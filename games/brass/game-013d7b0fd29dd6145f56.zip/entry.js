import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { AVATARS as a } from "@bgparty/sdk/avatars";
import { avatarNameAt as o, useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { playTurn as l, useSoundEdge as u } from "@bgparty/sdk/sfx";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { botAvatarOf as h } from "@bgparty/sdk/lobby";
import { ConfirmButton as g } from "@bgparty/sdk/confirm-button";
import { IconClose as _, IconExpand as v, IconLog as y } from "@bgparty/sdk/icons";
//#region src/games/brass/data.ts
var b = (e, t, n, r, i, a, o, s, c, l, u, d = 0, f = 0, p = !1) => ({
	industry: e,
	level: t,
	count: n,
	canal: r,
	rail: i,
	cost: a,
	coal: o,
	iron: s,
	vp: c,
	income: l,
	links: u,
	beer: d,
	produce: f,
	noDevelop: p
}), x = [
	b("brewery", 1, 2, !0, !1, 5, 0, 1, 4, 4, 2),
	b("brewery", 2, 2, !0, !0, 7, 0, 1, 5, 5, 2),
	b("brewery", 3, 2, !0, !0, 9, 0, 1, 7, 5, 2),
	b("brewery", 4, 1, !1, !0, 9, 0, 1, 10, 5, 2),
	b("coal", 1, 1, !0, !1, 5, 0, 0, 1, 4, 2, 0, 2),
	b("coal", 2, 2, !0, !0, 7, 0, 0, 2, 7, 1, 0, 3),
	b("coal", 3, 2, !0, !0, 8, 0, 1, 3, 6, 1, 0, 4),
	b("coal", 4, 2, !0, !0, 10, 0, 1, 4, 5, 1, 0, 5),
	b("cotton", 1, 3, !0, !1, 12, 0, 0, 5, 5, 1, 1),
	b("cotton", 2, 2, !0, !0, 14, 1, 0, 5, 4, 2, 1),
	b("cotton", 3, 3, !0, !0, 16, 1, 1, 9, 3, 1, 1),
	b("cotton", 4, 3, !0, !0, 18, 1, 1, 12, 2, 1, 1),
	b("iron", 1, 1, !0, !1, 5, 1, 0, 3, 3, 1, 0, 4),
	b("iron", 2, 1, !0, !0, 7, 1, 0, 5, 3, 1, 0, 4),
	b("iron", 3, 1, !0, !0, 9, 1, 0, 7, 2, 1, 0, 5),
	b("iron", 4, 1, !0, !0, 12, 1, 0, 9, 1, 1, 0, 6),
	b("manufacturer", 1, 1, !0, !1, 8, 1, 0, 3, 5, 2, 1),
	b("manufacturer", 2, 2, !0, !0, 10, 0, 1, 5, 1, 1, 1),
	b("manufacturer", 3, 1, !0, !0, 12, 2, 0, 4, 4, 0, 0),
	b("manufacturer", 4, 1, !0, !0, 8, 0, 1, 3, 6, 1, 1),
	b("manufacturer", 5, 2, !0, !0, 16, 1, 0, 8, 2, 2, 2),
	b("manufacturer", 6, 1, !0, !0, 20, 0, 0, 7, 6, 1, 1),
	b("manufacturer", 7, 1, !0, !0, 16, 1, 1, 9, 4, 0, 0),
	b("manufacturer", 8, 2, !0, !0, 20, 0, 2, 11, 1, 1, 1),
	b("pottery", 1, 1, !0, !0, 17, 0, 1, 10, 5, 1, 1, 0, !0),
	b("pottery", 2, 1, !0, !0, 0, 1, 0, 1, 1, 1, 1),
	b("pottery", 3, 1, !0, !0, 22, 2, 0, 11, 5, 1, 2, 0, !0),
	b("pottery", 4, 1, !0, !0, 0, 1, 0, 1, 1, 1, 1),
	b("pottery", 5, 1, !1, !0, 24, 2, 0, 20, 5, 1, 2)
];
function S(e, t) {
	let n = x.find((n) => n.industry === e && n.level === t);
	if (!n) throw Error(`no tile ${e} ${t}`);
	return n;
}
function C(e) {
	return x.filter((t) => t.industry === e).flatMap((e) => Array(e.count).fill(e.level)).reverse();
}
var w = [
	{
		id: "belper",
		nameKey: "games.brass.city.belper",
		region: "derbyshire",
		slots: [
			["cotton", "manufacturer"],
			["coal"],
			["pottery"]
		],
		x: 725,
		y: 55
	},
	{
		id: "derby",
		nameKey: "games.brass.city.derby",
		region: "derbyshire",
		slots: [
			["cotton", "brewery"],
			["cotton", "manufacturer"],
			["iron"]
		],
		x: 745,
		y: 160
	},
	{
		id: "leek",
		nameKey: "games.brass.city.leek",
		region: "staffordshire",
		slots: [["cotton", "manufacturer"], ["cotton", "coal"]],
		x: 440,
		y: 45
	},
	{
		id: "stokeOnTrent",
		nameKey: "games.brass.city.stokeOnTrent",
		region: "staffordshire",
		slots: [
			["cotton", "manufacturer"],
			["pottery", "iron"],
			["manufacturer"]
		],
		x: 310,
		y: 110
	},
	{
		id: "stone",
		nameKey: "games.brass.city.stone",
		region: "staffordshire",
		slots: [["cotton", "brewery"], ["manufacturer", "coal"]],
		x: 195,
		y: 185
	},
	{
		id: "uttoxeter",
		nameKey: "games.brass.city.uttoxeter",
		region: "staffordshire",
		slots: [["manufacturer", "brewery"], ["cotton", "brewery"]],
		x: 475,
		y: 160
	},
	{
		id: "stafford",
		nameKey: "games.brass.city.stafford",
		region: "midlands",
		slots: [["manufacturer", "brewery"], ["pottery"]],
		x: 260,
		y: 270
	},
	{
		id: "burtonOnTrent",
		nameKey: "games.brass.city.burtonOnTrent",
		region: "midlands",
		slots: [["manufacturer", "coal"], ["brewery"]],
		x: 620,
		y: 280
	},
	{
		id: "cannock",
		nameKey: "games.brass.city.cannock",
		region: "midlands",
		slots: [["manufacturer", "coal"], ["coal"]],
		x: 350,
		y: 355
	},
	{
		id: "tamworth",
		nameKey: "games.brass.city.tamworth",
		region: "midlands",
		slots: [["cotton", "coal"], ["cotton", "coal"]],
		x: 635,
		y: 380
	},
	{
		id: "walsall",
		nameKey: "games.brass.city.walsall",
		region: "midlands",
		slots: [["iron", "manufacturer"], ["manufacturer", "brewery"]],
		x: 430,
		y: 430
	},
	{
		id: "wolverhampton",
		nameKey: "games.brass.city.wolverhampton",
		region: "blackCountry",
		slots: [["manufacturer"], ["manufacturer", "coal"]],
		x: 255,
		y: 425
	},
	{
		id: "coalbrookdale",
		nameKey: "games.brass.city.coalbrookdale",
		region: "blackCountry",
		slots: [
			["iron", "brewery"],
			["iron"],
			["coal"]
		],
		x: 110,
		y: 455
	},
	{
		id: "dudley",
		nameKey: "games.brass.city.dudley",
		region: "blackCountry",
		slots: [["coal"], ["iron"]],
		x: 295,
		y: 510
	},
	{
		id: "kidderminster",
		nameKey: "games.brass.city.kidderminster",
		region: "blackCountry",
		slots: [["cotton", "coal"], ["cotton"]],
		x: 195,
		y: 600
	},
	{
		id: "worcester",
		nameKey: "games.brass.city.worcester",
		region: "blackCountry",
		slots: [["cotton"], ["cotton"]],
		x: 210,
		y: 720
	},
	{
		id: "birmingham",
		nameKey: "games.brass.city.birmingham",
		region: "birmingham",
		slots: [
			["cotton", "manufacturer"],
			["manufacturer"],
			["iron"],
			["manufacturer"]
		],
		x: 530,
		y: 535
	},
	{
		id: "coventry",
		nameKey: "games.brass.city.coventry",
		region: "birmingham",
		slots: [
			["pottery"],
			["manufacturer", "coal"],
			["iron", "manufacturer"]
		],
		x: 750,
		y: 565
	},
	{
		id: "nuneaton",
		nameKey: "games.brass.city.nuneaton",
		region: "birmingham",
		slots: [["manufacturer", "brewery"], ["cotton", "coal"]],
		x: 710,
		y: 460
	},
	{
		id: "redditch",
		nameKey: "games.brass.city.redditch",
		region: "birmingham",
		slots: [["manufacturer", "coal"], ["iron"]],
		x: 490,
		y: 640
	}
], T = [
	{
		id: "shrewsbury",
		nameKey: "games.brass.city.shrewsbury",
		slots: 1,
		minPlayers: 2,
		bonus: {
			kind: "vp",
			amount: 4
		},
		x: 25,
		y: 360
	},
	{
		id: "gloucester",
		nameKey: "games.brass.city.gloucester",
		slots: 2,
		minPlayers: 2,
		bonus: {
			kind: "develop",
			amount: 1
		},
		x: 75,
		y: 790
	},
	{
		id: "oxford",
		nameKey: "games.brass.city.oxford",
		slots: 2,
		minPlayers: 2,
		bonus: {
			kind: "income",
			amount: 2
		},
		x: 610,
		y: 740
	},
	{
		id: "warrington",
		nameKey: "games.brass.city.warrington",
		slots: 2,
		minPlayers: 3,
		bonus: {
			kind: "money",
			amount: 5
		},
		x: 180,
		y: 15
	},
	{
		id: "nottingham",
		nameKey: "games.brass.city.nottingham",
		slots: 2,
		minPlayers: 4,
		bonus: {
			kind: "vp",
			amount: 3
		},
		x: 835,
		y: 95
	}
], ee = [{
	id: "farmN",
	x: 385,
	y: 390
}, {
	id: "farmS",
	x: 175,
	y: 660
}], E = {
	2: [
		"blank",
		"blank",
		"any",
		"cotton",
		"manufacturer"
	],
	3: [
		"blank",
		"blank",
		"blank",
		"any",
		"cotton",
		"manufacturer",
		"pottery"
	],
	4: [
		"blank",
		"blank",
		"blank",
		"any",
		"cotton",
		"cotton",
		"manufacturer",
		"manufacturer",
		"pottery"
	]
}, D = (e, t, n = !0, r = !0) => ({
	id: e,
	nodes: t,
	canal: n,
	rail: r
}), O = [
	D("belper-derby", ["belper", "derby"]),
	D("belper-leek", ["belper", "leek"], !1, !0),
	D("birmingham-coventry", ["birmingham", "coventry"]),
	D("birmingham-dudley", ["birmingham", "dudley"]),
	D("birmingham-nuneaton", ["birmingham", "nuneaton"], !1, !0),
	D("birmingham-oxford", ["birmingham", "oxford"]),
	D("birmingham-redditch", ["birmingham", "redditch"], !1, !0),
	D("birmingham-tamworth", ["birmingham", "tamworth"]),
	D("birmingham-walsall", ["birmingham", "walsall"]),
	D("birmingham-worcester", ["birmingham", "worcester"]),
	D("burtonOnTrent-cannock", ["burtonOnTrent", "cannock"], !1, !0),
	D("burtonOnTrent-derby", ["burtonOnTrent", "derby"]),
	D("burtonOnTrent-stone", ["burtonOnTrent", "stone"]),
	D("burtonOnTrent-tamworth", ["burtonOnTrent", "tamworth"]),
	D("burtonOnTrent-walsall", ["burtonOnTrent", "walsall"], !0, !1),
	D("cannock-stafford", ["cannock", "stafford"]),
	D("cannock-farmN", ["cannock", "farmN"]),
	D("cannock-walsall", ["cannock", "walsall"]),
	D("cannock-wolverhampton", ["cannock", "wolverhampton"]),
	D("coalbrookdale-kidderminster", ["coalbrookdale", "kidderminster"]),
	D("coalbrookdale-shrewsbury", ["coalbrookdale", "shrewsbury"]),
	D("coalbrookdale-wolverhampton", ["coalbrookdale", "wolverhampton"]),
	D("coventry-nuneaton", ["coventry", "nuneaton"], !1, !0),
	D("derby-nottingham", ["derby", "nottingham"]),
	D("derby-uttoxeter", ["derby", "uttoxeter"], !1, !0),
	D("dudley-kidderminster", ["dudley", "kidderminster"]),
	D("dudley-wolverhampton", ["dudley", "wolverhampton"]),
	D("gloucester-redditch", ["gloucester", "redditch"]),
	D("gloucester-worcester", ["gloucester", "worcester"]),
	D("kidderminster-worcester", [
		"kidderminster",
		"farmS",
		"worcester"
	]),
	D("leek-stokeOnTrent", ["leek", "stokeOnTrent"]),
	D("nuneaton-tamworth", ["nuneaton", "tamworth"]),
	D("redditch-oxford", ["redditch", "oxford"]),
	D("stafford-stone", ["stafford", "stone"]),
	D("stokeOnTrent-stone", ["stokeOnTrent", "stone"]),
	D("stokeOnTrent-warrington", ["stokeOnTrent", "warrington"]),
	D("stone-uttoxeter", ["stone", "uttoxeter"], !1, !0),
	D("tamworth-walsall", ["tamworth", "walsall"], !1, !0),
	D("walsall-wolverhampton", ["walsall", "wolverhampton"])
];
function k(e) {
	let t = w.find((t) => t.id === e);
	if (t) return {
		x: t.x,
		y: t.y
	};
	let n = T.find((t) => t.id === e);
	if (n) return {
		x: n.x,
		y: n.y
	};
	let r = ee.find((t) => t.id === e);
	if (r) return {
		x: r.x,
		y: r.y
	};
	throw Error(`no node ${e}`);
}
[...[
	,
	,
	,
	,
].fill({ kind: "wildLocation" }), ...[
	,
	,
	,
	,
].fill({ kind: "wildIndustry" })];
function te(e) {
	let t = (e, t) => Array(t).fill({
		kind: "location",
		city: e
	}), n = (e, t) => Array(t).fill({
		kind: "industry",
		industries: [e]
	}), r = (e) => Array(e).fill({
		kind: "industry",
		industries: ["cotton", "manufacturer"]
	}), i = [
		...t("stafford", 2),
		...t("burtonOnTrent", 2),
		...t("cannock", 2),
		...t("tamworth", 1),
		...t("walsall", 1),
		...t("coalbrookdale", 3),
		...t("dudley", 2),
		...t("kidderminster", 2),
		...t("wolverhampton", 2),
		...t("worcester", 2),
		...t("birmingham", 3),
		...t("coventry", 3),
		...t("nuneaton", 1),
		...t("redditch", 1)
	], a = [
		...n("iron", 4),
		...n("coal", 2),
		...n("pottery", 2),
		...n("brewery", 5)
	], o = 0;
	return e >= 3 && (i.push(...t("leek", 2), ...t("stokeOnTrent", 3), ...t("stone", 2), ...t("uttoxeter", 1)), o = 6), e >= 4 && (i.push(...t("belper", 2), ...t("derby", 3), ...t("uttoxeter", 1)), a.push(...n("coal", 1), ...n("pottery", 1)), o = 8), [
		...i,
		...a,
		...r(o)
	];
}
var A = [
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7
], j = [
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5
];
function M(e) {
	return e <= 10 ? e - 10 : e <= 30 ? 1 + Math.floor((e - 11) / 2) : e <= 60 ? 11 + Math.floor((e - 31) / 3) : e <= 96 ? 21 + Math.floor((e - 61) / 4) : 30;
}
function N(e) {
	return e <= 0 ? e + 10 : e <= 10 ? 2 * e + 10 : e <= 20 ? 3 * e - 2 : e <= 29 ? 4 * e - 20 : 99;
}
var P = [
	"cotton",
	"manufacturer",
	"pottery"
], F = {
	id: "brass",
	tier: "alpha",
	mechanics: ["route-building"],
	interactionTags: [],
	nameKey: "games.brass.name",
	descKey: "games.brass.desc",
	rulesKey: "games.brass.rules",
	icon: "🏭",
	iconImg: "games/brass.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/brass/en.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3, 4],
	accent: "#8a5a2b",
	releasedAt: "2026-09-17",
	search: {
		py: "bo ming han",
		init: "bmh"
	},
	hotseat: "cover"
}, I = t.enum([
	"cotton",
	"manufacturer",
	"pottery",
	"brewery",
	"coal",
	"iron"
]), ne = t.enum([
	"belper",
	"derby",
	"leek",
	"stokeOnTrent",
	"stone",
	"uttoxeter",
	"stafford",
	"burtonOnTrent",
	"cannock",
	"tamworth",
	"walsall",
	"wolverhampton",
	"coalbrookdale",
	"dudley",
	"kidderminster",
	"worcester",
	"birmingham",
	"coventry",
	"nuneaton",
	"redditch"
]), re = t.enum(["farmN", "farmS"]), L = t.enum([
	"shrewsbury",
	"gloucester",
	"oxford",
	"warrington",
	"nottingham"
]), ie = t.union([t.object({
	city: ne,
	slot: t.int().nonnegative()
}), t.object({ farm: re })]), R = t.union([t.object({
	kind: t.literal("tile"),
	at: ie
}), t.object({
	kind: t.literal("merchant"),
	index: t.int().nonnegative()
})]), z = t.int().nonnegative(), B = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("build"),
		card: z,
		at: ie,
		industry: I.optional()
	}),
	t.object({
		type: t.literal("network"),
		card: z,
		links: t.array(t.string().min(1)).min(1).max(2),
		beerFrom: ie.optional()
	}),
	t.object({
		type: t.literal("develop"),
		card: z,
		industries: t.array(I).min(1).max(2)
	}),
	t.object({
		type: t.literal("sell"),
		card: z,
		sales: t.array(t.object({
			tile: ie,
			beers: t.array(R)
		})).min(1),
		bonusDevelop: t.array(I).max(2).optional()
	}),
	t.object({
		type: t.literal("loan"),
		card: z
	}),
	t.object({
		type: t.literal("scout"),
		cards: t.tuple([
			z,
			z,
			z
		])
	}),
	t.object({
		type: t.literal("pass"),
		card: z
	}),
	t.object({
		type: t.literal("payDebt"),
		tiles: t.array(ie).min(1)
	})
]), ae = t.union([
	t.object({
		kind: t.literal("location"),
		city: ne
	}),
	t.object({
		kind: t.literal("industry"),
		industries: t.array(I).min(1).max(2)
	}),
	t.object({ kind: t.literal("wildLocation") }),
	t.object({ kind: t.literal("wildIndustry") })
]), oe = t.object({
	industry: I,
	level: t.int().min(1),
	owner: t.int().nonnegative(),
	flipped: t.boolean(),
	cubes: t.int().nonnegative()
}), se = t.enum([
	"cotton",
	"manufacturer",
	"pottery",
	"any",
	"blank"
]), ce = t.object({
	phase: t.enum(["play", "done"]),
	era: t.enum(["canal", "rail"]),
	round: t.int().min(1),
	order: t.array(t.int().nonnegative()),
	turnIdx: t.int().nonnegative(),
	actionsLeft: t.int().min(0),
	players: t.array(t.object({
		rid: t.string(),
		money: t.int(),
		incomeLevel: t.int(),
		vp: t.int(),
		linkStock: t.int().nonnegative(),
		handCount: t.int().nonnegative(),
		stacks: t.record(t.string(), t.array(t.int().min(1))),
		spent: t.int().nonnegative()
	})),
	board: t.record(t.string(), oe),
	links: t.record(t.string(), t.int().nonnegative()),
	merchants: t.array(t.object({
		location: L,
		buys: se,
		beer: t.boolean()
	})),
	coalMarket: t.int().nonnegative(),
	ironMarket: t.int().nonnegative(),
	deckCount: t.int().nonnegative(),
	wilds: t.object({
		location: t.int().nonnegative(),
		industry: t.int().nonnegative()
	}),
	pendingDebt: t.array(t.object({
		rid: t.string(),
		need: t.int().min(1)
	})),
	eraScores: t.array(t.object({
		era: t.enum(["canal", "rail"]),
		rid: t.string(),
		industryVp: t.int(),
		linkVp: t.int()
	})).nullable(),
	winner: t.string().nullable()
}), le = t.object({ hand: t.array(ae) }), V = (e) => ({ code: e }), H = (e) => "city" in e ? `${e.city}:${e.slot}` : `farm:${e.farm}`, ue = (e) => "city" in e ? e.city : e.farm;
function U(t, n, r) {
	for (let i = t.length - 1; i > 0; i--) {
		let a = e(n, r, i + 1);
		r++, [t[i], t[a]] = [t[a], t[i]];
	}
	return r;
}
function de(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of O) if (e.links[n.id] !== void 0) for (let e of n.nodes) for (let r of n.nodes) e !== r && (t.has(e) || t.set(e, []), t.get(e).push(r));
	return t;
}
function W(e, t) {
	let n = /* @__PURE__ */ new Map([[t, 0]]), r = [t];
	for (; r.length > 0;) {
		let t = r.shift();
		for (let i of e.get(t) ?? []) n.has(i) || (n.set(i, n.get(t) + 1), r.push(i));
	}
	return n;
}
function fe(e, t) {
	let n = /* @__PURE__ */ new Set();
	for (let [r, i] of Object.entries(e.board)) i.owner === t && n.add(r.startsWith("farm:") ? r.slice(5) : r.split(":")[0]);
	for (let [r, i] of Object.entries(e.links)) {
		if (i !== t) continue;
		let e = O.find((e) => e.id === r);
		for (let t of e.nodes) n.add(t);
	}
	return n;
}
var G = (e, t) => Object.values(e.board).some((e) => e.owner === t) || Object.values(e.links).some((e) => e === t);
function pe(e, t) {
	t.flipped = !0, t.cubes = 0, e.incomeSpace[t.owner] = Math.min(99, e.incomeSpace[t.owner] + S(t.industry, t.level).income);
}
function me(e, t) {
	t.cubes--, t.cubes === 0 && pe(e, t);
}
var K = (e, t, n) => t === 0 ? n : e[e.length - t];
function he(e, t, n, r) {
	let i = de(e);
	for (let a = 0; a < n; a++) {
		let n = W(i, r), a = null, o = Infinity, s = !1;
		for (let [r, i] of Object.entries(e.board)) {
			if (i.industry !== "coal" || i.flipped || i.cubes === 0) continue;
			let e = r.split(":")[0], c = n.get(e);
			if (c === void 0) continue;
			let l = i.owner === t;
			(c < o || c === o && l && !s) && (a = r, o = c, s = l);
		}
		if (a) {
			me(e, e.board[a]);
			continue;
		}
		if (!T.some((e) => n.has(e.id))) return V("games.brass.errNoCoal");
		let c = K(A, e.coalMarket, 8);
		if (e.money[t] < c) return V("games.brass.errCantAfford");
		e.money[t] -= c, e.spent[t] += c, e.coalMarket > 0 && e.coalMarket--;
	}
	return null;
}
function ge(e, t, n) {
	for (let r = 0; r < n; r++) {
		let n = Object.entries(e.board).filter(([, e]) => e.industry === "iron" && !e.flipped && e.cubes > 0), r = n.find(([, e]) => e.owner === t) ?? n[0];
		if (r) {
			me(e, r[1]);
			continue;
		}
		let i = K(j, e.ironMarket, 6);
		if (e.money[t] < i) return V("games.brass.errCantAfford");
		e.money[t] -= i, e.spent[t] += i, e.ironMarket > 0 && e.ironMarket--;
	}
	return null;
}
function _e(e, t, n, r) {
	if (n.industry !== "coal" && n.industry !== "iron") return;
	if (n.industry === "coal") {
		let t = W(de(e), r);
		if (!T.some((e) => t.has(e.id))) return;
	}
	let i = n.industry === "coal" ? A : j;
	for (; n.cubes > 0;) {
		let r = n.industry === "coal" ? e.coalMarket : e.ironMarket;
		if (r >= i.length) break;
		let a = i[i.length - r - 1];
		e.money[t] += a, n.cubes--, n.industry === "coal" ? e.coalMarket++ : e.ironMarket++;
	}
	n.cubes === 0 && pe(e, n);
}
function q(e, t, n) {
	let r = e.hands[e.players[t]], i = r[n];
	return i ? (r.splice(n, 1), i.kind === "wildLocation" ? e.wilds.location++ : i.kind === "wildIndustry" ? e.wilds.industry++ : e.discard.push(i), i) : V("games.brass.errBadCard");
}
function ve(e, t) {
	let n = e.hands[e.players[t]];
	for (; n.length < 8 && e.deck.length > 0;) n.push(e.deck.pop());
}
function ye(e, t, n, r, i) {
	let a = "farm" in r;
	if (n.kind === "location") return a || r.city !== n.city ? V("games.brass.errBadCard") : i === void 0 ? V("games.brass.errNeedIndustry") : { industry: i };
	if (n.kind === "wildLocation") return a ? V("games.brass.errBadCard") : i === void 0 ? V("games.brass.errNeedIndustry") : { industry: i };
	let o;
	if (n.kind === "industry") {
		if (n.industries.length === 1) {
			if (i !== void 0 && i !== n.industries[0]) return V("games.brass.errBadCard");
			o = n.industries[0];
		} else {
			if (i === void 0 || !n.industries.includes(i)) return V("games.brass.errNeedIndustry");
			o = i;
		}
	} else {
		if (i === void 0) return V("games.brass.errNeedIndustry");
		o = i;
	}
	return a ? o === "brewery" ? { industry: o } : V("games.brass.errFarmBrewery") : G(e, t) && !fe(e, t).has(r.city) ? V("games.brass.errNotInNetwork") : { industry: o };
}
function be(e, t, n) {
	let r = e.hands[e.players[t]][n.card];
	if (!r) return V("games.brass.errBadCard");
	let i = ye(e, t, r, n.at, n.industry);
	if ("code" in i) return i;
	let { industry: a } = i, o = e.stacks[e.players[t]][a];
	if (!o || o.length === 0) return V("games.brass.errNoTile");
	let s = o[o.length - 1], c = S(a, s);
	if (e.era === "canal" && !c.canal || e.era === "rail" && !c.rail) return V("games.brass.errEraLocked");
	let l = H(n.at), u = e.board[l], d = ue(n.at);
	if (u) {
		if (u.industry !== a || s <= u.level) return V("games.brass.errBadOverbuild");
		if (u.owner !== t) {
			if (a !== "coal" && a !== "iron") return V("games.brass.errBadOverbuild");
			let t = Object.values(e.board).some((e) => e.industry === a && !e.flipped && e.cubes > 0), n = a === "coal" ? e.coalMarket > 0 : e.ironMarket > 0;
			if (t || n) return V("games.brass.errBadOverbuild");
		}
	} else {
		let r = n.at;
		if ("farm" in r) {
			if (a !== "brewery") return V("games.brass.errBadSlot");
		} else {
			let n = w.find((e) => e.id === r.city), i = n.slots[r.slot];
			if (!i || !i.includes(a)) return V("games.brass.errBadSlot");
			if (i.length > 1 && n.slots.some((t, r) => t.length === 1 && t[0] === a && e.board[`${n.id}:${r}`] === void 0)) return V("games.brass.errSingleSlotFirst");
			if (e.era === "canal" && Object.keys(e.board).some((r) => r.startsWith(`${n.id}:`) && e.board[r].owner === t)) return V("games.brass.errOnePerCity");
		}
	}
	if (e.money[t] < c.cost) return V("games.brass.errCantAfford");
	let f = ge(e, t, c.iron);
	if (f) return f;
	let p = he(e, t, c.coal, d);
	if (p) return p;
	e.money[t] -= c.cost, e.spent[t] += c.cost;
	let m = q(e, t, n.card);
	if ("code" in m) return m;
	o.pop();
	let h = a === "coal" || a === "iron" ? c.produce : a === "brewery" ? e.era === "canal" ? 1 : 2 : 0;
	return e.board[l] = {
		industry: a,
		level: s,
		owner: t,
		flipped: !1,
		cubes: h
	}, _e(e, t, e.board[l], d), null;
}
function xe(e, t, n) {
	if (!e.hands[e.players[t]][n.card]) return V("games.brass.errBadCard");
	if (e.era === "canal" && n.links.length !== 1) return V("games.brass.errBadLinks");
	let r = [];
	for (let t of n.links) {
		let n = O.find((e) => e.id === t);
		if (!n || e.links[t] !== void 0 || (e.era === "canal" ? !n.canal : !n.rail)) return V("games.brass.errBadLinks");
		r.push(n);
	}
	if (new Set(n.links).size !== n.links.length) return V("games.brass.errBadLinks");
	if (e.linkStock[t] < n.links.length) return V("games.brass.errNoTile");
	let i = e.era === "canal" ? 3 : n.links.length === 1 ? 5 : 15;
	if (e.money[t] < i) return V("games.brass.errCantAfford");
	if (n.links.length === 2) {
		if (!n.beerFrom) return V("games.brass.errNeedBeer");
		let t = e.board[H(n.beerFrom)];
		if (!t || t.industry !== "brewery" || t.flipped || t.cubes === 0) return V("games.brass.errNeedBeer");
	}
	let a = fe(e, t), o = !G(e, t);
	for (let n = 0; n < r.length; n++) {
		let i = r[n];
		if (!o && !i.nodes.some((e) => a.has(e))) return V("games.brass.errNotInNetwork");
		if (e.era === "rail") {
			e.links[i.id] = t;
			let n = de(e), r = (() => {
				let r = W(n, i.nodes[0]), a = W(n, i.nodes[i.nodes.length - 1]), o = null, s = Infinity, c = !1;
				for (let [n, i] of Object.entries(e.board)) {
					if (i.industry !== "coal" || i.flipped || i.cubes === 0) continue;
					let e = n.split(":")[0], l = Math.min(r.get(e) ?? Infinity, a.get(e) ?? Infinity);
					if (l === Infinity) continue;
					let u = i.owner === t;
					(l < s || l === s && u && !c) && (o = n, s = l, c = u);
				}
				if (o) return me(e, e.board[o]), null;
				if (!T.some((e) => r.has(e.id) || a.has(e.id))) return V("games.brass.errNoCoal");
				let l = K(A, e.coalMarket, 8);
				return e.money[t] < l ? V("games.brass.errCantAfford") : (e.money[t] -= l, e.spent[t] += l, e.coalMarket > 0 && e.coalMarket--, null);
			})();
			if (r) return delete e.links[i.id], r;
		} else e.links[i.id] = t;
		for (let e of i.nodes) a.add(e);
	}
	if (n.links.length === 2 && n.beerFrom) {
		let i = e.board[H(n.beerFrom)];
		if (i.owner !== t) {
			let t = W(de(e), ue(n.beerFrom));
			if (!r[1].nodes.some((e) => t.has(e))) return V("games.brass.errBeerNotConnected");
		}
		me(e, i);
	}
	e.money[t] -= i, e.spent[t] += i, e.linkStock[t] -= n.links.length;
	let s = q(e, t, n.card);
	return "code" in s ? s : null;
}
function Se(e, t, n) {
	if (!e.hands[e.players[t]][n.card]) return V("games.brass.errBadCard");
	let r = ge(e, t, n.industries.length);
	if (r) return r;
	for (let r of n.industries) {
		let n = e.stacks[e.players[t]][r];
		if (!n || n.length === 0) return V("games.brass.errNoTile");
		if (S(r, n[n.length - 1]).noDevelop) return V("games.brass.errLightbulb");
		n.pop();
	}
	let i = q(e, t, n.card);
	return "code" in i ? i : null;
}
function Ce(e, t, n) {
	let r = e.stacks[e.players[t]][n];
	return !r || r.length === 0 ? V("games.brass.errNoTile") : S(n, r[r.length - 1]).noDevelop ? V("games.brass.errLightbulb") : (r.pop(), null);
}
function we(e, t, n) {
	if (!e.hands[e.players[t]][n.card]) return V("games.brass.errBadCard");
	let r = de(e), i = 0;
	for (let a of n.sales) {
		let n = H(a.tile), o = e.board[n];
		if (!o || o.owner !== t || o.flipped || !P.includes(o.industry)) return V("games.brass.errBadSell");
		let s = S(o.industry, o.level);
		if (a.beers.length !== s.beer) return V("games.brass.errNeedBeer");
		let c = W(r, ue(a.tile));
		if (e.merchants.filter((e) => (e.buys === "any" || e.buys === o.industry) && c.has(e.location)).length === 0) return V("games.brass.errNoMerchant");
		let l = /* @__PURE__ */ new Set();
		for (let n of a.beers) if (n.kind === "merchant") {
			let t = e.merchants[n.index];
			if (!t || !t.beer) return V("games.brass.errNeedBeer");
			if (t.buys !== "any" && t.buys !== o.industry || !c.has(t.location)) return V("games.brass.errNoMerchant");
			l.add(n.index);
		} else {
			let r = H(n.at), i = e.board[r];
			if (!i || i.industry !== "brewery" || i.flipped || i.cubes === 0) return V("games.brass.errNeedBeer");
			if (i.owner !== t && !c.has(ue(n.at))) return V("games.brass.errBeerNotConnected");
		}
		if (l.size > 1) return V("games.brass.errOneMerchant");
		for (let n of a.beers) if (n.kind === "merchant") {
			let r = e.merchants[n.index];
			r.beer = !1;
			let a = T.find((e) => e.id === r.location).bonus;
			a.kind === "vp" ? e.vp[t] += a.amount : a.kind === "money" ? e.money[t] += a.amount : a.kind === "income" ? e.incomeSpace[t] = Math.min(99, e.incomeSpace[t] + a.amount) : i++;
		} else me(e, e.board[H(n.at)]);
		pe(e, o);
	}
	let a = n.bonusDevelop ?? [];
	if (a.length !== i) return V("games.brass.errBonusDevelop");
	for (let n of a) {
		let r = Ce(e, t, n);
		if (r) return r;
	}
	let o = q(e, t, n.card);
	return "code" in o ? o : null;
}
function Te(e, t, n) {
	if (!e.hands[e.players[t]][n.card]) return V("games.brass.errBadCard");
	let r = M(e.incomeSpace[t]);
	if (r - 3 < -10) return V("games.brass.errLoanFloor");
	e.money[t] += 30, e.incomeSpace[t] = N(r - 3);
	let i = q(e, t, n.card);
	return "code" in i ? i : null;
}
function Ee(e, t, n) {
	let r = e.hands[e.players[t]];
	if (r.some((e) => e.kind === "wildLocation" || e.kind === "wildIndustry")) return V("games.brass.errHasWild");
	if (e.wilds.location === 0 || e.wilds.industry === 0) return V("games.brass.errNoWild");
	if (new Set(n.cards).size !== 3 || n.cards.some((e) => !r[e])) return V("games.brass.errBadCard");
	for (let r of [...n.cards].sort((e, t) => t - e)) {
		let n = q(e, t, r);
		if ("code" in n) return n;
	}
	return e.wilds.location--, e.wilds.industry--, r.push({ kind: "wildLocation" }, { kind: "wildIndustry" }), null;
}
function De(e, t, n) {
	let r = e.pendingDebt.find((n) => n.rid === e.players[t]);
	if (!r) return V("games.brass.errNoDebt");
	let i = 0, a = [];
	for (let o of n.tiles) {
		let n = H(o), s = e.board[n];
		if (!s || s.owner !== t) return V("games.brass.errBadSell");
		if (i >= r.need) return V("games.brass.errOverpay");
		a.push(n), i += Math.floor(S(s.industry, s.level).cost / 2);
	}
	for (let t of a) delete e.board[t];
	e.money[t] += i;
	let o = Math.min(e.money[t], r.need);
	return e.money[t] -= o, r.need -= o, r.need <= 0 ? e.pendingDebt = e.pendingDebt.filter((e) => e !== r) : Object.values(e.board).some((e) => e.owner === t) || (e.vp[t] = Math.max(0, e.vp[t] - r.need), e.pendingDebt = e.pendingDebt.filter((e) => e !== r)), null;
}
function Oe(e) {
	return e.era === "canal" && e.round === 1 ? 1 : 2;
}
function ke(e) {
	let t = e.players.map(() => 0), n = e.players.map(() => 0), r = (t) => {
		if (T.some((e) => e.id === t)) return 2;
		let n = 0;
		for (let [r, i] of Object.entries(e.board)) i.flipped && (r.startsWith("farm:") ? r.slice(5) : r.split(":")[0]) === t && (n += S(i.industry, i.level).links);
		return n;
	};
	for (let [t, i] of Object.entries(e.links)) {
		let e = O.find((e) => e.id === t);
		n[i] += r(e.nodes[0]) + r(e.nodes[e.nodes.length - 1]);
	}
	for (let n of Object.values(e.board)) n.flipped && (t[n.owner] += S(n.industry, n.level).vp);
	e.players.forEach((r, i) => {
		e.vp[i] += t[i] + n[i], e.eraScores ||= [], e.eraScores.push({
			era: e.era,
			rid: r,
			industryVp: t[i],
			linkVp: n[i]
		});
	});
}
function Ae(e) {
	if (ke(e), e.era === "rail") {
		e.phase = "done";
		let t = e.players.map((e, t) => t).sort((t, n) => {
			if (e.vp[t] !== e.vp[n]) return e.vp[n] - e.vp[t];
			let r = M(e.incomeSpace[t]), i = M(e.incomeSpace[n]);
			return r === i ? e.money[n] - e.money[t] : i - r;
		});
		e.winner = e.players[t[0]];
		return;
	}
	for (let t of Object.keys(e.board)) e.board[t].level === 1 && delete e.board[t];
	for (let t of e.merchants) t.buys !== "blank" && (t.beer = !0);
	e.deck = e.discard, e.discard = [], e.rngCursor = U(e.deck, e.seed, e.rngCursor);
	for (let t of e.players) e.hands[t] = [], ve(e, e.players.indexOf(t));
	e.era = "rail", e.round = 1, e.links = {}, e.turnIdx = 0, e.actionsLeft = Oe(e);
}
function je(e) {
	e.order = [...e.order].sort((t, n) => e.spent[t] - e.spent[n]), e.spent = e.players.map(() => 0);
	let t = e.deck.length === 0 && e.players.every((t) => e.hands[t].length === 0);
	if (t && e.era === "rail" || e.players.forEach((t, n) => {
		let r = M(e.incomeSpace[n]);
		if (r >= 0) e.money[n] += r;
		else {
			let i = -r, a = Math.min(e.money[n], i);
			e.money[n] -= a;
			let o = i - a;
			o > 0 && (Object.values(e.board).some((e) => e.owner === n) || (e.vp[n] = Math.max(0, e.vp[n] - o), o = 0), o > 0 && e.pendingDebt.push({
				rid: t,
				need: o
			}));
		}
	}), e.pendingDebt.length > 0) {
		e.afterDebt = t ? "endEra" : "nextRound";
		return;
	}
	t ? Ae(e) : (e.round++, e.turnIdx = 0, e.actionsLeft = Oe(e));
}
function Me(e) {
	if (ve(e, e.order[e.turnIdx]), e.actionsLeft--, !(e.actionsLeft > 0)) {
		for (e.turnIdx++; e.turnIdx < e.players.length;) {
			e.actionsLeft = Oe(e);
			let t = e.players[e.order[e.turnIdx]];
			if (e.hands[t].length > 0) return;
			e.turnIdx++;
		}
		je(e);
	}
}
function Ne(e, t, n) {
	let r = 0, i = te(t.length);
	r = U(i, n, r);
	let a = t.map((e, t) => t);
	r = U(a, n, r);
	let o = {};
	for (let e of t) o[e] = [];
	for (let e = 0; e < 8; e++) for (let e of t) o[e].push(i.pop());
	let s = [];
	for (let e = 0; e < t.length; e++) s.push(i.pop());
	let c = [...E[t.length]];
	r = U(c, n, r);
	let l = [];
	for (let e of T) if (!(t.length < e.minPlayers)) for (let t = 0; t < e.slots; t++) {
		let t = c.pop();
		l.push({
			location: e.id,
			buys: t,
			beer: t !== "blank"
		});
	}
	let u = {};
	for (let e of t) u[e] = {
		cotton: C("cotton"),
		manufacturer: C("manufacturer"),
		pottery: C("pottery"),
		brewery: C("brewery"),
		coal: C("coal"),
		iron: C("iron")
	};
	return { state: {
		seed: n,
		rngCursor: r,
		players: t,
		phase: "play",
		era: "canal",
		round: 1,
		order: a,
		turnIdx: 0,
		actionsLeft: 1,
		spent: t.map(() => 0),
		hands: o,
		deck: i,
		discard: s,
		wilds: {
			location: 4,
			industry: 4
		},
		board: {},
		links: {},
		stacks: u,
		money: t.map(() => 17),
		incomeSpace: t.map(() => 10),
		vp: t.map(() => 0),
		coalMarket: 13,
		ironMarket: 8,
		merchants: l,
		linkStock: t.map(() => 14),
		pendingDebt: [],
		afterDebt: null,
		eraScores: null,
		winner: null
	} };
}
function Pe(e, t, n) {
	let r = structuredClone(e), i = r.players.indexOf(n.by);
	if (i < 0 || r.phase !== "play") return V("games.brass.errNotPlaying");
	if (r.pendingDebt.length > 0) {
		if (t.type !== "payDebt") return V("games.brass.errDebtPending");
		if (!r.pendingDebt.some((e) => e.rid === n.by)) return V("games.brass.errNoDebt");
		let e = De(r, i, t);
		if (e) return e;
		if (r.pendingDebt.length === 0) {
			let e = r.afterDebt;
			r.afterDebt = null, e === "endEra" ? Ae(r) : (r.round++, r.turnIdx = 0, r.actionsLeft = Oe(r));
		}
		return { state: r };
	}
	if (t.type === "payDebt") return V("games.brass.errNoDebt");
	if (r.order[r.turnIdx] !== i) return V("games.brass.errNotYourTurn");
	let a = [], o;
	switch (t.type) {
		case "build":
			o = be(r, i, t);
			break;
		case "network":
			o = xe(r, i, t);
			break;
		case "develop":
			o = Se(r, i, t);
			break;
		case "sell":
			o = we(r, i, t);
			break;
		case "loan":
			o = Te(r, i, t);
			break;
		case "scout":
			o = Ee(r, i, t);
			break;
		case "pass": {
			let e = q(r, i, t.card);
			o = "code" in e ? e : null;
			break;
		}
	}
	return o || (Me(r), {
		state: r,
		fx: a
	});
}
function Fe(e, t) {
	return {
		public: {
			phase: e.phase,
			era: e.era,
			round: e.round,
			order: e.order,
			turnIdx: e.turnIdx,
			actionsLeft: e.actionsLeft,
			players: e.players.map((t, n) => ({
				rid: t,
				money: e.money[n],
				incomeLevel: M(e.incomeSpace[n]),
				vp: e.vp[n],
				linkStock: e.linkStock[n],
				handCount: e.hands[t].length,
				stacks: Object.fromEntries(Object.entries(e.stacks[t]).map(([e, t]) => [e, [...t]])),
				spent: e.spent[n]
			})),
			board: structuredClone(e.board),
			links: { ...e.links },
			merchants: e.merchants.map((e) => ({ ...e })),
			coalMarket: e.coalMarket,
			ironMarket: e.ironMarket,
			deckCount: e.deck.length,
			wilds: { ...e.wilds },
			pendingDebt: e.pendingDebt.map((e) => ({ ...e })),
			eraScores: e.eraScores ? e.eraScores.map((e) => ({ ...e })) : null,
			winner: e.winner
		},
		private: { hand: [...e.hands[t]] }
	};
}
function Ie(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = e.players.map((e, t) => t).sort((t, n) => {
		if (e.vp[t] !== e.vp[n]) return e.vp[n] - e.vp[t];
		let r = M(e.incomeSpace[t]), i = M(e.incomeSpace[n]);
		return r === i ? e.money[n] - e.money[t] : i - r;
	}), n = t.filter((n) => e.vp[n] === e.vp[t[0]] && M(e.incomeSpace[n]) === M(e.incomeSpace[t[0]]) && e.money[n] === e.money[t[0]]);
	return {
		phase: e.phase,
		winner: n.map((t) => e.players[t]),
		ranking: t.map((t) => e.players[t]),
		scores: Object.fromEntries(e.players.map((t, n) => [t, e.vp[n]]))
	};
}
var Le = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: F,
	schemas: {
		action: B,
		publicView: ce,
		privateView: le
	},
	setup: Ne,
	reduce: Pe,
	viewFor: Fe,
	status: Ie
}, Re = {
	cotton: {
		icon: "🧵",
		color: "var(--color-brass-cotton)"
	},
	manufacturer: {
		icon: "🏭",
		color: "var(--color-brass-manufacturer)"
	},
	pottery: {
		icon: "🏺",
		color: "var(--color-brass-pottery)"
	},
	brewery: {
		icon: "🍺",
		color: "var(--color-brass-brewery)"
	},
	coal: {
		icon: "🪨",
		color: "var(--color-brass-coal)"
	},
	iron: {
		icon: "⛏️",
		color: "var(--color-brass-iron)"
	}
};
function ze({ industry: e, x: t = 12, y: n = 12, size: r = 24 }) {
	return /* @__PURE__ */ m("g", {
		transform: `translate(${t - r / 2},${n - r / 2}) scale(${r / 24})`,
		fill: "none",
		stroke: Re[e].color,
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: [
			e === "cotton" && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "M5 6c2-3 5-3 7 0 2-3 5-3 7 0 2 3 0 5-2 6 3 2 2 5-1 6-2 1-3 0-4-2-1 2-3 3-5 2-3-1-4-4-1-6-2-1-3-3-1-6Z" }), /* @__PURE__ */ p("path", { d: "M12 14v7" })] }),
			e === "manufacturer" && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "M3 20V9l6 4V9l6 4V5h5v15Z" }), /* @__PURE__ */ p("path", { d: "M7 17h2m3 0h2m3 0h2" })] }),
			e === "pottery" && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "M7 3h10M9 3v4c0 2-4 4-4 9 0 3 3 5 7 5s7-2 7-5c0-5-4-7-4-9V3" }), /* @__PURE__ */ p("path", { d: "M7 15h10" })] }),
			e === "brewery" && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "M7 4h10v4l-2 3v9H9v-9L7 8Z" }), /* @__PURE__ */ p("path", { d: "M7 8h10m-8 7h6" })] }),
			e === "coal" && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "m3 17 5-10 9-3 4 11-7 6Z" }), /* @__PURE__ */ p("path", { d: "m8 7 5 7 8 1m-8-1 1 7" })] }),
			e === "iron" && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", { d: "M3 8h18l-2 5-6 1-2 3H7l-2-3-2-1Z" }), /* @__PURE__ */ p("path", { d: "M8 17h8v4H8z" })] })
		]
	});
}
function Be({ industry: e, size: t = 22 }) {
	return /* @__PURE__ */ p("svg", {
		width: t,
		height: t,
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		children: /* @__PURE__ */ p(ze, { industry: e })
	});
}
//#endregion
//#region src/games/brass/name-keys.ts
var J = {
	belper: "games.brass.city.belper",
	derby: "games.brass.city.derby",
	leek: "games.brass.city.leek",
	stokeOnTrent: "games.brass.city.stokeOnTrent",
	stone: "games.brass.city.stone",
	uttoxeter: "games.brass.city.uttoxeter",
	stafford: "games.brass.city.stafford",
	burtonOnTrent: "games.brass.city.burtonOnTrent",
	cannock: "games.brass.city.cannock",
	tamworth: "games.brass.city.tamworth",
	walsall: "games.brass.city.walsall",
	wolverhampton: "games.brass.city.wolverhampton",
	coalbrookdale: "games.brass.city.coalbrookdale",
	dudley: "games.brass.city.dudley",
	kidderminster: "games.brass.city.kidderminster",
	worcester: "games.brass.city.worcester",
	birmingham: "games.brass.city.birmingham",
	coventry: "games.brass.city.coventry",
	nuneaton: "games.brass.city.nuneaton",
	redditch: "games.brass.city.redditch",
	shrewsbury: "games.brass.city.shrewsbury",
	gloucester: "games.brass.city.gloucester",
	oxford: "games.brass.city.oxford",
	warrington: "games.brass.city.warrington",
	nottingham: "games.brass.city.nottingham",
	farmN: "games.brass.city.farmN",
	farmS: "games.brass.city.farmS"
}, Y = {
	cotton: "games.brass.industry.cotton",
	manufacturer: "games.brass.industry.manufacturer",
	pottery: "games.brass.industry.pottery",
	brewery: "games.brass.industry.brewery",
	coal: "games.brass.industry.coal",
	iron: "games.brass.industry.iron"
}, X = 30, Ve = 3, He = 5;
function Ue(e, t) {
	let n = w.find((t) => t.id === e), r = Math.min(n.slots.length, 2), i = Math.ceil(n.slots.length / 2), a = 10 + r * X + (r - 1) * Ve, o = 10 + i * X + (i - 1) * Ve;
	return {
		x: n.x - a / 2 + He + X / 2 + t % 2 * 33,
		y: n.y - o / 2 + He + X / 2 + Math.floor(t / 2) * 33
	};
}
function We(e) {
	let t = w.find((t) => t.id === e), n = Math.min(t.slots.length, 2), r = Math.ceil(t.slots.length / 2), i = 10 + n * X + (n - 1) * Ve, a = 10 + r * X + (r - 1) * Ve;
	return {
		x: t.x - i / 2,
		y: t.y - a / 2,
		w: i,
		h: a
	};
}
var Z = {
	x0: -30,
	y0: -30,
	x1: 890,
	y1: 835
}, Q = (e) => Math.min(e.w / (Z.x1 - Z.x0), e.h / (Z.y1 - Z.y0)), Ge = (e, t) => {
	let n = t ? k(t) : {
		x: 430,
		y: 510
	};
	return {
		cx: n.x,
		cy: n.y,
		s: Math.max(.1, Q(e) * (t ? 2.2 : 2.5))
	};
}, Ke = (e) => new Map(Object.entries(e).map(([e, t]) => [e, {
	owner: t.owner,
	level: t.level,
	flipped: t.flipped
}]));
function qe({ pub: e, members: t, hot: a, pickedLinks: o, pickedTiles: s, focusNode: l, onTapSlot: u, onTapLink: d, onTapTile: h }) {
	let g = c(), _ = (n) => t.find((t) => t.rid === e.players[n]?.rid)?.name ?? `${n + 1}`, v = r(null), [y, b] = i({
		w: 0,
		h: 0
	}), [x, S] = i(null), C = r(Ge(y, l)), E = `${JSON.stringify(e.board)}|${JSON.stringify(e.links)}`, [D, te] = i(() => ({
		signature: E,
		tiles: Ke(e.board),
		links: new Set(Object.keys(e.links)),
		placed: /* @__PURE__ */ new Set(),
		flipped: /* @__PURE__ */ new Set(),
		newLinks: /* @__PURE__ */ new Set()
	}));
	if (D.signature !== E) {
		let t = Ke(e.board), n = new Set(Object.keys(e.links));
		te({
			signature: E,
			tiles: t,
			links: n,
			placed: new Set([...t].filter(([e, t]) => {
				let n = D.tiles.get(e);
				return !n || n.owner !== t.owner || n.level !== t.level;
			}).map(([e]) => e)),
			flipped: new Set([...t].filter(([e, t]) => !D.tiles.get(e)?.flipped && t.flipped).map(([e]) => e)),
			newLinks: new Set([...n].filter((e) => !D.links.has(e)))
		});
	}
	n(() => {
		let e = v.current, t = new ResizeObserver(() => b({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let A = x ?? Ge(y, l);
	n(() => {
		C.current = A;
	});
	let j = r({
		w: 0,
		h: 0
	});
	n(() => {
		let e = j.current;
		if (e.w > 0 && y.w > 0 && (e.w !== y.w || e.h !== y.h)) {
			let t = Q(y) / Q(e);
			S((e) => e ? {
				...e,
				s: e.s * t
			} : null);
		}
		j.current = y;
	}, [y]);
	let M = (e) => {
		let t = C.current;
		S({
			...t,
			s: Math.max(Q(y) * .85, Math.min(3, t.s * e))
		});
	}, N = () => S({
		cx: (Z.x0 + Z.x1) / 2,
		cy: (Z.y0 + Z.y1) / 2,
		s: Q(y)
	});
	n(() => {
		let e = v.current, t = (t) => {
			t.preventDefault();
			let n = e.getBoundingClientRect(), r = C.current, i = t.deltaY < 0 ? 1.15 : 1 / 1.15, a = Math.max(Q({
				w: n.width,
				h: n.height
			}) * .85, Math.min(3, r.s * i)), o = t.clientX - n.left - n.width / 2, s = t.clientY - n.top - n.height / 2, c = r.cx + o / r.s, l = r.cy + s / r.s, u = {
				s: a,
				cx: c - o / a,
				cy: l - s / a
			};
			C.current = u, S(u);
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, []);
	let P = r(/* @__PURE__ */ new Map()), F = r(0), I = r(0), ne = (e) => {
		if (e.currentTarget.setPointerCapture(e.pointerId), P.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), P.current.size === 1 && (F.current = 0), P.current.size === 2) {
			let [e, t] = [...P.current.values()];
			I.current = Math.hypot(e.x - t.x, e.y - t.y);
		}
	}, re = (e) => {
		let t = P.current.get(e.pointerId);
		if (!t) return;
		let n = v.current.getBoundingClientRect();
		if (P.current.size === 1) {
			let n = e.clientX - t.x, r = e.clientY - t.y;
			F.current += Math.abs(n) + Math.abs(r);
			let i = C.current, a = {
				...i,
				cx: i.cx - n / i.s,
				cy: i.cy - r / i.s
			};
			C.current = a, S(a);
		} else if (P.current.size === 2) {
			P.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			let [t, r] = [...P.current.values()], i = Math.hypot(t.x - r.x, t.y - r.y);
			if (I.current > 0 && i > 0) {
				let e = C.current, a = Math.max(Q({
					w: n.width,
					h: n.height
				}) * .85, Math.min(3, e.s * i / I.current)), o = (t.x + r.x) / 2 - n.left - n.width / 2, s = (t.y + r.y) / 2 - n.top - n.height / 2, c = e.cx + o / e.s, l = e.cy + s / e.s, u = {
					s: a,
					cx: c - o / a,
					cy: l - s / a
				};
				C.current = u, S(u);
			}
			I.current = i, F.current = 99;
			return;
		}
		P.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
	}, L = (e, t, n, r, i, a) => {
		let o = i - n, s = a - r, c = o * o + s * s, l = c === 0 ? 0 : Math.max(0, Math.min(1, ((e - n) * o + (t - r) * s) / c));
		return Math.hypot(e - (n + l * o), t - (r + l * s));
	};
	return /* @__PURE__ */ m("div", {
		ref: v,
		className: "brass-board",
		children: [
			/* @__PURE__ */ m("svg", {
				className: "brass-board__svg",
				onPointerDown: ne,
				onPointerMove: re,
				onPointerUp: (e) => {
					let t = P.current.size === 1 && F.current < 10;
					if (P.current.delete(e.pointerId), I.current = 0, !t || !a) return;
					let n = v.current.getBoundingClientRect(), r = C.current, i = r.cx + (e.clientX - n.left - n.width / 2) / r.s, o = r.cy + (e.clientY - n.top - n.height / 2) / r.s, s = (e) => e.startsWith("farm:") ? k(e.slice(5)) : Ue(e.split(":")[0], Number(e.split(":")[1]));
					if (a.tiles && h) {
						let e = null, t = Math.max(22, 22 / r.s);
						for (let n of a.tiles) {
							let r = s(n), a = Math.hypot(r.x - i, r.y - o);
							a < t && (t = a, e = n);
						}
						e && h(e);
						return;
					}
					if (a.slots && u) {
						let e = null, t = Math.max(22, 22 / r.s);
						for (let n of a.slots) {
							let r = s(n), a = Math.hypot(r.x - i, r.y - o);
							a < t && (t = a, e = n);
						}
						e && u(e);
						return;
					}
					if (a.links && d) {
						let e = null, t = Math.max(18, 22 / r.s);
						for (let n of a.links) {
							let r = O.find((e) => e.id === n);
							for (let a = 0; a + 1 < r.nodes.length; a++) {
								let s = k(r.nodes[a]), c = k(r.nodes[a + 1]), l = L(i, o, s.x, s.y, c.x, c.y);
								l < t && (t = l, e = n);
							}
						}
						e && d(e);
					}
				},
				onPointerCancel: (e) => {
					P.current.delete(e.pointerId), I.current = 0;
				},
				role: "img",
				"aria-label": g("games.brass.mapLabel"),
				children: [/* @__PURE__ */ p("defs", { children: /* @__PURE__ */ p("filter", {
					id: "brass-board-shadow",
					x: "-30%",
					y: "-30%",
					width: "160%",
					height: "170%",
					children: /* @__PURE__ */ p("feDropShadow", {
						dx: "2",
						dy: "3",
						stdDeviation: "1.2",
						floodColor: "#1b2624",
						floodOpacity: "0.45"
					})
				}) }), /* @__PURE__ */ m("g", {
					transform: `translate(${y.w / 2 - A.cx * A.s}, ${y.h / 2 - A.cy * A.s}) scale(${A.s})`,
					children: [
						/* @__PURE__ */ p("image", {
							href: "./games/brass/map.webp",
							x: Z.x0,
							y: Z.y0,
							width: Z.x1 - Z.x0,
							height: Z.y1 - Z.y0,
							preserveAspectRatio: "none"
						}),
						/* @__PURE__ */ p("rect", {
							x: Z.x0,
							y: Z.y0,
							width: Z.x1 - Z.x0,
							height: Z.y1 - Z.y0,
							fill: "var(--color-brass-cream)",
							opacity: .06
						}),
						O.map((t) => {
							let n = e.links[t.id], r = t.nodes.map((e) => k(e)), i = r.map((e, t) => `${t === 0 ? "M" : "L"}${e.x},${e.y}`).join(" "), s = o?.has(t.id) ?? !1, c = a?.links?.has(t.id) ?? !1, l = e.era === "canal" ? t.canal : t.rail, u = (e.era === "canal" || !t.rail) && t.canal, d = {
								x: (r[0].x + r[r.length - 1].x) / 2,
								y: (r[0].y + r[r.length - 1].y) / 2
							};
							return /* @__PURE__ */ m("g", {
								className: D.newLinks.has(t.id) ? "brass-board__new-link" : void 0,
								opacity: l || n !== void 0 ? 1 : .32,
								children: [
									/* @__PURE__ */ p("title", { children: `${t.nodes.map((e) => g(J[e])).join(" – ")}${n === void 0 ? "" : ` · ${_(n)}`}` }),
									/* @__PURE__ */ p("path", {
										d: i,
										fill: "none",
										stroke: "var(--color-brass-slate-deep)",
										strokeWidth: n === void 0 ? 7 : 9,
										strokeLinecap: "round",
										strokeLinejoin: "round",
										opacity: .83
									}),
									/* @__PURE__ */ p("path", {
										d: i,
										fill: "none",
										stroke: s ? "var(--color-brass-gold)" : u ? "var(--color-brass-canal)" : "var(--color-brass-copper)",
										strokeWidth: n === void 0 ? c ? 6.5 : 4 : 5.8,
										strokeLinecap: "round",
										strokeLinejoin: "round"
									}),
									!u && /* @__PURE__ */ p("path", {
										d: i,
										fill: "none",
										stroke: "var(--color-brass-slate-deep)",
										strokeWidth: 1.5,
										strokeDasharray: "3 5"
									}),
									c && /* @__PURE__ */ m(f, { children: [
										/* @__PURE__ */ p("path", {
											d: i,
											fill: "none",
											stroke: "var(--color-brass-cream)",
											strokeWidth: 1.5
										}),
										/* @__PURE__ */ p("circle", {
											cx: d.x,
											cy: d.y,
											r: 11,
											fill: "var(--color-brass-gold)",
											stroke: "var(--color-brass-cream)",
											strokeWidth: 2
										}),
										/* @__PURE__ */ p("text", {
											x: d.x,
											y: d.y + 4,
											textAnchor: "middle",
											fontSize: 13,
											fontWeight: 900,
											fill: "var(--color-brass-slate-deep)",
											children: "+"
										})
									] }),
									s && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("circle", {
										cx: d.x,
										cy: d.y,
										r: 11,
										fill: "var(--color-brass-gold)",
										stroke: "var(--color-brass-cream)",
										strokeWidth: 2
									}), /* @__PURE__ */ p("text", {
										x: d.x,
										y: d.y + 4,
										textAnchor: "middle",
										fontSize: 12,
										fontWeight: 900,
										fill: "var(--color-brass-slate-deep)",
										children: "✓"
									})] }),
									n !== void 0 && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("circle", {
										cx: d.x,
										cy: d.y,
										r: 10,
										fill: "var(--color-brass-slate-deep)",
										stroke: "var(--color-brass-gold)",
										strokeWidth: 2
									}), /* @__PURE__ */ p("text", {
										x: d.x,
										y: d.y + 3.5,
										textAnchor: "middle",
										fontSize: 10,
										fontWeight: 900,
										fill: "var(--color-brass-cream)",
										children: n + 1
									})] })
								]
							}, t.id);
						}),
						w.map((t) => {
							let n = We(t.id), r = g(J[t.id]), i = Math.max(n.w + 4, Math.min(160, r.length * (/[\u4e00-\u9fff]/.test(r) ? 11 : 7) + 12)), o = t.slots.some((e, n) => a?.slots?.has(`${t.id}:${n}`));
							return /* @__PURE__ */ m("g", { children: [
								/* @__PURE__ */ p("title", { children: r }),
								o && /* @__PURE__ */ p("rect", {
									x: n.x - 7,
									y: n.y - 7,
									width: n.w + 14,
									height: n.h + 14,
									rx: 12,
									fill: "var(--color-brass-gold)",
									opacity: .36
								}),
								/* @__PURE__ */ p("rect", {
									x: n.x,
									y: n.y + 3,
									width: n.w,
									height: n.h,
									rx: 7,
									fill: "var(--color-brass-slate-deep)",
									filter: "url(#brass-board-shadow)"
								}),
								/* @__PURE__ */ p("rect", {
									x: n.x,
									y: n.y,
									width: n.w,
									height: n.h,
									rx: 7,
									fill: "var(--color-brass-slate)",
									stroke: "var(--color-brass-gold)",
									strokeWidth: 2
								}),
								t.slots.map((n, r) => {
									let i = Ue(t.id, r), o = `${t.id}:${r}`, c = e.board[o], l = D.placed.has(o) ? "placed" : D.flipped.has(o) ? "flipped" : void 0, u = a?.slots?.has(o) ?? !1, d = s?.has(o) ?? !1;
									return /* @__PURE__ */ m("g", { children: [
										u && /* @__PURE__ */ p("rect", {
											x: i.x - X / 2 - 3,
											y: i.y - X / 2 - 3,
											width: 36,
											height: 36,
											rx: 5,
											fill: "var(--color-brass-gold)",
											stroke: "var(--color-brass-cream)",
											strokeWidth: 2
										}),
										d && /* @__PURE__ */ p("rect", {
											x: i.x - X / 2 - 4,
											y: i.y - X / 2 - 4,
											width: 38,
											height: 38,
											rx: 6,
											fill: "none",
											stroke: "var(--color-brass-gold)",
											strokeWidth: 3
										}),
										c ? /* @__PURE__ */ p(Je, {
											x: i.x,
											y: i.y,
											industry: c.industry,
											level: c.level,
											flipped: c.flipped,
											cubes: c.cubes,
											owner: c.owner,
											ownerName: _(c.owner),
											dim: a?.tiles != null && !a.tiles.has(o),
											motion: l
										}) : /* @__PURE__ */ m("g", { children: [
											/* @__PURE__ */ p("rect", {
												x: i.x - X / 2,
												y: i.y - X / 2,
												width: X,
												height: X,
												rx: 3,
												fill: "var(--color-brass-slot)",
												stroke: "var(--color-brass-gold)",
												strokeWidth: .8
											}),
											n.map((e, t) => /* @__PURE__ */ p(ze, {
												industry: e,
												x: i.x + (t - (n.length - 1) / 2) * 11,
												y: i.y,
												size: n.length === 1 ? 19 : 13
											}, e)),
											u && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("circle", {
												cx: i.x + X / 2 - 1,
												cy: i.y - X / 2 + 1,
												r: 5.7,
												fill: "var(--color-brass-gold)",
												stroke: "var(--color-brass-cream)",
												strokeWidth: 1
											}), /* @__PURE__ */ p("text", {
												x: i.x + X / 2 - 1,
												y: i.y - X / 2 + 3.5,
												textAnchor: "middle",
												fontSize: 8,
												fontWeight: 900,
												fill: "var(--color-brass-slate-deep)",
												children: "+"
											})] })
										] })
									] }, o);
								}),
								/* @__PURE__ */ p("rect", {
									x: t.x - i / 2,
									y: n.y + n.h + 2,
									width: i,
									height: 18,
									rx: 3,
									fill: "var(--color-brass-cream)",
									stroke: "var(--color-brass-copper)",
									strokeWidth: 1.3
								}),
								/* @__PURE__ */ p("text", {
									x: t.x,
									y: n.y + n.h + 15,
									textAnchor: "middle",
									fontSize: 11,
									fontWeight: 900,
									fill: "var(--color-brass-slate-deep)",
									textLength: r.length > 12 ? i - 7 : void 0,
									lengthAdjust: "spacingAndGlyphs",
									children: r
								})
							] }, t.id);
						}),
						ee.map((t) => {
							let n = `farm:${t.id}`, r = e.board[n], i = D.placed.has(n) ? "placed" : D.flipped.has(n) ? "flipped" : void 0, o = a?.slots?.has(n) ?? !1, c = s?.has(n) ?? !1;
							return /* @__PURE__ */ m("g", { children: [
								o && /* @__PURE__ */ p("circle", {
									cx: t.x,
									cy: t.y,
									r: 22,
									fill: "var(--color-brass-gold)",
									stroke: "var(--color-brass-cream)",
									strokeWidth: 2
								}),
								c && /* @__PURE__ */ p("circle", {
									cx: t.x,
									cy: t.y,
									r: 23,
									fill: "none",
									stroke: "var(--color-brass-gold)",
									strokeWidth: 3
								}),
								r ? /* @__PURE__ */ p(Je, {
									x: t.x,
									y: t.y,
									industry: "brewery",
									level: r.level,
									flipped: r.flipped,
									cubes: r.cubes,
									owner: r.owner,
									ownerName: _(r.owner),
									motion: i
								}) : /* @__PURE__ */ m("g", { children: [/* @__PURE__ */ p("circle", {
									cx: t.x,
									cy: t.y,
									r: 17,
									fill: "var(--color-brass-slate)",
									stroke: "var(--color-brass-gold)",
									strokeWidth: 2
								}), /* @__PURE__ */ p(ze, {
									industry: "brewery",
									x: t.x,
									y: t.y,
									size: 20
								})] }),
								/* @__PURE__ */ p("rect", {
									x: t.x - 29,
									y: t.y + 19,
									width: 58,
									height: 16,
									rx: 3,
									fill: "var(--color-brass-cream)",
									stroke: "var(--color-brass-copper)",
									strokeWidth: 1
								}),
								/* @__PURE__ */ p("text", {
									x: t.x,
									y: t.y + 31,
									textAnchor: "middle",
									fontSize: 10,
									fontWeight: 800,
									fill: "var(--color-brass-slate-deep)",
									children: g(J[t.id])
								})
							] }, t.id);
						}),
						e.merchants.map((e, t) => {
							let n = T.find((t) => t.id === e.location), r = k(e.location);
							return /* @__PURE__ */ m("g", {
								opacity: e.buys === "blank" ? .65 : 1,
								children: [
									/* @__PURE__ */ p("path", {
										d: `M${r.x - 17} ${r.y - 17}h34v25l-17 9-17-9Z`,
										fill: "var(--color-brass-slate-deep)",
										stroke: "var(--color-brass-gold)",
										strokeWidth: 2
									}),
									e.buys === "blank" ? /* @__PURE__ */ p("text", {
										x: r.x,
										y: r.y + 5,
										textAnchor: "middle",
										fontSize: 19,
										fontWeight: 900,
										fill: "var(--color-brass-cream)",
										children: "×"
									}) : e.buys === "any" ? /* @__PURE__ */ p("text", {
										x: r.x,
										y: r.y + 5,
										textAnchor: "middle",
										fontSize: 19,
										fill: "var(--color-brass-gold)",
										children: "★"
									}) : /* @__PURE__ */ p(ze, {
										industry: e.buys,
										x: r.x,
										y: r.y,
										size: 21
									}),
									e.beer && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("circle", {
										cx: r.x + 17,
										cy: r.y - 16,
										r: 9,
										fill: "var(--color-brass-cream)",
										stroke: "var(--color-brass-copper)",
										strokeWidth: 1.5
									}), /* @__PURE__ */ p(ze, {
										industry: "brewery",
										x: r.x + 17,
										y: r.y - 16,
										size: 13
									})] }),
									/* @__PURE__ */ p("rect", {
										x: r.x - 32,
										y: r.y + 20,
										width: 64,
										height: 16,
										rx: 3,
										fill: "var(--color-brass-cream)",
										stroke: "var(--color-brass-copper)",
										strokeWidth: 1
									}),
									/* @__PURE__ */ p("text", {
										x: r.x,
										y: r.y + 32,
										textAnchor: "middle",
										fontSize: 10,
										fontWeight: 800,
										fill: "var(--color-brass-slate-deep)",
										children: g(J[n.id])
									})
								]
							}, `${e.location}-${t}`);
						})
					]
				})]
			}),
			/* @__PURE__ */ p("div", {
				className: "brass-board__era",
				"aria-hidden": "true",
				children: g(e.era === "canal" ? "games.brass.eraCanal" : "games.brass.eraRail")
			}),
			/* @__PURE__ */ m("div", {
				className: "brass-board__toolbar",
				children: [
					/* @__PURE__ */ p("button", {
						type: "button",
						onClick: () => M(1.25),
						"aria-label": g("games.brass.zoomIn"),
						children: "＋"
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						onClick: () => M(.8),
						"aria-label": g("games.brass.zoomOut"),
						children: "－"
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						onClick: N,
						"aria-label": g("games.brass.showFullMap"),
						children: g("games.brass.showFullMap")
					})
				]
			})
		]
	});
}
function Je({ x: e, y: t, industry: n, level: r, flipped: i, cubes: a, owner: o, ownerName: s, dim: c, motion: l }) {
	return /* @__PURE__ */ m("g", {
		opacity: c ? .4 : 1,
		className: `brass-board__tile ${l ? `brass-board__tile--${l}` : ""}`,
		children: [
			/* @__PURE__ */ p("title", { children: `${s} · ${r}` }),
			/* @__PURE__ */ p("rect", {
				x: e - X / 2,
				y: t - X / 2 + 2,
				width: X,
				height: X,
				rx: 3,
				fill: "var(--color-brass-slate-deep)"
			}),
			/* @__PURE__ */ p("rect", {
				x: e - X / 2,
				y: t - X / 2,
				width: X,
				height: X,
				rx: 3,
				fill: i ? "var(--color-brass-copper)" : "var(--color-brass-slate)",
				stroke: "var(--color-brass-gold)",
				strokeWidth: 1.6
			}),
			/* @__PURE__ */ p(ze, {
				industry: n,
				x: e,
				y: t - 1,
				size: 19
			}),
			/* @__PURE__ */ p("rect", {
				x: e - X / 2 + 1.5,
				y: t - X / 2 + 1.5,
				width: 10,
				height: 9,
				rx: 2,
				fill: "var(--color-brass-cream)"
			}),
			/* @__PURE__ */ p("text", {
				x: e - X / 2 + 6.5,
				y: t - X / 2 + 8.5,
				textAnchor: "middle",
				fontSize: 7.5,
				fontWeight: 900,
				fill: "var(--color-brass-slate-deep)",
				children: r
			}),
			/* @__PURE__ */ p("circle", {
				cx: e + X / 2 - 5.5,
				cy: t + X / 2 - 5.5,
				r: 4.5,
				fill: "var(--color-brass-gold)"
			}),
			/* @__PURE__ */ p("text", {
				x: e + X / 2 - 5.5,
				y: t + X / 2 - 3.2,
				textAnchor: "middle",
				fontSize: 7,
				fontWeight: 900,
				fill: "var(--color-brass-slate-deep)",
				children: o + 1
			}),
			a > 0 && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("circle", {
				cx: e + X / 2 - 3,
				cy: t - X / 2 + 3,
				r: 5.5,
				fill: "var(--color-brass-cream)",
				stroke: "var(--color-brass-copper)",
				strokeWidth: 1
			}), /* @__PURE__ */ p("text", {
				x: e + X / 2 - 3,
				y: t - X / 2 + 5.8,
				textAnchor: "middle",
				fontSize: 8,
				fontWeight: 900,
				fill: "var(--color-brass-slate-deep)",
				children: a
			})] }),
			i && /* @__PURE__ */ p("text", {
				x: e - X / 2 + 4,
				y: t + X / 2 - 3,
				fontSize: 8,
				fill: "var(--color-brass-cream)",
				children: "★"
			})
		]
	});
}
//#endregion
//#region src/games/brass/bot.ts
var Ye = {
	moneyW: .1,
	incBase: 1,
	incPerRound: .5,
	resFlipE: .7,
	sellReadyE: .7,
	sellFarE: .2,
	breweryE: .6,
	canalL1W: 0,
	overbuildLossW: 1.5,
	denyW: .5,
	buildW: 1.4,
	sellW: 1.3,
	merchantBeerW: 1,
	gloucesterW: 0,
	developW: 2,
	scoutBase: 4,
	scoutCardW: 1,
	networkW: 1,
	networkMerchantW: 1,
	merchantBaseW: 2,
	breweryBarrelW: 2,
	linkIconW: 1,
	loanW: 1,
	passW: -2,
	cardW: 0,
	railRatio: .7
};
function Xe(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function $(e) {
	if (e.startsWith("farm:")) return { farm: e.slice(5) };
	let [t, n] = e.split(":");
	return {
		city: t,
		slot: Number(n)
	};
}
function Ze(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of O) if (e.links[n.id] !== void 0) for (let e of n.nodes) for (let r of n.nodes) e !== r && (t.has(e) || t.set(e, []), t.get(e).push(r));
	return t;
}
function Qe(e, t) {
	let n = /* @__PURE__ */ new Map([[t, 0]]), r = [t];
	for (; r.length > 0;) {
		let t = r.shift();
		for (let i of e.get(t) ?? []) n.has(i) || (n.set(i, n.get(t) + 1), r.push(i));
	}
	return n;
}
function $e(e, t) {
	return new Set(Qe(e, t).keys());
}
function et(e, t) {
	let n = /* @__PURE__ */ new Set();
	for (let [r, i] of Object.entries(e.board)) i.owner === t && n.add(r.startsWith("farm:") ? r.slice(5) : r.split(":")[0]);
	for (let [r, i] of Object.entries(e.links)) if (i === t) for (let e of O.find((e) => e.id === r).nodes) n.add(e);
	return n;
}
var tt = (e, t) => Object.values(e.board).some((e) => e.owner === t) || Object.values(e.links).some((e) => e === t), nt = (e, t, n) => t === 0 ? n : e[e.length - t], rt = [
	"cotton",
	"manufacturer",
	"pottery",
	"brewery",
	"coal",
	"iron"
];
function it(e, t) {
	let n = 0;
	for (let t of Object.values(e.board)) t.industry === "iron" && !t.flipped && (n += t.cubes);
	let r = e.ironMarket, i = 0;
	for (let e = 0; e < t; e++) {
		if (n > 0) {
			n--;
			continue;
		}
		i += nt(j, r, 6), r > 0 && r--;
	}
	return i;
}
function at(e, t, n) {
	if (n.length === 0) return 0;
	let r = Ze(e), i = n.map((e) => e.map((e) => Qe(r, e))), a = [];
	for (let [n, r] of Object.entries(e.board)) {
		if (r.industry !== "coal" || r.flipped || r.cubes === 0) continue;
		let e = n.split(":")[0], o = i.map((t) => Math.min(...t.map((t) => t.get(e) ?? Infinity)));
		a.push({
			cubes: r.cubes,
			own: r.owner === t,
			d: o
		});
	}
	let o = (e) => T.some((t) => i[e].some((e) => e.has(t.id))), s = e.coalMarket, c = 0;
	for (let e = 0; e < n.length; e++) {
		a.sort((t, n) => t.d[e] - n.d[e] || (t.own === n.own ? 0 : t.own ? -1 : 1));
		let t = a.find((t) => t.cubes > 0 && t.d[e] < Infinity);
		if (t) {
			t.cubes--;
			continue;
		}
		if (!o(e)) return null;
		c += nt(A, s, 8), s > 0 && s--;
	}
	return c;
}
function ot(e, t, n, r) {
	return at(e, t, Array.from({ length: n }, () => r));
}
function st(e, t, n) {
	let r = e.public, i = Ze(r), a = r.players.length, o = (r.deckCount + r.players.reduce((e, t) => e + t.handCount, 0)) / (2 * a), s = r.era === "canal" ? o * (1 + n.railRatio) : o, c = n.moneyW * (n.incBase + n.incPerRound * s), l = /* @__PURE__ */ new Map(), u = (e) => {
		let t = l.get(e);
		return t || (t = new Set(Qe(i, e).keys()), l.set(e, t)), t;
	};
	return {
		pub: r,
		me: t,
		P: n,
		adj: i,
		net: et(r, t),
		homeless: !tt(r, t),
		hand: e.private?.hand ?? [],
		money: r.players[t].money,
		incomeVal: c,
		buyerReach: (e, t) => r.merchants.some((n) => (n.buys === "any" || n.buys === t) && u(e).has(n.location)),
		merchantReach: (e) => T.some((t) => u(e).has(t.id))
	};
}
function ct(e, t, n, r) {
	let { pub: i, P: a } = e;
	return t === "coal" ? e.merchantReach(n) && A.length - i.coalMarket >= r.produce ? 1 : a.resFlipE : t === "iron" ? j.length - i.ironMarket >= r.produce ? 1 : a.resFlipE : t === "brewery" ? a.breweryE : e.buyerReach(n, t) ? a.sellReadyE : a.sellFarE;
}
function lt(e, t, n) {
	let r = S(t, n);
	return r.vp + r.income * e;
}
function ut(e, t) {
	let { pub: n } = e;
	if (t.kind === "wildLocation" || t.kind === "wildIndustry") return 4;
	if (t.kind === "location") {
		let e = w.find((e) => e.id === t.city);
		return e.slots.some((t, r) => !n.board[`${e.id}:${r}`]) ? 2 : 0;
	}
	return w.some((r) => (e.homeless || e.net.has(r.id)) && r.slots.some((e, i) => !n.board[`${r.id}:${i}`] && e.some((e) => t.industries.includes(e)))) || ee.some((n) => e.net.has(n.id) && t.industries.includes("brewery")) ? 3 : 1;
}
function dt(e) {
	let t = 0, n = Infinity;
	return e.hand.forEach((r, i) => {
		let a = ut(e, r);
		a < n && (n = a, t = i);
	}), t;
}
function ft(e) {
	let { pub: t, me: n, P: r, hand: i, money: a } = e, o = [], s = (s, c, l, u) => {
		let d = t.players[n].stacks[l], f = d?.[d.length - 1];
		if (f === void 0) return;
		let p = S(l, f);
		if ((t.era === "canal" ? !p.canal : !p.rail) || u && (u.level >= f || u.owner !== n && (l !== "coal" && l !== "iron" || Object.values(t.board).some((e) => e.industry === l && !e.flipped && e.cubes > 0) || (l === "coal" ? t.coalMarket : t.ironMarket) > 0))) return;
		let m = "city" in c ? c.city : c.farm, h = it(t, p.iron), g = ot(t, n, p.coal, [m]);
		if (g === null) return;
		let _ = p.cost + h + g;
		if (a < _) return;
		let v = ct(e, l, m, p), y = r.buildW * v * lt(e.incomeVal, l, f) - _ * r.moneyW - r.cardW * ut(e, i[s]);
		if (t.era === "canal" && f === 1 && (y -= r.canalL1W * (1 - v)), l === "brewery") {
			let e = t.era === "canal" ? 1 : 2, i = Object.values(t.board).filter((e) => e.owner === n && !e.flipped && P.includes(e.industry)).length;
			y += r.breweryBarrelW * e * (i > 0 ? 1 : .3);
		}
		if (u) {
			let t = lt(e.incomeVal, l, u.level);
			u.owner === n ? y -= r.overbuildLossW * t : y += r.denyW * t;
		}
		o.push({
			action: {
				type: "build",
				card: s,
				at: c,
				industry: l
			},
			score: y
		});
	};
	return i.forEach((r, i) => {
		let a, o = null, c = !1;
		r.kind === "location" ? a = w.filter((e) => e.id === r.city) : r.kind === "wildLocation" ? a = w : (o = r.kind === "industry" ? r.industries : rt, a = e.homeless ? w : w.filter((t) => e.net.has(t.id)), c = o.includes("brewery") && (e.homeless || ee.some((t) => e.net.has(t.id))));
		for (let e of a) {
			let r = Object.keys(t.board).filter((r) => r.startsWith(`${e.id}:`) && t.board[r].owner === n).length;
			e.slots.forEach((n, a) => {
				let c = `${e.id}:${a}`, l = t.board[c];
				if (l) {
					if (o && !o.includes(l.industry)) return;
					s(i, {
						city: e.id,
						slot: a
					}, l.industry, {
						owner: l.owner,
						level: l.level
					});
					return;
				}
				if (!(t.era === "canal" && r > 0)) for (let r of o ?? n) n.includes(r) && (n.length > 1 && e.slots.some((n, i) => n.length === 1 && n[0] === r && !t.board[`${e.id}:${i}`]) || s(i, {
					city: e.id,
					slot: a
				}, r, null));
			});
		}
		if (c) for (let n of ee) t.board[`farm:${n.id}`] || (e.homeless || e.net.has(n.id)) && s(i, { farm: n.id }, "brewery", null);
	}), o;
}
function pt(e) {
	let { pub: t, me: n, P: r } = e, i = dt(e);
	if (e.hand[i] === void 0) return null;
	let a = [], o = 0, s = 0, c = /* @__PURE__ */ new Set(), l = /* @__PURE__ */ new Set(), u = e.adj;
	for (let [i, d] of Object.entries(t.board)) {
		if (d.owner !== n || d.flipped || !P.includes(d.industry)) continue;
		let f = i.startsWith("farm:") ? i.slice(5) : i.split(":")[0], p = new Set(Qe(u, f).keys()), m = S(d.industry, d.level);
		if (!t.merchants.some((e) => (e.buys === "any" || e.buys === d.industry) && p.has(e.location))) continue;
		let h = [], g = -1, _ = !1, v = 0, y = t.merchants.findIndex((e, t) => e.beer && !c.has(t) && (e.buys === "any" || e.buys === d.industry) && p.has(e.location));
		if (y >= 0 && h.length < m.beer) {
			g = y, h.push({
				kind: "merchant",
				index: y
			});
			let n = T.find((e) => e.id === t.merchants[y].location).bonus;
			n.kind === "vp" ? v = r.merchantBeerW * n.amount : n.kind === "money" ? v = r.merchantBeerW * n.amount * r.moneyW : n.kind === "income" ? v = r.merchantBeerW * n.amount * e.incomeVal : _ = !0;
		}
		let b = [];
		for (let [e, r] of Object.entries(t.board)) {
			if (h.length >= m.beer) break;
			if (r.industry !== "brewery" || r.flipped || r.cubes === 0 || l.has(e) || b.includes(e)) continue;
			let t = e.startsWith("farm:") ? e.slice(5) : e.split(":")[0];
			(r.owner === n || p.has(t)) && (h.push({
				kind: "tile",
				at: $(e)
			}), b.push(e));
		}
		if (!(h.length < m.beer)) {
			g >= 0 && (c.add(g), o += v, _ && (s++, o += r.gloucesterW));
			for (let e of b) l.add(e);
			a.push({
				tile: $(i),
				beers: h
			}), o += m.vp + m.income * e.incomeVal;
		}
	}
	if (a.length === 0) return null;
	let d = /* @__PURE__ */ new Map();
	for (let [e, r] of Object.entries(t.players[n].stacks)) d.set(e, [...r]);
	let f = [];
	for (let e = 0; e < s; e++) {
		let e = [...d.entries()].filter(([e, t]) => t.length > 0 && !S(e, t[t.length - 1]).noDevelop).sort((e, t) => t[1].length - e[1].length)[0];
		e && (f.push(e[0]), e[1].pop());
	}
	return f.length < s ? null : {
		action: {
			type: "sell",
			card: i,
			sales: a,
			bonusDevelop: f.length > 0 ? f : void 0
		},
		score: r.sellW * o - r.cardW * ut(e, e.hand[i])
	};
}
function mt(e) {
	let { pub: t, me: n, P: r } = e, i = dt(e);
	if (e.hand[i] === void 0) return [];
	let a = (n, i) => {
		if (i === void 0) return 0;
		let a = S(n, i);
		return (t.era === "canal" ? !a.canal : !a.rail) ? 0 : (n === "coal" || n === "iron" ? r.resFlipE : n === "brewery" ? r.breweryE : t.merchants.some((e) => e.buys === "any" || e.buys === n) ? r.sellReadyE : r.sellFarE) * lt(e.incomeVal, n, i);
	}, o = [];
	for (let e of rt) {
		let r = t.players[n].stacks[e];
		if (!r || r.length === 0) continue;
		let i = r[r.length - 1];
		S(e, i).noDevelop || o.push({
			ind: e,
			gain: a(e, r[r.length - 2]) - a(e, i)
		});
	}
	if (o.length === 0) return [];
	let s = [], c = r.cardW * ut(e, e.hand[i]), l = (n, a) => {
		let o = it(t, n.length);
		if (e.money < o) return;
		let l = r.developW * a - o * r.moneyW - c;
		s.push({
			action: {
				type: "develop",
				card: i,
				industries: n
			},
			score: l
		});
	};
	for (let e of o) l([e.ind], e.gain);
	for (let e = 0; e < o.length; e++) for (let r = e; r < o.length; r++) {
		if (e === r) {
			let r = t.players[n].stacks[o[e].ind];
			if (r.length < 2 || S(o[e].ind, r[r.length - 2]).noDevelop) continue;
			let i = a(o[e].ind, r[r.length - 3]) - a(o[e].ind, r[r.length - 2]);
			l([o[e].ind, o[e].ind], o[e].gain + i);
			continue;
		}
		l([o[e].ind, o[r].ind], o[e].gain + o[r].gain);
	}
	return s;
}
function ht(e) {
	let { pub: t, P: n, hand: r } = e;
	if (r.length < 3 || r.some((e) => e.kind === "wildLocation" || e.kind === "wildIndustry") || t.wilds.location === 0 || t.wilds.industry === 0) return null;
	let i = r.map((t, n) => ({
		i: n,
		v: ut(e, t)
	})).sort((e, t) => e.v - t.v).slice(0, 3), a = n.scoutBase - n.scoutCardW * i.reduce((e, t) => e + t.v, 0);
	return {
		action: {
			type: "scout",
			cards: [
				i[0].i,
				i[1].i,
				i[2].i
			]
		},
		score: a
	};
}
function gt(e) {
	let { pub: t, me: n, P: r, money: i } = e, a = dt(e);
	if (e.hand[a] === void 0) return [];
	let o = r.cardW * ut(e, e.hand[a]), s = (i, a) => {
		if (a.has(i)) return 0;
		let o = 0, s = t.merchants.find((e) => e.location === i);
		if (s) {
			for (let [i, a] of Object.entries(t.board)) {
				if (a.owner !== n || a.flipped || !P.includes(a.industry) || s.buys !== "any" && s.buys !== a.industry) continue;
				let t = i.startsWith("farm:") ? i.slice(5) : i.split(":")[0];
				e.buyerReach(t, a.industry) || (o += r.networkMerchantW * lt(e.incomeVal, a.industry, a.level) * (r.sellReadyE - r.sellFarE));
			}
			for (let i of e.hand) {
				let a = i.kind === "industry" ? i.industries : i.kind === "wildIndustry" ? rt : null;
				if (!a) continue;
				let c = 0;
				for (let r of a) {
					if (!P.includes(r) || s.buys !== "any" && s.buys !== r) continue;
					let i = t.players[n].stacks[r], a = i?.[i.length - 1];
					a !== void 0 && (c = Math.max(c, lt(e.incomeVal, r, a)));
				}
				o += r.merchantBaseW * c * (r.sellReadyE - r.sellFarE);
			}
		}
		let c = w.find((e) => e.id === i);
		if (c) {
			let a = 0;
			e.hand.forEach((o) => {
				let s = null;
				if (o.kind === "industry") s = o.industries;
				else if (o.kind === "wildIndustry") s = rt;
				else if (o.kind === "location" && o.city !== c.id) return;
				c.slots.forEach((o, l) => {
					if (!t.board[`${c.id}:${l}`]) for (let c of s ?? o) {
						if (!o.includes(c)) continue;
						let s = t.players[n].stacks[c], l = s?.[s.length - 1];
						if (l === void 0) continue;
						let u = S(c, l);
						if (t.era === "canal" ? !u.canal : !u.rail) continue;
						let d = c === "coal" || c === "iron" ? r.resFlipE : c === "brewery" ? r.breweryE : e.buyerReach(i, c) ? r.sellReadyE : r.sellFarE;
						a = Math.max(a, d * lt(e.incomeVal, c, l));
					}
				});
			}), o += a;
		}
		return o;
	}, c = (e) => {
		let n = (e) => {
			if (T.some((t) => t.id === e)) return 2;
			let n = 0;
			for (let [r, i] of Object.entries(t.board)) i.flipped && (r.startsWith("farm:") ? r.slice(5) : r.split(":")[0]) === e && (n += S(i.industry, i.level).links);
			return n;
		};
		return n(e.nodes[0]) + n(e.nodes[e.nodes.length - 1]);
	}, l = (e) => (t.era === "canal" ? e.canal : e.rail) && t.links[e.id] === void 0, u = [];
	if (t.players[n].linkStock < 1) return u;
	let d = t.era === "canal" ? 3 : 5, f = [];
	for (let p of O) {
		if (!l(p) || !e.homeless && !p.nodes.some((t) => e.net.has(t))) continue;
		let m = 0;
		if (t.era === "rail") {
			let e = ot(t, n, 1, [...p.nodes]);
			if (e === null) continue;
			m = e;
		}
		if (i < d + m) continue;
		let h = p.nodes.reduce((t, n) => t + s(n, e.net), 0), g = r.networkW * h + r.linkIconW * c(p) - (d + m) * r.moneyW - o;
		f.push({
			link: p,
			score: g,
			coal: m
		}), u.push({
			action: {
				type: "network",
				card: a,
				links: [p.id]
			},
			score: g
		});
	}
	if (t.era === "rail" && t.players[n].linkStock >= 2 && i >= 15) {
		let l = (() => {
			let e = null, r = null;
			for (let [i, a] of Object.entries(t.board)) a.industry !== "brewery" || a.flipped || a.cubes === 0 || (a.owner === n ? e = $(i) : r ??= $(i));
			return e ?? r;
		})();
		if (l) {
			let d = "city" in l ? l.city : l.farm, p = t.board["city" in l ? `${l.city}:${l.slot}` : `farm:${l.farm}`].owner === n, m = [...f].sort((e, t) => t.score - e.score).slice(0, 6);
			for (let f = 0; f < m.length; f++) for (let h = 0; h < m.length; h++) {
				if (f === h) continue;
				let g = new Set(e.net);
				for (let e of m[f].link.nodes) g.add(e);
				if (!m[h].link.nodes.some((e) => g.has(e))) continue;
				if (!p) {
					let t = /* @__PURE__ */ new Map();
					for (let [n, r] of e.adj) t.set(n, [...r]);
					for (let e of [m[f].link, m[h].link]) for (let n of e.nodes) for (let r of e.nodes) n !== r && (t.has(n) || t.set(n, []), t.get(n).push(r));
					let n = Qe(t, d);
					if (!m[h].link.nodes.some((e) => n.has(e))) continue;
				}
				let _ = at(t, n, [[...m[f].link.nodes], [...m[f].link.nodes, ...m[h].link.nodes]]);
				if (_ === null || i < 15 + _) continue;
				let v = m[f].link.nodes.reduce((t, n) => t + s(n, e.net), 0) + m[h].link.nodes.reduce((e, t) => e + s(t, g), 0), y = r.networkW * v + r.linkIconW * (c(m[f].link) + c(m[h].link)) - (15 + _) * r.moneyW - o;
				u.push({
					action: {
						type: "network",
						card: a,
						links: [m[f].link.id, m[h].link.id],
						beerFrom: l
					},
					score: y
				});
			}
		}
	}
	return u;
}
function _t(e) {
	let { pub: t, me: n, P: r } = e;
	if (t.players[n].incomeLevel - 3 < -10) return null;
	let i = dt(e);
	if (e.hand[i] === void 0) return null;
	let a = r.loanW * (30 * r.moneyW - 3 * e.incomeVal) - r.cardW * ut(e, e.hand[i]);
	return {
		action: {
			type: "loan",
			card: i
		},
		score: a
	};
}
function vt(e) {
	let t = dt(e);
	return {
		action: {
			type: "pass",
			card: t
		},
		score: e.P.passW - e.P.cardW * ut(e, e.hand[t])
	};
}
var yt = ((e = {}) => {
	let t = {
		...Ye,
		...e
	};
	return (e, n) => {
		let r = e.public;
		if (r.phase !== "play") return null;
		let i = r.players.findIndex((e) => e.rid === n.rid);
		if (i < 0) return null;
		let a = r.pendingDebt.find((e) => e.rid === n.rid);
		if (a) {
			let e = [], t = 0, n = Object.entries(r.board).filter(([, e]) => e.owner === i).sort((e, t) => S(e[1].industry, e[1].level).cost - S(t[1].industry, t[1].level).cost);
			for (let [i] of n) {
				if (t >= a.need) break;
				e.push($(i)), t += Math.floor(S(r.board[i].industry, r.board[i].level).cost / 2);
			}
			return e.length > 0 ? { action: {
				type: "payDebt",
				tiles: e
			} } : null;
		}
		if (r.order[r.turnIdx] !== i || r.actionsLeft === 0 || (e.private?.hand ?? []).length === 0) return null;
		let o = st(e, i, t), s = pt(o), c = ht(o), l = _t(o), u = [
			...ft(o),
			...mt(o),
			...gt(o),
			...s ? [s] : [],
			...c ? [c] : [],
			...l ? [l] : [],
			vt(o)
		];
		return n.difficulty === "weak" ? { action: Xe(u).action } : (u.sort((e, t) => t.score - e.score), { action: u[0].action });
	};
})(), bt = (e, t, n) => {
	let r = (e) => {
		let r = "city" in e ? e.city : e.farm, i = t.public.board["city" in e ? `${e.city}:${e.slot}` : `farm:${e.farm}`], a = n(J[r]);
		return i ? `${a}·${n(Y[i.industry])}` : a;
	};
	switch (e.type) {
		case "build": {
			let t = n(J["city" in e.at ? e.at.city : e.at.farm]), r = e.industry ? n(Y[e.industry]) : "";
			return `${n("games.brass.action.build")}:${t} ${r}`;
		}
		case "network": {
			let t = e.links.map((e) => O.find((t) => t.id === e)?.nodes.map((e) => n(J[e])).join("—") ?? e).join(", ");
			return `${n("games.brass.action.network")}:${t}`;
		}
		case "develop": return `${n("games.brass.action.develop")}:${e.industries.map((e) => n(Y[e])).join(", ")}`;
		case "sell": return `${n("games.brass.action.sell")}:${e.sales.map((e) => r(e.tile)).join(", ")}`;
		case "loan": return n("games.brass.action.loan");
		case "scout": return n("games.brass.action.scout");
		case "pass": return n("games.brass.action.pass");
		case "payDebt": return `${n("games.brass.payDebt")}:${e.tiles.map((e) => r(e)).join(", ")}`;
	}
}, xt = [
	"cotton",
	"manufacturer",
	"pottery",
	"brewery",
	"coal",
	"iron"
], St = {
	build: "games.brass.action.build",
	network: "games.brass.action.network",
	develop: "games.brass.action.develop",
	sell: "games.brass.action.sell"
}, Ct = (e) => e.startsWith("farm:") ? e.slice(5) : e.split(":")[0];
function wt(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ p(Tt, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Tt({ pub: e, priv: t, members: n, myRid: r, send: o }) {
	let s = c(), h = (e) => n.find((t) => t.rid === e)?.name ?? e, g = e.players.findIndex((e) => e.rid === r), _ = e.players[g], v = t?.hand ?? [], y = e.phase === "play" && g >= 0 && e.order[e.turnIdx] === g && e.actionsLeft > 0, b = e.pendingDebt.find((e) => e.rid === r), x = e.pendingDebt.find((e) => e.rid !== r), C = e.phase === "play" ? e.players[e.order[e.turnIdx]]?.rid : void 0;
	u(y || !!b, l);
	let [E, D] = i("idle"), [k, te] = i(null), [M, N] = i(null), [F, I] = i([]), [ne, re] = i(null), [L, ie] = i([]), [R, z] = i([]), [B, ae] = i([]), [oe, se] = i([]), [ce, le] = i([]), [V, H] = i(null), [ue, U] = i(!1), [de, W] = i(!1), [fe, G] = i(!1), [pe, me] = i(null), K = () => {
		D("idle"), te(null), N(null), I([]), re(null), ie([]), z([]), ae([]), se([]), le([]), H(null), U(!1), W(!1), G(!1), me(null);
	}, he = `${e.phase}|${e.era}|${e.round}|${e.turnIdx}|${e.actionsLeft}|${v.length}|${b?.need ?? ""}`, [ge, _e] = i(he);
	ge !== he && (_e(he), K());
	let q = Ze(e), ve = et(e, g), ye = g >= 0 && !tt(e, g), be = (e) => {
		let t = _?.stacks[e];
		return t && t.length > 0 ? t[t.length - 1] : void 0;
	}, xe = (t) => {
		let n = be(t);
		if (n === void 0) return !1;
		let r = S(t, n);
		return e.era === "canal" ? r.canal : r.rail;
	}, Se = (t) => {
		let n = Ze(e);
		for (let e of t) {
			let t = O.find((t) => t.id === e);
			for (let e of t.nodes) for (let r of t.nodes) e !== r && (n.has(e) || n.set(e, []), n.get(e).push(r));
		}
		return n;
	}, Ce = (() => {
		if (E !== "build" || k == null || !y || !_) return null;
		let t = v[k];
		if (!t) return null;
		let n = /* @__PURE__ */ new Map(), r, i = null;
		t.kind === "location" ? r = [t.city] : t.kind === "wildLocation" ? r = w.map((e) => e.id) : (i = t.kind === "industry" ? t.industries : xt, r = ye ? w.map((e) => e.id) : w.filter((e) => ve.has(e.id)).map((e) => e.id));
		for (let t of r) {
			let r = w.find((e) => e.id === t), a = r.slots.some((n, r) => e.board[`${t}:${r}`]?.owner === g);
			r.slots.forEach((o, s) => {
				let c = `${t}:${s}`;
				if (e.board[c] || e.era === "canal" && a) return;
				let l = (i ?? o).filter((e) => o.includes(e) && xe(e));
				l = l.filter((n) => o.length === 1 || !r.slots.some((r, i) => r.length === 1 && r[0] === n && !e.board[`${t}:${i}`])), l.length > 0 && n.set(c, l);
			});
		}
		if (i?.includes("brewery") && xe("brewery")) for (let t of ee) e.board[`farm:${t.id}`] || n.set(`farm:${t.id}`, ["brewery"]);
		for (let [r, a] of Object.entries(e.board)) {
			if (a.owner !== g) continue;
			let e = be(a.industry);
			if (!(e === void 0 || e <= a.level || !xe(a.industry))) {
				if (i) {
					if (!i.includes(a.industry) || !ye && !ve.has(Ct(r))) continue;
				} else if (t.kind === "location" && r.split(":")[0] !== t.city) continue;
				n.set(r, [a.industry]);
			}
		}
		for (let t of ["coal", "iron"]) {
			if (!i?.includes(t) || !xe(t) || Object.values(e.board).some((e) => e.industry === t && !e.flipped && e.cubes > 0) || (t === "coal" ? e.coalMarket : e.ironMarket) !== 0) continue;
			let r = be(t);
			for (let [i, a] of Object.entries(e.board)) a.owner === g || a.industry !== t || r === void 0 || r <= a.level || (ye || ve.has(Ct(i))) && n.set(i, [t]);
		}
		return n;
	})(), we = (t) => {
		if (e.era === "canal") return !0;
		let n = O.find((e) => e.id === t), r = Se([...F, t]), i = /* @__PURE__ */ new Set();
		for (let e of [n.nodes[0], n.nodes[n.nodes.length - 1]]) for (let t of $e(r, e)) i.add(t);
		return T.some((e) => i.has(e.id)) ? !0 : Object.entries(e.board).some(([e, t]) => t.industry === "coal" && !t.flipped && t.cubes > 0 && i.has(Ct(e)));
	}, Te = (() => {
		if (E !== "network" || k == null || !y) return null;
		let t = Math.min(e.era === "canal" ? 1 : 2, _?.linkStock ?? 0);
		if (F.length >= t) return /* @__PURE__ */ new Set();
		let n = new Set(ve);
		for (let e of F) for (let t of O.find((t) => t.id === e).nodes) n.add(t);
		let r = /* @__PURE__ */ new Set();
		for (let t of O) e.links[t.id] !== void 0 || F.includes(t.id) || (e.era === "canal" ? !t.canal : !t.rail) || (ye || t.nodes.some((e) => n.has(e))) && we(t.id) && r.add(t.id);
		return r;
	})(), Ee = F.length === 2 ? (() => {
		let t = Se(F), n = O.find((e) => e.id === F[1]), r = /* @__PURE__ */ new Set();
		for (let e of [n.nodes[0], n.nodes[n.nodes.length - 1]]) for (let n of $e(t, e)) r.add(n);
		return Object.entries(e.board).filter(([e, t]) => t.industry !== "brewery" || t.flipped || t.cubes === 0 ? !1 : t.owner === g || r.has(Ct(e))).map(([e]) => e);
	})() : [], De = (t, n, r, i) => {
		let a = e.board[t];
		if (!a) return null;
		let o = S(a.industry, a.level), s = $e(q, Ct(t)), c = [], l = !1, u = e.merchants.findIndex((e, t) => e.beer && !n.has(t) && (e.buys === "any" || e.buys === a.industry) && s.has(e.location));
		u >= 0 && c.length < o.beer && (c.push({
			kind: "merchant",
			index: u
		}), l = e.merchants[u].location === "gloucester");
		for (let [t, n] of Object.entries(e.board)) {
			if (c.length >= o.beer) break;
			if (n.industry !== "brewery" || n.flipped || n.cubes <= (r.get(t) ?? 0) || n.owner !== g && !s.has(Ct(t))) continue;
			let e = n.cubes - (r.get(t) ?? 0);
			for (let n = 0; n < e && c.length < o.beer; n++) c.push({
				kind: "tile",
				at: $(t)
			});
		}
		if (c.length < o.beer) return null;
		if (i) {
			c.some((e) => e.kind === "merchant") && n.add(u);
			for (let e of c) if (e.kind === "tile") {
				let t = "city" in e.at ? `${e.at.city}:${e.at.slot}` : `farm:${e.at.farm}`;
				r.set(t, (r.get(t) ?? 0) + 1);
			}
		}
		return {
			beers: c,
			gloucester: l
		};
	}, Oe = /* @__PURE__ */ new Map(), ke = 0;
	{
		let e = /* @__PURE__ */ new Set(), t = /* @__PURE__ */ new Map();
		for (let n of R) {
			let r = De(n, e, t, !0);
			r && (Oe.set(n, r.beers), r.gloucester && ke++);
		}
	}
	let Ae = (() => {
		let t = /* @__PURE__ */ new Set();
		if (E !== "sell" || !y) return t;
		let n = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Map();
		for (let e of R) De(e, n, r, !0);
		for (let [i, a] of Object.entries(e.board)) {
			if (a.owner !== g || a.flipped || !P.includes(a.industry) || R.includes(i)) continue;
			let o = $e(q, Ct(i));
			e.merchants.some((e) => (e.buys === "any" || e.buys === a.industry) && o.has(e.location)) && De(i, new Set(n), new Map(r), !1) && t.add(i);
		}
		return t;
	})(), je = (e, t = []) => {
		let n = _?.stacks[e] ?? [], r = n[n.length - 1 - t.filter((t) => t === e).length];
		return r !== void 0 && !S(e, r).noDevelop;
	}, Me = ce.reduce((t, n) => {
		let r = e.board[n];
		return t + (r ? Math.floor(S(r.industry, r.level).cost / 2) : 0);
	}, 0), Ne = b && Me < b.need ? new Set(Object.entries(e.board).filter(([e, t]) => t.owner === g && !ce.includes(e)).map(([e]) => e)) : /* @__PURE__ */ new Set(), Pe = y && v.length >= 3 && !v.some((e) => e.kind === "wildLocation" || e.kind === "wildIndustry") && e.wilds.location > 0 && e.wilds.industry > 0, Fe = (e, t) => {
		o({
			type: "build",
			card: k,
			at: $(e),
			industry: t
		}), K();
	}, Ie = (e) => {
		let t = Ce?.get(e);
		if (t) {
			if (V?.key === e) {
				H(null);
				return;
			}
			t.length === 1 ? H({
				key: e,
				ind: t[0]
			}) : N({
				key: e,
				inds: t
			});
		}
	}, Le = (e) => {
		F.includes(e) ? (I((t) => t.filter((t) => t !== e)), re(null)) : Te?.has(e) && (I((t) => [...t, e]), re(null));
	}, ze = () => {
		o({
			type: "network",
			card: k,
			links: F,
			beerFrom: ne ? $(ne) : void 0
		}), K();
	}, X = () => {
		o({
			type: "sell",
			card: k,
			sales: R.map((e) => ({
				tile: $(e),
				beers: Oe.get(e)
			})),
			bonusDevelop: B.length > 0 ? B : void 0
		}), K();
	}, Ve = b ? { tiles: /* @__PURE__ */ new Set([...Ne, ...ce]) } : y ? E === "build" && Ce ? { slots: new Set(Ce.keys()) } : E === "network" && Te ? { links: /* @__PURE__ */ new Set([...Te, ...F]) } : E === "sell" ? { tiles: /* @__PURE__ */ new Set([...Ae, ...R]) } : null : null, He = b ? s("games.brass.debtYou", { n: b.need }) : x ? s("games.brass.debtWait", { name: h(x.rid) }) : e.phase === "done" ? `🏆 ${h(e.winner ?? "")}` : y ? s("games.brass.turnYou", { n: e.actionsLeft }) : s("games.brass.turnWait", { name: h(C ?? "") }), Ue = `${s(e.era === "canal" ? "games.brass.eraCanal" : "games.brass.eraRail")} · ${s("games.brass.roundLabel", { n: e.round })}`, We = k == null ? void 0 : v[k], Z = pe ?? (E === "build" && We?.kind === "location" ? We.city : null), Q = V ? S(V.ind, be(V.ind) ?? 1) : null, Ge = R.reduce((e, t) => e + (Oe.get(t)?.length ?? 0), 0), Ke = new Set(b ? ce : E === "sell" ? R : V ? [V.key] : []), Je = Ce ? [...new Set([...Ce.keys()].map(Ct))] : [], Ye = b ? s("games.brass.debtYou", { n: b.need }) : s(V ? "games.brass.confirm" : E === "build" ? "games.brass.selectSlot" : E === "network" ? "games.brass.selectLink" : E === "sell" ? "games.brass.selectTile" : E === "develop" ? "games.brass.selectIndustry" : E === "scout" ? "games.brass.scoutPick" : k == null ? "games.brass.selectCard" : "games.brass.selectAction"), Xe = (e) => {
		o({
			type: e,
			card: k
		}), K();
	};
	return /* @__PURE__ */ p("div", {
		className: "brass-screen",
		children: /* @__PURE__ */ p(d, {
			adaptive: !0,
			className: "brass-layout",
			scroll: !1,
			actionsHeight: "brass-console-height",
			banner: /* @__PURE__ */ m("div", {
				className: "brass-banner",
				children: [/* @__PURE__ */ m("div", {
					className: "brass-banner__top",
					children: [/* @__PURE__ */ m("div", {
						className: "brass-banner__identity",
						children: [/* @__PURE__ */ p("strong", { children: s("games.brass.name") }), /* @__PURE__ */ p("span", { children: Ue })]
					}), /* @__PURE__ */ p("p", {
						className: "brass-banner__turn",
						role: "status",
						children: He
					})]
				}), /* @__PURE__ */ p("div", {
					className: "brass-players",
					role: "list",
					children: e.players.map((t, i) => {
						let o = n.find((e) => e.rid === t.rid), c = t.rid === C || e.pendingDebt.some((e) => e.rid === t.rid);
						return /* @__PURE__ */ m("div", {
							className: `brass-player ${c ? "brass-player--active" : ""}`,
							role: "listitem",
							children: [
								/* @__PURE__ */ p("span", {
									className: "brass-player__portrait",
									children: /* @__PURE__ */ p("img", {
										src: `./${a[(o?.avatar ?? 0) % a.length]}`,
										alt: ""
									})
								}),
								/* @__PURE__ */ m("span", {
									className: "brass-player__body",
									children: [/* @__PURE__ */ m("span", {
										className: "brass-player__name",
										children: [
											/* @__PURE__ */ p("b", { children: i + 1 }),
											/* @__PURE__ */ p("strong", { children: h(t.rid) }),
											t.rid === r && /* @__PURE__ */ p("em", { children: s("games.brass.you") })
										]
									}), /* @__PURE__ */ m("span", {
										className: "brass-player__numbers",
										children: [
											/* @__PURE__ */ m("span", { children: ["£", t.money] }),
											/* @__PURE__ */ p("span", { children: s("games.brass.incomeLabel", { n: t.incomeLevel }) }),
											/* @__PURE__ */ p("span", { children: s("games.brass.vpLabel", { n: t.vp }) })
										]
									})]
								}),
								/* @__PURE__ */ p("span", {
									className: "brass-player__hand",
									children: t.handCount
								})
							]
						}, t.rid);
					})
				})]
			}),
			overlay: /* @__PURE__ */ m("div", {
				className: "brass-overlays",
				children: [
					e.eraScores && e.eraScores.length > 0 && /* @__PURE__ */ p("div", {
						className: "brass-overlays__score",
						children: e.eraScores.map((e, t) => /* @__PURE__ */ m("span", { children: [
							h(e.rid),
							" ",
							s("games.brass.industryVp", { n: e.industryVp }),
							" + ",
							s("games.brass.linkVp", { n: e.linkVp })
						] }, `${e.era}-${e.rid}-${t}`))
					}),
					M && /* @__PURE__ */ m("div", {
						className: "brass-overlay brass-overlay--choices",
						children: [
							/* @__PURE__ */ p("strong", { children: s("games.brass.selectIndustry") }),
							/* @__PURE__ */ p("div", {
								className: "brass-overlay__row",
								children: M.inds.map((e) => /* @__PURE__ */ m("button", {
									type: "button",
									onClick: () => {
										H({
											key: M.key,
											ind: e
										}), N(null);
									},
									children: [/* @__PURE__ */ p(Be, {
										industry: e,
										size: 18
									}), s(Y[e])]
								}, e))
							}),
							/* @__PURE__ */ p("button", {
								className: "brass-overlay__close",
								type: "button",
								onClick: () => N(null),
								children: s("games.brass.cancel")
							})
						]
					}),
					fe && /* @__PURE__ */ m("div", {
						className: "brass-overlay brass-overlay--list",
						children: [
							/* @__PURE__ */ p("strong", { children: s("games.brass.candidateCities", { n: Je.length }) }),
							/* @__PURE__ */ p("div", {
								className: "brass-overlay__row",
								children: Je.map((e) => /* @__PURE__ */ p("button", {
									type: "button",
									onClick: () => {
										me(e), G(!1);
									},
									children: s(J[e])
								}, e))
							}),
							/* @__PURE__ */ p("button", {
								className: "brass-overlay__close",
								type: "button",
								onClick: () => G(!1),
								children: s("games.brass.cancel")
							})
						]
					}),
					de && /* @__PURE__ */ m("div", {
						className: "brass-overlay brass-overlay--market",
						children: [
							/* @__PURE__ */ p("strong", { children: s("games.brass.marketPrices") }),
							/* @__PURE__ */ m("div", {
								className: "brass-overlay__prices",
								children: [/* @__PURE__ */ p("span", { children: s("games.brass.coalMarket") }), A.map((t, n) => /* @__PURE__ */ p("b", {
									className: n >= A.length - e.coalMarket ? "filled" : "",
									children: t
								}, `coal-${n}`))]
							}),
							/* @__PURE__ */ m("div", {
								className: "brass-overlay__prices",
								children: [/* @__PURE__ */ p("span", { children: s("games.brass.ironMarket") }), j.map((t, n) => /* @__PURE__ */ p("b", {
									className: n >= j.length - e.ironMarket ? "filled" : "",
									children: t
								}, `iron-${n}`))]
							}),
							/* @__PURE__ */ p("button", {
								className: "brass-overlay__close",
								type: "button",
								onClick: () => W(!1),
								children: s("games.brass.cancel")
							})
						]
					}),
					ue && /* @__PURE__ */ m("div", {
						className: "brass-overlay brass-overlay--more",
						children: [
							/* @__PURE__ */ p("strong", { children: s("games.brass.moreActions") }),
							/* @__PURE__ */ m("button", {
								type: "button",
								disabled: k == null || (_?.incomeLevel ?? -10) - 3 < -10,
								onClick: () => Xe("loan"),
								children: [/* @__PURE__ */ p("b", { children: s("games.brass.action.loan") }), /* @__PURE__ */ p("span", { children: s("games.brass.loanEffect") })]
							}),
							/* @__PURE__ */ m("button", {
								type: "button",
								disabled: !Pe,
								onClick: () => {
									D("scout"), U(!1), te(null);
								},
								children: [/* @__PURE__ */ p("b", { children: s("games.brass.action.scout") }), /* @__PURE__ */ p("span", { children: s("games.brass.scoutEffect") })]
							}),
							/* @__PURE__ */ m("button", {
								type: "button",
								disabled: k == null,
								onClick: () => Xe("pass"),
								children: [/* @__PURE__ */ p("b", { children: s("games.brass.action.pass") }), /* @__PURE__ */ p("span", { children: s("games.brass.passEffect") })]
							}),
							/* @__PURE__ */ p("button", {
								className: "brass-overlay__close",
								type: "button",
								onClick: () => U(!1),
								children: s("games.brass.cancel")
							})
						]
					}),
					E === "network" && F.length === 2 && /* @__PURE__ */ m("div", {
						className: "brass-overlay brass-overlay--choices",
						children: [/* @__PURE__ */ p("strong", { children: s("games.brass.selectBeer") }), /* @__PURE__ */ p("div", {
							className: "brass-overlay__row",
							children: Ee.map((t) => {
								let n = e.board[t]?.owner, r = n === void 0 ? void 0 : e.players[n]?.rid;
								return /* @__PURE__ */ m("button", {
									type: "button",
									className: ne === t ? "selected" : "",
									onClick: () => re((e) => e === t ? null : t),
									children: [/* @__PURE__ */ p(Be, {
										industry: "brewery",
										size: 18
									}), n === g ? s("games.brass.beerFromOwn") : s("games.brass.beerFromOpponent", { name: h(r ?? "") })]
								}, t);
							})
						})]
					}),
					E === "sell" && R.length > 0 && /* @__PURE__ */ m("div", {
						className: "brass-overlay brass-overlay--summary",
						children: [
							/* @__PURE__ */ m("strong", { children: [
								s("games.brass.action.sell"),
								" · ",
								R.length
							] }),
							/* @__PURE__ */ m("span", { children: ["🍺 ×", Ge] }),
							ke > 0 && /* @__PURE__ */ m("span", { children: [
								s("games.brass.bonusDevelop"),
								" ",
								B.length,
								"/",
								ke
							] })
						]
					}),
					V && Q && !M && /* @__PURE__ */ m("div", {
						className: "brass-overlay brass-overlay--build",
						children: [/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ m("strong", { children: [
							s(J[Ct(V.key)]),
							" · ",
							s(Y[V.ind]),
							" ",
							Q.level
						] }), /* @__PURE__ */ p("span", { children: Q.cost > (_?.money ?? 0) ? s("games.brass.errCantAfford") : s("games.brass.buildPreview") })] }), /* @__PURE__ */ m("p", { children: [
							"£",
							Q.cost,
							Q.coal > 0 && `  ·  ${Re.coal.icon} ×${Q.coal}`,
							Q.iron > 0 && `  ·  ${Re.iron.icon} ×${Q.iron}`
						] })]
					})
				]
			}),
			actions: /* @__PURE__ */ m("div", {
				className: "brass-console",
				children: [
					/* @__PURE__ */ m("div", {
						className: "brass-console__markets",
						children: [/* @__PURE__ */ p(Dt, {
							label: s("games.brass.coalMarket"),
							kind: "coal",
							prices: A,
							count: e.coalMarket,
							emptyPrice: 8,
							onClick: () => {
								W((e) => !e), U(!1), G(!1);
							}
						}), /* @__PURE__ */ p(Dt, {
							label: s("games.brass.ironMarket"),
							kind: "iron",
							prices: j,
							count: e.ironMarket,
							emptyPrice: 6,
							onClick: () => {
								W((e) => !e), U(!1), G(!1);
							}
						})]
					}),
					/* @__PURE__ */ m("div", {
						className: "brass-mat",
						children: [/* @__PURE__ */ p("span", {
							className: "brass-mat__label",
							children: s("games.brass.yourMat")
						}), /* @__PURE__ */ p("div", {
							className: "brass-mat__tiles",
							children: xt.map((e) => {
								let t = _?.stacks[e] ?? [], n = t[t.length - 1], r = E === "sell" && ke > B.length, i = E === "develop" ? L.length < 2 && je(e, L) : r && je(e, B), a = E === "develop" ? L.filter((t) => t === e).length : B.filter((t) => t === e).length;
								return /* @__PURE__ */ m("button", {
									type: "button",
									disabled: !i,
									className: `brass-mat__tile ${i ? "is-pickable" : ""} ${a > 0 ? "is-selected" : ""}`,
									title: s(Y[e]),
									onClick: () => {
										E === "develop" && L.length < 2 && je(e, L) ? ie((t) => [...t, e]) : r && je(e, B) && ae((t) => [...t, e]);
									},
									children: [
										/* @__PURE__ */ p(Be, {
											industry: e,
											size: 21
										}),
										/* @__PURE__ */ p("span", { children: n === void 0 ? "—" : `${n} ×${t.length}` }),
										a > 0 && /* @__PURE__ */ m("i", { children: ["✓", a > 1 ? a : ""] })
									]
								}, e);
							})
						})]
					}),
					/* @__PURE__ */ m("div", {
						className: "brass-hand",
						children: [/* @__PURE__ */ m("span", {
							className: "brass-hand__label",
							children: [
								s("games.brass.handLabel"),
								" ",
								/* @__PURE__ */ p("b", { children: v.length }),
								/* @__PURE__ */ m("span", {
									className: "brass-hand__supply",
									children: [
										s("games.brass.deckLabel", { n: e.deckCount }),
										" · ",
										s("games.brass.wildLabel"),
										" ",
										e.wilds.location,
										"+",
										e.wilds.industry
									]
								})
							]
						}), /* @__PURE__ */ p("div", {
							className: "brass-hand__cards",
							children: v.map((e, t) => /* @__PURE__ */ p(Et, {
								card: e,
								selected: E === "scout" ? oe.includes(t) : k === t,
								disabled: !y || !!b,
								onClick: () => {
									if (E === "scout") {
										se((e) => e.includes(t) ? e.filter((e) => e !== t) : e.length < 3 ? [...e, t] : e);
										return;
									}
									te((e) => e === t ? null : t), D("idle"), H(null), N(null), G(!1), me(null);
								}
							}, `${t}-${e.kind}`))
						})]
					}),
					/* @__PURE__ */ m("div", {
						className: "brass-console__guide",
						children: [/* @__PURE__ */ p("strong", { children: Ye }), /* @__PURE__ */ m("span", { children: [
							s("games.brass.deckLabel", { n: e.deckCount }),
							" · ",
							s("games.brass.wildLabel"),
							" ",
							e.wilds.location,
							"+",
							e.wilds.industry
						] })]
					}),
					/* @__PURE__ */ p("div", {
						className: "brass-actions",
						children: b ? /* @__PURE__ */ m(f, { children: [
							/* @__PURE__ */ m("span", {
								className: "brass-actions__hint",
								children: [
									"£",
									Me,
									"/£",
									b.need
								]
							}),
							/* @__PURE__ */ p("button", {
								type: "button",
								onClick: () => le([]),
								children: s("games.brass.cancel")
							}),
							/* @__PURE__ */ p("button", {
								type: "button",
								className: "is-primary",
								disabled: ce.length === 0 || Me < b.need,
								onClick: () => {
									o({
										type: "payDebt",
										tiles: ce.map($)
									}), K();
								},
								children: s("games.brass.payDebt")
							})
						] }) : E === "idle" ? /* @__PURE__ */ m(f, { children: [[
							"build",
							"network",
							"develop",
							"sell"
						].map((e) => /* @__PURE__ */ p("button", {
							type: "button",
							className: k == null ? "" : "is-ready",
							disabled: !y || k == null,
							onClick: () => {
								D(e), U(!1), W(!1);
							},
							children: s(St[e])
						}, e)), /* @__PURE__ */ p("button", {
							type: "button",
							onClick: () => {
								U((e) => !e), W(!1);
							},
							children: s("games.brass.moreActions")
						})] }) : /* @__PURE__ */ m(f, { children: [
							/* @__PURE__ */ p("span", {
								className: "brass-actions__hint",
								children: Ye
							}),
							E === "build" && Je.length > 1 && /* @__PURE__ */ p("button", {
								type: "button",
								onClick: () => {
									G((e) => !e), W(!1);
								},
								children: s("games.brass.candidateCities", { n: Je.length })
							}),
							/* @__PURE__ */ p("button", {
								type: "button",
								onClick: K,
								children: s("games.brass.cancel")
							}),
							E === "build" && /* @__PURE__ */ p("button", {
								type: "button",
								className: "is-primary",
								disabled: !V || !!(Q && _ && _.money < Q.cost),
								onClick: () => V && Fe(V.key, V.ind),
								children: s("games.brass.confirm")
							}),
							E === "network" && /* @__PURE__ */ p("button", {
								type: "button",
								className: "is-primary",
								disabled: F.length === 0 || F.length > (_?.linkStock ?? 0) || (e.era === "canal" ? (_?.money ?? 0) < 3 : F.length === 1 ? (_?.money ?? 0) < 5 : (_?.money ?? 0) < 15 || ne == null),
								onClick: ze,
								children: F.length === 2 ? s("games.brass.doubleRail") : s("games.brass.confirm")
							}),
							E === "develop" && /* @__PURE__ */ p("button", {
								type: "button",
								className: "is-primary",
								disabled: L.length === 0,
								onClick: () => {
									o({
										type: "develop",
										card: k,
										industries: L
									}), K();
								},
								children: s("games.brass.confirm")
							}),
							E === "sell" && /* @__PURE__ */ p("button", {
								type: "button",
								className: "is-primary",
								disabled: R.length === 0 || R.some((e) => !Oe.has(e)) || B.length !== ke,
								onClick: X,
								children: s("games.brass.confirm")
							}),
							E === "scout" && /* @__PURE__ */ p("button", {
								type: "button",
								className: "is-primary",
								disabled: oe.length !== 3,
								onClick: () => {
									o({
										type: "scout",
										cards: [
											oe[0],
											oe[1],
											oe[2]
										]
									}), K();
								},
								children: s("games.brass.confirm")
							})
						] })
					})
				]
			}),
			children: /* @__PURE__ */ m("div", {
				className: "brass-map-wrap",
				children: [/* @__PURE__ */ p(qe, {
					pub: e,
					members: n,
					hot: Ve,
					pickedLinks: new Set(F),
					pickedTiles: Ke,
					focusNode: Z,
					onTapSlot: E === "build" ? Ie : void 0,
					onTapLink: E === "network" ? Le : void 0,
					onTapTile: b ? (e) => le((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]) : E === "sell" ? (e) => {
						z((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]), ae([]);
					} : void 0
				}, Z ?? "map"), /* @__PURE__ */ p("div", {
					className: "brass-map-wrap__hint",
					children: Ye
				})]
			})
		})
	});
}
function Et({ card: e, selected: t, disabled: n, onClick: r }) {
	let i = c(), a = e.kind === "location" ? i(J[e.city]) : e.kind === "industry" ? e.industries.map((e) => i(Y[e])).join(" / ") : i(e.kind === "wildLocation" ? "games.brass.cardWildLocation" : "games.brass.cardWildIndustry"), o = e.kind === "location" || e.kind === "wildLocation" ? i("games.brass.cardLocation") : i("games.brass.cardIndustry");
	return /* @__PURE__ */ m("button", {
		type: "button",
		className: `brass-hand__card ${t ? "is-selected" : ""}`,
		disabled: n,
		onClick: r,
		"aria-pressed": t,
		title: a,
		children: [
			/* @__PURE__ */ p("span", {
				className: "brass-hand__type",
				children: o
			}),
			/* @__PURE__ */ p("span", {
				className: "brass-hand__symbol",
				children: e.kind === "industry" ? e.industries.map((t) => /* @__PURE__ */ p(Be, {
					industry: t,
					size: e.industries.length > 1 ? 17 : 24
				}, t)) : e.kind === "wildIndustry" ? "★" : "⌖"
			}),
			/* @__PURE__ */ p("span", {
				className: "brass-hand__name",
				children: a
			})
		]
	});
}
function Dt({ label: e, kind: t, prices: n, count: r, emptyPrice: i, onClick: a }) {
	let o = c(), s = r > 0 ? n[Math.max(0, n.length - r)] : i;
	return /* @__PURE__ */ m("button", {
		type: "button",
		className: "brass-market",
		onClick: a,
		"aria-label": `${e} · £${s} · ${o("games.brass.marketStock", { n: r })}`,
		children: [/* @__PURE__ */ m("span", {
			className: "brass-market__info",
			children: [/* @__PURE__ */ p("strong", { children: e }), /* @__PURE__ */ m("small", { children: [
				/* @__PURE__ */ p(Be, {
					industry: t,
					size: 13
				}),
				" ",
				o("games.brass.marketStock", { n: r })
			] })]
		}), /* @__PURE__ */ m("b", {
			className: "brass-market__price",
			children: ["£", s]
		}, `${t}-${r}`)]
	});
}
//#endregion
//#region src/games/brass/game-over.tsx
function Ot({ public: e, result: t, members: n, myRid: l, onPlayAgain: u, onBackToLobby: d, hintCount: b }) {
	let x = e, C = c(), w = s((e) => e.locale), [T, ee] = i(!0), [E, D] = i(null), O = r(null), k = r(null), te = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? h(e) === null ? t.name : o(w, t.avatar) : e;
	}, A = (e) => C(J[e.startsWith("farm:") ? e.slice(5) : e.split(":")[0]]), j = (e) => {
		D(null), ee(e), requestAnimationFrame(() => (e ? k : O).current?.focus());
	}, M = (e) => {
		let n = x.players.find((t) => t.rid === e);
		return t.ranking.findIndex((e) => {
			let t = x.players.find((t) => t.rid === e);
			return t.vp === n.vp && t.incomeLevel === n.incomeLevel && t.money === n.money;
		}) + 1;
	}, N = E ? x.board[E] : void 0, P = N ? S(N.industry, N.level) : void 0;
	return /* @__PURE__ */ m("div", {
		className: "brass-game-over",
		children: [
			/* @__PURE__ */ m("div", {
				className: "brass-final-board",
				inert: T,
				children: [
					/* @__PURE__ */ p(qe, {
						pub: x,
						members: n,
						hot: { tiles: new Set(Object.keys(x.board)) },
						pickedTiles: E ? /* @__PURE__ */ new Set([E]) : void 0,
						onTapTile: D
					}),
					/* @__PURE__ */ m("select", {
						className: "brass-final-select",
						"aria-label": C("games.brass.tileDetails"),
						value: E ?? "",
						onChange: (e) => D(e.target.value || null),
						children: [/* @__PURE__ */ p("option", {
							value: "",
							children: C("games.brass.tileDetails")
						}), Object.entries(x.board).map(([e, t]) => /* @__PURE__ */ m("option", {
							value: e,
							children: [
								A(e),
								" · ",
								C(Y[t.industry]),
								" ",
								t.level,
								" · ",
								te(x.players[t.owner].rid)
							]
						}, e))]
					}),
					N && P && E && /* @__PURE__ */ m("aside", {
						className: "brass-final-detail",
						"aria-label": C("games.brass.tileDetails"),
						children: [
							/* @__PURE__ */ m("header", { children: [/* @__PURE__ */ p("strong", { children: A(E) }), /* @__PURE__ */ p("button", {
								type: "button",
								"aria-label": C("common.qr.close"),
								onClick: () => D(null),
								children: /* @__PURE__ */ p(_, { size: 20 })
							})] }),
							/* @__PURE__ */ m("div", {
								className: "brass-final-tile",
								children: [/* @__PURE__ */ p(Be, { industry: N.industry }), /* @__PURE__ */ m("strong", { children: [
									C(Y[N.industry]),
									" · ",
									C("games.brass.tileLevel", { n: N.level })
								] })]
							}),
							/* @__PURE__ */ m("p", { children: [
								te(x.players[N.owner].rid),
								" · ",
								C(N.flipped ? "games.brass.tileFlipped" : "games.brass.tileUnflipped")
							] }),
							/* @__PURE__ */ m("p", { children: [
								C("games.brass.industryVp", { n: N.flipped ? P.vp : 0 }),
								" · ",
								C("games.brass.linkIcons", { n: N.flipped ? P.links : 0 })
							] }),
							N.cubes > 0 && /* @__PURE__ */ p("p", { children: C("games.brass.tileResources", { n: N.cubes }) })
						]
					})
				]
			}),
			/* @__PURE__ */ m("section", {
				className: "brass-result",
				hidden: !T,
				"aria-label": C("session.result.title"),
				children: [
					/* @__PURE__ */ m("header", {
						className: "brass-result-header",
						children: [/* @__PURE__ */ p("button", {
							ref: k,
							type: "button",
							className: "brass-final-button",
							"aria-label": C("games.brass.viewBoard"),
							title: C("games.brass.viewBoard"),
							onClick: () => j(!1),
							children: /* @__PURE__ */ p(v, { size: 18 })
						}), b !== void 0 && /* @__PURE__ */ p("span", { children: C("session.hint.usedCount", { n: b }) })]
					}),
					/* @__PURE__ */ p("ol", {
						className: "brass-result-list",
						children: t.ranking.map((e) => {
							let r = n.find((t) => t.rid === e), i = x.players.find((t) => t.rid === e), o = t.winner.includes(e);
							return /* @__PURE__ */ m("li", {
								className: `brass-result-player${o ? " brass-result-winner" : ""}`,
								children: [
									/* @__PURE__ */ m("div", {
										className: "brass-result-identity",
										children: [
											/* @__PURE__ */ p("span", {
												className: "brass-result-rank",
												children: M(e)
											}),
											r && /* @__PURE__ */ p("img", {
												src: a[r.avatar % a.length],
												alt: "",
												draggable: !1
											}),
											/* @__PURE__ */ m("strong", { children: [
												o && /* @__PURE__ */ p("span", {
													"aria-label": C("games.brass.winner"),
													children: "👑 "
												}),
												te(e),
												e === l && /* @__PURE__ */ p("small", { children: C("lobby.you") })
											] }),
											/* @__PURE__ */ p("b", {
												className: "brass-result-total",
												children: t.scores?.[e] ?? i.vp
											})
										]
									}),
									/* @__PURE__ */ p("dl", {
										className: "brass-result-eras",
										children: ["canal", "rail"].map((t) => {
											let n = x.eraScores?.find((n) => n.rid === e && n.era === t);
											return /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("dt", { children: C(t === "canal" ? "games.brass.eraCanal" : "games.brass.eraRail") }), /* @__PURE__ */ p("dd", { children: n ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("span", { children: C("games.brass.industryVp", { n: n.industryVp }) }), /* @__PURE__ */ p("span", { children: C("games.brass.linkVp", { n: n.linkVp }) })] }) : "—" })] }, t);
										})
									}),
									/* @__PURE__ */ m("div", {
										className: "brass-result-assets",
										children: [/* @__PURE__ */ p("span", { children: C("games.brass.incomeLabel", { n: i.incomeLevel }) }), /* @__PURE__ */ p("span", { children: C("games.brass.moneyLabel", { n: i.money }) })]
									}),
									t.autopilot?.[e] !== void 0 && t.autopilot[e] > 0 && /* @__PURE__ */ p("small", { children: C("session.autopilot.share", { n: Math.round(t.autopilot[e] * 100) }) })
								]
							}, e);
						})
					}),
					T && /* @__PURE__ */ m("footer", {
						className: "brass-result-actions",
						children: [
							u && /* @__PURE__ */ p(g, {
								className: "brass-final-button brass-final-primary",
								label: C("session.result.playAgain"),
								confirmLabel: C("games.brass.confirmAgain"),
								onConfirm: u
							}),
							d && /* @__PURE__ */ p(g, {
								className: "brass-final-button",
								label: C("session.result.backToLobby"),
								confirmLabel: C("games.brass.confirmBack"),
								onConfirm: d
							}),
							!u && !d && /* @__PURE__ */ p("p", { children: C("session.result.waitHost") })
						]
					})
				]
			}),
			!T && /* @__PURE__ */ m("button", {
				ref: O,
				type: "button",
				className: "brass-final-button brass-result-toggle",
				onClick: () => j(!0),
				children: [/* @__PURE__ */ p(y, { size: 18 }), C("games.brass.viewResults")]
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/brass/entry.tsx
var kt = {
	definition: Le,
	View: wt,
	bot: yt,
	describe: bt,
	OverView: Ot,
	locales: {
		zh: {
			name: "伯明翰",
			desc: "工业革命英格兰:建厂、铺路、卖货,两个时代的经济博弈",
			rules: "目标:运河与铁路两个时代,翻面产业与连接在时代末计分,总分最高者胜。\n回合:每轮每人 2 个行动(运河时代首轮仅 1 个),每个行动弃 1 张手牌。\n六个行动:\n· 建造——弃位置牌建该城任意产业(不需网络),或弃产业牌在你网络内的城市建设。\n· 取该产业最低级板块并支付金钱与煤/铁;有只印该产业图标的空槽时必须放那里。\n· 网络——运河时代 £3 建 1 条运河;铁路时代 £5 建 1 条铁路。\n· 也可支付 £15 加 1 份啤酒建 2 条铁路(啤酒须来自酒厂);每条铁路消耗 1 份煤。\n· 研发——移除自己板上 1-2 块最低级板块,每块消耗 1 份铁;灯泡陶器不可研发。\n· 出售——翻面你的棉纺厂/制造商/陶器厂:须连通收购该产业的商人,消耗板块所示数量的啤酒。\n· 一次出售可连卖多块;使用商人旁的啤酒还额外获得该商人的奖励。\n· 贷款——获得 £30,收入等级退 3 级。\n· 侦察——弃 3 张牌换 2 张百搭。\n资源:\n· 煤从最近的连通煤矿免费获取,煤矿没煤了才向市场购买(须连通商人)。\n· 铁从任意铁厂免费获取,铁厂没铁了才购买。\n· 啤酒可任意使用自家酒厂的,使用对手酒厂的啤酒须与其连通。\n时代:牌堆与手牌全空时时代结束;翻面产业和连接计分,运河时代末移除全部 1 级板块后进入铁路时代。\n回合末:花钱最少者下轮先手;按收入等级收钱(收入为负时要支付差额,钱不够就变卖板块)。",
			city: {
				belper: "贝尔珀",
				derby: "德比",
				leek: "利克",
				stokeOnTrent: "特伦特河畔斯托克",
				stone: "斯通",
				uttoxeter: "阿托克西特",
				stafford: "斯塔福德",
				burtonOnTrent: "特伦特河畔伯顿",
				cannock: "坎诺克",
				tamworth: "塔姆沃思",
				walsall: "沃尔索尔",
				wolverhampton: "伍尔弗汉普顿",
				coalbrookdale: "科尔布鲁克代尔",
				dudley: "达德利",
				kidderminster: "基德明斯特",
				worcester: "伍斯特",
				birmingham: "伯明翰",
				coventry: "考文垂",
				nuneaton: "纽尼顿",
				redditch: "雷迪奇",
				shrewsbury: "什鲁斯伯里",
				gloucester: "格洛斯特",
				oxford: "牛津",
				warrington: "沃灵顿",
				nottingham: "诺丁汉",
				farmN: "北农场",
				farmS: "南农场"
			},
			industry: {
				cotton: "棉纺厂",
				manufacturer: "制造商",
				pottery: "陶器厂",
				brewery: "啤酒厂",
				coal: "煤矿",
				iron: "铁厂"
			},
			action: {
				build: "建造",
				network: "网络",
				develop: "研发",
				sell: "出售",
				loan: "贷款",
				scout: "侦察",
				pass: "跳过"
			},
			errNotPlaying: "对局已结束",
			errNotYourTurn: "还没轮到你",
			errBadCard: "这张牌不能这么用",
			errNeedIndustry: "指定要建的产业",
			errFarmBrewery: "农场只能建啤酒厂(用啤酒产业牌或百搭产业牌)",
			errNotInNetwork: "目标不在你的网络内",
			errNoTile: "该产业的板块用完了",
			errEraLocked: "这个时代不能建这块板块",
			errBadOverbuild: "这里不能覆盖建造(需同产业更高等级;覆盖对手仅限煤/铁且该资源全图耗尽)",
			errBadSlot: "这个槽位不能建该产业",
			errSingleSlotFirst: "有只印该产业图标的空槽,必须优先放那里",
			errOnePerCity: "运河时代每城限建 1 块",
			errCantAfford: "钱不够",
			errNoCoal: "没有可用的煤(需连通煤矿或商人)",
			errBadLinks: "这条线不能建",
			errNeedBeer: "需要啤酒(双铁路须来自酒厂)",
			errBeerNotConnected: "对手的酒厂须连通第二条铁路",
			errLightbulb: "灯泡陶器不能被研发",
			errBadSell: "这块板块不能出售",
			errNoMerchant: "没有连通收购该产业的商人",
			errOneMerchant: "一次出售只能用一位商人的啤酒",
			errBonusDevelop: "免费研发数量与格洛斯特啤酒数不符",
			errLoanFloor: "收入不能再降了",
			errHasWild: "手上已有百搭,不能再侦察",
			errNoWild: "百搭牌已取完",
			errNoDebt: "你没有待偿还的缺口",
			errDebtPending: "先变卖板块偿还负收入",
			errOverpay: "够付即停,不能多卖",
			eraCanal: "运河时代",
			viewBoard: "查看版图",
			viewResults: "查看结算",
			tileDetails: "产业详情",
			tileLevel: "{{n}} 级",
			tileFlipped: "已翻面",
			tileUnflipped: "未翻面",
			tileResources: "剩余资源 {{n}}",
			linkIcons: "连接图标 {{n}}",
			winner: "获胜",
			confirmAgain: "确定再来一局",
			confirmBack: "确定返回房间",
			eraRail: "铁路时代",
			roundLabel: "第 {{n}} 轮",
			turnYou: "轮到你:还剩 {{n}} 个行动",
			turnWait: "等 {{name}} 行动…",
			deckLabel: "牌库 {{n}}",
			coalMarket: "煤市场",
			ironMarket: "铁市场",
			marketEmpty: "空",
			wildLabel: "百搭",
			handLabel: "手牌",
			yourMat: "你的玩家板",
			moneyLabel: "£{{n}}",
			incomeLabel: "收入 {{n}}",
			vpLabel: "{{n}} 分",
			linkStock: "连接 {{n}}",
			merchantBeer: "商人啤酒",
			merchantBlank: "不收购",
			merchantAny: "全收",
			bonusDevelop: "免费研发",
			bonusIncome: "收入+2",
			bonusVp: "+{{n}} 分",
			bonusMoney: "+£{{n}}",
			selectCard: "先选一张手牌",
			selectSlot: "选择槽位",
			selectLink: "选择线路",
			selectTile: "选择板块",
			selectIndustry: "选择产业",
			scoutPick: "选择 3 张牌换 2 张百搭",
			selectBeer: "选择啤酒来源",
			beerFromOwn: "自家酒厂",
			beerFromOpponent: "{{name}} 的酒厂",
			beerFromMerchant: "商人啤酒(得奖励)",
			confirm: "确认",
			cancel: "取消",
			actionsLeft: "剩 {{n}} 动",
			debtYou: "负收入缺口 £{{n}}:变卖板块偿还",
			debtWait: "等 {{name}} 变卖偿债…",
			payDebt: "变卖偿债",
			doubleRail: "双铁路(£15+1 啤酒)",
			sellMore: "继续出售",
			eraScoreTitle: "{{era}}计分",
			industryVp: "产业 {{n}}",
			linkVp: "连接 {{n}}",
			finalBreakdown: "得分明细",
			cardLocation: "位置牌",
			cardIndustry: "产业牌",
			cardDual: "棉纺/制造商",
			cardWildLocation: "百搭位置",
			cardWildIndustry: "百搭产业",
			you: "你",
			selectAction: "选择行动",
			candidateCities: "可选地点 {{n}}",
			marketPrices: "市场价格",
			marketStock: "库存 {{n}}",
			moreActions: "更多",
			loanEffect: "获得 £30，收入降 3 级",
			scoutEffect: "弃 3 张牌，换 2 张百搭",
			passEffect: "弃 1 张牌，跳过此行动",
			buildPreview: "建造费用与资源需求",
			mapLabel: "伯明翰工业地图，可拖动与缩放",
			zoomIn: "放大地图",
			zoomOut: "缩小地图",
			showFullMap: "全图"
		},
		en: {
			name: "Brass: Birmingham",
			desc: "Industrial revolution England: build, connect, and sell across two eras",
			rules: "Goal: across the Canal and Rail eras, flipped industries and links score at the end of each era; most VP wins.\nTurns: each round every player takes 2 actions (only 1 in the first Canal round); every action discards 1 card.\nThe six actions:\n· Build — discard a location card to build any industry in that city (no network needed), or an industry card to build in your network.\n· Take your lowest-level tile of that industry and pay its cost in money and coal/iron; if a slot showing only that industry is free, you must use it.\n· Network — Canal Era: 1 canal link for £3. Rail Era: 1 rail link for £5.\n· Or pay £15 plus 1 beer for 2 rail links (the beer must come from a brewery); each rail link consumes 1 coal.\n· Develop — remove 1-2 of your lowest-level tiles, 1 iron each; lightbulb Potteries cannot be developed.\n· Sell — flip your Cotton Mills, Manufacturers and Potteries: each must connect to a merchant buying that industry and consume the beer shown.\n· You may sell several tiles in one action; beer taken from beside a merchant also earns that merchant’s bonus.\n· Loan — take £30 and drop 3 income levels.\n· Scout — discard 3 cards for 2 wild cards.\nResources:\n· Coal is taken free from the closest connected mine; only when mines run out do you buy from the market (needs a merchant connection).\n· Iron is taken free from any iron works; only when they run out do you buy it.\n· Beer from your own breweries is used freely; opponents' breweries must be connected.\nEras: an era ends when the deck and all hands are empty; flipped industries and links score, and after the Canal Era all level 1 tiles are removed.\nEnd of round: whoever spent least goes first next round; collect income (when income is negative you must pay the difference — sell tiles if short).",
			city: {
				belper: "Belper",
				derby: "Derby",
				leek: "Leek",
				stokeOnTrent: "Stoke-on-Trent",
				stone: "Stone",
				uttoxeter: "Uttoxeter",
				stafford: "Stafford",
				burtonOnTrent: "Burton-on-Trent",
				cannock: "Cannock",
				tamworth: "Tamworth",
				walsall: "Walsall",
				wolverhampton: "Wolverhampton",
				coalbrookdale: "Coalbrookdale",
				dudley: "Dudley",
				kidderminster: "Kidderminster",
				worcester: "Worcester",
				birmingham: "Birmingham",
				coventry: "Coventry",
				nuneaton: "Nuneaton",
				redditch: "Redditch",
				shrewsbury: "Shrewsbury",
				gloucester: "Gloucester",
				oxford: "Oxford",
				warrington: "Warrington",
				nottingham: "Nottingham",
				farmN: "Farm (N)",
				farmS: "Farm (S)"
			},
			industry: {
				cotton: "Cotton Mill",
				manufacturer: "Manufacturer",
				pottery: "Pottery",
				brewery: "Brewery",
				coal: "Coal Mine",
				iron: "Iron Works"
			},
			action: {
				build: "Build",
				network: "Network",
				develop: "Develop",
				sell: "Sell",
				loan: "Loan",
				scout: "Scout",
				pass: "Pass"
			},
			errNotPlaying: "The game is over",
			errNotYourTurn: "Not your turn yet",
			errBadCard: "This card cannot be used for that",
			errNeedIndustry: "Choose which industry to build",
			errFarmBrewery: "Farms take breweries only (brewery industry or wild industry card)",
			errNotInNetwork: "Target is not in your network",
			errNoTile: "No tiles of that industry left",
			errEraLocked: "This tile cannot be built in this era",
			errBadOverbuild: "Cannot overbuild here (same industry, higher level; opponent tiles only coal/iron when that resource is exhausted)",
			errBadSlot: "This slot cannot hold that industry",
			errSingleSlotFirst: "A single-icon slot for this industry is free — you must use it",
			errOnePerCity: "Only 1 tile per city in the Canal Era",
			errCantAfford: "Not enough money",
			errNoCoal: "No coal available (needs a connected mine or merchant)",
			errBadLinks: "Cannot build a link here",
			errNeedBeer: "Beer required (double rail needs a brewery)",
			errBeerNotConnected: "Opponent's brewery must connect to the second rail link",
			errLightbulb: "Lightbulb Potteries cannot be developed",
			errBadSell: "This tile cannot be sold",
			errNoMerchant: "No connected merchant buys that industry",
			errOneMerchant: "One sale may use only one merchant's beer",
			errBonusDevelop: "Free develops must match Gloucester beers consumed",
			errLoanFloor: "Income cannot go lower",
			errHasWild: "Already holding a wild card",
			errNoWild: "No wild cards left",
			errNoDebt: "You have no shortfall to cover",
			errDebtPending: "Sell tiles to cover negative income first",
			errOverpay: "Stop as soon as the shortfall is covered",
			eraCanal: "Canal Era",
			viewBoard: "View board",
			viewResults: "View results",
			tileDetails: "Industry details",
			tileLevel: "Level {{n}}",
			tileFlipped: "Flipped",
			tileUnflipped: "Not flipped",
			tileResources: "Resources left: {{n}}",
			linkIcons: "Link icons {{n}}",
			winner: "Winner",
			confirmAgain: "Confirm new game",
			confirmBack: "Confirm return to lobby",
			eraRail: "Rail Era",
			roundLabel: "Round {{n}}",
			turnYou: "Your turn: {{n}} action(s) left",
			turnWait: "Waiting for {{name}}…",
			deckLabel: "Deck {{n}}",
			coalMarket: "Coal market",
			ironMarket: "Iron market",
			marketEmpty: "empty",
			wildLabel: "Wild",
			handLabel: "Hand",
			yourMat: "Your player mat",
			moneyLabel: "£{{n}}",
			incomeLabel: "Income {{n}}",
			vpLabel: "{{n}} VP",
			linkStock: "{{n}} links",
			merchantBeer: "Merchant beer",
			merchantBlank: "Buys nothing",
			merchantAny: "Buys all",
			bonusDevelop: "Free develop",
			bonusIncome: "Income +2",
			bonusVp: "+{{n}} VP",
			bonusMoney: "+£{{n}}",
			selectCard: "Pick a card first",
			selectSlot: "Pick a slot",
			selectLink: "Pick a link",
			selectTile: "Pick a tile",
			selectIndustry: "Pick an industry",
			scoutPick: "Pick 3 cards for 2 wilds",
			selectBeer: "Pick beer sources",
			beerFromOwn: "Your brewery",
			beerFromOpponent: "{{name}}'s brewery",
			beerFromMerchant: "Merchant beer (bonus)",
			confirm: "Confirm",
			cancel: "Cancel",
			actionsLeft: "{{n}} left",
			debtYou: "Negative income shortfall £{{n}}: sell tiles to cover it",
			debtWait: "Waiting for {{name}} to sell tiles…",
			payDebt: "Sell tiles",
			doubleRail: "Double rail (£15 + 1 beer)",
			sellMore: "Sell another",
			eraScoreTitle: "{{era}} scoring",
			industryVp: "Industry {{n}}",
			linkVp: "Links {{n}}",
			finalBreakdown: "Score breakdown",
			cardLocation: "Location",
			cardIndustry: "Industry",
			cardDual: "Cotton/Manufacturer",
			cardWildLocation: "Wild location",
			cardWildIndustry: "Wild industry",
			you: "You",
			selectAction: "Choose an action",
			candidateCities: "{{n}} places",
			marketPrices: "Market prices",
			marketStock: "{{n}} in stock",
			moreActions: "More",
			loanEffect: "Gain £30; drop 3 income levels",
			scoutEffect: "Discard 3 cards for 2 wilds",
			passEffect: "Discard 1 card and pass",
			buildPreview: "Build cost and resources",
			mapLabel: "Birmingham industrial map, drag or zoom to explore",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			showFullMap: "Full map"
		}
	}
};
//#endregion
export { kt as default };
