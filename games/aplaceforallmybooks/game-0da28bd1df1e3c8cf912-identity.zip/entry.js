import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { avatarNameAt as r, useI18nSettings as i, useT as a } from "@bgparty/sdk/i18n";
import { GameScreen as o } from "@bgparty/sdk/ui/game-screen";
import { gameAssetUrl as s } from "@bgparty/sdk/assets";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { Fragment as l, jsx as u, jsxs as d } from "react/jsx-runtime";
import { seatName as f } from "@bgparty/sdk/ui/player-strip";
import { AVATARS as ee } from "@bgparty/sdk/avatars";
import { DeltaNumber as p } from "@bgparty/sdk/fx/delta-number";
import { PLAYER_COLORS as te } from "@bgparty/sdk/player-colors";
import { Floater as ne, FlySprite as re, PulseBox as ie } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as ae, OptionSection as m, OptionSwitch as h } from "@bgparty/sdk/ui/game-options";
//#region src/games/aplaceforallmybooks/meta.ts
var oe = {
	id: "aplaceforallmybooks",
	tier: "alpha",
	mechanics: [
		"worker-placement",
		"tile-placement",
		"set-collection",
		"hand-management"
	],
	interactionTags: [],
	nameKey: "games.aplaceforallmybooks.name",
	descKey: "games.aplaceforallmybooks.desc",
	rulesKey: "games.aplaceforallmybooks.rules",
	rulesUrl: { en: "https://boardgamegeek.com/filepage/291968/a-place-for-all-my-books-rules-10" },
	icon: "📚",
	iconImg: "games/aplaceforallmybooks.webp",
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#245848",
	releasedAt: "2026-11-09T14:00:00+08:00",
	search: {
		py: "wodeshuxiangdi",
		init: "wdsxd"
	},
	hotseat: "cover"
}, se = t.enum([
	"r",
	"y",
	"b",
	"g"
]), ce = t.enum([
	"r",
	"y",
	"b",
	"g",
	"w0",
	"w1",
	"lamp",
	"ends"
]), g = t.int().min(0).max(54), _ = t.int().min(0).max(15), v = t.object({
	pins: t.boolean().default(!1),
	notes: t.boolean().default(!1),
	soloLevel: t.int().min(1).max(5).default(1)
}).prefault({}), y = t.enum([
	"gather",
	"sort",
	"read",
	"rest",
	"admire",
	"leave"
]), le = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("draft"),
		keep: t.array(g).length(3)
	}),
	t.object({
		type: t.literal("home"),
		action: y
	}),
	t.object({
		type: t.literal("village"),
		place: t.enum([
			"bookstore",
			"library",
			"shop",
			"exchange"
		]),
		shelf: t.int().min(0).max(2).optional(),
		side: t.int().min(0).max(1).optional(),
		items: t.array(t.int().min(0).max(48)).max(2).optional(),
		blind: t.boolean().optional()
	}),
	t.object({ type: t.literal("return") }),
	t.object({
		type: t.literal("gather"),
		sources: t.array(t.object({
			cell: _,
			token: t.enum([
				"book",
				"lamp",
				"ends"
			]).default("book")
		})).max(18),
		to: _
	}),
	t.object({
		type: t.literal("sort"),
		from: _,
		moves: t.array(t.object({
			index: t.int().min(0).max(9),
			to: _
		})).max(10)
	}),
	t.object({
		type: t.literal("read"),
		from: _,
		index: t.int().min(0).max(9)
	}),
	t.object({
		type: t.literal("discard"),
		ids: t.array(g).max(55)
	}),
	t.object({
		type: t.literal("selectBooks"),
		indices: t.array(t.int().min(0).max(5)).max(3)
	}),
	t.object({
		type: t.literal("pack"),
		piles: t.array(t.array(t.int().min(0).max(40)).max(40)).length(2)
	}),
	t.object({
		type: t.literal("unload"),
		cells: t.array(_).length(2)
	}),
	t.object({
		type: t.literal("exchange"),
		indices: t.array(t.int().min(0).max(9)).max(6),
		colors: t.array(se).max(8)
	}),
	t.object({
		type: t.literal("placeTile"),
		cell: _
	}),
	t.object({
		type: t.literal("kitty"),
		room: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("chooseColor"),
		color: se
	}),
	t.object({
		type: t.literal("project"),
		id: g
	}),
	t.object({ type: t.literal("finishAdmire") }),
	t.object({
		type: t.literal("candle"),
		ids: t.array(g).length(2),
		reward: t.enum(["energy", "cards"])
	}),
	t.object({
		type: t.literal("bonus"),
		id: t.int().min(0).max(48),
		discard: g.optional()
	}),
	t.object({
		type: t.literal("flip"),
		id: t.int().min(0).max(48)
	}),
	t.object({
		type: t.literal("takeItem"),
		id: t.int().min(0).max(48)
	}),
	t.object({
		type: t.literal("claim"),
		id: t.int().min(0).max(9)
	}),
	t.object({
		type: t.literal("removeRivals"),
		color: t.enum([
			"r",
			"y",
			"b",
			"g",
			"none"
		])
	}),
	t.object({ type: t.literal("skip") }),
	t.object({ type: t.literal("end") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), ue = t.object({
	kind: t.enum([
		"gather",
		"sort",
		"read",
		"discard",
		"library",
		"pack",
		"unload",
		"exchange",
		"tile",
		"kitty",
		"wild",
		"admire",
		"puzzle",
		"succulents",
		"record",
		"laptop",
		"snowglobe",
		"remove"
	]),
	rid: t.string(),
	cards: t.array(ce).default([]),
	n: t.int().default(0),
	id: t.int().default(-1),
	optional: t.boolean().default(!1)
}), b = t.object({
	books: t.int(),
	projects: t.int(),
	items: t.int(),
	majors: t.int(),
	energy: t.int(),
	total: t.int()
}), x = t.object({
	rid: t.string(),
	mat: t.int(),
	board: t.array(t.array(ce)).length(16),
	bag: t.array(t.array(ce)).length(2),
	energy: t.int(),
	pos: t.string(),
	items: t.array(t.int()),
	used: t.array(t.int()),
	cats: t.record(t.string(), t.int()),
	completed: t.int(),
	handCount: t.int(),
	majors: t.record(t.string(), t.int()),
	score: b
}), de = t.object({
	config: v,
	phase: t.enum([
		"draft",
		"turn",
		"rival",
		"done"
	]),
	turn: t.string(),
	actor: t.string(),
	round: t.int(),
	turnNo: t.int(),
	sun: t.int(),
	endRound: t.int().nullable(),
	step: t.enum([
		"main",
		"village",
		"home",
		"after"
	]),
	players: t.array(x),
	shelves: t.array(t.object({
		books: t.array(ce),
		project: g.nullable()
	})),
	shop: t.array(t.int()),
	itemDiscard: t.array(t.int()),
	projectDiscard: t.array(g),
	majors: t.array(t.int()),
	bagCount: t.int(),
	supply: t.record(se, t.int()),
	task: ue.nullable(),
	drafted: t.array(t.string()),
	wild: t.array(se),
	admireEnergy: t.int(),
	admireOverflow: t.int(),
	bookendReady: t.boolean(),
	candleUsed: t.boolean(),
	bonus: t.int().nullable(),
	rival: t.object({
		pos: t.string(),
		deckCount: t.int(),
		queue: t.array(t.int()),
		books: t.int(),
		projects: t.int(),
		items: t.array(t.int()),
		score: t.int(),
		last: t.int().nullable(),
		lost: t.boolean()
	}).nullable(),
	log: t.array(t.object({
		rid: t.string(),
		kind: t.string(),
		n: t.int()
	}))
}), fe = t.object({
	hand: t.array(g),
	completed: t.array(g),
	task: ue.nullable()
}), S = [
	"r",
	"y",
	"b",
	"g"
], C = [
	[
		0,
		1,
		4,
		5,
		8
	],
	[
		2,
		3,
		6,
		7
	],
	[
		12,
		13,
		14
	],
	[
		9,
		10,
		11,
		15
	]
], w = [
	0,
	3,
	12,
	15
], T = [
	5,
	6,
	9,
	10
], E = [
	0,
	2,
	5,
	8,
	15,
	44
], D = [
	12,
	17,
	25,
	26,
	41,
	43
], pe = {
	3: "g",
	6: "b",
	18: "y",
	42: "r"
}, me = [
	11,
	21,
	22,
	23,
	28,
	39
], he = [
	0,
	0,
	0,
	0,
	3,
	0,
	0,
	2,
	0,
	2,
	2,
	3,
	0,
	3,
	2,
	0,
	2,
	0,
	0,
	2,
	3,
	2,
	1,
	3,
	3,
	0,
	0,
	0,
	2,
	2,
	2,
	2,
	3,
	2,
	3,
	1,
	2,
	2,
	2,
	1,
	3,
	0,
	0,
	0,
	0,
	3,
	2,
	3,
	0
], O = [
	"b",
	"g",
	"y",
	"r"
], ge = [
	[
		3,
		3,
		4,
		2
	],
	[
		2,
		3,
		3,
		4
	],
	[
		3,
		4,
		2,
		3
	],
	[
		4,
		2,
		3,
		3
	]
], _e = [
	[
		4,
		7,
		9,
		14
	],
	[
		0,
		6,
		10,
		13
	],
	[
		2,
		5,
		13,
		15
	],
	[
		3,
		5,
		9,
		12
	]
], ve = [
	[
		3,
		4,
		3,
		2
	],
	[
		3,
		2,
		4,
		3
	],
	[
		3,
		3,
		2,
		4
	],
	[
		4,
		2,
		3,
		3
	]
], k = (e, t = [], n) => ({
	kind: e,
	colors: t,
	room: n,
	reward: "energy"
}), A = (e, t = [], n) => ({
	kind: e,
	colors: t,
	room: n,
	reward: "item"
}), ye = [
	A("cornersColor", ["g"]),
	k("mixed", ["g", "y"]),
	k("singleColor", ["b"]),
	A("cornersColor", ["y"]),
	A("noColorTall", ["y"]),
	A("roomTall", [], 3),
	k("singleColor", ["r"]),
	k("rowsCols"),
	k("roomsNoColor", ["r"], 1),
	k("rainbow"),
	A("cornersColor", ["r"]),
	A("noColorTall", ["b"]),
	k("centerEmpty"),
	A("noColorTall", ["g"]),
	k("roomsNoColor", ["b"], 1),
	k("oneEmpty"),
	k("rowTops"),
	k("centerTops", ["r"]),
	k("roomsNoColor", ["g"], 1),
	k("cornersEmpty"),
	k("cornersTops"),
	k("roomTops", ["g"]),
	k("allTall"),
	k("roomsNoColor", ["y"], 1),
	k("centerTops", ["y"]),
	k("colTops"),
	A("fourColor", ["y"]),
	A("noColorTall", ["r"]),
	k("roomsNoColor", ["y"], 0),
	k("roomTops", ["r"]),
	A("fourColor", ["r"]),
	k("centerTops", ["b"]),
	k("roomTops", ["b"]),
	k("mixed", ["b", "r"]),
	A("fourColor", ["g"]),
	k("cornerSingles"),
	k("centerTops", ["g"]),
	k("roomsNoColor", ["b"], 0),
	k("roomTops", ["y"]),
	A("oneTall"),
	A("nightColor"),
	k("noSingles"),
	k("roomsNoColor", ["g"], 0),
	k("roomsNoColor", ["r"], 0),
	A("cornersColor", ["b"]),
	A("roomTall", [], 0),
	k("roomSingles"),
	A("centerTall"),
	k("square"),
	A("fourColor", ["b"]),
	k("singleColor", ["y"]),
	k("six"),
	k("singleColor", ["g"]),
	k("noTall"),
	A("roomTall", [], 1)
], j = (e) => e !== "lamp" && e !== "ends", M = (e) => e.filter(j).length, be = (e) => {
	for (let t = e.length - 1; t >= 0; t--) if (j(e[t])) return t;
	return -1;
};
function xe(e, t = []) {
	return e === "lamp" || e === "ends" ? null : e === "w0" || e === "w1" ? t[e === "w0" ? 0 : 1] ?? "wild" : e;
}
var Se = (e, t = []) => e.map((e) => xe(e, t)).filter((e) => e !== null), N = (e, t = []) => Se(e, t).at(-1) ?? null, P = (e, t, n = []) => Se(e, n).filter((e) => e === t).length;
function F(e, t, n = []) {
	let r = ye[e], i = t.map(M), a = r.colors[0], o = t.map((e, t) => t), s = (e) => e.filter((e) => i[e] >= 3), c = (e) => S.some((r) => e.every((e) => N(t[e], n) === r)), l = (e, t = o) => e ? t : null;
	switch (r.kind) {
		case "cornersColor": return l(w.reduce((e, r) => e + P(t[r], a, n), 0) >= 4, w);
		case "mixed": {
			let e = o.filter((e) => r.colors.every((r) => P(t[e], r, n) >= 2));
			return e.length ? e : null;
		}
		case "singleColor": {
			let e = o.filter((e) => i[e] === 1 && N(t[e], n) === a);
			return l(e.length >= 3, e);
		}
		case "noColorTall": {
			let e = s(o).filter((e) => P(t[e], a, n) === 0);
			return l(e.length >= 3, e);
		}
		case "roomTall": {
			let e = s(C[r.room]);
			return l(e.length >= 3, e);
		}
		case "rowsCols": return l([
			0,
			1,
			2,
			3
		].every((e) => [
			0,
			1,
			2,
			3
		].some((t) => i[e * 4 + t] > 0) && [
			0,
			1,
			2,
			3
		].some((t) => i[t * 4 + e] > 0)));
		case "roomsNoColor": return l((r.room === 1 ? [...C[1], ...C[3]] : [...C[0], ...C[2]]).every((e) => P(t[e], a, n) === 0), []);
		case "rainbow": {
			let e = o.filter((e) => i[e] === 4 && S.every((r) => P(t[e], r, n) === 1));
			return e.length ? e : null;
		}
		case "centerEmpty": return l(T.every((e) => i[e] === 0), []);
		case "oneEmpty": return l(C.every((e) => e.filter((e) => i[e] === 0).length === 1));
		case "rowTops":
		case "colTops": {
			let e = [
				0,
				1,
				2,
				3
			].map((e) => [
				0,
				1,
				2,
				3
			].map((t) => r.kind === "rowTops" ? e * 4 + t : t * 4 + e)).filter(c).flat();
			return e.length ? e : null;
		}
		case "centerTops": {
			let e = T.filter((e) => N(t[e], n) === a);
			return l(e.length >= 3, e);
		}
		case "cornersEmpty": return l(w.every((e) => i[e] === 0), []);
		case "cornersTops": return l(c(w), w);
		case "roomTops": {
			let e = C.flatMap((e) => {
				let r = e.filter((e) => N(t[e], n) === a);
				return r.length >= 3 ? r : [];
			});
			return e.length ? e : null;
		}
		case "allTall": return l(i.every((e) => e === 0 || e >= 3));
		case "fourColor": {
			let e = o.filter((e) => P(t[e], a, n) >= 4);
			return e.length ? e : null;
		}
		case "cornerSingles": return l(w.every((e) => i[e] === 1), w);
		case "oneTall": return l(C.every((e) => s(e).length === 1), s(o));
		case "nightColor": return l(S.some((e) => P(t[1], e, n) >= 4), [1]);
		case "noSingles": return l(i.every((e) => e !== 1));
		case "roomSingles": {
			let e = C.filter((e) => e.every((e) => i[e] === 1)).flat();
			return e.length ? e : null;
		}
		case "centerTall": {
			let e = s(T);
			return l(e.length >= 3, e);
		}
		case "square": {
			let e = [
				0,
				1,
				4,
				5
			].flatMap((e) => {
				let t = [
					0,
					1,
					2,
					4,
					5,
					6,
					8,
					9,
					10
				].map((t) => t + e);
				return t.every((e) => i[e] > 0) ? t : [];
			});
			return e.length ? e : null;
		}
		case "six": {
			let e = o.filter((e) => i[e] === 6);
			return e.length ? e : null;
		}
		case "noTall": return l(i.every((e) => e < 3));
	}
}
var Ce = [
	[4, 2],
	[4, 2],
	[5, 3],
	[4, 2],
	[5, 3],
	[5, 3],
	[5, 3],
	[4, 2],
	[3, 1],
	[5, 3]
], we = [
	[],
	[],
	[],
	[],
	["b", "r"],
	["r", "y"],
	["r", "g"],
	["b", "y"],
	["b", "g"],
	["y", "g"],
	[],
	[],
	[],
	[]
], I = (e, t = {}) => ({
	place: e,
	...t
}), Te = [
	[
		I("cafe"),
		I("cafe"),
		I("library"),
		I("cafe", { random: 2 })
	],
	[
		I("library"),
		I("library", { random: 1 }),
		I("park"),
		I("bookstore", { rank: 1 })
	],
	[
		I("shop", { discard: !0 }),
		I("cafe", { dump: !0 }),
		I("bookstore", {
			rank: 1,
			random: 1
		}),
		I("bookstore", { rank: 2 })
	],
	[
		I("library"),
		I("park"),
		I("library", { random: 3 }),
		I("cafe", { random: 4 })
	],
	[
		I("park"),
		I("cafe", { random: 2 }),
		I("shop", {
			shop: 1,
			sun: !0
		}),
		I("shop", {
			shop: 2,
			sun: !0
		})
	],
	[
		I("cafe", { random: 2 }),
		I("bookstore", { rank: 1 }),
		I("bookstore", { rank: 2 }),
		I("bookstore", {
			rank: 2,
			sun: !0
		})
	],
	[
		I("cafe", { projects: [0] }),
		I("cafe", { projects: [2] }),
		I("cafe", {
			projects: [1, 0],
			sun: !0
		}),
		I("cafe", {
			projects: [
				0,
				1,
				2
			],
			sun: !0
		})
	],
	[
		I("bookstore", { rank: 1 }),
		I("park", { random: 1 }),
		I("bookstore", { rank: 2 }),
		I("bookstore", {
			rank: 2,
			sun: !0
		})
	],
	[
		I("cafe", { projects: [1] }),
		I("shop", {
			discard: !0,
			random: 3
		}),
		I("cafe", {
			random: 3,
			sun: !0
		}),
		I("shop", {
			discard: !0,
			random: 5,
			sun: !0
		})
	],
	[
		I("park"),
		I("library", { random: 2 }),
		I("bookstore", { rank: 2 }),
		I("bookstore", {
			rank: 2,
			sun: !0
		})
	],
	[
		I("bookstore", { rank: 1 }),
		I("park", { random: 2 }),
		I("cafe", { random: 4 }),
		I("library", { random: 5 })
	],
	[
		I("cafe", { random: 3 }),
		I("bookstore", { rank: 1 }),
		I("shop", { shop: 2 }),
		I("shop", { shop: 3 })
	],
	[
		I("park", { random: 3 }),
		I("bookstore", { rank: 2 }),
		I("cafe", { random: 6 }),
		I("library", { projects: [
			0,
			1,
			2
		] })
	],
	[
		I("park", { extraRival: !0 }),
		I("park", { random: 3 }),
		I("bookstore", {
			rank: 2,
			random: 2
		}),
		I("bookstore", {
			rank: 2,
			random: 4
		})
	]
], L = (e) => Array.from({ length: e }, (e, t) => t), R = () => L(16).map(() => []), z = (e) => new Set(e).size === e.length, B = (e) => e.players[e.turn], Ee = (e) => [
	"gather",
	"sort",
	"read",
	"rest",
	"admire",
	"leave"
].includes(e) ? `home:${e}` : e.startsWith("bookstore") ? "bookstore" : e === "gate" ? "home:leave" : e, De = (e) => ![
	"bookstore",
	"bookstore0",
	"bookstore1",
	"library",
	"shop",
	"exchange",
	"park",
	"gate"
].includes(e.pos), V = (e, t, n = {}) => ({
	kind: e,
	rid: t,
	cards: [],
	n: 0,
	id: -1,
	optional: !1,
	...n
}), H = (e, t, n, r = 0) => {
	e.log.push({
		rid: t,
		kind: n,
		n: r
	}), e.log = e.log.slice(-40);
}, U = (e, t, n, r) => e.fx.push({
	kind: n,
	rid: t,
	data: r
});
function W(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function Oe(t) {
	return t.bag.length ? t.bag.splice(e(t.seed, t.cursor++, t.bag.length), 1)[0] : null;
}
function ke(e, t) {
	return L(t).map(() => Oe(e)).filter((e) => e !== null);
}
function Ae(e) {
	return e.projects.length || (e.projects = W(e, e.projectDiscard), e.projectDiscard = []), e.projects.pop() ?? null;
}
function je(e) {
	return e.items.length || (e.items = W(e, e.itemDiscard), e.itemDiscard = []), e.items.pop() ?? null;
}
function G(e, t, n) {
	let r = t.energy;
	t.energy = Math.min(20, t.energy + n), e.admiring && t === B(e) && n > 0 && (e.admireEnergy += n, e.admireOverflow += n), U(e, t.rid, "energy", { n: t.energy - r });
}
function Me(e, t, n) {
	let r = 0;
	for (let i = 0; i < n; i++) {
		let n = Ae(e);
		n !== null && (t.hand.push(n), r++);
	}
	r && U(e, t.rid, "card", {
		from: "project-deck",
		to: `hand:${t.rid}`,
		n: r
	});
}
function Ne(e) {
	e.itemDiscard.push(...e.shop), e.shop = [];
	for (let t = 0; t < 2; t++) {
		let t = je(e);
		t !== null && (e.shop.push(t), U(e, B(e).rid, "card", {
			from: "item-deck",
			to: `item:${t}`,
			n: 1
		}));
	}
}
function Pe(e) {
	for (let [t, n] of e.shelves.entries()) {
		let r = Oe(e);
		r && (n.books.push(r), U(e, B(e).rid, "tile", {
			tile: r,
			from: "book-supply",
			to: `shelf:${t}`,
			index: n.books.length - 1
		}));
	}
}
function Fe(e) {
	return [
		0,
		1,
		2
	].sort((t, n) => e[t].books.length - e[n].books.length || t - n);
}
function Ie(e) {
	let t = [];
	for (let n = 0; n < 16; n++) for (let r = 0; r < 16; r++) {
		let i = Array(16).fill(0);
		i[n] += M(e.bag[0]), i[r] += M(e.bag[1]), i.every((t, n) => M(e.board[n]) + t <= 6) && t.push([n, r]);
	}
	return t;
}
function Le(e, t) {
	return [
		1,
		3,
		6
	][Fe(e).indexOf(t)];
}
function Re(e) {
	e.sun = Math.min(8, e.sun + 1), e.sun === 8 && e.endRound === null && (e.endRound = e.round + 1), U(e, B(e).rid, "sun", { n: e.sun });
}
function ze(e, t, n = 5) {
	t.hand.length > n && e.tasks.unshift(V("discard", t.rid, { n: t.hand.length - n }));
}
function Be(e, t, n) {
	n.length && e.tasks.unshift(V("pack", t.rid, { cards: n }));
}
function Ve(e, t, n) {
	if (n.length) {
		if (De(t)) for (let r = n.length - 1; r >= 0; r--) e.tasks.unshift(V("tile", t.rid, { cards: [n[r]] }));
		else Be(e, t, n);
	}
}
function He(e, t, n, r = "item-deck") {
	t.items.push(n), H(e, t.rid, "item", n), U(e, t.rid, "card", {
		from: r,
		to: `items:${t.rid}`,
		n: 1
	}), n in pe && e.tasks.unshift(V("kitty", t.rid, { id: n })), [
		13,
		16,
		20,
		27
	].includes(n) && Me(e, t, 2), (n === 14 || n === 19) && Ve(e, t, [n === 14 ? "w0" : "w1"]), (n === 4 || n === 40) && e.tasks.unshift(V("tile", t.rid, { cards: [n === 4 ? "lamp" : "ends"] })), (n === 30 || n === 33) && (G(e, t, 2), De(t) || (t.pos = "park")), n === 35 && e.tasks.unshift(V("wild", t.rid, {
		id: 35,
		n: 2
	}));
}
function Ue(e, t) {
	let n = je(e);
	n !== null && He(e, t, n);
}
function We(e, t) {
	if (!e.rival) return;
	let n = e.rival.queue.filter((e) => t.length ? we[e].some((e) => t.includes(e)) : we[e].length === 0);
	e.rival.queue = e.rival.queue.filter((e) => !n.includes(e)), e.rival.deck = W(e, [...e.rival.deck, ...n]), n.length && U(e, B(e).rid, "rivals", { n: n.length });
}
function Ge(e) {
	if (!e.rival) return null;
	let t = e.rival.deck.pop();
	return t === void 0 ? (e.rival.lost = !0, e.phase = "done", null) : (e.rival.queue.push(t), U(e, B(e).rid, "rivals", { n: 1 }), t);
}
function Ke(e, t, n) {
	for (let r of e.players) if (r.rid !== n && r.pos === t) {
		let t = Ee(r.pos);
		r.pos = "park", G(e, r, 2), r.items.includes(24) && (Me(e, r, 2), ze(e, r)), H(e, r.rid, "park"), U(e, r.rid, "walk", {
			from: t,
			to: "park"
		});
	}
	e.rival && n !== "penelope" && e.rival.pos === t && (e.rival.pos = "park", Ge(e));
}
function qe(e, t) {
	e.admiring = !0, e.admireEnergy = 0, e.admireOverflow = t.energy, e.bookendReady = !0, e.candleUsed = !1, e.wild = ["r", "r"], e.tasks.unshift(V("admire", t.rid));
	for (let n of [19, 14]) t.items.includes(n) && e.tasks.unshift(V("wild", t.rid, {
		id: n,
		n: n === 14 ? 0 : 1
	}));
}
function Je(e) {
	let t = e.tasks[0];
	if (t?.kind === "admire" && t.n === 0) {
		t.n = 1;
		let n = B(e), r = S.map((t) => n.board.reduce((n, r) => n + P(r, t, e.wild), 0));
		r[S.indexOf(O[n.mat])] === Math.max(...r) && G(e, n, 3), n.items.includes(30) && G(e, n, 1), n.items.includes(32) && n.board.filter((e) => M(e) > 0).length === 10 && G(e, n, 3);
		let i = n.board.map(M).filter((e) => e > 0);
		n.items.includes(45) && i.length && Math.max(...i) - Math.min(...i) <= 2 && G(e, n, 3);
	}
}
function Ye(e, t, n = [], r = 0) {
	let i = e.board.map(M), a = e.board.flat(), o = i.map((e, t) => e >= 3 ? t : -1).filter((e) => e >= 0);
	switch (t) {
		case 0: return e.items.length >= 4;
		case 1: return e.completed.length >= 6;
		case 2: return S.every((e) => P(a, e, n) >= 6);
		case 3: return M(e.board[1]) === 6 && S.some((t) => P(e.board[1], t, n) === 6);
		case 4: return o.filter((t) => S.some((r) => P(e.board[t], r, n) === i[t])).length >= 2;
		case 5: return i.every((e) => e > 0) && L(16).every((t) => (t % 4 == 3 || N(e.board[t], n) !== N(e.board[t + 1], n)) && (t >= 12 || N(e.board[t], n) !== N(e.board[t + 4], n)));
		case 6: return i.filter((e) => e === 6).length >= 3;
		case 7: return S.some((t) => e.board.filter((e) => N(e, n) === t).length >= 7);
		case 8: return r >= 24;
		case 9: {
			let t = C.map((t) => t.filter((e) => i[e] >= 3).map((t) => Se(e.board[t], n).sort().join(",")));
			return t[0].some((e) => t.slice(1).every((t) => t.includes(e)));
		}
		default: return !1;
	}
}
var Xe = (e) => [
	0,
	2,
	6,
	12,
	20
][Math.min(4, e)];
function Ze(e) {
	let t = e.board.map(M), n = [...e.board.flat(), ...e.bag.flat()], r = 0;
	for (let n of e.items) {
		if (E.includes(n) || D.includes(n)) continue;
		let i = he[n];
		n === 1 && (i = Math.min(7, t.filter((e) => e === 1).length)), n in pe && (i = Math.min(5, (C[e.cats[n]] ?? []).reduce((t, r) => t + P(e.board[r], pe[n]), 0))), n === 7 && (i += C.filter((e) => e.filter((e) => t[e] === 0).length >= 2).length), n === 10 && (i += Object.keys(e.majors).length), n === 27 && (i = e.hand.length), n === 29 && (i += new Set(Se(e.board[1])).size), n === 46 && (i += Math.min(6, t.filter((e) => e === 6).length * 2)), n === 48 && (i = e.items.length), r += i;
	}
	r += Xe(e.items.filter((e) => E.includes(e)).length) + Xe(e.items.filter((e) => D.includes(e)).length);
	let i = {
		books: n.filter(j).length,
		projects: e.completed.length * 2,
		items: r,
		majors: Object.values(e.majors).reduce((e, t) => e + t, 0),
		energy: Math.floor(e.energy / 4),
		total: 0
	};
	return i.total = i.books + i.projects + i.items + i.majors + i.energy, i;
}
var Qe = (e) => e.books + e.projects * 2 + e.items.reduce((e, t) => e + (he[t] || 3), 0);
function $e(e) {
	if (e.turnNo++, e.turn++, e.turn === e.players.length && (e.turn = 0, e.round++, e.endRound !== null && e.round > e.endRound)) {
		e.phase = "done";
		return;
	}
	e.step = "main", e.bonus = null, e.wild = [], e.admiring = !1, e.admireOverflow = 0, e.admireEnergy = 0;
}
function et(e) {
	let t = e.rival, n = Ge(e);
	if (n === null) return;
	t.last = n;
	let r = Te[n][t.queue.length <= 3 ? 0 : t.queue.length <= 5 ? 1 : t.queue.length <= 7 ? 2 : 3], i = Ee(t.pos);
	if (t.pos = r.place, Ke(e, r.place, "penelope"), e.phase === "done") return;
	let a = Fe(e.shelves);
	if (r.place === "park" && (Ge(e), r.extraRival && !t.lost && Ge(e)), r.place === "library" && (t.books += ke(e, 1).length, Pe(e)), r.place === "bookstore") {
		let n = e.shelves[a[r.rank ?? 1]];
		t.books += n.books.length, n.project !== null && t.projects++, n.books = [], n.project = Ae(e), Pe(e);
	}
	if (r.place === "shop") {
		if (r.discard) Ne(e);
		else {
			let n = r.shop ?? 0;
			for (let r = 0; r < Math.min(2, n); r++) {
				let n = e.shop.shift();
				n !== void 0 && t.items.push(n);
			}
			if (n > 2) {
				let n = je(e);
				n !== null && t.items.push(n);
			}
			Ne(e);
		}
	}
	if (r.dump) {
		let t = e.shelves[a[2]];
		e.bag.push(...t.books.filter((e) => S.includes(e))), t.project !== null && e.projectDiscard.push(t.project), t.books = [], t.project = Ae(e);
	}
	for (let n of r.projects ?? []) {
		let r = e.shelves[a[n]];
		r.project !== null && t.projects++, r.project = Ae(e);
	}
	r.random && (t.books += ke(e, r.random).length), r.sun && Re(e), H(e, "penelope", "rival", n), U(e, "penelope", "walk", {
		from: i,
		to: t.pos
	}), t.lost || (e.phase = "turn", $e(e));
}
function tt(e, t, n) {
	let r = {
		config: v.parse(e),
		players: [],
		phase: "draft",
		turn: 0,
		round: 1,
		turnNo: 0,
		sun: t.length <= 2 ? 3 : +(t.length === 3),
		endRound: null,
		step: "main",
		seed: n,
		cursor: 0,
		bag: S.flatMap((e) => L(32).map(() => e)),
		projects: [],
		projectDiscard: [],
		items: [],
		itemDiscard: [],
		shelves: [],
		shop: [],
		majors: [],
		tasks: [],
		drafted: [],
		wild: [],
		admireEnergy: 0,
		admireOverflow: 0,
		admiring: !1,
		bookendReady: !0,
		candleUsed: !1,
		bonus: null,
		rival: null,
		log: [],
		fx: []
	};
	r.projects = W(r, L(55)), r.items = W(r, L(49).filter((e) => (r.config.pins || !E.includes(e)) && (r.config.notes || e !== 10))), r.majors = W(r, L(10)).slice(0, 3);
	let i = W(r, L(4));
	t.forEach((e, t) => {
		let n = i[t], a = W(r, S.flatMap((e, t) => L(ge[n][t]).map(() => e))), o = R(), s = 0;
		_e[n].forEach((e, t) => {
			o[e] = a.slice(s, s + ve[n][t]), s += ve[n][t];
		});
		for (let e of a) r.bag.splice(r.bag.indexOf(e), 1);
		let c = {
			rid: e,
			mat: n,
			board: o,
			bag: [[], []],
			energy: 3 + t,
			pos: "home",
			items: [],
			used: [],
			cats: {},
			hand: [],
			completed: [],
			majors: {}
		};
		Me(r, c, 5), r.players.push(c);
	}), r.shelves = [
		3,
		2,
		1
	].map((e) => ({
		books: ke(r, e),
		project: Ae(r)
	})), Ne(r), t.length === 1 && (r.rival = {
		pos: "cafe",
		deck: W(r, L(10).map((e) => e + r.config.soloLevel - 1)),
		queue: [],
		books: 0,
		projects: 0,
		items: [],
		last: null,
		lost: !1
	});
	let a = r.fx;
	return r.fx = [], {
		state: r,
		fx: a
	};
}
function nt(e, t, { by: n }) {
	let r = { code: "games.aplaceforallmybooks.errAction" };
	if (e.phase === "done") return r;
	if (t.type === "tick") {
		if (n !== "$engine" || e.phase !== "rival") return r;
		let t = structuredClone(e);
		t.fx = [], et(t);
		let i = t.fx;
		return t.fx = [], {
			state: t,
			fx: i
		};
	}
	if (e.phase === "rival") return r;
	let i = structuredClone(e);
	i.fx = [];
	let a = i.players.find((e) => e.rid === n);
	if (!a) return r;
	if (i.phase === "draft") return t.type !== "draft" || i.drafted.includes(n) || !z(t.keep) || t.keep.some((e) => !a.hand.includes(e)) ? r : (i.projectDiscard.push(...a.hand.filter((e) => !t.keep.includes(e))), a.hand = t.keep, i.drafted.push(n), i.drafted.length === i.players.length && (i.phase = "turn"), { state: i });
	let o = i.tasks[0];
	if (n !== (o?.rid ?? B(i).rid)) return r;
	let s = !1;
	if (t.type === "claim" && n === B(i).rid && (!o || o.kind === "admire") && i.majors.includes(t.id) && a.majors[t.id] === void 0 && Ye(a, t.id, i.wild, i.admireOverflow)) {
		let e = a.items.includes(10), r = !i.players.some((e) => e.majors[t.id] !== void 0);
		if (a.majors[t.id] = Ce[t.id][+!r], H(i, n, "major", t.id), U(i, n, "claim", {
			from: `major:${t.id}`,
			to: `items:${n}`
		}), t.id === 3 || t.id === 8 ? Ue(i, a) : G(i, a, 3), e) for (let e of i.players) G(i, e, e === a ? 3 : 1);
		i.rival && i.tasks.unshift(V("remove", n)), s = !0;
	} else if (o) {
		let e = o, r = () => i.tasks.shift();
		if (t.type === "skip" && e.optional) r(), s = !0;
		else if (e.kind === "discard" && t.type === "discard" && t.ids.length === e.n && z(t.ids) && t.ids.every((e) => a.hand.includes(e))) r(), a.hand = a.hand.filter((e) => !t.ids.includes(e)), i.projectDiscard.push(...t.ids), U(i, n, "card", {
			from: `hand:${n}`,
			to: "project-discard",
			n: t.ids.length
		}), s = !0;
		else if (e.kind === "record" && t.type === "discard" && z(t.ids) && t.ids.every((e) => a.hand.includes(e))) r(), a.hand = a.hand.filter((e) => !t.ids.includes(e)), i.projectDiscard.push(...t.ids), Me(i, a, Math.max(0, 5 - a.hand.length)), s = !0;
		else if (e.kind === "gather" && t.type === "gather") {
			let e = t.sources.map((e) => `${e.cell}:${e.token}`);
			if (new Set(e).size === e.length && t.sources.filter((e) => e.token === "book").length <= 6) {
				let e = [], o = !0;
				for (let n of t.sources) {
					let t = a.board[n.cell], r = n.token === "book" ? be(t) : t.indexOf(n.token);
					if (r < 0) {
						o = !1;
						break;
					}
					e.push(t.splice(r, 1)[0]);
				}
				if (o && M(a.board[t.to]) + M(e) <= 6) {
					r(), a.board[t.to].push(...e);
					for (let r = 0; r < e.length; r++) U(i, n, "tile", {
						tile: e[r],
						from: `cell:${n}:${t.sources[r].cell}`,
						to: `cell:${n}:${t.to}`,
						index: a.board[t.to].length - e.length + r
					});
					i.bonus = 37, s = !0;
				}
			}
		} else if ((e.kind === "sort" || e.kind === "succulents") && t.type === "sort") {
			let o = a.board[t.from], c = t.moves.map((e) => e.index), l = Array(16).fill(0);
			for (let e of t.moves) j(o[e.index]) && l[e.to]++;
			let u = e.kind === "succulents" || t.moves.length === o.length, d = e.kind !== "succulents" || new Set(t.moves.map((e) => e.to)).size <= 1;
			if (u && d && z(c) && c.every((e) => e < o.length) && l.every((t) => e.kind === "succulents" || t <= 2)) {
				let u = t.moves.map((e) => ({
					tile: o[e.index],
					to: e.to
				}));
				if (a.board[t.from] = o.filter((e, t) => !c.includes(t)), l.every((e, t) => M(a.board[t]) + e <= 6)) {
					r();
					for (let e of u) a.board[e.to].push(e.tile), U(i, n, "tile", {
						tile: e.tile,
						from: `cell:${n}:${t.from}`,
						to: `cell:${n}:${e.to}`,
						index: a.board[e.to].length - 1
					});
					i.bonus = e.kind === "sort" ? 38 : null, s = !0;
				}
			}
		} else if (e.kind === "read" && t.type === "read") {
			let e = a.board[t.from], o = e[t.index];
			if (o !== void 0 && j(o) && (t.from === 1 || M(a.board[1]) < 6)) {
				r();
				let c = e.includes("lamp");
				e.splice(t.index, 1), a.board[1].push(o), U(i, n, "tile", {
					tile: o,
					from: `cell:${n}:${t.from}`,
					to: `cell:${n}:1`,
					index: a.board[1].length - 1
				}), c && (G(i, a, 1), Me(i, a, 1)), a.items.includes(9) && i.tasks.unshift(V("puzzle", n, { optional: !0 })), s = !0;
			}
		} else if (e.kind === "puzzle" && t.type === "project" && a.hand.includes(t.id)) r(), a.hand.splice(a.hand.indexOf(t.id), 1), a.completed.push(t.id), U(i, n, "card", {
			from: `project:${n}:${t.id}`,
			to: `completed:${n}`,
			n: 1
		}), H(i, n, "puzzle", t.id), s = !0;
		else if (e.kind === "library" && t.type === "selectBooks" && z(t.indices) && t.indices.length === e.n && t.indices.every((t) => t < e.cards.length)) {
			r();
			let o = t.indices.map((t) => e.cards[t]), c = W(i, e.cards.filter((e, n) => !t.indices.includes(n)));
			i.shelves.forEach((e, t) => {
				c[t] && (e.books.push(c[t]), U(i, n, "tile", {
					tile: c[t],
					from: "book-supply",
					to: `shelf:${t}`,
					index: e.books.length - 1
				}));
			}), Be(i, a, o), s = !0;
		} else if (e.kind === "pack" && t.type === "pack") {
			let o = t.piles.flat(), c = a.bag.reduce((e, t) => e + 6 - M(t), 0);
			if (z(o) && o.every((t) => t < e.cards.length) && o.length === Math.min(c, e.cards.length) && t.piles.every((e, t) => M(a.bag[t]) + e.length <= 6)) {
				r();
				for (let r = 0; r < 2; r++) for (let o of t.piles[r]) a.bag[r].push(e.cards[o]), U(i, n, "tile", {
					tile: e.cards[o],
					from: `pool:${o}`,
					to: `bag:${n}:${r}`,
					index: a.bag[r].length - 1
				});
				for (let t = 0; t < e.cards.length; t++) if (!o.includes(t)) {
					let n = e.cards[t];
					S.includes(n) && i.bag.push(n);
				}
				s = !0;
			}
		} else if (e.kind === "unload" && t.type === "unload") {
			let e = Array(16).fill(0);
			if (a.bag.forEach((n, r) => e[t.cells[r]] += M(n)), e.every((e, t) => M(a.board[t]) + e <= 6)) {
				r();
				for (let e = 0; e < 2; e++) a.board[t.cells[e]].push(...a.bag[e]), a.bag[e].forEach((r, o) => U(i, n, "tile", {
					tile: r,
					from: `bag:${n}:${e}`,
					to: `cell:${n}:${t.cells[e]}`,
					index: a.board[t.cells[e]].length - a.bag[e].length + o
				})), a.bag[e] = [];
				s = !0;
			}
		} else if (e.kind === "exchange" && t.type === "exchange" && z(t.indices) && t.indices.every((e) => a.board[1][e] !== void 0 && S.includes(a.board[1][e]))) {
			let e = t.indices.map((e) => a.board[1][e]), o = e.length + 1 + +!!a.items.includes(33), c = [...i.bag, ...e];
			if (t.colors.length === Math.min(o, c.length) && S.every((e) => t.colors.filter((t) => t === e).length <= c.filter((t) => t === e).length)) {
				r(), a.board[1] = a.board[1].filter((e, n) => !t.indices.includes(n)), i.bag.push(...e);
				for (let e of t.colors) i.bag.splice(i.bag.indexOf(e), 1);
				let o = a.items.includes(36) ? ke(i, new Set(e).size) : [];
				Be(i, a, [...t.colors, ...o]), e.forEach((e, t) => U(i, n, "tile", {
					tile: e,
					from: `cell:${n}:1`,
					to: "book-supply",
					index: t
				})), s = !0;
			}
		} else if (e.kind === "tile" && t.type === "placeTile" && (!j(e.cards[0]) || M(a.board[t.cell]) < 6)) r(), a.board[t.cell].push(e.cards[0]), U(i, n, "tile", {
			tile: e.cards[0],
			from: "item-deck",
			to: `cell:${n}:${t.cell}`,
			index: a.board[t.cell].length - 1
		}), s = !0;
		else if (e.kind === "kitty" && t.type === "kitty") r(), a.cats[e.id] = t.room, s = !0;
		else if (e.kind === "wild" && t.type === "chooseColor") {
			if (e.id === 35) {
				let e = i.bag.filter((e) => e === t.color);
				if (e.length || !i.bag.length) {
					r();
					let t = e.slice(0, 2);
					for (let e of t) i.bag.splice(i.bag.indexOf(e), 1);
					Ve(i, a, t), s = !0;
				}
			} else r(), i.wild[e.n] = t.color, s = !0;
		} else if (e.kind === "admire") {
			if (t.type === "project" && a.hand.includes(t.id)) {
				let e = F(t.id, a.board, i.wild);
				e && (a.hand.splice(a.hand.indexOf(t.id), 1), a.completed.push(t.id), H(i, n, "project", t.id), U(i, n, "card", {
					from: `project:${n}:${t.id}`,
					to: `completed:${n}`,
					n: 1
				}), We(i, ye[t.id].colors), i.bookendReady && e.some((e) => a.board[e].includes("ends")) && (i.bookendReady = !1, G(i, a, 2)), ye[t.id].reward === "energy" ? G(i, a, 3) : Ue(i, a), s = !0);
			} else t.type === "candle" && a.items.includes(47) && !i.candleUsed && z(t.ids) && t.ids.every((e) => a.hand.includes(e) && F(e, a.board, i.wild) === null) ? (i.candleUsed = !0, a.hand = a.hand.filter((e) => !t.ids.includes(e)), i.projectDiscard.push(...t.ids), t.reward === "energy" ? G(i, a, 3) : Me(i, a, 2), s = !0) : t.type === "finishAdmire" && (r(), a.items.includes(34) && a.hand.length === 0 && G(i, a, 3), i.admiring = !1, s = !0);
		} else if ((e.kind === "laptop" || e.kind === "snowglobe") && t.type === "takeItem") {
			let n = e.kind === "laptop" ? i.itemDiscard : i.shop, o = n.indexOf(t.id);
			o >= 0 && (r(), n.splice(o, 1), He(i, a, t.id, e.kind === "laptop" ? "item-discard" : "shop"), e.kind === "snowglobe" && Ne(i), s = !0);
		} else e.kind === "remove" && t.type === "removeRivals" && (r(), We(i, t.color === "none" ? [] : [t.color]), s = !0);
	} else if (n === B(i).rid) {
		if (t.type === "flip" && a.items.includes(t.id) && me.includes(t.id) && !a.used.includes(t.id)) a.used.push(t.id), U(i, n, "flip", { id: t.id }), t.id === 11 && G(i, a, 4), t.id === 21 && qe(i, a), t.id === 22 && i.tasks.unshift(V("laptop", n, { optional: !0 })), t.id === 23 && i.tasks.unshift(V("succulents", n, { optional: !0 })), t.id === 28 && i.tasks.unshift(V("record", n)), t.id === 39 && i.tasks.unshift(V("snowglobe", n, { optional: !0 })), s = !0;
		else if (t.type === "bonus" && t.id === i.bonus && a.items.includes(t.id) && t.discard !== void 0 && a.hand.includes(t.discard)) a.hand.splice(a.hand.indexOf(t.discard), 1), i.projectDiscard.push(t.discard), i.bonus = null, i.tasks.unshift(V(t.id === 37 ? "sort" : "gather", n)), s = !0;
		else if (t.type === "home" && i.step !== "after" && De(a) && t.action !== a.pos) {
			if (t.action === "leave") a.energy >= 6 && (a.energy -= 5, a.pos = "gate", i.step = "village", Re(i), s = !0);
			else {
				let e = Ee(a.pos);
				a.pos = t.action, i.step = "after", i.bonus = null, U(i, n, "walk", {
					from: e,
					to: `home:${t.action}`
				}), (t.action === "gather" || t.action === "sort") && (G(i, a, 1), i.tasks.unshift(V(t.action, n))), t.action === "read" && (G(i, a, 2), i.tasks.unshift(V("read", n))), t.action === "rest" && (G(i, a, 2 + (a.items.includes(31) ? 3 : 0)), Me(i, a, 2 + +!!a.items.includes(20)), ze(i, a)), t.action === "admire" && qe(i, a), H(i, n, t.action), s = !0;
			}
		} else if (t.type === "village" && i.step !== "after" && !De(a) && t.place !== a.pos && !(t.place === "bookstore" && a.pos.startsWith("bookstore"))) {
			let e = 0, r = !0, o = t.place;
			if (t.place === "bookstore") {
				let n = t.shelf ?? -1;
				if (r = n >= 0, r && (e = Le(i.shelves, n), i.players.length === 4)) {
					let e = t.side ?? -1;
					r = e >= 0 && (e === 0 ? n !== 2 : n !== 0), o = `bookstore${e}`;
				}
			} else if (t.place === "library") e = i.players.length === 4 ? 2 : 1;
			else if (t.place === "exchange") e = 1;
			else {
				let n = t.items ?? [];
				r = t.blind ? !n.length : z(n) && n.length >= 1 && n.length <= 2 && n.every((e) => i.shop.includes(e)), e = (t.blind ? 3 : n.length === 2 ? 9 : 4) - !!a.items.includes(16);
			}
			if (r && a.energy >= e) {
				let r = Ee(a.pos);
				if (a.energy -= e, a.pos = o, i.step = "after", i.bonus = null, Ke(i, o, n), U(i, n, "walk", {
					from: r,
					to: Ee(o)
				}), t.place === "bookstore") {
					let e = i.shelves[t.shelf];
					e.project !== null && a.hand.push(e.project), Be(i, a, e.books), e.books = [], e.project = Ae(i), Pe(i);
				}
				if (t.place === "library") {
					let e = +!!a.items.includes(13), t = ke(i, (i.players.length === 4 ? 5 : 4) + e);
					i.tasks.unshift(V("library", n, {
						cards: t,
						n: Math.min(t.length, (i.players.length === 4 ? 2 : 1) + e)
					}));
				}
				if (t.place === "exchange" && i.tasks.unshift(V("exchange", n)), t.place === "shop") {
					if (t.blind) Ue(i, a);
					else {
						for (let e of t.items) i.shop.splice(i.shop.indexOf(e), 1), He(i, a, e, "shop");
						Ne(i);
					}
				}
				H(i, n, t.place), s = !0;
			}
		} else if (t.type === "return" && i.step === "main" && !De(a)) {
			if (Ie(a).length > 0) {
				let e = Ee(a.pos);
				a.pos = "home", i.step = "home", i.tasks.unshift(V("unload", n)), U(i, n, "walk", {
					from: e,
					to: "home"
				}), s = !0;
			}
		} else t.type === "end" && i.step === "after" && (i.wild = [], i.rival ? i.phase = "rival" : $e(i), s = !0);
	}
	if (!s) return r;
	Je(i), i.phase === "done" && (i.tasks = []);
	for (let e of i.fx.slice(1)) e.with = !0;
	let c = i.fx;
	return i.fx = [], {
		state: i,
		fx: c
	};
}
function rt(e, t) {
	let n = e.players.find((e) => e.rid === t), r = e.tasks[0] ?? null;
	return {
		public: {
			config: e.config,
			phase: e.phase,
			turn: B(e).rid,
			actor: r?.rid ?? B(e).rid,
			round: e.round,
			turnNo: e.turnNo,
			sun: e.sun,
			endRound: e.endRound,
			step: e.step,
			players: e.players.map((e) => ({
				rid: e.rid,
				mat: e.mat,
				board: e.board,
				bag: e.bag,
				energy: e.energy,
				pos: e.pos,
				items: e.items,
				used: e.used,
				cats: e.cats,
				completed: e.completed.length,
				handCount: e.hand.length,
				majors: e.majors,
				score: Ze(e)
			})),
			shelves: e.shelves,
			shop: e.shop,
			itemDiscard: e.itemDiscard,
			projectDiscard: e.projectDiscard,
			majors: e.majors,
			bagCount: e.bag.length,
			supply: Object.fromEntries(S.map((t) => [t, e.bag.filter((e) => e === t).length])),
			task: r,
			drafted: e.drafted,
			wild: e.wild,
			admireEnergy: e.admireEnergy,
			admireOverflow: e.admireOverflow,
			bookendReady: e.bookendReady,
			candleUsed: e.candleUsed,
			bonus: e.bonus,
			rival: e.rival ? {
				pos: e.rival.pos,
				deckCount: e.rival.deck.length,
				queue: e.rival.queue,
				books: e.rival.books,
				projects: e.rival.projects,
				items: e.rival.items,
				score: Qe(e.rival),
				last: e.rival.last,
				lost: e.rival.lost
			} : null,
			log: e.log
		},
		private: n ? {
			hand: n.hand,
			completed: n.completed,
			task: r?.rid === t ? r : null
		} : void 0
	};
}
function it(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = Object.fromEntries(e.players.map((e) => [e.rid, Ze(e).total])), n = e.players.map((e) => e.rid).sort((n, r) => t[r] - t[n] || Ze(e.players.find((e) => e.rid === r)).books - Ze(e.players.find((e) => e.rid === n)).books), r = n.filter((r) => t[r] === t[n[0]] && Ze(e.players.find((e) => e.rid === r)).books === Ze(e.players.find((e) => e.rid === n[0])).books);
	return e.rival && (e.rival.lost || t[n[0]] < Qe(e.rival)) && (r = []), {
		phase: "done",
		scores: t,
		ranking: n,
		winner: r
	};
}
var at = {
	meta: oe,
	saveCompatibility: { version: "1" },
	schemas: {
		action: le,
		publicView: de,
		privateView: fe,
		config: v
	},
	setup: tt,
	reduce: nt,
	viewFor: rt,
	status: it,
	nextTickIn: (e) => e.phase === "rival" ? 560 : null
}, ot = {
	r: "#c84854",
	y: "#f5d64a",
	b: "#58b7d5",
	g: "#75a862"
};
function K({ name: e, children: t, className: n = "", style: r }) {
	let { ref: i, hidden: a } = c(e);
	return /* @__PURE__ */ u("div", {
		ref: i,
		className: n,
		style: {
			...r,
			visibility: a ? "hidden" : void 0
		},
		children: t
	});
}
function st() {
	return /* @__PURE__ */ u("svg", {
		className: "apb-ants",
		"aria-hidden": "true",
		children: /* @__PURE__ */ u("rect", {
			x: "2",
			y: "2",
			rx: "8"
		})
	});
}
function q({ tile: e }) {
	if (e === "lamp") return /* @__PURE__ */ d("svg", {
		viewBox: "0 0 60 72",
		className: "apb-book",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ u("ellipse", {
				cx: "30",
				cy: "65",
				rx: "17",
				ry: "4",
				fill: "#ac805b",
				stroke: "#765447",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ u("path", {
				d: "M27 61V35q0-6-6-9l3-5q9 4 9 13v27z",
				fill: "#c99d67",
				stroke: "#795c49",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ u("path", {
				d: "M8 18 14 8h34l7 10q-21 5-47 0z",
				fill: "#73975a",
				stroke: "#6c5843",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ u("path", {
				d: "M9 19q23 5 45 0l-3 4H12z",
				fill: "#eee0a6",
				stroke: "#9e7a50",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ u("path", {
				d: "M45 23v15",
				stroke: "#ac8753",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ u("circle", {
				cx: "45",
				cy: "40",
				r: "2",
				fill: "#ab7d4f"
			}),
			/* @__PURE__ */ u("path", {
				d: "M18 11h26",
				stroke: "#abc37c",
				strokeWidth: "2"
			})
		]
	});
	if (e === "ends") return /* @__PURE__ */ d("svg", {
		viewBox: "0 0 60 72",
		className: "apb-book",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ u("path", {
			d: "M7 14q20-12 21 9v43H6zM34 23q1-20 20-10v52H34z",
			fill: "#b29074",
			stroke: "#755650",
			strokeWidth: "2"
		}), /* @__PURE__ */ u("path", {
			d: "m10 26 8-9 6 9-6 10zM10 47l8-9 6 9-6 10zM39 25l8-9 4 9-4 10zM39 46l8-9 4 9-4 10z",
			fill: "none",
			stroke: "#8f6665",
			strokeWidth: "1.5"
		})]
	});
	let t = e.startsWith("w") ? "#a67fbc" : ot[e];
	return /* @__PURE__ */ d("svg", {
		viewBox: "0 0 60 76",
		className: "apb-book",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ u("path", {
				d: "M7 4h47v65H8q-4 0-4-4V8q0-4 3-4",
				fill: "#eee6c8",
				stroke: "#765b51",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ u("path", {
				d: "M7 4h44v61H7z",
				fill: t,
				stroke: "#f5e5a5",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ u("path", {
				d: "M11 8h35v53H11z",
				fill: "none",
				stroke: "#ebd99b",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ u("path", {
				d: "M8 69h45M8 72h43M7 4v61",
				stroke: "#b7a782",
				strokeWidth: "1"
			}),
			e === "r" ? /* @__PURE__ */ u("path", {
				d: "m28 13 13 21-13 21-13-21zM16 12l25 44M41 12 16 56",
				fill: "none",
				stroke: "#f2d98b",
				strokeWidth: "1.2"
			}) : e === "y" ? /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("rect", {
				x: "16",
				y: "14",
				width: "24",
				height: "41",
				rx: "1",
				fill: "none",
				stroke: "#bca433",
				strokeWidth: "1.5"
			}), /* @__PURE__ */ u("rect", {
				x: "19",
				y: "17",
				width: "18",
				height: "35",
				fill: "none",
				stroke: "#fff0a0"
			})] }) : e === "g" ? /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("ellipse", {
				cx: "28",
				cy: "34",
				rx: "13",
				ry: "22",
				fill: "none",
				stroke: "#e9db91",
				strokeWidth: "1.4"
			}), /* @__PURE__ */ u("path", {
				d: "M14 13q14 10 28 0M14 55q14-10 28 0",
				fill: "none",
				stroke: "#d8cb83"
			})] }) : e === "b" ? /* @__PURE__ */ u("path", {
				d: "M28 12q-9 0-9 7-9 0-6 10-2 6 6 9-1 12 9 17 11-5 10-17 8-3 6-9 3-10-6-10 0-7-10-7z",
				fill: "none",
				stroke: "#eedb90",
				strokeWidth: "1.5"
			}) : /* @__PURE__ */ u("path", {
				d: "m28 15 4 12 12 4-12 4-4 16-4-16-12-4 12-4z",
				fill: "#eadca4"
			})
		]
	});
}
function J({ n: e, arrow: t = !1 }) {
	return /* @__PURE__ */ d("span", {
		className: "apb-resource",
		children: [/* @__PURE__ */ d("svg", {
			viewBox: "0 0 48 43",
			"aria-hidden": !0,
			children: [/* @__PURE__ */ u("path", {
				d: "M24 4c12 0 20 8 20 17S37 39 24 39 4 31 4 21 12 4 24 4",
				fill: "#91b945",
				stroke: "#456f31",
				strokeWidth: "2"
			}), t && /* @__PURE__ */ u("path", {
				d: "M35 18V9h-5l8-8 8 8h-5v9",
				fill: "#9b91ce",
				stroke: "#514e75",
				strokeWidth: "1.3"
			})]
		}), e !== void 0 && /* @__PURE__ */ u("b", { children: e })]
	});
}
function Y({ n: e }) {
	return /* @__PURE__ */ d("span", {
		className: "apb-resource apb-star",
		children: [/* @__PURE__ */ u("svg", {
			viewBox: "0 0 48 45",
			"aria-hidden": !0,
			children: /* @__PURE__ */ u("path", {
				d: "m24 3 7 12 14 3-10 10 1 14-12-6-13 6 2-14L3 18l14-3z",
				fill: "#fff4b0",
				stroke: "#e9b429",
				strokeWidth: "3",
				strokeLinejoin: "round"
			})
		}), e !== void 0 && /* @__PURE__ */ u("b", { children: e })]
	});
}
function ct() {
	return /* @__PURE__ */ d("svg", {
		viewBox: "0 0 48 48",
		className: "apb-icon",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ u("path", {
			d: "m10 15-4 28h35l-3-28z",
			fill: "#9cc7e6",
			stroke: "#35648d",
			strokeWidth: "2"
		}), /* @__PURE__ */ u("path", {
			d: "M16 19V9q9-13 16 0v10",
			fill: "none",
			stroke: "#35648d",
			strokeWidth: "3"
		})]
	});
}
function lt() {
	return /* @__PURE__ */ d("svg", {
		viewBox: "0 0 48 48",
		className: "apb-icon",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ u("rect", {
				x: "6",
				y: "8",
				width: "27",
				height: "35",
				fill: "#f8edd6",
				stroke: "#967f69",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ u("rect", {
				x: "14",
				y: "4",
				width: "27",
				height: "35",
				fill: "#fffaed",
				stroke: "#967f69",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ u("path", {
				d: "M20 10v21h8V10z",
				fill: "#c65d6a"
			}),
			/* @__PURE__ */ u("path", {
				d: "M28 14v17h8V14z",
				fill: "#6ea97a"
			}),
			/* @__PURE__ */ u("path", {
				d: "M22 34h12",
				stroke: "#bca780"
			})
		]
	});
}
function ut() {
	return /* @__PURE__ */ d("div", {
		className: "apb-cardback",
		children: [/* @__PURE__ */ u(lt, {}), /* @__PURE__ */ d("span", { children: [
			"A Place for",
			/* @__PURE__ */ u("br", {}),
			"All My Books"
		] })]
	});
}
function dt({ id: e }) {
	return /* @__PURE__ */ u("img", {
		className: "apb-item-art",
		src: s(`games/aplaceforallmybooks/item-${e}.webp`),
		alt: "",
		draggable: !1
	});
}
function ft({ id: e }) {
	let t = ye[e], n = [];
	t.kind.startsWith("corner") ? n = w : t.kind.startsWith("center") ? n = T : t.room === void 0 ? t.kind === "nightColor" ? n = [1] : t.kind === "square" && (n = [
		0,
		1,
		2,
		4,
		5,
		6,
		8,
		9,
		10
	]) : n = t.kind === "roomsNoColor" ? t.room === 1 ? [...C[1], ...C[3]] : [...C[0], ...C[2]] : C[t.room];
	let r = t.kind === "cornersEmpty" || t.kind === "centerEmpty" || t.kind === "roomsNoColor";
	return /* @__PURE__ */ d("svg", {
		viewBox: "0 0 100 100",
		className: "apb-diagram",
		"aria-hidden": !0,
		children: [Array.from({ length: 16 }, (e, i) => {
			let a = C.findIndex((e) => e.includes(i));
			return /* @__PURE__ */ d("g", { children: [
				/* @__PURE__ */ u("rect", {
					x: 4 + i % 4 * 24,
					y: 4 + Math.floor(i / 4) * 24,
					width: "21",
					height: "21",
					rx: "1",
					fill: n.includes(i) ? "#f6e5a9" : "#f4efe4",
					stroke: [
						"#60a99e",
						"#c75b92",
						"#9e6698",
						"#db9a57"
					][a],
					strokeWidth: "2"
				}),
				n.includes(i) && r && /* @__PURE__ */ u("path", {
					d: `M${8 + i % 4 * 24} ${8 + Math.floor(i / 4) * 24}l13 13m0-13-13 13`,
					stroke: "#9e8d78",
					strokeWidth: "1.4"
				}),
				n.includes(i) && !r && /* @__PURE__ */ u("circle", {
					cx: 14 + i % 4 * 24,
					cy: 14 + Math.floor(i / 4) * 24,
					r: "6",
					fill: t.colors[0] ? ot[t.colors[0]] : "#8a7253"
				})
			] }, i);
		}), !n.length && t.colors.map((e, t) => /* @__PURE__ */ u("rect", {
			x: 20 + t * 27,
			y: "27",
			width: "22",
			height: "42",
			fill: ot[e],
			stroke: "#e8cc7e",
			strokeWidth: "2"
		}, e))]
	});
}
function pt({ colors: e }) {
	return /* @__PURE__ */ u("span", {
		className: "apb-chips",
		children: e.map((e, t) => /* @__PURE__ */ u("span", {
			style: { background: ot[e] },
			title: e
		}, `${e}${t}`))
	});
}
//#endregion
//#region src/games/aplaceforallmybooks/keys.ts
var mt = {
	name: "games.aplaceforallmybooks.name",
	desc: "games.aplaceforallmybooks.desc",
	errAction: "games.aplaceforallmybooks.errAction",
	gather: "games.aplaceforallmybooks.gather",
	sort: "games.aplaceforallmybooks.sort",
	read: "games.aplaceforallmybooks.read",
	rest: "games.aplaceforallmybooks.rest",
	admire: "games.aplaceforallmybooks.admire",
	leave: "games.aplaceforallmybooks.leave",
	bookstore: "games.aplaceforallmybooks.bookstore",
	library: "games.aplaceforallmybooks.library",
	shop: "games.aplaceforallmybooks.shop",
	exchange: "games.aplaceforallmybooks.exchange",
	park: "games.aplaceforallmybooks.park",
	home: "games.aplaceforallmybooks.home",
	cafe: "games.aplaceforallmybooks.cafe",
	bedroom: "games.aplaceforallmybooks.bedroom",
	den: "games.aplaceforallmybooks.den",
	bath: "games.aplaceforallmybooks.bath",
	kitchen: "games.aplaceforallmybooks.kitchen",
	nightstand: "games.aplaceforallmybooks.nightstand",
	r: "games.aplaceforallmybooks.r",
	y: "games.aplaceforallmybooks.y",
	b: "games.aplaceforallmybooks.b",
	g: "games.aplaceforallmybooks.g",
	wild: "games.aplaceforallmybooks.wild",
	lamp: "games.aplaceforallmybooks.lamp",
	ends: "games.aplaceforallmybooks.ends",
	round: "games.aplaceforallmybooks.round",
	sun: "games.aplaceforallmybooks.sun",
	finalRound: "games.aplaceforallmybooks.finalRound",
	turn: "games.aplaceforallmybooks.turn",
	waiting: "games.aplaceforallmybooks.waiting",
	battery: "games.aplaceforallmybooks.battery",
	energy: "games.aplaceforallmybooks.energy",
	points: "games.aplaceforallmybooks.points",
	books: "games.aplaceforallmybooks.books",
	projects: "games.aplaceforallmybooks.projects",
	items: "games.aplaceforallmybooks.items",
	majors: "games.aplaceforallmybooks.majors",
	backpack: "games.aplaceforallmybooks.backpack",
	collection: "games.aplaceforallmybooks.collection",
	village: "games.aplaceforallmybooks.village",
	draftPrompt: "games.aplaceforallmybooks.draftPrompt",
	confirmDraft: "games.aplaceforallmybooks.confirmDraft",
	gatherPrompt: "games.aplaceforallmybooks.gatherPrompt",
	sortPrompt: "games.aplaceforallmybooks.sortPrompt",
	readPrompt: "games.aplaceforallmybooks.readPrompt",
	discardPrompt: "games.aplaceforallmybooks.discardPrompt",
	libraryPrompt: "games.aplaceforallmybooks.libraryPrompt",
	packPrompt: "games.aplaceforallmybooks.packPrompt",
	unloadPrompt: "games.aplaceforallmybooks.unloadPrompt",
	exchangePrompt: "games.aplaceforallmybooks.exchangePrompt",
	tilePrompt: "games.aplaceforallmybooks.tilePrompt",
	kittyPrompt: "games.aplaceforallmybooks.kittyPrompt",
	wildPrompt: "games.aplaceforallmybooks.wildPrompt",
	shelfPrompt: "games.aplaceforallmybooks.shelfPrompt",
	admirePrompt: "games.aplaceforallmybooks.admirePrompt",
	puzzlePrompt: "games.aplaceforallmybooks.puzzlePrompt",
	succulentsPrompt: "games.aplaceforallmybooks.succulentsPrompt",
	recordPrompt: "games.aplaceforallmybooks.recordPrompt",
	laptopPrompt: "games.aplaceforallmybooks.laptopPrompt",
	snowglobePrompt: "games.aplaceforallmybooks.snowglobePrompt",
	removePrompt: "games.aplaceforallmybooks.removePrompt",
	rivalPrompt: "games.aplaceforallmybooks.rivalPrompt",
	afterPrompt: "games.aplaceforallmybooks.afterPrompt",
	mainPrompt: "games.aplaceforallmybooks.mainPrompt",
	confirm: "games.aplaceforallmybooks.confirm",
	cancel: "games.aplaceforallmybooks.cancel",
	close: "games.aplaceforallmybooks.close",
	skip: "games.aplaceforallmybooks.skip",
	end: "games.aplaceforallmybooks.end",
	finishAdmire: "games.aplaceforallmybooks.finishAdmire",
	return: "games.aplaceforallmybooks.return",
	none: "games.aplaceforallmybooks.none",
	use: "games.aplaceforallmybooks.use",
	used: "games.aplaceforallmybooks.used",
	details: "games.aplaceforallmybooks.details",
	claim: "games.aplaceforallmybooks.claim",
	completed: "games.aplaceforallmybooks.completed",
	handCount: "games.aplaceforallmybooks.handCount",
	cost: "games.aplaceforallmybooks.cost",
	gain: "games.aplaceforallmybooks.gain",
	rewardItem: "games.aplaceforallmybooks.rewardItem",
	scoreTwo: "games.aplaceforallmybooks.scoreTwo",
	shelf: "games.aplaceforallmybooks.shelf",
	buy: "games.aplaceforallmybooks.buy",
	buyBoth: "games.aplaceforallmybooks.buyBoth",
	blind: "games.aplaceforallmybooks.blind",
	viewApartment: "games.aplaceforallmybooks.viewApartment",
	cell: "games.aplaceforallmybooks.cell",
	chooseBook: "games.aplaceforallmybooks.chooseBook",
	moveTo: "games.aplaceforallmybooks.moveTo",
	selected: "games.aplaceforallmybooks.selected",
	ready: "games.aplaceforallmybooks.ready",
	notReady: "games.aplaceforallmybooks.notReady",
	drawPile: "games.aplaceforallmybooks.drawPile",
	discardPile: "games.aplaceforallmybooks.discardPile",
	empty: "games.aplaceforallmybooks.empty",
	inspect: "games.aplaceforallmybooks.inspect",
	topBook: "games.aplaceforallmybooks.topBook",
	to: "games.aplaceforallmybooks.to",
	nextBook: "games.aplaceforallmybooks.nextBook",
	chosenDestination: "games.aplaceforallmybooks.chosenDestination",
	prefer: "games.aplaceforallmybooks.prefer",
	majorReward: "games.aplaceforallmybooks.majorReward",
	majorEnergy: "games.aplaceforallmybooks.majorEnergy",
	majorItem: "games.aplaceforallmybooks.majorItem",
	flipNote: "games.aplaceforallmybooks.flipNote",
	candleEnergy: "games.aplaceforallmybooks.candleEnergy",
	candleCards: "games.aplaceforallmybooks.candleCards",
	chain: "games.aplaceforallmybooks.chain",
	chooseDiscard: "games.aplaceforallmybooks.chooseDiscard",
	penelope: "games.aplaceforallmybooks.penelope",
	rivalQueue: "games.aplaceforallmybooks.rivalQueue",
	rivalDeck: "games.aplaceforallmybooks.rivalDeck",
	rivalCard: "games.aplaceforallmybooks.rivalCard",
	rivalLost: "games.aplaceforallmybooks.rivalLost",
	resultTitle: "games.aplaceforallmybooks.resultTitle",
	winner: "games.aplaceforallmybooks.winner",
	sharedWin: "games.aplaceforallmybooks.sharedWin",
	soloWin: "games.aplaceforallmybooks.soloWin",
	soloLoss: "games.aplaceforallmybooks.soloLoss",
	total: "games.aplaceforallmybooks.total",
	review: "games.aplaceforallmybooks.review",
	results: "games.aplaceforallmybooks.results",
	resultEnergy: "games.aplaceforallmybooks.resultEnergy",
	resultMajors: "games.aplaceforallmybooks.resultMajors",
	resultProjects: "games.aplaceforallmybooks.resultProjects",
	resultItems: "games.aplaceforallmybooks.resultItems",
	resultBooks: "games.aplaceforallmybooks.resultBooks",
	assist: "games.aplaceforallmybooks.assist",
	autopilot: "games.aplaceforallmybooks.autopilot",
	optBase: "games.aplaceforallmybooks.optBase",
	optPins: "games.aplaceforallmybooks.optPins",
	optNotes: "games.aplaceforallmybooks.optNotes",
	optSolo: "games.aplaceforallmybooks.optSolo",
	level: "games.aplaceforallmybooks.level",
	hintHome: "games.aplaceforallmybooks.hintHome",
	hintVillage: "games.aplaceforallmybooks.hintVillage",
	hintTask: "games.aplaceforallmybooks.hintTask",
	log: "games.aplaceforallmybooks.log",
	logEvent: "games.aplaceforallmybooks.logEvent",
	first: "games.aplaceforallmybooks.first",
	bookendsRule: "games.aplaceforallmybooks.bookendsRule",
	project0: "games.aplaceforallmybooks.project0",
	project1: "games.aplaceforallmybooks.project1",
	project2: "games.aplaceforallmybooks.project2",
	project3: "games.aplaceforallmybooks.project3",
	project4: "games.aplaceforallmybooks.project4",
	project5: "games.aplaceforallmybooks.project5",
	project6: "games.aplaceforallmybooks.project6",
	project7: "games.aplaceforallmybooks.project7",
	project8: "games.aplaceforallmybooks.project8",
	project9: "games.aplaceforallmybooks.project9",
	project10: "games.aplaceforallmybooks.project10",
	project11: "games.aplaceforallmybooks.project11",
	project12: "games.aplaceforallmybooks.project12",
	project13: "games.aplaceforallmybooks.project13",
	project14: "games.aplaceforallmybooks.project14",
	project15: "games.aplaceforallmybooks.project15",
	project16: "games.aplaceforallmybooks.project16",
	project17: "games.aplaceforallmybooks.project17",
	project18: "games.aplaceforallmybooks.project18",
	project19: "games.aplaceforallmybooks.project19",
	project20: "games.aplaceforallmybooks.project20",
	project21: "games.aplaceforallmybooks.project21",
	project22: "games.aplaceforallmybooks.project22",
	project23: "games.aplaceforallmybooks.project23",
	project24: "games.aplaceforallmybooks.project24",
	project25: "games.aplaceforallmybooks.project25",
	project26: "games.aplaceforallmybooks.project26",
	project27: "games.aplaceforallmybooks.project27",
	project28: "games.aplaceforallmybooks.project28",
	project29: "games.aplaceforallmybooks.project29",
	project30: "games.aplaceforallmybooks.project30",
	project31: "games.aplaceforallmybooks.project31",
	project32: "games.aplaceforallmybooks.project32",
	project33: "games.aplaceforallmybooks.project33",
	project34: "games.aplaceforallmybooks.project34",
	project35: "games.aplaceforallmybooks.project35",
	project36: "games.aplaceforallmybooks.project36",
	project37: "games.aplaceforallmybooks.project37",
	project38: "games.aplaceforallmybooks.project38",
	project39: "games.aplaceforallmybooks.project39",
	project40: "games.aplaceforallmybooks.project40",
	project41: "games.aplaceforallmybooks.project41",
	project42: "games.aplaceforallmybooks.project42",
	project43: "games.aplaceforallmybooks.project43",
	project44: "games.aplaceforallmybooks.project44",
	project45: "games.aplaceforallmybooks.project45",
	project46: "games.aplaceforallmybooks.project46",
	project47: "games.aplaceforallmybooks.project47",
	project48: "games.aplaceforallmybooks.project48",
	project49: "games.aplaceforallmybooks.project49",
	project50: "games.aplaceforallmybooks.project50",
	project51: "games.aplaceforallmybooks.project51",
	project52: "games.aplaceforallmybooks.project52",
	project53: "games.aplaceforallmybooks.project53",
	project54: "games.aplaceforallmybooks.project54",
	item0: "games.aplaceforallmybooks.item0",
	itemDesc0: "games.aplaceforallmybooks.itemDesc0",
	item1: "games.aplaceforallmybooks.item1",
	itemDesc1: "games.aplaceforallmybooks.itemDesc1",
	item2: "games.aplaceforallmybooks.item2",
	itemDesc2: "games.aplaceforallmybooks.itemDesc2",
	item3: "games.aplaceforallmybooks.item3",
	itemDesc3: "games.aplaceforallmybooks.itemDesc3",
	item4: "games.aplaceforallmybooks.item4",
	itemDesc4: "games.aplaceforallmybooks.itemDesc4",
	item5: "games.aplaceforallmybooks.item5",
	itemDesc5: "games.aplaceforallmybooks.itemDesc5",
	item6: "games.aplaceforallmybooks.item6",
	itemDesc6: "games.aplaceforallmybooks.itemDesc6",
	item7: "games.aplaceforallmybooks.item7",
	itemDesc7: "games.aplaceforallmybooks.itemDesc7",
	item8: "games.aplaceforallmybooks.item8",
	itemDesc8: "games.aplaceforallmybooks.itemDesc8",
	item9: "games.aplaceforallmybooks.item9",
	itemDesc9: "games.aplaceforallmybooks.itemDesc9",
	item10: "games.aplaceforallmybooks.item10",
	itemDesc10: "games.aplaceforallmybooks.itemDesc10",
	item11: "games.aplaceforallmybooks.item11",
	itemDesc11: "games.aplaceforallmybooks.itemDesc11",
	item12: "games.aplaceforallmybooks.item12",
	itemDesc12: "games.aplaceforallmybooks.itemDesc12",
	item13: "games.aplaceforallmybooks.item13",
	itemDesc13: "games.aplaceforallmybooks.itemDesc13",
	item14: "games.aplaceforallmybooks.item14",
	itemDesc14: "games.aplaceforallmybooks.itemDesc14",
	item15: "games.aplaceforallmybooks.item15",
	itemDesc15: "games.aplaceforallmybooks.itemDesc15",
	item16: "games.aplaceforallmybooks.item16",
	itemDesc16: "games.aplaceforallmybooks.itemDesc16",
	item17: "games.aplaceforallmybooks.item17",
	itemDesc17: "games.aplaceforallmybooks.itemDesc17",
	item18: "games.aplaceforallmybooks.item18",
	itemDesc18: "games.aplaceforallmybooks.itemDesc18",
	item19: "games.aplaceforallmybooks.item19",
	itemDesc19: "games.aplaceforallmybooks.itemDesc19",
	item20: "games.aplaceforallmybooks.item20",
	itemDesc20: "games.aplaceforallmybooks.itemDesc20",
	item21: "games.aplaceforallmybooks.item21",
	itemDesc21: "games.aplaceforallmybooks.itemDesc21",
	item22: "games.aplaceforallmybooks.item22",
	itemDesc22: "games.aplaceforallmybooks.itemDesc22",
	item23: "games.aplaceforallmybooks.item23",
	itemDesc23: "games.aplaceforallmybooks.itemDesc23",
	item24: "games.aplaceforallmybooks.item24",
	itemDesc24: "games.aplaceforallmybooks.itemDesc24",
	item25: "games.aplaceforallmybooks.item25",
	itemDesc25: "games.aplaceforallmybooks.itemDesc25",
	item26: "games.aplaceforallmybooks.item26",
	itemDesc26: "games.aplaceforallmybooks.itemDesc26",
	item27: "games.aplaceforallmybooks.item27",
	itemDesc27: "games.aplaceforallmybooks.itemDesc27",
	item28: "games.aplaceforallmybooks.item28",
	itemDesc28: "games.aplaceforallmybooks.itemDesc28",
	item29: "games.aplaceforallmybooks.item29",
	itemDesc29: "games.aplaceforallmybooks.itemDesc29",
	item30: "games.aplaceforallmybooks.item30",
	itemDesc30: "games.aplaceforallmybooks.itemDesc30",
	item31: "games.aplaceforallmybooks.item31",
	itemDesc31: "games.aplaceforallmybooks.itemDesc31",
	item32: "games.aplaceforallmybooks.item32",
	itemDesc32: "games.aplaceforallmybooks.itemDesc32",
	item33: "games.aplaceforallmybooks.item33",
	itemDesc33: "games.aplaceforallmybooks.itemDesc33",
	item34: "games.aplaceforallmybooks.item34",
	itemDesc34: "games.aplaceforallmybooks.itemDesc34",
	item35: "games.aplaceforallmybooks.item35",
	itemDesc35: "games.aplaceforallmybooks.itemDesc35",
	item36: "games.aplaceforallmybooks.item36",
	itemDesc36: "games.aplaceforallmybooks.itemDesc36",
	item37: "games.aplaceforallmybooks.item37",
	itemDesc37: "games.aplaceforallmybooks.itemDesc37",
	item38: "games.aplaceforallmybooks.item38",
	itemDesc38: "games.aplaceforallmybooks.itemDesc38",
	item39: "games.aplaceforallmybooks.item39",
	itemDesc39: "games.aplaceforallmybooks.itemDesc39",
	item40: "games.aplaceforallmybooks.item40",
	itemDesc40: "games.aplaceforallmybooks.itemDesc40",
	item41: "games.aplaceforallmybooks.item41",
	itemDesc41: "games.aplaceforallmybooks.itemDesc41",
	item42: "games.aplaceforallmybooks.item42",
	itemDesc42: "games.aplaceforallmybooks.itemDesc42",
	item43: "games.aplaceforallmybooks.item43",
	itemDesc43: "games.aplaceforallmybooks.itemDesc43",
	item44: "games.aplaceforallmybooks.item44",
	itemDesc44: "games.aplaceforallmybooks.itemDesc44",
	item45: "games.aplaceforallmybooks.item45",
	itemDesc45: "games.aplaceforallmybooks.itemDesc45",
	item46: "games.aplaceforallmybooks.item46",
	itemDesc46: "games.aplaceforallmybooks.itemDesc46",
	item47: "games.aplaceforallmybooks.item47",
	itemDesc47: "games.aplaceforallmybooks.itemDesc47",
	item48: "games.aplaceforallmybooks.item48",
	itemDesc48: "games.aplaceforallmybooks.itemDesc48",
	major0: "games.aplaceforallmybooks.major0",
	major1: "games.aplaceforallmybooks.major1",
	major2: "games.aplaceforallmybooks.major2",
	major3: "games.aplaceforallmybooks.major3",
	major4: "games.aplaceforallmybooks.major4",
	major5: "games.aplaceforallmybooks.major5",
	major6: "games.aplaceforallmybooks.major6",
	major7: "games.aplaceforallmybooks.major7",
	major8: "games.aplaceforallmybooks.major8",
	major9: "games.aplaceforallmybooks.major9",
	rules: "games.aplaceforallmybooks.rules"
};
function X() {
	let e = a();
	return (t, n) => e(mt[t], n);
}
//#endregion
//#region src/games/aplaceforallmybooks/components.tsx
function ht(e, t, n) {
	return e ? /^(?:Player|玩家)\s*\d+$/i.test(e.name) ? r(t, e.avatar) : f(e, t) : n;
}
var gt = [
	"bedroom",
	"den",
	"bath",
	"kitchen"
], Z = (e, t) => `${e}${t}`;
function _t({ member: e, name: t }) {
	return /* @__PURE__ */ d("span", {
		className: "apb-avatar",
		style: { background: te[(e?.colorIndex ?? 0) % te.length].hex },
		children: [e && /* @__PURE__ */ u("img", {
			src: ee[e.avatar % ee.length],
			alt: ""
		}), /* @__PURE__ */ u("span", {
			className: "apb-visually-hidden",
			children: t
		})]
	});
}
function vt({ p: e, member: t, name: n, active: r, picked: i, onPick: a }) {
	let o = X();
	return /* @__PURE__ */ u(K, {
		name: `seat:${e.rid}`,
		children: /* @__PURE__ */ d("button", {
			className: `apb-seat${r ? " apb-active" : ""}${i ? " apb-picked" : ""}`,
			onClick: a,
			"aria-label": o("viewApartment", { name: n }),
			children: [
				/* @__PURE__ */ u(_t, {
					member: t,
					name: n
				}),
				/* @__PURE__ */ d("span", {
					className: "apb-seat-name",
					children: [n, /* @__PURE__ */ u("small", { children: o("prefer", { color: o(O[e.mat]) }) })]
				}),
				/* @__PURE__ */ d(K, {
					name: `energy:${e.rid}`,
					className: "apb-seat-energy",
					children: [/* @__PURE__ */ u(J, {}), /* @__PURE__ */ u(p, { value: e.energy })]
				}),
				/* @__PURE__ */ d("span", {
					className: "apb-seat-count",
					children: [/* @__PURE__ */ u(Y, {}), /* @__PURE__ */ u(p, { value: e.score.total })]
				})
			]
		})
	});
}
function yt({ tile: e, name: t, style: n }) {
	return t ? /* @__PURE__ */ u(K, {
		name: t,
		className: "apb-tile",
		style: n,
		children: /* @__PURE__ */ u(q, { tile: e })
	}) : /* @__PURE__ */ u("span", {
		className: "apb-tile",
		style: n,
		children: /* @__PURE__ */ u(q, { tile: e })
	});
}
function bt({ tiles: e, anchor: t, compact: n = !1 }) {
	let r = e.filter(j), i = e.filter((e) => !j(e));
	return /* @__PURE__ */ d("span", {
		className: `apb-stack${n ? " apb-stack-small" : ""}`,
		children: [
			/* @__PURE__ */ u("span", {
				className: "apb-stack-books",
				children: r.map((n, i) => /* @__PURE__ */ u(yt, {
					tile: n,
					name: t ? `tile:${t}:${e.indexOf(n) === -1 ? i : e.map((e, t) => j(e) ? t : -1).filter((e) => e >= 0)[i]}` : void 0,
					style: { transform: `translate(${i % 2 * 2}px,${-i * 100 / Math.max(1, r.length) * .4}%)` }
				}, i))
			}),
			i.map((e, t) => /* @__PURE__ */ u("span", {
				className: "apb-marker",
				style: { right: t * 20 },
				children: /* @__PURE__ */ u(q, { tile: e })
			}, e)),
			r.length > 0 && /* @__PURE__ */ u("b", {
				className: "apb-height",
				children: r.length
			})
		]
	});
}
function xt({ p: e, preview: t, legal: n = [], selected: r = [], onCell: i, readonly: a = !1 }) {
	let o = X(), s = t ?? e.board;
	return /* @__PURE__ */ d("div", {
		className: "apb-apartment-board",
		children: [
			/* @__PURE__ */ u("div", {
				className: "apb-room-heading apb-room-bedroom",
				children: o("bedroom")
			}),
			/* @__PURE__ */ u("div", {
				className: "apb-room-heading apb-room-den",
				children: o("den")
			}),
			/* @__PURE__ */ u("div", {
				className: "apb-grid",
				children: s.map((t, s) => {
					let c = C.findIndex((e) => e.includes(s)), l = M(t) === 0;
					return /* @__PURE__ */ u(K, {
						name: `cell:${e.rid}:${s}`,
						className: `apb-cell-wrap apb-room-${c}`,
						children: /* @__PURE__ */ d("button", {
							className: `apb-cell${r.includes(s) ? " apb-selected" : ""}${n.includes(s) ? " apb-legal" : ""}`,
							"aria-label": o("cell", {
								room: o(gt[c]),
								row: Math.floor(s / 4) + 1,
								col: s % 4 + 1,
								n: M(t)
							}),
							onClick: () => i(s),
							disabled: a && !t.length,
							children: [
								/* @__PURE__ */ u("span", {
									className: "apb-cell-floor",
									"aria-hidden": !0,
									children: l && s === 1 ? /* @__PURE__ */ u("svg", {
										viewBox: "0 0 100 100",
										children: /* @__PURE__ */ u("path", {
											d: "M30 20h40v60H30zM32 45h36M46 67h8",
											fill: "none",
											stroke: "currentColor",
											strokeWidth: "3"
										})
									}) : null
								}),
								s === 1 && /* @__PURE__ */ u("small", {
									className: "apb-night-label",
									children: o("nightstand")
								}),
								/* @__PURE__ */ u(bt, {
									tiles: t,
									anchor: `${e.rid}:cell:${s}`
								}),
								w.includes(s) && /* @__PURE__ */ u("span", { className: "apb-corner-mark" }),
								T.includes(s) && /* @__PURE__ */ u("span", { className: "apb-center-mark" }),
								n.includes(s) && /* @__PURE__ */ u(st, {})
							]
						})
					}, s);
				})
			}),
			/* @__PURE__ */ u("div", {
				className: "apb-room-heading apb-room-bath",
				children: o("bath")
			}),
			/* @__PURE__ */ u("div", {
				className: "apb-room-heading apb-room-kitchen",
				children: o("kitchen")
			})
		]
	});
}
function St({ id: e, board: t, wild: n, selected: r = !1, canChoose: i = !1, onChoose: a, onDetail: o }) {
	let s = X(), c = F(e, t, n) !== null;
	return /* @__PURE__ */ d(K, {
		name: `project-card:${e}`,
		className: `apb-project${r ? " apb-selected" : ""}${i ? " apb-legal" : ""}`,
		children: [
			/* @__PURE__ */ d("div", {
				className: "apb-project-reward",
				children: [
					/* @__PURE__ */ u(Y, { n: 2 }),
					ye[e].reward === "energy" ? /* @__PURE__ */ u(J, {
						n: 3,
						arrow: !0
					}) : /* @__PURE__ */ u(ct, {}),
					/* @__PURE__ */ u(pt, { colors: ye[e].colors })
				]
			}),
			/* @__PURE__ */ d("button", {
				className: "apb-project-face",
				onClick: o,
				"aria-label": s(Z("project", e)),
				children: [/* @__PURE__ */ u(ft, { id: e }), /* @__PURE__ */ u("span", { children: s(Z("project", e)) })]
			}),
			i && /* @__PURE__ */ u("button", {
				className: "apb-card-choice",
				onClick: a,
				children: r ? "✓" : s(c ? "ready" : "confirm")
			}),
			i && /* @__PURE__ */ u(st, {})
		]
	});
}
function Ct({ id: e, used: t = !1, onClick: n, canBuy: r = !1, selected: i = !1, onBuy: a }) {
	let o = X(), s = he[e] === 0;
	return /* @__PURE__ */ d(K, {
		name: `item:${e}`,
		className: `apb-item${t ? " apb-used" : ""}${i ? " apb-selected" : ""}`,
		children: [/* @__PURE__ */ d("button", {
			className: "apb-item-face",
			onClick: n,
			children: [
				/* @__PURE__ */ u("span", {
					className: "apb-item-name",
					children: o(Z("item", e))
				}),
				/* @__PURE__ */ u(Y, { n: s ? "?" : he[e] }),
				/* @__PURE__ */ u(dt, { id: e }),
				/* @__PURE__ */ u("span", {
					className: "apb-item-foot",
					children: t ? o("used") : me.includes(e) ? o("use") : E.includes(e) || D.includes(e) ? "2 · 6 · 12 · 20" : o("details")
				})
			]
		}), r && /* @__PURE__ */ u("button", {
			className: "apb-card-choice",
			onClick: a,
			children: i ? "✓" : o("buy")
		})]
	});
}
function wt({ id: e, claimable: t, claimed: n, onClaim: r, onDetail: i }) {
	let a = X();
	return /* @__PURE__ */ d(K, {
		name: `major:${e}`,
		className: `apb-major${t ? " apb-legal" : ""}`,
		children: [
			/* @__PURE__ */ d("button", {
				onClick: i,
				children: [/* @__PURE__ */ u(Y, { n: `${Ce[e][0]}/${Ce[e][1]}` }), /* @__PURE__ */ u("span", { children: a(Z("major", e)) })]
			}),
			n === void 0 ? t ? /* @__PURE__ */ u("button", {
				className: "apb-card-choice",
				onClick: r,
				children: a("claim")
			}) : null : /* @__PURE__ */ d("span", {
				className: "apb-major-claimed",
				children: ["✓ ", n]
			}),
			t && /* @__PURE__ */ u(st, {})
		]
	});
}
//#endregion
//#region src/games/aplaceforallmybooks/bot.ts
var Tt = (e, t = []) => ({
	...e,
	hand: t,
	completed: Array(e.completed).fill(-1)
}), Et = {
	progress: 1,
	travelEnergy: 12,
	itemValue: 1,
	searchWidth: 7
}, Q = Array.from({ length: 16 }, (e, t) => t), $ = (e) => e.reduce((e, t) => e + t, 0);
function Dt(e, t, n = []) {
	if (F(e, t, n)) return 0;
	let r = ye[e], i = r.colors[0], a = t.map(M), o = (e, t) => Math.max(0, t - e), s = (e, r) => $(e.map((e) => P(t[e], r, n))), c = (e, r) => e.filter((e) => N(t[e], n) === r).length;
	switch (r.kind) {
		case "cornersColor": return o(s(w, i), 4);
		case "mixed": return Math.min(...t.map((e) => $(r.colors.map((t) => o(P(e, t, n), 2)))));
		case "singleColor": return o(Q.filter((e) => a[e] === 1 && N(t[e], n) === i).length, 3);
		case "noColorTall": return o(Q.filter((e) => a[e] >= 3 && P(t[e], i, n) === 0).length, 3) * 1.5;
		case "roomTall": return o(C[r.room].filter((e) => a[e] >= 3).length, 3) * 1.5;
		case "rowsCols": return $([
			0,
			1,
			2,
			3
		].map((e) => +![
			0,
			1,
			2,
			3
		].some((t) => a[e * 4 + t] > 0) + +![
			0,
			1,
			2,
			3
		].some((t) => a[t * 4 + e] > 0)));
		case "roomsNoColor": return s(r.room === 1 ? [...C[1], ...C[3]] : [...C[0], ...C[2]], i);
		case "rainbow": return Math.min(...t.map((e) => $(S.map((t) => Math.abs(P(e, t, n) - 1)))));
		case "centerEmpty": return T.filter((e) => a[e] > 0).length;
		case "oneEmpty": return $(C.map((e) => Math.abs(e.filter((e) => a[e] === 0).length - 1)));
		case "rowTops":
		case "colTops": return Math.min(...[
			0,
			1,
			2,
			3
		].flatMap((e) => S.map((t) => 4 - c([
			0,
			1,
			2,
			3
		].map((t) => r.kind === "rowTops" ? e * 4 + t : t * 4 + e), t))));
		case "centerTops": return o(c(T, i), 3);
		case "cornersEmpty": return w.filter((e) => a[e] > 0).length;
		case "cornersTops": return Math.min(...S.map((e) => 4 - c(w, e)));
		case "roomTops": return Math.min(...C.map((e) => o(c(e, i), 3)));
		case "allTall": return $(a.filter((e) => e > 0).map((e) => o(e, 3))) / 2;
		case "fourColor": return Math.min(...t.map((e) => o(P(e, i, n), 4)));
		case "cornerSingles": return $(w.map((e) => Math.abs(a[e] - 1))) / 2;
		case "oneTall": return $(C.map((e) => Math.abs(e.filter((e) => a[e] >= 3).length - 1))) * 1.5;
		case "nightColor": return Math.min(...S.map((e) => o(P(t[1], e, n), 4)));
		case "noSingles": return a.filter((e) => e === 1).length / 2;
		case "roomSingles": return Math.min(...C.map((e) => $(e.map((e) => Math.abs(a[e] - 1))) / 2));
		case "centerTall": return o(T.filter((e) => a[e] >= 3).length, 3) * 1.5;
		case "square": return Math.min(...[
			0,
			1,
			4,
			5
		].map((e) => [
			0,
			1,
			2,
			4,
			5,
			6,
			8,
			9,
			10
		].filter((t) => a[e + t] === 0).length));
		case "six": return (6 - Math.max(...a)) / 2;
		case "noTall": return $(a.map((e) => Math.max(0, e - 2))) / 2;
	}
}
function Ot(e, t, n = [], r = 1) {
	return $(t.map((t) => {
		let r = Dt(t, e, n);
		return r === 0 ? 5 : 2.5 / (1 + r);
	}).sort((e, t) => t - e).map((e, t) => e * (t < 3 ? 1 : .35))) * r;
}
function kt(e) {
	return e.map((e) => [...e]);
}
function At(e, t, n, r = [], i = 7) {
	let a = t.board, o = {
		action: e === "gather" ? {
			type: "gather",
			sources: [],
			to: 0
		} : e === "read" ? {
			type: "read",
			from: Q.find((e) => a[e].length > 0) ?? 0,
			index: 0
		} : {
			type: "sort",
			from: 0,
			moves: []
		},
		value: -Infinity
	}, s = (e) => Ot(e, n, r);
	if (e === "read") for (let e of Q) for (let t = 0; t < a[e].length; t++) {
		let n = a[e][t];
		if (!j(n) || e !== 1 && M(a[1]) >= 6) continue;
		let r = kt(a);
		r[e].splice(t, 1), r[1].push(n);
		let i = s(r) + (a[e].includes("lamp") ? .8 : 0);
		i > o.value && (o = {
			action: {
				type: "read",
				from: e,
				index: t
			},
			value: i
		});
	}
	else if (e === "gather") {
		let e = Q.filter((e) => M(a[e]) > 0), t = [[]];
		for (let n of e) t.push([n]);
		for (let n of S) {
			let i = e.filter((e) => N(a[e], r) === n);
			for (let e = 2; e <= Math.min(6, i.length); e++) t.push(i.slice(0, e));
		}
		for (let n = 0; n < e.length; n++) t.push(e.slice(n, n + 6)), t.push(e.filter((e) => w.includes(e)).slice(0, 6)), t.push(e.filter((e) => T.includes(e)).slice(0, 6));
		for (let e of t) for (let t of Q) {
			let n = kt(a), r = e.map((e) => n[e].splice(be(n[e]), 1)[0]);
			if (!(M(n[t]) + r.length > 6)) for (let i of [!1, !0]) {
				let a = kt(n);
				a[t].push(...i ? [...r].reverse() : r);
				let c = s(a);
				c > o.value && (o = {
					action: {
						type: "gather",
						sources: (i ? [...e].reverse() : e).map((e) => ({
							cell: e,
							token: "book"
						})),
						to: t
					},
					value: c
				});
			}
		}
	} else for (let t of Q) {
		if (!a[t].length) continue;
		let n = kt(a);
		n[t] = [];
		let r = [{
			board: n,
			moves: [],
			counts: Array(16).fill(0),
			value: 0
		}];
		for (let n of a[t].map((e, t) => t)) {
			let o = [];
			for (let i of r) for (let r of Q) {
				if (e === "succulents" && i.moves.length && i.moves[0].to !== r) continue;
				let c = a[t][n];
				if (j(c) && (M(i.board[r]) >= 6 || e === "sort" && i.counts[r] >= 2)) continue;
				let l = kt(i.board);
				l[r].push(c);
				let u = [...i.counts];
				j(c) && u[r]++, o.push({
					board: l,
					moves: [...i.moves, {
						index: n,
						to: r
					}],
					counts: u,
					value: s(l)
				});
			}
			r = o.sort((e, t) => t.value - e.value).slice(0, i);
		}
		let c = r[0];
		c && c.value > o.value && (o = {
			action: {
				type: "sort",
				from: t,
				moves: c.moves
			},
			value: c.value
		});
	}
	return o;
}
function jt(e, t) {
	let n = he[e] + 1;
	return D.includes(e) && (n = [
		2,
		4,
		6,
		8,
		0
	][Math.min(4, t.items.filter((e) => D.includes(e)).length)]), E.includes(e) && (n = [
		2,
		4,
		6,
		8,
		0
	][Math.min(4, t.items.filter((e) => E.includes(e)).length)]), e in pe && (n = 3), e === 48 && (n = t.items.length + 2), e === 1 && (n = Math.min(7, t.board.filter((e) => M(e) === 1).length)), n;
}
function Mt(e = {}) {
	let t = {
		...Et,
		...e
	};
	return ({ public: e, private: n }, { rid: r, difficulty: i }) => {
		let a = e.players.find((e) => e.rid === r);
		if (!a || !n || e.phase === "done" || e.phase === "rival") return null;
		let o = n.hand, s = i === "normal", c = (e) => ({ action: e });
		if (e.phase === "draft") return e.drafted.includes(r) ? null : c({
			type: "draft",
			keep: [...o].sort((e, t) => Dt(e, a.board) - Dt(t, a.board)).slice(0, 3)
		});
		if (e.actor !== r) return null;
		let l = e.majors.find((t) => a.majors[t] === void 0 && Ye(Tt(a, o), t, e.wild, e.admireOverflow));
		if (l !== void 0 && (!e.task || e.task.kind === "admire")) return c({
			type: "claim",
			id: l
		});
		let u = e.task;
		if (u) {
			if (u.kind === "discard" || u.kind === "record") return c({
				type: "discard",
				ids: [...o].sort((e, t) => Dt(t, a.board) - Dt(e, a.board)).slice(0, u.kind === "discard" ? u.n : Math.max(0, o.length - 2))
			});
			if (u.kind === "gather" || u.kind === "sort" || u.kind === "read" || u.kind === "succulents") return c(At(u.kind, a, o, e.wild, s ? t.searchWidth : 1).action);
			if (u.kind === "library") {
				let e = O[a.mat];
				return c({
					type: "selectBooks",
					indices: u.cards.map((e, t) => ({
						c: e,
						i: t
					})).sort((t, n) => Number(n.c === e) - Number(t.c === e)).slice(0, u.n).map((e) => e.i)
				});
			}
			if (u.kind === "pack") {
				let e = [[], []], t = u.cards.map((e, t) => t).sort((e, t) => u.cards[e].localeCompare(u.cards[t]));
				for (let n of t) {
					let t = a.bag[0].length + e[0].length < 6 ? 0 : 1;
					a.bag[t].length + e[t].length >= 6 || (a.bag[1].length + e[1].length < 6 && N(a.bag[1]) === u.cards[n] && (t = 1), e[t].push(n));
				}
				return c({
					type: "pack",
					piles: e
				});
			}
			if (u.kind === "unload") {
				let e = -Infinity, t = [0, 0];
				for (let n of Q) for (let r of Q) {
					let i = kt(a.board);
					if (i[n].push(...a.bag[0]), i[r].push(...a.bag[1]), i.some((e) => M(e) > 6)) continue;
					let s = Ot(i, o);
					s > e && (e = s, t = [n, r]);
				}
				return c({
					type: "unload",
					cells: t
				});
			}
			if (u.kind === "exchange") {
				let t = a.board[1].map((e, t) => S.includes(e) && e !== O[a.mat] ? t : -1).filter((e) => e >= 0), n = { ...e.supply };
				for (let e of t) {
					let t = a.board[1][e];
					n[t]++;
				}
				let r = [];
				for (let e = 0; e < t.length + 1 + +!!a.items.includes(33); e++) {
					let e = [O[a.mat], ...S].find((e) => n[e] > 0);
					if (!e) break;
					r.push(e), n[e]--;
				}
				return c({
					type: "exchange",
					indices: t,
					colors: r
				});
			}
			if (u.kind === "tile") {
				let e = -Infinity, t = 0;
				for (let n of Q) {
					if (j(u.cards[0]) && M(a.board[n]) >= 6) continue;
					let r = kt(a.board);
					r[n].push(u.cards[0]);
					let i = Ot(r, o);
					i > e && (e = i, t = n);
				}
				return c({
					type: "placeTile",
					cell: t
				});
			}
			if (u.kind === "kitty") {
				let e = pe[u.id], t = -1, n = 0;
				return C.forEach((r, i) => {
					let o = $(r.map((t) => P(a.board[t], e)));
					o > t && (t = o, n = i);
				}), c({
					type: "kitty",
					room: n
				});
			}
			if (u.kind === "wild") return c({
				type: "chooseColor",
				color: u.id === 35 ? S.find((t) => e.supply[t] > 0) ?? "r" : O[a.mat]
			});
			if (u.kind === "admire") {
				let t = o.find((t) => F(t, a.board, e.wild));
				if (t !== void 0) return c({
					type: "project",
					id: t
				});
				let n = o.filter((t) => !F(t, a.board, e.wild));
				return a.items.includes(47) && !e.candleUsed && n.length >= 2 ? c({
					type: "candle",
					ids: n.slice(0, 2),
					reward: "cards"
				}) : c({ type: "finishAdmire" });
			}
			if (u.kind === "puzzle") {
				let e = [...o].sort((e, t) => Dt(t, a.board) - Dt(e, a.board))[0];
				return c(e === void 0 ? { type: "skip" } : {
					type: "project",
					id: e
				});
			}
			if (u.kind === "remove") return c({
				type: "removeRivals",
				color: [...S, "none"].sort((t, n) => (e.rival?.queue.filter((e) => t === "none" ? Pt(e) : Nt(e, t)).length ?? 0) - (e.rival?.queue.filter((e) => n === "none" ? Pt(e) : Nt(e, n)).length ?? 0)).at(-1)
			});
			if (u.kind === "laptop" || u.kind === "snowglobe") {
				let t = [...u.kind === "laptop" ? e.itemDiscard : e.shop].sort((e, t) => jt(t, a) - jt(e, a))[0];
				return c(t === void 0 ? { type: "skip" } : {
					type: "takeItem",
					id: t
				});
			}
			return null;
		}
		if (a.items.includes(11) && !a.used.includes(11) && a.energy <= 16) return c({
			type: "flip",
			id: 11
		});
		if (s) {
			let t = a.items.find((t) => me.includes(t) && !a.used.includes(t) && (t === 39 && e.shop.length || t === 22 && e.itemDiscard.length || t === 21 && o.some((t) => F(t, a.board, e.wild)) || t === 28 && o.length < 3));
			if (t !== void 0) return c({
				type: "flip",
				id: t
			});
		}
		if (e.step === "after") return c({ type: "end" });
		if (![
			"bookstore",
			"bookstore0",
			"bookstore1",
			"library",
			"shop",
			"exchange",
			"park",
			"gate"
		].includes(a.pos)) {
			let n = o.filter((t) => F(t, a.board, e.wild)).length;
			if (a.pos !== "admire" && (n > 0 || a.energy < 5 && a.pos === "rest")) return c({
				type: "home",
				action: "admire"
			});
			if (a.pos !== "leave" && a.energy >= (s ? t.travelEnergy : 8) && e.step !== "home") return c({
				type: "home",
				action: "leave"
			});
			if (a.pos !== "rest" && o.length <= 2) return c({
				type: "home",
				action: "rest"
			});
			if (s && o.length) {
				let n = null, r = Ot(a.board, o);
				for (let i of [
					"gather",
					"sort",
					"read"
				]) {
					if (a.pos === i) continue;
					let s = At(i, a, o, e.wild, t.searchWidth).value - r + (i === "read" ? .1 : 0);
					(!n || s > n.value) && (n = {
						kind: i,
						value: s
					});
				}
				if (n && n.value > .15) return c({
					type: "home",
					action: n.kind
				});
			}
			return c({
				type: "home",
				action: a.pos === "rest" ? "admire" : "rest"
			});
		}
		let d = [];
		if (!a.pos.startsWith("bookstore")) for (let t of [
			0,
			1,
			2
		]) {
			let n = Le(e.shelves, t);
			if (n <= a.energy) {
				let r = 12 - a.bag.flat().length;
				d.push({
					action: {
						type: "village",
						place: "bookstore",
						shelf: t,
						side: +(t === 2)
					},
					value: Math.min(r, e.shelves[t].books.length) + 1.4 - n * .24
				});
			}
		}
		if (a.pos !== "library" && a.energy >= (e.players.length === 4 ? 2 : 1) && a.bag.flat().length < 11 && d.push({
			action: {
				type: "village",
				place: "library"
			},
			value: 1.5
		}), a.pos !== "shop") for (let n of e.shop) {
			let e = a.items.includes(16) ? 3 : 4;
			a.energy >= e && d.push({
				action: {
					type: "village",
					place: "shop",
					items: [n]
				},
				value: jt(n, a) * t.itemValue - e * .26
			});
		}
		return e.step === "main" && (a.bag.flat().length >= 8 || a.energy < 2 || !d.length) ? c({ type: "return" }) : (d.sort((e, t) => t.value - e.value), d.length ? c(d[0].action) : c({ type: "return" }));
	};
}
var Nt = (e, t) => we[e].includes(t), Pt = (e) => we[e].length === 0, Ft = Mt(), It = (e, t, n) => e.type === "home" ? n("games.aplaceforallmybooks.hintHome") : e.type === "village" ? n("games.aplaceforallmybooks.hintVillage") : n("games.aplaceforallmybooks.hintTask"), Lt = (e) => ({
	scope: e,
	chosen: [],
	source: null,
	moves: [],
	sources: [],
	mode: "source",
	index: null,
	piles: [[], []],
	cells: [],
	colors: []
}), Rt = Array.from({ length: 16 }, (e, t) => t), zt = [
	"gather",
	"sort",
	"read",
	"rest",
	"admire",
	"leave"
], Bt = {
	gather: "gatherPrompt",
	sort: "sortPrompt",
	read: "readPrompt",
	discard: "discardPrompt",
	library: "libraryPrompt",
	pack: "packPrompt",
	unload: "unloadPrompt",
	exchange: "exchangePrompt",
	tile: "tilePrompt",
	kitty: "kittyPrompt",
	wild: "wildPrompt",
	admire: "admirePrompt",
	puzzle: "puzzlePrompt",
	succulents: "succulentsPrompt",
	record: "recordPrompt",
	laptop: "laptopPrompt",
	snowglobe: "snowglobePrompt",
	remove: "removePrompt"
};
function Vt(e) {
	return /* @__PURE__ */ u(Ht, { ...e });
}
function Ht({ public: e, private: t, members: r, myRid: a, send: s, readOnly: c = !1 }) {
	let f = e, ee = t, p = X(), te = i((e) => e.locale), [ne, re] = n(a), [ie, ae] = n("apartment"), [m, h] = n(null), [oe, se] = n(() => Lt("")), [ce, g] = n(a);
	ce !== a && (g(a), re(a), h(null), se(Lt("")));
	let _ = f.players.find((e) => e.rid === a), v = f.players.find((e) => e.rid === ne) ?? _ ?? f.players[0], y = f.task, le = ee?.hand ?? [], ue = `${a}:${f.turnNo}:${f.phase}:${y?.kind ?? f.step}:${y?.id ?? ""}:${y?.n ?? ""}`, b = oe.scope === ue ? oe : Lt(ue), x = !c && f.phase === "turn" && f.actor === a, de = x && !y && f.step !== "after", fe = _ ? ![
		"bookstore",
		"bookstore0",
		"bookstore1",
		"library",
		"shop",
		"exchange",
		"park",
		"gate"
	].includes(_.pos) : !1, C = x && v.rid === a, w = (e) => {
		if (e === "penelope") return p("penelope");
		let t = r.find((t) => t.rid === e), n = f.players.find((t) => t.rid === e);
		return ht(t, te, p(n ? O[n.mat] : "home"));
	}, T = (e) => se({
		...b,
		...e
	}), E = (e) => {
		s(e), se(Lt("")), e.type === "home" && e.action === "leave" && ae("village"), e.type === "return" && ae("apartment");
	}, D = (e) => T({ chosen: b.chosen.includes(e) ? b.chosen.filter((t) => t !== e) : [...b.chosen, e] }), ge = v.board[b.source ?? -1] ?? [], _e = ge.map((e, t) => t).filter((e) => !b.moves.some((t) => t.index === e)), ve = b.index !== null && _e.includes(b.index) ? b.index : _e[0], k = v.board.map((e) => [...e]);
	if (y && C) {
		if (y.kind === "gather" && b.mode === "target") {
			let e = b.sources.map((e) => {
				let t = k[e.cell], n = e.token === "book" ? be(t) : t.indexOf(e.token);
				return n >= 0 ? t.splice(n, 1)[0] : null;
			}).filter((e) => e !== null);
			b.source !== null && k[b.source].push(...e);
		}
		if ((y.kind === "sort" || y.kind === "succulents") && b.source !== null) {
			k[b.source] = ge.filter((e, t) => !b.moves.some((e) => e.index === t));
			for (let e of b.moves) k[e.to].push(ge[e.index]);
		}
		y.kind === "unload" && b.cells.forEach((e, t) => k[e].push(..._?.bag[t] ?? []));
	}
	let A = [];
	if (C && y) {
		if (y.kind === "gather" && (A = b.mode === "source" ? Rt.filter((e) => M(v.board[e]) > 0) : Rt.filter((e) => M(k[e]) + b.sources.filter((e) => e.token === "book").length <= 6)), (y.kind === "sort" || y.kind === "succulents") && (A = b.source === null ? Rt.filter((e) => v.board[e].length > 0) : ve === void 0 ? [] : Rt.filter((e) => {
			let t = ge[ve], n = b.moves.filter((t) => t.to === e && j(ge[t.index])).length;
			return (!j(t) || M(k[e]) < 6 && (y.kind === "succulents" || n < 2)) && (y.kind !== "succulents" || !b.moves.length || b.moves[0].to === e);
		})), y.kind === "read" && (A = Rt.filter((e) => v.board[e].length > 0 && (e === 1 || M(v.board[1]) < 6) && v.board[e].some(j))), y.kind === "tile" && (A = Rt.filter((e) => !j(y.cards[0]) || M(v.board[e]) < 6)), y.kind === "unload") {
			let e = b.cells.length;
			A = e < 2 ? Rt.filter((t) => M(k[t]) + M(v.bag[e]) <= 6 && (e === 1 || Ie(Tt(v)).some((e) => e[0] === t))) : [];
		}
		y.kind === "exchange" && (A = [1]);
	}
	function xe(e) {
		if (!C || !y) {
			v.board[e].length && h({
				kind: "stack",
				id: e
			});
			return;
		}
		if (y.kind === "gather") {
			if (b.mode === "target" && A.includes(e)) {
				E({
					type: "gather",
					sources: b.sources,
					to: e
				});
				return;
			}
			b.mode === "source" && M(v.board[e]) > 0 && (b.sources.some((t) => t.cell === e && t.token === "book") ? T({ sources: b.sources.filter((t) => t.cell !== e || t.token !== "book") }) : b.sources.filter((e) => e.token === "book").length < 6 && T({ sources: [...b.sources, {
				cell: e,
				token: "book"
			}] }));
		} else if (y.kind === "sort" || y.kind === "succulents") {
			if (b.source === null) {
				v.board[e].length && T({ source: e });
				return;
			}
			ve !== void 0 && A.includes(e) && T({
				moves: [...b.moves, {
					index: ve,
					to: e
				}],
				index: null
			});
		} else y.kind === "read" && A.includes(e) ? h({
			kind: "stack",
			id: e
		}) : y.kind === "tile" && A.includes(e) ? E({
			type: "placeTile",
			cell: e
		}) : y.kind === "unload" && A.includes(e) ? T({ cells: [...b.cells, e] }) : (y.kind === "exchange" && e === 1 || v.board[e].length) && h({
			kind: "stack",
			id: e
		});
	}
	let Se = (e) => {
		if (!c) {
			if (f.phase === "draft" && !f.drafted.includes(a)) {
				(b.chosen.includes(e) || b.chosen.length < 3) && D(e);
				return;
			}
			x && ((y?.kind === "discard" || y?.kind === "record") && D(e), y?.kind === "admire" && _ && F(e, _.board, f.wild) && E({
				type: "project",
				id: e
			}), y?.kind === "puzzle" && E({
				type: "project",
				id: e
			}), !y && f.bonus && _?.items.includes(f.bonus) && D(e));
		}
	}, N = (e) => !c && (f.phase === "draft" && !f.drafted.includes(a) || x && (y?.kind === "discard" || y?.kind === "record" || y?.kind === "puzzle" || y?.kind === "admire" && !!_ && F(e, _.board, f.wild) !== null || !y && f.bonus !== null && !!_?.items.includes(f.bonus))), P = { ...f.supply };
	if (y?.kind === "exchange" && _) for (let e of b.chosen) {
		let t = _.board[1][e];
		S.includes(t) && P[t]++;
	}
	for (let e of b.colors) P[e]--;
	let we = y?.kind === "exchange" ? Math.min(b.chosen.length + 1 + +!!_?.items.includes(33), f.bagCount + b.chosen.length) : 0, I = (e) => !!_ && x && (!y || y.kind === "admire") && _.majors[e] === void 0 && Ye(Tt(_, le), e, f.wild, f.admireOverflow), Te = de && !fe && _ !== void 0, L = c ? "" : f.phase === "draft" ? f.drafted.includes(a) ? p("waiting", { name: f.players.filter((e) => !f.drafted.includes(e.rid)).map((e) => w(e.rid)).join("、") }) : p("draftPrompt") : f.phase === "rival" ? p("rivalPrompt") : x ? y ? p(y.kind === "wild" && y.id === 35 ? "shelfPrompt" : Bt[y.kind], { n: y.n }) : f.step === "after" ? p("afterPrompt") : p("mainPrompt") : p("waiting", { name: w(f.actor) }), R;
	f.phase === "draft" && !f.drafted.includes(a) ? R = /* @__PURE__ */ u("button", {
		disabled: b.chosen.length !== 3,
		onClick: () => E({
			type: "draft",
			keep: b.chosen
		}),
		children: p("confirmDraft")
	}) : x && y ? (y.kind === "gather" && (R = /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("button", {
		onClick: () => T({ mode: b.mode === "source" ? "target" : "source" }),
		children: b.mode === "source" ? p("chosenDestination") : p("cancel")
	}), b.mode === "source" && !b.sources.length && /* @__PURE__ */ u("button", {
		onClick: () => E({
			type: "gather",
			sources: [],
			to: 0
		}),
		children: p("confirm")
	})] })), (y.kind === "sort" || y.kind === "succulents") && (R = /* @__PURE__ */ u("button", {
		disabled: b.source === null || y.kind === "sort" && b.moves.length !== ge.length,
		onClick: () => E({
			type: "sort",
			from: b.source,
			moves: b.moves
		}),
		children: p("confirm")
	})), (y.kind === "discard" || y.kind === "record") && (R = /* @__PURE__ */ u("button", {
		disabled: y.kind === "discard" && b.chosen.length !== y.n,
		onClick: () => E({
			type: "discard",
			ids: b.chosen
		}),
		children: p("confirm")
	})), y.kind === "library" && (R = /* @__PURE__ */ u("button", {
		disabled: b.chosen.length !== y.n,
		onClick: () => E({
			type: "selectBooks",
			indices: b.chosen
		}),
		children: p("confirm")
	})), y.kind === "pack" && (R = /* @__PURE__ */ u("button", {
		disabled: b.piles.flat().length !== Math.min(y.cards.length, 12 - (_?.bag.flat().filter(j).length ?? 0)),
		onClick: () => E({
			type: "pack",
			piles: b.piles
		}),
		children: p("confirm")
	})), y.kind === "unload" && (R = /* @__PURE__ */ u("button", {
		disabled: b.cells.length < 2,
		onClick: () => E({
			type: "unload",
			cells: b.cells
		}),
		children: p("confirm")
	})), y.kind === "exchange" && (R = /* @__PURE__ */ u("button", {
		disabled: b.colors.length !== we,
		onClick: () => E({
			type: "exchange",
			indices: b.chosen,
			colors: b.colors
		}),
		children: p("confirm")
	})), y.kind === "admire" && (R = /* @__PURE__ */ u("button", {
		onClick: () => E({ type: "finishAdmire" }),
		children: p("finishAdmire")
	})), R = /* @__PURE__ */ d(l, { children: [
		R,
		y.optional && /* @__PURE__ */ u("button", {
			className: "apb-quiet",
			onClick: () => E({ type: "skip" }),
			children: p("skip")
		}),
		/* @__PURE__ */ u("button", {
			className: "apb-quiet",
			onClick: () => se(Lt(ue)),
			children: p("cancel")
		})
	] })) : x && f.step === "after" && (R = /* @__PURE__ */ d(l, { children: [f.bonus !== null && _?.items.includes(f.bonus) && /* @__PURE__ */ u("button", {
		className: "apb-quiet",
		disabled: b.chosen.length !== 1,
		onClick: () => E({
			type: "bonus",
			id: f.bonus,
			discard: b.chosen[0]
		}),
		children: p("chain", { action: p(f.bonus === 37 ? "sort" : "gather") })
	}), /* @__PURE__ */ u("button", {
		onClick: () => E({ type: "end" }),
		children: p("end")
	})] }));
	let z = _?.board.flatMap((e, t) => e.filter((e) => !j(e)).map((e) => ({
		cell: t,
		token: e
	}))) ?? [], B = x && y && (y.kind !== "gather" || z.length) ? /* @__PURE__ */ d("div", {
		className: "apb-decision",
		children: [
			(y.kind === "sort" || y.kind === "succulents") && b.source !== null && /* @__PURE__ */ u("div", {
				className: "apb-loose-books",
				children: ge.map((e, t) => /* @__PURE__ */ u("button", {
					"aria-label": j(e) ? p("chooseBook", { color: p(e === "w0" || e === "w1" ? "wild" : e) }) : p(e),
					className: `${b.moves.some((e) => e.index === t) ? "apb-placed" : ""}${ve === t ? " apb-selected" : ""}`,
					disabled: b.moves.some((e) => e.index === t),
					onClick: () => T({ index: t }),
					children: /* @__PURE__ */ u(q, { tile: e })
				}, t))
			}),
			(y.kind === "library" || y.kind === "pack") && /* @__PURE__ */ u(K, {
				name: "book-supply",
				className: "apb-loose-books",
				children: y.cards.map((e, t) => /* @__PURE__ */ u(K, {
					name: `pool:${t}`,
					children: /* @__PURE__ */ u("button", {
						className: `${b.chosen.includes(t) || b.index === t ? "apb-selected" : ""}${b.piles.flat().includes(t) ? " apb-placed" : ""}`,
						disabled: y.kind === "pack" && b.piles.flat().includes(t),
						onClick: () => y.kind === "library" ? D(t) : T({ index: t }),
						"aria-label": p("chooseBook", { color: p(S.includes(e) ? e : "wild") }),
						children: /* @__PURE__ */ u(q, { tile: e })
					})
				}, t))
			}),
			y.kind === "tile" && /* @__PURE__ */ u(K, {
				name: "item-deck",
				className: "apb-pending-token",
				children: /* @__PURE__ */ u(q, { tile: y.cards[0] })
			}),
			y.kind === "gather" && z.map((e) => {
				let t = b.sources.some((t) => t.cell === e.cell && t.token === e.token);
				return /* @__PURE__ */ d("button", {
					className: `apb-token-choice${t ? " apb-selected" : ""}`,
					onClick: () => T({ sources: t ? b.sources.filter((t) => t.token !== e.token) : [...b.sources, e] }),
					children: [/* @__PURE__ */ u(q, { tile: e.token }), p(e.token)]
				}, e.token);
			}),
			y.kind === "unload" && /* @__PURE__ */ u("div", {
				className: "apb-unload-preview",
				children: _?.bag.map((e, t) => /* @__PURE__ */ d("span", {
					className: b.cells.length === t ? "apb-selected" : "",
					children: [/* @__PURE__ */ u(bt, { tiles: e }), b.cells[t] !== void 0 && /* @__PURE__ */ u("b", { children: "✓" })]
				}, t))
			}),
			y.kind === "kitty" && /* @__PURE__ */ u("div", {
				className: "apb-room-choices",
				children: gt.map((e, t) => /* @__PURE__ */ u("button", {
					className: `apb-room-${t}`,
					onClick: () => E({
						type: "kitty",
						room: t
					}),
					children: p(e)
				}, e))
			}),
			(y.kind === "wild" || y.kind === "exchange" || y.kind === "remove") && /* @__PURE__ */ d("div", {
				className: "apb-color-choices",
				children: [S.map((e) => /* @__PURE__ */ d("button", {
					disabled: y.kind === "exchange" ? P[e] <= 0 || b.colors.length >= we : y.kind === "wild" && y.id === 35 && f.supply[e] === 0 && f.bagCount > 0,
					onClick: () => y.kind === "wild" ? E({
						type: "chooseColor",
						color: e
					}) : y.kind === "remove" ? E({
						type: "removeRivals",
						color: e
					}) : T({ colors: [...b.colors, e] }),
					children: [/* @__PURE__ */ u(q, { tile: e }), /* @__PURE__ */ u("span", { children: p(e) })]
				}, e)), y.kind === "remove" && /* @__PURE__ */ u("button", {
					onClick: () => E({
						type: "removeRivals",
						color: "none"
					}),
					children: p("none")
				})]
			}),
			y.kind === "exchange" && /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ d("button", {
				className: "apb-quiet",
				onClick: () => h({
					kind: "stack",
					id: 1
				}),
				children: [
					p("nightstand"),
					" · ",
					p("selected", { n: b.chosen.length })
				]
			}), /* @__PURE__ */ u("div", {
				className: "apb-color-list",
				children: b.colors.map((e, t) => /* @__PURE__ */ u(q, { tile: e }, t))
			})] }),
			(y.kind === "laptop" || y.kind === "snowglobe") && /* @__PURE__ */ u("div", {
				className: "apb-item-grid",
				children: (y.kind === "laptop" ? f.itemDiscard : f.shop).map((e) => /* @__PURE__ */ u(Ct, {
					id: e,
					onClick: () => h({
						kind: "item",
						id: e
					}),
					canBuy: !0,
					onBuy: () => E({
						type: "takeItem",
						id: e
					})
				}, e))
			}),
			y.kind === "admire" && _?.items.includes(47) && !f.candleUsed && /* @__PURE__ */ d("div", {
				className: "apb-candle",
				children: [
					/* @__PURE__ */ u("button", {
						disabled: b.chosen.length !== 2,
						onClick: () => E({
							type: "candle",
							ids: b.chosen,
							reward: "energy"
						}),
						children: p("candleEnergy")
					}),
					/* @__PURE__ */ u("button", {
						disabled: b.chosen.length !== 2,
						onClick: () => E({
							type: "candle",
							ids: b.chosen,
							reward: "cards"
						}),
						children: p("candleCards")
					}),
					/* @__PURE__ */ u("div", {
						className: "apb-candle-cards",
						children: le.filter((e) => !F(e, _.board, f.wild)).map((e) => /* @__PURE__ */ u("button", {
							className: b.chosen.includes(e) ? "apb-selected" : "",
							onClick: () => D(e),
							children: p(Z("project", e))
						}, e))
					})
				]
			})
		]
	}) : null;
	return /* @__PURE__ */ d(o, {
		adaptive: !0,
		scroll: !1,
		className: "apb-screen",
		banner: /* @__PURE__ */ d("header", {
			className: "apb-header",
			children: [
				/* @__PURE__ */ u("div", {
					className: "apb-title",
					children: te === "en" ? /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("span", { children: "A Place for" }), /* @__PURE__ */ u("strong", { children: "All My Books" })] }) : /* @__PURE__ */ u("strong", { children: p("name") })
				}),
				/* @__PURE__ */ u("div", {
					className: "apb-seats",
					children: f.players.map((e) => /* @__PURE__ */ u(vt, {
						p: e,
						member: r.find((t) => t.rid === e.rid),
						name: w(e.rid),
						active: e.rid === f.turn && f.phase !== "done",
						picked: v.rid === e.rid,
						onPick: () => {
							re(e.rid), ae("apartment"), h(null);
						}
					}, e.rid))
				}),
				/* @__PURE__ */ d(K, {
					name: "sun",
					className: "apb-sun",
					children: [/* @__PURE__ */ u("div", {
						className: "apb-sun-track",
						"aria-label": p("sun"),
						children: Array.from({ length: 9 }, (e, t) => /* @__PURE__ */ u("span", {
							className: t <= f.sun ? "apb-sun-filled" : "",
							children: t === f.sun ? "☀" : ""
						}, t))
					}), /* @__PURE__ */ u("span", { children: f.endRound !== null && f.round >= f.endRound ? p("finalRound") : p("round", { n: f.round }) })]
				})
			]
		}),
		actionsHeight: c ? void 0 : "apb-action-height",
		actions: !c && /* @__PURE__ */ d("footer", {
			className: "apb-action-bar",
			children: [/* @__PURE__ */ u("p", {
				"aria-live": "polite",
				children: L
			}), /* @__PURE__ */ u("div", { children: R })]
		}),
		children: [
			/* @__PURE__ */ d("div", {
				className: "apb-scene-tabs",
				children: [
					/* @__PURE__ */ u("button", {
						className: ie === "apartment" ? "apb-selected" : "",
						onClick: () => ae("apartment"),
						children: p("home")
					}),
					/* @__PURE__ */ u("button", {
						className: ie === "village" ? "apb-selected" : "",
						onClick: () => ae("village"),
						children: p("village")
					}),
					/* @__PURE__ */ u("button", {
						className: "apb-quiet",
						onClick: () => h({
							kind: "log",
							id: 0
						}),
						children: p("log")
					})
				]
			}),
			/* @__PURE__ */ d("div", {
				className: `apb-table apb-scene-${ie}`,
				children: [
					/* @__PURE__ */ d("section", {
						className: "apb-village",
						children: [
							/* @__PURE__ */ u("h2", { children: p("village") }),
							/* @__PURE__ */ d("div", {
								className: "apb-rooftops",
								"aria-hidden": !0,
								children: [
									/* @__PURE__ */ u("i", {}),
									/* @__PURE__ */ u("i", {}),
									/* @__PURE__ */ u("i", {}),
									/* @__PURE__ */ u("i", {})
								]
							}),
							/* @__PURE__ */ d(K, {
								name: "book-supply",
								className: "apb-decks",
								children: [
									/* @__PURE__ */ u(K, {
										name: "project-deck",
										children: /* @__PURE__ */ u(ut, {})
									}),
									/* @__PURE__ */ d(K, {
										name: "project-discard",
										children: [/* @__PURE__ */ u(lt, {}), /* @__PURE__ */ u("span", { children: f.projectDiscard.length })]
									}),
									/* @__PURE__ */ u(K, {
										name: "item-deck",
										children: /* @__PURE__ */ u(Y, { n: "?" })
									}),
									/* @__PURE__ */ u(K, {
										name: "item-discard",
										children: /* @__PURE__ */ u(Ut, { n: f.itemDiscard.length })
									})
								]
							}),
							/* @__PURE__ */ u("div", {
								className: "apb-shelves",
								children: f.shelves.map((e, t) => {
									let n = Te && _ && !_.pos.startsWith("bookstore") && _.energy >= Le(f.shelves, t), r = +(t === 2);
									return /* @__PURE__ */ d(K, {
										name: `shelf:${t}`,
										className: "apb-shelf",
										children: [
											/* @__PURE__ */ d("div", {
												className: "apb-shelf-heading",
												children: [p("shelf", { n: t + 1 }), /* @__PURE__ */ u(J, { n: Le(f.shelves, t) })]
											}),
											/* @__PURE__ */ d("button", {
												className: `apb-shelf-books${n ? " apb-legal" : ""}`,
												disabled: !n,
												onClick: () => E({
													type: "village",
													place: "bookstore",
													shelf: t,
													side: r
												}),
												children: [/* @__PURE__ */ u(bt, {
													tiles: e.books,
													compact: !0
												}), n && /* @__PURE__ */ u(st, {})]
											}),
											e.project !== null && /* @__PURE__ */ u("button", {
												className: "apb-shelf-project",
												onClick: () => h({
													kind: "project",
													id: e.project
												}),
												children: p(Z("project", e.project))
											}),
											n && t === 1 && f.players.length === 4 && /* @__PURE__ */ d("div", {
												className: "apb-side-choices",
												children: [/* @__PURE__ */ u("button", {
													onClick: () => E({
														type: "village",
														place: "bookstore",
														shelf: t,
														side: 0
													}),
													children: "←"
												}), /* @__PURE__ */ u("button", {
													onClick: () => E({
														type: "village",
														place: "bookstore",
														shelf: t,
														side: 1
													}),
													children: "→"
												})]
											})
										]
									}, t);
								})
							}),
							/* @__PURE__ */ u("div", {
								className: "apb-village-stops",
								children: ["library", "exchange"].map((e) => /* @__PURE__ */ d(K, {
									name: e,
									className: "apb-stop",
									children: [/* @__PURE__ */ d("button", {
										disabled: !Te || _?.pos === e || (_?.energy ?? 0) < (e === "library" && f.players.length === 4 ? 2 : 1),
										onClick: () => E({
											type: "village",
											place: e
										}),
										children: [p(e), /* @__PURE__ */ u(J, { n: e === "library" && f.players.length === 4 ? 2 : 1 })]
									}), /* @__PURE__ */ u(Wt, {
										v: f,
										place: e,
										nameOf: w
									})]
								}, e))
							}),
							/* @__PURE__ */ d(K, {
								name: "bookstore",
								className: "apb-bookstore-occupants",
								children: [
									/* @__PURE__ */ u(Wt, {
										v: f,
										place: "bookstore",
										nameOf: w
									}),
									/* @__PURE__ */ u(Wt, {
										v: f,
										place: "bookstore0",
										nameOf: w
									}),
									/* @__PURE__ */ u(Wt, {
										v: f,
										place: "bookstore1",
										nameOf: w
									})
								]
							}),
							/* @__PURE__ */ d(K, {
								name: "shop",
								className: "apb-shop",
								children: [
									/* @__PURE__ */ d("h3", { children: [p("shop"), /* @__PURE__ */ u(J, { n: _?.items.includes(16) ? 3 : 4 })] }),
									/* @__PURE__ */ u("div", {
										className: "apb-item-grid",
										children: f.shop.map((e) => /* @__PURE__ */ u(Ct, {
											id: e,
											onClick: () => h({
												kind: "item",
												id: e
											}),
											selected: b.chosen.includes(e),
											canBuy: !!Te && _?.pos !== "shop",
											onBuy: () => D(e)
										}, e))
									}),
									/* @__PURE__ */ d("div", {
										className: "apb-shop-controls",
										children: [/* @__PURE__ */ d("button", {
											disabled: !Te || _?.pos === "shop" || !b.chosen.length || b.chosen.some((e) => !f.shop.includes(e)) || (_?.energy ?? 0) < (b.chosen.length === 2 ? 9 : 4) - !!_?.items.includes(16),
											onClick: () => E({
												type: "village",
												place: "shop",
												items: b.chosen
											}),
											children: [b.chosen.length === 2 ? p("buyBoth") : p("buy"), /* @__PURE__ */ u(J, { n: (b.chosen.length === 2 ? 9 : 4) - !!_?.items.includes(16) })]
										}), /* @__PURE__ */ d("button", {
											disabled: !Te || _?.pos === "shop" || (_?.energy ?? 0) < (_?.items.includes(16) ? 2 : 3),
											onClick: () => E({
												type: "village",
												place: "shop",
												blind: !0
											}),
											children: [p("blind"), /* @__PURE__ */ u(J, { n: _?.items.includes(16) ? 2 : 3 })]
										})]
									}),
									/* @__PURE__ */ u(Wt, {
										v: f,
										place: "shop",
										nameOf: w
									})
								]
							}),
							/* @__PURE__ */ d(K, {
								name: "park",
								className: "apb-park",
								children: [/* @__PURE__ */ u("span", { children: p("park") }), /* @__PURE__ */ u(Wt, {
									v: f,
									place: "park",
									nameOf: w
								})]
							}),
							/* @__PURE__ */ u(K, {
								name: "cafe",
								children: /* @__PURE__ */ u(Wt, {
									v: f,
									place: "cafe",
									nameOf: w
								})
							}),
							f.rival && /* @__PURE__ */ d("div", {
								className: "apb-rival",
								children: [
									/* @__PURE__ */ d("h3", { children: [p("penelope"), /* @__PURE__ */ u(Y, { n: f.rival.score })] }),
									/* @__PURE__ */ u("span", { children: p("rivalDeck", { n: f.rival.deckCount }) }),
									/* @__PURE__ */ u("div", {
										className: "apb-rival-queue",
										children: f.rival.queue.map((e, t) => /* @__PURE__ */ u("span", {
											title: p("rivalCard", { letter: String.fromCharCode(65 + e) }),
											children: String.fromCharCode(65 + e)
										}, t))
									})
								]
							})
						]
					}),
					/* @__PURE__ */ d("section", {
						className: "apb-apartment",
						children: [
							/* @__PURE__ */ d(K, {
								name: "home",
								className: "apb-apartment-heading",
								children: [/* @__PURE__ */ u("h2", { children: w(v.rid) }), /* @__PURE__ */ u("span", { children: p("prefer", { color: p(O[v.mat]) }) })]
							}),
							/* @__PURE__ */ u("div", {
								className: "apb-home-actions",
								children: zt.map((e) => /* @__PURE__ */ u(K, {
									name: `home:${e}`,
									children: /* @__PURE__ */ d("button", {
										className: `${v.pos === e ? "apb-occupied" : ""}${de && fe && v.rid === a && v.pos !== e ? " apb-action-available" : ""}`,
										disabled: !de || !fe || v.rid !== a || v.pos === e || e === "leave" && (_?.energy ?? 0) < 6,
										onClick: () => E({
											type: "home",
											action: e
										}),
										children: [p(e), e === "gather" || e === "sort" ? /* @__PURE__ */ u(J, {
											n: 1,
											arrow: !0
										}) : e === "rest" || e === "read" ? /* @__PURE__ */ u(J, {
											n: 2,
											arrow: !0
										}) : e === "leave" ? /* @__PURE__ */ u(J, { n: 5 }) : /* @__PURE__ */ u(lt, {})]
									})
								}, e))
							}),
							/* @__PURE__ */ u(xt, {
								p: v,
								preview: k,
								legal: A,
								selected: y?.kind === "gather" ? b.sources.map((e) => e.cell) : b.source === null ? b.cells : [b.source],
								onCell: xe,
								readonly: c
							}),
							/* @__PURE__ */ d("div", {
								className: "apb-backpack",
								children: [
									/* @__PURE__ */ u("h3", { children: p("backpack") }),
									/* @__PURE__ */ u("div", {
										className: "apb-backpack-piles",
										children: v.bag.map((e, t) => /* @__PURE__ */ u(K, {
											name: `bag:${v.rid}:${t}`,
											children: /* @__PURE__ */ d("button", {
												className: `${y?.kind === "pack" && C ? "apb-legal" : ""}`,
												disabled: !(y?.kind === "pack" && C),
												onClick: () => {
													if (b.index !== null && !b.piles.flat().includes(b.index) && e.length + b.piles[t].length < 6) {
														let e = b.piles.map((e, n) => n === t ? [...e, b.index] : e);
														T({
															piles: e,
															index: null
														});
													}
												},
												children: [/* @__PURE__ */ u(bt, {
													tiles: [...e, ...y?.kind === "pack" && C ? b.piles[t].map((e) => y.cards[e]) : []],
													anchor: `${v.rid}:bag:${t}`
												}), y?.kind === "pack" && C && /* @__PURE__ */ u(st, {})]
											})
										}, t))
									}),
									de && !fe && v.rid === a && f.step === "main" && /* @__PURE__ */ u("button", {
										className: "apb-return",
										disabled: !Ie(Tt(v)).length,
										onClick: () => E({ type: "return" }),
										children: p("return")
									})
								]
							})
						]
					}),
					/* @__PURE__ */ d("aside", {
						className: "apb-journal",
						children: [
							B,
							/* @__PURE__ */ d("section", {
								className: "apb-hand",
								children: [
									/* @__PURE__ */ d("h2", { children: [p("projects"), /* @__PURE__ */ u("span", { children: p("completed", { n: _?.completed ?? 0 }) })] }),
									/* @__PURE__ */ u(K, {
										name: `hand:${a}`,
										className: "apb-project-grid",
										children: le.map((e) => /* @__PURE__ */ u(St, {
											id: e,
											board: _?.board ?? v.board,
											wild: f.wild,
											selected: b.chosen.includes(e),
											canChoose: N(e),
											onChoose: () => Se(e),
											onDetail: () => h({
												kind: "project",
												id: e
											})
										}, e))
									}),
									/* @__PURE__ */ d(K, {
										name: `completed:${a}`,
										className: "apb-completed",
										children: [/* @__PURE__ */ u(lt, {}), /* @__PURE__ */ u("b", { children: _?.completed ?? 0 })]
									})
								]
							}),
							/* @__PURE__ */ d("section", { children: [/* @__PURE__ */ u("h2", { children: p("majors") }), /* @__PURE__ */ u("div", {
								className: "apb-major-list",
								children: f.majors.map((e) => /* @__PURE__ */ u(wt, {
									id: e,
									claimable: I(e),
									claimed: _?.majors[e],
									onClaim: () => E({
										type: "claim",
										id: e
									}),
									onDetail: () => h({
										kind: "major",
										id: e
									})
								}, e))
							})] }),
							/* @__PURE__ */ d("section", { children: [/* @__PURE__ */ u("h2", { children: p("items") }), /* @__PURE__ */ u(K, {
								name: `items:${v.rid}`,
								className: "apb-item-grid",
								children: v.items.map((e) => /* @__PURE__ */ u(Ct, {
									id: e,
									used: v.used.includes(e),
									onClick: () => h({
										kind: "item",
										id: e
									})
								}, e))
							})] })
						]
					})
				]
			}),
			m && /* @__PURE__ */ u("div", {
				className: "apb-modal-backdrop",
				onClick: () => h(null),
				children: /* @__PURE__ */ d("section", {
					className: "apb-modal",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": p("details"),
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ u("button", {
							className: "apb-modal-close",
							onClick: () => h(null),
							children: p("close")
						}),
						m.kind === "item" && /* @__PURE__ */ d(l, { children: [
							/* @__PURE__ */ u("h2", { children: p(Z("item", m.id)) }),
							/* @__PURE__ */ u(Ct, {
								id: m.id,
								used: v.used.includes(m.id),
								onClick: () => {}
							}),
							/* @__PURE__ */ u("p", { children: p(Z("itemDesc", m.id)) }),
							/* @__PURE__ */ d("p", { children: [/* @__PURE__ */ u(Y, { n: he[m.id] || "?" }), me.includes(m.id) && p("flipNote")] }),
							m.id in pe && v.cats[m.id] !== void 0 && /* @__PURE__ */ u("p", { children: p(gt[v.cats[m.id]]) }),
							x && !y && _?.items.includes(m.id) && me.includes(m.id) && !_.used.includes(m.id) && /* @__PURE__ */ u("button", {
								onClick: () => {
									E({
										type: "flip",
										id: m.id
									}), h(null);
								},
								children: p("use")
							})
						] }),
						m.kind === "project" && /* @__PURE__ */ d(l, { children: [
							/* @__PURE__ */ u("h2", { children: p("projects") }),
							/* @__PURE__ */ u(St, {
								id: m.id,
								board: _?.board ?? v.board,
								wild: f.wild,
								onDetail: () => {}
							}),
							/* @__PURE__ */ u("p", { children: p(ye[m.id].reward === "energy" ? "gain" : "rewardItem", { n: 3 }) }),
							/* @__PURE__ */ u("p", { children: p("scoreTwo") })
						] }),
						m.kind === "major" && /* @__PURE__ */ d(l, { children: [
							/* @__PURE__ */ u("h2", { children: p("majors") }),
							/* @__PURE__ */ u("p", { children: p(Z("major", m.id)) }),
							/* @__PURE__ */ u("p", { children: p("majorReward", {
								first: Ce[m.id][0],
								later: Ce[m.id][1]
							}) }),
							/* @__PURE__ */ u("p", { children: p(m.id === 3 || m.id === 8 ? "majorItem" : "majorEnergy") }),
							I(m.id) && /* @__PURE__ */ u("button", {
								onClick: () => {
									E({
										type: "claim",
										id: m.id
									}), h(null);
								},
								children: p("claim")
							})
						] }),
						m.kind === "stack" && /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("h2", { children: m.id === 1 ? p("nightstand") : p("inspect") }), /* @__PURE__ */ u("div", {
							className: "apb-stack-detail",
							children: v.board[m.id].map((e, t) => {
								let n = x && y?.kind === "read" && v.rid === a && j(e) && (m.id === 1 || M(v.board[1]) < 6), r = x && y?.kind === "exchange" && m.id === 1 && S.includes(e);
								return /* @__PURE__ */ d("button", {
									className: b.chosen.includes(t) && r ? "apb-selected" : "",
									disabled: !n && !r,
									onClick: () => {
										n ? (E({
											type: "read",
											from: m.id,
											index: t
										}), h(null)) : r && (D(t), T({
											chosen: b.chosen.includes(t) ? b.chosen.filter((e) => e !== t) : [...b.chosen, t],
											colors: []
										}));
									},
									children: [
										/* @__PURE__ */ u(q, { tile: e }),
										/* @__PURE__ */ u("span", { children: p(e === "w0" || e === "w1" ? "wild" : e) }),
										t === be(v.board[m.id]) && /* @__PURE__ */ u("small", { children: p("topBook") })
									]
								}, t);
							})
						})] }),
						m.kind === "log" && /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u("h2", { children: p("log") }), /* @__PURE__ */ u("ol", {
							className: "apb-log",
							children: [...f.log].reverse().map((e, t) => {
								let n = e.kind === "project" || e.kind === "puzzle" ? p(Z("project", e.n)) : e.kind === "item" ? p(Z("item", e.n)) : e.kind === "major" ? p(Z("major", e.n)) : e.kind === "rival" ? p("rivalCard", { letter: String.fromCharCode(65 + e.n) }) : e.kind in mt ? p(e.kind) : p("confirm");
								return /* @__PURE__ */ u("li", { children: p("logEvent", {
									name: w(e.rid),
									action: n
								}) }, t);
							})
						})] })
					]
				})
			})
		]
	});
}
function Ut({ n: e }) {
	let t = X();
	return /* @__PURE__ */ d("span", {
		title: t("discardPile"),
		children: [/* @__PURE__ */ u(Y, { n: "?" }), e]
	});
}
function Wt({ v: e, place: t, nameOf: n }) {
	return /* @__PURE__ */ d("div", {
		className: "apb-occupants",
		children: [e.players.filter((e) => e.pos === t).map((e) => /* @__PURE__ */ u("span", {
			className: `apb-occupant apb-color-${O[e.mat]}`,
			children: n(e.rid)
		}, e.rid)), e.rival?.pos === t && /* @__PURE__ */ u("span", {
			className: "apb-occupant apb-penelope",
			children: n("penelope")
		})]
	});
}
//#endregion
//#region src/games/aplaceforallmybooks/fx.tsx
function Gt(e, t = 43, n = 55) {
	return {
		x: e.x + (e.w - t) / 2,
		y: e.y + (e.h - n) / 2,
		w: t,
		h: n
	};
}
var Kt = {
	tile(e, t) {
		let n = e.data, r = t.anchor(n.from) ?? t.anchor(`seat:${e.rid}`), i = t.anchor(n.to) ?? t.anchor(`seat:${e.rid}`);
		if (!r || !i) return null;
		let a = `tile:${e.rid}:${n.to.startsWith("bag:") ? `bag:${n.to.split(":").at(-1)}` : `cell:${n.to.split(":").at(-1)}`}:${n.index}`, o = t.queued ? 160 : 360;
		return {
			ms: o + 30,
			hide: t.queued || !n.to.startsWith("cell:") && !n.to.startsWith("bag:") ? [] : [a],
			node: /* @__PURE__ */ u(re, {
				from: Gt(r),
				to: Gt(i),
				ms: o,
				children: /* @__PURE__ */ u("div", {
					style: {
						width: 43,
						height: 55
					},
					children: /* @__PURE__ */ u(q, { tile: n.tile })
				})
			})
		};
	},
	card(e, t) {
		let n = e.data, r = e.rid === t.myRid, i = t.anchor(n.from) ?? t.anchor(r ? `hand:${e.rid}` : `seat:${e.rid}`), a = t.anchor(n.to) ?? t.anchor(`seat:${e.rid}`);
		if (!i || !a) return null;
		let o = t.queued ? 150 : 340;
		return {
			ms: o + 30,
			node: /* @__PURE__ */ u(re, {
				from: Gt(i, 38, 54),
				to: Gt(a, 38, 54),
				ms: o,
				children: /* @__PURE__ */ u(ut, {})
			})
		};
	},
	energy(e, t) {
		let n = e.data.n;
		if (!n) return null;
		let r = t.anchor(`energy:${e.rid}`) ?? t.anchor(`seat:${e.rid}`);
		return r ? {
			ms: 420,
			node: /* @__PURE__ */ u(ne, {
				at: r,
				ms: 420,
				children: /* @__PURE__ */ d("span", {
					style: {
						color: n > 0 ? "#467230" : "#8a4545",
						fontSize: 22,
						fontWeight: 900,
						textShadow: "0 1px #fff9df"
					},
					children: [n > 0 ? "+" : "", n]
				})
			})
		} : null;
	},
	claim(e, t) {
		let n = e.data, r = t.anchor(n.from), i = t.anchor(n.to) ?? t.anchor(`seat:${e.rid}`);
		return r && i ? {
			ms: 480,
			node: /* @__PURE__ */ u(re, {
				from: Gt(r, 44, 44),
				to: Gt(i, 44, 44),
				ms: 440,
				children: /* @__PURE__ */ u(Y, {})
			})
		} : null;
	},
	flip(e, t) {
		let n = t.anchor(`item:${e.data.id}`);
		return n ? {
			ms: 360,
			node: /* @__PURE__ */ u(ie, {
				at: n,
				ms: 360
			})
		} : null;
	},
	walk(e, t) {
		let n = e.data, r = t.anchor(n.to), i = t.anchor(n.from) ?? t.anchor(`seat:${e.rid}`);
		return r && i ? {
			ms: 400,
			node: /* @__PURE__ */ u(re, {
				from: Gt(i, 23, 29),
				to: Gt(r, 23, 29),
				ms: 360,
				children: /* @__PURE__ */ u("span", { style: {
					display: "block",
					width: 23,
					height: 29,
					background: e.rid === "penelope" ? "#d799b6" : "#677e5a",
					border: "2px solid #fff3ce",
					borderRadius: "50% 50% 5px 5px",
					boxShadow: "1px 2px 2px #4a493855"
				} })
			})
		} : null;
	},
	sun(e, t) {
		let n = t.anchor("sun");
		return n ? {
			ms: 430,
			node: /* @__PURE__ */ u(ie, {
				at: n,
				ms: 430
			})
		} : null;
	},
	rivals(e, t) {
		let n = t.anchor("cafe") ?? t.anchor("sun");
		return n ? {
			ms: 400,
			node: /* @__PURE__ */ u(ie, {
				at: n,
				ms: 400
			})
		} : null;
	},
	exchange(e, t) {
		let n = t.anchor(e.data.from);
		return n ? {
			ms: 300,
			node: /* @__PURE__ */ u(ie, {
				at: n,
				ms: 300
			})
		} : null;
	}
};
//#endregion
//#region src/games/aplaceforallmybooks/game-over.tsx
function qt(e) {
	let t = e.public, r = X(), o = a(), s = i((e) => e.locale), [c, f] = n(!0), ee = (n) => {
		let i = e.members.find((e) => e.rid === n), a = t.players.find((e) => e.rid === n);
		return ht(i, s, r(a ? O[a.mat] : "home"));
	}, p = t.rival ? r(e.result.winner.length ? "soloWin" : "soloLoss") : e.result.winner.length > 1 ? r("sharedWin") : r("winner", { name: ee(e.result.winner[0] ?? e.myRid) }), te = [
		["books", "resultBooks"],
		["projects", "resultProjects"],
		["items", "resultItems"],
		["majors", "resultMajors"],
		["energy", "resultEnergy"]
	];
	return /* @__PURE__ */ d("div", {
		className: "apb-over",
		children: [
			/* @__PURE__ */ u(Ht, {
				...e,
				send: () => {},
				readOnly: !0
			}),
			/* @__PURE__ */ u("div", {
				className: `apb-result-curtain${c ? " apb-result-open" : ""}`,
				"aria-hidden": !c,
				children: /* @__PURE__ */ d("section", {
					className: "apb-result-sheet",
					role: "dialog",
					"aria-label": r("resultTitle"),
					"aria-modal": c,
					children: [
						/* @__PURE__ */ u("button", {
							className: "apb-result-close",
							onClick: () => f(!1),
							children: r("review")
						}),
						/* @__PURE__ */ d("header", { children: [
							/* @__PURE__ */ d("span", {
								className: "apb-result-books",
								children: [
									/* @__PURE__ */ u(q, { tile: "r" }),
									/* @__PURE__ */ u(q, { tile: "g" }),
									/* @__PURE__ */ u(q, { tile: "b" })
								]
							}),
							/* @__PURE__ */ u("h1", { children: r("resultTitle") }),
							/* @__PURE__ */ u("p", { children: p }),
							t.rival?.lost && /* @__PURE__ */ u("p", {
								className: "apb-result-warning",
								children: r("rivalLost")
							})
						] }),
						/* @__PURE__ */ d("div", {
							className: "apb-result-scroll",
							children: [
								/* @__PURE__ */ d("table", { children: [/* @__PURE__ */ u("thead", { children: /* @__PURE__ */ d("tr", { children: [
									/* @__PURE__ */ u("th", {}),
									/* @__PURE__ */ u(l, { children: e.result.ranking.map((t) => /* @__PURE__ */ d("th", { children: [
										/* @__PURE__ */ u(_t, {
											name: ee(t),
											member: e.members.find((e) => e.rid === t)
										}),
										/* @__PURE__ */ u("span", { children: ee(t) }),
										e.result.winner.includes(t) && /* @__PURE__ */ u(Y, {})
									] }, t)) }),
									t.rival && /* @__PURE__ */ u("th", { children: r("penelope") })
								] }) }), /* @__PURE__ */ d("tbody", { children: [te.map(([n, i]) => /* @__PURE__ */ d("tr", { children: [
									/* @__PURE__ */ u("th", { children: r(i) }),
									e.result.ranking.map((e) => /* @__PURE__ */ u("td", { children: t.players.find((t) => t.rid === e)?.score[n] ?? 0 }, e)),
									t.rival && /* @__PURE__ */ u("td", { children: n === "books" ? t.rival.books : n === "projects" ? t.rival.projects * 2 : n === "items" ? t.rival.score - t.rival.books - t.rival.projects * 2 : "—" })
								] }, n)), /* @__PURE__ */ d("tr", {
									className: "apb-result-total",
									children: [
										/* @__PURE__ */ u("th", { children: r("total") }),
										e.result.ranking.map((n) => /* @__PURE__ */ u("td", { children: e.result.scores?.[n] ?? t.players.find((e) => e.rid === n)?.score.total }, n)),
										t.rival && /* @__PURE__ */ u("td", { children: t.rival.score })
									]
								})] })] }),
								e.hintCount !== void 0 && e.hintCount > 0 && /* @__PURE__ */ u("p", { children: r("assist", { n: e.hintCount }) }),
								e.result.ranking.filter((t) => (e.result.autopilot?.[t] ?? 0) > 0).map((t) => /* @__PURE__ */ d("p", { children: [
									ee(t),
									" · ",
									r("autopilot", { n: Math.round((e.result.autopilot?.[t] ?? 0) * 100) })
								] }, t))
							]
						}),
						/* @__PURE__ */ d("footer", { children: [
							e.onPlayAgain && /* @__PURE__ */ u("button", {
								onClick: e.onPlayAgain,
								children: o("session.result.playAgain")
							}),
							e.onBackToLobby && /* @__PURE__ */ u("button", {
								onClick: e.onBackToLobby,
								children: o("session.result.backToLobby")
							}),
							!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ u("span", { children: o("session.result.waitHost") })
						] })
					]
				})
			}),
			/* @__PURE__ */ u("button", {
				className: "apb-show-results",
				onClick: () => f(!0),
				children: r("results")
			})
		]
	});
}
//#endregion
//#region src/games/aplaceforallmybooks/options.tsx
function Jt({ value: e, onChange: t }) {
	let n = X(), r = v.safeParse(e), i = r.success ? r.data : v.parse(void 0);
	return /* @__PURE__ */ d("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ d(m, {
			title: n("optBase"),
			children: [/* @__PURE__ */ u(h, {
				checked: i.pins,
				label: n("optPins"),
				accent: oe.accent,
				onChange: () => t({
					...i,
					pins: !i.pins
				})
			}), /* @__PURE__ */ u(h, {
				checked: i.notes,
				label: n("optNotes"),
				accent: oe.accent,
				onChange: () => t({
					...i,
					notes: !i.notes
				})
			})]
		}), /* @__PURE__ */ u(m, {
			title: n("optSolo"),
			children: [
				1,
				2,
				3,
				4,
				5
			].map((e) => /* @__PURE__ */ u(ae, {
				name: "books-solo",
				value: String(e),
				label: n("level", { n: e }),
				checked: i.soloLevel === e,
				accent: oe.accent,
				onChange: () => t({
					...i,
					soloLevel: e
				})
			}, e))
		})]
	});
}
//#endregion
//#region src/games/aplaceforallmybooks/guide.tsx
function Yt() {
	let e = X();
	return /* @__PURE__ */ d("div", {
		className: "apb-guide",
		children: [
			[
				"r",
				"y",
				"b",
				"g",
				"w0",
				"lamp",
				"ends"
			].map((t) => /* @__PURE__ */ d("span", { children: [/* @__PURE__ */ u(q, { tile: t }), e(t === "w0" ? "wild" : t)] }, t)),
			/* @__PURE__ */ d("span", { children: [/* @__PURE__ */ u(J, {}), e("battery")] }),
			/* @__PURE__ */ d("span", { children: [/* @__PURE__ */ u(Y, {}), e("points")] }),
			/* @__PURE__ */ d("span", { children: [/* @__PURE__ */ u(lt, {}), e("projects")] }),
			/* @__PURE__ */ d("span", { children: [/* @__PURE__ */ u(ct, {}), e("items")] })
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/aplaceforallmybooks/entry.tsx
var Xt = {
	definition: at,
	View: Vt,
	bot: Ft,
	describe: It,
	fx: Kt,
	OverView: qt,
	Options: Jt,
	Guide: Yt,
	locales: {
		zh: {
			name: "我的书香地",
			desc: "整理书堆，补充社交电量，再去村庄寻找更多好书。",
			errAction: "现在无法执行这个行动，请检查选择和所需电量。",
			gather: "集中",
			sort: "整理",
			read: "阅读",
			rest: "休息",
			admire: "欣赏",
			leave: "出门",
			bookstore: "二手书店",
			library: "图书馆",
			shop: "村庄商店",
			exchange: "换书处",
			park: "公园",
			home: "公寓",
			cafe: "咖啡馆",
			bedroom: "卧室",
			den: "书房",
			bath: "浴室",
			kitchen: "厨房",
			nightstand: "床头柜",
			r: "红色",
			y: "黄色",
			b: "蓝色",
			g: "绿色",
			wild: "万能书",
			lamp: "台灯",
			ends: "书挡",
			round: "第 {{n}} 轮",
			sun: "太阳进度",
			finalRound: "最后一轮",
			turn: "轮到 {{name}}",
			waiting: "等待 {{name}} 完成选择",
			battery: "社交电量",
			energy: "电量",
			points: "分数",
			books: "藏书",
			projects: "小项目",
			items: "精巧物品",
			majors: "大成就",
			backpack: "背包",
			collection: "我的公寓",
			village: "村庄",
			draftPrompt: "选择想保留的 3 张小项目。",
			confirmDraft: "保留所选项目",
			gatherPrompt: "依次选择最多 6 堆的顶书，再选择叠放位置。",
			sortPrompt: "选择一堆书，再逐本选择落点。每处最多放入 2 本。",
			readPrompt: "选择任意一堆中的一本书，移到床头柜。",
			discardPrompt: "选择并弃掉 {{n}} 张项目。",
			libraryPrompt: "选择要保留的 {{n}} 本书。",
			packPrompt: "选择待装入的书，再选择背包中的一堆；满溢的书将退回袋中。",
			unloadPrompt: "依次为两堆背包书选择公寓落点，保持整堆顺序。",
			exchangePrompt: "选择床头柜要换出的书，再选择新书颜色。",
			tilePrompt: "选择物品的放置位置。",
			kittyPrompt: "为招财猫选择一个房间。",
			wildPrompt: "选择这本万能书在本次欣赏中的颜色。",
			shelfPrompt: "选择要获得的两本同色书的颜色。",
			admirePrompt: "选择已完成的项目，逐张领取奖励。",
			puzzlePrompt: "可将一张项目直接放入计分堆，不领取奖励。",
			succulentsPrompt: "选择一堆中的书，再把它们放到同一个位置。",
			recordPrompt: "选择要弃掉的项目，然后摸牌至手中有 5 张。",
			laptopPrompt: "从弃物品堆中选择一张，免费获得。",
			snowglobePrompt: "选择一件商店物品，免费获得。",
			removePrompt: "选择一种颜色，或选择无色，移回对应的对手牌。",
			rivalPrompt: "Penelope 正在村庄行动。",
			afterPrompt: "可以使用物品或领取成就，然后结束回合。",
			mainPrompt: "选择一个不同的行动位置。",
			confirm: "确认",
			cancel: "取消选择",
			close: "关闭",
			skip: "跳过",
			end: "结束回合",
			finishAdmire: "结束欣赏",
			return: "回家",
			none: "无色",
			use: "使用",
			used: "已使用",
			details: "查看详情",
			claim: "领取成就",
			completed: "已完成 {{n}} 张",
			handCount: "手中有 {{n}} 张项目",
			cost: "支付 {{n}} 点电量",
			gain: "获得 {{n}} 点电量",
			rewardItem: "获得一张盲抽物品",
			scoreTwo: "终局计 2 分",
			shelf: "书架 {{n}}",
			buy: "购买",
			buyBoth: "购买两件",
			blind: "盲抽一件",
			viewApartment: "查看 {{name}} 的公寓",
			cell: "{{room}}，第 {{row}} 行第 {{col}} 列，{{n}} 本书",
			chooseBook: "选择{{color}}书",
			moveTo: "放到此处",
			selected: "已选 {{n}}",
			ready: "可以完成",
			notReady: "尚未完成",
			drawPile: "抽牌堆",
			discardPile: "弃牌堆",
			empty: "空",
			inspect: "查看书堆",
			topBook: "顶书",
			to: "落点",
			nextBook: "下一本",
			chosenDestination: "选择落点",
			prefer: "偏爱{{color}}书",
			majorReward: "首位 {{first}} 分，其后 {{later}} 分",
			majorEnergy: "同时获得 3 点电量。",
			majorItem: "同时盲抽一张物品。",
			flipNote: "整局可使用一次；使用后仍计分。",
			candleEnergy: "弃两张未完成项目，获得 3 点电量",
			candleCards: "弃两张未完成项目，摸 2 张项目",
			chain: "弃一张项目，再执行{{action}}",
			chooseDiscard: "先选择一张项目作为代价。",
			penelope: "Penelope",
			rivalQueue: "对手队列",
			rivalDeck: "剩余对手牌 {{n}} 张",
			rivalCard: "对手牌 {{letter}}",
			rivalLost: "Penelope 无法摸出对手牌，你本局落败。",
			resultTitle: "一屋好书",
			winner: "{{name}} 获胜",
			sharedWin: "共同获胜",
			soloWin: "你赢过了 Penelope",
			soloLoss: "Penelope 赢得了这场较量",
			total: "总分",
			review: "回看公寓",
			results: "查看计分",
			resultEnergy: "剩余电量",
			resultMajors: "大成就",
			resultProjects: "完成的项目",
			resultItems: "物品得分",
			resultBooks: "藏书得分",
			assist: "求助次数：{{n}}",
			autopilot: "托管：{{n}}%",
			optBase: "附加内容",
			optPins: "收藏徽章",
			optNotes: "感谢信",
			optSolo: "单人难度",
			level: "等级 {{n}}",
			hintHome: "在公寓选择一个行动，整理藏书或补充社交电量。",
			hintVillage: "前往村庄中的一个位置，领取书籍或购买物品。",
			hintTask: "完成当前书籍或卡牌的选择。",
			log: "最近行动",
			logEvent: "{{name}}：{{action}}",
			first: "首位",
			bookendsRule: "书挡在本次欣赏中仅奖励一次；项目需使用它所在的书堆。",
			project0: "四个角落合计有至少 4 本绿书。",
			project1: "有一堆书同时包含至少 2 本绿书与 2 本黄书。",
			project2: "有至少 3 本蓝色独本。",
			project3: "四个角落合计有至少 4 本黄书。",
			project4: "有至少 3 个不含黄书的高堆。",
			project5: "厨房有至少 3 个高堆。",
			project6: "有至少 3 本红色独本。",
			project7: "每行及每列都至少有一本书。",
			project8: "书房和厨房都没有红书。",
			project9: "有一堆恰好 4 本书，四色各一本。",
			project10: "四个角落合计有至少 4 本红书。",
			project11: "有至少 3 个不含蓝书的高堆。",
			project12: "中央四格全部没有书。",
			project13: "有至少 3 个不含绿书的高堆。",
			project14: "书房和厨房都没有蓝书。",
			project15: "每个房间恰好有一个没有书的格子。",
			project16: "某一整行的四个书堆顶色相同。",
			project17: "中央四格有至少 3 堆顶为红色。",
			project18: "书房和厨房都没有绿书。",
			project19: "四个角落全部没有书。",
			project20: "四个角落都有书，且顶书颜色相同。",
			project21: "同一个房间至少有 3 堆顶为绿色。",
			project22: "所有非空书堆都有至少 3 本书。",
			project23: "书房和厨房都没有黄书。",
			project24: "中央四格有至少 3 堆顶为黄色。",
			project25: "某一整列的四个书堆顶色相同。",
			project26: "有一堆书包含至少 4 本黄书。",
			project27: "有至少 3 个不含红书的高堆。",
			project28: "卧室和浴室都没有黄书。",
			project29: "同一个房间至少有 3 堆顶为红色。",
			project30: "有一堆书包含至少 4 本红书。",
			project31: "中央四格有至少 3 堆顶为蓝色。",
			project32: "同一个房间至少有 3 堆顶为蓝色。",
			project33: "有一堆书同时包含至少 2 本蓝书与 2 本红书。",
			project34: "有一堆书包含至少 4 本绿书。",
			project35: "四个角落都是独本。",
			project36: "中央四格有至少 3 堆顶为绿色。",
			project37: "卧室和浴室都没有蓝书。",
			project38: "同一个房间至少有 3 堆顶为黄色。",
			project39: "每个房间恰好有一个高堆。",
			project40: "床头柜有至少 4 本同色书。",
			project41: "没有任何独本。",
			project42: "卧室和浴室都没有绿书。",
			project43: "卧室和浴室都没有红书。",
			project44: "四个角落合计有至少 4 本蓝书。",
			project45: "卧室有至少 3 个高堆。",
			project46: "某个房间的每个格子都是独本。",
			project47: "中央四格有至少 3 个高堆。",
			project48: "有一个 3×3 正方形，其中九格都有书。",
			project49: "有一堆书包含至少 4 本蓝书。",
			project50: "有至少 3 本黄色独本。",
			project51: "有一堆恰好 6 本书。",
			project52: "有至少 3 本绿色独本。",
			project53: "没有任何高堆。",
			project54: "书房有至少 3 个高堆。",
			item0: "收藏徽章",
			itemDesc0: "收藏徽章有 1／2／3／4 张以上时，整组共计 2／6／12／20 分。",
			item1: "毛绒玩具",
			itemDesc1: "每本独本计 1 分，最多 7 分。",
			item2: "收藏徽章",
			itemDesc2: "收藏徽章有 1／2／3／4 张以上时，整组共计 2／6／12／20 分。",
			item3: "绿书招财猫",
			itemDesc3: "获得时放在一个房间旁。该房间每本绿书计 1 分，最多 5 分。",
			item4: "台灯",
			itemDesc4: "获得时将台灯放在任意书堆。阅读时若从该堆拿书，额外获得 1 点电量并摸 1 张项目。",
			item5: "收藏徽章",
			itemDesc5: "收藏徽章有 1／2／3／4 张以上时，整组共计 2／6／12／20 分。",
			item6: "蓝书招财猫",
			itemDesc6: "获得时放在一个房间旁。该房间每本蓝书计 1 分，最多 5 分。",
			item7: "柔软毛毯",
			itemDesc7: "每个至少有两个无书格的房间额外计 1 分。",
			item8: "收藏徽章",
			itemDesc8: "收藏徽章有 1／2／3／4 张以上时，整组共计 2／6／12／20 分。",
			item9: "拼图",
			itemDesc9: "每次阅读时，可以将手中 1 张项目直接放入计分堆，不领取奖励。",
			item10: "感谢信",
			itemDesc10: "你领取大成就时，你获得 3 点电量，其他每位玩家各获得 1 点。终局每个已完成大成就额外计 1 分。",
			item11: "法压壶",
			itemDesc11: "翻面使用一次，立即获得 4 点电量。",
			item12: "桌游 · SHŌBU",
			itemDesc12: "桌游有 1／2／3／4 张以上时，整组共计 2／6／12／20 分。",
			item13: "邮差包",
			itemDesc13: "获得时摸 2 张项目。每次使用图书馆时，多摸并保留 1 本书。",
			item14: "图像小说",
			itemDesc14: "获得时得到 1 本紫色万能书。每次欣赏时，为这本书指定颜色，持续至你的回合结束。",
			item15: "收藏徽章",
			itemDesc15: "收藏徽章有 1／2／3／4 张以上时，整组共计 2／6／12／20 分。",
			item16: "舒适运动鞋",
			itemDesc16: "获得时摸 2 张项目。每次在商店购买或盲抽物品，少支付 1 点电量。",
			item17: "桌游 · HIFI",
			itemDesc17: "桌游有 1／2／3／4 张以上时，整组共计 2／6／12／20 分。",
			item18: "黄书招财猫",
			itemDesc18: "获得时放在一个房间旁。该房间每本黄书计 1 分，最多 5 分。",
			item19: "图像小说",
			itemDesc19: "获得时得到 1 本紫色万能书。每次欣赏时，为这本书指定颜色，持续至你的回合结束。",
			item20: "艺术画",
			itemDesc20: "获得时摸 2 张项目。每次休息多摸 1 张项目。",
			item21: "皮革手账",
			itemDesc21: "翻面使用一次，立即执行一次欣赏，即使你不在家。",
			item22: "笔记本电脑",
			itemDesc22: "翻面使用一次，免费拿取弃物品堆中的 1 张物品。",
			item23: "多肉植物",
			itemDesc23: "翻面使用一次，从单个书堆中拿任意数量的书，以任意顺序放到同一处顶端。",
			item24: "可爱围巾",
			itemDesc24: "被挤到公园时，获得 2 点电量并摸 2 张项目，然后弃至手中有 5 张。",
			item25: "桌游 · BOOOOP",
			itemDesc25: "桌游有 1／2／3／4 张以上时，整组共计 2／6／12／20 分。",
			item26: "桌游 · BOOP THE HALLS",
			itemDesc26: "桌游有 1／2／3／4 张以上时，整组共计 2／6／12／20 分。",
			item27: "单反相机",
			itemDesc27: "获得时摸 2 张项目。终局手中每张项目计 1 分。",
			item28: "唱片机",
			itemDesc28: "翻面使用一次，弃掉任意数量项目，然后摸至手中有 5 张。",
			item29: "小夜灯",
			itemDesc29: "床头柜每种不同颜色的书额外计 1 分。",
			item30: "温暖连帽衫",
			itemDesc30: "获得时增加 2 点电量；若在村庄，移到公园且不触发公园奖励。每次欣赏获得 1 点电量。",
			item31: "豆袋椅",
			itemDesc31: "每次休息额外获得 3 点电量。",
			item32: "美术用品",
			itemDesc32: "每次欣赏时，若恰好有 10 个非空书堆，获得 3 点电量。",
			item33: "绒毛毛衣",
			itemDesc33: "获得时增加 2 点电量；若在村庄，移到公园且不触发公园奖励。每次换书额外获得 1 本自选色书。",
			item34: "编织套装",
			itemDesc34: "每次欣赏结束时，若手中没有项目，获得 3 点电量。",
			item35: "书架",
			itemDesc35: "获得时，从袋中选择两本同色书。",
			item36: "耳机",
			itemDesc36: "每次换书时，每退回一种不同颜色，额外随机摸 1 本书。",
			item37: "装饰马克杯",
			itemDesc37: "每次集中后，可弃 1 张项目，立即执行一次整理。",
			item38: "可爱钥匙链",
			itemDesc38: "每次整理后，可弃 1 张项目，立即执行一次集中。",
			item39: "雪景球",
			itemDesc39: "翻面使用一次，免费获得商店展示的 1 张物品，然后照常刷新商店。",
			item40: "精美书挡",
			itemDesc40: "获得时将书挡放在任意书堆。每次欣赏时，若项目使用该堆，获得 2 点电量。",
			item41: "桌游 · BOOP",
			itemDesc41: "桌游有 1／2／3／4 张以上时，整组共计 2／6／12／20 分。",
			item42: "红书招财猫",
			itemDesc42: "获得时放在一个房间旁。该房间每本红书计 1 分，最多 5 分。",
			item43: "桌游 · A PLACE FOR ALL MY BOOKS",
			itemDesc43: "桌游有 1／2／3／4 张以上时，整组共计 2／6／12／20 分。",
			item44: "收藏徽章",
			itemDesc44: "收藏徽章有 1／2／3／4 张以上时，整组共计 2／6／12／20 分。",
			item45: "禅意花园",
			itemDesc45: "每次欣赏时，最高与最矮非空书堆的高度差不超过 2 本，则获得 3 点电量。",
			item46: "熔岩灯",
			itemDesc46: "每个恰好 6 本的书堆额外计 2 分，最多额外 6 分。",
			item47: "香薰蜡烛",
			itemDesc47: "每次欣赏时，可弃 2 张未完成的手中项目，选择获得 3 点电量或摸 2 张项目。",
			item48: "展示柜",
			itemDesc48: "终局自己的每张物品计 1 分，包括展示柜。",
			major0: "拥有至少 4 件物品。",
			major1: "计分堆中至少有 6 张项目。",
			major2: "公寓中每种普通颜色都有至少 6 本书。",
			major3: "床头柜有恰好 6 本同色书。",
			major4: "有至少两个高堆，各自全部为同色书。",
			major5: "16 格都有书，且正交相邻的顶书颜色均不同。",
			major6: "有至少三个恰好 6 本的书堆。",
			major7: "有至少 7 堆顶书的颜色相同。",
			major8: "某次欣赏的电量总计达到至少 24 点。",
			major9: "每个房间都有一个高堆，四堆包含的颜色及数量完全相同。",
			rules: "你喜欢好书，也珍惜在家整理藏书的安静时光。你要在公寓中完成小项目，补充社交电量，再去村庄带回书籍与物品。终局分数最高者获胜。\n\n准备：\n每位玩家获得一间公寓、12 本初始书和 5 张小项目，并选择保留 3 张项目。按座次分别以 3、4、5、6 点社交电量开始。书店的三层书架分别有 3、2、1 本随机书及一张公开项目；商店展示两件物品，另有三张公共大成就。\n\n公寓与书堆：\n公寓共有四行四列，分为卧室、书房、浴室和厨房。卧室上方靠右的一格是床头柜。每格最多放 6 本书；一格仅有一本书时称为独本，至少有 3 本时称为高堆。书堆里的颜色顺序有意义。台灯和书挡不算书，不占高度；它们位于书堆上方，不妨碍拿取下方顶书。\n\n回合：\n轮到你时，必须移动到一个不同的行动位置并执行其行动。在公寓中获得电量，在村庄中支付电量；电量最多储存 20 点。行动及附带选择结束后，你可以使用尚未翻面的物品、领取满足条件的大成就，然后结束回合。你不能进入别人的公寓。\n\n家中行动：\n· 集中：获得 1 点电量。从最多 6 个不同书堆中各拿一本顶书，以任意顺序叠放到同一格，最终不得超过 6 本。台灯与书挡也可以一并移动。\n· 整理：获得 1 点电量。拿起整堆书，以任意顺序逐本放到任意格，包括原格。每个落点最多放入两本书，最终每堆不超过 6 本；台灯和书挡不占两本额度。\n· 阅读：获得 2 点电量。从任意一堆的任意深度拿一本书，放到床头柜顶端，仍遵守高度上限。\n· 休息：获得 2 点电量，并摸 2 张项目；若手中超过 5 张项目，弃至 5 张。其他行动获得项目不会自动触发这个手牌上限。\n· 欣赏：先检查角色偏爱的颜色。若该颜色在家中的数量最多，包含并列最多，获得 3 点电量。然后展示当前布局已经完成的小项目并逐张领取奖励：每张通常获得 3 点电量，或盲抽一张物品。完成的项目放入计分堆，每张终局计 2 分；书籍不消耗。项目所说的书只计算公寓中的书，不含背包。紫色万能书在每次欣赏时分别指定颜色，回合结束后恢复为紫色。\n· 出门：支付 5 点电量，太阳前进一格，立即在同一回合执行一次村庄行动，并支付该行动的费用。\n\n村庄行动：\n村庄的位置由所有人共享。你可以选择别人所在的位置，将对方挤到公园，对方获得 2 点电量。你不能主动前往公园。\n· 二手书店：按三层书架当前书量从少到多，分别支付 1、3 或 6 点电量，获得该架全部书和项目。随后补一张项目，并给每个书架各加一本随机书。书量相同时按书架从左到右定价。四人局有左右两个独立位置，左边只能拿左架或中架，右边只能拿右架或中架；不能在连续回合从一个书店位置移到另一个。\n· 图书馆：一至三人局支付 1 点电量，随机摸 4 本书并保留 1 本；四人局支付 2 点，摸 5 本并保留 2 本。其余三本打乱后，分别放到三个书架上。\n· 村庄商店：支付 4 点电量购买一件展示物品，或支付 9 点购买两件；也可以支付 3 点盲抽一件。购买展示物品后，将剩余展示物品弃掉，再展示两件；盲抽不会刷新展示。物品立即归你所有，并执行获得时能力。\n· 换书处：支付 1 点电量。将床头柜中任意数量的普通书退回袋中，包括零本；再取回退还数量加一本的自选颜色书，放进背包。紫色万能书不能换出。\n\n背包与回家：\n新获得的一批书可以任意排序，分放在背包的两个书堆顶端；每堆最多 6 本，满溢的书退回袋中。放好后不能重新排列，后续得到的书只能加在顶端。\n若在村庄开始回合，可以选择回家。先将背包的两堆书各自完整放到公寓中的格子上；不能拆堆或改变顺序，每处仍不得超过 6 本。然后立即执行一个家中行动。若没有合法卸载位置，就不能回家。\n\n物品与大成就：\n点击物品可以查看完整能力。标明翻面使用的物品整局限用一次；翻面后仍计分。小项目以当前布局判定，不消耗书。大成就一旦满足便可领取，不消耗行动；首位完成者获得较高分，其后完成者获得较低分，资源奖励相同，每位玩家每张成就只能领取一次。书挡在每次欣赏中至多提供一次奖励，且须有完成项目使用它所在的书堆。仅要求无书或没有某色的项目不触发书挡。\n\n结束与计分：\n太阳轨道有八格。单人及两人局从第三格、三人局从第一格、四人局从起点出发；到达第八格后完成当前轮，确保每人行动次数相同，然后每人再进行最后一个回合。\n· 公寓和背包中的每本书计 1 分。\n· 计分堆中的每张项目计 2 分。\n· 按物品卡和已领取大成就计分。\n· 每剩余 4 点电量计 1 分。\n分数相同时，藏书更多者获胜；仍相同则共同获胜。\n\n单人模式：Penelope\n选择难度一至五，分别使用 A–J、B–K、C–L、D–M、E–N 的十张对手牌。你先手并以 3 点电量开始，太阳使用两人起点。每次你的回合结束后，Penelope 抽一张对手牌加入队列，按新牌上对应队列张数的区间行动：1–3、4–5、6–7 或至少 8 张。\n· 她在图书馆获得一本随机书，并给每架补一本；在书店获得指定书架的全部书和项目，再正常补架；商店按牌说明拿取或弃掉物品；咖啡馆没有基础收益。\n· 她到公园时，再将一张对手牌加入队列，但不执行新牌。你把她挤到公园时也如此。她可以将你挤到公园，你照常获得奖励。\n· 你完成项目时，将队列中带有该项目所提及任一颜色的对手牌移回牌库并洗混；无色项目对应无色牌。角色偏好奖励与拼图直接计分不会移除对手牌。\n· 每完成一个大成就，你选择一种颜色或无色，移回对应牌。\n· 她每本书计 1 分，每张项目计 2 分，物品只计印分，问号一律按 3 分计算，不执行能力。\n当她必须抽牌但牌库已空时，你立即落败。正常终局时，你的分数不少于她便获胜。\n\n可选官方附加内容：\n收藏徽章与感谢信默认关闭。开启收藏徽章后，加入六张徽章；拥有 1、2、3、4 张以上时整组分别计 2、6、12、20 分。开启感谢信后，加入该物品：你领取大成就时，你获得 3 点电量，其他每位玩家各获得 1 点；终局每个已完成大成就额外计 1 分。桌游物品也按 1、2、3、4 张以上整组计 2、6、12、20 分。\n"
		},
		en: {
			name: "A Place for All My Books",
			desc: "Arrange your books, recharge your social battery, and visit the village for more.",
			errAction: "That action is unavailable. Check your selection and social battery.",
			gather: "Gather",
			sort: "Sort",
			read: "Read",
			rest: "Rest",
			admire: "Admire",
			leave: "Leave the house",
			bookstore: "Used bookstore",
			library: "Library",
			shop: "Village shops",
			exchange: "Book exchange",
			park: "Town park",
			home: "Apartment",
			cafe: "Café",
			bedroom: "Bedroom",
			den: "Den",
			bath: "Bath",
			kitchen: "Kitchen",
			nightstand: "Nightstand",
			r: "Red",
			y: "Yellow",
			b: "Blue",
			g: "Green",
			wild: "Wild book",
			lamp: "Desk lamp",
			ends: "Bookends",
			round: "Round {{n}}",
			sun: "Sun track",
			finalRound: "Final round",
			turn: "{{name}}’s turn",
			waiting: "Waiting for {{name}}",
			battery: "Social battery",
			energy: "Battery",
			points: "Points",
			books: "Books",
			projects: "Little projects",
			items: "Other neat stuff",
			majors: "Major accomplishments",
			backpack: "Backpack",
			collection: "My apartment",
			village: "Village",
			draftPrompt: "Choose 3 little projects to keep.",
			confirmDraft: "Keep selected projects",
			gatherPrompt: "Choose top books from up to 6 different stacks, then choose their destination.",
			sortPrompt: "Choose a stack, then place its books one at a time. Add at most 2 books to each space.",
			readPrompt: "Choose a book at any depth to move onto the nightstand.",
			discardPrompt: "Choose {{n}} projects to discard.",
			libraryPrompt: "Choose {{n}} books to keep.",
			packPrompt: "Choose a book, then a backpack stack. Excess books return to the bag.",
			unloadPrompt: "Choose apartment destinations for both backpack stacks, keeping each stack intact.",
			exchangePrompt: "Choose books to return from the nightstand, then choose replacement colors.",
			tilePrompt: "Choose where to place this token.",
			kittyPrompt: "Choose a room for the lucky kitty.",
			wildPrompt: "Choose this wild book’s color for this Admire action.",
			shelfPrompt: "Choose a color for the two matching books.",
			admirePrompt: "Choose achieved projects and collect their rewards.",
			puzzlePrompt: "You may score one project without its reward.",
			succulentsPrompt: "Choose books from one stack and move them onto a single space.",
			recordPrompt: "Choose projects to discard, then draw up to 5 cards.",
			laptopPrompt: "Take one item from the discard pile for free.",
			snowglobePrompt: "Take one displayed shop item for free.",
			removePrompt: "Choose a color, or colorless, to remove matching Rival cards.",
			rivalPrompt: "Penelope is visiting the village.",
			afterPrompt: "You may use an item or claim an accomplishment, then end your turn.",
			mainPrompt: "Move to a different action space.",
			confirm: "Confirm",
			cancel: "Clear selection",
			close: "Close",
			skip: "Skip",
			end: "End turn",
			finishAdmire: "Finish admiring",
			return: "Welcome home",
			none: "Colorless",
			use: "Use",
			used: "Used",
			details: "Details",
			claim: "Claim accomplishment",
			completed: "{{n}} completed",
			handCount: "{{n}} projects in hand",
			cost: "Pay {{n}} battery",
			gain: "Gain {{n}} battery",
			rewardItem: "Gain a blind-drawn item",
			scoreTwo: "Worth 2 points",
			shelf: "Shelf {{n}}",
			buy: "Buy",
			buyBoth: "Buy both",
			blind: "Draw one blind",
			viewApartment: "View {{name}}’s apartment",
			cell: "{{room}}, row {{row}}, column {{col}}, {{n}} books",
			chooseBook: "Choose a {{color}} book",
			moveTo: "Place here",
			selected: "{{n}} selected",
			ready: "Achieved",
			notReady: "Not achieved",
			drawPile: "Draw pile",
			discardPile: "Discard pile",
			empty: "Empty",
			inspect: "Inspect stack",
			topBook: "Top book",
			to: "Destination",
			nextBook: "Next book",
			chosenDestination: "Choose destination",
			prefer: "Prefers {{color}} books",
			majorReward: "{{first}} points first, {{later}} points later",
			majorEnergy: "Also gain 3 battery.",
			majorItem: "Also draw one blind item.",
			flipNote: "Use once per game; it still scores after use.",
			candleEnergy: "Discard two unachieved projects: gain 3 battery",
			candleCards: "Discard two unachieved projects: draw 2 projects",
			chain: "Discard a project to {{action}}",
			chooseDiscard: "First select a project to discard.",
			penelope: "Penelope",
			rivalQueue: "Rival queue",
			rivalDeck: "{{n}} Rival cards remain",
			rivalCard: "Rival {{letter}}",
			rivalLost: "Penelope could not draw a Rival card. You lose this game.",
			resultTitle: "A home full of good books",
			winner: "{{name}} wins",
			sharedWin: "Shared victory",
			soloWin: "You beat Penelope",
			soloLoss: "Penelope wins this time",
			total: "Total",
			review: "View apartments",
			results: "Show scores",
			resultEnergy: "Remaining battery",
			resultMajors: "Accomplishments",
			resultProjects: "Completed projects",
			resultItems: "Item points",
			resultBooks: "Book points",
			assist: "Hints used: {{n}}",
			autopilot: "Autopilot: {{n}}%",
			optBase: "Optional content",
			optPins: "Collectible Pin Cards",
			optNotes: "Thank You Notes",
			optSolo: "Solo difficulty",
			level: "Level {{n}}",
			hintHome: "Take an apartment action to arrange your books or recharge your social battery.",
			hintVillage: "Visit a village location to collect books or acquire an item.",
			hintTask: "Complete the current book or card choice.",
			log: "Recent activity",
			logEvent: "{{name}}: {{action}}",
			first: "First",
			bookendsRule: "Bookends reward once per Admire action when a project uses their stack.",
			project0: "Have at least 4 green books in the corners combined.",
			project1: "Have a stack with at least 2 green and 2 yellow books.",
			project2: "Have at least 3 lonesome blue books.",
			project3: "Have at least 4 yellow books in the corners combined.",
			project4: "Have at least 3 tall stacks containing no yellow books.",
			project5: "Have at least 3 tall stacks in the kitchen.",
			project6: "Have at least 3 lonesome red books.",
			project7: "Have a book in every row and every column.",
			project8: "Have no red books in the den or kitchen.",
			project9: "Have a stack of exactly 4 books, one of each color.",
			project10: "Have at least 4 red books in the corners combined.",
			project11: "Have at least 3 tall stacks containing no blue books.",
			project12: "Have no books in any of the four central spaces.",
			project13: "Have at least 3 tall stacks containing no green books.",
			project14: "Have no blue books in the den or kitchen.",
			project15: "Have exactly one empty space in each room.",
			project16: "Have a full row of four stacks with matching top colors.",
			project17: "Have at least 3 red-topped stacks in the central spaces.",
			project18: "Have no green books in the den or kitchen.",
			project19: "Have no books in any corner.",
			project20: "Have books in all four corners, with matching top colors.",
			project21: "Have at least 3 green-topped stacks in one room.",
			project22: "Have at least 3 books in every nonempty stack.",
			project23: "Have no yellow books in the den or kitchen.",
			project24: "Have at least 3 yellow-topped stacks in the central spaces.",
			project25: "Have a full column of four stacks with matching top colors.",
			project26: "Have a stack containing at least 4 yellow books.",
			project27: "Have at least 3 tall stacks containing no red books.",
			project28: "Have no yellow books in the bedroom or bath.",
			project29: "Have at least 3 red-topped stacks in one room.",
			project30: "Have a stack containing at least 4 red books.",
			project31: "Have at least 3 blue-topped stacks in the central spaces.",
			project32: "Have at least 3 blue-topped stacks in one room.",
			project33: "Have a stack with at least 2 blue and 2 red books.",
			project34: "Have a stack containing at least 4 green books.",
			project35: "Have a lonesome book in every corner.",
			project36: "Have at least 3 green-topped stacks in the central spaces.",
			project37: "Have no blue books in the bedroom or bath.",
			project38: "Have at least 3 yellow-topped stacks in one room.",
			project39: "Have exactly one tall stack in each room.",
			project40: "Have at least 4 books of one color on the nightstand.",
			project41: "Have no lonesome books.",
			project42: "Have no green books in the bedroom or bath.",
			project43: "Have no red books in the bedroom or bath.",
			project44: "Have at least 4 blue books in the corners combined.",
			project45: "Have at least 3 tall stacks in the bedroom.",
			project46: "Fill every space of one room with a lonesome book.",
			project47: "Have at least 3 tall stacks in the central spaces.",
			project48: "Have books in every space of a 3×3 square.",
			project49: "Have a stack containing at least 4 blue books.",
			project50: "Have at least 3 lonesome yellow books.",
			project51: "Have a stack of exactly 6 books.",
			project52: "Have at least 3 lonesome green books.",
			project53: "Have no tall stacks.",
			project54: "Have at least 3 tall stacks in the den.",
			item0: "Collectible Pin",
			itemDesc0: "A set of 1/2/3/4 or more collectible pins scores 2/6/12/20 points in total.",
			item1: "Plushie",
			itemDesc1: "Score 1 point per lonesome book, up to 7.",
			item2: "Collectible Pin",
			itemDesc2: "A set of 1/2/3/4 or more collectible pins scores 2/6/12/20 points in total.",
			item3: "Lucky Kitty",
			itemDesc3: "Place by a room when acquired. Score 1 point per green book there, up to 5.",
			item4: "Desk Lamp",
			itemDesc4: "Place the lamp on any stack. Reading a book from that stack grants 1 extra battery and 1 project.",
			item5: "Collectible Pin",
			itemDesc5: "A set of 1/2/3/4 or more collectible pins scores 2/6/12/20 points in total.",
			item6: "Lucky Kitty",
			itemDesc6: "Place by a room when acquired. Score 1 point per blue book there, up to 5.",
			item7: "Cozy Blanket",
			itemDesc7: "Score 1 extra point for each room with at least two empty spaces.",
			item8: "Collectible Pin",
			itemDesc8: "A set of 1/2/3/4 or more collectible pins scores 2/6/12/20 points in total.",
			item9: "Jigsaw Puzzle",
			itemDesc9: "Each time you Read, you may score one project from your hand without its reward.",
			item10: "Thank You Notes",
			itemDesc10: "When you claim an accomplishment, gain 3 battery and give every other player 1 battery. Score 1 extra point per accomplishment claimed.",
			item11: "French Press",
			itemDesc11: "Flip once to gain 4 battery immediately.",
			item12: "Board Game",
			itemDesc12: "A set of 1/2/3/4 or more board games scores 2/6/12/20 points in total.",
			item13: "Messenger Bag",
			itemDesc13: "Draw 2 projects when acquired. At the library, draw and keep 1 extra book.",
			item14: "Graphic Novel",
			itemDesc14: "Gain a purple wild book when acquired. Each time you Admire, choose its color until the end of your turn.",
			item15: "Collectible Pin",
			itemDesc15: "A set of 1/2/3/4 or more collectible pins scores 2/6/12/20 points in total.",
			item16: "Comfy Sneakers",
			itemDesc16: "Draw 2 projects when acquired. Pay 1 less battery for each shop purchase or blind draw.",
			item17: "Board Game",
			itemDesc17: "A set of 1/2/3/4 or more board games scores 2/6/12/20 points in total.",
			item18: "Lucky Kitty",
			itemDesc18: "Place by a room when acquired. Score 1 point per yellow book there, up to 5.",
			item19: "Graphic Novel",
			itemDesc19: "Gain a purple wild book when acquired. Each time you Admire, choose its color until the end of your turn.",
			item20: "Art Print",
			itemDesc20: "Draw 2 projects when acquired. Draw 1 extra project each time you Rest.",
			item21: "Leather Journal",
			itemDesc21: "Flip once to Admire immediately, even while away from home.",
			item22: "Laptop",
			itemDesc22: "Flip once to take an item from the discard pile for free.",
			item23: "Succulents",
			itemDesc23: "Flip once to move any number of books from one stack onto a single space, in any order.",
			item24: "Cute Scarf",
			itemDesc24: "When nudged to the park, gain 2 battery and draw 2 projects, then discard down to 5.",
			item25: "Board Game",
			itemDesc25: "A set of 1/2/3/4 or more board games scores 2/6/12/20 points in total.",
			item26: "Board Game",
			itemDesc26: "A set of 1/2/3/4 or more board games scores 2/6/12/20 points in total.",
			item27: "DSLR Camera",
			itemDesc27: "Draw 2 projects when acquired. Score 1 point for each project left in your hand.",
			item28: "Record Player",
			itemDesc28: "Flip once to discard any number of projects, then draw up to 5.",
			item29: "Night Lamp",
			itemDesc29: "Score 1 extra point for each different book color on the nightstand.",
			item30: "Snuggly Hoodie",
			itemDesc30: "Gain 2 battery when acquired. If in the village, move to the park without its reward. Gain 1 battery each time you Admire.",
			item31: "Beanbag Chair",
			itemDesc31: "Gain 3 extra battery each time you Rest.",
			item32: "Art Supplies",
			itemDesc32: "Each time you Admire, gain 3 battery if you have exactly 10 nonempty book stacks.",
			item33: "Fuzzy Sweater",
			itemDesc33: "Gain 2 battery when acquired. If in the village, move to the park without its reward. Gain 1 extra chosen-color book each time you Exchange.",
			item34: "Knitting Set",
			itemDesc34: "At the end of each Admire action, gain 3 battery if you have no projects left in hand.",
			item35: "Bookshelf",
			itemDesc35: "When acquired, take two books of one color from the bag.",
			item36: "Headphones",
			itemDesc36: "Each time you Exchange, draw 1 extra random book per different color returned.",
			item37: "Decorative Mug",
			itemDesc37: "After each Gather, you may discard a project to Sort immediately.",
			item38: "Cute Keychain",
			itemDesc38: "After each Sort, you may discard a project to Gather immediately.",
			item39: "Snowglobe",
			itemDesc39: "Flip once to take one displayed shop item for free, then refresh the shop.",
			item40: "Fancy Bookends",
			itemDesc40: "Place the bookends on any stack. Each time you Admire, gain 2 battery if a project uses that stack.",
			item41: "Board Game",
			itemDesc41: "A set of 1/2/3/4 or more board games scores 2/6/12/20 points in total.",
			item42: "Lucky Kitty",
			itemDesc42: "Place by a room when acquired. Score 1 point per red book there, up to 5.",
			item43: "Board Game",
			itemDesc43: "A set of 1/2/3/4 or more board games scores 2/6/12/20 points in total.",
			item44: "Collectible Pin",
			itemDesc44: "A set of 1/2/3/4 or more collectible pins scores 2/6/12/20 points in total.",
			item45: "Zen Garden",
			itemDesc45: "Each time you Admire, gain 3 battery if the difference between the tallest and shortest nonempty stacks is at most 2.",
			item46: "Lava Lamp",
			itemDesc46: "Score 2 extra points per stack of exactly 6 books, up to 6 extra points.",
			item47: "Scented Candle",
			itemDesc47: "Each time you Admire, you may discard 2 unachieved projects to gain 3 battery or draw 2 projects.",
			item48: "Display Case",
			itemDesc48: "Score 1 point for each item you own, including this Display Case.",
			major0: "Own at least 4 items.",
			major1: "Have at least 6 projects in your scoring pile.",
			major2: "Have at least 6 books of each ordinary color in your apartment.",
			major3: "Have exactly 6 matching-color books on the nightstand.",
			major4: "Have at least two tall stacks, each entirely one color.",
			major5: "Fill all 16 spaces; orthogonally adjacent top books must differ in color.",
			major6: "Have at least three stacks of exactly 6 books.",
			major7: "Have at least 7 stacks with matching top colors.",
			major8: "Reach a total of at least 24 battery during one Admire action.",
			major9: "Have a tall stack in each room, all four with identical color counts.",
			rules: "Collect, arrange, and admire good books in your apartment. Complete little projects to recharge your social battery, then visit the village for books and useful items. The highest final score wins.\n\nSetup:\nEach player receives an apartment, 12 starting books, and 5 projects, keeping 3 projects. Starting battery is 3, 4, 5, and 6 in turn order. The bookstore shelves begin with 3, 2, and 1 random books and one project each. Display two shop items and three major accomplishments.\n\nYour apartment:\nThe 4×4 apartment is divided into the bedroom, den, bath, and kitchen. The upper-right bedroom space is the nightstand. Each space holds at most 6 books. A single book alone is lonesome; a stack of at least 3 books is tall. The order of colors matters. The lamp and bookends are not books, do not count toward height, and do not obstruct gathering the top book beneath them.\n\nYour turn:\nMove to a different action space and resolve its action. Apartment actions restore battery; village actions cost battery. You can store at most 20 battery. After resolving the action and its choices, you may use unflipped items and claim achieved accomplishments, then end your turn. You cannot enter another player’s apartment.\n\nApartment actions:\n· Gather: Gain 1 battery. Take one top book from up to 6 different stacks and put them onto a single space in any order, respecting the height limit. You may also move the lamp and bookends.\n· Sort: Gain 1 battery. Pick up one entire stack and distribute its books in any order onto any spaces, including the original space. Add at most 2 books to each destination; each finished stack may contain at most 6 books. The lamp and bookends do not count against the two-book allowance.\n· Read: Gain 2 battery. Move one book from any depth in any stack onto the nightstand, respecting its height limit.\n· Rest: Gain 2 battery and draw 2 projects. If you then hold more than 5 projects, discard down to 5. Gaining projects through other actions does not automatically impose this hand limit.\n· Admire: First gain 3 battery if your character’s preferred color is the most common in your home, including a tie. Reveal achieved projects and resolve their rewards one at a time: usually 3 battery, or a blind-drawn item. Score each completed project for 2 points at game end; books are not spent. Projects count apartment books, excluding the backpack. Choose each wild book’s color for this Admire action; it returns to purple at the end of your turn.\n· Leave the house: Pay 5 battery, advance the sun one space, then immediately take a village action in the same turn, paying its cost too.\n\nVillage actions:\nVillage spaces are shared. Entering an occupied space nudges its occupant to the park, granting that player 2 battery. You cannot visit the park voluntarily.\n· Used bookstore: Pay 1, 3, or 6 battery for the smallest, middle, or largest shelf respectively. Take all books and the project from that shelf. Replace its project and add one random book to each shelf. Break equal-size shelf ties from left to right. With four players, the left bookstore space accesses the left or middle shelf, and the right space accesses the right or middle shelf. You cannot move between bookstore spaces on consecutive turns.\n· Library: With one to three players, pay 1 battery, draw 4 random books, and keep 1. With four players, pay 2 battery, draw 5, and keep 2. Shuffle the remaining three and add one to each shelf.\n· Village shops: Pay 4 battery for one displayed item, 9 for both, or 3 for one blind draw. After purchasing displayed items, discard the remaining display and reveal two new items. Blind draws do not refresh the display. Items and their acquisition effects apply immediately.\n· Exchange: Pay 1 battery. Return any number of ordinary books from the nightstand to the bag, including zero, then take that many books plus one in colors of your choice. Put the new books in your backpack. Purple wild books cannot be exchanged.\n\nBackpack and coming home:\nArrange a newly acquired batch of books in any order across the tops of your two backpack stacks. Each stack holds at most 6 books; return excess books to the bag. Once placed, they cannot be rearranged, and later books go on top.\nIf you begin your turn in the village, you may return home. First unload each entire backpack stack onto an apartment space, without dividing or reordering it and without exceeding the height limit. Then immediately take an apartment action. You cannot return if there is no legal way to unload.\n\nItems and accomplishments:\nSelect an item to read its full ability. Flip abilities may be used once per game; flipped items still score. Projects use the current arrangement and do not spend books. Claim an achieved major accomplishment without spending an action. The first claimant earns its larger score; later claimants earn the smaller score, with the same resource reward. Each player may claim each card once. Bookends grant at most one bonus per Admire action when a completed project uses their stack. Pure absence conditions do not trigger them.\n\nGame end and scoring:\nThe sun track has eight spaces. Start at space three with one or two players, space one with three players, or the starting position with four players. When the sun reaches space eight, finish the current round so everyone has equal turns, then play one additional final turn each.\n· Score 1 point for every book in your apartment and backpack.\n· Score 2 points for each project in your scoring pile.\n· Score your items and claimed major accomplishments.\n· Score 1 point per 4 remaining battery.\nBreak tied scores by most books. Share victory if still tied.\n\nSolo: Penelope\nDifficulty levels one through five use A–J, B–K, C–L, D–M, or E–N respectively, shuffling the ten cards. You start with 3 battery and the two-player sun position. After each of your turns, Penelope draws a Rival card into her queue. Resolve the newly drawn card using the queue-size band: 1–3, 4–5, 6–7, or 8+.\n· At the library, she gains a random book and adds one to each shelf. At the bookstore, she takes all books and the project from the indicated shelf, then restocks normally. Shops follow the card’s instruction; the café has no base effect.\n· At the park, add one more Rival card to the queue without resolving it. This also happens when you nudge her there. If she nudges you, gain the usual park reward.\n· When you complete a project, remove all queued Rival cards showing any color mentioned by that project and shuffle them into her deck. Colorless projects remove colorless Rivals. Character bonuses and projects scored with the jigsaw puzzle do not remove Rivals.\n· Each major accomplishment lets you choose a color, or colorless, to remove matching Rivals.\n· She scores 1 point per book, 2 per project, and printed item points. A question mark is always 3 points. She ignores item abilities and project rewards.\nYou lose immediately if she must draw a Rival card but her deck is empty. At a normal ending, match or exceed her score to win.\n\nOptional official extras:\nCollectible Pin Cards and Thank You Notes are off by default. Pins add six cards; a set of 1/2/3/4 or more scores 2/6/12/20 points in total. Thank You Notes adds its item: when you claim an accomplishment, gain 3 battery and give every other player 1 battery, and score 1 extra point per accomplishment claimed. Board-game items likewise score 2/6/12/20 for a set of 1/2/3/4 or more.\n"
		}
	}
};
//#endregion
export { Xt as default };
