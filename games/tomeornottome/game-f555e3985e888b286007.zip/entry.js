import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { useT as a } from "@bgparty/sdk/i18n";
import { useWakeLock as o } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as s } from "@bgparty/sdk/ui/game-screen";
import { Fragment as c, jsx as l, jsxs as u } from "react/jsx-runtime";
import { OptionRadio as d, OptionSection as f, OptionSwitch as p } from "@bgparty/sdk/ui/game-options";
import { ConfirmButton as m } from "@bgparty/sdk/confirm-button";
//#region src/games/tomeornottome/meta.ts
var h = {
	id: "tomeornottome",
	tier: "alpha",
	nameKey: "games.tomeornottome.name",
	descKey: "games.tomeornottome.desc",
	rulesKey: "games.tomeornottome.rules",
	icon: "❔",
	iconImg: "games/tomeornottome.webp",
	minPlayers: 3,
	maxPlayers: 6,
	mechanics: ["word-association", "deduction"],
	interactionTags: ["cooperative", "communication-limits"],
	accent: "#672278",
	releasedAt: "2026-11-03T12:40:21+08:00",
	search: {
		py: "gei wo hai shi ta",
		init: "gwhst"
	},
	hotseat: "cover",
	rulesUrl: { en: "https://www.dropbox.com/scl/fo/6xmfaxwvy2ndsbb99l3c0/AMo7yl7OwZVpTrs920LN9aA/EN/Regles_Tome%21_EN_web.pdf?rlkey=wdppz161adkqlzwu85jto80ae&dl=1" }
}, g = t.string().trim().min(1).max(40).refine((e) => !/[\p{Cc}\p{Cf}]/u.test(e)), _ = (e) => e.normalize("NFKC").toLocaleLowerCase("en-US").replace(/\s+/gu, "");
function v(e) {
	let t = /* @__PURE__ */ new Set();
	return e.split(/\r?\n/u).flatMap((e) => {
		let n = g.safeParse(e);
		return !n.success || t.has(_(n.data)) ? [] : (t.add(_(n.data)), [n.data]);
	}).slice(0, 500);
}
var y = t.object({
	wordSource: t.literal("custom").catch("custom"),
	customWords: t.string().max(2e4).catch(""),
	doubleThree: t.boolean().catch(!0),
	extraHolders: t.number().int().min(0).max(3).catch(0),
	pawnAdjustment: t.number().int().min(-1).max(2).catch(0),
	extraWild: t.boolean().catch(!1),
	allowProper: t.boolean().catch(!1),
	lastChance: t.boolean().catch(!1)
}).default({
	wordSource: "custom",
	customWords: "",
	doubleThree: !0,
	extraHolders: 0,
	pawnAdjustment: 0,
	extraWild: !1,
	allowProper: !1,
	lastChance: !1
}), b = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("configure"),
		words: t.string().max(2e4)
	}),
	t.object({
		type: t.literal("clue"),
		card: t.string(),
		target: t.number().int().min(1).max(6),
		word: g
	}),
	t.object({
		type: t.literal("invite"),
		player: t.string()
	}),
	t.object({
		type: t.literal("guess"),
		word: g
	}),
	t.object({
		type: t.literal("judge"),
		holder: t.number().int().min(1).max(6).nullable()
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), x = t.object({
	number: t.number().int(),
	owner: t.string(),
	solved: t.boolean(),
	word: t.string().nullable()
}), S = t.object({
	id: t.string(),
	by: t.string(),
	word: t.string(),
	target: t.number().int().nullable()
}), C = t.object({
	by: t.string(),
	word: t.string(),
	correct: t.boolean(),
	holder: t.number().int().nullable(),
	final: t.boolean()
}), w = t.object({
	phase: t.enum([
		"prepare",
		"play",
		"guess",
		"judge",
		"feedback",
		"done"
	]),
	players: t.array(t.string()),
	host: t.string(),
	turn: t.string(),
	holders: t.array(x),
	pawns: t.number().int(),
	initialPawns: t.number().int(),
	handCounts: t.record(t.string(), t.number().int()),
	clues: t.array(S),
	attempts: t.array(C),
	allowProper: t.boolean(),
	pending: t.object({
		player: t.string(),
		guess: t.string().nullable(),
		finalHolder: t.number().int().nullable()
	}).nullable(),
	voted: t.array(t.string()),
	lastMode: t.boolean(),
	won: t.boolean()
}), T = t.object({
	hand: t.array(t.object({
		id: t.string(),
		number: t.number().int()
	})),
	targets: t.array(t.object({
		number: t.number().int(),
		word: t.string()
	})),
	vote: t.number().int().nullable().optional()
}), E = () => ({ code: "games.tomeornottome.invalidAction" }), D = (e) => e.players[e.turnIndex], O = (e) => e.holders.length > 0 && e.holders.every((e) => e.solved);
function k(e, t, n) {
	let r = n.number === 0 || e.holders.some((e) => e.number === n.number && (e.owner === t || e.solved));
	return e.holders.filter((e) => !e.solved && e.owner !== t && (r || e.number === n.number));
}
function A(t, n) {
	let r = [...t];
	for (let t = r.length - 1; t > 0; t--) {
		let i = e(n.seed, n.cursor++, t + 1);
		[r[t], r[i]] = [r[i], r[t]];
	}
	return r;
}
function j(e, t) {
	let n = { ...e }, r = Math.min(6, (e.players.length === 3 && e.config.doubleThree ? 6 : e.players.length) + e.config.extraHolders), i = e.players.flatMap((t, n) => Array.from({ length: Math.floor(r / e.players.length) + +(n < r % e.players.length) }, () => t)), a = A(t, n);
	n.holders = i.map((e, t) => ({
		number: t + 1,
		owner: e,
		word: a[t],
		solved: !1
	}));
	let o = n.holders.flatMap((e) => [
		0,
		1,
		2
	].map((t) => ({
		id: `${e.number}-${t}`,
		number: e.number
	})));
	e.config.extraWild && o.push({
		id: "wild-0",
		number: 0
	}, {
		id: "wild-1",
		number: 0
	});
	let s = A(o, n);
	return n.hands = Object.fromEntries(e.players.map((t, n) => [t, s.filter((t, r) => r % e.players.length === n)])), n.phase = "play", n;
}
function M(e, t) {
	let n = t !== null;
	return {
		...e,
		phase: "feedback",
		holders: e.holders.map((e) => e.number === t ? {
			...e,
			solved: !0
		} : e),
		pawns: e.pawns - +(!n && !e.lastMode),
		votes: {},
		attempts: [...e.attempts, {
			by: e.pending.player,
			word: e.pending.guess,
			correct: n,
			holder: t,
			final: e.lastMode
		}],
		lastQueue: e.lastMode ? e.lastQueue.slice(1) : e.lastQueue
	};
}
function N(e) {
	if (O(e)) return {
		...e,
		phase: "done",
		pending: null
	};
	let t = {
		...e,
		pending: null,
		votes: {}
	};
	if (!e.lastMode && e.pawns === 0) {
		if (!e.config.lastChance) return {
			...t,
			phase: "done"
		};
		t = {
			...t,
			lastMode: !0,
			lastQueue: e.holders.filter((e) => !e.solved).map((e) => e.number)
		};
	}
	if (t.lastMode) {
		let e = t.holders.find((e) => e.number === t.lastQueue[0]);
		return e ? {
			...t,
			phase: "guess",
			pending: {
				player: e.owner,
				guess: null,
				finalHolder: e.number
			}
		} : {
			...t,
			phase: "done"
		};
	}
	return {
		...t,
		phase: "play",
		turnIndex: (e.turnIndex + 1) % e.players.length
	};
}
var P = {
	meta: h,
	saveCompatibility: { version: "1" },
	schemas: {
		action: b,
		publicView: w,
		privateView: T,
		config: y
	},
	setup(e, t, n) {
		let { customWords: r, ...i } = e, a = Math.min(6, (t.length === 3 && e.doubleThree ? 6 : t.length) + e.extraHolders), o = Math.max(1, (a < 5 ? 2 : 3) + e.pawnAdjustment), s = {
			players: [...t],
			config: i,
			seed: n,
			cursor: 0,
			phase: "prepare",
			holders: [],
			hands: Object.fromEntries(t.map((e) => [e, []])),
			clues: [],
			turnIndex: 0,
			pawns: o,
			initialPawns: o,
			pending: null,
			votes: {},
			attempts: [],
			lastMode: !1,
			lastQueue: []
		}, c = v(r);
		return { state: c.length >= 6 ? j(s, c) : s };
	},
	reduce(e, t, { by: n }) {
		if (t.type === "tick") return n === "$engine" && e.phase === "feedback" ? { state: N(e) } : E();
		if (!e.players.includes(n) || e.phase === "done") return E();
		if (t.type === "configure") {
			let r = v(t.words);
			return e.phase === "prepare" && n === e.players[0] && r.length >= 6 ? { state: j(e, r) } : E();
		}
		if (t.type === "clue") {
			if (e.phase !== "play" || n !== D(e)) return E();
			let r = e.hands[n].find((e) => e.id === t.card);
			if (!r || !k(e, n, r).some((e) => e.number === t.target) || e.holders.some((e) => (e.owner !== n || e.solved) && _(e.word) === _(t.word))) return E();
			let i = t.word.trim();
			return { state: {
				...e,
				hands: {
					...e.hands,
					[n]: e.hands[n].filter((e) => e.id !== r.id)
				},
				clues: [...e.clues, {
					id: `clue-${e.clues.length + 1}`,
					by: n,
					word: i,
					target: t.target
				}],
				turnIndex: (e.turnIndex + 1) % e.players.length
			} };
		}
		if (t.type === "invite") return e.phase !== "play" || n !== D(e) || e.pawns < 1 || !e.holders.some((e) => e.owner === t.player && !e.solved) ? E() : { state: {
			...e,
			phase: "guess",
			pending: {
				player: t.player,
				guess: null,
				finalHolder: null
			},
			votes: {}
		} };
		if (t.type === "guess") {
			if (e.phase !== "guess" || e.pending?.player !== n) return E();
			let r = {
				...e,
				phase: "judge",
				pending: {
					...e.pending,
					guess: t.word.trim()
				},
				votes: {}
			}, i = e.holders.find((r) => r.owner === n && !r.solved && (e.pending.finalHolder === null || r.number === e.pending.finalHolder) && _(r.word) === _(t.word));
			return { state: i ? M(r, i.number) : r };
		}
		if (t.type === "judge") {
			if (e.phase !== "judge" || !e.pending || n === e.pending.player || t.holder !== null && !e.holders.some((n) => n.number === t.holder && n.owner === e.pending.player && !n.solved && (e.pending.finalHolder === null || n.number === e.pending.finalHolder))) return E();
			let r = {
				...e.votes,
				[n]: t.holder
			};
			return { state: e.players.filter((t) => t !== e.pending.player).every((e) => Object.hasOwn(r, e) && r[e] === t.holder) ? M({
				...e,
				votes: r
			}, t.holder) : {
				...e,
				votes: r
			} };
		}
		return E();
	},
	viewFor(e, t) {
		let n = e.phase === "done", r = e.players.includes(t);
		return {
			public: {
				phase: e.phase,
				players: e.players,
				host: e.players[0],
				turn: D(e),
				holders: e.holders.map((e) => ({
					...e,
					word: e.solved || n ? e.word : null
				})),
				pawns: e.pawns,
				initialPawns: e.initialPawns,
				handCounts: Object.fromEntries(e.players.map((t) => [t, e.hands[t].length])),
				clues: e.clues.map((e, t) => ({
					...e,
					id: `clue-${t + 1}`,
					target: n ? e.target : null
				})),
				attempts: e.attempts,
				allowProper: e.config.allowProper,
				pending: e.pending,
				voted: Object.keys(e.votes),
				lastMode: e.lastMode,
				won: O(e)
			},
			private: {
				hand: r ? e.hands[t] : [],
				targets: r ? e.holders.filter((e) => e.owner !== t || e.solved || n).map((e) => ({
					number: e.number,
					word: e.word
				})) : [],
				...r && Object.hasOwn(e.votes, t) ? { vote: e.votes[t] } : {}
			}
		};
	},
	status(e) {
		return e.phase === "done" ? {
			phase: "done",
			winner: O(e) ? e.players : [],
			ranking: e.players,
			scores: Object.fromEntries(e.players.map((t) => [t, e.holders.filter((e) => e.solved).length]))
		} : { phase: e.phase };
	},
	nextTickIn(e) {
		return e.phase === "feedback" ? 650 : null;
	}
};
//#endregion
//#region src/games/tomeornottome/components.tsx
function F({ label: e, onClose: t, children: i }) {
	let a = r(null);
	return n(() => {
		let e = document.activeElement instanceof HTMLElement ? document.activeElement : null;
		return a.current?.querySelector("input")?.focus(), () => e?.focus();
	}, []), /* @__PURE__ */ l("div", {
		className: "tome-shade",
		children: /* @__PURE__ */ l("section", {
			className: "tome-dialog",
			ref: a,
			role: "dialog",
			"aria-modal": "true",
			"aria-label": e,
			onKeyDown: (e) => {
				if (e.key === "Escape" && (e.preventDefault(), t()), e.key !== "Tab") return;
				let n = [...a.current?.querySelectorAll("button:not(:disabled), input:not(:disabled)") ?? []];
				n.length && (e.shiftKey && document.activeElement === n[0] && (e.preventDefault(), n.at(-1)?.focus()), !e.shiftKey && document.activeElement === n.at(-1) && (e.preventDefault(), n[0].focus()));
			},
			children: i
		})
	});
}
function I({ lost: e = !1 }) {
	return /* @__PURE__ */ u("svg", {
		className: "tome-pawn",
		"data-lost": e,
		viewBox: "0 0 72 100",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ l("path", {
				d: "M8 85L20 76H53L65 85V94H8Z",
				fill: "#ac7d14"
			}),
			/* @__PURE__ */ l("path", {
				d: "M8 85L20 76H53L65 85H8Z",
				fill: "#f7dd62"
			}),
			/* @__PURE__ */ l("path", {
				d: "M19 25C19 5 57 4 57 26C57 40 40 43 40 56H27C27 34 44 38 44 26C44 16 31 16 31 27H19ZM27 64H40V78H27Z",
				fill: "#dbac19",
				stroke: "#d6a51a",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ l("path", {
				d: "M15 22C15 2 53 1 53 23C53 37 36 40 36 53H23C23 31 40 35 40 23C40 13 27 13 27 24H15ZM23 61H36V75H23Z",
				fill: "#f6ce26"
			})
		]
	});
}
function L() {
	return /* @__PURE__ */ l("svg", {
		className: "tome-target-outline",
		viewBox: "0 0 300 150",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: /* @__PURE__ */ l("rect", {
			x: "3",
			y: "3",
			width: "294",
			height: "144",
			rx: "15",
			fill: "none",
			stroke: "#672278",
			strokeWidth: "3",
			strokeDasharray: "9 7",
			children: /* @__PURE__ */ l("animate", {
				attributeName: "stroke-dashoffset",
				from: "32",
				to: "0",
				dur: "1s",
				repeatCount: "indefinite"
			})
		})
	});
}
function R({ number: e, word: t, name: n, solved: r, onClick: i, selectable: a, children: o }) {
	let s = /* @__PURE__ */ u(c, { children: [
		/* @__PURE__ */ u("div", {
			className: "tome-holder-face",
			children: [
				/* @__PURE__ */ l("span", {
					className: "tome-number",
					children: e
				}),
				/* @__PURE__ */ l("strong", { children: t ?? "?" }),
				o
			]
		}),
		/* @__PURE__ */ u("div", {
			className: "tome-holder-foot",
			children: [/* @__PURE__ */ l("span", { children: n }), r && /* @__PURE__ */ l("b", { children: "✓" })]
		}),
		a && /* @__PURE__ */ l(L, {})
	] });
	return i ? /* @__PURE__ */ l("button", {
		type: "button",
		className: "tome-holder",
		"data-solved": r,
		onClick: i,
		children: s
	}) : /* @__PURE__ */ l("div", {
		className: "tome-holder",
		"data-solved": r,
		children: s
	});
}
function z({ children: e, onClick: t, selected: n, disabled: r, label: i }) {
	return t ? /* @__PURE__ */ l("button", {
		type: "button",
		className: "tome-clue-card",
		"aria-label": i,
		"aria-pressed": n,
		disabled: r,
		onClick: t,
		children: e
	}) : /* @__PURE__ */ l("div", {
		className: "tome-clue-card",
		children: e
	});
}
//#endregion
//#region src/games/tomeornottome/options.tsx
function B({ value: e, onChange: t }) {
	let n = a(), [r, o] = i("");
	return /* @__PURE__ */ u("div", {
		className: "tome-word-input",
		children: [
			/* @__PURE__ */ u("label", { children: [/* @__PURE__ */ l("span", { children: n("games.tomeornottome.words") }), /* @__PURE__ */ l("textarea", {
				value: e,
				maxLength: 2e4,
				rows: 6,
				"aria-label": n("games.tomeornottome.words"),
				onChange: (e) => t(e.target.value)
			})] }),
			/* @__PURE__ */ l("p", { children: n("games.tomeornottome.wordsHint") }),
			/* @__PURE__ */ u("div", {
				className: "tome-import-row",
				children: [/* @__PURE__ */ u("label", {
					className: "tome-button tome-file",
					children: [n("games.tomeornottome.import"), /* @__PURE__ */ l("input", {
						type: "file",
						accept: ".txt,text/plain",
						onChange: async (e) => {
							let r = e.target.files?.[0];
							if (r) {
								try {
									if (r.size > 8e4) {
										o(n("games.tomeornottome.tooLarge"));
										return;
									}
									let e = await r.text();
									e.length > 2e4 ? o(n("games.tomeornottome.tooLarge")) : (t(e), o(""));
								} catch {
									o(n("games.tomeornottome.fileError"));
								}
								e.target.value = "";
							}
						}
					})]
				}), /* @__PURE__ */ l("strong", { children: n("games.tomeornottome.count", { n: v(e).length }) })]
			}),
			v(e).length < 6 && /* @__PURE__ */ l("p", {
				role: "status",
				children: n("games.tomeornottome.needWords")
			}),
			r && /* @__PURE__ */ l("p", {
				role: "alert",
				children: r
			})
		]
	});
}
function V({ value: e, onChange: t }) {
	let n = a(), r = y.safeParse(e), i = r.success ? r.data : y.parse(void 0);
	return /* @__PURE__ */ u("div", {
		className: "tome-options",
		children: [
			/* @__PURE__ */ l(f, {
				title: n("games.tomeornottome.wordSource"),
				children: /* @__PURE__ */ l(d, {
					name: "tome-word-source",
					value: "custom",
					checked: !0,
					label: n("games.tomeornottome.custom"),
					accent: "#672278",
					onChange: () => t({
						...i,
						wordSource: "custom"
					})
				})
			}),
			/* @__PURE__ */ l(B, {
				value: i.customWords,
				onChange: (e) => t({
					...i,
					customWords: e
				})
			}),
			/* @__PURE__ */ l(p, {
				checked: i.doubleThree,
				label: n("games.tomeornottome.double"),
				onChange: () => t({
					...i,
					doubleThree: !i.doubleThree
				})
			}),
			/* @__PURE__ */ l(f, {
				title: n("games.tomeornottome.extra"),
				children: [
					0,
					1,
					2,
					3
				].map((e) => /* @__PURE__ */ l(d, {
					name: "tome-extra",
					value: String(e),
					checked: i.extraHolders === e,
					label: n(e === 0 ? "games.tomeornottome.noExtra" : "games.tomeornottome.extraCount", { n: e }),
					onChange: () => t({
						...i,
						extraHolders: e
					})
				}, e))
			}),
			/* @__PURE__ */ l(f, {
				title: n("games.tomeornottome.pawns"),
				children: [
					-1,
					0,
					1,
					2
				].map((e) => /* @__PURE__ */ l(d, {
					name: "tome-pawns",
					value: String(e),
					checked: i.pawnAdjustment === e,
					label: n(e === -1 ? "games.tomeornottome.fewer" : e === 0 ? "games.tomeornottome.standard" : e === 1 ? "games.tomeornottome.more" : "games.tomeornottome.most"),
					onChange: () => t({
						...i,
						pawnAdjustment: e
					})
				}, e))
			}),
			/* @__PURE__ */ l(p, {
				checked: i.extraWild,
				label: n("games.tomeornottome.wild"),
				onChange: () => t({
					...i,
					extraWild: !i.extraWild
				})
			}),
			/* @__PURE__ */ l(p, {
				checked: i.allowProper,
				label: n("games.tomeornottome.proper"),
				onChange: () => t({
					...i,
					allowProper: !i.allowProper
				})
			}),
			/* @__PURE__ */ l(p, {
				checked: i.lastChance,
				label: n("games.tomeornottome.last"),
				onChange: () => t({
					...i,
					lastChance: !i.lastChance
				})
			})
		]
	});
}
//#endregion
//#region src/games/tomeornottome/view-player.tsx
function H(e) {
	return o(), /* @__PURE__ */ l(U, { ...e }, e.myRid);
}
function U({ public: e, private: t, members: n, myRid: r, send: o }) {
	let d = a(), f = e, p = t, [m, h] = i(null), [_, y] = i(null), [b, x] = i(""), [S, C] = i(!1), [w, T] = i(""), E = (e) => n.find((t) => t.rid === e)?.name ?? e, D = f.phase === "play" && f.turn === r, O = p?.hand.find((e) => e.id === m), k = O && (O.number === 0 || f.holders.some((e) => e.number === O.number && (e.owner === r || e.solved))), A = f.holders.filter((e) => !e.solved && e.owner !== r && (k || e.number === O?.number)), j = _ !== null && A.some((e) => e.number === _) ? _ : A.length === 1 ? A[0].number : null, M = () => {
		O && j !== null && g.safeParse(b).success && (o({
			type: "clue",
			card: O.id,
			target: j,
			word: b.trim()
		}), h(null), y(null), x(""));
	}, N = () => {
		g.safeParse(b).success && (o({
			type: "guess",
			word: b.trim()
		}), x(""));
	}, P = f.phase === "guess" && f.pending?.player === r, V = f.phase === "judge" && f.pending?.player !== r, H = f.phase === "prepare" ? d("games.tomeornottome.prepare") : f.phase === "guess" ? d("games.tomeornottome.guessing", { name: E(f.pending.player) }) : f.phase === "judge" ? d("games.tomeornottome.judging") : f.phase === "feedback" ? d("games.tomeornottome.guessed", { word: f.pending.guess }) : d("games.tomeornottome.turn", { name: E(f.turn) }), U = () => {
		h(null), y(null), x(""), C(!1);
	};
	return /* @__PURE__ */ u(s, {
		adaptive: !0,
		className: "tome-game",
		scroll: !1,
		banner: /* @__PURE__ */ u("header", {
			className: "tome-header",
			children: [/* @__PURE__ */ u("div", { children: [/* @__PURE__ */ l("strong", { children: H }), /* @__PURE__ */ l("span", { children: d("games.tomeornottome.solved", {
				n: f.holders.filter((e) => e.solved).length,
				total: f.holders.length
			}) })] }), /* @__PURE__ */ l("div", {
				className: "tome-pawn-rack",
				"aria-label": d("games.tomeornottome.pawnCount", { n: f.pawns }),
				children: Array.from({ length: f.initialPawns }, (e, t) => /* @__PURE__ */ l(I, { lost: t >= f.pawns }, t))
			})]
		}),
		actionsHeight: "tome-hand-height",
		actions: /* @__PURE__ */ u("section", {
			className: "tome-hand",
			"aria-label": d("games.tomeornottome.hand"),
			children: [/* @__PURE__ */ u("div", {
				className: "tome-hand-cards",
				children: [p?.hand.map((e) => /* @__PURE__ */ l(z, {
					disabled: !D,
					selected: m === e.id,
					label: e.number === 0 ? d("games.tomeornottome.wildCard") : d("games.tomeornottome.holder", { n: e.number }),
					onClick: () => {
						h(e.id), y(null), x(""), C(!1);
					},
					children: /* @__PURE__ */ l("b", { children: e.number || "★" })
				}, e.id)), f.phase !== "prepare" && !p?.hand.length && /* @__PURE__ */ l("p", { children: d("games.tomeornottome.noCards") })]
			}), /* @__PURE__ */ u("button", {
				type: "button",
				className: "tome-invite",
				"aria-label": d("games.tomeornottome.invite"),
				disabled: !D || !f.pawns,
				onClick: () => {
					C(!S), h(null);
				},
				children: [/* @__PURE__ */ l(I, {}), /* @__PURE__ */ l("span", { children: d("games.tomeornottome.invite") })]
			})]
		}),
		children: [
			/* @__PURE__ */ l("main", {
				className: "tome-main",
				"data-answering": f.phase === "guess" || f.phase === "judge",
				children: f.phase === "prepare" ? /* @__PURE__ */ u("section", {
					className: "tome-prepare",
					children: [/* @__PURE__ */ l("h1", { children: d("games.tomeornottome.custom") }), f.host === r ? /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l(B, {
						value: w,
						onChange: T
					}), /* @__PURE__ */ l("button", {
						className: "tome-button",
						disabled: v(w).length < 6,
						onClick: () => o({
							type: "configure",
							words: w
						}),
						children: d("games.tomeornottome.start")
					})] }) : /* @__PURE__ */ l("p", { children: d("games.tomeornottome.prepare") })]
				}) : /* @__PURE__ */ u(c, { children: [
					/* @__PURE__ */ l("section", {
						className: "tome-holders",
						"aria-label": d("games.tomeornottome.words"),
						children: f.holders.map((e) => {
							let t = e.word ?? p?.targets.find((t) => t.number === e.number)?.word ?? null, n = D && S && !e.solved;
							return /* @__PURE__ */ l(R, {
								number: e.number,
								word: t,
								name: E(e.owner),
								solved: e.solved,
								selectable: n,
								onClick: n ? () => {
									o({
										type: "invite",
										player: e.owner
									}), U();
								} : void 0,
								children: !t && /* @__PURE__ */ l("small", { children: d("games.tomeornottome.mine") })
							}, e.number);
						})
					}),
					D && S && /* @__PURE__ */ u("p", {
						className: "tome-choice-prompt",
						role: "status",
						children: [
							d("games.tomeornottome.choosePlayer"),
							" ",
							/* @__PURE__ */ l("button", {
								onClick: U,
								children: d("games.tomeornottome.cancel")
							})
						]
					}),
					/* @__PURE__ */ l("section", {
						className: "tome-table",
						"aria-label": d("games.tomeornottome.table"),
						children: f.players.map((e) => /* @__PURE__ */ u("div", {
							className: "tome-clue-group",
							children: [/* @__PURE__ */ u("h2", { children: [E(e), /* @__PURE__ */ l("span", { children: d("games.tomeornottome.cardCount", { n: f.handCounts[e] }) })] }), /* @__PURE__ */ u("div", {
								className: "tome-played",
								children: [f.clues.filter((t) => t.by === e).map((e) => /* @__PURE__ */ l(z, { children: e.word }, e.id)), !f.clues.some((t) => t.by === e) && /* @__PURE__ */ l("span", {
									className: "tome-empty",
									children: d("games.tomeornottome.noClues")
								})]
							})]
						}, e))
					})
				] })
			}),
			D && O && /* @__PURE__ */ u(F, {
				label: d("games.tomeornottome.write"),
				onClose: U,
				children: [/* @__PURE__ */ l("h2", { children: d("games.tomeornottome.write") }), /* @__PURE__ */ u("div", {
					className: "tome-form",
					onKeyDown: (e) => {
						e.key === "Enter" && !e.nativeEvent.isComposing && (e.preventDefault(), M());
					},
					children: [
						k && /* @__PURE__ */ l("div", {
							className: "tome-recipient",
							"aria-label": d("games.tomeornottome.wildTarget"),
							children: A.map((e) => /* @__PURE__ */ u("button", {
								type: "button",
								className: "tome-mini-holder",
								"aria-pressed": j === e.number,
								onClick: () => y(e.number),
								children: [
									e.number,
									/* @__PURE__ */ l("strong", { children: p?.targets.find((t) => t.number === e.number)?.word }),
									/* @__PURE__ */ l(L, {})
								]
							}, e.number))
						}),
						j !== null && /* @__PURE__ */ l("p", { children: d("games.tomeornottome.clueFor", { n: j }) }),
						/* @__PURE__ */ u("label", {
							className: "tome-writing",
							children: [/* @__PURE__ */ l("span", { children: d("games.tomeornottome.clue") }), /* @__PURE__ */ l("input", {
								value: b,
								maxLength: 40,
								"aria-label": d("games.tomeornottome.clueWord"),
								onChange: (e) => x(e.target.value),
								autoComplete: "off"
							})]
						}),
						/* @__PURE__ */ u("div", {
							className: "tome-dialog-actions",
							children: [/* @__PURE__ */ l("button", {
								type: "button",
								className: "tome-secondary",
								onClick: U,
								children: d("games.tomeornottome.cancel")
							}), /* @__PURE__ */ l("button", {
								type: "button",
								onClick: M,
								className: "tome-button",
								disabled: j === null || !g.safeParse(b).success,
								children: d("games.tomeornottome.play")
							})]
						})
					]
				})]
			}),
			(P || f.phase === "judge") && /* @__PURE__ */ l("div", {
				className: "tome-answer-dock",
				children: /* @__PURE__ */ u("section", {
					className: "tome-dialog",
					"aria-label": H,
					children: [
						/* @__PURE__ */ l("h2", { children: H }),
						f.pending.finalHolder !== null && /* @__PURE__ */ l("p", { children: d("games.tomeornottome.lastGuess", { n: f.pending.finalHolder }) }),
						P ? /* @__PURE__ */ u("div", {
							className: "tome-form",
							onKeyDown: (e) => {
								e.key === "Enter" && !e.nativeEvent.isComposing && (e.preventDefault(), N());
							},
							children: [/* @__PURE__ */ u("label", {
								className: "tome-writing",
								children: [/* @__PURE__ */ l("span", { children: d("games.tomeornottome.guess") }), /* @__PURE__ */ l("input", {
									value: b,
									maxLength: 40,
									"aria-label": d("games.tomeornottome.guessWord"),
									onChange: (e) => x(e.target.value),
									autoComplete: "off"
								})]
							}), /* @__PURE__ */ l("button", {
								type: "button",
								onClick: N,
								className: "tome-button",
								disabled: !g.safeParse(b).success,
								children: d("games.tomeornottome.submit")
							})]
						}) : f.phase === "judge" ? /* @__PURE__ */ u(c, { children: [
							/* @__PURE__ */ l("strong", {
								className: "tome-answer",
								children: d("games.tomeornottome.guessed", { word: f.pending.guess })
							}),
							V ? /* @__PURE__ */ u("div", {
								className: "tome-judge",
								children: [f.holders.filter((e) => e.owner === f.pending.player && !e.solved && (f.pending.finalHolder === null || e.number === f.pending.finalHolder)).map((e) => /* @__PURE__ */ l("button", {
									className: "tome-button",
									"aria-pressed": f.voted.includes(r) && p?.vote === e.number,
									onClick: () => o({
										type: "judge",
										holder: e.number
									}),
									children: d("games.tomeornottome.match", {
										n: e.number,
										word: p?.targets.find((t) => t.number === e.number)?.word ?? ""
									})
								}, e.number)), /* @__PURE__ */ l("button", {
									className: "tome-secondary",
									"aria-pressed": f.voted.includes(r) && p?.vote === null,
									onClick: () => o({
										type: "judge",
										holder: null
									}),
									children: d("games.tomeornottome.wrong")
								})]
							}) : /* @__PURE__ */ l("p", { children: d("games.tomeornottome.waitJudge") }),
							/* @__PURE__ */ l("p", { children: d("games.tomeornottome.voted", {
								n: f.voted.length,
								total: f.players.length - 1
							}) })
						] }) : /* @__PURE__ */ l("p", { children: d("games.tomeornottome.guessing", { name: E(f.pending.player) }) })
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/tomeornottome/bot.ts
var W = ({ public: e, private: t }, { rid: n }) => {
	if (!t || !e.players.includes(n)) return null;
	if (e.phase === "play" && e.turn === n) {
		for (let r of t.hand) {
			let i = r.number === 0 || e.holders.some((e) => e.number === r.number && (e.owner === n || e.solved)), a = e.holders.find((e) => !e.solved && e.owner !== n && (i || r.number === e.number));
			if (a && !t.targets.some((e) => _(e.word) === "placeholder")) return { action: {
				type: "clue",
				card: r.id,
				target: a.number,
				word: "placeholder"
			} };
		}
		let r = e.holders.find((e) => !e.solved)?.owner;
		return r ? { action: {
			type: "invite",
			player: r
		} } : null;
	}
	if (e.phase === "guess" && e.pending?.player === n) return { action: {
		type: "guess",
		word: "unknown"
	} };
	if (e.phase === "judge" && e.pending?.player !== n) {
		let r = e.holders.find((n) => n.owner === e.pending.player && !n.solved && (e.pending.finalHolder === null || e.pending.finalHolder === n.number) && _(t.targets.find((e) => e.number === n.number)?.word ?? "") === _(e.pending.guess ?? ""))?.number ?? null;
		if (!e.voted.includes(n) || t.vote !== r) return { action: {
			type: "judge",
			holder: r
		} };
	}
	return null;
};
//#endregion
//#region src/games/tomeornottome/game-over.tsx
function G({ public: e, members: t, result: n, hintCount: r, onPlayAgain: i, onBackToLobby: o }) {
	let s = e, c = a(), d = (e) => t.find((t) => t.rid === e)?.name ?? e;
	return /* @__PURE__ */ u("div", {
		className: "tome-final",
		children: [
			/* @__PURE__ */ u("header", {
				className: "tome-final-header",
				children: [/* @__PURE__ */ l(I, {}), /* @__PURE__ */ u("div", { children: [/* @__PURE__ */ l("h1", { children: c(s.won ? "games.tomeornottome.won" : "games.tomeornottome.lost") }), /* @__PURE__ */ u("p", { children: [
					c("games.tomeornottome.finalCount", {
						n: s.holders.filter((e) => e.solved).length,
						total: s.holders.length
					}),
					" · ",
					c("games.tomeornottome.unused", { n: Object.values(s.handCounts).reduce((e, t) => e + t, 0) })
				] })] })]
			}),
			/* @__PURE__ */ u("div", {
				className: "tome-final-scroll",
				children: [
					/* @__PURE__ */ u("div", {
						className: "tome-team",
						children: [s.players.map((e) => /* @__PURE__ */ u("span", { children: [d(e), (n.autopilot?.[e] ?? 0) > 0 && /* @__PURE__ */ l("small", { children: c("session.autopilot.share", { n: Math.round(n.autopilot[e] * 100) }) })] }, e)), r !== void 0 && /* @__PURE__ */ l("span", { children: c("session.hint.usedCount", { n: r }) })]
					}),
					/* @__PURE__ */ l("div", {
						className: "tome-holders",
						children: s.holders.map((e) => /* @__PURE__ */ l(R, {
							number: e.number,
							word: e.word,
							name: d(e.owner),
							solved: e.solved
						}, e.number))
					}),
					/* @__PURE__ */ l("section", {
						className: "tome-final-clues",
						children: s.clues.map((e) => /* @__PURE__ */ u("div", { children: [/* @__PURE__ */ l(z, { children: e.word }), /* @__PURE__ */ u("span", { children: [
							d(e.by),
							" · ",
							c("games.tomeornottome.cluesFor", { n: e.target })
						] })] }, e.id))
					}),
					/* @__PURE__ */ u("details", {
						className: "tome-history",
						children: [/* @__PURE__ */ l("summary", { children: c("games.tomeornottome.history") }), s.attempts.length ? /* @__PURE__ */ l("ol", { children: s.attempts.map((e, t) => /* @__PURE__ */ u("li", { children: [
							/* @__PURE__ */ l("span", { children: d(e.by) }),
							/* @__PURE__ */ l("strong", { children: e.word }),
							/* @__PURE__ */ l("b", { children: c(e.correct ? "games.tomeornottome.correct" : "games.tomeornottome.wrong") })
						] }, t)) }) : /* @__PURE__ */ l("p", { children: c("games.tomeornottome.noAttempts") })]
					})
				]
			}),
			/* @__PURE__ */ u("footer", {
				className: "tome-final-actions",
				children: [
					i && /* @__PURE__ */ l(m, {
						className: "tome-button",
						label: c("games.tomeornottome.again"),
						confirmLabel: c("games.tomeornottome.confirmAgain"),
						onConfirm: i
					}),
					o && /* @__PURE__ */ l(m, {
						className: "tome-secondary",
						label: c("games.tomeornottome.lobby"),
						confirmLabel: c("games.tomeornottome.confirmLobby"),
						onConfirm: o
					}),
					!i && !o && /* @__PURE__ */ l("p", { children: c("games.tomeornottome.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/tomeornottome/entry.tsx
var K = {
	definition: P,
	View: H,
	bot: W,
	OverView: G,
	Options: V,
	locales: {
		zh: {
			name: "给我！……还是他？",
			desc: "用自定义词库合作猜词：这些提示究竟写给谁？",
			rules: "目标：\n3–6人合作猜出全部卡架上的词。你能看见别人的词，却看不见自己的词；提示写给谁要保密，直到游戏结束。\n\n自定义词库：\n本版只提供自定义词库。房主在设置中粘贴词表或导入文本文件，每行一词，至少6个有效且不重复的词。词条最多40字、最多500条；空行、重复词与无效词条不计入。系统随机抽取目标词，不包含官方词卡。若开局尚未填写，房主可以在发词前补充。输入词表的人可能记得词库范围，应避免刻意记忆单词位置。\n\n准备：\n每人默认1个卡架，3人默认每人2个，共6个。卡架按玩家顺序编号；额外卡架最多补到6个。4个及以下卡架使用2枚猜词棋子，5–6个使用3枚。每个编号各有3张提示牌，洗匀发给玩家；玩家只能看自己的牌。所有玩家始终参与，包括已经猜出自己词的人。\n\n轮到你：\n从1号卡架的玩家开始，顺时针选择一个行动。\n· 给出提示：选择一张提示牌，按其秘密编号给对应卡架写提示，牌面放在自己面前；不公开提示对象。自己卡架编号、已猜中编号及通配牌可以为任意其他未猜中的词给提示。提示只依据词义，禁止翻译、同词族、符号、缩写、其他可见目标词及专有名词（启用相应难度选项时例外）。语义是否合法由玩家遵守规则判断，不能通过评论、表情或讨论暗示对象。牌用完后只能选择猜词行动。\n· 使用猜词棋子：选择自己或任何仍有未猜中词的玩家，邀请其说出一个答案。\n\n猜词：\n猜对时归还棋子、翻开对应卡架，该编号剩余提示牌变为通配。3人双卡架时，答案可以命中自己的任一未完成卡架。猜错时损失1枚棋子，不公开目标词。文字完全匹配时自动判为正确；其他表达由所有其余玩家一致确认，可修改自己的判断直到一致。提示牌继续留在桌面，不提前透露归属。\n\n结束：\n全部目标词猜中则共同胜利，剩余提示牌越多越好；棋子耗尽但仍有未完成目标则共同失败。终局公开全部目标和提示归属，供大家复盘。\n\n难度选项：\n可以增加卡架、增减猜词棋子、加入2张通配牌、允许专有名词作为提示，或开启最后机会。最后机会在棋子耗尽后，让每个未完成卡架各接受一次最终猜测；最终猜测只针对界面指定的卡架，不再给提示。",
			wordSource: "词库",
			custom: "自定义词库",
			words: "词表",
			wordsHint: "每行一词，至少6个有效词；最多500条，每条最多40字。空行、重复及无效词条不计入。",
			import: "导入文本文件",
			count: "{{n}} 个有效词",
			needWords: "请先输入至少6个有效词。",
			tooLarge: "文件过大，请使用不超过20,000字的文本词表。",
			fileError: "无法读取文件，请粘贴词表。",
			double: "3人时每人使用两个卡架",
			extra: "额外卡架（总数最多6个）",
			extraCount: "增加 {{n}} 个",
			noExtra: "不增加",
			pawns: "猜词棋子",
			standard: "标准数量",
			fewer: "减少1枚",
			more: "增加1枚",
			most: "增加2枚",
			wild: "加入2张通配提示牌",
			proper: "允许专有名词提示",
			last: "棋子耗尽后保留最后机会",
			start: "随机发词",
			prepare: "等待房主填写自定义词库",
			turn: "轮到 {{name}}",
			guessing: "{{name}} 正在猜词",
			judging: "请其他玩家确认答案",
			feedback: "正在确认结果",
			solved: "已猜中 {{n}} / {{total}}",
			pawnCount: "剩余 {{n}} 枚",
			mine: "你的词",
			done: "已猜中",
			holder: "{{n}}号卡架",
			invite: "使用猜词棋子",
			choosePlayer: "请选择猜词的玩家",
			cancel: "取消",
			write: "填写提示",
			clueFor: "给 {{n}} 号卡架的提示",
			clue: "提示",
			clueWord: "输入提示",
			play: "放下提示牌",
			hand: "你的提示牌",
			wildCard: "通配",
			wildTarget: "选择提示对象",
			noCards: "你的提示牌已用完。轮到你时，选择一名玩家猜词。",
			noClues: "还没有提示牌",
			table: "桌上的提示",
			cardCount: "{{n}} 张提示牌",
			guess: "说出你的答案",
			guessWord: "输入答案",
			submit: "提交答案",
			correct: "正确",
			wrong: "不正确",
			match: "对应 {{n}} 号：{{word}}",
			guessed: "答案：{{word}}",
			voted: "{{n}} / {{total}} 人已确认",
			waitJudge: "等待其他玩家确认答案",
			lastGuess: "{{n}}号卡架的最后机会",
			won: "全部猜中！",
			lost: "再试一次！",
			finalCount: "猜中 {{n}} / {{total}} 个词",
			unused: "剩余 {{n}} 张提示牌",
			history: "猜词记录",
			cluesFor: "提示给了 {{n}} 号",
			noAttempts: "没有猜词记录",
			again: "再玩一局",
			lobby: "返回大厅",
			confirmAgain: "确认重新开始？",
			confirmLobby: "确认返回大厅？",
			waitHost: "等待房主开始下一局",
			invalidAction: "现在不能这样操作，请检查行动对象和提示内容。"
		},
		en: {
			name: "To Me ! ...or not to me ?",
			desc: "Cooperate with a custom word list. Who are these clues really for?",
			rules: "Goal:\n3–6 players cooperate to guess every word. You see everyone else’s words, but never your own. Keep the intended recipient of each clue secret until the end.\n\nCustom word list:\nOnly custom lists are available. The host pastes a list or imports a text file in settings: one word per line, at least 6 distinct valid words, up to 500 entries and 40 characters each. Blank, duplicate and invalid entries are excluded. Words are drawn randomly; official word cards are not included. An empty list can be completed before dealing. The person entering the list may remember the pool and should avoid memorising word positions.\n\nSetup:\nEach player normally has one holder; with 3 players, each normally has two, for 6 words. Holders are numbered in player order; additional holders can bring the total up to 6. Use 2 guess pawns for up to 4 holders, or 3 for 5–6. Shuffle three clue cards for each holder number and deal them to the players. Keep your numbers secret. Everyone continues to play after guessing their own word.\n\nYour turn:\nStarting with the owner of holder 1, take turns clockwise and choose one action.\n· Give a clue: select a clue card and write a clue for its secret numbered holder, then place it in front of yourself. A card bearing your own holder number, an already solved number, or a wild card can give a clue to any other unsolved word. Clues must concern meaning only. Translations, related word forms, symbols, acronyms, other visible target words and proper nouns are forbidden (unless the proper-noun option is enabled). Players enforce semantic restrictions. Do not discuss, comment on or otherwise signal clue recipients. With no cards left, you must invite a guess.\n· Use a guess pawn: choose yourself or anyone with an unsolved word and ask them to guess.\n\nGuessing:\nA correct answer returns the pawn and reveals that holder. Its remaining numbered cards become wild. With two holders, an ordinary guess can match either of your unsolved words. A wrong answer loses one pawn without revealing the target. Exact text matches are accepted automatically; other answers require agreement from all other players, who may revise their votes until unanimous. Played clues stay on the table; recipients remain secret.\n\nEnd:\nGuess all words to win together. More unused clue cards means a better victory. Run out of pawns with words left to lose together. All targets and clue recipients are revealed for discussion at the end.\n\nDifficulty options:\nAdd holders, change pawn counts, add 2 wild cards, allow proper nouns as clues, or enable a last chance. Last chance gives each unsolved holder one final guess when pawns run out. Each final guess is for its designated holder only, with no more clues.",
			wordSource: "Word source",
			custom: "Custom word list",
			words: "Word list",
			wordsHint: "One word per line; at least 6 valid words. Up to 500 entries, 40 characters each. Blank, duplicate and invalid entries are excluded.",
			import: "Import text file",
			count: "{{n}} valid words",
			needWords: "Enter at least 6 valid words first.",
			tooLarge: "File is too large. Use a text list of at most 20,000 characters.",
			fileError: "Cannot read the file. Paste the list instead.",
			double: "Two holders each with 3 players",
			extra: "Extra holders (6 total maximum)",
			extraCount: "Add {{n}}",
			noExtra: "None",
			pawns: "Guess pawns",
			standard: "Standard",
			fewer: "One fewer",
			more: "One extra",
			most: "Two extra",
			wild: "Add 2 wild clue cards",
			proper: "Allow proper nouns as clues",
			last: "One last chance after pawns run out",
			start: "Deal random words",
			prepare: "Waiting for the host’s custom word list",
			turn: "{{name}}’s turn",
			guessing: "{{name}} is guessing",
			judging: "Other players: confirm the answer",
			feedback: "Confirming the result",
			solved: "{{n}} / {{total}} solved",
			pawnCount: "{{n}} left",
			mine: "Your word",
			done: "Solved",
			holder: "Holder {{n}}",
			invite: "Use a guess pawn",
			choosePlayer: "Choose someone to guess",
			cancel: "Cancel",
			write: "Write a clue",
			clueFor: "Clue for holder {{n}}",
			clue: "Clue",
			clueWord: "Enter a clue",
			play: "Place clue card",
			hand: "Your clue cards",
			wildCard: "Wild",
			wildTarget: "Choose a clue recipient",
			noCards: "No clue cards left. On your turn, invite someone to guess.",
			noClues: "No clues yet",
			table: "Clues on the table",
			cardCount: "{{n}} clue cards",
			guess: "What is your word?",
			guessWord: "Enter your answer",
			submit: "Submit answer",
			correct: "Correct",
			wrong: "Incorrect",
			match: "Holder {{n}}: {{word}}",
			guessed: "Answer: {{word}}",
			voted: "{{n}} / {{total}} confirmed",
			waitJudge: "Waiting for the other players",
			lastGuess: "Last chance for holder {{n}}",
			won: "Every word found!",
			lost: "Try again!",
			finalCount: "{{n}} / {{total}} words found",
			unused: "{{n}} unused clue cards",
			history: "Guess history",
			cluesFor: "Clue for holder {{n}}",
			noAttempts: "No guesses yet",
			again: "Play again",
			lobby: "Back to lobby",
			confirmAgain: "Start a new game?",
			confirmLobby: "Return to lobby?",
			waitHost: "Waiting for the host to start again",
			invalidAction: "This action is unavailable. Check the target and clue."
		}
	}
};
//#endregion
export { K as default };
