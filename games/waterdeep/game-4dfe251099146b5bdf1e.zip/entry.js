import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useCallback as n, useRef as r, useState as i } from "react";
import { BottomSheet as a } from "@bgparty/sdk/bottom-sheet";
import { useFxAnchor as o, useFxAnchorsMaybe as s } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as c } from "@bgparty/sdk/fx/delta-number";
import { IconExpand as l, IconInfo as u, IconLog as d } from "@bgparty/sdk/icons";
import { useI18nSettings as f, useT as p } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as m } from "@bgparty/sdk/player-colors";
import { Texture as h } from "@bgparty/sdk/texture";
import { useWakeLock as g } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as _ } from "@bgparty/sdk/ui/game-screen";
import { LogSheet as v } from "@bgparty/sdk/ui/log-sheet";
import { seatName as ee } from "@bgparty/sdk/ui/player-strip";
import { gameAssetUrl as te } from "@bgparty/sdk/assets";
import { Fragment as y, jsx as b, jsxs as x } from "react/jsx-runtime";
import { Floater as S, FlySprite as C, PulseBox as w } from "@bgparty/sdk/fx/primitives";
import { OptionSwitch as ne } from "@bgparty/sdk/ui/game-options";
//#region src/games/waterdeep/data.ts
var T = [
	{
		id: 1600,
		nameKey: "games.waterdeep.n1600",
		textKey: "games.waterdeep.d1600",
		type: "arcana",
		cost: "c1w2",
		reward: "v8f1g2",
		plot: !1,
		scope: "base"
	},
	{
		id: 1601,
		nameKey: "games.waterdeep.n1601",
		textKey: "games.waterdeep.d1601",
		type: "arcana",
		cost: "f1w2g2",
		reward: "v6",
		plot: !0,
		scope: "base"
	},
	{
		id: 1602,
		nameKey: "games.waterdeep.n1602",
		textKey: "games.waterdeep.d1602",
		type: "arcana",
		cost: "c1f1r2w2g2",
		reward: "v20i1",
		plot: !1,
		scope: "base"
	},
	{
		id: 1603,
		nameKey: "games.waterdeep.n1603",
		textKey: "games.waterdeep.d1603",
		type: "arcana",
		cost: "f2w2g4",
		reward: "v9c2",
		plot: !1,
		scope: "base"
	},
	{
		id: 1604,
		nameKey: "games.waterdeep.n1604",
		textKey: "games.waterdeep.d1604",
		type: "arcana",
		cost: "w5g2",
		reward: "v25",
		plot: !1,
		scope: "base"
	},
	{
		id: 1605,
		nameKey: "games.waterdeep.n1605",
		textKey: "games.waterdeep.d1605",
		type: "arcana",
		cost: "c1f1w2",
		reward: "v13i1",
		plot: !1,
		scope: "base"
	},
	{
		id: 1606,
		nameKey: "games.waterdeep.n1606",
		textKey: "games.waterdeep.d1606",
		type: "arcana",
		cost: "r3w2",
		reward: "v6",
		plot: !0,
		scope: "base"
	},
	{
		id: 1607,
		nameKey: "games.waterdeep.n1607",
		textKey: "games.waterdeep.d1607",
		type: "arcana",
		cost: "f1r1w2g4",
		reward: "v6w3",
		plot: !1,
		scope: "base"
	},
	{
		id: 1608,
		nameKey: "games.waterdeep.n1608",
		textKey: "games.waterdeep.d1608",
		type: "arcana",
		cost: "w2g4",
		reward: "v4w1",
		plot: !1,
		scope: "base"
	},
	{
		id: 1609,
		nameKey: "games.waterdeep.n1609",
		textKey: "games.waterdeep.d1609",
		type: "arcana",
		cost: "f2r1w2",
		reward: "v11g4",
		plot: !1,
		scope: "base"
	},
	{
		id: 1610,
		nameKey: "games.waterdeep.n1610",
		textKey: "games.waterdeep.d1610",
		type: "arcana",
		cost: "f1r2w2",
		reward: "v7g4i2",
		plot: !1,
		scope: "base"
	},
	{
		id: 1611,
		nameKey: "games.waterdeep.n1611",
		textKey: "games.waterdeep.d1611",
		type: "arcana",
		cost: "c1w2",
		reward: "v8",
		plot: !0,
		scope: "base"
	},
	{
		id: 1612,
		nameKey: "games.waterdeep.n1612",
		textKey: "games.waterdeep.d1612",
		type: "commerce",
		cost: "c1r3w1g8",
		reward: "v25",
		plot: !1,
		scope: "base"
	},
	{
		id: 1613,
		nameKey: "games.waterdeep.n1613",
		textKey: "games.waterdeep.d1613",
		type: "commerce",
		cost: "r4w1g4",
		reward: "v10",
		plot: !0,
		scope: "base"
	},
	{
		id: 1614,
		nameKey: "games.waterdeep.n1614",
		textKey: "games.waterdeep.d1614",
		type: "commerce",
		cost: "c1f2g4",
		reward: "v8",
		plot: !0,
		scope: "base"
	},
	{
		id: 1615,
		nameKey: "games.waterdeep.n1615",
		textKey: "games.waterdeep.d1615",
		type: "commerce",
		cost: "c1f2r2w1g4",
		reward: "v18i2",
		plot: !1,
		scope: "base"
	},
	{
		id: 1616,
		nameKey: "games.waterdeep.n1616",
		textKey: "games.waterdeep.d1616",
		type: "commerce",
		cost: "f2r2g4",
		reward: "v6",
		plot: !0,
		scope: "base"
	},
	{
		id: 1617,
		nameKey: "games.waterdeep.n1617",
		textKey: "games.waterdeep.d1617",
		type: "commerce",
		cost: "c1r3g2",
		reward: "v7i1",
		plot: !1,
		scope: "base"
	},
	{
		id: 1618,
		nameKey: "games.waterdeep.n1618",
		textKey: "games.waterdeep.d1618",
		type: "commerce",
		cost: "c1f1r1g2",
		reward: "v4",
		plot: !1,
		scope: "base"
	},
	{
		id: 1619,
		nameKey: "games.waterdeep.n1619",
		textKey: "games.waterdeep.d1619",
		type: "commerce",
		cost: "c2r2g4",
		reward: "v10",
		plot: !1,
		scope: "base"
	},
	{
		id: 1620,
		nameKey: "games.waterdeep.n1620",
		textKey: "games.waterdeep.d1620",
		type: "commerce",
		cost: "f1r1w1g4",
		reward: "v4w2",
		plot: !1,
		scope: "base"
	},
	{
		id: 1621,
		nameKey: "games.waterdeep.n1621",
		textKey: "games.waterdeep.d1621",
		type: "commerce",
		cost: "c1f1r1g4",
		reward: "v15",
		plot: !1,
		scope: "base"
	},
	{
		id: 1622,
		nameKey: "games.waterdeep.n1622",
		textKey: "games.waterdeep.d1622",
		type: "commerce",
		cost: "f3r2g2",
		reward: "v6g6",
		plot: !1,
		scope: "base"
	},
	{
		id: 1623,
		nameKey: "games.waterdeep.n1623",
		textKey: "games.waterdeep.d1623",
		type: "commerce",
		cost: "c1f1r1g4",
		reward: "v9r4",
		plot: !1,
		scope: "base"
	},
	{
		id: 1624,
		nameKey: "games.waterdeep.n1624",
		textKey: "games.waterdeep.d1624",
		type: "piety",
		cost: "c2f1",
		reward: "v8",
		plot: !1,
		scope: "base"
	},
	{
		id: 1625,
		nameKey: "games.waterdeep.n1625",
		textKey: "games.waterdeep.d1625",
		type: "piety",
		cost: "c5g2",
		reward: "v25",
		plot: !1,
		scope: "base"
	},
	{
		id: 1626,
		nameKey: "games.waterdeep.n1626",
		textKey: "games.waterdeep.d1626",
		type: "piety",
		cost: "c2f1r1w1",
		reward: "a1",
		plot: !0,
		scope: "base"
	},
	{
		id: 1627,
		nameKey: "games.waterdeep.n1627",
		textKey: "games.waterdeep.d1627",
		type: "piety",
		cost: "c2f1r1",
		reward: "v10",
		plot: !1,
		scope: "base"
	},
	{
		id: 1628,
		nameKey: "games.waterdeep.n1628",
		textKey: "games.waterdeep.d1628",
		type: "piety",
		cost: "c2f2r1",
		reward: "v11g4",
		plot: !1,
		scope: "base"
	},
	{
		id: 1629,
		nameKey: "games.waterdeep.n1629",
		textKey: "games.waterdeep.d1629",
		type: "piety",
		cost: "c2w1",
		reward: "v10",
		plot: !1,
		scope: "base"
	},
	{
		id: 1630,
		nameKey: "games.waterdeep.n1630",
		textKey: "games.waterdeep.d1630",
		type: "piety",
		cost: "c2w1g4",
		reward: "v6f6",
		plot: !1,
		scope: "base"
	},
	{
		id: 1631,
		nameKey: "games.waterdeep.n1631",
		textKey: "games.waterdeep.d1631",
		type: "piety",
		cost: "c2f2g4",
		reward: "v12c1f1",
		plot: !1,
		scope: "base"
	},
	{
		id: 1632,
		nameKey: "games.waterdeep.n1632",
		textKey: "games.waterdeep.d1632",
		type: "piety",
		cost: "c2g4",
		reward: "v5",
		plot: !0,
		scope: "base"
	},
	{
		id: 1633,
		nameKey: "games.waterdeep.n1633",
		textKey: "games.waterdeep.d1633",
		type: "piety",
		cost: "c2f1g2",
		reward: "v8",
		plot: !0,
		scope: "base"
	},
	{
		id: 1634,
		nameKey: "games.waterdeep.n1634",
		textKey: "games.waterdeep.d1634",
		type: "piety",
		cost: "c2f4g4",
		reward: "v10c3",
		plot: !1,
		scope: "base"
	},
	{
		id: 1635,
		nameKey: "games.waterdeep.n1635",
		textKey: "games.waterdeep.d1635",
		type: "piety",
		cost: "c2r3g4",
		reward: "v20",
		plot: !1,
		scope: "base"
	},
	{
		id: 1636,
		nameKey: "games.waterdeep.n1636",
		textKey: "games.waterdeep.d1636",
		type: "skullduggery",
		cost: "f1r3g4",
		reward: "v10i1",
		plot: !1,
		scope: "base"
	},
	{
		id: 1637,
		nameKey: "games.waterdeep.n1637",
		textKey: "games.waterdeep.d1637",
		type: "skullduggery",
		cost: "f2r3g2",
		reward: "v8",
		plot: !1,
		scope: "base"
	},
	{
		id: 1638,
		nameKey: "games.waterdeep.n1638",
		textKey: "games.waterdeep.d1638",
		type: "skullduggery",
		cost: "f1r8w1",
		reward: "v25",
		plot: !1,
		scope: "base"
	},
	{
		id: 1639,
		nameKey: "games.waterdeep.n1639",
		textKey: "games.waterdeep.d1639",
		type: "skullduggery",
		cost: "c1r4",
		reward: "v4c2",
		plot: !1,
		scope: "base"
	},
	{
		id: 1640,
		nameKey: "games.waterdeep.n1640",
		textKey: "games.waterdeep.d1640",
		type: "skullduggery",
		cost: "f1r3g4",
		reward: "v6",
		plot: !0,
		scope: "base"
	},
	{
		id: 1641,
		nameKey: "games.waterdeep.n1641",
		textKey: "games.waterdeep.d1641",
		type: "skullduggery",
		cost: "r4g4",
		reward: "v8",
		plot: !0,
		scope: "base"
	},
	{
		id: 1642,
		nameKey: "games.waterdeep.n1642",
		textKey: "games.waterdeep.d1642",
		type: "skullduggery",
		cost: "f1r4w1",
		reward: "",
		plot: !0,
		scope: "base"
	},
	{
		id: 1643,
		nameKey: "games.waterdeep.n1643",
		textKey: "games.waterdeep.d1643",
		type: "skullduggery",
		cost: "r4w2g2",
		reward: "v14f2",
		plot: !1,
		scope: "base"
	},
	{
		id: 1644,
		nameKey: "games.waterdeep.n1644",
		textKey: "games.waterdeep.d1644",
		type: "skullduggery",
		cost: "r3g6",
		reward: "v8i2",
		plot: !1,
		scope: "base"
	},
	{
		id: 1645,
		nameKey: "games.waterdeep.n1645",
		textKey: "games.waterdeep.d1645",
		type: "skullduggery",
		cost: "c1f2r4w1",
		reward: "v20g2",
		plot: !1,
		scope: "base"
	},
	{
		id: 1646,
		nameKey: "games.waterdeep.n1646",
		textKey: "games.waterdeep.d1646",
		type: "skullduggery",
		cost: "f1r4w1",
		reward: "v10g6",
		plot: !1,
		scope: "base"
	},
	{
		id: 1647,
		nameKey: "games.waterdeep.n1647",
		textKey: "games.waterdeep.d1647",
		type: "skullduggery",
		cost: "f1r2w1g6",
		reward: "v10r4",
		plot: !1,
		scope: "base"
	},
	{
		id: 1648,
		nameKey: "games.waterdeep.n1648",
		textKey: "games.waterdeep.d1648",
		type: "warfare",
		cost: "c1f3r1",
		reward: "v8g4",
		plot: !1,
		scope: "base"
	},
	{
		id: 1649,
		nameKey: "games.waterdeep.n1649",
		textKey: "games.waterdeep.d1649",
		type: "warfare",
		cost: "f9r2",
		reward: "v25",
		plot: !1,
		scope: "base"
	},
	{
		id: 1650,
		nameKey: "games.waterdeep.n1650",
		textKey: "games.waterdeep.d1650",
		type: "warfare",
		cost: "f4g4",
		reward: "v6",
		plot: !0,
		scope: "base"
	},
	{
		id: 1651,
		nameKey: "games.waterdeep.n1651",
		textKey: "games.waterdeep.d1651",
		type: "warfare",
		cost: "c1f4r2w1",
		reward: "v20g2",
		plot: !1,
		scope: "base"
	},
	{
		id: 1652,
		nameKey: "games.waterdeep.n1652",
		textKey: "games.waterdeep.d1652",
		type: "warfare",
		cost: "c1f3r1g2",
		reward: "v11f2",
		plot: !1,
		scope: "base"
	},
	{
		id: 1653,
		nameKey: "games.waterdeep.n1653",
		textKey: "games.waterdeep.d1653",
		type: "warfare",
		cost: "f4r1w1g2",
		reward: "v9c2",
		plot: !1,
		scope: "base"
	},
	{
		id: 1654,
		nameKey: "games.waterdeep.n1654",
		textKey: "games.waterdeep.d1654",
		type: "warfare",
		cost: "f4r1w1",
		reward: "v11g4",
		plot: !1,
		scope: "base"
	},
	{
		id: 1655,
		nameKey: "games.waterdeep.n1655",
		textKey: "games.waterdeep.d1655",
		type: "warfare",
		cost: "c1f4",
		reward: "v8",
		plot: !0,
		scope: "base"
	},
	{
		id: 1656,
		nameKey: "games.waterdeep.n1656",
		textKey: "games.waterdeep.d1656",
		type: "warfare",
		cost: "f4r2",
		reward: "v8g4",
		plot: !1,
		scope: "base"
	},
	{
		id: 1657,
		nameKey: "games.waterdeep.n1657",
		textKey: "games.waterdeep.d1657",
		type: "warfare",
		cost: "c1f5r1w1",
		reward: "",
		plot: !0,
		scope: "base"
	},
	{
		id: 1658,
		nameKey: "games.waterdeep.n1658",
		textKey: "games.waterdeep.d1658",
		type: "warfare",
		cost: "c1f4w1",
		reward: "v15g2",
		plot: !1,
		scope: "base"
	},
	{
		id: 1659,
		nameKey: "games.waterdeep.n1659",
		textKey: "games.waterdeep.d1659",
		type: "warfare",
		cost: "f3w1",
		reward: "v4f1w1",
		plot: !1,
		scope: "base"
	},
	{
		id: 1700,
		nameKey: "games.waterdeep.n1700",
		textKey: "games.waterdeep.d1700",
		type: "arcana",
		cost: "r2w2g3",
		reward: "v18f2w1i1x3",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 1701,
		nameKey: "games.waterdeep.n1701",
		textKey: "games.waterdeep.d1701",
		type: "arcana",
		cost: "c1f2r2w2g2",
		reward: "v13a2i2",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 1702,
		nameKey: "games.waterdeep.n1702",
		textKey: "games.waterdeep.d1702",
		type: "arcana",
		cost: "f1w1g2",
		reward: "v8",
		plot: !0,
		scope: "skullport"
	},
	{
		id: 1703,
		nameKey: "games.waterdeep.n1703",
		textKey: "games.waterdeep.d1703",
		type: "arcana",
		cost: "c1f1w2g2",
		reward: "v9",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 1704,
		nameKey: "games.waterdeep.n1704",
		textKey: "games.waterdeep.d1704",
		type: "arcana",
		cost: "c1f2r2w2",
		reward: "v10",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 1705,
		nameKey: "games.waterdeep.n1705",
		textKey: "games.waterdeep.d1705",
		type: "arcana",
		cost: "r2w3",
		reward: "v17",
		plot: !0,
		scope: "skullport"
	},
	{
		id: 1706,
		nameKey: "games.waterdeep.n1706",
		textKey: "games.waterdeep.d1706",
		type: "commerce",
		cost: "c1f2r2g4",
		reward: "v9",
		plot: !0,
		scope: "skullport"
	},
	{
		id: 1707,
		nameKey: "games.waterdeep.n1707",
		textKey: "games.waterdeep.d1707",
		type: "commerce",
		cost: "c2w1g10",
		reward: "v13",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 1708,
		nameKey: "games.waterdeep.n1708",
		textKey: "games.waterdeep.d1708",
		type: "commerce",
		cost: "r2g4",
		reward: "v8",
		plot: !0,
		scope: "skullport"
	},
	{
		id: 1709,
		nameKey: "games.waterdeep.n1709",
		textKey: "games.waterdeep.d1709",
		type: "commerce",
		cost: "c1r1w2g4",
		reward: "v20g12x3",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 1710,
		nameKey: "games.waterdeep.n1710",
		textKey: "games.waterdeep.d1710",
		type: "commerce",
		cost: "c1f1r2g5",
		reward: "v16",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 1711,
		nameKey: "games.waterdeep.n1711",
		textKey: "games.waterdeep.d1711",
		type: "commerce",
		cost: "c1r3g4",
		reward: "v4",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 1712,
		nameKey: "games.waterdeep.n1712",
		textKey: "games.waterdeep.d1712",
		type: "piety",
		cost: "c2f2w1",
		reward: "v5a1",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 1713,
		nameKey: "games.waterdeep.n1713",
		textKey: "games.waterdeep.d1713",
		type: "piety",
		cost: "a7",
		reward: "v19c3x4",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 1714,
		nameKey: "games.waterdeep.n1714",
		textKey: "games.waterdeep.d1714",
		type: "piety",
		cost: "c1r1g2",
		reward: "v8",
		plot: !0,
		scope: "skullport"
	},
	{
		id: 1715,
		nameKey: "games.waterdeep.n1715",
		textKey: "games.waterdeep.d1715",
		type: "piety",
		cost: "c4f1r1g2",
		reward: "v13",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 1716,
		nameKey: "games.waterdeep.n1716",
		textKey: "games.waterdeep.d1716",
		type: "piety",
		cost: "c3f2w1",
		reward: "v10",
		plot: !0,
		scope: "skullport"
	},
	{
		id: 1717,
		nameKey: "games.waterdeep.n1717",
		textKey: "games.waterdeep.d1717",
		type: "piety",
		cost: "c2w1g5",
		reward: "v18",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 1718,
		nameKey: "games.waterdeep.n1718",
		textKey: "games.waterdeep.d1718",
		type: "skullduggery",
		cost: "f2r3g2",
		reward: "v20x2",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 1719,
		nameKey: "games.waterdeep.n1719",
		textKey: "games.waterdeep.d1719",
		type: "skullduggery",
		cost: "f1r2g2",
		reward: "v8",
		plot: !0,
		scope: "skullport"
	},
	{
		id: 1720,
		nameKey: "games.waterdeep.n1720",
		textKey: "games.waterdeep.d1720",
		type: "skullduggery",
		cost: "f2r4w1",
		reward: "v9a1",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 1721,
		nameKey: "games.waterdeep.n1721",
		textKey: "games.waterdeep.d1721",
		type: "skullduggery",
		cost: "r6w2g5",
		reward: "v9f4",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 1722,
		nameKey: "games.waterdeep.n1722",
		textKey: "games.waterdeep.d1722",
		type: "skullduggery",
		cost: "c1f3w2",
		reward: "v16x1",
		plot: !0,
		scope: "skullport"
	},
	{
		id: 1723,
		nameKey: "games.waterdeep.n1723",
		textKey: "games.waterdeep.d1723",
		type: "skullduggery",
		cost: "c1f2r3g5",
		reward: "v13x3",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 1724,
		nameKey: "games.waterdeep.n1724",
		textKey: "games.waterdeep.d1724",
		type: "warfare",
		cost: "f4r1",
		reward: "v16x2",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 1725,
		nameKey: "games.waterdeep.n1725",
		textKey: "games.waterdeep.d1725",
		type: "warfare",
		cost: "f3g2",
		reward: "v8",
		plot: !0,
		scope: "skullport"
	},
	{
		id: 1726,
		nameKey: "games.waterdeep.n1726",
		textKey: "games.waterdeep.d1726",
		type: "warfare",
		cost: "c1f4r2g4",
		reward: "v8",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 1727,
		nameKey: "games.waterdeep.n1727",
		textKey: "games.waterdeep.d1727",
		type: "warfare",
		cost: "c1f3r2g2",
		reward: "v9r4",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 1728,
		nameKey: "games.waterdeep.n1728",
		textKey: "games.waterdeep.d1728",
		type: "warfare",
		cost: "f2w1g5",
		reward: "v10",
		plot: !0,
		scope: "skullport"
	},
	{
		id: 1729,
		nameKey: "games.waterdeep.n1729",
		textKey: "games.waterdeep.d1729",
		type: "warfare",
		cost: "c1f5r2g5",
		reward: "v18",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 1730,
		nameKey: "games.waterdeep.n1730",
		textKey: "games.waterdeep.d1730",
		type: "arcana",
		cost: "f1r4w2g5",
		reward: "v10",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 1731,
		nameKey: "games.waterdeep.n1731",
		textKey: "games.waterdeep.d1731",
		type: "arcana",
		cost: "c1f1r3w3",
		reward: "v12",
		plot: !0,
		scope: "undermountain"
	},
	{
		id: 1732,
		nameKey: "games.waterdeep.n1732",
		textKey: "games.waterdeep.d1732",
		type: "arcana",
		cost: "f2r3w4g6",
		reward: "v40",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 1733,
		nameKey: "games.waterdeep.n1733",
		textKey: "games.waterdeep.d1733",
		type: "arcana",
		cost: "c3g5",
		reward: "v6w3",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 1734,
		nameKey: "games.waterdeep.n1734",
		textKey: "games.waterdeep.d1734",
		type: "arcana",
		cost: "r2w5g5",
		reward: "v11",
		plot: !0,
		scope: "undermountain"
	},
	{
		id: 1735,
		nameKey: "games.waterdeep.n1735",
		textKey: "games.waterdeep.d1735",
		type: "arcana",
		cost: "c1f1a4",
		reward: "v15",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 1736,
		nameKey: "games.waterdeep.n1736",
		textKey: "games.waterdeep.d1736",
		type: "commerce",
		cost: "f2r2w1g10",
		reward: "v13",
		plot: !0,
		scope: "undermountain"
	},
	{
		id: 1737,
		nameKey: "games.waterdeep.n1737",
		textKey: "games.waterdeep.d1737",
		type: "commerce",
		cost: "c2f3r4g10",
		reward: "v40",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 1738,
		nameKey: "games.waterdeep.n1738",
		textKey: "games.waterdeep.d1738",
		type: "commerce",
		cost: "c1w1",
		reward: "v8",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 1739,
		nameKey: "games.waterdeep.n1739",
		textKey: "games.waterdeep.d1739",
		type: "commerce",
		cost: "c1f4r3g6",
		reward: "v12",
		plot: !0,
		scope: "undermountain"
	},
	{
		id: 1740,
		nameKey: "games.waterdeep.n1740",
		textKey: "games.waterdeep.d1740",
		type: "commerce",
		cost: "r4w2",
		reward: "v7g10",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 1741,
		nameKey: "games.waterdeep.n1741",
		textKey: "games.waterdeep.d1741",
		type: "commerce",
		cost: "f2r4w2g10",
		reward: "v13",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 1742,
		nameKey: "games.waterdeep.n1742",
		textKey: "games.waterdeep.d1742",
		type: "piety",
		cost: "c3f3g3",
		reward: "v10",
		plot: !0,
		scope: "undermountain"
	},
	{
		id: 1743,
		nameKey: "games.waterdeep.n1743",
		textKey: "games.waterdeep.d1743",
		type: "piety",
		cost: "c3r4g5",
		reward: "v11c1f1r1w1",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 1744,
		nameKey: "games.waterdeep.n1744",
		textKey: "games.waterdeep.d1744",
		type: "piety",
		cost: "c5f2r2w1",
		reward: "v40",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 1745,
		nameKey: "games.waterdeep.n1745",
		textKey: "games.waterdeep.d1745",
		type: "piety",
		cost: "f6w2",
		reward: "v10c3",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 1746,
		nameKey: "games.waterdeep.n1746",
		textKey: "games.waterdeep.d1746",
		type: "piety",
		cost: "f1w1a4",
		reward: "v15",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 1747,
		nameKey: "games.waterdeep.n1747",
		textKey: "games.waterdeep.d1747",
		type: "piety",
		cost: "c4f2g5",
		reward: "v13",
		plot: !0,
		scope: "undermountain"
	},
	{
		id: 1748,
		nameKey: "games.waterdeep.n1748",
		textKey: "games.waterdeep.d1748",
		type: "skullduggery",
		cost: "f2r5w1g5",
		reward: "v10",
		plot: !0,
		scope: "undermountain"
	},
	{
		id: 1749,
		nameKey: "games.waterdeep.n1749",
		textKey: "games.waterdeep.d1749",
		type: "skullduggery",
		cost: "c1r7w2g6",
		reward: "v40",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 1750,
		nameKey: "games.waterdeep.n1750",
		textKey: "games.waterdeep.d1750",
		type: "skullduggery",
		cost: "f3r6w1g10",
		reward: "v12a8",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 1751,
		nameKey: "games.waterdeep.n1751",
		textKey: "games.waterdeep.d1751",
		type: "skullduggery",
		cost: "f1r4w1g5",
		reward: "v9",
		plot: !0,
		scope: "undermountain"
	},
	{
		id: 1752,
		nameKey: "games.waterdeep.n1752",
		textKey: "games.waterdeep.d1752",
		type: "skullduggery",
		cost: "f6g5",
		reward: "v6r6",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 1753,
		nameKey: "games.waterdeep.n1753",
		textKey: "games.waterdeep.d1753",
		type: "skullduggery",
		cost: "c1f1r1w1",
		reward: "v12",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 1754,
		nameKey: "games.waterdeep.n1754",
		textKey: "games.waterdeep.d1754",
		type: "warfare",
		cost: "c2f7w2g2",
		reward: "v40",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 1755,
		nameKey: "games.waterdeep.n1755",
		textKey: "games.waterdeep.d1755",
		type: "warfare",
		cost: "c3f6r1w1",
		reward: "v15a2",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 1756,
		nameKey: "games.waterdeep.n1756",
		textKey: "games.waterdeep.d1756",
		type: "warfare",
		cost: "c1f2g2",
		reward: "v10",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 1757,
		nameKey: "games.waterdeep.n1757",
		textKey: "games.waterdeep.d1757",
		type: "warfare",
		cost: "f5r3w1g3",
		reward: "v10",
		plot: !0,
		scope: "undermountain"
	},
	{
		id: 1758,
		nameKey: "games.waterdeep.n1758",
		textKey: "games.waterdeep.d1758",
		type: "warfare",
		cost: "c1f4w2",
		reward: "v6",
		plot: !0,
		scope: "undermountain"
	},
	{
		id: 1759,
		nameKey: "games.waterdeep.n1759",
		textKey: "games.waterdeep.d1759",
		type: "warfare",
		cost: "c3r3",
		reward: "v8f6",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 2e3,
		nameKey: "games.waterdeep.n2000",
		textKey: "games.waterdeep.d2000",
		type: "mandatory",
		cost: "r2w1",
		reward: "i1",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 2001,
		nameKey: "games.waterdeep.n2001",
		textKey: "games.waterdeep.d2001",
		type: "mandatory",
		cost: "c1r1g2",
		reward: "v2",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 2002,
		nameKey: "games.waterdeep.n2002",
		textKey: "games.waterdeep.d2002",
		type: "mandatory",
		cost: "c1f1r1w1",
		reward: "v2",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 2003,
		nameKey: "games.waterdeep.n2003",
		textKey: "games.waterdeep.d2003",
		type: "mandatory",
		cost: "f1w1g2",
		reward: "v2",
		plot: !1,
		scope: "skullport"
	},
	{
		id: 2004,
		nameKey: "games.waterdeep.n2004",
		textKey: "games.waterdeep.d2004",
		type: "mandatory",
		cost: "c1f1r1",
		reward: "v2",
		plot: !1,
		scope: "base"
	},
	{
		id: 2005,
		nameKey: "games.waterdeep.n2005",
		textKey: "games.waterdeep.d2005",
		type: "mandatory",
		cost: "c1r2",
		reward: "v2",
		plot: !1,
		scope: "base"
	},
	{
		id: 2006,
		nameKey: "games.waterdeep.n2006",
		textKey: "games.waterdeep.d2006",
		type: "mandatory",
		cost: "c2f1",
		reward: "v4",
		plot: !1,
		scope: "base"
	},
	{
		id: 2007,
		nameKey: "games.waterdeep.n2007",
		textKey: "games.waterdeep.d2007",
		type: "mandatory",
		cost: "c1f1w1",
		reward: "v4",
		plot: !1,
		scope: "base"
	},
	{
		id: 2008,
		nameKey: "games.waterdeep.n2008",
		textKey: "games.waterdeep.d2008",
		type: "mandatory",
		cost: "f1r1w1",
		reward: "v2",
		plot: !1,
		scope: "base"
	},
	{
		id: 2009,
		nameKey: "games.waterdeep.n2009",
		textKey: "games.waterdeep.d2009",
		type: "mandatory",
		cost: "f2w1",
		reward: "v2",
		plot: !1,
		scope: "base"
	},
	{
		id: 2010,
		nameKey: "games.waterdeep.n2010",
		textKey: "games.waterdeep.d2010",
		type: "mandatory",
		cost: "c1w1",
		reward: "i1",
		plot: !1,
		scope: "undermountain"
	},
	{
		id: 2011,
		nameKey: "games.waterdeep.n2011",
		textKey: "games.waterdeep.d2011",
		type: "mandatory",
		cost: "c1f2",
		reward: "i1",
		plot: !1,
		scope: "undermountain"
	}
], E = [
	{
		id: 1500,
		nameKey: "games.waterdeep.n1500",
		textKey: "games.waterdeep.d1500",
		cost: 4,
		action: "stock",
		owner: "f1",
		scope: "base"
	},
	{
		id: 1501,
		nameKey: "games.waterdeep.n1501",
		textKey: "games.waterdeep.d1501",
		cost: 3,
		action: "w1i1",
		owner: "i1",
		scope: "base"
	},
	{
		id: 1502,
		nameKey: "games.waterdeep.n1502",
		textKey: "games.waterdeep.d1502",
		cost: 8,
		action: "f2w1",
		owner: "f1/w1",
		scope: "base"
	},
	{
		id: 1503,
		nameKey: "games.waterdeep.n1503",
		textKey: "games.waterdeep.d1503",
		cost: 4,
		action: "stock",
		owner: "g2",
		scope: "base"
	},
	{
		id: 1504,
		nameKey: "games.waterdeep.n1504",
		textKey: "games.waterdeep.d1504",
		cost: 3,
		action: "r2g2",
		owner: "r1",
		scope: "base"
	},
	{
		id: 1505,
		nameKey: "games.waterdeep.n1505",
		textKey: "games.waterdeep.d1505",
		cost: 4,
		action: "quest",
		owner: "v2",
		scope: "base"
	},
	{
		id: 1506,
		nameKey: "games.waterdeep.n1506",
		textKey: "games.waterdeep.d1506",
		cost: 3,
		action: "f1a1",
		owner: "f1",
		scope: "base"
	},
	{
		id: 1507,
		nameKey: "games.waterdeep.n1507",
		textKey: "games.waterdeep.d1507",
		cost: 8,
		action: "c1f2",
		owner: "c1/f1",
		scope: "base"
	},
	{
		id: 1508,
		nameKey: "games.waterdeep.n1508",
		textKey: "games.waterdeep.d1508",
		cost: 4,
		action: "g-2;c1/w1;c1/w1",
		owner: "g2",
		scope: "base"
	},
	{
		id: 1509,
		nameKey: "games.waterdeep.n1509",
		textKey: "games.waterdeep.d1509",
		cost: 3,
		action: "c1;quest",
		owner: "g2",
		scope: "base"
	},
	{
		id: 1510,
		nameKey: "games.waterdeep.n1510",
		textKey: "games.waterdeep.d1510",
		cost: 4,
		action: "stock",
		owner: "r1",
		scope: "base"
	},
	{
		id: 1511,
		nameKey: "games.waterdeep.n1511",
		textKey: "games.waterdeep.d1511",
		cost: 8,
		action: "r2w1",
		owner: "r1/w1",
		scope: "base"
	},
	{
		id: 1512,
		nameKey: "games.waterdeep.n1512",
		textKey: "games.waterdeep.d1512",
		cost: 3,
		action: "a1g2",
		owner: "v2",
		scope: "base"
	},
	{
		id: 1513,
		nameKey: "games.waterdeep.n1513",
		textKey: "games.waterdeep.d1513",
		cost: 4,
		action: "ambassador",
		owner: "v2",
		scope: "base"
	},
	{
		id: 1514,
		nameKey: "games.waterdeep.n1514",
		textKey: "games.waterdeep.d1514",
		cost: 4,
		action: "f1r1g2",
		owner: "f1/r1",
		scope: "base"
	},
	{
		id: 1515,
		nameKey: "games.waterdeep.n1515",
		textKey: "games.waterdeep.d1515",
		cost: 4,
		action: "g-2;f1/r1;f1/r1;f1/r1;f1/r1",
		owner: "g2",
		scope: "base"
	},
	{
		id: 1516,
		nameKey: "games.waterdeep.n1516",
		textKey: "games.waterdeep.d1516",
		cost: 4,
		action: "stock",
		owner: "v2",
		scope: "base"
	},
	{
		id: 1517,
		nameKey: "games.waterdeep.n1517",
		textKey: "games.waterdeep.d1517",
		cost: 4,
		action: "building-count-gold",
		owner: "g2",
		scope: "base"
	},
	{
		id: 1518,
		nameKey: "games.waterdeep.n1518",
		textKey: "games.waterdeep.d1518",
		cost: 4,
		action: "a-2;a3",
		owner: "g2",
		scope: "base"
	},
	{
		id: 1519,
		nameKey: "games.waterdeep.n1519",
		textKey: "games.waterdeep.d1519",
		cost: 8,
		action: "c1r2",
		owner: "c1/r1",
		scope: "base"
	},
	{
		id: 1520,
		nameKey: "games.waterdeep.n1520",
		textKey: "games.waterdeep.d1520",
		cost: 4,
		action: "stock",
		owner: "i1",
		scope: "base"
	},
	{
		id: 1521,
		nameKey: "games.waterdeep.n1521",
		textKey: "games.waterdeep.d1521",
		cost: 4,
		action: "stock;quest",
		owner: "v2",
		scope: "base"
	},
	{
		id: 1522,
		nameKey: "games.waterdeep.n1522",
		textKey: "games.waterdeep.d1522",
		cost: 4,
		action: "a2",
		owner: "a1",
		scope: "base"
	},
	{
		id: 1523,
		nameKey: "games.waterdeep.n1523",
		textKey: "games.waterdeep.d1523",
		cost: 8,
		action: "copy-opponent",
		owner: "v2",
		scope: "base"
	},
	{
		id: 1524,
		nameKey: "games.waterdeep.n1524",
		textKey: "games.waterdeep.d1524",
		cost: 7,
		action: "r3g5x1",
		owner: "g3",
		scope: "skullport"
	},
	{
		id: 1525,
		nameKey: "games.waterdeep.n1525",
		textKey: "games.waterdeep.d1525",
		cost: 6,
		action: "place-own-x1",
		owner: "v2",
		scope: "skullport"
	},
	{
		id: 1526,
		nameKey: "games.waterdeep.n1526",
		textKey: "games.waterdeep.d1526",
		cost: 3,
		action: "stock;recall-per-x",
		owner: "v2",
		scope: "skullport"
	},
	{
		id: 1527,
		nameKey: "games.waterdeep.n1527",
		textKey: "games.waterdeep.d1527",
		cost: 9,
		action: "remove-x2",
		owner: "v3",
		scope: "skullport"
	},
	{
		id: 1528,
		nameKey: "games.waterdeep.n1528",
		textKey: "games.waterdeep.d1528",
		cost: 8,
		action: "return-x1;c1",
		owner: "c1",
		scope: "skullport"
	},
	{
		id: 1529,
		nameKey: "games.waterdeep.n1529",
		textKey: "games.waterdeep.d1529",
		cost: 6,
		action: "c1f3x1",
		owner: "g3",
		scope: "skullport"
	},
	{
		id: 1530,
		nameKey: "games.waterdeep.n1530",
		textKey: "games.waterdeep.d1530",
		cost: 6,
		action: "a1g5x1;quest",
		owner: "v3",
		scope: "skullport"
	},
	{
		id: 1531,
		nameKey: "games.waterdeep.n1531",
		textKey: "games.waterdeep.d1531",
		cost: 4,
		action: "a-1;w3x1",
		owner: "returned-adventurer",
		scope: "skullport"
	},
	{
		id: 1532,
		nameKey: "games.waterdeep.n1532",
		textKey: "games.waterdeep.d1532",
		cost: 8,
		action: "c1f1r1w1x1",
		owner: "a1",
		scope: "skullport"
	},
	{
		id: 1533,
		nameKey: "games.waterdeep.n1533",
		textKey: "games.waterdeep.d1533",
		cost: 5,
		action: "return-x1;play1",
		owner: "i1",
		scope: "skullport"
	},
	{
		id: 1534,
		nameKey: "games.waterdeep.n1534",
		textKey: "games.waterdeep.d1534",
		cost: 8,
		action: "f3r3x1",
		owner: "f1r1",
		scope: "skullport"
	},
	{
		id: 1535,
		nameKey: "games.waterdeep.n1535",
		textKey: "games.waterdeep.d1535",
		cost: 4,
		action: "return-x1;g1",
		owner: "g2",
		scope: "skullport"
	},
	{
		id: 1536,
		nameKey: "games.waterdeep.n1536",
		textKey: "games.waterdeep.d1536",
		cost: 5,
		action: "g5;play1",
		owner: "g2",
		scope: "undermountain"
	},
	{
		id: 1537,
		nameKey: "games.waterdeep.n1537",
		textKey: "games.waterdeep.d1537",
		cost: 7,
		action: "f4;place-f1-2-spaces",
		owner: "f2",
		scope: "undermountain"
	},
	{
		id: 1538,
		nameKey: "games.waterdeep.n1538",
		textKey: "games.waterdeep.d1538",
		cost: 5,
		action: "play3",
		owner: "i1",
		scope: "undermountain"
	},
	{
		id: 1539,
		nameKey: "games.waterdeep.n1539",
		textKey: "games.waterdeep.d1539",
		cost: 4,
		action: "f1r1;play1",
		owner: "f1/r1",
		scope: "undermountain"
	},
	{
		id: 1540,
		nameKey: "games.waterdeep.n1540",
		textKey: "games.waterdeep.d1540",
		cost: 6,
		action: "place-own-a3-3-spaces;v10",
		owner: "v2",
		scope: "undermountain"
	},
	{
		id: 1541,
		nameKey: "games.waterdeep.n1541",
		textKey: "games.waterdeep.d1541",
		cost: 7,
		action: "g8;place-g2-2-spaces",
		owner: "g4",
		scope: "undermountain"
	},
	{
		id: 1542,
		nameKey: "games.waterdeep.n1542",
		textKey: "games.waterdeep.d1542",
		cost: 7,
		action: "c2;place-c1-1-space",
		owner: "c1",
		scope: "undermountain"
	},
	{
		id: 1543,
		nameKey: "games.waterdeep.n1543",
		textKey: "games.waterdeep.d1543",
		cost: 7,
		action: "r4;place-r1-2-spaces",
		owner: "r2",
		scope: "undermountain"
	},
	{
		id: 1544,
		nameKey: "games.waterdeep.n1544",
		textKey: "games.waterdeep.d1544",
		cost: 3,
		action: "a1;play1",
		owner: "v2",
		scope: "undermountain"
	},
	{
		id: 1545,
		nameKey: "games.waterdeep.n1545",
		textKey: "games.waterdeep.d1545",
		cost: 7,
		action: "w2;place-w1-1-space",
		owner: "w1",
		scope: "undermountain"
	},
	{
		id: 1546,
		nameKey: "games.waterdeep.n1546",
		textKey: "games.waterdeep.d1546",
		cost: 6,
		action: "discard-nonmandatory-quest;f1r1a1",
		owner: "a1",
		scope: "undermountain"
	},
	{
		id: 1547,
		nameKey: "games.waterdeep.n1547",
		textKey: "games.waterdeep.d1547",
		cost: 3,
		action: "i2g4;discard-i2",
		owner: "i1",
		scope: "undermountain"
	}
], re = [
	{
		id: 1801,
		nameKey: "games.waterdeep.n1801",
		textKey: "games.waterdeep.d1801",
		scope: "skullport",
		attack: !0
	},
	{
		id: 1802,
		nameKey: "games.waterdeep.n1802",
		textKey: "games.waterdeep.d1802",
		scope: "skullport",
		attack: !0
	},
	{
		id: 1803,
		nameKey: "games.waterdeep.n1803",
		textKey: "games.waterdeep.d1803",
		scope: "skullport",
		attack: !0
	},
	{
		id: 1804,
		nameKey: "games.waterdeep.n1804",
		textKey: "games.waterdeep.d1804",
		scope: "skullport",
		attack: !0
	},
	{
		id: 1805,
		nameKey: "games.waterdeep.n1805",
		textKey: "games.waterdeep.d1805",
		scope: "skullport",
		attack: !0
	},
	{
		id: 1806,
		nameKey: "games.waterdeep.n1806",
		textKey: "games.waterdeep.d1806",
		scope: "skullport",
		attack: !0
	},
	{
		id: 1807,
		nameKey: "games.waterdeep.n1807",
		textKey: "games.waterdeep.d1807",
		scope: "skullport",
		attack: !1
	},
	{
		id: 1808,
		nameKey: "games.waterdeep.n1808",
		textKey: "games.waterdeep.d1808",
		scope: "skullport",
		attack: !1
	},
	{
		id: 1809,
		nameKey: "games.waterdeep.n1809",
		textKey: "games.waterdeep.d1809",
		scope: "skullport",
		attack: !1
	},
	{
		id: 1810,
		nameKey: "games.waterdeep.n1810",
		textKey: "games.waterdeep.d1810",
		scope: "skullport",
		attack: !1
	},
	{
		id: 1811,
		nameKey: "games.waterdeep.n1811",
		textKey: "games.waterdeep.d1811",
		scope: "skullport",
		attack: !1
	},
	{
		id: 1812,
		nameKey: "games.waterdeep.n1812",
		textKey: "games.waterdeep.d1812",
		scope: "skullport",
		attack: !1
	},
	{
		id: 1813,
		nameKey: "games.waterdeep.n1813",
		textKey: "games.waterdeep.d1813",
		scope: "skullport",
		attack: !1
	},
	{
		id: 1814,
		nameKey: "games.waterdeep.n1814",
		textKey: "games.waterdeep.d1814",
		scope: "skullport",
		attack: !1
	},
	{
		id: 1815,
		nameKey: "games.waterdeep.n1815",
		textKey: "games.waterdeep.d1815",
		scope: "skullport",
		attack: !1
	},
	{
		id: 1816,
		nameKey: "games.waterdeep.n1816",
		textKey: "games.waterdeep.d1816",
		scope: "skullport",
		attack: !1
	},
	{
		id: 1817,
		nameKey: "games.waterdeep.n1817",
		textKey: "games.waterdeep.d1817",
		scope: "skullport",
		attack: !1
	},
	{
		id: 1818,
		nameKey: "games.waterdeep.n1818",
		textKey: "games.waterdeep.d1818",
		scope: "skullport",
		attack: !1
	},
	{
		id: 1819,
		nameKey: "games.waterdeep.n1819",
		textKey: "games.waterdeep.d1819",
		scope: "skullport",
		attack: !1
	},
	{
		id: 1820,
		nameKey: "games.waterdeep.n1820",
		textKey: "games.waterdeep.d1820",
		scope: "skullport",
		attack: !1
	},
	{
		id: 1821,
		nameKey: "games.waterdeep.n1821",
		textKey: "games.waterdeep.d1821",
		scope: "skullport",
		attack: !1
	},
	{
		id: 1822,
		nameKey: "games.waterdeep.n1822",
		textKey: "games.waterdeep.d1822",
		scope: "skullport",
		attack: !1
	},
	{
		id: 1823,
		nameKey: "games.waterdeep.n1823",
		textKey: "games.waterdeep.d1823",
		scope: "undermountain",
		attack: !1
	},
	{
		id: 1824,
		nameKey: "games.waterdeep.n1824",
		textKey: "games.waterdeep.d1824",
		scope: "undermountain",
		attack: !1
	},
	{
		id: 1825,
		nameKey: "games.waterdeep.n1825",
		textKey: "games.waterdeep.d1825",
		scope: "undermountain",
		attack: !0
	},
	{
		id: 1826,
		nameKey: "games.waterdeep.n1826",
		textKey: "games.waterdeep.d1826",
		scope: "undermountain",
		attack: !0
	},
	{
		id: 1827,
		nameKey: "games.waterdeep.n1827",
		textKey: "games.waterdeep.d1827",
		scope: "undermountain",
		attack: !0
	},
	{
		id: 1828,
		nameKey: "games.waterdeep.n1828",
		textKey: "games.waterdeep.d1828",
		scope: "undermountain",
		attack: !0
	},
	{
		id: 1829,
		nameKey: "games.waterdeep.n1829",
		textKey: "games.waterdeep.d1829",
		scope: "undermountain",
		attack: !0
	},
	{
		id: 1830,
		nameKey: "games.waterdeep.n1830",
		textKey: "games.waterdeep.d1830",
		scope: "undermountain",
		attack: !1
	},
	{
		id: 1831,
		nameKey: "games.waterdeep.n1831",
		textKey: "games.waterdeep.d1831",
		scope: "undermountain",
		attack: !1
	},
	{
		id: 1832,
		nameKey: "games.waterdeep.n1832",
		textKey: "games.waterdeep.d1832",
		scope: "undermountain",
		attack: !1
	},
	{
		id: 1833,
		nameKey: "games.waterdeep.n1833",
		textKey: "games.waterdeep.d1833",
		scope: "undermountain",
		attack: !1
	},
	{
		id: 1834,
		nameKey: "games.waterdeep.n1834",
		textKey: "games.waterdeep.d1834",
		scope: "undermountain",
		attack: !1
	},
	{
		id: 1835,
		nameKey: "games.waterdeep.n1835",
		textKey: "games.waterdeep.d1835",
		scope: "undermountain",
		attack: !1
	},
	{
		id: 1836,
		nameKey: "games.waterdeep.n1836",
		textKey: "games.waterdeep.d1836",
		scope: "undermountain",
		attack: !1
	},
	{
		id: 1837,
		nameKey: "games.waterdeep.n1837",
		textKey: "games.waterdeep.d1837",
		scope: "undermountain",
		attack: !1
	},
	{
		id: 1838,
		nameKey: "games.waterdeep.n1838",
		textKey: "games.waterdeep.d1838",
		scope: "undermountain",
		attack: !1
	},
	{
		id: 1839,
		nameKey: "games.waterdeep.n1839",
		textKey: "games.waterdeep.d1839",
		scope: "undermountain",
		attack: !1
	},
	{
		id: 1840,
		nameKey: "games.waterdeep.n1840",
		textKey: "games.waterdeep.d1840",
		scope: "undermountain",
		attack: !1
	},
	{
		id: 1841,
		nameKey: "games.waterdeep.n1841",
		textKey: "games.waterdeep.d1841",
		scope: "undermountain",
		attack: !1
	},
	{
		id: 1842,
		nameKey: "games.waterdeep.n1842",
		textKey: "games.waterdeep.d1842",
		scope: "undermountain",
		attack: !1
	},
	{
		id: 1843,
		nameKey: "games.waterdeep.n1843",
		textKey: "games.waterdeep.d1843",
		scope: "undermountain",
		attack: !1
	},
	{
		id: 1844,
		nameKey: "games.waterdeep.n1844",
		textKey: "games.waterdeep.d1844",
		scope: "undermountain",
		attack: !1
	},
	{
		id: 1912,
		nameKey: "games.waterdeep.n1912",
		textKey: "games.waterdeep.d1912",
		scope: "base",
		attack: !1
	},
	{
		id: 1900,
		nameKey: "games.waterdeep.n1900",
		textKey: "games.waterdeep.d1900",
		scope: "base",
		attack: !0
	},
	{
		id: 1901,
		nameKey: "games.waterdeep.n1901",
		textKey: "games.waterdeep.d1901",
		scope: "base",
		attack: !0
	},
	{
		id: 1902,
		nameKey: "games.waterdeep.n1902",
		textKey: "games.waterdeep.d1902",
		scope: "base",
		attack: !0
	},
	{
		id: 1903,
		nameKey: "games.waterdeep.n1903",
		textKey: "games.waterdeep.d1903",
		scope: "base",
		attack: !0
	},
	{
		id: 1904,
		nameKey: "games.waterdeep.n1904",
		textKey: "games.waterdeep.d1904",
		scope: "base",
		attack: !0
	},
	{
		id: 1905,
		nameKey: "games.waterdeep.n1905",
		textKey: "games.waterdeep.d1905",
		scope: "base",
		attack: !0
	},
	{
		id: 1913,
		nameKey: "games.waterdeep.n1913",
		textKey: "games.waterdeep.d1913",
		scope: "base",
		attack: !1
	},
	{
		id: 1914,
		nameKey: "games.waterdeep.n1914",
		textKey: "games.waterdeep.d1914",
		scope: "base",
		attack: !1
	},
	{
		id: 1915,
		nameKey: "games.waterdeep.n1915",
		textKey: "games.waterdeep.d1915",
		scope: "base",
		attack: !1
	},
	{
		id: 1906,
		nameKey: "games.waterdeep.n1906",
		textKey: "games.waterdeep.d1906",
		scope: "base",
		attack: !0
	},
	{
		id: 1907,
		nameKey: "games.waterdeep.n1907",
		textKey: "games.waterdeep.d1907",
		scope: "base",
		attack: !0
	},
	{
		id: 1916,
		nameKey: "games.waterdeep.n1916",
		textKey: "games.waterdeep.d1916",
		scope: "base",
		attack: !1
	},
	{
		id: 1917,
		nameKey: "games.waterdeep.n1917",
		textKey: "games.waterdeep.d1917",
		scope: "base",
		attack: !1
	},
	{
		id: 1918,
		nameKey: "games.waterdeep.n1918",
		textKey: "games.waterdeep.d1918",
		scope: "base",
		attack: !1
	},
	{
		id: 1919,
		nameKey: "games.waterdeep.n1919",
		textKey: "games.waterdeep.d1919",
		scope: "base",
		attack: !1
	},
	{
		id: 1920,
		nameKey: "games.waterdeep.n1920",
		textKey: "games.waterdeep.d1920",
		scope: "base",
		attack: !1
	},
	{
		id: 1921,
		nameKey: "games.waterdeep.n1921",
		textKey: "games.waterdeep.d1921",
		scope: "base",
		attack: !1
	},
	{
		id: 1922,
		nameKey: "games.waterdeep.n1922",
		textKey: "games.waterdeep.d1922",
		scope: "base",
		attack: !1
	},
	{
		id: 1923,
		nameKey: "games.waterdeep.n1923",
		textKey: "games.waterdeep.d1923",
		scope: "base",
		attack: !1
	},
	{
		id: 1924,
		nameKey: "games.waterdeep.n1924",
		textKey: "games.waterdeep.d1924",
		scope: "base",
		attack: !1
	},
	{
		id: 1908,
		nameKey: "games.waterdeep.n1908",
		textKey: "games.waterdeep.d1908",
		scope: "base",
		attack: !0
	},
	{
		id: 1909,
		nameKey: "games.waterdeep.n1909",
		textKey: "games.waterdeep.d1909",
		scope: "base",
		attack: !0
	},
	{
		id: 1925,
		nameKey: "games.waterdeep.n1925",
		textKey: "games.waterdeep.d1925",
		scope: "base",
		attack: !1
	},
	{
		id: 1926,
		nameKey: "games.waterdeep.n1926",
		textKey: "games.waterdeep.d1926",
		scope: "base",
		attack: !1
	},
	{
		id: 1927,
		nameKey: "games.waterdeep.n1927",
		textKey: "games.waterdeep.d1927",
		scope: "base",
		attack: !1
	},
	{
		id: 1928,
		nameKey: "games.waterdeep.n1928",
		textKey: "games.waterdeep.d1928",
		scope: "base",
		attack: !1
	},
	{
		id: 1910,
		nameKey: "games.waterdeep.n1910",
		textKey: "games.waterdeep.d1910",
		scope: "base",
		attack: !0
	},
	{
		id: 1911,
		nameKey: "games.waterdeep.n1911",
		textKey: "games.waterdeep.d1911",
		scope: "base",
		attack: !0
	},
	{
		id: 1929,
		nameKey: "games.waterdeep.n1929",
		textKey: "games.waterdeep.d1929",
		scope: "base",
		attack: !1
	},
	{
		id: 1930,
		nameKey: "games.waterdeep.n1930",
		textKey: "games.waterdeep.d1930",
		scope: "base",
		attack: !1
	},
	{
		id: 1931,
		nameKey: "games.waterdeep.n1931",
		textKey: "games.waterdeep.d1931",
		scope: "base",
		attack: !1
	},
	{
		id: 1932,
		nameKey: "games.waterdeep.n1932",
		textKey: "games.waterdeep.d1932",
		scope: "base",
		attack: !1
	},
	{
		id: 1933,
		nameKey: "games.waterdeep.n1933",
		textKey: "games.waterdeep.d1933",
		scope: "base",
		attack: !1
	},
	{
		id: 1934,
		nameKey: "games.waterdeep.n1934",
		textKey: "games.waterdeep.d1934",
		scope: "base",
		attack: !1
	},
	{
		id: 1935,
		nameKey: "games.waterdeep.n1935",
		textKey: "games.waterdeep.d1935",
		scope: "base",
		attack: !1
	},
	{
		id: 1936,
		nameKey: "games.waterdeep.n1936",
		textKey: "games.waterdeep.d1936",
		scope: "base",
		attack: !1
	},
	{
		id: 1937,
		nameKey: "games.waterdeep.n1937",
		textKey: "games.waterdeep.d1937",
		scope: "base",
		attack: !1
	},
	{
		id: 1938,
		nameKey: "games.waterdeep.n1938",
		textKey: "games.waterdeep.d1938",
		scope: "base",
		attack: !1
	},
	{
		id: 1939,
		nameKey: "games.waterdeep.n1939",
		textKey: "games.waterdeep.d1939",
		scope: "base",
		attack: !1
	},
	{
		id: 1940,
		nameKey: "games.waterdeep.n1940",
		textKey: "games.waterdeep.d1940",
		scope: "base",
		attack: !1
	},
	{
		id: 1941,
		nameKey: "games.waterdeep.n1941",
		textKey: "games.waterdeep.d1941",
		scope: "base",
		attack: !1
	},
	{
		id: 1942,
		nameKey: "games.waterdeep.n1942",
		textKey: "games.waterdeep.d1942",
		scope: "base",
		attack: !1
	},
	{
		id: 1943,
		nameKey: "games.waterdeep.n1943",
		textKey: "games.waterdeep.d1943",
		scope: "base",
		attack: !1
	},
	{
		id: 2e3,
		nameKey: "games.waterdeep.n2000",
		textKey: "games.waterdeep.d2000",
		scope: "undermountain",
		attack: !0
	},
	{
		id: 2001,
		nameKey: "games.waterdeep.n2001",
		textKey: "games.waterdeep.d2001",
		scope: "skullport",
		attack: !0
	},
	{
		id: 2002,
		nameKey: "games.waterdeep.n2002",
		textKey: "games.waterdeep.d2002",
		scope: "skullport",
		attack: !0
	},
	{
		id: 2003,
		nameKey: "games.waterdeep.n2003",
		textKey: "games.waterdeep.d2003",
		scope: "skullport",
		attack: !0
	},
	{
		id: 2004,
		nameKey: "games.waterdeep.n2004",
		textKey: "games.waterdeep.d2004",
		scope: "base",
		attack: !0
	},
	{
		id: 2005,
		nameKey: "games.waterdeep.n2005",
		textKey: "games.waterdeep.d2005",
		scope: "base",
		attack: !0
	},
	{
		id: 2006,
		nameKey: "games.waterdeep.n2006",
		textKey: "games.waterdeep.d2006",
		scope: "base",
		attack: !0
	},
	{
		id: 2007,
		nameKey: "games.waterdeep.n2007",
		textKey: "games.waterdeep.d2007",
		scope: "base",
		attack: !0
	},
	{
		id: 2008,
		nameKey: "games.waterdeep.n2008",
		textKey: "games.waterdeep.d2008",
		scope: "base",
		attack: !0
	},
	{
		id: 2009,
		nameKey: "games.waterdeep.n2009",
		textKey: "games.waterdeep.d2009",
		scope: "base",
		attack: !0
	},
	{
		id: 2010,
		nameKey: "games.waterdeep.n2010",
		textKey: "games.waterdeep.d2010",
		scope: "undermountain",
		attack: !0
	},
	{
		id: 2011,
		nameKey: "games.waterdeep.n2011",
		textKey: "games.waterdeep.d2011",
		scope: "undermountain",
		attack: !0
	}
], ie = [
	{
		id: 1300,
		nameKey: "games.waterdeep.n1300",
		types: ["arcana", "skullduggery"],
		scope: "base"
	},
	{
		id: 1301,
		nameKey: "games.waterdeep.n1301",
		types: ["skullduggery", "warfare"],
		scope: "base"
	},
	{
		id: 1302,
		nameKey: "games.waterdeep.n1302",
		types: ["commerce", "warfare"],
		scope: "base"
	},
	{
		id: 1303,
		nameKey: "games.waterdeep.n1303",
		types: ["arcana", "warfare"],
		scope: "base"
	},
	{
		id: 1304,
		nameKey: "games.waterdeep.n1304",
		types: ["arcana", "piety"],
		scope: "base"
	},
	{
		id: 1305,
		nameKey: "games.waterdeep.n1305",
		types: [],
		scope: "base"
	},
	{
		id: 1306,
		nameKey: "games.waterdeep.n1306",
		types: ["commerce", "piety"],
		scope: "base"
	},
	{
		id: 1307,
		nameKey: "games.waterdeep.n1307",
		types: ["piety", "skullduggery"],
		scope: "base"
	},
	{
		id: 1308,
		nameKey: "games.waterdeep.n1308",
		types: ["commerce", "skullduggery"],
		scope: "base"
	},
	{
		id: 1309,
		nameKey: "games.waterdeep.n1309",
		types: ["piety", "warfare"],
		scope: "base"
	},
	{
		id: 1310,
		nameKey: "games.waterdeep.n1310",
		types: ["arcana", "commerce"],
		scope: "base"
	},
	{
		id: 1311,
		nameKey: "games.waterdeep.n1311",
		types: [],
		scope: "undermountain"
	},
	{
		id: 1312,
		nameKey: "games.waterdeep.n1312",
		types: [],
		scope: "undermountain"
	},
	{
		id: 1313,
		nameKey: "games.waterdeep.n1313",
		types: [],
		scope: "undermountain"
	},
	{
		id: 1314,
		nameKey: "games.waterdeep.n1314",
		types: [],
		scope: "skullport"
	},
	{
		id: 1315,
		nameKey: "games.waterdeep.n1315",
		types: [],
		scope: "skullport"
	},
	{
		id: 1316,
		nameKey: "games.waterdeep.n1316",
		types: [],
		scope: "skullport"
	}
], D = (e) => T.find((t) => t.id === e), O = (e) => E.find((t) => t.id === e), k = (e) => re.find((t) => t.id === e), A = (e) => ie.find((t) => t.id === e), j = () => ({
	c: 0,
	f: 0,
	r: 0,
	w: 0,
	g: 0,
	v: 0,
	x: 0
}), M = (e, t) => e.players.find((e) => e.rid === t), N = (e, t, n) => M(e, t).completed.includes(n), ae = (e, t, n) => n.agent === "ambassador" && !e.ambassadorActor || n.rid !== t, oe = (e, t, n) => ae(e, t, n) && (n.agent === "ambassador" && !e.ambassadorActor || !M(e, n.rid).revealed), P = (e, t, n = {}) => ({
	...n,
	op: e,
	rid: t
}), F = (e, ...t) => {
	e.agenda.unshift(...t);
};
function I(e, t, n, r) {
	r.length && (e.serial += 1, e.decision = {
		rid: t,
		kind: n,
		offers: r.map((t, n) => ({
			...t,
			option: {
				...t.option,
				id: `${e.serial}:${n}`
			}
		}))
	}, e.phase = "play");
}
var L = (e, ...t) => ({
	option: {
		id: "",
		...e
	},
	jobs: t
}), R = () => L({ kind: "skip" });
function z(e, t, n, r = {}) {
	e.probing || (e.last = {
		kind: t,
		rid: n,
		...r
	}, e.log.push(e.last));
}
//#endregion
//#region src/games/waterdeep/resources.ts
var B = [
	"c",
	"f",
	"r",
	"w"
], se = [
	"c",
	"f",
	"r",
	"w",
	"g",
	"v",
	"x"
];
function V(e) {
	let t = {};
	for (let n of e.matchAll(/([cfrwgvxai])(-?\d+)/g)) t[n[1]] = (t[n[1]] ?? 0) + Number(n[2]);
	return t;
}
function ce(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.rngCursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function H(e, t) {
	return !e.decks[t].length && e.discard[t].length && (e.decks[t] = ce(e, e.discard[t]), e.discard[t] = []), e.decks[t].shift();
}
function U(e, t) {
	let n = V(t);
	return se.every((t) => e[t] >= (n[t] ?? 0)) && B.reduce((t, r) => t + e[r] - (n[r] ?? 0), 0) >= (n.a ?? 0);
}
function W(e, t, n) {
	let r = M(e, t), i = V(n);
	for (let t of se) {
		let n = i[t] ?? 0;
		r.resources[t] -= n, B.includes(t) && (e.supply[t] += n);
	}
}
function le(e) {
	let t = 0;
	return e.corruption.forEach((e, n) => {
		e || (t = n + 1);
	}), t;
}
function ue(e, t, n) {
	n && N(e, t, 1722) && !M(e, t).used.includes("shelter") && e.active === t && (M(e, t).used.push("shelter"), F(e, P("gain", t, { value: "i1" })));
}
function de(e, t, n, r = !1) {
	let i = 0;
	for (let a = 0; a < n; a += 1) {
		let n = e.corruption.findIndex((e) => e > 0);
		if (n < 0) {
			r || (M(e, t).resources.v -= 10);
			continue;
		}
		--e.corruption[n], i += 1, r ? e.removedCorruption += 1 : M(e, t).resources.x += 1;
	}
	return r || ue(e, t, i), i;
}
function fe(e, t, n, r = !1) {
	let i = M(e, t), a = Math.min(n, i.resources.x);
	if (i.resources.x -= a, r) e.removedCorruption += a;
	else {
		for (let t = 0; t < a; t += 1) for (let t = 8; t >= 0; --t) if (e.corruption[t] < 3) {
			e.corruption[t] += 1;
			break;
		}
		a && e.active === t && N(e, t, 1716) && !i.used.includes("converts") && i.resources.x && (i.used.push("converts"), F(e, P("returnMenu", t, { n: 1 })));
	}
}
function G(e, t, n, r = !1) {
	let i = V(n), a = M(e, t);
	for (let n of se) {
		let o = i[n] ?? 0;
		if (!o) continue;
		if (n === "x") {
			let n = de(e, t, o);
			r && e.actionRid === t && (e.actionGain.x = (e.actionGain.x ?? 0) + n);
			continue;
		}
		let s = B.includes(n) ? Math.min(o, e.supply[n]) : o;
		a.resources[n] += s, B.includes(n) && (e.supply[n] -= s), r && e.actionRid === t && s > 0 && (e.actionGain[n] = (e.actionGain[n] ?? 0) + s);
	}
	for (let t = 0; t < (i.i ?? 0); t += 1) {
		let t = H(e, "intrigues");
		t !== void 0 && a.hand.push(t);
	}
	i.a && F(e, P("any", t, {
		n: i.a,
		flag: r
	}));
}
function pe(e) {
	for (; e.marketQuests.length < 4;) {
		let t = H(e, "quests");
		if (t === void 0) break;
		e.marketQuests.push(t);
	}
	for (; e.marketBuildings.length < 3;) {
		let t = H(e, "buildings");
		if (t === void 0) break;
		e.marketBuildings.push({
			id: t,
			vp: 0
		});
	}
}
//#endregion
//#region src/games/waterdeep/intrigue-rules.ts
function K(e, t, n = !1) {
	let r = e.players.findIndex((e) => e.rid === t);
	return Array.from({ length: e.players.length - 1 }, (t, n) => e.players[(r + n + 1) % e.players.length]).filter((e) => !n || !e.revealed).map((e) => e.rid);
}
function me(e, t, n) {
	let r = M(e, t), i = K(e, t, k(n).attack), a = {
		...e,
		players: e.players.map((e) => e.rid === t ? {
			...e,
			hand: e.hand.filter((e) => e !== n)
		} : e)
	};
	if (n >= 2e3) return i.some((t) => n !== 2002 || M(e, t).resources.x > 0);
	if ([1906, 1907].includes(n)) {
		let n = {
			...a,
			players: a.players.map((e) => e.rid === t ? {
				...e,
				resources: {
					...e.resources,
					g: e.resources.g - 2
				}
			} : e)
		};
		return r.resources.g >= 2 && J(n, t, "copy").some((n) => e.spaces.find((e) => e.id === n.option.space).occupants.some((n) => oe(e, t, n)));
	}
	if (n === 1802) return e.spaces.some((n) => n.id !== "b1523" && n.occupants.some((n) => oe(e, t, n) && (n.agent !== "ambassador" || !!e.ambassadorActor) && M(e, n.rid).resources.x > r.resources.x) && Ee(a, t, n.id, !1));
	if ([
		1908,
		1909,
		1828
	].includes(n)) return i.some((t) => B.some((n) => M(e, t).resources[n]) && (n !== 1828 || M(e, t).resources.g >= 2));
	if (n === 1801) return i.length > 0;
	if (n === 1805) return r.quests.some((e) => D(e).type === "mandatory") && i.some((t) => M(e, t).resources.x > 0);
	if (n === 1806) return e.buildings.filter((e) => e.owner === t).length < 9 && e.buildings.some((n) => n.owner !== t && !M(e, n.owner).revealed);
	if ([1808].includes(n)) return r.resources.g >= 2;
	if ([1821, 1822].includes(n)) return B.some((e) => r.resources[e]);
	let o = {
		1824: "w1",
		1831: "c1",
		1833: "g4",
		1834: "r2",
		1837: "f2"
	};
	return o[n] ? U(r.resources, o[n]) : [1825, 1826].includes(n) ? i.some((t) => [
		"f2",
		"r2",
		"f1r1"
	].some((n) => U(M(e, t).resources, n))) : [1920].includes(n) ? r.quests.length > 0 : [1929].includes(n) ? e.buildings.some((n) => n.owner === t && !e.spaces.find((e) => e.id === `b${n.id}`).occupants.length) : [1930, 1931].includes(n) ? e.spaces.some((e) => e.occupants.some((e) => e.rid === t && e.agent !== "ambassador")) : n === 1912 ? e.spaces.some((e) => e.id.startsWith("harbor-") && e.occupants.some((e) => e.rid === t && e.agent !== "ambassador")) : [1935, 1936].includes(n) ? r.agents > 0 && e.marketBuildings.some((e) => Ee(a, t, `m${e.id}`)) : n === 1827 ? e.marketBuildings.length > 0 && e.buildings.some((n) => !e.spaces.find((e) => e.id === `b${n.id}`).occupants.length && (n.owner === t || !M(e, n.owner).revealed && r.resources.g >= he(n.id))) : n !== 1829 || r.agents > 0 && e.spaces.some((n) => n.occupants.some((n) => oe(e, t, n))) && e.spaces.some((e) => !e.occupants.length);
}
var he = (e) => O(e).cost;
function ge(e, t, n, r = () => !0, i = !1) {
	I(e, t.rid, "opponent", K(e, t.rid, i).filter(r).map((e) => L({
		kind: "opponent",
		rid: e
	}, ...n(e))));
}
var q = (e, t, n = !0) => P("gain", e, {
	value: t,
	flag: n
});
function _e(e, t, n) {
	let r = M(e, t);
	if (r.hand.some((e) => [
		1802,
		1823,
		1829,
		1835,
		1836,
		1844,
		1902,
		1903,
		1906,
		1907,
		1935,
		1936
	].includes(e))) return !1;
	let i = r.quests.some((e) => D(e).type === "mandatory");
	if (N(e, t, 1722) && e.active === t && !r.used.includes("shelter") && r.hand.some((e) => [
		1805,
		1806,
		1807,
		1811,
		1812,
		1814,
		1815
	].includes(e))) return !1;
	let a = e.spaces.some((e) => e.occupants.some((e) => e.rid === t && e.agent !== "ambassador")), o = e.spaces.some((e) => e.id.startsWith("harbor-") && e.occupants.some((e) => e.rid === t && e.agent !== "ambassador"));
	return o && r.hand.includes(1912) ? !1 : r.hand.filter((e) => e === 1805 ? i : e === 1912 ? o : e === 1930 || e === 1931 ? a : !0).length < n;
}
function ve(e, t) {
	let n = M(e, t.rid);
	switch (t.op) {
		case "playMenu": {
			if (e.probing && !t.flag && _e(e, t.rid, t.n ?? 1)) return e.probeFailed = !0, !0;
			e.actionRid === t.rid && t.ref !== "librarium" && (e.actionIntrigue = !0);
			let r = n.hand.filter((e) => t.id === void 0 || e === t.id).filter((n) => me(e, t.rid, n)).map((e) => L({
				kind: "play",
				card: e
			}, P("playCard", t.rid, { id: e }), ...t.n > 1 ? [P("playMenu", t.rid, {
				n: t.n - 1,
				flag: t.flag
			})] : []));
			if (!e.probing && (t.n ?? 1) > 1) for (let t = r.length - 1; t >= 0; t--) We(e, r[t].jobs) || r.splice(t, 1);
			return t.flag && r.push(R()), !r.length && !t.flag && e.probing && (e.probeFailed = !0), I(e, t.rid, "play", r), !0;
		}
		case "playCard": {
			let r = t.id, i = n.hand.indexOf(r);
			if (n.hand.splice(i, 1), e.discard.intrigues.push(r), z(e, "play", t.rid, { card: r }), N(e, t.rid, 1642) && F(e, q(t.rid, "v2", !1)), r >= 2e3) return ge(e, t, (e) => [P("mandatory", t.rid, {
				target: e,
				id: r
			})], (t) => r !== 2002 || M(e, t).resources.x > 0, !0), !0;
			let a = [];
			if (r >= 1900 && r <= 1911) {
				if ([1906, 1907].includes(r)) a.push(P("pay", t.rid, { value: "g2" }), P("attackCopy", t.rid));
				else if ([1908, 1909].includes(r)) a.push(P("stealMenu", t.rid, { value: "a1" }));
				else {
					let n = r <= 1901 ? "f" : r <= 1903 ? "w" : r <= 1905 ? "r" : "c", i = n === "f" ? "f1" : n === "w" ? "i1" : n === "r" ? "g2" : "v2";
					for (let r of K(e, t.rid, !0)) a.push(P("attackReturn", t.rid, {
						target: r,
						value: n,
						ref: i
					}));
				}
			} else switch (r) {
				case 1912:
					a.push(P("recallMenu", t.rid, {
						n: 1,
						value: "harbor"
					}), P("extraAssign", t.rid, { n: 2 }));
					break;
				case 1913:
				case 1914:
				case 1915: {
					let n = [];
					for (let t = 0; t < e.players.length; t++) {
						let t = H(e, "quests");
						t !== void 0 && n.push(t);
					}
					a.push(P("draftQuest", t.rid, {
						ids: n,
						n: 0
					}));
					break;
				}
				case 1916:
				case 1917:
					a.push(q(t.rid, "a2"), ...K(e, t.rid).map((e) => q(e, "a1", !1)));
					break;
				case 1918:
				case 1919:
					a.push(P("resourceChoice", t.rid, {
						value: "g4/f2/r2/w1/c1",
						flag: !0
					}));
					break;
				case 1920:
					a.push(P("discardQuestMenu", t.rid, { n: 6 }), ...K(e, t.rid).map((e) => P("discardQuestMenu", e, {
						n: 3,
						flag: !0
					})));
					break;
				case 1921:
				case 1922:
					a.push(q(t.rid, "f2"), P("opponentGift", t.rid, { value: "f1" }));
					break;
				case 1923:
				case 1924:
					a.push(q(t.rid, "r2"), P("opponentGift", t.rid, { value: "r1" }));
					break;
				case 1925:
				case 1926:
					a.push(q(t.rid, "c2"), P("opponentGift", t.rid, { value: "c1" }));
					break;
				case 1927:
				case 1928:
					a.push(q(t.rid, "w2"), P("opponentGift", t.rid, { value: "w1" }));
					break;
				case 1929:
					a.push(P("demolishMenu", t.rid, { value: "own" }), P("buildMenu", t.rid));
					break;
				case 1930:
				case 1931:
					a.push(P("recallMenu", t.rid, { n: 1 }));
					break;
				case 1932:
				case 1933:
				case 1934:
				case 1941:
				case 1942:
				case 1943: {
					let n = r === 1932 ? "r1" : r === 1933 ? "f1" : r === 1934 ? "w1" : r === 1941 ? "c1" : "g4", i = r === 1932 || r === 1933 ? 3 : r === 1934 || r === 1941 ? 5 : 4;
					a.push(q(t.rid, r === 1932 ? "r2" : r === 1933 ? "f2" : r === 1934 ? "w1" : r === 1941 ? "c1" : "g4")), a.push(...K(e, t.rid).map((e) => P("tributeMenu", e, {
						target: t.rid,
						value: n,
						n: i
					})));
					break;
				}
				case 1935:
				case 1936:
					a.push(P("sampleMenu", t.rid));
					break;
				case 1937:
				case 1938:
					a.push(P("specialQuestMenu", t.rid));
					break;
				case 1939:
				case 1940:
					a.push(q(t.rid, "g4"), P("opponentGift", t.rid, { value: "g2" }));
					break;
				case 1801: return ge(e, t, (e) => [P("blackmail", t.rid, { target: e })], () => !0, !0), !0;
				case 1802:
					a.push(P("attackCopy", t.rid, { flag: !0 }));
					break;
				case 1803:
				case 1804:
					a.push(...K(e, t.rid, !0).map((e) => P("expose", t.rid, { target: e })));
					break;
				case 1805:
					a.push(q(t.rid, "x1"), P("foistMenu", t.rid));
					break;
				case 1806:
					a.push(q(t.rid, "x2"), P("stealBuildingMenu", t.rid));
					break;
				case 1807:
				case 1811:
				case 1812:
				case 1814:
				case 1815: {
					let [n, i] = r === 1807 ? ["g8x1", "g4x1"] : r === 1811 ? ["r4x1", "r2x1"] : r === 1812 ? ["c2x1", "c1x1"] : r === 1814 ? ["f4x1", "f2x1"] : ["w2x1", "w1x1"];
					a.push(q(t.rid, n), ...K(e, t.rid).map((e) => P("optional", e, {
						value: "gain",
						ref: i
					})));
					break;
				}
				case 1808:
					a.push(P("pay", t.rid, { value: "g2" }), P("returnMenu", t.rid, { n: 2 }), ...K(e, t.rid).map((e) => P("bribeWatchMenu", e)));
					break;
				case 1809:
				case 1810:
					a.push(P("placeExtraMenu", t.rid, {
						value: "x1",
						n: 2
					}));
					break;
				case 1813:
					K(e, t.rid).every((t) => M(e, t).resources.x > n.resources.x) && a.push(q(t.rid, "v6"));
					break;
				case 1816:
				case 1817:
					a.push(P("removeTrack", t.rid, { n: 3 }));
					break;
				case 1818:
				case 1819:
				case 1820:
					a.push(P("returnMenu", t.rid, { n: 1 }));
					break;
				case 1821:
				case 1822:
					a.push(P("loseAny", t.rid, { n: 1 }), P("returnMenu", t.rid, { n: 2 }), ...K(e, t.rid).map((e) => P("scapegoatMenu", e)));
					break;
				case 1823:
				case 1844:
					a.push(P("drawPlay", t.rid, {
						n: 2,
						flag: !0
					}));
					break;
				case 1824:
				case 1831:
				case 1833:
				case 1834:
				case 1837: {
					let n = r === 1824 ? "w1" : r === 1831 ? "c1" : r === 1833 ? "g4" : r === 1834 ? "r2" : "f2";
					return ge(e, t, (e) => [P("transfer", t.rid, {
						target: e,
						value: n
					}), q(t.rid, "v8")]), !0;
				}
				case 1825:
				case 1826:
					a.push(P("stealMenu", t.rid, { value: "f2/r2/f1r1" }));
					break;
				case 1827:
					a.push(P("demolishMenu", t.rid), P("buildMenu", t.rid));
					break;
				case 1828:
					a.push(P("stealMenu", t.rid, {
						value: "a1g2",
						id: r
					}));
					break;
				case 1829:
					a.push(P("manipulateMenu", t.rid), P("extraAssign", t.rid, { n: 1 }));
					break;
				case 1830:
					a.push(q(t.rid, "g2"), P("first", t.rid));
					break;
				case 1832:
					a.push(q(t.rid, "g2"), P("buildMenu", t.rid, {
						value: "buy",
						flag: !0
					}));
					break;
				case 1835:
				case 1836:
					a.push(q(t.rid, "i3"), ...K(e, t.rid).map((e) => q(e, "i1", !1)));
					break;
				case 1838: {
					n.revealed = !0;
					let t = n.quests.filter((e) => D(e).type === "mandatory");
					n.quests = n.quests.filter((e) => !t.includes(e)), e.discard.intrigues.push(...t);
					break;
				}
				case 1839:
				case 1840:
				case 1841:
				case 1842:
				case 1843: {
					let e = r === 1839 ? "r" : r === 1840 ? "c" : r === 1841 ? "f" : r === 1842 ? "w" : "g", n = [
						"r",
						"f",
						"g"
					].includes(e) ? 2 : 1;
					a.push(q(t.rid, `${e}${e === "g" ? 5 : n}`), P("placeExtraMenu", t.rid, {
						value: `${e}${e === "g" ? 2 : 1}`,
						n
					}));
					break;
				}
			}
			return F(e, ...a), !0;
		}
		case "mandatory": return M(e, t.target).quests.push(t.id), e.discard.intrigues.splice(e.discard.intrigues.lastIndexOf(t.id), 1), !0;
		case "opponentGift": return ge(e, t, (e) => [q(e, t.value, !1)]), !0;
		case "attackReturn": {
			let n = M(e, t.target), r = t.value;
			return U(n.resources, `${r}1`) ? W(e, n.rid, `${r}1`) : G(e, t.rid, t.ref, !0), !0;
		}
		case "attackCopy": {
			let r = J(e, t.rid, "copy", void 0, (r) => r.occupants.some((r) => oe(e, t.rid, r) && (!t.flag || (r.agent !== "ambassador" || !!e.ambassadorActor) && M(e, r.rid).resources.x > n.resources.x)));
			return !r.length && e.probing && (e.probeFailed = !0), I(e, t.rid, "copy", r), !0;
		}
		case "blackmail": {
			let r = M(e, t.target), i = Math.min(2, r.resources.g);
			return r.resources.g -= i, G(e, t.rid, `g${i}`, !0), n.seenLords = n.seenLords.filter((e) => e.rid !== r.rid), n.seenLords.push({
				rid: r.rid,
				lord: r.lord
			}), !0;
		}
		case "expose": return M(e, t.target).resources.x > n.resources.x && G(e, t.target, "x1"), !0;
		case "foistMenu": {
			let r = n.quests.filter((e) => D(e).type === "mandatory").flatMap((n) => K(e, t.rid, !0).filter((t) => M(e, t).resources.x).map((e) => L({
				kind: "foist",
				card: n,
				rid: e
			}, P("foist", t.rid, {
				target: e,
				id: n
			}))));
			return I(e, t.rid, "foist", r), !0;
		}
		case "foist": return n.quests.splice(n.quests.indexOf(t.id), 1), M(e, t.target).quests.push(t.id), !0;
		case "stealBuildingMenu": return I(e, t.rid, "stealBuilding", e.buildings.filter((n) => n.owner !== t.rid && !M(e, n.owner).revealed).map((e) => L({
			kind: "stealBuilding",
			card: e.id,
			rid: e.owner
		}, P("stealBuilding", t.rid, { id: e.id })))), !0;
		case "stealBuilding": return e.buildings.find((e) => e.id === t.id).owner = t.rid, !0;
		case "transfer": {
			let n = M(e, t.target);
			return W(e, t.rid, t.value), G(e, n.rid, t.value), !0;
		}
		case "stealMenu": {
			let n = [];
			for (let r of K(e, t.rid, !0)) {
				let i = M(e, r), a = t.value.startsWith("a") ? B.map((e) => `${e}1${t.value.includes("g2") ? "g2" : ""}`) : t.value.split("/");
				for (let e of a.filter((e) => U(i.resources, e))) n.push(L({
					kind: "steal",
					rid: r,
					gain: e
				}, P("steal", t.rid, {
					target: r,
					value: e,
					id: t.id
				})));
			}
			return I(e, t.rid, "steal", n), !0;
		}
		case "steal":
			if (W(e, t.target, t.value), G(e, t.rid, t.value, !0), t.id) {
				let n = e.discard.intrigues.lastIndexOf(t.id);
				e.discard.intrigues.splice(n, 1), M(e, t.target).hand.push(t.id);
			}
			return !0;
		case "tributeMenu": return U(n.resources, t.value) && I(e, t.rid, "tribute", [L({
			kind: "tribute",
			rid: t.target,
			cost: t.value,
			gain: `v${t.n}`
		}, P("transfer", t.rid, {
			target: t.target,
			value: t.value
		}), q(t.rid, `v${t.n}`, !1)), R()]), !0;
		case "bribeWatchMenu": return n.resources.g >= 4 && n.resources.x && I(e, t.rid, "trade", [L({
			kind: "trade",
			cost: "g4",
			gain: "x-1"
		}, P("pay", t.rid, { value: "g4" }), P("return", t.rid, { n: 1 })), R()]), !0;
		case "scapegoatMenu": return B.reduce((e, t) => e + n.resources[t], 0) >= 2 && n.resources.x && I(e, t.rid, "trade", [L({
			kind: "trade",
			cost: "a2",
			gain: "x-1"
		}, P("loseAny", t.rid, { n: 2 }), P("return", t.rid, { n: 1 })), R()]), !0;
		case "draftQuest": return t.ids?.length && I(e, t.rid, "quest", t.ids.map((r) => L({
			kind: "takeQuest",
			card: r
		}, P("takeQuest", t.rid, { id: r }), P("draftQuest", e.players[(e.players.indexOf(n) + 1) % e.players.length].rid, { ids: t.ids.filter((e) => e !== r) })))), !0;
		case "specialQuestMenu": return I(e, t.rid, "questType", [
			"arcana",
			"commerce",
			"piety",
			"skullduggery",
			"warfare"
		].map((e) => L({
			kind: "questType",
			detail: e
		}, P("specialQuest", t.rid, { value: e })))), !0;
		case "specialQuest": {
			let n = e.decks.quests.length + e.discard.quests.length;
			for (let r = 0; r < n; r++) {
				let n = H(e, "quests");
				if (n === void 0) break;
				if (D(n).type === t.value) {
					F(e, P("takeQuest", t.rid, { id: n }));
					break;
				}
				e.discard.quests.push(n);
			}
			return !0;
		}
		case "sampleMenu": return n.agents && I(e, t.rid, "sample", e.marketBuildings.filter((n) => !e.spaces.find((e) => e.id === `m${n.id}`)?.occupants.length && Ee(e, t.rid, `m${n.id}`)).map((e) => L({
			kind: "sample",
			card: e.id
		}, P("sample", t.rid, { id: e.id })))), !0;
		case "sample": {
			let r = `m${t.id}`;
			if (e.spaces.some((e) => e.id === r) || e.spaces.push({
				id: r,
				occupants: [],
				extras: j()
			}), n.agents--, e.spaces.find((e) => e.id === r).occupants.push({
				rid: t.rid,
				agent: `${t.rid}:${++e.serial}`
			}), e.actionFrames.push({
				gain: e.actionGain,
				space: e.actionSpace,
				rid: e.actionRid,
				intrigue: e.actionIntrigue
			}), e.actionGain = {}, e.actionSpace = r, e.actionRid = t.rid, e.actionIntrigue = !1, z(e, "deploy", t.rid, { space: r }), t.id === 1521) {
				let n = e.marketBuildings.find((e) => e.id === t.id);
				G(e, t.rid, `v${n.vp}`, !0), n.vp = 0;
			}
			return F(e, P("useSpace", t.rid, { value: r }), P("actionTriggers", t.rid)), !0;
		}
		case "demolishMenu": {
			let r = e.buildings.filter((r) => !e.spaces.find((e) => e.id === `b${r.id}`).occupants.length && (r.owner === t.rid || t.value !== "own" && !M(e, r.owner).revealed && n.resources.g >= O(r.id).cost)).map((e) => L({
				kind: "demolish",
				card: e.id,
				rid: e.owner,
				cost: e.owner === t.rid ? "" : `g${O(e.id).cost}`
			}, P("demolish", t.rid, { id: e.id })));
			return I(e, t.rid, "demolish", r), !0;
		}
		case "demolish": {
			let n = e.buildings.find((e) => e.id === t.id), r = e.spaces.find((e) => e.id === `b${n.id}`);
			n.owner !== t.rid && (W(e, t.rid, `g${O(n.id).cost}`), G(e, n.owner, `g${O(n.id).cost}`));
			for (let t of B) e.supply[t] += n.stock[t] + r.extras[t];
			let i = n.stock.x + r.extras.x;
			for (let t = 0; t < i; t++) for (let t = 8; t >= 0; t--) if (e.corruption[t] < 3) {
				e.corruption[t]++;
				break;
			}
			if (e.buildings = e.buildings.filter((e) => e.id !== t.id), e.spaces = e.spaces.filter((e) => e.id !== `b${t.id}`), e.discard.buildings.push(t.id), t.id === 1513) {
				e.ambassador = null;
				for (let t of e.spaces) t.occupants = t.occupants.filter((e) => e.agent !== "ambassador");
			}
			return z(e, "demolish", t.rid, { card: t.id }), !0;
		}
		case "manipulateMenu": {
			let n = e.spaces.flatMap((n) => n.occupants.filter((n) => oe(e, t.rid, n)).map((e) => L({
				kind: "moveAgent",
				space: n.id,
				rid: e.rid
			}, P("manipulateTarget", t.rid, {
				value: n.id,
				target: e.rid,
				ref: e.agent
			}))));
			return I(e, t.rid, "moveAgent", n), !0;
		}
		case "manipulateTarget": return I(e, t.rid, "moveAgent", e.spaces.filter((e) => !e.occupants.length).map((e) => L({
			kind: "moveAgent",
			space: e.id,
			rid: t.target
		}, P("manipulateMove", t.rid, {
			...t,
			value: e.id,
			target: t.target
		})))), !0;
		case "manipulateMove":
			for (let n of e.spaces) n.occupants = n.occupants.filter((e) => e.agent !== t.ref);
			return e.spaces.find((e) => e.id === t.value).occupants.push({
				rid: t.target,
				agent: t.ref
			}), t.ref !== "ambassador" && Ee(e, t.target, t.value) && F(e, P("manipulateAction", t.target, { value: t.value })), !0;
		case "manipulateAction": return I(e, t.rid, "optional", [L({
			kind: "useSpace",
			space: t.value
		}, P("beginAction", t.rid, { value: t.value }), P("pickup", t.rid, { value: t.value }), P("useSpace", t.rid, { value: t.value }), P("actionTriggers", t.rid)), R()]), !0;
		case "drawPlay": {
			if (!t.n) return !0;
			let r = H(e, "intrigues");
			return r !== void 0 && n.hand.push(r), F(e, ...r === void 0 ? [] : [P("playMenu", t.rid, {
				id: r,
				n: 1,
				flag: !0,
				ref: t.ref
			})], ...t.n > 1 ? [P("drawPlay", t.rid, {
				n: t.n - 1,
				flag: t.flag,
				ref: t.ref
			})] : []), !0;
		}
		case "discardIntrigueMenu": return !t.n || !n.hand.length || I(e, t.rid, "discardIntrigue", n.hand.map((e) => L({
			kind: "discardIntrigue",
			card: e
		}, P("discardIntrigue", t.rid, { id: e }), ...t.n > 1 ? [P("discardIntrigueMenu", t.rid, { n: t.n - 1 })] : []))), !0;
		case "discardIntrigue": return n.hand.splice(n.hand.indexOf(t.id), 1), e.discard.intrigues.push(t.id), !0;
		default: return !1;
	}
}
//#endregion
//#region src/games/waterdeep/board-rules.ts
var ye = [
	"field",
	"lion",
	"tower",
	"plinth",
	"aurora",
	"castle",
	"builders",
	"cliff-gold",
	"cliff-card",
	"cliff-reset",
	"harbor-0",
	"harbor-1",
	"harbor-2"
], be = [
	"grim",
	"entry",
	"mirrors"
], xe = [
	"island",
	"voice",
	"slavers"
], Se = {
	field: "f2",
	lion: "r2",
	tower: "w1",
	plinth: "c1",
	aurora: "g4",
	castle: "i1",
	"cliff-gold": "g2",
	"cliff-card": "i1",
	grim: "i2",
	island: "a2x1",
	voice: "i1g5x1",
	slavers: "f2r2x1"
}, Ce = {
	1500: "f2",
	1503: "g4",
	1510: "r2",
	1516: "c1",
	1520: "w1",
	1521: "v3",
	1526: "x1"
};
function we(e, t) {
	let n = e.buildings.find((e) => e.id === t), r = V(Ce[t] ?? "");
	for (let [t, i] of Object.entries(r)) {
		let r = t;
		if (r === "x") for (let t = 0; t < i; t += 1) {
			let t = e.corruption.findIndex((e) => e > 0);
			t >= 0 && (e.corruption[t]--, n.stock.x++);
		}
		else {
			let t = B.includes(r) ? Math.min(i, e.supply[r]) : i;
			n.stock[r] += t, B.includes(r) && (e.supply[r] -= t);
		}
	}
}
function Te(e, t, n = 0) {
	return e.buildings.filter((e) => e.owner === t).length < 9 && e.marketBuildings.some((r) => O(r.id).cost <= M(e, t).resources.g + n);
}
function Ee(e, t, n, r = !0) {
	let i = M(e, t), a = (r ? e.spaces.find((e) => e.id === n)?.extras : void 0) ?? j(), o = { ...i.resources };
	for (let e of Object.keys(o)) o[e] += a[e];
	if (n.startsWith("harbor-") || n === "entry") return i.hand.some((n) => me({
		...e,
		players: e.players.map((e) => e.rid === t ? {
			...e,
			resources: o
		} : e)
	}, t, n));
	if (n === "builders") return Te(e, t, a.g);
	if (!/^[bm]\d+$/.test(n)) return !0;
	let s = Number(n.slice(1)), c = O(s);
	if (!c) return !1;
	let l = c.action.split(";").filter((e) => /[a-z]-\d/.test(e)).join("").replace(/-/g, "");
	if (l && !U(o, l) || [
		1528,
		1533,
		1535
	].includes(s) && !o.x || s === 1525 && !o.x || s === 1540 && B.reduce((e, t) => e + o[t], 0) < 3 || s === 1546 && !i.quests.some((e) => D(e).type !== "mandatory")) return !1;
	let u = {
		...e,
		players: e.players.map((e) => e.rid === t ? {
			...e,
			resources: o
		} : e)
	};
	if (s === 1538 && i.hand.length < 3) return !1;
	if ([
		1533,
		1536,
		1538,
		1539,
		1544
	].includes(s)) {
		let e = s === 1536 ? "g5" : s === 1539 ? "f1r1" : s === 1544 ? "a1" : "";
		if (!We(u, [
			...e ? [P("gain", t, { value: e })] : [],
			...s === 1533 ? [P("return", t, { n: 1 })] : [],
			P("playMenu", t, { n: s === 1538 ? 3 : 1 })
		])) return !1;
	}
	return !(s === 1523 && !e.spaces.some((r) => r.id !== n && r.occupants.some((n) => ae(e, t, n)) && r.id !== "b1523" && De(u, t, r.id)));
}
var De = (e, t, n) => n !== "b1523" && Ee(e, t, n, !1);
function J(e, t, n = "deploy", r, i) {
	let a = M(e, t);
	return e.spaces.filter((o) => i && !i(o) ? !1 : n === "copy" ? o.occupants.some((n) => ae(e, t, n)) && o.id !== "b1523" && De(e, t, o.id) : o.occupants.length && !(N(e, t, 1606) && !a.used.includes("orb") && o.occupants.some((n) => ae(e, t, n))) || r === o.id ? !1 : Ee(e, t, o.id)).map((e) => L({
		kind: n === "copy" ? "copy" : "deploy",
		space: e.id
	}, P(n === "copy" ? "useSpace" : "deploy", t, {
		value: e.id,
		ref: r
	})));
}
function Oe(e, t) {
	let n = M(e, t.rid);
	switch (t.op) {
		case "spaceMenu": {
			let r = J(e, t.rid, t.value, t.ref);
			return t.value === "copy-corrupt" && (r = J(e, t.rid, "copy", void 0, (r) => r.occupants.some((r) => ae(e, t.rid, r) && (r.agent !== "ambassador" || !!e.ambassadorActor) && M(e, r.rid).resources.x > n.resources.x))), t.flag && r.push(R()), I(e, t.rid, "deploy", r), !0;
		}
		case "deploy": {
			let r = e.spaces.find((e) => e.id === t.value), i;
			if (t.ref?.startsWith("harbor-") && !t.flag) {
				let n = e.spaces.find((e) => e.id === t.ref), r = n.occupants.findIndex((e) => e.rid === t.rid && e.agent !== "ambassador");
				i = n.occupants.splice(r, 1)[0].agent;
			} else if (e.mode === "ambassador" && e.active === t.rid && !t.flag) {
				for (let t of e.spaces) t.occupants = t.occupants.filter((e) => e.agent !== "ambassador");
				i = "ambassador", e.ambassadorActor = t.rid;
			} else n.agents--, i = `${t.rid}:${++e.serial}`;
			return r.occupants.length && n.used.push("orb"), r.occupants.push({
				rid: t.rid,
				agent: i
			}), e.actionFrames.push({
				gain: e.actionGain,
				space: e.actionSpace,
				rid: e.actionRid,
				intrigue: e.actionIntrigue
			}), e.actionGain = {}, e.actionSpace = r.id, e.actionRid = t.rid, e.actionIntrigue = !1, z(e, "deploy", t.rid, { space: r.id }), F(e, P("pickup", t.rid, { value: r.id }), P("useSpace", t.rid, { value: r.id }), ...i === "ambassador" ? [P("ambassadorReady", t.rid)] : [], P("assignmentPlots", t.rid, { value: r.id }), P("actionTriggers", t.rid)), !0;
		}
		case "pickup": {
			let r = e.spaces.find((e) => e.id === t.value);
			ue(e, t.rid, r.extras.x);
			for (let t of Object.keys(r.extras)) n.resources[t] += r.extras[t], r.extras[t] && (e.actionGain[t] = (e.actionGain[t] ?? 0) + r.extras[t]), r.extras[t] = 0;
			return !0;
		}
		case "useSpace": {
			let r = t.value, i = [];
			if (Se[r] && i.push(P("gain", t.rid, {
				value: Se[r],
				flag: !0
			})), r === "castle" && i.push(P("first", t.rid)), r === "builders" && i.push(P("buildMenu", t.rid, { value: "buy" })), (r.startsWith("cliff-") || r === "entry" || r === "voice") && (r === "cliff-reset" && i.push(P("resetQuests", t.rid)), i.push(P("questMenu", t.rid))), (r.startsWith("harbor-") || r === "entry") && i.push(P("playMenu", t.rid, { n: 1 })), r === "mirrors" && i.push(P("resourceChoice", t.rid, {
				value: "a1/f1r1",
				flag: !0
			})), /^[bm]\d+$/.test(r)) {
				let a = Number(r.slice(1)), o = O(a);
				if (r.startsWith("b") && Ce[a]) {
					let r = e.buildings.find((e) => e.id === a).stock;
					ue(e, t.rid, r.x);
					for (let t of Object.keys(r)) n.resources[t] += r[t], r[t] && (e.actionGain[t] = (e.actionGain[t] ?? 0) + r[t]), r[t] = 0;
				}
				switch (a) {
					case 1505:
						i.push(P("questMenu", t.rid, { flag: !0 }));
						break;
					case 1509:
						i.push(P("gain", t.rid, {
							value: "c1",
							flag: !0
						}), P("questMenu", t.rid));
						break;
					case 1513:
						i.push(P("ambassador", t.rid));
						break;
					case 1517:
						i.push(P("gain", t.rid, {
							value: `g${e.buildings.length}`,
							flag: !0
						}));
						break;
					case 1521:
						i.push(P("questMenu", t.rid));
						break;
					case 1523:
						i.push(P("spaceMenu", t.rid, { value: "copy" }));
						break;
					case 1525:
						i.push(P("placeExtraMenu", t.rid, {
							value: "own-x1",
							n: 1
						}));
						break;
					case 1526: {
						let n = e.actionGain.x ?? 0;
						n && i.push(P("recallMenu", t.rid, {
							n,
							flag: !0
						}));
						break;
					}
					case 1527:
						i.push(P("returnMenu", t.rid, {
							n: 2,
							flag: !0
						}));
						break;
					case 1528:
						i.push(P("return", t.rid, { n: 1 }), P("gain", t.rid, {
							value: "c1",
							flag: !0
						}));
						break;
					case 1530:
						i.push(P("gain", t.rid, {
							value: "a1g5x1",
							flag: !0
						}), P("questMenu", t.rid));
						break;
					case 1531:
						i.push(P("frontalPayMenu", t.rid, { value: r }));
						break;
					case 1533:
						i.push(P("return", t.rid, { n: 1 }), P("playMenu", t.rid, { n: 1 }));
						break;
					case 1535:
						i.push(P("return", t.rid, { n: 1 }), P("gain", t.rid, {
							value: "g1",
							flag: !0
						}));
						break;
					case 1536:
						i.push(P("gain", t.rid, {
							value: "g5",
							flag: !0
						}), P("playMenu", t.rid, { n: 1 }));
						break;
					case 1537:
						i.push(P("gain", t.rid, {
							value: "f4",
							flag: !0
						}), P("placeExtraMenu", t.rid, {
							value: "f1",
							n: 2
						}));
						break;
					case 1538:
						i.push(P("playMenu", t.rid, { n: 3 }));
						break;
					case 1539:
						i.push(P("gain", t.rid, {
							value: "f1r1",
							flag: !0
						}), P("playMenu", t.rid, { n: 1 }));
						break;
					case 1540:
						i.push(P("placeExtraMenu", t.rid, {
							value: "own-a1",
							n: 3
						}), P("gain", t.rid, {
							value: "v10",
							flag: !0
						}));
						break;
					case 1541:
						i.push(P("gain", t.rid, {
							value: "g8",
							flag: !0
						}), P("placeExtraMenu", t.rid, {
							value: "g2",
							n: 2
						}));
						break;
					case 1542:
						i.push(P("gain", t.rid, {
							value: "c2",
							flag: !0
						}), P("placeExtraMenu", t.rid, {
							value: "c1",
							n: 1
						}));
						break;
					case 1543:
						i.push(P("gain", t.rid, {
							value: "r4",
							flag: !0
						}), P("placeExtraMenu", t.rid, {
							value: "r1",
							n: 2
						}));
						break;
					case 1544:
						i.push(P("gain", t.rid, {
							value: "a1",
							flag: !0
						}), P("playMenu", t.rid, { n: 1 }));
						break;
					case 1545:
						i.push(P("gain", t.rid, {
							value: "w2",
							flag: !0
						}), P("placeExtraMenu", t.rid, {
							value: "w1",
							n: 1
						}));
						break;
					case 1546:
						i.push(P("discardQuestMenu", t.rid, { value: "normal" }), P("gain", t.rid, {
							value: "f1r1a1",
							flag: !0
						}));
						break;
					case 1547:
						i.push(P("gain", t.rid, {
							value: "i2g4",
							flag: !0
						}), P("discardIntrigueMenu", t.rid, { n: 2 }));
						break;
					default: for (let e of o.action.split(";")) e !== "stock" && (e.includes("/") ? i.push(P("resourceChoice", t.rid, {
						value: e,
						flag: !0
					})) : e.includes("-") ? i.push(P("payMenu", t.rid, {
						value: e.replace(/-/g, ""),
						id: a
					})) : i.push(P("gain", t.rid, {
						value: e,
						flag: !0
					})));
				}
				r.startsWith("b") && a !== 1531 && i.push(P("owner", t.rid, { id: a }));
			}
			return F(e, ...i), !0;
		}
		case "buildMenu": {
			if (e.buildings.filter((e) => e.owner === t.rid).length >= 9) return !0;
			let r = e.marketBuildings.filter((e) => t.value !== "buy" || n.resources.g >= O(e.id).cost).map((e) => L({
				kind: "build",
				card: e.id,
				cost: t.value === "buy" ? `g${O(e.id).cost}` : "",
				gain: `v${e.vp}`
			}, P("control", t.rid, {
				id: e.id,
				flag: t.value === "buy"
			})));
			return t.flag && r.push(R()), I(e, t.rid, "build", r), !0;
		}
		case "control": {
			if (e.buildings.filter((e) => e.owner === t.rid).length >= 9) return !0;
			let r = e.marketBuildings.findIndex((e) => e.id === t.id), i = O(t.id);
			t.flag && W(e, t.rid, `g${i.cost}`), r >= 0 && (n.resources.v += e.marketBuildings[r].vp, e.marketBuildings.splice(r, 1)), e.buildings.push({
				id: i.id,
				owner: t.rid,
				stock: j()
			});
			let a = e.spaces.find((e) => e.id === `m${i.id}`);
			return a ? a.id = `b${i.id}` : e.spaces.push({
				id: `b${i.id}`,
				occupants: [],
				extras: j()
			}), we(e, i.id), pe(e), z(e, "build", t.rid, {
				card: i.id,
				space: r >= 0 ? "market" : "deck"
			}), t.flag && N(e, t.rid, 1616) && F(e, P("gain", t.rid, { value: "v4" })), t.flag && N(e, t.rid, 1706) && n.resources.x && F(e, P("optional", t.rid, {
				value: "placeExtraMenu",
				ref: "own-x1",
				n: 1
			})), !0;
		}
		case "owner": {
			let n = e.buildings.find((e) => e.id === t.id);
			if (!n || n.owner === t.rid && !N(e, t.rid, 1751)) return !0;
			let r = O(n.id).owner;
			return r === "returned-adventurer" ? (t.value && F(e, P("gain", n.owner, { value: t.value })), !0) : (F(e, P(r.includes("/") ? "resourceChoice" : "gain", n.owner, { value: r })), !0);
		}
		case "ambassador":
			if (!e.ambassador) {
				for (let t of e.spaces) t.occupants = t.occupants.filter((e) => e.agent !== "ambassador");
				e.ambassador = t.rid;
			}
			return !0;
		case "ambassadorReady": return e.ambassadorActor = null, !0;
		case "frontalPayMenu": {
			let r = t.value?.startsWith("b") ? e.buildings.find((e) => e.id === 1531).owner : null;
			return I(e, t.rid, "payAny", B.filter((e) => n.resources[e]).map((n) => L({
				kind: "payResource",
				resource: n,
				amount: 1
			}, P("pay", t.rid, { value: `${n}1` }), P("gain", t.rid, {
				value: "w3x1",
				flag: !0
			}), ...r && (r !== t.rid || N(e, t.rid, 1751)) ? [P("gain", r, { value: `${n}1` })] : []))), !0;
		}
		case "placeExtraMenu": {
			if (!t.n) return !0;
			if (t.value === "own-a1") return I(e, t.rid, "placeResource", B.filter((e) => n.resources[e]).map((e) => L({
				kind: "resource",
				resource: e,
				amount: 1
			}, P("placeExtraMenu", t.rid, {
				...t,
				value: `own-${e}1`,
				ref: `any:${t.n}:${t.ref ?? ""}`
			})))), !0;
			let r = (t.ref?.startsWith("any:") ? t.ref.split(":").slice(2).join(":") : t.ref ?? "").split(",");
			return I(e, t.rid, "placeResource", e.spaces.filter((e) => !/^m\d+$/.test(e.id) && !r.includes(e.id)).map((e) => L({
				kind: "placeResource",
				space: e.id,
				gain: t.value?.replace("own-", "")
			}, P("placeExtra", t.rid, {
				...t,
				target: e.id
			})))), !0;
		}
		case "placeExtra": {
			let r = t.value.startsWith("own-"), i = V(t.value.replace("own-", "")), a = e.spaces.find((e) => e.id === t.target);
			for (let [t, o] of Object.entries(i)) {
				let i = t, s = o;
				if (r) n.resources[i] -= s;
				else if (i === "x") {
					s = 0;
					for (let t = 0; t < o; t++) {
						let t = e.corruption.findIndex((e) => e > 0);
						if (t < 0) break;
						e.corruption[t]--, s++;
					}
				} else B.includes(i) && (s = Math.min(s, e.supply[i]), e.supply[i] -= s);
				a.extras[i] += s;
			}
			let o = t.ref?.startsWith("any:") ? t.ref.split(":").slice(2).join(":") : t.ref ?? "";
			return (t.n ?? 1) > 1 && F(e, P("placeExtraMenu", t.rid, {
				value: t.ref?.startsWith("any:") ? "own-a1" : t.value,
				n: t.n - 1,
				ref: `${o},${a.id}`
			})), !0;
		}
		case "first":
			e.first = t.rid;
			for (let n of e.players.filter((e) => e.completed.includes(1728))) G(e, n.rid, "f1"), G(e, t.rid, "f1");
			return !0;
		case "assignmentPlots": {
			let r = {
				tower: [1702, "w1x1"],
				aurora: [1708, "g4x1"],
				plinth: [1714, "c1x1"],
				lion: [1719, "r2x1"],
				field: [1725, "f2x1"]
			}[t.value];
			return r && N(e, t.rid, r[0]) && F(e, P("optional", t.rid, {
				value: "gain",
				ref: r[1]
			})), t.value?.startsWith("harbor-") && N(e, t.rid, 1705) && n.hand.some((n) => me(e, t.rid, n)) && F(e, P("optional", t.rid, { value: "extraHarbor" })), !0;
		}
		case "extraHarbor": return F(e, P("playMenu", t.rid, { n: 1 }), P("gain", t.rid, {
			value: "x1",
			flag: !0
		}), P("playMenu", t.rid, {
			n: 1,
			flag: !0
		})), !0;
		case "actionTriggers": {
			let r = e.actionGain, i = `${r.w && N(e, t.rid, 1601) ? "i1" : ""}${r.g && N(e, t.rid, 1613) ? "r1" : ""}${r.r && N(e, t.rid, 1640) ? "g2" : ""}${r.f && N(e, t.rid, 1650) ? "f1" : ""}`;
			i && F(e, P("gain", t.rid, { value: i })), r.c && N(e, t.rid, 1632) && !n.used.includes("miracle") && F(e, P("miracle", t.rid));
			let a = e.actionIntrigue && N(e, t.rid, 1734), o = e.actionFrames.pop();
			return e.actionGain = o?.gain ?? {}, e.actionSpace = o?.space ?? null, e.actionRid = o?.rid ?? null, e.actionIntrigue = o?.intrigue ?? !1, a && e.agenda.splice(+!!i + (r.c && N(e, t.rid, 1632) && !n.used.includes("miracle") ? 1 : 0), 0, P("drawPlay", t.rid, {
				n: 1,
				ref: "librarium"
			})), !0;
		}
		case "miracle": {
			let r = B.filter((t) => t !== "c" && n.resources[t] && e.supply.c).map((e) => L({
				kind: "trade",
				cost: `${e}1`,
				gain: "c1"
			}, P("pay", t.rid, { value: `${e}1` }), P("gain", t.rid, { value: "c1" }), P("used", t.rid, { value: "miracle" })));
			return r.push(R()), I(e, t.rid, "trade", r), !0;
		}
		case "return": return fe(e, t.rid, t.n, t.flag), !0;
		default: return !1;
	}
}
//#endregion
//#region src/games/waterdeep/meta.ts
var ke = {
	id: "waterdeep",
	tier: "alpha",
	mechanics: [
		"worker-placement",
		"engine-building",
		"hand-management"
	],
	interactionTags: ["hidden-roles"],
	nameKey: "games.waterdeep.name",
	descKey: "games.waterdeep.desc",
	rulesKey: "games.waterdeep.rules",
	icon: "🏰",
	iconImg: "games/waterdeep.webp",
	rulesUrl: { en: "https://media.wizards.com/downloads/dnd/DnD_LOW_Rulebook_EN.pdf" },
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [3, 4],
	playerRange: (e) => {
		let t = e;
		return {
			min: 2,
			max: t?.undermountain || t?.skullport ? 6 : 5
		};
	},
	accent: "#426e86",
	releasedAt: "2026-10-31T00:37:00+08:00",
	search: {
		py: "shen shui cheng ling zhu",
		init: "ssclz"
	},
	hotseat: "cover"
};
//#endregion
//#region src/games/waterdeep/quest-rules.ts
function Ae(e, t, n) {
	let r = M(e, t), i = r.quests.filter((e) => D(e).type === "mandatory");
	return (i.length ? i : [...r.quests, ...N(e, t, 1742) ? e.marketQuests : []]).filter((e) => (n === void 0 || e === n) && U(r.resources, D(e).cost));
}
function je(e, t) {
	let n = M(e, t.rid);
	switch (t.op) {
		case "questMenu": return I(e, t.rid, "quest", e.marketQuests.map((e) => L({
			kind: "takeQuest",
			card: e
		}, P("takeQuest", t.rid, {
			id: e,
			flag: t.flag
		})))), !0;
		case "takeQuest": {
			let r = t.id, i = e.marketQuests.indexOf(r);
			i >= 0 && e.marketQuests.splice(i, 1), n.quests.push(r), pe(e), z(e, "takeQuest", t.rid, {
				card: r,
				space: i >= 0 ? "market" : "deck"
			});
			for (let [n, i, a] of [
				[
					1731,
					"arcana",
					"w1"
				],
				[
					1739,
					"commerce",
					"g4"
				],
				[
					1747,
					"piety",
					"c1"
				],
				[
					1748,
					"skullduggery",
					"r2"
				],
				[
					1757,
					"warfare",
					"f2"
				]
			]) N(e, t.rid, n) && D(r).type === i && F(e, P("gain", t.rid, { value: a }));
			return t.flag && F(e, P("completeMenu", t.rid, {
				id: r,
				flag: !0
			})), !0;
		}
		case "resetQuests": return e.discard.quests.push(...e.marketQuests), e.marketQuests = [], pe(e), !0;
		case "completeMenu": {
			let n = Ae(e, t.rid, t.id).map((e) => L({
				kind: "complete",
				card: e,
				cost: D(e).cost,
				gain: D(e).reward
			}, P("payQuest", t.rid, {
				id: e,
				flag: t.flag
			})));
			return n.push(R()), I(e, t.rid, "complete", n), !0;
		}
		case "payQuest": {
			let n = D(t.id), r = V(n.cost);
			return e.paid = Object.fromEntries(B.map((e) => [e, r[e] ?? 0])), W(e, t.rid, n.cost.replace(/a\d+/g, "")), F(e, ...r.a ? [P("payAny", t.rid, { n: r.a })] : [], P("finishQuest", t.rid, {
				id: n.id,
				flag: t.flag
			})), !0;
		}
		case "payAny": return t.n && I(e, t.rid, "payAny", B.filter((e) => n.resources[e]).map((e) => L({
			kind: "payResource",
			resource: e,
			amount: 1
		}, P("payAnyUnit", t.rid, {
			value: e,
			n: t.n
		})))), !0;
		case "payAnyUnit": {
			let n = t.value;
			return W(e, t.rid, `${n}1`), e.paid[n] = (e.paid[n] ?? 0) + 1, t.n > 1 && F(e, P("payAny", t.rid, { n: t.n - 1 })), !0;
		}
		case "finishQuest": {
			let r = D(t.id), i = n.quests.indexOf(r.id), a = i < 0;
			i >= 0 ? n.quests.splice(i, 1) : e.marketQuests.splice(e.marketQuests.indexOf(r.id), 1);
			let o = [...n.completed];
			r.type === "mandatory" ? e.discard.intrigues.push(r.id) : n.completed.push(r.id), a && pe(e), z(e, "complete", t.rid, {
				card: r.id,
				gain: r.reward,
				space: a ? "market" : "tavern"
			});
			let s = [P("gain", t.rid, { value: r.reward })];
			t.flag && s.push(P("gain", t.rid, { value: "v4" }));
			for (let [e, n] of [
				[1611, "arcana"],
				[1614, "commerce"],
				[1633, "piety"],
				[1641, "skullduggery"],
				[1655, "warfare"]
			]) o.includes(e) && r.type === n && s.push(P("gain", t.rid, { value: "v2" }));
			switch (o.includes(1758) && s.push(P("recoverSpent", t.rid, { value: B.filter((t) => e.paid[t]).join("") })), r.id) {
				case 1608:
					s.push(P("recallMenu", t.rid, { n: 1 }));
					break;
				case 1617: {
					let n = H(e, "quests");
					n !== void 0 && s.push(P("takeQuest", t.rid, { id: n }));
					break;
				}
				case 1618:
					s.push(P("buildMenu", t.rid));
					break;
				case 1619: {
					let n = H(e, "buildings");
					n !== void 0 && s.push(P("control", t.rid, { id: n }));
					break;
				}
				case 1621:
					s.push(P("opponentGift", t.rid, { value: "g4" }));
					break;
				case 1624:
				case 1627:
				case 1629:
					s.push(P("questMenu", t.rid));
					break;
				case 1637:
					s.push(P("gain", t.rid, { value: `v${2 * e.buildings.filter((e) => e.owner === t.rid).length}` }));
					break;
				case 1643:
					s.push(P("playMenu", t.rid, { n: 1 }));
					break;
				case 1657:
					n.lieutenant = !0, n.agents++;
					break;
				case 1703:
				case 1711:
				case 1712:
				case 1729:
					s.push(P("returnMenu", t.rid, { n: 2 }));
					break;
				case 1704:
				case 1707:
				case 1715:
				case 1721:
					s.push(P("returnMenu", t.rid, { n: 3 }));
					break;
				case 1720:
				case 2002:
					s.push(P("returnMenu", t.rid, { n: 1 }));
					break;
				case 1723:
					s.push(P("buildMenu", t.rid), P("buildMenu", t.rid));
					break;
				case 1724:
					for (let t = 1; t < e.players.length; t++) {
						let r = e.players[(e.players.indexOf(n) + t) % e.players.length];
						s.push(P("loseAny", r.rid, { n: 1 }));
					}
					break;
				case 1726:
					s.push(P("returnMenu", t.rid, {
						n: 3,
						flag: !0
					}));
					break;
				case 1730:
					s.push(P("drawPlay", t.rid, { n: 4 }));
					break;
				case 1735:
					s.push(P("gain", t.rid, { value: `i${e.paid.w ?? 0}` }));
					break;
				case 1738:
					s.push(P("tradeMenu", t.rid, {
						value: "g10",
						ref: "f3r3"
					}));
					break;
				case 1741:
					s.push(...e.marketBuildings.map((e) => P("control", t.rid, { id: e.id })));
					break;
				case 1743:
					s.push(...e.marketQuests.map((e) => P("takeQuest", t.rid, { id: e })));
					break;
				case 1746:
					s.push(P("gain", t.rid, { value: `v${2 * (e.paid.c ?? 0)}` }));
					break;
				case 1753:
					s.push(P("tradeMenu", t.rid, {
						value: "r4",
						ref: "v10"
					}));
					break;
				case 1755:
					s.push(P("recallMenu", t.rid, {
						n: 3,
						flag: !0
					}));
					break;
				case 1756: s.push(P("tradeMenu", t.rid, {
					value: "f4",
					ref: "v10"
				}));
			}
			return F(e, ...s), !0;
		}
		case "recoverSpent": return I(e, t.rid, "recover", [...B.filter((n) => t.value?.includes(n) && e.supply[n]).map((e) => L({
			kind: "resource",
			resource: e,
			amount: 1
		}, P("gain", t.rid, { value: `${e}1` }))), R()]), !0;
		case "discardQuestMenu": {
			let r = n.quests.filter((e) => t.value !== "normal" || D(e).type !== "mandatory").map((e) => L({
				kind: "discardQuest",
				card: e
			}, P("discardQuest", t.rid, {
				id: e,
				n: t.n
			})));
			return t.flag && r.push(R()), I(e, t.rid, "discardQuest", r), !0;
		}
		case "discardQuest": {
			let r = t.id;
			return n.quests.splice(n.quests.indexOf(r), 1), e.discard[D(r).type === "mandatory" ? "intrigues" : "quests"].push(r), t.n && G(e, t.rid, `v${t.n}`), z(e, "discardQuest", t.rid, { card: r }), !0;
		}
		default: return !1;
	}
}
//#endregion
//#region src/games/waterdeep/schema.ts
var Me = t.object({
	undermountain: t.boolean().default(!1),
	skullport: t.boolean().default(!1),
	long: t.boolean().default(!1)
}).prefault({}), Ne = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	id: t.string().max(160)
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), Pe = t.object({
	c: t.int().nonnegative(),
	f: t.int().nonnegative(),
	r: t.int().nonnegative(),
	w: t.int().nonnegative(),
	g: t.int().nonnegative(),
	v: t.int(),
	x: t.int().nonnegative()
}), Fe = t.object({
	id: t.string(),
	kind: t.string(),
	card: t.int().optional(),
	space: t.string().optional(),
	rid: t.string().optional(),
	resource: t.string().optional(),
	amount: t.int().optional(),
	detail: t.string().optional(),
	gain: t.string().optional(),
	cost: t.string().optional()
}), Ie = t.object({
	rid: t.string(),
	resources: Pe,
	agents: t.int().nonnegative(),
	quests: t.array(t.int()),
	completed: t.array(t.int()),
	intrigueCount: t.int().nonnegative(),
	lord: t.int().nullable(),
	revealed: t.boolean(),
	lieutenant: t.boolean()
}), Le = t.object({
	config: Me,
	round: t.int(),
	phase: t.enum([
		"play",
		"resolve",
		"done"
	]),
	first: t.string(),
	active: t.string(),
	mode: t.enum([
		"normal",
		"harbor",
		"ambassador"
	]),
	players: t.array(Ie),
	spaces: t.array(t.object({
		id: t.string(),
		occupants: t.array(t.object({
			rid: t.string(),
			agent: t.string()
		})),
		extras: Pe
	})),
	buildings: t.array(t.object({
		id: t.int(),
		owner: t.string(),
		stock: Pe
	})),
	marketQuests: t.array(t.int()),
	marketBuildings: t.array(t.object({
		id: t.int(),
		vp: t.int()
	})),
	corruption: t.array(t.int()),
	supply: Pe,
	removedCorruption: t.int(),
	pending: t.object({
		rid: t.string(),
		kind: t.string()
	}).nullable(),
	last: t.object({
		kind: t.string(),
		rid: t.string(),
		card: t.int().optional(),
		space: t.string().optional(),
		gain: t.string().optional()
	}).nullable(),
	log: t.array(t.object({
		kind: t.string(),
		rid: t.string(),
		card: t.int().optional(),
		space: t.string().optional(),
		gain: t.string().optional()
	})),
	final: t.array(t.object({
		rid: t.string(),
		points: t.int(),
		adventurers: t.int(),
		gold: t.int(),
		lord: t.int(),
		corruption: t.int(),
		total: t.int()
	}))
}), Re = t.object({
	hand: t.array(t.int()),
	lord: t.int().nullable(),
	choices: t.array(Fe),
	seenLords: t.array(t.object({
		rid: t.string(),
		lord: t.int()
	}))
});
function ze(e, t, n) {
	let r = Me.parse(e);
	if (t.length === 6 && !r.undermountain && !r.skullport) throw Error("Six players require an expansion");
	r.long ||= t.length === 6 || r.undermountain && r.skullport;
	let i = [
		...ye,
		...r.undermountain ? be : [],
		...r.skullport ? xe : []
	], a = {
		config: r,
		players: [],
		beat: 0,
		round: 1,
		phase: "resolve",
		first: t[0],
		active: t[0],
		mode: "normal",
		spaces: i.map((e) => ({
			id: e,
			occupants: [],
			extras: j()
		})),
		buildings: [],
		marketQuests: [],
		marketBuildings: [],
		decks: {
			quests: [],
			intrigues: [],
			buildings: []
		},
		discard: {
			quests: [],
			intrigues: [],
			buildings: []
		},
		supply: {
			...j(),
			c: r.undermountain || r.skullport ? 45 : 25,
			f: r.undermountain || r.skullport ? 45 : 25,
			r: r.undermountain || r.skullport ? 45 : 25,
			w: r.undermountain || r.skullport ? 45 : 25
		},
		corruption: r.skullport ? [
			1,
			3,
			3,
			3,
			3,
			3,
			3,
			3,
			3
		] : [],
		removedCorruption: 0,
		ambassador: null,
		ambassadorActor: null,
		harbor: [],
		agenda: [],
		decision: null,
		serial: 0,
		seed: n,
		rngCursor: 0,
		last: null,
		log: [],
		final: [],
		actionGain: {},
		actionSpace: null,
		actionRid: null,
		actionIntrigue: !1,
		actionFrames: [],
		paid: {}
	}, o = (e) => e === "base" || r[e], s = (e, t) => {
		let n = ce(a, e.filter((e) => e.scope === "base").map((e) => e.id)).slice(r.undermountain && r.skullport ? t : 0);
		return ce(a, [...n, ...e.filter((e) => e.scope !== "base" && o(e.scope)).map((e) => e.id)]);
	};
	a.decks.quests = s(T.filter((e) => e.type !== "mandatory"), 30), a.decks.intrigues = s(re, 25), a.decks.buildings = s(E, 12);
	let c = ce(a, ie.filter((e) => o(e.scope)).map((e) => e.id));
	a.first = ce(a, t)[0], a.active = a.first;
	let l = t.indexOf(a.first), u = (r.long ? [
		0,
		0,
		5,
		4,
		3,
		3,
		2
	] : [
		0,
		0,
		4,
		3,
		2,
		2
	])[t.length];
	for (let e = 0; e < t.length; e++) {
		let n = t[e];
		a.players.push({
			rid: n,
			resources: {
				...j(),
				g: 4 + (e - l + t.length) % t.length
			},
			agents: u,
			quests: [H(a, "quests"), H(a, "quests")],
			completed: [],
			hand: [H(a, "intrigues"), H(a, "intrigues")],
			lord: c[e],
			revealed: !1,
			lieutenant: !1,
			used: [],
			seenLords: []
		});
	}
	pe(a);
	for (let e of a.marketBuildings) e.vp++;
	return a.agenda = [P("turn", a.first)], {
		state: a,
		fx: []
	};
}
function Be(e, t) {
	e.active = t;
	for (let t of e.players) t.used = t.used.filter((e) => ![
		"shelter",
		"converts",
		"librarium",
		"intrigueAction"
	].includes(e));
	let n = M(e, t), r = n.agents || e.mode !== "normal" ? J(e, t, "deploy", e.mode === "harbor" ? e.harbor[0]?.space : void 0) : [];
	e.mode === "normal" && n.agents > 0 && N(e, t, 1736) && !n.used.includes("plans") && r.push(...e.marketBuildings.filter((n) => !e.spaces.find((e) => e.id === `m${n.id}`)?.occupants.length && Ee(e, t, `m${n.id}`)).map((e) => L({
		kind: "sample",
		card: e.id
	}, P("used", t, { value: "plans" }), P("sample", t, { id: e.id }))));
	let i = r.map((e) => ({
		...e,
		jobs: [...e.jobs, P("turnFinish", t)]
	}));
	if (!i.length) {
		F(e, P("advance", t));
		return;
	}
	I(e, t, "deploy", i);
}
function Ve(e) {
	let t = le(e);
	e.final = e.players.map((n) => {
		let r = n.lord, i = A(r), a = n.completed.map(D), o = e.buildings.filter((e) => e.owner === n.rid), s = 0;
		if (i.types.length) s = 4 * a.filter((e) => i.types.includes(e.type)).length;
		else switch (r) {
			case 1305:
				s = 6 * o.length;
				break;
			case 1311:
				s = 3 * a.length;
				break;
			case 1312:
			case 1315: {
				let e = r === 1312 ? "undermountain" : "skullport";
				s = 4 * (a.filter((t) => t.scope === e).length + o.filter((t) => E.find((e) => e.id === t.id).scope === e).length);
				break;
			}
			case 1313:
				s = 5 * a.filter((e) => (V(e.reward).v ?? 0) >= 10).length;
				break;
			case 1314:
				s = 6 * Math.max(0, ...[
					"arcana",
					"commerce",
					"piety",
					"skullduggery",
					"warfare"
				].map((e) => a.filter((t) => t.type === e).length));
				break;
			case 1316: s = 4 * n.resources.x;
		}
		let c = B.reduce((e, t) => e + n.resources[t], 0), l = Math.floor(n.resources.g / 2), u = n.resources.x * t;
		return {
			rid: n.rid,
			points: n.resources.v,
			adventurers: c,
			gold: l,
			lord: s,
			corruption: u,
			total: n.resources.v + c + l + s - u
		};
	}), e.phase = "done", e.decision = null, e.agenda = [], z(e, "finish", e.first);
}
function He(e, t) {
	if (e.mode === "ambassador") {
		e.mode = "normal", F(e, P("turn", e.first));
		return;
	}
	if (e.mode === "harbor") {
		if (M(e, t).agents > 0 && J(e, t).length) {
			F(e, P("harborExtra", t));
			return;
		}
		for (e.harbor.shift(); e.harbor.length && !e.spaces.find((t) => t.id === e.harbor[0].space)?.occupants.some((t) => t.agent === e.harbor[0].agent);) e.harbor.shift();
		if (e.harbor.length) {
			F(e, P("turn", e.harbor[0].rid));
			return;
		}
		F(e, P("roundEnd", e.first));
		return;
	}
	let n = e.players.findIndex((e) => e.rid === t);
	for (let t = 1; t <= e.players.length; t++) {
		let r = e.players[(n + t) % e.players.length];
		if (r.agents > 0 && (J(e, r.rid).length || N(e, r.rid, 1736) && !r.used.includes("plans") && e.marketBuildings.some((t) => !e.spaces.find((e) => e.id === `m${t.id}`)?.occupants.length && Ee(e, r.rid, `m${t.id}`)))) {
			F(e, P("turn", r.rid));
			return;
		}
	}
	e.harbor = e.spaces.filter((e) => e.id.startsWith("harbor-")).flatMap((e) => e.occupants.filter((e) => e.agent !== "ambassador").map((t) => ({
		space: e.id,
		...t
	}))), e.harbor.length ? (e.mode = "harbor", F(e, P("turn", e.harbor[0].rid))) : F(e, P("roundEnd", e.first));
}
function Ue(e, t) {
	let n = M(e, t.rid);
	switch (t.op) {
		case "beginAction": return e.actionFrames.push({
			gain: e.actionGain,
			space: e.actionSpace,
			rid: e.actionRid,
			intrigue: e.actionIntrigue
		}), e.actionGain = {}, e.actionSpace = t.value, e.actionRid = t.rid, e.actionIntrigue = !1, !0;
		case "turn": return Be(e, t.rid), !0;
		case "turnFinish": return F(e, P("completeMenu", t.rid), P("advance", t.rid)), !0;
		case "advance": return He(e, t.rid), !0;
		case "roundEnd": return e.round === 8 ? Ve(e) : F(e, P("startRound", e.first)), !0;
		case "startRound": {
			e.round++;
			for (let t of e.spaces) {
				for (let n of t.occupants) n.agent !== "ambassador" && M(e, n.rid).agents++;
				t.occupants = [];
			}
			e.spaces = e.spaces.filter((e) => !/^m\d+$/.test(e.id));
			for (let t of e.players) t.used = [], e.round === 5 && t.agents++;
			for (let t of e.marketBuildings) t.vp++;
			for (let t of e.buildings) we(e, t.id);
			let t = [], n = e.players.findIndex((t) => t.rid === e.first);
			for (let r = 0; r < e.players.length; r++) {
				let i = e.players[(n + r) % e.players.length];
				i.completed.includes(1626) && t.push(P("any", i.rid, { n: 1 }));
			}
			if (e.ambassador) {
				let n = e.ambassador;
				e.ambassador = null, e.mode = "ambassador", t.push(P("turn", n));
			} else e.mode = "normal", t.push(P("turn", e.first));
			return z(e, "round", e.first), F(e, ...t), !0;
		}
		case "harborExtra": return I(e, t.rid, "deploy", J(e, t.rid).map((e) => ({
			...e,
			jobs: [
				...e.jobs.map((e) => ({
					...e,
					flag: !0
				})),
				P("completeMenu", t.rid),
				P("advance", t.rid)
			]
		}))), !0;
		case "extraAssign": {
			if (!t.n || !n.agents) return !0;
			let r = J(e, t.rid).map((e) => ({
				...e,
				jobs: [
					...e.jobs.map((e) => ({
						...e,
						flag: !0
					})),
					P("completeMenu", t.rid),
					...t.n > 1 ? [P("extraAssign", t.rid, { n: t.n - 1 })] : []
				]
			}));
			return I(e, t.rid, "deploy", r), !0;
		}
		case "gain": return G(e, t.rid, t.value, t.flag), !0;
		case "pay": return W(e, t.rid, t.value), !0;
		case "used": return n.used.push(t.value), !0;
		case "any": return t.n && I(e, t.rid, "resource", B.filter((t) => e.supply[t]).map((e) => L({
			kind: "resource",
			resource: e,
			amount: 1
		}, P("gain", t.rid, {
			value: `${e}1`,
			flag: t.flag
		}), ...t.n > 1 ? [P("any", t.rid, {
			n: t.n - 1,
			flag: t.flag
		})] : []))), !0;
		case "resourceChoice": return I(e, t.rid, "resource", t.value.split("/").map((e) => L({
			kind: "gain",
			gain: e
		}, P("gain", t.rid, {
			value: e,
			flag: t.flag
		})))), !0;
		case "loseAny": return t.n && I(e, t.rid, "loseAny", B.filter((e) => n.resources[e]).map((e) => L({
			kind: "payResource",
			resource: e,
			amount: 1
		}, P("pay", t.rid, { value: `${e}1` }), ...t.n > 1 ? [P("loseAny", t.rid, { n: t.n - 1 })] : []))), !0;
		case "payMenu": {
			let n = V(t.value);
			return W(e, t.rid, t.value.replace(/a\d+/g, "")), n.a && F(e, P("loseAny", t.rid, { n: n.a })), !0;
		}
		case "optional": return I(e, t.rid, "optional", [L({
			kind: t.value,
			gain: t.ref
		}, P(t.value, t.rid, {
			value: t.ref,
			n: t.n,
			flag: t.flag
		})), R()]), !0;
		case "tradeMenu": return U(n.resources, t.value) && I(e, t.rid, "trade", [L({
			kind: "trade",
			cost: t.value,
			gain: t.ref
		}, P("pay", t.rid, { value: t.value }), P("gain", t.rid, { value: t.ref })), R()]), !0;
		case "returnMenu": {
			let r = Math.min(t.n, n.resources.x);
			return r && I(e, t.rid, t.flag ? "removeCorruption" : "returnCorruption", Array.from({ length: r + 1 }, (e, n) => L({
				kind: t.flag ? "removeCorruption" : "returnCorruption",
				amount: n
			}, P("return", t.rid, {
				n,
				flag: t.flag
			})))), !0;
		}
		case "removeTrack": return de(e, t.rid, t.n, !0), !0;
		case "recallMenu": {
			if (!t.n) return !0;
			let n = e.spaces.filter((e) => t.value !== "harbor" || e.id.startsWith("harbor-")).flatMap((e) => e.occupants.filter((e) => e.rid === t.rid && e.agent !== "ambassador").map((n) => L({
				kind: "recall",
				space: e.id
			}, P("recall", t.rid, { ref: n.agent }), ...t.n > 1 ? [P("recallMenu", t.rid, {
				n: t.n - 1,
				flag: t.flag
			})] : [])));
			return t.flag && n.push(R()), I(e, t.rid, "recall", n), !0;
		}
		case "recall":
			for (let r of e.spaces) {
				let e = r.occupants.findIndex((e) => e.agent === t.ref);
				if (e >= 0) {
					r.occupants.splice(e, 1), n.agents++;
					break;
				}
			}
			return !0;
		default: return !1;
	}
}
function We(e, t) {
	let n = structuredClone({
		...e,
		log: [],
		last: null
	});
	n.agenda = t, n.decision = null, n.probing = !0, n.probeFailed = !1;
	let r = (e) => {
		for (; e.agenda.length || e.decision;) {
			if (e.probeFailed) return !1;
			let t = e.agenda.at(-1);
			if (!e.decision && e.agenda.length > 1 && t?.op === "playMenu" && !t.flag && e.agenda.slice(0, -1).every((e) => e.op === "discardQuestMenu" && e.flag && e.rid !== t.rid) && !M(e, t.rid).hand.some((n) => me(e, t.rid, n))) return !1;
			if (e.decision) return [...e.decision.offers].sort((e, t) => Number(t.option.kind === "skip") - Number(e.option.kind === "skip")).some((t) => {
				let n = structuredClone(e);
				return n.decision = null, F(n, ...t.jobs), r(n);
			});
			let n = e.agenda.shift();
			if (!(Ue(e, n) || Oe(e, n) || je(e, n) || ve(e, n))) return !1;
		}
		return !e.probeFailed;
	};
	return r(n);
}
function Ge(e, t, n) {
	if (e.phase === "done") return { code: "games.waterdeep.errFinished" };
	if (t.type === "choose" && (!e.decision || e.decision.rid !== n.by)) return { code: "games.waterdeep.errTurn" };
	if (t.type === "choose" && !e.decision.offers.some((e) => e.option.id === t.id)) return { code: "games.waterdeep.errChoice" };
	if (t.type === "tick" && (e.decision || !e.agenda.length || n.by !== "$engine")) return {
		state: e,
		fx: []
	};
	let r = structuredClone(e);
	if (r.phase = "resolve", t.type === "choose") {
		let e = r.decision.offers.find((e) => e.option.id === t.id);
		r.decision = null, F(r, ...e.jobs);
	} else {
		let e = r.agenda.shift();
		if (!(Ue(r, e) || Oe(r, e) || je(r, e) || ve(r, e))) throw Error(`Unknown Waterdeep operation: ${e.op}`);
	}
	let i = r.last !== null && r.log.length > e.log.length && r.last.kind !== "deploy" ? [{
		kind: r.last.kind,
		rid: r.last.rid,
		data: { ...r.last }
	}] : [], a = new Map(e.spaces.flatMap((e) => e.occupants.map((t) => [t.agent, {
		...t,
		space: e.id
	}]))), o = new Map(r.spaces.flatMap((e) => e.occupants.map((t) => [t.agent, {
		...t,
		space: e.id
	}])));
	for (let e of /* @__PURE__ */ new Set([...a.keys(), ...o.keys()])) {
		let t = a.get(e), n = o.get(e), r = (n ?? t).rid;
		t?.space !== n?.space && i.push({
			kind: "agentMove",
			rid: r,
			data: {
				from: t?.space ?? null,
				to: n?.space ?? null,
				ambassador: e === "ambassador"
			},
			...i.length ? { with: !0 } : {}
		});
	}
	for (let t of r.players) {
		let n = M(e, t.rid), a = n.resources;
		t.hand.length !== n.hand.length && !(r.last?.kind === "play" && r.log.length > e.log.length && r.last.rid === t.rid) && i.push({
			kind: t.hand.length > n.hand.length ? "drawIntrigue" : "discardIntrigue",
			rid: t.rid,
			data: { n: Math.abs(t.hand.length - n.hand.length) },
			...i.length ? { with: !0 } : {}
		});
		let o = se.filter((e) => t.resources[e] !== a[e]).map((e) => `${e}${t.resources[e] - a[e]}`).join("");
		o && i.push({
			kind: "resources",
			rid: t.rid,
			data: { change: o },
			...i.length ? { with: !0 } : {}
		});
	}
	return r.beat = i.length ? 360 : 0, {
		state: r,
		fx: i
	};
}
function Ke(e, t) {
	let n = e.players.find((e) => e.rid === t);
	return {
		public: {
			config: e.config,
			round: e.round,
			phase: e.phase,
			first: e.first,
			active: e.active,
			mode: e.mode,
			players: e.players.map((t) => ({
				rid: t.rid,
				resources: t.resources,
				agents: t.agents,
				quests: t.quests,
				completed: t.completed,
				intrigueCount: t.hand.length,
				lord: t.revealed || e.phase === "done" ? t.lord : null,
				revealed: t.revealed,
				lieutenant: t.lieutenant
			})),
			spaces: e.spaces,
			buildings: e.buildings,
			marketQuests: e.marketQuests,
			marketBuildings: e.marketBuildings,
			corruption: e.corruption,
			supply: e.supply,
			removedCorruption: e.removedCorruption,
			pending: e.decision ? {
				rid: e.decision.rid,
				kind: e.decision.kind
			} : null,
			last: e.last,
			log: e.log,
			final: e.final
		},
		private: {
			hand: n?.hand ?? [],
			lord: n?.lord ?? null,
			choices: e.decision?.rid === t ? e.decision.offers.map((e) => e.option) : [],
			seenLords: n?.seenLords ?? []
		}
	};
}
function qe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.final.find((e) => e.rid === n.rid).total - e.final.find((e) => e.rid === t.rid).total || n.resources.g - t.resources.g).map((e) => e.rid), n = e.final.find((e) => e.rid === t[0]).total, r = M(e, t[0]).resources.g;
	return {
		phase: "done",
		ranking: t,
		winner: t.filter((t) => e.final.find((e) => e.rid === t).total === n && M(e, t).resources.g === r),
		scores: Object.fromEntries(e.final.map((e) => [e.rid, e.total]))
	};
}
var Je = {
	meta: ke,
	schemas: {
		action: Ne,
		publicView: Le,
		privateView: Re,
		config: Me
	},
	saveCompatibility: { version: "1" },
	setup: ze,
	reduce: Ge,
	viewFor: Ke,
	status: qe,
	nextTickIn: (e) => e.phase !== "done" && !e.decision && e.agenda.length ? e.beat : null
}, Ye = {
	c: "games.waterdeep.c",
	f: "games.waterdeep.f",
	r: "games.waterdeep.r",
	w: "games.waterdeep.w",
	g: "games.waterdeep.g",
	v: "games.waterdeep.v",
	x: "games.waterdeep.x",
	a: "games.waterdeep.a",
	i: "games.waterdeep.i"
}, Xe = {
	arcana: "games.waterdeep.arcana",
	commerce: "games.waterdeep.commerce",
	piety: "games.waterdeep.piety",
	skullduggery: "games.waterdeep.skullduggery",
	warfare: "games.waterdeep.warfare",
	mandatory: "games.waterdeep.mandatory"
}, Ze = {
	field: {
		name: "games.waterdeep.sfield",
		text: "games.waterdeep.sfieldDesc",
		gain: "f2"
	},
	lion: {
		name: "games.waterdeep.slion",
		text: "games.waterdeep.slionDesc",
		gain: "r2"
	},
	tower: {
		name: "games.waterdeep.stower",
		text: "games.waterdeep.stowerDesc",
		gain: "w1"
	},
	plinth: {
		name: "games.waterdeep.splinth",
		text: "games.waterdeep.splinthDesc",
		gain: "c1"
	},
	aurora: {
		name: "games.waterdeep.saurora",
		text: "games.waterdeep.sauroraDesc",
		gain: "g4"
	},
	castle: {
		name: "games.waterdeep.scastle",
		text: "games.waterdeep.scastleDesc",
		gain: "i1"
	},
	builders: {
		name: "games.waterdeep.sbuilders",
		text: "games.waterdeep.sbuildersDesc",
		gain: ""
	},
	"cliff-gold": {
		name: "games.waterdeep.scliff_gold",
		text: "games.waterdeep.scliff_goldDesc",
		gain: "g2"
	},
	"cliff-card": {
		name: "games.waterdeep.scliff_card",
		text: "games.waterdeep.scliff_cardDesc",
		gain: "i1"
	},
	"cliff-reset": {
		name: "games.waterdeep.scliff_reset",
		text: "games.waterdeep.scliff_resetDesc",
		gain: ""
	},
	"harbor-0": {
		name: "games.waterdeep.sharbor_0",
		text: "games.waterdeep.sharbor_0Desc",
		gain: ""
	},
	"harbor-1": {
		name: "games.waterdeep.sharbor_1",
		text: "games.waterdeep.sharbor_1Desc",
		gain: ""
	},
	"harbor-2": {
		name: "games.waterdeep.sharbor_2",
		text: "games.waterdeep.sharbor_2Desc",
		gain: ""
	},
	grim: {
		name: "games.waterdeep.sgrim",
		text: "games.waterdeep.sgrimDesc",
		gain: "i2"
	},
	entry: {
		name: "games.waterdeep.sentry",
		text: "games.waterdeep.sentryDesc",
		gain: ""
	},
	mirrors: {
		name: "games.waterdeep.smirrors",
		text: "games.waterdeep.smirrorsDesc",
		gain: "a1"
	},
	island: {
		name: "games.waterdeep.sisland",
		text: "games.waterdeep.sislandDesc",
		gain: "a2x1"
	},
	voice: {
		name: "games.waterdeep.svoice",
		text: "games.waterdeep.svoiceDesc",
		gain: "g5i1x1"
	},
	slavers: {
		name: "games.waterdeep.sslavers",
		text: "games.waterdeep.sslaversDesc",
		gain: "f2r2x1"
	}
}, Qe = {
	deploy: "games.waterdeep.act_deploy",
	copy: "games.waterdeep.act_copy",
	build: "games.waterdeep.act_build",
	takeQuest: "games.waterdeep.act_takeQuest",
	complete: "games.waterdeep.act_complete",
	play: "games.waterdeep.act_play",
	resource: "games.waterdeep.act_resource",
	payResource: "games.waterdeep.act_payResource",
	gain: "games.waterdeep.act_gain",
	trade: "games.waterdeep.act_trade",
	opponent: "games.waterdeep.act_opponent",
	placeResource: "games.waterdeep.act_placeResource",
	returnCorruption: "games.waterdeep.act_returnCorruption",
	removeCorruption: "games.waterdeep.act_removeCorruption",
	recall: "games.waterdeep.act_recall",
	discardQuest: "games.waterdeep.act_discardQuest",
	discardIntrigue: "games.waterdeep.act_discardIntrigue",
	sample: "games.waterdeep.act_sample",
	foist: "games.waterdeep.act_foist",
	stealBuilding: "games.waterdeep.act_stealBuilding",
	steal: "games.waterdeep.act_steal",
	tribute: "games.waterdeep.act_tribute",
	questType: "games.waterdeep.act_questType",
	demolish: "games.waterdeep.act_demolish",
	moveAgent: "games.waterdeep.act_moveAgent",
	useSpace: "games.waterdeep.act_useSpace",
	extraHarbor: "games.waterdeep.act_extraHarbor",
	placeExtraMenu: "games.waterdeep.act_placeExtraMenu",
	skip: "games.waterdeep.act_skip",
	optional: "games.waterdeep.act_optional"
}, $e = {
	deploy: "games.waterdeep.prompt_deploy",
	quest: "games.waterdeep.prompt_quest",
	build: "games.waterdeep.prompt_build",
	complete: "games.waterdeep.prompt_complete",
	play: "games.waterdeep.prompt_play",
	resource: "games.waterdeep.prompt_resource",
	payAny: "games.waterdeep.prompt_payAny",
	loseAny: "games.waterdeep.prompt_loseAny",
	trade: "games.waterdeep.prompt_trade",
	returnCorruption: "games.waterdeep.prompt_returnCorruption",
	removeCorruption: "games.waterdeep.prompt_removeCorruption",
	placeResource: "games.waterdeep.prompt_placeResource",
	recall: "games.waterdeep.prompt_recall",
	opponent: "games.waterdeep.prompt_opponent",
	copy: "games.waterdeep.prompt_copy",
	discardQuest: "games.waterdeep.prompt_discardQuest",
	discardIntrigue: "games.waterdeep.prompt_discardIntrigue",
	stealBuilding: "games.waterdeep.prompt_stealBuilding",
	foist: "games.waterdeep.prompt_foist",
	steal: "games.waterdeep.prompt_steal",
	tribute: "games.waterdeep.prompt_tribute",
	questType: "games.waterdeep.prompt_questType",
	sample: "games.waterdeep.prompt_sample",
	demolish: "games.waterdeep.prompt_demolish",
	moveAgent: "games.waterdeep.prompt_moveAgent",
	optional: "games.waterdeep.prompt_optional",
	recover: "games.waterdeep.prompt_recover"
}, et = (e) => e < 1400 ? A(e) : e < 1600 ? O(e) : e < 1800 || e >= 2e3 ? D(e) : k(e), tt = (e, t) => /^[bm]\d+$/.test(e) ? t(O(Number(e.slice(1))).nameKey) : t(Ze[e]?.name ?? "games.waterdeep.choose");
function nt(e, t, n) {
	return [
		t(Qe[e.kind] ?? "games.waterdeep.choose"),
		e.card ? t(et(e.card).nameKey) : e.space ? tt(e.space, t) : e.resource ? t(Ye[e.resource]) : e.detail && e.detail in Xe ? t(Xe[e.detail]) : "",
		e.rid ? n(e.rid) : "",
		e.amount === void 0 ? "" : String(e.amount)
	].filter(Boolean).join(" · ");
}
function rt(e, t) {
	let n = A(e);
	return n.types.length ? t("games.waterdeep.lordPair", { types: n.types.map((e) => t(Xe[e])).join(" / ") }) : e === 1305 ? t("games.waterdeep.lordBuildings") : e === 1311 ? t("games.waterdeep.lordAll") : e === 1312 || e === 1315 ? t("games.waterdeep.lordModule", { module: t(e === 1312 ? "games.waterdeep.undermountain" : "games.waterdeep.skullport") }) : t(e === 1313 ? "games.waterdeep.lordLarge" : e === 1314 ? "games.waterdeep.lordType" : "games.waterdeep.lordCorruption");
}
function it(e, t, n) {
	return t({
		deploy: "games.waterdeep.logDeploy",
		takeQuest: "games.waterdeep.logTake",
		complete: "games.waterdeep.logComplete",
		play: "games.waterdeep.logPlay",
		build: "games.waterdeep.logBuild",
		discardQuest: "games.waterdeep.logDiscard",
		demolish: "games.waterdeep.logDiscard",
		round: "games.waterdeep.logRound",
		finish: "games.waterdeep.logFinish"
	}[e.kind] ?? "games.waterdeep.resolving", {
		name: n(e.rid),
		card: e.card ? t(et(e.card).nameKey) : "",
		place: e.space ? tt(e.space, t) : ""
	});
}
//#endregion
//#region src/games/waterdeep/art.tsx
var at = (e) => te(`games/waterdeep/${e}.svg`), ot = {
	c: [
		"#efeee0",
		"#e3e1cb",
		"#faf9ed"
	],
	f: [
		"#e89a23",
		"#cf7b13",
		"#f2af37"
	],
	r: [
		"#191b17",
		"#0d100e",
		"#33372c"
	],
	w: [
		"#8546a5",
		"#6d338f",
		"#9b5bb6"
	]
};
function Y({ type: e }) {
	let t = p(), n = ot[e];
	return /* @__PURE__ */ b("svg", {
		className: "waterdeep-resource-icon",
		viewBox: "0 0 32 32",
		role: "img",
		"aria-label": t(Ye[e] ?? "games.waterdeep.a"),
		children: n ? /* @__PURE__ */ x("g", {
			stroke: e === "r" ? "#e6e1c6" : "#574936",
			strokeWidth: "1.1",
			strokeLinejoin: "round",
			children: [
				/* @__PURE__ */ b("path", {
					d: "M3 8 16 1 29 8 16 15Z",
					fill: n[2]
				}),
				/* @__PURE__ */ b("path", {
					d: "M3 8 16 15V30L3 23Z",
					fill: n[0]
				}),
				/* @__PURE__ */ b("path", {
					d: "M16 15 29 8V23L16 30Z",
					fill: n[1]
				})
			]
		}) : e === "g" ? /* @__PURE__ */ x("g", {
			stroke: "#5e4d25",
			children: [/* @__PURE__ */ b("rect", {
				x: "2",
				y: "2",
				width: "28",
				height: "28",
				rx: "2",
				fill: "#ead875"
			}), /* @__PURE__ */ b("circle", {
				cx: "16",
				cy: "16",
				r: "5",
				fill: "#f5efcf"
			})]
		}) : e === "v" ? /* @__PURE__ */ b("path", {
			d: "m9 2 16 0 7 14-8 14H8L1 16Z",
			fill: "#b22131",
			stroke: "#ecd5b0",
			strokeWidth: "2"
		}) : e === "x" ? /* @__PURE__ */ b("path", {
			d: "M7.77,8.94 4.87,12.47 4.87,16.0 5.84,16.88 5.84,18.65 6.81,19.53 6.81,20.41 7.77,20.41 8.74,21.29 12.61,21.29 13.58,22.18 12.61,23.06 13.58,22.18 14.55,22.18 16.48,24.82 20.35,24.82 21.32,25.71 24.23,25.71 25.19,24.82 25.19,22.18 24.23,21.29 24.23,16.88 23.26,16.0 23.26,10.71 20.35,8.06 19.39,8.06 18.42,7.18 13.58,7.18 12.61,8.06Z",
			fill: "#238baa",
			stroke: "#375757"
		}) : e === "i" ? /* @__PURE__ */ x("g", {
			stroke: "#a78b47",
			children: [
				/* @__PURE__ */ b("path", {
					d: "M5 1H27V31H5Z",
					fill: "#af5d27",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ b("path", {
					d: "M9 4H23V28H9Z",
					fill: "#e5bd58"
				}),
				/* @__PURE__ */ b("path", {
					d: "M11 6H21V9H18V24H21V27H11V24H14V9H11Z",
					fill: "#fff6dd"
				})
			]
		}) : /* @__PURE__ */ x("g", {
			stroke: "#5e4d37",
			fill: "#f4f1e5",
			children: [
				/* @__PURE__ */ b("path", { d: "M3 8 16 1 29 8V23L16 30 3 23Z" }),
				/* @__PURE__ */ b("path", {
					d: "M3 8 16 15 29 8M16 15V30",
					fill: "none"
				}),
				/* @__PURE__ */ b("path", {
					d: "M10 10C11 4 23 3 23 10C23 16 15 16 16 23H14C11 17 19 13 19 10C19 6 14 7 10 10Z",
					stroke: "#f4f1e5",
					strokeWidth: "1.6",
					fill: "#24221d",
					paintOrder: "stroke"
				}),
				/* @__PURE__ */ b("path", {
					d: "m16 24 3 3-3 3-3-3Z",
					stroke: "none",
					fill: "#24221d"
				})
			]
		})
	});
}
function X({ text: e, className: t = "" }) {
	let n = p(), r = V(e);
	return e.includes("/") ? /* @__PURE__ */ b("span", {
		className: `waterdeep-resource-row ${t}`,
		children: e.split("/").map((e, t) => /* @__PURE__ */ x("span", {
			className: "waterdeep-resource-alternative",
			children: [t > 0 && /* @__PURE__ */ b("small", { children: n("games.waterdeep.or") }), /* @__PURE__ */ b(X, { text: e })]
		}, t))
	}) : /* @__PURE__ */ b("span", {
		className: `waterdeep-resource-row ${t}`,
		children: Object.entries(r).filter(([, e]) => e).map(([e, t]) => /* @__PURE__ */ x("span", {
			className: "waterdeep-resource",
			children: [/* @__PURE__ */ b(Y, { type: e }), /* @__PURE__ */ b("b", { children: t })]
		}, e))
	});
}
function st({ color: e = "#f5ebce", ambassador: t = !1 }) {
	return /* @__PURE__ */ b("svg", {
		className: "waterdeep-agent",
		viewBox: "0 0 38 52",
		"aria-hidden": !0,
		children: /* @__PURE__ */ b("path", {
			d: "M13 16A8 8 0 1 1 25 16L28 17 34 33 30 34 37 51H27A8 7 0 0 0 11 51H1L8 34 4 33 10 17Z",
			fill: t ? "#f5f0de" : e,
			stroke: "#4d3a24",
			strokeWidth: "1.4",
			strokeLinejoin: "round"
		})
	});
}
function ct() {
	return /* @__PURE__ */ b("svg", {
		viewBox: "0 0 32 52",
		width: "16",
		height: "26",
		"aria-hidden": !0,
		children: /* @__PURE__ */ b("path", {
			d: "M5 1H10V6H14V1H19V6H23V1H28V13L25 17V43L30 47V51H2V47L7 43V17L5 13Z",
			fill: "#f0ddb0",
			stroke: "#654c29",
			strokeWidth: "1.4"
		})
	});
}
function lt() {
	return /* @__PURE__ */ x("svg", {
		className: "waterdeep-target",
		preserveAspectRatio: "none",
		viewBox: "0 0 100 100",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ b("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "96",
			rx: "5",
			fill: "none",
			stroke: "#f9f6d3",
			strokeWidth: "2",
			vectorEffect: "non-scaling-stroke"
		}), /* @__PURE__ */ b("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "96",
			rx: "5",
			fill: "none",
			stroke: "#227291",
			strokeWidth: "2",
			strokeDasharray: "7 5",
			vectorEffect: "non-scaling-stroke",
			children: /* @__PURE__ */ b("animate", {
				attributeName: "stroke-dashoffset",
				values: "0;-24",
				dur: "1.2s",
				repeatCount: "indefinite"
			})
		})]
	});
}
function Z() {
	return /* @__PURE__ */ x("svg", {
		className: "waterdeep-seal",
		viewBox: "0 0 100 100",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ b("circle", {
				cx: "50",
				cy: "50",
				r: "47",
				fill: "#334f5d",
				stroke: "#c6a45d",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ b("circle", {
				cx: "50",
				cy: "50",
				r: "38",
				fill: "none",
				stroke: "#c6a45d"
			}),
			/* @__PURE__ */ b("path", {
				d: "M26 72V39L35 35V26L43 23V39H57V23L65 26V35L74 39V72H59V56Q50 44 41 56V72Z",
				fill: "#e5cf8d"
			}),
			/* @__PURE__ */ b("path", {
				d: "M19 77H81M23 81H77",
				stroke: "#e5cf8d",
				strokeWidth: "2"
			})
		]
	});
}
//#endregion
//#region src/games/waterdeep/card.tsx
function Q({ id: e, choices: t = [], selected: i = !1, choose: a, inspect: c, full: l = !1, anchor: d = !0 }) {
	let f = p(), m = et(e), h = e < 1400, g = e >= 1500 && e < 1600, _ = !h && !g && (e < 1800 || e >= 2e3) ? D(e) : null, v = g ? O(e) : null, ee = !h && !g && !_ ? k(e) : null, { ref: te, hidden: S } = o(d ? `waterdeep-card:${e}` : `waterdeep-detail:${e}`), C = s(), w = r(null), ne = n((t) => {
		if (!t && w.current && d) {
			let t = w.current.getBoundingClientRect();
			if (t.width && t.height) {
				let n = {
					x: t.x,
					y: t.y,
					w: t.width,
					h: t.height
				};
				C?.registerProbe(`waterdeep-departure:${e}`, () => n);
			}
		}
		w.current = t, te(t);
	}, [
		d,
		C,
		e,
		te
	]), T = t.length > 0;
	return /* @__PURE__ */ x("div", {
		ref: ne,
		className: `waterdeep-card ${g ? "waterdeep-building-card" : h ? "waterdeep-lord-card" : _ ? "waterdeep-quest-card" : "waterdeep-intrigue-card"}${l ? " waterdeep-card-full" : ""}`,
		"data-type": _?.type,
		"data-available": T,
		"data-selected": i,
		style: { visibility: S ? "hidden" : void 0 },
		children: [/* @__PURE__ */ x("button", {
			className: "waterdeep-card-face",
			onClick: () => T && a ? a(t) : c?.(e),
			"aria-label": f(m.nameKey),
			children: [
				/* @__PURE__ */ x("header", { children: [
					_ && /* @__PURE__ */ b("span", {
						className: "waterdeep-type",
						children: f(Xe[_.type])
					}),
					_?.plot && /* @__PURE__ */ b("small", { children: f("games.waterdeep.plot") }),
					v && /* @__PURE__ */ b(X, { text: `g${v.cost}` }),
					/* @__PURE__ */ b("strong", { children: f(m.nameKey) })
				] }),
				/* @__PURE__ */ x("div", {
					className: "waterdeep-card-content",
					children: [!g && e < 2e3 && /* @__PURE__ */ b("div", {
						className: "waterdeep-illustration",
						children: /* @__PURE__ */ b("img", {
							src: at(`card-${e}`),
							alt: "",
							loading: "lazy"
						})
					}), /* @__PURE__ */ x("div", {
						className: "waterdeep-card-reading",
						children: [
							_ && /* @__PURE__ */ x(y, { children: [
								/* @__PURE__ */ b("span", {
									className: "waterdeep-card-label",
									children: f("games.waterdeep.cost")
								}),
								/* @__PURE__ */ b(X, { text: _.cost }),
								/* @__PURE__ */ b("span", {
									className: "waterdeep-card-label",
									children: f("games.waterdeep.reward")
								}),
								/* @__PURE__ */ b(X, { text: _.reward })
							] }),
							v && /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("div", {
								className: "waterdeep-building-emblem",
								children: /* @__PURE__ */ b(Z, {})
							}), v.action.split(";").filter((e) => /^[cfrwgvxai]\d/.test(e) && !e.includes("-")).map((e, t) => /* @__PURE__ */ b(X, { text: e }, t))] }),
							(l || g || ee) && /* @__PURE__ */ b("p", { children: h ? rt(e, f) : "textKey" in m ? f(m.textKey) : "" })
						]
					})]
				}),
				v && /* @__PURE__ */ x("footer", { children: [/* @__PURE__ */ b("span", { children: f("games.waterdeep.ownerBenefit") }), /* @__PURE__ */ b(X, { text: v.owner })] }),
				T && /* @__PURE__ */ b(lt, {})
			]
		}), c && /* @__PURE__ */ b("button", {
			className: "waterdeep-card-info",
			onClick: () => c(e),
			"aria-label": f("games.waterdeep.details"),
			children: /* @__PURE__ */ b(u, { size: 17 })
		})]
	});
}
//#endregion
//#region src/games/waterdeep/view-player.tsx
var ut = (e, t) => m[e.find((e) => e.rid === t)?.colorIndex ?? 0].hex, dt = (e) => se.filter((t) => e[t]).map((t) => `${t}${e[t]}`).join("");
function ft({ space: e, members: t, nameOf: n }) {
	let { ref: r, hidden: i } = o(e ? `waterdeep-arrival:${e.id}` : null);
	return /* @__PURE__ */ b("span", {
		ref: r,
		className: "waterdeep-building-agents",
		style: { visibility: i ? "hidden" : void 0 },
		children: e?.occupants.map((e) => /* @__PURE__ */ x("span", { children: [/* @__PURE__ */ b(st, {
			color: ut(t, e.rid),
			ambassador: e.agent === "ambassador"
		}), n(e.rid)] }, e.agent))
	});
}
function pt({ p: e, member: t, name: n, color: r, active: i, first: a, choices: s, select: l, inspect: u }) {
	let d = p(), { ref: f } = o(`waterdeep-seat:${e.rid}`);
	return /* @__PURE__ */ x("div", {
		ref: f,
		className: "waterdeep-player",
		"data-active": i,
		style: { "--waterdeep-player": r },
		children: [/* @__PURE__ */ x("button", {
			className: "waterdeep-player-name",
			onClick: () => s.length ? l(s) : u(),
			children: [
				/* @__PURE__ */ x("span", {
					className: "waterdeep-player-crest",
					children: [/* @__PURE__ */ b(st, { color: r }), a && /* @__PURE__ */ b("span", {
						"aria-label": d("games.waterdeep.first"),
						children: /* @__PURE__ */ b(ct, {})
					})]
				}),
				/* @__PURE__ */ b("strong", { children: n }),
				/* @__PURE__ */ x("span", {
					className: "waterdeep-player-vp",
					children: [/* @__PURE__ */ b(Y, { type: "v" }), /* @__PURE__ */ b(c, { value: e.resources.v })]
				}),
				s.length > 0 && /* @__PURE__ */ b(lt, {})
			]
		}), /* @__PURE__ */ x("div", {
			className: "waterdeep-player-counts",
			children: [
				/* @__PURE__ */ x("span", {
					title: d("games.waterdeep.agents"),
					children: [/* @__PURE__ */ b(st, { color: r }), e.agents]
				}),
				/* @__PURE__ */ x("span", {
					title: d("games.waterdeep.quests"),
					children: ["▤ ", e.quests.length]
				}),
				/* @__PURE__ */ x("span", {
					title: d("games.waterdeep.intrigues"),
					children: [/* @__PURE__ */ b(Y, { type: "i" }), e.intrigueCount]
				}),
				t?.autopilot && /* @__PURE__ */ b("span", { children: d("lobby.bot") })
			]
		})]
	});
}
function mt({ id: e, pub: t, members: n, options: r, choose: i, nameOf: a, describe: s }) {
	let c = p(), l = t.spaces.find((t) => t.id === e), d = Ze[e], { ref: f } = o(`waterdeep-space:${e}`), { ref: m, hidden: h } = o(`waterdeep-arrival:${e}`);
	return /* @__PURE__ */ x("div", {
		ref: f,
		className: "waterdeep-location",
		"data-harbor": e.startsWith("harbor-"),
		"data-available": r.length > 0,
		"data-occupied": l.occupants.length > 0,
		children: [/* @__PURE__ */ x("button", {
			className: "waterdeep-location-face",
			onClick: () => r.length ? i(r) : s(e),
			"aria-label": tt(e, c),
			children: [
				/* @__PURE__ */ b("span", {
					ref: m,
					className: "waterdeep-agent-slot",
					style: { visibility: h ? "hidden" : void 0 },
					children: l.occupants.length ? l.occupants.map((e) => /* @__PURE__ */ x("span", {
						className: "waterdeep-placed-agent",
						title: a(e.rid),
						children: [/* @__PURE__ */ b(st, {
							color: ut(n, e.rid),
							ambassador: e.agent === "ambassador"
						}), /* @__PURE__ */ b("small", { children: a(e.rid) })]
					}, e.agent)) : /* @__PURE__ */ b(st, {})
				}),
				/* @__PURE__ */ x("span", {
					className: "waterdeep-location-label",
					children: [/* @__PURE__ */ b("strong", { children: c(d.name) }), d.gain ? /* @__PURE__ */ b(X, { text: d.gain }) : /* @__PURE__ */ b("span", {
						className: "waterdeep-location-symbol",
						children: e === "builders" ? "⌂" : e.startsWith("harbor-") ? /* @__PURE__ */ b(Y, { type: "i" }) : "▤"
					})]
				}),
				dt(l.extras) && /* @__PURE__ */ b("span", {
					className: "waterdeep-extra",
					children: /* @__PURE__ */ b(X, { text: dt(l.extras) })
				}),
				r.length > 0 && /* @__PURE__ */ b(lt, {})
			]
		}), /* @__PURE__ */ b("button", {
			className: "waterdeep-space-info",
			"aria-label": c("games.waterdeep.details"),
			onClick: () => s(e),
			children: /* @__PURE__ */ b(u, { size: 15 })
		})]
	});
}
function ht(e) {
	return g(), /* @__PURE__ */ b(gt, {
		...e,
		pub: e.public,
		priv: e.private ?? {
			hand: [],
			lord: null,
			choices: [],
			seenLords: []
		}
	});
}
function gt({ pub: e, priv: t, members: n, myRid: r, send: s }) {
	let l = p(), u = f((e) => e.locale), m = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? ee(t, u) : e;
	}, g = e.players.find((e) => e.rid === r), te = e.pending?.rid === r && e.phase === "play", S = te ? t.choices : [], [C, w] = i(null), [ne, T] = i(null), [E, re] = i(!1), [ie, D] = i(""), O = S.map((e) => e.id).join(",");
	ie !== O && (D(O), T(null));
	let k = (e) => {
		e.length && (w(null), T(e));
	}, A = (e) => S.filter((t) => t.card === e), j = (e) => S.filter((t) => t.space === e && !t.card), M = (e) => S.filter((t) => t.rid === e && !t.card && !t.space), N = /* @__PURE__ */ new Set([
		"deploy",
		"copy",
		"placeResource",
		"recall",
		"moveAgent",
		"useSpace",
		"build",
		"sample",
		"takeQuest",
		"complete",
		"play",
		"discardQuest",
		"discardIntrigue",
		"stealBuilding",
		"demolish",
		"foist",
		"opponent",
		"steal"
	]), ae = S.filter((e) => !N.has(e.kind)), oe = /* @__PURE__ */ new Set([
		...e.marketQuests,
		...e.marketBuildings.map((e) => e.id),
		...e.buildings.map((e) => e.id),
		...e.players.flatMap((e) => [...e.quests, ...e.completed]),
		...t.hand
	]), P = S.filter((e) => e.card && !oe.has(e.card)).map((e) => e.card), F = e.phase === "done" ? l("games.waterdeep.done") : e.pending ? te ? l($e[e.pending.kind] ?? "games.waterdeep.choose") : l("games.waterdeep.waiting", { name: m(e.pending.rid) }) : l("games.waterdeep.resolving"), [I, L] = i(!1), { ref: R } = o(`waterdeep-quests:${r}`), { ref: z } = o(`waterdeep-completed:${r}`), { ref: B } = o("waterdeep-city"), { ref: V } = o("waterdeep-market"), { ref: ce } = o(`waterdeep-hand:${r}`), { ref: H } = o("waterdeep-building-market"), U = ne?.filter((e) => S.some((t) => t.id === e.id)) ?? [], W = /* @__PURE__ */ x("div", {
		className: "waterdeep-banner",
		children: [
			/* @__PURE__ */ x("div", {
				className: "waterdeep-round",
				children: [/* @__PURE__ */ b(Z, {}), /* @__PURE__ */ b("b", { children: l("games.waterdeep.round", { n: e.round }) })]
			}),
			/* @__PURE__ */ b("div", {
				className: "waterdeep-players",
				children: e.players.map((t) => /* @__PURE__ */ b(pt, {
					p: t,
					member: n.find((e) => e.rid === t.rid),
					name: m(t.rid),
					color: ut(n, t.rid),
					active: e.pending?.rid === t.rid,
					first: e.first === t.rid,
					choices: M(t.rid),
					select: k,
					inspect: () => w({ rid: t.rid })
				}, t.rid))
			}),
			/* @__PURE__ */ b("button", {
				className: "waterdeep-tool",
				"aria-label": l("common.log.title"),
				onClick: () => re(!0),
				children: /* @__PURE__ */ b(d, { size: 20 })
			})
		]
	}), ue = /* @__PURE__ */ x("div", {
		className: "waterdeep-actions",
		children: [/* @__PURE__ */ b("div", {
			className: "waterdeep-prompt",
			"aria-live": "polite",
			children: F
		}), /* @__PURE__ */ b("div", {
			className: "waterdeep-abstract",
			children: ae.map((e) => /* @__PURE__ */ x("button", {
				className: e.kind === "skip" ? "waterdeep-quiet" : "waterdeep-primary",
				onClick: () => e.kind === "skip" ? s({
					type: "choose",
					id: e.id
				}) : k([e]),
				children: [e.kind === "skip" ? l("games.waterdeep.skip") : e.resource ? /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b(Y, { type: e.resource }), e.amount ?? 1] }) : e.amount === void 0 ? nt(e, l, m) : /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b(Y, { type: "x" }), e.amount] }), e.gain && /* @__PURE__ */ b(X, { text: e.gain })]
			}, e.id))
		})]
	});
	return /* @__PURE__ */ x(_, {
		adaptive: !0,
		className: "waterdeep-screen",
		scroll: !1,
		banner: W,
		actions: ue,
		actionsHeight: "waterdeep-actions-height",
		children: [
			/* @__PURE__ */ x("div", {
				className: "waterdeep-table",
				children: [
					/* @__PURE__ */ b(h, {
						kind: "sheen",
						base: "#c9c0a4",
						className: "waterdeep-texture"
					}),
					/* @__PURE__ */ x("main", {
						className: "waterdeep-public-table",
						children: [
							/* @__PURE__ */ x("section", {
								ref: V,
								className: "waterdeep-quest-market",
								children: [/* @__PURE__ */ b("h2", { children: l("games.waterdeep.inn") }), /* @__PURE__ */ b("div", {
									className: "waterdeep-market-quests",
									children: e.marketQuests.map((e) => /* @__PURE__ */ b(Q, {
										id: e,
										choices: A(e),
										choose: k,
										inspect: (e) => w({ card: e })
									}, e))
								})]
							}),
							/* @__PURE__ */ x("section", {
								ref: B,
								className: "waterdeep-city",
								style: { backgroundImage: `url("${at("city")}")` },
								children: [
									/* @__PURE__ */ x("div", {
										className: "waterdeep-city-heading",
										children: [/* @__PURE__ */ b(Z, {}), /* @__PURE__ */ b("strong", { children: l("games.waterdeep.name") })]
									}),
									/* @__PURE__ */ b("div", {
										className: "waterdeep-city-locations",
										children: e.spaces.filter((e) => !/^[bm]\d+$/.test(e.id) && !e.id.startsWith("harbor-") && ![
											"grim",
											"entry",
											"mirrors",
											"island",
											"voice",
											"slavers"
										].includes(e.id)).map((t) => /* @__PURE__ */ b(mt, {
											id: t.id,
											pub: e,
											members: n,
											options: j(t.id),
											choose: k,
											nameOf: m,
											describe: (e) => w({ space: e })
										}, t.id))
									}),
									/* @__PURE__ */ b("div", {
										className: "waterdeep-expansion-locations",
										children: e.spaces.filter((e) => [
											"grim",
											"entry",
											"mirrors",
											"island",
											"voice",
											"slavers"
										].includes(e.id)).map((t) => /* @__PURE__ */ b(mt, {
											id: t.id,
											pub: e,
											members: n,
											options: j(t.id),
											choose: k,
											nameOf: m,
											describe: (e) => w({ space: e })
										}, t.id))
									}),
									/* @__PURE__ */ b("div", {
										className: "waterdeep-harbor",
										children: e.spaces.filter((e) => e.id.startsWith("harbor-")).map((t) => /* @__PURE__ */ b(mt, {
											id: t.id,
											pub: e,
											members: n,
											options: j(t.id),
											choose: k,
											nameOf: m,
											describe: (e) => w({ space: e })
										}, t.id))
									})
								]
							}),
							e.config.skullport && /* @__PURE__ */ x("section", {
								className: "waterdeep-corruption",
								children: [
									/* @__PURE__ */ b(Y, { type: "x" }),
									/* @__PURE__ */ b("span", { children: l("games.waterdeep.corruptionValue", { n: le(e) }) }),
									/* @__PURE__ */ b("div", { children: e.corruption.map((e, t) => /* @__PURE__ */ x("span", {
										"data-empty": !e,
										children: [/* @__PURE__ */ x("b", { children: ["−", t + 1] }), /* @__PURE__ */ b("small", { children: "●".repeat(e) || "—" })]
									}, t)) })
								]
							}),
							/* @__PURE__ */ x("section", {
								className: "waterdeep-buildings",
								children: [
									/* @__PURE__ */ b("h2", { children: l("games.waterdeep.market") }),
									/* @__PURE__ */ b("div", {
										ref: H,
										className: "waterdeep-building-market",
										children: e.marketBuildings.map((t) => /* @__PURE__ */ x("div", {
											className: "waterdeep-building-slot",
											children: [/* @__PURE__ */ b(Q, {
												id: t.id,
												choices: A(t.id),
												choose: k,
												inspect: (e) => w({ card: e })
											}), /* @__PURE__ */ x("span", {
												className: "waterdeep-building-points",
												children: [/* @__PURE__ */ b(X, { text: `v${t.vp}` }), /* @__PURE__ */ b(ft, {
													space: e.spaces.find((e) => e.id === `m${t.id}`),
													members: n,
													nameOf: m
												})]
											})]
										}, t.id))
									}),
									/* @__PURE__ */ b("div", {
										className: "waterdeep-owned-buildings",
										children: e.buildings.map((t) => {
											let r = e.spaces.find((e) => e.id === `b${t.id}`);
											return /* @__PURE__ */ x("div", {
												className: "waterdeep-owned-building",
												children: [
													/* @__PURE__ */ b("div", {
														className: "waterdeep-owner-label",
														style: { borderColor: ut(n, t.owner) },
														children: m(t.owner)
													}),
													/* @__PURE__ */ b(Q, {
														id: t.id,
														choices: [...A(t.id), ...j(r.id)],
														choose: k,
														inspect: (e) => w({ card: e })
													}),
													/* @__PURE__ */ x("div", {
														className: "waterdeep-building-stock",
														children: [
															/* @__PURE__ */ b(X, { text: dt(t.stock) }),
															/* @__PURE__ */ b(ft, {
																space: r,
																members: n,
																nameOf: m
															}),
															/* @__PURE__ */ b(X, { text: dt(r.extras) })
														]
													})
												]
											}, t.id);
										})
									})
								]
							})
						]
					}),
					/* @__PURE__ */ x("aside", {
						className: "waterdeep-tavern",
						children: [
							/* @__PURE__ */ x("header", {
								className: "waterdeep-tavern-heading",
								children: [/* @__PURE__ */ b("h2", { children: l("games.waterdeep.seat", { name: m(r) }) }), t.lord && /* @__PURE__ */ x("button", {
									className: "waterdeep-lord-medal",
									onClick: () => w({ card: t.lord }),
									children: [/* @__PURE__ */ b(Z, {}), l("games.waterdeep.lord")]
								})]
							}),
							g && /* @__PURE__ */ x("div", {
								className: "waterdeep-tavern-resources",
								children: [se.filter((t) => t !== "v" && (t !== "x" || e.config.skullport)).map((e) => /* @__PURE__ */ x("span", {
									"aria-label": l(Ye[e]),
									children: [/* @__PURE__ */ b(Y, { type: e }), /* @__PURE__ */ b(c, { value: g.resources[e] })]
								}, e)), /* @__PURE__ */ x("span", {
									className: "waterdeep-tavern-agents",
									children: [/* @__PURE__ */ b(st, { color: ut(n, r) }), /* @__PURE__ */ b("b", { children: g.agents })]
								})]
							}),
							/* @__PURE__ */ x("section", {
								ref: R,
								className: "waterdeep-active-quests",
								children: [/* @__PURE__ */ x("h2", { children: [l("games.waterdeep.quests"), /* @__PURE__ */ b("span", { children: g?.quests.length ?? 0 })] }), /* @__PURE__ */ x("div", { children: [g?.quests.map((e) => /* @__PURE__ */ b(Q, {
									id: e,
									choices: A(e),
									choose: k,
									inspect: (e) => w({ card: e })
								}, e)), !g?.quests.length && /* @__PURE__ */ b("p", { children: l("games.waterdeep.emptyQuests") })] })]
							}),
							/* @__PURE__ */ x("section", {
								ref: ce,
								className: "waterdeep-hand",
								children: [/* @__PURE__ */ x("h2", { children: [l("games.waterdeep.intrigues"), /* @__PURE__ */ b("span", { children: t.hand.length })] }), /* @__PURE__ */ x("div", { children: [t.hand.map((e) => /* @__PURE__ */ b(Q, {
									id: e,
									choices: A(e),
									choose: k,
									inspect: (e) => w({ card: e })
								}, e)), !t.hand.length && /* @__PURE__ */ b("p", { children: l("games.waterdeep.emptyHand") })] })]
							}),
							/* @__PURE__ */ x("section", {
								ref: z,
								className: "waterdeep-completed",
								children: [/* @__PURE__ */ x("button", {
									className: "waterdeep-quiet",
									onClick: () => L(!I),
									children: [
										l("games.waterdeep.completed"),
										" · ",
										g?.completed.length ?? 0
									]
								}), I && g?.completed.map((e) => /* @__PURE__ */ b(Q, {
									id: e,
									inspect: (e) => w({ card: e })
								}, e))]
							}),
							!!t.seenLords.length && /* @__PURE__ */ x("section", { children: [/* @__PURE__ */ b("h2", { children: l("games.waterdeep.seenLords") }), t.seenLords.map((e) => /* @__PURE__ */ b("button", {
								className: "waterdeep-quiet",
								onClick: () => w({ card: e.lord }),
								children: m(e.rid)
							}, e.rid))] })
						]
					})
				]
			}),
			/* @__PURE__ */ b(a, {
				open: !!C,
				onClose: () => w(null),
				label: l("games.waterdeep.details"),
				title: C?.card ? l(et(C.card).nameKey) : C?.space ? tt(C.space, l) : C?.rid ? m(C.rid) : "",
				tall: !0,
				children: /* @__PURE__ */ x("div", {
					className: "waterdeep-detail",
					children: [
						C?.card && /* @__PURE__ */ b(Q, {
							id: C.card,
							full: !0,
							anchor: !1
						}),
						C?.space && /* @__PURE__ */ b("p", { children: l(Ze[C.space].text) }),
						C?.rid && e.players.filter((e) => e.rid === C.rid).map((e) => /* @__PURE__ */ x("div", { children: [
							/* @__PURE__ */ b(X, { text: dt(e.resources) }),
							e.lord && /* @__PURE__ */ b(Q, {
								id: e.lord,
								full: !0,
								anchor: !1
							}),
							/* @__PURE__ */ b("h2", { children: l("games.waterdeep.quests") }),
							e.quests.map((e) => /* @__PURE__ */ b(Q, {
								id: e,
								choices: A(e),
								choose: k,
								inspect: (e) => w({ card: e }),
								anchor: !1
							}, e)),
							/* @__PURE__ */ b("h2", { children: l("games.waterdeep.completed") }),
							e.completed.map((e) => /* @__PURE__ */ b(Q, {
								id: e,
								inspect: (e) => w({ card: e }),
								anchor: !1
							}, e))
						] }, e.rid))
					]
				})
			}),
			/* @__PURE__ */ b(a, {
				open: U.length > 0 || P.length > 0,
				onClose: U.length ? () => T(null) : void 0,
				label: F,
				title: F,
				tall: !0,
				children: /* @__PURE__ */ x("div", {
					className: "waterdeep-choice-panel",
					children: [P.map((e) => /* @__PURE__ */ b(Q, {
						id: e,
						choices: A(e),
						choose: k,
						full: !0
					}, e)), U.map((e) => /* @__PURE__ */ x("div", {
						className: "waterdeep-choice-preview",
						children: [
							e.card ? /* @__PURE__ */ b(Q, {
								id: e.card,
								full: !0,
								anchor: !1
							}) : e.space ? /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("h3", { children: tt(e.space, l) }), Ze[e.space] && /* @__PURE__ */ b("p", { children: l(Ze[e.space].text) })] }) : null,
							e.rid && /* @__PURE__ */ b("strong", { children: m(e.rid) }),
							e.resource && /* @__PURE__ */ b("span", {
								className: "waterdeep-large-token",
								children: /* @__PURE__ */ b(Y, { type: e.resource })
							}),
							e.cost && /* @__PURE__ */ x("p", { children: [l("games.waterdeep.cost"), /* @__PURE__ */ b(X, { text: e.cost })] }),
							e.gain && /* @__PURE__ */ x("p", { children: [l("games.waterdeep.reward"), /* @__PURE__ */ b(X, { text: e.gain })] }),
							/* @__PURE__ */ x("button", {
								className: "waterdeep-primary",
								onClick: () => {
									T(null), s({
										type: "choose",
										id: e.id
									});
								},
								children: [l(Qe[e.kind] ?? "games.waterdeep.confirm"), e.amount === void 0 ? "" : ` · ${e.amount}`]
							})
						]
					}, e.id))]
				})
			}),
			E && /* @__PURE__ */ b(v, {
				log: e.log,
				line: (e) => it(e, l, m),
				onClose: () => re(!1)
			})
		]
	});
}
//#endregion
//#region src/games/waterdeep/bot.ts
var _t = {
	deficit: 1.2,
	congestion: .14,
	plot: .65,
	agent: 3.2,
	quest: .7,
	building: .35
}, vt = {
	c: 2.4,
	f: 1.3,
	r: 1.3,
	w: 2.4,
	g: .5,
	v: 1,
	x: -2.6
};
function yt(e, t) {
	let n = D(e), r = t.lord === null ? null : A(t.lord);
	return !r || n.type === "mandatory" ? 0 : r.types.includes(n.type) ? 4 : r.id === 1311 ? 3 : r.id === 1312 && n.scope === "undermountain" || r.id === 1315 && n.scope === "skullport" ? 4 : r.id === 1313 && (V(n.reward).v ?? 0) >= 10 ? 5 : r.id === 1314 ? 2.5 : 0;
}
var bt = (e, t) => {
	let n = V(e);
	return Object.keys(t).reduce((e, r) => e + (n[r] ?? 0) * t[r], 0) + (n.a ?? 0) * 2.4 + (n.i ?? 0) * 1.6;
};
function xt(e) {
	let t = Math.floor(4294967296 / e.length) * e.length, n;
	do
		n = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
	while (n >= t);
	return e[n % e.length];
}
function St(e, t, n = _t) {
	let r = e.public, i = e.private, a = r.players.find((e) => e.rid === t), o = 9 - r.round, s = a.resources, c = { ...vt }, l = a.quests.filter((e) => D(e).type === "mandatory"), u = (l.length ? l : a.quests).map((e) => {
		let t = D(e), r = V(t.cost);
		return {
			id: e,
			deficit: B.reduce((e, t) => e + Math.max(0, (r[t] ?? 0) - s[t]) * vt[t], 0) + Math.max(0, (r.g ?? 0) - s.g) * .5 + Math.max(0, (r.a ?? 0) - B.reduce((e, t) => e + s[t] - (r[t] ?? 0), 0)) * 1.7,
			cost: r,
			value: bt(t.reward, vt) + yt(e, i) + (t.plot ? o * n.plot : 0)
		};
	}).sort((e, t) => t.value - t.deficit - (e.value - e.deficit)).slice(0, 2);
	for (let e of B) u.some((t) => (t.cost[e] ?? 0) > s[e]) && (c[e] += n.deficit);
	u.some((e) => (e.cost.g ?? 0) > s.g) && (c.g += n.deficit * .3), c.x = -(Math.max(1, ...r.corruption.map((e, t) => e === 0 ? t + 1 : 0)) + .7 + r.round * .12) + (i.lord === 1316 ? 4 : 0);
	let d = (e) => bt(e, c), f = (e) => {
		let t = D(e), r = V(t.cost), c = B.reduce((e, t) => e + Math.max(0, (r[t] ?? 0) - s[t]) * vt[t], 0) + Math.max(0, (r.g ?? 0) - s.g) * .5 + (r.a ?? 0) * 1.3;
		return (bt(t.reward, vt) + yt(e, i) + (t.plot ? o * n.plot : 0) - c * .85) / (1 + c * .3) / (1 + Math.max(0, a.quests.length - 2) * n.congestion);
	}, p = (e) => {
		let t = O(e);
		return Math.max(2, d(t.owner.includes("/") ? t.owner.split("/")[0] : t.owner)) * o * n.building + (i.lord === 1305 ? 6 : i.lord === 1312 && t.scope === "undermountain" || i.lord === 1315 && t.scope === "skullport" ? 4 : 0);
	}, m = (e) => {
		let t = d({
			field: "f2",
			lion: "r2",
			tower: "w1",
			plinth: "c1",
			aurora: "g4",
			castle: "i1",
			grim: "i2",
			island: "a2x1",
			voice: "i1g5x1",
			slavers: "f2r2x1",
			mirrors: "a1"
		}[e] ?? "");
		if (e === "castle" && (t += o > 1 ? 1.3 : 0), (e.startsWith("cliff-") || e === "voice" || e === "entry") && (t += Math.max(0, ...r.marketQuests.map(f)) * n.quest), e === "cliff-gold" && (t += d("g2")), e === "cliff-card" && (t += 1.6), e === "builders" && (t += Math.max(0, ...r.marketBuildings.filter((e) => O(e.id).cost <= s.g).map((e) => p(e.id) + e.vp - O(e.id).cost * c.g))), e.startsWith("harbor-") && (t += 2.8 + .9 * o / 8), /^[bm]\d+$/.test(e)) {
			let i = Number(e.slice(1)), a = O(i), o = r.buildings.find((e) => e.id === i)?.stock;
			t += a.action.split(";").reduce((e, t) => e + Math.max(...t.split("/").map(d)), 0), o && (t += d(Object.entries(o).map(([e, t]) => `${e}${t}`).join(""))), (i === 1505 || i === 1509 || i === 1521 || i === 1530) && (t += Math.max(0, ...r.marketQuests.map(f)) * n.quest), i === 1513 && (t += r.round < 8 ? n.agent : 0), i === 1517 && (t += r.buildings.length * c.g), i === 1527 && (t += Math.min(2, s.x) * -c.x), [
				1528,
				1533,
				1535
			].includes(i) && (t += -c.x), i === 1523 && (t += 4), i === 1526 && (t += (o?.x ?? 0) * (n.agent + c.x)), i === 1540 && (t += 10 - 3 * 1.3), [
				1533,
				1536,
				1538,
				1539,
				1544
			].includes(i) && (t += i === 1538 ? 5 : 2);
		}
		let i = r.spaces.find((t) => t.id === e)?.extras;
		return i && (t += d(Object.entries(i).map(([e, t]) => `${e}${t}`).join(""))), t;
	};
	return i.choices.map((e) => {
		let t;
		switch (e.kind) {
			case "deploy":
			case "copy":
			case "useSpace":
				t = m(e.space);
				break;
			case "resource":
				t = c[e.resource];
				break;
			case "payResource":
				t = -c[e.resource];
				break;
			case "gain":
				t = d(e.gain);
				break;
			case "takeQuest":
				t = f(e.card);
				break;
			case "complete": {
				let a = D(e.card);
				t = d(a.reward) + yt(a.id, i) + (a.plot ? o * n.plot : 0) - d(a.cost) * (r.round === 8 ? .75 : .45) + (a.type === "mandatory" ? 10 : 0), a.id === 1657 && (t += n.agent * o);
				break;
			}
			case "build":
				t = p(e.card) + d(e.gain ?? "") - d(e.cost ?? "");
				break;
			case "play": {
				let i = e.card, a = {
					1916: "a2",
					1917: "a2",
					1918: "w1",
					1919: "w1",
					1921: "f2",
					1922: "f2",
					1923: "r2",
					1924: "r2",
					1925: "c2",
					1926: "c2",
					1927: "w2",
					1928: "w2",
					1939: "g4",
					1940: "g4",
					1807: "g8x1",
					1811: "r4x1",
					1812: "c2x1",
					1814: "f4x1",
					1815: "w2x1",
					1830: "g2",
					1839: "r2",
					1840: "c1",
					1841: "f2",
					1842: "w1",
					1843: "g5"
				};
				t = a[i] ? d(a[i]) : i >= 2e3 ? 3.5 : 2.8, [
					1912,
					1930,
					1931
				].includes(i) && (t = n.agent * (r.round === 8 ? .8 : 1.7)), [
					1818,
					1819,
					1820
				].includes(i) && (t = Math.min(1, s.x) * -c.x), [
					1824,
					1831,
					1833,
					1834,
					1837
				].includes(i) && (t = 5), i === 1838 && (t = l.length * 6 + o * .5);
				break;
			}
			case "returnCorruption":
			case "removeCorruption":
				t = (e.amount ?? 0) * -c.x;
				break;
			case "recall":
				t = n.agent;
				break;
			case "trade":
			case "tribute":
				t = d(e.gain ?? "") - d(e.cost ?? "");
				break;
			case "steal":
				t = d(e.gain ?? "");
				break;
			case "stealBuilding":
				t = p(e.card) + 3;
				break;
			case "discardQuest":
				t = -f(e.card) + (D(e.card).type === "mandatory" ? 8 : 0);
				break;
			case "discardIntrigue":
				t = e.card >= 2e3 ? -1 : -2;
				break;
			case "sample":
				t = m(`m${e.card}`) - 1.5;
				break;
			case "extraHarbor":
				t = 3 + c.x;
				break;
			case "placeResource":
				t = e.space === "aurora" || e.space === "field" ? 1 : .5;
				break;
			case "skip":
				t = -.1;
				break;
			case "questType":
				t = i.lord && A(i.lord).types.includes(e.detail) ? 3 : 1;
				break;
			default: t = e.gain ? d(e.gain) : 1;
		}
		return {
			option: e,
			score: t
		};
	}).sort((e, t) => t.score - e.score);
}
function Ct(e = _t) {
	return (t, n) => t.public.pending?.rid !== n.rid || !t.private?.choices.length ? null : { action: {
		type: "choose",
		id: (n.difficulty === "weak" ? xt(t.private.choices) : St(t, n.rid, e)[0].option).id
	} };
}
var wt = Ct(), Tt = (e, t, n) => {
	if (e.type !== "choose") return "";
	let r = t.private?.choices.find((t) => t.id === e.id);
	return n("games.waterdeep.hint", { action: r?.card ? n((r.card >= 1500 && r.card < 1600 ? O(r.card) : Et(r.card)).nameKey) : n("games.waterdeep.choose") });
}, Et = (e) => e >= 1800 && e < 2e3 ? k(e) : D(e);
//#endregion
//#region src/games/waterdeep/fx.tsx
function Dt({ card: e }) {
	let t = p();
	return /* @__PURE__ */ b("div", {
		className: "waterdeep-fx-card",
		children: e ? /* @__PURE__ */ x(y, { children: [(e < 1500 || e >= 1600 && e < 2e3) && /* @__PURE__ */ b("img", {
			src: at(`card-${e}`),
			alt: ""
		}), /* @__PURE__ */ b("strong", { children: t(et(e).nameKey) })] }) : /* @__PURE__ */ b(Z, {})
	});
}
var $ = (e, t, n) => ({
	x: e.x + (e.w - t) / 2,
	y: e.y + (e.h - n) / 2,
	w: t,
	h: n
}), Ot = {
	agentMove(e, t) {
		let n = e.data, r = (n) => n ? t.anchor(`waterdeep-arrival:${n}`) ?? t.anchor(`waterdeep-space:${n}`) ?? t.anchor(`waterdeep-card:${n.slice(1)}`) ?? t.anchor("waterdeep-city") : t.anchor(`waterdeep-seat:${e.rid}`), i = r(n.from), a = r(n.to);
		if (!i || !a) return null;
		let o = t.queued ? 130 : 360, s = n.to ? `waterdeep-arrival:${n.to}` : "", c = m[t.member(e.rid)?.colorIndex ?? 0].hex;
		return {
			ms: o,
			hide: !t.queued && s ? [s] : [],
			node: /* @__PURE__ */ b(C, {
				from: $(i, 30, 43),
				to: $(a, 30, 43),
				ms: o,
				children: /* @__PURE__ */ b("span", {
					className: "waterdeep-fx-agent",
					children: /* @__PURE__ */ b(st, {
						color: c,
						ambassador: n.ambassador
					})
				})
			})
		};
	},
	drawIntrigue(e, t) {
		let n = t.anchor("waterdeep-city"), r = t.anchor(`waterdeep-hand:${e.rid}`) ?? t.anchor(`waterdeep-seat:${e.rid}`);
		if (!n || !r) return null;
		let i = t.queued ? 130 : 360;
		return {
			ms: i,
			node: /* @__PURE__ */ b(C, {
				from: $(n, 60, 85),
				to: $(r, 60, 85),
				ms: i,
				children: /* @__PURE__ */ b("div", {
					className: "waterdeep-fx-card",
					children: /* @__PURE__ */ b(Z, {})
				})
			})
		};
	},
	discardIntrigue(e, t) {
		let n = t.anchor(`waterdeep-hand:${e.rid}`) ?? t.anchor(`waterdeep-seat:${e.rid}`), r = t.anchor("waterdeep-city");
		if (!n || !r) return null;
		let i = t.queued ? 130 : 360;
		return {
			ms: i,
			node: /* @__PURE__ */ b(C, {
				from: $(n, 60, 85),
				to: $(r, 60, 85),
				ms: i,
				children: /* @__PURE__ */ b("div", {
					className: "waterdeep-fx-card",
					children: /* @__PURE__ */ b(Z, {})
				})
			})
		};
	},
	deploy(e, t) {
		let n = e.data, r = t.anchor(`waterdeep-seat:${e.rid}`), i = `waterdeep-arrival:${n.space}`, a = t.anchor(i) ?? t.anchor(`waterdeep-space:${n.space}`);
		if (!r || !a) return null;
		let o = m[t.member(e.rid)?.colorIndex ?? 0].hex, s = t.queued ? 130 : 360;
		return {
			ms: s,
			hide: t.queued ? [] : [i],
			node: /* @__PURE__ */ b(C, {
				from: $(r, 30, 43),
				to: $(a, 30, 43),
				ms: s,
				children: /* @__PURE__ */ b("span", {
					className: "waterdeep-fx-agent",
					children: /* @__PURE__ */ b(st, { color: o })
				})
			})
		};
	},
	takeQuest(e, t) {
		let { card: n, space: r } = e.data, i = r === "deck" ? t.anchor("waterdeep-city") : t.anchor(`waterdeep-departure:${n}`) ?? t.anchor("waterdeep-market"), a = `waterdeep-card:${n}`, o = t.anchor(a) ?? t.anchor(`waterdeep-seat:${e.rid}`);
		if (!i || !o) return null;
		let s = t.queued ? 130 : 360;
		return {
			ms: s,
			hide: t.queued ? [] : [a],
			node: /* @__PURE__ */ b(C, {
				from: $(i, 110, 78),
				to: $(o, 110, 78),
				ms: s,
				children: /* @__PURE__ */ b(Dt, { card: n })
			})
		};
	},
	build(e, t) {
		let { card: n, space: r } = e.data, i = r === "deck" ? t.anchor("waterdeep-city") : t.anchor(`waterdeep-departure:${n}`) ?? t.anchor("waterdeep-building-market") ?? t.anchor("waterdeep-market"), a = `waterdeep-card:${n}`, o = t.anchor(a);
		if (!i || !o) return null;
		let s = t.queued ? 130 : 360;
		return {
			ms: s,
			hide: t.queued ? [] : [a],
			node: /* @__PURE__ */ b(C, {
				from: $(i, 110, 78),
				to: $(o, 110, 78),
				ms: s,
				children: /* @__PURE__ */ b(Dt, { card: n })
			})
		};
	},
	complete(e, t) {
		let { card: n, space: r } = e.data, i = `waterdeep-card:${n}`, a = t.anchor(i), o = (r === "market" || e.rid === t.myRid ? t.anchor(`waterdeep-departure:${n}`) : null) ?? t.anchor(`waterdeep-seat:${e.rid}`), s = a ?? t.anchor(`waterdeep-completed:${e.rid}`) ?? t.anchor(`waterdeep-seat:${e.rid}`);
		if (!o || !s) return null;
		let c = t.queued ? 130 : 360;
		return {
			ms: c,
			hide: a && !t.queued ? [i] : [],
			node: /* @__PURE__ */ b(C, {
				from: $(o, 110, 78),
				to: $(s, 70, 48),
				ms: c,
				children: /* @__PURE__ */ b(Dt, { card: n })
			})
		};
	},
	play(e, t) {
		let { card: n } = e.data, r = (e.rid === t.myRid ? t.anchor(`waterdeep-departure:${n}`) : null) ?? t.anchor(`waterdeep-seat:${e.rid}`), i = t.anchor("waterdeep-city");
		if (!r || !i) return null;
		let a = t.queued ? 130 : 360;
		return {
			ms: a,
			node: /* @__PURE__ */ b(C, {
				from: $(r, 80, 110),
				to: $(i, 80, 110),
				ms: a,
				children: /* @__PURE__ */ b(Dt, { card: n })
			})
		};
	},
	resources(e, t) {
		let n = t.anchor(`waterdeep-seat:${e.rid}`), { change: r } = e.data;
		return n ? {
			ms: 360,
			node: /* @__PURE__ */ b(S, {
				at: n,
				ms: 360,
				children: /* @__PURE__ */ b("span", {
					className: "waterdeep-fx-card",
					children: /* @__PURE__ */ b(X, { text: r })
				})
			})
		} : null;
	},
	round(e, t) {
		let n = t.anchor("waterdeep-city");
		return n ? {
			ms: 360,
			node: /* @__PURE__ */ b(w, {
				at: n,
				ms: 360
			})
		} : null;
	},
	finish(e, t) {
		let n = t.anchor("waterdeep-city");
		return n ? {
			ms: 360,
			node: /* @__PURE__ */ b(w, {
				at: n,
				ms: 360
			})
		} : null;
	},
	discardQuest(e, t) {
		let { card: n } = e.data, r = (e.rid === t.myRid ? t.anchor(`waterdeep-departure:${n}`) : null) ?? t.anchor(`waterdeep-seat:${e.rid}`), i = t.anchor("waterdeep-city");
		if (!r || !i) return null;
		let a = t.queued ? 130 : 360;
		return {
			ms: a,
			node: /* @__PURE__ */ b(C, {
				from: $(r, 80, 60),
				to: $(i, 40, 30),
				ms: a,
				children: /* @__PURE__ */ b(Dt, { card: n })
			})
		};
	},
	demolish(e, t) {
		let n = t.anchor("waterdeep-city");
		return n ? {
			ms: 360,
			node: /* @__PURE__ */ b(w, {
				at: n,
				ms: 360
			})
		} : null;
	}
};
//#endregion
//#region src/games/waterdeep/game-over.tsx
function kt({ public: e, private: t, result: n, members: a, myRid: o, onPlayAgain: s, onBackToLobby: c }) {
	let u = e, d = p(), m = f((e) => e.locale), [h, g] = i(!0), [_, v] = i(null), te = r(null), y = r(null), S = r(null), C = (e) => {
		let t = a.find((t) => t.rid === e);
		return t ? ee(t, m) : e;
	}, w = (e) => {
		g(e), v(null), requestAnimationFrame(() => (e ? te : y).current?.focus({ preventScroll: !0 }));
	}, ne = (e) => {
		if (e.key === "Escape" && (e.stopPropagation(), w(!1)), e.key !== "Tab") return;
		let t = [...S.current?.querySelectorAll("button:not(:disabled)") ?? []].filter((e) => e.getClientRects().length), n = t[0], r = t.at(-1);
		e.shiftKey && document.activeElement === n && (e.preventDefault(), r?.focus()), !e.shiftKey && document.activeElement === r && (e.preventDefault(), n?.focus());
	}, T = (e, t) => _ === e ? t() : v(e), E = (e, t) => /* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ b("th", {
		scope: "row",
		children: e
	}), n.ranking.map((e) => {
		let r = u.final.find((t) => t.rid === e)?.[t];
		return /* @__PURE__ */ b("td", {
			"data-winner": n.winner.includes(e),
			children: r === void 0 ? "—" : t === "corruption" && r ? `−${r}` : r
		}, e);
	})] });
	return /* @__PURE__ */ x("div", {
		className: "waterdeep-screen waterdeep-endgame",
		children: [
			/* @__PURE__ */ b("div", {
				className: "waterdeep-end-table",
				inert: h,
				children: /* @__PURE__ */ b(gt, {
					public: u,
					private: t,
					pub: u,
					priv: {
						...t,
						choices: []
					},
					members: a,
					myRid: o,
					send: () => void 0
				})
			}),
			/* @__PURE__ */ b("div", {
				className: "waterdeep-end-veil",
				hidden: !h,
				children: /* @__PURE__ */ x("section", {
					ref: S,
					className: "waterdeep-result",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": d("games.waterdeep.done"),
					onKeyDown: ne,
					children: [
						/* @__PURE__ */ x("header", {
							className: "waterdeep-result-heading",
							children: [/* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b(Z, {}), /* @__PURE__ */ b("h1", { children: d("games.waterdeep.done") })] }), /* @__PURE__ */ b("button", {
								ref: te,
								className: "waterdeep-tool",
								onClick: () => w(!1),
								"aria-label": d("games.waterdeep.showTable"),
								children: /* @__PURE__ */ b(l, { size: 22 })
							})]
						}),
						/* @__PURE__ */ x("div", {
							className: "waterdeep-result-body",
							children: [/* @__PURE__ */ x("aside", {
								className: "waterdeep-award",
								children: [
									/* @__PURE__ */ b(Z, {}),
									/* @__PURE__ */ b("span", { children: d("games.waterdeep.winner") }),
									/* @__PURE__ */ b("strong", { children: n.winner.map(C).join(" / ") }),
									/* @__PURE__ */ b("b", { children: n.scores?.[n.winner[0]] })
								]
							}), /* @__PURE__ */ b("div", {
								className: "waterdeep-score-scroll",
								children: /* @__PURE__ */ x("table", {
									className: "waterdeep-score-table",
									children: [
										/* @__PURE__ */ b("thead", { children: /* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ b("th", {
											scope: "col",
											children: d("games.waterdeep.total")
										}), n.ranking.map((e) => /* @__PURE__ */ b("th", {
											scope: "col",
											"data-winner": n.winner.includes(e),
											children: C(e)
										}, e))] }) }),
										/* @__PURE__ */ x("tbody", { children: [
											E(d("games.waterdeep.points"), "points"),
											E(d("games.waterdeep.adventurers"), "adventurers"),
											E(d("games.waterdeep.goldScore"), "gold"),
											E(d("games.waterdeep.lordScore"), "lord"),
											E(d("games.waterdeep.corruptionScore"), "corruption")
										] }),
										/* @__PURE__ */ b("tfoot", { children: E(d("games.waterdeep.total"), "total") })
									]
								})
							})]
						}),
						/* @__PURE__ */ x("footer", {
							className: "waterdeep-result-footer",
							children: [
								c && /* @__PURE__ */ b("button", {
									className: `waterdeep-quiet${_ === "lobby" ? " danger-stripes" : ""}`,
									onBlur: () => v(null),
									onClick: () => T("lobby", c),
									children: d(_ === "lobby" ? "games.waterdeep.confirmLobby" : "session.result.backToLobby")
								}),
								s && /* @__PURE__ */ b("button", {
									className: `waterdeep-primary${_ === "again" ? " danger-stripes" : ""}`,
									onBlur: () => v(null),
									onClick: () => T("again", s),
									children: d(_ === "again" ? "games.waterdeep.confirmAgain" : "session.result.playAgain")
								}),
								!s && !c && /* @__PURE__ */ b("span", { children: d("session.result.waitHost") })
							]
						})
					]
				})
			}),
			/* @__PURE__ */ b("button", {
				ref: y,
				className: "waterdeep-primary waterdeep-review-restore",
				hidden: h,
				onClick: () => w(!0),
				children: d("games.waterdeep.showResult")
			})
		]
	});
}
//#endregion
//#region src/games/waterdeep/options.tsx
function At({ value: e, onChange: t }) {
	let n = p(), r = Me.safeParse(e), i = r.success ? r.data : Me.parse(void 0);
	return /* @__PURE__ */ x("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ b(ne, {
				label: n("games.waterdeep.undermountain"),
				checked: i.undermountain,
				accent: ke.accent,
				onChange: () => t({
					...i,
					undermountain: !i.undermountain
				})
			}),
			/* @__PURE__ */ b(ne, {
				label: n("games.waterdeep.skullport"),
				checked: i.skullport,
				accent: ke.accent,
				onChange: () => t({
					...i,
					skullport: !i.skullport
				})
			}),
			/* @__PURE__ */ b(ne, {
				label: n("games.waterdeep.long"),
				checked: i.long || i.undermountain && i.skullport,
				accent: ke.accent,
				onChange: () => t({
					...i,
					long: !i.long
				})
			}),
			/* @__PURE__ */ b("p", { children: n("games.waterdeep.longNote") })
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/waterdeep/entry.tsx
var jt = {
	definition: Je,
	View: ht,
	bot: wt,
	describe: Tt,
	fx: Ot,
	OverView: kt,
	Options: At,
	locales: {
		zh: {
			n1600: "驯养枭熊",
			d1600: "",
			n1601: "探索阿格海伦之塔",
			d1601: "每当你采取获得法师的行动时，额外抽 1 张阴谋。",
			n1602: "揭露红袍法师间谍",
			d1602: "",
			n1603: "举办淑妮庆典",
			d1603: "",
			n1604: "潜入海拉斯特秘会",
			d1604: "",
			n1605: "调查异怪侵扰",
			d1605: "",
			n1606: "寻回法官宝珠",
			d1606: "每轮一次，可以将密探派到有对手密探的地点。",
			n1607: "为黑杖学院招募",
			d1607: "",
			n1608: "研究时间魔法",
			d1608: "召回一名已派遣的密探。",
			n1609: "寻回古代遗物",
			d1609: "",
			n1610: "窃取银手的法术书",
			d1610: "",
			n1611: "研究伊卢斯克拱门",
			d1611: "每当你完成奥术任务时，获得 2 分。",
			n1612: "与桑恩家族结盟",
			d1612: "",
			n1613: "贿赂造船匠",
			d1613: "每当你采取获得金币的行动时，额外获得 1 盗贼。",
			n1614: "建立新商人公会",
			d1614: "每当你完成商业任务时，获得 2 分。",
			n1615: "冒充阿达布兰特贵族",
			d1615: "",
			n1616: "渗透建筑大厅",
			d1616: "每当你购买建筑时，获得 4 分。",
			n1617: "洗劫裳禔亚墓穴",
			d1617: "从牌堆抽取一张任务。",
			n1618: "招揽米拉巴工匠",
			d1618: "免费控制一座市场建筑。",
			n1619: "安抚行走雕像",
			d1619: "免费控制建筑堆顶的一座建筑。",
			n1620: "保护埃尔托楚尔法师",
			d1620: "",
			n1621: "援助竖琴手",
			d1621: "选择一位对手获得 4 金币。",
			n1622: "刺探光明之家",
			d1622: "",
			n1623: "削弱城卫队",
			d1623: "",
			n1624: "劝贵族皈依洛山达",
			d1624: "接取一张明置任务。",
			n1625: "建立欧格玛神龛",
			d1625: "",
			n1626: "守卫幸运之塔",
			d1626: "每轮开始时，获得 1 任意冒险者。",
			n1627: "发现罗丝秘密神殿",
			d1627: "接取一张明置任务。",
			n1628: "消灭吸血鬼巢穴",
			d1628: "",
			n1629: "与拉瑟米结盟",
			d1629: "接取一张明置任务。",
			n1630: "救治灰手伤兵",
			d1630: "",
			n1631: "履行赎罪之责",
			d1631: "",
			n1632: "为民众施展神迹",
			d1632: "每轮一次，采取获得牧师的行动后，可以返还一名其他冒险者并获得 1 牧师。",
			n1633: "保护奇迹之家",
			d1633: "每当你完成虔诚任务时，获得 2 分。",
			n1634: "为提尔招募圣武士",
			d1634: "",
			n1635: "封闭希瑞克领域之门",
			d1635: "",
			n1636: "在骷髅港扬名",
			d1636: "",
			n1637: "建立竖琴手安全屋",
			d1637: "你控制的每座建筑额外提供 2 分。",
			n1638: "建立影贼公会",
			d1638: "",
			n1639: "揭露邪教腐败",
			d1639: "",
			n1640: "为黑暗公爵销赃",
			d1640: "每当你采取获得盗贼的行动时，额外获得 2 金币。",
			n1641: "在深水城堡安插间谍",
			d1641: "每当你完成诡计任务时，获得 2 分。",
			n1642: "在骷髅港安插卧底",
			d1642: "每当你打出阴谋时，获得 2 分。",
			n1643: "越狱",
			d1643: "立即打出一张阴谋。",
			n1644: "收购赃物",
			d1644: "",
			n1645: "突袭地底迷城",
			d1645: "",
			n1646: "盗窃阿达布兰特家族",
			d1646: "",
			n1647: "接管敌对组织",
			d1647: "",
			n1648: "伏击阿托尔莫林",
			d1648: "",
			n1649: "壮大城卫队",
			d1649: "",
			n1650: "加强狮鹫骑兵",
			d1650: "每当你采取获得战士的行动时，额外获得 1 战士。",
			n1651: "对抗珊娜萨",
			d1651: "",
			n1652: "镇压地底迷城叛乱",
			d1652: "",
			n1653: "向塞伦神殿运送武器",
			d1653: "",
			n1654: "下达最后通牒",
			d1654: "",
			n1655: "平息佣兵叛乱",
			d1655: "每当你完成战争任务时，获得 2 分。",
			n1656: "突袭兽人要塞",
			d1656: "",
			n1657: "招募副官",
			d1657: "将副官加入你的密探池，直到本局结束。",
			n1658: "击退海幽灵",
			d1658: "",
			n1659: "训练剑咏者",
			d1659: "",
			n1700: "建立邪教支部",
			d1700: "",
			n1701: "调查塞恩船只",
			d1701: "",
			n1702: "招募学院弃徒",
			d1702: "派遣到黑杖塔时，可以额外获得 1 法师及 1 腐败。",
			n1703: "重施防护结界",
			d1703: "可以返还至多 2 腐败。",
			n1704: "封闭骷髅港入口",
			d1704: "可以返还至多 3 腐败。",
			n1705: "揭示禁忌知识",
			d1705: "派遣到深水港时，可以获得 1 腐败并额外打出至多两张阴谋。",
			n1706: "诋毁竞争商号",
			d1706: "每当你购买建筑时，可以将自身一枚腐败放到任意行动格。",
			n1707: "向城市捐献",
			d1707: "可以返还至多 3 腐败。",
			n1708: "勒索奥萝拉",
			d1708: "派遣到奥萝拉商店时，可以额外获得 4 金币及 1 腐败。",
			n1709: "资助炼金研究",
			d1709: "",
			n1710: "资助渥金朝圣",
			d1710: "",
			n1711: "缴纳罚金",
			d1711: "可以返还至多 2 腐败。",
			n1712: "放逐邪灵",
			d1712: "可以返还至多 2 腐败。",
			n1713: "进入七苦之塔",
			d1713: "支付七名任意冒险者。",
			n1714: "向马斯克致敬",
			d1714: "派遣到神坛时，可以额外获得 1 牧师及 1 腐败。",
			n1715: "推行改革",
			d1715: "可以返还至多 3 腐败。",
			n1716: "保护伊莉丝翠信徒",
			d1716: "自己的回合内每回合一次，返还腐败时可以额外返还一枚。",
			n1717: "祝圣欧格玛神殿",
			d1717: "",
			n1718: "掩埋尸体",
			d1718: "",
			n1719: "扩张公会活动",
			d1719: "派遣到咧嘴狮子酒馆时，可以额外获得 2 盗贼及 1 腐败。",
			n1720: "从骷髅手中救人",
			d1720: "可以返还至多 1 腐败。",
			n1721: "救出被绑架的贵族",
			d1721: "可以返还至多 3 腐败。",
			n1722: "庇护散塔林间谍",
			d1722: "自己的回合内每回合一次，获得腐败时抽 1 张阴谋。",
			n1723: "欺诈建筑公会",
			d1723: "免费控制两座市场建筑。选取第二座前先补齐市场。",
			n1724: "暗杀对手",
			d1724: "每位对手自行选择返还一名冒险者。",
			n1725: "操纵冠军赛",
			d1725: "派遣到凯旋广场时，可以额外获得 2 战士及 1 腐败。",
			n1726: "加强监狱安保",
			d1726: "可以从本局永久移除自身至多三枚腐败。",
			n1727: "巡逻码头区",
			d1727: "",
			n1728: "训练城堡卫兵",
			d1728: "每当有人取得先手标记时，你与该玩家各获得 1 战士。",
			n1729: "揭露卓尔阴谋",
			d1729: "可以返还至多 2 腐败。",
			n1730: "与黑蝰蛇交易",
			d1730: "依次抽四张阴谋，每抽一张都可以立即打出。",
			n1731: "建立法师学院",
			d1731: "每当你接取奥术任务时，获得 1 法师。",
			n1732: "探索特罗布里安墓场",
			d1732: "",
			n1733: "复活法师",
			d1733: "",
			n1734: "在藏书馆研习",
			d1734: "完成允许打出阴谋的行动后，抽一张阴谋，并可以立即打出该牌。",
			n1735: "从海拉斯特会面中生还",
			d1735: "每支付一名法师，抽一张阴谋。",
			n1736: "取得建筑图纸",
			d1736: "每轮一次，可以派遣密探使用市场建筑，视同自己控制该建筑。",
			n1737: "洗劫维瑟姆陵墓",
			d1737: "",
			n1738: "为城卫队招募",
			d1738: "可以支付 10 金币，获得 3 战士及 3 盗贼。",
			n1739: "资助赏金猎人",
			d1739: "每当你接取商业任务时，获得 4 金币。",
			n1740: "窃取白骨王座宝石",
			d1740: "",
			n1741: "威胁建筑公会",
			d1741: "免费控制所有当前明置的市场建筑。",
			n1742: "出使苏萨尔",
			d1742: "可以完成市场中的明置任务，视同自己的任务。",
			n1743: "建立伊布兰杜神殿",
			d1743: "接取所有当前明置任务。",
			n1744: "掠夺岛上神殿",
			d1744: "",
			n1745: "救出泰摩拉牧师",
			d1745: "",
			n1746: "肃清劳薇塔信徒",
			d1746: "每支付一名牧师，额外获得 2 分。",
			n1747: "祝圣被亵渎的神殿",
			d1747: "每当你接取虔诚任务时，获得 1 牧师。",
			n1748: "与珊娜萨公会结盟",
			d1748: "每当你接取诡计任务时，获得 2 盗贼。",
			n1749: "潜入黑杖塔",
			d1749: "",
			n1750: "守卫战棋室",
			d1750: "",
			n1751: "冒充税吏",
			d1751: "派遣到自己的建筑时，也获得所有者收益。",
			n1752: "从阿克图莉雅变形术中生还",
			d1752: "",
			n1753: "掀起犯罪狂潮",
			d1753: "可以支付 4 盗贼，额外获得 10 分。",
			n1754: "闯荡缪拉尔迷宫",
			d1754: "",
			n1755: "保卫哈欠之门",
			d1755: "可以召回至多三名已派遣的密探。",
			n1756: "摧毁塞尔维塔姆神殿",
			d1756: "可以支付 4 战士，额外获得 10 分。",
			n1757: "寻回北地之焰",
			d1757: "每当你接取战争任务时，获得 2 战士。",
			n1758: "夺取血手堡垒",
			d1758: "每完成一张任务，可以取回为该任务支付的一名冒险者。",
			n1759: "唤醒六位沉睡者",
			d1759: "",
			n2000: "躲避刺客",
			d2000: "",
			n2001: "追捕潜伏食尸鬼",
			d2001: "",
			n2002: "掩盖丑闻",
			d2002: "只能交给至少持有一枚腐败的对手。完成后可以返还 1 腐败。",
			n2003: "清除锈蚀怪巢穴",
			d2003: "",
			n2004: "肃清邪教徒",
			d2004: "",
			n2005: "击退卓尔入侵者",
			d2005: "",
			n2006: "平息骚乱",
			d2006: "",
			n2007: "安抚愤怒商人",
			d2007: "",
			n2008: "挫败散塔林会",
			d2008: "",
			n2009: "抵御强盗",
			d2009: "",
			n2010: "揭露深渊密探",
			d2010: "",
			n2011: "制服夺心魔威胁",
			d2011: "",
			n1500: "商队庭院",
			d1500: "建成时及每轮开始放置 2 战士，来访者取得全部。",
			n1501: "龙塔",
			d1501: "",
			n1502: "蹄毛庭院",
			d1502: "",
			n1503: "金角酒馆",
			d1503: "建成时及每轮开始放置 4 金币，来访者取得全部。",
			n1504: "海姆之星仓库",
			d1504: "",
			n1505: "英雄花园",
			d1505: "接取一张明置任务，可以立即完成并额外获得 4 分，不占通常任务名额。",
			n1506: "好心情酒馆",
			d1506: "",
			n1507: "英雄之家",
			d1507: "",
			n1508: "奇迹之家",
			d1508: "支付 2 金币，获得两名冒险者，每名分别选择牧师或法师。",
			n1509: "月之居所",
			d1509: "",
			n1510: "弄臣庭院",
			d1510: "建成时及每轮开始放置 2 盗贼，来访者取得全部。",
			n1511: "新欧拉姆学院",
			d1511: "",
			n1512: "北门",
			d1512: "",
			n1513: "深水城宫殿",
			d1513: "取得大使，下一轮先于正常回合派遣。",
			n1514: "潜行小径",
			d1514: "",
			n1515: "走私者码头",
			d1515: "支付 2 金币，获得四名冒险者，每名分别选择战士或盗贼。",
			n1516: "晨曦尖塔",
			d1516: "建成时及每轮开始放置 1 牧师，来访者取得全部。",
			n1517: "石屋",
			d1517: "每座在场建筑提供 1 金币。",
			n1518: "三珍珠酒馆",
			d1518: "返还 2 任意冒险者，获得 3 任意冒险者。",
			n1519: "幸运之塔",
			d1519: "",
			n1520: "法师会高塔",
			d1520: "建成时及每轮开始放置 1 法师，来访者取得全部。",
			n1521: "路会场",
			d1521: "建成时及每轮开始放置 3 分，来访者取得全部，并接取一张明置任务。",
			n1522: "哈欠之门",
			d1522: "",
			n1523: "佐尔之星",
			d1523: "使用对手密探所在地点的行动；复制港口不能重新派遣。",
			n1524: "墓钥便利行",
			d1524: "",
			n1525: "探险者之愚",
			d1525: "将自身一枚腐败放到任意行动格。",
			n1526: "怪物订制所",
			d1526: "建成时及每轮开始放置 1 腐败；取得全部腐败，每取一枚可以召回一名密探。",
			n1527: "暗黑少女长廊",
			d1527: "可以永久移除自身至多 2 腐败。",
			n1528: "隐秘神殿",
			d1528: "返还 1 腐败，获得 1 牧师。",
			n1529: "沙拉丁精品僵尸",
			d1529: "",
			n1530: "深火之地",
			d1530: "获得 1 任意冒险者、5 金币及 1 腐败，接取一张明置任务。",
			n1531: "额叶酒馆",
			d1531: "返还 1 任意冒险者，获得 3 法师及 1 腐败；所有者得到你返还的冒险者。",
			n1532: "地狱犬之吻",
			d1532: "",
			n1533: "淬毒羽笔",
			d1533: "返还 1 腐败，打出 1 张阴谋。",
			n1534: "掷下的护手",
			d1534: "",
			n1535: "顶针酒当铺",
			d1535: "返还 1 腐败，获得 1 金币。",
			n1536: "贝尔克拉姆陵墓",
			d1536: "获得 5 金币，打出 1 张阴谋。",
			n1537: "血手堡垒",
			d1537: "获得 4 战士，从供应区在两个不同行动格各放 1 战士。",
			n1538: "多柱大厅",
			d1538: "依次打出 3 张阴谋。",
			n1539: "沉睡诸王大厅",
			d1539: "获得 1 战士及 1 盗贼，打出 1 张阴谋。",
			n1540: "三领主大厅",
			d1540: "将自身三名任意冒险者分别放到三个不同行动格，获得 10 分。",
			n1541: "大公陵墓",
			d1541: "获得 8 金币，从供应区在两个不同行动格各放 2 金币。",
			n1542: "智慧之室",
			d1542: "获得 2 牧师，从供应区在任意行动格放 1 牧师。",
			n1543: "影暮堡",
			d1543: "获得 4 盗贼，从供应区在两个不同行动格各放 1 盗贼。",
			n1544: "眼之巢穴",
			d1544: "获得 1 任意冒险者，打出 1 张阴谋。",
			n1545: "藏书馆",
			d1545: "获得 2 法师，从供应区在任意行动格放 1 法师。",
			n1546: "失落洞穴",
			d1546: "弃置一张非强制的未完成任务，获得 1 战士、1 盗贼及 1 任意冒险者。",
			n1547: "特罗布里安墓场",
			d1547: "抽 2 张阴谋，获得 4 金币，然后弃置 2 张阴谋。",
			n1801: "勒索",
			d1801: "夺取一位对手至多 2 金币，并查看其领主。",
			n1802: "变形怪",
			d1802: "使用腐败比你多的对手密探所在地点的行动。",
			n1803: "揭露腐败",
			d1803: "腐败比你多的每位对手获得 1 腐败。",
			n1804: "揭露腐败",
			d1804: "腐败比你多的每位对手获得 1 腐败。",
			n1805: "推卸责任",
			d1805: "获得 1 腐败，将自身一张强制任务交给至少有一枚腐败的对手。",
			n1806: "伪造地契",
			d1806: "获得 2 腐败，夺取一座对手建筑。",
			n1807: "黑市资金",
			d1807: "获得 8 金币及 1 腐败；每位对手可以获得 4 金币及 1 腐败。",
			n1808: "贿赂城卫",
			d1808: "支付 2 金币，可以返还至多 2 腐败；每位对手可以支付 4 金币返还 1 腐败。",
			n1809: "腐化影响",
			d1809: "从轨道取腐败，在两个不同的行动格各放一枚。",
			n1810: "腐化影响",
			d1810: "从轨道取腐败，在两个不同的行动格各放一枚。",
			n1811: "暗匕刺杀",
			d1811: "获得 4 盗贼及 1 腐败；每位对手可以获得 2 盗贼及 1 腐败。",
			n1812: "献给希瑞克的捐赠",
			d1812: "获得 2 牧师及 1 腐败；每位对手可以获得 1 牧师及 1 腐败。",
			n1813: "廉洁楷模",
			d1813: "若每位对手的腐败都比你多，获得 6 分。",
			n1814: "铁环奴隶",
			d1814: "获得 4 战士及 1 腐败；每位对手可以获得 2 战士及 1 腐败。",
			n1815: "夺心魔佣兵",
			d1815: "获得 2 法师及 1 腐败；每位对手可以获得 1 法师及 1 腐败。",
			n1816: "放出猎犬",
			d1816: "从腐败轨道取三枚腐败并永久移除。",
			n1817: "放出猎犬",
			d1817: "从腐败轨道取三枚腐败并永久移除。",
			n1818: "忏悔",
			d1818: "返还 1 腐败。",
			n1819: "忏悔",
			d1819: "返还 1 腐败。",
			n1820: "忏悔",
			d1820: "返还 1 腐败。",
			n1821: "替罪羊",
			d1821: "返还 1 任意冒险者，并可以返还至多 2 腐败；每位对手可以返还 2 任意冒险者及 1 腐败。",
			n1822: "替罪羊",
			d1822: "返还 1 任意冒险者，并可以返还至多 2 腐败；每位对手可以返还 2 任意冒险者及 1 腐败。",
			n1823: "意外成功",
			d1823: "依次抽两张阴谋，每抽一张可以立即打出。",
			n1824: "意想不到的援助",
			d1824: "赠给一位对手 1 法师，获得 8 分。",
			n1825: "征求援助",
			d1825: "从一位对手酒馆夺取冒险者：2 战士、2 盗贼或各 1，三者选一。",
			n1826: "征求援助",
			d1826: "从一位对手酒馆夺取冒险者：2 战士、2 盗贼或各 1，三者选一。",
			n1827: "拆除",
			d1827: "拆除一座未被占用的建筑；若属于对手，向其支付该建筑原价。然后免费控制一座市场建筑。",
			n1828: "必然的背叛",
			d1828: "从一位对手夺取 1 任意冒险者及 2 金币，然后将本牌交给该玩家。",
			n1829: "操纵",
			d1829: "将一名对手密探移到空行动格；对手可以执行新地点行动。然后派遣一名自己尚未派遣的密探。",
			n1830: "优待",
			d1830: "获得 2 金币及先手标记。",
			n1831: "信仰同盟",
			d1831: "赠给一位对手 1 牧师，获得 8 分。",
			n1832: "建筑创新",
			d1832: "获得 2 金币，可以购买一座市场建筑。",
			n1833: "友好借款",
			d1833: "赠给一位对手 4 金币，获得 8 分。",
			n1834: "盗亦有道",
			d1834: "赠给一位对手 2 盗贼，获得 8 分。",
			n1835: "情报掮客",
			d1835: "抽 3 张阴谋，每位对手抽 1 张阴谋。",
			n1836: "情报掮客",
			d1836: "抽 3 张阴谋，每位对手抽 1 张阴谋。",
			n1837: "佣兵契约",
			d1837: "赠给一位对手 2 战士，获得 8 分。",
			n1838: "公开领主",
			d1838: "公开领主，弃置自身全部强制任务。此后自身、密探及建筑免受对手攻击与强制任务阴谋影响。",
			n1839: "有组织犯罪",
			d1839: "获得 2 盗贼，并从供应区在两个不同行动格各放 1 盗贼。",
			n1840: "传教",
			d1840: "获得 1 牧师，并从供应区在任意行动格放 1 牧师。",
			n1841: "招募活动",
			d1841: "获得 2 战士，并从供应区在两个不同行动格各放 1 战士。",
			n1842: "资助学徒",
			d1842: "获得 1 法师，并从供应区在任意行动格放 1 法师。",
			n1843: "抗税暴动",
			d1843: "获得 5 金币，并从供应区在两个不同行动格各放 2 金币。",
			n1844: "意外成功",
			d1844: "依次抽两张阴谋，每抽一张可以立即打出。",
			n1912: "加速计划",
			d1912: "召回一名自己在深水港的密探，然后立即派遣两名密探。",
			n1900: "伏击",
			d1900: "每位对手返还 1 战士。每有一位无法返还，你获得 1 战士。",
			n1901: "伏击",
			d1901: "每位对手返还 1 战士。每有一位无法返还，你获得 1 战士。",
			n1902: "奥术事故",
			d1902: "每位对手返还 1 法师。每有一位无法返还，你抽 1 张阴谋。",
			n1903: "奥术事故",
			d1903: "每位对手返还 1 法师。每有一位无法返还，你抽 1 张阴谋。",
			n1904: "暗杀",
			d1904: "每位对手返还 1 盗贼。每有一位无法返还，你获得 2 金币。",
			n1905: "暗杀",
			d1905: "每位对手返还 1 盗贼。每有一位无法返还，你获得 2 金币。",
			n1913: "竞标战",
			d1913: "抽取等同玩家人数的任务。你选一张，其余传给左手边玩家，依次每人选一张。",
			n1914: "竞标战",
			d1914: "抽取等同玩家人数的任务。你选一张，其余传给左手边玩家，依次每人选一张。",
			n1915: "竞标战",
			d1915: "抽取等同玩家人数的任务。你选一张，其余传给左手边玩家，依次每人选一张。",
			n1906: "贿赂密探",
			d1906: "支付 2 金币，使用一名对手密探所在地点的行动。",
			n1907: "贿赂密探",
			d1907: "支付 2 金币，使用一名对手密探所在地点的行动。",
			n1916: "召集冒险者",
			d1916: "获得 2 任意冒险者，每位对手获得 1 任意冒险者。",
			n1917: "召集冒险者",
			d1917: "获得 2 任意冒险者，每位对手获得 1 任意冒险者。",
			n1918: "请求人情",
			d1918: "选择获得 4 金币、2 战士、2 盗贼、1 法师或 1 牧师。",
			n1919: "请求人情",
			d1919: "选择获得 4 金币、2 战士、2 盗贼、1 法师或 1 牧师。",
			n1920: "改变计划",
			d1920: "弃置一张未完成任务，获得 6 分。每位对手可以弃置一张未完成任务获得 3 分。可以弃置强制任务。",
			n1921: "征募",
			d1921: "获得 2 战士，选择一位对手获得 1 战士。",
			n1922: "征募",
			d1922: "获得 2 战士，选择一位对手获得 1 战士。",
			n1923: "犯罪浪潮",
			d1923: "获得 2 盗贼，选择一位对手获得 1 盗贼。",
			n1924: "犯罪浪潮",
			d1924: "获得 2 盗贼，选择一位对手获得 1 盗贼。",
			n1908: "免费酒水",
			d1908: "从一位对手的酒馆夺取 1 任意冒险者。",
			n1909: "免费酒水",
			d1909: "从一位对手的酒馆夺取 1 任意冒险者。",
			n1925: "诚意",
			d1925: "获得 2 牧师，选择一位对手获得 1 牧师。",
			n1926: "诚意",
			d1926: "获得 2 牧师，选择一位对手获得 1 牧师。",
			n1927: "毕业典礼",
			d1927: "获得 2 法师，选择一位对手获得 1 法师。",
			n1928: "毕业典礼",
			d1928: "获得 2 法师，选择一位对手获得 1 法师。",
			n1910: "信仰缺失",
			d1910: "每位对手返还 1 牧师。每有一位无法返还，你获得 2 分。",
			n1911: "信仰缺失",
			d1911: "每位对手返还 1 牧师。每有一位无法返还，你获得 2 分。",
			n1929: "地产交易",
			d1929: "弃置一座自己控制且没有密探的建筑，然后免费控制一座市场建筑。",
			n1930: "召回密探",
			d1930: "召回一名已派遣的密探。",
			n1931: "召回密探",
			d1931: "召回一名已派遣的密探。",
			n1932: "招募间谍",
			d1932: "获得 2 盗贼。每位对手可以赠给你 1 盗贼，获得 3 分。",
			n1933: "请求支援",
			d1933: "获得 2 战士。每位对手可以赠给你 1 战士，获得 3 分。",
			n1934: "研究协议",
			d1934: "获得 1 法师。每位对手可以赠给你 1 法师，获得 5 分。",
			n1935: "试用商品",
			d1935: "派遣一名尚未派遣的密探至市场建筑，执行其行动，视同自己控制该建筑。",
			n1936: "试用商品",
			d1936: "派遣一名尚未派遣的密探至市场建筑，执行其行动，视同自己控制该建筑。",
			n1937: "特殊委派",
			d1937: "选择一种任务类型，依次翻开任务直到出现该类型；接取该任务，弃置其余。",
			n1938: "特殊委派",
			d1938: "选择一种任务类型，依次翻开任务直到出现该类型；接取该任务，弃置其余。",
			n1939: "分享财富",
			d1939: "获得 4 金币，选择一位对手获得 2 金币。",
			n1940: "分享财富",
			d1940: "获得 4 金币，选择一位对手获得 2 金币。",
			n1941: "召集信徒",
			d1941: "获得 1 牧师。每位对手可以赠给你 1 牧师，获得 5 分。",
			n1942: "征税",
			d1942: "获得 4 金币。每位对手可以支付给你 4 金币，获得 4 分。",
			n1943: "征税",
			d1943: "获得 4 金币。每位对手可以支付给你 4 金币，获得 4 分。",
			n1300: "布莉安·拜恩德拉斯",
			n1301: "卡拉多恩·卡萨兰特",
			n1302: "漫游者杜南",
			n1303: "黑杖凯尔本·奥罗桑",
			n1304: "凯拉妮·阿格里瓦",
			n1305: "拉莉莎·尼瑟尔",
			n1306: "放贷者米尔特",
			n1307: "宁迪尔·贾尔巴克",
			n1308: "妮玛拉·谢隆",
			n1309: "圣武士之子皮尔盖伦",
			n1310: "萨梅雷扎·苏丰提斯",
			n1311: "丹尼洛·坦恩",
			n1312: "黑袍海拉斯特",
			n1313: "特罗布里安",
			n1314: "伊露希尔·艾拉奈斯",
			n1315: "桑伽洛",
			n1316: "珊娜萨",
			name: "深水城领主",
			desc: "派遣密探招募冒险者，完成任务，掌控深水城。",
			errFinished: "本局已经结束。",
			errTurn: "现在轮不到你行动。",
			errChoice: "这个选择已不可用，请重新选择。",
			round: "第 {{n}} / 8 轮",
			resolving: "行动结算中",
			waiting: "等待 {{name}}",
			yourTurn: "请选择行动地点",
			choose: "请选择",
			c: "牧师",
			f: "战士",
			r: "盗贼",
			w: "法师",
			g: "金币",
			v: "胜利分",
			x: "腐败",
			a: "任意冒险者",
			i: "阴谋",
			arcana: "奥术",
			commerce: "商业",
			piety: "虔诚",
			skullduggery: "诡计",
			warfare: "战争",
			mandatory: "强制任务",
			base: "基础版",
			undermountain: "地底迷城",
			skullport: "骷髅港",
			long: "长局",
			longNote: "六人及同时启用两个扩展时，使用长局的初始密探数量。",
			enabled: "开启",
			disabled: "关闭",
			quests: "任务",
			intrigues: "阴谋手牌",
			buildings: "建筑",
			completed: "已完成任务",
			market: "建筑大厅",
			inn: "悬崖岗哨旅店",
			harbor: "深水港",
			agents: "密探",
			lord: "领主",
			first: "先手",
			owned: "{{name}} 所有",
			available: "可用",
			occupied: "已占用",
			preview: "预览",
			confirm: "确认",
			cancel: "取消",
			close: "关闭",
			cost: "费用",
			reward: "奖励",
			plot: "剧情任务",
			ownerBenefit: "所有者收益",
			or: "或",
			details: "查看详情",
			seat: "{{name}} 的酒馆",
			privateLord: "你的隐藏领主",
			corruptionValue: "每枚罚 {{n}} 分",
			done: "深水城议会",
			points: "对局得分",
			adventurers: "剩余冒险者",
			goldScore: "剩余金币",
			lordScore: "领主奖励",
			corruptionScore: "腐败罚分",
			total: "总分",
			winner: "深水城的新任执政者",
			showTable: "查看最终牌桌",
			showResult: "查看计分",
			confirmAgain: "确认再来一局",
			confirmLobby: "确认返回房间",
			logDeploy: "{{name}} 派遣密探至 {{place}}。",
			logTake: "{{name}} 接取「{{card}}」。",
			logComplete: "{{name}} 完成「{{card}}」。",
			logPlay: "{{name}} 打出「{{card}}」。",
			logBuild: "{{name}} 获得「{{card}}」。",
			logDiscard: "{{name}} 弃置「{{card}}」。",
			logRound: "新一轮开始。",
			logFinish: "八轮结束，结算领主奖励。",
			lordPair: "每完成一张 {{types}} 任务，获得 4 分。",
			lordBuildings: "每控制一座建筑，获得 6 分。",
			lordAll: "每完成一张非强制任务，获得 3 分。",
			lordModule: "每完成一张 {{module}} 任务、每控制一座该模块建筑，获得 4 分。",
			lordLarge: "每完成一张印刷奖励至少 10 分的任务，获得 5 分。",
			lordType: "选择一种任务类型，每完成一张该类型任务，获得 6 分。",
			lordCorruption: "每枚自身腐败获得 4 分，仍须结算腐败罚分。",
			hint: "建议：{{action}}",
			emptyHand: "没有阴谋手牌",
			emptyQuests: "尚未接取任务",
			agentCount: "剩余密探 {{n}}",
			skip: "跳过",
			none: "无",
			revealed: "领主已公开",
			seenLords: "已查看的领主",
			sfield: "凯旋广场",
			sfieldDesc: "获得 2 战士。",
			slion: "咧嘴狮子酒馆",
			slionDesc: "获得 2 盗贼。",
			stower: "黑杖塔",
			stowerDesc: "获得 1 法师。",
			splinth: "神坛",
			splinthDesc: "获得 1 牧师。",
			saurora: "奥萝拉商店",
			sauroraDesc: "获得 4 金币。",
			scastle: "深水城堡",
			scastleDesc: "抽 1 张阴谋，取得先手标记。",
			sbuilders: "建筑大厅",
			sbuildersDesc: "支付费用，购买一座市场建筑并获得其累计分数。",
			scliff_gold: "旅店 · 金币",
			scliff_goldDesc: "接取一张明置任务，获得 2 金币。",
			scliff_card: "旅店 · 阴谋",
			scliff_cardDesc: "接取一张明置任务，抽 1 张阴谋。",
			scliff_reset: "旅店 · 更换任务",
			scliff_resetDesc: "弃置市场所有任务，补齐后接取一张。",
			sharbor_0: "深水港 Ⅰ",
			sharbor_0Desc: "打出一张阴谋。轮末首先重新派遣此处密探。",
			sharbor_1: "深水港 Ⅱ",
			sharbor_1Desc: "打出一张阴谋。轮末第二个重新派遣此处密探。",
			sharbor_2: "深水港 Ⅲ",
			sharbor_2Desc: "打出一张阴谋。轮末第三个重新派遣此处密探。",
			sgrim: "严峻雕像",
			sgrimDesc: "抽 2 张阴谋。",
			sentry: "入口井",
			sentryDesc: "接取一张明置任务，然后打出 1 张阴谋。",
			smirrors: "镜之厅",
			smirrorsDesc: "获得 1 任意冒险者，或获得 1 战士及 1 盗贼。",
			sisland: "骷髅岛",
			sislandDesc: "获得 2 任意冒险者及 1 腐败。",
			svoice: "众声大厅",
			svoiceDesc: "抽 1 张阴谋，接取一张明置任务，获得 5 金币及 1 腐败。",
			sslavers: "奴隶市场",
			sslaversDesc: "获得 2 战士、2 盗贼及 1 腐败。",
			act_deploy: "派遣密探",
			act_copy: "使用此地点",
			act_build: "获得建筑",
			act_takeQuest: "接取任务",
			act_complete: "完成任务",
			act_play: "打出阴谋",
			act_resource: "获得冒险者",
			act_payResource: "支付冒险者",
			act_gain: "获得资源",
			act_trade: "交换资源",
			act_opponent: "选择玩家",
			act_placeResource: "放置资源",
			act_returnCorruption: "返还腐败",
			act_removeCorruption: "移除腐败",
			act_recall: "召回密探",
			act_discardQuest: "弃置任务",
			act_discardIntrigue: "弃置阴谋",
			act_sample: "使用市场建筑",
			act_foist: "转移强制任务",
			act_stealBuilding: "夺取建筑",
			act_steal: "夺取资源",
			act_tribute: "赠送资源",
			act_questType: "选择任务类型",
			act_demolish: "拆除建筑",
			act_moveAgent: "移动密探",
			act_useSpace: "使用地点",
			act_extraHarbor: "额外打出阴谋",
			act_placeExtraMenu: "放置腐败",
			act_skip: "跳过",
			act_optional: "是否执行此效果？",
			prompt_deploy: "请选择密探的行动地点",
			prompt_quest: "选择一张任务",
			prompt_build: "选择一座建筑",
			prompt_complete: "可以完成一张任务",
			prompt_play: "选择要打出的阴谋",
			prompt_resource: "选择获得的冒险者",
			prompt_payAny: "选择支付的冒险者",
			prompt_loseAny: "选择返还的冒险者",
			prompt_trade: "是否交换资源？",
			prompt_returnCorruption: "选择返还的腐败数量",
			prompt_removeCorruption: "选择永久移除的腐败数量",
			prompt_placeResource: "选择放置资源的地点",
			prompt_recall: "选择召回的密探",
			prompt_opponent: "选择一位玩家",
			prompt_copy: "选择要使用的地点",
			prompt_discardQuest: "选择弃置的任务",
			prompt_discardIntrigue: "选择弃置的阴谋",
			prompt_stealBuilding: "选择夺取的建筑",
			prompt_foist: "选择强制任务及接收玩家",
			prompt_steal: "选择夺取的资源及目标",
			prompt_tribute: "是否赠送资源以获得分数？",
			prompt_questType: "选择任务类型",
			prompt_sample: "选择使用的市场建筑",
			prompt_demolish: "选择拆除的建筑",
			prompt_moveAgent: "选择密探及目的地",
			prompt_optional: "是否执行此效果？",
			prompt_recover: "取回一枚用于完成任务的冒险者",
			rules: "目标：\n八轮结束后，总分最高者获胜。总分包括对局得分、剩余冒险者（每枚 1 分）、金币（每 2 枚 1 分）、秘密领主奖励，并扣除腐败罚分。同分时金币较多者获胜；仍同分则并列。\n准备：\n每人秘密获得一位领主、两张阴谋，公开获得两张任务。按人数领取密探；先手玩家获得4枚金币，此后按顺时针顺序，每名玩家比前一名多获得1枚金币。在市场中正面朝上摆放四张任务和三座建筑。\n流程：\n从先手起轮流派遣一名可用密探至合法地点，领取该处放置的资源，再完整执行行动。通常每格只容纳一名密探。行动后可以完成一张任务：支付所需冒险者及金币，领取奖励。若有强制任务，必须优先完成。已完成的剧情任务持续提供卡面收益。阴谋与领主只向本人显示；未完成任务公开。\n深水港：\n在此打出一张阴谋。其他密探全部派遣完毕后，按港口 Ⅰ、Ⅱ、Ⅲ 顺序将实际驻留的密探重新派至其他合法地点。复制港口行动不会获得重新派遣。重派期间新获得的密探立即派遣。\n建筑：\n支付金币购买建筑，获得该市场位置累积的分数，并将建筑置于自己控制之下。每轮开始，三座市场建筑各增加 1 分；具有积累能力的已建建筑放置新资源。使用对手建筑时，对手获得所有者收益；使用自己建筑通常没有该收益。最多控制九座建筑。\n轮次：\n一轮结束后收回所有密探。第五轮每人额外获得一名密探。游戏共八轮，先手标记决定每轮首位行动者。\n扩展：\n地底迷城与骷髅港默认关闭，可单独或同时开启。至少开启一个扩展可进行六人局。长局初始密探数量为两人 5 名、三人 4 名、四至五人 3 名、六人 2 名；六人或同时开启两个扩展时必须使用长局。双扩展开局随机移除基础版的 25 张阴谋、30 张任务和 12 座建筑后混合。\n骷髅港：\n腐败从最接近 −1 的非空格拿取；返还时放入最远且未满三枚的格子。永久移除不会回到轨道。轨道中没有可拿取的腐败标记时，每缺少一枚所需标记，就立即失去10分。终局每枚腐败的罚分为轨道上最远空格的绝对值。\n特殊配件：\n· 副官：招募副官提供一名永久额外密探。\n· 大使：深水城宫殿授予大使，下一轮先于正常回合派遣；大使完成所派地点的行动后视为所有人的对手密探，在港口不会重新派遣。\n· 英雄花园允许立即完成新接任务并额外获得 4 分，不占通常一次任务完成名额。\n卡牌上的具体效果与限制优先。"
		},
		en: {
			n1600: "Domesticate Owlbears",
			d1600: "",
			n1601: "Explore Ahghairon's Tower",
			d1601: "Whenever an action gives you one or more Wizards, draw 1 Intrigue card.",
			n1602: "Expose Red Wizards' Spies",
			d1602: "",
			n1603: "Host Festival For Sune",
			d1603: "",
			n1604: "Infiltrate Halaster's Circle",
			d1604: "",
			n1605: "Investigate Aberrant Infestation",
			d1605: "",
			n1606: "Recover The Magister's Orb",
			d1606: "Once per round, you can assign an Agent to a space containing an opponent's Agent.",
			n1607: "Recruit For Blackstaff Academy",
			d1607: "",
			n1608: "Research Chronomancy",
			d1608: "Return 1 of your assigned Agents to your pool.",
			n1609: "Retrieve Ancient Artifacts",
			d1609: "",
			n1610: "Steal Spellbook From Silverhand",
			d1610: "",
			n1611: "Study The Illusk Arch",
			d1611: "Whenever you complete an Arcana Quest, you score 2 VP.",
			n1612: "Ally With House Thann",
			d1612: "",
			n1613: "Bribe The Shipwrights",
			d1613: "Whenever an action gives you Gold, also gain 1 Rogue.",
			n1614: "Establish New Merchant Guild",
			d1614: "Whenever you complete a Commerce Quest, you score 2 VP.",
			n1615: "Impersonate Adarbrent Noble",
			d1615: "",
			n1616: "Infiltrate Builder's Hall",
			d1616: "Whenever you buy a Building, you score 4 VP.",
			n1617: "Loot The Crypt Of Chauntea",
			d1617: "Draw one quest.",
			n1618: "Lure Artisans Of Mirabar",
			d1618: "Put one Building from Builder's Hall into play under your control at no cost.",
			n1619: "Placate The Walking Statue",
			d1619: "Draw one Building from the stack and put it into play under your control at no cost.",
			n1620: "Safeguard Eltorchul Mage",
			d1620: "",
			n1621: "Send Aid To The Harpers",
			d1621: "Choose an opponent to gain 4 gold.",
			n1622: "Spy on the House of Light",
			d1622: "",
			n1623: "Thin The City Watch",
			d1623: "",
			n1624: "Convert A Noble To Lathander",
			d1624: "Take one face-up quest.",
			n1625: "Create A Shrine To Oghma",
			d1625: "",
			n1626: "Defend The Tower Of Luck",
			d1626: "At the start of each round, gain 1 adventurer of your choice.",
			n1627: "Discover Hidden Temple Of Lolth",
			d1627: "Take one face-up quest.",
			n1628: "Eliminate Vampire Coven",
			d1628: "",
			n1629: "Form An Alliance With The Rashemi",
			d1629: "Take one face-up quest.",
			n1630: "Heal Fallen Gray Hand Soldiers",
			d1630: "",
			n1631: "Perform The Penance Of Duty",
			d1631: "",
			n1632: "Produce Miracle For The Masses",
			d1632: "Once per round, after an action provides any Clerics, you may return 1 Fighter, Rogue or Wizard from your Tavern and gain 1 Cleric.",
			n1633: "Protect The House Of Wonder",
			d1633: "Whenever you complete a Piety Quest, you score 2 VP.",
			n1634: "Recruit Paladins For Tyr",
			d1634: "",
			n1635: "Seal Gate To Cyric's Realm",
			d1635: "",
			n1636: "Build A Reputation In Skullport",
			d1636: "",
			n1637: "Establish Harpers Safe House",
			d1637: "Score 2 additional points for each Building you control.",
			n1638: "Establish Shadow Thieves' Guild",
			d1638: "",
			n1639: "Expose Cult Corruption",
			d1639: "",
			n1640: "Fence Goods For Duke Of Darkness",
			d1640: "Whenever an action gives you one or more Rogues, also gain 2 Gold.",
			n1641: "Install A Spy In Castle Waterdeep",
			d1641: "Whenever you complete a Skullduggery Quest, you score 2 VP.",
			n1642: "Place A Sleeper Agent In Skullport",
			d1642: "Whenever you play an Intrigue card, score 2 points.",
			n1643: "Prison Break",
			d1643: "Immediately play 1 Intrigue card without assigning an Agent.",
			n1644: "Procure Stolen Goods",
			d1644: "",
			n1645: "Raid On Undermountain",
			d1645: "",
			n1646: "Steal From House Adarbrent",
			d1646: "",
			n1647: "Take Over Rival Organization",
			d1647: "",
			n1648: "Ambush Artor Morlin",
			d1648: "",
			n1649: "Bolster City Guard",
			d1649: "",
			n1650: "Bolster Griffon Cavalry",
			d1650: "Whenever an action gives you one or more Fighters, also gain 1 Fighter.",
			n1651: "Confront The Xanathar",
			d1651: "",
			n1652: "Defeat Uprising From Undermountain",
			d1652: "",
			n1653: "Deliver Weapons To Selune's Temple",
			d1653: "",
			n1654: "Deliver An Ultimatum",
			d1654: "",
			n1655: "Quell Mercenary uprising",
			d1655: "Whenever you complete a Warfare Quest, you score 2 VP.",
			n1656: "Raid Orc Stronghold",
			d1656: "",
			n1657: "Recruit Lieutenant",
			d1657: "Add the Lieutenant to your pool of Agents for the rest of the game.",
			n1658: "Repel Seawraiths",
			d1658: "",
			n1659: "Train Bladesingers",
			d1659: "",
			n1700: "Establish Cult Cell",
			d1700: "",
			n1701: "Investigate Thayan Vessel",
			d1701: "",
			n1702: "Recruit Academy Castoffs",
			d1702: "Whenever you assign an Agent to Blackstaff Tower, you may gain 1 additional Wizard and take 1 Corruption.",
			n1703: "Renew Guards and Wards",
			d1703: "Return up to 2 Corruption.",
			n1704: "Seal an Entrance to Skullport",
			d1704: "Return up to 3 Corruption.",
			n1705: "Uncover Forbidden Lore",
			d1705: "After assigning to Waterdeep Harbor, you may play up to 2 additional Intrigue cards. If you play at least one, take 1 Corruption.",
			n1706: "Defame Rival Business",
			d1706: "Whenever you buy a Building, you may place 1 Corruption from your Tavern on any action space.",
			n1707: "Donate to the City",
			d1707: "Return up to 3 Corruption.",
			n1708: "Extort Aurora",
			d1708: "Whenever you assign an Agent to Aurora’s Realms Shop, you may gain 4 additional Gold and take 1 Corruption.",
			n1709: "Fund Alchemical Research",
			d1709: "",
			n1710: "Fund Pilgrimage of Waukeen",
			d1710: "",
			n1711: "Pay Fines",
			d1711: "Return up to 2 Corruption.",
			n1712: "Banish Evil Spirits",
			d1712: "Return up to 2 Corruption.",
			n1713: "Enter the Tower of Seven Woes",
			d1713: "",
			n1714: "Give Honor to Mask",
			d1714: "Whenever you assign an Agent to The Plinth, you may gain 1 additional Cleric and take 1 Corruption.",
			n1715: "Institute Reforms",
			d1715: "Return up to 3 Corruption.",
			n1716: "Protect Converts to Eilistraee",
			d1716: "Once on your turn, after returning Corruption, you may return 1 additional Corruption.",
			n1717: "Sanctify Temple to Oghma",
			d1717: "",
			n1718: "Bury the Bodies",
			d1718: "",
			n1719: "Expand Guild Activities",
			d1719: "Whenever you assign an Agent to The Grinning Lion Tavern, you may gain 2 additional Rogues and take 1 Corruption.",
			n1720: "Rescue a Victim from the Skulls",
			d1720: "Return up to 1 Corruption.",
			n1721: "Save Kidnapped Nobles",
			d1721: "Return up to 3 Corruption.",
			n1722: "Shelter Zhentarim Agents",
			d1722: "Once on your turn, after gaining Corruption, draw 1 Intrigue card.",
			n1723: "Swindle the Builder's Guilds",
			d1723: "Put 2 face-up market Buildings into play under your control at no cost. Refill the market before choosing the second.",
			n1724: "Assassinate Rivals",
			d1724: "Each opponent chooses 1 adventurer in their own Tavern and returns it to the supply.",
			n1725: "Fix the Champion's Games",
			d1725: "Whenever you assign an Agent to the Field of Triumph, you may gain 2 additional Fighters and take 1 Corruption.",
			n1726: "Improve Prison Security",
			d1726: "Permanently remove up to 3 Corruption from your Tavern.",
			n1727: "Patrol Dock Ward",
			d1727: "",
			n1728: "Train Castle Guards",
			d1728: "Whenever a player takes the first-player marker, both you and that player gain 1 Fighter.",
			n1729: "Uncover Drow Plot",
			d1729: "Return up to 2 Corruption.",
			n1730: "Deal with the Black Viper",
			d1730: "Draw 4 Intrigue cards, one at a time. You may play each card immediately after drawing it.",
			n1731: "Establish Wizard Academy",
			d1731: "Whenever you take an Arcana Quest, gain 1 Wizard.",
			n1732: "Explore Trobriand's Graveyard",
			d1732: "",
			n1733: "Resurrect Dead Wizards",
			d1733: "",
			n1734: "Study in the Librarium",
			d1734: "After fully completing an action that allows you to play Intrigue, draw 1 Intrigue card. You may play it immediately.",
			n1735: "Survive a Meeting with Halaster",
			d1735: "Draw 1 Intrigue card for each Wizard spent to complete this Quest.",
			n1736: "Obtain Builders' Plans",
			d1736: "Once per round, assign an agent to a market Building and use it as though you controlled it.",
			n1737: "Ransack Withehlm's Tomb",
			d1737: "",
			n1738: "Recruit for City Watch",
			d1738: "You may pay 10 Gold to gain 3 Fighters and 3 Rogues.",
			n1739: "Sponsor Bounty Hunters",
			d1739: "Whenever you take a Commerce Quest, gain 4 Gold.",
			n1740: "Steal Gems from the Bone Throne",
			d1740: "",
			n1741: "Threaten the Builders' Guilds",
			d1741: "Put all currently face-up market Buildings into play under your control at no cost.",
			n1742: "Diplomatic Mission to Suzail",
			d1742: "You may complete face-up Quests at Cliffwatch Inn as though they were your active Quests.",
			n1743: "Establish Temple to Ibrandul",
			d1743: "Take all face-up Quests at Cliffwatch Inn.",
			n1744: "Plunder the Island Temple",
			d1744: "",
			n1745: "Rescue Clerics of Tymora",
			d1745: "",
			n1746: "Root Out Loviatar's Faithful",
			d1746: "Score 2 additional points for each Cleric spent to complete this Quest.",
			n1747: "Sanctify a Desecrated Temple",
			d1747: "Whenever you take a Piety Quest, gain 1 Cleric.",
			n1748: "Ally with the Xanathar's Guild",
			d1748: "Whenever you take a Skullduggery Quest, gain 2 Rogues.",
			n1749: "Break Into Blackstaff Tower",
			d1749: "",
			n1750: "Defend the Lanceboard Room",
			d1750: "",
			n1751: "Impersonate Tax Collector",
			d1751: "Whenever you assign an Agent to a Building you control, also gain its owner benefit.",
			n1752: "Survive Arcturia's Transformation",
			d1752: "",
			n1753: "Unleash Crime Spree",
			d1753: "You may return 4 Rogues from your Tavern to the supply to score 10 points.",
			n1754: "Battle in Muiral's Gauntlet",
			d1754: "",
			n1755: "Defend the Yawning Portal",
			d1755: "Return up to 3 of your assigned Agents to your pool.",
			n1756: "Destroy a Temple of Selvetarm",
			d1756: "You may return 4 Fighters from your Tavern to the supply to score 10 points.",
			n1757: "Recover the Flame of the North",
			d1757: "Whenever you take a Warfare Quest, gain 2 Fighters.",
			n1758: "Seize Citadel of the Bloody Hand",
			d1758: "Whenever you complete a Quest, you may recover 1 adventurer spent to complete it.",
			n1759: "Wake the Six Sleepers",
			d1759: "",
			n2000: "Evade Assassin",
			d2000: "",
			n2001: "Hunt Hidden Ghoul",
			d2001: "",
			n2002: "Cover Up a Scandal",
			d2002: "Return up to 1 Corruption.",
			n2003: "Clear Rust Monster Nest",
			d2003: "",
			n2004: "Stamp Out Cultists",
			d2004: "",
			n2005: "Repel Drow Invaders",
			d2005: "",
			n2006: "Quell Riots",
			d2006: "",
			n2007: "Placate Angry Merchants",
			d2007: "",
			n2008: "Foil the Zhentarim",
			d2008: "",
			n2009: "Fend Off Bandits",
			d2009: "",
			n2010: "Unveil Abyssal Agent",
			d2010: "",
			n2011: "Subdue Illithid Menace",
			d2011: "",
			n1500: "Caravan Court",
			d1500: "When put in play and at the start of each round, add 2 Fighters. A visitor takes all accumulated Fighters.",
			n1501: "Dragon Tower",
			d1501: "",
			n1502: "Fetlock Court",
			d1502: "",
			n1503: "The Golden Horn",
			d1503: "When put in play and at the start of each round, add 4 Gold. A visitor takes all accumulated Gold.",
			n1504: "Helmstar Warehouse",
			d1504: "",
			n1505: "Heroes' Garden",
			d1505: "Take a face-up Quest. You may immediately complete it for 4 extra points, in addition to your usual completion allowance.",
			n1506: "House of Good Spirits",
			d1506: "",
			n1507: "House of Heroes",
			d1507: "",
			n1508: "House of Wonder",
			d1508: "Pay 2 Gold. Gain 2 adventurers, choosing Cleric or Wizard separately for each.",
			n1509: "House of the Moon",
			d1509: "",
			n1510: "Jesters' Court",
			d1510: "When put in play and at the start of each round, add 2 Rogues. A visitor takes all accumulated Rogues.",
			n1511: "New Olamn",
			d1511: "",
			n1512: "Northgate",
			d1512: "",
			n1513: "The Palace of Waterdeep",
			d1513: "Claim the Ambassador. Assign it before normal turns in the next round.",
			n1514: "The Skulkway",
			d1514: "",
			n1515: "Smuggler's Dock",
			d1515: "Pay 2 Gold. Gain 4 adventurers, choosing Fighter or Rogue separately for each.",
			n1516: "Spires of the Morning",
			d1516: "When put in play and at the start of each round, add 1 Cleric. A visitor takes all accumulated Clerics.",
			n1517: "The Stone House",
			d1517: "Gain 1 Gold for each advanced Building in play.",
			n1518: "The Three Pearls",
			d1518: "Return 2 adventurers of your choice, then gain 3 adventurers of your choice.",
			n1519: "The Tower of Luck",
			d1519: "",
			n1520: "Tower of the Order",
			d1520: "When put in play and at the start of each round, add 1 Wizard. A visitor takes all accumulated Wizards.",
			n1521: "The Waymoot",
			d1521: "When put in play and at the start of each round, add 3 points. A visitor scores all accumulated points and takes a face-up Quest.",
			n1522: "The Yawning Portal",
			d1522: "",
			n1523: "The Zoarstar",
			d1523: "Use an action space occupied by an opponent’s agent. Copying Harbor does not grant reassignment.",
			n1524: "Cryptkey Facilitations",
			d1524: "",
			n1525: "Delver's Folly",
			d1525: "Place 1 Corruption from your Tavern on any action space.",
			n1526: "Monsters Made to Order",
			d1526: "When put in play and at the start of each round, add 1 Corruption if available. Take all Corruption here; you may recall up to that many agents.",
			n1527: "Promenade of the Dark Maiden",
			d1527: "Permanently remove up to 2 Corruption from your Tavern.",
			n1528: "Secret Shrine",
			d1528: "Return 1 Corruption and gain 1 Cleric.",
			n1529: "Sharadin's Excellent Zombies",
			d1529: "",
			n1530: "The Deepfires",
			d1530: "Gain any 1 adventurer, 5 Gold and 1 Corruption. Take a face-up Quest.",
			n1531: "The Frontal Lobe",
			d1531: "Return 1 adventurer. Gain 3 Wizards and 1 Corruption. The owner receives the adventurer you returned.",
			n1532: "The Hell Hound's Muzzle",
			d1532: "",
			n1533: "The Poisoned Quill",
			d1533: "Return 1 Corruption, then play 1 Intrigue card.",
			n1534: "The Thrown Gauntlet",
			d1534: "",
			n1535: "Thimblewine's Pawnshop",
			d1535: "Return 1 Corruption and gain 1 Gold.",
			n1536: "Belkram's Tomb",
			d1536: "Gain 5 Gold, then play 1 Intrigue card.",
			n1537: "Citadel of the Bloody Hand",
			d1537: "Gain 4 Fighters. Place 1 Fighter from the supply on each of 2 different action spaces.",
			n1538: "Hall of Many Pillars",
			d1538: "Play 3 Intrigue cards, one at a time.",
			n1539: "Hall of Sleeping Kings",
			d1539: "Gain 1 Fighter and 1 Rogue, then play 1 Intrigue card.",
			n1540: "Hall of Three Lords",
			d1540: "Place 3 adventurers from your Tavern on 3 different action spaces, then score 10 points.",
			n1541: "High Duke's Tomb",
			d1541: "Gain 8 Gold. Place 2 Gold from the supply on each of 2 different action spaces.",
			n1542: "Room of Wisdom",
			d1542: "Gain 2 Clerics. Place 1 Cleric from the supply on any action space.",
			n1543: "Shadowdusk Hold",
			d1543: "Gain 4 Rogues. Place 1 Rogue from the supply on each of 2 different action spaces.",
			n1544: "The Eye's Lair",
			d1544: "Gain any 1 adventurer, then play 1 Intrigue card.",
			n1545: "The Librarium",
			d1545: "Gain 2 Wizards. Place 1 Wizard from the supply on any action space.",
			n1546: "The Lost Cavern",
			d1546: "Discard a non-mandatory active Quest. Gain 1 Fighter, 1 Rogue and any 1 adventurer.",
			n1547: "Trobriand's Graveyard",
			d1547: "Draw 2 Intrigue cards, gain 4 Gold, then discard 2 Intrigue cards.",
			n1801: "Blackmail",
			d1801: "Choose an opponent. Take up to 2 Gold from their Tavern and look at their Lord card.",
			n1802: "Doppelganger!",
			d1802: "Use an action space occupied by an Agent belonging to an opponent who has more Corruption than you.",
			n1803: "Expose Corruption",
			d1803: "Each opponent who has more Corruption than you takes 1 Corruption.",
			n1804: "Expose Corruption",
			d1804: "Each opponent who has more Corruption than you takes 1 Corruption.",
			n1805: "Foist Responsibility",
			d1805: "Take 1 Corruption. Give one of your uncompleted Mandatory Quests to an opponent who has at least 1 Corruption.",
			n1806: "Forge Deed",
			d1806: "Take 2 Corruption and gain control of one Building controlled by an opponent.",
			n1807: "Black Market Money",
			d1807: "Gain 8 Gold and 1 Corruption; each opponent may gain 4 Gold and 1 Corruption.",
			n1808: "Bribe the Watch",
			d1808: "Pay 2 Gold to return up to 2 Corruption. Each opponent may pay 4 Gold to return 1 Corruption.",
			n1809: "Corrupting Influence",
			d1809: "Place 1 Corruption from the track on each of 2 different action spaces.",
			n1810: "Corrupting Influence",
			d1810: "Place 1 Corruption from the track on each of 2 different action spaces.",
			n1811: "Dark Dagger Assassination",
			d1811: "Gain 4 Rogues and 1 Corruption; each opponent may gain 2 Rogues and 1 Corruption.",
			n1812: "Donations for Cyric",
			d1812: "Gain 2 Clerics and 1 Corruption; each opponent may gain 1 Cleric and 1 Corruption.",
			n1813: "Honorable Example",
			d1813: "Score 6 points if every opponent has more Corruption than you.",
			n1814: "Iron Ring Slaves",
			d1814: "Gain 4 Fighters and 1 Corruption; each opponent may gain 2 Fighters and 1 Corruption.",
			n1815: "Mind Flayer Mercenaries",
			d1815: "Gain 2 Wizards and 1 Corruption; each opponent may gain 1 Wizard and 1 Corruption.",
			n1816: "Release the Hounds",
			d1816: "Permanently remove 3 Corruption from the track.",
			n1817: "Release the Hounds",
			d1817: "Permanently remove 3 Corruption from the track.",
			n1818: "Repent",
			d1818: "Return 1 Corruption from your Tavern to the track.",
			n1819: "Repent",
			d1819: "Return 1 Corruption from your Tavern to the track.",
			n1820: "Repent",
			d1820: "Return 1 Corruption from your Tavern to the track.",
			n1821: "Scapegoat",
			d1821: "Return 1 adventurer of your choice from your Tavern to return up to 2 Corruption. Each opponent may return 2 adventurers of their own choice from their Tavern to return 1 Corruption.",
			n1822: "Scapegoat",
			d1822: "Return 1 adventurer of your choice from your Tavern to return up to 2 Corruption. Each opponent may return 2 adventurers of their own choice from their Tavern to return 1 Corruption.",
			n1823: "Unexpected Success",
			d1823: "Draw 2 Intrigue cards, one at a time. You may play each card immediately after drawing it.",
			n1824: "Unlikely Assistance",
			d1824: "Give an opponent 1 Wizard from your Tavern to score 8 points.",
			n1825: "Call for Assistance",
			d1825: "Take 2 Fighters, 2 Rogues, or 1 of each from one opponent’s Tavern. Choose one of these three options.",
			n1826: "Call for Assistance",
			d1826: "Take 2 Fighters, 2 Rogues, or 1 of each from one opponent’s Tavern. Choose one of these three options.",
			n1827: "Demolish",
			d1827: "Discard an unoccupied Building in play. If an opponent controls it, pay that opponent its printed Gold cost. Then put one face-up market Building into play under your control at no cost.",
			n1828: "Inevitable Betrayal",
			d1828: "Choose an opponent. Take 1 adventurer of your choice and 2 Gold from their Tavern, then give them this Intrigue card.",
			n1829: "Manipulate",
			d1829: "Move an opponent’s Agent to an unoccupied action space. That opponent may use the new space’s action. Then assign 1 Agent from your own pool.",
			n1830: "Preferential Treatment",
			d1830: "Gain 2 Gold and take the first-player marker.",
			n1831: "Allied Faiths",
			d1831: "Give an opponent 1 Cleric from your Tavern to score 8 points.",
			n1832: "Architectural Innovation",
			d1832: "Gain 2 Gold. You may then buy one face-up market Building.",
			n1833: "Friendly Loan",
			d1833: "Give an opponent 4 Gold from your Tavern to score 8 points.",
			n1834: "Honor Among Thieves",
			d1834: "Give an opponent 2 Rogues from your Tavern to score 8 points.",
			n1835: "Information Broker",
			d1835: "Draw 3 Intrigue cards. Each opponent draws 1 Intrigue card.",
			n1836: "Information Broker",
			d1836: "Draw 3 Intrigue cards. Each opponent draws 1 Intrigue card.",
			n1837: "Mercenary Contract",
			d1837: "Give an opponent 2 Fighters from your Tavern to score 8 points.",
			n1838: "Open Lord",
			d1838: "Reveal your Lord card and discard all of your uncompleted Mandatory Quests. You are immune to opponents’ Attack and Mandatory Quest Intrigue cards for the rest of the game.",
			n1839: "Organized Crime",
			d1839: "Gain 2 Rogues. Place 1 Rogue from the supply on each of 2 different action spaces.",
			n1840: "Proselytize",
			d1840: "Gain 1 Cleric. Place 1 Cleric from the supply on an action space.",
			n1841: "Recruitment Drive",
			d1841: "Gain 2 Fighters. Place 1 Fighter from the supply on each of 2 different action spaces.",
			n1842: "Sponsor Apprentices",
			d1842: "Gain 1 Wizard. Place 1 Wizard from the supply on an action space.",
			n1843: "Tax Revolt",
			d1843: "Gain 5 Gold. Place 2 Gold from the supply on each of 2 different action spaces.",
			n1844: "Unexpected Success",
			d1844: "Draw 2 Intrigue cards, one at a time. You may play each card immediately after drawing it.",
			n1912: "Accelerated Plans",
			d1912: "Return one of your Agents at Waterdeep Harbor to your pool, then immediately assign 2 Agents.",
			n1900: "Ambush",
			d1900: "Each opponent removes 1 Fighter from his or her Tavern and returns it to the supply.  For each opponent that could not do so, take 1 Fighter from the supply and place it in your Tavern.",
			n1901: "Ambush",
			d1901: "Each opponent removes 1 Fighter from his or her Tavern and returns it to the supply.  For each opponent that could not do so, take 1 Fighter from the supply and place it in your Tavern.",
			n1902: "Arcane Mishap",
			d1902: "Each opponent removes 1 Wizard from his or her Tavern and returns it to the supply.  For each opponent that could not do so, draw 1 Intrigue.",
			n1903: "Arcane Mishap",
			d1903: "Each opponent removes 1 Wizard from his or her Tavern and returns it to the supply.  For each opponent that could not do so, draw 1 Intrigue.",
			n1904: "Assassination",
			d1904: "Each opponent removes 1 Rogue from his or her Tavern and returns it to the supply.  For each opponent that could not do so, take 2 gold from the supply and place it in your Tavern.",
			n1905: "Assassination",
			d1905: "Each opponent removes 1 Rogue from his or her Tavern and returns it to the supply.  For each opponent that could not do so, take 2 gold from the supply and place it in your Tavern.",
			n1913: "Bidding War",
			d1913: "Draw a Quest from the deck equal to the number of players.  Keep one and pass the remaining Quests to the player on your left.  Each player, in turn, chooses 1 Quest to keep, and passes the rest to the left until every player has taken a Quest.",
			n1914: "Bidding War",
			d1914: "Draw a Quest from the deck equal to the number of players.  Keep one and pass the remaining Quests to the player on your left.  Each player, in turn, chooses 1 Quest to keep, and passes the rest to the left until every player has taken a Quest.",
			n1915: "Bidding War",
			d1915: "Draw a Quest from the deck equal to the number of players.  Keep one and pass the remaining Quests to the player on your left.  Each player, in turn, chooses 1 Quest to keep, and passes the rest to the left until every player has taken a Quest.",
			n1906: "Bribe Agent",
			d1906: "Pay 2 gold.  Choose an action space containing an opponent's Agent.  You use that space's action as though you had assigned an Agent to it.",
			n1907: "Bribe Agent",
			d1907: "Pay 2 gold.  Choose an action space containing an opponent's Agent.  You use that space's action as though you had assigned an Agent to it.",
			n1916: "Call For Adventurers",
			d1916: "Gain 2 adventurers of your choice. Each opponent gains 1 adventurer of their own choice.",
			n1917: "Call For Adventurers",
			d1917: "Gain 2 adventurers of your choice. Each opponent gains 1 adventurer of their own choice.",
			n1918: "Call In A Favor",
			d1918: "Choose one reward: 4 Gold, 2 Fighters, 2 Rogues, 1 Wizard, or 1 Cleric.",
			n1919: "Call In A Favor",
			d1919: "Choose one reward: 4 Gold, 2 Fighters, 2 Rogues, 1 Wizard, or 1 Cleric.",
			n1920: "Change Of Plans",
			d1920: "Discard one of your uncompleted Quests to score 6 points. Each opponent may discard one of their uncompleted Quests to score 3 points. Mandatory Quests may be discarded this way.",
			n1921: "Conscription",
			d1921: "Gain 2 Fighters. Choose an opponent to gain 1 Fighter.",
			n1922: "Conscription",
			d1922: "Gain 2 Fighters. Choose an opponent to gain 1 Fighter.",
			n1923: "Crime Wave",
			d1923: "Gain 2 Rogues. Choose an opponent to gain 1 Rogue.",
			n1924: "Crime Wave",
			d1924: "Gain 2 Rogues. Choose an opponent to gain 1 Rogue.",
			n1908: "Free Drinks",
			d1908: "Take 1 adventurer of your choice from an opponent’s Tavern and place it in your Tavern.",
			n1909: "Free Drinks",
			d1909: "Take 1 adventurer of your choice from an opponent’s Tavern and place it in your Tavern.",
			n1925: "Good Faith",
			d1925: "Gain 2 Clerics. Choose an opponent to gain 1 Cleric.",
			n1926: "Good Faith",
			d1926: "Gain 2 Clerics. Choose an opponent to gain 1 Cleric.",
			n1927: "Graduation Day",
			d1927: "Gain 2 Wizards. Choose an opponent to gain 1 Wizard.",
			n1928: "Graduation Day",
			d1928: "Gain 2 Wizards. Choose an opponent to gain 1 Wizard.",
			n1910: "Lack Of Faith",
			d1910: "Each opponent removes 1 Cleric from his or her Tavern and returns it to the supply.  For each opponent that could not do so, you score 2 VP.",
			n1911: "Lack Of Faith",
			d1911: "Each opponent removes 1 Cleric from his or her Tavern and returns it to the supply.  For each opponent that could not do so, you score 2 VP.",
			n1929: "Real Estate Deal",
			d1929: "Discard an unoccupied Building you control. Then put one face-up Building from Builder’s Hall into play under your control at no cost and refill the market.",
			n1930: "Recall Agent",
			d1930: "Return 1 of your assigned Agents to your pool.",
			n1931: "Recall Agent",
			d1931: "Return 1 of your assigned Agents to your pool.",
			n1932: "Recruit Spies",
			d1932: "Gain 2 Rogues. Each opponent may give you 1 Rogue from their Tavern to score 3 points.",
			n1933: "Request Assistance",
			d1933: "Gain 2 Fighters. Each opponent may give you 1 Fighter from their Tavern to score 3 points.",
			n1934: "Research Agreement",
			d1934: "Gain 1 Wizard. Each opponent may give you 1 Wizard from their Tavern to score 5 points.",
			n1935: "Sample Wares",
			d1935: "Assign 1 Agent from your pool to a face-up Building in Builder’s Hall. Immediately use its action as though you controlled it.",
			n1936: "Sample Wares",
			d1936: "Assign 1 Agent from your pool to a face-up Building in Builder’s Hall. Immediately use its action as though you controlled it.",
			n1937: "Special Assignment",
			d1937: "Choose a Quest type. Draw and reveal Quests until you reveal that type. Keep that Quest and discard the rest.",
			n1938: "Special Assignment",
			d1938: "Choose a Quest type. Draw and reveal Quests until you reveal that type. Keep that Quest and discard the rest.",
			n1939: "Spread The Wealth",
			d1939: "Take 4 gold from the supply and choose 1 opponent.  That opponent takes 2 gold from the supply.",
			n1940: "Spread The Wealth",
			d1940: "Take 4 gold from the supply and choose 1 opponent.  That opponent takes 2 gold from the supply.",
			n1941: "Summon The Faithful",
			d1941: "Gain 1 Cleric. Each opponent may give you 1 Cleric from their Tavern to score 5 points.",
			n1942: "Tax Collection",
			d1942: "Take 4 gold from the supply.  Each opponent can choose to pay you 4 gold to score 4 VP.",
			n1943: "Tax Collection",
			d1943: "Take 4 gold from the supply.  Each opponent can choose to pay you 4 gold to score 4 VP.",
			n1300: "Brianne Byndraeth",
			n1301: "Caladorn Cassalanter",
			n1302: "Durnan the Wanderer",
			n1303: "Khelben Arunsun, the Blackstaff",
			n1304: "K’yranní Agrivar",
			n1305: "Larissa Neathal",
			n1306: "Mirt the Moneylender",
			n1307: "Nindil Jalbuck",
			n1308: "Nymara Scheiron",
			n1309: "Piergeiron the Paladinson",
			n1310: "Sammereza Sulphontis",
			n1311: "Danilo Thann",
			n1312: "Halaster Blackcloak",
			n1313: "Trobriand",
			n1314: "Irusyl Eraneth",
			n1315: "Sangalor",
			n1316: "The Xanathar",
			name: "Lords of Waterdeep",
			desc: "Send agents, recruit adventurers and complete quests to rule Waterdeep.",
			errFinished: "This game has ended.",
			errTurn: "It is not your turn.",
			errChoice: "That choice is no longer available.",
			round: "Round {{n}} / 8",
			resolving: "Resolving action",
			waiting: "Waiting for {{name}}",
			yourTurn: "Choose an action space",
			choose: "Choose",
			c: "Cleric",
			f: "Fighter",
			r: "Rogue",
			w: "Wizard",
			g: "Gold",
			v: "Victory points",
			x: "Corruption",
			a: "Any adventurer",
			i: "Intrigue",
			arcana: "Arcana",
			commerce: "Commerce",
			piety: "Piety",
			skullduggery: "Skullduggery",
			warfare: "Warfare",
			mandatory: "Mandatory quest",
			base: "Base game",
			undermountain: "Undermountain",
			skullport: "Skullport",
			long: "Long game",
			longNote: "Six players and games with both modules use the long-game agent counts.",
			enabled: "On",
			disabled: "Off",
			quests: "Quests",
			intrigues: "Intrigue hand",
			buildings: "Buildings",
			completed: "Completed quests",
			market: "Builder’s Hall",
			inn: "Cliffwatch Inn",
			harbor: "Waterdeep Harbor",
			agents: "Agents",
			lord: "Lord",
			first: "First player",
			owned: "Owned by {{name}}",
			available: "Available",
			occupied: "Occupied",
			preview: "Preview",
			confirm: "Confirm",
			cancel: "Cancel",
			close: "Close",
			cost: "Cost",
			reward: "Reward",
			plot: "Plot quest",
			ownerBenefit: "Owner benefit",
			or: "or",
			details: "View details",
			seat: "{{name}}’s tavern",
			privateLord: "Your secret lord",
			corruptionValue: "−{{n}} points each",
			done: "The Council of Waterdeep",
			points: "Points earned",
			adventurers: "Remaining adventurers",
			goldScore: "Remaining gold",
			lordScore: "Lord bonus",
			corruptionScore: "Corruption penalty",
			total: "Total",
			winner: "Waterdeep’s new ruler",
			showTable: "Review final table",
			showResult: "View scores",
			confirmAgain: "Confirm new game",
			confirmLobby: "Confirm return to lobby",
			logDeploy: "{{name}} assigned an agent to {{place}}.",
			logTake: "{{name}} took {{card}}.",
			logComplete: "{{name}} completed {{card}}.",
			logPlay: "{{name}} played {{card}}.",
			logBuild: "{{name}} gained control of {{card}}.",
			logDiscard: "{{name}} discarded {{card}}.",
			logRound: "A new round begins.",
			logFinish: "Eight rounds have ended. Score lord bonuses.",
			lordPair: "Score 4 points for each completed {{types}} quest.",
			lordBuildings: "Score 6 points per building you control.",
			lordAll: "Score 3 points per completed non-mandatory quest.",
			lordModule: "Score 4 points per completed {{module}} quest and controlled building from that module.",
			lordLarge: "Score 5 points per completed quest with a printed reward of at least 10 points.",
			lordType: "Choose one quest type. Score 6 points per completed quest of that type.",
			lordCorruption: "Score 4 points per corruption you hold, then apply the usual corruption penalty.",
			hint: "Suggested: {{action}}",
			emptyHand: "No intrigue cards",
			emptyQuests: "No active quests",
			agentCount: "{{n}} agents available",
			skip: "Skip",
			none: "None",
			revealed: "Lord revealed",
			seenLords: "Lords you have seen",
			sfield: "Field of Triumph",
			sfieldDesc: "Gain 2 Fighters.",
			slion: "The Grinning Lion Tavern",
			slionDesc: "Gain 2 Rogues.",
			stower: "Blackstaff Tower",
			stowerDesc: "Gain 1 Wizard.",
			splinth: "The Plinth",
			splinthDesc: "Gain 1 Cleric.",
			saurora: "Aurora’s Realms Shop",
			sauroraDesc: "Gain 4 Gold.",
			scastle: "Castle Waterdeep",
			scastleDesc: "Draw 1 Intrigue and take the first-player marker.",
			sbuilders: "Builder’s Hall",
			sbuildersDesc: "Buy one market building and score its accumulated points.",
			scliff_gold: "Inn · Gold",
			scliff_goldDesc: "Take one face-up Quest and gain 2 Gold.",
			scliff_card: "Inn · Intrigue",
			scliff_cardDesc: "Take one face-up Quest and draw 1 Intrigue.",
			scliff_reset: "Inn · New Quests",
			scliff_resetDesc: "Replace all face-up Quests, then take one.",
			sharbor_0: "Waterdeep Harbor I",
			sharbor_0Desc: "Play 1 Intrigue. Reassign this agent first at round end.",
			sharbor_1: "Waterdeep Harbor II",
			sharbor_1Desc: "Play 1 Intrigue. Reassign this agent second at round end.",
			sharbor_2: "Waterdeep Harbor III",
			sharbor_2Desc: "Play 1 Intrigue. Reassign this agent third at round end.",
			sgrim: "The Grim Statue",
			sgrimDesc: "Draw 2 Intrigue cards.",
			sentry: "The Entry Well",
			sentryDesc: "Take a face-up Quest, then play 1 Intrigue.",
			smirrors: "Hall of Mirrors",
			smirrorsDesc: "Gain any 1 adventurer, or 1 Fighter and 1 Rogue.",
			sisland: "Skull Island",
			sislandDesc: "Gain any 2 adventurers and 1 Corruption.",
			svoice: "Hall of the Voice",
			svoiceDesc: "Draw 1 Intrigue, take 1 face-up Quest, gain 5 Gold and 1 Corruption.",
			sslavers: "Slavers’ Market",
			sslaversDesc: "Gain 2 Fighters, 2 Rogues and 1 Corruption.",
			act_deploy: "Assign agent",
			act_copy: "Use this space",
			act_build: "Gain building",
			act_takeQuest: "Take quest",
			act_complete: "Complete quest",
			act_play: "Play intrigue",
			act_resource: "Gain adventurer",
			act_payResource: "Pay adventurer",
			act_gain: "Gain resources",
			act_trade: "Exchange resources",
			act_opponent: "Choose player",
			act_placeResource: "Place resources",
			act_returnCorruption: "Return corruption",
			act_removeCorruption: "Remove corruption",
			act_recall: "Recall agent",
			act_discardQuest: "Discard quest",
			act_discardIntrigue: "Discard intrigue",
			act_sample: "Use market building",
			act_foist: "Transfer mandatory quest",
			act_stealBuilding: "Take building",
			act_steal: "Take resources",
			act_tribute: "Give resources",
			act_questType: "Choose quest type",
			act_demolish: "Demolish building",
			act_moveAgent: "Move agent",
			act_useSpace: "Use space",
			act_extraHarbor: "Play extra intrigue",
			act_placeExtraMenu: "Place corruption",
			act_skip: "Skip",
			act_optional: "Use this effect?",
			prompt_deploy: "Choose a space for your agent",
			prompt_quest: "Choose a quest",
			prompt_build: "Choose a building",
			prompt_complete: "You may complete one quest",
			prompt_play: "Choose an intrigue to play",
			prompt_resource: "Choose an adventurer",
			prompt_payAny: "Choose an adventurer to pay",
			prompt_loseAny: "Choose an adventurer to return",
			prompt_trade: "Exchange resources?",
			prompt_returnCorruption: "Choose corruption to return",
			prompt_removeCorruption: "Choose corruption to remove",
			prompt_placeResource: "Choose a space for these resources",
			prompt_recall: "Choose an agent to recall",
			prompt_opponent: "Choose a player",
			prompt_copy: "Choose a space to use",
			prompt_discardQuest: "Choose a quest to discard",
			prompt_discardIntrigue: "Choose an intrigue to discard",
			prompt_stealBuilding: "Choose a building to take",
			prompt_foist: "Choose a mandatory quest and a recipient",
			prompt_steal: "Choose resources and a target",
			prompt_tribute: "Give resources to score points?",
			prompt_questType: "Choose a quest type",
			prompt_sample: "Choose a market building to use",
			prompt_demolish: "Choose a building to demolish",
			prompt_moveAgent: "Choose an agent and its destination",
			prompt_optional: "Use this effect?",
			prompt_recover: "Recover one adventurer spent on this quest",
			rules: "Goal: after eight rounds, score points earned during play, 1 point per remaining adventurer, 1 per 2 Gold, and your secret Lord bonus; subtract Corruption penalties. Most points wins; ties go to the player with more Gold, then remain tied.\nSetup: each player receives a secret Lord, 2 Intrigue cards and 2 public Quests. Starting agents depend on player count. The first player receives 4 Gold, then each player clockwise receives one more. Reveal 4 Quests and 3 Buildings.\nTurns: clockwise from the first player, assign one available agent to a legal action space. Take resources placed there before carrying out every instruction. Spaces normally hold one agent. After each assignment, you may complete one Quest by paying its cost and receiving its reward. Complete Mandatory Quests before other Quests. Completed Plot Quests grant ongoing benefits. Intrigue and Lords are private; active Quests are public.\nWaterdeep Harbor: play an Intrigue card. After regular assignments, reassign the agents actually remaining at Harbor I, II and III in that order. Copying Harbor does not grant reassignment. Agents newly gained during reassignment are assigned immediately.\nBuildings: pay Gold to buy a market Building, score points accumulated on its position and put it under your control. Each market Building gains 1 point at the beginning of every round. Accumulating Buildings gain resources when put in play and each round thereafter. Using an opponent’s Building grants its owner benefit; using your own normally does not. You may control at most 9 Buildings.\nRounds: reclaim assigned agents at round end. Each player gains an extra agent at the start of round 5. The first-player marker determines who begins each round.\nModules: Undermountain and Skullport are off by default; enable either or both. At least one module allows 6 players. Long-game starting agents: 5 at 2 players, 4 at 3, 3 at 4–5, and 2 at 6. Six players and both modules require the long game. With both modules, randomly remove 25 base Intrigue cards, 30 Quests and 12 Buildings before combining.\nSkullport: take Corruption from the occupied space closest to −1. Return tokens to the furthest space holding fewer than 3. Removed tokens leave the game. Each token you cannot take because the track is empty immediately costs 10 points. At game end, each Corruption in your Tavern costs the absolute value of the furthest empty space.\nSpecial pieces:\n· Recruit Lieutenant grants a permanent extra agent.\n· The Palace grants the Ambassador for assignment before normal turns next round; it counts as an opponent’s agent for everyone and is never reassigned from Harbor.\n· Heroes’ Garden may immediately complete the newly taken Quest for 4 extra points without using your normal completion allowance.\nIndividual card effects and restrictions take precedence."
		}
	}
};
//#endregion
export { jt as default };
