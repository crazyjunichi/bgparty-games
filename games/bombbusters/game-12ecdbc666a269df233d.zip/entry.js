import { z as e } from "zod";
import { randomIntAt as t } from "@bgparty/sdk/engine/prng";
import { Children as n, useEffect as r, useState as i } from "react";
import { botAvatarOf as a } from "@bgparty/sdk/lobby";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { avatarNameAt as s, useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { IconDisconnected as u, IconLog as d } from "@bgparty/sdk/icons";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as p } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { Flash as _, Floater as v, PulseBox as y } from "@bgparty/sdk/fx/primitives";
import { Confetti as b } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as ee, OptionSection as te } from "@bgparty/sdk/ui/game-options";
//#region src/games/bombbusters/meta.ts
var x = {
	id: "bombbusters",
	tier: "beta",
	mechanics: ["deduction"],
	interactionTags: ["cooperative", "communication-limits"],
	nameKey: "games.bombbusters.name",
	descKey: "games.bombbusters.desc",
	rulesKey: "games.bombbusters.rules",
	icon: "💣",
	iconImg: "games/bombbusters.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/bombbusters/en.pdf" },
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [4],
	accent: "#ea580c",
	releasedAt: "2026-10-01",
	search: {
		py: "zha dan ke xing",
		init: "zdkx"
	},
	hotseat: "cover"
}, S = [
	1,
	2,
	3,
	4,
	5,
	6,
	7,
	8,
	9,
	10,
	11,
	12
], C = [
	...S,
	"fund",
	"disintegrator",
	"singleLabel",
	"threadCutter",
	"grapple",
	"doubleFond"
];
function w(e) {
	return e >= 9 ? C : S;
}
var T = {
	blueMax: 12,
	equipExclude: [],
	dialAdjust: 0,
	setupTokens: "standard",
	tokenStyle: "value"
}, ne = [
	{
		...T,
		id: 1,
		blueMax: 6,
		red: { n: 0 },
		yellow: { n: 0 },
		equip: "none",
		features: []
	},
	{
		...T,
		id: 2,
		blueMax: 8,
		red: { n: 0 },
		yellow: { n: 2 },
		yellowMax: 7.1,
		equip: "none",
		features: []
	},
	{
		...T,
		id: 3,
		blueMax: 10,
		red: { n: 1 },
		redMax: 9.5,
		yellow: { n: 0 },
		equip: "random",
		equipExclude: [11, 12],
		features: []
	},
	{
		...T,
		id: 4,
		red: { n: 1 },
		yellow: { n: 2 },
		yellow2p: { n: 4 },
		equip: "random",
		features: []
	},
	{
		...T,
		id: 5,
		red: { n: 1 },
		red2p: { n: 2 },
		yellow: {
			n: 2,
			of: 3
		},
		equip: "random",
		features: []
	},
	{
		...T,
		id: 6,
		red: { n: 1 },
		red2p: { n: 2 },
		yellow: { n: 4 },
		equip: "random",
		features: []
	},
	{
		...T,
		id: 7,
		red: {
			n: 1,
			of: 2
		},
		red2p: {
			n: 1,
			of: 3
		},
		yellow: { n: 0 },
		equip: "random",
		features: []
	},
	{
		...T,
		id: 8,
		red: {
			n: 1,
			of: 2
		},
		red2p: {
			n: 1,
			of: 3
		},
		yellow: {
			n: 2,
			of: 3
		},
		yellow2p: { n: 4 },
		equip: "random",
		features: []
	},
	{
		...T,
		id: 9,
		red: { n: 1 },
		red2p: { n: 2 },
		yellow: { n: 2 },
		yellow2p: { n: 4 },
		equip: "random",
		features: ["sequenceA"]
	},
	{
		...T,
		id: 10,
		red: { n: 1 },
		yellow: { n: 4 },
		equip: "random",
		equipExclude: [11],
		features: ["realtime"]
	},
	{
		...T,
		id: 11,
		red: { n: 0 },
		yellow: { n: 2 },
		yellow2p: { n: 4 },
		equip: "random",
		setupTokens: "captainNone",
		features: ["cursed"]
	},
	{
		...T,
		id: 12,
		red: { n: 1 },
		red2p: { n: 2 },
		yellow: { n: 4 },
		equip: "random",
		features: ["equipCover"]
	},
	{
		...T,
		id: 13,
		red: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		setupTokens: "random",
		features: ["redSeparate", "massCutRed3"]
	},
	{
		...T,
		id: 14,
		red: { n: 2 },
		red2p: { n: 3 },
		yellow: {
			n: 2,
			of: 3
		},
		yellow2p: { n: 4 },
		equip: "random",
		equipExclude: [9],
		features: ["intern"]
	},
	{
		...T,
		id: 15,
		red: {
			n: 1,
			of: 3
		},
		red2p: {
			n: 2,
			of: 3
		},
		yellow: { n: 0 },
		equip: "deck",
		features: ["equipDeck"]
	},
	{
		...T,
		id: 16,
		red: { n: 1 },
		red2p: { n: 2 },
		yellow: {
			n: 2,
			of: 3
		},
		yellow2p: { n: 4 },
		equip: "random",
		features: ["sequenceB"]
	},
	{
		...T,
		id: 17,
		red: {
			n: 2,
			of: 3
		},
		red2p: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		noDD2000: "captain",
		fakeTokens: "sergio",
		features: ["sergio"]
	},
	{
		...T,
		id: 18,
		red: { n: 2 },
		red2p: { n: 3 },
		yellow: { n: 0 },
		equip: "radar",
		setupTokens: "none",
		features: ["radarDeck"]
	},
	{
		...T,
		id: 19,
		red: { n: 1 },
		yellow: {
			n: 2,
			of: 3
		},
		equip: "random",
		features: []
	},
	{
		...T,
		id: 20,
		red: { n: 2 },
		red2p: {
			n: 2,
			of: 3
		},
		yellow: { n: 2 },
		yellow2p: { n: 4 },
		equip: "random",
		equipExclude: [2],
		features: ["xwires"]
	},
	{
		...T,
		id: 21,
		red: {
			n: 1,
			of: 2
		},
		red2p: { n: 2 },
		yellow: { n: 0 },
		equip: "random",
		setupTokens: "parity",
		tokenStyle: "parity",
		features: ["parityTokens"]
	},
	{
		...T,
		id: 22,
		red: { n: 1 },
		yellow: { n: 4 },
		equip: "random",
		setupTokens: "absent",
		features: ["absentTokens"]
	},
	{
		...T,
		id: 23,
		red: {
			n: 1,
			of: 3
		},
		red2p: {
			n: 2,
			of: 3
		},
		yellow: { n: 0 },
		equip: "pile",
		features: ["equipPile", "massCut4"]
	},
	{
		...T,
		id: 24,
		red: { n: 2 },
		red2p: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		setupTokens: "count",
		tokenStyle: "count",
		features: ["countTokens"]
	},
	{
		...T,
		id: 25,
		red: { n: 2 },
		red2p: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		features: []
	},
	{
		...T,
		id: 26,
		red: { n: 2 },
		yellow: { n: 0 },
		equip: "random",
		equipExclude: [10],
		features: ["numVisible"]
	},
	{
		...T,
		id: 27,
		red: { n: 1 },
		yellow: { n: 4 },
		equip: "random",
		equipExclude: [7],
		setupTokens: "captainNone",
		noDD2000: "all",
		features: ["noCharacters", "tokenDraft"]
	},
	{
		...T,
		id: 28,
		red: { n: 2 },
		red2p: { n: 3 },
		yellow: { n: 4 },
		equip: "random",
		noDD2000: "captain",
		features: ["lazyCaptain"]
	},
	{
		...T,
		id: 29,
		red: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		setupTokens: "captainNone",
		features: ["numHands"]
	},
	{
		...T,
		id: 31,
		red: {
			n: 2,
			of: 3
		},
		yellow: { n: 0 },
		equip: "random",
		features: ["constraintsChoose"]
	},
	{
		...T,
		id: 32,
		red: { n: 2 },
		red2p: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		features: ["constraintsDeck"]
	},
	{
		...T,
		id: 33,
		red: {
			n: 2,
			of: 3
		},
		red2p: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		setupTokens: "parity",
		tokenStyle: "parity",
		features: ["parityTokens"]
	},
	{
		...T,
		id: 34,
		red: { n: 1 },
		yellow: { n: 0 },
		equip: "random",
		minPlayers: 3,
		features: ["weakLink"]
	},
	{
		...T,
		id: 35,
		red: {
			n: 2,
			of: 3
		},
		red2p: { n: 3 },
		yellow: { n: 4 },
		equip: "random",
		equipExclude: [2],
		features: ["xwires", "xwiresGate"]
	},
	{
		...T,
		id: 36,
		red: {
			n: 1,
			of: 3
		},
		red2p: {
			n: 2,
			of: 3
		},
		yellow: { n: 2 },
		yellow2p: { n: 4 },
		equip: "random",
		features: ["sequenceDir"]
	},
	{
		...T,
		id: 37,
		red: { n: 2 },
		red2p: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		features: ["constraintsOnValidate"]
	},
	{
		...T,
		id: 38,
		red: { n: 2 },
		red2p: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		features: ["upsideCaptain"]
	},
	{
		...T,
		id: 39,
		red: {
			n: 2,
			of: 3
		},
		red2p: { n: 3 },
		yellow: { n: 4 },
		equip: "none",
		setupTokens: "random",
		features: ["slotCard", "massCut4"]
	},
	{
		...T,
		id: 40,
		red: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		setupTokens: "mixed",
		tokenStyle: "mixed",
		features: ["mixedTokens"]
	},
	{
		...T,
		id: 41,
		red: {
			n: 1,
			of: 3
		},
		red2p: {
			n: 2,
			of: 3
		},
		yellow: { n: -1 },
		yellow2p: { n: 2 },
		equip: "random",
		equipExclude: ["doubleFond"],
		dialPreSkull: !0,
		setupTokens: "random",
		features: ["iberian"]
	},
	{
		...T,
		id: 43,
		red: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		setupTokens: "captainRandom",
		features: ["nanoCollect"]
	},
	{
		...T,
		id: 44,
		red: {
			n: 1,
			of: 3
		},
		yellow: { n: 0 },
		equip: "random",
		equipExclude: [10],
		noXY: !0,
		features: ["oxygenPool"]
	},
	{
		...T,
		id: 45,
		red: { n: 2 },
		red2p: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		equipExclude: [10, 11],
		noXY: !0,
		features: ["squeak"]
	},
	{
		...T,
		id: 46,
		red: { n: 0 },
		yellow: { n: 4 },
		yellowFixed: [
			5.1,
			6.1,
			7.1,
			8.1
		],
		equip: "random",
		equipExclude: [7],
		setupTokens: "captainNone",
		features: ["sevensLast", "massCut4"]
	},
	{
		...T,
		id: 47,
		red: {
			n: 2,
			of: 3
		},
		yellow: { n: 0 },
		equip: "random",
		equipExclude: [10],
		noXY: !0,
		features: ["mathCards"]
	},
	{
		...T,
		id: 48,
		red: { n: 2 },
		red2p: { n: 3 },
		yellow: { n: 3 },
		equip: "random",
		features: ["yellowSeparate", "massCutYellow3"]
	},
	{
		...T,
		id: 49,
		red: { n: 2 },
		red2p: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		equipExclude: [10],
		noXY: !0,
		features: ["oxygenPerPlayer"]
	},
	{
		...T,
		id: 50,
		red: { n: 2 },
		red2p: { n: 3 },
		yellow: { n: 2 },
		yellow2p: { n: 4 },
		equip: "random",
		features: ["tokenBeside"]
	},
	{
		...T,
		id: 51,
		red: { n: 1 },
		red2p: { n: 2 },
		yellow: { n: 0 },
		equip: "random",
		equipExclude: [10],
		dialAdjust: 1,
		setupTokens: "captainNone",
		noXY: !0,
		features: ["bossDeck"]
	},
	{
		...T,
		id: 52,
		red: { n: 3 },
		yellow: { n: 0 },
		yellow2p: { n: 4 },
		equip: "random",
		equipExclude: [1, 12],
		setupTokens: "fake",
		fakeTokens: "all",
		features: ["fakeTokens"]
	},
	{
		...T,
		id: 53,
		red: { n: 2 },
		red2p: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		equipExclude: [6, 9],
		noDial: !0,
		features: ["nanoMove"]
	},
	{
		...T,
		id: 55,
		red: { n: 2 },
		red2p: {
			n: 2,
			of: 3
		},
		yellow: { n: 0 },
		equip: "random",
		dialPreSkull: !0,
		features: ["challenges"]
	},
	{
		...T,
		id: 56,
		red: {
			n: 2,
			of: 3
		},
		red2p: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		features: ["upside1"]
	},
	{
		...T,
		id: 57,
		red: { n: 1 },
		red2p: { n: 2 },
		yellow: { n: 0 },
		equip: "random",
		equipExclude: ["disintegrator"],
		features: ["constraintsByValidation"]
	},
	{
		...T,
		id: 58,
		red: { n: 2 },
		red2p: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		equipExclude: [4, 7],
		setupTokens: "none",
		tokenStyle: "none",
		unlimitedDD: !0,
		forceClassic: !0,
		features: ["tokenless"]
	},
	{
		...T,
		id: 59,
		red: {
			n: 2,
			of: 3
		},
		red2p: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		equipExclude: [10],
		features: ["nanoTrack"]
	},
	{
		...T,
		id: 60,
		red: {
			n: 2,
			of: 3
		},
		red2p: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		dialPreSkull: !0,
		features: ["challenges"]
	},
	{
		...T,
		id: 61,
		red: { n: 1 },
		red2p: { n: 2 },
		yellow: { n: 0 },
		equip: "random",
		features: ["constraintsPersonal"]
	},
	{
		...T,
		id: 62,
		red: { n: 2 },
		red2p: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		dialPreSkull: !0,
		features: ["bonusCards"]
	},
	{
		...T,
		id: 63,
		red: { n: 2 },
		red2p: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		equipExclude: [10],
		features: ["oxygenCaptain"]
	},
	{
		...T,
		id: 64,
		red: { n: 1 },
		red2p: { n: 2 },
		yellow: { n: 0 },
		equip: "random",
		features: ["upside2"]
	},
	{
		...T,
		id: 65,
		red: { n: 3 },
		yellow: { n: 0 },
		equip: "random",
		equipExclude: [10],
		noXY: !0,
		minPlayers: 3,
		features: ["handCards"]
	}
], re = new Map(ne.map((e) => [e.id, e])), ie = /* @__PURE__ */ "sequenceA.sequenceB.sequenceDir.cursed.equipDeck.radarDeck.squeak.bossDeck.numVisible.mathCards.slotCard.nanoCollect.nanoTrack.oxygenPool.oxygenPerPlayer.oxygenCaptain.constraintsChoose.constraintsDeck.constraintsOnValidate.constraintsByValidation.constraintsPersonal.weakLink.challenges.numHands.handCards.bonusCards".split(".");
function ae(e) {
	return e.blueMax !== 12 || e.features.some((e) => ie.includes(e));
}
var E = /* @__PURE__ */ new Set([
	19,
	30,
	42,
	54,
	66
]), oe = [
	"A",
	"B",
	"C",
	"D",
	"E"
], D = e.enum([
	"blue",
	"yellow",
	"red"
]), se = e.union([e.int().min(1).max(12), e.literal("yellow")]);
e.object({
	id: e.int(),
	color: D,
	sort: e.number(),
	cut: e.boolean(),
	x: e.boolean().optional(),
	upside: e.boolean().optional()
});
var O = e.discriminatedUnion("kind", [
	e.object({
		kind: e.literal("value"),
		value: e.int().min(1).max(12)
	}),
	e.object({ kind: e.literal("yellow") }),
	e.object({
		kind: e.literal("parity"),
		odd: e.boolean()
	}),
	e.object({
		kind: e.literal("count"),
		n: e.union([
			e.literal(1),
			e.literal(2),
			e.literal(3)
		])
	}),
	e.object({ kind: e.literal("eq") }),
	e.object({ kind: e.literal("neq") })
]), ce = e.object({
	wire: e.int(),
	token: O,
	fake: e.boolean()
}), k = e.enum([
	"neq",
	"talkies",
	"triple",
	"postit",
	"super",
	"rewinder",
	"batteries",
	"radar",
	"stabilizer",
	"xyray",
	"coffee",
	"eq",
	"fund",
	"disintegrator",
	"singleLabel",
	"threadCutter",
	"grapple",
	"doubleFond"
]), le = e.object({
	id: k,
	unlocked: e.boolean(),
	used: e.boolean(),
	cover: e.int().min(1).max(12).nullable()
}), A = e.enum([
	"dd2000",
	"xyray",
	"radar",
	"talkies",
	"triple"
]), ue = e.enum([
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G",
	"H",
	"I",
	"J",
	"K",
	"L"
]), de = e.object({
	mission: e.int().min(1).max(66).default(1),
	characters: e.enum(["classic", "mixed"]).default("classic"),
	markers: e.enum(["open", "hidden"]).default("open")
}).default({
	mission: 1,
	characters: "classic",
	markers: "open"
}), j = e.string(), M = e.int(), fe = e.object({
	a: M.optional(),
	b: M.optional(),
	target: j.optional(),
	myWire: M.optional(),
	theirWire: M.optional(),
	wire: M.optional(),
	token: O.optional(),
	value: e.int().min(1).max(12).optional(),
	rids: e.array(j).optional(),
	next: j.optional()
}), pe = e.discriminatedUnion("type", [
	e.object({
		type: e.literal("setupToken"),
		placements: e.array(e.object({
			wire: M,
			token: O
		})).min(1).max(2)
	}),
	e.object({
		type: e.literal("dual"),
		target: j,
		wires: e.array(M).min(1),
		guesses: e.array(se).min(1).max(2),
		mine: M.optional(),
		payTo: j.optional(),
		dd2000: e.boolean().optional(),
		boost: e.enum(["triple", "super"]).optional(),
		xyray: e.boolean().optional(),
		math: e.object({
			a: e.int().min(1).max(12),
			b: e.int().min(1).max(12)
		}).optional(),
		cover: e.int().min(1).max(12).optional()
	}),
	e.object({
		type: e.literal("solo"),
		value: se,
		payTo: j.optional(),
		math: e.object({
			a: e.int().min(1).max(12),
			b: e.int().min(1).max(12)
		}).optional(),
		cover: e.int().min(1).max(12).optional()
	}),
	e.object({ type: e.literal("reveal") }),
	e.object({ type: e.literal("pass") }),
	e.object({
		type: e.literal("equip"),
		id: e.union([k, e.literal("personal")]),
		params: fe.optional()
	}),
	e.object({
		type: e.literal("massCut"),
		picks: e.array(e.object({
			rid: j,
			wire: M
		})).min(1)
	}),
	e.object({
		type: e.literal("iberian"),
		target: j,
		wire: M
	}),
	e.object({
		type: e.literal("accuse"),
		target: j,
		constraint: ue
	}),
	e.object({
		type: e.literal("claim"),
		for: j.optional()
	}),
	e.object({
		type: e.literal("tick"),
		now: e.number()
	}),
	e.object({ type: e.literal("nextConstraint") }),
	e.object({
		type: e.literal("rotateConstraints"),
		dir: e.union([e.literal(1), e.literal(-1)])
	}),
	e.object({
		type: e.literal("respond"),
		kind: e.enum([
			"failToken",
			"pickToken",
			"passToken",
			"giveCard",
			"chooseConstraint",
			"swapConstraint",
			"placeCard",
			"moveSequence",
			"talkiesPick"
		]),
		placements: e.array(e.object({
			wire: M,
			token: O
		})).optional(),
		index: e.int().nonnegative().optional(),
		target: j.optional(),
		card: e.int().min(1).max(12).optional(),
		constraint: ue.optional(),
		end: e.enum(["left", "right"]).optional()
	})
]), me = e.object({
	id: e.int(),
	cut: e.boolean(),
	x: e.boolean().optional(),
	upside: e.boolean().optional(),
	tokens: e.array(ce),
	revealed: e.object({
		color: D,
		sort: e.number()
	}).nullable()
}), he = e.object({
	rid: j,
	kind: e.enum([
		"failToken",
		"pickToken",
		"passToken",
		"giveCard",
		"chooseConstraint",
		"placeCard",
		"moveSequence",
		"talkiesPick"
	]),
	cut: e.boolean().optional(),
	wires: e.array(e.int()).optional(),
	options: e.array(e.int()).optional(),
	fake: e.boolean().optional()
}), N = e.discriminatedUnion("k", [
	e.object({
		k: e.literal("dualOk"),
		from: j,
		to: j,
		guess: se,
		seq: e.int()
	}),
	e.object({
		k: e.literal("dualFail"),
		from: j,
		to: j,
		guess: se,
		seq: e.int()
	}),
	e.object({
		k: e.literal("solo"),
		rid: j,
		value: se,
		n: e.int(),
		seq: e.int()
	}),
	e.object({
		k: e.literal("reveal"),
		rid: j,
		n: e.int(),
		seq: e.int()
	}),
	e.object({
		k: e.literal("equip"),
		rid: j,
		id: e.string(),
		seq: e.int()
	}),
	e.object({
		k: e.literal("validate"),
		value: se,
		seq: e.int()
	}),
	e.object({
		k: e.literal("pass"),
		rid: j,
		seq: e.int()
	}),
	e.object({
		k: e.literal("claim"),
		rid: j,
		seq: e.int()
	}),
	e.object({
		k: e.literal("mass"),
		rid: j,
		n: e.int(),
		ok: e.boolean(),
		seq: e.int()
	}),
	e.object({
		k: e.literal("iberian"),
		from: j,
		to: j,
		ok: e.boolean(),
		seq: e.int()
	}),
	e.object({
		k: e.literal("accuse"),
		from: j,
		to: j,
		ok: e.boolean(),
		seq: e.int()
	}),
	e.object({
		k: e.literal("boom"),
		reason: e.enum([
			"red",
			"dial",
			"nano",
			"mass",
			"accuse",
			"timeout",
			"constrain",
			"lazy"
		]),
		seq: e.int()
	}),
	e.object({
		k: e.literal("radar"),
		rid: j,
		value: e.int(),
		yes: e.array(e.object({
			rid: j,
			rack: e.int()
		})),
		seq: e.int()
	})
]), P = e.object({
	actor: j,
	target: j.nullable(),
	values: e.array(se),
	wires: e.array(M),
	cut: e.array(M),
	outcome: e.enum([
		"success",
		"miss",
		"boom"
	]),
	hpDelta: e.int(),
	validated: e.array(se),
	equipments: e.array(k)
}), ge = e.object({
	value: e.int(),
	yes: e.array(e.object({
		rid: j,
		rack: e.int()
	}))
}), _e = P.extend({
	seq: e.int(),
	kind: e.enum([
		"dual",
		"solo",
		"mass",
		"iberian",
		"reveal",
		"equip"
	]),
	targets: e.array(e.object({
		wire: M,
		owner: j.nullable(),
		rack: e.int().nullable(),
		position: e.int().nullable(),
		revealed: e.object({
			color: D,
			sort: e.number()
		}).nullable()
	}))
}), ve = e.object({
	markers: e.object({
		red: e.array(e.object({
			v: e.int(),
			unsure: e.boolean()
		})),
		yellow: e.array(e.object({
			v: e.int(),
			unsure: e.boolean()
		}))
	}),
	sequence: e.object({
		cards: e.array(e.int()),
		at: e.int(),
		face: e.enum(["A", "B"]),
		dir: e.union([e.literal(1), e.literal(-1)])
	}).optional(),
	cursed: e.int().optional(),
	numDeck: e.object({
		current: e.int().nullable(),
		left: e.int()
	}).optional(),
	numVisible: e.array(e.int()).optional(),
	numHands: e.object({
		deckLeft: e.int(),
		placed: e.boolean(),
		revealed: e.int().nullable()
	}).optional(),
	slotCard: e.int().optional(),
	nano: e.object({
		pos: e.int(),
		dir: e.union([e.literal(1), e.literal(-1)]),
		nanoWires: e.int()
	}).optional(),
	nanoTrack: e.object({
		cards: e.array(e.int()),
		at: e.int(),
		flipped: e.boolean()
	}).optional(),
	oxygen: e.object({
		pool: e.int(),
		reserve: e.int(),
		perPlayer: e.record(e.string(), e.int()),
		holder: e.string().optional()
	}).optional(),
	constraints: e.object({
		active: e.array(ue),
		perPlayer: e.record(e.string(), ue.nullable()),
		deckLeft: e.int(),
		side: e.array(ue)
	}).optional(),
	challenges: e.array(e.object({
		id: e.int(),
		done: e.boolean()
	})).optional(),
	challenge8: e.array(e.int()).optional(),
	deadline: e.number().optional(),
	squeak: e.object({
		value: e.int(),
		claimed: j.nullable()
	}).optional(),
	bonusCards: e.array(e.int()).optional(),
	sevensOnly: e.boolean().optional(),
	handCards: e.record(e.string(), e.array(e.int())).optional(),
	handCardsDown: e.record(e.string(), e.array(e.int())).optional()
}), ye = e.object({
	mission: e.int(),
	phase: e.enum([
		"setup",
		"play",
		"resolving",
		"done"
	]),
	setupTurn: j.nullable(),
	turn: j.nullable(),
	forcedValue: e.int().nullable(),
	forcedBy: j.nullable(),
	captain: j,
	dial: e.object({
		step: e.int(),
		max: e.int()
	}).nullable(),
	stabilized: e.boolean(),
	players: e.array(e.object({
		rid: j,
		racks: e.array(e.array(me)),
		done: e.boolean(),
		character: e.object({
			id: A,
			used: e.boolean()
		}).nullable(),
		revealed: e.boolean()
	})),
	equipments: e.array(le),
	validated: e.array(e.int()),
	yellowDone: e.boolean(),
	mods: ve,
	pending: e.array(he),
	lastActor: j.nullable(),
	result: e.object({
		win: e.boolean(),
		reason: e.string()
	}).nullable(),
	cutBeat: P.nullable(),
	radarBeat: ge.nullable(),
	cutHistory: e.array(_e),
	log: e.array(N)
}), be = e.object({
	mine: e.array(e.object({
		wire: e.int(),
		color: D,
		sort: e.number()
	})),
	upsideVisible: e.array(e.object({
		wire: e.int(),
		color: D,
		sort: e.number()
	})),
	secretConstraint: ue.nullable(),
	handCards: e.array(e.int()),
	canPass: e.boolean()
}), F = (e) => re.get(e.mission), I = (e, t) => F(e).features.includes(t);
function L(e, n) {
	let r = t(e.seed, e.rng, n);
	return e.rng += 1, r;
}
function R(e, t) {
	for (let n = t.length - 1; n > 0; --n) {
		let r = L(e, n + 1);
		[t[n], t[r]] = [t[r], t[n]];
	}
	return t;
}
function z(e, t) {
	e.log.push({
		...t,
		seq: e.logSeq++
	}), e.log.length > 80 && e.log.splice(0, e.log.length - 80);
}
function xe(e) {
	let t = [];
	for (let n of e.players) for (let r of e.racks[n]) for (let e of r) t.push({
		wire: e,
		owner: n
	});
	if (e.mods.nano) for (let n of e.mods.nano.wires) t.push({
		wire: n,
		owner: "$nano"
	});
	return t;
}
function B(e, t) {
	for (let n of e.players) for (let r of e.racks[n]) {
		let e = r.find((e) => e.id === t);
		if (e) return {
			wire: e,
			owner: n,
			rack: r
		};
	}
	return null;
}
function V(e) {
	return e.color === "blue" ? Math.round(e.sort) : e.color;
}
function H(e, t) {
	return t.color === "red" || e.mods.cursed !== void 0 && t.color === "blue" && Math.round(t.sort) === e.mods.cursed;
}
function U(e, t) {
	return e.racks[t].flat().filter((e) => !e.cut);
}
function Se(e, t) {
	return xe(e).map((e) => e.wire).filter((e) => !e.cut && V(e) === t);
}
function Ce(e, t) {
	return xe(e).map((e) => e.wire).filter((e) => e.cut && V(e) === t).length;
}
function we(e, t) {
	return e.tokens.filter((e) => e.wire === t);
}
function Te(e, t) {
	return U(e, t).length === 0;
}
function Ee(e) {
	return e.players.filter((t) => !Te(e, t));
}
function W(e, t, n) {
	return e.maxDial < 0 ? !1 : (e.dial += t, n.push({
		kind: "dial",
		data: { step: e.dial }
	}), e.dial > e.maxDial && (G(e, "dial", n), !0));
}
function De(e, t, n) {
	e.maxDial < 0 || (e.dial = Math.max(0, e.dial - t), n.push({
		kind: "dial",
		data: { step: e.dial }
	}));
}
function G(e, t, n) {
	e.phase = "done", e.result = {
		win: !1,
		reason: t
	}, z(e, {
		k: "boom",
		reason: t === "win" ? "red" : t
	}), n.push({
		kind: "boom",
		data: { reason: t }
	});
}
function Oe(e, t, n, r) {
	t.cut = !0, n.push({
		kind: "cut",
		rid: r,
		data: {
			wire: t.id,
			color: t.color,
			sort: t.sort
		}
	});
	let i = V(t);
	i === "yellow" ? (e.cutYellows += 1, !e.yellowDone && Se(e, "yellow").length === 0 && (e.yellowDone = !0, z(e, {
		k: "validate",
		value: "yellow"
	}), je(e, "yellow", n)), I(e, "absentTokens") && !e.trig22 && e.cutYellows >= 2 && (e.trig22 = !0, Re(e)), I(e, "tokenDraft") && !e.trig27 && e.cutYellows >= 2 && (e.trig27 = !0, ze(e))) : typeof i == "number" && !e.validated.includes(i) && Se(e, i).length === 0 && (e.validated.push(i), z(e, {
		k: "validate",
		value: i
	}), n.push({
		kind: "validate",
		data: { value: i }
	}), je(e, i, n));
	let a = e.mods.sequence;
	if (a) {
		let t = a.dir === 1 ? a.cards[a.at] : a.cards[a.cards.length - 1 - a.at];
		t != null && Ce(e, t) >= (a.face === "A" ? 2 : 4) && (a.at += 1);
	}
	Ae(e), Ne(e, n);
}
var ke = {
	neq: 1,
	talkies: 2,
	triple: 3,
	postit: 4,
	super: 5,
	rewinder: 6,
	batteries: 7,
	radar: 8,
	stabilizer: 9,
	xyray: 10,
	coffee: 11,
	eq: 12,
	fund: 3,
	disintegrator: 10,
	singleLabel: 2,
	threadCutter: 9,
	grapple: 11,
	doubleFond: "yellow"
};
function Ae(e) {
	for (let t of e.equipments) t.unlocked || Ce(e, ke[t.id]) < 2 || t.cover !== null && Ce(e, t.cover) < 2 || (t.unlocked = !0);
}
function je(e, t, n) {
	if (typeof t == "number") {
		if (I(e, "equipDeck") && e.mods.numCurrent === t) {
			let t = e.equipHidden?.shift();
			for (t && (e.equipments.push({
				id: t,
				unlocked: !0,
				used: !1,
				cover: null
			}), n.push({
				kind: "equipIn",
				data: { id: t }
			})), Me(e); e.mods.numCurrent != null && e.validated.includes(e.mods.numCurrent);) Me(e);
		}
		if (e.mods.numVisible && !I(e, "mathCards") && (e.mods.numVisible = e.mods.numVisible.filter((e) => e !== t)), e.mods.handCards && e.mods.handCardsDown) for (let n of Object.keys(e.mods.handCards)) {
			let r = e.mods.handCards[n].filter((e) => e === t);
			r.length && (e.mods.handCards[n] = e.mods.handCards[n].filter((e) => e !== t), e.mods.handCardsDown[n] = [...e.mods.handCardsDown[n] ?? [], ...r]);
		}
		if (e.mods.numHands) {
			for (let n of Object.keys(e.mods.numHands.hands)) e.mods.numHands.hands[n] = e.mods.numHands.hands[n].filter((e) => e !== t);
			e.mods.numHands.deck = e.mods.numHands.deck.filter((e) => e !== t);
		}
		if (I(e, "constraintsOnValidate") && Le(e), I(e, "constraintsByValidation") && e.mods.constraints?.byValue) {
			let n = e.mods.constraints.byValue[t];
			n && (e.mods.constraints.active = [n]);
		}
		I(e, "bonusCards") && e.mods.bonusCards?.includes(t) && (e.mods.bonusCards = e.mods.bonusCards.filter((e) => e !== t), De(e, 1, n));
	}
}
function Me(e) {
	let t = e.mods.numDeck;
	t && (e.mods.numCurrent = t.pop() ?? null);
}
function Ne(e, t) {
	let n = e.mods.challenges;
	if (n) for (let r of n) r.done || Pe(e, r.id) && (r.done = !0, De(e, 1, t), t.push({
		kind: "challenge",
		data: { id: r.id }
	}));
}
function Pe(e, t) {
	let n = e.players.flatMap((t) => e.racks[t]);
	switch (t) {
		case 2: {
			let t = e.recentCuts;
			if (t.length < 4) return !1;
			let n = t.slice(-4);
			return new Set(n.map((e) => e.rid)).size === 4 && n.every((e) => typeof e.value == "number" && e.value % 2 == 0);
		}
		case 3: return n.some((e) => {
			let t = Fe(e);
			return t.length > 0 && t.every((e) => e === 2);
		});
		case 4: return e.validated.length >= 3 && e.validated[0] + e.validated[1] + e.validated[2] === 18;
		case 5: {
			let t = e.recentCuts;
			if (t.length < 2) return !1;
			let n = t.slice(-2);
			return n.every((e) => e.kind === "solo") && n[0].rid !== n[1].rid;
		}
		case 6: return n.some((e) => {
			let t = 0;
			for (let n = 0; n < e.length; n += 1) {
				if (e[n].cut) continue;
				let r = n === 0 || e[n - 1].cut, i = n === e.length - 1 || e[n + 1].cut;
				r && i && (t += 1);
			}
			return t >= 5;
		});
		case 7: {
			let t = e.recentCuts;
			if (t.length < 3) return !1;
			let n = t.slice(-3);
			if (new Set(n.map((e) => e.rid)).size !== 3 || n.some((e) => typeof e.value != "number")) return !1;
			let r = n.map((e) => e.value);
			return r[1] === r[0] + 1 && r[2] === r[1] + 1 || r[1] === r[0] - 1 && r[2] === r[1] - 1;
		}
		case 8: {
			let t = e.mods.challenge8;
			return !!t && e.validated.length >= 2 && t.includes(e.validated[0]) && t.includes(e.validated[1]);
		}
		case 9: return n.some((e) => {
			let t = e.filter((e) => !e.cut && e.color === "blue");
			return t.length >= 6 && t.every((e) => Math.round(e.sort) % 2 == 1);
		});
		case 10: return n.some((e) => e.filter((e) => e.cut).length >= 7 && e.length >= 2 && !e[0].cut && !e[e.length - 1].cut);
		default: return !1;
	}
}
function Fe(e) {
	let t = [], n = 0;
	for (let r of e) r.cut ? (n > 0 && t.push(n), n = 0) : n += 1;
	return n > 0 && t.push(n), t;
}
function Ie(e, t, n, r) {
	let i = e.mods.constraints;
	if (!i) return null;
	let a = [...i.active], o = i.perPlayer[t];
	o && a.push(o), I(e, "weakLink") && (a.length = 0, e.mods.weakLink?.rid === t && a.push(e.mods.weakLink.constraint));
	for (let e of a) {
		if (typeof n != "number") continue;
		let t = n;
		if (e === "A" && t % 2 == 1 || e === "B" && t % 2 == 0 || e === "C" && t > 6 || e === "D" && t < 7 || e === "E" && (t < 4 || t > 9) || e === "F" && t >= 4 && t <= 9) return { code: "games.bombbusters.errConstraint" };
	}
	return r && a.includes("K") ? { code: "games.bombbusters.errConstraint" } : null;
}
function K(e, t, n) {
	let r = e.mods.constraints;
	return r ? I(e, "weakLink") ? e.mods.weakLink?.rid === t && e.mods.weakLink.constraint === n : r.active.includes(n) || r.perPlayer[t] === n : !1;
}
function Le(e) {
	let t = e.mods.constraints;
	if (!t) return;
	let n = t.deck.pop();
	t.active = n ? [n] : [];
}
function Re(e) {
	let t = e.tokens.map((e, t) => e.fake ? t : -1).filter((e) => e >= 0);
	if (t.length === 0) return;
	let n = e.players.map((t, n) => e.players[(e.captain + n) % e.players.length]);
	e.pending.push({
		rid: n[0],
		kind: "passToken",
		options: t,
		wires: t.map((t) => e.tokens[t].wire),
		queue: n.slice(1)
	});
}
function ze(e) {
	let t = e.players.length, n = [];
	for (let r = 0; r < t; r += 1) n.push(1 + L(e, 12));
	let r = e.players.map((t, n) => e.players[(e.captain + n) % e.players.length]);
	e.pending.push({
		rid: r[0],
		kind: "pickToken",
		options: n,
		queue: r.slice(1)
	});
}
//#endregion
//#region src/games/bombbusters/rules.ts
var q = (e) => ({ code: `games.bombbusters.${e}` }), Be = [
	"dd2000",
	"xyray",
	"radar",
	"talkies",
	"triple"
], Ve = {
	1: "neq",
	2: "talkies",
	3: "triple",
	4: "postit",
	5: "super",
	6: "rewinder",
	7: "batteries",
	8: "radar",
	9: "stabilizer",
	10: "xyray",
	11: "coffee",
	12: "eq"
}, He = 1200, Ue = 2400;
function We(e, t, n) {
	let r = E.has(e.mission) ? 1 : e.mission, i = re.get(r), a = t.length === 2, o = a && i.red2p || i.red, s = a && i.yellow2p || i.yellow, c = {
		mission: r,
		players: [...t],
		captain: 0,
		seed: n,
		rng: 0,
		phase: "setup",
		cutBeat: null,
		radarBeat: null,
		cutHistory: [],
		phaseAfterBeat: null,
		setupQueue: [],
		turn: 0,
		acted: !1,
		lastActor: null,
		racks: {},
		tokens: [],
		dial: i.dialPreSkull ? t.length + i.dialAdjust - 1 : 0,
		maxDial: i.noDial ? -1 : t.length + i.dialAdjust,
		equipments: [],
		equipPile: null,
		equipHidden: null,
		characters: {},
		revealed: {},
		forcedValue: null,
		forcedBy: null,
		stabilized: !1,
		validated: [],
		yellowDone: !1,
		pending: [],
		passStreak: 0,
		recentCuts: [],
		cutYellows: 0,
		trig22: !1,
		trig27: !1,
		mods: { markers: {
			red: [],
			yellow: []
		} },
		log: [],
		logSeq: 0,
		result: null
	};
	c.captain = L(c, t.length);
	let l = 0, u = (e, t) => ({
		id: l++,
		color: e,
		sort: t,
		cut: !1
	}), d = [];
	for (let e = 1; e <= i.blueMax; e += 1) for (let t = 0; t < 4; t += 1) d.push(u("blue", e));
	let f = e.markers !== "hidden" && !J(i, "tokenBeside"), p = (e, t, n, r) => {
		if (e.n <= 0) return [];
		let i = [], a = e.of ?? e.n, o = [];
		for (let e = t; e <= n; e += 1) o.push(e);
		R(c, o);
		for (let e = 0; e < a && e < o.length; e += 1) i.push(o[e]);
		let s = i.slice(0, e.n);
		if (f) for (let t of i) c.mods.markers[r].push({
			v: Math.floor(t),
			unsure: i.length > e.n
		});
		return s.map((e) => u(r, e));
	}, m = i.redMax ?? 11.5, h = i.yellowMax ?? 11.1, g = J(i, "redSeparate") ? [] : p(o, 1.5, m, "red"), _ = i.yellowFixed, v = [];
	if (_) {
		if (f) for (let e of _) c.mods.markers.yellow.push({
			v: Math.floor(e),
			unsure: !1
		});
		v = _.map((e) => u("yellow", e));
	} else !J(i, "yellowSeparate") && !J(i, "iberian") && (v = p(s, 1.1, h, "yellow"));
	let y = J(i, "redSeparate") ? p(o, 1.5, m, "red") : [], b = [];
	J(i, "iberian") ? b = p({ n: Math.min(t.length === 5 ? 4 : t.length, 4) }, 1.1, h, "yellow") : J(i, "yellowSeparate") && (b = p(s, 1.1, h, "yellow"));
	let ee = (e) => t.length === 2 || t.length === 3 && e === t[c.captain] ? 2 : 1;
	for (let e of t) c.racks[e] = Array.from({ length: ee(e) }, () => []);
	if (J(i, "nanoCollect")) {
		let e = t.length === 2 ? 5 : t.length === 5 ? 3 : 4;
		R(c, d), c.mods.nano = {
			pos: 1,
			dir: 1,
			wires: d.splice(0, e)
		};
	}
	J(i, "nanoMove") && (c.mods.nano = {
		pos: 0,
		dir: 1,
		wires: []
	});
	let te = /* @__PURE__ */ new Map();
	if (J(i, "xwiresGate")) for (let e of t) for (let t = 0; t < c.racks[e].length; t += 1) {
		R(c, d);
		let n = d.pop();
		n.x = !0, te.set(`${e}:${t}`, [n]);
	}
	let x = R(c, [
		...d,
		...g,
		...v
	]), S = [];
	for (let e of t) for (let t = 0; t < c.racks[e].length; t += 1) S.push({
		rid: e,
		idx: t
	});
	let C = 0;
	for (; C < x.length;) for (let e of S) {
		if (C >= x.length) break;
		c.racks[e.rid][e.idx].push(x[C++]);
	}
	for (let e of t) for (let t of c.racks[e]) t.sort((e, t) => e.sort - t.sort);
	if (J(i, "xwiresGate")) for (let e of t) for (let t = 0; t < c.racks[e].length; t += 1) c.racks[e][t].push(...te.get(`${e}:${t}`));
	else if (J(i, "xwires")) for (let e of t) for (let t of c.racks[e]) t.length > 0 && (t[t.length - 1].x = !0);
	let w = (e, n = !1) => {
		let r = 0, i = t.map((e, n) => t[(c.captain + n) % t.length]).slice(+!!n), a = (e, t) => {
			let n = e.findIndex((e) => e.sort > t.sort);
			e.splice(n < 0 ? e.length : n, 0, t);
		};
		if (t.length === 2) for (let t of e) {
			let e = r % 2, n = r < 2 ? i[0] : i[1];
			a(c.racks[n][Math.min(e, c.racks[n].length - 1)], t), r += 1;
		}
		else for (let t of e) a(c.racks[i[r % i.length]][0], t), r += 1;
	};
	y.length && w(y), b.length && w(R(c, b), J(i, "iberian") && t.length === 5);
	let T = J(i, "upside2") ? 2 : +!!J(i, "upside1");
	if (T > 0) for (let e of t) {
		let t = c.racks[e].flat().filter((e) => e.color === "blue");
		R(c, t);
		for (let e of t.slice(0, T)) e.upside = !0;
	}
	if (J(i, "upsideCaptain")) {
		let e = t[c.captain], n = c.racks[e].flat().filter((e) => e.color === "blue");
		n.length && (n[L(c, n.length)].upside = !0);
	}
	Ge(c, i, t.length);
	let ne = i.forceClassic ? "classic" : e.characters;
	if (J(i, "noCharacters")) for (let e of t) c.characters[e] = null;
	else {
		let e = Be.filter((e) => !(i.noXY && e === "xyray"));
		for (let n of t) {
			let t = ne === "mixed" || J(i, "weakLink") ? e[L(c, e.length)] : "dd2000";
			c.characters[n] = {
				id: t,
				used: !1
			};
		}
		i.noDD2000 === "captain" && (c.characters[t[c.captain]] = null);
	}
	for (let e of t) c.revealed[e] = !0;
	Ke(c, i, t), Je(c, i, t);
	let ie = t.map((e, n) => ({
		kind: "deal",
		rid: e,
		data: { racks: c.racks[e].map((e) => e.length) },
		for: t.filter((t) => t !== e),
		secret: { wires: c.racks[e].flat().map((e) => ({
			wire: e.id,
			color: e.color,
			sort: e.sort,
			upside: !!e.upside
		})) },
		...n > 0 ? { with: !0 } : {}
	}));
	return c.setupQueue.length === 0 && c.pending.length === 0 && (c.phase = "play", c.turn = J(i, "realtime") ? -1 : c.captain, Ze(c)), {
		state: c,
		fx: ie
	};
}
function J(e, t) {
	return e.features.includes(t);
}
function Ge(e, t, n) {
	let r = w(t.id).map((e) => typeof e == "number" ? Ve[e] : e).filter((e) => !t.equipExclude.map((e) => typeof e == "number" ? Ve[e] : e).includes(e));
	if (t.equip === "none") return;
	if (t.equip === "radar") {
		e.equipments = [{
			id: "radar",
			unlocked: !0,
			used: !1,
			cover: null
		}];
		return;
	}
	if (t.equip === "pile") {
		e.equipPile = R(e, [...r]).slice(0, 7);
		return;
	}
	let i = R(e, [...r]).slice(0, n);
	if (t.equip === "deck") {
		e.equipHidden = i;
		return;
	}
	if (e.equipments = i.map((e) => ({
		id: e,
		unlocked: !1,
		used: !1,
		cover: null
	})), J(t, "equipCover")) {
		let t = R(e, [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			9,
			10,
			11,
			12
		]);
		e.equipments.forEach((e, n) => {
			e.cover = t[n];
		});
	}
}
function Ke(e, t, n) {
	let r = e.mods;
	if (J(t, "cursed")) {
		r.cursed = 1 + L(e, t.blueMax);
		let n = w(t.id).map((e) => typeof e == "number" ? Ve[e] : e).filter((t) => !e.equipments.some((e) => e.id === t) && ke[t] !== r.cursed);
		e.equipments = e.equipments.map((e) => {
			if (ke[e.id] !== r.cursed) return e;
			let t = n.pop();
			return t ? {
				...e,
				id: t
			} : e;
		}).filter((e) => ke[e.id] !== r.cursed);
	}
	if (J(t, "sequenceA") || J(t, "sequenceB") || J(t, "sequenceDir")) {
		let i = J(t, "sequenceDir") ? 5 : 3;
		r.sequence = {
			cards: R(e, [
				1,
				2,
				3,
				4,
				5,
				6,
				7,
				8,
				9,
				10,
				11,
				12
			]).slice(0, i),
			at: 0,
			face: J(t, "sequenceB") ? "B" : "A",
			dir: 1
		}, J(t, "sequenceDir") && e.pending.push({
			rid: n[e.captain],
			kind: "moveSequence"
		});
	}
	if ((J(t, "equipDeck") || J(t, "radarDeck") || J(t, "squeak") || J(t, "bossDeck")) && (r.numDeck = R(e, [
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9,
		10,
		11,
		12
	]), r.numCurrent = null, J(t, "equipDeck") && Me(e)), (J(t, "numVisible") || J(t, "mathCards")) && (r.numVisible = [
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9,
		10,
		11,
		12
	]), J(t, "numHands")) {
		let t = R(e, [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			9,
			10,
			11,
			12
		]), i = {}, a = n[(e.captain - 1 + n.length) % n.length];
		for (let e of n) i[e] = [];
		for (let r = 0; r < n.length * 2 + 1; r += 1) {
			let o = n[(e.captain + r) % n.length];
			i[o].length < (o === a ? 3 : 2) && i[o].push(t.pop());
		}
		r.numHands = {
			deck: t,
			hands: i,
			placed: null
		};
	}
	if (J(t, "equipPile") && (r.slotCard = 1 + L(e, 12)), J(t, "slotCard")) {
		let t = R(e, [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			9,
			10,
			11,
			12
		]);
		r.slotCard = t[0], r.numDeck = t.slice(1, 9);
	}
	if (J(t, "nanoTrack")) {
		let t = R(e, [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			9,
			10,
			11,
			12
		]);
		r.nanoTrack = {
			cards: t,
			at: t.indexOf(7),
			flipped: !1
		};
	}
	if (J(t, "oxygenPool") && (r.oxygen = {
		mode: "pool",
		pool: n.length * 2,
		perPlayer: {},
		holder: "",
		initial: n.length * 2
	}), J(t, "oxygenPerPlayer")) {
		let e = n.length === 2 ? 7 : n.length === 3 ? 6 : n.length === 4 ? 5 : 4, t = {};
		for (let r of n) t[r] = e;
		r.oxygen = {
			mode: "perPlayer",
			pool: 0,
			perPlayer: t,
			holder: "",
			initial: e
		};
	}
	if (J(t, "oxygenCaptain")) {
		let t = n.length === 2 ? 14 : n.length === 3 ? 18 : n.length === 4 ? 24 : 30;
		r.oxygen = {
			mode: "captain",
			pool: 0,
			perPlayer: {},
			holder: n[e.captain],
			initial: t
		}, r.oxygen.perPlayer[n[e.captain]] = t;
	}
	if (J(t, "constraintsDeck") || J(t, "constraintsOnValidate")) {
		let t = R(e, [...qe]);
		r.constraints = {
			deck: t,
			active: [t.pop()],
			perPlayer: {},
			side: []
		};
	}
	if (J(t, "constraintsChoose")) {
		r.constraints = {
			deck: [],
			active: [],
			perPlayer: {},
			side: []
		};
		let t = n.map((t, r) => n[(e.captain + r) % n.length]);
		e.pending.push({
			rid: t[0],
			kind: "chooseConstraint",
			options: [
				0,
				1,
				2,
				3,
				4
			],
			queue: t.slice(1)
		});
	}
	if (J(t, "weakLink")) {
		r.weakLink = {
			rid: n[L(e, n.length)],
			constraint: oe[L(e, oe.length)]
		};
		for (let t of n) e.revealed[t] = !1;
	}
	if (J(t, "constraintsPersonal")) {
		let t = R(e, [...oe]), i = {};
		n.forEach((e, n) => {
			i[e] = t[n];
		});
		let a = [];
		n.length === 2 && a.push(t[2], t[3]), n.length === 3 && a.push(t[3]), r.constraints = {
			deck: [],
			active: [],
			perPlayer: i,
			side: a
		};
	}
	if (J(t, "constraintsByValidation")) {
		let t = {}, n = R(e, [...qe]);
		for (let e = 1; e <= 12; e += 1) t[e] = n[e - 1];
		r.constraints = {
			deck: [],
			active: [],
			perPlayer: {},
			side: [],
			byValue: t
		}, r.numVisible = [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			9,
			10,
			11,
			12
		];
	}
	if (J(t, "challenges")) {
		let t = R(e, [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			9,
			10
		]).slice(0, n.length);
		r.challenges = t.map((e) => ({
			id: e,
			done: !1
		})), t.includes(8) && (r.challenge8 = R(e, [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			9,
			10,
			11,
			12
		]).slice(0, 2));
	}
	if (J(t, "bonusCards") && (r.bonusCards = R(e, [
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9,
		10,
		11,
		12
	]).slice(0, n.length)), J(t, "handCards")) {
		let t = R(e, [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			9,
			10,
			11,
			12
		]), i = {}, a = {};
		for (let e of n) i[e] = [], a[e] = [];
		t.forEach((t, r) => i[n[(e.captain + r) % n.length]].push(t)), r.handCards = i, r.handCardsDown = a;
	}
	J(t, "realtime") && (r.deadline = -1);
}
var qe = [
	"A",
	"B",
	"C",
	"D",
	"E",
	"F",
	"G",
	"H",
	"I",
	"J",
	"K",
	"L"
];
function Je(e, t, n) {
	let r = t.setupTokens;
	if (r === "none") return;
	let i = n[e.captain], a = n.map((t, r) => n[(e.captain + r) % n.length]), o = (t) => {
		let n = U(e, t).filter((e) => e.color === "blue" && !e.upside);
		if (!n.length) return;
		let r = n[L(e, n.length)];
		e.tokens.push({
			wire: r.id,
			token: {
				kind: "value",
				value: Math.round(r.sort)
			},
			fake: !1
		});
	};
	if (r === "random") {
		let e = n.length === 2 && J(t, "redSeparate") ? a.filter((e) => e !== i) : a;
		for (let t of e) o(t);
		return;
	}
	if (r === "captainRandom" && n.length === 2) {
		o(i), e.setupQueue = a.filter((e) => e !== i);
		return;
	}
	if (r === "captainNone" && n.length === 2) {
		e.setupQueue = a.filter((e) => e !== i);
		return;
	}
	if (r === "mixed" && n.length === 2) {
		e.setupQueue = [a[1]];
		return;
	}
	e.setupQueue = a;
}
function Ye(e, t) {
	let n = U(e, t);
	return !!(n.length === 0 || I(e, "iberian") && n.every((e) => e.color !== "blue"));
}
function Xe(e) {
	if (I(e, "realtime")) {
		e.lastActor = e.players[e.turn] ?? e.lastActor, e.turn = -1;
		return;
	}
	if (I(e, "squeak")) {
		e.turn = e.captain, Ze(e);
		return;
	}
	let t = e.players.length;
	for (let n = 1; n <= t; n += 1) {
		let r = (e.turn + n) % t;
		if (r === e.captain && Ye(e, e.players[r]) && mt(e), !Ye(e, e.players[r])) {
			e.turn = r;
			break;
		}
	}
	Ze(e);
}
function Ze(e) {
	let t = F(e), n = e.players[e.turn];
	if (n) {
		if (e.stabilized = !1, e.acted = !1, e.turn === e.captain && !e.mods.massDone && (e.equipPile && e.equipPile.length > 0 ? e.equipPile.pop() : I(e, "slotCard") && e.mods.numDeck && e.mods.numDeck.length > 0 && e.mods.numDeck.pop()), t.unlimitedDD) {
			let t = e.characters[n];
			t && t.id === "dd2000" && (t.used = !1);
		}
		if ((I(e, "oxygenPool") || I(e, "oxygenCaptain")) && e.turn === e.captain && mt(e), I(e, "numHands") && e.mods.numHands && !e.mods.numHands.placed) {
			let t = e.players[(e.turn - 1 + e.players.length) % e.players.length];
			(e.mods.numHands.hands[t] ?? []).length > 0 && e.pending.push({
				rid: t,
				kind: "placeCard"
			});
		}
		if ((I(e, "radarDeck") || I(e, "squeak") || I(e, "bossDeck")) && e.mods.numCurrent == null && (Me(e), e.mods.numCurrent == null && e.mods.numDeck && (e.mods.numDeck = R(e, [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			9,
			10,
			11,
			12
		].filter((t) => !e.validated.includes(t))), Me(e)), e.mods.numCurrent != null)) {
			if (I(e, "radarDeck")) {
				let t = e.mods.numCurrent, r = Mt(e, t);
				z(e, {
					k: "radar",
					rid: n,
					value: t,
					yes: r
				}), e.radarBeat = {
					value: t,
					yes: r
				}, e.phase === "play" && (e.phase = "resolving", e.phaseAfterBeat = "play"), e.forcedValue = t, e.forcedBy = null;
			} else e.forcedValue = e.mods.numCurrent, e.forcedBy = null;
		}
		if (I(e, "constraintsChoose") && e.mods.constraints) {
			let t = e.mods.constraints.perPlayer[n];
			t && !Qe(e, n, t) && (e.mods.constraints.perPlayer[n] = null);
		}
		if (I(e, "sevensLast")) {
			let t = Ee(e).flatMap((t) => U(e, t)).filter((e) => e.color === "blue");
			e.mods.sevensOnly = t.length > 0 && t.every((e) => Math.round(e.sort) === 7);
		}
	}
}
function Qe(e, t, n) {
	let r = U(e, t).filter((e) => e.color === "blue"), i = (e) => !(n === "A" && e % 2 == 1 || n === "B" && e % 2 == 0 || n === "C" && e > 6 || n === "D" && e < 7 || n === "E" && (e < 4 || e > 9) || n === "F" && e >= 4 && e <= 9);
	return r.some((e) => i(Math.round(e.sort)));
}
function $e(e, t, n) {
	if (t.type === "tick") {
		if (e.phase === "resolving") {
			let n = structuredClone(e), r = [];
			return n.cutBeat && n.radarBeat ? (n.cutBeat = null, {
				state: n,
				fx: r
			}) : (n.phase = n.phaseAfterBeat ?? "play", n.phaseAfterBeat = null, n.cutBeat = null, n.radarBeat = null, n.phase === "play" && n.mods.deadline !== void 0 && n.mods.deadline >= 0 && t.now >= n.mods.deadline && G(n, "timeout", r), {
				state: n,
				fx: r
			});
		}
		if (e.phase !== "play" || e.mods.deadline === void 0) return {
			state: e,
			fx: []
		};
		let n = structuredClone(e), r = [];
		return n.mods.deadline < 0 ? n.mods.deadline = t.now + 9e5 : t.now >= n.mods.deadline && G(n, "timeout", r), {
			state: n,
			fx: r
		};
	}
	if (e.phase === "done") return q("errDone");
	if (e.phase === "resolving") return q("errPhase");
	if (e.pending.length > 0 && (t.type !== "respond" || n.by !== e.pending[0].rid) && (t.type !== "respond" || t.kind !== "swapConstraint")) return q("errPending");
	let r = structuredClone(e), i = [];
	if (r.phase === "setup") return tt(r, t, n, i);
	switch (t.type) {
		case "respond": return jt(r, t, n, i);
		case "claim": return Ot(r, t, n, i);
		case "equip": return Pt(r, t, n, i);
		case "nextConstraint": return kt(r, n, i);
		case "rotateConstraints": return At(r, t, n, i);
		case "accuse": return Dt(r, t, n, i);
		case "dual": return vt(r, t, n, i);
		case "solo": return yt(r, t, n, i);
		case "reveal": return bt(r, n, i);
		case "pass": return Ct(r, n, i);
		case "massCut": return wt(r, t, n, i);
		case "iberian": return Et(r, t, n, i);
		default: return q("errPhase");
	}
}
function et(e, t, n) {
	let r = t.type === "respond" && e.pending[0]?.kind === "failToken" && e.pending[0].cut ? e.pending[0] : null, i = t.type === "dual" || t.type === "solo" || t.type === "massCut" || t.type === "iberian" || t.type === "reveal" || t.type === "equip" && (t.id === "threadCutter" || t.id === "disintegrator") || !!r, a = $e(e, t, n);
	if (!("state" in a) || !i) return a;
	let o = a.state, s = a.fx.filter((e) => e.kind === "cut").flatMap((e) => {
		let t = e.data?.wire;
		return t == null ? [] : [t];
	}), c = o.result?.win === !1 && e.result === null, l = t.type === "dual" && !o.pending.some((e) => e.kind === "failToken" && e.cut && e.actor === n.by) || t.type === "massCut" || t.type === "iberian";
	if (s.length === 0 && !c && !l) return a;
	let u = null, d = [], f = [];
	switch (t.type) {
		case "dual":
			u = t.target, d = t.xyray ? t.guesses : t.guesses.slice(0, 1), f = t.wires;
			break;
		case "solo":
			d = [t.value], f = U(e, n.by).filter((e) => V(e) === t.value).map((e) => e.id);
			break;
		case "massCut":
			f = t.picks.map((e) => e.wire);
			break;
		case "iberian":
			u = t.target, d = ["yellow"], f = [t.wire];
			break;
		case "reveal":
			f = U(e, n.by).map((e) => e.id);
			break;
		case "equip":
			if (f = t.id === "threadCutter" ? [t.params?.a, t.params?.b].filter((e) => e != null) : s, t.id === "disintegrator" && s.length > 0) {
				let e = B(o, s[0])?.wire;
				e?.color === "blue" && (d = [Math.round(e.sort)]);
			}
			break;
		case "respond": r && (u = r.rid, d = r.values ?? (r.value == null ? [] : [r.value]), f = [r.wires?.[t.index ?? -1]].filter((e) => e != null));
	}
	let p = r?.actor ?? n.by, m = e.equipments, h = o.equipments.flatMap((e, t) => {
		let n = m[t];
		return !n || n.unlocked !== e.unlocked || n.used !== e.used ? [e.id] : [];
	}), g = {
		actor: p,
		target: u,
		values: d,
		wires: [.../* @__PURE__ */ new Set([...f, ...s])],
		cut: s,
		outcome: c ? "boom" : s.length > 0 ? "success" : "miss",
		hpDelta: o.dial - e.dial,
		validated: [...o.validated.filter((t) => !e.validated.includes(t)), ...o.yellowDone && !e.yellowDone ? ["yellow"] : []],
		equipments: h
	}, _ = new Map(a.fx.filter((e) => e.kind === "cut").flatMap((e) => {
		let t = e.data;
		return t?.wire != null && t.color != null && t.sort != null ? [[t.wire, {
			color: t.color,
			sort: t.sort
		}]] : [];
	}));
	return o.cutHistory.push({
		...g,
		seq: o.logSeq++,
		kind: r ? "dual" : t.type === "massCut" ? "mass" : t.type === "iberian" ? "iberian" : t.type === "solo" ? "solo" : t.type === "reveal" ? "reveal" : t.type === "dual" ? "dual" : "equip",
		targets: g.wires.map((t) => {
			for (let n of e.players) for (let r = 0; r < e.racks[n].length; r += 1) {
				let i = e.racks[n][r].findIndex((e) => e.id === t);
				if (i >= 0) return {
					wire: t,
					owner: n,
					rack: r + 1,
					position: i + 1,
					revealed: _.get(t) ?? null
				};
			}
			return {
				wire: t,
				owner: null,
				rack: null,
				position: null,
				revealed: _.get(t) ?? null
			};
		})
	}), o.phaseAfterBeat = o.phase === "done" ? "done" : "play", o.phase = "resolving", o.cutBeat = g, {
		state: o,
		fx: [{
			kind: "cutResult",
			rid: p,
			data: {
				...g,
				ms: I(o, "realtime") ? 550 : He
			}
		}]
	};
}
function tt(e, t, n, r) {
	if (t.type === "respond") {
		let i = jt(e, t, n, r);
		return "code" in i || e.pending.length === 0 && e.setupQueue.length === 0 && (e.phase = "play", e.turn = I(e, "realtime") ? -1 : e.captain, Ze(e)), i;
	}
	if (t.type !== "setupToken") return q("errPhase");
	if (e.pending.length > 0) return q("errPending");
	if (e.setupQueue[0] !== n.by) return q("errNotYourTurn");
	let i = F(e), a = i.fakeTokens === "sergio" && it(e, n.by), o = i.setupTokens === "absent" || i.setupTokens === "fake" || a ? 2 : 1;
	if (t.placements.length !== o) return q("errSetupToken");
	for (let r of t.placements) {
		let t = B(e, r.wire);
		if (!t || t.owner !== n.by || t.wire.cut) return q("errSetupToken");
		let i = nt(e, n.by, t.wire, r.token);
		if (i) return i;
	}
	for (let n of t.placements) {
		let t = i.setupTokens === "absent" || i.setupTokens === "fake" || a;
		e.tokens.push({
			wire: n.wire,
			token: n.token,
			fake: t
		});
	}
	return e.setupQueue.shift(), e.setupQueue.length === 0 && e.pending.length === 0 && (e.phase = "play", e.turn = I(e, "realtime") ? -1 : e.captain, Ze(e)), {
		state: e,
		fx: r
	};
}
function nt(e, t, n, r) {
	let i = F(e), a = i.setupTokens, o = new Set(U(e, t).map((e) => V(e)));
	if (i.fakeTokens === "sergio" && it(e, t)) return r.kind !== "value" || n.color !== "blue" || r.value === Math.round(n.sort) ? q("errSetupToken") : null;
	switch (a) {
		case "standard":
		case "captainNone":
		case "captainRandom": return r.kind !== "value" || n.color !== "blue" || r.value !== Math.round(n.sort) ? q("errSetupToken") : null;
		case "parity": return r.kind !== "parity" || n.color !== "blue" || r.odd !== (Math.round(n.sort) % 2 == 1) ? q("errSetupToken") : null;
		case "count": {
			if (r.kind !== "count" || n.color !== "blue") return q("errSetupToken");
			let i = U(e, t).filter((e) => e.color === "blue" && Math.round(e.sort) === Math.round(n.sort)).length;
			return r.n === i ? null : q("errSetupToken");
		}
		case "absent":
			if ([
				1,
				2,
				3,
				4,
				5,
				6,
				7,
				8,
				9,
				10,
				11,
				12
			].every((e) => o.has(e)) && o.has("yellow")) return r.kind === "value" || r.kind === "yellow" ? null : q("errSetupToken");
			if (r.kind === "value") {
				if (o.has(r.value)) return q("errSetupToken");
			} else if (r.kind === "yellow") {
				if (o.has("yellow")) return q("errSetupToken");
			} else return q("errSetupToken");
			return null;
		case "fake": return n.color === "yellow" || r.kind !== "value" || n.color === "blue" && r.value === Math.round(n.sort) ? q("errSetupToken") : null;
		case "mixed":
			if ((e.players.indexOf(t) - e.captain + e.players.length) % e.players.length % 2 == 0) {
				if (r.kind !== "count" || n.color !== "blue") return q("errSetupToken");
				let i = U(e, t).filter((e) => e.color === "blue" && Math.round(e.sort) === Math.round(n.sort)).length;
				if (r.n !== i) return q("errSetupToken");
			} else if (r.kind !== "parity" || n.color !== "blue" || r.odd !== (Math.round(n.sort) % 2 == 1)) return q("errSetupToken");
			return null;
		default: return q("errSetupToken");
	}
}
function rt(e, t) {
	return F(e), I(e, "realtime") ? e.turn < 0 || e.players[e.turn] !== t ? q("errNotYourTurn") : null : I(e, "squeak") ? e.forcedBy === t ? null : q("errNotYourTurn") : I(e, "radarDeck") || I(e, "bossDeck") ? e.forcedBy ? e.forcedBy === t ? null : q("errNotYourTurn") : e.players[e.turn] === t ? null : q("errNotYourTurn") : e.turn < 0 || e.players[e.turn] !== t ? q("errNotYourTurn") : null;
}
var it = (e, t) => e.players[e.captain] === t, Y = (e, t) => (I(e, "intern") || I(e, "lazyCaptain")) && it(e, t), at = (e, t) => (I(e, "sergio") || I(e, "lazyCaptain")) && it(e, t);
function ot(e) {
	return e.color === "yellow" ? { kind: "yellow" } : {
		kind: "value",
		value: Math.round(e.sort)
	};
}
function st(e, t, n) {
	if (I(e, "tokenless")) return null;
	let r = V(n), i = F(e).tokenStyle;
	if (r === "red") return null;
	if (typeof r != "number") return i === "value" ? ot(n) : null;
	let a = i === "mixed" ? (e.players.indexOf(t) - e.captain + e.players.length) % e.players.length % 2 == 0 ? "count" : "parity" : i;
	if (a === "parity") return {
		kind: "parity",
		odd: r % 2 == 1
	};
	if (a === "count") {
		let n = e.racks[t].flat().filter((e) => e.color === "blue" && Math.round(e.sort) === r).length;
		return n < 1 || n > 3 ? null : {
			kind: "count",
			n
		};
	}
	return ot(n);
}
function ct(e, t) {
	return e.equipments.find((e) => e.id === t) ?? null;
}
function lt(e, t, n, r, i, a) {
	if (e.forcedValue != null && n !== e.forcedValue) return q("errBadGuess");
	let o = e.mods.sequence;
	if (o && typeof n == "number" && !e.validated.includes(n)) {
		let e = o.dir === 1 ? o.cards.slice(o.at) : o.cards.slice(0, o.cards.length - o.at).reverse();
		if (e.includes(n) && e[0] !== n) return q("errSequence");
	}
	if (I(e, "numVisible") && !I(e, "mathCards")) {
		let t = e.mods.numVisible;
		if (r.cover == null || !t.includes(r.cover) || (e.mods.numVisible = t.filter((e) => e !== r.cover), e.mods.numVisible.length === 0 && (e.mods.numVisible = [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			9,
			10,
			11,
			12
		].filter((t) => !e.validated.includes(t))), !e.mods.numVisible.includes(n))) return q("errBadGuess");
	}
	if (I(e, "mathCards")) {
		let t = r.math;
		if (!t || typeof n != "number") return q("errMath");
		let i = e.mods.numVisible;
		if (!i.includes(t.a) || !i.includes(t.b) || t.a === t.b && i.filter((e) => e === t.a).length < 2 || t.a + t.b !== n && Math.abs(t.a - t.b) !== n) return q("errMath");
		e.mods.numVisible = i.filter((e) => e !== t.a && e !== t.b);
	}
	if (I(e, "handCards") && typeof n == "number" && !(e.mods.handCards?.[t] ?? []).includes(n)) return q("errHandCard");
	if (e.mods.nanoTrack) {
		let t = e.mods.nanoTrack;
		if (typeof n != "number") return q("errNano");
		let r = t.cards.indexOf(n);
		if (r < 0 || e.validated.includes(n) || !(t.flipped ? r < t.at : r > t.at)) return q("errNano");
		t.at = r;
	}
	return Ie(e, t, n, i) || null;
}
function ut(e, t, n, r) {
	let i = e.mods.oxygen;
	if (!i) return null;
	if (i.mode === "pool") {
		let e = typeof n == "number" ? n : 1, t = e <= 4 ? 1 : e <= 8 ? 2 : 3;
		return i.pool < t ? q("errOxygen") : (i.pool -= t, null);
	}
	if (i.mode === "perPlayer") {
		let a = typeof n == "number" ? n : 1;
		return !r || r === t || !e.players.includes(r) || (i.perPlayer[t] ?? 0) < a ? q("errOxygen") : (i.perPlayer[t] -= a, i.perPlayer[r] = (i.perPlayer[r] ?? 0) + a, null);
	}
	let a = typeof n == "number" ? n : 1;
	return (i.perPlayer[i.holder] ?? 0) < a ? q("errOxygen") : (i.perPlayer[i.holder] -= a, null);
}
function dt(e, t) {
	return !e.players.every((t) => U(e, t).length === 0) || e.mods.nano && e.mods.nano.wires.length > 0 ? !1 : (e.phase = "done", e.result = {
		win: !0,
		reason: "win"
	}, t.push({ kind: "win" }), !0);
}
function ft(e) {
	let t = e.mods.nano;
	t && (t.pos += t.dir, t.pos > 12 ? (t.pos = 11, t.dir = -1) : t.pos < 1 && (t.pos = 2, t.dir = 1));
}
function pt(e, t) {
	let n = e.mods.oxygen;
	if (n?.mode !== "captain") return;
	let r = e.players.indexOf(t), i = e.players[(r + 1) % e.players.length];
	n.perPlayer[i] = n.perPlayer[t] ?? 0, n.perPlayer[t] = 0, n.holder = i;
}
function mt(e) {
	let t = e.mods.oxygen;
	t && (t.mode === "pool" && (t.pool = t.initial), t.mode === "captain" && (t.perPlayer[t.holder] = t.initial));
}
function X(e, t, n, r, i) {
	if (e.phase === "done") return;
	e.acted = !0, r !== "pass" && (e.passStreak = 0);
	let a = e.mods.numHands;
	if (a?.placed && !a.placed.revealed) {
		a.placed.revealed = !0, i.includes(a.placed.card) && W(e, 1, t), e.validated.includes(a.placed.card) || (a.hands[n] = [...a.hands[n] ?? [], a.placed.card]);
		for (let t of e.players) {
			let n = a.hands[t] ?? [];
			if (n.length <= 1) {
				let r = a.deck.pop();
				for (; r != null && e.validated.includes(r);) r = a.deck.pop();
				r != null && (a.hands[t] = [...n, r]);
			}
		}
		if (e.validated.length >= 11) {
			for (let t of e.players) a.hands[t] = [];
			a.deck = [];
		}
	}
	if (I(e, "nanoCollect") && ft(e), I(e, "nanoMove") && e.mods.nano) {
		let n = e.mods.nano;
		if (r === "fail" ? n.pos += 2 : r === "ok" && (n.pos += i.includes(n.pos) ? -1 : 1), n.pos < 0 && (n.pos = 0), n.pos > 12) {
			G(e, "nano", t);
			return;
		}
	}
	if (pt(e, n), (I(e, "numVisible") || I(e, "mathCards")) && e.mods.numVisible && e.mods.numVisible.length === 0 && (e.mods.numVisible = I(e, "mathCards") ? [
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9,
		10,
		11,
		12
	] : [
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9,
		10,
		11,
		12
	].filter((t) => !e.validated.includes(t))), (I(e, "squeak") || I(e, "radarDeck") || I(e, "bossDeck")) && (e.mods.numCurrent = null, e.forcedValue = null, e.forcedBy = null), !dt(e, t)) {
		if (I(e, "handCards") && (e.mods.handCards?.[n] ?? []).length + (e.mods.handCardsDown?.[n] ?? []).length > 0) {
			e.pending.push({
				rid: n,
				kind: "giveCard"
			});
			return;
		}
		Xe(e);
	}
}
function ht(e, t, n, r) {
	Oe(e, t, n, r);
	let i = V(t);
	if (I(e, "nanoCollect") && e.mods.nano && typeof i == "number" && i === e.mods.nano.pos && e.mods.nano.wires.length > 0) {
		let t = e.mods.nano.wires.pop(), i = e.racks[r][0];
		i.push(t), i.sort((e, t) => e.sort - t.sort), n.push({
			kind: "nanoTake",
			rid: r,
			data: { wire: t.id },
			for: e.players.filter((e) => e !== r),
			secret: {
				color: t.color,
				sort: t.sort
			}
		});
	}
}
function gt(e, t) {
	return I(e, "sevensLast") && t === 7 && !e.mods.sevensOnly;
}
function _t(e, t, n, r) {
	e.recentCuts.push({
		rid: t,
		value: n,
		kind: r
	}), e.recentCuts.length > 8 && e.recentCuts.shift();
}
function vt(e, t, n, r) {
	let i = rt(e, n.by);
	if (i) return i;
	let a = n.by;
	if (t.target === a || !e.players.includes(t.target)) return q("errBadTarget");
	if (I(e, "massCutRed3") && U(e, a).every((e) => e.color === "red")) return q("errMassCount");
	if (e.mods.sevensOnly) return q("errMassValue");
	let o = [];
	for (let n of t.wires) {
		let r = B(e, n);
		if (!r || r.owner !== t.target || r.wire.cut || o.includes(r.wire)) return q("errBadWire");
		o.push(r.wire);
	}
	let s = t.dd2000 ? "dd2000" : t.boost ?? null, c = t.xyray ? t.guesses : [t.guesses[0]];
	if (t.xyray && (t.guesses.length !== 2 || t.guesses[0] === t.guesses[1]) || s && c[0] === "yellow" || (I(e, "iberian") || I(e, "yellowSeparate")) && c.includes("yellow")) return q("errBadGuess");
	if (!s && o.length !== 1 || s === "dd2000" && o.length !== 2 || s === "triple" && o.length !== 3) return q("errBadWire");
	if (s === "super") {
		let n = (e.racks[t.target].find((e) => e.some((e) => e.id === o[0].id)) ?? []).filter((e) => !e.cut && !e.x);
		if (o.length !== n.length || !n.every((e) => o.includes(e))) return q("errBadWire");
	}
	for (let n of o) {
		if (n.x && I(e, "xwiresGate") && !e.yellowDone || n.x && s) return q("errXwire");
		if (n.upside && (s || t.xyray) || n.upside && I(e, "upsideCaptain")) return q("errBadWire");
		if (K(e, a, "H") && we(e, n.id).length > 0) return q("errConstraint");
		if (K(e, a, "I") || K(e, a, "J")) {
			let r = (e.racks[t.target].find((e) => e.includes(n)) ?? []).filter((e) => !e.cut);
			if ((K(e, a, "I") ? r[r.length - 1] : r[0]) === n) return q("errConstraint");
		}
	}
	if (t.dd2000) {
		let t = e.characters[a];
		if (!t || t.id !== "dd2000" || t.used || F(e).noDD2000 === "all" || !e.revealed[a]) return q("errNoPersonal");
		if (K(e, a, "G")) return q("errConstraint");
	}
	if (t.boost) {
		let n = ct(e, t.boost), r = e.characters[a], i = n && n.unlocked && !n.used && !at(e, a) && !K(e, a, "G"), o = t.boost === "triple" && r && r.id === "triple" && !r.used && e.revealed[a];
		if (!i && !o) return K(e, a, "G") ? q("errConstraint") : !n || at(e, a) ? q("errNoEquip") : n.unlocked ? q("errEquipUsed") : q("errEquipLocked");
	}
	if (t.xyray) {
		let t = ct(e, "xyray"), n = e.characters[a], r = t && t.unlocked && !t.used && !at(e, a) && !K(e, a, "G"), i = n && n.id === "xyray" && !n.used && e.revealed[a] && !F(e).noXY;
		if (!r && !i) return q("errNoEquip");
	}
	for (let n of c) {
		let i = lt(e, a, n, {
			cover: t.cover,
			math: t.math
		}, !1, r);
		if (i) return i;
		if (!U(e, a).some((e) => !e.cut && V(e) === n)) return q("errNoMatch");
	}
	let l = ut(e, a, c[0], t.payTo);
	if (l) return l;
	if (t.dd2000 && (e.characters[a].used = !0), t.boost) {
		let n = ct(e, t.boost), r = e.characters[a];
		n && n.unlocked && !n.used && !at(e, a) && !K(e, a, "G") ? n.used = !0 : r && (r.used = !0);
	}
	if (t.xyray) {
		let t = ct(e, "xyray"), n = e.characters[a];
		t && t.unlocked && !t.used && !at(e, a) && !K(e, a, "G") ? t.used = !0 : n && (n.used = !0);
	}
	let u = U(e, a).filter((t) => c.includes(V(t)) && !(t.x && I(e, "xwiresGate") && !e.yellowDone)), d = u[0];
	if (t.mine != null) {
		let n = B(e, t.mine);
		if (!n || n.owner !== a || n.wire.cut || !u.includes(n.wire)) return q("errBadWire");
		if (n.wire.x && I(e, "xwiresGate") && !e.yellowDone) return q("errXwire");
		d = n.wire;
	}
	if (!d) return q("errNoMatch");
	if (d.upside && (s || t.xyray)) return q("errBadWire");
	if (K(e, a, "H") && we(e, d.id).length > 0) return q("errConstraint");
	let f = new Set(c), p = o.filter((e) => f.has(V(e)));
	if (!c.some((t) => gt(e, t)) && (s ? p.length >= 1 : p.length === 1)) {
		let n = V(p[0]), i = o.some((e) => e.upside);
		if (s && p.length >= 2) return e.pending.push({
			rid: t.target,
			kind: "failToken",
			wires: p.map((e) => e.id),
			cut: !0,
			actor: a,
			mineWire: d.id,
			value: n,
			values: c
		}), {
			state: e,
			fx: r
		};
		for (let t of [...p, d]) if (H(e, t)) return G(e, "red", r), {
			state: e,
			fx: r
		};
		let l = e.mods.sequence?.at;
		for (let n of p) ht(e, n, r, t.target);
		return ht(e, d, r, a), _t(e, a, n, "dual"), z(e, {
			k: "dualOk",
			from: a,
			to: t.target,
			guess: n
		}), i && (I(e, "upside1") || I(e, "upside2")) && W(e, 1, r), I(e, "sequenceDir") && e.mods.sequence && e.mods.sequence.at !== l && e.phase !== "done" && e.pending.push({
			rid: a,
			kind: "moveSequence"
		}), X(e, r, a, "ok", [n]), {
			state: e,
			fx: r
		};
	}
	let m = e.stabilized;
	if (!m && !s && o.some((t) => H(e, t)) || !m && s && o.every((t) => H(e, t))) return G(e, "red", r), {
		state: e,
		fx: r
	};
	if (!m && Y(e, a)) return G(e, "lazy", r), {
		state: e,
		fx: r
	};
	if (!m && (I(e, "upside1") || I(e, "upside2") || I(e, "upsideCaptain")) && (o.some((e) => e.upside) || d.upside)) return G(e, "red", r), {
		state: e,
		fx: r
	};
	if (z(e, {
		k: "dualFail",
		from: a,
		to: t.target,
		guess: c[0]
	}), !m) {
		let n = I(e, "fakeTokens") || I(e, "sergio") && it(e, t.target), i = I(e, "tokenless") || K(e, a, "H");
		if (s) {
			let r = o.filter((t) => !H(e, t));
			if (!i && r.length > 1) e.pending.push({
				rid: t.target,
				kind: "failToken",
				wires: r.map((e) => e.id),
				fake: n,
				actor: a,
				value: c[0],
				outcome: "fail"
			});
			else if (!i && r.length === 1) {
				let i = n && typeof c[0] == "number" ? {
					kind: "value",
					value: c[0]
				} : st(e, t.target, r[0]);
				i && e.tokens.push({
					wire: r[0].id,
					token: i,
					fake: n
				});
			}
		} else if (!i) {
			let r = o[0], i = n && typeof c[0] == "number" ? {
				kind: "value",
				value: c[0]
			} : st(e, t.target, r);
			i && e.tokens.push({
				wire: r.id,
				token: i,
				fake: n
			});
		}
		W(e, K(e, a, "L") ? 2 : 1, r);
	}
	return e.pending.length > 0 || X(e, r, a, "fail", []), {
		state: e,
		fx: r
	};
}
function yt(e, t, n, r) {
	let i = rt(e, n.by);
	if (i) return i;
	let a = n.by;
	if (I(e, "massCutRed3") && U(e, a).every((e) => e.color === "red")) return q("errMassCount");
	if (e.mods.sevensOnly) return q("errMassValue");
	let o = t.value;
	if (I(e, "sevensLast") && o === 7) return q("errMassValue");
	if ((I(e, "iberian") || I(e, "yellowSeparate")) && o === "yellow") return q("errBadGuess");
	let s = lt(e, a, o, {
		cover: t.cover,
		math: t.math
	}, !0, r);
	if (s) return s;
	let c = Se(e, o), l = c.filter((t) => B(e, t.id)?.owner === a);
	if (l.length !== c.length || l.length === 0 || typeof o == "number" && l.length !== 2 && l.length !== 4) return q("errNoSolo");
	if (K(e, a, "H") && l.some((t) => we(e, t.id).length > 0)) return q("errConstraint");
	let u = ut(e, a, o, t.payTo);
	if (u) return u;
	if (l.some((t) => H(e, t))) return G(e, "red", r), {
		state: e,
		fx: r
	};
	let d = e.mods.sequence?.at;
	for (let t of l) ht(e, t, r, a);
	return _t(e, a, o, "solo"), z(e, {
		k: "solo",
		rid: a,
		value: o,
		n: l.length
	}), I(e, "sequenceDir") && e.mods.sequence && e.mods.sequence.at !== d && e.phase !== "done" && e.pending.push({
		rid: a,
		kind: "moveSequence"
	}), X(e, r, a, "ok", [o]), {
		state: e,
		fx: r
	};
}
function bt(e, t, n) {
	let r = rt(e, t.by);
	if (r) return r;
	let i = t.by, a = U(e, i);
	if (a.length === 0 || !a.every((t) => H(e, t))) return q("errNotAllRed");
	for (let e of a) e.cut = !0, n.push({
		kind: "cut",
		rid: i,
		data: {
			wire: e.id,
			color: e.color,
			sort: e.sort
		}
	});
	return _t(e, i, "yellow", "reveal"), z(e, {
		k: "reveal",
		rid: i,
		n: a.length
	}), X(e, n, i, "ok", []), {
		state: e,
		fx: n
	};
}
function xt(e, t) {
	if (e.mods.sevensOnly) return !1;
	let n = e.mods.numVisible ?? [], r = e.mods.nanoTrack, i = I(e, "xwiresGate") && !e.yellowDone;
	for (let a of U(e, t)) {
		if (a.x && i) continue;
		let o = V(a);
		if (o === "red") continue;
		if (o === "yellow") {
			if (!e.yellowDone && e.forcedValue == null && !I(e, "iberian") && !I(e, "yellowSeparate")) return !0;
			continue;
		}
		if (e.validated.includes(o) || e.forcedValue != null && o !== e.forcedValue) continue;
		let s = e.mods.sequence;
		if (s) {
			let e = s.dir === 1 ? s.cards.slice(s.at) : s.cards.slice(0, s.cards.length - s.at).reverse();
			if (e.includes(o) && e[0] !== o) continue;
		}
		if (!(I(e, "numVisible") && !I(e, "mathCards") && (n.length === 0 || n.length > 1 && !n.includes(o))) && (!I(e, "mathCards") || n.some((e, t) => n.some((r, i) => (t !== i || n.filter((t) => t === e).length > 1) && (e + r === o || Math.abs(e - r) === o)))) && (!I(e, "handCards") || (e.mods.handCards?.[t] ?? []).includes(o))) {
			if (r) {
				let e = r.cards.indexOf(o);
				if (e < 0 || !(r.flipped ? e < r.at : e > r.at)) continue;
			}
			if ((!I(e, "massCut4") || e.mods.massDone || e.mods.slotCard !== o) && !Ie(e, t, o, !1)) return !0;
		}
	}
	return !1;
}
function St(e, t) {
	return e.forcedValue != null && e.forcedBy === t ? !U(e, t).some((t) => V(t) === e.forcedValue) : e.mods.weakLink?.rid === t || !xt(e, t) || I(e, "numVisible") || I(e, "mathCards") || I(e, "constraintsDeck") || I(e, "constraintsOnValidate") || I(e, "constraintsByValidation") || I(e, "constraintsPersonal") || I(e, "oxygenPool") || I(e, "oxygenPerPlayer") || I(e, "oxygenCaptain") || I(e, "upsideCaptain") || I(e, "nanoTrack") || I(e, "handCards");
}
function Ct(e, t, n) {
	let r = rt(e, t.by);
	if (r) return r;
	let i = t.by;
	if (!St(e, i)) return q("errNoPass");
	if (e.mods.nanoTrack) return e.mods.nanoTrack.flipped = !e.mods.nanoTrack.flipped, W(e, 1, n), {
		state: e,
		fx: n
	};
	if (z(e, {
		k: "pass",
		rid: i
	}), e.passStreak += 1, e.forcedValue != null && e.forcedBy === i && !U(e, i).some((t) => V(t) === e.forcedValue)) {
		let t = U(e, i).find((e) => e.color === "blue");
		t && !K(e, i, "H") && e.tokens.push({
			wire: t.id,
			token: ot(t),
			fake: !1
		}), W(e, 1, n);
	}
	if (e.mods.weakLink?.rid === i && (W(e, 2, n), e.phase !== "done")) {
		e.mods.weakLink = void 0;
		for (let t of e.players) e.characters[t] = null, e.revealed[t] = !0;
	}
	if (I(e, "upsideCaptain") && W(e, 1, n), I(e, "mathCards") && e.mods.numVisible && (e.mods.numVisible = [...e.mods.numVisible].sort((e, t) => e - t).slice(2), W(e, 1, n)), e.mods.oxygen && W(e, 1, n), I(e, "handCards") && W(e, 1, n), e.phase !== "done" && e.passStreak >= Ee(e).length) {
		if (I(e, "constraintsByValidation") || I(e, "constraintsPersonal")) return G(e, "constrain", n), {
			state: e,
			fx: n
		};
		I(e, "constraintsOnValidate") && (W(e, 1, n), Le(e)), e.passStreak = 0;
	}
	return e.phase === "done" || X(e, n, i, "pass", []), {
		state: e,
		fx: n
	};
}
function wt(e, t, n, r) {
	let i = rt(e, n.by);
	if (i) return i;
	let a = n.by, o = [];
	for (let n of t.picks) {
		let t = B(e, n.wire);
		if (!t || t.owner !== n.rid || t.wire.cut) return q("errBadWire");
		o.push(t.wire);
	}
	if (o.length === 1 && e.mods.challenges?.some((e) => e.id === 1 && !e.done)) {
		let t = o[0];
		if (t.color === "red") {
			t.cut = !0, r.push({
				kind: "cut",
				rid: a,
				data: {
					wire: t.id,
					color: t.color,
					sort: t.sort
				}
			});
			let n = e.mods.challenges.find((e) => e.id === 1);
			return n.done = !0, De(e, 1, r), r.push({
				kind: "challenge",
				data: { id: 1 }
			}), z(e, {
				k: "mass",
				rid: a,
				n: 1,
				ok: !0
			}), X(e, r, a, "ok", []), {
				state: e,
				fx: r
			};
		}
		return G(e, "mass", r), {
			state: e,
			fx: r
		};
	}
	if (I(e, "massCutRed3")) {
		if (o.length !== 3) return q("errMassCount");
		if (!o.every((e) => e.color === "red")) return G(e, "mass", r), {
			state: e,
			fx: r
		};
		for (let e of o) e.cut = !0, r.push({
			kind: "cut",
			rid: a,
			data: {
				wire: e.id,
				color: e.color,
				sort: e.sort
			}
		});
		return z(e, {
			k: "mass",
			rid: a,
			n: 3,
			ok: !0
		}), X(e, r, a, "ok", []), {
			state: e,
			fx: r
		};
	}
	if (I(e, "massCutYellow3")) {
		if (o.length !== 3) return q("errMassCount");
		if (o.every((e) => e.color === "yellow")) {
			for (let t of o) ht(e, t, r, Tt(e, t));
			return z(e, {
				k: "mass",
				rid: a,
				n: 3,
				ok: !0
			}), X(e, r, a, "ok", ["yellow"]), {
				state: e,
				fx: r
			};
		}
		for (let t of o) t.color !== "red" && e.tokens.push({
			wire: t.id,
			token: ot(t),
			fake: !1
		});
		return z(e, {
			k: "mass",
			rid: a,
			n: 3,
			ok: !1
		}), W(e, 1, r), X(e, r, a, "fail", []), {
			state: e,
			fx: r
		};
	}
	if (I(e, "massCut4")) {
		if (o.length !== 4) return q("errMassCount");
		let t = I(e, "sevensLast") ? 7 : e.mods.slotCard ?? 0;
		if (!t || !o.every((e) => V(e) === t)) return G(e, "mass", r), {
			state: e,
			fx: r
		};
		for (let t of o) ht(e, t, r, Tt(e, t));
		if (e.mods.massDone = !0, z(e, {
			k: "mass",
			rid: a,
			n: 4,
			ok: !0
		}), e.equipPile) {
			for (let t of e.equipPile) e.equipments.push({
				id: t,
				unlocked: !0,
				used: !1,
				cover: null
			});
			e.equipPile = null;
		}
		if (e.mods.numDeck && I(e, "slotCard")) {
			let t = e.players.map((t, n) => e.players[(e.captain + n) % e.players.length]);
			e.mods.numDeck.forEach((n, r) => {
				let i = t[r % t.length], a = U(e, i).find((t) => t.color === "blue" && Math.round(t.sort) === n && we(e, t.id).length === 0);
				a && e.tokens.push({
					wire: a.id,
					token: {
						kind: "value",
						value: n
					},
					fake: !1
				});
			}), e.mods.numDeck = [];
		}
		return X(e, r, a, "ok", [t]), {
			state: e,
			fx: r
		};
	}
	return q("errPhase");
}
function Tt(e, t) {
	return B(e, t.id)?.owner ?? e.players[0];
}
function Et(e, t, n, r) {
	let i = rt(e, n.by);
	if (i) return i;
	let a = n.by;
	if (!I(e, "iberian")) return q("errPhase");
	if (t.target === a || !e.players.includes(t.target)) return q("errBadTarget");
	let o = B(e, t.wire);
	if (!o || o.owner !== t.target || o.wire.cut) return q("errBadWire");
	if (o.wire.color === "red") return G(e, "red", r), {
		state: e,
		fx: r
	};
	if (o.wire.color === "yellow") ht(e, o.wire, r, t.target), z(e, {
		k: "iberian",
		from: a,
		to: t.target,
		ok: !0
	}), De(e, 1, r), X(e, r, a, "ok", ["yellow"]);
	else {
		let n = st(e, t.target, o.wire);
		n && e.tokens.push({
			wire: o.wire.id,
			token: n,
			fake: !1
		}), z(e, {
			k: "iberian",
			from: a,
			to: t.target,
			ok: !1
		}), W(e, 1, r), X(e, r, a, "fail", []);
	}
	return {
		state: e,
		fx: r
	};
}
function Dt(e, t, n, r) {
	if (!e.mods.weakLink || e.players[e.turn] !== n.by || e.acted) return q("errAccuse");
	if (t.target === n.by) return q("errBadTarget");
	let i = e.mods.weakLink;
	if (i.rid === t.target && i.constraint === t.constraint) {
		for (let t of e.players) e.revealed[t] = !0;
		e.mods.weakLink = void 0, z(e, {
			k: "accuse",
			from: n.by,
			to: t.target,
			ok: !0
		});
	} else z(e, {
		k: "accuse",
		from: n.by,
		to: t.target,
		ok: !1
	}), W(e, 1, r);
	return {
		state: e,
		fx: r
	};
}
function Ot(e, t, n, r) {
	let i = n.by;
	if (I(e, "realtime")) return e.turn >= 0 || e.lastActor === i && e.players.length > 2 && e.players.some((t) => t !== i && !Te(e, t)) || Te(e, i) ? q("errClaim") : (e.turn = e.players.indexOf(i), Ze(e), z(e, {
		k: "claim",
		rid: i
	}), {
		state: e,
		fx: r
	});
	if (I(e, "squeak")) {
		if (e.forcedValue == null || e.forcedBy != null) return q("errSqueak");
		if (t.for !== void 0) return e.players[e.turn] !== i || !it(e, i) ? q("errNotYourTurn") : !e.players.includes(t.for) || Te(e, t.for) ? q("errBadTarget") : (e.forcedBy = t.for, z(e, {
			k: "claim",
			rid: t.for
		}), {
			state: e,
			fx: r
		});
		if (Te(e, i)) return q("errSqueak");
		let n = U(e, i);
		return !(n.length > 0 && n.every((t) => H(e, t))) && !n.some((t) => V(t) === e.forcedValue) ? q("errSqueak") : (e.forcedBy = i, z(e, {
			k: "claim",
			rid: i
		}), {
			state: e,
			fx: r
		});
	}
	if (I(e, "radarDeck") || I(e, "bossDeck")) {
		if (e.players[e.turn] !== i || e.forcedValue == null || e.forcedBy != null) return q("errNotYourTurn");
		let n = t.for ?? i;
		return !e.players.includes(n) || Te(e, n) ? q("errBadTarget") : (e.forcedBy = n, z(e, {
			k: "claim",
			rid: n
		}), {
			state: e,
			fx: r
		});
	}
	return q("errClaim");
}
function kt(e, t, n) {
	return I(e, "constraintsDeck") ? !it(e, t.by) || e.acted ? q("errNotYourTurn") : (Le(e), {
		state: e,
		fx: n
	}) : q("errPhase");
}
function At(e, t, n, r) {
	if (!I(e, "constraintsPersonal") || !e.mods.constraints) return q("errPhase");
	if (e.players[e.turn] !== n.by || !it(e, n.by) || e.acted) return q("errNotYourTurn");
	let i = e.mods.constraints, a = e.players.map((t, n) => e.players[(e.captain + n) % e.players.length]), o = [...a.map((e) => i.perPlayer[e] ?? null), ...i.side], s = o.length, c = o.map((e, n) => o[(n - t.dir + s) % s]);
	return a.forEach((e, t) => {
		i.perPlayer[e] = c[t];
	}), i.side = c.slice(a.length).filter((e) => e != null), {
		state: e,
		fx: r
	};
}
function jt(e, t, n, r) {
	if (t.kind === "swapConstraint") {
		let t = e.mods.constraints;
		if (!I(e, "constraintsPersonal") || !t || !t.perPlayer[n.by]) return q("errPhase");
		let i = [
			"F",
			"G",
			"H",
			"I",
			"J",
			"K",
			"L"
		];
		return t.perPlayer[n.by] = i[L(e, i.length)], W(e, 1, r), {
			state: e,
			fx: r
		};
	}
	let i = e.pending[0];
	if (!i || i.rid !== n.by || i.kind !== t.kind) return q("errPending");
	switch (i.kind) {
		case "failToken": {
			let a = t.index ?? -1, o = i.wires?.[a];
			if (o == null) return q("errBadWire");
			let s = B(e, o);
			if (!s || s.wire.cut) return q("errBadWire");
			if (e.pending.shift(), i.cut) {
				if (H(e, s.wire)) return G(e, "red", r), {
					state: e,
					fx: r
				};
				let t = e.mods.sequence?.at;
				if (ht(e, s.wire, r, n.by), i.mineWire != null && i.actor) {
					let a = B(e, i.mineWire);
					if (a && !a.wire.cut) {
						if (H(e, a.wire)) return G(e, "red", r), {
							state: e,
							fx: r
						};
						ht(e, a.wire, r, i.actor);
					}
					_t(e, i.actor, typeof i.value == "number" ? i.value : "yellow", "dual"), z(e, {
						k: "dualOk",
						from: i.actor,
						to: n.by,
						guess: i.value ?? 1
					}), I(e, "sequenceDir") && e.mods.sequence && e.mods.sequence.at !== t && e.phase !== "done" && e.pending.push({
						rid: i.actor,
						kind: "moveSequence"
					}), X(e, r, i.actor, "ok", i.value == null ? [] : [i.value]);
				}
				return {
					state: e,
					fx: r
				};
			}
			if (!I(e, "tokenless") && !K(e, i.actor ?? n.by, "H")) {
				let t = i.fake && typeof i.value == "number" ? {
					kind: "value",
					value: i.value
				} : st(e, n.by, s.wire);
				t && e.tokens.push({
					wire: s.wire.id,
					token: t,
					fake: !!i.fake
				});
			}
			return i.actor && X(e, r, i.actor, i.outcome ?? "fail", []), {
				state: e,
				fx: r
			};
		}
		case "pickToken": {
			let a = t.index ?? -1, o = i.options?.[a];
			if (o == null) return q("errBadWire");
			let s = U(e, n.by).find((t) => t.color === "blue" && Math.round(t.sort) === o && we(e, t.id).length === 0);
			if (!s) {
				if ((i.options ?? []).some((t) => U(e, n.by).some((n) => n.color === "blue" && Math.round(n.sort) === t && we(e, n.id).length === 0))) return q("errSetupToken");
				e.pending.shift();
				let t = i.queue?.[0];
				return t && (i.options ?? []).length > 0 && e.pending.push({
					rid: t,
					kind: "pickToken",
					options: i.options,
					queue: i.queue?.slice(1)
				}), {
					state: e,
					fx: r
				};
			}
			e.tokens.push({
				wire: s.id,
				token: {
					kind: "value",
					value: o
				},
				fake: !1
			}), e.pending.shift();
			let c = (i.options ?? []).filter((e, t) => t !== a), l = i.queue?.[0];
			return l && c.length > 0 && e.pending.push({
				rid: l,
				kind: "pickToken",
				options: c,
				queue: i.queue?.slice(1)
			}), {
				state: e,
				fx: r
			};
		}
		case "passToken": {
			let a = t.index ?? -1, o = i.options?.[a];
			if (o == null || !e.tokens[o]) return q("errBadWire");
			let s = e.tokens[o];
			e.tokens.splice(o, 1);
			let c = e.players.indexOf(n.by), l = e.players[(c + 1) % e.players.length];
			if (s.token.kind === "value") {
				let t = s.token.value, n = U(e, l).find((n) => n.color === "blue" && Math.round(n.sort) === t && we(e, n.id).length === 0);
				n && e.tokens.push({
					wire: n.id,
					token: {
						kind: "value",
						value: t
					},
					fake: !1
				});
			}
			e.pending.shift();
			let u = (i.options ?? []).filter((e) => e !== o).map((e) => e > o ? e - 1 : e), d = i.queue?.[0];
			return d && u.length > 0 && e.pending.push({
				rid: d,
				kind: "passToken",
				options: u,
				wires: u.map((t) => e.tokens[t].wire),
				queue: i.queue?.slice(1)
			}), {
				state: e,
				fx: r
			};
		}
		case "chooseConstraint": {
			let a = t.constraint;
			if (!a || !oe.includes(a)) return q("errConstraint");
			let o = e.mods.constraints;
			if (!o) return q("errPhase");
			if (Object.values(o.perPlayer).includes(a)) return q("errConstraint");
			o.perPlayer[n.by] = a, e.pending.shift();
			let s = i.queue?.[0];
			return s && e.pending.push({
				rid: s,
				kind: "chooseConstraint",
				queue: i.queue?.slice(1)
			}), {
				state: e,
				fx: r
			};
		}
		case "placeCard": {
			let i = e.mods.numHands?.hands[n.by] ?? [];
			return t.card == null || !i.includes(t.card) ? q("errHandCard") : (e.mods.numHands.hands[n.by] = i.filter((e) => e !== t.card), e.mods.numHands.placed = {
				by: n.by,
				card: t.card,
				revealed: !1
			}, e.pending.shift(), {
				state: e,
				fx: r
			});
		}
		case "giveCard": {
			let i = e.mods.handCards?.[n.by] ?? [], a = e.mods.handCardsDown?.[n.by] ?? [];
			return t.card == null || !i.includes(t.card) && !a.includes(t.card) ? q("errHandCard") : !t.target || t.target === n.by || !e.players.includes(t.target) ? q("errBadTarget") : (a.includes(t.card) ? (e.mods.handCardsDown[n.by] = a.filter((e) => e !== t.card), e.mods.handCardsDown[t.target] = [...e.mods.handCardsDown[t.target] ?? [], t.card]) : (e.mods.handCards[n.by] = i.filter((e) => e !== t.card), e.mods.handCards[t.target] = [...e.mods.handCards[t.target] ?? [], t.card]), e.pending.shift(), Xe(e), {
				state: e,
				fx: r
			});
		}
		case "talkiesPick": {
			let a = i.wires?.[t.index ?? -1], o = a == null ? null : B(e, a), s = i.mineWire == null ? null : B(e, i.mineWire);
			return !s || !o || o.owner !== n.by || s.wire.cut || o.wire.cut ? q("errBadWire") : (e.pending.shift(), Nt(s, o, r), {
				state: e,
				fx: r
			});
		}
		case "moveSequence": return e.mods.sequence ? (e.mods.sequence.dir = t.end === "right" ? -1 : 1, e.pending.shift(), {
			state: e,
			fx: r
		}) : q("errPhase");
		default: return q("errPending");
	}
}
function Mt(e, t) {
	let n = [];
	for (let r of e.players) e.racks[r].forEach((e, i) => {
		e.some((e) => !e.cut && !e.x && e.color === "blue" && Math.round(e.sort) === t) && n.push({
			rid: r,
			rack: i + 1
		});
	});
	return n;
}
function Nt(e, t, n) {
	e.rack.splice(e.rack.indexOf(e.wire), 1), t.rack.splice(t.rack.indexOf(t.wire), 1), e.rack.push(t.wire), e.rack.sort((e, t) => e.sort - t.sort), t.rack.push(e.wire), t.rack.sort((e, t) => e.sort - t.sort), n.push({
		kind: "swap",
		data: {
			a: e.wire.id,
			b: t.wire.id
		}
	});
}
function Pt(e, t, n, r) {
	let i = n.by, a = t.params ?? {}, o = t.id === "personal" ? null : t.id, s = !1;
	if (t.id === "personal") {
		let t = e.characters[i];
		if (!t || t.used || !e.revealed[i] || I(e, "noCharacters") || t.id === "dd2000" || t.id === "xyray" || t.id === "triple") return q("errNoPersonal");
		o = t.id, s = !0;
	} else {
		if (at(e, i)) return q("errNoEquip");
		let t = ct(e, o);
		if (!t) return q("errNoEquip");
		if (!t.unlocked) return q("errEquipLocked");
		if (t.used) return q("errEquipUsed");
	}
	if (K(e, i, "G")) return q("errConstraint");
	let c = () => {
		s ? e.characters[i].used = !0 : ct(e, o).used = !0, z(e, {
			k: "equip",
			rid: i,
			id: o
		});
	}, l = (t) => {
		if (t == null) return null;
		let n = B(e, t);
		return n && n.owner === i && !n.wire.cut ? n : null;
	};
	switch (o) {
		case "neq":
		case "eq": {
			let t = l(a.a), n = l(a.b);
			if (!t || !n || t.wire === n.wire) return q("errBadWire");
			let i = t.rack.indexOf(t.wire), s = n.rack.indexOf(n.wire);
			if (t.rack !== n.rack || Math.abs(i - s) !== 1) return q("errBadWire");
			let u = V(t.wire) === V(n.wire);
			if (o === "eq" ? !u : u) return q("errBadWire");
			let d = { kind: o };
			return e.tokens.push({
				wire: t.wire.id,
				token: d,
				fake: !1
			}, {
				wire: n.wire.id,
				token: d,
				fake: !1
			}), c(), {
				state: e,
				fx: r
			};
		}
		case "talkies": {
			let t = l(a.myWire), n = a.target;
			if (!t || !n || n === i || !e.players.includes(n)) return q("errBadWire");
			if (t.wire.x || t.wire.upside) return q("errXwire");
			let o = U(e, n).filter((e) => !e.x && !e.upside);
			return o.length === 0 ? q("errBadWire") : (c(), o.length === 1 ? Nt(t, B(e, o[0].id), r) : e.pending.push({
				rid: n,
				kind: "talkiesPick",
				wires: o.map((e) => e.id),
				mineWire: t.wire.id
			}), {
				state: e,
				fx: r
			});
		}
		case "postit": {
			let t = l(a.wire);
			return !t || !a.token ? q("errBadWire") : t.wire.x || t.wire.upside ? q("errXwire") : K(e, i, "H") ? q("errConstraint") : Ft(e, i, t.wire, a.token) || (e.tokens.push({
				wire: t.wire.id,
				token: a.token,
				fake: I(e, "fakeTokens") || F(e).fakeTokens === "sergio" && it(e, i)
			}), c(), {
				state: e,
				fx: r
			});
		}
		case "radar": {
			if (a.value == null) return q("errBadGuess");
			let t = Mt(e, a.value);
			return z(e, {
				k: "radar",
				rid: i,
				value: a.value,
				yes: t
			}), e.radarBeat = {
				value: a.value,
				yes: t
			}, e.phase = "resolving", e.phaseAfterBeat = "play", c(), {
				state: e,
				fx: r
			};
		}
		case "rewinder": return e.dial <= 0 ? q("errNoEquip") : (De(e, 1, r), c(), {
			state: e,
			fx: r
		});
		case "batteries": {
			let t = (a.rids ?? []).filter((t) => e.players.includes(t) && e.characters[t]?.used);
			if (t.length < 1 || t.length > 2) return q("errBadTarget");
			for (let n of t) e.characters[n].used = !1;
			return c(), {
				state: e,
				fx: r
			};
		}
		case "stabilizer": return e.players[e.turn] !== i || e.acted ? q("errNotYourTurn") : (e.stabilized = !0, c(), {
			state: e,
			fx: r
		});
		case "coffee": return e.players[e.turn] !== i || e.acted ? q("errNotYourTurn") : !a.next || !e.players.includes(a.next) || Te(e, a.next) ? q("errBadTarget") : (c(), I(e, "nanoCollect") && ft(e), pt(e, i), e.turn = e.players.indexOf(a.next), Ze(e), {
			state: e,
			fx: r
		});
		case "fund":
			if (!e.equipments.some((e) => e.used)) return q("errNoEquip");
			for (let t of e.equipments) t.used = !1;
			return c(), {
				state: e,
				fx: r
			};
		case "disintegrator": {
			let t = /* @__PURE__ */ new Set();
			for (let n of e.players) for (let r of U(e, n)) r.color === "blue" && !(I(e, "sevensLast") && Math.round(r.sort) === 7) && t.add(Math.round(r.sort));
			if (t.size === 0) return q("errNoEquip");
			let n = [...t][L(e, t.size)];
			for (let t of e.players) for (let i of U(e, t)) i.color === "blue" && Math.round(i.sort) === n && ht(e, i, r, t);
			return c(), dt(e, r), e.phase !== "done" && e.turn >= 0 && Ye(e, e.players[e.turn]) && Xe(e), {
				state: e,
				fx: r
			};
		}
		case "singleLabel": {
			let t = l(a.wire);
			return !t || t.wire.color !== "blue" ? q("errBadWire") : (e.tokens.push({
				wire: t.wire.id,
				token: {
					kind: "count",
					n: 1
				},
				fake: !1
			}), c(), {
				state: e,
				fx: r
			});
		}
		case "threadCutter": {
			if (e.players[e.turn] !== i || e.acted) return q("errNotYourTurn");
			let t = l(a.a), n = l(a.b);
			if (!t || !n || t.wire === n.wire || t.wire.color !== "blue" || n.wire.color !== "blue" || Math.round(t.wire.sort) !== Math.round(n.wire.sort)) return q("errBadWire");
			let o = Math.round(t.wire.sort);
			return I(e, "sevensLast") && o === 7 ? q("errMassValue") : (c(), ht(e, t.wire, r, i), ht(e, n.wire, r, i), z(e, {
				k: "solo",
				rid: i,
				value: o,
				n: 2
			}), X(e, r, i, "ok", [o]), {
				state: e,
				fx: r
			});
		}
		case "grapple": {
			let t = a.theirWire == null ? null : B(e, a.theirWire);
			if (!t || t.owner === i || t.wire.cut) return q("errBadWire");
			if (t.wire.x || t.wire.upside) return q("errXwire");
			t.rack.splice(t.rack.indexOf(t.wire), 1);
			let n = e.racks[i][0];
			return n.push(t.wire), n.sort((e, t) => e.sort - t.sort), c(), r.push({
				kind: "grapple",
				rid: i,
				data: {
					wire: t.wire.id,
					color: t.wire.color,
					sort: t.wire.sort
				},
				for: e.players.filter((e) => e !== i)
			}), {
				state: e,
				fx: r
			};
		}
		case "doubleFond": {
			let t = new Set(e.equipments.map((e) => e.id)), n = w(e.mission).map((e) => typeof e == "number" ? Ve[e] : e).filter((n) => !t.has(n) && ke[n] !== e.mods.cursed);
			R(e, n);
			for (let t of n.slice(0, 2)) e.equipments.push({
				id: t,
				unlocked: !1,
				used: !1,
				cover: I(e, "equipCover") ? 1 + L(e, 12) : null
			});
			return c(), {
				state: e,
				fx: r
			};
		}
		default: return q("errNoEquip");
	}
}
function Ft(e, t, n, r) {
	let i = F(e).tokenStyle, a = V(n), o = I(e, "fakeTokens") || F(e).fakeTokens === "sergio" && it(e, t);
	switch (r.kind) {
		case "value": return i !== "value" && i !== "mixed" || typeof a != "number" || !o && r.value !== a || o && r.value === a ? q("errSetupToken") : null;
		case "parity": return i !== "parity" && i !== "mixed" || typeof a != "number" || !o && r.odd !== (a % 2 == 1) ? q("errSetupToken") : null;
		case "count": {
			if (i !== "count" && i !== "mixed" || typeof a != "number") return q("errSetupToken");
			let n = e.racks[t].flat().filter((e) => e.color === "blue" && Math.round(e.sort) === a).length;
			return !o && (r.n !== n || n > 3) ? q("errSetupToken") : null;
		}
		default: return q("errSetupToken");
	}
}
function It(e, t) {
	let n = e.mods, r = (t) => ({
		id: t.id,
		cut: t.cut,
		...t.x ? { x: !0 } : {},
		...t.upside ? { upside: !0 } : {},
		tokens: we(e, t.id),
		revealed: t.cut ? {
			color: t.color,
			sort: t.sort
		} : null
	});
	return {
		public: {
			mission: e.mission,
			phase: e.phase,
			setupTurn: e.phase === "setup" ? e.setupQueue[0] ?? null : null,
			turn: e.turn >= 0 ? e.players[e.turn] : null,
			forcedValue: e.forcedValue,
			forcedBy: e.forcedBy,
			captain: e.players[e.captain],
			dial: e.maxDial < 0 ? null : {
				step: e.dial,
				max: e.maxDial
			},
			stabilized: e.stabilized,
			players: e.players.map((t) => ({
				rid: t,
				racks: e.racks[t].map((e) => e.map(r)),
				done: U(e, t).length === 0,
				character: e.revealed[t] ? e.characters[t] : null,
				revealed: e.revealed[t]
			})),
			equipments: e.equipments.map((e) => ({ ...e })),
			validated: [...e.validated],
			yellowDone: e.yellowDone,
			mods: {
				markers: n.markers,
				...n.sequence ? { sequence: {
					cards: n.sequence.cards,
					at: n.sequence.at,
					face: n.sequence.face,
					dir: n.sequence.dir
				} } : {},
				...n.cursed === void 0 ? {} : { cursed: n.cursed },
				...n.numDeck ? { numDeck: {
					current: n.numCurrent ?? null,
					left: n.numDeck.length
				} } : {},
				...n.numVisible ? { numVisible: [...n.numVisible] } : {},
				...n.numHands ? { numHands: {
					deckLeft: n.numHands.deck.length,
					placed: !!n.numHands.placed,
					revealed: n.numHands.placed?.revealed ? n.numHands.placed.card : null
				} } : {},
				...n.slotCard !== void 0 && !n.massDone ? { slotCard: n.slotCard } : {},
				...n.nano ? { nano: {
					pos: n.nano.pos,
					dir: n.nano.dir,
					nanoWires: n.nano.wires.length
				} } : {},
				...n.nanoTrack ? { nanoTrack: {
					cards: n.nanoTrack.cards,
					at: n.nanoTrack.at,
					flipped: n.nanoTrack.flipped
				} } : {},
				...n.oxygen ? { oxygen: {
					pool: n.oxygen.mode === "pool" ? n.oxygen.pool : n.oxygen.mode === "captain" ? n.oxygen.perPlayer[n.oxygen.holder] ?? 0 : 0,
					reserve: 0,
					perPlayer: { ...n.oxygen.perPlayer },
					...n.oxygen.mode === "captain" ? { holder: n.oxygen.holder } : {}
				} } : {},
				...n.constraints ? { constraints: {
					active: [...n.constraints.active],
					perPlayer: { ...n.constraints.perPlayer },
					deckLeft: n.constraints.deck.length,
					side: [...n.constraints.side]
				} } : {},
				...n.challenges ? { challenges: n.challenges.map((e) => ({ ...e })) } : {},
				...n.challenge8 ? { challenge8: [...n.challenge8] } : {},
				...n.deadline !== void 0 && n.deadline >= 0 ? { deadline: n.deadline } : {},
				...I(e, "squeak") && e.forcedValue != null ? { squeak: {
					value: e.forcedValue,
					claimed: e.forcedBy
				} } : {},
				...n.bonusCards ? { bonusCards: [...n.bonusCards] } : {},
				...n.sevensOnly === void 0 ? {} : { sevensOnly: n.sevensOnly },
				...n.handCards ? { handCards: Object.fromEntries(Object.entries(n.handCards).map(([e, t]) => [e, [...t]])) } : {},
				...n.handCardsDown ? { handCardsDown: Object.fromEntries(Object.entries(n.handCardsDown).map(([e, t]) => [e, [...t]])) } : {}
			},
			pending: e.pending.map((e) => ({
				rid: e.rid,
				kind: e.kind,
				...e.cut ? { cut: !0 } : {},
				...e.wires ? { wires: [...e.wires] } : {},
				...e.options ? { options: [...e.options] } : {},
				...e.fake ? { fake: !0 } : {}
			})),
			lastActor: e.lastActor,
			result: e.result ? {
				win: e.result.win,
				reason: e.result.reason
			} : null,
			cutBeat: e.cutBeat,
			radarBeat: e.radarBeat,
			cutHistory: e.cutHistory,
			log: [...e.log]
		},
		private: {
			mine: e.racks[t].flat().filter((e) => !e.upside).map((e) => ({
				wire: e.id,
				color: e.color,
				sort: e.sort
			})),
			upsideVisible: e.players.filter((e) => e !== t).flatMap((t) => e.racks[t].flat()).filter((e) => e.upside && !e.cut).map((e) => ({
				wire: e.id,
				color: e.color,
				sort: e.sort
			})),
			secretConstraint: n.weakLink?.rid === t ? n.weakLink.constraint : null,
			handCards: [...n.numHands?.hands[t] ?? []],
			canPass: e.phase === "play" && e.pending.length === 0 && St(e, t)
		}
	};
}
function Lt(e) {
	return e.phase !== "done" || !e.result ? { phase: e.phase } : {
		phase: "done",
		winner: e.result.win ? [...e.players] : [],
		ranking: [...e.players]
	};
}
function Rt(e, t) {
	return e.phase === "resolving" ? I(e, "realtime") ? 550 : e.cutBeat ? He : Ue : e.phase !== "play" || e.mods.deadline === void 0 ? null : e.mods.deadline < 0 ? 1e3 : Math.max(250, e.mods.deadline - t);
}
var zt = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: x,
	schemas: {
		action: pe,
		publicView: ye,
		privateView: be,
		config: de
	},
	setup: We,
	reduce: et,
	viewFor: It,
	status: Lt,
	nextTickIn: Rt
}, Bt = "<!-- @license lucide-static v1.49.0 - ISC -->\n<svg\n  class=\"lucide lucide-battery-charging\"\n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"2.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"m11 7-3 5h4l-3 5\" />\n  <path d=\"M14.856 6H16a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.935\" />\n  <path d=\"M22 14v-4\" />\n  <path d=\"M5.14 18H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h2.936\" />\n</svg>\n", Vt = "<!-- @license lucide-static v1.49.0 - ISC -->\n<svg\n  class=\"lucide lucide-coffee\"\n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"2.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M10 2v2\" />\n  <path d=\"M14 2v2\" />\n  <path d=\"M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14a4 4 0 1 1 0 8h-1\" />\n  <path d=\"M6 2v2\" />\n</svg>\n", Ht = "<!-- @license lucide-static v1.49.0 - ISC -->\n<svg\n  class=\"lucide lucide-coins\"\n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"2.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M13.744 17.736a6 6 0 1 1-7.48-7.48\" />\n  <path d=\"M15 6h1v4\" />\n  <path d=\"m6.134 14.768.866-.5 2 3.464\" />\n  <circle cx=\"16\" cy=\"8\" r=\"6\" />\n</svg>\n", Ut = "<!-- @license lucide-static v1.49.0 - ISC -->\n<svg\n  class=\"lucide lucide-equal\"\n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"2.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <line x1=\"5\" x2=\"19\" y1=\"9\" y2=\"9\" />\n  <line x1=\"5\" x2=\"19\" y1=\"15\" y2=\"15\" />\n</svg>\n", Wt = "<!-- @license lucide-static v1.49.0 - ISC -->\n<svg\n  class=\"lucide lucide-equal-not\"\n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"2.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <line x1=\"5\" x2=\"19\" y1=\"9\" y2=\"9\" />\n  <line x1=\"5\" x2=\"19\" y1=\"15\" y2=\"15\" />\n  <line x1=\"19\" x2=\"5\" y1=\"5\" y2=\"19\" />\n</svg>\n", Gt = "<!-- @license lucide-static v1.49.0 - ISC -->\n<svg\n  class=\"lucide lucide-eraser\"\n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"2.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M21 21H8a2 2 0 0 1-1.42-.587l-3.994-3.999a2 2 0 0 1 0-2.828l10-10a2 2 0 0 1 2.829 0l5.999 6a2 2 0 0 1 0 2.828L12.834 21\" />\n  <path d=\"m5.082 11.09 8.828 8.828\" />\n</svg>\n", Kt = "<!-- @license lucide-static v1.49.0 - ISC -->\n<svg\n  class=\"lucide lucide-gauge\"\n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"2.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"m12 14 4-4\" />\n  <path d=\"M3.34 19a10 10 0 1 1 17.32 0\" />\n</svg>\n", qt = "<!-- @license lucide-static v1.49.0 - ISC -->\n<svg\n  class=\"lucide lucide-grab\"\n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"2.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M18 11.5V9a2 2 0 0 0-2-2a2 2 0 0 0-2 2v1.4\" />\n  <path d=\"M14 10V8a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2\" />\n  <path d=\"M10 9.9V9a2 2 0 0 0-2-2a2 2 0 0 0-2 2v5\" />\n  <path d=\"M6 14a2 2 0 0 0-2-2a2 2 0 0 0-2 2\" />\n  <path d=\"M18 11a2 2 0 1 1 4 0v3a8 8 0 0 1-8 8h-4a8 8 0 0 1-8-8 2 2 0 1 1 4 0\" />\n</svg>\n", Jt = "<!-- @license lucide-static v1.49.0 - ISC -->\n<svg\n  class=\"lucide lucide-piggy-bank\"\n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"2.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M11 17h3v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-3a3.16 3.16 0 0 0 2-2h1a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1h-1a5 5 0 0 0-2-4V3a4 4 0 0 0-3.2 1.6l-.3.4H11a6 6 0 0 0-6 6v1a5 5 0 0 0 2 4v3a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1z\" />\n  <path d=\"M16 10h.01\" />\n  <path d=\"M2 8v1a2 2 0 0 0 2 2h1\" />\n</svg>\n", Yt = "<!-- @license lucide-static v1.49.0 - ISC -->\n<svg\n  class=\"lucide lucide-radar\"\n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"2.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M19.07 4.93A10 10 0 0 0 6.99 3.34\" />\n  <path d=\"M4 6h.01\" />\n  <path d=\"M2.29 9.62A10 10 0 1 0 21.31 8.35\" />\n  <path d=\"M16.24 7.76A6 6 0 1 0 8.23 16.67\" />\n  <path d=\"M12 18h.01\" />\n  <path d=\"M17.99 11.66A6 6 0 0 1 15.77 16.67\" />\n  <circle cx=\"12\" cy=\"12\" r=\"2\" />\n  <path d=\"m13.41 10.59 5.66-5.66\" />\n</svg>\n", Xt = "<!-- @license lucide-static v1.49.0 - ISC -->\n<svg\n  class=\"lucide lucide-radio\"\n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"2.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M16.247 7.761a6 6 0 0 1 0 8.478\" />\n  <path d=\"M19.075 4.933a10 10 0 0 1 0 14.134\" />\n  <path d=\"M4.925 19.067a10 10 0 0 1 0-14.134\" />\n  <path d=\"M7.753 16.239a6 6 0 0 1 0-8.478\" />\n  <circle cx=\"12\" cy=\"12\" r=\"2\" />\n</svg>\n", Zt = "<!-- @license lucide-static v1.49.0 - ISC -->\n<svg\n  class=\"lucide lucide-rewind\"\n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"2.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M12 6a2 2 0 0 0-3.414-1.414l-6 6a2 2 0 0 0 0 2.828l6 6A2 2 0 0 0 12 18z\" />\n  <path d=\"M22 6a2 2 0 0 0-3.414-1.414l-6 6a2 2 0 0 0 0 2.828l6 6A2 2 0 0 0 22 18z\" />\n</svg>\n", Qt = "<!-- @license lucide-static v1.49.0 - ISC -->\n<svg\n  class=\"lucide lucide-rows-3\"\n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"2.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <rect width=\"18\" height=\"18\" x=\"3\" y=\"3\" rx=\"2\" />\n  <path d=\"M21 9H3\" />\n  <path d=\"M21 15H3\" />\n</svg>\n", $t = "<!-- @license lucide-static v1.49.0 - ISC -->\n<svg\n  class=\"lucide lucide-scan-eye\"\n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"2.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M3 7V5a2 2 0 0 1 2-2h2\" />\n  <path d=\"M17 3h2a2 2 0 0 1 2 2v2\" />\n  <path d=\"M21 17v2a2 2 0 0 1-2 2h-2\" />\n  <path d=\"M7 21H5a2 2 0 0 1-2-2v-2\" />\n  <circle cx=\"12\" cy=\"12\" r=\"1\" />\n  <path d=\"M18.944 12.33a1 1 0 0 0 0-.66 7.5 7.5 0 0 0-13.888 0 1 1 0 0 0 0 .66 7.5 7.5 0 0 0 13.888 0\" />\n</svg>\n", en = "<!-- @license lucide-static v1.49.0 - ISC -->\n<svg\n  class=\"lucide lucide-scissors\"\n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"2.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <circle cx=\"6\" cy=\"6\" r=\"3\" />\n  <path d=\"M8.12 8.12 12 12\" />\n  <path d=\"M20 4 8.12 15.88\" />\n  <circle cx=\"6\" cy=\"18\" r=\"3\" />\n  <path d=\"M14.8 14.8 20 20\" />\n</svg>\n", tn = "<!-- @license lucide-static v1.49.0 - ISC -->\n<svg\n  class=\"lucide lucide-sticky-note\"\n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"2.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M21 9a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 15 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2z\" />\n  <path d=\"M15 3v5a1 1 0 0 0 1 1h5\" />\n</svg>\n", nn = "<!-- @license lucide-static v1.49.0 - ISC -->\n<svg\n  class=\"lucide lucide-tag\"\n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"2.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z\" />\n  <circle cx=\"7.5\" cy=\"7.5\" r=\".5\" fill=\"currentColor\" />\n</svg>\n", rn = "<!-- @license lucide-static v1.49.0 - ISC -->\n<svg\n  class=\"lucide lucide-telescope\"\n  xmlns=\"http://www.w3.org/2000/svg\"\n  width=\"24\"\n  height=\"24\"\n  viewBox=\"0 0 24 24\"\n  fill=\"none\"\n  stroke=\"currentColor\"\n  stroke-width=\"2.5\"\n  stroke-linecap=\"round\"\n  stroke-linejoin=\"round\"\n>\n  <path d=\"m10.065 12.493-6.18 1.318a.934.934 0 0 1-1.108-.702l-.537-2.15a1.07 1.07 0 0 1 .691-1.265l13.504-4.44\" />\n  <path d=\"m13.56 11.747 4.332-.924\" />\n  <path d=\"m16 21-3.105-6.21\" />\n  <path d=\"M16.485 5.94a2 2 0 0 1 1.455-2.425l1.09-.272a1 1 0 0 1 1.212.727l1.515 6.06a1 1 0 0 1-.727 1.213l-1.09.272a2 2 0 0 1-2.425-1.455z\" />\n  <path d=\"m6.158 8.633 1.114 4.456\" />\n  <path d=\"m8 21 3.105-6.21\" />\n  <circle cx=\"12\" cy=\"13\" r=\"2\" />\n</svg>\n";
//#endregion
//#region src/games/bombbusters/board.tsx
function an({ step: e, max: t, beatDelta: n = 0 }) {
	let r = l(), i = t + 1, a = Math.max(0, i - e);
	return /* @__PURE__ */ g("span", {
		className: `bb-hp ${a <= 1 ? "bb-hp--danger" : ""} ${n ? "bb-hp--beat" : ""}`,
		role: "img",
		"aria-label": r("games.bombbusters.dialLeft", { n: a }),
		children: [/* @__PURE__ */ h("span", {
			className: "bb-hp__label",
			children: "HP"
		}), /* @__PURE__ */ g("span", {
			className: "bb-hp__value",
			children: [
				a,
				"/",
				i
			]
		})]
	});
}
function on({ pub: e }) {
	let t = l(), n = e.mods, r = re.get(e.mission)?.features.includes("tokenBeside") ?? !1, i = /* @__PURE__ */ new Map();
	for (let e of n.markers.red) i.set(e.v, [...i.get(e.v) ?? [], { unsure: e.unsure }]);
	let a = /* @__PURE__ */ new Map();
	for (let e of n.markers.yellow) a.set(e.v, [...a.get(e.v) ?? [], { unsure: e.unsure }]);
	let o = new Set(n.bonusCards ?? []), s = /* @__PURE__ */ new Map();
	for (let t of e.players) for (let e of t.racks) for (let t of e) if (t.cut && t.revealed?.color === "blue") {
		let e = Math.round(t.revealed.sort);
		s.set(e, (s.get(e) ?? 0) + 1);
	}
	return /* @__PURE__ */ g("div", {
		className: "bb-track",
		role: "list",
		"aria-label": t("games.bombbusters.validatedTrack"),
		children: [[
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			9,
			10,
			11,
			12
		].map((c) => {
			let l = !r && e.validated.includes(c), u = l ? 0 : s.get(c) ?? 0, d = n.cursed === c, f = e.forcedValue === c, p = n.nano?.pos === c, m = c === 1 && n.nano?.pos === 0, _ = i.get(c) ?? [], v = a.get(c) ?? [], y = l ? "bb-track__cell--validated" : d ? "bb-track__cell--cursed" : f ? "bb-track__cell--forced" : o.has(c) ? "bb-track__cell--bonus" : "", b = e.cutBeat?.values.includes(c) || e.cutBeat?.validated.includes(c);
			return /* @__PURE__ */ g("span", {
				role: "listitem",
				className: `bb-track__cell ${y} ${b ? "bb-track__cell--beat" : ""}`,
				title: `${c} · ${_.length} ${t("games.bombbusters.wireRed")} · ${v.length} ${t("games.bombbusters.guessYellow")}`,
				children: [
					u > 0 && /* @__PURE__ */ h("span", {
						"aria-hidden": "true",
						className: "bb-track__fill",
						style: { height: `${u / 4 * 100}%` }
					}),
					_.length > 0 && /* @__PURE__ */ g("span", {
						className: "bb-track__arrow bb-track__arrow--red",
						children: [_.length > 1 ? _.length : "", _.some((e) => e.unsure) ? "?" : ""]
					}),
					v.length > 0 && /* @__PURE__ */ g("span", {
						className: `bb-track__arrow bb-track__arrow--yellow ${_.length > 0 ? "bb-track__arrow--shift" : ""}`,
						children: [v.length > 1 ? v.length : "", v.some((e) => e.unsure) ? "?" : ""]
					}),
					/* @__PURE__ */ h("span", {
						className: "relative",
						children: c
					}),
					(l || p || d) && /* @__PURE__ */ h("span", {
						className: "bb-track__check",
						"aria-label": p ? t("games.bombbusters.nanoAt", { n: c }) : void 0,
						children: p ? "🤖" : d ? "💀" : "✓"
					}),
					m && /* @__PURE__ */ h("span", {
						className: "bb-track__check bb-track__check--before",
						"aria-label": t("games.bombbusters.nanoAt", { n: 0 }),
						children: "🤖"
					})
				]
			}, c);
		}), (() => {
			let n = re.get(e.mission), i = e.players.length, a = n ? (i === 2 && n.red2p ? n.red2p : n.red).n : 0, o = n ? i === 2 && n.yellow2p ? n.yellow2p : n.yellow : null, s = o ? o.n < 0 ? Math.min(i, 4) : o.n : 0;
			return /* @__PURE__ */ g("span", {
				role: "listitem",
				className: `bb-track__cell bb-track__cell--yellow ${!r && e.yellowDone ? "bb-track__cell--validated" : ""} ${e.cutBeat?.values.includes("yellow") || e.cutBeat?.validated.includes("yellow") ? "bb-track__cell--beat" : ""}`,
				"aria-label": `${t("games.bombbusters.wireRed")} ${a} · ${t("games.bombbusters.guessYellow")} ${s}`,
				children: [/* @__PURE__ */ g("span", {
					"aria-hidden": "true",
					className: "bb-track__wires",
					children: [Array.from({ length: a }, (e, t) => /* @__PURE__ */ h("svg", {
						className: "bb-track__miniwire bb-track__miniwire--red",
						viewBox: "0 0 6 20",
						children: /* @__PURE__ */ h("path", {
							d: "M3 2 C5.5 5 .5 8 3 11 S5.5 16 3 18",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "1.8",
							strokeLinecap: "round"
						})
					}, `r${t}`)), Array.from({ length: s }, (e, t) => /* @__PURE__ */ h("svg", {
						className: "bb-track__miniwire bb-track__miniwire--yellow",
						viewBox: "0 0 6 20",
						children: /* @__PURE__ */ h("path", {
							d: "M3 2 C5.5 5 .5 8 3 11 S5.5 16 3 18",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "1.8",
							strokeLinecap: "round"
						})
					}, `y${t}`))]
				}), e.yellowDone && !r && /* @__PURE__ */ h("span", {
					className: "bb-track__check",
					children: "✓"
				})]
			});
		})()]
	});
}
var sn = {
	neq: "games.bombbusters.eqNeq",
	talkies: "games.bombbusters.eqTalkies",
	triple: "games.bombbusters.eqTriple",
	postit: "games.bombbusters.eqPostit",
	super: "games.bombbusters.eqSuper",
	rewinder: "games.bombbusters.eqRewinder",
	batteries: "games.bombbusters.eqBatteries",
	radar: "games.bombbusters.eqRadar",
	stabilizer: "games.bombbusters.eqStabilizer",
	xyray: "games.bombbusters.eqXyray",
	coffee: "games.bombbusters.eqCoffee",
	eq: "games.bombbusters.eqEq",
	fund: "games.bombbusters.eqFund",
	disintegrator: "games.bombbusters.eqDisintegrator",
	singleLabel: "games.bombbusters.eqSingleLabel",
	threadCutter: "games.bombbusters.eqThreadCutter",
	grapple: "games.bombbusters.eqGrapple",
	doubleFond: "games.bombbusters.eqDoubleFond"
}, cn = {
	neq: "games.bombbusters.eqNeqDesc",
	talkies: "games.bombbusters.eqTalkiesDesc",
	triple: "games.bombbusters.eqTripleDesc",
	postit: "games.bombbusters.eqPostitDesc",
	super: "games.bombbusters.eqSuperDesc",
	rewinder: "games.bombbusters.eqRewinderDesc",
	batteries: "games.bombbusters.eqBatteriesDesc",
	radar: "games.bombbusters.eqRadarDesc",
	stabilizer: "games.bombbusters.eqStabilizerDesc",
	xyray: "games.bombbusters.eqXyrayDesc",
	coffee: "games.bombbusters.eqCoffeeDesc",
	eq: "games.bombbusters.eqEqDesc",
	fund: "games.bombbusters.eqFundDesc",
	disintegrator: "games.bombbusters.eqDisintegratorDesc",
	singleLabel: "games.bombbusters.eqSingleLabelDesc",
	threadCutter: "games.bombbusters.eqThreadCutterDesc",
	grapple: "games.bombbusters.eqGrappleDesc",
	doubleFond: "games.bombbusters.eqDoubleFondDesc"
}, ln = {
	A: "games.bombbusters.cA",
	B: "games.bombbusters.cB",
	C: "games.bombbusters.cC",
	D: "games.bombbusters.cD",
	E: "games.bombbusters.cE",
	F: "games.bombbusters.cF",
	G: "games.bombbusters.cG",
	H: "games.bombbusters.cH",
	I: "games.bombbusters.cI",
	J: "games.bombbusters.cJ",
	K: "games.bombbusters.cK",
	L: "games.bombbusters.cL"
}, un = {
	1: "games.bombbusters.ch1",
	2: "games.bombbusters.ch2",
	3: "games.bombbusters.ch3",
	4: "games.bombbusters.ch4",
	5: "games.bombbusters.ch5",
	6: "games.bombbusters.ch6",
	7: "games.bombbusters.ch7",
	8: "games.bombbusters.ch8",
	9: "games.bombbusters.ch9",
	10: "games.bombbusters.ch10"
}, dn = {
	neq: Wt,
	talkies: Xt,
	triple: Qt,
	postit: tn,
	super: rn,
	rewinder: Zt,
	batteries: Bt,
	radar: Yt,
	stabilizer: Kt,
	xyray: $t,
	coffee: Vt,
	eq: Ut,
	fund: Ht,
	disintegrator: Gt,
	singleLabel: nn,
	threadCutter: en,
	grapple: qt,
	doubleFond: Jt
};
function fn({ pub: e, onUse: t, onInspect: n }) {
	let r = l();
	return /* @__PURE__ */ g("ul", {
		className: "bb-equip-list",
		"aria-label": r("games.bombbusters.actEquip"),
		children: [e.equipments.map((i, a) => {
			let o = i.unlocked && !i.used, s = ke[i.id], c = s === "yellow" ? r("games.bombbusters.guessYellow") : String(s), l = i.used ? r("games.bombbusters.equipUsed") : i.unlocked ? r("games.bombbusters.equipReady") : r("games.bombbusters.equipUnlock", { v: c });
			return /* @__PURE__ */ h("li", { children: /* @__PURE__ */ g("button", {
				type: "button",
				disabled: !t && !n,
				onClick: () => o ? t?.(i.id) : n?.(),
				title: `${r(cn[i.id])} · ${l}`,
				className: `bb-equip-card ${o ? "bb-equip-card--ready" : ""} ${i.used ? "bb-equip-card--used" : i.unlocked ? "" : "bb-equip-card--locked"} ${e.cutBeat?.equipments.includes(i.id) ? "bb-equip-card--beat" : ""}`,
				children: [
					/* @__PURE__ */ h("span", {
						className: "bb-equip-card__icon",
						"aria-hidden": "true",
						dangerouslySetInnerHTML: { __html: dn[i.id] }
					}),
					/* @__PURE__ */ h("span", {
						className: "bb-equip-card__name",
						children: r(sn[i.id])
					}),
					/* @__PURE__ */ g("span", {
						className: "bb-equip-card__state",
						"aria-label": l,
						children: [i.used ? "×" : i.unlocked ? "✓" : c, i.cover != null && !i.unlocked ? `+${i.cover}` : ""]
					}),
					/* @__PURE__ */ h("span", {
						className: "bb-equip-card__status",
						children: l
					})
				]
			}) }, `${i.id}-${a}`);
		}), Array.from({ length: Math.max(0, 5 - e.equipments.length) }, (e, t) => /* @__PURE__ */ h("li", {
			"aria-hidden": "true",
			children: /* @__PURE__ */ h("span", {
				className: "bb-equip-card bb-equip-card--locked",
				children: /* @__PURE__ */ h("span", {
					className: "bb-equip-card__icon",
					children: "—"
				})
			})
		}, `empty-${t}`))]
	});
}
function pn(e) {
	if (e.forcedValue == null || !re.get(e.mission)?.features.includes("radarDeck")) return null;
	for (let t = e.log.length - 1; t >= 0; --t) {
		let n = e.log[t];
		if (n.k === "radar" && n.value === e.forcedValue) return n;
	}
	return null;
}
function mn(e, t, n) {
	return t.map((t) => {
		let r = e.players.find((e) => e.rid === t.rid);
		return r && r.racks.length > 1 ? `${n(t.rid)}·${t.rack}` : n(t.rid);
	});
}
function hn({ v: e, tone: t = "blue", current: n = !1, mini: r = !1 }) {
	return /* @__PURE__ */ g("span", {
		className: `bb-number-card bb-number-card--${t} ${n ? "bb-number-card--current" : ""} ${r ? "bb-number-card--mini" : ""}`,
		children: [t !== "blue" && /* @__PURE__ */ h("svg", {
			"aria-hidden": "true",
			className: "bb-number-card__wire",
			viewBox: "0 0 28 72",
			preserveAspectRatio: "none",
			children: /* @__PURE__ */ h("path", {
				d: "M14 5 C21 11 7 17 14 23 S21 35 14 41 S7 53 14 59 S21 65 14 68",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "4"
			})
		}), /* @__PURE__ */ h("span", {
			className: "bb-number-card__v",
			children: e
		})]
	});
}
function gn({ pub: e, onOpen: t }) {
	let n = l();
	return /* @__PURE__ */ g("button", {
		type: "button",
		className: "bb-mission-title",
		onClick: t,
		"aria-label": n("games.bombbusters.missionDetails"),
		children: [
			/* @__PURE__ */ g("span", {
				className: "bb-mission-sheet__no",
				children: ["#", e.mission]
			}),
			/* @__PURE__ */ h("span", {
				className: "bb-mission-title__name",
				children: n(`games.bombbusters.m${e.mission}name`)
			}),
			/* @__PURE__ */ h("span", {
				className: "bb-mission-title__open",
				"aria-hidden": "true",
				children: "›"
			})
		]
	});
}
function _n(e, t, n, r, i, a = [], o = !1, s = "all") {
	let c = t.mods, l = [], u = "bb-mission-chip", d = s !== "personal", f = s !== "public", p = re.get(t.mission);
	if (d && p && p.blueMax !== 12 && l.push(/* @__PURE__ */ h("span", {
		className: u,
		children: e("games.bombbusters.infoBlueRange", { max: p.blueMax })
	}, "wb")), d && c.cursed !== void 0 && l.push(/* @__PURE__ */ g("span", {
		className: u,
		children: [/* @__PURE__ */ h(hn, {
			v: c.cursed,
			tone: "red"
		}), e("games.bombbusters.cursedAsRed")]
	}, "cursed")), d && c.sequence) {
		let t = c.sequence;
		l.push(/* @__PURE__ */ g("span", {
			className: u,
			children: [
				e("games.bombbusters.infoSequence"),
				t.dir === -1 && "←",
				t.cards.map((e, n) => /* @__PURE__ */ h(hn, {
					v: e,
					current: n === t.at
				}, n)),
				t.dir === 1 && "→"
			]
		}, "seq"));
	}
	if (d && c.numDeck) {
		let t = p?.features ?? [], n = t.includes("equipDeck") ? e("games.bombbusters.infoDeckEquipPre") : t.includes("radarDeck") ? e("games.bombbusters.infoDeckTargetPre") : t.includes("squeak") ? e("games.bombbusters.infoDeckSqueakPre") : t.includes("bossDeck") ? e("games.bombbusters.infoDeckBossPre") : e("games.bombbusters.infoDeckPile"), r = t.includes("equipDeck") ? e("games.bombbusters.infoDeckEquipPost") : t.includes("squeak") ? e("games.bombbusters.infoDeckSqueakPost") : "";
		l.push(/* @__PURE__ */ g("span", {
			className: u,
			children: [
				n,
				c.numDeck.current != null && /* @__PURE__ */ h(hn, { v: c.numDeck.current }),
				r,
				/* @__PURE__ */ h("span", {
					className: "opacity-60",
					children: e("games.bombbusters.infoNumDeckLeft", { n: c.numDeck.left })
				})
			]
		}, "nd"));
	}
	let m = pn(t);
	if (d && m) {
		let n = mn(t, m.yes, r);
		l.push(/* @__PURE__ */ g("span", {
			className: u,
			children: [
				"📡 ",
				m.value,
				" → ",
				n.length > 0 ? n.join("、") : e("games.bombbusters.logRadarNoOne")
			]
		}, "radar"));
	}
	if (d && c.numVisible) {
		let t = p?.features ?? [], n = t.includes("mathCards") ? e("games.bombbusters.infoNumVisibleMath") : t.includes("constraintsByValidation") ? e("games.bombbusters.infoNumVisibleByValid") : e("games.bombbusters.infoNumVisibleTick");
		l.push(/* @__PURE__ */ g("span", {
			className: u,
			children: [
				e("games.bombbusters.infoNumCards"),
				c.numVisible.map((e, t) => /* @__PURE__ */ h(hn, { v: e }, t)),
				/* @__PURE__ */ h("span", {
					className: "opacity-60",
					children: n
				})
			]
		}, "nv"));
	}
	if (d && c.slotCard !== void 0 && l.push(/* @__PURE__ */ g("span", {
		className: u,
		children: [e("games.bombbusters.infoMassCut"), /* @__PURE__ */ h(hn, { v: c.slotCard })]
	}, "slot")), d && c.nano?.nanoWires && l.push(/* @__PURE__ */ g("span", {
		className: u,
		children: ["🤖 ", e("games.bombbusters.nanoCarry", { n: c.nano.nanoWires })]
	}, "nano")), d && c.nanoTrack) {
		let t = c.nanoTrack;
		l.push(/* @__PURE__ */ g("span", {
			className: u,
			children: [
				e("games.bombbusters.infoNanoTrack"),
				t.flipped ? "←" : "",
				t.cards.map((e, n) => /* @__PURE__ */ h(hn, {
					v: n === t.at ? `🤖${e}` : e,
					current: n === t.at
				}, n)),
				t.flipped ? "" : "→"
			]
		}, "nt"));
	}
	if (d && c.oxygen && l.push(/* @__PURE__ */ g("span", {
		className: u,
		children: [
			"🫧 ",
			c.oxygen.pool > 0 ? e("games.bombbusters.oxygenPoolLeft", { n: c.oxygen.pool }) : e("games.bombbusters.oxygenLeft"),
			Object.entries(c.oxygen.perPlayer).map(([e, t]) => /* @__PURE__ */ g("span", {
				className: `font-mono tabular-nums ${e === c.oxygen.holder ? "rounded bg-info-soft px-0.5" : ""}`,
				children: [
					r(e),
					":",
					t
				]
			}, e))
		]
	}, "ox")), f && i && l.push(/* @__PURE__ */ h("span", {
		className: `${u} bg-warn-soft text-warn-ink`,
		children: e("games.bombbusters.weakLinkLine", { text: e(ln[i]) })
	}, "weak")), c.constraints) {
		if (d) for (let t of c.constraints.active) l.push(/* @__PURE__ */ h("span", {
			className: `${u} bg-warn-soft text-warn-ink`,
			children: e("games.bombbusters.constraintLine", {
				id: t,
				text: e(ln[t])
			})
		}, `a${t}`));
		for (let [t, i] of Object.entries(c.constraints.perPlayer)) i && (t === n && f ? l.push(/* @__PURE__ */ h("span", {
			className: `${u} bg-warn-soft text-warn-ink`,
			children: e("games.bombbusters.constraintMine", {
				id: i,
				text: e(ln[i])
			})
		}, `p${t}`)) : t !== n && o && l.push(/* @__PURE__ */ h("span", {
			className: u,
			children: e("games.bombbusters.constraintWho", {
				name: r(t),
				id: i,
				text: e(ln[i])
			})
		}, `p${t}`)));
		if (d) for (let t of c.constraints.side) l.push(/* @__PURE__ */ h("span", {
			className: `${u} opacity-60`,
			children: e("games.bombbusters.constraintSide", {
				id: t,
				text: e(ln[t])
			})
		}, `s${t}`));
	}
	if (d && c.challenges) for (let t of c.challenges) l.push(/* @__PURE__ */ g("span", {
		className: `${u} ${t.done ? "bb-mission-chip--done" : ""}`,
		children: [e("games.bombbusters.challengeLine", {
			id: t.id,
			text: e(un[t.id] ?? "games.bombbusters.ch1")
		}), t.done && " ✓"]
	}, `ch${t.id}`));
	let _ = c.handCards ? c.handCards[n] ?? [] : a;
	f && _.length > 0 && l.push(/* @__PURE__ */ g("span", {
		className: u,
		children: [
			e("games.bombbusters.myNumCards"),
			_.map((e, t) => /* @__PURE__ */ h(hn, { v: e }, t)),
			c.handCards && /* @__PURE__ */ h("span", {
				className: "opacity-60",
				children: e("games.bombbusters.infoHandLimit")
			})
		]
	}, "hc"));
	let v = c.handCardsDown?.[n] ?? [];
	return f && v.length > 0 && l.push(/* @__PURE__ */ h("span", {
		className: `${u} opacity-50`,
		children: v.map((e, t) => /* @__PURE__ */ h(hn, { v: e }, t))
	}, "hd")), d && c.bonusCards && l.push(/* @__PURE__ */ g("span", {
		className: u,
		children: [
			e("games.bombbusters.infoBonusPre"),
			c.bonusCards.map((e, t) => /* @__PURE__ */ h(hn, { v: e }, t)),
			e("games.bombbusters.infoBonusPost")
		]
	}, "bc")), l;
}
function vn({ pub: e, myRid: t, nameOf: n, secretConstraint: r, myCards: i = [], onOpen: a, scope: o = "all", className: s = "" }) {
	let c = l(), u = _n(c, e, t, n, r, i, !1, o);
	return /* @__PURE__ */ h("button", {
		type: "button",
		className: `bb-info-strip scrollbar-none ${s}`,
		onClick: a,
		"aria-label": c("games.bombbusters.missionDetails"),
		children: u.length ? u : o === "all" ? /* @__PURE__ */ h("span", {
			className: "bb-info-strip__empty",
			children: c("games.bombbusters.infoNone")
		}) : null
	});
}
function yn({ deadline: e }) {
	let t = l(), [n, a] = i(() => Date.now());
	r(() => {
		let e = setInterval(() => a(Date.now()), 500);
		return () => clearInterval(e);
	}, []);
	let o = Math.max(0, Math.ceil((e - n) / 1e3)), s = Math.floor(o / 60), c = String(o % 60).padStart(2, "0");
	return /* @__PURE__ */ g("span", {
		className: `flex flex-none items-center rounded-lg border-2 border-ink px-1.5 py-0.5 font-mono text-xs font-extrabold tabular-nums ${o <= 60 ? "bg-rose-100 text-rose-700" : "bg-surface"}`,
		children: ["⏱ ", t("games.bombbusters.timerLeft", { time: `${s}:${c}` })]
	});
}
//#endregion
//#region src/games/bombbusters/guess.ts
var bn = (e, t) => e.features.includes(t);
function xn(e, t, n, r, i, a) {
	let o = e.mods;
	if (i === "yellow") return !e.yellowDone && !o.sevensOnly && e.forcedValue == null && !bn(t, "iberian") && !bn(t, "yellowSeparate");
	if (e.validated.includes(i) || e.forcedValue != null && i !== e.forcedValue || o.sevensOnly || bn(t, "numVisible") && !bn(t, "mathCards") && o.numVisible && !o.numVisible.includes(i)) return !1;
	if (bn(t, "mathCards") && o.numVisible) {
		let e = o.numVisible;
		if (!e.some((t, n) => e.some((r, a) => (n !== a || e.filter((e) => e === t).length > 1) && (t + r === i || Math.abs(t - r) === i)))) return !1;
	}
	if (bn(t, "handCards") && !(o.handCards?.[n] ?? []).includes(i)) return !1;
	if (o.sequence && !e.validated.includes(i)) {
		let e = o.sequence.dir === 1 ? o.sequence.cards.slice(o.sequence.at) : o.sequence.cards.slice(0, o.sequence.cards.length - o.sequence.at).reverse();
		if (e.includes(i) && e[0] !== i) return !1;
	}
	if (o.nanoTrack) {
		let e = o.nanoTrack.cards.indexOf(i);
		if (e < 0 || (o.nanoTrack.flipped ? e >= o.nanoTrack.at : e <= o.nanoTrack.at)) return !1;
	}
	let s = [];
	if (bn(t, "weakLink")) r && s.push(r);
	else {
		s.push(...o.constraints?.active ?? []);
		let e = o.constraints?.perPlayer[n];
		e && s.push(e), r && s.push(r);
	}
	for (let e of s) if (e === "A" && i % 2 == 1 || e === "B" && i % 2 == 0 || e === "C" && i > 6 || e === "D" && i < 7 || e === "E" && (i < 4 || i > 9) || e === "F" && i >= 4 && i <= 9 || a && e === "K") return !1;
	return !0;
}
//#endregion
//#region src/games/bombbusters/wire.tsx
function Sn() {
	let e = l();
	return (t, n) => {
		let r;
		switch (t.kind) {
			case "value":
				r = String(t.value);
				break;
			case "yellow":
				r = e("games.bombbusters.guessYellow");
				break;
			case "parity":
				r = t.odd ? e("games.bombbusters.tokOdd") : e("games.bombbusters.tokEven");
				break;
			case "count":
				r = `×${t.n}`;
				break;
			case "eq":
				r = "=";
				break;
			case "neq": r = "≠";
		}
		return n && t.kind === "value" ? `≠${r}` : r;
	};
}
function Cn({ label: e, fake: t, compact: n = !1 }) {
	return /* @__PURE__ */ h("span", {
		className: `bb-wire-token ${n ? "bb-wire-token--compact" : ""} ${t ? "bb-wire-token--fake" : ""} ${e === "=" || e === "≠" ? "bb-wire-token--sym" : ""}`,
		children: e
	});
}
function wn() {
	return /* @__PURE__ */ g("svg", {
		className: "bb-target-ants",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		focusable: "false",
		children: [/* @__PURE__ */ h("rect", {
			className: "bb-target-ants__base",
			x: "0",
			y: "0",
			width: "100",
			height: "100",
			rx: "7",
			fill: "none",
			vectorEffect: "non-scaling-stroke"
		}), /* @__PURE__ */ h("rect", {
			className: "bb-target-ants__march",
			x: "0",
			y: "0",
			width: "100",
			height: "100",
			rx: "7",
			fill: "none",
			vectorEffect: "non-scaling-stroke",
			strokeDasharray: "6 4",
			children: /* @__PURE__ */ h("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-10",
				dur: "0.55s",
				repeatCount: "indefinite"
			})
		})]
	});
}
function Tn(e, t, n, r) {
	return e === "blue" ? String(Math.round(t)) : e === "yellow" ? n : r;
}
function En({ wire: e, face: t, selected: n, selectable: r, dimmed: i, beat: a, small: s, hideTokens: c, anchor: u = !0, onClick: d }) {
	let f = l(), p = Sn(), { ref: _ } = o(`wire:${e.id}`), v = (e.cut ? e.revealed : null) ?? t, y = v ? Tn(v.color, v.sort, f("games.bombbusters.guessYellow"), f("games.bombbusters.wireRed")) : null, b = v == null ? f("games.bombbusters.wireBack") : v.color === "blue" ? String(Math.round(v.sort)) : `${v.color === "yellow" ? f("games.bombbusters.guessYellow") : f("games.bombbusters.wireRed")} ${Math.floor(v.sort)}`, ee = v == null || v.color !== "blue", te = /* @__PURE__ */ g(m, { children: [
		ee && /* @__PURE__ */ g("svg", {
			"aria-hidden": "true",
			className: "bb-wire-circuit",
			viewBox: "0 0 28 72",
			preserveAspectRatio: "none",
			children: [
				/* @__PURE__ */ h("path", {
					d: "M14 5 C21 11 7 17 14 23 S21 35 14 41 S7 53 14 59 S21 65 14 68",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "2.5"
				}),
				/* @__PURE__ */ h("circle", {
					cx: "14",
					cy: "5",
					r: "2.5"
				}),
				/* @__PURE__ */ h("circle", {
					cx: "14",
					cy: "68",
					r: "2.5"
				})
			]
		}),
		ee && v && /* @__PURE__ */ h("span", {
			"aria-hidden": "true",
			className: "bb-wire-sub",
			children: Math.floor(v.sort)
		}),
		!ee && /* @__PURE__ */ h("span", {
			className: "bb-wire-value",
			children: y
		}),
		e.x && /* @__PURE__ */ h("span", {
			"aria-hidden": "true",
			className: "bb-wire-x",
			children: "×"
		}),
		e.upside && /* @__PURE__ */ h("span", {
			"aria-hidden": "true",
			className: "bb-wire-upside",
			children: "↺"
		})
	] }), x = [
		"bb-wire",
		s ? "bb-wire--compact" : "bb-wire--detail",
		v == null ? "bb-wire--back" : `bb-wire--${v.color}`,
		v?.color === "blue" && y && y.length > 1 ? "bb-wire--double-digit" : "",
		e.cut ? "bb-wire--cut" : "",
		n ? "bb-wire--selected" : "",
		a ? `bb-wire--beat-${a}` : "",
		r ? "bb-wire--selectable" : "",
		i ? "bb-wire--dimmed" : ""
	].filter(Boolean).join(" ");
	return /* @__PURE__ */ g("span", {
		ref: u ? _ : void 0,
		className: "bb-wire-shell",
		children: [e.tokens.length > 0 && !c && /* @__PURE__ */ h("span", {
			className: "bb-wire-tokens",
			children: e.tokens.map((e, t) => /* @__PURE__ */ h(Cn, {
				label: p(e.token, e.fake),
				fake: e.fake,
				compact: s
			}, t))
		}), d ? /* @__PURE__ */ g("button", {
			type: "button",
			"aria-label": b,
			"aria-pressed": n,
			disabled: !r,
			onClick: (e) => {
				e.stopPropagation(), d();
			},
			className: x,
			children: [te, r && !n && /* @__PURE__ */ h(wn, {})]
		}) : /* @__PURE__ */ h("span", {
			"aria-label": b,
			className: x,
			children: te
		})]
	});
}
function Dn({ children: e, label: t, overview: r = !1, onOpen: i, tokensPile: a }) {
	let o = n.toArray(e), s = o.map(() => "minmax(0,1fr)").join(" ");
	return /* @__PURE__ */ g("div", {
		className: `bb-rack-row ${r ? "bb-rack-row--overview" : "bb-rack-row--detail"}`,
		"aria-label": t,
		children: [
			/* @__PURE__ */ h("ul", {
				className: "bb-rack-list",
				style: r ? { gridTemplateColumns: s } : void 0,
				children: o
			}),
			a,
			i && /* @__PURE__ */ h("button", {
				type: "button",
				className: "bb-rack-open",
				"aria-label": t,
				onClick: (e) => {
					e.stopPropagation(), i();
				}
			})
		]
	});
}
//#endregion
//#region src/games/bombbusters/view-player.tsx
function On(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ h(zn, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var kn = {
	dd2000: "games.bombbusters.charDd2000",
	xyray: "games.bombbusters.charXyray",
	radar: "games.bombbusters.charRadar",
	talkies: "games.bombbusters.charTalkies",
	triple: "games.bombbusters.charTriple"
}, An = {
	dd2000: "games.bombbusters.charDd2000Short",
	xyray: "games.bombbusters.charXyrayShort",
	radar: "games.bombbusters.charRadarShort",
	talkies: "games.bombbusters.charTalkiesShort",
	triple: "games.bombbusters.charTripleShort"
}, jn = {
	neq: "games.bombbusters.eqNeqShort",
	talkies: "games.bombbusters.eqTalkiesShort",
	triple: "games.bombbusters.eqTripleShort",
	postit: "games.bombbusters.eqPostitShort",
	super: "games.bombbusters.eqSuperShort",
	rewinder: "games.bombbusters.eqRewinderShort",
	batteries: "games.bombbusters.eqBatteriesShort",
	radar: "games.bombbusters.eqRadarShort",
	stabilizer: "games.bombbusters.eqStabilizerShort",
	xyray: "games.bombbusters.eqXyrayShort",
	coffee: "games.bombbusters.eqCoffeeShort",
	eq: "games.bombbusters.eqEqShort",
	fund: "games.bombbusters.eqFundShort",
	disintegrator: "games.bombbusters.eqDisintegratorShort",
	singleLabel: "games.bombbusters.eqSingleLabelShort",
	threadCutter: "games.bombbusters.eqThreadCutterShort",
	grapple: "games.bombbusters.eqGrappleShort",
	doubleFond: "games.bombbusters.eqDoubleFondShort"
};
function Mn({ name: e, description: t, iconId: n, personal: r = !1, used: i, reason: a, useLabel: o, stateLabel: s, onUse: c }) {
	return /* @__PURE__ */ g("li", {
		className: `bb-equip-sheet__item ${c ? "bb-equip-sheet__item--ready" : "bb-equip-sheet__item--inactive"} ${r ? "bb-equip-sheet__item--personal" : ""}`,
		children: [
			/* @__PURE__ */ h("span", {
				className: "bb-equip-sheet__icon",
				"aria-hidden": "true",
				children: n === "dd2000" ? /* @__PURE__ */ g("svg", {
					viewBox: "0 0 40 40",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "3",
					children: [
						/* @__PURE__ */ h("circle", {
							cx: "13",
							cy: "14",
							r: "8"
						}),
						/* @__PURE__ */ h("circle", {
							cx: "27",
							cy: "27",
							r: "8"
						}),
						/* @__PURE__ */ h("path", { d: "m18 20 4 3" })
					]
				}) : /* @__PURE__ */ h("span", { dangerouslySetInnerHTML: { __html: dn[n] } })
			}),
			/* @__PURE__ */ g("span", {
				className: "bb-equip-sheet__copy",
				children: [/* @__PURE__ */ h("strong", { children: e }), /* @__PURE__ */ h("span", { children: t })]
			}),
			c ? /* @__PURE__ */ h("button", {
				type: "button",
				className: "bb-equip-sheet__use",
				onClick: c,
				children: o
			}) : /* @__PURE__ */ g("span", {
				className: `bb-equip-sheet__state ${i ? "bb-equip-sheet__state--used" : ""}`,
				children: [/* @__PURE__ */ h("strong", { children: s }), a?.map((e, t) => /* @__PURE__ */ h("span", { children: e }, t))]
			})
		]
	});
}
var Nn = {
	dual: "games.bombbusters.historyKindDual",
	solo: "games.bombbusters.historyKindSolo",
	mass: "games.bombbusters.historyKindMass",
	iberian: "games.bombbusters.historyKindIberian",
	reveal: "games.bombbusters.historyKindReveal",
	equip: "games.bombbusters.historyKindEquip"
};
function Pn({ rid: e, turn: t, wireCount: n, pick: r, children: i }) {
	let { ref: a } = o(`seat:${e}`);
	return /* @__PURE__ */ g("section", {
		ref: a,
		className: `bb-seat ${t ? "bb-seat--turn" : ""} ${r ? "bb-seat--pick" : ""} ${r?.selected ? "bb-seat--picked" : ""}`,
		style: { "--bb-wire-count": n },
		onClick: r?.onPick,
		children: [i, r && !r.selected && /* @__PURE__ */ h(wn, {})]
	});
}
var Fn = {
	failToken: "games.bombbusters.pendFailToken",
	pickToken: "games.bombbusters.pendPickToken",
	passToken: "games.bombbusters.pendPassToken",
	giveCard: "games.bombbusters.pendGiveCard",
	chooseConstraint: "games.bombbusters.pendChooseConstraint",
	placeCard: "games.bombbusters.pendPlaceCard",
	moveSequence: "games.bombbusters.pendMoveSequence",
	talkiesPick: "games.bombbusters.pendTalkiesPick"
}, In = { k: "idle" };
function Ln(e, t) {
	return a(e.rid) === null ? e.name : s(t, e.avatar);
}
function Z(e, t) {
	return t === "yellow" ? e("games.bombbusters.guessYellow") : t === "red" ? e("games.bombbusters.wireRed") : String(t);
}
function Rn({ text: e }) {
	let t = e.split("\n").filter((e) => e.trim());
	return /* @__PURE__ */ h("div", {
		className: "bb-mission-brief",
		children: t.map((e, t) => {
			let n = t > 0 ? e.match(/^([^:：\n]{2,16})[:：]\s*(.*)$/s) : null, r = !n && t > 0 && /^[((]/.test(e);
			return /* @__PURE__ */ g("p", {
				className: t === 0 ? "bb-mission-brief__flavor" : r ? "bb-mission-brief__note" : "bb-mission-brief__para",
				children: [n && /* @__PURE__ */ h("strong", {
					className: "bb-mission-brief__label",
					children: n[1]
				}), n ? n[2] : e]
			}, t);
		})
	});
}
function zn({ pub: e, priv: t, members: n, myRid: r, send: a }) {
	let s = l(), _ = c((e) => e.locale), v = Sn(), { ref: y } = o("dial"), { ref: b } = o("track"), { ref: ee } = o("equips"), { ref: te } = o(`seat:${r}`), S = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? Ln(t, _) : e;
	}, C = re.get(e.mission), w = (e) => C.features.includes(e), T = C.fakeTokens === "sergio" && e.captain === r, ne = ae(C), ie = w("numHands") || w("handCards") || w("weakLink") || w("constraintsChoose") || w("constraintsPersonal"), E = ae({
		...C,
		features: C.features.filter((e) => e !== "numHands" && e !== "handCards" && e !== "weakLink" && e !== "constraintsChoose")
	}), D = e.players.find((e) => e.rid === r), se = e.equipments.filter((e) => e.unlocked && !e.used).length + (D?.character && D.revealed && !D.character.used ? 1 : 0), O = new Map((t?.mine ?? []).map((e) => [e.wire, e])), ce = new Map((t?.upsideVisible ?? []).map((e) => [e.wire, e])), k = e.pending.find((e) => e.rid === r) ?? null, le = e.pending[0] ?? null, A = e.cutBeat, ue = new Set(A?.cut ?? []), de = new Set(A?.wires ?? []), j = e.forcedBy ?? e.turn, M = e.phase === "play" && j === r && !k, fe = e.phase === "play" && !le && (w("radarDeck") || w("bossDeck") || w("squeak")) && e.turn === r && e.forcedValue != null && e.forcedBy == null, pe = (D?.racks ?? []).flat().filter((e) => !e.cut), me = /* @__PURE__ */ new Set();
	for (let e of pe) {
		let t = O.get(e.id);
		t && (t.color === "blue" ? me.add(Math.round(t.sort)) : t.color === "yellow" && me.add("yellow"));
	}
	let he = pe.length > 0 && pe.every((t) => {
		let n = O.get(t.id);
		return !n || n.color === "red" || e.mods.cursed !== void 0 && n.color === "blue" && Math.round(n.sort) === e.mods.cursed;
	}), [N, P] = i(In), [ge, _e] = i(null), [ve, ye] = i([]), [be, F] = i(!1), I = e.phase !== "done" && e.cutHistory.length === 0 ? `${e.mission}` : null, [L, R] = i(I), [z, xe] = i(I != null);
	I !== L && (R(I), I !== null && xe(!0));
	let [B, V] = i(!1), [H, U] = i(null), [Se, Ce] = i(null), we = `${e.phase}|${e.turn}|${e.forcedBy}|${e.pending.length}|${e.setupTurn}`, [Te, Ee] = i(we);
	Te !== we && (Ee(we), P(In), _e(null), ye([]), F(!1), U(null), Ce(null));
	let W = (n, i) => xn(e, C, r, t?.secretConstraint ?? null, n, i), De = (e) => {
		let t = O.get(e.id);
		return t?.color === "blue" ? Math.round(t.sort) : t?.color === "yellow" ? "yellow" : null;
	}, G = (t) => {
		let n = e.mods.oxygen;
		if (!n) return !0;
		if (w("oxygenPerPlayer")) return (n.perPlayer[r] ?? 0) >= (typeof t == "number" ? t : 1);
		if (w("oxygenPool")) {
			let e = typeof t == "number" ? t <= 4 ? 1 : t <= 8 ? 2 : 3 : 1;
			return n.pool >= e;
		}
		return w("oxygenCaptain") && n.holder ? (n.perPlayer[n.holder] ?? 0) >= (typeof t == "number" ? t : 1) : !0;
	}, Oe = (t) => {
		if (!M || t.cut || t.x && w("xwiresGate") && !e.yellowDone) return !1;
		let n = De(t);
		return n == null ? !!t.upside && !O.has(t.id) : n === e.mods.cursed || w("sevensLast") && n === 7 || w("massCut4") && e.mods.slotCard === n ? !1 : W(n, !1) && G(n);
	}, Ae = (t) => {
		if (!W(t, !0) || w("sevensLast") && t === 7 || w("massCut4") && e.mods.slotCard === t) return !1;
		let n = pe.filter((e) => De(e) === t);
		if (n.length === 0 || typeof t == "number" && n.length !== 2 && n.length !== 4 || n.some((t) => t.x && w("xwiresGate") && !e.yellowDone)) return !1;
		let r = e.players.flatMap((e) => e.racks.flat()).filter((e) => e.cut && e.revealed?.color === (t === "yellow" ? "yellow" : "blue") && (t === "yellow" || Math.round(e.revealed.sort) === t)).length, i = e.players.length === 2 && C.yellow2p || C.yellow, a = t === "yellow" ? C.yellowFixed?.length ?? (w("iberian") ? Math.min(e.players.length, 4) : i.n) : 4;
		return n.length + r === a;
	}, je = w("numVisible") || w("mathCards") || w("oxygenPerPlayer"), Me = (e, t, n = null) => ({
		k: "dual",
		guess: e,
		guess2: null,
		boost: n,
		target: null,
		wires: [],
		mine: t,
		cover: null,
		math: [],
		payTo: null
	}), Ne = (e, t = !1) => ({
		k: "solo",
		value: e,
		blind: t,
		cover: null,
		math: [],
		payTo: null
	}), Pe = (t) => {
		if (!Oe(t)) return;
		let n = De(t);
		n == null ? (P(Me(e.forcedValue, t.id)), e.forcedValue ?? U({ kind: "blind" })) : Ae(n) ? je ? P(Ne(n)) : a({
			type: "solo",
			value: n
		}) : P(Me(n, t.id));
	}, Fe = (t, n) => {
		if (!n.cut) {
			if (e.phase === "setup" && e.setupTurn === r && t === r) {
				Ie(n);
				return;
			}
			if ((k?.kind === "failToken" || k?.kind === "talkiesPick") && k.wires?.includes(n.id)) {
				a({
					type: "respond",
					kind: k.kind,
					index: k.wires.indexOf(n.id)
				});
				return;
			}
			if (N.k === "idle" && t === r) {
				Pe(n);
				return;
			}
			if (N.k === "dual") {
				if (t === r) {
					if (n.upside && !O.has(n.id) && N.boost == null) {
						let e = N.mine === n.id ? null : n.id;
						P({
							...N,
							mine: e
						}), e != null && N.guess == null && U({ kind: "blind" });
						return;
					}
					let e = De(n), t = [N.guess, N.guess2].filter((e) => e != null);
					e != null && N.guess == null && W(e, !1) ? P({
						...N,
						guess: e,
						mine: n.id
					}) : e != null && t.includes(e) && P({
						...N,
						mine: N.mine === n.id ? null : n.id
					});
					return;
				}
				let i = N.boost === "dd2000" ? 2 : N.boost === "triple" ? 3 : N.boost === "super" ? 99 : 1;
				if (N.target !== null && N.target !== t) return;
				if (N.wires.includes(n.id)) {
					let e = N.wires.filter((e) => e !== n.id);
					P({
						...N,
						wires: e,
						target: e.length ? N.target : null
					});
					return;
				}
				if (N.boost === "super") {
					let r = e.players.find((e) => e.rid === t).racks.find((e) => e.some((e) => e.id === n.id));
					P({
						...N,
						target: t,
						wires: r.filter((e) => !e.cut).map((e) => e.id)
					});
					return;
				}
				if (N.wires.length >= i) return;
				P({
					...N,
					target: t,
					wires: [...N.wires, n.id]
				}), N.boost === "xyray" && N.guess2 == null && U({ kind: "xyray" });
				return;
			}
			if (N.k === "mass") {
				let e = N.picks.some((e) => e.wire === n.id);
				P({
					...N,
					picks: e ? N.picks.filter((e) => e.wire !== n.id) : [...N.picks, {
						rid: t,
						wire: n.id
					}]
				});
				return;
			}
			if (N.k === "iberian" && t !== r) {
				P({
					...N,
					pick: {
						rid: t,
						wire: n.id
					}
				});
				return;
			}
			if (N.k === "equip") {
				if (t === r) {
					let e = N.myWires.includes(n.id) ? N.myWires.filter((e) => e !== n.id) : [...N.myWires.slice(-1), n.id];
					P({
						...N,
						myWires: e
					});
				} else P({
					...N,
					theirWire: n.id,
					target: t
				});
			}
		}
	}, Ie = (t) => {
		let n = O.get(t.id);
		if ((!n || n.color !== "blue") && (C.setupTokens !== "fake" || n?.color !== "red")) return;
		let i = C.setupTokens, o = n ? Math.round(n.sort) : 0;
		if (!T) {
			if (i === "standard" || i === "captainNone" || i === "captainRandom") {
				a({
					type: "setupToken",
					placements: [{
						wire: t.id,
						token: {
							kind: "value",
							value: o
						}
					}]
				});
				return;
			}
			if (i === "parity") {
				a({
					type: "setupToken",
					placements: [{
						wire: t.id,
						token: {
							kind: "parity",
							odd: o % 2 == 1
						}
					}]
				});
				return;
			}
			if (i === "count") {
				let e = pe.filter((e) => {
					let t = O.get(e.id);
					return t?.color === "blue" && Math.round(t.sort) === o;
				}).length;
				e >= 1 && e <= 3 && a({
					type: "setupToken",
					placements: [{
						wire: t.id,
						token: {
							kind: "count",
							n: e
						}
					}]
				});
				return;
			}
			if (i === "mixed") {
				if ((e.players.findIndex((e) => e.rid === r) - e.players.findIndex((t) => t.rid === e.captain) + e.players.length) % e.players.length % 2 == 0) {
					let e = pe.filter((e) => {
						let t = O.get(e.id);
						return t?.color === "blue" && Math.round(t.sort) === o;
					}).length;
					e >= 1 && e <= 3 && a({
						type: "setupToken",
						placements: [{
							wire: t.id,
							token: {
								kind: "count",
								n: e
							}
						}]
					});
				} else a({
					type: "setupToken",
					placements: [{
						wire: t.id,
						token: {
							kind: "parity",
							odd: o % 2 == 1
						}
					}]
				});
				return;
			}
		}
		if (ge === t.id) {
			_e(null);
			return;
		}
		_e(t.id), U({ kind: "setup" });
	}, K = (e) => {
		if (ge == null) return;
		let t = e === "yellow" ? { kind: "yellow" } : {
			kind: "value",
			value: e
		}, n = [...ve, {
			wire: ge,
			token: t
		}];
		ye(n), _e(null), n.length === 2 && (a({
			type: "setupToken",
			placements: n
		}), ye([]));
	}, Le = (e) => ({
		...e.cover == null ? {} : { cover: e.cover },
		...e.math.length === 2 ? { math: {
			a: e.math[0],
			b: e.math[1]
		} } : {},
		...e.payTo ? { payTo: e.payTo } : {}
	}), Re = (e) => {
		e.guess != null && e.target != null && e.wires.length !== 0 && (a({
			type: "dual",
			target: e.target,
			wires: e.wires,
			guesses: e.boost === "xyray" ? [e.guess, e.guess2 ?? e.guess] : [e.guess],
			...e.mine == null ? {} : { mine: e.mine },
			...e.boost === "dd2000" ? { dd2000: !0 } : {},
			...e.boost === "triple" || e.boost === "super" ? { boost: e.boost } : {},
			...e.boost === "xyray" ? { xyray: !0 } : {},
			...Le(e)
		}), P(In));
	}, ze = (e) => {
		e.value != null && (a({
			type: "solo",
			value: e.value,
			...Le(e)
		}), P(In));
	}, q = (e) => {
		let t = e.id, n = t === "personal" ? D?.character?.id ?? null : null, r = t === "personal" ? n === "radar" || n === "talkies" ? n : null : t;
		if (!r) return;
		let i = {};
		if (r === "neq" || r === "eq" || r === "threadCutter") {
			if (e.myWires.length !== 2) return;
			i.a = e.myWires[0], i.b = e.myWires[1];
		} else if (r === "talkies") {
			if (e.myWires.length !== 1 || e.target == null) return;
			i.myWire = e.myWires[0], i.target = e.target;
		} else if (r === "grapple") {
			if (e.theirWire == null) return;
			i.theirWire = e.theirWire, i.target = e.target;
		} else if (r === "postit" || r === "singleLabel") {
			if (e.myWires.length !== 1) return;
			if (i.wire = e.myWires[0], r === "postit") {
				let t = Be(e.myWires[0]);
				if (!t) return;
				i.token = t;
			}
		} else if (r === "batteries") {
			if (e.rids.length < 1 || e.rids.length > 2) return;
			i.rids = e.rids;
		} else if (r === "coffee") {
			if (!e.target) return;
			i.next = e.target;
		}
		a({
			type: "equip",
			id: t,
			params: i
		}), P(In);
	}, Be = (t) => {
		let n = O.get(t);
		if (!n || n.color !== "blue") return null;
		let i = Math.round(n.sort), a = w("fakeTokens"), o = C.tokenStyle;
		if (o === "parity") return {
			kind: "parity",
			odd: i % 2 == 1
		};
		if (o === "count") {
			let e = pe.filter((e) => {
				let t = O.get(e.id);
				return t?.color === "blue" && Math.round(t.sort) === i;
			}).length;
			return a ? {
				kind: "count",
				n: 1
			} : e >= 1 && e <= 3 ? {
				kind: "count",
				n: e
			} : null;
		}
		if (o === "mixed") {
			if ((e.players.findIndex((e) => e.rid === r) - e.players.findIndex((t) => t.rid === e.captain) + e.players.length) % e.players.length % 2 == 1) return {
				kind: "parity",
				odd: i % 2 == 1
			};
			let t = pe.filter((e) => {
				let t = O.get(e.id);
				return t?.color === "blue" && Math.round(t.sort) === i;
			}).length;
			return t >= 1 && t <= 3 ? {
				kind: "count",
				n: t
			} : null;
		}
		return {
			kind: "value",
			value: a ? i % 12 + 1 : i
		};
	}, Ve = pn(e), He = (() => {
		if (!Ve || Ve.yes.length === 0) return null;
		let t = /* @__PURE__ */ new Set();
		for (let n of Ve.yes) {
			let r = e.players.find((e) => e.rid === n.rid);
			for (let e of r?.racks[n.rack - 1] ?? []) e.cut || t.add(e.id);
		}
		return t.size > 0 ? t : null;
	})(), Ue = Ve && Ve.yes.length > 0 ? new Set(Ve.yes.map((e) => e.rid)) : null, We = (t, n) => {
		if (n.cut) return !1;
		if (k) return le === k && t === r && (k.kind === "failToken" || k.kind === "talkiesPick") && (k.wires?.includes(n.id) ?? !1);
		if (le) return !1;
		if (e.phase === "setup") {
			if (t !== r || e.setupTurn !== r) return !1;
			let i = O.get(n.id);
			return i?.color === "blue" || C.setupTokens === "fake" && i?.color === "red";
		}
		if (e.phase !== "play") return !1;
		if (N.k === "idle") return t === r && Oe(n);
		if (N.k === "dual") {
			if (t === r) {
				if (n.x && w("xwiresGate") && !e.yellowDone) return !1;
				if (n.upside && !O.has(n.id)) return N.boost == null;
				let t = De(n);
				return t != null && (N.guess === t || N.guess2 === t || N.guess == null && W(t, !1));
			}
			let i = N.boost === "dd2000" ? 2 : N.boost === "triple" ? 3 : N.boost === "super" ? 99 : 1;
			return He && N.guess === e.forcedValue && N.guess2 == null && N.boost !== "xyray" && !He.has(n.id) ? !1 : (N.target == null || N.target === t) && (N.wires.includes(n.id) || N.wires.length < i);
		}
		if (N.k === "mass") {
			let e = w("massCut4") ? 4 : w("massCutRed3") || w("massCutYellow3") ? 3 : 1;
			return N.picks.some((e) => e.wire === n.id) || N.picks.length < e;
		}
		if (N.k === "iberian") return t !== r;
		if (N.k !== "equip") return !1;
		let i = N.id === "personal" ? D?.character?.id : N.id;
		if (t !== r) return i === "grapple" && !n.x && !n.upside;
		if (N.myWires.includes(n.id)) return !0;
		let a = O.get(n.id);
		if (i === "talkies") return !n.x && !n.upside;
		if (i === "postit") return !n.x && !n.upside && Be(n.id) != null;
		if (i === "singleLabel") return a?.color === "blue";
		if (i === "threadCutter") {
			if (a?.color !== "blue" || w("sevensLast") && Math.round(a.sort) === 7) return !1;
			let e = N.myWires.at(-1);
			return pe.some((t) => t.id !== n.id && (e == null || t.id === e) && O.get(t.id)?.color === "blue" && Math.round(O.get(t.id).sort) === Math.round(a.sort));
		}
		if (i === "eq" || i === "neq") {
			let e = D?.racks.find((e) => e.some((e) => e.id === n.id)), t = e?.findIndex((e) => e.id === n.id) ?? -1;
			if (!e || t < 0 || !a) return !1;
			let r = a.color === "blue" ? Math.round(a.sort) : a.color, o = N.myWires.at(-1);
			return [e[t - 1], e[t + 1]].some((e) => {
				if (!e || e.cut || o != null && e.id !== o) return !1;
				let t = O.get(e.id);
				if (!t) return !1;
				let n = t.color === "blue" ? Math.round(t.sort) : t.color;
				return i === "eq" ? r === n : r !== n;
			});
		}
		return !1;
	}, J = (t) => {
		switch (t.k) {
			case "dualOk": return s("games.bombbusters.logDualOk", {
				from: S(t.from),
				to: S(t.to),
				guess: Z(s, t.guess)
			});
			case "dualFail": return s("games.bombbusters.logDualFail", {
				from: S(t.from),
				to: S(t.to),
				guess: Z(s, t.guess)
			});
			case "solo": return s("games.bombbusters.logSolo", {
				name: S(t.rid),
				value: Z(s, t.value),
				n: t.n
			});
			case "reveal": return s("games.bombbusters.logReveal", {
				name: S(t.rid),
				n: t.n
			});
			case "equip": return s("games.bombbusters.logEquip", {
				name: S(t.rid),
				equip: s(sn[t.id] ?? "games.bombbusters.eqRadar")
			});
			case "validate": return s("games.bombbusters.logValidate", { value: Z(s, t.value) });
			case "pass": return s("games.bombbusters.logPass", { name: S(t.rid) });
			case "claim": return s("games.bombbusters.logClaim", { name: S(t.rid) });
			case "mass": return t.ok ? s("games.bombbusters.logMassOk", {
				name: S(t.rid),
				n: t.n
			}) : s("games.bombbusters.logMassFail", { name: S(t.rid) });
			case "iberian": return t.ok ? s("games.bombbusters.logIberianOk", {
				from: S(t.from),
				to: S(t.to)
			}) : s("games.bombbusters.logIberianFail", {
				from: S(t.from),
				to: S(t.to)
			});
			case "accuse": return t.ok ? s("games.bombbusters.logAccuseOk", {
				from: S(t.from),
				to: S(t.to)
			}) : s("games.bombbusters.logAccuseFail", {
				from: S(t.from),
				to: S(t.to)
			});
			case "boom": return s(Bn(t.reason));
			case "radar": {
				let n = mn(e, t.yes, S);
				return s("games.bombbusters.logRadar", {
					name: S(t.rid),
					value: t.value,
					yes: n.length > 0 ? n.join("、") : s("games.bombbusters.logRadarNoOne")
				});
			}
		}
	}, Ge = /* @__PURE__ */ new Map();
	for (let t of e.cutHistory) Ge.set(t.actor, t);
	let Ke = (e) => {
		let t = s(e.outcome === "success" ? "games.bombbusters.historyBriefSuccess" : e.outcome === "boom" ? "games.bombbusters.historyBriefBoom" : "games.bombbusters.historyBriefMiss", { n: e.cut.length });
		if (e.values.length === 0) return t;
		let n = e.target ? S(e.target) : s("games.bombbusters.cutSumSelf");
		return `${s("games.bombbusters.cutSum", {
			who: n,
			value: e.values.map((e) => Z(s, e)).join("/")
		})},${t}`;
	}, qe = (e) => e.owner == null ? s("games.bombbusters.historyNano") : `${S(e.owner)} · ${s("games.bombbusters.historyPosition", {
		rack: e.rack ?? 1,
		position: e.position ?? 1
	})}`, Je = e.cutHistory.map((e) => ({
		type: "cut",
		entry: e
	})), Ye = e.cutHistory.some((e) => e.outcome === "boom");
	for (let t of e.log) t.k !== "dualOk" && t.k !== "dualFail" && t.k !== "solo" && t.k !== "reveal" && t.k !== "mass" && t.k !== "iberian" && t.k !== "validate" && (t.k !== "equip" || t.id !== "radar" && t.id !== "threadCutter" && t.id !== "disintegrator") && (t.k === "boom" && Ye || Je.push({
		type: "log",
		line: t
	}));
	Je.sort((e, t) => (t.type === "cut" ? t.entry.seq : t.line.seq) - (e.type === "cut" ? e.entry.seq : e.line.seq));
	let Xe = (e) => /* @__PURE__ */ g("article", {
		className: `bb-history-entry bb-history-entry--${e.outcome}`,
		children: [
			/* @__PURE__ */ g("div", {
				className: "bb-history-entry__heading",
				children: [
					/* @__PURE__ */ h("b", { children: s(Nn[e.kind]) }),
					/* @__PURE__ */ h("strong", { children: e.target ? s("games.bombbusters.beatActorTarget", {
						actor: S(e.actor),
						target: S(e.target)
					}) : s("games.bombbusters.beatActor", { actor: S(e.actor) }) }),
					/* @__PURE__ */ h("span", { children: s(e.outcome === "success" ? "games.bombbusters.beatSuccess" : e.outcome === "boom" ? "games.bombbusters.beatBoom" : "games.bombbusters.beatMiss") })
				]
			}),
			e.values.length > 0 && /* @__PURE__ */ h("p", {
				className: "bb-history-entry__called",
				children: s("games.bombbusters.beatCalled", { value: e.values.map((e) => Z(s, e)).join(" / ") })
			}),
			/* @__PURE__ */ h("ul", {
				className: "bb-history-entry__targets",
				children: e.targets.map((e) => /* @__PURE__ */ g("li", { children: [/* @__PURE__ */ h("span", { children: qe(e) }), /* @__PURE__ */ h("b", { children: e.revealed ? s("games.bombbusters.historyCutValue", { value: Z(s, e.revealed.color === "blue" ? Math.round(e.revealed.sort) : e.revealed.color) }) : s("games.bombbusters.historyUncut") })] }, e.wire))
			}),
			/* @__PURE__ */ g("div", {
				className: "bb-history-entry__changes",
				children: [
					e.hpDelta > 0 && /* @__PURE__ */ h("span", { children: s("games.bombbusters.beatHpLoss", { n: e.hpDelta }) }),
					e.hpDelta < 0 && /* @__PURE__ */ h("span", { children: s("games.bombbusters.beatHpGain", { n: -e.hpDelta }) }),
					e.validated.length > 0 && /* @__PURE__ */ h("span", { children: s("games.bombbusters.beatValidated", { value: e.validated.map((e) => Z(s, e)).join(" / ") }) }),
					e.equipments.length > 0 && /* @__PURE__ */ h("span", { children: s("games.bombbusters.historyEquipment", { names: e.equipments.map((e) => s(sn[e])).join(" / ") }) })
				]
			})
		]
	}, `c${e.seq}`), Ze = "info", Qe, $e;
	e.phase === "resolving" && A ? (Ze = A.outcome === "success" ? "done" : "warn", Qe = s(A.outcome === "success" ? "games.bombbusters.beatSuccess" : A.outcome === "boom" ? "games.bombbusters.beatBoom" : "games.bombbusters.beatMiss"), $e = A.hpDelta > 0 ? s("games.bombbusters.beatHpLoss", { n: A.hpDelta }) : A.hpDelta < 0 ? s("games.bombbusters.beatHpGain", { n: -A.hpDelta }) : A.validated.length > 0 ? s("games.bombbusters.beatValidated", { value: A.validated.map((e) => Z(s, e)).join(" / ") }) : void 0) : e.phase === "done" && e.result ? (Ze = e.result.win ? "done" : "warn", Qe = e.result.win ? s("games.bombbusters.overWin") : s(Bn(e.result.reason))) : le ? (Ze = le.rid === r ? "accent" : "warn", Qe = s(Fn[le.kind] ?? "games.bombbusters.pendFailToken", { name: S(le.rid) }), le.kind === "failToken" && le.cut && (Qe = s("games.bombbusters.pendPickCut")), le.kind === "failToken" && le.fake && ($e = s("games.bombbusters.pendFakeToken", { name: S(le.rid) }))) : e.phase === "setup" ? (Ze = e.setupTurn === r ? "accent" : "info", Qe = e.setupTurn === r ? s("games.bombbusters.setupTokenYou") : s("games.bombbusters.setupTokenWait", { name: S(e.setupTurn ?? e.captain) })) : e.turn === null ? (Ze = "warn", Qe = s("games.bombbusters.actClaim")) : e.mods.squeak && e.forcedValue != null && e.forcedBy == null ? (Ze = "warn", Qe = e.turn === r && e.captain === r ? s("games.bombbusters.squeakOpenCaptain", { value: e.forcedValue }) : s("games.bombbusters.squeakOpen", { value: e.forcedValue })) : j === r ? (Ze = "accent", Qe = s("games.bombbusters.turnYou")) : Qe = s("games.bombbusters.turnWait", { name: S(j ?? e.captain) }), e.phase === "play" && e.forcedValue != null && ($e = s("games.bombbusters.forcedOnly", { value: e.forcedValue }));
	let et = e.log[e.log.length - 1];
	et && e.phase !== "resolving" && ($e = $e ? `${$e} · ${J(et)}` : J(et));
	let tt = `#${e.mission}`, nt = e.players.filter((e) => e.rid !== r);
	function rt() {
		if (e.phase !== "play") return null;
		if (k) return k.kind === "failToken" || k.kind === "talkiesPick" ? null : X(k);
		if (N.k === "iberian") return dt(N);
		if (N.k === "accuse") return ft(N);
		if (N.k === "equip") {
			let e = N.id === "personal" ? D?.character?.id : N.id;
			if (e && pt.has(e)) return mt(N);
		}
		return null;
	}
	function it() {
		if (e.phase === "done" || e.phase === "resolving" || k) return null;
		if (e.phase === "setup") return e.setupTurn === r ? ht() : null;
		if (N.k === "dual") return st(N);
		if (N.k === "solo") return ct(N);
		if (N.k === "mass") return lt(N);
		if (N.k === "iberian" || N.k === "accuse") return null;
		if (N.k === "equip") {
			let e = N.id === "personal" ? D?.character?.id : N.id;
			return e && pt.has(e) ? null : mt(N);
		}
		return gt();
	}
	let Y = (e, t, n, r = !1, i, a = !1) => /* @__PURE__ */ g("button", {
		type: "button",
		disabled: r,
		"aria-pressed": t,
		onClick: n,
		className: `flex min-h-11 flex-none items-center justify-center rounded-lg border-2 border-ink px-2 text-xs font-bold ${a ? "bb-target-chip" : ""} ${t ? "bg-info-soft text-info-ink shadow-[1px_1px_0_var(--color-ink)]" : "bg-surface"} ${r ? "opacity-40" : ""}`,
		children: [e, a && !t && !r && /* @__PURE__ */ h(wn, {})]
	}, i);
	function at(t, n, r) {
		let i = [];
		if (w("numVisible") && !w("mathCards") && e.mods.numVisible) {
			let a = e.mods.numVisible, o = a.length === 1 ? a : a.filter((e) => e !== r);
			i.push(/* @__PURE__ */ g("span", {
				className: "bb-extra-choice",
				children: [/* @__PURE__ */ h("span", {
					className: "bb-extra-choice__label",
					children: s("games.bombbusters.pickCover")
				}), /* @__PURE__ */ h("span", {
					className: "bb-extra-choice__values",
					children: o.map((e) => Y(/* @__PURE__ */ h("span", {
						className: "font-mono tabular-nums",
						children: e
					}), t.cover === e, () => n({ cover: e }), !1, `c${e}`))
				})]
			}, "cover"));
		}
		if (w("mathCards") && e.mods.numVisible) {
			let a = t.math.map((t) => e.mods.numVisible[t]), o = a.length === 2 && typeof r == "number" && (a[0] + a[1] === r || Math.abs(a[0] - a[1]) === r), c = [...a].sort((e, t) => t - e), l = o ? `${c[0]} ${c[0] + c[1] === r ? "+" : "−"} ${c[1]} = ${r}` : null, u = e.mods.numVisible.map((e, r) => Y(/* @__PURE__ */ h("span", {
				className: "font-mono tabular-nums",
				children: e
			}), t.math.includes(r), () => n({ math: t.math.includes(r) ? t.math.filter((e) => e !== r) : [...t.math.slice(-1), r] }), !1, `m${r}`));
			i.push(/* @__PURE__ */ g("span", {
				className: "bb-extra-choice",
				children: [/* @__PURE__ */ g("span", {
					className: "bb-extra-choice__mobile",
					children: [/* @__PURE__ */ h("span", {
						className: "bb-extra-choice__label",
						children: s("games.bombbusters.pickMath")
					}), /* @__PURE__ */ h("span", {
						className: "bb-extra-choice__values",
						children: u
					})]
				}), /* @__PURE__ */ g("details", {
					className: "bb-extra-choice__details",
					open: !o,
					children: [/* @__PURE__ */ g("summary", {
						className: "bb-extra-choice__summary",
						children: [l ?? s("games.bombbusters.pickMath"), /* @__PURE__ */ h("span", {
							"aria-hidden": "true",
							children: "⌄"
						})]
					}), /* @__PURE__ */ h("span", {
						className: "bb-extra-choice__values",
						children: u
					})]
				})]
			}, "math"));
		}
		return w("oxygenPerPlayer") && i.push(/* @__PURE__ */ h("span", {
			className: "flex flex-none items-center text-[10px] font-bold opacity-70",
			children: t.payTo ? `🫧 ${S(t.payTo)}` : s("games.bombbusters.payToHint")
		}, "pay")), i.length ? /* @__PURE__ */ h("div", {
			className: "bb-cut-panel__extras",
			children: i
		}) : null;
	}
	function ot(t, n) {
		if (w("numVisible") && !w("mathCards") && e.mods.numVisible && e.mods.numVisible.length > 0 && t.cover == null) return !1;
		if (w("mathCards")) {
			if (t.math.length !== 2 || typeof n != "number") return !1;
			let r = e.mods.numVisible[t.math[0]], i = e.mods.numVisible[t.math[1]];
			if (r + i !== n && Math.abs(r - i) !== n) return !1;
		}
		return !(w("oxygenPerPlayer") && !t.payTo);
	}
	function st(t) {
		let n = t.boost === "dd2000" ? 2 : t.boost === "triple" ? 3 : (t.boost, 1), r = t.guess != null && t.target != null && t.wires.length >= n && (t.boost !== "xyray" || t.guess2 != null) && ot(t, t.guess), i = e.players.find((e) => e.rid === t.target)?.racks.flat() ?? [], a = t.wires.map((e) => i.findIndex((t) => t.id === e) + 1).filter((e) => e > 0), o = t.mine != null && !O.has(t.mine), c = D?.character, l = !!c && c.id === "dd2000" && !c.used && D?.revealed, u = (t) => e.equipments.some((e) => e.id === t && e.unlocked && !e.used), d = u("xyray") || !!c && c.id === "xyray" && !c.used && D?.revealed, f = u("triple") || !!c && c.id === "triple" && !c.used && D?.revealed;
		return /* @__PURE__ */ g("div", {
			className: "bb-cut-panel",
			children: [/* @__PURE__ */ g("div", {
				className: "bb-cut-panel__options",
				children: [
					/* @__PURE__ */ g("div", {
						className: "bb-cut-panel__heading",
						children: [/* @__PURE__ */ g("span", {
							className: "bb-cut-panel__title",
							children: [/* @__PURE__ */ h("span", { children: t.boost === "dd2000" ? s("games.bombbusters.charDd2000") : t.boost ? s(sn[t.boost]) : s("games.bombbusters.actDual") }), t.guess != null && /* @__PURE__ */ h("span", {
								className: "bb-cut-panel__value",
								children: Z(s, t.guess)
							})]
						}), t.target && a.length > 0 && /* @__PURE__ */ h("span", {
							className: "bb-cut-panel__target",
							children: s("games.bombbusters.cutTarget", {
								name: S(t.target),
								positions: a.join("/")
							})
						})]
					}),
					at(t, (e) => P({
						...t,
						...e
					}), t.guess),
					t.guess == null && Y(s("games.bombbusters.valuePickOne"), !1, () => U({ kind: t.boost === "xyray" ? "xyray" : "blind" }), !1, "bp", !0),
					t.boost === "xyray" && t.guess != null && Y(`${Z(s, t.guess)} / ${t.guess2 == null ? "…" : Z(s, t.guess2)}`, !1, () => U({ kind: "xyray" })),
					o && t.boost == null && Y(s("games.bombbusters.actSolo"), !1, () => {
						P(Ne(e.forcedValue, !0)), e.forcedValue ?? U({ kind: "blind" });
					}),
					l && Y(s("games.bombbusters.charDd2000"), t.boost === "dd2000", () => P({
						...t,
						boost: t.boost === "dd2000" ? null : "dd2000",
						wires: [],
						target: null,
						mine: o ? null : t.mine,
						guess: t.guess === "yellow" ? null : t.guess
					})),
					f && Y(s("games.bombbusters.eqTriple"), t.boost === "triple", () => P({
						...t,
						boost: t.boost === "triple" ? null : "triple",
						wires: [],
						target: null,
						mine: o ? null : t.mine,
						guess: t.guess === "yellow" ? null : t.guess
					})),
					u("super") && Y(s("games.bombbusters.eqSuper"), t.boost === "super", () => P({
						...t,
						boost: t.boost === "super" ? null : "super",
						wires: [],
						target: null,
						mine: o ? null : t.mine,
						guess: t.guess === "yellow" ? null : t.guess
					})),
					d && Y(s("games.bombbusters.eqXyray"), t.boost === "xyray", () => P({
						...t,
						boost: t.boost === "xyray" ? null : "xyray",
						guess2: null,
						mine: o ? null : t.mine,
						guess: t.guess === "yellow" ? null : t.guess
					}))
				]
			}), /* @__PURE__ */ g("div", {
				className: "bb-cut-panel__submit",
				children: [Y(s("games.bombbusters.cancel"), !1, () => P(In)), /* @__PURE__ */ h("button", {
					type: "button",
					disabled: !r,
					onClick: () => Re(t),
					className: "btn-base min-h-11 flex-none px-4",
					style: { background: x.accent },
					children: s("games.bombbusters.confirm")
				})]
			})]
		});
	}
	function ct(e) {
		let t = e.value != null && ot(e, e.value);
		return /* @__PURE__ */ g("div", {
			className: "bb-cut-panel",
			children: [/* @__PURE__ */ g("div", {
				className: "bb-cut-panel__options",
				children: [
					/* @__PURE__ */ h("div", {
						className: "bb-cut-panel__heading",
						children: /* @__PURE__ */ g("span", {
							className: "bb-cut-panel__title",
							children: [/* @__PURE__ */ h("span", { children: s("games.bombbusters.actSolo") }), e.value != null && /* @__PURE__ */ h("span", {
								className: "bb-cut-panel__value",
								children: Z(s, e.value)
							})]
						})
					}),
					e.value == null && Y(s("games.bombbusters.valuePickOne"), !1, () => U({ kind: "blind" }), !1, "bp", !0),
					at(e, (t) => P({
						...e,
						...t
					}), e.value)
				]
			}), /* @__PURE__ */ g("div", {
				className: "bb-cut-panel__submit",
				children: [Y(s("games.bombbusters.cancel"), !1, () => P(In)), /* @__PURE__ */ h("button", {
					type: "button",
					disabled: !t,
					onClick: () => ze(e),
					className: "btn-base min-h-11 flex-none px-4",
					style: { background: x.accent },
					children: s("games.bombbusters.confirm")
				})]
			})]
		});
	}
	function lt(t) {
		let n = [];
		(w("massCutRed3") || w("massCutYellow3")) && n.push(3), w("massCut4") && n.push(4), e.mods.challenges?.some((e) => e.id === 1 && !e.done) && n.push(1);
		let r = n.includes(t.picks.length);
		return /* @__PURE__ */ g("div", {
			className: "bb-cut-panel",
			children: [/* @__PURE__ */ h("div", {
				className: "bb-cut-panel__options",
				children: /* @__PURE__ */ g("span", {
					className: "bb-cut-panel__title",
					children: [
						s("games.bombbusters.actMass"),
						" · ",
						t.picks.length
					]
				})
			}), /* @__PURE__ */ g("div", {
				className: "bb-cut-panel__submit",
				children: [Y(s("games.bombbusters.cancel"), !1, () => P(In)), /* @__PURE__ */ h("button", {
					type: "button",
					disabled: !r,
					onClick: () => {
						a({
							type: "massCut",
							picks: t.picks
						}), P(In);
					},
					className: "btn-base min-h-11 flex-none px-4",
					style: { background: x.accent },
					children: s("games.bombbusters.confirm")
				})]
			})]
		});
	}
	function ut(e, t, n) {
		return /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("p", {
				className: "bb-overlay__hint",
				children: e
			}),
			/* @__PURE__ */ h("div", {
				className: "bb-overlay__body",
				children: t
			}),
			/* @__PURE__ */ h("div", {
				className: "bb-overlay__submit",
				children: n
			})
		] });
	}
	function dt(e) {
		return ut(s("games.bombbusters.iberianHint"), null, /* @__PURE__ */ g(m, { children: [Y(s("games.bombbusters.cancel"), !1, () => P(In)), /* @__PURE__ */ h("button", {
			type: "button",
			disabled: !e.pick,
			onClick: () => {
				a({
					type: "iberian",
					target: e.pick.rid,
					wire: e.pick.wire
				}), P(In);
			},
			className: "btn-base min-h-12 flex-none px-6",
			style: { background: x.accent },
			children: s("games.bombbusters.confirm")
		})] }));
	}
	function ft(e) {
		return ut(/* @__PURE__ */ g(m, { children: [s("games.bombbusters.accuseHint"), e.target ? ` · ${S(e.target)}` : ""] }), oe.map((t) => Y(t, e.constraint === t, () => P({
			...e,
			constraint: t
		}), !1, `c${t}`)), /* @__PURE__ */ g(m, { children: [Y(s("games.bombbusters.cancel"), !1, () => P(In)), /* @__PURE__ */ h("button", {
			type: "button",
			disabled: !e.target || !e.constraint,
			onClick: () => {
				a({
					type: "accuse",
					target: e.target,
					constraint: e.constraint
				}), P(In);
			},
			className: "btn-base min-h-12 flex-none px-6",
			style: { background: x.accent },
			children: s("games.bombbusters.confirm")
		})] }));
	}
	let pt = /* @__PURE__ */ new Set([
		"coffee",
		"batteries",
		"fund",
		"grapple"
	]);
	function mt(e) {
		let t = e.id, n = t === "personal" ? D?.character?.id ?? null : t, r = /* @__PURE__ */ g(m, { children: [Y(s("games.bombbusters.cancel"), !1, () => P(In)), /* @__PURE__ */ h("button", {
			type: "button",
			onClick: () => q(e),
			className: "btn-base min-h-12 flex-none px-6",
			style: { background: x.accent },
			children: s("games.bombbusters.confirm")
		})] });
		return n && pt.has(n) ? ut(s(cn[n]), null, r) : /* @__PURE__ */ g("div", {
			className: "bb-cut-panel",
			children: [/* @__PURE__ */ g("div", {
				className: "bb-cut-panel__options",
				children: [/* @__PURE__ */ h("span", {
					className: "bb-cut-panel__target",
					children: (e.id === "personal" ? s("games.bombbusters.actPersonal") : s(sn[e.id])) + (e.target ? ` · ${S(e.target)}` : "")
				}), n === "talkies" && /* @__PURE__ */ h("span", {
					className: "flex-none text-[10px] font-bold opacity-70",
					children: s(cn.talkies)
				})]
			}), /* @__PURE__ */ h("div", {
				className: "bb-cut-panel__submit",
				children: r
			})]
		});
	}
	function X(n) {
		let i = s(Fn[n.kind] ?? "games.bombbusters.pendFailToken", { name: S(r) });
		switch (n.kind) {
			case "pickToken": return ut(i, (n.options ?? []).map((e, t) => Y(/* @__PURE__ */ h("span", {
				className: "font-mono tabular-nums",
				children: e
			}), !1, () => a({
				type: "respond",
				kind: "pickToken",
				index: t
			}), !1, `pt${t}`)), null);
			case "passToken": {
				let t = (t) => {
					if (t == null) return "?";
					for (let n of e.players) for (let e of n.racks) for (let n of e) if (n.id === t) {
						let e = n.tokens.find((e) => e.fake) ?? n.tokens[0];
						return e ? v(e.token, e.fake) : "?";
					}
					return "?";
				};
				return ut(i, (n.options ?? []).map((e, r) => Y(t(n.wires?.[r]), !1, () => a({
					type: "respond",
					kind: "passToken",
					index: r
				}), !1, `ps${r}`)), null);
			}
			case "giveCard": {
				let t = e.mods.handCards?.[r] ?? [], n = e.mods.handCardsDown?.[r] ?? [];
				return ut(s("games.bombbusters.giveCardHint"), /* @__PURE__ */ g(m, { children: [t.map((e, t) => Y(/* @__PURE__ */ h("span", {
					className: "font-mono tabular-nums",
					children: e
				}), Se === e, () => Ce(Se === e ? null : e), !1, `gc${t}`)), n.map((e, t) => /* @__PURE__ */ h("span", {
					className: "opacity-50",
					children: Y(/* @__PURE__ */ h("span", {
						className: "font-mono tabular-nums",
						children: e
					}), Se === e, () => Ce(Se === e ? null : e), !1, `gd${t}`)
				}, `gd${t}`))] }), null);
			}
			case "chooseConstraint": {
				let t = new Set(Object.values(e.mods.constraints?.perPlayer ?? {}).filter((e) => e != null));
				return ut(i, oe.map((e) => Y(e, !1, () => a({
					type: "respond",
					kind: "chooseConstraint",
					constraint: e
				}), t.has(e), `cc${e}`)), null);
			}
			case "placeCard": return ut(i, (t?.handCards ?? []).map((e, t) => Y(/* @__PURE__ */ h("span", {
				className: "font-mono tabular-nums",
				children: e
			}), !1, () => a({
				type: "respond",
				kind: "placeCard",
				card: e
			}), !1, `pc${t}`)), null);
			case "moveSequence": return ut(i, /* @__PURE__ */ g(m, { children: [Y(s("games.bombbusters.endLeft"), !1, () => a({
				type: "respond",
				kind: "moveSequence",
				end: "left"
			})), Y(s("games.bombbusters.endRight"), !1, () => a({
				type: "respond",
				kind: "moveSequence",
				end: "right"
			}))] }), null);
			default: return /* @__PURE__ */ h("div", {
				className: "bb-idle-actions",
				children: /* @__PURE__ */ h("span", {
					className: "bb-idle-actions__hint",
					children: n.kind === "failToken" && n.cut ? s("games.bombbusters.pendPickCut") : n.kind === "failToken" ? s("games.bombbusters.pendFailTokenYou") : s("games.bombbusters.pendTalkiesPickYou")
				})
			});
		}
	}
	function ht() {
		let e = C.setupTokens === "absent" || C.setupTokens === "fake" || T;
		return /* @__PURE__ */ g("div", {
			className: "bb-idle-actions",
			children: [/* @__PURE__ */ g("span", {
				className: "bb-idle-actions__hint",
				children: [s("games.bombbusters.setupTokenYou"), e ? ` · ${ve.length}/2` : ""]
			}), ve.length > 0 && Y(s("games.bombbusters.cancel"), !1, () => {
				ye([]), _e(null);
			})]
		});
	}
	function gt() {
		let n = [], i = D?.character;
		if (e.phase === "play" && !le) {
			e.turn === null && w("realtime") && !(e.lastActor === r && e.players.length > 2) && !D?.done && n.push(/* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => a({ type: "claim" }),
				className: "btn-base min-h-12 flex-none px-5",
				style: { background: x.accent },
				children: s("games.bombbusters.actClaim")
			}, "claim")), e.mods.squeak && e.forcedValue != null && e.forcedBy == null && !D?.done && n.push(/* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => a({ type: "claim" }),
				className: "btn-base min-h-12 flex-none px-5",
				style: { background: x.accent },
				children: s("games.bombbusters.actSqueak")
			}, "sq")), M && (he && n.push(/* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => a({ type: "reveal" }),
				className: "btn-base min-h-12 flex-none bg-rose-500 px-4 text-white",
				children: s("games.bombbusters.actReveal")
			}, "rv")), (w("massCutRed3") || w("massCut4") || w("massCutYellow3") || e.mods.challenges?.some((e) => e.id === 1 && !e.done)) && n.push(/* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => P({
					k: "mass",
					picks: []
				}),
				className: "bb-act flex-none",
				children: s("games.bombbusters.actMass")
			}, "mass")), w("iberian") && n.push(/* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => P({
					k: "iberian",
					pick: null
				}),
				className: "bb-act flex-none",
				children: s("games.bombbusters.actIberian")
			}, "ib")), w("weakLink") && n.push(/* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => P({
					k: "accuse",
					target: null,
					constraint: null
				}),
				className: "bb-act flex-none",
				children: s("games.bombbusters.actAccuse")
			}, "ac")), t?.canPass && n.push(/* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => a({ type: "pass" }),
				className: "bb-act flex-none",
				children: s("games.bombbusters.actPass")
			}, "pass")), w("constraintsDeck") && e.turn === r && n.push(/* @__PURE__ */ g("button", {
				type: "button",
				onClick: () => a({ type: "nextConstraint" }),
				className: "bb-act flex-none",
				children: [s("games.bombbusters.constraintNow"), "→"]
			}, "nc")), w("constraintsPersonal") && e.turn === r && n.push(/* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => a({
					type: "rotateConstraints",
					dir: 1
				}),
				className: "bb-act flex-none px-2.5",
				"aria-label": "rotate",
				children: "⟳"
			}, "rl"), /* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => a({
					type: "rotateConstraints",
					dir: -1
				}),
				className: "bb-act flex-none px-2.5",
				"aria-label": "rotate",
				children: "⟲"
			}, "rr")));
			let o = !!i && !i.used && D?.revealed;
			(e.equipments.some((e) => e.unlocked && !e.used) || o) && n.push(/* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => F(!0),
				className: "bb-act flex-none",
				children: s("games.bombbusters.actEquip")
			}, "eq")), w("constraintsPersonal") && e.mods.constraints?.perPlayer[r] && n.push(/* @__PURE__ */ g("button", {
				type: "button",
				onClick: () => a({
					type: "respond",
					kind: "swapConstraint"
				}),
				className: "bb-act flex-none",
				children: ["⇄", s("games.bombbusters.constraintNow")]
			}, "sw"));
		}
		return n.length === 0 && !M ? /* @__PURE__ */ h("span", {}) : /* @__PURE__ */ g("div", {
			className: `bb-idle-actions ${M ? "" : "bb-idle-actions--tools-only"}`,
			children: [M && /* @__PURE__ */ h("span", {
				className: "bb-idle-actions__hint",
				children: s(fe ? "games.bombbusters.pickActor" : "games.bombbusters.cutStartHint")
			}), n.length > 0 && /* @__PURE__ */ h("div", {
				className: "bb-idle-actions__tools scrollbar-none",
				children: n
			})]
		});
	}
	let _t = D?.racks.flat() ?? [], vt = w("tokenBeside"), yt = (e) => {
		if (!vt) return;
		let t = e.flatMap((e) => e.tokens);
		if (t.length !== 0) return /* @__PURE__ */ h("span", {
			className: "bb-rack-tokens",
			children: t.map((e, t) => /* @__PURE__ */ h(Cn, {
				label: v(e.token, e.fake),
				fake: e.fake,
				compact: !0
			}, t))
		});
	}, bt = /* @__PURE__ */ h("div", {
		ref: te,
		className: "bb-my-rack flex-none",
		style: { "--bb-wire-count": _t.length },
		children: /* @__PURE__ */ h(Dn, {
			label: s("games.bombbusters.myRack"),
			overview: !0,
			tokensPile: yt(_t),
			children: _t.map((e) => {
				let t = O.get(e.id) ?? null, n = We(r, e), i = N.k === "dual" && N.mine === e.id || N.k === "mass" && N.picks.some((t) => t.wire === e.id) || N.k === "equip" && N.myWires.includes(e.id) || ge === e.id || ve.some((t) => t.wire === e.id);
				return /* @__PURE__ */ h("li", { children: /* @__PURE__ */ h(En, {
					wire: e,
					face: t,
					small: !0,
					hideTokens: vt,
					selected: i,
					selectable: n,
					beat: ue.has(e.id) ? "cut" : de.has(e.id) ? "target" : void 0,
					onClick: n ? () => Fe(r, e) : void 0
				}) }, e.id);
			})
		})
	}), xt = it(), St = rt(), Ct = `${s("games.bombbusters.myRack")} · ${S(r)}`, wt = (() => {
		if (N.k === "equip" && (N.id === "personal" ? D?.character?.id : N.id) === "batteries" && D?.character?.used) return {
			selected: N.rids.includes(r),
			onPick: () => P({
				...N,
				rids: N.rids.includes(r) ? N.rids.filter((e) => e !== r) : [...N.rids, r].slice(-2)
			})
		};
		if (fe && !D?.done && (!Ue || Ue.has(r))) return {
			selected: !1,
			onPick: () => a({
				type: "claim",
				for: r
			})
		};
	})();
	return /* @__PURE__ */ g("div", {
		className: `bb-game h-full ${w("realtime") ? "bb-game--realtime" : ""}`,
		children: [
			/* @__PURE__ */ h(f, {
				adaptive: !0,
				className: "bb-screen",
				banner: /* @__PURE__ */ g("div", {
					className: `bb-console ${E ? "bb-console--info" : ""}`,
					children: [
						/* @__PURE__ */ g("div", {
							className: `bb-console__header ${e.mods.deadline === void 0 ? "" : "bb-console__header--deadline"}`,
							children: [
								/* @__PURE__ */ h("div", { children: /* @__PURE__ */ h(p, {
									tone: Ze,
									text: Qe,
									sub: $e,
									chip: tt,
									accent: x.accent
								}) }),
								/* @__PURE__ */ h("button", {
									type: "button",
									className: "bb-history-open bb-history-open--header",
									onClick: () => V(!0),
									"aria-label": s("games.bombbusters.historyOpen"),
									children: /* @__PURE__ */ h(d, { size: 18 })
								}),
								e.mods.deadline !== void 0 && /* @__PURE__ */ h("div", {
									className: "bb-console__deadline",
									children: /* @__PURE__ */ h(yn, { deadline: e.mods.deadline })
								})
							]
						}),
						/* @__PURE__ */ g("div", {
							className: "bb-console__mission",
							children: [
								e.dial && /* @__PURE__ */ h("span", {
									ref: y,
									className: "flex-none",
									children: /* @__PURE__ */ h(an, {
										step: e.dial.step,
										max: e.dial.max,
										beatDelta: A?.hpDelta
									})
								}),
								A ? /* @__PURE__ */ g("div", {
									className: `bb-result-beat bb-result-beat--${A.outcome}`,
									role: "status",
									"aria-live": "polite",
									children: [/* @__PURE__ */ g("span", {
										className: "bb-result-beat__main",
										children: [A.target ? s("games.bombbusters.beatActorTarget", {
											actor: S(A.actor),
											target: S(A.target)
										}) : s("games.bombbusters.beatActor", { actor: S(A.actor) }), A.values.length > 0 && /* @__PURE__ */ g("b", { children: [" · ", s("games.bombbusters.beatCalled", { value: A.values.map((e) => Z(s, e)).join(" / ") })] })]
									}), /* @__PURE__ */ g("span", {
										className: "bb-result-beat__detail",
										children: [
											A.outcome === "success" ? s("games.bombbusters.beatCutCount", { n: A.cut.length }) : s(A.outcome === "boom" ? "games.bombbusters.beatBoom" : "games.bombbusters.beatMiss"),
											A.hpDelta > 0 && /* @__PURE__ */ g("b", { children: [" · HP −", A.hpDelta] }),
											A.hpDelta < 0 && /* @__PURE__ */ g("b", { children: [" · HP +", -A.hpDelta] }),
											A.validated.length > 0 && /* @__PURE__ */ g("b", { children: [" · ✓ ", A.validated.map((e) => Z(s, e)).join(" / ")] }),
											A.equipments.length > 0 && /* @__PURE__ */ g("b", { children: [" · ", s("games.bombbusters.beatEquipment")] })
										]
									})]
								}) : e.radarBeat ? /* @__PURE__ */ g("div", {
									className: "bb-result-beat bb-result-beat--radar",
									role: "status",
									"aria-live": "polite",
									children: [/* @__PURE__ */ g("span", {
										className: "bb-result-beat__main",
										children: ["📡 ", s("games.bombbusters.radarBeatTitle", { value: e.radarBeat.value })]
									}), /* @__PURE__ */ h("span", {
										className: "bb-result-beat__detail",
										children: e.radarBeat.yes.length > 0 ? mn(e, e.radarBeat.yes, S).join("、") : s("games.bombbusters.logRadarNoOne")
									})]
								}) : /* @__PURE__ */ h(gn, {
									pub: e,
									onOpen: () => xe(!0)
								}),
								/* @__PURE__ */ h("button", {
									type: "button",
									className: "bb-history-open bb-history-open--mission",
									onClick: () => V(!0),
									"aria-label": s("games.bombbusters.historyOpen"),
									children: /* @__PURE__ */ h(d, { size: 18 })
								})
							]
						}),
						/* @__PURE__ */ h("div", {
							ref: ee,
							className: "bb-console__equipment",
							children: /* @__PURE__ */ h(fn, {
								pub: e,
								onUse: e.phase === "resolving" ? void 0 : (t) => t === "triple" || t === "super" || t === "xyray" ? P(Me(e.forcedValue, null, t)) : t === "radar" ? U({
									kind: "radar",
									id: t
								}) : P({
									k: "equip",
									id: t,
									myWires: [],
									theirWire: null,
									target: null,
									value: null,
									rids: []
								}),
								onInspect: e.phase === "resolving" ? void 0 : () => F(!0)
							})
						}),
						/* @__PURE__ */ h("div", {
							ref: b,
							className: "bb-console__track",
							children: /* @__PURE__ */ h(on, { pub: e })
						}),
						E && /* @__PURE__ */ h(vn, {
							pub: e,
							myRid: r,
							nameOf: S,
							secretConstraint: null,
							scope: "public",
							className: "bb-console__info",
							onOpen: () => xe(!0)
						})
					]
				}),
				actionsHeight: `bb-actions-height ${ne ? "bb-actions-height--info" : ""} ${ie ? "bb-actions-height--personal" : ""}`,
				actions: /* @__PURE__ */ g("div", {
					className: `bb-my-dock flex flex-col ${ne ? "bb-my-dock--info" : ""} ${ie ? "bb-my-dock--personal" : ""}`,
					children: [
						/* @__PURE__ */ g("div", {
							className: `bb-my-dock__header ${wt ? "bb-my-dock__header--pick" : ""} ${wt?.selected ? "bb-my-dock__header--picked" : ""}`,
							onClick: wt?.onPick,
							children: [
								/* @__PURE__ */ h("span", {
									className: "bb-my-dock__name",
									children: Ct
								}),
								D?.character && /* @__PURE__ */ h("span", {
									className: `bb-seat__badge ${D.character.used ? "opacity-40" : ""}`,
									children: s(kn[D.character.id])
								}),
								t?.secretConstraint && /* @__PURE__ */ h("span", {
									className: "bb-seat__badge",
									children: s("games.bombbusters.youAreWeak")
								}),
								Ge.get(r) && /* @__PURE__ */ h("span", {
									className: "bb-seat__last",
									title: Ke(Ge.get(r)),
									children: Ke(Ge.get(r))
								}),
								wt && !wt.selected && /* @__PURE__ */ h(wn, {})
							]
						}),
						ne && /* @__PURE__ */ h(vn, {
							pub: e,
							myRid: r,
							nameOf: S,
							secretConstraint: t?.secretConstraint ?? null,
							myCards: t?.handCards ?? [],
							className: "bb-my-dock__all-info",
							onOpen: () => xe(!0)
						}),
						ie && /* @__PURE__ */ h(vn, {
							pub: e,
							myRid: r,
							nameOf: S,
							secretConstraint: t?.secretConstraint ?? null,
							myCards: t?.handCards ?? [],
							scope: "personal",
							className: "bb-my-dock__personal-info",
							onOpen: () => xe(!0)
						}),
						/* @__PURE__ */ g("div", {
							className: "bb-my-dock__body",
							children: [
								bt,
								/* @__PURE__ */ h("div", {
									className: "bb-my-dock__actions",
									children: St ? null : xt
								}),
								St && /* @__PURE__ */ h("div", {
									className: "bb-my-dock__overlay",
									children: St
								})
							]
						})
					]
				}),
				children: /* @__PURE__ */ h("div", {
					className: `bb-table ${e.players.length <= 3 ? "bb-table--few" : ""} ${e.players.length === 2 ? "bb-table--single" : ""}`,
					children: nt.map((t) => {
						let r = n.find((e) => e.rid === t.rid), i = j === t.rid && e.phase === "play", o = N.k === "equip" ? N.id === "personal" ? D?.character?.id : N.id : null, c;
						return N.k === "equip" && (o === "talkies" || o === "coffee") && !t.done ? c = {
							selected: N.target === t.rid,
							onPick: () => P({
								...N,
								target: t.rid
							})
						} : N.k === "equip" && o === "batteries" && t.character?.used ? c = {
							selected: N.rids.includes(t.rid),
							onPick: () => P({
								...N,
								rids: N.rids.includes(t.rid) ? N.rids.filter((e) => e !== t.rid) : [...N.rids, t.rid].slice(-2)
							})
						} : N.k === "accuse" ? c = {
							selected: N.target === t.rid,
							onPick: () => P({
								...N,
								target: t.rid
							})
						} : fe && !t.done && (!Ue || Ue.has(t.rid)) ? c = {
							selected: !1,
							onPick: () => a({
								type: "claim",
								for: t.rid
							})
						} : k?.kind === "giveCard" && Se != null ? c = {
							selected: !1,
							onPick: () => {
								a({
									type: "respond",
									kind: "giveCard",
									card: Se,
									target: t.rid
								}), Ce(null);
							}
						} : (N.k === "dual" || N.k === "solo") && w("oxygenPerPlayer") && (c = {
							selected: N.payTo === t.rid,
							onPick: () => P({
								...N,
								payTo: N.payTo === t.rid ? null : t.rid
							})
						}), /* @__PURE__ */ g(Pn, {
							rid: t.rid,
							turn: i,
							wireCount: t.racks.flat().length,
							pick: c,
							children: [/* @__PURE__ */ g("header", {
								className: "bb-seat__header",
								children: [
									/* @__PURE__ */ h("span", {
										className: "bb-seat__name",
										children: S(t.rid)
									}),
									r && !r.online && /* @__PURE__ */ h(u, {
										size: 12,
										"aria-label": s("lobby.offline")
									}),
									t.rid === e.captain && /* @__PURE__ */ h("span", {
										className: "bb-seat__badge",
										children: s("games.bombbusters.captainBadge")
									}),
									t.character && /* @__PURE__ */ h("span", {
										className: `bb-seat__badge ${t.character.used ? "opacity-40" : ""}`,
										children: s(kn[t.character.id])
									}),
									t.done && /* @__PURE__ */ h("span", {
										className: "bb-seat__badge",
										children: s("games.bombbusters.playerDone")
									}),
									e.mods.constraints?.perPlayer?.[t.rid] && /* @__PURE__ */ h("span", {
										className: "bb-seat__badge",
										children: s("games.bombbusters.constraintBadge", { id: e.mods.constraints.perPlayer[t.rid] })
									}),
									e.mods.handCards?.[t.rid] && /* @__PURE__ */ h("span", {
										className: "flex items-center gap-0.5",
										children: e.mods.handCards[t.rid].map((e, t) => /* @__PURE__ */ h(hn, {
											v: e,
											mini: !0
										}, t))
									}),
									e.mods.handCardsDown?.[t.rid]?.length ? /* @__PURE__ */ h("span", {
										className: "flex items-center gap-0.5 opacity-50",
										children: e.mods.handCardsDown[t.rid].map((e, t) => /* @__PURE__ */ h(hn, {
											v: e,
											mini: !0
										}, t))
									}) : null,
									Ge.get(t.rid) && /* @__PURE__ */ h("span", {
										className: "bb-seat__last",
										title: Ke(Ge.get(t.rid)),
										children: Ke(Ge.get(t.rid))
									}),
									/* @__PURE__ */ h("span", {
										className: "bb-seat__count",
										children: t.racks.flat().filter((e) => !e.cut).length
									})
								]
							}), /* @__PURE__ */ h(Dn, {
								label: s("games.bombbusters.rackOf", { name: S(t.rid) }),
								overview: !0,
								tokensPile: yt(t.racks.flat()),
								children: t.racks.flat().map((e) => {
									let n = ce.get(e.id), r = n ? {
										color: n.color,
										sort: n.sort
									} : null, i = N.k === "equip" ? N.id === "personal" ? D?.character?.id : N.id : null, a = N.k === "dual" && N.wires.includes(e.id) || N.k === "mass" && N.picks.some((t) => t.wire === e.id) || N.k === "iberian" && N.pick?.wire === e.id || N.k === "equip" && (N.theirWire === e.id || i === "talkies" && N.target === t.rid && !e.cut), o = We(t.rid, e);
									return /* @__PURE__ */ h("li", { children: /* @__PURE__ */ h(En, {
										wire: e,
										face: r,
										small: !0,
										hideTokens: vt,
										selected: a,
										selectable: o,
										beat: ue.has(e.id) ? "cut" : de.has(e.id) ? "target" : void 0,
										onClick: o ? () => Fe(t.rid, e) : void 0
									}) }, e.id);
								})
							})]
						}, t.rid);
					})
				})
			}),
			B && /* @__PURE__ */ h("div", {
				className: "bb-picker-backdrop",
				onClick: () => V(!1),
				children: /* @__PURE__ */ g("section", {
					className: "bb-picker bb-history-sheet",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": s("games.bombbusters.historyTitle"),
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ g("header", {
						className: "bb-picker__header",
						children: [/* @__PURE__ */ g("span", { children: [
							s("games.bombbusters.historyTitle"),
							" · ",
							Je.length
						] }), /* @__PURE__ */ h("button", {
							type: "button",
							className: "bb-picker__close",
							onClick: () => V(!1),
							children: s("games.bombbusters.cancel")
						})]
					}), /* @__PURE__ */ g("div", {
						className: "bb-history-list",
						children: [Je.length === 0 && /* @__PURE__ */ h("p", {
							className: "bb-history-empty",
							children: s("games.bombbusters.historyEmpty")
						}), Je.map((e) => e.type === "log" ? /* @__PURE__ */ h("p", {
							className: "bb-history-log",
							children: J(e.line)
						}, `l${e.line.seq}`) : Xe(e.entry))]
					})]
				})
			}),
			z && /* @__PURE__ */ h("div", {
				className: "bb-picker-backdrop",
				onClick: () => xe(!1),
				children: /* @__PURE__ */ g("section", {
					className: "bb-picker bb-mission-sheet overflow-y-auto",
					onClick: (e) => e.stopPropagation(),
					role: "dialog",
					"aria-modal": "true",
					"aria-label": s("games.bombbusters.missionInfo"),
					children: [
						/* @__PURE__ */ g("header", {
							className: "bb-picker__header bb-mission-sheet__header",
							children: [
								/* @__PURE__ */ g("span", {
									className: "bb-mission-sheet__no",
									children: ["#", e.mission]
								}),
								/* @__PURE__ */ h("h2", {
									className: "bb-mission-sheet__name",
									children: s(`games.bombbusters.m${e.mission}name`)
								}),
								/* @__PURE__ */ h("button", {
									type: "button",
									className: "bb-picker__close",
									onClick: () => xe(!1),
									children: s("games.bombbusters.cancel")
								})
							]
						}),
						/* @__PURE__ */ h(Rn, { text: s(`games.bombbusters.m${e.mission}brief`) }),
						(() => {
							let n = _n(s, e, r, S, t?.secretConstraint ?? null, t?.handCards ?? [], !0);
							return n.length > 0 ? /* @__PURE__ */ h("div", {
								className: "bb-mission-chips",
								children: n
							}) : null;
						})()
					]
				})
			}),
			H && (() => {
				let e = H.kind === "xyray" && N.k === "dual" ? N.guess : null, t = H.kind === "xyray" && e == null ? 2 : 1, n = H.kind === "xyray" ? s(e == null ? "games.bombbusters.valuePickTwo" : "games.bombbusters.valuePickSecond") : H.kind === "blind" ? s(N.k === "dual" && N.mine != null && !O.has(N.mine) ? "games.bombbusters.valuePickBlind" : "games.bombbusters.valuePickOne") : H.kind === "setup" ? s(C.setupTokens === "absent" ? "games.bombbusters.setupAbsent" : "games.bombbusters.setupFake") : s("games.bombbusters.valuePickOne");
				return /* @__PURE__ */ h(Vn, {
					title: n,
					count: t,
					legal: (t) => {
						if (H.kind === "radar") return t !== "yellow";
						if (H.kind === "blind") return W(t, N.k === "solo");
						if (H.kind === "setup") {
							if (C.setupTokens === "absent") return !me.has(t);
							let e = ge == null ? null : O.get(ge);
							return t !== "yellow" && (e?.color !== "blue" || t !== Math.round(e.sort));
						}
						return W(t, !1) && t !== e && (t === "yellow" || me.has(t));
					},
					onDone: (t) => {
						H.kind === "xyray" && N.k === "dual" ? P(e == null ? {
							...N,
							guess: t[0],
							guess2: t[1] ?? null
						} : {
							...N,
							guess2: t[0]
						}) : H.kind === "blind" ? N.k === "dual" ? P({
							...N,
							guess: t[0]
						}) : N.k === "solo" && P({
							...N,
							value: t[0]
						}) : H.kind === "setup" ? K(t[0]) : H.kind === "radar" && typeof t[0] == "number" && (a({
							type: "equip",
							id: H.id,
							params: { value: t[0] }
						}), P(In)), U(null);
					},
					onCancel: () => {
						H.kind === "setup" && _e(null), U(null);
					}
				});
			})(),
			be && /* @__PURE__ */ h("div", {
				className: "bb-picker-backdrop bb-equip-backdrop",
				onClick: () => F(!1),
				children: /* @__PURE__ */ g("section", {
					className: "bb-equip-sheet",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": s("games.bombbusters.equipSheetTitle"),
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ g("header", {
						className: "bb-equip-sheet__header",
						children: [
							/* @__PURE__ */ g("span", {
								className: "bb-equip-sheet__heading",
								children: [/* @__PURE__ */ h("strong", { children: s("games.bombbusters.equipSheetTitle") }), /* @__PURE__ */ h("small", { children: s("games.bombbusters.equipSheetSubtitle") })]
							}),
							/* @__PURE__ */ h("span", {
								className: "bb-equip-sheet__count",
								children: s("games.bombbusters.equipSheetAvailable", { n: se })
							}),
							/* @__PURE__ */ h("button", {
								type: "button",
								className: "bb-equip-sheet__close",
								onClick: () => F(!1),
								"aria-label": s("games.bombbusters.cancel"),
								children: "×"
							})
						]
					}), /* @__PURE__ */ g("div", {
						className: "bb-equip-sheet__body",
						children: [D?.character && /* @__PURE__ */ g("section", {
							className: "bb-equip-sheet__section",
							children: [/* @__PURE__ */ g("h2", {
								className: "bb-equip-sheet__section-title",
								children: [s("games.bombbusters.equipSectionPersonal"), /* @__PURE__ */ h("small", { children: s("games.bombbusters.equipSheetOnce") })]
							}), /* @__PURE__ */ h("ul", {
								className: "bb-equip-sheet__list",
								children: /* @__PURE__ */ h(Mn, {
									name: s(kn[D.character.id]),
									description: s(An[D.character.id]),
									iconId: D.character.id,
									personal: !0,
									used: D.character.used,
									reason: D.revealed ? void 0 : [s("games.bombbusters.equipNeedReveal")],
									useLabel: s("games.bombbusters.equipUse"),
									stateLabel: s(D.character.used ? "games.bombbusters.equipSheetUsed" : "games.bombbusters.equipLocked"),
									onUse: !D.character.used && D.revealed ? () => {
										F(!1);
										let t = D.character.id;
										t === "dd2000" || t === "triple" || t === "xyray" ? P(Me(e.forcedValue, null, t)) : t === "radar" ? U({
											kind: "radar",
											id: "personal"
										}) : P({
											k: "equip",
											id: "personal",
											myWires: [],
											theirWire: null,
											target: null,
											value: null,
											rids: []
										});
									} : void 0
								})
							})]
						}), e.equipments.length > 0 && /* @__PURE__ */ g("section", {
							className: "bb-equip-sheet__section bb-equip-sheet__section--public",
							children: [/* @__PURE__ */ h("h2", {
								className: "bb-equip-sheet__section-title",
								children: s("games.bombbusters.equipSectionPublic")
							}), /* @__PURE__ */ h("ul", {
								className: "bb-equip-sheet__list",
								children: e.equipments.map((t, n) => {
									let r = ke[t.id], i = (e) => s("games.bombbusters.equipNeedCut", { v: e === "yellow" ? s("games.bombbusters.guessYellow") : e });
									return /* @__PURE__ */ h(Mn, {
										name: s(sn[t.id]),
										description: s(jn[t.id]),
										iconId: t.id,
										used: t.used,
										reason: !t.unlocked && !t.used ? [i(r), ...t.cover == null ? [] : [i(t.cover)]] : void 0,
										useLabel: s("games.bombbusters.equipUse"),
										stateLabel: s(t.used ? "games.bombbusters.equipSheetUsed" : "games.bombbusters.equipLocked"),
										onUse: t.unlocked && !t.used ? () => {
											F(!1), t.id === "triple" || t.id === "super" || t.id === "xyray" ? P(Me(e.forcedValue, null, t.id)) : t.id === "radar" ? U({
												kind: "radar",
												id: "radar"
											}) : P({
												k: "equip",
												id: t.id,
												myWires: [],
												theirWire: null,
												target: null,
												value: null,
												rids: []
											});
										} : void 0
									}, `${t.id}${n}`);
								})
							})]
						})]
					})]
				})
			})
		]
	});
}
function Bn(e) {
	switch (e) {
		case "red": return "games.bombbusters.overBoomRed";
		case "dial": return "games.bombbusters.overBoomDial";
		case "nano": return "games.bombbusters.overBoomNano";
		case "mass": return "games.bombbusters.overBoomMass";
		case "accuse": return "games.bombbusters.overBoomAccuse";
		case "timeout": return "games.bombbusters.overBoomTimeout";
		default: return "games.bombbusters.overBoomConstrain";
	}
}
function Vn({ title: e, count: t, legal: n, initial: r, onDone: a, onCancel: o }) {
	let s = l(), [c, u] = i(r ?? []);
	return /* @__PURE__ */ h("div", {
		className: "bb-picker-backdrop",
		onClick: o,
		children: /* @__PURE__ */ g("section", {
			className: "bb-picker bb-value-picker",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": e,
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ g("header", {
					className: "bb-picker__header",
					children: [/* @__PURE__ */ h("span", { children: e }), /* @__PURE__ */ h("button", {
						type: "button",
						className: "bb-picker__close",
						onClick: o,
						children: s("games.bombbusters.cancel")
					})]
				}),
				/* @__PURE__ */ h("div", {
					className: "grid grid-cols-4 gap-1.5 p-1",
					children: [
						1,
						2,
						3,
						4,
						5,
						6,
						7,
						8,
						9,
						10,
						11,
						12,
						"yellow"
					].map((e) => {
						let r = c.includes(e), i = (n ? !n(e) : !1) || !r && c.length >= t;
						return /* @__PURE__ */ h("button", {
							type: "button",
							disabled: i,
							"aria-pressed": r,
							onClick: () => u(r ? c.filter((t) => t !== e) : [...c, e]),
							className: `bb-value-picker__key grid min-h-12 place-items-center rounded-lg border-2 border-ink font-mono text-base font-extrabold tabular-nums ${r ? "bg-info-soft text-info-ink -translate-y-0.5 shadow-[1px_2px_0_var(--color-ink)]" : e === "yellow" ? "bg-amber-400" : "bg-surface"} ${i ? "opacity-30" : ""}`,
							children: Z(s, e)
						}, String(e));
					})
				}),
				/* @__PURE__ */ h("div", {
					className: "flex items-center justify-end gap-2 px-1 pb-1",
					children: /* @__PURE__ */ h("button", {
						type: "button",
						disabled: c.length !== t,
						onClick: () => a(c),
						className: "btn-base min-h-11 flex-none px-4",
						style: { background: x.accent },
						children: s("games.bombbusters.confirm")
					})
				})
			]
		})
	});
}
//#endregion
//#region src/games/bombbusters/infer.ts
var Hn = (e, t) => e.features.includes(t), Un = (e) => Math.round(e * 10);
function Wn(e, t, n, r) {
	let i = e.players.length === 2, a = e.mods.cursed, o = [];
	for (let e = 1; e <= n.blueMax; e += 1) o.push({
		color: "blue",
		v: e,
		sort: e,
		w: 4
	});
	let s = (t, r) => {
		let a = i && (t === "red" ? n.red2p : n.yellow2p) || (t === "red" ? n.red : n.yellow), o = e.mods.markers[t];
		if (o.length === 0 && a.n > 0) {
			let e = t === "red" ? n.redMax ?? 11.5 : n.yellowMax ?? 11.1, i = [];
			for (let t = r === .5 ? 1.5 : 1.1; t <= e; t += 1) i.push(t);
			return i.map((e) => ({
				color: t,
				v: Math.floor(e),
				sort: e,
				w: a.n / i.length
			}));
		}
		return o.map((e) => ({
			color: t,
			v: e.v,
			sort: e.v + r,
			w: e.unsure ? a.n / Math.max(1, o.length) : 1
		}));
	};
	o.push(...s("red", .5), ...s("yellow", .1));
	let c = new Map(o.map((e) => [e, e.w])), l = [...o].sort((e, t) => e.sort - t.sort), u = l.reduce((e, t) => e + (c.get(t) ?? 0), 0), d = (() => {
		let e = /* @__PURE__ */ new Map(), t = 0;
		for (let n of l) {
			let r = Un(n.sort), i = e.get(r) ?? {
				before: t,
				count: 0
			}, a = c.get(n) ?? 0;
			i.count += a, e.set(r, i), t += a;
		}
		return (t) => {
			let n = e.get(Un(t));
			return n && u > 0 ? (n.before + n.count / 2) / u : .5;
		};
	})(), f = (e, t) => o.find((n) => n.color === e && Un(n.sort) === Un(t)), p = (e, t, n = 1) => {
		let r = f(e, t);
		r && (r.w = Math.max(0, r.w - n));
	}, m = /* @__PURE__ */ new Map();
	for (let t of e.players) for (let e of t.racks) for (let n of e) m.set(n.id, {
		w: n,
		owner: t.rid
	}), n.cut && n.revealed && p(n.revealed.color, n.revealed.sort);
	for (let e of t?.mine ?? []) {
		let t = m.get(e.wire);
		t && !t.w.cut && p(e.color, e.sort);
	}
	let h = /* @__PURE__ */ new Map();
	for (let e of t?.mine ?? []) {
		if (e.color !== "blue") continue;
		let t = Math.round(e.sort);
		h.set(t, (h.get(t) ?? 0) + 1);
	}
	let g = new Map((t?.upsideVisible ?? []).map((e) => [e.wire, e])), _ = /* @__PURE__ */ new Map(), v = /* @__PURE__ */ new Map();
	for (let t of e.players) if (t.rid !== r) for (let e of t.racks) for (let t of e) {
		if (t.cut) continue;
		let e = g.get(t.id);
		if (e) {
			_.set(t.id, {
				color: e.color,
				v: Math.round(e.sort),
				sort: e.sort
			});
			continue;
		}
		for (let e of t.tokens) e.fake || (e.token.kind === "value" ? _.set(t.id, {
			color: "blue",
			v: e.token.value,
			sort: e.token.value
		}) : e.token.kind === "yellow" && v.set(t.id, "yellow"));
	}
	let y = (e) => e.cut && e.revealed ? {
		color: e.revealed.color,
		v: Math.round(e.revealed.sort),
		sort: e.revealed.sort
	} : _.get(e.id) ?? null;
	for (let t of e.players) if (t.rid !== r) for (let e of t.racks) for (let t = 0; t + 1 < e.length; t += 1) {
		let n = e[t], r = e[t + 1];
		if (!n.tokens.some((e) => e.token.kind === "eq") || !r.tokens.some((e) => e.token.kind === "eq")) continue;
		let i = y(n), a = y(r);
		i && !r.cut && !_.has(r.id) && _.set(r.id, i), a && !n.cut && !_.has(n.id) && _.set(n.id, a);
	}
	for (let e of _.values()) p(e.color, e.sort);
	let b = /* @__PURE__ */ new Map();
	for (let e of ["yellow", "red"]) {
		let t = [...v.values()].filter((t) => t === e).length;
		if (!t) continue;
		let n = o.filter((t) => t.color === e).reduce((e, t) => e + t.w, 0);
		b.set(e, n > 0 ? Math.max(0, n - t) / n : 1);
	}
	let ee = /* @__PURE__ */ new Map();
	{
		let t = Hn(n, "nanoCollect");
		for (let n of e.log) {
			if (n.k === "equip" && (n.id === "talkies" || n.id === "grapple") && (t = !0), n.k !== "radar") continue;
			if (t) {
				for (let e of ee.values()) e.delete(n.value);
				continue;
			}
			let r = new Set(n.yes.map((e) => `${e.rid}:${e.rack}`));
			for (let t of e.players) t.racks.forEach((e, i) => {
				let a = `${t.rid}:${i + 1}`;
				if (r.has(a)) return;
				let o = ee.get(a) ?? /* @__PURE__ */ new Set();
				o.add(n.value), ee.set(a, o);
			});
		}
	}
	let te = /* @__PURE__ */ new Map();
	for (let t of e.cutHistory) {
		let e = (e, t) => {
			let n = te.get(e) ?? /* @__PURE__ */ new Set();
			n.add(t), te.set(e, n);
		};
		if (t.kind === "dual") {
			if (Hn(n, "sevensLast") && t.values.includes(7)) continue;
			let r = new Set(t.cut);
			for (let n of t.wires) if (!r.has(n)) for (let r of t.values) e(n, r);
		} else if (t.kind === "iberian" && t.outcome !== "success") for (let n of t.wires) e(n, "yellow");
	}
	let x = [], S = /* @__PURE__ */ new Map(), C = (e, t, n, r = !1, i = -1, s = 0) => {
		n.length === 0 && (n = o.filter((e) => e.w > 0));
		let c = (e) => {
			let t = r ? e.w * (b.get(e.color) ?? 1) : e.w;
			if (i >= 0 && s > 0) {
				let n = d(e.sort) - i;
				t *= Math.exp(n * n * -.5 / s);
			}
			return t;
		}, l = n.reduce((e, t) => e + c(t), 0) || 1, u = /* @__PURE__ */ new Map(), f = 0;
		for (let e of n) {
			let t = c(e) / l;
			if (e.color === "red" || e.color === "blue" && e.v === a) {
				f += t;
				continue;
			}
			let n = e.color === "yellow" ? "yellow" : e.v;
			u.set(n, (u.get(n) ?? 0) + t);
		}
		let p = u.size === 1 && f === 0 ? [...u.keys()][0] : null, m = {
			owner: e,
			wire: t,
			p: u,
			boom: f,
			certain: p
		};
		x.push(m), S.set(t.id, m);
	};
	for (let t of e.players) t.rid !== r && t.racks.forEach((e, r) => {
		let i = (e) => e.cut && e.revealed ? e.revealed.sort : _.get(e.id)?.sort ?? null, a = /* @__PURE__ */ new Map(), s = 0;
		for (let t of e) Hn(n, "xwiresGate") && t.x || a.set(t.id, s++);
		let c = s;
		for (let s = 0; s < e.length; s += 1) {
			let l = e[s];
			if (l.cut) continue;
			let u = _.get(l.id);
			if (u) {
				let e = f(u.color, u.sort);
				C(t.rid, l, [{
					color: u.color,
					v: u.v,
					sort: u.sort,
					w: Math.max(1e-4, e?.w ?? 0)
				}]);
				continue;
			}
			let d = v.get(l.id);
			if (d) {
				C(t.rid, l, o.filter((e) => e.color === d && e.w > 0));
				continue;
			}
			let p = Hn(n, "xwiresGate") && !!l.x, m = 0, g = 99;
			if (!p) {
				for (let t = s - 1; t >= 0; --t) {
					let n = i(e[t]);
					if (n != null) {
						m = n;
						break;
					}
				}
				for (let t = s + 1; t < e.length; t += 1) {
					let n = i(e[t]);
					if (n != null) {
						g = n;
						break;
					}
				}
			}
			let b = o.filter((e) => e.w > 0 && e.sort >= m && e.sort <= g);
			Hn(n, "xwiresGate") && l.x && (b = b.filter((e) => e.color === "blue"));
			for (let e of l.tokens) {
				let t = e.token;
				t.kind === "value" && e.fake ? b = b.filter((e) => e.color !== "blue" || e.v !== t.value) : t.kind === "yellow" && e.fake ? b = b.filter((e) => e.color !== "yellow") : t.kind === "parity" ? b = b.filter((e) => e.color === "blue" && e.v % 2 == 1 === t.odd) : t.kind === "count" && (b = b.filter((e) => e.color === "blue" && t.n + (h.get(e.v) ?? 0) <= 4));
			}
			for (let t of [s - 1, s + 1]) {
				let n = e[t];
				if (!n || s < 0 || !(l.tokens.some((e) => e.token.kind === "neq") && n.tokens.some((e) => e.token.kind === "neq"))) continue;
				let r = y(n);
				r && (b = b.filter((e) => e.color !== r.color || e.v !== r.v));
			}
			let x = te.get(l.id);
			x && (b = b.filter((e) => e.color === "red" || !x.has(e.color === "yellow" ? "yellow" : e.v)));
			let S = ee.get(`${t.rid}:${r + 1}`);
			S && (b = b.filter((e) => e.color !== "blue" || !S.has(e.v)));
			let w = -1, T = 0, ne = a.get(l.id);
			!p && ne != null && c > 0 && (w = (ne + 1) / (c + 1), T = Math.max(.0036, w * (1 - w) / (c + 2)) * .75), C(t.rid, l, b, !0, w, T);
		}
	});
	{
		let i = Hn(n, "nanoCollect"), o = /* @__PURE__ */ new Map(), s = (e, t, n) => {
			let r = o.get(e) ?? /* @__PURE__ */ new Map();
			r.set(t, (r.get(t) ?? 0) + n), o.set(e, r);
		};
		for (let t of e.log) t.k === "equip" && (t.id === "talkies" || t.id === "grapple") && (i = !0), (t.k === "dualOk" || t.k === "dualFail") && (i || s(t.from, t.guess, 1));
		for (let t of e.players) for (let e of t.racks) for (let n of e) {
			if (!n.cut || !n.revealed) continue;
			let e = n.revealed.color === "blue" ? Math.round(n.revealed.sort) : n.revealed.color;
			e !== "red" && s(t.rid, e, -1);
		}
		let c = (e, t) => {
			e.p = /* @__PURE__ */ new Map([[t, 1]]), e.boom = 0, e.certain = t;
		};
		for (let i = 0; i < 2; i += 1) {
			for (let [e, t] of o) for (let [n, r] of t) {
				if (r <= 0 || typeof n == "number" && n === a) continue;
				let t = x.filter((t) => t.owner === e && (t.p.get(n) ?? 0) > 0);
				if (t.length === r) for (let e of t) c(e, n);
			}
			let i = /* @__PURE__ */ new Map();
			for (let e of t?.mine ?? []) {
				let t = m.get(e.wire);
				if (!t || t.w.cut) continue;
				let n = e.color === "blue" ? Math.round(e.sort) : "yellow";
				e.color !== "red" && i.set(n, (i.get(n) ?? 0) + 1);
			}
			let s = (() => {
				let t = e.players.length;
				return t === 2 && n.yellow2p ? n.yellow2p.n : n.yellow.n < 0 ? Math.min(t, 4) : n.yellow.n;
			})(), l = [];
			for (let e = 1; e <= n.blueMax; e += 1) l.push(e);
			l.push("yellow");
			let u = new Set((t?.mine ?? []).map((e) => e.wire)), d = 0;
			for (let t of e.players) if (t.rid === r) for (let e of t.racks) for (let t of e) !t.cut && !u.has(t.id) && (d += 1);
			for (let t of l) {
				if (typeof t == "number" && t === a) continue;
				let n = t === "yellow" ? s : 4;
				if (n <= 0) continue;
				let r = 0;
				for (let n of e.players) for (let e of n.racks) for (let n of e) n.cut && n.revealed && (n.revealed.color === "blue" ? Math.round(n.revealed.sort) : n.revealed.color) === t && (r += 1);
				let o = n - r - (i.get(t) ?? 0);
				if (o <= 0) continue;
				let l = x.filter((e) => (e.p.get(t) ?? 0) > 0);
				if (l.length + d === o) for (let e of l) c(e, t);
			}
		}
	}
	return {
		ests: x,
		byWire: S
	};
}
//#endregion
//#region src/games/bombbusters/bot.ts
var Q = (e, t) => e.features.includes(t), $ = (e) => e.color === "blue" ? Math.round(e.sort) : e.color;
function Gn(e, t) {
	return {
		pub: e.public,
		priv: e.private,
		me: t
	};
}
var Kn = (e) => new Map((e.priv?.mine ?? []).map((e) => [e.wire, e]));
function qn(e, t) {
	let n = e.pub.players.length;
	return n === 2 && t.yellow2p ? t.yellow2p.n : t.yellow.n < 0 ? Math.min(n, 4) : t.yellow.n;
}
function Jn(e) {
	return e.pub.players.find((t) => t.rid === e.me);
}
function Yn(e) {
	return (Jn(e)?.racks ?? []).flat().filter((e) => !e.cut);
}
function Xn(e) {
	return e.pub.players.filter((t) => t.rid !== e.me && !t.done);
}
function Zn(e, t) {
	return (e.pub.players.find((e) => e.rid === t)?.racks ?? []).flat().filter((e) => !e.cut);
}
function Qn(e, t) {
	let n = 0;
	for (let r of e.pub.players) for (let e of r.racks) for (let r of e) r.cut && r.revealed && (r.revealed.color === "blue" ? Math.round(r.revealed.sort) : r.revealed.color) === t && n++;
	return n;
}
function $n(e) {
	let t = /* @__PURE__ */ new Map(), n = (e, n, r) => {
		let i = t.get(e) ?? /* @__PURE__ */ new Map();
		i.set(n, (i.get(n) ?? 0) + r), t.set(e, i);
	};
	for (let t of e.pub.log) (t.k === "dualOk" || t.k === "dualFail") && n(t.from, t.guess, 1);
	for (let t of e.pub.players) for (let e of t.racks) for (let r of e) {
		if (!r.cut || !r.revealed) continue;
		let e = r.revealed.color === "blue" ? Math.round(r.revealed.sort) : r.revealed.color;
		e !== "red" && n(t.rid, e, -1);
	}
	return t;
}
function er(e, t, n) {
	return Yn(e).filter((e) => $(t.get(e.id) ?? {
		color: "red",
		sort: 0
	}) === n).length;
}
function tr(e, t, n, r) {
	if (!xn(e.pub, t, e.me, e.priv?.secretConstraint ?? null, r, !0) || (e.pub.mods.nano?.nanoWires ?? 0) > 0) return !1;
	let i = r === "yellow" ? qn(e, t) : 4;
	if (i <= 0) return !1;
	let a = i - Qn(e, r), o = er(e, n, r);
	return !(o === 0 || o !== a || typeof r == "number" && o !== 2 && o !== 4);
}
function nr(e, t, n) {
	let r = {}, i = Kn(e);
	if (Q(t, "numVisible") && !Q(t, "mathCards") && e.pub.mods.numVisible) {
		let t = e.pub.mods.numVisible, a = t.filter((t) => t !== n && er(e, i, t) === 0), o = t.filter((e) => e !== n), s = a[0] ?? o[0] ?? (typeof n == "number" ? n : void 0);
		if (s == null) return null;
		r.cover = s;
	}
	if (Q(t, "mathCards") && e.pub.mods.numVisible && typeof n == "number") {
		let t = e.pub.mods.numVisible, i = null;
		for (let e = 0; e < t.length && !i; e++) for (let r = 0; r < t.length; r++) if (!(e === r && t.filter((n) => n === t[e]).length < 2) && (e !== r || t.filter((n) => n === t[e]).length > 1) && (t[e] + t[r] === n || Math.abs(t[e] - t[r]) === n)) {
			i = {
				a: t[e],
				b: t[r]
			};
			break;
		}
		if (!i) return null;
		r.math = i;
	}
	let a = e.pub.mods.oxygen;
	if (a) {
		let i = typeof n == "number" ? n <= 4 ? 1 : n <= 8 ? 2 : 3 : 1, o = typeof n == "number" ? n : 1;
		if (Q(t, "oxygenPool")) {
			if (a.pool < i) return null;
		} else if (Q(t, "oxygenPerPlayer")) {
			if ((a.perPlayer[e.me] ?? 0) < o) return null;
			let t = Xn(e).sort((e, t) => (a.perPlayer[t.rid] ?? 0) - (a.perPlayer[e.rid] ?? 0))[0];
			if (!t) return null;
			r.payTo = t.rid;
		} else if (Q(t, "oxygenCaptain") && (a.perPlayer[a.holder ?? ""] ?? 0) < o) return null;
	}
	return r;
}
function rr(e, t) {
	for (let n of Jn(e)?.racks ?? []) {
		let e = n.findIndex((e) => e.id === t);
		if (e >= 0) return n.length <= 1 ? .5 : e / (n.length - 1);
	}
	return .5;
}
function ir(e, t) {
	let n = Kn(e), r = Yn(e), i = r.filter((e) => n.get(e.id)?.color === "blue"), a = t.setupTokens;
	if (a === "none" || a === "random") return null;
	let o = /* @__PURE__ */ new Set(), s = /* @__PURE__ */ new Set(), c = /* @__PURE__ */ new Set();
	for (let t of e.pub.players) for (let e of t.racks) for (let t of e) for (let e of t.tokens) e.token.kind === "value" ? (e.fake ? s : o).add(e.token.value) : e.token.kind === "parity" && !e.fake && c.add(e.token.odd);
	let l = e.pub.players.findIndex((t) => t.rid === e.me), u = e.pub.players.findIndex((t) => t.rid === e.pub.captain), d = t.tokenStyle === "parity" || t.tokenStyle === "mixed" && (l - u + e.pub.players.length) % 2 == 1, f = (i) => {
		let a = n.get(i.id);
		if (!a) return null;
		let o = Math.round(a.sort), s = t.tokenStyle, c = t.fakeTokens === "all" || t.fakeTokens === "sergio" && e.me === e.pub.captain, l = (e) => c && e.kind === "value" ? {
			kind: "value",
			value: o % 12 + 1
		} : e;
		if (s === "parity") return {
			kind: "parity",
			odd: o % 2 == 1
		};
		if (s === "count") {
			let e = r.filter((e) => n.get(e.id)?.color === "blue" && Math.round(n.get(e.id).sort) === o).length;
			return e >= 1 && e <= 3 ? {
				kind: "count",
				n: e
			} : null;
		}
		if (s === "mixed") {
			if ((e.pub.players.findIndex((t) => t.rid === e.me) - e.pub.players.findIndex((t) => t.rid === e.pub.captain) + e.pub.players.length) % e.pub.players.length % 2 == 1) return {
				kind: "parity",
				odd: o % 2 == 1
			};
			let t = r.filter((e) => n.get(e.id)?.color === "blue" && Math.round(n.get(e.id).sort) === o).length;
			return t >= 1 && t <= 3 ? {
				kind: "count",
				n: t
			} : null;
		}
		return s === "none" ? null : l({
			kind: "value",
			value: o
		});
	}, p = (t) => {
		let a = i.filter((e) => !t.has(e.id) && e.tokens.length === 0);
		if (o.size > 0) {
			let e = a.filter((e) => !o.has(Math.round(n.get(e.id)?.sort ?? -1)));
			e.length > 0 && (a = e);
		}
		if (d && c.size === 1) {
			let e = ![...c][0], t = a.filter((t) => {
				let r = n.get(t.id);
				return r?.color === "blue" && Math.round(r.sort) % 2 == 1 === e;
			});
			t.length > 0 && (a = t);
		}
		let s = a.filter((e) => {
			let t = Math.round(n.get(e.id).sort);
			return r.filter((e) => n.get(e.id)?.color === "blue" && Math.round(n.get(e.id).sort) === t).length === 1;
		});
		return (s.length > 0 ? s : a).sort((t, n) => Math.abs(rr(e, t.id) - .5) - Math.abs(rr(e, n.id) - .5))[0] ?? null;
	};
	if (a === "absent") {
		let e = /* @__PURE__ */ new Set(), t = !1;
		for (let i of r) {
			let r = n.get(i.id);
			r?.color === "blue" ? e.add(Math.round(r.sort)) : r?.color === "yellow" && (t = !0);
		}
		let a = [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			9,
			10,
			11,
			12
		].filter((t) => !e.has(t) && !s.has(t)), o = [
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			9,
			10,
			11,
			12
		].filter((t) => !e.has(t)), c = [];
		o.length >= 1 ? (c.push({
			kind: "value",
			value: a[0] ?? o[0]
		}), c.push({
			kind: "value",
			value: a[1] ?? a[0] ?? o[0]
		})) : t ? c.push({
			kind: "value",
			value: 1
		}, {
			kind: "value",
			value: 2
		}) : c.push({ kind: "yellow" }, { kind: "yellow" });
		let l = [], u = /* @__PURE__ */ new Set();
		for (let e of c) {
			let t = p(u) ?? i.filter((e) => !u.has(e.id))[0];
			if (!t) break;
			u.add(t.id), l.push({
				wire: t.id,
				token: e
			});
		}
		return l.length === 2 ? {
			type: "setupToken",
			placements: l
		} : null;
	}
	if (a === "fake") {
		let e = [], t = /* @__PURE__ */ new Set();
		for (let i = 0; i < 2; i++) {
			let i = p(t) ?? r.filter((e) => !t.has(e.id) && e.tokens.length === 0)[0];
			if (!i) break;
			let a = n.get(i.id);
			if (!a) break;
			t.add(i.id);
			let o = ((a.color === "blue" ? Math.round(a.sort) : 0) + 5) % 12 + 1;
			e.push({
				wire: i.id,
				token: {
					kind: "value",
					value: o
				}
			});
		}
		return e.length > 0 ? {
			type: "setupToken",
			placements: e
		} : null;
	}
	if (t.fakeTokens === "sergio" && e.me === e.pub.captain && a === "standard") {
		let e = [], t = /* @__PURE__ */ new Set();
		for (let r = 0; r < 2; r++) {
			let r = p(t) ?? i.filter((e) => !t.has(e.id))[0];
			if (!r) break;
			let a = n.get(r.id);
			if (!a) break;
			t.add(r.id);
			let o = Math.round(a.sort);
			e.push({
				wire: r.id,
				token: {
					kind: "value",
					value: o % 12 + 1
				}
			});
		}
		return e.length === 2 ? {
			type: "setupToken",
			placements: e
		} : null;
	}
	let m = p(/* @__PURE__ */ new Set());
	if (!m) return null;
	let h = f(m);
	return h ? {
		type: "setupToken",
		placements: [{
			wire: m.id,
			token: h
		}]
	} : null;
}
function ar(e, t) {
	let n = e.pub.pending.find((t) => t.rid === e.me);
	if (!n) return null;
	let r = Kn(e);
	switch (n.kind) {
		case "failToken": {
			let t = n.wires ?? [];
			if (t.length === 0) return {
				type: "respond",
				kind: "failToken",
				index: 0
			};
			if (n.cut) {
				let n = 0, i = -1;
				return t.forEach((t, a) => {
					let o = r.get(t), s = o ? Qn(e, $(o) === "red" ? 1 : $(o)) : 0;
					s > i && (i = s, n = a);
				}), {
					type: "respond",
					kind: "failToken",
					index: n
				};
			}
			let i = 0, a = -Infinity;
			return t.forEach((t, n) => {
				let o = r.get(t), s = -Math.abs(rr(e, t) - .5);
				if (o?.color === "blue") {
					let t = Math.round(o.sort), n = Yn(e).filter((e) => r.get(e.id)?.color === "blue" && Math.round(r.get(e.id).sort) === t).length;
					s += n === 1 ? 2 : 1;
				}
				let c = Yn(e).find((e) => e.id === t);
				c && c.tokens.length === 0 && (s += 1), s > a && (a = s, i = n);
			}), {
				type: "respond",
				kind: "failToken",
				index: i
			};
		}
		case "pickToken": {
			let t = n.options ?? [];
			for (let n = 0; n < t.length; n++) if (Yn(e).some((e) => r.get(e.id)?.color === "blue" && Math.round(r.get(e.id).sort) === t[n] && e.tokens.length === 0)) return {
				type: "respond",
				kind: "pickToken",
				index: n
			};
			return {
				type: "respond",
				kind: "pickToken",
				index: 0
			};
		}
		case "passToken": return {
			type: "respond",
			kind: "passToken",
			index: 0
		};
		case "chooseConstraint": {
			let t = new Set(Object.values(e.pub.mods.constraints?.perPlayer ?? {}).filter((e) => e != null)), n = [...new Set(Yn(e).map((e) => $(r.get(e.id) ?? {
				color: "red",
				sort: 0
			})))].filter((e) => typeof e == "number"), i = (e) => n.filter((t) => e === "A" && t % 2 == 1 || e === "B" && t % 2 == 0 || e === "C" && t > 6 || e === "D" && t < 7 || e === "E" && (t < 4 || t > 9)).length, a = oe.filter((e) => !t.has(e)).sort((e, t) => i(e) - i(t))[0];
			return a ? {
				type: "respond",
				kind: "chooseConstraint",
				constraint: a
			} : {
				type: "respond",
				kind: "chooseConstraint",
				constraint: "A"
			};
		}
		case "placeCard": {
			let t = e.priv?.handCards ?? [];
			return {
				type: "respond",
				kind: "placeCard",
				card: t.find((t) => e.pub.validated.includes(t)) ?? t[0]
			};
		}
		case "giveCard": {
			let n = e.pub.mods.handCardsDown?.[e.me] ?? [], i = e.pub.mods.handCards?.[e.me] ?? [], a = new Set(Yn(e).map((e) => $(r.get(e.id) ?? {
				color: "red",
				sort: 0
			}))), o = i.find((e, t) => i.indexOf(e) !== t), s = i.filter((e) => !a.has(e)), c = n[0] ?? o ?? s[0] ?? i[0], l = Xn(e)[0], u = -1;
			for (let n of Xn(e)) {
				let e = 1 - t.ests.filter((e) => e.owner === n.rid).reduce((e, t) => e * (1 - (t.p.get(c) ?? 0)), 1);
				e > u && (u = e, l = n);
			}
			return {
				type: "respond",
				kind: "giveCard",
				card: c,
				target: l?.rid ?? e.pub.players.find((t) => t.rid !== e.me).rid
			};
		}
		case "talkiesPick": {
			let t = n.wires ?? [], i = 0, a = -Infinity;
			return t.forEach((t, n) => {
				let o = r.get(t), s = 0;
				o?.color === "red" ? s = 2 : o?.color === "yellow" ? s = 1 : o && e.pub.validated.includes(Math.round(o.sort)) ? s = 3 : o && (s = -o.sort / 100), s > a && (a = s, i = n);
			}), {
				type: "respond",
				kind: "talkiesPick",
				index: i
			};
		}
		case "moveSequence": return {
			type: "respond",
			kind: "moveSequence",
			end: "left"
		};
	}
}
var or = (e) => e >= 3 ? .45 : e === 2 ? .6 : e === 1 ? .85 : 1, sr = .02;
function cr(e, t) {
	let n = e.pub, r = Kn(e), i = Yn(e);
	if (i.length === 0) return null;
	let a = e.priv?.secretConstraint ?? null, o = Wn(n, e.priv, t, e.me), s = i.filter((e) => !r.has(e.id)), c = /* @__PURE__ */ new Map();
	if (s.length > 0) {
		let n = [];
		for (let e = 1; e <= t.blueMax; e += 1) n.push(e);
		n.push("yellow");
		for (let i of n) {
			let n = (i === "yellow" ? qn(e, t) : 4) - Qn(e, i) - er(e, r, i) - o.ests.filter((e) => (e.p.get(i) ?? 0) > 0).length;
			n >= 1 && c.set(i, n);
		}
	}
	let l = new Set(c.keys()), u = /* @__PURE__ */ new Map();
	if (s.length > 0) for (let t of Jn(e)?.racks ?? []) {
		let e = 0;
		for (let n = 0; n < t.length; n += 1) {
			let i = t[n], a = r.get(i.id)?.sort ?? (i.cut && i.revealed ? i.revealed.sort : null);
			if (a != null) {
				for (let i = n + 1; i < t.length; i += 1) {
					let n = t[i];
					if (r.has(n.id) || n.cut && n.revealed) break;
					if (s.some((e) => e.id === n.id)) {
						let t = u.get(n.id);
						u.set(n.id, {
							lo: e,
							hi: t?.hi ?? 99
						});
					}
				}
				e = a;
			}
		}
		let n = 99;
		for (let e = t.length - 1; e >= 0; --e) {
			let i = t[e], a = r.get(i.id)?.sort ?? (i.cut && i.revealed ? i.revealed.sort : null);
			if (a != null) {
				for (let i = e - 1; i >= 0; --i) {
					let e = t[i];
					if (r.has(e.id) || e.cut && e.revealed) break;
					let a = u.get(e.id);
					a && a.hi === 99 && u.set(e.id, {
						lo: a.lo,
						hi: n
					});
				}
				n = a;
			}
		}
	}
	let d = (e, t) => {
		let n = u.get(e);
		return !n || t === "yellow" || n.lo <= t && t <= n.hi;
	}, f = (e, t) => {
		let n = c.get(t);
		return !n || !d(e.id, t) ? !1 : s.filter((n) => n.id !== e.id && d(n.id, t)).length < n;
	}, p = new Map(r);
	for (let e of s) for (let t of l) if (f(e, t)) {
		p.set(e.id, {
			color: t === "yellow" ? "yellow" : "blue",
			sort: t === "yellow" ? .1 : t
		});
		break;
	}
	let m = 0;
	for (let e = n.log.length - 1; e >= 0 && n.log[e].k === "pass"; e--) m++;
	let h = n.players.filter((e) => !e.done).length, g = m >= h, _ = n.forcedBy === e.me && n.forcedValue != null && i.some((e) => $(p.get(e.id) ?? {
		color: "red",
		sort: 0
	}) === n.forcedValue), v = !!(n.mods.oxygen || Q(t, "mathCards") || Q(t, "numHands") || Q(t, "nanoTrack") || Q(t, "handCards") || Q(t, "upsideCaptain") || Q(t, "constraintsOnValidate")), y = !!e.priv?.canPass && !v;
	if (n.mods.squeak && n.forcedValue != null && n.forcedBy == null && n.turn === e.me) return null;
	if (i.every((e) => {
		let t = p.get(e.id);
		return t ? t.color === "red" || n.mods.cursed !== void 0 && t.color === "blue" && Math.round(t.sort) === n.mods.cursed : !1;
	}) && i.length > 0 && (n.turn === e.me || n.forcedBy === e.me) && !Q(t, "massCutRed3") && !n.mods.sevensOnly) return { type: "reveal" };
	if (n.mods.sevensOnly) {
		let t = [];
		for (let n of i) {
			let r = p.get(n.id);
			r?.color === "blue" && Math.round(r.sort) === 7 && t.push({
				rid: e.me,
				wire: n.id,
				score: 2
			});
		}
		for (let e of o.ests) {
			let n = e.p.get(7) ?? 0;
			if (n <= 0) continue;
			let r = e.boom === 0 && !e.p.has("yellow");
			t.push({
				rid: e.owner,
				wire: e.wire.id,
				score: +!!r + n
			});
		}
		t.sort((e, t) => t.score - e.score || e.wire - t.wire);
		let n = t.slice(0, 4);
		if (n.length === 4) return {
			type: "massCut",
			picks: n.map((e) => ({
				rid: e.rid,
				wire: e.wire
			}))
		};
	}
	if (Q(t, "massCutRed3") && i.every((e) => p.get(e.id)?.color === "red")) {
		let t = i.map((t) => ({
			rid: e.me,
			wire: t.id
		})), n = o.ests.filter((e) => !t.some((t) => t.wire === e.wire.id)).sort((e, t) => t.boom - e.boom || e.wire.id - t.wire.id);
		for (let e of n) {
			if (t.length >= 3) break;
			t.push({
				rid: e.owner,
				wire: e.wire.id
			});
		}
		if (t.length === 3) return {
			type: "massCut",
			picks: t
		};
	}
	if (Q(t, "massCutYellow3")) {
		let t = i.filter((e) => p.get(e.id)?.color === "yellow").map((t) => ({
			rid: e.me,
			wire: t.id
		}));
		for (let e of o.ests) e.certain === "yellow" && t.push({
			rid: e.owner,
			wire: e.wire.id
		});
		if (t.length >= 3) return {
			type: "massCut",
			picks: t.slice(0, 3)
		};
	}
	let b = null;
	if (Q(t, "massCut4") && n.mods.slotCard !== void 0 && Qn(e, n.mods.slotCard) === 0) {
		let t = n.mods.slotCard, r = [];
		for (let n of i) {
			let i = p.get(n.id);
			i?.color === "blue" && Math.round(i.sort) === t && r.push({
				rid: e.me,
				wire: n.id,
				p: 1
			});
		}
		for (let e of o.ests) {
			let n = e.certain === t ? 1 : e.p.get(t) ?? 0;
			n > 0 && r.push({
				rid: e.owner,
				wire: e.wire.id,
				p: n
			});
		}
		r.sort((e, t) => t.p - e.p || e.wire - t.wire);
		let a = r.slice(0, 4);
		if (a.length === 4) {
			let e = a.reduce((e, t) => e * t.p, 1);
			if (b = {
				combined: e,
				make: () => ({
					type: "massCut",
					picks: a.map((e) => ({
						rid: e.rid,
						wire: e.wire
					}))
				})
			}, e >= .999) return b.make();
		}
	}
	if (n.mods.challenges?.some((e) => e.id === 1 && !e.done)) {
		let t = i.find((e) => p.get(e.id)?.color === "red");
		if (t) return {
			type: "massCut",
			picks: [{
				rid: e.me,
				wire: t.id
			}]
		};
	}
	let ee = (r) => xn(n, t, e.me, a, r, !1) && (typeof r != "number" || n.mods.cursed !== r), te = (r) => ee(r) && !(Q(t, "sevensLast") && r === 7 && !n.mods.sevensOnly) && !(Q(t, "massCut4") && n.mods.slotCard === r && Qn(e, r) === 0), x = [.../* @__PURE__ */ new Set([...i.map((e) => $(p.get(e.id) ?? {
		color: "red",
		sort: 0
	})), ...l])], S = x.filter((e) => e !== "red" && te(e)), C = [...n.mods.constraints?.active ?? []], w = n.mods.constraints?.perPlayer[e.me];
	w && C.push(w);
	let T = C.includes("H"), ne = C.includes("I") ? 1 : C.includes("J") ? -1 : 0, re = (e, t) => {
		if (!ne) return !1;
		let r = ((n.players.find((t) => t.rid === e)?.racks ?? []).find((e) => e.some((e) => e.id === t)) ?? []).filter((e) => !e.cut);
		return (ne === 1 ? r[r.length - 1] : r[0])?.id === t;
	}, ie = (e) => !(T && e.wire.tokens.length > 0 || re(e.owner, e.wire.id) || e.wire.upside && Q(t, "upsideCaptain"));
	for (let r of x) if (r !== "red" && (te(r) || typeof r == "number" && n.mods.slotCard === r && Qn(e, r) > 0) && !(T && i.some((e) => e.tokens.length > 0 && $(p.get(e.id) ?? {
		color: "red",
		sort: 0
	}) === r)) && tr(e, t, p, r)) {
		let n = nr(e, t, r);
		if (n) return {
			type: "solo",
			value: r,
			...n
		};
	}
	if (Q(t, "iberian") && !n.yellowDone) {
		for (let e of o.ests) if (e.certain === "yellow") return {
			type: "iberian",
			target: e.owner,
			wire: e.wire.id
		};
		for (let t of Xn(e)) for (let n of Zn(e, t.rid)) if (n.tokens.some((e) => e.token.kind === "yellow" && !e.fake)) return {
			type: "iberian",
			target: t.rid,
			wire: n.id
		};
	}
	let ae = (e) => {
		let r = i.filter((t) => $(p.get(t.id) ?? {
			color: "red",
			sort: 0
		}) === e);
		return Q(t, "xwiresGate") && !n.yellowDone && (r = r.filter((e) => !e.x)), T && (r = r.filter((e) => e.tokens.length === 0)), r = r.sort((e, t) => e.tokens.length - t.tokens.length || e.id - t.id), r.length > 0 ? r[0] : s.filter((e) => !(e.x && Q(t, "xwiresGate") && !n.yellowDone) && !(T && e.tokens.length > 0)).find((t) => f(t, e));
	}, E = /* @__PURE__ */ new Map();
	for (let n of S) {
		let r = nr(e, t, n), i = ae(n);
		r && i && E.set(n, {
			ex: r,
			mine: i.id,
			marked: i.tokens.length > 0
		});
	}
	let oe = (r) => r === "yellow" ? (Q(t, "xwiresGate") && !n.yellowDone ? 100 : 0) + (Q(t, "sevensLast") ? 50 : 0) : 2 * Qn(e, r) + (n.mods.bonusCards?.includes(r) ? 3 : 0) + (n.mods.challenge8?.includes(r) && n.validated.length < 2 ? 2 : 0) + (n.mods.nano && n.mods.nano.pos === r ? 4 : 0), D = (n) => n === "yellow" ? qn(e, t) - Qn(e, "yellow") : 4 - Qn(e, n), se = (n) => t.fakeTokens || g || _ ? !1 : !!E.get(n)?.marked && D(n) > er(e, p, n), O = o.ests.filter((e) => e.certain != null && E.has(e.certain) && D(e.certain) !== 3 && !(e.wire.x && Q(t, "xwiresGate") && !n.yellowDone) && ie(e)).sort((e, t) => oe(t.certain) - oe(e.certain) || e.wire.id - t.wire.id), ce = O.filter((e) => !se(e.certain)), k = ce.length > 0 || y ? ce : O;
	for (let e of k) {
		let t = E.get(e.certain);
		return {
			type: "dual",
			target: e.owner,
			wires: [e.wire.id],
			guesses: [e.certain],
			mine: t.mine,
			...t.ex
		};
	}
	let le = (Q(t, "sergio") || Q(t, "lazyCaptain")) && e.me === n.captain, A = (e) => !le && n.equipments.some((t) => t.id === e && t.unlocked && !t.used), ue = n.mods.constraints?.active.includes("G") || n.mods.constraints?.perPlayer[e.me] === "G";
	if (!ue) {
		if (n.dial && n.dial.step >= Math.ceil(n.dial.max / 2) && A("rewinder")) return {
			type: "equip",
			id: "rewinder"
		};
		if (A("doubleFond")) return {
			type: "equip",
			id: "doubleFond"
		};
		if (A("disintegrator")) return {
			type: "equip",
			id: "disintegrator"
		};
		if (A("threadCutter") && n.turn === e.me && n.forcedBy == null) {
			let e = /* @__PURE__ */ new Map();
			for (let t of i) {
				let n = p.get(t.id);
				if (n?.color !== "blue" || t.x) continue;
				let r = Math.round(n.sort);
				e.set(r, [...e.get(r) ?? [], t]);
			}
			for (let [n, r] of e) {
				let e = r.sort((e, t) => e.tokens.length - t.tokens.length || e.id - t.id).map((e) => e.id);
				if (e.length >= 2 && D(n) !== 3 && !(Q(t, "sevensLast") && n === 7)) return {
					type: "equip",
					id: "threadCutter",
					params: {
						a: e[0],
						b: e[1]
					}
				};
			}
		}
		if (A("radar")) {
			let e = new Set(n.log.filter((e) => e.k === "radar").map((e) => e.value)), t = null, r = .5;
			for (let n of S) {
				if (typeof n != "number" || e.has(n)) continue;
				let i = 0;
				for (let e of o.ests) {
					let t = e.p.get(n) ?? 0;
					t > 0 && t < 1 && (i += t);
				}
				i > r && (r = i, t = n);
			}
			if (t != null) return {
				type: "equip",
				id: "radar",
				params: { value: t }
			};
		}
		if (A("fund") && n.equipments.some((e) => e.used && (e.id === "stabilizer" || e.id === "rewinder" || e.id === "radar" || e.id === "postit"))) return {
			type: "equip",
			id: "fund",
			params: {}
		};
		if (A("batteries")) {
			let e = n.players.filter((e) => e.character?.used).map((e) => e.rid).slice(0, 2);
			if (e.length > 0) return {
				type: "equip",
				id: "batteries",
				params: { rids: e }
			};
		}
		let r = i.filter((e) => e.tokens.length === 0 && p.get(e.id)?.color === "blue" && !e.x).sort((t, n) => Math.abs(rr(e, t.id) - .5) - Math.abs(rr(e, n.id) - .5))[0];
		if (r && A("postit")) {
			let n = p.get(r.id), i = Math.round(n.sort), a = t.fakeTokens === "all" || t.fakeTokens === "sergio" && e.me === e.pub.captain, o = t.tokenStyle;
			o === "mixed" && (o = (e.pub.players.findIndex((t) => t.rid === e.me) - e.pub.players.findIndex((t) => t.rid === e.pub.captain) + e.pub.players.length) % 2 == 0 ? "count" : "parity");
			let s = null;
			if (o === "parity") s = {
				kind: "parity",
				odd: i % 2 == 1
			};
			else if (o === "count") {
				let e = [...p.values()].filter((e) => e.color === "blue" && Math.round(e.sort) === i).length;
				!a && e >= 1 && e <= 3 && (s = {
					kind: "count",
					n: e
				});
			} else s = {
				kind: "value",
				value: a ? i % 12 + 1 : i
			};
			if (s) return {
				type: "equip",
				id: "postit",
				params: {
					wire: r.id,
					token: s
				}
			};
		}
		if (r && A("singleLabel")) return {
			type: "equip",
			id: "singleLabel",
			params: { wire: r.id }
		};
		if (A("eq")) {
			let t = null;
			for (let n of Jn(e)?.racks ?? []) for (let e = 0; e + 1 < n.length; e++) {
				if (n[e].cut || n[e + 1].cut) continue;
				let r = p.get(n[e].id), i = p.get(n[e + 1].id);
				if (!r || !i) continue;
				let a = $(r);
				a !== "red" && a === $(i) && !n[e].tokens.some((e) => e.token.kind === "eq") && (t = {
					a: n[e].id,
					b: n[e + 1].id
				});
			}
			if (t) return {
				type: "equip",
				id: "eq",
				params: t
			};
		}
		if (A("neq")) {
			let t = null;
			for (let n of Jn(e)?.racks ?? []) for (let e = 0; e + 1 < n.length; e++) {
				if (n[e].cut || n[e + 1].cut || n[e].tokens.some((e) => e.token.kind === "neq" || e.token.kind === "eq") || n[e + 1].tokens.some((e) => e.token.kind === "neq" || e.token.kind === "eq")) continue;
				let r = p.get(n[e].id), i = p.get(n[e + 1].id);
				r && i && $(r) !== $(i) && (t = {
					a: n[e].id,
					b: n[e + 1].id
				});
			}
			if (t) return {
				type: "equip",
				id: "neq",
				params: t
			};
		}
		if (A("grapple")) {
			let e = null, t = .5;
			for (let n of o.ests) if (!(n.wire.x || n.wire.upside || n.boom > sr)) for (let r of S) {
				let i = n.p.get(r) ?? 0;
				i > t && (t = i, e = n);
			}
			if (e) return {
				type: "equip",
				id: "grapple",
				params: { theirWire: e.wire.id }
			};
		}
	}
	let de = (() => {
		if (ue || t.noDD2000 === "all" || t.noDD2000 === "captain" && e.me === n.captain) return !1;
		if (t.unlimitedDD) return !0;
		let r = Jn(e)?.character;
		return !!r && r.id === "dd2000" && !r.used && !!Jn(e)?.revealed;
	})(), j = (e, r) => !(!ie(e) || e.wire.x && Q(t, "xwiresGate") && !n.yellowDone || r && (e.wire.x || e.wire.upside)), M = (e) => {
		let t = n.mods.nanoTrack;
		if (t && typeof e == "number") {
			let n = t.cards.indexOf(e);
			if (n >= 0) return Math.abs(n - t.at) / 8;
		}
		return 0;
	}, fe = (r) => {
		let i = [], a = (e, t) => {
			if (D(t) === 3) return;
			let n = E.get(t);
			i.push({
				p: e.p.get(t) ?? 0,
				boom: e.boom,
				cost: M(t),
				g: t,
				make: () => ({
					type: "dual",
					target: e.owner,
					wires: [e.wire.id],
					guesses: [t],
					mine: n.mine,
					...n.ex
				})
			});
		};
		for (let s of S) if (!(!E.has(s) || r && se(s))) for (let r of Xn(e)) {
			let c = o.ests.filter((e) => e.owner === r.rid && j(e, !1) && (e.p.get(s) ?? 0) > 0);
			for (let e of c) a(e, s);
			if (typeof s != "number") continue;
			if (de && D(s) !== 3) {
				let e = o.ests.filter((e) => e.owner === r.rid && j(e, !0) && (e.p.get(s) ?? 0) > 0).sort((e, t) => (t.p.get(s) ?? 0) - (e.p.get(s) ?? 0) || e.wire.id - t.wire.id);
				if (e.length >= 2) {
					let [n, a] = e, o = E.get(s);
					i.push({
						p: 1 - (1 - (n.p.get(s) ?? 0)) * (1 - (a.p.get(s) ?? 0)),
						boom: 1 - (1 - n.boom) * (1 - a.boom),
						cost: t.unlimitedDD ? 0 : .03,
						g: s,
						make: () => ({
							type: "dual",
							target: r.rid,
							wires: [n.wire.id, a.wire.id],
							guesses: [s],
							mine: o.mine,
							dd2000: !0,
							...o.ex
						})
					});
				}
			}
			let l = Jn(e)?.character, u = A("triple") || !!l && l.id === "triple" && !l.used && !!Jn(e)?.revealed;
			if (!ue && u) {
				let e = o.ests.filter((e) => e.owner === r.rid && j(e, !0) && (e.p.get(s) ?? 0) > 0).sort((e, t) => (t.p.get(s) ?? 0) - (e.p.get(s) ?? 0) || e.wire.id - t.wire.id);
				if (e.length >= 3) {
					let t = e.slice(0, 3), n = E.get(s);
					i.push({
						p: 1 - t.reduce((e, t) => e * (1 - (t.p.get(s) ?? 0)), 1),
						boom: 1 - t.reduce((e, t) => e * (1 - t.boom), 1),
						cost: .03,
						g: s,
						make: () => ({
							type: "dual",
							target: r.rid,
							wires: t.map((e) => e.wire.id),
							guesses: [s],
							mine: n.mine,
							boost: "triple",
							...n.ex
						})
					});
				}
			}
			if (!ue && A("super")) {
				let e = n.players.find((e) => e.rid === r.rid)?.racks ?? [];
				for (let t of e) {
					let e = t.filter((e) => !e.cut);
					if (e.length < 2 || e.some((e) => e.x || e.upside)) continue;
					let n = e.map((e) => o.byWire.get(e.id)).filter((e) => !!e && j(e, !0));
					if (n.length !== e.length || n.filter((e) => (e.p.get(s) ?? 0) > 0).length === 0) continue;
					let a = E.get(s);
					i.push({
						p: 1 - n.reduce((e, t) => e * (1 - (t.p.get(s) ?? 0)), 1),
						boom: 1 - n.reduce((e, t) => e * (1 - t.boom), 1),
						cost: .03,
						g: s,
						make: () => ({
							type: "dual",
							target: r.rid,
							wires: n.map((e) => e.wire.id),
							guesses: [s],
							mine: a.mine,
							boost: "super",
							...a.ex
						})
					});
				}
			}
		}
		return i;
	}, pe = fe(!0);
	pe.length === 0 && !y && (pe = fe(!1));
	let me = (Q(t, "nanoMove") || Q(t, "nanoCollect")) && n.mods.nano ? n.mods.nano.pos : null, he = (e) => me == null || e !== me ? 0 : Q(t, "nanoMove") ? 1 : .5;
	pe.sort((e, t) => t.p - t.cost + he(t.g) - (e.p - e.cost + he(e.g)) || (e.g === "yellow" ? 1 : e.g) - (t.g === "yellow" ? 1 : t.g));
	let N = n.dial ? n.dial.max - n.dial.step : n.mods.nano ? Math.max(0, Math.floor((12 - n.mods.nano.pos) / 2)) : 99, P = (Q(t, "intern") || Q(t, "lazyCaptain")) && e.me === n.captain, ge = !ue && A("stabilizer") && !n.stabilized && n.turn === e.me && n.forcedBy == null, _e = g || _ ? 0 : y ? .95 : or(N), ve = n.stabilized || ge, ye = Math.max(1, N), be = .1, F = Q(t, "nanoMove") ? 2 : 1, I = (e, t, n = 0, r = 0) => (ve ? 0 : Math.max(0, e - be) * 5) + (1 - t - e) * (P ? ye : F) + n - r, L = [...pe].sort((e, t) => I(e.boom, e.p, e.cost, he(e.g)) - I(t.boom, t.p, t.cost, he(t.g)) || t.p - e.p), R = L.find((e) => e.p >= _e) ?? L[0], z = L[0], xe = (e) => ge && (e.p < .75 || e.boom > be) ? {
		type: "equip",
		id: "stabilizer"
	} : e.make();
	if (n.stabilized && z) return z.make();
	if (R && (R.p >= _e || R.p >= 1)) return xe(R);
	let B = (Q(t, "constraintsByValidation") || Q(t, "constraintsPersonal")) && m >= h - 1;
	if (e.priv?.canPass && !v && !B && !_ && !g && !(R && R.p >= 1) && !b) return { type: "pass" };
	let V = P ? z : L.find((e) => e.boom < sr);
	if (!V && !ue && A("coffee") && n.turn === e.me && n.forcedBy == null) {
		let r = 0;
		for (let e = n.log.length - 1; e >= 0; e--) {
			let t = n.log[e];
			if (t.k === "equip" && t.id === "coffee") r++;
			else break;
		}
		let i = $n(e);
		outer: for (let a of o.ests) {
			if (r >= n.players.length - 1) break;
			if (a.certain != null && D(a.certain) !== 3) {
				for (let r of Xn(e)) if (r.rid !== a.owner && r.rid !== e.me && !((i.get(r.rid)?.get(a.certain) ?? 0) <= 0) && xn(n, t, r.rid, null, a.certain, !1)) {
					V = {
						p: .99,
						boom: 0,
						cost: 0,
						g: 0,
						make: () => ({
							type: "equip",
							id: "coffee",
							params: { next: r.rid }
						})
					};
					break outer;
				}
			}
		}
	}
	if (!V) {
		for (let n of x) {
			if (n === "red" || E.has(n) || !ee(n)) continue;
			let r = nr(e, t, n), i = ae(n);
			r && i && E.set(n, {
				ex: r,
				mine: i.id,
				marked: i.tokens.length > 0
			});
		}
		for (let e of [
			(e, t) => D(e) !== 3 && t.boom < sr,
			(e) => D(e) !== 3,
			() => !0
		]) {
			let t = null, n = null, r = null, i = 0, a = Infinity;
			for (let [s, c] of E) for (let l of o.ests) {
				if (!j(l, !1) || !e(s, l)) continue;
				let o = l.p.get(s) ?? 0, u = I(l.boom, o, 0, he(s));
				(u < a || u === a && o > i) && (t = l, n = s, r = c, i = o, a = u);
			}
			if (t && n && r) {
				let e = t, a = n, o = r;
				V = {
					p: i,
					boom: e.boom,
					cost: 0,
					g: a,
					make: () => ({
						type: "dual",
						target: e.owner,
						wires: [e.wire.id],
						guesses: [a],
						mine: o.mine,
						...o.ex
					})
				};
			}
			if (V) break;
		}
	}
	if (!V && b && (V = {
		p: b.combined,
		boom: 1 - b.combined,
		cost: 0,
		g: 0,
		make: b.make
	}), V ||= z, V) return xe(V);
	if (Q(t, "iberian") && !n.yellowDone) {
		let e = null, t = -1;
		for (let n of o.ests) {
			if (n.wire.tokens.some((e) => e.token.kind === "yellow" && !e.fake)) continue;
			let r = n.p.get("yellow") ?? 0, i = r * (1 - n.boom);
			r > 0 && i > t && (e = n, t = i);
		}
		if (e) return {
			type: "iberian",
			target: e.owner,
			wire: e.wire.id
		};
	}
	if (e.priv?.canPass) return { type: "pass" };
	if (i.length > 0) for (let n = 1; n <= t.blueMax; n += 1) {
		if (!te(n)) continue;
		let r = nr(e, t, n);
		if (r) return {
			type: "solo",
			value: n,
			...r
		};
	}
	return null;
}
var lr = (e, t) => {
	let n = Gn(e, t.rid), r = n.pub, i = re.get(r.mission);
	if (!i || r.phase === "done" || r.phase === "resolving") return null;
	let a = Wn(r, n.priv, i, t.rid), o = ar(n, a);
	if (o) return { action: o };
	if (r.phase === "setup") {
		if (r.setupTurn !== n.me) return null;
		let e = ir(n, i);
		return e ? { action: e } : null;
	}
	let s = Jn(n);
	if (!s) return null;
	let c = Q(i, "squeak") && r.turn === n.me;
	if (s.done && !c) return null;
	if (r.turn === null) {
		let e = r.players.some((e) => e.rid !== n.me && !e.done);
		if (Q(i, "realtime") && (r.lastActor !== n.me || r.players.length === 2 || !e)) {
			if (!t.signal) return { action: { type: "claim" } };
			let e = Kn(n), r = new Set(Yn(n).map((t) => $(e.get(t.id) ?? {
				color: "red",
				sort: 0
			}))), i = a.ests.some((e) => e.certain != null && r.has(e.certain)), o = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295, s = i ? 1200 + o * 1500 : 6e3 + o * 5e3;
			return new Promise((e) => setTimeout(() => e({ action: { type: "claim" } }), s));
		}
		return null;
	}
	if (r.mods.squeak && r.mods.squeak.claimed == null) {
		let e = Kn(n), i = Yn(n);
		if (i.some((t) => e.get(t.id)?.color === "blue" && Math.round(e.get(t.id).sort) === r.mods.squeak.value) || i.length > 0 && i.every((t) => e.get(t.id)?.color === "red")) return { action: { type: "claim" } };
		if (r.turn === n.me) {
			let e = r.mods.squeak.value, i = $n(n), o = null, s = -1;
			for (let t of r.players) {
				if (t.done || t.rid === n.me) continue;
				let r = 1 - a.ests.filter((e) => e.owner === t.rid).reduce((t, n) => t * (1 - (n.p.get(e) ?? 0)), 1);
				(i.get(t.rid)?.get(e) ?? 0) > 0 && (r = 1), r > s && (s = r, o = t.rid);
			}
			if (o) {
				if (!t.signal) return { action: {
					type: "claim",
					for: o
				} };
				let e = o, n = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
				return new Promise((t) => setTimeout(() => t({ action: {
					type: "claim",
					for: e
				} }), 2500 + n * 3e3));
			}
		}
	}
	if (r.forcedValue != null && r.forcedBy == null && r.turn === n.me && !Q(i, "squeak")) {
		let e = r.forcedValue, t = Kn(n), i = $n(n), o = null, s = -1;
		for (let c of r.players) {
			if (c.done) continue;
			let r;
			c.rid === n.me ? r = +!!Yn(n).some((n) => $(t.get(n.id) ?? {
				color: "red",
				sort: 0
			}) === e) : (r = 1 - a.ests.filter((e) => e.owner === c.rid).reduce((t, n) => t * (1 - (n.p.get(e) ?? 0)), 1), (i.get(c.rid)?.get(e) ?? 0) > 0 && (r = 1)), r > s && (s = r, o = c.rid);
		}
		return { action: {
			type: "claim",
			for: o ?? void 0
		} };
	}
	let l = r.mods.constraints;
	if (Q(i, "constraintsPersonal") && l && r.turn === n.me && n.me === r.captain) {
		let e = r.players.findIndex((e) => e.rid === r.captain), t = r.players.map((t, n) => r.players[(e + n) % r.players.length].rid), o = t.map((e) => l.perPlayer[e] ?? null), s = Kn(n), c = new Set(Yn(n).map((e) => $(s.get(e.id) ?? {
			color: "red",
			sort: 0
		}))), u = [];
		for (let e = 1; e <= i.blueMax; e += 1) u.push(e);
		let d = (e, t) => {
			if (e === n.me) return +!!c.has(t);
			let r = 1;
			for (let n of a.ests) n.owner === e && (r *= 1 - (n.p.get(t) ?? 0));
			return 1 - r;
		}, f = (e) => {
			let n = 0;
			return t.forEach((t, a) => {
				let o = {
					...r,
					mods: {
						...r.mods,
						constraints: {
							...l,
							perPlayer: {
								...l.perPlayer,
								[t]: e[a]
							}
						}
					}
				};
				for (let e of u) xn(o, i, t, null, e, !1) && (n += d(t, e));
			}), n;
		}, p = f(o), m = (e) => t.map((n, r) => o[(r - e + t.length) % t.length]), h = f(m(1)), g = f(m(-1));
		if (Math.max(h, g) > p + .5) return { action: {
			type: "rotateConstraints",
			dir: h >= g ? 1 : -1
		} };
	}
	if (r.mods.constraints?.perPlayer[n.me] && Q(i, "constraintsPersonal")) {
		let e = Kn(n);
		if (![...new Set(Yn(n).map((t) => $(e.get(t.id) ?? {
			color: "red",
			sort: 0
		})))].some((e) => e !== "red" && xn(r, i, n.me, n.priv?.secretConstraint ?? null, e, !1))) return { action: {
			type: "respond",
			kind: "swapConstraint"
		} };
	}
	if ((r.forcedBy ?? r.turn) !== n.me) return null;
	if (Q(i, "constraintsDeck") && r.turn === n.me && n.me === r.captain && (r.mods.constraints?.deckLeft ?? 0) > 0) {
		let e = Kn(n), t = [...new Set(Yn(n).map((t) => $(e.get(t.id) ?? {
			color: "red",
			sort: 0
		})))];
		if (t.some((e) => e !== "red") && !t.some((e) => e !== "red" && xn(r, i, n.me, n.priv?.secretConstraint ?? null, e, !1))) return { action: { type: "nextConstraint" } };
	}
	let u = cr(n, i);
	return u ? { action: u } : null;
}, ur = (e, t) => {
	let n = t.data?.wire;
	return (n == null ? null : e.anchor(`wire:${n}`)) ?? (t.rid ? e.anchor(`seat:${t.rid}`) : null);
}, dr = {
	deal(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ h(y, {
				at: n,
				ms: 700
			})
		} : null;
	},
	cutResult(e, t) {
		let n = e.data, r = n?.ms ?? 1200, i = (n?.wires ?? []).flatMap((e) => {
			let n = t.anchor(`wire:${e}`);
			return n ? [n] : [];
		}), a = n?.hpDelta ? t.anchor("dial") : null, o = n?.validated?.length ? t.anchor("track") : null, s = n?.equipments?.length ? t.anchor("equips") : null, c = i[0] ?? a ?? o;
		return {
			ms: r,
			node: /* @__PURE__ */ g(m, { children: [
				n?.outcome === "boom" && /* @__PURE__ */ h(_, { ms: r }),
				i.map((e, t) => /* @__PURE__ */ h(y, {
					at: e,
					ms: r
				}, t)),
				a && /* @__PURE__ */ h(y, {
					at: a,
					ms: r
				}),
				o && /* @__PURE__ */ h(y, {
					at: o,
					ms: r
				}),
				s && /* @__PURE__ */ h(y, {
					at: s,
					ms: r
				}),
				c && /* @__PURE__ */ h(v, {
					at: c,
					ms: r,
					children: n?.outcome === "boom" ? "💥" : n?.outcome === "miss" ? "⚠️" : "✂️"
				})
			] })
		};
	},
	cut(e, t) {
		let n = ur(t, e);
		if (!n) return null;
		let r = t.queued > 0 ? 300 : 700;
		return {
			ms: r,
			node: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(y, {
				at: n,
				ms: r
			}), /* @__PURE__ */ h(v, {
				at: n,
				ms: r,
				children: /* @__PURE__ */ h("span", {
					className: "text-base",
					children: "✂️"
				})
			})] })
		};
	},
	dial(e, t) {
		let n = t.anchor("dial");
		return n ? {
			ms: 800,
			node: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(y, {
				at: n,
				ms: 800
			}), /* @__PURE__ */ h(v, {
				at: n,
				ms: 800,
				children: /* @__PURE__ */ h("span", {
					className: "text-lg",
					children: "⚠️"
				})
			})] })
		} : null;
	},
	boom(e, t) {
		let n = t.anchor("dial");
		return {
			ms: 1200,
			node: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(_, { ms: 900 }), n && /* @__PURE__ */ h(v, {
				at: n,
				ms: 1200,
				children: /* @__PURE__ */ h("span", {
					className: "text-2xl",
					children: "💥"
				})
			})] })
		};
	},
	win(e, t) {
		let n = t.anchor("track");
		return {
			ms: 1400,
			node: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(_, {
				ms: 900,
				className: "bg-done-soft"
			}), n && /* @__PURE__ */ h(v, {
				at: n,
				ms: 1400,
				children: /* @__PURE__ */ h("span", {
					className: "text-2xl",
					children: "🎉"
				})
			})] })
		};
	},
	validate(e, t) {
		let n = t.anchor("track");
		return n ? {
			ms: 800,
			node: /* @__PURE__ */ h(v, {
				at: n,
				ms: 800,
				children: /* @__PURE__ */ h("span", {
					className: "text-lg",
					children: "✅"
				})
			})
		} : null;
	},
	equipIn(e, t) {
		let n = t.anchor("equips");
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ h(v, {
				at: n,
				ms: 900,
				children: /* @__PURE__ */ h("span", {
					className: "text-lg",
					children: "🔓"
				})
			})
		} : null;
	},
	challenge(e, t) {
		let n = t.anchor("track");
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ h(v, {
				at: n,
				ms: 900,
				children: /* @__PURE__ */ h("span", {
					className: "text-lg",
					children: "🏅"
				})
			})
		} : null;
	},
	nanoTake(e, t) {
		let n = ur(t, e);
		return n ? {
			ms: 800,
			node: /* @__PURE__ */ h(v, {
				at: n,
				ms: 800,
				children: /* @__PURE__ */ h("span", {
					className: "text-base",
					children: "🤖"
				})
			})
		} : null;
	},
	swap(e, t) {
		let n = e.data, r = n?.a == null ? null : t.anchor(`wire:${n.a}`), i = n?.b == null ? null : t.anchor(`wire:${n.b}`);
		return !r && !i ? null : {
			ms: 700,
			node: /* @__PURE__ */ g(m, { children: [r && /* @__PURE__ */ h(y, {
				at: r,
				ms: 700
			}), i && /* @__PURE__ */ h(y, {
				at: i,
				ms: 700
			})] })
		};
	},
	grapple(e, t) {
		let n = ur(t, e);
		return n ? {
			ms: 800,
			node: /* @__PURE__ */ h(v, {
				at: n,
				ms: 800,
				children: /* @__PURE__ */ h("span", {
					className: "text-base",
					children: "🪝"
				})
			})
		} : null;
	}
}, fr = {
	red: "games.bombbusters.overBoomRed",
	dial: "games.bombbusters.overBoomDial",
	nano: "games.bombbusters.overBoomNano",
	mass: "games.bombbusters.overBoomMass",
	accuse: "games.bombbusters.overBoomAccuse",
	timeout: "games.bombbusters.overBoomTimeout",
	constrain: "games.bombbusters.overBoomConstrain",
	lazy: "games.bombbusters.overBoomLazy"
};
function pr({ public: e, members: t, onPlayAgain: n, onPlayAgainWithConfig: r, onBackToLobby: i }) {
	let a = l(), o = e, s = o.result?.win === !0, c = s ? ne.find((e) => e.id > o.mission && !E.has(e.id) && (e.minPlayers ?? 0) <= t.length) : void 0, u = o.result ? fr[o.result.reason] : void 0, d = r ?? n ?? i;
	return /* @__PURE__ */ g("main", {
		className: `bb-over ${s ? "bb-over--win" : "bb-over--lose"}`,
		children: [
			s && /* @__PURE__ */ h(b, {}),
			/* @__PURE__ */ g("div", {
				className: "bb-over__header",
				children: [/* @__PURE__ */ h("span", {
					className: "bb-over__mission",
					children: a("games.bombbusters.missionN", { n: o.mission })
				}), /* @__PURE__ */ h("span", {
					className: "bb-over__mission-name",
					children: a(`games.bombbusters.m${o.mission}name`)
				})]
			}),
			/* @__PURE__ */ g("div", {
				className: "bb-over__content",
				children: [/* @__PURE__ */ g("div", {
					className: "bb-over__scene",
					role: "status",
					"aria-live": "polite",
					children: [
						/* @__PURE__ */ h("div", {
							className: "bb-over__emblem",
							"aria-hidden": "true",
							children: s ? "✓" : "!"
						}),
						/* @__PURE__ */ g("div", {
							className: "bb-over__wire",
							"aria-hidden": "true",
							children: [
								/* @__PURE__ */ h("i", {}),
								/* @__PURE__ */ h("i", {}),
								/* @__PURE__ */ h("i", {})
							]
						}),
						/* @__PURE__ */ h("h1", {
							className: "bb-over__title",
							children: a(s ? "games.bombbusters.overWin" : "games.bombbusters.overLose")
						}),
						s ? /* @__PURE__ */ h("p", {
							className: "bb-over__detail",
							children: a("games.bombbusters.overSafe")
						}) : /* @__PURE__ */ h("p", {
							className: "bb-over__detail",
							children: a(u || "games.bombbusters.overBoomOther")
						})
					]
				}), d ? /* @__PURE__ */ g("div", {
					className: "bb-over__actions safe-b",
					children: [
						s && c && r && /* @__PURE__ */ h("button", {
							type: "button",
							className: "bb-over__primary",
							style: { backgroundColor: x.accent },
							onClick: () => r({ mission: c.id }),
							children: a("games.bombbusters.overNextMission", { n: c.id })
						}),
						!s && (r || n) && /* @__PURE__ */ h("button", {
							type: "button",
							className: "bb-over__primary",
							style: { backgroundColor: x.accent },
							onClick: () => r ? r({}) : n?.(),
							children: a("games.bombbusters.overRetry")
						}),
						i && /* @__PURE__ */ h("button", {
							type: "button",
							className: "bb-over__secondary",
							onClick: i,
							children: a("session.result.backToLobby")
						})
					]
				}) : /* @__PURE__ */ h("p", {
					className: "bb-over__waiting safe-b",
					children: a("session.result.waitHost")
				})]
			})
		]
	});
}
//#endregion
//#region src/games/bombbusters/options.tsx
var mr = [
	{
		key: "games.bombbusters.missionBox1",
		range: [1, 8]
	},
	{
		key: "games.bombbusters.missionBox2",
		range: [9, 19]
	},
	{
		key: "games.bombbusters.missionBox3",
		range: [20, 30]
	},
	{
		key: "games.bombbusters.missionBox4",
		range: [31, 42]
	},
	{
		key: "games.bombbusters.missionBox5",
		range: [43, 54]
	},
	{
		key: "games.bombbusters.missionBox6",
		range: [55, 66]
	}
], hr = {
	classic: {
		name: "games.bombbusters.chClassic",
		hint: "games.bombbusters.chClassicHint"
	},
	mixed: {
		name: "games.bombbusters.chMixed",
		hint: "games.bombbusters.chMixedHint"
	}
}, gr = {
	open: {
		name: "games.bombbusters.mkOpen",
		hint: "games.bombbusters.mkOpenHint"
	},
	hidden: {
		name: "games.bombbusters.mkHidden",
		hint: "games.bombbusters.mkHiddenHint"
	}
};
function _r({ value: e, onChange: t }) {
	let n = l(), r = de.safeParse(e), a = r.success ? r.data : de.parse(void 0), [o, s] = i(() => Math.max(0, mr.findIndex((e) => a.mission >= e.range[0] && a.mission <= e.range[1]))), c = (e) => t({
		...a,
		...e
	}), u = mr[o];
	return /* @__PURE__ */ g("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ g("section", { children: [
				/* @__PURE__ */ h("h3", {
					className: "section-label mb-2",
					children: n("games.bombbusters.optMission")
				}),
				/* @__PURE__ */ h("div", {
					className: "-mx-4 flex gap-1.5 overflow-x-auto px-4 pb-2",
					children: mr.map((e, t) => /* @__PURE__ */ g("button", {
						type: "button",
						"aria-pressed": o === t,
						onClick: () => s(t),
						className: "min-h-11 flex-none rounded-lg border-2 border-ink/35 bg-surface px-2 text-xs font-bold",
						style: o === t ? { borderColor: x.accent } : void 0,
						children: [n(e.key), a.mission >= e.range[0] && a.mission <= e.range[1] ? " ✓" : ""]
					}, e.key))
				}),
				/* @__PURE__ */ h("div", {
					role: "group",
					"aria-label": n(u.key),
					className: "grid grid-cols-3 gap-1.5",
					children: ne.filter((e) => e.id >= u.range[0] && e.id <= u.range[1]).map((e) => {
						let t = E.has(e.id);
						return /* @__PURE__ */ h(ee, {
							name: "bombbusters-mission",
							value: String(e.id),
							checked: a.mission === e.id,
							disabled: t,
							accent: x.accent,
							label: n("games.bombbusters.missionN", { n: e.id }),
							hint: n(`games.bombbusters.m${e.id}name`),
							title: t ? n("games.bombbusters.missionUnavailable") : e.minPlayers ? n("games.bombbusters.missionNeed3") : n(`games.bombbusters.m${e.id}brief`),
							onChange: () => c({ mission: e.id })
						}, e.id);
					})
				})
			] }),
			/* @__PURE__ */ h(te, {
				title: n("games.bombbusters.optCharacters"),
				children: ["classic", "mixed"].map((e) => /* @__PURE__ */ h(ee, {
					name: "bombbusters-characters",
					value: e,
					checked: a.characters === e,
					accent: x.accent,
					label: n(hr[e].name),
					hint: n(hr[e].hint),
					onChange: () => c({ characters: e })
				}, e))
			}),
			/* @__PURE__ */ h(te, {
				title: n("games.bombbusters.optMarkers"),
				children: ["open", "hidden"].map((e) => /* @__PURE__ */ h(ee, {
					name: "bombbusters-markers",
					value: e,
					checked: a.markers === e,
					accent: x.accent,
					label: n(gr[e].name),
					hint: n(gr[e].hint),
					onChange: () => c({ markers: e })
				}, e))
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/bombbusters/entry.tsx
var vr = {
	definition: zt,
	View: On,
	bot: lr,
	fx: dr,
	OverView: pr,
	Options: _r,
	locales: {
		zh: {
			name: "炸弹克星",
			desc: "合作拆弹:报编号指认队友的导线,剪错蓝黄导线起爆器逼近骷髅,剪到红色导线当场爆炸",
			rules: "目标:全队合作,在起爆器走到骷髅前剪完全部蓝色导线与黄色导线;剪到红色导线或起爆器到底,炸弹爆炸。\n准备:\n· 蓝色导线 1-12 各 4 根,红色黄色导线按任务牌数量随机混入;各自升序放上板块底座,只看得见自己的导线。\n· 任务 3 起抽人数张装备牌:某编号剪出 2 根后解锁,每张限用一次。\n· 从队长开始,每人放 1 个信息指示物在自己一根蓝色导线前方。\n流程:\n· 轮到你时三选一:双人剪线、单人剪线、展示红色导线。\n· 双人剪线:报一个编号(1-12 或「黄」),指定队友一根导线。\n· 猜对:两根导线各翻明剪出;猜错:起爆器前进一格,队友在导线前方放真实编号的信息指示物;指到红色导线立刻爆炸。\n· 单人剪线:某编号剩余未剪的导线全在你手里(2 或 4 根),可独自全部剪出;黄色导线须握有全部在局的黄色导线。\n· 展示红色导线:未剪的导线全是红色时全部亮出,你完工。\n· 某编号 4 根全剪出,数字轨放验证指示物。\n· 每人有 1 次个人装备「双重探测器」:双人剪线可指定队友 2 根导线,任一命中即成功。\n任务:66 个任务各有不同特殊规则(顺序牌、限制牌、氧气、纳米机器人等),开局前在任务列表查看。\n结束:\n· 所有人板块底座清空:任务成功。\n· 剪到红色导线或起爆器走到骷髅:爆炸,任务失败。",
			turnYou: "轮到你:点自己的导线开始剪线",
			turnWait: "等 {{name}} 行动…",
			setupTokenYou: "轮到你:选一根自己的蓝色导线放信息指示物",
			setupTokenWait: "等 {{name}} 放开局指示物…",
			actDual: "双人剪线",
			cutTarget: "{{name}} · 第 {{positions}} 根导线",
			actSolo: "单人剪线",
			cutStartHint: "点自己板块底座上的导线开始剪线",
			actReveal: "展示红色导线",
			actPass: "跳过",
			actMass: "特殊行动",
			actIberian: "指认拌线",
			actAccuse: "指控",
			actClaim: "我剪!",
			actSqueak: "我剪!",
			actEquip: "用装备",
			actPersonal: "个人装备",
			valuePickOne: "选一个编号",
			valuePickTwo: "报两个编号,任一命中即成功",
			valuePickSecond: "报第二个编号,任一命中即成功",
			valuePickBlind: "导线编号不可见,盲报一个编号",
			iberianHint: "点队友的一根导线,宣布它是拌线",
			guessYellow: "黄",
			confirm: "确定",
			cancel: "取消",
			dialLeft: "还能失败 {{n}} 次",
			dialDanger: "下一格就是骷髅!",
			validatedTrack: "已集齐",
			myRack: "我的板块底座",
			rackOf: "{{name}} 的板块底座",
			missionInfo: "任务情报",
			missionDetails: "查看任务情报",
			rackPicker: "放大选导线",
			playerDone: "已完工",
			captainBadge: "队长",
			equipLocked: "未解锁",
			equipUsed: "已用",
			equipReady: "可用",
			equipSheetTitle: "装备柜",
			equipSheetSubtitle: "MISSION LOADOUT",
			equipSheetAvailable: "{{n}} 可用",
			equipSectionPersonal: "个人装备",
			equipSectionPublic: "公共装备",
			equipSheetOnce: "角色专属 · 每局一次",
			equipUse: "使用",
			equipSheetUsed: "已使用",
			equipNeedCut: "剪 2 根「{{v}}」",
			equipNeedReveal: "角色牌未亮出",
			optMission: "任务",
			optCharacters: "角色牌",
			chClassic: "经典",
			chClassicHint: "全员双重探测器",
			chMixed: "混编",
			chMixedHint: "随机替换扩展角色",
			optMarkers: "红/黄线数字提示",
			mkOpen: "标出编号",
			mkOpenHint: "数字轨标出红/黄线的编号(官方规则)",
			mkHidden: "隐藏编号",
			mkHiddenHint: "数字轨不标红/黄线编号,难度更高",
			missionBox1: "基础盒",
			missionBox2: "惊喜盒 9-19",
			missionBox3: "惊喜盒 20-30",
			missionBox4: "惊喜盒 31-42",
			missionBox5: "惊喜盒 43-54",
			missionBox6: "惊喜盒 55-66",
			missionUnavailable: "音频任务,待后续版本",
			missionNeed3: "至少 3 人",
			overWin: "拆弹成功!",
			overLose: "任务失败",
			overSafe: "全队安全撤离",
			overRetry: "重试本任务",
			overNextMission: "下一个任务 · {{n}}",
			overBoomOther: "炸弹爆炸…",
			overBoomLazy: "懒队长剪线失败,炸弹爆炸…",
			overBoomRed: "剪到红色导线,炸弹爆炸…",
			overBoomDial: "起爆器走到骷髅,炸弹爆炸…",
			overBoomNano: "纳米越过终点,炸弹爆炸…",
			overBoomMass: "特殊行动失败,炸弹爆炸…",
			overBoomAccuse: "最弱的一环走投无路,炸弹爆炸…",
			overBoomTimeout: "时间耗尽,炸弹爆炸…",
			overBoomConstrain: "整轮无人能动,炸弹爆炸…",
			pendFailToken: "{{name}} 选择在哪根导线前方放信息指示物",
			pendFailTokenYou: "点选一根导线,在它前方放信息指示物",
			pendPickCut: "两线都命中:选一根剪出",
			pendFakeToken: "{{name}} 放一个假指示物",
			pendPickToken: "{{name}} 挑选一个指示物",
			pendPassToken: "{{name}} 选一个指示物传给左邻",
			pendGiveCard: "{{name}} 把一张数字牌交给队友",
			pendChooseConstraint: "{{name}} 选择一张限制牌",
			pendPlaceCard: "{{name}} 扣放一张数字牌",
			pendMoveSequence: "{{name}} 移动顺序牌",
			pendTalkiesPick: "{{name}} 选一根自己的未剪导线换给对方",
			pendTalkiesPickYou: "对讲机:点选一根你的未剪导线交给对方",
			constraintNow: "当前限制",
			challengeDone: "挑战达成!",
			oxygenLeft: "氧气",
			nanoAt: "纳米在 {{n}}",
			timerLeft: "剩余 {{time}}",
			logDualOk: "{{from}} 与 {{to}} 各剪断一根「{{guess}}」",
			logDualFail: "{{from}} 指 {{to}} 的导线报「{{guess}}」,猜错",
			logSolo: "{{name}} 独自剪出 {{n}} 根「{{value}}」",
			logReveal: "{{name}} 亮出全部红色导线({{n}} 根),完工",
			logEquip: "{{name}} 使用「{{equip}}」",
			logValidate: "「{{value}}」4 根集齐,放验证指示物",
			logPass: "{{name}} 跳过",
			logClaim: "{{name}} 抢下行动权",
			logMassOk: "{{name}} 同时指认 {{n}} 根导线,全部命中",
			logMassFail: "{{name}} 的指认失败",
			logIberianOk: "{{from}} 指认 {{to}} 的拌线,命中",
			logIberianFail: "{{from}} 指认 {{to}} 的导线,不是拌线",
			beatActorTarget: "{{actor}} 指向 {{target}} 的板块底座",
			beatActor: "{{actor}} 发起剪线",
			beatCalled: "报「{{value}}」",
			beatSuccess: "剪线成功",
			beatMiss: "指认失败",
			beatBoom: "炸弹引爆",
			beatCutCount: "剪断 {{n}} 根",
			beatHpLoss: "HP −{{n}}",
			beatHpGain: "HP +{{n}}",
			beatValidated: "验证 {{value}}",
			beatEquipment: "装备变化",
			historyButton: "记录",
			historyOpen: "查看对局记录",
			historyTitle: "对局记录",
			historyKindDual: "双人剪线",
			historyKindSolo: "单人剪线",
			historyKindMass: "特殊行动",
			historyKindIberian: "拌线指认",
			historyKindReveal: "展示红色导线",
			historyKindEquip: "装备剪线",
			historyEmpty: "还没有对局记录",
			historyPosition: "第 {{rack}} 排 · 第 {{position}} 根",
			historyNano: "纳米的导线",
			historyCutValue: "剪出「{{value}}」",
			historyUncut: "被指，未剪",
			historyEquipment: "装备变化：{{names}}",
			historyBriefSuccess: "剪断 {{n}} 根",
			historyBriefMiss: "指错",
			historyBriefBoom: "引爆",
			cutSum: "剪{{who}}的{{value}}",
			cutSumSelf: "自己",
			logAccuseOk: "{{from}} 指控 {{to}} 成立,最弱的一环现形",
			logAccuseFail: "{{from}} 指控 {{to}} 失败",
			errDone: "本局已结束",
			errNotYourTurn: "还没轮到你",
			errPending: "先完成当前的待办",
			errBadTarget: "不能指自己",
			errBadWire: "目标导线不存在或已剪断",
			errBadGuess: "这个报值不合法",
			errNoMatch: "你手里没有这个编号的未剪导线",
			errNoSolo: "该编号剩余未剪的导线不全在你手里",
			errNotAllRed: "只剩红色导线时才能展示",
			errConstraint: "限制牌不允许这么做",
			errEquipLocked: "装备还没解锁",
			errEquipUsed: "装备已用过",
			errNoEquip: "这张装备不在场上",
			errNoPersonal: "个人装备不可用",
			errNoPass: "现在不能跳过",
			errOxygen: "氧气不够",
			errSequence: "顺序牌还没到这一编号",
			errMath: "需要用两张数字牌加减得出要剪的编号",
			errXwire: "X 导线现在不能剪",
			errCursed: "这是被诅咒的编号",
			errNano: "纳米不在那里",
			errHandCard: "你手上没有这张数字牌",
			errSetupToken: "这根导线不能放这个指示物",
			errClaim: "同一个人不能连续行动",
			errSqueak: "现在不能抢答",
			errMassCount: "指认数量不对",
			errMassValue: "这些导线不是任务要求的编号",
			errAccuse: "现在不能指控",
			errPhase: "现在处于开局标记阶段",
			errCharacter: "这个角色不可用",
			eqNeq: "标签 ≠",
			eqNeqDesc: "将 ≠ 指示物放在自己两根编号不同的相邻导线前方;其中可以有一根已剪断的导线。注意:2 根黄色导线或 2 根红色导线始终视为相同,不算作「编号不同」",
			eqTalkies: "对讲机",
			eqTalkiesDesc: "与一名队友交换导线:双方各取出一根未剪断的导线,正面朝下交给对方,再各自放上自己的板块底座;可以交换红色和黄色导线",
			eqTriple: "三重探测器",
			eqTripleDesc: "双人剪线时报一个编号(不能是「黄」),指定一名队友板块底座上的 3 根导线,任一命中即成功",
			eqPostit: "便利贴",
			eqPostitDesc: "将一个信息指示物放在自己的 1 根蓝色导线前方",
			eqSuper: "超级探测器",
			eqSuperDesc: "双人剪线时报一个编号(不能是「黄」),指定一名队友的整个板块底座,任一命中即成功",
			eqRewinder: "抑制器",
			eqRewinderDesc: "使起爆器倒退一格",
			eqBatteries: "备用电池",
			eqBatteriesDesc: "将一至两张使用过的角色牌翻回正面,这些角色的个人装备可以在本次任务中再次使用",
			eqRadar: "通用雷达",
			eqRadarDesc: "说出一个 1 到 12 的编号,所有拆弹专家(包括自己)板块底座上有该编号未剪断蓝色导线的回答「有」",
			eqStabilizer: "稳定剂",
			eqStabilizerDesc: "双人剪线行动开始前使用:本回合起爆器不会移动(即使行动失败),炸弹不会爆炸(即使剪到红色导线);猜错时队友仍须照常放信息指示物",
			eqXyray: "X/Y 射线",
			eqXyrayDesc: "双人剪线时指定 1 根导线并说出两个编号(可以是「黄」),命中其一即成功;两个编号都必须在自己手中",
			eqCoffee: "咖啡瓶",
			eqCoffeeDesc: "跳过你的回合,并任选一位玩家成为下一个进行回合的拆弹专家(不能商议),之后从其顺时针继续",
			eqEq: "标签 =",
			eqEqDesc: "将 = 指示物放在自己两根编号相同的相邻导线前方;其中可以有一根已剪断的导线",
			eqFund: "应急箱",
			eqFundDesc: "立刻翻面所有已使用的装备牌,本次任务中可以再次使用它们",
			eqDisintegrator: "分解器",
			eqDisintegratorDesc: "随机拿取一个信息指示物(1 至 12):所有拆弹专家剪断自己此编号的全部剩余导线",
			eqSingleLabel: "单线标签",
			eqSingleLabelDesc: "在自己的一根蓝色导线(可已剪断)前方放一个 ×1 指示物,表示该编号在此板块底座只出现一次",
			eqThreadCutter: "快速通行证",
			eqThreadCutterDesc: "单人剪线行动中剪断 2 根相同编号的导线,即使它们不是该编号仅存的导线",
			eqGrapple: "钩索",
			eqGrappleDesc: "指向队友的一根导线,在不展示的情况下拿取它,放到自己的板块底座上;所有人都能看到拿取和插入的位置",
			eqDoubleFond: "双层底",
			eqDoubleFondDesc: "拿出 2 张装备牌加入本局;如果其对应编号的导线已被剪断 2 根,则立刻可用",
			charDd2000: "双重探测器",
			charDd2000Desc: "双人剪线时报一个编号,指定队友的 2 根导线,任一命中即成功;每局限用一次",
			charXyray: "X/Y 射线员",
			charXyrayDesc: "个人装备同「X/Y 射线」,每局限用一次",
			charRadar: "雷达员",
			charRadarDesc: "个人装备同「通用雷达」,每局限用一次",
			charTalkies: "通讯兵",
			charTalkiesDesc: "个人装备同「对讲机」,每局限用一次",
			charTriple: "三重探测器 3000",
			charTripleDesc: "个人装备同「三重探测器」,每局限用一次",
			eqNeqShort: "相邻两根不同编号导线放 ≠ 标记;一根可已剪,同色红线或黄线视为相同。",
			eqTalkiesShort: "与队友各交换一根未剪导线;红线和黄线也能交换。",
			eqTripleShort: "报一个非黄编号,指队友 3 根线;任一命中即成功。",
			eqPostitShort: "给自己一根蓝线放信息标记。",
			eqSuperShort: "报一个非黄编号,指队友整排线;任一命中即成功。",
			eqRewinderShort: "让起爆器倒退一格。",
			eqBatteriesShort: "翻回 1–2 张已用角色牌,个人装备可再次使用。",
			eqRadarShort: "报 1–12 的编号;所有人回答自己有无该值未剪蓝线。",
			eqStabilizerShort: "本回合双人剪线失败不推进起爆器,剪红线也不爆炸;猜错仍放信息标记。",
			eqXyrayShort: "报手中两个编号(可含黄),指队友一根线;任一命中即成功。",
			eqCoffeeShort: "跳过自己回合,指定下位行动者;此后按顺时针继续。",
			eqEqShort: "给自己相邻同编号的两根线放 = 标记;一根可已剪。",
			eqFundShort: "翻回全部已用装备牌,本任务可再次使用。",
			eqDisintegratorShort: "随机抽一个编号;所有人剪掉自己剩余的该值导线。",
			eqSingleLabelShort: "给自己一根蓝线放 ×1 标记,表示此排仅有这根该值导线。",
			eqThreadCutterShort: "单人剪任意两根同编号导线,即使不是该值最后两根。",
			eqGrappleShort: "不展示编号,取队友一根线放进自己的牌架;位置公开。",
			eqDoubleFondShort: "加入 2 张装备牌;若对应值已剪 2 根,立即可用。",
			charDd2000Short: "报一个编号,指队友两根线;任一命中成功。每局一次。",
			charXyrayShort: "报手中两个编号指一根线;任一命中成功。每局一次。",
			charRadarShort: "报一个编号,让所有人回答有无该值蓝线。每局一次。",
			charTalkiesShort: "与队友各交换一根未剪导线。每局一次。",
			charTripleShort: "报非黄编号,指队友三根线;任一命中成功。每局一次。",
			cA: "只能剪偶数编号的导线",
			cB: "只能剪奇数编号的导线",
			cC: "只能剪 1 至 6 号导线",
			cD: "只能剪 7 至 12 号导线",
			cE: "只能剪 4 至 9 号导线",
			cF: "禁止剪 4 至 9 号导线",
			cG: "禁止使用装备牌和个人装备",
			cH: "剪线失败不放信息指示物;不能剪被指示物标记编号的导线;便利贴不可用",
			cI: "不能剪队友板块底座上最右端的导线",
			cJ: "不能剪队友板块底座上最左端的导线",
			cK: "不能执行单人剪线行动",
			cL: "剪线失败时起爆器前进 2 格",
			ch1: "指认队友的一根导线是红色并剪断它;不是红色就爆炸",
			ch2: "连续 4 名拆弹专家剪断偶数编号的导线",
			ch3: "板块底座上未剪断的导线两两成组(被已剪断的导线隔开)",
			ch4: "前 3 个验证指示物的编号之和等于 18",
			ch5: "连续 2 名拆弹专家执行单人剪线行动",
			ch6: "板块底座上至少有 5 根孤立的导线(相邻导线都已被剪断)",
			ch7: "连续 3 名拆弹专家剪断连续编号(递增或递减)的导线",
			ch8: "前 2 个验证指示物放在指定的编号上",
			ch9: "板块底座上只剩奇数编号的导线未剪断(至少 6 根,红黄导线不计)",
			ch10: "板块底座上至少 7 根导线被剪断,且两端各 2 根未被剪断",
			tokOdd: "奇",
			tokEven: "偶",
			wireBack: "未剪断的导线",
			wireRed: "红",
			wireBlue: "蓝",
			missionN: "任务 {{n}}",
			pickCover: "先扣置一张数字牌",
			pickMath: "选两张数字牌,加减得出报值",
			payToHint: "点队友面板交氧气",
			giveCardHint: "选一张数字牌,再点队友的面板",
			forcedOnly: "本回合只能剪「{{value}}」",
			pickActor: "指定一名玩家行动",
			accuseHint: "点一名玩家的面板,再说对他的限制",
			endLeft: "放最左",
			endRight: "放最右",
			youAreWeak: "你是最弱的一环,暗守限制",
			nanoCarry: "携带 {{n}} 根导线",
			myNumCards: "我的数字牌",
			infoNone: "无附加规则",
			infoBlueRange: "蓝线只有 1-{{max}} 号",
			cursedAsRed: "视同红线,剪到即爆",
			infoSequence: "按顺序剪",
			infoNumCards: "数字牌",
			infoNumDeckLeft: "还剩 {{n}} 张",
			infoDeckEquipPre: "剪断",
			infoDeckEquipPost: "可获得一件装备",
			infoDeckTargetPre: "本轮剪",
			infoDeckSqueakPre: "翻出",
			infoDeckSqueakPost: "后抢答",
			infoDeckBossPre: "头目翻开",
			infoDeckPile: "数字牌叠",
			infoNumVisibleTick: "每回合扣 1 张",
			infoNumVisibleMath: "可加减组合报值",
			infoNumVisibleByValid: "验证后附加限制",
			infoMassCut: "特殊行动 · 同时剪 4 根",
			infoNanoTrack: "纳米队列",
			infoHandLimit: "只能报这些值",
			oxygenPoolLeft: "氧气池剩 {{n}}",
			constraintLine: "限制 {{id}} · {{text}}",
			constraintMine: "我的限制 {{id}} · {{text}}",
			constraintWho: "{{name}} · 限制 {{id}} · {{text}}",
			constraintSide: "备选限制 {{id}} · {{text}}",
			constraintBadge: "限制{{id}}",
			weakLinkLine: "薄弱环节 · {{text}}",
			challengeLine: "挑战 {{id}} · {{text}}",
			infoBonusPre: "剪完",
			infoBonusPost: "起爆器退 1 格",
			squeakOpen: "翻开「{{value}}」——抢答!",
			squeakOpenCaptain: "翻开「{{value}}」——抢答!无人抢就点座位指定",
			setupAbsent: "选一个你手中没有的编号",
			setupFake: "选一个不等于导线编号的数(假指示物)",
			logRadar: "{{name}} 雷达扫描「{{value}}」:{{yes}}",
			logRadarNoOne: "无人持有",
			radarBeatTitle: "雷达扫描「{{value}}」",
			equipUnlock: "剪 2 根「{{v}}」解锁",
			m1name: "训练:第一天",
			m1brief: "第 1 课:如何剪断导线?\n本任务只使用编号 1 到 6 的蓝色导线,不使用装备牌。\n任务规则:在各自的回合中,玩家必须通过以下方式剪断导线——\n· 双人剪线:剪断 2 根相同编号的导线,其中 1 根是自己的,1 根是队友的。指定一根队友的导线,然后猜测它的编号,例如「这根导线是 9」。猜对则行动成功,两根导线一起剪出;猜错则行动失败:起爆器前进一格(到达骷髅图标时引爆炸弹,任务失败),队友将一个信息指示物放在被指定的导线前方,显示其实际编号。注意:当前回合的玩家不能展示自己手中想要剪断的导线。\n· 单人剪线:剪断自己手中同一编号的所有剩余导线——可以剪断全部 4 根,或剪断剩余的 2 根(前提是另外 2 根已经被剪断)。",
			m2name: "训练:第二天",
			m2brief: "第 2 课:剪断黄色导线\n本任务只使用编号 1 到 8 的蓝色导线;黄色导线从编号 1.1 到 7.1 中抽取;不使用装备牌;游戏设置阶段禁止使用「黄色」信息指示物。\n· 新配件:黄色导线!剪断方式与蓝色导线相同(双人剪线和单人剪线);所有黄色导线都视为编号相同。\n· 要剪断黄色导线,当前回合的拆弹专家手中必须至少有一根黄色导线,并在指定队友的导线时声明「这根导线是黄色」。\n· 注意:被猜错的导线是黄色导线时,使用「黄色」信息指示物。",
			m3name: "训练:第三天",
			m3brief: "第 3 课:(请勿)剪断红色导线\n本任务只使用编号 1 到 10 的蓝色导线;红色导线从编号 1.5 到 9.5 中抽取。从本次任务开始:随机抽取与玩家数量相同的装备牌;如果抽到了 11 号装备(咖啡瓶)或 12 号装备(标签 =),请换一个装备。\n· 新配件:红色导线。剪断红色导线会有什么后果?炸弹立刻爆炸,任务失败!\n· 新行动——展示红色导线:回合开始时,如果一位拆弹专家手中只剩下红色导线,就必须展示它们。此拆弹专家不能继续拆除炸弹,但队友们可以继续游戏。这是在不引爆炸弹的情况下展示红色导线的唯一方法。\n· 新配件:装备牌。游戏开始时无法使用;剪断对应编号的 2 根导线后才能使用;每张装备只能使用一次。",
			m4name: "训练:实地练习第一天",
			m4brief: "是时候把理论付诸实践了!从现在开始,任务会一直用到所有蓝色导线。\n本任务涵盖了你已学会的所有内容:剪断对应编号的 2 根导线后即可使用装备;2 根黄色导线需要同时剪断;1 根红色导线在任务期间不能剪断,只能在手中仅剩红色导线时展示。\n2 名玩家:红色导线 ×1,黄色导线 ×4。",
			m5name: "训练:实地练习第二天",
			m5brief: "这不是「黄砖路」,是雷区……\n新规则「三选二」:拿出 3 根黄色导线,将 3 个棋子在版图相应空格中问号面朝上放置;洗匀后将其中 2 根正面朝下混入蓝色导线,第 3 根放在一边,不要露出编号。2 根黄色导线需要同时剪断,但有三种可能的编号。\n2 名玩家:红色导线 ×2,黄色导线 ×2(三选二)。",
			m6name: "训练:实地练习第三天",
			m6brief: "什么东西黄黄的在等着你?原来是 4 根需要及时剪断的黄色导线啊!\n新规则:4 根黄色导线视为编号相同,剪断方式与相同编号的 4 根导线一样——通常通过双人剪线一次剪断 2 根;如果有玩家持有游戏中的所有剩余黄色导线,可以通过单人剪线一次剪断全部 4 根或仅剩的 2 根。\n2 名玩家:红色导线 ×2,黄色导线 ×4。",
			m7name: "训练:练习结课日",
			m7brief: "有一根好的红色导线和一根坏的红色导线……\n新规则「二选一」:拿出 2 根红色导线,将 2 个棋子在版图对应空格中问号面朝上放置;洗匀后将其中 1 根正面朝下混入蓝色导线,另一根放在一边,不要露出编号。游戏中只有一根红色导线,但它有两种可能的编号。\n2 名玩家:红色导线 ×1(三选一)。",
			m8name: "最终测试",
			m8brief: "这一天终于到了!准备好通过拆弹测试了吗?\n无特殊规则:学以致用,完成任务。\n2 名玩家:红色导线 ×1(三选一),黄色导线 ×4。",
			m9name: "轻重缓急",
			m9brief: "可怕的疯狂科学家在炸弹上做了手脚:必须按顺序剪断某些导线。保持冷静,别乱了阵脚!\n游戏设置:洗匀数字牌,抽出 3 张正面朝上并排放在桌上,把顺序牌(A 面朝上)放在最左侧的数字牌上方。\n任务规则:至少剪断 2 根 a 导线后才能剪断 b 和 c 数字的导线;至少剪断 2 根 b 导线后才能剪断 c 数字的导线;其他编号的导线可以随时剪断。剪断 2 根 a 导线后,将 a 卡牌翻面,把顺序牌移至 b 卡牌上方,之后对 b 重复相同流程。\n2 名玩家:红色导线 ×2,黄色导线 ×4。\n(汉化卡背面误印为「全部 4 根」,此处按顺序牌 A 面与英文原版的正确规则「2 根」呈现。)",
			m10name: "困境",
			m10brief: "有些导线需要解开,但同事间的关系也是剪不断理还乱。保持团队精神,面包会有的,导线也会有的!\n游戏设置:准备 1 个 15 分钟的计时器;抽到装备 11(咖啡瓶)请替换成其他装备。\n任务规则:游戏设置阶段结束后立刻开始倒计时,必须在计时结束前拆除炸弹。本次任务不必按顺时针顺序进行:只要某位拆弹专家说出「我剪!」,就可以成为当前回合玩家。注意:等到当前回合玩家的回合结束再说「我剪!」沉住气,大家都在同一条船上!同一人不能连续进行多个回合,除非只有 2 位拆弹专家。\n2 名玩家:倒计时 12 分钟。",
			m11name: "又蓝又红,这可如何是好",
			m11brief: "「队长,我有阅读障碍,还是色盲!」\n游戏设置:随机抽一张数字牌,正面朝上放在任务牌旁;如果数字与版图上的装备牌重复,换一张数字牌。\n任务规则:与数字牌同编号的 4 根导线被视为与红色导线相同——剪断此编号的导线将引爆炸弹,任务失败;手中只剩下此编号的导线时,才能在自己的回合将其展示。\n2 名玩家:黄色导线 ×4;队长不能在游戏设置阶段放置信息指示物。",
			m12name: "失踪的装备",
			m12brief: "「都急个锤子,哥们只活这一辈子!」……说到锤子,谁看见工具箱了?\n游戏设置:在每张装备牌上放一张正面朝上的数字牌(把装备编号露在外面)。\n任务规则:必须剪断数字牌对应的 2 根导线,才能使用被压住的装备(仍须剪断装备自身对应的导线)。使用装备牌「双层底」时,2 张新装备牌也需各放 1 张数字牌;若某张数字牌对应的 2 根导线已被剪断,可立刻移除那张数字牌。\n2 名玩家:红色导线 ×2,黄色导线 ×4。",
			m13name: "红色警报!",
			m13brief: "疯狂科学家气疯了!他满眼血红,气得把 3 根红色导线塞进了这颗自制炸弹。\n游戏设置:3 根红色导线不与其他导线混在一起,正面朝下从队长开始顺时针发放(只有两位拆弹专家时,队长拿到 2 根,每个板块底座各放 1 根),随后发放蓝色导线。各玩家不能选择信息指示物,改为随机抽取一个放在自己手牌前方的相应位置;没有对应编号就放在手牌旁边;抽到「黄色」指示物请换一个。\n任务规则——本次任务的特殊行动:同时剪断 3 根红色导线。拆弹专家必须在尚未剪断的导线中指定 3 根红色导线;如果有导线不是红色,炸弹就会爆炸。有 4 或 5 名拆弹专家时,手中没有红色导线的拆弹专家也可以执行此行动。注意:手中只有红色导线时,必须执行此行动。\n2 名玩家:队长不能在游戏设置阶段放置信息指示物。",
			m14name: "高危拆弹专家",
			m14brief: "千里之堤,溃于蚁穴。注意菜鸟!\n游戏设置:正面朝下洗匀角色牌,给每位玩家发一张并展示;拿到队长牌的玩家在本次任务中称为「菜鸟」。\n任务规则:如果菜鸟在双人剪线中失败,炸弹会立刻爆炸。注意:菜鸟不能使用装备 9(稳定剂)。\n2 名玩家:红色导线 ×3,黄色导线 ×4。",
			m15name: "Новосибирск任务(我们也不会念)",
			m15brief: "工具箱上贴了俄语标签,没人看得懂。所以每次打开盒子都能收获惊喜!\n游戏设置:装备牌正面朝下加入游戏,不要查看内容;洗匀 12 张数字牌,牌堆正面朝下放置,翻开最上面一张。\n任务规则:剪断第 1 张数字牌对应的 4 根导线时,将一张装备牌翻回正面朝上并立即可用(无论装备牌本身的编号是什么),然后翻开下一张数字牌,以此类推。数字牌被翻开时对应编号的 4 根导线已被剪断的,翻开下一张(不翻装备)。\n2 名玩家:红色导线 ×2(三选二)。",
			m16name: "这很合理",
			m16brief: "别掉队了,做出正确的选择!\n游戏设置:洗匀数字牌,拿出 3 张正面朝上并排放在桌上,把顺序牌(B 面朝上)放到最左侧数字牌上方。\n任务规则:剪断全部 4 根 a 导线后才能剪断 b 和 c 数字的导线;剪断全部 4 根 b 导线后才能剪断 c 数字的导线;其他编号的导线可以随时剪断。剪断 4 根 a 导线后,将 a 卡牌翻面,把顺序牌移至 b 卡牌上方,之后对 b 重复相同流程。\n2 名玩家:红色导线 ×2,黄色导线 ×4。\n(汉化卡背面误印为「至少 2 根」,此处按顺序牌 B 面与英文原版的正确规则「全部 4 根」呈现。)",
			m17name: "匹诺曹",
			m17brief: "你能辨别真假吗?\n游戏设置:正面朝下洗匀角色牌,给每位玩家发一张并展示。拿到队长牌的玩家在本次任务中称为「匹诺曹」:他将队长牌放回游戏盒中,本次游戏无法使用双重探测器。匹诺曹需要在手牌前方摆放 2 个信息指示物,而非通常的 1 个;这些指示物必须是假信息——与指定的 2 根导线编号不同,且不能放在红色导线前方。\n任务规则:本任务中匹诺曹的所有信息指示物都是谎言,代表「这根导线不是这个编号」。指定匹诺曹手牌的双人剪线失败时,匹诺曹将猜测编号的信息指示物放在指定的导线前方(这是误导信息)。匹诺曹不能使用装备牌,但可以成为装备 2(对讲机)和装备 8(通用雷达)的使用对象。\n2 名玩家:红色导线 ×3。",
			m18name: "蝙蝠之友",
			m18brief: "本次任务没有装备,不过蝙蝠侠把他的蝙蝠雷达借给了我们。\n游戏设置:洗匀 12 张数字牌,牌堆正面朝下放置;只将装备 8(通用雷达)正面朝上放在版图上;本次任务不能在游戏设置阶段放置信息指示物。\n任务规则:本次任务中可以重复使用通用雷达。在自己的回合,当前回合的拆弹专家:❶ 翻开牌堆的第 1 张数字牌;❷ 对这张数字牌的编号使用通用雷达;❸ 指定一位玩家(包括自己)对此编号的导线执行剪线行动。牌堆抽空时重新洗匀;某编号 4 根导线均被剪断后丢弃那张数字牌。回合开始时手中只有红色导线的,执行展示红色导线行动。\n注意:不允许回顾先前回合对雷达的回复,一定要多留心!\n2 名玩家:红色导线 ×3。",
			m19name: "深入虎穴",
			m19brief: "你们终于找到了疯狂科学家的秘密巢穴!他一直在这个山洞里策划各种阴谋诡计。当心了,一只脚踏进坟墓可不是好主意……\n本任务没有特殊规则。\n(原作此任务配有剧情音频,线上版不播放。)",
			m20name: "大灰狼",
			m20brief: "这是连环炸弹客在自己作品上的签名。但谁会害怕大灰狼?你们可不怕!\n游戏设置:为每个板块底座发放的最后一根导线不放入手牌,而是放置在板块底座最右侧(不论是什么编号),然后将 X 指示物放在这根导线前方。抽到装备 2(对讲机)请替换成其他装备。\n任务规则:无特殊规则,照常进行游戏,但要注意 X 指示物标记的导线是乱序的。装备使用规则:装备牌不能用于 X 导线;所有装备都对 X 导线无效,包括个人装备、超级探测器(5)和通用雷达(8)。\n2 名玩家:红色导线 ×2(三选二),黄色导线 ×4。",
			m21name: "烤鸭危机",
			m21brief: "闻所未闻:有人在烤鸭里藏了炸弹!拆弹时一定要当心,奇偶不分可比雌雄莫辨危险多了!\n游戏设置:将所有信息指示物替换成奇偶指示物;游戏设置阶段放置一个奇偶指示物,而非信息指示物——指示物不再表示导线的具体编号,而是表明编号是奇数还是偶数。\n任务规则:任务期间始终使用奇偶指示物而非信息指示物,本规则适用于猜错编号时和装备 4(便利贴)。注意:红色导线既不是奇数,也不是偶数。\n2 名玩家:红色导线 ×2。",
			m22name: "我绝不允许!",
			m22brief: "「当你排除了一切不可能的情形,剩下的不管多么难以置信,那就是真相。」——夏洛克·福尔摩斯\n游戏设置:每位玩家拿取 2 个自己手牌中没有的编号的信息指示物,放在手牌旁边(可以拿取「黄色」指示物;有 2 个板块底座的玩家在每个底座旁边各放 1 个;缺少的编号不足 2 个则减少放置)。\n任务规则:剪断前 2 根黄色导线后,每位拆弹专家(从队长开始,顺时针方向)从版图选择一个信息指示物,交给自己左侧的玩家;每个玩家将收到的指示物正确摆放在手牌前方(没有对应编号就放在手牌旁边)。",
			m23name: "福德维治任务",
			m23brief: "这不是拍电影,危险的任务可不止会发生在纽约!连邮局都找不到它……你们的装备会晚一点送到。\n游戏设置:不要拿取装备牌,改为随机抽取 7 张装备牌正面朝下洗匀,在版图上组成牌堆;将任意一张数字牌正面朝上放在任务牌旁边。\n任务规则:数字牌对应的 4 根导线必须同时被剪断。本次任务的特殊行动——同时指定 4 根对应数字牌编号的导线(不使用装备或双重探测器):行动成功即可剪断这 4 根导线;行动失败,炸弹就会爆炸!每轮结束时、队长的回合开始前,从 7 张装备牌中弃掉 1 张,直到执行特殊行动;之后所有剩余的装备都变为可用(无论剪断过哪些导线)。\n2 名玩家:红色导线 ×2(三选二)。",
			m24name: "正确无误!",
			m24brief: "靠你们来数导线了!倒计时已经开始……\n游戏设置:将信息指示物替换为「×1」「×2」「×3」指示物,本次任务的游戏设置阶段和游戏流程都会用到。这些指示物表示指定的编号在板块底座上出现了一次、两次或三次(包括已经剪断的导线);×2 和 ×3 可以放在同一编号的任意导线前方;不能放在红色导线前方。\n任务规则:任务期间始终使用 ×1、×2、×3 指示物而非信息指示物,本规则适用于猜错编号时和装备 4(便利贴)。使用便利贴时,可以将指示物放在已剪断的导线前方。\n2 名玩家:红色导线 ×3。",
			m25name: "为了更好地听你说话呀……",
			m25brief: "不管有没有看到大耳朵,你们都知道大灰狼在偷听!本次拆弹任务中,大声说话会很危险!\n任务规则:拆弹专家不能直接说出导线编号,可以用各种方法暗示:用拼音、噪声、用手指数展示或说「一周的天数」等等。如果有拆弹专家忘记这条规则,大声说出了编号,起爆器就会前进一格!千万注意措辞!\n(线上对局无法执行禁语,本任务按无机械变化的普通局处理。)\n2 名玩家:红色导线 ×3。",
			m26name: "说到狼……",
			m26brief: "你们又落入了狼口。这次只有通过团队合作才能逃出生天。\n游戏设置:把所有数字牌正面朝上放在桌上;抽到装备 10(X/Y 射线)请替换成其他装备。\n任务规则:拆弹专家在自己的回合必须先选择一张正面朝上的数字牌翻至正面朝下,然后必须对此编号的导线执行一次剪线行动;之后的回合只能剪断仍然正面朝上的数字对应的导线。数字全部正面朝下时,将所有数字牌翻回正面;某数字的 4 根导线都被剪断后,将对应的数字牌从游戏中移除。当前回合的拆弹专家手中没有导线对应面朝上的数字时,跳过自己的回合,起爆器位置不变。",
			m27name: "玩导线",
			m27brief: "盘里放着一个梨,桌上放块橡皮泥……没时间说绕口令了,这东西随时可能爆炸!\n游戏设置:本次任务只口头确定队长,不发放角色牌——没有双重探测器!抽到装备 7(备用电池)请替换成其他装备。\n任务规则:剪断前 2 根黄色导线时——❶ 随机拿出与拆弹专家相同数量的信息指示物,正面朝上排成一行;❷ 每位拆弹专家(从队长开始,顺时针方向)从中选择一个,放在自己手牌的对应位置前方(没有对应编号就放在手牌旁边)。\n2 名玩家:队长不能在游戏设置阶段放置信息指示物。",
			m28name: "懒队长",
			m28brief: "懒队长有点不太聪明。他忘记带工具了。而且只要他犯一丁点错,任务就全完了!\n游戏设置:角色牌发放完毕后,队长(本次任务中称为「懒队长」)把自己的角色牌放回盒子——懒队长没有双重探测器。\n任务规则:懒队长不能使用装备牌和自己的个人装备;懒队长执行双人剪线失败时,炸弹会立刻爆炸。装备 2(对讲机)和装备 8(通用雷达)可以对懒队长生效。\n2 名玩家:红色导线 ×3,黄色导线 ×4。",
			m29name: "错误号码",
			m29brief: "「小心陷阱数字!」\n游戏设置:洗匀数字牌,正面朝下给每位玩家发 2 张(队长右侧的玩家发 3 张),其余数字牌正面朝下组成牌堆;每位玩家秘密拿取数字牌。\n任务规则——玩家回合开始时:❶ 当前回合玩家右侧的玩家将自己的一张数字牌正面朝下放在桌上;❷ 当前回合玩家照常进行回合;❸ 展示这张数字牌:如果当前回合玩家剪断了对应编号的导线,起爆器前进一格;❹ 当前回合玩家拿起这张数字牌。剪断 4 根相同编号的导线时,立刻弃掉对应的数字牌;手中只有一张数字牌时从牌堆再拿一张(对应编号已剪完就再拿一张);只剩一个编号的导线可以剪时,立刻弃掉最后的数字牌。\n2 名玩家:队长不能在游戏设置阶段放置信息指示物。",
			m31name: "每个人都受伤了",
			m31brief: "有些限制可以选择,还有些则没得选……更别提队友了!\n游戏设置:把 A 到 E 的 5 张限制牌正面朝上放在桌上。拿取信息指示物前,从队长开始按顺时针方向,每名玩家选择一张限制牌正面朝上放在自己面前;拆弹专家人数小于 5 时丢弃多余的限制牌。\n任务规则:每位玩家必须遵守自己的限制。在自己的回合开始时,如果一位拆弹专家没有条件遵守自己的限制,将这张限制牌翻面,之后正常游戏。\n2 名玩家:不建议选择 A+B 或 C+D 的限制牌组合。",
			m32name: "恶作剧攻击!",
			m32brief: "你们已经见过一些坏蛋了,但邪恶小丑绝对是最可怕的一个……可怕到能让人患上「小丑恐惧症」!每一轮都要适应他的新规则!\n游戏设置:洗匀 12 张限制牌,正面朝下组成牌堆,将最上面的牌翻开。\n任务规则:所有拆弹专家必须遵守正面朝上的限制。各拆弹专家的回合开始时,队长可以在商议过后将正面朝上的限制牌替换成下一张。当前回合的拆弹专家因为限制而无法继续游戏流程时,说明此情况并跳过自己的回合(起爆器保持不动)。展示红色导线行动不受限制影响。\n2 名玩家:红色导线 ×3。",
			m33name: "情迷拉斯维加斯……",
			m33brief: "一个小丑还不够,现在乔治·克鲁尼和他的 11 名同伙又在赌场保险箱上放了炸弹!游戏开始!\n游戏设置:将所有信息指示物替换成奇偶指示物;游戏设置阶段放置一个奇偶指示物,而非信息指示物。\n任务规则:任务期间始终使用奇偶指示物而非信息指示物,本规则适用于猜错编号时和装备 4(便利贴)。注意:红色导线既不是奇数,也不是偶数。\n2 名玩家:红色导线 ×3。",
			m34name: "最弱的一环",
			m34brief: "没错,最弱的一环就在你们之中!甚至可能就是你!\n游戏设置:确定队长后,洗匀角色牌(确保队长牌在里面),正面朝下给每名玩家发一张——第一名玩家不一定会拿到「队长」牌。洗匀 A 到 E 的限制牌,正面朝下给每名玩家发一张。每位拆弹专家秘密查看自己的 2 张牌:拿到「队长」牌的玩家成为最弱的一环,不能让其他人知道,并且只有此玩家需要遵守自己的限制(其他玩家也要阅读自己的牌,以免暴露)。\n任务规则:角色牌隐藏时,拆弹专家没有个人装备。最弱的一环必须遵守自己的限制牌且不得声张;在自己的回合因为限制而无法继续游戏时:起爆器前进 2 格,所有拆弹专家弃掉自己的限制牌和角色牌。其余拆弹专家无视自己的限制牌;回合开始时,可以指认最弱的一环并描述其限制(不能咨询他人)——说错(身份和/或限制):起爆器前进一格;说对(身份和限制):翻面所有角色牌并可使用,最弱的一环无需再遵守限制。\n本任务无法由 2 名拆弹专家游玩。",
			m35name: "无关的单线",
			m35brief: "这根孤零零的导线是硬连接的!\n游戏设置:将红色和黄色导线与蓝色导线洗到一起之前,给每位拆弹专家的每个板块底座发一张正面朝下的蓝色导线牌:不放入手牌,必须放在板块底座右端(不论是什么编号),并在其前方放一个 X 指示物,之后照常洗匀发放其他导线。抽到装备 2(对讲机)请替换成其他装备。\n任务规则:可以用正常方式(双人或单人剪线)剪断 X 指示物标记的导线,但前提是已经剪断了全部 4 根黄色导线。装备使用规则:装备不能用于 X 导线;所有装备都对 X 导线无效,个人装备、装备 5(超级探测器)和装备 8(通用雷达)也是如此。\n2 名玩家:红色导线 ×3,黄色导线 ×4。",
			m36name: "棕榈树下的恐慌",
			m36brief: "欢迎来到波拉波拉岛。这是个天堂……但今天除外!今天不能在泳池里跳水了……\n游戏设置:洗匀数字牌,抽取 5 张正面朝上并排放在桌上;队长选择(不得商议)将顺序牌(A 面朝上)放在哪一端,并使其箭头指向另一端。\n任务规则:只能按照顺序牌上箭头所示的顺序,剪断正面朝上的数字牌对应的导线。每当一位拆弹专家剪断面朝顺序牌的第 1 个数字的 2 根对应导线,就移除这张数字牌,然后此拆弹专家可以选择(不得咨询他人)将顺序牌放在剩余数字牌的任意一边。与 5 张数字牌编号不同的导线可以随时剪断。\n2 名玩家:红色导线 ×2(三选二),黄色导线 ×4。",
			m37name: "小丑!",
			m37brief: "他放了一根松动的导线!每次你们取得进展,他都会改变规则!这个小丑真是越来越讨厌了。\n游戏设置:洗匀 12 张限制牌,正面朝下组成牌堆,将第 1 张牌翻面。\n任务规则:必须遵守正面朝上的限制。剪断某编号的全部 4 根导线后,把当前限制牌替换成下一张。当前回合的拆弹专家因限制无法继续游戏流程时,说明情况并跳过回合;但如果一整轮所有拆弹专家都无法继续,则起爆器前进一格,然后替换限制牌。牌堆抽空后不再有限制。展示红色导线行动不受限制影响。\n2 名玩家:红色导线 ×3。",
			m38name: "正一根线,反一根线……",
			m38brief: "队长必须及时剪断未知导线,否则就全完了!\n游戏设置:导线发放完毕后,队长在不看编号的情况下将自己的一张导线牌翻面(编号朝向队友),放在手牌的末尾。\n任务规则:队长必须自己用常规剪线行动剪断被翻面的导线,但不能使用装备或双重探测器;剪线失败,炸弹就会爆炸。其他拆弹专家不能剪这根导线;除了剪断被翻面的导线已没有其他可用行动时,必须跳过回合,起爆器前进一格。不可对被翻面的导线使用装备牌或角色的个人装备。\n2 名玩家:红色导线 ×3。",
			m39name: "四圣线",
			m39brief: "据奇线博士所述,剪断 4 根正确的导线就可以获得大量信息!\n游戏设置:请勿将装备牌放在版图上。将任意一张数字牌正面朝上放在版图的第一个装备格上;随机拿取 8 张数字牌正面朝下堆放在版图旁边。每名玩家不能选择信息指示物,改为随机拿取一个放在手牌前方的对应位置(没有对应编号就放在手牌旁边;抽到「黄色」指示物请换一个)。\n任务规则:必须同时剪断正面朝上的数字牌对应的 4 根导线。本次任务的特殊行动——指定并剪断数字牌对应的 4 根导线(不使用个人装备),手中没有对应编号的导线时也可以执行;剪线失败,炸弹就会爆炸。每轮结束时、队长的回合开始前,从牌堆弃掉 1 张数字牌,直到执行特殊行动。执行特殊行动后:将剩余数字牌正面朝下,从队长开始顺时针发给所有拆弹专家;每位拆弹专家根据收到的数字牌,在自己手牌前方放置对应的信息指示物(已没有此编号的指示物则无视)。\n2 名玩家:红色导线 ×3,黄色导线 ×4。",
			m40name: "虎胆龙威",
			m40brief: "你们一起来到中富大厦庆祝圣诞节……然而事情突然失控了!现在你们正在通风管道里爬行,试图拆除绑匪的炸弹,这让沟通变得十分困难!玩得开心点!\n游戏设置:将所有信息指示物替换为「×1」「×2」「×3」指示物与奇偶指示物。游戏设置阶段,队长放置一个「×1/×2/×3」指示物,队长左手边的玩家放置一个奇偶指示物,再下一位放置「×1/×2/×3」指示物,以此类推。两种指示物都不能放在红色导线前方。\n任务规则:任务期间始终使用 ×1、×2、×3 指示物与奇偶指示物,而非信息指示物;适用于猜错编号时和装备 4(便利贴)。队长与顺位 3、5 的玩家使用 ×1/×2/×3 指示物,顺位 2、4 的玩家使用奇偶指示物。使用便利贴时,可以将 ×1/×2/×3 指示物放在已剪断的导线前方。\n2 名玩家:队长不能在游戏设置阶段放置指示物,另一位玩家放置一个奇偶指示物。",
			m41name: "拉丁炸弹",
			m41brief: "「Para bailar la Bamba...」在西班牙语中的意思是「糟了,又一颗炸弹」(算是吧,翻译过后总会损失一点含义……)。这颗炸弹是个烫手山芋,所以要保持头脑冷静!\n游戏设置:黄色导线不与其他导线混在一起,它们是拌线:将黄色导线牌正面朝下给每位拆弹专家发一张(有 5 名拆弹专家时队长没有)。将起爆器调整到更难的位置。每名玩家随机拿取一个信息指示物放在手牌前方(没有对应编号就放在手牌旁边)。抽到装备「双层底」请替换成其他装备。\n任务规则:无法通过常规方式剪断拌线,只能每次剪断一根。本次任务的特殊行动——在自己的回合,拆弹专家可以指定 1 名队友的拌线:行动成功,只展示被指定的导线,且起爆器倒退一格;行动失败,在被指定的导线前方放置信息指示物,起爆器前进一格!手中只剩下拌线和红色导线的拆弹专家跳过自己的回合。\n2 名玩家:红色导线 ×2(三选二),黄色导线 ×2。",
			m43name: "“纳米”机器人",
			m43brief: "纳米有话要说:「哔——哔哔哔——哔!」(这个机器人太粗鲁了,我们只能把它说的话全屏蔽掉。)\n游戏设置:将「纳米」机器人放在版图的「1」格上。发放导线时,在纳米上放置指定数量的导线牌,不要查看它们:2 名拆弹专家时 5 根;3 或 4 名时 4 根;5 名时 3 根。\n任务规则:一位拆弹专家的回合结束时,纳米前进一格;到达「12」后掉头回到「11」,以此类推。当前回合的拆弹专家剪断纳米所在数字的对应导线时,从机器人上拿一张导线牌(不展示编号),放在自己手牌的正确位置(有 2 个板块底座时任选一个)。必须剪断所有导线(红色导线则是展示)才能拆除炸弹并获胜,包括纳米的导线。装备 11(咖啡瓶)不会阻止纳米前进。\n2 名玩家:队长在游戏设置阶段随机抽取自己的指示物。",
			m44name: "水下压力",
			m44brief: "作为海盗,红兔子既擅长海上非法劫掠,也对电子产品盗版颇有心得。他能让你们更加内行,因为这次任务很有「深度」。管理好自己的氧气罐……还有压力!\n游戏设置:每有一名拆弹专家,将 2 个氧气指示物放在储备区(3 名玩家需要 6 个)。抽到装备 10(X/Y 射线)请替换成其他装备;不使用带有 X/Y 射线装备的新角色。\n任务规则:拆弹专家必须先从储备区拿取导线编号范围对应数量的氧气指示物,才能执行剪线行动:1 个(1 至 4 号)、2 个(5 至 8 号)、3 个(9 至 12 号)。队长的回合开始时,将所有指示物放回储备区。氧气指示物不足而无法行动时,跳过回合,起爆器前进一格。\n(原作的水下禁语规则在线上不执行。)",
			m45name: "我的导线,我的战斗!",
			m45brief: "选择因人而异,而你的命运由你自己决定。要快!\n游戏设置:洗匀 12 张数字牌,正面朝下组成牌堆。抽到装备 10(X/Y 射线)或装备 11(咖啡瓶)请替换成其他装备;不使用带有 X/Y 射线装备的新角色。\n任务规则:拆弹专家不再按顺时针轮流行动——每个回合,队长拿取一张数字牌,第一位说出「我剪!」的拆弹专家(包括队长)必须剪断此编号的导线。剪断 4 根同编号导线时丢弃对应数字牌;牌堆抽空时重新洗匀组成新牌堆。说出「我剪!」但没有对应编号的,或者提供了线索(例如「我有点犹豫要不要这么做」),起爆器前进一格。没有人自告奋勇时,队长挑选一名拆弹专家(包括自己);此拆弹专家没有对应编号的导线时,选择一个信息指示物放在自己手牌前方,起爆器前进一格。手中只有红色导线的拆弹专家随时可以说「我剪!」,然后执行展示红色导线行动。\n2 名玩家:红色导线 ×3。",
			m46name: "特工 007",
			m46brief: "「我叫邦弹,詹姆斯·邦弹。」\n游戏设置:4 根黄色导线的编号固定为 5.1 / 6.1 / 7.1 / 8.1。抽到装备 7(备用电池)请替换成其他装备。\n任务规则:4 根 7 号导线必须最后剪断。本次任务的特殊行动——回合开始时,手中只有 007 导线的拆弹专家必须同时剪断全部 4 根 7 号导线;剪线失败,炸弹就会爆炸。在此之前剪到 007 导线的,视为剪线失败,照常处理(放置信息指示物,起爆器前进一格)。\n2 名玩家:队长不能在游戏设置阶段放置信息指示物。",
			m47name: "结帐!",
			m47brief: "现在比任何时候都更需要心理素质(不只是算术),还有团队精神。\n游戏设置:将 12 张数字牌正面朝上并排放在桌上。抽到装备 10(X/Y 射线)请替换成其他装备;不使用带有 X/Y 射线装备的新角色。\n任务规则:要剪断导线,必须选择 2 张数字牌相加或相减来确定要剪断的导线编号,然后弃掉这些数字牌。范例:数字牌 3 和 9 可以剪 12(3+9);数字牌 10 和 3 可以剪 7(10-3)。桌上没有正面朝上的数字牌时,将弃牌堆的 12 张牌再次摊开。拆弹专家不能或不想行动时,选择并弃掉 2 张数字牌,起爆器前进一格。\n2 名玩家:红色导线 ×3。",
			m48name: "三人成行",
			m48brief: "「——我们数到三就上。——等等!是数到三的时候上,还是数完三再上?」\n游戏设置:3 根黄色导线不与其他导线混在一起,正面朝下从队长开始按顺时针方向逐一发放(只有 2 位拆弹专家时,队长拿到 2 根,每个板块底座各放 1 根),随后发放其余导线。\n任务规则:不能用常规方式剪断黄色导线。本次任务的特殊行动——同时剪断 3 根黄色导线;有 4 或 5 名拆弹专家时,手中没有黄色导线的拆弹专家也可以执行此行动。行动失败时,所有被指定的导线都获得一个信息指示物,但起爆器只前进一格。\n2 名玩家:红色导线 ×3,黄色导线 ×3。",
			m49name: "瓶中信",
			m49brief: "红兔子是海盗,他从不和别人分享朗姆酒。但你们别无选择,只能分享……自己的氧气瓶!请合理分配!\n游戏设置:拿取氧气指示物放在自己面前:2 名拆弹专家时每人 7 个;3 名时每人 6 个;4 名时每人 5 个;5 名时每人 4 个。抽到装备 10(X/Y 射线)请替换成其他装备;不使用带有 X/Y 射线装备的新角色。\n任务规则:拆弹专家必须先将等同于要剪断导线编号数量的氧气指示物交给一名队友,才能执行剪线行动。范例:要剪断 5 号导线,必须将 5 个指示物交给一名队友(不一定是你要剪线的队友)。氧气指示物不足而无法行动时,跳过回合,起爆器前进一格。\n(原作的水下禁语规则在线上不执行。)\n2 名玩家:红色导线 ×3。",
			m50name: "黑海",
			m50brief: "在这夜晚的茫茫大海上,你早该想到红兔子不会放过你们的!他劫持了你们的船,还把所有灯都关了。好在你们记性不错,对吧?\n游戏设置:本次任务不使用验证指示物和红黄棋子!先记住游戏中使用的红色和黄色导线,再将它们混入蓝色导线。所有人将信息指示物放在自己的手牌旁边(而非手牌前方),通过指向对应的导线来告知队友——没错,你们必须记住这些信息!\n任务规则:剪线失败时,将信息指示物放在相关板块底座的旁边(而非被选中导线的前方)。不用说也知道,拆弹专家不能分享自己记住的信息。所有装备都可以正常使用。\n2 名玩家:红色导线 ×3,黄色导线 ×4。",
			m51name: "今天你们(不)走运啦!",
			m51brief: "有时候只有技术是不够的,你们必须相信自己的直觉。\n游戏设置:洗匀 12 张数字牌,正面朝下组成牌堆;将起爆器倒退一格(相当于多了一个拆弹专家)。抽到装备 10(X/Y 射线)请替换成其他装备;不使用带有 X/Y 射线装备的新角色。\n任务规则:在自己的回合,当前回合的拆弹专家成为「长官」:❶ 将牌堆的第 1 张数字牌翻面;❷ 决定(不得商议)哪位玩家需要对此编号的导线执行剪线行动(包括自己);❸ 被指定的玩家说「是,长官!」,然后执行剪线行动。之后「长官」左侧的玩家成为新「长官」,以此类推。被指定的拆弹专家没有对应编号的导线时,选择一个信息指示物放在自己手牌前方,起爆器前进一格。剪断 4 根对应导线后丢弃数字牌;牌堆抽空时重新洗匀。回合开始时手中只有红色导线的,执行展示红色导线行动。\n2 名玩家:红色导线 ×2;队长不能在游戏设置阶段放置信息指示物。",
			m52name: "一群叛徒!",
			m52brief: "猜忌正在队伍里悄悄蔓延。所有人都互相提防,谎言不断吞噬你们,而真相却无处可寻……\n游戏设置:抽到装备 1(标签 ≠)或装备 12(标签 =)请替换成其他装备。每位拆弹专家需要在手牌前方放置 2 个信息指示物,而非通常的 1 个;这 2 个指示物必须提供假信息,可以放在蓝色或红色导线前方。\n任务规则:本次任务中的所有信息指示物都是错误的:信息指示物代表「这根导线不是这个编号」。双人剪线失败时,被指定导线的所有者在手牌前方放置对应猜测编号的信息指示物(这是假信息)。\n2 名玩家:红色导线 ×3,黄色导线 ×4。",
			m53name: "纳米归来",
			m53brief: "机器人第四定律:有时候,机器人想做什么就做什么。\n游戏设置:把纳米放在版图的「1」格前面;本次任务不使用起爆器。抽到装备 6(抑制器)或装备 9(稳定剂)请替换成其他装备。\n任务规则:纳米会在一位拆弹专家的回合结束时移动——剪线成功:前进 1 格;成功剪断纳米所在数字的对应导线:后退 1 格;剪线失败:前进 2 格。当心,纳米到达「12」,炸弹就会「砰」地一声爆炸!\n2 名玩家:红色导线 ×3。",
			m55name: "诺普博士的挑战",
			m55brief: "「好了,炸弹克星,是时候来会会比自己更强的人了!」\n游戏设置:取出与拆弹专家人数相等的挑战牌,正面朝上放在桌上;将起爆器调整到更难的位置。\n任务规则:挑战牌会显示一个条件:条件得到满足,则挑战成功。条件可能针对 1 名拆弹专家(例如在板块底座上排列导线),也可能针对整个团队(例如剪断导线的顺序)。挑战成功时,立刻弃掉这张挑战牌,起爆器倒退一格。\n2 名玩家:红色导线 ×2(三选二)。",
			m56name: "拌线",
			m56brief: "它们会让事情变成一团乱麻。\n游戏设置:导线发放完毕后,每位玩家将自己的一根导线翻面(编号朝向队友)且不查看编号,放在手牌的最右端。\n任务规则:每位拆弹专家必须自己通过常规剪线行动剪断自己被翻面的导线,不能使用装备或双重探测器;行动失败,炸弹就会爆炸。不可对被翻面的导线使用装备牌或角色的个人装备。拆弹专家可以(选择或被迫)对队友面朝外的导线执行双人剪线行动,但这样做会使起爆器前进一格。\n2 名玩家:红色导线 ×3。",
			m57name: "碟中谍",
			m57brief: "某个叫伊森的家伙发来一条信息:「我正在度假,因此你们将决定是否接受这个任务:拯救世界。就这么简单。另外,此消息将在 10 秒后自动销毁……祝你们好运!」\n游戏设置:把所有数字牌正面朝上放在桌上,每张牌旁边随机放一张正面朝上的限制牌。抽到装备 10-10(分解器)请替换成其他装备。\n任务规则:每次在版图上放置验证指示物时,在版图上放置相应的(数字牌旁的)限制牌;已有限制牌就放在上一张上面——同一时间只会有一个限制生效。所有拆弹专家必须遵守此限制。当前回合的拆弹专家因限制无法行动时,说明情况并跳过回合(起爆器不会移动);但如果一整轮都没有拆弹专家可以行动,炸弹就会爆炸。展示红色导线行动不受限制影响。\n2 名玩家:红色导线 ×2。",
			m58name: "DIY",
			m58brief: "不能交流就很难拆除炸弹。不过这次运气不错,你们的朋友麦盖先带着口香糖和回形针,设法修好了双重探测器!\n游戏设置:本次任务不使用信息指示物(游戏设置阶段也不用)。抽到装备 4(便利贴)或装备 7(备用电池)请替换成其他装备;不使用新角色。\n任务规则:即使剪线失败,也不能透露被指定的导线的任何信息。但好消息是,每位拆弹专家每回合都可以使用自己的双重探测器——它们永远不会翻面!\n2 名玩家:红色导线 ×3。",
			m59name: "“纳米”前来救援",
			m59brief: "「生活,别跟我提什么生活。」纳米的情绪有些低落,但人生没有过不去的坎,只要你们勇于面对!\n游戏设置:将 12 张数字牌正面朝上随机并排放在桌上;将「纳米」机器人放在 7 号牌上,面朝数字牌更多的一边。抽到装备 10(X/Y 射线)请替换成其他装备;不使用带有 X/Y 射线装备的新角色。\n任务规则:要执行剪线行动,当前回合的拆弹专家必须——❶ 将纳米向前移动或留在原地(禁止后退),让它处于自己手牌中一个编号对应的卡牌上;❷ 用纳米所在的编号执行一次剪线行动;❸ 选择纳米面朝的方向(保持不变或转 180 度)。无法使用现有的编号(纳米下方和前面的卡牌)执行行动时,需要把纳米旋转 180 度,将起爆器前进一格,然后再行动。剪断同编号的 4 根导线后,将相应的数字牌翻面。装备 11(咖啡瓶)会跳过一整个回合。\n2 名玩家:红色导线 ×3。",
			m60name: "诺普博士归来",
			m60brief: "「世上有两种人,一种用炸弹震撼整个世界,而另一种只会剪断细细的导线。」别让诺普博士的挑衅得逞!\n游戏设置:取出与拆弹专家人数相等的挑战牌,正面朝上放在桌上;将起爆器调整到更难的位置。\n任务规则:挑战牌会显示一个条件:条件得到满足,则挑战成功。条件可能针对 1 名拆弹专家,也可能针对整个团队。挑战成功时,立刻弃掉这张挑战牌,起爆器倒退一格。\n2 名玩家:红色导线 ×3。",
			m61name: "安静,然后行动!",
			m61brief: "与团队分享问题会有帮助!\n游戏设置:每位玩家随机获得一张 A 到 E 的限制牌,正面朝上放在自己面前。有 2 名拆弹专家时,在桌上添加 2 张限制牌(A 到 E):一张放在队长左侧,一张放在队长右侧;有 3 名时添加 1 张,放在队长左侧。\n任务规则:每位玩家必须遵守自己的限制。没有条件遵守自己的限制时,跳过回合(起爆器保持不动);但如果一整轮都没有拆弹专家可以行动,炸弹就会爆炸。每轮的队长回合开始前,拆弹专家们互相商量,决定是否传递所有限制牌;同意则选择按顺时针或逆时针方向传递。拆弹专家随时可以弃掉自己的限制牌,换成随机一张(F 到 L)限制牌,但必须将起爆器前进一格。展示红色导线行动不受限制影响。\n2 名玩家:红色导线 ×2。",
			m62name: "绝世天劫轮盘赌",
			m62brief: "布鲁斯·沃拉斯和他的太空探险家团队必须在一颗陨石上及时安装炸弹,否则它就会撞击地球。不出所料,一个笨手笨脚的傻瓜在训练场就把炸弹启动了。赶快前往 NASA 的急诊室,拯救这些未来的救世主!\n游戏设置:随机取出与拆弹专家人数相等的数字牌,正面朝上放在桌上;将起爆器调整到更难的位置。\n任务规则:每次剪断正面朝上的数字牌对应的 4 根导线后,将起爆器倒退一格。\n2 名玩家:红色导线 ×3。",
			m63name: "泰坦尼克号 2",
			m63brief: "这艘新巨轮的名字很怪,更怪的是迪卡普里奥的粉丝在船体内放了一颗炸弹!管理好自己的氧气,成为世界之王!\n游戏设置:队长拿取氧气指示物:2 名拆弹专家时 14 个;3 名时 18 个;4 名时 24 个;5 名时 30 个。抽到装备 10(X/Y 射线)请替换成其他装备;不使用带有 X/Y 射线装备的新角色。\n任务规则:拆弹专家必须先在储备区放入与指定导线编号相等数量的氧气指示物,才能执行剪线行动(范例:剪断 5 号导线须放入 5 个)。自己的回合结束时,当前回合的拆弹专家将剩余的所有指示物交给左侧的玩家。每轮结束后,队长拿取储备区中的所有指示物再开始回合;队长已没有导线或用咖啡瓶跳过回合时,由下一位玩家拿取所有指示物。氧气指示物不足而无法行动时,跳过回合,起爆器前进一格。\n(原作的水下禁语规则在线上不执行。)\n2 名玩家:红色导线 ×3。",
			m64name: "拌线归来",
			m64brief: "这次它们非常灵敏!\n游戏设置:导线发放完毕后,每位玩家将自己的 2 根导线翻面(编号朝向队友)且不查看编号;根据队友的指示,将编号较小的放在手牌最左端,编号较大的放在最右端。\n任务规则:每位拆弹专家必须自己通过常规剪线行动剪断自己被翻面的导线,不能使用装备或双重探测器;行动失败,炸弹就会爆炸。拆弹专家可以(选择或被迫)对队友面朝外的导线执行双人剪线行动,但这样做会使起爆器前进一格。\n2 名玩家:红色导线 ×2。",
			m65name: "幕后牵线",
			m65brief: "「可以告诉我你的号码吗?」\n游戏设置:将数字牌随机发放给各位拆弹专家,正面朝上放在面前;有 5 名拆弹专家时,队长和队长左侧的玩家比其他玩家多拿 1 张。抽到装备 10(X/Y 射线)请替换成其他装备;不使用带有 X/Y 射线装备的新角色。\n任务规则:执行剪线行动时,拆弹专家必须尝试剪断与自己的一张数字牌对应的编号。当前回合的拆弹专家手中没有与自己的数字牌对应的导线时,跳过回合,起爆器前进一格。在任何情况下,回合结束时都必须选择自己的一张数字牌,交给任意队友。剪断同编号的 4 根导线后,将相应的数字牌翻面——你面前就有一些正面朝上的牌(要剪的数字)和一些正面朝下的牌(总是可以送给队友)。可以使用装备 11(咖啡瓶)跳过回合。\n本任务无法由 2 名拆弹专家游玩。"
		},
		en: {
			name: "Bomb Busters",
			desc: "Co-op bomb defusal: call a value and point at a teammate’s wire — a wrong blue or yellow advances the dial, a red one explodes",
			rules: "Goal: as a team, cut every blue and yellow wire before the detonator dial reaches the skull; cutting a red wire or maxing the dial explodes the bomb.\nSetup:\n· Four blue wires of each value 1-12, plus red and yellow wires mixed in as the mission card shows; each player sorts their own rack ascending and only sees their own wires.\n· From mission 3 on, draw as many equipment cards as players; each unlocks once 2 wires of its value are cut, and can be used once.\n· Starting with the Captain, each player places 1 info token in front of one of their blue wires.\nPlay:\n· On your turn, choose one of: Dual Cut, Solo Cut, or Reveal Red Wires.\n· Dual Cut: call a value (1-12 or \"yellow\") and point at one of a teammate’s wires.\n· If right, both wires are cut face-up; if wrong, the dial advances and the teammate places a true-value token on that wire; pointing at a red wire explodes the bomb.\n· Solo Cut: if every remaining uncut wire of a value is in your hand (2 or 4), cut them all alone; for yellow you must hold every yellow wire in play.\n· Reveal Red Wires: when every uncut wire in your hand is red, reveal them all — you are done.\n· When all 4 wires of a value are cut, place a validation token on the number track.\n· Each player has a once-per-game personal gadget, the Double Detector: a Dual Cut may point at 2 of a teammate’s wires and succeeds if either matches.\nMissions: 66 missions each add their own special rules (sequence cards, constraint cards, oxygen, the Nano robot and more) — check the mission list before starting.\nEnd:\n· Every rack empty: mission accomplished.\n· A red wire cut or the dial reaching the skull: the bomb explodes — mission failed.",
			turnYou: "Your turn: tap one of your wires to cut",
			turnWait: "Waiting for {{name}}…",
			setupTokenYou: "Your turn: place an info token on one of your blue wires",
			setupTokenWait: "Waiting for {{name}} to place their opening token…",
			actDual: "Dual Cut",
			cutTarget: "{{name}} · wire {{positions}}",
			actSolo: "Solo Cut",
			cutStartHint: "Tap a wire on your rack to start cutting",
			actReveal: "Reveal Reds",
			actPass: "Pass",
			actMass: "Mass Call",
			actIberian: "Call Yellow",
			actAccuse: "Accuse",
			actClaim: "Take Turn",
			actSqueak: "Squeak!",
			actEquip: "Equipment",
			actPersonal: "Gadget",
			valuePickOne: "Pick a value",
			valuePickTwo: "Call two values; either hit succeeds",
			valuePickSecond: "Call a second value; either hit succeeds",
			valuePickBlind: "Wire value hidden — call blind",
			iberianHint: "Tap a teammate's wire and declare it yellow",
			guessYellow: "Yellow",
			confirm: "Confirm",
			cancel: "Cancel",
			dialLeft: "{{n}} failures left",
			dialDanger: "Next step is the skull!",
			validatedTrack: "Completed",
			myRack: "My rack",
			rackOf: "{{name}}’s rack",
			missionInfo: "Mission",
			missionDetails: "View mission details",
			rackPicker: "Inspect wires",
			playerDone: "Done",
			captainBadge: "Captain",
			equipLocked: "Locked",
			equipUsed: "Used",
			equipReady: "Ready",
			equipSheetTitle: "Equipment",
			equipSheetSubtitle: "MISSION LOADOUT",
			equipSheetAvailable: "{{n}} ready",
			equipSectionPersonal: "Personal gadget",
			equipSectionPublic: "Shared equipment",
			equipSheetOnce: "Character gear · once per mission",
			equipUse: "Use",
			equipSheetUsed: "Used",
			equipNeedCut: "Cut 2 × {{v}}",
			equipNeedReveal: "Reveal character card",
			optMission: "Mission",
			optCharacters: "Characters",
			chClassic: "Classic",
			chClassicHint: "Everyone gets the Double Detector",
			chMixed: "Mixed",
			chMixedHint: "Randomly deal expansion characters",
			optMarkers: "Red/yellow value hints",
			mkOpen: "Marked",
			mkOpenHint: "The number track marks red/yellow values (official rule)",
			mkHidden: "Hidden",
			mkHiddenHint: "No value marks for red/yellow wires — harder",
			missionBox1: "Base box",
			missionBox2: "Box 9-19",
			missionBox3: "Box 20-30",
			missionBox4: "Box 31-42",
			missionBox5: "Box 43-54",
			missionBox6: "Box 55-66",
			missionUnavailable: "Audio mission, coming later",
			missionNeed3: "Needs 3+ players",
			overWin: "Bomb defused!",
			overLose: "Mission failed",
			overSafe: "The whole team made it out safely",
			overRetry: "Retry this mission",
			overNextMission: "Next mission · {{n}}",
			overBoomOther: "The bomb exploded…",
			overBoomLazy: "The intern Captain missed — BOOM…",
			overBoomRed: "A red wire was cut — BOOM…",
			overBoomDial: "The dial hit the skull — BOOM…",
			overBoomNano: "Nano ran past the end — BOOM…",
			overBoomMass: "The mass call missed — BOOM…",
			overBoomAccuse: "The weak link was cornered — BOOM…",
			overBoomTimeout: "Time ran out — BOOM…",
			overBoomConstrain: "A full round with no moves — BOOM…",
			pendFailToken: "{{name}} chooses which wire gets the info token",
			pendFailTokenYou: "Tap a wire to place the info token in front of it",
			pendPickCut: "Both wires hit: choose which one to cut",
			pendFakeToken: "{{name}} places a fake token",
			pendPickToken: "{{name}} picks a token",
			pendPassToken: "{{name}} passes a token to their left neighbor",
			pendGiveCard: "{{name}} gives a number card to a teammate",
			pendChooseConstraint: "{{name}} chooses a constraint card",
			pendPlaceCard: "{{name}} places a number card face down",
			pendMoveSequence: "{{name}} moves the Sequence card",
			pendTalkiesPick: "{{name}} chooses one of their uncut wires to give",
			pendTalkiesPickYou: "Walkie-talkies swap: tap one of your uncut wires to give",
			constraintNow: "Active constraint",
			challengeDone: "Challenge complete!",
			oxygenLeft: "Oxygen",
			nanoAt: "Nano on {{n}}",
			timerLeft: "{{time}} left",
			logDualOk: "{{from}} and {{to}} each cut a \"{{guess}}\"",
			logDualFail: "{{from}} called \"{{guess}}\" on {{to}}’s wire — wrong",
			logSolo: "{{name}} solo-cut {{n}} \"{{value}}\" wires",
			logReveal: "{{name}} revealed all red wires ({{n}}) — done",
			logEquip: "{{name}} used \"{{equip}}\"",
			logValidate: "All 4 \"{{value}}\" wires cut — validation token placed",
			logPass: "{{name}} passed",
			logClaim: "{{name}} takes the turn",
			logMassOk: "{{name}} called {{n}} wires — all correct",
			logMassFail: "{{name}}’s mass call failed",
			logIberianOk: "{{from}} called {{to}}’s yellow wire — correct",
			logIberianFail: "{{from}}’s call on {{to}}’s wire was not yellow",
			beatActorTarget: "{{actor}} targets {{target}}’s rack",
			beatActor: "{{actor}} cuts wires",
			beatCalled: "called “{{value}}”",
			beatSuccess: "Wires cut",
			beatMiss: "Wrong call",
			beatBoom: "Bomb detonated",
			beatCutCount: "{{n}} wires cut",
			beatHpLoss: "HP −{{n}}",
			beatHpGain: "HP +{{n}}",
			beatValidated: "{{value}} verified",
			beatEquipment: "Equipment changed",
			historyButton: "Log",
			historyOpen: "View game log",
			historyTitle: "Game log",
			historyKindDual: "Duo",
			historyKindSolo: "Solo",
			historyKindMass: "Special call",
			historyKindIberian: "Yellow call",
			historyKindReveal: "Red reveal",
			historyKindEquip: "Gadget cut",
			historyEmpty: "No events yet",
			historyPosition: "Rack {{rack}} · wire {{position}}",
			historyNano: "Nano wire",
			historyCutValue: "Cut “{{value}}”",
			historyUncut: "Targeted, not cut",
			historyEquipment: "Equipment changed: {{names}}",
			historyBriefSuccess: "{{n}} cut",
			historyBriefMiss: "Wrong call",
			historyBriefBoom: "Detonated",
			cutSum: "Cut {{value}} ({{who}})",
			cutSumSelf: "self",
			logAccuseOk: "{{from}}’s accusation of {{to}} stands — weak link exposed",
			logAccuseFail: "{{from}}’s accusation of {{to}} failed",
			errDone: "This mission is over",
			errNotYourTurn: "Not your turn",
			errPending: "Finish the pending step first",
			errBadTarget: "You cannot point at yourself",
			errBadWire: "That wire does not exist or is already cut",
			errBadGuess: "Illegal call",
			errNoMatch: "You hold no uncut wire of that value",
			errNoSolo: "Not every remaining wire of that value is in your hand",
			errNotAllRed: "You may only reveal when all your remaining wires are red",
			errConstraint: "The constraint card forbids that",
			errEquipLocked: "That equipment is not unlocked yet",
			errEquipUsed: "That equipment is already used",
			errNoEquip: "That equipment is not in play",
			errNoPersonal: "Personal gadget unavailable",
			errNoPass: "You cannot pass right now",
			errOxygen: "Not enough oxygen",
			errSequence: "The Sequence card has not reached that value",
			errMath: "You must spend two number cards adding or subtracting to the called value",
			errXwire: "That X wire cannot be cut now",
			errCursed: "That value is cursed",
			errNano: "Nano is not there",
			errHandCard: "You do not hold that number card",
			errSetupToken: "That token cannot go on that wire",
			errClaim: "The same player cannot act twice in a row",
			errSqueak: "You cannot squeak right now",
			errMassCount: "Wrong number of wires",
			errMassValue: "Those wires are not the required value",
			errAccuse: "You cannot accuse right now",
			errPhase: "Still in the opening-token phase",
			errCharacter: "That character is unavailable",
			eqNeq: "Label ≠",
			eqNeqDesc: "Place the ≠ token between two adjacent wires of yours with different values",
			eqTalkies: "Walkie-talkies",
			eqTalkiesDesc: "Swap uncut wires with a teammate — each picks one of their own",
			eqTriple: "Triple detector",
			eqTripleDesc: "Dual Cut: call 1 value (not yellow) at 3 wires on one teammate rack — any hit succeeds",
			eqPostit: "Post-it",
			eqPostitDesc: "Place an info token in front of one of your blue wires",
			eqSuper: "Super detector",
			eqSuperDesc: "Dual Cut: call 1 value (not yellow) at a teammate’s whole rack — any hit succeeds",
			eqRewinder: "Rewinder",
			eqRewinderDesc: "Move the dial back 1 space",
			eqBatteries: "Emergency batteries",
			eqBatteriesDesc: "Flip 1-2 used character cards face up again",
			eqRadar: "General radar",
			eqRadarDesc: "Call a number 1-12; everyone answers whether they hold an uncut blue wire of it",
			eqStabilizer: "Stabilizer",
			eqStabilizerDesc: "This turn a failed Dual Cut costs nothing: no dial, no explosion",
			eqXyray: "X or Y ray",
			eqXyrayDesc: "Dual Cut: call 2 values (yellow allowed) at 1 wire — either hit succeeds; you must hold both values",
			eqCoffee: "Coffee thermos",
			eqCoffeeDesc: "Skip your turn and choose who acts next",
			eqEq: "Label =",
			eqEqDesc: "Place the = token between two adjacent wires of yours with equal values",
			eqFund: "Emergency fund",
			eqFundDesc: "Flip all used equipment cards back — they can be used again this mission",
			eqDisintegrator: "Disintegrator",
			eqDisintegratorDesc: "Draw a random value; everyone cuts all their remaining wires of it",
			eqSingleLabel: "Single thread label",
			eqSingleLabelDesc: "Place an x1 token in front of one of your blue wires",
			eqThreadCutter: "Thread cutter card",
			eqThreadCutterDesc: "Solo-cut 2 wires of a value even if they are not the last ones",
			eqGrapple: "Grapple",
			eqGrappleDesc: "Take one of a teammate’s wires into your rack without revealing it",
			eqDoubleFond: "Double fond",
			eqDoubleFondDesc: "Draw 2 equipment cards into play",
			charDd2000: "Double Detector",
			charDd2000Desc: "Dual Cut: call 1 value at 2 of a teammate’s wires — either hit succeeds; once per game",
			charXyray: "X/Y Ray Specialist",
			charXyrayDesc: "Personal gadget works like \"X or Y ray\"; once per game",
			charRadar: "Radar Operator",
			charRadarDesc: "Personal gadget works like \"General radar\"; once per game",
			charTalkies: "Radio Operator",
			charTalkiesDesc: "Personal gadget works like \"Walkie-talkies\"; once per game",
			charTriple: "Triple Detector 3000",
			charTripleDesc: "Personal gadget works like \"Triple detector\"; once per game",
			eqNeqShort: "Mark adjacent wires of different values ≠; one may be cut. Same-color red/yellow are equal.",
			eqTalkiesShort: "Swap one uncut wire each with a teammate; red and yellow may be swapped.",
			eqTripleShort: "Call a non-yellow value at 3 teammate wires; any match succeeds.",
			eqPostitShort: "Place an info token before one of your blue wires.",
			eqSuperShort: "Call a non-yellow value at a teammate’s full rack; any match succeeds.",
			eqRewinderShort: "Move the detonator dial back one space.",
			eqBatteriesShort: "Refresh 1–2 used character cards so their gadgets can be used again.",
			eqRadarShort: "Call 1–12; everyone reports if they have an uncut blue wire of it.",
			eqStabilizerShort: "This Dual Cut cannot advance the dial or explode; a miss still needs an info token.",
			eqXyrayShort: "Call 2 values you hold (yellow allowed) at one wire; either match succeeds.",
			eqCoffeeShort: "Skip your turn and choose the next player; play continues clockwise.",
			eqEqShort: "Place = across adjacent same-value wires; one may already be cut.",
			eqFundShort: "Refresh all used equipment cards for another use this mission.",
			eqDisintegratorShort: "Draw a random value; everyone cuts all their remaining wires of it.",
			eqSingleLabelShort: "Place ×1 before your blue wire: it is the only one of its value on your rack.",
			eqThreadCutterShort: "Solo-cut 2 same-value wires, even if more of that value remain.",
			eqGrappleShort: "Move one teammate wire to your rack face down; everyone sees its position.",
			eqDoubleFondShort: "Add 2 equipment cards; those already meeting the unlock value are ready.",
			charDd2000Short: "Call a value at 2 teammate wires; either hit succeeds. Once per mission.",
			charXyrayShort: "Call 2 values you hold at one wire; either hit succeeds. Once per mission.",
			charRadarShort: "Call a value; all report if they hold an uncut blue wire. Once per mission.",
			charTalkiesShort: "Swap one uncut wire each with a teammate. Once per mission.",
			charTripleShort: "Call a non-yellow value at 3 teammate wires; any hit works. Once per mission.",
			cA: "Only even wires may be cut",
			cB: "Only odd wires may be cut",
			cC: "Only wires 1-6 may be cut",
			cD: "Only wires 7-12 may be cut",
			cE: "Only wires 4-9 may be cut",
			cF: "Wires 4-9 may not be cut",
			cG: "No equipment or personal gadgets",
			cH: "No token on failure; token-marked wires cannot be cut",
			cI: "The rightmost wire of a teammate’s rack cannot be cut",
			cJ: "The leftmost wire of a teammate’s rack cannot be cut",
			cK: "No Solo Cuts",
			cL: "A failed cut advances the dial +2",
			ch1: "Declare a teammate’s wire red and cut it — if it is not red, the bomb explodes",
			ch2: "Four players in a row cut even values",
			ch3: "A rack’s uncut wires form only groups of 2",
			ch4: "The first 3 validation tokens sum to 18",
			ch5: "Two players in a row perform Solo Cuts",
			ch6: "At least 5 uncut wires on a rack are isolated",
			ch7: "Three players in a row cut consecutive values",
			ch8: "The first 2 validation tokens land on the drawn values",
			ch9: "A rack’s uncut blue wires are all odd (at least 6)",
			ch10: "A rack has 7+ cut wires but both ends uncut",
			tokOdd: "Odd",
			tokEven: "Even",
			wireBack: "Uncut wire",
			wireRed: "Red",
			wireBlue: "Blue",
			missionN: "Mission {{n}}",
			pickCover: "Cover one number card first",
			pickMath: "Pick two number cards that add or subtract to the called value",
			payToHint: "Tap a teammate panel to pass oxygen",
			giveCardHint: "Pick a card, then tap a teammate panel",
			forcedOnly: "Only \"{{value}}\" may be cut this turn",
			pickActor: "Choose a player to act",
			accuseHint: "Tap a player's panel, then name their constraint",
			endLeft: "Leftmost",
			endRight: "Rightmost",
			youAreWeak: "You are the weak link — secretly obey your constraint",
			nanoCarry: "Carrying {{n}} wires",
			myNumCards: "My number cards",
			infoNone: "No special rules",
			infoBlueRange: "Blue wires 1-{{max}} only",
			cursedAsRed: "counts as red — boom if cut",
			infoSequence: "Cut in order",
			infoNumCards: "Number cards",
			infoNumDeckLeft: "{{n}} left",
			infoDeckEquipPre: "Cut",
			infoDeckEquipPost: "to unlock an equipment",
			infoDeckTargetPre: "Cut this round",
			infoDeckSqueakPre: "Revealed:",
			infoDeckSqueakPost: "squeak!",
			infoDeckBossPre: "Boss flips",
			infoDeckPile: "Number deck",
			infoNumVisibleTick: "discard 1 per round",
			infoNumVisibleMath: "may combine with +/-",
			infoNumVisibleByValid: "validation adds a constraint",
			infoMassCut: "Mass action · cut all 4 of",
			infoNanoTrack: "Nano queue",
			infoHandLimit: "may only call these",
			oxygenPoolLeft: "Oxygen pool: {{n}} left",
			constraintLine: "Constraint {{id}} · {{text}}",
			constraintMine: "Your constraint {{id}} · {{text}}",
			constraintWho: "{{name}} · Constraint {{id}} · {{text}}",
			constraintSide: "Spare constraint {{id}} · {{text}}",
			constraintBadge: "Constr. {{id}}",
			weakLinkLine: "Weak link · {{text}}",
			challengeLine: "Challenge {{id}} · {{text}}",
			infoBonusPre: "Cut all four of",
			infoBonusPost: "to rewind the detonator by 1",
			squeakOpen: "\"{{value}}\" revealed — squeak!",
			squeakOpenCaptain: "\"{{value}}\" revealed — squeak, or tap a seat to designate!",
			setupAbsent: "Pick a value you do not have",
			setupFake: "Pick a value that does not match the wire (fake token)",
			logRadar: "{{name}} radar-scanned \"{{value}}\": {{yes}}",
			logRadarNoOne: "no one has it",
			radarBeatTitle: "Radar scan \"{{value}}\"",
			equipUnlock: "Cut 2 wires of \"{{v}}\" to unlock",
			m1name: "Training: Day 1",
			m1brief: "Tutorial, lesson one: cutting wires. Only blue wires 1-6 (4 copies each) are used; no red or yellow wires and no equipment.\nThe back of the card recaps the full Dual Cut and Solo Cut procedures — worth reading aloud before you start.",
			m2name: "Training: Day 2",
			m2brief: "Tutorial, lesson two: yellow wires. Blue wires expand to 1-8, and 2 yellow wires (values 1-7) enter play; no equipment yet.\nYellow wires cut like blue ones, and all yellow wires count as the same value: call \"yellow\" and point at a teammate’s wire — but you must hold a yellow wire yourself. If a yellow wire is wrongly named, place a yellow info token in front of it.",
			m3name: "Training: Day 3",
			m3brief: "Tutorial, lesson three: red wires and equipment. Blue wires expand to 1-10, and 1 red wire (value 1-9) enters play — cutting it explodes the bomb at once.\nNew action — Reveal Reds: when only red wires remain in hand at the start of your turn, you must reveal them all, and you are done.\nEquipment debuts: unusable at first, unlocked once 2 wires of its value are cut, each card usable once. Redraw the Coffee thermos and Label = if drawn.",
			m4name: "Boot Camp: Day 1",
			m4brief: "A full review with no new rules: all 48 blue wires, 1 red wire, 2 yellow wires, and randomly drawn equipment.\nWith 2 players: 4 yellow wires instead.",
			m5name: "Boot Camp: Day 2",
			m5brief: "Yellow wires first appear as \"2 out of 3\": take 3 yellow wires, mark their values with \"?\" tokens on the track, shuffle, mix 2 into the wire pile, and set the third aside unrevealed — you only know the yellows are two of three possible values.\nWith 2 players: 2 red wires.",
			m6name: "Boot Camp: Day 3",
			m6brief: "All 4 yellow wires count as the same value: usually cut in pairs with Dual Cuts, or Solo Cut them if you hold every yellow wire left in play (all 4, or the last 2).\nWith 2 players: 2 red wires.",
			m7name: "Training: Last Day",
			m7brief: "The red wire first appears as \"1 out of 2\": take 2 red wires, mark both values with \"?\" tokens, shuffle, mix 1 into the pile, and set the other aside unrevealed.\nWith 2 players: \"1 out of 3\" instead.",
			m8name: "Final Exam",
			m8brief: "The final exam: no new rules — apply everything from training. Red wires are \"1 out of 2\", yellow wires \"2 out of 3\".\nWith 2 players: red \"1 out of 3\" and 4 yellow wires.",
			m9name: "A Sense of Priorities",
			m9brief: "Shuffle and draw 3 number cards face up in a row; place the Sequence card (side A) on the leftmost. You cannot cut values b or c before 2 wires of value a are cut, nor value c before 2 of b; flip a finished card and shift the Sequence card rightward. Values outside the queue are always free.\nWith 2 players: 2 red and 4 yellow wires.",
			m10name: "A Bad Quarter of an Hour",
			m10brief: "A real-time mission: start a 15-minute timer once setup is done — time out and the bomb explodes.\nTurns no longer go clockwise: the first player to call \"Quack!\" becomes the active player; wait for the current turn to end before calling; the same player cannot act twice in a row (except with 2 players). Redraw the Coffee thermos if drawn.\nWith 2 players: 12 minutes.",
			m11name: "Blue on Red, Nothing Moves",
			m11brief: "Draw 1 number card face up: the 4 wires of its value count as red for the whole mission — cutting one explodes the bomb, and they may only be revealed when they are the only wires left in hand at the start of a turn. Redraw the equipment of the same number if drawn.\nWith 2 players: 4 yellow wires, and the Captain places no opening info token.",
			m12name: "Equipment Out of Reach",
			m12brief: "Place a face-up number card on each equipment in play: to unlock an equipment, cut 2 wires of its own value and 2 of the number card on it, in any order.\nThe 2 equipment entering via Double fond each get a number card too; remove it at once if that value already has 2 wires cut.\nWith 2 players: 2 red and 4 yellow wires.",
			m13name: "Red Alert!",
			m13brief: "The 3 red wires are not shuffled in: deal them face down clockwise from the Captain (with 2 players, the Captain gets 2, one per rack). Opening info tokens are drawn at random; redraw a yellow token.\nMass Call: name the 3 red wires among the uncut wires and cut them all at once — if any is not red, the bomb explodes. With 4-5 players you may attempt it holding no red. A player holding only red wires must attempt it.\nWith 2 players: the Captain places no opening info token.",
			m14name: "High Risk Mine Clearance",
			m14brief: "Whoever holds the Captain character card is the Intern for this mission: if the Intern fails a Dual Cut, the bomb explodes at once. The Stabilizer is not available.\nWith 2 players: 3 red and 4 yellow wires.",
			m15name: "Mission to Novosibirsk",
			m15brief: "Equipment enters play face down, identities unknown. Stack the 12 number cards face down and flip the first: when all 4 wires of the showing value are cut, flip one equipment card — usable at once, whatever its number — then flip the next number card, and so on.\nIf a flipped number card’s value is already fully cut, skip to the next card without flipping equipment.\nWith 2 players: red \"2 out of 3\".",
			m16name: "A Story of Common Sense",
			m16brief: "The Sequence card returns on side B: you cannot cut values b or c before all 4 wires of value a are cut, nor value c before all 4 of b; flip a finished card and shift the Sequence card rightward. Values outside the queue are always free.\nWith 2 players: 2 red and 4 yellow wires.",
			m17name: "Sergio El Mytho",
			m17brief: "Whoever holds the Captain character card becomes Sergio: they return the card and have no personal equipment.\nSergio places 2 false info tokens at setup (the values must not match; never in front of a red wire), and every info token he places this mission is false. When a Dual Cut fails on Sergio’s rack, he places a token of the called value — false again. He cannot use equipment, but still joins the effects of the Walkie-talkies and the General radar.\nWith 2 players: 3 red wires.",
			m18name: "BAT Helping Hand",
			m18brief: "The General radar is the only equipment, and it stays available all mission; no opening info tokens. The number cards form a face-down deck.\nEach turn the active player: flips the top number card, uses the General radar on that value, then designates a player (possibly themselves) to cut that value. Discard a card once its 4 wires are cut; reshuffle an empty deck.\nReminder: as in every mission, recalling answers from previous radar scans is forbidden — memorize well.\nWith 2 players: 3 red wires.",
			m19name: "In the Villain’s Lair",
			m19brief: "A story mission: you have finally found the Mad Scientist’s secret lair. No special rules — defuse as usual.\n(The original card plays an audio track here; the online edition does not.)",
			m20name: "The Big Bad Wolf",
			m20brief: "The last wire dealt to each rack is not sorted: it sits at the far right with an X token in front. X wires can be cut normally, but equipment can never target them, and all equipment — personal equipment, the Super detector and the General radar included — ignores them. Redraw the Walkie-talkies if drawn.\nWith 2 players: red \"2 out of 3\" and 4 yellow wires.",
			m21name: "Kouign Amann Mortal",
			m21brief: "Parity tokens replace info tokens for the whole mission — setup, failed cuts and the Post-it included: information is odd or even, never the value.\nNote: a red wire has no value, so it is neither odd nor even.\nWith 2 players: 2 red wires.",
			m22name: "None of That in My House!",
			m22brief: "At setup, each player chooses 2 info tokens of values they do NOT hold (yellow allowed) and places them beside their rack — one per rack for two-rack players, fewer if they lack 2 missing values.\nAs soon as the first 2 yellow wires are cut: starting with the Captain and going clockwise, each player takes one info token from the board and gives it to their left neighbor, who places it correctly (or beside the rack if they lack the value).",
			m23name: "Mission in Sevenans",
			m23brief: "No equipment is drawn; instead form a face-down pile of 7 equipment cards, and reveal 1 random number card.\nMass Call: name all 4 wires of that value and cut them at once — no equipment, no Double Detector, and allowed even holding none yourself; failure explodes the bomb. Before each of the Captain’s turns, discard 1 card from the pile until the Mass Call is done; then all remaining equipment becomes usable.\nWith 2 players: red \"2 out of 3\".",
			m24name: "The Count Is Good!",
			m24brief: "Count tokens (x1/x2/x3) replace info tokens all mission — setup, failed cuts and the Post-it included: they report how many times the value appears on the rack, cut wires counting too. x2/x3 may sit in front of any wire of that value; never in front of red wires.\nException: a Post-it token may be placed in front of a wire already cut.\nWith 2 players: 3 red wires.",
			m25name: "To Hear You Better",
			m25brief: "A silence mission: players may not say any number aloud — spelling, gestures or \"the days in a week\" are allowed; a slip advances the dial 1 notch.\n(Silence cannot be enforced online, so this plays as a normal mission.)\nWith 2 players: 3 red wires.",
			m26name: "Speak of the Wolf",
			m26brief: "All 12 number cards lie face up. Each turn the active player first flips any still-visible card face down, then must cut that value — only visible values may be cut. When none remain visible, flip them all face up again; remove a card once its 4 wires are cut.\nIf the active player holds no wire of a visible value, they pass without moving the dial. Redraw the X or Y ray if drawn.",
			m27name: "Dough Threads",
			m27brief: "No character cards this mission, so no personal equipment; redraw the Emergency batteries if drawn.\nAs soon as the first 2 yellow wires are cut: reveal as many info tokens as players; starting with the Captain and going clockwise, each player takes one and places it correctly (or beside the rack if they lack the value).\nWith 2 players: the Captain places no opening info token.",
			m28name: "Captain Lazy",
			m28brief: "The Captain becomes Captain Lazy: he returns his character card, has no personal equipment, and cannot use equipment cards; if he fails a Dual Cut, the bomb explodes at once. He still joins the effects of the Walkie-talkies and the General radar.\nWith 2 players: 3 red and 4 yellow wires.",
			m29name: "Number Error",
			m29brief: "Deal each player 2 number cards face down (3 to the Captain’s right neighbor); stack the rest. Each turn: the active player’s right neighbor places one of their cards face down; the active player acts normally; the card is revealed — if they cut that value this turn, the dial advances 1 notch; then the active player takes the card into hand.\nDiscard a card once its value’s 4 wires are cut; a player down to 1 card draws another (redraw if that value is done); when only one value remains, discard the last card.\nWith 2 players: the Captain places no opening info token.",
			m31name: "To Each Their Own Constraint",
			m31brief: "Constraint cards A-E lie face up; starting with the Captain and going clockwise, each player chooses one and the rest are discarded. Everyone obeys their own constraint; a player who can no longer satisfy theirs at the start of a turn flips it over and plays normally from then on.\nWith 2 players: avoid the A+B and C+D combinations.",
			m32name: "Prank Attack!",
			m32brief: "Stack the 12 constraint cards face down and flip the first; everyone obeys the visible constraint. At the start of the Captain’s turn, after discussion, the team may replace it with the next card.\nA player unable to act declares it and passes (the dial does not move). Constraints never apply to Reveal Reds.\nWith 2 players: 3 red wires.",
			m33name: "What Happens in Vegas",
			m33brief: "Same as mission 21: parity tokens replace info tokens all mission (setup, failed cuts and Post-it included). A red wire is neither odd nor even.\nWith 2 players: 3 red wires.",
			m34name: "The Weak Link",
			m34brief: "Deal each player a face-down character card (the Captain card included) and a face-down constraint card (A-E); everyone peeks at both. Whoever holds the Captain card is the Weak Link: only they must obey their constraint, in secret — everyone still reads their cards to keep it hidden.\nWhile character cards stay hidden, nobody has personal equipment. If the Weak Link cannot act, the dial advances 2 notches and everyone redraws both cards. At the start of their turn, another player may accuse — name the person and their constraint, without consulting: a wrong accusation advances the dial 1 notch; a correct one flips all character cards up, restoring personal equipment and ending the constraint.\nNot playable with 2 players.",
			m35name: "No Ties, Single Thread",
			m35brief: "Before mixing, deal each player 1 face-down blue wire per rack: unsorted, fixed at the far right, with an X token in front. X wires can be cut normally, but only after all 4 yellow wires are cut; equipment can never target them, and all equipment — personal equipment, the Super detector and the General radar included — ignores them. Redraw the Walkie-talkies if drawn.\nWith 2 players: 3 red and 4 yellow wires.",
			m36name: "Panic in the Tropics",
			m36brief: "Draw 5 number cards face up in a row; the Captain, without consulting, places the Sequence card (side A) at either end, arrow pointing along the row.\nQueued values must be cut in arrow order: whenever a player cuts 2 wires of the head value, they remove that card and may, without consulting, move the Sequence card to either end. Values outside the queue are always free.\nWith 2 players: red \"2 out of 3\" and 4 yellow wires.",
			m37name: "The Boss of the Farce!",
			m37brief: "Stack the 12 constraint cards face down and flip the first; everyone obeys the visible constraint, and each time a value’s 4 wires are all cut, the next constraint replaces it.\nA player unable to act passes (the dial does not move); but if nobody can act for a whole round, the dial advances 1 notch and the constraint is replaced. Once the deck runs out, no constraint applies. Constraints never apply to Reveal Reds.\nWith 2 players: 3 red wires.",
			m38name: "One Thread Upside Down",
			m38brief: "While dealing, the Captain places one of their wires upside down at one end of a rack — value facing the teammates, unseen by themself. Only the Captain may cut it, with a normal cutting action, and failure explodes the bomb.\nOther players cannot cut it; if it is their only option, they pass and the dial advances 1 notch. No equipment or personal equipment may be used on it.\nWith 2 players: 3 red wires.",
			m39name: "The Doctor’s Four Sons Walk",
			m39brief: "No equipment on the board. Reveal 1 random number card on the first equipment slot; stack 8 more face down. Opening info tokens are drawn at random (redraw a yellow).\nMass Call: name and cut all 4 wires of the revealed value at once — no personal equipment, allowed even holding none; failure explodes the bomb. Before each of the Captain’s turns, discard 1 card from the deck until the Mass Call is done.\nOnce it is done, deal the remaining deck face down to everyone, clockwise from the Captain: each player places info tokens matching the values received (skip exhausted values).\nWith 2 players: 3 red and 4 yellow wires.",
			m40name: "Christmas Trap",
			m40brief: "Info tokens come in two alternating families: count tokens (x1/x2/x3) and parity tokens. The Captain uses count tokens, their left neighbor parity tokens, and so on around the table. Count tokens follow mission 24 rules (cut wires count; x2/x3 may sit in front of any wire of the value; the Post-it may sit in front of a cut wire). Neither family may be placed in front of red wires.\nWith 2 players: the Captain places no token; the second player places 1 parity token.",
			m41name: "Bomba Latina",
			m41brief: "The yellow wires are IBERIAN wires: not shuffled in, dealt face down, 1 per player (the Captain gets none with 5 players); their number equals the player count, at most 4. The dial starts closer to the skull; opening info tokens are drawn at random; redraw Double fond if drawn.\nIBERIAN wires are cut one by one. Special action: point at a teammate’s wire and declare \"this is an IBERIAN wire\" — a hit reveals it and moves the dial back 1 notch; a miss places an info token and advances the dial 1 notch. A player holding only their IBERIAN wire (and reds) passes.\nWith 2 players: red \"2 out of 3\" and 2 yellow wires.",
			m43name: "Nano and Robot",
			m43brief: "Nano the robot stands on space 1 of the track; while dealing, stack wires on it sight unseen (5 with 2 players, 4 with 3-4, 3 with 5).\nAt the end of each turn Nano moves 1 space forward, turning back at 12. When the active player cuts wires of the value Nano stands on, they take 1 wire from the robot, unseen, and insert it correctly into a rack of theirs. To win, every wire — Nano’s included — must be cut (or revealed, for reds). The Coffee thermos does not stop Nano.\nWith 2 players: the Captain draws the opening info token at random.",
			m44name: "Underwater Pressure",
			m44brief: "The oxygen pool holds 2 tokens per player, in the reserve. Before a cutting action, pay oxygen from the reserve by zone: 1 token for values 1-4, 2 for 5-8, 3 for 9-12. At the start of the Captain’s turn each round, all tokens return to the reserve. A player short of oxygen passes and the dial advances 1 notch.\nRedraw the X or Y ray if drawn; the X or Y ray character is not used.\n(The original underwater no-talking rule is not enforced online.)",
			m45name: "My Thread, My Battle!",
			m45brief: "A semi-real-time mission: the number cards form a face-down deck; each turn the Captain flips the top card, and the first player to call \"Squeak!\" (the Captain included) cuts that value. A wrong call or any hint (such as \"I’m not sure...\") advances the dial 1 notch.\nIf nobody volunteers, the Captain designates someone; a designee lacking the value places an info token of their choice and the dial advances 1 notch. A player holding only red wires may call \"Squeak!\" at any time to reveal them. Discard a card once its 4 wires are cut; reshuffle an empty deck. Redraw the X or Y ray and Coffee thermos if drawn; the X or Y ray character is not used.\nWith 2 players: 3 red wires.",
			m46name: "Agent 007",
			m46brief: "The 4 yellow wires are fixed (values 5-8), and the four 7s must be cut last.\nMass Call: a player holding only 7s at the start of their turn must cut all four 7s at once — failure explodes the bomb. Naming a 7 earlier is a normal failure (info token placed, dial advances 1 notch). Redraw the Emergency batteries if drawn.\nWith 2 players: the Captain places no opening info token.",
			m47name: "The Bill, Please!",
			m47brief: "All 12 number cards lie face up. To cut, choose 2 cards whose sum or difference equals the target value, then discard them — for example 3 and 9 to cut 12, or 10 and 3 to cut 7.\nWhen no cards remain visible, take back all 12 and spread them again. A player unable or unwilling to act discards 2 cards of their choice and the dial advances 1 notch. Redraw the X or Y ray if drawn; the X or Y ray character is not used.\nWith 2 players: 3 red wires.",
			m48name: "3-Wire Plan",
			m48brief: "The 3 yellow wires are not shuffled in: deal them face down clockwise from the Captain (with 2 players, the Captain gets 2, one per rack). Yellow wires cannot be cut normally.\nMass Call: cut the 3 yellow wires simultaneously; with 4-5 players this is allowed even without holding any yellow. On failure, every designated wire still gets an info token, but the dial advances only 1 notch.\nWith 2 players: 3 red and 3 yellow wires.",
			m49name: "Bottles in the Sea",
			m49brief: "Oxygen is dealt out openly: 7 each with 2 players, 6 with 3, 5 with 4, 4 with 5. Before a cutting action, give oxygen tokens equal to the called value to any one teammate (not necessarily the one you are cutting).\nA player short of oxygen passes and the dial advances 1 notch. Redraw the X or Y ray if drawn; the X or Y ray character is not used.\n(The original underwater no-talking rule is not enforced online.)\nWith 2 players: 3 red wires.",
			m50name: "The Black Sea",
			m50brief: "No red/yellow markers and no validation tokens this mission: memorize the red and yellow values before mixing.\nInfo tokens are placed beside the rack, not in front of a wire — point out which wire each token refers to, and remember it yourselves; failed-cut tokens go beside the rack too. Players may not relay each other’s memorized information; equipment works normally.\nWith 2 players: 3 red and 4 yellow wires.",
			m51name: "Unlucky Day",
			m51brief: "The dial starts 1 notch back (more forgiving). The number cards form a face-down deck.\nEach turn the active player is the boss: they flip the top number card and, without consulting, designate a player (possibly themselves) to cut that value. A designee lacking the value places an info token of their choice and the dial advances 1 notch. Discard a card once its 4 wires are cut; reshuffle an empty deck. Redraw the X or Y ray if drawn; the X or Y ray character is not used.\nWith 2 players: 2 red wires, and the Captain places no opening info token.",
			m52name: "All Traitors!",
			m52brief: "Every info token this mission is false — it means \"this wire is NOT that value\". At setup, each player places 2 false tokens (the values must not match; they may point at blue or red wires). When a Dual Cut fails, the targeted player places a token of the called value in front of the designated wire — false again. Redraw Label ≠ and Label = if drawn.\nWith 2 players: 3 red and 4 yellow wires.",
			m53name: "Nano Is Back",
			m53brief: "The dial is not used this mission; redraw the Rewinder and the Stabilizer if drawn. Nano stands just before space 1.\nAt the end of each turn, Nano moves: 1 space forward on a successful cut, 1 back when wires of the value Nano stands on are cut, 2 forward on a failed cut. If Nano goes past space 12, the bomb explodes.\nWith 2 players: 3 red wires.",
			m55name: "Doctor No’s Challenge",
			m55brief: "Reveal as many random challenge cards as players; the dial starts closer to the skull.\nChallenges are personal or team-wide, with the condition on the card; each completed challenge is discarded and moves the dial back 1 notch.\nWith 2 players: red \"2 out of 3\".",
			m56name: "The Rebel Sons",
			m56brief: "While dealing, each player places one of their wires upside down at one end of a rack — value facing the teammates, unseen. Each player must cut their own upside-down wire with a normal cutting action; failure explodes the bomb. No equipment or personal equipment may be used on it.\nYou may Dual Cut a teammate’s upside-down wire, but the dial advances 1 notch.\nWith 2 players: 3 red wires.",
			m57name: "Mission Impossible",
			m57brief: "All 12 number cards lie face up, each with a random face-down constraint card beside it. Each time a validation token is placed, the constraint of that number comes into play, replacing the previous one — only one constraint is ever active.\nA player unable to act passes (the dial does not move); if nobody can act for a whole round, the bomb explodes. Constraints never apply to Reveal Reds. Redraw the Disintegrator if drawn.\nWith 2 players: 2 red wires.",
			m58name: "System D",
			m58brief: "No info tokens at all this mission, including at setup; a failed cut reveals nothing about the targeted wire. In return, every player’s Double Detector works every turn, without limit.\nRedraw the Post-it and Emergency batteries if drawn; the new characters are not used.\nWith 2 players: 3 red wires.",
			m59name: "Nano to the Rescue",
			m59brief: "The 12 number cards lie face up in a random row; Nano stands on the 7, facing the higher values. Before cutting, move Nano forward (never backward) onto a card matching one of your wire values, then cut that value; afterwards you may reorient Nano freely.\nIf you cannot act with the values available to you, flip Nano over and advance the dial 1 notch, then act as normal. Flip a card face down once its 4 wires are cut; the Coffee thermos skips the whole turn instead. Redraw the X or Y ray if drawn; the X or Y ray character is not used.\nWith 2 players: 3 red wires.",
			m60name: "The Return of Doctor No",
			m60brief: "Same as mission 55: reveal as many random challenge cards as players, the dial starts closer to the skull, and each completed challenge is discarded and moves the dial back 1 notch.\nWith 2 players: 3 red wires.",
			m61name: "Quiet, We’re Filming!",
			m61brief: "Each player receives a random face-up constraint card from A-E (with 2 players, add 2 more beside the Captain, left and right; with 3, add 1 to the Captain’s left). Everyone obeys their own constraint; a player who cannot act passes (the dial does not move) — but if everyone passes for a whole round, the bomb explodes.\nBefore each of the Captain’s turns, the team may agree to rotate all constraint cards one seat, clockwise or counterclockwise. At any time, a player may discard their constraint and draw a random one from F-L, at the cost of 1 dial notch. Constraints never apply to Reveal Reds.\nWith 2 players: 2 red wires.",
			m62name: "Armageddon Dumpling",
			m62brief: "Reveal as many random number cards as players; the dial starts closer to the skull. Each time all 4 wires of a visible number card’s value are cut, the dial moves back 1 notch.\nWith 2 players: 3 red wires.",
			m63name: "Titanic II",
			m63brief: "The Captain holds the oxygen pool: 14 tokens with 2 players, 18 with 3, 24 with 4, 30 with 5. Before a cutting action, place oxygen equal to the called value into the reserve. At the end of a turn, all remaining oxygen passes to the left neighbor; at the start of the Captain’s turn each round, the Captain takes back everything from the reserve (if the Captain does not act or uses the Coffee thermos, the next player takes over).\nA player short of oxygen passes and the dial advances 1 notch. Redraw the X or Y ray if drawn; the X or Y ray character is not used.\n(The original underwater no-talking rule is not enforced online.)\nWith 2 players: 3 red wires.",
			m64name: "The Return of the Rebel Sons!",
			m64brief: "While dealing, each player places 2 wires upside down — values facing the teammates, unseen — and, guided by a teammate, puts the smaller one at the far left and the larger at the far right. Each player must cut their own upside-down wires with normal cutting actions, without equipment or the Double Detector; failure explodes the bomb.\nYou may Dual Cut a teammate’s upside-down wire, but the dial advances 1 notch.\nWith 2 players: 2 red wires.",
			m65name: "Good Thread and Not Good Thread",
			m65brief: "Deal the 12 number cards out face up among the players (with 5 players, the Captain and their left neighbor get one extra): you may only cut values shown on your own cards; holding no wire of your values, you pass and the dial advances 1 notch.\nAt the end of a turn, the active player must give one of their number cards to any teammate. Flip a card face down once its 4 wires are cut — it can still be given away; the Coffee thermos skips the whole turn. Redraw the X or Y ray if drawn; the X or Y ray character is not used.\nNot playable with 2 players."
		}
	}
};
//#endregion
export { vr as default };
