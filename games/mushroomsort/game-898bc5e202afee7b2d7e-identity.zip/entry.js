import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useFxAnchor as r } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as i, useT as a } from "@bgparty/sdk/i18n";
import { GameScreen as o } from "@bgparty/sdk/ui/game-screen";
import { AVATARS as s } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as c } from "@bgparty/sdk/player-colors";
import { seatName as l } from "@bgparty/sdk/ui/player-strip";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { Floater as p, FlySprite as m, PulseBox as h } from "@bgparty/sdk/fx/primitives";
import { OptionSwitch as g } from "@bgparty/sdk/ui/game-options";
//#region src/games/mushroomsort/data.ts
var _ = [
	"#cf3e42",
	"#2689bb",
	"#d2b51c",
	"#303d3e"
], v = [
	"games.mushroomsort.red",
	"games.mushroomsort.blue",
	"games.mushroomsort.yellow",
	"games.mushroomsort.black"
], y = {
	four: "games.mushroomsort.four",
	full: "games.mushroomsort.full",
	straight: "games.mushroomsort.straight",
	three: "games.mushroomsort.three",
	mini: "games.mushroomsort.mini",
	pair: "games.mushroomsort.pair",
	mixed: "games.mushroomsort.mixed"
}, ee = [
	"four",
	"full",
	"straight",
	"three",
	"mini",
	"pair",
	"mixed"
], b = (e) => e % 8 + 1, x = (e) => Math.floor(e / 8), S = (e) => +(b(e) === 3 || b(e) === 6), C = (e) => e === 2 ? 5 : e === 3 ? 7 : 8, w = (e) => Array.from({ length: 32 }, (e, t) => t).filter((t) => b(t) <= C(e)), T = (e) => [...e].sort((e, t) => b(e) - b(t));
function E(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(b(n), (t.get(b(n)) ?? 0) + 1);
	let n = [...t.values()].sort((e, t) => t - e), r = [...t.keys()].sort((e, t) => e - t), i = 0, a = 0, o = -2;
	for (let e of r) i = e === o + 1 ? i + 1 : 1, a = Math.max(a, i), o = e;
	return n[0] === 4 ? {
		kind: "four",
		strength: 1
	} : n[0] === 3 && n[1] === 2 ? {
		kind: "full",
		strength: 2
	} : a >= 5 ? {
		kind: "straight",
		strength: 3
	} : n[0] === 3 ? {
		kind: "three",
		strength: 4
	} : a >= 4 ? {
		kind: "mini",
		strength: 4
	} : n[0] >= 2 ? {
		kind: "pair",
		strength: 5
	} : {
		kind: "mixed",
		strength: 6
	};
}
function D(e, t, n) {
	return t > 1 || n === 2 && t === 1 ? 0 : (n === 4 ? {
		four: [5, 4],
		full: [4, 2],
		straight: [3, 2],
		three: [3, 2],
		mini: [3, 1],
		pair: [2, 1],
		mixed: [2, 1]
	} : {
		four: [5, 3],
		full: [3, 2],
		straight: [3, 1],
		three: [3, 1],
		mini: [3, 1],
		pair: [2, 1],
		mixed: [2, 1]
	})[e][t];
}
//#endregion
//#region src/games/mushroomsort/meta.ts
var O = {
	id: "mushroomsort",
	tier: "alpha",
	nameKey: "games.mushroomsort.name",
	descKey: "games.mushroomsort.desc",
	rulesKey: "games.mushroomsort.rules",
	icon: "🍄",
	iconImg: "games/mushroomsort.webp",
	rulesUrl: { en: "https://ayatsurare.tokyo/download/mushroom-sort-rulesenglish/?wpdmdl=1161" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3, 4],
	mechanics: [
		"deduction",
		"drafting",
		"set-collection"
	],
	interactionTags: [],
	accent: "#397e67",
	releasedAt: "2026-11-10T23:38:01+08:00",
	search: {
		py: "",
		init: ""
	},
	hotseat: "cover"
}, k = t.int().min(0).max(31), A = t.string(), j = t.enum(["mushroom", "pot"]), M = t.object({ pig: t.boolean().default(!1) }).prefault({}), N = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("prepare"),
		center: k.nullable(),
		order: t.array(k).min(6).max(8)
	}),
	t.object({
		type: t.literal("claim"),
		slot: t.string(),
		token: j
	}),
	t.object({
		type: t.literal("predict"),
		guesses: t.record(A, t.int().min(1).max(8))
	}),
	t.object({ type: t.literal("next") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), P = t.object({
	id: t.string(),
	owner: A.nullable(),
	index: t.int().nonnegative(),
	zone: t.enum(["row", "center"]),
	suit: t.int().min(0).max(3),
	face: k.nullable(),
	claimedBy: A.nullable(),
	token: j.nullable(),
	collected: t.boolean(),
	blocked: t.boolean()
}), F = t.object({
	rid: A,
	cards: t.array(k),
	kind: t.enum([
		"four",
		"full",
		"straight",
		"three",
		"mini",
		"pair",
		"mixed"
	]),
	strength: t.int(),
	stars: t.int(),
	points: t.int(),
	pigPoints: t.int(),
	pig: t.boolean(),
	place: t.int()
}), I = t.object({
	players: t.array(A),
	round: t.int(),
	start: A,
	phase: t.enum([
		"prepare",
		"gather",
		"predict",
		"awaitReveal",
		"reveal",
		"collect",
		"score",
		"roundEnd",
		"done"
	]),
	actor: A.nullable(),
	ready: t.array(A),
	slots: t.array(P),
	hands: t.array(t.object({
		rid: A,
		suit: t.int().min(0).max(3),
		face: k.nullable()
	})),
	previewSuits: t.array(t.int().min(0).max(3)),
	picks: t.record(A, t.int()),
	potUsed: t.array(A),
	basketFlipped: t.array(A),
	pigEnabled: t.boolean(),
	pigBy: A.nullable(),
	pigToken: j.nullable(),
	guesses: t.record(A, t.int()).nullable(),
	collected: t.array(A),
	soups: t.record(A, t.array(k)),
	scores: t.record(A, t.int()),
	results: t.array(F),
	history: t.array(t.object({
		round: t.int(),
		results: t.array(F)
	})),
	nextReady: t.array(A)
}), L = t.object({
	initial: t.array(k),
	known: t.record(t.string(), k),
	hand: k.nullable(),
	prepared: t.boolean()
}), R = {
	claim: 440,
	reveal: 850,
	collect: 650,
	score: 850
}, z = (e, t) => `row:${e}:${t}`;
function B(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function V(e) {
	let t = e.players.length, n = B(e, w(t));
	if (e.centers = [], t === 2) {
		for (let t = 0; t < 4; t++) {
			let r = n.findIndex((e) => x(e) === t);
			e.centers.push({
				owner: null,
				card: n.splice(r, 1)[0]
			});
		}
		n = B(e, n);
	}
	e.initial = Object.fromEntries(e.players.map((e) => [e, []]));
	let r = t === 3 ? 8 : 7;
	for (let i = 0; i < r; i++) for (let r = 0; r < t; r++) e.initial[e.players[(e.startIndex + r) % t]].push(n.shift());
	for (let t of e.players) e.initial[t] = T(e.initial[t]);
	e.remaining = n, e.rows = {}, e.hands = {}, e.ready = [], e.claims = {}, e.picks = Object.fromEntries(e.players.map((e) => [e, 0])), e.potUsed = [], e.basketFlipped = [], e.pig = null, e.guesses = null, e.collected = [], e.results = [], e.nextReady = [], e.turn = 0, e.phase = "prepare";
}
function H(e, t, n) {
	let r = {
		players: [...t],
		seed: n,
		cursor: 0,
		config: { pig: e.pig && t.length > 2 },
		round: 1,
		startIndex: 0,
		phase: "prepare",
		turn: 0,
		initial: {},
		rows: {},
		centers: [],
		hands: {},
		remaining: [],
		ready: [],
		claims: {},
		picks: {},
		potUsed: [],
		basketFlipped: [],
		pig: null,
		guesses: null,
		collected: [],
		results: [],
		history: [],
		scores: Object.fromEntries(t.map((e) => [e, 0])),
		nextReady: []
	};
	return V(r), {
		state: r,
		fx: t.map((e, t) => ({
			kind: "deal",
			rid: e,
			data: { count: r.initial[e].length },
			...t ? { with: !0 } : {}
		}))
	};
}
function te(e) {
	return e.phase === "gather" ? e.players[(e.startIndex + e.turn) % e.players.length] : e.phase === "predict" ? e.pig.rid : null;
}
function U(e) {
	let t = [
		"reveal",
		"collect",
		"score",
		"roundEnd",
		"done"
	].includes(e.phase), n = [], r = (r, i, a, o, s) => {
		let c = e.claims[r], l = o === "row" && e.players.length === 2 ? z(e.players.find((e) => e !== i), 6 - a) : "";
		n.push({
			id: r,
			owner: i,
			index: a,
			zone: o,
			suit: x(s),
			face: c && (c.token === "mushroom" || t) ? s : null,
			claimedBy: c?.rid ?? null,
			token: c?.token ?? null,
			collected: !!c && e.collected.includes(c.rid),
			blocked: !!e.claims[l]
		});
	};
	for (let t of e.players) (e.rows[t] ?? e.initial[t]).forEach((e, n) => r(z(t, n), t, n, "row", e));
	return e.centers.forEach((e, t) => r(`center:${t}`, e.owner, t, "center", e.card)), n;
}
function W(e, t) {
	if (e.phase !== "gather" || e.actor !== t) return [];
	let n = e.slots.filter((n) => !n.claimedBy && !n.blocked && (n.zone === "center" ? e.players.length === 2 || e.picks[t] === 3 : n.owner !== t)).map((e) => e.id);
	return e.pigEnabled && !e.pigBy && n.push("pig"), n;
}
function G(e, t) {
	if (t.startsWith("center:")) return e.centers[Number(t.split(":")[1])].card;
	let n = U(e).find((e) => e.id === t);
	return e.rows[n.owner][n.index];
}
function K(e, t) {
	return T([e.hands[t], ...Object.entries(e.claims).filter(([, e]) => e.rid === t).map(([t]) => G(e, t))]);
}
function q(e) {
	let t = e.players.map((t) => {
		let n = K(e, t);
		return {
			rid: t,
			cards: n,
			...E(n),
			stars: n.reduce((e, t) => e + S(t), e.basketFlipped.includes(t) ? 0 : 2),
			points: 0,
			pigPoints: 0,
			pig: e.pig?.rid === t,
			place: 0
		};
	}), n = (t) => (e.players.indexOf(t) - e.startIndex + e.players.length) % e.players.length;
	t.sort((e, t) => e.strength - t.strength || t.stars - e.stars || n(t.rid) - n(e.rid)), t.forEach((t, n) => {
		t.place = n + 1, t.points = e.pig?.rid === t.rid ? 0 : D(t.kind, n, e.players.length), e.pig?.rid === t.rid && e.guesses && e.players.filter((e) => e !== t.rid).every((t) => e.guesses[t] === b(e.hands[t])) && (t.pigPoints = e.players.length - 1), e.scores[t.rid] += t.points + t.pigPoints;
	}), e.results = t, e.history.push({
		round: e.round,
		results: t
	}), e.phase = e.round === e.players.length ? "done" : "roundEnd";
}
function J(e, t, { by: n }) {
	let r = { code: "games.mushroomsort.invalid" };
	if (t.type !== "tick" && !e.players.includes(n)) return r;
	if (t.type === "tick") {
		if (![
			"awaitReveal",
			"reveal",
			"collect",
			"score"
		].includes(e.phase)) return { state: e };
		let t = structuredClone(e);
		if (t.phase === "awaitReveal") return t.phase = "reveal", {
			state: t,
			fx: [{
				kind: "reveal",
				data: { cards: U(t).filter((e) => e.claimedBy).map((e) => e.id) }
			}]
		};
		if (t.phase === "reveal" || t.phase === "collect") {
			let e = t.players[(t.startIndex + t.collected.length) % t.players.length], n = Object.entries(t.claims).filter(([, t]) => t.rid === e).map(([e]) => e);
			return t.collected.push(e), t.phase = t.collected.length === t.players.length ? "score" : "collect", {
				state: t,
				fx: [{
					kind: "collect",
					rid: e,
					data: {
						from: n,
						cards: n.map((e) => G(t, e)),
						hand: t.hands[e]
					}
				}]
			};
		}
		return q(t), {
			state: t,
			fx: [{
				kind: "score",
				data: { points: Object.fromEntries(t.results.map((e) => [e.rid, e.points + e.pigPoints])) }
			}]
		};
	}
	if (t.type === "prepare") {
		if (e.phase !== "prepare" || e.ready.includes(n)) return r;
		let i = e.initial[n], a = t.center === null ? t.order : [...t.order, t.center];
		if (e.players.length === 2 != (t.center === null) || a.length !== i.length || new Set(a).size !== a.length || a.some((e) => !i.includes(e)) || t.order.some((e, n) => n > 0 && b(t.order[n - 1]) > b(e))) return r;
		let o = structuredClone(e);
		if (o.rows[n] = t.order, o.ready.push(n), t.center !== null && o.centers.push({
			owner: n,
			card: t.center
		}), o.ready.length === o.players.length) {
			for (let e = 0; e < o.players.length; e++) o.hands[o.players[(o.startIndex + e) % o.players.length]] = o.remaining.shift();
			o.remaining.length && o.centers.push({
				owner: null,
				card: o.remaining.shift()
			}), o.phase = "gather";
		}
		return {
			state: o,
			fx: [{
				kind: "prepare",
				rid: n,
				data: {
					central: t.center !== null,
					suit: t.center === null ? 0 : x(t.center)
				}
			}]
		};
	}
	if (t.type === "claim") {
		let i = Y(e, n).public;
		if (!W(i, n).includes(t.slot) || t.token === "pot" && e.potUsed.includes(n) || t.token === "mushroom" && e.picks[n] - +!!e.potUsed.includes(n) >= 3) return r;
		let a = structuredClone(e), o = {
			rid: n,
			token: t.token
		};
		return t.slot === "pig" ? a.pig = o : a.claims[t.slot] = o, t.token === "pot" && (a.potUsed.push(n), a.picks[n] === 3 && a.basketFlipped.push(n)), a.picks[n]++, a.turn++, a.turn === a.players.length * 4 && (a.phase = a.pig ? "predict" : "awaitReveal"), {
			state: a,
			fx: [{
				kind: "claim",
				rid: n,
				data: {
					slot: t.slot,
					token: t.token
				}
			}]
		};
	}
	if (t.type === "predict") {
		let i = e.players.filter((e) => e !== n);
		if (e.phase !== "predict" || e.pig?.rid !== n || Object.keys(t.guesses).length !== i.length || i.some((n) => !Number.isInteger(t.guesses[n]) || t.guesses[n] < 1 || t.guesses[n] > (e.players.length === 3 ? 7 : 8))) return r;
		let a = structuredClone(e);
		return a.guesses = t.guesses, a.phase = "awaitReveal", { state: a };
	}
	if (e.phase !== "roundEnd" || e.nextReady.includes(n)) return r;
	let i = structuredClone(e);
	return i.nextReady.push(n), i.nextReady.length === i.players.length && (i.round++, i.startIndex = (i.startIndex + 1) % i.players.length, V(i)), { state: i };
}
function Y(e, t) {
	let n = [
		"reveal",
		"collect",
		"score",
		"roundEnd",
		"done"
	].includes(e.phase), r = {
		players: e.players,
		round: e.round,
		start: e.players[e.startIndex],
		phase: e.phase,
		actor: te(e),
		ready: e.ready,
		slots: U(e),
		hands: e.players.filter((t) => e.hands[t] !== void 0).map((t) => ({
			rid: t,
			suit: x(e.hands[t]),
			face: n ? e.hands[t] : null
		})),
		previewSuits: e.phase === "prepare" ? e.remaining.map(x) : [],
		picks: e.picks,
		potUsed: e.potUsed,
		basketFlipped: e.basketFlipped,
		pigEnabled: e.config.pig,
		pigBy: e.pig?.rid ?? null,
		pigToken: e.pig?.token ?? null,
		guesses: e.guesses,
		collected: e.collected,
		soups: Object.fromEntries(e.collected.map((t) => [t, K(e, t)])),
		scores: e.scores,
		results: e.results,
		history: e.history,
		nextReady: e.nextReady
	};
	if (!e.players.includes(t)) return { public: r };
	let i = {};
	return (e.rows[t] ?? e.initial[t]).forEach((e, n) => {
		i[z(t, n)] = e;
	}), e.centers.forEach((e, n) => {
		e.owner === t && (i[`center:${n}`] = e.card);
	}), {
		public: r,
		private: {
			initial: e.phase === "prepare" ? e.initial[t] : [],
			known: i,
			hand: e.hands[t] ?? null,
			prepared: e.ready.includes(t)
		}
	};
}
var X = {
	meta: O,
	saveCompatibility: { version: "1" },
	schemas: {
		action: N,
		publicView: I,
		privateView: L,
		config: M
	},
	setup: H,
	reduce: J,
	viewFor: Y,
	status(e) {
		if (e.phase !== "done") return {
			phase: e.phase,
			scores: e.scores
		};
		let t = [...e.players].sort((t, n) => e.scores[n] - e.scores[t] || e.results.findIndex((e) => e.rid === t) - e.results.findIndex((e) => e.rid === n));
		return {
			phase: "done",
			winner: t.slice(0, 1),
			ranking: t,
			scores: e.scores
		};
	},
	nextTickIn(e) {
		return e.phase === "awaitReveal" ? R.claim : e.phase === "reveal" ? R.reveal : e.phase === "collect" ? R.collect : e.phase === "score" ? R.score : null;
	}
};
//#endregion
//#region src/games/mushroomsort/pieces.tsx
function Z({ pot: e = !1 }) {
	return /* @__PURE__ */ d("svg", {
		viewBox: "0 0 48 48",
		fill: "currentColor",
		"aria-hidden": "true",
		children: e ? /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d("path", { d: "M9 21h30l-3 19H12zM5 24h6v5H5zm32 0h6v5h-6zM8 17h32v4H8z" }),
			/* @__PURE__ */ d("path", { d: "M19 12h10v5H19z" }),
			/* @__PURE__ */ d("path", {
				d: "M16 5q-5 4 0 7m8-9q-5 4 0 7m8-5q-5 4 0 7",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2"
			})
		] }) : /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d("path", { d: "M6 25C1 12 14 4 24 4s23 8 18 21c-7 4-29 4-36 0Z" }),
			/* @__PURE__ */ d("path", { d: "m19 28-3 14q8 5 16 0l-3-14Z" }),
			/* @__PURE__ */ d("circle", {
				cx: "15",
				cy: "17",
				r: "4",
				fill: "#fff"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "29",
				cy: "13",
				r: "3",
				fill: "#fff"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "35",
				cy: "21",
				r: "2",
				fill: "#fff"
			})
		] })
	});
}
function ne() {
	return /* @__PURE__ */ d("svg", {
		className: "ms-ants",
		viewBox: "0 0 100 145",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		children: /* @__PURE__ */ d("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "141",
			rx: "8",
			pathLength: "100"
		})
	});
}
function Q({ card: e, suit: t, legal: n = !1, selected: r = !1, privateFace: i = !1, children: o }) {
	let s = a(), c = s(v[t]), l = e === null ? s("games.mushroomsort.cardBack", { color: c }) : s("games.mushroomsort.cardLabel", {
		color: c,
		n: b(e)
	}) + (S(e) ? ` · ${s("games.mushroomsort.stars", { n: 1 })}` : "") + (i ? ` · ${s("games.mushroomsort.privateCard")}` : "");
	return /* @__PURE__ */ f("span", {
		role: "img",
		"aria-label": l,
		className: `ms-card ms-suit-${t}${e === null ? " ms-back" : " ms-face"}`,
		"data-selected": r,
		"data-private": i,
		style: { "--ms-suit": _[t] },
		children: [
			e === null ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d(Z, {}), /* @__PURE__ */ d("span", {
				className: "ms-back-mark",
				children: "✦"
			})] }) : /* @__PURE__ */ f("span", {
				className: "ms-face-layer",
				children: [
					/* @__PURE__ */ d("span", {
						className: "ms-card-art",
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ f("span", {
						className: "ms-number",
						children: [b(e), S(e) > 0 && /* @__PURE__ */ d("small", { children: "★" })]
					}),
					/* @__PURE__ */ d("span", {
						className: "ms-number ms-number-bottom",
						"aria-hidden": "true",
						children: b(e)
					})
				]
			}, e),
			n && /* @__PURE__ */ d(ne, {}),
			o
		]
	});
}
function re(e) {
	let t = a(), n = i((e) => e.locale), r = (t) => e.find((e) => e.rid === t), o = (e) => c[(r(e)?.colorIndex ?? 0) % c.length];
	return {
		member: r,
		color: o,
		name: (e) => r(e) ? l(r(e), n) : t(o(e).nameKey)
	};
}
function $({ member: e, small: t = !1 }) {
	return /* @__PURE__ */ d("span", {
		className: `ms-avatar${t ? " ms-avatar-small" : ""}`,
		style: { background: c[(e?.colorIndex ?? 0) % c.length].hex },
		children: /* @__PURE__ */ d("img", {
			src: s[(e?.avatar ?? 0) % s.length],
			alt: "",
			draggable: !1
		})
	});
}
//#endregion
//#region src/games/mushroomsort/view-player.tsx
var ie = {
	prepare: "games.mushroomsort.prepare",
	gather: "games.mushroomsort.gather",
	predict: "games.mushroomsort.predict",
	awaitReveal: "games.mushroomsort.reveal",
	reveal: "games.mushroomsort.reveal",
	collect: "games.mushroomsort.collect",
	score: "games.mushroomsort.score",
	roundEnd: "games.mushroomsort.roundEnd",
	done: "games.mushroomsort.roundEnd"
};
function ae({ slot: e, members: t }) {
	let { ref: n, hidden: i } = r(`claim:${e.id}`), o = re(t), s = a();
	return /* @__PURE__ */ f("span", {
		ref: n,
		className: "ms-claim",
		style: {
			"--ms-player": o.color(e.claimedBy).hex,
			visibility: i ? "hidden" : void 0
		},
		"aria-label": s("games.mushroomsort.collectedBy", {
			name: o.name(e.claimedBy),
			token: s(e.token === "pot" ? "games.mushroomsort.pot" : "games.mushroomsort.mushroom")
		}),
		children: [/* @__PURE__ */ d(Z, { pot: e.token === "pot" }), /* @__PURE__ */ d($, {
			member: o.member(e.claimedBy),
			small: !0
		})]
	});
}
function oe({ slot: e, face: t, legal: n, selected: i, members: o, label: s, onClick: c }) {
	let { ref: l, hidden: u } = r(`slot:${e.id}`), p = a();
	return /* @__PURE__ */ f("div", {
		className: "ms-slot",
		ref: l,
		style: { visibility: u ? "hidden" : void 0 },
		"data-collected": e.collected,
		children: [/* @__PURE__ */ f("button", {
			className: "ms-card-button",
			type: "button",
			"aria-label": s,
			"aria-pressed": i,
			disabled: !n,
			onClick: c,
			children: [/* @__PURE__ */ d(Q, {
				card: t,
				suit: e.suit,
				legal: n,
				selected: i,
				privateFace: e.face === null && t !== null
			}), e.blocked && !e.claimedBy && /* @__PURE__ */ d("span", {
				className: "ms-blocked",
				title: p("games.mushroomsort.blocked"),
				"aria-label": p("games.mushroomsort.blocked"),
				children: "×"
			})]
		}), e.claimedBy && /* @__PURE__ */ d(ae, {
			slot: e,
			members: o
		})]
	});
}
function se({ rid: e, children: t }) {
	let { ref: n, hidden: i } = r(`soup:${e}`);
	return /* @__PURE__ */ d("div", {
		ref: n,
		className: "ms-soup-cards",
		style: { visibility: i ? "hidden" : void 0 },
		children: t
	});
}
function ce({ rid: e, card: t }) {
	let { ref: n } = r(`soup-card:${e}:${t}`);
	return /* @__PURE__ */ d("span", {
		ref: n,
		className: "ms-soup-target",
		children: /* @__PURE__ */ d(Q, {
			card: t,
			suit: x(t)
		})
	});
}
function le({ rid: e, members: t }) {
	let { ref: n } = r(`seat:${e}`);
	return /* @__PURE__ */ d("span", {
		ref: n,
		children: /* @__PURE__ */ d($, { member: t.find((t) => t.rid === e) })
	});
}
function ue(e) {
	let { public: t, private: i, myRid: s, members: c, send: l } = e, p = t, m = i, h = a(), g = re(c), { ref: _ } = r("table"), S = `${s}:${p.round}`, [w, E] = n(null), [O, k] = n(null), [A, j] = n(null), [M, N] = n(!1), [P, F] = n(null), I = W(p, s), L = w?.scope === S && I.includes(w.slot) ? w.slot : null, R = O?.scope === S ? O : {
		scope: S,
		center: null,
		order: T(m?.initial ?? []),
		swap: null
	}, z = p.phase === "prepare" && !!m && !m.prepared, B = p.phase === "gather" && p.actor === s, V = A === S || p.phase === "prepare", H = p.players.includes(s), te = 3 - ((p.picks[s] ?? 0) - +!!p.potUsed.includes(s)), U = P?.scope === S ? P.guesses : {}, G = g.name, K = (e, t) => e === null ? h("games.mushroomsort.cardBack", { color: h(v[t]) }) : h("games.mushroomsort.cardLabel", {
		color: h(v[t]),
		n: b(e)
	}), q = (e) => e.face ?? (V ? m?.known[e.id] ?? null : null), J = (e) => {
		L && (l({
			type: "claim",
			slot: L,
			token: e
		}), E(null));
	};
	function Y(e) {
		if (R.swap !== null && R.swap !== e && b(R.swap) === b(e)) {
			let t = [...R.order], n = t.indexOf(R.swap), r = t.indexOf(e);
			[t[n], t[r]] = [t[r], t[n]], k({
				...R,
				order: t,
				swap: null
			});
			return;
		}
		k({
			...R,
			swap: e
		});
	}
	let X = z ? h(p.players.length === 2 ? "games.mushroomsort.preparingTwo" : "games.mushroomsort.preparing") : p.phase === "prepare" ? h("games.mushroomsort.waitingPrepare") : B ? h("games.mushroomsort.yourTurn") : p.actor ? h(p.phase === "predict" ? "games.mushroomsort.guessWaiting" : "games.mushroomsort.waiting", { name: G(p.actor) }) : h(ie[p.phase]);
	return /* @__PURE__ */ f(o, {
		adaptive: !0,
		className: "ms-screen",
		actionsHeight: "ms-actions-height",
		banner: /* @__PURE__ */ f("header", {
			className: "ms-banner",
			children: [
				/* @__PURE__ */ d(Z, {}),
				/* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("small", { children: h("games.mushroomsort.round", {
					n: p.round,
					total: p.players.length
				}) }), /* @__PURE__ */ d("strong", { children: X })] }),
				/* @__PURE__ */ d("button", {
					type: "button",
					className: "ms-text-button",
					onClick: () => N(!0),
					children: h("games.mushroomsort.recipe")
				})
			]
		}),
		actions: /* @__PURE__ */ d("div", {
			className: "ms-actions",
			children: z ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("p", { children: R.center === null ? h(p.players.length === 2 ? "games.mushroomsort.preparingTwo" : "games.mushroomsort.selectCenter") : h("games.mushroomsort.centerSelected") }), /* @__PURE__ */ d("button", {
				type: "button",
				className: "ms-primary",
				disabled: p.players.length > 2 && R.center === null,
				onClick: () => l({
					type: "prepare",
					center: R.center,
					order: R.order
				}),
				children: h("games.mushroomsort.prepareConfirm")
			})] }) : B && L ? /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("button", {
					type: "button",
					className: "ms-text-button ms-cancel",
					onClick: () => E(null),
					"aria-label": h("games.mushroomsort.cancel"),
					children: "×"
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "ms-primary",
					disabled: te <= 0,
					onClick: () => J("mushroom"),
					children: [/* @__PURE__ */ d(Z, {}), h("games.mushroomsort.claimMushroom")]
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "ms-secondary",
					disabled: p.potUsed.includes(s),
					onClick: () => J("pot"),
					children: [/* @__PURE__ */ d(Z, { pot: !0 }), h("games.mushroomsort.claimPot")]
				}),
				!p.potUsed.includes(s) && p.picks[s] === 3 && /* @__PURE__ */ d("small", {
					className: "ms-penalty",
					children: h("games.mushroomsort.potPenalty")
				})
			] }) : p.phase === "roundEnd" ? /* @__PURE__ */ d("button", {
				className: "ms-primary",
				type: "button",
				disabled: !H || p.nextReady.includes(s),
				onClick: () => l({ type: "next" }),
				children: h(p.nextReady.includes(s) ? "games.mushroomsort.nextWaiting" : "games.mushroomsort.next")
			}) : /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("p", { children: B ? h("games.mushroomsort.chooseTarget") : X }), H && p.phase !== "prepare" && /* @__PURE__ */ d("button", {
				className: "ms-secondary",
				type: "button",
				onClick: () => j(V ? null : S),
				children: h(V ? "games.mushroomsort.hideOwn" : "games.mushroomsort.peek")
			})] })
		}),
		children: [
			/* @__PURE__ */ f("div", {
				className: "ms-table",
				"data-players": p.players.length,
				ref: _,
				children: [/* @__PURE__ */ d("div", {
					className: "ms-rows",
					children: p.players.map((e) => /* @__PURE__ */ f("section", {
						className: "ms-player-row",
						"data-active": p.actor === e,
						"data-own": s === e,
						style: { "--ms-player": g.color(e).hex },
						children: [
							/* @__PURE__ */ f("header", { children: [
								/* @__PURE__ */ d(le, {
									rid: e,
									members: c
								}),
								/* @__PURE__ */ d("strong", { children: G(e) }),
								e === s && /* @__PURE__ */ d("small", { children: h("lobby.you") }),
								e === p.start && /* @__PURE__ */ d("span", {
									className: "ms-start",
									children: h("games.mushroomsort.start")
								}),
								/* @__PURE__ */ d("b", { children: h("games.mushroomsort.points", { n: p.scores[e] }) })
							] }),
							z && e === s ? /* @__PURE__ */ f(u, { children: [
								/* @__PURE__ */ d("div", {
									className: "ms-row-cards ms-prep-cards",
									children: R.order.map((e) => /* @__PURE__ */ f("div", {
										className: "ms-prep-slot",
										children: [/* @__PURE__ */ d("button", {
											type: "button",
											className: "ms-card-button",
											"aria-label": K(e, x(e)),
											"aria-pressed": R.swap === e,
											onClick: () => Y(e),
											children: /* @__PURE__ */ d(Q, {
												card: e,
												suit: x(e),
												selected: R.swap === e,
												legal: !0
											})
										}), R.swap === e && p.players.length > 2 && /* @__PURE__ */ d("button", {
											type: "button",
											className: "ms-center-choice",
											onClick: () => k({
												scope: S,
												center: e,
												order: T([...R.center === null ? [] : [R.center], ...R.order.filter((t) => t !== e)]),
												swap: null
											}),
											children: h("games.mushroomsort.centerChoice")
										})]
									}, e))
								}),
								/* @__PURE__ */ d("p", {
									className: "ms-order-hint",
									children: h("games.mushroomsort.orderHint")
								}),
								R.center !== null && /* @__PURE__ */ f("div", {
									className: "ms-prep-central",
									children: [/* @__PURE__ */ d("span", { children: h("games.mushroomsort.central") }), /* @__PURE__ */ d(Q, {
										card: R.center,
										suit: x(R.center)
									})]
								})
							] }) : /* @__PURE__ */ d("div", {
								className: "ms-row-cards",
								children: p.slots.filter((t) => t.zone === "row" && t.owner === e).map((t) => /* @__PURE__ */ f("div", {
									className: "ms-position",
									children: [/* @__PURE__ */ d(oe, {
										slot: t,
										face: q(t),
										legal: I.includes(t.id),
										selected: L === t.id,
										members: c,
										label: h("games.mushroomsort.cardSlot", {
											owner: G(e),
											n: t.index + 1,
											card: K(q(t), t.suit)
										}),
										onClick: () => E({
											scope: S,
											slot: t.id
										})
									}), p.players.length === 2 && /* @__PURE__ */ d("small", {
										className: "ms-pair",
										children: h("games.mushroomsort.pairSlot", { n: p.players.indexOf(e) === 0 ? t.index + 1 : 7 - t.index })
									})]
								}, t.id))
							}),
							/* @__PURE__ */ f("footer", { children: [
								/* @__PURE__ */ d("span", { children: h("games.mushroomsort.pickCount", { n: p.picks[e] }) }),
								/* @__PURE__ */ d("span", {
									className: "ms-basket",
									"aria-label": h("games.mushroomsort.basketStars", { n: p.basketFlipped.includes(e) ? 0 : 2 }),
									children: p.basketFlipped.includes(e) ? "☆ ☆" : "★ ★"
								}),
								p.phase === "prepare" && p.ready.includes(e) && /* @__PURE__ */ d("b", { children: h("games.mushroomsort.ready") })
							] }),
							/* @__PURE__ */ f("div", {
								className: "ms-player-tray",
								children: [p.hands.find((t) => t.rid === e) && /* @__PURE__ */ f("div", {
									className: "ms-hand",
									children: [(() => {
										let t = p.hands.find((t) => t.rid === e);
										return /* @__PURE__ */ d(Q, {
											card: t.face ?? (e === s ? m?.hand ?? null : null),
											suit: t.suit,
											privateFace: e === s && t.face === null
										});
									})(), /* @__PURE__ */ d("small", { children: h("games.mushroomsort.hand") })]
								}), /* @__PURE__ */ d(se, {
									rid: e,
									children: p.collected.includes(e) ? p.soups[e]?.map((t) => /* @__PURE__ */ d(ce, {
										rid: e,
										card: t
									}, t)) : /* @__PURE__ */ f("div", {
										className: "ms-token-rack",
										style: { color: g.color(e).hex },
										children: [/* @__PURE__ */ d("span", {
											"aria-label": h("games.mushroomsort.tokenCount", {
												token: h("games.mushroomsort.mushroom"),
												n: 3 - (p.picks[e] - +!!p.potUsed.includes(e))
											}),
											children: [
												0,
												1,
												2
											].map((t) => /* @__PURE__ */ d("i", {
												"data-used": t < p.picks[e] - +!!p.potUsed.includes(e),
												children: /* @__PURE__ */ d(Z, {})
											}, t))
										}), /* @__PURE__ */ d("span", {
											"aria-label": h("games.mushroomsort.tokenCount", {
												token: h("games.mushroomsort.pot"),
												n: +!p.potUsed.includes(e)
											}),
											children: /* @__PURE__ */ d("i", {
												"data-used": p.potUsed.includes(e),
												children: /* @__PURE__ */ d(Z, { pot: !0 })
											})
										})]
									})
								})]
							}),
							p.results.find((t) => t.rid === e) && /* @__PURE__ */ d("p", {
								className: "ms-round-score",
								children: (() => {
									let t = p.results.find((t) => t.rid === e);
									return h("games.mushroomsort.scoreLine", {
										kind: h(y[t.kind]),
										stars: t.stars,
										points: t.points + t.pigPoints
									});
								})()
							})
						]
					}, e))
				}), /* @__PURE__ */ f("aside", {
					className: "ms-center-area",
					children: [
						/* @__PURE__ */ d("h2", { children: h("games.mushroomsort.central") }),
						/* @__PURE__ */ d("div", {
							className: "ms-center-cards",
							children: p.slots.filter((e) => e.zone === "center").map((e) => /* @__PURE__ */ f("div", {
								className: "ms-central-slot",
								children: [e.owner && /* @__PURE__ */ f("span", {
									className: "ms-central-owner",
									children: [/* @__PURE__ */ d($, {
										small: !0,
										member: g.member(e.owner)
									}), /* @__PURE__ */ d("span", { children: G(e.owner) })]
								}), /* @__PURE__ */ d(oe, {
									slot: e,
									face: q(e),
									legal: I.includes(e.id),
									selected: L === e.id,
									members: c,
									label: h("games.mushroomsort.centerSlot", { card: K(q(e), e.suit) }),
									onClick: () => E({
										scope: S,
										slot: e.id
									})
								})]
							}, e.id))
						}),
						p.phase === "prepare" && /* @__PURE__ */ f("div", {
							className: "ms-deck-colors",
							children: [/* @__PURE__ */ d("h3", { children: h("games.mushroomsort.deckColors") }), p.previewSuits.map((e, t) => /* @__PURE__ */ d("span", {
								className: `ms-color-dot ms-suit-${e}`,
								"aria-label": h(v[e]),
								children: /* @__PURE__ */ d(Z, {})
							}, t))]
						}),
						p.pigEnabled && /* @__PURE__ */ f("button", {
							type: "button",
							className: "ms-pig",
							disabled: !I.includes("pig"),
							"data-selected": L === "pig",
							onClick: () => E({
								scope: S,
								slot: "pig"
							}),
							children: [
								/* @__PURE__ */ d("span", {
									"aria-hidden": "true",
									children: "🐖"
								}),
								/* @__PURE__ */ d("strong", { children: h("games.mushroomsort.pig") }),
								p.pigBy && /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d($, {
									small: !0,
									member: g.member(p.pigBy)
								}), G(p.pigBy)] }),
								I.includes("pig") && /* @__PURE__ */ d(ne, {})
							]
						}),
						p.guesses && p.hands.every((e) => e.face !== null) && /* @__PURE__ */ f("div", {
							className: "ms-pig-results",
							children: [/* @__PURE__ */ d("p", { children: h("games.mushroomsort.noRecipePoints") }), Object.entries(p.guesses).map(([e, t]) => /* @__PURE__ */ f("p", { children: [/* @__PURE__ */ d("strong", { children: G(e) }), /* @__PURE__ */ d("span", { children: h("games.mushroomsort.guessResult", {
								guess: t,
								actual: b(p.hands.find((t) => t.rid === e).face)
							}) })] }, e))]
						}),
						/* @__PURE__ */ f("div", {
							className: "ms-inline-recipe",
							children: [/* @__PURE__ */ d("h3", { children: h("games.mushroomsort.recipe") }), /* @__PURE__ */ f("table", { children: [/* @__PURE__ */ d("thead", { children: /* @__PURE__ */ f("tr", { children: [
								/* @__PURE__ */ d("th", {}),
								/* @__PURE__ */ d("th", { children: h("games.mushroomsort.first") }),
								p.players.length > 2 && /* @__PURE__ */ d("th", { children: h("games.mushroomsort.second") })
							] }) }), /* @__PURE__ */ d("tbody", { children: ee.map((e) => /* @__PURE__ */ f("tr", { children: [
								/* @__PURE__ */ d("th", { children: h(y[e]) }),
								/* @__PURE__ */ d("td", { children: D(e, 0, p.players.length) }),
								p.players.length > 2 && /* @__PURE__ */ d("td", { children: D(e, 1, p.players.length) })
							] }, e)) })] })]
						})
					]
				})]
			}),
			M && /* @__PURE__ */ d("div", {
				className: "ms-modal-backdrop",
				onClick: () => N(!1),
				children: /* @__PURE__ */ f("section", {
					className: "ms-modal ms-recipe-paper",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": h("games.mushroomsort.recipe"),
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ f("header", { children: [/* @__PURE__ */ d("h2", { children: h("games.mushroomsort.recipe") }), /* @__PURE__ */ d("button", {
						type: "button",
						className: "ms-text-button",
						"aria-label": h("games.mushroomsort.cancel"),
						onClick: () => N(!1),
						children: "×"
					})] }), /* @__PURE__ */ f("table", { children: [/* @__PURE__ */ d("thead", { children: /* @__PURE__ */ f("tr", { children: [
						/* @__PURE__ */ d("th", { children: h("games.mushroomsort.strength") }),
						/* @__PURE__ */ d("th", { children: h("games.mushroomsort.first") }),
						p.players.length > 2 && /* @__PURE__ */ d("th", { children: h("games.mushroomsort.second") })
					] }) }), /* @__PURE__ */ d("tbody", { children: ee.map((e) => /* @__PURE__ */ f("tr", { children: [
						/* @__PURE__ */ d("th", { children: h(y[e]) }),
						/* @__PURE__ */ d("td", { children: D(e, 0, p.players.length) }),
						p.players.length > 2 && /* @__PURE__ */ d("td", { children: D(e, 1, p.players.length) })
					] }, e)) })] })]
				})
			}),
			p.phase === "predict" && p.pigBy === s && /* @__PURE__ */ d("div", {
				className: "ms-modal-backdrop",
				children: /* @__PURE__ */ f("section", {
					className: "ms-modal",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": h("games.mushroomsort.predict"),
					children: [
						/* @__PURE__ */ d("h2", { children: h("games.mushroomsort.predict") }),
						/* @__PURE__ */ d("p", { children: h("games.mushroomsort.guessPrompt") }),
						p.players.filter((e) => e !== s).map((e) => /* @__PURE__ */ f("fieldset", { children: [/* @__PURE__ */ d("legend", { children: G(e) }), /* @__PURE__ */ d("div", {
							className: "ms-guess-numbers",
							children: Array.from({ length: C(p.players.length) }, (t, n) => /* @__PURE__ */ d("button", {
								type: "button",
								className: "ms-secondary",
								"aria-pressed": U[e] === n + 1,
								onClick: () => F({
									scope: S,
									guesses: {
										...U,
										[e]: n + 1
									}
								}),
								children: n + 1
							}, n))
						})] }, e)),
						/* @__PURE__ */ d("button", {
							className: "ms-primary",
							type: "button",
							disabled: p.players.some((e) => e !== s && U[e] === void 0),
							onClick: () => l({
								type: "predict",
								guesses: U
							}),
							children: h("games.mushroomsort.guessConfirm")
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/mushroomsort/bot.ts
var de = {
	pairW: 2,
	runW: 1.3,
	starW: .22,
	samples: 12
};
function fe(e, t) {
	let n = 2166136261;
	for (let r of `${t}:${e.round}:${Object.values(e.picks).join(",")}`) n = Math.imul(n ^ r.charCodeAt(0), 16777619);
	return () => (n ^= n << 13, n ^= n >>> 17, n ^= n << 5, (n >>> 0) / 4294967296);
}
function pe(e, t) {
	let n = [...e];
	for (let e = n.length - 1; e > 0; e--) {
		let r = Math.floor(t() * (e + 1));
		[n[e], n[r]] = [n[r], n[e]];
	}
	return n;
}
function me(e, t, n, r) {
	let i = [...e.slots.map((e) => ({
		id: e.id,
		suit: e.suit,
		row: e.zone === "row" ? e.owner : null,
		index: e.index,
		face: e.face ?? t.known[e.id] ?? null
	})), ...e.hands.map((e) => ({
		id: `hand:${e.rid}`,
		suit: e.suit,
		row: null,
		index: 0,
		face: e.face
	}))], a = e.players.find((e) => Object.keys(t.known).some((t) => t.startsWith(`row:${e}:`)));
	for (let n of i) n.id.startsWith("hand:") && (n.face = e.hands.find((e) => `hand:${e.rid}` === n.id).face ?? (n.id === `hand:${a}` ? t.hand : null));
	let o = Object.fromEntries(i.filter((e) => e.face !== null).map((e) => [e.id, e.face])), s = [], c = w(e.players.length);
	for (let t = 0; t < n; t++) {
		let t = { ...o }, n = new Set(Object.values(o)), a = 0;
		function l() {
			if (++a > 3500) return !1;
			let o = null, s = [];
			for (let r of i) {
				if (t[r.id] !== void 0) continue;
				let a = 1, l = C(e.players.length);
				if (r.row) for (let e of i) e.row === r.row && t[e.id] !== void 0 && (e.index < r.index ? a = Math.max(a, b(t[e.id])) : e.index > r.index && (l = Math.min(l, b(t[e.id]))));
				let u = c.filter((e) => !n.has(e) && x(e) === r.suit && b(e) >= a && b(e) <= l);
				if (!u.length) return !1;
				(!o || u.length < s.length) && (o = r, s = u);
			}
			if (!o) return !0;
			for (let e of pe(s, r)) {
				if (t[o.id] = e, n.add(e), l()) return !0;
				delete t[o.id], n.delete(e);
			}
			return !1;
		}
		l() && s.push(t);
	}
	return s;
}
function he(e, t) {
	let n = Array(9).fill(0);
	for (let t of e) n[b(t)]++;
	let r = n.reduce((e, t) => e + t * (t - 1) / 2, 0), i = 0;
	for (let e = 1; e <= 5; e++) {
		let t = n.slice(e, e + 4).filter(Boolean).length;
		i = Math.max(i, t >= 3 ? t * t / 4 : t / 3);
	}
	let a = e.length >= 4 ? (7 - E(e).strength) * 2 : 0;
	return r * t.pairW + i * t.runW + a + e.reduce((e, t) => e + S(t), 0) * t.starW;
}
function ge(e = de) {
	return ({ public: t, private: n }, r) => {
		if (!n || !t.players.includes(r.rid)) return null;
		let i = fe(t, r.rid);
		if (t.phase === "prepare" && !n.prepared) {
			let e = pe(n.initial, i), r = t.players.length === 2 ? null : e[0];
			return { action: {
				type: "prepare",
				center: r,
				order: T(e.filter((e) => e !== r))
			} };
		}
		if (t.phase === "roundEnd" && !t.nextReady.includes(r.rid)) return { action: { type: "next" } };
		if (t.phase === "predict" && t.pigBy === r.rid) {
			let a = me(t, n, e.samples, i), o = Object.fromEntries(t.players.filter((e) => e !== r.rid).map((e) => {
				let t = Array(9).fill(0);
				return a.forEach((n) => t[b(n[`hand:${e}`])]++), [e, t.indexOf(Math.max(...t.slice(1)))];
			}));
			for (let e in o) o[e] < 1 && (o[e] = 1);
			return { action: {
				type: "predict",
				guesses: o
			} };
		}
		let a = W(t, r.rid);
		if (!a.length) return null;
		let o = t.picks[r.rid], s = t.potUsed.includes(r.rid), c = [];
		if (o - +!!s < 3 && c.push("mushroom"), s || c.push("pot"), r.difficulty === "weak") return { action: {
			type: "claim",
			slot: a[Math.floor(i() * a.length)],
			token: c[Math.floor(i() * c.length)]
		} };
		let l = me(t, n, e.samples, i), u = t.slots.filter((e) => e.claimedBy === r.rid).map((e) => e.id), d = a.find((e) => e !== "pig") ?? a[0], f = -Infinity;
		for (let t of a) {
			if (t === "pig") continue;
			let r = l.length ? l.reduce((r, i) => r + he([
				n.hand,
				...u.map((e) => i[e]),
				i[t]
			], e), 0) / l.length : i();
			r > f && (f = r, d = t);
		}
		let p = !s && o >= 2 ? "pot" : c.includes("mushroom") ? "mushroom" : "pot";
		return { action: {
			type: "claim",
			slot: d,
			token: p
		} };
	};
}
var _e = ge(), ve = (e, t, n) => {
	if (e.type === "prepare") return n("games.mushroomsort.botPrepare");
	if (e.type === "predict") return n("games.mushroomsort.botPredict");
	if (e.type === "next" || e.type === "tick") return n("games.mushroomsort.botNext");
	let r = t.public.slots.find((t) => t.id === e.slot);
	return n("games.mushroomsort.botClaim", { card: n(r ? v[r.suit] : "games.mushroomsort.pig") });
}, ye = {
	deal(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null, r = t.anchor("table");
		if (!n || !r) return null;
		let i = {
			x: r.x + r.w / 2,
			y: r.y + r.h / 2,
			w: 36,
			h: 52
		};
		return {
			ms: 360,
			node: /* @__PURE__ */ d(m, {
				from: i,
				to: n,
				ms: 360,
				children: /* @__PURE__ */ d("div", {
					style: { width: 36 },
					children: /* @__PURE__ */ d(Q, {
						card: null,
						suit: 0
					})
				})
			})
		};
	},
	prepare(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 280,
			node: /* @__PURE__ */ d(h, {
				at: n,
				ms: 280
			})
		} : null;
	},
	claim(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null, i = t.anchor(`claim:${n.slot}`);
		if (!r || !i) return null;
		let a = e.rid ? t.member(e.rid) : void 0;
		return {
			ms: R.claim,
			hide: t.queued ? [] : [`claim:${n.slot}`],
			node: /* @__PURE__ */ d(m, {
				from: {
					...r,
					w: 36,
					h: 36
				},
				to: i,
				ms: R.claim - 60,
				children: /* @__PURE__ */ f("span", {
					className: "ms-fx-token",
					style: { color: c[(a?.colorIndex ?? 0) % c.length].hex },
					children: [/* @__PURE__ */ d(Z, { pot: n.token === "pot" }), /* @__PURE__ */ d($, {
						member: a,
						small: !0
					})]
				})
			})
		};
	},
	reveal() {
		return {
			ms: R.reveal,
			node: null
		};
	},
	collect(e, t) {
		let n = e.data;
		if (!(e.rid && t.anchor(`soup:${e.rid}`))) return null;
		let r = n.from.flatMap((r, i) => {
			let a = t.anchor(`slot:${r}`), o = t.anchor(`soup-card:${e.rid}:${n.cards[i]}`);
			return a && o ? [/* @__PURE__ */ d(m, {
				from: a,
				to: o,
				ms: 410,
				delay: i * 55,
				children: /* @__PURE__ */ d("div", {
					className: "ms-fx-card",
					style: { width: a.w },
					children: /* @__PURE__ */ d(Q, {
						card: n.cards[i],
						suit: x(n.cards[i])
					})
				})
			}, r)] : [];
		});
		return {
			ms: R.collect,
			node: r,
			hide: t.queued ? [] : [`soup:${e.rid}`]
		};
	},
	score(e, t) {
		let n = e.data.points;
		return {
			ms: R.score,
			node: Object.entries(n).flatMap(([e, n]) => {
				let r = t.anchor(`seat:${e}`);
				return r && n > 0 ? [/* @__PURE__ */ d(p, {
					at: r,
					ms: R.score,
					children: /* @__PURE__ */ f("span", {
						className: "ms-fx-points",
						children: ["+", n]
					})
				}, e)] : [];
			})
		};
	}
};
//#endregion
//#region src/games/mushroomsort/game-over.tsx
function be({ public: e, private: t, result: r, members: i, myRid: s, hintCount: c, onPlayAgain: l, onBackToLobby: u }) {
	let p = e, m = a(), h = re(i), [g, _] = n(!0), v = r.winner[0];
	return /* @__PURE__ */ f("div", {
		className: "ms-over-root",
		children: [
			/* @__PURE__ */ d("div", {
				className: "ms-final-table",
				inert: g,
				children: /* @__PURE__ */ d(ue, {
					public: p,
					private: t,
					members: i,
					myRid: s,
					send: () => void 0
				})
			}),
			/* @__PURE__ */ d("div", {
				className: "ms-over-layer",
				"data-open": g,
				inert: !g,
				children: /* @__PURE__ */ d(o, {
					adaptive: !0,
					className: "ms-screen ms-over",
					actionsHeight: "ms-over-actions-height",
					banner: /* @__PURE__ */ f("header", {
						className: "ms-banner",
						children: [
							/* @__PURE__ */ d(Z, { pot: !0 }),
							/* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("small", { children: m("games.mushroomsort.name") }), /* @__PURE__ */ d("strong", { children: v ? m("games.mushroomsort.winner", { name: h.name(v) }) : m("session.result.title") })] }),
							/* @__PURE__ */ d("button", {
								type: "button",
								className: "ms-text-button",
								onClick: () => _(!1),
								children: m("games.mushroomsort.reviewTable")
							})
						]
					}),
					actions: l || u ? /* @__PURE__ */ f("div", {
						className: "ms-actions",
						children: [l && /* @__PURE__ */ d("button", {
							className: "ms-primary",
							type: "button",
							onClick: l,
							children: m("session.result.playAgain")
						}), u && /* @__PURE__ */ d("button", {
							className: "ms-secondary",
							type: "button",
							onClick: u,
							children: m("session.result.backToLobby")
						})]
					}) : /* @__PURE__ */ d("div", {
						className: "ms-actions",
						children: /* @__PURE__ */ d("p", { children: m("session.result.waitHost") })
					}),
					children: /* @__PURE__ */ f("div", {
						className: "ms-over-content",
						children: [
							c !== void 0 && /* @__PURE__ */ d("p", {
								className: "ms-hint-count",
								children: m("session.hint.usedCount", { n: c })
							}),
							/* @__PURE__ */ d("div", {
								className: "ms-final-players",
								children: r.ranking.map((e, t) => /* @__PURE__ */ f("section", {
									className: "ms-final-player",
									"data-winner": r.winner.includes(e),
									style: { borderColor: h.color(e).hex },
									children: [
										/* @__PURE__ */ f("header", { children: [
											/* @__PURE__ */ d($, { member: h.member(e) }),
											/* @__PURE__ */ d("strong", { children: h.name(e) }),
											e === s && /* @__PURE__ */ d("small", { children: m("lobby.you") })
										] }),
										/* @__PURE__ */ f("div", {
											className: "ms-final-score",
											children: [/* @__PURE__ */ d("span", { children: m("games.mushroomsort.rank", { n: t + 1 }) }), /* @__PURE__ */ d("b", { children: m("games.mushroomsort.points", { n: p.scores[e] }) })]
										}),
										(r.autopilot?.[e] ?? 0) > 0 && /* @__PURE__ */ d("p", {
											className: "ms-autopilot",
											children: m("session.autopilot.share", { n: Math.round(r.autopilot[e] * 100) })
										}),
										/* @__PURE__ */ d("div", {
											className: "ms-final-soup",
											"aria-label": m("games.mushroomsort.soup", { name: h.name(e) }),
											children: p.results.find((t) => t.rid === e)?.cards.map((e) => /* @__PURE__ */ d(Q, {
												card: e,
												suit: x(e)
											}, e))
										})
									]
								}, e))
							}),
							/* @__PURE__ */ f("section", {
								className: "ms-score-paper",
								children: [/* @__PURE__ */ d("h2", { children: m("games.mushroomsort.scoreDetail") }), /* @__PURE__ */ f("table", { children: [/* @__PURE__ */ d("thead", { children: /* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", {}), p.players.map((e) => /* @__PURE__ */ f("th", { children: [/* @__PURE__ */ d($, {
									small: !0,
									member: h.member(e)
								}), /* @__PURE__ */ d("span", { children: h.name(e) })] }, e))] }) }), /* @__PURE__ */ d("tbody", { children: p.history.map((e) => /* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", { children: m("games.mushroomsort.round", {
									n: e.round,
									total: p.players.length
								}) }), p.players.map((t) => {
									let n = e.results.find((e) => e.rid === t);
									return /* @__PURE__ */ f("td", { children: [
										/* @__PURE__ */ d("span", { children: m(y[n.kind]) }),
										/* @__PURE__ */ d("small", { children: m("games.mushroomsort.stars", { n: n.stars }) }),
										/* @__PURE__ */ d("strong", { children: m("games.mushroomsort.points", { n: n.points }) }),
										n.pig && /* @__PURE__ */ d("small", {
											className: "ms-pig-bonus",
											children: m("games.mushroomsort.pigBonus", { n: n.pigPoints })
										})
									] }, t);
								})] }, e.round)) })] })]
							})
						]
					})
				})
			}),
			!g && /* @__PURE__ */ d("button", {
				className: "ms-primary ms-restore-results",
				type: "button",
				onClick: () => _(!0),
				children: m("games.mushroomsort.backResult")
			})
		]
	});
}
//#endregion
//#region src/games/mushroomsort/options.tsx
function xe({ value: e, onChange: t }) {
	let n = a(), r = M.parse(e);
	return /* @__PURE__ */ d(g, {
		checked: r.pig,
		label: n("games.mushroomsort.pigOption"),
		hint: n("games.mushroomsort.pigOptionHint"),
		accent: "#397e67",
		onChange: () => t({
			...r,
			pig: !r.pig
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/mushroomsort/entry.tsx
var Se = {
	definition: X,
	View: ue,
	bot: _e,
	describe: ve,
	fx: ye,
	OverView: be,
	Options: xe,
	locales: {
		zh: {
			name: "Mushroom Sort",
			desc: "观察颜色与排列，采集蘑菇，煮出最好的汤。",
			rules: "目标：游戏进行与玩家人数相同的轮数。每轮采集蘑菇组成配方，获得分数；全部轮次结束后，总分最高者获胜。\n\n组件与准备：\n· 蘑菇牌有红、蓝、黄、黑四种颜色，每种颜色的每个数字各有一张。牌背可以辨认颜色，牌面上的数字只有翻开后才能看见。数字 3 和 6 的牌各有一颗星。\n· 双人使用每色 1—5，三人使用每色 1—7，四人使用全部 1—8。每人每轮有三个蘑菇标记、一个锅标记，以及初始带两颗星的篮子。\n· 本作由大堂中排在首位的玩家开始第一轮，之后每轮的起始玩家顺时针移动一位。游戏不收集年龄；可在开局前调整座位。\n\n三人或四人的摆牌：\n· 三人时每人收到八张牌，四人时每人收到七张牌。每人选一张作为自己的中央牌，余牌按数字从小到大、从左到右面朝下排列。相同数字的牌可以自行调整先后顺序。\n· 你可以随时查看自己的牌列和自己的中央牌。其他玩家只能看见这些牌的颜色。摆牌时可以查看余下牌堆的颜色，但看不见数字。\n· 所有人摆好后，每人再收到一张初始手牌。你知道自己的手牌数字，其他人只知道它的颜色。三人局最后剩下的一张牌放入中央，所有人都不能查看它。\n\n采集：\n· 从起始玩家开始顺时针行动，每人轮流采集一次，共行动四次。点击其他玩家牌列中尚未被标记的牌，再选择一个剩余标记放在该牌上。不能采集自己的牌列。\n· 使用蘑菇标记时，所选牌立即翻开，所有人都能看见它的数字。使用锅标记时，该牌继续面朝下，采集者也不能查看；原本有权查看自己的中央牌的玩家仍可查看它。\n· 三人或四人时，只有自己的第四次采集可以选择中央牌，此时也可以选择自己的中央牌。前面三次只能选择其他玩家的牌列，或选择启用的猪牌。\n· 如果第四次采集才使用锅标记，本轮篮子的两颗星全部失去。采集标记放好后，牌仍留在原位置，直到比较阶段才收走。\n\n双人变化：\n· 每轮先从每种颜色中随机抽出一张牌作为四张中央牌，双方都不能查看。每人收到七张牌，全部按数字从小到大排列，不需要从中选中央牌；然后各收到一张初始手牌。\n· 每次采集都可以选择中央牌。双方牌列彼此面对面，因此你牌列左端的牌与对方牌列右端的牌相对。任一牌被采集后，与其相对的另一张牌就不能再采集。界面用相同的对位标记显示这七组关系。\n· 双人局只给本轮第一名配方分，不使用猪牌。\n\n比较配方：\n· 四次采集结束后，翻开所有被采集的牌和初始手牌。每人用采集的四张牌加初始手牌，共五张牌组成配方。颜色不参与配方强弱比较。\n配方按以下顺序从强到弱比较，其中三条与小顺子的强度相同：\n· 四条：配方中包含四张数字相同的牌。\n· 葫芦：配方中包含三张数字相同的牌，以及另一组两张数字相同的牌。\n· 顺子：配方中包含五个连续数字。\n· 三条：配方中包含三张数字相同的牌。\n· 小顺子：配方中包含四个连续数字。\n· 对子：配方中至少有两张数字相同的牌。两对仍按对子比较。\n· 杂烩：配方不满足以上任何一种条件。\n· 配方同强度时，比较蘑菇牌上的星数与篮子剩余星数之和，星数较多者优先。星数也相同时，顺时针离本轮起始玩家更远者优先；不比较数字大小。\n\n每轮得分：\n只有第一名和第二名获得配方分，双人局只有第一名得分。每位得分玩家按自己的配方获得以下分数。\n\n双人或三人局按下列说明计分；双人局不发放第二名的分数：\n· 四条：第一名获得 5 分，三人局的第二名获得 3 分。\n· 葫芦：第一名获得 3 分，三人局的第二名获得 2 分。\n· 顺子：第一名获得 3 分，三人局的第二名获得 1 分。\n· 三条：第一名获得 3 分，三人局的第二名获得 1 分。\n· 小顺子：第一名获得 3 分，三人局的第二名获得 1 分。\n· 对子：第一名获得 2 分，三人局的第二名获得 1 分。\n· 杂烩：第一名获得 2 分，三人局的第二名获得 1 分。\n\n四人局按下列说明计分：\n· 四条：第一名获得 5 分，第二名获得 4 分。\n· 葫芦：第一名获得 4 分，第二名获得 2 分。\n· 顺子：第一名获得 3 分，第二名获得 2 分。\n· 三条：第一名获得 3 分，第二名获得 2 分。\n· 小顺子：第一名获得 3 分，第二名获得 1 分。\n· 对子：第一名获得 2 分，第二名获得 1 分。\n· 杂烩：第一名获得 2 分，第二名获得 1 分。\n\n猪牌（可选，默认关闭）：\n· 猪牌仅用于三人或四人局。任何一次采集都可以把一个剩余标记放在猪牌上，整轮仅一人能够选择它。使用蘑菇或锅标记的效果相同，但第四次才使用锅标记时，仍失去篮子的两颗星。\n· 选择猪牌后，你本轮只有四张蘑菇牌。所有人采集结束后、手牌和锅下的牌翻开前，你必须分别猜测每位对手的初始手牌数字。\n· 只有全部猜对才获得猪牌分：三人局获得 2 分，四人局获得 3 分。你仍参与配方排名，但本轮不获得任何配方分，也不会把你的配方得分资格递补给其他人。\n\n结束：每轮结算后，由所有玩家确认进入下一轮。完成全部轮次后比较总分；总分相同时，按最后一轮的配方排名决定胜负。",
			red: "红色",
			blue: "蓝色",
			yellow: "黄色",
			black: "黑色",
			four: "四条",
			full: "葫芦",
			straight: "顺子",
			three: "三条",
			mini: "小顺子",
			pair: "对子",
			mixed: "杂烩",
			round: "第 {{n}}／{{total}} 轮",
			prepare: "摆好你的蘑菇牌",
			gather: "采集蘑菇",
			predict: "猪牌的猜测",
			reveal: "翻开蘑菇",
			collect: "蘑菇入锅",
			score: "比较配方",
			roundEnd: "本轮收获",
			yourTurn: "轮到你采集",
			waiting: "等待 {{name}} 采集",
			waitingPrepare: "等待其他玩家摆牌",
			preparing: "选一张中央牌，再确认牌列。",
			preparingTwo: "确认牌列；相同数字的牌可以调整顺序。",
			central: "中央牌",
			tableau: "牌列",
			hand: "初始手牌",
			own: "你的牌列",
			start: "起始",
			ready: "已摆好",
			points: "{{n}} 分",
			pickCount: "已采集 {{n}}／4",
			prepareConfirm: "摆好了",
			centerChoice: "设为中央牌",
			centerSelected: "中央牌已选",
			orderHint: "点击相同数字的两张牌可交换位置。",
			swap: "与同数字的牌交换",
			selectCenter: "先选择中央牌",
			deckColors: "余牌颜色",
			mushroom: "蘑菇",
			pot: "锅",
			basket: "篮子",
			basketStars: "篮子 {{n}} 星",
			stars: "{{n}} 星",
			chooseTarget: "选择一张蘑菇牌",
			claimMushroom: "翻开采集",
			claimPot: "盖锅采集",
			cancel: "取消",
			potPenalty: "此时盖锅将失去篮子的两颗星。",
			blocked: "对位牌已被采集",
			hidden: "数字未知",
			privateCard: "仅你可见",
			publicCard: "已翻开",
			selected: "已选中",
			collectedBy: "{{name}} 的{{token}}标记",
			cardLabel: "{{color}} {{n}}",
			cardBack: "{{color}}蘑菇，数字未知",
			cardSlot: "{{owner}}的第 {{n}} 张牌，{{card}}",
			centerSlot: "中央牌，{{card}}",
			pairSlot: "对位 {{n}}",
			pig: "猪牌",
			pigOption: "加入猪牌",
			pigOptionHint: "仅限三至四人。猜中所有对手的初始手牌数字可得分，但本轮放弃配方分。",
			pigChoose: "选择猪牌",
			pigClaimed: "{{name}} 选择了猪牌",
			guessPrompt: "分别猜测对手的初始手牌数字。",
			guessWaiting: "等待 {{name}} 猜测",
			guessFor: "{{name}} 的手牌数字",
			guessConfirm: "确认猜测",
			pigBonus: "猪牌 {{n}} 分",
			guessResult: "猜 {{guess}}，实际 {{actual}}",
			recipe: "配方表",
			first: "第一名",
			second: "第二名",
			strength: "强度",
			rank: "第 {{n}} 名",
			next: "下一轮",
			nextWaiting: "等待其他玩家确认",
			scoreDetail: "每轮得分",
			finalSoup: "最后一锅",
			reviewTable: "回看最后牌桌",
			backResult: "返回成绩",
			winner: "{{name}} 获胜",
			noRecipePoints: "猪牌不计配方分",
			soup: "{{name}} 的汤",
			scoreLine: "{{kind}} · {{stars}} 星 · {{points}} 分",
			tokenCount: "剩余{{token}}标记 {{n}} 个",
			peek: "查看自己的牌",
			hideOwn: "收起牌面",
			botPrepare: "整理牌列",
			botClaim: "采集{{card}}",
			botPredict: "猜测对手的手牌",
			botNext: "进入下一轮",
			invalid: "这个操作目前无法执行，请重新选择。"
		},
		en: {
			name: "Mushroom Sort",
			desc: "Read the colors and order, gather mushrooms, and cook the finest soup.",
			rules: "Goal: Play one round per player. Gather mushrooms to form recipes and earn points. The player with the most total points wins.\n\nComponents and setup:\n· There are red, blue, yellow, and black mushrooms. Each color–number combination appears exactly once. A card’s back shows its color, while its number is hidden until revealed. Cards numbered 3 and 6 each have one star.\n· Use numbers 1–5 of each color with two players, 1–7 with three, and all 1–8 with four. Each player has three mushroom tokens, one pot token, and a basket worth two stars at the start of each round.\n· The first lobby seat starts the first round. The starting player moves one seat clockwise each round. This adaptation does not collect ages; you may rearrange seats before starting.\n\nPreparation with three or four players:\n· Deal eight cards to each player with three players, or seven with four. Choose one card as your central card. Arrange your remaining cards face down in ascending numerical order, from your left to your right. You may arrange equal numbers in either order.\n· You may always inspect your own row and your own central card. Everyone else sees only their colors. During preparation, the colors of cards left in the deck are visible, but their numbers are hidden.\n· After everyone finishes arranging, deal each player one initial hand card. You know its number; other players know only its color. With three players, place the final undealt card in the center. Nobody may inspect that card.\n\nGathering:\n· Starting with the starting player, take turns clockwise until everyone has taken four turns. Select an unclaimed card from another player’s row, then place one remaining token on it. You cannot gather from your own row.\n· A mushroom token reveals its card to everyone immediately. A pot token leaves its card face down, and even the gatherer cannot inspect it. A player who already owns that central card may still inspect it.\n· With three or four players, you may gather a central card only on your fourth turn. You may choose your own central card then. On your first three turns, choose another player’s row or the optional pig card.\n· If you use your pot token on your fourth turn, you lose both basket stars for that round. Claimed cards remain in their original positions until comparison.\n\nTwo-player changes:\n· At the start of each round, randomly set aside one card of each color as four central cards. Neither player may inspect them. Deal seven cards to each player and arrange all seven in ascending order; do not choose a central card from them. Then deal one initial hand card to each player.\n· You may gather a central card on any turn. The rows face each other, so the leftmost card in your row faces the rightmost card in the other row. Once either card in a facing pair is claimed, the other card cannot be gathered. Matching pair labels identify these seven pairs.\n· Only first place earns recipe points. Do not use the pig card with two players.\n\nComparing recipes:\n· After gathering, reveal all claimed cards and initial hand cards. Combine your four gathered cards with your initial hand card to make a five-card recipe. Colors do not affect recipe strength.\nCompare recipes in the following order, from strongest to weakest. Three of a kind and Mini straight have equal strength:\n· Four of a kind: Your recipe contains four cards with the same number.\n· Full house: Your recipe contains three cards with the same number and another two cards with a different matching number.\n· Straight: Your recipe contains five consecutive numbers.\n· Three of a kind: Your recipe contains three cards with the same number.\n· Mini straight: Your recipe contains four consecutive numbers.\n· Pair: Your recipe contains at least two cards with the same number. Two pairs still count as Pair.\n· Mixed: Your recipe meets none of the conditions above.\n· For equal recipe strength, compare stars on the mushrooms plus any remaining basket stars. More stars wins. If still tied, the player farthest clockwise from the starting player wins. Higher numbers do not break ties.\n\nRound scoring:\nOnly first and second place earn recipe points; with two players, only first place scores. Each scoring player earns points for their own recipe as described below.\n\nWith two or three players, use the following scores. Do not award second-place points with two players:\n· Four of a kind: First place earns 5 points. With three players, second place earns 3 points.\n· Full house: First place earns 3 points. With three players, second place earns 2 points.\n· Straight: First place earns 3 points. With three players, second place earns 1 point.\n· Three of a kind: First place earns 3 points. With three players, second place earns 1 point.\n· Mini straight: First place earns 3 points. With three players, second place earns 1 point.\n· Pair: First place earns 2 points. With three players, second place earns 1 point.\n· Mixed: First place earns 2 points. With three players, second place earns 1 point.\n\nWith four players, use the following scores:\n· Four of a kind: First place earns 5 points and second place earns 4 points.\n· Full house: First place earns 4 points and second place earns 2 points.\n· Straight: First place earns 3 points and second place earns 2 points.\n· Three of a kind: First place earns 3 points and second place earns 2 points.\n· Mini straight: First place earns 3 points and second place earns 1 point.\n· Pair: First place earns 2 points and second place earns 1 point.\n· Mixed: First place earns 2 points and second place earns 1 point.\n\nPig card (optional, off by default):\n· With three or four players, you may place a remaining token on the pig instead of gathering a mushroom on any turn. Only one player can claim it per round. Mushroom and pot tokens work identically on the pig, but using the pot on your fourth turn still loses both basket stars.\n· The pig gives you no mushroom card, so your recipe has only four cards. After gathering ends, before revealing hand cards or cards under pots, guess each opponent’s initial hand-card number separately.\n· All guesses must be correct to score: 2 points with three players, or 3 with four. You still take part in recipe ranking but earn no recipe points that round. Other players do not move up to inherit your scoring place.\n\nEnding: After scoring, everyone confirms the next round. After the final round, the highest total score wins. Break tied total scores using the recipe ranking from the final round.",
			red: "Red",
			blue: "Blue",
			yellow: "Yellow",
			black: "Black",
			four: "Four of a kind",
			full: "Full house",
			straight: "Straight",
			three: "Three of a kind",
			mini: "Mini straight",
			pair: "Pair",
			mixed: "Mixed",
			round: "Round {{n}} / {{total}}",
			prepare: "Arrange your mushrooms",
			gather: "Gather mushrooms",
			predict: "The pig’s guesses",
			reveal: "Reveal the mushrooms",
			collect: "Into the pot",
			score: "Compare recipes",
			roundEnd: "This round’s harvest",
			yourTurn: "Your turn to gather",
			waiting: "Waiting for {{name}} to gather",
			waitingPrepare: "Waiting for the other players",
			preparing: "Choose a central card, then confirm your row.",
			preparingTwo: "Confirm your row. You may reorder equal numbers.",
			central: "Central cards",
			tableau: "Row",
			hand: "Initial hand",
			own: "Your row",
			start: "Starts",
			ready: "Ready",
			points: "{{n}} pts",
			pickCount: "Gathered {{n}} / 4",
			prepareConfirm: "Ready",
			centerChoice: "Set central card",
			centerSelected: "Central card chosen",
			orderHint: "Select two equal-numbered cards to swap them.",
			swap: "Swap with an equal-numbered card",
			selectCenter: "Choose a central card first",
			deckColors: "Remaining deck colors",
			mushroom: "Mushroom",
			pot: "Pot",
			basket: "Basket",
			basketStars: "Basket: {{n}} stars",
			stars: "{{n}} stars",
			chooseTarget: "Choose a mushroom card",
			claimMushroom: "Gather face up",
			claimPot: "Gather under pot",
			cancel: "Cancel",
			potPenalty: "Using the pot now loses both basket stars.",
			blocked: "Its facing card is claimed",
			hidden: "Unknown number",
			privateCard: "Only you can see this",
			publicCard: "Revealed",
			selected: "Selected",
			collectedBy: "{{name}}’s {{token}} token",
			cardLabel: "{{color}} {{n}}",
			cardBack: "{{color}} mushroom, unknown number",
			cardSlot: "{{owner}}’s card {{n}}, {{card}}",
			centerSlot: "Central card, {{card}}",
			pairSlot: "Pair {{n}}",
			pig: "Pig",
			pigOption: "Include the pig",
			pigOptionHint: "For three or four players. Guess every opponent’s initial hand number to score, but forfeit recipe points this round.",
			pigChoose: "Choose the pig",
			pigClaimed: "{{name}} chose the pig",
			guessPrompt: "Guess each opponent’s initial hand-card number.",
			guessWaiting: "Waiting for {{name}} to guess",
			guessFor: "{{name}}’s hand number",
			guessConfirm: "Confirm guesses",
			pigBonus: "Pig: {{n}} pts",
			guessResult: "Guessed {{guess}}, actual {{actual}}",
			recipe: "Recipes",
			first: "First",
			second: "Second",
			strength: "Strength",
			rank: "Place {{n}}",
			next: "Next round",
			nextWaiting: "Waiting for the other players",
			scoreDetail: "Points by round",
			finalSoup: "The final soup",
			reviewTable: "Review final table",
			backResult: "Back to results",
			winner: "{{name}} wins",
			noRecipePoints: "The pig earns no recipe points",
			soup: "{{name}}’s soup",
			scoreLine: "{{kind}} · {{stars}} stars · {{points}} pts",
			tokenCount: "{{n}} {{token}} tokens left",
			peek: "Inspect your cards",
			hideOwn: "Hide your cards",
			botPrepare: "Arrange the row",
			botClaim: "Gather {{card}}",
			botPredict: "Guess the opponents’ hands",
			botNext: "Start the next round",
			invalid: "That action is unavailable. Please choose again."
		}
	}
};
//#endregion
export { Se as default };
