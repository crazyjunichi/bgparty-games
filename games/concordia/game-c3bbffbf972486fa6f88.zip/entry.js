import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useCallback as n, useRef as r, useState as i } from "react";
import { useT as a } from "@bgparty/sdk/i18n";
import { useFxAnchor as o, useFxAnchorsMaybe as s } from "@bgparty/sdk/fx/anchors";
import { Texture as c } from "@bgparty/sdk/texture";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { LogTicker as f } from "@bgparty/sdk/ui/log-sheet";
import { gameAssetUrl as p } from "@bgparty/sdk/assets";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { SheetFxProbe as _, SheetView as v } from "@bgparty/sdk/sheet-view";
import { Floater as y, FlySprite as b, PulseBox as x } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as S, OptionSection as C, OptionSwitch as w } from "@bgparty/sdk/ui/game-options";
//#region src/games/concordia/data.ts
var T = [
	"brick",
	"food",
	"tool",
	"wine",
	"cloth"
], E = () => ({
	brick: 0,
	food: 0,
	tool: 0,
	wine: 0,
	cloth: 0
}), D = {
	brick: 3,
	food: 4,
	tool: 5,
	wine: 6,
	cloth: 7
}, O = {
	brick: 1,
	food: 2,
	tool: 3,
	wine: 4,
	cloth: 5
}, k = {
	brick: 2,
	food: 2,
	tool: 2,
	wine: 2,
	cloth: 1
}, A = [
	"vesta",
	"jupiter",
	"saturnus",
	"mercurius",
	"mars",
	"minerva"
], j = (e, t, n) => ({
	id: e,
	role: t,
	god: n,
	cost: [],
	deck: 0
}), M = [
	j("s-architect", "architect", "jupiter"),
	j("s-diplomat", "diplomat", "jupiter"),
	j("s-mercator", "mercator", "mercurius"),
	j("s-prefect1", "prefect", "saturnus"),
	j("s-prefect2", "prefect", "saturnus"),
	j("s-senator", "senator", "vesta"),
	j("s-tribune", "tribune", "mars")
], N = [
	[
		1,
		"architect",
		"jupiter",
		["tool"]
	],
	[
		1,
		"prefect",
		"saturnus",
		["wine"]
	],
	[
		1,
		"mercator",
		"mercurius",
		["wine"]
	],
	[
		1,
		"colonist",
		"mars",
		["food"]
	],
	[
		1,
		"diplomat",
		"saturnus",
		["tool"]
	],
	[
		1,
		"mason",
		"minerva",
		["food"],
		"brick",
		3
	],
	[
		1,
		"farmer",
		"minerva",
		["brick", "food"],
		"food",
		3
	],
	[
		1,
		"smith",
		"minerva",
		["brick", "tool"],
		"tool",
		3
	],
	[
		2,
		"architect",
		"jupiter",
		["tool"]
	],
	[
		2,
		"prefect",
		"saturnus",
		["wine"]
	],
	[
		2,
		"mercator",
		"mercurius",
		["wine"]
	],
	[
		2,
		"colonist",
		"mars",
		["food"]
	],
	[
		2,
		"consul",
		"jupiter",
		["cloth"]
	],
	[
		2,
		"vintner",
		"minerva",
		["brick", "wine"],
		"wine",
		4
	],
	[
		2,
		"weaver",
		"minerva",
		["brick", "cloth"],
		"cloth",
		5
	],
	[
		3,
		"architect",
		"jupiter",
		["tool"]
	],
	[
		3,
		"prefect",
		"saturnus",
		["wine"]
	],
	[
		3,
		"mercator",
		"mercurius",
		["wine"]
	],
	[
		3,
		"colonist",
		"mars",
		["food"]
	],
	[
		3,
		"diplomat",
		"saturnus",
		["food"]
	],
	[
		3,
		"consul",
		"jupiter",
		["cloth"]
	],
	[
		4,
		"architect",
		"jupiter",
		["tool"]
	],
	[
		4,
		"prefect",
		"saturnus",
		["wine"]
	],
	[
		4,
		"colonist",
		"mars",
		["food"]
	],
	[
		4,
		"diplomat",
		"mercurius",
		["tool"]
	],
	[
		4,
		"consul",
		"jupiter",
		["cloth"]
	],
	[
		5,
		"prefect",
		"saturnus",
		["wine"]
	],
	[
		5,
		"mercator",
		"mercurius",
		["wine"]
	],
	[
		5,
		"diplomat",
		"mars",
		["food"]
	],
	[
		5,
		"consul",
		"jupiter",
		["cloth"]
	]
].map(([e, t, n, r, i, a], o) => ({
	id: `m${o}`,
	deck: e,
	role: t,
	god: n,
	cost: r,
	...i ? {
		specialty: i,
		points: a
	} : {}
})), P = Object.fromEntries([...M, ...N].map((e) => [e.id, e])), ee = [
	[],
	["any"],
	["any"],
	["cloth"],
	["cloth"],
	["any", "cloth"],
	["cloth", "cloth"]
], te = {
	A: [
		"food",
		"brick",
		"brick",
		"food",
		"tool",
		"wine",
		"cloth"
	],
	B: [
		"tool",
		"tool",
		"food",
		"brick",
		"brick",
		"food",
		"wine",
		"cloth"
	],
	C: [
		"wine",
		"wine",
		"tool",
		"food",
		"brick",
		"brick",
		"brick",
		"food",
		"tool",
		"cloth"
	],
	D: [...T]
};
function ne(e, t, n, r, i) {
	let a = n.map(([e, t, n, r, i]) => ({
		id: e.toLowerCase().replace(/[^a-z]/g, ""),
		name: e,
		x: t,
		y: n,
		province: r,
		group: i
	})), o = [];
	for (let [e, t] of [["land", r], ["sea", i]]) for (let [n, i] of t.split(" ").entries()) {
		let [t, s] = i.split("-").map(Number), c = e === "sea" && r.split(" ").some((e) => e === i || e === `${s}-${t}`);
		o.push({
			id: `${e[0]}${n}`,
			a: a[t].id,
			b: a[s].id,
			kind: e,
			bend: e === "sea" ? c ? 48 : 24 : 0
		});
	}
	return {
		id: e,
		cities: a,
		roads: o,
		provinces: t
	};
}
var F = {
	italia: ne("italia", [
		"Venetia",
		"Transpadana",
		"Liguria",
		"Aemilia",
		"Etruria",
		"Corsica",
		"Umbria",
		"Campania",
		"Apulia",
		"Lucania",
		"Sicilia"
	], [
		[
			"Roma",
			880,
			779,
			-1,
			""
		],
		[
			"Bauzanum",
			305,
			389,
			0,
			"A"
		],
		[
			"Aquileia",
			488,
			367,
			0,
			"A"
		],
		[
			"Verona",
			391,
			503,
			0,
			"A"
		],
		[
			"Comum",
			223,
			697,
			1,
			"A"
		],
		[
			"Segusio",
			178,
			884,
			1,
			"A"
		],
		[
			"Genua",
			335,
			866,
			2,
			"A"
		],
		[
			"Nicae",
			305,
			1072,
			2,
			"A"
		],
		[
			"Mutina",
			469,
			615,
			3,
			"B"
		],
		[
			"Ravenna",
			608,
			512,
			3,
			"B"
		],
		[
			"Florentia",
			608,
			694,
			4,
			"B"
		],
		[
			"Cosa",
			732,
			814,
			4,
			"B"
		],
		[
			"Aleria",
			635,
			1020,
			5,
			"B"
		],
		[
			"Olbia",
			806,
			1100,
			5,
			"B"
		],
		[
			"Ancona",
			781,
			479,
			6,
			"C"
		],
		[
			"Hadria",
			948,
			525,
			6,
			"C"
		],
		[
			"Spoletium",
			816,
			629,
			6,
			"C"
		],
		[
			"Casinum",
			999,
			688,
			7,
			"B"
		],
		[
			"Neapolis",
			1153,
			727,
			7,
			"B"
		],
		[
			"Luceria",
			1153,
			540,
			8,
			"C"
		],
		[
			"Brundisium",
			1368,
			425,
			8,
			"C"
		],
		[
			"Potentia",
			1284,
			616,
			9,
			"C"
		],
		[
			"Croton",
			1503,
			663,
			9,
			"C"
		],
		[
			"Messana",
			1486,
			893,
			10,
			"C"
		],
		[
			"Syracusae",
			1584,
			988,
			10,
			"C"
		],
		[
			"Panormus",
			1344,
			1063,
			10,
			"C"
		]
	], "1-2 1-3 2-3 2-9 3-9 3-8 3-4 4-8 4-5 4-6 5-6 5-7 6-7 6-10 8-9 8-10 9-10 9-14 10-11 10-16 11-0 0-16 0-17 16-14 16-15 16-17 15-17 15-19 17-19 17-18 19-20 19-21 21-20 21-22 22-23 23-25 25-24", "2-14 2-9 9-14 14-15 15-20 20-22 22-24 22-23 23-24 23-25 24-25 18-23 18-25 0-18 0-25 0-13 0-11 6-11 6-7 7-12 11-12 12-13 13-25"),
	imperium: ne("imperium", [
		"Britannia",
		"Gallia",
		"Hispania",
		"Germania",
		"Italia",
		"Mauretania",
		"Dacia",
		"Hellas",
		"Lybia",
		"Asia",
		"Syria",
		"Aegyptus"
	], [
		[
			"Roma",
			835,
			686,
			-1,
			""
		],
		[
			"Isca D.",
			290,
			427,
			0,
			"A"
		],
		[
			"Londinium",
			391,
			370,
			0,
			"A"
		],
		[
			"Lutetia",
			480,
			480,
			1,
			"B"
		],
		[
			"Burdigala",
			417,
			637,
			1,
			"B"
		],
		[
			"Massilia",
			596,
			672,
			1,
			"B"
		],
		[
			"Brigantium",
			203,
			698,
			2,
			"B"
		],
		[
			"Olisipo",
			205,
			882,
			2,
			"B"
		],
		[
			"Valentia",
			468,
			868,
			2,
			"B"
		],
		[
			"Colonia A.",
			613,
			366,
			3,
			"A"
		],
		[
			"Vindobona",
			860,
			396,
			3,
			"A"
		],
		[
			"Novaria",
			690,
			568,
			4,
			"D"
		],
		[
			"Aquileia",
			844,
			534,
			4,
			"D"
		],
		[
			"Syracusae",
			963,
			832,
			4,
			"D"
		],
		[
			"Rusadir",
			392,
			1042,
			5,
			"B"
		],
		[
			"Carthago",
			794,
			901,
			5,
			"B"
		],
		[
			"Sirmium",
			1033,
			506,
			6,
			"A"
		],
		[
			"Napoca",
			1130,
			399,
			6,
			"A"
		],
		[
			"Tomis",
			1255,
			492,
			6,
			"A"
		],
		[
			"Dyrrhachium",
			1054,
			675,
			7,
			"D"
		],
		[
			"Athenae",
			1211,
			784,
			7,
			"D"
		],
		[
			"Leptis Magna",
			950,
			1071,
			8,
			"C"
		],
		[
			"Cyrene",
			1173,
			1021,
			8,
			"C"
		],
		[
			"Byzantium",
			1328,
			617,
			9,
			"C"
		],
		[
			"Sinope",
			1536,
			565,
			9,
			"C"
		],
		[
			"Attalia",
			1441,
			775,
			9,
			"C"
		],
		[
			"Antiochia",
			1618,
			774,
			10,
			"C"
		],
		[
			"Tyros",
			1594,
			925,
			10,
			"C"
		],
		[
			"Alexandria",
			1423,
			1009,
			11,
			"C"
		],
		[
			"Memphis",
			1498,
			1109,
			11,
			"C"
		],
		[
			"Petra",
			1631,
			1070,
			11,
			"C"
		]
	], "1-2 2-3 3-9 3-4 3-5 4-5 4-6 6-7 6-8 7-8 7-14 8-14 8-5 14-15 15-21 21-22 21-29 22-29 22-28 28-29 28-27 29-30 30-27 27-26 26-25 26-24 25-23 23-24 23-18 23-19 18-17 18-16 17-16 16-10 16-12 16-19 19-20 9-10 9-11 10-12 11-12 11-5 11-0 12-0 0-13", "1-2 1-6 1-4 2-9 4-6 6-7 7-14 8-14 8-15 8-5 14-15 5-15 5-0 0-15 0-13 15-21 21-13 21-22 13-19 13-20 13-22 12-19 20-22 20-28 20-23 20-25 23-24 23-18 18-24 25-26 25-28 26-27 27-28 28-22")
};
function I(e, t) {
	let n = e.cities.find((e) => e.id === t.a), r = e.cities.find((e) => e.id === t.b), i = r.x - n.x, a = r.y - n.y, o = Math.hypot(i, a);
	return {
		x: (n.x + r.x) / 2 - a / o * t.bend / 2,
		y: (n.y + r.y) / 2 + i / o * t.bend / 2
	};
}
function re(e, t) {
	let n = e.cities.find((e) => e.id === t.a), r = e.cities.find((e) => e.id === t.b), i = r.x - n.x, a = r.y - n.y, o = Math.hypot(i, a);
	return `M${n.x} ${n.y} Q${(n.x + r.x) / 2 - a / o * t.bend} ${(n.y + r.y) / 2 + i / o * t.bend} ${r.x} ${r.y}`;
}
//#endregion
//#region src/games/concordia/logic.ts
var L = (e) => T.reduce((t, n) => t + e[n], 0), R = (e) => 12 - (6 - e.units.length) - L(e.goods);
function ie(e, t, n, r) {
	let i = F[e.map], a = e.players.find((e) => e.rid === t)?.units[n];
	if (!a) return {};
	let o = i.roads.filter((e) => e.kind === a.kind), s = o.find((e) => e.id === a.location), c = {}, l = [];
	if (s) c[s.id] = 0, l.push(s.id);
	else for (let e of o) (e.a === a.location || e.b === a.location) && (c[e.id] = 1, l.push(e.id));
	for (let e = 0; e < l.length; e++) {
		let t = o.find((t) => t.id === l[e]);
		if (!(c[t.id] >= r)) for (let e of o) c[e.id] === void 0 && (e.a === t.a || e.b === t.a || e.a === t.b || e.b === t.b) && (c[e.id] = c[t.id] + 1, l.push(e.id));
	}
	let u = e.players.flatMap((e) => e.units.filter((r, i) => e.rid !== t || i !== n).map((e) => e.location));
	return Object.fromEntries(Object.entries(c).filter(([e, t]) => t > 0 && t <= r && !u.includes(e)));
}
function z(e, t) {
	let n = F[e];
	return [...new Set(t.flatMap((e) => {
		let t = n.roads.find((t) => t.id === e.location);
		return t ? [t.a, t.b] : [e.location];
	}))];
}
function B(e, t) {
	let n = e.cityGoods[t];
	if (!n) return null;
	let r = E();
	return n === "brick" ? r.food = 1 : (r.brick = 1, r[n] += 1), {
		goods: r,
		cash: O[n] * (1 + e.players.filter((e) => e.houses.includes(t)).length)
	};
}
var V = (e, t) => T.every((n) => e[n] >= t[n]);
function ae(e, t) {
	let n = e.players.find((e) => e.rid === t);
	return !n || n.houses.length >= 15 ? [] : z(e.map, n.units).filter((t) => {
		let r = B(e, t);
		return r && !n.houses.includes(t) && n.cash >= r.cash && V(n.goods, r.goods);
	});
}
function oe(e, t, n, r) {
	let i = P[e];
	if (!i) return null;
	let a = E();
	for (let e of i.cost) a[e] += 1;
	if (!n) for (let e of ee[t]) if (e === "any") {
		if (!r) return null;
		a[r] += 1;
	} else a[e] += 1;
	return a;
}
//#endregion
//#region src/games/concordia/meta.ts
var se = {
	id: "concordia",
	tier: "alpha",
	nameKey: "games.concordia.name",
	descKey: "games.concordia.desc",
	rulesKey: "games.concordia.rules",
	icon: "🏛️",
	iconImg: "games/concordia.webp",
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [3, 4],
	accent: "#376c79",
	releasedAt: "2026-10-31T15:00:36+08:00",
	search: {
		py: "kang kao di ya",
		init: "kkdy"
	},
	hotseat: "cover",
	mechanics: [
		"hand-management",
		"deck-bag-building",
		"route-building"
	],
	interactionTags: [],
	rulesUrl: { en: "https://www.pd-verlag.de/WebRoot/HostEurope/Shops/es719366/MediaGallery/Spielregeln/Concordia_rules_eng_1_1.pdf" }
}, H = t.enum([
	"brick",
	"food",
	"tool",
	"wine",
	"cloth"
]), ce = t.object({
	brick: t.int().nonnegative(),
	food: t.int().nonnegative(),
	tool: t.int().nonnegative(),
	wine: t.int().nonnegative(),
	cloth: t.int().nonnegative()
}), U = t.object({
	map: t.enum([
		"auto",
		"italia",
		"imperium"
	]).default("auto"),
	intermediate: t.boolean().default(!1)
}).default({
	map: "auto",
	intermediate: !1
}), le = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		card: t.string().max(24)
	}),
	t.object({
		type: t.literal("move"),
		unit: t.int().min(0).max(5),
		road: t.string().max(8)
	}),
	t.object({
		type: t.literal("build"),
		city: t.string().max(32)
	}),
	t.object({
		type: t.literal("produce"),
		province: t.int().min(0).max(11)
	}),
	t.object({ type: t.literal("cash") }),
	t.object({
		type: t.literal("copy"),
		rid: t.string().max(128)
	}),
	t.object({
		type: t.literal("trade"),
		good: H,
		amount: t.int().min(-12).max(12).refine((e) => e !== 0)
	}),
	t.object({
		type: t.literal("buy"),
		slot: t.int().min(0).max(6),
		payment: H.optional()
	}),
	t.object({
		type: t.literal("recruit"),
		kind: t.enum(["land", "sea"]),
		city: t.string().max(32)
	}),
	t.object({
		type: t.literal("receive"),
		goods: ce
	}),
	t.object({ type: t.literal("finish") })
]), ue = t.object({
	kind: t.enum(["land", "sea"]),
	location: t.string()
}), de = t.object({
	rid: t.string(),
	cash: t.int(),
	goods: ce,
	houses: t.array(t.string()),
	units: t.array(ue),
	handCount: t.int(),
	discardCount: t.int(),
	top: t.string().nullable(),
	bought: t.array(t.string()),
	intermediate: t.int().nullable()
}), fe = t.object({
	vesta: t.int(),
	jupiter: t.int(),
	saturnus: t.int(),
	mercurius: t.int(),
	mars: t.int(),
	minerva: t.int(),
	concordia: t.int(),
	total: t.int(),
	cards: t.array(t.string()),
	factors: t.record(t.string(), t.int())
}), pe = t.object({
	rid: t.string(),
	kind: t.enum([
		"play",
		"move",
		"build",
		"produce",
		"cash",
		"trade",
		"buy",
		"recruit",
		"receive",
		"finish",
		"intermediate",
		"end"
	]),
	target: t.string().optional(),
	n: t.int().optional(),
	good: H.optional()
}), me = t.enum([
	"play",
	"move",
	"build",
	"prefect",
	"trade",
	"buy",
	"colonist",
	"tribune",
	"copy",
	"receive",
	"done"
]), he = t.object({
	map: t.enum(["italia", "imperium"]),
	players: t.array(de),
	turn: t.string(),
	phase: me,
	actor: t.string(),
	turnNo: t.int(),
	cityGoods: t.record(t.string(), H),
	activeProvinces: t.array(t.boolean()),
	bonuses: t.array(H),
	magnus: t.string(),
	market: t.array(t.string().nullable()),
	deckCount: t.int(),
	card: t.string().nullable(),
	movement: t.int(),
	purchases: t.int(),
	traded: t.array(H),
	recruited: t.int(),
	pending: t.object({
		rid: t.string(),
		goods: ce,
		space: t.int()
	}).nullable(),
	endBy: t.string().nullable(),
	log: t.array(pe),
	scores: t.record(t.string(), fe).nullable(),
	intermediateEnabled: t.boolean(),
	intermediateAwarded: t.boolean()
}), ge = t.object({
	hand: t.array(t.string()),
	discard: t.array(t.string())
}), W = () => ({ code: "games.concordia.invalid" }), _e = (e, t) => {
	for (let n of T) e.goods[n] -= t[n];
}, G = (e, t) => e.players.find((e) => e.rid === t), K = (e, t) => {
	e.log.push(t);
};
function ve(t, n) {
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function ye(e, t) {
	let n = e.players.find((e) => e.rid === t), r = [...n.hand, ...n.discard], i = F[e.map], a = {
		vesta: 0,
		jupiter: 0,
		saturnus: 0,
		mercurius: 0,
		mars: 0,
		minerva: 0,
		concordia: e.endBy === t ? 7 : 0,
		total: 0,
		cards: r,
		factors: {}
	}, o = (t) => n.houses.filter((n) => e.cityGoods[n] === t).length, s = {
		vesta: Math.floor((n.cash + T.reduce((e, t) => e + n.goods[t] * D[t], 0)) / 10),
		jupiter: n.houses.filter((t) => e.cityGoods[t] !== "brick").length,
		saturnus: new Set(n.houses.map((e) => i.cities.find((t) => t.id === e).province)).size,
		mercurius: T.filter((e) => o(e) > 0).length * 2,
		mars: n.units.length * 2,
		minerva: 0
	};
	for (let e of A) a.factors[e] = s[e];
	for (let e of r) {
		let t = P[e];
		a[t.god] += t.specialty ? o(t.specialty) * t.points : s[t.god];
	}
	for (let e of T) a.factors[e] = o(e);
	return a.total = A.reduce((e, t) => e + a[t], a.concordia), a;
}
function be(e) {
	for (e.market = e.market.filter((e) => e !== null); e.market.length < 7 && e.deck.length;) e.market.push(e.deck.shift());
}
function xe(e, t) {
	e.endBy || (e.endBy = t, K(e, {
		rid: t,
		kind: "end"
	}));
}
function Se(e) {
	be(e);
	let t = e.players[(e.players.findIndex((t) => t.rid === e.turn) + 1) % e.players.length].rid;
	if (t === e.endBy) {
		e.phase = "done", e.scores = Object.fromEntries(e.players.map((t) => [t.rid, ye(e, t.rid)]));
		return;
	}
	e.turn = t, e.phase = "play", e.card = null, e.turnNo++, e.traded = [], e.movement = 0, e.purchases = 0, e.recruited = 0;
}
function Ce(e, t) {
	for (; e.gains.length;) {
		let n = e.gains[0], r = G(e, n.rid), i = R(r), a = L(n.goods);
		if (a > i && i > 0) {
			e.phase = "receive";
			return;
		}
		if (i > 0) {
			for (let e of T) r.goods[e] += n.goods[e];
			K(e, {
				rid: r.rid,
				kind: "receive",
				n: a
			}), t.push({
				kind: "concordiaGain",
				rid: r.rid,
				data: {
					goods: n.goods,
					source: n.source
				}
			});
		}
		e.gains.shift();
	}
	Se(e);
}
function we(e, t) {
	if (e.intermediateEnabled && t.intermediate === null && (t.intermediate = ye(e, t.rid).total, K(e, {
		rid: t.rid,
		kind: "intermediate",
		n: t.intermediate
	}), e.players.every((e) => e.intermediate !== null) && !e.intermediateAwarded)) {
		let t = [...new Set(e.players.map((e) => e.intermediate))].sort((e, t) => t - e);
		for (let n of e.players) n.cash += n.intermediate === t[0] ? 2 : +(n.intermediate === t[1]);
		e.intermediateAwarded = !0;
	}
}
function Te(e, t, n, r) {
	let i = G(e, e.turn);
	if (t === "architect") e.phase = "move", e.movement = i.units.length;
	else if (t === "prefect") e.phase = "prefect";
	else if (t === "mercator") e.phase = "trade", i.cash += P[n].deck ? 5 : 3, r.push({
		kind: "concordiaCash",
		rid: i.rid,
		data: { n: P[n].deck ? 5 : 3 }
	});
	else if (t === "diplomat") e.phase = "copy";
	else if (t === "senator" || t === "consul") e.phase = "buy", e.purchases = t === "senator" ? 2 : 1;
	else if (t === "colonist") e.phase = "colonist";
	else if (t === "tribune") {
		let t = i.discard.length;
		i.cash += Math.max(0, t - 3), i.hand.push(...i.discard), i.discard = [], e.phase = "tribune", we(e, i), r.push({
			kind: "concordiaRecover",
			rid: i.rid,
			data: { n: t }
		});
	} else {
		let t = P[n].specialty, a = E();
		a[t] = i.houses.filter((n) => e.cityGoods[n] === t).length, e.gains = [{
			rid: i.rid,
			goods: a,
			source: `cc:discard:${i.rid}`
		}], Ce(e, r);
	}
}
function Ee(t, n, r) {
	let i = t.map === "auto" ? n.length <= 3 ? "italia" : "imperium" : t.map === "italia" && n.length > 4 ? "imperium" : t.map === "imperium" && n.length < 3 ? "italia" : t.map, a = e(r, 0, n.length), o = [...n.slice(a), ...n.slice(0, a)], s = {
		map: i,
		players: o.map((e, t) => ({
			rid: e,
			cash: 5 + t,
			goods: {
				brick: 1,
				food: 2,
				tool: 1,
				wine: 1,
				cloth: 1
			},
			houses: [],
			units: [{
				kind: "land",
				location: "roma"
			}, {
				kind: "sea",
				location: "roma"
			}],
			hand: M.map((e) => e.id),
			discard: [],
			handCount: 7,
			discardCount: 0,
			top: null,
			bought: [],
			intermediate: null
		})),
		turn: o[0],
		phase: "play",
		turnNo: 1,
		cityGoods: {},
		activeProvinces: [],
		bonuses: [],
		magnus: o.at(-1),
		market: [],
		deck: [],
		card: null,
		movement: 0,
		purchases: 0,
		traded: [],
		recruited: 0,
		gains: [],
		endBy: null,
		log: [],
		scores: null,
		intermediateEnabled: t.intermediate,
		intermediateAwarded: !1,
		seed: r,
		cursor: 1
	};
	for (let e of [
		"A",
		"B",
		"C",
		"D"
	]) {
		let t = ve(s, [...te[e]]);
		for (let n of F[i].cities.filter((t) => t.group === e)) s.cityGoods[n.id] = t.pop();
	}
	s.bonuses = F[i].provinces.map((e, t) => F[i].cities.filter((e) => e.province === t).map((e) => s.cityGoods[e.id]).sort((e, t) => D[t] - D[e])[0]), s.activeProvinces = s.bonuses.map(() => !0);
	for (let e = 1; e <= n.length; e++) s.deck.push(...ve(s, N.filter((t) => t.deck === e).map((e) => e.id)));
	return be(s), {
		state: s,
		fx: []
	};
}
function De(e, t, n) {
	let r = e.phase === "receive" ? e.gains[0]?.rid : e.turn;
	if (e.phase === "done" || n.by !== r) return W();
	let i = structuredClone(e), a = G(i, i.turn), o = [];
	if (t.type === "play") {
		if (i.phase !== "play" || !a.hand.includes(t.card) || !P[t.card]) return W();
		a.hand.splice(a.hand.indexOf(t.card), 1), a.discard.push(t.card), i.card = t.card, K(i, {
			rid: a.rid,
			kind: "play",
			target: t.card
		}), o.push({
			kind: "concordiaPlay",
			rid: a.rid,
			data: { card: t.card }
		}), Te(i, P[t.card].role, t.card, o);
	} else if (t.type === "copy") {
		let e = i.players.find((e) => e.rid === t.rid), n = e?.discard.at(-1);
		if (i.phase !== "copy" || !e || e.rid === a.rid || !n || ["tribune", "diplomat"].includes(P[n].role)) return W();
		i.card = n, Te(i, P[n].role, n, o);
	} else if (t.type === "move") {
		if (i.phase !== "move") return W();
		let e = ie(i, a.rid, t.unit, i.movement)[t.road];
		if (e === void 0) return W();
		let n = a.units[t.unit].location;
		a.units[t.unit].location = t.road, i.movement -= e, K(i, {
			rid: a.rid,
			kind: "move",
			target: t.road,
			n: e
		}), o.push({
			kind: "concordiaMove",
			rid: a.rid,
			data: {
				unit: t.unit,
				from: n,
				to: t.road
			}
		});
	} else if (t.type === "build") {
		if (i.phase !== "build" || !ae(i, a.rid).includes(t.city)) return W();
		let e = B(i, t.city);
		_e(a, e.goods), a.cash -= e.cash, a.houses.push(t.city), K(i, {
			rid: a.rid,
			kind: "build",
			target: t.city,
			n: e.cash
		}), o.push({
			kind: "concordiaBuild",
			rid: a.rid,
			data: { city: t.city }
		}), a.houses.length === 15 && xe(i, a.rid);
	} else if (t.type === "produce") {
		if (i.phase !== "prefect" || !i.activeProvinces[t.province]) return W();
		i.activeProvinces[t.province] = !1, i.gains = i.players.map((e) => {
			let n = E();
			for (let r of F[i.map].cities.filter((n) => n.province === t.province && e.houses.includes(n.id))) n[i.cityGoods[r.id]]++;
			return e.rid === a.rid && (n[i.bonuses[t.province]] += i.magnus === a.rid ? 2 : 1), {
				rid: e.rid,
				goods: n,
				source: `cc:province:${t.province}`
			};
		}).filter((e) => L(e.goods) > 0), i.magnus === a.rid && (i.magnus = i.players[(i.players.findIndex((e) => e.rid === a.rid) + i.players.length - 1) % i.players.length].rid), K(i, {
			rid: a.rid,
			kind: "produce",
			target: String(t.province)
		}), o.push({
			kind: "concordiaProvince",
			data: { province: t.province }
		}), Ce(i, o);
	} else if (t.type === "cash") {
		if (i.phase !== "prefect" && i.phase !== "colonist" || i.phase === "colonist" && i.recruited > 0) return W();
		let e = i.phase === "colonist" ? 5 + a.units.length : i.bonuses.reduce((e, t, n) => e + (i.activeProvinces[n] ? 0 : k[t]), 0);
		i.phase === "prefect" && i.activeProvinces.fill(!0), a.cash += e, K(i, {
			rid: a.rid,
			kind: "cash",
			n: e
		}), o.push({
			kind: "concordiaCash",
			rid: a.rid,
			data: { n: e }
		}), Se(i);
	} else if (t.type === "trade") {
		if (i.phase !== "trade" || !i.traded.includes(t.good) && i.traded.length >= 2 || t.amount > 0 && (R(a) < t.amount || a.cash < D[t.good] * t.amount) || a.goods[t.good] + t.amount < 0) return W();
		a.goods[t.good] += t.amount, a.cash -= D[t.good] * t.amount, i.traded.includes(t.good) || i.traded.push(t.good), K(i, {
			rid: a.rid,
			kind: "trade",
			good: t.good,
			n: t.amount
		}), o.push({
			kind: "concordiaTrade",
			rid: a.rid,
			data: {
				good: t.good,
				n: t.amount
			}
		});
	} else if (t.type === "buy") {
		let e = i.market[t.slot];
		if (i.phase !== "buy" || i.purchases < 1 || !e) return W();
		let n = oe(e, t.slot, P[i.card].role === "consul", t.payment);
		if (!n || !V(a.goods, n)) return W();
		_e(a, n), a.hand.push(e), a.bought.push(e), i.market[t.slot] = null, i.purchases--, K(i, {
			rid: a.rid,
			kind: "buy",
			target: e,
			n: t.slot
		}), o.push({
			kind: "concordiaBuy",
			rid: a.rid,
			data: {
				card: e,
				slot: t.slot
			}
		}), i.deck.length === 0 && i.market.every((e) => e === null) && xe(i, a.rid), (i.purchases === 0 || i.market.every((e) => e === null)) && Se(i);
	} else if (t.type === "recruit") {
		if (i.phase !== "colonist" && i.phase !== "tribune" || i.phase === "tribune" && (i.recruited > 0 || t.city !== "roma") || !["roma", ...a.houses].includes(t.city) || a.units.filter((e) => e.kind === t.kind).length >= 3 || a.goods.food < 1 || a.goods.tool < 1 || !F[i.map].cities.some((e) => e.id === t.city)) return W();
		a.goods.food--, a.goods.tool--, a.units.push({
			kind: t.kind,
			location: t.city
		}), i.recruited++, K(i, {
			rid: a.rid,
			kind: "recruit",
			target: t.city
		}), o.push({
			kind: "concordiaRecruit",
			rid: a.rid,
			data: {
				unit: a.units.length - 1,
				city: t.city,
				kind: t.kind
			}
		});
	} else if (t.type === "receive") {
		if (i.phase !== "receive" || !i.gains.length) return W();
		let e = i.gains[0], n = G(i, e.rid), r = R(n);
		if (L(t.goods) !== Math.min(r, L(e.goods)) || !V(e.goods, t.goods)) return W();
		for (let e of T) n.goods[e] += t.goods[e];
		K(i, {
			rid: n.rid,
			kind: "receive",
			n: L(t.goods)
		}), o.push({
			kind: "concordiaGain",
			rid: n.rid,
			data: {
				goods: t.goods,
				source: e.source
			}
		}), i.gains.shift(), Ce(i, o);
	} else if (t.type === "finish") {
		if (i.phase === "move") i.phase = "build";
		else if ([
			"build",
			"trade",
			"buy",
			"colonist",
			"tribune",
			"copy"
		].includes(i.phase)) K(i, {
			rid: a.rid,
			kind: "finish"
		}), Se(i);
		else return W();
	}
	return {
		state: i,
		fx: o
	};
}
function Oe(e, t) {
	let n = e.players.find((e) => e.rid === t), r = e.phase === "receive" ? e.gains[0] : null;
	return {
		public: {
			map: e.map,
			players: e.players.map(({ hand: e, discard: t, ...n }) => ({
				...n,
				handCount: e.length,
				discardCount: t.length,
				top: t.at(-1) ?? null
			})),
			turn: e.turn,
			actor: r?.rid ?? e.turn,
			phase: e.phase,
			turnNo: e.turnNo,
			cityGoods: { ...e.cityGoods },
			activeProvinces: [...e.activeProvinces],
			bonuses: [...e.bonuses],
			magnus: e.magnus,
			market: [...e.market],
			deckCount: e.deck.length,
			card: e.card,
			movement: e.movement,
			purchases: e.purchases,
			traded: [...e.traded],
			recruited: e.recruited,
			pending: r ? {
				...r,
				space: R(G(e, r.rid))
			} : null,
			endBy: e.endBy,
			log: e.log.slice(-80),
			scores: e.scores,
			intermediateEnabled: e.intermediateEnabled,
			intermediateAwarded: e.intermediateAwarded
		},
		...n ? { private: {
			hand: [...n.hand],
			discard: [...n.discard]
		} } : {}
	};
}
var ke = {
	meta: se,
	saveCompatibility: { version: "1" },
	schemas: {
		action: le,
		publicView: he,
		privateView: ge,
		config: U
	},
	setup: Ee,
	reduce: De,
	viewFor: Oe,
	status: (e) => {
		if (e.phase !== "done") return { phase: e.phase };
		let t = e.players.map((e) => e.rid), n = t.indexOf(e.magnus), r = [...t.slice(0, n + 1).reverse(), ...t.slice(n + 1).reverse()], i = t.sort((t, n) => e.scores[n].total - e.scores[t].total || r.indexOf(t) - r.indexOf(n));
		return {
			phase: "done",
			ranking: i,
			winner: [i[0]],
			scores: Object.fromEntries(i.map((t) => [t, e.scores[t].total]))
		};
	}
}, q = (e) => `games.concordia.${e}`;
function J({ good: e, className: t, style: n }) {
	return /* @__PURE__ */ h("img", {
		src: p(`games/concordia/${e}.svg`),
		className: t ?? "cc-good",
		style: n,
		alt: "",
		draggable: !1
	});
}
function Ae({ className: e }) {
	return /* @__PURE__ */ g("svg", {
		viewBox: "0 0 140 110",
		className: e,
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ h("path", {
				d: "M8 33 70 4l62 29v10H8z",
				fill: "#d4bb7c",
				stroke: "#695536",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ h("path", {
				d: "m25 30 45-20 45 20z",
				fill: "#8f7652"
			}),
			/* @__PURE__ */ h("path", {
				d: "M8 99h124v7H8zM15 90h110v9H15z",
				fill: "#b79b64",
				stroke: "#695536",
				strokeWidth: "2"
			}),
			[
				25,
				51,
				77,
				103
			].map((e) => /* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("path", {
				d: `M${e - 5} 44h18v7h-18zM${e - 2} 51h12v35h-12zM${e - 5} 85h18v7h-18z`,
				fill: "#f0e0b6",
				stroke: "#8f7652",
				strokeWidth: "2"
			}), /* @__PURE__ */ h("path", {
				d: `M${e + 2} 54v28`,
				stroke: "#b59a66",
				strokeWidth: "3"
			})] }, e)),
			/* @__PURE__ */ h("path", {
				d: "M10 38h120",
				stroke: "#f7e9c1",
				strokeWidth: "3"
			})
		]
	});
}
function Y({ kind: e, color: t = "#376c79", size: n = 30 }) {
	return /* @__PURE__ */ h("svg", {
		width: n,
		height: n,
		viewBox: "0 0 40 40",
		"aria-hidden": !0,
		children: e === "land" ? /* @__PURE__ */ g("g", {
			fill: t,
			stroke: "#352d24",
			strokeWidth: "1.5",
			children: [/* @__PURE__ */ h("circle", {
				cx: "20",
				cy: "7",
				r: "5"
			}), /* @__PURE__ */ h("path", { d: "M14 14h12l6 12-6 2-2-6v14h-7V22l-3 6-6-2z" })]
		}) : /* @__PURE__ */ g("g", {
			stroke: "#352d24",
			strokeWidth: "1.5",
			children: [/* @__PURE__ */ h("path", {
				d: "M4 28h32l-7 9H12z",
				fill: t
			}), /* @__PURE__ */ h("path", {
				d: "M20 4v24M18 5 6 24h12zM23 8l10 16H23z",
				fill: "#f5e7bb"
			})]
		})
	});
}
function je({ color: e = "#b35b42", size: t = 26 }) {
	return /* @__PURE__ */ g("svg", {
		width: t,
		height: t,
		viewBox: "0 0 32 32",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ h("path", {
			d: "m3 13 13-10 13 10-3 3v13H6V16z",
			fill: e,
			stroke: "#44382b",
			strokeWidth: "1.8"
		}), /* @__PURE__ */ h("path", {
			d: "M13 29V18h7v11M3 13h26",
			fill: "#f0dfb9",
			stroke: "#44382b",
			strokeWidth: "1.5"
		})]
	});
}
function Me({ role: e }) {
	let t = e === "mason" ? "brick" : e === "farmer" ? "food" : e === "smith" ? "tool" : e === "vintner" ? "wine" : e === "weaver" ? "cloth" : null;
	return /* @__PURE__ */ h("div", {
		className: "cc-card-relief",
		children: t ? /* @__PURE__ */ h(J, { good: t }) : e === "colonist" ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(Y, {
			kind: "land",
			size: 42
		}), /* @__PURE__ */ h(Y, {
			kind: "sea",
			size: 42
		})] }) : e === "architect" ? /* @__PURE__ */ g("svg", {
			viewBox: "0 0 140 100",
			"aria-hidden": !0,
			children: [
				/* @__PURE__ */ h("path", {
					d: "M24 83 63 13h10l42 70-9 5-37-62-35 62z",
					fill: "#9b967c",
					stroke: "#4b514c",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ h("path", {
					d: "m36 58 57-22M50 71l38-46",
					stroke: "#a9794e",
					strokeWidth: "9"
				}),
				/* @__PURE__ */ h("circle", {
					cx: "68",
					cy: "20",
					r: "9",
					fill: "#d3b96e",
					stroke: "#594936",
					strokeWidth: "3"
				})
			]
		}) : /* @__PURE__ */ h(Ae, {})
	});
}
function Ne() {
	return /* @__PURE__ */ g("div", {
		className: "cc-card-back",
		children: [/* @__PURE__ */ h(Ae, {}), /* @__PURE__ */ h("strong", { children: "CONCORDIA" })]
	});
}
function X({ id: e, onClick: t, disabled: n = !1, selected: r = !1, anchor: i, small: s = !1, back: c = !1 }) {
	let l = a(), u = P[e], { ref: d, hidden: f } = o(i ?? null);
	if (!u) return null;
	let p = [
		"mason",
		"farmer",
		"smith",
		"vintner",
		"weaver"
	].includes(u.role) ? "cardSpecialist" : `card${u.role[0].toUpperCase()}${u.role.slice(1)}`;
	return /* @__PURE__ */ h("button", {
		type: "button",
		ref: d,
		className: `cc-personality ${s ? "cc-small" : ""} ${r ? "cc-selected" : ""}`,
		onClick: t,
		disabled: n,
		style: { visibility: f ? "hidden" : void 0 },
		"aria-label": `${l(q(u.role))} · ${l(q(u.god))}`,
		title: l(q(p)),
		children: c ? /* @__PURE__ */ h(Ne, {}) : /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("header", { children: l(q(u.role)) }),
			/* @__PURE__ */ h(Me, { role: u.role }),
			/* @__PURE__ */ h("span", {
				className: "cc-card-detail",
				children: l(q(p))
			}),
			/* @__PURE__ */ h("span", {
				className: "cc-card-cost",
				children: u.cost.map((e, t) => /* @__PURE__ */ h(J, { good: e }, t))
			}),
			/* @__PURE__ */ g("footer", { children: [/* @__PURE__ */ h("span", { children: u.points ?? (u.god === "mars" || u.god === "mercurius" ? 2 : 1) }), l(q(u.god))] })
		] })
	});
}
//#endregion
//#region src/games/concordia/board.tsx
var Pe = [
	"I",
	"II",
	"III",
	"IV",
	"V",
	"VI",
	"VII",
	"VIII",
	"IX",
	"X",
	"XI",
	"XII"
];
function Fe({ path: e }) {
	return /* @__PURE__ */ h("path", {
		d: e,
		fill: "none",
		stroke: "#fff6d9",
		strokeWidth: "9",
		strokeDasharray: "14 10",
		children: /* @__PURE__ */ h("animate", {
			attributeName: "stroke-dashoffset",
			from: "0",
			to: "-24",
			dur: "0.7s",
			repeatCount: "indefinite"
		})
	});
}
function Ie({ name: e, size: t }) {
	let r = s(), i = n((t) => {
		r?.registerProbe(e, t ? () => {
			let e = t.getBoundingClientRect();
			return {
				x: e.left,
				y: e.top,
				w: e.width,
				h: e.height
			};
		} : null);
	}, [r, e]);
	return /* @__PURE__ */ h("rect", {
		ref: i,
		width: t,
		height: t,
		fill: "none",
		pointerEvents: "none"
	});
}
function Le({ name: e, color: t, x: n, y: r, anchor: i }) {
	let a = o(i);
	return /* @__PURE__ */ g("g", {
		transform: `translate(${n} ${r})`,
		visibility: a.hidden ? "hidden" : void 0,
		children: [
			/* @__PURE__ */ h("title", { children: e }),
			/* @__PURE__ */ h(je, {
				color: t,
				size: 26
			}),
			/* @__PURE__ */ h(Ie, {
				name: i,
				size: 26
			})
		]
	});
}
function Re({ kind: e, color: t, x: n, y: r, anchor: i, label: a, selected: s }) {
	let c = o(i);
	return /* @__PURE__ */ g("g", {
		transform: `translate(${n - 19} ${r - 19})`,
		visibility: c.hidden ? "hidden" : void 0,
		children: [
			/* @__PURE__ */ h("title", { children: a }),
			s && /* @__PURE__ */ h("circle", {
				cx: "19",
				cy: "19",
				r: "25",
				fill: "#ead197",
				stroke: "#775520",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ h(Y, {
				kind: e,
				color: t,
				size: 38
			}),
			/* @__PURE__ */ h(Ie, {
				name: i,
				size: 38
			})
		]
	});
}
function ze({ v: e, members: t, myRid: n, send: r, onInspect: o, recruitKind: s }) {
	let c = a(), u = F[e.map], [d, f] = i(null), [m, y] = i(0), b = e.players.find((e) => e.rid === n), x = e.actor === n && e.phase !== "done", S = d?.turn === e.turnNo ? d.unit : null, C = x && b && b.goods.food > 0 && b.goods.tool > 0 && b.units.filter((e) => e.kind === s).length < 3 && (e.phase === "colonist" || e.phase === "tribune" && e.recruited === 0), w = x && e.phase === "move" && S !== null ? ie(e, n, S, e.movement) : {}, T = x && e.phase === "build" ? ae(e, n) : [], E = C ? e.phase === "tribune" ? ["roma"] : ["roma", ...b.houses] : [], D = (e) => l[(t.find((t) => t.rid === e)?.colorIndex ?? 0) % l.length].hex, O = (e) => t.find((t) => t.rid === e)?.name ?? e, k = e.players.flatMap((e, t) => e.units.map((n, r) => {
		let i = u.roads.find((e) => e.id === n.location), a = u.cities.find((e) => e.id === n.location);
		return {
			p: e,
			u: n,
			i: r,
			...i ? I(u, i) : {
				x: a.x - 65 + t * 29,
				y: a.y + 50 + (n.kind === "sea" ? 32 : 0)
			}
		};
	})), A = [
		...k.filter(({ p: t }) => x && e.phase === "move" && t.rid === n).map(({ i: e, x: t, y: n }) => ({
			key: `u:${e}`,
			rect: {
				x: t - 119,
				y: n - 329,
				w: 38,
				h: 38
			}
		})),
		...Object.keys(w).map((e) => {
			let t = I(u, u.roads.find((t) => t.id === e));
			return {
				key: `r:${e}`,
				rect: {
					x: t.x - 124,
					y: t.y - 334,
					w: 48,
					h: 48
				}
			};
		}),
		...u.cities.map((e) => ({
			key: `c:${e.id}`,
			rect: {
				x: e.x - 132,
				y: e.y - 340,
				w: 64,
				h: 60
			}
		}))
	], j = (t) => {
		let [n, i] = t.split(":");
		n === "u" ? f({
			turn: e.turnNo,
			unit: Number(i)
		}) : n === "r" && S !== null ? r({
			type: "move",
			unit: S,
			road: i
		}) : T.includes(i) ? r({
			type: "build",
			city: i
		}) : E.includes(i) ? r({
			type: "recruit",
			city: i,
			kind: s
		}) : o(i);
	};
	return /* @__PURE__ */ g("div", {
		className: "cc-map",
		children: [/* @__PURE__ */ h(v, {
			image: p(`games/concordia/${e.map}.svg`),
			sheetW: 1600,
			sheetH: 860,
			eligible: A,
			onTapEligible: j,
			fitKey: `${e.map}:${m}`,
			clampToSheet: !0,
			highlight: "off",
			children: /* @__PURE__ */ g("g", {
				transform: "translate(-100 -310)",
				children: [
					/* @__PURE__ */ h("g", {
						opacity: "0.65",
						children: u.provinces.map((e, t) => {
							let n = u.cities.filter((e) => e.province === t), r = n.reduce((e, t) => e + t.x, 0) / n.length, i = n.reduce((e, t) => e + t.y, 0) / n.length;
							return /* @__PURE__ */ g("text", {
								x: r,
								y: i - 63,
								textAnchor: "middle",
								className: "cc-province-name",
								children: [
									Pe[t],
									" · ",
									e.toUpperCase()
								]
							}, e);
						})
					}),
					u.roads.map((e) => /* @__PURE__ */ g("g", { children: [
						/* @__PURE__ */ h("path", {
							d: re(u, e),
							fill: "none",
							stroke: "#f9e6b8",
							strokeWidth: "9"
						}),
						/* @__PURE__ */ h("path", {
							d: re(u, e),
							fill: "none",
							stroke: e.kind === "sea" ? "#367f9e" : "#87684b",
							strokeWidth: "5",
							strokeDasharray: e.kind === "sea" ? "11 5" : void 0
						}),
						w[e.id] !== void 0 && /* @__PURE__ */ h(Fe, { path: re(u, e) }),
						/* @__PURE__ */ h(_, {
							name: `cc:location:${e.id}`,
							r: {
								x: I(u, e).x - 16,
								y: I(u, e).y - 16,
								w: 32,
								h: 32
							}
						})
					] }, e.id)),
					u.cities.map((t) => {
						let n = T.includes(t.id) || E.includes(t.id), r = b && e.phase === "build" && z(e.map, b.units).includes(t.id);
						return /* @__PURE__ */ g("g", {
							role: "button",
							tabIndex: 0,
							"aria-label": `${t.name}${e.cityGoods[t.id] ? ` · ${c(`games.concordia.${e.cityGoods[t.id]}`)}` : ""}`,
							onKeyDown: (e) => {
								(e.key === "Enter" || e.key === " ") && (e.preventDefault(), j(`c:${t.id}`));
							},
							children: [
								/* @__PURE__ */ h("title", { children: t.name }),
								/* @__PURE__ */ h("path", {
									d: `M${t.x - 30} ${t.y + 20}v-34Q${t.x} ${t.y - 54} ${t.x + 30} ${t.y - 14}v34Z`,
									fill: t.id === "roma" ? "#e6c77f" : "#f4e3bb",
									stroke: n ? "#79571f" : r ? "#b69954" : "#796b53",
									strokeWidth: "3"
								}),
								n && /* @__PURE__ */ h("path", {
									d: `M${t.x - 35} ${t.y + 25}v-39Q${t.x} ${t.y - 62} ${t.x + 35} ${t.y - 14}v39Z`,
									fill: "none",
									stroke: "#fff",
									strokeWidth: "5",
									strokeDasharray: "10 7",
									children: /* @__PURE__ */ h("animate", {
										attributeName: "stroke-dashoffset",
										from: "0",
										to: "-17",
										dur: "0.7s",
										repeatCount: "indefinite"
									})
								}),
								e.cityGoods[t.id] ? /* @__PURE__ */ h("image", {
									href: p(`games/concordia/${e.cityGoods[t.id]}.svg`),
									x: t.x - 22,
									y: t.y - 25,
									width: "44",
									height: "40"
								}) : /* @__PURE__ */ h("text", {
									x: t.x,
									y: t.y + 5,
									textAnchor: "middle",
									fontSize: "25",
									fill: "#5b4a2c",
									children: "SPQR"
								}),
								/* @__PURE__ */ h("rect", {
									x: t.x - 47,
									y: t.y + 20,
									width: "94",
									height: "21",
									rx: "3",
									fill: "#fbf0d2"
								}),
								/* @__PURE__ */ h("text", {
									x: t.x,
									y: t.y + 35,
									textAnchor: "middle",
									fontSize: t.name.length > 10 ? 12 : 15,
									fontWeight: "700",
									fill: "#493a27",
									children: t.name
								}),
								/* @__PURE__ */ h(_, {
									name: `cc:location:${t.id}`,
									r: {
										x: t.x - 24,
										y: t.y - 24,
										w: 48,
										h: 48
									}
								}),
								e.players.filter((e) => e.houses.includes(t.id)).map((e, n) => /* @__PURE__ */ h(Le, {
									name: O(e.rid),
									color: D(e.rid),
									x: t.x - 30 + n * 24,
									y: t.y - 57,
									anchor: `cc:house:${e.rid}:${t.id}`
								}, e.rid))
							]
						}, t.id);
					}),
					k.map(({ p: t, u: r, i, x: a, y: o }) => /* @__PURE__ */ h(Re, {
						kind: r.kind,
						color: D(t.rid),
						x: a,
						y: o,
						label: `${O(t.rid)} · ${c(r.kind === "land" ? "games.concordia.land" : "games.concordia.sea")}`,
						anchor: `cc:unit:${t.rid}:${i}`,
						selected: t.rid === n && S === i && e.phase === "move"
					}, `${t.rid}:${i}`))
				]
			})
		}), /* @__PURE__ */ h("button", {
			type: "button",
			className: "cc-map-reset",
			onClick: () => y((e) => e + 1),
			children: c("games.concordia.resetMap")
		})]
	});
}
//#endregion
//#region src/games/concordia/view-player.tsx
var Be = (e) => e[0].toUpperCase() + e.slice(1);
function Z({ name: e, className: t, children: n }) {
	let { ref: r, hidden: i } = o(e);
	return /* @__PURE__ */ h("div", {
		ref: r,
		className: t,
		style: { visibility: i ? "hidden" : void 0 },
		children: n
	});
}
function Ve({ p: e, name: t, color: n, selected: r, active: i, magnus: s, onPick: c, onCopy: l }) {
	let u = a(), { ref: d } = o(`cc:seat:${e.rid}`), { ref: f } = o(`cc:top:${e.rid}`), { ref: p, hidden: m } = o(`cc:top-card:${e.rid}`);
	return /* @__PURE__ */ g("div", {
		ref: d,
		className: `cc-seat ${i ? "cc-active" : ""} ${r ? "cc-picked" : ""}`,
		style: { borderTopColor: n },
		children: [/* @__PURE__ */ g("button", {
			type: "button",
			onClick: c,
			className: "cc-seat-pick",
			children: [/* @__PURE__ */ h("strong", { children: t }), /* @__PURE__ */ g("span", {
				className: "cc-seat-stats",
				children: [
					/* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h(je, {
						color: n,
						size: 19
					}), e.houses.length] }),
					/* @__PURE__ */ g("span", { children: [e.cash, " ◉"] }),
					/* @__PURE__ */ g("span", { children: [e.units.length, "/6"] }),
					s && /* @__PURE__ */ h("abbr", {
						title: u("games.concordia.magnus"),
						children: "M"
					})
				]
			})]
		}), /* @__PURE__ */ g("button", {
			type: "button",
			ref: f,
			className: `cc-top ${l ? "cc-legal" : ""}`,
			disabled: !l,
			onClick: l,
			title: u("games.concordia.discard"),
			children: [/* @__PURE__ */ h("span", {
				ref: p,
				style: { visibility: m ? "hidden" : void 0 },
				children: e.top ? u(q(P[e.top].role)) : "—"
			}), /* @__PURE__ */ g("small", { children: [
				e.handCount,
				" / ",
				e.handCount + e.discardCount
			] })]
		})]
	});
}
function He(e) {
	let t = e.public, n = e.private, r = a(), [o, s] = i(e.myRid), [p, _] = i(null), [v, y] = i({
		stamp: -1,
		goods: E()
	}), [b, x] = i("land"), S = t.actor === e.myRid && t.phase !== "done", C = t.players.find((t) => t.rid === e.myRid), w = t.players.find((e) => e.rid === o) ?? C ?? t.players[0], O = F[t.map], A = p?.stamp === t.turnNo ? p : null, j = v.stamp === t.turnNo ? v.goods : E(), M = (t) => e.members.find((e) => e.rid === t)?.name ?? t, N = (t) => {
		S && e.send(t);
	}, te = t.card !== null && P[t.card].role === "consul", ne = (e, t, n) => oe(e, t, te, n), I = (e, t) => C && T.some((n) => V(C.goods, ne(e, t, n))), re = (e) => {
		let n = t.market[e];
		S && t.phase === "buy" && n && (!te && ee[e].includes("any") ? _({
			kind: "payment",
			id: String(e),
			stamp: t.turnNo
		}) : N({
			type: "buy",
			slot: e
		}));
	}, ie = (e) => {
		let t = e.target ?? "";
		return t = e.kind === "play" || e.kind === "buy" ? r(q(P[t]?.role ?? "cards")) : e.kind === "produce" ? O.provinces[Number(t)] ?? t : e.kind === "trade" ? r(q(e.good ?? "brick")) : O.cities.find((e) => e.id === t)?.name ?? t, r(q(`log${Be(e.kind)}`), {
			name: M(e.rid),
			target: t,
			n: e.n ?? 0
		});
	}, z = r(q(`phase${Be(t.phase)}`)), ae = t.phase === "colonist" ? (C?.units.length ?? 0) + 5 : t.bonuses.reduce((e, n, r) => e + (t.activeProvinces[r] ? 0 : k[n]), 0), se = S && C && (t.phase === "colonist" || t.phase === "tribune" && t.recruited === 0) && C.goods.food > 0 && C.goods.tool > 0, H = /* @__PURE__ */ g("div", {
		className: "cc-toolbar",
		children: [
			/* @__PURE__ */ h("div", {
				className: "cc-step",
				children: t.phase === "move" ? r("games.concordia.moves", { n: t.movement }) : t.phase === "buy" ? r("games.concordia.purchases", { n: t.purchases }) : t.endBy ? r("games.concordia.finalTurns") : ""
			}),
			se && /* @__PURE__ */ g("div", {
				className: "cc-recruit",
				children: [
					["land", "sea"].map((e) => /* @__PURE__ */ h("button", {
						type: "button",
						className: b === e ? "cc-selected" : "",
						disabled: C.units.filter((t) => t.kind === e).length >= 3,
						onClick: () => x(e),
						"aria-label": r(q(e)),
						children: /* @__PURE__ */ h(Y, { kind: e })
					}, e)),
					/* @__PURE__ */ h(J, { good: "food" }),
					/* @__PURE__ */ h(J, { good: "tool" })
				]
			}),
			S && (t.phase === "prefect" || t.phase === "colonist" && t.recruited === 0) && /* @__PURE__ */ h("button", {
				type: "button",
				className: "cc-primary",
				onClick: () => N({ type: "cash" }),
				children: r("games.concordia.cash", { n: ae })
			}),
			S && [
				"move",
				"build",
				"trade",
				"buy",
				"colonist",
				"tribune",
				"copy"
			].includes(t.phase) && /* @__PURE__ */ h("button", {
				type: "button",
				className: "cc-primary",
				onClick: () => N({ type: "finish" }),
				children: r(t.phase === "move" ? "games.concordia.finishMove" : "games.concordia.finish")
			})
		]
	}), ce = /* @__PURE__ */ g(Z, {
		name: `cc:warehouse:${w.rid}`,
		className: "cc-warehouse",
		children: [
			/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ h("strong", { children: M(w.rid) }), /* @__PURE__ */ h("span", { children: r("games.concordia.storage", { n: 12 - R(w) }) })] }),
			/* @__PURE__ */ h("div", {
				className: "cc-goods",
				children: T.map((n) => /* @__PURE__ */ h(Z, {
					name: `cc:good:${w.rid}:${n}`,
					children: /* @__PURE__ */ g("button", {
						type: "button",
						className: `cc-cargo ${S && t.phase === "trade" && w.rid === e.myRid ? "cc-legal" : ""}`,
						onClick: () => S && t.phase === "trade" && w.rid === e.myRid && _({
							kind: "trade",
							id: n,
							stamp: t.turnNo
						}),
						disabled: !S || t.phase !== "trade" || w.rid !== e.myRid,
						"aria-label": `${r(q(n))}: ${w.goods[n]}`,
						children: [
							/* @__PURE__ */ h(J, { good: n }),
							/* @__PURE__ */ h("strong", { children: w.goods[n] }),
							/* @__PURE__ */ g("small", { children: [D[n], " ◉"] })
						]
					})
				}, n))
			}),
			/* @__PURE__ */ g("div", {
				className: "cc-storage-tokens",
				children: [
					Array.from({ length: 3 - w.units.filter((e) => e.kind === "land").length }, (e, t) => /* @__PURE__ */ h(Y, { kind: "land" }, `l${t}`)),
					Array.from({ length: 3 - w.units.filter((e) => e.kind === "sea").length }, (e, t) => /* @__PURE__ */ h(Y, { kind: "sea" }, `s${t}`)),
					/* @__PURE__ */ h("span", { children: r("games.concordia.supply", { n: 15 - w.houses.length }) })
				]
			})
		]
	}), U = A?.kind === "city" ? O.cities.find((e) => e.id === A.id) : null, le = U ? B(t, U.id) : null, ue = t.phase === "receive" && S && t.pending ? /* @__PURE__ */ h("div", {
		className: "cc-dialog-wrap",
		children: /* @__PURE__ */ g("section", {
			className: "cc-dialog",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": z,
			children: [
				/* @__PURE__ */ h("header", { children: /* @__PURE__ */ h("strong", { children: z }) }),
				/* @__PURE__ */ h("p", { children: r("games.concordia.keep", { n: t.pending.space }) }),
				/* @__PURE__ */ h("div", {
					className: "cc-choose-goods",
					children: T.filter((e) => t.pending.goods[e] > 0).map((e) => /* @__PURE__ */ g("div", { children: [
						/* @__PURE__ */ h(J, { good: e }),
						/* @__PURE__ */ h("span", { children: r(q(e)) }),
						/* @__PURE__ */ g("div", { children: [
							/* @__PURE__ */ h("button", {
								type: "button",
								"aria-label": `${r("games.concordia.cancel")} ${r(q(e))}`,
								disabled: j[e] === 0,
								onClick: () => y({
									stamp: t.turnNo,
									goods: {
										...j,
										[e]: j[e] - 1
									}
								}),
								children: "−"
							}),
							/* @__PURE__ */ g("strong", { children: [
								j[e],
								"/",
								t.pending.goods[e]
							] }),
							/* @__PURE__ */ h("button", {
								type: "button",
								"aria-label": `${r("games.concordia.receive")} ${r(q(e))}`,
								disabled: j[e] >= t.pending.goods[e] || L(j) >= t.pending.space,
								onClick: () => y({
									stamp: t.turnNo,
									goods: {
										...j,
										[e]: j[e] + 1
									}
								}),
								children: "+"
							})
						] })
					] }, e))
				}),
				/* @__PURE__ */ h("footer", { children: /* @__PURE__ */ h("button", {
					type: "button",
					className: "cc-primary",
					disabled: L(j) !== t.pending.space,
					onClick: () => {
						N({
							type: "receive",
							goods: j
						}), y({
							stamp: -1,
							goods: E()
						});
					},
					children: r("games.concordia.confirm")
				}) })
			]
		})
	}) : A ? /* @__PURE__ */ h("div", {
		className: "cc-dialog-wrap",
		onClick: () => _(null),
		children: /* @__PURE__ */ g("section", {
			className: "cc-dialog",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": U?.name ?? (A.kind === "card" ? r(q(P[A.id].role)) : r(A.kind === "payment" ? "games.concordia.choosePayment" : "games.concordia.phaseTrade")),
			onClick: (e) => e.stopPropagation(),
			onKeyDown: (e) => {
				e.key === "Escape" && _(null);
			},
			children: [/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ h("strong", { children: U?.name ?? (A.kind === "card" ? r(q(P[A.id].role)) : r(A.kind === "payment" ? "games.concordia.choosePayment" : "games.concordia.phaseTrade")) }), /* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => _(null),
				"aria-label": r("games.concordia.close"),
				children: "×"
			})] }), A.kind === "card" ? /* @__PURE__ */ g("div", {
				className: "cc-card-preview",
				children: [
					/* @__PURE__ */ h(X, { id: A.id }),
					/* @__PURE__ */ h("p", { children: r(q([
						"mason",
						"farmer",
						"smith",
						"vintner",
						"weaver"
					].includes(P[A.id].role) ? "cardSpecialist" : `card${Be(P[A.id].role)}`)) }),
					/* @__PURE__ */ h("button", {
						type: "button",
						className: "cc-primary",
						disabled: !S || t.phase !== "play" || !n?.hand.includes(A.id),
						onClick: () => {
							N({
								type: "play",
								card: A.id
							}), _(null);
						},
						children: r("games.concordia.confirm")
					})
				]
			}) : U ? /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ g("div", {
					className: "cc-city-detail",
					children: [t.cityGoods[U.id] && /* @__PURE__ */ h(J, { good: t.cityGoods[U.id] }), /* @__PURE__ */ h("span", { children: U.province >= 0 ? O.provinces[U.province] : "Roma" })]
				}),
				le && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("p", { children: r("games.concordia.buildCost") }), /* @__PURE__ */ g("div", {
					className: "cc-cost",
					children: [T.flatMap((e) => Array.from({ length: le.goods[e] }, (t, n) => /* @__PURE__ */ h(J, { good: e }, `${e}${n}`))), /* @__PURE__ */ g("strong", { children: [le.cash, " ◉"] })]
				})] }),
				/* @__PURE__ */ h("ul", { children: t.players.filter((e) => e.houses.includes(U.id)).map((e) => /* @__PURE__ */ h("li", { children: M(e.rid) }, e.rid)) })
			] }) : A.kind === "payment" ? /* @__PURE__ */ h("div", {
				className: "cc-payment",
				children: T.map((e) => {
					let n = Number(A.id), i = t.market[n], a = i ? ne(i, n, e) : null;
					return /* @__PURE__ */ g("button", {
						type: "button",
						disabled: !S || !C || !a || !V(C.goods, a),
						onClick: () => {
							N({
								type: "buy",
								slot: n,
								payment: e
							}), _(null);
						},
						"aria-label": r(q(e)),
						children: [/* @__PURE__ */ h(J, { good: e }), /* @__PURE__ */ h("span", { children: r(q(e)) })]
					}, e);
				})
			}) : /* @__PURE__ */ g("div", {
				className: "cc-trade-detail",
				children: [
					/* @__PURE__ */ h(J, { good: A.id }),
					/* @__PURE__ */ g("strong", { children: [
						r(q(A.id)),
						" · ",
						D[A.id],
						" ◉"
					] }),
					/* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("button", {
						type: "button",
						disabled: !S || !C || C.goods[A.id] === 0 || !t.traded.includes(A.id) && t.traded.length >= 2,
						onClick: () => N({
							type: "trade",
							good: A.id,
							amount: -1
						}),
						children: r("games.concordia.tradeSell")
					}), /* @__PURE__ */ h("button", {
						type: "button",
						disabled: !S || !C || C.cash < D[A.id] || R(C) < 1 || !t.traded.includes(A.id) && t.traded.length >= 2,
						onClick: () => N({
							type: "trade",
							good: A.id,
							amount: 1
						}),
						children: r("games.concordia.tradeBuy")
					})] })
				]
			})]
		})
	}) : null;
	return /* @__PURE__ */ g(u, {
		adaptive: !0,
		scroll: !1,
		className: "concordia",
		actionsHeight: "cc-bottom-height",
		banner: /* @__PURE__ */ g("div", {
			className: "cc-banner",
			children: [/* @__PURE__ */ h(d, {
				tone: S ? "accent" : t.phase === "done" ? "done" : "info",
				accent: "#376c79",
				text: S || t.phase === "done" ? z : r("games.concordia.waiting", { name: M(t.actor) }),
				chip: t.endBy ? r("games.concordia.finalTurns") : r("games.concordia.turn", { n: t.turnNo })
			}), /* @__PURE__ */ h("div", {
				className: "cc-seats",
				children: t.players.map((n) => /* @__PURE__ */ h(Ve, {
					p: n,
					name: M(n.rid),
					color: l[(e.members.find((e) => e.rid === n.rid)?.colorIndex ?? 0) % l.length].hex,
					selected: n.rid === w.rid,
					active: t.actor === n.rid && t.phase !== "done",
					magnus: t.magnus === n.rid,
					onPick: () => s(n.rid),
					onCopy: S && t.phase === "copy" && n.rid !== e.myRid && n.top && !["tribune", "diplomat"].includes(P[n.top].role) ? () => N({
						type: "copy",
						rid: n.rid
					}) : void 0
				}, n.rid))
			})]
		}),
		actions: /* @__PURE__ */ g("div", {
			className: "cc-bottom",
			children: [H, /* @__PURE__ */ h(Z, {
				name: "cc:hand-area",
				className: "cc-hand",
				children: n?.hand.map((e) => /* @__PURE__ */ h(X, {
					id: e,
					anchor: `cc:hand:${e}`,
					onClick: () => _({
						kind: "card",
						id: e,
						stamp: t.turnNo
					}),
					disabled: !S || t.phase !== "play"
				}, e))
			})]
		}),
		children: [/* @__PURE__ */ g("div", {
			className: "cc-table",
			children: [
				/* @__PURE__ */ h(c, {
					kind: "sheen",
					base: "#d5c39b",
					className: "absolute inset-0"
				}),
				/* @__PURE__ */ g("div", {
					className: "cc-table-main",
					children: [
						/* @__PURE__ */ g("div", {
							className: "cc-market",
							"aria-label": r("games.concordia.market"),
							children: [t.market.map((e, n) => /* @__PURE__ */ g(Z, {
								name: `cc:market:${n}`,
								className: "cc-market-slot",
								children: [e ? /* @__PURE__ */ h(X, {
									id: e,
									small: !0,
									onClick: () => re(n),
									disabled: !S || t.phase !== "buy" || !I(e, n),
									selected: S && t.phase === "buy" && !!I(e, n)
								}) : /* @__PURE__ */ h("div", { className: "cc-market-empty" }), /* @__PURE__ */ h("span", {
									className: "cc-surcharge",
									children: ee[n].length ? ee[n].map((e, t) => e === "any" ? /* @__PURE__ */ h("span", {
										title: r("games.concordia.any"),
										children: "?"
									}, t) : /* @__PURE__ */ h(J, { good: e }, t)) : /* @__PURE__ */ h("span", { children: "—" })
								})]
							}, n)), /* @__PURE__ */ g(Z, {
								name: "cc:bank",
								className: "cc-deck",
								children: [/* @__PURE__ */ h("strong", { children: t.deckCount }), /* @__PURE__ */ h("span", { children: "CONCORDIA" })]
							})]
						}),
						/* @__PURE__ */ h("div", {
							className: "cc-provinces",
							children: O.provinces.map((e, n) => /* @__PURE__ */ h(Z, {
								name: `cc:province:${n}`,
								children: /* @__PURE__ */ g("button", {
									type: "button",
									className: `cc-province ${t.activeProvinces[n] ? "" : "cc-spent"} ${S && t.phase === "prefect" && t.activeProvinces[n] ? "cc-legal" : ""}`,
									disabled: !S || t.phase !== "prefect" || !t.activeProvinces[n],
									onClick: () => N({
										type: "produce",
										province: n
									}),
									"aria-label": `${e} · ${r(t.activeProvinces[n] ? "games.concordia.available" : "games.concordia.used")}`,
									children: [/* @__PURE__ */ h("small", { children: e }), t.activeProvinces[n] ? /* @__PURE__ */ h(J, { good: t.bonuses[n] }) : /* @__PURE__ */ g("strong", { children: [k[t.bonuses[n]], " ◉"] })]
								})
							}, e))
						}),
						/* @__PURE__ */ h(ze, {
							v: t,
							members: e.members,
							myRid: e.myRid,
							send: N,
							recruitKind: b,
							onInspect: (e) => _({
								kind: "city",
								id: e,
								stamp: t.turnNo
							})
						}),
						/* @__PURE__ */ h("div", {
							className: "cc-log",
							children: /* @__PURE__ */ h(f, {
								log: t.log,
								line: ie
							})
						})
					]
				}),
				/* @__PURE__ */ g("aside", {
					className: "cc-side",
					children: [ce, /* @__PURE__ */ h("div", {
						className: "cc-discard-list",
						children: t.players.map((n) => /* @__PURE__ */ g(Z, {
							name: `cc:discard:${n.rid}`,
							className: "cc-discard-stack",
							children: [/* @__PURE__ */ g("span", { children: [
								M(n.rid),
								" · ",
								n.discardCount
							] }), n.top ? /* @__PURE__ */ h(X, {
								id: n.top,
								small: !0,
								anchor: `cc:discard-card:${n.rid}`,
								onClick: () => N({
									type: "copy",
									rid: n.rid
								}),
								disabled: !S || t.phase !== "copy" || n.rid === e.myRid || ["tribune", "diplomat"].includes(P[n.top].role)
							}) : /* @__PURE__ */ h("div", { className: "cc-market-empty" })]
						}, n.rid))
					})]
				})
			]
		}), ue]
	});
}
//#endregion
//#region src/games/concordia/bot.ts
var Ue = {
	expansion: 1,
	diversity: 0,
	cards: .6,
	opponent: 0,
	recruit: 0
}, We = {
	expansion: 1,
	diversity: 2,
	cards: 1,
	opponent: .2,
	recruit: 1.2
};
function Ge(e) {
	return (t, n) => {
		let r = t.public, i = r.players.find((e) => e.rid === n.rid), a = t.private?.hand ?? [], o = F[r.map];
		if (!i || r.actor !== n.rid || r.phase === "done") return null;
		let s = (e) => ({ action: e }), c = () => s({ type: "finish" }), l = (e) => D[e] * (i.goods[e] === 0 ? 1.45 : i.goods[e] > 2 ? .5 : 1), u = (t) => {
			let n = r.cityGoods[t], a = o.cities.find((e) => e.id === t).province, s = !i.houses.some((e) => o.cities.find((t) => t.id === e).province === a), c = !i.houses.some((e) => r.cityGoods[e] === n);
			return 8 * e.expansion + (s ? 2 : 0) * e.diversity + (c ? 2 : 0) * e.diversity + D[n] * .4 + (n === "brick" || n === "food" ? 2 : 0);
		}, d = (e) => r.market.flatMap((t, n) => t ? T.flatMap((r) => {
			let a = oe(t, n, e, r);
			return V(i.goods, a) ? [{
				id: t,
				slot: n,
				payment: r,
				cost: a
			}] : [];
		}) : []), f = (t) => {
			let n = P[t], a = i.houses.length;
			return 4 + (n.god === "jupiter" ? a * .8 : n.god === "saturnus" ? new Set(i.houses.map((e) => o.cities.find((t) => t.id === e).province)).size : n.god === "mercurius" ? new Set(i.houses.map((e) => r.cityGoods[e])).size * 2 : n.god === "mars" ? i.units.length * 2 : n.god === "minerva" ? i.houses.filter((e) => r.cityGoods[e] === n.specialty).length * n.points : Math.floor(i.cash / 10)) * e.cards + (n.role === "colonist" && i.units.length < 5 ? 4 : 0) + (n.role === "architect" ? 2 : 0) + (n.role === "consul" ? 3 : 0);
		}, p = (t) => {
			let n = r.bonuses[t], a = R(i), s = l(n) * (r.magnus === i.rid ? 2 : 1), c = i.houses.filter((e) => o.cities.find((t) => t.id === e).province === t).map((e) => l(r.cityGoods[e])).reduce((e, t) => e + t, 0), u = r.players.filter((e) => e.rid !== i.rid).reduce((e, n) => e + n.houses.filter((e) => o.cities.find((t) => t.id === e).province === t).length, 0);
			return Math.min(s + c, a * 6) - u * e.opponent;
		}, m = r.activeProvinces.flatMap((e, t) => e ? [t] : []).sort((e, t) => p(t) - p(e)), h = r.bonuses.reduce((e, t, n) => e + (r.activeProvinces[n] ? 0 : k[t]), 0), g = i.goods.food > 0 && i.goods.tool > 0 && i.units.length < 6, _ = ae(r, i.rid), v = i.units.flatMap((e, t) => Object.entries(ie(r, i.rid, t, r.phase === "move" ? r.movement : i.units.length)).map(([n, a]) => {
			let s = o.roads.find((e) => e.id === n), c = [s.a, s.b].filter((e) => e !== "roma" && !i.houses.includes(e)), l = c.filter((e) => {
				let t = B(r, e);
				return V(i.goods, t.goods) && i.cash >= t.cash;
			}), d = z(r.map, [e]);
			return {
				unit: t,
				road: n,
				distance: a,
				value: l.reduce((e, t) => e + u(t), 0) + c.filter((e) => !d.includes(e)).length * .4 - a * .12
			};
		})).sort((e, t) => t.value - e.value), y = (t, n) => {
			if (t === "architect") return Math.max(_.length ? 10 + _.length * 5 : 0, (v[0]?.value ?? 0) * .9);
			if (t === "prefect") return Math.max(m.length ? p(m[0]) * .8 : 0, h * (i.cash < 8 ? 1.3 : .65));
			if (t === "mercator") return (i.cash < 6 ? 11 : 7) + (i.goods.brick === 0 ? 3 : 0) + (i.goods.food === 0 ? 2 : 0);
			if (t === "senator" || t === "consul") return Math.max(0, ...d(t === "consul").map((e) => f(e.id) + 4));
			if (t === "colonist") return g && i.units.length < 5 ? 12 + e.recruit * 2 : i.cash < 10 ? 12 : 5;
			if (t === "tribune") return Math.max(0, (7 + i.bought.length - a.length) * 1.8 - 4) + (a.length < 3 ? 8 : 0);
			if (t === "diplomat") return Math.max(0, ...r.players.filter((e) => e.rid !== i.rid && e.top && !["tribune", "diplomat"].includes(P[e.top].role)).map((e) => y(P[e.top].role, e.top))) - .2;
			let o = P[n].specialty;
			return Math.min(R(i), i.houses.filter((e) => r.cityGoods[e] === o).length) * l(o) * .85;
		};
		if (r.phase === "play") return s({
			type: "play",
			card: [...a].sort((e, t) => y(P[t].role, t) - y(P[e].role, e) || e.localeCompare(t))[0]
		});
		if (r.phase === "copy") {
			let e = r.players.filter((e) => e.rid !== i.rid && e.top && !["tribune", "diplomat"].includes(P[e.top].role)).sort((e, t) => y(P[t.top].role, t.top) - y(P[e.top].role, e.top));
			return e.length ? s({
				type: "copy",
				rid: e[0].rid
			}) : c();
		}
		if (r.phase === "move") {
			if (_.length) return c();
			let e = v[0];
			return e && e.value > 4 ? s({
				type: "move",
				unit: e.unit,
				road: e.road
			}) : c();
		}
		if (r.phase === "build") return _.length ? s({
			type: "build",
			city: _.sort((e, t) => u(t) - u(e))[0]
		}) : c();
		if (r.phase === "prefect") return m.length && p(m[0]) * .8 > h * (i.cash < 8 ? 1.3 : .65) ? s({
			type: "produce",
			province: m[0]
		}) : s({ type: "cash" });
		if (r.phase === "buy") {
			let e = d(r.card !== null && P[r.card].role === "consul").sort((e, t) => f(t.id) - L(t.cost) * 1.2 - (f(e.id) - L(e.cost) * 1.2));
			return e.length ? s({
				type: "buy",
				slot: e[0].slot,
				payment: e[0].payment
			}) : c();
		}
		if (r.phase === "colonist" || r.phase === "tribune") {
			if (g && (r.phase === "colonist" || r.recruited === 0) && (i.units.length < 4 || e.recruit > 0 && i.units.length < 6)) {
				let e = i.units.filter((e) => e.kind === "land").length <= i.units.filter((e) => e.kind === "sea").length ? "land" : "sea", t = (r.phase === "tribune" ? ["roma"] : ["roma", ...i.houses]).sort((t, n) => {
					let r = (t) => o.roads.filter((n) => n.kind === e && (n.a === t || n.b === t)).reduce((e, t) => e + Number(!i.houses.includes(t.a)) + Number(!i.houses.includes(t.b)), 0);
					return r(n) - r(t);
				})[0];
				return s({
					type: "recruit",
					kind: e,
					city: t
				});
			}
			return r.phase === "colonist" && r.recruited === 0 ? s({ type: "cash" }) : c();
		}
		let b = [];
		for (let e of o.cities.filter((e) => e.id !== "roma" && !i.houses.includes(e.id))) {
			let t = B(r, e.id), n = i.units.some((t) => z(r.map, [t]).includes(e.id)) ? 0 : 2;
			b.push({
				goods: t.goods,
				rank: u(e.id) - T.reduce((e, n) => e + Math.max(0, t.goods[n] - i.goods[n]) * D[n], 0) - Math.max(0, t.cash - i.cash) * .5 - n
			});
		}
		for (let [e, t] of r.market.entries()) if (t) {
			let n = oe(t, e, !1, "brick");
			b.push({
				goods: n,
				rank: f(t) + 3 - T.reduce((e, t) => e + Math.max(0, n[t] - i.goods[t]) * D[t], 0)
			});
		}
		b.sort((e, t) => t.rank - e.rank);
		let x = { ...b[0]?.goods ?? E() };
		if (x.brick = Math.max(x.brick, i.houses.length < 10 ? 2 : 1), x.food = Math.max(x.food, 2), i.units.length < 4 && (x.tool = Math.max(x.tool, 1)), r.phase === "receive") {
			let e = E(), t = { ...r.pending.goods };
			for (let n = 0; n < r.pending.space; n++) {
				let n = T.filter((e) => t[e] > 0).sort((t, n) => l(n) + (i.goods[n] + e[n] < x[n] ? 8 : 0) - (l(t) + (i.goods[t] + e[t] < x[t] ? 8 : 0)))[0];
				n && (e[n]++, t[n]--);
			}
			return s({
				type: "receive",
				goods: e
			});
		}
		if (r.phase === "trade") {
			let e = T.filter((e) => r.traded.includes(e) || r.traded.length < 2), t = e.filter((e) => i.goods[e] < x[e]).sort((e, t) => (x[t] - i.goods[t]) * l(t) - (x[e] - i.goods[e]) * l(e)), n = e.filter((e) => i.goods[e] > x[e]).sort((e, t) => (i.goods[t] - x[t]) * D[t] - (i.goods[e] - x[e]) * D[e])[0];
			if (n && (i.cash < 8 || R(i) === 0) && (!t.length || i.cash < D[t[0]] || R(i) === 0)) return s({
				type: "trade",
				good: n,
				amount: -(i.goods[n] - x[n])
			});
			let a = t.find((e) => i.cash >= D[e] && R(i) > 0);
			return a ? s({
				type: "trade",
				good: a,
				amount: Math.min(x[a] - i.goods[a], Math.floor(i.cash / D[a]), R(i))
			}) : n && i.cash < 4 ? s({
				type: "trade",
				good: n,
				amount: -1
			}) : c();
		}
		return c();
	};
}
var Ke = Ge(We), qe = Ge(Ue), Je = (e, t) => (t.difficulty === "weak" ? qe : Ke)(e, t), Ye = (e, t, n) => {
	let r = F[t.public.map];
	if (e.type === "play") return n("games.concordia.logPlay", {
		name: "",
		target: n(`games.concordia.${P[e.card].role}`),
		n: 0
	}).trim();
	if (e.type === "build" || e.type === "recruit") return n(e.type === "build" ? "games.concordia.logBuild" : "games.concordia.logRecruit", {
		name: "",
		target: r.cities.find((t) => t.id === e.city)?.name ?? e.city,
		n: e.type === "build" ? B(t.public, e.city)?.cash ?? 0 : 0
	}).trim();
	if (e.type === "produce") return n("games.concordia.logProduce", {
		name: "",
		target: r.provinces[e.province],
		n: 0
	}).trim();
	if (e.type === "buy") {
		let r = t.public.market[e.slot];
		return n("games.concordia.logBuy", {
			name: "",
			target: r ? n(`games.concordia.${P[r].role}`) : "",
			n: e.slot
		}).trim();
	}
	if (e.type === "move") {
		let t = r.roads.find((t) => t.id === e.road);
		return n("games.concordia.hintMove", {
			from: r.cities.find((e) => e.id === t.a).name,
			to: r.cities.find((e) => e.id === t.b).name
		});
	}
	return e.type === "trade" ? n("games.concordia.hintTrade", {
		action: n(e.amount > 0 ? "games.concordia.tradeBuy" : "games.concordia.tradeSell"),
		n: Math.abs(e.amount),
		good: n(`games.concordia.${e.good}`)
	}) : e.type === "copy" ? n("games.concordia.diplomat") : n(e.type === "cash" ? "games.concordia.hintCash" : e.type === "receive" ? "games.concordia.confirm" : "games.concordia.finish");
}, Q = (e) => e.queued ? 110 : 380, $ = (e, ...t) => t.map((t) => e.anchor(t)).find((e) => e && e.w > 0 && e.h > 0) ?? null, Xe = (e, t) => $(e, `cc:discard-card:${t}`, `cc:top:${t}`), Ze = (e, t) => e.queued ? [] : [`cc:discard-card:${t}`, `cc:top-card:${t}`].filter((t) => $(e, t)), Qe = {
	concordiaPlay(e, t) {
		let n = e.data.card, r = $(t, e.rid === t.myRid ? "cc:hand-area" : `cc:top:${e.rid}`), i = Xe(t, e.rid);
		return r && i ? {
			ms: Q(t),
			hide: Ze(t, e.rid),
			node: /* @__PURE__ */ h(b, {
				from: {
					...r,
					w: 80,
					h: 120
				},
				to: i,
				ms: Q(t),
				children: /* @__PURE__ */ h(X, {
					id: n,
					small: !0
				})
			})
		} : null;
	},
	concordiaMove(e, t) {
		let n = e.data, r = $(t, `cc:location:${n.from}`), i = $(t, `cc:unit:${e.rid}:${n.unit}`), a = t.member(e.rid), o = l[(a?.colorIndex ?? 0) % l.length].hex;
		return !r || !i ? null : {
			ms: Q(t),
			hide: t.queued ? [] : [`cc:unit:${e.rid}:${n.unit}`],
			node: /* @__PURE__ */ h(b, {
				from: r,
				to: i,
				ms: Q(t),
				children: /* @__PURE__ */ h(Y, {
					kind: n.to.startsWith("s") ? "sea" : "land",
					color: o,
					size: i.w
				})
			})
		};
	},
	concordiaBuild(e, t) {
		let n = e.data.city, r = $(t, `cc:warehouse:${e.rid}`) ?? $(t, `cc:seat:${e.rid}`), i = $(t, `cc:house:${e.rid}:${n}`), a = l[(t.member(e.rid)?.colorIndex ?? 0) % l.length].hex;
		return r && i ? {
			ms: Q(t),
			hide: t.queued ? [] : [`cc:house:${e.rid}:${n}`],
			node: /* @__PURE__ */ h(b, {
				from: {
					...r,
					w: 26,
					h: 26
				},
				to: i,
				ms: Q(t),
				children: /* @__PURE__ */ h(je, { color: a })
			})
		} : null;
	},
	concordiaBuy(e, t) {
		let n = e.data, r = $(t, `cc:market:${n.slot}`), i = $(t, e.rid === t.myRid ? `cc:hand:${n.card}` : `cc:top:${e.rid}`);
		return r && i ? {
			ms: Q(t),
			hide: e.rid === t.myRid && !t.queued ? [`cc:hand:${n.card}`] : [],
			node: /* @__PURE__ */ h(b, {
				from: r,
				to: i,
				ms: Q(t),
				children: e.rid === t.myRid ? /* @__PURE__ */ h(X, {
					id: n.card,
					small: !0
				}) : /* @__PURE__ */ h(Ne, {})
			})
		} : null;
	},
	concordiaRecover(e, t) {
		let n = Xe(t, e.rid), r = $(t, e.rid === t.myRid ? "cc:hand-area" : `cc:top:${e.rid}`);
		return n && r ? {
			ms: Q(t),
			node: /* @__PURE__ */ h(b, {
				from: n,
				to: {
					...r,
					w: 90,
					h: 120
				},
				ms: Q(t),
				children: /* @__PURE__ */ h(Ne, {})
			})
		} : null;
	},
	concordiaRecruit(e, t) {
		let n = e.data, r = $(t, `cc:warehouse:${e.rid}`) ?? $(t, `cc:seat:${e.rid}`), i = $(t, `cc:unit:${e.rid}:${n.unit}`), a = l[(t.member(e.rid)?.colorIndex ?? 0) % l.length].hex;
		return r && i ? {
			ms: Q(t),
			hide: t.queued ? [] : [`cc:unit:${e.rid}:${n.unit}`],
			node: /* @__PURE__ */ h(b, {
				from: {
					...r,
					w: 32,
					h: 32
				},
				to: i,
				ms: Q(t),
				children: /* @__PURE__ */ h(Y, {
					kind: n.kind,
					color: a,
					size: i.w
				})
			})
		} : null;
	},
	concordiaGain(e, t) {
		let n = e.data, r = $(t, n.source ?? "cc:bank", `cc:seat:${e.rid}`), i = $(t, `cc:seat:${e.rid}`);
		return !r || !i ? null : {
			ms: Q(t),
			node: /* @__PURE__ */ h(m, { children: T.filter((e) => n.goods[e] > 0).map((n) => {
				let a = $(t, `cc:good:${e.rid}:${n}`) ?? i;
				return /* @__PURE__ */ h(b, {
					from: {
						...r,
						w: 28,
						h: 28
					},
					to: {
						...a,
						w: 28,
						h: 28
					},
					ms: Q(t),
					children: /* @__PURE__ */ h(J, {
						good: n,
						style: {
							width: 28,
							height: 28
						}
					})
				}, n);
			}) })
		};
	},
	concordiaCash(e, t) {
		let n = $(t, `cc:seat:${e.rid}`);
		return n ? {
			ms: t.queued ? 110 : 460,
			node: /* @__PURE__ */ h(y, {
				at: n,
				ms: t.queued ? 110 : 460,
				children: /* @__PURE__ */ g("span", {
					className: "cc-float",
					children: [
						"+",
						e.data.n,
						" ◉"
					]
				})
			})
		} : null;
	},
	concordiaTrade(e, t) {
		let n = e.data, r = $(t, "cc:bank"), i = $(t, `cc:good:${e.rid}:${n.good}`) ?? $(t, `cc:seat:${e.rid}`);
		return r && i ? {
			ms: Q(t),
			node: /* @__PURE__ */ h(b, {
				from: {
					...n.n > 0 ? r : i,
					w: 28,
					h: 28
				},
				to: {
					...n.n > 0 ? i : r,
					w: 28,
					h: 28
				},
				ms: Q(t),
				children: /* @__PURE__ */ h(J, {
					good: n.good,
					style: {
						width: 28,
						height: 28
					}
				})
			})
		} : null;
	},
	concordiaProvince(e, t) {
		let n = $(t, `cc:province:${e.data.province}`);
		return n ? {
			ms: Q(t),
			node: /* @__PURE__ */ h(x, {
				at: n,
				ms: Q(t)
			})
		} : null;
	}
};
//#endregion
//#region src/games/concordia/game-over.tsx
function $e(e) {
	let t = e.public, n = a(), [o, s] = i(!0), [c, l] = i(null), u = r(null), d = r(null), f = (t) => e.members.find((e) => e.rid === t)?.name ?? t, p = (e) => {
		s(e), l(null), requestAnimationFrame(() => {
			(e ? u : d).current?.focus();
		});
	}, _ = () => {
		c === "again" ? e.onPlayAgain?.() : e.onBackToLobby?.(), l(null);
	};
	return /* @__PURE__ */ g("div", {
		className: "concordia cc-result-wrap",
		children: [
			/* @__PURE__ */ h("div", {
				className: "cc-result-board",
				inert: o,
				children: /* @__PURE__ */ h(He, {
					...e,
					send: () => {}
				})
			}),
			/* @__PURE__ */ h("div", {
				className: "cc-result-overlay",
				hidden: !o,
				children: /* @__PURE__ */ g("section", {
					className: "cc-result",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": n("games.concordia.results"),
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), p(!1));
					},
					children: [
						/* @__PURE__ */ g("header", { children: [
							/* @__PURE__ */ h(Ae, {}),
							/* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("h1", { children: n("games.concordia.results") }), /* @__PURE__ */ h("p", { children: n("games.concordia.winner", { name: f(e.result.winner[0]) }) })] }),
							/* @__PURE__ */ h("button", {
								type: "button",
								ref: u,
								onClick: () => p(!1),
								"aria-label": n("games.concordia.hideResult"),
								children: "↙"
							})
						] }),
						/* @__PURE__ */ g("div", {
							className: "cc-result-body",
							inert: c !== null,
							children: [/* @__PURE__ */ h("div", {
								className: "cc-score-scroll",
								children: /* @__PURE__ */ g("table", {
									"aria-label": n("games.concordia.score"),
									children: [
										/* @__PURE__ */ h("thead", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", { children: "CONCORDIA" }), e.result.ranking.map((e) => /* @__PURE__ */ h("th", {
											scope: "col",
											children: f(e)
										}, e))] }) }),
										/* @__PURE__ */ h("tbody", { children: [...A, "concordia"].map((r) => /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
											scope: "row",
											children: n(q(r))
										}), e.result.ranking.map((e) => /* @__PURE__ */ g("td", { children: [t.scores?.[e][r] ?? 0, r !== "concordia" && r !== "minerva" && /* @__PURE__ */ h("small", { children: n("games.concordia.factor", { n: t.scores?.[e].factors[r] ?? 0 }) })] }, e))] }, r)) }),
										/* @__PURE__ */ h("tfoot", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
											scope: "row",
											children: n("games.concordia.score")
										}), e.result.ranking.map((e) => /* @__PURE__ */ h("td", { children: t.scores?.[e].total ?? 0 }, e))] }) })
									]
								})
							}), /* @__PURE__ */ g("div", {
								className: "cc-result-meta",
								children: [e.hintCount !== void 0 && /* @__PURE__ */ h("span", { children: n("session.hint.usedCount", { n: e.hintCount }) }), e.result.ranking.filter((t) => e.result.autopilot?.[t]).map((t) => /* @__PURE__ */ g("span", { children: [
									f(t),
									" · ",
									n("games.concordia.autopilot", { n: Math.round(e.result.autopilot[t] * 100) })
								] }, t))]
							})]
						}),
						/* @__PURE__ */ h("footer", { children: c ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
							type: "button",
							className: "danger-stripes",
							autoFocus: !0,
							onClick: _,
							children: n(c === "again" ? "games.concordia.confirmAgain" : "games.concordia.confirmLobby")
						}), /* @__PURE__ */ h("button", {
							type: "button",
							onClick: () => l(null),
							children: n("games.concordia.cancel")
						})] }) : /* @__PURE__ */ g(m, { children: [
							e.onBackToLobby && /* @__PURE__ */ h("button", {
								type: "button",
								onClick: () => l("lobby"),
								children: n("session.result.backToLobby")
							}),
							e.onPlayAgain && /* @__PURE__ */ h("button", {
								type: "button",
								className: "cc-primary",
								onClick: () => l("again"),
								children: n("session.result.playAgain")
							}),
							!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ h("span", { children: n("session.result.waitHost") })
						] }) })
					]
				})
			}),
			/* @__PURE__ */ h("button", {
				type: "button",
				ref: d,
				hidden: o,
				className: "cc-result-restore",
				onClick: () => p(!0),
				children: n("games.concordia.showResult")
			})
		]
	});
}
//#endregion
//#region src/games/concordia/options.tsx
function et({ value: e, onChange: t }) {
	let n = a(), r = U.safeParse(e), i = r.success ? r.data : U.parse(void 0);
	return /* @__PURE__ */ g(m, { children: [
		/* @__PURE__ */ h(C, {
			title: n("games.concordia.map"),
			columns: 3,
			children: [
				"auto",
				"italia",
				"imperium"
			].map((e) => /* @__PURE__ */ h(S, {
				name: "concordia-map",
				value: e,
				label: n(q(e)),
				checked: i.map === e,
				accent: "#376c79",
				onChange: () => t({
					...i,
					map: e
				})
			}, e))
		}),
		/* @__PURE__ */ h("p", {
			className: "text-xs",
			children: n("games.concordia.mapHelp")
		}),
		/* @__PURE__ */ h(w, {
			label: n("games.concordia.intermediate"),
			checked: i.intermediate,
			onChange: () => t({
				...i,
				intermediate: !i.intermediate
			})
		})
	] });
}
//#endregion
//#region .bgparty/cache/pack-entry/concordia/entry.tsx
var tt = {
	definition: ke,
	View: He,
	bot: Je,
	describe: Ye,
	fx: Qe,
	OverView: $e,
	Options: et,
	locales: {
		zh: {
			name: "康考迪亚",
			desc: "在罗马帝国拓展贸易网络，借助人物牌发展城市，让诸神见证你的繁荣。",
			rules: "目标：\n在罗马帝国建立房屋、发展殖民者与贸易，并收集人物牌。终局时每张人物牌按其神祇为你计分，最高分者获胜。\n准备：\n游戏支持2至5人。Italia地图适合2至4人，Imperium地图适合3至5人。自动地图在2至3人时使用Italia，4至5人时使用Imperium；与人数不符的手动选择会采用该人数的官方地图。按城市背面字母分别随机分配货物；每省最贵货物成为省奖励。每人拥有7张起手牌、15座房屋和陆海各3名殖民者，其中陆海各1名从Roma出发，其余4名留在12格仓库。仓库起始有2粮食及砖块、工具、葡萄酒、布料各1。随机先手获得5钱，后续座次依次多1钱；末席持有大执政官。市场按I至人数的牌堆分别洗牌、依次叠放，展示7张。\n流程：\n轮到你时打出1张人物牌并执行其行动。自己已打出的牌堆只向对手展示顶牌；购买的牌立即进入手牌。\n· 建筑师：移动点等于你在版图上的殖民者总数，可分配给任意己方殖民者，也可少用。陆地殖民者走陆路，海上殖民者走海路；从城市出发到相邻路线用1点，从路线经过城市到另一条同类路线再用1点。可以穿过已占用的路线并计算每步，不能停在被占用的路线上。全部移动结束后，可在己方殖民者所在路线两端的城市建任意数量的房屋。每人每城最多1座，Roma不能建房。砖城支付1粮食；其余城市支付1砖块和1份该城货物。钱币基础费用按砖、粮、工具、酒、布依次为1、2、3、4、5，乘以建成后该城总房屋数。\n· 执政官：选择尚未生产的省份，领取其奖励货物1份，并让该省所有玩家的每座房屋各生产1份城市货物，然后将奖励翻为钱币面；也可领取所有已翻面奖励的金币总数并将其全部复原。布料奖励的背面为1钱，其余为2钱。持有大执政官者选择生产时必须领取双份省奖励，随后把大执政官交给右手玩家；房屋产量不翻倍，收钱不传递大执政官。\n· 商人：起手商人先获得3钱，购买的商人先获得5钱，然后最多交易两种货物，可买入或卖出任意数量，受资金和仓库容量限制。砖、粮、工具、酒、布的固定单价为3、4、5、6、7。\n· 元老：最多购买2张市场牌，支付牌面费用及原槽位附费。7个槽位附费依次为无、任意货物、任意货物、布料、布料、任意货物与布料、2布料。全部购买结束后才左移并补牌。领事只买1张，忽略槽位附费。\n· 外交官：复制其他玩家弃牌顶牌的行动，不能复制外交官或护民官。自己弃牌顶仍是外交官。\n· 殖民官：每支付1粮食和1工具，就从仓库部署1名陆地或海上殖民者至Roma或自己已有房屋的城市；也可领取5钱及每名已在版图的己方殖民者各1钱。\n· 护民官：收回全部弃牌（含本牌），每超过3张获得1钱；此外可支付1粮食和1工具，从仓库部署1名殖民者至Roma。\n· 石匠、农夫、铁匠、酿酒师、织工：分别让自己所有对应砖、粮、工具、酒、布城市的房屋各生产1份货物。\n仓库：\n每份货物及每名尚未部署的殖民者占1格，共12格。不能主动丢弃货物；生产超过剩余空间时，自己选择接收哪些新货物，必须填满剩余格。钱币和货物供应不限，每人殖民者上限6名。玩家之间不能交易。\n结束与计分：\n首位建出第15座房屋，或买光市场与牌堆最后1张牌的玩家，获得Concordia奖励7分；其他玩家各执行最后1回合，然后同时计分。计算手牌与弃牌中的全部人物牌，每张按其神祇获得下列分数：\n· 维斯塔：现金与仓库货物市价合计，每满10钱获得1分。\n· 朱庇特：每座非砖城房屋获得1分。\n· 萨图恩：每个拥有己方房屋的省份获得1分。\n· 墨丘利：每种己方房屋能生产的货物获得2分。\n· 玛尔斯：每名已在版图的己方殖民者获得2分。\n· 密涅瓦：按对应专精城市计分，砖、粮、工具每座3分，葡萄酒每座4分，布料每座5分。\n分数最高者获胜。同分时，持有大执政官者优先；若其不在同分者中，沿大执政官向右传递的方向最先取得它的同分玩家优先。\n中间计分（可选，默认关闭）：\n每人第一次打出护民官收牌后立即记录当时分数。所有人都完成后，最高分者获得2钱，第二名获得1钱；并列同一名次者获得相同奖励。这些分数不会保留到终局。",
			hintMove: "将殖民者移动至 {{from}} 与 {{to}} 之间的路线。",
			hintTrade: "{{action}} {{n}} 份{{good}}。",
			hintCash: "领取钱币。",
			architect: "建筑师",
			prefect: "执政官",
			mercator: "商人",
			colonist: "殖民官",
			diplomat: "外交官",
			senator: "元老",
			consul: "领事",
			tribune: "护民官",
			mason: "石匠",
			farmer: "农夫",
			smith: "铁匠",
			vintner: "酿酒师",
			weaver: "织工",
			vesta: "维斯塔",
			jupiter: "朱庇特",
			saturnus: "萨图恩",
			mercurius: "墨丘利",
			mars: "玛尔斯",
			minerva: "密涅瓦",
			concordia: "Concordia",
			brick: "砖块",
			food: "粮食",
			tool: "工具",
			wine: "葡萄酒",
			cloth: "布料",
			land: "陆地殖民者",
			sea: "海上殖民者",
			invalid: "当前不能执行该行动，请检查目标、费用和行动阶段。",
			map: "地图",
			auto: "自动",
			italia: "Italia（2至4人）",
			imperium: "Imperium（3至5人）",
			mapHelp: "人数不符时自动采用该人数的官方地图。",
			intermediate: "中间计分",
			intermediateHelp: "推荐首次游玩时开启。",
			phasePlay: "打出一张人物牌",
			phaseMove: "选择殖民者与目的路线",
			phaseBuild: "在相邻城市建造房屋",
			phasePrefect: "选择省份生产，或领取钱币",
			phaseTrade: "最多交易两种货物",
			phaseBuy: "选择要购买的人物牌",
			phaseColonist: "部署殖民者，或领取钱币",
			phaseTribune: "可在Roma部署一名殖民者",
			phaseCopy: "选择对手的顶牌",
			phaseReceive: "选择要接收的新货物",
			phaseDone: "对局结束",
			waiting: "等待 {{name}}",
			turn: "第 {{n}} 回合",
			finalTurns: "最后一轮",
			moves: "剩余移动点 {{n}}",
			purchases: "还可购买 {{n}} 张",
			finishMove: "结束移动",
			finish: "结束行动",
			cash: "领取 {{n}} 钱",
			receive: "接收货物",
			choosePayment: "选择支付的任意货物",
			cancel: "取消",
			confirm: "确认",
			warehouse: "仓库",
			storage: "已使用 {{n}} / 12 格",
			cashLabel: "钱币",
			houses: "房屋",
			colonists: "殖民者",
			cards: "人物牌",
			magnus: "大执政官",
			bonus: "省份奖励",
			market: "人物市场",
			hand: "手牌",
			discard: "弃牌",
			bank: "银行",
			inspect: "查看",
			resetMap: "回到全图",
			details: "详情",
			close: "关闭",
			buildCost: "建造费用",
			any: "任意货物",
			free: "无附费",
			buy: "购买",
			tradeBuy: "买入",
			tradeSell: "卖出",
			recruit: "部署",
			available: "可用",
			used: "已生产",
			keep: "接收 {{n}} 份",
			supply: "房屋余量 {{n}}",
			cardArchitect: "移动殖民者，然后在相邻城市建房。",
			cardPrefect: "让一个省份生产，或收取所有已翻面的金币。",
			cardMercator: "获得钱币，然后交易最多两种货物。",
			cardColonist: "在己方城市部署殖民者，或获得钱币。",
			cardDiplomat: "复制一名对手的顶牌行动。",
			cardSenator: "按原槽位费用购买最多两张牌。",
			cardConsul: "忽略槽位附费购买一张牌。",
			cardTribune: "收回弃牌，获得钱币，并可部署一名殖民者。",
			cardSpecialist: "对应货物的全部己方房屋生产。",
			logPlay: "{{name}} 打出了{{target}}。",
			logMove: "{{name}} 移动了殖民者，使用 {{n}} 点移动。",
			logBuild: "{{name}} 在 {{target}} 建造了房屋。",
			logProduce: "{{name}} 令 {{target}} 生产。",
			logCash: "{{name}} 获得了 {{n}} 钱。",
			logTrade: "{{name}} 交易了 {{n}} 份{{target}}。",
			logBuy: "{{name}} 购买了{{target}}。",
			logRecruit: "{{name}} 在 {{target}} 部署了殖民者。",
			logReceive: "{{name}} 接收了 {{n}} 份货物。",
			logFinish: "{{name}} 结束了行动。",
			logIntermediate: "{{name}} 的中间计分为 {{n}} 分。",
			logEnd: "{{name}} 触发了最后一轮。",
			score: "总分",
			results: "诸神的赞誉",
			winner: "{{name}} 获胜",
			hideResult: "收起结算，回看版图",
			showResult: "查看结算",
			confirmAgain: "确认再来一局",
			confirmLobby: "确认返回大厅",
			autopilot: "托管 {{n}}%",
			factor: "每张 {{n}} 分",
			hint: "执行：{{action}}"
		},
		en: {
			name: "Concordia",
			desc: "Expand your trade network across the Roman Empire. Build cities and collect personality cards to earn the gods’ favour.",
			rules: "Goal:\nBuild houses, develop colonists and trade, and collect personality cards. Each card scores for its god at the end; the highest score wins.\nSetup:\nFor 2–5 players. Italia supports 2–4 and Imperium supports 3–5. Auto uses Italia for 2–3 and Imperium for 4–5; an incompatible manual selection uses the official map for the player count. Shuffle city tokens within each letter group. Each province’s most valuable good becomes its bonus. Each player has 7 starting cards, 15 houses and 3 colonists of each type. One land and one sea colonist start in Roma; the other four occupy the 12-space storehouse, together with 2 food and 1 each of brick, tool, wine and cloth. A random first player receives 5 coins; each later seat receives one more. The last player holds Praefectus Magnus. Shuffle market decks I through the player count separately, stack in that order, and display 7 cards.\nTurns:\nPlay one personality card and carry out its action. Only the top card of each opponent’s discard pile is visible. Purchased cards immediately enter your hand.\n· Architect: Movement points equal your colonists on the map. Distribute them freely; unused points are allowed. Land colonists use land routes and sea colonists sea routes. Leaving a city for an adjacent route costs 1 point; moving from a route through a city to another adjacent route costs 1 more. You may pass through occupied routes, paying for every step, but cannot stop on an occupied route. After all movement, build any number of houses in cities adjacent to your colonists. At most one house per player per city; none in Roma. A brick city costs 1 food; other cities cost 1 brick and 1 of that city’s good. Coin costs are 1/2/3/4/5 for brick/food/tool/wine/cloth, multiplied by the total houses in the city after building.\n· Prefect: Choose an active province, receive one bonus good, produce one good per house there for every owner, and flip the marker to coins. Alternatively collect all visible coins and reactivate those markers. Cloth markers show 1 coin, all other goods 2. Praefectus Magnus must double the province bonus when its owner produces, then passes to the player on the right. House production is unchanged. Collecting coins neither doubles the coins nor passes Magnus.\n· Mercator: Gain 3 coins with a starting Mercator or 5 with a purchased one, then buy and/or sell up to two types of goods in any quantity your cash and space permit. Fixed prices for brick/food/tool/wine/cloth are 3/4/5/6/7.\n· Senator: Buy up to 2 market cards, paying their printed costs plus the original slot surcharge. The seven surcharges are none, any good, any good, cloth, cloth, any good plus cloth, and 2 cloth. Shift and refill only after both purchases. Consul buys one card without a slot surcharge.\n· Diplomat: Copy another player’s top discard action, excluding Diplomat and Tribune. Your own top discard remains the Diplomat.\n· Colonist: Pay 1 food and 1 tool per new land or sea colonist, deploying from storage to Roma or a city with your house. Alternatively gain 5 coins plus 1 for each of your colonists already on the map.\n· Tribune: Recover all discards, including this card, and gain 1 coin for each recovered card beyond the third. You may also pay 1 food and 1 tool to deploy one colonist from storage into Roma.\n· Mason, Farmer, Smith, Vintner, Weaver: Produce one good at each of your houses in the corresponding brick, food, tool, wine or cloth city.\nStorehouse:\nEach good and each undeployed colonist occupies one of 12 spaces. You may not discard existing goods. If production exceeds free space, choose which new goods to receive, filling all free spaces. Goods and coins are unlimited; colonists are limited to 6 per player. Players cannot trade with each other.\nEnding and scoring:\nThe first player to build a 15th house or buy the last remaining card receives the 7-point Concordia bonus. Every other player gets one final turn, then scores every card in hand and discard by its god:\n· Vesta: 1 point per full 10 coins of cash plus the market value of stored goods.\n· Jupiter: 1 point per house in a non-brick city.\n· Saturnus: 1 point per province containing your house.\n· Mercurius: 2 points per good type produced by your houses.\n· Mars: 2 points per colonist on the map.\n· Minerva: 3 points per matching brick, food or tool house; 4 per wine house; 5 per cloth house.\nMost points wins. Ties favour the holder of Praefectus Magnus, then the first tied player who would receive it when passing to the right.\nIntermediate scoring (optional, off by default):\nAfter each player’s first Tribune recovery, record their current score. Once everyone has done so, first place receives 2 coins and second place 1 coin; tied players at a position receive the same reward. These scores do not carry into final scoring.",
			hintMove: "Move a colonist to the route between {{from}} and {{to}}.",
			hintTrade: "{{action}} {{n}} {{good}}.",
			hintCash: "Collect coins.",
			architect: "Architect",
			prefect: "Prefect",
			mercator: "Mercator",
			colonist: "Colonist",
			diplomat: "Diplomat",
			senator: "Senator",
			consul: "Consul",
			tribune: "Tribune",
			mason: "Mason",
			farmer: "Farmer",
			smith: "Smith",
			vintner: "Vintner",
			weaver: "Weaver",
			vesta: "Vesta",
			jupiter: "Jupiter",
			saturnus: "Saturnus",
			mercurius: "Mercurius",
			mars: "Mars",
			minerva: "Minerva",
			concordia: "Concordia",
			brick: "Brick",
			food: "Food",
			tool: "Tool",
			wine: "Wine",
			cloth: "Cloth",
			land: "Land colonist",
			sea: "Sea colonist",
			invalid: "This action is unavailable. Check the target, costs and current phase.",
			map: "Map",
			auto: "Auto",
			italia: "Italia (2–4 players)",
			imperium: "Imperium (3–5 players)",
			mapHelp: "An incompatible selection uses the official map for the player count.",
			intermediate: "Intermediate scoring",
			intermediateHelp: "Recommended for a first game.",
			phasePlay: "Play a personality card",
			phaseMove: "Choose a colonist and destination route",
			phaseBuild: "Build houses in adjacent cities",
			phasePrefect: "Produce a province or collect coins",
			phaseTrade: "Trade up to two types of goods",
			phaseBuy: "Choose personality cards to buy",
			phaseColonist: "Deploy colonists or collect coins",
			phaseTribune: "You may deploy one colonist in Roma",
			phaseCopy: "Choose an opponent’s top card",
			phaseReceive: "Choose new goods to receive",
			phaseDone: "Game over",
			waiting: "Waiting for {{name}}",
			turn: "Turn {{n}}",
			finalTurns: "Final turns",
			moves: "Movement left: {{n}}",
			purchases: "Purchases left: {{n}}",
			finishMove: "Finish moving",
			finish: "Finish action",
			cash: "Collect {{n}} coins",
			receive: "Receive goods",
			choosePayment: "Choose any good to pay",
			cancel: "Cancel",
			confirm: "Confirm",
			warehouse: "Storehouse",
			storage: "{{n}} / 12 spaces used",
			cashLabel: "Coins",
			houses: "Houses",
			colonists: "Colonists",
			cards: "Cards",
			magnus: "Praefectus Magnus",
			bonus: "Province bonus",
			market: "Personality market",
			hand: "Hand",
			discard: "Discards",
			bank: "Bank",
			inspect: "Inspect",
			resetMap: "Show full map",
			details: "Details",
			close: "Close",
			buildCost: "Building cost",
			any: "Any good",
			free: "No surcharge",
			buy: "Buy",
			tradeBuy: "Buy",
			tradeSell: "Sell",
			recruit: "Deploy",
			available: "Active",
			used: "Produced",
			keep: "Receive {{n}} goods",
			supply: "Houses remaining: {{n}}",
			cardArchitect: "Move colonists, then build in adjacent cities.",
			cardPrefect: "Produce a province or collect all visible coins.",
			cardMercator: "Gain coins, then trade up to two goods types.",
			cardColonist: "Deploy colonists in your cities or gain coins.",
			cardDiplomat: "Copy an opponent’s top discard action.",
			cardSenator: "Buy up to two cards at their original slot costs.",
			cardConsul: "Buy one card without a slot surcharge.",
			cardTribune: "Recover discards, gain coins, and optionally deploy one colonist.",
			cardSpecialist: "All your houses of the matching good produce.",
			logPlay: "{{name}} played {{target}}.",
			logMove: "{{name}} moved a colonist using {{n}} movement.",
			logBuild: "{{name}} built in {{target}}.",
			logProduce: "{{name}} produced {{target}}.",
			logCash: "{{name}} gained {{n}} coins.",
			logTrade: "{{name}} traded {{n}} {{target}}.",
			logBuy: "{{name}} bought {{target}}.",
			logRecruit: "{{name}} deployed a colonist in {{target}}.",
			logReceive: "{{name}} received {{n}} goods.",
			logFinish: "{{name}} finished their action.",
			logIntermediate: "{{name}} scored {{n}} intermediate points.",
			logEnd: "{{name}} triggered the final turns.",
			score: "Total",
			results: "Favour of the gods",
			winner: "{{name}} wins",
			hideResult: "Hide results and inspect the map",
			showResult: "Show results",
			confirmAgain: "Confirm new game",
			confirmLobby: "Confirm return to lobby",
			autopilot: "Autopilot {{n}}%",
			factor: "{{n}} points per card",
			hint: "Perform: {{action}}"
		}
	}
};
//#endregion
export { tt as default };
