import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useCallback as n, useRef as r, useState as i } from "react";
import { useT as a } from "@bgparty/sdk/i18n";
import { useFxAnchor as o, useFxAnchorsMaybe as s } from "@bgparty/sdk/fx/anchors";
import { Texture as c } from "@bgparty/sdk/texture";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { LogTicker as f } from "@bgparty/sdk/ui/log-sheet";
import { gameAssetUrl as p } from "@bgparty/sdk/assets";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { SheetFxProbe as _, SheetView as ee } from "@bgparty/sdk/sheet-view";
import { Floater as v, FlySprite as y, PulseBox as b } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as x, OptionSection as S, OptionSwitch as C } from "@bgparty/sdk/ui/game-options";
//#region src/games/concordia/venus-maps.ts
function w(e, t, n, r, i, a, o, s = {
	x: 100,
	y: 95,
	w: 1600,
	h: 1080
}) {
	let c = i.map(([e, r, i, a, o]) => ({
		id: e.toLowerCase().replace(/[^a-z]/g, ""),
		name: e,
		x: Math.round(r / t * 1800),
		y: Math.round(i / n * 1260),
		province: a,
		group: o
	})), l = [];
	for (let [e, t] of [["land", a], ["sea", o]]) for (let [n, r] of t.split(" ").entries()) {
		let [t, i] = r.split("-").map(Number), o = e === "sea" && a.split(" ").some((e) => e === r || e === `${i}-${t}`);
		l.push({
			id: `${e[0]}${n}`,
			a: c[t].id,
			b: c[i].id,
			kind: e,
			bend: e === "sea" ? o ? 50 : 28 : 0
		});
	}
	return {
		id: e,
		cities: c,
		roads: l,
		provinces: r,
		frame: s
	};
}
var T = w("hellas", 2526, 1771, [
	"Epirus",
	"Thessalia",
	"Locris",
	"Euboea",
	"Sporades",
	"Cyclades",
	"Attica",
	"Argolis",
	"Achaia",
	"Laconia"
], [
	[
		"Athenae",
		1710,
		790,
		-1,
		""
	],
	[
		"Nicopolis",
		770,
		325,
		0,
		"A"
	],
	[
		"Kephallenia",
		710,
		635,
		0,
		"A"
	],
	[
		"Zakynthos",
		770,
		825,
		0,
		"A"
	],
	[
		"Metropolis",
		1110,
		230,
		1,
		"A"
	],
	[
		"Demetrias",
		1470,
		220,
		1,
		"A"
	],
	[
		"Thermos",
		1030,
		515,
		2,
		"A"
	],
	[
		"Delphi",
		1300,
		585,
		2,
		"A"
	],
	[
		"Oreos",
		1555,
		405,
		3,
		"B"
	],
	[
		"Chalcis",
		1700,
		580,
		3,
		"B"
	],
	[
		"Karystos",
		1945,
		740,
		3,
		"B"
	],
	[
		"Skyros",
		2030,
		415,
		4,
		"B"
	],
	[
		"Psyra",
		2260,
		560,
		4,
		"B"
	],
	[
		"Naxos",
		2260,
		1145,
		5,
		"B"
	],
	[
		"Melos",
		1945,
		1270,
		5,
		"B"
	],
	[
		"Thera",
		2290,
		1430,
		5,
		"B"
	],
	[
		"Thebae",
		1530,
		630,
		6,
		"C"
	],
	[
		"Corinthus",
		1450,
		795,
		6,
		"C"
	],
	[
		"Argos",
		1380,
		950,
		7,
		"C"
	],
	[
		"Hermione",
		1590,
		1015,
		7,
		"C"
	],
	[
		"Patrae",
		1080,
		710,
		8,
		"C"
	],
	[
		"Olympia",
		985,
		915,
		8,
		"C"
	],
	[
		"Megalopolis",
		1170,
		960,
		8,
		"C"
	],
	[
		"Methone",
		1060,
		1215,
		9,
		"C"
	],
	[
		"Sparta",
		1315,
		1165,
		9,
		"C"
	],
	[
		"Kythera",
		1495,
		1465,
		9,
		"C"
	]
], "1-4 1-6 4-5 4-6 5-7 5-8 6-7 6-20 7-16 8-9 9-10 9-16 16-17 16-0 17-0 17-20 17-18 18-19 18-22 18-24 20-21 20-22 21-22 21-23 22-23 22-24", "1-2 2-3 2-20 3-20 3-21 3-23 7-20 5-8 8-11 8-9 9-10 10-11 10-12 11-12 12-13 10-13 10-14 13-14 14-15 14-19 14-25 17-0 17-19 0-19 0-10 0-14 19-25 21-23 23-25 25-15", {
	x: 350,
	y: 95,
	w: 1360,
	h: 1075
}), E = w("ionium", 2289, 1607, [
	"Dardania",
	"Epirus",
	"Macedonia",
	"Campania",
	"Calabria",
	"Sicilia",
	"Thracia",
	"Ionia",
	"Asia",
	"Achaia",
	"Sparta",
	"Rhodos"
], [
	[
		"Athenae",
		1370,
		910,
		-1,
		""
	],
	[
		"Scodra",
		805,
		278,
		0,
		"A"
	],
	[
		"Scupi",
		1108,
		242,
		0,
		"A"
	],
	[
		"Philippopolis",
		1355,
		220,
		0,
		"A"
	],
	[
		"Apollonia",
		790,
		480,
		1,
		"A"
	],
	[
		"Ambrakia",
		990,
		730,
		1,
		"A"
	],
	[
		"Thessalonica",
		1210,
		485,
		2,
		"A"
	],
	[
		"Larissa",
		1180,
		638,
		2,
		"A"
	],
	[
		"Terventum",
		215,
		315,
		3,
		"B"
	],
	[
		"Neapolis",
		215,
		520,
		3,
		"B"
	],
	[
		"Canusium",
		395,
		405,
		3,
		"B"
	],
	[
		"Brundisium",
		610,
		495,
		4,
		"B"
	],
	[
		"Heraclea",
		450,
		585,
		4,
		"B"
	],
	[
		"Croton",
		548,
		790,
		4,
		"B"
	],
	[
		"Messana",
		345,
		950,
		5,
		"B"
	],
	[
		"Syracusae",
		325,
		1170,
		5,
		"B"
	],
	[
		"Hadrianopolis",
		1635,
		220,
		6,
		"C"
	],
	[
		"Abdera",
		1485,
		360,
		6,
		"C"
	],
	[
		"Byzantium",
		1990,
		300,
		6,
		"C"
	],
	[
		"Dardanos",
		1685,
		500,
		7,
		"C"
	],
	[
		"Pergamon",
		1775,
		700,
		7,
		"C"
	],
	[
		"Ephesus",
		1820,
		885,
		7,
		"C"
	],
	[
		"Hadrianoi",
		1985,
		510,
		8,
		"C"
	],
	[
		"Colossae",
		2065,
		875,
		8,
		"C"
	],
	[
		"Patrae",
		1085,
		895,
		9,
		"D"
	],
	[
		"Delphi",
		1215,
		825,
		9,
		"D"
	],
	[
		"Lepreon",
		1105,
		1050,
		10,
		"D"
	],
	[
		"Sparta",
		1260,
		1145,
		10,
		"D"
	],
	[
		"Heraklion",
		1620,
		1370,
		10,
		"D"
	],
	[
		"Rhodos",
		1940,
		1150,
		11,
		"C"
	],
	[
		"Patara",
		2085,
		1175,
		11,
		"C"
	]
], "1-2 1-4 2-3 2-6 3-16 3-17 4-5 4-6 5-7 5-24 6-7 6-17 7-25 8-9 8-10 9-10 9-12 9-13 10-11 11-12 12-13 13-14 14-15 16-18 16-19 17-19 18-22 19-20 19-22 20-21 20-22 21-23 23-30 24-25 24-0 25-0 26-0 26-27", "1-10 1-4 4-11 4-5 4-13 11-10 11-12 11-13 12-13 9-14 9-15 13-26 14-15 14-26 15-26 6-17 6-19 6-21 6-0 17-18 17-19 18-19 19-20 20-21 21-29 21-0 24-5 24-25 24-26 0-25 0-26 0-27 0-28 0-29 26-28 27-28 28-29 28-30 29-30");
E.roads.push({
	id: "lx",
	a: "brundisium",
	b: "apollonia",
	kind: "land",
	bend: 0,
	transit: !0
});
var D = new Set(E.cities.filter((e) => e.group === "B").map((e) => e.id)), O = E.provinces.filter((e, t) => ![
	3,
	4,
	5
].includes(t)), te = {
	hellas: T,
	ionium: E,
	ioniumSmall: {
		...E,
		id: "ioniumSmall",
		cities: E.cities.filter((e) => !D.has(e.id)).map((e) => ({
			...e,
			province: e.province > 5 ? e.province - 3 : e.province
		})),
		roads: E.roads.filter((e) => !D.has(e.a) && !D.has(e.b)),
		provinces: O,
		frame: {
			x: 570,
			y: 95,
			w: 1130,
			h: 1080
		}
	},
	cyprus: w("cyprus", 2273, 1594, [
		"I",
		"II",
		"III",
		"IV",
		"V",
		"VI",
		"VII",
		"VIII",
		"IX",
		"X",
		"XI",
		"XII"
	], [
		[
			"Antiochia",
			1395,
			830,
			-1,
			""
		],
		[
			"Paphos",
			345,
			1300,
			0,
			"A"
		],
		[
			"Soloi",
			445,
			1150,
			0,
			"A"
		],
		[
			"Keryneia",
			620,
			1085,
			0,
			"A"
		],
		[
			"Karpasia",
			875,
			1005,
			1,
			"A"
		],
		[
			"Salamis",
			790,
			1165,
			1,
			"A"
		],
		[
			"Kition",
			680,
			1250,
			2,
			"A"
		],
		[
			"Amathous",
			545,
			1310,
			2,
			"A"
		],
		[
			"Tyana",
			940,
			240,
			3,
			"D"
		],
		[
			"Tarsus",
			1045,
			565,
			3,
			"B"
		],
		[
			"Anazarbus",
			1320,
			415,
			5,
			"B"
		],
		[
			"Mallus",
			1195,
			645,
			5,
			"B"
		],
		[
			"Alexandria A.I.",
			1415,
			655,
			7,
			"B"
		],
		[
			"Cyrrhus",
			1635,
			610,
			7,
			"B"
		],
		[
			"Germanikeia",
			1625,
			310,
			6,
			"B"
		],
		[
			"Samosata",
			2030,
			330,
			6,
			"B"
		],
		[
			"Zeugma",
			1885,
			500,
			6,
			"B"
		],
		[
			"Hierapolis",
			1920,
			695,
			8,
			"C"
		],
		[
			"Chalcis A.B.",
			1650,
			885,
			8,
			"C"
		],
		[
			"Resafa",
			2070,
			990,
			9,
			"C"
		],
		[
			"Seriane",
			1870,
			1110,
			9,
			"C"
		],
		[
			"Apamea",
			1490,
			1085,
			10,
			"C"
		],
		[
			"Laodiceia",
			1290,
			1040,
			10,
			"C"
		],
		[
			"Arados",
			1310,
			1255,
			11,
			"C"
		],
		[
			"Hemesa",
			1585,
			1325,
			11,
			"C"
		],
		[
			"Tripolis",
			1300,
			1410,
			11,
			"C"
		],
		[
			"Palmyra",
			2e3,
			1375,
			9,
			"C"
		],
		[
			"Korakesion",
			210,
			665,
			4,
			"D"
		],
		[
			"Germanicopolis",
			475,
			635,
			4,
			"D"
		],
		[
			"Anemurium",
			450,
			850,
			4,
			"D"
		],
		[
			"Seleucia",
			760,
			735,
			3,
			"D"
		]
	], "8-9 8-10 8-14 9-10 9-11 9-30 10-11 10-13 10-14 12-13 13-14 13-17 13-0 14-15 14-16 15-16 15-17 16-17 17-18 17-19 18-0 18-20 18-21 19-20 19-26 20-21 20-24 20-26 21-0 21-22 21-23 21-24 22-0 23-24 23-25 24-25 24-26 27-28 27-29 28-29 28-30 29-30", "1-2 1-6 1-7 1-25 1-27 2-3 3-4 3-29 4-5 4-30 4-0 5-6 5-22 6-7 6-25 9-11 9-30 11-12 11-30 11-0 12-0 22-0 22-23 22-25 23-25 27-29 29-30")
}, k = [
	"brick",
	"food",
	"tool",
	"wine",
	"cloth"
], A = () => ({
	brick: 0,
	food: 0,
	tool: 0,
	wine: 0,
	cloth: 0
}), j = {
	brick: 3,
	food: 4,
	tool: 5,
	wine: 6,
	cloth: 7
}, ne = {
	brick: 1,
	food: 2,
	tool: 3,
	wine: 4,
	cloth: 5
}, re = {
	brick: 2,
	food: 2,
	tool: 2,
	wine: 2,
	cloth: 1
}, ie = [
	"vesta",
	"jupiter",
	"saturnus",
	"venus",
	"mercurius",
	"mars",
	"minerva"
], M = (e, t, n) => ({
	id: e,
	role: t,
	god: n,
	cost: [],
	deck: 0
}), ae = [
	M("s-architect", "architect", "jupiter"),
	M("s-diplomat", "diplomat", "jupiter"),
	M("s-mercator", "mercator", "mercurius"),
	M("s-prefect1", "prefect", "saturnus"),
	M("s-prefect2", "prefect", "saturnus"),
	M("s-senator", "senator", "vesta"),
	M("s-tribune", "tribune", "mars")
], oe = [
	[
		1,
		"architect",
		"jupiter",
		["tool"]
	],
	[
		1,
		"prefect",
		"saturnus",
		["wine"]
	],
	[
		1,
		"mercator",
		"mercurius",
		["wine"]
	],
	[
		1,
		"colonist",
		"mars",
		["food"]
	],
	[
		1,
		"diplomat",
		"saturnus",
		["tool"]
	],
	[
		1,
		"mason",
		"minerva",
		["food"],
		"brick",
		3
	],
	[
		1,
		"farmer",
		"minerva",
		["brick", "food"],
		"food",
		3
	],
	[
		1,
		"smith",
		"minerva",
		["brick", "tool"],
		"tool",
		3
	],
	[
		2,
		"architect",
		"jupiter",
		["tool"]
	],
	[
		2,
		"prefect",
		"saturnus",
		["wine"]
	],
	[
		2,
		"mercator",
		"mercurius",
		["wine"]
	],
	[
		2,
		"colonist",
		"mars",
		["food"]
	],
	[
		2,
		"consul",
		"jupiter",
		["cloth"]
	],
	[
		2,
		"vintner",
		"minerva",
		["brick", "wine"],
		"wine",
		4
	],
	[
		2,
		"weaver",
		"minerva",
		["brick", "cloth"],
		"cloth",
		5
	],
	[
		3,
		"architect",
		"jupiter",
		["tool"]
	],
	[
		3,
		"prefect",
		"saturnus",
		["wine"]
	],
	[
		3,
		"mercator",
		"mercurius",
		["wine"]
	],
	[
		3,
		"colonist",
		"mars",
		["food"]
	],
	[
		3,
		"diplomat",
		"saturnus",
		["food"]
	],
	[
		3,
		"consul",
		"jupiter",
		["cloth"]
	],
	[
		4,
		"architect",
		"jupiter",
		["tool"]
	],
	[
		4,
		"prefect",
		"saturnus",
		["wine"]
	],
	[
		4,
		"colonist",
		"mars",
		["food"]
	],
	[
		4,
		"diplomat",
		"mercurius",
		["tool"]
	],
	[
		4,
		"consul",
		"jupiter",
		["cloth"]
	],
	[
		5,
		"prefect",
		"saturnus",
		["wine"]
	],
	[
		5,
		"mercator",
		"mercurius",
		["wine"]
	],
	[
		5,
		"diplomat",
		"mars",
		["food"]
	],
	[
		5,
		"consul",
		"jupiter",
		["cloth"]
	]
].map(([e, t, n, r, i, a], o) => ({
	id: `m${o}`,
	deck: e,
	role: t,
	god: n,
	cost: r,
	...i ? {
		specialty: i,
		points: a
	} : {}
})), N = [...ae, M("v-magister", "magister", "venus")], se = [
	...ae.filter((e) => !["s-prefect2", "s-senator"].includes(e.id)),
	M("t-praetor", "praetor", "vesta"),
	{
		...M("t-legatus", "legatus", "jupiter"),
		gods: [
			"jupiter",
			"saturnus",
			"venus"
		]
	}
], ce = oe.map((e) => ({
	...e,
	deck: e.id === "m5" ? 2 : e.deck
})).map((e) => {
	let t = {
		m1: [
			"prefect",
			"architect",
			"wine"
		],
		m9: [
			"architect",
			"mercator",
			"tool"
		],
		m17: [
			"prefect",
			"mercator",
			"wine"
		],
		m21: [
			"architect",
			"mercator",
			"tool"
		]
	}[e.id];
	return t ? {
		...e,
		id: `v-${e.id}`,
		role: t[0],
		choice: t[1],
		god: "venus",
		cost: [t[2]]
	} : e;
}), le = ce.map((e) => e.choice ? {
	...e,
	id: `t-${e.id}`
} : e.role === "consul" ? {
	...e,
	id: `t-${e.id}`,
	role: "proconsul"
} : e), P = Object.fromEntries([
	...ae,
	...oe,
	...N,
	...se,
	...ce,
	...le
].map((e) => [e.id, e])), ue = [
	[],
	["any"],
	["any"],
	["cloth"],
	["cloth"],
	["any", "cloth"],
	["cloth", "cloth"]
], de = {
	A: [
		"food",
		"brick",
		"brick",
		"food",
		"tool",
		"wine",
		"cloth"
	],
	B: [
		"tool",
		"tool",
		"food",
		"brick",
		"brick",
		"food",
		"wine",
		"cloth"
	],
	C: [
		"wine",
		"wine",
		"tool",
		"food",
		"brick",
		"brick",
		"brick",
		"food",
		"tool",
		"cloth"
	],
	D: [...k]
};
function F(e, t, n, r, i) {
	let a = n.map(([e, t, n, r, i]) => ({
		id: e.toLowerCase().replace(/[^a-z]/g, ""),
		name: e,
		x: t,
		y: n,
		province: r,
		group: i
	})), o = [];
	for (let [e, t] of [["land", r], ["sea", i]]) for (let [n, i] of t.split(" ").entries()) {
		let [t, s] = i.split("-").map(Number), c = e === "sea" && r.split(" ").some((e) => e === i || e === `${s}-${t}`);
		o.push({
			id: `${e[0]}${n}`,
			a: a[t].id,
			b: a[s].id,
			kind: e,
			bend: e === "sea" ? c ? 48 : 24 : 0
		});
	}
	return {
		id: e,
		cities: a,
		roads: o,
		provinces: t
	};
}
var I = {
	italia: F("italia", [
		"Venetia",
		"Transpadana",
		"Liguria",
		"Aemilia",
		"Etruria",
		"Corsica",
		"Umbria",
		"Campania",
		"Apulia",
		"Lucania",
		"Sicilia"
	], [
		[
			"Roma",
			880,
			779,
			-1,
			""
		],
		[
			"Bauzanum",
			305,
			389,
			0,
			"A"
		],
		[
			"Aquileia",
			488,
			367,
			0,
			"A"
		],
		[
			"Verona",
			391,
			503,
			0,
			"A"
		],
		[
			"Comum",
			223,
			697,
			1,
			"A"
		],
		[
			"Segusio",
			178,
			884,
			1,
			"A"
		],
		[
			"Genua",
			335,
			866,
			2,
			"A"
		],
		[
			"Nicae",
			305,
			1072,
			2,
			"A"
		],
		[
			"Mutina",
			469,
			615,
			3,
			"B"
		],
		[
			"Ravenna",
			608,
			512,
			3,
			"B"
		],
		[
			"Florentia",
			608,
			694,
			4,
			"B"
		],
		[
			"Cosa",
			732,
			814,
			4,
			"B"
		],
		[
			"Aleria",
			635,
			1020,
			5,
			"B"
		],
		[
			"Olbia",
			806,
			1100,
			5,
			"B"
		],
		[
			"Ancona",
			781,
			479,
			6,
			"C"
		],
		[
			"Hadria",
			948,
			525,
			6,
			"C"
		],
		[
			"Spoletium",
			816,
			629,
			6,
			"C"
		],
		[
			"Casinum",
			999,
			688,
			7,
			"B"
		],
		[
			"Neapolis",
			1153,
			727,
			7,
			"B"
		],
		[
			"Luceria",
			1153,
			540,
			8,
			"C"
		],
		[
			"Brundisium",
			1368,
			425,
			8,
			"C"
		],
		[
			"Potentia",
			1284,
			616,
			9,
			"C"
		],
		[
			"Croton",
			1503,
			663,
			9,
			"C"
		],
		[
			"Messana",
			1486,
			893,
			10,
			"C"
		],
		[
			"Syracusae",
			1584,
			988,
			10,
			"C"
		],
		[
			"Panormus",
			1344,
			1063,
			10,
			"C"
		]
	], "1-2 1-3 2-3 2-9 3-9 3-8 3-4 4-8 4-5 4-6 5-6 5-7 6-7 6-10 8-9 8-10 9-10 9-14 10-11 10-16 11-0 0-16 0-17 16-14 16-15 16-17 15-17 15-19 17-19 17-18 19-20 19-21 21-20 21-22 22-23 23-25 25-24", "2-14 2-9 9-14 14-15 15-20 20-22 22-24 22-23 23-24 23-25 24-25 18-23 18-25 0-18 0-25 0-13 0-11 6-11 6-7 7-12 11-12 12-13 13-25"),
	imperium: F("imperium", [
		"Britannia",
		"Gallia",
		"Hispania",
		"Germania",
		"Italia",
		"Mauretania",
		"Dacia",
		"Hellas",
		"Lybia",
		"Asia",
		"Syria",
		"Aegyptus"
	], [
		[
			"Roma",
			835,
			686,
			-1,
			""
		],
		[
			"Isca D.",
			290,
			427,
			0,
			"A"
		],
		[
			"Londinium",
			391,
			370,
			0,
			"A"
		],
		[
			"Lutetia",
			480,
			480,
			1,
			"B"
		],
		[
			"Burdigala",
			417,
			637,
			1,
			"B"
		],
		[
			"Massilia",
			596,
			672,
			1,
			"B"
		],
		[
			"Brigantium",
			203,
			698,
			2,
			"B"
		],
		[
			"Olisipo",
			205,
			882,
			2,
			"B"
		],
		[
			"Valentia",
			468,
			868,
			2,
			"B"
		],
		[
			"Colonia A.",
			613,
			366,
			3,
			"A"
		],
		[
			"Vindobona",
			860,
			396,
			3,
			"A"
		],
		[
			"Novaria",
			690,
			568,
			4,
			"D"
		],
		[
			"Aquileia",
			844,
			534,
			4,
			"D"
		],
		[
			"Syracusae",
			963,
			832,
			4,
			"D"
		],
		[
			"Rusadir",
			392,
			1042,
			5,
			"B"
		],
		[
			"Carthago",
			794,
			901,
			5,
			"B"
		],
		[
			"Sirmium",
			1033,
			506,
			6,
			"A"
		],
		[
			"Napoca",
			1130,
			399,
			6,
			"A"
		],
		[
			"Tomis",
			1255,
			492,
			6,
			"A"
		],
		[
			"Dyrrhachium",
			1054,
			675,
			7,
			"D"
		],
		[
			"Athenae",
			1211,
			784,
			7,
			"D"
		],
		[
			"Leptis Magna",
			950,
			1071,
			8,
			"C"
		],
		[
			"Cyrene",
			1173,
			1021,
			8,
			"C"
		],
		[
			"Byzantium",
			1328,
			617,
			9,
			"C"
		],
		[
			"Sinope",
			1536,
			565,
			9,
			"C"
		],
		[
			"Attalia",
			1441,
			775,
			9,
			"C"
		],
		[
			"Antiochia",
			1618,
			774,
			10,
			"C"
		],
		[
			"Tyros",
			1594,
			925,
			10,
			"C"
		],
		[
			"Alexandria",
			1423,
			1009,
			11,
			"C"
		],
		[
			"Memphis",
			1498,
			1109,
			11,
			"C"
		],
		[
			"Petra",
			1631,
			1070,
			11,
			"C"
		]
	], "1-2 2-3 3-9 3-4 3-5 4-5 4-6 6-7 6-8 7-8 7-14 8-14 8-5 14-15 15-21 21-22 21-29 22-29 22-28 28-29 28-27 29-30 30-27 27-26 26-25 26-24 25-23 23-24 23-18 23-19 18-17 18-16 17-16 16-10 16-12 16-19 19-20 9-10 9-11 10-12 11-12 11-5 11-0 12-0 0-13", "1-2 1-6 1-4 2-9 4-6 6-7 7-14 8-14 8-15 8-5 14-15 5-15 5-0 0-15 0-13 15-21 21-13 21-22 13-19 13-20 13-22 12-19 20-22 20-28 20-23 20-25 23-24 23-18 18-24 25-26 25-28 26-27 27-28 28-22"),
	...te
}, L = (e) => I[e].cities.find((e) => e.province === -1).id;
function fe(e, t) {
	let n = e.cities.find((e) => e.id === t.a), r = e.cities.find((e) => e.id === t.b), i = r.x - n.x, a = r.y - n.y, o = Math.hypot(i, a);
	return {
		x: (n.x + r.x) / 2 - a / o * t.bend / 2,
		y: (n.y + r.y) / 2 + i / o * t.bend / 2
	};
}
function pe(e, t) {
	let n = e.cities.find((e) => e.id === t.a), r = e.cities.find((e) => e.id === t.b), i = r.x - n.x, a = r.y - n.y, o = Math.hypot(i, a);
	return `M${n.x} ${n.y} Q${(n.x + r.x) / 2 - a / o * t.bend} ${(n.y + r.y) / 2 + i / o * t.bend} ${r.x} ${r.y}`;
}
//#endregion
//#region src/games/concordia/logic.ts
var R = (e) => k.reduce((t, n) => t + e[n], 0), z = (e) => 12 - (6 - e.units.length) - R(e.goods);
function me(e, t, n, r) {
	let i = I[e.map], a = e.players.find((e) => e.rid === t)?.units[n];
	if (!a) return {};
	let o = i.roads.filter((e) => e.kind === a.kind), s = o.find((e) => e.id === a.location), c = {}, l = [];
	if (s) c[s.id] = 0, l.push(s.id);
	else for (let e of o) (e.a === a.location || e.b === a.location) && (c[e.id] = 1, l.push(e.id));
	for (let e = 0; e < l.length; e++) {
		let t = o.find((t) => t.id === l[e]);
		if (!(c[t.id] >= r)) for (let e of o) c[e.id] === void 0 && (e.a === t.a || e.b === t.a || e.a === t.b || e.b === t.b) && (c[e.id] = c[t.id] + 1, l.push(e.id));
	}
	let u = e.players.flatMap((e) => e.units.filter((r, i) => e.rid !== t || i !== n).map((e) => e.location));
	return Object.fromEntries(Object.entries(c).filter(([e, t]) => t > 0 && t <= r && !u.includes(e) && !o.find((t) => t.id === e)?.transit));
}
function he(e, t, n = !1) {
	let r = I[e];
	return [...new Set(t.flatMap((e) => {
		let t = r.roads.find((t) => t.id === e.location);
		return t ? [t.a, t.b] : n ? [] : [e.location];
	}))];
}
function B(e, t) {
	return e.teams?.[t];
}
function ge(e, t) {
	return e.players.filter((n) => n.rid === t || n.rid === B(e, t)).reduce((e, t) => e + t.cash, 0);
}
function _e(e) {
	let t = I[e], n = L(e), r = new Set(t.roads.filter((e) => e.a === n || e.b === n).flatMap((e) => [e.a, e.b]));
	return t.cities.filter((e) => e.id !== n && !r.has(e.id)).map((e) => e.id);
}
function V(e, t) {
	let n = e.cityGoods[t];
	if (!n) return null;
	let r = A();
	return n === "brick" ? r.food = 1 : (r.brick = 1, r[n] += 1), {
		goods: r,
		cash: ne[n] * (1 + e.players.filter((e) => e.houses.includes(t)).length)
	};
}
var H = (e, t) => k.every((n) => e[n] >= t[n]);
function ve(e, t) {
	let n = e.players.find((e) => e.rid === t);
	return !n || n.houses.length >= 15 ? [] : he(e.map, n.units, !!e.teams).filter((r) => {
		let i = V(e, r);
		return i && !n.houses.includes(r) && ge(e, t) >= i.cash && H(n.goods, i.goods);
	});
}
function ye(e, t, n, r) {
	let i = P[e];
	if (!i) return null;
	let a = A();
	for (let e of i.cost) a[e] += 1;
	if (!n) for (let e of ue[t]) if (e === "any") {
		if (!r) return null;
		a[r] += 1;
	} else a[e] += 1;
	return a;
}
//#endregion
//#region src/games/concordia/meta.ts
var be = {
	id: "concordia",
	tier: "alpha",
	nameKey: "games.concordia.name",
	descKey: "games.concordia.desc",
	rulesKey: "games.concordia.rules",
	icon: "🏛️",
	iconImg: "games/concordia.webp",
	minPlayers: 2,
	maxPlayers: 6,
	playerRange: (e) => {
		let t = e;
		return t?.mode === "team" ? {
			min: t.teamPlayers === 6 ? 6 : 4,
			max: t.teamPlayers === 6 ? 6 : 4
		} : {
			min: 2,
			max: 5
		};
	},
	bestPlayers: [3, 4],
	accent: "#376c79",
	releasedAt: "2026-10-31T15:00:36+08:00",
	search: {
		py: "kang kao di ya",
		init: "kkdy"
	},
	hotseat: "cover",
	mechanics: [
		"hand-management",
		"deck-bag-building",
		"route-building"
	],
	interactionTags: [],
	rulesUrl: { en: "https://www.pd-verlag.de/WebRoot/HostEurope/Shops/es719366/MediaGallery/Venus/Rules_Venus_Expansion_engl_A4_1_01.pdf" }
}, U = t.enum([
	"brick",
	"food",
	"tool",
	"wine",
	"cloth"
]), xe = t.object({
	brick: t.int().nonnegative(),
	food: t.int().nonnegative(),
	tool: t.int().nonnegative(),
	wine: t.int().nonnegative(),
	cloth: t.int().nonnegative()
}), Se = t.enum([
	"italia",
	"imperium",
	"hellas",
	"ionium",
	"ioniumSmall",
	"cyprus"
]), Ce = t.enum([
	"classic",
	"venus",
	"team"
]), we = t.object({
	map: t.enum([
		"auto",
		"italia",
		"imperium",
		"hellas",
		"ionium",
		"ioniumSmall",
		"cyprus"
	]).default("auto"),
	intermediate: t.boolean().default(!1),
	mode: Ce.default("classic"),
	teamPlayers: t.union([t.literal(4), t.literal(6)]).default(4)
}).default({
	map: "auto",
	intermediate: !1,
	mode: "classic",
	teamPlayers: 4
}), Te = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		card: t.string().max(24)
	}),
	t.object({
		type: t.literal("move"),
		unit: t.int().min(0).max(5),
		road: t.string().max(8)
	}),
	t.object({
		type: t.literal("build"),
		city: t.string().max(32)
	}),
	t.object({
		type: t.literal("produce"),
		province: t.int().min(0).max(11)
	}),
	t.object({ type: t.literal("cash") }),
	t.object({
		type: t.literal("copy"),
		rid: t.string().max(128)
	}),
	t.object({
		type: t.literal("choose"),
		role: t.enum([
			"architect",
			"prefect",
			"mercator"
		])
	}),
	t.object({
		type: t.literal("startCity"),
		city: t.string().max(32)
	}),
	t.object({
		type: t.literal("recommend"),
		card: t.string().max(24).nullable()
	}),
	t.object({
		type: t.literal("trade"),
		good: U,
		amount: t.int().min(-12).max(12).refine((e) => e !== 0)
	}),
	t.object({
		type: t.literal("buy"),
		slot: t.int().min(0).max(6),
		payment: U.optional()
	}),
	t.object({
		type: t.literal("recruit"),
		kind: t.enum(["land", "sea"]),
		city: t.string().max(32)
	}),
	t.object({
		type: t.literal("receive"),
		goods: xe
	}),
	t.object({ type: t.literal("finish") })
]), Ee = t.object({
	kind: t.enum(["land", "sea"]),
	location: t.string()
}), De = t.object({
	rid: t.string(),
	cash: t.int(),
	goods: xe,
	houses: t.array(t.string()),
	units: t.array(Ee),
	handCount: t.int(),
	discardCount: t.int(),
	top: t.string().nullable(),
	bought: t.array(t.string()),
	intermediate: t.int().nullable()
}), Oe = t.object({
	vesta: t.int(),
	jupiter: t.int(),
	saturnus: t.int(),
	mercurius: t.int(),
	mars: t.int(),
	minerva: t.int(),
	venus: t.int().default(0),
	concordia: t.int(),
	total: t.int(),
	cards: t.array(t.string()),
	factors: t.record(t.string(), t.int())
}), ke = t.object({
	rid: t.string(),
	kind: t.enum([
		"play",
		"move",
		"build",
		"produce",
		"cash",
		"trade",
		"buy",
		"recruit",
		"receive",
		"finish",
		"intermediate",
		"end",
		"start",
		"choose"
	]),
	target: t.string().optional(),
	n: t.int().optional(),
	good: U.optional()
}), Ae = t.enum([
	"play",
	"move",
	"build",
	"prefect",
	"trade",
	"buy",
	"colonist",
	"tribune",
	"copy",
	"receive",
	"done",
	"start",
	"choice",
	"legatus",
	"partner"
]), je = t.object({
	map: Se,
	mode: Ce.optional(),
	teams: t.record(t.string(), t.string()).optional(),
	players: t.array(De),
	turn: t.string(),
	phase: Ae,
	actor: t.string(),
	turnNo: t.int(),
	cityGoods: t.record(t.string(), U),
	activeProvinces: t.array(t.boolean()),
	bonuses: t.array(U),
	magnus: t.string(),
	market: t.array(t.string().nullable()),
	deckCount: t.int(),
	card: t.string().nullable(),
	movement: t.int(),
	purchases: t.int(),
	traded: t.array(U),
	recruited: t.int(),
	pending: t.object({
		rid: t.string(),
		goods: xe,
		space: t.int()
	}).nullable(),
	endBy: t.string().nullable(),
	log: t.array(ke),
	scores: t.record(t.string(), Oe).nullable(),
	intermediateEnabled: t.boolean(),
	intermediateAwarded: t.boolean(),
	copyTargets: t.array(t.string()).optional(),
	freePurchase: t.boolean().optional(),
	proconsulPurchase: t.boolean().optional(),
	singlePlay: t.boolean().optional()
}), Me = t.object({
	hand: t.array(t.string()),
	discard: t.array(t.string()),
	partnerHand: t.array(t.string()).optional(),
	recommendation: t.string().nullable().optional()
}), W = () => ({ code: "games.concordia.invalid" }), Ne = (e, t) => {
	for (let n of k) e.goods[n] -= t[n];
}, G = (e, t) => e.players.find((e) => e.rid === t), K = (e, t) => {
	e.log.push(t);
};
function Pe(t, n) {
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function Fe(e, t) {
	let n = e.players.find((e) => e.rid === t), r = [...n.hand, ...n.discard], i = I[e.map], a = {
		vesta: 0,
		jupiter: 0,
		saturnus: 0,
		mercurius: 0,
		mars: 0,
		minerva: 0,
		venus: 0,
		concordia: e.endBy === t ? 7 : 0,
		total: 0,
		cards: r,
		factors: {}
	}, o = (t) => n.houses.filter((n) => e.cityGoods[n] === t).length, s = {
		vesta: Math.floor((n.cash + k.reduce((e, t) => e + n.goods[t] * j[t], 0)) / 10),
		jupiter: n.houses.filter((t) => e.cityGoods[t] !== "brick").length,
		saturnus: new Set(n.houses.map((e) => i.cities.find((t) => t.id === e).province)).size,
		mercurius: k.filter((e) => o(e) > 0).length * 2,
		mars: n.units.length * 2,
		minerva: 0,
		venus: i.provinces.filter((r, a) => {
			let o = n.houses.filter((e) => i.cities.find((t) => t.id === e).province === a).length;
			return e.teams ? o > 0 && e.players.find((n) => n.rid === e.teams[t]).houses.some((e) => i.cities.find((t) => t.id === e).province === a) : o >= 2;
		}).length * (e.teams ? 1 : 2)
	};
	for (let e of ie) a.factors[e] = s[e];
	for (let e of r) {
		let t = P[e];
		for (let e of t.gods ?? [t.god]) a[e] += t.specialty ? o(t.specialty) * t.points : s[e];
	}
	for (let e of k) a.factors[e] = o(e);
	return a.total = ie.reduce((e, t) => e + a[t], a.concordia), a;
}
function Ie(e) {
	for (e.market = e.market.filter((e) => e !== null); e.market.length < 7 && e.deck.length;) e.market.push(e.deck.shift());
}
function Le(e, t) {
	e.endBy || (e.endBy = t, K(e, {
		rid: t,
		kind: "end"
	}));
}
function Re(e) {
	e.traded = [], e.movement = 0, e.purchases = 0, e.recruited = 0, e.freePurchase = !1, e.proconsulPurchase = !1;
}
function ze(e, t, n) {
	if (n <= t.cash) {
		t.cash -= n;
		return;
	}
	let r = G(e, B(e, t.rid));
	r.cash -= n - t.cash, t.cash = 0;
}
function Be(e) {
	e.phase = "done", e.scores = Object.fromEntries(e.players.map((t) => [t.rid, Fe(e, t.rid)]));
}
function Ve(e, t) {
	let n = t.discard.at(-1);
	if (t.rid === e.turn || t.rid === B(e, e.turn) || !n || ["tribune", "diplomat"].includes(P[n].role) || e.singlePlay && P[n].role === "legatus") return !1;
	let r = [e.turn, B(e, e.turn) ?? ""].sort().join("|");
	return !e.copied?.[r]?.includes(`${t.rid}:${e.topInstances?.[t.rid]}`);
}
function He(e, t = []) {
	if (e.mode && e.mode !== "classic") {
		let n = e.queue?.shift();
		if (n) {
			e.turn = n.rid, Re(e), e.turnNo++, "play" in n ? (e.phase = "partner", e.singlePlay = n.single, e.card = null, e.followers = n.single ? [] : [B(e, n.rid)]) : (e.card = n.id, e.effectiveRole = n.role, Ge(e, n.role, n.id, t));
			return;
		}
		Ie(e);
		let r = e.marker ?? e.turn, i = e.players[(e.players.findIndex((e) => e.rid === r) + 1) % e.players.length].rid;
		if (e.endBy && (i === e.endBy || B(e, i) === e.endBy)) {
			Be(e);
			return;
		}
		e.marker = i, e.turn = i, e.phase = "play", e.card = null, e.turnNo++, e.singlePlay = !1, e.followers = [], Re(e);
		return;
	}
	Ie(e);
	let n = e.players[(e.players.findIndex((t) => t.rid === e.turn) + 1) % e.players.length].rid;
	if (n === e.endBy) {
		e.phase = "done", e.scores = Object.fromEntries(e.players.map((t) => [t.rid, Fe(e, t.rid)]));
		return;
	}
	e.turn = n, e.phase = "play", e.card = null, e.turnNo++, e.traded = [], e.movement = 0, e.purchases = 0, e.recruited = 0;
}
function Ue(e, t) {
	for (; e.gains.length;) {
		let n = e.gains[0], r = G(e, n.rid), i = z(r), a = R(n.goods);
		if (a > i && i > 0) {
			e.phase = "receive";
			return;
		}
		if (i > 0) {
			for (let e of k) r.goods[e] += n.goods[e];
			K(e, {
				rid: r.rid,
				kind: "receive",
				n: a
			}), t.push({
				kind: "concordiaGain",
				rid: r.rid,
				data: {
					goods: n.goods,
					source: n.source
				}
			});
		}
		e.gains.shift();
	}
	He(e, t);
}
function We(e, t) {
	if (e.intermediateEnabled && t.intermediate === null && (t.intermediate = Fe(e, t.rid).total, K(e, {
		rid: t.rid,
		kind: "intermediate",
		n: t.intermediate
	}), e.players.every((e) => e.intermediate !== null) && !e.intermediateAwarded)) {
		let t = [...new Set(e.players.map((e) => e.intermediate))].sort((e, t) => t - e);
		for (let n of e.players) n.cash += n.intermediate === t[0] ? 2 : +(n.intermediate === t[1]);
		e.intermediateAwarded = !0;
	}
}
function Ge(e, t, n, r) {
	let i = G(e, e.turn);
	if (t === "architect") e.phase = "move", e.movement = i.units.length;
	else if (t === "prefect") e.phase = "prefect";
	else if (t === "mercator") e.phase = "trade", i.cash += P[n].deck ? 5 : 3, r.push({
		kind: "concordiaCash",
		rid: i.rid,
		data: { n: P[n].deck ? 5 : 3 }
	});
	else if (t === "diplomat") e.phase = "copy";
	else if ([
		"senator",
		"consul",
		"praetor",
		"proconsul"
	].includes(t)) e.phase = "buy", e.purchases = t === "senator" ? 2 : 1, e.mode && e.mode !== "classic" && (e.freePurchase = t === "consul" || t === "proconsul", e.proconsulPurchase = t === "proconsul");
	else if (t === "colonist") e.phase = "colonist";
	else if (t === "tribune") {
		let t = i.discard.length;
		i.cash += Math.max(0, t - 3), i.hand.push(...i.discard), i.discard = [], e.phase = "tribune", We(e, i), r.push({
			kind: "concordiaRecover",
			rid: i.rid,
			data: { n: t }
		});
	} else {
		let t = P[n].specialty, a = A();
		a[t] = i.houses.filter((n) => e.cityGoods[n] === t).length, e.gains = [{
			rid: i.rid,
			goods: a,
			source: `cc:discard:${i.rid}`
		}], Ue(e, r);
	}
}
function Ke(e, t, n) {
	let r = P[t], i = G(e, e.turn);
	if (e.card = t, r.role === "magister") {
		let t = i.discard[e.repeatIndex ?? -1];
		if (e.repeatIndex = (e.repeatIndex ?? 0) - 1, !t || P[t].role === "senator") {
			He(e, n);
			return;
		}
		Ke(e, t, n);
		return;
	}
	if (r.role === "diplomat") {
		e.phase = "copy";
		return;
	}
	if (r.role === "legatus") {
		e.phase = "legatus";
		return;
	}
	if (r.role === "proconsul") e.singlePlay || e.queue.push({
		rid: B(e, i.rid),
		play: !0,
		single: !0
	});
	else if (r.choice) {
		e.phase = "choice";
		return;
	} else for (let n of e.followers ?? []) e.queue.push({
		rid: n,
		id: t,
		role: r.role
	});
	e.followers = [], e.effectiveRole = r.role, Ge(e, r.role, t, n);
}
function qe(t, n, r) {
	let i = t.mode ?? "classic", a = i === "team";
	if (a && n.length !== t.teamPlayers || !a && n.length > 5) throw Error("Invalid Concordia player count");
	let o = i === "classic" && ![
		"auto",
		"italia",
		"imperium"
	].includes(t.map) ? "auto" : t.map, s = o === "auto" ? i === "classic" ? n.length <= 3 ? "italia" : "imperium" : n.length <= 3 ? "ioniumSmall" : n.length === 4 ? "hellas" : "imperium" : i === "classic" && o === "italia" && n.length > 4 ? "imperium" : i === "classic" && o === "imperium" && n.length < 3 ? "italia" : o, c = L(s), l = i === "classic" ? ae : a ? se : N, u = e(r, 0, n.length), d = [...n.slice(u), ...n.slice(0, u)], f = {
		map: s,
		players: d.map((e, t) => ({
			rid: e,
			cash: 5 + (a ? t % (n.length / 2) : t),
			goods: {
				brick: 1,
				food: 2,
				tool: 1,
				wine: 1,
				cloth: 1
			},
			houses: [],
			units: [{
				kind: "land",
				location: c
			}, {
				kind: "sea",
				location: c
			}],
			hand: l.filter((e) => !a || e.id !== (t < n.length / 2 ? "s-diplomat" : "s-architect")).map((e) => e.id),
			discard: [],
			handCount: 7,
			discardCount: 0,
			top: null,
			bought: [],
			intermediate: null
		})),
		turn: d[0],
		phase: "play",
		turnNo: 1,
		cityGoods: {},
		activeProvinces: [],
		bonuses: [],
		magnus: d.at(-1),
		market: [],
		deck: [],
		card: null,
		movement: 0,
		purchases: 0,
		traded: [],
		recruited: 0,
		gains: [],
		endBy: null,
		log: [],
		scores: null,
		intermediateEnabled: t.intermediate,
		intermediateAwarded: !1,
		seed: r,
		cursor: 1
	};
	i !== "classic" && (f.mode = i, f.marker = d[0], f.queue = [], f.followers = [], f.topInstances = {}, f.copied = {}, a && (f.teams = Object.fromEntries(d.map((e, t) => [e, d[(t + n.length / 2) % n.length]])), f.startQueue = d.slice(n.length / 2), f.turn = f.startQueue[0], f.phase = "start"));
	for (let e of [
		"A",
		"B",
		"C",
		"D"
	]) {
		let t = Pe(f, [...de[e]]);
		for (let n of I[s].cities.filter((t) => t.group === e)) f.cityGoods[n.id] = t.pop();
	}
	f.bonuses = I[s].provinces.map((e, t) => I[s].cities.filter((e) => e.province === t).map((e) => f.cityGoods[e.id]).sort((e, t) => j[t] - j[e])[0]), f.activeProvinces = f.bonuses.map(() => !0);
	for (let e = 1; e <= n.length; e++) f.deck.push(...Pe(f, (i === "classic" ? oe : a ? le : ce).filter((t) => t.deck === e).map((e) => e.id)));
	return Ie(f), {
		state: f,
		fx: []
	};
}
function Je(e, t, n) {
	let r = e.phase === "receive" ? e.gains[0]?.rid : e.turn;
	if (e.phase === "done" || n.by !== r) return W();
	let i = structuredClone(e), a = G(i, i.turn), o = [];
	if (t.type === "startCity") {
		if (i.phase !== "start" || !_e(i.map).includes(t.city)) return W();
		let e = new Set(I[i.map].roads.filter((e) => e.a === t.city || e.b === t.city).map((e) => e.kind)), n = e.size === 1 ? [...e][0] : null;
		a.units = [{
			kind: n ?? "land",
			location: t.city
		}, {
			kind: n ?? "sea",
			location: t.city
		}];
		for (let [e, n] of a.units.entries()) o.push({
			kind: "concordiaRecruit",
			rid: a.rid,
			data: {
				unit: e,
				city: t.city,
				kind: n.kind
			}
		});
		K(i, {
			rid: a.rid,
			kind: "start",
			target: t.city
		}), i.startQueue.shift(), i.turnNo++, i.startQueue.length ? i.turn = i.startQueue[0] : (i.turn = i.marker, i.phase = "play");
	} else if (t.type === "recommend") {
		if (i.phase !== "legatus" || t.card !== null && !G(i, B(i, a.rid)).hand.includes(t.card)) return W();
		i.recommendation = t.card, i.turn = B(i, a.rid), i.followers = [a.rid], i.phase = "partner", i.singlePlay = !1, i.turnNo++;
	} else if (t.type === "choose") {
		let e = i.card && P[i.card];
		if (i.phase !== "choice" || !e || !e.choice || ![e.role, e.choice].includes(t.role)) return W();
		for (let n of i.followers ?? []) i.queue.push({
			rid: n,
			id: e.id,
			role: t.role === e.role ? e.choice : e.role
		});
		i.followers = [], i.effectiveRole = t.role, K(i, {
			rid: a.rid,
			kind: "choose",
			target: t.role
		}), Ge(i, t.role, e.id, o);
	} else if (t.type === "play") {
		if (!["play", "partner"].includes(i.phase) || !a.hand.includes(t.card) || !P[t.card] || i.phase === "partner" && i.singlePlay && P[t.card].role === "legatus") return W();
		i.mode && i.mode !== "classic" && (i.repeatIndex = a.discard.length - 1, i.phase === "play" && (i.queue = [], i.followers = i.teams ? [B(i, a.rid)] : []), i.topInstances[a.rid] = (i.topInstances[a.rid] ?? 0) + 1, i.recommendation = null), a.hand.splice(a.hand.indexOf(t.card), 1), a.discard.push(t.card), i.card = t.card, K(i, {
			rid: a.rid,
			kind: "play",
			target: t.card
		}), o.push({
			kind: "concordiaPlay",
			rid: a.rid,
			data: { card: t.card }
		}), i.mode && i.mode !== "classic" ? Ke(i, t.card, o) : Ge(i, P[t.card].role, t.card, o);
	} else if (t.type === "copy") {
		let e = i.players.find((e) => e.rid === t.rid), n = e?.discard.at(-1);
		if (i.phase !== "copy" || !e || !n || !Ve(i, e)) return W();
		if (i.teams) {
			let t = [a.rid, B(i, a.rid)].sort().join("|"), n = `${e.rid}:${i.topInstances[e.rid]}`;
			if (i.copied[t]?.includes(n)) return W();
			(i.copied[t] ??= []).push(n);
		}
		i.card = n, i.mode && i.mode !== "classic" ? Ke(i, n, o) : Ge(i, P[n].role, n, o);
	} else if (t.type === "move") {
		if (i.phase !== "move") return W();
		let e = me(i, a.rid, t.unit, i.movement)[t.road];
		if (e === void 0) return W();
		let n = a.units[t.unit].location;
		a.units[t.unit].location = t.road, i.movement -= e, K(i, {
			rid: a.rid,
			kind: "move",
			target: t.road,
			n: e
		}), o.push({
			kind: "concordiaMove",
			rid: a.rid,
			data: {
				unit: t.unit,
				from: n,
				to: t.road
			}
		});
	} else if (t.type === "build") {
		if (i.phase !== "build" || !ve(i, a.rid).includes(t.city)) return W();
		let e = V(i, t.city);
		Ne(a, e.goods), ze(i, a, e.cash), a.houses.push(t.city), K(i, {
			rid: a.rid,
			kind: "build",
			target: t.city,
			n: e.cash
		}), o.push({
			kind: "concordiaBuild",
			rid: a.rid,
			data: { city: t.city }
		}), a.houses.length === 15 && Le(i, a.rid);
	} else if (t.type === "produce") {
		if (i.phase !== "prefect" || !i.activeProvinces[t.province]) return W();
		i.activeProvinces[t.province] = !1, i.gains = i.players.map((e) => {
			let n = A();
			for (let r of I[i.map].cities.filter((n) => n.province === t.province && e.houses.includes(n.id))) n[i.cityGoods[r.id]]++;
			return e.rid === a.rid && (n[i.bonuses[t.province]] += i.magnus === a.rid ? 2 : 1), {
				rid: e.rid,
				goods: n,
				source: `cc:province:${t.province}`
			};
		}).filter((e) => R(e.goods) > 0), i.magnus === a.rid && (i.magnus = i.players[(i.players.findIndex((e) => e.rid === a.rid) + i.players.length - 1) % i.players.length].rid), K(i, {
			rid: a.rid,
			kind: "produce",
			target: String(t.province)
		}), o.push({
			kind: "concordiaProvince",
			data: { province: t.province }
		}), Ue(i, o);
	} else if (t.type === "cash") {
		if (i.phase !== "prefect" && i.phase !== "colonist" || i.phase === "colonist" && i.recruited > 0) return W();
		let e = i.phase === "colonist" ? 5 + a.units.length : i.bonuses.reduce((e, t, n) => e + (i.activeProvinces[n] ? 0 : re[t]), 0);
		i.phase === "prefect" && i.activeProvinces.fill(!0), a.cash += e, K(i, {
			rid: a.rid,
			kind: "cash",
			n: e
		}), o.push({
			kind: "concordiaCash",
			rid: a.rid,
			data: { n: e }
		}), He(i, o);
	} else if (t.type === "trade") {
		if (i.phase !== "trade" || !i.traded.includes(t.good) && i.traded.length >= 2 || t.amount > 0 && (z(a) < t.amount || ge(i, a.rid) < j[t.good] * t.amount) || a.goods[t.good] + t.amount < 0) return W();
		a.goods[t.good] += t.amount, ze(i, a, j[t.good] * t.amount), i.traded.includes(t.good) || i.traded.push(t.good), K(i, {
			rid: a.rid,
			kind: "trade",
			good: t.good,
			n: t.amount
		}), o.push({
			kind: "concordiaTrade",
			rid: a.rid,
			data: {
				good: t.good,
				n: t.amount
			}
		});
	} else if (t.type === "buy") {
		let e = i.market[t.slot];
		if (i.phase !== "buy" || i.purchases < 1 || !e || i.proconsulPurchase && P[e].role === "proconsul") return W();
		let n = ye(e, t.slot, i.freePurchase ?? P[i.card].role === "consul", t.payment);
		if (!n || !H(a.goods, n)) return W();
		Ne(a, n), a.hand.push(e), a.bought.push(e), i.market[t.slot] = null, i.purchases--, K(i, {
			rid: a.rid,
			kind: "buy",
			target: e,
			n: t.slot
		}), o.push({
			kind: "concordiaBuy",
			rid: a.rid,
			data: {
				card: e,
				slot: t.slot
			}
		}), i.deck.length === 0 && i.market.every((e) => e === null) && Le(i, a.rid), (i.purchases === 0 || i.market.every((e) => e === null)) && He(i, o);
	} else if (t.type === "recruit") {
		if (i.phase !== "colonist" && i.phase !== "tribune" || i.phase === "tribune" && (i.recruited > 0 || t.city !== L(i.map)) || ![L(i.map), ...a.houses].includes(t.city) || a.units.filter((e) => e.kind === t.kind).length >= 3 || a.goods.food < 1 || a.goods.tool < 1 || !I[i.map].cities.some((e) => e.id === t.city)) return W();
		a.goods.food--, a.goods.tool--, a.units.push({
			kind: t.kind,
			location: t.city
		}), i.recruited++, K(i, {
			rid: a.rid,
			kind: "recruit",
			target: t.city
		}), o.push({
			kind: "concordiaRecruit",
			rid: a.rid,
			data: {
				unit: a.units.length - 1,
				city: t.city,
				kind: t.kind
			}
		});
	} else if (t.type === "receive") {
		if (i.phase !== "receive" || !i.gains.length) return W();
		let e = i.gains[0], n = G(i, e.rid), r = z(n);
		if (R(t.goods) !== Math.min(r, R(e.goods)) || !H(e.goods, t.goods)) return W();
		for (let e of k) n.goods[e] += t.goods[e];
		K(i, {
			rid: n.rid,
			kind: "receive",
			n: R(t.goods)
		}), o.push({
			kind: "concordiaGain",
			rid: n.rid,
			data: {
				goods: t.goods,
				source: e.source
			}
		}), i.gains.shift(), Ue(i, o);
	} else if (t.type === "finish") {
		if (i.phase === "move") i.phase = "build";
		else if ([
			"build",
			"trade",
			"buy",
			"colonist",
			"tribune",
			"copy"
		].includes(i.phase)) K(i, {
			rid: a.rid,
			kind: "finish"
		}), He(i, o);
		else return W();
	}
	return {
		state: i,
		fx: o
	};
}
function Ye(e, t) {
	let n = e.players.find((e) => e.rid === t), r = e.phase === "receive" ? e.gains[0] : null;
	return {
		public: {
			map: e.map,
			mode: e.mode,
			teams: e.teams,
			copyTargets: e.phase === "copy" ? e.players.filter((t) => Ve(e, t)).map((e) => e.rid) : [],
			freePurchase: e.freePurchase,
			proconsulPurchase: e.proconsulPurchase,
			singlePlay: e.singlePlay,
			players: e.players.map(({ hand: e, discard: t, ...n }) => ({
				...n,
				handCount: e.length,
				discardCount: t.length,
				top: t.at(-1) ?? null
			})),
			turn: e.marker ?? e.turn,
			actor: r?.rid ?? e.turn,
			phase: e.phase,
			turnNo: e.turnNo,
			cityGoods: { ...e.cityGoods },
			activeProvinces: [...e.activeProvinces],
			bonuses: [...e.bonuses],
			magnus: e.magnus,
			market: [...e.market],
			deckCount: e.deck.length,
			card: e.card,
			movement: e.movement,
			purchases: e.purchases,
			traded: [...e.traded],
			recruited: e.recruited,
			pending: r ? {
				...r,
				space: z(G(e, r.rid))
			} : null,
			endBy: e.endBy,
			log: e.log.slice(-80),
			scores: e.scores,
			intermediateEnabled: e.intermediateEnabled,
			intermediateAwarded: e.intermediateAwarded
		},
		...n ? { private: {
			hand: [...n.hand],
			discard: [...n.discard],
			...e.phase === "legatus" && e.turn === t ? { partnerHand: [...G(e, B(e, t)).hand] } : {},
			...e.phase === "partner" && e.turn === t ? { recommendation: e.recommendation ?? null } : {}
		} } : {}
	};
}
var Xe = {
	meta: be,
	saveCompatibility: { version: "1" },
	schemas: {
		action: Te,
		publicView: je,
		privateView: Me,
		config: we
	},
	setup: qe,
	reduce: Je,
	viewFor: Ye,
	status: (e) => {
		if (e.phase !== "done") return { phase: e.phase };
		let t = e.players.map((e) => e.rid), n = t.indexOf(e.magnus), r = [...t.slice(0, n + 1).reverse(), ...t.slice(n + 1).reverse()];
		if (e.teams) {
			let n = (t) => e.scores[t].total + e.scores[e.teams[t]].total, i = t.filter((e, n) => n < t.length / 2).sort((t, i) => n(i) - n(t) || Math.min(r.indexOf(t), r.indexOf(e.teams[t])) - Math.min(r.indexOf(i), r.indexOf(e.teams[i])));
			return {
				phase: "done",
				ranking: i.flatMap((t) => [t, e.teams[t]]),
				winner: [i[0], e.teams[i[0]]],
				scores: Object.fromEntries(t.map((t) => [t, e.scores[t].total]))
			};
		}
		let i = t.sort((t, n) => e.scores[n].total - e.scores[t].total || r.indexOf(t) - r.indexOf(n));
		return {
			phase: "done",
			ranking: i,
			winner: [i[0]],
			scores: Object.fromEntries(i.map((t) => [t, e.scores[t].total]))
		};
	}
}, q = (e) => `games.concordia.${e}`;
function J({ good: e, className: t, style: n }) {
	return /* @__PURE__ */ h("img", {
		src: p(`games/concordia/${e}.svg`),
		className: t ?? "cc-good",
		style: n,
		alt: "",
		draggable: !1
	});
}
function Ze({ className: e }) {
	return /* @__PURE__ */ g("svg", {
		viewBox: "0 0 140 110",
		className: e,
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ h("path", {
				d: "M8 33 70 4l62 29v10H8z",
				fill: "#d4bb7c",
				stroke: "#695536",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ h("path", {
				d: "m25 30 45-20 45 20z",
				fill: "#8f7652"
			}),
			/* @__PURE__ */ h("path", {
				d: "M8 99h124v7H8zM15 90h110v9H15z",
				fill: "#b79b64",
				stroke: "#695536",
				strokeWidth: "2"
			}),
			[
				25,
				51,
				77,
				103
			].map((e) => /* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("path", {
				d: `M${e - 5} 44h18v7h-18zM${e - 2} 51h12v35h-12zM${e - 5} 85h18v7h-18z`,
				fill: "#f0e0b6",
				stroke: "#8f7652",
				strokeWidth: "2"
			}), /* @__PURE__ */ h("path", {
				d: `M${e + 2} 54v28`,
				stroke: "#b59a66",
				strokeWidth: "3"
			})] }, e)),
			/* @__PURE__ */ h("path", {
				d: "M10 38h120",
				stroke: "#f7e9c1",
				strokeWidth: "3"
			})
		]
	});
}
function Y({ kind: e, color: t = "#376c79", size: n = 30 }) {
	return /* @__PURE__ */ h("svg", {
		width: n,
		height: n,
		viewBox: "0 0 40 40",
		"aria-hidden": !0,
		children: e === "land" ? /* @__PURE__ */ g("g", {
			fill: t,
			stroke: "#352d24",
			strokeWidth: "1.5",
			children: [/* @__PURE__ */ h("circle", {
				cx: "20",
				cy: "7",
				r: "5"
			}), /* @__PURE__ */ h("path", { d: "M14 14h12l6 12-6 2-2-6v14h-7V22l-3 6-6-2z" })]
		}) : /* @__PURE__ */ g("g", {
			stroke: "#352d24",
			strokeWidth: "1.5",
			children: [/* @__PURE__ */ h("path", {
				d: "M4 28h32l-7 9H12z",
				fill: t
			}), /* @__PURE__ */ h("path", {
				d: "M20 4v24M18 5 6 24h12zM23 8l10 16H23z",
				fill: "#f5e7bb"
			})]
		})
	});
}
function Qe({ color: e = "#b35b42", size: t = 26 }) {
	return /* @__PURE__ */ g("svg", {
		width: t,
		height: t,
		viewBox: "0 0 32 32",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ h("path", {
			d: "m3 13 13-10 13 10-3 3v13H6V16z",
			fill: e,
			stroke: "#44382b",
			strokeWidth: "1.8"
		}), /* @__PURE__ */ h("path", {
			d: "M13 29V18h7v11M3 13h26",
			fill: "#f0dfb9",
			stroke: "#44382b",
			strokeWidth: "1.5"
		})]
	});
}
function $e({ role: e }) {
	let t = e === "mason" ? "brick" : e === "farmer" ? "food" : e === "smith" ? "tool" : e === "vintner" ? "wine" : e === "weaver" ? "cloth" : null;
	return /* @__PURE__ */ h("div", {
		className: "cc-card-relief",
		children: t ? /* @__PURE__ */ h(J, { good: t }) : e === "colonist" ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(Y, {
			kind: "land",
			size: 42
		}), /* @__PURE__ */ h(Y, {
			kind: "sea",
			size: 42
		})] }) : e === "architect" ? /* @__PURE__ */ g("svg", {
			viewBox: "0 0 140 100",
			"aria-hidden": !0,
			children: [
				/* @__PURE__ */ h("path", {
					d: "M24 83 63 13h10l42 70-9 5-37-62-35 62z",
					fill: "#9b967c",
					stroke: "#4b514c",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ h("path", {
					d: "m36 58 57-22M50 71l38-46",
					stroke: "#a9794e",
					strokeWidth: "9"
				}),
				/* @__PURE__ */ h("circle", {
					cx: "68",
					cy: "20",
					r: "9",
					fill: "#d3b96e",
					stroke: "#594936",
					strokeWidth: "3"
				})
			]
		}) : /* @__PURE__ */ h(Ze, {})
	});
}
function et() {
	return /* @__PURE__ */ g("div", {
		className: "cc-card-back",
		children: [/* @__PURE__ */ h(Ze, {}), /* @__PURE__ */ h("strong", { children: "CONCORDIA" })]
	});
}
function X({ id: e, onClick: t, disabled: n = !1, selected: r = !1, anchor: i, small: s = !1, back: c = !1, team: l = e.startsWith("t-") }) {
	let u = a(), d = P[e], { ref: f, hidden: p } = o(i ?? null);
	if (!d) return null;
	let _ = d.choice ? "cardDual" : [
		"mason",
		"farmer",
		"smith",
		"vintner",
		"weaver"
	].includes(d.role) ? "cardSpecialist" : `card${d.role[0].toUpperCase()}${d.role.slice(1)}`;
	return /* @__PURE__ */ h("button", {
		type: "button",
		ref: f,
		className: `cc-personality ${s ? "cc-small" : ""} ${r ? "cc-selected" : ""}`,
		onClick: t,
		disabled: n,
		style: { visibility: p ? "hidden" : void 0 },
		"aria-label": `${u(q(d.role))}${d.choice ? ` / ${u(q(d.choice))}` : ""} · ${(d.gods ?? [d.god]).map((e) => u(q(e))).join(" · ")}`,
		title: u(q(_), {
			first: u(q(d.role)),
			second: d.choice ? u(q(d.choice)) : ""
		}),
		children: c ? /* @__PURE__ */ h(et, {}) : /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ g("header", { children: [u(q(d.role)), d.choice && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("span", {
				className: "cc-choice-divider",
				children: " / "
			}), u(q(d.choice))] })] }),
			/* @__PURE__ */ h($e, { role: d.role }),
			/* @__PURE__ */ h("span", {
				className: "cc-card-detail",
				children: u(q(_), {
					first: u(q(d.role)),
					second: d.choice ? u(q(d.choice)) : ""
				})
			}),
			/* @__PURE__ */ h("span", {
				className: "cc-card-cost",
				children: d.cost.map((e, t) => /* @__PURE__ */ h(J, { good: e }, t))
			}),
			/* @__PURE__ */ g("footer", {
				className: d.god === "venus" ? "cc-venus-band" : d.gods ? "cc-three-gods" : void 0,
				children: [/* @__PURE__ */ h("span", { children: d.points ?? (d.god === "mars" || d.god === "mercurius" ? 2 : d.god === "venus" ? l ? 1 : 2 : 1) }), (d.gods ?? [d.god]).map((e) => /* @__PURE__ */ h("span", {
					className: "cc-god-name",
					children: u(q(e))
				}, e))]
			})
		] })
	});
}
//#endregion
//#region src/games/concordia/board.tsx
var tt = [
	"I",
	"II",
	"III",
	"IV",
	"V",
	"VI",
	"VII",
	"VIII",
	"IX",
	"X",
	"XI",
	"XII"
];
function nt({ path: e }) {
	return /* @__PURE__ */ h("path", {
		d: e,
		fill: "none",
		stroke: "#fff6d9",
		strokeWidth: "9",
		strokeDasharray: "14 10",
		children: /* @__PURE__ */ h("animate", {
			attributeName: "stroke-dashoffset",
			from: "0",
			to: "-24",
			dur: "0.7s",
			repeatCount: "indefinite"
		})
	});
}
function rt({ name: e, size: t }) {
	let r = s(), i = n((t) => {
		r?.registerProbe(e, t ? () => {
			let e = t.getBoundingClientRect();
			return {
				x: e.left,
				y: e.top,
				w: e.width,
				h: e.height
			};
		} : null);
	}, [r, e]);
	return /* @__PURE__ */ h("rect", {
		ref: i,
		width: t,
		height: t,
		fill: "none",
		pointerEvents: "none"
	});
}
function it({ name: e, color: t, x: n, y: r, anchor: i }) {
	let a = o(i);
	return /* @__PURE__ */ g("g", {
		transform: `translate(${n} ${r})`,
		visibility: a.hidden ? "hidden" : void 0,
		children: [
			/* @__PURE__ */ h("title", { children: e }),
			/* @__PURE__ */ h(Qe, {
				color: t,
				size: 26
			}),
			/* @__PURE__ */ h(rt, {
				name: i,
				size: 26
			})
		]
	});
}
function at({ kind: e, color: t, x: n, y: r, anchor: i, label: a, selected: s }) {
	let c = o(i);
	return /* @__PURE__ */ g("g", {
		transform: `translate(${n - 19} ${r - 19})`,
		visibility: c.hidden ? "hidden" : void 0,
		children: [
			/* @__PURE__ */ h("title", { children: a }),
			s && /* @__PURE__ */ h("circle", {
				cx: "19",
				cy: "19",
				r: "25",
				fill: "#ead197",
				stroke: "#775520",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ h(Y, {
				kind: e,
				color: t,
				size: 38
			}),
			/* @__PURE__ */ h(rt, {
				name: i,
				size: 38
			})
		]
	});
}
function ot({ v: e, members: t, myRid: n, send: r, onInspect: o, recruitKind: s }) {
	let c = a(), u = I[e.map], d = u.frame ?? {
		x: 100,
		y: 310,
		w: 1600,
		h: 860
	}, [f, m] = i(null), [v, y] = i(0), b = e.players.find((e) => e.rid === n), x = e.actor === n && e.phase !== "done", S = f?.turn === e.turnNo ? f.unit : null, C = x && b && b.goods.food > 0 && b.goods.tool > 0 && b.units.filter((e) => e.kind === s).length < 3 && (e.phase === "colonist" || e.phase === "tribune" && e.recruited === 0), w = x && e.phase === "move" && S !== null ? me(e, n, S, e.movement) : {}, T = x && e.phase === "build" ? ve(e, n) : [], E = C ? e.phase === "tribune" ? [L(e.map)] : [L(e.map), ...b.houses] : [], D = x && e.phase === "start" ? _e(e.map) : [], O = (e) => l[(t.find((t) => t.rid === e)?.colorIndex ?? 0) % l.length].hex, te = (e) => t.find((t) => t.rid === e)?.name ?? e, k = e.players.flatMap((e, t) => e.units.map((n, r) => {
		let i = u.roads.find((e) => e.id === n.location), a = u.cities.find((e) => e.id === n.location);
		return {
			p: e,
			u: n,
			i: r,
			...i ? fe(u, i) : {
				x: a.x - 65 + t * 29,
				y: a.y + 50 + (n.kind === "sea" ? 32 : 0)
			}
		};
	})), A = [
		...k.filter(({ p: t }) => x && e.phase === "move" && t.rid === n).map(({ i: e, x: t, y: n }) => ({
			key: `u:${e}`,
			rect: {
				x: t - 19 - d.x,
				y: n - 19 - d.y,
				w: 38,
				h: 38
			}
		})),
		...Object.keys(w).map((e) => {
			let t = fe(u, u.roads.find((t) => t.id === e));
			return {
				key: `r:${e}`,
				rect: {
					x: t.x - 24 - d.x,
					y: t.y - 24 - d.y,
					w: 48,
					h: 48
				}
			};
		}),
		...u.cities.map((e) => ({
			key: `c:${e.id}`,
			rect: {
				x: e.x - 32 - d.x,
				y: e.y - 30 - d.y,
				w: 64,
				h: 60
			}
		}))
	], j = (t) => {
		let [n, i] = t.split(":");
		n === "u" ? m({
			turn: e.turnNo,
			unit: Number(i)
		}) : n === "r" && S !== null ? r({
			type: "move",
			unit: S,
			road: i
		}) : D.includes(i) ? r({
			type: "startCity",
			city: i
		}) : T.includes(i) ? r({
			type: "build",
			city: i
		}) : E.includes(i) ? r({
			type: "recruit",
			city: i,
			kind: s
		}) : o(i);
	};
	return /* @__PURE__ */ g("div", {
		className: "cc-map",
		children: [/* @__PURE__ */ h(ee, {
			image: p(`games/concordia/${e.map}.svg`),
			sheetW: d.w,
			sheetH: d.h,
			eligible: A,
			onTapEligible: j,
			fitKey: `${e.map}:${v}`,
			clampToSheet: !0,
			highlight: "off",
			children: /* @__PURE__ */ g("g", {
				transform: `translate(${-d.x} ${-d.y})`,
				children: [
					/* @__PURE__ */ h("g", {
						opacity: "0.65",
						children: u.provinces.map((e, t) => {
							let n = u.cities.filter((e) => e.province === t), r = n.reduce((e, t) => e + t.x, 0) / n.length, i = n.reduce((e, t) => e + t.y, 0) / n.length;
							return /* @__PURE__ */ g("text", {
								x: r,
								y: i - 63,
								textAnchor: "middle",
								className: "cc-province-name",
								children: [e === tt[t] ? e : `${tt[t]} · ${e.toUpperCase()}`, " "]
							}, e);
						})
					}),
					u.roads.map((e) => /* @__PURE__ */ g("g", { children: [
						/* @__PURE__ */ h("path", {
							d: pe(u, e),
							fill: "none",
							stroke: "#f9e6b8",
							strokeWidth: "9"
						}),
						/* @__PURE__ */ h("path", {
							d: pe(u, e),
							fill: "none",
							stroke: e.kind === "sea" ? "#367f9e" : "#87684b",
							strokeWidth: "5",
							strokeDasharray: e.kind === "sea" ? "11 5" : void 0
						}),
						w[e.id] !== void 0 && /* @__PURE__ */ h(nt, { path: pe(u, e) }),
						/* @__PURE__ */ h(_, {
							name: `cc:location:${e.id}`,
							r: {
								x: fe(u, e).x - 16,
								y: fe(u, e).y - 16,
								w: 32,
								h: 32
							}
						})
					] }, e.id)),
					u.cities.map((t) => {
						let n = T.includes(t.id) || E.includes(t.id) || D.includes(t.id), r = b && e.phase === "build" && he(e.map, b.units, !!e.teams).includes(t.id);
						return /* @__PURE__ */ g("g", {
							role: "button",
							tabIndex: 0,
							"aria-label": `${t.name}${e.cityGoods[t.id] ? ` · ${c(`games.concordia.${e.cityGoods[t.id]}`)}` : ""}`,
							onKeyDown: (e) => {
								(e.key === "Enter" || e.key === " ") && (e.preventDefault(), j(`c:${t.id}`));
							},
							children: [
								/* @__PURE__ */ h("title", { children: t.name }),
								/* @__PURE__ */ h("path", {
									d: `M${t.x - 30} ${t.y + 20}v-34Q${t.x} ${t.y - 54} ${t.x + 30} ${t.y - 14}v34Z`,
									fill: t.province === -1 ? "#e6c77f" : "#f4e3bb",
									stroke: n ? "#79571f" : r ? "#b69954" : "#796b53",
									strokeWidth: "3"
								}),
								n && /* @__PURE__ */ h("path", {
									d: `M${t.x - 35} ${t.y + 25}v-39Q${t.x} ${t.y - 62} ${t.x + 35} ${t.y - 14}v39Z`,
									fill: "none",
									stroke: "#fff",
									strokeWidth: "5",
									strokeDasharray: "10 7",
									children: /* @__PURE__ */ h("animate", {
										attributeName: "stroke-dashoffset",
										from: "0",
										to: "-17",
										dur: "0.7s",
										repeatCount: "indefinite"
									})
								}),
								e.cityGoods[t.id] ? /* @__PURE__ */ h("image", {
									href: p(`games/concordia/${e.cityGoods[t.id]}.svg`),
									x: t.x - 22,
									y: t.y - 25,
									width: "44",
									height: "40"
								}) : /* @__PURE__ */ h("text", {
									x: t.x,
									y: t.y + 5,
									textAnchor: "middle",
									fontSize: "25",
									fill: "#5b4a2c",
									children: "SPQR"
								}),
								/* @__PURE__ */ h("rect", {
									x: t.x - 47,
									y: t.y + 20,
									width: "94",
									height: "21",
									rx: "3",
									fill: "#fbf0d2"
								}),
								/* @__PURE__ */ h("text", {
									x: t.x,
									y: t.y + 35,
									textAnchor: "middle",
									fontSize: t.name.length > 10 ? 12 : 15,
									fontWeight: "700",
									fill: "#493a27",
									children: t.name
								}),
								/* @__PURE__ */ h(_, {
									name: `cc:location:${t.id}`,
									r: {
										x: t.x - 24,
										y: t.y - 24,
										w: 48,
										h: 48
									}
								}),
								e.players.filter((e) => e.houses.includes(t.id)).map((e, n) => /* @__PURE__ */ h(it, {
									name: te(e.rid),
									color: O(e.rid),
									x: t.x - 30 + n * 24,
									y: t.y - 57,
									anchor: `cc:house:${e.rid}:${t.id}`
								}, e.rid))
							]
						}, t.id);
					}),
					k.map(({ p: t, u: r, i, x: a, y: o }) => /* @__PURE__ */ h(at, {
						kind: r.kind,
						color: O(t.rid),
						x: a,
						y: o,
						label: `${te(t.rid)} · ${c(r.kind === "land" ? "games.concordia.land" : "games.concordia.sea")}`,
						anchor: `cc:unit:${t.rid}:${i}`,
						selected: t.rid === n && S === i && e.phase === "move"
					}, `${t.rid}:${i}`))
				]
			})
		}), /* @__PURE__ */ h("button", {
			type: "button",
			className: "cc-map-reset",
			onClick: () => y((e) => e + 1),
			children: c("games.concordia.resetMap")
		})]
	});
}
//#endregion
//#region src/games/concordia/view-player.tsx
var st = (e) => e[0].toUpperCase() + e.slice(1);
function Z({ name: e, className: t, children: n }) {
	let { ref: r, hidden: i } = o(e);
	return /* @__PURE__ */ h("div", {
		ref: r,
		className: t,
		style: { visibility: i ? "hidden" : void 0 },
		children: n
	});
}
function ct({ p: e, name: t, color: n, selected: r, active: i, magnus: s, marker: c, onPick: l, onCopy: u }) {
	let d = a(), { ref: f } = o(`cc:seat:${e.rid}`), { ref: p } = o(`cc:top:${e.rid}`), { ref: m, hidden: _ } = o(`cc:top-card:${e.rid}`);
	return /* @__PURE__ */ g("div", {
		ref: f,
		className: `cc-seat ${i ? "cc-active" : ""} ${r ? "cc-picked" : ""}`,
		style: { borderTopColor: n },
		children: [/* @__PURE__ */ g("button", {
			type: "button",
			onClick: l,
			className: "cc-seat-pick",
			children: [/* @__PURE__ */ g("strong", { children: [c && /* @__PURE__ */ h("span", {
				className: "cc-turn-marker",
				title: d("games.concordia.turnMarker"),
				"aria-label": d("games.concordia.turnMarker"),
				children: "● "
			}), t] }), /* @__PURE__ */ g("span", {
				className: "cc-seat-stats",
				children: [
					/* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h(Qe, {
						color: n,
						size: 19
					}), e.houses.length] }),
					/* @__PURE__ */ g("span", { children: [e.cash, " ◉"] }),
					/* @__PURE__ */ g("span", { children: [e.units.length, "/6"] }),
					s && /* @__PURE__ */ h("abbr", {
						title: d("games.concordia.magnus"),
						children: "M"
					})
				]
			})]
		}), /* @__PURE__ */ g("button", {
			type: "button",
			ref: p,
			className: `cc-top ${u ? "cc-legal" : ""}`,
			disabled: !u,
			onClick: u,
			title: d("games.concordia.discard"),
			children: [/* @__PURE__ */ h("span", {
				ref: m,
				style: { visibility: _ ? "hidden" : void 0 },
				children: e.top ? d(q(P[e.top].role)) : "—"
			}), /* @__PURE__ */ g("small", { children: [
				e.handCount,
				" / ",
				e.handCount + e.discardCount
			] })]
		})]
	});
}
function lt(e) {
	let t = e.public, n = e.private, r = a(), [o, s] = i(e.myRid), [p, _] = i(null), [ee, v] = i({
		stamp: -1,
		goods: A()
	}), [y, b] = i("land"), x = t.actor === e.myRid && t.phase !== "done", S = t.players.find((t) => t.rid === e.myRid), C = t.players.find((e) => e.rid === o) ?? S ?? t.players[0], w = I[t.map], T = p?.stamp === t.turnNo ? p : null, E = ee.stamp === t.turnNo ? ee.goods : A(), D = (t) => e.members.find((e) => e.rid === t)?.name ?? t, O = (t) => {
		x && e.send(t);
	}, te = t.freePurchase ?? (t.card !== null && P[t.card].role === "consul"), ne = (e, t, n) => ye(e, t, te, n), ie = (e, n) => S && (!t.proconsulPurchase || P[e].role !== "proconsul") && k.some((t) => H(S.goods, ne(e, n, t))), M = (e) => {
		let n = t.market[e];
		x && t.phase === "buy" && n && (!te && ue[e].includes("any") ? _({
			kind: "payment",
			id: String(e),
			stamp: t.turnNo
		}) : O({
			type: "buy",
			slot: e
		}));
	}, ae = (e) => {
		let t = e.target ?? "";
		return t = e.kind === "choose" ? r(q(t)) : e.kind === "play" || e.kind === "buy" ? r(q(P[t]?.role ?? "cards")) : e.kind === "produce" ? w.provinces[Number(t)] ?? t : e.kind === "trade" ? r(q(e.good ?? "brick")) : w.cities.find((e) => e.id === t)?.name ?? t, r(q(`log${st(e.kind)}`), {
			name: D(e.rid),
			target: t,
			n: e.n ?? 0
		});
	}, oe = t.phase === "partner" && n?.recommendation ? n.recommendation : null, N = r(q(`phase${st(t.phase)}`)), se = t.phase === "colonist" ? (S?.units.length ?? 0) + 5 : t.bonuses.reduce((e, n, r) => e + (t.activeProvinces[r] ? 0 : re[n]), 0), ce = x && S && (t.phase === "colonist" || t.phase === "tribune" && t.recruited === 0) && S.goods.food > 0 && S.goods.tool > 0, le = /* @__PURE__ */ g("div", {
		className: "cc-toolbar",
		children: [
			/* @__PURE__ */ h("div", {
				className: "cc-step",
				children: oe ? r("games.concordia.recommended", { card: r(q(P[oe].role)) }) : t.phase === "move" ? r("games.concordia.moves", { n: t.movement }) : t.phase === "buy" ? r("games.concordia.purchases", { n: t.purchases }) : t.endBy ? r("games.concordia.finalTurns") : ""
			}),
			ce && /* @__PURE__ */ g("div", {
				className: "cc-recruit",
				children: [
					["land", "sea"].map((e) => /* @__PURE__ */ h("button", {
						type: "button",
						className: y === e ? "cc-selected" : "",
						disabled: S.units.filter((t) => t.kind === e).length >= 3,
						onClick: () => b(e),
						"aria-label": r(q(e)),
						children: /* @__PURE__ */ h(Y, { kind: e })
					}, e)),
					/* @__PURE__ */ h(J, { good: "food" }),
					/* @__PURE__ */ h(J, { good: "tool" })
				]
			}),
			x && (t.phase === "prefect" || t.phase === "colonist" && t.recruited === 0) && /* @__PURE__ */ h("button", {
				type: "button",
				className: "cc-primary",
				onClick: () => O({ type: "cash" }),
				children: r("games.concordia.cash", { n: se })
			}),
			x && [
				"move",
				"build",
				"trade",
				"buy",
				"colonist",
				"tribune",
				"copy"
			].includes(t.phase) && /* @__PURE__ */ h("button", {
				type: "button",
				className: "cc-primary",
				onClick: () => O({ type: "finish" }),
				children: r(t.phase === "move" ? "games.concordia.finishMove" : "games.concordia.finish")
			})
		]
	}), de = /* @__PURE__ */ g(Z, {
		name: `cc:warehouse:${C.rid}`,
		className: "cc-warehouse",
		children: [
			/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ h("strong", { children: D(C.rid) }), /* @__PURE__ */ h("span", { children: r("games.concordia.storage", { n: 12 - z(C) }) })] }),
			/* @__PURE__ */ h("div", {
				className: "cc-goods",
				children: k.map((n) => /* @__PURE__ */ h(Z, {
					name: `cc:good:${C.rid}:${n}`,
					children: /* @__PURE__ */ g("button", {
						type: "button",
						className: `cc-cargo ${x && t.phase === "trade" && C.rid === e.myRid ? "cc-legal" : ""}`,
						onClick: () => x && t.phase === "trade" && C.rid === e.myRid && _({
							kind: "trade",
							id: n,
							stamp: t.turnNo
						}),
						disabled: !x || t.phase !== "trade" || C.rid !== e.myRid,
						"aria-label": `${r(q(n))}: ${C.goods[n]}`,
						children: [
							/* @__PURE__ */ h(J, { good: n }),
							/* @__PURE__ */ h("strong", { children: C.goods[n] }),
							/* @__PURE__ */ g("small", { children: [j[n], " ◉"] })
						]
					})
				}, n))
			}),
			/* @__PURE__ */ g("div", {
				className: "cc-storage-tokens",
				children: [
					Array.from({ length: 3 - C.units.filter((e) => e.kind === "land").length }, (e, t) => /* @__PURE__ */ h(Y, { kind: "land" }, `l${t}`)),
					Array.from({ length: 3 - C.units.filter((e) => e.kind === "sea").length }, (e, t) => /* @__PURE__ */ h(Y, { kind: "sea" }, `s${t}`)),
					/* @__PURE__ */ h("span", { children: r("games.concordia.supply", { n: 15 - C.houses.length }) })
				]
			})
		]
	}), F = T?.kind === "city" ? w.cities.find((e) => e.id === T.id) : null, L = F ? V(t, F.id) : null, fe = x && t.phase === "choice" && t.card ? /* @__PURE__ */ h("div", {
		className: "cc-dialog-wrap",
		children: /* @__PURE__ */ g("section", {
			className: "cc-dialog",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": N,
			children: [/* @__PURE__ */ h("header", { children: /* @__PURE__ */ h("strong", { children: N }) }), /* @__PURE__ */ h("div", {
				className: "cc-action-choices",
				children: [P[t.card].role, P[t.card].choice].map((e) => /* @__PURE__ */ g("button", {
					type: "button",
					onClick: () => O({
						type: "choose",
						role: e
					}),
					children: [r(q(e)), /* @__PURE__ */ h("small", { children: r(q(`card${st(e)}`)) })]
				}, e))
			})]
		})
	}) : x && t.phase === "legatus" ? /* @__PURE__ */ h("div", {
		className: "cc-dialog-wrap",
		children: /* @__PURE__ */ g("section", {
			className: "cc-dialog",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": N,
			children: [
				/* @__PURE__ */ h("header", { children: /* @__PURE__ */ h("strong", { children: r("games.concordia.partnerHand", { name: D(B(t, e.myRid)) }) }) }),
				/* @__PURE__ */ h("div", {
					className: "cc-partner-hand",
					children: n?.partnerHand?.map((e) => /* @__PURE__ */ h(X, {
						team: !!t.teams,
						id: e,
						onClick: () => O({
							type: "recommend",
							card: e
						})
					}, e))
				}),
				/* @__PURE__ */ h("footer", { children: /* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => O({
						type: "recommend",
						card: null
					}),
					children: r("games.concordia.noRecommendation")
				}) })
			]
		})
	}) : null, pe = t.phase === "receive" && x && t.pending ? /* @__PURE__ */ h("div", {
		className: "cc-dialog-wrap",
		children: /* @__PURE__ */ g("section", {
			className: "cc-dialog",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": N,
			children: [
				/* @__PURE__ */ h("header", { children: /* @__PURE__ */ h("strong", { children: N }) }),
				/* @__PURE__ */ h("p", { children: r("games.concordia.keep", { n: t.pending.space }) }),
				/* @__PURE__ */ h("div", {
					className: "cc-choose-goods",
					children: k.filter((e) => t.pending.goods[e] > 0).map((e) => /* @__PURE__ */ g("div", { children: [
						/* @__PURE__ */ h(J, { good: e }),
						/* @__PURE__ */ h("span", { children: r(q(e)) }),
						/* @__PURE__ */ g("div", { children: [
							/* @__PURE__ */ h("button", {
								type: "button",
								"aria-label": `${r("games.concordia.cancel")} ${r(q(e))}`,
								disabled: E[e] === 0,
								onClick: () => v({
									stamp: t.turnNo,
									goods: {
										...E,
										[e]: E[e] - 1
									}
								}),
								children: "−"
							}),
							/* @__PURE__ */ g("strong", { children: [
								E[e],
								"/",
								t.pending.goods[e]
							] }),
							/* @__PURE__ */ h("button", {
								type: "button",
								"aria-label": `${r("games.concordia.receive")} ${r(q(e))}`,
								disabled: E[e] >= t.pending.goods[e] || R(E) >= t.pending.space,
								onClick: () => v({
									stamp: t.turnNo,
									goods: {
										...E,
										[e]: E[e] + 1
									}
								}),
								children: "+"
							})
						] })
					] }, e))
				}),
				/* @__PURE__ */ h("footer", { children: /* @__PURE__ */ h("button", {
					type: "button",
					className: "cc-primary",
					disabled: R(E) !== t.pending.space,
					onClick: () => {
						O({
							type: "receive",
							goods: E
						}), v({
							stamp: -1,
							goods: A()
						});
					},
					children: r("games.concordia.confirm")
				}) })
			]
		})
	}) : T ? /* @__PURE__ */ h("div", {
		className: "cc-dialog-wrap",
		onClick: () => _(null),
		children: /* @__PURE__ */ g("section", {
			className: "cc-dialog",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": F?.name ?? (T.kind === "card" ? r(q(P[T.id].role)) : r(T.kind === "payment" ? "games.concordia.choosePayment" : "games.concordia.phaseTrade")),
			onClick: (e) => e.stopPropagation(),
			onKeyDown: (e) => {
				e.key === "Escape" && _(null);
			},
			children: [/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ h("strong", { children: F?.name ?? (T.kind === "card" ? r(q(P[T.id].role)) : r(T.kind === "payment" ? "games.concordia.choosePayment" : "games.concordia.phaseTrade")) }), /* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => _(null),
				"aria-label": r("games.concordia.close"),
				children: "×"
			})] }), T.kind === "card" ? /* @__PURE__ */ g("div", {
				className: "cc-card-preview",
				children: [
					/* @__PURE__ */ h(X, {
						team: !!t.teams,
						id: T.id
					}),
					/* @__PURE__ */ h("p", { children: r(q(P[T.id].choice ? "cardDual" : [
						"mason",
						"farmer",
						"smith",
						"vintner",
						"weaver"
					].includes(P[T.id].role) ? "cardSpecialist" : `card${st(P[T.id].role)}`), {
						first: r(q(P[T.id].role)),
						second: P[T.id].choice ? r(q(P[T.id].choice)) : ""
					}) }),
					/* @__PURE__ */ h("button", {
						type: "button",
						className: "cc-primary",
						disabled: !x || !["play", "partner"].includes(t.phase) || !n?.hand.includes(T.id) || t.phase === "partner" && t.singlePlay && P[T.id].role === "legatus",
						onClick: () => {
							O({
								type: "play",
								card: T.id
							}), _(null);
						},
						children: r("games.concordia.confirm")
					})
				]
			}) : F ? /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ g("div", {
					className: "cc-city-detail",
					children: [t.cityGoods[F.id] && /* @__PURE__ */ h(J, { good: t.cityGoods[F.id] }), /* @__PURE__ */ h("span", { children: F.province >= 0 ? w.provinces[F.province] : r("games.concordia.capital") })]
				}),
				L && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("p", { children: r("games.concordia.buildCost") }), /* @__PURE__ */ g("div", {
					className: "cc-cost",
					children: [k.flatMap((e) => Array.from({ length: L.goods[e] }, (t, n) => /* @__PURE__ */ h(J, { good: e }, `${e}${n}`))), /* @__PURE__ */ g("strong", { children: [L.cash, " ◉"] })]
				})] }),
				/* @__PURE__ */ h("ul", { children: t.players.filter((e) => e.houses.includes(F.id)).map((e) => /* @__PURE__ */ h("li", { children: D(e.rid) }, e.rid)) })
			] }) : T.kind === "payment" ? /* @__PURE__ */ h("div", {
				className: "cc-payment",
				children: k.map((e) => {
					let n = Number(T.id), i = t.market[n], a = i ? ne(i, n, e) : null;
					return /* @__PURE__ */ g("button", {
						type: "button",
						disabled: !x || !S || !a || !H(S.goods, a),
						onClick: () => {
							O({
								type: "buy",
								slot: n,
								payment: e
							}), _(null);
						},
						"aria-label": r(q(e)),
						children: [/* @__PURE__ */ h(J, { good: e }), /* @__PURE__ */ h("span", { children: r(q(e)) })]
					}, e);
				})
			}) : /* @__PURE__ */ g("div", {
				className: "cc-trade-detail",
				children: [
					/* @__PURE__ */ h(J, { good: T.id }),
					/* @__PURE__ */ g("strong", { children: [
						r(q(T.id)),
						" · ",
						j[T.id],
						" ◉"
					] }),
					/* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("button", {
						type: "button",
						disabled: !x || !S || S.goods[T.id] === 0 || !t.traded.includes(T.id) && t.traded.length >= 2,
						onClick: () => O({
							type: "trade",
							good: T.id,
							amount: -1
						}),
						children: r("games.concordia.tradeSell")
					}), /* @__PURE__ */ h("button", {
						type: "button",
						disabled: !x || !S || ge(t, S.rid) < j[T.id] || z(S) < 1 || !t.traded.includes(T.id) && t.traded.length >= 2,
						onClick: () => O({
							type: "trade",
							good: T.id,
							amount: 1
						}),
						children: r("games.concordia.tradeBuy")
					})] })
				]
			})]
		})
	}) : null;
	return /* @__PURE__ */ g(u, {
		adaptive: !0,
		scroll: !1,
		className: "concordia",
		actionsHeight: "cc-bottom-height",
		banner: /* @__PURE__ */ g("div", {
			className: "cc-banner",
			children: [/* @__PURE__ */ h(d, {
				tone: x ? "accent" : t.phase === "done" ? "done" : "info",
				accent: "#376c79",
				text: x || t.phase === "done" ? N : r("games.concordia.waiting", { name: D(t.actor) }),
				chip: t.endBy ? r("games.concordia.finalTurns") : r("games.concordia.turn", { n: t.turnNo })
			}), /* @__PURE__ */ h("div", {
				className: "cc-seats",
				children: t.players.map((n) => /* @__PURE__ */ h(ct, {
					p: n,
					name: t.teams ? `${r("games.concordia.teamNumber", { n: 1 + t.players.findIndex((e) => e.rid === n.rid) % (t.players.length / 2) })} · ${D(n.rid)}` : D(n.rid),
					color: l[(e.members.find((e) => e.rid === n.rid)?.colorIndex ?? 0) % l.length].hex,
					selected: n.rid === C.rid,
					active: t.actor === n.rid && t.phase !== "done",
					magnus: t.magnus === n.rid,
					marker: !!t.teams && t.turn === n.rid,
					onPick: () => s(n.rid),
					onCopy: x && t.phase === "copy" && t.copyTargets?.includes(n.rid) ? () => O({
						type: "copy",
						rid: n.rid
					}) : void 0
				}, n.rid))
			})]
		}),
		actions: /* @__PURE__ */ g("div", {
			className: "cc-bottom",
			children: [le, /* @__PURE__ */ h(Z, {
				name: "cc:hand-area",
				className: "cc-hand",
				children: n?.hand.map((e) => /* @__PURE__ */ h(X, {
					team: !!t.teams,
					id: e,
					anchor: `cc:hand:${e}`,
					onClick: () => _({
						kind: "card",
						id: e,
						stamp: t.turnNo
					}),
					disabled: !x || !["play", "partner"].includes(t.phase) || t.phase === "partner" && t.singlePlay && P[e].role === "legatus"
				}, e))
			})]
		}),
		children: [
			/* @__PURE__ */ g("div", {
				className: "cc-table",
				children: [
					/* @__PURE__ */ h(c, {
						kind: "sheen",
						base: "#d5c39b",
						className: "absolute inset-0"
					}),
					/* @__PURE__ */ g("div", {
						className: "cc-table-main",
						children: [
							/* @__PURE__ */ g("div", {
								className: "cc-market",
								"aria-label": r("games.concordia.market"),
								children: [t.market.map((e, n) => /* @__PURE__ */ g(Z, {
									name: `cc:market:${n}`,
									className: "cc-market-slot",
									children: [e ? /* @__PURE__ */ h(X, {
										team: !!t.teams,
										id: e,
										small: !0,
										onClick: () => M(n),
										disabled: !x || t.phase !== "buy" || !ie(e, n),
										selected: x && t.phase === "buy" && !!ie(e, n)
									}) : /* @__PURE__ */ h("div", { className: "cc-market-empty" }), /* @__PURE__ */ h("span", {
										className: "cc-surcharge",
										children: ue[n].length ? ue[n].map((e, t) => e === "any" ? /* @__PURE__ */ h("span", {
											title: r("games.concordia.any"),
											children: "?"
										}, t) : /* @__PURE__ */ h(J, { good: e }, t)) : /* @__PURE__ */ h("span", { children: "—" })
									})]
								}, n)), /* @__PURE__ */ g(Z, {
									name: "cc:bank",
									className: "cc-deck",
									children: [/* @__PURE__ */ h("strong", { children: t.deckCount }), /* @__PURE__ */ h("span", { children: "CONCORDIA" })]
								})]
							}),
							/* @__PURE__ */ h("div", {
								className: "cc-provinces",
								children: w.provinces.map((e, n) => /* @__PURE__ */ h(Z, {
									name: `cc:province:${n}`,
									children: /* @__PURE__ */ g("button", {
										type: "button",
										className: `cc-province ${t.activeProvinces[n] ? "" : "cc-spent"} ${x && t.phase === "prefect" && t.activeProvinces[n] ? "cc-legal" : ""}`,
										disabled: !x || t.phase !== "prefect" || !t.activeProvinces[n],
										onClick: () => O({
											type: "produce",
											province: n
										}),
										"aria-label": `${e} · ${r(t.activeProvinces[n] ? "games.concordia.available" : "games.concordia.used")}`,
										children: [/* @__PURE__ */ h("small", { children: e }), t.activeProvinces[n] ? /* @__PURE__ */ h(J, { good: t.bonuses[n] }) : /* @__PURE__ */ g("strong", { children: [re[t.bonuses[n]], " ◉"] })]
									})
								}, e))
							}),
							/* @__PURE__ */ h(ot, {
								v: t,
								members: e.members,
								myRid: e.myRid,
								send: O,
								recruitKind: y,
								onInspect: (e) => _({
									kind: "city",
									id: e,
									stamp: t.turnNo
								})
							}),
							/* @__PURE__ */ h("div", {
								className: "cc-log",
								children: /* @__PURE__ */ h(f, {
									log: t.log,
									line: ae
								})
							})
						]
					}),
					/* @__PURE__ */ g("aside", {
						className: "cc-side",
						children: [de, /* @__PURE__ */ h("div", {
							className: "cc-discard-list",
							children: t.players.map((e) => /* @__PURE__ */ g(Z, {
								name: `cc:discard:${e.rid}`,
								className: "cc-discard-stack",
								children: [/* @__PURE__ */ g("span", { children: [
									D(e.rid),
									" · ",
									e.discardCount
								] }), e.top ? /* @__PURE__ */ h(X, {
									team: !!t.teams,
									id: e.top,
									small: !0,
									anchor: `cc:discard-card:${e.rid}`,
									onClick: () => O({
										type: "copy",
										rid: e.rid
									}),
									disabled: !x || t.phase !== "copy" || !t.copyTargets?.includes(e.rid)
								}) : /* @__PURE__ */ h("div", { className: "cc-market-empty" })]
							}, e.rid))
						})]
					})
				]
			}),
			fe,
			pe
		]
	});
}
//#endregion
//#region src/games/concordia/bot.ts
var ut = {
	expansion: 1,
	diversity: 0,
	cards: .6,
	opponent: 0,
	recruit: 0
}, dt = {
	expansion: 1,
	diversity: 2,
	cards: 1,
	opponent: .2,
	recruit: 1.2
};
function ft(e) {
	return (t, n) => {
		let r = t.public, i = r.players.find((e) => e.rid === n.rid), a = t.private?.hand ?? [], o = I[r.map];
		if (!i || r.actor !== n.rid || r.phase === "done") return null;
		let s = ge(r, n.rid), c = L(r.map), l = (e) => ({ action: e }), u = () => l({ type: "finish" }), d = (e) => j[e] * (i.goods[e] === 0 ? 1.45 : i.goods[e] > 2 ? .5 : 1), f = (t) => {
			let n = r.cityGoods[t], a = o.cities.find((e) => e.id === t).province, s = !i.houses.some((e) => o.cities.find((t) => t.id === e).province === a), c = !i.houses.some((e) => r.cityGoods[e] === n);
			return 8 * e.expansion + (s ? 2 : 0) * e.diversity + (c ? 2 : 0) * e.diversity + j[n] * .4 + (n === "brick" || n === "food" ? 2 : 0);
		}, p = (e) => r.market.flatMap((t, n) => t ? k.flatMap((a) => {
			let o = ye(t, n, e, a);
			return (!r.proconsulPurchase || P[t].role !== "proconsul") && H(i.goods, o) ? [{
				id: t,
				slot: n,
				payment: a,
				cost: o
			}] : [];
		}) : []), m = (t) => {
			let n = P[t], a = i.houses.length;
			return 4 + (n.god === "jupiter" ? a * .8 : n.god === "saturnus" ? new Set(i.houses.map((e) => o.cities.find((t) => t.id === e).province)).size : n.god === "mercurius" ? new Set(i.houses.map((e) => r.cityGoods[e])).size * 2 : n.god === "mars" ? i.units.length * 2 : n.god === "venus" ? o.provinces.filter((e, t) => {
				let n = i.houses.filter((e) => o.cities.find((t) => t.id === e).province === t).length;
				return r.teams ? n > 0 && r.players.find((e) => e.rid === B(r, i.rid)).houses.some((e) => o.cities.find((t) => t.id === e).province === t) : n >= 2;
			}).length * (r.teams ? 1 : 2) : n.god === "minerva" ? i.houses.filter((e) => r.cityGoods[e] === n.specialty).length * n.points : Math.floor(i.cash / 10)) * e.cards + (n.role === "colonist" && i.units.length < 5 ? 4 : 0) + (n.role === "architect" ? 2 : 0) + (n.role === "consul" ? 3 : 0);
		}, h = (t) => {
			let n = r.bonuses[t], a = z(i), s = d(n) * (r.magnus === i.rid ? 2 : 1), c = i.houses.filter((e) => o.cities.find((t) => t.id === e).province === t).map((e) => d(r.cityGoods[e])).reduce((e, t) => e + t, 0), l = r.players.filter((e) => e.rid !== i.rid).reduce((e, n) => e + n.houses.filter((e) => o.cities.find((t) => t.id === e).province === t).length, 0);
			return Math.min(s + c, a * 6) - l * e.opponent;
		}, g = r.activeProvinces.flatMap((e, t) => e ? [t] : []).sort((e, t) => h(t) - h(e)), _ = r.bonuses.reduce((e, t, n) => e + (r.activeProvinces[n] ? 0 : re[t]), 0), ee = i.goods.food > 0 && i.goods.tool > 0 && i.units.length < 6, v = ve(r, i.rid), y = i.units.flatMap((e, t) => Object.entries(me(r, i.rid, t, r.phase === "move" ? r.movement : i.units.length)).map(([n, a]) => {
			let l = o.roads.find((e) => e.id === n), u = [l.a, l.b].filter((e) => e !== c && !i.houses.includes(e)), d = u.filter((e) => {
				let t = V(r, e);
				return H(i.goods, t.goods) && s >= t.cash;
			}), p = he(r.map, [e]);
			return {
				unit: t,
				road: n,
				distance: a,
				value: d.reduce((e, t) => e + f(t), 0) + u.filter((e) => !p.includes(e)).length * .4 - a * .12
			};
		})).sort((e, t) => t.value - e.value), b = (n, o) => {
			if (n === "architect") return Math.max(v.length ? 10 + v.length * 5 : 0, (y[0]?.value ?? 0) * .9);
			if (n === "prefect") return Math.max(g.length ? h(g[0]) * .8 : 0, _ * (i.cash < 8 ? 1.3 : .65));
			if (n === "mercator") return (i.cash < 6 ? 11 : 7) + (i.goods.brick === 0 ? 3 : 0) + (i.goods.food === 0 ? 2 : 0);
			if ([
				"senator",
				"consul",
				"praetor",
				"proconsul"
			].includes(n)) return Math.max(0, ...p(n === "consul" || n === "proconsul").map((e) => m(e.id) + 4));
			if (n === "colonist") return ee && i.units.length < 5 ? 12 + e.recruit * 2 : i.cash < 10 ? 12 : 5;
			if (n === "tribune") return Math.max(0, ((r.teams ? 6 : r.mode === "venus" ? 8 : 7) + i.bought.length - a.length) * 1.8 - 4) + (a.length < 3 ? 8 : 0);
			if (n === "magister") {
				let e = t.private?.discard.at(-1);
				return e && ![
					"senator",
					"magister",
					"diplomat"
				].includes(P[e].role) ? b(P[e].role, e) : 0;
			}
			if (n === "legatus") return 13;
			if (n === "diplomat") return Math.max(0, ...r.players.filter((e) => e.rid !== i.rid && e.rid !== B(r, i.rid) && e.top && ![
				"tribune",
				"diplomat",
				"magister",
				"legatus"
			].includes(P[e.top].role)).map((e) => b(P[e.top].role, e.top))) - .2;
			let s = P[o].specialty;
			return Math.min(z(i), i.houses.filter((e) => r.cityGoods[e] === s).length) * d(s) * .85;
		}, x = (e) => Math.max(b(P[e].role, e), P[e].choice ? b(P[e].choice, e) : 0);
		if (r.phase === "start") return l({
			type: "startCity",
			city: _e(r.map).sort((e, t) => o.roads.filter((e) => e.a === t || e.b === t).length - o.roads.filter((t) => t.a === e || t.b === e).length)[0]
		});
		if (r.phase === "legatus") {
			let e = t.private?.partnerHand ?? [];
			return l({
				type: "recommend",
				card: e.filter((e) => P[e].role === "architect")[0] ?? e[0] ?? null
			});
		}
		if (r.phase === "choice") {
			let e = P[r.card];
			return l({
				type: "choose",
				role: b(e.role, e.id) >= b(e.choice, e.id) ? e.role : e.choice
			});
		}
		if (r.phase === "play" || r.phase === "partner") return l({
			type: "play",
			card: a.filter((e) => !(r.phase === "partner" && r.singlePlay && P[e].role === "legatus")).sort((e, t) => x(t) - x(e) || e.localeCompare(t))[0]
		});
		if (r.phase === "copy") {
			let e = r.players.filter((e) => r.copyTargets?.includes(e.rid) ?? (e.rid !== i.rid && e.rid !== B(r, i.rid) && !!e.top && !["tribune", "diplomat"].includes(P[e.top].role))).sort((e, t) => b(P[t.top].role, t.top) - b(P[e.top].role, e.top));
			return e.length ? l({
				type: "copy",
				rid: e[0].rid
			}) : u();
		}
		if (r.phase === "move") {
			if (v.length) return u();
			let e = y[0];
			return e && e.value > 4 ? l({
				type: "move",
				unit: e.unit,
				road: e.road
			}) : u();
		}
		if (r.phase === "build") return v.length ? l({
			type: "build",
			city: v.sort((e, t) => f(t) - f(e))[0]
		}) : u();
		if (r.phase === "prefect") return g.length && h(g[0]) * .8 > _ * (i.cash < 8 ? 1.3 : .65) ? l({
			type: "produce",
			province: g[0]
		}) : l({ type: "cash" });
		if (r.phase === "buy") {
			let e = p(r.freePurchase ?? (r.card !== null && P[r.card].role === "consul")).sort((e, t) => m(t.id) - R(t.cost) * 1.2 - (m(e.id) - R(e.cost) * 1.2));
			return e.length ? l({
				type: "buy",
				slot: e[0].slot,
				payment: e[0].payment
			}) : u();
		}
		if (r.phase === "colonist" || r.phase === "tribune") {
			if (ee && (r.phase === "colonist" || r.recruited === 0) && (i.units.length < 4 || e.recruit > 0 && i.units.length < 6)) {
				let e = i.units.filter((e) => e.kind === "land").length <= i.units.filter((e) => e.kind === "sea").length ? "land" : "sea", t = (r.phase === "tribune" ? [c] : [c, ...i.houses]).sort((t, n) => {
					let r = (t) => o.roads.filter((n) => n.kind === e && (n.a === t || n.b === t)).reduce((e, t) => e + Number(!i.houses.includes(t.a)) + Number(!i.houses.includes(t.b)), 0);
					return r(n) - r(t);
				})[0];
				return l({
					type: "recruit",
					kind: e,
					city: t
				});
			}
			return r.phase === "colonist" && r.recruited === 0 ? l({ type: "cash" }) : u();
		}
		let S = [];
		for (let e of o.cities.filter((e) => e.id !== c && !i.houses.includes(e.id))) {
			let t = V(r, e.id), n = i.units.some((t) => he(r.map, [t]).includes(e.id)) ? 0 : 2;
			S.push({
				goods: t.goods,
				rank: f(e.id) - k.reduce((e, n) => e + Math.max(0, t.goods[n] - i.goods[n]) * j[n], 0) - Math.max(0, t.cash - i.cash) * .5 - n
			});
		}
		for (let [e, t] of r.market.entries()) if (t) {
			let n = ye(t, e, !1, "brick");
			S.push({
				goods: n,
				rank: m(t) + 3 - k.reduce((e, t) => e + Math.max(0, n[t] - i.goods[t]) * j[t], 0)
			});
		}
		S.sort((e, t) => t.rank - e.rank);
		let C = { ...S[0]?.goods ?? A() };
		if (C.brick = Math.max(C.brick, i.houses.length < 10 ? 2 : 1), C.food = Math.max(C.food, 2), i.units.length < 4 && (C.tool = Math.max(C.tool, 1)), r.phase === "receive") {
			let e = A(), t = { ...r.pending.goods };
			for (let n = 0; n < r.pending.space; n++) {
				let n = k.filter((e) => t[e] > 0).sort((t, n) => d(n) + (i.goods[n] + e[n] < C[n] ? 8 : 0) - (d(t) + (i.goods[t] + e[t] < C[t] ? 8 : 0)))[0];
				n && (e[n]++, t[n]--);
			}
			return l({
				type: "receive",
				goods: e
			});
		}
		if (r.phase === "trade") {
			let e = k.filter((e) => r.traded.includes(e) || r.traded.length < 2), t = e.filter((e) => i.goods[e] < C[e]).sort((e, t) => (C[t] - i.goods[t]) * d(t) - (C[e] - i.goods[e]) * d(e)), n = e.filter((e) => i.goods[e] > C[e]).sort((e, t) => (i.goods[t] - C[t]) * j[t] - (i.goods[e] - C[e]) * j[e])[0];
			if (n && (i.cash < 8 || z(i) === 0) && (!t.length || s < j[t[0]] || z(i) === 0)) return l({
				type: "trade",
				good: n,
				amount: -(i.goods[n] - C[n])
			});
			let a = t.find((e) => s >= j[e] && z(i) > 0);
			return a ? l({
				type: "trade",
				good: a,
				amount: Math.min(C[a] - i.goods[a], Math.floor(s / j[a]), z(i))
			}) : n && i.cash < 4 ? l({
				type: "trade",
				good: n,
				amount: -1
			}) : u();
		}
		return u();
	};
}
var pt = ft(dt), mt = ft(ut), ht = (e, t) => (t.difficulty === "weak" ? mt : pt)(e, t), gt = (e, t, n) => {
	let r = I[t.public.map];
	if (e.type === "play") return n("games.concordia.logPlay", {
		name: "",
		target: n(`games.concordia.${P[e.card].role}`),
		n: 0
	}).trim();
	if (e.type === "build" || e.type === "recruit") return n(e.type === "build" ? "games.concordia.logBuild" : "games.concordia.logRecruit", {
		name: "",
		target: r.cities.find((t) => t.id === e.city)?.name ?? e.city,
		n: e.type === "build" ? V(t.public, e.city)?.cash ?? 0 : 0
	}).trim();
	if (e.type === "produce") return n("games.concordia.logProduce", {
		name: "",
		target: r.provinces[e.province],
		n: 0
	}).trim();
	if (e.type === "buy") {
		let r = t.public.market[e.slot];
		return n("games.concordia.logBuy", {
			name: "",
			target: r ? n(`games.concordia.${P[r].role}`) : "",
			n: e.slot
		}).trim();
	}
	if (e.type === "move") {
		let t = r.roads.find((t) => t.id === e.road);
		return n("games.concordia.hintMove", {
			from: r.cities.find((e) => e.id === t.a).name,
			to: r.cities.find((e) => e.id === t.b).name
		});
	}
	return e.type === "trade" ? n("games.concordia.hintTrade", {
		action: n(e.amount > 0 ? "games.concordia.tradeBuy" : "games.concordia.tradeSell"),
		n: Math.abs(e.amount),
		good: n(`games.concordia.${e.good}`)
	}) : e.type === "startCity" ? n("games.concordia.phaseStart") : e.type === "choose" ? n(`games.concordia.${e.role}`) : e.type === "recommend" ? n("games.concordia.phaseLegatus") : e.type === "copy" ? n("games.concordia.diplomat") : n(e.type === "cash" ? "games.concordia.hintCash" : e.type === "receive" ? "games.concordia.confirm" : "games.concordia.finish");
}, Q = (e) => e.queued ? 110 : 380, $ = (e, ...t) => t.map((t) => e.anchor(t)).find((e) => e && e.w > 0 && e.h > 0) ?? null, _t = (e, t) => $(e, `cc:discard-card:${t}`, `cc:top:${t}`), vt = (e, t) => e.queued ? [] : [`cc:discard-card:${t}`, `cc:top-card:${t}`].filter((t) => $(e, t)), yt = {
	concordiaPlay(e, t) {
		let n = e.data.card, r = $(t, e.rid === t.myRid ? "cc:hand-area" : `cc:top:${e.rid}`), i = _t(t, e.rid);
		return r && i ? {
			ms: Q(t),
			hide: vt(t, e.rid),
			node: /* @__PURE__ */ h(y, {
				from: {
					...r,
					w: 80,
					h: 120
				},
				to: i,
				ms: Q(t),
				children: /* @__PURE__ */ h(X, {
					id: n,
					small: !0
				})
			})
		} : null;
	},
	concordiaMove(e, t) {
		let n = e.data, r = $(t, `cc:location:${n.from}`), i = $(t, `cc:unit:${e.rid}:${n.unit}`), a = t.member(e.rid), o = l[(a?.colorIndex ?? 0) % l.length].hex;
		return !r || !i ? null : {
			ms: Q(t),
			hide: t.queued ? [] : [`cc:unit:${e.rid}:${n.unit}`],
			node: /* @__PURE__ */ h(y, {
				from: r,
				to: i,
				ms: Q(t),
				children: /* @__PURE__ */ h(Y, {
					kind: n.to.startsWith("s") ? "sea" : "land",
					color: o,
					size: i.w
				})
			})
		};
	},
	concordiaBuild(e, t) {
		let n = e.data.city, r = $(t, `cc:warehouse:${e.rid}`) ?? $(t, `cc:seat:${e.rid}`), i = $(t, `cc:house:${e.rid}:${n}`), a = l[(t.member(e.rid)?.colorIndex ?? 0) % l.length].hex;
		return r && i ? {
			ms: Q(t),
			hide: t.queued ? [] : [`cc:house:${e.rid}:${n}`],
			node: /* @__PURE__ */ h(y, {
				from: {
					...r,
					w: 26,
					h: 26
				},
				to: i,
				ms: Q(t),
				children: /* @__PURE__ */ h(Qe, { color: a })
			})
		} : null;
	},
	concordiaBuy(e, t) {
		let n = e.data, r = $(t, `cc:market:${n.slot}`), i = $(t, e.rid === t.myRid ? `cc:hand:${n.card}` : `cc:top:${e.rid}`);
		return r && i ? {
			ms: Q(t),
			hide: e.rid === t.myRid && !t.queued ? [`cc:hand:${n.card}`] : [],
			node: /* @__PURE__ */ h(y, {
				from: r,
				to: i,
				ms: Q(t),
				children: e.rid === t.myRid ? /* @__PURE__ */ h(X, {
					id: n.card,
					small: !0
				}) : /* @__PURE__ */ h(et, {})
			})
		} : null;
	},
	concordiaRecover(e, t) {
		let n = _t(t, e.rid), r = $(t, e.rid === t.myRid ? "cc:hand-area" : `cc:top:${e.rid}`);
		return n && r ? {
			ms: Q(t),
			node: /* @__PURE__ */ h(y, {
				from: n,
				to: {
					...r,
					w: 90,
					h: 120
				},
				ms: Q(t),
				children: /* @__PURE__ */ h(et, {})
			})
		} : null;
	},
	concordiaRecruit(e, t) {
		let n = e.data, r = $(t, `cc:warehouse:${e.rid}`) ?? $(t, `cc:seat:${e.rid}`), i = $(t, `cc:unit:${e.rid}:${n.unit}`), a = l[(t.member(e.rid)?.colorIndex ?? 0) % l.length].hex;
		return r && i ? {
			ms: Q(t),
			hide: t.queued ? [] : [`cc:unit:${e.rid}:${n.unit}`],
			node: /* @__PURE__ */ h(y, {
				from: {
					...r,
					w: 32,
					h: 32
				},
				to: i,
				ms: Q(t),
				children: /* @__PURE__ */ h(Y, {
					kind: n.kind,
					color: a,
					size: i.w
				})
			})
		} : null;
	},
	concordiaGain(e, t) {
		let n = e.data, r = $(t, n.source ?? "cc:bank", `cc:seat:${e.rid}`), i = $(t, `cc:seat:${e.rid}`);
		return !r || !i ? null : {
			ms: Q(t),
			node: /* @__PURE__ */ h(m, { children: k.filter((e) => n.goods[e] > 0).map((n) => {
				let a = $(t, `cc:good:${e.rid}:${n}`) ?? i;
				return /* @__PURE__ */ h(y, {
					from: {
						...r,
						w: 28,
						h: 28
					},
					to: {
						...a,
						w: 28,
						h: 28
					},
					ms: Q(t),
					children: /* @__PURE__ */ h(J, {
						good: n,
						style: {
							width: 28,
							height: 28
						}
					})
				}, n);
			}) })
		};
	},
	concordiaCash(e, t) {
		let n = $(t, `cc:seat:${e.rid}`);
		return n ? {
			ms: t.queued ? 110 : 460,
			node: /* @__PURE__ */ h(v, {
				at: n,
				ms: t.queued ? 110 : 460,
				children: /* @__PURE__ */ g("span", {
					className: "cc-float",
					children: [
						"+",
						e.data.n,
						" ◉"
					]
				})
			})
		} : null;
	},
	concordiaTrade(e, t) {
		let n = e.data, r = $(t, "cc:bank"), i = $(t, `cc:good:${e.rid}:${n.good}`) ?? $(t, `cc:seat:${e.rid}`);
		return r && i ? {
			ms: Q(t),
			node: /* @__PURE__ */ h(y, {
				from: {
					...n.n > 0 ? r : i,
					w: 28,
					h: 28
				},
				to: {
					...n.n > 0 ? i : r,
					w: 28,
					h: 28
				},
				ms: Q(t),
				children: /* @__PURE__ */ h(J, {
					good: n.good,
					style: {
						width: 28,
						height: 28
					}
				})
			})
		} : null;
	},
	concordiaProvince(e, t) {
		let n = $(t, `cc:province:${e.data.province}`);
		return n ? {
			ms: Q(t),
			node: /* @__PURE__ */ h(b, {
				at: n,
				ms: Q(t)
			})
		} : null;
	}
};
//#endregion
//#region src/games/concordia/game-over.tsx
function bt(e) {
	let t = e.public, n = a(), [o, s] = i(!0), [c, l] = i(null), u = r(null), d = r(null), f = (t) => e.members.find((e) => e.rid === t)?.name ?? t, p = (e) => {
		s(e), l(null), requestAnimationFrame(() => {
			(e ? u : d).current?.focus();
		});
	}, _ = () => {
		c === "again" ? e.onPlayAgain?.() : e.onBackToLobby?.(), l(null);
	};
	return /* @__PURE__ */ g("div", {
		className: "concordia cc-result-wrap",
		children: [
			/* @__PURE__ */ h("div", {
				className: "cc-result-board",
				inert: o,
				children: /* @__PURE__ */ h(lt, {
					...e,
					send: () => {}
				})
			}),
			/* @__PURE__ */ h("div", {
				className: "cc-result-overlay",
				hidden: !o,
				children: /* @__PURE__ */ g("section", {
					className: "cc-result",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": n("games.concordia.results"),
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), p(!1));
					},
					children: [
						/* @__PURE__ */ g("header", { children: [
							/* @__PURE__ */ h(Ze, {}),
							/* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("h1", { children: n("games.concordia.results") }), /* @__PURE__ */ h("p", { children: n("games.concordia.winner", { name: e.result.winner.map(f).join(" + ") }) })] }),
							/* @__PURE__ */ h("button", {
								type: "button",
								ref: u,
								onClick: () => p(!1),
								"aria-label": n("games.concordia.hideResult"),
								children: "↙"
							})
						] }),
						/* @__PURE__ */ g("div", {
							className: "cc-result-body",
							inert: c !== null,
							children: [/* @__PURE__ */ h("div", {
								className: "cc-score-scroll",
								children: /* @__PURE__ */ g("table", {
									"aria-label": n("games.concordia.score"),
									children: [
										/* @__PURE__ */ h("thead", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", { children: "CONCORDIA" }), e.result.ranking.map((e) => /* @__PURE__ */ h("th", {
											scope: "col",
											children: f(e)
										}, e))] }) }),
										/* @__PURE__ */ h("tbody", { children: [...ie.filter((e) => e !== "venus" || t.mode && t.mode !== "classic"), "concordia"].map((r) => /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
											scope: "row",
											children: n(q(r))
										}), e.result.ranking.map((e) => /* @__PURE__ */ g("td", { children: [t.scores?.[e][r] ?? 0, r !== "concordia" && r !== "minerva" && /* @__PURE__ */ h("small", { children: n("games.concordia.factor", { n: t.scores?.[e].factors[r] ?? 0 }) })] }, e))] }, r)) }),
										/* @__PURE__ */ g("tfoot", { children: [/* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
											scope: "row",
											children: n("games.concordia.score")
										}), e.result.ranking.map((e) => /* @__PURE__ */ h("td", { children: t.scores?.[e].total ?? 0 }, e))] }), t.teams && /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
											scope: "row",
											children: n("games.concordia.teamScore")
										}), e.result.ranking.filter((e, t) => t % 2 == 0).map((e) => /* @__PURE__ */ h("td", {
											colSpan: 2,
											children: (t.scores?.[e].total ?? 0) + (t.scores?.[t.teams[e]].total ?? 0)
										}, e))] })] })
									]
								})
							}), /* @__PURE__ */ g("div", {
								className: "cc-result-meta",
								children: [e.hintCount !== void 0 && /* @__PURE__ */ h("span", { children: n("session.hint.usedCount", { n: e.hintCount }) }), e.result.ranking.filter((t) => e.result.autopilot?.[t]).map((t) => /* @__PURE__ */ g("span", { children: [
									f(t),
									" · ",
									n("games.concordia.autopilot", { n: Math.round(e.result.autopilot[t] * 100) })
								] }, t))]
							})]
						}),
						/* @__PURE__ */ h("footer", { children: c ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
							type: "button",
							className: "danger-stripes",
							autoFocus: !0,
							onClick: _,
							children: n(c === "again" ? "games.concordia.confirmAgain" : "games.concordia.confirmLobby")
						}), /* @__PURE__ */ h("button", {
							type: "button",
							onClick: () => l(null),
							children: n("games.concordia.cancel")
						})] }) : /* @__PURE__ */ g(m, { children: [
							e.onBackToLobby && /* @__PURE__ */ h("button", {
								type: "button",
								onClick: () => l("lobby"),
								children: n("session.result.backToLobby")
							}),
							e.onPlayAgain && /* @__PURE__ */ h("button", {
								type: "button",
								className: "cc-primary",
								onClick: () => l("again"),
								children: n("session.result.playAgain")
							}),
							!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ h("span", { children: n("session.result.waitHost") })
						] }) })
					]
				})
			}),
			/* @__PURE__ */ h("button", {
				type: "button",
				ref: d,
				hidden: o,
				className: "cc-result-restore",
				onClick: () => p(!0),
				children: n("games.concordia.showResult")
			})
		]
	});
}
//#endregion
//#region src/games/concordia/options.tsx
function xt({ value: e, onChange: t }) {
	let n = a(), r = we.safeParse(e), i = r.success ? r.data : we.parse(void 0);
	return /* @__PURE__ */ g(m, { children: [
		/* @__PURE__ */ h(S, {
			title: n("games.concordia.mode"),
			columns: 3,
			children: [
				"classic",
				"venus",
				"team"
			].map((e) => /* @__PURE__ */ h(x, {
				name: "concordia-mode",
				value: e,
				label: n(q(e === "venus" ? "individual" : e)),
				checked: i.mode === e,
				accent: "#376c79",
				onChange: () => t({
					...i,
					mode: e,
					map: "auto"
				})
			}, e))
		}),
		i.mode === "team" && /* @__PURE__ */ h(S, {
			title: n("games.concordia.teamPlayers"),
			columns: 2,
			children: [4, 6].map((e) => /* @__PURE__ */ h(x, {
				name: "concordia-teams",
				value: String(e),
				label: n("games.concordia.players", { n: e }),
				checked: i.teamPlayers === e,
				accent: "#376c79",
				onChange: () => t({
					...i,
					teamPlayers: e
				})
			}, e))
		}),
		/* @__PURE__ */ h(S, {
			title: n("games.concordia.map"),
			columns: 3,
			children: (i.mode === "classic" ? [
				"auto",
				"italia",
				"imperium"
			] : [
				"auto",
				"italia",
				"imperium",
				"hellas",
				"ionium",
				"ioniumSmall",
				"cyprus"
			]).map((e) => /* @__PURE__ */ h(x, {
				name: "concordia-map",
				value: e,
				label: n(q(e)),
				checked: i.map === e,
				accent: "#376c79",
				onChange: () => t({
					...i,
					map: e
				})
			}, e))
		}),
		/* @__PURE__ */ h("p", {
			className: "text-xs",
			children: n("games.concordia.mapHelp")
		}),
		/* @__PURE__ */ h(C, {
			label: n("games.concordia.intermediate"),
			checked: i.intermediate,
			onChange: () => t({
				...i,
				intermediate: !i.intermediate
			})
		})
	] });
}
//#endregion
//#region .bgparty/cache/pack-entry/concordia/entry.tsx
var St = {
	definition: Xe,
	View: lt,
	bot: ht,
	describe: gt,
	fx: yt,
	OverView: bt,
	Options: xt,
	locales: {
		zh: {
			name: "康考迪亚",
			desc: "在罗马帝国拓展贸易网络，借助人物牌发展城市，让诸神见证你的繁荣。",
			rules: "目标：\n在罗马帝国建立房屋、发展殖民者与贸易，并收集人物牌。终局时每张人物牌按其神祇为你计分，最高分者获胜。\n准备：\n游戏支持2至5人。Italia地图适合2至4人，Imperium地图适合3至5人。自动地图在2至3人时使用Italia，4至5人时使用Imperium；与人数不符的手动选择会采用该人数的官方地图。按城市背面字母分别随机分配货物；每省最贵货物成为省奖励。每人拥有7张起手牌、15座房屋和陆海各3名殖民者，其中陆海各1名从Roma出发，其余4名留在12格仓库。仓库起始有2份粮食以及砖块、工具、葡萄酒和布料各1份。随机先手获得5枚钱币，后续座次依次多1枚钱币；末席持有大执政官。市场按I至人数的牌堆分别洗牌、依次叠放，展示7张。\n流程：\n轮到你时打出1张人物牌并执行其行动。自己已打出的牌堆只向对手展示顶牌；购买的牌立即进入手牌。\n· 建筑师：移动点等于你在版图上的殖民者总数，可分配给任意己方殖民者，也可少用。陆地殖民者走陆路，海上殖民者走海路；从城市出发到相邻路线用1点，从路线经过城市到另一条同类路线再用1点。可以穿过已占用的路线并计算每步，不能停在被占用的路线上。全部移动结束后，可在己方殖民者所在路线两端的城市建任意数量的房屋。每人每城最多1座，Roma不能建房。砖城支付1份粮食；其余城市支付1份砖块和1份该城货物。钱币基础费用按砖、粮、工具、酒、布依次为1、2、3、4、5，乘以建成后该城总房屋数。\n· 执政官：选择尚未生产的省份，领取其奖励货物1份，并让该省所有玩家的每座房屋各生产1份城市货物，然后将奖励翻为钱币面；也可领取所有已翻面奖励的金币总数并将其全部复原。布料奖励的背面为1枚钱币，其余为2枚钱币。持有大执政官者选择生产时必须领取双份省奖励，随后把大执政官交给右手玩家；房屋产量不翻倍；选择领取钱币时，不传递大执政官。\n· 商人：起手商人先获得3枚钱币，购买的商人先获得5枚钱币，然后最多交易两种货物，可买入或卖出任意数量，受资金和仓库容量限制。砖块、粮食、工具、葡萄酒和布料的固定单价分别为3、4、5、6、7枚钱币。\n· 元老：最多购买2张市场牌，支付牌面费用及原槽位附费。7个槽位附费依次为无、任意货物、任意货物、布料、布料、任意货物与布料、2份布料。全部购买结束后才左移并补牌。\n· 领事：只购买1张市场牌，忽略槽位附费。\n· 外交官：复制其他玩家弃牌顶牌的行动，不能复制外交官或护民官。自己弃牌顶仍是外交官。\n· 殖民官：每支付1份粮食和1份工具，就从仓库部署1名陆地或海上殖民者至Roma或自己已有房屋的城市；也可领取5枚钱币及每名已在版图的己方殖民者各1枚钱币。\n· 护民官：收回全部弃牌（含本牌），每超过3张获得1枚钱币；此外可支付1份粮食和1份工具，从仓库部署1名殖民者至Roma。\n· 石匠：让自己在砖块城市的每座房屋各生产1份货物。\n· 农夫：让自己在粮食城市的每座房屋各生产1份货物。\n· 铁匠：让自己在工具城市的每座房屋各生产1份货物。\n· 酿酒师：让自己在葡萄酒城市的每座房屋各生产1份货物。\n· 织工：让自己在布料城市的每座房屋各生产1份货物。\n仓库：\n每份货物及每名尚未部署的殖民者占1格，共12格。不能主动丢弃货物；生产超过剩余空间时，自己选择接收哪些新货物，必须填满剩余格。钱币和货物供应不限，每人殖民者上限6名。玩家之间不能交易。\n结束与计分：\n首位建出第15座房屋，或买光市场与牌堆最后1张牌的玩家，获得Concordia奖励7分；其他玩家各执行最后1回合，然后同时计分。计算手牌与弃牌中的全部人物牌，每张按其神祇获得下列分数：\n· 维斯塔：现金与仓库货物市价合计，每满10枚钱币获得1分。\n· 朱庇特：每座非砖城房屋获得1分。\n· 萨图恩：每个拥有己方房屋的省份获得1分。\n· 墨丘利：每种己方房屋能生产的货物获得2分。\n· 玛尔斯：每名已在版图的己方殖民者获得2分。\n· 密涅瓦：按对应专精城市计分，砖、粮、工具每座3分，葡萄酒每座4分，布料每座5分。\n分数最高者获胜。同分时，持有大执政官者优先；若其不在同分者中，沿大执政官向右传递的方向最先取得它的同分玩家优先。\n中间计分（可选，默认关闭）：\n每人第一次打出护民官收牌后立即记录当时分数。所有人都完成后，最高分者获得2枚钱币，第二名获得1枚钱币；并列同一名次者获得相同奖励。这些分数不会保留到终局。\n\nVenus 个人玩法（2至5人）：\n在开局设置中选择，默认仍为经典基础版。Venus 每人有8张起手牌，新增导师（维纳斯）：重复自己上一张人物牌的行动，但不能重复元老。市场以4张维纳斯双行动牌替换经典对应牌，石匠移入II牌堆；每堆仍按罗马数字分别洗牌。打出双行动牌时选择其中一种人物行动。每张维纳斯牌按每个至少有2座己方房屋的省份获得2分。\nVenus 组队玩法（4或6人）：\n双方按座位相对组成2或3队。每人保管自己的手牌、货物、房屋、殖民者与钱币；货物及牌不能交换。仅当行动需要的钱币不足时，可直接取用伙伴补足的差额。第一队的每名玩家起始获得5枚钱币，第二队每人获得6枚，第三队每人获得7枚。\n团队起手牌包括建筑师、外交官、商人、1张执政官、裁判官、护民官和使节。每队第一名伙伴移除外交官，第二名伙伴移除建筑师，各以6张牌开局。首伙伴的殖民者从首都出发；次伙伴选择不与首都直接相邻的非首都城市。所选城市若只连接陆路或只连接海路，两名起始殖民者都采用该类型；每人陆海各3名的总储备不变。仍在城市内的殖民者不能用于建房。\n回合标记按座位顺时针移动。一人出牌，先自己执行，再由伙伴执行；伙伴通常不出牌。双方完成后标记才移至出牌者下一席。双行动牌由先执行者选一项，伙伴必须执行另一项。大执政官仅影响当前持有人，仍向右传递。\n· 裁判官：双方各最多购买1张，双方结束后才左移及补充市场。\n· 总督：出牌者购买1张市场牌，无须支付槽位附加费用，但不能购买总督；然后伙伴另出1张牌，仅自己执行，不能出使节。双方结束后才补市场。\n· 使节：出牌者可查看伙伴手牌并建议一张，伙伴自行决定出什么牌。先由伙伴执行，再由请求者执行；回合标记不变。手牌仅在该阶段向请求者开放。\n· 外交官：不能复制伙伴的牌；同一队不能重复复制某位对手仍置顶的同一次出牌。对手收回并重新打出该牌后可再次复制。双方执行同一个被选牌的行动；双行动牌仍各执行一项。\n· 护民官：双方各收回自己的弃牌；只有实际打出护民官的一方将本牌计入收牌数量。\n团队每张维纳斯牌按每个双方各有至少1座房屋的省份获得1分。使节包含朱庇特、萨图恩、维纳斯，分别计分一次。终局将双方个人分数相加；触发终局的团队完成当前回合后，其他团队各进行最后1回合。团队同分仍按大执政官及向右传递顺序判定，获胜队双方共同获胜。\nVenus 地图：\n可选 Hellas、Ionium、Ionium 小地图、Cyprus，以及原有地图。自动地图在2至3人使用 Ionium 小地图、4人使用 Hellas、5至6人使用 Imperium。Venus 可在既有地图游玩；经典版仍按原人数限制选择 Italia／Imperium。Hellas 和 Ionium 的首都是 Athenae，Cyprus 的首都是 Antiochia；护民官和殖民官的首都部署规则随所选地图变化。\nIonium 的 Brundisium—Apollonia 特殊陆路可花1点移动经过，但不能作为结束移动的停点。小地图移除全部8座B城市与3个意大利省份，剩22座生产城市和9省。Cyprus 的省份以 I 至 XII 标识。",
			mode: "玩法",
			classic: "经典基础版",
			individual: "Venus 个人",
			team: "Venus 组队",
			teamPlayers: "组队人数",
			players: "{{n}} 人",
			teamNumber: "第{{n}}队",
			hellas: "Hellas",
			ionium: "Ionium",
			ioniumSmall: "Ionium（小地图）",
			cyprus: "Cyprus",
			magister: "导师",
			praetor: "裁判官",
			proconsul: "总督",
			legatus: "使节",
			venus: "维纳斯",
			cardMagister: "再次执行自己上一张人物牌的行动，不能重复元老。",
			cardPraetor: "双方各可购买一张人物牌，全部结束后补充市场。",
			cardProconsul: "无附费购买一张非总督牌，然后伙伴另出一张牌，仅自己执行；不能出使节。",
			cardLegatus: "查看伙伴手牌并可建议一张，由伙伴自行出牌，双方从伙伴开始执行。",
			cardDual: "选择{{first}}或{{second}}；组队时伙伴执行另一项。",
			phaseStart: "选择不与首都直接相邻的起始城市",
			phaseChoice: "选择本次执行的人物行动",
			phaseLegatus: "查看伙伴手牌，可建议一张牌",
			phasePartner: "从手牌打出一张人物牌",
			partnerHand: "{{name}}的手牌",
			noRecommendation: "由伙伴自行选择",
			recommended: "伙伴建议：{{card}}",
			teamScore: "团队总分",
			capital: "首都",
			turnMarker: "回合标记",
			logStart: "{{name}} 选择了起始城市 {{target}}。",
			logChoose: "{{name}} 选择了{{target}}行动。",
			hintMove: "将殖民者移动至 {{from}} 与 {{to}} 之间的路线。",
			hintTrade: "{{action}} {{n}} 份{{good}}。",
			hintCash: "领取钱币。",
			architect: "建筑师",
			prefect: "执政官",
			mercator: "商人",
			colonist: "殖民官",
			diplomat: "外交官",
			senator: "元老",
			consul: "领事",
			tribune: "护民官",
			mason: "石匠",
			farmer: "农夫",
			smith: "铁匠",
			vintner: "酿酒师",
			weaver: "织工",
			vesta: "维斯塔",
			jupiter: "朱庇特",
			saturnus: "萨图恩",
			mercurius: "墨丘利",
			mars: "玛尔斯",
			minerva: "密涅瓦",
			concordia: "Concordia",
			brick: "砖块",
			food: "粮食",
			tool: "工具",
			wine: "葡萄酒",
			cloth: "布料",
			land: "陆地殖民者",
			sea: "海上殖民者",
			invalid: "当前不能执行该行动，请检查目标、费用和行动阶段。",
			map: "地图",
			auto: "自动",
			italia: "Italia（2至4人）",
			imperium: "Imperium（3至5人）",
			mapHelp: "人数不符时自动采用该人数的官方地图。",
			intermediate: "中间计分",
			intermediateHelp: "推荐首次游玩时开启。",
			phasePlay: "打出一张人物牌",
			phaseMove: "选择殖民者与目的路线",
			phaseBuild: "在相邻城市建造房屋",
			phasePrefect: "选择省份生产，或领取钱币",
			phaseTrade: "最多交易两种货物",
			phaseBuy: "选择要购买的人物牌",
			phaseColonist: "部署殖民者，或领取钱币",
			phaseTribune: "可在首都部署一名殖民者",
			phaseCopy: "选择对手的顶牌",
			phaseReceive: "选择要接收的新货物",
			phaseDone: "对局结束",
			waiting: "等待 {{name}}",
			turn: "第 {{n}} 回合",
			finalTurns: "最后一轮",
			moves: "剩余移动点 {{n}}",
			purchases: "还可购买 {{n}} 张",
			finishMove: "结束移动",
			finish: "结束行动",
			cash: "领取 {{n}} 钱",
			receive: "接收货物",
			choosePayment: "选择支付的任意货物",
			cancel: "取消",
			confirm: "确认",
			warehouse: "仓库",
			storage: "已使用 {{n}} / 12 格",
			cashLabel: "钱币",
			houses: "房屋",
			colonists: "殖民者",
			cards: "人物牌",
			magnus: "大执政官",
			bonus: "省份奖励",
			market: "人物市场",
			hand: "手牌",
			discard: "弃牌",
			bank: "银行",
			inspect: "查看",
			resetMap: "回到全图",
			details: "详情",
			close: "关闭",
			buildCost: "建造费用",
			any: "任意货物",
			free: "无附费",
			buy: "购买",
			tradeBuy: "买入",
			tradeSell: "卖出",
			recruit: "部署",
			available: "可用",
			used: "已生产",
			keep: "接收 {{n}} 份",
			supply: "房屋余量 {{n}}",
			cardArchitect: "移动殖民者，然后在相邻城市建房。",
			cardPrefect: "让一个省份生产，或收取所有已翻面的金币。",
			cardMercator: "获得钱币，然后交易最多两种货物。",
			cardColonist: "在己方城市部署殖民者，或获得钱币。",
			cardDiplomat: "复制一名对手的顶牌行动。",
			cardSenator: "按原槽位费用购买最多两张牌。",
			cardConsul: "忽略槽位附费购买一张牌。",
			cardTribune: "收回弃牌，获得钱币，并可部署一名殖民者。",
			cardSpecialist: "对应货物的全部己方房屋生产。",
			logPlay: "{{name}} 打出了{{target}}。",
			logMove: "{{name}} 移动了殖民者，使用 {{n}} 点移动。",
			logBuild: "{{name}} 在 {{target}} 建造了房屋。",
			logProduce: "{{name}} 令 {{target}} 生产。",
			logCash: "{{name}} 获得了 {{n}} 钱。",
			logTrade: "{{name}} 交易了 {{n}} 份{{target}}。",
			logBuy: "{{name}} 购买了{{target}}。",
			logRecruit: "{{name}} 在 {{target}} 部署了殖民者。",
			logReceive: "{{name}} 接收了 {{n}} 份货物。",
			logFinish: "{{name}} 结束了行动。",
			logIntermediate: "{{name}} 的中间计分为 {{n}} 分。",
			logEnd: "{{name}} 触发了最后一轮。",
			score: "总分",
			results: "诸神的赞誉",
			winner: "{{name}} 获胜",
			hideResult: "收起结算，回看版图",
			showResult: "查看结算",
			confirmAgain: "确认再来一局",
			confirmLobby: "确认返回大厅",
			autopilot: "托管 {{n}}%",
			factor: "每张 {{n}} 分",
			hint: "执行：{{action}}"
		},
		en: {
			name: "Concordia",
			desc: "Expand your trade network across the Roman Empire. Build cities and collect personality cards to earn the gods’ favour.",
			rules: "Goal:\nBuild houses, develop colonists and trade, and collect personality cards. Each card scores for its god at the end; the highest score wins.\nSetup:\nFor 2–5 players. Italia supports 2–4 and Imperium supports 3–5. Auto uses Italia for 2–3 and Imperium for 4–5; an incompatible manual selection uses the official map for the player count. Shuffle city tokens within each letter group. Each province’s most valuable good becomes its bonus. Each player has 7 starting cards, 15 houses and 3 colonists of each type. One land and one sea colonist start in Roma; the other four occupy the 12-space storehouse, together with 2 food and 1 each of brick, tool, wine and cloth. A random first player receives 5 coins; each later seat receives one more. The last player holds Praefectus Magnus. Shuffle market decks I through the player count separately, stack in that order, and display 7 cards.\nTurns:\nPlay one personality card and carry out its action. Only the top card of each opponent’s discard pile is visible. Purchased cards immediately enter your hand.\n· Architect: Movement points equal your colonists on the map. Distribute them freely; unused points are allowed. Land colonists use land routes and sea colonists sea routes. Leaving a city for an adjacent route costs 1 point; moving from a route through a city to another adjacent route costs 1 more. You may pass through occupied routes, paying for every step, but cannot stop on an occupied route. After all movement, build any number of houses in cities adjacent to your colonists. At most one house per player per city; none in Roma. A brick city costs 1 food; other cities cost 1 brick and 1 of that city’s good. Coin costs are 1/2/3/4/5 for brick/food/tool/wine/cloth, multiplied by the total houses in the city after building.\n· Prefect: Choose an active province, receive one bonus good, produce one good per house there for every owner, and flip the marker to coins. Alternatively collect all visible coins and reactivate those markers. Cloth markers show 1 coin, all other goods 2. Praefectus Magnus must double the province bonus when its owner produces, then passes to the player on the right. House production is unchanged. Collecting coins neither doubles the coins nor passes Magnus.\n· Mercator: Gain 3 coins with a starting Mercator or 5 with a purchased one, then buy and/or sell up to two types of goods in any quantity your cash and space permit. Fixed prices for brick/food/tool/wine/cloth are 3/4/5/6/7.\n· Senator: Buy up to 2 market cards, paying their printed costs plus the original slot surcharge. The seven surcharges are none, any good, any good, cloth, cloth, any good plus cloth, and 2 cloth. Shift and refill only after both purchases.\n· Consul: buy one card without a slot surcharge.\n· Diplomat: Copy another player’s top discard action, excluding Diplomat and Tribune. Your own top discard remains the Diplomat.\n· Colonist: Pay 1 food and 1 tool per new land or sea colonist, deploying from storage to Roma or a city with your house. Alternatively gain 5 coins plus 1 for each of your colonists already on the map.\n· Tribune: Recover all discards, including this card, and gain 1 coin for each recovered card beyond the third. You may also pay 1 food and 1 tool to deploy one colonist from storage into Roma.\n· Mason: produce one good at each of your houses in a brick city.\n· Farmer: produce one good at each of your houses in a food city.\n· Smith: produce one good at each of your houses in a tool city.\n· Vintner: produce one good at each of your houses in a wine city.\n· Weaver: produce one good at each of your houses in a cloth city.\nStorehouse:\nEach good and each undeployed colonist occupies one of 12 spaces. You may not discard existing goods. If production exceeds free space, choose which new goods to receive, filling all free spaces. Goods and coins are unlimited; colonists are limited to 6 per player. Players cannot trade with each other.\nEnding and scoring:\nThe first player to build a 15th house or buy the last remaining card receives the 7-point Concordia bonus. Every other player gets one final turn, then scores every card in hand and discard by its god:\n· Vesta: 1 point per full 10 coins of cash plus the market value of stored goods.\n· Jupiter: 1 point per house in a non-brick city.\n· Saturnus: 1 point per province containing your house.\n· Mercurius: 2 points per good type produced by your houses.\n· Mars: 2 points per colonist on the map.\n· Minerva: 3 points per matching brick, food or tool house; 4 per wine house; 5 per cloth house.\nMost points wins. Ties favour the holder of Praefectus Magnus, then the first tied player who would receive it when passing to the right.\nIntermediate scoring (optional, off by default):\nAfter each player’s first Tribune recovery, record their current score. Once everyone has done so, first place receives 2 coins and second place 1 coin; tied players at a position receive the same reward. These scores do not carry into final scoring.\n\nVenus Individual (2–5 players):\nChoose this variant in setup; Classic remains the default. Start with 8 cards, adding Magister (Venus), which repeats your previous personality except Senator. Four Venus double-choice market cards replace their classic counterparts, and Mason moves to deck II. Shuffle each numbered deck separately. Choose one personality when using a double-choice card. Each Venus card scores 2 points per province containing at least two of your houses.\nVenus Team (4 or 6 players):\nOpposite seats form two or three teams. Each player keeps their own hand, goods, houses, colonists and cash. Goods and cards cannot be exchanged. Only when an action needs more cash than you own may you take the missing amount from your partner. Both members of the first, second and third team start with 5, 6 and 7 coins respectively.\nThe seven team starting cards are Architect, Diplomat, Mercator, one Prefect, Praetor, Tribune and Legatus. The first partner removes Diplomat; the second removes Architect, leaving each with six cards. First partners start their colonists in the capital. Second partners choose a non-capital city not directly adjacent to it. If that city has only land or only sea routes, both starting colonists match that type; the total supply remains three of each type per player. Colonists still inside a city cannot build houses.\nThe turn order marker moves clockwise by seat. A player plays a card and acts first, followed by their partner, who normally plays no card. Move the marker to the next seat only after both finish. On a double-choice card, the first player chooses one personality and their partner must use the other. Praefectus Magnus affects only its current owner and still passes to the right.\n· Praetor: Each partner may buy at most one card; shift and refill after both finish.\n· Proconsul: Buy one card without a surcharge, except another Proconsul. Your partner then plays one card and uses it alone, except Legatus. Refill only after both finish.\n· Legatus: Inspect your partner’s hand and optionally suggest a card. Your partner chooses what to play. They act first, followed by the requester; the marker stays in place. Only the requester can inspect the hand, during this phase.\n· Diplomat: You cannot copy your partner. A team cannot copy the same opponent’s still-visible played card twice. Once that opponent recovers and plays the card again, it can be copied again. Both partners use the same selected card; double-choice cards still give one personality to each partner.\n· Tribune: Each partner recovers their own discards. Only the player who actually played Tribune counts that card among those recovered.\nEach team Venus card scores 1 point per province where both partners have at least one house. Legatus scores once each for Jupiter, Saturnus and Venus. Add both personal scores for the team total. After the team triggering the end completes its turn, every other team takes one final turn. Ties use Magnus and its passing order to the right; both members of the winning team win together.\nVenus maps:\nChoose Hellas, Ionium, small Ionium, Cyprus or an existing map. Auto uses small Ionium for 2–3, Hellas for 4 and Imperium for 5–6 players. Venus works on existing maps; Classic keeps the original Italia/Imperium player limits. The capital is Athenae on Hellas and Ionium, and Antiochia on Cyprus. Tribune and Colonist deployment use the selected map’s capital.\nOn Ionium, the special Brundisium–Apollonia land connection costs one movement step to cross but cannot be a final stopping point. Small Ionium removes all eight B cities and the three Italian provinces, leaving 22 producing cities in nine provinces. Cyprus provinces are identified by I–XII.",
			mode: "Variant",
			classic: "Classic",
			individual: "Venus Individual",
			team: "Venus Team",
			teamPlayers: "Team player count",
			players: "{{n}} players",
			teamNumber: "Team {{n}}",
			hellas: "Hellas",
			ionium: "Ionium",
			ioniumSmall: "Ionium (small)",
			cyprus: "Cyprus",
			magister: "Magister",
			praetor: "Praetor",
			proconsul: "Proconsul",
			legatus: "Legatus",
			venus: "Venus",
			cardMagister: "Repeat your previous personality card, except Senator.",
			cardPraetor: "Each partner may buy one card. Refill after both have finished.",
			cardProconsul: "Buy one non-Proconsul without a surcharge. Your partner then plays and uses one card alone, except Legatus.",
			cardLegatus: "Inspect your partner’s hand and optionally suggest a card. They choose what to play; both act, starting with them.",
			cardDual: "Choose {{first}} or {{second}}. In teams, your partner uses the other.",
			phaseStart: "Choose a starting city not directly adjacent to the capital",
			phaseChoice: "Choose a personality action",
			phaseLegatus: "Inspect your partner’s hand and optionally suggest a card",
			phasePartner: "Play a personality card from your hand",
			partnerHand: "{{name}}’s hand",
			noRecommendation: "Let partner choose",
			recommended: "Partner suggests: {{card}}",
			teamScore: "Team total",
			capital: "Capital",
			turnMarker: "Turn order marker",
			logStart: "{{name}} chose {{target}} as their starting city.",
			logChoose: "{{name}} chose the {{target}} action.",
			hintMove: "Move a colonist to the route between {{from}} and {{to}}.",
			hintTrade: "{{action}} {{n}} {{good}}.",
			hintCash: "Collect coins.",
			architect: "Architect",
			prefect: "Prefect",
			mercator: "Mercator",
			colonist: "Colonist",
			diplomat: "Diplomat",
			senator: "Senator",
			consul: "Consul",
			tribune: "Tribune",
			mason: "Mason",
			farmer: "Farmer",
			smith: "Smith",
			vintner: "Vintner",
			weaver: "Weaver",
			vesta: "Vesta",
			jupiter: "Jupiter",
			saturnus: "Saturnus",
			mercurius: "Mercurius",
			mars: "Mars",
			minerva: "Minerva",
			concordia: "Concordia",
			brick: "Brick",
			food: "Food",
			tool: "Tool",
			wine: "Wine",
			cloth: "Cloth",
			land: "Land colonist",
			sea: "Sea colonist",
			invalid: "This action is unavailable. Check the target, costs and current phase.",
			map: "Map",
			auto: "Auto",
			italia: "Italia (2–4 players)",
			imperium: "Imperium (3–5 players)",
			mapHelp: "An incompatible selection uses the official map for the player count.",
			intermediate: "Intermediate scoring",
			intermediateHelp: "Recommended for a first game.",
			phasePlay: "Play a personality card",
			phaseMove: "Choose a colonist and destination route",
			phaseBuild: "Build houses in adjacent cities",
			phasePrefect: "Produce a province or collect coins",
			phaseTrade: "Trade up to two types of goods",
			phaseBuy: "Choose personality cards to buy",
			phaseColonist: "Deploy colonists or collect coins",
			phaseTribune: "You may deploy one colonist in the capital",
			phaseCopy: "Choose an opponent’s top card",
			phaseReceive: "Choose new goods to receive",
			phaseDone: "Game over",
			waiting: "Waiting for {{name}}",
			turn: "Turn {{n}}",
			finalTurns: "Final turns",
			moves: "Movement left: {{n}}",
			purchases: "Purchases left: {{n}}",
			finishMove: "Finish moving",
			finish: "Finish action",
			cash: "Collect {{n}} coins",
			receive: "Receive goods",
			choosePayment: "Choose any good to pay",
			cancel: "Cancel",
			confirm: "Confirm",
			warehouse: "Storehouse",
			storage: "{{n}} / 12 spaces used",
			cashLabel: "Coins",
			houses: "Houses",
			colonists: "Colonists",
			cards: "Cards",
			magnus: "Praefectus Magnus",
			bonus: "Province bonus",
			market: "Personality market",
			hand: "Hand",
			discard: "Discards",
			bank: "Bank",
			inspect: "Inspect",
			resetMap: "Show full map",
			details: "Details",
			close: "Close",
			buildCost: "Building cost",
			any: "Any good",
			free: "No surcharge",
			buy: "Buy",
			tradeBuy: "Buy",
			tradeSell: "Sell",
			recruit: "Deploy",
			available: "Active",
			used: "Produced",
			keep: "Receive {{n}} goods",
			supply: "Houses remaining: {{n}}",
			cardArchitect: "Move colonists, then build in adjacent cities.",
			cardPrefect: "Produce a province or collect all visible coins.",
			cardMercator: "Gain coins, then trade up to two goods types.",
			cardColonist: "Deploy colonists in your cities or gain coins.",
			cardDiplomat: "Copy an opponent’s top discard action.",
			cardSenator: "Buy up to two cards at their original slot costs.",
			cardConsul: "Buy one card without a slot surcharge.",
			cardTribune: "Recover discards, gain coins, and optionally deploy one colonist.",
			cardSpecialist: "All your houses of the matching good produce.",
			logPlay: "{{name}} played {{target}}.",
			logMove: "{{name}} moved a colonist using {{n}} movement.",
			logBuild: "{{name}} built in {{target}}.",
			logProduce: "{{name}} produced {{target}}.",
			logCash: "{{name}} gained {{n}} coins.",
			logTrade: "{{name}} traded {{n}} {{target}}.",
			logBuy: "{{name}} bought {{target}}.",
			logRecruit: "{{name}} deployed a colonist in {{target}}.",
			logReceive: "{{name}} received {{n}} goods.",
			logFinish: "{{name}} finished their action.",
			logIntermediate: "{{name}} scored {{n}} intermediate points.",
			logEnd: "{{name}} triggered the final turns.",
			score: "Total",
			results: "Favour of the gods",
			winner: "{{name}} wins",
			hideResult: "Hide results and inspect the map",
			showResult: "Show results",
			confirmAgain: "Confirm new game",
			confirmLobby: "Confirm return to lobby",
			autopilot: "Autopilot {{n}}%",
			factor: "{{n}} points per card",
			hint: "Perform: {{action}}"
		}
	}
};
//#endregion
export { St as default };
