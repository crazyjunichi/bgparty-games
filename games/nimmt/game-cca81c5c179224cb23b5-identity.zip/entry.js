import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { AVATARS as r } from "@bgparty/sdk/avatars";
import { useFxAnchor as i } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as a } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { Texture as c } from "@bgparty/sdk/texture";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as f, seatName as p } from "@bgparty/sdk/ui/player-strip";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { IconBot as _, IconCheck as v } from "@bgparty/sdk/icons";
import { Floater as y, FlySprite as b, PulseBox as x } from "@bgparty/sdk/fx/primitives";
import { Confetti as S } from "@bgparty/sdk/ui/confetti";
//#region src/games/nimmt/meta.ts
var C = {
	id: "nimmt",
	tier: "released",
	mechanics: ["hand-management"],
	interactionTags: [],
	nameKey: "games.nimmt.name",
	descKey: "games.nimmt.desc",
	rulesKey: "games.nimmt.rules",
	icon: "🐮",
	iconImg: "games/nimmt.webp",
	rulesUrl: { en: "https://blog.amigo-spiele.de/content/ap/rule/04910-GB-AmigoRule.pdf" },
	minPlayers: 2,
	maxPlayers: 10,
	bestPlayers: [5, 6],
	accent: "#ea580c",
	releasedAt: "2026-09-07",
	search: {
		py: "shui shi niu tou wang",
		init: "ssntw"
	},
	hotseat: "cover"
}, w = t.int().min(1).max(104), T = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("select"),
		card: w
	}),
	t.object({
		type: t.literal("takeRow"),
		row: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), E = t.string(), D = t.object({
	rows: t.tuple([
		t.array(w),
		t.array(w),
		t.array(w),
		t.array(w)
	]),
	round: t.int().min(1),
	phase: t.enum([
		"select",
		"resolve",
		"done"
	]),
	players: t.array(t.object({
		rid: E,
		picked: t.boolean(),
		pen: t.int().nonnegative()
	})),
	queue: t.array(t.object({
		rid: E,
		card: w
	})),
	pendingTake: t.object({
		rid: E,
		card: w
	}).nullable()
}), ee = t.object({
	hand: t.array(w),
	mySelected: w.nullable()
});
//#endregion
//#region src/games/nimmt/rules.ts
function O(e) {
	return e === 55 ? 7 : e % 11 == 0 ? 5 : e % 10 == 0 ? 3 : e % 5 == 0 ? 2 : 1;
}
var k = 4, A = {
	place: 550,
	takeRow: 1300
}, j = (e) => 350 + 60 * e;
function te(t, n, r) {
	let i = Array.from({ length: 104 }, (e, t) => t + 1), a = 0;
	for (let t = i.length - 1; t > 0; --t) {
		let n = e(r, a, t + 1);
		a += 1, [i[t], i[n]] = [i[n], i[t]];
	}
	let o = 0, s = [
		[i[o++]],
		[i[o++]],
		[i[o++]],
		[i[o++]]
	], c = {}, l = {};
	for (let e of n) c[e] = i.slice(o, o + 10).sort((e, t) => e - t), o += 10, l[e] = 0;
	return {
		state: {
			players: n,
			hands: c,
			rows: s,
			selected: {},
			queue: [],
			pendingTake: null,
			pen: l,
			round: 1,
			phase: "select",
			beatMs: 0,
			rngCursor: a
		},
		fx: n.map((e, t) => ({
			kind: "deal",
			rid: e,
			data: { count: 10 },
			for: [e],
			secret: { cards: c[e] },
			...t > 0 ? { with: !0 } : {}
		}))
	};
}
function ne(e) {
	if (e.queue.length === 0 || e.pendingTake) return null;
	let { rid: t, card: n } = e.queue[0];
	e.queue = e.queue.slice(1);
	let r = -1;
	for (let t = 0; t < k; t += 1) {
		let i = e.rows[t][e.rows[t].length - 1];
		i < n && (r < 0 || i > e.rows[r][e.rows[r].length - 1]) && (r = t);
	}
	if (r < 0) return e.pendingTake = {
		rid: t,
		card: n
	}, {
		kind: "waitTake",
		rid: t,
		data: { card: n }
	};
	if (e.rows[r].length + 1 === 6) {
		let i = e.rows[r], a = i.reduce((e, t) => e + O(t), 0);
		return e.pen[t] += a, e.rows[r] = [n], {
			kind: "takeRow",
			rid: t,
			data: {
				card: n,
				row: r,
				taken: i,
				bulls: a
			}
		};
	}
	return e.rows[r] = [...e.rows[r], n], {
		kind: "place",
		rid: t,
		data: {
			card: n,
			row: r
		}
	};
}
function M(e) {
	e.queue.length > 0 || e.pendingTake || (e.round >= 10 ? e.phase = "done" : (e.round += 1, e.phase = "select", e.selected = {}));
}
function re(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "resolve" || e.pendingTake || e.queue.length === 0) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e), n = ne(t);
		return t.beatMs = n.kind === "takeRow" ? A.takeRow : A.place, M(t), {
			state: t,
			fx: [n]
		};
	}
	if (t.type === "select") {
		if (e.phase !== "select" || n.by in e.selected) return { code: "games.nimmt.errNotYourTurn" };
		if (!e.hands[n.by]?.includes(t.card)) return { code: "games.nimmt.errBadCard" };
		let r = structuredClone(e);
		return r.hands[n.by] = r.hands[n.by].filter((e) => e !== t.card), r.selected[n.by] = t.card, Object.keys(r.selected).length === r.players.length ? (r.queue = Object.entries(r.selected).map(([e, t]) => ({
			rid: e,
			card: t
		})).sort((e, t) => e.card - t.card), r.selected = {}, r.phase = "resolve", r.beatMs = j(r.queue.length), {
			state: r,
			fx: [{
				kind: "reveal",
				data: { cards: r.queue }
			}]
		}) : {
			state: r,
			fx: []
		};
	}
	let r = e.pendingTake;
	if (!r || r.rid !== n.by) return { code: "games.nimmt.errNotYourTurn" };
	if (t.row < 0 || t.row >= k) return { code: "games.nimmt.errBadRow" };
	let i = structuredClone(e), a = i.rows[t.row], o = a.reduce((e, t) => e + O(t), 0);
	return i.pen[n.by] += o, i.rows[t.row] = [r.card], i.pendingTake = null, i.beatMs = A.takeRow, M(i), {
		state: i,
		fx: [{
			kind: "takeRow",
			rid: n.by,
			data: {
				card: r.card,
				row: t.row,
				taken: a,
				bulls: o
			}
		}]
	};
}
function ie(e, t) {
	return {
		public: {
			rows: e.rows,
			round: e.round,
			phase: e.phase,
			players: e.players.map((t) => ({
				rid: t,
				picked: t in e.selected,
				pen: e.pen[t]
			})),
			queue: e.queue,
			pendingTake: e.pendingTake
		},
		private: {
			hand: e.hands[t] ?? [],
			mySelected: e.selected[t] ?? null
		}
	};
}
function ae(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.pen[t] - e.pen[n]), n = e.pen[t[0]];
	return {
		phase: "done",
		winner: t.filter((t) => e.pen[t] === n),
		ranking: t,
		scores: { ...e.pen }
	};
}
function oe(e) {
	return e.phase === "resolve" && !e.pendingTake && e.queue.length > 0 ? e.beatMs : null;
}
var se = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: C,
	schemas: {
		action: T,
		publicView: D,
		privateView: ee
	},
	setup: te,
	reduce: re,
	viewFor: ie,
	status: ae,
	nextTickIn: oe
};
//#endregion
//#region src/games/nimmt/bull-icon.tsx
function N({ size: e = 16, color: t = "var(--color-ink)", className: n }) {
	return /* @__PURE__ */ h("svg", {
		width: e,
		height: e,
		viewBox: "0 0 1858.875 1719.628",
		fill: "none",
		"aria-hidden": !0,
		className: n,
		children: /* @__PURE__ */ h("path", {
			d: "M147.481,59.837c17.026,11.111,155.055,130.45,137.791,255.92c-16.23,106.237-111.865,238.915-48.351,341.487\n          c11.418,18.488,19.75,28.967,37.416,28.222c44.255,1.681,142.288-61.329,260.401-89.654c14.004-3.761,18.445-1.637,23.115-12.401\n          c24.17-51.458,109.146-81.341,165.773-93.374c4.674-1.232,19.707-2.104,14.394-11.294c-3.218-4.474-9.467-6.814-48.517-21.275\n          c126.732-3.581,234.163,67.278,240.126,68.952c5.234-1.708,112.221-71.651,237.466-69.052l1.227-0.907\n          c-0.28,0.587-0.833,1.747-1.113,2.334c-4.579,0.582-30.845,11.139-35.969,13.268c-6.109,2.678-12.603,5.495-10.127,12.334\n          c2.737,5.954,11.183,2.631,55.478,16.408c30.856,8.171,100.504,36.221,123.583,80.606c10.4,19.836,0.386,1.366,103.228,38.623\n          c68.824,24.935,125.522,55.575,165.593,63.732c31.915,6.219,37.679-5.396,47.044-17.708c66.216-91.118-4.555-207.702-37.516-325.859\n          c-8.588-40.036-9.599-68.892,6.667-114.982c28.894-77.759,101.149-148.862,126.21-165.293\n          c-5.053,13.451-64.439,137.031-39.796,248.92c25.692,118.72,161.541,250.039,111.916,438.355\n          c-59.064,224.315-400.668,149.062-412.773,153.586c-0.867,0.387-2.16,0.667-1.953,1.893c-0.533,1.9,0.933,3.314,2.354,4.32\n          c9.862,7.506,204.095,90.128,210.543,94.908c-3.796,6.181-125.934,62.302-226.305,34.563c-3.42-0.9-6.707-2.333-10.201-2.854\n          c-13.298,4.087-4.443,5.937,19.842,74.353c31.362,95.621,44.881,208.72-49.991,240.619\n          c-105.68,36.24-147.093,133.889-198.502,148.152c-4.587,1.2-8.634,5.454-8.481,10.367c-0.16,13.541,5.452,77.522-35.843,117.196\n          c-16.655,16.895-39.496,26.355-62.572,30.402c-3.36,0.42-5.947,2.714-8.114,5.134H867.998\n          c-12.566-8.099-119.364-5.826-117.263-138.011c-0.028-20.126,4.295-20.281-12.481-26.409\n          c-49.952-17.807-86.345-108.642-198.922-148.485c-106.181-40.607-69.013-191.203-23.109-295.823c2.12-4.3,4.207-9.154,2.794-14.001\n          c-3.033-5.102-16.339-0.444-18.055,0.007c-41.355,10.743-86.369,8.705-128.417-0.593c-46.429-8.579-95.694-33.854-96.694-34.296\n          c176.799-79.832,209.573-88.888,207.57-98.055c-7.465-5.404-47.423,4.651-114.402,5.274\n          c-279.006-2.808-293.43-136.2-304.151-235.025c-12.935-236.169,219.457-292.494,87.56-602.914\n          C150.774,67.617,148.887,63.823,147.481,59.837z",
			fill: t,
			stroke: t,
			strokeLinejoin: "round",
			strokeWidth: 2,
			vectorEffect: "non-scaling-stroke"
		})
	});
}
//#endregion
//#region src/games/nimmt/card.tsx
var P = {
	low: {
		className: "nimmt-card--low",
		color: "var(--color-ink)"
	},
	mid: {
		className: "nimmt-card--mid",
		color: "var(--color-warn-ink)"
	},
	high: {
		className: "nimmt-card--high",
		color: "var(--color-danger)"
	}
};
function F(e) {
	return e >= 5 ? P.high : e >= 2 ? P.mid : P.low;
}
function I({ card: e, size: t, selected: n, elevated: r, style: i }) {
	let a = s(), o = O(e), c = F(o), l = t === "hand";
	return /* @__PURE__ */ g("span", {
		"aria-label": a("games.nimmt.bullAria", { n: o }),
		className: `nimmt-card ${l ? "nimmt-card--hand" : "nimmt-card--table"} ${c.className} ${r ? "nimmt-card--elevated" : ""} ${n ? "nimmt-card--selected" : ""}`,
		style: {
			"--nimmt-accent": C.accent,
			...i
		},
		children: [
			/* @__PURE__ */ h("span", {
				"aria-hidden": !0,
				className: "nimmt-card-watermark",
				children: /* @__PURE__ */ h(N, {
					size: l ? 52 : 36,
					color: c.color
				})
			}),
			/* @__PURE__ */ h("span", {
				"aria-hidden": !0,
				className: "nimmt-card-bulls",
				children: Array.from({ length: o }, (e, t) => /* @__PURE__ */ h(N, {
					size: l ? 8 : 6,
					color: c.color
				}, t))
			}),
			/* @__PURE__ */ h("span", {
				className: "nimmt-card-number",
				children: e
			}),
			l && /* @__PURE__ */ g("span", {
				"aria-hidden": !0,
				className: "nimmt-card-count",
				children: [
					/* @__PURE__ */ h(N, {
						size: 9,
						color: c.color
					}),
					"×",
					o
				]
			}),
			n && /* @__PURE__ */ h("span", {
				className: "nimmt-card-check",
				children: /* @__PURE__ */ h(v, { size: 10 })
			})
		]
	});
}
function L({ style: e } = {}) {
	return /* @__PURE__ */ h("span", {
		className: "nimmt-card-back",
		style: {
			"--nimmt-accent": C.accent,
			...e
		},
		children: /* @__PURE__ */ h("span", {
			"aria-hidden": !0,
			className: "nimmt-card-back-mark",
			children: /* @__PURE__ */ h(N, {
				size: 26,
				color: "var(--color-surface)"
			})
		})
	});
}
//#endregion
//#region src/games/nimmt/view-player.tsx
function ce(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ h(ue, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function le(e, t) {
	let n = -1;
	for (let r = 0; r < e.length; r += 1) {
		let i = e[r][e[r].length - 1];
		i < t && (n < 0 || i > e[n][e[n].length - 1]) && (n = r);
	}
	return n < 0 ? null : n;
}
function ue({ pub: e, priv: t, members: r, myRid: o, send: l }) {
	let p = s(), [m, _] = n(null), v = (e) => r.find((t) => t.rid === e)?.name ?? e, { ref: y } = i("table"), b = (t?.mySelected ?? null) !== null, x = e.pendingTake?.rid === o, S = e.phase === "select" && !b && m !== null && t?.hand.includes(m) ? m : null, w = S === null ? void 0 : le(e.rows, S), T = w === void 0 ? null : w === null ? p("games.nimmt.previewTake") : p("games.nimmt.previewRow", { n: w + 1 }), E, D;
	return e.phase === "resolve" ? e.pendingTake ? (E = x ? "warn" : "info", D = x ? p("games.nimmt.takeRowPrompt") : p("games.nimmt.takeRowWaiting", { name: v(e.pendingTake.rid) })) : (E = "info", D = p("games.nimmt.resolving")) : b ? (E = "info", D = p("games.nimmt.waitingPick")) : (E = "accent", D = p("games.nimmt.selectPrompt")), /* @__PURE__ */ h("div", {
		className: "nimmt-screen",
		"data-queue-rows": Math.ceil(e.players.length / 5),
		style: { "--nimmt-accent": C.accent },
		children: /* @__PURE__ */ h(u, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ g("div", {
				className: "nimmt-top flex flex-col gap-2",
				children: [/* @__PURE__ */ g("div", {
					className: "nimmt-phase",
					"data-tone": E,
					children: [/* @__PURE__ */ h(d, {
						tone: E,
						text: D,
						chip: p("games.nimmt.roundShort", {
							n: e.round,
							total: 10
						}),
						accent: "var(--color-jp-yellow)"
					}), /* @__PURE__ */ h("span", {
						className: "nimmt-phase-burst",
						"aria-hidden": !0,
						children: /* @__PURE__ */ h(N, { size: 23 })
					})]
				}), /* @__PURE__ */ h("div", {
					className: "nimmt-players",
					children: /* @__PURE__ */ h(f, {
						variant: "medal",
						members: r,
						myRid: o,
						anchorOf: (e) => `seat:${e}`,
						action: (t) => {
							if (e.phase !== "select") return null;
							let n = e.players.find((e) => e.rid === t);
							return n ? n.picked ? "done" : "pending" : null;
						},
						status: (t) => {
							let n = e.players.find((e) => e.rid === t);
							return n ? /* @__PURE__ */ g("span", {
								className: "nimmt-player-score flex items-center gap-0.5 text-xs font-bold",
								children: [/* @__PURE__ */ h(N, { size: 12 }), /* @__PURE__ */ h(a, {
									value: n.pen,
									className: "font-mono tabular-nums"
								})]
							}) : null;
						}
					})
				})]
			}),
			actionsHeight: "nimmt-actions h-44 short:h-28",
			actions: t && /* @__PURE__ */ g("div", {
				className: "nimmt-hand",
				children: [
					/* @__PURE__ */ h("span", {
						className: "nimmt-hand-count",
						children: p("games.nimmt.handCount", { n: t.hand.length })
					}),
					/* @__PURE__ */ h("div", {
						className: "nimmt-hand-scroll",
						children: /* @__PURE__ */ g("div", {
							className: "nimmt-hand-cards",
							children: [b && t.mySelected !== null && /* @__PURE__ */ h(I, {
								card: t.mySelected,
								size: "hand",
								selected: !0,
								elevated: !0
							}), t.hand.map((t) => /* @__PURE__ */ h("button", {
								type: "button",
								className: "nimmt-hand-card",
								disabled: b || e.phase !== "select",
								"aria-pressed": S === t,
								"aria-label": p(S === t ? "games.nimmt.cancelPreviewAria" : "games.nimmt.previewCardAria", { n: t }),
								onClick: () => _(S === t ? null : t),
								children: /* @__PURE__ */ h(H, {
									card: t,
									size: "hand",
									selected: S === t,
									elevated: !0
								})
							}, t))]
						})
					}),
					S !== null && /* @__PURE__ */ h("button", {
						type: "button",
						className: "nimmt-confirm",
						onClick: () => {
							S !== null && (l({
								type: "select",
								card: S
							}), _(null));
						},
						children: p("games.nimmt.playCardAria", { n: S })
					})
				]
			}),
			overlay: T && /* @__PURE__ */ h("div", {
				className: "nimmt-preview-note",
				children: T
			}),
			children: /* @__PURE__ */ g("div", {
				ref: y,
				className: "nimmt-board",
				children: [/* @__PURE__ */ h(c, {
					kind: "sheen",
					base: "var(--color-jp-yellow)",
					className: "absolute inset-0 size-full"
				}), /* @__PURE__ */ h("div", {
					className: "nimmt-board-scroll",
					children: /* @__PURE__ */ g("div", {
						className: "nimmt-board-inner",
						children: [
							/* @__PURE__ */ g("div", {
								className: "nimmt-brand",
								"aria-hidden": !0,
								children: [/* @__PURE__ */ h(N, {
									size: 13,
									color: "var(--color-surface)"
								}), "6!"]
							}),
							e.rows.map((e, t) => /* @__PURE__ */ h(R, {
								row: e,
								index: t,
								tappable: x,
								preview: w === t,
								onTake: () => l({
									type: "takeRow",
									row: t
								})
							}, t)),
							/* @__PURE__ */ h(B, {
								pub: e,
								members: r
							})
						]
					})
				})]
			})
		})
	});
}
function R({ row: e, index: t, tappable: n, preview: r, onTake: a }) {
	let o = s(), { ref: c } = i(`row:${t}`), l = e.reduce((e, t) => e + O(t), 0), u = e.length === 5;
	return /* @__PURE__ */ g("button", {
		ref: c,
		type: "button",
		disabled: !n,
		"aria-label": n ? o("games.nimmt.takeRowChoiceAria", {
			n: t + 1,
			bulls: l
		}) : void 0,
		onClick: a,
		className: `nimmt-row ${n ? "nimmt-row--take" : ""} ${r ? "nimmt-row--preview" : ""}`,
		children: [/* @__PURE__ */ g("span", {
			className: "nimmt-row-score",
			children: [/* @__PURE__ */ h("strong", { children: t + 1 }), /* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h(N, { size: 10 }), l] })]
		}), /* @__PURE__ */ h("span", {
			className: "nimmt-track",
			children: Array.from({ length: 6 }, (n, i) => /* @__PURE__ */ h(z, {
				rowIndex: t,
				slotIndex: i,
				card: e[i],
				next: i === e.length,
				preview: r && i === e.length,
				hot: u
			}, i))
		})]
	});
}
function z({ rowIndex: e, slotIndex: t, card: n, next: r, preview: a, hot: o }) {
	let { ref: s } = i(`rslot:${e}:${t}`), c = t === 5;
	return /* @__PURE__ */ g("span", {
		ref: s,
		className: `nimmt-cell ${n === void 0 ? "" : "nimmt-cell--filled"} ${c ? "nimmt-cell--danger" : ""} ${c && o ? "nimmt-cell--hot" : ""} ${a ? "nimmt-cell--preview" : ""}`,
		children: [
			c && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(N, {
				size: 20,
				color: "currentColor"
			}), /* @__PURE__ */ h("span", { children: "6" })] }),
			r && !c && /* @__PURE__ */ h("span", {
				className: "nimmt-next",
				children: a ? "↘" : "+"
			}),
			n !== void 0 && /* @__PURE__ */ h(H, {
				card: n,
				size: "table",
				className: "absolute inset-0"
			})
		]
	});
}
function B({ pub: e, members: t }) {
	let { ref: n } = i("queue"), r = /* @__PURE__ */ new Map();
	for (let t of e.queue) r.set(t.rid, t.card);
	e.pendingTake && r.set(e.pendingTake.rid, e.pendingTake.card);
	let a = new Set(e.players.map((e) => e.rid)), o = t.filter((e) => a.has(e.rid)).map((e) => e.rid), s = [...o, ...e.players.map((e) => e.rid).filter((e) => !o.includes(e))];
	return /* @__PURE__ */ h("ul", {
		ref: n,
		className: "nimmt-queue",
		style: {
			"--nimmt-queue-columns": Math.min(5, s.length),
			"--nimmt-queue-rows": Math.ceil(s.length / 5)
		},
		children: s.map((n) => {
			let i = t.find((e) => e.rid === n), a = e.players.find((e) => e.rid === n)?.picked ?? !1;
			return /* @__PURE__ */ h(V, {
				rid: n,
				member: i,
				picked: a,
				revealedCard: r.get(n)
			}, n);
		})
	});
}
function V({ rid: e, member: t, picked: n, revealedCard: a }) {
	let { ref: o } = i(`qslot:${e}`), s = n || a !== void 0, c = l[(t?.colorIndex ?? 0) % l.length];
	return /* @__PURE__ */ h("li", {
		className: "flex-none",
		children: /* @__PURE__ */ g("span", {
			ref: o,
			className: "nimmt-qslot",
			children: [a === void 0 ? n ? /* @__PURE__ */ h(L, {}) : /* @__PURE__ */ h("span", {
				"aria-hidden": !0,
				className: "nimmt-qslot-empty"
			}) : /* @__PURE__ */ h("span", {
				className: "card-flip-in",
				children: /* @__PURE__ */ h(H, {
					card: a,
					size: "table"
				})
			}), t && /* @__PURE__ */ h("img", {
				src: r[t.avatar % r.length],
				alt: "",
				draggable: !1,
				className: `nimmt-qslot-avatar ${s ? "" : "opacity-45"}`,
				style: { backgroundColor: c.hex }
			})]
		})
	});
}
function H({ card: e, size: t, elevated: n, selected: r, className: a, style: o }) {
	let { ref: s, hidden: c } = i(`card:${e}`);
	return /* @__PURE__ */ h("span", {
		ref: s,
		className: `inline-flex ${a ?? ""}`,
		style: {
			...o,
			visibility: c ? "hidden" : void 0
		},
		children: /* @__PURE__ */ h(I, {
			card: e,
			size: t,
			elevated: n,
			selected: r
		})
	});
}
//#endregion
//#region src/games/nimmt/bot.ts
var U = 4, de = (e) => 5 - e.length;
function W(e, t) {
	let n = 0, r = e.length;
	for (; n < r;) {
		let i = n + r >> 1;
		e[i] < t ? n = i + 1 : r = i;
	}
	return n;
}
function G(e) {
	return e.reduce((e, t) => e + O(t), 0);
}
function K(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function fe(e, t, n, r) {
	if (t <= 0) return 1;
	if (e <= 0 || n <= 0) return 0;
	let i = e / r;
	if (i >= 1) return 1;
	let a = 1 - i, o = a ** n, s = 0;
	for (let e = 0; e < t; e += 1) s += o, o *= (n - e) / (e + 1) * (i / a);
	return 1 - s;
}
var pe = {
	noTargetBias: .25,
	fullRowFactor: 1,
	bullsExp: 1,
	probExp: 1,
	riskScale: 1,
	lowCardBias: 0,
	takeRowLenW: 0,
	seenCorrW: 0,
	followUpFactor: .8,
	endgameW: 0
};
function me(e = pe) {
	return (t, n) => {
		let r = t.public, i = t.private?.hand ?? [];
		if (r.pendingTake) {
			if (r.pendingTake.rid !== n.rid) return null;
			if (n.difficulty === "weak") return { action: {
				type: "takeRow",
				row: K([
					0,
					1,
					2,
					3
				])
			} };
			let t = 0, i = Infinity;
			for (let n = 0; n < U; n += 1) {
				let a = G(r.rows[n]) + e.takeRowLenW * r.rows[n].length;
				a < i && (i = a, t = n);
			}
			return { action: {
				type: "takeRow",
				row: t
			} };
		}
		if (r.phase !== "select" || t.private?.mySelected != null || i.length === 0) return null;
		if (n.difficulty === "weak") return { action: {
			type: "select",
			card: K(i)
		} };
		let a = r.rows.flat(), o = n.memory, s = new Set(o?.everSeen), c = o === void 0;
		for (let e of a) s.has(e) || (s.add(e), c = !0);
		let l = new Set(a), u = [...s].filter((e) => !l.has(e)).sort((e, t) => e - t), d = r.players.length - 1, f = 104 - i.length - a.length, p = Math.max(f - e.seenCorrW * u.length, d), m = e.riskScale * (1 + e.endgameW * (r.round - 1) / 9), h = new Set(i), g = Math.min(...r.rows.map(G)), _ = i[0], v = Infinity;
		for (let t of i) {
			let n = -1;
			for (let e = 0; e < U; e += 1) {
				let i = r.rows[e][r.rows[e].length - 1];
				i < t && (n < 0 || i > r.rows[n][r.rows[n].length - 1]) && (n = e);
			}
			let i;
			if (n < 0) i = g ** e.bullsExp + e.noTargetBias;
			else {
				let a = r.rows[n], o = de(a), s = G(a) ** e.bullsExp;
				if (o <= 0) i = e.fullRowFactor * s;
				else {
					let n = a[a.length - 1], r = e.seenCorrW > 0 ? W(u, t) - W(u, n + 1) : 0, c = t - n - 1 - e.seenCorrW * r;
					i = m * s * fe(c, o, d, p) ** e.probExp;
				}
			}
			let a = 0;
			for (; a < 3 && h.has(t + 1 + a);) a += 1;
			a > 0 && (i *= e.followUpFactor ** a), i += e.lowCardBias * t, i < v && (v = i, _ = t);
		}
		return {
			action: {
				type: "select",
				card: _
			},
			...c ? { memory: { everSeen: [...s] } } : {}
		};
	};
}
var he = me(), ge = (e, t, n) => e.type === "takeRow" ? n("games.nimmt.takeRowAria", { n: e.row + 1 }) : e.type === "select" ? n("games.nimmt.playCardAria", { n: e.card }) : "", _e = (e) => e.reduce((e, t) => e + O(t), 0), ve = {
	needsAction(e, t) {
		let n = e.public;
		return n.pendingTake ? n.pendingTake.rid === t.rid : n.phase === "select" && e.private?.mySelected == null && (e.private?.hand.length ?? 0) > 0;
	},
	describeView(e, t) {
		let n = e.public, r = [`第 ${n.round} 轮。桌面四行牌(每行满 5 张后,放第 6 张的人收走整行):`];
		n.rows.forEach((e, t) => {
			r.push(`行 ${t}: ${e.join(", ")}(共 ${_e(e)} 个牛头)`);
		});
		let i = e.private?.hand ?? [];
		return r.push(`你的手牌: ${i.join(", ")}`), n.pendingTake ? n.pendingTake.rid === t.rid ? r.push(`你打出的 ${n.pendingTake.card} 比所有行尾都小,现在必须选一行收走。输出 takeRow 行动。`) : r.push("有玩家正在选行收牌,暂时轮不到你。") : n.phase === "select" ? e.private?.mySelected == null ? r.push("现在是从手牌暗选一张打出的阶段,输出 select 行动。") : r.push(`你已暗选了 ${e.private.mySelected},等其他玩家选牌,无需行动。`) : r.push("当前无需你行动。"), r.push(`各玩家罚分(牛头越少越好): ${n.players.map((e) => `${e.rid === t.rid ? "你" : e.rid}=${e.pen}`).join(", ")}`), r.join("\n");
	},
	actionJsonSchema: { oneOf: [{
		type: "object",
		properties: {
			type: { const: "select" },
			card: {
				type: "integer",
				minimum: 1,
				maximum: 104,
				description: "必须从手牌中选"
			}
		},
		required: ["type", "card"],
		additionalProperties: !1
	}, {
		type: "object",
		properties: {
			type: { const: "takeRow" },
			row: {
				type: "integer",
				minimum: 0,
				maximum: 3
			}
		},
		required: ["type", "row"],
		additionalProperties: !1
	}] },
	parseAction(e) {
		let t = T.safeParse(e);
		return t.success ? t.data.type === "tick" ? null : t.data : null;
	}
}, q = 44, J = 64;
function Y(e, t = q, n = J) {
	let r = e.anchor("table");
	return r ? {
		x: r.x + r.w / 2 - t / 2,
		y: r.y + r.h / 2 - n / 2,
		w: t,
		h: n
	} : null;
}
function X(e) {
	return e.anchor("rslot:0:0");
}
function Z(e, t = "table") {
	return {
		[`--nimmt-${t}-w`]: `${e.w}px`,
		[`--nimmt-${t}-h`]: `${e.h}px`
	};
}
function ye(e) {
	let t = e.anchor("queue");
	if (!t) return null;
	let n = X(e), r = n?.w ?? q, i = n?.h ?? J;
	return {
		x: t.x + t.w / 2 - r / 2,
		y: t.y + t.h / 2 - i / 2,
		w: r,
		h: i
	};
}
function Q(e, t) {
	return (t ? e.anchor(`qslot:${t}`) : null) ?? ye(e) ?? Y(e);
}
function $(e, t, n, r) {
	return e.anchor(`rslot:${n}:${r}`) ?? {
		x: t.x + 44 + r * 48,
		y: t.y + (t.h - J) / 2,
		w: q,
		h: J
	};
}
var be = {
	deal(e, t) {
		let n = e.secret;
		if (n && Array.isArray(n.cards)) {
			let e = [], r = [];
			for (let [i, a] of n.cards.entries()) {
				let n = t.anchor(`card:${a}`);
				if (!n) continue;
				let o = Y(t, n.w, n.h);
				o && (r.push(`card:${a}`), e.push(/* @__PURE__ */ h(b, {
					from: o,
					to: n,
					ms: 320,
					delay: i * 45,
					children: /* @__PURE__ */ h(I, {
						card: a,
						size: "hand",
						elevated: !0,
						style: Z(n, "hand")
					})
				}, a)));
			}
			return e.length ? {
				ms: 320 + e.length * 45,
				node: e,
				hide: r
			} : null;
		}
		let r = X(t), i = Y(t, r?.w, r?.h), a = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		if (!i || !a) return null;
		let o = e.data?.count, s = typeof o == "number" ? o : 10;
		return {
			ms: 320 + s * 45,
			node: Array.from({ length: s }, (e, t) => /* @__PURE__ */ h(b, {
				from: i,
				to: a,
				ms: 320,
				delay: t * 45,
				children: /* @__PURE__ */ h(L, { style: Z(i) })
			}, t))
		};
	},
	reveal(e) {
		let t = e.data?.cards;
		return !Array.isArray(t) || !t.length ? null : {
			ms: j(t.length),
			node: null
		};
	},
	place(e, t) {
		let n = e.data;
		if (typeof n?.card != "number") return null;
		let r = t.anchor(`card:${n.card}`), i = Q(t, e.rid);
		return !r || !i ? null : {
			ms: A.place,
			node: /* @__PURE__ */ h(b, {
				from: i,
				to: r,
				ms: 380,
				children: /* @__PURE__ */ h(I, {
					card: n.card,
					size: "table",
					style: Z(i)
				})
			}),
			hide: [`card:${n.card}`]
		};
	},
	takeRow(e, t) {
		let n = e.data;
		if (typeof n?.card != "number" || typeof n.row != "number" || !Array.isArray(n.taken) || typeof n.bulls != "number") return null;
		let r = t.anchor(`row:${n.row}`), i = e.rid ? t.anchor(`seat:${e.rid}`) : null, a = Q(t, e.rid);
		if (!r || !i || !a) return null;
		let o = n.taken, s = n.row;
		return {
			ms: A.takeRow,
			hide: [`card:${n.card}`],
			node: /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h(b, {
					from: a,
					to: $(t, r, s, o.length),
					ms: 360,
					children: /* @__PURE__ */ h(I, {
						card: n.card,
						size: "table",
						style: Z(a)
					})
				}),
				o.map((e, n) => /* @__PURE__ */ h(b, {
					from: $(t, r, s, n),
					to: i,
					ms: 420,
					delay: 440 + n * 40,
					children: /* @__PURE__ */ h(I, {
						card: e,
						size: "table",
						style: Z($(t, r, s, n))
					})
				}, e)),
				/* @__PURE__ */ h(y, {
					at: i,
					ms: 800,
					delay: 590,
					children: /* @__PURE__ */ g("span", {
						className: "inline-flex items-center gap-0.5",
						children: [
							"+",
							n.bulls,
							/* @__PURE__ */ h(N, { size: 13 })
						]
					})
				})
			] })
		};
	},
	waitTake(e, t) {
		let n = e.data, r = typeof n?.card == "number" ? t.anchor(`card:${n.card}`) : null;
		return r ? {
			ms: 900,
			node: /* @__PURE__ */ h(x, {
				at: r,
				ms: 900
			})
		} : null;
	}
};
//#endregion
//#region src/games/nimmt/game-over.tsx
function xe({ result: e, public: t, members: n, myRid: i, onPlayAgain: a, onBackToLobby: c }) {
	let u = s(), d = o((e) => e.locale), f = t, m = a ?? c;
	return /* @__PURE__ */ h("div", {
		className: "nimmt-result",
		"data-many": e.ranking.length > 5,
		style: { "--nimmt-accent": C.accent },
		children: /* @__PURE__ */ g("div", {
			className: "nimmt-result-layout",
			children: [
				e.winner.length > 0 && /* @__PURE__ */ h(S, {}),
				/* @__PURE__ */ g("h1", {
					className: "nimmt-result-title",
					children: [/* @__PURE__ */ h(N, { size: 30 }), u("session.result.title")]
				}),
				/* @__PURE__ */ g("div", {
					className: "nimmt-result-body",
					children: [/* @__PURE__ */ h("ol", {
						className: "nimmt-result-ranking",
						children: e.ranking.map((t, a) => {
							let o = n.find((e) => e.rid === t), s = o ? p(o, d) : t, c = e.scores?.[t] ?? f.players.find((e) => e.rid === t)?.pen ?? 0, m = e.winner.includes(t), v = e.autopilot?.[t];
							return /* @__PURE__ */ g("li", {
								className: "nimmt-result-player",
								"data-winner": m,
								children: [
									m && /* @__PURE__ */ h("span", {
										className: "nimmt-result-cup",
										"aria-hidden": !0,
										children: "🏆"
									}),
									/* @__PURE__ */ h("span", {
										className: "nimmt-result-avatar",
										style: { backgroundColor: l[(o?.colorIndex ?? 0) % l.length].hex },
										children: o && /* @__PURE__ */ h("img", {
											src: r[o.avatar % r.length],
											alt: "",
											draggable: !1
										})
									}),
									/* @__PURE__ */ g("div", {
										className: "nimmt-result-person",
										children: [
											/* @__PURE__ */ g("strong", { children: [
												a + 1,
												". ",
												s,
												t === i && /* @__PURE__ */ h("small", { children: u("lobby.you") })
											] }),
											/* @__PURE__ */ g("span", {
												className: "nimmt-result-penalty",
												"aria-label": u("games.nimmt.bullAria", { n: c }),
												children: [/* @__PURE__ */ h(N, { size: 24 }), /* @__PURE__ */ h("b", { children: c })]
											}),
											v !== void 0 && v > 0 && /* @__PURE__ */ g("small", {
												className: "nimmt-result-autopilot",
												children: [/* @__PURE__ */ h(_, { size: 14 }), u("session.autopilot.share", { n: Math.round(v * 100) })]
											})
										]
									})
								]
							}, t);
						})
					}), /* @__PURE__ */ g("section", {
						className: "nimmt-result-table",
						children: [/* @__PURE__ */ h("h2", { children: u("games.nimmt.resultTable") }), /* @__PURE__ */ h("ol", {
							className: "nimmt-result-lanes",
							children: f.rows.map((e, t) => /* @__PURE__ */ g("li", {
								className: "nimmt-result-lane",
								children: [/* @__PURE__ */ g("span", {
									className: "nimmt-result-row-index",
									children: [t + 1, /* @__PURE__ */ g("small", {
										"aria-label": u("games.nimmt.bullAria", { n: e.reduce((e, t) => e + O(t), 0) }),
										children: [/* @__PURE__ */ h(N, { size: 12 }), e.reduce((e, t) => e + O(t), 0)]
									})]
								}), /* @__PURE__ */ h("div", {
									className: "nimmt-result-cards",
									children: e.map((e) => /* @__PURE__ */ h(I, {
										card: e,
										size: "table"
									}, e))
								})]
							}, t))
						})]
					})]
				}),
				m ? /* @__PURE__ */ g("div", {
					className: "nimmt-result-controls safe-b",
					children: [a && /* @__PURE__ */ h("button", {
						type: "button",
						className: "btn-base text-white",
						style: { background: C.accent },
						onClick: a,
						children: u("session.result.playAgain")
					}), c && /* @__PURE__ */ h("button", {
						type: "button",
						className: "btn-quiet",
						onClick: c,
						children: u("session.result.backToLobby")
					})]
				}) : /* @__PURE__ */ h("p", {
					className: "nimmt-result-wait safe-b",
					children: u("session.result.waitHost")
				})
			]
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/nimmt/entry.tsx
var Se = {
	definition: se,
	View: ce,
	bot: he,
	describe: ge,
	llm: ve,
	fx: be,
	OverView: xe,
	locales: {
		zh: {
			name: "谁是牛头王",
			desc: "从小到大地接牌,谁吃牛少谁赢",
			rules: "目标:十轮结束后,收取卡牌上的牛头总数最少的玩家获胜。\n准备:\n· 牌共 104 张,每人 10 张手牌,桌面翻出 4 张作为四行的行首。\n· 每张牌印有牛头,收走的牌按牛头数计罚分。\n牛头数量如下：\n· 个位数为 5 的卡牌印有 2 个牛头。\n· 整十数卡牌印有 3 个牛头。\n· 两位数字相同的卡牌，如 11、22 等，印有 5 个牛头。\n· 55 号牌印有 7 个牛头。\n· 其余卡牌印有 1 个牛头。\n流程:\n· 每轮所有人同时暗选一张手牌打出,再按点数从小到大依次落位。\n· 落位规则:接到「行尾点数比它小、且与它最接近」的那一行末尾。\n· 打出的牌比四个行尾都小时,必须任选一行收走,打出的牌成为该行新行首。\n· 某一行将放入第 6 张牌时,先收走该行已有的 5 张,新牌成为行首。\n结束:\n· 十轮后结算,罚分最少者获胜;平分则并列获胜。",
			round: "第 {{n}} 轮",
			roundShort: "{{n}}/{{total}}",
			selectPrompt: "选一张牌打出",
			waitingPick: "已出牌,等其他人…",
			resolving: "结算中…",
			takeRowPrompt: "你的牌太小了,选一行收走",
			takeRowWaiting: "等 {{name}} 收牌…",
			playCardAria: "打出 {{n}}",
			previewCardAria: "预览 {{n}}",
			cancelPreviewAria: "取消预览 {{n}}",
			previewRow: "预计接入第 {{n}} 行 · 结果可能变化",
			previewTake: "可能需收行 · 结果可能变化",
			handCount: "手牌 {{n}}",
			takeRowAria: "收走第 {{n}} 行",
			takeRowChoiceAria: "收走第 {{n}} 行，增加 {{bulls}} 个牛头",
			bullAria: "{{n}} 个牛头",
			resultTable: "最终牌桌",
			errNotYourTurn: "现在轮不到你",
			errBadCard: "这张牌不在你手里",
			errBadRow: "这行不能收"
		},
		en: {
			name: "6 Nimmt",
			desc: "Play cards in order — fewest bullheads wins",
			rules: "Goal: after ten rounds, whoever has collected the fewest bullheads wins.\nSetup:\n· The deck has 104 cards. Each player holds 10 cards, and 4 cards are dealt face-up as the heads of the four rows.\n· Every card shows bullheads; cards you take score their bullheads against you.\nBullhead counts are as follows:\n· Cards ending in 5 show 2 bullheads.\n· Multiples of 10 show 3 bullheads.\n· Cards with two identical digits, such as 11 or 22, show 5 bullheads.\n· Card 55 shows 7 bullheads.\n· All other cards show 1 bullhead.\nPlay:\n· Each round everyone secretly picks one card, then the cards are placed in ascending order.\n· A card goes to the end of the row whose tail is lower than it and closest to it.\n· If your card is lower than all four row tails, you must take a whole row, and your card becomes its new head.\n· If a card would become the 6th card of a row, the 5 cards already there are taken first, and the new card becomes the row head.\nEnd:\n· After ten rounds the fewest bullheads wins; tied players share the win.",
			round: "Round {{n}}",
			roundShort: "{{n}}/{{total}}",
			selectPrompt: "Pick a card to play",
			waitingPick: "Card played — waiting for others…",
			resolving: "Resolving…",
			takeRowPrompt: "Too low! Pick a row to take",
			takeRowWaiting: "Waiting for {{name}} to take a row…",
			playCardAria: "Play {{n}}",
			previewCardAria: "Preview {{n}}",
			cancelPreviewAria: "Cancel preview of {{n}}",
			previewRow: "Likely row {{n}} · may change",
			previewTake: "May need to take a row · may change",
			handCount: "{{n}} cards",
			takeRowAria: "Take row {{n}}",
			takeRowChoiceAria: "Take row {{n}} for {{bulls}} bull heads",
			bullAria: "{{n}} bull heads",
			resultTable: "Final table",
			errNotYourTurn: "Not your move right now",
			errBadCard: "That card is not in your hand",
			errBadRow: "Can't take that row"
		}
	}
};
//#endregion
export { Se as default };
