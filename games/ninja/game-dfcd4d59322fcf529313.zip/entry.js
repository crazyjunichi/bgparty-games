import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { createPortal as r } from "react-dom";
import { botAvatarOf as i } from "@bgparty/sdk/lobby";
import { AVATARS as a } from "@bgparty/sdk/avatars";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { avatarNameAt as c, useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { IconBot as d, IconDisconnected as f } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as p } from "@bgparty/sdk/player-colors";
import { GameScreen as m } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as h } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as g, jsx as _, jsxs as v } from "react/jsx-runtime";
import { Floater as y, FlySprite as b, PulseBox as x } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as S } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/ninja/cards.ts
var C = [
	"spy",
	"mystic",
	"trickster",
	"assassin",
	"shinobi"
], w = (() => {
	let e = [], t = 1;
	for (let n of C) for (let r = 1; r <= 6; r += 1) e.push({
		id: t++,
		kind: n,
		rank: r
	});
	return e.push({
		id: 31,
		kind: "monk",
		rank: 0
	}, {
		id: 32,
		kind: "martyr",
		rank: 0
	}, {
		id: 33,
		kind: "mastermind",
		rank: 0
	}), e;
})();
function T(e) {
	let t = w[e - 1];
	if (!t) throw Error(`bad card id ${e}`);
	return t;
}
var E = {
	1: "games.ninja.card.trickster1",
	2: "games.ninja.card.trickster2",
	3: "games.ninja.card.trickster3",
	4: "games.ninja.card.trickster4",
	5: "games.ninja.card.trickster5",
	6: "games.ninja.card.trickster6"
}, D = {
	spy: "games.ninja.card.spy",
	mystic: "games.ninja.card.mystic",
	trickster: "games.ninja.card.trickster1",
	assassin: "games.ninja.card.assassin",
	shinobi: "games.ninja.card.shinobi",
	monk: "games.ninja.card.monk",
	martyr: "games.ninja.card.martyr",
	mastermind: "games.ninja.card.mastermind"
};
function O(e) {
	return e.kind === "trickster" ? E[e.rank] : D[e.kind];
}
var k = {
	spy: "games.ninja.eff.spy",
	mystic: "games.ninja.eff.mystic",
	trickster: "games.ninja.eff.trickster1",
	assassin: "games.ninja.eff.assassin",
	shinobi: "games.ninja.eff.shinobi",
	monk: "games.ninja.eff.monk",
	martyr: "games.ninja.eff.martyr",
	mastermind: "games.ninja.eff.mastermind"
}, A = {
	1: "games.ninja.eff.trickster1",
	2: "games.ninja.eff.trickster2",
	3: "games.ninja.eff.trickster3",
	4: "games.ninja.eff.trickster4",
	5: "games.ninja.eff.trickster5",
	6: "games.ninja.eff.trickster6"
};
function j(e) {
	return e.kind === "trickster" ? A[e.rank] : k[e.kind];
}
function M(e) {
	let t = Math.floor(e / 2), n = [];
	for (let e = 1; e <= t; e += 1) n.push({
		house: "crane",
		rank: e
	}, {
		house: "lotus",
		rank: e
	});
	return e % 2 == 1 && n.push({
		house: "ronin",
		rank: 0
	}), n;
}
var N = [
	...Array(14).fill(2),
	...Array(14).fill(3),
	...Array(7).fill(4)
], P = {
	spy: "🕵️",
	mystic: "🔮",
	trickster: "🎭",
	assassin: "🌫️",
	shinobi: "🗡️",
	monk: "🪞",
	martyr: "🕯️",
	mastermind: "👑"
}, F = {
	crane: "🪶",
	lotus: "🪷",
	ronin: "⚔️"
}, I = {
	crane: "games.ninja.houseCrane",
	lotus: "games.ninja.houseLotus",
	ronin: "games.ninja.houseRonin"
}, ee = {
	spy: "games.ninja.stageSpy",
	mystic: "games.ninja.stageMystic",
	trickster: "games.ninja.stageTrickster",
	assassin: "games.ninja.stageAssassin",
	shinobi: "games.ninja.stageShinobi"
}, L = {
	id: "ninja",
	tier: "alpha",
	mechanics: ["drafting"],
	interactionTags: ["hidden-roles", "team-based"],
	nameKey: "games.ninja.name",
	descKey: "games.ninja.desc",
	rulesKey: "games.ninja.rules",
	icon: "🥷",
	iconImg: "games/ninja.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/ninja/en.pdf" },
	minPlayers: 4,
	maxPlayers: 11,
	bestPlayers: [
		6,
		7,
		8
	],
	accent: "#7c3aed",
	releasedAt: "2026-09-15",
	search: {
		py: "ren zhe zhi ye",
		init: "rzzy"
	},
	hotseat: "cover"
}, R = t.string(), z = t.int().min(1).max(33), B = t.object({
	house: t.enum([
		"crane",
		"lotus",
		"ronin"
	]),
	rank: t.int().min(0).max(5)
}), te = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("draftPick"),
		cardId: z
	}),
	t.object({
		type: t.literal("play"),
		targets: t.array(R)
	}),
	t.object({ type: t.literal("skip") }),
	t.object({
		type: t.literal("shinobiKill"),
		kill: t.boolean()
	}),
	t.object({
		type: t.literal("shapeshiftSwap"),
		swap: t.boolean()
	}),
	t.object({
		type: t.literal("troubleReveal"),
		reveal: t.boolean()
	}),
	t.object({
		type: t.literal("merchantPeek"),
		what: t.enum(["house", "token"]),
		tokenIndex: t.int().nonnegative().optional()
	}),
	t.object({
		type: t.literal("merchantSwap"),
		mine: t.int().nonnegative().nullable(),
		theirs: t.int().nonnegative().nullable()
	}),
	t.object({
		type: t.literal("thiefPick"),
		target: R.nullable(),
		tokenIndex: t.int().nonnegative().optional()
	}),
	t.object({
		type: t.literal("gravePeek"),
		indices: t.tuple([t.int().nonnegative(), t.int().nonnegative()])
	}),
	t.object({
		type: t.literal("graveTake"),
		cardId: z,
		mode: t.enum(["now", "keep"])
	}),
	t.object({
		type: t.literal("react"),
		card: t.enum(["monk", "martyr"]).nullable()
	}),
	t.object({ type: t.literal("confirm") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), ne = t.enum([
	"prompt",
	"shinobiDecide",
	"shapeshiftDecide",
	"troubleDecide",
	"merchantPeek",
	"merchantSwap",
	"thiefChoose",
	"gravePeek",
	"graveTake",
	"react"
]), re = t.discriminatedUnion("via", [
	t.object({
		round: t.int().min(1),
		via: t.enum([
			"spy",
			"mystic",
			"shinobi",
			"troublemaker",
			"shapeshifter",
			"merchant"
		]),
		about: R,
		house: B
	}),
	t.object({
		round: t.int().min(1),
		via: t.literal("mysticCard"),
		about: R,
		cardId: z
	}),
	t.object({
		round: t.int().min(1),
		via: t.literal("gravedigger"),
		cardIds: t.tuple([z, z])
	}),
	t.object({
		round: t.int().min(1),
		via: t.literal("merchantToken"),
		about: R,
		value: t.int()
	})
]), ie = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("prompt"),
		cardId: z,
		fromGrave: t.boolean()
	}),
	t.object({
		kind: t.literal("shinobi"),
		target: R,
		house: B
	}),
	t.object({
		kind: t.literal("shapeshift"),
		targets: t.tuple([R, R]),
		houses: t.tuple([B, B])
	}),
	t.object({
		kind: t.literal("trouble"),
		target: R,
		house: B
	}),
	t.object({
		kind: t.literal("graveTake"),
		cards: t.array(z).min(1).max(2)
	}),
	t.object({
		kind: t.literal("merchantPeek"),
		target: R
	}),
	t.object({
		kind: t.literal("merchantSwap"),
		target: R,
		seenHouse: B.nullable(),
		seenToken: t.object({
			index: t.int().nonnegative(),
			value: t.int()
		}).nullable()
	}),
	t.object({ kind: t.literal("gravePeek") }),
	t.object({ kind: t.literal("thiefChoose") }),
	t.object({
		kind: t.literal("react"),
		attacker: R
	})
]), ae = t.object({
	round: t.int().min(1),
	phase: t.enum([
		"draft1",
		"draft2",
		"night",
		"reveal",
		"roundEnd",
		"done"
	]),
	night: t.object({
		stage: t.int().min(0).max(4),
		rank: t.int().min(1).max(6)
	}).nullable(),
	pending: t.object({
		kind: ne,
		actor: R
	}).nullable(),
	players: t.array(t.object({
		rid: R,
		alive: t.boolean(),
		honorCount: t.int().nonnegative(),
		played: t.array(z),
		house: B.nullable()
	})),
	draftPicked: t.array(R),
	discardCount: t.int().nonnegative(),
	tokensLeft: t.int().nonnegative(),
	confirmed: t.array(R),
	lastRound: t.object({
		winnerHouse: t.enum(["crane", "lotus"]).nullable(),
		awarded: t.array(R),
		mastermindBy: R.nullable()
	}).nullable()
}), oe = t.object({
	houseKnown: B.nullable(),
	hand: t.array(z),
	draftHand: t.array(z),
	honor: t.array(t.int()),
	intel: t.array(re),
	peek: ie.nullable()
});
//#endregion
//#region src/games/ninja/rules.ts
function V(t, n, r) {
	for (let i = t.length - 1; i > 0; --i) {
		let a = e(n, r.at, i + 1);
		r.at += 1, [t[i], t[a]] = [t[a], t[i]];
	}
	return t;
}
function H(t) {
	let n = t.tokens.pop();
	if (n !== void 0) return n;
	let r = 2 + e(t.seed, t.rngCursor, 3);
	return t.rngCursor += 1, r;
}
function U(e) {
	return e.honor.reduce((e, t) => e + t, 0);
}
function W(e) {
	let t = { at: e.rngCursor }, n = V(M(e.players.length), e.seed, t), r = V(w.map((e) => e.id), e.seed, t);
	e.rngCursor = t.at;
	let i = [];
	return e.players.forEach((t, a) => {
		let o = e.per[t];
		o.house = n[a], o.houseKnown = n[a], o.alive = !0, o.hand = [], o.played = [], o.draftHand = r.slice(a * 3, a * 3 + 3), o.draftPicked = !1, o.revealedHouse = null, i.push({
			kind: "deal",
			rid: t,
			data: { count: 3 },
			for: [t],
			secret: {
				house: o.house,
				cards: o.draftHand
			},
			...a > 0 ? { with: !0 } : {}
		});
	}), e.discard = [], e.pending = null, e.confirmed = [], e.lastRound = null, e.night = {
		stage: 0,
		rank: 0
	}, e.phase = "draft1", i;
}
function se(e, t, n) {
	let r = { at: 0 }, i = V([...N], n, r), a = {
		players: t,
		seed: n,
		rngCursor: r.at,
		round: 1,
		phase: "draft1",
		per: Object.fromEntries(t.map((e) => [e, {
			house: {
				house: "ronin",
				rank: 0
			},
			houseKnown: null,
			alive: !0,
			hand: [],
			played: [],
			honor: [],
			intel: [],
			draftHand: [],
			draftPicked: !1,
			revealedHouse: null
		}])),
		discard: [],
		tokens: i,
		night: {
			stage: 0,
			rank: 0
		},
		pending: null,
		confirmed: [],
		lastRound: null
	};
	return {
		state: a,
		fx: W(a)
	};
}
function G(e) {
	for (;;) {
		if (e.night.rank < 6) e.night.rank += 1;
		else if (e.night.stage < C.length - 1) e.night.stage += 1, e.night.rank = 1;
		else return le(e);
		let t = w.find((t) => t.kind === C[e.night.stage] && t.rank === e.night.rank);
		if (!t) continue;
		let n = e.players.find((n) => e.per[n].alive && e.per[n].hand.includes(t.id));
		if (n) return e.pending = {
			kind: "prompt",
			actor: n,
			cardId: t.id
		}, [];
	}
}
function ce(e, t, n) {
	let r = (t) => e.players.filter((n) => e.per[n].alive && e.per[n].house.house === t).map((t) => e.per[t].house.rank).sort((e, t) => e - t), i = r(t), a = r(n);
	for (let e = 0; e < Math.max(i.length, a.length); e += 1) {
		let t = i[e] ?? Infinity, n = a[e] ?? Infinity;
		if (t !== n) return t < n;
	}
	return !1;
}
function le(e) {
	e.phase = "reveal", e.pending = null;
	let t = [], n = e.players.find((t) => e.per[t].alive && e.per[t].hand.includes(K("mastermind", 0))), r = null, i = null;
	if (n) {
		i = n;
		let a = K("mastermind", 0);
		e.per[n].hand = e.per[n].hand.filter((e) => e !== a), e.per[n].played.push(a);
		let o = e.per[n].house.house;
		o !== "ronin" && (r = o), t.push({
			kind: "play",
			rid: n,
			data: { cardId: a }
		});
	} else ce(e, "crane", "lotus") ? r = "crane" : ce(e, "lotus", "crane") && (r = "lotus");
	let a = [], o = (n) => {
		e.per[n].honor.push(H(e)), a.push(n), t.push({
			kind: "honor",
			rid: n,
			data: { count: e.per[n].honor.length }
		});
	};
	if (r) for (let t of e.players) e.per[t].house.house === r && o(t);
	else if (!i) for (let t of e.players) e.per[t].alive && o(t);
	for (let t of e.players) e.per[t].alive && e.per[t].house.house === "ronin" && o(t);
	return e.lastRound = {
		winnerHouse: r,
		awarded: a,
		mastermindBy: i
	}, t.push({
		kind: "roundResult",
		data: {
			winnerHouse: r,
			awarded: a,
			mastermindBy: i
		}
	}), e.phase = e.players.some((t) => U(e.per[t]) >= 10) ? "done" : "roundEnd", e.confirmed = [], t;
}
function K(e, t) {
	let n = w.find((n) => n.kind === e && n.rank === t);
	if (!n) throw Error(`no card ${e} ${t}`);
	return n.id;
}
function ue(e, t, n) {
	let r = e.per[n];
	return r.hand.some((e) => T(e).kind === "monk" || T(e).kind === "martyr") ? (e.pending = {
		kind: "react",
		attacker: t,
		target: n
	}, []) : (r.alive = !1, [{
		kind: "kill",
		rid: n,
		data: { by: t }
	}]);
}
function de(e, t, n, r) {
	let i = (t) => e.players.includes(t) && e.per[t].alive, a = t.kind === "trickster" && t.rank === 1 ? 2 : t.kind === "trickster" && (t.rank === 2 || t.rank === 5) ? 0 : 1;
	if (r.length !== a || new Set(r).size !== r.length) return { code: "games.ninja.errBadTarget" };
	for (let e of r) {
		if (!i(e)) return { code: "games.ninja.errBadTarget" };
		let r = t.kind === "shinobi" || t.kind === "trickster" && t.rank === 1;
		if (e === n && !r) return { code: "games.ninja.errBadTarget" };
	}
	return null;
}
function fe(t, n, r, i) {
	let a = T(r), o = t.per[n];
	o.played.push(r);
	let s = [{
		kind: "play",
		rid: n,
		data: {
			cardId: r,
			targets: i
		}
	}], c = (e, n) => {
		o.intel.push({
			round: t.round,
			via: e,
			about: n,
			house: t.per[n].house
		});
	};
	switch (a.kind) {
		case "spy": return c("spy", i[0]), t.pending = null, s.push(...G(t)), s;
		case "mystic": {
			c("mystic", i[0]);
			let n = t.per[i[0]].hand;
			if (n.length > 0) {
				let r = n.length === 1 ? 0 : e(t.seed, t.rngCursor, n.length);
				t.rngCursor += n.length === 1 ? 0 : 1, o.intel.push({
					round: t.round,
					via: "mysticCard",
					about: i[0],
					cardId: n[r]
				});
			}
			return t.pending = null, s.push(...G(t)), s;
		}
		case "assassin": return s.push(...ue(t, n, i[0])), t.pending?.kind !== "react" && s.push(...G(t)), s;
		case "shinobi": return t.pending = {
			kind: "shinobiDecide",
			actor: n,
			target: i[0],
			house: t.per[i[0]].house
		}, s;
		case "trickster": switch (a.rank) {
			case 1: return t.pending = {
				kind: "shapeshiftDecide",
				actor: n,
				targets: [i[0], i[1]],
				houses: [t.per[i[0]].house, t.per[i[1]].house]
			}, s;
			case 2: return t.discard.length === 0 ? (t.pending = null, s.push(...G(t))) : t.pending = t.discard.length === 1 ? {
				kind: "graveTake",
				actor: n,
				cards: [t.discard[0]]
			} : {
				kind: "gravePeek",
				actor: n
			}, s;
			case 3: return t.pending = {
				kind: "troubleDecide",
				actor: n,
				target: i[0],
				house: t.per[i[0]].house
			}, s;
			case 4: return t.pending = {
				kind: "merchantPeek",
				actor: n,
				target: i[0]
			}, s;
			case 5: return o.revealedHouse = o.house, s.push({
				kind: "revealHouse",
				rid: n,
				data: { house: o.house }
			}), t.pending = {
				kind: "thiefChoose",
				actor: n
			}, s;
			default: return o.revealedHouse = o.house, s.push({
				kind: "revealHouse",
				rid: n,
				data: { house: o.house }
			}), t.per[i[0]].alive = !1, s.push({
				kind: "kill",
				rid: i[0],
				data: { by: n }
			}), t.pending = null, s.push(...G(t)), s;
		}
		default: return { code: "games.ninja.errBadCard" };
	}
}
function pe(e, t, n) {
	if (t.type === "tick") return {
		state: e,
		fx: []
	};
	if (t.type === "confirm") {
		if (e.phase !== "roundEnd" || e.confirmed.includes(n.by)) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		return t.confirmed.push(n.by), t.confirmed.length < t.players.length ? {
			state: t,
			fx: []
		} : (t.round += 1, {
			state: t,
			fx: W(t)
		});
	}
	if (t.type === "draftPick") {
		let r = e.phase;
		if (r !== "draft1" && r !== "draft2") return { code: "games.ninja.errNotYourTurn" };
		let i = e.per[n.by];
		if (!i || i.draftPicked || !i.draftHand.includes(t.cardId)) return { code: "games.ninja.errBadCard" };
		let a = structuredClone(e), o = a.per[n.by];
		if (o.draftHand = o.draftHand.filter((e) => e !== t.cardId), o.hand.push(t.cardId), o.draftPicked = !0, !a.players.every((e) => a.per[e].draftPicked)) return {
			state: a,
			fx: []
		};
		if (r === "draft1") {
			let e = a.players.map((e) => a.per[e].draftHand);
			return a.players.forEach((t, n) => {
				a.per[a.players[(n + 1) % a.players.length]].draftHand = e[n], a.per[t].draftPicked = !1;
			}), a.phase = "draft2", {
				state: a,
				fx: [{ kind: "draftPass" }]
			};
		}
		for (let e of a.players) a.discard.push(...a.per[e].draftHand), a.per[e].draftHand = [];
		a.phase = "night";
		let s = G(a);
		return s.unshift({ kind: "nightStart" }), {
			state: a,
			fx: s
		};
	}
	let r = e.pending;
	if (e.phase !== "night" || !r) return { code: "games.ninja.errNotYourTurn" };
	if (t.type === "skip") {
		if (r.kind !== "prompt" || r.actor !== n.by) return { code: "games.ninja.errNotYourTurn" };
		if (r.fromGrave) return { code: "games.ninja.errBadChoice" };
		let t = structuredClone(e);
		return t.pending = null, {
			state: t,
			fx: G(t)
		};
	}
	if (t.type === "play") {
		if (r.kind !== "prompt" || r.actor !== n.by) return { code: "games.ninja.errNotYourTurn" };
		let i = de(e, T(r.cardId), n.by, t.targets);
		if (i) return i;
		if (r.fromGrave) {
			if (e.discard.includes(r.cardId)) return { code: "games.ninja.errBadCard" };
		} else if (!e.per[n.by].hand.includes(r.cardId)) return { code: "games.ninja.errBadCard" };
		let a = structuredClone(e);
		r.fromGrave || (a.per[n.by].hand = a.per[n.by].hand.filter((e) => e !== r.cardId));
		let o = fe(a, n.by, r.cardId, t.targets);
		return "code" in o ? o : {
			state: a,
			fx: o
		};
	}
	if (t.type === "shinobiKill") {
		if (r.kind !== "shinobiDecide" || r.actor !== n.by) return { code: "games.ninja.errNotYourTurn" };
		if (t.kill && (r.target === n.by || !e.per[r.target].alive)) return { code: "games.ninja.errBadTarget" };
		let i = structuredClone(e), a = [];
		return t.kill && a.push(...ue(i, n.by, r.target)), i.pending?.kind !== "react" && (i.pending = null, a.push(...G(i))), {
			state: i,
			fx: a
		};
	}
	if (t.type === "shapeshiftSwap") {
		if (r.kind !== "shapeshiftDecide" || r.actor !== n.by) return { code: "games.ninja.errNotYourTurn" };
		let i = structuredClone(e), a = i.per[n.by], [o, s] = r.targets;
		a.intel.push({
			round: i.round,
			via: "shapeshifter",
			about: o,
			house: r.houses[0]
		}), a.intel.push({
			round: i.round,
			via: "shapeshifter",
			about: s,
			house: r.houses[1]
		}), t.swap && ([i.per[o].house, i.per[s].house] = [r.houses[1], r.houses[0]]);
		for (let e of r.targets) i.per[e].houseKnown = e === n.by ? i.per[e].house : null;
		return i.pending = null, {
			state: i,
			fx: G(i)
		};
	}
	if (t.type === "troubleReveal") {
		if (r.kind !== "troubleDecide" || r.actor !== n.by) return { code: "games.ninja.errNotYourTurn" };
		let i = structuredClone(e);
		i.per[n.by].intel.push({
			round: i.round,
			via: "troublemaker",
			about: r.target,
			house: r.house
		});
		let a = [];
		return t.reveal && (i.per[r.target].revealedHouse = r.house, a.push({
			kind: "revealHouse",
			rid: r.target,
			data: { house: r.house }
		})), i.pending = null, a.push(...G(i)), {
			state: i,
			fx: a
		};
	}
	if (t.type === "merchantPeek") {
		if (r.kind !== "merchantPeek" || r.actor !== n.by) return { code: "games.ninja.errNotYourTurn" };
		let i = e.per[r.target];
		if (t.what === "token" && (t.tokenIndex === void 0 || t.tokenIndex >= i.honor.length)) return { code: "games.ninja.errBadTarget" };
		let a = structuredClone(e), o = a.per[n.by];
		if (t.what === "house") o.intel.push({
			round: a.round,
			via: "merchant",
			about: r.target,
			house: i.house
		}), a.pending = {
			kind: "merchantSwap",
			actor: n.by,
			target: r.target,
			seenHouse: i.house,
			seenToken: null
		};
		else {
			let e = i.honor[t.tokenIndex];
			o.intel.push({
				round: a.round,
				via: "merchantToken",
				about: r.target,
				value: e
			}), a.pending = {
				kind: "merchantSwap",
				actor: n.by,
				target: r.target,
				seenHouse: null,
				seenToken: {
					index: t.tokenIndex,
					value: e
				}
			};
		}
		return {
			state: a,
			fx: []
		};
	}
	if (t.type === "merchantSwap") {
		if (r.kind !== "merchantSwap" || r.actor !== n.by) return { code: "games.ninja.errNotYourTurn" };
		if (t.mine === null != (t.theirs === null)) return { code: "games.ninja.errBadChoice" };
		let i = e.per[n.by], a = e.per[r.target];
		if (t.mine !== null && (t.mine >= i.honor.length || t.theirs >= a.honor.length)) return { code: "games.ninja.errBadChoice" };
		let o = structuredClone(e), s = [];
		if (t.mine !== null) {
			let e = o.per[n.by].honor, i = o.per[r.target].honor;
			[e[t.mine], i[t.theirs]] = [i[t.theirs], e[t.mine]], s.push({
				kind: "honorSwap",
				data: {
					a: n.by,
					b: r.target
				}
			});
		}
		return o.pending = null, s.push(...G(o)), {
			state: o,
			fx: s
		};
	}
	if (t.type === "thiefPick") {
		if (r.kind !== "thiefChoose" || r.actor !== n.by) return { code: "games.ninja.errNotYourTurn" };
		if (t.target !== null) {
			let r = e.per[t.target];
			if (!r || t.target === n.by || r.honor.length <= e.per[n.by].honor.length || t.tokenIndex === void 0 || t.tokenIndex >= r.honor.length) return { code: "games.ninja.errBadTarget" };
		}
		let i = structuredClone(e), a = [];
		if (t.target !== null) {
			let e = i.per[t.target].honor.splice(t.tokenIndex, 1)[0];
			i.per[n.by].honor.push(e), a.push({
				kind: "steal",
				data: {
					from: t.target,
					to: n.by
				}
			});
		}
		return i.pending = null, a.push(...G(i)), {
			state: i,
			fx: a
		};
	}
	if (t.type === "gravePeek") {
		if (r.kind !== "gravePeek" || r.actor !== n.by) return { code: "games.ninja.errNotYourTurn" };
		let [i, a] = t.indices;
		if (i === a || i >= e.discard.length || a >= e.discard.length) return { code: "games.ninja.errBadChoice" };
		let o = structuredClone(e), s = [o.discard[i], o.discard[a]];
		return o.per[n.by].intel.push({
			round: o.round,
			via: "gravedigger",
			cardIds: [s[0], s[1]]
		}), o.pending = {
			kind: "graveTake",
			actor: n.by,
			cards: s
		}, {
			state: o,
			fx: []
		};
	}
	if (t.type === "graveTake") {
		if (r.kind !== "graveTake" || r.actor !== n.by || !r.cards.includes(t.cardId)) return { code: "games.ninja.errBadChoice" };
		let i = T(t.cardId);
		if (t.mode === "now" && !C.includes(i.kind)) return { code: "games.ninja.errBadCard" };
		let a = structuredClone(e);
		return a.discard = a.discard.filter((e) => e !== t.cardId), t.mode === "keep" ? (a.per[n.by].hand.push(t.cardId), a.pending = null, {
			state: a,
			fx: G(a)
		}) : (a.pending = {
			kind: "prompt",
			actor: n.by,
			cardId: t.cardId,
			fromGrave: !0
		}, {
			state: a,
			fx: []
		});
	}
	if (r.kind !== "react" || r.target !== n.by) return { code: "games.ninja.errNotYourTurn" };
	if (t.card !== null) {
		let r = K(t.card, 0);
		if (!e.per[n.by].hand.includes(r)) return { code: "games.ninja.errBadCard" };
	}
	let i = structuredClone(e), a = [];
	if (t.card === "monk") {
		let e = K("monk", 0);
		i.per[n.by].hand = i.per[n.by].hand.filter((t) => t !== e), i.per[n.by].played.push(e), i.per[r.attacker].alive = !1, a.push({
			kind: "play",
			rid: n.by,
			data: {
				cardId: e,
				targets: []
			}
		}), a.push({
			kind: "kill",
			rid: r.attacker,
			data: {
				by: n.by,
				counter: !0
			}
		});
	} else if (t.card === "martyr") {
		let e = K("martyr", 0);
		i.per[n.by].hand = i.per[n.by].hand.filter((t) => t !== e), i.per[n.by].played.push(e), i.per[n.by].alive = !1, i.per[n.by].honor.push(H(i)), a.push({
			kind: "play",
			rid: n.by,
			data: {
				cardId: e,
				targets: []
			}
		}), a.push({
			kind: "kill",
			rid: n.by,
			data: { by: r.attacker }
		}), a.push({
			kind: "honor",
			rid: n.by,
			data: { count: i.per[n.by].honor.length }
		});
	} else i.per[n.by].alive = !1, a.push({
		kind: "kill",
		rid: n.by,
		data: { by: r.attacker }
	});
	return i.pending = null, a.push(...G(i)), {
		state: i,
		fx: a
	};
}
function me(e, t) {
	let n = e.per[t], r = e.phase === "reveal" || e.phase === "roundEnd" || e.phase === "done", i = e.pending, a = null;
	return i && (i.kind === "prompt" && i.actor === t ? a = {
		kind: "prompt",
		cardId: i.cardId,
		fromGrave: i.fromGrave === !0
	} : i.kind === "shinobiDecide" && i.actor === t ? a = {
		kind: "shinobi",
		target: i.target,
		house: i.house
	} : i.kind === "shapeshiftDecide" && i.actor === t ? a = {
		kind: "shapeshift",
		targets: i.targets,
		houses: i.houses
	} : i.kind === "troubleDecide" && i.actor === t ? a = {
		kind: "trouble",
		target: i.target,
		house: i.house
	} : i.kind === "graveTake" && i.actor === t ? a = {
		kind: "graveTake",
		cards: i.cards
	} : i.kind === "merchantPeek" && i.actor === t ? a = {
		kind: "merchantPeek",
		target: i.target
	} : i.kind === "merchantSwap" && i.actor === t ? a = {
		kind: "merchantSwap",
		target: i.target,
		seenHouse: i.seenHouse,
		seenToken: i.seenToken
	} : i.kind === "thiefChoose" && i.actor === t ? a = { kind: "thiefChoose" } : i.kind === "gravePeek" && i.actor === t ? a = { kind: "gravePeek" } : i.kind === "react" && i.target === t && (a = {
		kind: "react",
		attacker: i.attacker
	})), {
		public: {
			round: e.round,
			phase: e.phase,
			night: e.phase === "night" ? {
				stage: e.night.stage,
				rank: Math.max(1, e.night.rank)
			} : null,
			pending: i ? {
				kind: i.kind,
				actor: i.kind === "react" ? i.target : i.actor
			} : null,
			players: e.players.map((t) => {
				let n = e.per[t];
				return {
					rid: t,
					alive: n.alive,
					honorCount: n.honor.length,
					played: n.played,
					house: n.revealedHouse ?? (r && n.alive ? n.house : null)
				};
			}),
			draftPicked: e.players.filter((t) => e.per[t].draftPicked),
			discardCount: e.discard.length,
			tokensLeft: e.tokens.length,
			confirmed: e.confirmed,
			lastRound: e.lastRound
		},
		private: {
			houseKnown: n?.houseKnown ?? null,
			hand: n?.hand ?? [],
			draftHand: n?.draftHand ?? [],
			honor: n?.honor ?? [],
			intel: n?.intel ?? [],
			peek: a
		}
	};
}
function he(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = (t) => U(e.per[t]), n = [...e.players].sort((e, n) => t(n) - t(e)), r = t(n[0]);
	return {
		phase: "done",
		winner: n.filter((e) => t(e) === r),
		ranking: n,
		scores: Object.fromEntries(e.players.map((e) => [e, t(e)]))
	};
}
var ge = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: L,
	schemas: {
		action: te,
		publicView: ae,
		privateView: oe
	},
	setup: se,
	reduce: pe,
	viewFor: me,
	status: he
};
//#endregion
//#region src/games/ninja/view-player.tsx
function _e(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ _(ye, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function ve(e) {
	let t = T(e);
	if (t.kind === "trickster") {
		if (t.rank === 1) return 2;
		if (t.rank === 2 || t.rank === 5) return 0;
	}
	return 1;
}
function q(e, t) {
	return i(e.rid) === null ? e.name : c(t, e.avatar);
}
function ye({ pub: e, priv: t, members: r, myRid: i, send: a }) {
	let o = u(), c = l((e) => e.locale), d = (e) => {
		let t = r.find((t) => t.rid === e);
		return t ? q(t, c) : e;
	}, f = (e) => `${F[e.house]}${o(I[e.house])}${e.rank > 0 ? ` ${e.rank}` : ""}`, { ref: p } = s("table"), g = e.players.find((e) => e.rid === i)?.alive ?? !1, y = e.pending, b = y !== null && y.actor === i && (y.kind === "react" || g), x = t?.peek ?? null, [S, w] = n([]), E = y ? `${y.kind}:${y.actor}` : "", [D, k] = n(E);
	D !== E && (k(E), w([]));
	let A = "info", j = "", M;
	if (e.phase === "draft1" || e.phase === "draft2") {
		let t = e.draftPicked.includes(i);
		A = t ? "info" : "accent", j = e.phase === "draft1" ? o("games.ninja.draft1") : o("games.ninja.draft2"), M = t ? o("games.ninja.draftWaiting", {
			n: e.draftPicked.length,
			total: e.players.length
		}) : void 0;
	} else if (e.phase === "night" && e.night) {
		let t = C[e.night.stage];
		M = o("games.ninja.stageProgress", {
			stage: o(ee[t]),
			rank: e.night.rank
		}), b ? (A = "accent", j = y.kind === "react" ? o("games.ninja.reactBanner") : o("games.ninja.yourDecision")) : j = y ? o("games.ninja.waiting", { name: d(y.actor) }) : o("games.ninja.nightFalls");
	} else if (e.phase === "roundEnd" && e.lastRound) {
		A = "done";
		let t = e.lastRound;
		j = t.winnerHouse ? o("games.ninja.roundWin", { house: `${F[t.winnerHouse]}${o(I[t.winnerHouse])}` }) : o(t.mastermindBy ? "games.ninja.roundRoninMastermind" : "games.ninja.roundTie");
	}
	let N = b && y.kind === "prompt" && x?.kind === "prompt" ? x.cardId : null, P = N === null ? 0 : ve(N), R = (t) => {
		if (N === null) return !1;
		let n = T(N);
		if (!e.players.find((e) => e.rid === t)?.alive) return !1;
		let r = n.kind === "shinobi" || n.kind === "trickster" && n.rank === 1;
		return t !== i || r;
	}, z = N !== null && P > 0;
	return /* @__PURE__ */ _(m, {
		adaptive: !0,
		className: "ninja-screen",
		scroll: !1,
		banner: /* @__PURE__ */ _(h, {
			tone: A,
			text: j,
			sub: M,
			chip: o("games.ninja.roundShort", { n: e.round }),
			accent: L.accent
		}),
		children: /* @__PURE__ */ v("div", {
			className: "ninja-layout",
			style: {
				"--ninja-wide-cols": e.players.length <= 4 ? 2 : e.players.length <= 6 ? 3 : 4,
				"--ninja-seat-scale": e.players.length <= 4 ? 1.5 : e.players.length <= 6 ? 1.2 : 1
			},
			children: [/* @__PURE__ */ _("div", {
				ref: p,
				className: "frame ninja-table",
				children: /* @__PURE__ */ _("ul", {
					className: "ninja-seats",
					children: e.players.map((t) => {
						let n = r.find((e) => e.rid === t.rid);
						if (!n) return null;
						let a = z && R(t.rid);
						return /* @__PURE__ */ _(be, {
							m: n,
							p: t,
							locale: c,
							isMe: t.rid === i,
							acting: y?.actor === t.rid && e.phase === "night",
							selectable: a,
							selected: S.includes(t.rid),
							onPick: a ? () => w((e) => e.includes(t.rid) ? e.filter((e) => e !== t.rid) : [...e, t.rid].slice(-P)) : void 0,
							youLabel: o("lobby.you"),
							offlineLabel: o("lobby.offline"),
							botLabel: o("lobby.bot"),
							deadLabel: o("games.ninja.dead"),
							houseText: t.house ? f(t.house) : null
						}, t.rid);
					})
				})
			}), /* @__PURE__ */ v("section", {
				className: "frame ninja-private",
				children: [
					t && /* @__PURE__ */ v("div", {
						className: "ninja-private-status",
						children: [
							/* @__PURE__ */ _("span", {
								className: "ninja-house",
								"aria-label": o("games.ninja.myHouse"),
								children: t.houseKnown ? f(t.houseKnown) : o("games.ninja.houseUnknown")
							}),
							t.honor.length > 0 && /* @__PURE__ */ v("span", {
								className: "ninja-honor",
								"aria-label": o("games.ninja.myHonor"),
								children: [/* @__PURE__ */ _("span", {
									"aria-hidden": !0,
									children: "⭐"
								}), /* @__PURE__ */ _("span", {
									className: "font-mono tabular-nums",
									children: t.honor.reduce((e, t) => e + t, 0)
								})]
							}),
							t.intel.length > 0 && /* @__PURE__ */ _(xe, {
								intel: t.intel,
								nameOf: d,
								houseText: f
							})
						]
					}),
					t && t.hand.length > 0 && /* @__PURE__ */ _("div", {
						className: "ninja-hand",
						children: t.hand.map((e) => /* @__PURE__ */ _(J, {
							id: e,
							mini: !0
						}, e))
					}),
					/* @__PURE__ */ v("div", {
						className: "ninja-actions",
						children: [
							e.phase === "roundEnd" && e.lastRound && /* @__PURE__ */ v("div", {
								className: "ninja-round-summary",
								children: [e.lastRound.mastermindBy && /* @__PURE__ */ _("p", { children: o("games.ninja.mastermindReveal", { name: d(e.lastRound.mastermindBy) }) }), e.lastRound.awarded.length > 0 && /* @__PURE__ */ _("p", { children: o("games.ninja.awarded", { names: e.lastRound.awarded.map(d).join("、") }) })]
							}),
							(e.phase === "draft1" || e.phase === "draft2") && t && !e.draftPicked.includes(i) && /* @__PURE__ */ _("div", {
								className: "ninja-draft",
								children: t.draftHand.map((e) => /* @__PURE__ */ v("button", {
									type: "button",
									onClick: () => a({
										type: "draftPick",
										cardId: e
									}),
									className: "ninja-draft-card",
									children: [/* @__PURE__ */ _(J, { id: e }), /* @__PURE__ */ _("span", {
										className: "ninja-card-name",
										children: o(O(T(e)))
									})]
								}, e))
							}),
							e.phase === "night" && g && !b && /* @__PURE__ */ _("p", {
								className: "py-2 text-center text-xs font-bold opacity-60",
								children: o("games.ninja.nightWait")
							}),
							e.phase === "night" && !g && /* @__PURE__ */ _("p", {
								className: "py-2 text-center text-xs font-bold opacity-60",
								children: o("games.ninja.deadWatch")
							}),
							e.phase === "night" && b && t && x && /* @__PURE__ */ _(Se, {
								pub: e,
								priv: t,
								peek: x,
								sel: S,
								needTargets: P,
								myRid: i,
								nameOf: d,
								houseText: f,
								send: a
							}, E),
							e.phase === "roundEnd" && (e.confirmed.includes(i) ? /* @__PURE__ */ _("p", {
								className: "py-2 text-center text-xs font-bold opacity-60",
								children: o("games.ninja.confirmWait", {
									n: e.confirmed.length,
									total: e.players.length
								})
							}) : /* @__PURE__ */ _("button", {
								type: "button",
								onClick: () => a({ type: "confirm" }),
								className: "btn-base min-h-12 w-full text-base",
								style: { background: L.accent },
								children: o("games.ninja.nextRound")
							}))
						]
					})
				]
			})]
		})
	});
}
function J({ id: e, mini: t }) {
	let n = T(e);
	return /* @__PURE__ */ v("span", {
		className: `ninja-card${t ? " ninja-card--mini" : ""}`,
		children: [/* @__PURE__ */ _("span", {
			"aria-hidden": !0,
			className: "ninja-card-symbol",
			children: P[n.kind]
		}), n.rank > 0 && /* @__PURE__ */ _("span", {
			"aria-hidden": !0,
			className: "ninja-card-rank font-mono tabular-nums",
			children: n.rank
		})]
	});
}
function be({ m: e, p: t, locale: n, isMe: r, acting: o, selectable: c, selected: l, onPick: u, youLabel: m, offlineLabel: h, botLabel: y, deadLabel: b, houseText: x }) {
	let { ref: S } = s(`seat:${e.rid}`), C = p[e.colorIndex % p.length], w = i(e.rid) !== null, T = /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ v("span", {
		className: "ninja-seat-heading",
		children: [/* @__PURE__ */ v("span", {
			ref: S,
			className: `relative flex-none rounded-full ${o ? "ring-3 ring-offset-1 ring-offset-transparent" : ""}`,
			style: o ? { "--tw-ring-color": L.accent } : void 0,
			children: [
				e.online ? w ? /* @__PURE__ */ _("span", {
					role: "img",
					"aria-label": y,
					className: "absolute -top-1 -right-1 z-20 grid size-4 place-items-center rounded-full border-2 border-ink bg-warn-soft text-warn-ink",
					children: /* @__PURE__ */ _(d, {
						size: 10,
						"aria-hidden": !0
					})
				}) : null : /* @__PURE__ */ _("span", {
					role: "img",
					"aria-label": h,
					className: "absolute -top-1 -right-1 z-20 grid size-4 place-items-center rounded-full border-2 border-ink bg-ink text-surface",
					children: /* @__PURE__ */ _(f, {
						size: 10,
						"aria-hidden": !0
					})
				}),
				!t.alive && /* @__PURE__ */ _("span", {
					role: "img",
					"aria-label": b,
					className: "absolute -bottom-1 -left-1 z-20 grid size-4 place-items-center rounded-full border-2 border-ink bg-surface text-[9px] leading-none",
					children: "💀"
				}),
				/* @__PURE__ */ _("span", {
					className: "ninja-avatar",
					style: { backgroundColor: C.hex },
					children: /* @__PURE__ */ _("img", {
						src: a[e.avatar % a.length],
						alt: "",
						draggable: !1,
						className: "ninja-avatar-image"
					})
				})
			]
		}), /* @__PURE__ */ v("span", {
			className: "ninja-seat-info",
			children: [/* @__PURE__ */ v("span", {
				className: "ninja-seat-name",
				title: q(e, n),
				children: [q(e, n), r && /* @__PURE__ */ v("span", {
					className: "ml-0.5 opacity-60",
					children: [
						"(",
						m,
						")"
					]
				})]
			}), t.honorCount > 0 && /* @__PURE__ */ v("span", {
				className: "ninja-seat-honor",
				children: [/* @__PURE__ */ _("span", {
					"aria-hidden": !0,
					children: "⭐"
				}), /* @__PURE__ */ v("span", {
					className: "font-mono tabular-nums",
					children: ["×", t.honorCount]
				})]
			})]
		})]
	}), /* @__PURE__ */ v("span", {
		className: "ninja-seat-cards",
		children: [x && /* @__PURE__ */ _("span", {
			className: "ninja-seat-house",
			children: x
		}), t.played.map((e) => /* @__PURE__ */ _(J, {
			id: e,
			mini: !0
		}, e))]
	})] }), E = `ninja-seat ${t.alive ? "" : "opacity-50"} ${l ? "ninja-seat--selected" : ""}`;
	return c ? /* @__PURE__ */ _("li", { children: /* @__PURE__ */ _("button", {
		type: "button",
		onClick: u,
		className: `${E} ninja-seat--selectable`,
		"aria-pressed": l,
		children: T
	}) }) : /* @__PURE__ */ _("li", {
		className: E,
		children: T
	});
}
function xe({ intel: e, nameOf: t, houseText: i }) {
	let a = u(), [s, c] = n(!1), l = (e) => {
		switch (e.via) {
			case "mysticCard": return a("games.ninja.intelCard", {
				round: e.round,
				name: t(e.about),
				card: a(O(T(e.cardId)))
			});
			case "gravedigger": return a("games.ninja.intelGrave", {
				round: e.round,
				cards: e.cardIds.map((e) => a(O(T(e)))).join("、")
			});
			case "merchantToken": return a("games.ninja.intelToken", {
				round: e.round,
				name: t(e.about),
				value: e.value
			});
			default: return a("games.ninja.intelHouse", {
				round: e.round,
				name: t(e.about),
				house: i(e.house)
			});
		}
	};
	return /* @__PURE__ */ v("span", {
		className: "ninja-intel-toggle",
		children: [/* @__PURE__ */ _("button", {
			type: "button",
			"aria-expanded": s,
			"aria-label": a("games.ninja.intel"),
			onClick: () => c((e) => !e),
			className: "btn-quiet ninja-intel-button",
			children: "📝"
		}), r(/* @__PURE__ */ _(o, {
			open: s,
			onClose: () => c(!1),
			label: a("games.ninja.intel"),
			title: a("games.ninja.intel"),
			children: /* @__PURE__ */ _("ul", {
				className: "ninja-intel-list",
				children: e.map((e, t) => /* @__PURE__ */ _("li", { children: l(e) }, t))
			})
		}), document.body)]
	});
}
function Se({ pub: e, priv: t, peek: r, sel: i, needTargets: a, myRid: o, nameOf: s, houseText: c, send: l }) {
	let d = u(), [f, p] = n(null), [m, h] = n(null), [g, y] = n(null), [b, x] = n([]);
	if (r.kind === "react") {
		let e = t.hand.some((e) => T(e).kind === "monk"), n = t.hand.some((e) => T(e).kind === "martyr");
		return /* @__PURE__ */ v("div", {
			className: "ninja-decision",
			children: [/* @__PURE__ */ _("p", {
				className: "text-xs leading-4 font-bold",
				children: d("games.ninja.reactPrompt", { name: s(r.attacker) })
			}), /* @__PURE__ */ v("div", {
				className: "ninja-button-row",
				children: [
					e && /* @__PURE__ */ v("button", {
						type: "button",
						onClick: () => l({
							type: "react",
							card: "monk"
						}),
						className: "btn-base min-h-12 flex-1 text-sm",
						style: { background: L.accent },
						children: ["🪞 ", d("games.ninja.reactMonk")]
					}),
					n && /* @__PURE__ */ v("button", {
						type: "button",
						onClick: () => l({
							type: "react",
							card: "martyr"
						}),
						className: "btn-base min-h-12 flex-1 text-sm",
						style: { background: L.accent },
						children: ["🕯️ ", d("games.ninja.reactMartyr")]
					}),
					/* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => l({
							type: "react",
							card: null
						}),
						className: "btn-quiet min-h-12 flex-1 text-sm",
						children: d("games.ninja.reactDie")
					})
				]
			})]
		});
	}
	switch (r.kind) {
		case "prompt": {
			let e = T(r.cardId);
			return /* @__PURE__ */ v("div", {
				className: "ninja-decision",
				children: [/* @__PURE__ */ v("div", {
					className: "ninja-prompt",
					children: [/* @__PURE__ */ _(J, { id: r.cardId }), /* @__PURE__ */ v("div", {
						className: "ninja-prompt-description",
						children: [/* @__PURE__ */ _("p", {
							className: "text-xs leading-4 font-extrabold",
							children: d(O(e))
						}), /* @__PURE__ */ _("p", {
							className: "text-[10px] leading-3.5 opacity-70",
							children: d(j(e))
						})]
					})]
				}), /* @__PURE__ */ v("div", {
					className: "ninja-button-row",
					children: [/* @__PURE__ */ _("button", {
						type: "button",
						disabled: a > 0 && i.length < a,
						onClick: () => l({
							type: "play",
							targets: i
						}),
						className: "btn-base min-h-12 flex-1 text-base disabled:opacity-40",
						style: { background: L.accent },
						children: a > 0 ? d("games.ninja.playWithTargets", {
							n: i.length,
							total: a
						}) : d("games.ninja.play")
					}), !r.fromGrave && /* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => l({ type: "skip" }),
						className: "btn-quiet min-h-12 flex-none px-4 text-sm",
						children: d("games.ninja.skip")
					})]
				})]
			});
		}
		case "shinobi": return /* @__PURE__ */ v("div", {
			className: "ninja-decision",
			children: [/* @__PURE__ */ _("p", {
				className: "text-xs leading-4 font-bold",
				children: d("games.ninja.shinobiSeen", {
					name: s(r.target),
					house: c(r.house)
				})
			}), /* @__PURE__ */ v("div", {
				className: "ninja-button-row",
				children: [/* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => l({
						type: "shinobiKill",
						kill: !1
					}),
					className: "btn-quiet min-h-12 flex-1 text-sm",
					children: d("games.ninja.spare")
				}), /* @__PURE__ */ _("button", {
					type: "button",
					disabled: r.target === o,
					onClick: () => l({
						type: "shinobiKill",
						kill: !0
					}),
					className: "btn-base min-h-12 flex-1 text-base disabled:opacity-40",
					style: { background: "var(--color-danger)" },
					children: d("games.ninja.kill")
				})]
			})]
		});
		case "shapeshift": return /* @__PURE__ */ v("div", {
			className: "ninja-decision",
			children: [/* @__PURE__ */ v("p", {
				className: "text-xs leading-4 font-bold",
				children: [
					s(r.targets[0]),
					": ",
					c(r.houses[0]),
					" ・ ",
					s(r.targets[1]),
					": ",
					c(r.houses[1])
				]
			}), /* @__PURE__ */ v("div", {
				className: "ninja-button-row",
				children: [/* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => l({
						type: "shapeshiftSwap",
						swap: !1
					}),
					className: "btn-quiet min-h-12 flex-1 text-sm",
					children: d("games.ninja.noSwap")
				}), /* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => l({
						type: "shapeshiftSwap",
						swap: !0
					}),
					className: "btn-base min-h-12 flex-1 text-base",
					style: { background: L.accent },
					children: d("games.ninja.doSwap")
				})]
			})]
		});
		case "trouble": return /* @__PURE__ */ v("div", {
			className: "ninja-decision",
			children: [/* @__PURE__ */ _("p", {
				className: "text-xs leading-4 font-bold",
				children: d("games.ninja.troubleSeen", {
					name: s(r.target),
					house: c(r.house)
				})
			}), /* @__PURE__ */ v("div", {
				className: "ninja-button-row",
				children: [/* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => l({
						type: "troubleReveal",
						reveal: !1
					}),
					className: "btn-quiet min-h-12 flex-1 text-sm",
					children: d("games.ninja.keepSecret")
				}), /* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => l({
						type: "troubleReveal",
						reveal: !0
					}),
					className: "btn-base min-h-12 flex-1 text-base",
					style: { background: L.accent },
					children: d("games.ninja.revealIt")
				})]
			})]
		});
		case "merchantPeek": {
			let t = e.players.find((e) => e.rid === r.target)?.honorCount ?? 0;
			return /* @__PURE__ */ v("div", {
				className: "ninja-decision",
				children: [/* @__PURE__ */ _("p", {
					className: "text-xs leading-4 font-bold",
					children: d("games.ninja.merchantPeekPrompt", { name: s(r.target) })
				}), /* @__PURE__ */ v("div", {
					className: "ninja-button-row",
					children: [/* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => l({
							type: "merchantPeek",
							what: "house"
						}),
						className: "btn-base min-h-12 flex-1 text-sm",
						style: { background: L.accent },
						children: d("games.ninja.peekHouse")
					}), t > 0 && /* @__PURE__ */ _("span", {
						className: "ninja-token-options",
						children: [...Array(t).keys()].map((e) => /* @__PURE__ */ _("button", {
							type: "button",
							"aria-label": d("games.ninja.peekTokenAria", { n: e + 1 }),
							onClick: () => l({
								type: "merchantPeek",
								what: "token",
								tokenIndex: e
							}),
							className: "card grid min-h-12 min-w-11 flex-1 place-items-center text-base",
							children: "⭐"
						}, e))
					})]
				})]
			});
		}
		case "merchantSwap": {
			let n = e.players.find((e) => e.rid === r.target)?.honorCount ?? 0, i = r.seenHouse ? c(r.seenHouse) : r.seenToken ? d("games.ninja.tokenValue", { value: r.seenToken.value }) : "";
			return /* @__PURE__ */ v("div", {
				className: "ninja-decision",
				children: [
					/* @__PURE__ */ _("p", {
						className: "text-xs leading-4 font-bold",
						children: d("games.ninja.merchantSeen", {
							name: s(r.target),
							seen: i
						})
					}),
					/* @__PURE__ */ v("div", {
						className: "ninja-token-options",
						children: [
							t.honor.map((e, t) => /* @__PURE__ */ v("button", {
								type: "button",
								"aria-pressed": f === t,
								"aria-label": d("games.ninja.myTokenAria", { value: e }),
								onClick: () => p(f === t ? null : t),
								className: `card grid min-h-11 min-w-11 place-items-center font-mono text-sm font-bold tabular-nums ${f === t ? "ring-3 ring-sky" : ""}`,
								children: ["⭐", e]
							}, t)),
							/* @__PURE__ */ _("span", {
								"aria-hidden": !0,
								className: "px-1",
								children: "⇄"
							}),
							[...Array(n).keys()].map((e) => /* @__PURE__ */ _("button", {
								type: "button",
								"aria-pressed": m === e,
								"aria-label": d("games.ninja.theirTokenAria", { n: e + 1 }),
								onClick: () => h(m === e ? null : e),
								className: `card grid min-h-11 min-w-11 place-items-center font-mono text-sm font-bold tabular-nums ${m === e ? "ring-3 ring-sky" : ""}`,
								children: r.seenToken?.index === e ? `⭐${r.seenToken.value}` : "⭐?"
							}, e))
						]
					}),
					/* @__PURE__ */ v("div", {
						className: "ninja-button-row",
						children: [/* @__PURE__ */ _("button", {
							type: "button",
							onClick: () => l({
								type: "merchantSwap",
								mine: null,
								theirs: null
							}),
							className: "btn-quiet min-h-12 flex-1 text-sm",
							children: d("games.ninja.noSwap")
						}), /* @__PURE__ */ _("button", {
							type: "button",
							disabled: f === null || m === null,
							onClick: () => l({
								type: "merchantSwap",
								mine: f,
								theirs: m
							}),
							className: "btn-base min-h-12 flex-1 text-base disabled:opacity-40",
							style: { background: L.accent },
							children: d("games.ninja.doSwap")
						})]
					})
				]
			});
		}
		case "gravePeek": return /* @__PURE__ */ v("div", {
			className: "ninja-decision",
			children: [
				/* @__PURE__ */ _("p", {
					className: "text-xs leading-4 font-bold",
					children: d("games.ninja.gravePeekPrompt")
				}),
				/* @__PURE__ */ _("div", {
					className: "ninja-grave-options",
					children: [...Array(e.discardCount).keys()].map((e) => /* @__PURE__ */ _("button", {
						type: "button",
						"aria-pressed": b.includes(e),
						"aria-label": d("games.ninja.graveCardAria", { n: e + 1 }),
						onClick: () => x((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e].slice(-2)),
						className: `card grid min-h-11 min-w-11 place-items-center text-lg ${b.includes(e) ? "ring-3 ring-sky" : ""}`,
						children: "🂠"
					}, e))
				}),
				/* @__PURE__ */ _("button", {
					type: "button",
					disabled: b.length !== 2,
					onClick: () => l({
						type: "gravePeek",
						indices: [b[0], b[1]]
					}),
					className: "btn-base min-h-12 w-full text-base disabled:opacity-40",
					style: { background: L.accent },
					children: d("games.ninja.gravePeekGo")
				})
			]
		});
		case "graveTake": return /* @__PURE__ */ v("div", {
			className: "ninja-decision",
			children: [/* @__PURE__ */ _("p", {
				className: "text-xs leading-4 font-bold",
				children: d("games.ninja.graveTakePrompt")
			}), /* @__PURE__ */ _("div", {
				className: "ninja-grave-take",
				children: r.cards.map((e) => {
					let t = T(e), n = C.includes(t.kind);
					return /* @__PURE__ */ v("div", {
						className: "ninja-take-card",
						children: [
							/* @__PURE__ */ _(J, { id: e }),
							/* @__PURE__ */ _("span", {
								className: "ninja-card-name",
								children: d(O(t))
							}),
							/* @__PURE__ */ v("div", {
								className: "flex w-full gap-1",
								children: [/* @__PURE__ */ _("button", {
									type: "button",
									onClick: () => l({
										type: "graveTake",
										cardId: e,
										mode: "keep"
									}),
									className: "btn-quiet min-h-11 flex-1 text-[11px]",
									children: d("games.ninja.keepCard")
								}), n && /* @__PURE__ */ _("button", {
									type: "button",
									onClick: () => l({
										type: "graveTake",
										cardId: e,
										mode: "now"
									}),
									className: "btn-base min-h-11 flex-1 text-[11px]",
									style: { background: L.accent },
									children: d("games.ninja.playNow")
								})]
							})
						]
					}, e);
				})
			})]
		});
		case "thiefChoose": {
			let n = e.players.filter((e) => e.rid !== o && e.honorCount > t.honor.length), r = n.find((e) => e.rid === g);
			return /* @__PURE__ */ v("div", {
				className: "ninja-decision",
				children: [/* @__PURE__ */ _("p", {
					className: "text-xs leading-4 font-bold",
					children: d("games.ninja.thiefPrompt")
				}), n.length === 0 ? /* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => l({
						type: "thiefPick",
						target: null
					}),
					className: "btn-base min-h-12 w-full text-base",
					style: { background: L.accent },
					children: d("games.ninja.thiefNoOne")
				}) : r ? /* @__PURE__ */ v("div", {
					className: "ninja-token-options",
					children: [/* @__PURE__ */ v("span", {
						className: "flex-none text-xs font-bold",
						children: [s(r.rid), ":"]
					}), [...Array(r.honorCount).keys()].map((e) => /* @__PURE__ */ _("button", {
						type: "button",
						"aria-label": d("games.ninja.stealTokenAria", { n: e + 1 }),
						onClick: () => l({
							type: "thiefPick",
							target: r.rid,
							tokenIndex: e
						}),
						className: "card grid min-h-11 min-w-11 flex-1 place-items-center text-base",
						children: "⭐"
					}, e))]
				}) : /* @__PURE__ */ v("div", {
					className: "ninja-button-row",
					children: [/* @__PURE__ */ _("div", {
						className: "ninja-thief-targets",
						children: n.map((e) => /* @__PURE__ */ v("button", {
							type: "button",
							onClick: () => y(e.rid),
							className: "card min-h-11 px-2 text-xs font-bold",
							children: [
								s(e.rid),
								" ⭐×",
								e.honorCount
							]
						}, e.rid))
					}), /* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => l({
							type: "thiefPick",
							target: null
						}),
						className: "btn-quiet min-h-12 flex-none px-3 text-sm",
						children: d("games.ninja.noSteal")
					})]
				})]
			});
		}
		default: return null;
	}
}
//#endregion
//#region src/games/ninja/bot.ts
function Y(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function X(e) {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % 100 < e * 100;
}
var Ce = (e, t) => {
	let n = e.public, r = e.private;
	if (!r) return null;
	if (n.phase === "draft1" || n.phase === "draft2") return n.draftPicked.includes(t.rid) || r.draftHand.length === 0 ? null : { action: {
		type: "draftPick",
		cardId: Y(r.draftHand)
	} };
	if (n.phase === "roundEnd") return n.confirmed.includes(t.rid) ? null : { action: { type: "confirm" } };
	if (n.phase !== "night" || !n.pending || n.pending.actor !== t.rid) return null;
	if (n.pending.kind === "react") {
		let e = [null];
		return r.hand.some((e) => T(e).kind === "monk") && e.push("monk"), r.hand.some((e) => T(e).kind === "martyr") && e.push("martyr"), { action: {
			type: "react",
			card: Y(e)
		} };
	}
	let i = n.players.filter((e) => e.alive && e.rid !== t.rid).map((e) => e.rid), a = (e) => {
		let t = T(e);
		if (t.kind === "trickster" && (t.rank === 2 || t.rank === 5)) return [];
		if (t.kind === "trickster" && t.rank === 1) {
			let e = n.players.filter((e) => e.alive).map((e) => e.rid), t = Y(e);
			return [t, Y(e.filter((e) => e !== t))];
		}
		return t.kind === "shinobi" ? [Y(n.players.filter((e) => e.alive).map((e) => e.rid))] : [Y(i)];
	};
	switch (n.pending.kind) {
		case "prompt": return r.peek?.kind === "prompt" ? !r.peek.fromGrave && !X(.7) ? { action: { type: "skip" } } : { action: {
			type: "play",
			targets: a(r.peek.cardId)
		} } : null;
		case "shinobiDecide": return r.peek?.kind === "shinobi" ? { action: {
			type: "shinobiKill",
			kill: r.peek.target !== t.rid && X(.6)
		} } : null;
		case "shapeshiftDecide": return { action: {
			type: "shapeshiftSwap",
			swap: X(.5)
		} };
		case "troubleDecide": return { action: {
			type: "troubleReveal",
			reveal: X(.5)
		} };
		case "merchantPeek": {
			if (r.peek?.kind !== "merchantPeek") return null;
			let e = n.players.find((e) => e.rid === r.peek.target)?.honorCount ?? 0;
			return e > 0 && X(.5) ? { action: {
				type: "merchantPeek",
				what: "token",
				tokenIndex: Y([...Array(e).keys()])
			} } : { action: {
				type: "merchantPeek",
				what: "house"
			} };
		}
		case "merchantSwap": {
			if (r.peek?.kind !== "merchantSwap") return null;
			let e = n.players.find((e) => e.rid === r.peek.target)?.honorCount ?? 0;
			return r.honor.length === 0 || e === 0 || !X(.5) ? { action: {
				type: "merchantSwap",
				mine: null,
				theirs: null
			} } : { action: {
				type: "merchantSwap",
				mine: Y([...Array(r.honor.length).keys()]),
				theirs: Y([...Array(e).keys()])
			} };
		}
		case "thiefChoose": {
			let e = n.players.filter((e) => e.rid !== t.rid && e.honorCount > r.honor.length);
			if (e.length === 0 || !X(.7)) return { action: {
				type: "thiefPick",
				target: null
			} };
			let i = Y(e);
			return { action: {
				type: "thiefPick",
				target: i.rid,
				tokenIndex: Y([...Array(i.honorCount).keys()])
			} };
		}
		case "gravePeek": {
			let e = Y([...Array(n.discardCount).keys()]);
			return { action: {
				type: "gravePeek",
				indices: [e, Y([...Array(n.discardCount).keys()].filter((t) => t !== e))]
			} };
		}
		case "graveTake": {
			if (r.peek?.kind !== "graveTake") return null;
			let e = Y(r.peek.cards);
			return { action: {
				type: "graveTake",
				cardId: e,
				mode: C.includes(T(e).kind) && X(.5) ? "now" : "keep"
			} };
		}
		default: return null;
	}
}, we = (e, t, n) => {
	switch (e.type) {
		case "draftPick": return n("games.ninja.hintDraft", { card: n(O(T(e.cardId))) });
		case "confirm": return n("games.ninja.nextRound");
		case "play": {
			let e = t.private?.peek;
			return e?.kind === "prompt" ? n("games.ninja.hintPlay", { card: n(O(T(e.cardId))) }) : n("games.ninja.play");
		}
		case "skip": return n("games.ninja.skip");
		case "react": return e.card === "monk" ? n("games.ninja.reactMonk") : e.card === "martyr" ? n("games.ninja.reactMartyr") : n("games.ninja.reactDie");
		case "shinobiKill": return n(e.kill ? "games.ninja.kill" : "games.ninja.spare");
		case "shapeshiftSwap": return n(e.swap ? "games.ninja.doSwap" : "games.ninja.noSwap");
		case "troubleReveal": return n(e.reveal ? "games.ninja.revealIt" : "games.ninja.keepSecret");
		case "merchantPeek": return e.what === "house" ? n("games.ninja.peekHouse") : n("games.ninja.peekTokenAria", { n: (e.tokenIndex ?? 0) + 1 });
		case "merchantSwap": return e.mine === null || e.theirs === null ? n("games.ninja.noSwap") : n("games.ninja.hintMerchantSwap");
		case "thiefPick": return e.target === null ? n("games.ninja.noSteal") : n("games.ninja.stealTokenAria", { n: (e.tokenIndex ?? 0) + 1 });
		case "gravePeek": return n("games.ninja.gravePeekGo");
		case "graveTake": return e.mode === "now" ? n("games.ninja.hintGravePlay", { card: n(O(T(e.cardId))) }) : n("games.ninja.hintGraveKeep", { card: n(O(T(e.cardId))) });
		case "tick": return "";
	}
}, Z = 40, Q = 56;
function $(e, t, n) {
	let r = e.anchor("table");
	return r ? {
		x: r.x + r.w / 2 - t / 2,
		y: r.y + r.h / 2 - n / 2,
		w: t,
		h: n
	} : null;
}
function Te({ cardId: e }) {
	let t = T(e);
	return /* @__PURE__ */ v("span", {
		className: "grid h-full w-full place-items-center rounded-md border-2 border-ink bg-surface text-lg leading-none",
		children: [/* @__PURE__ */ _("span", {
			"aria-hidden": !0,
			children: P[t.kind]
		}), t.rank > 0 && /* @__PURE__ */ _("span", {
			"aria-hidden": !0,
			className: "absolute right-0.5 bottom-0 font-mono text-[10px] font-bold tabular-nums",
			children: t.rank
		})]
	});
}
var Ee = {
	deal(e, t) {
		let n = $(t, Z, Q), r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !n || !r ? null : {
			ms: 340,
			node: /* @__PURE__ */ _(b, {
				from: n,
				to: r,
				ms: 320,
				children: /* @__PURE__ */ _("span", {
					className: "grid h-full w-full place-items-center rounded-md border-2 border-ink bg-ink font-extrabold text-surface",
					children: "?"
				})
			})
		};
	},
	play(e, t) {
		let n = e.data;
		if (typeof n?.cardId != "number") return null;
		let r = (e.rid ? t.anchor(`seat:${e.rid}`) : null) ?? $(t, Z, Q), i = $(t, Z, Q);
		return !r || !i ? null : {
			ms: 420,
			node: /* @__PURE__ */ _(b, {
				from: r,
				to: i,
				ms: 400,
				children: /* @__PURE__ */ _(Te, { cardId: n.cardId })
			})
		};
	},
	kill(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 1100,
			node: /* @__PURE__ */ _(y, {
				at: n,
				ms: 1e3,
				children: /* @__PURE__ */ _("span", {
					"aria-hidden": !0,
					className: "text-2xl",
					children: "💀"
				})
			})
		} : null;
	},
	honor(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 1e3,
			node: /* @__PURE__ */ _(y, {
				at: n,
				ms: 900,
				children: /* @__PURE__ */ _("span", {
					"aria-hidden": !0,
					className: "text-xl",
					children: "⭐"
				})
			})
		} : null;
	},
	revealHouse(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !r || !n?.house ? null : {
			ms: 900,
			node: /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _(x, {
				at: r,
				ms: 900
			}), /* @__PURE__ */ _(y, {
				at: r,
				ms: 850,
				children: /* @__PURE__ */ _("span", {
					"aria-hidden": !0,
					className: "text-xl",
					children: F[n.house.house]
				})
			})] })
		};
	},
	steal(e, t) {
		let n = e.data, r = typeof n?.from == "string" ? t.anchor(`seat:${n.from}`) : null;
		return r ? {
			ms: 800,
			node: /* @__PURE__ */ _(x, {
				at: r,
				ms: 800
			})
		} : null;
	},
	honorSwap(e, t) {
		let n = e.data, r = typeof n?.b == "string" ? t.anchor(`seat:${n.b}`) : null;
		return r ? {
			ms: 800,
			node: /* @__PURE__ */ _(x, {
				at: r,
				ms: 800
			})
		} : null;
	}
};
//#endregion
//#region src/games/ninja/game-over.tsx
function De(e) {
	return /* @__PURE__ */ _(m, {
		adaptive: !0,
		className: "ninja-over",
		scroll: !1,
		children: /* @__PURE__ */ _(S, {
			...e,
			accent: L.accent
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/ninja/entry.tsx
var Oe = {
	definition: ge,
	View: _e,
	bot: Ce,
	describe: we,
	fx: Ee,
	OverView: De,
	locales: {
		zh: {
			name: "忍者之夜",
			desc: "两派忍者暗夜互杀:看穿谁是敌人,活到天亮为家族赢下荣誉",
			rules: "目标:为自己的家族赢下回合、获得荣誉,荣誉先到 10 分者获胜。\n准备:\n· 每名玩家秘密抽取一张家族卡，身份可能是仙鹤家族或莲花家族；玩家人数为奇数时，加入浪人身份。同一家族的玩家互为队友，但所有人的身份均保密。\n· 每回合轮抽忍者卡：先从3张牌中保留1张，将其余2张传给左侧玩家；再从收到的2张牌中保留1张，弃置剩余的1张。\n夜晚:\n· 依次结算间谍、占星师、诡计师、盲刺客和忍杀者五个阶段；同一阶段中的卡牌，按牌上数字从小到大的顺序结算。\n· 轮到你时可以亮牌执行,也可以藏牌跳过。\n· 被击败时，持有反应卡的玩家可以将其亮出：镜僧使攻击者阵亡；殉道者仍然阵亡，但获得一枚荣誉标记。\n天亮:\n· 所有玩家亮出家族身份牌。存活者中顺位最高的家族获胜，其成员各从供给中随机抽取一枚荣誉标记，面值为2至4，并保持面朝下。浪人若存活至回合结束，也抽取一枚荣誉标记。\n· 幕后黑手活到天亮时亮出,他的家族直接获胜。\n· 家族获胜时，该家族已经阵亡的成员也同样领取荣誉标记。",
			roundShort: "第 {{n}} 轮",
			draft1: "轮抽:选 1 张留下,其余传给左手边",
			draft2: "轮抽:再选 1 张,剩下那张弃掉",
			draftWaiting: "等其他人选牌({{n}}/{{total}})…",
			stageSpy: "间谍",
			stageMystic: "占星师",
			stageTrickster: "诡计师",
			stageAssassin: "盲刺客",
			stageShinobi: "忍杀者",
			stageProgress: "{{stage}} · {{rank}} 号",
			yourDecision: "轮到你决定",
			reactBanner: "有人要杀你!",
			waiting: "等 {{name}} 决定…",
			nightFalls: "夜幕降临…",
			nightWait: "夜晚进行中,留意桌上的动静",
			deadWatch: "你已阵亡,可以继续围观",
			dead: "阵亡",
			myHouse: "我的家族",
			houseUnknown: "❓ 身份成谜",
			myHonor: "我的荣誉",
			intel: "见闻",
			roundWin: "{{house}}家族获胜!",
			roundTie: "平手——无家族获胜,存活者人人有份",
			roundRoninMastermind: "浪人搅局——无家族获胜",
			mastermindReveal: "{{name}} 亮出幕后黑手!",
			awarded: "{{names}} 获得荣誉",
			nextRound: "下一回合",
			confirmWait: "已确认 {{n}}/{{total}}",
			play: "打出",
			playWithTargets: "打出({{n}}/{{total}} 个目标)",
			skip: "藏牌",
			kill: "击杀",
			spare: "放过",
			shinobiSeen: "{{name}} 的家族是 {{house}}",
			doSwap: "交换",
			noSwap: "不换",
			troubleSeen: "{{name}} 的家族是 {{house}}",
			revealIt: "公开",
			keepSecret: "保密",
			merchantPeekPrompt: "看 {{name}} 的家族,还是一枚荣誉?",
			peekHouse: "看家族",
			peekTokenAria: "看第 {{n}} 枚荣誉",
			merchantSeen: "看到 {{name}} 的 {{seen}}——要交换一枚荣誉吗?",
			tokenValue: "⭐{{value}} 分",
			myTokenAria: "我的 {{value}} 分荣誉",
			theirTokenAria: "对方第 {{n}} 枚荣誉",
			gravePeekPrompt: "从弃牌堆选 2 张偷看",
			graveCardAria: "第 {{n}} 张弃牌",
			gravePeekGo: "偷看这两张",
			graveTakePrompt: "拿哪一张?",
			keepCard: "留手",
			playNow: "立即使用",
			thiefPrompt: "偷谁的一枚荣誉?(只能偷比你多的)",
			thiefNoOne: "没有荣誉比我多的,放弃",
			noSteal: "不偷",
			stealTokenAria: "偷第 {{n}} 枚",
			reactPrompt: "{{name}} 要杀你!",
			reactMonk: "亮镜僧反杀",
			reactMartyr: "亮殉道者(阵亡,拿荣誉)",
			reactDie: "认命",
			intelHouse: "第{{round}}轮·{{name}} 的家族是 {{house}}",
			intelCard: "第{{round}}轮·{{name}} 的手牌有 {{card}}",
			intelGrave: "第{{round}}轮·弃牌堆里看到 {{cards}}",
			intelToken: "第{{round}}轮·{{name}} 有一枚 {{value}} 分荣誉",
			houseCrane: "仙鹤",
			houseLotus: "莲花",
			houseRonin: "浪人",
			card: {
				spy: "间谍",
				mystic: "占星师",
				trickster1: "变形者",
				trickster2: "掘墓人",
				trickster3: "捣乱鬼",
				trickster4: "灵魂商人",
				trickster5: "窃贼",
				trickster6: "判官",
				assassin: "盲刺客",
				shinobi: "忍杀者",
				monk: "镜僧",
				martyr: "殉道者",
				mastermind: "幕后黑手"
			},
			eff: {
				spy: "偷看一名玩家的家族",
				mystic: "偷看一名玩家的家族和一张手牌",
				trickster1: "偷看两名玩家的家族,可以暗中交换",
				trickster2: "偷看 2 张弃牌,拿 1 张立即用或留手",
				trickster3: "偷看一名玩家的家族,可以公开它",
				trickster4: "偷看一名玩家的荣誉或家族,可以交换一枚荣誉",
				trickster5: "亮出自己家族,可从荣誉比你多的玩家处拿一枚",
				trickster6: "亮出自己家族,直接杀死一名玩家(反应卡无效)",
				assassin: "盲选一名玩家,杀死他",
				shinobi: "偷看一名玩家的家族,可以选择杀死他",
				monk: "被杀时亮出:反杀攻击者",
				martyr: "被杀时亮出:你阵亡,但拿一枚荣誉",
				mastermind: "天亮时若你还活着,亮出它你的家族直接获胜"
			},
			errNotYourTurn: "现在轮不到你",
			errBadCard: "这张卡现在不能打",
			errBadTarget: "目标不合法",
			errBadChoice: "这个选择不合法",
			hintDraft: "选 {{card}} 留下",
			hintPlay: "打出 {{card}}",
			hintMerchantSwap: "与对方交换一枚荣誉",
			hintGraveKeep: "拿 {{card}} 留手",
			hintGravePlay: "拿 {{card}} 立即使用"
		},
		en: {
			name: "Night of the Ninja",
			desc: "Two ninja houses strike in the dark: unmask your enemies, survive till dawn, win Honor for your House",
			rules: "Goal: win rounds for your House and gather Honor; first to 10 points wins.\nSetup:\n· Each player receives a secret House card showing Crane or Lotus. Add the Ronin when the number of players is odd. Players in the same House are teammates, but all identities remain secret.\n· Each round, draft Ninja cards: pick 1 of 3, pass the rest left, pick 1 more, discard the last.\nThe Night:\n· Resolve five stages in this order: Spy, Mystic, Trickster, Blind Assassin and Shinobi. Within each stage, resolve cards in ascending numerical order.\n· On your turn you may reveal and resolve your card, or keep it hidden and skip.\n· When killed, a reaction card may be revealed: the Mirror Monk kills your attacker, the Martyr dies but gains Honor.\nDawn:\n· Survivors reveal their Houses: the House with the highest-ranked survivor wins, and every member draws a face-down Honor token (worth 2–4); a surviving Ronin also draws one.\n· A Mastermind alive at dawn may reveal it to win the round for their House.\n· Eliminated members of the winning House also receive Honor tokens.",
			roundShort: "Round {{n}}",
			draft1: "Draft: keep 1 card, pass the rest left",
			draft2: "Draft: keep 1 more, discard the last",
			draftWaiting: "Waiting for others ({{n}}/{{total}})…",
			stageSpy: "Spy",
			stageMystic: "Mystic",
			stageTrickster: "Trickster",
			stageAssassin: "Blind Assassin",
			stageShinobi: "Shinobi",
			stageProgress: "{{stage}} · #{{rank}}",
			yourDecision: "Your move",
			reactBanner: "You are being attacked!",
			waiting: "Waiting for {{name}}…",
			nightFalls: "Night falls…",
			nightWait: "The Night is on — watch the table",
			deadWatch: "You are dead — keep watching",
			dead: "Dead",
			myHouse: "My House",
			houseUnknown: "❓ Identity unknown",
			myHonor: "My Honor",
			intel: "Intel",
			roundWin: "House {{house}} wins the round!",
			roundTie: "Total tie — no House wins; every survivor gains Honor",
			roundRoninMastermind: "The Ronin Mastermind strikes — no House wins",
			mastermindReveal: "{{name}} reveals the Mastermind!",
			awarded: "{{names}} gain Honor",
			nextRound: "Next round",
			confirmWait: "Confirmed {{n}}/{{total}}",
			play: "Play",
			playWithTargets: "Play ({{n}}/{{total}} targets)",
			skip: "Keep hidden",
			kill: "Kill",
			spare: "Spare",
			shinobiSeen: "{{name}}'s House is {{house}}",
			doSwap: "Swap",
			noSwap: "No swap",
			troubleSeen: "{{name}}'s House is {{house}}",
			revealIt: "Reveal",
			keepSecret: "Keep secret",
			merchantPeekPrompt: "Look at {{name}}'s House, or one Honor token?",
			peekHouse: "Look at House",
			peekTokenAria: "Look at token #{{n}}",
			merchantSeen: "You saw {{name}}'s {{seen}} — swap one Honor token?",
			tokenValue: "⭐{{value}}",
			myTokenAria: "My {{value}}-point token",
			theirTokenAria: "Their token #{{n}}",
			gravePeekPrompt: "Pick 2 discarded cards to peek at",
			graveCardAria: "Discard #{{n}}",
			gravePeekGo: "Peek at these two",
			graveTakePrompt: "Take which one?",
			keepCard: "Keep",
			playNow: "Play now",
			thiefPrompt: "Steal one Honor token from whom? (must have more than you)",
			thiefNoOne: "Nobody has more Honor — skip",
			noSteal: "Skip",
			stealTokenAria: "Steal token #{{n}}",
			reactPrompt: "{{name}} is killing you!",
			reactMonk: "Mirror Monk: kill them",
			reactMartyr: "Martyr: die, gain Honor",
			reactDie: "Accept death",
			intelHouse: "R{{round}} · {{name}}'s House is {{house}}",
			intelCard: "R{{round}} · {{name}} holds {{card}}",
			intelGrave: "R{{round}} · Saw {{cards}} in the discards",
			intelToken: "R{{round}} · {{name}} has a {{value}}-point token",
			houseCrane: "Crane",
			houseLotus: "Lotus",
			houseRonin: "Ronin",
			card: {
				spy: "Spy",
				mystic: "Mystic",
				trickster1: "Shapeshifter",
				trickster2: "Grave Digger",
				trickster3: "Troublemaker",
				trickster4: "Spirit Merchant",
				trickster5: "Thief",
				trickster6: "Judge",
				assassin: "Blind Assassin",
				shinobi: "Shinobi",
				monk: "Mirror Monk",
				martyr: "Martyr",
				mastermind: "Mastermind"
			},
			eff: {
				spy: "Look at another player's House card",
				mystic: "Look at another player's House card and one Ninja card",
				trickster1: "Look at two players' House cards; you may secretly swap them",
				trickster2: "Look at 2 discarded Ninja cards; take 1 to play now or keep",
				trickster3: "Look at another player's House card; you may reveal it",
				trickster4: "Look at another player's Honor token or House card; you may swap one Honor token",
				trickster5: "Reveal your House; you may take an Honor token from a player who has more",
				trickster6: "Reveal your House; choose a player and kill them (reacts do not work)",
				assassin: "Choose a player and kill them, blind",
				shinobi: "Look at a player's House card; you may kill them",
				monk: "Reveal when killed: kill the attacker instead",
				martyr: "Reveal when killed: you die, but gain Honor",
				mastermind: "If alive at dawn, reveal it: your House wins the round"
			},
			errNotYourTurn: "Not your turn",
			errBadCard: "Cannot play this card now",
			errBadTarget: "Invalid target",
			errBadChoice: "Invalid choice",
			hintDraft: "Keep {{card}}",
			hintPlay: "Play {{card}}",
			hintMerchantSwap: "Swap one honor token with the target",
			hintGraveKeep: "Take {{card}} to hand",
			hintGravePlay: "Take {{card}} and play it now"
		}
	}
};
//#endregion
export { Oe as default };
