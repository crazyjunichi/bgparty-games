import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useMemo as r, useRef as i, useState as a } from "react";
import { avatarNameAt as o, useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as u } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as d } from "@bgparty/sdk/ui/player-strip";
import { gridCells as f } from "@bgparty/sdk/sheet-geometry";
import { SheetMark as p } from "@bgparty/sdk/sheet-mark";
import { SheetText as m, SheetView as ee } from "@bgparty/sdk/sheet-view";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { botAvatarOf as v } from "@bgparty/sdk/lobby";
import { AVATARS as y } from "@bgparty/sdk/avatars";
import { ConfirmButton as b } from "@bgparty/sdk/confirm-button";
import { IconExpand as x, IconLog as te } from "@bgparty/sdk/icons";
import { OptionRadio as S, OptionSection as C } from "@bgparty/sdk/ui/game-options";
//#region src/games/moon/adv/adv1.ts
var w = [
	{
		quarter: 4,
		value: 2
	},
	{
		quarter: 6,
		value: 2
	},
	{
		quarter: 8,
		value: 4
	},
	{
		quarter: 11,
		value: 4
	},
	{
		quarter: 12,
		value: 3
	},
	{
		quarter: 16,
		value: 3
	},
	{
		quarter: 17,
		value: 2
	}
], T = [
	{
		start: 0,
		size: 2,
		rocket: 2,
		build: !0,
		sabs: []
	},
	{
		start: 2,
		size: 2,
		rocket: 2,
		build: !0,
		sabs: []
	},
	{
		start: 4,
		size: 2,
		rocket: 2,
		build: !0,
		sabs: []
	},
	{
		start: 6,
		size: 2,
		activation: !0,
		build: !0,
		sabs: []
	},
	{
		start: 8,
		size: 2,
		rocket: 2,
		inactive: 0,
		sabs: []
	},
	{
		start: 10,
		size: 2,
		rocket: 2,
		activation: !0,
		sabs: []
	},
	{
		start: 12,
		size: 2,
		rocket: 2,
		inactive: 1,
		sabs: []
	},
	{
		start: 14,
		size: 2,
		build: !0,
		sabs: [0]
	},
	{
		start: 16,
		size: 5,
		rocket: 4,
		inactive: 2,
		sabs: [1, 2]
	},
	{
		start: 21,
		size: 2,
		rocket: 3,
		sabs: []
	},
	{
		start: 23,
		size: 3,
		rocket: 2,
		activation: !0,
		build: !0,
		sabs: []
	},
	{
		start: 26,
		size: 6,
		rocket: 4,
		inactive: 3,
		build: !0,
		sabs: [3]
	},
	{
		start: 32,
		size: 5,
		rocket: 3,
		inactive: 4,
		sabs: [4, 5]
	},
	{
		start: 37,
		size: 2,
		activation: !0,
		build: !0,
		sabs: []
	},
	{
		start: 39,
		size: 3,
		rocket: 3,
		build: !0,
		sabs: []
	},
	{
		start: 42,
		size: 2,
		rocket: 2,
		sabs: [6]
	},
	{
		start: 44,
		size: 3,
		rocket: 3,
		inactive: 5,
		sabs: []
	},
	{
		start: 47,
		size: 3,
		rocket: 2,
		inactive: 6,
		sabs: [7]
	},
	{
		start: 50,
		size: 3,
		rocket: 3,
		activation: !0,
		build: !0,
		sabs: []
	}
], E = [
	{
		action: "wild",
		quarters: [
			0,
			1,
			2,
			3
		]
	},
	{
		action: "plant",
		quarters: [
			4,
			5,
			6,
			7
		]
	},
	{
		action: "energy",
		quarters: [
			8,
			9,
			10
		]
	},
	{
		action: "planning",
		quarters: [11]
	},
	{
		action: "robot",
		quarters: [12]
	},
	{
		action: "robot",
		quarters: [13, 14]
	},
	{
		action: "water",
		quarters: [15, 16]
	},
	{
		action: "astronaut",
		quarters: [17]
	},
	{
		action: "astronaut",
		quarters: [18]
	}
], D = [
	5,
	4,
	3,
	3,
	3,
	3,
	3,
	3,
	2,
	2
], O = [
	0,
	15,
	30,
	45,
	60,
	75,
	90,
	105,
	120,
	135,
	150
];
function k() {
	return Array(53).fill(null);
}
function A(e) {
	for (let t = E.length - 1; t >= 0; --t) if (e >= T[E[t].quarters[0]].start) return t;
	return 0;
}
function j(e) {
	for (let t = 0; t < T.length; t += 1) {
		let n = T[t];
		if (e >= n.start && e < n.start + n.size) return t;
	}
	return -1;
}
function M(e, t, n) {
	if (t < 0 || t >= 53 || e[t] !== null) return !1;
	let r = A(t), i = T[E[r].quarters[0]].start, a = T[E[r].quarters.at(-1)].start + T[E[r].quarters.at(-1)].size;
	for (let r = i; r < t; r += 1) {
		let t = e[r];
		if (typeof t == "number" && t >= n) return !1;
	}
	for (let r = t + 1; r < a; r += 1) {
		let t = e[r];
		if (typeof t == "number" && t <= n) return !1;
	}
	return !0;
}
function N(e) {
	let t = [];
	for (let n = 0; n < E.length; n += 1) (E[n].action === e || E[n].action === "wild") && t.push(n);
	return t;
}
function P(e, t, n) {
	let r = [];
	for (let i of N(t)) for (let t of E[i].quarters) {
		let i = T[t];
		for (let t = i.start; t < i.start + i.size; t += 1) M(e, t, n) && r.push(t);
	}
	return r;
}
function F(e, t) {
	let n = T[t];
	for (let t = n.start; t < n.start + n.size; t += 1) if (e[t] === null) return !1;
	return !0;
}
function I(e, t) {
	return E[t].quarters.every((t) => F(e, t));
}
function L(e) {
	return e.every((e) => e !== null);
}
function R(e) {
	let t = 0, n = 0;
	for (let r of D) n += r, e >= n && (t += 1);
	return t;
}
function ne(e) {
	return e.launched ? 150 : O[R(e.track)] - 5 * (e.circled - e.cleared);
}
var re = {
	64: {
		id: 64,
		kind: "A",
		hi: 3,
		lo: 2
	},
	65: {
		id: 65,
		kind: "A",
		hi: 4,
		lo: 2
	},
	66: {
		id: 66,
		kind: "B",
		hi: 3,
		lo: 2
	},
	67: {
		id: 67,
		kind: "B",
		hi: 3,
		lo: 2
	},
	68: {
		id: 68,
		kind: "C",
		hi: 2,
		lo: 1
	},
	69: {
		id: 69,
		kind: "C",
		hi: 3,
		lo: 2
	}
}, ie = {
	A: [64, 65],
	B: [66, 67],
	C: [68, 69]
};
function z(e, t) {
	switch (e) {
		case 64: return I(t.cells, 6) && I(t.cells, 7) && I(t.cells, 8);
		case 65: return I(t.cells, 3) && I(t.cells, 4) && I(t.cells, 5);
		case 66: return I(t.cells, 2);
		case 67: return I(t.cells, 0) && I(t.cells, 1);
		case 68: return t.xCount >= 10;
		case 69: return t.circled - t.cleared >= 5;
	}
}
//#endregion
//#region src/games/moon/adv/common.ts
function B(t, n) {
	let r = t.rngCursor;
	for (let i = n.length - 1; i > 0; --i) {
		let a = e(t.seed, r, i + 1);
		r += 1, [n[i], n[a]] = [n[a], n[i]];
	}
	return t.rngCursor = r, n;
}
function V(e, t) {
	return e.piles[t].length === 0 && (e.piles[t] = B(e, e.discards[t]), e.discards[t] = []), e.piles[t].pop();
}
function ae(e, t, n, r, i) {
	let a = [];
	return t.forEach((t, o) => {
		let s = e.filter((e) => n[e][o] === null && i(t, r[e]));
		if (s.length === 0) return;
		let c = !e.some((e) => n[e][o] !== null);
		for (let e of s) a.push({
			rid: e,
			slot: o,
			level: c ? "high" : "low"
		});
	}), a;
}
var H = [
	[1, ["robot", "energy"]],
	[2, ["robot", "plant"]],
	[3, [
		"water",
		"astronaut",
		"planning"
	]],
	[4, [
		"energy",
		"plant",
		"astronaut",
		"planning"
	]],
	[5, [
		"robot",
		"robot",
		"energy",
		"energy",
		"plant"
	]],
	[6, [
		"robot",
		"energy",
		"plant",
		"water",
		"astronaut",
		"planning"
	]],
	[7, [
		"robot",
		"energy",
		"energy",
		"plant",
		"plant",
		"water"
	]],
	[8, [
		"robot",
		"robot",
		"energy",
		"plant",
		"plant",
		"water",
		"planning"
	]],
	[9, [
		"robot",
		"energy",
		"plant",
		"plant",
		"water",
		"astronaut"
	]],
	[10, [
		"robot",
		"energy",
		"plant",
		"water",
		"astronaut",
		"planning"
	]],
	[11, [
		"robot",
		"robot",
		"energy",
		"energy",
		"plant"
	]],
	[12, [
		"energy",
		"plant",
		"astronaut",
		"planning"
	]],
	[13, [
		"water",
		"astronaut",
		"planning"
	]],
	[14, ["robot", "plant"]],
	[15, ["robot", "energy"]]
].flatMap(([e, t]) => t.map((t) => ({
	n: e,
	act: t
}))), oe = [
	0,
	5,
	10,
	15
], se = [14, 21], ce = [
	5,
	30,
	...se
], le = [
	[
		0,
		1,
		2,
		6,
		7,
		8,
		12,
		13,
		14
	],
	[
		3,
		4,
		5,
		9,
		10,
		11,
		15,
		16,
		17
	],
	[
		18,
		19,
		20,
		24,
		25,
		26,
		30,
		31,
		32
	],
	[
		21,
		22,
		23,
		27,
		28,
		29,
		33,
		34,
		35
	]
];
function ue(e) {
	return le.findIndex((t) => t.includes(e));
}
var de = [
	0,
	8,
	10,
	17,
	19,
	26,
	28,
	33
], fe = [
	1,
	3,
	8,
	10,
	12,
	15,
	19,
	22,
	24,
	27,
	29,
	31,
	34
], pe = le.map((e) => {
	let t = fe.map((t, n) => e.includes(t) ? n : -1).filter((e) => e >= 0);
	return e.includes(5) && t.push(13, 14, 15), t;
}), me = le.map((e) => de.map((t, n) => e.includes(t) ? n : -1).filter((e) => e >= 0)), he = [25, 54];
function ge(e) {
	if (e < 30) {
		let t = Math.floor(e / 5), n = e % 5;
		return [t * 6 + n, t * 6 + n + 1];
	}
	let t = e - 30, n = Math.floor(t / 6), r = t % 6;
	return [n * 6 + r, (n + 1) * 6 + r];
}
var _e = {
	plant: [
		0,
		1,
		2,
		3,
		4
	],
	water: [
		0,
		2,
		4,
		6,
		8
	],
	antenna: [
		0,
		1,
		2,
		4,
		6
	]
}, ve = [
	0,
	1,
	3,
	6,
	9,
	12,
	16,
	20,
	24,
	28
], ye = [
	20,
	10,
	5
], be = {
	high: 15,
	low: 5
};
function xe() {
	let e = Array(36).fill(null);
	for (let t of ce) e[t] = "x";
	return {
		cells: e,
		tanks: de.map(() => !1),
		antennas: Array(16).fill(!1),
		greenhouses: Array(16).fill(!1),
		tunnels: Array.from({ length: 60 }, (e, t) => he.includes(t)),
		trackPlant: 0,
		trackWater: 0,
		trackAntenna: 0,
		astronauts: 0,
		planning: 0,
		errors: 0,
		quarterTurn: [
			-1,
			-1,
			-1,
			-1
		]
	};
}
function Se(e, t, n) {
	if (t < 0 || t >= 36 || e[t] !== null) return !1;
	let r = Math.floor(t / 6), i = t % 6;
	for (let t = 0; t < 6; t += 1) {
		let a = e[r * 6 + t];
		if (typeof a == "number" && (t < i && a >= n || t > i && a <= n)) return !1;
	}
	for (let t = 0; t < 6; t += 1) {
		let a = e[t * 6 + i];
		if (typeof a == "number" && (t > r && a >= n || t < r && a <= n)) return !1;
	}
	return !0;
}
function Ce(e, t) {
	let n = [];
	for (let r = 0; r < 36; r += 1) Se(e, r, t) && n.push(r);
	return n;
}
function we(e) {
	let t = /* @__PURE__ */ new Set([30]), n = [30];
	for (; n.length > 0;) {
		let r = n.pop();
		for (let i = 0; i < 60; i += 1) {
			if (!e[i]) continue;
			let [a, o] = ge(i), s = a === r ? o : o === r ? a : -1;
			s >= 0 && !t.has(s) && (t.add(s), n.push(s));
		}
	}
	return t;
}
function Te(e) {
	let t = we(e), n = [];
	for (let r = 0; r < 60; r += 1) {
		if (e[r]) continue;
		let [i, a] = ge(r);
		t.has(i) !== t.has(a) && n.push(r);
	}
	return n;
}
function Ee(e) {
	let t = we(e.tunnels);
	fe.forEach((n, r) => {
		!e.antennas[r] && typeof e.cells[n] == "number" && t.has(n) && (e.antennas[r] = !0);
	}), t.has(5) && (e.antennas[13] = !0, e.antennas[14] = !0, e.antennas[15] = !0);
}
function De(e, t) {
	le.forEach((n, r) => {
		e.quarterTurn[r] === -1 && n.every((t) => e.cells[t] !== null) && (e.quarterTurn[r] = t);
	});
}
function Oe(e) {
	return e.greenhouses.reduce((e, t, n) => e + (t ? n % 4 == 3 ? 2 : 1 : 0), 0);
}
var ke = {
	76: {
		id: 76,
		kind: "A",
		hi: 12,
		lo: 6
	},
	77: {
		id: 77,
		kind: "A",
		hi: 12,
		lo: 5
	},
	78: {
		id: 78,
		kind: "B",
		hi: 9,
		lo: 4
	},
	79: {
		id: 79,
		kind: "B",
		hi: 9,
		lo: 4
	},
	80: {
		id: 80,
		kind: "C",
		hi: 8,
		lo: 4
	},
	81: {
		id: 81,
		kind: "C",
		hi: 9,
		lo: 5
	}
}, Ae = {
	A: [76, 77],
	B: [78, 79],
	C: [80, 81]
};
function je(e, t) {
	switch (e) {
		case 76: {
			let e = 0;
			for (let n = 0; n < 6; n += 1) {
				let r = !0;
				for (let e = 0; e < 6; e += 1) t.cells[e * 6 + n] === null && (r = !1);
				r && (e += 1);
			}
			return e >= 3;
		}
		case 77: {
			let e = 0;
			for (let n = 0; n < 6; n += 1) {
				let r = !0;
				for (let e = 0; e < 6; e += 1) t.cells[n * 6 + e] === null && (r = !1);
				r && (e += 1);
			}
			return e >= 3;
		}
		case 78: return we(t.tunnels).has(5);
		case 79: return pe.filter((e) => e.every((e) => t.antennas[e])).length >= 2;
		case 80: return Oe(t) >= 10;
		case 81: return me.filter((e) => e.every((e) => t.tanks[e])).length >= 2;
	}
}
function Me(e) {
	let t = Oe(e), n = e.tanks.filter(Boolean).length, r = e.antennas.filter(Boolean).length;
	return t * _e.plant[e.trackPlant] + n * _e.water[e.trackWater] + r * _e.antenna[e.trackAntenna];
}
function Ne(e) {
	return e.planning < 10 ? ve[e.planning] : 0;
}
function Pe(e) {
	return oe[Math.min(e.errors, 3)];
}
function Fe(e) {
	return Me(e) - Ne(e) - Pe(e);
}
function Ie(e, t) {
	let n = {};
	for (let r of e) {
		let i = 0;
		t[r].quarterTurn.forEach((n, r) => {
			if (n === -1) return;
			let a = Math.min(...e.map((e) => t[e].quarterTurn[r]).filter((e) => e !== -1));
			i += n === a ? be.high : be.low;
		}), n[r] = i;
	}
	return n;
}
function Le(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let r of e) {
		let e = t[r].astronauts;
		n.has(e) || n.set(e, []), n.get(e).push(r);
	}
	let r = {};
	for (let t of e) r[t] = 0;
	let i = 0;
	for (let e of [...n.keys()].filter((e) => e > 0).sort((e, t) => t - e)) {
		let t = n.get(e), a = ye[i] ?? 0;
		for (let e of t) r[e] = a;
		i += t.length;
	}
	return r;
}
function Re(e, t) {
	return t.reduce((t, n, r) => {
		if (!n) return t;
		let i = ke[e[r]];
		return t + (n === "high" ? i.hi : i.lo);
	}, 0);
}
function ze(e, t, n, r, i) {
	return Fe(t[i]) + Re(n, r[i]) + Ie(e, t)[i] + Le(e, t)[i];
}
var U = {
	over: "games.moon.errOver",
	badStage: "games.moon.errBadStage",
	alreadyDone: "games.moon.errAlreadyDone",
	badCell: "games.moon.errBadCell",
	badCombo: "games.moon.errBadCombo",
	canPlace: "games.moon.errCanPlace",
	badEffect: "games.moon.errBadEffect",
	badTarget: "games.moon.errBadTarget",
	badMod: "games.moon.errBadMod"
};
function Be() {
	return {
		combo: null,
		cell: null,
		error: !1,
		queue: []
	};
}
function Ve(e) {
	e.turn += 1, e.flipped = [
		V(e, 0),
		V(e, 1),
		V(e, 2)
	], e.picks = {};
	for (let t of e.players) e.picks[t] = Be();
}
function He(t, n) {
	let r = {
		adv: 3,
		players: t,
		turn: 0,
		seed: n,
		rngCursor: 3,
		piles: [
			[],
			[],
			[]
		],
		discards: [
			[],
			[],
			[]
		],
		flipped: [
			H[0],
			H[0],
			H[0]
		],
		missions: [
			76,
			78,
			80
		],
		missionClaims: {},
		sheets: {},
		picks: {},
		phase: "pick"
	};
	r.missions = [
		"A",
		"B",
		"C"
	].map((t, r) => Ae[t][e(n, r, 2)]);
	let i = B(r, [...H]);
	r.piles = [
		i.slice(0, 21),
		i.slice(21, 42),
		i.slice(42)
	];
	for (let e of t) r.sheets[e] = xe(), r.missionClaims[e] = [
		null,
		null,
		null
	];
	return Ve(r), {
		state: r,
		fx: []
	};
}
function Ue(e) {
	return e.players.every((t) => {
		let n = e.picks[t];
		return (n.combo !== null || n.error) && n.queue.length === 0;
	});
}
function We(e, t, n, r) {
	let i = e.sheets[t], a = e.picks[t];
	switch (n) {
		case "water": {
			let e = de.indexOf(r);
			e >= 0 && !i.tanks[e] && (i.tanks[e] = !0);
			break;
		}
		case "plant": {
			let e = ue(r);
			for (let t = 0; t < 4; t += 1) {
				let n = e * 4 + t;
				if (!i.greenhouses[n]) {
					i.greenhouses[n] = !0;
					break;
				}
			}
			break;
		}
		case "robot":
			Te(i.tunnels).length > 0 && a.queue.push("robot");
			break;
		case "energy":
			(i.trackPlant < 4 || i.trackWater < 4 || i.trackAntenna < 4) && a.queue.push("energy");
			break;
		case "planning": i.planning < 10 && i.cells.some((e) => e === null) && a.queue.push("planX");
	}
}
function Ge(e) {
	for (let t of ae(e.players, e.missions, e.missionClaims, e.sheets, (e, t) => je(e, t))) e.missionClaims[t.rid][t.slot] = t.level;
	if (e.players.some((t) => {
		let n = e.sheets[t];
		return e.missionClaims[t].filter(Boolean).length >= 3 || n.errors >= 4 || n.cells.every((e) => e !== null);
	})) {
		e.phase = "done";
		return;
	}
	e.flipped.forEach((t, n) => e.discards[n].push(t)), Ve(e);
}
function Ke(e, t, n) {
	if (e.phase === "done") return { code: U.over };
	let r = e.picks[n.by];
	if (!r) return { code: U.badStage };
	if (t.type === "pick") {
		if (r.combo !== null || r.error) return { code: U.alreadyDone };
		let i = e.flipped[t.combo];
		if (!i) return { code: U.badCombo };
		let a = e.sheets[n.by];
		if (t.mod !== void 0 && (i.act !== "astronaut" || a.astronauts >= 9 || i.n + t.mod < 0 || i.n + t.mod > 17)) return { code: U.badMod };
		let o = i.n + (t.mod ?? 0);
		if (!Se(a.cells, t.cell, o)) return { code: U.badCell };
		let s = structuredClone(e), c = s.sheets[n.by];
		c.cells[t.cell] = o, t.mod !== void 0 && (c.astronauts += 1);
		let l = s.picks[n.by];
		return l.combo = t.combo, l.cell = t.cell, Ee(c), De(c, s.turn), We(s, n.by, i.act, t.cell), Ue(s) && Ge(s), {
			state: s,
			fx: []
		};
	}
	if (t.type === "error") {
		if (r.combo !== null || r.error) return { code: U.alreadyDone };
		let t = e.sheets[n.by];
		if (!e.flipped.every((e) => Ce(t.cells, e.n).length === 0)) return { code: U.canPlace };
		let i = structuredClone(e);
		return i.sheets[n.by].errors = Math.min(4, i.sheets[n.by].errors + 1), i.picks[n.by].error = !0, Ue(i) && Ge(i), {
			state: i,
			fx: []
		};
	}
	let i = r.queue[0];
	if (t.type === "skip") {
		if (!i) return { code: U.badEffect };
		let t = structuredClone(e);
		return t.picks[n.by].queue.shift(), Ue(t) && Ge(t), {
			state: t,
			fx: []
		};
	}
	if (t.type === "tunnel") {
		if (i !== "robot") return { code: U.badEffect };
		if (t.edge < 0 || t.edge >= 60 || e.sheets[n.by].tunnels[t.edge] || !Te(e.sheets[n.by].tunnels).includes(t.edge)) return { code: U.badTarget };
		let r = structuredClone(e), a = r.sheets[n.by];
		return a.tunnels[t.edge] = !0, Ee(a), r.picks[n.by].queue.shift(), Ue(r) && Ge(r), {
			state: r,
			fx: []
		};
	}
	if (t.type === "energy") {
		if (i !== "energy") return { code: U.badEffect };
		let r = e.sheets[n.by];
		if ((t.track === 0 ? r.trackPlant : t.track === 1 ? r.trackWater : r.trackAntenna) >= 4) return { code: U.badTarget };
		let a = structuredClone(e), o = a.sheets[n.by];
		return t.track === 0 ? o.trackPlant += 1 : t.track === 1 ? o.trackWater += 1 : o.trackAntenna += 1, a.picks[n.by].queue.shift(), Ue(a) && Ge(a), {
			state: a,
			fx: []
		};
	}
	if (t.type === "planX") {
		if (i !== "planX") return { code: U.badEffect };
		let r = e.sheets[n.by];
		if (r.planning >= 10) return { code: U.badEffect };
		if (t.cell < 0 || t.cell >= 36 || r.cells[t.cell] !== null) return { code: U.badCell };
		let a = structuredClone(e), o = a.sheets[n.by];
		return o.cells[t.cell] = "x", o.planning += 1, Ee(o), De(o, a.turn), a.picks[n.by].queue.shift(), Ue(a) && Ge(a), {
			state: a,
			fx: []
		};
	}
	return { code: U.badStage };
}
var qe = [
	0,
	5,
	10,
	15
], Je = [
	"pearl",
	"pearl",
	null,
	"ruby",
	null,
	"ruby",
	"ruby",
	"ruby",
	"pearl",
	"ruby",
	"pearl",
	"pearl",
	"ruby",
	null,
	"pearl",
	null,
	"ruby",
	null,
	"ruby",
	"pearl",
	null,
	"pearl",
	null,
	"pearl",
	"pearl",
	"ruby",
	"ruby",
	"ruby",
	"pearl",
	"ruby",
	null,
	null,
	"ruby",
	null,
	"pearl",
	"ruby"
], Ye = [
	"plant",
	"water",
	"plant",
	"water",
	null,
	"plant",
	null,
	"water",
	"plant",
	"plant",
	"water",
	"plant",
	"plant",
	"plant",
	null,
	"plant",
	"water",
	null,
	"water",
	"water",
	"plant",
	"water",
	"plant",
	"plant"
], W = [
	{
		kind: "plant",
		slots: 14,
		low: 2,
		high: 4,
		bolts: 1,
		robots: 3,
		badgeAt: 7,
		badgeValue: 8
	},
	{
		kind: "water",
		slots: 10,
		low: 3,
		high: 5,
		bolts: 1,
		robots: 2,
		badgeAt: 5,
		badgeValue: 10
	},
	{
		kind: "pearl",
		slots: 14,
		low: 2,
		high: 3,
		bolts: 2,
		robots: 1,
		badgeAt: 9,
		badgeValue: 8
	},
	{
		kind: "ruby",
		slots: 16,
		low: 2,
		high: 3,
		bolts: 2,
		robots: 2,
		badgeAt: 11,
		badgeValue: 12
	},
	{
		kind: "astro",
		slots: 8,
		low: 0,
		high: 3,
		bolts: 1,
		robots: 1,
		badgeAt: null,
		badgeValue: 0
	},
	{
		kind: "plan",
		slots: 6,
		low: -3,
		high: 0,
		bolts: 1,
		robots: 1,
		badgeAt: null,
		badgeValue: 0
	}
], Xe = {
	plant: 0,
	water: 1,
	pearl: 2,
	ruby: 3
}, G = [
	{
		bolts: 1,
		robots: 1,
		give: 0
	},
	{
		bolts: 1,
		robots: 2,
		give: 1
	},
	{
		bolts: 1,
		robots: 2,
		give: 2
	},
	{
		bolts: 1,
		robots: 1,
		give: 3
	},
	{
		bolts: 2,
		robots: 0,
		give: "robots"
	}
];
function Ze() {
	return {
		cells: Array(36).fill(null),
		minerals: Array(36).fill(0),
		stems: Array(24).fill(0),
		pumps: Array(12).fill(!1),
		circled: [
			,
			,
			,
			,
			,
			,
		].fill(0),
		bolts: [
			,
			,
			,
			,
			,
			,
		].fill(0),
		robots: [
			,
			,
			,
			,
			,
			,
		].fill(0),
		upgraded: [
			,
			,
			,
			,
			,
			,
		].fill(!1),
		badge: [
			null,
			null,
			null,
			null
		],
		subBolts: [
			,
			,
			,
			,
			,
		].fill(0),
		subRobots: [
			,
			,
			,
			,
			,
		].fill(0),
		subUsed: [
			,
			,
			,
			,
			,
		].fill(!1),
		errors: 0
	};
}
function Qe(e, t, n) {
	if (t < 0 || t >= 36 || e[t] !== null) return !1;
	let r = Math.floor(t / 12), i = t % 12;
	for (let t = 0; t < 12; t += 1) {
		let a = e[r * 12 + t];
		if (typeof a == "number" && (t < i && a >= n || t > i && a <= n)) return !1;
	}
	return !0;
}
function $e(e, t) {
	let n = [];
	for (let r = 0; r < 36; r += 1) Qe(e, r, t) && n.push(r);
	return n;
}
function et(e) {
	let t = Math.floor(e / 12), n = e % 12, r = [];
	return t > 0 && r.push((t - 1) * 12 + n), t < 2 && r.push(t * 12 + n), r;
}
var tt = {
	82: {
		id: 82,
		kind: "A",
		hi: 8,
		lo: 4
	},
	83: {
		id: 83,
		kind: "A",
		hi: 9,
		lo: 4
	},
	84: {
		id: 84,
		kind: "B",
		hi: 11,
		lo: 6
	},
	85: {
		id: 85,
		kind: "B",
		hi: 10,
		lo: 4
	},
	86: {
		id: 86,
		kind: "C",
		hi: 8,
		lo: 3
	},
	87: {
		id: 87,
		kind: "C",
		hi: 10,
		lo: 4
	}
}, nt = {
	A: [82, 83],
	B: [84, 85],
	C: [86, 87]
};
function rt(e, t) {
	switch (e) {
		case 82: return t.pumps.filter(Boolean).length >= 5;
		case 83:
			for (let e = 0; e + 4 <= 12; e += 1) if (t.pumps.slice(e, e + 4).every(Boolean)) return !0;
			return !1;
		case 84: return t.subUsed.every(Boolean);
		case 85: return t.upgraded.filter(Boolean).length + t.subUsed.filter(Boolean).length >= 6;
		case 86: {
			let e = 0;
			return Ye.forEach((n, r) => {
				n === "plant" && t.stems[r] >= 1 && (e += 1);
			}), e >= 8;
		}
		case 87: {
			let e = 0;
			return Ye.forEach((n, r) => {
				n === "water" && t.stems[r] >= 1 && (e += 1);
			}), e >= 5;
		}
	}
}
function it(e) {
	return qe[Math.min(e.errors, 3)];
}
function at(e) {
	let t = 0;
	return W.forEach((n, r) => {
		t += e.circled[r] * (e.upgraded[r] ? n.high : n.low), n.badgeAt !== null && e.badge[r] === "circle" && (t += n.badgeValue);
	}), t;
}
function ot(e) {
	return at(e) - it(e);
}
function st(e, t) {
	return t.reduce((t, n, r) => {
		if (!n) return t;
		let i = tt[e[r]];
		return t + (n === "high" ? i.hi : i.lo);
	}, 0);
}
function ct(e, t, n, r) {
	return ot(e[r]) + st(t, n[r]);
}
var K = {
	over: "games.moon.errOver",
	badStage: "games.moon.errBadStage",
	alreadyDone: "games.moon.errAlreadyDone",
	badCell: "games.moon.errBadCell",
	badCombo: "games.moon.errBadCombo",
	canPlace: "games.moon.errCanPlace",
	badEffect: "games.moon.errBadEffect",
	badTarget: "games.moon.errBadTarget",
	badMod: "games.moon.errBadMod"
};
function lt() {
	return {
		combo: null,
		cell: null,
		error: !1,
		extracted: !1,
		queue: []
	};
}
function ut(e) {
	e.turn += 1, e.flipped = [
		V(e, 0),
		V(e, 1),
		V(e, 2)
	], e.picks = {};
	for (let t of e.players) e.picks[t] = lt();
}
function dt(t, n) {
	let r = {
		adv: 4,
		players: t,
		turn: 0,
		seed: n,
		rngCursor: 3,
		piles: [
			[],
			[],
			[]
		],
		discards: [
			[],
			[],
			[]
		],
		flipped: [
			H[0],
			H[0],
			H[0]
		],
		missions: [
			82,
			84,
			86
		],
		missionClaims: {},
		badgeClaims: [
			null,
			null,
			null,
			null
		],
		sheets: {},
		picks: {},
		phase: "pick"
	};
	r.missions = [
		"A",
		"B",
		"C"
	].map((t, r) => nt[t][e(n, r, 2)]);
	let i = B(r, [...H]);
	r.piles = [
		i.slice(0, 21),
		i.slice(21, 42),
		i.slice(42)
	];
	for (let e of t) r.sheets[e] = Ze(), r.missionClaims[e] = [
		null,
		null,
		null
	];
	return ut(r), {
		state: r,
		fx: []
	};
}
function ft(e) {
	return e.players.every((t) => {
		let n = e.picks[t];
		return (n.combo !== null || n.error) && n.queue.length === 0;
	});
}
function pt(e, t, n) {
	let r = e.sheets[t], i = W[n];
	if (!(r.circled[n] >= i.slots) && (r.circled[n] += 1, i.badgeAt !== null && r.circled[n] === i.badgeAt + 1 && r.badge[n] === null)) {
		let i = e.badgeClaims[n];
		i ? i.turn === e.turn ? (i.rids.push(t), r.badge[n] = "circle") : r.badge[n] = "cross" : (e.badgeClaims[n] = {
			turn: e.turn,
			rids: [t]
		}, r.badge[n] = "circle");
	}
}
function mt(e, t, n) {
	let r = e.sheets[t], i = e.picks[t];
	if (n < 6) {
		let e = W[n];
		!r.upgraded[n] && r.bolts[n] >= e.bolts && r.robots[n] >= e.robots && (r.upgraded[n] = !0);
		return;
	}
	let a = n - 6, o = G[a];
	if (!(r.subUsed[a] || r.subBolts[a] < o.bolts || r.subRobots[a] < o.robots)) {
		if (r.subUsed[a] = !0, o.give === "robots") {
			let e = W.reduce((e, t, n) => e + Math.max(0, t.robots - r.robots[n]), 0) + G.reduce((e, t, n) => e + Math.max(0, t.robots - r.subRobots[n]), 0);
			for (let t = 0; t < Math.min(3, e); t += 1) i.queue.unshift({
				k: "cross",
				sym: "robot"
			});
		} else pt(e, t, o.give), pt(e, t, o.give);
	}
}
function ht(e, t) {
	let n = e.picks[t];
	if (n.extracted || n.combo === null || n.queue.length > 0) return;
	n.extracted = !0;
	let r = e.sheets[t];
	for (let n = 0; n < 12; n += 1) if (!r.pumps[n] && r.cells[n] !== null && r.cells[12 + n] !== null && r.cells[24 + n] !== null) {
		for (let i = 0; i < 3; i += 1) {
			let a = i * 12 + n, o = Je[a];
			o && r.minerals[a] === 1 && (r.minerals[a] = 2, pt(e, t, Xe[o]));
		}
		for (let i = 0; i < 2; i += 1) {
			let a = i * 12 + n, o = Ye[a];
			o && r.stems[a] === 1 && (r.stems[a] = 2, pt(e, t, Xe[o]));
		}
		r.pumps[n] = !0;
	}
}
function gt(e, t, n, r) {
	let i = e.sheets[t], a = e.picks[t];
	switch (n) {
		case "water":
		case "plant":
			et(r).some((e) => Ye[e] === n && i.stems[e] === 0) && a.queue.push({
				k: "stem",
				res: n
			});
			break;
		case "energy":
			(W.some((e, t) => i.bolts[t] < e.bolts) || G.some((e, t) => i.subBolts[t] < e.bolts)) && a.queue.push({
				k: "cross",
				sym: "bolt"
			});
			break;
		case "robot":
			(W.some((e, t) => i.robots[t] < e.robots) || G.some((e, t) => i.subRobots[t] < e.robots)) && a.queue.push({
				k: "cross",
				sym: "robot"
			});
			break;
		case "planning": i.circled[5] < W[5].slots && i.cells.some((e) => e === null) && a.queue.push({ k: "planX" });
	}
}
function _t(e) {
	for (let t of ae(e.players, e.missions, e.missionClaims, e.sheets, (e, t) => rt(e, t))) e.missionClaims[t.rid][t.slot] = t.level;
	if (e.players.some((t) => {
		let n = e.sheets[t];
		return e.missionClaims[t].filter(Boolean).length >= 3 || n.errors >= 4 || n.cells.every((e) => e !== null);
	})) {
		e.phase = "done";
		return;
	}
	e.flipped.forEach((t, n) => e.discards[n].push(t)), ut(e);
}
function vt(e, t, n) {
	if (e.phase === "done") return { code: K.over };
	let r = e.picks[n.by];
	if (!r) return { code: K.badStage };
	if (t.type === "pick") {
		if (r.combo !== null || r.error) return { code: K.alreadyDone };
		let i = e.flipped[t.combo];
		if (!i) return { code: K.badCombo };
		let a = e.sheets[n.by];
		if (t.mod !== void 0 && (i.act !== "astronaut" || a.circled[4] >= W[4].slots || i.n + t.mod < 0 || i.n + t.mod > 17)) return { code: K.badMod };
		let o = i.n + (t.mod ?? 0);
		if (!Qe(a.cells, t.cell, o)) return { code: K.badCell };
		let s = structuredClone(e), c = s.sheets[n.by];
		c.cells[t.cell] = o, t.mod !== void 0 && (c.circled[4] += 1), Je[t.cell] && (c.minerals[t.cell] = 1);
		let l = s.picks[n.by];
		return l.combo = t.combo, l.cell = t.cell, gt(s, n.by, i.act, t.cell), ht(s, n.by), ft(s) && _t(s), {
			state: s,
			fx: []
		};
	}
	if (t.type === "error") {
		if (r.combo !== null || r.error) return { code: K.alreadyDone };
		let t = e.sheets[n.by];
		if (!e.flipped.every((e) => $e(t.cells, e.n).length === 0)) return { code: K.canPlace };
		let i = structuredClone(e);
		return i.sheets[n.by].errors = Math.min(4, i.sheets[n.by].errors + 1), i.picks[n.by].error = !0, ft(i) && _t(i), {
			state: i,
			fx: []
		};
	}
	let i = r.queue[0];
	if (t.type === "skip") {
		if (!i) return { code: K.badEffect };
		let t = structuredClone(e);
		return t.picks[n.by].queue.shift(), ht(t, n.by), ft(t) && _t(t), {
			state: t,
			fx: []
		};
	}
	if (t.type === "stem") {
		if (!i || i.k !== "stem") return { code: K.badEffect };
		let a = e.sheets[n.by];
		if (t.stem < 0 || t.stem >= 24 || Ye[t.stem] !== i.res || a.stems[t.stem] !== 0 || r.cell === null || !et(r.cell).includes(t.stem)) return { code: K.badTarget };
		let o = structuredClone(e);
		return o.sheets[n.by].stems[t.stem] = 1, o.picks[n.by].queue.shift(), ht(o, n.by), ft(o) && _t(o), {
			state: o,
			fx: []
		};
	}
	if (t.type === "cross") {
		if (!i || i.k !== "cross" || i.sym !== t.sym) return { code: K.badEffect };
		if (t.factory < 0 || t.factory >= 11) return { code: K.badTarget };
		let r = e.sheets[n.by];
		if (t.factory < 6) {
			let e = W[t.factory];
			if (t.sym === "bolt" ? r.bolts[t.factory] >= e.bolts : r.robots[t.factory] >= e.robots) return { code: K.badTarget };
		} else {
			let e = G[t.factory - 6], n = t.factory - 6;
			if (t.sym === "bolt" ? r.subBolts[n] >= e.bolts : r.subRobots[n] >= e.robots) return { code: K.badTarget };
		}
		let a = structuredClone(e), o = a.sheets[n.by];
		if (t.factory < 6) t.sym === "bolt" ? o.bolts[t.factory] += 1 : o.robots[t.factory] += 1;
		else {
			let e = t.factory - 6;
			t.sym === "bolt" ? o.subBolts[e] += 1 : o.subRobots[e] += 1;
		}
		return a.picks[n.by].queue.shift(), mt(a, n.by, t.factory), ht(a, n.by), ft(a) && _t(a), {
			state: a,
			fx: []
		};
	}
	if (t.type === "planX") {
		if (!i || i.k !== "planX") return { code: K.badEffect };
		let r = e.sheets[n.by];
		if (r.circled[5] >= W[5].slots) return { code: K.badEffect };
		if (t.cell < 0 || t.cell >= 36 || r.cells[t.cell] !== null) return { code: K.badCell };
		let a = structuredClone(e), o = a.sheets[n.by];
		return o.cells[t.cell] = "x", o.circled[5] += 1, a.picks[n.by].queue.shift(), ht(a, n.by), ft(a) && _t(a), {
			state: a,
			fx: []
		};
	}
	return { code: K.badStage };
}
var yt = [
	0,
	5,
	10,
	15
], bt = [
	{
		x: 258,
		hi: 3,
		lo: 6,
		top: {
			hi: 6,
			lo: 3
		},
		bot: {
			hi: 20,
			lo: 10
		}
	},
	{
		x: 439,
		hi: 6,
		lo: 4,
		top: {
			hi: 20,
			lo: 10
		},
		bot: {
			hi: 10,
			lo: 5
		}
	},
	{
		x: 623,
		hi: 7,
		lo: 3,
		top: {
			hi: 25,
			lo: 12
		},
		bot: {
			hi: 6,
			lo: 3
		}
	},
	{
		x: 780,
		hi: 4,
		lo: 5,
		top: {
			hi: 10,
			lo: 5
		},
		bot: {
			hi: 15,
			lo: 7
		}
	}
];
function xt(e, t) {
	let n = bt[e];
	return t >= 7 - n.hi && t <= 6 || t >= 7 && t <= 6 + n.lo;
}
function St(e) {
	let t = bt[e], n = [];
	for (let e = 7 - t.hi; e <= 6 + t.lo; e += 1) n.push(e);
	return n;
}
function Ct(e) {
	return 7 - bt[e].hi;
}
function wt(e) {
	return 6 + bt[e].lo;
}
var Tt = [6, 7];
function Et(e) {
	return e >= 3 && e <= 10 ? 10 - e : -1;
}
var Dt = [
	{
		parity: "odd",
		ax: 99,
		ay: 523,
		bx: 137,
		by: 355
	},
	{
		parity: "even",
		ax: 137,
		ay: 355,
		bx: 286,
		by: 177
	},
	{
		parity: "odd",
		ax: 286,
		ay: 177,
		bx: 430,
		by: 96
	},
	{
		parity: "even",
		ax: 430,
		ay: 96,
		bx: 645,
		by: 59
	},
	{
		parity: "odd",
		ax: 645,
		ay: 59,
		bx: 806,
		by: 87
	},
	{
		parity: "even",
		ax: 806,
		ay: 87,
		bx: 1002,
		by: 199
	},
	{
		parity: "odd",
		ax: 1002,
		ay: 199,
		bx: 1106,
		by: 332
	},
	{
		parity: "even",
		ax: 1106,
		ay: 332,
		bx: 1157,
		by: 517
	}
], Ot = [
	[8, 4],
	[10, 6],
	[12, 8],
	[15, 9]
], kt = [18, 10], At = [
	[
		2,
		5,
		9
	],
	[
		2,
		6,
		10
	],
	[
		3,
		7,
		12
	],
	[
		3,
		8,
		15
	]
], jt = [
	4,
	10,
	18
], Mt = [
	[10, 0],
	[0, 2],
	[10, 4],
	[20, 7]
], Nt = [30, 10], Pt = [
	6,
	5,
	4,
	3
], Ft = {
	A: [88, 89],
	B: [90, 91],
	C: [92, 93]
};
function It() {
	return {
		cells: Array(52).fill(null),
		towerPlants: Array(8).fill(0),
		towerWaters: Array(8).fill(0),
		dome: Dt.map((e) => ({
			parity: e.parity,
			half: !1,
			built: !1
		})),
		astronauts: 0,
		xCount: 0,
		energyMission: 0,
		energyTower: 0,
		energyAstro: 0,
		energyDome: 0,
		bonus: Array(8).fill(null),
		errors: 0
	};
}
function Lt(e, t, n) {
	return St(t).some((n) => e[t * 13 + n] !== null) ? n > 0 && xt(t, n - 1) && e[t * 13 + n - 1] !== null || n < 12 && xt(t, n + 1) && e[t * 13 + n + 1] !== null : Tt.includes(n);
}
function Rt(e, t, n) {
	if (t < 0 || t >= 52) return !1;
	let r = Math.floor(t / 13), i = t % 13;
	if (!xt(r, i) || e[t] !== null || !Lt(e, r, i)) return !1;
	for (let t of St(r)) {
		let a = e[r * 13 + t];
		if (typeof a == "number" && (t < i && a <= n || t > i && a >= n)) return !1;
	}
	return !0;
}
function zt(e, t) {
	let n = [];
	for (let r = 0; r < 52; r += 1) Rt(e, r, t) && n.push(r);
	return n;
}
function Bt(e, t) {
	if (t < 0 || t >= 52) return !1;
	let n = Math.floor(t / 13), r = t % 13;
	return !xt(n, r) || e[t] !== null ? !1 : Lt(e, n, r);
}
function Vt(e, t, n) {
	let r = e[t];
	return !r || r.built || n % 2 == 0 != (r.parity === "even") ? !1 : t === 0 || t === e.length - 1 || e[t - 1].built || e[t + 1].built;
}
function Ht(e, t) {
	return e.some((n, r) => Vt(e, r, t));
}
function Ut(e, t) {
	let n = e[t];
	return !!n && !n.built && !n.half;
}
function Wt(e) {
	return e.some((t, n) => Ut(e, n));
}
function Gt(e) {
	return e.filter((e) => !e.built).length;
}
function Kt(e, t) {
	switch (e) {
		case 88: return bt.some((e, n) => St(n).every((e) => t.cells[n * 13 + e] !== null));
		case 89: {
			let e = 0;
			for (let n = 0; n < 4; n += 1) typeof t.cells[n * 13 + Ct(n)] == "number" && (e += 1);
			return e >= 2;
		}
		case 90: {
			let e = 0;
			for (let n = 0; n < 8; n += 1) t.towerPlants[n] + t.towerWaters[n] >= 2 && (e += 1);
			return e >= 3;
		}
		case 91: {
			let e = 0;
			for (let n = 0; n < 8; n += 1) t.towerPlants[n] + t.towerWaters[n] >= 3 && (e += 1);
			return e >= 2;
		}
		case 92: return t.dome.every((e) => e.built);
		case 93: return t.xCount >= 4;
	}
}
function qt(e) {
	return yt[Math.min(e.errors, 3)];
}
function Jt(e, t) {
	return e.energyMission < 4 ? Ot[e.energyMission][t] : kt[t];
}
function Yt(e, t) {
	return e.energyTower < 4 ? At[e.energyTower][t] : jt[t];
}
function Xt(e, t) {
	return e.energyAstro < 4 ? Mt[e.energyAstro][t] : Nt[t];
}
function Zt(e) {
	return e.energyDome < 4 ? Pt[e.energyDome] : 2;
}
function Qt(e, t, n) {
	return t.reduce((e, t) => t ? e + Jt(n, t === "high" ? 0 : 1) : e, 0);
}
function $t(e) {
	let t = 0;
	for (let n = 1; n <= 3; n += 1) {
		let r = 0;
		for (let t = 0; t < 8; t += 1) e.towerPlants[t] + e.towerWaters[t] === n && (r += 1);
		t += r * Yt(e, n - 1);
	}
	return t;
}
function en(e) {
	let t = 0;
	for (let n = 0; n < 4; n += 1) {
		let r = bt[n];
		e.bonus[n * 2] === "circle" ? t += r.top.hi : e.bonus[n * 2] === "cross" && (t += r.top.lo), e.bonus[n * 2 + 1] === "circle" ? t += r.bot.hi : e.bonus[n * 2 + 1] === "cross" && (t += r.bot.lo);
	}
	return t;
}
function tn(e, t, n) {
	let r = t[n];
	if (r.astronauts === 0) return 0;
	let i = Math.max(...e.map((e) => t[e].astronauts));
	return Xt(r, r.astronauts >= i ? 0 : 1);
}
function nn(e) {
	return Gt(e.dome) * Zt(e);
}
function rn(e) {
	return $t(e) + en(e) - nn(e) - qt(e);
}
function an(e, t, n, r, i) {
	return rn(t[i]) + Qt(n, r[i], t[i]) + tn(e, t, i);
}
var q = {
	over: "games.moon.errOver",
	badStage: "games.moon.errBadStage",
	alreadyDone: "games.moon.errAlreadyDone",
	badCell: "games.moon.errBadCell",
	badCombo: "games.moon.errBadCombo",
	canPlace: "games.moon.errCanPlace",
	badEffect: "games.moon.errBadEffect",
	badTarget: "games.moon.errBadTarget",
	badMod: "games.moon.errBadMod"
};
function on() {
	return {
		combo: null,
		cell: null,
		error: !1,
		queue: []
	};
}
function sn(e) {
	e.turn += 1, e.flipped = [
		V(e, 0),
		V(e, 1),
		V(e, 2)
	], e.picks = {};
	for (let t of e.players) e.picks[t] = on();
}
function cn(t, n) {
	let r = {
		adv: 5,
		players: t,
		turn: 0,
		seed: n,
		rngCursor: 3,
		piles: [
			[],
			[],
			[]
		],
		discards: [
			[],
			[],
			[]
		],
		flipped: [
			H[0],
			H[0],
			H[0]
		],
		missions: [
			88,
			90,
			92
		],
		missionClaims: {},
		bonusClaims: Array(8).fill(null),
		sheets: {},
		picks: {},
		phase: "pick"
	};
	r.missions = [
		"A",
		"B",
		"C"
	].map((t, r) => Ft[t][e(n, r, 2)]);
	let i = B(r, [...H]);
	r.piles = [
		i.slice(0, 21),
		i.slice(21, 42),
		i.slice(42)
	];
	for (let e of t) r.sheets[e] = It(), r.missionClaims[e] = [
		null,
		null,
		null
	];
	return sn(r), {
		state: r,
		fx: []
	};
}
function ln(e) {
	return e.players.every((t) => {
		let n = e.picks[t];
		return (n.combo !== null || n.error) && n.queue.length === 0;
	});
}
function un(e, t, n) {
	let r = e.sheets[t];
	if (r.bonus[n] !== null) return;
	let i = e.bonusClaims[n];
	i ? i.turn === e.turn ? (i.rids.includes(t) || i.rids.push(t), r.bonus[n] = "circle") : r.bonus[n] = "cross" : (e.bonusClaims[n] = {
		turn: e.turn,
		rids: [t]
	}, r.bonus[n] = "circle");
}
function dn(e, t, n, r, i) {
	let a = e.sheets[t], o = e.picks[t], s = r % 13;
	switch (n) {
		case "water":
		case "plant": {
			let e = Et(s);
			if (e < 0) break;
			(n === "water" ? a.towerWaters[e] < 1 : a.towerPlants[e] < 2) && o.queue.push({
				k: "tower",
				res: n
			});
			break;
		}
		case "robot":
			Ht(a.dome, i) && o.queue.push({ k: "dome" });
			break;
		case "planning":
			if (!a.cells.some((e, t) => Bt(a.cells, t))) break;
			o.queue.push({ k: "planX" }), Wt(a.dome) && o.queue.push({ k: "cut" });
			break;
		case "energy": (a.energyMission < 4 || a.energyTower < 4 || a.energyAstro < 4 || a.energyDome < 4) && o.queue.push({ k: "energy" });
	}
}
function fn(e) {
	for (let t of ae(e.players, e.missions, e.missionClaims, e.sheets, (e, t) => Kt(e, t))) e.missionClaims[t.rid][t.slot] = t.level;
	if (e.players.some((t) => {
		let n = e.sheets[t];
		return e.missionClaims[t].filter(Boolean).length >= 3 || n.errors >= 4 || n.cells.every((e, t) => e !== null || !xt(Math.floor(t / 13), t % 13));
	})) {
		e.phase = "done";
		return;
	}
	e.flipped.forEach((t, n) => e.discards[n].push(t)), sn(e);
}
function pn(e, t, n) {
	if (e.phase === "done") return { code: q.over };
	let r = e.picks[n.by];
	if (!r) return { code: q.badStage };
	if (t.type === "pick") {
		if (r.combo !== null || r.error) return { code: q.alreadyDone };
		let i = e.flipped[t.combo];
		if (!i) return { code: q.badCombo };
		let a = e.sheets[n.by];
		if (t.mod !== void 0 && (i.act !== "astronaut" || a.astronauts >= 6 || i.n + t.mod < 0 || i.n + t.mod > 17)) return { code: q.badMod };
		let o = i.n + (t.mod ?? 0);
		if (!Rt(a.cells, t.cell, o)) return { code: q.badCell };
		let s = structuredClone(e), c = s.sheets[n.by];
		c.cells[t.cell] = o, t.mod !== void 0 && (c.astronauts += 1);
		let l = s.picks[n.by];
		l.combo = t.combo, l.cell = t.cell;
		let u = Math.floor(t.cell / 13), d = t.cell % 13;
		return d === Ct(u) && un(s, n.by, u * 2), d === wt(u) && un(s, n.by, u * 2 + 1), dn(s, n.by, i.act, t.cell, o), ln(s) && fn(s), {
			state: s,
			fx: []
		};
	}
	if (t.type === "error") {
		if (r.combo !== null || r.error) return { code: q.alreadyDone };
		let t = e.sheets[n.by];
		if (!e.flipped.every((e) => zt(t.cells, e.n).length === 0)) return { code: q.canPlace };
		let i = structuredClone(e);
		return i.sheets[n.by].errors = Math.min(4, i.sheets[n.by].errors + 1), i.picks[n.by].error = !0, ln(i) && fn(i), {
			state: i,
			fx: []
		};
	}
	let i = r.queue[0];
	if (t.type === "skip") {
		if (!i || i.k === "cut") return { code: q.badEffect };
		let t = structuredClone(e);
		return t.picks[n.by].queue.shift(), i.k === "planX" && t.picks[n.by].queue[0]?.k === "cut" && t.picks[n.by].queue.shift(), ln(t) && fn(t), {
			state: t,
			fx: []
		};
	}
	if (t.type === "towerSym") {
		if (!i || i.k !== "tower") return { code: q.badEffect };
		let a = e.sheets[n.by];
		if (t.level < 0 || t.level >= 8 || r.cell === null || Et(r.cell % 13) !== t.level || (i.res === "water" ? a.towerWaters[t.level] >= 1 : a.towerPlants[t.level] >= 2)) return { code: q.badTarget };
		let o = structuredClone(e);
		return i.res === "water" ? o.sheets[n.by].towerWaters[t.level] += 1 : o.sheets[n.by].towerPlants[t.level] += 1, o.picks[n.by].queue.shift(), ln(o) && fn(o), {
			state: o,
			fx: []
		};
	}
	if (t.type === "domeBuild") {
		if (!i || i.k !== "dome") return { code: q.badEffect };
		let a = e.sheets[n.by];
		if (r.cell === null) return { code: q.badStage };
		let o = a.cells[r.cell];
		if (typeof o != "number") return { code: q.badStage };
		if (!Vt(a.dome, t.index, o)) return { code: q.badTarget };
		let s = structuredClone(e);
		return s.sheets[n.by].dome[t.index].built = !0, s.picks[n.by].queue.shift(), ln(s) && fn(s), {
			state: s,
			fx: []
		};
	}
	if (t.type === "planX") {
		if (!i || i.k !== "planX") return { code: q.badEffect };
		let r = e.sheets[n.by];
		if (!Bt(r.cells, t.cell)) return { code: q.badCell };
		let a = structuredClone(e), o = a.sheets[n.by];
		return o.cells[t.cell] = "x", o.xCount += 1, a.picks[n.by].queue.shift(), ln(a) && fn(a), {
			state: a,
			fx: []
		};
	}
	if (t.type === "domeCut") {
		if (!i || i.k !== "cut") return { code: q.badEffect };
		let r = e.sheets[n.by];
		if (!Ut(r.dome, t.index)) return { code: q.badTarget };
		let a = structuredClone(e), o = a.sheets[n.by].dome[t.index];
		return a.sheets[n.by].dome.splice(t.index, 1, {
			parity: o.parity,
			half: !0,
			built: !1
		}, {
			parity: o.parity,
			half: !0,
			built: !1
		}), a.picks[n.by].queue.shift(), ln(a) && fn(a), {
			state: a,
			fx: []
		};
	}
	if (t.type === "energyUp") {
		if (!i || i.k !== "energy") return { code: q.badEffect };
		let r = e.sheets[n.by];
		if ((t.field === 0 ? r.energyMission : t.field === 1 ? r.energyTower : t.field === 2 ? r.energyAstro : r.energyDome) >= 4) return { code: q.badTarget };
		let a = structuredClone(e), o = a.sheets[n.by];
		return t.field === 0 ? o.energyMission += 1 : t.field === 1 ? o.energyTower += 1 : t.field === 2 ? o.energyAstro += 1 : o.energyDome += 1, a.picks[n.by].queue.shift(), ln(a) && fn(a), {
			state: a,
			fx: []
		};
	}
	return { code: q.badStage };
}
var mn = [
	0,
	5,
	10,
	15
], hn = [
	{
		cell: 1,
		value: 4
	},
	{
		cell: 4,
		value: 4
	},
	{
		cell: 6,
		value: 5
	},
	{
		cell: 10,
		value: 6
	},
	{
		cell: 13,
		value: 7
	},
	{
		cell: 17,
		value: 8
	},
	{
		cell: 18,
		value: 8
	},
	{
		cell: 22,
		value: 7
	},
	{
		cell: 25,
		value: 6
	},
	{
		cell: 29,
		value: 5
	},
	{
		cell: 31,
		value: 4
	},
	{
		cell: 34,
		value: 4
	}
], J = [
	{
		robots: 3,
		plants: 3,
		hi: 9,
		lo: 7,
		link: 15
	},
	{
		robots: 3,
		plants: 4,
		hi: 8,
		lo: 6,
		link: 20
	},
	{
		robots: 4,
		plants: 4,
		hi: 10,
		lo: 7,
		link: 30
	},
	{
		robots: 2,
		plants: 4,
		hi: 6,
		lo: 5,
		link: 5
	}
], gn = [
	20,
	10,
	5
];
function _n() {
	return {
		cells: Array(36).fill(null),
		tanks: hn.map(() => !1),
		splits: Array(35).fill(!1),
		energyPairs: 0,
		energyPending: !0,
		stations: J.map(() => ({
			robots: 0,
			plants: 0,
			mult: null,
			fullTurn: -1
		})),
		astronauts: 0,
		plannings: 0,
		wilds: 0,
		wildsUsed: 0,
		errors: 0
	};
}
function vn(e, t) {
	let n = t, r = t;
	for (; n > 0 && !e[n - 1];) --n;
	for (; r < 35 && !e[r];) r += 1;
	return [n, r];
}
function yn(e) {
	let t = [], n = 0;
	for (let r = 0; r < 35; r += 1) e[r] && (t.push([n, r]), n = r + 1);
	return t.push([n, 35]), t;
}
function bn(e, t, n, r) {
	if (n < 0 || n >= 36 || e[n] !== null) return !1;
	let [i, a] = vn(t, n);
	for (let t = i; t < n; t += 1) {
		let n = e[t];
		if (typeof n == "number" && n >= r) return !1;
	}
	for (let t = n + 1; t <= a; t += 1) {
		let n = e[t];
		if (typeof n == "number" && n <= r) return !1;
	}
	return !0;
}
function xn(e, t, n) {
	let r = [];
	for (let i = 0; i < 36; i += 1) bn(e, t, i, n) && r.push(i);
	return r;
}
function Sn(e, t) {
	let [n, r] = vn(e, t), i = [];
	return J.forEach((e, t) => {
		e.link >= n && e.link <= r && i.push(t);
	}), i;
}
function Cn(e) {
	return yn(e.splits).filter(([t, n]) => {
		for (let r = t; r <= n; r += 1) if (e.cells[r] === null) return !1;
		return !0;
	});
}
function wn(e) {
	return Cn(e).reduce((e, [t, n]) => Math.max(e, n - t + 1), 0);
}
function Tn(e) {
	return e.energyPairs >= 6 && !e.energyPending ? null : e.energyPending ? (e.energyPending = !1, e.energyPairs += 1, "split") : (e.energyPending = !0, "single");
}
var En = {
	70: {
		id: 70,
		kind: "A",
		hi: 9,
		lo: 5
	},
	71: {
		id: 71,
		kind: "A",
		hi: 10,
		lo: 5
	},
	72: {
		id: 72,
		kind: "B",
		hi: 11,
		lo: 6
	},
	73: {
		id: 73,
		kind: "B",
		hi: 12,
		lo: 6
	},
	74: {
		id: 74,
		kind: "C",
		hi: 9,
		lo: 5
	},
	75: {
		id: 75,
		kind: "C",
		hi: 11,
		lo: 6
	}
}, Dn = {
	A: [70, 71],
	B: [72, 73],
	C: [74, 75]
};
function On(e, t) {
	switch (e) {
		case 70: return t.stations.filter((e) => e.mult !== null).length >= 3;
		case 71: return t.stations.filter((e, t) => e.plants >= J[t].plants).length >= 2;
		case 72: return Cn(t).filter(([e, t]) => t - e + 1 === 6).length >= 2;
		case 73: {
			let e = Cn(t).map(([e, t]) => t - e + 1);
			return e.includes(6) && e.includes(4) && e.includes(2);
		}
		case 74: return t.tanks.filter(Boolean).length >= 6;
		case 75:
			for (let e = 0; e + 4 <= t.tanks.length; e += 1) if (t.tanks[e] && t.tanks[e + 1] && t.tanks[e + 2] && t.tanks[e + 3]) return !0;
			return !1;
	}
}
function kn(e) {
	return e.stations.reduce((e, t, n) => t.robots < J[n].robots || t.mult === null ? e : e + t.plants * (t.mult === "high" ? J[n].hi : J[n].lo), 0);
}
function An(e) {
	return e.tanks.reduce((e, t, n) => e + (t ? hn[n].value : 0), 0);
}
function jn(e) {
	return mn[Math.min(e.errors, 3)];
}
function Mn(e) {
	return kn(e) + An(e) + wn(e) - jn(e);
}
var Y = {
	over: "games.moon.errOver",
	badStage: "games.moon.errBadStage",
	alreadyDone: "games.moon.errAlreadyDone",
	badCell: "games.moon.errBadCell",
	badCombo: "games.moon.errBadCombo",
	canPlace: "games.moon.errCanPlace",
	badEffect: "games.moon.errBadEffect",
	badTarget: "games.moon.errBadTarget",
	badMod: "games.moon.errBadMod",
	noWild: "games.moon.errNoWild"
};
function Nn() {
	return {
		combo: null,
		cell: null,
		error: !1,
		queue: []
	};
}
function Pn(e) {
	e.turn += 1, e.flipped = [
		V(e, 0),
		V(e, 1),
		V(e, 2)
	], e.picks = {};
	for (let t of e.players) e.picks[t] = Nn();
}
function Fn(t, n) {
	let r = {
		adv: 2,
		players: t,
		turn: 0,
		seed: n,
		rngCursor: 3,
		piles: [
			[],
			[],
			[]
		],
		discards: [
			[],
			[],
			[]
		],
		flipped: [
			H[0],
			H[0],
			H[0]
		],
		missions: [
			70,
			72,
			74
		],
		missionClaims: {},
		sheets: {},
		picks: {},
		phase: "pick"
	};
	r.missions = [
		"A",
		"B",
		"C"
	].map((t, r) => Dn[t][e(n, r, 2)]);
	let i = B(r, [...H]);
	r.piles = [
		i.slice(0, 21),
		i.slice(21, 42),
		i.slice(42)
	];
	for (let e of t) r.sheets[e] = _n(), r.missionClaims[e] = [
		null,
		null,
		null
	];
	return Pn(r), {
		state: r,
		fx: []
	};
}
function In(e) {
	return e.players.every((t) => {
		let n = e.picks[t];
		return (n.combo !== null || n.error) && n.queue.length === 0;
	});
}
function Ln(e, t, n, r) {
	let i = e.sheets[t], a = e.picks[t];
	switch (n) {
		case "water": {
			let e = hn.findIndex((e) => e.cell === r);
			e >= 0 && !i.tanks[e] && (i.tanks[e] = !0);
			break;
		}
		case "energy":
			Tn(i) === "split" && a.queue.push("split");
			break;
		case "robot":
			i.stations.some((e, t) => e.robots < J[t].robots) && a.queue.push("robot");
			break;
		case "plant":
			Sn(i.splits, r).some((e) => i.stations[e].plants < J[e].plants) && a.queue.push("plant");
			break;
		case "planning": i.plannings < 6 && i.cells.some((e) => e === null) && a.queue.push("planX");
	}
}
function Rn(e) {
	for (let t of ae(e.players, e.missions, e.missionClaims, e.sheets, (e, t) => On(e, t))) e.missionClaims[t.rid][t.slot] = t.level;
	if (e.players.some((t) => {
		let n = e.sheets[t];
		return e.missionClaims[t].filter(Boolean).length >= 3 || n.errors >= 4 || n.cells.every((e) => e !== null);
	})) {
		e.phase = "done";
		return;
	}
	e.flipped.forEach((t, n) => e.discards[n].push(t)), Pn(e);
}
function zn(e, t, n) {
	if (e.phase === "done") return { code: Y.over };
	let r = e.picks[n.by];
	if (!r) return { code: Y.badStage };
	if (t.type === "pick") {
		if (r.combo !== null || r.error) return { code: Y.alreadyDone };
		let i = e.flipped[t.combo];
		if (!i) return { code: Y.badCombo };
		let a = t.wild ?? i.act, o = e.sheets[n.by];
		if (t.wild !== void 0 && o.wildsUsed >= o.wilds) return { code: Y.noWild };
		if (t.mod !== void 0 && (a !== "astronaut" || o.astronauts >= 6 || i.n + t.mod < 0 || i.n + t.mod > 17)) return { code: Y.badMod };
		let s = i.n + (t.mod ?? 0);
		if (!bn(o.cells, o.splits, t.cell, s)) return { code: Y.badCell };
		let c = structuredClone(e), l = c.sheets[n.by];
		l.cells[t.cell] = s, t.wild !== void 0 && (l.wildsUsed += 1), t.mod !== void 0 && (l.astronauts += 1, l.astronauts % 2 == 0 && (l.wilds += 1));
		let u = c.picks[n.by];
		return u.combo = t.combo, u.cell = t.cell, Ln(c, n.by, a, t.cell), In(c) && Rn(c), {
			state: c,
			fx: []
		};
	}
	if (t.type === "error") {
		if (r.combo !== null || r.error) return { code: Y.alreadyDone };
		let t = e.sheets[n.by];
		if (!e.flipped.every((e) => xn(t.cells, t.splits, e.n).length === 0)) return { code: Y.canPlace };
		let i = structuredClone(e), a = i.sheets[n.by];
		return a.errors = Math.min(4, a.errors + 1), i.picks[n.by].error = !0, a.errors <= 2 && Tn(a) === "split" && i.picks[n.by].queue.push("split"), In(i) && Rn(i), {
			state: i,
			fx: []
		};
	}
	let i = r.queue[0];
	if (t.type === "skip") {
		if (!i || i === "split") return { code: Y.badEffect };
		let t = structuredClone(e);
		return t.picks[n.by].queue.shift(), In(t) && Rn(t), {
			state: t,
			fx: []
		};
	}
	if (t.type === "robot") {
		if (i !== "robot") return { code: Y.badEffect };
		let r = e.sheets[n.by].stations[t.station];
		if (!r || r.robots >= J[t.station].robots) return { code: Y.badTarget };
		let a = structuredClone(e), o = a.sheets[n.by].stations[t.station];
		return o.robots += 1, o.robots === J[t.station].robots && (o.fullTurn = a.turn, o.mult = a.players.some((e) => {
			if (e === n.by) return !1;
			let r = a.sheets[e].stations[t.station].fullTurn;
			return r !== -1 && r < a.turn;
		}) ? "low" : "high"), a.picks[n.by].queue.shift(), In(a) && Rn(a), {
			state: a,
			fx: []
		};
	}
	if (t.type === "plant") {
		if (i !== "plant") return { code: Y.badEffect };
		if (r.cell === null) return { code: Y.badStage };
		if (!Sn(e.sheets[n.by].splits, r.cell).includes(t.station) || e.sheets[n.by].stations[t.station].plants >= J[t.station].plants) return { code: Y.badTarget };
		let a = structuredClone(e);
		return a.sheets[n.by].stations[t.station].plants += 1, a.picks[n.by].queue.shift(), In(a) && Rn(a), {
			state: a,
			fx: []
		};
	}
	if (t.type === "planX") {
		if (i !== "planX") return { code: Y.badEffect };
		let r = e.sheets[n.by];
		if (r.plannings >= 6) return { code: Y.badEffect };
		if (t.cell < 0 || t.cell >= 36 || r.cells[t.cell] !== null) return { code: Y.badCell };
		let a = structuredClone(e), o = a.sheets[n.by];
		return o.cells[t.cell] = "x", o.plannings += 1, o.plannings % 2 == 0 && (o.wilds += 1), a.picks[n.by].queue.shift(), In(a) && Rn(a), {
			state: a,
			fx: []
		};
	}
	if (t.type === "split") {
		if (i !== "split") return { code: Y.badEffect };
		if (t.gap < 0 || t.gap >= 35 || e.sheets[n.by].splits[t.gap]) return { code: Y.badTarget };
		let r = structuredClone(e);
		return r.sheets[n.by].splits[t.gap] = !0, r.picks[n.by].queue.shift(), In(r) && Rn(r), {
			state: r,
			fx: []
		};
	}
	return { code: Y.badStage };
}
function Bn(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let r of e) {
		let e = Cn(t[r]).length;
		n.has(e) || n.set(e, []), n.get(e).push(r);
	}
	let r = {};
	for (let t of e) r[t] = 0;
	let i = 0;
	for (let e of [...n.keys()].filter((e) => e > 0).sort((e, t) => t - e)) {
		let t = n.get(e), a = gn[i] ?? 0;
		for (let e of t) r[e] = a;
		i += t.length;
	}
	return r;
}
function Vn(e, t) {
	return t.reduce((t, n, r) => {
		if (!n) return t;
		let i = En[e[r]];
		return t + (n === "high" ? i.hi : i.lo);
	}, 0);
}
function Hn(e, t, n, r, i) {
	return Mn(t[i]) + Vn(n, r[i]) + Bn(e, t)[i];
}
var Un = [
	[0, 1],
	[2, 3],
	[
		4,
		5,
		6
	],
	[7, 8],
	[9, 10]
], Wn = [
	0,
	0,
	1,
	1,
	2,
	2,
	2,
	3,
	3,
	4,
	4
], Gn = [
	[0, 7],
	[0, 4],
	[1, 4],
	[0, 1],
	[1, 5],
	[1, 2],
	[2, 3],
	[2, 6],
	[4, 5],
	[4, 8],
	[5, 8],
	[5, 6],
	[3, 10],
	[5, 9],
	[6, 10],
	[9, 10],
	[7, 8],
	[6, 9],
	[3, 6],
	[4, 7],
	[2, 5],
	[8, 9]
], Kn = (() => {
	let e = Array.from({ length: 11 }, () => []);
	return Gn.forEach(([t, n], r) => {
		e[t].push({
			walk: r,
			to: n
		}), e[n].push({
			walk: r,
			to: t
		});
	}), e;
})(), qn = [
	1,
	5,
	9,
	2,
	8
], Jn = [
	0,
	3,
	7,
	10
], Yn = {
	0: 0,
	6: 1,
	12: 2,
	19: 3,
	22: 4,
	33: 5,
	36: 6,
	42: 7,
	46: 8,
	52: 9
}, Xn = [
	1,
	1,
	2,
	1,
	2,
	2,
	2,
	1,
	2,
	1,
	1
], Zn = [
	0,
	1,
	2,
	4,
	5,
	7,
	9,
	11,
	12,
	14,
	15
], Qn = {
	count: 16,
	ends: [
		1,
		3,
		6,
		9,
		12,
		15
	],
	scores: [
		5,
		10,
		20,
		35,
		55,
		80
	],
	virusAt: 4,
	virus: 3,
	props: {
		7: 0,
		10: 1
	}
}, $n = {
	count: 10,
	ends: [
		1,
		3,
		5,
		7,
		9
	],
	scores: [
		10,
		20,
		35,
		55,
		80
	],
	virusAt: 2,
	virus: 4,
	props: {
		4: 2,
		6: 3
	}
}, er = [
	{
		tanks: [0, 1],
		plants: [0, 1]
	},
	{
		tanks: [2, 3],
		plants: [
			2,
			3,
			4
		]
	},
	{
		tanks: [4, 5],
		plants: [
			5,
			6,
			7,
			8,
			9,
			10
		]
	},
	{
		tanks: [6, 7],
		plants: [
			11,
			12,
			13
		]
	},
	{
		tanks: [8, 9],
		plants: [14, 15]
	}
], tr = {
	A: [94, 95],
	B: [96, 97],
	C: [98, 99]
}, nr = {
	94: [8, 3],
	95: [8, 3],
	96: [11, 4],
	97: [12, 5],
	98: [10, 4],
	99: [10, 4]
}, rr = [
	0,
	1,
	2
];
function ir() {
	return {
		cells: Array(55).fill(null),
		energy: Array(22).fill(!1),
		walkways: Array(22).fill(!1),
		plants: Array(16).fill(!1),
		tanks: Array(10).fill(!1),
		plantTrack: 0,
		waterTrack: 0,
		viruses: Array(11).fill(!1),
		virusCrossed: Array(11).fill(!1),
		greyQuarter: -1,
		propSlots: [
			,
			,
			,
			,
		].fill(!1),
		evac: Array(11).fill(null),
		astronauts: 0,
		plannings: 0,
		wilds: 0,
		wildsUsed: 0,
		errors: 0
	};
}
function ar(e) {
	return Math.floor(e / 5);
}
function or(e, t, n) {
	if (t < 0 || t >= 55 || e[t] !== null) return !1;
	let r = Wn[ar(t)];
	for (let i of Un[r]) for (let r = 0; r < 5; r += 1) {
		let a = i * 5 + r, o = e[a];
		if (typeof o == "number" && (a < t && o >= n || a > t && o <= n)) return !1;
	}
	return !0;
}
function sr(e, t) {
	let n = [];
	for (let r = 0; r < 55; r += 1) or(e, r, t) && n.push(r);
	return n;
}
function cr(e, t) {
	let n = 0;
	return e.ends.forEach((r, i) => {
		t > r && (n = e.scores[i]);
	}), n;
}
function lr(e, t) {
	let n = 0;
	for (let r = 0; r < 5; r += 1) typeof e.cells[t * 5 + r] == "number" && (n += 1);
	return n;
}
function ur(e, t) {
	return +!!e.energy[t * 2] + +!!e.energy[t * 2 + 1];
}
function dr(e, t) {
	return (1 + ur(e, t)) * lr(e, t);
}
function fr(e, t) {
	for (let n = 0; n < 5; n += 1) if (e.cells[t * 5 + n] === null) return !1;
	return !0;
}
function pr(e) {
	for (let t = 0; t < 11; t += 1) e.evac[t] === null && fr(e, t) && (e.evac[t] = dr(e, t));
}
function mr(e, t) {
	return Kn[t].every(({ walk: t }) => e.walkways[t]);
}
function hr(e, t) {
	for (let n of Gn[t]) mr(e, n) && (e.virusCrossed[n] = !0);
}
function gr(e, t) {
	if (e.evac[t] === null) {
		let n = [];
		for (let r = 0; r < 5; r += 1) e.cells[t * 5 + r] === null && n.push(t * 5 + r);
		return n.length > 0 ? [n] : [];
	}
	let n = [];
	for (let { walk: r, to: i } of Kn[t]) {
		if (e.walkways[r]) continue;
		let t = [];
		for (let n = 0; n < 5; n += 1) e.cells[i * 5 + n] === null && t.push(i * 5 + n);
		t.length > 0 && n.push(t);
	}
	return n;
}
function _r(e, t) {
	switch (e) {
		case 94: return t.evac.filter((e) => e !== null).length >= 2;
		case 95: return Un.some((e) => e.every((e) => t.evac[e] !== null));
		case 96: {
			let e = 0;
			for (let n = 0; n < 11; n += 1) mr(t, n) && (e += 1);
			return e >= 3;
		}
		case 97: return mr(t, 2) && mr(t, 8);
		case 98: {
			let e = 0;
			for (let n of Un) n.every((e) => t.energy[e * 2] && t.energy[e * 2 + 1]) && (e += 1);
			return e >= 2;
		}
		case 99: {
			let e = 0;
			for (let n of er) n.tanks.every((e) => t.tanks[e]) && n.plants.every((e) => t.plants[e]) && (e += 1);
			return e >= 2;
		}
	}
}
function vr(e, t) {
	return t.reduce((t, n, r) => {
		if (!n) return t;
		let [i, a] = nr[e[r]];
		return t + (n === "high" ? i : a);
	}, 0);
}
function yr(e) {
	return e.cells.filter((e) => e === "v").length;
}
function br(e) {
	return e.evac.reduce((e, t) => e + (t ?? 0), 0);
}
function xr(e) {
	return e.errors * 5;
}
function Sr(e) {
	return cr(Qn, e.plantTrack) + cr($n, e.waterTrack) + br(e) - yr(e) - xr(e);
}
var X = {
	over: "games.moon.errOver",
	badStage: "games.moon.errBadStage",
	alreadyDone: "games.moon.errAlreadyDone",
	badCell: "games.moon.errBadCell",
	badCombo: "games.moon.errBadCombo",
	canPlace: "games.moon.errCanPlace",
	badEffect: "games.moon.errBadEffect",
	badTarget: "games.moon.errBadTarget",
	badMod: "games.moon.errBadMod",
	noWild: "games.moon.errNoWild"
};
function Cr() {
	return {
		combo: null,
		cell: null,
		error: !1,
		queue: []
	};
}
function wr(e) {
	e.turn += 1, e.flipped = [
		V(e, 0),
		V(e, 1),
		V(e, 2)
	], e.picks = {};
	for (let t of e.players) e.picks[t] = Cr();
}
function Tr(t, n) {
	let r = {
		adv: 6,
		stage: "grey",
		players: t,
		turn: 0,
		seed: n,
		rngCursor: 3,
		piles: [
			[],
			[],
			[]
		],
		discards: [
			[],
			[],
			[]
		],
		flipped: [
			H[0],
			H[0],
			H[0]
		],
		missions: [
			94,
			96,
			98
		],
		missionClaims: {},
		activatedViruses: [
			,
			,
			,
			,
			,
		].fill(!1),
		turnViruses: [],
		turnProps: [],
		sheets: {},
		picks: {},
		phase: "pick"
	};
	r.missions = [
		"A",
		"B",
		"C"
	].map((t, r) => tr[t][e(n, r, 2)]);
	let i = B(r, [...H]);
	r.piles = [
		i.slice(0, 21),
		i.slice(21, 42),
		i.slice(42)
	];
	for (let e of t) r.sheets[e] = ir(), r.missionClaims[e] = [
		null,
		null,
		null
	], r.picks[e] = Cr();
	return {
		state: r,
		fx: []
	};
}
function Er(e, t) {
	e.activatedViruses[t] || (e.activatedViruses[t] = !0, e.turnViruses.push(t));
}
function Dr(e, t, n, r) {
	let i = e.sheets[t], a = i[r];
	if (a >= n.count) return;
	i[r] = a + 1;
	let o = e.picks[t];
	n.ends.includes(a) && (r === "plantTrack" ? i.walkways.some((e) => !e) && o.queue.push({ k: "robot" }) : Or(i, null).length > 0 && o.queue.push({
		k: "energy",
		q: null
	})), a === n.virusAt && Er(e, n.virus);
	let s = n.props[a];
	s !== void 0 && !i.propSlots[s] && (i.propSlots[s] = !0, e.turnProps.includes(s) || e.turnProps.push(s));
}
function Or(e, t) {
	let n = (t) => e.evac[t] === null && (!e.energy[t * 2] || !e.energy[t * 2 + 1]);
	if (t !== null) return n(t) ? [t] : [];
	let r = [];
	for (let e = 0; e < 11; e += 1) n(e) && r.push(e);
	return r;
}
function kr(e, t, n, r) {
	let i = e.sheets[t], a = e.picks[t], o = ar(r);
	switch (n) {
		case "energy":
			Or(i, o).length > 0 && a.queue.push({
				k: "energy",
				q: o
			});
			break;
		case "robot":
			i.walkways.some((e) => !e) && a.queue.push({ k: "robot" });
			break;
		case "plant": {
			let n = Zn[o], r = Xn[o];
			for (let a = 0; a < r; a += 1) if (!i.plants[n + a]) {
				i.plants[n + a] = !0, Dr(e, t, Qn, "plantTrack");
				break;
			}
			break;
		}
		case "water": {
			let n = Yn[r];
			n !== void 0 && !i.tanks[n] && (i.tanks[n] = !0, Dr(e, t, $n, "waterTrack"));
			break;
		}
		case "planning": i.plannings < 6 && i.cells.some((e) => e === null) && a.queue.push({ k: "planX" });
	}
}
function Ar(e, t) {
	for (; e.queue.length > 0 && e.queue[0].k === "infect" && gr(t, e.queue[0].q).length === 0;) e.queue.shift();
}
function jr(e) {
	return e.players.every((t) => {
		let n = e.picks[t];
		return (e.stage === "prop" || n.combo !== null || n.error) && n.queue.length === 0;
	});
}
function Mr(e) {
	for (let t of e.turnViruses) {
		let n = qn[t];
		for (let t of e.players) e.sheets[t].viruses[n] = !0;
	}
	for (let t of e.players) {
		let n = e.sheets[t], r = e.picks[t], i = 0;
		r.error && n.errors >= 2 && (i += 1);
		for (let t of e.turnProps) n.propSlots[t] || (n.propSlots[t] = !0, i += 1);
		i += e.turnViruses.length;
		for (let e = 0; e < i; e += 1) for (let e = 0; e < 11; e += 1) n.viruses[e] && r.queue.push({
			k: "infect",
			q: e
		});
		Ar(r, n);
	}
	e.turnViruses = [], e.turnProps = [];
}
function Nr(e) {
	let t = ae(e.players, e.missions, e.missionClaims, e.sheets, (e, t) => _r(e, t));
	for (let n of t) e.missionClaims[n.rid][n.slot] = n.level;
	let n = !1;
	for (let r of t) if (r.level === "high") {
		let t = rr[r.slot];
		e.activatedViruses[t] || (Er(e, t), n = !0);
	}
	return n;
}
function Pr(e) {
	for (; Nr(e);) if (Mr(e), !jr(e)) return;
	if (e.players.some((t) => {
		let n = e.sheets[t];
		return n.errors >= 3 || e.missionClaims[t].filter(Boolean).length >= 3 || n.cells.every((e) => e !== null);
	})) {
		for (let t of e.players) {
			let n = e.sheets[t];
			for (let e = 0; e < 11; e += 1) n.evac[e] === null && (n.evac[e] = dr(n, e));
		}
		e.phase = "done";
		return;
	}
	e.flipped.forEach((t, n) => e.discards[n].push(t)), wr(e), e.stage = "play";
}
function Fr(e) {
	Mr(e), e.stage = "prop", jr(e) && Pr(e);
}
function Ir(e, t, n = !1) {
	let r = e.picks[t], i = e.sheets[t];
	Ar(r, i), (n || r.queue.length === 0) && pr(i), jr(e) && (e.stage === "play" ? Fr(e) : Pr(e));
}
function Lr(e, t, n) {
	if (e.phase === "done") return { code: X.over };
	let r = e.picks[n.by];
	if (!r) return { code: X.badStage };
	if (t.type === "grey") {
		if (e.stage !== "grey") return { code: X.badStage };
		if (e.sheets[n.by].greyQuarter >= 0) return { code: X.alreadyDone };
		let r = ar(t.cell);
		if (!Jn.includes(r)) return { code: X.badCell };
		let i = structuredClone(e), a = i.sheets[n.by];
		return a.cells[t.cell] = "v", a.greyQuarter = r, a.viruses[r] = !0, i.players.every((e) => i.sheets[e].greyQuarter >= 0) && (wr(i), i.stage = "play"), {
			state: i,
			fx: []
		};
	}
	if (e.stage === "grey") return { code: X.badStage };
	if (t.type === "pick") {
		if (e.stage !== "play") return { code: X.badStage };
		if (r.combo !== null || r.error) return { code: X.alreadyDone };
		let i = e.flipped[t.combo];
		if (!i) return { code: X.badCombo };
		let a = e.sheets[n.by], o = t.wild ?? i.act;
		if (t.wild !== void 0 && a.wildsUsed >= a.wilds) return { code: X.noWild };
		if (t.mod !== void 0 && (o !== "astronaut" || a.astronauts >= 6 || i.n + t.mod < 0 || i.n + t.mod > 17)) return { code: X.badMod };
		let s = i.n + (t.mod ?? 0);
		if (!or(a.cells, t.cell, s)) return { code: X.badCell };
		let c = structuredClone(e), l = c.sheets[n.by];
		t.wild !== void 0 && (l.wildsUsed += 1), l.cells[t.cell] = s, o === "astronaut" && t.mod !== void 0 && (l.astronauts += 1, l.astronauts % 2 == 0 && (l.wilds += 1));
		let u = c.picks[n.by];
		return u.combo = t.combo, u.cell = t.cell, kr(c, n.by, o, t.cell), Ir(c, n.by), {
			state: c,
			fx: []
		};
	}
	if (t.type === "error") {
		if (e.stage !== "play") return { code: X.badStage };
		if (r.combo !== null || r.error) return { code: X.alreadyDone };
		let t = e.sheets[n.by];
		if (!e.flipped.every((e) => sr(t.cells, e.n).length === 0)) return { code: X.canPlace };
		let i = structuredClone(e);
		return i.sheets[n.by].errors = Math.min(3, i.sheets[n.by].errors + 1), i.picks[n.by].error = !0, Ir(i, n.by), {
			state: i,
			fx: []
		};
	}
	let i = r.queue[0];
	if (t.type === "skip") {
		if (!i || i.k === "infect") return { code: X.badEffect };
		let t = structuredClone(e);
		return t.picks[n.by].queue.shift(), Ir(t, n.by), {
			state: t,
			fx: []
		};
	}
	if (t.type === "close") {
		if (!i || i.k !== "robot") return { code: X.badEffect };
		let r = e.sheets[n.by];
		if (t.walk < 0 || t.walk >= 22 || r.walkways[t.walk]) return { code: X.badTarget };
		let a = structuredClone(e), o = a.sheets[n.by];
		return o.walkways[t.walk] = !0, hr(o, t.walk), a.picks[n.by].queue.shift(), Ir(a, n.by), {
			state: a,
			fx: []
		};
	}
	if (t.type === "circleEnergy") {
		if (!i || i.k !== "energy") return { code: X.badEffect };
		let r = e.sheets[n.by];
		if (i.q !== null && t.quarter !== i.q || !Or(r, t.quarter).includes(t.quarter)) return { code: X.badTarget };
		let a = structuredClone(e), o = a.sheets[n.by], s = o.energy[t.quarter * 2] ? t.quarter * 2 + 1 : t.quarter * 2;
		return o.energy[s] = !0, a.picks[n.by].queue.shift(), Ir(a, n.by), {
			state: a,
			fx: []
		};
	}
	if (t.type === "planX") {
		if (!i || i.k !== "planX") return { code: X.badEffect };
		let r = e.sheets[n.by];
		if (r.plannings >= 6) return { code: X.badEffect };
		if (t.cell < 0 || t.cell >= 55 || r.cells[t.cell] !== null) return { code: X.badCell };
		let a = structuredClone(e), o = a.sheets[n.by];
		return o.cells[t.cell] = "x", o.plannings += 1, o.plannings % 2 == 0 && (o.wilds += 1), a.picks[n.by].queue.shift(), Ir(a, n.by), {
			state: a,
			fx: []
		};
	}
	if (t.type === "infect") {
		if (!i || i.k !== "infect") return { code: X.badEffect };
		let r = e.sheets[n.by], a = gr(r, i.q);
		if (a.length === 0 || t.cells.length !== a.length) return { code: X.badTarget };
		for (let e = 0; e < a.length; e += 1) if (!a[e].includes(t.cells[e])) return { code: X.badTarget };
		let o = structuredClone(e), s = o.sheets[n.by];
		for (let e of t.cells) s.cells[e] = "v";
		return o.picks[n.by].queue.shift(), Ir(o, n.by, !0), {
			state: o,
			fx: []
		};
	}
	return { code: X.badStage };
}
var Rr = [
	1,
	3,
	6,
	9,
	12,
	16,
	20,
	24,
	28
], zr = [
	[0, 8],
	[9, 18],
	[19, 25],
	[26, 31],
	[32, 37],
	[38, 42]
], Br = [
	{
		starship: 0,
		gh: !1,
		cells: [
			0,
			1,
			2,
			3
		]
	},
	{
		starship: 0,
		gh: !0,
		cells: [4]
	},
	{
		starship: 0,
		gh: !1,
		cells: [
			5,
			6,
			7,
			8
		]
	},
	{
		starship: 1,
		gh: !1,
		cells: [
			9,
			10,
			11
		]
	},
	{
		starship: 1,
		gh: !1,
		cells: [
			12,
			13,
			14
		]
	},
	{
		starship: 1,
		gh: !0,
		cells: [15]
	},
	{
		starship: 1,
		gh: !1,
		cells: [
			16,
			17,
			18
		]
	},
	{
		starship: 2,
		gh: !0,
		cells: [19]
	},
	{
		starship: 2,
		gh: !1,
		cells: [
			20,
			21,
			22
		]
	},
	{
		starship: 2,
		gh: !1,
		cells: [
			23,
			24,
			25
		]
	},
	{
		starship: 3,
		gh: !1,
		cells: [26, 27]
	},
	{
		starship: 3,
		gh: !0,
		cells: [28]
	},
	{
		starship: 3,
		gh: !1,
		cells: [
			29,
			30,
			31
		]
	},
	{
		starship: 4,
		gh: !1,
		cells: [
			32,
			33,
			34
		]
	},
	{
		starship: 4,
		gh: !0,
		cells: [35]
	},
	{
		starship: 4,
		gh: !1,
		cells: [36, 37]
	},
	{
		starship: 5,
		gh: !1,
		cells: [38, 39]
	},
	{
		starship: 5,
		gh: !1,
		cells: [40, 41]
	},
	{
		starship: 5,
		gh: !0,
		cells: [42]
	}
], Vr = [
	[0, 1],
	[1, 2],
	[0, 3],
	[4, 0],
	[6, 2],
	[3, 4],
	[4, 5],
	[5, 6],
	[8, 3],
	[9, 4],
	[7, 8],
	[8, 9],
	[10, 8],
	[12, 9],
	[10, 11],
	[11, 12],
	[13, 10],
	[15, 12],
	[13, 14],
	[14, 15],
	[16, 13],
	[17, 15],
	[16, 17],
	[17, 18]
], Hr = [0, 2], Ur = {
	2: 0,
	6: 1,
	10: 2,
	13: 3,
	17: 4,
	21: 5,
	25: 6,
	26: 7,
	30: 8,
	33: 9,
	36: 10,
	38: 11,
	40: 12
}, Wr = [
	[
		2,
		1,
		0
	],
	[
		5,
		4,
		3
	],
	[
		8,
		7,
		6
	],
	[10, 9],
	[12, 11],
	[13]
], Gr = [
	0,
	0,
	0,
	1,
	1,
	2
], Kr = [
	[
		0,
		1,
		2
	],
	[
		3,
		4,
		5
	],
	[6, 7],
	[8, 9],
	[10, 11],
	[12]
], qr = [
	0,
	0,
	1,
	1,
	1,
	2
], Jr = [
	4,
	15,
	19,
	28,
	35,
	42
], Yr = [
	0,
	7,
	11,
	18,
	23,
	27,
	37,
	39
], Xr = [
	[0, 1],
	[
		2,
		3,
		4
	],
	[5, 6],
	[7, 8],
	[9, 10],
	[11, 12]
], Zr = Object.fromEntries(Br.map((e, t) => [t, Ur[e.cells.find((e) => Ur[e] !== void 0)]]).filter((e) => e[1] !== void 0)), Qr = (() => {
	let e = Array(43).fill(-1);
	return Br.forEach((t, n) => t.cells.forEach((t) => e[t] = n)), e;
})(), $r = Qr.map((e) => Br[e].starship);
function ei() {
	return {
		cells: Array(43).fill(null),
		airlocks: Array(24).fill(!1),
		tanks: Array(13).fill(!1),
		reactors: Array(14).fill(!1),
		plants: Array(13).fill(!1),
		x2: [
			,
			,
			,
			,
			,
			,
		].fill(null),
		astronauts: 0,
		wilds: 0,
		wildsUsed: 0,
		plannings: 0,
		errors: 0
	};
}
function ti(e) {
	let t = new Set(Hr), n = [...Hr];
	for (; n.length > 0;) {
		let r = n.shift();
		Vr.forEach(([i, a], o) => {
			if (!e[o]) return;
			let s = i === r ? a : a === r ? i : -1;
			s >= 0 && !t.has(s) && (t.add(s), n.push(s));
		});
	}
	return t;
}
function ni(e) {
	let t = ti(e), n = [];
	return Vr.forEach(([r, i], a) => {
		!e[a] && (t.has(r) || t.has(i)) && n.push(a);
	}), n;
}
function ri(e, t, n) {
	if (t < 0 || t >= 43 || e.cells[t] !== null || !ti(e.airlocks).has(Qr[t])) return !1;
	let [r, i] = zr[$r[t]];
	for (let i = r; i < t; i += 1) {
		let t = e.cells[i];
		if (typeof t == "number" && t >= n) return !1;
	}
	for (let r = t + 1; r <= i; r += 1) {
		let t = e.cells[r];
		if (typeof t == "number" && t <= n) return !1;
	}
	return !0;
}
function ii(e, t) {
	let n = [];
	for (let r = 0; r < 43; r += 1) ri(e, r, t) && n.push(r);
	return n;
}
function ai(e, t) {
	return Kr[t].filter((t) => e.plants[t]).length + qr[t];
}
function oi(e, t) {
	return Wr[t].filter((t) => e.reactors[t]).length + Gr[t];
}
function si(e, t) {
	return Br[t].cells.every((t) => e.cells[t] !== null);
}
var ci = {
	100: {
		id: 100,
		kind: "A",
		hi: 10,
		lo: 5
	},
	101: {
		id: 101,
		kind: "A",
		hi: 7,
		lo: 3
	},
	102: {
		id: 102,
		kind: "B",
		hi: 9,
		lo: 4
	},
	103: {
		id: 103,
		kind: "B",
		hi: 10,
		lo: 5
	},
	104: {
		id: 104,
		kind: "C",
		hi: 10,
		lo: 5
	},
	105: {
		id: 105,
		kind: "C",
		hi: 10,
		lo: 5
	}
}, li = {
	A: [100, 101],
	B: [102, 103],
	C: [104, 105]
};
function ui(e, t) {
	switch (e) {
		case 100: return Jr.filter((e, n) => t.cells[e] !== null && ai(t, n) === 3).length >= 3;
		case 101: return t.cells[Jr[5]] !== null && ai(t, 5) === 3;
		case 102: return Br.filter((e, n) => !e.gh && si(t, n)).length >= 7;
		case 103: return zr.filter(([e, n]) => {
			for (let r = e; r <= n; r += 1) if (t.cells[r] === null) return !1;
			return !0;
		}).length >= 3;
		case 104: return Wr.filter((e) => e.every((e) => t.reactors[e])).length >= 3;
		case 105: return Xr.filter((e) => e.every((e) => t.tanks[e])).length >= 3;
	}
}
var di = [
	0,
	2,
	4,
	7
], fi = [
	0,
	2,
	4,
	7
];
function pi(e) {
	return Jr.reduce((t, n, r) => {
		if (e.cells[n] === null) return t;
		let i = di[ai(e, r)];
		return t + (e.x2[r] === "circle" ? i * 2 : i);
	}, 0);
}
function mi(e) {
	let t = 0;
	return Br.forEach((n, r) => {
		if (n.gh || !si(e, r)) return;
		let i = fi[Math.min(3, oi(e, n.starship))];
		t += e.tanks[Zr[r]] ? i * 2 : i;
	}), t;
}
function hi(e) {
	return e.plannings > 0 ? Rr[e.plannings - 1] : 0;
}
function gi(e) {
	return pi(e) + mi(e) - hi(e) - e.errors * 5;
}
var Z = {
	over: "games.moon.errOver",
	badStage: "games.moon.errBadStage",
	alreadyDone: "games.moon.errAlreadyDone",
	badCell: "games.moon.errBadCell",
	badCombo: "games.moon.errBadCombo",
	canPlace: "games.moon.errCanPlace",
	badEffect: "games.moon.errBadEffect",
	badTarget: "games.moon.errBadTarget",
	badMod: "games.moon.errBadMod",
	noWild: "games.moon.errNoWild"
};
function _i() {
	return {
		combo: null,
		cell: null,
		error: !1,
		queue: []
	};
}
function vi(e) {
	e.turn += 1, e.flipped = [
		V(e, 0),
		V(e, 1),
		V(e, 2)
	], e.picks = {};
	for (let t of e.players) e.picks[t] = _i();
}
function yi(t, n) {
	let r = {
		adv: 7,
		players: t,
		turn: 0,
		seed: n,
		rngCursor: 3,
		piles: [
			[],
			[],
			[]
		],
		discards: [
			[],
			[],
			[]
		],
		flipped: [
			H[0],
			H[0],
			H[0]
		],
		missions: [
			100,
			102,
			104
		],
		missionClaims: {},
		x2Claims: [
			,
			,
			,
			,
			,
			,
		].fill(null),
		sheets: {},
		picks: {},
		phase: "pick"
	};
	r.missions = [
		"A",
		"B",
		"C"
	].map((t, r) => li[t][e(n, r, 2)]);
	let i = B(r, [...H]);
	r.piles = [
		i.slice(0, 21),
		i.slice(21, 42),
		i.slice(42)
	];
	for (let e of t) r.sheets[e] = ei(), r.missionClaims[e] = [
		null,
		null,
		null
	];
	return vi(r), {
		state: r,
		fx: []
	};
}
function bi(e) {
	return e.players.every((t) => {
		let n = e.picks[t];
		return (n.combo !== null || n.error) && n.queue.length === 0;
	});
}
function xi(e, t, n) {
	let r = e.sheets[t];
	if (r.x2[n] !== null) return;
	let i = e.x2Claims[n];
	i ? i.turn === e.turn ? (i.rids.includes(t) || i.rids.push(t), r.x2[n] = "circle") : r.x2[n] = "cross" : (e.x2Claims[n] = {
		turn: e.turn,
		rids: [t]
	}, r.x2[n] = "circle");
}
function Si(e, t, n, r) {
	let i = e.sheets[t], a = e.picks[t];
	Yr.includes(r) && a.queue.push({ k: "airlock" });
	let o = Jr.indexOf(r);
	o >= 0 && xi(e, t, o);
	let s = $r[r];
	switch (n) {
		case "energy": {
			let e = Wr[s].find((e) => !i.reactors[e]);
			e !== void 0 && (i.reactors[e] = !0);
			break;
		}
		case "plant": {
			let e = Kr[s].find((e) => !i.plants[e]);
			e !== void 0 && (i.plants[e] = !0);
			break;
		}
		case "water": {
			let e = Ur[r];
			e !== void 0 && !i.tanks[e] && (i.tanks[e] = !0);
			break;
		}
		case "robot":
			ni(i.airlocks).length > 0 && a.queue.push({ k: "airlock" });
			break;
		case "planning": i.plannings < 9 && i.cells.some((e, t) => e === null && ti(i.airlocks).has(Qr[t])) && a.queue.push({ k: "planX" });
	}
}
function Ci(e) {
	for (let t of ae(e.players, e.missions, e.missionClaims, e.sheets, (e, t) => ui(e, t))) e.missionClaims[t.rid][t.slot] = t.level;
	if (e.players.some((t) => {
		let n = e.sheets[t];
		return e.missionClaims[t].filter(Boolean).length >= 3 || n.errors >= 3 || n.cells.every((e) => e !== null);
	})) {
		e.phase = "done";
		return;
	}
	e.flipped.forEach((t, n) => e.discards[n].push(t)), vi(e);
}
function wi(e, t, n) {
	if (e.phase === "done") return { code: Z.over };
	let r = e.picks[n.by];
	if (!r) return { code: Z.badStage };
	if (t.type === "pick") {
		if (r.combo !== null || r.error) return { code: Z.alreadyDone };
		let i = e.flipped[t.combo];
		if (!i) return { code: Z.badCombo };
		let a = t.wild ?? i.act, o = e.sheets[n.by];
		if (t.wild !== void 0 && o.wildsUsed >= o.wilds) return { code: Z.noWild };
		if (t.mod !== void 0 && (a !== "astronaut" || o.astronauts >= 6 || i.n + t.mod < 0 || i.n + t.mod > 17)) return { code: Z.badMod };
		let s = i.n + (t.mod ?? 0);
		if (!ri(o, t.cell, s)) return { code: Z.badCell };
		let c = structuredClone(e), l = c.sheets[n.by];
		l.cells[t.cell] = s, t.wild !== void 0 && (l.wildsUsed += 1), t.mod !== void 0 && (l.astronauts += 1, l.astronauts % 2 == 0 && l.wilds < 3 && (l.wilds += 1));
		let u = c.picks[n.by];
		return u.combo = t.combo, u.cell = t.cell, Si(c, n.by, a, t.cell), bi(c) && Ci(c), {
			state: c,
			fx: []
		};
	}
	if (t.type === "error") {
		if (r.combo !== null || r.error) return { code: Z.alreadyDone };
		let t = e.sheets[n.by];
		if (!e.flipped.every((e) => ii(t, e.n).length === 0)) return { code: Z.canPlace };
		let i = structuredClone(e), a = i.sheets[n.by];
		return a.errors = Math.min(3, a.errors + 1), i.picks[n.by].error = !0, a.errors <= 2 && ni(a.airlocks).length > 0 && i.picks[n.by].queue.push({ k: "airlock" }), bi(i) && Ci(i), {
			state: i,
			fx: []
		};
	}
	let i = r.queue[0];
	if (t.type === "skip") {
		if (!i) return { code: Z.badEffect };
		let t = structuredClone(e);
		return t.picks[n.by].queue.shift(), bi(t) && Ci(t), {
			state: t,
			fx: []
		};
	}
	if (t.type === "airlock") {
		if (i?.k !== "airlock") return { code: Z.badEffect };
		if (!ni(e.sheets[n.by].airlocks).includes(t.airlock)) return { code: Z.badTarget };
		let r = structuredClone(e);
		return r.sheets[n.by].airlocks[t.airlock] = !0, r.picks[n.by].queue.shift(), bi(r) && Ci(r), {
			state: r,
			fx: []
		};
	}
	if (t.type === "planX") {
		if (i?.k !== "planX") return { code: Z.badEffect };
		let r = e.sheets[n.by];
		if (r.plannings >= 9) return { code: Z.badEffect };
		if (t.cell < 0 || t.cell >= 43 || r.cells[t.cell] !== null || !ti(r.airlocks).has(Qr[t.cell])) return { code: Z.badCell };
		let a = structuredClone(e), o = a.sheets[n.by];
		o.cells[t.cell] = "x", o.plannings += 1, Yr.includes(t.cell) && a.picks[n.by].queue.push({ k: "airlock" });
		let s = Jr.indexOf(t.cell);
		return s >= 0 && xi(a, n.by, s), a.picks[n.by].queue.shift(), bi(a) && Ci(a), {
			state: a,
			fx: []
		};
	}
	return { code: Z.badStage };
}
function Ti(e, t) {
	return t.reduce((t, n, r) => {
		if (!n) return t;
		let i = ci[e[r]];
		return t + (n === "high" ? i.hi : i.lo);
	}, 0);
}
//#endregion
//#region src/games/moon/meta.ts
var Ei = {
	id: "moon",
	tier: "beta",
	mechanics: ["roll-and-write"],
	interactionTags: [],
	nameKey: "games.moon.name",
	descKey: "games.moon.desc",
	rulesKey: "games.moon.rules",
	icon: "🚀",
	iconImg: "games/moon.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/moon/en.pdf" },
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [
		2,
		3,
		4
	],
	accent: "#ea7c28",
	releasedAt: "2026-09-17",
	search: {
		py: "huan ying lai dao yue qiu",
		init: "hyldyq"
	},
	hotseat: "cover"
}, Di = t.enum([
	"robot",
	"energy",
	"plant",
	"water",
	"astronaut",
	"planning"
]), Oi = t.object({
	n: t.int().min(1).max(15),
	act: Di
}), ki = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("pick"),
		combo: t.union([
			t.literal(0),
			t.literal(1),
			t.literal(2)
		]),
		cell: t.int().min(0).max(54),
		mod: t.union([
			t.literal(-2),
			t.literal(-1),
			t.literal(0),
			t.literal(1),
			t.literal(2)
		]).optional(),
		wild: Di.optional()
	}),
	t.object({ type: t.literal("error") }),
	t.object({
		type: t.literal("build"),
		cell: t.int().min(0).max(52)
	}),
	t.object({
		type: t.literal("activate"),
		target: t.int().min(0).max(6)
	}),
	t.object({
		type: t.literal("robot"),
		station: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("plant"),
		station: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("planX"),
		cell: t.int().min(0).max(54)
	}),
	t.object({
		type: t.literal("split"),
		gap: t.int().min(0).max(34)
	}),
	t.object({
		type: t.literal("tunnel"),
		edge: t.int().min(0).max(59)
	}),
	t.object({
		type: t.literal("energy"),
		track: t.union([
			t.literal(0),
			t.literal(1),
			t.literal(2)
		])
	}),
	t.object({
		type: t.literal("stem"),
		stem: t.int().min(0).max(23)
	}),
	t.object({
		type: t.literal("cross"),
		sym: t.enum(["bolt", "robot"]),
		factory: t.int().min(0).max(10)
	}),
	t.object({
		type: t.literal("towerSym"),
		level: t.int().min(0).max(7)
	}),
	t.object({
		type: t.literal("domeBuild"),
		index: t.int().min(0).max(15)
	}),
	t.object({
		type: t.literal("domeCut"),
		index: t.int().min(0).max(15)
	}),
	t.object({
		type: t.literal("energyUp"),
		field: t.union([
			t.literal(0),
			t.literal(1),
			t.literal(2),
			t.literal(3)
		])
	}),
	t.object({
		type: t.literal("grey"),
		cell: t.int().min(0).max(54)
	}),
	t.object({
		type: t.literal("close"),
		walk: t.int().min(0).max(21)
	}),
	t.object({
		type: t.literal("circleEnergy"),
		quarter: t.int().min(0).max(10)
	}),
	t.object({
		type: t.literal("infect"),
		cells: t.array(t.int().min(0).max(54)).min(1).max(6)
	}),
	t.object({
		type: t.literal("airlock"),
		airlock: t.int().min(0).max(23)
	}),
	t.object({ type: t.literal("skip") })
]), Ai = t.object({ adventure: t.union([
	t.literal(1),
	t.literal(2),
	t.literal(3),
	t.literal(4),
	t.literal(5),
	t.literal(6),
	t.literal(7)
]).default(1) }).default({ adventure: 1 }), ji = t.union([
	t.int().min(1).max(15),
	t.literal("x"),
	t.null()
]), Mi = t.object({
	cells: t.array(ji).length(53),
	circled: t.int().min(0).max(8),
	cleared: t.int().min(0).max(8),
	track: t.int().min(0).max(31),
	bonus: t.int().min(0).max(8),
	activated: t.array(t.boolean()).length(7),
	xCount: t.int().min(0),
	launched: t.boolean()
}), Ni = t.object({
	combo: t.union([
		t.literal(0),
		t.literal(1),
		t.literal(2),
		t.null()
	]),
	cell: t.union([t.int().min(0).max(52), t.null()]),
	error: t.boolean(),
	queue: t.array(t.enum(["build", "activate"]))
}), Pi = {
	players: t.array(t.string()).min(2).max(6),
	turn: t.int().min(1),
	phase: t.enum(["pick", "done"]),
	flipped: t.array(Oi).length(3),
	missionClaims: t.record(t.string(), t.array(t.union([t.enum(["high", "low"]), t.null()])).length(3))
}, Fi = t.object({
	...Pi,
	adv: t.literal(1),
	missions: t.array(t.union([
		t.literal(64),
		t.literal(65),
		t.literal(66),
		t.literal(67),
		t.literal(68),
		t.literal(69)
	])).length(3),
	usedSabotages: t.array(t.boolean()).length(8),
	sheets: t.record(t.string(), Mi),
	picks: t.record(t.string(), Ni),
	pendingSab: t.array(t.object({
		sab: t.int().min(0).max(7),
		by: t.string()
	}))
}), Ii = t.union([
	t.int().min(0).max(17),
	t.literal("x"),
	t.null()
]), Li = t.object({
	cells: t.array(Ii).length(36),
	tanks: t.array(t.boolean()).length(12),
	splits: t.array(t.boolean()).length(35),
	energyPairs: t.int().min(0).max(6),
	energyPending: t.boolean(),
	stations: t.array(t.object({
		robots: t.int().min(0).max(4),
		plants: t.int().min(0).max(4),
		mult: t.union([t.enum(["high", "low"]), t.null()]),
		fullTurn: t.int().min(-1)
	})).length(4),
	astronauts: t.int().min(0).max(6),
	plannings: t.int().min(0).max(6),
	wilds: t.int().min(0).max(6),
	wildsUsed: t.int().min(0).max(6),
	errors: t.int().min(0).max(4)
}), Ri = t.object({
	combo: t.union([
		t.literal(0),
		t.literal(1),
		t.literal(2),
		t.null()
	]),
	cell: t.union([t.int().min(0).max(35), t.null()]),
	error: t.boolean(),
	queue: t.array(t.enum([
		"robot",
		"plant",
		"planX",
		"split"
	]))
}), zi = t.object({
	...Pi,
	adv: t.literal(2),
	missions: t.array(t.union([
		t.literal(70),
		t.literal(71),
		t.literal(72),
		t.literal(73),
		t.literal(74),
		t.literal(75)
	])).length(3),
	sheets: t.record(t.string(), Li),
	picks: t.record(t.string(), Ri)
}), Bi = t.object({
	cells: t.array(Ii).length(36),
	tanks: t.array(t.boolean()).length(8),
	antennas: t.array(t.boolean()).length(16),
	greenhouses: t.array(t.boolean()).length(16),
	tunnels: t.array(t.boolean()).length(60),
	trackPlant: t.int().min(0).max(4),
	trackWater: t.int().min(0).max(4),
	trackAntenna: t.int().min(0).max(4),
	astronauts: t.int().min(0).max(9),
	planning: t.int().min(0).max(10),
	errors: t.int().min(0).max(4),
	quarterTurn: t.array(t.int().min(-1)).length(4)
}), Vi = t.object({
	combo: t.union([
		t.literal(0),
		t.literal(1),
		t.literal(2),
		t.null()
	]),
	cell: t.union([t.int().min(0).max(35), t.null()]),
	error: t.boolean(),
	queue: t.array(t.enum([
		"robot",
		"energy",
		"planX"
	]))
}), Hi = t.object({
	...Pi,
	adv: t.literal(3),
	missions: t.array(t.union([
		t.literal(76),
		t.literal(77),
		t.literal(78),
		t.literal(79),
		t.literal(80),
		t.literal(81)
	])).length(3),
	sheets: t.record(t.string(), Bi),
	picks: t.record(t.string(), Vi)
}), Ui = t.object({
	cells: t.array(Ii).length(36),
	minerals: t.array(t.int().min(0).max(2)).length(36),
	stems: t.array(t.int().min(0).max(2)).length(24),
	pumps: t.array(t.boolean()).length(12),
	circled: t.array(t.int().min(0).max(16)).length(6),
	bolts: t.array(t.int().min(0).max(2)).length(6),
	robots: t.array(t.int().min(0).max(3)).length(6),
	upgraded: t.array(t.boolean()).length(6),
	badge: t.array(t.union([t.enum(["circle", "cross"]), t.null()])).length(4),
	subBolts: t.array(t.int().min(0).max(2)).length(5),
	subRobots: t.array(t.int().min(0).max(2)).length(5),
	subUsed: t.array(t.boolean()).length(5),
	errors: t.int().min(0).max(4)
}), Wi = t.discriminatedUnion("k", [
	t.object({
		k: t.literal("stem"),
		res: t.enum(["plant", "water"])
	}),
	t.object({
		k: t.literal("cross"),
		sym: t.enum(["bolt", "robot"])
	}),
	t.object({ k: t.literal("planX") })
]), Gi = t.object({
	combo: t.union([
		t.literal(0),
		t.literal(1),
		t.literal(2),
		t.null()
	]),
	cell: t.union([t.int().min(0).max(35), t.null()]),
	error: t.boolean(),
	extracted: t.boolean(),
	queue: t.array(Wi)
}), Ki = t.object({
	...Pi,
	adv: t.literal(4),
	missions: t.array(t.union([
		t.literal(82),
		t.literal(83),
		t.literal(84),
		t.literal(85),
		t.literal(86),
		t.literal(87)
	])).length(3),
	badgeClaims: t.array(t.object({
		turn: t.int().min(0),
		rids: t.array(t.string())
	}).nullable()).length(4),
	sheets: t.record(t.string(), Ui),
	picks: t.record(t.string(), Gi)
}), qi = t.object({
	cells: t.array(Ii).length(52),
	towerPlants: t.array(t.int().min(0).max(2)).length(8),
	towerWaters: t.array(t.int().min(0).max(1)).length(8),
	dome: t.array(t.object({
		parity: t.enum(["odd", "even"]),
		half: t.boolean(),
		built: t.boolean()
	})).min(8).max(16),
	astronauts: t.int().min(0).max(6),
	xCount: t.int().min(0),
	energyMission: t.int().min(0).max(4),
	energyTower: t.int().min(0).max(4),
	energyAstro: t.int().min(0).max(4),
	energyDome: t.int().min(0).max(4),
	bonus: t.array(t.union([t.enum(["circle", "cross"]), t.null()])).length(8),
	errors: t.int().min(0).max(4)
}), Ji = t.discriminatedUnion("k", [
	t.object({
		k: t.literal("tower"),
		res: t.enum(["plant", "water"])
	}),
	t.object({ k: t.literal("dome") }),
	t.object({ k: t.literal("planX") }),
	t.object({ k: t.literal("cut") }),
	t.object({ k: t.literal("energy") })
]), Yi = t.object({
	combo: t.union([
		t.literal(0),
		t.literal(1),
		t.literal(2),
		t.null()
	]),
	cell: t.union([t.int().min(0).max(51), t.null()]),
	error: t.boolean(),
	queue: t.array(Ji)
}), Xi = t.object({
	...Pi,
	adv: t.literal(5),
	missions: t.array(t.union([
		t.literal(88),
		t.literal(89),
		t.literal(90),
		t.literal(91),
		t.literal(92),
		t.literal(93)
	])).length(3),
	bonusClaims: t.array(t.object({
		turn: t.int().min(0),
		rids: t.array(t.string())
	}).nullable()).length(8),
	sheets: t.record(t.string(), qi),
	picks: t.record(t.string(), Yi)
}), Zi = t.union([
	t.int().min(0).max(17),
	t.literal("x"),
	t.literal("v"),
	t.null()
]), Qi = t.object({
	cells: t.array(Zi).length(55),
	energy: t.array(t.boolean()).length(22),
	walkways: t.array(t.boolean()).length(22),
	plants: t.array(t.boolean()).length(16),
	tanks: t.array(t.boolean()).length(10),
	plantTrack: t.int().min(0).max(16),
	waterTrack: t.int().min(0).max(10),
	viruses: t.array(t.boolean()).length(11),
	virusCrossed: t.array(t.boolean()).length(11),
	greyQuarter: t.int().min(-1).max(10),
	propSlots: t.array(t.boolean()).length(4),
	evac: t.array(t.union([t.int().min(0), t.null()])).length(11),
	astronauts: t.int().min(0).max(6),
	plannings: t.int().min(0).max(6),
	wilds: t.int().min(0).max(6),
	wildsUsed: t.int().min(0).max(6),
	errors: t.int().min(0).max(3)
}), $i = t.discriminatedUnion("k", [
	t.object({
		k: t.literal("energy"),
		q: t.union([t.int().min(0).max(10), t.null()])
	}),
	t.object({ k: t.literal("robot") }),
	t.object({ k: t.literal("planX") }),
	t.object({
		k: t.literal("infect"),
		q: t.int().min(0).max(10)
	})
]), ea = t.object({
	combo: t.union([
		t.literal(0),
		t.literal(1),
		t.literal(2),
		t.null()
	]),
	cell: t.union([t.int().min(0).max(54), t.null()]),
	error: t.boolean(),
	queue: t.array($i)
}), ta = t.object({
	...Pi,
	adv: t.literal(6),
	stage: t.enum([
		"grey",
		"play",
		"prop"
	]),
	turn: t.int().min(0),
	missions: t.array(t.union([
		t.literal(94),
		t.literal(95),
		t.literal(96),
		t.literal(97),
		t.literal(98),
		t.literal(99)
	])).length(3),
	activatedViruses: t.array(t.boolean()).length(5),
	sheets: t.record(t.string(), Qi),
	picks: t.record(t.string(), ea)
}), na = t.object({
	cells: t.array(Ii).length(43),
	airlocks: t.array(t.boolean()).length(24),
	tanks: t.array(t.boolean()).length(13),
	reactors: t.array(t.boolean()).length(14),
	plants: t.array(t.boolean()).length(13),
	x2: t.array(t.union([t.enum(["circle", "cross"]), t.null()])).length(6),
	astronauts: t.int().min(0).max(6),
	wilds: t.int().min(0).max(3),
	wildsUsed: t.int().min(0).max(3),
	plannings: t.int().min(0).max(9),
	errors: t.int().min(0).max(3)
}), ra = t.discriminatedUnion("k", [t.object({ k: t.literal("airlock") }), t.object({ k: t.literal("planX") })]), ia = t.object({
	combo: t.union([
		t.literal(0),
		t.literal(1),
		t.literal(2),
		t.null()
	]),
	cell: t.union([t.int().min(0).max(42), t.null()]),
	error: t.boolean(),
	queue: t.array(ra)
}), aa = t.object({
	...Pi,
	adv: t.literal(7),
	missions: t.array(t.union([
		t.literal(100),
		t.literal(101),
		t.literal(102),
		t.literal(103),
		t.literal(104),
		t.literal(105)
	])).length(3),
	x2Claims: t.array(t.object({
		turn: t.int().min(0),
		rids: t.array(t.string())
	}).nullable()).length(6),
	sheets: t.record(t.string(), na),
	picks: t.record(t.string(), ia)
}), oa = t.discriminatedUnion("adv", [
	Fi,
	zi,
	Hi,
	Ki,
	Xi,
	ta,
	aa
]), sa = t.object({}), ca = {
	over: "games.moon.errOver",
	badStage: "games.moon.errBadStage",
	alreadyDone: "games.moon.errAlreadyDone",
	badCell: "games.moon.errBadCell",
	badCombo: "games.moon.errBadCombo",
	canPlace: "games.moon.errCanPlace",
	badEffect: "games.moon.errBadEffect",
	badTarget: "games.moon.errBadTarget"
};
function la() {
	return {
		cells: k(),
		circled: 0,
		cleared: 0,
		track: 0,
		bonus: 0,
		activated: Array(7).fill(!1),
		xCount: 0,
		launched: !1
	};
}
function ua() {
	return {
		combo: null,
		cell: null,
		error: !1,
		queue: []
	};
}
function da(e) {
	e.turn += 1, e.flipped = [
		V(e, 0),
		V(e, 1),
		V(e, 2)
	], e.picks = {};
	for (let t of e.players) e.picks[t] = ua();
	e.pendingSab = [];
}
function fa(e, t, n) {
	return e.adventure === 2 ? Fn(t, n) : e.adventure === 3 ? He(t, n) : e.adventure === 4 ? dt(t, n) : e.adventure === 5 ? cn(t, n) : e.adventure === 6 ? Tr(t, n) : e.adventure === 7 ? yi(t, n) : pa(t, n);
}
function pa(t, n) {
	let r = {
		adv: 1,
		players: t,
		turn: 0,
		seed: n,
		rngCursor: 3,
		piles: [
			[],
			[],
			[]
		],
		discards: [
			[],
			[],
			[]
		],
		flipped: [
			H[0],
			H[0],
			H[0]
		],
		missions: [
			64,
			66,
			68
		],
		missionClaims: {},
		usedSabotages: Array(8).fill(!1),
		sheets: {},
		picks: {},
		pendingSab: [],
		phase: "pick"
	};
	r.missions = [
		"A",
		"B",
		"C"
	].map((t, r) => ie[t][e(n, r, 2)]);
	let i = B(r, [...H]);
	r.piles = [
		i.slice(0, 21),
		i.slice(21, 42),
		i.slice(42)
	];
	for (let e of t) r.sheets[e] = la(), r.missionClaims[e] = [
		null,
		null,
		null
	];
	return da(r), {
		state: r,
		fx: []
	};
}
function ma(e, t) {
	for (let n = 0; n < t; n += 1) e.track < 31 ? e.track += 1 : e.cleared < e.circled ? e.cleared += 1 : e.bonus < 8 && (e.bonus += 1);
}
function ha(e, t, n) {
	let r = e.sheets[t], i = T[n], a = e.picks[t];
	i.rocket && ma(r, i.rocket), i.inactive !== void 0 && r.activated[i.inactive] && ma(r, w[i.inactive].value), i.activation && a.queue.push("activate"), i.build && a.queue.push("build");
	for (let n of i.sabs) e.usedSabotages[n] || e.pendingSab.push({
		sab: n,
		by: t
	});
}
function ga(e, t, n) {
	let r = j(n);
	r >= 0 && F(e.sheets[t].cells, r) && ha(e, t, r);
}
function _a(e, t) {
	let n = e.sheets[t];
	return e.flipped.every((e) => P(n.cells, e.act, e.n).length === 0);
}
function va(e) {
	return e.players.every((t) => {
		let n = e.picks[t];
		return (n.combo !== null || n.error) && n.queue.length === 0;
	});
}
function ya(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.pendingSab) t.has(n.sab) || t.set(n.sab, /* @__PURE__ */ new Set()), t.get(n.sab).add(n.by);
	for (let [n, r] of t) if (!e.usedSabotages[n]) {
		e.usedSabotages[n] = !0;
		for (let t of e.players) !r.has(t) && e.sheets[t].circled < 8 && (e.sheets[t].circled += 1);
	}
	for (let t of ae(e.players, e.missions, e.missionClaims, e.sheets, (e, t) => z(e, t))) {
		e.missionClaims[t.rid][t.slot] = t.level;
		let n = re[e.missions[t.slot]];
		ma(e.sheets[t.rid], t.level === "high" ? n.hi : n.lo);
	}
	let n = e.players.filter((t) => {
		let n = e.sheets[t];
		return n.track >= 31 && n.cleared >= n.circled;
	});
	if (n.length > 0) {
		for (let t of n) e.sheets[t].launched = !0;
		e.phase = "done";
		return;
	}
	if (e.players.some((t) => {
		let n = e.sheets[t];
		return e.missionClaims[t].filter(Boolean).length >= 3 || n.circled >= 8 || L(n.cells);
	})) {
		e.phase = "done";
		return;
	}
	e.flipped.forEach((t, n) => e.discards[n].push(t)), da(e);
}
function ba(e, t, n) {
	if (e.phase === "done") return { code: ca.over };
	let r = e.picks[n.by];
	if (!r) return { code: ca.badStage };
	if (t.type === "pick") {
		if (r.combo !== null || r.error) return { code: ca.alreadyDone };
		let i = e.flipped[t.combo];
		if (!i) return { code: ca.badCombo };
		let a = structuredClone(e), o = a.sheets[n.by], s = j(t.cell);
		if (s < 0) return { code: ca.badCell };
		let c = E.findIndex((e) => e.quarters.includes(s));
		if (E[c].action !== i.act && E[c].action !== "wild" || !M(o.cells, t.cell, i.n)) return { code: ca.badCell };
		o.cells[t.cell] = i.n;
		let l = a.picks[n.by];
		return l.combo = t.combo, l.cell = t.cell, ga(a, n.by, t.cell), va(a) && ya(a), {
			state: a,
			fx: []
		};
	}
	if (t.type === "error") {
		if (r.combo !== null || r.error) return { code: ca.alreadyDone };
		if (!_a(e, n.by)) return { code: ca.canPlace };
		let t = structuredClone(e);
		return t.sheets[n.by].circled = Math.min(8, t.sheets[n.by].circled + 1), t.picks[n.by].error = !0, va(t) && ya(t), {
			state: t,
			fx: []
		};
	}
	let i = r.queue[0];
	if (t.type === "skip") {
		if (!i) return { code: ca.badEffect };
		let t = structuredClone(e);
		return t.picks[n.by].queue.shift(), va(t) && ya(t), {
			state: t,
			fx: []
		};
	}
	if (t.type === "build") {
		if (i !== "build") return { code: ca.badEffect };
		let r = structuredClone(e), a = r.sheets[n.by];
		return t.cell < 0 || t.cell >= 53 || a.cells[t.cell] !== null ? { code: ca.badCell } : (a.cells[t.cell] = "x", a.xCount += 1, r.picks[n.by].queue.shift(), ga(r, n.by, t.cell), va(r) && ya(r), {
			state: r,
			fx: []
		});
	}
	if (t.type === "activate") {
		if (i !== "activate") return { code: ca.badEffect };
		let r = structuredClone(e), a = r.sheets[n.by], o = t.target;
		return o < 0 || o >= w.length || a.activated[o] || F(a.cells, w[o].quarter) ? { code: ca.badTarget } : (a.activated[o] = !0, r.picks[n.by].queue.shift(), va(r) && ya(r), {
			state: r,
			fx: []
		});
	}
	return { code: ca.badStage };
}
function xa(e, t, n) {
	return e.adv === 2 ? zn(e, t, n) : e.adv === 3 ? Ke(e, t, n) : e.adv === 4 ? vt(e, t, n) : e.adv === 5 ? pn(e, t, n) : e.adv === 6 ? Lr(e, t, n) : e.adv === 7 ? wi(e, t, n) : ba(e, t, n);
}
function Sa(e) {
	return e.adv === 6 ? {
		public: {
			adv: 6,
			players: e.players,
			turn: e.turn,
			phase: e.phase,
			stage: e.stage,
			flipped: e.flipped.map((e) => ({ ...e })),
			missions: [...e.missions],
			missionClaims: e.missionClaims,
			activatedViruses: [...e.activatedViruses],
			sheets: e.sheets,
			picks: e.picks
		},
		private: {}
	} : e.adv === 7 ? {
		public: {
			adv: 7,
			players: e.players,
			turn: e.turn,
			phase: e.phase,
			flipped: e.flipped.map((e) => ({ ...e })),
			missions: [...e.missions],
			missionClaims: e.missionClaims,
			x2Claims: e.x2Claims.map((e) => e ? {
				turn: e.turn,
				rids: [...e.rids]
			} : null),
			sheets: e.sheets,
			picks: e.picks
		},
		private: {}
	} : e.adv === 2 ? {
		public: {
			adv: 2,
			players: e.players,
			turn: e.turn,
			phase: e.phase,
			flipped: e.flipped.map((e) => ({ ...e })),
			missions: [...e.missions],
			missionClaims: e.missionClaims,
			sheets: e.sheets,
			picks: e.picks
		},
		private: {}
	} : e.adv === 3 ? {
		public: {
			adv: 3,
			players: e.players,
			turn: e.turn,
			phase: e.phase,
			flipped: e.flipped.map((e) => ({ ...e })),
			missions: [...e.missions],
			missionClaims: e.missionClaims,
			sheets: e.sheets,
			picks: e.picks
		},
		private: {}
	} : e.adv === 4 ? {
		public: {
			adv: 4,
			players: e.players,
			turn: e.turn,
			phase: e.phase,
			flipped: e.flipped.map((e) => ({ ...e })),
			missions: [...e.missions],
			missionClaims: e.missionClaims,
			badgeClaims: e.badgeClaims.map((e) => e ? {
				turn: e.turn,
				rids: [...e.rids]
			} : null),
			sheets: e.sheets,
			picks: e.picks
		},
		private: {}
	} : e.adv === 5 ? {
		public: {
			adv: 5,
			players: e.players,
			turn: e.turn,
			phase: e.phase,
			flipped: e.flipped.map((e) => ({ ...e })),
			missions: [...e.missions],
			missionClaims: e.missionClaims,
			bonusClaims: e.bonusClaims.map((e) => e ? {
				turn: e.turn,
				rids: [...e.rids]
			} : null),
			sheets: e.sheets,
			picks: e.picks
		},
		private: {}
	} : {
		public: {
			adv: 1,
			players: e.players,
			turn: e.turn,
			phase: e.phase,
			flipped: e.flipped.map((e) => ({ ...e })),
			missions: [...e.missions],
			missionClaims: e.missionClaims,
			usedSabotages: [...e.usedSabotages],
			sheets: e.sheets,
			picks: e.picks,
			pendingSab: e.pendingSab.map((e) => ({ ...e }))
		},
		private: {}
	};
}
function Ca(e) {
	return e.adv === 2 ? ka(e) : e.adv === 3 ? Oa(e) : e.adv === 4 ? Da(e) : e.adv === 5 ? Ea(e) : e.adv === 6 ? Ta(e) : e.adv === 7 ? wa(e) : Aa(e);
}
function wa(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {};
	for (let n of e.players) t[n] = gi(e.sheets[n]) + Ti(e.missions, e.missionClaims[n]);
	let n = [...e.players].sort((n, r) => t[r] - t[n] || e.sheets[n].errors - e.sheets[r].errors || e.players.indexOf(n) - e.players.indexOf(r)), r = n[0];
	return {
		phase: "done",
		winner: n.filter((n) => t[n] === t[r] && e.sheets[n].errors === e.sheets[r].errors),
		ranking: n,
		scores: t
	};
}
function Ta(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {};
	for (let n of e.players) t[n] = Sr(e.sheets[n]) + vr(e.missions, e.missionClaims[n]);
	let n = [...e.players].sort((n, r) => t[r] - t[n] || e.sheets[n].errors - e.sheets[r].errors || e.players.indexOf(n) - e.players.indexOf(r)), r = n[0];
	return {
		phase: "done",
		winner: n.filter((n) => t[n] === t[r] && e.sheets[n].errors === e.sheets[r].errors),
		ranking: n,
		scores: t
	};
}
function Ea(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {};
	for (let n of e.players) t[n] = rn(e.sheets[n]) + Qt(e.missions, e.missionClaims[n], e.sheets[n]) + tn(e.players, e.sheets, n);
	let n = [...e.players].sort((n, r) => t[r] - t[n] || e.sheets[n].errors - e.sheets[r].errors || e.players.indexOf(n) - e.players.indexOf(r)), r = n[0];
	return {
		phase: "done",
		winner: n.filter((n) => t[n] === t[r] && e.sheets[n].errors === e.sheets[r].errors),
		ranking: n,
		scores: t
	};
}
function Da(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {};
	for (let n of e.players) t[n] = ot(e.sheets[n]) + st(e.missions, e.missionClaims[n]);
	let n = [...e.players].sort((n, r) => t[r] - t[n] || e.sheets[n].errors - e.sheets[r].errors || e.players.indexOf(n) - e.players.indexOf(r)), r = n[0];
	return {
		phase: "done",
		winner: n.filter((n) => t[n] === t[r] && e.sheets[n].errors === e.sheets[r].errors),
		ranking: n,
		scores: t
	};
}
function Oa(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = Ie(e.players, e.sheets), n = Le(e.players, e.sheets), r = {};
	for (let i of e.players) r[i] = Fe(e.sheets[i]) + Re(e.missions, e.missionClaims[i]) + t[i] + n[i];
	let i = [...e.players].sort((t, n) => r[n] - r[t] || e.sheets[t].errors - e.sheets[n].errors || e.players.indexOf(t) - e.players.indexOf(n)), a = i[0];
	return {
		phase: "done",
		winner: i.filter((t) => r[t] === r[a] && e.sheets[t].errors === e.sheets[a].errors),
		ranking: i,
		scores: r
	};
}
function ka(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = Bn(e.players, e.sheets), n = {};
	for (let r of e.players) n[r] = Mn(e.sheets[r]) + Vn(e.missions, e.missionClaims[r]) + t[r];
	let r = [...e.players].sort((t, r) => n[r] - n[t] || e.sheets[t].errors - e.sheets[r].errors || e.players.indexOf(t) - e.players.indexOf(r)), i = r[0];
	return {
		phase: "done",
		winner: r.filter((t) => n[t] === n[i] && e.sheets[t].errors === e.sheets[i].errors),
		ranking: r,
		scores: n
	};
}
function Aa(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {};
	for (let n of e.players) t[n] = ne(e.sheets[n]);
	let n = e.players.filter((t) => e.sheets[t].launched), r;
	if (n.length > 0) {
		let i = e.players.filter((t) => !e.sheets[t].launched);
		n.sort((t, n) => e.sheets[n].bonus - e.sheets[t].bonus || e.players.indexOf(t) - e.players.indexOf(n)), i.sort((n, r) => t[r] - t[n] || e.sheets[n].circled - e.sheets[r].circled || e.players.indexOf(n) - e.players.indexOf(r)), r = [...n, ...i];
		let a = n[0];
		return {
			phase: "done",
			winner: n.filter((t) => e.sheets[t].bonus === e.sheets[a].bonus),
			ranking: r,
			scores: t
		};
	}
	r = [...e.players].sort((n, r) => t[r] - t[n] || e.sheets[n].circled - e.sheets[r].circled || e.players.indexOf(n) - e.players.indexOf(r));
	let i = r[0];
	return {
		phase: "done",
		winner: r.filter((n) => t[n] === t[i] && e.sheets[n].circled === e.sheets[i].circled),
		ranking: r,
		scores: t
	};
}
var ja = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: Ei,
	schemas: {
		action: ki,
		publicView: oa,
		privateView: sa,
		config: Ai
	},
	setup: fa,
	reduce: xa,
	viewFor: Sa,
	status: Ca
}, Ma = 1544, Na = 1544, Pa = [
	{
		x: 313.8,
		y: 1343.4,
		w: 65,
		h: 68,
		pitch: 65,
		count: 2
	},
	{
		x: 472.6,
		y: 1341,
		w: 65,
		h: 68,
		pitch: 65,
		count: 2
	},
	{
		x: 633.9,
		y: 1346.3,
		w: 65,
		h: 68,
		pitch: 65,
		count: 2
	},
	{
		x: 791,
		y: 1344.1,
		w: 65,
		h: 68,
		pitch: 65,
		count: 2
	},
	{
		x: 305.6,
		y: 1209.5,
		w: 66,
		h: 68,
		pitch: 65,
		count: 2
	},
	{
		x: 469.9,
		y: 1211.5,
		w: 66,
		h: 68,
		pitch: 65,
		count: 2
	},
	{
		x: 629.1,
		y: 1211.5,
		w: 66,
		h: 68,
		pitch: 65,
		count: 2
	},
	{
		x: 790.3,
		y: 1205.5,
		w: 66,
		h: 68,
		pitch: 65,
		count: 2
	},
	{
		x: 258,
		y: 1062.7,
		w: 65,
		h: 68,
		pitch: 65,
		count: 5
	},
	{
		x: 630,
		y: 1063.8,
		w: 65,
		h: 68,
		pitch: 65,
		count: 2
	},
	{
		x: 800.9,
		y: 1061.7,
		w: 65,
		h: 68,
		pitch: 65,
		count: 3
	},
	{
		x: 422.7,
		y: 923.5,
		w: 65,
		h: 60,
		pitch: 65,
		count: 6
	},
	{
		x: 453.1,
		y: 773.6,
		w: 65,
		h: 65,
		pitch: 65,
		count: 5
	},
	{
		x: 431.1,
		y: 633.1,
		w: 65,
		h: 60,
		pitch: 65,
		count: 2
	},
	{
		x: 595.1,
		y: 636.8,
		w: 65,
		h: 60,
		pitch: 65,
		count: 3
	},
	{
		x: 433,
		y: 484.7,
		w: 65,
		h: 62,
		pitch: 65,
		count: 2
	},
	{
		x: 597.6,
		y: 481.9,
		w: 65,
		h: 62,
		pitch: 65,
		count: 3
	},
	{
		x: 519.4,
		y: 344.4,
		w: 65,
		h: 55,
		pitch: 65,
		count: 3
	},
	{
		x: 523.1,
		y: 195,
		w: 65,
		h: 58,
		pitch: 65,
		count: 3
	}
].flatMap((e) => f(e)), Fa = [
	{
		x: 384.4,
		y: 1158.9,
		w: 62,
		h: 46
	},
	{
		x: 692,
		y: 1155.3,
		w: 65,
		h: 46
	},
	{
		x: 358.4,
		y: 1004.6,
		w: 62,
		h: 48
	},
	{
		x: 536.6,
		y: 864.8,
		w: 64,
		h: 45
	},
	{
		x: 546.9,
		y: 720.5,
		w: 64,
		h: 45
	},
	{
		x: 693,
		y: 430,
		w: 68,
		h: 45
	},
	{
		x: 596.6,
		y: 284.8,
		w: 64,
		h: 44
	}
], Ia = [{
	x: 1044.2,
	y: 425.6,
	w: 70,
	h: 70,
	pitch: 90,
	count: 4,
	mark: "circle"
}, {
	x: 1001,
	y: 491.4,
	w: 70,
	h: 70,
	pitch: 90,
	count: 4,
	mark: "circle"
}], La = Ia.flatMap((e) => f(e)), Ra = [
	{
		x: 1174.2,
		y: 1439.1,
		w: 43,
		h: 70,
		pitch: 42,
		count: 5,
		mark: "slash"
	},
	{
		x: 1199,
		y: 1357.4,
		w: 43,
		h: 70,
		pitch: 42,
		count: 4,
		mark: "slash"
	},
	{
		x: 1217.1,
		y: 1272.6,
		w: 43,
		h: 70,
		pitch: 42,
		count: 3,
		mark: "slash"
	},
	{
		x: 1213.1,
		y: 1200.4,
		w: 43,
		h: 70,
		pitch: 42,
		count: 3,
		mark: "slash"
	},
	{
		x: 1217.1,
		y: 1109.6,
		w: 43,
		h: 70,
		pitch: 42,
		count: 3,
		mark: "slash"
	},
	{
		x: 1220.1,
		y: 1031.7,
		w: 43,
		h: 70,
		pitch: 42,
		count: 3,
		mark: "slash"
	},
	{
		x: 1215.3,
		y: 957.6,
		w: 43,
		h: 70,
		pitch: 42,
		count: 3,
		mark: "slash"
	},
	{
		x: 1218.3,
		y: 873.7,
		w: 43,
		h: 70,
		pitch: 42,
		count: 3,
		mark: "slash"
	},
	{
		x: 1241.9,
		y: 795.6,
		w: 43,
		h: 70,
		pitch: 42,
		count: 2,
		mark: "slash"
	},
	{
		x: 1245,
		y: 713,
		w: 43,
		h: 70,
		pitch: 42,
		count: 2,
		mark: "slash"
	}
], za = Ra.flatMap((e) => f(e)), Ba = [{
	x: 1219.7,
	y: 166.1,
	w: 40,
	h: 58,
	pitch: 40,
	count: 4
}, {
	x: 1221.6,
	y: 232,
	w: 40,
	h: 58,
	pitch: 40,
	count: 4
}], Va = Ba.flatMap((e) => f(e)), Ha = [
	{
		x: 1407.8,
		y: 1440.8,
		w: 80,
		h: 60
	},
	{
		x: 1409.8,
		y: 1363.6,
		w: 80,
		h: 60
	},
	{
		x: 1406.4,
		y: 1282.7,
		w: 80,
		h: 60
	},
	{
		x: 1407.8,
		y: 1204.2,
		w: 80,
		h: 60
	},
	{
		x: 1406.2,
		y: 1123.2,
		w: 80,
		h: 60
	},
	{
		x: 1410.4,
		y: 1041,
		w: 80,
		h: 60
	},
	{
		x: 1409.8,
		y: 961.1,
		w: 80,
		h: 60
	},
	{
		x: 1407.8,
		y: 884.1,
		w: 80,
		h: 60
	},
	{
		x: 1407.8,
		y: 803.1,
		w: 80,
		h: 60
	},
	{
		x: 1404.8,
		y: 723.1,
		w: 80,
		h: 60
	},
	{
		x: 1406.8,
		y: 641.1,
		w: 80,
		h: 60
	}
], Ua = [
	{
		x: 1055.6,
		y: 54,
		w: 68,
		h: 80
	},
	{
		x: 1128,
		y: 52.3,
		w: 68,
		h: 80
	},
	{
		x: 1205.7,
		y: 54.1,
		w: 68,
		h: 80
	}
];
if (Pa.length !== 53) throw Error("cell rects mismatch");
if (za.length !== 31) throw Error("track rects mismatch");
if (Va.length !== 8) throw Error("bonus rects mismatch");
if (La.length !== 8) throw Error("error rects mismatch");
if (Fa.length !== 7 || T.length !== 19) throw Error("layout mismatch");
//#endregion
//#region src/games/moon/adv/adv3-layout.ts
var Wa = 2315, Ga = 2315, Ka = [
	{
		x: 478,
		y: 118,
		w: 170,
		h: 170
	},
	{
		x: 711,
		y: 118,
		w: 170,
		h: 170
	},
	{
		x: 946,
		y: 118,
		w: 170,
		h: 170
	},
	{
		x: 1177,
		y: 118,
		w: 170,
		h: 170
	},
	{
		x: 1408,
		y: 118,
		w: 170,
		h: 170
	},
	{
		x: 1644,
		y: 118,
		w: 170,
		h: 170
	},
	{
		x: 478,
		y: 348,
		w: 170,
		h: 170
	},
	{
		x: 711,
		y: 348,
		w: 170,
		h: 170
	},
	{
		x: 946,
		y: 348,
		w: 170,
		h: 170
	},
	{
		x: 1177,
		y: 348,
		w: 170,
		h: 170
	},
	{
		x: 1408,
		y: 348,
		w: 170,
		h: 170
	},
	{
		x: 1644,
		y: 348,
		w: 170,
		h: 170
	},
	{
		x: 478,
		y: 585,
		w: 170,
		h: 170
	},
	{
		x: 711,
		y: 585,
		w: 170,
		h: 170
	},
	{
		x: 946,
		y: 585,
		w: 170,
		h: 170
	},
	{
		x: 1177,
		y: 585,
		w: 170,
		h: 170
	},
	{
		x: 1408,
		y: 585,
		w: 170,
		h: 170
	},
	{
		x: 1644,
		y: 585,
		w: 170,
		h: 170
	},
	{
		x: 478,
		y: 823,
		w: 170,
		h: 170
	},
	{
		x: 711,
		y: 823,
		w: 170,
		h: 170
	},
	{
		x: 946,
		y: 823,
		w: 170,
		h: 170
	},
	{
		x: 1177,
		y: 823,
		w: 170,
		h: 170
	},
	{
		x: 1408,
		y: 823,
		w: 170,
		h: 170
	},
	{
		x: 1644,
		y: 823,
		w: 170,
		h: 170
	},
	{
		x: 478,
		y: 1053,
		w: 170,
		h: 170
	},
	{
		x: 711,
		y: 1053,
		w: 170,
		h: 170
	},
	{
		x: 946,
		y: 1053,
		w: 170,
		h: 170
	},
	{
		x: 1177,
		y: 1053,
		w: 170,
		h: 170
	},
	{
		x: 1408,
		y: 1053,
		w: 170,
		h: 170
	},
	{
		x: 1644,
		y: 1053,
		w: 170,
		h: 170
	},
	{
		x: 478,
		y: 1283,
		w: 170,
		h: 170
	},
	{
		x: 711,
		y: 1283,
		w: 170,
		h: 170
	},
	{
		x: 946,
		y: 1283,
		w: 170,
		h: 170
	},
	{
		x: 1177,
		y: 1283,
		w: 170,
		h: 170
	},
	{
		x: 1408,
		y: 1283,
		w: 170,
		h: 170
	},
	{
		x: 1644,
		y: 1283,
		w: 170,
		h: 170
	}
], qa = [
	{
		x: 708,
		y: 121,
		w: 80,
		h: 80
	},
	{
		x: 1164,
		y: 107,
		w: 80,
		h: 80
	},
	{
		x: 970,
		y: 365,
		w: 80,
		h: 80
	},
	{
		x: 1432,
		y: 370,
		w: 80,
		h: 80
	},
	{
		x: 468,
		y: 574,
		w: 80,
		h: 80
	},
	{
		x: 1181,
		y: 586,
		w: 80,
		h: 80
	},
	{
		x: 735,
		y: 845,
		w: 80,
		h: 80
	},
	{
		x: 1417,
		y: 828,
		w: 80,
		h: 80
	},
	{
		x: 473,
		y: 1036,
		w: 80,
		h: 80
	},
	{
		x: 1186,
		y: 1051,
		w: 80,
		h: 80
	},
	{
		x: 1651,
		y: 1053,
		w: 80,
		h: 80
	},
	{
		x: 701,
		y: 1276,
		w: 80,
		h: 80
	},
	{
		x: 1418,
		y: 1290,
		w: 80,
		h: 80
	},
	{
		x: 1622,
		y: 100,
		w: 80,
		h: 80
	},
	{
		x: 1771,
		y: 110,
		w: 80,
		h: 80
	},
	{
		x: 1770,
		y: 228,
		w: 80,
		h: 80
	}
], Ja = [
	{
		x: 596,
		y: 233,
		w: 70,
		h: 70
	},
	{
		x: 1064,
		y: 463,
		w: 70,
		h: 70
	},
	{
		x: 1526,
		y: 463,
		w: 70,
		h: 70
	},
	{
		x: 1762,
		y: 700,
		w: 70,
		h: 70
	},
	{
		x: 829,
		y: 938,
		w: 70,
		h: 70
	},
	{
		x: 1064,
		y: 1168,
		w: 70,
		h: 70
	},
	{
		x: 1526,
		y: 1168,
		w: 70,
		h: 70
	},
	{
		x: 1295,
		y: 1398,
		w: 70,
		h: 70
	}
], Ya = [
	{
		x: 298,
		y: 135,
		w: 110,
		h: 110
	},
	{
		x: 308,
		y: 286,
		w: 110,
		h: 110
	},
	{
		x: 302,
		y: 418,
		w: 110,
		h: 110
	},
	{
		x: 293,
		y: 580,
		w: 130,
		h: 130
	},
	{
		x: 1875,
		y: 138,
		w: 110,
		h: 110
	},
	{
		x: 1880,
		y: 286,
		w: 110,
		h: 110
	},
	{
		x: 1880,
		y: 418,
		w: 110,
		h: 110
	},
	{
		x: 1870,
		y: 580,
		w: 130,
		h: 130
	},
	{
		x: 308,
		y: 852,
		w: 110,
		h: 110
	},
	{
		x: 316,
		y: 997,
		w: 110,
		h: 110
	},
	{
		x: 315,
		y: 1136,
		w: 110,
		h: 110
	},
	{
		x: 306,
		y: 1306,
		w: 130,
		h: 130
	},
	{
		x: 1880,
		y: 852,
		w: 110,
		h: 110
	},
	{
		x: 1880,
		y: 992,
		w: 110,
		h: 110
	},
	{
		x: 1880,
		y: 1134,
		w: 110,
		h: 110
	},
	{
		x: 1881,
		y: 1291,
		w: 130,
		h: 130
	}
], Xa = [
	{
		x: 132,
		y: 267,
		w: 70,
		h: 70
	},
	{
		x: 151,
		y: 336,
		w: 70,
		h: 70
	},
	{
		x: 2085,
		y: 261,
		w: 70,
		h: 70
	},
	{
		x: 2063,
		y: 331,
		w: 70,
		h: 70
	},
	{
		x: 132,
		y: 974,
		w: 70,
		h: 70
	},
	{
		x: 151,
		y: 1037,
		w: 70,
		h: 70
	},
	{
		x: 2085,
		y: 962,
		w: 70,
		h: 70
	},
	{
		x: 2063,
		y: 1033,
		w: 70,
		h: 70
	}
], Za = [
	{
		x: 364,
		y: 1691,
		w: 60,
		h: 60,
		pitch: 70,
		count: 1
	},
	{
		x: 364,
		y: 1761,
		w: 60,
		h: 60,
		pitch: 70,
		count: 1
	},
	{
		x: 364,
		y: 1831,
		w: 60,
		h: 60,
		pitch: 70,
		count: 1
	},
	{
		x: 364,
		y: 1901,
		w: 60,
		h: 60,
		pitch: 70,
		count: 1
	}
], Qa = [
	{
		x: 575,
		y: 1691,
		w: 60,
		h: 60,
		pitch: 70,
		count: 1
	},
	{
		x: 575,
		y: 1761,
		w: 60,
		h: 60,
		pitch: 70,
		count: 1
	},
	{
		x: 575,
		y: 1831,
		w: 60,
		h: 60,
		pitch: 70,
		count: 1
	},
	{
		x: 575,
		y: 1901,
		w: 60,
		h: 60,
		pitch: 70,
		count: 1
	}
], $a = [
	{
		x: 785,
		y: 1691,
		w: 60,
		h: 60,
		pitch: 70,
		count: 1
	},
	{
		x: 785,
		y: 1761,
		w: 60,
		h: 60,
		pitch: 70,
		count: 1
	},
	{
		x: 785,
		y: 1831,
		w: 60,
		h: 60,
		pitch: 70,
		count: 1
	},
	{
		x: 785,
		y: 1901,
		w: 60,
		h: 60,
		pitch: 70,
		count: 1
	}
], eo = [
	{
		x: 357,
		y: 2032,
		w: 78,
		h: 59
	},
	{
		x: 569,
		y: 2032,
		w: 78,
		h: 59
	},
	{
		x: 779,
		y: 2032,
		w: 78,
		h: 59
	}
], to = [
	{
		x: 148,
		y: 1700,
		w: 92,
		h: 105
	},
	{
		x: 148,
		y: 1839,
		w: 92,
		h: 105
	},
	{
		x: 148,
		y: 1978,
		w: 92,
		h: 105
	}
], no = [
	{
		x: 1330,
		y: 1709,
		w: 46,
		h: 46,
		pitch: 68,
		count: 3
	},
	{
		x: 1330,
		y: 1799,
		w: 46,
		h: 46,
		pitch: 68,
		count: 3
	},
	{
		x: 1330,
		y: 1895,
		w: 46,
		h: 46,
		pitch: 68,
		count: 3
	}
].flatMap((e) => f(e)), ro = [
	{
		x: 1601,
		y: 1736,
		w: 62,
		h: 68,
		pitch: 70,
		count: 2
	},
	{
		x: 1601,
		y: 1813,
		w: 62,
		h: 68,
		pitch: 70,
		count: 2
	},
	{
		x: 1601,
		y: 1891,
		w: 62,
		h: 68,
		pitch: 70,
		count: 2
	},
	{
		x: 1601,
		y: 1964,
		w: 62,
		h: 68,
		pitch: 70,
		count: 2
	},
	{
		x: 1601,
		y: 2036,
		w: 62,
		h: 68,
		pitch: 70,
		count: 2
	}
].flatMap((e) => f(e)), io = [
	{
		x: 1850,
		y: 1741,
		w: 64,
		h: 64
	},
	{
		x: 1850,
		y: 1840,
		w: 64,
		h: 64
	},
	{
		x: 1850,
		y: 1943,
		w: 64,
		h: 64
	},
	{
		x: 1850,
		y: 2038,
		w: 64,
		h: 64
	}
];
function ao(e) {
	let [t, n] = ge(e), r = Ka[t], i = Ka[n], a = (r.x + r.w / 2 + i.x + i.w / 2) / 2, o = (r.y + r.h / 2 + i.y + i.h / 2) / 2;
	return {
		x: a - 28,
		y: o - 28,
		w: 56,
		h: 56
	};
}
if (Array.from({ length: 36 }, (e, t) => ({
	id: `c${t}`,
	comment: `r${Math.floor(t / 6)}c${t % 6}`
})), Array.from({ length: 16 }, (e, t) => ({
	id: `d${t}`,
	comment: t < 13 ? `碟${t}` : `天文台碟${t - 13}`
})), de.map((e) => ({
	id: `c${e}`,
	comment: `cell${e}`
})), Array.from({ length: 16 }, (e, t) => ({
	id: `g${t}`,
	comment: `Q${Math.floor(t / 4) + 1} 温室${t % 4}${t % 4 == 3 ? "(2植物)" : ""}`
})), Array.from({ length: 8 }, (e, t) => ({
	id: `q${t}`,
	comment: `Q${Math.floor(t / 2) + 1} ${t % 2 == 0 ? "15" : "5"}`
})), [
	0,
	1,
	2,
	3
].map((e) => ({
	id: `p${e}`,
	comment: `植物${e}`
})), [
	0,
	2,
	4,
	6
].map((e) => ({
	id: `w${e}`,
	comment: `水${e}`
})), [
	0,
	1,
	2,
	4
].map((e) => ({
	id: `a${e}`,
	comment: `天线${e}`
})), Ka.length !== 36) throw Error("cell rects mismatch");
if (qa.length !== 16) throw Error("dish rects mismatch");
if (Ja.length !== de.length) throw Error("tank rects mismatch");
if (io.length !== 4) throw Error("error rects mismatch");
if (ro.length !== 10) throw Error("planning rects mismatch");
//#endregion
//#region src/games/moon/adv/adv2-layout.ts
var oo = 2315, so = 2315, co = [
	{
		x: 455.4,
		y: 1377.2,
		w: 86,
		h: 86
	},
	{
		x: 618.5,
		y: 1313,
		w: 86,
		h: 86
	},
	{
		x: 745.1,
		y: 1368.1,
		w: 86,
		h: 86
	},
	{
		x: 881,
		y: 1431.6,
		w: 86,
		h: 86
	},
	{
		x: 978.1,
		y: 1544.2,
		w: 86,
		h: 86
	},
	{
		x: 1003.9,
		y: 1726.2,
		w: 86,
		h: 86
	},
	{
		x: 963.9,
		y: 1891.6,
		w: 86,
		h: 86
	},
	{
		x: 837.9,
		y: 2002.7,
		w: 86,
		h: 86
	},
	{
		x: 682.9,
		y: 2049.9,
		w: 86,
		h: 86
	},
	{
		x: 536.2,
		y: 2053.1,
		w: 86,
		h: 86
	},
	{
		x: 389.2,
		y: 2001.5,
		w: 86,
		h: 86
	},
	{
		x: 242,
		y: 1925.9,
		w: 86,
		h: 86
	},
	{
		x: 156.1,
		y: 1801.9,
		w: 86,
		h: 86
	},
	{
		x: 116.2,
		y: 1665.6,
		w: 86,
		h: 86
	},
	{
		x: 116.2,
		y: 1488.2,
		w: 86,
		h: 86
	},
	{
		x: 147.1,
		y: 1348,
		w: 86,
		h: 86
	},
	{
		x: 210,
		y: 1232.7,
		w: 86,
		h: 86
	},
	{
		x: 313,
		y: 1123,
		w: 86,
		h: 86
	},
	{
		x: 444,
		y: 1047,
		w: 86,
		h: 86
	},
	{
		x: 580.9,
		y: 1011.7,
		w: 86,
		h: 86
	},
	{
		x: 732.8,
		y: 975.9,
		w: 86,
		h: 86
	},
	{
		x: 887,
		y: 929.6,
		w: 86,
		h: 86
	},
	{
		x: 1037.9,
		y: 879.1,
		w: 86,
		h: 86
	},
	{
		x: 1188.8,
		y: 837.6,
		w: 86,
		h: 86
	},
	{
		x: 1339.6,
		y: 787.2,
		w: 86,
		h: 86
	},
	{
		x: 1497,
		y: 726,
		w: 86,
		h: 86
	},
	{
		x: 1625.5,
		y: 684.2,
		w: 86,
		h: 86
	},
	{
		x: 1760.5,
		y: 627.5,
		w: 86,
		h: 86
	},
	{
		x: 1873.7,
		y: 552.8,
		w: 86,
		h: 86
	},
	{
		x: 1936.5,
		y: 416.2,
		w: 86,
		h: 86
	},
	{
		x: 1919.5,
		y: 232.5,
		w: 86,
		h: 86
	},
	{
		x: 1789,
		y: 138,
		w: 86,
		h: 86
	},
	{
		x: 1630.8,
		y: 143.7,
		w: 86,
		h: 86
	},
	{
		x: 1512,
		y: 233,
		w: 86,
		h: 86
	},
	{
		x: 1523.7,
		y: 407,
		w: 86,
		h: 86
	},
	{
		x: 1681.7,
		y: 461.3,
		w: 86,
		h: 86
	}
], lo = [
	{
		x: 616.2,
		y: 1195.3,
		w: 95,
		h: 80
	},
	{
		x: 1032.8,
		y: 1491,
		w: 95,
		h: 80
	},
	{
		x: 989.5,
		y: 1971.9,
		w: 95,
		h: 80
	},
	{
		x: 335.6,
		y: 2072.6,
		w: 95,
		h: 80
	},
	{
		x: 179,
		y: 1619.7,
		w: 95,
		h: 80
	},
	{
		x: 348.5,
		y: 1205.9,
		w: 95,
		h: 80
	},
	{
		x: 477.6,
		y: 1130.7,
		w: 95,
		h: 80
	},
	{
		x: 1055.6,
		y: 964.9,
		w: 95,
		h: 80
	},
	{
		x: 1505.4,
		y: 808.5,
		w: 95,
		h: 80
	},
	{
		x: 1870,
		y: 399,
		w: 64.6,
		h: 77.8
	},
	{
		x: 1845.7,
		y: 86,
		w: 95,
		h: 80
	},
	{
		x: 1498.5,
		y: 478.5,
		w: 95,
		h: 80
	}
], uo = [{
	x: 362,
	y: 97,
	w: 79.9,
	h: 76,
	pitch: 123,
	count: 6
}, {
	x: 362,
	y: 187,
	w: 75.5,
	h: 76,
	pitch: 123,
	count: 6
}].flatMap((e) => f(e)), fo = [{
	x: 383.7,
	y: 352,
	w: 32.2,
	h: 93.4,
	pitch: 123,
	count: 6
}].flatMap((e) => f(e)), po = [{
	x: 1711.3,
	y: 1233.9,
	w: 62,
	h: 62,
	pitch: 75,
	count: 3
}, {
	x: 1711.3,
	y: 1310.1,
	w: 62,
	h: 62,
	pitch: 75,
	count: 3
}].flatMap((e) => f(e)), mo = [{
	x: 1702,
	y: 1470.4,
	w: 72,
	h: 72,
	pitch: 75,
	count: 3
}], ho = [{
	x: 1987.6,
	y: 1224.4,
	w: 66,
	h: 74,
	pitch: 75,
	count: 3
}, {
	x: 1989.8,
	y: 1302,
	w: 66,
	h: 74,
	pitch: 75,
	count: 3
}].flatMap((e) => f(e)), go = [{
	x: 1988.9,
	y: 1470.4,
	w: 72,
	h: 72,
	pitch: 75,
	count: 3
}], _o = [
	{
		x: 1964,
		y: 1753.7,
		w: 70,
		h: 80
	},
	{
		x: 1968.3,
		y: 1855,
		w: 70,
		h: 80
	},
	{
		x: 1965.5,
		y: 1965,
		w: 70,
		h: 80
	},
	{
		x: 1970,
		y: 2067,
		w: 70,
		h: 80
	}
], vo = [
	{
		x: 1332.8,
		y: 1798.1,
		w: 76,
		h: 62
	},
	{
		x: 1332.8,
		y: 1883.1,
		w: 76,
		h: 62
	},
	{
		x: 1332.8,
		y: 1973.1,
		w: 76,
		h: 62
	},
	{
		x: 1332.8,
		y: 2053.1,
		w: 76,
		h: 62
	}
], yo = [
	{
		x: 1146.8,
		y: 1775.3,
		w: 104,
		h: 112
	},
	{
		x: 1144.7,
		y: 1891.7,
		w: 104,
		h: 112
	},
	{
		x: 1146.8,
		y: 2014.6,
		w: 104,
		h: 112
	}
], bo = [
	{
		x: 188.5,
		y: 994.1,
		w: 70,
		h: 70
	},
	{
		x: 105,
		y: 1124.1,
		w: 70,
		h: 70
	},
	{
		x: 100,
		y: 1277.7,
		w: 70,
		h: 70
	},
	{
		x: 924.3,
		y: 620.3,
		w: 70,
		h: 70
	},
	{
		x: 784.5,
		y: 714.2,
		w: 70,
		h: 70
	},
	{
		x: 743,
		y: 876.5,
		w: 70,
		h: 70
	},
	{
		x: 2020,
		y: 235,
		w: 70,
		h: 70
	},
	{
		x: 2100,
		y: 365,
		w: 70,
		h: 70
	},
	{
		x: 2120,
		y: 505,
		w: 70,
		h: 70
	},
	{
		x: 2080,
		y: 650,
		w: 70,
		h: 70
	},
	{
		x: 1178.6,
		y: 1542,
		w: 70,
		h: 70
	},
	{
		x: 1080,
		y: 1647.7,
		w: 70,
		h: 70
	}
], xo = [
	{
		x: 332,
		y: 625,
		w: 56,
		h: 56
	},
	{
		x: 465.5,
		y: 706.5,
		w: 56,
		h: 56
	},
	{
		x: 337.7,
		y: 784.8,
		w: 56,
		h: 56
	},
	{
		x: 1192,
		y: 392,
		w: 56,
		h: 56
	},
	{
		x: 1059,
		y: 462,
		w: 56,
		h: 56
	},
	{
		x: 1212,
		y: 537,
		w: 56,
		h: 56
	},
	{
		x: 1087,
		y: 577,
		w: 56,
		h: 56
	},
	{
		x: 1757,
		y: 862,
		w: 56,
		h: 56
	},
	{
		x: 1957,
		y: 904,
		w: 56,
		h: 56
	},
	{
		x: 1822,
		y: 962,
		w: 56,
		h: 56
	},
	{
		x: 1944,
		y: 992,
		w: 56,
		h: 56
	},
	{
		x: 1377,
		y: 1170.9,
		w: 56,
		h: 56
	},
	{
		x: 1460.5,
		y: 1229.4,
		w: 56,
		h: 56
	},
	{
		x: 1381.2,
		y: 1332.8,
		w: 56,
		h: 56
	},
	{
		x: 1245.1,
		y: 1262.3,
		w: 56,
		h: 56
	}
], So = [
	{
		x: 140,
		y: 790,
		w: 110,
		h: 135
	},
	{
		x: 1005,
		y: 655,
		w: 100,
		h: 140
	},
	{
		x: 2030,
		y: 775,
		w: 115,
		h: 150
	},
	{
		x: 1280,
		y: 1420,
		w: 110,
		h: 145
	}
], Co = (() => {
	let e = [], t = 0;
	for (let n of J) e.push(bo.slice(t, t + n.robots)), t += n.robots;
	return e;
})(), wo = (() => {
	let e = [], t = 0;
	for (let n of J) e.push(xo.slice(t, t + n.plants)), t += n.plants;
	return e;
})();
function To(e) {
	let t = co[e], n = co[e + 1], r = (t.x + t.w / 2 + n.x + n.w / 2) / 2, i = (t.y + t.h / 2 + n.y + n.h / 2) / 2;
	return {
		x: r - 22,
		y: i - 22,
		w: 44,
		h: 44
	};
}
if (Array.from({ length: 36 }, (e, t) => ({
	id: `p${t}`,
	comment: `p${t}`
})), hn.map((e) => ({
	id: `p${e.cell}`,
	comment: `p${e.cell} 值${e.value}`
})), J.flatMap((e, t) => Array.from({ length: e.robots }, (e, n) => ({
	id: `s${t}r${n}`,
	comment: `站${t} 机器人${n}`
}))), J.flatMap((e, t) => Array.from({ length: e.plants }, (e, n) => ({
	id: `s${t}p${n}`,
	comment: `站${t} 植物${n}`
}))), co.length !== 36) throw Error("cell rects mismatch");
if (lo.length !== hn.length) throw Error("tank rects mismatch");
if (_o.length !== 4) throw Error("error rects mismatch");
if (bo.length !== J.reduce((e, t) => e + t.robots, 0)) throw Error("robot rects mismatch");
if (xo.length !== J.reduce((e, t) => e + t.plants, 0)) throw Error("plant rects mismatch");
if (uo.length !== 12 || fo.length !== 6) throw Error("energy layout mismatch");
//#endregion
//#region src/games/moon/sheet-view.tsx
function Q({ r: e, shade: t = "var(--color-ink)" }) {
	return /* @__PURE__ */ g(p, {
		mark: "x",
		rect: e,
		color: t
	});
}
var Eo = Ia.flatMap((e) => Array.from({ length: e.count }, () => e.mark)), Do = Ra.flatMap((e) => Array.from({ length: e.count }, () => e.mark)), Oo = Ba.flatMap((e) => Array.from({ length: e.count }, () => e.mark));
function ko({ sheet: e, claims: t, pickCells: n, buildMode: i, activateTargets: a, onTapCell: o, onTapRocket: s, readOnly: c, fitKey: l, pulse: u, focus: d }) {
	let f = r(() => {
		if (!c) return i ? Pa.map((e, t) => ({
			key: `c${t}`,
			rect: e
		})).filter((t, n) => e.cells[n] === null) : a ? a.map((e) => ({
			key: `r${e}`,
			rect: Fa[e]
		})) : n?.map((e) => ({
			key: `c${e}`,
			rect: Pa[e]
		}));
	}, [
		c,
		i,
		a,
		n,
		e.cells
	]), h = r(() => {
		if (o || s) return (e) => {
			e[0] === "c" ? o?.(Number(e.slice(1))) : s?.(Number(e.slice(1)));
		};
	}, [o, s]), v = Ha[R(e.track)];
	return /* @__PURE__ */ _(ee, {
		image: "games/moon/sheet.webp",
		sheetW: Ma,
		sheetH: Na,
		eligible: f,
		onTapEligible: h,
		readOnly: c,
		fitKey: l,
		focus: d,
		children: [
			e.cells.map((e, t) => e === null ? null : e === "x" ? /* @__PURE__ */ g(Q, { r: Pa[t] }, t) : /* @__PURE__ */ g(m, {
				r: Pa[t],
				text: String(e)
			}, t)),
			e.activated.map((e, t) => e && /* @__PURE__ */ g("rect", {
				x: Fa[t].x - 5,
				y: Fa[t].y - 5,
				width: Fa[t].w + 10,
				height: Fa[t].h + 10,
				rx: 12,
				fill: "#f59e0b",
				fillOpacity: .25,
				stroke: "#f59e0b",
				strokeWidth: 6,
				pointerEvents: "none"
			}, `act${t}`)),
			La.map((t, n) => n >= e.circled ? null : /* @__PURE__ */ _("g", {
				pointerEvents: "none",
				children: [/* @__PURE__ */ g(p, {
					mark: Eo[n] ?? "circle",
					rect: t,
					inset: -.05
				}), n < e.cleared && /* @__PURE__ */ g(Q, {
					r: t,
					shade: "#059669"
				})]
			}, `err${n}`)),
			za.slice(0, e.track).map((e, t) => /* @__PURE__ */ g(p, {
				mark: Do[t] ?? "x",
				rect: e
			}, `tr${t}`)),
			Va.slice(0, e.bonus).map((e, t) => /* @__PURE__ */ g(p, {
				mark: Oo[t] ?? "x",
				rect: e
			}, `bn${t}`)),
			/* @__PURE__ */ g("rect", {
				x: v.x - 5,
				y: v.y - 5,
				width: v.w + 10,
				height: v.h + 10,
				rx: 12,
				fill: "none",
				stroke: "#ffffff",
				strokeWidth: 9,
				pointerEvents: "none"
			}),
			/* @__PURE__ */ g("rect", {
				x: v.x - 5,
				y: v.y - 5,
				width: v.w + 10,
				height: v.h + 10,
				rx: 12,
				fill: "none",
				stroke: "var(--color-ink)",
				strokeWidth: 4,
				pointerEvents: "none"
			}),
			Ua.map((e, n) => {
				let r = t[n];
				return /* @__PURE__ */ _("g", {
					pointerEvents: "none",
					children: [/* @__PURE__ */ g(m, {
						r: e,
						text: "ABC"[n]
					}), r && /* @__PURE__ */ g("rect", {
						x: e.x - 5,
						y: e.y - 5,
						width: e.w + 10,
						height: e.h + 10,
						rx: 16,
						fill: "none",
						stroke: r === "high" ? "#059669" : "#0284c7",
						strokeWidth: 7
					})]
				}, `ms${n}`);
			}),
			u?.rects.map((e, t) => /* @__PURE__ */ g("rect", {
				x: e.x - 12,
				y: e.y - 12,
				width: e.w + 24,
				height: e.h + 24,
				rx: 20,
				fill: "none",
				stroke: "#f59e0b",
				strokeWidth: 10,
				strokeOpacity: 0,
				pointerEvents: "none",
				children: /* @__PURE__ */ g("animate", {
					attributeName: "stroke-opacity",
					values: "0.95;0.1;0.95;0.1;0.95",
					keyTimes: "0;0.25;0.5;0.75;1",
					dur: "1.3s",
					begin: `${t * .12}s`,
					repeatCount: "1"
				})
			}, `${u.key}:${t}`))
		]
	});
}
//#endregion
//#region src/games/moon/sheet-view2.tsx
var Ao = Array.from({ length: 12 }, (e, t) => t % 2 == 0 ? uo[t / 2] : uo[6 + (t - 1) / 2]), jo = f(mo[0]), Mo = f(go[0]);
function No({ r: e, shade: t = "var(--color-ink)" }) {
	return /* @__PURE__ */ g("ellipse", {
		cx: e.x + e.w / 2,
		cy: e.y + e.h / 2,
		rx: e.w / 2 + 8,
		ry: e.h / 2 + 8,
		fill: "none",
		stroke: t,
		strokeWidth: Math.min(e.w, e.h) * .12,
		pointerEvents: "none"
	});
}
function Po(e) {
	let t = Math.min(...e.map((e) => e.x)), n = Math.min(...e.map((e) => e.y));
	return {
		x: t,
		y: n,
		w: Math.max(...e.map((e) => e.x + e.w)) - t,
		h: Math.max(...e.map((e) => e.y + e.h)) - n
	};
}
function Fo({ sheet: e, missions: t, claims: n, mode: i, onTapCell: a, onTapStation: o, onTapGap: s, readOnly: c, fitKey: l, pulse: u, focus: d }) {
	let f = r(() => {
		if (!c && i) switch (i.kind) {
			case "pick": return i.cells.map((e) => ({
				key: `c${e}`,
				rect: co[e]
			}));
			case "planX": return co.map((e, t) => ({
				key: `c${t}`,
				rect: e
			})).filter((t, n) => e.cells[n] === null);
			case "robot": return i.stations.map((e) => ({
				key: `s${e}`,
				rect: Po(Co[e])
			}));
			case "plant": return i.stations.map((e) => ({
				key: `s${e}`,
				rect: Po(wo[e])
			}));
			case "split": return e.splits.flatMap((e, t) => e ? [] : [{
				key: `g${t}`,
				rect: To(t)
			}]);
		}
	}, [
		c,
		i,
		e.cells,
		e.splits
	]), p = r(() => {
		if (a || o || s) return (e) => {
			let t = Number(e.slice(1));
			e[0] === "c" ? a?.(t) : e[0] === "s" ? o?.(t) : s?.(t);
		};
	}, [
		a,
		o,
		s
	]), h = e.energyPairs * 2 + +!!e.energyPending, v = e.splits.reduce((e, t) => e + +!!t, 0), y = [...jo.slice(0, Math.floor(e.astronauts / 2)), ...Mo.slice(0, Math.floor(e.plannings / 2))];
	return /* @__PURE__ */ _(ee, {
		image: "games/moon/sheet2.webp",
		sheetW: oo,
		sheetH: so,
		eligible: f,
		onTapEligible: p,
		readOnly: c,
		fitKey: l,
		focus: d,
		children: [
			e.cells.map((e, t) => e === null ? null : e === "x" ? /* @__PURE__ */ g(Q, { r: co[t] }, t) : /* @__PURE__ */ g(m, {
				r: co[t],
				text: String(e)
			}, t)),
			e.splits.map((e, t) => {
				if (!e) return null;
				let n = co[t], r = co[t + 1], i = n.x + n.w / 2, a = n.y + n.h / 2, o = r.x + r.w / 2, s = r.y + r.h / 2, c = (i + o) / 2, l = (a + s) / 2, u = Math.hypot(o - i, s - a) || 1, d = -(s - a) / u * 30, f = (o - i) / u * 30;
				return /* @__PURE__ */ _("g", {
					pointerEvents: "none",
					strokeLinecap: "round",
					children: [/* @__PURE__ */ g("line", {
						x1: c - d,
						y1: l - f,
						x2: c + d,
						y2: l + f,
						stroke: "#ffffff",
						strokeWidth: 18
					}), /* @__PURE__ */ g("line", {
						x1: c - d,
						y1: l - f,
						x2: c + d,
						y2: l + f,
						stroke: "var(--color-ink)",
						strokeWidth: 9
					})]
				}, `sp${t}`);
			}),
			e.tanks.map((e, t) => e && /* @__PURE__ */ g(No, { r: lo[t] }, `tk${t}`)),
			Ao.slice(0, h).map((t, n) => /* @__PURE__ */ _("g", {
				pointerEvents: "none",
				children: [/* @__PURE__ */ g(No, { r: t }), n < e.energyPairs * 2 && /* @__PURE__ */ g(Q, { r: t })]
			}, `en${n}`)),
			fo.slice(0, v).map((e, t) => /* @__PURE__ */ g(Q, { r: e }, `bar${t}`)),
			po.slice(0, e.astronauts).map((e, t) => /* @__PURE__ */ g(Q, { r: e }, `as${t}`)),
			ho.slice(0, e.plannings).map((e, t) => /* @__PURE__ */ g(Q, { r: e }, `pl${t}`)),
			y.map((t, n) => /* @__PURE__ */ _("g", {
				pointerEvents: "none",
				children: [/* @__PURE__ */ g(No, { r: t }), n < e.wildsUsed && /* @__PURE__ */ g(Q, { r: t })]
			}, `ge${n}`)),
			e.stations.map((e, t) => /* @__PURE__ */ _("g", {
				pointerEvents: "none",
				children: [
					Co[t].slice(0, e.robots).map((e, t) => /* @__PURE__ */ g(No, { r: e }, `r${t}`)),
					wo[t].slice(0, e.plants).map((e, t) => /* @__PURE__ */ g(No, { r: e }, `p${t}`)),
					e.mult && /* @__PURE__ */ g("ellipse", {
						cx: So[t].x + So[t].w / 2,
						cy: So[t].y + So[t].h * (e.mult === "high" ? .25 : .75),
						rx: So[t].w * .48,
						ry: So[t].h * .22,
						fill: "none",
						stroke: "var(--color-ink)",
						strokeWidth: 8
					})
				]
			}, `st${t}`)),
			e.stations.map((e, t) => {
				if (!e.mult) return null;
				let n = e.mult === "high" ? J[t].hi : J[t].lo;
				return /* @__PURE__ */ g(m, {
					r: vo[t],
					text: String(e.plants * n)
				}, `pr${t}`);
			}),
			_o.slice(0, e.errors).map((e, t) => /* @__PURE__ */ g("ellipse", {
				cx: e.x + e.w / 2,
				cy: e.y + e.h / 2,
				rx: e.w / 2 + 8,
				ry: e.h / 2 + 8,
				fill: "none",
				stroke: "#dc2626",
				strokeWidth: 7,
				pointerEvents: "none"
			}, `er${t}`)),
			yo.map((e, r) => {
				let i = n[r];
				if (!i) return null;
				let a = En[t[r]];
				return /* @__PURE__ */ _("g", {
					pointerEvents: "none",
					children: [/* @__PURE__ */ g("rect", {
						x: e.x - 5,
						y: e.y - 5,
						width: e.w + 10,
						height: e.h + 10,
						rx: 16,
						fill: "none",
						stroke: i === "high" ? "#059669" : "#0284c7",
						strokeWidth: 7
					}), /* @__PURE__ */ g(m, {
						r: e,
						text: String(i === "high" ? a.hi : a.lo)
					})]
				}, `ms${r}`);
			}),
			u?.rects.map((e, t) => /* @__PURE__ */ g("rect", {
				x: e.x - 12,
				y: e.y - 12,
				width: e.w + 24,
				height: e.h + 24,
				rx: 20,
				fill: "none",
				stroke: "#f59e0b",
				strokeWidth: 10,
				strokeOpacity: 0,
				pointerEvents: "none",
				children: /* @__PURE__ */ g("animate", {
					attributeName: "stroke-opacity",
					values: "0.95;0.1;0.95;0.1;0.95",
					keyTimes: "0;0.25;0.5;0.75;1",
					dur: "1.3s",
					begin: `${t * .12}s`,
					repeatCount: "1"
				})
			}, `${u.key}:${t}`))
		]
	});
}
//#endregion
//#region src/games/moon/sheet-view3.tsx
var Io = /* @__PURE__ */ new Set([
	5,
	30,
	...se
]), Lo = [
	Za,
	Qa,
	$a
].map((e) => e.flatMap((e) => f(e)));
function Ro({ r: e, shade: t = "var(--color-ink)" }) {
	return /* @__PURE__ */ g("ellipse", {
		cx: e.x + e.w / 2,
		cy: e.y + e.h / 2,
		rx: e.w / 2 + 8,
		ry: e.h / 2 + 8,
		fill: "none",
		stroke: t,
		strokeWidth: Math.min(e.w, e.h) * .12,
		pointerEvents: "none"
	});
}
function zo(e) {
	let t = Math.min(...e.map((e) => e.x)), n = Math.min(...e.map((e) => e.y));
	return {
		x: t,
		y: n,
		w: Math.max(...e.map((e) => e.x + e.w)) - t,
		h: Math.max(...e.map((e) => e.y + e.h)) - n
	};
}
function Bo({ sheet: e, missions: t, claims: n, quarterLevels: i, mode: a, onTapCell: o, onTapTunnel: s, onTapTrack: c, readOnly: l, fitKey: u, pulse: d, focus: f }) {
	let p = r(() => {
		if (!l && a) switch (a.kind) {
			case "pick": return a.cells.map((e) => ({
				key: `c${e}`,
				rect: Ka[e]
			}));
			case "planX": return Ka.map((e, t) => ({
				key: `c${t}`,
				rect: e
			})).filter((t, n) => e.cells[n] === null);
			case "tunnel": return a.edges.map((e) => ({
				key: `t${e}`,
				rect: ao(e)
			}));
			case "energy": return a.tracks.map((e) => ({
				key: `e${e}`,
				rect: zo([...Lo[e], eo[e]])
			}));
		}
	}, [
		l,
		a,
		e.cells
	]), h = r(() => {
		if (o || s || c) return (e) => {
			let t = Number(e.slice(1));
			e[0] === "c" ? o?.(t) : e[0] === "t" ? s?.(t) : c?.(t);
		};
	}, [
		o,
		s,
		c
	]);
	return /* @__PURE__ */ _(ee, {
		image: "games/moon/sheet3.webp",
		sheetW: Wa,
		sheetH: Ga,
		eligible: p,
		onTapEligible: h,
		readOnly: l,
		fitKey: u,
		focus: f,
		children: [
			e.tunnels.map((e, t) => {
				if (!e) return null;
				let [n, r] = ge(t), i = Ka[n], a = Ka[r], o = i.x + i.w / 2, s = i.y + i.h / 2, c = a.x + a.w / 2, l = a.y + a.h / 2;
				return /* @__PURE__ */ _("g", {
					pointerEvents: "none",
					strokeLinecap: "round",
					children: [/* @__PURE__ */ g("line", {
						x1: o,
						y1: s,
						x2: c,
						y2: l,
						stroke: "#ffffff",
						strokeWidth: 22
					}), /* @__PURE__ */ g("line", {
						x1: o,
						y1: s,
						x2: c,
						y2: l,
						stroke: "var(--color-ink)",
						strokeWidth: 11
					})]
				}, `tn${t}`);
			}),
			e.cells.map((e, t) => e === null || Io.has(t) ? null : e === "x" ? /* @__PURE__ */ g(Q, { r: Ka[t] }, t) : /* @__PURE__ */ g(m, {
				r: Ka[t],
				text: String(e)
			}, t)),
			e.antennas.map((e, t) => e && /* @__PURE__ */ g(Ro, { r: qa[t] }, `ds${t}`)),
			e.tanks.map((e, t) => e && /* @__PURE__ */ g(Ro, { r: Ja[t] }, `tk${t}`)),
			e.greenhouses.map((e, t) => e && /* @__PURE__ */ g(Ro, { r: Ya[t] }, `gh${t}`)),
			Lo.map((t, n) => {
				let r = n === 0 ? e.trackPlant : n === 1 ? e.trackWater : e.trackAntenna;
				return t.slice(0, r).map((e, t) => /* @__PURE__ */ g(Q, { r: e }, `tr${n}:${t}`));
			}),
			no.slice(0, e.astronauts).map((e, t) => /* @__PURE__ */ g(Q, { r: e }, `as${t}`)),
			ro.slice(0, e.planning).map((e, t) => /* @__PURE__ */ g(Q, { r: e }, `pl${t}`)),
			i.map((e, t) => e ? /* @__PURE__ */ g(Ro, { r: Xa[t * 2 + (e === "high" ? 0 : 1)] }, `qb${t}`) : null),
			io.slice(0, e.errors).map((e, t) => /* @__PURE__ */ g("ellipse", {
				cx: e.x + e.w / 2,
				cy: e.y + e.h / 2,
				rx: e.w / 2 + 8,
				ry: e.h / 2 + 8,
				fill: "none",
				stroke: "#dc2626",
				strokeWidth: 7,
				pointerEvents: "none"
			}, `er${t}`)),
			to.map((e, r) => {
				let i = n[r];
				if (!i) return null;
				let a = ke[t[r]];
				return /* @__PURE__ */ _("g", {
					pointerEvents: "none",
					children: [/* @__PURE__ */ g("rect", {
						x: e.x - 5,
						y: e.y - 5,
						width: e.w + 10,
						height: e.h + 10,
						rx: 16,
						fill: "none",
						stroke: i === "high" ? "#059669" : "#0284c7",
						strokeWidth: 7
					}), /* @__PURE__ */ g(m, {
						r: e,
						text: String(i === "high" ? a.hi : a.lo)
					})]
				}, `ms${r}`);
			}),
			d?.rects.map((e, t) => /* @__PURE__ */ g("rect", {
				x: e.x - 12,
				y: e.y - 12,
				width: e.w + 24,
				height: e.h + 24,
				rx: 20,
				fill: "none",
				stroke: "#f59e0b",
				strokeWidth: 10,
				strokeOpacity: 0,
				pointerEvents: "none",
				children: /* @__PURE__ */ g("animate", {
					attributeName: "stroke-opacity",
					values: "0.95;0.1;0.95;0.1;0.95",
					keyTimes: "0;0.25;0.5;0.75;1",
					dur: "1.3s",
					begin: `${t * .12}s`,
					repeatCount: "1"
				})
			}, `${d.key}:${t}`))
		]
	});
}
//#endregion
//#region src/games/moon/adv/adv4-layout.ts
var Vo = 2315, Ho = 2315, Uo = [
	{
		x: 82,
		y: 1560,
		w: 150,
		h: 170
	},
	{
		x: 265,
		y: 1560,
		w: 150,
		h: 170
	},
	{
		x: 444,
		y: 1560,
		w: 150,
		h: 170
	},
	{
		x: 626,
		y: 1560,
		w: 150,
		h: 170
	},
	{
		x: 794,
		y: 1560,
		w: 150,
		h: 170
	},
	{
		x: 973,
		y: 1560,
		w: 150,
		h: 170
	},
	{
		x: 1154,
		y: 1560,
		w: 150,
		h: 170
	},
	{
		x: 1334,
		y: 1560,
		w: 150,
		h: 170
	},
	{
		x: 1514,
		y: 1560,
		w: 150,
		h: 170
	},
	{
		x: 1693,
		y: 1560,
		w: 150,
		h: 170
	},
	{
		x: 1878,
		y: 1560,
		w: 150,
		h: 170
	},
	{
		x: 2058,
		y: 1560,
		w: 150,
		h: 170
	},
	{
		x: 82,
		y: 1840,
		w: 150,
		h: 170
	},
	{
		x: 265,
		y: 1840,
		w: 150,
		h: 170
	},
	{
		x: 444,
		y: 1840,
		w: 150,
		h: 170
	},
	{
		x: 626,
		y: 1840,
		w: 150,
		h: 170
	},
	{
		x: 794,
		y: 1840,
		w: 150,
		h: 170
	},
	{
		x: 973,
		y: 1840,
		w: 150,
		h: 170
	},
	{
		x: 1154,
		y: 1840,
		w: 150,
		h: 170
	},
	{
		x: 1334,
		y: 1840,
		w: 150,
		h: 170
	},
	{
		x: 1514,
		y: 1840,
		w: 150,
		h: 170
	},
	{
		x: 1693,
		y: 1840,
		w: 150,
		h: 170
	},
	{
		x: 1878,
		y: 1840,
		w: 150,
		h: 170
	},
	{
		x: 2058,
		y: 1840,
		w: 150,
		h: 170
	},
	{
		x: 82,
		y: 2105,
		w: 150,
		h: 170
	},
	{
		x: 265,
		y: 2105,
		w: 150,
		h: 170
	},
	{
		x: 444,
		y: 2105,
		w: 150,
		h: 170
	},
	{
		x: 626,
		y: 2105,
		w: 150,
		h: 170
	},
	{
		x: 794,
		y: 2105,
		w: 150,
		h: 170
	},
	{
		x: 973,
		y: 2105,
		w: 150,
		h: 170
	},
	{
		x: 1154,
		y: 2105,
		w: 150,
		h: 170
	},
	{
		x: 1334,
		y: 2105,
		w: 150,
		h: 170
	},
	{
		x: 1514,
		y: 2105,
		w: 150,
		h: 170
	},
	{
		x: 1693,
		y: 2105,
		w: 150,
		h: 170
	},
	{
		x: 1878,
		y: 2105,
		w: 150,
		h: 170
	},
	{
		x: 2058,
		y: 2105,
		w: 150,
		h: 170
	}
], Wo = [
	{
		x: 112,
		y: 1740,
		w: 90,
		h: 90
	},
	{
		x: 295,
		y: 1740,
		w: 90,
		h: 90
	},
	{
		x: 474,
		y: 1740,
		w: 90,
		h: 90
	},
	{
		x: 656,
		y: 1740,
		w: 90,
		h: 90
	},
	{
		x: 824,
		y: 1740,
		w: 90,
		h: 90
	},
	{
		x: 1003,
		y: 1740,
		w: 90,
		h: 90
	},
	{
		x: 1184,
		y: 1740,
		w: 90,
		h: 90
	},
	{
		x: 1364,
		y: 1740,
		w: 90,
		h: 90
	},
	{
		x: 1544,
		y: 1740,
		w: 90,
		h: 90
	},
	{
		x: 1723,
		y: 1740,
		w: 90,
		h: 90
	},
	{
		x: 1908,
		y: 1740,
		w: 90,
		h: 90
	},
	{
		x: 2088,
		y: 1740,
		w: 90,
		h: 90
	},
	{
		x: 112,
		y: 2020,
		w: 90,
		h: 90
	},
	{
		x: 295,
		y: 2020,
		w: 90,
		h: 90
	},
	{
		x: 474,
		y: 2020,
		w: 90,
		h: 90
	},
	{
		x: 656,
		y: 2020,
		w: 90,
		h: 90
	},
	{
		x: 824,
		y: 2020,
		w: 90,
		h: 90
	},
	{
		x: 1003,
		y: 2020,
		w: 90,
		h: 90
	},
	{
		x: 1184,
		y: 2020,
		w: 90,
		h: 90
	},
	{
		x: 1364,
		y: 2020,
		w: 90,
		h: 90
	},
	{
		x: 1544,
		y: 2020,
		w: 90,
		h: 90
	},
	{
		x: 1723,
		y: 2020,
		w: 90,
		h: 90
	},
	{
		x: 1908,
		y: 2020,
		w: 90,
		h: 90
	},
	{
		x: 2088,
		y: 2020,
		w: 90,
		h: 90
	}
], Go = [
	{
		x: 102,
		y: 1385,
		w: 110,
		h: 100
	},
	{
		x: 285,
		y: 1385,
		w: 110,
		h: 100
	},
	{
		x: 464,
		y: 1385,
		w: 110,
		h: 100
	},
	{
		x: 646,
		y: 1385,
		w: 110,
		h: 100
	},
	{
		x: 814,
		y: 1385,
		w: 110,
		h: 100
	},
	{
		x: 993,
		y: 1385,
		w: 110,
		h: 100
	},
	{
		x: 1174,
		y: 1385,
		w: 110,
		h: 100
	},
	{
		x: 1354,
		y: 1385,
		w: 110,
		h: 100
	},
	{
		x: 1534,
		y: 1385,
		w: 110,
		h: 100
	},
	{
		x: 1713,
		y: 1385,
		w: 110,
		h: 100
	},
	{
		x: 1898,
		y: 1385,
		w: 110,
		h: 100
	},
	{
		x: 2078,
		y: 1385,
		w: 110,
		h: 100
	}
], Ko = [
	[
		{
			x: 295,
			y: 483,
			w: 64,
			h: 64
		},
		{
			x: 358,
			y: 510,
			w: 64,
			h: 64
		},
		{
			x: 295,
			y: 564,
			w: 64,
			h: 64
		},
		{
			x: 358,
			y: 593,
			w: 64,
			h: 64
		},
		{
			x: 295,
			y: 647,
			w: 64,
			h: 64
		},
		{
			x: 358,
			y: 678,
			w: 64,
			h: 64
		},
		{
			x: 295,
			y: 733,
			w: 64,
			h: 64
		},
		{
			x: 358,
			y: 770,
			w: 64,
			h: 64
		},
		{
			x: 295,
			y: 817,
			w: 64,
			h: 64
		},
		{
			x: 358,
			y: 851,
			w: 64,
			h: 64
		},
		{
			x: 295,
			y: 902,
			w: 64,
			h: 64
		},
		{
			x: 358,
			y: 937,
			w: 64,
			h: 64
		},
		{
			x: 295,
			y: 988,
			w: 64,
			h: 64
		},
		{
			x: 358,
			y: 1027,
			w: 64,
			h: 64
		}
	],
	[
		{
			x: 628,
			y: 486,
			w: 64,
			h: 64
		},
		{
			x: 676,
			y: 543,
			w: 64,
			h: 64
		},
		{
			x: 628,
			y: 593,
			w: 64,
			h: 64
		},
		{
			x: 676,
			y: 649,
			w: 64,
			h: 64
		},
		{
			x: 628,
			y: 702,
			w: 64,
			h: 64
		},
		{
			x: 676,
			y: 768,
			w: 64,
			h: 64
		},
		{
			x: 628,
			y: 818,
			w: 64,
			h: 64
		},
		{
			x: 676,
			y: 877,
			w: 64,
			h: 64
		},
		{
			x: 628,
			y: 939,
			w: 64,
			h: 64
		},
		{
			x: 676,
			y: 997,
			w: 64,
			h: 64
		}
	],
	[
		{
			x: 934,
			y: 484,
			w: 64,
			h: 64
		},
		{
			x: 994,
			y: 506,
			w: 64,
			h: 64
		},
		{
			x: 934,
			y: 564,
			w: 64,
			h: 64
		},
		{
			x: 994,
			y: 589,
			w: 64,
			h: 64
		},
		{
			x: 934,
			y: 649,
			w: 64,
			h: 64
		},
		{
			x: 994,
			y: 672,
			w: 64,
			h: 64
		},
		{
			x: 934,
			y: 737,
			w: 64,
			h: 64
		},
		{
			x: 994,
			y: 758,
			w: 64,
			h: 64
		},
		{
			x: 934,
			y: 821,
			w: 64,
			h: 64
		},
		{
			x: 994,
			y: 848,
			w: 64,
			h: 64
		},
		{
			x: 934,
			y: 907,
			w: 64,
			h: 64
		},
		{
			x: 994,
			y: 928,
			w: 64,
			h: 64
		},
		{
			x: 934,
			y: 991,
			w: 64,
			h: 64
		},
		{
			x: 994,
			y: 1014,
			w: 64,
			h: 64
		}
	],
	[
		{
			x: 1241,
			y: 491,
			w: 64,
			h: 64
		},
		{
			x: 1301,
			y: 510,
			w: 64,
			h: 64
		},
		{
			x: 1241,
			y: 563,
			w: 64,
			h: 64
		},
		{
			x: 1301,
			y: 583,
			w: 64,
			h: 64
		},
		{
			x: 1241,
			y: 635,
			w: 64,
			h: 64
		},
		{
			x: 1301,
			y: 658,
			w: 64,
			h: 64
		},
		{
			x: 1241,
			y: 709,
			w: 64,
			h: 64
		},
		{
			x: 1301,
			y: 729,
			w: 64,
			h: 64
		},
		{
			x: 1241,
			y: 783,
			w: 64,
			h: 64
		},
		{
			x: 1301,
			y: 801,
			w: 64,
			h: 64
		},
		{
			x: 1241,
			y: 856,
			w: 64,
			h: 64
		},
		{
			x: 1301,
			y: 880,
			w: 64,
			h: 64
		},
		{
			x: 1241,
			y: 932,
			w: 64,
			h: 64
		},
		{
			x: 1301,
			y: 951,
			w: 64,
			h: 64
		},
		{
			x: 1241,
			y: 1013,
			w: 64,
			h: 64
		},
		{
			x: 1301,
			y: 1028,
			w: 64,
			h: 64
		}
	],
	[
		{
			x: 1572,
			y: 615,
			w: 56,
			h: 56
		},
		{
			x: 1617,
			y: 690,
			w: 56,
			h: 56
		},
		{
			x: 1572,
			y: 751,
			w: 56,
			h: 56
		},
		{
			x: 1617,
			y: 815,
			w: 56,
			h: 56
		},
		{
			x: 1572,
			y: 879,
			w: 56,
			h: 56
		},
		{
			x: 1617,
			y: 945,
			w: 56,
			h: 56
		},
		{
			x: 1572,
			y: 1003,
			w: 56,
			h: 56
		},
		{
			x: 1617,
			y: 1065,
			w: 56,
			h: 56
		}
	],
	[
		{
			x: 1872,
			y: 648,
			w: 63,
			h: 46
		},
		{
			x: 1872,
			y: 735,
			w: 63,
			h: 46
		},
		{
			x: 1872,
			y: 821,
			w: 63,
			h: 46
		},
		{
			x: 1872,
			y: 906,
			w: 63,
			h: 46
		},
		{
			x: 1872,
			y: 993,
			w: 63,
			h: 46
		},
		{
			x: 1872,
			y: 1087,
			w: 63,
			h: 46
		}
	]
], qo = [
	{
		x: 466,
		y: 521,
		w: 78,
		h: 66
	},
	{
		x: 781,
		y: 521,
		w: 78,
		h: 66
	},
	{
		x: 1093,
		y: 521,
		w: 78,
		h: 66
	},
	{
		x: 1408,
		y: 521,
		w: 78,
		h: 66
	},
	{
		x: 1722,
		y: 633,
		w: 78,
		h: 66
	},
	{
		x: 1967,
		y: 635,
		w: 78,
		h: 66
	}
], Jo = [
	{
		x: 377,
		y: 732,
		w: 90,
		h: 90
	},
	{
		x: 702,
		y: 705,
		w: 90,
		h: 90
	},
	{
		x: 1020,
		y: 810,
		w: 90,
		h: 90
	},
	{
		x: 1332,
		y: 835,
		w: 90,
		h: 90
	}
], Yo = [
	{
		x: 474,
		y: 646,
		w: 60,
		h: 56
	},
	{
		x: 795,
		y: 689,
		w: 60,
		h: 56
	},
	{
		x: 1102,
		y: 691,
		w: 60,
		h: 56
	},
	{
		x: 1101,
		y: 754,
		w: 60,
		h: 56
	},
	{
		x: 1418,
		y: 641,
		w: 60,
		h: 56
	},
	{
		x: 1417,
		y: 699,
		w: 60,
		h: 56
	},
	{
		x: 1731,
		y: 828,
		w: 60,
		h: 56
	},
	{
		x: 1974,
		y: 829,
		w: 60,
		h: 56
	}
], Xo = [
	{
		x: 470,
		y: 713,
		w: 80,
		h: 62
	},
	{
		x: 469,
		y: 775,
		w: 80,
		h: 62
	},
	{
		x: 469,
		y: 836,
		w: 80,
		h: 62
	},
	{
		x: 786,
		y: 770,
		w: 80,
		h: 62
	},
	{
		x: 786,
		y: 831,
		w: 80,
		h: 62
	},
	{
		x: 1096,
		y: 831,
		w: 80,
		h: 62
	},
	{
		x: 1410,
		y: 773,
		w: 80,
		h: 62
	},
	{
		x: 1410,
		y: 834,
		w: 80,
		h: 62
	},
	{
		x: 1726,
		y: 904,
		w: 80,
		h: 62
	},
	{
		x: 1968,
		y: 905,
		w: 80,
		h: 62
	}
], Zo = [
	{
		x: 345,
		y: 214,
		w: 60,
		h: 60
	},
	{
		x: 662,
		y: 220,
		w: 60,
		h: 60
	},
	{
		x: 972,
		y: 223,
		w: 60,
		h: 60
	},
	{
		x: 1290,
		y: 218,
		w: 60,
		h: 60
	},
	{
		x: 1626,
		y: 196,
		w: 60,
		h: 60
	},
	{
		x: 1705,
		y: 195,
		w: 60,
		h: 60
	}
], Qo = [
	{
		x: 434,
		y: 194,
		w: 80,
		h: 54
	},
	{
		x: 757,
		y: 179,
		w: 80,
		h: 54
	},
	{
		x: 756,
		y: 242,
		w: 80,
		h: 54
	},
	{
		x: 1068,
		y: 180,
		w: 80,
		h: 54
	},
	{
		x: 1068,
		y: 242,
		w: 80,
		h: 54
	},
	{
		x: 1387,
		y: 196,
		w: 80,
		h: 54
	}
], $o = [
	{
		x: 322,
		y: 310,
		w: 187,
		h: 100
	},
	{
		x: 632,
		y: 319,
		w: 187,
		h: 100
	},
	{
		x: 947,
		y: 323,
		w: 187,
		h: 100
	},
	{
		x: 1262,
		y: 315,
		w: 187,
		h: 100
	},
	{
		x: 1591,
		y: 282,
		w: 223,
		h: 138
	}
], es = [
	{
		x: 149,
		y: 819,
		w: 92,
		h: 105
	},
	{
		x: 150,
		y: 978,
		w: 92,
		h: 105
	},
	{
		x: 150,
		y: 1127,
		w: 92,
		h: 105
	}
], ts = [
	{
		x: 1908,
		y: 263,
		w: 64,
		h: 64
	},
	{
		x: 1958,
		y: 323,
		w: 64,
		h: 64
	},
	{
		x: 1910,
		y: 385,
		w: 64,
		h: 64
	},
	{
		x: 1958,
		y: 433,
		w: 64,
		h: 64
	}
];
if ([
	Array.from({ length: 36 }, (e, t) => ({
		id: `c${t}`,
		comment: `L${Math.floor(t / 12) + 1}C${t % 12}`
	})),
	Array.from({ length: 24 }, (e, t) => ({
		id: `s${t}`,
		comment: `S${Math.floor(t / 12) + 1}C${t % 12}`
	})),
	Array.from({ length: 12 }, (e, t) => ({
		id: `p${t}`,
		comment: `C${t}`
	})),
	...W.map((e, t) => ({
		id: `slots${t}`,
		exportAs: "MAIN_SLOT_RECTS",
		kind: "rect",
		items: Array.from({ length: e.slots }, (t, n) => ({
			id: `s${n}`,
			comment: `槽${n}${e.badgeAt === n ? "(徽章锚)" : ""}`
		}))
	})),
	G.map((e, t) => ({
		id: `s${t}`,
		comment: `S${t} ${e.give === "robots" ? "3机器人" : "+2"}`
	}))
], Uo.length !== 36) throw Error("cell rects mismatch");
if (Wo.length !== 24) throw Error("stem rects mismatch");
if (Go.length !== 12) throw Error("pump rects mismatch");
if (Ko.some((e, t) => e.length !== W[t].slots)) throw Error("main slot rects mismatch");
if (Yo.length !== W.reduce((e, t) => e + t.bolts, 0)) throw Error("main bolt rects mismatch");
if (Xo.length !== W.reduce((e, t) => e + t.robots, 0)) throw Error("main robot rects mismatch");
if (Zo.length !== G.reduce((e, t) => e + t.bolts, 0)) throw Error("sub bolt rects mismatch");
if (Qo.length !== G.reduce((e, t) => e + t.robots, 0)) throw Error("sub robot rects mismatch");
if (ts.length !== 4) throw Error("error rects mismatch");
//#endregion
//#region src/games/moon/sheet-view4.tsx
function ns({ r: e, shade: t = "var(--color-ink)" }) {
	return /* @__PURE__ */ g("ellipse", {
		cx: e.x + e.w / 2,
		cy: e.y + e.h / 2,
		rx: e.w / 2 + 8,
		ry: e.h / 2 + 8,
		fill: "none",
		stroke: t,
		strokeWidth: Math.min(e.w, e.h) * .12,
		pointerEvents: "none"
	});
}
function rs(e) {
	let t = Math.min(...e.map((e) => e.x)), n = Math.min(...e.map((e) => e.y));
	return {
		x: t,
		y: n,
		w: Math.max(...e.map((e) => e.x + e.w)) - t,
		h: Math.max(...e.map((e) => e.y + e.h)) - n
	};
}
function is(e) {
	let t = [], n = 0;
	for (let r of e) t.push(n), n += r;
	return t;
}
var as = is(W.map((e) => e.bolts)), os = is(W.map((e) => e.robots)), ss = is(G.map((e) => e.bolts)), cs = is(G.map((e) => e.robots));
function ls(e, t) {
	if (e < 6) return rs(t === "bolt" ? Yo.slice(as[e], as[e] + W[e].bolts) : Xo.slice(os[e], os[e] + W[e].robots));
	let n = e - 6;
	return rs(t === "bolt" ? Zo.slice(ss[n], ss[n] + G[n].bolts) : Qo.slice(cs[n], cs[n] + G[n].robots));
}
function us({ sheet: e, missions: t, claims: n, mode: i, onTapCell: a, onTapStem: o, onTapFactory: s, readOnly: c, fitKey: l, pulse: u, focus: d }) {
	let f = r(() => {
		if (!c && i) switch (i.kind) {
			case "pick": return i.cells.map((e) => ({
				key: `c${e}`,
				rect: Uo[e]
			}));
			case "planX": return Uo.map((e, t) => ({
				key: `c${t}`,
				rect: e
			})).filter((t, n) => e.cells[n] === null);
			case "stem": return i.stems.map((e) => ({
				key: `s${e}`,
				rect: Wo[e]
			}));
			case "cross": return i.factories.map((e) => ({
				key: `f${e}`,
				rect: ls(e, i.sym)
			}));
		}
	}, [
		c,
		i,
		e.cells
	]), p = r(() => {
		if (a || o || s) return (e) => {
			let t = Number(e.slice(1));
			e[0] === "c" ? a?.(t) : e[0] === "s" ? o?.(t) : s?.(t);
		};
	}, [
		a,
		o,
		s
	]);
	return /* @__PURE__ */ _(ee, {
		image: "games/moon/sheet4.webp",
		sheetW: Vo,
		sheetH: Ho,
		eligible: f,
		onTapEligible: p,
		readOnly: c,
		fitKey: l,
		focus: d,
		children: [
			e.cells.map((e, t) => e === null ? null : e === "x" ? /* @__PURE__ */ g(Q, { r: Uo[t] }, t) : /* @__PURE__ */ g(m, {
				r: Uo[t],
				text: String(e)
			}, t)),
			e.minerals.map((e, t) => e === 0 ? null : /* @__PURE__ */ _("g", {
				pointerEvents: "none",
				children: [/* @__PURE__ */ g(ns, { r: Uo[t] }), e === 2 && /* @__PURE__ */ g(Q, {
					r: Uo[t],
					shade: "#7c2d12"
				})]
			}, `mn${t}`)),
			e.stems.map((e, t) => e === 0 || !Ye[t] ? null : /* @__PURE__ */ _("g", {
				pointerEvents: "none",
				children: [/* @__PURE__ */ g(ns, { r: Wo[t] }), e === 2 && /* @__PURE__ */ g(Q, {
					r: Wo[t],
					shade: "#7c2d12"
				})]
			}, `sm${t}`)),
			e.pumps.map((e, t) => e && /* @__PURE__ */ g(ns, { r: Go[t] }, `pp${t}`)),
			W.map((t, n) => /* @__PURE__ */ _("g", {
				pointerEvents: "none",
				children: [
					Ko[n].slice(0, e.circled[n]).map((e, n) => t.kind === "astro" || t.kind === "plan" ? /* @__PURE__ */ g(Q, { r: e }, n) : /* @__PURE__ */ g(ns, { r: e }, n)),
					Yo.slice(as[n], as[n] + e.bolts[n]).map((e, t) => /* @__PURE__ */ g(Q, { r: e }, `b${t}`)),
					Xo.slice(os[n], os[n] + e.robots[n]).map((e, t) => /* @__PURE__ */ g(Q, { r: e }, `r${t}`)),
					e.upgraded[n] && /* @__PURE__ */ g(Q, { r: qo[n] }),
					n < 4 && e.badge[n] === "circle" && /* @__PURE__ */ g(ns, {
						r: Jo[n],
						shade: "#059669"
					}),
					n < 4 && e.badge[n] === "cross" && /* @__PURE__ */ g(Q, { r: Jo[n] })
				]
			}, `fac${n}`)),
			G.map((t, n) => /* @__PURE__ */ _("g", {
				pointerEvents: "none",
				children: [
					Zo.slice(ss[n], ss[n] + e.subBolts[n]).map((e, t) => /* @__PURE__ */ g(Q, { r: e }, `b${t}`)),
					Qo.slice(cs[n], cs[n] + e.subRobots[n]).map((e, t) => /* @__PURE__ */ g(Q, { r: e }, `r${t}`)),
					e.subUsed[n] && /* @__PURE__ */ g(Q, { r: $o[n] })
				]
			}, `sub${n}`)),
			ts.slice(0, e.errors).map((e, t) => /* @__PURE__ */ g("ellipse", {
				cx: e.x + e.w / 2,
				cy: e.y + e.h / 2,
				rx: e.w / 2 + 8,
				ry: e.h / 2 + 8,
				fill: "none",
				stroke: "#dc2626",
				strokeWidth: 7,
				pointerEvents: "none"
			}, `er${t}`)),
			es.map((e, r) => {
				let i = n[r];
				if (!i) return null;
				let a = tt[t[r]];
				return /* @__PURE__ */ _("g", {
					pointerEvents: "none",
					children: [/* @__PURE__ */ g("rect", {
						x: e.x - 5,
						y: e.y - 5,
						width: e.w + 10,
						height: e.h + 10,
						rx: 16,
						fill: "none",
						stroke: i === "high" ? "#059669" : "#0284c7",
						strokeWidth: 7
					}), /* @__PURE__ */ g(m, {
						r: e,
						text: String(i === "high" ? a.hi : a.lo)
					})]
				}, `ms${r}`);
			}),
			u?.rects.map((e, t) => /* @__PURE__ */ g("rect", {
				x: e.x - 12,
				y: e.y - 12,
				width: e.w + 24,
				height: e.h + 24,
				rx: 20,
				fill: "none",
				stroke: "#f59e0b",
				strokeWidth: 10,
				strokeOpacity: 0,
				pointerEvents: "none",
				children: /* @__PURE__ */ g("animate", {
					attributeName: "stroke-opacity",
					values: "0.95;0.1;0.95;0.1;0.95",
					keyTimes: "0;0.25;0.5;0.75;1",
					dur: "1.3s",
					begin: `${t * .12}s`,
					repeatCount: "1"
				})
			}, `${u.key}:${t}`))
		]
	});
}
//#endregion
//#region src/games/moon/adv/adv5-layout.ts
var ds = 2315, fs = 2315, ps = [
	284,
	391,
	502,
	609,
	714,
	823,
	938,
	1045,
	1154,
	1261,
	1366,
	1473,
	1578
], ms = [
	476,
	810,
	1150,
	1440
], hs = [...Array.from({ length: 52 }, (e, t) => {
	let n = Math.floor(t / 13), r = t % 13;
	return xt(n, r) ? {
		x: ms[n] - 53,
		y: ps[r] - 48,
		w: 107,
		h: 96
	} : {
		x: ms[n] - 1,
		y: ps[r] - 1,
		w: 2,
		h: 2
	};
})], gs = Array.from({ length: 8 }, (e, t) => ps[10 - t]), _s = [...gs.flatMap((e) => [{
	x: 1674,
	y: e - 46,
	w: 74,
	h: 92
}, {
	x: 1735,
	y: e - 46,
	w: 74,
	h: 92
}])], vs = [...gs.map((e) => ({
	x: 1811,
	y: e - 51,
	w: 83,
	h: 102
}))], ys = [
	{
		x: 154,
		y: 747,
		w: 129,
		h: 129
	},
	{
		x: 327,
		y: 427,
		w: 129,
		h: 129
	},
	{
		x: 597,
		y: 189,
		w: 129,
		h: 129
	},
	{
		x: 929,
		y: 80,
		w: 129,
		h: 129
	},
	{
		x: 1276,
		y: 71,
		w: 129,
		h: 129
	},
	{
		x: 1605,
		y: 200,
		w: 129,
		h: 129
	},
	{
		x: 1882,
		y: 427,
		w: 129,
		h: 129
	},
	{
		x: 2026,
		y: 721,
		w: 129,
		h: 129
	}
], bs = [...[
	1772,
	1846,
	1920,
	1999
].flatMap((e) => [{
	x: 239,
	y: e - 34,
	w: 87,
	h: 68
}, {
	x: 321,
	y: e - 34,
	w: 87,
	h: 68
}])], xs = [...[
	1711,
	1772,
	1846,
	1920
].flatMap((e) => [
	{
		x: 627,
		y: e - 34,
		w: 87,
		h: 68
	},
	{
		x: 727,
		y: e - 34,
		w: 87,
		h: 68
	},
	{
		x: 825,
		y: e - 34,
		w: 87,
		h: 68
	}
])], Ss = [...[
	1767,
	1846,
	1925,
	1988
].flatMap((e) => [{
	x: 1410,
	y: e - 34,
	w: 87,
	h: 68
}, {
	x: 1484,
	y: e - 34,
	w: 87,
	h: 68
}])], Cs = [...[
	1698,
	1767,
	1833,
	1896
].map((e) => ({
	x: 1643,
	y: e - 34,
	w: 87,
	h: 68
}))], ws = [...[
	1698,
	1767,
	1841,
	1907,
	1975,
	2049
].map((e, t) => ({
	x: (t % 2 == 0 ? 1279 : 1335) - 37,
	y: e - 37,
	w: 74,
	h: 74
}))], Ts = [
	{
		x: 412,
		y: 1714,
		w: 111,
		h: 129
	},
	{
		x: 412,
		y: 1837,
		w: 111,
		h: 129
	},
	{
		x: 412,
		y: 1948,
		w: 111,
		h: 129
	}
], Es = [...[
	0,
	1,
	2,
	3
].flatMap((e) => {
	let t = ps[[
		4,
		1,
		0,
		3
	][e]], n = ps[[
		12,
		10,
		9,
		11
	][e]];
	return [{
		x: ms[e] - 83,
		y: t - 65,
		w: 166,
		h: 66
	}, {
		x: ms[e] - 83,
		y: n,
		w: 166,
		h: 66
	}];
})], Ds = [...[
	1754,
	1852,
	1938,
	2025
].map((e) => ({
	x: 1868,
	y: e - 46,
	w: 92,
	h: 92
}))];
if (Array.from({ length: 52 }, (e, t) => ({
	id: `c${t}`,
	comment: `楼${Math.floor(t / 13) + 1}r${t % 13}`
})), Array.from({ length: 16 }, (e, t) => ({
	id: `p${t}`,
	comment: `层${Math.floor(t / 2) + 1}植${t % 2 + 1}`
})), Array.from({ length: 8 }, (e, t) => ({
	id: `w${t}`,
	comment: `层${t + 1}水`
})), Dt.map((e, t) => ({
	id: `d${t}`,
	comment: `段${t + 1} ${e.parity === "even" ? "偶" : "奇"}`
})), Array.from({ length: 8 }, (e, t) => ({
	id: `m${t}`,
	comment: `任务r${Math.floor(t / 2)}c${t % 2}`
})), Array.from({ length: 12 }, (e, t) => ({
	id: `t${t}`,
	comment: `塔r${Math.floor(t / 3)}c${t % 3}`
})), Array.from({ length: 8 }, (e, t) => ({
	id: `a${t}`,
	comment: `宇航r${Math.floor(t / 2)}c${t % 2}`
})), Array.from({ length: 4 }, (e, t) => ({
	id: `d${t}`,
	comment: `穹顶r${t}`
})), Array.from({ length: 6 }, (e, t) => ({
	id: `c${t}`,
	comment: `币${t + 1}`
})), Array.from({ length: 8 }, (e, t) => ({
	id: `b${t}`,
	comment: `楼${Math.floor(t / 2) + 1}${t % 2 == 0 ? "顶" : "底"}`
})), hs.length !== 52) throw Error("cell rects mismatch");
if (_s.length !== 16) throw Error("tower plant rects mismatch");
if (vs.length !== 8) throw Error("tower water rects mismatch");
if (ys.length !== Dt.length) throw Error("dome seg rects mismatch");
if (bs.length !== 8 || Ss.length !== 8) throw Error("energy double-column rects mismatch");
if (xs.length !== 12 || Cs.length !== 4) throw Error("energy rects mismatch");
if (Es.length !== 8) throw Error("bonus rects mismatch");
if (Ds.length !== 4) throw Error("error rects mismatch");
//#endregion
//#region src/games/moon/sheet-view5.tsx
function Os({ r: e, shade: t = "var(--color-ink)" }) {
	return /* @__PURE__ */ g("ellipse", {
		cx: e.x + e.w / 2,
		cy: e.y + e.h / 2,
		rx: e.w / 2 + 8,
		ry: e.h / 2 + 8,
		fill: "none",
		stroke: t,
		strokeWidth: Math.min(e.w, e.h) * .12,
		pointerEvents: "none"
	});
}
function ks(e) {
	let t = Math.min(...e.map((e) => e.x)), n = Math.min(...e.map((e) => e.y));
	return {
		x: t,
		y: n,
		w: Math.max(...e.map((e) => e.x + e.w)) - t,
		h: Math.max(...e.map((e) => e.y + e.h)) - n
	};
}
function As(e) {
	let t = 2315 / 1254, n = [], r = 0, i = 0;
	for (; i < e.length && r < Dt.length;) {
		let a = Dt[r], o = a.ax * t, s = a.ay * t, c = a.bx * t, l = a.by * t;
		e[i].half ? (n.push({
			ax: o,
			ay: s,
			bx: (o + c) / 2,
			by: (s + l) / 2
		}), n.push({
			ax: (o + c) / 2,
			ay: (s + l) / 2,
			bx: c,
			by: l
		}), i += 2) : (n.push({
			ax: o,
			ay: s,
			bx: c,
			by: l
		}), i += 1), r += 1;
	}
	return n;
}
function js(e) {
	let t = (e.ax + e.bx) / 2, n = (e.ay + e.by) / 2;
	return {
		x: t - 64,
		y: n - 64,
		w: 129,
		h: 129
	};
}
function Ms(e, t) {
	return t === 0 ? e.energyMission >= 4 ? null : ks([bs[e.energyMission * 2], bs[e.energyMission * 2 + 1]]) : t === 1 ? e.energyTower >= 4 ? null : ks([
		xs[e.energyTower * 3],
		xs[e.energyTower * 3 + 1],
		xs[e.energyTower * 3 + 2]
	]) : t === 2 ? e.energyAstro >= 4 ? null : ks([Ss[e.energyAstro * 2], Ss[e.energyAstro * 2 + 1]]) : e.energyDome >= 4 ? null : Cs[e.energyDome];
}
function Ns({ sheet: e, claims: t, mode: n, onTapCell: i, onTapTower: a, onTapDome: o, onTapEnergy: s, readOnly: c, fitKey: l, pulse: u, focus: d }) {
	let f = r(() => As(e.dome), [e.dome]), p = r(() => {
		if (!c && n) switch (n.kind) {
			case "pick": return n.cells.map((e) => ({
				key: `c${e}`,
				rect: hs[e]
			}));
			case "planX": return hs.map((e, t) => ({
				key: `c${t}`,
				rect: e
			})).filter((t, n) => e.cells[n] === null && xt(Math.floor(n / 13), n % 13));
			case "tower": {
				if (n.res === "water") return [{
					key: `t${n.level}`,
					rect: vs[n.level]
				}];
				let t = [];
				for (let r = 0; r < 2; r += 1) r >= e.towerPlants[n.level] && t.push({
					key: `t${n.level}`,
					rect: _s[n.level * 2 + r]
				});
				return t.length > 0 ? [t[0]] : [];
			}
			case "dome":
			case "cut": return n.indices.map((e) => ({
				key: `d${e}`,
				rect: js(f[e])
			}));
			case "energy": return n.fields.flatMap((t) => {
				let n = Ms(e, t);
				return n ? [{
					key: `e${t}`,
					rect: n
				}] : [];
			});
		}
	}, [
		c,
		n,
		e,
		f
	]), h = r(() => {
		if (i || a || o || s) return (e) => {
			let t = Number(e.slice(1));
			e[0] === "c" ? i?.(t) : e[0] === "t" ? a?.(t) : e[0] === "d" ? o?.(t) : s?.(t);
		};
	}, [
		i,
		a,
		o,
		s
	]);
	return /* @__PURE__ */ _(ee, {
		image: "games/moon/sheet5.webp",
		sheetW: ds,
		sheetH: fs,
		eligible: p,
		onTapEligible: h,
		readOnly: c,
		fitKey: l,
		focus: d,
		children: [
			e.cells.map((e, t) => e === null || !xt(Math.floor(t / 13), t % 13) ? null : e === "x" ? /* @__PURE__ */ g(Q, { r: hs[t] }, t) : /* @__PURE__ */ g(m, {
				r: hs[t],
				text: String(e)
			}, t)),
			e.towerPlants.map((e, t) => Array.from({ length: e }, (e, n) => /* @__PURE__ */ g(Os, {
				r: _s[t * 2 + n],
				shade: "#166534"
			}, `tp${t}-${n}`))),
			e.towerWaters.map((e, t) => e > 0 ? /* @__PURE__ */ g(Os, {
				r: vs[t],
				shade: "#0369a1"
			}, `tw${t}`) : null),
			f.map((t, n) => {
				let r = e.dome[n];
				return r ? /* @__PURE__ */ _("g", {
					pointerEvents: "none",
					children: [r.built && /* @__PURE__ */ g("line", {
						x1: t.ax,
						y1: t.ay,
						x2: t.bx,
						y2: t.by,
						stroke: "#f59e0b",
						strokeWidth: 26,
						strokeLinecap: "round"
					}), r.half && n % 2 == 1 && e.dome[n - 1]?.half && /* @__PURE__ */ g("circle", {
						cx: t.ax,
						cy: t.ay,
						r: 20,
						fill: "none",
						stroke: "#dc2626",
						strokeWidth: 7
					})]
				}, `dm${n}`) : null;
			}),
			Array.from({ length: e.energyMission }, (e, t) => /* @__PURE__ */ _("g", {
				pointerEvents: "none",
				children: [/* @__PURE__ */ g(Q, { r: bs[t * 2] }), /* @__PURE__ */ g(Q, { r: bs[t * 2 + 1] })]
			}, `em${t}`)),
			Array.from({ length: e.energyTower }, (e, t) => /* @__PURE__ */ _("g", {
				pointerEvents: "none",
				children: [
					/* @__PURE__ */ g(Q, { r: xs[t * 3] }),
					/* @__PURE__ */ g(Q, { r: xs[t * 3 + 1] }),
					/* @__PURE__ */ g(Q, { r: xs[t * 3 + 2] })
				]
			}, `et${t}`)),
			Array.from({ length: e.energyAstro }, (e, t) => /* @__PURE__ */ _("g", {
				pointerEvents: "none",
				children: [/* @__PURE__ */ g(Q, { r: Ss[t * 2] }), /* @__PURE__ */ g(Q, { r: Ss[t * 2 + 1] })]
			}, `ea${t}`)),
			Array.from({ length: e.energyDome }, (e, t) => /* @__PURE__ */ g(Q, { r: Cs[t] }, `ed${t}`)),
			ws.slice(0, e.astronauts).map((e, t) => /* @__PURE__ */ g(Q, { r: e }, `ac${t}`)),
			Es.map((t, n) => {
				let r = e.bonus[n];
				if (!r) return null;
				let i = {
					x: t.x,
					y: t.y,
					w: t.w / 2,
					h: t.h
				};
				return r === "circle" ? /* @__PURE__ */ g(Os, {
					r: i,
					shade: "#059669"
				}, `bn${n}`) : /* @__PURE__ */ g(Q, { r: i }, `bn${n}`);
			}),
			Ds.slice(0, e.errors).map((e, t) => /* @__PURE__ */ g("ellipse", {
				cx: e.x + e.w / 2,
				cy: e.y + e.h / 2,
				rx: e.w / 2 + 8,
				ry: e.h / 2 + 8,
				fill: "none",
				stroke: "#dc2626",
				strokeWidth: 7,
				pointerEvents: "none"
			}, `er${t}`)),
			Ts.map((n, r) => {
				let i = t[r];
				return i ? /* @__PURE__ */ _("g", {
					pointerEvents: "none",
					children: [/* @__PURE__ */ g("rect", {
						x: n.x - 5,
						y: n.y - 5,
						width: n.w + 10,
						height: n.h + 10,
						rx: 16,
						fill: "none",
						stroke: i === "high" ? "#059669" : "#0284c7",
						strokeWidth: 7
					}), /* @__PURE__ */ g(m, {
						r: n,
						text: String(Jt(e, i === "high" ? 0 : 1))
					})]
				}, `ms${r}`) : null;
			}),
			u?.rects.map((e, t) => /* @__PURE__ */ g("rect", {
				x: e.x - 12,
				y: e.y - 12,
				width: e.w + 24,
				height: e.h + 24,
				rx: 20,
				fill: "none",
				stroke: "#f59e0b",
				strokeWidth: 10,
				strokeOpacity: 0,
				pointerEvents: "none",
				children: /* @__PURE__ */ g("animate", {
					attributeName: "stroke-opacity",
					values: "0.95;0.1;0.95;0.1;0.95",
					keyTimes: "0;0.25;0.5;0.75;1",
					dur: "1.3s",
					begin: `${t * .12}s`,
					repeatCount: "1"
				})
			}, `${u.key}:${t}`))
		]
	});
}
//#endregion
//#region src/games/moon/adv/adv6-layout.ts
var Ps = 2315, Fs = 2315, Is = [
	340,
	997,
	990,
	1640,
	430,
	985,
	1640,
	315,
	980,
	978,
	1632
], Ls = [
	196,
	493,
	816,
	1143,
	1490
], Rs = [
	0,
	0,
	1,
	1,
	2,
	2,
	2,
	3,
	3,
	4,
	4
], zs = [...Array.from({ length: 55 }, (e, t) => {
	let n = Math.floor(t / 5), r = Is[n] + t % 5 * 98, i = Ls[Rs[n]];
	return {
		x: r - 45,
		y: i - 40,
		w: 90,
		h: 80
	};
})], Bs = [
	315,
	640,
	965,
	1285,
	1610
], Vs = [
	349,
	1015,
	975,
	1684,
	309,
	975,
	1636,
	355,
	971,
	1012,
	1677
], Hs = [
	[434, 521],
	[1099, 1182],
	[1057, 1141],
	[1766, 1851],
	[392, 477],
	[1058, 1141],
	[1719, 1803],
	[438, 522],
	[1054, 1137],
	[1095, 1176],
	[1759, 1844]
], Us = [
	[650],
	[1300],
	[1256, 1344],
	[1967],
	[599, 687],
	[1256, 1341],
	[1920, 2008],
	[639],
	[1256, 1344],
	[1301],
	[1954]
], Ws = [...Hs.flatMap(([e, t], n) => [e, t].map((e) => ({
	x: e - 32,
	y: Bs[Rs[n]] - 32,
	w: 64,
	h: 64
})))], Gs = [...Vs.map((e, t) => ({
	x: e - 33,
	y: Bs[Rs[t]] - 33,
	w: 66,
	h: 66
}))], Ks = [...Us.flatMap((e, t) => e.map((e) => ({
	x: e - 37,
	y: Bs[Rs[t]] - 32,
	w: 74,
	h: 64
})))], qs = [...[
	[331, 137],
	[1087, 139],
	[1185, 459],
	[2030, 458],
	[521, 782],
	[1934, 782],
	[406, 1109],
	[1171, 1109],
	[1067, 1430],
	[1831, 1429]
].map(([e, t]) => ({
	x: e - 28,
	y: t - 30,
	w: 56,
	h: 60
}))], Js = [...[
	[790, 100],
	[1438, 119],
	[1400, 390],
	[1919, 422],
	[0, 0],
	[1428, 740],
	[0, 0],
	[729, 1058],
	[1378, 1056],
	[1277, 1384],
	[2028, 1376]
].map(([e, t]) => e === 0 ? {
	x: 0,
	y: 0,
	w: 2,
	h: 2
} : {
	x: e - 48,
	y: t - 48,
	w: 96,
	h: 96
})], Ys = [
	{
		x: 211,
		y: 279,
		w: 44,
		h: 72
	},
	{
		x: 392,
		y: 333,
		w: 85,
		h: 44
	},
	{
		x: 581,
		y: 719,
		w: 79,
		h: 44
	},
	{
		x: 768,
		y: 200,
		w: 44,
		h: 58
	},
	{
		x: 907,
		y: 720,
		w: 86,
		h: 44
	},
	{
		x: 1039,
		y: 334,
		w: 83,
		h: 44
	},
	{
		x: 1422,
		y: 523,
		w: 44,
		h: 58
	},
	{
		x: 1422,
		y: 608,
		w: 44,
		h: 70
	},
	{
		x: 769,
		y: 846,
		w: 44,
		h: 60
	},
	{
		x: 769,
		y: 932,
		w: 44,
		h: 68
	},
	{
		x: 1036,
		y: 982,
		w: 82,
		h: 44
	},
	{
		x: 1422,
		y: 846,
		w: 44,
		h: 58
	},
	{
		x: 2089,
		y: 455,
		w: 44,
		h: 70
	},
	{
		x: 1422,
		y: 931,
		w: 44,
		h: 68
	},
	{
		x: 1777,
		y: 980,
		w: 76,
		h: 44
	},
	{
		x: 1398,
		y: 1497,
		w: 90,
		h: 44
	},
	{
		x: 881,
		y: 1171,
		w: 44,
		h: 58
	},
	{
		x: 1664,
		y: 981,
		w: 77,
		h: 44
	},
	{
		x: 1788,
		y: 660,
		w: 80,
		h: 44
	},
	{
		x: 479,
		y: 981,
		w: 81,
		h: 44
	},
	{
		x: 1127,
		y: 661,
		w: 80,
		h: 44
	},
	{
		x: 1122,
		y: 1305,
		w: 81,
		h: 44
	}
], Xs = [...[
	[589, 1677],
	[655, 1677],
	[589, 1746],
	[655, 1746],
	[523, 1820],
	[589, 1820],
	[655, 1820],
	[523, 1890],
	[589, 1890],
	[655, 1890],
	[523, 1963],
	[589, 1963],
	[655, 1963],
	[523, 2038],
	[589, 2038],
	[655, 2038]
].map(([e, t]) => ({
	x: e - 28,
	y: t - 32,
	w: 56,
	h: 64
}))], Zs = [...[
	[1049, 1729],
	[1118, 1729],
	[1050, 1806],
	[1117, 1806],
	[1049, 1881],
	[1117, 1881],
	[1050, 1958],
	[1118, 1958],
	[1050, 2034],
	[1117, 2034]
].map(([e, t]) => ({
	x: e - 28,
	y: t - 30,
	w: 56,
	h: 60
}))], Qs = [...[
	1746,
	1818,
	1892,
	1967,
	2042,
	2115
].map((e) => ({
	x: 696,
	y: e - 31,
	w: 60,
	h: 62
}))], $s = [...[
	1814,
	1889,
	1965,
	2041,
	2110
].map((e) => ({
	x: 1160,
	y: e - 31,
	w: 62,
	h: 62
}))], ec = [...[
	1669,
	1742,
	1814,
	1890,
	1965,
	2037
].map((e) => ({
	x: 785,
	y: e - 24,
	w: 58,
	h: 48
}))], tc = [...[
	1740,
	1813,
	1893,
	1966,
	2042
].map((e) => ({
	x: 1226,
	y: e - 22,
	w: 52,
	h: 44
}))], nc = [
	{
		x: 397,
		y: 1862,
		w: 56,
		h: 56
	},
	{
		x: 397,
		y: 1922,
		w: 56,
		h: 56
	},
	{
		x: 932,
		y: 1872,
		w: 56,
		h: 56
	},
	{
		x: 932,
		y: 1942,
		w: 56,
		h: 56
	}
], rc = [
	{
		x: 265,
		y: 1780,
		w: 70,
		h: 70
	},
	{
		x: 265,
		y: 1900,
		w: 70,
		h: 70
	},
	{
		x: 265,
		y: 2020,
		w: 70,
		h: 70
	},
	{
		x: 424,
		y: 1701,
		w: 70,
		h: 70
	},
	{
		x: 950,
		y: 1736,
		w: 70,
		h: 70
	}
], ic = [
	{
		x: 140,
		y: 1760,
		w: 110,
		h: 110
	},
	{
		x: 140,
		y: 1880,
		w: 110,
		h: 110
	},
	{
		x: 140,
		y: 2e3,
		w: 110,
		h: 110
	}
], ac = [
	{
		x: 1394,
		y: 1799,
		w: 80,
		h: 80
	},
	{
		x: 1486,
		y: 1799,
		w: 80,
		h: 80
	},
	{
		x: 1486,
		y: 1880,
		w: 80,
		h: 80
	},
	{
		x: 1577,
		y: 1880,
		w: 80,
		h: 80
	},
	{
		x: 1393,
		y: 1960,
		w: 80,
		h: 80
	},
	{
		x: 1485,
		y: 1960,
		w: 80,
		h: 80
	},
	{
		x: 1577,
		y: 1960,
		w: 80,
		h: 80
	},
	{
		x: 1393,
		y: 2040,
		w: 80,
		h: 80
	},
	{
		x: 1485,
		y: 2040,
		w: 80,
		h: 80
	},
	{
		x: 1485,
		y: 2119,
		w: 80,
		h: 80
	},
	{
		x: 1577,
		y: 2119,
		w: 80,
		h: 80
	}
], oc = [
	{
		x: 1825,
		y: 1870,
		w: 90,
		h: 90
	},
	{
		x: 1825,
		y: 1980,
		w: 90,
		h: 90
	},
	{
		x: 1810,
		y: 2060,
		w: 90,
		h: 90
	}
], sc = [...[
	[1616, 109],
	[1685, 109],
	[1616, 193],
	[1685, 193],
	[1616, 276],
	[1685, 276]
].map(([e, t]) => ({
	x: e - 37,
	y: t - 37,
	w: 74,
	h: 74
}))], cc = [...[
	[1950, 120],
	[2025, 120],
	[1950, 190],
	[2025, 190],
	[1950, 265],
	[2025, 265]
].map(([e, t]) => ({
	x: e - 30,
	y: t - 40,
	w: 60,
	h: 80
}))], lc = [...[
	[1805, 120],
	[1805, 190],
	[1805, 265],
	[2140, 120],
	[2140, 190],
	[2140, 265]
].map(([e, t]) => ({
	x: e - 37,
	y: t - 37,
	w: 74,
	h: 74
}))];
if (Array.from({ length: 55 }, (e, t) => ({
	id: `c${t}`,
	comment: `Q${Math.floor(t / 5)}格${t % 5 + 1}`
})), Array.from({ length: 22 }, (e, t) => ({
	id: `e${t}`,
	comment: `Q${Math.floor(t / 2)}旗${t % 2 + 1}`
})), Array.from({ length: 11 }, (e, t) => ({
	id: `q${t}`,
	comment: `Q${t}疏散圈`
})), Array.from({ length: 16 }, (e, t) => {
	let n = 0;
	for (; t >= Xn.slice(0, n + 1).reduce((e, t) => e + t, 0);) n += 1;
	return {
		id: `p${t}`,
		comment: `Q${n}植物`
	};
}), Array.from({ length: 10 }, (e, t) => ({
	id: `t${t}`,
	comment: `水箱${t + 1}`
})), Array.from({ length: 11 }, (e, t) => ({
	id: `v${t}`,
	comment: `Q${t}靶`
})), Array.from({ length: 22 }, (e, t) => ({
	id: `w${t}`,
	comment: `步道${t + 98}`
})), Array.from({ length: Qn.count }, (e, t) => ({
	id: `pt${t}`,
	comment: `植物轨${t + 1}`
})), Array.from({ length: $n.count }, (e, t) => ({
	id: `wt${t}`,
	comment: `水轨${t + 1}`
})), Qn.scores.map((e, t) => ({
	id: `ps${t}`,
	comment: `植物${e}`
})), $n.scores.map((e, t) => ({
	id: `ws${t}`,
	comment: `水${e}`
})), Array.from({ length: 6 }, (e, t) => ({
	id: `pr${t}`,
	comment: `机器人${t + 1}`
})), Array.from({ length: 5 }, (e, t) => ({
	id: `we${t}`,
	comment: `能量${t + 1}`
})), Array.from({ length: 4 }, (e, t) => ({
	id: `pp${t}`,
	comment: `传播槽${t + 1}`
})), Array.from({ length: 5 }, (e, t) => ({
	id: `vd${t}`,
	comment: `病毒${[
		"红",
		"紫",
		"黄",
		"绿",
		"蓝"
	][t]}`
})), Array.from({ length: 11 }, (e, t) => ({
	id: `ev${t}`,
	comment: `Q${t}疏散分`
})), Array.from({ length: 3 }, (e, t) => ({
	id: `e${t}`,
	comment: `-${(t + 1) * 5}`
})), Array.from({ length: 6 }, (e, t) => ({
	id: `ac${t}`,
	comment: `币${t + 1}`
})), Array.from({ length: 6 }, (e, t) => ({
	id: `pl${t}`,
	comment: `卡${t + 1}`
})), Array.from({ length: 6 }, (e, t) => ({
	id: `wg${t}`,
	comment: `齿轮${t + 1}`
})), zs.length !== 55) throw Error("cell rects mismatch");
if (Ws.length !== 22) throw Error("energy rects mismatch");
if (Gs.length !== 11 || ac.length !== 11) throw Error("quarter rects mismatch");
if (Ks.length !== 16) throw Error("plant rects mismatch");
if (qs.length !== 10) throw Error("tank rects mismatch");
if (Js.length !== 11) throw Error("virus rects mismatch");
if (Ys.length !== 22) throw Error("walkway rects mismatch");
if (Xs.length !== Qn.count || Zs.length !== $n.count) throw Error("track rects mismatch");
if (Qs.length !== Qn.scores.length || $s.length !== $n.scores.length) throw Error("score rects mismatch");
if (nc.length !== 4 || rc.length !== 5) throw Error("prop/virus display rects mismatch");
if (oc.length !== 3) throw Error("error rects mismatch");
//#endregion
//#region src/games/moon/sheet-view6.tsx
function uc({ r: e, shade: t = "var(--color-ink)" }) {
	return /* @__PURE__ */ g("ellipse", {
		cx: e.x + e.w / 2,
		cy: e.y + e.h / 2,
		rx: e.w / 2 + 8,
		ry: e.h / 2 + 8,
		fill: "none",
		stroke: t,
		strokeWidth: Math.min(e.w, e.h) * .12,
		pointerEvents: "none"
	});
}
function dc({ r: e }) {
	return /* @__PURE__ */ g("circle", {
		cx: e.x + e.w / 2,
		cy: e.y + e.h / 2,
		r: Math.min(e.w, e.h) * .3,
		fill: "#65a30d",
		stroke: "#ffffff",
		strokeWidth: Math.min(e.w, e.h) * .08,
		pointerEvents: "none"
	});
}
function fc({ sheet: e, missions: t, claims: n, activatedViruses: i, mode: a, markedCells: o, onTapCell: s, onTapWalk: c, onTapEnergy: l, readOnly: u, fitKey: d, pulse: f, focus: p }) {
	let h = r(() => {
		if (!u && a) switch (a.kind) {
			case "pick":
			case "grey":
			case "infect": return a.cells.map((e) => ({
				key: `c${e}`,
				rect: zs[e]
			}));
			case "planX": return zs.map((e, t) => ({
				key: `c${t}`,
				rect: e
			})).filter((t, n) => e.cells[n] === null);
			case "close": return a.walks.map((e) => ({
				key: `w${e}`,
				rect: Ys[e]
			}));
			case "energy": return a.slots.map((e) => ({
				key: `e${e}`,
				rect: Ws[e]
			}));
		}
	}, [
		u,
		a,
		e
	]), v = r(() => {
		if (s || c || l) return (e) => {
			let t = Number(e.slice(1));
			e[0] === "c" ? s?.(t) : e[0] === "w" ? c?.(t) : l?.(t);
		};
	}, [
		s,
		c,
		l
	]), y = (t) => e.plantTrack > Qn.ends[t], b = (t) => e.waterTrack > $n.ends[t];
	return /* @__PURE__ */ _(ee, {
		image: "games/moon/sheet6.webp",
		sheetW: Ps,
		sheetH: Fs,
		eligible: h,
		onTapEligible: v,
		readOnly: u,
		fitKey: d,
		focus: p,
		children: [
			e.cells.map((e, t) => e === null ? null : e === "x" ? /* @__PURE__ */ g(Q, { r: zs[t] }, t) : e === "v" ? /* @__PURE__ */ g(dc, { r: zs[t] }, t) : /* @__PURE__ */ g(m, {
				r: zs[t],
				text: String(e)
			}, t)),
			o?.map((e) => /* @__PURE__ */ g(uc, {
				r: zs[e],
				shade: "#0284c7"
			}, `mk${e}`)),
			e.energy.map((e, t) => e ? /* @__PURE__ */ g(uc, {
				r: Ws[t],
				shade: "#d97706"
			}, `e${t}`) : null),
			e.walkways.map((e, t) => e ? /* @__PURE__ */ g(Q, {
				r: Ys[t],
				shade: "#dc2626"
			}, `w${t}`) : null),
			e.plants.map((e, t) => e ? /* @__PURE__ */ g(uc, {
				r: Ks[t],
				shade: "#166534"
			}, `p${t}`) : null),
			e.tanks.map((e, t) => e ? /* @__PURE__ */ g(uc, {
				r: qs[t],
				shade: "#0369a1"
			}, `t${t}`) : null),
			Xs.slice(0, e.plantTrack).map((e, t) => /* @__PURE__ */ g(Q, {
				r: e,
				shade: "#166534"
			}, `pt${t}`)),
			Zs.slice(0, e.waterTrack).map((e, t) => /* @__PURE__ */ g(Q, {
				r: e,
				shade: "#0369a1"
			}, `wt${t}`)),
			Qs.map((e, t) => y(t) ? /* @__PURE__ */ g(Q, {
				r: e,
				shade: "#166534"
			}, `ps${t}`) : null),
			$s.map((e, t) => b(t) ? /* @__PURE__ */ g(Q, {
				r: e,
				shade: "#0369a1"
			}, `ws${t}`) : null),
			ec.map((e, t) => y(t) ? /* @__PURE__ */ g(Q, { r: e }, `pr${t}`) : null),
			tc.map((e, t) => b(t) ? /* @__PURE__ */ g(Q, { r: e }, `we${t}`) : null),
			e.viruses.map((e, t) => e && Js[t].w > 10 ? /* @__PURE__ */ g(uc, {
				r: Js[t],
				shade: "#7c3aed"
			}, `v${t}`) : null),
			e.virusCrossed.map((e, t) => e && Js[t].w > 10 ? /* @__PURE__ */ g(Q, {
				r: Js[t],
				shade: "#7c3aed"
			}, `vx${t}`) : null),
			i.map((e, t) => e ? /* @__PURE__ */ g(Q, {
				r: rc[t],
				shade: "#7c3aed"
			}, `vd${t}`) : null),
			e.propSlots.map((e, t) => e ? /* @__PURE__ */ g(Q, {
				r: nc[t],
				shade: "#7c3aed"
			}, `pp${t}`) : null),
			e.evac.map((e, t) => e === null ? null : /* @__PURE__ */ _("g", {
				pointerEvents: "none",
				children: [/* @__PURE__ */ g(uc, {
					r: Gs[t],
					shade: "#059669"
				}), /* @__PURE__ */ g(m, {
					r: ac[t],
					text: String(e)
				})]
			}, `ev${t}`)),
			oc.slice(0, e.errors).map((e, t) => /* @__PURE__ */ g("ellipse", {
				cx: e.x + e.w / 2,
				cy: e.y + e.h / 2,
				rx: e.w / 2 + 8,
				ry: e.h / 2 + 8,
				fill: "none",
				stroke: "#dc2626",
				strokeWidth: 7,
				pointerEvents: "none"
			}, `er${t}`)),
			sc.slice(0, e.astronauts).map((e, t) => /* @__PURE__ */ g(Q, { r: e }, `ac${t}`)),
			cc.slice(0, e.plannings).map((e, t) => /* @__PURE__ */ g(Q, { r: e }, `pl${t}`)),
			lc.slice(0, e.wilds).map((t, n) => n < e.wildsUsed ? /* @__PURE__ */ g(Q, { r: t }, `wg${n}`) : /* @__PURE__ */ g(uc, {
				r: t,
				shade: "#059669"
			}, `wg${n}`)),
			ic.map((e, r) => {
				let i = n[r];
				if (!i) return null;
				let a = nr[t[r]][i === "high" ? 0 : 1];
				return /* @__PURE__ */ _("g", {
					pointerEvents: "none",
					children: [/* @__PURE__ */ g("rect", {
						x: e.x - 5,
						y: e.y - 5,
						width: e.w + 10,
						height: e.h + 10,
						rx: 16,
						fill: "none",
						stroke: i === "high" ? "#059669" : "#0284c7",
						strokeWidth: 7
					}), /* @__PURE__ */ g(m, {
						r: e,
						text: String(a)
					})]
				}, `ms${r}`);
			}),
			f?.rects.map((e, t) => /* @__PURE__ */ g("rect", {
				x: e.x - 12,
				y: e.y - 12,
				width: e.w + 24,
				height: e.h + 24,
				rx: 20,
				fill: "none",
				stroke: "#f59e0b",
				strokeWidth: 10,
				strokeOpacity: 0,
				pointerEvents: "none",
				children: /* @__PURE__ */ g("animate", {
					attributeName: "stroke-opacity",
					values: "0.95;0.1;0.95;0.1;0.95",
					keyTimes: "0;0.25;0.5;0.75;1",
					dur: "1.3s",
					begin: `${t * .12}s`,
					repeatCount: "1"
				})
			}, `${f.key}:${t}`))
		]
	});
}
//#endregion
//#region src/games/moon/adv/adv7-layout.ts
var pc = 2315, mc = 2315, hc = [
	{
		x: 514,
		y: 1452,
		w: 92,
		h: 88
	},
	{
		x: 619,
		y: 1452,
		w: 92,
		h: 88
	},
	{
		x: 724,
		y: 1452,
		w: 92,
		h: 88
	},
	{
		x: 830,
		y: 1446,
		w: 92,
		h: 88
	},
	{
		x: 1081,
		y: 1452,
		w: 92,
		h: 88
	},
	{
		x: 1340,
		y: 1450,
		w: 92,
		h: 88
	},
	{
		x: 1442,
		y: 1452,
		w: 92,
		h: 88
	},
	{
		x: 1549,
		y: 1450,
		w: 92,
		h: 88
	},
	{
		x: 1652,
		y: 1450,
		w: 92,
		h: 88
	},
	{
		x: 389,
		y: 1194,
		w: 92,
		h: 88
	},
	{
		x: 490,
		y: 1194,
		w: 92,
		h: 88
	},
	{
		x: 596,
		y: 1194,
		w: 92,
		h: 88
	},
	{
		x: 851,
		y: 1196,
		w: 92,
		h: 88
	},
	{
		x: 958,
		y: 1194,
		w: 92,
		h: 88
	},
	{
		x: 1062,
		y: 1192,
		w: 92,
		h: 88
	},
	{
		x: 1315,
		y: 1192,
		w: 92,
		h: 88
	},
	{
		x: 1570,
		y: 1194,
		w: 92,
		h: 88
	},
	{
		x: 1676,
		y: 1194,
		w: 92,
		h: 88
	},
	{
		x: 1785,
		y: 1192,
		w: 92,
		h: 88
	},
	{
		x: 350,
		y: 938,
		w: 92,
		h: 88
	},
	{
		x: 629,
		y: 936,
		w: 92,
		h: 88
	},
	{
		x: 734,
		y: 938,
		w: 92,
		h: 88
	},
	{
		x: 839,
		y: 934,
		w: 92,
		h: 88
	},
	{
		x: 1091,
		y: 934,
		w: 92,
		h: 88
	},
	{
		x: 1196,
		y: 934,
		w: 92,
		h: 88
	},
	{
		x: 1296,
		y: 934,
		w: 92,
		h: 88
	},
	{
		x: 436,
		y: 675,
		w: 92,
		h: 88
	},
	{
		x: 541,
		y: 673,
		w: 92,
		h: 88
	},
	{
		x: 859,
		y: 679,
		w: 92,
		h: 88
	},
	{
		x: 1101,
		y: 677,
		w: 92,
		h: 88
	},
	{
		x: 1210,
		y: 675,
		w: 92,
		h: 88
	},
	{
		x: 1311,
		y: 675,
		w: 92,
		h: 88
	},
	{
		x: 643,
		y: 413,
		w: 92,
		h: 88
	},
	{
		x: 752,
		y: 413,
		w: 92,
		h: 88
	},
	{
		x: 859,
		y: 413,
		w: 92,
		h: 88
	},
	{
		x: 1112,
		y: 417,
		w: 92,
		h: 88
	},
	{
		x: 1409,
		y: 417,
		w: 92,
		h: 88
	},
	{
		x: 1512,
		y: 417,
		w: 92,
		h: 88
	},
	{
		x: 914,
		y: 160,
		w: 92,
		h: 88
	},
	{
		x: 1019,
		y: 158,
		w: 92,
		h: 88
	},
	{
		x: 1374,
		y: 160,
		w: 92,
		h: 88
	},
	{
		x: 1479,
		y: 158,
		w: 92,
		h: 88
	},
	{
		x: 1781,
		y: 162,
		w: 92,
		h: 88
	}
], gc = [
	{
		x: 117,
		y: 1689,
		w: 130,
		h: 120
	},
	{
		x: 121,
		y: 1831,
		w: 130,
		h: 120
	},
	{
		x: 121,
		y: 1971,
		w: 130,
		h: 120
	}
], _c = [
	{
		x: 138,
		y: 2131,
		w: 100,
		h: 96
	},
	{
		x: 319,
		y: 2135,
		w: 100,
		h: 96
	},
	{
		x: 488,
		y: 2133,
		w: 100,
		h: 96
	},
	{
		x: 660,
		y: 2133,
		w: 100,
		h: 96
	},
	{
		x: 917,
		y: 2135,
		w: 100,
		h: 96
	},
	{
		x: 1126,
		y: 2133,
		w: 100,
		h: 96
	},
	{
		x: 1331,
		y: 2133,
		w: 100,
		h: 96
	},
	{
		x: 1645,
		y: 2135,
		w: 100,
		h: 96
	},
	{
		x: 1837,
		y: 2135,
		w: 100,
		h: 96
	},
	{
		x: 2071,
		y: 2133,
		w: 100,
		h: 96
	}
], vc = [
	{
		x: 341,
		y: 1985,
		w: 80,
		h: 40
	},
	{
		x: 506,
		y: 1983,
		w: 80,
		h: 40
	},
	{
		x: 680,
		y: 1983,
		w: 80,
		h: 40
	},
	{
		x: 337,
		y: 2067,
		w: 80,
		h: 40
	},
	{
		x: 504,
		y: 2067,
		w: 80,
		h: 40
	},
	{
		x: 684,
		y: 2067,
		w: 80,
		h: 40
	},
	{
		x: 935,
		y: 1985,
		w: 80,
		h: 40
	},
	{
		x: 1144,
		y: 1983,
		w: 80,
		h: 40
	},
	{
		x: 1350,
		y: 1983,
		w: 80,
		h: 40
	},
	{
		x: 935,
		y: 2065,
		w: 80,
		h: 40
	},
	{
		x: 1148,
		y: 2067,
		w: 80,
		h: 40
	},
	{
		x: 1352,
		y: 2067,
		w: 80,
		h: 40
	}
], yc = [
	{
		x: 1825,
		y: 1854,
		w: 90,
		h: 90
	},
	{
		x: 1839,
		y: 1958,
		w: 90,
		h: 90
	},
	{
		x: 1845,
		y: 2040,
		w: 90,
		h: 90
	}
], bc = [
	{
		x: 750,
		y: 1386,
		w: 56,
		h: 60
	},
	{
		x: 1468,
		y: 1386,
		w: 56,
		h: 60
	},
	{
		x: 518,
		y: 1130,
		w: 56,
		h: 60
	},
	{
		x: 984,
		y: 1134,
		w: 56,
		h: 60
	},
	{
		x: 1705,
		y: 1132,
		w: 56,
		h: 60
	},
	{
		x: 756,
		y: 868,
		w: 56,
		h: 60
	},
	{
		x: 1319,
		y: 872,
		w: 56,
		h: 60
	},
	{
		x: 464,
		y: 611,
		w: 56,
		h: 60
	},
	{
		x: 1234,
		y: 609,
		w: 56,
		h: 60
	},
	{
		x: 778,
		y: 351,
		w: 56,
		h: 60
	},
	{
		x: 1433,
		y: 347,
		w: 56,
		h: 60
	},
	{
		x: 941,
		y: 92,
		w: 56,
		h: 60
	},
	{
		x: 1401,
		y: 96,
		w: 56,
		h: 60
	}
], xc = [
	{
		x: 1033,
		y: 1415,
		w: 64,
		h: 58
	},
	{
		x: 1171,
		y: 1411,
		w: 64,
		h: 58
	},
	{
		x: 1167,
		y: 1544,
		w: 64,
		h: 58
	},
	{
		x: 1267,
		y: 1151,
		w: 64,
		h: 58
	},
	{
		x: 1405,
		y: 1149,
		w: 64,
		h: 58
	},
	{
		x: 1405,
		y: 1279,
		w: 64,
		h: 58
	},
	{
		x: 436,
		y: 891,
		w: 64,
		h: 58
	},
	{
		x: 436,
		y: 1023,
		w: 64,
		h: 58
	},
	{
		x: 945,
		y: 636,
		w: 64,
		h: 58
	},
	{
		x: 949,
		y: 768,
		w: 64,
		h: 58
	},
	{
		x: 1198,
		y: 376,
		w: 64,
		h: 58
	},
	{
		x: 1200,
		y: 502,
		w: 64,
		h: 58
	},
	{
		x: 1871,
		y: 250,
		w: 64,
		h: 58
	}
], Sc = [
	{
		x: 1932,
		y: 815,
		w: 56,
		h: 56
	},
	{
		x: 2e3,
		y: 813,
		w: 56,
		h: 56
	},
	{
		x: 1932,
		y: 896,
		w: 56,
		h: 56
	},
	{
		x: 1998,
		y: 894,
		w: 56,
		h: 56
	},
	{
		x: 1932,
		y: 974,
		w: 56,
		h: 56
	},
	{
		x: 2e3,
		y: 972,
		w: 56,
		h: 56
	}
], Cc = [
	{
		x: 2146,
		y: 827,
		w: 64,
		h: 64
	},
	{
		x: 2142,
		y: 906,
		w: 64,
		h: 64
	},
	{
		x: 2140,
		y: 980,
		w: 64,
		h: 64
	}
], wc = [
	{
		x: 1682,
		y: 1783,
		w: 60,
		h: 60
	},
	{
		x: 1610,
		y: 1857,
		w: 60,
		h: 60
	},
	{
		x: 1684,
		y: 1857,
		w: 60,
		h: 60
	},
	{
		x: 1614,
		y: 1925,
		w: 60,
		h: 60
	},
	{
		x: 1686,
		y: 1925,
		w: 60,
		h: 60
	},
	{
		x: 1614,
		y: 1995,
		w: 60,
		h: 60
	},
	{
		x: 1690,
		y: 1993,
		w: 60,
		h: 60
	},
	{
		x: 1612,
		y: 2063,
		w: 60,
		h: 60
	},
	{
		x: 1690,
		y: 2061,
		w: 60,
		h: 60
	}
], Tc = [
	{
		x: 315,
		y: 1520,
		w: 56,
		h: 56
	},
	{
		x: 386,
		y: 1476,
		w: 56,
		h: 56
	},
	{
		x: 314,
		y: 1430,
		w: 56,
		h: 56
	},
	{
		x: 191,
		y: 1266,
		w: 56,
		h: 56
	},
	{
		x: 259,
		y: 1220,
		w: 56,
		h: 56
	},
	{
		x: 189,
		y: 1174,
		w: 56,
		h: 56
	},
	{
		x: 173,
		y: 1008,
		w: 56,
		h: 56
	},
	{
		x: 247,
		y: 962,
		w: 56,
		h: 56
	},
	{
		x: 175,
		y: 916,
		w: 56,
		h: 56
	},
	{
		x: 273,
		y: 699,
		w: 56,
		h: 56
	},
	{
		x: 204,
		y: 655,
		w: 56,
		h: 56
	},
	{
		x: 526,
		y: 443,
		w: 56,
		h: 56
	},
	{
		x: 458,
		y: 397,
		w: 56,
		h: 56
	},
	{
		x: 754,
		y: 186,
		w: 56,
		h: 56
	}
], Ec = [
	{
		x: 1015,
		y: 1462,
		w: 44,
		h: 96
	},
	{
		x: 1275,
		y: 1462,
		w: 44,
		h: 96
	},
	{
		x: 516,
		y: 1354,
		w: 96,
		h: 44
	},
	{
		x: 861,
		y: 1350,
		w: 96,
		h: 44
	},
	{
		x: 1654,
		y: 1350,
		w: 96,
		h: 44
	},
	{
		x: 787,
		y: 1198,
		w: 44,
		h: 96
	},
	{
		x: 1246,
		y: 1194,
		w: 44,
		h: 96
	},
	{
		x: 1509,
		y: 1196,
		w: 44,
		h: 96
	},
	{
		x: 650,
		y: 1096,
		w: 96,
		h: 44
	},
	{
		x: 1108,
		y: 1092,
		w: 96,
		h: 44
	},
	{
		x: 540,
		y: 936,
		w: 44,
		h: 96
	},
	{
		x: 1025,
		y: 940,
		w: 44,
		h: 96
	},
	{
		x: 627,
		y: 843,
		w: 96,
		h: 44
	},
	{
		x: 1225,
		y: 833,
		w: 96,
		h: 44
	},
	{
		x: 793,
		y: 683,
		w: 44,
		h: 96
	},
	{
		x: 1051,
		y: 685,
		w: 44,
		h: 96
	},
	{
		x: 654,
		y: 575,
		w: 96,
		h: 44
	},
	{
		x: 1379,
		y: 575,
		w: 96,
		h: 44
	},
	{
		x: 1045,
		y: 423,
		w: 44,
		h: 96
	},
	{
		x: 1302,
		y: 423,
		w: 44,
		h: 96
	},
	{
		x: 882,
		y: 317,
		w: 96,
		h: 44
	},
	{
		x: 1568,
		y: 311,
		w: 96,
		h: 44
	},
	{
		x: 1267,
		y: 168,
		w: 44,
		h: 96
	},
	{
		x: 1715,
		y: 166,
		w: 44,
		h: 96
	}
], Dc = [
	{
		x: 1032,
		y: 1538,
		w: 66,
		h: 66
	},
	{
		x: 1268,
		y: 1273,
		w: 66,
		h: 66
	},
	{
		x: 303,
		y: 1019,
		w: 66,
		h: 66
	},
	{
		x: 811,
		y: 764,
		w: 66,
		h: 66
	},
	{
		x: 1063,
		y: 502,
		w: 66,
		h: 66
	},
	{
		x: 1736,
		y: 246,
		w: 66,
		h: 66
	}
];
if (Array.from({ length: 43 }, (e, t) => ({
	id: `c${t}`,
	comment: `格${t + 1}`
})), Array.from({ length: 10 }, (e, t) => ({
	id: `s${t}`,
	comment: `大分槽${t + 1}`
})), Array.from({ length: 12 }, (e, t) => ({
	id: `ss${t}`,
	comment: `小分槽${t + 1}`
})), Array.from({ length: 3 }, (e, t) => ({
	id: `e${t}`,
	comment: `-${(t + 1) * 5}`
})), Array.from({ length: 13 }, (e, t) => ({
	id: `t${t}`,
	comment: `水箱${t + 1}`
})), Array.from({ length: 13 }, (e, t) => ({
	id: `p${t}`,
	comment: `植物${t + 1}`
})), Array.from({ length: 6 }, (e, t) => ({
	id: `ac${t}`,
	comment: `币${t + 1}`
})), Array.from({ length: 3 }, (e, t) => ({
	id: `wg${t}`,
	comment: `万能${t + 1}`
})), Array.from({ length: 9 }, (e, t) => ({
	id: `pl${t}`,
	comment: `规划${t + 1}`
})), Array.from({ length: 14 }, (e, t) => ({
	id: `r${t}`,
	comment: `反应堆${t + 1}`
})), Array.from({ length: 24 }, (e, t) => ({
	id: `a${t}`,
	comment: `气闸${t + 1}`
})), Array.from({ length: 6 }, (e, t) => ({
	id: `x${t}`,
	comment: `温室x2 ${t + 1}`
})), hc.length !== 43) throw Error("cell rects mismatch");
if (gc.length !== 3 || _c.length !== 10 || vc.length !== 12) throw Error("score rects mismatch");
if (yc.length !== 3) throw Error("error rects mismatch");
if (bc.length !== 13) throw Error("tank rects mismatch");
if (xc.length !== 13) throw Error("plant rects mismatch");
if (Sc.length !== 6 || Cc.length !== 3) throw Error("astro/wild rects mismatch");
if (wc.length !== 9) throw Error("planning rects mismatch");
if (Tc.length !== 14) throw Error("reactor rects mismatch");
if (Ec.length !== 24) throw Error("airlock rects mismatch");
if (Dc.length !== 6) throw Error("x2 rects mismatch");
//#endregion
//#region src/games/moon/sheet-view7.tsx
function Oc({ r: e, shade: t = "var(--color-ink)" }) {
	return /* @__PURE__ */ g("ellipse", {
		cx: e.x + e.w / 2,
		cy: e.y + e.h / 2,
		rx: e.w / 2 + 8,
		ry: e.h / 2 + 8,
		fill: "none",
		stroke: t,
		strokeWidth: Math.min(e.w, e.h) * .12,
		pointerEvents: "none"
	});
}
function kc({ sheet: e, missions: t, claims: n, mode: i, onTapCell: a, onTapAirlock: o, readOnly: s, fitKey: c, pulse: l, focus: u }) {
	let d = r(() => {
		if (!s && i) switch (i.kind) {
			case "pick":
			case "planX": return i.cells.map((e) => ({
				key: `c${e}`,
				rect: hc[e]
			}));
			case "airlock": return i.slots.map((e) => ({
				key: `a${e}`,
				rect: Ec[e]
			}));
		}
	}, [s, i]), f = r(() => {
		if (a || o) return (e) => {
			let t = Number(e.slice(1));
			e[0] === "c" ? a?.(t) : o?.(t);
		};
	}, [a, o]);
	return /* @__PURE__ */ _(ee, {
		image: "games/moon/sheet7.webp",
		sheetW: pc,
		sheetH: mc,
		eligible: d,
		onTapEligible: f,
		readOnly: s,
		fitKey: c,
		focus: u,
		children: [
			e.cells.map((e, t) => e === null ? null : e === "x" ? /* @__PURE__ */ g(Q, { r: hc[t] }, t) : /* @__PURE__ */ g(m, {
				r: hc[t],
				text: String(e)
			}, t)),
			e.airlocks.map((e, t) => e ? /* @__PURE__ */ g(Oc, {
				r: Ec[t],
				shade: "#059669"
			}, `a${t}`) : null),
			e.tanks.map((e, t) => e ? /* @__PURE__ */ g(Oc, {
				r: bc[t],
				shade: "#0369a1"
			}, `t${t}`) : null),
			e.reactors.map((e, t) => e ? /* @__PURE__ */ g(Oc, {
				r: Tc[t],
				shade: "#d97706"
			}, `r${t}`) : null),
			e.plants.map((e, t) => e ? /* @__PURE__ */ g(Oc, {
				r: xc[t],
				shade: "#166534"
			}, `p${t}`) : null),
			e.x2.map((e, t) => e === "circle" ? /* @__PURE__ */ g(Oc, {
				r: Dc[t],
				shade: "#166534"
			}, `x${t}`) : e === "cross" ? /* @__PURE__ */ g(Q, {
				r: Dc[t],
				shade: "#166534"
			}, `x${t}`) : null),
			yc.slice(0, e.errors).map((e, t) => /* @__PURE__ */ g("ellipse", {
				cx: e.x + e.w / 2,
				cy: e.y + e.h / 2,
				rx: e.w / 2 + 8,
				ry: e.h / 2 + 8,
				fill: "none",
				stroke: "#dc2626",
				strokeWidth: 7,
				pointerEvents: "none"
			}, `er${t}`)),
			Sc.slice(0, e.astronauts).map((e, t) => /* @__PURE__ */ g(Q, { r: e }, `ac${t}`)),
			Cc.slice(0, e.wilds).map((t, n) => n < e.wildsUsed ? /* @__PURE__ */ g(Q, { r: t }, `wg${n}`) : /* @__PURE__ */ g(Oc, {
				r: t,
				shade: "#059669"
			}, `wg${n}`)),
			wc.slice(0, e.plannings).map((e, t) => /* @__PURE__ */ g(Q, { r: e }, `pl${t}`)),
			gc.map((e, r) => {
				let i = n[r];
				if (!i) return null;
				let a = ci[t[r]], o = i === "high" ? a.hi : a.lo;
				return /* @__PURE__ */ _("g", {
					pointerEvents: "none",
					children: [/* @__PURE__ */ g("rect", {
						x: e.x - 5,
						y: e.y - 5,
						width: e.w + 10,
						height: e.h + 10,
						rx: 16,
						fill: "none",
						stroke: i === "high" ? "#059669" : "#0284c7",
						strokeWidth: 7
					}), /* @__PURE__ */ g(m, {
						r: e,
						text: String(o)
					})]
				}, `ms${r}`);
			}),
			l?.rects.map((e, t) => /* @__PURE__ */ g("rect", {
				x: e.x - 12,
				y: e.y - 12,
				width: e.w + 24,
				height: e.h + 24,
				rx: 20,
				fill: "none",
				stroke: "#f59e0b",
				strokeWidth: 10,
				strokeOpacity: 0,
				pointerEvents: "none",
				children: /* @__PURE__ */ g("animate", {
					attributeName: "stroke-opacity",
					values: "0.95;0.1;0.95;0.1;0.95",
					keyTimes: "0;0.25;0.5;0.75;1",
					dur: "1.3s",
					begin: `${t * .12}s`,
					repeatCount: "1"
				})
			}, `${l.key}:${t}`))
		]
	});
}
//#endregion
//#region src/games/moon/view-player.tsx
var $ = {
	robot: "games.moon.act.robot",
	energy: "games.moon.act.energy",
	plant: "games.moon.act.plant",
	water: "games.moon.act.water",
	astronaut: "games.moon.act.astronaut",
	planning: "games.moon.act.planning"
}, Ac = {
	robot: "🤖",
	energy: "⚡",
	plant: "🌱",
	water: "💧",
	astronaut: "🧑‍🚀",
	planning: "📋"
}, jc = [
	"robot",
	"energy",
	"plant",
	"water",
	"astronaut",
	"planning"
], Mc = {
	64: "games.moon.mission.m64",
	65: "games.moon.mission.m65",
	66: "games.moon.mission.m66",
	67: "games.moon.mission.m67",
	68: "games.moon.mission.m68",
	69: "games.moon.mission.m69"
}, Nc = {
	70: "games.moon.mission.m70",
	71: "games.moon.mission.m71",
	72: "games.moon.mission.m72",
	73: "games.moon.mission.m73",
	74: "games.moon.mission.m74",
	75: "games.moon.mission.m75"
}, Pc = {
	76: "games.moon.mission.m76",
	77: "games.moon.mission.m77",
	78: "games.moon.mission.m78",
	79: "games.moon.mission.m79",
	80: "games.moon.mission.m80",
	81: "games.moon.mission.m81"
}, Fc = {
	82: "games.moon.mission.m82",
	83: "games.moon.mission.m83",
	84: "games.moon.mission.m84",
	85: "games.moon.mission.m85",
	86: "games.moon.mission.m86",
	87: "games.moon.mission.m87"
}, Ic = {
	88: "games.moon.mission.m88",
	89: "games.moon.mission.m89",
	90: "games.moon.mission.m90",
	91: "games.moon.mission.m91",
	92: "games.moon.mission.m92",
	93: "games.moon.mission.m93"
}, Lc = {
	94: "games.moon.mission.m94",
	95: "games.moon.mission.m95",
	96: "games.moon.mission.m96",
	97: "games.moon.mission.m97",
	98: "games.moon.mission.m98",
	99: "games.moon.mission.m99"
}, Rc = {
	100: "games.moon.mission.m100",
	101: "games.moon.mission.m101",
	102: "games.moon.mission.m102",
	103: "games.moon.mission.m103",
	104: "games.moon.mission.m104",
	105: "games.moon.mission.m105"
}, zc = 1700;
function Bc() {
	let [e, t] = a(null), [n, r] = a(null), o = i(0);
	return {
		pulse: e,
		focus: n,
		fire: (e) => {
			if (e.length === 0) return;
			let n = /* @__PURE__ */ new Set(), i = e.filter((e) => {
				let t = `${e.x},${e.y}`;
				return !n.has(t) && (n.add(t), !0);
			});
			o.current += 1;
			let a = o.current, s = Math.min(...i.map((e) => e.x)), c = Math.min(...i.map((e) => e.y));
			t({
				rects: i,
				key: a
			}), r({
				rect: {
					x: s,
					y: c,
					w: Math.max(...i.map((e) => e.x + e.w)) - s,
					h: Math.max(...i.map((e) => e.y + e.h)) - c
				},
				key: a,
				returnAfterMs: zc
			}), setTimeout(() => t((e) => e?.key === a ? null : e), zc);
		}
	};
}
function Vc(e) {
	let t = i(null), [r, o] = a("");
	return n(() => {
		let e = t.current;
		if (!e) return;
		let n = new ResizeObserver(() => o(`${e.clientWidth}x${e.clientHeight}`));
		return n.observe(e), () => n.disconnect();
	}, []), {
		ref: t,
		fitKey: `${e}:${r}`
	};
}
function Hc(e) {
	return /* @__PURE__ */ g(l, {
		adaptive: !0,
		scroll: !1,
		className: "moon-screen",
		children: /* @__PURE__ */ g(Uc, { ...e })
	});
}
function Uc(e) {
	let t = e.public;
	return t.adv === 2 ? /* @__PURE__ */ g(Jc, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	}) : t.adv === 3 ? /* @__PURE__ */ g(Kc, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	}) : t.adv === 4 ? /* @__PURE__ */ g(Yc, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	}) : t.adv === 5 ? /* @__PURE__ */ g(Xc, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	}) : t.adv === 6 ? /* @__PURE__ */ g(Zc, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	}) : t.adv === 7 ? /* @__PURE__ */ g(Qc, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	}) : /* @__PURE__ */ g(Wc, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Wc({ pub: e, members: t, myRid: o, send: s }) {
	let l = c(), [f, p] = a(o), { ref: m, fitKey: ee } = Vc(f), [h, v] = a(null), y = e.sheets[o], b = e.sheets[f] ?? y, x = e.picks[o], te = (e) => t.find((t) => t.rid === e)?.name ?? e, S = e.phase === "done", C = x?.queue[0], T = !!x && (x.combo !== null || x.error), E = T && x.queue.length === 0, D = !S && f === o && !!y && !!x, O = e.missionClaims[o], k = i(null), { pulse: A, focus: j, fire: M } = Bc();
	n(() => {
		if (f !== o || !y || !O) {
			k.current = null;
			return;
		}
		let e = k.current;
		if (k.current = {
			sheet: y,
			claims: O
		}, !e) return;
		let t = [];
		for (let n = e.sheet.track; n < y.track; n += 1) t.push(za[n]);
		for (let n = e.sheet.bonus; n < y.bonus; n += 1) t.push(Va[n]);
		for (let n = e.sheet.circled; n < y.circled; n += 1) t.push(La[n]);
		for (let n = e.sheet.cleared; n < y.cleared; n += 1) t.push(La[n]);
		O.forEach((n, r) => {
			n && !e.claims[r] && t.push(Ua[r]);
		}), M(t);
	}, [
		y,
		f,
		o,
		O
	]);
	let N = r(() => {
		if (!D || T || C || h === null || !y) return;
		let t = e.flipped[h];
		return P(y.cells, t.act, t.n);
	}, [
		D,
		T,
		C,
		h,
		y,
		e.flipped
	]), I = D && C === "build", L = r(() => {
		if (D && C === "activate" && y) return w.map((e, t) => ({
			r: e,
			id: t
		})).filter(({ r: e, id: t }) => !y.activated[t] && !F(y.cells, e.quarter)).map(({ id: e }) => e);
	}, [
		D,
		C,
		y
	]), R = r(() => !!y && e.flipped.every((e) => P(y.cells, e.act, e.n).length === 0), [y, e.flipped]), ie = D && (N !== void 0 || I || L !== void 0), z = (e) => {
		if (C === "build") {
			s({
				type: "build",
				cell: e
			});
			return;
		}
		h !== null && (s({
			type: "pick",
			combo: h,
			cell: e
		}), v(null));
	}, B = S ? y?.launched ? {
		tone: "accent",
		text: l("games.moon.launched")
	} : {
		tone: "info",
		text: l("games.moon.scoreAria", { n: y ? ne(y) : 0 })
	} : C === "build" ? {
		tone: "accent",
		text: l("games.moon.buildPrompt")
	} : C === "activate" ? {
		tone: "accent",
		text: l("games.moon.activatePrompt")
	} : T ? {
		tone: "info",
		text: l("games.moon.waitingPick")
	} : {
		tone: "accent",
		text: l("games.moon.pickPrompt")
	};
	return /* @__PURE__ */ _("div", {
		className: "moon-table moon-table-basic",
		children: [/* @__PURE__ */ _("div", {
			className: "moon-sidebar",
			children: [/* @__PURE__ */ _("div", {
				className: "moon-heading",
				children: [/* @__PURE__ */ g(u, {
					tone: B.tone,
					text: B.text,
					accent: Ei.accent,
					chip: `${l("games.moon.turnChip", { n: e.turn })} 🚀${y?.track ?? 0}/31`
				}), /* @__PURE__ */ g(d, {
					members: t.filter((t) => e.players.includes(t.rid)),
					myRid: o,
					variant: "plate",
					status: (t) => {
						let n = e.sheets[t];
						if (!n) return null;
						let r = n.circled - n.cleared;
						return /* @__PURE__ */ _("span", {
							className: "flex items-center gap-1.5 font-mono tabular-nums",
							children: [
								/* @__PURE__ */ g("span", {
									className: "moon-total text-base font-black",
									"aria-label": l("games.moon.scoreAria", { n: ne(n) }),
									children: ne(n)
								}),
								n.launched && /* @__PURE__ */ g("span", {
									"aria-label": l("games.moon.launched"),
									children: "🚀"
								}),
								r > 0 && /* @__PURE__ */ _("span", {
									className: "moon-error text-xs font-bold text-rose-600",
									"aria-label": l("games.moon.errorAria", { n: r }),
									children: ["✕", r]
								})
							]
						});
					},
					action: (t) => {
						if (S) return null;
						let n = e.picks[t];
						return n ? (n.combo !== null || n.error) && n.queue.length === 0 ? "done" : "pending" : null;
					},
					onPick: (e) => p(e),
					picked: (e) => e === f
				})]
			}), /* @__PURE__ */ _("div", {
				className: "moon-controls",
				children: [
					/* @__PURE__ */ g("div", {
						className: "moon-missions",
						children: e.missions.map((t, n) => {
							let r = e.players.filter((t) => e.missionClaims[t]?.[n]);
							return /* @__PURE__ */ _("div", {
								className: "moon-mission frame flex min-w-0 flex-1 items-center gap-1 px-1.5",
								title: l(Mc[t]),
								children: [
									/* @__PURE__ */ g("span", {
										className: "moon-mission-label shrink-0 text-xs font-black",
										children: "ABC"[n]
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-mission-title min-w-0 flex-1 truncate text-[10px] leading-tight",
										children: l(Mc[t])
									}),
									r.map((r) => {
										let i = e.missionClaims[r][n] === "high" ? re[t].hi : re[t].lo;
										return /* @__PURE__ */ _("span", {
											className: "moon-mission-reward shrink-0 text-[10px] font-bold text-emerald-700",
											children: [te(r), l("games.moon.missionReward", { n: i })]
										}, r);
									})
								]
							}, n);
						})
					}),
					/* @__PURE__ */ g("div", {
						className: "moon-combos",
						children: e.flipped.map((e, t) => {
							let n = !!y && P(y.cells, e.act, e.n).length > 0, r = D && !T && !C && n, i = h === t;
							return /* @__PURE__ */ _("button", {
								type: "button",
								disabled: !r,
								onClick: () => v(i ? null : t),
								"aria-label": `${l($[e.act])} ${e.n}`,
								className: `moon-combo card flex min-w-0 flex-1 items-center justify-center gap-1.5 ${i ? "ring-4 ring-sky-400" : ""} ${!r && !i ? "opacity-40" : ""}`,
								children: [
									/* @__PURE__ */ g("span", {
										"aria-hidden": !0,
										className: "moon-combo-icon text-xl",
										children: Ac[e.act]
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-combo-number font-mono text-2xl font-black tabular-nums",
										children: e.n
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-combo-label truncate text-xs font-bold",
										children: l($[e.act])
									})
								]
							}, t);
						})
					}),
					/* @__PURE__ */ _("div", {
						className: "moon-actions",
						children: [
							D && !T && !C && R && /* @__PURE__ */ g("button", {
								type: "button",
								onClick: () => s({ type: "error" }),
								className: "btn-base min-h-11 w-full text-sm font-black text-white bg-rose-500",
								children: l("games.moon.errorBtn")
							}),
							D && C && /* @__PURE__ */ g("button", {
								type: "button",
								onClick: () => s({ type: "skip" }),
								className: "btn-quiet min-h-11 w-full text-sm font-bold",
								children: l("games.moon.skipEffect")
							}),
							D && E && /* @__PURE__ */ g("span", {
								className: "w-full text-center text-sm font-bold text-emerald-700",
								children: x.error ? l("games.moon.tookError") : l("games.moon.wrote")
							})
						]
					})
				]
			})]
		}), /* @__PURE__ */ g("div", {
			ref: m,
			className: "moon-paper frame",
			children: /* @__PURE__ */ g(ko, {
				sheet: b,
				claims: e.missionClaims[f] ?? [
					null,
					null,
					null
				],
				pickCells: N,
				buildMode: I,
				activateTargets: L,
				onTapCell: z,
				onTapRocket: (e) => s({
					type: "activate",
					target: e
				}),
				readOnly: !ie,
				fitKey: ee,
				pulse: f === o ? A : null,
				focus: f === o ? j : null
			})
		})]
	});
}
var Gc = [
	Za,
	Qa,
	$a
].map((e) => e.flatMap((e) => f(e)));
function Kc({ pub: e, members: t, myRid: o, send: s }) {
	let l = c(), [f, p] = a(o), { ref: m, fitKey: ee } = Vc(f), [h, v] = a(null), [y, b] = a(null), x = e.sheets[o], te = e.sheets[f] ?? x, S = e.picks[o], C = (e) => t.find((t) => t.rid === e)?.name ?? e, w = e.phase === "done", T = S?.queue[0], E = !!S && (S.combo !== null || S.error), D = E && S.queue.length === 0, O = !w && f === o && !!x && !!S, [k, A] = a(e.turn);
	k !== e.turn && (A(e.turn), v(null), b(null));
	let j = h === null ? null : e.flipped[h], M = !!x && j?.act === "astronaut" && x.astronauts < 9, N = M ? y : null, P = j ? j.n + (N ?? 0) : 0, F = r(() => {
		let t = te;
		return t ? t.quarterTurn.map((t, n) => t === -1 ? null : t === Math.min(...e.players.map((t) => e.sheets[t].quarterTurn[n]).filter((e) => e !== -1)) ? "high" : "low") : [
			null,
			null,
			null,
			null
		];
	}, [
		te,
		e.players,
		e.sheets
	]), I = e.missionClaims[o], L = i(null), { pulse: R, focus: ne, fire: re } = Bc();
	n(() => {
		if (f !== o || !x || !I) {
			L.current = null;
			return;
		}
		let e = L.current;
		if (L.current = {
			sheet: x,
			claims: I
		}, !e) return;
		let t = e.sheet, n = [];
		x.tanks.forEach((e, r) => {
			e && !t.tanks[r] && n.push(Ja[r]);
		}), x.antennas.forEach((e, r) => {
			e && !t.antennas[r] && n.push(qa[r]);
		}), x.greenhouses.forEach((e, r) => {
			e && !t.greenhouses[r] && n.push(Ya[r]);
		}), x.tunnels.forEach((e, r) => {
			e && !t.tunnels[r] && n.push(ao(r));
		}), Gc.forEach((e, r) => {
			let i = r === 0 ? t.trackPlant : r === 1 ? t.trackWater : t.trackAntenna, a = r === 0 ? x.trackPlant : r === 1 ? x.trackWater : x.trackAntenna;
			for (let t = i; t < a; t += 1) n.push(e[t]);
		});
		for (let e = t.astronauts; e < x.astronauts; e += 1) n.push(no[e]);
		for (let e = t.planning; e < x.planning; e += 1) n.push(ro[e]);
		for (let e = t.errors; e < x.errors; e += 1) n.push(io[e]);
		I.forEach((t, r) => {
			t && !e.claims[r] && n.push(to[r]);
		}), re(n);
	}, [
		x,
		f,
		o,
		I
	]);
	let ie = r(() => {
		if (O && !E && !T && h !== null && x) return Ce(x.cells, P);
	}, [
		O,
		E,
		T,
		h,
		x,
		P
	]), z = r(() => {
		if (O && T === "robot" && x) return Te(x.tunnels);
	}, [
		O,
		T,
		x
	]), B = r(() => {
		if (O && T === "energy" && x) return [
			x.trackPlant,
			x.trackWater,
			x.trackAntenna
		].flatMap((e, t) => e < 4 ? [t] : []);
	}, [
		O,
		T,
		x
	]), V = (() => {
		if (O) {
			if (T === "robot" && z) return {
				kind: "tunnel",
				edges: z
			};
			if (T === "energy" && B) return {
				kind: "energy",
				tracks: B
			};
			if (T === "planX") return { kind: "planX" };
			if (ie) return {
				kind: "pick",
				cells: ie
			};
		}
	})(), ae = r(() => !!x && e.flipped.every((e) => Ce(x.cells, e.n).length === 0), [x, e.flipped]), H = (e, t) => x ? Ce(x.cells, e).length > 0 ? !0 : t !== "astronaut" || x.astronauts >= 9 ? !1 : qc.some((t) => e + t >= 0 && e + t <= 17 && Ce(x.cells, e + t).length > 0) : !1, oe = (e) => {
		if (T === "planX") {
			s({
				type: "planX",
				cell: e
			});
			return;
		}
		h !== null && (s({
			type: "pick",
			combo: h,
			cell: e,
			...N === null ? {} : { mod: N }
		}), v(null), b(null));
	}, se = w ? {
		tone: "info",
		text: l("games.moon.scoreAria", { n: x ? ze(e.players, e.sheets, e.missions, e.missionClaims, o) : 0 })
	} : T === "robot" ? {
		tone: "accent",
		text: l("games.moon.tunnelPrompt")
	} : T === "energy" ? {
		tone: "accent",
		text: l("games.moon.energyPrompt")
	} : T === "planX" ? {
		tone: "accent",
		text: l("games.moon.planXPrompt")
	} : E ? {
		tone: "info",
		text: l("games.moon.waitingPick")
	} : {
		tone: "accent",
		text: l("games.moon.pickPrompt")
	};
	return /* @__PURE__ */ _("div", {
		className: "moon-table",
		children: [/* @__PURE__ */ _("div", {
			className: "moon-sidebar",
			children: [/* @__PURE__ */ _("div", {
				className: "moon-heading",
				children: [/* @__PURE__ */ g(u, {
					tone: se.tone,
					text: se.text,
					accent: Ei.accent,
					chip: `${l("games.moon.turnChip", { n: e.turn })} ✕${x?.errors ?? 0}/4`
				}), /* @__PURE__ */ g(d, {
					members: t.filter((t) => e.players.includes(t.rid)),
					myRid: o,
					variant: "plate",
					status: (t) => {
						let n = e.sheets[t];
						if (!n) return null;
						let r = ze(e.players, e.sheets, e.missions, e.missionClaims, t);
						return /* @__PURE__ */ _("span", {
							className: "flex items-center gap-1.5 font-mono tabular-nums",
							children: [/* @__PURE__ */ g("span", {
								className: "moon-total text-base font-black",
								"aria-label": l("games.moon.scoreAria", { n: r }),
								children: r
							}), n.errors > 0 && /* @__PURE__ */ _("span", {
								className: "moon-error text-xs font-bold text-rose-600",
								"aria-label": l("games.moon.errorAria", { n: n.errors }),
								children: ["✕", n.errors]
							})]
						});
					},
					action: (t) => {
						if (w) return null;
						let n = e.picks[t];
						return n ? (n.combo !== null || n.error) && n.queue.length === 0 ? "done" : "pending" : null;
					},
					onPick: (e) => p(e),
					picked: (e) => e === f
				})]
			}), /* @__PURE__ */ _("div", {
				className: "moon-controls",
				children: [
					/* @__PURE__ */ g("div", {
						className: "moon-missions",
						children: e.missions.map((t, n) => {
							let r = e.players.filter((t) => e.missionClaims[t]?.[n]);
							return /* @__PURE__ */ _("div", {
								className: "moon-mission frame flex min-w-0 flex-1 items-center gap-1 px-1.5",
								title: l(Pc[t]),
								children: [
									/* @__PURE__ */ g("span", {
										className: "moon-mission-label shrink-0 text-xs font-black",
										children: "ABC"[n]
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-mission-title min-w-0 flex-1 truncate text-[10px] leading-tight",
										children: l(Pc[t])
									}),
									r.map((r) => {
										let i = e.missionClaims[r][n] === "high" ? ke[t].hi : ke[t].lo;
										return /* @__PURE__ */ _("span", {
											className: "moon-mission-reward shrink-0 text-[10px] font-bold text-emerald-700",
											children: [C(r), l("games.moon.missionReward2", { n: i })]
										}, r);
									})
								]
							}, n);
						})
					}),
					/* @__PURE__ */ g("div", {
						className: "moon-combos",
						children: e.flipped.map((e, t) => {
							let n = O && !E && !T && H(e.n, e.act), r = h === t;
							return /* @__PURE__ */ _("button", {
								type: "button",
								disabled: !n,
								onClick: () => {
									v(r ? null : t), b(null);
								},
								"aria-label": `${l($[e.act])} ${e.n}`,
								className: `moon-combo card flex min-w-0 flex-1 items-center justify-center gap-1.5 ${r ? "ring-4 ring-sky-400" : ""} ${!n && !r ? "opacity-40" : ""}`,
								children: [
									/* @__PURE__ */ g("span", {
										"aria-hidden": !0,
										className: "moon-combo-icon text-xl",
										children: Ac[e.act]
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-combo-number font-mono text-2xl font-black tabular-nums",
										children: e.n
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-combo-label truncate text-xs font-bold",
										children: l($[e.act])
									})
								]
							}, t);
						})
					}),
					/* @__PURE__ */ g("div", {
						className: "moon-modifiers",
						children: O && !E && !T && j && M && [null, ...qc].filter((e) => e === null || j.n + e >= 0 && j.n + e <= 17).map((e) => /* @__PURE__ */ g("button", {
							type: "button",
							onClick: () => b(e),
							className: `btn-quiet min-h-11 shrink-0 px-2 font-mono text-sm font-black tabular-nums ${y === e ? "ring-2 ring-sky-400" : ""}`,
							children: e === null ? l("games.moon.modNone") : e === 0 ? "±0" : e > 0 ? `+${e}` : e
						}, e === null ? "none" : e))
					}),
					/* @__PURE__ */ _("div", {
						className: "moon-actions",
						children: [
							O && !E && !T && ae && /* @__PURE__ */ g("button", {
								type: "button",
								onClick: () => s({ type: "error" }),
								className: "btn-base min-h-11 w-full text-sm font-black text-white bg-rose-500",
								children: l("games.moon.errorBtn2")
							}),
							O && T && /* @__PURE__ */ g("button", {
								type: "button",
								onClick: () => s({ type: "skip" }),
								className: "btn-quiet min-h-11 w-full text-sm font-bold",
								children: l("games.moon.skipEffect")
							}),
							O && D && /* @__PURE__ */ g("span", {
								className: "w-full text-center text-sm font-bold text-emerald-700",
								children: S.error ? l("games.moon.tookError") : l("games.moon.wrote")
							})
						]
					})
				]
			})]
		}), /* @__PURE__ */ g("div", {
			ref: m,
			className: "moon-paper frame",
			children: /* @__PURE__ */ g(Bo, {
				sheet: te,
				missions: e.missions,
				claims: e.missionClaims[f] ?? [
					null,
					null,
					null
				],
				quarterLevels: F,
				mode: V,
				onTapCell: oe,
				onTapTunnel: (e) => s({
					type: "tunnel",
					edge: e
				}),
				onTapTrack: (e) => s({
					type: "energy",
					track: e
				}),
				readOnly: !V,
				fitKey: ee,
				pulse: f === o ? R : null,
				focus: f === o ? ne : null
			})
		})]
	});
}
var qc = [
	-2,
	-1,
	0,
	1,
	2
];
function Jc({ pub: e, members: t, myRid: o, send: s }) {
	let l = c(), [f, p] = a(o), { ref: m, fitKey: ee } = Vc(f), [v, y] = a(null), [b, x] = a(null), [te, S] = a(!1), [C, w] = a(null), T = e.sheets[o], E = e.sheets[f] ?? T, D = e.picks[o], O = (e) => t.find((t) => t.rid === e)?.name ?? e, k = e.phase === "done", A = D?.queue[0], j = !!D && (D.combo !== null || D.error), M = j && D.queue.length === 0, N = !k && f === o && !!T && !!D, P = T ? T.wilds - T.wildsUsed : 0, [F, I] = a(e.turn);
	F !== e.turn && (I(e.turn), y(null), x(null), w(null), S(!1));
	let L = v === null ? null : e.flipped[v], R = L ? C ?? L.act : null, ne = !!T && R === "astronaut" && T.astronauts < 6, re = ne ? b : null, ie = L ? L.n + (re ?? 0) : 0, z = e.missionClaims[o], B = i(null), { pulse: V, focus: ae, fire: H } = Bc();
	n(() => {
		if (f !== o || !T || !z) {
			B.current = null;
			return;
		}
		let e = B.current;
		if (B.current = {
			sheet: T,
			claims: z
		}, !e) return;
		let t = e.sheet, n = [];
		T.tanks.forEach((e, r) => {
			e && !t.tanks[r] && n.push(lo[r]);
		}), T.splits.forEach((e, r) => {
			e && !t.splits[r] && n.push(To(r));
		});
		let r = t.energyPairs * 2 + +!!t.energyPending, i = T.energyPairs * 2 + +!!T.energyPending;
		for (let e = r; e < i; e += 1) n.push(Ao[e]);
		for (let e = t.errors; e < T.errors; e += 1) n.push(_o[e]);
		T.stations.forEach((e, r) => {
			for (let i = t.stations[r].robots; i < e.robots; i += 1) n.push(Co[r][i]);
			for (let i = t.stations[r].plants; i < e.plants; i += 1) n.push(wo[r][i]);
			e.mult && !t.stations[r].mult && n.push(So[r]);
		});
		for (let e = t.astronauts; e < T.astronauts; e += 1) n.push(po[e]);
		for (let e = t.plannings; e < T.plannings; e += 1) n.push(ho[e]);
		z.forEach((t, r) => {
			t && !e.claims[r] && n.push(yo[r]);
		}), H(n);
	}, [
		T,
		f,
		o,
		z
	]);
	let oe = r(() => {
		if (N && !j && !A && v !== null && T) return xn(T.cells, T.splits, ie);
	}, [
		N,
		j,
		A,
		v,
		T,
		ie
	]), se = r(() => {
		if (N && A === "robot" && T) return J.map((e, t) => t).filter((e) => T.stations[e].robots < J[e].robots);
	}, [
		N,
		A,
		T
	]), ce = r(() => {
		if (N && A === "plant" && T && D.cell !== null) return Sn(T.splits, D.cell).filter((e) => T.stations[e].plants < J[e].plants);
	}, [
		N,
		A,
		T,
		D
	]), le = (() => {
		if (N) {
			if (A === "robot" && se) return {
				kind: "robot",
				stations: se
			};
			if (A === "plant" && ce) return {
				kind: "plant",
				stations: ce
			};
			if (A === "planX") return { kind: "planX" };
			if (A === "split") return { kind: "split" };
			if (oe) return {
				kind: "pick",
				cells: oe
			};
		}
	})(), ue = r(() => !!T && e.flipped.every((e) => xn(T.cells, T.splits, e.n).length === 0), [T, e.flipped]), de = (e, t) => T ? xn(T.cells, T.splits, e).length > 0 ? !0 : T.astronauts >= 6 || t !== "astronaut" && P <= 0 ? !1 : qc.some((t) => e + t >= 0 && e + t <= 17 && xn(T.cells, T.splits, e + t).length > 0) : !1, fe = (e) => {
		if (A === "planX") {
			s({
				type: "planX",
				cell: e
			});
			return;
		}
		v !== null && (s({
			type: "pick",
			combo: v,
			cell: e,
			...re === null ? {} : { mod: re },
			...C ? { wild: C } : {}
		}), y(null), x(null), w(null), S(!1));
	}, pe = (e) => {
		A === "robot" ? s({
			type: "robot",
			station: e
		}) : A === "plant" && s({
			type: "plant",
			station: e
		});
	}, me = (e) => s({
		type: "split",
		gap: e
	}), he = k ? {
		tone: "info",
		text: l("games.moon.scoreAria", { n: T ? Hn(e.players, e.sheets, e.missions, e.missionClaims, o) : 0 })
	} : A === "robot" ? {
		tone: "accent",
		text: l("games.moon.robotPrompt")
	} : A === "plant" ? {
		tone: "accent",
		text: l("games.moon.plantPrompt")
	} : A === "planX" ? {
		tone: "accent",
		text: l("games.moon.planXPrompt")
	} : A === "split" ? {
		tone: "accent",
		text: l("games.moon.splitPrompt")
	} : j ? {
		tone: "info",
		text: l("games.moon.waitingPick")
	} : {
		tone: "accent",
		text: l("games.moon.pickPrompt")
	};
	return /* @__PURE__ */ _("div", {
		className: "moon-table",
		children: [/* @__PURE__ */ _("div", {
			className: "moon-sidebar",
			children: [/* @__PURE__ */ _("div", {
				className: "moon-heading",
				children: [/* @__PURE__ */ g(u, {
					tone: he.tone,
					text: he.text,
					accent: Ei.accent,
					chip: `${l("games.moon.turnChip", { n: e.turn })} ✕${T?.errors ?? 0}/4`
				}), /* @__PURE__ */ g(d, {
					members: t.filter((t) => e.players.includes(t.rid)),
					myRid: o,
					variant: "plate",
					status: (t) => {
						let n = e.sheets[t];
						if (!n) return null;
						let r = Hn(e.players, e.sheets, e.missions, e.missionClaims, t);
						return /* @__PURE__ */ _("span", {
							className: "flex items-center gap-1.5 font-mono tabular-nums",
							children: [/* @__PURE__ */ g("span", {
								className: "moon-total text-base font-black",
								"aria-label": l("games.moon.scoreAria", { n: r }),
								children: r
							}), n.errors > 0 && /* @__PURE__ */ _("span", {
								className: "moon-error text-xs font-bold text-rose-600",
								"aria-label": l("games.moon.errorAria", { n: n.errors }),
								children: ["✕", n.errors]
							})]
						});
					},
					action: (t) => {
						if (k) return null;
						let n = e.picks[t];
						return n ? (n.combo !== null || n.error) && n.queue.length === 0 ? "done" : "pending" : null;
					},
					onPick: (e) => p(e),
					picked: (e) => e === f
				})]
			}), /* @__PURE__ */ _("div", {
				className: "moon-controls",
				children: [
					/* @__PURE__ */ g("div", {
						className: "moon-missions",
						children: e.missions.map((t, n) => {
							let r = e.players.filter((t) => e.missionClaims[t]?.[n]);
							return /* @__PURE__ */ _("div", {
								className: "moon-mission frame flex min-w-0 flex-1 items-center gap-1 px-1.5",
								title: l(Nc[t]),
								children: [
									/* @__PURE__ */ g("span", {
										className: "moon-mission-label shrink-0 text-xs font-black",
										children: "ABC"[n]
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-mission-title min-w-0 flex-1 truncate text-[10px] leading-tight",
										children: l(Nc[t])
									}),
									r.map((r) => {
										let i = e.missionClaims[r][n] === "high" ? En[t].hi : En[t].lo;
										return /* @__PURE__ */ _("span", {
											className: "moon-mission-reward shrink-0 text-[10px] font-bold text-emerald-700",
											children: [O(r), l("games.moon.missionReward2", { n: i })]
										}, r);
									})
								]
							}, n);
						})
					}),
					/* @__PURE__ */ g("div", {
						className: "moon-combos",
						children: e.flipped.map((e, t) => {
							let n = N && !j && !A && de(e.n, e.act), r = v === t;
							return /* @__PURE__ */ _("button", {
								type: "button",
								disabled: !n,
								onClick: () => {
									y(r ? null : t), x(null), w(null), S(!1);
								},
								"aria-label": `${l($[e.act])} ${e.n}`,
								className: `moon-combo card flex min-w-0 flex-1 items-center justify-center gap-1.5 ${r ? "ring-4 ring-sky-400" : ""} ${!n && !r ? "opacity-40" : ""}`,
								children: [
									/* @__PURE__ */ g("span", {
										"aria-hidden": !0,
										className: "moon-combo-icon text-xl",
										children: Ac[e.act]
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-combo-number font-mono text-2xl font-black tabular-nums",
										children: e.n
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-combo-label truncate text-xs font-bold",
										children: l($[e.act])
									})
								]
							}, t);
						})
					}),
					/* @__PURE__ */ _("div", {
						className: "moon-modifiers",
						children: [N && !j && !A && L && te && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("span", {
							className: "shrink-0 text-xs font-bold",
							children: l("games.moon.wildPrompt")
						}), jc.map((e) => /* @__PURE__ */ _("button", {
							type: "button",
							disabled: e === L.act,
							onClick: () => {
								w(e), S(!1), e !== "astronaut" && x(null);
							},
							className: `btn-quiet flex min-h-11 shrink-0 items-center gap-1 px-2 text-xs font-bold ${e === L.act ? "opacity-40" : ""}`,
							children: [/* @__PURE__ */ g("span", {
								"aria-hidden": !0,
								children: Ac[e]
							}), l($[e])]
						}, e))] }), N && !j && !A && L && !te && /* @__PURE__ */ _(h, { children: [P > 0 && /* @__PURE__ */ _("button", {
							type: "button",
							onClick: () => S(!0),
							className: `btn-quiet flex min-h-11 shrink-0 items-center gap-1 px-2 text-xs font-bold ${C ? "ring-2 ring-sky-400" : ""}`,
							children: [
								"⚙ ",
								l("games.moon.wildBtn"),
								" ×",
								P,
								C && /* @__PURE__ */ _("span", { children: [
									"→",
									Ac[C],
									l($[C])
								] })
							]
						}), ne && [null, ...qc].filter((e) => e === null || L.n + e >= 0 && L.n + e <= 17).map((e) => /* @__PURE__ */ g("button", {
							type: "button",
							onClick: () => x(e),
							className: `btn-quiet min-h-11 shrink-0 px-2 font-mono text-sm font-black tabular-nums ${b === e ? "ring-2 ring-sky-400" : ""}`,
							children: e === null ? l("games.moon.modNone") : e === 0 ? "±0" : e > 0 ? `+${e}` : e
						}, e === null ? "none" : e))] })]
					}),
					/* @__PURE__ */ _("div", {
						className: "moon-actions",
						children: [
							N && !j && !A && ue && /* @__PURE__ */ g("button", {
								type: "button",
								onClick: () => s({ type: "error" }),
								className: "btn-base min-h-11 w-full text-sm font-black text-white bg-rose-500",
								children: l("games.moon.errorBtn2")
							}),
							N && A && A !== "split" && /* @__PURE__ */ g("button", {
								type: "button",
								onClick: () => s({ type: "skip" }),
								className: "btn-quiet min-h-11 w-full text-sm font-bold",
								children: l("games.moon.skipEffect")
							}),
							N && M && /* @__PURE__ */ g("span", {
								className: "w-full text-center text-sm font-bold text-emerald-700",
								children: D.error ? l("games.moon.tookError") : l("games.moon.wrote")
							})
						]
					})
				]
			})]
		}), /* @__PURE__ */ g("div", {
			ref: m,
			className: "moon-paper frame",
			children: /* @__PURE__ */ g(Fo, {
				sheet: E,
				missions: e.missions,
				claims: e.missionClaims[f] ?? [
					null,
					null,
					null
				],
				mode: le,
				onTapCell: fe,
				onTapStation: pe,
				onTapGap: me,
				readOnly: !le,
				fitKey: ee,
				pulse: f === o ? V : null,
				focus: f === o ? ae : null
			})
		})]
	});
}
function Yc({ pub: e, members: t, myRid: o, send: s }) {
	let l = c(), [f, p] = a(o), { ref: m, fitKey: ee } = Vc(f), [h, v] = a(null), [y, b] = a(null), x = e.sheets[o], te = e.sheets[f] ?? x, S = e.picks[o], C = (e) => t.find((t) => t.rid === e)?.name ?? e, w = e.phase === "done", T = S?.queue[0], E = !!S && (S.combo !== null || S.error), D = E && S.queue.length === 0, O = !w && f === o && !!x && !!S, [k, A] = a(e.turn);
	k !== e.turn && (A(e.turn), v(null), b(null));
	let j = h === null ? null : e.flipped[h], M = !!x && j?.act === "astronaut" && x.circled[4] < W[4].slots, N = M ? y : null, P = j ? j.n + (N ?? 0) : 0, F = e.missionClaims[o], I = i(null), { pulse: L, focus: R, fire: ne } = Bc();
	n(() => {
		if (f !== o || !x || !F) {
			I.current = null;
			return;
		}
		let e = I.current;
		if (I.current = {
			sheet: x,
			claims: F
		}, !e) return;
		let t = e.sheet, n = [];
		x.minerals.forEach((e, r) => {
			e !== t.minerals[r] && n.push(Uo[r]);
		}), x.stems.forEach((e, r) => {
			e !== t.stems[r] && n.push(Wo[r]);
		}), x.pumps.forEach((e, r) => {
			e && !t.pumps[r] && n.push(Go[r]);
		}), W.forEach((e, r) => {
			for (let e = t.circled[r]; e < x.circled[r]; e += 1) n.push(Ko[r][e]);
			for (let e = t.bolts[r]; e < x.bolts[r]; e += 1) n.push(Yo[as[r] + e]);
			for (let e = t.robots[r]; e < x.robots[r]; e += 1) n.push(Xo[os[r] + e]);
			x.upgraded[r] && !t.upgraded[r] && n.push(qo[r]), r < 4 && x.badge[r] && !t.badge[r] && n.push(Jo[r]);
		}), G.forEach((e, r) => {
			for (let e = t.subBolts[r]; e < x.subBolts[r]; e += 1) n.push(Zo[ss[r] + e]);
			for (let e = t.subRobots[r]; e < x.subRobots[r]; e += 1) n.push(Qo[cs[r] + e]);
			x.subUsed[r] && !t.subUsed[r] && n.push($o[r]);
		});
		for (let e = t.errors; e < x.errors; e += 1) n.push(ts[e]);
		F.forEach((t, r) => {
			t && !e.claims[r] && n.push(es[r]);
		}), ne(n);
	}, [
		x,
		f,
		o,
		F
	]);
	let re = r(() => {
		if (O && !E && !T && h !== null && x) return $e(x.cells, P);
	}, [
		O,
		E,
		T,
		h,
		x,
		P
	]), ie = r(() => {
		if (O && T?.k === "stem" && x && S.cell !== null) return et(S.cell).filter((e) => Ye[e] === T.res && x.stems[e] === 0);
	}, [
		O,
		T,
		x,
		S
	]), z = r(() => {
		if (!O || T?.k !== "cross" || !x) return;
		let e = [];
		return W.forEach((t, n) => {
			(T.sym === "bolt" ? t.bolts - x.bolts[n] : t.robots - x.robots[n]) > 0 && e.push(n);
		}), G.forEach((t, n) => {
			(T.sym === "bolt" ? t.bolts - x.subBolts[n] : t.robots - x.subRobots[n]) > 0 && e.push(6 + n);
		}), e;
	}, [
		O,
		T,
		x
	]), B = (() => {
		if (O) {
			if (T?.k === "stem" && ie) return {
				kind: "stem",
				stems: ie
			};
			if (T?.k === "cross" && z) return {
				kind: "cross",
				sym: T.sym,
				factories: z
			};
			if (T?.k === "planX") return { kind: "planX" };
			if (re) return {
				kind: "pick",
				cells: re
			};
		}
	})(), V = r(() => !!x && e.flipped.every((e) => $e(x.cells, e.n).length === 0), [x, e.flipped]), ae = (e, t) => x ? $e(x.cells, e).length > 0 ? !0 : t !== "astronaut" || x.circled[4] >= W[4].slots ? !1 : qc.some((t) => e + t >= 0 && e + t <= 17 && $e(x.cells, e + t).length > 0) : !1, H = (e) => {
		if (T?.k === "planX") {
			s({
				type: "planX",
				cell: e
			});
			return;
		}
		h !== null && (s({
			type: "pick",
			combo: h,
			cell: e,
			...N === null ? {} : { mod: N }
		}), v(null), b(null));
	}, oe = w ? {
		tone: "info",
		text: l("games.moon.scoreAria", { n: x ? ct(e.sheets, e.missions, e.missionClaims, o) : 0 })
	} : T?.k === "stem" ? {
		tone: "accent",
		text: l("games.moon.stemPrompt")
	} : T?.k === "cross" ? {
		tone: "accent",
		text: l(T.sym === "bolt" ? "games.moon.crossBoltPrompt" : "games.moon.crossRobotPrompt")
	} : T?.k === "planX" ? {
		tone: "accent",
		text: l("games.moon.planXPrompt")
	} : E ? {
		tone: "info",
		text: l("games.moon.waitingPick")
	} : {
		tone: "accent",
		text: l("games.moon.pickPrompt")
	};
	return /* @__PURE__ */ _("div", {
		className: "moon-table",
		children: [/* @__PURE__ */ _("div", {
			className: "moon-sidebar",
			children: [/* @__PURE__ */ _("div", {
				className: "moon-heading",
				children: [/* @__PURE__ */ g(u, {
					tone: oe.tone,
					text: oe.text,
					accent: Ei.accent,
					chip: `${l("games.moon.turnChip", { n: e.turn })} ✕${x?.errors ?? 0}/4`
				}), /* @__PURE__ */ g(d, {
					members: t.filter((t) => e.players.includes(t.rid)),
					myRid: o,
					variant: "plate",
					status: (t) => {
						let n = e.sheets[t];
						if (!n) return null;
						let r = ct(e.sheets, e.missions, e.missionClaims, t);
						return /* @__PURE__ */ _("span", {
							className: "flex items-center gap-1.5 font-mono tabular-nums",
							children: [/* @__PURE__ */ g("span", {
								className: "moon-total text-base font-black",
								"aria-label": l("games.moon.scoreAria", { n: r }),
								children: r
							}), n.errors > 0 && /* @__PURE__ */ _("span", {
								className: "moon-error text-xs font-bold text-rose-600",
								"aria-label": l("games.moon.errorAria", { n: n.errors }),
								children: ["✕", n.errors]
							})]
						});
					},
					action: (t) => {
						if (w) return null;
						let n = e.picks[t];
						return n ? (n.combo !== null || n.error) && n.queue.length === 0 ? "done" : "pending" : null;
					},
					onPick: (e) => p(e),
					picked: (e) => e === f
				})]
			}), /* @__PURE__ */ _("div", {
				className: "moon-controls",
				children: [
					/* @__PURE__ */ g("div", {
						className: "moon-missions",
						children: e.missions.map((t, n) => {
							let r = e.players.filter((t) => e.missionClaims[t]?.[n]);
							return /* @__PURE__ */ _("div", {
								className: "moon-mission frame flex min-w-0 flex-1 items-center gap-1 px-1.5",
								title: l(Fc[t]),
								children: [
									/* @__PURE__ */ g("span", {
										className: "moon-mission-label shrink-0 text-xs font-black",
										children: "ABC"[n]
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-mission-title min-w-0 flex-1 truncate text-[10px] leading-tight",
										children: l(Fc[t])
									}),
									r.map((r) => {
										let i = e.missionClaims[r][n] === "high" ? tt[t].hi : tt[t].lo;
										return /* @__PURE__ */ _("span", {
											className: "moon-mission-reward shrink-0 text-[10px] font-bold text-emerald-700",
											children: [C(r), l("games.moon.missionReward2", { n: i })]
										}, r);
									})
								]
							}, n);
						})
					}),
					/* @__PURE__ */ g("div", {
						className: "moon-combos",
						children: e.flipped.map((e, t) => {
							let n = O && !E && !T && ae(e.n, e.act), r = h === t;
							return /* @__PURE__ */ _("button", {
								type: "button",
								disabled: !n,
								onClick: () => {
									v(r ? null : t), b(null);
								},
								"aria-label": `${l($[e.act])} ${e.n}`,
								className: `moon-combo card flex min-w-0 flex-1 items-center justify-center gap-1.5 ${r ? "ring-4 ring-sky-400" : ""} ${!n && !r ? "opacity-40" : ""}`,
								children: [
									/* @__PURE__ */ g("span", {
										"aria-hidden": !0,
										className: "moon-combo-icon text-xl",
										children: Ac[e.act]
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-combo-number font-mono text-2xl font-black tabular-nums",
										children: e.n
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-combo-label truncate text-xs font-bold",
										children: l($[e.act])
									})
								]
							}, t);
						})
					}),
					/* @__PURE__ */ g("div", {
						className: "moon-modifiers",
						children: O && !E && !T && j && M && [null, ...qc].filter((e) => e === null || j.n + e >= 0 && j.n + e <= 17).map((e) => /* @__PURE__ */ g("button", {
							type: "button",
							onClick: () => b(e),
							className: `btn-quiet min-h-11 shrink-0 px-2 font-mono text-sm font-black tabular-nums ${y === e ? "ring-2 ring-sky-400" : ""}`,
							children: e === null ? l("games.moon.modNone") : e === 0 ? "±0" : e > 0 ? `+${e}` : e
						}, e === null ? "none" : e))
					}),
					/* @__PURE__ */ _("div", {
						className: "moon-actions",
						children: [
							O && !E && !T && V && /* @__PURE__ */ g("button", {
								type: "button",
								onClick: () => s({ type: "error" }),
								className: "btn-base min-h-11 w-full text-sm font-black text-white bg-rose-500",
								children: l("games.moon.errorBtn2")
							}),
							O && T && /* @__PURE__ */ g("button", {
								type: "button",
								onClick: () => s({ type: "skip" }),
								className: "btn-quiet min-h-11 w-full text-sm font-bold",
								children: l("games.moon.skipEffect")
							}),
							O && D && /* @__PURE__ */ g("span", {
								className: "w-full text-center text-sm font-bold text-emerald-700",
								children: S.error ? l("games.moon.tookError") : l("games.moon.wrote")
							})
						]
					})
				]
			})]
		}), /* @__PURE__ */ g("div", {
			ref: m,
			className: "moon-paper frame",
			children: /* @__PURE__ */ g(us, {
				sheet: te,
				missions: e.missions,
				claims: e.missionClaims[f] ?? [
					null,
					null,
					null
				],
				mode: B,
				onTapCell: H,
				onTapStem: (e) => s({
					type: "stem",
					stem: e
				}),
				onTapFactory: (e) => {
					T?.k === "cross" && s({
						type: "cross",
						sym: T.sym,
						factory: e
					});
				},
				readOnly: !B,
				fitKey: ee,
				pulse: f === o ? L : null,
				focus: f === o ? R : null
			})
		})]
	});
}
function Xc({ pub: e, members: t, myRid: o, send: s }) {
	let l = c(), [f, p] = a(o), { ref: m, fitKey: ee } = Vc(f), [h, v] = a(null), [y, b] = a(null), x = e.sheets[o], te = e.sheets[f] ?? x, S = e.picks[o], C = (e) => t.find((t) => t.rid === e)?.name ?? e, w = e.phase === "done", T = S?.queue[0], E = !!S && (S.combo !== null || S.error), D = E && S.queue.length === 0, O = !w && f === o && !!x && !!S, [k, A] = a(e.turn);
	k !== e.turn && (A(e.turn), v(null), b(null));
	let j = h === null ? null : e.flipped[h], M = !!x && j?.act === "astronaut" && x.astronauts < 6, N = M ? y : null, P = j ? j.n + (N ?? 0) : 0, F = e.missionClaims[o], I = i(null), { pulse: L, focus: R, fire: ne } = Bc();
	n(() => {
		if (f !== o || !x || !F) {
			I.current = null;
			return;
		}
		let e = I.current;
		if (I.current = {
			sheet: x,
			claims: F
		}, !e) return;
		let t = e.sheet, n = [];
		x.cells.forEach((e, r) => {
			e !== t.cells[r] && n.push(hs[r]);
		}), x.towerPlants.forEach((e, r) => {
			for (let i = t.towerPlants[r]; i < e; i += 1) n.push(_s[r * 2 + i]);
		}), x.towerWaters.forEach((e, r) => {
			for (let i = t.towerWaters[r]; i < e; i += 1) n.push(vs[r]);
		});
		let r = As(x.dome);
		x.dome.forEach((e, i) => {
			let a = t.dome[i];
			if (!e.built || a?.built) return;
			let o = r[i];
			n.push({
				x: (o.ax + o.bx) / 2 - 64,
				y: (o.ay + o.by) / 2 - 64,
				w: 129,
				h: 129
			});
		});
		for (let e = t.energyMission; e < x.energyMission; e += 1) n.push(bs[e * 2], bs[e * 2 + 1]);
		for (let e = t.energyTower; e < x.energyTower; e += 1) n.push(xs[e * 3], xs[e * 3 + 1], xs[e * 3 + 2]);
		for (let e = t.energyAstro; e < x.energyAstro; e += 1) n.push(Ss[e * 2], Ss[e * 2 + 1]);
		for (let e = t.energyDome; e < x.energyDome; e += 1) n.push(Cs[e]);
		for (let e = t.astronauts; e < x.astronauts; e += 1) n.push(ws[e]);
		x.bonus.forEach((e, r) => {
			e && !t.bonus[r] && n.push(Es[r]);
		});
		for (let e = t.errors; e < x.errors; e += 1) n.push(Ds[e]);
		F.forEach((t, r) => {
			t && !e.claims[r] && n.push(Ts[r]);
		}), ne(n);
	}, [
		x,
		f,
		o,
		F
	]);
	let re = r(() => {
		if (O && !E && !T && h !== null && x) return zt(x.cells, P);
	}, [
		O,
		E,
		T,
		h,
		x,
		P
	]), ie = r(() => {
		if (!O || T?.k !== "dome" || !x || S.cell === null) return;
		let e = x.cells[S.cell];
		if (typeof e == "number") return x.dome.flatMap((t, n) => Vt(x.dome, n, e) ? [n] : []);
	}, [
		O,
		T,
		x,
		S
	]), z = r(() => {
		if (O && T?.k === "cut" && x) return x.dome.flatMap((e, t) => Ut(x.dome, t) ? [t] : []);
	}, [
		O,
		T,
		x
	]), B = r(() => {
		if (!O || T?.k !== "energy" || !x) return;
		let e = [];
		return x.energyMission < 4 && e.push(0), x.energyTower < 4 && e.push(1), x.energyAstro < 4 && e.push(2), x.energyDome < 4 && e.push(3), e;
	}, [
		O,
		T,
		x
	]), V = (() => {
		if (O) {
			if (T?.k === "tower" && S.cell !== null) {
				let e = Et(S.cell % 13);
				if (e >= 0) return {
					kind: "tower",
					level: e,
					res: T.res
				};
			}
			if (T?.k === "dome" && ie) return {
				kind: "dome",
				indices: ie
			};
			if (T?.k === "planX") return { kind: "planX" };
			if (T?.k === "cut" && z) return {
				kind: "cut",
				indices: z
			};
			if (T?.k === "energy" && B) return {
				kind: "energy",
				fields: B
			};
			if (re) return {
				kind: "pick",
				cells: re
			};
		}
	})(), ae = r(() => !!x && e.flipped.every((e) => zt(x.cells, e.n).length === 0), [x, e.flipped]), H = (e, t) => x ? zt(x.cells, e).length > 0 ? !0 : t !== "astronaut" || x.astronauts >= 6 ? !1 : qc.some((t) => e + t >= 0 && e + t <= 17 && zt(x.cells, e + t).length > 0) : !1, oe = (e) => {
		if (T?.k === "planX") {
			s({
				type: "planX",
				cell: e
			});
			return;
		}
		h !== null && (s({
			type: "pick",
			combo: h,
			cell: e,
			...N === null ? {} : { mod: N }
		}), v(null), b(null));
	}, se = w ? {
		tone: "info",
		text: l("games.moon.scoreAria", { n: x ? an(e.players, e.sheets, e.missions, e.missionClaims, o) : 0 })
	} : T?.k === "tower" ? {
		tone: "accent",
		text: l(T.res === "water" ? "games.moon.towerWaterPrompt" : "games.moon.towerPlantPrompt")
	} : T?.k === "dome" ? {
		tone: "accent",
		text: l("games.moon.domeBuildPrompt")
	} : T?.k === "planX" ? {
		tone: "accent",
		text: l("games.moon.planXPrompt")
	} : T?.k === "cut" ? {
		tone: "accent",
		text: l("games.moon.domeCutPrompt")
	} : T?.k === "energy" ? {
		tone: "accent",
		text: l("games.moon.energyUpPrompt")
	} : E ? {
		tone: "info",
		text: l("games.moon.waitingPick")
	} : {
		tone: "accent",
		text: l("games.moon.pickPrompt")
	};
	return /* @__PURE__ */ _("div", {
		className: "moon-table",
		children: [/* @__PURE__ */ _("div", {
			className: "moon-sidebar",
			children: [/* @__PURE__ */ _("div", {
				className: "moon-heading",
				children: [/* @__PURE__ */ g(u, {
					tone: se.tone,
					text: se.text,
					accent: Ei.accent,
					chip: `${l("games.moon.turnChip", { n: e.turn })} ✕${x?.errors ?? 0}/4`
				}), /* @__PURE__ */ g(d, {
					members: t.filter((t) => e.players.includes(t.rid)),
					myRid: o,
					variant: "plate",
					status: (t) => {
						let n = e.sheets[t];
						if (!n) return null;
						let r = an(e.players, e.sheets, e.missions, e.missionClaims, t);
						return /* @__PURE__ */ _("span", {
							className: "flex items-center gap-1.5 font-mono tabular-nums",
							children: [/* @__PURE__ */ g("span", {
								className: "moon-total text-base font-black",
								"aria-label": l("games.moon.scoreAria", { n: r }),
								children: r
							}), n.errors > 0 && /* @__PURE__ */ _("span", {
								className: "moon-error text-xs font-bold text-rose-600",
								"aria-label": l("games.moon.errorAria", { n: n.errors }),
								children: ["✕", n.errors]
							})]
						});
					},
					action: (t) => {
						if (w) return null;
						let n = e.picks[t];
						return n ? (n.combo !== null || n.error) && n.queue.length === 0 ? "done" : "pending" : null;
					},
					onPick: (e) => p(e),
					picked: (e) => e === f
				})]
			}), /* @__PURE__ */ _("div", {
				className: "moon-controls",
				children: [
					/* @__PURE__ */ g("div", {
						className: "moon-missions",
						children: e.missions.map((t, n) => {
							let r = e.players.filter((t) => e.missionClaims[t]?.[n]);
							return /* @__PURE__ */ _("div", {
								className: "moon-mission frame flex min-w-0 flex-1 items-center gap-1 px-1.5",
								title: l(Ic[t]),
								children: [
									/* @__PURE__ */ g("span", {
										className: "moon-mission-label shrink-0 text-xs font-black",
										children: "ABC"[n]
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-mission-title min-w-0 flex-1 truncate text-[10px] leading-tight",
										children: l(Ic[t])
									}),
									r.map((t) => {
										let r = e.missionClaims[t][n], i = Jt(e.sheets[t], r === "high" ? 0 : 1);
										return /* @__PURE__ */ _("span", {
											className: "moon-mission-reward shrink-0 text-[10px] font-bold text-emerald-700",
											children: [C(t), l("games.moon.missionReward2", { n: i })]
										}, t);
									})
								]
							}, n);
						})
					}),
					/* @__PURE__ */ g("div", {
						className: "moon-combos",
						children: e.flipped.map((e, t) => {
							let n = O && !E && !T && H(e.n, e.act), r = h === t;
							return /* @__PURE__ */ _("button", {
								type: "button",
								disabled: !n,
								onClick: () => {
									v(r ? null : t), b(null);
								},
								"aria-label": `${l($[e.act])} ${e.n}`,
								className: `moon-combo card flex min-w-0 flex-1 items-center justify-center gap-1.5 ${r ? "ring-4 ring-sky-400" : ""} ${!n && !r ? "opacity-40" : ""}`,
								children: [
									/* @__PURE__ */ g("span", {
										"aria-hidden": !0,
										className: "moon-combo-icon text-xl",
										children: Ac[e.act]
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-combo-number font-mono text-2xl font-black tabular-nums",
										children: e.n
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-combo-label truncate text-xs font-bold",
										children: l($[e.act])
									})
								]
							}, t);
						})
					}),
					/* @__PURE__ */ g("div", {
						className: "moon-modifiers",
						children: O && !E && !T && j && M && [null, ...qc].filter((e) => e === null || j.n + e >= 0 && j.n + e <= 17).map((e) => /* @__PURE__ */ g("button", {
							type: "button",
							onClick: () => b(e),
							className: `btn-quiet min-h-11 shrink-0 px-2 font-mono text-sm font-black tabular-nums ${y === e ? "ring-2 ring-sky-400" : ""}`,
							children: e === null ? l("games.moon.modNone") : e === 0 ? "±0" : e > 0 ? `+${e}` : e
						}, e === null ? "none" : e))
					}),
					/* @__PURE__ */ _("div", {
						className: "moon-actions",
						children: [
							O && !E && !T && ae && /* @__PURE__ */ g("button", {
								type: "button",
								onClick: () => s({ type: "error" }),
								className: "btn-base min-h-11 w-full text-sm font-black text-white bg-rose-500",
								children: l("games.moon.errorBtn2")
							}),
							O && T && T.k !== "cut" && /* @__PURE__ */ g("button", {
								type: "button",
								onClick: () => s({ type: "skip" }),
								className: "btn-quiet min-h-11 w-full text-sm font-bold",
								children: l("games.moon.skipEffect")
							}),
							O && D && /* @__PURE__ */ g("span", {
								className: "w-full text-center text-sm font-bold text-emerald-700",
								children: S.error ? l("games.moon.tookError") : l("games.moon.wrote")
							})
						]
					})
				]
			})]
		}), /* @__PURE__ */ g("div", {
			ref: m,
			className: "moon-paper frame",
			children: /* @__PURE__ */ g(Ns, {
				sheet: te,
				claims: e.missionClaims[f] ?? [
					null,
					null,
					null
				],
				mode: V,
				onTapCell: oe,
				onTapTower: (e) => s({
					type: "towerSym",
					level: e
				}),
				onTapDome: (e) => {
					T?.k === "dome" ? s({
						type: "domeBuild",
						index: e
					}) : T?.k === "cut" && s({
						type: "domeCut",
						index: e
					});
				},
				onTapEnergy: (e) => s({
					type: "energyUp",
					field: e
				}),
				readOnly: !V,
				fitKey: ee,
				pulse: f === o ? L : null,
				focus: f === o ? R : null
			})
		})]
	});
}
function Zc({ pub: e, members: t, myRid: o, send: s }) {
	let l = c(), [f, p] = a(o), { ref: m, fitKey: ee } = Vc(f), [v, y] = a(null), [b, x] = a(null), [te, S] = a(!1), [C, w] = a(null), [T, E] = a([]), D = e.sheets[o], O = e.sheets[f] ?? D, k = e.picks[o], A = (e) => t.find((t) => t.rid === e)?.name ?? e, j = e.phase === "done", M = e.stage === "grey", N = !!D && D.greyQuarter >= 0, P = k?.queue[0], F = !!k && (k.combo !== null || k.error), I = F && k.queue.length === 0, L = !j && f === o && !!D && !!k, R = D ? D.wilds - D.wildsUsed : 0, ne = `${e.turn}:${e.stage}:${k?.queue.length ?? 0}`, [re, ie] = a(ne);
	re !== ne && (ie(ne), y(null), x(null), w(null), S(!1), E([]));
	let z = v === null ? null : e.flipped[v], B = z ? C ?? z.act : null, V = !!D && B === "astronaut" && D.astronauts < 6, ae = V ? b : null, H = z ? z.n + (ae ?? 0) : 0, oe = e.missionClaims[o], se = i(null), { pulse: ce, focus: le, fire: ue } = Bc();
	n(() => {
		if (f !== o || !D || !oe) {
			se.current = null;
			return;
		}
		let t = se.current;
		if (se.current = {
			sheet: D,
			claims: oe,
			viruses: e.activatedViruses
		}, !t) return;
		let n = t.sheet, r = [];
		D.cells.forEach((e, t) => {
			e !== n.cells[t] && r.push(zs[t]);
		}), D.energy.forEach((e, t) => {
			e && !n.energy[t] && r.push(Ws[t]);
		}), D.walkways.forEach((e, t) => {
			e && !n.walkways[t] && r.push(Ys[t]);
		}), D.plants.forEach((e, t) => {
			e && !n.plants[t] && r.push(Ks[t]);
		}), D.tanks.forEach((e, t) => {
			e && !n.tanks[t] && r.push(qs[t]);
		});
		for (let e = n.plantTrack; e < D.plantTrack; e += 1) r.push(Xs[e]);
		for (let e = n.waterTrack; e < D.waterTrack; e += 1) r.push(Zs[e]);
		D.viruses.forEach((e, t) => {
			e && !n.viruses[t] && Js[t].w > 10 && r.push(Js[t]);
		}), D.virusCrossed.forEach((e, t) => {
			e && !n.virusCrossed[t] && Js[t].w > 10 && r.push(Js[t]);
		}), D.propSlots.forEach((e, t) => {
			e && !n.propSlots[t] && r.push(nc[t]);
		}), e.activatedViruses.forEach((e, n) => {
			e && !t.viruses[n] && r.push(rc[n]);
		}), D.evac.forEach((e, t) => {
			e !== null && n.evac[t] === null && r.push(Gs[t], ac[t]);
		});
		for (let e = n.astronauts; e < D.astronauts; e += 1) r.push(sc[e]);
		for (let e = n.plannings; e < D.plannings; e += 1) r.push(cc[e]);
		for (let e = n.wilds; e < D.wilds; e += 1) r.push(lc[e]);
		for (let e = n.errors; e < D.errors; e += 1) r.push(oc[e]);
		oe.forEach((e, n) => {
			e && !t.claims[n] && r.push(ic[n]);
		}), ue(r);
	}, [
		D,
		f,
		o,
		oe,
		e.activatedViruses
	]);
	let de = r(() => {
		if (L && M && !N && D) return Jn.flatMap((e) => Array.from({ length: 5 }, (t, n) => e * 5 + n)).filter((e) => D.cells[e] === null);
	}, [
		L,
		M,
		N,
		D
	]), fe = r(() => {
		if (!(!L || M || F || P || v === null || !D)) return sr(D.cells, H);
	}, [
		L,
		M,
		F,
		P,
		v,
		D,
		H
	]), pe = r(() => {
		if (L && P?.k === "energy" && D) return Or(D, P.q).map((e) => D.energy[e * 2] ? e * 2 + 1 : e * 2);
	}, [
		L,
		P,
		D
	]), me = r(() => {
		if (L && P?.k === "robot" && D) return D.walkways.flatMap((e, t) => e ? [] : [t]);
	}, [
		L,
		P,
		D
	]), he = r(() => {
		if (L && P?.k === "infect" && D) return gr(D, P.q);
	}, [
		L,
		P,
		D
	]), ge = (() => {
		if (L) {
			if (M) return de ? {
				kind: "grey",
				cells: de
			} : void 0;
			if (P?.k === "energy" && pe) return {
				kind: "energy",
				slots: pe
			};
			if (P?.k === "robot" && me) return {
				kind: "close",
				walks: me
			};
			if (P?.k === "planX") return { kind: "planX" };
			if (P?.k === "infect" && he) return {
				kind: "infect",
				cells: he.flat()
			};
			if (fe) return {
				kind: "pick",
				cells: fe
			};
		}
	})(), _e = r(() => !!D && e.flipped.every((e) => sr(D.cells, e.n).length === 0), [D, e.flipped]), ve = (e, t) => D ? sr(D.cells, e).length > 0 ? !0 : D.astronauts >= 6 || t !== "astronaut" && R <= 0 ? !1 : qc.some((t) => e + t >= 0 && e + t <= 17 && sr(D.cells, e + t).length > 0) : !1, ye = (e) => {
		if (M) {
			s({
				type: "grey",
				cell: e
			});
			return;
		}
		if (P?.k === "infect" && he) {
			let t = he.findIndex((t) => t.includes(e));
			if (t < 0) return;
			let n = he.map((n, r) => r === t ? e : T[r] ?? null);
			n.every((e) => e !== null) ? (s({
				type: "infect",
				cells: n.map((e) => e)
			}), E([])) : E(n);
			return;
		}
		if (P?.k === "planX") {
			s({
				type: "planX",
				cell: e
			});
			return;
		}
		v !== null && (s({
			type: "pick",
			combo: v,
			cell: e,
			...ae === null ? {} : { mod: ae },
			...C ? { wild: C } : {}
		}), y(null), x(null), w(null), S(!1));
	}, be = j ? {
		tone: "info",
		text: l("games.moon.scoreAria", { n: D ? Sr(D) + vr(e.missions, oe ?? [
			null,
			null,
			null
		]) : 0 })
	} : M ? {
		tone: "accent",
		text: l(N ? "games.moon.waitingPick" : "games.moon.greyPrompt")
	} : P?.k === "energy" ? {
		tone: "accent",
		text: l("games.moon.circleEnergyPrompt")
	} : P?.k === "robot" ? {
		tone: "accent",
		text: l("games.moon.closePrompt")
	} : P?.k === "planX" ? {
		tone: "accent",
		text: l("games.moon.planXPrompt")
	} : P?.k === "infect" ? {
		tone: "accent",
		text: l("games.moon.infectPrompt")
	} : F ? {
		tone: "info",
		text: l("games.moon.waitingPick")
	} : {
		tone: "accent",
		text: l("games.moon.pickPrompt")
	};
	return /* @__PURE__ */ _("div", {
		className: "moon-table",
		children: [/* @__PURE__ */ _("div", {
			className: "moon-sidebar",
			children: [/* @__PURE__ */ _("div", {
				className: "moon-heading",
				children: [/* @__PURE__ */ g(u, {
					tone: be.tone,
					text: be.text,
					accent: Ei.accent,
					chip: M ? "🦠" : `${l("games.moon.turnChip", { n: e.turn })} ✕${D?.errors ?? 0}/3`
				}), /* @__PURE__ */ g(d, {
					members: t.filter((t) => e.players.includes(t.rid)),
					myRid: o,
					variant: "plate",
					status: (t) => {
						let n = e.sheets[t];
						if (!n) return null;
						let r = Sr(n) + vr(e.missions, e.missionClaims[t] ?? [
							null,
							null,
							null
						]);
						return /* @__PURE__ */ _("span", {
							className: "flex items-center gap-1.5 font-mono tabular-nums",
							children: [/* @__PURE__ */ g("span", {
								className: "moon-total text-base font-black",
								"aria-label": l("games.moon.scoreAria", { n: r }),
								children: r
							}), n.errors > 0 && /* @__PURE__ */ _("span", {
								className: "moon-error text-xs font-bold text-rose-600",
								"aria-label": l("games.moon.errorAria", { n: n.errors }),
								children: ["✕", n.errors]
							})]
						});
					},
					action: (t) => {
						if (j) return null;
						let n = e.sheets[t], r = e.picks[t];
						return !n || !r ? null : e.stage === "grey" ? n.greyQuarter >= 0 ? "done" : "pending" : (r.combo !== null || r.error) && r.queue.length === 0 ? "done" : "pending";
					},
					onPick: (e) => p(e),
					picked: (e) => e === f
				})]
			}), /* @__PURE__ */ _("div", {
				className: "moon-controls",
				children: [
					/* @__PURE__ */ g("div", {
						className: "moon-missions",
						children: e.missions.map((t, n) => {
							let r = e.players.filter((t) => e.missionClaims[t]?.[n]);
							return /* @__PURE__ */ _("div", {
								className: "moon-mission frame flex min-w-0 flex-1 items-center gap-1 px-1.5",
								title: l(Lc[t]),
								children: [
									/* @__PURE__ */ g("span", {
										className: "moon-mission-label shrink-0 text-xs font-black",
										children: "ABC"[n]
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-mission-title min-w-0 flex-1 truncate text-[10px] leading-tight",
										children: l(Lc[t])
									}),
									r.map((r) => {
										let i = e.missionClaims[r][n], a = nr[t][i === "high" ? 0 : 1];
										return /* @__PURE__ */ _("span", {
											className: "moon-mission-reward shrink-0 text-[10px] font-bold text-emerald-700",
											children: [A(r), l("games.moon.missionReward2", { n: a })]
										}, r);
									})
								]
							}, n);
						})
					}),
					/* @__PURE__ */ g("div", {
						className: "moon-combos",
						children: !M && e.flipped.map((e, t) => {
							let n = L && !F && !P && ve(e.n, e.act), r = v === t;
							return /* @__PURE__ */ _("button", {
								type: "button",
								disabled: !n,
								onClick: () => {
									y(r ? null : t), x(null), w(null), S(!1);
								},
								"aria-label": `${l($[e.act])} ${e.n}`,
								className: `moon-combo card flex min-w-0 flex-1 items-center justify-center gap-1.5 ${r ? "ring-4 ring-sky-400" : ""} ${!n && !r ? "opacity-40" : ""}`,
								children: [
									/* @__PURE__ */ g("span", {
										"aria-hidden": !0,
										className: "moon-combo-icon text-xl",
										children: Ac[e.act]
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-combo-number font-mono text-2xl font-black tabular-nums",
										children: e.n
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-combo-label truncate text-xs font-bold",
										children: l($[e.act])
									})
								]
							}, t);
						})
					}),
					/* @__PURE__ */ _("div", {
						className: "moon-modifiers",
						children: [L && !M && !F && !P && z && te && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("span", {
							className: "shrink-0 text-xs font-bold",
							children: l("games.moon.wildPrompt")
						}), jc.map((e) => /* @__PURE__ */ _("button", {
							type: "button",
							disabled: e === z.act,
							onClick: () => {
								w(e), S(!1), e !== "astronaut" && x(null);
							},
							className: `btn-quiet flex min-h-11 shrink-0 items-center gap-1 px-2 text-xs font-bold ${e === z.act ? "opacity-40" : ""}`,
							children: [/* @__PURE__ */ g("span", {
								"aria-hidden": !0,
								children: Ac[e]
							}), l($[e])]
						}, e))] }), L && !M && !F && !P && z && !te && /* @__PURE__ */ _(h, { children: [R > 0 && /* @__PURE__ */ _("button", {
							type: "button",
							onClick: () => S(!0),
							className: `btn-quiet flex min-h-11 shrink-0 items-center gap-1 px-2 text-xs font-bold ${C ? "ring-2 ring-sky-400" : ""}`,
							children: [
								"⚙ ",
								l("games.moon.wildBtn"),
								" ×",
								R,
								C && /* @__PURE__ */ _("span", { children: [
									"→",
									Ac[C],
									l($[C])
								] })
							]
						}), V && [null, ...qc].filter((e) => e === null || z.n + e >= 0 && z.n + e <= 17).map((e) => /* @__PURE__ */ g("button", {
							type: "button",
							onClick: () => x(e),
							className: `btn-quiet min-h-11 shrink-0 px-2 font-mono text-sm font-black tabular-nums ${b === e ? "ring-2 ring-sky-400" : ""}`,
							children: e === null ? l("games.moon.modNone") : e === 0 ? "±0" : e > 0 ? `+${e}` : e
						}, e === null ? "none" : e))] })]
					}),
					/* @__PURE__ */ _("div", {
						className: "moon-actions",
						children: [
							L && !M && !F && !P && _e && /* @__PURE__ */ g("button", {
								type: "button",
								onClick: () => s({ type: "error" }),
								className: "btn-base min-h-11 w-full text-sm font-black text-white bg-rose-500",
								children: l("games.moon.errorBtn2")
							}),
							L && P && P.k !== "infect" && /* @__PURE__ */ g("button", {
								type: "button",
								onClick: () => s({ type: "skip" }),
								className: "btn-quiet min-h-11 w-full text-sm font-bold",
								children: l("games.moon.skipEffect")
							}),
							L && !M && I && /* @__PURE__ */ g("span", {
								className: "w-full text-center text-sm font-bold text-emerald-700",
								children: k.error ? l("games.moon.tookError") : l("games.moon.wrote")
							})
						]
					})
				]
			})]
		}), /* @__PURE__ */ g("div", {
			ref: m,
			className: "moon-paper frame",
			children: /* @__PURE__ */ g(fc, {
				sheet: O,
				missions: e.missions,
				claims: e.missionClaims[f] ?? [
					null,
					null,
					null
				],
				activatedViruses: e.activatedViruses,
				mode: ge,
				markedCells: P?.k === "infect" ? T.filter((e) => e !== null) : void 0,
				onTapCell: ye,
				onTapWalk: (e) => s({
					type: "close",
					walk: e
				}),
				onTapEnergy: (e) => s({
					type: "circleEnergy",
					quarter: Math.floor(e / 2)
				}),
				readOnly: !ge,
				fitKey: ee,
				pulse: f === o ? ce : null,
				focus: f === o ? le : null
			})
		})]
	});
}
function Qc({ pub: e, members: t, myRid: o, send: s }) {
	let l = c(), [f, p] = a(o), { ref: m, fitKey: ee } = Vc(f), [v, y] = a(null), [b, x] = a(null), [te, S] = a(!1), [C, w] = a(null), T = e.sheets[o], E = e.sheets[f] ?? T, D = e.picks[o], O = (e) => t.find((t) => t.rid === e)?.name ?? e, k = e.phase === "done", A = D?.queue[0], j = !!D && (D.combo !== null || D.error), M = j && D.queue.length === 0, N = !k && f === o && !!T && !!D, P = T ? T.wilds - T.wildsUsed : 0, F = `${e.turn}:${D?.queue.length ?? 0}`, [I, L] = a(F);
	I !== F && (L(F), y(null), x(null), w(null), S(!1));
	let R = v === null ? null : e.flipped[v], ne = R ? C ?? R.act : null, re = !!T && ne === "astronaut" && T.astronauts < 6, ie = re ? b : null, z = R ? R.n + (ie ?? 0) : 0, B = e.missionClaims[o], V = i(null), { pulse: ae, focus: H, fire: oe } = Bc();
	n(() => {
		if (f !== o || !T || !B) {
			V.current = null;
			return;
		}
		let e = V.current;
		if (V.current = {
			sheet: T,
			claims: B
		}, !e) return;
		let t = e.sheet, n = [];
		T.cells.forEach((e, r) => {
			e !== t.cells[r] && n.push(hc[r]);
		}), T.airlocks.forEach((e, r) => {
			e && !t.airlocks[r] && n.push(Ec[r]);
		}), T.tanks.forEach((e, r) => {
			e && !t.tanks[r] && n.push(bc[r]);
		}), T.reactors.forEach((e, r) => {
			e && !t.reactors[r] && n.push(Tc[r]);
		}), T.plants.forEach((e, r) => {
			e && !t.plants[r] && n.push(xc[r]);
		}), T.x2.forEach((e, r) => {
			e !== t.x2[r] && n.push(Dc[r]);
		});
		for (let e = t.astronauts; e < T.astronauts; e += 1) n.push(Sc[e]);
		for (let e = t.wilds; e < T.wilds; e += 1) n.push(Cc[e]);
		for (let e = t.plannings; e < T.plannings; e += 1) n.push(wc[e]);
		for (let e = t.errors; e < T.errors; e += 1) n.push(yc[e]);
		B.forEach((t, r) => {
			t && !e.claims[r] && n.push(gc[r]);
		}), oe(n);
	}, [
		T,
		f,
		o,
		B
	]);
	let se = r(() => {
		if (N && !j && !A && v !== null && T) return ii(T, z);
	}, [
		N,
		j,
		A,
		v,
		T,
		z
	]), ce = r(() => {
		if (N && A?.k === "airlock" && T) return ni(T.airlocks);
	}, [
		N,
		A,
		T
	]), le = r(() => {
		if (!N || A?.k !== "planX" || !T) return;
		let e = ti(T.airlocks);
		return T.cells.flatMap((t, n) => t === null && e.has(Qr[n]) ? [n] : []);
	}, [
		N,
		A,
		T
	]), ue = (() => {
		if (N) {
			if (A?.k === "airlock" && ce) return {
				kind: "airlock",
				slots: ce
			};
			if (A?.k === "planX" && le) return {
				kind: "planX",
				cells: le
			};
			if (se) return {
				kind: "pick",
				cells: se
			};
		}
	})(), de = r(() => !!T && e.flipped.every((e) => ii(T, e.n).length === 0), [T, e.flipped]), fe = (e, t) => T ? ii(T, e).length > 0 ? !0 : T.astronauts >= 6 || t !== "astronaut" && P <= 0 ? !1 : qc.some((t) => e + t >= 0 && e + t <= 17 && ii(T, e + t).length > 0) : !1, pe = (e) => {
		if (A?.k === "planX") {
			s({
				type: "planX",
				cell: e
			});
			return;
		}
		v !== null && (s({
			type: "pick",
			combo: v,
			cell: e,
			...ie === null ? {} : { mod: ie },
			...C ? { wild: C } : {}
		}), y(null), x(null), w(null), S(!1));
	}, me = k ? {
		tone: "info",
		text: l("games.moon.scoreAria", { n: T ? gi(T) + Ti(e.missions, B ?? [
			null,
			null,
			null
		]) : 0 })
	} : A?.k === "airlock" ? {
		tone: "accent",
		text: l("games.moon.airlockPrompt")
	} : A?.k === "planX" ? {
		tone: "accent",
		text: l("games.moon.planXPrompt")
	} : j ? {
		tone: "info",
		text: l("games.moon.waitingPick")
	} : {
		tone: "accent",
		text: l("games.moon.pickPrompt")
	};
	return /* @__PURE__ */ _("div", {
		className: "moon-table",
		children: [/* @__PURE__ */ _("div", {
			className: "moon-sidebar",
			children: [/* @__PURE__ */ _("div", {
				className: "moon-heading",
				children: [/* @__PURE__ */ g(u, {
					tone: me.tone,
					text: me.text,
					accent: Ei.accent,
					chip: `${l("games.moon.turnChip", { n: e.turn })} ✕${T?.errors ?? 0}/3`
				}), /* @__PURE__ */ g(d, {
					members: t.filter((t) => e.players.includes(t.rid)),
					myRid: o,
					variant: "plate",
					status: (t) => {
						let n = e.sheets[t];
						if (!n) return null;
						let r = gi(n) + Ti(e.missions, e.missionClaims[t] ?? [
							null,
							null,
							null
						]);
						return /* @__PURE__ */ _("span", {
							className: "flex items-center gap-1.5 font-mono tabular-nums",
							children: [/* @__PURE__ */ g("span", {
								className: "moon-total text-base font-black",
								"aria-label": l("games.moon.scoreAria", { n: r }),
								children: r
							}), n.errors > 0 && /* @__PURE__ */ _("span", {
								className: "moon-error text-xs font-bold text-rose-600",
								"aria-label": l("games.moon.errorAria", { n: n.errors }),
								children: ["✕", n.errors]
							})]
						});
					},
					action: (t) => {
						if (k) return null;
						let n = e.picks[t];
						return n ? (n.combo !== null || n.error) && n.queue.length === 0 ? "done" : "pending" : null;
					},
					onPick: (e) => p(e),
					picked: (e) => e === f
				})]
			}), /* @__PURE__ */ _("div", {
				className: "moon-controls",
				children: [
					/* @__PURE__ */ g("div", {
						className: "moon-missions",
						children: e.missions.map((t, n) => {
							let r = e.players.filter((t) => e.missionClaims[t]?.[n]);
							return /* @__PURE__ */ _("div", {
								className: "moon-mission frame flex min-w-0 flex-1 items-center gap-1 px-1.5",
								title: l(Rc[t]),
								children: [
									/* @__PURE__ */ g("span", {
										className: "moon-mission-label shrink-0 text-xs font-black",
										children: "ABC"[n]
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-mission-title min-w-0 flex-1 truncate text-[10px] leading-tight",
										children: l(Rc[t])
									}),
									r.map((r) => {
										let i = e.missionClaims[r][n], a = ci[t], o = i === "high" ? a.hi : a.lo;
										return /* @__PURE__ */ _("span", {
											className: "moon-mission-reward shrink-0 text-[10px] font-bold text-emerald-700",
											children: [O(r), l("games.moon.missionReward2", { n: o })]
										}, r);
									})
								]
							}, n);
						})
					}),
					/* @__PURE__ */ g("div", {
						className: "moon-combos",
						children: e.flipped.map((e, t) => {
							let n = N && !j && !A && fe(e.n, e.act), r = v === t;
							return /* @__PURE__ */ _("button", {
								type: "button",
								disabled: !n,
								onClick: () => {
									y(r ? null : t), x(null), w(null), S(!1);
								},
								"aria-label": `${l($[e.act])} ${e.n}`,
								className: `moon-combo card flex min-w-0 flex-1 items-center justify-center gap-1.5 ${r ? "ring-4 ring-sky-400" : ""} ${!n && !r ? "opacity-40" : ""}`,
								children: [
									/* @__PURE__ */ g("span", {
										"aria-hidden": !0,
										className: "moon-combo-icon text-xl",
										children: Ac[e.act]
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-combo-number font-mono text-2xl font-black tabular-nums",
										children: e.n
									}),
									/* @__PURE__ */ g("span", {
										className: "moon-combo-label truncate text-xs font-bold",
										children: l($[e.act])
									})
								]
							}, t);
						})
					}),
					/* @__PURE__ */ _("div", {
						className: "moon-modifiers",
						children: [N && !j && !A && R && te && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("span", {
							className: "shrink-0 text-xs font-bold",
							children: l("games.moon.wildPrompt")
						}), jc.map((e) => /* @__PURE__ */ _("button", {
							type: "button",
							disabled: e === R.act,
							onClick: () => {
								w(e), S(!1), e !== "astronaut" && x(null);
							},
							className: `btn-quiet flex min-h-11 shrink-0 items-center gap-1 px-2 text-xs font-bold ${e === R.act ? "opacity-40" : ""}`,
							children: [/* @__PURE__ */ g("span", {
								"aria-hidden": !0,
								children: Ac[e]
							}), l($[e])]
						}, e))] }), N && !j && !A && R && !te && /* @__PURE__ */ _(h, { children: [P > 0 && /* @__PURE__ */ _("button", {
							type: "button",
							onClick: () => S(!0),
							className: `btn-quiet flex min-h-11 shrink-0 items-center gap-1 px-2 text-xs font-bold ${C ? "ring-2 ring-sky-400" : ""}`,
							children: [
								"⚙ ",
								l("games.moon.wildBtn"),
								" ×",
								P,
								C && /* @__PURE__ */ _("span", { children: [
									"→",
									Ac[C],
									l($[C])
								] })
							]
						}), re && [null, ...qc].filter((e) => e === null || R.n + e >= 0 && R.n + e <= 17).map((e) => /* @__PURE__ */ g("button", {
							type: "button",
							onClick: () => x(e),
							className: `btn-quiet min-h-11 shrink-0 px-2 font-mono text-sm font-black tabular-nums ${b === e ? "ring-2 ring-sky-400" : ""}`,
							children: e === null ? l("games.moon.modNone") : e === 0 ? "±0" : e > 0 ? `+${e}` : e
						}, e === null ? "none" : e))] })]
					}),
					/* @__PURE__ */ _("div", {
						className: "moon-actions",
						children: [
							N && !j && !A && de && /* @__PURE__ */ g("button", {
								type: "button",
								onClick: () => s({ type: "error" }),
								className: "btn-base min-h-11 w-full text-sm font-black text-white bg-rose-500",
								children: l("games.moon.errorBtn2")
							}),
							N && A && /* @__PURE__ */ g("button", {
								type: "button",
								onClick: () => s({ type: "skip" }),
								className: "btn-quiet min-h-11 w-full text-sm font-bold",
								children: l("games.moon.skipEffect")
							}),
							N && M && /* @__PURE__ */ g("span", {
								className: "w-full text-center text-sm font-bold text-emerald-700",
								children: D.error ? l("games.moon.tookError") : l("games.moon.wrote")
							})
						]
					})
				]
			})]
		}), /* @__PURE__ */ g("div", {
			ref: m,
			className: "moon-paper frame",
			children: /* @__PURE__ */ g(kc, {
				sheet: E,
				missions: e.missions,
				claims: e.missionClaims[f] ?? [
					null,
					null,
					null
				],
				mode: ue,
				onTapCell: pe,
				onTapAirlock: (e) => s({
					type: "airlock",
					airlock: e
				}),
				readOnly: !ue,
				fitKey: ee,
				pulse: f === o ? ae : null,
				focus: f === o ? H : null
			})
		})]
	});
}
//#endregion
//#region src/games/moon/bot.ts
var $c = (e, t) => {
	let n = e.public;
	return n.phase === "done" ? null : n.adv === 2 ? ll(n, t) : n.adv === 3 ? hl(n, t) : n.adv === 4 ? yl(n, t) : n.adv === 5 ? Cl(n, t) : n.adv === 6 ? El(n, t) : n.adv === 7 ? kl(n, t) : rl(n, t);
}, el = {
	64: [
		6,
		7,
		8
	],
	65: [
		3,
		4,
		5
	],
	66: [2],
	67: [0, 1],
	68: [],
	69: []
};
function tl(e, t) {
	let n = T[t], r = 0;
	for (let t = n.start; t < n.start + n.size; t += 1) e.cells[t] === null && (r += 1);
	return r;
}
function nl(e, t, n, r) {
	let i = j(t), a = A(t), o = T[i], s = tl(e, i), c = 0;
	s === 1 ? (c += (o.rocket ?? 0) * 2, o.inactive !== void 0 && e.activated[o.inactive] && (c += w[o.inactive].value * 2), (o.build || o.activation) && (c += .6)) : c += (o.size - s) * .25, r.has(a) && (c += 1), E[a].action === "wild" && (c -= 1.2);
	let l = E[a], u = T[l.quarters[0]].start, d = T[l.quarters[l.quarters.length - 1]], f = 0, p = 0;
	for (let n = u; n < t; n += 1) e.cells[n] === null && (f += 1);
	for (let n = t + 1; n < d.start + d.size; n += 1) e.cells[n] === null && (p += 1);
	return c -= .3 * ((p * n + f * (16 - n)) / 15), c;
}
function rl(e, t) {
	let n = e.sheets[t.rid], r = e.picks[t.rid];
	if (!n || !r) return null;
	let i = r.queue[0];
	if (i === "build") {
		let e = -1, r = -Infinity;
		for (let i = 0; i < n.cells.length; i += 1) {
			if (n.cells[i] !== null) continue;
			if (t.difficulty === "weak") return { action: {
				type: "build",
				cell: i
			} };
			let a = j(i), o = T[a], s = tl(n, a), c = o.size - s + (s === 1 ? (o.rocket ?? 0) * 2 : 0);
			s === 1 && o.inactive !== void 0 && n.activated[o.inactive] && (c += w[o.inactive].value * 2), c > r && (r = c, e = i);
		}
		return { action: e >= 0 ? {
			type: "build",
			cell: e
		} : { type: "skip" } };
	}
	if (i === "activate") {
		let e = -1, r = -Infinity;
		return w.forEach((i, a) => {
			if (n.activated[a] || tl(n, i.quarter) === 0) return;
			if (t.difficulty === "weak") {
				e < 0 && (e = a);
				return;
			}
			let o = T[i.quarter], s = i.value * 2 + (o.size - tl(n, i.quarter)) * .5;
			s > r && (r = s, e = a);
		}), { action: e >= 0 ? {
			type: "activate",
			target: e
		} : { type: "skip" } };
	}
	if (r.combo !== null || r.error) return null;
	let a = /* @__PURE__ */ new Set();
	e.missions.forEach((n, r) => {
		if (!e.missionClaims[t.rid]?.[r]) for (let e of el[n]) a.add(e);
	});
	let o = null;
	for (let r of [
		0,
		1,
		2
	]) {
		let i = e.flipped[r];
		for (let e of P(n.cells, i.act, i.n)) {
			if (t.difficulty === "weak") return { action: {
				type: "pick",
				combo: r,
				cell: e
			} };
			let s = nl(n, e, i.n, a);
			(!o || s > o.score) && (o = {
				combo: r,
				cell: e,
				score: s
			});
		}
	}
	return o ? { action: {
		type: "pick",
		combo: o.combo,
		cell: o.cell
	} } : { action: { type: "error" } };
}
var il = [
	"robot",
	"energy",
	"plant",
	"water",
	"astronaut",
	"planning"
], al = [
	-2,
	-1,
	0,
	1,
	2
];
function ol(e, t) {
	let n = [];
	for (let t = 0; t < 35; t += 1) e.splits[t] || n.push(t);
	if (t || n.length === 0) return n[0] ?? 0;
	let r = -1, i = -Infinity;
	for (let [t, n] of yn(e.splits)) {
		let a = t;
		for (; a <= n && e.cells[a] !== null;) a += 1;
		if (a > t && a <= n) {
			let e = (a - t) * 2;
			e > i && (i = e, r = a - 1);
		}
	}
	if (r >= 0) return r;
	let a = null, o = -1;
	for (let t of yn(e.splits)) {
		let n = 0;
		for (let r = t[0]; r <= t[1]; r += 1) e.cells[r] === null && (n += 1);
		n > o && (o = n, a = t);
	}
	return !a || a[0] >= a[1] ? n[0] : a[0] + Math.floor((a[1] - a[0]) / 2);
}
function sl(e, t, n) {
	let [r, i] = vn(e.splits, t), a = 0, o = 0, s = 0;
	for (let n = r; n <= i; n += 1) e.cells[n] === null ? n < t ? o += 1 : n > t && (s += 1) : a += 1;
	let c = i - r + 1, l = a * .4;
	return a === c - 1 && (l += c * 2), l -= .25 * ((s * n + o * (17 - n)) / 17), l;
}
function cl(e, t, n) {
	switch (t) {
		case "water": {
			let t = hn.findIndex((e) => e.cell === n);
			return t >= 0 && !e.tanks[t] ? hn[t].value : 0;
		}
		case "energy": return e.energyPairs < 6 ? 2.2 : 0;
		case "robot": {
			let t = 0;
			return J.forEach((n, r) => {
				let i = e.stations[r];
				i.robots < n.robots && (t = Math.max(t, n.hi * .3 + (i.robots === n.robots - 1 ? 2 : 0)));
			}), t;
		}
		case "plant": return Sn(e.splits, n).some((t) => e.stations[t].plants < J[t].plants) ? 1.5 : 0;
		case "planning": return e.plannings < 6 && e.cells.some((e) => e === null) ? 1 : 0;
		case "astronaut": return e.astronauts < 6 ? .4 : 0;
	}
}
function ll(e, t) {
	let n = e.sheets[t.rid], r = e.picks[t.rid];
	if (!n || !r) return null;
	let i = t.difficulty === "weak", a = r.queue[0];
	if (a === "split") return { action: {
		type: "split",
		gap: ol(n, i)
	} };
	if (a === "robot") {
		let r = J.map((e, t) => t).filter((e) => n.stations[e].robots < J[e].robots);
		if (r.length === 0) return { action: { type: "skip" } };
		if (i) return { action: {
			type: "robot",
			station: r[0]
		} };
		let a = r[0], o = -Infinity;
		for (let i of r) {
			let r = n.stations[i], s = J[i], c = s.hi + r.robots * 2;
			if (r.robots === s.robots - 1) {
				let n = e.players.some((n) => n !== t.rid && e.sheets[n].stations[i].fullTurn !== -1);
				c += n ? 2 : 6;
			}
			c > o && (o = c, a = i);
		}
		return { action: {
			type: "robot",
			station: a
		} };
	}
	if (a === "plant") {
		let e = r.cell === null ? [] : Sn(n.splits, r.cell).filter((e) => n.stations[e].plants < J[e].plants);
		if (e.length === 0) return { action: { type: "skip" } };
		if (i) return { action: {
			type: "plant",
			station: e[0]
		} };
		let t = e[0], a = -Infinity;
		for (let r of e) {
			let e = n.stations[r], i = e.plants + (e.mult ? e.plants + 4 : 0);
			i > a && (a = i, t = r);
		}
		return { action: {
			type: "plant",
			station: t
		} };
	}
	if (a === "planX") {
		let e = [];
		for (let t = 0; t < 36; t += 1) n.cells[t] === null && e.push(t);
		if (e.length === 0) return { action: { type: "skip" } };
		if (i) return { action: {
			type: "planX",
			cell: e[0]
		} };
		let t = e[0], r = -Infinity;
		for (let i of e) {
			let [e, a] = vn(n.splits, i), o = 0;
			for (let t = e; t <= a; t += 1) n.cells[t] !== null && (o += 1);
			let s = a - e + 1, c = o * 2 - s * .1 + (o === s - 1 ? s * 2 : 0);
			c > r && (r = c, t = i);
		}
		return { action: {
			type: "planX",
			cell: t
		} };
	}
	if (r.combo !== null || r.error) return null;
	let o = n.wilds - n.wildsUsed > 0, s = null;
	for (let t of [
		0,
		1,
		2
	]) {
		let r = e.flipped[t];
		if (i) {
			let e = xn(n.cells, n.splits, r.n);
			if (e.length > 0) return { action: {
				type: "pick",
				combo: t,
				cell: e[0]
			} };
			continue;
		}
		let a = [{
			n: r.n,
			eff: r.act
		}];
		if (n.astronauts < 6) {
			let e = r.act === "astronaut" ? [void 0] : o ? ["astronaut"] : [];
			for (let t of e) for (let e of al) r.n + e < 0 || r.n + e > 17 || a.push({
				n: r.n + e,
				mod: e,
				eff: "astronaut",
				wild: t
			});
		}
		if (o) for (let e of il) e !== r.act && e !== "astronaut" && a.push({
			n: r.n,
			eff: e,
			wild: e
		});
		for (let e of a) for (let r of xn(n.cells, n.splits, e.n)) {
			let i = sl(n, r, e.n) + cl(n, e.eff, r) + (e.wild ? -.6 : 0);
			(!s || i > s.score) && (s = {
				combo: t,
				cell: r,
				mod: e.mod,
				wild: e.wild,
				score: i
			});
		}
	}
	return i ? { action: { type: "error" } } : s ? { action: {
		type: "pick",
		combo: s.combo,
		cell: s.cell,
		...s.mod === void 0 ? {} : { mod: s.mod },
		...s.wild ? { wild: s.wild } : {}
	} } : { action: { type: "error" } };
}
function ul(e, t) {
	return le[t].filter((t) => e.cells[t] !== null).length;
}
function dl(e, t, n) {
	let r = ue(t), i = ul(e, r), a = i * .4;
	i === le[r].length - 1 && (a += 8);
	let o = we(e.tunnels), s = fe.indexOf(t);
	s >= 0 && !e.antennas[s] && (a += o.has(t) ? 2.5 : 1.2), de.includes(t) && (a += .3);
	let c = Math.floor(t / 6), l = t % 6, u = 0, d = 0, f = 0, p = 0;
	for (let t = 0; t < 6; t += 1) e.cells[c * 6 + t] === null && (t < l ? u += 1 : t > l && (d += 1));
	for (let t = 0; t < 6; t += 1) e.cells[t * 6 + l] === null && (t > c ? f += 1 : t < c && (p += 1));
	return a -= .13 * (((u + f) * n + (d + p) * (17 - n)) / 17), a;
}
function fl(e) {
	let t = [
		Oe(e),
		e.tanks.filter(Boolean).length,
		e.antennas.filter(Boolean).length
	], n = [
		e.trackPlant,
		e.trackWater,
		e.trackAntenna
	], r = [
		_e.plant,
		_e.water,
		_e.antenna
	], i = null;
	for (let e of [
		0,
		1,
		2
	]) {
		if (n[e] >= 4) continue;
		let a = r[e][n[e] + 1] - r[e][n[e]], o = t[e] * a + (n[e] === 0 ? t[e] * .2 : 0);
		(!i || o > i.score) && (i = {
			track: e,
			score: o
		});
	}
	return i;
}
function pl(e, t, n) {
	switch (t) {
		case "water": {
			let t = de.indexOf(n);
			return t >= 0 && !e.tanks[t] ? 2 : 0;
		}
		case "plant": {
			let t = ue(n);
			for (let n = 0; n < 4; n += 1) if (!e.greenhouses[t * 4 + n]) return n === 3 ? 2.4 : 1.5;
			return 0;
		}
		case "robot": return Te(e.tunnels).length > 0 ? 1.2 : 0;
		case "energy": return (fl(e)?.score ?? 0) > 0 ? 1.8 : 0;
		case "planning": return e.planning < 10 && e.cells.some((e) => e === null) ? 1.2 - ve[e.planning] * .04 : 0;
		case "astronaut": return e.astronauts < 9 ? .3 : 0;
	}
}
function ml(e, t) {
	let n = Te(e.tunnels);
	if (n.length === 0) return null;
	if (t) return n[0];
	let r = we(e.tunnels), i = n[0], a = -Infinity;
	for (let t of n) {
		let [n, o] = ge(t), s = r.has(n) ? o : n, c = .3;
		s === 5 ? c = 6 : fe.includes(s) ? c = e.cells[s] === null ? 1.5 : 3 : e.cells[s] !== null && (c = .6), c > a && (a = c, i = t);
	}
	return i;
}
function hl(e, t) {
	let n = e.sheets[t.rid], r = e.picks[t.rid];
	if (!n || !r) return null;
	let i = t.difficulty === "weak", a = r.queue[0];
	if (a === "robot") {
		let e = ml(n, i);
		return { action: e === null ? { type: "skip" } : {
			type: "tunnel",
			edge: e
		} };
	}
	if (a === "energy") {
		let e = fl(n);
		return e ? { action: {
			type: "energy",
			track: i ? [
				n.trackPlant,
				n.trackWater,
				n.trackAntenna
			].findIndex((e) => e < 4) : e.track
		} } : { action: { type: "skip" } };
	}
	if (a === "planX") {
		let e = [];
		for (let t = 0; t < 36; t += 1) n.cells[t] === null && e.push(t);
		if (e.length === 0) return { action: { type: "skip" } };
		if (i) return { action: {
			type: "planX",
			cell: e[0]
		} };
		let t = e[0], r = -Infinity;
		for (let i of e) {
			let e = ue(i), a = ul(n, e), o = a * 2 + (a === le[e].length - 1 ? 10 : 0) + +!!fe.includes(i);
			o > r && (r = o, t = i);
		}
		return { action: {
			type: "planX",
			cell: t
		} };
	}
	if (r.combo !== null || r.error) return null;
	let o = null;
	for (let t of [
		0,
		1,
		2
	]) {
		let r = e.flipped[t];
		if (i) {
			let e = Ce(n.cells, r.n);
			if (e.length > 0) return { action: {
				type: "pick",
				combo: t,
				cell: e[0]
			} };
			continue;
		}
		let a = [{ n: r.n }];
		if (r.act === "astronaut" && n.astronauts < 9) for (let e of al) r.n + e < 0 || r.n + e > 17 || a.push({
			n: r.n + e,
			mod: e
		});
		for (let e of a) for (let i of Ce(n.cells, e.n)) {
			let a = dl(n, i, e.n) + (e.mod === void 0 ? pl(n, r.act, i) : pl(n, "astronaut", i));
			(!o || a > o.score) && (o = {
				combo: t,
				cell: i,
				mod: e.mod,
				score: a
			});
		}
	}
	return i ? { action: { type: "error" } } : o ? { action: {
		type: "pick",
		combo: o.combo,
		cell: o.cell,
		...o.mod === void 0 ? {} : { mod: o.mod }
	} } : { action: { type: "error" } };
}
function gl(e, t, n) {
	let r = Math.floor(t / 12), i = t % 12, a = 0, o = 0, s = 0, c = 0;
	for (let t = 0; t < 12; t += 1) e.cells[r * 12 + t] === null ? t < i ? s += 1 : t > i && (c += 1) : o += 1;
	a += o * .3;
	let l = 0;
	for (let t = 0; t < 3; t += 1) e.cells[t * 12 + i] !== null && (l += 1);
	if (l === 2) {
		let t = 2;
		for (let n = 0; n < 3; n += 1) {
			let r = n * 12 + i;
			Je[r] && e.minerals[r] === 1 && (t += 2);
		}
		for (let n of [i, 12 + i]) Ye[n] && e.stems[n] === 1 && (t += 2);
		a += t * 1.6;
	} else a += l * .8;
	return Je[t] && (a += 1), a -= .12 * ((c * n + s * (17 - n)) / 17), a;
}
function _l(e, t) {
	let n = null, r = -Infinity;
	return W.forEach((i, a) => {
		let o = t === "bolt" ? i.bolts - e.bolts[a] : i.robots - e.robots[a];
		if (o <= 0) return;
		let s = e.bolts[a] + +(t === "bolt"), c = e.robots[a] + +(t === "robot"), l = (s >= i.bolts && c >= i.robots && !e.upgraded[a] ? (i.high - i.low) * Math.max(e.circled[a], 3) + 4 : 0) + (i.bolts + i.robots - o) * .5 + 1;
		l > r && (r = l, n = a);
	}), G.forEach((i, a) => {
		let o = t === "bolt" ? i.bolts - e.subBolts[a] : i.robots - e.subRobots[a];
		if (o <= 0 || e.subUsed[a]) return;
		let s = (e.subBolts[a] + +(t === "bolt") >= i.bolts && e.subRobots[a] + +(t === "robot") >= i.robots ? i.give === "robots" ? 7 : 6 : 0) + (i.bolts + i.robots - o) * .5 + 1;
		s > r && (r = s, n = 6 + a);
	}), n;
}
function vl(e, t, n) {
	switch (t) {
		case "water":
		case "plant": return et(n).some((n) => Ye[n] === t && e.stems[n] === 0) ? 1.5 : 0;
		case "energy": return _l(e, "bolt") === null ? 0 : 1.8;
		case "robot": return _l(e, "robot") === null ? 0 : 1.8;
		case "planning": return e.circled[5] < W[5].slots && e.cells.some((e) => e === null) ? e.upgraded[5] ? 1.2 : .5 : 0;
		case "astronaut": return e.circled[4] < W[4].slots ? .4 : 0;
	}
}
function yl(e, t) {
	let n = e.sheets[t.rid], r = e.picks[t.rid];
	if (!n || !r) return null;
	let i = t.difficulty === "weak", a = r.queue[0];
	if (a?.k === "stem") {
		let e = r.cell === null ? [] : et(r.cell).filter((e) => Ye[e] === a.res && n.stems[e] === 0);
		return { action: e.length > 0 ? {
			type: "stem",
			stem: e[0]
		} : { type: "skip" } };
	}
	if (a?.k === "cross") {
		if (i) {
			for (let e = 0; e < 11; e += 1) if ((e < 6 ? a.sym === "bolt" ? W[e].bolts - n.bolts[e] : W[e].robots - n.robots[e] : a.sym === "bolt" ? G[e - 6].bolts - n.subBolts[e - 6] : G[e - 6].robots - n.subRobots[e - 6]) > 0) return { action: {
				type: "cross",
				sym: a.sym,
				factory: e
			} };
			return { action: { type: "skip" } };
		}
		let e = _l(n, a.sym);
		return { action: e === null ? { type: "skip" } : {
			type: "cross",
			sym: a.sym,
			factory: e
		} };
	}
	if (a?.k === "planX") {
		let e = [];
		for (let t = 0; t < n.cells.length; t += 1) n.cells[t] === null && e.push(t);
		if (e.length === 0) return { action: { type: "skip" } };
		if (i) return { action: {
			type: "planX",
			cell: e[0]
		} };
		let t = e[0], r = -Infinity;
		for (let i of e) {
			let e = i % 12, a = 0;
			for (let t = 0; t < 3; t += 1) n.cells[t * 12 + e] !== null && (a += 1);
			let o = a * 2 + (a === 2 ? 6 : 0) + +!!Je[i];
			o > r && (r = o, t = i);
		}
		return { action: {
			type: "planX",
			cell: t
		} };
	}
	if (r.combo !== null || r.error) return null;
	let o = null;
	for (let t of [
		0,
		1,
		2
	]) {
		let r = e.flipped[t];
		if (i) {
			let e = $e(n.cells, r.n);
			if (e.length > 0) return { action: {
				type: "pick",
				combo: t,
				cell: e[0]
			} };
			continue;
		}
		let a = [{ n: r.n }];
		if (r.act === "astronaut" && n.circled[4] < W[4].slots) for (let e of al) r.n + e < 0 || r.n + e > 17 || a.push({
			n: r.n + e,
			mod: e
		});
		for (let e of a) for (let i of $e(n.cells, e.n)) {
			let a = gl(n, i, e.n) + (e.mod === void 0 ? vl(n, r.act, i) : vl(n, "astronaut", i));
			(!o || a > o.score) && (o = {
				combo: t,
				cell: i,
				mod: e.mod,
				score: a
			});
		}
	}
	return i ? { action: { type: "error" } } : o ? { action: {
		type: "pick",
		combo: o.combo,
		cell: o.cell,
		...o.mod === void 0 ? {} : { mod: o.mod }
	} } : { action: { type: "error" } };
}
function bl(e, t, n) {
	let r = Math.floor(t / 13), i = t % 13, a = St(r), o = a.filter((t) => e.cells[r * 13 + t] !== null).length, s = o === a.length - 1 ? 6 : o * .4;
	i === Ct(r) && e.bonus[r * 2] === null && (s += bt[r].top.hi * .5), i === wt(r) && e.bonus[r * 2 + 1] === null && (s += bt[r].bot.hi * .5), Et(i) >= 0 && (s += .8);
	let c = 0, l = 0;
	for (let t of a) e.cells[r * 13 + t] === null && (t < i ? c += 1 : t > i && (l += 1));
	return s -= .3 * ((c * n + l * (16 - n)) / 15), s;
}
function xl(e, t, n, r) {
	let i = n % 13;
	switch (t) {
		case "water": {
			let t = Et(i);
			return t >= 0 && e.towerWaters[t] < 1 ? 2 : 0;
		}
		case "plant": {
			let t = Et(i);
			return t >= 0 && e.towerPlants[t] < 2 ? 2 : 0;
		}
		case "robot": return Ht(e.dome, r) ? 3 : 0;
		case "planning": return e.cells.some((t, n) => Bt(e.cells, n)) ? 2 : 0;
		case "energy": return e.energyMission < 4 || e.energyTower < 4 || e.energyAstro < 4 || e.energyDome < 4 ? 2.5 : 0;
		case "astronaut": return 0;
	}
}
function Sl(e, t, n, r) {
	if (r === 0) {
		if (t.energyMission >= 4) return -1;
		let r = Ot[t.energyMission], i = t.energyMission + 1 < 4 ? Ot[t.energyMission + 1] : kt, a = 0;
		for (let t of e.missionClaims[n] ?? []) t && (a += t === "high" ? i[0] - r[0] : i[1] - r[1]);
		return a;
	}
	if (r === 1) {
		if (t.energyTower >= 4) return -1;
		let e = At[t.energyTower], n = t.energyTower + 1 < 4 ? At[t.energyTower + 1] : jt, r = 0;
		for (let i = 1; i <= 3; i += 1) {
			let a = 0;
			for (let e = 0; e < 8; e += 1) t.towerPlants[e] + t.towerWaters[e] === i && (a += 1);
			r += a * (n[i - 1] - e[i - 1]);
		}
		return r;
	}
	if (r === 2) {
		if (t.energyAstro >= 4 || t.astronauts === 0) return -1;
		let n = Mt[t.energyAstro], r = t.energyAstro + 1 < 4 ? Mt[t.energyAstro + 1] : Nt, i = Math.max(...e.players.map((t) => e.sheets[t].astronauts)), a = t.astronauts >= i ? 0 : 1;
		return r[a] - n[a];
	}
	if (t.energyDome >= 4) return -1;
	let i = Pt[t.energyDome], a = t.energyDome + 1 < 4 ? Pt[t.energyDome + 1] : 2;
	return Gt(t.dome) * (i - a);
}
function Cl(e, t) {
	let n = e.sheets[t.rid], r = e.picks[t.rid];
	if (!n || !r) return null;
	let i = t.difficulty === "weak", a = r.queue[0];
	if (a?.k === "tower") {
		let e = r.cell === null ? -1 : Et(r.cell % 13);
		return { action: e < 0 || (a.res === "water" ? n.towerWaters[e] >= 1 : n.towerPlants[e] >= 2) ? { type: "skip" } : {
			type: "towerSym",
			level: e
		} };
	}
	if (a?.k === "dome") {
		let e = r.cell === null ? null : n.cells[r.cell], t = typeof e == "number" ? n.dome.flatMap((t, r) => Vt(n.dome, r, e) ? [r] : []) : [];
		return t.length === 0 ? { action: { type: "skip" } } : { action: {
			type: "domeBuild",
			index: i ? t[0] : t.find((e) => !n.dome[e].half) ?? t[0]
		} };
	}
	if (a?.k === "planX") {
		let e = [];
		for (let t = 0; t < 52; t += 1) n.cells[t] === null && Bt(n.cells, t) && e.push(t);
		if (e.length === 0) return { action: { type: "skip" } };
		if (i) return { action: {
			type: "planX",
			cell: e[0]
		} };
		let t = e[0], r = -Infinity;
		for (let i of e) {
			let e = Math.floor(i / 13), a = i % 13, o = St(e), s = o.filter((t) => n.cells[e * 13 + t] !== null).length, c = s * 2 + (s === o.length - 1 ? 6 : 0);
			(a === Ct(e) || a === wt(e)) && (c -= 2), c > r && (r = c, t = i);
		}
		return { action: {
			type: "planX",
			cell: t
		} };
	}
	if (a?.k === "cut") {
		let e = n.dome.flatMap((e, t) => Ut(n.dome, t) ? [t] : []);
		return e.length === 0 ? null : { action: {
			type: "domeCut",
			index: e[Math.floor(e.length / 2)]
		} };
	}
	if (a?.k === "energy") {
		if (i) {
			for (let r of [
				0,
				1,
				2,
				3
			]) if (Sl(e, n, t.rid, r) >= 0) return { action: {
				type: "energyUp",
				field: r
			} };
			return { action: { type: "skip" } };
		}
		let r = null, a = 0;
		for (let i of [
			0,
			1,
			2,
			3
		]) {
			let o = Sl(e, n, t.rid, i);
			o > a && (a = o, r = i);
		}
		return { action: r === null ? { type: "skip" } : {
			type: "energyUp",
			field: r
		} };
	}
	if (r.combo !== null || r.error) return null;
	let o = null;
	for (let t of [
		0,
		1,
		2
	]) {
		let r = e.flipped[t];
		if (i) {
			let e = zt(n.cells, r.n);
			if (e.length > 0) return { action: {
				type: "pick",
				combo: t,
				cell: e[0]
			} };
			continue;
		}
		let a = [{ n: r.n }];
		if (r.act === "astronaut" && n.astronauts < 6) for (let e of al) r.n + e < 0 || r.n + e > 17 || a.push({
			n: r.n + e,
			mod: e
		});
		for (let e of a) for (let i of zt(n.cells, e.n)) {
			let a = bl(n, i, e.n) + xl(n, r.act, i, e.n);
			(!o || a > o.score) && (o = {
				combo: t,
				cell: i,
				mod: e.mod,
				score: a
			});
		}
	}
	return i ? { action: { type: "error" } } : o ? { action: {
		type: "pick",
		combo: o.combo,
		cell: o.cell,
		...o.mod === void 0 ? {} : { mod: o.mod }
	} } : { action: { type: "error" } };
}
function wl(e, t, n) {
	let r = ar(t), i = 0;
	for (let t = 0; t < 5; t += 1) e.cells[r * 5 + t] !== null && (i += 1);
	Yn[t] !== void 0 && !e.tanks[Yn[t]] && (i += 2);
	let a = Zn[r];
	for (let t = 0; t < Xn[r]; t += 1) e.plants[a + t] || (i += .5);
	let o = Un[Wn[r]];
	for (let r of o) for (let a = 0; a < 5; a += 1) {
		let o = r * 5 + a;
		if (o === t || e.cells[o] !== null) continue;
		let s = 0, c = 0;
		for (let r = 1; r <= 15; r += 1) or(e.cells, o, r) && (s += 1), e.cells[t] = n, or(e.cells, o, r) && (c += 1), e.cells[t] = null;
		i -= (s - c) * .2;
	}
	return i;
}
function Tl(e, t, n) {
	let r = ar(n);
	switch (t) {
		case "energy": return e.evac[r] === null && (!e.energy[r * 2] || !e.energy[r * 2 + 1]) ? 2 : 0;
		case "plant": {
			let t = Zn[r];
			return e.plants.slice(t, t + Xn[r]).some((e) => !e) ? 2 : 0;
		}
		case "water": {
			let t = Yn[n];
			return t !== void 0 && !e.tanks[t] ? 2 : 0;
		}
		case "robot": return +!!e.walkways.some((e) => !e);
		case "planning": return +(e.plannings < 6);
		case "astronaut": return 0;
	}
}
function El(e, t) {
	let n = e.sheets[t.rid], r = e.picks[t.rid];
	if (!n || !r) return null;
	let i = t.difficulty === "weak";
	if (e.stage === "grey") return n.greyQuarter >= 0 ? null : { action: {
		type: "grey",
		cell: 50
	} };
	let a = r.queue[0];
	if (a?.k === "infect") {
		let e = gr(n, a.q);
		return e.length === 0 ? null : { action: {
			type: "infect",
			cells: e.map((e) => e[0])
		} };
	}
	if (a?.k === "energy") {
		let e = Or(n, a.q);
		if (e.length === 0) return { action: { type: "skip" } };
		let t = e[0];
		if (!i) {
			let r = -1;
			for (let i of e) {
				let e = 0;
				for (let t = 0; t < 5; t += 1) typeof n.cells[i * 5 + t] == "number" && (e += 1);
				e > r && (r = e, t = i);
			}
		}
		return { action: {
			type: "circleEnergy",
			quarter: t
		} };
	}
	if (a?.k === "robot") {
		let e = [];
		for (let t = 0; t < 22; t += 1) n.walkways[t] || e.push(t);
		return e.length === 0 ? { action: { type: "skip" } } : i ? { action: {
			type: "close",
			walk: e[0]
		} } : { action: {
			type: "close",
			walk: e.find((e) => {
				let [t, r] = Gn[e];
				return n.viruses[t] && n.evac[t] !== null || n.viruses[r] && n.evac[r] !== null;
			}) ?? e[0]
		} };
	}
	if (a?.k === "planX") {
		let e = [];
		for (let t = 0; t < 55; t += 1) n.cells[t] === null && e.push(t);
		if (e.length === 0) return { action: { type: "skip" } };
		if (i) return { action: {
			type: "planX",
			cell: e[0]
		} };
		let t = e[0], r = -1;
		for (let i of e) {
			let e = ar(i);
			if (n.evac[e] !== null) continue;
			let a = 0;
			for (let t = 0; t < 5; t += 1) n.cells[e * 5 + t] !== null && (a += 1);
			a > r && (r = a, t = i);
		}
		return { action: {
			type: "planX",
			cell: t
		} };
	}
	if (r.combo !== null || r.error || e.stage !== "play") return null;
	let o = null;
	for (let t of [
		0,
		1,
		2
	]) {
		let r = e.flipped[t];
		if (i) {
			let e = sr(n.cells, r.n);
			if (e.length > 0) return { action: {
				type: "pick",
				combo: t,
				cell: e[0]
			} };
			continue;
		}
		let a = [{ n: r.n }];
		if (r.act === "astronaut" && n.astronauts < 6) for (let e of al) r.n + e < 0 || r.n + e > 17 || a.push({
			n: r.n + e,
			mod: e
		});
		for (let e of a) for (let i of sr(n.cells, e.n)) {
			let a = wl(n, i, e.n) + Tl(n, r.act, i);
			(!o || a > o.score) && (o = {
				combo: t,
				cell: i,
				mod: e.mod,
				score: a
			});
		}
	}
	return o ? { action: {
		type: "pick",
		combo: o.combo,
		cell: o.cell,
		...o.mod === void 0 ? {} : { mod: o.mod }
	} } : { action: { type: "error" } };
}
function Dl(e, t, n) {
	let r = Br[Qr[t]], i = 0;
	if (r.gh) i += 10;
	else {
		let t = r.cells.filter((t) => e.cells[t] !== null).length;
		i += t * 1.5, t === r.cells.length - 1 && (i += 12);
	}
	Yr.includes(t) && (i += 6);
	let a = Ur[t];
	a !== void 0 && !e.tanks[a] && (i += 3);
	let [o, s] = zr[$r[t]];
	for (let r = o; r <= s; r += 1) {
		if (r === t || e.cells[r] !== null) continue;
		let a = 0, o = 0;
		for (let i = 1; i <= 15; i += 1) ri(e, r, i) && (a += 1), e.cells[t] = n, ri(e, r, i) && (o += 1), e.cells[t] = null;
		i -= (a - o) * .2;
	}
	return i;
}
function Ol(e, t, n) {
	let r = $r[n];
	switch (t) {
		case "energy": return Wr[r].some((t) => !e.reactors[t]) ? 3 : 0;
		case "plant": return Kr[r].some((t) => !e.plants[t]) ? 3 : 0;
		case "water": {
			let t = Ur[n];
			return t !== void 0 && !e.tanks[t] ? 4 : 0;
		}
		case "robot": return ni(e.airlocks).length > 0 ? 5 : 0;
		case "planning": return +(e.plannings < 9);
		case "astronaut": return 0;
	}
}
function kl(e, t) {
	let n = e.sheets[t.rid], r = e.picks[t.rid];
	if (!n || !r) return null;
	let i = t.difficulty === "weak", a = r.queue[0];
	if (a?.k === "airlock") {
		let e = ni(n.airlocks);
		if (e.length === 0) return { action: { type: "skip" } };
		if (i) return { action: {
			type: "airlock",
			airlock: e[0]
		} };
		let t = ti(n.airlocks), r = e[0], a = -1;
		for (let i of e) {
			let [e, o] = Vr[i], s = t.has(e) ? o : t.has(o) ? e : -1;
			if (s < 0) continue;
			let c = Br[s], l = c.cells.length;
			if (c.gh) {
				l += 8;
				let e = Jr.indexOf(c.cells[0]);
				e >= 0 && n.x2[e] === null && (l += 4);
			}
			l > a && (a = l, r = i);
		}
		return { action: {
			type: "airlock",
			airlock: r
		} };
	}
	if (a?.k === "planX") {
		let e = ti(n.airlocks), t = [];
		for (let r = 0; r < 43; r += 1) n.cells[r] === null && e.has(Qr[r]) && t.push(r);
		if (t.length === 0) return { action: { type: "skip" } };
		if (i) return { action: {
			type: "planX",
			cell: t[0]
		} };
		let r = t[0], a = -Infinity;
		for (let e of t) {
			let t = Br[Qr[e]], i;
			if (t.gh) {
				let t = Jr.indexOf(e);
				i = t >= 0 && n.x2[t] === null ? 20 : 2;
			} else i = t.cells.filter((e) => n.cells[e] !== null).length * 2;
			i > a && (a = i, r = e);
		}
		return { action: {
			type: "planX",
			cell: r
		} };
	}
	if (r.combo !== null || r.error) return null;
	let o = null;
	for (let t of [
		0,
		1,
		2
	]) {
		let r = e.flipped[t];
		if (i) {
			let e = ii(n, r.n);
			if (e.length > 0) return { action: {
				type: "pick",
				combo: t,
				cell: e[0]
			} };
			continue;
		}
		let a = [{ n: r.n }];
		if (r.act === "astronaut" && n.astronauts < 6) for (let e of al) r.n + e < 0 || r.n + e > 17 || a.push({
			n: r.n + e,
			mod: e
		});
		for (let e of a) for (let i of ii(n, e.n)) {
			let a = Dl(n, i, e.n) + Ol(n, r.act, i);
			(!o || a > o.score) && (o = {
				combo: t,
				cell: i,
				mod: e.mod,
				score: a
			});
		}
	}
	return i ? { action: { type: "error" } } : o ? { action: {
		type: "pick",
		combo: o.combo,
		cell: o.cell,
		...o.mod === void 0 ? {} : { mod: o.mod }
	} } : { action: { type: "error" } };
}
//#endregion
//#region src/games/moon/game-over-row.tsx
function Al({ public: e, rid: t, fullSize: r = !1, fitKey: o = "over" }) {
	let s = e, c = i(null), [l, u] = a("");
	n(() => {
		if (r || !c.current) return;
		let e = c.current, t = new ResizeObserver(() => u(`${e.clientWidth}x${e.clientHeight}`));
		return t.observe(e), () => t.disconnect();
	}, [r]);
	let d = r ? o : `${o}-${l}`, f = s.missionClaims[t] ?? [
		null,
		null,
		null
	], p = r ? "moon-final-sheet" : "moon-final-paper frame pointer-events-none mt-1.5 overflow-hidden";
	if (s.adv === 7) {
		let e = s.sheets[t];
		return e ? /* @__PURE__ */ g("div", {
			ref: c,
			className: p,
			"aria-hidden": !r || void 0,
			children: /* @__PURE__ */ g("div", {
				style: r ? { height: "100%" } : { aspectRatio: `${pc} / ${mc}` },
				children: /* @__PURE__ */ g(kc, {
					sheet: e,
					missions: s.missions,
					claims: f,
					readOnly: !0,
					fitKey: `${d}-${t}`
				})
			})
		}) : null;
	}
	if (s.adv === 6) {
		let e = s.sheets[t];
		return e ? /* @__PURE__ */ g("div", {
			ref: c,
			className: p,
			"aria-hidden": !r || void 0,
			children: /* @__PURE__ */ g("div", {
				style: r ? { height: "100%" } : { aspectRatio: `${Ps} / ${Fs}` },
				children: /* @__PURE__ */ g(fc, {
					sheet: e,
					missions: s.missions,
					claims: f,
					activatedViruses: s.activatedViruses,
					readOnly: !0,
					fitKey: `${d}-${t}`
				})
			})
		}) : null;
	}
	if (s.adv === 5) {
		let e = s.sheets[t];
		return e ? /* @__PURE__ */ g("div", {
			ref: c,
			className: p,
			"aria-hidden": !r || void 0,
			children: /* @__PURE__ */ g("div", {
				style: r ? { height: "100%" } : { aspectRatio: `${ds} / ${fs}` },
				children: /* @__PURE__ */ g(Ns, {
					sheet: e,
					claims: f,
					readOnly: !0,
					fitKey: `${d}-${t}`
				})
			})
		}) : null;
	}
	if (s.adv === 4) {
		let e = s.sheets[t];
		return e ? /* @__PURE__ */ g("div", {
			ref: c,
			className: p,
			"aria-hidden": !r || void 0,
			children: /* @__PURE__ */ g("div", {
				style: r ? { height: "100%" } : { aspectRatio: `${Vo} / ${Ho}` },
				children: /* @__PURE__ */ g(us, {
					sheet: e,
					missions: s.missions,
					claims: f,
					readOnly: !0,
					fitKey: `${d}-${t}`
				})
			})
		}) : null;
	}
	if (s.adv === 2) {
		let e = s.sheets[t];
		return e ? /* @__PURE__ */ g("div", {
			ref: c,
			className: p,
			"aria-hidden": !r || void 0,
			children: /* @__PURE__ */ g("div", {
				style: r ? { height: "100%" } : { aspectRatio: `${oo} / ${so}` },
				children: /* @__PURE__ */ g(Fo, {
					sheet: e,
					missions: s.missions,
					claims: f,
					readOnly: !0,
					fitKey: `${d}-${t}`
				})
			})
		}) : null;
	}
	if (s.adv === 3) {
		let e = s.sheets[t];
		if (!e) return null;
		let n = e.quarterTurn.map((e, t) => e === -1 ? null : e === Math.min(...s.players.map((e) => s.sheets[e].quarterTurn[t]).filter((e) => e !== -1)) ? "high" : "low");
		return /* @__PURE__ */ g("div", {
			ref: c,
			className: p,
			"aria-hidden": !r || void 0,
			children: /* @__PURE__ */ g("div", {
				style: r ? { height: "100%" } : { aspectRatio: `${Wa} / ${Ga}` },
				children: /* @__PURE__ */ g(Bo, {
					sheet: e,
					missions: s.missions,
					claims: f,
					quarterLevels: n,
					readOnly: !0,
					fitKey: `${d}-${t}`
				})
			})
		});
	}
	let m = s.sheets[t];
	return m ? /* @__PURE__ */ g("div", {
		ref: c,
		className: p,
		"aria-hidden": !r || void 0,
		children: /* @__PURE__ */ g("div", {
			style: r ? { height: "100%" } : { aspectRatio: `${Ma} / ${Na}` },
			children: /* @__PURE__ */ g(ko, {
				sheet: m,
				claims: f,
				readOnly: !0,
				fitKey: `${d}-${t}`
			})
		})
	}) : null;
}
//#endregion
//#region src/games/moon/game-over.tsx
var jl = {
	1: "games.moon.advName.a1",
	2: "games.moon.advName.a2",
	3: "games.moon.advName.a3",
	4: "games.moon.advName.a4",
	5: "games.moon.advName.a5",
	6: "games.moon.advName.a6",
	7: "games.moon.advName.a7"
};
function Ml(e) {
	let t = e.public, r = c(), l = s((e) => e.locale), [u, d] = a(!0), [f, p] = a(t.sheets[e.myRid] ? e.myRid : t.players[0]), [m, ee] = a(0), [h, S] = a(""), C = i(null), w = i(null), T = i(null);
	n(() => {
		let e = C.current, t = new ResizeObserver(() => S(`${e.clientWidth}x${e.clientHeight}`));
		return t.observe(e), () => t.disconnect();
	}, []);
	let E = (t) => {
		let n = e.members.find((e) => e.rid === t);
		return n ? v(t) === null ? n.name : o(l, n.avatar) : t;
	}, D = (e) => {
		d(e), requestAnimationFrame(() => (e ? T : w).current?.focus());
	}, O = (n) => e.result.ranking.findIndex((r) => {
		if (t.adv === 1) {
			let i = t.sheets[n], a = t.sheets[r];
			return i.launched || a.launched ? i.launched === a.launched && i.bonus === a.bonus : e.result.scores?.[n] === e.result.scores?.[r] && i.circled === a.circled;
		}
		return e.result.scores?.[n] === e.result.scores?.[r] && t.sheets[n].errors === t.sheets[r].errors;
	}) + 1;
	return /* @__PURE__ */ _("div", {
		className: "moon-final",
		children: [/* @__PURE__ */ _("section", {
			className: "moon-final-view",
			inert: u,
			"aria-label": r("games.moon.sheetFor", { name: E(f) }),
			children: [
				/* @__PURE__ */ _("header", {
					className: "moon-final-heading",
					children: [
						/* @__PURE__ */ g("select", {
							"aria-label": r("games.moon.viewPlayer"),
							value: f,
							onChange: (e) => p(e.target.value),
							children: t.players.map((e) => /* @__PURE__ */ g("option", {
								value: e,
								children: E(e)
							}, e))
						}),
						/* @__PURE__ */ g("span", { children: r(jl[t.adv]) }),
						e.result.scores?.[f] !== void 0 && /* @__PURE__ */ g("strong", { children: r("games.moon.finalScore", { n: e.result.scores[f] }) })
					]
				}),
				/* @__PURE__ */ g("div", {
					ref: C,
					className: "moon-final-fullpaper",
					children: /* @__PURE__ */ g(Al, {
						public: t,
						rid: f,
						myRid: e.myRid,
						fullSize: !0,
						fitKey: `final-${h}-${m}`
					})
				}),
				/* @__PURE__ */ _("footer", {
					className: "moon-final-tools",
					children: [/* @__PURE__ */ _("button", {
						ref: w,
						type: "button",
						className: "btn-base bg-surface",
						onClick: () => D(!0),
						children: [/* @__PURE__ */ g(te, { size: 18 }), r("games.moon.viewResults")]
					}), /* @__PURE__ */ g("button", {
						type: "button",
						className: "btn-quiet",
						onClick: () => ee((e) => e + 1),
						children: r("games.moon.fitSheet")
					})]
				})
			]
		}), /* @__PURE__ */ _("section", {
			className: "moon-result",
			hidden: !u,
			"aria-label": r("session.result.title"),
			children: [
				/* @__PURE__ */ _("header", {
					className: "moon-result-header",
					children: [/* @__PURE__ */ g("button", {
						ref: T,
						type: "button",
						className: "btn-quiet",
						"aria-label": r("games.moon.viewSheet"),
						title: r("games.moon.viewSheet"),
						onClick: () => D(!1),
						children: /* @__PURE__ */ g(x, { size: 18 })
					}), e.hintCount !== void 0 && /* @__PURE__ */ g("span", { children: r("session.hint.usedCount", { n: e.hintCount }) })]
				}),
				/* @__PURE__ */ g("ol", {
					className: "moon-result-list",
					children: e.result.ranking.map((n) => {
						let i = e.members.find((e) => e.rid === n), a = e.result.winner.includes(n), o = e.result.scores?.[n];
						return /* @__PURE__ */ _("li", {
							className: `moon-result-player${a ? " moon-result-winner" : ""}`,
							children: [
								/* @__PURE__ */ _("div", {
									className: "moon-result-identity",
									children: [
										/* @__PURE__ */ g("span", {
											className: "moon-result-rank",
											children: O(n)
										}),
										i && /* @__PURE__ */ g("img", {
											src: y[i.avatar % y.length],
											alt: "",
											draggable: !1
										}),
										/* @__PURE__ */ _("strong", { children: [
											a && /* @__PURE__ */ g("span", {
												"aria-label": r("games.moon.winner"),
												children: "👑 "
											}),
											E(n),
											n === e.myRid && /* @__PURE__ */ g("small", { children: r("lobby.you") })
										] }),
										o !== void 0 && /* @__PURE__ */ g("b", { children: o })
									]
								}),
								e.result.autopilot?.[n] !== void 0 && e.result.autopilot[n] > 0 && /* @__PURE__ */ g("small", { children: r("session.autopilot.share", { n: Math.round(e.result.autopilot[n] * 100) }) }),
								/* @__PURE__ */ g(Al, {
									public: t,
									rid: n,
									myRid: e.myRid
								}),
								/* @__PURE__ */ g("button", {
									type: "button",
									className: "btn-quiet moon-final-open",
									"aria-label": r("games.moon.sheetFor", { name: E(n) }),
									onClick: () => {
										p(n), D(!1);
									},
									children: r("games.moon.viewSheet")
								})
							]
						}, n);
					})
				}),
				u && /* @__PURE__ */ _("footer", {
					className: "moon-result-actions",
					children: [
						e.onPlayAgain && /* @__PURE__ */ g(b, {
							className: "moon-final-primary",
							label: r("session.result.playAgain"),
							confirmLabel: r("games.moon.confirmAgain"),
							onConfirm: e.onPlayAgain
						}),
						e.onBackToLobby && /* @__PURE__ */ g(b, {
							label: r("session.result.backToLobby"),
							confirmLabel: r("games.moon.confirmBack"),
							onConfirm: e.onBackToLobby
						}),
						!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ g("p", { children: r("session.result.waitHost") })
					]
				})
			]
		})]
	});
}
//#endregion
//#region src/games/moon/options.tsx
var Nl = [
	{
		id: 1,
		nameKey: "games.moon.advName.a1",
		ready: !0
	},
	{
		id: 2,
		nameKey: "games.moon.advName.a2",
		ready: !0
	},
	{
		id: 3,
		nameKey: "games.moon.advName.a3",
		ready: !0
	},
	{
		id: 4,
		nameKey: "games.moon.advName.a4",
		ready: !0
	},
	{
		id: 5,
		nameKey: "games.moon.advName.a5",
		ready: !0
	},
	{
		id: 6,
		nameKey: "games.moon.advName.a6",
		ready: !0
	},
	{
		id: 7,
		nameKey: "games.moon.advName.a7",
		ready: !0
	}
];
function Pl({ value: e, onChange: t }) {
	let n = c(), r = Ai.safeParse(e), i = r.success ? r.data : Ai.parse(void 0);
	return /* @__PURE__ */ g(C, {
		title: n("games.moon.optAdventure"),
		children: Nl.map((e) => /* @__PURE__ */ g(S, {
			name: "moon-adventure",
			value: String(e.id),
			checked: i.adventure === e.id,
			disabled: !e.ready,
			label: /* @__PURE__ */ _(h, { children: [
				e.id,
				". ",
				n(e.nameKey)
			] }),
			hint: e.ready ? void 0 : n("games.moon.advSoon"),
			accent: Ei.accent,
			onChange: () => t({ adventure: e.id })
		}, e.id))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/moon/entry.tsx
var Fl = {
	definition: ja,
	View: Hc,
	bot: $c,
	OverView: Ml,
	RowView: Al,
	Options: Pl,
	locales: {
		zh: {
			name: "欢迎来到月球",
			desc: "填格装火箭,抢在别人之前点火发射",
			rules: "目标:赶在别人之前装满火箭并点火发射;若无人发射,分数最高者获胜。\n流程:\n· 每回合翻开 3 张飞船卡,形成 3 个「数字+动作」组合;所有玩家同时各选一个组合。\n· 将所选数字写入火箭中与该行动对应的楼层；万能层可以使用任意行动。每层数字从左到右必须严格递增，同一层不能重复。\n· 三个组合都无处可写时,必须圈 1 个系统错误。\n舱室效果:\n楼层被隔断分成若干舱室。一个舱室被数字或 X 填满时，立即触发其中的效果：\n· Ⓧ 在任意空格补写一个 X。\n· 🚀 在计分轨上划掉对应数量的火箭。\n· 紫色箭头可激活一个浅色火箭(其所在舱室填满时才划掉对应火箭);\n· 红色感叹号是破坏。\n破坏:\n· 触发破坏后,其他玩家各圈 1 个系统错误;每个破坏符号全局只能触发一次。\n任务:\n· A/B/C 各一张公共任务;同一回合内首批达成者划较多火箭,之后达成者划较少火箭。\n结束:\n· 划满计分轨全部火箭并消掉所有已圈错误,回合末即发射获胜;同回合多人发射则比加赛火箭数。\n· 若有玩家完成三张任务、圈满八个系统错误，或填满整张记录表，对局结束并计分。以计分轨上最低的未划掉分数框为基础分数，每个尚未消除的系统错误扣除 5 分。总分最高的玩家获胜。\n冒险版图:\n· 大堂选项可切换冒险版图;规则骨架相同,各版图的舱室/轨迹效果与算分不同。\n可选的冒险版图包括发射、旅程、殖民地、矿场、穹顶、病毒和逃脱。",
			optAdventure: "选择冒险版图",
			viewSheet: "查看计分纸",
			viewResults: "查看结算",
			viewPlayer: "选择玩家",
			sheetFor: "查看{{name}}的计分纸",
			fitSheet: "回到全景",
			finalScore: "{{n}} 分",
			winner: "获胜",
			confirmAgain: "确定再来一局",
			confirmBack: "确定返回房间",
			advSoon: "(敬请期待)",
			advName: {
				a1: "发射",
				a2: "旅程",
				a3: "殖民地",
				a4: "矿场",
				a5: "穹顶",
				a6: "病毒",
				a7: "逃脱"
			},
			pickPrompt: "选一个组合,点版图高亮格写入",
			waitingPick: "等其他人写数…",
			wrote: "已写入",
			tookError: "圈了系统错误",
			errorBtn: "无处可写:圈 1 个系统错误(每格 −5)",
			errorBtn2: "无处可写:圈 1 个系统错误",
			buildPrompt: "建造效果:点任意空格写 X,或跳过",
			activatePrompt: "火箭激活:点一个浅色火箭,或跳过",
			robotPrompt: "机器人效果:点一个空间站圈机器人,或跳过",
			plantPrompt: "植物效果:点相连空间站的植物,或跳过",
			planXPrompt: "规划效果:点任意空格写 X,或跳过",
			splitPrompt: "能量凑对:点两格之间放刀,切开分区",
			modNone: "不用动作",
			wildBtn: "万能",
			wildPrompt: "划 1 个万能齿轮,把动作换成:",
			skipEffect: "跳过此效果",
			turnChip: "第 {{n}} 回合",
			act: {
				robot: "机器人",
				energy: "能量",
				plant: "植物",
				water: "水",
				astronaut: "宇航员",
				planning: "规划",
				wild: "万能"
			},
			mission: {
				m64: "填满水层与两个宇航员层",
				m65: "填满规划层与两个机器人层",
				m66: "填满能量层",
				m67: "填满植物层与万能层",
				m68: "用建造效果写 10 个 X",
				m69: "同时拥有 5 个未消的系统错误",
				m70: "3 个空间站圈到倍率",
				m71: "2 个空间站圈全植物",
				m72: "切出 2 个恰好 6 格的完整分区",
				m73: "切出 6、4、2 格的三个完整分区",
				m74: "圈 6 个水箱",
				m75: "圈 4 个连续的水箱",
				m76: "写满 3 条竖列",
				m77: "写满 3 条横行",
				m78: "隧道网连到天文台",
				m79: "圈完 2 个舱区的全部天线碟",
				m80: "圈温室累计 10 株植物",
				m81: "圈完 2 个舱区的全部水箱",
				m82: "圈 5 个开采泵",
				m83: "圈 4 个相邻的开采泵",
				m84: "激活全部 5 个副工厂",
				m85: "升级或激活合计 6 个工厂",
				m86: "圈矿区 8 株植物",
				m87: "圈矿区 5 处水",
				m88: "一栋摩天楼全部写满",
				m89: "至少 2 栋楼的顶层写上数字",
				m90: "研究塔至少 3 层各圈 2 个符号",
				m91: "研究塔至少 2 层圈满 3 个符号",
				m92: "建成穹顶的所有分段",
				m93: "规划写下 4 个 X",
				m94: "疏散 2 个区域",
				m95: "疏散同一层的所有区域",
				m96: "3 个区域的所有步道全部关闭",
				m97: "绿区与蓝区的所有步道全部关闭",
				m98: "2 个楼层的能量旗全部圈完",
				m99: "2 个楼层的植物与水箱全部圈完",
				m100: "3 个温室各圈满 3 株植物",
				m101: "最顶端星舰的温室圈满 3 株植物",
				m102: "7 个模块全部填满",
				m103: "3 艘星舰全部填满",
				m104: "3 艘星舰的反应堆全部圈完",
				m105: "3 艘星舰的水箱全部圈完"
			},
			towerPlantPrompt: "植物效果:点研究塔对应层的植物圈上,或跳过",
			towerWaterPrompt: "水效果:点研究塔对应层的水滴圈上,或跳过",
			domeBuildPrompt: "机器人效果:点一段穹顶建造(数字奇偶须匹配),或跳过",
			domeCutPrompt: "规划效果:必须再点一段未建的穹顶,把它切成两半",
			energyUpPrompt: "能量效果:点一个区域划掉它的一行框(升级计分),或跳过",
			greyPrompt: "病毒爆发:点 4 个空病毒区之一的任意格,放置你的灰病毒",
			circleEnergyPrompt: "能量效果:点一面能量旗圈上,或跳过",
			closePrompt: "机器人效果:点一条步道闸门关闭,或跳过",
			infectPrompt: "病毒传播:每组高亮格各选 1 格感染(不可跳过)",
			airlockPrompt: "机器人效果:点一个气闸激活(连通两侧舱段),或跳过",
			stemPrompt: "资源效果:点所落腔体正上/正下方对应的茎资源,或跳过",
			crossBoltPrompt: "能量效果:点一个工厂的闪电划掉,或跳过",
			crossRobotPrompt: "机器人效果:点一个工厂的机器人划掉,或跳过",
			tunnelPrompt: "机器人效果:点一条隧道画线(从已连网建筑出发),或跳过",
			energyPrompt: "能量效果:点一条计分轨划掉最低格,或跳过",
			missionReward: "🚀{{n}}",
			missionReward2: "+{{n}}",
			scoreAria: "当前 {{n}} 分",
			errorAria: "系统错误 {{n}} 个",
			launched: "已发射!",
			errOver: "本局已结束",
			errBadStage: "现在不是这个阶段",
			errAlreadyDone: "本回合你已行动过",
			errBadCell: "这格不能写",
			errBadCombo: "没有这个组合",
			errCanPlace: "还有可写的格子,必须写数",
			errBadEffect: "当前没有待处理的效果",
			errBadTarget: "这个目标不能选",
			errBadMod: "这个修正现在不能用",
			errNoWild: "没有可划的万能齿轮"
		},
		en: {
			name: "Welcome to the Moon",
			desc: "Fill your rocket floor by floor and launch before everyone else",
			rules: "Goal: Load your rocket and launch before the others; if nobody launches, the highest score wins.\nPlay:\n· Each turn 3 starship cards are flipped, making 3 number+action combos; all players simultaneously pick one.\n· Write the chosen number on a floor matching the combination's action. The wild floor accepts any action. Numbers on each floor must strictly increase from left to right, without duplicates.\n· If none of the 3 combos can be written, you must circle a System Error.\nQuarter effects:\nPartition walls divide floors into quarters. Filling a quarter with numbers or X marks immediately triggers its effects:\n· Ⓧ write an X in any empty space.\n· 🚀 cross that many rockets on the scoring track.\n· a purple arrow activates a dim rocket (its rockets are crossed when its own quarter fills);\n· a red diamond is a Sabotage.\nSabotage:\n· Triggering a Sabotage makes every other player circle 1 System Error; each Sabotage symbol can be triggered only once per game.\nMissions:\n· Three shared missions (A/B/C); the first players to fulfill one in the same turn cross more rockets, later claimants cross fewer.\nEnd:\n· Cross every rocket on the track and clear all your circled errors to launch at the end of the turn and win; ties on the same turn are broken by bonus rockets.\n· Otherwise, the game ends when a player claims all three missions, circles eight System Errors, or fills the entire sheet. Take the value of your lowest uncrossed score box and deduct 5 points per uncleared error. The highest total wins.\nAdventure sheets:\n· Switch sheets in the lobby options; the core rules are shared, but each sheet has its own effects and scoring.\nThe available adventure maps are The Launch, The Journey, The Colony, The Mine, The Dome, The Virus and The Escape.",
			optAdventure: "Adventure sheet",
			viewSheet: "View sheet",
			viewResults: "View results",
			viewPlayer: "Choose player",
			sheetFor: "View {{name}}'s sheet",
			fitSheet: "Fit sheet",
			finalScore: "{{n}} points",
			winner: "Winner",
			confirmAgain: "Confirm new game",
			confirmBack: "Confirm return to lobby",
			advSoon: "(coming soon)",
			advName: {
				a1: "The Launch",
				a2: "The Journey",
				a3: "The Colony",
				a4: "The Mine",
				a5: "The Dome",
				a6: "The Virus",
				a7: "The Escape"
			},
			pickPrompt: "Pick a combo, then tap a highlighted space",
			waitingPick: "Waiting for others to write…",
			wrote: "Written",
			tookError: "Circled a System Error",
			errorBtn: "No space to write: circle a System Error (−5 each)",
			errorBtn2: "No space to write: circle a System Error",
			buildPrompt: "Building effect: tap any empty space for an X, or skip",
			activatePrompt: "Rocket activation: tap a dim rocket, or skip",
			robotPrompt: "Robot effect: tap a station to circle a robot, or skip",
			plantPrompt: "Plant effect: tap a plant at a linked station, or skip",
			planXPrompt: "Planning effect: tap any empty space for an X, or skip",
			splitPrompt: "Energy pair: tap between two spaces to place a divider",
			modNone: "No action",
			wildBtn: "Wild",
			wildPrompt: "Cross 1 wild gear to swap the action:",
			skipEffect: "Skip this effect",
			turnChip: "Turn {{n}}",
			act: {
				robot: "Robot",
				energy: "Energy",
				plant: "Plant",
				water: "Water",
				astronaut: "Astronaut",
				planning: "Planning",
				wild: "Wild"
			},
			mission: {
				m64: "Fill the Water floor and both Astronaut floors",
				m65: "Fill the Planning floor and both Robot floors",
				m66: "Fill the Energy floor",
				m67: "Fill the Plant floor and the Wild floor",
				m68: "Write 10 X with Building effects",
				m69: "Have 5 uncleared System Errors at once",
				m70: "Circle the multiplier at 3 stations",
				m71: "Circle every plant at 2 stations",
				m72: "Carve out 2 complete zones of exactly 6 spaces",
				m73: "Carve out complete zones of 6, 4 and 2 spaces",
				m74: "Circle 6 water tanks",
				m75: "Circle 4 water tanks in a row",
				m76: "Number all buildings in 3 columns",
				m77: "Number all buildings in 3 rows",
				m78: "Connect the tunnel network to the observatory",
				m79: "Circle every antenna dish in 2 quarters",
				m80: "Circle greenhouses for 10 plants total",
				m81: "Circle every water tank in 2 quarters",
				m82: "Circle 5 extraction pumps",
				m83: "Circle 4 adjacent extraction pumps",
				m84: "Activate all 5 auxiliary factories",
				m85: "Upgrade or activate 6 factories total",
				m86: "Circle 8 plants in the mine",
				m87: "Circle 5 water in the mine",
				m88: "Fill every floor of one skyscraper",
				m89: "Write a number on the top floor of 2+ towers",
				m90: "Circle 2+ symbols on each of 3 research-tower levels",
				m91: "Circle all 3 symbols on each of 2 research-tower levels",
				m92: "Build every segment of the dome",
				m93: "Write 4 X with Planning effects",
				m94: "Evacuate 2 quarters",
				m95: "Evacuate every quarter on one floor",
				m96: "Close every walkway of 3 quarters",
				m97: "Close every walkway of the green and blue quarters",
				m98: "Circle both energy flags on 2 floors",
				m99: "Circle every plant and water tank on 2 floors",
				m100: "Circle all 3 plants in each of 3 greenhouses",
				m101: "Circle all 3 plants of the topmost starship greenhouse",
				m102: "Fill all 7 modules",
				m103: "Fill 3 starships completely",
				m104: "Circle every reactor of 3 starships",
				m105: "Circle every water tank of 3 starships"
			},
			towerPlantPrompt: "Plant effect: tap a plant on the linked tower level, or skip",
			towerWaterPrompt: "Water effect: tap the water drop on the linked tower level, or skip",
			domeBuildPrompt: "Robot effect: tap a dome segment to build it (parity must match), or skip",
			domeCutPrompt: "Planning effect: you must also tap an unbuilt segment to split it in half",
			energyUpPrompt: "Energy effect: tap an area to cross one row of boxes (better scoring), or skip",
			greyPrompt: "Outbreak: tap any space in one of the 4 empty-virus quarters to place your grey virus",
			circleEnergyPrompt: "Energy effect: tap an energy flag to circle it, or skip",
			closePrompt: "Robot effect: tap a walkway gate to close it, or skip",
			infectPrompt: "Virus spreads: pick 1 space per highlighted group (cannot skip)",
			airlockPrompt: "Robot effect: tap an airlock to activate it (links both sides), or skip",
			stemPrompt: "Resource effect: tap the matching stem right above/below the cell, or skip",
			crossBoltPrompt: "Energy effect: tap a factory bolt to cross it, or skip",
			crossRobotPrompt: "Robot effect: tap a factory robot to cross it, or skip",
			tunnelPrompt: "Robot effect: tap a tunnel to draw (must start from the network), or skip",
			energyPrompt: "Energy effect: tap a scoring track to cross its lowest box, or skip",
			missionReward: "🚀{{n}}",
			missionReward2: "+{{n}}",
			scoreAria: "Currently {{n}} points",
			errorAria: "{{n}} System Errors",
			launched: "Launched!",
			errOver: "This game is over",
			errBadStage: "Not in this phase",
			errAlreadyDone: "You already acted this turn",
			errBadCell: "Can't write here",
			errBadCombo: "No such combo",
			errCanPlace: "You still have a space to write — you must write",
			errBadEffect: "No pending effect to resolve",
			errBadTarget: "Can't target that",
			errBadMod: "Modifier not allowed now",
			errNoWild: "No wild gear to cross"
		}
	}
};
//#endregion
export { Fl as default };
