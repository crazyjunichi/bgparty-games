import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { gameAssetUrl as r } from "@bgparty/sdk/assets";
import { AVATARS as i } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as a } from "@bgparty/sdk/player-colors";
import { useWakeLock as o } from "@bgparty/sdk/use-wake-lock";
import { DeltaNumber as s } from "@bgparty/sdk/fx/delta-number";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { seatName as l } from "@bgparty/sdk/ui/player-strip";
import { useFxAnchor as u } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as d, useT as f } from "@bgparty/sdk/i18n";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { FlySprite as g, PulseBox as _ } from "@bgparty/sdk/fx/primitives";
import { Confetti as v } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as ee, OptionSection as te, OptionSwitch as ne } from "@bgparty/sdk/ui/game-options";
//#region src/games/everdell-emerland/data.ts
var y = (e, t, n, r, i, a, o, s, c, l, u, d = 0) => ({
	id: e,
	name: [t, n],
	color: r,
	building: i,
	cost: [...a, ...Array(5 - a.length).fill(0)],
	points: o,
	copies: s,
	ref: c,
	text: l,
	upgrade: u,
	capacity: d
}), b = [
	y("auctionHouse", "拍卖行", "Auction House", "blue", !0, [1, 1], 2, 1, 700, ["抽取遗物时，额外抽取1件，仍只保留1件。", "When drawing artifacts, draw 1 extra; keep only 1."], ["额外抽取2件遗物，仍只保留1件。", "Draw 2 extra artifacts; keep only 1."]),
	y("archaeologist", "考古学家", "Archaeologist", "red", !1, [
		0,
		0,
		0,
		3
	], 1, 2, 702, ["抽取1件遗物。", "Draw 1 artifact."], ["抽取3件遗物，保留1件。", "Draw 3 artifacts; keep 1."]),
	y("tunnelNetwork", "隧道网络", "Tunnel Network", "tan", !0, [3, 1], 1, 1, 706, ["打出1张牌，费用减少至多3份资源。", "Play a card for up to 3 fewer resources."], ["支付1颗祖母绿，免费打出1张牌。", "Pay 1 emerald to play a card for free."]),
	y("troubadour", "吟游诗人", "Troubadour", "tan", !1, [
		0,
		0,
		0,
		3
	], 2, 1, 707, ["支付1颗祖母绿，激活对手占据的1个地点。", "Pay 1 emerald to activate a location occupied by an opponent."], ["激活自己或对手占据的1个地点。", "Activate a location occupied by you or an opponent."]),
	y("ropeBridge", "绳桥", "Rope Bridge", "tan", !0, [
		1,
		1,
		2
	], 2, 1, 708, ["支付2颗祖母绿，获得1张领地。", "Pay 2 emeralds to gain a Realm."], ["支付1颗祖母绿，获得1张领地。", "Pay 1 emerald to gain a Realm."]),
	y("postalPigeon", "信鸽", "Postal Pigeon", "tan", !1, [
		0,
		0,
		0,
		2
	], 0, 2, 709, ["抽4张牌；不占城市空间。", "Draw 4 cards. Takes no city space."], ["弃任意数量的手牌，打出1张牌，按弃牌数量减少资源费用；不占城市空间。", "Discard any number of cards to play a card for that many fewer resources. Takes no city space."]),
	y("minersCamp", "矿工营地", "Miner’s Camp", "tan", !0, [
		1,
		1,
		1
	], 1, 2, 710, ["获得2颗祖母绿。", "Gain 2 emeralds."], ["获得3颗祖母绿。", "Gain 3 emeralds."]),
	y("lostRuin", "失落遗迹", "Lost Ruin", "tan", !0, [
		1,
		2,
		2
	], 3, 1, 711, ["抽取2件遗物，保留1件。", "Draw 2 artifacts; keep 1."], ["抽取4件遗物，保留1件。", "Draw 4 artifacts; keep 1."]),
	y("interpreter", "翻译员", "Interpreter", "tan", !1, [
		0,
		0,
		0,
		2
	], 1, 2, 712, ["激活对手城市中的1张生产牌。", "Activate 1 Production card in another city."], ["激活对手城市中的2张生产牌。", "Activate 2 Production cards in other cities."]),
	y("floatingMarket", "水上市场", "Floating Market", "tan", !0, [0, 2], 0, 2, 713, ["获得2枚不同市场骰的奖励。", "Copy 2 different Market dice."], ["获得3枚不同市场骰的奖励。", "Copy 3 different Market dice."]),
	y("dancer", "舞者", "Dancer", "tan", !1, [
		0,
		0,
		0,
		3
	], 2, 1, 714, ["获得1把竖琴。", "Gain 1 harp."], ["收回自己建筑上的1把竖琴。", "Retrieve 1 harp from your Constructions."]),
	y("crafter", "工艺师", "Crafter", "tan", !1, [
		0,
		0,
		0,
		2
	], 1, 2, 715, ["支付1颗祖母绿，升级1张牌。", "Pay 1 emerald to upgrade 1 card."], ["支付1颗祖母绿，升级2张牌。", "Pay 1 emerald to upgrade 2 cards."]),
	y("vineSurfer", "藤蔓冲浪者", "Vine Surfer", "red", !1, [
		0,
		0,
		0,
		3
	], 1, 2, 716, ["激活高台上的1张旅行牌。", "Activate 1 Traveler card in the Plateau."], ["激活高台或自己城市中的1张旅行牌。", "Activate 1 Traveler card in the Plateau or your city."]),
	y("canopyHighway", "树冠大道", "Canopy Highway", "blue", !0, [2, 3], 2, 2, 717, ["此后打出牌时，从高台拿1张牌。", "After playing another card, take a Plateau card."], ["此后打出牌时，从高台拿1张牌，并获得1分。", "After playing another card, take a Plateau card and gain 1 point."]),
	y("treetopBazaar", "树梢集市", "Treetop Bazaar", "red", !0, [
		1,
		1,
		2
	], 2, 2, 718, ["获得2枚不同市场骰的奖励。", "Copy 2 different Market dice."], ["获得3枚不同市场骰的奖励。", "Copy 3 different Market dice."]),
	y("travelCenter", "旅客中心", "Travel Center", "red", !0, [
		1,
		1,
		1
	], 1, 1, 719, ["抽2张牌；每张建筑获得1份任意资源，每张动物获得1颗祖母绿。", "Draw 2 cards. Gain a resource per Construction drawn and an emerald per Critter."], ["抽3张牌，并按牌的类别获得奖励。", "Draw 3 cards and gain the rewards for their types."]),
	y("tomb", "陵墓", "Tomb", "red", !0, [
		0,
		0,
		3
	], 2, 1, 720, ["获得1把竖琴。", "Gain 1 harp."], ["获得1颗祖母绿与1把竖琴。", "Gain 1 emerald and 1 harp."]),
	y("postOffice", "邮局", "Post Office", "red", !0, [2, 1], 1, 2, 721, ["从手牌打出1张牌，费用减少至多3份资源。", "Play a hand card for up to 3 fewer resources."], ["从手牌打出1张牌，费用减少至多3份资源；或支付1颗祖母绿免费打出。", "Play a hand card for 3 fewer resources, or pay 1 emerald to play it free."]),
	y("inn", "旅店", "Inn", "red", !0, [
		1,
		1,
		1
	], 2, 1, 722, ["从高台打出1张牌，费用减少至多3份资源。", "Play a Plateau card for up to 3 fewer resources."], ["从高台打出1张牌，费用减少至多3份资源；或支付1颗祖母绿免费打出。", "Play a Plateau card for 3 fewer resources, or pay 1 emerald to play it free."]),
	y("drummer", "鼓手", "Drummer", "red", !1, [
		0,
		0,
		0,
		2
	], 1, 2, 723, ["激活高台上的2张生产牌。", "Activate 2 Production cards in the Plateau."], ["激活高台或自己城市中的2张生产牌。", "Activate 2 Production cards in the Plateau or your city."]),
	y("caveHermit", "洞穴隐士", "Cave Hermit", "red", !1, [
		0,
		0,
		0,
		3
	], 1, 1, 724, ["升级1张牌。", "Upgrade 1 card."], ["获得1颗祖母绿，并升级1张牌。", "Gain 1 emerald and upgrade 1 card."]),
	y("adventurer", "冒险家", "Adventurer", "red", !1, [
		0,
		0,
		0,
		3
	], 1, 1, 726, ["支付2颗祖母绿，获得领地牌堆顶牌。", "Pay 2 emeralds to gain the top Realm."], ["支付2颗祖母绿，获得1张领地。", "Pay 2 emeralds to gain a Realm."]),
	y("statue", "雕像", "Statue", "purple", !0, [
		0,
		0,
		4
	], 4, 1, 727, ["拥有至少3张工匠牌，额外获得3分。", "Gain 3 bonus points with at least 3 Artisan cards."], ["拥有至少2张工匠牌，额外获得5分。", "Gain 5 bonus points with at least 2 Artisan cards."]),
	y("sanctuary", "圣所", "Sanctuary", "purple", !0, [
		3,
		3,
		3
	], 7, 1, 728, ["六类牌各至少1张，额外获得4分。", "Gain 4 bonus points with at least 1 card of every color."], ["六类牌各至少1张，额外获得7分。", "Gain 7 bonus points with at least 1 card of every color."]),
	y("sacredSite", "圣地", "Sacred Site", "purple", !0, [
		2,
		0,
		2
	], 4, 1, 729, ["拥有至少3张旅行牌，额外获得3分。", "Gain 3 bonus points with at least 3 Traveler cards."], ["拥有至少2张旅行牌，额外获得5分。", "Gain 5 bonus points with at least 2 Traveler cards."]),
	y("riverWharf", "河畔码头", "River Wharf", "purple", !0, [4, 1], 4, 1, 730, ["拥有至少4张生产牌，额外获得3分。", "Gain 3 bonus points with at least 4 Production cards."], ["拥有至少3张生产牌，额外获得5分。", "Gain 5 bonus points with at least 3 Production cards."]),
	y("performer", "表演家", "Performer", "purple", !1, [
		0,
		0,
		0,
		6
	], 3, 1, 731, ["拥有至少4张升级动物，额外获得3分。", "Gain 3 bonus points with at least 4 upgraded Critters."], ["拥有至少3张升级动物，额外获得5分。", "Gain 5 bonus points with at least 3 upgraded Critters."]),
	y("pathWeaver", "开路者", "Path Weaver", "purple", !1, [
		0,
		0,
		0,
		4
	], 3, 1, 732, ["拥有至少3张领地，额外获得3分。", "Gain 3 bonus points with at least 3 Realms."], ["拥有至少2张领地，额外获得5分。", "Gain 5 bonus points with at least 2 Realms."]),
	y("maestro", "音乐大师", "Maestro", "purple", !1, [
		0,
		0,
		0,
		5
	], 3, 1, 733, ["拥有至少3把竖琴，含已放置的竖琴，额外获得3分。", "Gain 3 bonus points with at least 3 harps, including placed harps."], ["拥有至少2把竖琴，额外获得5分。", "Gain 5 bonus points with at least 2 harps."]),
	y("gemCutter", "宝石切割师", "Gem Cutter", "purple", !1, [
		0,
		0,
		0,
		6
	], 3, 1, 734, ["拥有至少3张繁荣牌，额外获得3分。", "Gain 3 bonus points with at least 3 Prosperity cards."], ["拥有至少2张繁荣牌，额外获得5分。", "Gain 5 bonus points with at least 2 Prosperity cards."]),
	y("fountain", "喷泉", "Fountain", "purple", !0, [
		3,
		2,
		1
	], 4, 1, 735, ["拥有至少3张治理牌，额外获得3分。", "Gain 3 bonus points with at least 3 Governance cards."], ["拥有至少2张治理牌，额外获得5分。", "Gain 5 bonus points with at least 2 Governance cards."]),
	y("elder", "长者", "Elder", "purple", !1, [
		0,
		0,
		0,
		4
	], 3, 1, 736, ["拥有至少4张升级建筑，额外获得3分。", "Gain 3 bonus points with at least 4 upgraded Constructions."], ["拥有至少3张升级建筑，额外获得5分。", "Gain 5 bonus points with at least 3 upgraded Constructions."]),
	y("curator", "馆长", "Curator", "purple", !1, [
		0,
		0,
		0,
		4
	], 3, 1, 737, ["拥有至少5件遗物，额外获得3分。", "Gain 3 bonus points with at least 5 artifacts."], ["拥有至少4件遗物，额外获得5分。", "Gain 5 bonus points with at least 4 artifacts."]),
	y("canopyStadium", "树冠竞技场", "Canopy Stadium", "purple", !0, [
		2,
		2,
		2
	], 4, 1, 738, ["拥有至少3张目的地牌，额外获得3分。", "Gain 3 bonus points with at least 3 Destination cards."], ["拥有至少2张目的地牌，额外获得5分。", "Gain 5 bonus points with at least 2 Destination cards."]),
	y("tradeGate", "贸易之门", "Trade Gate", "orange", !0, [2, 1], 1, 2, 739, ["支付1份任意资源，获得2份任意资源。", "Pay 1 resource to gain 2 resources."], ["支付1份任意资源，获得2份任意资源与2分。", "Pay 1 resource to gain 2 resources and 2 points."], 2),
	y("studio", "工作室", "Studio", "orange", !0, [
		2,
		0,
		2
	], 1, 2, 800, ["支付1颗祖母绿，升级1张牌。", "Pay 1 emerald to upgrade 1 card."], ["升级1张牌。", "Upgrade 1 card."], 2),
	y("mapShop", "地图商店", "Map Shop", "orange", !0, [
		1,
		2,
		1
	], 2, 1, 801, ["支付2颗祖母绿，获得1张领地。", "Pay 2 emeralds to gain a Realm."], ["获得1张领地。", "Gain a Realm."], 1),
	y("luthier", "制琴师", "Luthier", "orange", !1, [
		0,
		0,
		0,
		2
	], 0, 2, 802, ["获得2份竹材与1分。", "Gain 2 bamboo and 1 point."], ["获得3份竹材与1分。", "Gain 3 bamboo and 1 point."], 2),
	y("gardener", "园丁", "Gardener", "orange", !1, [
		0,
		0,
		0,
		3
	], 1, 2, 803, ["获得1片叶片与1分。", "Gain 1 leaf and 1 point."], ["获得2片叶片与1分。", "Gain 2 leaves and 1 point."], 2),
	y("gallery", "画廊", "Gallery", "orange", !0, [1, 2], 1, 1, 804, ["抽取1件遗物。", "Draw 1 artifact."], ["抽取3件遗物，保留1件。", "Draw 3 artifacts; keep 1."], 2),
	y("chiseler", "石匠", "Chiseler", "orange", !1, [
		0,
		0,
		0,
		4
	], 2, 2, 805, ["获得1块大理石与1分。", "Gain 1 marble and 1 point."], ["获得2块大理石与1分。", "Gain 2 marble and 1 point."], 2),
	y("chef", "厨师", "Chef", "orange", !1, [
		0,
		0,
		0,
		3
	], 2, 2, 806, ["获得1颗无花果与1分。", "Gain 1 fig and 1 point."], ["获得2颗无花果与1分。", "Gain 2 figs and 1 point."], 2),
	y("bridgeBuilder", "造桥师", "Bridge Builder", "orange", !1, [
		0,
		0,
		0,
		4
	], 1, 1, 807, ["获得1份任意资源。", "Gain 1 resource."], ["获得2份任意资源。", "Gain 2 resources."], 2),
	y("academy", "学院", "Academy", "orange", !0, [
		1,
		0,
		2
	], 2, 1, 808, ["从1个地点收回自己的1名工人。", "Retrieve your worker from 1 location."], ["从1个地点收回自己的1名工人与1名助手。", "Retrieve your worker and 1 helper from 1 location."], 1),
	y("treeNursery", "苗圃", "Tree Nursery", "green", !0, [
		1,
		1,
		1
	], 1, 2, 809, ["获得1片叶片。", "Gain 1 leaf."], ["获得2片叶片。", "Gain 2 leaves."]),
	y("tradeDock", "贸易码头", "Trade Dock", "green", !0, [2, 1], 2, 1, 810, ["获得1枚市场骰的奖励。", "Copy 1 Market die."], ["获得2枚不同市场骰的奖励。", "Copy 2 different Market dice."]),
	y("skyScout", "空中斥候", "Sky Scout", "green", !1, [
		0,
		0,
		0,
		1
	], 0, 2, 811, ["抽1张牌。", "Draw 1 card."], ["抽2张牌。", "Draw 2 cards."]),
	y("ropeMiner", "索道矿工", "Rope Miner", "green", !1, [
		0,
		0,
		0,
		2
	], 1, 2, 812, ["弃1张手牌，获得1份任意资源或1颗祖母绿。", "Discard a card to gain a resource or an emerald."], ["弃1张手牌，获得1份任意资源与1颗祖母绿。", "Discard a card to gain a resource and an emerald."]),
	y("piper", "笛手", "Piper", "green", !1, [
		0,
		0,
		0,
		3
	], 1, 2, 813, ["支付1份竹材或叶片，获得1份任意资源与1分。", "Pay 1 bamboo or leaf to gain a resource and 1 point."], ["支付1份竹材或叶片，获得2份任意资源与2分。", "Pay 1 bamboo or leaf to gain 2 resources and 2 points."]),
	y("noveltyShop", "珍奇商店", "Novelty Shop", "green", !0, [0, 1], 1, 2, 814, ["抽1张牌，并获得1分。", "Draw 1 card and gain 1 point."], ["抽2张牌，并获得1分。", "Draw 2 cards and gain 1 point."]),
	y("mineShaft", "矿井", "Mine Shaft", "green", !0, [
		2,
		0,
		1
	], 2, 1, 815, ["获得1颗祖母绿。", "Gain 1 emerald."], ["获得2颗祖母绿。", "Gain 2 emeralds."]),
	y("marbleQuarry", "大理石采场", "Marble Quarry", "green", !0, [
		1,
		1,
		1
	], 2, 2, 816, ["获得1块大理石。", "Gain 1 marble."], ["获得2块大理石。", "Gain 2 marble."]),
	y("juggler", "杂耍艺人", "Juggler", "green", !1, [
		0,
		0,
		0,
		1
	], 1, 2, 817, ["支付1份任意资源，获得1份任意资源。", "Pay 1 resource to gain 1 resource."], ["支付1份任意资源，获得2份任意资源。", "Pay 1 resource to gain 2 resources."]),
	y("harpist", "竖琴师", "Harpist", "green", !1, [
		0,
		0,
		0,
		4
	], 1, 1, 818, ["支付1颗祖母绿，获得1把竖琴。", "Pay 1 emerald to gain 1 harp."], ["支付1份任意资源，获得1把竖琴。", "Pay 1 resource to gain 1 harp."]),
	y("fruitMarket", "水果市场", "Fruit Market", "green", !0, [2, 1], 1, 2, 819, ["获得1颗无花果。", "Gain 1 fig."], ["获得2颗无花果。", "Gain 2 figs."]),
	y("digger", "挖掘者", "Digger", "green", !1, [
		0,
		0,
		0,
		3
	], 1, 1, 820, ["弃1张手牌，抽取1件遗物。", "Discard a card to draw 1 artifact."], ["抽取1件遗物。", "Draw 1 artifact."]),
	y("chipchop", "伐木工", "Chipchop", "green", !1, [
		0,
		0,
		0,
		2
	], 1, 2, 821, ["激活高台上的1张生产牌。", "Activate 1 Production card in the Plateau."], ["激活高台或自己城市中的另1张生产牌。", "Activate 1 other Production card in the Plateau or your city."]),
	y("cargoMill", "货运磨坊", "Cargo Mill", "green", !0, [
		1,
		0,
		1
	], 1, 2, 822, ["获得1份竹材。", "Gain 1 bamboo."], ["获得2份竹材。", "Gain 2 bamboo."]),
	y("baseCamp", "大本营", "Base Camp", "green", !0, [
		1,
		1,
		1
	], 1, 1, 823, ["弃掉1件遗物，再抽取1件遗物。", "Discard an artifact to draw 1 artifact."], ["弃掉1件遗物，再抽取2件，保留1件。", "Discard an artifact to draw 2; keep 1."]),
	y("apothecary", "药剂师", "Apothecary", "green", !1, [
		0,
		0,
		0,
		4
	], 2, 2, 824, ["支付1颗无花果或1块大理石，获得1份任意资源与2分。", "Pay 1 fig or marble to gain a resource and 2 points."], ["支付1颗无花果或1块大理石，获得2份任意资源与2分。", "Pay 1 fig or marble to gain 2 resources and 2 points."]),
	y("waypoint", "路标站", "Waypoint", "blue", !0, [
		1,
		1,
		2
	], 1, 1, 825, ["打出动物时，可弃1张手牌，使费用减少1颗无花果。", "When playing a Critter, discard a card to pay 1 fewer fig."], ["打出动物的费用减少1颗无花果。", "Critters cost 1 fewer fig."]),
	y("trumpeter", "号手", "Trumpeter", "blue", !1, [
		0,
		0,
		0,
		3
	], 1, 1, 826, ["获得竖琴后，获得2分。", "After gaining a harp, gain 2 points."], ["获得竖琴后，获得1颗祖母绿与2分。", "After gaining a harp, gain 1 emerald and 2 points."]),
	y("thatcher", "屋顶工", "Thatcher", "blue", !1, [
		0,
		0,
		0,
		3
	], 1, 2, 827, ["此后打出建筑时，抽1张牌。", "After playing a Construction, draw 1 card."], ["此后打出建筑时，抽1张牌并获得1分。", "After playing a Construction, draw 1 card and gain 1 point."]),
	y("steamboat", "汽船", "Steamboat", "blue", !0, [3, 1], 1, 2, 828, ["工人带助手派遣后，可弃1张手牌，获得1份任意资源。", "After placing a worker with a helper, discard a card to gain a resource."], ["工人带助手派遣后，获得1份任意资源。", "After placing a worker with a helper, gain a resource."]),
	y("riverExplorer", "河流探险家", "River Explorer", "blue", !1, [
		0,
		0,
		0,
		3
	], 1, 1, 829, ["打出建筑时，可弃1张手牌，使费用减少1份任意资源。", "When playing a Construction, discard a card to pay 1 fewer resource."], ["打出建筑的费用减少1份任意资源。", "Constructions cost 1 fewer resource."]),
	y("playwright", "剧作家", "Playwright", "blue", !1, [
		0,
		0,
		0,
		3
	], 1, 2, 830, ["此后打出动物时，抽1张牌。", "After playing a Critter, draw 1 card."], ["此后打出动物时，抽1张牌并获得1分。", "After playing a Critter, draw 1 card and gain 1 point."]),
	y("nightwatch", "守夜者", "Nightwatch", "blue", !1, [
		0,
		0,
		0,
		2
	], 2, 1, 831, ["派工进入已占据地点时，可弃1张手牌代替谈判助手。", "Discard a card instead of a negotiator when entering an occupied board location."], ["保留原能力，且不再占城市空间。", "Keep the ability. Takes no city space."]),
	y("gemWorkshop", "宝石工坊", "Gem Workshop", "blue", !0, [
		2,
		0,
		2
	], 1, 2, 832, ["获得祖母绿时，抽2张牌。", "When gaining emeralds, draw 2 cards."], ["获得祖母绿时，抽2张牌或额外获得1颗祖母绿。", "When gaining emeralds, draw 2 cards or gain 1 extra emerald."])
], x = Object.fromEntries(b.map((e) => [e.id, e])), re = [
	"green",
	"blue",
	"tan",
	"red",
	"orange",
	"purple"
], ie = {
	green: ["生产", "Production"],
	blue: ["治理", "Governance"],
	tan: ["旅行", "Traveler"],
	red: ["目的地", "Destination"],
	orange: ["工匠", "Artisan"],
	purple: ["繁荣", "Prosperity"]
}, ae = [[
	"竹材",
	"叶片",
	"大理石",
	"无花果",
	"祖母绿"
], [
	"Bamboo",
	"Leaf",
	"Marble",
	"Fig",
	"Emerald"
]], oe = [[
	"夏季",
	"秋季",
	"冬季",
	"春季"
], [
	"Summer",
	"Autumn",
	"Winter",
	"Spring"
]], se = [
	[
		"emerald",
		"宝石矿",
		"Gem Mine",
		"2颗祖母绿",
		"2 emeralds"
	],
	[
		"marble",
		"采石场",
		"Quarry",
		"1块大理石，抽1张牌",
		"1 marble, draw 1"
	],
	[
		"bamboo",
		"竹林",
		"Bamboo Grove",
		"3份竹材",
		"3 bamboo"
	],
	[
		"leaf",
		"叶林",
		"Leaf Grove",
		"2片叶片",
		"2 leaves"
	],
	[
		"fig",
		"果园",
		"Fig Orchard",
		"2颗无花果",
		"2 figs"
	],
	[
		"market",
		"河流市场",
		"River Market",
		"2枚不同市场骰的奖励",
		"Copy 2 different dice"
	],
	[
		"realm",
		"领地喷泉",
		"Realm Fountain",
		"支付2颗祖母绿，获得1张领地",
		"Pay 2 emeralds; gain a Realm"
	],
	[
		"song",
		"歌谣喷泉",
		"Song Fountain",
		"支付1颗祖母绿，获得竖琴并补满手牌",
		"Pay 1 emerald; gain a harp and fill hand"
	],
	[
		"exchange",
		"河畔喷泉",
		"River Fountain",
		"拿2张高台牌、1颗祖母绿与1枚骰的奖励",
		"Take 2 Plateau cards, 1 emerald and copy 1 die"
	],
	[
		"treasure",
		"遗物喷泉",
		"Artifact Fountain",
		"获得1颗祖母绿与1件遗物",
		"Gain 1 emerald and 1 artifact"
	],
	[
		"grandMarket",
		"商船喷泉",
		"Trading Fountain",
		"支付1颗祖母绿，获得所有市场骰奖励",
		"Pay 1 emerald; copy all Market dice"
	],
	[
		"upgrade",
		"升级",
		"Upgrade",
		"支付1颗祖母绿，升级1张牌",
		"Pay 1 emerald; upgrade a card"
	],
	[
		"mooring",
		"泊船处",
		"Mooring",
		"抽2张牌或获得1枚市场骰奖励",
		"Draw 2 cards or copy 1 die"
	]
], S = {
	scale: {
		name: ["天平", "Scales"],
		points: 2,
		copies: 1,
		ref: "006_1358870d5c68.png",
		text: ["支付1份任意资源，获得2份任意资源。", "Pay a resource to gain 2 resources."]
	},
	ocarina: {
		name: ["陶笛", "Ocarina"],
		points: 5,
		copies: 4,
		ref: "007_d5f0184703cb.png",
		text: ["", ""]
	},
	pot: {
		name: ["陶罐", "Pot"],
		points: 1,
		copies: 4,
		ref: "008_02b05ea3f2a3.png",
		text: ["获得1份任意资源。", "Gain 1 resource."]
	},
	dice: {
		name: ["古骰", "Ancient Dice"],
		points: 2,
		copies: 4,
		ref: "009_b03dec4135ea.png",
		text: ["获得1枚市场骰的奖励。", "Copy 1 Market die."]
	},
	coin: {
		name: ["金币", "Coin"],
		points: 3,
		copies: 6,
		ref: "010_f01ae6222ce1.png",
		text: ["", ""]
	},
	harp: {
		name: ["古竖琴", "Ancient Harp"],
		points: 1,
		copies: 1,
		ref: "011_31344d681fe6.png",
		text: ["获得1把竖琴。", "Gain 1 harp."]
	},
	ring: {
		name: ["戒指", "Ring"],
		points: 1,
		copies: 5,
		ref: "012_e0b752583e29.png",
		text: ["获得1颗祖母绿。", "Gain 1 emerald."]
	},
	parchment: {
		name: ["卷轴", "Parchment"],
		points: 2,
		copies: 5,
		ref: "013_345a6ba3a1e4.png",
		text: ["从高台拿1张牌。", "Take a Plateau card."]
	},
	necklace: {
		name: ["项链", "Necklace"],
		points: 6,
		copies: 2,
		ref: "014_1f7fc86fc9a6.png",
		text: ["", ""]
	},
	cloth: {
		name: ["织物", "Cloth"],
		points: 1,
		copies: 1,
		ref: "015_269f377566d3.png",
		text: ["升级1张牌。", "Upgrade a card."]
	},
	sundial: {
		name: ["日晷", "Sundial"],
		points: 2,
		copies: 1,
		ref: "016_09e071e89f6a.png",
		text: ["激活自己城市或高台上的1张生产牌。", "Activate a Production card in your city or the Plateau."]
	},
	cape: {
		name: ["披风", "Cape"],
		points: 2,
		copies: 5,
		ref: "017_31cc6f05d54c.png",
		text: ["抽1张牌。", "Draw 1 card."]
	},
	chest: {
		name: ["宝箱", "Chest"],
		points: 2,
		copies: 1,
		ref: "018_327098ca57d0.png",
		text: ["再抽取并保留1件遗物。", "Draw and keep another artifact."]
	},
	statue: {
		name: ["古雕像", "Ancient Statue"],
		points: 4,
		copies: 4,
		ref: "019_c89ef00723db.png",
		text: ["", ""]
	},
	crown: {
		name: ["王冠", "Crown"],
		points: 7,
		copies: 1,
		ref: "020_a9cc2f1f538f.png",
		text: ["", ""]
	}
}, C = [
	{
		name: ["幽洞", "Cavern"],
		text: ["每张升级牌1分。", "1 point per upgraded card."]
	},
	{
		name: ["峭壁", "Cliffside"],
		text: ["每张旅行牌2分。", "2 points per Traveler."]
	},
	{
		name: ["河流", "River"],
		text: ["每张治理牌2分。", "2 points per Governance card."]
	},
	{
		name: ["藤冠", "Vine Canopy"],
		text: ["每张目的地牌2分。", "2 points per Destination."]
	},
	{
		name: ["云雾林", "Cloud Forest"],
		text: ["每张工匠牌2分。", "2 points per Artisan."]
	},
	{
		name: ["湖泊", "Lake"],
		text: ["城市中每种牌色2分。", "2 points per different city card color."]
	},
	{
		name: ["山谷", "Valley"],
		text: ["每张动物1分。", "1 point per Critter."]
	},
	{
		name: ["灌木丛", "Thicket"],
		text: ["每张建筑1分。", "1 point per Construction."]
	},
	{
		name: ["花冠", "Flower Canopy"],
		text: ["每2枚分数标记1分。", "1 point per 2 point tokens."]
	},
	{
		name: ["巨树", "Giant Tree"],
		text: ["每张升级建筑2分。", "2 points per upgraded Construction."]
	},
	{
		name: ["山顶", "Mountain Top"],
		text: ["每张领地3分。", "3 points per Realm."]
	},
	{
		name: ["废墟", "Ruins"],
		text: ["每种不同遗物1分。", "1 point per different artifact."]
	},
	{
		name: ["峡谷", "Canyon"],
		text: ["每把竖琴2分，含已放置的竖琴。", "2 points per harp, including placed harps."]
	},
	{
		name: ["海滩", "Beach"],
		text: ["每张升级动物2分。", "2 points per upgraded Critter."]
	},
	{
		name: ["天坑", "Sinkhole"],
		text: ["建筑上每把竖琴2分。", "2 points per placed harp."]
	},
	{
		name: ["洞穴", "Cave"],
		text: ["工匠牌下每张弃牌2分。", "2 points per card tucked under Artisans."]
	},
	{
		name: ["瀑布", "Waterfall"],
		text: ["每张繁荣牌3分。", "3 points per Prosperity card."]
	},
	{
		name: ["火山", "Volcano"],
		text: ["每张生产牌2分。", "2 points per Production card."]
	}
], ce = [
	{
		stops: [
			["fig", 2],
			["marble", 1],
			["realm", 2],
			["leaf", 1]
		],
		plan: "emerald",
		fallback: "mooring",
		reward: "emerald"
	},
	{
		stops: [
			["bamboo", 2],
			["market", 1],
			["song", 1],
			["emerald", 2]
		],
		plan: "point",
		fallback: "mooring",
		reward: "point"
	},
	{
		stops: [
			["leaf", 2],
			["bamboo", 2],
			["red", 1],
			["emerald", 1]
		],
		plan: "excavate",
		fallback: "mooring",
		reward: "emerald"
	},
	{
		stops: [
			["bamboo", 1],
			["realm", 1],
			["leaf", 2],
			["market", 2]
		],
		plan: "point",
		fallback: "mooring",
		reward: "point"
	},
	{
		stops: [
			["marble", 1],
			["song", 1],
			["market", 2],
			["red", 1]
		],
		plan: "emerald",
		fallback: "mooring",
		reward: "emerald"
	},
	{
		stops: [
			["market", 2],
			["emerald", 2],
			["marble", 1],
			["fig", 2]
		],
		plan: "excavate",
		fallback: "mooring",
		reward: "point"
	},
	{
		stops: [
			["emerald", 1],
			["fig", 1],
			["market", 2],
			["bamboo", 2]
		],
		plan: "point",
		fallback: "mooring",
		reward: "point"
	},
	{
		stops: [
			["bamboo", 2],
			["leaf", 1],
			["fig", 2],
			["market", 2]
		],
		plan: "excavate",
		fallback: "mooring",
		reward: "emerald"
	},
	{
		stops: [
			["market", 2],
			["leaf", 2],
			["red", 1],
			["bamboo", 2]
		],
		plan: "excavate",
		fallback: "mooring",
		reward: "emerald"
	}
], w = [
	{
		targets: [
			"a2",
			"apurple",
			"cblue",
			"a1"
		],
		plan: "point",
		reward: ""
	},
	{
		targets: [
			"cpurple",
			"corange",
			"ub2",
			"bpurple"
		],
		plan: "realm1",
		reward: ""
	},
	{
		targets: [
			"b4",
			"ubgreen",
			"cpurple",
			"cred"
		],
		plan: "excavate",
		reward: "point"
	},
	{
		targets: [
			"c1",
			"uared",
			"aorange",
			"b4"
		],
		plan: "emerald",
		reward: "emerald"
	},
	{
		targets: [
			"bblue",
			"uctan",
			"bpurple",
			"cgreen"
		],
		plan: "excavate",
		reward: "point"
	},
	{
		targets: [
			"bred",
			"c2",
			"bpurple",
			"a0"
		],
		plan: "emerald",
		reward: ""
	},
	{
		targets: [
			"a0",
			"bpurple",
			"c2",
			"borange"
		],
		plan: "point",
		reward: "emerald"
	},
	{
		targets: [
			"ub1",
			"b2",
			"ctan",
			"apurple"
		],
		plan: "realm0",
		reward: ""
	},
	{
		targets: [
			"b4",
			"btan",
			"a2",
			"apurple"
		],
		plan: "realm2",
		reward: ""
	}
], le = [
	[
		"artifact",
		"discard1emerald",
		"clear:red",
		"stealOrPay"
	],
	[
		"stealEmerald",
		"discard2",
		"loseHarp",
		"steal"
	],
	[
		"clear:blue,tan",
		"discard1",
		"lose1discard",
		"realmTop"
	],
	[
		"dice",
		"clear:green",
		"stealLowest",
		"artifact"
	],
	[
		"discard1",
		"dice",
		"discard1emerald",
		"stealOrPay"
	],
	[
		"clear:orange",
		"lose2",
		"artifact",
		"loseEmeraldPoint"
	],
	[
		"clear:critter",
		"artifact",
		"lose2",
		"stealEmerald"
	],
	[
		"loseEmeraldPoint",
		"clear:critter",
		"discard1",
		"dice"
	],
	[
		"lose1discard",
		"back",
		"dice",
		"discard2"
	]
], T = {
	id: "everdell-emerland",
	tier: "alpha",
	mechanics: [
		"worker-placement",
		"engine-building",
		"set-collection"
	],
	interactionTags: [],
	nameKey: "games.everdell-emerland.name",
	descKey: "games.everdell-emerland.desc",
	rulesKey: "games.everdell-emerland.rules",
	icon: "💎",
	iconImg: "games/everdell-emerland.webp",
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#236a52",
	releasedAt: "2026-11-07T02:11:50+08:00",
	search: {
		py: "",
		init: ""
	},
	hotseat: "cover",
	botDelayMs: 550,
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/15911528853685526583/C8F7FCEB3A01BB316A4D431FF1AADCCEB072F248/" }
}, ue = t.tuple([
	t.int().nonnegative(),
	t.int().nonnegative(),
	t.int().nonnegative(),
	t.int().nonnegative(),
	t.int().nonnegative()
]), E = t.object({
	soloDifficulty: t.enum(["normal", "hard"]).default("normal"),
	tricks: t.boolean().default(!1)
}).prefault({}), de = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	id: t.string().max(80)
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), fe = t.object({
	uid: t.int(),
	card: t.string(),
	upgraded: t.boolean(),
	harp: t.boolean(),
	tucked: t.int().nonnegative()
}), pe = t.object({
	uid: t.int(),
	rid: t.string(),
	location: t.string(),
	worker: t.int().nonnegative(),
	helpers: t.int().nonnegative(),
	guide: t.boolean()
}), D = t.object({
	id: t.string(),
	kind: t.string(),
	value: t.string(),
	card: t.string().optional(),
	uid: t.int().optional(),
	owner: t.string().optional(),
	n: t.int().optional(),
	cost: ue.optional(),
	mode: t.string().optional()
}), O = t.object({
	cards: t.int(),
	prosperity: t.int(),
	points: t.int(),
	artifacts: t.int(),
	path: t.int(),
	realms: t.int(),
	resources: t.int(),
	total: t.int()
}), k = t.object({
	rid: t.string(),
	season: t.int().min(0).max(3),
	ended: t.boolean(),
	resources: ue,
	points: t.int(),
	workers: t.int(),
	helpers: t.int(),
	harps: t.int(),
	handCount: t.int(),
	city: t.array(fe),
	artifacts: t.array(t.string()),
	realms: t.array(t.int()),
	path: t.int(),
	lostCity: t.int(),
	score: O
}), me = t.object({
	phase: t.enum([
		"play",
		"settle",
		"done"
	]),
	turn: t.string(),
	actor: t.string(),
	prompt: t.string(),
	source: t.string().nullable(),
	sourceUid: t.int().nullable(),
	promptN: t.int(),
	revision: t.int(),
	plateau: t.array(t.object({
		card: t.string(),
		count: t.int()
	})),
	realms: t.array(t.int()),
	dice: t.array(t.int()),
	pathPiles: t.array(t.array(t.int())),
	lostCityAvailable: t.array(t.int()),
	deckCount: t.int(),
	discardCount: t.int(),
	artifactCount: t.int(),
	placements: t.array(pe),
	players: t.array(k),
	artifactsOffered: t.array(t.string()),
	config: E,
	koto: t.object({
		player: k,
		deck: t.enum([
			"expedition",
			"excavation",
			"trick"
		]).nullable(),
		card: t.int().nullable()
	}).nullable(),
	log: t.array(t.object({
		rid: t.string(),
		kind: t.string(),
		value: t.string(),
		n: t.int()
	}))
}), A = t.object({
	hand: t.array(t.string()),
	choices: t.array(D)
}), he = () => [
	0,
	0,
	0,
	0,
	0
], j = (e) => e.reduce((e, t) => e + t, 0), M = (e) => [...e.players, ...e.koto ? [e.koto.player] : []], N = (e, t) => M(e).find((e) => e.rid === t), P = (e, t) => M(e).flatMap((e) => e.city).find((e) => e.uid === t), ge = (e, t) => e.city.filter((e) => e.card === t), F = (e, t, n = {}) => ({
	kind: e,
	rid: t,
	...n
}), I = (e, ...t) => {
	e.queue.unshift(...t);
}, L = (t, n) => e(t.seed, t.cursor++, n);
function R(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; t--) {
		let r = L(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
var z = (e, t, n, r = "", i = 0) => {
	e.log.push({
		rid: t,
		kind: n,
		value: r,
		n: i
	}), e.log.length > 80 && e.log.shift();
}, B = (e, t, n = !1) => (n ? t.helpers : t.workers) - e.placements.filter((e) => e.rid === t.rid).reduce((e, t) => e + (n ? t.helpers : t.worker), 0), _e = (e) => e.city.filter((e) => e.card !== "postalPigeon" && !(e.card === "nightwatch" && e.upgraded)).length, ve = (e, t) => t === "postalPigeon" || _e(e) < 12 + e.realms.length;
function ye(e) {
	return !e.deck.length && e.discard.length && (e.deck = R(e, e.discard), e.discard = []), e.deck.pop();
}
function V(e, t, n) {
	let r = N(e, t), i = [];
	if (r.ended || t === "$koto") return i;
	for (let t = 0; t < n && r.hand.length < 6; t++) {
		let t = ye(e);
		if (!t) break;
		r.hand.push(t), i.push(t);
	}
	return i;
}
function be(e) {
	for (; e.plateau.filter((e) => e.count > 0).length < 6;) {
		let t = ye(e);
		if (!t) break;
		let n = e.plateau.find((e) => e.card === t && e.count > 0);
		if (n) n.count++;
		else {
			let n = e.plateau.findIndex((e) => e.count === 0);
			n >= 0 ? e.plateau[n] = {
				card: t,
				count: 1
			} : e.plateau.push({
				card: t,
				count: 1
			});
		}
	}
	e.plateau = e.plateau.filter((e) => e.count > 0);
}
function xe(e, t) {
	let n = e.plateau.find((e) => e.card === t);
	return !n || !n.count ? !1 : (n.count--, !0);
}
function H(e, t, n, r = 1, i = !0) {
	let a = N(e, t);
	a.ended || r <= 0 || (a.resources[n] += r, n === 4 && i && t !== "$koto" && I(e, ...ge(a, "gemWorkshop").map((e) => F("workshop", t, {
		uid: e.uid,
		card: e.card,
		up: e.upgraded
	}))));
}
function Se(e, t) {
	let n = N(e, t);
	n.ended || t === "$koto" || (n.harps++, I(e, ...ge(n, "trumpeter").map((e) => U(t, e))), z(e, t, "harp"));
}
var U = (e, t, n = [], r) => F("activate", e, {
	card: t.card,
	uid: t.uid,
	up: t.upgraded,
	chain: n,
	owner: r
}), W = (e, t = 1, n = {}) => F("resource", e, {
	n: t,
	...n
}), G = (e, t, n, r = [
	"0",
	"1",
	"2",
	"3"
]) => F("payResource", e, {
	n: t,
	after: n,
	ids: r
}), Ce = (e, t, n, r, i = [], a = {}) => F("discard", e, {
	min: t,
	max: n,
	count: 0,
	mode: r,
	after: i,
	...a
}), K = (e, t, n) => F("emeraldCost", e, {
	n: t,
	after: n
}), we = (e, t = 1) => F("upgrade", e, { n: t }), q = (e, t = 1) => F("artifactDraw", e, { n: t }), Te = (e, t, n = 1) => F("dice", e, {
	n: t,
	max: n,
	ids: []
}), Ee = (e, t, n, r) => F("copy", e, {
	mode: t,
	n,
	ids: [],
	chain: r
});
function De(e, t, n) {
	let r = [], i = Math.max(0, j(e.slice(0, 4)) - n);
	for (let n = 0; n <= Math.min(e[0], t[0]); n++) for (let a = 0; a <= Math.min(e[1], t[1]); a++) for (let o = 0; o <= Math.min(e[2], t[2]); o++) for (let s = 0; s <= Math.min(e[3], t[3]); s++) n + a + o + s === i && r.push([
		n,
		a,
		o,
		s,
		0
	]);
	return r;
}
function Oe(e, t, n, r, i = 0, a = !1) {
	let o = N(e, t), s = x[n];
	if (!s || !ve(o, n) && n !== "nightwatch") return [];
	let c = [], l = ge(o, s.building ? "riverExplorer" : "waypoint"), u = [...s.cost], d = i;
	s.building ? d += l.filter((e) => e.upgraded).length : u[3] = Math.max(0, u[3] - l.filter((e) => e.upgraded).length);
	let f = (e, t, n, r) => De(e, o.resources, t).forEach((e) => c.push({
		cost: e,
		mode: n,
		value: r
	}));
	if (a && ve(o, n) ? c.push({
		cost: he(),
		mode: "free"
	}) : ve(o, n) && (f(u, d, "pay"), l.some((e) => !e.upgraded) && o.hand.forEach((e, t) => {
		if (r !== `h:${t}`) {
			let e = [...u];
			s.building || (e[3] = Math.max(0, e[3] - 1)), f(e, d + +!!s.building, "discard", String(t));
		}
	})), !s.building && o.harps > 0) {
		let e = new Set(o.city.filter((e) => e.harp).map((e) => x[e.card].color));
		for (let t of o.city) x[t.card].building && t.upgraded && !t.harp && !e.has(x[t.card].color) && c.push({
			cost: he(),
			mode: "harp",
			uid: t.uid
		});
	}
	return c;
}
var J = (e, t = "", n = {}) => ({
	id: "",
	kind: e,
	value: t,
	...n
}), ke = [
	"emerald",
	"marble",
	"bamboo",
	"leaf",
	"fig",
	"market"
];
function Ae(e) {
	return se.filter((t) => t[0] !== "exchange" || e.players.length >= 3).filter((t) => !["treasure", "grandMarket"].includes(t[0]) || e.players.length === 4);
}
function je(e, t) {
	let n = N(e, t), r = [], i = B(e, n), a = B(e, n, !0);
	if (i > 0) for (let i of Ae(e).filter((e) => !["upgrade", "mooring"].includes(e[0]))) {
		let o = i[0], s = e.placements.some((e) => e.location === o);
		if ((ke.includes(o) || !e.placements.some((e) => e.rid === t && e.location === o)) && !(o === "realm" && (n.resources[4] < 2 || !e.realms.length && !e.realmDeck.length) || o === "song" && n.resources[4] < 1 || o === "grandMarket" && n.resources[4] < 1)) for (let e of [!1, !0]) {
			if (e && (!s || !ge(n, "nightwatch").length || !n.hand.length)) continue;
			let t = s && !e ? 1 : 0;
			for (let n of [!1, !0]) {
				if (n && !ke.includes(o)) continue;
				let i = t + Number(n);
				i <= a && r.push(J("place", o, {
					n: i,
					mode: `${e ? "night" : "normal"}${n ? ":guide" : ""}`
				}));
			}
		}
	}
	a > 0 && (r.push(J("helper", "mooring")), n.resources[4] > 0 && n.city.some((e) => !e.upgraded) && r.push(J("helper", "upgrade")));
	for (let n of M(e)) for (let o of n.city) if (x[o.card].color === "red" && (n.rid === t || x[o.card].building)) {
		let s = `c:${o.uid}`, c = n.rid === t;
		if (e.placements.some((e) => e.location === s && (c ? e.rid === t : e.rid !== n.rid))) continue;
		i > 0 && r.push(J("place", s, {
			uid: o.uid,
			card: o.card,
			owner: n.rid,
			n: 0,
			mode: "normal"
		})), c && !x[o.card].building && a > 0 && r.push(J("helper", s, {
			uid: o.uid,
			card: o.card,
			owner: n.rid
		}));
	}
	return r;
}
function Me(e, t) {
	let n = [], r = t.chain ?? [], i = t.mode?.includes("tan") ? "tan" : "green";
	if (!t.mode?.startsWith("other")) for (let a of e.plateau) a.count > 0 && x[a.card].color === i && !r.includes(a.card) && !t.ids?.includes(`p:${a.card}`) && n.push(J("copy", `p:${a.card}`, { card: a.card }));
	for (let a of M(e)) if (!(t.mode?.startsWith("other") ? a.rid === t.rid : a.rid !== t.rid || !t.mode?.includes("own"))) for (let e of a.city) x[e.card].color === i && !r.includes(e.card) && !t.ids?.includes(`c:${e.uid}`) && n.push(J("copy", `c:${e.uid}`, {
		uid: e.uid,
		card: e.card,
		owner: a.rid,
		mode: e.upgraded ? "up" : ""
	}));
	return n;
}
function Ne(e, t) {
	let n = N(e, t.rid), r = [];
	switch (t.kind) {
		case "turn": {
			r.push(...je(e, t.rid)), n.hand.forEach((n, i) => {
				Oe(e, t.rid, n, `h:${i}`).length && r.push(J("play", `h:${i}`, { card: n }));
			});
			for (let n of e.plateau) n.count > 0 && Oe(e, t.rid, n.card, `p:${n.card}`).length && r.push(J("play", `p:${n.card}`, { card: n.card }));
			for (let e of n.city) x[e.card].color === "orange" && e.tucked < x[e.card].capacity && n.hand.length && r.push(J("artisan", String(e.uid), {
				card: e.card,
				uid: e.uid
			}));
			let i = [
				1,
				1,
				2,
				2,
				2
			][n.path];
			n.path < [
				1,
				2,
				3,
				5
			][n.season] && n.hand.length && j(n.resources.slice(0, 4)) >= i && (n.path < 4 || n.resources[4] > 0) && r.push(J("excavate")), n.season < 3 && (B(e, n) === 0 || !r.some((e) => e.kind === "place")) && r.push(J("season")), n.season === 3 && r.push(J("end"));
			break;
		}
		case "payment":
			for (let n of Oe(e, t.rid, t.card, t.value, t.n ?? 0, t.mode === "free")) r.push(J("payment", n.value ?? "", {
				cost: n.cost,
				mode: n.mode,
				uid: n.uid,
				card: t.card
			}));
			r.push(J("cancel"));
			break;
		case "playOffer": {
			let i = [...t.mode === "plateau" ? [] : n.hand.map((e, t) => ({
				id: e,
				source: `h:${t}`
			})), ...t.mode === "hand" ? [] : e.plateau.filter((e) => e.count > 0).map((e) => ({
				id: e.card,
				source: `p:${e.card}`
			}))];
			for (let n of i) Oe(e, t.rid, n.id, n.source, t.n ?? 0, t.value === "free").length && r.push(J("play", n.source, { card: n.id }));
			t.up && n.resources[4] > 0 && r.push(J("freePlay")), r.push(J("skip"));
			break;
		}
		case "activate":
			r.push(J("activate", "", {
				card: t.card,
				uid: t.uid
			})), r.push(J("skip"));
			break;
		case "resource":
			for (let e = 0; e < (t.mode === "emerald" ? 5 : 4); e++) r.push(J("resource", String(e), { n: 1 }));
			break;
		case "payResource":
			for (let e of t.ids ?? [
				"0",
				"1",
				"2",
				"3"
			]) n.resources[Number(e)] > 0 && r.push(J("payResource", e));
			break;
		case "discard":
			n.hand.forEach((e, t) => r.push(J("discard", String(t), { card: e }))), (t.count ?? 0) >= (t.min ?? 0) && r.push(J("finish")), (t.count ?? 0) === 0 && t.min !== 0 && t.mode !== "excavate" && t.mode !== "artisan" && t.mode !== "night" && r.push(J("skip"));
			break;
		case "dice":
			e.dice.forEach((e, n) => {
				e >= 0 && !t.ids?.includes(String(n)) && r.push(J("die", String(n), { n: e }));
			}), r.push(J("skip"));
			break;
		case "mooring":
			r.push(J("draw")), e.dice.some((e) => e >= 0) && r.push(J("copyDie"));
			break;
		case "upgrade":
			for (let e of n.city) e.upgraded || r.push(J("upgrade", String(e.uid), {
				card: e.card,
				uid: e.uid
			}));
			r.push(J("skip"));
			break;
		case "realm":
			t.mode !== "top" && e.realms.forEach((e, t) => r.push(J("realm", String(t), { n: e }))), e.realmDeck.length && r.push(J("realm", "top")), r.push(J("skip"));
			break;
		case "artifact":
			e.offered.forEach((e, t) => r.push(J("artifact", String(t), { mode: e })));
			break;
		case "plateau":
			if (n.hand.length < 6) for (let t of e.plateau) t.count > 0 && r.push(J("plateau", t.card, { card: t.card }));
			r.push(J("skip"));
			break;
		case "copy":
			r.push(...Me(e, t)), r.push(J("skip"));
			break;
		case "production":
			for (let n of t.ids ?? []) {
				let t = P(e, Number(n));
				t && r.push(J("production", n, {
					card: t.card,
					uid: t.uid
				}));
			}
			r.push(J("skip"));
			break;
		case "retrieveHarp":
			for (let e of n.city) e.harp && r.push(J("retrieveHarp", String(e.uid), {
				card: e.card,
				uid: e.uid
			}));
			r.push(J("skip"));
			break;
		case "retrieveWorker":
			for (let n of e.placements) n.rid === t.rid && n.worker > 0 && r.push(J("retrieveWorker", String(n.uid), {
				owner: n.location,
				uid: n.uid
			}));
			r.push(J("skip"));
			break;
		case "discardArtifact":
			n.artifacts.forEach((e, t) => r.push(J("discardArtifact", String(t), { mode: e }))), r.push(J("skip"));
			break;
		case "copyLocation":
			for (let n of e.placements) if ((t.up || n.rid !== t.rid) && n.worker > 0 && !["upgrade", "mooring"].includes(n.location) && !r.some((e) => e.value === n.location)) {
				let i = n.location.startsWith("c:") ? P(e, Number(n.location.slice(2))) : void 0;
				if (i && (t.chain ?? []).includes(i.card)) continue;
				r.push(J("copyLocation", n.location, {
					card: i?.card,
					uid: i?.uid
				}));
			}
			r.push(J("skip"));
			break;
		case "workshop":
			r.push(J("draw")), t.up && r.push(J("emerald")), r.push(J("skip"));
			break;
		case "kotoRed":
			for (let t of n.city) x[t.card].building && x[t.card].color === "red" && !e.placements.some((e) => e.location === `c:${t.uid}` && e.rid !== n.rid) && r.push(J("kotoRed", String(t.uid), {
				card: t.card,
				uid: t.uid
			}));
			break;
		case "stealChoice":
			n.artifacts.forEach((e, n) => {
				S[e].points === t.n && r.push(J("stealArtifact", String(n), { mode: e }));
			});
			break;
		case "stealOrPay": n.resources[4] && r.push(J("payEmerald")), r.push(J("allowSteal"));
	}
	return r.map((t, n) => ({
		...t,
		id: `${e.revision}:${n}`
	}));
}
function Pe(e, t, n) {
	let r = N(e, t), i = n.kind === "helper", a = n.mode?.includes("guide") ?? !1;
	if (e.placements.push({
		uid: e.uid++,
		rid: t,
		location: n.value,
		worker: +!i,
		helpers: i ? 1 : n.n ?? 0,
		guide: a
	}), z(e, t, i ? "helper" : "place", n.value, n.n ?? 0), n.value.startsWith("c:")) {
		let r = P(e, Number(n.value.slice(2))), i = M(e).find((e) => e.city.includes(r));
		i.rid !== t && (i.points += r.upgraded ? 2 : 1), I(e, U(t, r));
	} else I(e, F("location", t, {
		value: n.value,
		n: a ? 2 : 1
	}));
	!i && (n.n ?? 0) > 0 && e.queue.push(...ge(r, "steamboat").map((e) => U(t, e)));
}
function Fe(e, t, n) {
	let r = N(e, t.rid), i = t.card, a = x[i], o = t.value, s = r.city.filter((e) => x[e.card].color === "blue").map((e) => ({ ...e }));
	n.cost.forEach((e, t) => r.resources[t] -= e);
	let c = o.startsWith("h:") ? Number(o.slice(2)) : -1;
	if (n.mode === "discard") {
		let t = Number(n.value);
		e.discard.push(r.hand.splice(t, 1)[0]), t < c && c--;
	}
	c >= 0 ? r.hand.splice(c, 1) : xe(e, i), n.mode === "harp" && (r.harps--, P(e, n.uid).harp = !0);
	let l = {
		uid: e.uid++,
		card: i,
		upgraded: n.mode === "harp",
		harp: !1,
		tucked: 0
	};
	r.city.push(l);
	let u = [];
	(a.color === "green" || a.color === "tan") && u.push(U(t.rid, l, t.chain ?? []));
	for (let e of s) (e.card === "canopyHighway" || e.card === (a.building ? "thatcher" : "playwright")) && u.push(U(t.rid, e));
	I(e, ...u), z(e, t.rid, "play", i, l.uid);
}
function Ie(e, t, n) {
	let r = P(e, n);
	if (!r || r.upgraded || (r.upgraded = !0, z(e, t, "upgrade", r.card, n), t === "$koto")) return;
	let i = x[r.card].color;
	if ((i === "green" || i === "tan") && I(e, U(t, r)), i === "red") {
		let t = M(e).find((e) => e.city.some((e) => e.uid === n)).rid;
		I(e, ...e.placements.filter((e) => e.location === `c:${n}` && e.rid !== "$koto").sort((e, n) => Number(n.rid === t) - Number(e.rid === t)).map((e) => U(e.rid, r, [], e.rid === t ? void 0 : t)));
	}
}
function Le(e, t, n = !1) {
	let r = N(e, t);
	if (r.path >= 5 || !n && r.path >= [
		1,
		2,
		3,
		5
	][r.season]) return !1;
	if (r.path++, r.path < 5) {
		let t = e.pathPiles[r.path - 1];
		t.length && (r.points += t.shift());
	} else r.lostCity = e.lostCityAvailable.shift() ?? 0;
	return z(e, t, "path", "", r.path), t === "$koto" && I(e, q(t), ...e.config.tricks && e.config.soloDifficulty === "hard" ? [F("trick", t, { n: r.season })] : []), !0;
}
function Re(e, t) {
	let n = N(e, t);
	e.placements = e.placements.filter((e) => e.rid !== t), n.season++, z(e, t, "season", "", n.season), n.season > e.rolled && (e.rolled = n.season, e.dice = Array.from({ length: 4 }, () => L(e, 6))), t === "$koto" ? (n.workers = [
		4,
		5,
		6,
		9
	][n.season], e.koto.expedition = R(e, [
		0,
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8
	]), e.koto.excavation = R(e, [
		0,
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8
	]), e.koto.prepare = !1, e.config.tricks && I(e, F("trick", t, { n: n.season - 1 }))) : (n.season === 1 && n.helpers++, n.season === 2 && (n.workers++, H(e, t, 4), e.discard.push(...e.plateau.flatMap((e) => Array(e.count).fill(e.card))), e.plateau = [], be(e)), n.season === 3 && (n.workers += 2, n.helpers++), (n.season === 1 || n.season === 3) && I(e, F("production", t, { ids: n.city.filter((e) => x[e.card].color === "green").map((e) => String(e.uid)) })), e.koto && B(e, e.koto.player) === 0 && e.koto.player.season < 3 && (e.koto.prepare = !0));
}
function ze(e, t) {
	let n = t.rid, r = N(e, n), i = t.card, a = !!t.up, o = a ? 2 : 1, s = [...t.chain ?? [], i], c = (e, t = 1) => Ee(n, e, t, s);
	switch (i) {
		case "treeNursery":
			H(e, n, 1, o);
			break;
		case "cargoMill":
			H(e, n, 0, o);
			break;
		case "fruitMarket":
			H(e, n, 3, o);
			break;
		case "marbleQuarry":
			H(e, n, 2, o);
			break;
		case "mineShaft":
			H(e, n, 4, o);
			break;
		case "skyScout":
			V(e, n, o);
			break;
		case "noveltyShop":
			V(e, n, o), r.points++;
			break;
		case "tradeDock":
			I(e, Te(n, o));
			break;
		case "ropeMiner":
			I(e, Ce(n, 1, 1, "ability", a ? [W(n), F("gain", n, { value: "4" })] : [W(n, 1, { mode: "emerald" })]));
			break;
		case "piper":
			I(e, G(n, 1, [W(n, o), F("points", n, { n: o })], ["0", "1"]));
			break;
		case "juggler":
			I(e, G(n, 1, [W(n, o)]));
			break;
		case "harpist":
			I(e, a ? G(n, 1, [F("harp", n)]) : K(n, 1, [F("harp", n)]));
			break;
		case "digger":
			I(e, ...a ? [q(n)] : [Ce(n, 1, 1, "ability", [q(n)])]);
			break;
		case "chipchop":
			I(e, c(a ? "green-own" : "green"));
			break;
		case "baseCamp":
			I(e, F("discardArtifact", n, { n: a ? 2 : 1 }));
			break;
		case "apothecary":
			I(e, G(n, 1, [W(n, o), F("points", n, { n: 2 })], ["2", "3"]));
			break;
		case "tunnelNetwork":
			I(e, a ? K(n, 1, [F("playOffer", n, {
				value: "free",
				chain: s
			})]) : F("playOffer", n, {
				n: 3,
				chain: s
			}));
			break;
		case "troubadour":
			I(e, a ? F("copyLocation", n, {
				up: !0,
				chain: s
			}) : K(n, 1, [F("copyLocation", n, { chain: s })]));
			break;
		case "ropeBridge":
			I(e, K(n, a ? 1 : 2, [F("realm", n)]));
			break;
		case "postalPigeon":
			a ? I(e, Ce(n, 0, r.hand.length, "pigeon", [], { chain: s })) : V(e, n, 4);
			break;
		case "minersCamp":
			H(e, n, 4, a ? 3 : 2);
			break;
		case "lostRuin":
			I(e, q(n, a ? 4 : 2));
			break;
		case "interpreter":
			I(e, c("other-green", o));
			break;
		case "floatingMarket":
		case "treetopBazaar":
			I(e, Te(n, a ? 3 : 2));
			break;
		case "dancer":
			a ? I(e, F("retrieveHarp", n)) : Se(e, n);
			break;
		case "crafter":
			I(e, K(n, 1, [we(n, o)]));
			break;
		case "archaeologist":
		case "gallery":
			I(e, q(n, a ? 3 : 1));
			break;
		case "vineSurfer":
			I(e, c(a ? "tan-own" : "tan"));
			break;
		case "drummer":
			I(e, c(a ? "green-own" : "green", 2));
			break;
		case "travelCenter": {
			let t = V(e, n, a ? 3 : 2);
			for (let r of t) x[r].building ? e.queue.unshift(W(n)) : H(e, n, 4);
			break;
		}
		case "tomb":
			a && H(e, n, 4), Se(e, n);
			break;
		case "postOffice":
		case "inn":
			I(e, F("playOffer", n, {
				n: 3,
				mode: i === "inn" ? "plateau" : "hand",
				up: a,
				chain: s
			}));
			break;
		case "caveHermit":
			a && H(e, n, 4), I(e, we(n));
			break;
		case "adventurer":
			I(e, K(n, 2, [F("realm", n, { mode: a ? "" : "top" })]));
			break;
		case "tradeGate":
			I(e, G(n, 1, [W(n, 2), F("points", n, { n: a ? 2 : 0 })]));
			break;
		case "studio":
			I(e, a ? we(n) : K(n, 1, [we(n)]));
			break;
		case "mapShop":
			I(e, a ? F("realm", n) : K(n, 2, [F("realm", n)]));
			break;
		case "luthier":
			H(e, n, 0, a ? 3 : 2), r.points++;
			break;
		case "gardener":
			H(e, n, 1, o), r.points++;
			break;
		case "chiseler":
			H(e, n, 2, o), r.points++;
			break;
		case "chef":
			H(e, n, 3, o), r.points++;
			break;
		case "bridgeBuilder":
			I(e, W(n, o));
			break;
		case "academy":
			I(e, F("retrieveWorker", n, { up: a }));
			break;
		case "canopyHighway":
			a && r.points++, I(e, F("plateau", n, { n: 1 }));
			break;
		case "thatcher":
		case "playwright":
			V(e, n, 1), a && r.points++;
			break;
		case "trumpeter":
			r.points += 2, a && H(e, n, 4);
			break;
		case "steamboat": I(e, a ? W(n) : Ce(n, 1, 1, "ability", [W(n)]));
	}
}
function Be(e, t) {
	let n = t.rid, r = t.n ?? 1;
	if (t.value?.startsWith("c:")) {
		let r = P(e, Number(t.value.slice(2)));
		r && I(e, U(n, r, t.chain));
		return;
	}
	switch (t.value) {
		case "emerald":
			H(e, n, 4, 2 * r);
			break;
		case "marble":
			H(e, n, 2, r), V(e, n, r);
			break;
		case "bamboo":
			H(e, n, 0, 3 * r);
			break;
		case "leaf":
			H(e, n, 1, 2 * r);
			break;
		case "fig":
			H(e, n, 3, 2 * r);
			break;
		case "market":
			I(e, Te(n, 2, r));
			break;
		case "realm":
			I(e, K(n, 2, [F("realm", n)]));
			break;
		case "song":
			I(e, K(n, 1, [F("harp", n), F("draw", n, { n: 6 })]));
			break;
		case "exchange":
			H(e, n, 4), I(e, F("plateau", n, { n: 2 }), Te(n, 1));
			break;
		case "treasure":
			H(e, n, 4), I(e, q(n));
			break;
		case "grandMarket":
			I(e, K(n, 1, [Te(n, e.dice.filter((e) => e >= 0).length)]));
			break;
		case "upgrade":
			I(e, K(n, 1, [we(n)]));
			break;
		case "mooring": I(e, F("mooring", n));
	}
}
function Ve(e, t, n) {
	if (t !== "$koto" || [
		"ring",
		"chest",
		"cloth"
	].includes(n)) switch (n) {
		case "scale":
			I(e, G(t, 1, [W(t, 2)]));
			break;
		case "pot":
			I(e, W(t));
			break;
		case "dice":
			I(e, Te(t, 1));
			break;
		case "harp":
			Se(e, t);
			break;
		case "ring":
			H(e, t, 4);
			break;
		case "parchment":
			I(e, F("plateau", t, { n: 1 }));
			break;
		case "cloth":
			I(e, we(t));
			break;
		case "sundial":
			I(e, Ee(t, "green-own", 1, []));
			break;
		case "cape":
			V(e, t, 1);
			break;
		case "chest": I(e, q(t));
	}
}
function He(e, t, n) {
	let r = N(e, t.rid), i = t.rid;
	if (n.kind !== "skip") switch (t.kind) {
		case "turn":
			if ((n.kind === "place" || n.kind === "helper") && (n.mode?.startsWith("night") ? I(e, Ce(i, 1, 1, "night", [F("placeCommitted", i, { value: JSON.stringify(n) })])) : Pe(e, i, n)), n.kind === "play" && I(e, F("payment", i, {
				card: n.card,
				value: n.value
			})), n.kind === "artisan" && I(e, Ce(i, 1, 1, "artisan", [U(i, P(e, n.uid))], { uid: n.uid })), n.kind === "excavate") {
				let t = [
					1,
					1,
					2,
					2,
					2
				][r.path];
				I(e, G(i, t, [F("excavatePay", i)]));
			}
			n.kind === "season" && Re(e, i), n.kind === "end" && (r.ended = !0, z(e, i, "end"));
			break;
		case "payment":
			n.kind === "cancel" ? t.mode ? I(e, ...t.after ?? []) : I(e, F("turn", i)) : Fe(e, t, n);
			break;
		case "playOffer":
			n.kind === "freePlay" ? I(e, K(i, 1, [{
				...t,
				value: "free",
				up: !1
			}])) : I(e, F("payment", i, {
				card: n.card,
				value: n.value,
				n: t.n,
				mode: t.value === "free" ? "free" : "discount",
				chain: t.chain,
				after: [t]
			}));
			break;
		case "activate":
			t.owner && (N(e, t.owner).points += 2), ze(e, t);
			break;
		case "resource":
			H(e, i, Number(n.value)), (t.n ?? 1) > 1 && I(e, {
				...t,
				n: t.n - 1
			});
			break;
		case "payResource":
			r.resources[Number(n.value)]--, (t.n ?? 1) > 1 ? I(e, {
				...t,
				n: t.n - 1
			}) : I(e, ...t.after ?? []);
			break;
		case "discard": {
			if (n.kind === "finish") {
				Ue(e, t);
				break;
			}
			let i = r.hand.splice(Number(n.value), 1)[0];
			t.mode === "artisan" ? P(e, t.uid).tucked++ : e.discard.push(i);
			let a = {
				...t,
				count: (t.count ?? 0) + 1
			};
			a.count >= (t.max ?? 1) || !r.hand.length ? Ue(e, a) : I(e, a);
			break;
		}
		case "dice": {
			let a = Number(n.value), o = e.dice[a], s = t.max ?? 1;
			(t.n ?? 1) > 1 && I(e, {
				...t,
				n: t.n - 1,
				ids: [...t.ids ?? [], String(a)]
			}), o < 4 ? H(e, i, o, s) : o === 4 ? I(e, W(i, s)) : (V(e, i, s), r.points += s);
			break;
		}
		case "mooring":
			n.kind === "draw" ? V(e, i, 2) : I(e, Te(i, 1));
			break;
		case "upgrade":
			(t.n ?? 1) > 1 && I(e, {
				...t,
				n: t.n - 1
			}), Ie(e, i, n.uid);
			break;
		case "realm": {
			let t;
			if (n.value === "top") t = e.realmDeck.pop();
			else {
				let r = Number(n.value);
				t = e.realms[r];
				let i = e.realmDeck.pop();
				i === void 0 ? e.realms.splice(r, 1) : e.realms[r] = i;
			}
			t !== void 0 && (r.realms.push(t), z(e, i, "realm", "", t));
			break;
		}
		case "artifact": {
			let t = e.offered.splice(Number(n.value), 1)[0];
			e.bag.push(...e.offered), e.offered = [], r.artifacts.push(t), z(e, i, "artifact", t), Ve(e, i, t);
			break;
		}
		case "plateau":
			xe(e, n.value) && r.hand.push(n.value), (t.n ?? 1) > 1 && I(e, {
				...t,
				n: t.n - 1
			});
			break;
		case "copy":
			(t.n ?? 1) > 1 && I(e, {
				...t,
				n: t.n - 1,
				ids: [...t.ids ?? [], n.value]
			}), I(e, U(i, n.uid ? P(e, n.uid) : {
				uid: 0,
				card: n.card,
				upgraded: !1,
				harp: !1,
				tucked: 0
			}, t.chain));
			break;
		case "production": {
			let r = P(e, n.uid), a = (t.ids ?? []).filter((e) => e !== String(r.uid));
			a.length && I(e, {
				...t,
				ids: a
			}), I(e, U(i, r));
			break;
		}
		case "retrieveHarp":
			P(e, n.uid).harp = !1, Se(e, i);
			break;
		case "retrieveWorker": {
			let r = e.placements.find((e) => e.uid === n.uid);
			if (r.worker = 0, t.up) {
				let t = e.placements.find((e) => e.rid === i && e.location === r.location && e.helpers > 0);
				t && t.helpers--;
			}
			e.placements = e.placements.filter((e) => e.worker + e.helpers > 0);
			break;
		}
		case "discardArtifact":
			e.bag.push(r.artifacts.splice(Number(n.value), 1)[0]), I(e, q(i, t.n));
			break;
		case "copyLocation":
			I(e, F("location", i, {
				value: n.value,
				chain: t.chain
			}));
			break;
		case "workshop":
			n.kind === "draw" ? V(e, i, 2) : H(e, i, 4, 1, !1);
			break;
		case "kotoRed": {
			let i = P(e, n.uid);
			r.points += i.upgraded ? 2 : 1, Ge(e, `c:${n.uid}`, t.n ?? 1), Le(e, "$koto");
			break;
		}
		case "stealChoice":
			e.koto.player.artifacts.push(r.artifacts.splice(Number(n.value), 1)[0]);
			break;
		case "stealOrPay": n.kind === "payEmerald" ? r.resources[4]-- : Ze(e);
	}
}
function Ue(e, t) {
	t.mode === "excavate" ? (Le(e, t.rid), I(e, q(t.rid, t.count ?? 1))) : t.mode === "pigeon" ? I(e, F("playOffer", t.rid, {
		n: t.count,
		chain: t.chain
	})) : I(e, ...t.after ?? []);
}
function We(e, t) {
	let n = e.koto;
	n[t].length || (n[t] = R(e, [
		0,
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8
	]));
	let r = n[t].pop();
	return n.deck = t, n.card = r, z(e, "$koto", t, "", r), r;
}
function Ge(e, t, n) {
	let r = e.koto.player;
	n = Math.min(n, B(e, r)), !(n <= 0) && (e.placements.push({
		uid: e.uid++,
		rid: "$koto",
		location: t,
		worker: n,
		helpers: 0,
		guide: !1
	}), z(e, "$koto", "place", t, n), t === "emerald" && H(e, "$koto", 4, 2 * n));
}
function Ke(e, t) {
	let n = e.koto.player;
	if (t === "point") n.points++;
	else if (t === "emerald") H(e, n.rid, 4);
	else if (t === "excavate") Le(e, n.rid);
	else if (t.startsWith("realm")) {
		let r = Number(t.slice(5)), i;
		if (t === "realmTop") i = e.realmDeck.pop();
		else if (e.realms[r] !== void 0) {
			i = e.realms[r];
			let t = e.realmDeck.pop();
			t === void 0 ? e.realms.splice(r, 1) : e.realms[r] = t;
		}
		i !== void 0 && n.realms.push(i);
	}
}
function qe(e, t, n) {
	if (t === "red") {
		let t = e.koto.player, r = t.city.find((n) => x[n.card].color === "red" && !e.placements.some((e) => e.location === `c:${n.uid}` && e.rid === t.rid));
		if (r) return Ge(e, `c:${r.uid}`, n), Le(e, t.rid), !0;
		let i = F("kotoRed", e.players[0].rid, { n });
		return Ne(e, i).length ? (I(e, i), !0) : !1;
	}
	return !e.placements.some((e) => e.location === t) && (Ge(e, t, n), !0);
}
function Je(e) {
	let t = e.koto, n = t.player;
	if (!n.ended) {
		if ((t.prepare || e.players[0].season > n.season && B(e, n) === 0) && n.season < 3) {
			Re(e, n.rid);
			return;
		}
		if (B(e, n) > 0) {
			I(e, F("kotoExpedition", n.rid, {
				n: We(e, "expedition"),
				count: 0
			}));
			return;
		}
		if (n.city.length >= 15) {
			n.season === 3 ? I(e, F("kotoFinishPath", n.rid)) : H(e, n.rid, 4);
			return;
		}
		I(e, F("kotoExcavation", n.rid, {
			n: We(e, "excavation"),
			count: 0
		}));
	}
}
function Ye(e, t) {
	let n = e.koto.player, r = ce[t.n], i = t.count ?? 0, a = r.stops[n.season][1];
	if (i < 4) {
		let [o] = r.stops[(n.season + i) % 4];
		if (qe(e, o, a)) return;
		I(e, {
			...t,
			count: i + 1
		}), i === 0 && Ke(e, r.plan);
		return;
	}
	Ge(e, r.fallback, a), Ke(e, r.reward);
}
function Xe(e, t) {
	let n = e.koto.player, r = w[t.n], i = t.count ?? 0;
	if (i < 4) {
		let a = r.targets[(n.season + i) % 4], o = a.startsWith("u"), s = o ? a.slice(1) : a, c = s[0], l = s.slice(1), u = [
			0,
			3,
			1,
			4,
			2,
			5
		].map((t) => e.plateau[t]).find((e) => {
			if (!e) return !1;
			let t = x[e.card];
			return e.count > 0 && (c === "a" || t.building === (c === "b")) && (String(t.points) === l || t.color === l);
		});
		if (!u) {
			I(e, {
				...t,
				count: i + 1
			}), i === 0 && Ke(e, r.plan);
			return;
		}
		xe(e, u.card), n.city.push({
			uid: e.uid++,
			card: u.card,
			upgraded: o,
			harp: !1,
			tucked: 0
		});
	} else {
		let t = ye(e);
		t && n.city.push({
			uid: e.uid++,
			card: t,
			upgraded: !0,
			harp: !1,
			tucked: 0
		}), Ke(e, r.reward);
	}
	n.city.length === 15 && e.config.tricks && I(e, F("trick", n.rid, { n: n.season }));
}
function Ze(e) {
	let t = e.players[0];
	t.artifacts.length && e.koto.player.artifacts.push(t.artifacts.splice(L(e, t.artifacts.length), 1)[0]);
}
function Qe(e, t) {
	let n = e.koto, r = e.players[0], i = le[We(e, "trick")][t], a = (t) => {
		for (let n = 0; n < t && r.hand.length; n++) e.discard.push(r.hand.splice(L(e, r.hand.length), 1)[0]);
	};
	if (i === "artifact") {
		I(e, q("$koto"));
		return;
	}
	if (i.startsWith("clear:")) {
		let t = i.slice(6).split(",");
		for (let r of e.plateau) (t.includes(x[r.card].color) || t.includes("critter") && !x[r.card].building) && (n.player.points += r.count, e.discard.push(...Array(r.count).fill(r.card)), r.count = 0);
		be(e);
		return;
	}
	switch (i) {
		case "discard1":
			a(1);
			break;
		case "discard2":
			a(2);
			break;
		case "discard1emerald":
			a(1), H(e, "$koto", 4);
			break;
		case "loseHarp":
			r.harps = Math.max(0, r.harps - 1);
			break;
		case "stealEmerald":
			r.resources[4] && (r.resources[4]--, H(e, "$koto", 4));
			break;
		case "loseEmeraldPoint":
			r.resources[4] = Math.max(0, r.resources[4] - 1), n.player.points++;
			break;
		case "lose1discard":
			a(1), j(r.resources.slice(0, 4)) && I(e, G(r.rid, 1, []));
			break;
		case "lose2": {
			let t = Math.min(2, j(r.resources.slice(0, 4)));
			t && I(e, G(r.rid, t, []));
			break;
		}
		case "back":
			r.path > 0 && (r.path--, r.lostCity && (e.lostCityAvailable.push(r.lostCity), e.lostCityAvailable.sort((e, t) => t - e)), r.lostCity = 0);
			break;
		case "realmTop":
			Ke(e, "realmTop");
			break;
		case "dice": {
			let t = e.dice.map((e, t) => e >= 0 ? t : -1).filter((e) => e >= 0);
			for (let n of R(e, t).slice(0, 2)) e.dice[n] = -1;
			e.dice = e.dice.map((t) => t >= 0 ? L(e, 6) : -1);
			break;
		}
		case "steal":
			Ze(e);
			break;
		case "stealOrPay":
			r.artifacts.length && I(e, F("stealOrPay", r.rid));
			break;
		case "stealLowest": r.artifacts.length && I(e, F("stealChoice", r.rid, { n: Math.min(...r.artifacts.map((e) => S[e].points)) }));
	}
}
var $e = /* @__PURE__ */ new Set([
	"turn",
	"payment",
	"playOffer",
	"activate",
	"resource",
	"payResource",
	"discard",
	"dice",
	"mooring",
	"upgrade",
	"realm",
	"artifact",
	"plateau",
	"copy",
	"production",
	"retrieveHarp",
	"retrieveWorker",
	"discardArtifact",
	"copyLocation",
	"workshop",
	"kotoRed",
	"stealChoice",
	"stealOrPay"
]);
function et(e, t) {
	let n = N(e, t.rid);
	switch (t.kind) {
		case "location":
			Be(e, t);
			break;
		case "placeCommitted":
			Pe(e, t.rid, JSON.parse(t.value));
			break;
		case "gain":
			H(e, t.rid, Number(t.value), t.n ?? 1);
			break;
		case "draw":
			V(e, t.rid, t.n ?? 1);
			break;
		case "harp":
			Se(e, t.rid);
			break;
		case "points":
			n.points += t.n ?? 0;
			break;
		case "emeraldCost":
			n.resources[4] >= (t.n ?? 1) && (n.resources[4] -= t.n ?? 1, I(e, ...t.after ?? []));
			break;
		case "excavatePay":
			n.path === 4 && n.resources[4]--, I(e, Ce(t.rid, 1, n.hand.length, "excavate"));
			break;
		case "artifactDraw": {
			let r = t.rid === "$koto" ? 0 : ge(n, "auctionHouse").reduce((e, t) => e + (t.upgraded ? 2 : 1), 0), i = Math.min(e.bag.length, (t.n ?? 1) + r);
			if (!i) break;
			e.offered = [];
			for (let t = 0; t < i; t++) e.offered.push(e.bag.splice(L(e, e.bag.length), 1)[0]);
			if (t.rid === "$koto") {
				let r = e.offered[0];
				n.artifacts.push(r), e.bag.push(...e.offered.slice(1)), e.offered = [], Ve(e, t.rid, r);
			} else I(e, F("artifact", t.rid));
			break;
		}
		case "koto":
			Je(e);
			break;
		case "kotoExpedition":
			Ye(e, t);
			break;
		case "kotoExcavation":
			Xe(e, t);
			break;
		case "kotoFinishPath":
			n.path < 5 ? (I(e, F("kotoFinishPath", n.rid)), Le(e, n.rid, !0)) : I(e, F("endKoto", n.rid));
			break;
		case "endKoto":
			n.ended = !0;
			break;
		case "trick": Qe(e, t.n ?? n.season);
	}
}
function tt(e) {
	if (be(e), M(e).every((e) => e.ended)) {
		e.phase = "done";
		return;
	}
	let t = M(e);
	do
		e.turn = (e.turn + 1) % t.length;
	while (t[e.turn].ended);
	let n = t[e.turn];
	I(e, F(n.rid === "$koto" ? "koto" : "turn", n.rid));
}
function nt(e) {
	for (let t = 0; t < 100; t++) {
		if (!e.queue.length && (tt(e), e.phase === "done")) return;
		let t = e.queue[0];
		if ($e.has(t.kind)) {
			if (t.rid === "$koto" && t.kind === "upgrade") {
				if (!N(e, "$koto").city.some((e) => !e.upgraded)) {
					e.queue.shift();
					continue;
				}
				let n = {
					...t,
					rid: e.players[0].rid,
					owner: "$koto"
				};
				e.queue[0] = n;
			}
			let n = e.queue[0];
			if (n.kind === "upgrade" && n.owner === "$koto") {
				e.phase = "play";
				return;
			}
			let r = Ne(e, n);
			if (!r.length || r.every((e) => e.kind === "skip")) {
				e.queue.shift();
				continue;
			}
			e.phase = "play";
			return;
		}
		e.queue.shift(), et(e, t), e.phase = "settle";
		return;
	}
	throw Error("Emerland task queue did not advance");
}
function rt(e, t) {
	if (t.rid === "$koto") {
		let n = e.config.soloDifficulty === "hard", r = n ? 15 : 10, i = t.city.filter((e) => x[e.card].color === "purple").length * (n ? 4 : 3) + t.city.filter((e) => e.upgraded).length * (n ? 3 : 2), a = t.points, o = t.artifacts.reduce((e, t) => e + S[t].points, 0), s = t.lostCity, c = t.realms.length * (n ? 5 : 4), l = t.resources[4] * (n ? 2 : 1);
		return {
			cards: r,
			prosperity: i,
			points: a,
			artifacts: o,
			path: s,
			realms: c,
			resources: l,
			total: r + i + a + o + s + c + l
		};
	}
	let n = Object.fromEntries(re.map((e) => [e, t.city.filter((t) => x[t.card].color === e).length])), r = t.city.filter((e) => e.upgraded && x[e.card].building).length, i = t.city.filter((e) => e.upgraded && !x[e.card].building).length, a = t.harps + t.city.filter((e) => e.harp).length, o = 0;
	for (let e of t.city) {
		let s = e.upgraded ? 2 : 3, c = !1;
		switch (e.card) {
			case "statue":
				c = n.orange >= s;
				break;
			case "sanctuary":
				c = re.every((e) => n[e] > 0);
				break;
			case "sacredSite":
				c = n.tan >= s;
				break;
			case "riverWharf":
				c = n.green >= s + 1;
				break;
			case "performer":
				c = i >= s + 1;
				break;
			case "pathWeaver":
				c = t.realms.length >= s;
				break;
			case "maestro":
				c = a >= s;
				break;
			case "gemCutter":
				c = n.purple >= s;
				break;
			case "fountain":
				c = n.blue >= s;
				break;
			case "elder":
				c = r >= s + 1;
				break;
			case "curator":
				c = t.artifacts.length >= s + 2;
				break;
			case "canopyStadium": c = n.red >= s;
		}
		c && (o += e.card === "sanctuary" ? e.upgraded ? 7 : 4 : e.upgraded ? 5 : 3);
	}
	let s = t.city.filter((e) => x[e.card].building).length, c = [
		r + i,
		2 * n.tan,
		2 * n.blue,
		2 * n.red,
		2 * n.orange,
		2 * re.filter((e) => n[e] > 0).length,
		t.city.length - s,
		s,
		Math.floor(t.points / 2),
		2 * r,
		3 * t.realms.length,
		new Set(t.artifacts).size,
		2 * a,
		2 * i,
		2 * t.city.filter((e) => e.harp).length,
		2 * t.city.reduce((e, t) => e + t.tucked, 0),
		3 * n.purple,
		2 * n.green
	], l = t.city.reduce((e, t) => e + x[t.card].points + Number(t.upgraded), 0), u = t.points, d = t.artifacts.reduce((e, t) => e + S[t].points, 0), f = t.lostCity, p = t.realms.reduce((e, t) => e + c[t], 0), m = Math.floor(j(t.resources) / 2);
	return {
		cards: l,
		prosperity: o,
		points: u,
		artifacts: d,
		path: f,
		realms: p,
		resources: m,
		total: l + o + u + d + f + p + m
	};
}
function it(e, t = !1) {
	return {
		rid: e,
		season: 0,
		ended: !1,
		resources: t ? he() : [
			0,
			0,
			0,
			0,
			1
		],
		points: 0,
		workers: t ? 4 : 2,
		helpers: t ? 0 : 2,
		harps: 0,
		hand: [],
		city: [],
		artifacts: [],
		realms: [],
		path: 0,
		lostCity: 0
	};
}
function at(e, t, n) {
	let r = {
		seed: n,
		cursor: 0,
		uid: 1,
		revision: 1,
		players: t.map((e) => it(e)),
		turn: +(t.length === 1),
		phase: "play",
		queue: [],
		deck: [],
		discard: [],
		plateau: [],
		realmDeck: [],
		realms: [],
		bag: [],
		offered: [],
		placements: [],
		dice: [],
		rolled: 0,
		pathPiles: [],
		lostCityAvailable: [
			7,
			5,
			3,
			2
		],
		config: E.parse(e),
		koto: null,
		log: []
	};
	return r.deck = R(r, b.flatMap((e) => Array(e.copies).fill(e.id))), r.realmDeck = R(r, Array.from({ length: 18 }, (e, t) => t)), r.realms = r.realmDeck.splice(-3), r.bag = Object.entries(S).flatMap(([e, t]) => Array(t.copies).fill(e)), r.dice = Array.from({ length: 4 }, () => L(r, 6)), r.pathPiles = [
		[1, 1],
		[2, 1],
		[2, 2],
		[3, 2]
	].map((e) => t.length <= 2 ? e.slice(0, 1) : e), t.forEach((e, n) => V(r, e, t.length === 1 ? 4 : 3 + n)), be(r), t.length === 1 ? (r.koto = {
		player: it("$koto", !0),
		expedition: R(r, [
			0,
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8
		]),
		excavation: R(r, [
			0,
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8
		]),
		trick: R(r, [
			0,
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8
		]),
		deck: null,
		card: null,
		prepare: !1
	}, r.queue = [F("koto", "$koto")], r.phase = "settle") : r.queue = [F("turn", t[0])], { state: r };
}
function ot(e, t) {
	return t.kind === "upgrade" && t.owner === "$koto" ? [...e.koto.player.city.filter((e) => !e.upgraded).map((e) => J("upgrade", String(e.uid), {
		card: e.card,
		uid: e.uid
	})), J("skip")].map((t, n) => ({
		...t,
		id: `${e.revision}:${n}`
	})) : Ne(e, t);
}
function st(e, t) {
	let n = [], r = e.queue[0], i = r?.uid ? `card:${r.uid}` : r?.kind === "location" ? `location:${r.value}` : "supply";
	for (let a of M(t)) {
		let t = N(e, a.rid);
		a.resources.forEach((e, r) => {
			let o = e - t.resources[r];
			o && n.push({
				kind: "resource",
				rid: a.rid,
				with: !0,
				data: {
					from: o > 0 ? i : `seat:${a.rid}`,
					to: o > 0 ? `seat:${a.rid}` : i,
					n: Math.abs(o),
					resource: r
				}
			});
		}), a.hand.length > t.hand.length && n.push({
			kind: "cards",
			rid: a.rid,
			with: !0,
			data: {
				from: r?.kind === "plateau" ? `plateau:${r.value ?? ""}` : "deck",
				to: `hand:${a.rid}`,
				n: a.hand.length - t.hand.length
			}
		}), r?.kind === "discard" && r.rid === a.rid && a.hand.length < t.hand.length && n.push({
			kind: "cards",
			rid: a.rid,
			with: !0,
			data: {
				from: `hand:${a.rid}`,
				to: r.mode === "artisan" ? `card:${r.uid}` : "deck",
				n: t.hand.length - a.hand.length
			}
		});
		for (let e of a.city) t.city.some((t) => t.uid === e.uid) || n.push({
			kind: "card",
			rid: a.rid,
			with: !0,
			data: {
				from: r?.value?.startsWith("h:") ? `hand:${a.rid}` : r?.value?.startsWith("p:") ? `plateau:${e.card}` : "deck",
				to: `card:${e.uid}`,
				card: e.card
			}
		});
		for (let e of a.city) e.upgraded && !t.city.find((t) => t.uid === e.uid)?.upgraded && n.push({
			kind: "upgrade",
			rid: a.rid,
			with: !0,
			data: { uid: e.uid }
		});
		a.path !== t.path && n.push({
			kind: "path",
			rid: a.rid,
			with: !0,
			data: {
				from: t.path,
				n: a.path
			}
		}), a.artifacts.length > t.artifacts.length && n.push({
			kind: "artifact",
			rid: a.rid,
			with: !0,
			data: { id: a.artifacts.at(-1) ?? "" }
		});
	}
	for (let r of t.placements) e.placements.some((e) => r.uid === e.uid) || n.push({
		kind: "worker",
		rid: r.rid,
		with: !0,
		data: {
			location: r.location,
			helper: r.worker === 0,
			n: r.worker + r.helpers
		}
	});
	for (let r of e.placements) {
		let e = t.placements.find((e) => r.uid === e.uid), i = r.worker + r.helpers - (e?.worker ?? 0) - (e?.helpers ?? 0);
		i > 0 && n.push({
			kind: "retrieve",
			rid: r.rid,
			with: !0,
			data: {
				location: r.location,
				helper: r.worker === 0,
				n: i
			}
		});
	}
	for (let r of t.plateau) r.count > (e.plateau.find((e) => e.card === r.card)?.count ?? 0) && n.push({
		kind: "refill",
		with: !0,
		data: { card: r.card }
	});
	return n.length && delete n[0].with, n;
}
function ct(e, t, n) {
	if (e.phase === "done") return { code: "games.everdell-emerland.error.finished" };
	if (t.type === "tick") {
		if (n.by !== "$engine" || e.phase !== "settle") return { code: "games.everdell-emerland.error.turn" };
		let t = structuredClone(e);
		return t.revision++, nt(t), {
			state: t,
			fx: st(e, t)
		};
	}
	let r = e.queue[0];
	if (e.phase !== "play" || !r || r.rid !== n.by) return { code: "games.everdell-emerland.error.turn" };
	let i = ot(e, r).find((e) => e.id === t.id);
	if (!i) return { code: "games.everdell-emerland.error.choice" };
	let a = structuredClone(e);
	return a.queue.shift(), a.revision++, r.kind === "upgrade" && r.owner === "$koto" ? i.kind !== "skip" && Ie(a, "$koto", i.uid) : He(a, r, i), a.phase = "settle", {
		state: a,
		fx: st(e, a)
	};
}
function lt(e, t) {
	let n = e.queue[0], r = e.players.find((e) => e.rid === t), i = (t) => ({
		rid: t.rid,
		season: t.season,
		ended: t.ended,
		resources: t.resources,
		points: t.points,
		workers: t.workers,
		helpers: t.helpers,
		harps: t.harps,
		handCount: t.hand.length,
		city: t.city,
		artifacts: t.artifacts,
		realms: t.realms,
		path: t.path,
		lostCity: t.lostCity,
		score: rt(e, t)
	});
	return {
		public: {
			phase: e.phase,
			turn: M(e)[e.turn].rid,
			actor: n?.rid ?? M(e)[e.turn].rid,
			prompt: n?.kind ?? "turn",
			source: n?.kind === "payment" || n?.kind === "discard" ? null : n?.card ?? null,
			sourceUid: n?.uid ?? null,
			promptN: n?.kind === "discard" ? n.count ?? 0 : n?.n ?? 0,
			revision: e.revision,
			plateau: e.plateau.filter((e) => e.count > 0),
			realms: e.realms,
			dice: e.dice,
			pathPiles: e.pathPiles,
			lostCityAvailable: e.lostCityAvailable,
			deckCount: e.deck.length,
			discardCount: e.discard.length,
			artifactCount: e.bag.length,
			placements: e.placements,
			players: e.players.map(i),
			artifactsOffered: e.offered,
			config: e.config,
			koto: e.koto ? {
				player: i(e.koto.player),
				deck: e.koto.deck,
				card: e.koto.card
			} : null,
			log: e.log
		},
		private: {
			hand: r?.hand ?? [],
			choices: n?.rid === t && e.phase === "play" ? ot(e, n) : []
		}
	};
}
function ut(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = Object.fromEntries(e.players.map((t) => [t.rid, rt(e, t).total])), n = (n, r) => {
		let i = N(e, n), a = N(e, r);
		return t[r] - t[n] || a.city.filter((e) => e.upgraded).length - i.city.filter((e) => e.upgraded).length || a.path - i.path || a.realms.length - i.realms.length || j(a.resources) - j(i.resources);
	}, r = e.players.map((e) => e.rid).sort(n);
	return {
		phase: "done",
		scores: t,
		ranking: r,
		winner: e.koto ? t[r[0]] > rt(e, e.koto.player).total ? [r[0]] : [] : r.filter((e) => n(r[0], e) === 0)
	};
}
var dt = {
	meta: T,
	saveCompatibility: { version: "1" },
	schemas: {
		action: de,
		publicView: me,
		privateView: A,
		config: E
	},
	setup: at,
	reduce: ct,
	viewFor: lt,
	status: ut,
	nextTickIn: (e) => e.phase === "settle" ? 460 : null
}, ft = {
	name: "Everdell Emerland",
	discardCount: "已弃 {{n}} 张",
	desc: "在热带丛林建造繁荣城市，让工人与昆虫助手合作，发掘失落文明的遗物。",
	rules: "目标与准备：游戏支持1至4人。每人从夏季开始，拥有2名工人、2名助手、1名考古者和1颗祖母绿。按座次抽3、4、5、6张牌；单人抽4张。手牌上限6张，城市通常有12格，每张领地增加1格。同名牌可以重复；信鸽及升级守夜者不占城市空间。高台维持6种牌，同名牌叠放，回合结束时补牌；牌堆用尽时重洗弃牌。\n回合行动：每回合选择以下一项行动：\n· 派遣工人。\n· 单独派遣助手。\n· 打出1张牌。\n· 使用工匠。\n· 考古前进。\n· 准备下一季。\n绿色主板地点被任何工人占据时，须带1名助手谈判；可额外带1名助手作为向导，让地点奖励翻倍。喷泉每人每处限1名工人，不能使用向导。红色动物只接受自己1名工人或助手；红色建筑分别容纳主人和1位访客，访客使主人获得基础1分、升级2分，不能谈判或向导。\n助手与打牌：助手可以单独进入以下地点：\n· 升级处：支付1颗祖母绿，升级1张牌。\n· 泊船处：抽取2张牌，或选择1枚市场骰并获得对应奖励。\n打牌从手牌或高台支付费用。也可把1把竖琴放在自己的升级建筑上，免费打出任意动物的升级面；每种建筑颜色最多放1把竖琴。打出生产、旅行牌时立即激活，再结算原有治理牌。所有牌能力均可放弃。\n升级与工匠：升级后基础分增加1分。生产、旅行牌立即激活；已占用的目的地可再激活，主人优先，访客选择激活时主人再获得来访分。工匠以一次回合行动使用：把1张手牌面朝下放在工匠下方，然后激活；大多容量2张，学院与地图商店容量1张。\n考古与遗物：每次考古前进1格，按路径依次支付1、1、2、2、2份任意普通资源，最后一次还需额外支付1颗祖母绿，并弃置至少1张手牌。每弃置1张手牌，抽取1件遗物，额外抽取能力叠加，但只保留1件，其余放回袋中。到达该格时，取得该格剩余分值最高的分数堆。夏季最多前进1格，秋季2格，冬季3格，春季可到第5格失落之城，终点按先后获得7、5、3、2分。遗物按所示结算奖励，宝箱额外获得1件遗物；已到终点不能继续前进。\n季节与结束：工人全部派出后可准备下一季；助手不必用完。无合法派工地点时也可换季。收回自己的全部工人与助手。各季奖励如下：\n· 秋季：增加1名助手，并按自己选择的顺序激活全部生产牌。\n· 冬季：增加1名工人和1颗祖母绿，清空并补充高台。\n· 春季：增加2名工人和1名助手，并激活全部生产牌。\n各季第一个进入的人重掷4枚市场骰。春季可以结束自己的游戏，之后不再行动或获得资源，棋子保留占位。\n计分：所有人结束后，计算以下得分：\n· 城市卡牌的基础分。\n· 繁荣条件奖励。\n· 分数标记。\n· 遗物。\n· 失落之城位置。\n· 领地。\n· 剩余资源：包含祖母绿，每2份获得1分。\n最高分获胜；依次比较升级牌数量、考古位置、领地数、剩余资源，仍同则共享胜利。\n单人教授：按双人设置，教授先手，以4、5、6、9名工人逐季行动。教授先按远征牌派完工，再按挖掘牌从高台取牌，依当前季、后续季顺序寻找；无匹配时执行新计划，全部无匹配执行最后手段。教授忽略牌能力及普通资源，只获得祖母绿、分数、领地和遗物；城市上限固定15张。教授已派完工且你进入下一季后，教授下次行动换季。春季派完工且城市15张时结束，考古直接走至最高空位，途经每格获得分数堆和1件遗物。教授的计分按普通和困难难度分别计算：\n· 基础分：普通难度10分，困难难度15分。\n· 每张繁荣牌：普通难度3分，困难难度4分。\n· 每张升级牌：普通难度2分，困难难度3分。\n· 每张领地：普通难度4分，困难难度5分。\n· 每颗祖母绿：普通难度1分，困难难度2分。\n此外，再计算分数标记、遗物和失落之城终点的分数。你须严格超过教授。可选诡计：普通在教授换季及城市满15张时触发；困难另在每次教授考古后触发。\n数字版裁定：复制链内不能再次复制同名能力，以避免无穷循环；冬季每位玩家换季均清空高台。教授等待换季时，在自己的工人全部派完后跟随已经推进的玩家季节。详细牌面与升级能力可点牌查看。",
	plateau: "高台",
	board: "河流与喷泉",
	city: "城市",
	journey: "失落之城",
	hand: "手牌",
	deck: "牌堆",
	discardPile: "弃牌堆",
	artifacts: "遗物",
	realms: "领地",
	workers: "工人",
	helpers: "助手",
	harps: "竖琴",
	points: "分数标记",
	score: "当前得分",
	capacity: "城市空间",
	season: "准备下一季",
	end: "结束自己的游戏",
	ended: "已结束",
	choose: "确认选择",
	close: "关闭",
	inspect: "查看牌面",
	activate: "激活能力",
	skip: "放弃此能力",
	cancel: "返回",
	finish: "完成弃牌",
	draw: "抽取牌堆的牌",
	copyDie: "选择市场骰",
	emerald: "获得1颗祖母绿",
	freePlay: "支付1颗祖母绿，免费打牌",
	payEmerald: "支付1颗祖母绿",
	allowSteal: "允许教授拿走遗物",
	play: "打出此牌",
	artisan: "使用工匠",
	excavate: "考古前进",
	helper: "派遣助手",
	place: "派遣工人",
	payment: "选择支付方式",
	resource: "选择获得的资源",
	payResource: "选择支付的资源",
	discard: "选择弃掉的手牌",
	dice: "选择不同的市场骰",
	mooring: "选择泊船处奖励",
	upgrade: "选择要升级的牌",
	realm: "选择领地",
	artifact: "选择保留的遗物",
	plateauPrompt: "从高台拿牌",
	copy: "选择要激活的牌",
	production: "选择下一张生产牌",
	retrieveHarp: "选择收回哪把竖琴",
	retrieveWorker: "选择收回哪名工人",
	discardArtifact: "选择换掉的遗物",
	copyLocation: "选择要激活的占据地点",
	workshop: "选择宝石工坊奖励",
	playOffer: "选择要打出的牌",
	turn: "选择本回合行动",
	kotoRed: "选择教授拜访的建筑",
	stealChoice: "选择交给教授的最低分遗物",
	stealOrPay: "支付祖母绿保留遗物？",
	waiting: "等待 {{name}}",
	resolving: "正在结算",
	koto: "Koto 教授",
	normal: "普通",
	hard: "困难",
	soloDifficulty: "单人难度",
	tricks: "教授诡计",
	tricksHint: "单人对局加入诡计牌。困难模式下，教授考古时也会触发。",
	onlySolo: "仅影响单人对局",
	pay: "支付资源",
	free: "免费打出",
	harp: "使用建筑上的竖琴位",
	discountDiscard: "弃1张手牌减费",
	negotiator: "谈判",
	guide: "向导翻倍",
	night: "弃1张手牌代替谈判助手",
	helperCost: "带 {{n}} 名助手",
	noCost: "无需资源",
	fromHand: "从手牌打出",
	fromPlateau: "从高台打出",
	building: "建筑",
	critter: "动物",
	basic: "基础面",
	upgraded: "升级面",
	upgradePreview: "升级能力",
	tucked: "工匠下的牌",
	visitors: "访客",
	owner: "主人",
	unavailable: "当前不能执行",
	details: "查看详情",
	market: "市场骰",
	any: "任意普通资源",
	drawPoint: "抽1张牌并获得1分",
	removedDie: "本季移除",
	final: "丛林之歌",
	victory: "你的城市迎来繁荣",
	defeat: "教授完成了更辉煌的探险",
	overview: "回看最终牌桌",
	showResult: "返回计分",
	again: "再来一局",
	back: "返回大堂",
	waitHost: "等待主机",
	cardsScore: "城市基础分",
	prosperity: "繁荣奖励",
	pathScore: "失落之城",
	resourcesScore: "剩余资源",
	total: "总分",
	hintCount: "求助次数：{{n}}",
	autopilot: "托管：{{n}}%",
	confirmEnd: "结束后不能再次行动。确认结束自己的游戏？",
	confirmSeason: "收回自己的工人与助手，进入下一季。",
	expedition: "远征",
	excavation: "挖掘",
	trick: "诡计",
	lostCity: "终点",
	pathCost: "支付 {{n}} 份资源并弃至少1张手牌",
	confirm: "确认",
	inspectEmpty: "尚无城市牌",
	noHand: "手牌为空",
	used: "已使用",
	nameFallback: "探险者",
	"error.finished": "本局已经结束。",
	"error.turn": "请等待自己的行动。",
	"error.choice": "这个选择已失效，请重新选择。"
}, pt = Object.fromEntries(Object.keys(ft).map((e) => [e, `games.everdell-emerland.${e}`]));
function mt() {
	let e = f(), t = d((e) => e.locale), n = t === "zh" ? 0 : 1, r = (t, n) => e(pt[t], n), i = (e, t) => e.startsWith("c:") ? x[[...t?.players ?? [], ...t?.koto ? [t.koto.player] : []].flatMap((e) => e.city).find((t) => t.uid === Number(e.slice(2)))?.card ?? ""]?.name[n] ?? "" : se.find((t) => t[0] === e)?.[n === 0 ? 1 : 2] ?? "", a = (e) => e < 0 ? r("removedDie") : e < 4 ? ae[n][e] : r(e === 4 ? "any" : "drawPoint");
	return {
		text: r,
		lang: n,
		locale: t,
		location: i,
		die: a,
		label: (e, t) => e.kind === "place" || e.kind === "helper" || e.kind === "copyLocation" ? i(e.value, t) : e.kind === "resource" || e.kind === "payResource" ? ae[n][Number(e.value)] : e.kind === "die" ? a(e.n ?? 0) : e.kind === "realm" ? e.value === "top" ? r("deck") : C[e.n ?? 0].name[n] : [
			"artifact",
			"discardArtifact",
			"stealArtifact"
		].includes(e.kind) ? S[e.mode ?? ""]?.name[n] ?? "" : e.kind === "retrieveWorker" ? i(e.owner ?? "", t) : e.kind === "payment" ? r(e.mode === "harp" ? "harp" : e.mode === "free" ? "free" : e.mode === "discard" ? "discountDiscard" : "pay") : e.card ? x[e.card].name[n] : r(e.kind)
	};
}
//#endregion
//#region src/games/everdell-emerland/art.tsx
function Y({ name: e, children: t, className: n }) {
	let { ref: r, hidden: i } = u(e);
	return /* @__PURE__ */ m("div", {
		ref: r,
		className: n,
		style: i ? { visibility: "hidden" } : void 0,
		children: t
	});
}
function ht() {
	return /* @__PURE__ */ m("svg", {
		className: "em-ants",
		"aria-hidden": !0,
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		children: /* @__PURE__ */ m("rect", {
			x: "1.5",
			y: "1.5",
			width: "97",
			height: "97",
			rx: "6",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeDasharray: "5 4",
			vectorEffect: "non-scaling-stroke",
			children: /* @__PURE__ */ m("animate", {
				attributeName: "stroke-dashoffset",
				from: "18",
				to: "0",
				dur: "1.1s",
				repeatCount: "indefinite"
			})
		})
	});
}
function gt({ index: e }) {
	return /* @__PURE__ */ m("svg", {
		className: "em-icon",
		"aria-hidden": !0,
		viewBox: "0 0 32 32",
		children: /* @__PURE__ */ m("g", {
			stroke: "#394030",
			strokeWidth: "1.6",
			strokeLinejoin: "round",
			children: e === 0 ? /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("path", {
					d: "M11 28 7 26 21 3 26 6Z",
					fill: "#e9b748"
				}),
				/* @__PURE__ */ m("path", { d: "m10 23 6 3m-1-10 6 3m-1-10 6 3" }),
				/* @__PURE__ */ m("path", {
					d: "M19 9Q10 3 9 9q3 6 10 0",
					fill: "#7c9d37"
				})
			] }) : e === 1 ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
				d: "M5 27Q1 6 28 3q3 24-23 24",
				fill: "#8bb54e"
			}), /* @__PURE__ */ m("path", {
				d: "M6 27 25 6m-9 10-1-7m-3 12 10-1",
				fill: "none"
			})] }) : e === 2 ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
				d: "m3 12 7-8 17 3 3 15-10 7-16-7Z",
				fill: "#ebe9cf"
			}), /* @__PURE__ */ m("path", {
				d: "m3 12 16 4 8-9m-8 9 1 13",
				fill: "none",
				stroke: "#b9b7a9"
			})] }) : e === 3 ? /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("path", {
					d: "M18 4q-4 8-9 12-8 14 8 14 14-2 6-15-6-6-5-11",
					fill: "#9767a9"
				}),
				/* @__PURE__ */ m("path", {
					d: "M16 8 21 2l5 1-7 7",
					fill: "#6d9943"
				}),
				/* @__PURE__ */ m("path", {
					d: "M10 20q-2 7 5 7",
					fill: "none",
					stroke: "#c8a4d5"
				})
			] }) : /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
				d: "m8 3 20 4-3 21-21-3Z",
				fill: "#44a87a"
			}), /* @__PURE__ */ m("path", {
				d: "m8 3 3 7 12 2 5-5m-5 5-3 11 5 5M4 25l7-15m-7 15 16-2",
				fill: "none",
				stroke: "#b2e7b1"
			})] })
		})
	});
}
function X({ color: e, helper: t = !1 }) {
	return /* @__PURE__ */ h("svg", {
		className: "em-pawn",
		viewBox: "0 0 36 38",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ m("g", {
			fill: e,
			stroke: "#343326",
			strokeWidth: "1.8",
			strokeLinejoin: "round",
			children: t ? /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("ellipse", {
					cx: "18",
					cy: "23",
					rx: "11",
					ry: "12"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "18",
					cy: "9",
					r: "6"
				}),
				/* @__PURE__ */ m("path", {
					d: "M18 15v18M9 18 3 15m6 11-6 5m24-13 6-3m-6 11 6 5",
					fill: "none"
				})
			] }) : /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("path", { d: "M10 34 5 29l4-12 6-4h9l7 9-5 4 2 8H10Z" }),
				/* @__PURE__ */ m("circle", {
					cx: "19",
					cy: "9",
					r: "8"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "12",
					cy: "3",
					r: "3"
				}),
				/* @__PURE__ */ m("path", { d: "M24 10h8l-3 6h-7" })
			] })
		}), /* @__PURE__ */ m("circle", {
			cx: "22",
			cy: "8",
			r: "1.3",
			fill: "#252d24"
		})]
	});
}
function _t() {
	return /* @__PURE__ */ h("svg", {
		className: "em-icon em-flower",
		"aria-hidden": !0,
		viewBox: "0 0 32 32",
		children: [/* @__PURE__ */ m("path", {
			d: "M16 11C1-5 1 15 11 17-4 25 14 36 17 22c11 15 23-3 9-7C38 3 17-5 16 11",
			fill: "#fff8d8",
			stroke: "#aa7950",
			strokeWidth: "1.4"
		}), /* @__PURE__ */ m("circle", {
			cx: "18",
			cy: "17",
			r: "4",
			fill: "#e2b24d"
		})]
	});
}
function vt() {
	return /* @__PURE__ */ h("svg", {
		className: "em-icon",
		"aria-hidden": !0,
		viewBox: "0 0 32 32",
		children: [/* @__PURE__ */ m("path", {
			d: "M7 4h19l-4 22q-12 10-16-3l1-19",
			fill: "#e7b94a",
			stroke: "#795b33",
			strokeWidth: "2"
		}), /* @__PURE__ */ m("path", {
			d: "M11 7v17m5-17v19m5-19-1 17",
			stroke: "#fff1b9",
			strokeWidth: "1.6"
		})]
	});
}
function yt({ building: e }) {
	return /* @__PURE__ */ m("svg", {
		className: "em-icon",
		"aria-hidden": !0,
		viewBox: "0 0 32 32",
		fill: "currentColor",
		children: e ? /* @__PURE__ */ m("path", { d: "m3 15 13-12 13 12-3 3-2-2v13H8V16l-2 2Zm9 12h8V16h-8Z" }) : /* @__PURE__ */ m("path", { d: "M6 10C0 1 13-1 14 7c5-2 10 0 12 5l5 3-5 5-3 8H9l-2-9C3 17 3 12 6 10m13 2a1.5 1.5 0 1 0 3 0 1.5 1.5 0 0 0-3 0" })
	});
}
function bt({ resources: e, lang: t, all: n = !1 }) {
	return /* @__PURE__ */ m("span", {
		className: "em-resources",
		children: e.map((e, r) => e > 0 || n ? /* @__PURE__ */ h("span", {
			title: ae[t][r],
			"aria-label": `${ae[t][r]} ${e}`,
			children: [/* @__PURE__ */ m(gt, { index: r }), /* @__PURE__ */ m("b", { children: e })]
		}, r) : null)
	});
}
function xt({ id: e, city: t, legal: n = !1, small: i = !1, onClick: a, anchor: o }) {
	let { text: s, lang: c } = mt(), l = x[e], u = /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ h("div", {
			className: "em-card-art",
			children: [
				/* @__PURE__ */ m("img", {
					src: r(`games/everdell-emerland/live/${e}.webp`),
					alt: "",
					draggable: !1
				}),
				/* @__PURE__ */ h("span", {
					className: "em-card-points",
					children: [
						t?.upgraded ? /* @__PURE__ */ m(_t, {}) : "❀",
						" ",
						l.points + Number(!!t?.upgraded)
					]
				}),
				t?.harp && /* @__PURE__ */ m("span", {
					className: "em-card-harp",
					children: /* @__PURE__ */ m(vt, {})
				})
			]
		}),
		/* @__PURE__ */ h("div", {
			className: "em-card-name",
			children: [/* @__PURE__ */ m("b", { children: l.name[c] }), /* @__PURE__ */ m("span", {
				title: l.building ? s("building") : s("critter"),
				children: /* @__PURE__ */ m(yt, { building: l.building })
			})]
		}),
		/* @__PURE__ */ h("div", {
			className: "em-card-cost",
			children: [/* @__PURE__ */ m(bt, {
				resources: l.cost,
				lang: c
			}), /* @__PURE__ */ m("span", { children: ie[l.color][c] })]
		}),
		!i && /* @__PURE__ */ m("p", {
			className: "em-card-effect",
			children: (t?.upgraded ? l.upgrade : l.text)[c]
		}),
		t && l.capacity > 0 && /* @__PURE__ */ h("span", {
			className: "em-tucked",
			children: [
				"▱ ",
				t.tucked,
				"/",
				l.capacity
			]
		}),
		n && /* @__PURE__ */ m(ht, {})
	] }), d = {
		className: `em-card em-${l.color}${i ? " em-card-small" : ""}${n ? " em-legal" : ""}${t?.upgraded ? " is-upgraded" : ""}`,
		style: { "--em-type": {
			green: "#477f4b",
			blue: "#3e6c87",
			tan: "#91623c",
			red: "#a54938",
			orange: "#b67932",
			purple: "#7b5288"
		}[l.color] }
	}, f = a ? /* @__PURE__ */ m("button", {
		type: "button",
		...d,
		"aria-label": `${s("inspect")} ${l.name[c]}${t?.upgraded ? ` · ${s("upgraded")}` : ""}`,
		onClick: a,
		children: u
	}) : /* @__PURE__ */ m("div", {
		...d,
		children: u
	});
	return o ? /* @__PURE__ */ m(Y, {
		name: o,
		children: f
	}) : f;
}
function St({ id: e }) {
	return /* @__PURE__ */ m("img", {
		className: "em-artifact-glyph",
		src: r(`games/everdell-emerland/live/artifact-${e}.webp`),
		alt: "",
		draggable: !1
	});
}
//#endregion
//#region src/games/everdell-emerland/view-player.tsx
function Ct(e) {
	return /* @__PURE__ */ m(wt, {
		...e,
		pub: e.public,
		priv: e.private
	});
}
function wt({ pub: e, priv: t, members: u, myRid: d, send: f, readOnly: g = !1 }) {
	o();
	let { text: _, lang: v, locale: ee, location: te, die: ne, label: y } = mt(), [b, re] = n("plateau"), [ae, ce] = n(d), [w, le] = n(null), [T, ue] = n(null), [E, de] = n(null), fe = e.players.find((e) => e.rid === d) ?? e.players[0], pe = [...e.players, ...e.koto ? [e.koto.player] : []], D = pe.find((e) => e.rid === ae) ?? fe, O = (e) => {
		if (e === "$koto") return _("koto");
		let t = u.find((t) => t.rid === e);
		return t ? l(t, ee) : _("nameFallback");
	}, k = (e) => e === "$koto" ? "#b84942" : a[(u.find((t) => t.rid === e)?.colorIndex ?? 0) % a.length].hex, me = !g && e.phase === "play" && e.actor === d, A = me ? t?.choices ?? [] : [], he = w?.source?.startsWith("h:") ? t?.hand[Number(w.source.slice(2))] === w.card : w?.source?.startsWith("p:") ? e.plateau.some((e) => e.card === w.card) : !w?.uid || pe.some((e) => e.city.some((e) => e.uid === w.uid)), j = w?.rid === d && he ? w : null, M = (e) => {
		le(null), ue(null), de(null), f({
			type: "choose",
			id: e.id
		});
	}, N = (e, t) => A.filter((n) => n.kind === e && (t === void 0 || n.value === t)), P = (e) => pe.flatMap((e) => e.city).find((t) => t.uid === e), ge = j ? A.filter((e) => j.source ? e.kind === "play" && e.value === j.source : e.uid === j.uid && [
		"artisan",
		"place",
		"helper",
		"upgrade",
		"production",
		"copy",
		"retrieveHarp"
	].includes(e.kind)) : [], F = j?.uid ? P(j.uid) : void 0, I = e.phase === "settle" ? _("resolving") : me ? _(e.prompt === "plateau" ? "plateauPrompt" : e.prompt) + (e.prompt === "discard" ? ` · ${_("discardCount", { n: e.promptN })}` : "") : _("waiting", { name: O(e.actor) }), L = (t) => /* @__PURE__ */ m("span", {
		className: "em-markers",
		children: e.placements.filter((e) => e.location === t).map((e) => /* @__PURE__ */ m(Y, {
			name: `piece:${e.uid}`,
			children: /* @__PURE__ */ h("span", {
				className: "em-marker",
				title: O(e.rid),
				"aria-label": `${O(e.rid)} · ${e.worker ? _("workers") : _("helpers")}`,
				children: [/* @__PURE__ */ m(X, {
					color: k(e.rid),
					helper: !e.worker
				}), e.worker + e.helpers > 1 && /* @__PURE__ */ m("b", { children: e.worker + e.helpers })]
			})
		}, e.uid))
	}), R = (e, t, n) => le({
		card: e,
		uid: t?.uid,
		source: n,
		rid: d
	}), z = (e) => e.kind === "place" ? /* @__PURE__ */ h("span", { children: [
		e.mode?.startsWith("night") && /* @__PURE__ */ m("small", { children: _("night") }),
		(e.n ?? 0) > 0 && /* @__PURE__ */ m("small", { children: _("helperCost", { n: e.n }) }),
		e.mode?.includes("guide") && /* @__PURE__ */ m("small", { children: _("guide") })
	] }) : e.kind === "payment" ? /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m(bt, {
			resources: e.cost ?? [
				0,
				0,
				0,
				0,
				0
			],
			lang: v
		}),
		e.mode === "harp" && /* @__PURE__ */ m("small", { children: x[P(e.uid)?.card ?? ""]?.name[v] }),
		e.mode === "discard" && /* @__PURE__ */ h("small", { children: [
			_("discard"),
			" · ",
			x[t?.hand[Number(e.value)] ?? ""]?.name[v]
		] })
	] }) : null, B = (t) => {
		if (t.card && ![
			"payment",
			"place",
			"helper",
			"copyLocation"
		].includes(t.kind)) return /* @__PURE__ */ h("div", {
			className: "em-choice-card",
			children: [/* @__PURE__ */ m(xt, {
				id: t.card,
				city: t.uid ? P(t.uid) : void 0,
				legal: !0,
				onClick: () => M(t)
			}), /* @__PURE__ */ m("span", { children: _(t.kind === "play" ? "play" : t.kind === "discard" ? "discard" : t.kind === "artisan" ? "artisan" : t.kind === "upgrade" ? "upgrade" : "activate") })]
		}, t.id);
		if (t.kind === "resource" || t.kind === "payResource") return /* @__PURE__ */ h("button", {
			type: "button",
			className: "em-resource-choice",
			onClick: () => M(t),
			children: [/* @__PURE__ */ m(gt, { index: Number(t.value) }), /* @__PURE__ */ m("span", { children: y(t, e) })]
		}, t.id);
		if ([
			"artifact",
			"discardArtifact",
			"stealArtifact"
		].includes(t.kind)) {
			let e = S[t.mode];
			return /* @__PURE__ */ h("button", {
				type: "button",
				className: "em-artifact",
				onClick: () => M(t),
				children: [
					/* @__PURE__ */ m(St, { id: t.mode }),
					/* @__PURE__ */ m("strong", { children: e.name[v] }),
					/* @__PURE__ */ h("b", { children: ["❀ ", e.points] }),
					/* @__PURE__ */ m("p", { children: e.text[v] }),
					/* @__PURE__ */ m(ht, {})
				]
			}, t.id);
		}
		return t.kind === "realm" && t.n !== void 0 ? /* @__PURE__ */ h("button", {
			type: "button",
			className: "em-realm",
			onClick: () => M(t),
			children: [
				/* @__PURE__ */ m("span", {
					className: "em-realm-art",
					"aria-hidden": !0,
					children: "♧"
				}),
				/* @__PURE__ */ m("b", { children: C[t.n].name[v] }),
				/* @__PURE__ */ m("p", { children: C[t.n].text[v] }),
				/* @__PURE__ */ m(ht, {})
			]
		}, t.id) : t.kind === "die" ? /* @__PURE__ */ h("button", {
			type: "button",
			className: "em-die-choice",
			onClick: () => M(t),
			children: [/* @__PURE__ */ m("span", {
				className: "em-die",
				children: (t.n ?? 0) < 4 ? /* @__PURE__ */ m(gt, { index: t.n }) : t.n === 4 ? /* @__PURE__ */ m("span", { children: "✦" }) : /* @__PURE__ */ m("span", { children: "▱❀" })
			}), /* @__PURE__ */ m("span", { children: ne(t.n ?? 0) })]
		}, t.id) : /* @__PURE__ */ h("button", {
			type: "button",
			className: `em-choice${["skip", "cancel"].includes(t.kind) ? " em-quiet" : ""}`,
			onClick: () => M(t),
			children: [/* @__PURE__ */ m("b", { children: y(t, e) }), z(t)]
		}, t.id);
	}, _e = /* @__PURE__ */ h("section", {
		className: "em-scene em-board",
		"data-panel": "board",
		children: [
			/* @__PURE__ */ m("h2", { children: _("board") }),
			/* @__PURE__ */ m("div", {
				className: "em-locations",
				children: se.filter((t) => t[0] !== "exchange" || e.players.length >= 3).filter((t) => !["treasure", "grandMarket"].includes(t[0]) || e.players.length === 4).map((e, t) => {
					let n = A.filter((t) => (t.kind === "place" || t.kind === "helper" || t.kind === "copyLocation") && t.value === e[0]);
					return /* @__PURE__ */ m(Y, {
						name: `location:${e[0]}`,
						children: /* @__PURE__ */ h("button", {
							type: "button",
							className: `em-location${t < 6 ? " em-grove" : ""}${n.length ? " em-legal" : ""}`,
							onClick: () => ue(e[0]),
							"aria-label": `${e[v === 0 ? 1 : 2]} · ${e[v === 0 ? 3 : 4]}`,
							children: [
								/* @__PURE__ */ m("span", {
									className: "em-location-icon",
									"aria-hidden": !0,
									children: t < 5 ? /* @__PURE__ */ m(gt, { index: [
										4,
										2,
										0,
										1,
										3
									][t] }) : t === 5 ? "⚄" : e[0] === "song" ? /* @__PURE__ */ m(vt, {}) : e[0] === "realm" ? "♧" : e[0] === "upgrade" ? /* @__PURE__ */ m(_t, {}) : e[0] === "mooring" ? "⚓" : "❦"
								}),
								/* @__PURE__ */ m("b", { children: e[v === 0 ? 1 : 2] }),
								/* @__PURE__ */ m("span", { children: e[v === 0 ? 3 : 4] }),
								L(e[0]),
								n.length > 0 && /* @__PURE__ */ m(ht, {})
							]
						})
					}, e[0]);
				})
			}),
			/* @__PURE__ */ m("div", {
				className: "em-dice-row",
				"aria-label": _("market"),
				children: e.dice.map((e, t) => /* @__PURE__ */ m(Y, {
					name: `die:${t}`,
					children: /* @__PURE__ */ m("div", {
						className: `em-die${e < 0 ? " is-removed" : ""}`,
						title: ne(e),
						children: e < 0 ? "—" : e < 4 ? /* @__PURE__ */ m(gt, { index: e }) : e === 4 ? "✦" : "▱❀"
					})
				}, t))
			})
		]
	}), ve = /* @__PURE__ */ h("section", {
		className: "em-scene em-plateau",
		"data-panel": "plateau",
		children: [/* @__PURE__ */ h("div", {
			className: "em-scene-heading",
			children: [/* @__PURE__ */ m("h2", { children: _("plateau") }), /* @__PURE__ */ m(Y, {
				name: "deck",
				children: /* @__PURE__ */ h("span", {
					className: "em-deck-count",
					children: [
						"▱ ",
						e.deckCount,
						" · ",
						_("discardPile"),
						" ",
						e.discardCount
					]
				})
			})]
		}), /* @__PURE__ */ m("div", {
			className: "em-plateau-grid",
			children: e.plateau.map((e) => /* @__PURE__ */ h("div", {
				className: "em-plateau-slot",
				children: [/* @__PURE__ */ m(xt, {
					id: e.card,
					legal: N("play", `p:${e.card}`).length > 0 || N("plateau", e.card).length > 0 || N("copy", `p:${e.card}`).length > 0,
					onClick: () => R(e.card, void 0, `p:${e.card}`),
					anchor: `plateau:${e.card}`
				}), e.count > 1 && /* @__PURE__ */ h("span", {
					className: "em-stack-count",
					children: ["▱ ", e.count]
				})]
			}, e.card))
		})]
	}), ye = /* @__PURE__ */ h("section", {
		className: "em-scene em-city",
		"data-panel": "city",
		children: [
			/* @__PURE__ */ m("div", {
				className: "em-city-tabs",
				children: pe.map((e) => /* @__PURE__ */ m("button", {
					type: "button",
					"aria-pressed": D.rid === e.rid,
					onClick: () => ce(e.rid),
					children: O(e.rid)
				}, e.rid))
			}),
			/* @__PURE__ */ h("div", {
				className: "em-city-heading",
				children: [/* @__PURE__ */ h("span", { children: [
					_("city"),
					" ",
					D.city.filter((e) => e.card !== "postalPigeon" && !(e.card === "nightwatch" && e.upgraded)).length,
					"/",
					D.rid === "$koto" ? 15 : 12 + D.realms.length
				] }), /* @__PURE__ */ h("span", { children: ["❀ ", /* @__PURE__ */ m(s, { value: D.score.total })] })]
			}),
			/* @__PURE__ */ h(Y, {
				name: `city:${D.rid}`,
				className: "em-city-grid",
				children: [D.city.map((e) => /* @__PURE__ */ h("div", {
					className: "em-city-slot",
					children: [/* @__PURE__ */ m(xt, {
						id: e.card,
						city: e,
						legal: A.some((t) => t.uid === e.uid),
						onClick: () => R(e.card, e),
						anchor: `card:${e.uid}`
					}), /* @__PURE__ */ m(Y, {
						name: `location:c:${e.uid}`,
						children: L(`c:${e.uid}`)
					})]
				}, e.uid)), D.city.length === 0 && /* @__PURE__ */ h("div", {
					className: "em-empty-city",
					children: [/* @__PURE__ */ m("span", {
						"aria-hidden": !0,
						children: "♧"
					}), /* @__PURE__ */ m("p", { children: _("inspectEmpty") })]
				})]
			}),
			/* @__PURE__ */ h("div", {
				className: "em-collections",
				children: [
					/* @__PURE__ */ m("h3", { children: _("realms") }),
					/* @__PURE__ */ m("div", {
						className: "em-collection-grid",
						children: D.realms.map((e) => /* @__PURE__ */ h("div", {
							className: "em-realm",
							children: [
								/* @__PURE__ */ m("span", {
									className: "em-realm-art",
									"aria-hidden": !0,
									children: "♧"
								}),
								/* @__PURE__ */ m("b", { children: C[e].name[v] }),
								/* @__PURE__ */ m("p", { children: C[e].text[v] })
							]
						}, e))
					}),
					/* @__PURE__ */ h("h3", { children: [
						_("artifacts"),
						" ",
						D.artifacts.length
					] }),
					/* @__PURE__ */ m(Y, {
						name: `artifacts:${D.rid}`,
						className: "em-collection-grid",
						children: D.artifacts.map((e, t) => /* @__PURE__ */ h("div", {
							className: "em-artifact",
							children: [
								/* @__PURE__ */ m(St, { id: e }),
								/* @__PURE__ */ h("b", { children: [
									S[e].name[v],
									" · ❀ ",
									S[e].points
								] }),
								/* @__PURE__ */ m("p", { children: S[e].text[v] })
							]
						}, `${e}:${t}`))
					})
				]
			})
		]
	}), V = /* @__PURE__ */ h("section", {
		className: "em-scene em-journey",
		"data-panel": "journey",
		children: [
			/* @__PURE__ */ m("h2", { children: _("journey") }),
			/* @__PURE__ */ h(Y, {
				name: "path",
				className: "em-path",
				children: [/* @__PURE__ */ m("div", {
					className: "em-path-start",
					children: pe.filter((e) => e.path === 0).map((e) => /* @__PURE__ */ m("span", {
						title: O(e.rid),
						children: /* @__PURE__ */ m(X, { color: k(e.rid) })
					}, e.rid))
				}), [
					1,
					2,
					3,
					4,
					5
				].map((t, n) => {
					let r = N("excavate")[0], i = !!r && fe.path === n;
					return /* @__PURE__ */ m(Y, {
						name: `path:${t}`,
						children: /* @__PURE__ */ h("button", {
							type: "button",
							className: `em-path-step${i ? " em-legal" : ""}`,
							onClick: () => i ? de(r) : void 0,
							"aria-label": n === 4 ? _("lostCity") : _("pathCost", { n: [
								1,
								1,
								2,
								2,
								2
							][n] }),
							children: [
								/* @__PURE__ */ m("span", { children: n < 3 ? oe[v][n] : n === 3 ? oe[v][3] : _("lostCity") }),
								/* @__PURE__ */ m("b", { children: n === 4 ? `${e.lostCityAvailable.join(" · ")} ❀` : `${[
									1,
									1,
									2,
									2
								][n]} ✦` }),
								n === 4 ? /* @__PURE__ */ m(gt, { index: 4 }) : /* @__PURE__ */ h("span", {
									className: "em-path-points",
									children: [e.pathPiles[n].join(" · "), " ❀"]
								}),
								/* @__PURE__ */ m("span", {
									className: "em-path-pawns",
									children: pe.filter((e) => e.path === t).map((e) => /* @__PURE__ */ m("span", {
										title: O(e.rid),
										"aria-label": O(e.rid),
										children: /* @__PURE__ */ m(X, { color: k(e.rid) })
									}, e.rid))
								}),
								i && /* @__PURE__ */ m(ht, {})
							]
						})
					}, t);
				})]
			}),
			/* @__PURE__ */ m("h3", { children: _("realms") }),
			/* @__PURE__ */ m("div", {
				className: "em-faceup-realms",
				children: e.realms.map((e) => /* @__PURE__ */ h("div", {
					className: "em-realm",
					children: [
						/* @__PURE__ */ m("span", {
							className: "em-realm-art",
							"aria-hidden": !0,
							children: "♧"
						}),
						/* @__PURE__ */ m("b", { children: C[e].name[v] }),
						/* @__PURE__ */ m("p", { children: C[e].text[v] })
					]
				}, e))
			}),
			/* @__PURE__ */ m(Y, {
				name: "artifacts",
				children: /* @__PURE__ */ h("span", {
					className: "em-bag",
					children: [
						"♟ ",
						_("artifacts"),
						" · ",
						e.artifactCount
					]
				})
			}),
			e.koto && /* @__PURE__ */ h("div", {
				className: "em-professor",
				children: [
					/* @__PURE__ */ m(X, { color: k("$koto") }),
					/* @__PURE__ */ m("b", { children: _("koto") }),
					e.koto.deck && /* @__PURE__ */ h("span", { children: [
						_(e.koto.deck),
						" · ",
						e.koto.card + 1
					] })
				]
			})
		]
	}), be = j ? A.filter((e) => j.source?.startsWith("p:") && (e.kind === "plateau" && e.card === j.card || e.kind === "copy" && e.value === `p:${j.card}`)) : [], xe = T ? A.filter((e) => [
		"place",
		"helper",
		"copyLocation"
	].includes(e.kind) && e.value === T) : [], H = me && e.prompt !== "turn" && !j && !T && !E;
	return /* @__PURE__ */ m(c, {
		adaptive: !0,
		scroll: !1,
		className: "em-game",
		actionsHeight: "em-hand-height",
		banner: /* @__PURE__ */ h("div", {
			className: "em-header",
			children: [/* @__PURE__ */ m("div", {
				className: "em-players",
				children: pe.map((t) => {
					let n = u.find((e) => e.rid === t.rid), a = t.workers - e.placements.filter((e) => e.rid === t.rid).reduce((e, t) => e + t.worker, 0), o = t.helpers - e.placements.filter((e) => e.rid === t.rid).reduce((e, t) => e + t.helpers, 0);
					return /* @__PURE__ */ m(Y, {
						name: `seat:${t.rid}`,
						children: /* @__PURE__ */ h("button", {
							type: "button",
							className: `em-player${t.rid === e.turn ? " is-turn" : ""}`,
							style: { "--em-player": k(t.rid) },
							onClick: () => {
								ce(t.rid), re("city");
							},
							children: [
								/* @__PURE__ */ h("span", {
									className: "em-player-top",
									children: [
										n ? /* @__PURE__ */ m("img", {
											src: r(i[n.avatar % i.length]),
											alt: ""
										}) : /* @__PURE__ */ m(X, { color: k(t.rid) }),
										/* @__PURE__ */ m("b", { children: O(t.rid) }),
										/* @__PURE__ */ h("span", { children: [oe[v][t.season], t.ended ? ` · ${_("ended")}` : ""] })
									]
								}),
								/* @__PURE__ */ m(bt, {
									resources: t.resources,
									lang: v,
									all: !0
								}),
								/* @__PURE__ */ h("span", {
									className: "em-player-bottom",
									children: [
										/* @__PURE__ */ h("span", {
											title: _("workers"),
											children: [
												/* @__PURE__ */ m(X, { color: k(t.rid) }),
												" ",
												a
											]
										}),
										/* @__PURE__ */ h("span", {
											title: _("helpers"),
											children: [
												/* @__PURE__ */ m(X, {
													color: k(t.rid),
													helper: !0
												}),
												" ",
												o
											]
										}),
										/* @__PURE__ */ h("span", {
											title: _("harps"),
											children: [
												/* @__PURE__ */ m(vt, {}),
												" ",
												t.harps
											]
										}),
										/* @__PURE__ */ h("span", { children: ["▱ ", t.handCount] }),
										/* @__PURE__ */ h("span", { children: ["❀ ", /* @__PURE__ */ m(s, { value: t.score.total })] })
									]
								})
							]
						})
					}, t.rid);
				})
			}), /* @__PURE__ */ m("div", {
				className: "em-prompt",
				role: "status",
				children: g ? _("overview") : I
			})]
		}),
		actions: /* @__PURE__ */ h("div", {
			className: "em-hand-bar",
			children: [/* @__PURE__ */ h(Y, {
				name: `hand:${d}`,
				className: "em-hand",
				children: [
					/* @__PURE__ */ h("span", {
						className: "em-hand-label",
						children: [
							_("hand"),
							" ",
							t?.hand.length ?? 0,
							"/6"
						]
					}),
					t?.hand.map((e, t) => /* @__PURE__ */ m(xt, {
						id: e,
						small: !0,
						legal: N("play", `h:${t}`).length > 0,
						onClick: () => R(e, void 0, `h:${t}`)
					}, `${t}:${e}`)),
					!t?.hand.length && /* @__PURE__ */ m("span", {
						className: "em-no-hand",
						children: _("noHand")
					})
				]
			}), /* @__PURE__ */ h("div", {
				className: "em-turn-actions",
				children: [N("season").map((e) => /* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => de(e),
					children: _("season")
				}, e.id)), N("end").map((e) => /* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => de(e),
					children: _("end")
				}, e.id))]
			})]
		}),
		overlay: (j || T || E || H) && /* @__PURE__ */ m("div", {
			className: "em-dialog-shade",
			children: /* @__PURE__ */ h("section", {
				className: `em-dialog${j ? " em-inspector" : ""}`,
				role: "dialog",
				"aria-modal": "true",
				"aria-label": j ? x[j.card].name[v] : T ? te(T, e) : I,
				children: [(j || T || E) && /* @__PURE__ */ m("button", {
					type: "button",
					className: "em-close",
					"aria-label": _("close"),
					onClick: () => {
						le(null), ue(null), de(null);
					},
					children: "×"
				}), j ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(xt, {
					id: j.card,
					city: F,
					small: !0
				}), /* @__PURE__ */ h("div", {
					className: "em-inspector-text",
					children: [
						/* @__PURE__ */ h("b", { children: [
							x[j.card].building ? _("building") : _("critter"),
							" · ",
							ie[x[j.card].color][v]
						] }),
						/* @__PURE__ */ m("h3", { children: _("basic") }),
						/* @__PURE__ */ m("p", { children: x[j.card].text[v] }),
						/* @__PURE__ */ h("h3", { children: [/* @__PURE__ */ m(_t, {}), _("upgradePreview")] }),
						/* @__PURE__ */ m("p", { children: x[j.card].upgrade[v] }),
						/* @__PURE__ */ m("div", {
							className: "em-choice-grid",
							children: [...ge, ...be].map((e) => /* @__PURE__ */ h("button", {
								type: "button",
								className: "em-choice",
								onClick: () => M(e),
								children: [/* @__PURE__ */ m("b", { children: _(e.kind === "play" ? "play" : e.kind === "place" ? "place" : e.kind === "helper" ? "helper" : e.kind === "artisan" ? "artisan" : e.kind === "upgrade" ? "upgrade" : "activate") }), z(e)]
							}, e.id))
						})
					]
				})] }) : T ? /* @__PURE__ */ h(p, { children: [
					/* @__PURE__ */ m("h2", { children: te(T, e) }),
					/* @__PURE__ */ m("p", { children: se.find((e) => e[0] === T)?.[v === 0 ? 3 : 4] }),
					L(T),
					/* @__PURE__ */ m("div", {
						className: "em-choice-grid",
						children: xe.map(B)
					}),
					!xe.length && /* @__PURE__ */ m("p", { children: _("unavailable") })
				] }) : E ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("h2", { children: _(E.kind === "end" ? "confirmEnd" : E.kind === "season" ? "confirmSeason" : "pathCost", E.kind === "excavate" ? { n: [
					1,
					1,
					2,
					2,
					2
				][fe.path] } : void 0) }), /* @__PURE__ */ m("button", {
					type: "button",
					className: "em-choice em-primary",
					onClick: () => M(E),
					children: _("confirm")
				})] }) : /* @__PURE__ */ h(p, { children: [
					/* @__PURE__ */ m("h2", { children: I }),
					(e.source ?? A.find((e) => e.card)?.card) && /* @__PURE__ */ m("span", {
						className: "em-source",
						children: x[e.source ?? A.find((e) => e.card).card]?.name[v]
					}),
					/* @__PURE__ */ m("div", {
						className: "em-choice-grid",
						children: A.map(B)
					})
				] })]
			})
		}),
		children: /* @__PURE__ */ h(Y, {
			name: "table",
			className: "em-table",
			children: [
				/* @__PURE__ */ m("nav", {
					className: "em-navigation",
					children: [
						"board",
						"plateau",
						"city",
						"journey"
					].map((e) => /* @__PURE__ */ m(Y, {
						name: `tab:${e}`,
						children: /* @__PURE__ */ m("button", {
							type: "button",
							"aria-pressed": b === e,
							onClick: () => re(e),
							children: _(e)
						})
					}, e))
				}),
				/* @__PURE__ */ h("div", {
					className: "em-panels",
					"data-tab": b,
					children: [
						_e,
						ve,
						ye,
						V
					]
				}),
				/* @__PURE__ */ m(Y, { name: "supply" })
			]
		})
	});
}
//#endregion
//#region src/games/everdell-emerland/bot.ts
var Tt = {
	production: 1,
	governance: 2,
	resource: 1,
	artifact: 2,
	upgrade: 2,
	space: 1
};
function Et(e = Tt) {
	return (t, n) => {
		let r = t.public, i = t.private, a = r.players.find((e) => e.rid === n.rid);
		if (!i || !a || r.phase !== "play" || r.actor !== n.rid || !i.choices.length) return null;
		let o = i.hand, s = a.city, c = a.season, l = 12 + a.realms.length - s.filter((e) => e.card !== "postalPigeon" && !(e.card === "nightwatch" && e.upgraded)).length, u = [
			0,
			0,
			0,
			0
		];
		for (let e of [...o, ...r.plateau.map((e) => e.card)]) {
			let t = x[e];
			for (let e = 0; e < 4; e++) u[e] = Math.max(u[e], t.cost[e] - a.resources[e]);
		}
		let d = (t) => t === 4 ? a.resources[4] < 2 ? 1.8 : 1.15 : e.resource * (1 + Math.min(2, Math.max(0, u[t])) * .35) / (1 + a.resources[t] * .14), f = Math.max(.08, (6 - o.length) * .12), p = (t, n = !1) => {
			let r = n ? 2 : 1, i = x[t], s = {
				treeNursery: r * d(1),
				cargoMill: r * d(0),
				fruitMarket: r * d(3),
				marbleQuarry: r * d(2),
				mineShaft: r * d(4),
				skyScout: r * f,
				noveltyShop: 1 + r * f,
				tradeDock: r * 1.3,
				ropeMiner: o.length ? 1.2 : 0,
				piper: r * .7 + 1,
				juggler: n ? 1 : .1,
				harpist: a.harps < 2 ? 1.4 : 0,
				digger: e.artifact * (n ? 4 : o.length ? 2.7 : 0),
				chipchop: 2.1,
				baseCamp: a.artifacts.length ? 1.2 : 0,
				apothecary: 2.2,
				tunnelNetwork: 3.5,
				troubadour: 2.8,
				ropeBridge: 4.3,
				postalPigeon: n ? 2 : Math.min(4, 6 - o.length) * f,
				minersCamp: (n ? 3 : 2) * d(4),
				lostRuin: e.artifact * (n ? 5.1 : 4.6),
				interpreter: 1.8 * r,
				floatingMarket: (n ? 3 : 2) * 1.3,
				dancer: a.harps < 2 ? 2.7 : 1,
				crafter: r * 2.5,
				archaeologist: e.artifact * (n ? 5 : 4),
				vineSurfer: 3,
				drummer: 4,
				travelCenter: (n ? 3 : 2) * (f + 1),
				tomb: 2.5 + (n ? d(4) : 0),
				postOffice: 3.6,
				inn: 3.6,
				treetopBazaar: (n ? 3 : 2) * 1.3,
				caveHermit: e.upgrade * (2.6 + (n ? 1.2 : 0)),
				adventurer: 3,
				tradeGate: 1 + (n ? 2 : 0),
				studio: e.upgrade * (n ? 3.3 : 2.2),
				mapShop: n ? 6 : 3.4,
				luthier: (n ? 3 : 2) * d(0) + 1,
				gardener: r * d(1) + 1,
				chiseler: r * d(2) + 1,
				chef: r * d(3) + 1,
				bridgeBuilder: r * 1.3,
				academy: 3.8
			};
			return i.color === "blue" ? ({
				canopyHighway: 2.8,
				thatcher: 1.6,
				playwright: 1.6,
				waypoint: 2.7,
				riverExplorer: 2.7,
				auctionHouse: 2.2,
				gemWorkshop: 2.6,
				trumpeter: 1.7,
				steamboat: 1.7,
				nightwatch: 1.4
			}[t] ?? 0) * (n ? 1.5 : 1) : s[t] ?? 0;
		}, m = (t) => {
			let n = x[t], r = c === 0 ? 2.1 : c < 3 ? 1.5 : 1, i = n.points;
			return n.color === "green" && (i += p(t) * r * e.production), n.color === "tan" && (i += p(t)), n.color === "orange" && (i += p(t) * Math.min(1.5, o.length * .5)), n.color === "blue" && (i += p(t) * (3 - c) / 3 * e.governance), n.color === "red" && (i += p(t) * (.5 + (3 - c) * .22)), n.color === "purple" && (i += 2.2), l <= 2 && t !== "postalPigeon" && (i -= e.space * (l === 1 ? 2 : 1)), i;
		}, h = (e) => {
			let t = (e) => s.filter((t) => x[t.card].color === e).length, n = s.filter((e) => x[e.card].building).length, r = s.filter((e) => e.upgraded && x[e.card].building).length, i = s.filter((e) => e.upgraded && !x[e.card].building).length, o = a.harps + s.filter((e) => e.harp).length;
			return [
				r + i,
				2 * t("tan"),
				2 * t("blue"),
				2 * t("red"),
				2 * t("orange"),
				2 * new Set(s.map((e) => x[e.card].color)).size,
				s.length - n,
				n,
				Math.floor(a.points / 2),
				2 * r,
				3 * (a.realms.length + 1),
				new Set(a.artifacts).size,
				2 * o,
				2 * i,
				2 * s.filter((e) => e.harp).length,
				2 * s.reduce((e, t) => e + t.tucked, 0),
				3 * t("purple"),
				2 * t("green")
			][e] + (3 - c) * .6;
		}, g = (t) => {
			if (t.startsWith("c:")) {
				let e = [...r.players, ...r.koto ? [r.koto.player] : []].flatMap((e) => e.city).find((e) => e.uid === Number(t.slice(2)));
				return e ? p(e.card, e.upgraded) : 0;
			}
			return {
				bamboo: 3 * d(0),
				leaf: 2 * d(1),
				marble: d(2) + f,
				fig: 2 * d(3),
				emerald: 2 * d(4),
				market: 2.7,
				realm: Math.max(2, ...r.realms.map(h)) - 2 * d(4) + Math.max(0, 3 - l),
				song: (a.harps < 2 ? 3.8 : 1) + Math.min(3, 6 - o.length) * f - d(4),
				exchange: 2 * f + d(4) + 1.4,
				treasure: d(4) + 4 * e.artifact,
				grandMarket: 5 - d(4),
				upgrade: 3.3 * e.upgrade - d(4),
				mooring: Math.max(2 * f, 1.4)
			}[t] ?? 0;
		}, _ = (t) => {
			if (t.kind === "skip") return -1;
			if (t.kind === "cancel") return -100;
			if (t.kind === "end") return -2;
			if (t.kind === "season") return -1.8;
			if (t.kind === "activate") return .1;
			if (t.kind === "finish") return 0;
			if (t.kind === "payment") return -(t.cost ?? []).reduce((e, t, n) => e + t * d(n), 0) - +(t.mode === "discard") + (t.mode === "harp" ? .8 : 0);
			if (t.kind === "resource") return d(Number(t.value));
			if (t.kind === "payResource") return -d(Number(t.value));
			if (t.kind === "place" || t.kind === "helper" || t.kind === "copyLocation") return g(t.value) * (t.mode?.includes("guide") ? 2 : 1) - (t.n ?? 0) * .7 - (t.mode?.startsWith("night") ? 1.2 : 0);
			if (t.kind === "excavate") return e.artifact * 4 + (r.pathPiles[a.path]?.[0] ?? 0) * .7 + (a.path === 4 ? r.lostCityAvailable[0] ?? 0 : 0) - [
				1,
				1,
				2,
				2,
				2
			][a.path] * .5 - 1;
			if (t.kind === "artisan") {
				let e = s.find((e) => e.uid === t.uid);
				return p(t.card, e.upgraded) - .8;
			}
			if (t.kind === "realm") return t.value === "top" ? 2 : h(t.n ?? 0);
			if ([
				"artifact",
				"discardArtifact",
				"stealArtifact"
			].includes(t.kind)) {
				let e = S[t.mode].points + ({
					cloth: 2.5,
					chest: 4.5,
					harp: 2,
					ring: d(4),
					dice: 1.4,
					pot: 1.4,
					scale: 1,
					parchment: f,
					sundial: 2.5,
					cape: f
				}[t.mode] ?? 0);
				return t.kind === "artifact" ? e : -e;
			}
			if (t.kind === "die") {
				let e = t.n ?? 0;
				return e < 4 ? d(e) : e === 4 ? Math.max(...u.map((e, t) => d(t))) : 1 + f;
			}
			if (t.kind === "copy" || t.kind === "production") {
				let e = t.uid ? [...r.players, ...r.koto ? [r.koto.player] : []].flatMap((e) => e.city).find((e) => e.uid === t.uid) : void 0;
				return p(t.card, e?.upgraded);
			}
			if (t.kind === "upgrade") {
				let n = s.find((e) => e.uid === t.uid);
				return n ? e.upgrade * (1 + (p(n.card, !0) - p(n.card, !1)) * (x[n.card].color === "green" ? 1 + (3 - c) * .35 : 1) + (x[n.card].building && a.harps > 0 ? 2 : 0)) : -x[t.card].points;
			}
			return t.kind === "discard" ? -Math.max(.1, m(t.card) * .15) + (r.prompt === "discard" && o.length === 6 ? .8 : 0) : t.card ? t.kind === "play" ? m(t.card) - x[t.card].cost.reduce((e, t, n) => e + t * d(n) * .4, 0) : m(t.card) : t.kind === "draw" ? 2 * f : t.kind === "copyDie" ? 1.4 : t.kind === "emerald" ? d(4) : t.kind === "payEmerald" ? 2 : t.kind === "allowSteal" ? -2 : t.kind === "freePlay" ? 0 : 1;
		}, v = i.choices[0], ee = -Infinity;
		for (let e of i.choices) {
			let t = _(e);
			n.difficulty === "weak" && e.kind === "play" && (t = x[e.card].points), t > ee && (ee = t, v = e);
		}
		return { action: {
			type: "choose",
			id: v.id
		} };
	};
}
var Dt = Et(), Ot = (e, t, n) => {
	if (e.type !== "choose") return "";
	let r = t.private?.choices.find((t) => t.id === e.id);
	if (!r) return "";
	let i = d.getState().locale === "zh" ? 0 : 1;
	return r.card ? x[r.card].name[i] : r.kind === "resource" || r.kind === "payResource" ? ae[i][Number(r.value)] : r.kind === "place" || r.kind === "helper" ? se.find((e) => e[0] === r.value)?.[i === 0 ? 1 : 2] ?? n("games.everdell-emerland.place") : r.kind === "realm" && r.n !== void 0 ? C[r.n].name[i] : r.kind === "artifact" ? S[r.mode].name[i] : n("games.everdell-emerland.choose");
}, Z = (e, t, n = "") => {
	let r = t.startsWith("location:") ? "board" : t.startsWith("card:") || t.startsWith("city:") || t.startsWith("artifacts:") ? "city" : t.startsWith("path") ? "journey" : "plateau";
	for (let i of [
		t,
		`tab:${r}`,
		`seat:${n}`,
		"table"
	]) {
		let t = e.anchor(i);
		if (t && t.w > 0 && t.h > 0) return t;
	}
	return null;
}, Q = (e, t = 30, n = 32) => ({
	...e,
	x: e.x + (e.w - t) / 2,
	y: e.y + (e.h - n) / 2,
	w: t,
	h: n
}), kt = (e, t) => {
	let n = e.anchor(t);
	return !e.queued && n && n.w > 0 && n.h > 0 ? [t] : [];
}, $ = (e) => e.queued ? 170 : 460, At = {
	cards(e, t) {
		let n = e.data, r = Z(t, n.from, e.rid), i = Z(t, n.to, e.rid);
		return !r || !i ? null : {
			ms: $(t),
			node: /* @__PURE__ */ m(g, {
				from: Q(r, 42, 58),
				to: Q(i, 42, 58),
				ms: $(t) - 25,
				children: /* @__PURE__ */ h("span", {
					style: {
						display: "grid",
						placeItems: "center",
						height: 58,
						width: 42,
						border: "2px solid #cfba77",
						borderRadius: 6,
						background: "repeating-linear-gradient(45deg,#406e53 0 6px,#315b46 6px 12px)",
						color: "#fff1c5",
						fontWeight: 700
					},
					children: ["▱ ", n.n]
				})
			})
		};
	},
	refill(e, t) {
		let n = e.data, r = t.anchor(`plateau:${n.card}`);
		return r && r.w > 0 && r.h > 0 ? {
			ms: $(t),
			node: /* @__PURE__ */ m(_, {
				at: r,
				ms: $(t)
			})
		} : null;
	},
	retrieve(e, t) {
		let n = e.data, r = Z(t, `location:${n.location}`, e.rid), i = Z(t, `seat:${e.rid}`, e.rid);
		if (!r || !i) return null;
		let o = e.rid === "$koto" ? "#b84942" : a[(t.member(e.rid ?? "")?.colorIndex ?? 0) % a.length].hex;
		return {
			ms: $(t),
			node: /* @__PURE__ */ m(g, {
				from: Q(r),
				to: Q(i),
				ms: $(t) - 25,
				children: /* @__PURE__ */ m("span", {
					style: { fontSize: 25 },
					children: /* @__PURE__ */ m(X, {
						color: o,
						helper: n.helper
					})
				})
			})
		};
	},
	resource(e, t) {
		let n = e.data, r = Z(t, n.from, e.rid), i = Z(t, n.to, e.rid);
		return !r || !i ? null : {
			ms: $(t),
			node: /* @__PURE__ */ m(g, {
				from: Q(r, 48, 32),
				to: Q(i, 48, 32),
				ms: $(t) - 30,
				children: /* @__PURE__ */ h("span", {
					style: {
						display: "flex",
						alignItems: "center",
						padding: 3,
						borderRadius: 8,
						background: "#f2e4b8",
						fontSize: 20,
						color: "#34432e"
					},
					children: [/* @__PURE__ */ m(gt, { index: n.resource }), /* @__PURE__ */ m("b", { children: n.n })]
				})
			})
		};
	},
	card(e, t) {
		let n = e.data, r = Z(t, n.from, e.rid), i = Z(t, n.to, e.rid);
		if (!r || !i) return null;
		let a = t.anchor(n.to), o = a && a.w > 0 && a.h > 0 ? a : Q(i, 80, 110);
		return {
			ms: $(t),
			hide: kt(t, n.to),
			node: /* @__PURE__ */ m(g, {
				from: Q(r, 80, 110),
				to: o,
				ms: $(t) - 25,
				children: /* @__PURE__ */ m("div", {
					style: {
						width: 80,
						height: 110
					},
					children: /* @__PURE__ */ m(xt, {
						id: n.card,
						small: !0
					})
				})
			})
		};
	},
	worker(e, t) {
		let n = e.data, r = Z(t, `seat:${e.rid}`, e.rid), i = Z(t, `location:${n.location}`, e.rid);
		if (!r || !i) return null;
		let o = e.rid === "$koto" ? "#b84942" : a[(t.member(e.rid ?? "")?.colorIndex ?? 0) % a.length].hex;
		return {
			ms: $(t),
			node: /* @__PURE__ */ m(g, {
				from: Q(r),
				to: Q(i),
				ms: $(t) - 25,
				children: /* @__PURE__ */ m("span", {
					style: { fontSize: 25 },
					children: /* @__PURE__ */ m(X, {
						color: o,
						helper: n.helper
					})
				})
			})
		};
	},
	upgrade(e, t) {
		let n = e.data, r = Z(t, `card:${n.uid}`, e.rid);
		return r ? {
			ms: $(t),
			node: /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(_, {
				at: r,
				ms: $(t)
			}), /* @__PURE__ */ m(g, {
				from: Q(r, 12, 12),
				to: Q(r, 52, 52),
				ms: $(t) - 25,
				children: /* @__PURE__ */ m("span", {
					style: { fontSize: 36 },
					children: /* @__PURE__ */ m(_t, {})
				})
			})] })
		} : null;
	},
	path(e, t) {
		let n = e.data, r = Z(t, n.from ? `path:${n.from}` : "path", e.rid), i = Z(t, n.n ? `path:${n.n}` : "path", e.rid);
		if (!r || !i) return null;
		let o = e.rid === "$koto" ? "#b84942" : a[(t.member(e.rid ?? "")?.colorIndex ?? 0) % a.length].hex;
		return {
			ms: $(t),
			node: /* @__PURE__ */ m(g, {
				from: Q(r),
				to: Q(i),
				ms: $(t) - 30,
				children: /* @__PURE__ */ m("span", {
					style: { fontSize: 25 },
					children: /* @__PURE__ */ m(X, { color: o })
				})
			})
		};
	},
	artifact(e, t) {
		let n = e.data, r = Z(t, "artifacts", e.rid), i = Z(t, `artifacts:${e.rid}`, e.rid);
		return !r || !i ? null : {
			ms: $(t),
			node: /* @__PURE__ */ m(g, {
				from: Q(r, 50, 50),
				to: Q(i, 50, 50),
				ms: $(t) - 30,
				children: /* @__PURE__ */ m("span", {
					style: {
						background: "#e9d4a4",
						border: "2px solid #a79d62",
						borderRadius: "50%",
						display: "grid",
						placeItems: "center",
						width: 50,
						height: 50
					},
					children: /* @__PURE__ */ m(St, { id: n.id })
				})
			})
		};
	}
};
//#endregion
//#region src/games/everdell-emerland/game-over.tsx
function jt({ public: e, private: t, result: r, members: i, myRid: a, hintCount: o, onPlayAgain: s, onBackToLobby: c }) {
	let u = e, d = t, { text: f, locale: g } = mt(), [_, ee] = n(!0), [te, ne] = n(null), y = (e) => {
		let t = i.find((t) => t.rid === e);
		return e === "$koto" ? f("koto") : t ? l(t, g) : f("nameFallback");
	}, b = [...r.ranking.map((e) => u.players.find((t) => t.rid === e)), ...u.koto ? [u.koto.player] : []];
	return /* @__PURE__ */ h("div", {
		className: "em-game em-result",
		children: [
			/* @__PURE__ */ m(wt, {
				pub: u,
				priv: d,
				members: i,
				myRid: a,
				send: () => {},
				readOnly: !0
			}),
			r.winner.includes(a) && /* @__PURE__ */ m(v, {}),
			/* @__PURE__ */ h("div", {
				className: "em-result-overlay",
				hidden: !_,
				children: [
					/* @__PURE__ */ h("header", {
						className: "em-result-header",
						children: [
							/* @__PURE__ */ m(_t, {}),
							/* @__PURE__ */ m("h1", { children: f("final") }),
							/* @__PURE__ */ m("p", { children: f(u.koto && !r.winner.length ? "defeat" : "victory") }),
							/* @__PURE__ */ m("b", { children: r.winner.map(y).join(" · ") })
						]
					}),
					/* @__PURE__ */ h("div", {
						className: "em-result-body",
						children: [/* @__PURE__ */ m("div", {
							className: "em-score-scroll",
							children: /* @__PURE__ */ h("table", {
								className: "em-score-table",
								children: [
									/* @__PURE__ */ m("thead", { children: /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
										scope: "col",
										children: "❦"
									}), b.map((e) => /* @__PURE__ */ h("th", {
										scope: "col",
										children: [r.winner.includes(e.rid) ? "♕ " : "", y(e.rid)]
									}, e.rid))] }) }),
									/* @__PURE__ */ m("tbody", { children: [
										["cards", "cardsScore"],
										["prosperity", "prosperity"],
										["points", "points"],
										["artifacts", "artifacts"],
										["path", "pathScore"],
										["realms", "realms"],
										["resources", "resourcesScore"]
									].map(([e, t]) => /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
										scope: "row",
										children: f(t)
									}), b.map((t) => /* @__PURE__ */ m("td", { children: t.score[e] }, t.rid))] }, e)) }),
									/* @__PURE__ */ m("tfoot", { children: /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
										scope: "row",
										children: f("total")
									}), b.map((e) => /* @__PURE__ */ m("td", { children: e.score.total }, e.rid))] }) })
								]
							})
						}), /* @__PURE__ */ h("div", {
							className: "em-result-badges",
							children: [o !== void 0 && /* @__PURE__ */ m("span", { children: f("hintCount", { n: o }) }), b.map((e) => r.autopilot?.[e.rid] ? /* @__PURE__ */ h("span", { children: [
								y(e.rid),
								" · ",
								f("autopilot", { n: Math.round(r.autopilot[e.rid] * 100) })
							] }, e.rid) : null)]
						})]
					}),
					/* @__PURE__ */ m("footer", {
						className: "em-result-controls",
						children: te ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("button", {
							type: "button",
							className: "em-choice",
							onClick: () => ne(null),
							children: f("cancel")
						}), /* @__PURE__ */ h("button", {
							type: "button",
							className: "em-choice em-primary danger-stripes",
							onClick: () => te === "again" ? s?.() : c?.(),
							children: [
								f("confirm"),
								" · ",
								f(te)
							]
						})] }) : /* @__PURE__ */ h(p, { children: [
							/* @__PURE__ */ m("button", {
								type: "button",
								className: "em-choice",
								onClick: () => ee(!1),
								children: f("overview")
							}),
							s && /* @__PURE__ */ m("button", {
								type: "button",
								className: "em-choice em-primary",
								onClick: () => ne("again"),
								children: f("again")
							}),
							c && /* @__PURE__ */ m("button", {
								type: "button",
								className: "em-choice",
								onClick: () => ne("back"),
								children: f("back")
							}),
							!s && !c && /* @__PURE__ */ m("span", { children: f("waitHost") })
						] })
					})
				]
			}),
			!_ && /* @__PURE__ */ m("button", {
				type: "button",
				className: "em-result-reopen em-choice",
				onClick: () => ee(!0),
				children: f("showResult")
			})
		]
	});
}
//#endregion
//#region src/games/everdell-emerland/options.tsx
function Mt({ value: e, onChange: t }) {
	let { text: n } = mt(), r = E.safeParse(e), i = r.success ? r.data : E.parse(void 0);
	return /* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m(te, {
		title: n("soloDifficulty"),
		children: ["normal", "hard"].map((e) => /* @__PURE__ */ m(ee, {
			name: "emerland-difficulty",
			value: e,
			checked: i.soloDifficulty === e,
			label: n(e),
			hint: n("onlySolo"),
			accent: T.accent,
			onChange: () => t({
				...i,
				soloDifficulty: e
			})
		}, e))
	}), /* @__PURE__ */ m(ne, {
		checked: i.tricks,
		label: n("tricks"),
		hint: n("tricksHint"),
		accent: T.accent,
		onChange: () => t({
			...i,
			tricks: !i.tricks
		})
	})] });
}
//#endregion
//#region src/games/everdell-emerland/guide.tsx
function Nt() {
	let { lang: e, text: t } = mt();
	return /* @__PURE__ */ m("article", {
		style: {
			display: "grid",
			gap: 16,
			lineHeight: 1.7
		},
		children: /* @__PURE__ */ h("div", {
			style: {
				display: "flex",
				gap: 12,
				flexWrap: "wrap"
			},
			children: [
				ae[e].map((e, t) => /* @__PURE__ */ h("span", { children: [
					/* @__PURE__ */ m(gt, { index: t }),
					" ",
					e
				] }, e)),
				/* @__PURE__ */ h("span", { children: [
					/* @__PURE__ */ m(_t, {}),
					" ",
					t("upgraded")
				] }),
				/* @__PURE__ */ h("span", { children: [
					/* @__PURE__ */ m(vt, {}),
					" ",
					t("harps")
				] }),
				/* @__PURE__ */ h("span", { children: [
					/* @__PURE__ */ m(X, { color: "#4e8154" }),
					" ",
					t("workers")
				] }),
				/* @__PURE__ */ h("span", { children: [
					/* @__PURE__ */ m(X, {
						color: "#4e8154",
						helper: !0
					}),
					" ",
					t("helpers")
				] })
			]
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/everdell-emerland/entry.tsx
var Pt = {
	definition: dt,
	View: Ct,
	bot: Dt,
	describe: Ot,
	fx: At,
	OverView: jt,
	Options: Mt,
	Guide: Nt,
	locales: {
		zh: ft,
		en: {
			discardCount: "{{n}} discarded",
			name: "Everdell Emerland",
			desc: "Build a tropical jungle city, enlist clever Helpers and uncover the artifacts of a lost civilization.",
			rules: "Goal and setup: For 1–4 players. Begin in summer with 2 Workers, 2 Helpers, an Archaeologist and 1 emerald. Deal 3, 4, 5 or 6 cards in turn order; solo starts with 4. The hand limit is 6 and the city has 12 spaces, plus 1 per Realm. Duplicates are allowed. Postal Pigeon and upgraded Nightwatch take no space. Maintain 6 different Plateau names, stacking duplicates. Refill at turn end; shuffle discards when the deck runs out.\nTurns: Choose one action on your turn:\n· Place a Worker.\n· Place a Helper.\n· Play a card.\n· Use an Artisan.\n· Excavate.\n· Prepare for season.\nAn occupied green board location requires a Helper as negotiator. Another Helper may guide, doubling its reward. Each Fountain permits only one of your Workers, with no guides. Your red Critters accept one Worker or Helper. Red Constructions have separate owner and visitor spaces. Visitors award the owner 1 point, or 2 when upgraded. No negotiating or guiding on Destination cards.\nHelpers and cards: Send a Helper to one of these locations:\n· Upgrade: pay 1 emerald to upgrade a city card.\n· Mooring: draw 2 cards or copy 1 Market die.\nPlay cards from hand or Plateau by paying resources. Alternatively, place a harp on your upgraded Construction to play any Critter free on its upgraded side. Only one harp per Construction color. Resolve the newly played Production or Traveler, then existing Governance triggers. All card abilities are optional.\nUpgrades and Artisans: Upgrades add 1 printed point. Production and Traveler cards activate immediately. Occupied Destinations may activate again, owner first; a visitor choosing to activate awards the owner the upgraded visitor points. To use an Artisan, tuck a hand card beneath it and activate it as your turn. Most hold 2 tucked cards; Academy and Map Shop hold 1.\nExcavation: Move one step, paying 1, 1, 2, 2 or 2 ordinary resources in order; the final step also costs 1 emerald. Discard at least one hand card. Draw one artifact per discarded card plus bonuses, keep only one and return the rest. Claim the highest remaining point pile at the space. Summer permits step 1, autumn 2, winter 3 and spring 5. Lost City spaces score 7, 5, 3 or 2 in arrival order. Resolve the kept artifact reward. A chest grants another artifact. No movement beyond the Lost City.\nSeasons and ending: Prepare once all your Workers are deployed, or no legal Worker placement is possible. Unused Helpers are allowed. Retrieve all your Workers and Helpers. Seasonal rewards are:\n· Autumn: gain 1 Helper and activate all your Production in your chosen order.\n· Winter: gain 1 Worker and 1 emerald, discard the entire Plateau, then refill it.\n· Spring: gain 2 Workers, 1 Helper and a Production round.\nThe first to enter each season rerolls all 4 dice. In spring you may finish your game. You stop acting and gaining resources, while deployed pieces remain.\nScoring: Add the following scores:\n· Printed city-card points.\n· Prosperity bonuses.\n· Point tokens.\n· Artifacts.\n· Lost City position.\n· Realms.\n· Leftover resources: 1 point per 2, including emeralds.\nMost points wins. Ties compare upgraded cards, path position, Realms and resources, then share victory.\nSolo Professor: Use two-player setup. Koto starts and has 4, 5, 6 and 9 interchangeable Workers each season. Resolve Expeditions until all are deployed, then Excavations to build his fixed 15-card city. Match the current season first, then later seasons cyclically. A first failure triggers New Plan; all failures trigger Last Resort. Ignore his card abilities and ordinary resources. He gains emeralds, points, Realms and artifacts. After you advance season, he follows once all his Workers are deployed. With 15 cards and all spring Workers placed, he finishes and moves directly to the best vacant Lost City space, taking points and an artifact for every passed step. The Professor scores the following amounts in normal and hard difficulty:\n· Base score: 10 points in normal, 15 in hard.\n· Each Prosperity card: 3 points in normal, 4 in hard.\n· Each upgrade: 2 points in normal, 3 in hard.\n· Each Realm: 4 points in normal, 5 in hard.\n· Each emerald: 1 point in normal, 2 in hard.\nAdd points from tokens, artifacts and the Lost City. You must strictly exceed his score. Optional Tricks occur on his season changes and 15th card; hard also triggers one per excavation.\nDigital rulings: A copy chain cannot repeat a card name, preventing infinite loops. Every player clears the Plateau when entering winter. Koto follows an already advanced human season once his Workers are all deployed. Inspect cards for complete basic and upgraded abilities.",
			plateau: "Plateau",
			board: "River & Fountains",
			city: "City",
			journey: "Lost City",
			hand: "Hand",
			deck: "Deck",
			discardPile: "Discard",
			artifacts: "Artifacts",
			realms: "Realms",
			workers: "Workers",
			helpers: "Helpers",
			harps: "Harps",
			points: "Point tokens",
			score: "Current score",
			capacity: "City spaces",
			season: "Prepare for season",
			end: "Finish your game",
			ended: "Finished",
			choose: "Confirm choice",
			close: "Close",
			inspect: "Inspect card",
			activate: "Activate ability",
			skip: "Skip this ability",
			cancel: "Back",
			finish: "Finish discarding",
			draw: "Draw from deck",
			copyDie: "Choose a Market die",
			emerald: "Gain 1 emerald",
			freePlay: "Pay 1 emerald to play free",
			payEmerald: "Pay 1 emerald",
			allowSteal: "Let Koto take an artifact",
			play: "Play this card",
			artisan: "Use Artisan",
			excavate: "Excavate",
			helper: "Place a Helper",
			place: "Place a Worker",
			payment: "Choose a payment",
			resource: "Choose a resource to gain",
			payResource: "Choose a resource to pay",
			discard: "Choose a hand card to discard",
			dice: "Choose different Market dice",
			mooring: "Choose a Mooring reward",
			upgrade: "Choose a card to upgrade",
			realm: "Choose a Realm",
			artifact: "Choose an artifact to keep",
			plateauPrompt: "Take a Plateau card",
			copy: "Choose a card to activate",
			production: "Choose the next Production card",
			retrieveHarp: "Choose a harp to retrieve",
			retrieveWorker: "Choose a Worker to retrieve",
			discardArtifact: "Choose an artifact to exchange",
			copyLocation: "Choose an occupied location to activate",
			workshop: "Choose a Gem Workshop reward",
			playOffer: "Choose a card to play",
			turn: "Choose your turn action",
			kotoRed: "Choose a Construction for Koto to visit",
			stealChoice: "Choose the lowest-value artifact to give Koto",
			stealOrPay: "Pay an emerald to protect your artifact?",
			waiting: "Waiting for {{name}}",
			resolving: "Resolving",
			koto: "Professor Koto",
			normal: "Normal",
			hard: "Hard",
			soloDifficulty: "Solo difficulty",
			tricks: "Koto’s Tricks",
			tricksHint: "Add Trick cards in solo. Hard mode also triggers Tricks when Koto excavates.",
			onlySolo: "Affects solo games only",
			pay: "Pay resources",
			free: "Play free",
			harp: "Use a Construction harp space",
			discountDiscard: "Discard a hand card for a discount",
			negotiator: "Negotiator",
			guide: "Guide: double reward",
			night: "Discard a card instead of a negotiator",
			helperCost: "Bring {{n}} Helpers",
			noCost: "No resources",
			fromHand: "Play from hand",
			fromPlateau: "Play from Plateau",
			building: "Construction",
			critter: "Critter",
			basic: "Basic side",
			upgraded: "Upgraded side",
			upgradePreview: "Upgraded ability",
			tucked: "Tucked cards",
			visitors: "Visitors",
			owner: "Owner",
			unavailable: "Not available now",
			details: "View details",
			market: "Market dice",
			any: "Any ordinary resource",
			drawPoint: "Draw 1 card and gain 1 point",
			removedDie: "Removed this season",
			final: "Song of the Jungle",
			victory: "Your city flourishes",
			defeat: "The Professor’s expedition prevails",
			overview: "View the final table",
			showResult: "Return to scores",
			again: "Play again",
			back: "Back to lobby",
			waitHost: "Waiting for the host",
			cardsScore: "City printed points",
			prosperity: "Prosperity bonuses",
			pathScore: "Lost City",
			resourcesScore: "Leftover resources",
			total: "Total",
			hintCount: "Hints used: {{n}}",
			autopilot: "Autopilot: {{n}}%",
			confirmEnd: "You cannot act again after finishing. Finish your game?",
			confirmSeason: "Retrieve your Workers and Helpers and enter the next season.",
			expedition: "Expedition",
			excavation: "Excavation",
			trick: "Trick",
			lostCity: "Lost City",
			pathCost: "Pay {{n}} resources and discard at least 1 card",
			confirm: "Confirm",
			inspectEmpty: "No city cards yet",
			noHand: "Your hand is empty",
			used: "Used",
			nameFallback: "Explorer",
			"error.finished": "This game has finished.",
			"error.turn": "Please wait for your action.",
			"error.choice": "That choice is no longer available. Choose again."
		}
	}
};
//#endregion
export { Pt as default };
