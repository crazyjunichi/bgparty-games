import { z as e } from "zod";
import { AVATARS as t } from "@bgparty/sdk/avatars";
import { useId as n, useMemo as r, useState as i } from "react";
import { createPortal as a } from "react-dom";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { useT as s } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as c } from "@bgparty/sdk/player-colors";
import { Texture as l } from "@bgparty/sdk/texture";
import { useWakeLock as u } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
//#region src/games/seti/project-cards.ts
var h = (e, t = 1) => ({
	kind: "gain",
	resource: e,
	n: t
}), g = (e = 1) => ({
	kind: "draw",
	n: e
}), _ = (e = 1) => ({
	kind: "move",
	n: e
}), v = { kind: "launch" }, ee = {
	kind: "scan",
	todo: []
}, y = (e) => ({
	kind: "research",
	family: e
}), te = (e, t = !1) => ({
	kind: "trace",
	color: e,
	requireOwn: t
}), b = (e, t = 1, n = !1, r = !1) => ({
	kind: "targetSignal",
	target: e,
	n: t,
	noData: n,
	adjacent: r
}), x = (e = 1) => [{
	kind: "rowSignals",
	n: e,
	sectors: []
}, { kind: "refill" }], S = (e) => ({
	kind: "project",
	id: e
}), C = (e, t, n = 1, r) => ({
	metric: {
		kind: e,
		target: t,
		color: r
	},
	atLeast: n
}), w = (e, ...t) => ({
	condition: e,
	rewards: [t]
}), T = (e, t, n) => n ? {
	events: n.map((t) => ({
		kind: e,
		target: t
	})),
	rewards: t
} : {
	event: { kind: e },
	rewards: t
}, E = {
	1: {
		effects: [],
		mission: T("visit", [[h("data")], [h("vp", 4)]], ["jupiter", "saturn"])
	},
	2: {
		effects: [],
		mission: T("visit", [[g()], [h("publicity")]], ["mercury", "venus"])
	},
	3: {
		effects: [],
		mission: T("visit", [[h("energy")], [h("credit")]], ["uranus", "neptune"])
	},
	4: {
		effects: [],
		mission: T("visit", [[h("publicity")], [h("data")]], ["venus", "jupiter"])
	},
	5: {
		effects: [v, h("publicity")],
		mission: w(C("figure", "venus"), h("vp", 7), h("publicity"))
	},
	6: {
		effects: [v, h("data")],
		mission: w(C("figure", "jupiter"), h("vp", 7), h("publicity"))
	},
	7: {
		effects: [v, _()],
		mission: w(C("figure", "mercury"), h("vp", 7), h("publicity"))
	},
	8: {
		effects: [v, g()],
		mission: w(C("figure", "saturn"), h("vp", 6), h("publicity"))
	},
	9: { effects: [
		{
			kind: "launch",
			ignoreLimit: !0
		},
		{
			kind: "launch",
			ignoreLimit: !0
		},
		h("publicity")
	] },
	10: {
		effects: [y("probe")],
		mission: w({
			...C("figure", "neptune"),
			all: [C("figure", "uranus")]
		}, h("vp", 5), g())
	},
	11: { effects: [S(11)] },
	12: {
		effects: [{
			kind: "land",
			override: !1,
			moonAccess: !0
		}],
		score: {
			metric: {
				kind: "figure",
				target: "jupiter"
			},
			multiplier: 3
		}
	},
	13: { effects: [{
		kind: "land",
		override: !1
	}, S(13)] },
	14: {
		effects: [h("publicity"), h("data", 2)],
		score: {
			metric: {
				kind: "figure",
				target: "mars"
			},
			multiplier: 4
		}
	},
	15: { effects: [{ kind: "removeOrbiter" }] },
	16: { effects: [{
		kind: "land",
		override: !0
	}] },
	17: { effects: [S(17)] },
	18: { effects: [{
		kind: "if",
		condition: C("probeTerrain", "asteroid"),
		effects: [te("yellow")]
	}] },
	19: { effects: [S(19), _(2)] },
	20: { effects: [_(2), {
		kind: "if",
		condition: C("visit", "mercury"),
		effects: [h("vp", 4)]
	}] },
	21: { effects: [_(2), {
		kind: "if",
		condition: C("visit", "venus"),
		effects: [h("vp", 3)]
	}] },
	22: { effects: [_(2), {
		kind: "if",
		condition: C("visit", "mars"),
		effects: [h("vp", 4)]
	}] },
	23: { effects: [_(2), {
		kind: "if",
		condition: C("visit", "jupiter"),
		effects: [h("vp", 4)]
	}] },
	24: { effects: [_(3), {
		kind: "if",
		condition: C("visit", "saturn"),
		effects: [h("vp", 6)]
	}] },
	25: { effects: [S(25), _(4)] },
	26: { effects: [S(26), _(2)] },
	27: { effects: [_(), b("probe")] },
	28: { effects: [_(), b("probe", 2)] },
	29: { effects: [_(), b("probe", 1, !1, !0)] },
	30: { effects: [b("anyProbe", 3)] },
	31: {
		effects: [v, _()],
		mission: w(C("lander", "planet", 3), h("credit"))
	},
	32: {
		effects: [b("mercury", 2)],
		mission: w(C("figure", "mercury"), h("vp", 4))
	},
	33: {
		effects: [b("venus", 2)],
		mission: w(C("figure", "venus"), h("vp", 4))
	},
	34: {
		effects: [b("mars", 2)],
		mission: w(C("figure", "mars"), h("vp", 4))
	},
	35: {
		effects: [b("jupiter", 2)],
		mission: w(C("figure", "jupiter"), h("vp", 4))
	},
	36: {
		effects: [b("saturn", 2)],
		mission: w(C("figure", "saturn"), h("vp", 4))
	},
	37: {
		effects: [b("proxima", 2)],
		mission: w(C("wins", "proxima", 2), h("vp", 4), h("publicity"))
	},
	38: {
		effects: [b("barnard", 2)],
		score: {
			metric: {
				kind: "wins",
				target: "barnard"
			},
			multiplier: 3
		}
	},
	39: {
		effects: [b("virginis", 2)],
		mission: w(C("wins", "virginis", 2), h("vp", 4), h("publicity"))
	},
	40: {
		effects: [b("kepler", 2)],
		score: {
			metric: {
				kind: "wins",
				target: "kepler"
			},
			multiplier: 3
		}
	},
	41: {
		effects: [b("sirius", 2)],
		mission: w(C("wins", "sirius", 2), h("vp", 4), h("publicity"))
	},
	42: {
		effects: [b("procyon", 2)],
		score: {
			metric: {
				kind: "wins",
				target: "procyon"
			},
			multiplier: 3
		}
	},
	43: {
		effects: [b("pictoris")],
		mission: w(C("wins", "pictoris"), h("vp", 2), h("publicity"))
	},
	44: {
		effects: [b("vega")],
		score: {
			metric: {
				kind: "wins",
				target: "vega"
			},
			multiplier: 3
		}
	},
	45: { effects: [...x(2), S(45)] },
	46: { effects: [...x(2), S(46)] },
	47: { effects: [...x(2), S(47)] },
	48: { effects: [_(), b("red")] },
	49: { effects: [_(), b("yellow")] },
	50: { effects: [...x(3), {
		kind: "scoreActionSignals",
		unique: !0
	}] },
	51: {
		effects: [h("data"), ee],
		mission: w(C("resource", "publicity", 8), h("vp", 3), g())
	},
	52: { effects: [ee, {
		kind: "scoreActionSignals",
		color: "red"
	}] },
	53: { effects: [ee, {
		kind: "scoreActionSignals",
		color: "yellow"
	}] },
	54: { effects: [ee, {
		kind: "scoreActionSignals",
		color: "blue"
	}] },
	55: { effects: [ee, b("any")] },
	56: { effects: [_(), b("blue")] },
	57: { effects: [g(), y("telescope")] },
	58: {
		effects: [v],
		mission: w(C("figure", "uranus"), h("vp", 3), g())
	},
	59: { effects: [h("energy"), y("probe")] },
	60: {
		effects: [v],
		mission: w(C("figure", "neptune"), h("vp", 4), h("data"))
	},
	61: {
		effects: [y("computer")],
		mission: w(C("resource", "vp", 50), { kind: "income" })
	},
	62: {
		effects: [y("telescope")],
		score: {
			metric: {
				kind: "trace",
				color: "red"
			},
			multiplier: 2
		}
	},
	63: {
		effects: [y("probe")],
		score: {
			metric: {
				kind: "trace",
				color: "yellow"
			},
			multiplier: 2
		}
	},
	64: {
		effects: [y("computer")],
		mission: w(C("traceSpecies", void 0, 2, "blue"), h("data", 2))
	},
	65: { effects: [...x(2), y("telescope")] },
	66: {
		effects: [y("telescope")],
		mission: w(C("traceSpecies", void 0, 2, "red"), h("vp", 2), h("energy"))
	},
	67: { effects: [
		h("publicity"),
		y("telescope"),
		{
			kind: "handSignal",
			optional: !0
		}
	] },
	68: {
		effects: [y("computer")],
		score: {
			metric: {
				kind: "trace",
				color: "blue"
			},
			multiplier: 2
		}
	},
	69: { effects: [h("data"), y("computer")] },
	70: {
		effects: [y("computer")],
		mission: w(C("trace", void 0, 3, "blue"), h("vp", 3), h("data"))
	},
	71: { effects: [y("any"), { kind: "techScore" }] },
	72: { effects: [y("any"), S(72)] },
	73: { effects: [S(73)] },
	74: { effects: [v, S(74)] },
	75: { effects: [S(75)] },
	76: {
		effects: [],
		mission: T("research", [
			[h("energy")],
			[h("publicity")],
			[g()]
		], [
			"probe",
			"telescope",
			"computer"
		])
	},
	77: {
		effects: [h("publicity")],
		mission: T("trace", [
			[h("data")],
			[h("data")],
			[h("data")]
		], [
			"red",
			"yellow",
			"blue"
		])
	},
	78: {
		effects: [h("publicity")],
		mission: T("scan", [
			[h("data", 2)],
			[g()],
			[h("vp", 4)]
		])
	},
	79: {
		effects: [h("publicity")],
		mission: T("launch", [
			[h("credit")],
			[g()],
			[h("vp", 5)]
		])
	},
	80: {
		effects: [],
		mission: {
			event: { kind: "launch" },
			rewards: [
				[_()],
				[_()],
				[_()]
			]
		}
	},
	81: { effects: [{
		kind: "research",
		family: "any",
		rotated: !0,
		collaboration: !0
	}] },
	82: {
		effects: [],
		mission: {
			events: [{ kind: "orbit" }, { kind: "land" }],
			rewards: [[h("publicity", 2)], [h("publicity", 2)]]
		}
	},
	83: { effects: [h("publicity"), b("earth", 2)] },
	84: { effects: [{ kind: "removeLander" }] },
	85: { effects: [v, y("probe")] },
	86: {
		effects: x(),
		score: {
			metric: { kind: "signalSectors" },
			multiplier: 1
		}
	},
	87: {
		effects: [y("probe")],
		mission: w(C("distantProbe", void 0, 5), h("vp", 3), h("energy"))
	},
	88: {
		effects: [b("probe", 2)],
		mission: w(C("signalSectors", void 0, 4), h("publicity", 2))
	},
	89: {
		effects: [g(3)],
		mission: w({
			metric: { kind: "hand" },
			atMost: 0
		}, g())
	},
	90: { effects: [{
		kind: "metricGain",
		metric: {
			kind: "hand",
			target: "energy"
		},
		resource: "energy",
		multiplier: 1
	}] },
	91: { effects: [{
		kind: "metricGain",
		metric: {
			kind: "income",
			target: "energy"
		},
		resource: "energy",
		multiplier: 1
	}, S(91)] },
	92: { effects: [
		h("publicity", 2),
		{
			kind: "metricGain",
			metric: {
				kind: "income",
				target: "card"
			},
			resource: "publicity",
			multiplier: 1
		},
		S(92)
	] },
	93: { effects: [{
		kind: "metricGain",
		metric: {
			kind: "income",
			target: "credit"
		},
		resource: "vp",
		multiplier: 3
	}, S(93)] },
	94: {
		effects: [h("publicity")],
		mission: T("research", [
			[h("publicity", 2)],
			[h("publicity", 2)],
			[h("publicity", 2)]
		], [
			"probe",
			"telescope",
			"computer"
		])
	},
	95: {
		effects: [h("publicity", 2)],
		mission: w(C("probeTerrain", "earthAsteroid"), h("vp", 5), g())
	},
	96: {
		effects: [
			h("publicity"),
			h("data"),
			g()
		],
		mission: w(C("trace", void 0, 3, "yellow"), te("yellow"))
	},
	97: {
		effects: [y("probe")],
		mission: w(C("traceSpecies", void 0, 2, "yellow"), h("vp", 2), g())
	},
	98: { effects: [te("red", !0)] },
	99: { effects: [te("yellow", !0)] },
	100: { effects: [te("blue", !0)] },
	101: {
		effects: [],
		mission: T("scan", [
			[b("yellow")],
			[b("red")],
			[b("blue")]
		])
	},
	102: {
		effects: [h("publicity", 3)],
		mission: w(C("traceSet"), S(102))
	},
	103: {
		effects: [y("telescope")],
		mission: w(C("wins", "same", 2), h("vp", 9))
	},
	104: {
		effects: [v],
		mission: w(C("probeTerrain", "comet"), h("vp", 3), h("data"))
	},
	105: {
		effects: [ee],
		mission: w(C("trace", void 0, 3, "red"), te("red"))
	},
	106: {
		effects: [],
		mission: T("pay", [
			[h("vp", 2)],
			[g()],
			[h("publicity", 2)]
		], [
			"1",
			"2",
			"3"
		])
	},
	107: {
		effects: [h("data", 2)],
		mission: {
			event: {
				kind: "trace",
				target: "blue"
			},
			rewards: [[h("publicity", 2)], [h("vp", 4)]]
		}
	},
	108: { effects: [{
		kind: "if",
		condition: C("resource", "publicity", 8),
		effects: [te("red")]
	}] },
	109: { effects: [h("energy"), y("computer")] },
	110: { effects: [h("publicity", 3)] },
	111: {
		effects: [y("telescope")],
		mission: w(C("orbiter", void 0, 2), h("data", 2))
	},
	112: {
		effects: [y("probe")],
		mission: w(C("pairedFigures"), h("vp", 3), h("data"))
	},
	113: {
		effects: [h("publicity", 2)],
		keep: !0
	},
	114: { effects: [
		g(),
		{
			kind: "handSignal",
			optional: !0
		},
		{
			kind: "handSignal",
			optional: !0
		},
		{
			kind: "handSignal",
			optional: !0
		}
	] },
	115: {
		effects: [b("any")],
		mission: w(C("tech", "telescope", 3), h("data"))
	},
	116: {
		effects: [],
		mission: T("signal", [
			[_()],
			[_()],
			[_()]
		], [
			"yellow",
			"red",
			"blue"
		])
	},
	117: {
		effects: [v],
		mission: {
			event: { kind: "land" },
			rewards: [[v], [h("energy")]]
		}
	},
	118: { effects: [b("probe", 3, !0)] },
	119: { effects: [y("computer"), { kind: "publicityScore" }] },
	120: { effects: [b("probe"), S(120)] },
	121: { effects: [h("data", 3), y("computer")] },
	122: { effects: [
		S(122),
		S(122),
		S(122)
	] },
	123: { effects: [_(), {
		kind: "if",
		condition: C("visit", "asteroid"),
		effects: [h("data")]
	}] },
	124: { effects: [_(2), {
		kind: "if",
		condition: C("visit", "comet"),
		effects: [h("vp", 4)]
	}] },
	125: { effects: [_(), {
		kind: "if",
		condition: C("sameRing"),
		effects: [h("vp", 3), h("publicity")]
	}] },
	126: {
		effects: [y("space")],
		score: {
			metric: {
				kind: "tech",
				target: "computer"
			},
			multiplier: 2
		}
	},
	127: {
		effects: [h("publicity", 2)],
		score: {
			metric: {
				kind: "probeTerrain",
				target: "asteroid"
			},
			multiplier: 13,
			minimum: 1
		}
	},
	128: {
		effects: [],
		mission: {
			event: {
				kind: "visit",
				target: "planet"
			},
			rewards: [
				[h("energy")],
				[h("data")],
				[_()]
			]
		}
	},
	129: {
		effects: [],
		mission: {
			event: {
				kind: "visit",
				target: "asteroid"
			},
			rewards: [
				[h("data")],
				[h("data")],
				[h("data")]
			]
		}
	},
	130: { effects: [v] },
	131: {
		effects: [g()],
		mission: {
			events: [{
				kind: "research",
				target: "telescope"
			}, { kind: "scan" }],
			rewards: [[h("publicity")], [h("data")]]
		}
	},
	132: {
		effects: [v, h("publicity", 2)],
		mission: w(C("figure", void 0, 5), h("vp", 3), h("credit"))
	},
	133: { effects: [v, { kind: "launchWindow" }] },
	134: {
		effects: [b("probe")],
		mission: w(C("signalSectors", void 0, 4), h("publicity", 2))
	},
	135: { effects: [h("publicity"), ee] },
	136: { effects: [
		b("yellow", 1, !0),
		b("red", 1, !0),
		b("blue", 1, !0),
		b("black", 1, !0)
	] },
	137: { effects: [h("data", 2)] },
	138: {
		effects: [],
		mission: T("discard", [
			[h("publicity")],
			[h("data")],
			[_()]
		], [
			"publicity",
			"data",
			"move"
		])
	}
}, ne = [
	{
		id: 1,
		name: "games.seti.projects.p1",
		text: "games.seti.projects.p1Text",
		cost: 0,
		color: "yellow",
		free: "move",
		income: "energy",
		...E[1]
	},
	{
		id: 2,
		name: "games.seti.projects.p2",
		text: "games.seti.projects.p2Text",
		cost: 0,
		color: "blue",
		free: "move",
		income: "credit",
		...E[2]
	},
	{
		id: 3,
		name: "games.seti.projects.p3",
		text: "games.seti.projects.p3Text",
		cost: 0,
		color: "yellow",
		free: "move",
		income: "card",
		...E[3]
	},
	{
		id: 4,
		name: "games.seti.projects.p4",
		text: "games.seti.projects.p4Text",
		cost: 0,
		color: "red",
		free: "move",
		income: "card",
		...E[4]
	},
	{
		id: 5,
		name: "games.seti.projects.p5",
		text: "games.seti.projects.p5Text",
		cost: 3,
		color: "blue",
		free: "move",
		income: "credit",
		...E[5]
	},
	{
		id: 6,
		name: "games.seti.projects.p6",
		text: "games.seti.projects.p6Text",
		cost: 3,
		color: "red",
		free: "data",
		income: "energy",
		...E[6]
	},
	{
		id: 7,
		name: "games.seti.projects.p7",
		text: "games.seti.projects.p7Text",
		cost: 3,
		color: "yellow",
		free: "publicity",
		income: "card",
		...E[7]
	},
	{
		id: 8,
		name: "games.seti.projects.p8",
		text: "games.seti.projects.p8Text",
		cost: 3,
		color: "red",
		free: "publicity",
		income: "energy",
		...E[8]
	},
	{
		id: 9,
		name: "games.seti.projects.p9",
		text: "games.seti.projects.p9Text",
		cost: 3,
		color: "yellow",
		free: "move",
		income: "credit",
		...E[9]
	},
	{
		id: 10,
		name: "games.seti.projects.p10",
		text: "games.seti.projects.p10Text",
		cost: 3,
		color: "black",
		free: "data",
		income: "credit",
		...E[10]
	},
	{
		id: 11,
		name: "games.seti.projects.p11",
		text: "games.seti.projects.p11Text",
		cost: 1,
		color: "yellow",
		free: "publicity",
		income: "energy",
		...E[11]
	},
	{
		id: 12,
		name: "games.seti.projects.p12",
		text: "games.seti.projects.p12Text",
		cost: 2,
		color: "black",
		free: "publicity",
		income: "credit",
		...E[12]
	},
	{
		id: 13,
		name: "games.seti.projects.p13",
		text: "games.seti.projects.p13Text",
		cost: 1,
		color: "blue",
		free: "publicity",
		income: "card",
		...E[13]
	},
	{
		id: 14,
		name: "games.seti.projects.p14",
		text: "games.seti.projects.p14Text",
		cost: 2,
		color: "red",
		free: "move",
		income: "credit",
		...E[14]
	},
	{
		id: 15,
		name: "games.seti.projects.p15",
		text: "games.seti.projects.p15Text",
		cost: 1,
		color: "blue",
		free: "move",
		income: "credit",
		...E[15]
	},
	{
		id: 16,
		name: "games.seti.projects.p16",
		text: "games.seti.projects.p16Text",
		cost: 1,
		color: "blue",
		free: "move",
		income: "credit",
		...E[16]
	},
	{
		id: 17,
		name: "games.seti.projects.p17",
		text: "games.seti.projects.p17Text",
		cost: 1,
		color: "yellow",
		free: "move",
		income: "credit",
		...E[17]
	},
	{
		id: 18,
		name: "games.seti.projects.p18",
		text: "games.seti.projects.p18Text",
		cost: 1,
		color: "black",
		free: "move",
		income: "card",
		...E[18]
	},
	{
		id: 19,
		name: "games.seti.projects.p19",
		text: "games.seti.projects.p19Text",
		cost: 1,
		color: "yellow",
		free: "publicity",
		income: "credit",
		...E[19]
	},
	{
		id: 20,
		name: "games.seti.projects.p20",
		text: "games.seti.projects.p20Text",
		cost: 1,
		color: "red",
		free: "publicity",
		income: "energy",
		...E[20]
	},
	{
		id: 21,
		name: "games.seti.projects.p21",
		text: "games.seti.projects.p21Text",
		cost: 1,
		color: "yellow",
		free: "publicity",
		income: "credit",
		...E[21]
	},
	{
		id: 22,
		name: "games.seti.projects.p22",
		text: "games.seti.projects.p22Text",
		cost: 1,
		color: "yellow",
		free: "data",
		income: "energy",
		...E[22]
	},
	{
		id: 23,
		name: "games.seti.projects.p23",
		text: "games.seti.projects.p23Text",
		cost: 1,
		color: "blue",
		free: "publicity",
		income: "energy",
		...E[23]
	},
	{
		id: 24,
		name: "games.seti.projects.p24",
		text: "games.seti.projects.p24Text",
		cost: 2,
		color: "red",
		free: "data",
		income: "card",
		...E[24]
	},
	{
		id: 25,
		name: "games.seti.projects.p25",
		text: "games.seti.projects.p25Text",
		cost: 2,
		color: "red",
		free: "publicity",
		income: "credit",
		...E[25]
	},
	{
		id: 26,
		name: "games.seti.projects.p26",
		text: "games.seti.projects.p26Text",
		cost: 1,
		color: "blue",
		free: "data",
		income: "card",
		...E[26]
	},
	{
		id: 27,
		name: "games.seti.projects.p27",
		text: "games.seti.projects.p27Text",
		cost: 1,
		color: "red",
		free: "publicity",
		income: "card",
		...E[27]
	},
	{
		id: 28,
		name: "games.seti.projects.p28",
		text: "games.seti.projects.p28Text",
		cost: 2,
		color: "blue",
		free: "publicity",
		income: "credit",
		...E[28]
	},
	{
		id: 29,
		name: "games.seti.projects.p29",
		text: "games.seti.projects.p29Text",
		cost: 2,
		color: "yellow",
		free: "publicity",
		income: "energy",
		...E[29]
	},
	{
		id: 30,
		name: "games.seti.projects.p30",
		text: "games.seti.projects.p30Text",
		cost: 2,
		color: "yellow",
		free: "move",
		income: "card",
		...E[30]
	},
	{
		id: 31,
		name: "games.seti.projects.p31",
		text: "games.seti.projects.p31Text",
		cost: 2,
		color: "yellow",
		free: "data",
		income: "card",
		...E[31]
	},
	{
		id: 32,
		name: "games.seti.projects.p32",
		text: "games.seti.projects.p32Text",
		cost: 2,
		color: "yellow",
		free: "publicity",
		income: "credit",
		...E[32]
	},
	{
		id: 33,
		name: "games.seti.projects.p33",
		text: "games.seti.projects.p33Text",
		cost: 2,
		color: "red",
		free: "move",
		income: "energy",
		...E[33]
	},
	{
		id: 34,
		name: "games.seti.projects.p34",
		text: "games.seti.projects.p34Text",
		cost: 2,
		color: "blue",
		free: "move",
		income: "card",
		...E[34]
	},
	{
		id: 35,
		name: "games.seti.projects.p35",
		text: "games.seti.projects.p35Text",
		cost: 2,
		color: "blue",
		free: "publicity",
		income: "credit",
		...E[35]
	},
	{
		id: 36,
		name: "games.seti.projects.p36",
		text: "games.seti.projects.p36Text",
		cost: 2,
		color: "blue",
		free: "publicity",
		income: "card",
		...E[36]
	},
	{
		id: 37,
		name: "games.seti.projects.p37",
		text: "games.seti.projects.p37Text",
		cost: 2,
		color: "yellow",
		free: "move",
		income: "credit",
		...E[37]
	},
	{
		id: 38,
		name: "games.seti.projects.p38",
		text: "games.seti.projects.p38Text",
		cost: 2,
		color: "blue",
		free: "publicity",
		income: "energy",
		...E[38]
	},
	{
		id: 39,
		name: "games.seti.projects.p39",
		text: "games.seti.projects.p39Text",
		cost: 2,
		color: "blue",
		free: "move",
		income: "card",
		...E[39]
	},
	{
		id: 40,
		name: "games.seti.projects.p40",
		text: "games.seti.projects.p40Text",
		cost: 2,
		color: "red",
		free: "publicity",
		income: "credit",
		...E[40]
	},
	{
		id: 41,
		name: "games.seti.projects.p41",
		text: "games.seti.projects.p41Text",
		cost: 2,
		color: "red",
		free: "move",
		income: "energy",
		...E[41]
	},
	{
		id: 42,
		name: "games.seti.projects.p42",
		text: "games.seti.projects.p42Text",
		cost: 2,
		color: "yellow",
		free: "data",
		income: "card",
		...E[42]
	},
	{
		id: 43,
		name: "games.seti.projects.p43",
		text: "games.seti.projects.p43Text",
		cost: 1,
		color: "blue",
		free: "move",
		income: "energy",
		...E[43]
	},
	{
		id: 44,
		name: "games.seti.projects.p44",
		text: "games.seti.projects.p44Text",
		cost: 1,
		color: "red",
		free: "publicity",
		income: "credit",
		...E[44]
	},
	{
		id: 45,
		name: "games.seti.projects.p45",
		text: "games.seti.projects.p45Text",
		cost: 2,
		color: "red",
		free: "publicity",
		income: "card",
		...E[45]
	},
	{
		id: 46,
		name: "games.seti.projects.p46",
		text: "games.seti.projects.p46Text",
		cost: 2,
		color: "yellow",
		free: "move",
		income: "credit",
		...E[46]
	},
	{
		id: 47,
		name: "games.seti.projects.p47",
		text: "games.seti.projects.p47Text",
		cost: 2,
		color: "yellow",
		free: "publicity",
		income: "card",
		...E[47]
	},
	{
		id: 48,
		name: "games.seti.projects.p48",
		text: "games.seti.projects.p48Text",
		cost: 1,
		color: "blue",
		free: "publicity",
		income: "credit",
		...E[48]
	},
	{
		id: 49,
		name: "games.seti.projects.p49",
		text: "games.seti.projects.p49Text",
		cost: 1,
		color: "red",
		free: "publicity",
		income: "credit",
		...E[49]
	},
	{
		id: 50,
		name: "games.seti.projects.p50",
		text: "games.seti.projects.p50Text",
		cost: 3,
		color: "blue",
		free: "publicity",
		income: "credit",
		...E[50]
	},
	{
		id: 51,
		name: "games.seti.projects.p51",
		text: "games.seti.projects.p51Text",
		cost: 3,
		color: "red",
		free: "move",
		income: "card",
		...E[51]
	},
	{
		id: 52,
		name: "games.seti.projects.p52",
		text: "games.seti.projects.p52Text",
		cost: 2,
		color: "yellow",
		free: "move",
		income: "card",
		...E[52]
	},
	{
		id: 53,
		name: "games.seti.projects.p53",
		text: "games.seti.projects.p53Text",
		cost: 2,
		color: "blue",
		free: "move",
		income: "energy",
		...E[53]
	},
	{
		id: 54,
		name: "games.seti.projects.p54",
		text: "games.seti.projects.p54Text",
		cost: 2,
		color: "red",
		free: "move",
		income: "credit",
		...E[54]
	},
	{
		id: 55,
		name: "games.seti.projects.p55",
		text: "games.seti.projects.p55Text",
		cost: 3,
		color: "yellow",
		free: "publicity",
		income: "card",
		...E[55]
	},
	{
		id: 56,
		name: "games.seti.projects.p56",
		text: "games.seti.projects.p56Text",
		cost: 1,
		color: "yellow",
		free: "publicity",
		income: "credit",
		...E[56]
	},
	{
		id: 57,
		name: "games.seti.projects.p57",
		text: "games.seti.projects.p57Text",
		cost: 3,
		color: "blue",
		free: "publicity",
		income: "energy",
		...E[57]
	},
	{
		id: 58,
		name: "games.seti.projects.p58",
		text: "games.seti.projects.p58Text",
		cost: 2,
		color: "red",
		free: "publicity",
		income: "credit",
		...E[58]
	},
	{
		id: 59,
		name: "games.seti.projects.p59",
		text: "games.seti.projects.p59Text",
		cost: 3,
		color: "red",
		free: "publicity",
		income: "card",
		...E[59]
	},
	{
		id: 60,
		name: "games.seti.projects.p60",
		text: "games.seti.projects.p60Text",
		cost: 2,
		color: "blue",
		free: "publicity",
		income: "card",
		...E[60]
	},
	{
		id: 61,
		name: "games.seti.projects.p61",
		text: "games.seti.projects.p61Text",
		cost: 3,
		color: "black",
		free: "publicity",
		income: "card",
		...E[61]
	},
	{
		id: 62,
		name: "games.seti.projects.p62",
		text: "games.seti.projects.p62Text",
		cost: 3,
		color: "red",
		free: "data",
		income: "credit",
		...E[62]
	},
	{
		id: 63,
		name: "games.seti.projects.p63",
		text: "games.seti.projects.p63Text",
		cost: 3,
		color: "blue",
		free: "move",
		income: "credit",
		...E[63]
	},
	{
		id: 64,
		name: "games.seti.projects.p64",
		text: "games.seti.projects.p64Text",
		cost: 3,
		color: "blue",
		free: "move",
		income: "credit",
		...E[64]
	},
	{
		id: 65,
		name: "games.seti.projects.p65",
		text: "games.seti.projects.p65Text",
		cost: 4,
		color: "black",
		free: "move",
		income: "credit",
		...E[65]
	},
	{
		id: 66,
		name: "games.seti.projects.p66",
		text: "games.seti.projects.p66Text",
		cost: 3,
		color: "yellow",
		free: "publicity",
		income: "card",
		...E[66]
	},
	{
		id: 67,
		name: "games.seti.projects.p67",
		text: "games.seti.projects.p67Text",
		cost: 3,
		color: "blue",
		free: "move",
		income: "card",
		...E[67]
	},
	{
		id: 68,
		name: "games.seti.projects.p68",
		text: "games.seti.projects.p68Text",
		cost: 3,
		color: "red",
		free: "publicity",
		income: "credit",
		...E[68]
	},
	{
		id: 69,
		name: "games.seti.projects.p69",
		text: "games.seti.projects.p69Text",
		cost: 3,
		color: "black",
		free: "move",
		income: "energy",
		...E[69]
	},
	{
		id: 70,
		name: "games.seti.projects.p70",
		text: "games.seti.projects.p70Text",
		cost: 3,
		color: "red",
		free: "publicity",
		income: "credit",
		...E[70]
	},
	{
		id: 71,
		name: "games.seti.projects.p71",
		text: "games.seti.projects.p71Text",
		cost: 3,
		color: "red",
		free: "publicity",
		income: "credit",
		...E[71]
	},
	{
		id: 72,
		name: "games.seti.projects.p72",
		text: "games.seti.projects.p72Text",
		cost: 3,
		color: "blue",
		free: "data",
		income: "credit",
		...E[72]
	},
	{
		id: 73,
		name: "games.seti.projects.p73",
		text: "games.seti.projects.p73Text",
		cost: 1,
		color: "yellow",
		free: "publicity",
		income: "credit",
		...E[73]
	},
	{
		id: 74,
		name: "games.seti.projects.p74",
		text: "games.seti.projects.p74Text",
		cost: 2,
		color: "yellow",
		free: "publicity",
		income: "card",
		...E[74]
	},
	{
		id: 75,
		name: "games.seti.projects.p75",
		text: "games.seti.projects.p75Text",
		cost: 2,
		color: "black",
		free: "data",
		income: "credit",
		...E[75]
	},
	{
		id: 76,
		name: "games.seti.projects.p76",
		text: "games.seti.projects.p76Text",
		cost: 1,
		color: "blue",
		free: "move",
		income: "card",
		...E[76]
	},
	{
		id: 77,
		name: "games.seti.projects.p77",
		text: "games.seti.projects.p77Text",
		cost: 1,
		color: "yellow",
		free: "publicity",
		income: "card",
		...E[77]
	},
	{
		id: 78,
		name: "games.seti.projects.p78",
		text: "games.seti.projects.p78Text",
		cost: 2,
		color: "red",
		free: "data",
		income: "energy",
		...E[78]
	},
	{
		id: 79,
		name: "games.seti.projects.p79",
		text: "games.seti.projects.p79Text",
		cost: 2,
		color: "red",
		free: "data",
		income: "credit",
		...E[79]
	},
	{
		id: 80,
		name: "games.seti.projects.p80",
		text: "games.seti.projects.p80Text",
		cost: 1,
		color: "black",
		free: "publicity",
		income: "card",
		...E[80]
	},
	{
		id: 81,
		name: "games.seti.projects.p81",
		text: "games.seti.projects.p81Text",
		cost: 2,
		color: "yellow",
		free: "move",
		income: "card",
		...E[81]
	},
	{
		id: 82,
		name: "games.seti.projects.p82",
		text: "games.seti.projects.p82Text",
		cost: 1,
		color: "yellow",
		free: "data",
		income: "energy",
		...E[82]
	},
	{
		id: 83,
		name: "games.seti.projects.p83",
		text: "games.seti.projects.p83Text",
		cost: 2,
		color: "blue",
		free: "move",
		income: "energy",
		...E[83]
	},
	{
		id: 84,
		name: "games.seti.projects.p84",
		text: "games.seti.projects.p84Text",
		cost: 1,
		color: "blue",
		free: "publicity",
		income: "energy",
		...E[84]
	},
	{
		id: 85,
		name: "games.seti.projects.p85",
		text: "games.seti.projects.p85Text",
		cost: 4,
		color: "red",
		free: "publicity",
		income: "credit",
		...E[85]
	},
	{
		id: 86,
		name: "games.seti.projects.p86",
		text: "games.seti.projects.p86Text",
		cost: 1,
		color: "red",
		free: "publicity",
		income: "energy",
		...E[86]
	},
	{
		id: 87,
		name: "games.seti.projects.p87",
		text: "games.seti.projects.p87Text",
		cost: 3,
		color: "yellow",
		free: "move",
		income: "card",
		...E[87]
	},
	{
		id: 88,
		name: "games.seti.projects.p88",
		text: "games.seti.projects.p88Text",
		cost: 2,
		color: "blue",
		free: "move",
		income: "energy",
		...E[88]
	},
	{
		id: 89,
		name: "games.seti.projects.p89",
		text: "games.seti.projects.p89Text",
		cost: 2,
		color: "blue",
		free: "publicity",
		income: "card",
		...E[89]
	},
	{
		id: 90,
		name: "games.seti.projects.p90",
		text: "games.seti.projects.p90Text",
		cost: 1,
		color: "blue",
		free: "data",
		income: "card",
		...E[90]
	},
	{
		id: 91,
		name: "games.seti.projects.p91",
		text: "games.seti.projects.p91Text",
		cost: 3,
		color: "red",
		free: "publicity",
		income: "energy",
		...E[91]
	},
	{
		id: 92,
		name: "games.seti.projects.p92",
		text: "games.seti.projects.p92Text",
		cost: 3,
		color: "blue",
		free: "data",
		income: "card",
		...E[92]
	},
	{
		id: 93,
		name: "games.seti.projects.p93",
		text: "games.seti.projects.p93Text",
		cost: 3,
		color: "yellow",
		free: "publicity",
		income: "credit",
		...E[93]
	},
	{
		id: 94,
		name: "games.seti.projects.p94",
		text: "games.seti.projects.p94Text",
		cost: 2,
		color: "red",
		free: "data",
		income: "energy",
		...E[94]
	},
	{
		id: 95,
		name: "games.seti.projects.p95",
		text: "games.seti.projects.p95Text",
		cost: 2,
		color: "yellow",
		free: "data",
		income: "energy",
		...E[95]
	},
	{
		id: 96,
		name: "games.seti.projects.p96",
		text: "games.seti.projects.p96Text",
		cost: 2,
		color: "yellow",
		free: "move",
		income: "energy",
		...E[96]
	},
	{
		id: 97,
		name: "games.seti.projects.p97",
		text: "games.seti.projects.p97Text",
		cost: 3,
		color: "blue",
		free: "data",
		income: "energy",
		...E[97]
	},
	{
		id: 98,
		name: "games.seti.projects.p98",
		text: "games.seti.projects.p98Text",
		cost: 1,
		color: "red",
		free: "data",
		income: "energy",
		...E[98]
	},
	{
		id: 99,
		name: "games.seti.projects.p99",
		text: "games.seti.projects.p99Text",
		cost: 1,
		color: "yellow",
		free: "data",
		income: "card",
		...E[99]
	},
	{
		id: 100,
		name: "games.seti.projects.p100",
		text: "games.seti.projects.p100Text",
		cost: 1,
		color: "blue",
		free: "data",
		income: "credit",
		...E[100]
	},
	{
		id: 101,
		name: "games.seti.projects.p101",
		text: "games.seti.projects.p101Text",
		cost: 2,
		color: "black",
		free: "publicity",
		income: "energy",
		...E[101]
	},
	{
		id: 102,
		name: "games.seti.projects.p102",
		text: "games.seti.projects.p102Text",
		cost: 2,
		color: "blue",
		free: "data",
		income: "credit",
		...E[102]
	},
	{
		id: 103,
		name: "games.seti.projects.p103",
		text: "games.seti.projects.p103Text",
		cost: 3,
		color: "yellow",
		free: "data",
		income: "energy",
		...E[103]
	},
	{
		id: 104,
		name: "games.seti.projects.p104",
		text: "games.seti.projects.p104Text",
		cost: 2,
		color: "blue",
		free: "publicity",
		income: "energy",
		...E[104]
	},
	{
		id: 105,
		name: "games.seti.projects.p105",
		text: "games.seti.projects.p105Text",
		cost: 2,
		color: "black",
		free: "move",
		income: "credit",
		...E[105]
	},
	{
		id: 106,
		name: "games.seti.projects.p106",
		text: "games.seti.projects.p106Text",
		cost: 1,
		color: "yellow",
		free: "move",
		income: "credit",
		...E[106]
	},
	{
		id: 107,
		name: "games.seti.projects.p107",
		text: "games.seti.projects.p107Text",
		cost: 2,
		color: "red",
		free: "move",
		income: "energy",
		...E[107]
	},
	{
		id: 108,
		name: "games.seti.projects.p108",
		text: "games.seti.projects.p108Text",
		cost: 1,
		color: "black",
		free: "data",
		income: "credit",
		...E[108]
	},
	{
		id: 109,
		name: "games.seti.projects.p109",
		text: "games.seti.projects.p109Text",
		cost: 3,
		color: "yellow",
		free: "data",
		income: "card",
		...E[109]
	},
	{
		id: 110,
		name: "games.seti.projects.p110",
		text: "games.seti.projects.p110Text",
		cost: 1,
		color: "red",
		free: "data",
		income: "credit",
		...E[110]
	},
	{
		id: 111,
		name: "games.seti.projects.p111",
		text: "games.seti.projects.p111Text",
		cost: 3,
		color: "red",
		free: "publicity",
		income: "energy",
		...E[111]
	},
	{
		id: 112,
		name: "games.seti.projects.p112",
		text: "games.seti.projects.p112Text",
		cost: 3,
		color: "yellow",
		free: "publicity",
		income: "energy",
		...E[112]
	},
	{
		id: 113,
		name: "games.seti.projects.p113",
		text: "games.seti.projects.p113Text",
		cost: 2,
		color: "blue",
		free: "data",
		income: "card",
		...E[113]
	},
	{
		id: 114,
		name: "games.seti.projects.p114",
		text: "games.seti.projects.p114Text",
		cost: 1,
		color: "red",
		free: "publicity",
		income: "energy",
		...E[114]
	},
	{
		id: 115,
		name: "games.seti.projects.p115",
		text: "games.seti.projects.p115Text",
		cost: 1,
		color: "red",
		free: "publicity",
		income: "card",
		...E[115]
	},
	{
		id: 116,
		name: "games.seti.projects.p116",
		text: "games.seti.projects.p116Text",
		cost: 1,
		color: "black",
		free: "publicity",
		income: "card",
		...E[116]
	},
	{
		id: 117,
		name: "games.seti.projects.p117",
		text: "games.seti.projects.p117Text",
		cost: 3,
		color: "red",
		free: "publicity",
		income: "card",
		...E[117]
	},
	{
		id: 118,
		name: "games.seti.projects.p118",
		text: "games.seti.projects.p118Text",
		cost: 1,
		color: "yellow",
		free: "data",
		income: "credit",
		...E[118]
	},
	{
		id: 119,
		name: "games.seti.projects.p119",
		text: "games.seti.projects.p119Text",
		cost: 3,
		color: "blue",
		free: "data",
		income: "energy",
		...E[119]
	},
	{
		id: 120,
		name: "games.seti.projects.p120",
		text: "games.seti.projects.p120Text",
		cost: 1,
		color: "black",
		free: "move",
		income: "energy",
		...E[120]
	},
	{
		id: 121,
		name: "games.seti.projects.p121",
		text: "games.seti.projects.p121Text",
		cost: 4,
		color: "yellow",
		free: "move",
		income: "energy",
		...E[121]
	},
	{
		id: 122,
		name: "games.seti.projects.p122",
		text: "games.seti.projects.p122Text",
		cost: 2,
		color: "black",
		free: "publicity",
		income: "energy",
		...E[122]
	},
	{
		id: 123,
		name: "games.seti.projects.p123",
		text: "games.seti.projects.p123Text",
		cost: 0,
		color: "red",
		free: "publicity",
		income: "card",
		...E[123]
	},
	{
		id: 124,
		name: "games.seti.projects.p124",
		text: "games.seti.projects.p124Text",
		cost: 1,
		color: "yellow",
		free: "publicity",
		income: "energy",
		...E[124]
	},
	{
		id: 125,
		name: "games.seti.projects.p125",
		text: "games.seti.projects.p125Text",
		cost: 1,
		color: "blue",
		free: "data",
		income: "card",
		...E[125]
	},
	{
		id: 126,
		name: "games.seti.projects.p126",
		text: "games.seti.projects.p126Text",
		cost: 3,
		color: "blue",
		free: "publicity",
		income: "card",
		...E[126]
	},
	{
		id: 127,
		name: "games.seti.projects.p127",
		text: "games.seti.projects.p127Text",
		cost: 1,
		color: "yellow",
		free: "data",
		income: "credit",
		...E[127]
	},
	{
		id: 128,
		name: "games.seti.projects.p128",
		text: "games.seti.projects.p128Text",
		cost: 1,
		color: "blue",
		free: "publicity",
		income: "card",
		...E[128]
	},
	{
		id: 129,
		name: "games.seti.projects.p129",
		text: "games.seti.projects.p129Text",
		cost: 0,
		color: "red",
		free: "move",
		income: "energy",
		...E[129]
	},
	{
		id: 130,
		name: "games.seti.projects.p130",
		text: "games.seti.projects.p130Text",
		cost: 1,
		color: "yellow",
		free: "publicity",
		income: "energy",
		...E[130]
	},
	{
		id: 131,
		name: "games.seti.projects.p131",
		text: "games.seti.projects.p131Text",
		cost: 1,
		color: "red",
		free: "data",
		income: "energy",
		...E[131]
	},
	{
		id: 132,
		name: "games.seti.projects.p132",
		text: "games.seti.projects.p132Text",
		cost: 3,
		color: "black",
		free: "move",
		income: "card",
		...E[132]
	},
	{
		id: 133,
		name: "games.seti.projects.p133",
		text: "games.seti.projects.p133Text",
		cost: 2,
		color: "red",
		free: "data",
		income: "publicity",
		...E[133]
	},
	{
		id: 134,
		name: "games.seti.projects.p134",
		text: "games.seti.projects.p134Text",
		cost: 1,
		color: "red",
		free: "move",
		income: "card",
		...E[134]
	},
	{
		id: 135,
		name: "games.seti.projects.p135",
		text: "games.seti.projects.p135Text",
		cost: 2,
		color: "blue",
		free: "move",
		income: "energy",
		...E[135]
	},
	{
		id: 136,
		name: "games.seti.projects.p136",
		text: "games.seti.projects.p136Text",
		cost: 1,
		color: "red",
		free: "data",
		income: "energy",
		...E[136]
	},
	{
		id: 137,
		name: "games.seti.projects.p137",
		text: "games.seti.projects.p137Text",
		cost: 1,
		color: "black",
		free: "publicity",
		income: "card",
		...E[137]
	},
	{
		id: 138,
		name: "games.seti.projects.p138",
		text: "games.seti.projects.p138Text",
		cost: 1,
		color: "blue",
		free: "publicity",
		income: "card",
		...E[138]
	}
], D = (e, t = 1) => ({
	kind: "gain",
	resource: e,
	n: t
}), re = (e = 1) => ({
	kind: "draw",
	n: e
}), O = (e = 1) => ({
	kind: "move",
	n: e
}), k = (e, t) => ({
	kind: "alien",
	op: e,
	species: -1,
	n: t
}), A = (e) => ({
	kind: "research",
	family: e
}), j = (e, t, n = 1, r) => ({
	metric: {
		kind: e,
		target: t,
		color: r
	},
	atLeast: n
}), M = (e, ...t) => ({
	condition: e,
	rewards: [t]
}), N = {
	1001: {
		effects: [
			O(),
			{
				kind: "land",
				override: !1
			},
			k("collect")
		],
		mission: M({
			metric: {
				kind: "sampleDelivery",
				target: "earth",
				n: 1001
			},
			atLeast: 1
		}, k("deliver"), D("data", 2))
	},
	1002: {
		effects: [{
			kind: "land",
			override: !1,
			moonAccess: !0
		}, k("collect")],
		mission: M({
			metric: {
				kind: "sampleDelivery",
				target: "earth",
				n: 1002
			},
			atLeast: 1
		}, k("deliver"), D("vp", 3), D("data", 3))
	},
	1003: {
		effects: [k("sampleOrbitLand"), k("collect")],
		mission: M({
			metric: {
				kind: "sampleDelivery",
				target: "earth",
				n: 1003
			},
			atLeast: 1
		}, k("deliver"), D("vp", 3), D("credit"))
	},
	1004: {
		effects: [{
			kind: "land",
			override: !1
		}, k("collect")],
		mission: M({
			metric: {
				kind: "sampleDelivery",
				target: "mars",
				n: 1004
			},
			atLeast: 1
		}, k("deliver"), D("vp", 2), re())
	},
	1005: {
		effects: [k("inspectHere")],
		score: {
			metric: {
				kind: "speciesTrace",
				target: "mascamites"
			},
			multiplier: 1
		}
	},
	1006: {
		effects: [{
			kind: "land",
			override: !1,
			moonAccess: !0
		}, k("collect")],
		mission: M({
			metric: {
				kind: "sampleDelivery",
				target: "earth",
				n: 1006
			},
			atLeast: 1
		}, k("deliver"), D("vp", 6), D("publicity", 2))
	},
	1007: {
		effects: [{
			kind: "land",
			override: !1
		}, k("collect")],
		mission: M({
			metric: {
				kind: "sampleDelivery",
				target: "earth",
				n: 1007
			},
			atLeast: 1
		}, k("deliver", 2))
	},
	1008: {
		effects: [D("publicity"), A("telescope")],
		mission: M(j("speciesTrace", "mascamites", 2, "red"), k("inspectAny"))
	},
	1009: {
		effects: [D("publicity"), A("computer")],
		mission: M(j("speciesTrace", "mascamites", 2, "blue"), k("inspectAny"))
	},
	1010: {
		effects: [D("publicity"), A("probe")],
		mission: M(j("speciesTrace", "mascamites", 2, "yellow"), k("inspectAny"))
	},
	1011: {
		effects: [k("nextAnomaly")],
		mission: M(j("traceSet", "anomalies"), D("vp", 3), D("publicity", 2))
	},
	1012: { effects: [{ kind: "launch" }, k("launchAnomalyMove")] },
	1013: {
		effects: [D("publicity")],
		mission: {
			event: { kind: "research" },
			rewards: [
				[D("energy")],
				[re()],
				[D("vp", 3)]
			]
		}
	},
	1014: { effects: [{
		kind: "scan",
		todo: []
	}, k("nextAnomalySignal")] },
	1015: { effects: [k("drawThree")] },
	1016: { effects: [k("takeRow")] },
	1017: { effects: [k("noPublicity"), O(5)] },
	1018: { effects: [A("any")] },
	1019: { effects: [{
		kind: "trace",
		color: "any"
	}] },
	1020: { effects: [{
		kind: "targetSignal",
		target: "any",
		n: 1
	}, k("anomalySignalScore")] },
	1021: {
		effects: [k("scanFossilVP"), {
			kind: "scan",
			todo: []
		}],
		mission: M(j("fossilResearch"), D("data"))
	},
	1022: {
		effects: [k("scanFossil"), {
			kind: "scan",
			todo: []
		}],
		mission: M(j("lander", "oumuamua"), D("vp", 4))
	},
	1023: {
		effects: [{
			kind: "targetSignal",
			target: "oumuamua",
			n: 1
		}],
		mission: M(j("fossil", void 0, 3), k("spendFossil", 2), D("vp", 11))
	},
	1024: { effects: [A("computer"), k("fossilData")] },
	1025: { effects: [k("fossilMove"), {
		kind: "land",
		override: !1
	}] },
	1026: {
		effects: [{
			kind: "land",
			override: !1
		}, k("landOumuamuaScore")],
		mission: M(j("traceSet", "oumuamua"), k("fossil", 1))
	},
	1027: {
		effects: [O(4), {
			kind: "if",
			condition: j("visit", "oumuamua"),
			effects: [k("fossil", 1)]
		}],
		mission: M(j("oumuamuaSignal"), k("fossil", 1))
	},
	1028: { effects: [{ kind: "launch" }, k("fossil", 1)] },
	1029: {
		effects: [k("fossil", 1)],
		mission: {
			event: { kind: "trace" },
			rewards: [
				[D("data")],
				[D("publicity")],
				[D("vp", 3)]
			]
		}
	},
	1030: {
		effects: [
			{
				kind: "targetSignal",
				target: "yellow",
				n: 1
			},
			{
				kind: "targetSignal",
				target: "red",
				n: 1
			},
			{
				kind: "targetSignal",
				target: "blue",
				n: 1
			},
			k("fossilSignal")
		],
		score: {
			metric: {
				kind: "speciesTrace",
				target: "oumuamua"
			},
			multiplier: 1
		}
	},
	1031: { effects: [{ kind: "launch" }, k("messageTuck")] },
	1032: { effects: [D("data", 2), k("messageTuck")] },
	1033: { effects: [
		D("publicity"),
		D("credit"),
		k("messageTuck")
	] },
	1034: { effects: [re(), k("messageTrace", 0)] },
	1035: { effects: [D("data"), k("messageTrace", 1)] },
	1036: { effects: [D("publicity", 2), k("messageTrace", 2)] },
	1037: { effects: [re(), k("messageWild")] },
	1038: { effects: [A("computer"), k("messageTuck")] },
	1039: { effects: [A("telescope"), k("messageTuck")] },
	1040: { effects: [{
		kind: "targetSignal",
		target: "any",
		n: 2
	}, k("messageTuck")] }
}, P = [
	[
		1001,
		1,
		"blue",
		"publicity",
		"card"
	],
	[
		1002,
		2,
		"black",
		"publicity",
		"card"
	],
	[
		1003,
		1,
		"yellow",
		"data",
		"energy"
	],
	[
		1004,
		1,
		"red",
		"data",
		"credit"
	],
	[
		1005,
		1,
		"blue",
		"move",
		"card"
	],
	[
		1006,
		2,
		"red",
		"move",
		"credit"
	],
	[
		1007,
		1,
		"red",
		"publicity",
		"energy"
	],
	[
		1008,
		3,
		"yellow",
		"move",
		"credit"
	],
	[
		1009,
		3,
		"yellow",
		"data",
		"card"
	],
	[
		1010,
		3,
		"blue",
		"move",
		"energy"
	],
	[
		1011,
		1,
		"yellow",
		"move",
		"card"
	],
	[
		1012,
		1,
		"blue",
		"publicity",
		"card"
	],
	[
		1013,
		1,
		"yellow",
		"data",
		"credit"
	],
	[
		1014,
		2,
		"red",
		"move",
		"card"
	],
	[
		1015,
		1,
		"blue",
		"move",
		"credit"
	],
	[
		1016,
		1,
		"red",
		"data",
		"credit"
	],
	[
		1017,
		1,
		"red",
		"publicity",
		"credit"
	],
	[
		1018,
		2,
		"blue",
		"data",
		"credit"
	],
	[
		1019,
		1,
		"black",
		"publicity",
		"energy"
	],
	[
		1020,
		1,
		"yellow",
		"publicity",
		"energy"
	],
	[
		1021,
		2,
		"blue",
		"publicity",
		"card"
	],
	[
		1022,
		2,
		"red",
		"move",
		"energy"
	],
	[
		1023,
		1,
		"yellow",
		"publicity",
		"credit"
	],
	[
		1024,
		2,
		"blue",
		"move",
		"card"
	],
	[
		1025,
		1,
		"blue",
		"data",
		"card"
	],
	[
		1026,
		1,
		"black",
		"data",
		"card"
	],
	[
		1027,
		2,
		"yellow",
		"data",
		"credit"
	],
	[
		1028,
		1,
		"red",
		"publicity",
		"credit"
	],
	[
		1029,
		1,
		"red",
		"move",
		"energy"
	],
	[
		1030,
		3,
		"yellow",
		"move",
		"credit"
	],
	[
		1031,
		1,
		"blue",
		"data",
		"publicity"
	],
	[
		1032,
		1,
		"red",
		"move",
		"data"
	],
	[
		1033,
		1,
		"yellow",
		"publicity",
		"publicity"
	],
	[
		1034,
		1,
		"red",
		"move",
		"energy"
	],
	[
		1035,
		1,
		"yellow",
		"publicity",
		"card"
	],
	[
		1036,
		1,
		"blue",
		"data",
		"credit"
	],
	[
		1037,
		2,
		"black",
		"data",
		"energy"
	],
	[
		1038,
		2,
		"blue",
		"publicity",
		"data"
	],
	[
		1039,
		2,
		"red",
		"move",
		"publicity"
	],
	[
		1040,
		2,
		"yellow",
		"publicity",
		"data"
	]
], ie = (e) => e <= 1010 ? "mascamites" : e <= 1020 ? "anomalies" : e <= 1030 ? "oumuamua" : "centaurians", ae = [
	["games.seti.aliens.c1001", "games.seti.aliens.c1001Text"],
	["games.seti.aliens.c1002", "games.seti.aliens.c1002Text"],
	["games.seti.aliens.c1003", "games.seti.aliens.c1003Text"],
	["games.seti.aliens.c1004", "games.seti.aliens.c1004Text"],
	["games.seti.aliens.c1005", "games.seti.aliens.c1005Text"],
	["games.seti.aliens.c1006", "games.seti.aliens.c1006Text"],
	["games.seti.aliens.c1007", "games.seti.aliens.c1007Text"],
	["games.seti.aliens.c1008", "games.seti.aliens.c1008Text"],
	["games.seti.aliens.c1009", "games.seti.aliens.c1009Text"],
	["games.seti.aliens.c1010", "games.seti.aliens.c1010Text"],
	["games.seti.aliens.c1011", "games.seti.aliens.c1011Text"],
	["games.seti.aliens.c1012", "games.seti.aliens.c1012Text"],
	["games.seti.aliens.c1013", "games.seti.aliens.c1013Text"],
	["games.seti.aliens.c1014", "games.seti.aliens.c1014Text"],
	["games.seti.aliens.c1015", "games.seti.aliens.c1015Text"],
	["games.seti.aliens.c1016", "games.seti.aliens.c1016Text"],
	["games.seti.aliens.c1017", "games.seti.aliens.c1017Text"],
	["games.seti.aliens.c1018", "games.seti.aliens.c1018Text"],
	["games.seti.aliens.c1019", "games.seti.aliens.c1019Text"],
	["games.seti.aliens.c1020", "games.seti.aliens.c1020Text"],
	["games.seti.aliens.c1021", "games.seti.aliens.c1021Text"],
	["games.seti.aliens.c1022", "games.seti.aliens.c1022Text"],
	["games.seti.aliens.c1023", "games.seti.aliens.c1023Text"],
	["games.seti.aliens.c1024", "games.seti.aliens.c1024Text"],
	["games.seti.aliens.c1025", "games.seti.aliens.c1025Text"],
	["games.seti.aliens.c1026", "games.seti.aliens.c1026Text"],
	["games.seti.aliens.c1027", "games.seti.aliens.c1027Text"],
	["games.seti.aliens.c1028", "games.seti.aliens.c1028Text"],
	["games.seti.aliens.c1029", "games.seti.aliens.c1029Text"],
	["games.seti.aliens.c1030", "games.seti.aliens.c1030Text"],
	["games.seti.aliens.c1031", "games.seti.aliens.c1031Text"],
	["games.seti.aliens.c1032", "games.seti.aliens.c1032Text"],
	["games.seti.aliens.c1033", "games.seti.aliens.c1033Text"],
	["games.seti.aliens.c1034", "games.seti.aliens.c1034Text"],
	["games.seti.aliens.c1035", "games.seti.aliens.c1035Text"],
	["games.seti.aliens.c1036", "games.seti.aliens.c1036Text"],
	["games.seti.aliens.c1037", "games.seti.aliens.c1037Text"],
	["games.seti.aliens.c1038", "games.seti.aliens.c1038Text"],
	["games.seti.aliens.c1039", "games.seti.aliens.c1039Text"],
	["games.seti.aliens.c1040", "games.seti.aliens.c1040Text"]
], oe = P.map(([e, t, n, r, i], a) => ({
	id: e,
	cost: t,
	color: n,
	free: r,
	income: i,
	name: ae[a][0],
	text: ae[a][1],
	species: ie(e),
	energyCost: e >= 1031,
	...e >= 1031 && r !== "publicity" ? { corner: [D("vp"), r === "move" ? O() : D("data")] } : r === "publicity" ? { corner: [D("publicity", 2)] } : { corner: [D("vp"), r === "move" ? O() : D("data")] },
	...N[e]
})), se = [
	{
		condition: j("speciesTrace", "exertians", 6),
		vp: 7,
		danger: 0
	},
	{
		condition: j("samePlanetFigures", void 0, 3),
		vp: 10,
		danger: 2
	},
	{
		condition: j("wins", "blue", 2),
		vp: 12,
		danger: 4
	},
	{
		condition: j("tech", "telescope", 3),
		vp: 15,
		danger: 7
	},
	{
		condition: j("tech", "computer", 3),
		vp: 9,
		danger: 3
	},
	{
		condition: j("income", void 0, 8),
		vp: 18,
		danger: 8
	},
	{
		condition: j("wins", "black", 2),
		vp: 14,
		danger: 5
	},
	{
		condition: j("lander", void 0, 4),
		vp: 16,
		danger: 7
	},
	{
		condition: j("trace", "same", 5),
		vp: 8,
		danger: 1
	},
	{
		condition: j("speciesTrace", "other", 6),
		vp: 20,
		danger: 9
	},
	{
		condition: j("orbiter", void 0, 3),
		vp: 11,
		danger: 3
	},
	{
		condition: j("wins", "red", 2),
		vp: 12,
		danger: 4
	},
	{
		condition: j("tech", "probe", 3),
		vp: 14,
		danger: 6
	},
	{
		condition: j("mission", void 0, 5),
		vp: 12,
		danger: 4
	},
	{
		condition: j("wins", "yellow", 2),
		vp: 12,
		danger: 4
	}
], ce = [
	["games.seti.aliens.c2001", "games.seti.aliens.c2001Text"],
	["games.seti.aliens.c2002", "games.seti.aliens.c2002Text"],
	["games.seti.aliens.c2003", "games.seti.aliens.c2003Text"],
	["games.seti.aliens.c2004", "games.seti.aliens.c2004Text"],
	["games.seti.aliens.c2005", "games.seti.aliens.c2005Text"],
	["games.seti.aliens.c2006", "games.seti.aliens.c2006Text"],
	["games.seti.aliens.c2007", "games.seti.aliens.c2007Text"],
	["games.seti.aliens.c2008", "games.seti.aliens.c2008Text"],
	["games.seti.aliens.c2009", "games.seti.aliens.c2009Text"],
	["games.seti.aliens.c2010", "games.seti.aliens.c2010Text"],
	["games.seti.aliens.c2011", "games.seti.aliens.c2011Text"],
	["games.seti.aliens.c2012", "games.seti.aliens.c2012Text"],
	["games.seti.aliens.c2013", "games.seti.aliens.c2013Text"],
	["games.seti.aliens.c2014", "games.seti.aliens.c2014Text"],
	["games.seti.aliens.c2015", "games.seti.aliens.c2015Text"]
], le = se.map((e, t) => ({
	id: 2001 + t,
	name: ce[t][0],
	text: ce[t][1],
	cost: 0,
	color: "black",
	free: "vp",
	income: "vp",
	effects: [],
	species: "exertians",
	danger: e.danger
})), ue = [
	...ne,
	...oe,
	...le
], de = [
	"games.seti.sampleRewards.credit",
	"games.seti.sampleRewards.energy",
	"games.seti.sampleRewards.publicity",
	"games.seti.sampleRewards.data",
	"games.seti.sampleRewards.cards",
	"games.seti.sampleRewards.pointsCards",
	"games.seti.sampleRewards.points"
], F = (e) => ue.find((t) => t.id === e), fe = {
	earth: "games.seti.planets.earth",
	mercury: "games.seti.planets.mercury",
	venus: "games.seti.planets.venus",
	mars: "games.seti.planets.mars",
	jupiter: "games.seti.planets.jupiter",
	saturn: "games.seti.planets.saturn",
	uranus: "games.seti.planets.uranus",
	neptune: "games.seti.planets.neptune",
	oumuamua: "games.seti.species.oumuamua"
}, pe = {
	credit: "games.seti.resources.credit",
	energy: "games.seti.resources.energy",
	publicity: "games.seti.resources.publicity",
	data: "games.seti.resources.data",
	vp: "games.seti.resources.vp",
	card: "games.seti.resources.card",
	move: "games.seti.resources.move"
}, me = [
	{
		id: "p0",
		family: "probe",
		name: "games.seti.techs.capacity",
		text: "games.seti.techs.capacityText",
		bonus: [{ kind: "launch" }]
	},
	{
		id: "p1",
		family: "probe",
		name: "games.seti.techs.asteroid",
		text: "games.seti.techs.asteroidText"
	},
	{
		id: "p2",
		family: "probe",
		name: "games.seti.techs.landing",
		text: "games.seti.techs.landingText"
	},
	{
		id: "p3",
		family: "probe",
		name: "games.seti.techs.moon",
		text: "games.seti.techs.moonText"
	},
	{
		id: "t0",
		family: "telescope",
		name: "games.seti.techs.adjacent",
		text: "games.seti.techs.adjacentText",
		bonus: [{
			kind: "gain",
			resource: "data",
			n: 2
		}]
	},
	{
		id: "t1",
		family: "telescope",
		name: "games.seti.techs.hand",
		text: "games.seti.techs.handText"
	},
	{
		id: "t2",
		family: "telescope",
		name: "games.seti.techs.mercury",
		text: "games.seti.techs.mercuryText"
	},
	{
		id: "t3",
		family: "telescope",
		name: "games.seti.techs.launch",
		text: "games.seti.techs.launchText"
	},
	{
		id: "c0",
		family: "computer",
		name: "games.seti.techs.publicity",
		text: "games.seti.techs.publicityText",
		lower: [{
			kind: "gain",
			resource: "publicity",
			n: 2
		}]
	},
	{
		id: "c1",
		family: "computer",
		name: "games.seti.techs.card",
		text: "games.seti.techs.cardText",
		lower: [{ kind: "pickCard" }]
	},
	{
		id: "c2",
		family: "computer",
		name: "games.seti.techs.energy",
		text: "games.seti.techs.energyText",
		lower: [{
			kind: "gain",
			resource: "energy",
			n: 1
		}]
	},
	{
		id: "c3",
		family: "computer",
		name: "games.seti.techs.credit",
		text: "games.seti.techs.creditText",
		lower: [{
			kind: "gain",
			resource: "credit",
			n: 1
		}]
	}
], I = (e) => me.find((t) => t.id === e), he = {
	probe: "games.seti.probeTech",
	telescope: "games.seti.telescopeTech",
	computer: "games.seti.computerTech"
}, L = (e, t) => ({
	kind: "gain",
	resource: e,
	n: t
}), ge = { kind: "income" }, _e = {
	kind: "rowSignals",
	n: 1,
	sectors: []
}, ve = [
	{
		id: "oumuamua",
		orbit: [
			L("vp", 10),
			{
				kind: "alien",
				op: "fossil",
				species: -1,
				n: 1
			},
			{
				kind: "targetSignal",
				target: "oumuamua",
				n: 1
			}
		],
		vp: 9,
		first: [
			1,
			2,
			3
		],
		moons: []
	},
	{
		id: "mercury",
		orbit: [
			{
				kind: "draw",
				n: 1
			},
			_e,
			_e,
			{ kind: "refill" },
			ge
		],
		vp: 12,
		first: [3],
		moons: []
	},
	{
		id: "venus",
		orbit: [L("vp", 6), ge],
		vp: 5,
		first: [2],
		moons: []
	},
	{
		id: "mars",
		orbit: [
			L("credit", 1),
			_e,
			{ kind: "refill" },
			ge
		],
		vp: 6,
		first: [1, 2],
		moons: [{
			id: "phobos",
			name: "games.seti.moons.phobos",
			effects: [
				L("vp", 8),
				ge,
				ge
			]
		}]
	},
	{
		id: "jupiter",
		orbit: [
			L("data", 1),
			_e,
			{ kind: "refill" },
			ge
		],
		vp: 7,
		first: [2],
		moons: [
			{
				id: "io",
				name: "games.seti.moons.io",
				effects: [L("vp", 10), L("energy", 4)]
			},
			{
				id: "europa",
				name: "games.seti.moons.europa",
				effects: [
					L("vp", 7),
					{
						kind: "trace",
						color: "any"
					},
					{
						kind: "trace",
						color: "any"
					}
				]
			},
			{
				id: "ganymede",
				name: "games.seti.moons.ganymede",
				effects: [L("vp", 12), L("publicity", 5)]
			},
			{
				id: "callisto",
				name: "games.seti.moons.callisto",
				effects: [L("vp", 13), L("data", 4)]
			}
		]
	},
	{
		id: "saturn",
		orbit: [
			L("publicity", 2),
			_e,
			{ kind: "refill" },
			ge
		],
		vp: 8,
		first: [2],
		moons: [{
			id: "enceladus",
			name: "games.seti.moons.enceladus",
			effects: [
				L("vp", 12),
				{
					kind: "trace",
					color: "red"
				},
				{
					kind: "trace",
					color: "yellow"
				},
				{
					kind: "trace",
					color: "blue"
				}
			]
		}, {
			id: "titan",
			name: "games.seti.moons.titan",
			effects: [
				L("vp", 7),
				{
					kind: "research",
					family: "any"
				},
				{
					kind: "research",
					family: "any"
				}
			]
		}]
	},
	{
		id: "uranus",
		orbit: [
			L("vp", 8),
			{
				kind: "draw",
				n: 3
			},
			{
				kind: "signal",
				sectors: [
					0,
					1,
					2,
					3,
					4,
					5,
					6,
					7
				]
			}
		],
		vp: 9,
		first: [3],
		moons: [{
			id: "titania",
			name: "games.seti.moons.titania",
			effects: [L("vp", 25)]
		}]
	},
	{
		id: "neptune",
		orbit: [
			L("vp", 7),
			L("data", 4),
			{
				kind: "signal",
				sectors: [
					0,
					1,
					2,
					3,
					4,
					5,
					6,
					7
				]
			}
		],
		vp: 10,
		first: [3],
		moons: [{
			id: "triton",
			name: "games.seti.moons.triton",
			effects: [L("vp", 26)]
		}]
	}
], ye = [
	{
		id: "procyon",
		color: "blue",
		capacity: 5,
		firstVP: 0,
		laterVP: 3
	},
	{
		id: "vega",
		color: "black",
		capacity: 4,
		firstVP: 2,
		laterVP: 5
	},
	{
		id: "sirius",
		color: "blue",
		capacity: 6,
		firstVP: 0,
		laterVP: 0
	},
	{
		id: "barnard",
		color: "red",
		capacity: 5,
		firstVP: 0,
		laterVP: 3
	},
	{
		id: "kepler",
		color: "yellow",
		capacity: 5,
		firstVP: 0,
		laterVP: 3
	},
	{
		id: "proxima",
		color: "red",
		capacity: 6,
		firstVP: 0,
		laterVP: 0
	},
	{
		id: "virginis",
		color: "yellow",
		capacity: 6,
		firstVP: 0,
		laterVP: 0
	},
	{
		id: "pictoris",
		color: "black",
		capacity: 4,
		firstVP: 3,
		laterVP: 0
	}
], be = {
	procyon: "games.seti.stars.procyon",
	vega: "games.seti.stars.vega",
	sirius: "games.seti.stars.sirius",
	barnard: "games.seti.stars.barnard",
	kepler: "games.seti.stars.kepler",
	proxima: "games.seti.stars.proxima",
	virginis: "games.seti.stars.virginis",
	pictoris: "games.seti.stars.pictoris"
}, xe = {
	mascamites: "games.seti.species.mascamites",
	anomalies: "games.seti.species.anomalies",
	oumuamua: "games.seti.species.oumuamua",
	centaurians: "games.seti.species.centaurians",
	exertians: "games.seti.species.exertians"
}, R = (e) => (e % 8 + 8) % 8, z = [
	[[
		1,
		2,
		3,
		5,
		6
	]],
	[[
		2,
		3,
		4,
		5,
		6
	], [
		2,
		5,
		6
	]],
	[
		[
			0,
			1,
			2,
			5,
			6,
			7
		],
		[
			0,
			2,
			4,
			5,
			7
		],
		[
			2,
			3,
			4,
			7
		]
	]
], B = {
	"0:1:1": { planet: "mercury" },
	"0:1:3": { planet: "venus" },
	"0:1:5": { planet: "earth" },
	"1:2:2": { planet: "mars" },
	"1:1:3": { asteroid: !0 },
	"1:1:5": { asteroid: !0 },
	"1:2:6": { asteroid: !0 },
	"2:3:7": { planet: "saturn" },
	"2:3:3": { planet: "jupiter" },
	"2:2:0": { comet: !0 },
	"2:2:7": { asteroid: !0 },
	"2:2:4": { asteroid: !0 },
	"2:1:7": { asteroid: !0 },
	"2:1:6": { asteroid: !0 },
	"2:1:2": { asteroid: !0 },
	"2:1:1": { comet: !0 },
	"3:4:0": { planet: "uranus" },
	"3:4:3": { planet: "neptune" },
	"3:4:5": { comet: !0 },
	"3:4:7": { comet: !0 },
	"3:3:1": { asteroid: !0 },
	"3:3:3": { asteroid: !0 },
	"3:3:4": { asteroid: !0 },
	"3:3:7": { asteroid: !0 },
	"3:3:2": { comet: !0 },
	"3:2:2": { asteroid: !0 },
	"3:2:6": { asteroid: !0 },
	"3:2:1": { comet: !0 },
	"3:2:4": { comet: !0 },
	"3:1:0": { asteroid: !0 },
	"3:1:3": { asteroid: !0 },
	"3:1:4": { asteroid: !0 },
	"3:1:1": { comet: !0 },
	"3:1:6": { comet: !0 },
	"3:1:7": { comet: !0 }
};
function Se(e, t) {
	for (let n = 0; n < 3; n++) if (z[n][t.ring - 1]?.includes(R(t.sector - e[n]))) return n;
	return 3;
}
function V(e, t, n = !1) {
	if (n && t.ring === 3 && t.sector === R(e[2] + 2)) return { planet: "oumuamua" };
	let r = Se(e, t);
	return B[`${r}:${t.ring}:${R(t.sector - (e[r] ?? 0))}`] ?? {};
}
function H(e, t) {
	if (t === "oumuamua") return {
		ring: 3,
		sector: R(e[2] + 2)
	};
	for (let n = 1; n <= 4; n++) for (let r = 0; r < 8; r++) if (V(e, {
		ring: n,
		sector: r
	}).planet === t) return {
		ring: n,
		sector: r
	};
	throw Error(`Missing planet: ${t}`);
}
function Ce(e, t) {
	return e.map((e, n) => R(e - +(n <= t)));
}
function we(e, t, n, r) {
	return Se(e, r) <= n || Se(t, r) <= n ? {
		...r,
		sector: R(r.sector - 1)
	} : { ...r };
}
function Te(e) {
	return [
		{
			...e,
			sector: R(e.sector - 1)
		},
		{
			...e,
			sector: R(e.sector + 1)
		},
		...e.ring > 1 ? [{
			...e,
			ring: e.ring - 1
		}] : [],
		...e.ring < 4 ? [{
			...e,
			ring: e.ring + 1
		}] : []
	];
}
function Ee(e, t = 1) {
	let n = (e.sector + .5) * Math.PI / 4, r = (45 + e.ring * 43) * t;
	return {
		x: 300 + Math.sin(n) * r,
		y: 300 - Math.cos(n) * r
	};
}
//#endregion
//#region src/games/seti/model.ts
var U = () => ({
	stage: "before",
	flow: [],
	free: null,
	sameRing: !1,
	lightsail: null,
	lastFamily: null,
	pass: !1,
	effectOwner: null,
	landingProbe: null,
	endRequested: !1,
	ignoreAsteroid: !1,
	slingshot: !1,
	noPublicity: !1,
	actionSignals: [],
	card: null,
	landings: [],
	landingSite: null,
	oumuamuaSignals: 0,
	scanBonus: null,
	completedSectors: [],
	bonuses: [],
	revealedCards: []
});
//#endregion
//#region src/games/seti/metrics.ts
function W(e, t, n, r) {
	let i = [
		"red",
		"yellow",
		"blue"
	];
	return e.species.reduce((e, a, o) => e + (r !== void 0 && o !== r ? 0 : a.traces.filter((e, r) => e === t.rid && (!n || i[r] === n)).length + a.overflow.filter((e, r) => e === t.rid && (!n || a.overflowColors[r] === n)).length + a.research.filter((e) => !n || e.color === n).reduce((e, n) => e + n.owners.filter((e) => e === t.rid).length, 0)), 0);
}
function De(e, t) {
	let n = H(e.angles, "earth"), r = [{
		...t,
		cost: 0
	}], i = /* @__PURE__ */ new Map();
	for (; r.length;) {
		r.sort((e, t) => e.cost - t.cost);
		let e = r.shift(), t = `${e.ring}:${e.sector}`;
		if (!i.has(t)) {
			if (i.set(t, e.cost), e.ring === n.ring && e.sector === n.sector) return e.cost;
			r.push(...Te(e).map((t) => ({
				...t,
				cost: e.cost + 1
			})));
		}
	}
	return 0;
}
function Oe(e, t, n) {
	let r = e.figures.filter((e) => e.owner === t.rid), i = e.probes.filter((e) => e.owner === t.rid);
	switch (n.kind) {
		case "figure": return r.filter((e) => !n.target || e.planet === n.target).length;
		case "lander": return r.filter((e) => e.kind === "lander" && (!n.target || (n.target === "planet" ? !e.moon : e.planet === n.target))).length;
		case "orbiter": return r.filter((e) => e.kind === "orbiter").length;
		case "tech": return t.techs.filter((e) => !n.target || I(e).family === n.target).length;
		case "trace": return n.target === "same" ? Math.max(...[
			"red",
			"yellow",
			"blue"
		].map((n) => W(e, t, n))) : W(e, t, n.color);
		case "speciesTrace": return W(e, t, n.color, n.target === "other" ? e.species.findIndex((e) => e.id !== "exertians") : e.species.findIndex((e) => e.id === n.target));
		case "traceSpecies": return e.species.filter((r, i) => W(e, t, n.color, i) > 0).length;
		case "traceSet": return e.species.filter((r, i) => (!n.target || r.id === n.target) && [
			"red",
			"yellow",
			"blue"
		].every((n) => W(e, t, n, i) > 0)).length;
		case "wins": {
			let r = e.sectors.filter((e) => !n.target || n.target === "same" || e.id === n.target || e.color === n.target).map((e) => e.winners.filter((e) => e === t.rid).length);
			return n.target === "same" ? Math.max(0, ...r) : r.reduce((e, t) => e + t, 0);
		}
		case "income": return t.income.filter((e) => !n.target || F(e.id).income === n.target).length;
		case "mission": return t.missions.filter((e) => e.circles.length === F(e.card.id).mission?.rewards.length).length;
		case "endgame": return t.played.filter((e) => F(e.id).score || e.id === 113).length;
		case "resource": return t[n.target];
		case "signalSectors": return e.sectors.filter((e) => e.signals.includes(t.rid)).length;
		case "probeTerrain": return i.filter((t) => {
			let r = V(e.angles, t);
			return n.target === "earthAsteroid" ? r.asteroid && Te(H(e.angles, "earth")).some((e) => e.ring === t.ring && e.sector === t.sector) : n.target === "asteroid" ? r.asteroid : r.comet;
		}).length;
		case "distantProbe": return Math.max(0, ...i.map((t) => De(e, t)));
		case "pairedFigures": return r.filter((e) => e.kind === "orbiter" && r.some((t) => t.planet === e.planet && t.kind === "lander")).length;
		case "visit": return e.events.filter((r) => r.owner === t.rid && r.turn === e.turnNumber && r.kind === "visit" && r.target === n.target).length;
		case "sameRing": return Number(e.turn.sameRing);
		case "completedSector": return e.turn.completedSectors.length;
		case "hand": return t.hand.filter((e) => !n.target || F(e.id).income === n.target).length;
		case "fossil": return t.fossil;
		case "sampleDelivery": return e.probes.filter((r) => r.owner === t.rid && r.sample !== void 0 && V(e.angles, r).planet === n.target).length;
		case "oumuamuaSignal": return Number(e.species.some((e) => e.id === "oumuamua" && e.signals.includes(t.rid)));
		case "fossilResearch": return Number(e.species.some((e) => e.id === "oumuamua" && e.research.some((e) => e.fossil && e.owners.includes(t.rid))));
		case "samePlanetFigures": return Math.max(0, ...r.map((e) => r.filter((t) => t.planet === e.planet).length));
	}
}
var ke = (e, t, n) => (n.atLeast === void 0 || Oe(e, t, n.metric) >= n.atLeast) && (n.atMost === void 0 || Oe(e, t, n.metric) <= n.atMost) && (!n.all || n.all.every((n) => ke(e, t, n))), Ae = [
	[
		11,
		8,
		5
	],
	[
		7,
		5,
		3
	],
	[
		4,
		3,
		2
	],
	[
		8,
		6,
		4
	],
	[
		11,
		8,
		5
	],
	[
		5,
		4,
		3
	],
	[
		8,
		6,
		4
	],
	[
		8,
		6,
		4
	]
];
function je(e, t, n, r) {
	let i = n * 2 + e.goldFaces[n], a = (n, r, i) => Oe(e, t, {
		kind: n,
		target: r,
		color: i
	});
	return [
		Math.min(a("tech", "probe"), a("tech", "telescope"), a("tech", "computer")),
		Math.floor(t.techs.length / 2),
		a("mission"),
		Math.floor((a("mission") + a("endgame")) / 2),
		Math.min(a("income", "credit"), a("income", "energy"), a("income", "card")),
		Math.max(a("income", "credit"), a("income", "energy")),
		Math.min(W(e, t, "red"), W(e, t, "yellow"), W(e, t, "blue")),
		Math.min(a("wins"), a("figure"))
	][i] * Ae[i][Math.min(2, r)];
}
//#endregion
//#region src/games/seti/alien-engine.ts
var G = (e, t) => ({
	kind: "gain",
	resource: e,
	n: t
}), Me = (e, t, n, r) => ({
	kind: "alien",
	op: e,
	species: t,
	n,
	card: r
}), Ne = (e) => Me("draw", e), Pe = [
	"red",
	"yellow",
	"blue"
], Fe = [
	[G("credit", 2)],
	[G("energy", 2)],
	[G("publicity", 3)],
	[G("data", 2)],
	[{
		kind: "draw",
		n: 2
	}],
	[G("vp", 3), {
		kind: "draw",
		n: 1
	}],
	[G("vp", 7)]
];
function K(e, t, n, r = {}) {
	e.research.push({
		color: t,
		cost: 0,
		reward: n,
		owners: [],
		...r
	});
}
function Ie(e, t, n) {
	e.responses.push({
		owner: t,
		event: ++e.serial,
		options: [],
		flow: n
	});
}
function Le(e, t) {
	let n = e.species[t];
	if (n.revealed = !0, n.deck = Je(e, ue.filter((e) => e.species === n.id).map((t) => ({
		id: t.id,
		uid: Ye(e, "a")
	}))), n.id === "exertians") {
		let r = Math.max(...e.players.map((e) => e.vp));
		n.dangerThresholds = [r + 20, r + 40];
		for (let r of e.players) {
			let i = n.traces.filter((e) => e === r.rid).length;
			r.secret.push(...n.deck.splice(0, 3 + i)), i && Ie(e, r.rid, [Me("secretPlay", t, i)]);
		}
		n.deck = [];
	} else {
		for (let t of e.players) t.hand.push(...n.deck.splice(0, n.traces.filter((e) => e === t.rid).length));
		n.market = n.deck.splice(0, 1);
	}
	for (let e of Pe) if (n.id === "mascamites") K(n, e, [G("vp", 5), Ne(t)]), K(n, e, [G("vp", 3), Ne(t)]), e !== "blue" && (K(n, e, [G("vp", 5)]), K(n, e, [G("vp", 4)]));
	else if (n.id === "anomalies") K(n, e, [G("vp", 4), Ne(t)]), K(n, e, [G("vp", 2), Ne(t)]), K(n, e, [G("vp", 2), G("publicity", 1)]), K(n, e, [G("vp", 3)]), K(n, e, [G("vp", 2)], { repeat: !0 });
	else if (n.id === "oumuamua") K(n, e, [G("vp", 25)], { fossil: 4 }), K(n, e, [
		G("vp", 3),
		Ne(t),
		Me("fossil", t, 1)
	]), K(n, e, [G("vp", 3), Ne(t)]), K(n, e, [G("vp", 2), Me("fossil", t, 1)]), K(n, e, [G("vp", 6)], {
		fossil: 1,
		repeat: !0
	});
	else if (n.id === "centaurians") K(n, e, [G("vp", 5), Ne(t)]), K(n, e, [G("vp", 3), Ne(t)]), K(n, e, [G("vp", 5)]), K(n, e, [G("vp", 15)], { cost: 3 }), K(n, e, [G("vp", 6)], {
		cost: 1,
		repeat: !0
	});
	else for (let t = 0; t < 5; t++) K(n, e, [G("vp", e === "red" ? [
		9,
		7,
		5,
		4,
		3
	][t] : [
		6,
		4,
		2,
		1,
		3
	][t]), ...e === "red" ? [G(t === 4 ? "publicity" : "credit", 1)] : e === "yellow" ? t === 4 ? [G("publicity", 1)] : [G("energy", 1), {
		kind: "draw",
		n: 1
	}] : t === 4 ? [G("publicity", 1)] : [G("data", 1), G("publicity", 1)]], { danger: t < 2 ? 3 : t < 4 ? 2 : 1 });
	if (n.id === "mascamites") {
		let t = Je(e, [
			0,
			1,
			2,
			3,
			4,
			5,
			6
		]);
		n.samples.jupiter = t.splice(0, 3), n.samples.saturn = t.splice(0, 3), K(n, "blue", Fe[t[0]], { sample: t[0] });
	}
	if (n.id === "centaurians") for (let t of e.players) n.messages.push({
		owner: t.rid,
		threshold: t.vp + 15,
		card: null
	});
	if (n.id === "oumuamua") {
		let t = Re(e);
		for (let n of e.probes) n.ring === t.ring && n.sector === t.sector && X(Xe(e, n.owner), "publicity", 1);
	}
	if (n.id === "anomalies") {
		let t = H(e.angles, "earth").sector;
		e.anomalies = Je(e, Pe.slice()).map((n, r) => ({
			color: n,
			sector: R(t + [
				0,
				-3,
				3
			][r]),
			reward: qe(e) < .5 ? n === "yellow" ? [{
				kind: "draw",
				n: 1
			}] : [G(n === "red" ? "vp" : "energy", n === "red" ? 4 : 1)] : [G(n === "red" ? "credit" : n === "yellow" ? "publicity" : "data", n === "yellow" ? 2 : 1)]
		}));
	}
}
function Re(e) {
	return H(e.angles, "oumuamua");
}
function q(e, t) {
	let n = Re(e);
	return e.species.some((e) => e.id === "oumuamua" && e.revealed) && t.ring === n.ring && t.sector === n.sector ? "oumuamua" : V(e.angles, t).planet;
}
function ze(e) {
	let t = H(e.angles, "earth").sector, n = e.species.find((e) => e.id === "anomalies" && e.revealed);
	if (n) for (let r of e.anomalies.filter((e) => e.sector === t)) {
		let t = n.research.filter((e) => e.color === r.color && e.owners.length).at(-1)?.owners.at(-1);
		t && Ie(e, t, structuredClone(r.reward));
	}
}
function Be(e) {
	let t = H(e.angles, "earth").sector;
	return [...e.anomalies].sort((e, n) => (R(t - e.sector) || 8) - (R(t - n.sector) || 8))[0];
}
function Ve(e, t) {
	for (let n = 0; n < e.species.length; n++) {
		let r = e.species[n], i = r.messages.find((e) => e.owner === t.rid);
		if (i && t.vp >= i.threshold) return Me(i.card ? "resolveMessage" : "messageBonus", n, void 0, i.card ?? void 0);
		let a = r.dangerThresholds.findIndex((e, n) => t.vp >= e && !t.exertianReached.includes(n));
		if (a >= 0) return Me("secretMilestone", n, a);
	}
	return null;
}
function He(e, t, n, r) {
	let i = F(r.id), a = e.species.findIndex((e) => e.id === i.species);
	return structuredClone(n).map((n) => n.kind === "alien" ? {
		...n,
		species: a,
		card: r
	} : n.kind === "if" ? {
		...n,
		effects: He(e, t, n.effects, r)
	} : n.kind === "scan" && !n.todo.length ? {
		...n,
		todo: [
			"earth",
			"row",
			...t.techs.includes("t1") ? ["hand"] : [],
			...t.techs.includes("t2") ? ["mercury"] : [],
			...t.techs.includes("t3") ? ["probe"] : []
		]
	} : n);
}
function Ue(e, t, n) {
	e.species.find((e) => e.id === "centaurians").messages.push({
		owner: t.rid,
		threshold: t.vp + 15,
		card: n
	});
}
function We(e, t, n) {
	let r = [], i = e.species[n.species], a = (e, t, n = {}) => r.push({
		id: e,
		key: t,
		group: "effect",
		...n
	});
	switch (n.op) {
		case "draw":
			i.market.forEach((e) => a(`alienDraw:${e.uid}`, "games.seti.takeCard", { card: e.uid })), i.deck.length && a("alienDraw:deck", "games.seti.drawCard");
			break;
		case "secretPlay":
		case "secretMilestone":
			(n.op === "secretPlay" || n.n === 0 || t.credit > 0) && t.secret.forEach((e) => a(`alienSecret:${e.uid}`, "games.seti.playSecret", { card: e.uid })), a("alienSecret:skip", "games.seti.declineMission");
			break;
		case "messageBonus":
			[
				0,
				1,
				2,
				3
			].forEach((e) => {
				i.messageRewards[e] || a(`alienMessageBonus:${e}`, [
					"games.seti.messageBonuses.trace",
					"games.seti.messageBonuses.cardEnergy",
					"games.seti.messageBonuses.publicity",
					"games.seti.messageBonuses.points"
				][e], { n: e });
			});
			break;
		case "collect": {
			let t = e.turn.landingSite?.planet;
			(t === "jupiter" || t === "saturn") && i.samples[t].forEach((e) => a(`alienSample:${t}:${e}`, de[e], { n: e }));
			break;
		}
		case "deliver":
			for (let r of e.probes.filter((r) => r.owner === t.rid && r.sample !== void 0 && V(e.angles, r).planet === F(n.card.id).mission.condition.metric.target)) a(`alienDeliver:${r.uid}`, de[r.sample], { card: r.uid });
			break;
		case "inspectHere":
			for (let n of ["jupiter", "saturn"]) e.probes.some((r) => r.owner === t.rid && q(e, r) === n) && i.samples[n].forEach((e) => a(`alienSample:${n}:${e}`, de[e], { n: e }));
			break;
		case "inspectAny":
			for (let e of ["jupiter", "saturn"]) i.samples[e].forEach((t) => a(`alienSample:${e}:${t}`, de[t], { n: t }));
			break;
		case "sampleOrbitLand":
			e.probes.filter((n) => n.owner === t.rid && n.sample === void 0 && q(e, n) && q(e, n) !== "earth").forEach((e) => a(`alienOrbit:${e.uid}`, "games.seti.freeOrbit", { card: e.uid })), a("alienLand", "games.seti.freeLanding");
			break;
		case "discardCorner":
		case "discardIncome":
			t.hand.filter((e) => !n.selected || n.selected.includes(e.uid)).forEach((e) => a(`alienDiscard:${e.uid}`, "games.seti.discardCard", { card: e.uid }));
			break;
		case "fossilData":
		case "fossilMove":
		case "fossilSignal":
			t.fossil && a("alienFossil:spend", "games.seti.spendFossil"), a("alienFossil:skip", "games.seti.declineMission");
			break;
		default: a("alienContinue", "games.seti.continue");
	}
	return r.length || a("alienContinue", "games.seti.continue"), r;
}
function Ge(e, t, n, r) {
	Ze(e).shift();
	let i = e.species[n.species], a = r.id.split(":");
	switch (n.op) {
		case "draw": {
			let e = a[1] === "deck" ? i.deck.shift() : i.market.find((e) => e.uid === a[1]);
			e && (t.hand.push(e), i.market = i.market.filter((t) => t.uid !== e.uid), i.market.length || i.market.push(...i.deck.splice(0, 1)));
			break;
		}
		case "secretPlay":
		case "secretMilestone":
			if (n.op === "secretMilestone" && t.exertianReached.push(n.n), a[1] !== "skip" && a[0] === "alienSecret") {
				let r = t.secret.find((e) => e.uid === a[1]);
				t.secret = t.secret.filter((e) => e.uid !== r.uid), t.secretPlayed.push(r), n.op === "secretMilestone" && n.n === 1 && t.credit--, n.op === "secretPlay" && n.n > 1 && Y(e, [Me("secretPlay", n.species, n.n - 1)]);
			}
			break;
		case "messageBonus": {
			let a = r.n;
			i.messageRewards[a] = t.rid, i.messages.splice(i.messages.findIndex((e) => e.owner === t.rid && !e.card), 1), Y(e, a === 0 ? [{
				kind: "trace",
				color: "any"
			}] : a === 1 ? [Ne(n.species), G("energy", 1)] : [G(a === 2 ? "publicity" : "vp", a === 2 ? 3 : 8)]);
			break;
		}
		case "resolveMessage": {
			i.messages.splice(i.messages.findIndex((e) => e.card?.uid === n.card.uid), 1);
			let r = n.card.id;
			[
				1031,
				1032,
				1033,
				1038,
				1039,
				1040
			].includes(r) ? it(e, t, n.card) : (e.discard.push(n.card), Y(e, r === 1037 ? [G("credit", 1), {
				kind: "trace",
				color: "any"
			}] : [{
				kind: "trace",
				color: Pe[r === 1034 ? 0 : r === 1035 ? 1 : 2]
			}]));
			break;
		}
		case "collect": {
			if (a[0] !== "alienSample" || !e.turn.landingSite || !n.card) break;
			let o = a[1], s = r.n;
			i.samples[o] = i.samples[o].filter((e) => e !== s), e.probes.push({
				...e.turn.landingSite,
				uid: Ye(e, "capsule"),
				owner: t.rid,
				sample: s,
				mission: n.card.uid
			});
			break;
		}
		case "deliver": {
			let r = e.probes.find((e) => e.owner === t.rid && e.uid === a[1] && e.sample !== void 0);
			if (!r) break;
			e.probes = e.probes.filter((e) => e.uid !== r.uid), K(i, "blue", Fe[r.sample], { sample: r.sample }), Y(e, Array.from({ length: n.n ?? 1 }, () => Fe[r.sample]).flat());
			break;
		}
		case "inspectHere":
		case "inspectAny":
			a[0] === "alienSample" && (e.sampleReveals.push({
				owner: t.rid,
				planet: a[1],
				sample: r.n
			}), Y(e, Fe[r.n]));
			break;
		case "sampleOrbitLand":
			r.id === "alienLand" ? Y(e, [{
				kind: "land",
				override: !1
			}]) : a[0] === "alienOrbit" && Y(e, [Me("orbit", n.species, void 0, {
				id: 0,
				uid: a[1]
			})]);
			break;
		case "nextAnomaly": {
			let t = Be(e);
			t && Y(e, t.reward);
			break;
		}
		case "nextAnomalySignal": {
			let t = Be(e);
			t && Y(e, [{
				kind: "signal",
				sectors: [t.sector]
			}]);
			break;
		}
		case "launchAnomalyMove":
			e.anomalies.some((t) => t.sector === H(e.angles, "earth").sector) && Y(e, [{
				kind: "move",
				n: 1
			}]);
			break;
		case "anomalySignalScore":
			X(t, "vp", e.anomalies.reduce((n, r) => n + e.sectors[r.sector].signals.filter((e) => e === t.rid).length, 0));
			break;
		case "noPublicity":
			e.turn.noPublicity = !0;
			break;
		case "takeRow":
			t.hand.push(...e.market.splice(0)), et(e);
			break;
		case "drawThree": {
			let r = [];
			for (let t = 0; t < 3; t++) {
				let t = $e(e);
				t && r.push(t);
			}
			t.hand.push(...r), Y(e, [{
				kind: "alien",
				op: "discardCorner",
				species: n.species,
				selected: r.map((e) => e.uid)
			}]);
			break;
		}
		case "discardCorner":
		case "discardIncome": {
			let r = t.hand.find((e) => e.uid === a[1]);
			if (!r) break;
			if (t.hand = t.hand.filter((e) => e.uid !== r.uid), e.discard.push(r), n.op === "discardCorner") Y(e, [...Tt(r), {
				kind: "alien",
				op: "discardIncome",
				species: n.species,
				selected: n.selected?.filter((e) => e !== r.uid)
			}]), Z(e, t.rid, "discard", F(r.id).free);
			else {
				let n = F(r.id).income;
				n === "card" ? Y(e, [{
					kind: "draw",
					n: 1
				}]) : X(t, n, 1);
			}
			break;
		}
		case "fossil":
			t.fossil += n.n ?? 1;
			break;
		case "spendFossil":
			t.fossil -= n.n ?? 1;
			break;
		case "fossilData":
		case "fossilMove":
		case "fossilSignal":
			a[1] === "spend" && (t.fossil--, Y(e, n.op === "fossilData" ? [G("data", 1)] : n.op === "fossilSignal" ? [{
				kind: "targetSignal",
				target: "any",
				n: 1
			}] : [{
				kind: "move",
				n: 2
			}, n]));
			break;
		case "landOumuamuaScore":
			e.turn.landings.includes("oumuamua") && X(t, "vp", 3);
			break;
		case "scanFossil":
		case "scanFossilVP": e.turn.oumuamuaSignals = 0, e.turn.scanBonus = n.op === "scanFossil" ? "fossil" : "vp";
	}
}
function Ke(e) {
	for (let t of e.finalScores) {
		let n = Xe(e, t.owner);
		t.aliens = n.secretPlayed.reduce((t, r) => {
			let i = se[r.id - 2001];
			return t + (ke(e, n, i.condition) ? i.vp : 0);
		}, 0), t.total = t.base + t.cards + t.gold + t.aliens;
	}
	if (e.species.some((e) => e.revealed && e.id === "exertians")) {
		let t = e.players.map((e) => e.danger + e.secretPlayed.reduce((e, t) => e + F(t.id).danger, 0)), n = Math.max(...t);
		e.finalScores.forEach((e, r) => {
			t[r] === n && (e.penalty = Math.floor(e.total / 10), e.total -= e.penalty);
		});
	}
}
//#endregion
//#region src/games/seti/engine.ts
function qe(e) {
	return e.seed = Math.imul(e.seed, 1664525) + 1013904223 >>> 0, e.seed / 4294967296;
}
function Je(e, t) {
	for (let n = t.length - 1; n > 0; n--) {
		let r = Math.floor(qe(e) * (n + 1));
		[t[n], t[r]] = [t[r], t[n]];
	}
	return t;
}
var Ye = (e, t) => `${t}${++e.serial}`, J = (e) => e.players[e.active], Xe = (e, t) => e.players.find((e) => e.rid === t), Ze = (e) => e.responses[0]?.flow ?? e.turn.free ?? e.turn.flow, Y = (e, t) => Ze(e).unshift(...structuredClone(t)), Qe = (e, t, n, r) => {
	e.log.push({
		owner: t,
		key: n,
		...r ? { params: r } : {}
	}), e.log = e.log.slice(-60);
};
function X(e, t, n) {
	e[t] = Math.min(t === "data" ? 6 : t === "publicity" ? 10 : Infinity, e[t] + n);
}
function $e(e) {
	return e.deck.length || (e.deck = Je(e, e.discard.splice(0))), e.deck.shift();
}
function et(e) {
	for (; e.market.length < 3;) {
		let t = $e(e);
		if (!t) break;
		e.market.push(t);
	}
}
function Z(e, t, n, r) {
	let i = {
		id: ++e.serial,
		owner: t,
		kind: n,
		turn: e.turnNumber,
		...r ? { target: r } : {}
	};
	e.events.push(i);
	let a = Xe(e, t).missions.flatMap((i) => {
		let a = F(i.card.id).mission;
		if (!a || i.card.id === 129 && J(e).rid !== t) return [];
		let o = (e) => (e.kind === n || i.card.id === 117 && n === "orbit") && (!e.target || e.target === r || e.target === "planet" && n === "visit" && r !== "earth" && r !== "comet" && r !== "asteroid");
		return a.rewards.flatMap((e, t) => !i.circles.includes(t) && (a.events ? o(a.events[t]) : a.event && o(a.event)) ? [{
			uid: i.card.uid,
			circle: t
		}] : []);
	});
	a.length && e.responses.push({
		owner: t,
		event: i.id,
		options: a
	});
}
function tt(e, t) {
	let n = Xe(e, t.owner), r = V(e.angles, t, e.species.some((e) => e.id === "oumuamua" && e.revealed));
	!(e.turn.noPublicity && J(e).rid === n.rid) && (r.planet && r.planet !== "earth" || r.comet || r.asteroid && n.techs.includes("p1")) && (r.planet && e.turn.slingshot && J(e).rid === n.rid ? Y(e, [{
		kind: "choose",
		options: [{
			effects: [{
				kind: "gain",
				resource: "publicity",
				n: 1
			}],
			resource: "publicity",
			n: 1
		}, {
			effects: [{
				kind: "move",
				n: 1
			}],
			resource: "move",
			n: 1
		}]
	}]) : X(n, "publicity", 1)), r.asteroid && Z(e, n.rid, "visit", "asteroid"), r.comet && Z(e, n.rid, "visit", "comet"), r.planet && (n.rid === J(e).rid && e.turn.lightsail && !e.turn.lightsail.includes(r.planet) && (e.turn.lightsail.push(r.planet), X(n, "vp", 1)), Z(e, n.rid, "visit", r.planet));
}
function nt(e) {
	let t = e.angles, n = Ce(t, e.nextDisc), r = e.probes.map((r) => we(t, n, e.nextDisc, r));
	e.angles = n, e.probes.forEach((n, i) => {
		let a = Se(t, n) > e.nextDisc && n.sector !== r[i].sector;
		Object.assign(n, r[i]), a && (n.owner === J(e).rid && (e.turn.sameRing = !0), tt(e, n));
	}), Qe(e, J(e).rid, "games.seti.log.rotate", { n: e.nextDisc + 1 }), e.nextDisc = (e.nextDisc + 1) % 3, ze(e);
}
function rt(e, t) {
	if (e.length < 2 || e.length > 4 || new Set(e).size !== e.length) throw Error("SETI requires 2–4 distinct seats");
	let n = {
		phase: "setup",
		seed: t >>> 0,
		serial: 0,
		players: [],
		active: 0,
		setupIndex: 0,
		angles: [
			0,
			0,
			0
		],
		nextDisc: 0,
		probes: [],
		figures: [],
		sectors: [],
		species: [],
		deck: [],
		discard: [],
		market: [],
		techRewards: {},
		researched: {},
		turn: U(),
		responses: [],
		events: [],
		neutral: [],
		gold: [
			0,
			0,
			0,
			0
		],
		log: [],
		anomalies: [],
		sampleReveals: [],
		round: 1,
		first: 0,
		turnNumber: 1,
		roundDecks: [],
		roundOffer: null,
		roundWait: null,
		roundDrafted: [],
		goldFaces: [],
		finalScores: [],
		ending: !1,
		finalChoices: []
	};
	n.deck = Je(n, ue.filter((e) => !e.species).map((e) => ({
		id: e.id,
		uid: Ye(n, "c")
	}))), n.angles = [
		0,
		0,
		0
	].map(() => Math.floor(qe(n) * 8)), n.sectors = Je(n, [
		0,
		1,
		2,
		3
	]).flatMap((e) => ye.slice(e * 2, e * 2 + 2).map((e) => ({
		...e,
		signals: [],
		winners: []
	}))), n.species = Je(n, [
		"mascamites",
		"anomalies",
		"oumuamua",
		"centaurians",
		"exertians"
	]).slice(0, 2).map((e) => ({
		id: e,
		traces: [
			null,
			null,
			null
		],
		overflow: [],
		overflowColors: [],
		revealed: !1,
		research: [],
		deck: [],
		market: [],
		samples: {
			jupiter: [],
			saturn: []
		},
		messages: [],
		messageRewards: [
			,
			,
			,
			,
		].fill(""),
		signals: [],
		dangerThresholds: []
	}));
	for (let e of me) n.techRewards[e.id] = Je(n, [
		"publicity",
		"energy",
		"pickCard",
		"vp"
	]);
	return n.players = e.map((e, t) => ({
		rid: e,
		credit: 4,
		energy: 3,
		publicity: 4,
		data: 0,
		vp: t + 1,
		hand: n.deck.splice(0, 5),
		income: [],
		missions: [],
		played: [],
		techs: [],
		computer: 0,
		lower: [],
		installed: [
			,
			,
			,
			,
			,
			,
		].fill(null),
		passed: !1,
		gold: [],
		goldRates: [],
		fossil: 0,
		danger: 0,
		secret: [],
		secretPlayed: [],
		exertianReached: []
	})), n.roundDecks = Array.from({ length: 4 }, () => n.deck.splice(0, e.length + 1)), n.goldFaces = Array.from({ length: 4 }, () => Math.floor(qe(n) * 2)), et(n), n;
}
function it(e, t, n) {
	t.hand = t.hand.filter((e) => e.uid !== n.uid), t.income.push(n);
	let r = F(n.id).income;
	if (r === "card") {
		let n = $e(e);
		n && t.hand.push(n);
	} else X(t, r, 1);
}
var at = (e, t) => e.probes.filter((e) => e.owner === t.rid && e.sample === void 0).length < (t.techs.includes("p0") ? 2 : 1);
function ot(e, t, n = !1) {
	if (!n && !at(e, t)) return;
	let r = {
		...H(e.angles, "earth"),
		owner: t.rid,
		uid: Ye(e, "p")
	};
	e.probes.push(r), Qe(e, t.rid, "games.seti.log.launch"), Z(e, t.rid, "launch");
}
function st(e, t, n, r = !1) {
	if (n === 8) {
		let n = e.species.find((e) => e.id === "oumuamua" && e.revealed);
		n.signals.length < 3 && (r || X(t, "data", 1), n.signals.length === 0 && X(t, "vp", 1), n.signals.length === 2 && X(t, "vp", 2)), n.signals.push(t.rid), !e.turn.free && !e.responses.length && e.turn.scanBonus && e.turn.oumuamuaSignals++, n.signals.length === 3 && t.rid === J(e).rid && e.turn.completedSectors.push(8), t.rid === J(e).rid && !e.turn.free && !e.responses.length && e.turn.stage === "main" && e.turn.actionSignals.push(8), e.turn.scanBonus === "vp" && !e.turn.free && !e.responses.length && X(t, "vp", 2), Z(e, t.rid, "signal", e.sectors[Re(e).sector].color);
		return;
	}
	let i = e.sectors[n];
	i.signals.length < i.capacity && (r || X(t, "data", 1), i.signals.length === 1 && X(t, "vp", 2)), i.signals.push(t.rid), i.signals.length === i.capacity && t.rid === J(e).rid && e.turn.completedSectors.push(n), t.rid === J(e).rid && !e.turn.free && !e.responses.length && e.turn.stage === "main" && e.turn.actionSignals.push(n), Z(e, t.rid, "signal", i.color), Qe(e, t.rid, "games.seti.log.signal", { n: n + 1 });
}
function ct(e, t) {
	return e.sectors.flatMap((e, n) => e.color === F(t).color ? [n] : []);
}
var lt = (e, t, n, r, i = null) => e.figures.some((e) => e.planet === t && e.kind === n && e.slot === r && e.moon === i), ut = (e, t, n) => 3 - Number(e.figures.some((e) => e.planet === n && e.kind === "orbiter")) - Number(t.techs.includes("p2"));
function dt(e) {
	if (e.responses[0]?.flow?.length === 0 && e.responses.shift(), e.turn.free?.length === 0 && (e.turn.free = null), e.phase !== "playing" || e.responses.length || e.turn.free) return;
	if (!e.turn.flow.length) {
		e.turn.effectOwner = null;
		let t = e.turn.bonuses.filter((t) => ke(e, J(e), t.condition));
		e.turn.bonuses = e.turn.bonuses.filter((e) => !t.includes(e)), e.turn.flow.push(...t.flatMap((e) => e.effects));
	}
	e.turn.stage === "main" && !e.turn.flow.length && (e.turn.stage = "sectors");
	let t = e.sectors.some((e) => e.signals.length >= e.capacity) || e.species.some((e) => e.id === "oumuamua" && e.signals.length >= 3);
	!e.turn.flow.length && t && (e.turn.stage === "after" || e.turn.endRequested) && (e.turn.stage = "sectors"), e.turn.stage === "sectors" && !e.turn.flow.length && !t && (e.turn.stage = "after"), e.turn.endRequested && !e.turn.flow.length && !t && yt(e);
}
function ft(e) {
	for (let t = 0; t < e.players.length; t++) {
		let n = e.players[(e.active + t) % e.players.length];
		if (n.gold.length < [
			25,
			50,
			70
		].filter((e) => n.vp >= e).length || Ve(e, n)) return n.rid;
	}
	return null;
}
function pt(e) {
	return e.phase === "finished" ? null : e.ending ? e.finalChoices[0] ?? null : e.roundOffer && (!e.roundOffer.deferred || e.roundWait || e.players.every((e) => e.passed)) ? e.roundOffer.owner : e.responses[0]?.owner ?? e.turn.effectOwner ?? (e.turn.endRequested && e.turn.stage !== "sectors" ? ft(e) : null) ?? (e.phase === "setup" ? e.players[e.setupIndex].rid : J(e).rid);
}
function mt(e, t, n) {
	let r = [], i = (e, t, n = {}) => r.push({
		id: e,
		key: t,
		group: "effect",
		...n
	});
	switch (n.kind) {
		case "move":
			if (n.n > 0) for (let r of e.probes.filter((e) => e.owner === t.rid)) {
				let a = V(e.angles, r).asteroid && !t.techs.includes("p1") && !e.turn.ignoreAsteroid ? 2 : 1;
				if (a <= n.n + t.energy) for (let e of Te(r)) i(`move:${r.uid}:${e.ring}:${e.sector}`, a > n.n ? "games.seti.moveWithEnergy" : "games.seti.moveTo", {
					target: e,
					card: r.uid,
					n: a,
					params: {
						ring: e.ring,
						sector: e.sector + 1,
						n: a > n.n ? a - n.n : a
					}
				});
			}
			i("effect:skip", "games.seti.finishMovement");
			break;
		case "research":
			if (!n.rotated) i("effect:rotateResearch", "games.seti.rotateResearch");
			else for (let r of me.filter((r) => (n.family === "any" || n.family === "space" && r.family !== "computer" || r.family === n.family) && !t.techs.includes(r.id) && e.techRewards[r.id].length && (!n.collaboration || e.players.some((e) => e.rid !== t.rid && e.techs.includes(r.id))))) i(`tech:${r.id}`, r.name, { tech: r.id });
			r.length || i("effect:skip", "games.seti.continue");
			break;
		case "install":
			for (let e = 0; e < 6; e++) t.installed[e] || i(`install:${e}`, "games.seti.installTech", {
				n: e,
				tech: n.tech,
				params: { n: e + 1 }
			});
			break;
		case "income":
			for (let e of t.hand) i(`income:${e.uid}`, "games.seti.tuck", { card: e.uid });
			i("effect:skip", "games.seti.skipIncome");
			break;
		case "pickCard":
			e.market.forEach((e) => i(`pick:${e.uid}`, "games.seti.takeCard", { card: e.uid })), (e.deck.length || e.discard.length) && i("pick:deck", "games.seti.drawCard"), r.length || i("effect:skip", "games.seti.continue");
			break;
		case "rowSignals":
			for (let t of e.market) for (let n of ct(e, t.id)) i(`row:${t.uid}:${n}`, "games.seti.discardSignal", {
				card: t.uid,
				n,
				params: { n: n + 1 }
			});
			r.length || i("effect:skip", "games.seti.continue");
			break;
		case "handSignal":
			for (let n of t.hand) for (let t of ct(e, n.id)) i(`handSignal:${n.uid}:${t}`, "games.seti.discardSignal", {
				card: n.uid,
				n: t,
				params: { n: t + 1 }
			});
			(n.optional || !r.length) && i("effect:skip", "games.seti.continue");
			break;
		case "choose":
			n.options.forEach((e, t) => i(`option:${t}`, "games.seti.chooseReward", {
				n: t,
				params: {
					n: e.n ?? 1,
					resource: e.resource ?? "vp"
				}
			}));
			break;
		case "targetSignal": {
			let a = e.sectors.findIndex((e) => e.id === n.target);
			if (a >= 0) i(`targetSignal:${a}`, "games.seti.markSector", {
				n: a,
				params: { n: a + 1 }
			});
			else if (n.locked !== void 0) i(`targetSignal:${n.locked}`, "games.seti.markSector", {
				n: n.locked,
				params: { n: n.locked + 1 }
			});
			else if (n.target === "probe" || n.target === "anyProbe") for (let r of e.probes.filter((e) => (n.target === "anyProbe" || e.owner === t.rid) && !n.selected?.includes(e.uid))) i(`targetSignal:${r.sector}:${r.uid}`, "games.seti.markSector", {
				card: r.uid,
				n: r.sector,
				params: { n: r.sector + 1 }
			});
			else if ([
				"red",
				"yellow",
				"blue",
				"black",
				"any"
			].includes(n.target)) e.sectors.forEach((e, t) => {
				(n.target === "any" || e.color === n.target) && i(`targetSignal:${t}`, "games.seti.markSector", {
					n: t,
					params: { n: t + 1 }
				});
			});
			else {
				let t = H(e.angles, n.target);
				i(`targetSignal:${t.sector}`, "games.seti.markSector", {
					n: t.sector,
					params: { n: t.sector + 1 }
				});
			}
			(!r.length || n.target === "anyProbe") && i("effect:skip", "games.seti.finishSignals");
			break;
		}
		case "project":
			if (n.id === 17) for (let n of e.probes.filter((e) => e.owner === t.rid)) i(`projectProbe:${n.uid}`, "games.seti.selectProbe", { card: n.uid });
			else n.id === 75 ? [
				"red",
				"yellow",
				"blue"
			].forEach((e, t) => i(`projectColor:${e}`, "games.seti.chooseTraceColor", {
				n: t,
				params: { n: t + 1 }
			})) : n.id === 102 ? e.species.forEach((n, r) => {
				[
					"red",
					"yellow",
					"blue"
				].every((n) => W(e, t, n, r) > 0) && i(`projectSpecies:${r}`, "games.seti.markTrace", {
					species: r,
					params: {
						n: r + 1,
						color: 0
					}
				});
			}) : i("effect:continue", "games.seti.continue");
			r.length || i("effect:skip", "games.seti.continue");
			break;
		case "goldScore":
			[
				0,
				1,
				2,
				3
			].filter((e) => !t.gold.includes(e)).forEach((e) => i(`solvay:${e}`, "games.seti.markGold", {
				n: e,
				params: { n: e + 1 }
			}));
			break;
		case "alien": return We(e, t, n);
		case "signal":
			for (let e of n.sectors) i(`signal:${e}`, "games.seti.markSector", {
				n: e,
				params: { n: e + 1 }
			});
			break;
		case "earthSignal": {
			let n = H(e.angles, "earth").sector;
			(t.techs.includes("t0") ? [
				R(n - 1),
				n,
				R(n + 1)
			] : [n]).forEach((e) => i(`signal:${e}`, "games.seti.markSector", {
				n: e,
				params: { n: e + 1 }
			}));
			break;
		}
		case "mercurySignal":
			i(`signal:${H(e.angles, "mercury").sector}`, "games.seti.markSector", {
				n: H(e.angles, "mercury").sector,
				params: { n: H(e.angles, "mercury").sector + 1 }
			});
			break;
		case "scan":
			for (let e of n.todo) (e === "earth" || e === "row" || e === "hand" && t.hand.length || e === "mercury" && t.publicity >= 1 || e === "probe") && i(`scan:${e}`, {
				earth: "games.seti.scanEarth",
				row: "games.seti.scanRow",
				hand: "games.seti.scanHand",
				mercury: "games.seti.scanMercury",
				probe: "games.seti.scanProbe"
			}[e]);
			!n.todo.includes("earth") && !n.todo.includes("row") && i("effect:endScan", "games.seti.finishScan");
			break;
		case "scanProbe":
			at(e, t) && t.energy >= 1 && i("effect:launch", "games.seti.scanLaunch"), i("effect:scanMove", "games.seti.gainMove");
			break;
		case "trace": {
			let a = [
				"red",
				"yellow",
				"blue"
			];
			e.species.forEach((r, o) => {
				(n.species === void 0 || n.species === o) && (!n.requireOwn || W(e, t, n.color === "any" ? void 0 : n.color, o)) && (a.forEach((e, t) => {
					(n.color === "any" || n.color === e) && !r.traces[t] && i(`trace:${o}:${t}`, "games.seti.markTrace", {
						species: o,
						n: t,
						params: {
							n: o + 1,
							color: t + 1
						}
					});
				}), r.revealed && r.research.forEach((e, r) => {
					(n.color === "any" || n.color === e.color) && (!e.owners.length || e.repeat) && t.data >= e.cost && t.fossil >= (e.fossil ?? 0) && i(`trace:${o}:research:${r}`, "games.seti.researchTrace", {
						species: o,
						n: r,
						params: { n: r + 1 }
					});
				}), a.forEach((e, t) => {
					(n.color === "any" || n.color === e) && i(`trace:${o}:overflow:${e}`, "games.seti.overflowColor", {
						species: o,
						n: t,
						params: {
							n: o + 1,
							color: t + 1
						}
					});
				}));
			}), r.length || i("effect:skip", "games.seti.continue");
			break;
		}
		case "land":
			for (let r of e.probes.filter((n) => n.owner === t.rid && n.sample === void 0 && (!e.turn.landingProbe || n.uid === e.turn.landingProbe))) {
				let a = q(e, r), o = ve.find((e) => e.id === a);
				if (!o) continue;
				let s = o.first.flatMap((t, r) => !lt(e, o.id, "lander", r) || n.override ? [r] : []);
				s.length || s.push(-1);
				for (let e of s) i(`land:${r.uid}:planet:${e}`, "games.seti.landPlanet", {
					card: r.uid,
					n: e,
					params: { n: e < 0 ? 0 : o.first[e] }
				});
				if (t.techs.includes("p3") || n.moonAccess) for (let t of o.moons) (!lt(e, o.id, "lander", 0, t.id) || n.override) && i(`land:${r.uid}:${t.id}:0`, t.name, { card: r.uid });
			}
			r.length || i("effect:skip", "games.seti.continue");
			break;
		case "removeOrbiter":
		case "removeLander":
			for (let r of e.figures.filter((e) => e.owner === t.rid && e.kind === (n.kind === "removeOrbiter" ? "orbiter" : "lander"))) i(`remove:${r.uid}`, "games.seti.removeFigure", { card: r.uid });
			r.length || i("effect:skip", "games.seti.continue");
			break;
		default: i("effect:continue", "games.seti.continue");
	}
	if ([
		"signal",
		"earthSignal",
		"mercurySignal",
		"rowSignals",
		"handSignal",
		"targetSignal"
	].includes(n.kind) && e.species.some((e) => e.id === "oumuamua" && e.revealed)) {
		let t = Re(e).sector;
		r.filter((e) => e.n === t).forEach((e) => r.push({
			...e,
			id: `oumuamua:${e.id}`,
			key: "games.seti.markOumuamua",
			n: 8
		}));
	}
	return r;
}
function ht(e, t) {
	let n = [], r = (e, t, r = {}) => n.push({
		id: e,
		key: t,
		group: "free",
		...r
	});
	if (t.data && t.computer < 6 && r("free:upper", "games.seti.placeUpper", {
		n: t.computer,
		params: { n: t.computer + 1 }
	}), t.data && t.installed.forEach((e, n) => {
		e && n < t.computer && !t.lower.includes(n) && r(`free:lower:${n}`, "games.seti.placeLower", {
			n,
			tech: e,
			params: { n: n + 1 }
		});
	}), t.energy > 0) for (let n of e.probes.filter((e) => e.owner === t.rid)) {
		let i = V(e.angles, n).asteroid && !t.techs.includes("p1") && !e.turn.ignoreAsteroid ? 2 : 1;
		if (t.energy >= i) for (let e of Te(n)) r(`free:move:${n.uid}:${e.ring}:${e.sector}`, "games.seti.moveTo", {
			target: e,
			card: n.uid,
			n: i,
			params: {
				ring: e.ring,
				sector: e.sector + 1,
				n: i
			}
		});
	}
	for (let e of t.hand) r(`free:discard:${e.uid}`, "games.seti.discardBonus", { card: e.uid });
	for (let e of [
		"credit",
		"energy",
		"card"
	]) for (let n of [
		"credit",
		"energy",
		"card"
	]) if (e === "card" && t.hand.length >= 2) for (let i = 0; i < t.hand.length; i++) for (let a = i + 1; a < t.hand.length; a++) r(`free:exchange:${e}:${n}:${t.hand[i].uid}:${t.hand[a].uid}`, "games.seti.exchange", {
		params: {
			from: e,
			to: n
		},
		card: t.hand[i].uid
	});
	else e !== "card" && t[e] >= 2 && e !== n && r(`free:exchange:${e}:${n}`, "games.seti.exchange", { params: {
		from: e,
		to: n
	} });
	t.publicity >= 3 && (e.market.forEach((e) => r(`free:buy:${e.uid}`, "games.seti.buyCard", { card: e.uid })), r("free:buy:deck", "games.seti.buyDeck"));
	for (let n of t.missions) {
		let i = F(n.card.id).mission;
		i?.condition && !n.circles.length && ke(e, t, i.condition) && r(`free:mission:${n.card.uid}`, "games.seti.completeMission", { card: n.card.uid });
	}
	return n;
}
function gt(e, t) {
	if (pt(e) !== t) return [];
	let n = Xe(e, t);
	if (e.ending) return [
		0,
		1,
		2,
		3
	].filter((e) => !n.gold.includes(e)).map((e) => ({
		id: `solvay:${e}`,
		key: "games.seti.markGold",
		group: "effect",
		n: e,
		params: { n: e + 1 }
	}));
	if (e.roundOffer && (!e.roundOffer.deferred || e.roundWait || e.players.every((e) => e.passed))) {
		let t = e.roundOffer.cards.map((e) => ({
			id: `roundCard:${e.uid}`,
			key: "games.seti.takeCard",
			group: "effect",
			card: e.uid
		}));
		return !e.roundWait && !e.players.every((e) => e.passed) && t.push({
			id: "roundCard:defer",
			key: "games.seti.deferRoundCard",
			group: "effect"
		}), t;
	}
	if (e.responses[0]?.flow?.length) return mt(e, n, e.responses[0].flow[0]);
	if (e.responses.length) return [...e.responses[0].options.filter((e) => !n.missions.find((t) => t.card.uid === e.uid)?.circles.includes(e.circle)).map((e) => ({
		id: `claim:${e.uid}:${e.circle}`,
		key: "games.seti.claimMission",
		group: "response",
		card: e.uid,
		n: e.circle,
		params: { n: e.circle + 1 }
	})), {
		id: "response:skip",
		key: "games.seti.declineMission",
		group: "response"
	}];
	if (e.phase === "setup") return n.hand.map((e) => ({
		id: `setup:${e.uid}`,
		key: "games.seti.tuck",
		group: "effect",
		card: e.uid
	}));
	if (e.turn.stage === "sectors") return e.turn.flow.length ? mt(e, n, e.turn.flow[0]) : [...e.sectors.flatMap((e, t) => e.signals.length >= e.capacity ? [{
		id: `settle:${t}`,
		key: "games.seti.resolveSector",
		group: "effect",
		n: t,
		params: { n: t + 1 }
	}] : []), ...e.species.some((e) => e.id === "oumuamua" && e.signals.length >= 3) ? [{
		id: "settle:oumuamua",
		key: "games.seti.resolveOumuamua",
		group: "effect"
	}] : []];
	if (e.turn.endRequested && Ze(e).length) return mt(e, n, Ze(e)[0]);
	if (e.turn.endRequested) {
		if (n.gold.length < [
			25,
			50,
			70
		].filter((e) => n.vp >= e).length) return [
			0,
			1,
			2,
			3
		].filter((e) => !n.gold.includes(e)).map((e) => ({
			id: `gold:${e}`,
			key: "games.seti.markGold",
			group: "effect",
			n: e,
			params: { n: e + 1 }
		}));
		let t = Ve(e, n);
		return t ? We(e, n, t) : [];
	}
	if (e.turn.stage === "closing") return n.hand.length > 4 ? n.hand.map((e) => ({
		id: `passDiscard:${e.uid}`,
		key: "games.seti.discardCard",
		group: "effect",
		card: e.uid
	})) : [{
		id: "closing:finish",
		key: "games.seti.confirmPass",
		group: "effect"
	}];
	let r = Ze(e);
	if (r[0]?.kind === "research" && r[0].rotated) {
		let t = r[0], i = me.filter((r) => (t.family === "any" || t.family === "space" && r.family !== "computer" || r.family === t.family) && !n.techs.includes(r.id) && e.techRewards[r.id].length && (!t.collaboration || e.players.some((e) => e.rid !== n.rid && e.techs.includes(r.id)))).map((e) => ({
			id: `tech:${e.id}`,
			key: e.name,
			group: "effect",
			tech: e.id
		}));
		return i.length || i.push({
			id: "effect:skip",
			key: "games.seti.continue",
			group: "effect"
		}), [...i, ...e.turn.free ? [] : ht(e, n)];
	}
	if (r.length) return [...mt(e, n, r[0]), ...e.turn.free ? [] : ht(e, n)];
	let i = ht(e, n);
	if (e.turn.stage === "after") return [...i, {
		id: "endTurn",
		key: "games.seti.endTurn",
		group: "main"
	}];
	n.credit >= 2 && at(e, n) && i.push({
		id: "main:launch",
		key: "games.seti.launch",
		group: "main"
	});
	for (let r of e.probes.filter((e) => e.owner === t)) {
		let t = r.sample === void 0 ? q(e, r) : void 0;
		t && t !== "earth" && (n.credit >= 1 && n.energy >= 1 && i.push({
			id: `orbit:${r.uid}`,
			key: "games.seti.orbit",
			group: "main",
			card: r.uid
		}), n.energy >= ut(e, n, t) && i.push(...mt(e, n, {
			kind: "land",
			override: !1
		}).filter((e) => e.card === r.uid).map((e) => ({
			...e,
			id: `mainLand:${e.id.slice(5)}`,
			group: "main"
		}))));
	}
	n.credit >= 1 && n.energy >= 2 && i.push({
		id: "main:scan",
		key: "games.seti.scan",
		group: "main"
	}), n.computer === 6 && n.energy >= 1 && i.push({
		id: "main:analyze",
		key: "games.seti.analyze",
		group: "main"
	}), n.publicity >= 6 && me.some((e) => !n.techs.includes(e.id)) && i.push({
		id: "main:research",
		key: "games.seti.research",
		group: "main"
	});
	for (let e of n.hand) n[F(e.id).energyCost ? "energy" : "credit"] >= F(e.id).cost && i.push({
		id: `play:${e.uid}`,
		key: "games.seti.playCard",
		group: "main",
		card: e.uid
	});
	return i.push({
		id: "main:pass",
		key: "games.seti.pass",
		group: "main"
	}), i;
}
function _t(e, t) {
	let n = e.sectors[t], r = [...new Set(n.signals)].sort((e, t) => n.signals.filter((e) => e === t).length - n.signals.filter((t) => t === e).length || n.signals.lastIndexOf(t) - n.signals.lastIndexOf(e));
	for (let t of r) X(Xe(e, t), "publicity", 1);
	let i = Xe(e, r[0]), a = n.winners.length === 0;
	X(i, "vp", a ? n.firstVP : n.laterVP);
	let o = a || [
		"sirius",
		"proxima",
		"virginis",
		"pictoris"
	].includes(n.id);
	n.winners.push(i.rid), n.signals = r[1] ? [r[1]] : [], o && e.turn.flow.push({
		kind: "trace",
		color: "red"
	}), o && (e.turn.effectOwner = i.rid), Qe(e, i.rid, "games.seti.log.sectorWon", { n: t + 1 });
}
function vt(e, t, n) {
	let r = e.probes.find((e) => e.uid === n), i = q(e, r), a = !lt(e, i, "orbiter", 0);
	e.probes = e.probes.filter((e) => e.uid !== r.uid), e.turn.landingSite = {
		ring: r.ring,
		sector: r.sector,
		planet: i
	}, e.figures.push({
		uid: r.uid,
		owner: t.rid,
		planet: i,
		kind: "orbiter",
		slot: a ? 0 : null,
		moon: null
	}), a && i !== "oumuamua" && X(t, "vp", 3);
	let o = e.species.findIndex((e) => e.id === "oumuamua");
	Y(e, [...a && i === "oumuamua" ? [{
		kind: "alien",
		op: "draw",
		species: o
	}] : [], ...ve.find((e) => e.id === i).orbit.map((e) => e.kind === "alien" ? {
		...e,
		species: o
	} : e)]), Z(e, t.rid, "orbit", i), Qe(e, t.rid, "games.seti.log.orbit");
}
function yt(e) {
	if (e.responses.length || Ze(e).length || ft(e)) return;
	if (e.players.length < 4) for (let t = 0; t < e.players.length; t++) {
		let n = e.players[(e.active + t) % e.players.length];
		for (let t of [20, 30]) if (n.vp >= t && !e.neutral.includes(`${t}:${n.rid}`) && e.neutral.filter((e) => e.startsWith(`${t}:`)).length < (e.players.length === 2 ? 2 : 1)) {
			e.neutral.push(`${t}:${n.rid}`);
			let r = e.species.find((e) => e.traces.includes(null));
			r && (r.traces[r.traces.indexOf(null)] = "$neutral");
		}
	}
	if (e.species.forEach((t, n) => {
		!t.revealed && t.traces.every(Boolean) && Le(e, n);
	}), e.responses.length) return;
	let t = J(e);
	if (t.passed && e.round < 5 && !e.roundDrafted.includes(t.rid)) {
		if (e.roundOffer) {
			e.roundWait = t.rid;
			return;
		}
		e.roundOffer = {
			owner: t.rid,
			cards: e.roundDecks[e.round - 1].splice(0),
			deferred: !1
		}, e.roundDrafted.push(t.rid);
		return;
	}
	if (!(e.roundOffer && e.players.every((e) => e.passed))) {
		if (e.players.every((e) => e.passed)) {
			bt(e);
			return;
		}
		do
			e.active = (e.active + 1) % e.players.length;
		while (J(e).passed);
		e.turn = U(), e.turnNumber++, e.events = e.events.filter((t) => t.turn >= e.turnNumber - 1);
	}
}
function bt(e) {
	if (e.round === 5) {
		xt(e);
		return;
	}
	let t = e.roundDecks[e.round - 1].splice(0);
	e.discard.push(...t);
	for (let t of e.players) {
		t.passed = !1, X(t, "credit", 3), X(t, "energy", 2);
		let n = $e(e);
		n && t.hand.push(n);
		for (let n of t.income) {
			let r = F(n.id).income;
			if (r === "card") {
				let n = $e(e);
				n && t.hand.push(n);
			} else X(t, r, 1);
		}
	}
	e.round++, e.first = (e.first + 1) % e.players.length, e.active = e.first, e.roundDrafted = [], e.roundWait = null, e.turn = U(), e.turnNumber++, Qe(e, J(e).rid, "games.seti.log.round", { n: e.round });
}
function xt(e) {
	e.ending = !0, e.phase = "roundEnd", e.finalScores = e.players.map((t) => ({
		owner: t.rid,
		base: t.vp,
		cards: t.played.reduce((n, r) => {
			let i = F(r.id).score;
			if (!i) return n;
			let a = Oe(e, t, i.metric);
			return n + (i.minimum ? Number(a >= i.minimum) : a) * i.multiplier;
		}, 0),
		gold: t.gold.reduce((n, r, i) => n + je(e, t, r, t.goldRates[i]), 0),
		aliens: 0,
		penalty: 0,
		total: 0
	})), e.finalChoices = e.players.filter((e) => e.played.some((e) => e.id === 113)).map((e) => e.rid), e.finalChoices.length || St(e);
}
function St(e) {
	Ke(e);
	for (let t of e.finalScores) Xe(e, t.owner).vp = t.total;
	e.phase = "finished", e.ending = !1;
}
function Ct(e, t, n, r, i) {
	n.ring === r && (e.turn.sameRing = !0), Object.assign(n, {
		ring: r,
		sector: i
	}), tt(e, n), Z(e, t.rid, "move");
}
function wt(e, t, n, r, i) {
	let a = e.probes.find((e) => e.uid === n), o = q(e, a), s = ve.find((e) => e.id === o);
	e.turn.landingSite = {
		ring: a.ring,
		sector: a.sector,
		planet: o
	}, e.probes = e.probes.filter((e) => e.uid !== n), e.figures.push({
		uid: n,
		owner: t.rid,
		planet: o,
		kind: "lander",
		moon: r === "planet" ? null : r,
		slot: i < 0 ? null : i
	}), r === "planet" ? Y(e, [
		{
			kind: "gain",
			resource: "vp",
			n: s.vp
		},
		...i < 0 ? [] : [{
			kind: "gain",
			resource: "data",
			n: s.first[i]
		}],
		...o === "oumuamua" ? [{
			kind: "alien",
			op: "fossil",
			species: e.species.findIndex((e) => e.id === "oumuamua"),
			n: 2
		}] : [{
			kind: "trace",
			color: "yellow"
		}]
	]) : Y(e, s.moons.find((e) => e.id === r).effects), e.turn.landingProbe = null, e.turn.landings.push(r === "planet" ? o : r), Z(e, t.rid, "land", o), Qe(e, t.rid, "games.seti.log.land");
}
function Tt(e) {
	let t = F(e.id);
	return t.corner ?? (t.free === "move" ? [{
		kind: "move",
		n: 1
	}] : [{
		kind: "gain",
		resource: t.free,
		n: 1
	}]);
}
function Et(e, t, n, r) {
	let i = n.source ?? e.turn.card;
	switch (n.id) {
		case 11: {
			let n = $e(e);
			n && (t.hand.push(n), Y(e, Tt(n)), Qe(e, t.rid, "games.seti.log.revealCard", { n: n.id }));
			break;
		}
		case 13:
			e.turn.landings.some((e) => ["mars", "mercury"].includes(e) || ve.some((t) => t.moons.some((t) => t.id === e))) && X(t, "vp", 4);
			break;
		case 17: {
			let n = e.probes.find((e) => e.uid === r.card);
			X(t, "data", Number(!!V(e.angles, n).asteroid) * 2 + Te(n).filter((t) => V(e.angles, t).asteroid).length);
			break;
		}
		case 19:
			e.turn.slingshot = !0;
			break;
		case 25:
			e.turn.lightsail = [...new Set(e.events.filter((n) => n.owner === t.rid && n.turn === e.turnNumber && n.kind === "visit" && (n.target === "earth" || ve.some((e) => e.id === n.target))).map((e) => e.target))], X(t, "vp", e.turn.lightsail.length);
			break;
		case 26:
			e.turn.ignoreAsteroid = !0;
			break;
		case 45:
		case 46:
		case 47:
			Y(e, [{
				kind: "if",
				condition: {
					metric: { kind: "completedSector" },
					atLeast: 1
				},
				effects: n.id === 46 ? [{
					kind: "draw",
					n: 1
				}] : [{
					kind: "gain",
					resource: n.id === 45 ? "energy" : "data",
					n: 1
				}]
			}]);
			break;
		case 72:
			e.turn.lastFamily && e.players.some((e) => e.rid !== t.rid && e.techs.some((e) => e === t.techs.at(-1))) && X(t, "publicity", 2);
			break;
		case 73: {
			let t = e.market.splice(0);
			e.discard.push(...t), Y(e, [...t.flatMap((e) => Tt(e)), { kind: "refill" }]);
			break;
		}
		case 74:
			e.turn.revealedCards = t.hand.filter((e) => F(e.id).free === "move"), Y(e, [{
				kind: "move",
				n: e.turn.revealedCards.length
			}]);
			break;
		case 75: {
			let t = r.id.split(":")[1];
			Y(e, [{
				kind: "trace",
				color: t
			}, {
				kind: "metricGain",
				metric: {
					kind: "trace",
					color: t
				},
				resource: "vp",
				multiplier: 1
			}]);
			break;
		}
		case 91:
		case 92:
		case 93:
			i && (e.discard = e.discard.filter((e) => e.uid !== i.uid), Y(e, [{
				kind: "tuckSelf",
				card: i
			}]));
			break;
		case 102:
			Y(e, [{
				kind: "trace",
				color: "any",
				species: r.species
			}]);
			break;
		case 120: {
			let n = e.turn.actionSignals.at(-1), r = n === 8 ? e.species.find((e) => e.id === "oumuamua")?.signals : e.sectors[n]?.signals;
			i && r?.filter((e) => e === t.rid).length === 1 && (e.discard = e.discard.filter((e) => e.uid !== i.uid), t.hand.push(i));
			break;
		}
		case 122: {
			let n = $e(e);
			n && (e.discard.push(n), Y(e, [{
				kind: "signal",
				sectors: ct(e, n.id)
			}]), Qe(e, t.rid, "games.seti.log.revealCard", { n: n.id }));
			break;
		}
	}
}
function Dt(e, t, n) {
	let r = Ze(e), i = r[0], a = n.id.startsWith("oumuamua:"), o = (a ? n.id.slice(9) : n.id).split(":");
	if (n.id === "effect:skip") {
		r.shift();
		return;
	}
	switch (i.kind) {
		case "gain":
			r.shift(), X(t, i.resource, i.n);
			break;
		case "draw":
			r.shift();
			for (let n = 0; n < i.n; n++) {
				let n = $e(e);
				n && t.hand.push(n);
			}
			break;
		case "publicityScore":
			r.shift(), X(t, "vp", t.publicity);
			break;
		case "techScore":
			r.shift(), X(t, "vp", t.techs.filter((t) => I(t).family === e.turn.lastFamily).length * 2);
			break;
		case "move":
			if (n.id === "effect:skip") r.shift();
			else {
				let a = e.probes.find((e) => e.uid === o[1]), s = Math.min(i.n, n.n);
				t.energy -= n.n - s, i.n -= s, Ct(e, t, a, Number(o[2]), Number(o[3])), i.n || r.shift();
			}
			break;
		case "launch":
			r.shift(), ot(e, t, i.ignoreLimit);
			break;
		case "launchWindow": {
			r.shift();
			let t = H(e.angles, "earth"), n = 0;
			for (let r = 2; r <= 4; r++) {
				let i = V(e.angles, {
					ring: r,
					sector: t.sector
				});
				(i.planet || i.comet) && n++;
			}
			n && Y(e, [{
				kind: "move",
				n
			}]);
			break;
		}
		case "income":
			r.shift(), it(e, t, t.hand.find((e) => e.uid === o[1]));
			break;
		case "pickCard": {
			r.shift();
			let n = o[1] === "deck" ? $e(e) : e.market.find((e) => e.uid === o[1]);
			n && (t.hand.push(n), o[1] !== "deck" && (e.market = e.market.filter((e) => e.uid !== n.uid))), et(e);
			break;
		}
		case "rowSignals": {
			let n = e.market.find((e) => e.uid === o[1]), s = a ? 8 : Number(o[2]);
			e.market = e.market.filter((e) => e.uid !== n.uid), e.discard.push(n), st(e, t, s), i.sectors.push(s), i.n--, i.n || r.shift();
			break;
		}
		case "refill":
			r.shift(), et(e);
			break;
		case "handSignal": {
			r.shift();
			let n = t.hand.find((e) => e.uid === o[1]);
			t.hand = t.hand.filter((e) => e.uid !== n.uid), e.discard.push(n), st(e, t, a ? 8 : Number(o[2]));
			break;
		}
		case "earthSignal":
		case "mercurySignal":
		case "signal":
			r.shift(), st(e, t, n.n);
			break;
		case "scan": {
			if (n.id === "effect:endScan") {
				r.shift(), et(e), e.turn.scanBonus === "fossil" && e.turn.oumuamuaSignals > 0 && t.fossil++, e.turn.scanBonus = null, Z(e, t.rid, "scan");
				break;
			}
			let a = o[1];
			i.todo = i.todo.filter((e) => e !== a), a === "earth" && Y(e, [{ kind: "earthSignal" }]), a === "row" && Y(e, [{
				kind: "rowSignals",
				n: 1,
				sectors: []
			}]), a === "hand" && Y(e, [{ kind: "handSignal" }]), a === "mercury" && (t.publicity--, Y(e, [{ kind: "mercurySignal" }])), a === "probe" && Y(e, [{ kind: "scanProbe" }]);
			break;
		}
		case "scanProbe":
			r.shift(), n.id === "effect:launch" ? (t.energy--, ot(e, t)) : Y(e, [{
				kind: "move",
				n: 1
			}]);
			break;
		case "research": {
			if (!i.rotated) {
				i.rotated = !0, nt(e);
				break;
			}
			r.shift();
			let n = I(o[1]);
			t.techs.push(n.id), e.turn.lastFamily = n.family, !e.researched[n.id] && !i.collaboration && X(t, "vp", 2), e.researched[n.id] = (e.researched[n.id] ?? 0) + 1;
			let a = e.techRewards[n.id].shift();
			Y(e, [
				...i.collaboration ? [] : a === "pickCard" ? [{ kind: "pickCard" }] : [{
					kind: "gain",
					resource: a,
					n: a === "vp" ? 3 : 1
				}],
				...n.bonus ?? [],
				...n.family === "computer" ? [{
					kind: "install",
					tech: n.id
				}] : []
			]), Z(e, t.rid, "research", n.family), Qe(e, t.rid, "games.seti.log.research");
			break;
		}
		case "install":
			r.shift(), t.installed[n.n] = i.tech;
			break;
		case "trace": {
			r.shift();
			let n = e.species[Number(o[1])], i = o[2] === "research" ? n.research[Number(o[3])] : null, a = i?.color ?? (o[2] === "overflow" ? o[3] : [
				"red",
				"yellow",
				"blue"
			][Number(o[2])]);
			o[2] === "overflow" ? (n.overflow.push(t.rid), n.overflowColors.push(a), X(t, "vp", 3)) : i ? (t.data -= i.cost, t.fossil -= i.fossil ?? 0, t.danger += i.danger ?? 0, i.owners.push(t.rid), Y(e, i.reward)) : (n.traces[Number(o[2])] = t.rid, X(t, "publicity", 1), X(t, "vp", Number(o[1]) === 0 ? 5 : 3)), Z(e, t.rid, "trace", a), Qe(e, t.rid, "games.seti.log.trace", { n: Number(o[1]) + 1 });
			break;
		}
		case "land":
			r.shift(), wt(e, t, o[1], o[2], Number(o[3]));
			break;
		case "removeOrbiter":
		case "removeLander":
			r.shift(), e.figures = e.figures.filter((e) => e.uid !== o[1]), Y(e, i.kind === "removeLander" ? [{
				kind: "trace",
				color: "yellow"
			}] : [
				{
					kind: "gain",
					resource: "vp",
					n: 3
				},
				{
					kind: "gain",
					resource: "data",
					n: 1
				},
				{ kind: "pickCard" }
			]);
			break;
		case "metricGain":
			r.shift(), e.turn.card?.id === 90 && (e.turn.revealedCards = t.hand.filter((e) => F(e.id).income === "energy")), X(t, i.resource, Oe(e, t, i.metric) * i.multiplier);
			break;
		case "if":
			r.shift(), ke(e, t, i.condition) ? Y(e, i.effects) : [
				"visit",
				"sameRing",
				"completedSector"
			].includes(i.condition.metric.kind) && e.turn.bonuses.push({
				condition: i.condition,
				effects: i.effects
			});
			break;
		case "choose":
			r.shift(), Y(e, i.options[Number(o[1])].effects);
			break;
		case "tuckSelf":
			r.shift(), it(e, t, i.card);
			break;
		case "targetSignal":
			if (st(e, t, n.n, i.noData), i.n--, i.target === "anyProbe" ? (i.selected ??= [], i.selected.push(o[2])) : (i.target === "probe" || e.turn.card?.id === 1040) && (i.locked = n.n === 8 ? Re(e).sector : n.n), i.adjacent) {
				let t = n.n === 8 ? Re(e).sector : n.n;
				r.shift(), Y(e, [{
					kind: "signal",
					sectors: [R(t - 1)]
				}, {
					kind: "signal",
					sectors: [R(t + 1)]
				}]);
			} else i.n <= 0 && r.shift();
			break;
		case "scoreActionSignals":
			r.shift(), X(t, "vp", 2 * (i.unique ? new Set(e.turn.actionSignals).size : e.turn.actionSignals.filter((t) => e.sectors[t === 8 ? Re(e).sector : t]?.color === i.color).length));
			break;
		case "goldScore":
			r.shift(), X(t, "vp", je(e, t, Number(o[1]), 2));
			break;
		case "project":
			r.shift(), Et(e, t, i, n);
			break;
		case "alien": i.op === "orbit" ? (r.shift(), vt(e, t, i.card.uid)) : Ge(e, t, i, n);
	}
}
function Ot(e, t, n) {
	let r = Xe(e, t), i = n.id.split(":");
	if (e.ending) {
		e.finalScores.find((e) => e.owner === t).cards += je(e, r, Number(i[1]), 2), e.finalChoices.shift(), e.finalChoices.length || St(e);
		return;
	}
	if (i[0] === "roundCard") {
		let t = e.roundOffer;
		if (i[1] === "defer") {
			t.deferred = !0, yt(e);
			return;
		}
		let n = t.cards.find((e) => e.uid === i[1]);
		r.hand.push(n), e.roundDecks[e.round - 1] = t.cards.filter((e) => e.uid !== n.uid), e.roundOffer = null, e.roundWait = null, yt(e);
		return;
	}
	if (e.phase === "setup") {
		it(e, r, r.hand.find((e) => e.uid === i[1])), e.setupIndex++, e.setupIndex === e.players.length && (e.phase = "playing");
		return;
	}
	if (e.responses[0]?.flow?.length) {
		Dt(e, r, n), dt(e);
		return;
	}
	if (e.responses.length) {
		let t = e.responses[0];
		if (n.id === "response:skip") e.responses.shift();
		else {
			let n = r.missions.find((e) => e.card.uid === i[1]), a = Number(i[2]);
			n.circles.push(a), t.options = [], t.flow = He(e, r, F(n.card.id).mission.rewards[a], n.card);
		}
		dt(e);
		return;
	}
	if (i[0] === "gold") {
		let t = Number(i[1]);
		r.gold.push(t), r.goldRates.push(e.gold[t]++), yt(e);
		return;
	}
	if (e.turn.endRequested && !Ze(e).length) {
		let i = Ve(e, r);
		if (i) {
			e.turn.effectOwner = t, e.turn.flow.push(i), Dt(e, r, n), dt(e);
			return;
		}
	}
	if (i[0] === "passDiscard") {
		let t = r.hand.find((e) => e.uid === i[1]);
		r.hand = r.hand.filter((e) => e.uid !== t.uid), e.discard.push(t);
		return;
	}
	if (n.id === "closing:finish") {
		let t = !e.players.some((e) => e.passed);
		r.passed = !0, e.turn.endRequested = !0, t && nt(e), dt(e);
		return;
	}
	if (n.id === "endTurn") {
		e.turn.stage = "closing", e.turn.endRequested = !0, yt(e);
		return;
	}
	if (i[0] === "settle") {
		if (i[1] === "oumuamua") {
			let t = e.species.find((e) => e.id === "oumuamua");
			for (let n of new Set(t.signals)) Xe(e, n).fossil++;
			t.signals = [];
		} else _t(e, Number(i[1]));
		dt(e);
		return;
	}
	if (n.group === "free") {
		if (e.turn.free = [], i[1] === "upper") {
			let t = r.computer++;
			r.data--, r.installed[t] ? X(r, "vp", 2) : t === 1 ? X(r, "publicity", 1) : t === 3 && Y(e, [{ kind: "income" }]);
		}
		if (i[1] === "lower") {
			let t = Number(i[2]);
			r.data--, r.lower.push(t), Y(e, I(r.installed[t]).lower ?? []);
		}
		if (i[1] === "move" && (r.energy -= n.n, Ct(e, r, e.probes.find((e) => e.uid === i[2]), Number(i[3]), Number(i[4]))), i[1] === "discard") {
			let t = r.hand.find((e) => e.uid === i[2]);
			r.hand = r.hand.filter((e) => e.uid !== t.uid), e.discard.push(t), Y(e, Tt(t)), Z(e, r.rid, "discard", F(t.id).free);
		}
		if (i[1] === "exchange") {
			if (i[2] === "card") {
				let t = r.hand.filter((e) => e.uid === i[4] || e.uid === i[5]);
				r.hand = r.hand.filter((e) => !t.includes(e)), e.discard.push(...t);
			} else r[i[2]] -= 2;
			i[3] === "card" ? Y(e, [{ kind: "pickCard" }]) : X(r, i[3], 1);
		}
		if (i[1] === "buy") {
			r.publicity -= 3;
			let t = i[2] === "deck" ? $e(e) : e.market.find((e) => e.uid === i[2]);
			t && (r.hand.push(t), e.market = e.market.filter((e) => e.uid !== t.uid)), et(e);
		}
		if (i[1] === "mission") {
			let t = r.missions.find((e) => e.card.uid === i[2]);
			t.circles.push(0), Y(e, He(e, r, F(t.card.id).mission.rewards[0], t.card));
		}
		dt(e);
		return;
	}
	if (Ze(e).length) {
		Dt(e, r, n), dt(e);
		return;
	}
	if (e.turn.stage = "main", i[0] === "play") {
		let t = r.hand.find((e) => e.uid === i[1]), n = F(t.id);
		r[n.energyCost ? "energy" : "credit"] -= n.cost, r.hand = r.hand.filter((e) => e.uid !== t.uid), !n.energyCost && n.cost && Z(e, r.rid, "pay", String(n.cost)), n.energyCost ? Ue(e, r, t) : n.mission ? r.missions.push({
			card: t,
			circles: []
		}) : n.keep || n.score ? r.played.push(t) : e.discard.push(t), e.turn.card = t, Y(e, He(e, r, n.effects.filter((e) => e.kind !== "alien" || !e.op.startsWith("message")), t).map((e) => e.kind === "project" ? {
			...e,
			source: t
		} : e)), Z(e, r.rid, "play", String(t.id)), Qe(e, r.rid, "games.seti.log.play", { n: t.id });
	} else if (i[0] === "orbit") r.credit--, r.energy--, vt(e, r, i[1]);
	else if (i[0] === "mainLand") {
		let t = e.probes.find((e) => e.uid === i[1]);
		r.energy -= ut(e, r, q(e, t)), wt(e, r, i[1], i[2], Number(i[3]));
	} else i[1] === "launch" ? (r.credit -= 2, ot(e, r)) : i[1] === "scan" ? (r.credit--, r.energy -= 2, Y(e, [{
		kind: "scan",
		todo: [
			"earth",
			"row",
			...r.techs.includes("t1") ? ["hand"] : [],
			...r.techs.includes("t2") ? ["mercury"] : [],
			...r.techs.includes("t3") ? ["probe"] : []
		]
	}])) : i[1] === "analyze" ? (r.energy--, r.computer = 0, r.lower = [], Y(e, [{
		kind: "trace",
		color: "blue"
	}])) : i[1] === "research" ? (r.publicity -= 6, Y(e, [{
		kind: "research",
		family: "any"
	}])) : i[1] === "pass" && (e.turn.pass = !0, e.turn.stage = "closing");
	dt(e);
}
function kt(e) {
	return e.phase === "finished" ? "games.seti.prompt.finished" : e.ending ? "games.seti.prompt.finalGold" : e.roundOffer && pt(e) === e.roundOffer.owner ? "games.seti.prompt.roundCard" : e.phase === "setup" ? "games.seti.prompt.setup" : e.phase === "roundEnd" ? "games.seti.prompt.roundEnd" : e.phase === "discovery" ? "games.seti.prompt.discovery" : e.responses.length ? "games.seti.prompt.response" : e.turn.endRequested ? "games.seti.prompt.gold" : e.turn.stage === "closing" ? "games.seti.prompt.pass" : e.turn.free ? "games.seti.prompt.free" : Ze(e).length ? "games.seti.prompt.effect" : e.turn.stage === "sectors" ? "games.seti.prompt.sector" : e.turn.stage === "after" ? "games.seti.prompt.after" : "games.seti.prompt.main";
}
//#endregion
//#region src/games/seti/meta.ts
var At = {
	id: "seti",
	tier: "beta",
	mechanics: [
		"hand-management",
		"engine-building",
		"grid-movement",
		"area-control"
	],
	interactionTags: [],
	nameKey: "games.seti.name",
	descKey: "games.seti.desc",
	rulesKey: "games.seti.rules",
	icon: "🪐",
	iconImg: "games/seti.webp",
	minPlayers: 2,
	maxPlayers: 4,
	accent: "#176b88",
	releasedAt: "2026-10-25T00:43:06+08:00",
	rulesUrl: {
		en: "https://filemanager.czechgames.com/storage/files/seti-search-for-extraterrestrial-intelligence/rules/seti-rules-en.pdf",
		zh: "https://filemanager.czechgames.com/storage/files/seti-search-for-extraterrestrial-intelligence/rules/SE%20rulebook%20ZH-S%2006.pdf"
	},
	search: {
		py: "sou xun di wai wen ming",
		init: "sxdwwm"
	},
	hotseat: "cover"
}, Q = e.string(), jt = e.string().startsWith("games.seti.").transform((e) => e), Mt = e.object({
	ring: e.int().min(1).max(4),
	sector: e.int().min(0).max(7)
}), Nt = e.object({
	uid: e.string(),
	id: e.int()
}), Pt = e.object({
	uid: e.string(),
	owner: Q,
	planet: e.enum([
		"earth",
		"mercury",
		"venus",
		"mars",
		"jupiter",
		"saturn",
		"uranus",
		"neptune",
		"oumuamua"
	]),
	moon: e.string().nullable(),
	slot: e.int().nullable(),
	kind: e.enum(["orbiter", "lander"])
}), Ft = e.record(e.string(), e.union([e.string(), e.number()])), It = e.object({
	card: Nt,
	circles: e.array(e.int())
}), Lt = e.union([
	e.object({
		kind: e.literal("gain"),
		resource: e.enum([
			"credit",
			"energy",
			"publicity",
			"data",
			"vp"
		]),
		n: e.int()
	}),
	e.object({
		kind: e.literal("draw"),
		n: e.int()
	}),
	e.object({
		kind: e.literal("alien"),
		op: e.string(),
		species: e.int(),
		n: e.int().optional()
	})
]), Rt = e.object({
	rid: Q,
	credit: e.int(),
	energy: e.int(),
	publicity: e.int(),
	data: e.int(),
	vp: e.int(),
	handCount: e.int(),
	income: e.array(Nt),
	missions: e.array(It),
	played: e.array(Nt),
	techs: e.array(e.string()),
	computer: e.int().min(0).max(6),
	lower: e.array(e.int()),
	installed: e.array(e.string().nullable()),
	passed: e.boolean(),
	gold: e.array(e.int()),
	goldRates: e.array(e.int()),
	fossil: e.int(),
	danger: e.int(),
	secretCount: e.int(),
	secretPlayedCount: e.int()
}), zt = e.object({
	type: e.literal("choose"),
	id: e.string().min(1).max(180)
}).strict(), Bt = e.object({}).default({}), Vt = e.object({
	phase: e.enum([
		"setup",
		"playing",
		"roundEnd",
		"discovery",
		"finished"
	]),
	active: Q,
	acting: Q.nullable(),
	stage: e.enum([
		"before",
		"main",
		"sectors",
		"after",
		"closing"
	]),
	round: e.int().min(1).max(5),
	first: Q,
	goldFaces: e.array(e.int()),
	gold: e.array(e.int()),
	roundCardCount: e.int(),
	revealedCards: e.array(Nt),
	finalScores: e.array(e.object({
		owner: Q,
		base: e.int(),
		cards: e.int(),
		gold: e.int(),
		aliens: e.int(),
		penalty: e.int(),
		total: e.int()
	})),
	anomalies: e.array(e.object({
		sector: e.int(),
		color: e.enum([
			"red",
			"yellow",
			"blue"
		]),
		reward: e.array(Lt)
	})),
	revealedSecrets: e.array(e.object({
		owner: Q,
		cards: e.array(Nt),
		danger: e.int()
	})),
	sampleReveals: e.array(e.object({
		owner: Q,
		planet: e.enum(["jupiter", "saturn"]),
		sample: e.int()
	})),
	angles: e.tuple([
		e.int(),
		e.int(),
		e.int()
	]),
	nextDisc: e.int().min(0).max(2),
	players: e.array(Rt),
	probes: e.array(Mt.extend({
		uid: e.string(),
		owner: Q,
		sample: e.boolean().optional(),
		mission: e.string().optional()
	})),
	figures: e.array(Pt),
	sectors: e.array(e.object({
		id: e.string(),
		color: e.enum([
			"red",
			"yellow",
			"blue",
			"black"
		]),
		capacity: e.int(),
		signals: e.array(Q),
		winners: e.array(Q),
		firstVP: e.int(),
		laterVP: e.int()
	})),
	species: e.array(e.object({
		id: e.string().nullable(),
		traces: e.array(Q.nullable()),
		overflow: e.array(Q),
		overflowColors: e.array(e.enum([
			"red",
			"yellow",
			"blue"
		])),
		revealed: e.boolean(),
		research: e.array(e.object({
			color: e.enum([
				"red",
				"yellow",
				"blue"
			]),
			cost: e.int(),
			owners: e.array(Q),
			repeat: e.boolean().optional(),
			fossil: e.int().optional(),
			sample: e.int().optional(),
			danger: e.int().optional(),
			reward: e.array(Lt)
		})),
		market: e.array(Nt),
		deckCount: e.int(),
		sampleCounts: e.object({
			jupiter: e.int(),
			saturn: e.int()
		}),
		messages: e.array(e.object({
			owner: Q,
			threshold: e.int(),
			card: Nt.nullable()
		})),
		messageRewards: e.array(e.string()),
		signals: e.array(Q),
		dangerThresholds: e.array(e.int())
	})),
	market: e.array(Nt),
	discard: e.array(Nt),
	deckCount: e.int(),
	techMarket: e.array(e.object({
		id: e.string(),
		count: e.int(),
		first: e.boolean(),
		reward: e.string().nullable()
	})),
	prompt: jt,
	effect: e.object({
		kind: e.string(),
		n: e.number().optional(),
		resource: e.string().optional(),
		tech: e.string().optional()
	}).nullable(),
	log: e.array(e.object({
		key: jt,
		owner: Q,
		params: Ft.optional()
	}))
}), Ht = e.object({
	hand: e.array(Nt),
	roundCards: e.array(Nt),
	secret: e.array(Nt),
	secretPlayed: e.array(Nt),
	samples: e.array(e.object({
		uid: e.string(),
		sample: e.int()
	})),
	choices: e.array(e.object({
		id: e.string(),
		key: jt,
		group: e.enum([
			"main",
			"free",
			"effect",
			"response"
		]),
		params: Ft.optional(),
		card: e.string().optional(),
		target: Mt.optional(),
		tech: e.string().optional(),
		species: e.int().optional(),
		n: e.number().optional()
	}))
}), Ut = (e) => e.flatMap((e) => e.kind === "gain" ? [{
	kind: "gain",
	resource: e.resource,
	n: e.n
}] : e.kind === "draw" ? [{
	kind: "draw",
	n: e.n
}] : e.kind === "alien" ? [{
	kind: "alien",
	op: e.op,
	species: e.species,
	n: e.n
}] : []), Wt = {
	saveCompatibility: {
		version: "2",
		migrate: () => null
	},
	meta: At,
	schemas: {
		action: zt,
		publicView: Vt,
		privateView: Ht,
		config: Bt
	},
	setup(e, t, n) {
		return { state: rt(t, n) };
	},
	reduce(e, t, { by: n }) {
		let r = zt.safeParse(t);
		if (!r.success) return { code: "games.seti.invalidAction" };
		let i = gt(e, n).find((e) => e.id === r.data.id);
		if (!i) return { code: "games.seti.invalidAction" };
		let a = structuredClone(e);
		return Ot(a, n, i), { state: a };
	},
	viewFor(e, t) {
		let n = e.players.find((e) => e.rid === t), r = (e.responses[0]?.flow ?? e.turn.free ?? e.turn.flow)[0];
		return {
			public: {
				phase: e.phase,
				active: e.players[e.active].rid,
				acting: pt(e),
				stage: e.turn.stage,
				angles: e.angles,
				nextDisc: e.nextDisc,
				round: e.round,
				first: e.players[e.first].rid,
				goldFaces: e.goldFaces,
				gold: e.gold,
				roundCardCount: e.roundOffer?.cards.length ?? 0,
				finalScores: e.finalScores,
				revealedCards: e.turn.revealedCards,
				players: e.players.map((e) => ({
					rid: e.rid,
					credit: e.credit,
					energy: e.energy,
					publicity: e.publicity,
					data: e.data,
					vp: e.vp,
					income: e.income,
					missions: e.missions,
					played: e.played,
					techs: e.techs,
					computer: e.computer,
					lower: e.lower,
					installed: e.installed,
					passed: e.passed,
					gold: e.gold,
					goldRates: e.goldRates,
					fossil: e.fossil,
					danger: e.danger,
					handCount: e.hand.length,
					secretCount: e.secret.length,
					secretPlayedCount: e.secretPlayed.length
				})),
				probes: e.probes.map((e) => ({
					uid: e.uid,
					owner: e.owner,
					ring: e.ring,
					sector: e.sector,
					...e.sample === void 0 ? {} : {
						sample: !0,
						mission: e.mission
					}
				})),
				figures: e.figures,
				sectors: e.sectors,
				anomalies: e.anomalies.map((e) => ({
					...e,
					reward: Ut(e.reward)
				})),
				sampleReveals: e.sampleReveals,
				revealedSecrets: e.phase === "finished" ? e.players.map((e) => ({
					owner: e.rid,
					cards: e.secretPlayed,
					danger: e.danger + e.secretPlayed.reduce((e, t) => e + (ue.find((e) => e.id === t.id)?.danger ?? 0), 0)
				})) : [],
				species: e.species.map((e) => ({
					id: e.revealed ? e.id : null,
					traces: e.traces,
					overflow: e.overflow,
					overflowColors: e.overflowColors,
					revealed: e.revealed,
					research: e.revealed ? e.research.map(({ color: e, cost: t, owners: n, repeat: r, fossil: i, sample: a, danger: o, reward: s }) => ({
						color: e,
						cost: t,
						owners: n,
						repeat: r,
						fossil: i,
						sample: a,
						danger: o,
						reward: Ut(s)
					})) : [],
					market: e.revealed ? e.market : [],
					deckCount: e.revealed ? e.deck.length : 0,
					sampleCounts: {
						jupiter: e.samples.jupiter.length,
						saturn: e.samples.saturn.length
					},
					messages: e.messages,
					messageRewards: e.messageRewards,
					signals: e.signals,
					dangerThresholds: e.dangerThresholds
				})),
				market: e.market,
				discard: e.discard,
				deckCount: e.deck.length,
				techMarket: me.map((t) => ({
					id: t.id,
					count: e.techRewards[t.id].length,
					first: !e.researched[t.id],
					reward: e.techRewards[t.id][0] ?? null
				})),
				prompt: kt(e),
				effect: r ? {
					kind: r.kind,
					..."n" in r ? { n: r.n } : {},
					..."resource" in r ? { resource: r.resource } : {},
					..."tech" in r ? { tech: r.tech } : {}
				} : null,
				log: e.log
			},
			...n ? { private: {
				hand: n.hand,
				roundCards: e.roundOffer?.owner === t ? e.roundOffer.cards : [],
				secret: n.secret,
				secretPlayed: n.secretPlayed,
				samples: e.probes.flatMap((e) => e.owner === t && e.sample !== void 0 ? [{
					uid: e.uid,
					sample: e.sample
				}] : []),
				choices: gt(e, t)
			} } : {}
		};
	},
	status(e) {
		let t = [...e.players].sort((e, t) => t.vp - e.vp).map((e) => e.rid);
		return {
			phase: e.phase,
			...e.phase === "finished" ? {
				winner: e.players.filter((t) => t.vp === Math.max(...e.players.map((e) => e.vp))).map((e) => e.rid),
				ranking: t,
				scores: Object.fromEntries(e.players.map((e) => [e.rid, e.vp]))
			} : {}
		};
	}
}, Gt = "\n  <linearGradient id=\"table\" x2=\"1\" y2=\"1\"><stop stop-color=\"#142c40\"/><stop offset=\".45\" stop-color=\"#081521\"/><stop offset=\"1\" stop-color=\"#101f31\"/></linearGradient>\n  <radialGradient id=\"space\"><stop stop-color=\"#194b66\"/><stop offset=\".55\" stop-color=\"#102838\"/><stop offset=\"1\" stop-color=\"#071320\"/></radialGradient>\n  <radialGradient id=\"sun\"><stop stop-color=\"#fff4ba\"/><stop offset=\".38\" stop-color=\"#ffd64d\"/><stop offset=\".75\" stop-color=\"#f5a522\"/><stop offset=\"1\" stop-color=\"#d76519\"/></radialGradient>\n  <radialGradient id=\"disc0\" gradientUnits=\"userSpaceOnUse\" cx=\"300\" cy=\"300\" r=\"115\"><stop stop-color=\"#fff089\"/><stop offset=\".65\" stop-color=\"#f0c229\"/><stop offset=\"1\" stop-color=\"#d19c19\"/></radialGradient>\n  <radialGradient id=\"disc1\" gradientUnits=\"userSpaceOnUse\" cx=\"300\" cy=\"300\" r=\"158\"><stop stop-color=\"#ebca71\"/><stop offset=\".8\" stop-color=\"#b18b39\"/><stop offset=\"1\" stop-color=\"#927039\"/></radialGradient>\n  <radialGradient id=\"disc2\" gradientUnits=\"userSpaceOnUse\" cx=\"300\" cy=\"300\" r=\"220\"><stop stop-color=\"#ad803c\"/><stop offset=\".8\" stop-color=\"#796448\"/><stop offset=\"1\" stop-color=\"#5c5142\"/></radialGradient>\n  <linearGradient id=\"paper\" x2=\".8\" y2=\"1\"><stop stop-color=\"#fffefa\"/><stop offset=\"1\" stop-color=\"#eeeade\"/></linearGradient>\n  <linearGradient id=\"skin\" x2=\".8\" y2=\"1\"><stop stop-color=\"#ffe2ac\"/><stop offset=\".55\" stop-color=\"#dd9a72\"/><stop offset=\"1\" stop-color=\"#844b46\"/></linearGradient>\n  <linearGradient id=\"foil\" x2=\"1\" y2=\"1\"><stop stop-color=\"#ffffd4\"/><stop offset=\".3\" stop-color=\"#c7c9b3\"/><stop offset=\".55\" stop-color=\"#69787d\"/><stop offset=\".8\" stop-color=\"#e1e6d5\"/><stop offset=\"1\" stop-color=\"#4b5a62\"/></linearGradient>\n  <linearGradient id=\"sail\" x1=\"0\" y1=\"1\" x2=\".8\" y2=\".1\"><stop stop-color=\"#fff99b\"/><stop offset=\".45\" stop-color=\"#dd7f28\"/><stop offset=\"1\" stop-color=\"#481d35\"/></linearGradient>\n  <linearGradient id=\"desert\" x2=\"0\" y2=\"1\"><stop stop-color=\"#ffca6d\"/><stop offset=\".45\" stop-color=\"#c97136\"/><stop offset=\"1\" stop-color=\"#5b2c31\"/></linearGradient>\n  <linearGradient id=\"sky\" x2=\"0\" y2=\"1\"><stop stop-color=\"#3b80b3\"/><stop offset=\".8\" stop-color=\"#c9e0de\"/><stop offset=\"1\" stop-color=\"#e5d2ab\"/></linearGradient>\n  <radialGradient id=\"planetShade\" cx=\".22\" cy=\".24\"><stop stop-color=\"#fff5cf\" stop-opacity=\".15\"/><stop offset=\".55\" stop-color=\"#18273a\" stop-opacity=\"0\"/><stop offset=\"1\" stop-color=\"#020c15\" stop-opacity=\".87\"/></radialGradient>\n  <linearGradient id=\"action\" x2=\".2\" y2=\"1\"><stop stop-color=\"#d3f0ec\"/><stop offset=\"1\" stop-color=\"#87c8ce\"/></linearGradient>\n  <pattern id=\"grain\" width=\"5\" height=\"7\" patternUnits=\"userSpaceOnUse\"><circle cx=\"1\" cy=\"2\" r=\".45\" fill=\"#fff\" opacity=\".035\"/><circle cx=\"4\" cy=\"6\" r=\".55\" fill=\"#000\" opacity=\".045\"/></pattern>\n  <filter id=\"cardShadow\" x=\"-.15\" y=\"-.1\" width=\"1.3\" height=\"1.25\"><feDropShadow dx=\"0\" dy=\"3\" stdDeviation=\"1.8\" flood-color=\"#000b\"/></filter>\n  <clipPath id=\"artClip\"><rect width=\"240\" height=\"163\"/></clipPath>\n  <clipPath id=\"cardClip\"><rect width=\"240\" height=\"336\" rx=\"7\"/></clipPath>\n  ", Kt = {
	credit: "<path d=\"M26 1L51 26 26 51 1 26Z\" fill=\"#bd963b\" stroke=\"#f6d37a\" stroke-width=\"1.4\"/><path d=\"M22 5L22 12 18 9 18 19 10 26 18 33 18 43 22 40 22 47 26 43 30 47 30 40 34 43 34 33 27 26 34 19 34 9 30 12 30 5 26 9Z\" fill=\"white\"/><path d=\"M26 20L32 26 26 32 20 26Z\" fill=\"#bd963b\"/>",
	energy: "<path d=\"M0 5H35L52 26 35 47H0Z\" fill=\"#78b83d\"/><path d=\"M31 7L15 29H25L22 46 39 22H28Z\" fill=\"white\"/>",
	publicity: "<path d=\"M26 1L51 26 26 51 1 26Z\" fill=\"#f15b3d\"/><path d=\"M22 10Q26 5 30 10V24Q26 29 22 24Z M19 17V24Q19 33 26 33Q33 33 33 24V17 M26 33V39 M19 40H33\" fill=\"white\" stroke=\"white\" stroke-width=\"3.4\" stroke-linecap=\"round\"/><path d=\"M23 13H29M23 17H29\" stroke=\"#f15b3d\" stroke-width=\"1\"/>",
	data: "<path d=\"M26 1L51 26 26 51 1 26Z\" fill=\"#475eac\" stroke=\"#b2b8e3\" stroke-width=\"1\"/><g fill=\"white\" font-family=\"Consolas,monospace\" font-size=\"9\" text-anchor=\"middle\"><text x=\"26\" y=\"18\">0100</text><text x=\"26\" y=\"27\">0011</text><text x=\"26\" y=\"36\">0100</text></g>",
	vp: "<circle cx=\"26\" cy=\"26\" r=\"25\" fill=\"#137658\" stroke=\"#8dcbaa\" stroke-width=\"1.1\"/><g fill=\"none\" stroke=\"#b7e5bf\" stroke-width=\"1.8\"><path d=\"M26 45Q5 37 8 20M26 45Q47 37 44 20\"/></g><g fill=\"#a8dcaf\"><path d=\"M14 36Q6 37 6 29Q13 28 14 36 M11 29Q3 27 7 20Q14 21 11 29 M13 22Q6 17 11 12Q17 17 13 22 M18 39Q11 43 9 36Q14 33 18 39 M20 42Q17 34 13 33Q12 40 20 42 M38 36Q46 37 46 29Q39 28 38 36 M41 29Q49 27 45 20Q38 21 41 29 M39 22Q46 17 41 12Q35 17 39 22 M34 39Q41 43 43 36Q38 33 34 39 M32 42Q35 34 39 33Q40 40 32 42\"/></g>",
	signal: "<g fill=\"white\"><rect x=\"9\" y=\"19\" width=\"6\" height=\"17\" rx=\"3\"/><rect x=\"19\" y=\"8\" width=\"6\" height=\"38\" rx=\"3\"/><rect x=\"29\" y=\"14\" width=\"6\" height=\"27\" rx=\"3\"/><circle cx=\"41\" cy=\"27\" r=\"3\"/></g>",
	move: "<path d=\"M23 1Q37-1 42 10L51 26 40 40Q34 49 21 50L4 45 1 26 9 8Z\" fill=\"#272d43\" stroke=\"#bac4d6\" stroke-width=\"2\"/><path d=\"M33 9L48 25Q49 26 47 28L33 42 27 36 37 26 27 17Z\" fill=\"#cbd3ef\"/><path d=\"M14 7L22 10 18 23 10 20Z M9 23L18 27 14 40 6 37Z M9 20L25 27 22 33 6 25Z M16 23L21 20 25 28 19 35Z\" fill=\"white\"/>",
	lander: "<path d=\"M26 2L48 14V38L26 50 4 38V14Z\" fill=\"#452333\" stroke=\"#efba38\" stroke-width=\"2\"/><path d=\"M9 25Q18 35 48 29V38L26 49 4 37V31Z\" fill=\"#9f5230\"/><path d=\"M12 22H39M25 7V21M17 23H34V31H17Z M21 30L14 37M27 31L34 38\" fill=\"#f5bb3b\" stroke=\"#f5bb3b\" stroke-width=\"1.8\"/><g fill=\"none\" stroke=\"#f9d45a\" stroke-width=\"2.8\"><circle cx=\"13\" cy=\"38\" r=\"4\"/><circle cx=\"25\" cy=\"39\" r=\"4\"/><circle cx=\"38\" cy=\"37\" r=\"4\"/><path d=\"M14 38L23 29 26 39 30 29 38 37\"/></g>",
	card: "<path d=\"M25 3L51 26 26 50 3 26Z\" fill=\"#34373c\"/><rect x=\"13\" y=\"10\" width=\"24\" height=\"34\" rx=\"3\" fill=\"white\" stroke=\"#373b42\" stroke-width=\"2.5\"/><path d=\"M28 11L37 20H28Z\" fill=\"#abb6b9\"/>",
	probe: "<path d=\"M26 2L48 14V38L26 50 4 38V14Z\" fill=\"#48213a\" stroke=\"#efba38\" stroke-width=\"2\"/><path d=\"M26 9Q16 17 19 31L14 39 23 35 26 44 29 35 38 39 33 31Q36 17 26 9Z\" fill=\"#f79a2f\"/><circle cx=\"26\" cy=\"23\" r=\"3\" fill=\"#582235\"/>",
	telescope: "<path d=\"M26 2L48 14V38L26 50 4 38V14Z\" fill=\"#40213a\" stroke=\"#e9b239\" stroke-width=\"2\"/><path d=\"M10 17Q24 42 40 18Z\" fill=\"#de87b1\"/><path d=\"M26 32L20 43M26 32L33 43M16 43H37M26 20L34 10\" fill=\"none\" stroke=\"#de87b1\" stroke-width=\"3\"/>",
	computer: "<path d=\"M26 2L48 14V38L26 50 4 38V14Z\" fill=\"#172c46\" stroke=\"#a1d1eb\" stroke-width=\"2\"/><path d=\"M16 13H36V36H16ZM12 18H40M12 25H40M12 32H40M21 8V42M30 8V42\" fill=\"none\" stroke=\"#67bfe5\" stroke-width=\"3\"/><path d=\"M21 18H30V30H21Z\" fill=\"#a6d9ed\"/>",
	tech: "<path d=\"M10 11L23 0H47V15L6 51H0V26Z\" fill=\"#e87924\"/><path d=\"M51 1V25L24 51H1Z\" fill=\"#d72c85\"/><path d=\"M51 30V48H30Z\" fill=\"#2581bb\"/><path d=\"M5 39L39 5M16 48L49 16\" stroke=\"#ffcf7d\" stroke-width=\"1\"/><path d=\"M8 2V9M18 0V5M28 0V5M40 0V5M52 13H47M52 23H47M52 35H47M44 52V47M33 52V47M22 52V47M0 20H5M0 30H5\" stroke=\"#db3b83\" stroke-width=\"3\"/>",
	rotate: "<path d=\"M7 24A20 20 0 1 1 26 47M1 23L7 13 12 24\" fill=\"none\" stroke=\"#9cabb0\" stroke-width=\"4\"/><circle cx=\"26\" cy=\"27\" r=\"5\" fill=\"#35434d\"/><circle cx=\"34\" cy=\"17\" r=\"3\" fill=\"#b8c4c7\"/>",
	income: "<path d=\"M3 34L25 12 34 19 45 5V35L33 46 23 35 13 46Z\" fill=\"#f5f4d8\" stroke=\"#26323a\" stroke-width=\"2\"/><path d=\"M12 33L24 21 33 28 42 17V33L33 41 23 30 13 41Z\" fill=\"#839443\"/>",
	"trace-red": "<path d=\"M5 8Q26-2 47 8L30 47Q26 52 22 47Z\" fill=\"#b73a87\"/><circle cx=\"26\" cy=\"29\" r=\"9\" fill=\"#e5a1c8\"/><circle cx=\"14\" cy=\"17\" r=\"6\" fill=\"#e5a1c8\"/><circle cx=\"39\" cy=\"17\" r=\"6\" fill=\"#e5a1c8\"/>",
	"trace-yellow": "<path d=\"M5 8Q26-2 47 8L30 47Q26 52 22 47Z\" fill=\"#cda136\"/><path d=\"M13 16L24 10 36 17 37 30 24 40 13 30Z\" fill=\"#fff0b8\"/><path d=\"M24 11L20 24 26 25 23 37 34 22 27 22Z\" fill=\"#cda136\"/>",
	"trace-blue": "<path d=\"M5 8Q26-2 47 8L30 47Q26 52 22 47Z\" fill=\"#2789bb\"/><path d=\"M15 16Q29 5 37 18Q41 26 29 28L24 34\" fill=\"none\" stroke=\"#c0ecf3\" stroke-width=\"5\"/><circle cx=\"23\" cy=\"40\" r=\"3\" fill=\"#c0ecf3\"/>",
	"data-piece": "<circle cx=\"26\" cy=\"28\" r=\"22\" fill=\"#1e2546\"/><circle cx=\"26\" cy=\"24\" r=\"22\" fill=\"#4560ac\" stroke=\"#a4bae0\" stroke-width=\"1.7\"/><path d=\"M10 11A20 20 0 0 1 39 10\" fill=\"none\" stroke=\"#d7e6fa\" opacity=\".65\"/><g fill=\"#e0e7f4\" font-size=\"9\" font-family=\"Consolas\" text-anchor=\"middle\"><text x=\"26\" y=\"19\">0100</text><text x=\"26\" y=\"28\">0011</text><text x=\"26\" y=\"37\">0100</text></g>",
	"probe-piece": "<path d=\"M13 43L27 43 27 48 13 48Z\" fill=\"#050f18\"/><path d=\"M20 4Q11 10 12 29L5 40 15 37 20 44 25 37 35 40 28 29Q29 10 20 4Z\" fill=\"currentColor\" stroke=\"#e5f5fa\" stroke-width=\"1.4\"/><path d=\"M17 12Q21 7 22 12V30L19 35Z\" fill=\"#fff\" opacity=\".25\"/><circle cx=\"20\" cy=\"21\" r=\"4\" fill=\"#13293b\" stroke=\"#c1e5ed\" stroke-width=\"1\"/>"
}, qt = {
	pioneer: "<g clip-path=\"url(#artClip)\"><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"#172c3a\" /><circle cx=\"57.586439307779074\" cy=\"30.253543310798705\" r=\"0.7866240108548663\" fill=\"#c7e6ed\" opacity=\"0.13825466729700564\"/><circle cx=\"11.69758765026927\" cy=\"16.123333767056465\" r=\"0.7759818150359206\" fill=\"#c7e6ed\" opacity=\"0.5047513087838889\"/><circle cx=\"142.78306474909186\" cy=\"25.474044523201883\" r=\"0.5038846801198088\" fill=\"#c7e6ed\" opacity=\"0.4011299020797014\"/><circle cx=\"91.78592098876834\" cy=\"65.73663885705173\" r=\"0.466513629227411\" fill=\"#c7e6ed\" opacity=\"0.2043374305218458\"/><circle cx=\"57.42600118741393\" cy=\"75.57956402469426\" r=\"0.5343815412535332\" fill=\"#c7e6ed\" opacity=\"0.3659931186586618\"/><circle cx=\"104.57396803423762\" cy=\"27.708983194082975\" r=\"0.3072434291872196\" fill=\"#c7e6ed\" opacity=\"0.5828474166244269\"/><circle cx=\"44.73470052704215\" cy=\"111.41803081613034\" r=\"1.0503055465570652\" fill=\"#c7e6ed\" opacity=\"0.2558347345143557\"/><circle cx=\"132.390067409724\" cy=\"49.99446643330157\" r=\"0.406264572001528\" fill=\"#c7e6ed\" opacity=\"0.3952199267596006\"/><circle cx=\"0.9510756097733974\" cy=\"71.84610192570835\" r=\"1.0402081219642423\" fill=\"#c7e6ed\" opacity=\"0.5293385265022517\"/><circle cx=\"42.069393675774336\" cy=\"63.953377194702625\" r=\"1.0369078415143305\" fill=\"#c7e6ed\" opacity=\"0.13443072997033595\"/><circle cx=\"132.05825021490455\" cy=\"160.0084592839703\" r=\"0.3825363232917152\" fill=\"#c7e6ed\" opacity=\"0.3030691308528185\"/><circle cx=\"29.172707330435514\" cy=\"25.350239938125014\" r=\"0.2753391045774333\" fill=\"#c7e6ed\" opacity=\"0.5286802046746015\"/><circle cx=\"65.49930905923247\" cy=\"9.55460659880191\" r=\"0.2722929924889468\" fill=\"#c7e6ed\" opacity=\"0.483659543171525\"/><circle cx=\"97.20510480925441\" cy=\"43.28936183825135\" r=\"1.041281967300456\" fill=\"#c7e6ed\" opacity=\"0.46858083866536615\"/><circle cx=\"16.896047797054052\" cy=\"20.79316623043269\" r=\"0.3008219138882123\" fill=\"#c7e6ed\" opacity=\"0.5699986184388399\"/><circle cx=\"151.8347684852779\" cy=\"71.087879659608\" r=\"0.3418654313008301\" fill=\"#c7e6ed\" opacity=\"0.12434472911059856\"/><circle cx=\"171.76772302016616\" cy=\"139.78367606643587\" r=\"0.6887179704545997\" fill=\"#c7e6ed\" opacity=\"0.16541857101023197\"/><circle cx=\"230.11171666905284\" cy=\"137.0863066315651\" r=\"0.6685965499537997\" fill=\"#c7e6ed\" opacity=\"0.13297108255326748\"/><circle cx=\"202.24980225786567\" cy=\"155.36588639672846\" r=\"0.3218623000360094\" fill=\"#c7e6ed\" opacity=\"0.39988247461616994\"/><circle cx=\"144.68655360862613\" cy=\"137.39657932333648\" r=\"1.0474580846424215\" fill=\"#c7e6ed\" opacity=\"0.21543371491134167\"/><circle cx=\"118.81271397694945\" cy=\"47.12655678857118\" r=\"0.7905824516131542\" fill=\"#c7e6ed\" opacity=\"0.46217176236212254\"/><circle cx=\"223.02921948954463\" cy=\"5.587604518979788\" r=\"0.8921311610075645\" fill=\"#c7e6ed\" opacity=\"0.5838685514777899\"/><circle cx=\"56.98059758171439\" cy=\"58.303752961568534\" r=\"0.2819375415495597\" fill=\"#c7e6ed\" opacity=\"0.28207372672855857\"/><circle cx=\"21.647740434855223\" cy=\"96.30830609239638\" r=\"0.5103429251979105\" fill=\"#c7e6ed\" opacity=\"0.37876112692058084\"/><circle cx=\"199.05005341395736\" cy=\"4.628643662668765\" r=\"0.27512840984156356\" fill=\"#c7e6ed\" opacity=\"0.24256901957094668\"/><circle cx=\"55.30697850510478\" cy=\"152.84817188233137\" r=\"0.8133392001199535\" fill=\"#c7e6ed\" opacity=\"0.33613408528268335\"/><circle cx=\"110.80889275297523\" cy=\"101.10479754116386\" r=\"0.39003277636831624\" fill=\"#c7e6ed\" opacity=\"0.32201915211975574\"/><circle cx=\"61.24738169834018\" cy=\"118.63530056737363\" r=\"0.5284821416880005\" fill=\"#c7e6ed\" opacity=\"0.5647346799820661\"/><circle cx=\"133.25488781556487\" cy=\"46.72498002368957\" r=\"0.9388653971417806\" fill=\"#c7e6ed\" opacity=\"0.5863539949804544\"/><circle cx=\"38.40373395010829\" cy=\"21.671948540955782\" r=\"0.2649728950741701\" fill=\"#c7e6ed\" opacity=\"0.15322227381169795\"/><circle cx=\"29.31452175602317\" cy=\"116.12545018922538\" r=\"0.43096322055673225\" fill=\"#c7e6ed\" opacity=\"0.15125927813351153\"/><circle cx=\"221.623905133456\" cy=\"72.90757678635418\" r=\"0.6826992509583942\" fill=\"#c7e6ed\" opacity=\"0.5273558389395475\"/><circle cx=\"165.561738666147\" cy=\"20.177757644094527\" r=\"0.7806955436407588\" fill=\"#c7e6ed\" opacity=\"0.37436409093439577\"/><circle cx=\"230.88760105893016\" cy=\"0.5493977516889572\" r=\"0.7142083017784171\" fill=\"#c7e6ed\" opacity=\"0.5571814569085836\"/><circle cx=\"188.93669357523322\" cy=\"99.51803939696401\" r=\"0.6684991683042608\" fill=\"#c7e6ed\" opacity=\"0.2774283821135759\"/><circle cx=\"35.525113474577665\" cy=\"65.31042222492397\" r=\"0.9398040979797951\" fill=\"#c7e6ed\" opacity=\"0.21421981863677503\"/><circle cx=\"238.46450245007873\" cy=\"124.01381673384458\" r=\"0.855038557590451\" fill=\"#c7e6ed\" opacity=\"0.5185304597765208\"/><circle cx=\"93.43607006594539\" cy=\"7.595006208866835\" r=\"1.0657703042658977\" fill=\"#c7e6ed\" opacity=\"0.29865372441709037\"/><circle cx=\"131.97399219498038\" cy=\"99.16829209309071\" r=\"1.048490991925355\" fill=\"#c7e6ed\" opacity=\"0.5542544914036989\"/><circle cx=\"185.3081844560802\" cy=\"1.6218977961689234\" r=\"0.8557178558479063\" fill=\"#c7e6ed\" opacity=\"0.1565155839174986\"/><circle cx=\"127.81645065173507\" cy=\"145.46214594040066\" r=\"0.22495672536781058\" fill=\"#c7e6ed\" opacity=\"0.5118780038505792\"/><circle cx=\"63.836006205528975\" cy=\"30.48478404432535\" r=\"0.26505761469481515\" fill=\"#c7e6ed\" opacity=\"0.5868749161809683\"/><circle cx=\"141.58437659963965\" cy=\"102.63283364381641\" r=\"0.4019941418594681\" fill=\"#c7e6ed\" opacity=\"0.5715593833476305\"/><circle cx=\"237.9396708123386\" cy=\"127.15033785067499\" r=\"0.4785980257834308\" fill=\"#c7e6ed\" opacity=\"0.41902584962546824\"/><circle cx=\"57.83022975549102\" cy=\"162.8913823487237\" r=\"0.2652799114747904\" fill=\"#c7e6ed\" opacity=\"0.2585253755003214\"/><circle cx=\"11.983649712055922\" cy=\"14.393764827400446\" r=\"0.7512677733483724\" fill=\"#c7e6ed\" opacity=\"0.19967462204396724\"/><circle cx=\"176.78518077358603\" cy=\"88.07668785285205\" r=\"0.748394146671053\" fill=\"#c7e6ed\" opacity=\"0.5252585852891207\"/><circle cx=\"219.99550027772784\" cy=\"99.6718501765281\" r=\"0.4019634371320717\" fill=\"#c7e6ed\" opacity=\"0.510127080604434\"/><circle cx=\"116.07786124572158\" cy=\"107.74731148127466\" r=\"0.4657305585383438\" fill=\"#c7e6ed\" opacity=\"0.4636849770694971\"/><circle cx=\"94.88461581990123\" cy=\"75.93350556492805\" r=\"0.8605221486347727\" fill=\"#c7e6ed\" opacity=\"0.19347618184983728\"/><circle cx=\"7.453113701194525\" cy=\"75.21077696140856\" r=\"0.548531613049563\" fill=\"#c7e6ed\" opacity=\"0.16736137457191944\"/><circle cx=\"32.66097558662295\" cy=\"18.36781599931419\" r=\"0.9678192473645322\" fill=\"#c7e6ed\" opacity=\"0.25178949169814585\"/><circle cx=\"148.49074160680175\" cy=\"141.49036729801446\" r=\"1.0340486873104238\" fill=\"#c7e6ed\" opacity=\"0.14366296090185643\"/><circle cx=\"171.6538947634399\" cy=\"65.08958670124412\" r=\"0.8289909370872192\" fill=\"#c7e6ed\" opacity=\"0.45329668544232843\"/><circle cx=\"69.32425936684012\" cy=\"13.229421648196876\" r=\"0.7078272258094512\" fill=\"#c7e6ed\" opacity=\"0.1559707785397768\"/><g transform=\"rotate(-32 166 99)\"><ellipse cx=\"190\" cy=\"120\" rx=\"134\" ry=\"40\" fill=\"none\" stroke=\"#715f4f\" stroke-width=\"17\"/><ellipse cx=\"190\" cy=\"120\" rx=\"153\" ry=\"47\" fill=\"none\" stroke=\"#ada18a\" stroke-width=\"5\"/><ellipse cx=\"190\" cy=\"120\" rx=\"162\" ry=\"50\" fill=\"none\" stroke=\"#7b7770\" stroke-width=\"1.5\"/></g><g transform=\"translate(228 190)\"><defs><clipPath id=\"p266\"><circle cx=\"0\" cy=\"0\" r=\"106\" fill=\"#fff\" /></clipPath></defs><ellipse rx=\"180.2\" ry=\"45.58\" transform=\"rotate(-28)\" fill=\"none\" stroke=\"#c1ac7c\" stroke-width=\"22.259999999999998\"/><ellipse rx=\"201.39999999999998\" ry=\"53\" transform=\"rotate(-28)\" fill=\"none\" stroke=\"#8c856f\" stroke-width=\"7.949999999999999\"/><circle cx=\"0\" cy=\"0\" r=\"106\" fill=\"#c9b473\" /><g clip-path=\"url(#p266)\"><path d=\"M-127.19999999999999 -106Q0 -81.62 127.19999999999999 -109.18\" fill=\"none\" stroke=\"#f3dfb1\" stroke-width=\"6.359999999999999\" opacity=\"0.65\"/><path d=\"M-127.19999999999999 -85.86Q0 -61.48 127.19999999999999 -89.03999999999999\" fill=\"none\" stroke=\"#754c3b\" stroke-width=\"9.54\" opacity=\"0.65\"/><path d=\"M-127.19999999999999 -65.72Q0 -41.339999999999996 127.19999999999999 -68.9\" fill=\"none\" stroke=\"#e6c78e\" stroke-width=\"12.719999999999999\" opacity=\"0.65\"/><path d=\"M-127.19999999999999 -45.58Q0 -21.199999999999996 127.19999999999999 -48.76\" fill=\"none\" stroke=\"#c07e4c\" stroke-width=\"6.359999999999999\" opacity=\"0.65\"/><path d=\"M-127.19999999999999 -25.439999999999998Q0 -1.0599999999999952 127.19999999999999 -28.619999999999997\" fill=\"none\" stroke=\"#f3dfb1\" stroke-width=\"9.54\" opacity=\"0.65\"/><path d=\"M-127.19999999999999 -5.299999999999997Q0 19.080000000000005 127.19999999999999 -8.479999999999997\" fill=\"none\" stroke=\"#754c3b\" stroke-width=\"12.719999999999999\" opacity=\"0.65\"/><path d=\"M-127.19999999999999 14.840000000000003Q0 39.220000000000006 127.19999999999999 11.660000000000004\" fill=\"none\" stroke=\"#e6c78e\" stroke-width=\"6.359999999999999\" opacity=\"0.65\"/><path d=\"M-127.19999999999999 34.97999999999999Q0 59.35999999999999 127.19999999999999 31.79999999999999\" fill=\"none\" stroke=\"#c07e4c\" stroke-width=\"9.54\" opacity=\"0.65\"/><path d=\"M-127.19999999999999 55.120000000000005Q0 79.5 127.19999999999999 51.940000000000005\" fill=\"none\" stroke=\"#f3dfb1\" stroke-width=\"12.719999999999999\" opacity=\"0.65\"/><path d=\"M-127.19999999999999 75.25999999999999Q0 99.63999999999999 127.19999999999999 72.07999999999998\" fill=\"none\" stroke=\"#754c3b\" stroke-width=\"6.359999999999999\" opacity=\"0.65\"/><path d=\"M-127.19999999999999 95.4Q0 119.78 127.19999999999999 92.22\" fill=\"none\" stroke=\"#e6c78e\" stroke-width=\"9.54\" opacity=\"0.65\"/></g><circle cx=\"0\" cy=\"0\" r=\"106\" fill=\"url(#planetShade)\" /><circle cx=\"0\" cy=\"0\" r=\"106\" fill=\"none\" stroke=\"#b7d6d6\" stroke-width=\".5\" stroke-opacity=\".3\"/><path d=\"M-180.2 47.7Q21.200000000000003 42.400000000000006 177.01999999999998 -68.9\" fill=\"none\" stroke=\"#c6b58c\" stroke-width=\"14.840000000000002\"/></g><path d=\"M99-4L240 62 240 2Z\" fill=\"#e7dcc0\" opacity=\".11\"/><path d=\"M109-4L240 46M136-4L240 32\" stroke=\"#fff8db\" opacity=\".18\" stroke-width=\"2\"/><g transform=\"translate(86 80) scale(1.18)\"><g transform=\"rotate(-33)\"><path d=\"M0 2L-66 55M3-14L56-66M5-12L62-64\" stroke=\"#dbb45a\" stroke-width=\"1.6\"/><path d=\"M47-60L66-71 68-60 50-49Z\" fill=\"#333d44\"/><ellipse cy=\"4\" rx=\"36\" ry=\"19\" fill=\"url(#foil)\" stroke=\"#dadfd2\" stroke-width=\"1.2\"/><path d=\"M0 0L34.8251457847309 1.797001499642907L29.8383582720827 9.408370120751865Z\" fill=\"#c3c9c4\" stroke=\"#8f9795\" stroke-width=\".6\"/><path d=\"M0 0L29.8383582720827 9.408370120751865L18.91058070538489 15.146477726542138Z\" fill=\"#e3dfc6\" stroke=\"#8f9795\" stroke-width=\".6\"/><path d=\"M0 0L18.91058070538489 15.146477726542138L4.217596927857824 17.868833838676593Z\" fill=\"#c3c9c4\" stroke=\"#8f9795\" stroke-width=\".6\"/><path d=\"M0 0L4.217596927857824 17.868833838676593L-11.315134840222623 17.03340157837346Z\" fill=\"#e3dfc6\" stroke=\"#8f9795\" stroke-width=\".6\"/><path d=\"M0 0L-11.315134840222623 17.03340157837346L-24.594957687074384 12.806520350235198Z\" fill=\"#c3c9c4\" stroke=\"#8f9795\" stroke-width=\".6\"/><path d=\"M0 0L-24.594957687074384 12.806520350235198L-32.97778192340304 6.029786702806284Z\" fill=\"#e3dfc6\" stroke=\"#8f9795\" stroke-width=\".6\"/><path d=\"M0 0L-32.97778192340304 6.029786702806284L-34.79453866281912 -1.9475124215419508Z\" fill=\"#c3c9c4\" stroke=\"#8f9795\" stroke-width=\".6\"/><ellipse cy=\"-9\" rx=\"16\" ry=\"9\" fill=\"#d7af47\" stroke=\"#333744\" stroke-width=\"3\"/><ellipse cy=\"-10\" rx=\"12\" ry=\"6\" fill=\"#44474a\" stroke=\"#f1d56d\" stroke-width=\"2\"/><path d=\"M-8-6L-9 6 9 6 9-6\" fill=\"#d5af37\" stroke=\"#353642\"/><path d=\"M9 8L30 29M-10 8L-22 31\" stroke=\"#c3b27d\" stroke-width=\"1.5\"/><circle cx=\"31\" cy=\"30\" r=\"4\" fill=\"#9b9c97\"/></g></g><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"url(#grain)\" /></g>",
	entry: "<g clip-path=\"url(#artClip)\"><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"#1a3d59\" /><path d=\"M25 163Q46 59 197-10H240V163Z\" fill=\"#a03938\"/><path d=\"M36 163Q91 31 240 18\" fill=\"none\" stroke=\"#f69a62\" stroke-width=\"14\" opacity=\".7\"/><path d=\"M46 163Q91 50 240 26\" fill=\"none\" stroke=\"#ffd194\" stroke-width=\"3\"/><g transform=\"translate(92 63) rotate(-25)\"><ellipse rx=\"27\" ry=\"24\" fill=\"url(#foil)\" stroke=\"#e4dbc6\" stroke-width=\"2\"/><ellipse cy=\"7\" rx=\"24\" ry=\"17\" fill=\"#263b47\"/><path d=\"M-23-6L20-10M-18-15L-15 6M-3-22V-2M13-18L13-2\" stroke=\"#728e8c\" stroke-width=\"2\"/><circle cx=\"10\" cy=\"-10\" r=\"4\" fill=\"#c4433c\" /><circle cx=\"-14\" cy=\"-9\" r=\"3\" fill=\"#e8dfbd\" /></g><g transform=\"translate(179 119) rotate(-24)\"><path d=\"M-28-14Q-5-57 31-13L19 11-19 11Z\" fill=\"url(#foil)\" stroke=\"#ffe0aa\"/><path d=\"M-23 1L-37-54-6-28 1-65 10-27 39-52 24 0Z\" fill=\"#f35427\"/><path d=\"M-17 2L-15-25-4-10 4-41 10-13 23-25 17 7Z\" fill=\"#ffd75b\"/><path d=\"M-10 7L0-15 11 7Z\" fill=\"#fff4ab\"/></g><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"url(#grain)\" /></g>",
	dragonfly: "<g clip-path=\"url(#artClip)\"><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"url(#desert)\" /><path d=\"M0 54L33 37 65 49 103 24 158 31 201 9 240 16V163H0Z\" fill=\"#de8947\"/><path d=\"M0 83L49 61 69 75 113 50 155 68 206 40 240 53V163H0Z\" fill=\"#b05b32\"/><path d=\"M0 132L31 93 65 84 47 127 104 93 92 163H0Z\" fill=\"#723731\"/><path d=\"M115 163L137 121 169 97 148 144 186 136 224 92 240 93V163Z\" fill=\"#98462d\"/><path d=\"M0 61Q92 37 240 30M0 73Q81 58 240 42M29 142L65 110M168 136L201 100\" fill=\"none\" stroke=\"#f8c373\" stroke-width=\"1.3\" opacity=\".6\"/><g transform=\"translate(137 88) rotate(-13)\"><ellipse cx=\"-4\" cy=\"44\" rx=\"64\" ry=\"9\" fill=\"#4c2729\" opacity=\".5\"/><path d=\"M-20-25L24-25 42-12 34 22-11 25-36 4Z\" fill=\"#b47a37\" stroke=\"#553427\" stroke-width=\"2\"/><path d=\"M-27-21L0-31 29-24 11-12-20-11Z\" fill=\"#e5b959\"/><path d=\"M-31-7L10-14 40-5 33 18-12 22-31 9Z\" fill=\"#714a2f\"/><path d=\"M7-13L26-10 29 15 8 19Z\" fill=\"#af7537\"/><ellipse cx=\"42\" cy=\"1\" rx=\"12\" ry=\"22\" fill=\"#54372b\" stroke=\"#d09b48\" stroke-width=\"2\"/><ellipse cx=\"43\" cy=\"0\" rx=\"8\" ry=\"17\" fill=\"#372a27\"/><path d=\"M-13 20L-24 38-7 42M23 18L17 38 40 42\" fill=\"none\" stroke=\"#44352b\" stroke-width=\"4\"/><path d=\"M-20 4L-43-12M11 1L-4-26M14 12L-11 34M-22 14L-51 27\" stroke=\"#382d28\" stroke-width=\"3\"/><g transform=\"translate(-45 -16)\"><path d=\"M0 7V-6\" stroke=\"#332c27\" stroke-width=\"3\"/><ellipse cy=\"-6\" rx=\"26\" ry=\"4\" fill=\"#edb351\" opacity=\".85\"/><path d=\"M-25-6H25\" stroke=\"#6a4a2b\" stroke-width=\"1.5\"/></g><g transform=\"translate(15 26)\"><path d=\"M0 7V-6\" stroke=\"#332c27\" stroke-width=\"3\"/><ellipse cy=\"-6\" rx=\"26\" ry=\"4\" fill=\"#edb351\" opacity=\".85\"/><path d=\"M-25-6H25\" stroke=\"#6a4a2b\" stroke-width=\"1.5\"/></g><path d=\"M-14-18H0V-9H-14Z\" fill=\"#ecc76c\"/><path d=\"M-25 1L-8 0M-23 8L-6 7\" stroke=\"#d5aa57\" stroke-width=\"1\"/></g><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"url(#grain)\" /></g>",
	lightsail: "<g clip-path=\"url(#artClip)\"><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"#271d2b\" /><circle cx=\"58.88861546292901\" cy=\"74.2395354132168\" r=\"0.43465245169820266\" fill=\"#c7e6ed\" opacity=\"0.38700464621186254\"/><circle cx=\"91.02421374991536\" cy=\"92.39953245827928\" r=\"0.8053224991471506\" fill=\"#c7e6ed\" opacity=\"0.42129921197891235\"/><circle cx=\"172.06591302528977\" cy=\"156.57150680338964\" r=\"0.8032198954303749\" fill=\"#c7e6ed\" opacity=\"0.20306768283247947\"/><circle cx=\"14.039679933339357\" cy=\"118.7844537240453\" r=\"0.6336011145659722\" fill=\"#c7e6ed\" opacity=\"0.4564973375201225\"/><circle cx=\"92.02415445819497\" cy=\"110.26667498378083\" r=\"0.6875336733576841\" fill=\"#c7e6ed\" opacity=\"0.5651596100628375\"/><circle cx=\"26.626235861331224\" cy=\"8.084389674011618\" r=\"0.6330124644027092\" fill=\"#c7e6ed\" opacity=\"0.5847346991300583\"/><circle cx=\"199.19104361906648\" cy=\"141.63093099137768\" r=\"0.5322967922245152\" fill=\"#c7e6ed\" opacity=\"0.13057992741465568\"/><circle cx=\"213.49625336006284\" cy=\"154.7009039525874\" r=\"0.5987493625306525\" fill=\"#c7e6ed\" opacity=\"0.4776418510079384\"/><circle cx=\"117.68080780282617\" cy=\"151.63367904676124\" r=\"0.6689584745955653\" fill=\"#c7e6ed\" opacity=\"0.4902121187746525\"/><circle cx=\"40.15800269320607\" cy=\"146.76059682527557\" r=\"0.6784246667684056\" fill=\"#c7e6ed\" opacity=\"0.15902708172798158\"/><circle cx=\"193.2629477418959\" cy=\"71.14025842910632\" r=\"0.2415930651058443\" fill=\"#c7e6ed\" opacity=\"0.20321115240454674\"/><circle cx=\"138.3844025619328\" cy=\"23.31627705367282\" r=\"0.7495126851298846\" fill=\"#c7e6ed\" opacity=\"0.2345639142394066\"/><circle cx=\"106.3309876061976\" cy=\"2.5818653511814773\" r=\"0.8609039367106742\" fill=\"#c7e6ed\" opacity=\"0.5016909809410572\"/><circle cx=\"26.681770104914904\" cy=\"33.985633770469576\" r=\"0.2749155820743181\" fill=\"#c7e6ed\" opacity=\"0.3514786058664322\"/><circle cx=\"139.87122500315309\" cy=\"5.062974834349006\" r=\"0.5363523969356901\" fill=\"#c7e6ed\" opacity=\"0.5854120413959026\"/><circle cx=\"165.75857089832425\" cy=\"42.02740835445002\" r=\"0.33665478475624694\" fill=\"#c7e6ed\" opacity=\"0.20823764830827712\"/><circle cx=\"62.43148097768426\" cy=\"11.906262583564967\" r=\"0.8364115941268392\" fill=\"#c7e6ed\" opacity=\"0.26646875515580176\"/><circle cx=\"188.99416895583272\" cy=\"37.85506630549207\" r=\"1.0476873892755247\" fill=\"#c7e6ed\" opacity=\"0.23423526763916014\"/><circle cx=\"186.089850012213\" cy=\"43.63502686237916\" r=\"0.926945423700381\" fill=\"#c7e6ed\" opacity=\"0.36397702798247333\"/><circle cx=\"27.907576728612185\" cy=\"132.98796911956742\" r=\"0.2918475669273175\" fill=\"#c7e6ed\" opacity=\"0.4994809243083\"/><circle cx=\"39.42345002666116\" cy=\"64.39311036793515\" r=\"0.5877124343928881\" fill=\"#c7e6ed\" opacity=\"0.36876175001263617\"/><circle cx=\"92.62620510533452\" cy=\"34.4400461637415\" r=\"0.5919129704521038\" fill=\"#c7e6ed\" opacity=\"0.25428681313991547\"/><circle cx=\"175.47717237845063\" cy=\"133.80232210597023\" r=\"0.30699473451124504\" fill=\"#c7e6ed\" opacity=\"0.578044295758009\"/><circle cx=\"27.354613412171602\" cy=\"118.54596655117348\" r=\"0.3057961402856745\" fill=\"#c7e6ed\" opacity=\"0.4989553633332252\"/><circle cx=\"154.7324318625033\" cy=\"39.25735926581547\" r=\"1.0043518981826491\" fill=\"#c7e6ed\" opacity=\"0.5401300241053104\"/><circle cx=\"120.8432594127953\" cy=\"29.22481101611629\" r=\"0.6008609108091332\" fill=\"#c7e6ed\" opacity=\"0.4634667384624481\"/><circle cx=\"143.075916711241\" cy=\"38.658229095395654\" r=\"0.8314998716046101\" fill=\"#c7e6ed\" opacity=\"0.5290957783162593\"/><circle cx=\"91.8572493083775\" cy=\"16.681243788916618\" r=\"1.006363816598896\" fill=\"#c7e6ed\" opacity=\"0.4771663364768028\"/><circle cx=\"124.76833859458566\" cy=\"105.58017077622935\" r=\"0.9513148792949505\" fill=\"#c7e6ed\" opacity=\"0.28947738602757456\"/><circle cx=\"49.645087737590075\" cy=\"126.54418447101489\" r=\"0.5440204986766912\" fill=\"#c7e6ed\" opacity=\"0.1884522897005081\"/><circle cx=\"90.41318261995912\" cy=\"121.88107729842886\" r=\"0.7449623303418047\" fill=\"#c7e6ed\" opacity=\"0.33095715925097463\"/><circle cx=\"29.40742777660489\" cy=\"10.44297990994528\" r=\"1.03669711075956\" fill=\"#c7e6ed\" opacity=\"0.2944629648327827\"/><circle cx=\"239.92545733228326\" cy=\"39.746417335700244\" r=\"0.29715072465362025\" fill=\"#c7e6ed\" opacity=\"0.49305139437317846\"/><circle cx=\"22.765820939093828\" cy=\"10.021076074335724\" r=\"0.6952267255098559\" fill=\"#c7e6ed\" opacity=\"0.5807644629478455\"/><circle cx=\"0.5004447139799595\" cy=\"13.171657120343298\" r=\"0.8095105592091567\" fill=\"#c7e6ed\" opacity=\"0.5797978721559047\"/><circle cx=\"23.23146717622876\" cy=\"91.3871899289079\" r=\"0.9333507407852448\" fill=\"#c7e6ed\" opacity=\"0.511038119494915\"/><circle cx=\"179.5824501849711\" cy=\"9.88218231825158\" r=\"0.3920982343074866\" fill=\"#c7e6ed\" opacity=\"0.18444335773587228\"/><circle cx=\"86.67396487668157\" cy=\"53.00398130947724\" r=\"0.9107852858887053\" fill=\"#c7e6ed\" opacity=\"0.4467680042982101\"/><circle cx=\"92.83355260267854\" cy=\"44.690719903912395\" r=\"0.5330249598179944\" fill=\"#c7e6ed\" opacity=\"0.5841311006247998\"/><circle cx=\"166.79006086662412\" cy=\"29.01422479795292\" r=\"1.0544126278185286\" fill=\"#c7e6ed\" opacity=\"0.13692842155694962\"/><circle cx=\"227.10235426202416\" cy=\"56.2922600354068\" r=\"0.2962106614303775\" fill=\"#c7e6ed\" opacity=\"0.5445883347094058\"/><circle cx=\"205.5724004097283\" cy=\"147.00448159733787\" r=\"0.25759757751831786\" fill=\"#c7e6ed\" opacity=\"0.23767140984535218\"/><circle cx=\"118.39273089542985\" cy=\"79.4964779294096\" r=\"0.3472628869046457\" fill=\"#c7e6ed\" opacity=\"0.4348137782514095\"/><circle cx=\"238.77827720716596\" cy=\"155.20627140672877\" r=\"0.3576288961269893\" fill=\"#c7e6ed\" opacity=\"0.14201424211263655\"/><circle cx=\"84.83258167281747\" cy=\"60.897655736189336\" r=\"0.6574807123211213\" fill=\"#c7e6ed\" opacity=\"0.25176513388752936\"/><circle cx=\"36.398383397608995\" cy=\"160.13474429631606\" r=\"0.8912857012287713\" fill=\"#c7e6ed\" opacity=\"0.2795269256830215\"/><circle cx=\"94.6425792016089\" cy=\"132.98210441460833\" r=\"0.38598364833043886\" fill=\"#c7e6ed\" opacity=\"0.19504658862948415\"/><circle cx=\"198.12555955722928\" cy=\"29.6648525823839\" r=\"0.2785288731032051\" fill=\"#c7e6ed\" opacity=\"0.24601970225572586\"/><circle cx=\"89.10491952672601\" cy=\"42.67308560712263\" r=\"0.7899655464035459\" fill=\"#c7e6ed\" opacity=\"0.43159631386399266\"/><circle cx=\"143.8235446996987\" cy=\"69.54502270231023\" r=\"0.884317460975144\" fill=\"#c7e6ed\" opacity=\"0.44323054790496824\"/><circle cx=\"80.53207213059068\" cy=\"16.31323351478204\" r=\"0.963073505081702\" fill=\"#c7e6ed\" opacity=\"0.5303739653527737\"/><circle cx=\"198.9957262761891\" cy=\"39.34832708956674\" r=\"0.9585500892647542\" fill=\"#c7e6ed\" opacity=\"0.5085126730799675\"/><circle cx=\"25.23552993312478\" cy=\"127.08447677223012\" r=\"0.8519117762264795\" fill=\"#c7e6ed\" opacity=\"0.48704818323254584\"/><circle cx=\"95.25389017537236\" cy=\"93.86115604871884\" r=\"0.654131363837514\" fill=\"#c7e6ed\" opacity=\"0.2945220226049423\"/><circle cx=\"191.4945592917502\" cy=\"120.86546032270417\" r=\"0.5006706712697633\" fill=\"#c7e6ed\" opacity=\"0.45868409201502797\"/><circle cx=\"125.78697072342038\" cy=\"63.90938963042572\" r=\"0.8731632782542146\" fill=\"#c7e6ed\" opacity=\"0.5189047756791114\"/><circle cx=\"102.52495000138879\" cy=\"26.52646729303524\" r=\"0.6238804674637504\" fill=\"#c7e6ed\" opacity=\"0.16843080058693885\"/><circle cx=\"155.82980068400502\" cy=\"10.622069506440312\" r=\"0.8912616200209594\" fill=\"#c7e6ed\" opacity=\"0.20398484587669372\"/><circle cx=\"134.44776529446244\" cy=\"83.66184086864814\" r=\"0.2572903141309507\" fill=\"#c7e6ed\" opacity=\"0.38020890220999715\"/><circle cx=\"88.13186125829816\" cy=\"97.13257084460929\" r=\"0.7099973768391646\" fill=\"#c7e6ed\" opacity=\"0.5064513811469078\"/><circle cx=\"9.25809184089303\" cy=\"150.75990616856143\" r=\"0.8368721389141864\" fill=\"#c7e6ed\" opacity=\"0.2033979745209217\"/><circle cx=\"103.42603208497167\" cy=\"103.71727418387309\" r=\"0.4874631428555586\" fill=\"#c7e6ed\" opacity=\"0.5370462638139725\"/><circle cx=\"182.79378974810243\" cy=\"60.810392120387405\" r=\"0.5559495540265925\" fill=\"#c7e6ed\" opacity=\"0.3075240795314312\"/><circle cx=\"195.89734124019742\" cy=\"53.37173730926588\" r=\"0.44696452491218225\" fill=\"#c7e6ed\" opacity=\"0.5302516105771065\"/><circle cx=\"127.7042425610125\" cy=\"109.34935333533213\" r=\"0.25045176250161605\" fill=\"#c7e6ed\" opacity=\"0.5269472636282444\"/><path d=\"M0 163L151 4 15 59Z\" fill=\"#d73630\" opacity=\".28\"/><g transform=\"translate(37 102)\"><defs><clipPath id=\"p267\"><circle cx=\"0\" cy=\"0\" r=\"27\" fill=\"#fff\" /></clipPath></defs><circle cx=\"0\" cy=\"0\" r=\"27\" fill=\"#236da6\" /><g clip-path=\"url(#p267)\"><path d=\"M-13.5 -27L5.4 -21.6 11.34 -10.8 2.7 -2.7 7.5600000000000005 6.21 1.08 21.6 -5.4 14.850000000000001 -8.1 1.35 -20.25 -3.2399999999999998Z\" fill=\"#84a268\"/><path d=\"M-27 -8.1Q0 -18.9 27 -6.75M-27 13.5Q0 5.4 27 18.9\" fill=\"none\" stroke=\"#e6eee3\" stroke-width=\"3.2399999999999998\" opacity=\".65\"/></g><circle cx=\"0\" cy=\"0\" r=\"27\" fill=\"url(#planetShade)\" /><circle cx=\"0\" cy=\"0\" r=\"27\" fill=\"none\" stroke=\"#b7d6d6\" stroke-width=\".5\" stroke-opacity=\".3\"/></g><path d=\"M146 6L126 154 230 105Z\" fill=\"url(#sail)\" stroke=\"#6d3d39\" stroke-width=\"1.8\"/><path d=\"M146 6L231 105 126 154Z\" fill=\"none\" stroke=\"#c56b4b\" stroke-width=\"1.2\"/><path d=\"M146 6L126 154 203 93Z\" fill=\"#efa94e\" opacity=\".23\"/><path d=\"M144.33333333333334 18.333333333333332L153 14.25\" fill=\"none\" stroke=\"#f5ba63\" stroke-width=\"0.5\" opacity=\".5\"/><path d=\"M144.33333333333334 18.333333333333332L134.66666666666666 149.91666666666666\" fill=\"none\" stroke=\"#702e2e\" stroke-width=\"0.65\" opacity=\".55\"/><path d=\"M142.66666666666666 30.666666666666664L160 22.5\" fill=\"none\" stroke=\"#f5ba63\" stroke-width=\"0.5\" opacity=\".5\"/><path d=\"M142.66666666666666 30.666666666666664L143.33333333333334 145.83333333333334\" fill=\"none\" stroke=\"#702e2e\" stroke-width=\"0.65\" opacity=\".55\"/><path d=\"M141 43L167 30.75\" fill=\"none\" stroke=\"#f5ba63\" stroke-width=\"0.5\" opacity=\".5\"/><path d=\"M141 43L152 141.75\" fill=\"none\" stroke=\"#702e2e\" stroke-width=\"0.65\" opacity=\".55\"/><path d=\"M139.33333333333334 55.33333333333333L174 39\" fill=\"none\" stroke=\"#f5ba63\" stroke-width=\"0.5\" opacity=\".5\"/><path d=\"M139.33333333333334 55.33333333333333L160.66666666666666 137.66666666666666\" fill=\"none\" stroke=\"#702e2e\" stroke-width=\"0.65\" opacity=\".55\"/><path d=\"M137.66666666666666 67.66666666666667L181 47.25\" fill=\"none\" stroke=\"#f5ba63\" stroke-width=\"0.5\" opacity=\".5\"/><path d=\"M137.66666666666666 67.66666666666667L169.33333333333334 133.58333333333334\" fill=\"none\" stroke=\"#702e2e\" stroke-width=\"0.65\" opacity=\".55\"/><path d=\"M136 80L188 55.5\" fill=\"none\" stroke=\"#f5ba63\" stroke-width=\"0.5\" opacity=\".5\"/><path d=\"M136 80L178 129.5\" fill=\"none\" stroke=\"#702e2e\" stroke-width=\"0.65\" opacity=\".55\"/><path d=\"M134.33333333333334 92.33333333333334L195 63.75000000000001\" fill=\"none\" stroke=\"#f5ba63\" stroke-width=\"0.5\" opacity=\".5\"/><path d=\"M134.33333333333334 92.33333333333334L186.66666666666669 125.41666666666666\" fill=\"none\" stroke=\"#702e2e\" stroke-width=\"0.65\" opacity=\".55\"/><path d=\"M132.66666666666666 104.66666666666666L202 72\" fill=\"none\" stroke=\"#f5ba63\" stroke-width=\"0.5\" opacity=\".5\"/><path d=\"M132.66666666666666 104.66666666666666L195.33333333333331 121.33333333333334\" fill=\"none\" stroke=\"#702e2e\" stroke-width=\"0.65\" opacity=\".55\"/><path d=\"M131 117L209 80.25\" fill=\"none\" stroke=\"#f5ba63\" stroke-width=\"0.5\" opacity=\".5\"/><path d=\"M131 117L204 117.25\" fill=\"none\" stroke=\"#702e2e\" stroke-width=\"0.65\" opacity=\".55\"/><path d=\"M129.33333333333334 129.33333333333334L216 88.5\" fill=\"none\" stroke=\"#f5ba63\" stroke-width=\"0.5\" opacity=\".5\"/><path d=\"M129.33333333333334 129.33333333333334L212.66666666666669 113.16666666666666\" fill=\"none\" stroke=\"#702e2e\" stroke-width=\"0.65\" opacity=\".55\"/><path d=\"M127.66666666666667 141.66666666666666L223 96.75\" fill=\"none\" stroke=\"#f5ba63\" stroke-width=\"0.5\" opacity=\".5\"/><path d=\"M127.66666666666667 141.66666666666666L221.33333333333331 109.08333333333334\" fill=\"none\" stroke=\"#702e2e\" stroke-width=\"0.65\" opacity=\".55\"/><path d=\"M146 6L45 81M126 154L50 123M230 105L56 100\" fill=\"none\" stroke=\"#e25146\" stroke-width=\"1.4\"/><path d=\"M126 154L118 162\" stroke=\"#bbb9ae\" stroke-width=\"2\"/><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"url(#grain)\" /></g>",
	array: "<g clip-path=\"url(#artClip)\"><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"url(#sky)\" /><path d=\"M0 62L34 52 65 58 99 46 140 54 175 41 211 50 240 44V85H0Z\" fill=\"#8c92a5\"/><path d=\"M0 75Q119 67 240 77V163H0Z\" fill=\"#bd8b4a\"/><path d=\"M0 109L240 87M0 148L240 99M40 163L184 84M172 163L135 85\" fill=\"none\" stroke=\"#f0d49a\" stroke-width=\"3\"/><g transform=\"translate(12 84) scale(0.28)\"><g transform=\"rotate(-10)\"><ellipse cy=\"13\" rx=\"13\" ry=\"4\" fill=\"#4b493c\" opacity=\".7\"/><path d=\"M-3-3L-8 13H8L3-3\" fill=\"#b6bcb6\" stroke=\"#606e6d\" stroke-width=\"1\"/><path d=\"M-12-23Q-14 0 4 1Q21-8 11-28Q2-11-12-23\" fill=\"url(#foil)\" stroke=\"#e8efe0\" stroke-width=\"1\"/><path d=\"M-11-22Q2-12 11-27M3-7L2-25\" fill=\"none\" stroke=\"#7c999d\" stroke-width=\"1\"/><circle cx=\"2\" cy=\"-25\" r=\"1.5\" fill=\"#f1ead8\"/></g></g><g transform=\"translate(59 84) scale(0.28)\"><g transform=\"rotate(-10)\"><ellipse cy=\"13\" rx=\"13\" ry=\"4\" fill=\"#4b493c\" opacity=\".7\"/><path d=\"M-3-3L-8 13H8L3-3\" fill=\"#b6bcb6\" stroke=\"#606e6d\" stroke-width=\"1\"/><path d=\"M-12-23Q-14 0 4 1Q21-8 11-28Q2-11-12-23\" fill=\"url(#foil)\" stroke=\"#e8efe0\" stroke-width=\"1\"/><path d=\"M-11-22Q2-12 11-27M3-7L2-25\" fill=\"none\" stroke=\"#7c999d\" stroke-width=\"1\"/><circle cx=\"2\" cy=\"-25\" r=\"1.5\" fill=\"#f1ead8\"/></g></g><g transform=\"translate(106 84) scale(0.28)\"><g transform=\"rotate(-10)\"><ellipse cy=\"13\" rx=\"13\" ry=\"4\" fill=\"#4b493c\" opacity=\".7\"/><path d=\"M-3-3L-8 13H8L3-3\" fill=\"#b6bcb6\" stroke=\"#606e6d\" stroke-width=\"1\"/><path d=\"M-12-23Q-14 0 4 1Q21-8 11-28Q2-11-12-23\" fill=\"url(#foil)\" stroke=\"#e8efe0\" stroke-width=\"1\"/><path d=\"M-11-22Q2-12 11-27M3-7L2-25\" fill=\"none\" stroke=\"#7c999d\" stroke-width=\"1\"/><circle cx=\"2\" cy=\"-25\" r=\"1.5\" fill=\"#f1ead8\"/></g></g><g transform=\"translate(153 84) scale(0.28)\"><g transform=\"rotate(-10)\"><ellipse cy=\"13\" rx=\"13\" ry=\"4\" fill=\"#4b493c\" opacity=\".7\"/><path d=\"M-3-3L-8 13H8L3-3\" fill=\"#b6bcb6\" stroke=\"#606e6d\" stroke-width=\"1\"/><path d=\"M-12-23Q-14 0 4 1Q21-8 11-28Q2-11-12-23\" fill=\"url(#foil)\" stroke=\"#e8efe0\" stroke-width=\"1\"/><path d=\"M-11-22Q2-12 11-27M3-7L2-25\" fill=\"none\" stroke=\"#7c999d\" stroke-width=\"1\"/><circle cx=\"2\" cy=\"-25\" r=\"1.5\" fill=\"#f1ead8\"/></g></g><g transform=\"translate(200 84) scale(0.28)\"><g transform=\"rotate(-10)\"><ellipse cy=\"13\" rx=\"13\" ry=\"4\" fill=\"#4b493c\" opacity=\".7\"/><path d=\"M-3-3L-8 13H8L3-3\" fill=\"#b6bcb6\" stroke=\"#606e6d\" stroke-width=\"1\"/><path d=\"M-12-23Q-14 0 4 1Q21-8 11-28Q2-11-12-23\" fill=\"url(#foil)\" stroke=\"#e8efe0\" stroke-width=\"1\"/><path d=\"M-11-22Q2-12 11-27M3-7L2-25\" fill=\"none\" stroke=\"#7c999d\" stroke-width=\"1\"/><circle cx=\"2\" cy=\"-25\" r=\"1.5\" fill=\"#f1ead8\"/></g></g><g transform=\"translate(2 116) scale(0.5900000000000001)\"><g transform=\"rotate(-10)\"><ellipse cy=\"13\" rx=\"13\" ry=\"4\" fill=\"#4b493c\" opacity=\".7\"/><path d=\"M-3-3L-8 13H8L3-3\" fill=\"#b6bcb6\" stroke=\"#606e6d\" stroke-width=\"1\"/><path d=\"M-12-23Q-14 0 4 1Q21-8 11-28Q2-11-12-23\" fill=\"url(#foil)\" stroke=\"#e8efe0\" stroke-width=\"1\"/><path d=\"M-11-22Q2-12 11-27M3-7L2-25\" fill=\"none\" stroke=\"#7c999d\" stroke-width=\"1\"/><circle cx=\"2\" cy=\"-25\" r=\"1.5\" fill=\"#f1ead8\"/></g></g><g transform=\"translate(52 116) scale(0.5900000000000001)\"><g transform=\"rotate(-10)\"><ellipse cy=\"13\" rx=\"13\" ry=\"4\" fill=\"#4b493c\" opacity=\".7\"/><path d=\"M-3-3L-8 13H8L3-3\" fill=\"#b6bcb6\" stroke=\"#606e6d\" stroke-width=\"1\"/><path d=\"M-12-23Q-14 0 4 1Q21-8 11-28Q2-11-12-23\" fill=\"url(#foil)\" stroke=\"#e8efe0\" stroke-width=\"1\"/><path d=\"M-11-22Q2-12 11-27M3-7L2-25\" fill=\"none\" stroke=\"#7c999d\" stroke-width=\"1\"/><circle cx=\"2\" cy=\"-25\" r=\"1.5\" fill=\"#f1ead8\"/></g></g><g transform=\"translate(102 116) scale(0.5900000000000001)\"><g transform=\"rotate(-10)\"><ellipse cy=\"13\" rx=\"13\" ry=\"4\" fill=\"#4b493c\" opacity=\".7\"/><path d=\"M-3-3L-8 13H8L3-3\" fill=\"#b6bcb6\" stroke=\"#606e6d\" stroke-width=\"1\"/><path d=\"M-12-23Q-14 0 4 1Q21-8 11-28Q2-11-12-23\" fill=\"url(#foil)\" stroke=\"#e8efe0\" stroke-width=\"1\"/><path d=\"M-11-22Q2-12 11-27M3-7L2-25\" fill=\"none\" stroke=\"#7c999d\" stroke-width=\"1\"/><circle cx=\"2\" cy=\"-25\" r=\"1.5\" fill=\"#f1ead8\"/></g></g><g transform=\"translate(152 116) scale(0.5900000000000001)\"><g transform=\"rotate(-10)\"><ellipse cy=\"13\" rx=\"13\" ry=\"4\" fill=\"#4b493c\" opacity=\".7\"/><path d=\"M-3-3L-8 13H8L3-3\" fill=\"#b6bcb6\" stroke=\"#606e6d\" stroke-width=\"1\"/><path d=\"M-12-23Q-14 0 4 1Q21-8 11-28Q2-11-12-23\" fill=\"url(#foil)\" stroke=\"#e8efe0\" stroke-width=\"1\"/><path d=\"M-11-22Q2-12 11-27M3-7L2-25\" fill=\"none\" stroke=\"#7c999d\" stroke-width=\"1\"/><circle cx=\"2\" cy=\"-25\" r=\"1.5\" fill=\"#f1ead8\"/></g></g><g transform=\"translate(202 116) scale(0.5900000000000001)\"><g transform=\"rotate(-10)\"><ellipse cy=\"13\" rx=\"13\" ry=\"4\" fill=\"#4b493c\" opacity=\".7\"/><path d=\"M-3-3L-8 13H8L3-3\" fill=\"#b6bcb6\" stroke=\"#606e6d\" stroke-width=\"1\"/><path d=\"M-12-23Q-14 0 4 1Q21-8 11-28Q2-11-12-23\" fill=\"url(#foil)\" stroke=\"#e8efe0\" stroke-width=\"1\"/><path d=\"M-11-22Q2-12 11-27M3-7L2-25\" fill=\"none\" stroke=\"#7c999d\" stroke-width=\"1\"/><circle cx=\"2\" cy=\"-25\" r=\"1.5\" fill=\"#f1ead8\"/></g></g><g transform=\"translate(-8 148) scale(0.9)\"><g transform=\"rotate(-10)\"><ellipse cy=\"13\" rx=\"13\" ry=\"4\" fill=\"#4b493c\" opacity=\".7\"/><path d=\"M-3-3L-8 13H8L3-3\" fill=\"#b6bcb6\" stroke=\"#606e6d\" stroke-width=\"1\"/><path d=\"M-12-23Q-14 0 4 1Q21-8 11-28Q2-11-12-23\" fill=\"url(#foil)\" stroke=\"#e8efe0\" stroke-width=\"1\"/><path d=\"M-11-22Q2-12 11-27M3-7L2-25\" fill=\"none\" stroke=\"#7c999d\" stroke-width=\"1\"/><circle cx=\"2\" cy=\"-25\" r=\"1.5\" fill=\"#f1ead8\"/></g></g><g transform=\"translate(45 148) scale(0.9)\"><g transform=\"rotate(-10)\"><ellipse cy=\"13\" rx=\"13\" ry=\"4\" fill=\"#4b493c\" opacity=\".7\"/><path d=\"M-3-3L-8 13H8L3-3\" fill=\"#b6bcb6\" stroke=\"#606e6d\" stroke-width=\"1\"/><path d=\"M-12-23Q-14 0 4 1Q21-8 11-28Q2-11-12-23\" fill=\"url(#foil)\" stroke=\"#e8efe0\" stroke-width=\"1\"/><path d=\"M-11-22Q2-12 11-27M3-7L2-25\" fill=\"none\" stroke=\"#7c999d\" stroke-width=\"1\"/><circle cx=\"2\" cy=\"-25\" r=\"1.5\" fill=\"#f1ead8\"/></g></g><g transform=\"translate(98 148) scale(0.9)\"><g transform=\"rotate(-10)\"><ellipse cy=\"13\" rx=\"13\" ry=\"4\" fill=\"#4b493c\" opacity=\".7\"/><path d=\"M-3-3L-8 13H8L3-3\" fill=\"#b6bcb6\" stroke=\"#606e6d\" stroke-width=\"1\"/><path d=\"M-12-23Q-14 0 4 1Q21-8 11-28Q2-11-12-23\" fill=\"url(#foil)\" stroke=\"#e8efe0\" stroke-width=\"1\"/><path d=\"M-11-22Q2-12 11-27M3-7L2-25\" fill=\"none\" stroke=\"#7c999d\" stroke-width=\"1\"/><circle cx=\"2\" cy=\"-25\" r=\"1.5\" fill=\"#f1ead8\"/></g></g><g transform=\"translate(151 148) scale(0.9)\"><g transform=\"rotate(-10)\"><ellipse cy=\"13\" rx=\"13\" ry=\"4\" fill=\"#4b493c\" opacity=\".7\"/><path d=\"M-3-3L-8 13H8L3-3\" fill=\"#b6bcb6\" stroke=\"#606e6d\" stroke-width=\"1\"/><path d=\"M-12-23Q-14 0 4 1Q21-8 11-28Q2-11-12-23\" fill=\"url(#foil)\" stroke=\"#e8efe0\" stroke-width=\"1\"/><path d=\"M-11-22Q2-12 11-27M3-7L2-25\" fill=\"none\" stroke=\"#7c999d\" stroke-width=\"1\"/><circle cx=\"2\" cy=\"-25\" r=\"1.5\" fill=\"#f1ead8\"/></g></g><g transform=\"translate(204 148) scale(0.9)\"><g transform=\"rotate(-10)\"><ellipse cy=\"13\" rx=\"13\" ry=\"4\" fill=\"#4b493c\" opacity=\".7\"/><path d=\"M-3-3L-8 13H8L3-3\" fill=\"#b6bcb6\" stroke=\"#606e6d\" stroke-width=\"1\"/><path d=\"M-12-23Q-14 0 4 1Q21-8 11-28Q2-11-12-23\" fill=\"url(#foil)\" stroke=\"#e8efe0\" stroke-width=\"1\"/><path d=\"M-11-22Q2-12 11-27M3-7L2-25\" fill=\"none\" stroke=\"#7c999d\" stroke-width=\"1\"/><circle cx=\"2\" cy=\"-25\" r=\"1.5\" fill=\"#f1ead8\"/></g></g><g transform=\"translate(143 151) scale(1.06)\"><g transform=\"rotate(-12)\"><ellipse cy=\"13\" rx=\"13\" ry=\"4\" fill=\"#4b493c\" opacity=\".7\"/><path d=\"M-3-3L-8 13H8L3-3\" fill=\"#b6bcb6\" stroke=\"#606e6d\" stroke-width=\"1\"/><path d=\"M-12-23Q-14 0 4 1Q21-8 11-28Q2-11-12-23\" fill=\"url(#foil)\" stroke=\"#e8efe0\" stroke-width=\"1\"/><path d=\"M-11-22Q2-12 11-27M3-7L2-25\" fill=\"none\" stroke=\"#7c999d\" stroke-width=\"1\"/><circle cx=\"2\" cy=\"-25\" r=\"1.5\" fill=\"#f1ead8\"/></g></g><path d=\"M0 155Q45 138 71 147T134 163M196 146L240 127\" fill=\"none\" stroke=\"#f8d699\" stroke-width=\"2\"/><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"url(#grain)\" /></g>",
	focus: "<g clip-path=\"url(#artClip)\"><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"#163e66\" /><path d=\"M0 0L29 16 48 56 95 36 121 0H240V103L0 123Z\" fill=\"#2878aa\"/><path d=\"M134 0L121 96M151 0L147 98M71 0L87 29 102 0M191 0L176 23 222 27 232 2\" fill=\"none\" stroke=\"#80c0cf\" stroke-width=\"4\"/><path d=\"M132 0L119 96M149 0L145 97M184 29L190 84\" stroke=\"#092c5d\" stroke-width=\"5\"/><path d=\"M0 123L240 76V163H0Z\" fill=\"#603b32\"/><path d=\"M0 132L240 86V163H0Z\" fill=\"#448b3b\"/><path d=\"M12 145L192 103 228 112 99 158M15 157L158 126 219 134M34 133L66 139 112 128 128 141M141 159L162 139 210 145\" fill=\"none\" stroke=\"#a6c460\" stroke-width=\"1.5\"/><path d=\"M12 130L36 137M197 99L218 104\" stroke=\"#d1df92\" stroke-width=\"3\"/><g transform=\"translate(18 142) rotate(-13)\"><rect x=\"0\" y=\"0\" width=\"11\" height=\"5\" rx=\"1\" fill=\"#c1cd98\" /><path d=\"M2 -2L2 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /><path d=\"M8 -2L8 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /></g><g transform=\"translate(36 132) rotate(-13)\"><rect x=\"0\" y=\"0\" width=\"11\" height=\"5\" rx=\"1\" fill=\"#152f31\" /><path d=\"M2 -2L2 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /><path d=\"M8 -2L8 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /></g><g transform=\"translate(54 122) rotate(-13)\"><rect x=\"0\" y=\"0\" width=\"11\" height=\"5\" rx=\"1\" fill=\"#c1cd98\" /><path d=\"M2 -2L2 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /><path d=\"M8 -2L8 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /></g><g transform=\"translate(72 142) rotate(-13)\"><rect x=\"0\" y=\"0\" width=\"11\" height=\"5\" rx=\"1\" fill=\"#152f31\" /><path d=\"M2 -2L2 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /><path d=\"M8 -2L8 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /></g><g transform=\"translate(90 132) rotate(-13)\"><rect x=\"0\" y=\"0\" width=\"11\" height=\"5\" rx=\"1\" fill=\"#c1cd98\" /><path d=\"M2 -2L2 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /><path d=\"M8 -2L8 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /></g><g transform=\"translate(108 122) rotate(-13)\"><rect x=\"0\" y=\"0\" width=\"11\" height=\"5\" rx=\"1\" fill=\"#152f31\" /><path d=\"M2 -2L2 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /><path d=\"M8 -2L8 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /></g><g transform=\"translate(126 142) rotate(-13)\"><rect x=\"0\" y=\"0\" width=\"11\" height=\"5\" rx=\"1\" fill=\"#c1cd98\" /><path d=\"M2 -2L2 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /><path d=\"M8 -2L8 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /></g><g transform=\"translate(144 132) rotate(-13)\"><rect x=\"0\" y=\"0\" width=\"11\" height=\"5\" rx=\"1\" fill=\"#152f31\" /><path d=\"M2 -2L2 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /><path d=\"M8 -2L8 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /></g><g transform=\"translate(162 122) rotate(-13)\"><rect x=\"0\" y=\"0\" width=\"11\" height=\"5\" rx=\"1\" fill=\"#c1cd98\" /><path d=\"M2 -2L2 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /><path d=\"M8 -2L8 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /></g><g transform=\"translate(180 142) rotate(-13)\"><rect x=\"0\" y=\"0\" width=\"11\" height=\"5\" rx=\"1\" fill=\"#152f31\" /><path d=\"M2 -2L2 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /><path d=\"M8 -2L8 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /></g><g transform=\"translate(198 132) rotate(-13)\"><rect x=\"0\" y=\"0\" width=\"11\" height=\"5\" rx=\"1\" fill=\"#c1cd98\" /><path d=\"M2 -2L2 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /><path d=\"M8 -2L8 7\" fill=\"none\" stroke=\"#d0c798\" stroke-width=\"0.8\" /></g><path d=\"M0 47L30 35 55 54 42 85 0 109Z\" fill=\"#245585\"/><path d=\"M32 38Q48 31 66 39L91 55Q98 63 108 95L116 119Q115 129 107 125L92 101 87 94 103 123Q103 134 95 130L76 103 71 98 85 127Q83 137 76 129L56 107 47 102Q39 95 29 86Q16 65 32 38Z\" fill=\"url(#skin)\" stroke=\"#ad6b54\" stroke-width=\"1\"/><path d=\"M39 42L63 47 81 62 91 91M34 52L53 64 68 89M28 65L44 77 53 96\" fill=\"none\" stroke=\"#bc7858\" stroke-width=\"3\"/><path d=\"M79 65L93 102 104 121 109 119 101 93 91 63Z\" fill=\"#f8cda0\"/><path d=\"M240 88Q212 78 196 89L175 108 159 136Q161 143 169 138L185 122 191 120 176 143Q175 153 185 149L208 125 222 120 239 123Z\" fill=\"url(#skin)\" stroke=\"#a36550\"/><path d=\"M196 92L211 93 232 100M192 101L207 103 224 111\" fill=\"none\" stroke=\"#ae6a50\" stroke-width=\"2\"/><path d=\"M100 123L111 116 119 130 109 136Z\" fill=\"#203c39\" stroke=\"#f8dc89\" stroke-width=\"1\"/><path d=\"M109 130L148 143M116 132L148 129M118 127L142 115\" stroke=\"#fff6ad\" stroke-width=\"1.2\"/><circle cx=\"120\" cy=\"134\" r=\"13\" fill=\"#fff68c\" opacity=\".22\"/><path d=\"M74 163Q73 117 88 133M52 161Q59 119 71 130\" fill=\"none\" stroke=\"#eeae35\" stroke-width=\"2\"/><circle cx=\"131\" cy=\"20\" r=\"4\" fill=\"#d5b85f\" stroke=\"#62533f\"/><path d=\"M130 18L133 22\" fill=\"none\" stroke=\"#6f613a\" stroke-width=\"1\" /><circle cx=\"128\" cy=\"57\" r=\"4\" fill=\"#d5b85f\" stroke=\"#62533f\"/><path d=\"M127 55L130 59\" fill=\"none\" stroke=\"#6f613a\" stroke-width=\"1\" /><circle cx=\"124\" cy=\"88\" r=\"4\" fill=\"#d5b85f\" stroke=\"#62533f\"/><path d=\"M123 86L126 90\" fill=\"none\" stroke=\"#6f613a\" stroke-width=\"1\" /><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"url(#grain)\" /></g>",
	sample: "<g clip-path=\"url(#artClip)\"><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"url(#desert)\" /><path d=\"M0 0H240V93Q112 133 0 98Z\" fill=\"#ec6539\"/><path d=\"M0 127L41 111 83 130 133 118 194 144 240 135V163H0Z\" fill=\"#a1543a\"/><path d=\"M0 146Q68 124 240 155\" fill=\"none\" stroke=\"#f5aa68\" stroke-width=\"4\"/><path d=\"M54 130Q92 97 111 91T169 50\" fill=\"none\" stroke=\"#ffe5a1\" stroke-width=\"16\"/><circle cx=\"57\" cy=\"127\" r=\"13\" fill=\"#fff0bc\" opacity=\".7\"/><circle cx=\"66\" cy=\"120.5\" r=\"12.3\" fill=\"#fff0bc\" opacity=\".7\"/><circle cx=\"75\" cy=\"114\" r=\"11.6\" fill=\"#fff0bc\" opacity=\".7\"/><circle cx=\"84\" cy=\"107.5\" r=\"10.9\" fill=\"#fff0bc\" opacity=\".7\"/><circle cx=\"93\" cy=\"101\" r=\"10.2\" fill=\"#fff0bc\" opacity=\".7\"/><circle cx=\"102\" cy=\"94.5\" r=\"9.5\" fill=\"#fff0bc\" opacity=\".7\"/><circle cx=\"111\" cy=\"88\" r=\"8.8\" fill=\"#fff0bc\" opacity=\".7\"/><circle cx=\"120\" cy=\"81.5\" r=\"8.100000000000001\" fill=\"#fff0bc\" opacity=\".7\"/><circle cx=\"129\" cy=\"75\" r=\"7.4\" fill=\"#fff0bc\" opacity=\".7\"/><circle cx=\"138\" cy=\"68.5\" r=\"6.7\" fill=\"#fff0bc\" opacity=\".7\"/><circle cx=\"147\" cy=\"62\" r=\"6\" fill=\"#fff0bc\" opacity=\".7\"/><circle cx=\"156\" cy=\"55.5\" r=\"5.300000000000001\" fill=\"#fff0bc\" opacity=\".7\"/><g transform=\"translate(177 43) rotate(46)\"><path d=\"M0-13L7 3 5 16-5 16-7 3Z\" fill=\"#d7d1b6\" stroke=\"#534b46\"/><path d=\"M-3 17L0 34 3 17Z\" fill=\"#fff6b4\"/></g><g transform=\"translate(58 131)\"><path d=\"M-27-7L22-12 30 4-19 10Z\" fill=\"#6f5148\" stroke=\"#392e2b\"/><path d=\"M-20 6L-27 23M23 4L29 18M-25 22H-16M25 18H34\" stroke=\"#453c36\" stroke-width=\"3\"/><path d=\"M-7-11V-29M-16-27H6\" stroke=\"#d7b47a\" stroke-width=\"2\"/><circle cx=\"15\" cy=\"-7\" r=\"6\" fill=\"#342c2d\"/></g><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"url(#grain)\" /></g>",
	telescope: "<g clip-path=\"url(#artClip)\"><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"url(#sky)\" /><path d=\"M0 119L57 106 121 116 175 102 240 115V163H0Z\" fill=\"#d6b379\"/><path d=\"M0 142Q70 114 240 143\" fill=\"none\" stroke=\"#f7dba6\" stroke-width=\"4\"/><g transform=\"translate(34 135) scale(1.1)\"><g transform=\"rotate(-10)\"><ellipse cy=\"13\" rx=\"13\" ry=\"4\" fill=\"#4b493c\" opacity=\".7\"/><path d=\"M-3-3L-8 13H8L3-3\" fill=\"#b6bcb6\" stroke=\"#606e6d\" stroke-width=\"1\"/><path d=\"M-12-23Q-14 0 4 1Q21-8 11-28Q2-11-12-23\" fill=\"url(#foil)\" stroke=\"#e8efe0\" stroke-width=\"1\"/><path d=\"M-11-22Q2-12 11-27M3-7L2-25\" fill=\"none\" stroke=\"#7c999d\" stroke-width=\"1\"/><circle cx=\"2\" cy=\"-25\" r=\"1.5\" fill=\"#f1ead8\"/></g></g><g transform=\"translate(93 125) scale(2.4)\"><g transform=\"rotate(20)\"><ellipse cy=\"13\" rx=\"13\" ry=\"4\" fill=\"#4b493c\" opacity=\".7\"/><path d=\"M-3-3L-8 13H8L3-3\" fill=\"#b6bcb6\" stroke=\"#606e6d\" stroke-width=\"1\"/><path d=\"M-12-23Q-14 0 4 1Q21-8 11-28Q2-11-12-23\" fill=\"url(#foil)\" stroke=\"#e8efe0\" stroke-width=\"1\"/><path d=\"M-11-22Q2-12 11-27M3-7L2-25\" fill=\"none\" stroke=\"#7c999d\" stroke-width=\"1\"/><circle cx=\"2\" cy=\"-25\" r=\"1.5\" fill=\"#f1ead8\"/></g></g><path d=\"M139 163L142 123Q156 107 183 108L203 98 231 115 240 122V163Z\" fill=\"#24364b\"/><path d=\"M184 107L184 84Q172 72 183 52Q194 34 212 43Q230 53 221 74L219 98 230 119Z\" fill=\"#6b4540\"/><path d=\"M181 68Q171 45 194 38Q226 32 228 57L222 85 215 80 209 64Z\" fill=\"#202d39\"/><path d=\"M147 135L182 126 211 137M161 151L191 140\" fill=\"none\" stroke=\"#4d6275\" stroke-width=\"4\"/><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"url(#grain)\" /></g>",
	solvay: "<g clip-path=\"url(#artClip)\"><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"#c6c0ac\" /><path d=\"M110 0H240V145H94Z\" fill=\"#d4d0bd\"/><path d=\"M126 0V118M150 0V118M175 0V118M200 0V118M226 0V118\" stroke=\"#827e71\" stroke-width=\"5\"/><path d=\"M118 24H240M110 47H240M103 74H240\" stroke=\"#ece5cd\" stroke-width=\"4\"/><path d=\"M0 28Q40-17 84 13L94 55 0 76Z\" fill=\"#7a7753\"/><path d=\"M0 140H240V163H0Z\" fill=\"#7c7b72\"/><g transform=\"translate(20 55)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#454a49\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#43423d\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(42 55)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#262d32\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#dfd5bc\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(64 55)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#262d32\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#43423d\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(86 55)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#454a49\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#43423d\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(108 55)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#262d32\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#dfd5bc\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(130 55)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#262d32\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#43423d\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(152 55)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#454a49\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#43423d\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(174 55)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#262d32\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#dfd5bc\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(196 55)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#262d32\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#43423d\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(9 87)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#454a49\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#43423d\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(31 87)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#262d32\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#dfd5bc\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(53 87)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#262d32\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#43423d\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(75 87)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#454a49\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#43423d\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(97 87)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#262d32\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#dfd5bc\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(119 87)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#262d32\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#43423d\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(141 87)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#454a49\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#43423d\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(163 87)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#262d32\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#dfd5bc\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(185 87)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#262d32\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#43423d\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(207 87)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#454a49\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#43423d\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(229 87)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#262d32\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#dfd5bc\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(9 119)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#454a49\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#43423d\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(31 119)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#262d32\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#dfd5bc\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(53 119)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#262d32\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#43423d\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(75 119)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#454a49\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#43423d\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(97 119)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#262d32\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#dfd5bc\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(119 119)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#262d32\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#43423d\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(141 119)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#454a49\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#43423d\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(163 119)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#262d32\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#dfd5bc\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(185 119)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#262d32\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#43423d\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(207 119)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#454a49\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#43423d\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><g transform=\"translate(229 119)\"><path d=\"M-8 13L-11 42-5 56H-1L1 34 4 56H9L10 13Z\" fill=\"#262d32\"/><path d=\"M-3 11L0 29 5 11Z\" fill=\"#e9dec5\"/><path d=\"M0 15L2 25 4 14Z\" fill=\"#6f5449\"/><circle cx=\"0\" cy=\"5\" r=\"6.3\" fill=\"#c8a47f\" /><path d=\"M-6 4Q-6-4 1-3L6 1\" fill=\"none\" stroke=\"#dfd5bc\" stroke-width=\"3\"/><path d=\"M-2 8H3\" stroke=\"#715f50\" stroke-width=\".8\"/></g><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"url(#grain)\" /></g>",
	pixl: "<g clip-path=\"url(#artClip)\"><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"url(#desert)\" /><path d=\"M0 53L60 24 112 46 165 25 240 66V163H0Z\" fill=\"#dc8750\"/><path d=\"M0 117L44 88 83 123 139 95 194 141 240 120V163H0Z\" fill=\"#be6442\"/><g transform=\"translate(126 86) rotate(10)\"><path d=\"M-82 82L-54 46-26 31 0 0\" fill=\"none\" stroke=\"#3e3c3c\" stroke-width=\"17\"/><path d=\"M-83 78L-55 43-25 29\" fill=\"none\" stroke=\"#9e8b72\" stroke-width=\"7\"/><path d=\"M-40-39L20-50 51-18 40 35-26 37-49 3Z\" fill=\"#b98b67\" stroke=\"#493b35\" stroke-width=\"3\"/><path d=\"M-25-38H25L34-24H-22Z\" fill=\"#e4bc8b\"/><path d=\"M18-29H40V28H18Z\" fill=\"#443e3b\"/><path d=\"M-33-10L13-13 18 31-24 33Z\" fill=\"#e7bd8c\" stroke=\"#98694d\"/><circle cx=\"-8\" cy=\"12\" r=\"11\" fill=\"#9b634a\" stroke=\"#e3b283\" stroke-width=\"3\"/><path d=\"M-44-18Q-64-20-63 2Q-58 19-44 14Z\" fill=\"url(#foil)\" stroke=\"#644c3c\"/><path d=\"M39-16H65M39 0H63M38 17H61\" stroke=\"#423a38\" stroke-width=\"5\"/><path d=\"M-26-38V-52H17V-45M-48-7L-52-29-23-36\" fill=\"none\" stroke=\"#e2af7c\" stroke-width=\"3\"/></g><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"url(#grain)\" /></g>",
	correction: "<g clip-path=\"url(#artClip)\"><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"#311d38\" /><circle cx=\"62.05104326829314\" cy=\"87.91980194766074\" r=\"0.6727215223177336\" fill=\"#c7e6ed\" opacity=\"0.5111117378622294\"/><circle cx=\"9.388877134770155\" cy=\"161.21315785124898\" r=\"0.5122927319887094\" fill=\"#c7e6ed\" opacity=\"0.49291554830968376\"/><circle cx=\"3.1814016960561275\" cy=\"148.9510580552742\" r=\"0.31589113261317836\" fill=\"#c7e6ed\" opacity=\"0.3392022932320833\"/><circle cx=\"65.22738022729754\" cy=\"14.757718401029706\" r=\"0.43224215038819236\" fill=\"#c7e6ed\" opacity=\"0.38317139737308026\"/><circle cx=\"141.76252668723464\" cy=\"31.50680159870535\" r=\"0.8166174227534793\" fill=\"#c7e6ed\" opacity=\"0.15742108918726444\"/><circle cx=\"145.8960291557014\" cy=\"30.28180541098118\" r=\"0.45273726421175525\" fill=\"#c7e6ed\" opacity=\"0.3150323852151632\"/><circle cx=\"197.15644827112556\" cy=\"145.14797427412122\" r=\"0.852846960274037\" fill=\"#c7e6ed\" opacity=\"0.16924682445824146\"/><circle cx=\"101.8969906680286\" cy=\"152.84510935656726\" r=\"0.5804981395299547\" fill=\"#c7e6ed\" opacity=\"0.12923795275390149\"/><circle cx=\"58.31015741452575\" cy=\"89.26065205503255\" r=\"0.25306647384306413\" fill=\"#c7e6ed\" opacity=\"0.18947655715048312\"/><circle cx=\"69.801767449826\" cy=\"138.29241592809558\" r=\"0.2935369566711597\" fill=\"#c7e6ed\" opacity=\"0.15018965028226375\"/><circle cx=\"170.4743560217321\" cy=\"111.46034206729382\" r=\"0.2635880095115863\" fill=\"#c7e6ed\" opacity=\"0.1664132047444582\"/><circle cx=\"26.4699481241405\" cy=\"18.376652905717492\" r=\"0.3225056664715521\" fill=\"#c7e6ed\" opacity=\"0.3431386374682188\"/><circle cx=\"136.92220693454146\" cy=\"8.933779464103281\" r=\"0.46895908696344124\" fill=\"#c7e6ed\" opacity=\"0.1340530440956354\"/><circle cx=\"198.26795725151896\" cy=\"127.81943703442812\" r=\"0.23516864652512595\" fill=\"#c7e6ed\" opacity=\"0.3413731833547353\"/><circle cx=\"95.66808393225074\" cy=\"36.71822430100292\" r=\"0.8654978557652794\" fill=\"#c7e6ed\" opacity=\"0.5542732114344835\"/><circle cx=\"165.28780533000827\" cy=\"41.30912089906633\" r=\"0.3240003574336879\" fill=\"#c7e6ed\" opacity=\"0.3434061663597822\"/><circle cx=\"71.18632173165679\" cy=\"73.91825841087848\" r=\"0.5879532516165636\" fill=\"#c7e6ed\" opacity=\"0.16901920236647128\"/><circle cx=\"20.565838795155287\" cy=\"6.436339799314737\" r=\"0.996907999056857\" fill=\"#c7e6ed\" opacity=\"0.4801625742763281\"/><circle cx=\"181.1299659870565\" cy=\"144.86008227895945\" r=\"0.9392901525995694\" fill=\"#c7e6ed\" opacity=\"0.48249237187206745\"/><circle cx=\"224.3014900200069\" cy=\"145.5670586246997\" r=\"0.5210791667620651\" fill=\"#c7e6ed\" opacity=\"0.5721670042723417\"/><circle cx=\"18.049523290246725\" cy=\"13.183311917819083\" r=\"0.8235995354293845\" fill=\"#c7e6ed\" opacity=\"0.5533374343067408\"/><circle cx=\"153.07602731510997\" cy=\"34.65311872959137\" r=\"0.4699545076745562\" fill=\"#c7e6ed\" opacity=\"0.2767311628907919\"/><circle cx=\"86.11171117052436\" cy=\"130.87027574237436\" r=\"0.7321336317039094\" fill=\"#c7e6ed\" opacity=\"0.33682996340095994\"/><circle cx=\"144.07130492851138\" cy=\"125.98028480820358\" r=\"1.023325376927387\" fill=\"#c7e6ed\" opacity=\"0.5851413660496473\"/><circle cx=\"12.81820809468627\" cy=\"30.21281144488603\" r=\"0.832466084153857\" fill=\"#c7e6ed\" opacity=\"0.5770638922601938\"/><circle cx=\"74.28851304575801\" cy=\"124.85379176959395\" r=\"0.5705564939114265\" fill=\"#c7e6ed\" opacity=\"0.4298460390418768\"/><circle cx=\"15.724403467029333\" cy=\"26.71656286995858\" r=\"0.8107771028927527\" fill=\"#c7e6ed\" opacity=\"0.20913901336491109\"/><circle cx=\"234.76692778989673\" cy=\"25.221391612663865\" r=\"0.4669335985253565\" fill=\"#c7e6ed\" opacity=\"0.401643216535449\"/><circle cx=\"104.15814762935042\" cy=\"38.942776889540255\" r=\"0.6172636216669344\" fill=\"#c7e6ed\" opacity=\"0.39134847857058047\"/><circle cx=\"179.8026612214744\" cy=\"55.23390030115843\" r=\"0.49313610742567104\" fill=\"#c7e6ed\" opacity=\"0.1368680425733328\"/><circle cx=\"135.93850186094642\" cy=\"89.28760027792305\" r=\"0.41467445410555226\" fill=\"#c7e6ed\" opacity=\"0.28736629910767075\"/><circle cx=\"111.16741133853793\" cy=\"21.74324463866651\" r=\"0.31783477027667684\" fill=\"#c7e6ed\" opacity=\"0.4145802705734968\"/><circle cx=\"9.094488378614187\" cy=\"40.6988765867427\" r=\"0.5799704499705695\" fill=\"#c7e6ed\" opacity=\"0.43843484558165075\"/><circle cx=\"237.32721207663417\" cy=\"9.73800914362073\" r=\"1.013414326000493\" fill=\"#c7e6ed\" opacity=\"0.36375176332890985\"/><circle cx=\"228.5838403366506\" cy=\"36.3304430199787\" r=\"0.9091096514067613\" fill=\"#c7e6ed\" opacity=\"0.28555234797298906\"/><circle cx=\"27.661183308809996\" cy=\"154.71648292429745\" r=\"0.6748211590270512\" fill=\"#c7e6ed\" opacity=\"0.3404539930075407\"/><circle cx=\"208.01175182685256\" cy=\"12.133927308954298\" r=\"0.7249574491917156\" fill=\"#c7e6ed\" opacity=\"0.40166039563715455\"/><circle cx=\"1.6802808456122875\" cy=\"139.9972065538168\" r=\"0.2915359555440955\" fill=\"#c7e6ed\" opacity=\"0.395045541152358\"/><circle cx=\"66.34962787851691\" cy=\"75.38804458733648\" r=\"0.7383217389858328\" fill=\"#c7e6ed\" opacity=\"0.31383143730461593\"/><circle cx=\"53.24604643508792\" cy=\"48.96701894514263\" r=\"0.3226713597471826\" fill=\"#c7e6ed\" opacity=\"0.5693595986813307\"/><circle cx=\"159.65383445844054\" cy=\"119.16539426613599\" r=\"0.7121130775823258\" fill=\"#c7e6ed\" opacity=\"0.555456281080842\"/><circle cx=\"69.78935776278377\" cy=\"127.26660422608256\" r=\"0.7251946300896815\" fill=\"#c7e6ed\" opacity=\"0.14389146588742732\"/><circle cx=\"27.784448470920324\" cy=\"139.73675690870732\" r=\"0.57862983915722\" fill=\"#c7e6ed\" opacity=\"0.3084315944463014\"/><circle cx=\"206.5291784517467\" cy=\"106.91353861428797\" r=\"1.0352752955327742\" fill=\"#c7e6ed\" opacity=\"0.15498605243861674\"/><circle cx=\"116.12400775775313\" cy=\"115.91289110574871\" r=\"0.7599683715193531\" fill=\"#c7e6ed\" opacity=\"0.23534740425646306\"/><circle cx=\"95.6913080625236\" cy=\"48.36283729225397\" r=\"0.5027578117954544\" fill=\"#c7e6ed\" opacity=\"0.5420253773778676\"/><circle cx=\"32.296261098235846\" cy=\"102.32383035030216\" r=\"0.8415581523603759\" fill=\"#c7e6ed\" opacity=\"0.4216745967417955\"/><circle cx=\"110.72713209316134\" cy=\"92.50500128231943\" r=\"0.8287592176045291\" fill=\"#c7e6ed\" opacity=\"0.5646160691231489\"/><circle cx=\"57.884918209165335\" cy=\"47.6356799127534\" r=\"0.848821945504751\" fill=\"#c7e6ed\" opacity=\"0.14795241750776766\"/><circle cx=\"125.5323719792068\" cy=\"100.60156432166696\" r=\"0.45639179094461724\" fill=\"#c7e6ed\" opacity=\"0.5697768654674291\"/><circle cx=\"155.15239974483848\" cy=\"152.70491371583194\" r=\"0.8769609571597539\" fill=\"#c7e6ed\" opacity=\"0.4519759715348482\"/><circle cx=\"88.66583509370685\" cy=\"160.15813973732293\" r=\"0.8146107053081505\" fill=\"#c7e6ed\" opacity=\"0.30912611357867714\"/><circle cx=\"68.75858729705215\" cy=\"138.670171209611\" r=\"0.7738649921654723\" fill=\"#c7e6ed\" opacity=\"0.3609837231785059\"/><circle cx=\"12.568164747208357\" cy=\"0.7349673211574554\" r=\"0.715186685945373\" fill=\"#c7e6ed\" opacity=\"0.5260692699998617\"/><circle cx=\"42.479573395103216\" cy=\"32.981554246507585\" r=\"0.7261476102448068\" fill=\"#c7e6ed\" opacity=\"0.23384499616920945\"/><circle cx=\"97.78059018775821\" cy=\"90.69496020488441\" r=\"1.0028036661143416\" fill=\"#c7e6ed\" opacity=\"0.13298640064895154\"/><circle cx=\"230.92641150578856\" cy=\"28.367423956282437\" r=\"1.0483062822534703\" fill=\"#c7e6ed\" opacity=\"0.21324747361242768\"/><circle cx=\"32.16367660090327\" cy=\"13.889251735061407\" r=\"0.758281443330925\" fill=\"#c7e6ed\" opacity=\"0.49841968081891536\"/><circle cx=\"6.2638660334050655\" cy=\"66.73869762104005\" r=\"0.32500754642998797\" fill=\"#c7e6ed\" opacity=\"0.5078846979886293\"/><circle cx=\"105.11607510969043\" cy=\"157.2802423480898\" r=\"0.3549233356188051\" fill=\"#c7e6ed\" opacity=\"0.5242608951777219\"/><circle cx=\"39.929162319749594\" cy=\"126.03064555022866\" r=\"0.4064971646456979\" fill=\"#c7e6ed\" opacity=\"0.1446435711532831\"/><circle cx=\"56.79327277466655\" cy=\"26.50214644521475\" r=\"0.3179888377594762\" fill=\"#c7e6ed\" opacity=\"0.2729389377683401\"/><circle cx=\"199.35073664411902\" cy=\"68.98218795564026\" r=\"0.4071352786547504\" fill=\"#c7e6ed\" opacity=\"0.4307918543368578\"/><circle cx=\"222.3263425938785\" cy=\"35.35903926752508\" r=\"0.23729127754224463\" fill=\"#c7e6ed\" opacity=\"0.1846073120087385\"/><circle cx=\"219.66698622331023\" cy=\"31.85269182641059\" r=\"0.9570565663441084\" fill=\"#c7e6ed\" opacity=\"0.16616566814482212\"/><circle cx=\"171.04069350287318\" cy=\"86.26040377095342\" r=\"0.28292047201422976\" fill=\"#c7e6ed\" opacity=\"0.20433163069188592\"/><circle cx=\"30.445019211620092\" cy=\"49.07626780401915\" r=\"0.8569553979835473\" fill=\"#c7e6ed\" opacity=\"0.36535699255764487\"/><circle cx=\"120.67482037469745\" cy=\"157.59417750127614\" r=\"0.2240903837303631\" fill=\"#c7e6ed\" opacity=\"0.25927711598575115\"/><circle cx=\"217.39940470084548\" cy=\"54.85356705728918\" r=\"0.5859959924756549\" fill=\"#c7e6ed\" opacity=\"0.2499011669307947\"/><circle cx=\"86.59905401989818\" cy=\"127.03729946911335\" r=\"1.0511117770033889\" fill=\"#c7e6ed\" opacity=\"0.16589609943330286\"/><circle cx=\"219.11092272028327\" cy=\"98.68107815738767\" r=\"0.7628475736058317\" fill=\"#c7e6ed\" opacity=\"0.3504643899947405\"/><circle cx=\"126.03431118652225\" cy=\"134.80375702492893\" r=\"0.7004898741538637\" fill=\"#c7e6ed\" opacity=\"0.4071155219525099\"/><circle cx=\"18.745314236730337\" cy=\"122.81792395282537\" r=\"0.6598445262922905\" fill=\"#c7e6ed\" opacity=\"0.2390312198549509\"/><circle cx=\"237.27084456011653\" cy=\"19.830132734030485\" r=\"0.8831470117601565\" fill=\"#c7e6ed\" opacity=\"0.4195244338363409\"/><circle cx=\"50.77203115448356\" cy=\"116.69015844445676\" r=\"1.0202715528360569\" fill=\"#c7e6ed\" opacity=\"0.4910920739918947\"/><circle cx=\"153.8869927637279\" cy=\"110.89865125156939\" r=\"0.36577029690844937\" fill=\"#c7e6ed\" opacity=\"0.1505614947527647\"/><circle cx=\"42.682986315339804\" cy=\"159.23256366048008\" r=\"0.9787738291709683\" fill=\"#c7e6ed\" opacity=\"0.23783072926104068\"/><circle cx=\"233.96793035790324\" cy=\"112.69772619754076\" r=\"1.0552842634427362\" fill=\"#c7e6ed\" opacity=\"0.56570247374475\"/><circle cx=\"151.71130349859595\" cy=\"23.167946531437337\" r=\"0.9848921611136756\" fill=\"#c7e6ed\" opacity=\"0.3883118218928575\"/><circle cx=\"84.32441784068942\" cy=\"161.82000703178346\" r=\"0.5364485282148235\" fill=\"#c7e6ed\" opacity=\"0.2256477492302656\"/><circle cx=\"76.55006742104888\" cy=\"134.22393576521426\" r=\"0.6797231406136416\" fill=\"#c7e6ed\" opacity=\"0.5216683474928141\"/><circle cx=\"199.7115516476333\" cy=\"140.6979259289801\" r=\"0.8125804473343304\" fill=\"#c7e6ed\" opacity=\"0.41350980900228024\"/><circle cx=\"224.07107373699546\" cy=\"136.28727872204036\" r=\"0.22570430200314148\" fill=\"#c7e6ed\" opacity=\"0.489289161041379\"/><circle cx=\"137.0475141517818\" cy=\"20.47674465365708\" r=\"0.949402772418689\" fill=\"#c7e6ed\" opacity=\"0.5720007502287626\"/><circle cx=\"131.04357903823256\" cy=\"115.49563828948885\" r=\"0.8395242782472633\" fill=\"#c7e6ed\" opacity=\"0.487006476894021\"/><circle cx=\"184.63232366368175\" cy=\"91.82510143518448\" r=\"0.8220163068431429\" fill=\"#c7e6ed\" opacity=\"0.37061977945268154\"/><circle cx=\"140.85305085405707\" cy=\"82.26688975747675\" r=\"0.27815795719390735\" fill=\"#c7e6ed\" opacity=\"0.557283368781209\"/><circle cx=\"46.36658443138003\" cy=\"105.68305784277618\" r=\"0.6649975619907491\" fill=\"#c7e6ed\" opacity=\"0.24284071259200574\"/><circle cx=\"95.21991765126586\" cy=\"156.26591769326478\" r=\"0.27802663782378656\" fill=\"#c7e6ed\" opacity=\"0.4814012698084116\"/><circle cx=\"60.970236640423536\" cy=\"94.9476456604898\" r=\"0.6756214135023765\" fill=\"#c7e6ed\" opacity=\"0.3932994749397039\"/><circle cx=\"80.9183188341558\" cy=\"150.30891281645745\" r=\"0.44728318650042637\" fill=\"#c7e6ed\" opacity=\"0.5416474724560976\"/><circle cx=\"156.20130641385913\" cy=\"106.0959137622267\" r=\"0.6702087575267069\" fill=\"#c7e6ed\" opacity=\"0.1949816011637449\"/><circle cx=\"111.49485474452376\" cy=\"20.205168874002993\" r=\"0.7112221932201647\" fill=\"#c7e6ed\" opacity=\"0.27350262857973573\"/><circle cx=\"138.0746558122337\" cy=\"144.745474986732\" r=\"0.6435991669702343\" fill=\"#c7e6ed\" opacity=\"0.3764097353070974\"/><circle cx=\"183.98733666166663\" cy=\"39.5363795151934\" r=\"0.4108151278621517\" fill=\"#c7e6ed\" opacity=\"0.4878282494097948\"/><circle cx=\"115.08073283359408\" cy=\"9.15255301259458\" r=\"0.5317485477472655\" fill=\"#c7e6ed\" opacity=\"0.3188311307877302\"/><circle cx=\"230.64353680238128\" cy=\"47.37343516666442\" r=\"0.8543704964383505\" fill=\"#c7e6ed\" opacity=\"0.4030542055517435\"/><circle cx=\"97.4043214134872\" cy=\"152.64752923324704\" r=\"0.8774517950299195\" fill=\"#c7e6ed\" opacity=\"0.5434051503986119\"/><circle cx=\"205.63993832096457\" cy=\"50.93071990739554\" r=\"0.2723189973435365\" fill=\"#c7e6ed\" opacity=\"0.4473662269860506\"/><circle cx=\"211.1432914249599\" cy=\"152.00798963196576\" r=\"0.9991904494981281\" fill=\"#c7e6ed\" opacity=\"0.30839076630771156\"/><circle cx=\"47\" cy=\"113\" r=\"17\" fill=\"url(#sun)\" /><path d=\"M-15 138Q51 21 249 53M15 63Q132-4 244 17\" fill=\"none\" stroke=\"#dac1cb\" stroke-width=\".8\" stroke-dasharray=\"5 4\"/><path d=\"M-10 151Q137 50 250 72\" fill=\"none\" stroke=\"#e9b6b2\" stroke-width=\".6\"/><g transform=\"translate(170 106) scale(1.45)\"><g transform=\"rotate(35)\"><path d=\"M0 2L-66 55M3-14L56-66M5-12L62-64\" stroke=\"#dbb45a\" stroke-width=\"1.6\"/><path d=\"M47-60L66-71 68-60 50-49Z\" fill=\"#333d44\"/><ellipse cy=\"4\" rx=\"36\" ry=\"19\" fill=\"url(#foil)\" stroke=\"#dadfd2\" stroke-width=\"1.2\"/><path d=\"M0 0L34.8251457847309 1.797001499642907L29.8383582720827 9.408370120751865Z\" fill=\"#c3c9c4\" stroke=\"#8f9795\" stroke-width=\".6\"/><path d=\"M0 0L29.8383582720827 9.408370120751865L18.91058070538489 15.146477726542138Z\" fill=\"#e3dfc6\" stroke=\"#8f9795\" stroke-width=\".6\"/><path d=\"M0 0L18.91058070538489 15.146477726542138L4.217596927857824 17.868833838676593Z\" fill=\"#c3c9c4\" stroke=\"#8f9795\" stroke-width=\".6\"/><path d=\"M0 0L4.217596927857824 17.868833838676593L-11.315134840222623 17.03340157837346Z\" fill=\"#e3dfc6\" stroke=\"#8f9795\" stroke-width=\".6\"/><path d=\"M0 0L-11.315134840222623 17.03340157837346L-24.594957687074384 12.806520350235198Z\" fill=\"#c3c9c4\" stroke=\"#8f9795\" stroke-width=\".6\"/><path d=\"M0 0L-24.594957687074384 12.806520350235198L-32.97778192340304 6.029786702806284Z\" fill=\"#e3dfc6\" stroke=\"#8f9795\" stroke-width=\".6\"/><path d=\"M0 0L-32.97778192340304 6.029786702806284L-34.79453866281912 -1.9475124215419508Z\" fill=\"#c3c9c4\" stroke=\"#8f9795\" stroke-width=\".6\"/><ellipse cy=\"-9\" rx=\"16\" ry=\"9\" fill=\"#d7af47\" stroke=\"#333744\" stroke-width=\"3\"/><ellipse cy=\"-10\" rx=\"12\" ry=\"6\" fill=\"#44474a\" stroke=\"#f1d56d\" stroke-width=\"2\"/><path d=\"M-8-6L-9 6 9 6 9-6\" fill=\"#d5af37\" stroke=\"#353642\"/><path d=\"M9 8L30 29M-10 8L-22 31\" stroke=\"#c3b27d\" stroke-width=\"1.5\"/><circle cx=\"31\" cy=\"30\" r=\"4\" fill=\"#9b9c97\"/></g></g><path d=\"M4 163L89 163 56 119Z\" fill=\"#da5a31\" opacity=\".12\"/><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"url(#grain)\" /></g>",
	window: "<g clip-path=\"url(#artClip)\"><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"#184846\" /><path d=\"M0 0H240L216 30H22Z\" fill=\"#4b6260\"/><path d=\"M26 0L42 28M78 0L84 28M130 0L126 28M185 0L174 28M231 0L220 28M10 13H229\" stroke=\"#203b3d\" stroke-width=\"2\"/><path d=\"M19 34H199V117H19Z\" fill=\"#4a9981\" stroke=\"#153c40\" stroke-width=\"5\"/><path d=\"M126 35V116\" stroke=\"#163c3a\" stroke-width=\"5\"/><path d=\"M29 111H119L110 90 94 82 82 63 71 87 57 92Z\" fill=\"#edc86b\"/><path d=\"M75 91L79 51 85 91Z\" fill=\"#ecded0\"/><path d=\"M76 92L81 111 85 91Z\" fill=\"#fff1b3\"/><path d=\"M135 46H190V108H135Z\" fill=\"#27695e\" stroke=\"#84b7a0\"/><ellipse cx=\"162\" cy=\"79\" rx=\"18\" ry=\"12\" fill=\"none\" stroke=\"#87b7a2\"/><path d=\"M137 102L149 82 162 79 190 54\" fill=\"none\" stroke=\"#cad082\" stroke-width=\"1.4\"/><path d=\"M0 132L220 107 240 125V163H0Z\" fill=\"#243b40\"/><rect x=\"12\" y=\"135\" width=\"27\" height=\"21\" rx=\"1\" fill=\"#6f9da0\" stroke=\"#c4cdac\"/><path d=\"M18 150l4-9 5 5 5-2\" fill=\"none\" stroke=\"#d5d89d\"/><rect x=\"55\" y=\"132\" width=\"27\" height=\"21\" rx=\"1\" fill=\"#6f9da0\" stroke=\"#c4cdac\"/><path d=\"M61 147l4-9 5 5 5-2\" fill=\"none\" stroke=\"#d5d89d\"/><rect x=\"98\" y=\"129\" width=\"27\" height=\"21\" rx=\"1\" fill=\"#6f9da0\" stroke=\"#c4cdac\"/><path d=\"M104 144l4-9 5 5 5-2\" fill=\"none\" stroke=\"#d5d89d\"/><rect x=\"141\" y=\"126\" width=\"27\" height=\"21\" rx=\"1\" fill=\"#6f9da0\" stroke=\"#c4cdac\"/><path d=\"M147 141l4-9 5 5 5-2\" fill=\"none\" stroke=\"#d5d89d\"/><rect x=\"184\" y=\"123\" width=\"27\" height=\"21\" rx=\"1\" fill=\"#6f9da0\" stroke=\"#c4cdac\"/><path d=\"M190 138l4-9 5 5 5-2\" fill=\"none\" stroke=\"#d5d89d\"/><g transform=\"translate(25 114) scale(0.7)\"><path d=\"M-13 10L-18 37H20L12 8Z\" fill=\"#1c3338\"/><path d=\"M-4 7V16H8V5Z\" fill=\"#ad9771\"/><ellipse cy=\"-3\" rx=\"8\" ry=\"10\" fill=\"#b0a080\"/><path d=\"M-8-3Q-10-16 4-14L10-5 6 0 3-9Z\" fill=\"#1c3034\"/></g><g transform=\"translate(84 112) scale(0.8)\"><path d=\"M-13 10L-18 37H20L12 8Z\" fill=\"#1c3338\"/><path d=\"M-4 7V16H8V5Z\" fill=\"#ad9771\"/><ellipse cy=\"-3\" rx=\"8\" ry=\"10\" fill=\"#b0a080\"/><path d=\"M-8-3Q-10-16 4-14L10-5 6 0 3-9Z\" fill=\"#1c3034\"/></g><g transform=\"translate(153 112) scale(0.75)\"><path d=\"M-13 10L-18 37H20L12 8Z\" fill=\"#1c3338\"/><path d=\"M-4 7V16H8V5Z\" fill=\"#ad9771\"/><ellipse cy=\"-3\" rx=\"8\" ry=\"10\" fill=\"#b0a080\"/><path d=\"M-8-3Q-10-16 4-14L10-5 6 0 3-9Z\" fill=\"#1c3034\"/></g><g transform=\"translate(213 126) scale(1.2)\"><path d=\"M-13 10L-18 37H20L12 8Z\" fill=\"#1c3338\"/><path d=\"M-4 7V16H8V5Z\" fill=\"#ad9771\"/><ellipse cy=\"-3\" rx=\"8\" ry=\"10\" fill=\"#b0a080\"/><path d=\"M-8-3Q-10-16 4-14L10-5 6 0 3-9Z\" fill=\"#1c3034\"/></g><rect x=\"0\" y=\"0\" width=\"240\" height=\"163\" rx=\"0\" fill=\"url(#grain)\" /></g>"
}, Jt = {
	earth: "<g transform=\"translate(50 50)\"><defs><clipPath id=\"p268\"><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"#fff\" /></clipPath></defs><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"#236da6\" /><g clip-path=\"url(#p268)\"><path d=\"M-19.5 -39L7.800000000000001 -31.200000000000003 16.38 -15.600000000000001 3.9000000000000004 -3.9000000000000004 10.920000000000002 8.97 1.56 31.200000000000003 -7.800000000000001 21.450000000000003 -11.7 1.9500000000000002 -29.25 -4.68Z\" fill=\"#84a268\"/><path d=\"M-39 -11.7Q0 -27.299999999999997 39 -9.75M-39 19.5Q0 7.800000000000001 39 27.299999999999997\" fill=\"none\" stroke=\"#e6eee3\" stroke-width=\"4.68\" opacity=\".65\"/></g><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"url(#planetShade)\" /><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"none\" stroke=\"#b7d6d6\" stroke-width=\".5\" stroke-opacity=\".3\"/></g>",
	mercury: "<g transform=\"translate(50 50)\"><defs><clipPath id=\"p269\"><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"#fff\" /></clipPath></defs><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"#ad9c79\" /><g clip-path=\"url(#p269)\"><ellipse cx=\"6.16644143732834\" cy=\"0\" rx=\"2.34\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-7.35698767677936\" cy=\"6.875662318912749\" rx=\"3.3539999999999996\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"0.867225854642836\" cy=\"-12.807143292594137\" rx=\"4.367999999999999\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"9.544377841554411\" cy=\"11.707042821210026\" rx=\"5.382000000000001\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-16.918240922384914\" cy=\"-2.301765429434649\" rx=\"2.34\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"15.37211132566757\" cy=\"-10.890279766437718\" rx=\"3.3539999999999996\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-4.119909693371524\" cy=\"20.03250718503461\" rx=\"4.367999999999999\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-11.447952077231891\" cy=\"-18.7241660224802\" rx=\"5.382000000000001\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"22.49720663855666\" cy=\"6.237042044277264\" rx=\"2.34\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-21.865312129675385\" cy=\"11.41525844963094\" rx=\"3.3539999999999996\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"8.595986292922703\" cy=\"-24.45166701171691\" rx=\"4.367999999999999\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"10.895652475011367\" cy=\"24.828104179412865\" rx=\"5.382000000000001\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-25.96474277031862\" cy=\"-11.151552935407114\" rx=\"2.34\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"27.619007460692725\" cy=\"-9.95441745589362\" rx=\"3.3539999999999996\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-13.86484786995127\" cy=\"27.074729796308358\" rx=\"4.367999999999999\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-8.638482325993234\" cy=\"-30.232873219452742\" rx=\"5.382000000000001\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"27.804903370833497\" cy=\"16.700669104518298\" rx=\"2.34\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-32.65897702436823\" cy=\"6.98507120377367\" rx=\"3.3539999999999996\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"19.626169157354887\" cy=\"-28.170702586319923\" rx=\"4.367999999999999\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"5.026014787788562\" cy=\"34.88393864449556\" rx=\"5.382000000000001\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-28.183457892921496\" cy=\"-22.610123865160954\" rx=\"2.34\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"36.893296883500106\" cy=\"-2.7900976803547417\" rx=\"3.3539999999999996\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-25.622524248623442\" cy=\"27.852490932207548\" rx=\"4.367999999999999\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/></g><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"url(#planetShade)\" /><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"none\" stroke=\"#b7d6d6\" stroke-width=\".5\" stroke-opacity=\".3\"/></g>",
	venus: "<g transform=\"translate(50 50)\"><defs><clipPath id=\"p270\"><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"#fff\" /></clipPath></defs><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"#d99925\" /><g clip-path=\"url(#p270)\"><ellipse cx=\"6.16644143732834\" cy=\"0\" rx=\"2.34\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-7.35698767677936\" cy=\"6.875662318912749\" rx=\"3.3539999999999996\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"0.867225854642836\" cy=\"-12.807143292594137\" rx=\"4.367999999999999\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"9.544377841554411\" cy=\"11.707042821210026\" rx=\"5.382000000000001\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-16.918240922384914\" cy=\"-2.301765429434649\" rx=\"2.34\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"15.37211132566757\" cy=\"-10.890279766437718\" rx=\"3.3539999999999996\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-4.119909693371524\" cy=\"20.03250718503461\" rx=\"4.367999999999999\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-11.447952077231891\" cy=\"-18.7241660224802\" rx=\"5.382000000000001\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"22.49720663855666\" cy=\"6.237042044277264\" rx=\"2.34\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-21.865312129675385\" cy=\"11.41525844963094\" rx=\"3.3539999999999996\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"8.595986292922703\" cy=\"-24.45166701171691\" rx=\"4.367999999999999\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"10.895652475011367\" cy=\"24.828104179412865\" rx=\"5.382000000000001\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-25.96474277031862\" cy=\"-11.151552935407114\" rx=\"2.34\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"27.619007460692725\" cy=\"-9.95441745589362\" rx=\"3.3539999999999996\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-13.86484786995127\" cy=\"27.074729796308358\" rx=\"4.367999999999999\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-8.638482325993234\" cy=\"-30.232873219452742\" rx=\"5.382000000000001\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"27.804903370833497\" cy=\"16.700669104518298\" rx=\"2.34\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-32.65897702436823\" cy=\"6.98507120377367\" rx=\"3.3539999999999996\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"19.626169157354887\" cy=\"-28.170702586319923\" rx=\"4.367999999999999\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"5.026014787788562\" cy=\"34.88393864449556\" rx=\"5.382000000000001\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-28.183457892921496\" cy=\"-22.610123865160954\" rx=\"2.34\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"36.893296883500106\" cy=\"-2.7900976803547417\" rx=\"3.3539999999999996\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-25.622524248623442\" cy=\"27.852490932207548\" rx=\"4.367999999999999\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/></g><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"url(#planetShade)\" /><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"none\" stroke=\"#b7d6d6\" stroke-width=\".5\" stroke-opacity=\".3\"/></g>",
	mars: "<g transform=\"translate(50 50)\"><defs><clipPath id=\"p271\"><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"#fff\" /></clipPath></defs><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"#bf5b32\" /><g clip-path=\"url(#p271)\"><ellipse cx=\"6.16644143732834\" cy=\"0\" rx=\"2.34\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-7.35698767677936\" cy=\"6.875662318912749\" rx=\"3.3539999999999996\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"0.867225854642836\" cy=\"-12.807143292594137\" rx=\"4.367999999999999\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"9.544377841554411\" cy=\"11.707042821210026\" rx=\"5.382000000000001\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-16.918240922384914\" cy=\"-2.301765429434649\" rx=\"2.34\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"15.37211132566757\" cy=\"-10.890279766437718\" rx=\"3.3539999999999996\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-4.119909693371524\" cy=\"20.03250718503461\" rx=\"4.367999999999999\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-11.447952077231891\" cy=\"-18.7241660224802\" rx=\"5.382000000000001\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"22.49720663855666\" cy=\"6.237042044277264\" rx=\"2.34\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-21.865312129675385\" cy=\"11.41525844963094\" rx=\"3.3539999999999996\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"8.595986292922703\" cy=\"-24.45166701171691\" rx=\"4.367999999999999\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"10.895652475011367\" cy=\"24.828104179412865\" rx=\"5.382000000000001\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-25.96474277031862\" cy=\"-11.151552935407114\" rx=\"2.34\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"27.619007460692725\" cy=\"-9.95441745589362\" rx=\"3.3539999999999996\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-13.86484786995127\" cy=\"27.074729796308358\" rx=\"4.367999999999999\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-8.638482325993234\" cy=\"-30.232873219452742\" rx=\"5.382000000000001\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"27.804903370833497\" cy=\"16.700669104518298\" rx=\"2.34\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-32.65897702436823\" cy=\"6.98507120377367\" rx=\"3.3539999999999996\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"19.626169157354887\" cy=\"-28.170702586319923\" rx=\"4.367999999999999\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"5.026014787788562\" cy=\"34.88393864449556\" rx=\"5.382000000000001\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-28.183457892921496\" cy=\"-22.610123865160954\" rx=\"2.34\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"36.893296883500106\" cy=\"-2.7900976803547417\" rx=\"3.3539999999999996\" ry=\"2.34\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-25.622524248623442\" cy=\"27.852490932207548\" rx=\"4.367999999999999\" ry=\"2.34\" fill=\"#f0d09a\" opacity=\"0.3\"/></g><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"url(#planetShade)\" /><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"none\" stroke=\"#b7d6d6\" stroke-width=\".5\" stroke-opacity=\".3\"/></g>",
	jupiter: "<g transform=\"translate(50 50)\"><defs><clipPath id=\"p272\"><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"#fff\" /></clipPath></defs><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"#bf8e53\" /><g clip-path=\"url(#p272)\"><path d=\"M-46.8 -39Q0 -30.03 46.8 -40.17\" fill=\"none\" stroke=\"#f3dfb1\" stroke-width=\"2.34\" opacity=\"0.65\"/><path d=\"M-46.8 -31.59Q0 -22.619999999999997 46.8 -32.76\" fill=\"none\" stroke=\"#754c3b\" stroke-width=\"3.51\" opacity=\"0.65\"/><path d=\"M-46.8 -24.18Q0 -15.209999999999999 46.8 -25.35\" fill=\"none\" stroke=\"#e6c78e\" stroke-width=\"4.68\" opacity=\"0.65\"/><path d=\"M-46.8 -16.77Q0 -7.799999999999999 46.8 -17.939999999999998\" fill=\"none\" stroke=\"#c07e4c\" stroke-width=\"2.34\" opacity=\"0.65\"/><path d=\"M-46.8 -9.36Q0 -0.3899999999999988 46.8 -10.53\" fill=\"none\" stroke=\"#f3dfb1\" stroke-width=\"3.51\" opacity=\"0.65\"/><path d=\"M-46.8 -1.9500000000000028Q0 7.019999999999998 46.8 -3.1200000000000028\" fill=\"none\" stroke=\"#754c3b\" stroke-width=\"4.68\" opacity=\"0.65\"/><path d=\"M-46.8 5.460000000000001Q0 14.430000000000001 46.8 4.290000000000001\" fill=\"none\" stroke=\"#e6c78e\" stroke-width=\"2.34\" opacity=\"0.65\"/><path d=\"M-46.8 12.869999999999997Q0 21.839999999999996 46.8 11.699999999999998\" fill=\"none\" stroke=\"#c07e4c\" stroke-width=\"3.51\" opacity=\"0.65\"/><path d=\"M-46.8 20.28Q0 29.25 46.8 19.11\" fill=\"none\" stroke=\"#f3dfb1\" stroke-width=\"4.68\" opacity=\"0.65\"/><path d=\"M-46.8 27.689999999999998Q0 36.66 46.8 26.519999999999996\" fill=\"none\" stroke=\"#754c3b\" stroke-width=\"2.34\" opacity=\"0.65\"/><path d=\"M-46.8 35.099999999999994Q0 44.06999999999999 46.8 33.92999999999999\" fill=\"none\" stroke=\"#e6c78e\" stroke-width=\"3.51\" opacity=\"0.65\"/><ellipse cx=\"17.55\" cy=\"14.43\" rx=\"10.530000000000001\" ry=\"4.68\" transform=\"rotate(-10)\" fill=\"#ca5f37\" stroke=\"#e3b17e\" stroke-width=\"1.56\"/></g><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"url(#planetShade)\" /><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"none\" stroke=\"#b7d6d6\" stroke-width=\".5\" stroke-opacity=\".3\"/></g>",
	saturn: "<g transform=\"translate(50 50)\"><defs><clipPath id=\"p273\"><circle cx=\"0\" cy=\"0\" r=\"25\" fill=\"#fff\" /></clipPath></defs><ellipse rx=\"42.5\" ry=\"10.75\" transform=\"rotate(-28)\" fill=\"none\" stroke=\"#c1ac7c\" stroke-width=\"5.25\"/><ellipse rx=\"47.5\" ry=\"12.5\" transform=\"rotate(-28)\" fill=\"none\" stroke=\"#8c856f\" stroke-width=\"1.875\"/><circle cx=\"0\" cy=\"0\" r=\"25\" fill=\"#c9b473\" /><g clip-path=\"url(#p273)\"><path d=\"M-30 -25Q0 -19.25 30 -25.75\" fill=\"none\" stroke=\"#f3dfb1\" stroke-width=\"1.5\" opacity=\"0.65\"/><path d=\"M-30 -20.25Q0 -14.5 30 -21\" fill=\"none\" stroke=\"#754c3b\" stroke-width=\"2.25\" opacity=\"0.65\"/><path d=\"M-30 -15.5Q0 -9.75 30 -16.25\" fill=\"none\" stroke=\"#e6c78e\" stroke-width=\"3\" opacity=\"0.65\"/><path d=\"M-30 -10.75Q0 -5 30 -11.5\" fill=\"none\" stroke=\"#c07e4c\" stroke-width=\"1.5\" opacity=\"0.65\"/><path d=\"M-30 -6Q0 -0.25 30 -6.75\" fill=\"none\" stroke=\"#f3dfb1\" stroke-width=\"2.25\" opacity=\"0.65\"/><path d=\"M-30 -1.25Q0 4.5 30 -2\" fill=\"none\" stroke=\"#754c3b\" stroke-width=\"3\" opacity=\"0.65\"/><path d=\"M-30 3.5Q0 9.25 30 2.75\" fill=\"none\" stroke=\"#e6c78e\" stroke-width=\"1.5\" opacity=\"0.65\"/><path d=\"M-30 8.25Q0 14 30 7.5\" fill=\"none\" stroke=\"#c07e4c\" stroke-width=\"2.25\" opacity=\"0.65\"/><path d=\"M-30 13Q0 18.75 30 12.25\" fill=\"none\" stroke=\"#f3dfb1\" stroke-width=\"3\" opacity=\"0.65\"/><path d=\"M-30 17.75Q0 23.5 30 17\" fill=\"none\" stroke=\"#754c3b\" stroke-width=\"1.5\" opacity=\"0.65\"/><path d=\"M-30 22.5Q0 28.25 30 21.75\" fill=\"none\" stroke=\"#e6c78e\" stroke-width=\"2.25\" opacity=\"0.65\"/></g><circle cx=\"0\" cy=\"0\" r=\"25\" fill=\"url(#planetShade)\" /><circle cx=\"0\" cy=\"0\" r=\"25\" fill=\"none\" stroke=\"#b7d6d6\" stroke-width=\".5\" stroke-opacity=\".3\"/><path d=\"M-42.5 11.25Q5 10 41.75 -16.25\" fill=\"none\" stroke=\"#c6b58c\" stroke-width=\"3.5000000000000004\"/></g>",
	uranus: "<g transform=\"translate(50 50)\"><defs><clipPath id=\"p274\"><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"#fff\" /></clipPath></defs><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"#59b9c9\" /><g clip-path=\"url(#p274)\"><path d=\"M-46.8 -39Q0 -30.03 46.8 -40.17\" fill=\"none\" stroke=\"#f3dfb1\" stroke-width=\"2.34\" opacity=\"0.16\"/><path d=\"M-46.8 -31.59Q0 -22.619999999999997 46.8 -32.76\" fill=\"none\" stroke=\"#754c3b\" stroke-width=\"3.51\" opacity=\"0.16\"/><path d=\"M-46.8 -24.18Q0 -15.209999999999999 46.8 -25.35\" fill=\"none\" stroke=\"#e6c78e\" stroke-width=\"4.68\" opacity=\"0.16\"/><path d=\"M-46.8 -16.77Q0 -7.799999999999999 46.8 -17.939999999999998\" fill=\"none\" stroke=\"#c07e4c\" stroke-width=\"2.34\" opacity=\"0.16\"/><path d=\"M-46.8 -9.36Q0 -0.3899999999999988 46.8 -10.53\" fill=\"none\" stroke=\"#f3dfb1\" stroke-width=\"3.51\" opacity=\"0.16\"/><path d=\"M-46.8 -1.9500000000000028Q0 7.019999999999998 46.8 -3.1200000000000028\" fill=\"none\" stroke=\"#754c3b\" stroke-width=\"4.68\" opacity=\"0.16\"/><path d=\"M-46.8 5.460000000000001Q0 14.430000000000001 46.8 4.290000000000001\" fill=\"none\" stroke=\"#e6c78e\" stroke-width=\"2.34\" opacity=\"0.16\"/><path d=\"M-46.8 12.869999999999997Q0 21.839999999999996 46.8 11.699999999999998\" fill=\"none\" stroke=\"#c07e4c\" stroke-width=\"3.51\" opacity=\"0.16\"/><path d=\"M-46.8 20.28Q0 29.25 46.8 19.11\" fill=\"none\" stroke=\"#f3dfb1\" stroke-width=\"4.68\" opacity=\"0.16\"/><path d=\"M-46.8 27.689999999999998Q0 36.66 46.8 26.519999999999996\" fill=\"none\" stroke=\"#754c3b\" stroke-width=\"2.34\" opacity=\"0.16\"/><path d=\"M-46.8 35.099999999999994Q0 44.06999999999999 46.8 33.92999999999999\" fill=\"none\" stroke=\"#e6c78e\" stroke-width=\"3.51\" opacity=\"0.16\"/></g><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"url(#planetShade)\" /><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"none\" stroke=\"#b7d6d6\" stroke-width=\".5\" stroke-opacity=\".3\"/></g>",
	neptune: "<g transform=\"translate(50 50)\"><defs><clipPath id=\"p275\"><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"#fff\" /></clipPath></defs><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"#5267a7\" /><g clip-path=\"url(#p275)\"><path d=\"M-46.8 -39Q0 -30.03 46.8 -40.17\" fill=\"none\" stroke=\"#f3dfb1\" stroke-width=\"2.34\" opacity=\"0.16\"/><path d=\"M-46.8 -31.59Q0 -22.619999999999997 46.8 -32.76\" fill=\"none\" stroke=\"#754c3b\" stroke-width=\"3.51\" opacity=\"0.16\"/><path d=\"M-46.8 -24.18Q0 -15.209999999999999 46.8 -25.35\" fill=\"none\" stroke=\"#e6c78e\" stroke-width=\"4.68\" opacity=\"0.16\"/><path d=\"M-46.8 -16.77Q0 -7.799999999999999 46.8 -17.939999999999998\" fill=\"none\" stroke=\"#c07e4c\" stroke-width=\"2.34\" opacity=\"0.16\"/><path d=\"M-46.8 -9.36Q0 -0.3899999999999988 46.8 -10.53\" fill=\"none\" stroke=\"#f3dfb1\" stroke-width=\"3.51\" opacity=\"0.16\"/><path d=\"M-46.8 -1.9500000000000028Q0 7.019999999999998 46.8 -3.1200000000000028\" fill=\"none\" stroke=\"#754c3b\" stroke-width=\"4.68\" opacity=\"0.16\"/><path d=\"M-46.8 5.460000000000001Q0 14.430000000000001 46.8 4.290000000000001\" fill=\"none\" stroke=\"#e6c78e\" stroke-width=\"2.34\" opacity=\"0.16\"/><path d=\"M-46.8 12.869999999999997Q0 21.839999999999996 46.8 11.699999999999998\" fill=\"none\" stroke=\"#c07e4c\" stroke-width=\"3.51\" opacity=\"0.16\"/><path d=\"M-46.8 20.28Q0 29.25 46.8 19.11\" fill=\"none\" stroke=\"#f3dfb1\" stroke-width=\"4.68\" opacity=\"0.16\"/><path d=\"M-46.8 27.689999999999998Q0 36.66 46.8 26.519999999999996\" fill=\"none\" stroke=\"#754c3b\" stroke-width=\"2.34\" opacity=\"0.16\"/><path d=\"M-46.8 35.099999999999994Q0 44.06999999999999 46.8 33.92999999999999\" fill=\"none\" stroke=\"#e6c78e\" stroke-width=\"3.51\" opacity=\"0.16\"/></g><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"url(#planetShade)\" /><circle cx=\"0\" cy=\"0\" r=\"39\" fill=\"none\" stroke=\"#b7d6d6\" stroke-width=\".5\" stroke-opacity=\".3\"/></g>"
}, Yt = {
	p0: "<g transform=\"translate(0 0) scale(1)\"><path d=\"M3 0H67L88 22V113H0V8Z\" fill=\"#bb6126\" stroke=\"#c8b7a5\" stroke-width=\".8\"/><path d=\"M3 0H67L74 7H9V106H0V8Z\" fill=\"#713c28\"/><rect x=\"9\" y=\"11\" width=\"68\" height=\"91\" rx=\"0\" fill=\"url(#grain)\" /><use href=\"#i-probe\" x=\"32\" y=\"12\" width=\"38\" height=\"38\" /><use href=\"#i-probe\" x=\"12\" y=\"60\" width=\"25\" height=\"25\" /><use href=\"#i-probe\" x=\"43\" y=\"60\" width=\"25\" height=\"25\" /></g>",
	p1: "<g transform=\"translate(0 0) scale(1)\"><path d=\"M3 0H67L88 22V113H0V8Z\" fill=\"#bb6126\" stroke=\"#c8b7a5\" stroke-width=\".8\"/><path d=\"M3 0H67L74 7H9V106H0V8Z\" fill=\"#713c28\"/><rect x=\"9\" y=\"11\" width=\"68\" height=\"91\" rx=\"0\" fill=\"url(#grain)\" /><use href=\"#i-probe\" x=\"32\" y=\"12\" width=\"38\" height=\"38\" /><path d=\"M24 62L37 58 48 69 43 83 30 84 21 75Z\" fill=\"#c5aa77\" stroke=\"#fff1bd\"/><path d=\"M17 90L59 56\" stroke=\"#f9edbb\" stroke-width=\"3\"/></g>",
	p2: "<g transform=\"translate(0 0) scale(1)\"><path d=\"M3 0H67L88 22V113H0V8Z\" fill=\"#bb6126\" stroke=\"#c8b7a5\" stroke-width=\".8\"/><path d=\"M3 0H67L74 7H9V106H0V8Z\" fill=\"#713c28\"/><rect x=\"9\" y=\"11\" width=\"68\" height=\"91\" rx=\"0\" fill=\"url(#grain)\" /><use href=\"#i-probe\" x=\"32\" y=\"12\" width=\"38\" height=\"38\" /><use href=\"#i-energy\" x=\"14\" y=\"59\" width=\"26\" height=\"26\" /><text x=\"49\" y=\"81\" font-size=\"20\" fill=\"#fff0c7\" >−1</text></g>",
	p3: "<g transform=\"translate(0 0) scale(1)\"><path d=\"M3 0H67L88 22V113H0V8Z\" fill=\"#bb6126\" stroke=\"#c8b7a5\" stroke-width=\".8\"/><path d=\"M3 0H67L74 7H9V106H0V8Z\" fill=\"#713c28\"/><rect x=\"9\" y=\"11\" width=\"68\" height=\"91\" rx=\"0\" fill=\"url(#grain)\" /><use href=\"#i-probe\" x=\"32\" y=\"12\" width=\"38\" height=\"38\" /><g transform=\"translate(43 74)\"><defs><clipPath id=\"p276\"><circle cx=\"0\" cy=\"0\" r=\"17\" fill=\"#fff\" /></clipPath></defs><circle cx=\"0\" cy=\"0\" r=\"17\" fill=\"#ad9c79\" /><g clip-path=\"url(#p276)\"><ellipse cx=\"2.6879360111431225\" cy=\"0\" rx=\"1.02\" ry=\"1.02\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-3.206892064237157\" cy=\"2.9970835749106857\" rx=\"1.462\" ry=\"1.02\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"0.37802152638277464\" cy=\"-5.582600922412829\" rx=\"1.904\" ry=\"1.02\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"4.160369828369872\" cy=\"5.103069947706934\" rx=\"2.346\" ry=\"1.02\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-7.374617837962655\" cy=\"-1.0033336487279239\" rx=\"1.02\" ry=\"1.02\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"6.700663911188428\" cy=\"-4.747045026395929\" rx=\"1.462\" ry=\"1.02\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-1.7958580714696384\" cy=\"8.732118516553546\" rx=\"1.904\" ry=\"1.02\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-4.990132956742106\" cy=\"-8.16181595851701\" rx=\"2.346\" ry=\"1.02\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"9.80647468860162\" cy=\"2.718710634684961\" rx=\"1.02\" ry=\"1.02\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-9.531033492422603\" cy=\"4.975881888300666\" rx=\"1.462\" ry=\"1.02\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"3.746968384094512\" cy=\"-10.65841895382532\" rx=\"1.904\" ry=\"1.02\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"4.749386976287006\" cy=\"10.82250695000048\" rx=\"2.346\" ry=\"1.02\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-11.317964797318373\" cy=\"-4.860933330818485\" rx=\"1.02\" ry=\"1.02\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"12.039054534148113\" cy=\"-4.339105044876706\" rx=\"1.462\" ry=\"1.02\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-6.043651635619785\" cy=\"11.801805295826721\" rx=\"1.904\" ry=\"1.02\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-3.7654922959457684\" cy=\"-13.178431916171707\" rx=\"2.346\" ry=\"1.02\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"12.120086084722294\" cy=\"7.279778840431053\" rx=\"1.02\" ry=\"1.02\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-14.235964343955382\" cy=\"3.044774627285959\" rx=\"1.462\" ry=\"1.02\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"8.554996812180335\" cy=\"-12.27953702480612\" rx=\"1.904\" ry=\"1.02\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"2.19082695877963\" cy=\"15.20581940913909\" rx=\"2.346\" ry=\"1.02\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-12.285097030247831\" cy=\"-9.855695018147083\" rx=\"1.02\" ry=\"1.02\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"16.081693513320563\" cy=\"-1.2161964247700157\" rx=\"1.462\" ry=\"1.02\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-11.168792621194834\" cy=\"12.140829380705854\" rx=\"1.904\" ry=\"1.02\" fill=\"#f0d09a\" opacity=\"0.3\"/></g><circle cx=\"0\" cy=\"0\" r=\"17\" fill=\"url(#planetShade)\" /><circle cx=\"0\" cy=\"0\" r=\"17\" fill=\"none\" stroke=\"#b7d6d6\" stroke-width=\".5\" stroke-opacity=\".3\"/></g><use href=\"#i-lander\" x=\"51\" y=\"72\" width=\"25\" height=\"25\" /></g>",
	t0: "<g transform=\"translate(0 0) scale(1)\"><path d=\"M3 0H67L88 22V113H0V8Z\" fill=\"#a83c77\" stroke=\"#c8b7a5\" stroke-width=\".8\"/><path d=\"M3 0H67L74 7H9V106H0V8Z\" fill=\"#592748\"/><rect x=\"9\" y=\"11\" width=\"68\" height=\"91\" rx=\"0\" fill=\"url(#grain)\" /><use href=\"#i-telescope\" x=\"32\" y=\"12\" width=\"38\" height=\"38\" /><path d=\"M20 74H67M20 74L28 66M20 74L28 82M67 74L59 66M67 74L59 82\" fill=\"none\" stroke=\"#f2d8e4\" stroke-width=\"3\"/></g>",
	t1: "<g transform=\"translate(0 0) scale(1)\"><path d=\"M3 0H67L88 22V113H0V8Z\" fill=\"#a83c77\" stroke=\"#c8b7a5\" stroke-width=\".8\"/><path d=\"M3 0H67L74 7H9V106H0V8Z\" fill=\"#592748\"/><rect x=\"9\" y=\"11\" width=\"68\" height=\"91\" rx=\"0\" fill=\"url(#grain)\" /><use href=\"#i-telescope\" x=\"32\" y=\"12\" width=\"38\" height=\"38\" /><use href=\"#i-card\" x=\"14\" y=\"57\" width=\"24\" height=\"24\" /><use href=\"#i-signal\" x=\"48\" y=\"57\" width=\"26\" height=\"26\" /></g>",
	t2: "<g transform=\"translate(0 0) scale(1)\"><path d=\"M3 0H67L88 22V113H0V8Z\" fill=\"#a83c77\" stroke=\"#c8b7a5\" stroke-width=\".8\"/><path d=\"M3 0H67L74 7H9V106H0V8Z\" fill=\"#592748\"/><rect x=\"9\" y=\"11\" width=\"68\" height=\"91\" rx=\"0\" fill=\"url(#grain)\" /><use href=\"#i-telescope\" x=\"32\" y=\"12\" width=\"38\" height=\"38\" /><use href=\"#i-publicity\" x=\"14\" y=\"58\" width=\"22\" height=\"22\" /><text x=\"9.6\" y=\"75.38\" font-size=\"18.48\" fill=\"#fff\" font-family=\"Arial\" font-weight=\"900\" stroke=\"#172434\" stroke-width=\"1.4\" paint-order=\"stroke\">1</text><g transform=\"translate(61 72)\"><defs><clipPath id=\"p277\"><circle cx=\"0\" cy=\"0\" r=\"13\" fill=\"#fff\" /></clipPath></defs><circle cx=\"0\" cy=\"0\" r=\"13\" fill=\"#ad9c79\" /><g clip-path=\"url(#p277)\"><ellipse cx=\"2.0554804791094465\" cy=\"0\" rx=\"0.78\" ry=\"0.78\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-2.4523292255931195\" cy=\"2.291887439637583\" rx=\"1.1179999999999999\" ry=\"0.78\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"0.28907528488094536\" cy=\"-4.269047764198047\" rx=\"1.456\" ry=\"0.78\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"3.1814592805181365\" cy=\"3.9023476070700083\" rx=\"1.794\" ry=\"0.78\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-5.63941364079497\" cy=\"-0.7672551431448829\" rx=\"0.78\" ry=\"0.78\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"5.124037108555856\" cy=\"-3.6300932554792396\" rx=\"1.1179999999999999\" ry=\"0.78\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-1.3733032311238411\" cy=\"6.677502395011536\" rx=\"1.456\" ry=\"0.78\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-3.8159840257439637\" cy=\"-6.241388674160067\" rx=\"1.794\" ry=\"0.78\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"7.4990688795188865\" cy=\"2.079014014759088\" rx=\"0.78\" ry=\"0.78\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-7.288437376558462\" cy=\"3.80508614987698\" rx=\"1.1179999999999999\" ry=\"0.78\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"2.8653287643075678\" cy=\"-8.150555670572304\" rx=\"1.456\" ry=\"0.78\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"3.6318841583371224\" cy=\"8.276034726470956\" rx=\"1.794\" ry=\"0.78\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-8.654914256772875\" cy=\"-3.7171843118023715\" rx=\"0.78\" ry=\"0.78\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"9.206335820230908\" cy=\"-3.31813915196454\" rx=\"1.1179999999999999\" ry=\"0.78\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-4.621615956650424\" cy=\"9.024909932102787\" rx=\"1.456\" ry=\"0.78\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-2.8794941086644115\" cy=\"-10.077624406484247\" rx=\"1.794\" ry=\"0.78\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"9.268301123611165\" cy=\"5.566889701506099\" rx=\"0.78\" ry=\"0.78\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"-10.88632567478941\" cy=\"2.3283570679245567\" rx=\"1.1179999999999999\" ry=\"0.78\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"6.542056385784963\" cy=\"-9.390234195439973\" rx=\"1.456\" ry=\"0.78\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"1.6753382625961875\" cy=\"11.627979548165186\" rx=\"1.794\" ry=\"0.78\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-9.394485964307165\" cy=\"-7.536707955053651\" rx=\"0.78\" ry=\"0.78\" fill=\"#f0d09a\" opacity=\"0.3\"/><ellipse cx=\"12.29776562783337\" cy=\"-0.9300325601182473\" rx=\"1.1179999999999999\" ry=\"0.78\" fill=\"#543c36\" opacity=\"0.34\"/><ellipse cx=\"-8.540841416207815\" cy=\"9.284163644069183\" rx=\"1.456\" ry=\"0.78\" fill=\"#f0d09a\" opacity=\"0.3\"/></g><circle cx=\"0\" cy=\"0\" r=\"13\" fill=\"url(#planetShade)\" /><circle cx=\"0\" cy=\"0\" r=\"13\" fill=\"none\" stroke=\"#b7d6d6\" stroke-width=\".5\" stroke-opacity=\".3\"/></g></g>",
	t3: "<g transform=\"translate(0 0) scale(1)\"><path d=\"M3 0H67L88 22V113H0V8Z\" fill=\"#a83c77\" stroke=\"#c8b7a5\" stroke-width=\".8\"/><path d=\"M3 0H67L74 7H9V106H0V8Z\" fill=\"#592748\"/><rect x=\"9\" y=\"11\" width=\"68\" height=\"91\" rx=\"0\" fill=\"url(#grain)\" /><use href=\"#i-telescope\" x=\"32\" y=\"12\" width=\"38\" height=\"38\" /><use href=\"#i-energy\" x=\"13\" y=\"58\" width=\"22\" height=\"22\" /><text x=\"8.6\" y=\"75.38\" font-size=\"18.48\" fill=\"#fff\" font-family=\"Arial\" font-weight=\"900\" stroke=\"#172434\" stroke-width=\"1.4\" paint-order=\"stroke\">1</text><text x=\"41\" y=\"77\" font-size=\"22\" fill=\"#e6f0ef\" >/</text><use href=\"#i-move\" x=\"59\" y=\"59\" width=\"22\" height=\"22\" /><text x=\"54.6\" y=\"76.38\" font-size=\"18.48\" fill=\"#fff\" font-family=\"Arial\" font-weight=\"900\" stroke=\"#172434\" stroke-width=\"1.4\" paint-order=\"stroke\">1</text></g>",
	c0: "<g transform=\"translate(0 0) scale(1)\"><path d=\"M3 0H67L88 22V113H0V8Z\" fill=\"#317aab\" stroke=\"#c8b7a5\" stroke-width=\".8\"/><path d=\"M3 0H67L74 7H9V106H0V8Z\" fill=\"#193f62\"/><rect x=\"9\" y=\"11\" width=\"68\" height=\"91\" rx=\"0\" fill=\"url(#grain)\" /><use href=\"#i-computer\" x=\"32\" y=\"12\" width=\"38\" height=\"38\" /><use href=\"#i-vp\" x=\"18\" y=\"55\" width=\"28\" height=\"28\" /><text x=\"32\" y=\"74.6\" font-size=\"16.52\" fill=\"#fff\" text-anchor=\"middle\" font-family=\"Arial\" font-weight=\"900\">2</text><use href=\"#i-publicity\" x=\"48\" y=\"77\" width=\"25\" height=\"25\" /></g>",
	c1: "<g transform=\"translate(0 0) scale(1)\"><path d=\"M3 0H67L88 22V113H0V8Z\" fill=\"#317aab\" stroke=\"#c8b7a5\" stroke-width=\".8\"/><path d=\"M3 0H67L74 7H9V106H0V8Z\" fill=\"#193f62\"/><rect x=\"9\" y=\"11\" width=\"68\" height=\"91\" rx=\"0\" fill=\"url(#grain)\" /><use href=\"#i-computer\" x=\"32\" y=\"12\" width=\"38\" height=\"38\" /><use href=\"#i-vp\" x=\"18\" y=\"55\" width=\"28\" height=\"28\" /><text x=\"32\" y=\"74.6\" font-size=\"16.52\" fill=\"#fff\" text-anchor=\"middle\" font-family=\"Arial\" font-weight=\"900\">2</text><use href=\"#i-card\" x=\"48\" y=\"77\" width=\"25\" height=\"25\" /></g>",
	c2: "<g transform=\"translate(0 0) scale(1)\"><path d=\"M3 0H67L88 22V113H0V8Z\" fill=\"#317aab\" stroke=\"#c8b7a5\" stroke-width=\".8\"/><path d=\"M3 0H67L74 7H9V106H0V8Z\" fill=\"#193f62\"/><rect x=\"9\" y=\"11\" width=\"68\" height=\"91\" rx=\"0\" fill=\"url(#grain)\" /><use href=\"#i-computer\" x=\"32\" y=\"12\" width=\"38\" height=\"38\" /><use href=\"#i-vp\" x=\"18\" y=\"55\" width=\"28\" height=\"28\" /><text x=\"32\" y=\"74.6\" font-size=\"16.52\" fill=\"#fff\" text-anchor=\"middle\" font-family=\"Arial\" font-weight=\"900\">2</text><use href=\"#i-energy\" x=\"48\" y=\"77\" width=\"25\" height=\"25\" /></g>",
	c3: "<g transform=\"translate(0 0) scale(1)\"><path d=\"M3 0H67L88 22V113H0V8Z\" fill=\"#317aab\" stroke=\"#c8b7a5\" stroke-width=\".8\"/><path d=\"M3 0H67L74 7H9V106H0V8Z\" fill=\"#193f62\"/><rect x=\"9\" y=\"11\" width=\"68\" height=\"91\" rx=\"0\" fill=\"url(#grain)\" /><use href=\"#i-computer\" x=\"32\" y=\"12\" width=\"38\" height=\"38\" /><use href=\"#i-vp\" x=\"18\" y=\"55\" width=\"28\" height=\"28\" /><text x=\"32\" y=\"74.6\" font-size=\"16.52\" fill=\"#fff\" text-anchor=\"middle\" font-family=\"Arial\" font-weight=\"900\">2</text><use href=\"#i-credit\" x=\"48\" y=\"77\" width=\"25\" height=\"25\" /></g>"
}, Xt = {
	fossil: "<path d=\"M6 33L13 9 31 5 45 18 38 43 18 47Z\" fill=\"#a48bb5\" stroke=\"#e7d6ec\" stroke-width=\"2\"/><path d=\"M14 29Q16 13 29 14T35 33Q26 43 21 32T30 24\" fill=\"none\" stroke=\"#f3e5e8\" stroke-width=\"4\"/>",
	danger: "<path d=\"M19 4H33L48 19V33L33 48H19L4 33V19Z\" fill=\"#3a343c\" stroke=\"#e9d4b1\" stroke-width=\"2\"/><path d=\"M26 12V30\" stroke=\"#e6a07a\" stroke-width=\"5\"/><circle cx=\"26\" cy=\"38\" r=\"3\" fill=\"#e6a07a\"/>",
	"alien-card": "<rect x=\"9\" y=\"3\" width=\"34\" height=\"46\" rx=\"4\" fill=\"#397f80\" stroke=\"#cee5d3\" stroke-width=\"2\"/><path d=\"M14 20Q26 6 38 20Q38 35 26 41Q14 35 14 20Z\" fill=\"#d8e7d2\"/><path d=\"M18 23L23 29M34 23L29 29\" stroke=\"#255c66\" stroke-width=\"4\"/>",
	capsule: "<path d=\"M14 10Q26-3 38 10V40Q26 53 14 40Z\" fill=\"currentColor\" stroke=\"#e9dfbc\" stroke-width=\"2\"/><ellipse cx=\"26\" cy=\"23\" rx=\"7\" ry=\"11\" fill=\"#acc9c5\"/><path d=\"M15 35H37\" stroke=\"#354d59\" stroke-width=\"3\"/>"
}, Zt = Object.entries(Kt).map(([e, t]) => `<symbol id="i-${e}" viewBox="${e === "probe-piece" ? "0 0 40 50" : "0 0 52 52"}">${t}</symbol>`).join("");
function Qt({ markup: e, viewBox: t, className: i, symbols: a = !1, children: o }) {
	let s = n().replace(/[^a-zA-Z0-9_-]/g, ""), c = r(() => `<defs>${Gt}${a ? Zt : ""}</defs>${e}`.replace(/id="([^"]+)"/g, `id="${s}-$1"`).replace(/url\(#([^)]+)\)/g, `url(#${s}-$1)`).replace(/href="#([^"]+)"/g, `href="#${s}-$1"`), [
		s,
		e,
		a
	]);
	return /* @__PURE__ */ m("svg", {
		viewBox: t,
		className: i,
		"aria-hidden": "true",
		children: [/* @__PURE__ */ p("g", { dangerouslySetInnerHTML: { __html: c } }), o]
	});
}
function $t({ d: e }) {
	return /* @__PURE__ */ m("g", {
		className: "seti-action-contour",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ p("path", {
			d: e,
			className: "seti-action-backing"
		}), /* @__PURE__ */ p("path", {
			d: e,
			className: "seti-action-ants"
		})]
	});
}
function en({ round: e = !1 }) {
	let t = (t) => e ? /* @__PURE__ */ p("ellipse", {
		cx: "50%",
		cy: "50%",
		className: t
	}) : /* @__PURE__ */ p("rect", {
		x: "1",
		y: "1",
		rx: "5",
		className: t
	});
	return /* @__PURE__ */ m("svg", {
		className: "seti-action-outline seti-action-contour",
		"aria-hidden": "true",
		focusable: "false",
		children: [t("seti-action-backing"), t("seti-action-ants")]
	});
}
function $({ icon: e, n: t, className: n = "" }) {
	let r = t !== void 0 && e !== "vp";
	return /* @__PURE__ */ m("svg", {
		viewBox: e === "probe-piece" ? "0 0 40 50" : r ? "-20 0 72 52" : "0 0 52 52",
		className: `seti-icon${r ? " seti-icon-counted" : ""} ${n}`,
		"aria-hidden": "true",
		children: [/* @__PURE__ */ p("g", { dangerouslySetInnerHTML: { __html: e in Xt ? Xt[e] : Kt[e] } }), t !== void 0 && /* @__PURE__ */ p("text", {
			x: r ? -18 : 26,
			y: r ? 42 : 36,
			textAnchor: r ? "start" : "middle",
			className: "seti-icon-number",
			fontSize: r ? 43 : 30,
			children: t
		})]
	});
}
function tn({ resource: e, n: t }) {
	let n = s();
	return /* @__PURE__ */ m("span", {
		className: "seti-resource",
		title: n(pe[e]),
		children: [
			/* @__PURE__ */ p($, { icon: e }),
			/* @__PURE__ */ p("b", { children: t }),
			/* @__PURE__ */ p("span", {
				className: "sr-only",
				children: n(pe[e])
			})
		]
	});
}
function nn({ owner: e, name: t, color: n, avatar: r }) {
	return /* @__PURE__ */ p("span", {
		className: "seti-owner",
		style: { "--seti-owner": n(e) },
		title: t(e),
		children: e === "$neutral" ? "○" : /* @__PURE__ */ p("img", {
			src: r(e),
			alt: "",
			draggable: !1,
			style: {
				width: "1.75em",
				height: "1.75em",
				maxWidth: "100%",
				maxHeight: "100%",
				display: "block",
				objectFit: "contain",
				pointerEvents: "none",
				borderRadius: "inherit"
			}
		})
	});
}
function rn({ planet: e, className: t = "" }) {
	let n = e === "oumuamua" ? "<path d=\"M9 65Q27 35 83 26L91 35Q66 57 17 73Z\" fill=\"#78566d\" stroke=\"#d5b8bd\" stroke-width=\"2\"/><path d=\"M20 64L78 33 48 53Z\" fill=\"#aa7e85\"/><path d=\"M27 58L41 58M57 45L68 43M67 39L79 34\" stroke=\"#372e43\" stroke-width=\"3\"/>" : Jt[e];
	return /* @__PURE__ */ p(Qt, {
		markup: n,
		viewBox: "0 0 100 100",
		className: `seti-planet-art ${t}`
	});
}
function an({ steps: e }) {
	return /* @__PURE__ */ p("span", {
		className: "seti-rewards",
		children: e.map((e, t) => e.kind === "gain" ? /* @__PURE__ */ p($, {
			icon: e.resource,
			n: e.n
		}, t) : e.kind === "draw" ? /* @__PURE__ */ p($, {
			icon: "card",
			n: e.n
		}, t) : e.kind === "income" ? /* @__PURE__ */ p($, { icon: "income" }, t) : e.kind === "rowSignals" || e.kind === "signal" ? /* @__PURE__ */ p($, { icon: "signal" }, t) : e.kind === "research" ? /* @__PURE__ */ p($, { icon: "tech" }, t) : e.kind === "trace" ? /* @__PURE__ */ p($, { icon: e.color === "any" ? "trace-yellow" : `trace-${e.color}` }, t) : e.kind === "move" ? /* @__PURE__ */ p($, {
			icon: "move",
			n: e.n
		}, t) : e.kind === "launch" ? /* @__PURE__ */ p($, { icon: "probe" }, t) : e.kind === "land" ? /* @__PURE__ */ p($, { icon: "lander" }, t) : e.kind === "targetSignal" ? /* @__PURE__ */ p($, {
			icon: "signal",
			n: e.n
		}, t) : e.kind === "alien" && (e.op === "draw" || e.op === "fossil") ? /* @__PURE__ */ p($, {
			icon: e.op === "draw" ? "alien-card" : "fossil",
			n: e.n ?? 1
		}, t) : null)
	});
}
function on({ planet: e, choices: t, onOpen: n, ...r }) {
	let i = s(), { pub: a } = r, o = a.figures.filter((t) => t.planet === e.id), c = t.some((t) => t.card && /^(orbit|mainLand|land):/.test(t.id) && a.probes.some((n) => n.uid === t.card && e.id === V(a.angles, n, a.species.some((e) => e.id === "oumuamua")).planet));
	return /* @__PURE__ */ m("button", {
		className: `seti-exploration-planet${c ? " seti-legal" : ""}`,
		onClick: n,
		"aria-label": i(fe[e.id]),
		children: [
			c && /* @__PURE__ */ p(en, {}),
			/* @__PURE__ */ m("span", {
				className: "seti-exploration-orbit",
				children: [e.id === "oumuamua" ? /* @__PURE__ */ p($, { icon: "alien-card" }) : /* @__PURE__ */ p($, {
					icon: "vp",
					n: 3
				}), /* @__PURE__ */ p(an, { steps: e.orbit })]
			}),
			/* @__PURE__ */ m("span", {
				className: "seti-exploration-world",
				children: [
					/* @__PURE__ */ p(rn, { planet: e.id }),
					/* @__PURE__ */ m("span", {
						className: "seti-landing-reward",
						children: [/* @__PURE__ */ p($, {
							icon: "vp",
							n: e.vp
						}), /* @__PURE__ */ p($, {
							icon: e.id === "oumuamua" ? "fossil" : "trace-yellow",
							n: e.id === "oumuamua" ? 2 : void 0
						})]
					}),
					/* @__PURE__ */ p("span", {
						className: "seti-first-slots",
						children: e.first.map((e, t) => {
							let n = o.find((e) => e.kind === "lander" && !e.moon && e.slot === t);
							return /* @__PURE__ */ p("span", { children: n ? /* @__PURE__ */ p(nn, {
								...r,
								owner: n.owner
							}) : /* @__PURE__ */ p($, {
								icon: "data",
								n: e
							}) }, t);
						})
					})
				]
			}),
			/* @__PURE__ */ p("strong", { children: i(fe[e.id]) }),
			/* @__PURE__ */ p("span", {
				className: "seti-orbiters",
				children: o.filter((e) => e.kind === "orbiter").map((e) => /* @__PURE__ */ p(nn, {
					...r,
					owner: e.owner
				}, e.uid))
			}),
			/* @__PURE__ */ p("span", {
				className: "seti-moons",
				children: e.moons.map((e) => /* @__PURE__ */ m("span", {
					className: "seti-moon",
					children: [/* @__PURE__ */ m("span", {
						className: "seti-moon-world",
						children: [/* @__PURE__ */ p(rn, { planet: "mercury" }), o.filter((t) => t.moon === e.id).map((e) => /* @__PURE__ */ p(nn, {
							...r,
							owner: e.owner
						}, e.uid))]
					}), /* @__PURE__ */ p("span", { children: i(e.name) })]
				}, e.id))
			})
		]
	});
}
function sn({ id: e, legal: t = !1 }) {
	return /* @__PURE__ */ p(Qt, {
		markup: Yt[e],
		symbols: !0,
		viewBox: "0 0 88 113",
		className: "seti-tech-art",
		children: t && /* @__PURE__ */ p($t, { d: "M3 0H67L88 22V113H0V8Z" })
	});
}
//#endregion
//#region src/games/seti/board.tsx
var cn = {
	blue: "#4baed2",
	yellow: "#ccad48",
	red: "#c46d92",
	black: "#abbcc5"
};
function ln(e, t) {
	let n = t * Math.PI / 4;
	return `${300 + Math.sin(n) * e},${300 - Math.cos(n) * e}`;
}
function un(e, t, n) {
	return `M${ln(e, n)}L${ln(t, n)}A${t} ${t} 0 0 1 ${ln(t, n + 1)}L${ln(e, n + 1)}A${e} ${e} 0 0 0 ${ln(e, n)}Z`;
}
var dn = Array.from({ length: 32 }, (e, t) => ({
	ring: Math.floor(t / 8) + 1,
	sector: t % 8
})), fn = Array.from({ length: 145 }, (e, t) => ({
	x: t * 137.51 % 600,
	y: t * 89.79 % 600,
	r: t % 7 == 0 ? 1 : .5
}));
function pn({ pub: e, choices: t, color: r, name: i, avatar: a, choose: o, inspectSector: c }) {
	let l = s(), u = n().replace(/[^a-zA-Z0-9_-]/g, ""), d = (e, t, n, r = 10) => /* @__PURE__ */ m("g", {
		pointerEvents: "none",
		children: [/* @__PURE__ */ p("title", { children: i(e) }), e === "$neutral" ? /* @__PURE__ */ p("text", {
			x: t,
			y: n + 3,
			textAnchor: "middle",
			className: "seti-signal-owner",
			children: "○"
		}) : /* @__PURE__ */ p("image", {
			href: a(e),
			x: t - r / 2,
			y: n - r / 2,
			width: r,
			height: r,
			preserveAspectRatio: "xMidYMid meet"
		})]
	});
	return /* @__PURE__ */ m("svg", {
		viewBox: "0 0 600 600",
		className: "seti-solar",
		"aria-label": l("games.seti.solarSystem"),
		children: [
			/* @__PURE__ */ m("defs", { children: [
				/* @__PURE__ */ m("radialGradient", {
					id: `${u}space`,
					children: [
						/* @__PURE__ */ p("stop", { stopColor: "#194b66" }),
						/* @__PURE__ */ p("stop", {
							offset: ".55",
							stopColor: "#102838"
						}),
						/* @__PURE__ */ p("stop", {
							offset: "1",
							stopColor: "#071320"
						})
					]
				}),
				/* @__PURE__ */ m("radialGradient", {
					id: `${u}sun`,
					children: [
						/* @__PURE__ */ p("stop", { stopColor: "#fff4ba" }),
						/* @__PURE__ */ p("stop", {
							offset: ".38",
							stopColor: "#ffd64d"
						}),
						/* @__PURE__ */ p("stop", {
							offset: ".75",
							stopColor: "#f5a522"
						}),
						/* @__PURE__ */ p("stop", {
							offset: "1",
							stopColor: "#d76519"
						})
					]
				}),
				[
					"#e6bc27",
					"#ad8539",
					"#786247"
				].map((e, t) => /* @__PURE__ */ m("radialGradient", {
					id: `${u}disc${t}`,
					gradientUnits: "userSpaceOnUse",
					cx: "300",
					cy: "300",
					r: [
						115,
						158,
						220
					][t],
					children: [/* @__PURE__ */ p("stop", { stopColor: [
						"#fff089",
						"#ebca71",
						"#ad803c"
					][t] }), /* @__PURE__ */ p("stop", {
						offset: "1",
						stopColor: e
					})]
				}, t))
			] }),
			/* @__PURE__ */ p("circle", {
				cx: "300",
				cy: "300",
				r: "297",
				fill: `url(#${u}space)`,
				stroke: "#477c91",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ p("g", {
				fill: "#c7e6ed",
				opacity: ".3",
				children: fn.map((e, t) => /* @__PURE__ */ p("circle", {
					cx: e.x,
					cy: e.y,
					r: e.r
				}, t))
			}),
			e.sectors.map((e, n) => {
				let a = t.filter((e) => e.n === n && /^(signal|row|handSignal|targetSignal|settle):/.test(e.id)), s = (n + .5) * Math.PI / 4, u = 300 + Math.sin(s) * 278, h = 300 - Math.cos(s) * 278, g = Math.abs(u - 300) > 220 ? l(be[e.id]).split(" ") : [l(be[e.id])];
				return /* @__PURE__ */ m("g", { children: [
					/* @__PURE__ */ p("path", {
						d: un(243, 296, n),
						fill: a.length ? "#285260" : "#10283b",
						stroke: cn[e.color],
						strokeWidth: a.length ? 2.4 : .8
					}),
					/* @__PURE__ */ p("text", {
						x: u,
						y: h + 3 - (g.length - 1) * 7,
						textAnchor: "middle",
						className: "seti-star-label",
						children: g.map((e, t) => /* @__PURE__ */ p("tspan", {
							x: u,
							dy: t ? 14 : 0,
							children: e
						}, t))
					}),
					Array.from({ length: Math.max(e.capacity, e.signals.length) }, (t, i) => {
						let a = (n + .16 + i * .68 / Math.max(1, e.capacity - 1, e.signals.length - 1)) * Math.PI / 4, o = 300 + Math.sin(a) * 255, s = 300 - Math.cos(a) * 255, c = e.signals[i];
						return /* @__PURE__ */ m("g", { children: [/* @__PURE__ */ p("circle", {
							cx: o,
							cy: s,
							r: c ? 6 : 4.6,
							fill: c ? r(c) : "#142d41",
							stroke: c ? "#e8efde" : cn[e.color],
							strokeWidth: ".8"
						}), c && /* @__PURE__ */ p(f, { children: d(c, o, s) })] }, i);
					}),
					e.winners.length > 0 && /* @__PURE__ */ m("g", { children: [
						/* @__PURE__ */ p("title", { children: e.winners.map(i).join(", ") }),
						/* @__PURE__ */ p("circle", {
							cx: u,
							cy: h + 15,
							r: "6",
							fill: r(e.winners.at(-1)),
							stroke: "#fff",
							strokeWidth: ".6"
						}),
						d(e.winners.at(-1), u, h + 15)
					] }),
					/* @__PURE__ */ p("path", {
						d: un(243, 296, n),
						className: "seti-board-hit",
						role: "button",
						tabIndex: 0,
						"aria-label": l(a.length ? "games.seti.markSector" : "games.seti.inspectSector", { n: n + 1 }),
						onClick: () => a.length ? o(a) : c(n),
						onKeyDown: (e) => {
							(e.key === "Enter" || e.key === " ") && (e.preventDefault(), a.length ? o(a) : c(n));
						}
					})
				] }, e.id);
			}),
			dn.map((t) => {
				let n = Se(e.angles, t), r = Se(e.angles, {
					...t,
					sector: (t.sector + 7) % 8
				});
				return /* @__PURE__ */ m("g", { children: [
					/* @__PURE__ */ p("path", {
						d: un(24 + t.ring * 43, 67 + t.ring * 43, t.sector),
						fill: n < 3 ? `url(#${u}disc${n})` : "#103b50"
					}),
					/* @__PURE__ */ p("path", {
						d: `M${ln(67 + t.ring * 43, t.sector)}A${67 + t.ring * 43} ${67 + t.ring * 43} 0 0 1 ${ln(67 + t.ring * 43, t.sector + 1)}`,
						fill: "none",
						stroke: n < 3 ? "#ebd697" : "#6299ab",
						strokeOpacity: ".5",
						strokeWidth: ".7"
					}),
					/* @__PURE__ */ p("path", {
						d: `M${ln((r === n ? 31 : 24) + t.ring * 43, t.sector)}L${ln((r === n ? 60 : 67) + t.ring * 43, t.sector)}`,
						fill: "none",
						stroke: "#fae3a0",
						strokeWidth: r === n ? .65 : 1.3,
						opacity: r === n ? .3 : .6
					})
				] }, `disc-${t.ring}-${t.sector}`);
			}),
			dn.map((n) => {
				let r = Ee(n), i = V(e.angles, n, e.species.some((e) => e.id === "oumuamua")), a = t.filter((e) => e.target?.ring === n.ring && e.target.sector === n.sector);
				return /* @__PURE__ */ m("g", { children: [
					i.asteroid && /* @__PURE__ */ m("g", {
						transform: `translate(${r.x} ${r.y}) rotate(${n.sector * 25})`,
						children: [
							/* @__PURE__ */ p("path", {
								d: "M-14-4L-9-13 0-11 7-2 2 8-9 7Z",
								fill: "#8b8a78",
								stroke: "#bbb69a",
								strokeWidth: ".6"
							}),
							/* @__PURE__ */ p("path", {
								d: "M7-12L15-15 21-6 16 0 8-3Z",
								fill: "#aaa28d"
							}),
							/* @__PURE__ */ p("path", {
								d: "M9 8L17 4 22 10 16 16 10 14Z",
								fill: "#7e847b"
							}),
							/* @__PURE__ */ p("path", {
								d: "M-11-5L-3-8 1-2-5 2Z",
								fill: "#5d655f"
							})
						]
					}),
					i.comet && /* @__PURE__ */ m("g", {
						transform: `translate(${r.x} ${r.y}) rotate(${n.sector * 45 - 30})`,
						children: [
							/* @__PURE__ */ p("path", {
								d: "M-3 5Q12-9 34-20L9 6Z",
								fill: "#c6eef1",
								opacity: ".4"
							}),
							/* @__PURE__ */ p("path", {
								d: "M0 3L32-14 9 5Z",
								fill: "#b1e7e9",
								opacity: ".65"
							}),
							/* @__PURE__ */ p("circle", {
								cy: "4",
								r: "3",
								fill: "#fff6cd"
							})
						]
					}),
					i.planet && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("svg", {
						x: r.x - 24,
						y: r.y - 27,
						width: "48",
						height: "48",
						className: "seti-board-planet",
						children: /* @__PURE__ */ p(rn, { planet: i.planet })
					}), /* @__PURE__ */ p("text", {
						x: r.x,
						y: r.y + 24,
						textAnchor: "middle",
						className: "seti-planet-label",
						children: l(fe[i.planet])
					})] }),
					a.length > 0 && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("circle", {
						cx: r.x,
						cy: r.y,
						r: "23",
						fill: "#b4e8e320"
					}), /* @__PURE__ */ p("path", {
						d: un(24 + n.ring * 43, 67 + n.ring * 43, n.sector),
						className: "seti-board-hit seti-cell-legal",
						role: "button",
						tabIndex: 0,
						"aria-label": l("games.seti.moveTo", {
							ring: n.ring,
							sector: n.sector + 1,
							n: a[0].n ?? 1
						}),
						onClick: () => o(a),
						onKeyDown: (e) => {
							(e.key === "Enter" || e.key === " ") && (e.preventDefault(), o(a));
						}
					})] })
				] }, `cell-${n.ring}-${n.sector}`);
			}),
			e.anomalies.map((e, t) => {
				let n = Ee({
					ring: 4,
					sector: e.sector
				});
				return /* @__PURE__ */ m("g", {
					transform: `translate(${n.x + 14} ${n.y - 17})`,
					children: [
						/* @__PURE__ */ p("ellipse", {
							rx: "12",
							ry: "19",
							fill: cn[e.color],
							stroke: "#c2e4d4",
							strokeWidth: "1"
						}),
						/* @__PURE__ */ p("ellipse", {
							rx: "5",
							ry: "12",
							fill: "#0e3445"
						}),
						/* @__PURE__ */ p("title", { children: l("games.seti.anomalyAt", { n: e.sector + 1 }) })
					]
				}, t);
			}),
			/* @__PURE__ */ p("circle", {
				cx: "300",
				cy: "300",
				r: "47",
				fill: "#e89924",
				stroke: "#f5d05b",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ p("circle", {
				cx: "300",
				cy: "300",
				r: "42",
				fill: `url(#${u}sun)`
			}),
			Array.from({ length: 12 }, (e, t) => /* @__PURE__ */ p("path", {
				d: `M${300 + Math.cos(t * 1.71) * 32} ${300 + Math.sin(t * 1.71) * 32}q10-9 18 0`,
				fill: "none",
				stroke: "#fff7b3",
				strokeWidth: "1.2",
				opacity: ".25"
			}, t)),
			e.probes.map((t, n) => {
				let a = Ee(t), o = e.probes.slice(0, n).filter((e) => e.ring === t.ring && e.sector === t.sector).length * 16;
				return /* @__PURE__ */ m("g", {
					pointerEvents: "none",
					style: { color: r(t.owner) },
					children: [
						/* @__PURE__ */ p("title", { children: l(t.sample ? "games.seti.sampleCapsule" : "games.seti.probe", { name: i(t.owner) }) }),
						/* @__PURE__ */ p("svg", {
							x: a.x - 15 + o,
							y: a.y - 25,
							width: "29",
							height: "36",
							className: "seti-board-probe",
							children: /* @__PURE__ */ p($, { icon: t.sample ? "capsule" : "probe-piece" })
						}),
						/* @__PURE__ */ p("circle", {
							cx: a.x + 12 + o,
							cy: a.y - 10,
							r: "7",
							fill: r(t.owner),
							stroke: "#fff",
							strokeWidth: ".7"
						}),
						d(t.owner, a.x + 12 + o, a.y - 10, 12)
					]
				}, t.uid);
			}),
			/* @__PURE__ */ p("circle", {
				cx: "300",
				cy: "300",
				r: "238",
				fill: "none",
				stroke: "#96bdc3",
				strokeOpacity: ".35",
				strokeWidth: "1.1"
			}),
			e.sectors.map((e, n) => t.some((e) => e.n === n && /^(signal|row|handSignal|targetSignal|settle):/.test(e.id)) && /* @__PURE__ */ p($t, { d: un(243, 296, n) }, e.id)),
			dn.map((e) => t.some((t) => t.target?.ring === e.ring && t.target.sector === e.sector) && /* @__PURE__ */ p($t, { d: un(24 + e.ring * 43, 67 + e.ring * 43, e.sector) }, `${e.ring}-${e.sector}`))
		]
	});
}
//#endregion
//#region src/games/seti/alien-panels.tsx
var mn = [
	"trace-red",
	"trace-yellow",
	"trace-blue"
], hn = [
	"games.seti.traceNames.red",
	"games.seti.traceNames.yellow",
	"games.seti.traceNames.blue"
], gn = [
	"games.seti.goldFaces.techSet",
	"games.seti.goldFaces.techPair",
	"games.seti.goldFaces.missions",
	"games.seti.goldFaces.missionPair",
	"games.seti.goldFaces.incomeSet",
	"games.seti.goldFaces.incomeMaximum",
	"games.seti.goldFaces.traceSet",
	"games.seti.goldFaces.winFigure"
], _n = [
	[
		11,
		8,
		5
	],
	[
		7,
		5,
		3
	],
	[
		4,
		3,
		2
	],
	[
		8,
		6,
		4
	],
	[
		11,
		8,
		5
	],
	[
		5,
		4,
		3
	],
	[
		8,
		6,
		4
	],
	[
		8,
		6,
		4
	]
];
function vn(e) {
	let t = s(), { pub: n, priv: r, name: i, send: a, cardPiece: o } = e, c = r?.choices ?? [], l = n.players.find((t) => t.rid === e.myRid);
	return /* @__PURE__ */ m(f, { children: [
		!!r?.roundCards.length && /* @__PURE__ */ m("section", {
			className: "seti-round-cards seti-section",
			children: [/* @__PURE__ */ p("header", { children: /* @__PURE__ */ p("h2", { children: t("games.seti.roundCards") }) }), /* @__PURE__ */ p("div", {
				className: "seti-card-row",
				children: r.roundCards.map(o)
			})]
		}),
		!!r && (!!r.secret.length || !!r.secretPlayed.length) && /* @__PURE__ */ m("section", {
			className: "seti-secret-cards seti-section",
			children: [
				/* @__PURE__ */ m("header", { children: [/* @__PURE__ */ p("h2", { children: t("games.seti.secretCards") }), /* @__PURE__ */ p("span", { children: l?.secretPlayedCount })] }),
				/* @__PURE__ */ p("div", {
					className: "seti-card-row",
					children: r.secret.map(o)
				}),
				/* @__PURE__ */ m("details", { children: [/* @__PURE__ */ p("summary", { children: t("games.seti.playedSecrets") }), /* @__PURE__ */ p("div", {
					className: "seti-card-row",
					children: r.secretPlayed.map(o)
				})] })
			]
		}),
		!!r?.samples.length && /* @__PURE__ */ m("section", {
			className: "seti-section",
			children: [/* @__PURE__ */ p("header", { children: /* @__PURE__ */ p("h2", { children: t("games.seti.sampleContents") }) }), /* @__PURE__ */ p("div", {
				className: "seti-capsule-list",
				children: r.samples.map((e) => {
					let r = n.probes.find((t) => t.uid === e.uid);
					return /* @__PURE__ */ m("span", { children: [
						/* @__PURE__ */ p($, { icon: "capsule" }),
						t(de[e.sample]),
						" · ",
						t("games.seti.capsulePosition", {
							ring: r.ring,
							sector: r.sector + 1
						})
					] }, e.uid);
				})
			})]
		}),
		!!n.revealedCards.length && /* @__PURE__ */ m("section", {
			className: "seti-section",
			children: [/* @__PURE__ */ p("header", { children: /* @__PURE__ */ p("h2", { children: t("games.seti.revealedCards") }) }), /* @__PURE__ */ p("div", {
				className: "seti-card-row",
				children: n.revealedCards.map(o)
			})]
		}),
		!!n.sampleReveals.length && /* @__PURE__ */ m("section", {
			className: "seti-section",
			children: [/* @__PURE__ */ p("header", { children: /* @__PURE__ */ p("h2", { children: t("games.seti.sampleReveals") }) }), /* @__PURE__ */ p("div", {
				className: "seti-capsule-list",
				children: n.sampleReveals.map((e, n) => /* @__PURE__ */ m("span", { children: [
					i(e.owner),
					" · ",
					t(fe[e.planet]),
					" · ",
					t(de[e.sample])
				] }, n))
			})]
		}),
		!!n.anomalies.length && /* @__PURE__ */ m("section", {
			className: "seti-section",
			children: [/* @__PURE__ */ p("header", { children: /* @__PURE__ */ p("h2", { children: t("games.seti.anomalyRewards") }) }), /* @__PURE__ */ p("div", {
				className: "seti-capsule-list",
				children: n.anomalies.map((e) => /* @__PURE__ */ m("span", { children: [
					/* @__PURE__ */ p($, { icon: mn[[
						"red",
						"yellow",
						"blue"
					].indexOf(e.color)] }),
					t("games.seti.anomalyAt", { n: e.sector + 1 }),
					/* @__PURE__ */ p(an, { steps: e.reward })
				] }, e.color))
			})]
		}),
		/* @__PURE__ */ m("section", {
			className: "seti-gold-board seti-section",
			children: [/* @__PURE__ */ p("header", { children: /* @__PURE__ */ p("h2", { children: t("games.seti.goldTiles") }) }), /* @__PURE__ */ p("div", {
				className: "seti-gold-tiles",
				children: n.goldFaces.map((r, i) => {
					let o = c.find((e) => e.id === `gold:${i}` || e.id === `solvay:${i}`), s = i * 2 + r;
					return /* @__PURE__ */ m("button", {
						className: `seti-gold-tile${o ? " seti-legal" : ""}`,
						disabled: !o,
						onClick: () => o && a(o.id),
						children: [
							/* @__PURE__ */ p("strong", { children: t(gn[s]) }),
							/* @__PURE__ */ p("span", {
								className: "seti-gold-rates",
								children: _n[s].map((t, r) => /* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p($, {
									icon: "vp",
									n: t
								}), n.players.filter((e) => e.gold.includes(i) && Math.min(2, e.goldRates[e.gold.indexOf(i)]) === r).map((t) => /* @__PURE__ */ p(nn, {
									...e,
									owner: t.rid
								}, t.rid))] }, r))
							}),
							o && /* @__PURE__ */ p(en, {})
						]
					}, i);
				})
			})]
		}),
		/* @__PURE__ */ p("section", {
			className: "seti-species-row",
			children: n.species.map((n, r) => /* @__PURE__ */ m("article", {
				className: "seti-species",
				children: [
					/* @__PURE__ */ p("h2", { children: n.id ? t(xe[n.id]) : t("games.seti.unnamedSpecies", { n: r + 1 }) }),
					/* @__PURE__ */ p("div", {
						className: "seti-traces",
						children: n.traces.map((n, o) => {
							let s = c.find((e) => e.id === `trace:${r}:${o}`);
							return /* @__PURE__ */ m("button", {
								className: `seti-trace${s ? " seti-legal" : ""}`,
								disabled: !s,
								"aria-label": `${t(hn[o])}${n ? ` · ${i(n)}` : ""}`,
								onClick: () => s && a(s.id),
								children: [
									/* @__PURE__ */ p($, { icon: mn[o] }),
									n && /* @__PURE__ */ p(nn, {
										...e,
										owner: n
									}),
									s && /* @__PURE__ */ p(en, { round: !0 })
								]
							}, o);
						})
					}),
					n.revealed && /* @__PURE__ */ m(f, { children: [
						/* @__PURE__ */ p("div", {
							className: "seti-research-columns",
							children: [
								"red",
								"yellow",
								"blue"
							].map((i, o) => /* @__PURE__ */ p("div", {
								className: "seti-research-column",
								children: n.research.map((n, s) => {
									if (n.color !== i) return null;
									let l = c.find((e) => e.id === `trace:${r}:research:${s}`);
									return /* @__PURE__ */ m("button", {
										className: `seti-research-space seti-research-${i}${l ? " seti-legal" : ""}`,
										disabled: !l,
										"aria-label": `${t(hn[o])} · ${t("games.seti.researchTrace", { n: s + 1 })}`,
										onClick: () => l && a(l.id),
										children: [
											/* @__PURE__ */ p(an, { steps: n.reward }),
											!!n.cost && /* @__PURE__ */ p("small", { children: t("games.seti.researchCost", { n: n.cost }) }),
											!!n.fossil && /* @__PURE__ */ p("small", { children: t("games.seti.fossilCost", { n: n.fossil }) }),
											!!n.danger && /* @__PURE__ */ p($, {
												icon: "danger",
												n: n.danger
											}),
											n.repeat && /* @__PURE__ */ p("span", {
												"aria-label": t("games.seti.repeatable"),
												children: "∞"
											}),
											n.owners.map((t, n) => /* @__PURE__ */ p(nn, {
												...e,
												owner: t
											}, n)),
											l && /* @__PURE__ */ p(en, { round: !0 })
										]
									}, s);
								})
							}, i))
						}),
						/* @__PURE__ */ m("div", {
							className: "seti-species-market",
							children: [n.market.map(o), !!n.deckCount && /* @__PURE__ */ p("span", { children: /* @__PURE__ */ p($, {
								icon: "alien-card",
								n: n.deckCount
							}) })]
						}),
						!!n.messages.length && /* @__PURE__ */ p("div", {
							className: "seti-message-list",
							children: n.messages.map((e, n) => /* @__PURE__ */ m("span", { children: [t("games.seti.messageThreshold", {
								name: i(e.owner),
								n: e.threshold
							}), e.card && ` · ${t(F(e.card.id).name)}`] }, n))
						}),
						n.id === "mascamites" && /* @__PURE__ */ p("p", {
							className: "seti-alien-counters",
							children: t("games.seti.samplesRemaining", {
								jupiter: n.sampleCounts.jupiter,
								saturn: n.sampleCounts.saturn
							})
						}),
						n.id === "oumuamua" && /* @__PURE__ */ m("div", {
							className: "seti-alien-counters",
							children: [
								/* @__PURE__ */ p($, { icon: "signal" }),
								n.signals.map((t, n) => /* @__PURE__ */ p(nn, {
									...e,
									owner: t
								}, n)),
								c.filter((e) => e.id.startsWith("oumuamua:") || e.id === "settle:oumuamua").map((e) => /* @__PURE__ */ p("button", {
									className: "seti-button",
									onClick: () => a(e.id),
									children: t(e.key, e.params)
								}, e.id))
							]
						}),
						!!n.dangerThresholds.length && /* @__PURE__ */ p("p", { children: t("games.seti.exertianMilestones", {
							first: n.dangerThresholds[0],
							second: n.dangerThresholds[1]
						}) })
					] }),
					/* @__PURE__ */ m("div", {
						className: "seti-overflow",
						children: [
							/* @__PURE__ */ p($, {
								icon: "vp",
								n: 3
							}),
							/* @__PURE__ */ p("span", {
								title: t("games.seti.overflowCount", { n: n.overflow.length }),
								children: n.overflow.map((t, r) => /* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p($, { icon: mn[[
									"red",
									"yellow",
									"blue"
								].indexOf(n.overflowColors[r])] }), /* @__PURE__ */ p(nn, {
									...e,
									owner: t
								})] }, r))
							}),
							c.filter((e) => e.id.startsWith(`trace:${r}:overflow:`)).map((e) => /* @__PURE__ */ p("button", {
								className: "seti-button",
								onClick: () => a(e.id),
								children: t(hn[e.n])
							}, e.id))
						]
					})
				]
			}, r))
		}),
		!!l && /* @__PURE__ */ m("div", {
			className: "seti-alien-counters",
			children: [n.species.some((e) => e.id === "oumuamua") && /* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p($, {
				icon: "fossil",
				n: l.fossil
			}), t("games.seti.fossil")] }), n.species.some((e) => e.id === "exertians") && /* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p($, {
				icon: "danger",
				n: l.danger
			}), t("games.seti.danger")] })]
		})
	] });
}
//#endregion
//#region src/games/seti/card-art.tsx
var yn = {
	1: "pioneer",
	15: "entry",
	16: "dragonfly",
	25: "lightsail",
	50: "array",
	71: "focus",
	84: "sample",
	101: "telescope",
	113: "solvay",
	119: "pixl",
	125: "correction",
	133: "window"
}, bn = {
	1: "games.seti.cardBrief.pioneer",
	15: "games.seti.cardBrief.entry",
	16: "games.seti.cardBrief.dragonfly",
	25: "games.seti.cardBrief.lightsail",
	50: "games.seti.cardBrief.array",
	71: "games.seti.cardBrief.focus",
	84: "games.seti.cardBrief.sample",
	101: "games.seti.cardBrief.telescope",
	113: "games.seti.cardBrief.solvay",
	119: "games.seti.cardBrief.pixl",
	125: "games.seti.cardBrief.correction",
	133: "games.seti.cardBrief.window"
};
function xn({ id: e }) {
	let t = {
		1: [["data", 1], ["vp", 4]],
		15: [
			["vp", 3],
			["data", 1],
			["card", 1]
		],
		16: [["lander"]],
		25: [["move", 4]],
		50: [
			["signal"],
			["signal"],
			["signal"]
		],
		71: [["rotate"], ["tech"]],
		84: [["lander"], ["trace-yellow"]],
		101: [
			["signal"],
			["signal"],
			["signal"]
		],
		113: [["publicity", 2]],
		119: [["rotate"], ["computer"]],
		125: [["move", 1]],
		133: [["probe"]]
	};
	return /* @__PURE__ */ p("span", {
		className: "seti-project-effects",
		children: t[e] ? t[e].map(([e, t], n) => /* @__PURE__ */ p($, {
			icon: e,
			n: t,
			className: e === "signal" ? "seti-paper-signal" : void 0
		}, n)) : /* @__PURE__ */ p(an, { steps: F(e).effects.slice(0, 4) })
	});
}
var Sn = {
	mascamites: "<path d=\"M0 0H240V163H0Z\" fill=\"#373b27\"/><ellipse cx=\"140\" cy=\"119\" rx=\"79\" ry=\"18\" fill=\"#b29952\"/><g fill=\"#a37d36\" stroke=\"#e1bf73\" stroke-width=\"3\"><path d=\"M89 92L41 63 23 115M118 102L74 139 56 124M138 83L179 46 203 78M149 108L190 133 215 117\" fill=\"none\"/><ellipse cx=\"119\" cy=\"88\" rx=\"38\" ry=\"20\" transform=\"rotate(-28 119 88)\"/><path d=\"M84 74Q55 40 75 23Q96 54 105 64Z\"/><circle cx=\"151\" cy=\"71\" r=\"16\"/></g><circle cx=\"154\" cy=\"69\" r=\"5\" fill=\"#f0c984\"/><path d=\"M160 59L172 30M145 57L143 27\" stroke=\"#dbc08b\" stroke-width=\"2\"/>",
	anomalies: "<path d=\"M0 0H240V163H0Z\" fill=\"#0a3041\"/><g fill=\"none\" stroke=\"#6eb6b7\" opacity=\".5\"><ellipse cx=\"120\" cy=\"82\" rx=\"93\" ry=\"28\"/><ellipse cx=\"120\" cy=\"82\" rx=\"58\" ry=\"56\"/><ellipse cx=\"120\" cy=\"82\" rx=\"105\" ry=\"67\"/></g><path d=\"M116 20Q153 52 132 130Q92 112 104 45Z\" fill=\"#87d8d6\" stroke=\"#d0efdf\" stroke-width=\"3\"/><path d=\"M118 43Q140 74 122 107Q106 75 118 43Z\" fill=\"#06384f\"/><circle cx=\"123\" cy=\"73\" r=\"10\" fill=\"#339bba\"/>",
	oumuamua: "<path d=\"M0 0H240V163H0Z\" fill=\"#202739\"/><g stroke=\"#8bacc9\" opacity=\".4\"><path d=\"M10 40H37M30 124H67M180 28H214M169 133H224\"/></g><path d=\"M20 117Q60 58 214 33L224 49Q155 109 28 130Z\" fill=\"#745166\" stroke=\"#c6a5b0\" stroke-width=\"3\"/><path d=\"M44 111L198 45 163 80 102 105Z\" fill=\"#a07981\"/><g stroke=\"#392f43\" stroke-width=\"4\"><path d=\"M65 104L86 100M112 83L133 77M147 70L168 59\"/></g>",
	centaurians: "<path d=\"M0 0H240V163H0Z\" fill=\"#163c38\"/><path d=\"M0 138L66 97 107 131 179 84 240 114V163H0Z\" fill=\"#315e4d\"/><g fill=\"none\" stroke=\"#a4debf\" stroke-width=\"2\"><circle cx=\"125\" cy=\"67\" r=\"42\"/><circle cx=\"125\" cy=\"67\" r=\"57\" opacity=\".4\"/><path d=\"M125 4V20M125 114V148M65 67H40M185 67H220\"/></g><path d=\"M125 29L158 50 158 86 125 105 92 86 92 50Z\" fill=\"#628a73\" stroke=\"#d1e5b8\" stroke-width=\"3\"/><path d=\"M125 44L144 57 144 78 125 90 106 78 106 57Z\" fill=\"#173d37\"/><circle cx=\"125\" cy=\"67\" r=\"9\" fill=\"#c5ebd1\"/>",
	exertians: "<path d=\"M0 0H240V163H0Z\" fill=\"#292c33\"/><path d=\"M0 145L240 108V163H0Z\" fill=\"#7f4b38\"/><path d=\"M100 23H145L150 93 123 142 96 95Z\" fill=\"#a0a5a3\" stroke=\"#e3d1a1\" stroke-width=\"3\"/><path d=\"M103 48L143 62M102 69L146 83M104 91L136 103M112 112L128 118\" stroke=\"#354047\" stroke-width=\"6\"/><path d=\"M48 35L87 47V83L48 72ZM160 49L201 36V73L160 87Z\" fill=\"#c47847\" stroke=\"#e0ac67\" stroke-width=\"2\"/><circle cx=\"122\" cy=\"38\" r=\"11\" fill=\"#f2d37e\"/>"
};
function Cn({ id: e, detailed: t = !1 }) {
	let n = s(), r = F(e), i = r.effects.some((e) => e.kind === "research" && e.family === "computer") ? "pixl" : r.effects.some((e) => e.kind === "research" || e.kind === "rowSignals" || e.kind === "targetSignal") ? "array" : r.effects.some((e) => e.kind === "launch" || e.kind === "land" || e.kind === "move") ? "pioneer" : "solvay", a = r.species ? Sn[r.species] : qt[yn[e] ?? i], o = r.species === "exertians";
	return /* @__PURE__ */ m("span", {
		className: `seti-project seti-project-${r.color}${t ? " seti-project-detailed" : ""}`,
		children: [
			/* @__PURE__ */ m("span", {
				className: "seti-project-art",
				children: [/* @__PURE__ */ p(Qt, {
					markup: a,
					viewBox: "0 0 240 163"
				}), !o && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("span", {
					className: "seti-project-free",
					children: r.corner ? /* @__PURE__ */ p(an, { steps: r.corner }) : /* @__PURE__ */ p($, {
						icon: r.free,
						n: 1
					})
				}), /* @__PURE__ */ p("span", {
					className: "seti-project-signal",
					children: /* @__PURE__ */ p($, { icon: "signal" })
				})] })]
			}),
			/* @__PURE__ */ m("span", {
				className: "seti-project-title",
				children: [/* @__PURE__ */ m("span", {
					className: "seti-project-cost",
					children: [/* @__PURE__ */ p("b", { children: o ? r.danger : r.cost }), /* @__PURE__ */ p($, { icon: o ? "danger" : r.energyCost ? "energy" : "credit" })]
				}), /* @__PURE__ */ p("strong", { children: n(r.name) })]
			}),
			/* @__PURE__ */ m("span", {
				className: "seti-project-body",
				children: [/* @__PURE__ */ p(xn, { id: e }), /* @__PURE__ */ p("span", { children: n(!t && bn[e] ? bn[e] : r.text) })]
			}),
			!o && /* @__PURE__ */ m("span", {
				className: `seti-project-income seti-income-${r.income}`,
				children: [/* @__PURE__ */ p("small", { children: r.id > 1e3 ? `ET.${r.id - 1e3}` : r.id }), /* @__PURE__ */ p($, { icon: r.income })]
			})
		]
	});
}
//#endregion
//#region src/games/seti/view-player.tsx
var wn = {
	c0: "publicity",
	c1: "card",
	c2: "energy",
	c3: "credit"
}, Tn = [
	"games.seti.traceNames.red",
	"games.seti.traceNames.yellow",
	"games.seti.traceNames.blue"
];
function En(e) {
	u();
	let n = s(), r = e.public, h = e.private, [g, _] = i(null), [v, ee] = i(!1), [y, te] = i(!1), b = h?.choices ?? [], x = r.players.find((t) => t.rid === e.myRid), S = (t) => t === "$neutral" ? n("games.seti.neutralMarker") : e.members.find((e) => e.rid === t)?.name ?? n(c[0].nameKey), C = {
		pub: r,
		name: S,
		color: (t) => t === "$neutral" ? "#9ba6ab" : c[(e.members.find((e) => e.rid === t)?.colorIndex ?? 0) % c.length]?.hex ?? "#7893a4",
		avatar: (n) => t[(e.members.find((e) => e.rid === n)?.avatar ?? 0) % t.length]
	}, w = (e) => {
		_(e), ee(!0);
	}, T = (t) => {
		e.send({
			type: "choose",
			id: t
		}), ee(!1);
	}, E = (e) => {
		e.length === 1 ? T(e[0].id) : e.length && w({
			kind: "actions",
			ids: e.map((e) => e.id)
		});
	}, ne = [
		...h?.hand ?? [],
		...h?.roundCards ?? [],
		...h?.secret ?? [],
		...h?.secretPlayed ?? [],
		...r.species.flatMap((e) => [...e.market, ...e.messages.flatMap((e) => e.card ? [e.card] : [])]),
		...r.market,
		...r.discard,
		...r.players.flatMap((e) => [
			...e.income,
			...e.played,
			...e.missions.map((e) => e.card)
		])
	], D = (e) => ne.find((t) => t.uid === e), re = (e) => {
		let t = { ...e.params };
		e.key === "games.seti.exchange" && (t.from = n(pe[t.from]), t.to = n(pe[t.to])), e.key === "games.seti.chooseReward" && (t.resource = n(pe[t.resource])), (e.key === "games.seti.markTrace" || e.key === "games.seti.overflowColor") && (t.color = Number(t.color) > 0 ? n(Tn[Number(t.color) - 1]) : n("games.seti.anyTrace")), e.key === "games.seti.chooseTraceColor" && (t.n = n(Tn[e.n]));
		let i = n(e.key, t);
		e.id.startsWith("alienSample:") && (i = `${n(fe[e.id.split(":")[1]])} · ${i}`);
		let a = D(e.card);
		a && (i = `${n(F(a.id).name)} · ${i}`);
		let o = r.figures.find((t) => t.uid === e.card);
		o && (i = `${n(fe[o.planet])} · ${i}`);
		let s = r.probes.find((t) => t.uid === e.card);
		if (s && !e.target && (i = `${n("games.seti.probe", { name: S(s.owner) })} · ${i}`), (e.id.startsWith("gold:") || e.id.startsWith("solvay:")) && (i = `${n("games.seti.markGold", { n: e.n + 1 })} · ${n(gn[e.n * 2 + r.goldFaces[e.n]])}`), e.id.startsWith("free:exchange:card:")) {
			let t = D(e.id.split(":")[5]);
			t && (i += ` · ${n(F(t.id).name)}`);
		}
		return i;
	}, O = b.filter((e) => e.group === "effect" || e.group === "response"), k = b.find((e) => e.id === "endTurn"), A = b.filter((e) => e.id === "pick:deck" || e.id === "free:buy:deck"), j = (e) => {
		let t = b.some((t) => t.card === e.uid);
		return /* @__PURE__ */ m("button", {
			className: `seti-card${t ? " seti-card-legal" : ""}`,
			"aria-label": n(F(e.id).name),
			onClick: () => w({
				kind: "card",
				card: e
			}),
			children: [/* @__PURE__ */ p(Cn, { id: e.id }), t && /* @__PURE__ */ p(en, {})]
		}, e.uid);
	}, M = /* @__PURE__ */ m("section", {
		className: "seti-hand seti-section",
		children: [/* @__PURE__ */ m("header", { children: [/* @__PURE__ */ p("h2", { children: n("games.seti.hand") }), /* @__PURE__ */ p("span", { children: h?.hand.length ?? 0 })] }), /* @__PURE__ */ m("div", {
			className: "seti-card-row",
			children: [h?.hand.map(j), !h?.hand.length && /* @__PURE__ */ p("p", { children: n("games.seti.noHand") })]
		})]
	}), N = /* @__PURE__ */ p("div", {
		className: "seti-resources",
		children: x && [
			"credit",
			"energy",
			"publicity",
			"data"
		].map((e) => /* @__PURE__ */ p(tn, {
			resource: e,
			n: x[e]
		}, e))
	}), P = g?.kind === "card" ? F(g.card.id) : null, ie = g?.kind === "tech" ? I(g.id) : null, ae = g?.kind === "planet" ? ve.find((e) => e.id === g.id) : null, oe = g?.kind === "sector" ? r.sectors[g.n] : null, se = b.filter((e) => g?.kind === "card" ? e.card === g.card.uid : g?.kind === "tech" ? e.tech === g.id : g?.kind === "planet" ? /^(orbit|mainLand|land):/.test(e.id) && r.probes.some((t) => t.uid === e.card && V(r.angles, t, r.species.some((e) => e.id === "oumuamua")).planet === g.id) : g?.kind === "sector" ? e.n === g.n && /^(signal|row|handSignal|settle):/.test(e.id) : g?.kind === "actions" && (!g.ids || g.ids.includes(e.id)) && (!g.group || e.group === g.group)), ce = se.find((e) => e.group === "main" || e.id.startsWith("setup:") || e.id.startsWith("pick:")) ?? se[0], le = P ? n(P.name) : ie ? n(ie.name) : ae ? n(fe[ae.id]) : oe ? n(be[oe.id]) : g?.kind === "history" ? n("games.seti.history") : n("games.seti.decisions"), ue = r.effect?.kind === "move" ? n("games.seti.moveEffect", { n: r.effect.n ?? 0 }) : n("games.seti.nextRotation", { n: r.nextDisc + 1 });
	return /* @__PURE__ */ m(d, {
		adaptive: !0,
		className: "seti-screen",
		scroll: !1,
		actionsHeight: "seti-actions-slot",
		banner: /* @__PURE__ */ m("div", {
			className: "seti-banner",
			children: [
				/* @__PURE__ */ m("div", {
					className: "seti-brand",
					children: [/* @__PURE__ */ p("b", { children: "SETI" }), /* @__PURE__ */ p("small", { children: n("games.seti.roundLabel", { n: r.round }) })]
				}),
				/* @__PURE__ */ p("div", {
					className: "seti-players",
					children: r.players.map((e) => /* @__PURE__ */ m("div", {
						className: `seti-player${e.rid === r.acting ? " seti-player-active" : ""}${e.passed ? " seti-player-passed" : ""}`,
						children: [
							/* @__PURE__ */ p(nn, {
								...C,
								owner: e.rid
							}),
							/* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p("strong", { children: S(e.rid) }), /* @__PURE__ */ p("small", { children: e.passed ? n("games.seti.completed") : n("games.seti.handCount", { n: e.handCount }) })] }),
							/* @__PURE__ */ p(tn, {
								resource: "vp",
								n: e.vp
							})
						]
					}, e.rid))
				}),
				/* @__PURE__ */ m("div", {
					className: "seti-turn",
					children: [/* @__PURE__ */ p("strong", { children: r.acting && r.acting !== e.myRid ? n("games.seti.waiting", { name: S(r.acting) }) : n(r.prompt) }), /* @__PURE__ */ p("small", { children: ue })]
				}),
				/* @__PURE__ */ p("div", {
					className: "seti-banner-resources",
					children: N
				})
			]
		}),
		actions: /* @__PURE__ */ m("div", {
			className: "seti-dock",
			children: [/* @__PURE__ */ p("div", {
				className: "seti-dock-hand",
				children: M
			}), /* @__PURE__ */ m("div", {
				className: "seti-controls",
				children: [
					/* @__PURE__ */ p("div", {
						className: "seti-dock-resources",
						children: N
					}),
					/* @__PURE__ */ m("div", {
						className: "seti-toolbar",
						children: [
							/* @__PURE__ */ p("button", {
								className: "seti-button seti-primary",
								disabled: !b.length,
								onClick: () => O.length === 1 ? T(O[0].id) : w(O.length ? {
									kind: "actions",
									ids: O.map((e) => e.id)
								} : {
									kind: "actions",
									group: "main"
								}),
								children: O.length === 1 ? n(O[0].key, O[0].params) : n("games.seti.choose")
							}),
							/* @__PURE__ */ p("button", {
								className: "seti-button",
								disabled: !b.some((e) => e.group === "free"),
								onClick: () => w({
									kind: "actions",
									group: "free"
								}),
								children: n("games.seti.freeActions")
							}),
							k ? /* @__PURE__ */ p("button", {
								className: "seti-button",
								onClick: () => T(k.id),
								children: n("games.seti.endTurn")
							}) : /* @__PURE__ */ p("button", {
								className: "seti-button seti-history-button",
								onClick: () => w({ kind: "history" }),
								children: n("games.seti.history")
							})
						]
					}),
					/* @__PURE__ */ p("div", {
						className: "seti-dock-income",
						children: x && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("span", { children: n("games.seti.income") }), [
							"credit",
							"energy",
							"publicity",
							"card"
						].map((e) => {
							let t = x.income.filter((t) => F(t.id).income === e).length;
							return t ? /* @__PURE__ */ p("span", { children: /* @__PURE__ */ p($, {
								icon: e,
								n: t
							}) }, e) : null;
						})] })
					})
				]
			})]
		}),
		children: [
			/* @__PURE__ */ p(l, {
				kind: "sheen",
				base: "#0b1d2c",
				className: "seti-texture"
			}),
			/* @__PURE__ */ m("div", {
				className: "seti-table",
				children: [/* @__PURE__ */ m("div", {
					className: "seti-left",
					children: [/* @__PURE__ */ m("section", {
						className: `seti-board-frame${y ? " seti-zoom" : ""}`,
						children: [/* @__PURE__ */ m("header", {
							className: "seti-board-heading",
							children: [
								/* @__PURE__ */ p("h2", { children: n("games.seti.solarSystem") }),
								/* @__PURE__ */ p("small", {
									className: "seti-board-detail",
									children: ue
								}),
								/* @__PURE__ */ p("button", {
									className: "seti-button",
									onClick: () => te(!y),
									children: n(y ? "games.seti.fit" : "games.seti.zoom")
								})
							]
						}), /* @__PURE__ */ p("div", {
							className: "seti-board-scroll",
							children: /* @__PURE__ */ p(pn, {
								...C,
								choices: b,
								choose: E,
								inspectSector: (e) => w({
									kind: "sector",
									n: e
								})
							})
						})]
					}), /* @__PURE__ */ p("div", {
						className: "seti-flow-hand",
						children: M
					})]
				}), /* @__PURE__ */ m("div", {
					className: "seti-public",
					children: [
						/* @__PURE__ */ m("section", {
							className: "seti-exploration seti-section",
							children: [/* @__PURE__ */ p("header", { children: /* @__PURE__ */ p("h2", { children: n("games.seti.planetaryBoard") }) }), /* @__PURE__ */ p("div", {
								className: "seti-exploration-grid",
								children: ve.filter((e) => e.id !== "oumuamua" || r.species.some((e) => e.id === "oumuamua")).map((e) => /* @__PURE__ */ p(on, {
									...C,
									planet: e,
									choices: b,
									onOpen: () => w({
										kind: "planet",
										id: e.id
									})
								}, e.id))
							})]
						}),
						/* @__PURE__ */ m("section", {
							className: "seti-market seti-section",
							children: [/* @__PURE__ */ m("header", { children: [/* @__PURE__ */ p("h2", { children: n("games.seti.market") }), /* @__PURE__ */ p("small", { children: n("games.seti.deckCount", { n: r.deckCount }) })] }), /* @__PURE__ */ m("div", {
								className: "seti-card-row",
								children: [r.market.map(j), /* @__PURE__ */ m("button", {
									className: "seti-deck",
									"aria-label": n("games.seti.drawCard"),
									onClick: () => A.length ? E(A) : w({
										kind: "actions",
										group: "free"
									}),
									children: [
										/* @__PURE__ */ p($, { icon: "signal" }),
										/* @__PURE__ */ p("strong", { children: "SETI" }),
										/* @__PURE__ */ p("span", { children: r.deckCount }),
										A.length > 0 && /* @__PURE__ */ p(en, {})
									]
								})]
							})]
						}),
						/* @__PURE__ */ m("section", {
							className: "seti-techs seti-section",
							children: [/* @__PURE__ */ p("header", { children: /* @__PURE__ */ p("h2", { children: n("games.seti.technologies") }) }), [
								"probe",
								"telescope",
								"computer"
							].map((t) => /* @__PURE__ */ m("div", {
								className: "seti-tech-family",
								children: [/* @__PURE__ */ p("h3", { children: n(he[t]) }), /* @__PURE__ */ p("div", {
									className: "seti-tech-grid",
									children: me.filter((e) => e.family === t).map((t) => {
										let i = r.techMarket.find((e) => e.id === t.id), a = x?.techs.includes(t.id), o = b.some((e) => e.tech === t.id);
										return /* @__PURE__ */ m("button", {
											className: `seti-tech${a ? " seti-tech-owned" : ""}${o ? " seti-legal" : ""}`,
											onClick: () => w({
												kind: "tech",
												id: t.id
											}),
											"aria-label": `${n(t.name)} · ${a ? n("games.seti.ownedTech") : n("games.seti.techRemaining", { n: i.count })}`,
											children: [
												/* @__PURE__ */ p(sn, {
													id: t.id,
													legal: o
												}),
												/* @__PURE__ */ p("span", {
													className: "seti-tech-name",
													children: n(t.name)
												}),
												/* @__PURE__ */ p("span", {
													className: "seti-tech-status",
													children: a ? /* @__PURE__ */ p(nn, {
														...C,
														owner: e.myRid
													}) : /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("small", { children: i.count }), i.reward && /* @__PURE__ */ p($, {
														icon: i.reward === "pickCard" ? "card" : i.reward,
														n: i.reward === "vp" ? 3 : 1
													})] })
												})
											]
										}, t.id);
									})
								})]
							}, t))]
						}),
						x && /* @__PURE__ */ m("section", {
							className: "seti-personal seti-section",
							children: [
								/* @__PURE__ */ m("header", { children: [/* @__PURE__ */ p("h2", { children: n("games.seti.computer") }), /* @__PURE__ */ p("span", {
									className: "seti-data-pool",
									title: n("games.seti.dataPool"),
									children: Array.from({ length: x.data }, (e, t) => /* @__PURE__ */ p($, { icon: "data-piece" }, t))
								})] }),
								/* @__PURE__ */ p("div", {
									className: "seti-computer",
									children: Array.from({ length: 6 }, (e, t) => {
										let r = b.find((e) => e.id === "free:upper" && e.n === t), i = b.find((e) => e.id === `install:${t}`), a = b.find((e) => e.id === `free:lower:${t}`), o = t < x.computer, s = x.installed[t];
										return /* @__PURE__ */ m("div", {
											className: `seti-computer-column${s ? " seti-computer-installed" : ""}`,
											children: [/* @__PURE__ */ m("button", {
												"aria-label": n(i ? "games.seti.installTech" : "games.seti.upperReward", { n: t + 1 }),
												className: `seti-data-slot${o ? " seti-data-filled" : ""}`,
												disabled: !r && !i,
												onClick: () => T((i ?? r).id),
												children: [o ? /* @__PURE__ */ p($, { icon: "data-piece" }) : s ? /* @__PURE__ */ p($, {
													icon: "vp",
													n: 2
												}) : t === 1 ? /* @__PURE__ */ p($, {
													icon: "publicity",
													n: 1
												}) : t === 3 ? /* @__PURE__ */ p($, { icon: "income" }) : t === 5 ? /* @__PURE__ */ p($, { icon: "trace-blue" }) : /* @__PURE__ */ p("span", { children: t + 1 }), (r || i) && /* @__PURE__ */ p(en, {})]
											}), /* @__PURE__ */ m("button", {
												className: `seti-data-slot seti-lower${x.lower.includes(t) ? " seti-data-filled" : ""}`,
												"aria-label": n("games.seti.lowerReward", { n: t + 1 }),
												disabled: !a,
												onClick: () => a && T(a.id),
												children: [x.lower.includes(t) ? /* @__PURE__ */ p($, { icon: "data-piece" }) : s ? /* @__PURE__ */ p($, {
													icon: wn[s],
													n: s === "c0" ? 2 : 1
												}) : null, a && /* @__PURE__ */ p(en, {})]
											})]
										}, t);
									})
								}),
								/* @__PURE__ */ m("details", {
									className: "seti-personal-details",
									children: [/* @__PURE__ */ m("summary", { children: [
										n("games.seti.income"),
										" · ",
										x.income.length
									] }), /* @__PURE__ */ p("div", {
										className: "seti-card-row",
										children: x.income.map(j)
									})]
								}),
								/* @__PURE__ */ m("details", {
									className: "seti-personal-details",
									children: [/* @__PURE__ */ m("summary", { children: [
										n("games.seti.missions"),
										" · ",
										x.missions.length + x.played.length
									] }), /* @__PURE__ */ m("div", {
										className: "seti-card-row",
										children: [x.missions.map((e) => /* @__PURE__ */ m("span", {
											className: "seti-mission",
											children: [j(e.card), /* @__PURE__ */ p("span", {
												className: "seti-mission-circles",
												children: Array.from({ length: F(e.card.id).mission?.rewards.length ?? 1 }, (t, n) => /* @__PURE__ */ p("span", {
													className: e.circles.includes(n) ? "seti-mission-done" : "",
													children: n + 1
												}, n))
											})]
										}, e.card.uid)), x.played.map(j)]
									})]
								})
							]
						}),
						/* @__PURE__ */ p(vn, {
							...C,
							priv: h,
							myRid: e.myRid,
							send: T,
							cardPiece: j
						})
					]
				})]
			}),
			a(/* @__PURE__ */ p("div", {
				className: "seti-modal",
				children: /* @__PURE__ */ p(o, {
					open: v,
					onClose: () => ee(!1),
					title: le,
					label: le,
					tall: !0,
					footer: ce ? /* @__PURE__ */ p("div", {
						className: "seti-sheet-footer",
						children: /* @__PURE__ */ m("button", {
							className: "seti-button seti-primary",
							onClick: () => T(ce.id),
							children: [P ? n(ce.key, ce.params) : re(ce), P && ce.id.startsWith("play:") && /* @__PURE__ */ p($, {
								icon: P.energyCost ? "energy" : "credit",
								n: P.cost
							})]
						})
					}) : void 0,
					children: /* @__PURE__ */ m("div", {
						className: "seti-dialog",
						children: [
							P && /* @__PURE__ */ m("div", {
								className: "seti-inspection-card",
								children: [/* @__PURE__ */ p(Cn, {
									id: P.id,
									detailed: !0
								}), /* @__PURE__ */ m("div", {
									className: "seti-card-benefits",
									children: [/* @__PURE__ */ m("span", { children: [n("games.seti.discardBenefit"), P.corner ? /* @__PURE__ */ p(an, { steps: P.corner }) : /* @__PURE__ */ p($, {
										icon: P.free,
										n: 1
									})] }), /* @__PURE__ */ m("span", { children: [n("games.seti.income"), /* @__PURE__ */ p($, {
										icon: P.income,
										n: 1
									})] })]
								})]
							}),
							ie && /* @__PURE__ */ m("div", {
								className: "seti-inspection-tech",
								children: [
									/* @__PURE__ */ p(sn, { id: ie.id }),
									/* @__PURE__ */ p("p", { children: n(ie.text) }),
									/* @__PURE__ */ p("p", { children: n("games.seti.researchFirst") })
								]
							}),
							ae && /* @__PURE__ */ m("div", {
								className: "seti-inspection-planet",
								children: [
									/* @__PURE__ */ p(on, {
										...C,
										planet: ae,
										choices: [],
										onOpen: () => void 0
									}),
									/* @__PURE__ */ m("p", { children: [
										n("games.seti.orbiters", { n: r.figures.filter((e) => e.planet === ae.id && e.kind === "orbiter").length }),
										" · ",
										n("games.seti.landers", { n: r.figures.filter((e) => e.planet === ae.id && e.kind === "lander").length })
									] }),
									ae.moons.map((e) => /* @__PURE__ */ m("div", {
										className: "seti-moon-detail",
										children: [
											/* @__PURE__ */ p("strong", { children: n(e.name) }),
											/* @__PURE__ */ p(an, { steps: e.effects }),
											/* @__PURE__ */ p("span", { children: r.figures.filter((t) => t.moon === e.id).map((e) => S(e.owner)).join(", ") || n("games.seti.empty") })
										]
									}, e.id))
								]
							}),
							oe && /* @__PURE__ */ m("div", {
								className: "seti-inspection",
								children: [
									/* @__PURE__ */ p("p", { children: n("games.seti.signalCount", {
										n: oe.signals.length,
										max: oe.capacity
									}) }),
									/* @__PURE__ */ p("div", {
										className: "seti-sector-markers",
										children: oe.signals.map((e, t) => /* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p(nn, {
											...C,
											owner: e
										}), S(e)] }, t))
									}),
									/* @__PURE__ */ p("span", { children: n("games.seti.gainEffect", {
										n: oe.winners.length ? oe.laterVP : oe.firstVP,
										name: n("games.seti.resources.vp")
									}) })
								]
							}),
							g?.kind === "history" ? /* @__PURE__ */ p("ol", {
								className: "seti-log",
								children: r.log.map((e, t) => /* @__PURE__ */ m("li", { children: [
									/* @__PURE__ */ p("b", { children: S(e.owner) }),
									" · ",
									n(e.key, e.params)
								] }, t))
							}) : /* @__PURE__ */ m("div", {
								className: "seti-choice-list",
								children: [se.filter((e) => e !== ce).map((e) => /* @__PURE__ */ p("button", {
									className: "seti-button",
									onClick: () => T(e.id),
									children: re(e)
								}, e.id)), g?.kind === "actions" && !se.length && /* @__PURE__ */ p("p", { children: n("games.seti.noChoices") })]
							})
						]
					})
				})
			}), document.body)
		]
	});
}
//#endregion
//#region src/games/seti/bot-metrics.ts
function Dn(e, t, n, r) {
	let i = e.players.find((e) => e.rid === n), a = e.figures.filter((e) => e.owner === n), o = e.probes.filter((e) => e.owner === n), s = (e, t) => e.traces.filter((e, r) => e === n && (!t || [
		"red",
		"yellow",
		"blue"
	][r] === t)).length + e.overflow.filter((r, i) => r === n && (!t || e.overflowColors[i] === t)).length + e.research.filter((e) => !t || e.color === t).reduce((e, t) => e + t.owners.filter((e) => e === n).length, 0);
	switch (r.kind) {
		case "figure": return a.filter((e) => !r.target || e.planet === r.target).length;
		case "lander": return a.filter((e) => e.kind === "lander" && (!r.target || (r.target === "planet" ? !e.moon : e.planet === r.target))).length;
		case "orbiter": return a.filter((e) => e.kind === "orbiter").length;
		case "samePlanetFigures": return Math.max(0, ...a.map((e) => a.filter((t) => e.planet === t.planet).length));
		case "pairedFigures": return a.filter((e) => e.kind === "orbiter" && a.some((t) => t.kind === "lander" && t.planet === e.planet)).length;
		case "tech": return i.techs.filter((e) => !r.target || I(e).family === r.target).length;
		case "trace": return r.target === "same" ? Math.max(...[
			"red",
			"yellow",
			"blue"
		].map((t) => e.species.reduce((e, n) => e + s(n, t), 0))) : e.species.reduce((e, t) => e + s(t, r.color), 0);
		case "speciesTrace": return e.species.filter((e) => r.target === "other" ? e.id !== "exertians" : e.id === r.target).reduce((e, t) => e + s(t, r.color), 0);
		case "traceSpecies": return e.species.filter((e) => s(e, r.color) > 0).length;
		case "traceSet": return e.species.filter((e) => (!r.target || e.id === r.target) && [
			"red",
			"yellow",
			"blue"
		].every((t) => s(e, t) > 0)).length;
		case "wins": {
			let t = e.sectors.filter((e) => !r.target || r.target === "same" || e.id === r.target || e.color === r.target).map((e) => e.winners.filter((e) => e === n).length);
			return r.target === "same" ? Math.max(0, ...t) : t.reduce((e, t) => e + t, 0);
		}
		case "income": return i.income.filter((e) => !r.target || F(e.id).income === r.target).length;
		case "mission": return i.missions.filter((e) => e.circles.length === F(e.card.id).mission?.rewards.length).length;
		case "endgame": return i.played.filter((e) => F(e.id).score || e.id === 113).length;
		case "hand": return t.hand.filter((e) => !r.target || F(e.id).income === r.target).length;
		case "resource": return i[r.target];
		case "fossil": return i.fossil;
		case "signalSectors": return e.sectors.filter((e) => e.signals.includes(n)).length;
		case "probeTerrain": return o.filter((t) => {
			let n = V(e.angles, t);
			return r.target === "earthAsteroid" ? n.asteroid && Te(H(e.angles, "earth")).some((e) => e.ring === t.ring && e.sector === t.sector) : r.target === "asteroid" ? n.asteroid : n.comet;
		}).length;
		case "distantProbe": {
			let t = [{
				...H(e.angles, "earth"),
				cost: 0
			}], n = /* @__PURE__ */ new Map();
			for (let e = 0; e < t.length; e++) {
				let r = t[e], i = `${r.ring}:${r.sector}`;
				n.has(i) || (n.set(i, r.cost), t.push(...Te(r).filter((e) => !n.has(`${e.ring}:${e.sector}`)).map((e) => ({
					...e,
					cost: r.cost + 1
				}))));
			}
			return Math.max(0, ...o.map((e) => n.get(`${e.ring}:${e.sector}`) ?? 0));
		}
		case "sampleDelivery": return o.filter((t) => t.sample && V(e.angles, t).planet === r.target).length;
		case "oumuamuaSignal": return Number(e.species.some((e) => e.id === "oumuamua" && e.signals.includes(n)));
		case "fossilResearch": return Number(e.species.some((e) => e.id === "oumuamua" && e.research.some((e) => e.fossil && e.owners.includes(n))));
		default: return 0;
	}
}
function On(e, t, n, r) {
	let i = Dn(e, t, n, r.metric), a = Math.min(+(r.atMost === void 0 || i <= r.atMost), r.atLeast === void 0 ? 1 : Math.min(1, i / r.atLeast));
	return Math.min(a, ...r.all?.map((r) => On(e, t, n, r)) ?? [1]);
}
function kn(e, t, n, r) {
	let i = Dn(e, t, n, r.metric);
	return (r.minimum === void 0 ? i : Number(i >= r.minimum)) * r.multiplier;
}
function An(e, t, n, r, i) {
	let a = e.players.find((e) => e.rid === n), o = (r, i, a) => Dn(e, t, n, {
		kind: r,
		target: i,
		color: a
	}), s = [
		Math.min(o("tech", "probe"), o("tech", "telescope"), o("tech", "computer")),
		Math.floor(a.techs.length / 2),
		o("mission"),
		Math.floor((o("mission") + o("endgame")) / 2),
		Math.min(o("income", "credit"), o("income", "energy"), o("income", "card")),
		Math.max(o("income", "credit"), o("income", "energy")),
		Math.min(o("trace", void 0, "red"), o("trace", void 0, "yellow"), o("trace", void 0, "blue")),
		Math.min(o("wins"), o("figure"))
	], c = [
		[
			11,
			8,
			5
		],
		[
			7,
			5,
			3
		],
		[
			4,
			3,
			2
		],
		[
			8,
			6,
			4
		],
		[
			11,
			8,
			5
		],
		[
			5,
			4,
			3
		],
		[
			8,
			6,
			4
		],
		[
			8,
			6,
			4
		]
	], l = r * 2 + e.goldFaces[r];
	return s[l] * c[l][Math.min(2, i)];
}
//#endregion
//#region src/games/seti/bot-objectives.ts
var jn = (e) => e.reduce((e, t) => e + (t.kind === "gain" ? t.n * {
	vp: 1,
	credit: 1.25,
	energy: 1.35,
	publicity: .65,
	data: 1.4
}[t.resource] : t.kind === "draw" ? t.n * 1.6 : t.kind === "trace" || t.kind === "research" ? 4 : t.kind === "income" ? 2 : t.kind === "move" ? t.n * .6 : 0), 0);
function Mn(e, t, n) {
	let r = e.players.find((e) => e.rid === n), i = /* @__PURE__ */ new Map(), a = (t) => t >= 1 ? 1 : t ** 2 * (e.round === 5 ? .2 : .55), o = (e, i) => {
		let o = i.played.reduce((r, i) => r + (F(i.id).score ? kn(e, t, n, F(i.id).score) : 0), 0);
		o += i.gold.reduce((r, a, o) => r + An(e, t, n, a, i.goldRates[o]), 0);
		for (let i of r.missions) {
			let r = F(i.card.id).mission;
			r.condition && !i.circles.length && (o += jn(r.rewards[0]) * a(On(e, t, n, r.condition)));
		}
		for (let r of t.secretPlayed) {
			let i = se[r.id - 2001];
			o += i.vp * a(On(e, t, n, i.condition));
		}
		return o;
	}, s = o(e, r), c = r.played.some((e) => F(e.id).score) || r.gold.length || r.missions.length || t.secretPlayed.length;
	return {
		delta: (a) => {
			if (!c) return 0;
			let l = JSON.stringify(a), u = i.get(l);
			if (u !== void 0) return u;
			let d = { ...r }, f = {
				...e,
				players: e.players.map((e) => e.rid === n ? d : e)
			};
			a.tech && (d.techs = [...r.techs, a.tech]), a.income && (d.income = [...r.income, a.income]), a.figure && (f.figures = [...e.figures, a.figure]), a.fossil && (d.fossil += a.fossil), a.trace && (f.species = e.species.map((e, t) => t === a.trace.species ? {
				...e,
				overflow: [...e.overflow, n],
				overflowColors: [...e.overflowColors, a.trace.color]
			} : e)), (a.signal !== void 0 || a.win !== void 0) && (f.sectors = e.sectors.map((e, t) => t === a.win ? {
				...e,
				winners: [...e.winners, n]
			} : t === a.signal ? {
				...e,
				signals: [...e.signals, n]
			} : e)), d.missions = r.missions.map((e) => {
				let r = F(e.card.id).mission;
				return r.condition && !e.circles.length && On(f, t, n, r.condition) === 1 ? {
					...e,
					circles: r.rewards.map((e, t) => t)
				} : e;
			});
			let p = 0;
			for (let e of r.missions) {
				let t = F(e.card.id).mission;
				for (let n of a.events ?? []) {
					let r = (e) => e.kind === n.kind && (!e.target || e.target === n.target || e.kind === "visit" && e.target === "planet" && n.target !== "asteroid" && n.target !== "comet"), i = t.events ? t.events.findIndex((t, n) => !e.circles.includes(n) && r(t)) : t.event && r(t.event) ? e.circles.length : -1;
					i >= 0 && i < t.rewards.length && (p += jn(t.rewards[i]));
				}
			}
			let m = o(f, d) - s + p;
			return i.set(l, m), m;
		},
		dangerCost: (i) => {
			if (!i || !e.species.some((e) => e.id === "exertians")) return 0;
			let a = r.danger + t.secretPlayed.reduce((e, t) => e + F(t.id).danger, 0), o = (t) => e.players.filter((e) => e.rid !== n).reduce((e, n) => {
				let r = n.danger, i = r + n.secretPlayedCount * 9;
				return e * (i === r ? Number(t >= r) : Math.min(1, Math.max(0, (t - r + 1) / (i - r + 1))));
			}, 1), s = r.vp + r.played.reduce((r, i) => r + (F(i.id).score ? kn(e, t, n, F(i.id).score) : 0), 0) + r.gold.reduce((i, a, o) => i + An(e, t, n, a, r.goldRates[o]), 0);
			return (o(a + i) - o(a)) * Math.floor(s / 10);
		}
	};
}
//#endregion
//#region src/games/seti/bot.ts
var Nn = {
	credit: 1.25,
	energy: 1.35,
	publicity: .65,
	data: 1.4,
	shortage: 2.5,
	hand: .65,
	future: .65,
	combo: 1,
	joint: 1,
	allocation: 1,
	prepWeight: 1.3,
	links: 1,
	route: .12
};
function Pn(e = {}) {
	let t = {
		...Nn,
		...e
	};
	return (e, n) => {
		let r = e.private?.choices ?? [];
		if (!r.length || !e.private) return null;
		let i = e.public, a = e.private.hand, o = ve.filter((e) => e.id !== "oumuamua" || i.species.some((e) => e.id === "oumuamua")), s = i.players.find((e) => e.rid === n.rid), c = Mn(i, e.private, n.rid), l = 5 - i.round, u = (e) => F(e.id).corner ?? (F(e.id).free === "move" ? [{
			kind: "move",
			n: 1
		}] : [{
			kind: "gain",
			resource: F(e.id).free,
			n: 1
		}]), d = n.memory, f = d?.active === i.active && i.phase === "playing" && (i.stage !== "before" || i.effect) ? {
			...d,
			sectors: [...d.sectors],
			visited: [...d.visited]
		} : {
			active: i.active,
			sectors: [],
			visited: []
		}, p = {
			credit: s.credit,
			energy: s.energy,
			publicity: s.publicity,
			data: s.data
		}, m = i.probes.filter((e) => e.owner === s.rid && !e.sample), h = (e) => V(i.angles, e, i.species.some((e) => e.id === "oumuamua")), g = (e) => s.missions.some((t) => t.card.id === e && t.circles.length < (F(e).mission?.rewards.length ?? 0)), _ = /* @__PURE__ */ new Map(), v = (e) => {
			let n = _.get(e);
			if (n !== void 0) return n;
			let r = Math.max(3, ...i.species.flatMap((n, r) => [
				"red",
				"yellow",
				"blue"
			].filter((t, n) => e === "any" || e === n).flatMap((e) => {
				let i = c.delta({
					trace: {
						species: r,
						color: e
					},
					events: [{
						kind: "trace",
						target: e
					}]
				}), a = [3 + i];
				n.traces[[
					"red",
					"yellow",
					"blue"
				].indexOf(e)] || a.push((r === 0 ? 5 : 3) + y("publicity", 1) + i);
				for (let r of n.research) if (r.color === e && (!r.owners.length || r.repeat) && r.cost <= s.data && (r.fossil ?? 0) <= s.fossil) {
					let e = r.reward.reduce((e, t) => e + (t.kind === "gain" ? y(t.resource, t.n) : t.kind === "draw" ? t.n * 1.6 : t.op === "draw" ? 2 : t.op === "fossil" ? (t.n ?? 1) * 1.5 : 0), 0);
					a.push(e - r.cost * t.data - (r.fossil ?? 0) * 1.2 - c.dangerCost(r.danger ?? 0) + i);
				}
				return a;
			})));
			return _.set(e, r), r;
		}, ee = (e, n) => {
			if (e === "data") return t.data + (s.computer >= 4 && s.computer < 6 ? .3 : 0);
			let r = n <= 2 ? 1.3 : n > 6 ? .55 : 1;
			return t[e] * r;
		}, y = (e, t, n = p) => {
			if (e === "vp") return t;
			let r = e === "data" ? 6 : e === "publicity" ? 10 : Infinity, i = 0;
			if (t >= 0) for (let a = 1; a <= Math.min(t, r - n[e]); a++) i += ee(e, n[e] + a);
			else for (let r = 0; r < -t; r++) i -= ee(e, n[e] - r);
			return i;
		}, te = (e) => {
			let t = h(e), n = t.planet && t.planet !== "earth" || t.comet || t.asteroid && s.techs.includes("p1") ? y("publicity", 1) : 0;
			for (let e of [
				t.planet,
				t.asteroid ? "asteroid" : void 0,
				t.comet ? "comet" : void 0
			]) e && (n += c.delta({ events: [{
				kind: "visit",
				target: e
			}] }));
			return n;
		}, b = () => ({
			rows: i.sectors.map((e) => e.signals),
			data: s.data
		}), x = (e, t = b()) => {
			let n = {
				...i.sectors[e],
				signals: t.rows[e]
			}, r = (n.winners.length === 0 ? n.firstVP : n.laterVP) + (n.winners.length === 0 || [
				"sirius",
				"proxima",
				"virginis",
				"pictoris"
			].includes(n.id) ? v(0) : 0) + c.delta({ win: e }), a = (e) => {
				let t = e.filter((e) => e === s.rid).length;
				if (!t) return 0;
				let a = i.players.filter((e) => e.rid !== s.rid).map((t) => ({
					rid: t.rid,
					count: e.filter((e) => e === t.rid).length
				})), o = Math.max(0, ...a.map((e) => e.count)), c = Math.max(-1, ...a.filter((e) => e.count === o).map((t) => e.lastIndexOf(t.rid))), l = t > o || t === o && e.lastIndexOf(s.rid) > c;
				if (e.length >= n.capacity) return l ? r : 0;
				let u = l ? .55 + .1 * Math.min(2, t - o) : Math.max(.05, .3 - (o - t) * .1);
				return r * u * e.length / n.capacity;
			};
			return (n.signals.length < n.capacity ? y("data", 1, {
				...p,
				data: t.data
			}) + (n.signals.length === 1 ? 2 : 0) : 0) + a([...n.signals, s.rid]) - a(n.signals) + (n.signals.length + 1 === n.capacity && !n.signals.includes(s.rid) ? y("publicity", 1) : 0) + (t.rows[e].includes(s.rid) ? 0 : c.delta({ signal: e }));
		}, S = (e, t) => ({
			rows: e.rows.map((e, n) => n === t ? [...e, s.rid] : e),
			data: Math.min(6, e.data + Number(e.rows[t].length < i.sectors[t].capacity))
		}), C = (e) => i.sectors.flatMap((t, n) => t.color === F(e.id).color ? [n] : []), w = (e, t, n, r = [], i = !1) => !e || !n.length ? i && r.length === 3 ? new Set(r).size * 2 : 0 : Math.max(0, ...n.flatMap((a) => C(a).map((o) => x(o, t) + w(e - 1, S(t, o), n.filter((e) => e.uid !== a.uid), [...r, o], i)))), T = (e, t, n = a, r = i.market) => {
			if (!e.length) return 0;
			let [o, ...c] = e, l = (e, i = n, a = r) => x(e, t) + T(c, S(t, e), i, a);
			if (o === "earth") {
				let e = H(i.angles, "earth").sector;
				return Math.max(...(s.techs.includes("t0") ? [
					R(e - 1),
					e,
					R(e + 1)
				] : [e]).map((e) => l(e)));
			}
			if (o === "row") return r.length ? Math.max(...r.flatMap((e) => C(e).map((t) => l(t, n, r.filter((t) => t.uid !== e.uid))))) : T(c, t, n, r);
			let u = T(c, t, n, r);
			return o === "mercury" && s.publicity ? Math.max(u, l(H(i.angles, "mercury").sector) + y("publicity", -1)) : o === "hand" ? Math.max(u, ...n.flatMap((e) => C(e).map((t) => l(t, n.filter((t) => t.uid !== e.uid)) - z(e)))) : u;
		}, E = () => [
			"earth",
			"row",
			...s.techs.includes("t1") ? ["hand"] : [],
			...s.techs.includes("t2") ? ["mercury"] : []
		], ne = () => Math.max(0, ...i.market.flatMap((e) => i.sectors.flatMap((t, n) => t.color === F(e.id).color ? [x(n)] : []))), D = (e = p, n = a, r = i.market) => {
			if (t.joint) {
				let t = T(E().filter((t) => t !== "mercury" || e.publicity > 0), {
					...b(),
					data: e.data
				}, n, r);
				return g(101) && (t += Math.max(...s.missions.filter((e) => e.card.id === 101).flatMap((e) => [
					1,
					0,
					2
				].filter((t, n) => !e.circles.includes(n)).map((e) => Math.max(0, ...i.sectors.flatMap((t, n) => t.color === [
					"red",
					"yellow",
					"blue"
				][e] ? [x(n)] : [])))))), s.techs.includes("t3") && (t += m.length ? 1 : 2), t + c.delta({ events: [{ kind: "scan" }] });
			}
			let o = H(i.angles, "earth").sector, l = s.techs.includes("t0") ? [
				R(o - 1),
				o,
				R(o + 1)
			] : [o], u = Math.max(...l.map((e) => x(e))) + ne();
			return g(101) && (u += Math.max(...s.missions.filter((e) => e.card.id === 101).flatMap((e) => [
				1,
				0,
				2
			].filter((t, n) => !e.circles.includes(n)).map((e) => Math.max(0, ...i.sectors.flatMap((t, n) => t.color === [
				"red",
				"yellow",
				"blue"
			][e] ? [x(n)] : [])))))), s.techs.includes("t2") && s.publicity && (u += Math.max(0, x(H(i.angles, "mercury").sector) + y("publicity", -1))), s.techs.includes("t1") && a.length > 1 && (u += Math.max(0, ne() - 1.5)), s.techs.includes("t3") && (u += m.length ? 1 : 2), u + c.delta({ events: [{ kind: "scan" }] });
		}, re = /* @__PURE__ */ new Map(), O = (e) => {
			let t = re.get(e);
			if (t !== void 0) return t;
			let n = I(e), r = i.techMarket.find((t) => t.id === e);
			if (!r.count || s.techs.includes(e)) return -100;
			let o = (r.first ? 2 : 0) + (r.reward === "vp" ? 3 : r.reward === "pickCard" ? 2 : r.reward ? y(r.reward, 1) : 0), u = 0;
			n.family === "computer" && (u += (s.computer < 6 ? 2 : 0) + (e === "c0" ? y("publicity", 2) : e === "c1" ? 2 : y(e === "c2" ? "energy" : "credit", 1)) * .7), e === "t0" && (u += y("data", 2) + .7), e === "t1" && (u += a.length > 2 ? 1 : .3), e === "t2" && (u += s.publicity > 2 ? 1.2 : .3), e === "t3" && (u += 1.5), e === "p0" && (u += m.length < 2 ? 2.5 : .5), e === "p1" && (u += m.some((e) => h(e).asteroid) ? 2.5 : .5), e === "p2" && (u += m.length ? y("energy", 1) : .3), e === "p3" && (u += m.some((e) => e.ring >= 2) ? 3.5 : .5);
			let d = o + u * (.6 + l * .1) + c.delta({
				tech: e,
				events: [{
					kind: "research",
					target: n.family
				}]
			});
			return re.set(e, d), d;
		}, k = (e = "any") => Math.max(0, ...i.techMarket.filter((t) => e === "any" || e === "space" && I(t.id).family !== "computer" || I(t.id).family === e).map((e) => O(e.id))), A = (e) => {
			let n = F(e.id).income, r = s.income.filter((e) => F(e.id).income === n).length;
			if (i.players.length === 3) return (n === "card" ? 1.6 : y(n, 1)) * (1 + l * .4) + c.delta({ income: e });
			let a = (n === "card" ? 1.1 : n === "vp" ? 1 : t[n] * (n === "credit" ? 1.1 : 1)) / (1 + r * .3);
			return (n === "card" ? 1.6 : y(n, 1)) + l * .5 * a + c.delta({ income: e });
		}, j = (e) => {
			let t = i.probes.find((t) => t.uid === e);
			return Number(!!h(t).asteroid) * 2 + Te(t).filter((e) => h(e).asteroid).length;
		}, M = (n) => {
			if (n === 11) return 1.6 + (i.deckCount ? 1.2 : 0);
			if (n === 13) return m.some((e) => {
				let t = h(e).planet;
				return t === "mercury" || t === "mars" || s.techs.includes("p3") && o.some((e) => e.id === t && e.moons.length);
			}) ? 4 : 0;
			if (n === 17) return Math.max(0, ...i.probes.filter((e) => e.owner === s.rid).map((e) => y("data", j(e.uid))));
			if (n === 19 || n === 26) return m.length ? 1.2 : 0;
			if (n === 45 || n === 46 || n === 47) return i.sectors.some((e) => e.signals.length >= e.capacity - 2) ? n === 46 ? 1.6 : y(n === 45 ? "energy" : "data", 1) : 0;
			if (n === 72) return i.players.some((e) => e.rid !== s.rid && e.techs.some((e) => !s.techs.includes(e))) ? y("publicity", 2) : 0;
			if (n === 73) return N(i.market.flatMap(u));
			if (n === 74) return a.filter((e) => F(e.id).free === "move").length * t.energy * .6;
			if (n === 75) return Math.max(...[
				0,
				1,
				2
			].map((t) => v(t) + Dn(i, e.private, s.rid, {
				kind: "trace",
				color: [
					"red",
					"yellow",
					"blue"
				][t]
			}) + 1));
			if (n === 91 || n === 92 || n === 93) {
				let e = a.find((e) => e.id === n);
				return e ? A(e) : 0;
			}
			return n === 102 ? v("any") : n === 120 ? .5 : n === 122 ? ne() : 0;
		}, N = (n) => n.reduce((n, r) => r.kind === "gain" ? n + y(r.resource, r.n) : r.kind === "trace" ? n + v(r.color === "any" ? "any" : [
			"red",
			"yellow",
			"blue"
		].indexOf(r.color)) : r.kind === "draw" || r.kind === "pickCard" ? n + 1.6 * ("n" in r ? r.n : 1) : r.kind === "income" ? n + (a.length ? Math.max(0, ...a.map((e) => A(e) - t.hand)) : 0) : r.kind === "rowSignals" || r.kind === "signal" ? n + ne() * ("n" in r ? r.n : 1) : r.kind === "research" ? n + k(r.family) : r.kind === "scan" ? n + D() : r.kind === "targetSignal" ? n + r.n * Math.max(0, ...i.sectors.flatMap((e, t) => r.target === "any" || r.target === e.color || r.target === e.id || m.some((e) => e.sector === t) ? [x(t)] : [])) : r.kind === "move" ? n + (i.probes.some((e) => e.owner === s.rid) ? r.n * t.energy * .7 : 0) : r.kind === "launch" ? n + (m.length < (s.techs.includes("p0") ? 2 : 1) || r.ignoreLimit ? 3 + c.delta({ events: [{ kind: "launch" }] }) : 0) : r.kind === "land" ? n + Math.max(0, ...m.flatMap((e) => {
			let t = V(i.angles, e, i.species.some((e) => e.id === "oumuamua")).planet, n = o.find((e) => e.id === t);
			return n ? [n.vp + (t === "oumuamua" ? 2.4 : v(1))] : [];
		})) : r.kind === "metricGain" ? n + y(r.resource, Dn(i, e.private, s.rid, r.metric) * r.multiplier) : r.kind === "if" ? n + N(r.effects) * On(i, e.private, s.rid, r.condition) : r.kind === "choose" ? n + Math.max(...r.options.map((e) => N(e.effects))) : r.kind === "project" ? n + M(r.id) : r.kind === "alien" ? n + (r.op === "fossil" ? (r.n ?? 1) * 1.5 : r.op === "draw" ? 2 : r.op === "spendFossil" ? -(r.n ?? 1) * 1.5 : [
			"collect",
			"inspectHere",
			"inspectAny",
			"nextAnomaly"
		].includes(r.op) ? 3 : r.op === "takeRow" ? 4.8 : r.op === "drawThree" ? 5 : 0) : n, 0), P = (e, t, n) => {
			let r = o.find((t) => t.id === e);
			return (t === "planet" ? r.vp + (n < 0 ? 0 : y("data", r.first[n])) + (e === "oumuamua" ? 3 : v(1)) : N(r.moons.find((e) => e.id === t).effects)) + c.delta({
				figure: {
					uid: "future-lander",
					owner: s.rid,
					planet: r.id,
					moon: t === "planet" ? null : t,
					slot: n,
					kind: "lander"
				},
				events: [{
					kind: "land",
					target: t === "planet" ? e : t
				}]
			});
		}, ie = /* @__PURE__ */ new Map(), ae = (e) => {
			let t = ie.get(e);
			if (t) return t;
			let n = o.find((t) => t.id === e), r = i.figures.filter((t) => t.planet === e), a = !r.some((e) => e.kind === "orbiter" && e.slot === 0), l = [{
				id: "orbit",
				value: (a ? 3 : 0) + N(n.orbit) + c.delta({
					figure: {
						uid: "future-orbiter",
						owner: s.rid,
						planet: n.id,
						moon: null,
						slot: a ? 0 : null,
						kind: "orbiter"
					},
					events: [{
						kind: "orbit",
						target: e
					}]
				}),
				credit: 1,
				energy: 1
			}], u = 3 - Number(r.some((e) => e.kind === "orbiter")) - Number(s.techs.includes("p2")), d = n.first.flatMap((e, t) => r.some((e) => e.kind === "lander" && !e.moon && e.slot === t) ? [] : [t]);
			d.length || d.push(-1);
			for (let t of d) l.push({
				id: `mainLand:planet:${t}`,
				value: P(e, "planet", t),
				energy: u
			});
			if (s.techs.includes("p3")) for (let t of n.moons) r.some((e) => e.kind === "lander" && e.moon === t.id) || l.push({
				id: `mainLand:${t.id}:0`,
				value: P(e, t.id, 0),
				energy: u
			});
			return ie.set(e, l), l;
		}, oe = /* @__PURE__ */ new Map(), ce = (e) => {
			let t = `${e.ring}:${e.sector}`;
			if (oe.has(t)) return oe.get(t);
			let n = /* @__PURE__ */ new Map([[`${e.ring}:${e.sector}`, {
				cost: 0,
				path: []
			}]]), r = [e];
			for (; r.length;) {
				r.sort((e, t) => n.get(`${e.ring}:${e.sector}`).cost - n.get(`${t.ring}:${t.sector}`).cost);
				let e = r.shift(), t = n.get(`${e.ring}:${e.sector}`), i = h(e).asteroid && !s.techs.includes("p1") ? 2 : 1;
				for (let a of Te(e)) {
					let e = `${a.ring}:${a.sector}`;
					(n.get(e)?.cost ?? Infinity) <= t.cost + i || (n.set(e, {
						cost: t.cost + i,
						path: [...t.path, a]
					}), r.push(a));
				}
			}
			return oe.set(t, n), n;
		}, le = (e) => {
			let n = ce(e);
			return o.flatMap((r) => {
				let a = H(i.angles, r.id), o = n.get(`${a.ring}:${a.sector}`), s = new Set(o.path.flatMap((e) => {
					let t = h(e).planet;
					return t && !f.visited.includes(t) ? [t] : [];
				}));
				return ae(r.id).map((n) => ({
					...n,
					id: n.id === "orbit" ? `orbit:${e.uid}` : n.id.replace("mainLand:", `mainLand:${e.uid}:`),
					value: n.value + (o.path.length ? te(a) : 0) - o.path.length * t.route + (f.mainCard === 25 ? s.size : 0),
					energy: (n.energy ?? 0) + o.cost,
					probe: e.uid,
					path: o.path,
					travel: o.cost
				}));
			});
		}, ue = (e, n) => {
			let r = [];
			for (let a of n.filter((e) => e.id === 16)) {
				let n = ce(e);
				for (let c of o) {
					let o = H(i.angles, c.id), l = n.get(`${o.ring}:${o.sector}`), u = [...c.first.map((e, t) => ({
						moon: "planet",
						slot: t
					})), ...s.techs.includes("p3") ? c.moons.map((e) => ({
						moon: e.id,
						slot: 0
					})) : []];
					for (let n of u) r.push({
						id: `play:${a.uid}`,
						card: a.uid,
						probe: e.uid,
						path: l.path,
						travel: l.cost,
						energy: l.cost,
						credit: F(a.id).cost,
						value: P(c.id, n.moon, n.slot) + (l.path.length ? te(o) : 0) - l.path.length * t.route
					});
				}
			}
			return r;
		}, de = (e) => [
			y("credit", 2),
			y("energy", 2),
			y("publicity", 3),
			y("data", 2),
			3.2,
			4.6,
			7
		][e], fe = i.probes.filter((e) => e.owner === s.rid && e.sample).flatMap((n) => {
			let r = e.private.samples.find((e) => e.uid === n.uid), a = ce(n);
			return s.missions.flatMap((e) => {
				let o = F(e.card.id).mission;
				if (e.circles.length || o?.condition?.metric.kind !== "sampleDelivery") return [];
				let s = H(i.angles, o.condition.metric.target), c = a.get(`${s.ring}:${s.sector}`), l = o.rewards[0].find((e) => e.kind === "alien" && e.op === "deliver");
				return [{
					id: `free:mission:${e.card.uid}`,
					probe: n.uid,
					path: c.path,
					travel: c.cost,
					energy: c.cost,
					value: de(r.sample) * (l?.kind === "alien" ? l.n ?? 1 : 1) + N(o.rewards[0]) - c.path.length * t.route
				}];
			});
		}), pe = [...m.flatMap((e) => le(e)), ...fe], me = /* @__PURE__ */ new Map(), he = (e = a) => {
			if (!t.links) return pe;
			let n = e.map((e) => e.uid).sort().join(",");
			if (me.has(n)) return me.get(n);
			let r = [...pe];
			if (i.stage === "before") for (let t of m) r.push(...ue(t, e));
			return me.set(n, r), r;
		}, L = (e, t = 0) => (e.energy ?? 0) - Math.min(t, e.travel ?? 0), ge = (e = p, n = a) => {
			if (m.length >= (s.techs.includes("p0") ? 2 : 1)) return 0;
			let r = {
				...H(i.angles, "earth"),
				uid: "launch"
			};
			if (!t.links) return Math.max(0, ...le(r).filter((e) => (e.energy ?? 0) <= s.energy && (e.credit ?? 0) + 2 <= s.credit).map((e) => (e.value + y("energy", -(e.energy ?? 0)) + y("credit", -(e.credit ?? 0))) * t.future));
			let o = {
				...e,
				credit: Math.max(0, e.credit - 2)
			}, l = [...le(r), ...ue(r, n)];
			return Math.max(0, ...l.filter((t) => (t.energy ?? 0) <= e.energy && (t.credit ?? 0) + 2 <= e.credit).map((e) => (e.value + y("energy", -(e.energy ?? 0), o) + y("credit", -(e.credit ?? 0), o) - (e.card ? t.hand : 0)) * t.future)) + c.delta({ events: [{ kind: "launch" }] });
		}, _e = (n, r, a) => {
			let c = F(n.id);
			if (n.id === 1) return g(1) ? 0 : Math.max(0, ...pe.filter((e) => e.path?.length && e.path.length <= 3).map((e) => {
				let t = h(e.path[e.path.length - 1]).planet;
				return t === "jupiter" ? y("data", 1) : t === "saturn" ? 4 : 0;
			})) * t.future;
			if (n.id === 15) return i.figures.some((e) => e.owner === s.rid && e.kind === "orbiter") ? 3 + y("data", 1) + 1.6 : 0;
			if (n.id === 16) return Math.max(0, ...m.flatMap((e) => {
				let t = h(e).planet, n = o.find((e) => e.id === t);
				return n ? [...n.first.map((e, t) => P(n.id, "planet", t)), ...s.techs.includes("p3") ? n.moons.map((e) => P(n.id, e.id, 0)) : []] : [];
			}));
			if (n.id === 25 || n.id === 125) {
				let e = n.id === 25 ? 4 : 1, i = Math.max(0, ...pe.filter((t) => t.path?.length && L(t, e) <= r.energy && (t.credit ?? 0) <= r.credit - c.cost).map((n) => Math.min(e, n.travel ?? 0) * t.energy));
				return i + (n.id === 25 && i ? 2 : n.id === 125 && m.length ? 3 + y("publicity", 1) : 0);
			}
			if (n.id === 50) return t.joint ? w(3, {
				...b(),
				data: r.data
			}, a, [], !0) : ne() * 3 + 5;
			if (n.id === 71) return k() + 2 * (1 + Math.max(0, ...[
				"probe",
				"telescope",
				"computer"
			].map((e) => s.techs.filter((t) => I(t).family === e).length)));
			if (n.id === 84) return i.figures.some((e) => e.owner === s.rid && e.kind === "lander") ? v(1) : 0;
			if (n.id === 101) return g(101) ? 0 : Math.min(3, (r.energy + 1) / 2) * ne() * t.future;
			if (n.id === 119) return k("computer") + r.publicity;
			if (n.id === 133) {
				if (m.length >= (s.techs.includes("p0") ? 2 : 1)) return 0;
				let e = H(i.angles, "earth"), n = 0;
				for (let t = 2; t <= 4; t++) {
					let r = h({
						ring: t,
						sector: e.sector
					});
					(r.planet || r.comet) && n++;
				}
				return ge() + n * t.energy;
			}
			let l = c.mission ? c.mission.condition ? N(c.mission.rewards[0]) * (.25 + .75 * On(i, e.private, s.rid, c.mission.condition)) : c.mission.rewards.reduce((e, t) => e + N(t), 0) * Math.max(.1, (6 - i.round) * .12) : 0, u = c.score ? kn(i, e.private, s.rid, c.score) : c.keep ? Math.max(0, ...i.gold.map((t, n) => s.gold.includes(n) ? 0 : An(i, e.private, s.rid, n, 2))) : 0;
			return N(c.effects) + l + u + (c.energyCost ? 2 : 0);
		}, ye = /* @__PURE__ */ new Map(), be = (e, t = p, n = i.market) => {
			let r = `${e.id}:${Object.values(t).join(",")}:${n.map((e) => e.uid).join(",")}`;
			return ye.has(r) || (ye.set(r, 0), ye.set(r, _e(e, t, n))), ye.get(r);
		}, xe = /* @__PURE__ */ new Map(), z = (e) => {
			if (!xe.has(e.uid)) {
				let n = F(e.id), r = n.energyCost ? "energy" : "credit", i = l || p[r] >= n.cost ? 1 : .25;
				xe.set(e.uid, t.hand), xe.set(e.uid, t.hand * (l ? 1 : .7) + Math.max(0, be(e) + y(r, -n.cost)) * .23 * i);
			}
			return xe.get(e.uid);
		}, B = (t) => [
			...a,
			...e.private.roundCards,
			...e.private.secret,
			...e.private.secretPlayed,
			...i.market,
			...i.species.flatMap((e) => e.market),
			...s.income,
			...s.played,
			...s.missions.map((e) => e.card)
		].find((e) => e.uid === t), Se = ge(), Ce = k(), we = (e = p, n = a, r = i.market) => [
			...he(n),
			...n.map((t) => ({
				id: `play:${t.uid}`,
				value: be(t, e, r),
				...F(t.id).energyCost ? { energy: F(t.id).cost } : { credit: F(t.id).cost },
				card: t.uid
			})),
			{
				id: "main:scan",
				value: D(e, n, r),
				credit: 1,
				energy: 2
			},
			{
				id: "main:research",
				value: Ce,
				publicity: 6
			},
			...s.computer === 6 ? [{
				id: "main:analyze",
				value: v(2),
				energy: 1
			}] : [],
			{
				id: "main:launch",
				value: t.links ? ge(e, n) : Se,
				credit: 2
			}
		], Ee = we(), U = (e, n = p, r = a, i = 0) => {
			if (e.card && !r.some((t) => t.uid === e.card)) return -100;
			let o = e.value - (e.card ? z(r.find((t) => t.uid === e.card)) : 0) - .15;
			for (let r of [
				"credit",
				"energy",
				"publicity"
			]) {
				let a = r === "energy" ? L(e, i) : e[r] ?? 0;
				o += y(r, -a, n) - Math.max(0, a - n[r]) * t.shortage;
			}
			return o;
		}, W = /* @__PURE__ */ new Map(), De = (e, n, r = i.market) => {
			let a = `${Object.values(e).join(",")}:${n.map((e) => e.uid).sort().join(",")}:${r.map((e) => e.uid).join(",")}`;
			return W.has(a) || W.set(a, Math.max(0, ...(t.combo ? we(e, n, r) : Ee).map((t) => U(t, e, n)))), W.get(a);
		}, Oe = Math.max(0, ...he().filter((e) => !e.path?.length && L(e) <= s.energy && (e.credit ?? 0) <= s.credit).map((e) => U(e))), ke = De(p, a), Ae = Math.max(0, ...Ee.filter((e) => (e.credit ?? 0) <= s.credit && (e.energy ?? 0) <= s.energy && (e.publicity ?? 0) <= s.publicity).map((e) => U(e))), je = (e) => i.players.length !== 3 && l && i.techMarket.some((e) => e.count && !s.techs.includes(e.id)) ? Math.min(6, e.publicity) * Math.max(0, 3 - s.techs.length) * .15 * Math.min(1, l / 2) : 0, G = (e, t, n = 0) => {
			let r = n - a.filter((e) => !t.some((t) => t.uid === e.uid)).reduce((e, t) => e + z(t), 0);
			for (let t of [
				"credit",
				"energy",
				"publicity",
				"data"
			]) r += y(t, e[t] - p[t]);
			return r += 1.3 * (De(e, t) - ke), r += je(e) - je(p), r > .12 ? Ae + r + .2 : -100;
		}, Me = (e) => {
			if (f.mainCard === 119 && i.effect?.kind === "publicityScore" && e.id.startsWith("free:discard:")) {
				let t = B(e.card);
				return F(t.id).free === "publicity" && s.publicity < 10 ? 1 + y("publicity", 1) + 1 - z(t) : -100;
			}
			if (i.stage !== "before" || i.effect) return -100;
			let n = e.id.split(":"), r = { ...p }, o = a, c = 0;
			if (n[1] === "discard") {
				let e = B(n[2]), i = u(e);
				o = a.filter((t) => t.uid !== e.uid);
				for (let e of i) if (e.kind === "move") {
					let n = Math.max(0, ...he(o).filter((e) => e.path?.length).map((t) => U(t, r, o, e.n)));
					c += t.prepWeight * (n - ke);
				} else e.kind === "gain" && (e.resource === "vp" ? c += e.n : r[e.resource] = Math.min(e.resource === "data" ? 6 : e.resource === "publicity" ? 10 : Infinity, r[e.resource] + e.n));
			} else if (n[1] === "exchange") n[2] === "card" ? o = a.filter((e) => e.uid !== n[4] && e.uid !== n[5]) : r[n[2]] -= 2, n[3] === "card" ? c = Math.max(1, ...i.market.map((e) => z(e))) : r[n[3]]++;
			else if (n[1] === "buy") {
				r.publicity -= 3;
				let e = i.market.find((e) => e.uid === n[2]);
				e ? (o = [...a, e], c = z(e)) : c = 1;
			}
			return G(r, o, c);
		}, Ne = (e) => e.extra + a.filter((t) => !e.cards.some((e) => e.uid === t.uid)).reduce((e, t) => e - z(t), 0) + e.cards.filter((e) => !a.some((t) => t.uid === e.uid)).reduce((e, t) => e + z(t), 0) + [
			"credit",
			"energy",
			"publicity",
			"data"
		].reduce((t, n) => t + y(n, e.funds[n] - p[n]), 0) + je(e.funds) - je(p) + t.prepWeight * (De(e.funds, e.cards, e.market) - ke), Pe = (e) => {
			let t = [], n = (n, r, i = e.cards, a = e.market, o = e.extra) => t.push({
				id: n,
				state: {
					funds: r,
					cards: i,
					market: a,
					extra: o
				}
			}), r = (t, n) => ({
				...e.funds,
				[t]: Math.min(t === "data" ? 6 : t === "publicity" ? 10 : Infinity, e.funds[t] + n)
			});
			for (let t of e.cards) {
				let r = u(t);
				if (r.some((e) => e.kind === "move")) continue;
				let i = { ...e.funds }, a = e.extra;
				for (let e of r) e.kind === "gain" && (e.resource === "vp" ? a += e.n : i[e.resource] = Math.min(e.resource === "data" ? 6 : e.resource === "publicity" ? 10 : Infinity, i[e.resource] + e.n));
				n(`free:discard:${t.uid}`, i, e.cards.filter((e) => e.uid !== t.uid), e.market, a);
			}
			if (e.funds.publicity >= 3) for (let t of e.market) n(`free:buy:${t.uid}`, r("publicity", -3), [...e.cards, t], e.market.filter((e) => e.uid !== t.uid));
			for (let t of [
				"credit",
				"energy",
				"card"
			]) for (let r of [
				"credit",
				"energy",
				"card"
			]) {
				if (t === r && t !== "card") continue;
				let i = (t, i, a = e.cards) => {
					if (r === "card") for (let r of e.market) n(t, i, [...a, r], e.market.filter((e) => e.uid !== r.uid));
					else n(t, {
						...i,
						[r]: i[r] + 1
					}, a);
				};
				if (t === "card") for (let t = 0; t < e.cards.length; t++) for (let n = t + 1; n < e.cards.length; n++) {
					let a = e.cards[t], o = e.cards[n];
					i(`free:exchange:card:${r}:${a.uid}:${o.uid}`, e.funds, e.cards.filter((e) => e !== a && e !== o));
				}
				else e.funds[t] >= 2 && i(`free:exchange:${t}:${r}`, {
					...e.funds,
					[t]: e.funds[t] - 2
				});
			}
			return t;
		}, Fe = /* @__PURE__ */ new Map();
		if (t.combo && i.stage === "before" && !i.effect) {
			let e = {
				funds: p,
				cards: a,
				market: i.market,
				extra: 0
			};
			for (let t of Pe(e)) {
				let e = Ne(t.state);
				for (let n of Pe(t.state)) e = Math.max(e, Ne(n.state) - .08);
				Fe.set(t.id, Math.max(Fe.get(t.id) ?? -100, e > .12 ? Ae + e + .2 : -100));
			}
		}
		let K = (e) => Fe.get(e.id) ?? Me(e), Ie = /* @__PURE__ */ new Map();
		if (t.allocation && s.data) {
			let e = (e, n) => v(2) * (t.future * (e / 6) ** 2 + (e === 6 && n.energy && i.stage === "before" ? 1 - t.future : 0)), n = /* @__PURE__ */ new Map(), r = (e, i, a, s) => {
				let c = `${e}:${i}:${a.join(",")}:${Object.values(s).join(",")}`, l = n.get(c);
				if (l !== void 0) return l;
				let u = e * t.data * .15;
				for (let t of o(e, i, a, s)) u = Math.max(u, t.value + r(e - 1, t.computer, t.lower, t.funds));
				return n.set(c, u), u;
			}, o = (t, n, r, i) => {
				let o = [];
				if (!t) return o;
				if (n < 6) {
					let t = {
						...i,
						publicity: Math.min(10, i.publicity + Number(!s.installed[n] && n === 1))
					}, c = s.installed[n] ? 2 : n === 1 ? y("publicity", 1, i) : n === 3 ? Math.max(0, ...a.map((e) => A(e) - z(e))) : 0;
					o.push({
						id: "free:upper",
						value: c + e(n + 1, t) - e(n, i),
						computer: n + 1,
						lower: r,
						funds: t
					});
				}
				return s.installed.forEach((t, a) => {
					if (!t || a >= n || r.includes(a)) return;
					let s = { ...i }, c = 0;
					for (let e of I(t).lower ?? []) e.kind === "gain" ? (c += y(e.resource, e.n, s), e.resource !== "vp" && (s[e.resource] = Math.min(e.resource === "publicity" ? 10 : e.resource === "data" ? 6 : Infinity, s[e.resource] + e.n))) : c += N([e]);
					o.push({
						id: `free:lower:${a}`,
						value: c + e(n, s) - e(n, i),
						computer: n,
						lower: [...r, a].sort(),
						funds: s
					});
				}), o;
			};
			for (let e of o(s.data, s.computer, s.lower, p)) Ie.set(e.id, e.value > 0 ? 15 + e.value + r(s.data - 1, e.computer, e.lower, e.funds) : -100);
		}
		let Le = (n) => {
			let o = n.id.split(":");
			if (o[0] === "roundCard") return o[1] === "defer" ? -20 : z(B(n.card));
			if (o[0] === "solvay") return An(i, e.private, s.rid, n.n, 2);
			if (o[0] === "alienSecret") {
				if (o[1] === "skip") return 0;
				let t = se[B(n.card).id - 2001], r = On(i, e.private, s.rid, t.condition), a = r === 1 ? 1 : r ** (i.round === 5 ? 4 : 2) * (.35 + l * .15);
				return t.vp * a - c.dangerCost(t.danger);
			}
			if (o[0] === "alienDraw") return o[1] === "deck" ? 1.5 : z(B(n.card));
			if (o[0] === "alienMessageBonus") return [
				v("any"),
				2.8,
				y("publicity", 3),
				8
			][n.n];
			if (o[0] === "targetSignal") return x(n.n);
			if (o[0] === "oumuamua") return 2.5 + (i.species.find((e) => e.id === "oumuamua")?.signals.length === 2 ? 2 : 0);
			if (o[0] === "projectColor") return v(n.n);
			if (o[0] === "projectProbe") return y("data", j(n.card));
			if (o[0] === "projectSpecies") return Math.max(0, ...r.filter((e) => e.species === n.species).map(() => v("any")));
			if (o[0] === "option") return n.params?.resource === "move" ? Math.max(0, ...he().filter((e) => e.path?.length).map((e) => U(e, p, a, Number(n.params?.n ?? 1)) - U(e))) : y(n.params?.resource ?? "vp", Number(n.params?.n ?? 1));
			if (o[0] === "alienDiscard") return -z(B(n.card));
			if (o[0] === "alienSample") return de(n.n);
			if (o[0] === "alienDeliver") return de(e.private.samples.find((e) => e.uid === n.card).sample);
			if (o[0] === "alienOrbit") {
				let e = m.find((e) => e.uid === n.card);
				return ae(h(e).planet).find((e) => e.id === "orbit").value;
			}
			if (o[0] === "alienLand") return Math.max(0, ...m.flatMap((e) => {
				let t = h(e).planet;
				return t && t !== "earth" ? ae(t).filter((e) => e.id !== "orbit").map((e) => e.value) : [];
			}));
			if (o[0] === "alienFossil") {
				if (o[1] === "skip") return 0;
				let e = f.mainCard ?? Number([...i.log].reverse().find((e) => e.owner === s.rid && e.key === "games.seti.log.play")?.params?.n);
				return (e === 1025 ? Math.max(0, ...he().filter((e) => e.path?.length && L(e, 2) <= s.energy).map((e) => U(e, p, a, 2) - U(e))) : e === 1030 ? Math.max(0, ...i.sectors.map((e, t) => x(t))) : y("data", 1)) - (l ? 1.5 : .6) + c.delta({ fossil: -1 });
			}
			if (o[0] === "alienContinue") return 1;
			if (n.group === "response") {
				if (o[0] !== "claim") return 0;
				let e = s.missions.find((e) => e.card.uid === n.card);
				return 30 + N(F(e.card.id).mission.rewards[n.n]);
			}
			if (o[0] === "trace") {
				let e = Number(o[1]), n = i.species[e].research[Number(o[3])], r = n?.color ?? (o[2] === "overflow" ? o[3] : [
					"red",
					"yellow",
					"blue"
				][Number(o[2])]), a = c.delta({
					trace: {
						species: e,
						color: r
					},
					events: [{
						kind: "trace",
						target: r
					}]
				});
				return o[2] === "research" ? N(n.reward) - n.cost * t.data - (n.fossil ?? 0) * 1.2 - c.dangerCost(n.danger ?? 0) + a : (o[2] === "overflow" ? 3 : (e === 0 ? 5 : 3) + y("publicity", 1)) + a;
			}
			if (o[0] === "setup" || o[0] === "income") {
				let e = B(n.card);
				return A(e) - z(e);
			}
			if (t.combo && o[0] === "pick" && o[1] !== "deck" && i.stage === "before") {
				let e = B(n.card);
				return z(e) + t.prepWeight * (De(p, [...a, e], i.market.filter((t) => t.uid !== e.uid)) - ke);
			}
			if (o[0] === "pick") return o[1] === "deck" ? 1.2 : z(B(n.card));
			if (o[0] === "tech") return O(o[1]) + (f.mainCard === 71 ? 2 * s.techs.filter((e) => I(e).family === I(o[1]).family).length : 0);
			if (o[0] === "install") return (n.n >= s.computer ? 3 : 0) - n.n * .1 + (n.n < s.computer && s.data && I(n.tech).lower ? .3 : 0);
			if (o[0] === "gold") return An(i, e.private, s.rid, n.n, i.gold[n.n]);
			if (o[0] === "passDiscard") return -z(B(n.card));
			if (o[0] === "signal" || o[0] === "row" || o[0] === "handSignal") {
				let e = o[0] === "signal" ? n.n : Number(o[2]);
				return t.joint && o[0] === "row" && f.mainCard === 50 ? x(e) + w(Math.max(0, 2 - f.sectors.length), S(b(), e), i.market.filter((e) => e.uid !== n.card), [...f.sectors, e], !0) : t.joint && f.scan && [
					"signal",
					"row",
					"handSignal"
				].includes(o[0]) ? x(e) + T(f.scan, S(b(), e), o[0] === "handSignal" ? a.filter((e) => e.uid !== n.card) : a, o[0] === "row" ? i.market.filter((e) => e.uid !== n.card) : i.market) - (o[0] === "handSignal" ? z(B(n.card)) : 0) : x(e) - (o[0] === "handSignal" ? z(B(n.card)) : 0) + (o[0] === "row" && f.mainCard === 50 && !f.sectors.includes(e) ? 2 : 0);
			}
			if (o[0] === "scan") {
				if (o[1] === "earth" || o[1] === "row") return 10;
				if (t.joint && f.scan && ["hand", "mercury"].includes(o[1])) {
					let e = f.scan.filter((e) => e !== o[1]);
					return T([o[1], ...e], b()) - T(e, b()) - .01;
				}
				return o[1] === "mercury" ? x(H(i.angles, "mercury").sector) + y("publicity", -1) : o[1] === "hand" ? Math.max(-1, ...a.flatMap((e) => i.sectors.flatMap((t, n) => t.color === F(e.id).color ? [x(n) - z(e)] : []))) : m.length ? 1.2 : ge() + y("energy", -1);
			}
			if (o[0] === "land") {
				let e = m.find((e) => e.uid === n.card), t = h(e).planet;
				return P(t, o[2], Number(o[3]));
			}
			if (o[0] === "remove") {
				let e = i.figures.find((e) => e.uid === n.card);
				return e.kind === "orbiter" && e.slot === 0 ? -.5 : 0;
			}
			if (o[0] === "move" || o[0] === "free" && o[1] === "move") {
				let e = o[0] === "free";
				if (e && (i.stage !== "before" || i.effect)) return -100;
				let t = e ? 0 : i.effect?.n ?? 1;
				return Math.max(-100, ...he().filter((e) => e.probe === n.card && e.path?.length && e.path[0].ring === n.target.ring && e.path[0].sector === n.target.sector && L(e, t) <= s.energy && (e.credit ?? 0) <= s.credit).map((n) => U(n, p, a, t) - (e ? 0 : Oe) + (e ? 0 : .2)));
			}
			if (o[0] === "free") {
				if (o[1] === "mission") return 50;
				if (Ie.has(n.id)) return Ie.get(n.id);
				if (o[1] === "upper") return 15 + (s.installed[s.computer] ? 2 : 0) + (s.computer === 5 ? 2 : 0);
				if (o[1] === "lower") {
					let e = N(I(n.tech).lower ?? []);
					return e > .9 ? 15 + e - (s.computer >= 4 && s.computer < 6 ? 2 : 0) : -100;
				}
				return K(n);
			}
			return o[0] === "effect" ? o[1] === "skip" ? i.effect?.kind === "income" ? 0 : -.01 : o[1] === "endScan" ? 0 : o[1] === "launch" ? ge() + y("energy", -1) : o[1] === "scanMove" ? +!!m.length : 1 : n.id === "endTurn" || n.id === "main:pass" ? 0 : n.id === "closing:finish" ? 1 : Math.max(-100, ...Ee.filter((e) => e.id === n.id && !e.path?.length).map((e) => U(e)));
		}, Re = r.map((e) => ({
			c: e,
			score: Le(e)
		}));
		Re.sort((e, t) => t.score - e.score || e.c.id.localeCompare(t.c.id));
		let q = Re[0].c;
		if (q.id === "main:scan" && (f.scan = E()), q.id.startsWith("scan:") && (f.pending = q.id.split(":")[1], f.scan = f.scan?.filter((e) => e !== f.pending)), q.id === "effect:endScan" && (f.scan = void 0), q.id.startsWith("play:") && (f.mainCard = B(q.card).id, f.sectors = [], f.visited = []), q.id.startsWith("row:") && f.sectors.push(Number(q.id.split(":")[2])), q.target && f.mainCard === 25) {
			let e = h(q.target).planet;
			e && !f.visited.includes(e) && f.visited.push(e);
		}
		return (q.id === "endTurn" || q.id === "main:pass") && (f.mainCard = void 0, f.sectors = [], f.visited = []), {
			action: {
				type: "choose",
				id: q.id
			},
			memory: f
		};
	};
}
var Fn = Pn();
//#endregion
//#region src/games/seti/game-over-row.tsx
function In({ public: e, rid: t }) {
	let n = s(), r = e, i = r.finalScores.find((e) => e.owner === t), a = r.revealedSecrets.find((e) => e.owner === t);
	return i ? /* @__PURE__ */ m("div", {
		className: "seti-result",
		children: [/* @__PURE__ */ m("dl", {
			className: "seti-result-breakdown",
			children: [
				/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("dt", { children: n("games.seti.baseScore") }), /* @__PURE__ */ p("dd", { children: i.base })] }),
				/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("dt", { children: n("games.seti.cardScore") }), /* @__PURE__ */ p("dd", { children: i.cards })] }),
				/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("dt", { children: n("games.seti.goldScore") }), /* @__PURE__ */ p("dd", { children: i.gold })] }),
				/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("dt", { children: n("games.seti.alienScore") }), /* @__PURE__ */ p("dd", { children: i.aliens })] }),
				/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("dt", { children: n("games.seti.dangerPenalty") }), /* @__PURE__ */ m("dd", { children: ["−", i.penalty] })] })
			]
		}), !!a?.cards.length && /* @__PURE__ */ m("details", { children: [/* @__PURE__ */ m("summary", { children: [
			n("games.seti.danger"),
			" · ",
			a.danger
		] }), /* @__PURE__ */ p("div", {
			className: "seti-card-row",
			children: a.cards.map((e) => /* @__PURE__ */ p("div", {
				className: "seti-card",
				children: /* @__PURE__ */ p(Cn, {
					id: e.id,
					detailed: !0
				})
			}, e.uid))
		})] })]
	}) : null;
}
//#endregion
//#region .bgparty/cache/pack-entry/seti/entry.tsx
var Ln = {
	definition: Wt,
	View: En,
	bot: Fn,
	RowView: In,
	locales: {
		zh: {
			projects: {
				p1: "先驱者11号任务",
				p1Text: "事件任务（打出本牌后生效；同一事件至多领取一个奖励，每项限一次）：访问（木星）：获得1个数据；访问（土星）：获得4分。",
				p2: "水手10号任务",
				p2Text: "事件任务（打出本牌后生效；同一事件至多领取一个奖励，每项限一次）：访问（水星）：从牌库抽1张牌；访问（金星）：获得1点推广。",
				p3: "旅行者2号任务",
				p3Text: "事件任务（打出本牌后生效；同一事件至多领取一个奖励，每项限一次）：访问（天王星）：获得1点能量；访问（海王星）：获得1点信用。",
				p4: "伽利略任务",
				p4Text: "事件任务（打出本牌后生效；同一事件至多领取一个奖励，每项限一次）：访问（金星）：获得1点推广；访问（木星）：获得1个数据。",
				p5: "金星探测器",
				p5Text: "免费发射一个探测器。获得1点推广。任务：自己在金星的环绕器和着陆器数量（含卫星）至少为1时，可领取：获得7分。获得1点推广。",
				p6: "朱诺探测器",
				p6Text: "免费发射一个探测器。获得1个数据。任务：自己在木星的环绕器和着陆器数量（含卫星）至少为1时，可领取：获得7分。获得1点推广。",
				p7: "信使号探测器",
				p7Text: "免费发射一个探测器。获得1次移动。任务：自己在水星的环绕器和着陆器数量（含卫星）至少为1时，可领取：获得7分。获得1点推广。",
				p8: "卡西尼探测器",
				p8Text: "免费发射一个探测器。从牌库抽1张牌。任务：自己在土星的环绕器和着陆器数量（含卫星）至少为1时，可领取：获得6分。获得1点推广。",
				p9: "猎鹰重型运载火箭",
				p9Text: "免费发射一个探测器，此次发射忽略太空探测器上限。免费发射一个探测器，此次发射忽略太空探测器上限。获得1点推广。",
				p10: "ODINUS任务",
				p10Text: "免费研究一项探测器科技。任务：自己在海王星的环绕器和着陆器数量（含卫星）至少为1，且自己在天王星的环绕器和着陆器数量（含卫星）至少为1时，可领取：获得5分。从牌库抽1张牌。",
				p11: "科研补助",
				p11Text: "从牌库抽一张牌，展示它并获得其弃置收益；保留该牌。",
				p12: "欧罗巴快船",
				p12Text: "免费着陆，即使没有卫星探测科技也可在卫星着陆。终局计分：自己在木星的环绕器和着陆器数量（含卫星），每个计3分。",
				p13: "毅力号火星车",
				p13Text: "免费着陆。若本次行动在火星、水星或任意卫星着陆，获得4分。",
				p14: "火星科学实验室",
				p14Text: "获得1点推广。获得2个数据。终局计分：自己在火星的环绕器和着陆器数量（含卫星），每个计4分。",
				p15: "大气进入",
				p15Text: "移除自己的一个环绕器，获得3分、1个数据，并选择获得一张牌。",
				p16: "蜻蜓号",
				p16Text: "免费着陆，可选择已占用的位置。",
				p17: "OSIRIS-REx",
				p17Text: "选择自己的一个探测器：若它在小行星上，获得2个数据；其所在格位每相邻一个小行星格位，再获得1个数据。",
				p18: "隼鸟号",
				p18Text: "若位于小行星的己方探测器数量至少为1，标记一个黄色痕迹。",
				p19: "引力弹弓",
				p19Text: "本回合访问行星时，可以用1次移动替代获得的1点推广。获得2次移动。",
				p20: "水星飞掠",
				p20Text: "获得2次移动。若本回合访问水星的次数至少为1，获得4分。",
				p21: "金星飞掠",
				p21Text: "获得2次移动。若本回合访问金星的次数至少为1，获得3分。",
				p22: "火星飞掠",
				p22Text: "获得2次移动。若本回合访问火星的次数至少为1，获得4分。",
				p23: "木星飞掠",
				p23Text: "获得2次移动。若本回合访问木星的次数至少为1，获得4分。",
				p24: "土星飞掠",
				p24Text: "获得3次移动。若本回合访问土星的次数至少为1，获得6分。",
				p25: "光帆",
				p25Text: "本回合每访问一颗不同的行星，获得1分，包括地球。获得4次移动。",
				p26: "穿越小行星带",
				p26Text: "本回合离开小行星格位不额外消耗移动。获得2次移动。",
				p27: "哈勃太空望远镜",
				p27Text: "获得1次移动。在自己一个探测器所在的扇区标记1个信号。",
				p28: "开普勒太空望远镜",
				p28Text: "获得1次移动。在自己一个探测器所在的扇区标记2个信号。",
				p29: "詹姆斯·韦布太空望远镜",
				p29Text: "获得1次移动。在自己一个探测器所在的扇区标记1个信号，并在两侧相邻扇区各标记1个信号。",
				p30: "大型天文台计划",
				p30Text: "在至多三个不同探测器所在的扇区（可属于任意玩家）标记各1个信号。",
				p31: "太空发射系统",
				p31Text: "免费发射一个探测器。获得1次移动。任务：自己的行星着陆器数量（不含卫星）至少为3时，可领取：获得1点信用。",
				p32: "水星探索计划",
				p32Text: "在水星所在的扇区标记2个信号。任务：自己在水星的环绕器和着陆器数量（含卫星）至少为1时，可领取：获得4分。",
				p33: "金星探索计划",
				p33Text: "在金星所在的扇区标记2个信号。任务：自己在金星的环绕器和着陆器数量（含卫星）至少为1时，可领取：获得4分。",
				p34: "火星探索计划",
				p34Text: "在火星所在的扇区标记2个信号。任务：自己在火星的环绕器和着陆器数量（含卫星）至少为1时，可领取：获得4分。",
				p35: "木星探索计划",
				p35Text: "在木星所在的扇区标记2个信号。任务：自己在木星的环绕器和着陆器数量（含卫星）至少为1时，可领取：获得4分。",
				p36: "土星探索计划",
				p36Text: "在土星所在的扇区标记2个信号。任务：自己在土星的环绕器和着陆器数量（含卫星）至少为1时，可领取：获得4分。",
				p37: "比邻星观测",
				p37Text: "在比邻星所在的扇区标记2个信号。任务：自己在比邻星扇区的胜利次数至少为2时，可领取：获得4分。获得1点推广。",
				p38: "巴纳德星观测",
				p38Text: "在巴纳德星所在的扇区标记2个信号。终局计分：自己在巴纳德星扇区的胜利次数，每个计3分。",
				p39: "室女座61观测",
				p39Text: "在室女座61所在的扇区标记2个信号。任务：自己在室女座61扇区的胜利次数至少为2时，可领取：获得4分。获得1点推广。",
				p40: "开普勒22观测",
				p40Text: "在开普勒22所在的扇区标记2个信号。终局计分：自己在开普勒22扇区的胜利次数，每个计3分。",
				p41: "天狼星A观测",
				p41Text: "在天狼星A所在的扇区标记2个信号。任务：自己在天狼星A扇区的胜利次数至少为2时，可领取：获得4分。获得1点推广。",
				p42: "南河三观测",
				p42Text: "在南河三所在的扇区标记2个信号。终局计分：自己在南河三扇区的胜利次数，每个计3分。",
				p43: "绘架座β观测",
				p43Text: "在绘架座β所在的扇区标记1个信号。任务：自己在绘架座β扇区的胜利次数至少为1时，可领取：获得2分。获得1点推广。",
				p44: "织女星观测",
				p44Text: "在织女星所在的扇区标记1个信号。终局计分：自己在织女星扇区的胜利次数，每个计3分。",
				p45: "艾伦望远镜阵列",
				p45Text: "依次弃置2张公开项目牌，各在相同信号颜色的一个扇区标记信号。随后补足公开项目牌。若本回合填满一个扇区，获得1点能量。",
				p46: "阿塔卡马大型毫米波阵列",
				p46Text: "依次弃置2张公开项目牌，各在相同信号颜色的一个扇区标记信号。随后补足公开项目牌。若本回合填满一个扇区，从牌库抽1张牌。",
				p47: "甚大天线阵",
				p47Text: "依次弃置2张公开项目牌，各在相同信号颜色的一个扇区标记信号。随后补足公开项目牌。若本回合填满一个扇区，获得1个数据。",
				p48: "突破摄星",
				p48Text: "获得1次移动。在红色扇区标记1个信号。",
				p49: "突破观测",
				p49Text: "获得1次移动。在黄色扇区标记1个信号。",
				p50: "平方千米阵列",
				p50Text: "依次弃置3张公开项目牌，各在相同信号颜色的一个扇区标记信号。随后补足公开项目牌。本次行动每标记一个不同扇区的信号，获得2分。",
				p51: "洛弗尔望远镜",
				p51Text: "获得1个数据。免费执行一次扫描；仍须支付额外扫描步骤的费用。任务：自己当前的推广至少为8时，可领取：获得3分。从牌库抽1张牌。",
				p52: "帕克斯天文台",
				p52Text: "免费执行一次扫描；仍须支付额外扫描步骤的费用。本次行动每标记一个红色信号，获得2分。",
				p53: "深度巡天阵列",
				p53Text: "免费执行一次扫描；仍须支付额外扫描步骤的费用。本次行动每标记一个黄色信号，获得2分。",
				p54: "VERITAS望远镜",
				p54Text: "免费执行一次扫描；仍须支付额外扫描步骤的费用。本次行动每标记一个蓝色信号，获得2分。",
				p55: "阿雷西博天文台",
				p55Text: "免费执行一次扫描；仍须支付额外扫描步骤的费用。在任意扇区标记1个信号。",
				p56: "突破聆听",
				p56Text: "获得1次移动。在蓝色扇区标记1个信号。",
				p57: "埃费尔斯贝格望远镜建设",
				p57Text: "从牌库抽1张牌。免费研究一项望远镜科技。",
				p58: "天王星轨道器与探测器",
				p58Text: "免费发射一个探测器。任务：自己在天王星的环绕器和着陆器数量（含卫星）至少为1时，可领取：获得3分。从牌库抽1张牌。",
				p59: "离子推进系统",
				p59Text: "获得1点能量。免费研究一项探测器科技。",
				p60: "三叉戟探测器",
				p60Text: "免费发射一个探测器。任务：自己在海王星的环绕器和着陆器数量（含卫星）至少为1时，可领取：获得4分。获得1个数据。",
				p61: "量子计算机",
				p61Text: "免费研究一项计算机科技。任务：自己当前分数至少为50时，可领取：可以将一张手牌放入收入区，并立即获得收入。",
				p62: "昂萨拉望远镜建设",
				p62Text: "免费研究一项望远镜科技。终局计分：自己的红色痕迹数量（含溢出区），每个计2分。",
				p63: "SHERLOC",
				p63Text: "免费研究一项探测器科技。终局计分：自己的黄色痕迹数量（含溢出区），每个计2分。",
				p64: "ALICE",
				p64Text: "免费研究一项计算机科技。任务：拥有自己蓝色痕迹的文明数量至少为2时，可领取：获得2个数据。",
				p65: "FAST望远镜建设",
				p65Text: "依次弃置2张公开项目牌，各在相同信号颜色的一个扇区标记信号。随后补足公开项目牌。免费研究一项望远镜科技。",
				p66: "GMRT望远镜建设",
				p66Text: "免费研究一项望远镜科技。任务：拥有自己红色痕迹的文明数量至少为2时，可领取：获得2分。获得1点能量。",
				p67: "叶夫帕托里亚望远镜建设",
				p67Text: "获得1点推广。免费研究一项望远镜科技。可以弃置一张手牌，在与其信号颜色相同的一个扇区标记信号。",
				p68: "DUNE",
				p68Text: "免费研究一项计算机科技。终局计分：自己的蓝色痕迹数量（含溢出区），每个计2分。",
				p69: "大型强子对撞机",
				p69Text: "获得1个数据。免费研究一项计算机科技。",
				p70: "ATLAS",
				p70Text: "免费研究一项计算机科技。任务：自己的蓝色痕迹数量（含溢出区）至少为3时，可领取：获得3分。获得1个数据。",
				p71: "集中研究",
				p71Text: "免费研究一项任意科技。在本次选择的科技类别中，每拥有一项科技，获得2分。",
				p72: "科学合作",
				p72Text: "免费研究一项任意科技。若其他玩家已经拥有本次选择的科技，获得2点推广。",
				p73: "清洁太空倡议",
				p73Text: "弃置全部公开项目牌，获得它们各自的弃置收益，然后补足公开项目牌。",
				p74: "发射前测试",
				p74Text: "免费发射一个探测器。展示手牌中弃置收益为移动的牌，每展示一张，获得1次移动。",
				p75: "嗜极生物研究",
				p75Text: "选择一种颜色，标记该颜色的痕迹。随后，你每拥有一个该颜色的痕迹，获得1分。",
				p76: "NASA研究中心",
				p76Text: "事件任务（打出本牌后生效；同一事件至多领取一个奖励，每项限一次）：研究科技（探测器）：获得1点能量；研究科技（望远镜）：获得1点推广；研究科技（计算机）：从牌库抽1张牌。",
				p77: "NASA天体生物研究所",
				p77Text: "获得1点推广。事件任务（打出本牌后生效；同一事件至多领取一个奖励，每项限一次）：标记痕迹（红色）：获得1个数据；标记痕迹（黄色）：获得1个数据；标记痕迹（蓝色）：获得1个数据。",
				p78: "SETI研究所",
				p78Text: "获得1点推广。事件任务（打出本牌后生效；同一事件至多领取一个奖励，每项限一次）：完成扫描：获得2个数据；完成扫描：从牌库抽1张牌；完成扫描：获得4分。",
				p79: "国际空间站",
				p79Text: "获得1点推广。事件任务（打出本牌后生效；同一事件至多领取一个奖励，每项限一次）：发射探测器：获得1点信用；发射探测器：从牌库抽1张牌；发射探测器：获得5分。",
				p80: "卡纳维拉尔角太空军基地",
				p80Text: "事件任务（打出本牌后生效；同一事件至多领取一个奖励，每项限一次）：发射探测器：获得1次移动；发射探测器：获得1次移动；发射探测器：获得1次移动。",
				p81: "国际合作",
				p81Text: "免费研究一项任意科技，必须已有其他玩家拥有；不旋转太阳系，不获得科技板块奖励。",
				p82: "约翰逊航天中心",
				p82Text: "事件任务（打出本牌后生效；同一事件至多领取一个奖励，每项限一次）：环绕：获得2点推广；着陆：获得2点推广。",
				p83: "Wow!信号",
				p83Text: "获得1点推广。在地球所在的扇区标记2个信号。",
				p84: "样本返回",
				p84Text: "移除自己的一个着陆器（含卫星），标记一个黄色痕迹。",
				p85: "星舰",
				p85Text: "免费发射一个探测器。免费研究一项探测器科技。",
				p86: "巨型麦哲伦望远镜",
				p86Text: "依次弃置1张公开项目牌，各在相同信号颜色的一个扇区标记信号。随后补足公开项目牌。终局计分：有自己信号的不同扇区数量，每个计1分。",
				p87: "远射计划",
				p87Text: "免费研究一项探测器科技。任务：自己的探测器距地球所需移动次数的最大值至少为5时，可领取：获得3分。获得1点能量。",
				p88: "钱德拉太空天文台",
				p88Text: "在自己一个探测器所在的扇区标记2个信号。任务：有自己信号的不同扇区数量至少为4时，可领取：获得2点推广。",
				p89: "NIAC计划",
				p89Text: "从牌库抽3张牌。任务：手牌中牌的数量不超过0时，可领取：从牌库抽1张牌。",
				p90: "燃料箱建造",
				p90Text: "按手牌中能量收入牌的数量，每个获得1点能量。",
				p91: "聚变反应堆",
				p91Text: "按自己收入区中能量收入牌的数量，每个获得1点能量。将本牌放入收入区，并立即获得它的收入。",
				p92: "NASA每日一图",
				p92Text: "获得2点推广。按自己收入区中牌收入牌的数量，每个获得1点推广。将本牌放入收入区，并立即获得它的收入。",
				p93: "政府资助",
				p93Text: "按自己收入区中信用收入牌的数量，每个获得3分。将本牌放入收入区，并立即获得它的收入。",
				p94: "科学普及",
				p94Text: "获得1点推广。事件任务（打出本牌后生效；同一事件至多领取一个奖励，每项限一次）：研究科技（探测器）：获得2点推广；研究科技（望远镜）：获得2点推广；研究科技（计算机）：获得2点推广。",
				p95: "近地小行星巡天",
				p95Text: "获得2点推广。任务：位于地球相邻小行星格位的己方探测器数量至少为1时，可领取：获得5分。从牌库抽1张牌。",
				p96: "缓步动物研究",
				p96Text: "获得1点推广。获得1个数据。从牌库抽1张牌。任务：自己的黄色痕迹数量（含溢出区）至少为3时，可领取：标记一个黄色痕迹。",
				p97: "阿波罗11号任务",
				p97Text: "免费研究一项探测器科技。任务：拥有自己黄色痕迹的文明数量至少为2时，可领取：获得2分。从牌库抽1张牌。",
				p98: "日冕光谱仪",
				p98Text: "标记一个红色痕迹，只能选择自己已有该颜色痕迹的文明。",
				p99: "电子显微镜",
				p99Text: "标记一个黄色痕迹，只能选择自己已有该颜色痕迹的文明。",
				p100: "百亿亿次超级计算机",
				p100Text: "标记一个蓝色痕迹，只能选择自己已有该颜色痕迹的文明。",
				p101: "望远镜时间分配",
				p101Text: "事件任务（打出本牌后生效；同一事件至多领取一个奖励，每项限一次）：完成扫描：在黄色扇区标记1个信号；完成扫描：在红色扇区标记1个信号；完成扫描：在蓝色扇区标记1个信号。",
				p102: "语言分析",
				p102Text: "获得3点推广。任务：自己拥有三种颜色痕迹的文明数量至少为1时，可领取：在你拥有三种颜色痕迹的一个文明中，标记任意一种颜色的痕迹。",
				p103: "韦斯特博克综合射电望远镜",
				p103Text: "免费研究一项望远镜科技。任务：自己在同一扇区的最高胜利次数至少为2时，可领取：获得9分。",
				p104: "罗塞塔探测器",
				p104Text: "免费发射一个探测器。任务：位于彗星的己方探测器数量至少为1时，可领取：获得3分。获得1个数据。",
				p105: "绿岸望远镜",
				p105Text: "免费执行一次扫描；仍须支付额外扫描步骤的费用。任务：自己的红色痕迹数量（含溢出区）至少为3时，可领取：标记一个红色痕迹。",
				p106: "战略规划",
				p106Text: "事件任务（打出本牌后生效；同一事件至多领取一个奖励，每项限一次）：支付信用打出项目牌（1）：获得2分；支付信用打出项目牌（2）：从牌库抽1张牌；支付信用打出项目牌（3）：获得2点推广。",
				p107: "首张黑洞照片",
				p107Text: "获得2个数据。事件任务（打出本牌后生效；同一事件至多领取一个奖励，每项限一次）：标记痕迹（蓝色）：获得2点推广；标记痕迹（蓝色）：获得4分。",
				p108: "SETI@Home",
				p108Text: "若自己当前的推广至少为8，标记一个红色痕迹。",
				p109: "低功耗微处理器",
				p109Text: "获得1点能量。免费研究一项计算机科技。",
				p110: "新闻声明",
				p110Text: "获得3点推广。",
				p111: "罗曼太空望远镜",
				p111Text: "免费研究一项望远镜科技。任务：自己的环绕器数量至少为2时，可领取：获得2个数据。",
				p112: "行星地质测绘",
				p112Text: "免费研究一项探测器科技。任务：自己同时拥有环绕器与着陆器的行星数量至少为1时，可领取：获得3分。获得1个数据。",
				p113: "索尔维会议",
				p113Text: "获得2点推广。终局时，选择一块自己未标记的黄金板块，按最右侧数值计分。",
				p114: "行星猎人",
				p114Text: "从牌库抽1张牌。可以弃置一张手牌，在与其信号颜色相同的一个扇区标记信号。可以弃置一张手牌，在与其信号颜色相同的一个扇区标记信号。可以弃置一张手牌，在与其信号颜色相同的一个扇区标记信号。",
				p115: "加拿大氢强度测绘望远镜",
				p115Text: "在任意扇区标记1个信号。任务：自己拥有的望远镜科技数量至少为3时，可领取：获得1个数据。",
				p116: "控制中心",
				p116Text: "事件任务（打出本牌后生效；同一事件至多领取一个奖励，每项限一次）：标记信号（黄色）：获得1次移动；标记信号（红色）：获得1次移动；标记信号（蓝色）：获得1次移动。",
				p117: "月球门户",
				p117Text: "免费发射一个探测器。事件任务（打出本牌后生效；同一事件至多领取一个奖励，每项限一次）：环绕或着陆：免费发射一个探测器；环绕或着陆：获得1点能量。",
				p118: "PLATO",
				p118Text: "在自己一个探测器所在的扇区标记3个信号；这些信号不获得数据。",
				p119: "PIXL",
				p119Text: "免费研究一项计算机科技。当前每有1点推广，获得1分。",
				p120: "拉格朗日点轨道",
				p120Text: "在自己一个探测器所在的扇区标记1个信号。若你在刚标记的扇区中恰有一个信号，将本牌收回手牌。",
				p121: "未来环形对撞机",
				p121Text: "获得3个数据。免费研究一项计算机科技。",
				p122: "业余天文学家",
				p122Text: "从牌库顶弃置一张牌，在与其信号颜色相同的一个扇区标记信号。从牌库顶弃置一张牌，在与其信号颜色相同的一个扇区标记信号。从牌库顶弃置一张牌，在与其信号颜色相同的一个扇区标记信号。",
				p123: "小行星飞掠",
				p123Text: "获得1次移动。若本回合访问小行星的次数至少为1，获得1个数据。",
				p124: "彗星邂逅",
				p124Text: "获得2次移动。若本回合访问彗星的次数至少为1，获得4分。",
				p125: "轨道修正",
				p125Text: "获得1次移动。若本回合同一轨道环内的移动次数至少为1，获得3分。获得1点推广。",
				p126: "欧几里得望远镜建设",
				p126Text: "免费研究一项探测器或望远镜科技。终局计分：自己拥有的计算机科技数量，每个计2分。",
				p127: "近地小行星交会探测器",
				p127Text: "获得2点推广。终局计分：若位于小行星的己方探测器数量至少为1，获得13分。",
				p128: "先进导航系统",
				p128Text: "事件任务（打出本牌后生效；同一事件至多领取一个奖励，每项限一次）：访问（planet）：获得1点能量；访问（planet）：获得1个数据；访问（planet）：获得1次移动。",
				p129: "小行星研究",
				p129Text: "事件任务（打出本牌后生效；同一事件至多领取一个奖励，每项限一次）：访问（小行星）：获得1个数据；访问（小行星）：获得1个数据；访问（小行星）：获得1个数据。",
				p130: "低成本太空发射",
				p130Text: "免费发射一个探测器。",
				p131: "望远镜升级",
				p131Text: "从牌库抽1张牌。事件任务（打出本牌后生效；同一事件至多领取一个奖励，每项限一次）：研究科技（望远镜）：获得1点推广；完成扫描：获得1个数据。",
				p132: "航天飞机",
				p132Text: "免费发射一个探测器。获得2点推广。任务：自己在所有行星的环绕器和着陆器数量（含卫星）至少为5时，可领取：获得3分。获得1点信用。",
				p133: "最佳发射窗口",
				p133Text: "免费发射一个探测器。地球所在扇区每有另一颗行星或一颗彗星，获得1次移动。",
				p134: "赫歇尔太空天文台",
				p134Text: "在自己一个探测器所在的扇区标记1个信号。任务：有自己信号的不同扇区数量至少为4时，可领取：获得2点推广。",
				p135: "诺托射电天文台",
				p135Text: "获得1点推广。免费执行一次扫描；仍须支付额外扫描步骤的费用。",
				p136: "阿尔冈昆射电天文台",
				p136Text: "在黄色扇区标记1个信号；这些信号不获得数据。在红色扇区标记1个信号；这些信号不获得数据。在蓝色扇区标记1个信号；这些信号不获得数据。在黑色扇区标记1个信号；这些信号不获得数据。",
				p137: "SETI数据档案",
				p137Text: "获得2个数据。",
				p138: "康奈尔大学",
				p138Text: "事件任务（打出本牌后生效；同一事件至多领取一个奖励，每项限一次）：为弃置收益弃置手牌（推广）：获得1点推广；为弃置收益弃置手牌（数据）：获得1个数据；为弃置收益弃置手牌（次移动）：获得1次移动。"
			},
			aliens: {
				c1001: "首次接触",
				c1001Text: "获得1次移动。免费着陆，并从该行星的硫铵虫样本中秘密选择一个，放置样本舱。任务：将自己的一个样本舱送达地球后，领取样本奖励和2个数据。",
				c1002: "漫游车探索",
				c1002Text: "免费着陆；即使没有卫星探测科技也可在卫星着陆。若该行星有样本，秘密选择一个并放置样本舱。任务：送达地球，领取样本奖励、3分和3个数据。",
				c1003: "大规模样本收集",
				c1003Text: "免费环绕或着陆。若该行星有硫铵虫样本，秘密选择一个并放置样本舱。任务：送达地球，领取样本奖励、3分和1点信用。",
				c1004: "火星隔离实验室",
				c1004Text: "免费着陆，秘密选择该行星的一个样本并放置样本舱。任务：送达火星，领取样本奖励、2分，并抽1张牌。",
				c1005: "生态系统研究",
				c1005Text: "选择有自己探测器的行星，查看该行星的样本，领取其中一个样本的奖励，再将样本放回。终局时，自己在硫铵虫文明每有一个痕迹，获得1分。",
				c1006: "虫后",
				c1006Text: "免费着陆；即使没有卫星探测科技也可在卫星着陆。秘密选择一个样本并放置样本舱。任务：送达地球，领取样本奖励、6分和2点推广。",
				c1007: "繁殖样本",
				c1007Text: "免费着陆，秘密选择该行星的一个样本并放置样本舱。任务：送达地球，领取两次该样本的奖励。",
				c1008: "轨道监测",
				c1008Text: "获得1点推广，研究一项望远镜科技。任务：在硫铵虫文明拥有两个红色痕迹后，可查看木星或土星的样本，领取其中一个的奖励，再放回。",
				c1009: "计算机模拟",
				c1009Text: "获得1点推广，研究一项计算机科技。任务：在硫铵虫文明拥有两个蓝色痕迹后，可查看木星或土星的样本，领取其中一个的奖励，再放回。",
				c1010: "虫巢样本",
				c1010Text: "获得1点推广，研究一项探测器科技。任务：在硫铵虫文明拥有两个黄色痕迹后，可查看木星或土星的样本，领取其中一个的奖励，再放回。",
				c1011: "我们被观察了吗？",
				c1011Text: "获得下一次将触发的异常点所示奖励。任务：在异常点文明拥有三种颜色各一个痕迹后，获得3分和2点推广。",
				c1012: "生命迹象",
				c1012Text: "免费发射一个探测器。若发射所在扇区有异常点，获得1次移动。",
				c1013: "忧虑的人们",
				c1013Text: "获得1点推广。事件任务：此后每研究一项科技，可领取一个未领取的奖励：1点能量、抽1张牌或3分。每项限一次。",
				c1014: "仔细聆听",
				c1014Text: "进行一次扫描，并在下一次将触发的异常点所在扇区额外标记一个信号。",
				c1015: "日常生活的一部分",
				c1015Text: "从牌库抽3张牌。弃置其中一张，领取其弃置收益；再弃置另一张，领取其收入所示资源。保留剩余的一张。",
				c1016: "媒体空间洪流",
				c1016Text: "获得全部公开项目牌，然后补足公开项目牌。",
				c1017: "近距离观察",
				c1017Text: "获得5次移动。本回合的移动不获得推广。",
				c1018: "信息舱",
				c1018Text: "免费研究一项任意类别的科技。",
				c1019: "新物理学",
				c1019Text: "标记一个任意颜色的痕迹。",
				c1020: "惊人的不确定性",
				c1020Text: "在任意扇区标记一个信号。随后，有异常点的扇区中每有一个自己的信号，获得1分。",
				c1021: "天空中的访客",
				c1021Text: "进行一次扫描；本次扫描每在奥陌陌上标记一个信号，获得2分。任务：在奥陌陌文明标记过至少一个需要支付化石的研究位置后，获得1个数据。",
				c1022: "改变轨迹",
				c1022Text: "进行一次扫描；若本次扫描至少在奥陌陌上标记一个信号，获得1个地外化石。任务：在奥陌陌拥有着陆器后，获得4分。",
				c1023: "地外化石发现",
				c1023Text: "在奥陌陌所在扇区或其板块上标记一个信号。任务：拥有至少3个地外化石时，可以支付2个地外化石，获得11分。",
				c1024: "地外化石样本",
				c1024Text: "研究一项计算机科技。随后可以支付1个地外化石，获得1个数据。",
				c1025: "探测器定制",
				c1025Text: "可以任意次支付1个地外化石，每次获得2次移动。随后免费着陆。",
				c1026: "挖掘漫游车",
				c1026Text: "免费着陆；若本次在奥陌陌着陆，额外获得3分。任务：在奥陌陌文明拥有三种颜色各一个痕迹后，获得1个地外化石。",
				c1027: "完美时机",
				c1027Text: "获得4次移动；若本回合访问奥陌陌，获得1个地外化石。任务：奥陌陌板块上有自己的信号时，获得1个地外化石。",
				c1028: "争分夺秒",
				c1028Text: "免费发射一个探测器，并获得1个地外化石。",
				c1029: "对比分析",
				c1029Text: "获得1个地外化石。事件任务：此后每标记一个痕迹，可领取一个未领取的奖励：1个数据、1点推广或3分。每项限一次。",
				c1030: "地形测绘",
				c1030Text: "依次在黄色、红色、蓝色扇区各标记一个信号。随后可以支付1个地外化石，在任意扇区标记一个信号。终局时，自己在奥陌陌文明每有一个痕迹，获得1分。",
				c1031: "飞船设计",
				c1031Text: "免费发射一个探测器，并发送消息。再获得15分后，将本牌放入收入区并立即获得收入。",
				c1032: "地外计算机",
				c1032Text: "获得2个数据，并发送消息。再获得15分后，将本牌放入收入区并立即获得收入。",
				c1033: "信息集群",
				c1033Text: "获得1点推广和1点信用，并发送消息。再获得15分后，将本牌放入收入区并立即获得收入。",
				c1034: "远方的信息",
				c1034Text: "从牌库抽1张牌，并发送消息。再获得15分后，标记一个红色痕迹。",
				c1035: "合成指令",
				c1035Text: "获得1个数据，并发送消息。再获得15分后，标记一个黄色痕迹。",
				c1036: "外星蓝图",
				c1036Text: "获得2点推广，并发送消息。再获得15分后，标记一个蓝色痕迹。",
				c1037: "天体之音",
				c1037Text: "从牌库抽1张牌，并发送消息。再获得15分后，获得1点信用并标记一个任意颜色的痕迹。",
				c1038: "蜂群思维概念",
				c1038Text: "研究一项计算机科技，并发送消息。再获得15分后，将本牌放入收入区并立即获得收入。",
				c1039: "望远镜蓝图",
				c1039Text: "研究一项望远镜科技，并发送消息。再获得15分后，将本牌放入收入区并立即获得收入。",
				c1040: "洪流链信号",
				c1040Text: "在同一个任意扇区标记两个信号，并发送消息。再获得15分后，将本牌放入收入区并立即获得收入。",
				c2001: "自动化实验室",
				c2001Text: "危险值0。终局时，若在钻探者文明拥有至少6个痕迹，获得7分。",
				c2002: "盒式部署",
				c2002Text: "危险值2。终局时，若在同一颗行星拥有至少3个环绕器或着陆器（含卫星），获得10分。",
				c2003: "核心突破系外行星",
				c2003Text: "危险值4。终局时，若在蓝色扇区获胜至少2次，获得12分。",
				c2004: "偏转器",
				c2004Text: "危险值7。终局时，若拥有至少3项望远镜科技，获得15分。",
				c2005: "扩展核心",
				c2005Text: "危险值3。终局时，若拥有至少3项计算机科技，获得9分。",
				c2006: "提取器",
				c2006Text: "危险值8。终局时，若收入区至少有8张牌，获得18分。",
				c2007: "裂变恒星系外行星",
				c2007Text: "危险值5。终局时，若在黑色扇区获胜至少2次，获得14分。",
				c2008: "生成式基础设施",
				c2008Text: "危险值7。终局时，若拥有至少4个着陆器（含卫星），获得16分。",
				c2009: "纳米焊接节点",
				c2009Text: "危险值1。终局时，若拥有至少5个同色痕迹，获得8分。",
				c2010: "神经实验室",
				c2010Text: "危险值9。终局时，若在另一个文明拥有至少6个痕迹，获得20分。",
				c2011: "振荡探测器",
				c2011Text: "危险值3。终局时，若拥有至少3个环绕器，获得11分。",
				c2012: "穿透系外行星",
				c2012Text: "危险值4。终局时，若在红色扇区获胜至少2次，获得12分。",
				c2013: "剃刀边缘穿梭机",
				c2013Text: "危险值6。终局时，若拥有至少3项探测器科技，获得14分。",
				c2014: "平流层电梯",
				c2014Text: "危险值4。终局时，若完成至少5张任务，获得12分。",
				c2015: "涡旋系外行星",
				c2015Text: "危险值4。终局时，若在黄色扇区获胜至少2次，获得12分。"
			},
			anomalyAt: "第 {{n}} 扇区的异常点",
			sampleCapsule: "{{name}} 的样本舱",
			playedSecrets: "已秘密打出的项目",
			repeatable: "可重复标记",
			samplesRemaining: "剩余样本：木星 {{jupiter}} · 土星 {{saturn}}",
			exertianMilestones: "秘密项目机会：{{first}} 分 · {{second}} 分",
			goldFaces: {
				techSet: "三类科技各一项",
				techPair: "每两项科技",
				missions: "每张已完成任务",
				missionPair: "每两张已完成任务或终局项目",
				incomeSet: "信用、能量与卡牌收入各一张",
				incomeMaximum: "信用或能量收入牌的较大数量",
				traceSet: "三种颜色痕迹各一个",
				winFigure: "每次扇区胜利配一个环绕器或着陆器"
			},
			playSecret: "秘密打出此牌",
			messageBonus: "选择第 {{n}} 项消息奖励",
			freeOrbit: "免费进入环绕轨道",
			freeLanding: "免费着陆",
			spendFossil: "支付一个地外化石",
			researchTrace: "标记第 {{n}} 个研究位置",
			markOumuamua: "在奥陌陌上标记信号",
			resolveOumuamua: "结算奥陌陌信号",
			fossil: "地外化石",
			danger: "危险值",
			secretCards: "钻探者秘密项目",
			messageThreshold: "{{name}} 的消息：{{n}} 分",
			researchCost: "支付 {{n}} 数据",
			fossilCost: "支付 {{n}} 地外化石",
			sampleRewards: {
				credit: "样本：2 点信用",
				energy: "样本：2 点能量",
				publicity: "样本：3 点推广",
				data: "样本：2 个数据",
				cards: "样本：抽 2 张牌",
				pointsCards: "样本：3 分并抽 1 张牌",
				points: "样本：7 分"
			},
			chooseReward: "获得 {{n}} {{resource}}",
			finishSignals: "结束信号标记",
			selectProbe: "选择此探测器",
			chooseTraceColor: "选择{{n}}",
			overflowColor: "文明{{n}}：{{color}}放入溢出区 · 3分",
			deferRoundCard: "稍后选牌",
			roundLabel: "第 {{n}} / 5 轮",
			roundCards: "轮末选牌",
			goldTiles: "黄金板块",
			firstPlayer: "起始玩家",
			finalScore: "终局计分",
			baseScore: "对局得分",
			cardScore: "项目牌",
			goldScore: "黄金板块",
			alienScore: "文明奖励",
			dangerPenalty: "危险惩罚",
			totalScore: "总分",
			name: "SETI：搜寻地外文明",
			desc: "探索旋转太阳系，研究科技，搜寻五种地外文明。2至4人，完整五轮，138张基础项目牌。",
			rules: "游戏目标与准备：\n通过探索行星、研究科技和寻找外星文明痕迹获得分数。基础版支持2至4人，进行完整五轮，使用138张各不相同的基础项目牌及本局两种文明的专属牌。\n开局准备：\n· 每位玩家获得 4 点信用、3 点能量、4 点推广和 5 张手牌。\n· 按座次顺序，各玩家的起始分数依次为 1、2、3、4 分。\n· 公开项目区放置 3 张牌；太阳系的初始位置随机确定。\n· 本局使用两块尚未揭示身份的文明板，各有三个不同颜色的发现格。\n· 从首位玩家开始，依次选择一张手牌放入自己的收入区。\n· 立即获得牌底显示的 1 点资源；若牌底为卡牌图标，则从牌库抽取 1 张牌。\n· 收入牌不再属于手牌，不能作为手牌打出或弃置。\n· 所有玩家完成收入选择后，由首位玩家开始行动。\n资源与卡牌：\n· 信用用于发射、环绕、扫描和支付项目牌费用。\n· 能量用于移动、环绕、着陆和分析；推广用于研究科技与购买卡牌。\n· 推广最多保留 10 点；数据池最多保留 6 个数据，超出部分不保留。\n· 已放入计算机的数据不占用数据池容量；信用和能量没有数量上限。\n· 项目牌的费用、弃置收益、信号颜色和收入分别标示在牌面上。\n· 打出项目牌、领取弃置收益和作为收入是不同用途，不能同时领取。\n· 选择获得一张牌时，可选择一张公开项目，或从牌库顶抽取一张牌。\n· 公开项目被拿取后补足至 3 张；效果另有补牌时机时，按该效果执行。\n· 牌库耗尽时，将弃牌堆洗混作为新牌库。\n回合流程：\n· 玩家按座次轮流行动，已经退出本轮的玩家不再获得自己的行动回合。\n· 每个回合执行一个主行动。发射、环绕、着陆、扫描和分析均为主行动。\n· 打出项目牌、研究科技和退出本轮也各占用一个主行动。\n· 可在主行动之前、之后，以及效果允许的间隙执行自由行动。\n· 一个自由行动及其奖励必须全部完成，才能开始另一个自由行动。\n· 任务奖励需要作出选择时，先完成该次选择及奖励，再继续当前行动。\n· 主行动及其效果完成后，结算所有已经填满的扇区。\n· 扇区全部结算后，可继续执行自由行动，再选择“结束回合”。\n发射探测器：\n· 支付 2 点信用，将一个探测器放置在地球所在的格位。\n· 未获得“双探测器”科技时，每位玩家在太空中最多拥有一个探测器。\n· 环绕器和着陆器不计入此上限；发射本身不视为访问地球。\n探测器移动：\n· 支付 1 点能量，可将自己的一个探测器移动到相邻格位。\n· 相邻格位包括同一轨道环左右两格，以及同一扇区相邻轨道环的格位。\n· 不能斜向移动、穿过太阳，或移出太阳系最外侧的轨道环。\n· 离开小行星格位消耗 2 次移动；“小行星导航”科技可取消额外消耗。\n· 卡牌或科技提供的移动可用于自己的探测器；移动不足时可支付能量补足。\n· 例如，离开小行星需要 2 次移动；仅有 1 次可用移动时，须额外支付1点能量。\n· 拥有两个探测器时，同一次效果提供的移动可以分配给这两个探测器。\n· 可提前结束一次移动效果；未使用的移动不保留到之后的效果或回合。\n· 进入地球以外的行星格位或彗星格位时，获得 1 点推广。\n· 再次进入这些格位仍可获得推广；停留在原格位不会重复获得奖励。\n太阳系旋转：\n· 研究科技，以及本轮首位玩家确认退出时，均会触发一次旋转。\n· 旋转依次使用顶盘、中盘、底盘；每次逆时针旋转一个扇区。\n· 旋转中盘或底盘时，其上方的转盘也随之旋转。\n· 探测器随承载它的转盘移动；随盘移动不视为重新访问原有格位。\n· 切口中的探测器可能保持原位，也可能被转盘边缘推动至相邻扇区。\n· 被盘缘推动进入新格位时，按新格位处理推广和访问任务。\n进入行星轨道：\n· 自己的探测器位于地球以外的行星格位时，可以执行环绕主行动。\n· 支付 1 点信用和 1 点能量，将该探测器移至对应行星的环绕轨道。\n· 若首次环绕奖励位置尚未被占用，将环绕器放入该位置并获得 3 分。\n· 每次环绕均获得该行星列出的环绕奖励；具体效果见行星详情。\n· 环绕器不再是可移动的探测器，不能继续在太阳系格位之间移动。\n行星与卫星着陆：\n· 自己的探测器位于地球以外的行星格位时，可以执行着陆主行动。\n· 着陆通常支付 3 点能量；该行星已有任意玩家的环绕器时，减少 1 点。\n· 拥有“着陆改进”科技时再减少 1 点能量，两项减免可以同时生效。\n· 例如，行星已有环绕器，且你拥有“着陆改进”时，着陆支付 1 点能量。\n· 在行星上着陆时，获得该行星的着陆分数，并标记一次生命痕迹。\n· 若有未占用的首次着陆位置，选择其中一个，并获得该位置的数据奖励。\n· 首次着陆位置已全部占用时，仍可着陆，但不再获得该项数据奖励。\n· 拥有“卫星探测”科技后，可改在该行星的卫星上着陆。\n· 卫星着陆适用同一能量费用；通常每颗卫星只能容纳一个着陆器。\n· 卫星着陆只获得该卫星列出的奖励，不同时获得行星着陆奖励。\n· 着陆后，探测器成为着陆器，不能继续移动；卡牌例外以卡牌说明为准。\n扫描：\n· 支付 1 点信用和 2 点能量，执行一次扫描；不要求太空中有探测器。\n· 基础扫描包含两个步骤：扫描地球扇区，以及弃置一张公开项目并标记信号。\n· 扫描地球扇区时，在地球所在扇区放置一个自己的信号。\n· 弃置公开项目时，在与该牌信号颜色相同的一个扇区放置一个信号。\n· 同一颜色对应多个扇区时，从中选择一个；此处使用牌面右上角的颜色。\n· 两个基础步骤的顺序可以自选；完成两步后才能结束扫描。\n· 科技提供的额外步骤可穿插执行；每种额外步骤每次扫描至多执行一次。\n· 扫描中的公开项目在整次扫描完成后补足；多张公开牌效果先全部弃置，再补牌。\n信号奖励与扇区结算：\n· 在信号轨道尚未填满的扇区放置信号时，获得 1 个数据。\n· 放置该扇区的第二个信号时，额外获得 2 分，不论第一个信号属于谁。\n· 扇区填满后仍可继续放置信号，计入竞争数量，但不再获得上述奖励。\n· 主行动完成后，由当前回合的玩家选择已经填满的扇区逐一结算。\n· 结算时，在该扇区拥有至少一个信号的每位玩家均获得 1 点推广。\n· 信号最多的玩家获胜，并获得该扇区本次结算对应的分数。\n· 数量并列时，比较并列玩家最后一次放置信号的时间，较晚放置者优先。\n· 该比较方式也用于确定第二名；只有第二名保留一个信号，其余信号清除。\n· 某扇区第一次结算时，获胜者获得一次标记信号痕迹的机会。\n· 天狼星 A、比邻星、室女座 61 和绘架座 β 的后续胜利也给予信号痕迹。\n· 获胜记录保留，但不作为该扇区下一次结算时的信号数量。\n· 获胜者自行选择痕迹的放置位置，即使此时并非该玩家的行动回合。\n计算机与数据：\n· 放置数据是自由行动：从数据池取出一个数据，放入计算机上排。\n· 上排必须从左至右连续放置，每次放入最左侧的空格。\n· 未安装科技时，第二格给予 1 点推广，第四格允许增加一张收入牌。\n· 增加收入时，从手牌选择一张放入收入区，并立即获得其收入；也可放弃。\n· 上排格位已安装计算机科技时，放入数据改为获得 2 分。\n· 科技下排格位只有在对应上排已有数据时才能放置数据。\n· 下排不要求从左至右放置；每次消耗一个数据，并获得该科技的下排奖励。\n· 已有数据的格位不能再次放置；每次放置数据各视为一次自由行动。\n分析数据：\n· 计算机上排六格全部放入数据后，可支付 1 点能量执行分析主行动。\n· 分析移除计算机上下两排的全部数据，并获得一次标记分析痕迹的机会。\n· 移除的数据不退回数据池；数据池原有的数据和已安装科技均保留。\n研究科技：\n· 支付 6 点推广执行研究主行动，先旋转太阳系，再选择一项科技。\n· 科技分为探测器、望远镜和计算机三类，每类有四种。\n· 只能选择自己尚未拥有、且仍有剩余板块的科技。\n· 全局首位研究某种科技的玩家，额外获得 2 分。\n· 每次研究还会获得所领取板块显示的即时奖励，并执行该科技的获得效果。\n· 即时奖励可能为 1 点推广、1 点能量、选择一张牌，或获得 3 分。\n· 卡牌提供的研究不另支付 6 点推广，但仍须旋转并遵守科技类别限制。\n探测器科技：\n· 双探测器：太空中的探测器上限提高至两个，获得时可免费发射一个。\n· 小行星导航：离开小行星不再额外消耗移动，进入小行星格位获得 1 点推广。\n· 着陆改进：行星和卫星着陆的能量费用减少 1 点。\n· 卫星探测：允许在对应行星的卫星上着陆，按卫星奖励结算。\n望远镜科技：\n· 拓展观测：获得时取得 2 个数据；地球扫描可改在相邻的一个扇区进行。\n· 项目观测：扫描时可从手牌弃置一张牌，在对应信号颜色的扇区额外标记一次。\n· 水星观测：扫描时可支付 1 点推广，在水星所在扇区额外标记一次信号。\n· 协同发射：扫描时可支付 1 点能量发射一个探测器，或免费获得 1 次移动。\n· 协同发射的两种效果只能选择一种；发射仍须满足探测器数量上限。\n计算机科技：\n· 领取计算机科技后，将它安装到计算机中任意一个尚未安装科技的位置。\n· 可以安装到已有数据的位置，但不会因此再次获得该位置的奖励。\n· 四种计算机科技的上排奖励均为 2 分，替代该格原有奖励。\n· 推广计算机的下排奖励为 2 点推广。\n· 项目计算机的下排奖励允许选择获得一张牌。\n· 能量计算机的下排奖励为 1 点能量。\n· 信用计算机的下排奖励为 1 点信用。\n其他自由行动：\n· 从手牌弃置一张牌，获得其左上角显示的 1 点资源或 1 次移动。\n· 支付 2 点信用，可获得 1 点能量，或选择获得一张牌。\n· 支付 2 点能量，可获得 1 点信用，或选择获得一张牌。\n· 从手牌弃置两张牌，可获得 1 点信用、1 点能量或选择获得一张牌。\n· 支付 3 点推广，可获得一张公开项目，或从牌库顶抽取一张牌。\n· 为扫描、交换或退出本轮而弃置卡牌时，不领取左上角的弃置收益。\n· 移动探测器、放置数据和领取符合条件的任务奖励也属于自由行动。\n· 自由行动没有统一次数上限，但每次都须满足资源和效果条件。\n项目牌与任务：\n· 打出项目牌时，从手牌选择一张，支付其信用费用，并依次执行牌面效果。\n· 任务牌和需要保留的项目放入个人区域；其余项目执行后进入弃牌堆。\n· 事件任务只记录该任务牌打出后发生的事件，不能追溯之前的行动。\n· 同一事件在自己所有事件任务中，最多领取一个尚未领取的奖励。\n· 可以放弃本次事件奖励；同一事件不能留待之后再领取。\n· 每个任务奖励圈只能领取一次；已经标记的奖励圈不能重复使用。\n· 先驱者 11 号任务：自己的探测器之后访问木星获得 1 个数据，访问土星获得 4 分。\n· 望远镜时间分配：之后每完成一次扫描，可领取一个未完成奖励圈，在对应颜色的扇区标记信号。\n· 轨道修正是即时项目：本回合发生过同环移动时，获得3分和1点推广。\n· 条件任务可以检查本回合已经发生的移动，与事件任务的触发方式不同。\n文明痕迹与发现：\n三种文明痕迹的颜色对应关系如下：\n· 红色：信号痕迹。\n· 黄色：生命痕迹。\n· 蓝色：分析痕迹。\n获得痕迹时，可以选择任意文明中颜色相符的空发现格，或已发现文明的研究位置。发现格给予1点推广，左侧文明另获得5分，右侧获得3分。也可以放入任一文明的溢出区获得3分；溢出标记保留所选颜色，计入痕迹数量。研究位置按所示奖励结算，部分需要支付数据或地外化石；最上方有无限标记的位置可以重复使用。\n三个发现格均填满时，在回合结束且里程碑处理完后揭示文明。每位玩家按自己的发现格标记数量取得文明牌。普通文明牌可以作为手牌、弃置或收入；钻探者牌另行保管。\n回合结束的里程碑：\n达到25、50、70分时，分别标记一块自己未标记的黄金板块，按全体玩家选择该板块的先后占据档位。四块板块在准备时分别随机选择正面或反面。所有玩家按当前回合玩家起的座次处理自己的黄金与文明里程碑，不可在此期间执行自由行动。\n两人局在20分、30分各有两个中立标记；三人局各一个；四人局没有。每位玩家首次达到相应分数时只取一个尚有剩余的中立标记，按从左至右的顺序放入空发现格。中立标记不奖励玩家，可能促成发现。中立里程碑最后处理。\n退出与五轮流程：\n退出本轮是主行动。选择退出前可以执行自由行动，之后按顺序将手牌弃至4张；若为本轮首位退出者，旋转太阳系；再从该轮私有候选牌中选择1张。前四轮各有一堆人数加一张的轮末牌。可以延迟决定，直到下一位玩家退出时交接；候选牌只供持有者查看。第五轮仍须旋转，但没有轮末选牌。\n所有玩家退出并完成选牌后，弃置候选堆最后一张牌。前四轮结束时，每人获得3点信用、2点能量、从牌库抽1张牌，以及收入区所有牌的收入；再将起始玩家顺移一位，开始下一轮。\n五种文明：\n· 硫铵虫：木星和土星各有3个秘密样本，另1个公开成为蓝色研究位置。指定文明牌允许采集样本：查看所在行星的所有样本，秘密选择一个，放置样本舱。样本舱按探测器移动，不计入探测器上限，不可环绕或着陆。可以用自己的任意样本舱完成对应目的地的运输任务；交付时领取样本奖励，并将样本公开放到文明板上，成为新的蓝色研究位置。\n· 异常点：在地球扇区及其左右相隔三个扇区的最外环，各放一个随机面的异常点。每次太阳系旋转后，若地球与异常点在同一扇区，对应颜色研究列中位置最高的玩家领取奖励；最高位置可重复标记，后来者在上。访问异常点不提供奖励。\n· 奥陌陌：将奥陌陌放到第三转盘的指定格位；它视为行星，访问获得1点推广，可环绕或着陆。奥陌陌所在扇区的信号可以改放到其独立信号槽；第一格获得1分，第三格获得2分，每个未填满槽位仍提供数据。主行动后填满时，参与玩家各获得1个地外化石，清空并补满信号槽，不产生扇区胜者。化石用于部分研究位置和卡牌，剩余化石不计分。\n· 半人马族：发现时每人设置一个当前分数加15的消息阈值；达到后选择一项尚可用的文明奖励。该文明牌支付能量，每打出一张，再设置一个当前分数加15的阈值，先执行白色区域，达到阈值后按发送顺序执行绿色区域。消息牌不算任务。研究位置的数据费用只能从数据池支付。\n· 钻探者：发现时每人取得3张秘密牌，再按自己的发现贡献各多取1张，每份贡献可立即秘密打出1张。以发现时领先者分数加20、加40设置两个阈值；每人达到时可再秘密打出1张，第二个阈值需要支付1点信用。秘密牌不属于手牌，不能弃置或作为收入，也不算任务或终局项目。文明研究位置另增加公开危险值。\n终局与胜负：\n第五轮全部玩家退出，且最后一次旋转、任务响应、里程碑和发现均处理完毕后，先计已打出的终局项目，再计黄金板块，最后揭示钻探者秘密项目并按条件加分。\n黄金板块按自己占据的档位，逐组计算科技组合、已完成任务、收入组合、三色痕迹组合或扇区胜利与棋件组合；只计算放入收入区的牌，不计每轮固定获得的3点信用、2点能量和1张随机牌。事件任务所有奖励圈均完成才算完成一张任务。《索尔维会议》额外选择一块自己未标记的黄金板块，按最右档计分。\n最后合计公开危险值和已打出秘密牌的危险值，危险最高的所有玩家各扣除总分十分之一，向下取整。总分最高者获胜，同分并列。基础版仅支持2至4人，不包含官方单人对手、Space Agencies扩展及Promo牌。",
			invalidAction: "此时无法执行该操作，请重新选择。",
			resources: {
				credit: "信用",
				energy: "能量",
				publicity: "推广",
				data: "数据",
				vp: "分数",
				card: "牌",
				move: "移动"
			},
			planets: {
				earth: "地球",
				mercury: "水星",
				venus: "金星",
				mars: "火星",
				jupiter: "木星",
				saturn: "土星",
				uranus: "天王星",
				neptune: "海王星"
			},
			moons: {
				phobos: "火卫一与火卫二",
				io: "木卫一",
				europa: "木卫二",
				ganymede: "木卫三",
				callisto: "木卫四",
				enceladus: "土卫二",
				titan: "土卫六",
				titania: "天卫三",
				triton: "海卫一"
			},
			stars: {
				procyon: "南河三",
				vega: "织女星",
				sirius: "天狼星 A",
				barnard: "巴纳德星",
				kepler: "开普勒 22",
				proxima: "比邻星",
				virginis: "室女座 61",
				pictoris: "绘架座 β"
			},
			species: {
				mascamites: "硫铵虫",
				anomalies: "异常点",
				oumuamua: "奥陌陌",
				centaurians: "半人马族",
				exertians: "钻探者"
			},
			cards: {
				pioneer: "先驱者 11 号任务",
				pioneerText: "事件任务：打出此牌后，你的探测器每次访问木星或土星时，可以领取对应奖励。木星奖励为 1 个数据，土星奖励为 4 分；每项奖励只能领取一次。",
				entry: "进入大气层",
				entryText: "移除自己的一个环绕器，获得 3 分和 1 个数据。然后从公开项目中选择一张牌，或从牌库顶抽取一张牌。",
				dragonfly: "蜻蜓号",
				dragonflyText: "将自己的一个探测器免费着陆到其所在的行星或对应卫星上。可以选择已被占用的位置，并获得该位置的奖励。卫星着陆仍须拥有“卫星探测”科技。",
				lightsail: "光帆",
				lightsailText: "获得 4 次移动。本回合接下来每访问一个不同的行星，获得 1 分，地球也包括在内。同一行星最多计分一次，停留在原格位不视为再次访问。",
				array: "平方千米阵列",
				arrayText: "依次弃置公开项目区的 3 张牌，每弃置一张，在与其信号颜色相同的一个扇区标记一次信号。三张牌全部弃置后再补充公开项目。每个不同的目标扇区给予 2 分。",
				focus: "专注研究",
				focusText: "旋转太阳系，然后研究任意一项尚未拥有的科技。完成研究后，你每拥有一项与本次研究同类别的科技，获得 2 分，包括刚获得的科技。",
				sample: "样本返回",
				sampleText: "移除自己在任意行星或卫星上的一个着陆器，然后标记一次任意颜色的痕迹。",
				telescope: "望远镜时间分配",
				telescopeText: "事件任务：打出此牌后，每次完成扫描，可以选择一个尚未领取的奖励圈，并标记该圈显示颜色的痕迹。每个奖励圈只能领取一次，同一次扫描最多领取一个任务奖励。",
				solvay: "索尔维会议",
				solvayText: "获得 2 点推广。最终计分时，选择一块自己尚未标记的黄金计分板块，按其最右侧档位计分。",
				pixl: "PIXL 行星岩石化学 X 射线仪",
				pixlText: "旋转太阳系，然后研究一项尚未拥有的计算机科技。完成研究后，你每拥有 1 点推广，获得 1 分；推广不会因此消耗。计分前可以完成此时允许的自由行动。",
				correction: "轨道修正",
				correctionText: "获得 1 次移动。条件任务：若本回合已经进行过至少一次同一轨道环内的移动，可以领取 3 分和 1 点推广。此项任务奖励只能领取一次。",
				window: "最佳发射窗口",
				windowText: "免费发射一个探测器，仍须遵守探测器数量上限。然后检查地球所在扇区向外的三个格位，每有一个其他行星或彗星，获得 1 次移动，最多获得 3 次移动。"
			},
			techs: {
				capacity: "双探测器",
				capacityText: "你在太空中可以同时拥有最多两个可移动的探测器。获得此科技时，可以免费发射一个探测器，但仍须遵守此上限。",
				asteroid: "小行星导航",
				asteroidText: "离开小行星格位不再额外消耗一次移动。每次进入小行星格位时，获得 1 点推广。",
				landing: "着陆改进",
				landingText: "在行星或卫星上着陆时，支付的能量减少 1 点。此减免可与该行星已有环绕器提供的减免同时生效。",
				moon: "卫星探测",
				moonText: "允许将探测器着陆到其所在行星的卫星上，能量费用与在该行星着陆相同。通常每颗卫星只能容纳一个着陆器，奖励按卫星说明执行。",
				adjacent: "拓展观测",
				adjacentText: "获得此科技时，获得 2 个数据。扫描时，可以将原本在地球扇区放置的信号，改放到与该扇区相邻的一个扇区。",
				hand: "项目观测",
				handText: "每次扫描时，可以额外从手牌弃置一张牌，在与该牌右上角信号颜色相同的一个扇区标记一次信号。此处弃置不获得卡牌左上角的收益。",
				mercury: "水星观测",
				mercuryText: "每次扫描时，可以额外支付 1 点推广，在水星当前所在的扇区标记一次信号。",
				launch: "协同发射",
				launchText: "每次扫描时，可以额外选择一种效果：支付 1 点能量发射一个探测器，或免费获得 1 次移动。发射仍须满足探测器数量上限。",
				publicity: "推广计算机",
				publicityText: "向此科技的上排格位放入一个数据时，获得 2 分，替代该格原有奖励。向下排格位放入一个数据时，获得 2 点推广；下排放置要求上排已有数据。",
				card: "项目计算机",
				cardText: "向此科技的上排格位放入一个数据时，获得 2 分，替代该格原有奖励。向下排格位放入一个数据时，选择获得一张公开项目，或从牌库抽取一张牌；下排放置要求上排已有数据。",
				energy: "能量计算机",
				energyText: "向此科技的上排格位放入一个数据时，获得 2 分，替代该格原有奖励。向下排格位放入一个数据时，获得 1 点能量；下排放置要求上排已有数据。",
				credit: "信用计算机",
				creditText: "向此科技的上排格位放入一个数据时，获得 2 分，替代该格原有奖励。向下排格位放入一个数据时，获得 1 点信用；下排放置要求上排已有数据。"
			},
			prompt: {
				setup: "选择一张手牌作为收入",
				main: "执行一个主行动",
				effect: "继续完成当前行动",
				free: "完成当前自由行动",
				response: "选择是否领取任务奖励",
				sector: "选择一个已填满的扇区结算",
				after: "可执行自由行动，或结束回合",
				pass: "弃牌至四张，然后确认退出本轮",
				gold: "选择尚未标记的黄金板块",
				roundEnd: "所有玩家已退出本轮",
				discovery: "已发现外星文明",
				finished: "对局结束",
				finalGold: "选择索尔维会议的计分板块",
				roundCard: "选择一张轮末项目牌"
			},
			launch: "发射 · 2 信用",
			orbit: "环绕 · 1 信用＋1 能量",
			land: "着陆",
			scan: "扫描 · 1 信用＋2 能量",
			analyze: "分析 · 1 能量",
			research: "研究 · 6 推广",
			pass: "退出本轮",
			playCard: "打出项目牌",
			endTurn: "结束回合",
			continue: "继续",
			finishMovement: "结束这次移动",
			finishScan: "完成扫描",
			moveTo: "前往第 {{ring}} 环、第 {{sector}} 扇区 · {{n}} 次移动",
			moveWithEnergy: "前往第 {{ring}} 环、第 {{sector}} 扇区 · 另付 {{n}} 能量",
			rotateResearch: "旋转太阳系并选择科技",
			installTech: "安装到第 {{n}} 格",
			tuck: "作为收入",
			takeCard: "获得此牌",
			drawCard: "抽取牌库顶牌",
			discardSignal: "弃置此牌，在第 {{n}} 扇区标记信号",
			markSector: "在第 {{n}} 扇区标记信号",
			scanEarth: "扫描地球扇区",
			scanRow: "弃置公开牌并标记信号",
			scanHand: "弃置手牌并标记信号",
			scanMercury: "扫描水星扇区 · 1 推广",
			scanProbe: "发射或移动",
			scanLaunch: "发射 · 1 能量",
			gainMove: "获得 1 次移动",
			markTrace: "标记文明{{n}}的{{color}}",
			overflow: "文明 {{n}}：放入溢出位置 · 3 分",
			landPlanet: "在行星上着陆 · 首次数据 {{n}}",
			removeFigure: "移除此棋件",
			placeUpper: "放入计算机第 {{n}} 格",
			placeLower: "放入第 {{n}} 格下排",
			discardBonus: "弃牌获得角标收益",
			exchange: "用 2 {{from}} 交换 1 {{to}}",
			buyCard: "购买此牌 · 3 推广",
			buyDeck: "抽取一张牌 · 3 推广",
			completeMission: "完成任务",
			claimMission: "领取第 {{n}} 个任务奖励",
			declineMission: "本次不领取",
			discardCard: "弃置此牌",
			confirmPass: "确认退出本轮",
			resolveSector: "结算第 {{n}} 扇区",
			markGold: "标记黄金板块 {{n}}",
			solarSystem: "太阳系",
			planetaryBoard: "行星探索",
			computer: "计算机",
			dataPool: "数据池",
			technologies: "科技研究",
			probeTech: "探测器科技",
			telescopeTech: "望远镜科技",
			computerTech: "计算机科技",
			hand: "手牌",
			market: "公开项目",
			missions: "任务与项目",
			income: "收入",
			actions: "行动",
			freeActions: "自由行动",
			decisions: "当前选择",
			details: "详情",
			history: "行动记录",
			noChoices: "当前没有可执行的操作",
			waiting: "等待 {{name}}",
			nextRotation: "下次旋转：第 {{n}} 盘",
			sector: "第 {{n}} 扇区",
			ring: "第 {{n}} 环",
			signalCount: "信号 {{n}} / {{max}}",
			handCount: "手牌 {{n}}",
			cost: "费用：{{n}} 信用",
			freeBonus: "弃牌：{{name}} ×1",
			incomeBonus: "收入：{{name}} ×1",
			deckCount: "牌库 {{n}}",
			unnamedSpecies: "未知文明 {{n}}",
			traceNames: {
				red: "信号痕迹",
				yellow: "生命痕迹",
				blue: "分析痕迹"
			},
			choose: "选择行动",
			ownArea: "个人研究区",
			empty: "空",
			firstReward: "首次奖励",
			completed: "已完成",
			upperReward: "上排第 {{n}} 格",
			lowerReward: "科技下排第 {{n}} 格",
			marker: "{{name}} 的标记",
			probe: "{{name}} 的探测器",
			goldCategories: {
				tech: "科技",
				mission: "任务",
				signal: "信号",
				planet: "行星"
			},
			techReward: "即时奖励：{{name}} ×{{n}}",
			techRemaining: "剩余 {{n}}",
			researchFirst: "首次领取另得 2 分",
			gainEffect: "获得 {{n}} {{name}}",
			moveEffect: "可用移动：{{n}}",
			publicityEffect: "按当前推广计分",
			techEffect: "按刚研究的科技类别计分",
			chooseEffect: "请选择目标或继续完成效果",
			zoom: "放大盘面",
			fit: "适合屏幕",
			orbiters: "环绕器 {{n}}",
			landers: "着陆器 {{n}}",
			noHand: "没有手牌",
			skipIncome: "不增加收入",
			cardBrief: {
				pioneer: "访问木星获得数据；访问土星获得分数。",
				entry: "移除环绕器，获得分数、数据和牌。",
				dragonfly: "免费着陆一次，可选择已占用位置并获得覆盖奖励。",
				lightsail: "本回合每访问一个不同星球获得 1 分，包括地球。",
				array: "弃置 3 张公开牌并标记信号；每个不同扇区获得 2 分。",
				focus: "研究任意科技；每拥有一个该类别科技获得 2 分。",
				sample: "移除一个着陆器，标记黄色生命痕迹。",
				telescope: "每次扫描后，可标记一个尚未领取的指定颜色信号。",
				solvay: "获得 2 推广；终局结算一块未标记的黄金板块。",
				pixl: "研究计算机科技；按当前推广获得分数。",
				correction: "获得1次移动；若本回合在同一轨道环内移动过，获得3分和1点推广。",
				window: "免费发射；按地球扇区的其他星球和彗星获得移动。"
			},
			discardBenefit: "弃置收益",
			civilizationTraces: "文明痕迹",
			overflowCount: "溢出标记 {{n}}",
			ownedTech: "已研究",
			neutralMarker: "中立标记",
			currentPlayer: "当前行动",
			inspectSector: "查看第 {{n}} 扇区",
			anyTrace: "任意颜色痕迹",
			capsulePosition: "第{{ring}}环 · 第{{sector}}扇区",
			messageBonuses: {
				trace: "标记任意颜色的痕迹",
				cardEnergy: "获得一张半人马族牌和1点能量",
				publicity: "获得3点推广",
				points: "获得8分"
			},
			revealedCards: "展示的手牌",
			sampleContents: "样本舱内容",
			sampleReveals: "已展示的样本记录",
			anomalyRewards: "异常点奖励",
			log: {
				rotate: "旋转第 {{n}} 盘",
				launch: "发射探测器",
				signal: "在第 {{n}} 扇区标记信号",
				sectorWon: "赢得第 {{n}} 扇区",
				land: "探测器着陆",
				orbit: "探测器进入环绕轨道",
				trace: "标记文明 {{n}} 的痕迹",
				research: "研究科技",
				play: "打出项目 #{{n}}",
				round: "开始第 {{n}} 轮",
				revealCard: "展示项目 #{{n}}"
			}
		},
		en: {
			projects: {
				p1: "Pioneer 11 Mission",
				p1Text: "Triggered mission (after this card is played; claim at most one reward per event, each reward once): visit (Jupiter): Gain 1 data; visit (Saturn): Gain 4 points.",
				p2: "Mariner 10 Mission",
				p2Text: "Triggered mission (after this card is played; claim at most one reward per event, each reward once): visit (Mercury): Draw 1 card from the deck; visit (Venus): Gain 1 publicity.",
				p3: "Voyager 2 Mission",
				p3Text: "Triggered mission (after this card is played; claim at most one reward per event, each reward once): visit (Uranus): Gain 1 energy; visit (Neptune): Gain 1 credit.",
				p4: "Galileo Mission",
				p4Text: "Triggered mission (after this card is played; claim at most one reward per event, each reward once): visit (Venus): Gain 1 publicity; visit (Jupiter): Gain 1 data.",
				p5: "Venera Probe",
				p5Text: "Launch a probe for free. Gain 1 publicity. Mission: when your orbiters and landers at Venus, including moons is at least 1, claim: Gain 7 points. Gain 1 publicity.",
				p6: "Juno Probe",
				p6Text: "Launch a probe for free. Gain 1 data. Mission: when your orbiters and landers at Jupiter, including moons is at least 1, claim: Gain 7 points. Gain 1 publicity.",
				p7: "MESSENGER Probe",
				p7Text: "Launch a probe for free. Gain 1 movement. Mission: when your orbiters and landers at Mercury, including moons is at least 1, claim: Gain 7 points. Gain 1 publicity.",
				p8: "Cassini Probe",
				p8Text: "Launch a probe for free. Draw 1 card from the deck. Mission: when your orbiters and landers at Saturn, including moons is at least 1, claim: Gain 6 points. Gain 1 publicity.",
				p9: "Falcon Heavy",
				p9Text: "Launch a probe for free, ignoring your limit of probes in space for this launch. Launch a probe for free, ignoring your limit of probes in space for this launch. Gain 1 publicity.",
				p10: "ODINUS Mission",
				p10Text: "Research one probe technology for free. Mission: when your orbiters and landers at Neptune, including moons is at least 1 and your orbiters and landers at Uranus, including moons is at least 1, claim: Gain 5 points. Draw 1 card from the deck.",
				p11: "Grant",
				p11Text: "Draw a card, reveal it and gain its corner benefit without discarding it.",
				p12: "Europa Clipper",
				p12Text: "Land for free, including on a moon without moon technology. End-game scoring: Score 3 points per your orbiters and landers at Jupiter, including moons.",
				p13: "Perseverance Rover",
				p13Text: "Land for free. Gain 4 points if this action landed on Mars, Mercury or any moon.",
				p14: "Mars Science Laboratory",
				p14Text: "Gain 1 publicity. Gain 2 data. End-game scoring: Score 4 points per your orbiters and landers at Mars, including moons.",
				p15: "Atmospheric Entry",
				p15Text: "Remove one of your orbiters to gain 3 points, 1 data and a card of your choice.",
				p16: "Dragonfly",
				p16Text: "Land for free, even on an occupied space.",
				p17: "OSIRIS-REx",
				p17Text: "Choose your probe. Gain 2 data if it is on an asteroid, plus 1 data for each adjacent asteroid space.",
				p18: "Hayabusa",
				p18Text: "If your probes on asteroids is at least 1, Mark one yellow trace.",
				p19: "Gravitational Slingshot",
				p19Text: "For the rest of this turn, each planet visit may grant 1 movement instead of 1 publicity. Gain 2 movement.",
				p20: "Mercury Flyby",
				p20Text: "Gain 2 movement. If visits to Mercury this turn is at least 1, Gain 4 points.",
				p21: "Venus Flyby",
				p21Text: "Gain 2 movement. If visits to Venus this turn is at least 1, Gain 3 points.",
				p22: "Mars Flyby",
				p22Text: "Gain 2 movement. If visits to Mars this turn is at least 1, Gain 4 points.",
				p23: "Jupiter Flyby",
				p23Text: "Gain 2 movement. If visits to Jupiter this turn is at least 1, Gain 4 points.",
				p24: "Saturn Flyby",
				p24Text: "Gain 3 movement. If visits to Saturn this turn is at least 1, Gain 6 points.",
				p25: "Lightsail",
				p25Text: "Gain 1 point for each different planet visited this turn, including Earth. Gain 4 movement.",
				p26: "Through the Asteroid Belt",
				p26Text: "Ignore the extra movement cost of leaving asteroids for the rest of this turn. Gain 2 movement.",
				p27: "Hubble Space Telescope",
				p27Text: "Gain 1 movement. Mark 1 signal in a sector containing your probe.",
				p28: "Kepler Space Telescope",
				p28Text: "Gain 1 movement. Mark 2 signals in a sector containing your probe.",
				p29: "James Webb Space Telescope",
				p29Text: "Gain 1 movement. Mark 1 signal in a sector containing your probe and 1 signal in each adjacent sector.",
				p30: "Great Observatories Project",
				p30Text: "Mark 1 signals in sectors containing up to three different probes belonging to any player.",
				p31: "Space Launch System",
				p31Text: "Launch a probe for free. Gain 1 movement. Mission: when your landers on planets, excluding moons is at least 3, claim: Gain 1 credit.",
				p32: "Mercury Exploration Program",
				p32Text: "Mark 2 signals in the sector containing Mercury. Mission: when your orbiters and landers at Mercury, including moons is at least 1, claim: Gain 4 points.",
				p33: "Venus Exploration Program",
				p33Text: "Mark 2 signals in the sector containing Venus. Mission: when your orbiters and landers at Venus, including moons is at least 1, claim: Gain 4 points.",
				p34: "Mars Exploration Program",
				p34Text: "Mark 2 signals in the sector containing Mars. Mission: when your orbiters and landers at Mars, including moons is at least 1, claim: Gain 4 points.",
				p35: "Jupiter Exploration Program",
				p35Text: "Mark 2 signals in the sector containing Jupiter. Mission: when your orbiters and landers at Jupiter, including moons is at least 1, claim: Gain 4 points.",
				p36: "Saturn Exploration Program",
				p36Text: "Mark 2 signals in the sector containing Saturn. Mission: when your orbiters and landers at Saturn, including moons is at least 1, claim: Gain 4 points.",
				p37: "Proxima Centauri Observation",
				p37Text: "Mark 2 signals in the sector containing Proxima Centauri. Mission: when your wins in Proxima Centauri is at least 2, claim: Gain 4 points. Gain 1 publicity.",
				p38: "Barnard's Star Observation",
				p38Text: "Mark 2 signals in the sector containing Barnard’s Star. End-game scoring: Score 3 points per your wins in Barnard’s Star.",
				p39: "61 Virginis Observation",
				p39Text: "Mark 2 signals in the sector containing 61 Virginis. Mission: when your wins in 61 Virginis is at least 2, claim: Gain 4 points. Gain 1 publicity.",
				p40: "Kepler 22 Observation",
				p40Text: "Mark 2 signals in the sector containing Kepler 22. End-game scoring: Score 3 points per your wins in Kepler 22.",
				p41: "Sirius A Observation",
				p41Text: "Mark 2 signals in the sector containing Sirius A. Mission: when your wins in Sirius A is at least 2, claim: Gain 4 points. Gain 1 publicity.",
				p42: "Procyon Observation",
				p42Text: "Mark 2 signals in the sector containing Procyon. End-game scoring: Score 3 points per your wins in Procyon.",
				p43: "Beta Pictoris Observation",
				p43Text: "Mark 1 signal in the sector containing Beta Pictoris. Mission: when your wins in Beta Pictoris is at least 1, claim: Gain 2 points. Gain 1 publicity.",
				p44: "Vega Observation",
				p44Text: "Mark 1 signal in the sector containing Vega. End-game scoring: Score 3 points per your wins in Vega.",
				p45: "Allen Telescope Array",
				p45Text: "Discard 2 cards from the card row and mark a signal matching each card’s colour. Then refill the card row. Gain 1 energy if a sector was completed this turn.",
				p46: "ALMA Observatory",
				p46Text: "Discard 2 cards from the card row and mark a signal matching each card’s colour. Then refill the card row. Draw 1 card if a sector was completed this turn.",
				p47: "Very Large Array",
				p47Text: "Discard 2 cards from the card row and mark a signal matching each card’s colour. Then refill the card row. Gain 1 data if a sector was completed this turn.",
				p48: "Breakthrough Starshot",
				p48Text: "Gain 1 movement. Mark 1 signal in red sectors.",
				p49: "Breakthrough Watch",
				p49Text: "Gain 1 movement. Mark 1 signal in yellow sectors.",
				p50: "Square Kilometre Array",
				p50Text: "Discard 3 cards from the card row and mark a signal matching each card’s colour. Then refill the card row. Gain 2 points for each different sector where this action marked a signal.",
				p51: "Lovell Telescope",
				p51Text: "Gain 1 data. Scan for free; pay the costs of any additional technology steps you use. Mission: when your current publicity is at least 8, claim: Gain 3 points. Draw 1 card from the deck.",
				p52: "Parkes Observatory",
				p52Text: "Scan for free; pay the costs of any additional technology steps you use. Gain 2 points for each red signal marked during this action.",
				p53: "Deep Synoptic Array",
				p53Text: "Scan for free; pay the costs of any additional technology steps you use. Gain 2 points for each yellow signal marked during this action.",
				p54: "VERITAS Telescopes",
				p54Text: "Scan for free; pay the costs of any additional technology steps you use. Gain 2 points for each blue signal marked during this action.",
				p55: "Arecibo Observatory",
				p55Text: "Scan for free; pay the costs of any additional technology steps you use. Mark 1 signal in any sector.",
				p56: "Breakthrough Listen",
				p56Text: "Gain 1 movement. Mark 1 signal in blue sectors.",
				p57: "Effelsberg Telescope Construction",
				p57Text: "Draw 1 card from the deck. Research one telescope technology for free.",
				p58: "Uranus Orbiter and Probe",
				p58Text: "Launch a probe for free. Mission: when your orbiters and landers at Uranus, including moons is at least 1, claim: Gain 3 points. Draw 1 card from the deck.",
				p59: "Ion Propulsion System",
				p59Text: "Gain 1 energy. Research one probe technology for free.",
				p60: "Trident Probe",
				p60Text: "Launch a probe for free. Mission: when your orbiters and landers at Neptune, including moons is at least 1, claim: Gain 4 points. Gain 1 data.",
				p61: "Quantum Computer",
				p61Text: "Research one computer technology for free. Mission: when your current points is at least 50, claim: You may tuck a card from your hand for income and immediately gain its income.",
				p62: "Onsala Telescope Construction",
				p62Text: "Research one telescope technology for free. End-game scoring: Score 2 points per your red traces, including overflow.",
				p63: "SHERLOC",
				p63Text: "Research one probe technology for free. End-game scoring: Score 2 points per your yellow traces, including overflow.",
				p64: "ALICE",
				p64Text: "Research one computer technology for free. Mission: when species with at least one of your blue traces is at least 2, claim: Gain 2 data.",
				p65: "FAST Telescope Construction",
				p65Text: "Discard 2 cards from the card row and mark a signal matching each card’s colour. Then refill the card row. Research one telescope technology for free.",
				p66: "GMRT Telescope Construction",
				p66Text: "Research one telescope technology for free. Mission: when species with at least one of your red traces is at least 2, claim: Gain 2 points. Gain 1 energy.",
				p67: "Yevpatoria Telescope Construction",
				p67Text: "Gain 1 publicity. Research one telescope technology for free. You may discard a card from your hand to mark a signal matching its colour.",
				p68: "DUNE",
				p68Text: "Research one computer technology for free. End-game scoring: Score 2 points per your blue traces, including overflow.",
				p69: "Large Hadron Collider",
				p69Text: "Gain 1 data. Research one computer technology for free.",
				p70: "ATLAS",
				p70Text: "Research one computer technology for free. Mission: when your blue traces, including overflow is at least 3, claim: Gain 3 points. Gain 1 data.",
				p71: "Focused Research",
				p71Text: "Research one technology for free. Gain 2 points for each technology you own in the category just researched.",
				p72: "Scientific Cooperation",
				p72Text: "Research one technology for free. Gain 2 publicity if another player already owns the technology you chose.",
				p73: "Clean Space Initiative",
				p73Text: "Discard all cards in the card row, gain their corner benefits, then refill the row.",
				p74: "Pre-launch Testing",
				p74Text: "Launch a probe for free. Reveal any cards in your hand with a movement corner. Gain 1 movement per card revealed.",
				p75: "Extremophiles Study",
				p75Text: "Choose a colour and mark a trace of that colour. Then gain 1 point for each of your traces of that colour.",
				p76: "NASA Research Center",
				p76Text: "Triggered mission (after this card is played; claim at most one reward per event, each reward once): research technology (probe): Gain 1 energy; research technology (telescope): Gain 1 publicity; research technology (computer): Draw 1 card from the deck.",
				p77: "NASA Astrobiology Institute",
				p77Text: "Gain 1 publicity. Triggered mission (after this card is played; claim at most one reward per event, each reward once): mark a trace (red): Gain 1 data; mark a trace (yellow): Gain 1 data; mark a trace (blue): Gain 1 data.",
				p78: "SETI Institute",
				p78Text: "Gain 1 publicity. Triggered mission (after this card is played; claim at most one reward per event, each reward once): complete a scan: Gain 2 data; complete a scan: Draw 1 card from the deck; complete a scan: Gain 4 points.",
				p79: "ISS",
				p79Text: "Gain 1 publicity. Triggered mission (after this card is played; claim at most one reward per event, each reward once): launch a probe: Gain 1 credit; launch a probe: Draw 1 card from the deck; launch a probe: Gain 5 points.",
				p80: "Cape Canaveral SFS",
				p80Text: "Triggered mission (after this card is played; claim at most one reward per event, each reward once): launch a probe: Gain 1 movement; launch a probe: Gain 1 movement; launch a probe: Gain 1 movement.",
				p81: "International Collaboration",
				p81Text: "Research one technology for free that another player owns, without rotating the solar system or gaining the tile reward.",
				p82: "Johnson Space Center",
				p82Text: "Triggered mission (after this card is played; claim at most one reward per event, each reward once): enter orbit: Gain 2 publicity; land: Gain 2 publicity.",
				p83: "Wow! Signal",
				p83Text: "Gain 1 publicity. Mark 2 signals in the sector containing Earth.",
				p84: "Sample Return",
				p84Text: "Remove one of your landers, including on a moon, to mark a yellow trace.",
				p85: "Starship",
				p85Text: "Launch a probe for free. Research one probe technology for free.",
				p86: "Giant Magellan Telescope",
				p86Text: "Discard 1 card from the card row and mark a signal matching each card’s colour. Then refill the card row. End-game scoring: Score 1 points per sectors containing your signals.",
				p87: "Project Longshot",
				p87Text: "Research one probe technology for free. Mission: when the greatest movement distance from your probes to Earth is at least 5, claim: Gain 3 points. Gain 1 energy.",
				p88: "Chandra Space Observatory",
				p88Text: "Mark 2 signals in a sector containing your probe. Mission: when sectors containing your signals is at least 4, claim: Gain 2 publicity.",
				p89: "NIAC Program",
				p89Text: "Draw 3 cards from the deck. Mission: when cards in your hand is at most 0, claim: Draw 1 card from the deck.",
				p90: "Fuel Tanks Construction",
				p90Text: "Gain 1 energy for each of cards in your hand with energy income.",
				p91: "Fusion Reactor",
				p91Text: "Gain 1 energy for each of your tucked energy income cards. Tuck this card for income and immediately gain its income.",
				p92: "NASA Image of the Day",
				p92Text: "Gain 2 publicity. Gain 1 publicity for each of your tucked cards income cards. Tuck this card for income and immediately gain its income.",
				p93: "Government Funding",
				p93Text: "Gain 3 points for each of your tucked credit income cards. Tuck this card for income and immediately gain its income.",
				p94: "Popularization of Science",
				p94Text: "Gain 1 publicity. Triggered mission (after this card is played; claim at most one reward per event, each reward once): research technology (probe): Gain 2 publicity; research technology (telescope): Gain 2 publicity; research technology (computer): Gain 2 publicity.",
				p95: "Near-Earth Asteroids Survey",
				p95Text: "Gain 2 publicity. Mission: when your probes on asteroids adjacent to Earth is at least 1, claim: Gain 5 points. Draw 1 card from the deck.",
				p96: "Tardigrades Study",
				p96Text: "Gain 1 publicity. Gain 1 data. Draw 1 card from the deck. Mission: when your yellow traces, including overflow is at least 3, claim: Mark one yellow trace.",
				p97: "Apollo 11 Mission",
				p97Text: "Research one probe technology for free. Mission: when species with at least one of your yellow traces is at least 2, claim: Gain 2 points. Draw 1 card from the deck.",
				p98: "Coronal Spectrograph",
				p98Text: "Mark one red trace for a species where you already have a trace of that colour.",
				p99: "Electron Microscope",
				p99Text: "Mark one yellow trace for a species where you already have a trace of that colour.",
				p100: "Exascale Supercomputer",
				p100Text: "Mark one blue trace for a species where you already have a trace of that colour.",
				p101: "Telescope Time Allocation",
				p101Text: "Triggered mission (after this card is played; claim at most one reward per event, each reward once): complete a scan: Mark 1 signal in yellow sectors; complete a scan: Mark 1 signal in red sectors; complete a scan: Mark 1 signal in blue sectors.",
				p102: "Linguistic Analysis",
				p102Text: "Gain 3 publicity. Mission: when species where you have all three trace colours is at least 1, claim: Mark a trace of any colour for a species where you have all three trace colours.",
				p103: "Westerbork Synthesis Radio Telescope",
				p103Text: "Research one telescope technology for free. Mission: when your highest number of wins in one sector is at least 2, claim: Gain 9 points.",
				p104: "Rosetta Probe",
				p104Text: "Launch a probe for free. Mission: when your probes on comets is at least 1, claim: Gain 3 points. Gain 1 data.",
				p105: "Green Bank Telescope",
				p105Text: "Scan for free; pay the costs of any additional technology steps you use. Mission: when your red traces, including overflow is at least 3, claim: Mark one red trace.",
				p106: "Strategic Planning",
				p106Text: "Triggered mission (after this card is played; claim at most one reward per event, each reward once): play a project for credits (1): Gain 2 points; play a project for credits (2): Draw 1 card from the deck; play a project for credits (3): Gain 2 publicity.",
				p107: "First Black Hole Photo",
				p107Text: "Gain 2 data. Triggered mission (after this card is played; claim at most one reward per event, each reward once): mark a trace (blue): Gain 2 publicity; mark a trace (blue): Gain 4 points.",
				p108: "SETI@Home",
				p108Text: "If your current publicity is at least 8, Mark one red trace.",
				p109: "Low-Power Microprocessors",
				p109Text: "Gain 1 energy. Research one computer technology for free.",
				p110: "Press Statement",
				p110Text: "Gain 3 publicity.",
				p111: "Roman Space Telescope",
				p111Text: "Research one telescope technology for free. Mission: when your orbiters is at least 2, claim: Gain 2 data.",
				p112: "Planetary Geologic Mapping",
				p112Text: "Research one probe technology for free. Mission: when planets where you have both an orbiter and a lander is at least 1, claim: Gain 3 points. Gain 1 data.",
				p113: "Solvay Conference",
				p113Text: "Gain 2 publicity. At game end, choose one gold tile you have not marked and score it at its rightmost value.",
				p114: "Planet Hunters",
				p114Text: "Draw 1 card from the deck. You may discard a card from your hand to mark a signal matching its colour. You may discard a card from your hand to mark a signal matching its colour. You may discard a card from your hand to mark a signal matching its colour.",
				p115: "Canadian Hydrogen Telescope",
				p115Text: "Mark 1 signal in any sector. Mission: when your telescope technologies is at least 3, claim: Gain 1 data.",
				p116: "Control Center",
				p116Text: "Triggered mission (after this card is played; claim at most one reward per event, each reward once): mark a signal (yellow): Gain 1 movement; mark a signal (red): Gain 1 movement; mark a signal (blue): Gain 1 movement.",
				p117: "Lunar Gateway",
				p117Text: "Launch a probe for free. Triggered mission (after this card is played; claim at most one reward per event, each reward once): enter orbit or land: Launch a probe for free; enter orbit or land: Gain 1 energy.",
				p118: "PLATO",
				p118Text: "Mark 3 signals in a sector containing your probe; gain no data from these signals.",
				p119: "PIXL",
				p119Text: "Research one computer technology for free. Gain 1 point for each publicity you currently have.",
				p120: "Orbiting Lagrange Point",
				p120Text: "Mark 1 signal in a sector containing your probe. Return this card to your hand if you have exactly one signal in the sector just marked.",
				p121: "Future Circular Collider",
				p121Text: "Gain 3 data. Research one computer technology for free.",
				p122: "Amateur Astronomers",
				p122Text: "Discard the top card of the deck and mark a signal in a sector matching its colour. Discard the top card of the deck and mark a signal in a sector matching its colour. Discard the top card of the deck and mark a signal in a sector matching its colour.",
				p123: "Asteroids Flyby",
				p123Text: "Gain 1 movement. If visits to asteroids this turn is at least 1, Gain 1 data.",
				p124: "Cometary Encounter",
				p124Text: "Gain 2 movement. If visits to a comet this turn is at least 1, Gain 4 points.",
				p125: "Trajectory Correction",
				p125Text: "Gain 1 movement. If moves within the same ring this turn is at least 1, Gain 3 points. Gain 1 publicity.",
				p126: "Euclid Telescope Construction",
				p126Text: "Research one probe or telescope technology for free. End-game scoring: Score 2 points per your computer technologies.",
				p127: "NEAR Shoemaker",
				p127Text: "Gain 2 publicity. End-game scoring: Gain 13 points if your probes on asteroids is at least 1.",
				p128: "Advanced Navigation System",
				p128Text: "Triggered mission (after this card is played; claim at most one reward per event, each reward once): visit (planet): Gain 1 energy; visit (planet): Gain 1 data; visit (planet): Gain 1 movement.",
				p129: "Asteroids Research",
				p129Text: "Triggered mission (after this card is played; claim at most one reward per event, each reward once): visit (asteroids): Gain 1 data; visit (asteroids): Gain 1 data; visit (asteroids): Gain 1 data.",
				p130: "Low-Cost Space Launch",
				p130Text: "Launch a probe for free.",
				p131: "Telescope Modernization",
				p131Text: "Draw 1 card from the deck. Triggered mission (after this card is played; claim at most one reward per event, each reward once): research technology (telescope): Gain 1 publicity; complete a scan: Gain 1 data.",
				p132: "Space Shuttle",
				p132Text: "Launch a probe for free. Gain 2 publicity. Mission: when your orbiters and landers, including moons is at least 5, claim: Gain 3 points. Gain 1 credit.",
				p133: "Optimal Launch Window",
				p133Text: "Launch a probe for free. Gain 1 movement per other planet or comet in Earth’s sector.",
				p134: "Herschel Space Observatory",
				p134Text: "Mark 1 signal in a sector containing your probe. Mission: when sectors containing your signals is at least 4, claim: Gain 2 publicity.",
				p135: "Noto Radio Observatory",
				p135Text: "Gain 1 publicity. Scan for free; pay the costs of any additional technology steps you use.",
				p136: "Algonquin Radio Observatory",
				p136Text: "Mark 1 signal in yellow sectors; gain no data from these signals. Mark 1 signal in red sectors; gain no data from these signals. Mark 1 signal in blue sectors; gain no data from these signals. Mark 1 signal in black sectors; gain no data from these signals.",
				p137: "SETI Data Archive",
				p137Text: "Gain 2 data.",
				p138: "Cornell University",
				p138Text: "Triggered mission (after this card is played; claim at most one reward per event, each reward once): discard a card for its corner benefit (publicity): Gain 1 publicity; discard a card for its corner benefit (data): Gain 1 data; discard a card for its corner benefit (movement): Gain 1 movement."
			},
			aliens: {
				c1001: "First Contact",
				c1001Text: "Gain 1 movement. Land for free and secretly choose a Mascamite sample from that planet to place a capsule. Mission: deliver the capsule to Earth to gain its sample reward and 2 data.",
				c1002: "Rover Exploration",
				c1002Text: "Land for free, including on a moon without moon technology. Secretly collect a sample if available and place a capsule. Mission: deliver it to Earth to gain the sample reward, 3 points and 3 data.",
				c1003: "Mass Sample Collection",
				c1003Text: "Enter orbit or land for free. Secretly collect a Mascamite sample if available on that planet and place a capsule. Mission: deliver it to Earth to gain the sample reward, 3 points and 1 credit.",
				c1004: "Martian Quarantine Lab",
				c1004Text: "Land for free, secretly collect a sample from that planet if available and place a capsule. Mission: deliver it to Mars to gain its sample reward, 2 points and draw 1 card.",
				c1005: "Ecosystem Study",
				c1005Text: "Choose a planet containing your probe. Inspect its samples, gain the reward from one, then return them. At game end, gain 1 point per trace you marked for Mascamites.",
				c1006: "The Queen",
				c1006Text: "Land for free, including on a moon without moon technology. Secretly collect a sample if available and place a capsule. Mission: deliver it to Earth to gain its sample reward, 6 points and 2 publicity.",
				c1007: "Breeding Sample",
				c1007Text: "Land for free, secretly collect a sample from that planet if available and place a capsule. Mission: deliver it to Earth to gain its sample reward twice.",
				c1008: "Orbital Monitoring",
				c1008Text: "Gain 1 publicity and research a telescope technology. Mission: with two red Mascamite traces, inspect the samples on Jupiter or Saturn, gain one sample’s reward and return them.",
				c1009: "Computer Simulations",
				c1009Text: "Gain 1 publicity and research a computer technology. Mission: with two blue Mascamite traces, inspect the samples on Jupiter or Saturn, gain one sample’s reward and return them.",
				c1010: "Hive Sample",
				c1010Text: "Gain 1 publicity and research a probe technology. Mission: with two yellow Mascamite traces, inspect the samples on Jupiter or Saturn, gain one sample’s reward and return them.",
				c1011: "Are We Being Observed?",
				c1011Text: "Gain the reward on the anomaly that will trigger next. Mission: with all three trace colours for Anomalies, gain 3 points and 2 publicity.",
				c1012: "Signs of Life",
				c1012Text: "Launch a probe for free. If Earth’s sector contains an anomaly, gain 1 movement.",
				c1013: "Concerned People",
				c1013Text: "Gain 1 publicity. Triggered mission: after each subsequent technology research, claim one unused reward: 1 energy, draw 1 card or 3 points. Each reward can be claimed once.",
				c1014: "Listening Carefully",
				c1014Text: "Perform a scan, then mark an extra signal in the sector containing the anomaly that will trigger next.",
				c1015: "Part of Everyday Life",
				c1015Text: "Draw 3 cards. Discard one of those cards for its corner benefit, then discard another for its income resource. Keep the remaining card.",
				c1016: "Flooding the Media Space",
				c1016Text: "Take all cards from the card row, then refill it.",
				c1017: "Close-up View",
				c1017Text: "Gain 5 movement. Movement grants no publicity for the rest of this turn.",
				c1018: "Message Capsule",
				c1018Text: "Research a technology of any category for free.",
				c1019: "New Physics",
				c1019Text: "Mark a trace of any colour.",
				c1020: "Amazing Uncertainty",
				c1020Text: "Mark a signal in any sector. Then gain 1 point for each of your signals in sectors containing anomalies.",
				c1021: "Visitor in the Sky",
				c1021Text: "Perform a scan. Gain 2 points for each signal marked on the ‘Oumuamua tile during this scan. Mission: after marking an ‘Oumuamua research space that costs exofossils, gain 1 data.",
				c1022: "Altered Trajectory",
				c1022Text: "Perform a scan. Gain 1 exofossil if this scan marked at least one signal on the ‘Oumuamua tile. Mission: with a lander on ‘Oumuamua, gain 4 points.",
				c1023: "Exofossil Discovery",
				c1023Text: "Mark a signal in ‘Oumuamua’s sector or on its tile. Mission: with at least 3 exofossils, spend 2 exofossils to gain 11 points.",
				c1024: "Exofossil Samples",
				c1024Text: "Research a computer technology. Then you may spend 1 exofossil to gain 1 data.",
				c1025: "Probe Customisation",
				c1025Text: "You may repeatedly spend 1 exofossil to gain 2 movement each time. Then land for free.",
				c1026: "Excavation Rover",
				c1026Text: "Land for free. Gain 3 extra points if this action landed on ‘Oumuamua. Mission: with all three trace colours for ‘Oumuamua, gain 1 exofossil.",
				c1027: "Perfect Timing",
				c1027Text: "Gain 4 movement. Gain 1 exofossil if you visited ‘Oumuamua this turn. Mission: with one of your signals on the ‘Oumuamua tile, gain 1 exofossil.",
				c1028: "Race Against Time",
				c1028Text: "Launch a probe for free and gain 1 exofossil.",
				c1029: "Comparative Analysis",
				c1029Text: "Gain 1 exofossil. Triggered mission: after each subsequent trace you mark, claim one unused reward: 1 data, 1 publicity or 3 points. Each reward can be claimed once.",
				c1030: "Terrain Mapping",
				c1030Text: "Mark one signal each in yellow, red and blue sectors, in that order. Then you may spend 1 exofossil to mark a signal in any sector. At game end, score 1 point per trace you marked for ‘Oumuamua.",
				c1031: "Vessel Designs",
				c1031Text: "Launch a probe for free and send a message. After you gain 15 more points, tuck this card for income and gain its income immediately.",
				c1032: "Exocomputers",
				c1032Text: "Gain 2 data and send a message. After you gain 15 more points, tuck this card for income and gain its income immediately.",
				c1033: "Infocluster",
				c1033Text: "Gain 1 publicity and 1 credit, and send a message. After you gain 15 more points, tuck this card for income and gain its income immediately.",
				c1034: "A Message from Afar",
				c1034Text: "Draw 1 card and send a message. After you gain 15 more points, mark a red trace.",
				c1035: "Synthesis Instructions",
				c1035Text: "Gain 1 data and send a message. After you gain 15 more points, mark a yellow trace.",
				c1036: "Alien Schematics",
				c1036Text: "Gain 2 publicity and send a message. After you gain 15 more points, mark a blue trace.",
				c1037: "Music of the Spheres",
				c1037Text: "Draw 1 card and send a message. After you gain 15 more points, gain 1 credit and mark a trace of any colour.",
				c1038: "Hivemind Concept",
				c1038Text: "Research a computer technology and send a message. After you gain 15 more points, tuck this card for income and gain its income immediately.",
				c1039: "Telescope Blueprints",
				c1039Text: "Research a telescope technology and send a message. After you gain 15 more points, tuck this card for income and gain its income immediately.",
				c1040: "Torrent-chain Signal",
				c1040Text: "Mark 2 signals in one sector of your choice and send a message. After you gain 15 more points, tuck this card for income and gain its income immediately.",
				c2001: "Automated Lab",
				c2001Text: "Danger 0. At game end, gain 7 points if you have at least 6 traces for Exertians.",
				c2002: "Casette Deployment",
				c2002Text: "Danger 2. At game end, gain 10 points if you have at least 3 orbiters or landers at one planet, including its moons.",
				c2003: "Core-breach Exoplanet",
				c2003Text: "Danger 4. At game end, gain 12 points if you have at least 2 wins in blue sectors.",
				c2004: "Deflector",
				c2004Text: "Danger 7. At game end, gain 15 points if you have at least 3 telescope technologies.",
				c2005: "Expender Core",
				c2005Text: "Danger 3. At game end, gain 9 points if you have at least 3 computer technologies.",
				c2006: "Extractor",
				c2006Text: "Danger 8. At game end, gain 18 points if you have at least 8 tucked income cards.",
				c2007: "Fission-sun Exoplanet",
				c2007Text: "Danger 5. At game end, gain 14 points if you have at least 2 wins in black sectors.",
				c2008: "Generative Infrastructure",
				c2008Text: "Danger 7. At game end, gain 16 points if you have at least 4 landers, including moons.",
				c2009: "Nanowielder Node",
				c2009Text: "Danger 1. At game end, gain 8 points if you have at least 5 traces of the same colour.",
				c2010: "Neuralab",
				c2010Text: "Danger 9. At game end, gain 20 points if you have at least 6 traces for the other species.",
				c2011: "Oscillating Probes",
				c2011Text: "Danger 3. At game end, gain 11 points if you have at least 3 orbiters.",
				c2012: "Pierced Exoplanet",
				c2012Text: "Danger 4. At game end, gain 12 points if you have at least 2 wins in red sectors.",
				c2013: "Razor-edge Shuttle",
				c2013Text: "Danger 6. At game end, gain 14 points if you have at least 3 probe technologies.",
				c2014: "Stratoelevator",
				c2014Text: "Danger 4. At game end, gain 12 points if you have at least 5 completed missions.",
				c2015: "Vortex Exoplanet",
				c2015Text: "Danger 4. At game end, gain 12 points if you have at least 2 wins in yellow sectors."
			},
			anomalyAt: "Anomaly in sector {{n}}",
			sampleCapsule: "{{name}}’s sample capsule",
			playedSecrets: "Projects played face down",
			repeatable: "May be marked repeatedly",
			samplesRemaining: "Samples remaining: Jupiter {{jupiter}} · Saturn {{saturn}}",
			exertianMilestones: "Secret project opportunities: {{first}} points · {{second}} points",
			goldFaces: {
				techSet: "One technology of each category",
				techPair: "Each pair of technologies",
				missions: "Each completed mission",
				missionPair: "Each pair of completed missions or scoring projects",
				incomeSet: "One credit, energy and card income",
				incomeMaximum: "Most credit or energy income cards",
				traceSet: "One trace of each colour",
				winFigure: "Each sector win paired with an orbiter or lander"
			},
			playSecret: "Play this card face down",
			messageBonus: "Choose message reward {{n}}",
			freeOrbit: "Enter orbit for free",
			freeLanding: "Land for free",
			spendFossil: "Spend 1 exofossil",
			researchTrace: "Mark research space {{n}}",
			markOumuamua: "Mark a signal on ‘Oumuamua",
			resolveOumuamua: "Resolve ‘Oumuamua signals",
			fossil: "Exofossils",
			danger: "Danger",
			secretCards: "Secret Exertian projects",
			messageThreshold: "{{name}}’s message: {{n}} points",
			researchCost: "Pay {{n}} data",
			fossilCost: "Pay {{n}} exofossils",
			sampleRewards: {
				credit: "Sample: 2 credits",
				energy: "Sample: 2 energy",
				publicity: "Sample: 3 publicity",
				data: "Sample: 2 data",
				cards: "Sample: draw 2 cards",
				pointsCards: "Sample: 3 points and draw 1 card",
				points: "Sample: 7 points"
			},
			chooseReward: "Gain {{n}} {{resource}}",
			finishSignals: "Finish marking signals",
			selectProbe: "Choose this probe",
			chooseTraceColor: "Choose {{n}}",
			overflowColor: "Species {{n}}: {{color}} in overflow · 3 points",
			deferRoundCard: "Choose later",
			roundLabel: "Round {{n}} / 5",
			roundCards: "End-of-round cards",
			goldTiles: "Gold tiles",
			firstPlayer: "Starting player",
			finalScore: "Final scoring",
			baseScore: "Points in play",
			cardScore: "Projects",
			goldScore: "Gold tiles",
			alienScore: "Alien rewards",
			dangerPenalty: "Danger penalty",
			totalScore: "Total",
			name: "SETI: Search for Extraterrestrial Intelligence",
			desc: "Explore a rotating solar system, research technologies and discover five alien species. A complete five-round base game for 2–4 players with 138 distinct projects.",
			rules: "Goal and setup:\nEarn points by exploring planets, researching technologies and finding traces of extraterrestrial life. The base game supports 2–4 players for five complete rounds, using 138 distinct base projects and the cards of the two species in play.\nSetup:\n· Each player receives 4 credits, 3 energy, 4 publicity, and 5 hand cards.\n· Starting scores are 1, 2, 3, and 4 points in seating order, using only the occupied seats.\n· Place 3 cards in the project market. The starting positions of the solar-system discs are randomized.\n· Two civilizations begin with their identities hidden. Each has three discovery spaces of different colors.\n· Starting with the first player, each player places one card from their hand in their income area.\n· Immediately gain the 1 resource shown at the bottom of that card, or draw 1 card from the deck if it shows a card.\n· An income card is no longer in your hand and cannot be played or discarded as a hand card.\n· Once every player has chosen an income card, the first player begins their turn.\nResources and cards:\n· Credits pay for launching, orbiting, scanning, and playing project cards.\n· Energy pays for movement, orbiting, landing, and analysis. Publicity pays for research and card purchases.\n· You may hold at most 10 publicity and 6 data in your pool. Any excess is lost.\n· Data in your computer does not count toward your pool limit. Credits and energy have no holding limit.\n· Each project card shows its play cost, discard benefit, signal color, and income.\n· Playing a card, discarding it for its benefit, and placing it as income are separate uses. Do not combine their rewards.\n· When instructed to choose a card, take one project from the market or draw the top card of the deck.\n· Refill the market to 3 cards after taking a card, unless the effect specifies a different refill timing.\n· When the deck is exhausted, shuffle the discard pile to form a new deck.\nTurn sequence:\n· Take turns in seating order. Players who have passed for the round receive no further turns of their own.\n· Perform one main action per turn. Launching, orbiting, landing, scanning, and analysis are main actions.\n· Playing a project, researching a technology, and passing for the round also each use one main action.\n· You may take free actions before or after your main action, and between effects when permitted.\n· Complete a free action and all its resulting rewards before starting another free action.\n· When a mission reward requires a decision, resolve that decision and its reward before continuing the current action.\n· After your main action and its effects are complete, resolve every sector whose signal track is full.\n· After all such sectors are resolved, you may take further free actions, then select End turn.\nLaunching probes:\n· Pay 2 credits to place one probe in the space containing Earth.\n· Without Two probes technology, you may have at most one probe in space.\n· Orbiters and landers do not count toward this limit. Launching does not count as visiting Earth.\nMoving probes:\n· As a free action, pay 1 energy to move one of your probes to an adjacent space.\n· Adjacent spaces are the two neighboring sectors on the same ring and the neighboring rings in the same sector.\n· You cannot move diagonally, through the Sun, or beyond the outermost ring.\n· Leaving an asteroid space costs 2 movement. Asteroid navigation removes this additional cost.\n· Movement granted by cards or technologies may move your own probes. Pay energy to cover any movement shortfall.\n· For example, leaving an asteroid costs 2 movement. With only 1 granted movement available, pay 1 additional energy.\n· If you have two probes, you may divide the movement from one effect between them.\n· You may end a movement effect early. Unused movement is not saved for later effects or turns.\n· Gain 1 publicity when entering a space containing a planet other than Earth, or a comet.\n· Entering such a space again can grant publicity again. Remaining in the same space grants no repeated reward.\nRotating the discs:\n· Researching a technology and the first player confirming their pass each trigger one rotation.\n· Rotate the top, middle, and bottom discs in that order, advancing one sector counterclockwise each time.\n· Rotating the middle or bottom disc also rotates every disc above it.\n· A probe moves with its supporting disc. Being carried on that disc is not a new visit to its existing space.\n· A probe in a cutout may remain in place or be pushed into the neighboring sector by a disc edge.\n· If a disc edge pushes a probe into a new space, resolve that space for publicity and visit missions.\nEntering orbit:\n· You may take the orbit main action with your own probe in a space containing a planet other than Earth.\n· Pay 1 credit and 1 energy, then move that probe to the planet’s orbit.\n· If the first-orbiter reward space is unoccupied, place your orbiter there and gain 3 points.\n· Every orbit action grants the orbit rewards listed for that planet. Consult its details for the individual rewards.\n· An orbiter is no longer a movable probe and cannot move between solar-system spaces.\nLanding:\n· You may take the land main action with your own probe in a space containing a planet other than Earth.\n· Landing normally costs 3 energy. Reduce the cost by 1 if any player has an orbiter at that planet.\n· Improved landing reduces the cost by a further 1 energy. Both reductions may apply together.\n· For example, landing costs 1 energy if an orbiter is present and you have Improved landing.\n· Landing on a planet grants its landing points and one life trace.\n· If an unoccupied first-landing space remains, choose one and gain its data reward.\n· You may still land when all first-landing spaces are occupied, but receive no first-landing data reward.\n· Moon exploration allows you to land on one of that planet’s moons instead.\n· Landing on a moon uses the same energy cost. Normally, each moon can hold only one lander.\n· Landing on a moon grants its listed rewards instead of the planet’s landing rewards.\n· After landing, the probe becomes a lander and cannot move. Follow any exceptions stated by the card used.\nScanning:\n· Pay 1 credit and 2 energy to scan. You do not need a probe in space.\n· A basic scan has two steps: mark Earth’s sector, and discard one market project to mark a signal.\n· For the Earth step, place one of your signals in the sector currently containing Earth.\n· For the market step, discard one market project and place one signal in a sector matching its signal color.\n· If several sectors match, choose one. Use the signal color shown at the top right of the card.\n· Resolve the two basic steps in either order. Complete both before ending the scan.\n· You may interleave additional technology steps. Each such step can be taken at most once per scan.\n· Refill the card row after the entire scan. For multi-card effects, finish all required discards before refilling.\nSignals and sectors:\n· Placing a signal in a sector whose track is not yet full grants 1 data.\n· Placing the second signal grants an additional 2 points, regardless of who placed the first signal.\n· Further signals may be placed after the track is full. They count toward control but grant neither of those placement rewards.\n· After the main action, the current player chooses the order in which completed sectors are resolved.\n· Each player with at least one signal in that sector gains 1 publicity when it is resolved.\n· The player with the most signals wins and gains the points applicable to that resolution of the sector.\n· Break a tie by comparing the tied players’ last placements in that sector. The later placement ranks higher.\n· Use the same comparison to determine second place. Only the runner-up keeps one signal; remove all other signals.\n· On a sector’s first resolution, its winner receives one signal trace.\n· Later victories at Sirius A, Proxima Centauri, 61 Virginis, and Beta Pictoris also grant a signal trace.\n· Victory records remain, but do not count as signals in the next resolution of that sector.\n· The winner chooses where to place their trace, even if it is another player’s turn.\nComputer and data:\n· Placing data is a free action. Spend one data from your pool to fill a space in your computer’s top row.\n· Fill the top row from left to right, always using its leftmost empty space.\n· Without installed technology, the second space grants 1 publicity and the fourth allows you to add an income card.\n· To add income, place one hand card in your income area and receive its income immediately. You may decline.\n· If computer technology is installed in the top space, placing data there grants 2 points instead.\n· An installed technology’s lower space may be filled only if its top space already contains data.\n· Lower spaces need not be filled left to right. Each placement costs one data and grants that technology’s lower reward.\n· An occupied space cannot receive another data. Each individual data placement is a separate free action.\nAnalyzing data:\n· When all six top spaces are filled, pay 1 energy to take the analyze main action.\n· Analysis removes all data from both rows and grants one analysis trace.\n· Removed data does not return to your pool. Existing pool data and installed technologies remain.\nResearch:\n· Pay 6 publicity for the research main action. Rotate the solar system before choosing a technology.\n· Technologies belong to three families: probe, telescope, and computer, with four technologies in each family.\n· Choose a technology you do not already own and for which a tile remains available.\n· The first player in the game to research a particular technology gains an additional 2 points.\n· Each research also grants the immediate reward on the tile taken and any acquisition effect of that technology.\n· An immediate tile reward is 1 publicity, 1 energy, a chosen card, or 3 points.\n· Research granted by a card does not cost an additional 6 publicity, but still rotates the discs and obeys its family restriction.\nProbe technologies:\n· Two probes increases your limit in space to two probes and grants a free launch when acquired.\n· Asteroid navigation removes the extra movement cost for leaving asteroids and grants 1 publicity when entering one.\n· Improved landing reduces the energy cost of landing on planets and moons by 1.\n· Moon exploration allows landing on a planet’s moons to receive the rewards of the chosen moon.\nTelescope abilities:\n· Extended observation grants 2 data when acquired and allows the Earth scan step to target either adjacent sector instead.\n· Project observation adds an optional scan step: discard one hand card to mark a sector matching its signal color.\n· Mercury observation adds an optional scan step: pay 1 publicity to mark the sector containing Mercury.\n· Launch coordination adds an optional scan step: pay 1 energy to launch a probe, or gain 1 free movement.\n· Choose only one of Launch coordination’s two effects. Its launch must obey your probe limit.\nComputer technology:\n· After acquiring computer technology, install it in any computer column that has no installed technology.\n· You may install it beneath existing data, but installation does not award that space’s reward again.\n· All four computer technologies give 2 points for top-row placement, replacing the space’s original reward.\n· Publicity computer grants 2 publicity in its lower space.\n· Project computer grants a chosen card.\n· Energy computer grants 1 energy in its lower space.\n· Credit computer grants 1 credit.\nOther free actions:\n· Discard one hand card to gain the 1 resource or 1 movement shown at its top left.\n· Pay 2 credits to gain 1 energy or choose a card.\n· Pay 2 energy to gain 1 credit or choose a card.\n· Discard two hand cards to gain 1 credit, gain 1 energy, or choose a card.\n· Pay 3 publicity to take one market project or draw the top card of the deck.\n· Cards discarded for scanning, exchanging, or passing do not grant their top-left discard benefits.\n· Moving probes, placing data, and claiming eligible conditional-mission rewards are also free actions.\n· Free actions have no general per-turn limit, but each must meet its own resource and effect requirements.\nCards and missions:\n· To play a project, choose one card from your hand, pay its credit cost, and resolve its effects in order.\n· Keep mission cards and projects that must remain in play in your personal area. Discard other projects after resolving them.\n· Event missions respond only to events that occur after the mission card was played. Earlier actions do not count.\n· A single event can claim at most one unclaimed reward across all your event missions.\n· You may decline an event reward, but cannot save that event to claim later.\n· Each mission reward circle may be claimed only once. A marked circle cannot be used again.\n· Pioneer 11 Mission grants 1 data for a later visit by your probe to Jupiter and 4 points for a later visit to Saturn.\n· After each later scan, Telescope Time Allocation may mark a signal in the colour of one unclaimed reward circle.\n· Trajectory Correction is an immediate project. Gain 3 points and 1 publicity if you moved within a ring this turn.\n· A conditional mission may use movement that already occurred this turn, unlike an event mission.\nTraces and discoveries:\nTrace colors are as follows:\n· Red: signal trace.\n· Yellow: life trace.\n· Blue: analysis trace.\nMark an empty discovery space or an available research space of the corresponding colour on either revealed species board. Discovery spaces give 1 publicity and 5 points on the left species or 3 on the right. You may instead use either overflow area for 3 points, retaining the chosen colour for trace counts. Research spaces grant their depicted rewards and may cost pool data or exofossils. Spaces marked as repeatable remain available.\nOnce all three discovery spaces are filled, reveal the species after end-turn milestones. Players receive one species card per discovery marker they placed. Regular alien cards may be held, discarded or tucked; Exertian cards are kept separately.\nEnd-turn milestones:\nAt 25, 50 and 70 points, mark a gold tile you have not previously marked. Claim its value according to the order in which players choose that tile. Randomly select one side of each of the four tiles during setup. Starting with the player whose turn just ended, resolve each player’s gold and alien milestones in seating order. No free actions are allowed during this process.\nAt both 20 and 30 points, two-player games have two neutral markers and three-player games have one. Each player reaching that threshold takes only one remaining marker, placing it in the leftmost empty discovery space. Neutral markers grant no player rewards and may cause a discovery. Resolve neutral milestones last. Four-player games use none.\nPassing and five rounds:\nPassing is a main action. Take any desired free actions beforehand. Then discard to 4 hand cards; rotate the solar system if you are the first player to pass this round; choose one card from the round’s private offer. Prepare four end-of-round piles with one more card than the player count. You may defer your choice until the next player passes. Only the current holder sees the offer. In round five the first passer still rotates, but no cards are offered.\nWhen all players have passed and chosen, discard the offer’s last card. After rounds one through four, each player gains 3 credits, 2 energy, 1 random deck card and all tucked income. Pass the starting-player marker to the next seat and begin the next round.\nFive alien species:\n· Mascamites: Jupiter and Saturn each receive three hidden samples; the remaining sample becomes a public blue research space. Specific cards allow collection: inspect all samples at that planet, secretly select one and place a capsule. Capsules move like probes, do not count toward the probe limit, and cannot orbit or land. Deliver any of your capsules to a mission’s destination to claim its reward. The delivered sample becomes a new public blue research space.\n· Anomalies: place three randomly sided anomaly tokens in the outermost ring, in Earth’s sector and three sectors in either direction. After every rotation, trigger an anomaly sharing Earth’s sector. The highest marker on the matching research column gains its reward. The top space is repeatable and later markers go above earlier ones. Visiting anomalies grants nothing.\n· ‘Oumuamua: place its tile in the designated space on disc three. It counts as a planet, grants 1 publicity per visit and may be orbited or landed on. Signals in its sector may be marked on its separate track instead. The first and third slots give 1 and 2 points, and unfilled slots grant data. Resolve a completed track after the main action: each participant gains 1 exofossil, then clear and refill it, with no sector winner. Exofossils pay for some research spaces and card effects; unused ones score nothing.\n· Centaurians: on discovery, each player places a message milestone 15 points ahead of their score. On reaching it, claim one available board reward. Centaurian cards cost energy. Playing one creates another milestone 15 points ahead: resolve its white section immediately, then its green section when reached, in sending order. Messages are not missions. Research data costs must be paid from the data pool.\n· Exertians: on discovery, deal three secret cards per player plus one per discovery contribution. Each contribution also allows one immediate face-down play. Set two milestones at 20 and 40 points ahead of the discovery-time leader. Each player may play one secret card upon reaching each; the second costs 1 credit. Secret cards are not hand cards, cannot be discarded or tucked, and are neither missions nor end-game scoring cards. Research spaces also add public danger.\nFinal scoring and winning:\nAfter all players pass in round five, finish the last rotation, mission responses, milestones and discoveries. Score played end-game projects, then gold tiles, then reveal and score Exertian projects whose conditions are met.\nGold tiles score their depicted sets of technologies, completed missions, tucked income, trace colours, or sector wins paired with orbiters or landers, at the value you claimed. The fixed per-round income of 3 credits, 2 energy and 1 random card does not count. A triggered mission is complete only when all its reward circles are marked. Solvay Conference additionally scores an unmarked gold tile at its rightmost value.\nFinally, add public danger to the danger on played secret cards. Every player tied for the most danger loses one tenth of their total points, rounded down. Highest score wins; ties share victory. This implementation covers the 2–4 player base game, excluding the official solo rival, Space Agencies expansion and promo cards.",
			invalidAction: "That action is unavailable now. Please choose again.",
			resources: {
				credit: "credits",
				energy: "energy",
				publicity: "publicity",
				data: "data",
				vp: "points",
				card: "cards",
				move: "movement"
			},
			planets: {
				earth: "Earth",
				mercury: "Mercury",
				venus: "Venus",
				mars: "Mars",
				jupiter: "Jupiter",
				saturn: "Saturn",
				uranus: "Uranus",
				neptune: "Neptune"
			},
			moons: {
				phobos: "Phobos & Deimos",
				io: "Io",
				europa: "Europa",
				ganymede: "Ganymede",
				callisto: "Callisto",
				enceladus: "Enceladus",
				titan: "Titan",
				titania: "Titania",
				triton: "Triton"
			},
			stars: {
				procyon: "Procyon",
				vega: "Vega",
				sirius: "Sirius A",
				barnard: "Barnard’s Star",
				kepler: "Kepler 22",
				proxima: "Proxima Centauri",
				virginis: "61 Virginis",
				pictoris: "Beta Pictoris"
			},
			species: {
				mascamites: "Mascamites",
				anomalies: "Anomalies",
				oumuamua: "‘Oumuamua",
				centaurians: "Centaurians",
				exertians: "Exertians"
			},
			cards: {
				pioneer: "Pioneer 11 Mission",
				pioneerText: "Event mission: after playing this card, each visit by your probe to Jupiter or Saturn may claim the corresponding reward. Jupiter grants 1 data; Saturn grants 4 points. Each reward may be claimed only once.",
				entry: "Atmospheric Entry",
				entryText: "Remove one of your orbiters to gain 3 points and 1 data. Then choose one project from the market or draw the top card of the deck.",
				dragonfly: "Dragonfly",
				dragonflyText: "Land one of your probes for free on the planet in its space or one of that planet’s moons. You may use an occupied space and receive its reward. Landing on a moon still requires Moon exploration technology.",
				lightsail: "Lightsail",
				lightsailText: "Gain 4 movement. For the rest of this turn, gain 1 point for each different planet you visit, including Earth. Each planet scores at most once. Remaining in the same space is not another visit.",
				array: "Square Kilometre Array",
				arrayText: "Discard the 3 market projects one at a time. For each card, mark one signal in a sector matching its signal color. Refill the market after all three discards. Gain 2 points for each different sector targeted.",
				focus: "Focused Research",
				focusText: "Rotate the solar system, then research any technology you do not already own. After research is complete, gain 2 points for each technology you own in the family just researched, including the newly acquired technology.",
				sample: "Sample Return",
				sampleText: "Remove one of your landers from any planet or moon, then mark one yellow life trace.",
				telescope: "Telescope Time Allocation",
				telescopeText: "Event mission: after playing this card, each completed scan may claim one unclaimed reward circle and mark a signal in a sector of its shown color. Each circle may be claimed only once. A single scan can claim at most one mission reward.",
				solvay: "Solvay Conference",
				solvayText: "Gain 2 publicity. During final scoring, choose a gold scoring tile you have not marked and score its rightmost tier. ",
				pixl: "PIXL",
				pixlText: "Rotate the solar system, then research a computer technology you do not already own. After research is complete, gain 1 point for each publicity you hold without spending that publicity. You may complete permitted free actions before scoring.",
				correction: "Trajectory Correction",
				correctionText: "Gain 1 movement. If you moved within the same ring at least once this turn, gain 3 points and 1 publicity.",
				window: "Optimal Launch Window",
				windowText: "Launch one probe for free, obeying your probe limit. Then inspect the three spaces outward from Earth in its sector. Gain 1 movement for each other planet or comet in those spaces, up to 3 movement."
			},
			techs: {
				capacity: "Two probes",
				capacityText: "You may have up to two movable probes in space at once. When acquiring this technology, you may launch one probe for free, obeying that limit.",
				asteroid: "Asteroid navigation",
				asteroidText: "Leaving an asteroid space no longer costs an additional movement. Gain 1 publicity each time you enter an asteroid space.",
				landing: "Improved landing",
				landingText: "Reduce the energy cost of landing on a planet or moon by 1. This reduction may be combined with the reduction for an orbiter already present at the planet.",
				moon: "Moon exploration",
				moonText: "You may land a probe on a moon of the planet in its space, at the same energy cost as landing on that planet. Normally each moon holds only one lander. Receive the moon’s listed rewards.",
				adjacent: "Extended observation",
				adjacentText: "Gain 2 data when acquiring this technology. During scanning, you may place the signal for the Earth step in either adjacent sector instead of Earth’s sector.",
				hand: "Project observation",
				handText: "Once per scan, you may additionally discard one hand card to mark one signal in a sector matching its top-right signal color. This discard does not grant the card’s top-left benefit.",
				mercury: "Mercury observation",
				mercuryText: "Once per scan, you may additionally pay 1 publicity to mark one signal in the sector currently containing Mercury.",
				launch: "Launch coordination",
				launchText: "Once per scan, you may additionally choose one effect: pay 1 energy to launch a probe, or gain 1 free movement. The launch must obey your probe limit.",
				publicity: "Publicity computer",
				publicityText: "Placing one data in this technology’s top space grants 2 points instead of the original space reward. Placing one data in its lower space grants 2 publicity. The lower space requires data in the top space.",
				card: "Project computer",
				cardText: "Placing one data in this technology’s top space grants 2 points instead of the original space reward. Placing one data in its lower space grants a market project of your choice or a card drawn from the deck. The lower space requires data in the top space.",
				energy: "Energy computer",
				energyText: "Placing one data in this technology’s top space grants 2 points instead of the original space reward. Placing one data in its lower space grants 1 energy. The lower space requires data in the top space.",
				credit: "Credit computer",
				creditText: "Placing one data in this technology’s top space grants 2 points instead of the original space reward. Placing one data in its lower space grants 1 credit. The lower space requires data in the top space."
			},
			prompt: {
				setup: "Tuck a hand card for income",
				main: "Take one main action",
				effect: "Continue the current action",
				free: "Complete the current free action",
				response: "Choose whether to claim a mission reward",
				sector: "Choose a completed sector to resolve",
				after: "Take free actions or end your turn",
				pass: "Discard to four cards, then confirm passing",
				gold: "Choose an unmarked gold tile",
				roundEnd: "All players have passed",
				discovery: "An alien civilization has been discovered",
				finished: "Game over",
				finalGold: "Choose the Solvay Conference scoring tile",
				roundCard: "Choose an end-of-round project"
			},
			launch: "Launch · 2 credits",
			orbit: "Orbit · 1 credit + 1 energy",
			land: "Land",
			scan: "Scan · 1 credit + 2 energy",
			analyze: "Analyze · 1 energy",
			research: "Research · 6 publicity",
			pass: "Pass for the round",
			playCard: "Play project",
			endTurn: "End turn",
			continue: "Continue",
			finishMovement: "Finish movement",
			finishScan: "Complete scan",
			moveTo: "Move to ring {{ring}}, sector {{sector}} · {{n}} movement",
			moveWithEnergy: "Move to ring {{ring}}, sector {{sector}} · pay {{n}} extra energy",
			rotateResearch: "Rotate and choose a tech",
			installTech: "Install in slot {{n}}",
			tuck: "Tuck for income",
			takeCard: "Take this card",
			drawCard: "Draw from the deck",
			discardSignal: "Discard this card; mark sector {{n}}",
			markSector: "Mark a signal in sector {{n}}",
			scanEarth: "Scan Earth’s sector",
			scanRow: "Discard a market card for a signal",
			scanHand: "Discard a hand card for a signal",
			scanMercury: "Scan Mercury’s sector · 1 publicity",
			scanProbe: "Launch or move",
			scanLaunch: "Launch · 1 energy",
			gainMove: "Gain 1 movement",
			markTrace: "Mark {{color}} for species {{n}}",
			overflow: "Civilization {{n}}: overflow · 3 points",
			landPlanet: "Land on planet · first data {{n}}",
			removeFigure: "Remove this figure",
			placeUpper: "Place data in slot {{n}}",
			placeLower: "Place data below slot {{n}}",
			discardBonus: "Discard for corner benefit",
			exchange: "Trade 2 {{from}} for 1 {{to}}",
			buyCard: "Buy this card · 3 publicity",
			buyDeck: "Draw a card · 3 publicity",
			completeMission: "Complete mission",
			claimMission: "Claim mission reward {{n}}",
			declineMission: "Decline this time",
			discardCard: "Discard this card",
			confirmPass: "Confirm passing",
			resolveSector: "Resolve sector {{n}}",
			markGold: "Mark gold tile {{n}}",
			solarSystem: "Solar system",
			planetaryBoard: "Planet exploration",
			computer: "Computer",
			dataPool: "Data pool",
			technologies: "Technology research",
			probeTech: "Probe techs",
			telescopeTech: "Telescope techs",
			computerTech: "Computer techs",
			hand: "Hand",
			market: "Project market",
			missions: "Missions & projects",
			income: "Income",
			actions: "Actions",
			freeActions: "Free actions",
			decisions: "Current choices",
			details: "Details",
			history: "Action log",
			noChoices: "No actions are available here",
			waiting: "Waiting for {{name}}",
			nextRotation: "Next rotation: disc {{n}}",
			sector: "Sector {{n}}",
			ring: "Ring {{n}}",
			signalCount: "Signals {{n}} / {{max}}",
			handCount: "Hand {{n}}",
			cost: "Cost: {{n}} credits",
			freeBonus: "Discard: {{name}} ×1",
			incomeBonus: "Income: {{name}} ×1",
			deckCount: "Deck {{n}}",
			unnamedSpecies: "Unknown civilization {{n}}",
			traceNames: {
				red: "Signal trace",
				yellow: "Life trace",
				blue: "Analysis trace"
			},
			choose: "Choose action",
			ownArea: "Personal research",
			empty: "Empty",
			firstReward: "First reward",
			completed: "Completed",
			upperReward: "Upper slot {{n}}",
			lowerReward: "Tech lower slot {{n}}",
			marker: "{{name}}’s marker",
			probe: "{{name}}’s probe",
			goldCategories: {
				tech: "Techs",
				mission: "Missions",
				signal: "Signals",
				planet: "Planets"
			},
			techReward: "Immediate reward: {{name}} ×{{n}}",
			techRemaining: "{{n}} left",
			researchFirst: "First claim: +2 points",
			gainEffect: "Gain {{n}} {{name}}",
			moveEffect: "Movement available: {{n}}",
			publicityEffect: "Score your current publicity",
			techEffect: "Score techs of the acquired type",
			chooseEffect: "Choose a target or continue the effect",
			zoom: "Enlarge board",
			fit: "Fit board",
			orbiters: "Orbiters {{n}}",
			landers: "Landers {{n}}",
			noHand: "No cards in hand",
			skipIncome: "Do not increase income",
			cardBrief: {
				pioneer: "Visit Jupiter for data; visit Saturn for points.",
				entry: "Remove an orbiter for points, data and a card.",
				dragonfly: "Land for free, even on an occupied space, and gain its reward.",
				lightsail: "Gain 1 point per different planet visited this turn, including Earth.",
				array: "Discard 3 market cards to mark signals. Gain 2 points per different sector.",
				focus: "Research any tech. Gain 2 points per tech of that family.",
				sample: "Remove a lander to mark a yellow life trace.",
				telescope: "After each scan, mark a signal in one unclaimed reward colour.",
				solvay: "Gain 2 publicity. Score an unmarked gold tile at game end.",
				pixl: "Research a computer tech, then score your publicity.",
				correction: "Gain 1 movement. Gain 3 points and 1 publicity if you moved within a ring this turn.",
				window: "Launch for free. Gain movement for other planets and comets in Earth’s sector."
			},
			discardBenefit: "Discard benefit",
			civilizationTraces: "Civilization traces",
			overflowCount: "Overflow markers: {{n}}",
			ownedTech: "Researched",
			neutralMarker: "Neutral marker",
			currentPlayer: "Taking a turn",
			inspectSector: "Inspect sector {{n}}",
			anyTrace: "a trace of any colour",
			capsulePosition: "Ring {{ring}} · Sector {{sector}}",
			messageBonuses: {
				trace: "Mark a trace of any colour",
				cardEnergy: "Gain a Centaurian card and 1 energy",
				publicity: "Gain 3 publicity",
				points: "Gain 8 points"
			},
			revealedCards: "Revealed hand cards",
			sampleContents: "Capsule contents",
			sampleReveals: "Sample inspection history",
			anomalyRewards: "Anomaly rewards",
			log: {
				rotate: "Rotated disc {{n}}",
				launch: "Launched a probe",
				signal: "Marked sector {{n}}",
				sectorWon: "Won sector {{n}}",
				land: "Landed a probe",
				orbit: "Placed a probe in orbit",
				trace: "Marked a trace for civilization {{n}}",
				research: "Researched a tech",
				play: "Played project #{{n}}",
				round: "Started round {{n}}",
				revealCard: "Revealed project #{{n}}"
			}
		}
	}
};
//#endregion
export { Ln as default };
