import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useState as r } from "react";
import { BottomSheet as i } from "@bgparty/sdk/bottom-sheet";
import { useI18nSettings as a, useT as o } from "@bgparty/sdk/i18n";
import { PhaseBanner as s } from "@bgparty/sdk/ui/phase-banner";
import { seatName as c } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { PLAYER_COLORS as u } from "@bgparty/sdk/player-colors";
import { jsx as d, jsxs as f } from "react/jsx-runtime";
import { Confetti as p } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as m, OptionSection as h } from "@bgparty/sdk/ui/game-options";
//#region src/games/cahoots/goals.ts
var g = 0, _ = 1, v = 2, y = 3, b = [
	{ k: "gt4" },
	{ k: "lt4" },
	{
		k: "half",
		a: g,
		b: _
	},
	{
		k: "half",
		a: _,
		b: v
	},
	{
		k: "half",
		a: v,
		b: y
	},
	{
		k: "half",
		a: y,
		b: g
	},
	{
		k: "adj2",
		a: g
	},
	{
		k: "adj2",
		a: v
	},
	{
		k: "nonAdj2",
		a: _
	},
	{
		k: "nonAdj2",
		a: y
	},
	{
		k: "nonAdj2",
		a: v
	},
	{
		k: "nonAdj2",
		a: g
	},
	{
		k: "sumEq",
		a: g,
		b: y
	},
	{
		k: "sumEq",
		a: y,
		b: v
	},
	{
		k: "sumEq",
		a: v,
		b: _
	},
	{
		k: "sumEq",
		a: _,
		b: g
	},
	{
		k: "adj2",
		a: _
	},
	{
		k: "adj2",
		a: y
	},
	{
		k: "only2",
		a: v,
		b: g
	},
	{ k: "noSameNum" },
	{ k: "noSameBoth" },
	{
		k: "only2",
		a: _,
		b: y
	},
	{
		k: "only2",
		a: g,
		b: _
	},
	{
		k: "only2",
		a: v,
		b: y
	},
	{ k: "straight4" },
	{ k: "noSameColor" },
	{ k: "altParity" },
	{ k: "straight3" },
	{ k: "allEven" },
	{ k: "allOdd" },
	{
		k: "threeOf",
		a: v
	},
	{
		k: "threeOf",
		a: g
	},
	{
		k: "sumColor",
		a: v,
		n: 7
	},
	{
		k: "sumColor",
		a: g,
		n: 4
	},
	{
		k: "sumColor",
		a: y,
		n: 11
	},
	{
		k: "sumColor",
		a: y,
		n: 2
	},
	{
		k: "sumColor",
		a: v,
		n: 6
	},
	{
		k: "sumColor",
		a: g,
		n: 10
	},
	{
		k: "sumAll",
		n: 10
	},
	{
		k: "threeOf",
		a: y
	},
	{
		k: "threeOf",
		a: _
	},
	{
		k: "sumAll",
		n: 18
	},
	{
		k: "sumAll",
		n: 20
	},
	{
		k: "sumAll",
		n: 15
	},
	{
		k: "sumColor",
		a: _,
		n: 9
	},
	{
		k: "sumColor",
		a: _,
		n: 3
	},
	{
		k: "alt2",
		a: v
	},
	{
		k: "alt2",
		a: _
	},
	{
		k: "alt2",
		a: y
	},
	{
		k: "alt2",
		a: g
	}
], x = {
	gt4: "games.cahoots.goal.gt4",
	lt4: "games.cahoots.goal.lt4",
	half: "games.cahoots.goal.half",
	adj2: "games.cahoots.goal.adj2",
	nonAdj2: "games.cahoots.goal.nonAdj2",
	alt2: "games.cahoots.goal.alt2",
	sumEq: "games.cahoots.goal.sumEq",
	only2: "games.cahoots.goal.only2",
	noSameNum: "games.cahoots.goal.noSameNum",
	noSameColor: "games.cahoots.goal.noSameColor",
	noSameBoth: "games.cahoots.goal.noSameBoth",
	straight4: "games.cahoots.goal.straight4",
	straight3: "games.cahoots.goal.straight3",
	allEven: "games.cahoots.goal.allEven",
	allOdd: "games.cahoots.goal.allOdd",
	altParity: "games.cahoots.goal.altParity",
	threeOf: "games.cahoots.goal.threeOf",
	sumColor: "games.cahoots.goal.sumColor",
	sumAll: "games.cahoots.goal.sumAll"
}, S = (e, t) => e.reduce((e, n) => n.c === t ? e + n.n : e, 0), C = (e, t) => e.filter((e) => e.c === t).length;
function w(e, t) {
	switch (e.k) {
		case "gt4": return t.every((e) => e.n > 4);
		case "lt4": return t.every((e) => e.n < 4);
		case "allEven": return t.every((e) => e.n % 2 == 0);
		case "allOdd": return t.every((e) => e.n % 2 == 1);
		case "altParity": {
			let e = t.map((e) => e.n % 2);
			return e[0] === e[2] && e[1] === e[3] && e[0] !== e[1];
		}
		case "noSameNum": return new Set(t.map((e) => e.n)).size === 4;
		case "noSameColor": return new Set(t.map((e) => e.c)).size === 4;
		case "noSameBoth": return new Set(t.map((e) => e.n)).size === 4 && new Set(t.map((e) => e.c)).size === 4;
		case "straight4": {
			let e = t.map((e) => e.n).sort((e, t) => e - t);
			return e[3] - e[0] === 3 && new Set(e).size === 4;
		}
		case "straight3": {
			let e = (e) => {
				let n = t[e + 1].n - t[e].n, r = t[e + 2].n - t[e + 1].n;
				return n === 1 && r === 1 || n === -1 && r === -1;
			};
			return e(0) || e(1);
		}
		case "adj2": return t.some((n, r) => r < 3 && n.c === e.a && t[r + 1].c === e.a);
		case "nonAdj2": return t[0].c === e.a && t[2].c === e.a || t[0].c === e.a && t[3].c === e.a || t[1].c === e.a && t[3].c === e.a;
		case "alt2": return t[0].c === e.a && t[2].c === e.a || t[1].c === e.a && t[3].c === e.a;
		case "threeOf": return C(t, e.a) === 3;
		case "only2": return t.every((t) => t.c === e.a || t.c === e.b);
		case "sumColor": return S(t, e.a) === e.n;
		case "sumAll": return t.reduce((e, t) => e + t.n, 0) === e.n;
		case "sumEq": return C(t, e.a) + C(t, e.b) > 0 && S(t, e.a) === S(t, e.b);
		case "half": return C(t, e.a) + C(t, e.b) > 0 && S(t, e.a) * 2 === S(t, e.b);
	}
}
//#endregion
//#region src/games/cahoots/meta.ts
var T = {
	id: "cahoots",
	tier: "released",
	mechanics: ["hand-management"],
	interactionTags: ["cooperative", "communication-limits"],
	nameKey: "games.cahoots.name",
	descKey: "games.cahoots.desc",
	rulesKey: "games.cahoots.rules",
	icon: "🤝",
	iconImg: "games/cahoots.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/cahoots/en.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [4],
	accent: "#0d9488",
	releasedAt: "2026-09-15",
	search: {
		py: "tong mou",
		init: "tm"
	},
	hotseat: "cover"
}, E = t.int().min(0).max(55), D = t.int().min(0).max(49), O = t.string(), k = t.discriminatedUnion("type", [t.object({
	type: t.literal("play"),
	card: E,
	pile: t.int().min(0).max(3)
})]), A = [
	"beginner",
	"normal",
	"expert",
	"insane"
], j = t.object({ difficulty: t.enum(A).default("normal") }).default({ difficulty: "normal" }), M = t.discriminatedUnion("k", [t.object({
	k: t.literal("play"),
	rid: O,
	card: E,
	pile: t.int().min(0).max(3),
	met: t.array(D)
}), t.object({
	k: t.literal("start"),
	met: t.array(D).min(1)
})]), N = t.object({
	phase: t.enum(["play", "done"]),
	turn: O,
	piles: t.array(t.array(E)).length(4),
	goals: t.array(D),
	goalLeft: t.int().nonnegative(),
	doneCount: t.int().nonnegative(),
	goalTotal: t.int().positive(),
	deckCount: t.int().nonnegative(),
	players: t.array(t.object({
		rid: O,
		handCount: t.int().nonnegative()
	})),
	result: t.enum(["win", "lose"]).nullable(),
	log: t.array(M)
}), P = t.object({ hand: t.array(E) }), F = 4, I = 4, L = {
	beginner: {
		small: 15,
		four: 12
	},
	normal: {
		small: 18,
		four: 15
	},
	expert: {
		small: 21,
		four: 18
	},
	insane: {
		small: 24,
		four: 21
	}
}, R = (e) => Math.floor(e / 14), z = (e) => Math.floor(e / 2) % 7 + 1, B = 60;
function V(e, t) {
	e.log.push(t), e.log.length > B && e.log.splice(0, e.log.length - B);
}
function H(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.rngCursor, n + 1);
		t.rngCursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
var U = (e) => e.piles.map((e) => ({
	c: R(e[e.length - 1]),
	n: z(e[e.length - 1])
}));
function ee(e) {
	let t = U(e), n = e.goals.filter((e) => w(b[e], t));
	return n.length === 0 ? n : (e.done.push(...n), e.goals = e.goals.flatMap((t) => n.includes(t) ? e.goalDeck.length > 0 ? [e.goalDeck.shift()] : [] : [t]), n);
}
function W(e) {
	let t = [];
	for (;;) {
		let n = ee(e);
		if (n.length === 0) return t;
		t.push(...n);
	}
}
function te(e, t) {
	let n = e.hands[t];
	return !n || n.length === 0 ? !1 : n.some((t) => e.piles.some((e) => G(t, e[e.length - 1])));
}
var G = (e, t) => R(e) === R(t) || z(e) === z(t);
function K(e) {
	return e.goals.length === 0 && e.goalDeck.length === 0 ? (e.phase = "done", e.result = "win", !0) : !te(e, e.players[e.turnIdx]) && (e.phase = "done", e.result = "lose", !0);
}
function ne(e, t, n) {
	let r = {
		seed: n,
		rngCursor: 0,
		players: t,
		turnIdx: 0,
		piles: [
			[],
			[],
			[],
			[]
		],
		deck: [],
		hands: {},
		goalDeck: [],
		goals: [],
		done: [],
		goalTotal: 0,
		phase: "play",
		result: null,
		log: []
	}, i = H(r, Array.from({ length: 56 }, (e, t) => t));
	for (let e of t) r.hands[e] = i.splice(0, F);
	for (let e = 0; e < 4; e += 1) r.piles[e] = [i.shift()];
	r.deck = i;
	let a = t.length >= 4 ? L[e.difficulty].four : L[e.difficulty].small;
	r.goalDeck = H(r, Array.from({ length: b.length }, (e, t) => t)).slice(0, a), r.goalTotal = a;
	for (let e = 0; e < I; e += 1) r.goals.push(r.goalDeck.shift());
	let o = W(r);
	return o.length > 0 && V(r, {
		k: "start",
		met: o
	}), K(r), {
		state: r,
		fx: r.players.map((e, t) => ({
			kind: "deal",
			rid: e,
			data: { count: F },
			for: [e],
			secret: { cards: r.hands[e] },
			...t > 0 ? { with: !0 } : {}
		}))
	};
}
function re(e, t, n) {
	if (e.phase === "done") return { code: "games.cahoots.errDone" };
	if (n.by !== e.players[e.turnIdx]) return { code: "games.cahoots.errNotYourTurn" };
	if (!e.hands[n.by]?.includes(t.card)) return { code: "games.cahoots.errBadCard" };
	let r = e.piles[t.pile];
	if (!r || !G(t.card, r[r.length - 1])) return { code: "games.cahoots.errBadPile" };
	let i = structuredClone(e);
	i.hands[n.by] = i.hands[n.by].filter((e) => e !== t.card), i.piles[t.pile].push(t.card);
	let a = null;
	i.deck.length > 0 && (a = i.deck.shift(), i.hands[n.by].push(a));
	let o = W(i);
	V(i, {
		k: "play",
		rid: n.by,
		card: t.card,
		pile: t.pile,
		met: o
	});
	let s = [{
		kind: "play",
		rid: n.by,
		data: {
			card: t.card,
			pile: t.pile
		}
	}];
	return a !== null && s.push({
		kind: "draw",
		rid: n.by,
		data: {},
		for: [n.by],
		secret: { card: a },
		with: !0
	}), o.length > 0 && s.push({
		kind: "goal",
		data: { goals: o },
		with: !0
	}), i.turnIdx = (i.turnIdx + 1) % i.players.length, K(i), {
		state: i,
		fx: s
	};
}
function ie(e, t) {
	return {
		public: {
			phase: e.phase,
			turn: e.players[e.turnIdx],
			piles: e.piles.map((e) => [...e]),
			goals: [...e.goals],
			goalLeft: e.goalDeck.length,
			doneCount: e.done.length,
			goalTotal: e.goalTotal,
			deckCount: e.deck.length,
			players: e.players.map((t) => ({
				rid: t,
				handCount: e.hands[t]?.length ?? 0
			})),
			result: e.result,
			log: e.log.map((e) => ({ ...e }))
		},
		private: { hand: [...e.hands[t] ?? []] }
	};
}
function ae(e) {
	return e.phase === "done" ? {
		phase: "done",
		winner: e.result === "win" ? [...e.players] : [],
		ranking: [...e.players],
		scores: Object.fromEntries(e.players.map((t) => [t, e.done.length]))
	} : { phase: e.phase };
}
var oe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: T,
	schemas: {
		action: k,
		publicView: N,
		privateView: P,
		config: j
	},
	setup: ne,
	reduce: re,
	viewFor: ie,
	status: ae
}, q = [
	"#e84995",
	"#9e5bd0",
	"#91c62d",
	"#f79336"
];
function J({ color: e, x: t, y: n, scale: r = 1 }) {
	let i = `translate(${t} ${n}) scale(${r})`;
	switch (e) {
		case 0: return /* @__PURE__ */ d("path", {
			transform: i,
			d: "M0-6 1.7-1.7 6 0 1.7 1.7 0 6-1.7 1.7-6 0-1.7-1.7Z",
			fill: "currentColor"
		});
		case 2: return /* @__PURE__ */ f("g", {
			transform: i,
			fill: "currentColor",
			children: [
				/* @__PURE__ */ d("circle", {
					cx: "-2.7",
					cy: "0",
					r: "2.5"
				}),
				/* @__PURE__ */ d("circle", {
					cx: "2.7",
					cy: "0",
					r: "2.5"
				}),
				/* @__PURE__ */ d("circle", {
					cx: "0",
					cy: "-2.7",
					r: "2.5"
				}),
				/* @__PURE__ */ d("circle", {
					cx: "0",
					cy: "2.7",
					r: "2.5"
				})
			]
		});
		case 1: return /* @__PURE__ */ d("path", {
			transform: i,
			d: "M0-6 6 0 0 6-6 0Z",
			fill: "currentColor"
		});
		default: return /* @__PURE__ */ d("path", {
			transform: i,
			d: "M1-6-4 1H0L-1 6 5-1H1Z",
			fill: "currentColor"
		});
	}
}
function Y({ color: e, size: t = 14 }) {
	return /* @__PURE__ */ d("svg", {
		"aria-hidden": "true",
		width: t,
		height: t,
		viewBox: "-7 -7 14 14",
		style: { color: q[e] },
		children: /* @__PURE__ */ d(J, {
			color: e,
			x: 0,
			y: 0
		})
	});
}
function X({ id: e, size: t = "hand" }) {
	let n = R(e), r = z(e);
	return /* @__PURE__ */ d("span", {
		className: `cahoots-number cahoots-number--${t}`,
		children: /* @__PURE__ */ f("svg", {
			"aria-hidden": "true",
			viewBox: "0 0 60 84",
			preserveAspectRatio: "none",
			children: [
				/* @__PURE__ */ d("rect", {
					x: "1",
					y: "1",
					width: "58",
					height: "82",
					rx: "5.5",
					fill: "#fff8e9",
					stroke: "#fffdf1",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ d("rect", {
					x: "4",
					y: "4",
					width: "52",
					height: "76",
					rx: "4",
					fill: q[n]
				}),
				/* @__PURE__ */ d("path", {
					d: "M4 66V80H26Z",
					fill: "#fff8e9"
				}),
				/* @__PURE__ */ d("text", {
					x: "9",
					y: "15",
					fill: "#fff",
					fontSize: "9",
					fontWeight: "800",
					fontFamily: "Arial, sans-serif",
					children: r
				}),
				/* @__PURE__ */ d("g", {
					color: "#fff",
					children: /* @__PURE__ */ d(J, {
						color: n,
						x: 48,
						y: 12,
						scale: .72
					})
				}),
				/* @__PURE__ */ d("text", {
					x: "30",
					y: "57",
					textAnchor: "middle",
					fill: "#fff",
					fontSize: "43",
					fontWeight: "800",
					fontFamily: "Arial, sans-serif",
					children: r
				})
			]
		})
	});
}
//#endregion
//#region src/games/cahoots/view-player.tsx
var Z = {
	0: "games.cahoots.color.pink",
	1: "games.cahoots.color.purple",
	2: "games.cahoots.color.green",
	3: "games.cahoots.color.orange"
};
function se(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ d(ce, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function ce({ pub: e, priv: t, members: p, myRid: m, send: h }) {
	let g = o(), _ = a((e) => e.locale), v = (e) => {
		let t = p.find((t) => t.rid === e);
		return t ? c(t, _) : e;
	}, [y, b] = r(null), [x, S] = r(null), [C, w] = r(1), E = x === null ? C : Math.min(6, Math.max(1, e.piles[x].length));
	E !== C && w(E);
	let D = t?.hand ?? [], O = e.phase === "play" && e.turn === m, k = `${e.turn}|${D.join(".")}`, [A, j] = r(k);
	A !== k && (j(k), b(null));
	let [M, N] = r({
		goals: e.goals,
		left: e.goalLeft
	}), [P, F] = r([]), [I, L] = r([]);
	if ((!(e.goals.length === M.goals.length && e.goals.every((e, t) => e === M.goals[t])) || e.goalLeft !== M.left) && P.length === 0 && I.length === 0) {
		let t = M.goals.filter((t) => !e.goals.includes(t));
		t.length > 0 ? F(t) : N({
			goals: e.goals,
			left: e.goalLeft
		});
	}
	n(() => {
		if (P.length === 0) return;
		let e = setTimeout(() => {
			L(P), F([]);
		}, 400);
		return () => clearTimeout(e);
	}, [P]), n(() => {
		if (I.length === 0) return;
		let t = setTimeout(() => {
			N({
				goals: e.goals,
				left: e.goalLeft
			}), L([]);
		}, 200);
		return () => clearTimeout(t);
	}, [
		I,
		e.goals,
		e.goalLeft
	]);
	let B = (t) => {
		if (y === null) return !1;
		let n = e.piles[t][e.piles[t].length - 1];
		return R(y) === R(n) || z(y) === z(n);
	}, V = (e) => {
		if (O && y !== null && B(e)) {
			h({
				type: "play",
				card: y,
				pile: e
			}), b(null);
			return;
		}
		y === null && S(e);
	}, H, U;
	return O ? (H = "accent", U = g("games.cahoots.turnYou")) : (H = "info", U = g("games.cahoots.turnWait", { name: v(e.turn) })), /* @__PURE__ */ f("div", {
		className: "cahoots-screen h-full min-h-0",
		style: { "--cahoots-history-columns": C },
		children: [/* @__PURE__ */ d(l, {
			adaptive: !0,
			className: "cahoots-adaptive",
			scroll: !1,
			actionsHeight: "cahoots-actions-height",
			banner: /* @__PURE__ */ f("div", {
				className: "cahoots-top",
				children: [/* @__PURE__ */ d(s, {
					tone: H,
					text: U,
					accent: T.accent
				}), /* @__PURE__ */ d("ul", {
					className: "cahoots-players",
					style: { "--cahoots-player-count": p.length },
					children: p.map((t) => {
						let n = c(t, _), r = e.players.find((e) => e.rid === t.rid)?.handCount;
						return /* @__PURE__ */ f("li", {
							className: `cahoots-player ${t.online ? "" : "cahoots-player--offline"}`,
							"aria-current": t.rid === e.turn ? "true" : void 0,
							children: [
								/* @__PURE__ */ d("span", {
									className: "cahoots-player-token",
									style: { backgroundColor: u[t.colorIndex % u.length].hex },
									"aria-hidden": "true",
									children: t.rid === m ? g("games.cahoots.selfToken") : Array.from(n)[0]
								}),
								/* @__PURE__ */ d("span", {
									className: "cahoots-player-name",
									title: n,
									children: t.rid === m ? g("lobby.you") : n
								}),
								/* @__PURE__ */ d("span", {
									className: "cahoots-player-count",
									children: r === void 0 ? "" : g("games.cahoots.stripHand", { n: r })
								})
							]
						}, t.rid);
					})
				})]
			}),
			actions: /* @__PURE__ */ d("div", {
				className: "cahoots-hand-zone",
				children: t && /* @__PURE__ */ d("div", {
					className: "cahoots-hand",
					children: D.map((e) => /* @__PURE__ */ d("button", {
						type: "button",
						disabled: !O,
						onClick: () => b(y === e ? null : e),
						className: `cahoots-hand-card ${y === e ? "cahoots-hand-card--selected" : ""}`,
						"aria-label": `${g(Z[R(e)])} ${z(e)}`,
						"aria-pressed": y === e,
						children: /* @__PURE__ */ d(X, { id: e })
					}, e))
				})
			}),
			children: /* @__PURE__ */ d("div", {
				className: "cahoots-board",
				style: { backgroundImage: "url(./games/cahoots/scene.webp)" },
				children: /* @__PURE__ */ f("div", {
					className: "cahoots-board__inner",
					children: [/* @__PURE__ */ f("div", {
						className: "cahoots-goal-area",
						children: [/* @__PURE__ */ f("div", {
							className: "cahoots-goal-counts",
							children: [
								/* @__PURE__ */ d("span", { children: g("games.cahoots.goalLeft", { n: M.left }) }),
								/* @__PURE__ */ d("span", {
									className: "cahoots-count-separator",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ d("strong", { children: g("games.cahoots.progress", {
									done: e.doneCount,
									total: e.goalTotal
								}) })
							]
						}), /* @__PURE__ */ d("div", {
							className: "cahoots-goals",
							children: Array.from({ length: 4 }, (e, t) => {
								let n = M.goals[t];
								return n === void 0 ? /* @__PURE__ */ d("div", {
									className: "cahoots-goal cahoots-goal--empty",
									"aria-hidden": "true",
									children: /* @__PURE__ */ d("svg", {
										viewBox: "0 0 24 24",
										children: /* @__PURE__ */ d("path", {
											d: "m4 12 5 5L20 6",
											fill: "none",
											stroke: "currentColor",
											strokeWidth: "3",
											strokeLinecap: "round",
											strokeLinejoin: "round"
										})
									})
								}, `empty-${t}`) : /* @__PURE__ */ d(fe, {
									id: n,
									stage: P.includes(n) ? "celebrate" : I.includes(n) ? "exit" : void 0
								}, n);
							})
						})]
					}), /* @__PURE__ */ d("div", {
						className: "cahoots-play-area",
						children: /* @__PURE__ */ f("div", {
							className: "cahoots-piles",
							children: [/* @__PURE__ */ f("div", {
								className: "cahoots-draw",
								"aria-label": g("games.cahoots.deckLeft", { n: e.deckCount }),
								children: [/* @__PURE__ */ d("span", {
									className: `cahoots-draw-stack ${e.deckCount === 0 ? "cahoots-draw-stack--empty" : ""}`,
									"aria-hidden": "true",
									children: /* @__PURE__ */ d("svg", {
										width: "27",
										height: "27",
										viewBox: "0 0 27 27",
										children: /* @__PURE__ */ d("path", {
											d: "m13.5 1 3.2 9.3L26 13.5l-9.3 3.2L13.5 26l-3.2-9.3L1 13.5l9.3-3.2Z",
											fill: "currentColor"
										})
									})
								}), /* @__PURE__ */ d("span", {
									className: "cahoots-draw-count",
									children: e.deckCount
								})]
							}), e.piles.map((e, t) => {
								let n = e[e.length - 1], r = O && y !== null && B(t);
								return /* @__PURE__ */ f("button", {
									type: "button",
									onClick: () => V(t),
									className: `cahoots-pile ${r ? "cahoots-pile--legal" : ""} ${O && y !== null && !r ? "cahoots-pile--dim" : ""}`,
									"aria-label": g("games.cahoots.pileAria", { n: t + 1 }),
									children: [/* @__PURE__ */ f("span", {
										className: "cahoots-pile-card-wrap",
										children: [/* @__PURE__ */ d(X, {
											id: n,
											size: "pile"
										}), r && /* @__PURE__ */ d("span", {
											className: "cahoots-pile-check",
											"aria-hidden": "true",
											children: /* @__PURE__ */ d("svg", {
												width: "12",
												height: "12",
												viewBox: "0 0 12 12",
												children: /* @__PURE__ */ d("path", {
													d: "m2 6 2.5 2.5L10 3",
													fill: "none",
													stroke: "currentColor",
													strokeWidth: "2",
													strokeLinecap: "round",
													strokeLinejoin: "round"
												})
											})
										})]
									}), /* @__PURE__ */ f("span", {
										className: "cahoots-pile-count",
										children: [
											t + 1,
											" · ×",
											e.length
										]
									})]
								}, t);
							})]
						})
					})]
				})
			})
		}), /* @__PURE__ */ d(i, {
			open: x !== null,
			onClose: () => S(null),
			label: g("games.cahoots.pileHistory"),
			children: x !== null && /* @__PURE__ */ f("div", {
				className: "cahoots-history",
				children: [/* @__PURE__ */ d("p", {
					className: "section-label",
					children: g("games.cahoots.pileAria", { n: x + 1 })
				}), /* @__PURE__ */ d("div", {
					className: "cahoots-history-cards",
					children: [...e.piles[x]].reverse().map((e, t) => /* @__PURE__ */ d(X, {
						id: e,
						size: "history"
					}, `${e}-${t}`))
				})]
			})
		})]
	});
}
var le = {
	celebrate: "goal-leave",
	exit: "goal-exit-up"
}, ue = [
	"#b32769",
	"#7941a7",
	"#527b13",
	"#b85b17"
];
function de(e, t) {
	let n = t.map((e) => e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
	return e.split(RegExp(`(${n.join("|")})`, "gi")).map((e, n) => {
		let r = t.findIndex((t) => t.toLocaleLowerCase() === e.toLocaleLowerCase());
		return r < 0 ? e : /* @__PURE__ */ d("span", {
			style: { color: ue[r] },
			children: e
		}, n);
	});
}
function fe({ id: e, stage: t }) {
	let n = o(), r = b[e], i = n(x[r.k], {
		a: r.a === void 0 ? "" : n(Z[r.a]),
		b: r.b === void 0 ? "" : n(Z[r.b]),
		n: r.n ?? 0
	}), a = [
		0,
		1,
		2,
		3
	].map((e) => n(Z[e])), s = r.a === void 0 ? "#0d9488" : q[r.a];
	return /* @__PURE__ */ f("div", {
		className: `cahoots-goal ${t ? le[t] : "goal-enter"}`,
		style: { "--cahoots-goal-accent": s },
		children: [
			/* @__PURE__ */ f("span", {
				className: "cahoots-goal-symbols",
				"aria-hidden": "true",
				children: [r.a === void 0 ? /* @__PURE__ */ d("svg", {
					width: "14",
					height: "14",
					viewBox: "0 0 14 14",
					children: /* @__PURE__ */ d("path", {
						d: "M7 1 8.5 5.5 13 7 8.5 8.5 7 13 5.5 8.5 1 7 5.5 5.5Z",
						fill: "#0d9488"
					})
				}) : /* @__PURE__ */ d(Y, { color: r.a }), r.b !== void 0 && /* @__PURE__ */ d(Y, { color: r.b })]
			}),
			/* @__PURE__ */ d("span", {
				className: "cahoots-goal-content",
				children: /* @__PURE__ */ d("span", {
					className: "cahoots-goal-text",
					children: de(i, a)
				})
			}),
			/* @__PURE__ */ d("span", {
				className: "cahoots-goal-pin",
				"aria-hidden": "true"
			})
		]
	});
}
//#endregion
//#region src/games/cahoots/bot.ts
function Q(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var pe = (e, t) => {
	let n = [];
	for (let r of e) for (let e = 0; e < 4; e += 1) {
		let i = t[e];
		(R(r) === R(i) || z(r) === z(i)) && n.push({
			card: r,
			pile: e
		});
	}
	return n;
}, me = (e, t) => {
	for (let n = 0; n < 4; n += 1) for (let r = 0; r < 4; r += 1) for (let i = 1; i <= 7; i += 1) {
		if (r === t[n].c && i === t[n].n) continue;
		let a = t.slice();
		if (a[n] = {
			c: r,
			n: i
		}, w(e, a)) return !0;
	}
	return !1;
}, he = (e, t) => w(e, t) ? 0 : me(e, t) ? 1 : 2, ge = (e, t) => {
	let n = e.public, r = e.private;
	if (n.phase === "done" || n.turn !== t.rid || !r) return null;
	let i = n.piles.map((e) => e[e.length - 1]), a = pe(r.hand, i);
	if (a.length === 0) return null;
	if (t.difficulty === "weak") {
		let e = Q(a);
		return { action: {
			type: "play",
			card: e.card,
			pile: e.pile
		} };
	}
	let o = i.map((e) => ({
		c: R(e),
		n: z(e)
	})), s = n.goals.map((e) => he(b[e], o)), c = a.map((e) => {
		let t = o.map((t, n) => n === e.pile ? {
			c: R(e.card),
			n: z(e.card)
		} : t), i = 0, a = 0, c = 0;
		n.goals.forEach((e, n) => {
			let r = he(b[e], t);
			r === 0 ? i += 1 : (a += s[n] - r, r === 1 && (c += 1));
		});
		let l = r.hand.some((t) => t !== e.card && R(t) === R(e.card)), u = r.hand.some((t) => t !== e.card && z(t) === z(e.card)), d = new Set(t.map((e) => e.c)), f = new Set(t.map((e) => e.n));
		return {
			m: e,
			score: i * 1e3 + a * 30 + c * 25 + (l ? 3 : 0) + (u ? 3 : 0) + d.size * 2 + f.size * 2
		};
	}), l = Math.max(...c.map((e) => e.score)), u = Q(c.filter((e) => e.score === l).map((e) => e.m));
	return { action: {
		type: "play",
		card: u.card,
		pile: u.pile
	} };
}, $ = {
	0: "games.cahoots.color.pink",
	1: "games.cahoots.color.purple",
	2: "games.cahoots.color.green",
	3: "games.cahoots.color.orange"
};
function _e({ result: e, public: t, members: n, onPlayAgain: r, onBackToLobby: i }) {
	let s = o(), l = a((e) => e.locale), u = t, m = u.result === "win", h = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? c(t, l) : e;
	}, g = u.goals.length + u.goalLeft;
	return /* @__PURE__ */ f("div", {
		className: "cahoots-over",
		style: { backgroundImage: "url(./games/cahoots/scene.webp)" },
		children: [m && /* @__PURE__ */ d(p, {}), /* @__PURE__ */ f("div", {
			className: "cahoots-over__inner",
			children: [
				/* @__PURE__ */ f("header", {
					className: "cahoots-over__heading",
					children: [/* @__PURE__ */ d("span", {
						"aria-hidden": !0,
						className: `cahoots-over__seal ${m ? "" : "cahoots-over__seal--lose"}`,
						children: m ? "✓" : "×"
					}), /* @__PURE__ */ d("h1", { children: s(m ? "games.cahoots.overWin" : "games.cahoots.overLose") })]
				}),
				/* @__PURE__ */ f("div", {
					className: "cahoots-over__content",
					children: [/* @__PURE__ */ f("section", {
						className: "cahoots-over__team cahoots-over__paper",
						children: [
							/* @__PURE__ */ f("div", {
								className: "cahoots-over__progress",
								children: [
									/* @__PURE__ */ f("strong", {
										className: "font-mono tabular-nums",
										"aria-label": s("games.cahoots.overProgress", {
											done: u.doneCount,
											total: u.goalTotal
										}),
										children: [u.doneCount, /* @__PURE__ */ f("span", { children: [" / ", u.goalTotal] })]
									}),
									/* @__PURE__ */ d("p", { children: s("games.cahoots.overProgressLabel") }),
									!m && /* @__PURE__ */ d("p", { children: s("games.cahoots.overUnfinished", { n: g }) })
								]
							}),
							/* @__PURE__ */ d("h2", { children: s("games.cahoots.overTeam") }),
							/* @__PURE__ */ d("ul", {
								className: "cahoots-over__players",
								children: e.ranking.map((e) => /* @__PURE__ */ f("li", {
									className: "cahoots-over__player",
									children: [/* @__PURE__ */ d("span", {
										"aria-hidden": !0,
										children: m ? "✓" : "×"
									}), /* @__PURE__ */ d("span", {
										className: "cahoots-over__name",
										title: h(e),
										children: h(e)
									})]
								}, e))
							})
						]
					}), /* @__PURE__ */ f("div", {
						className: "cahoots-over__review",
						children: [/* @__PURE__ */ f("section", {
							className: "cahoots-over__table cahoots-over__paper",
							children: [/* @__PURE__ */ f("div", {
								className: "cahoots-over__table-heading",
								children: [/* @__PURE__ */ d("h2", { children: s("games.cahoots.overTable") }), /* @__PURE__ */ d("p", {
									className: "font-mono tabular-nums",
									children: s("games.cahoots.deckLeft", { n: u.deckCount })
								})]
							}), /* @__PURE__ */ d("ol", {
								className: "cahoots-over__piles",
								children: u.piles.map((e, t) => {
									let n = e[e.length - 1];
									return /* @__PURE__ */ f("li", {
										className: "cahoots-over__pile",
										"aria-label": `${s("games.cahoots.pileAria", { n: t + 1 })}: ${s($[R(n)])} ${z(n)}, ${s("games.cahoots.stripHand", { n: e.length })}`,
										children: [/* @__PURE__ */ d(X, {
											id: n,
											size: "pile"
										}), /* @__PURE__ */ f("span", {
											className: "cahoots-over__pile-count font-mono tabular-nums",
											children: [
												t + 1,
												" · ×",
												e.length
											]
										})]
									}, t);
								})
							})]
						}), u.goals.length > 0 && /* @__PURE__ */ f("section", {
							className: "cahoots-over__goals cahoots-over__paper",
							children: [/* @__PURE__ */ d("h2", { children: s("games.cahoots.overVisibleGoals") }), /* @__PURE__ */ d("ul", {
								className: "cahoots-over__goal-list",
								children: u.goals.map((e) => {
									let t = b[e], n = s(x[t.k], {
										a: t.a === void 0 ? "" : s($[t.a]),
										b: t.b === void 0 ? "" : s($[t.b]),
										n: t.n ?? 0
									});
									return /* @__PURE__ */ f("li", {
										className: "cahoots-over__goal",
										style: { "--cahoots-goal-accent": t.a === void 0 ? T.accent : q[t.a] },
										children: [t.a !== void 0 && /* @__PURE__ */ f("span", {
											className: "cahoots-over__goal-symbols",
											"aria-hidden": "true",
											children: [/* @__PURE__ */ d(Y, { color: t.a }), t.b !== void 0 && /* @__PURE__ */ d(Y, { color: t.b })]
										}), /* @__PURE__ */ d("span", { children: n })]
									}, e);
								})
							})]
						})]
					})]
				}),
				/* @__PURE__ */ f("footer", {
					className: "cahoots-over__actions safe-b",
					children: [
						r && /* @__PURE__ */ d("button", {
							type: "button",
							className: "btn-base text-white",
							style: { background: T.accent },
							onClick: r,
							children: s("session.result.playAgain")
						}),
						i && /* @__PURE__ */ d("button", {
							type: "button",
							className: "btn-quiet",
							onClick: i,
							children: s("session.result.backToLobby")
						}),
						!r && !i && /* @__PURE__ */ d("p", { children: s("session.result.waitHost") })
					]
				})
			]
		})]
	});
}
//#endregion
//#region src/games/cahoots/options.tsx
var ve = {
	beginner: "games.cahoots.diff.beginner",
	normal: "games.cahoots.diff.normal",
	expert: "games.cahoots.diff.expert",
	insane: "games.cahoots.diff.insane"
};
function ye({ value: e, onChange: t }) {
	let n = o(), r = j.safeParse(e), i = r.success ? r.data : j.parse(void 0);
	return /* @__PURE__ */ f("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ d(h, {
			title: n("games.cahoots.optDifficulty"),
			children: A.map((e) => /* @__PURE__ */ d(m, {
				name: "cahoots-difficulty",
				value: e,
				checked: i.difficulty === e,
				label: n(ve[e]),
				accent: T.accent,
				onChange: () => t({ difficulty: e })
			}, e))
		}), /* @__PURE__ */ d("p", {
			className: "text-xs text-ink/70",
			children: n("games.cahoots.optDifficultyHint")
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/cahoots/entry.tsx
var be = {
	definition: oe,
	View: se,
	bot: ge,
	OverView: _e,
	Options: ye,
	locales: {
		zh: {
			name: "同谋 Cahoots",
			desc: "合作出牌:轮流往四个牌堆放牌,凑出目标牌要求的牌面,全程不许透露手牌",
			rules: "目标:全队合作完成所有目标牌,即共同获胜。\n组件:\n· 数字牌 56 张:4 种颜色 × 数字 1~7,各两张。\n· 目标牌 50 张,按难度取出一部分组成本局目标牌堆。\n流程:\n· 每人 4 张手牌,彼此保密;桌面有 4 个明置牌堆与 4 张公开目标牌。\n· 轮到你:将一张手牌放到任一牌堆顶,须与堆顶牌同色或同号,然后将手牌补回 4 张。\n· 打出的牌使某张公开目标成立时(只检查四个堆顶),该目标立即完成,并补翻一张新目标。\n失败:\n· 抽牌堆抽空且全员手牌打完,或轮到的玩家没有任何合法出牌。\n沟通限制:\n· 不得透露自己手牌的颜色或数字;只能表达想往哪堆放、建议完成哪张目标。\n· 目标判定严格按字面执行:例如「三堆粉色」必须恰好三堆。",
			progress: "完成 {{done}}/{{total}}",
			stripHand: "{{n}} 张",
			selfToken: "我",
			turnYou: "轮到你",
			turnWait: "等 {{name}} 出牌…",
			deckLeft: "抽牌 {{n}}",
			goalLeft: "目标剩 {{n}}",
			pileAria: "第 {{n}} 堆",
			pileHistory: "牌堆记录(新牌在上)",
			optDifficulty: "目标难度",
			optDifficultyHint: "目标牌数:2–3 人 入门15/普通18/专家21/疯狂24;4 人 12/15/18/21",
			overWin: "同心协力,目标全清!",
			overLose: "目标未完成",
			overProgress: "完成目标 {{done}}/{{total}}",
			overProgressLabel: "完成目标",
			overTeam: "协作团队",
			overTable: "终局牌面",
			overVisibleGoals: "尚未完成的公开目标",
			overUnfinished: "未完成目标 {{n}}",
			errDone: "本局已结束",
			errNotYourTurn: "还没轮到你",
			errBadCard: "手里没有这张牌",
			errBadPile: "只能打到与堆顶同色或同号的牌堆",
			color: {
				pink: "粉色",
				purple: "紫色",
				green: "绿色",
				orange: "橙色"
			},
			diff: {
				beginner: "入门",
				normal: "普通",
				expert: "专家",
				insane: "疯狂"
			},
			goal: {
				gt4: "所有牌都大于 4",
				lt4: "所有牌都小于 4",
				half: "{{a}}之和是{{b}}的一半",
				adj2: "相邻两堆都是{{a}}",
				nonAdj2: "两个不相邻的堆是{{a}}",
				alt2: "相间的两堆是{{a}}",
				sumEq: "{{a}}之和等于{{b}}之和",
				only2: "所有牌都是{{a}}或{{b}}",
				noSameNum: "没有重复的数字",
				noSameColor: "没有重复的颜色",
				noSameBoth: "颜色和数字都不重复",
				straight4: "四个数字连成顺子(任意顺序)",
				straight3: "相邻三堆数字连续(递增或递减)",
				allEven: "全是偶数",
				allOdd: "全是奇数",
				altParity: "奇偶相间",
				threeOf: "恰好三堆是{{a}}",
				sumColor: "{{a}}之和等于 {{n}}",
				sumAll: "所有牌之和等于 {{n}}"
			}
		},
		en: {
			name: "Cahoots",
			desc: "Co-op card play: match color or number onto four piles and meet every goal — without revealing your hand",
			rules: "Goal: complete all goal cards together to win as a team.\nContents:\n· 56 number cards: 4 colors × numbers 1–7, two of each.\n· 50 goal cards; a subset forms this game's goal deck depending on difficulty.\nHow to play:\n· Everyone holds 4 secret cards; the table has 4 face-up piles and 4 visible goal cards.\n· On your turn: play one card from your hand onto a pile — it must match the top card in color or number — then draw back up to 4.\n· If your card makes any visible goal true (judged on the four pile tops), that goal is completed at once and a new one is revealed.\nYou lose:\n· If the draw pile runs out with all hands empty, or a player cannot legally play.\nTable talk:\n· Never reveal the colors or numbers in your hand; you may only say which pile you want to play on or suggest which goal to finish.\n· Goals are judged exactly as written: “three pink piles” means exactly three.",
			progress: "Done {{done}}/{{total}}",
			stripHand: "{{n}} cards",
			selfToken: "Me",
			turnYou: "Your turn",
			turnWait: "Waiting for {{name}}…",
			deckLeft: "Draw {{n}}",
			goalLeft: "{{n}} goals left",
			pileAria: "Pile {{n}}",
			pileHistory: "Pile history (newest first)",
			optDifficulty: "Goal difficulty",
			optDifficultyHint: "Goal deck size: 2–3 players 15/18/21/24; 4 players 12/15/18/21",
			overWin: "All goals complete — in cahoots!",
			overLose: "Goals unfinished",
			overProgress: "Goals done {{done}}/{{total}}",
			overProgressLabel: "Goals complete",
			overTeam: "Team",
			overTable: "Final piles",
			overVisibleGoals: "Unfinished visible goals",
			overUnfinished: "{{n}} goals unfinished",
			errDone: "This round is over",
			errNotYourTurn: "Not your turn yet",
			errBadCard: "That card is not in your hand",
			errBadPile: "Play only on a pile matching color or number",
			color: {
				pink: "pink",
				purple: "purple",
				green: "green",
				orange: "orange"
			},
			diff: {
				beginner: "Beginner",
				normal: "Normal",
				expert: "Expert",
				insane: "Insane"
			},
			goal: {
				gt4: "All cards higher than 4",
				lt4: "All cards lower than 4",
				half: "{{a}} sum is half of {{b}}",
				adj2: "Two adjacent piles are {{a}}",
				nonAdj2: "Two non-adjacent piles are {{a}}",
				alt2: "Alternating piles are {{a}}",
				sumEq: "Sum of {{a}} equals sum of {{b}}",
				only2: "All cards are {{a}} or {{b}}",
				noSameNum: "No repeated numbers",
				noSameColor: "No repeated colors",
				noSameBoth: "No repeated color or number",
				straight4: "A straight of four (any order)",
				straight3: "A straight of three in a row",
				allEven: "All even",
				allOdd: "All odd",
				altParity: "Alternating even and odd",
				threeOf: "Three {{a}} piles",
				sumColor: "Sum of {{a}} cards is {{n}}",
				sumAll: "Sum of all cards is {{n}}"
			}
		}
	}
};
//#endregion
export { be as default };
