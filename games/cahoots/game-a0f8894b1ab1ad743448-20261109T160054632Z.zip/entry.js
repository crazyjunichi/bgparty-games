import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useI18nSettings as n, useT as r } from "@bgparty/sdk/i18n";
import { seatName as i } from "@bgparty/sdk/ui/player-strip";
import { AVATARS as a } from "@bgparty/sdk/avatars";
import { useEffect as o, useState as s } from "react";
import { BottomSheet as c } from "@bgparty/sdk/bottom-sheet";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { PLAYER_COLORS as d } from "@bgparty/sdk/player-colors";
import { jsx as f, jsxs as p } from "react/jsx-runtime";
import { Confetti as m } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as h, OptionSection as g } from "@bgparty/sdk/ui/game-options";
//#region src/games/cahoots/goals.ts
var _ = 0, v = 1, y = 2, b = 3, x = [
	{ k: "gt4" },
	{ k: "lt4" },
	{
		k: "half",
		a: _,
		b: v
	},
	{
		k: "half",
		a: v,
		b: y
	},
	{
		k: "half",
		a: y,
		b
	},
	{
		k: "half",
		a: b,
		b: _
	},
	{
		k: "adj2",
		a: _
	},
	{
		k: "adj2",
		a: y
	},
	{
		k: "nonAdj2",
		a: v
	},
	{
		k: "nonAdj2",
		a: b
	},
	{
		k: "nonAdj2",
		a: y
	},
	{
		k: "nonAdj2",
		a: _
	},
	{
		k: "sumEq",
		a: _,
		b
	},
	{
		k: "sumEq",
		a: b,
		b: y
	},
	{
		k: "sumEq",
		a: y,
		b: v
	},
	{
		k: "sumEq",
		a: v,
		b: _
	},
	{
		k: "adj2",
		a: v
	},
	{
		k: "adj2",
		a: b
	},
	{
		k: "only2",
		a: y,
		b: _
	},
	{ k: "noSameNum" },
	{ k: "noSameBoth" },
	{
		k: "only2",
		a: v,
		b
	},
	{
		k: "only2",
		a: _,
		b: v
	},
	{
		k: "only2",
		a: y,
		b
	},
	{ k: "straight4" },
	{ k: "noSameColor" },
	{ k: "altParity" },
	{ k: "straight3" },
	{ k: "allEven" },
	{ k: "allOdd" },
	{
		k: "threeOf",
		a: y
	},
	{
		k: "threeOf",
		a: _
	},
	{
		k: "sumColor",
		a: y,
		n: 7
	},
	{
		k: "sumColor",
		a: _,
		n: 4
	},
	{
		k: "sumColor",
		a: b,
		n: 11
	},
	{
		k: "sumColor",
		a: b,
		n: 2
	},
	{
		k: "sumColor",
		a: y,
		n: 6
	},
	{
		k: "sumColor",
		a: _,
		n: 10
	},
	{
		k: "sumAll",
		n: 10
	},
	{
		k: "threeOf",
		a: b
	},
	{
		k: "threeOf",
		a: v
	},
	{
		k: "sumAll",
		n: 18
	},
	{
		k: "sumAll",
		n: 20
	},
	{
		k: "sumAll",
		n: 15
	},
	{
		k: "sumColor",
		a: v,
		n: 9
	},
	{
		k: "sumColor",
		a: v,
		n: 3
	},
	{
		k: "alt2",
		a: y
	},
	{
		k: "alt2",
		a: v
	},
	{
		k: "alt2",
		a: b
	},
	{
		k: "alt2",
		a: _
	}
], S = {
	gt4: "games.cahoots.goal.gt4",
	lt4: "games.cahoots.goal.lt4",
	half: "games.cahoots.goal.half",
	adj2: "games.cahoots.goal.adj2",
	nonAdj2: "games.cahoots.goal.nonAdj2",
	alt2: "games.cahoots.goal.alt2",
	sumEq: "games.cahoots.goal.sumEq",
	only2: "games.cahoots.goal.only2",
	noSameNum: "games.cahoots.goal.noSameNum",
	noSameColor: "games.cahoots.goal.noSameColor",
	noSameBoth: "games.cahoots.goal.noSameBoth",
	straight4: "games.cahoots.goal.straight4",
	straight3: "games.cahoots.goal.straight3",
	allEven: "games.cahoots.goal.allEven",
	allOdd: "games.cahoots.goal.allOdd",
	altParity: "games.cahoots.goal.altParity",
	threeOf: "games.cahoots.goal.threeOf",
	sumColor: "games.cahoots.goal.sumColor",
	sumAll: "games.cahoots.goal.sumAll"
}, C = (e, t) => e.reduce((e, n) => n.c === t ? e + n.n : e, 0), w = (e, t) => e.filter((e) => e.c === t).length;
function T(e, t) {
	switch (e.k) {
		case "gt4": return t.every((e) => e.n > 4);
		case "lt4": return t.every((e) => e.n < 4);
		case "allEven": return t.every((e) => e.n % 2 == 0);
		case "allOdd": return t.every((e) => e.n % 2 == 1);
		case "altParity": {
			let e = t.map((e) => e.n % 2);
			return e[0] === e[2] && e[1] === e[3] && e[0] !== e[1];
		}
		case "noSameNum": return new Set(t.map((e) => e.n)).size === 4;
		case "noSameColor": return new Set(t.map((e) => e.c)).size === 4;
		case "noSameBoth": return new Set(t.map((e) => e.n)).size === 4 && new Set(t.map((e) => e.c)).size === 4;
		case "straight4": {
			let e = t.map((e) => e.n).sort((e, t) => e - t);
			return e[3] - e[0] === 3 && new Set(e).size === 4;
		}
		case "straight3": {
			let e = (e) => {
				let n = t[e + 1].n - t[e].n, r = t[e + 2].n - t[e + 1].n;
				return n === 1 && r === 1 || n === -1 && r === -1;
			};
			return e(0) || e(1);
		}
		case "adj2": return t.some((n, r) => r < 3 && n.c === e.a && t[r + 1].c === e.a);
		case "nonAdj2": return t[0].c === e.a && t[2].c === e.a || t[0].c === e.a && t[3].c === e.a || t[1].c === e.a && t[3].c === e.a;
		case "alt2": return t[0].c === e.a && t[2].c === e.a || t[1].c === e.a && t[3].c === e.a;
		case "threeOf": return w(t, e.a) === 3;
		case "only2": return t.every((t) => t.c === e.a || t.c === e.b);
		case "sumColor": return C(t, e.a) === e.n;
		case "sumAll": return t.reduce((e, t) => e + t.n, 0) === e.n;
		case "sumEq": return w(t, e.a) + w(t, e.b) > 0 && C(t, e.a) === C(t, e.b);
		case "half": return w(t, e.a) + w(t, e.b) > 0 && C(t, e.a) * 2 === C(t, e.b);
	}
}
//#endregion
//#region src/games/cahoots/meta.ts
var E = {
	id: "cahoots",
	tier: "released",
	mechanics: ["hand-management"],
	interactionTags: ["cooperative", "communication-limits"],
	nameKey: "games.cahoots.name",
	descKey: "games.cahoots.desc",
	rulesKey: "games.cahoots.rules",
	icon: "🤝",
	iconImg: "games/cahoots.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/cahoots/en.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [4],
	accent: "#0d9488",
	releasedAt: "2026-09-15",
	search: {
		py: "tong mou",
		init: "tm"
	},
	hotseat: "cover"
}, D = t.int().min(0).max(55), O = t.int().min(0).max(49), k = t.string(), A = t.discriminatedUnion("type", [t.object({
	type: t.literal("play"),
	card: D,
	pile: t.int().min(0).max(3)
})]), j = [
	"beginner",
	"normal",
	"expert",
	"insane"
], M = t.object({ difficulty: t.enum(j).default("normal") }).default({ difficulty: "normal" }), N = t.discriminatedUnion("k", [t.object({
	k: t.literal("play"),
	rid: k,
	card: D,
	pile: t.int().min(0).max(3),
	met: t.array(O)
}), t.object({
	k: t.literal("start"),
	met: t.array(O).min(1)
})]), P = t.object({
	phase: t.enum(["play", "done"]),
	turn: k,
	piles: t.array(t.array(D)).length(4),
	goals: t.array(O),
	goalLeft: t.int().nonnegative(),
	doneCount: t.int().nonnegative(),
	goalTotal: t.int().positive(),
	deckCount: t.int().nonnegative(),
	players: t.array(t.object({
		rid: k,
		handCount: t.int().nonnegative()
	})),
	result: t.enum(["win", "lose"]).nullable(),
	log: t.array(N)
}), F = t.object({ hand: t.array(D) }), I = 4, L = 4, R = {
	beginner: {
		small: 15,
		four: 12
	},
	normal: {
		small: 18,
		four: 15
	},
	expert: {
		small: 21,
		four: 18
	},
	insane: {
		small: 24,
		four: 21
	}
}, z = (e) => Math.floor(e / 14), B = (e) => Math.floor(e / 2) % 7 + 1, V = 60;
function H(e, t) {
	e.log.push(t), e.log.length > V && e.log.splice(0, e.log.length - V);
}
function U(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.rngCursor, n + 1);
		t.rngCursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
var W = (e) => e.piles.map((e) => ({
	c: z(e[e.length - 1]),
	n: B(e[e.length - 1])
}));
function ee(e) {
	let t = W(e), n = e.goals.filter((e) => T(x[e], t));
	return n.length === 0 ? n : (e.done.push(...n), e.goals = e.goals.flatMap((t) => n.includes(t) ? e.goalDeck.length > 0 ? [e.goalDeck.shift()] : [] : [t]), n);
}
function G(e) {
	let t = [];
	for (;;) {
		let n = ee(e);
		if (n.length === 0) return t;
		t.push(...n);
	}
}
function te(e, t) {
	let n = e.hands[t];
	return !n || n.length === 0 ? !1 : n.some((t) => e.piles.some((e) => K(t, e[e.length - 1])));
}
var K = (e, t) => z(e) === z(t) || B(e) === B(t);
function q(e) {
	return e.goals.length === 0 && e.goalDeck.length === 0 ? (e.phase = "done", e.result = "win", !0) : !te(e, e.players[e.turnIdx]) && (e.phase = "done", e.result = "lose", !0);
}
function ne(e, t, n) {
	let r = {
		seed: n,
		rngCursor: 0,
		players: t,
		turnIdx: 0,
		piles: [
			[],
			[],
			[],
			[]
		],
		deck: [],
		hands: {},
		goalDeck: [],
		goals: [],
		done: [],
		goalTotal: 0,
		phase: "play",
		result: null,
		log: []
	}, i = U(r, Array.from({ length: 56 }, (e, t) => t));
	for (let e of t) r.hands[e] = i.splice(0, I);
	for (let e = 0; e < 4; e += 1) r.piles[e] = [i.shift()];
	r.deck = i;
	let a = t.length >= 4 ? R[e.difficulty].four : R[e.difficulty].small;
	r.goalDeck = U(r, Array.from({ length: x.length }, (e, t) => t)).slice(0, a), r.goalTotal = a;
	for (let e = 0; e < L; e += 1) r.goals.push(r.goalDeck.shift());
	let o = G(r);
	return o.length > 0 && H(r, {
		k: "start",
		met: o
	}), q(r), {
		state: r,
		fx: r.players.map((e, t) => ({
			kind: "deal",
			rid: e,
			data: { count: I },
			for: [e],
			secret: { cards: r.hands[e] },
			...t > 0 ? { with: !0 } : {}
		}))
	};
}
function re(e, t, n) {
	if (e.phase === "done") return { code: "games.cahoots.errDone" };
	if (n.by !== e.players[e.turnIdx]) return { code: "games.cahoots.errNotYourTurn" };
	if (!e.hands[n.by]?.includes(t.card)) return { code: "games.cahoots.errBadCard" };
	let r = e.piles[t.pile];
	if (!r || !K(t.card, r[r.length - 1])) return { code: "games.cahoots.errBadPile" };
	let i = structuredClone(e);
	i.hands[n.by] = i.hands[n.by].filter((e) => e !== t.card), i.piles[t.pile].push(t.card);
	let a = null;
	i.deck.length > 0 && (a = i.deck.shift(), i.hands[n.by].push(a));
	let o = G(i);
	H(i, {
		k: "play",
		rid: n.by,
		card: t.card,
		pile: t.pile,
		met: o
	});
	let s = [{
		kind: "play",
		rid: n.by,
		data: {
			card: t.card,
			pile: t.pile
		}
	}];
	return a !== null && s.push({
		kind: "draw",
		rid: n.by,
		data: {},
		for: [n.by],
		secret: { card: a },
		with: !0
	}), o.length > 0 && s.push({
		kind: "goal",
		data: { goals: o },
		with: !0
	}), i.turnIdx = (i.turnIdx + 1) % i.players.length, q(i), {
		state: i,
		fx: s
	};
}
function ie(e, t) {
	return {
		public: {
			phase: e.phase,
			turn: e.players[e.turnIdx],
			piles: e.piles.map((e) => [...e]),
			goals: [...e.goals],
			goalLeft: e.goalDeck.length,
			doneCount: e.done.length,
			goalTotal: e.goalTotal,
			deckCount: e.deck.length,
			players: e.players.map((t) => ({
				rid: t,
				handCount: e.hands[t]?.length ?? 0
			})),
			result: e.result,
			log: e.log.map((e) => ({ ...e }))
		},
		private: { hand: [...e.hands[t] ?? []] }
	};
}
function ae(e) {
	return e.phase === "done" ? {
		phase: "done",
		winner: e.result === "win" ? [...e.players] : [],
		ranking: [...e.players],
		scores: Object.fromEntries(e.players.map((t) => [t, e.done.length]))
	} : { phase: e.phase };
}
var oe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: E,
	schemas: {
		action: A,
		publicView: P,
		privateView: F,
		config: M
	},
	setup: ne,
	reduce: re,
	viewFor: ie,
	status: ae
}, J = [
	"#e84995",
	"#9e5bd0",
	"#91c62d",
	"#f79336"
];
function Y({ color: e, x: t, y: n, scale: r = 1 }) {
	let i = `translate(${t} ${n}) scale(${r})`;
	switch (e) {
		case 0: return /* @__PURE__ */ f("path", {
			transform: i,
			d: "M0-6 1.7-1.7 6 0 1.7 1.7 0 6-1.7 1.7-6 0-1.7-1.7Z",
			fill: "currentColor"
		});
		case 2: return /* @__PURE__ */ p("g", {
			transform: i,
			fill: "currentColor",
			children: [
				/* @__PURE__ */ f("circle", {
					cx: "-2.7",
					cy: "0",
					r: "2.5"
				}),
				/* @__PURE__ */ f("circle", {
					cx: "2.7",
					cy: "0",
					r: "2.5"
				}),
				/* @__PURE__ */ f("circle", {
					cx: "0",
					cy: "-2.7",
					r: "2.5"
				}),
				/* @__PURE__ */ f("circle", {
					cx: "0",
					cy: "2.7",
					r: "2.5"
				})
			]
		});
		case 1: return /* @__PURE__ */ f("path", {
			transform: i,
			d: "M0-6 6 0 0 6-6 0Z",
			fill: "currentColor"
		});
		default: return /* @__PURE__ */ f("path", {
			transform: i,
			d: "M1-6-4 1H0L-1 6 5-1H1Z",
			fill: "currentColor"
		});
	}
}
function X({ color: e, size: t = 14 }) {
	return /* @__PURE__ */ f("svg", {
		"aria-hidden": "true",
		width: t,
		height: t,
		viewBox: "-7 -7 14 14",
		style: { color: J[e] },
		children: /* @__PURE__ */ f(Y, {
			color: e,
			x: 0,
			y: 0
		})
	});
}
function Z({ id: e, size: t = "hand" }) {
	let n = z(e), r = B(e);
	return /* @__PURE__ */ f("span", {
		className: `cahoots-number cahoots-number--${t}`,
		children: /* @__PURE__ */ p("svg", {
			"aria-hidden": "true",
			viewBox: "0 0 60 84",
			preserveAspectRatio: "none",
			children: [
				/* @__PURE__ */ f("rect", {
					x: "1",
					y: "1",
					width: "58",
					height: "82",
					rx: "5.5",
					fill: "#fff8e9",
					stroke: "#fffdf1",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ f("rect", {
					x: "4",
					y: "4",
					width: "52",
					height: "76",
					rx: "4",
					fill: J[n]
				}),
				/* @__PURE__ */ f("path", {
					d: "M4 66V80H26Z",
					fill: "#fff8e9"
				}),
				/* @__PURE__ */ f("text", {
					x: "9",
					y: "15",
					fill: "#fff",
					fontSize: "9",
					fontWeight: "800",
					fontFamily: "Arial, sans-serif",
					children: r
				}),
				/* @__PURE__ */ f("g", {
					color: "#fff",
					children: /* @__PURE__ */ f(Y, {
						color: n,
						x: 48,
						y: 12,
						scale: .72
					})
				}),
				/* @__PURE__ */ f("text", {
					x: "30",
					y: "57",
					textAnchor: "middle",
					fill: "#fff",
					fontSize: "43",
					fontWeight: "800",
					fontFamily: "Arial, sans-serif",
					children: r
				})
			]
		})
	});
}
//#endregion
//#region src/games/cahoots/view-player.tsx
var Q = {
	0: "games.cahoots.color.pink",
	1: "games.cahoots.color.purple",
	2: "games.cahoots.color.green",
	3: "games.cahoots.color.orange"
};
function se(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ f(ce, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function ce({ pub: e, priv: t, members: m, myRid: h, send: g }) {
	let _ = n((e) => e.locale), v = r(), y = (e) => {
		let t = m.find((t) => t.rid === e);
		return t ? i(t, _) : e;
	}, [b, x] = s(null), [S, C] = s(null), [w, T] = s(1), D = S === null ? w : Math.min(6, Math.max(1, e.piles[S].length));
	D !== w && T(D);
	let O = t?.hand ?? [], k = e.phase === "play" && e.turn === h, A = `${e.turn}|${O.join(".")}`, [j, M] = s(A);
	j !== A && (M(A), x(null));
	let [N, P] = s({
		goals: e.goals,
		left: e.goalLeft
	}), [F, I] = s([]), [L, R] = s([]);
	if ((!(e.goals.length === N.goals.length && e.goals.every((e, t) => e === N.goals[t])) || e.goalLeft !== N.left) && F.length === 0 && L.length === 0) {
		let t = N.goals.filter((t) => !e.goals.includes(t));
		t.length > 0 ? I(t) : P({
			goals: e.goals,
			left: e.goalLeft
		});
	}
	o(() => {
		if (F.length === 0) return;
		let e = setTimeout(() => {
			R(F), I([]);
		}, 400);
		return () => clearTimeout(e);
	}, [F]), o(() => {
		if (L.length === 0) return;
		let t = setTimeout(() => {
			P({
				goals: e.goals,
				left: e.goalLeft
			}), R([]);
		}, 200);
		return () => clearTimeout(t);
	}, [
		L,
		e.goals,
		e.goalLeft
	]);
	let V = (t) => {
		if (b === null) return !1;
		let n = e.piles[t][e.piles[t].length - 1];
		return z(b) === z(n) || B(b) === B(n);
	}, H = (e) => {
		if (k && b !== null && V(e)) {
			g({
				type: "play",
				card: b,
				pile: e
			}), x(null);
			return;
		}
		b === null && C(e);
	}, U, W;
	return k ? (U = "accent", W = v("games.cahoots.turnYou")) : (U = "info", W = v("games.cahoots.turnWait", { name: y(e.turn) })), /* @__PURE__ */ p("div", {
		className: "cahoots-screen h-full min-h-0",
		style: { "--cahoots-history-columns": w },
		children: [/* @__PURE__ */ f(u, {
			adaptive: !0,
			className: "cahoots-adaptive",
			scroll: !1,
			actionsHeight: "cahoots-actions-height",
			banner: /* @__PURE__ */ p("div", {
				className: "cahoots-top",
				children: [/* @__PURE__ */ f(l, {
					tone: U,
					text: W,
					accent: E.accent
				}), /* @__PURE__ */ f("ul", {
					className: "cahoots-players",
					style: { "--cahoots-player-count": m.length },
					children: m.map((t) => {
						let n = i(t, _), r = e.players.find((e) => e.rid === t.rid)?.handCount;
						return /* @__PURE__ */ p("li", {
							className: `cahoots-player ${t.online ? "" : "cahoots-player--offline"}`,
							"aria-current": t.rid === e.turn ? "true" : void 0,
							children: [
								/* @__PURE__ */ f("span", {
									className: "cahoots-player-token",
									style: { backgroundColor: d[t.colorIndex % d.length].hex },
									"aria-hidden": "true",
									children: /* @__PURE__ */ f("img", {
										src: a[(t?.avatar ?? 0) % a.length],
										alt: "",
										draggable: !1,
										style: {
											width: "1.75em",
											height: "1.75em",
											maxWidth: "100%",
											maxHeight: "100%",
											display: "block",
											objectFit: "contain",
											pointerEvents: "none",
											borderRadius: "inherit"
										}
									})
								}),
								/* @__PURE__ */ f("span", {
									className: "cahoots-player-name",
									title: n,
									children: t.rid === h ? v("lobby.you") : n
								}),
								/* @__PURE__ */ f("span", {
									className: "cahoots-player-count",
									children: r === void 0 ? "" : v("games.cahoots.stripHand", { n: r })
								})
							]
						}, t.rid);
					})
				})]
			}),
			actions: /* @__PURE__ */ f("div", {
				className: "cahoots-hand-zone",
				children: t && /* @__PURE__ */ f("div", {
					className: "cahoots-hand",
					children: O.map((e) => /* @__PURE__ */ f("button", {
						type: "button",
						disabled: !k,
						onClick: () => x(b === e ? null : e),
						className: `cahoots-hand-card ${b === e ? "cahoots-hand-card--selected" : ""}`,
						"aria-label": `${v(Q[z(e)])} ${B(e)}`,
						"aria-pressed": b === e,
						children: /* @__PURE__ */ f(Z, { id: e })
					}, e))
				})
			}),
			children: /* @__PURE__ */ f("div", {
				className: "cahoots-board",
				style: { backgroundImage: "url(./games/cahoots/scene.webp)" },
				children: /* @__PURE__ */ p("div", {
					className: "cahoots-board__inner",
					children: [/* @__PURE__ */ p("div", {
						className: "cahoots-goal-area",
						children: [/* @__PURE__ */ p("div", {
							className: "cahoots-goal-counts",
							children: [
								/* @__PURE__ */ f("span", { children: v("games.cahoots.goalLeft", { n: N.left }) }),
								/* @__PURE__ */ f("span", {
									className: "cahoots-count-separator",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ f("strong", { children: v("games.cahoots.progress", {
									done: e.doneCount,
									total: e.goalTotal
								}) })
							]
						}), /* @__PURE__ */ f("div", {
							className: "cahoots-goals",
							children: Array.from({ length: 4 }, (e, t) => {
								let n = N.goals[t];
								return n === void 0 ? /* @__PURE__ */ f("div", {
									className: "cahoots-goal cahoots-goal--empty",
									"aria-hidden": "true",
									children: /* @__PURE__ */ f("svg", {
										viewBox: "0 0 24 24",
										children: /* @__PURE__ */ f("path", {
											d: "m4 12 5 5L20 6",
											fill: "none",
											stroke: "currentColor",
											strokeWidth: "3",
											strokeLinecap: "round",
											strokeLinejoin: "round"
										})
									})
								}, `empty-${t}`) : /* @__PURE__ */ f(fe, {
									id: n,
									stage: F.includes(n) ? "celebrate" : L.includes(n) ? "exit" : void 0
								}, n);
							})
						})]
					}), /* @__PURE__ */ f("div", {
						className: "cahoots-play-area",
						children: /* @__PURE__ */ p("div", {
							className: "cahoots-piles",
							children: [/* @__PURE__ */ p("div", {
								className: "cahoots-draw",
								"aria-label": v("games.cahoots.deckLeft", { n: e.deckCount }),
								children: [/* @__PURE__ */ f("span", {
									className: `cahoots-draw-stack ${e.deckCount === 0 ? "cahoots-draw-stack--empty" : ""}`,
									"aria-hidden": "true",
									children: /* @__PURE__ */ f("svg", {
										width: "27",
										height: "27",
										viewBox: "0 0 27 27",
										children: /* @__PURE__ */ f("path", {
											d: "m13.5 1 3.2 9.3L26 13.5l-9.3 3.2L13.5 26l-3.2-9.3L1 13.5l9.3-3.2Z",
											fill: "currentColor"
										})
									})
								}), /* @__PURE__ */ f("span", {
									className: "cahoots-draw-count",
									children: e.deckCount
								})]
							}), e.piles.map((e, t) => {
								let n = e[e.length - 1], r = k && b !== null && V(t);
								return /* @__PURE__ */ p("button", {
									type: "button",
									onClick: () => H(t),
									className: `cahoots-pile ${r ? "cahoots-pile--legal" : ""} ${k && b !== null && !r ? "cahoots-pile--dim" : ""}`,
									"aria-label": v("games.cahoots.pileAria", { n: t + 1 }),
									children: [/* @__PURE__ */ p("span", {
										className: "cahoots-pile-card-wrap",
										children: [/* @__PURE__ */ f(Z, {
											id: n,
											size: "pile"
										}), r && /* @__PURE__ */ f("span", {
											className: "cahoots-pile-check",
											"aria-hidden": "true",
											children: /* @__PURE__ */ f("svg", {
												width: "12",
												height: "12",
												viewBox: "0 0 12 12",
												children: /* @__PURE__ */ f("path", {
													d: "m2 6 2.5 2.5L10 3",
													fill: "none",
													stroke: "currentColor",
													strokeWidth: "2",
													strokeLinecap: "round",
													strokeLinejoin: "round"
												})
											})
										})]
									}), /* @__PURE__ */ p("span", {
										className: "cahoots-pile-count",
										children: [
											t + 1,
											" · ×",
											e.length
										]
									})]
								}, t);
							})]
						})
					})]
				})
			})
		}), /* @__PURE__ */ f(c, {
			open: S !== null,
			onClose: () => C(null),
			label: v("games.cahoots.pileHistory"),
			children: S !== null && /* @__PURE__ */ p("div", {
				className: "cahoots-history",
				children: [/* @__PURE__ */ f("p", {
					className: "section-label",
					children: v("games.cahoots.pileAria", { n: S + 1 })
				}), /* @__PURE__ */ f("div", {
					className: "cahoots-history-cards",
					children: [...e.piles[S]].reverse().map((e, t) => /* @__PURE__ */ f(Z, {
						id: e,
						size: "history"
					}, `${e}-${t}`))
				})]
			})
		})]
	});
}
var le = {
	celebrate: "goal-leave",
	exit: "goal-exit-up"
}, ue = [
	"#b32769",
	"#7941a7",
	"#527b13",
	"#b85b17"
];
function de(e, t) {
	let n = t.map((e) => e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
	return e.split(RegExp(`(${n.join("|")})`, "gi")).map((e, n) => {
		let r = t.findIndex((t) => t.toLocaleLowerCase() === e.toLocaleLowerCase());
		return r < 0 ? e : /* @__PURE__ */ f("span", {
			style: { color: ue[r] },
			children: e
		}, n);
	});
}
function fe({ id: e, stage: t }) {
	let n = r(), i = x[e], a = n(S[i.k], {
		a: i.a === void 0 ? "" : n(Q[i.a]),
		b: i.b === void 0 ? "" : n(Q[i.b]),
		n: i.n ?? 0
	}), o = [
		0,
		1,
		2,
		3
	].map((e) => n(Q[e])), s = i.a === void 0 ? "#0d9488" : J[i.a];
	return /* @__PURE__ */ p("div", {
		className: `cahoots-goal ${t ? le[t] : "goal-enter"}`,
		style: { "--cahoots-goal-accent": s },
		children: [
			/* @__PURE__ */ p("span", {
				className: "cahoots-goal-symbols",
				"aria-hidden": "true",
				children: [i.a === void 0 ? /* @__PURE__ */ f("svg", {
					width: "14",
					height: "14",
					viewBox: "0 0 14 14",
					children: /* @__PURE__ */ f("path", {
						d: "M7 1 8.5 5.5 13 7 8.5 8.5 7 13 5.5 8.5 1 7 5.5 5.5Z",
						fill: "#0d9488"
					})
				}) : /* @__PURE__ */ f(X, { color: i.a }), i.b !== void 0 && /* @__PURE__ */ f(X, { color: i.b })]
			}),
			/* @__PURE__ */ f("span", {
				className: "cahoots-goal-content",
				children: /* @__PURE__ */ f("span", {
					className: "cahoots-goal-text",
					children: de(a, o)
				})
			}),
			/* @__PURE__ */ f("span", {
				className: "cahoots-goal-pin",
				"aria-hidden": "true"
			})
		]
	});
}
//#endregion
//#region src/games/cahoots/bot.ts
function pe(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var me = (e, t) => {
	let n = [];
	for (let r of e) for (let e = 0; e < 4; e += 1) {
		let i = t[e];
		(z(r) === z(i) || B(r) === B(i)) && n.push({
			card: r,
			pile: e
		});
	}
	return n;
}, he = (e, t) => {
	for (let n = 0; n < 4; n += 1) for (let r = 0; r < 4; r += 1) for (let i = 1; i <= 7; i += 1) {
		if (r === t[n].c && i === t[n].n) continue;
		let a = t.slice();
		if (a[n] = {
			c: r,
			n: i
		}, T(e, a)) return !0;
	}
	return !1;
}, ge = (e, t) => T(e, t) ? 0 : he(e, t) ? 1 : 2, _e = (e, t) => {
	let n = e.public, r = e.private;
	if (n.phase === "done" || n.turn !== t.rid || !r) return null;
	let i = n.piles.map((e) => e[e.length - 1]), a = me(r.hand, i);
	if (a.length === 0) return null;
	if (t.difficulty === "weak") {
		let e = pe(a);
		return { action: {
			type: "play",
			card: e.card,
			pile: e.pile
		} };
	}
	let o = i.map((e) => ({
		c: z(e),
		n: B(e)
	})), s = n.goals.map((e) => ge(x[e], o)), c = a.map((e) => {
		let t = o.map((t, n) => n === e.pile ? {
			c: z(e.card),
			n: B(e.card)
		} : t), i = 0, a = 0, c = 0;
		n.goals.forEach((e, n) => {
			let r = ge(x[e], t);
			r === 0 ? i += 1 : (a += s[n] - r, r === 1 && (c += 1));
		});
		let l = r.hand.some((t) => t !== e.card && z(t) === z(e.card)), u = r.hand.some((t) => t !== e.card && B(t) === B(e.card)), d = new Set(t.map((e) => e.c)), f = new Set(t.map((e) => e.n));
		return {
			m: e,
			score: i * 1e3 + a * 30 + c * 25 + (l ? 3 : 0) + (u ? 3 : 0) + d.size * 2 + f.size * 2
		};
	}), l = Math.max(...c.map((e) => e.score)), u = pe(c.filter((e) => e.score === l).map((e) => e.m));
	return { action: {
		type: "play",
		card: u.card,
		pile: u.pile
	} };
}, $ = {
	0: "games.cahoots.color.pink",
	1: "games.cahoots.color.purple",
	2: "games.cahoots.color.green",
	3: "games.cahoots.color.orange"
};
function ve({ result: e, public: t, members: a, onPlayAgain: o, onBackToLobby: s }) {
	let c = r(), l = n((e) => e.locale), u = t, d = u.result === "win", h = (e) => {
		let t = a.find((t) => t.rid === e);
		return t ? i(t, l) : e;
	}, g = u.goals.length + u.goalLeft;
	return /* @__PURE__ */ p("div", {
		className: "cahoots-over",
		style: { backgroundImage: "url(./games/cahoots/scene.webp)" },
		children: [d && /* @__PURE__ */ f(m, {}), /* @__PURE__ */ p("div", {
			className: "cahoots-over__inner",
			children: [
				/* @__PURE__ */ p("header", {
					className: "cahoots-over__heading",
					children: [/* @__PURE__ */ f("span", {
						"aria-hidden": !0,
						className: `cahoots-over__seal ${d ? "" : "cahoots-over__seal--lose"}`,
						children: d ? "✓" : "×"
					}), /* @__PURE__ */ f("h1", { children: c(d ? "games.cahoots.overWin" : "games.cahoots.overLose") })]
				}),
				/* @__PURE__ */ p("div", {
					className: "cahoots-over__content",
					children: [/* @__PURE__ */ p("section", {
						className: "cahoots-over__team cahoots-over__paper",
						children: [
							/* @__PURE__ */ p("div", {
								className: "cahoots-over__progress",
								children: [
									/* @__PURE__ */ p("strong", {
										className: "font-mono tabular-nums",
										"aria-label": c("games.cahoots.overProgress", {
											done: u.doneCount,
											total: u.goalTotal
										}),
										children: [u.doneCount, /* @__PURE__ */ p("span", { children: [" / ", u.goalTotal] })]
									}),
									/* @__PURE__ */ f("p", { children: c("games.cahoots.overProgressLabel") }),
									!d && /* @__PURE__ */ f("p", { children: c("games.cahoots.overUnfinished", { n: g }) })
								]
							}),
							/* @__PURE__ */ f("h2", { children: c("games.cahoots.overTeam") }),
							/* @__PURE__ */ f("ul", {
								className: "cahoots-over__players",
								children: e.ranking.map((e) => /* @__PURE__ */ p("li", {
									className: "cahoots-over__player",
									children: [/* @__PURE__ */ f("span", {
										"aria-hidden": !0,
										children: d ? "✓" : "×"
									}), /* @__PURE__ */ f("span", {
										className: "cahoots-over__name",
										title: h(e),
										children: h(e)
									})]
								}, e))
							})
						]
					}), /* @__PURE__ */ p("div", {
						className: "cahoots-over__review",
						children: [/* @__PURE__ */ p("section", {
							className: "cahoots-over__table cahoots-over__paper",
							children: [/* @__PURE__ */ p("div", {
								className: "cahoots-over__table-heading",
								children: [/* @__PURE__ */ f("h2", { children: c("games.cahoots.overTable") }), /* @__PURE__ */ f("p", {
									className: "font-mono tabular-nums",
									children: c("games.cahoots.deckLeft", { n: u.deckCount })
								})]
							}), /* @__PURE__ */ f("ol", {
								className: "cahoots-over__piles",
								children: u.piles.map((e, t) => {
									let n = e[e.length - 1];
									return /* @__PURE__ */ p("li", {
										className: "cahoots-over__pile",
										"aria-label": `${c("games.cahoots.pileAria", { n: t + 1 })}: ${c($[z(n)])} ${B(n)}, ${c("games.cahoots.stripHand", { n: e.length })}`,
										children: [/* @__PURE__ */ f(Z, {
											id: n,
											size: "pile"
										}), /* @__PURE__ */ p("span", {
											className: "cahoots-over__pile-count font-mono tabular-nums",
											children: [
												t + 1,
												" · ×",
												e.length
											]
										})]
									}, t);
								})
							})]
						}), u.goals.length > 0 && /* @__PURE__ */ p("section", {
							className: "cahoots-over__goals cahoots-over__paper",
							children: [/* @__PURE__ */ f("h2", { children: c("games.cahoots.overVisibleGoals") }), /* @__PURE__ */ f("ul", {
								className: "cahoots-over__goal-list",
								children: u.goals.map((e) => {
									let t = x[e], n = c(S[t.k], {
										a: t.a === void 0 ? "" : c($[t.a]),
										b: t.b === void 0 ? "" : c($[t.b]),
										n: t.n ?? 0
									});
									return /* @__PURE__ */ p("li", {
										className: "cahoots-over__goal",
										style: { "--cahoots-goal-accent": t.a === void 0 ? E.accent : J[t.a] },
										children: [t.a !== void 0 && /* @__PURE__ */ p("span", {
											className: "cahoots-over__goal-symbols",
											"aria-hidden": "true",
											children: [/* @__PURE__ */ f(X, { color: t.a }), t.b !== void 0 && /* @__PURE__ */ f(X, { color: t.b })]
										}), /* @__PURE__ */ f("span", { children: n })]
									}, e);
								})
							})]
						})]
					})]
				}),
				/* @__PURE__ */ p("footer", {
					className: "cahoots-over__actions safe-b",
					children: [
						o && /* @__PURE__ */ f("button", {
							type: "button",
							className: "btn-base text-white",
							style: { background: E.accent },
							onClick: o,
							children: c("session.result.playAgain")
						}),
						s && /* @__PURE__ */ f("button", {
							type: "button",
							className: "btn-quiet",
							onClick: s,
							children: c("session.result.backToLobby")
						}),
						!o && !s && /* @__PURE__ */ f("p", { children: c("session.result.waitHost") })
					]
				})
			]
		})]
	});
}
//#endregion
//#region src/games/cahoots/options.tsx
var ye = {
	beginner: "games.cahoots.diff.beginner",
	normal: "games.cahoots.diff.normal",
	expert: "games.cahoots.diff.expert",
	insane: "games.cahoots.diff.insane"
};
function be({ value: e, onChange: t }) {
	let n = r(), i = M.safeParse(e), a = i.success ? i.data : M.parse(void 0);
	return /* @__PURE__ */ p("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ f(g, {
			title: n("games.cahoots.optDifficulty"),
			children: j.map((e) => /* @__PURE__ */ f(h, {
				name: "cahoots-difficulty",
				value: e,
				checked: a.difficulty === e,
				label: n(ye[e]),
				accent: E.accent,
				onChange: () => t({ difficulty: e })
			}, e))
		}), /* @__PURE__ */ f("p", {
			className: "text-xs text-ink/70",
			children: n("games.cahoots.optDifficultyHint")
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/cahoots/entry.tsx
var xe = {
	definition: oe,
	View: se,
	bot: _e,
	OverView: ve,
	Options: be,
	locales: {
		zh: {
			name: "同谋 Cahoots",
			desc: "合作出牌:轮流往四个牌堆放牌,凑出目标牌要求的牌面,全程不许透露手牌",
			rules: "目标:全队合作完成所有目标牌,即共同获胜。\n组件:\n· 数字牌 56 张:4 种颜色 × 数字 1~7,各两张。\n· 目标牌 50 张,按难度取出一部分组成本局目标牌堆。\n流程:\n· 每人 4 张手牌,彼此保密;桌面有 4 个明置牌堆与 4 张公开目标牌。\n· 轮到你:将一张手牌放到任一牌堆顶,须与堆顶牌同色或同号,然后将手牌补回 4 张。\n· 打出的牌使某张公开目标成立时(只检查四个堆顶),该目标立即完成,并补翻一张新目标。\n失败:\n· 抽牌堆抽空且全员手牌打完,或轮到的玩家没有任何合法出牌。\n沟通限制:\n· 不得透露自己手牌的颜色或数字;只能表达想往哪堆放、建议完成哪张目标。\n· 目标判定严格按字面执行:例如「三堆粉色」必须恰好三堆。",
			progress: "完成 {{done}}/{{total}}",
			stripHand: "{{n}} 张",
			selfToken: "我",
			turnYou: "轮到你",
			turnWait: "等 {{name}} 出牌…",
			deckLeft: "抽牌 {{n}}",
			goalLeft: "目标剩 {{n}}",
			pileAria: "第 {{n}} 堆",
			pileHistory: "牌堆记录(新牌在上)",
			optDifficulty: "目标难度",
			optDifficultyHint: "目标牌数:2–3 人 入门15/普通18/专家21/疯狂24;4 人 12/15/18/21",
			overWin: "同心协力,目标全清!",
			overLose: "目标未完成",
			overProgress: "完成目标 {{done}}/{{total}}",
			overProgressLabel: "完成目标",
			overTeam: "协作团队",
			overTable: "终局牌面",
			overVisibleGoals: "尚未完成的公开目标",
			overUnfinished: "未完成目标 {{n}}",
			errDone: "本局已结束",
			errNotYourTurn: "还没轮到你",
			errBadCard: "手里没有这张牌",
			errBadPile: "只能打到与堆顶同色或同号的牌堆",
			color: {
				pink: "粉色",
				purple: "紫色",
				green: "绿色",
				orange: "橙色"
			},
			diff: {
				beginner: "入门",
				normal: "普通",
				expert: "专家",
				insane: "疯狂"
			},
			goal: {
				gt4: "所有牌都大于 4",
				lt4: "所有牌都小于 4",
				half: "{{a}}之和是{{b}}的一半",
				adj2: "相邻两堆都是{{a}}",
				nonAdj2: "两个不相邻的堆是{{a}}",
				alt2: "相间的两堆是{{a}}",
				sumEq: "{{a}}之和等于{{b}}之和",
				only2: "所有牌都是{{a}}或{{b}}",
				noSameNum: "没有重复的数字",
				noSameColor: "没有重复的颜色",
				noSameBoth: "颜色和数字都不重复",
				straight4: "四个数字连成顺子(任意顺序)",
				straight3: "相邻三堆数字连续(递增或递减)",
				allEven: "全是偶数",
				allOdd: "全是奇数",
				altParity: "奇偶相间",
				threeOf: "恰好三堆是{{a}}",
				sumColor: "{{a}}之和等于 {{n}}",
				sumAll: "所有牌之和等于 {{n}}"
			}
		},
		en: {
			name: "Cahoots",
			desc: "Co-op card play: match color or number onto four piles and meet every goal — without revealing your hand",
			rules: "Goal: complete all goal cards together to win as a team.\nContents:\n· 56 number cards: 4 colors × numbers 1–7, two of each.\n· 50 goal cards; a subset forms this game's goal deck depending on difficulty.\nHow to play:\n· Everyone holds 4 secret cards; the table has 4 face-up piles and 4 visible goal cards.\n· On your turn: play one card from your hand onto a pile — it must match the top card in color or number — then draw back up to 4.\n· If your card makes any visible goal true (judged on the four pile tops), that goal is completed at once and a new one is revealed.\nYou lose:\n· If the draw pile runs out with all hands empty, or a player cannot legally play.\nTable talk:\n· Never reveal the colors or numbers in your hand; you may only say which pile you want to play on or suggest which goal to finish.\n· Goals are judged exactly as written: “three pink piles” means exactly three.",
			progress: "Done {{done}}/{{total}}",
			stripHand: "{{n}} cards",
			selfToken: "Me",
			turnYou: "Your turn",
			turnWait: "Waiting for {{name}}…",
			deckLeft: "Draw {{n}}",
			goalLeft: "{{n}} goals left",
			pileAria: "Pile {{n}}",
			pileHistory: "Pile history (newest first)",
			optDifficulty: "Goal difficulty",
			optDifficultyHint: "Goal deck size: 2–3 players 15/18/21/24; 4 players 12/15/18/21",
			overWin: "All goals complete — in cahoots!",
			overLose: "Goals unfinished",
			overProgress: "Goals done {{done}}/{{total}}",
			overProgressLabel: "Goals complete",
			overTeam: "Team",
			overTable: "Final piles",
			overVisibleGoals: "Unfinished visible goals",
			overUnfinished: "{{n}} goals unfinished",
			errDone: "This round is over",
			errNotYourTurn: "Not your turn yet",
			errBadCard: "That card is not in your hand",
			errBadPile: "Play only on a pile matching color or number",
			color: {
				pink: "pink",
				purple: "purple",
				green: "green",
				orange: "orange"
			},
			diff: {
				beginner: "Beginner",
				normal: "Normal",
				expert: "Expert",
				insane: "Insane"
			},
			goal: {
				gt4: "All cards higher than 4",
				lt4: "All cards lower than 4",
				half: "{{a}} sum is half of {{b}}",
				adj2: "Two adjacent piles are {{a}}",
				nonAdj2: "Two non-adjacent piles are {{a}}",
				alt2: "Alternating piles are {{a}}",
				sumEq: "Sum of {{a}} equals sum of {{b}}",
				only2: "All cards are {{a}} or {{b}}",
				noSameNum: "No repeated numbers",
				noSameColor: "No repeated colors",
				noSameBoth: "No repeated color or number",
				straight4: "A straight of four (any order)",
				straight3: "A straight of three in a row",
				allEven: "All even",
				allOdd: "All odd",
				altParity: "Alternating even and odd",
				threeOf: "Three {{a}} piles",
				sumColor: "Sum of {{a}} cards is {{n}}",
				sumAll: "Sum of all cards is {{n}}"
			}
		}
	}
};
//#endregion
export { xe as default };
