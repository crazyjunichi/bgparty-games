import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useId as r, useRef as i, useState as a } from "react";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { IconBot as u, IconExpand as d, IconInfo as f, IconLog as p, IconRecenter as m, IconZoomIn as h, IconZoomOut as ee } from "@bgparty/sdk/icons";
import { useWakeLock as te } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as ne } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as g } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as re, seatName as ie } from "@bgparty/sdk/ui/player-strip";
import { Fragment as _, jsx as v, jsxs as y } from "react/jsx-runtime";
import { usePrefersReducedMotion as ae } from "@bgparty/sdk/fx/use-reduced-motion";
import { PLAYER_COLORS as b } from "@bgparty/sdk/player-colors";
import { Floater as x, FlySprite as S, PulseBox as C } from "@bgparty/sdk/fx/primitives";
import { OptionSwitch as oe } from "@bgparty/sdk/ui/game-options";
//#region src/games/jamaica/data.ts
var w = [
	["forward", "forward"],
	["food", "forward"],
	["powder", "food"],
	["forward", "food"],
	["backward", "forward"],
	["powder", "forward"],
	["gold", "gold"],
	["forward", "backward"],
	["gold", "powder"],
	["forward", "gold"],
	["food", "powder"]
], T = {
	gold: "games.jamaica.gold",
	food: "games.jamaica.food",
	powder: "games.jamaica.powder",
	forward: "games.jamaica.forward",
	backward: "games.jamaica.backward"
}, se = [
	"strategist",
	"buccaneer",
	"beth",
	"saran",
	"cooper",
	"venetian",
	"prussian",
	"helvetian",
	"seafarer",
	"anchoree",
	"seadog",
	"cartographer",
	"king",
	"nosey",
	"bishop",
	"shipowner",
	"calypso",
	"oracle",
	"lookout",
	"witch"
], E = {
	strategist: [0, -3],
	buccaneer: [0, -3],
	beth: [6, 4],
	saran: [5, 3],
	cooper: [6, 4],
	venetian: [5, 2],
	prussian: [5, 3],
	helvetian: [5, 2],
	seafarer: [5, 2],
	anchoree: [5, 2],
	seadog: [5, 2],
	cartographer: [3, 1],
	king: [9, -3],
	nosey: [3, 1],
	bishop: [3, 1],
	shipowner: [0, 2],
	calypso: [6, 0],
	oracle: [5, 2],
	lookout: [5, 3],
	witch: [0, -3]
}, D = {
	strategist: "games.jamaica.crew.strategist",
	buccaneer: "games.jamaica.crew.buccaneer",
	beth: "games.jamaica.crew.beth",
	saran: "games.jamaica.crew.saran",
	cooper: "games.jamaica.crew.cooper",
	venetian: "games.jamaica.crew.venetian",
	prussian: "games.jamaica.crew.prussian",
	helvetian: "games.jamaica.crew.helvetian",
	seafarer: "games.jamaica.crew.seafarer",
	anchoree: "games.jamaica.crew.anchoree",
	seadog: "games.jamaica.crew.seadog",
	cartographer: "games.jamaica.crew.cartographer",
	king: "games.jamaica.crew.king",
	nosey: "games.jamaica.crew.nosey",
	bishop: "games.jamaica.crew.bishop",
	shipowner: "games.jamaica.crew.shipowner",
	calypso: "games.jamaica.crew.calypso",
	oracle: "games.jamaica.crew.oracle",
	lookout: "games.jamaica.crew.lookout",
	witch: "games.jamaica.crew.witch"
}, ce = {
	strategist: "games.jamaica.power.strategist",
	buccaneer: "games.jamaica.power.buccaneer",
	beth: "games.jamaica.power.beth",
	saran: "games.jamaica.power.saran",
	cooper: "games.jamaica.power.cooper",
	venetian: "games.jamaica.power.venetian",
	prussian: "games.jamaica.power.prussian",
	helvetian: "games.jamaica.power.helvetian",
	seafarer: "games.jamaica.power.seafarer",
	anchoree: "games.jamaica.power.anchoree",
	seadog: "games.jamaica.power.seadog",
	cartographer: "games.jamaica.power.cartographer",
	king: "games.jamaica.power.king",
	nosey: "games.jamaica.power.nosey",
	bishop: "games.jamaica.power.bishop",
	shipowner: "games.jamaica.power.shipowner",
	calypso: "games.jamaica.power.calypso",
	oracle: "games.jamaica.power.oracle",
	lookout: "games.jamaica.power.lookout",
	witch: "games.jamaica.power.witch"
}, O = [
	[
		91,
		21,
		"royal",
		0
	],
	[
		90,
		31,
		"food",
		2
	],
	[
		92,
		39,
		"food",
		3
	],
	[
		91,
		46,
		"food",
		2
	],
	[
		89,
		54,
		"lair",
		0
	],
	[
		88,
		59,
		"gold",
		3
	],
	[
		85,
		64,
		"gold",
		5
	],
	[
		80,
		71,
		"food",
		3
	],
	[
		73,
		77,
		"food",
		4
	],
	[
		65,
		85,
		"food",
		3
	],
	[
		59,
		75,
		"gold",
		5
	],
	[
		53,
		80,
		"food",
		2
	],
	[
		46,
		75,
		"gold",
		3
	],
	[
		40,
		84,
		"lair",
		0
	],
	[
		32,
		75,
		"food",
		4
	],
	[
		20,
		74,
		"food",
		4
	],
	[
		20,
		61,
		"gold",
		5
	],
	[
		8,
		56,
		"food",
		1
	],
	[
		15,
		45,
		"gold",
		5
	],
	[
		16,
		35,
		"gold",
		3
	],
	[
		10,
		28,
		"food",
		3
	],
	[
		22,
		23,
		"food",
		4
	],
	[
		32,
		22,
		"food",
		4
	],
	[
		38,
		24,
		"gold",
		5
	],
	[
		44,
		14,
		"food",
		2
	],
	[
		49,
		15,
		"food",
		3
	],
	[
		54,
		12,
		"lair",
		0
	],
	[
		62,
		11,
		"gold",
		4
	],
	[
		68,
		7,
		"food",
		2
	],
	[
		76,
		7,
		"food",
		3
	],
	[
		85,
		7,
		"food",
		3
	],
	[
		93,
		11,
		"food",
		3
	],
	[
		91,
		21,
		"royal",
		0
	],
	[
		94,
		76,
		"food",
		2
	],
	[
		91,
		83,
		"food",
		3
	],
	[
		87,
		89,
		"lair",
		0
	],
	[
		83,
		94,
		"food",
		3
	],
	[
		77,
		95,
		"lair",
		0
	],
	[
		67,
		94,
		"food",
		3
	],
	[
		32,
		94,
		"food",
		3
	],
	[
		26,
		87,
		"gold",
		3
	],
	[
		18,
		95,
		"lair",
		0
	],
	[
		10,
		94,
		"food",
		2
	],
	[
		5,
		87,
		"food",
		3
	],
	[
		8,
		75,
		"lair",
		0
	],
	[
		4,
		15,
		"lair",
		0
	],
	[
		11,
		12,
		"gold",
		3
	],
	[
		14,
		6,
		"food",
		2
	],
	[
		20,
		7,
		"food",
		1
	],
	[
		26,
		14,
		"lair",
		0
	],
	[
		34,
		8,
		"food",
		1
	]
];
function le(e, t, n) {
	return {
		x: (O[e][0] > 80 ? -57 : O[e][0] < 13 ? 10 : -34) + t % 2 * 48,
		row: Math.floor(t / 2),
		rows: Math.ceil(n / 2)
	};
}
var k = O.map(([e, t, n, r], i) => ({
	x: e,
	y: t,
	kind: n,
	cost: r,
	next: i < 32 ? [i + 1] : [],
	previous: [],
	score: i === 32 ? 15 : i >= 23 && i <= 31 ? i - 21 : -5
}));
for (let e of [
	[
		6,
		33,
		34,
		35,
		36,
		37,
		38,
		10
	],
	[
		12,
		39,
		40,
		41,
		42,
		43,
		44,
		16
	],
	[
		20,
		45,
		46,
		47,
		48,
		49,
		50,
		23
	]
]) for (let t = 0; t < e.length - 1; t++) k[e[t]].next.push(e[t + 1]);
for (let e = 0; e < k.length; e++) for (let t of k[e].next) k[t].previous.push(e);
function A(e) {
	return e === 32 ? 0 : 1 + Math.min(...k[e].next.map(A));
}
var j = "$ghost", M = [
	2,
	4,
	6,
	8,
	10,
	-1
], N = {
	p2a: 2,
	p2b: 2,
	p3a: 3,
	p3b: 3,
	p3c: 3,
	p4a: 4,
	p4b: 4,
	p5: 5,
	p6: 6,
	p7: 7,
	curse2: -2,
	curse3: -3,
	curse4: -4,
	diamond: 12
}, ue = [
	"p3a",
	"p4a",
	"p5",
	"p6",
	"p7",
	"curse2",
	"curse3",
	"curse4",
	"map",
	"sabre",
	"beth",
	"hold"
], de = [
	"p2a",
	"p2b",
	"p3a",
	"p3b",
	"p3c",
	"p4a",
	"p4b",
	"p7",
	"curse2",
	"curse3",
	"curse4",
	"diamond"
], fe = [
	"rum",
	"sextant",
	"anchor"
], P = {
	map: "games.jamaica.treasure.map",
	sabre: "games.jamaica.treasure.sabre",
	beth: "games.jamaica.treasure.beth",
	hold: "games.jamaica.treasure.hold",
	rum: "games.jamaica.treasure.rum",
	sextant: "games.jamaica.treasure.sextant",
	anchor: "games.jamaica.treasure.anchor",
	diamond: "games.jamaica.treasure.diamond"
}, pe = (e) => e in P, me = {
	id: "jamaica",
	tier: "alpha",
	mechanics: [
		"race",
		"action-programming",
		"dice-rolling",
		"hand-management"
	],
	interactionTags: [],
	nameKey: "games.jamaica.name",
	descKey: "games.jamaica.desc",
	rulesKey: "games.jamaica.rules",
	icon: "🏴‍☠️",
	iconImg: "games/jamaica.webp",
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [
		4,
		5,
		6
	],
	accent: "#b56b16",
	releasedAt: "2026-10-29T21:40:00+08:00",
	search: {
		py: "ya mai jia",
		init: "ymj"
	},
	hotseat: "cover"
}, F = t.object({
	crew: t.boolean().default(!1),
	extra: t.boolean().default(!1)
}).prefault({}), he = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("select"),
		card: t.int().min(0).max(10),
		swap: t.boolean().default(!1)
	}),
	t.object({
		type: t.literal("choose"),
		id: t.string().max(100)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), ge = t.object({
	kind: t.enum([
		"gold",
		"food",
		"powder",
		"crew"
	]),
	n: t.int().positive(),
	crew: t.string().optional()
}).nullable(), _e = t.object({
	id: t.string(),
	kind: t.string(),
	n: t.number().optional(),
	node: t.number().optional(),
	hold: t.number().optional(),
	rid: t.string().optional(),
	crew: t.string().optional(),
	treasure: t.string().optional(),
	resource: t.string().optional(),
	cost: t.number().optional()
}), ve = t.object({
	rid: t.string(),
	node: t.int(),
	finished: t.boolean(),
	holds: t.array(ge),
	treasures: t.array(t.string().nullable()),
	tokens: t.int(),
	picked: t.boolean(),
	card: t.int().nullable(),
	swap: t.boolean(),
	score: t.object({
		position: t.number(),
		gold: t.number(),
		treasure: t.number(),
		crew: t.number(),
		total: t.number()
	}).nullable()
}), ye = t.object({
	phase: t.enum([
		"oracle",
		"arrange",
		"select",
		"resolve",
		"done"
	]),
	round: t.int(),
	captain: t.string(),
	dice: t.tuple([t.int(), t.int()]),
	config: F,
	ships: t.array(ve),
	lairs: t.array(t.int()),
	market: t.array(t.string().nullable()),
	bottle: t.int(),
	empty: t.array(t.int()),
	prompt: t.object({
		rid: t.string(),
		actor: t.string(),
		kind: t.string(),
		n: t.number().optional()
	}).nullable(),
	battle: t.object({
		attacker: t.string(),
		defender: t.string(),
		a: t.number().nullable(),
		d: t.number().nullable(),
		powderA: t.number(),
		powderD: t.number(),
		adjacent: t.boolean(),
		winner: t.string().nullable()
	}).nullable(),
	active: t.string().nullable(),
	half: t.int(),
	log: t.array(t.object({
		kind: t.string(),
		rid: t.string(),
		n: t.number().optional(),
		target: t.string().optional(),
		node: t.number().optional(),
		resource: t.string().optional()
	})),
	specialWinner: t.string().nullable()
}), be = t.object({
	hand: t.array(t.int()),
	selected: t.int().nullable(),
	treasures: t.array(t.string()),
	choices: t.array(_e)
}), I = {
	sail: 260,
	event: 550,
	battle: 750,
	reveal: 850
}, L = (e, t) => e.ships[t], R = (e) => e.holds.flatMap((e) => e?.kind === "crew" ? [e.crew] : []), z = (e, t, n) => R(L(e, t)).includes(n), xe = (e, t, n) => L(e, t).treasures.includes(n), B = (e, t, n, r = n) => z(e, t, n) || xe(e, t, r);
function V(t, n) {
	return e(t.seed, t.rngCursor++, n);
}
function H(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; t--) {
		let r = V(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
function U(e, t, n, r = {}) {
	e.log.push({
		kind: t,
		rid: n,
		...r
	}), e.log = e.log.slice(-24);
}
function W(e, t, n, r = {}) {
	e.push({
		kind: t,
		rid: n,
		data: r
	});
}
function G(e, t, n, r, i, a = n, o) {
	e.pending = {
		kind: t,
		rid: n,
		actor: a,
		choices: r,
		job: i,
		...o === void 0 ? {} : { n: o }
	};
}
function Se(e, t) {
	let n = L(e, t), r = B(e, t, "cartographer", "map") ? 4 : 3;
	for (; n.hand.length < r && (n.deck.length || (n.deck = H(e, n.discard), n.discard = []), n.deck.length);) n.hand.push(n.deck.shift());
}
function Ce(e, t) {
	let n = R({ holds: e }), r = /* @__PURE__ */ new Set([t]);
	for (let e = 0; e < 3; e++) for (let [e, t, i] of [
		[
			"venetian",
			"gold",
			"food"
		],
		[
			"prussian",
			"food",
			"powder"
		],
		[
			"helvetian",
			"powder",
			"gold"
		]
	]) n.includes(e) && (r.has(t) || r.has(i)) && (r.add(t), r.add(i));
	return [...r];
}
function K(e, t) {
	let n = Ce(e, t);
	return e.reduce((e, t) => e + (t && t.kind !== "crew" && n.includes(t.kind) ? t.n : 0), 0);
}
function we(e, t, n) {
	return t === "$ghost" ? e.players.find((e) => e !== n) : t;
}
function Te(e, t) {
	return t.rid === "$ghost" ? t.kind === "load" && e.battle?.winner === "$ghost" ? we(e, j, e.battle.attacker === "$ghost" ? e.battle.defender : e.battle.attacker) : e.players[e.captain] : t.rid;
}
function Ee(e, t) {
	z(e, t, "calypso") && [
		"curse2",
		"curse3",
		"curse4"
	].every((n) => xe(e, t, n)) && (e.specialWinner = t, e.phase = "done", e.jobs = [], e.pending = null, U(e, "calypso", t));
}
function De(e, t, n, r) {
	let i = null;
	if (r) {
		let t = L(e, r);
		t.treasures.splice(t.treasures.indexOf(n), 1), n === "hold" && (i = t.holds.pop() ?? null);
	}
	L(e, t).treasures.push(n), n === "hold" && L(e, t).holds.push(i), Ee(e, t);
}
var Oe = (e) => [
	e - 7,
	e + 7,
	...e % 7 > 0 ? [e - 1] : [],
	...e % 7 < 6 ? [e + 1] : []
].filter((e) => e >= 0 && e < 21);
function ke(e, t) {
	let n = /* @__PURE__ */ new Map([[t, 0]]), r = [t];
	for (let t = 0; t < r.length; t++) for (let i of Oe(r[t])) e[i] === null && !n.has(i) && (n.set(i, n.get(r[t]) + 1), r.push(i));
	return n;
}
function Ae(e) {
	let t = ke(e.market, e.bottle), n = new Set([...t.keys()].flatMap(Oe));
	return e.market.map((e, t) => e === null ? null : n.has(t) ? e : "?");
}
function je(e) {
	e.active = null, e.half = 0, e.battle = null;
	for (let t of e.players) {
		let n = L(e, t);
		n.selected !== null && n.discard.push(n.selected), n.selected = null, n.swap = !1, Se(e, t);
	}
	let t = e.players[e.captain];
	z(e, t, "oracle") ? (e.phase = "oracle", e.dice = [0, 0], G(e, "oracle", t, [{
		id: "random",
		kind: "roll"
	}, ...Array.from({ length: 6 }, (e, t) => ({
		id: String(t + 1),
		kind: "die",
		n: t + 1
	}))], {
		kind: "oracle",
		rid: t
	})) : Me(e);
}
function Me(e, t) {
	e.dice = [t ?? V(e, 6) + 1, V(e, 6) + 1], e.phase = "arrange";
	let n = e.players[e.captain];
	G(e, "arrange", n, [{
		id: "keep",
		kind: "dice",
		n: e.dice[0],
		cost: e.dice[1]
	}, {
		id: "swap",
		kind: "dice",
		n: e.dice[1],
		cost: e.dice[0]
	}], {
		kind: "arrange",
		rid: n
	});
}
function Ne(e, t, n) {
	let r = {
		players: [...t],
		ships: {},
		config: F.parse(e),
		seed: n,
		rngCursor: 0,
		phase: "arrange",
		round: 1,
		captain: 0,
		dice: [0, 0],
		jobs: [],
		pending: null,
		active: null,
		half: 0,
		battle: null,
		lairs: k.flatMap((e, t) => e.kind === "lair" ? [t] : []),
		treasureDeck: [],
		market: Array.from({ length: 21 }, () => null),
		bottle: 17,
		log: [],
		beatMs: 0,
		endRound: !1,
		specialWinner: null
	};
	for (let e of [...t, ...t.length === 2 ? [j] : []]) r.ships[e] = {
		node: 0,
		finished: !1,
		holds: e === "$ghost" ? [
			{
				kind: "gold",
				n: 5
			},
			{
				kind: "gold",
				n: 3
			},
			null,
			null,
			null
		] : [
			{
				kind: "gold",
				n: 3
			},
			{
				kind: "food",
				n: 3
			},
			null,
			null,
			null
		],
		treasures: e === "$ghost" ? ["beth"] : [],
		tokens: 0,
		hand: [],
		deck: e === "$ghost" ? [] : H(r, w.map((e, t) => t)),
		discard: [],
		selected: null,
		swap: !1
	};
	if (r.treasureDeck = H(r, [...r.config.crew ? de : ue, ...r.config.extra ? fe : []].filter((e) => t.length !== 2 || e !== "beth")).slice(0, 9), r.config.crew) {
		let e = H(r, [...se]);
		r.market = r.market.map((t, n) => n === 17 ? null : e.pop());
	}
	return r.captain = V(r, t.length), je(r), {
		state: r,
		fx: []
	};
}
function Pe(e, t) {
	let n = L(e, t.rid), r = t.cargo, i = n.holds.flatMap((e, t) => e === null ? [t] : []), a = i.length ? i : n.holds.flatMap((e, t) => e?.kind === r.kind ? [] : [t]);
	if (!a.length) {
		U(e, "ignored", t.rid);
		return;
	}
	G(e, "load", t.rid, a.map((e) => ({
		id: String(e),
		kind: i.length ? "store" : "replace",
		hold: e,
		resource: r.kind,
		n: r.n,
		crew: r.crew
	})), t, Te(e, t));
}
function Fe(e, t) {
	if (!t.n) return;
	let n = L(e, t.rid), r = Ce(n.holds, t.resource), i = n.holds.flatMap((e, n) => e && e.kind !== "crew" && r.includes(e.kind) ? [{
		id: String(n),
		kind: "pay",
		hold: n,
		resource: e.kind,
		n: Math.min(e.n, t.n)
	}] : []);
	i.length && G(e, "pay", t.rid, i, t, Te(e, t), t.n);
}
function Ie(e, t, n) {
	let r = L(e, t.rid);
	if (r.finished) return;
	if (t.kind === "sail" && t.n === 0) {
		e.jobs.unshift({
			kind: "land",
			rid: t.rid
		});
		return;
	}
	let i = t.dir === -1 || t.kind === "retreat" ? k[r.node].previous : k[r.node].next;
	if (!i.length) {
		e.jobs.unshift({
			kind: "land",
			rid: t.rid
		});
		return;
	}
	if (i.length > 1 && t.node === void 0) {
		G(e, "route", t.rid, i.map((e) => ({
			id: String(e),
			kind: "space",
			node: e
		})), t, Te(e, t));
		return;
	}
	let a = r.node, o = Object.entries(e.ships), s = o.findIndex(([e]) => e === t.rid), c = (e) => e === 0 || e === 32, l = (e) => o.slice(0, s).filter(([, t]) => t.node === e || c(t.node) && c(e)).length, u = l(a), d = (e) => o.filter(([, t]) => t.node === e || c(t.node) && c(e)).length, f = d(a);
	if (r.node = t.node ?? i[0], W(n, "sail", t.rid, {
		from: a,
		to: r.node,
		fromRank: u,
		fromCount: f,
		toRank: l(r.node),
		toCount: d(r.node),
		number: s + 1
	}), U(e, t.kind === "retreat" ? "retreat" : "sail", t.rid, { node: r.node }), r.node === 32) {
		r.finished = !0, e.endRound = !0, U(e, "finish", t.rid);
		return;
	}
	if (t.kind === "retreat") {
		let n = k[r.node], i = n.kind !== "food" && n.kind !== "gold" || K(r.holds, n.kind) >= n.cost;
		e.jobs.unshift({
			kind: i ? "land" : "retreat",
			rid: t.rid
		});
	} else e.jobs.unshift({
		...t,
		n: t.n - 1,
		node: void 0
	});
	e.beatMs = I.sail;
}
function Le(e, t) {
	let n = L(e, t);
	if (k[n.node].kind === "royal") return;
	let r = Object.keys(e.ships).filter((r) => r !== t && L(e, r).node === n.node), i = z(e, t, "buccaneer") ? Object.keys(e.ships).filter((r) => r !== t && [...k[n.node].next, ...k[n.node].previous].includes(L(e, r).node) && !L(e, r).finished) : [];
	e.jobs.unshift({
		kind: "settle",
		rid: t
	});
	let a = [...r.map((e) => ({
		id: e,
		kind: "attack",
		rid: e
	})), ...i.map((e) => ({
		id: e,
		kind: "raid",
		rid: e
	}))];
	a.length && (r.length || a.push({
		id: "skip",
		kind: "skip",
		rid: ""
	}), G(e, "enemy", t, a, {
		kind: "enemy",
		rid: t,
		indices: i.map((t) => Object.keys(e.ships).indexOf(t))
	}, t === "$ghost" ? e.players[e.captain] : t));
}
function Re(e, t) {
	let n = L(e, t), r = k[n.node];
	if (t === "$ghost" || r.kind !== "food" && r.kind !== "gold") {
		e.jobs.unshift({
			kind: "collect",
			rid: t
		});
		return;
	}
	let i = K(n.holds, r.kind);
	i < r.cost ? (U(e, "shortage", t, {
		n: r.cost - i,
		resource: r.kind
	}), e.jobs.unshift({
		kind: "pay",
		rid: t,
		resource: r.kind,
		n: i
	}, {
		kind: "retreat",
		rid: t
	})) : e.jobs.unshift({
		kind: "pay",
		rid: t,
		resource: r.kind,
		n: r.cost
	}, ...r.kind === "gold" && e.config.crew ? [{
		kind: "recruit",
		rid: t
	}] : [], {
		kind: "collect",
		rid: t
	});
}
function ze(e, t) {
	let n = L(e, t), r = [n.node, ...z(e, t, "lookout") ? [...k[n.node].next, ...k[n.node].previous] : []].filter((t) => e.lairs.includes(t));
	r.length && e.treasureDeck.length && (r.length === 1 ? Be(e, t, r[0]) : G(e, "lair", t, r.map((e) => ({
		id: String(e),
		kind: "space",
		node: e
	})), {
		kind: "lair",
		rid: t
	}, t === "$ghost" ? e.players[e.captain] : t));
}
function Be(e, t, n) {
	e.lairs.splice(e.lairs.indexOf(n), 1), L(e, t).tokens++, e.jobs.unshift({
		kind: "treasure",
		rid: t,
		source: "deck"
	}), U(e, "treasure", t);
}
function Ve(e, t, n) {
	let r = t.source === "deck" ? e.treasureDeck : L(e, t.source).treasures, i = r.flatMap((e, n) => t.source === "$ghost" && e === "beth" ? [] : [n]);
	if (!i.length) return;
	let a = z(e, t.rid, "nosey") ? 3 : 1;
	if (t.source === "deck") {
		let o = i.slice(0, a);
		if (a === 1) {
			let i = r.shift();
			De(e, t.rid, i), W(n, "treasure", t.rid);
			return;
		}
		G(e, "treasure", t.rid, o.map((e) => ({
			id: String(e),
			kind: "treasure",
			treasure: r[e]
		})), {
			...t,
			indices: o
		});
	} else if (a === 3) {
		let n = H(e, i).slice(0, 3);
		G(e, "treasure", t.rid, n.map((e) => ({
			id: String(e),
			kind: "treasure",
			treasure: r[e]
		})), {
			...t,
			indices: n
		});
	} else G(e, "treasure", t.rid, i.map((e) => ({
		id: String(e),
		kind: "treasure",
		treasure: pe(r[e]) ? r[e] : "?"
	})), t, t.rid === "$ghost" ? we(e, j, t.source) : t.rid);
}
function He(e, t) {
	let n = L(e, t);
	if (!n.holds.some((e) => e?.kind !== "crew")) return;
	let r = ke(e.market, e.bottle), i = K(n.holds, "gold"), a = [{
		id: "skip",
		kind: "skip"
	}];
	for (let [t, n] of r) if (n <= i) for (let r of Oe(t)) e.market[r] && a.push({
		id: `${t}:${r}`,
		kind: "recruit",
		crew: e.market[r],
		cost: n,
		node: r,
		n: t
	});
	a.length > 1 && G(e, "recruit", t, a, {
		kind: "recruit",
		rid: t
	});
}
function Ue(e, t, n, r) {
	e.battle = {
		attacker: t,
		defender: n,
		a: null,
		d: null,
		powderA: 0,
		powderD: 0,
		adjacent: r,
		winner: null,
		rerolled: !1
	}, U(e, "battle", t, { target: n }), e.jobs.unshift({
		kind: "combat",
		rid: t,
		stage: z(e, t, "strategist") ? "win" : "powder",
		side: "a"
	});
}
function We(e, t, n) {
	let r = e.battle, i = t.side ?? "a", a = i === "a" ? r.attacker : r.defender, o = i === "a" ? r.defender : r.attacker;
	if (t.stage === "powder") {
		let n = K(L(e, a).holds, "powder");
		G(e, "powder", a, Array.from({ length: n + 1 }, (e, t) => ({
			id: String(t),
			kind: "powder",
			n: t
		})), t, we(e, a, o));
		return;
	}
	if (t.stage === "roll") {
		r[i] = M[V(e, 6)], W(n, "combat", a, {
			side: i,
			face: r[i]
		}), e.beatMs = I.battle, e.jobs.unshift({
			...t,
			stage: i === "a" ? "afterAttack" : "afterDefense"
		});
		return;
	}
	if (t.stage === "afterAttack" || t.stage === "afterDefense") {
		let n = [r.attacker, r.defender].find((t) => B(e, t, "saran", "sabre"));
		if (n && !r.rerolled) {
			let i = [{
				id: "skip",
				kind: "keep"
			}, {
				id: "a",
				kind: "reroll",
				rid: r.attacker
			}];
			r.d !== null && i.push({
				id: "d",
				kind: "reroll",
				rid: r.defender
			}), G(e, "reroll", n, i, t, we(e, n, n === r.attacker ? r.defender : r.attacker));
			return;
		}
		Ge(e, t.stage);
		return;
	}
	if (t.stage === "win") r.winner = r.attacker;
	else {
		let t = r.a + r.powderA + (B(e, r.attacker, "beth") ? 2 : 0), n = r.d + r.powderD + (B(e, r.defender, "beth") ? 2 : 0);
		r.winner = r.a === -1 ? r.attacker : r.d === -1 ? r.defender : t === n ? null : t > n ? r.attacker : r.defender;
	}
	let s = r.winner;
	if (W(n, "battleResult", s ?? r.attacker, { winner: s }), U(e, s ? "winBattle" : "drawBattle", s ?? r.attacker), !s || r.adjacent && s !== r.attacker) return;
	let c = s === r.attacker ? r.defender : r.attacker, l = L(e, s), u = L(e, c), d = u.holds.flatMap((e, t) => e ? [{
		id: `hold:${t}`,
		kind: r.adjacent ? "destroy" : "stealHold",
		hold: t,
		rid: c,
		resource: e.kind,
		crew: e.crew,
		n: e.n
	}] : []);
	if (!r.adjacent && (u.treasures.some((e) => c !== "$ghost" || e !== "beth") && d.push({
		id: "treasure",
		kind: "stealTreasure",
		rid: c
	}), s !== "$ghost")) for (let e of l.treasures.filter((e) => (N[e] ?? 0) < 0)) d.push({
		id: e,
		kind: "giveCurse",
		treasure: e,
		rid: c
	});
	d.length && G(e, "loot", s, d, {
		kind: "loot",
		rid: s,
		target: c,
		adjacent: r.adjacent
	}, we(e, s, c));
}
function Ge(e, t) {
	let n = e.battle;
	t === "afterAttack" && n.a !== -1 ? e.jobs.unshift({
		kind: "combat",
		rid: n.defender,
		side: "d",
		stage: "powder"
	}) : e.jobs.unshift({
		kind: "combat",
		rid: n.attacker,
		stage: n.a === -1 ? "win" : "result"
	});
}
function Ke(e, t) {
	let n = L(e, t.rid);
	if (n.finished) return;
	if (e.active = t.rid, e.half = t.half, e.battle = null, t.rid === "$ghost") {
		let r = A(n.node), i = Object.values(e.ships).map((e) => A(e.node)), a = r < Math.max(...i) && r === Math.min(...i) ? [-1] : r === Math.max(...i) ? [1] : [-1, 1];
		a.length === 1 ? e.jobs.unshift({
			kind: "sail",
			rid: t.rid,
			dir: a[0],
			n: e.dice[t.half]
		}) : G(e, "ghost", j, a.map((n) => ({
			id: String(n),
			kind: n === 1 ? "forward" : "backward",
			n: e.dice[t.half]
		})), t, e.players[e.captain]);
		return;
	}
	let r = w[n.selected][t.half], i = e.dice[n.swap ? 1 - t.half : t.half];
	if (r !== "forward" && r !== "backward") {
		e.jobs.unshift({
			kind: "load",
			rid: t.rid,
			cargo: {
				kind: r,
				n: i + +!!z(e, t.rid, "cooper") + +!!xe(e, t.rid, "rum")
			}
		});
		return;
	}
	let a = /* @__PURE__ */ new Set([i]);
	B(e, t.rid, "anchoree", "anchor") && a.add(Math.max(0, i - 1)), B(e, t.rid, "seafarer", "sextant") && a.add(i + 1), r === "backward" && z(e, t.rid, "seadog") && a.add(0);
	let o = {
		kind: "sail",
		rid: t.rid,
		dir: r === "forward" ? 1 : -1,
		n: i
	};
	a.size === 1 ? e.jobs.unshift(o) : G(e, "distance", t.rid, [...a].sort((e, t) => e - t).map((e) => ({
		id: String(e),
		kind: r,
		n: e
	})), o);
}
function qe(e, t) {
	let n = e.jobs.shift();
	if (e.beatMs = I.event, !n) {
		e.endRound ? (e.phase = "done", e.active = null, U(e, "end", e.players[e.captain])) : (e.round++, e.captain = (e.captain + 1) % e.players.length, je(e));
		return;
	}
	switch (n.kind) {
		case "action":
			Ke(e, n);
			break;
		case "sail":
		case "retreat":
			Ie(e, n, t);
			break;
		case "land":
			Le(e, n.rid);
			break;
		case "settle":
			Re(e, n.rid);
			break;
		case "collect":
			ze(e, n.rid);
			break;
		case "load":
			Pe(e, n);
			break;
		case "pay":
			Fe(e, n);
			break;
		case "recruit":
			He(e, n.rid);
			break;
		case "treasure":
			Ve(e, n, t);
			break;
		case "combat":
			We(e, n, t);
			break;
		case "hire": {
			let t = e.market[n.node];
			e.market[n.node] = null, e.bottle = n.n, U(e, "recruit", n.rid), e.jobs.unshift({
				kind: "load",
				rid: n.rid,
				cargo: {
					kind: "crew",
					crew: t,
					n: 1
				}
			});
			break;
		}
	}
}
function Je(e, t, n, r) {
	let i = t.job, a = L(e, t.rid);
	switch (e.pending = null, e.beatMs = I.event, t.kind) {
		case "oracle":
			Me(e, n.id === "random" ? void 0 : n.n);
			break;
		case "arrange":
			n.id === "swap" && e.dice.reverse(), e.phase = "select";
			break;
		case "load": {
			let o = a.holds[n.hold];
			a.holds[n.hold] = i.cargo, o && U(e, "discard", t.rid, {
				n: o.n,
				resource: o.kind
			}), U(e, "load", t.rid, {
				n: i.cargo.n,
				resource: i.cargo.kind
			}), W(r, "load", t.rid, {
				hold: n.hold,
				kind: i.cargo.kind,
				n: i.cargo.n,
				...i.cargo.crew ? { crew: i.cargo.crew } : {}
			}), Ee(e, t.rid);
			break;
		}
		case "pay": {
			let o = a.holds[n.hold];
			o.n -= n.n, o.n || (a.holds[n.hold] = null), U(e, "pay", t.rid, {
				n: n.n,
				resource: n.resource
			}), W(r, "pay", t.rid, {
				hold: n.hold,
				n: n.n,
				kind: n.resource
			}), i.n > n.n && e.jobs.unshift({
				...i,
				n: i.n - n.n
			});
			break;
		}
		case "distance":
			n.n > 0 && e.jobs.unshift({
				...i,
				n: n.n
			});
			break;
		case "route":
			e.jobs.unshift({
				...i,
				node: n.node
			});
			break;
		case "ghost":
			e.jobs.unshift({
				kind: "sail",
				rid: j,
				dir: Number(n.id),
				n: n.n
			});
			break;
		case "enemy":
			n.id !== "skip" && Ue(e, t.rid, n.id, n.kind === "raid");
			break;
		case "lair":
			Be(e, t.rid, n.node);
			break;
		case "treasure": {
			let a = i.source === "deck" ? e.treasureDeck : L(e, i.source).treasures, o = a[Number(n.id)];
			i.source === "deck" ? (a.splice(Number(n.id), 1), De(e, t.rid, o), z(e, t.rid, "nosey") && (e.treasureDeck = H(e, a))) : De(e, t.rid, o, i.source), W(r, "treasure", t.rid);
			break;
		}
		case "recruit":
			n.id !== "skip" && e.jobs.unshift({
				kind: "pay",
				rid: t.rid,
				resource: "gold",
				n: n.cost
			}, {
				kind: "hire",
				rid: t.rid,
				node: n.node,
				n: n.n
			});
			break;
		case "powder": {
			let r = e.battle;
			i.side === "a" ? r.powderA = n.n : r.powderD = n.n, e.jobs.unshift({
				kind: "pay",
				rid: t.rid,
				resource: "powder",
				n: n.n
			}, {
				...i,
				stage: "roll"
			});
			break;
		}
		case "reroll":
			if (n.id === "skip") Ge(e, i.stage);
			else {
				let t = e.battle, a = n.id;
				t[a] = M[V(e, 6)], t.rerolled = !0, W(r, "combat", n.rid, {
					side: a,
					face: t[a]
				}), Ge(e, i.stage);
			}
			break;
		case "loot": {
			let a = L(e, i.target);
			if (n.kind === "stealHold" || n.kind === "destroy") {
				let r = a.holds[n.hold];
				a.holds[n.hold] = null, !i.adjacent && (t.rid !== "$ghost" || r.kind === "gold") && e.jobs.unshift({
					kind: "load",
					rid: t.rid,
					cargo: r
				}), U(e, i.adjacent ? "destroy" : "steal", t.rid, {
					target: i.target,
					resource: r.kind,
					n: r.n
				});
			} else n.kind === "stealTreasure" ? e.jobs.unshift({
				kind: "treasure",
				rid: t.rid,
				source: i.target
			}) : n.kind === "giveCurse" && (De(e, i.target, n.treasure, t.rid), U(e, "curse", t.rid, { target: i.target }));
			W(r, "loot", t.rid);
			break;
		}
	}
}
function Ye(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "resolve" || e.pending) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e), n = [];
		return qe(t, n), {
			state: t,
			fx: n
		};
	}
	if (e.phase === "done" || !e.players.includes(n.by)) return { code: "games.jamaica.errTurn" };
	if (t.type === "select") {
		let r = L(e, n.by);
		if (e.phase !== "select" || r.selected !== null || !r.hand.includes(t.card) || t.swap && !z(e, n.by, "witch")) return { code: "games.jamaica.errChoice" };
		let i = structuredClone(e), a = L(i, n.by);
		return a.hand.splice(a.hand.indexOf(t.card), 1), a.selected = t.card, a.swap = t.swap, i.players.every((e) => L(i, e).selected !== null) ? (i.phase = "resolve", i.beatMs = I.reveal, i.jobs = [
			...i.players.slice(i.captain),
			...i.players.slice(0, i.captain),
			...i.players.length === 2 ? [j] : []
		].flatMap((e) => [{
			kind: "action",
			rid: e,
			half: 0
		}, {
			kind: "action",
			rid: e,
			half: 1
		}]), {
			state: i,
			fx: [{
				kind: "reveal",
				data: {}
			}]
		}) : {
			state: i,
			fx: []
		};
	}
	let r = e.pending, i = r?.choices.find((e) => e.id === t.id);
	if (!r || r.actor !== n.by || !i) return { code: "games.jamaica.errChoice" };
	let a = structuredClone(e), o = [];
	return Je(a, a.pending, i, o), {
		state: a,
		fx: o
	};
}
function Xe(e, t) {
	let n = L(e, t), r = R(n), i = n.finished ? 15 : k[n.node].score, a = n.holds.reduce((e, t) => e + (t?.kind === "gold" ? t.n : 0), 0), o = n.treasures.reduce((e, t) => e + (N[t] ?? 0), 0), s = r.reduce((e, t) => e + E[t][+!n.finished], 0) + (r.includes("shipowner") ? r.length * 3 : 0) + (r.includes("bishop") ? n.tokens * 2 : 0);
	return {
		position: i,
		gold: a,
		treasure: o,
		crew: s,
		total: i + a + o + s
	};
}
function Ze(e, t) {
	let n = e.phase === "done", r = e.ships[t];
	return {
		public: {
			phase: e.phase,
			round: e.round,
			captain: e.players[e.captain],
			dice: e.dice,
			config: e.config,
			ships: Object.entries(e.ships).map(([t, r]) => ({
				rid: t,
				node: r.node,
				finished: r.finished,
				holds: r.holds,
				treasures: r.treasures.map((e) => n || pe(e) ? e : null),
				tokens: r.tokens,
				picked: r.selected !== null,
				card: e.phase === "resolve" || n ? r.selected : null,
				swap: e.phase === "resolve" || n ? r.swap : !1,
				score: n ? Xe(e, t) : null
			})),
			lairs: e.lairs,
			market: Ae(e),
			bottle: e.bottle,
			empty: [...ke(e.market, e.bottle).keys()],
			prompt: e.pending ? {
				kind: e.pending.kind,
				rid: e.pending.rid,
				actor: e.pending.actor,
				...e.pending.n === void 0 ? {} : { n: e.pending.n }
			} : null,
			battle: e.battle ? {
				attacker: e.battle.attacker,
				defender: e.battle.defender,
				a: e.battle.a,
				d: e.battle.d,
				powderA: e.battle.powderA,
				powderD: e.battle.powderD,
				adjacent: e.battle.adjacent,
				winner: e.battle.winner
			} : null,
			active: e.active,
			half: e.half,
			log: e.log,
			specialWinner: e.specialWinner
		},
		private: {
			hand: r?.hand ?? [],
			selected: r?.selected ?? null,
			treasures: r?.treasures ?? [],
			choices: e.pending?.actor === t ? e.pending.choices : []
		}
	};
}
function Qe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = Object.fromEntries(e.players.map((t) => [t, Xe(e, t).total])), n = [...e.players].sort((n, r) => (e.specialWinner === n ? -1 : +(e.specialWinner === r)) || t[r] - t[n] || A(L(e, n).node) - A(L(e, r).node)), r = n[0];
	return {
		phase: "done",
		winner: e.specialWinner ? [e.specialWinner] : n.filter((n) => t[n] === t[r] && A(L(e, n).node) === A(L(e, r).node)),
		ranking: n,
		scores: t
	};
}
var $e = {
	meta: me,
	saveCompatibility: { version: "1" },
	schemas: {
		action: he,
		config: F,
		publicView: ye,
		privateView: be
	},
	setup: Ne,
	reduce: Ye,
	viewFor: Ze,
	status: Qe,
	nextTickIn: (e) => e.phase === "resolve" && !e.pending ? e.beatMs : null
};
//#endregion
//#region src/games/jamaica/art.tsx
function q({ kind: e, size: t = 28 }) {
	let n = r().replaceAll(":", "");
	return /* @__PURE__ */ y("svg", {
		viewBox: "0 0 64 64",
		width: t,
		height: t,
		"aria-hidden": "true",
		className: "jamaica-resource",
		children: [
			/* @__PURE__ */ y("defs", { children: [/* @__PURE__ */ y("linearGradient", {
				id: n,
				children: [
					/* @__PURE__ */ v("stop", { stopColor: "#fff4ad" }),
					/* @__PURE__ */ v("stop", {
						offset: ".45",
						stopColor: "#edbb28"
					}),
					/* @__PURE__ */ v("stop", {
						offset: "1",
						stopColor: "#a46511"
					})
				]
			}), /* @__PURE__ */ y("linearGradient", {
				id: `${n}s`,
				x2: ".8",
				y2: "1",
				children: [
					/* @__PURE__ */ v("stop", { stopColor: "#b9c2c1" }),
					/* @__PURE__ */ v("stop", {
						offset: ".5",
						stopColor: "#536166"
					}),
					/* @__PURE__ */ v("stop", {
						offset: "1",
						stopColor: "#202c34"
					})
				]
			})] }),
			e === "gold" ? /* @__PURE__ */ y("g", {
				stroke: "#643c15",
				strokeWidth: "1.1",
				children: [
					/* @__PURE__ */ v("circle", {
						cx: "32",
						cy: "32",
						r: "28",
						fill: `url(#${n})`,
						stroke: "#fff5d6",
						strokeWidth: "2.2"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "32",
						cy: "32",
						r: "24.5",
						fill: "none",
						stroke: "#855019"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "32",
						cy: "32",
						r: "22.5",
						fill: "#ce8821",
						stroke: "#efc956"
					}),
					/* @__PURE__ */ v("path", {
						d: "m30 10 4-2 3 5 8 1-1 6 7 3-3 7 1 7-5 4-1 7-8 2-7 4-6-5-7-2 0-8-5-6 5-7-1-7 9-1 1-5z",
						fill: "#e9b23b",
						stroke: "#83531d"
					}),
					/* @__PURE__ */ v("path", {
						d: "M18 20q13-8 27 0l-1 22q-9 11-15 6-9-1-12-9z",
						fill: "#754a1b",
						stroke: "#f6ce6b",
						strokeWidth: "1.2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M20 21h22v12H19zm-1 14h22l-1 7-10 6-10-7z",
						fill: "#c88d27"
					}),
					/* @__PURE__ */ v("path", {
						d: "M30 18v29m-12-14 25 0",
						fill: "none",
						stroke: "#69451d",
						strokeWidth: "2.6"
					}),
					/* @__PURE__ */ v("path", {
						d: "M29 19v27m-11-14 25 0",
						fill: "none",
						stroke: "#f2cb64",
						strokeWidth: ".9"
					}),
					/* @__PURE__ */ v("path", {
						d: "m20 24 2 0 0-2 2 0 0 2 2 0 0-2 2 0 0 7-8 0zM33 38l2 0 0-2 2 0 0 2 2 0v4l-6 3z",
						fill: "#f6c85e",
						stroke: "#6e4c1c",
						strokeWidth: ".6"
					}),
					/* @__PURE__ */ v("path", {
						d: "m22 27 3 0m-2-2 0 4m13 11 0 3",
						stroke: "#82521e",
						strokeWidth: ".8"
					}),
					/* @__PURE__ */ v("path", {
						d: "m34 23 2-2 2 2-1 2 3 1-2 3-4-1-1-3 2-1m-13 13 2-2 2 2-1 2 3 1-2 3-4-1-1-3 2-1",
						stroke: "#f7cd68",
						strokeWidth: "1.5",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "m27 13 1-5 3 3 3-4 3 5 4-2-1 6-6-1z",
						fill: "#db9c29",
						stroke: "#82531c",
						strokeWidth: ".8"
					}),
					/* @__PURE__ */ v("path", {
						d: "M13 16q6-7 14-8M9 25l2-4m39 22-3 5",
						stroke: "#fff0a0",
						strokeWidth: "1.4",
						fill: "none"
					}),
					Array.from({ length: 20 }, (e, t) => /* @__PURE__ */ v("path", {
						d: "M32 5.7v2.2",
						transform: `rotate(${t * 18} 32 32)`,
						stroke: "#95601c",
						strokeWidth: "1"
					}, t))
				]
			}) : null,
			e === "food" ? /* @__PURE__ */ y("g", {
				strokeLinejoin: "round",
				strokeWidth: ".8",
				children: [
					/* @__PURE__ */ v("path", {
						d: "M6 5h52v54H6z",
						fill: "#5d642c",
						stroke: "#fff4d3",
						strokeWidth: "2.3"
					}),
					/* @__PURE__ */ v("path", {
						d: "M39 15c6-7 12-3 10 3 7-2 11 5 5 9 6 5 0 12-6 10l-10 5-7-11-1-12z",
						fill: "#38352d",
						stroke: "#8e8654"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "42",
						cy: "19",
						rx: "4.4",
						ry: "5",
						fill: "#74704b",
						stroke: "#2b2c22"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "49",
						cy: "24",
						rx: "4.7",
						ry: "5",
						fill: "#5b5841",
						stroke: "#292e26"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "41",
						cy: "29",
						rx: "5",
						ry: "6",
						fill: "#343933",
						stroke: "#8b8458"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "48",
						cy: "34",
						rx: "4.4",
						ry: "5.4",
						fill: "#494d39",
						stroke: "#292c25"
					}),
					/* @__PURE__ */ v("path", {
						d: "M19 24c-7-2-11 4-9 10 0 9 14 15 20 8l7-11z",
						fill: "#db7a19",
						stroke: "#7c5b20"
					}),
					/* @__PURE__ */ v("path", {
						d: "M12 30q3-4 8-3m-6 10 3 3",
						stroke: "#eebc39",
						fill: "none",
						strokeWidth: "1.3"
					}),
					/* @__PURE__ */ v("path", {
						d: "M22 14c7-4 16 0 19 8 4 9 1 18-7 22-9 3-18-3-20-11-3-9 0-16 8-19z",
						fill: "#efe2b8",
						stroke: "#c8a855",
						strokeWidth: "1"
					}),
					/* @__PURE__ */ v("path", {
						d: "M22 18c6-4 14 1 16 8 3 8-1 14-7 15-7 1-13-5-14-11-1-6 1-10 5-12z",
						fill: "#d45224",
						stroke: "#f4bb70"
					}),
					/* @__PURE__ */ v("path", {
						d: "M28 27l-6-9m7 9 6-5m-4 8 7 2m-9 0 3 8m-6-9-7 4m7-8-8-2",
						stroke: "#f6cf97",
						strokeWidth: "1.5"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "28",
						cy: "29",
						rx: "3.2",
						ry: "3.7",
						fill: "#d2bd84",
						stroke: "#faf0cb"
					}),
					/* @__PURE__ */ v("path", {
						d: "M32 42c4-4 9-1 8 4-1 6-8 8-10 3z",
						fill: "#e7b530",
						stroke: "#a38d3e"
					}),
					/* @__PURE__ */ v("path", {
						d: "m33 44 3 3m-24-1 7 2",
						stroke: "#f7d96a",
						fill: "none"
					})
				]
			}) : null,
			e === "powder" ? /* @__PURE__ */ y("g", {
				strokeLinejoin: "round",
				children: [
					/* @__PURE__ */ v("path", {
						d: "m19 4 26 0 16 16v25L45 61H19L3 45V20z",
						fill: "#20232d",
						stroke: "#fff3db",
						strokeWidth: "2.5"
					}),
					/* @__PURE__ */ v("path", {
						d: "M18 18h21l2 29H17l-2-18z",
						fill: "#9f5428",
						stroke: "#4c3728",
						strokeWidth: "1"
					}),
					/* @__PURE__ */ v("path", {
						d: "m18 20 16 0m-16 22 19 0m-16-20-2 18m13-20 3 21",
						stroke: "#d4934d",
						fill: "none",
						strokeWidth: "1"
					}),
					/* @__PURE__ */ v("path", {
						d: "M39 16c1 10 10 13 8 20l-6 10c-3 4-5 4-8 3l-3-6 8-10-4-8z",
						fill: `url(#${n}s)`,
						stroke: "#423d39",
						strokeWidth: "1.5"
					}),
					/* @__PURE__ */ v("path", {
						d: "m38 13 15 9 2 6-5 3-17-12z",
						fill: "#b5ad9d",
						stroke: "#e0d5bb",
						strokeWidth: "1.2"
					}),
					/* @__PURE__ */ v("path", {
						d: "m38 16 13 8m-16 4q0 7-5 12m3 6 8-7",
						stroke: "#f4e2c5",
						strokeWidth: "2",
						fill: "none"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "26",
						cy: "30",
						r: "9",
						fill: "#ce7b29",
						stroke: "#493d33",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "26",
						cy: "30",
						r: "6.5",
						fill: "#a56027",
						stroke: "#e2a143"
					}),
					/* @__PURE__ */ v("path", {
						d: "M25 26c-6-1-6 9 1 8 5-1 3-7 0-5l-1 2m15 14 2 7-5 1-1-5",
						fill: "none",
						stroke: "#d9c49b",
						strokeWidth: "1.3"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "26",
						cy: "30",
						r: "2.5",
						fill: "#444b44",
						stroke: "#a4aaa1",
						strokeWidth: "1"
					})
				]
			}) : null,
			e === "forward" || e === "backward" ? /* @__PURE__ */ y("g", {
				transform: e === "backward" ? "rotate(180 32 32)" : void 0,
				strokeLinejoin: "round",
				children: [
					/* @__PURE__ */ v("path", {
						d: "M32 7c-9 5-17 14-23 23l13 1v23h22V31l12-1C49 19 41 12 32 7z",
						fill: e === "forward" ? "#5c892d" : "#bf2428",
						stroke: "#fff5dc",
						strokeWidth: "3.4"
					}),
					/* @__PURE__ */ v("path", {
						d: "M32 11Q20 20 14 28l12 0v22h14V28h11Q44 18 32 11z",
						fill: "none",
						stroke: e === "forward" ? "#415822" : "#752c24",
						strokeWidth: "1.2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M32 13q-8 6-13 13m7 7v14",
						fill: "none",
						stroke: e === "forward" ? "#99b74b" : "#e55531",
						strokeWidth: "1.5"
					})
				]
			}) : null,
			e === "lair" ? /* @__PURE__ */ y("g", {
				stroke: "#553a27",
				strokeWidth: "1.1",
				strokeLinejoin: "round",
				children: [/* @__PURE__ */ v("circle", {
					cx: "32",
					cy: "32",
					r: "28",
					fill: "#c69d56",
					stroke: "#e1c38b",
					strokeWidth: "2"
				}), /* @__PURE__ */ y("g", {
					transform: "translate(-2 13) scale(1.06 .64)",
					children: [
						/* @__PURE__ */ v("path", {
							d: "m12 31 31-5 10 7-1 16-31 6-9-7z",
							fill: "#8f472c"
						}),
						/* @__PURE__ */ v("path", {
							d: "m43 26 10 7-1 16-9-5z",
							fill: "#5f392c"
						}),
						/* @__PURE__ */ v("path", {
							d: "m12 32 31-5v21l-30 5z",
							fill: "#a7552e"
						}),
						/* @__PURE__ */ v("path", {
							d: "M12 32c-3-8 0-16 8-18l22-4c7 0 12 9 11 20l-10 4z",
							fill: "#ad653b"
						}),
						/* @__PURE__ */ v("path", {
							d: "M12 32c-1-8 1-14 8-16l22-4c4 2 6 8 5 15l-4 7z",
							fill: "#b36b3d"
						}),
						/* @__PURE__ */ v("path", {
							d: "m43 12 0 22 10-4c1-9-3-17-10-18z",
							fill: "#6c402e"
						}),
						/* @__PURE__ */ v("path", {
							d: "m15 23 31-6m-33 12 33-6m-31 17 27-5m-27 11 26-5",
							stroke: "#74412c",
							fill: "none"
						}),
						/* @__PURE__ */ v("path", {
							d: "m18 17 4-1m-5 11 8-2m4 13 8-1m-8 9 7-1",
							stroke: "#ce8b50",
							fill: "none",
							strokeWidth: ".8"
						}),
						/* @__PURE__ */ v("path", {
							d: "M21 15c-5 3-5 10-3 18l1 19m18-40c-3 4-2 13 0 18v19m-24 4 30-5m0-36 0 36 9 1",
							stroke: "#89958a",
							strokeWidth: "3.2",
							fill: "none"
						}),
						/* @__PURE__ */ v("path", {
							d: "M21 15c-4 5-4 11-2 18v18m18-38c-2 4-1 12 1 17v18m-24 4 29-5",
							stroke: "#d1cbb1",
							strokeWidth: ".7",
							fill: "none"
						}),
						/* @__PURE__ */ v("path", {
							d: "m25 32 8-1v10l-8 2z",
							fill: "#a3ad98",
							stroke: "#51554a"
						}),
						/* @__PURE__ */ v("path", {
							d: "m27 34 4-1v3l-1 1 1 3-3 0 1-3-2-1z",
							fill: "#343b34",
							stroke: "none"
						}),
						/* @__PURE__ */ v("path", {
							d: "M12 33 43 28m-29 18v2m28-10v3m7-6v3",
							fill: "none",
							stroke: "#dbc493",
							strokeWidth: ".8"
						})
					]
				})]
			}) : null,
			e === "star" ? /* @__PURE__ */ v("path", {
				d: "m32 5 5 17 14-12-8 18 17 4-17 5 11 15-18-9-4 17-5-17-16 11 10-17-17-5 17-4-10-17 16 11z",
				fill: "#e6d8b2",
				stroke: "#302c29",
				strokeWidth: "2.4",
				strokeLinejoin: "round"
			}) : null,
			e === "crew" ? /* @__PURE__ */ y("g", {
				stroke: "#715131",
				strokeWidth: "2",
				fill: "none",
				strokeLinejoin: "round",
				strokeLinecap: "round",
				children: [
					/* @__PURE__ */ v("path", { d: "M12 5h39v54H12z" }),
					/* @__PURE__ */ v("path", { d: "M21 19c0-8 6-12 11-12 7 0 11 6 10 13l5 4-9 1-6-3-10 4-7-3zM22 28c-6-2-7 6-1 7 1 8 6 12 12 12s11-6 11-13c5-1 4-8-1-6M25 31l3 1m8-1 3-1m-8 1-3 6 6 0m-8 3q7 5 13-1M20 53c2-7 5-9 8-9m7 1 8 9m-18-8 7 8 5-8" }),
					/* @__PURE__ */ v("path", { d: "M29 13q4-3 6 1v5h-6z" }),
					/* @__PURE__ */ v("path", {
						d: "m30 15 0 1m3-1 0 1",
						strokeWidth: "1"
					})
				]
			}) : null
		]
	});
}
function et({ color: e = "#b74531", number: t, ghost: n = !1 }) {
	let i = r().replaceAll(":", "");
	return /* @__PURE__ */ y("svg", {
		viewBox: "0 0 140 120",
		"aria-hidden": "true",
		className: "jamaica-ship-art",
		children: [
			/* @__PURE__ */ y("defs", { children: [/* @__PURE__ */ y("linearGradient", {
				id: i,
				x2: "0",
				y2: "1",
				children: [
					/* @__PURE__ */ v("stop", { stopColor: "#dfb876" }),
					/* @__PURE__ */ v("stop", {
						offset: ".5",
						stopColor: "#9a582e"
					}),
					/* @__PURE__ */ v("stop", {
						offset: "1",
						stopColor: "#4d3226"
					})
				]
			}), /* @__PURE__ */ y("linearGradient", {
				id: `${i}p`,
				x2: "1",
				y2: ".5",
				children: [
					/* @__PURE__ */ v("stop", { stopColor: n ? "#66757a" : "#fff4ce" }),
					/* @__PURE__ */ v("stop", {
						offset: ".6",
						stopColor: n ? "#b2beb7" : "#fff9df"
					}),
					/* @__PURE__ */ v("stop", {
						offset: "1",
						stopColor: n ? "#465b64" : "#cfb784"
					})
				]
			})] }),
			/* @__PURE__ */ v("ellipse", {
				cx: "72",
				cy: "109",
				rx: "56",
				ry: "6",
				fill: "#134b5c",
				opacity: ".3"
			}),
			/* @__PURE__ */ y("g", {
				stroke: "#3e2c23",
				strokeWidth: "2",
				strokeLinejoin: "round",
				children: [
					/* @__PURE__ */ v("path", {
						d: "m15 79 109-4-8 21q-12 18-67 12L30 99z",
						fill: `url(#${i})`
					}),
					/* @__PURE__ */ v("path", {
						d: "m15 79 4 8 101-3 4-9z",
						fill: e
					}),
					/* @__PURE__ */ v("path", {
						d: "m31 99 82-5M25 93l91-5m-74-1 5 17m16-18 2 20m17-21v20m17-21-3 17",
						fill: "none",
						stroke: "#593b2b",
						strokeWidth: "1.5"
					}),
					/* @__PURE__ */ v("path", {
						d: "m106 73 4-21 22 1-3 30-18 2",
						fill: "#b98a51"
					}),
					/* @__PURE__ */ v("path", {
						d: "m113 61 4 1v8h-4zm9 0 4 1v7h-4z",
						fill: "#efda8b"
					}),
					/* @__PURE__ */ v("path", {
						d: "M62 86V8m36 69V20M35 83V28",
						stroke: "#65452c",
						strokeWidth: "4"
					}),
					/* @__PURE__ */ v("path", {
						d: "M58 16h-4M60 23H18m78 9H69M33 37H10M61 60H12m84 6H71",
						stroke: "#5b412e",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ v("path", {
						d: "M56 25Q28 22 19 28q8 20-5 30 20 10 45 1-10-18-3-34",
						fill: `url(#${i}p)`
					}),
					/* @__PURE__ */ v("path", {
						d: "M93 35q-12-1-24 0 9 14 2 29 11 7 26-1-8-15-4-28",
						fill: `url(#${i}p)`
					}),
					/* @__PURE__ */ v("path", {
						d: "M31 39H12q8 11 1 21 7 5 18 1-5-13 0-22",
						fill: `url(#${i}p)`
					}),
					/* @__PURE__ */ v("path", {
						d: "M60 9q14-9 23 0l-5 10q-8-7-18-2z",
						fill: e
					}),
					/* @__PURE__ */ v("path", {
						d: "m63 9 10 5m-7 0 7-5",
						stroke: "#fff1cf"
					}),
					/* @__PURE__ */ v("path", {
						d: "m59 20 48 59M61 21 25 82M96 32l28 48M35 36 13 80",
						stroke: "#594a36",
						strokeWidth: "1"
					}),
					/* @__PURE__ */ v("path", {
						d: "M25 30q13 13 25 1M23 54q14 9 30 2m20-17q8 6 17 0m-16 20q9 5 18-1",
						fill: "none",
						stroke: "#c1ae85",
						strokeWidth: "1"
					}),
					/* @__PURE__ */ v("path", {
						d: "m6 77 16 4m99-7 13-9",
						stroke: "#77452c",
						strokeWidth: "4"
					}),
					[
						42,
						58,
						77,
						94
					].map((e) => /* @__PURE__ */ y("g", { children: [/* @__PURE__ */ v("circle", {
						cx: e,
						cy: "93",
						r: "4",
						fill: "#252c2f",
						stroke: "#c29a55"
					}), /* @__PURE__ */ v("path", {
						d: `M${e - 1} 91h2`,
						stroke: "#8a9e9c",
						strokeWidth: "1"
					})] }, e)),
					/* @__PURE__ */ v("path", {
						d: "M34 74h12v8H34z",
						fill: "#594a34"
					}),
					/* @__PURE__ */ v("path", {
						d: "m37 75 12-4 2 4-12 4",
						fill: "#303b3c"
					}),
					/* @__PURE__ */ v("path", {
						d: "M64 39q9-8 14 0l-2 8-8 1z",
						fill: e,
						stroke: "none"
					}),
					t !== void 0 && /* @__PURE__ */ v("text", {
						x: "40",
						y: "48",
						fontSize: "18",
						textAnchor: "middle",
						fill: "#513622",
						stroke: "none",
						fontWeight: "800",
						children: t
					})
				]
			})
		]
	});
}
function J({ id: e, hidden: t = !1, crewSet: n = !1 }) {
	let i = r().replaceAll(":", ""), a = e?.startsWith("curse"), o = e?.startsWith("p"), s = t || !e || e === "?", c = `url(#${i}g)`, l = `url(#${i}w)`, u = `url(#${i}s)`, d = `url(#${i}a)`, f = `url(#${i}p)`, p;
	return p = !s && n && o ? /* @__PURE__ */ y("g", {
		stroke: "#5b4226",
		strokeWidth: "1",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ v("path", {
				d: "M18 24c6-14 29-16 42-5 17 13 15 35 1 44l-2 12-17-2-7 4-15-4 1-13C8 49 9 34 18 24z",
				fill: c
			}),
			/* @__PURE__ */ v("path", {
				d: "M49 21c16 10 18 28 8 39l-8 9-5 3 15 3 2-12c18-14 14-37-8-46z",
				fill: "#8a672c",
				stroke: "none"
			}),
			/* @__PURE__ */ v("path", {
				d: "M19 35q10-12 19-4c7 11-2 22-15 19-8-1-10-9-4-15zm31-7c12-5 19 6 15 16-4 11-14 11-19 1-3-8-1-14 4-17z",
				fill: "#3b3b2b"
			}),
			/* @__PURE__ */ v("path", {
				d: "M27 33q9-4 10 6c-1 7-12 7-13 1-1-3 0-5 3-7z",
				fill: e === "p7" || e?.startsWith("p4") ? "#467e54" : "#aa8034",
				stroke: "#e9ce68",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ v("path", {
				d: "m47 45-5 12 9-1-1-10m-28 11 4 2m-6 4 7 2m6-3 4 1m21-11 4-3m-34 21 30 2m-28-8-1 10m7-9-1 10m7-8 0 7m7-7 0 7",
				fill: "none",
				stroke: "#503e24",
				strokeWidth: "1.3"
			}),
			/* @__PURE__ */ v("path", {
				d: "M22 24c11-6 28-7 38 0l-2-11-14-6-16 4z",
				fill: e === "p7" || e?.startsWith("p4") ? c : u
			}),
			e === "p7" ? /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v("path", {
					d: "m22 15-3-13 11 8 8-9 6 9 12-9 2 15z",
					fill: c
				}),
				/* @__PURE__ */ v("path", {
					d: "m28 10 4 4m9-9 1 9m12-8-1 7",
					stroke: "#fce69c",
					fill: "none"
				}),
				/* @__PURE__ */ v("path", {
					d: "m25 16 32 0",
					stroke: "#8b6329"
				})
			] }) : e?.startsWith("p4") ? /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v("path", {
					d: "m24 15 0-5 35 0 0 9",
					fill: c
				}),
				[
					25,
					33,
					42,
					51,
					59
				].map((e) => /* @__PURE__ */ v("circle", {
					cx: e,
					cy: "9",
					r: "2.2",
					fill: c
				}, e)),
				/* @__PURE__ */ v("path", {
					d: "m27 13 28 0",
					stroke: "#f9db7d"
				})
			] }) : /* @__PURE__ */ v("path", {
				d: "M26 16q14-7 31 0m-23-3 4 5 5-6 5 5 5-5",
				fill: "none",
				stroke: "#d1b778",
				strokeWidth: "1"
			}),
			[
				20,
				26,
				52,
				60
			].map((e, t) => /* @__PURE__ */ y("g", { children: [/* @__PURE__ */ v("circle", {
				cx: e,
				cy: 31 - t % 2 * 3,
				r: "2.8",
				fill: c
			}), /* @__PURE__ */ v("circle", {
				cx: e,
				cy: 31 - t % 2 * 3,
				r: "1",
				fill: "#857024"
			})] }, e)),
			/* @__PURE__ */ v("path", {
				d: "M17 32q-4 11 1 18m5-24 8-2m25 3 6 4m-39 22 5 1",
				fill: "none",
				stroke: "#f4d47e",
				strokeWidth: "1.2"
			})
		]
	}) : !s && n && a ? /* @__PURE__ */ y("g", {
		stroke: "#60402f",
		strokeWidth: "1",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ v("path", {
				d: "M30 53c-8 2-9 9-9 15-2 2-4 7-1 9 4 4 11 3 14-1 2-3 1-6 2-8l7-8z",
				fill: `url(#${i}cloth)`
			}),
			/* @__PURE__ */ v("path", {
				d: "M49 54c8 1 11 5 14 10 5 0 9 5 8 9-1 5-9 7-13 4-4-3-3-6-6-9l-9-5z",
				fill: `url(#${i}cloth)`
			}),
			/* @__PURE__ */ v("path", {
				d: "M25 61c-2 5-3 9-1 14m8-14-2 8m23-10 6 9m5 0 4 3",
				stroke: "#f2d598",
				fill: "none"
			}),
			/* @__PURE__ */ v("path", {
				d: "M22 70q6 3 12 1m23-3q4 6 11 6",
				stroke: e === "curse4" ? "#a5452d" : "#90613b",
				fill: "none",
				strokeWidth: e === "curse4" ? 5 : 1
			}),
			/* @__PURE__ */ v("path", {
				d: "M29 38c-6-4-10-3-15-2-6-2-11 0-12 5-1 5 3 10 9 10l14-2 9-4z",
				fill: `url(#${i}cloth)`
			}),
			/* @__PURE__ */ v("path", {
				d: "M56 36c4-3 9-3 14-4 5-2 10 0 11 4 2 6-3 11-8 11l-13 2-7-5z",
				fill: `url(#${i}cloth)`
			}),
			/* @__PURE__ */ v("path", {
				d: "M12 37q4 6 2 13m11-13q-4 6-1 12m40-15q4 7 2 14m10-15q-4 6-1 12",
				stroke: "#9e693a",
				fill: "none"
			}),
			/* @__PURE__ */ v("path", {
				d: "M4 39q-2 6 2 9m6-10q4 1 9 0m49-3 6 0",
				stroke: "#efcc88",
				fill: "none"
			}),
			e === "curse4" && /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("path", {
				d: "M4 39q-2 6 2 9m69-14q4 3 1 9",
				stroke: "#ac492e",
				strokeWidth: "5"
			}), /* @__PURE__ */ v("path", {
				d: "m17 36-3 14m47-15 3 13",
				stroke: "#d4cbb0",
				strokeWidth: "4"
			})] }),
			/* @__PURE__ */ v("path", {
				d: "M31 32c-7 6-10 15-7 22 2 8 10 12 19 11 12 0 19-6 19-15 0-9-6-17-14-19z",
				fill: e === "curse4" ? `url(#${i}blackcloth)` : `url(#${i}cloth)`
			}),
			/* @__PURE__ */ v("path", {
				d: "M51 36c7 5 10 15 5 22-4 5-8 5-13 6 11 2 19-5 19-14 0-6-3-12-7-15z",
				fill: e === "curse4" ? "#171e20" : "#9f6a38",
				stroke: "none",
				opacity: ".65"
			}),
			/* @__PURE__ */ v("path", {
				d: "M28 43q-3 10 6 15m3-23q4-1 8 0m-17 24 8 3m14-2 6-3",
				stroke: e === "curse4" ? "#74766c" : "#f0cd8b",
				fill: "none",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ v("path", {
				d: "M22 19c-1-10 7-16 18-17 14-1 23 6 24 17 0 12-10 19-23 19-12 0-20-8-19-19z",
				fill: e === "curse4" ? `url(#${i}blackcloth)` : `url(#${i}cloth)`
			}),
			/* @__PURE__ */ v("path", {
				d: "M55 9c7 12 1 22-10 26 12 2 21-5 19-16-1-4-4-8-9-10z",
				fill: e === "curse4" ? "#141f20" : "#a47641",
				stroke: "none",
				opacity: ".7"
			}),
			e === "curse4" ? /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v("path", {
					d: "M24 14c-1-7 7-12 14-10l1 10-7 7-8-1zm18-9c9-3 17 2 20 10l-7 7-10-5z",
					fill: "#b7502c",
					stroke: "#d99b50",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ v("path", {
					d: "m26 13 8-6m11 1 10 6",
					stroke: "#eead5a",
					fill: "none"
				}),
				/* @__PURE__ */ v("path", {
					d: "m31 18 9 0m-2-11 6 0",
					stroke: "#554233",
					strokeWidth: "1.5"
				}),
				/* @__PURE__ */ v("path", {
					d: "M24 22c9-5 25-4 36 0-1 10-10 16-19 15-9 0-16-6-17-15z",
					fill: "#e6d7ae"
				}),
				/* @__PURE__ */ v("path", {
					d: "m27 22 3 9m3-11 4 14m4-14 4 13m3-13 4 10m3-8 3 5",
					stroke: "#6e5c47",
					strokeWidth: "1.5"
				}),
				/* @__PURE__ */ v("path", {
					d: "M26 23q17 7 31-1",
					stroke: "#9c8f6b",
					fill: "none"
				}),
				/* @__PURE__ */ v("path", {
					d: "m29 42 7 2m-8 4 8 1m18-7-6 2m9 3-8 2",
					stroke: "#d7d4b6",
					strokeWidth: "3",
					fill: "none"
				}),
				/* @__PURE__ */ v("circle", {
					cx: "43",
					cy: "44",
					r: "4.4",
					fill: "#b64f2f"
				}),
				/* @__PURE__ */ v("circle", {
					cx: "45",
					cy: "55",
					r: "4",
					fill: "#a6472d"
				}),
				/* @__PURE__ */ v("path", {
					d: "m42 41 2 5m-4-2 6-1m-3 9 4 4m-4 0 4-4",
					stroke: "#e1c8a0",
					fill: "none"
				})
			] }) : e === "curse3" ? /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v("path", {
					d: "M22 16c0-9 8-16 19-15 13 0 21 6 22 15l-6-3-1 6-7-8-4 8-5-9-7 8-3-7z",
					fill: "#a44b25"
				}),
				/* @__PURE__ */ v("path", {
					d: "M28 8q3-6 11-4m4-1q10 0 14 8m-32 1 3 5",
					stroke: "#e19a3e",
					fill: "none",
					strokeWidth: "1.6"
				}),
				/* @__PURE__ */ v("path", {
					d: "m31 23 2 0m12-2 2 0",
					stroke: "#624331",
					strokeWidth: "2.2"
				}),
				/* @__PURE__ */ v("path", {
					d: "m36 27 4-1 1 3m-9 2q6 4 12 0",
					stroke: "#94623e",
					fill: "none"
				}),
				/* @__PURE__ */ v("path", {
					d: "M39 43c-4-7-11-5-10 0 1 5 8 10 14 13 4-7 8-11 5-15-3-4-7-3-9 2z",
					fill: "#9e3e27"
				}),
				/* @__PURE__ */ v("path", {
					d: "m32 41 3-1",
					stroke: "#dc8262",
					fill: "none"
				}),
				/* @__PURE__ */ v("path", {
					d: "m23 21-5-2m44 1 5-4m-37 44 8 1m11-2 6-3",
					stroke: "#6c553c",
					fill: "none"
				}),
				/* @__PURE__ */ v("path", {
					d: "m19 17-2 5m48-8 3 4m-37 40-1 5m4-4 0 4m17-7 2 4",
					stroke: "#baa880",
					fill: "none"
				})
			] }) : /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v("path", {
					d: "M24 16q15 8 36-1m-31-4 1 9m5-8 1 10m7-8 0 8m7-9-1 7m6-9-2 7M26 28q16-6 33-3m-28-1 2 8m6-9 1 7m8-7 0 7m7-7-1 6",
					stroke: "#725333",
					fill: "none",
					strokeWidth: "1.3"
				}),
				/* @__PURE__ */ v("path", {
					d: "M40 43c-5-6-12-3-8 3l10 9 7-14c0-5-6-5-9 2z",
					fill: "#86452c"
				}),
				/* @__PURE__ */ v("path", {
					d: "M26 51q16 7 33-1m-28-1 0 8m6-6 0 7m7-5 0 7m7-7 0 6m-24 7 6 2m-9 2 8 2m24-9 6 5m-4-6 6 5",
					stroke: "#795735",
					fill: "none"
				}),
				/* @__PURE__ */ v("path", {
					d: "m26 24-9-5m18-7-1-10m19 9 9-6",
					stroke: "#63553b",
					fill: "none"
				}),
				[
					[17, 19],
					[34, 2],
					[62, 5]
				].map(([e, t]) => /* @__PURE__ */ v("circle", {
					cx: e,
					cy: t,
					r: "1.9",
					fill: "#b74d30"
				}, e))
			] }),
			/* @__PURE__ */ v("path", {
				d: "m14 41 2 0m-1 3 2 0m7-5 2 1m-1 3 2 1m40-5 2-1m-1 4 2-1m-37 20 3 1m19 0 2-1",
				stroke: e === "curse4" ? "#a6a18c" : "#9b7144",
				strokeWidth: ".6",
				fill: "none"
			})
		]
	}) : s || o || a ? /* @__PURE__ */ y("g", {
		stroke: "#473022",
		strokeWidth: "1.1",
		strokeLinejoin: "round",
		children: [
			a && /* @__PURE__ */ y("g", {
				fill: "none",
				stroke: "#afc74d",
				strokeWidth: "2",
				opacity: ".65",
				children: [/* @__PURE__ */ v("path", { d: "M28 47c-18-8-3-20-9-25-11-8-14 4-9 7m34 14c16-6 6-18 10-25 3-6 11-4 9 3m-34 18c-9-9 9-12 0-20" }), /* @__PURE__ */ v("path", {
					d: "M17 44c-9-5-13 1-9 6m49-11c13-6 17 3 11 7",
					strokeWidth: "1"
				})]
			}),
			!s && /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v("path", {
					d: "M21 40 20 18q20-10 44-2l7 24-13 8-29 1z",
					fill: l
				}),
				/* @__PURE__ */ v("path", {
					d: "M25 35 24 20q17-7 36-2l6 21-11 4-28-1z",
					fill: "#30251d"
				}),
				/* @__PURE__ */ v("path", {
					d: "M27 22q15-4 30-2l4 14-15-5z",
					fill: "#5d3421"
				}),
				/* @__PURE__ */ v("path", {
					d: "m22 17 5 21m33-22 8 23",
					stroke: c,
					strokeWidth: "3"
				}),
				/* @__PURE__ */ v("path", {
					d: "m25 18 4 19m32-20 6 21",
					stroke: "#ead19a",
					strokeWidth: ".7"
				}),
				/* @__PURE__ */ v("path", {
					d: "M37 18q5-3 8-1l1 5-7 0z",
					fill: u
				})
			] }),
			/* @__PURE__ */ v("path", {
				d: "m12 43 39-7 23 11-5 24-37 8-19-10z",
				fill: l
			}),
			/* @__PURE__ */ v("path", {
				d: "m14 44 17 9 42-7-21-10z",
				fill: "#cf8742"
			}),
			/* @__PURE__ */ v("path", {
				d: "m17 44 15 5 31-5-12-5z",
				fill: "#30231d"
			}),
			!s && /* @__PURE__ */ y(_, { children: [
				Array.from({ length: 17 }, (e, t) => /* @__PURE__ */ y("g", {
					transform: `translate(${25 + t * 13 % 38} ${40 + t * 7 % 10}) rotate(${t * 27})`,
					children: [/* @__PURE__ */ v("ellipse", {
						rx: "4.2",
						ry: "1.7",
						fill: c,
						stroke: "#865b23",
						strokeWidth: ".6"
					}), /* @__PURE__ */ v("path", {
						d: "M-3 0H3",
						stroke: "#fbe08b",
						strokeWidth: ".5"
					})]
				}, t)),
				/* @__PURE__ */ v("path", {
					d: "M30 45c-2-8 3-12 8-10 7 2 4 12-3 12z",
					fill: c
				}),
				/* @__PURE__ */ v("path", {
					d: "m34 37 0 8m-2-5 5 0",
					stroke: "#a07524"
				}),
				o && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "m49 41 2-11 4 4 4-7 3 8 5-2-4 11z",
						fill: c
					}),
					/* @__PURE__ */ v("circle", {
						cx: "55",
						cy: "39",
						r: "1.7",
						fill: "#a52e28"
					}),
					/* @__PURE__ */ v("path", {
						d: "m22 48-5-11 6-2 7 12",
						fill: c
					})
				] })
			] }),
			/* @__PURE__ */ v("path", {
				d: "m32 54 41-7-4 24-37 8z",
				fill: l
			}),
			/* @__PURE__ */ v("path", {
				d: "m13 44 19 10v25L13 69z",
				fill: "#674025"
			}),
			/* @__PURE__ */ v("path", {
				d: "m38 54-2 19m9-21-1 20m9-22-1 20m9-22-2 20m8-21-2 20M17 49l0 17m6-14 0 19",
				fill: "none",
				stroke: "#4c2e21",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ v("path", {
				d: "m34 55 4-1-1 21 31-6 1-19 4-1-3 23-37 8zM13 45l4 2 0 18 14 8v5L13 69z",
				fill: u
			}),
			/* @__PURE__ */ v("path", {
				d: "m35 55 1 20 32-6m-53-21 0 18 16 9",
				fill: "none",
				stroke: "#e2c999",
				strokeWidth: ".7"
			}),
			/* @__PURE__ */ v("path", {
				d: "m47 55 9-2-1 10-9 2z",
				fill: u
			}),
			/* @__PURE__ */ v("ellipse", {
				cx: "51",
				cy: "58",
				rx: "2",
				ry: "2.6",
				fill: "#392c22"
			}),
			/* @__PURE__ */ v("path", {
				d: "m50 59-1 4 3-1-1-3",
				fill: "#1c2420"
			}),
			/* @__PURE__ */ v("path", {
				d: "m40 76 0-4m22 0 0-4m-46-18 0 2m1 10 0 2m19-7 0 2m1 10 0 2m30-16 0 2m-1 9 0 2",
				stroke: "#f5db96",
				strokeWidth: "1.2"
			}),
			s && /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v("path", {
					d: "M13 44c-3-14 4-24 18-27l29-4c11 2 15 12 14 30l-41 9z",
					fill: l
				}),
				/* @__PURE__ */ v("path", {
					d: "M20 23q-4 9-2 20m8-24q-3 11-2 27m10-29 0 29m8-30 2 29m6-29 3 27m5-28 5 25",
					stroke: "#603c25",
					fill: "none"
				}),
				/* @__PURE__ */ v("path", {
					d: "m14 44 19 8 41-9m-52-22 3 25m31-31 8 26",
					stroke: u,
					strokeWidth: "3"
				}),
				/* @__PURE__ */ v("path", {
					d: "m25 21 3 25m31-30 7 25",
					stroke: "#e5cc91",
					strokeWidth: ".7"
				})
			] }),
			a && /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v("path", {
					d: "M22 43c-10-14 5-13 8-20-10-4-10-14-3-15 11 0 11 14 4 21-7 7-8 9 2 14m17-3c17-12-3-15 9-23 11-9 11-13 7-18",
					fill: "none",
					stroke: "#d7e764",
					strokeWidth: "2.7"
				}),
				/* @__PURE__ */ v("path", {
					d: "M24 39c-9-7 3-8 7-14m19 12c9-5 4-9 8-15",
					fill: "none",
					stroke: "#f9f59c",
					strokeWidth: ".8"
				}),
				/* @__PURE__ */ v("path", {
					d: "m14 40 4-1m44-9 4-2m-29-14 3-2",
					stroke: "#d1dc62"
				})
			] }),
			o && /* @__PURE__ */ y(_, { children: [
				/* @__PURE__ */ v("path", {
					d: "M65 65c12-3 17 10 8 15l-11 0-4-5z",
					fill: "#71482a"
				}),
				/* @__PURE__ */ v("path", {
					d: "m67 64 6-7 4 2-5 7",
					fill: "#9f6b36"
				}),
				/* @__PURE__ */ v("ellipse", {
					cx: "60",
					cy: "78",
					rx: "5",
					ry: "2",
					fill: c
				}),
				/* @__PURE__ */ v("ellipse", {
					cx: "54",
					cy: "79",
					rx: "4",
					ry: "1.6",
					fill: c
				}),
				/* @__PURE__ */ v("path", {
					d: "M6 75q5-4 10-1m3 5 9-2",
					stroke: c,
					strokeWidth: "2.5",
					fill: "none"
				})
			] })
		]
	}) : e === "diamond" ? /* @__PURE__ */ y("g", {
		stroke: "#702e42",
		strokeWidth: ".8",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ v("path", {
				d: "m8 29 17-17h37l15 17-35 46z",
				fill: "#cf345b"
			}),
			/* @__PURE__ */ v("path", {
				d: "m8 29 17-17 8 17zm17-17 17 0-9 17zm17 0 20 0-10 17zm20 0 15 17H52z",
				fill: "#f18caa"
			}),
			/* @__PURE__ */ v("path", {
				d: "m8 29 25 0 9 46zm25 0 19 0-10 46zm19 0 25 0-35 46z",
				fill: "#a42247"
			}),
			/* @__PURE__ */ v("path", {
				d: "m8 29 25 0 9 46m-17-63 8 17h19l10-17m-10 17L42 75m-34-46h69",
				fill: "none",
				stroke: "#ffd0c5",
				strokeWidth: "1.8"
			}),
			/* @__PURE__ */ v("path", {
				d: "m17 25 7-7 5 8m12-10 6 9m12-6 8 7",
				stroke: "#ffe3da",
				strokeWidth: "1.2",
				fill: "none"
			})
		]
	}) : e === "map" ? /* @__PURE__ */ y("g", {
		stroke: "#6e4226",
		strokeWidth: "1.1",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ v("path", {
				d: "M20 11q22-5 45 1l-5 58-42-3z",
				fill: f
			}),
			/* @__PURE__ */ v("path", {
				d: "M19 12c-11-3-15 8-8 13l11-1 0-8 40 1c11 1 14-8 5-10l-48 1z",
				fill: f
			}),
			/* @__PURE__ */ v("path", {
				d: "M13 12q-5 7 6 8m43-12c7 2 7 7-2 7",
				fill: "none",
				stroke: "#b68444"
			}),
			/* @__PURE__ */ v("path", {
				d: "M18 55c-12-3-16 6-9 11l9 2 44 0c11 1 13-12 5-13l-49 0z",
				fill: f
			}),
			/* @__PURE__ */ v("path", {
				d: "M18 56q10 5 2 11m43-10q8 5 1 10M22 25q17-6 34-2m-35 8 7-4 3 7 8-3 4 5 10-6 3 6-11 7-7-5-5 8-8-3m3 0-1 7 5 1m10-8 9 2-2 7m-26-12 3-2m13 13 8 1",
				stroke: "#aa763d",
				fill: "none",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ v("circle", {
				cx: "40",
				cy: "34",
				r: "12",
				fill: "none",
				stroke: "#b18445",
				strokeWidth: ".65"
			}),
			/* @__PURE__ */ v("path", {
				d: "m29 34 22 0m-11-11 0 22m-7-18 14 14m0-14-14 14",
				stroke: "#b68c4f",
				strokeWidth: ".5"
			}),
			/* @__PURE__ */ v("path", {
				d: "m22 23 3 5 5-5m16 18 7 9m0-9-7 9",
				stroke: "#89522f",
				fill: "none"
			}),
			/* @__PURE__ */ v("path", {
				d: "m24 15 3 2m17-4 6 2m-38 46 6 2m43-1 4 1",
				stroke: "#f3d6a0",
				fill: "none"
			})
		]
	}) : e === "sabre" ? /* @__PURE__ */ y("g", {
		stroke: "#713124",
		strokeWidth: "1",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ v("path", {
				d: "M64 5c15 20 6 44-27 57l-9-10C49 41 64 25 64 5z",
				fill: `url(#${i}blade)`
			}),
			/* @__PURE__ */ v("path", {
				d: "M65 9c6 20-8 38-31 48",
				stroke: "#ffdf95",
				strokeWidth: "1.6",
				fill: "none"
			}),
			/* @__PURE__ */ v("path", {
				d: "m62 23-5 10m-7 5-4 8m-5 0-5 7",
				stroke: "#ce602e",
				fill: "none"
			}),
			/* @__PURE__ */ v("path", {
				d: "M20 44c5 0 9 5 10 10 10 0 15 5 15 12-10 4-19-2-23-10-10 0-14-7-11-10z",
				fill: c
			}),
			/* @__PURE__ */ v("path", {
				d: "M18 51 7 68q-3 7 4 9c5 0 8-4 10-10l7-10",
				fill: "#78432b"
			}),
			/* @__PURE__ */ v("path", {
				d: "m10 66 7 4m-4-9 7 4m-4-9 7 4",
				stroke: "#b97c43",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ v("circle", {
				cx: "10",
				cy: "75",
				r: "4",
				fill: c
			}),
			/* @__PURE__ */ v("path", {
				d: "M15 45q-4 5 6 9m13 4q7 2 7 6",
				stroke: "#ffe397",
				fill: "none"
			}),
			/* @__PURE__ */ v("path", {
				d: "M50 19c-11 0-21 12-16 18-1-13 9-12 16-18m24 14c4 10-1 20-11 25 5-1 16 0 17-10m-54-9c-10-8-8-19-2-24-2 8 4 9 2 24",
				stroke: "#e87b32",
				fill: "none",
				opacity: ".75"
			})
		]
	}) : e === "beth" ? /* @__PURE__ */ y("g", {
		stroke: "#443929",
		strokeWidth: "1",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ v("path", {
				d: "m32 28 25-5 9 42-29 6-10-10z",
				fill: l
			}),
			/* @__PURE__ */ v("path", {
				d: "m40 28 8 0 7 38-9 2z",
				fill: "#b58b53"
			}),
			/* @__PURE__ */ v("path", {
				d: "m27 61 38-4 9 14-31 9-23-6z",
				fill: l
			}),
			/* @__PURE__ */ v("path", {
				d: "m28 64 13 8 26-6m-28 4-5 5m18-4-3 5",
				fill: "none",
				stroke: "#d9ac6b"
			}),
			/* @__PURE__ */ v("circle", {
				cx: "31",
				cy: "68",
				r: "9",
				fill: "#494a3d",
				stroke: "#332e25",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ v("circle", {
				cx: "31",
				cy: "68",
				r: "5.5",
				fill: l
			}),
			/* @__PURE__ */ v("circle", {
				cx: "31",
				cy: "68",
				r: "2",
				fill: u
			}),
			/* @__PURE__ */ v("circle", {
				cx: "63",
				cy: "68",
				r: "8",
				fill: "#494a3d",
				stroke: "#332e25",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ v("circle", {
				cx: "63",
				cy: "68",
				r: "4.5",
				fill: l
			}),
			/* @__PURE__ */ v("circle", {
				cx: "63",
				cy: "68",
				r: "1.8",
				fill: u
			}),
			/* @__PURE__ */ v("path", {
				d: "M24 30 64 18c13-1 16 17 4 20L29 49z",
				fill: u
			}),
			/* @__PURE__ */ v("path", {
				d: "m30 31 34-10m-34 23 34-9",
				stroke: "#d5c999",
				strokeWidth: "1.1"
			}),
			/* @__PURE__ */ v("path", {
				d: "m47 24 2 16m11-20 3 17",
				stroke: "#615f4b",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ v("ellipse", {
				cx: "25",
				cy: "39",
				rx: "16",
				ry: "17",
				fill: u,
				stroke: "#4b493b",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ v("ellipse", {
				cx: "23",
				cy: "39",
				rx: "11.5",
				ry: "12.5",
				fill: "#645f48"
			}),
			/* @__PURE__ */ v("ellipse", {
				cx: "22",
				cy: "39",
				rx: "7",
				ry: "8.5",
				fill: "#272f2a"
			}),
			/* @__PURE__ */ v("path", {
				d: "M15 35q1-5 6-5m-6 16 5 3",
				stroke: "#d9cf9e",
				fill: "none",
				strokeWidth: "1.4"
			}),
			[
				[18, 26],
				[29, 28],
				[34, 39],
				[29, 50],
				[16, 50],
				[10, 40]
			].map(([e, t]) => /* @__PURE__ */ v("circle", {
				cx: e,
				cy: t,
				r: "1.8",
				fill: c
			}, e + ":" + t)),
			/* @__PURE__ */ v("path", {
				d: "M50 23v-7m-4-6c0-7 11-8 11-1 0 6-10 8-11 1z",
				fill: "none",
				stroke: c,
				strokeWidth: "2"
			}),
			/* @__PURE__ */ v("path", {
				d: "m49 45 2 14-7 4m21-24 5 14",
				fill: "none",
				stroke: "#4d3e2c",
				strokeWidth: "2"
			})
		]
	}) : e === "hold" ? /* @__PURE__ */ y("g", {
		stroke: "#51341f",
		strokeWidth: "1",
		children: [
			/* @__PURE__ */ v("path", {
				d: "m8 9 66-4 3 69-66 5z",
				fill: l
			}),
			/* @__PURE__ */ v("path", {
				d: "m16 16 52-3 2 53-53 4z",
				fill: "#754528"
			}),
			/* @__PURE__ */ v("path", {
				d: "m20 16 0 51m7-51-1 50m8-51 0 51m7-52 1 51m6-51 1 51m8-52 1 51m6-50 2 49",
				stroke: "#4c2e22",
				fill: "none"
			}),
			/* @__PURE__ */ v("path", {
				d: "m23 17 1 22m7 4 0 22m7-47 1 24m7 7 0 16m7-46 1 22m8 1 1 19m-42-10 0 7",
				stroke: "#bb8143",
				strokeWidth: ".8",
				fill: "none"
			}),
			/* @__PURE__ */ v("path", {
				d: "m8 9 66-4 1 9-60 4 3 49 57-4 1 11-65 5z",
				fill: f
			}),
			/* @__PURE__ */ v("path", {
				d: "m10 12 62-4m-58 9 2 52m0 5 56-7",
				fill: "none",
				stroke: "#f0c476",
				strokeWidth: "1.1"
			}),
			[
				[11, 12],
				[70, 8],
				[15, 72],
				[72, 68]
			].map(([e, t]) => /* @__PURE__ */ y("g", { children: [/* @__PURE__ */ v("circle", {
				cx: e,
				cy: t,
				r: "2",
				fill: u
			}), /* @__PURE__ */ v("path", {
				d: `m${e - 1} ${t} 2 0`,
				stroke: "#e8d3a1",
				strokeWidth: ".6"
			})] }, e + ":" + t)),
			/* @__PURE__ */ v("path", {
				d: "m20 69 4-14 7 12-4 8",
				fill: l
			})
		]
	}) : e === "rum" ? /* @__PURE__ */ y("g", {
		stroke: "#634022",
		strokeWidth: "1",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ v("path", {
				d: "M28 9h14l-1 15c0 7 8 10 10 17l-1 29c-9 6-24 6-34 0l-1-27c1-10 11-12 12-20z",
				fill: d
			}),
			/* @__PURE__ */ v("path", {
				d: "m29 11-1 14c0 9-8 12-9 18l1 22c2 4 5 5 9 5",
				fill: "none",
				stroke: "#f8d685",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ v("path", {
				d: "M28 4q7-3 15 0l0 10q-9 4-16-1z",
				fill: l
			}),
			/* @__PURE__ */ v("path", {
				d: "m28 7 14 0m-14 4 13 1m-13 5 13 0m-14 5 13 0",
				stroke: "#bd8b43",
				fill: "none",
				strokeWidth: "1.8"
			}),
			/* @__PURE__ */ v("path", {
				d: "M17 44q15 7 32 0v17q-17 6-31-1z",
				fill: c
			}),
			/* @__PURE__ */ v("ellipse", {
				cx: "30",
				cy: "54",
				rx: "10",
				ry: "13",
				fill: "#dfb65b"
			}),
			/* @__PURE__ */ v("path", {
				d: "m23 48 5 12m1-12-6 12m8-12 4 12m1-12-5 12",
				stroke: "#8f572b",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ v("path", {
				d: "M54 51c21-3 22 17 20 23-4 10-20 9-24 1l0-17z",
				fill: l
			}),
			/* @__PURE__ */ v("path", {
				d: "M72 56c12-5 15 8 7 13l-5 0m1-9c6-2 6 4 2 6",
				fill: "none",
				stroke: "#a16c35",
				strokeWidth: "2.2"
			}),
			/* @__PURE__ */ v("ellipse", {
				cx: "61",
				cy: "54",
				rx: "11",
				ry: "5",
				fill: c
			}),
			/* @__PURE__ */ v("ellipse", {
				cx: "61",
				cy: "54",
				rx: "8",
				ry: "3",
				fill: "#48301f"
			}),
			/* @__PURE__ */ v("path", {
				d: "M53 62v10q1 5 5 5",
				stroke: "#d09a53",
				strokeWidth: "2",
				fill: "none"
			}),
			/* @__PURE__ */ v("path", {
				d: "m66 66 0 9",
				stroke: "#4e321f",
				fill: "none"
			})
		]
	}) : e === "anchor" ? /* @__PURE__ */ y("g", {
		stroke: "#324549",
		strokeWidth: "1",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ v("path", {
				d: "M35 23c-10-3-14-17-4-22 10-6 22 3 18 12l-6 9 3 26c7-3 12-7 16-15l-8-2 16-15 6 22-7-3c-2 18-9 31-26 38l-3 7-5-6C17 66 10 53 7 39L1 42l3-24 18 12-7 3c5 10 9 14 20 17z",
				fill: u
			}),
			/* @__PURE__ */ v("path", {
				d: "M35 17c-6-1-9-9-3-12 6-3 13 2 9 8z",
				fill: "#31596a"
			}),
			/* @__PURE__ */ v("path", {
				d: "m35 25 5 42m-1-42 4 26m-31-12c5 18 12 25 23 29m9-1c13-5 21-18 23-32",
				fill: "none",
				stroke: "#a9c5c5",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ v("path", {
				d: "m20 27 37-5 1 7-37 6z",
				fill: u
			}),
			/* @__PURE__ */ v("path", {
				d: "m22 28 32-4",
				stroke: "#d4d4bb",
				fill: "none"
			}),
			[
				[17, 49],
				[29, 65],
				[52, 61],
				[64, 43]
			].map(([e, t]) => /* @__PURE__ */ v("circle", {
				cx: e,
				cy: t,
				r: "1.5",
				fill: "#b7c9bc"
			}, e)),
			/* @__PURE__ */ v("path", {
				d: "M48 5c18 6 28 0 29 12 1 12-18 7-11 17",
				fill: "none",
				stroke: "#78887a",
				strokeWidth: "2.3"
			}),
			/* @__PURE__ */ v("path", {
				d: "M48 5c18 6 28 0 29 12",
				fill: "none",
				stroke: "#d0cfae",
				strokeWidth: ".6"
			})
		]
	}) : /* @__PURE__ */ y("g", {
		stroke: "#855b24",
		strokeWidth: ".9",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ v("path", {
				d: "M18 14 65 49C58 65 42 74 17 74z",
				fill: c
			}),
			/* @__PURE__ */ v("path", {
				d: "M23 26 55 50C49 59 37 65 23 65z",
				fill: "#cdb987"
			}),
			/* @__PURE__ */ v("path", {
				d: "M18 14v60q31 0 47-25l-6-4C47 63 33 68 23 67V19z",
				fill: c
			}),
			/* @__PURE__ */ v("path", {
				d: "M22 71q25-3 39-22M19 19v48",
				fill: "none",
				stroke: "#fff0a1"
			}),
			Array.from({ length: 10 }, (e, t) => /* @__PURE__ */ v("path", {
				d: "M20 71v-4",
				transform: `rotate(${-t * 6} 18 14)`,
				stroke: "#936326",
				strokeWidth: ".8"
			}, t)),
			/* @__PURE__ */ v("path", {
				d: "m16 17 34 47 5-4-34-47z",
				fill: c
			}),
			/* @__PURE__ */ v("path", {
				d: "m20 19 30 40",
				stroke: "#fff3ac",
				fill: "none"
			}),
			/* @__PURE__ */ v("circle", {
				cx: "19",
				cy: "15",
				r: "7",
				fill: c
			}),
			/* @__PURE__ */ v("circle", {
				cx: "19",
				cy: "15",
				r: "3",
				fill: "#6d5b32"
			}),
			/* @__PURE__ */ v("path", {
				d: "m45 23 0 23 6 0 0-23",
				fill: c
			}),
			/* @__PURE__ */ v("path", {
				d: "m39 21 21 0 0 7-21 0z",
				fill: c
			}),
			/* @__PURE__ */ v("path", {
				d: "m53 23 0 4m-9-4 0 4",
				stroke: "#8b6829"
			}),
			/* @__PURE__ */ v("path", {
				d: "m14 42 17-4 1 6-17 5z",
				fill: c
			}),
			/* @__PURE__ */ v("circle", {
				cx: "28",
				cy: "42",
				r: "4",
				fill: c
			}),
			/* @__PURE__ */ v("path", {
				d: "M18 12q8-5 14 2",
				fill: "none",
				stroke: "#e9cd6f"
			}),
			/* @__PURE__ */ v("path", {
				d: "m18 74 0 6m40-20 5 5",
				stroke: c,
				strokeWidth: "3"
			})
		]
	}), /* @__PURE__ */ y("svg", {
		viewBox: "0 0 84 84",
		"aria-hidden": "true",
		className: "jamaica-treasure-art",
		children: [
			/* @__PURE__ */ y("defs", { children: [
				/* @__PURE__ */ y("linearGradient", {
					id: `${i}g`,
					x1: ".2",
					x2: ".8",
					y2: "1",
					children: [
						/* @__PURE__ */ v("stop", { stopColor: "#fff0a0" }),
						/* @__PURE__ */ v("stop", {
							offset: ".4",
							stopColor: "#d9a332"
						}),
						/* @__PURE__ */ v("stop", {
							offset: ".65",
							stopColor: "#f3cf6b"
						}),
						/* @__PURE__ */ v("stop", {
							offset: "1",
							stopColor: "#956126"
						})
					]
				}),
				/* @__PURE__ */ y("linearGradient", {
					id: `${i}w`,
					x2: ".8",
					y2: ".4",
					children: [
						/* @__PURE__ */ v("stop", { stopColor: "#d28b43" }),
						/* @__PURE__ */ v("stop", {
							offset: ".3",
							stopColor: "#a6582a"
						}),
						/* @__PURE__ */ v("stop", {
							offset: ".7",
							stopColor: "#7f3f25"
						}),
						/* @__PURE__ */ v("stop", {
							offset: "1",
							stopColor: "#bd7437"
						})
					]
				}),
				/* @__PURE__ */ y("linearGradient", {
					id: `${i}s`,
					x1: ".1",
					x2: ".9",
					y2: ".8",
					children: [
						/* @__PURE__ */ v("stop", { stopColor: "#d8d0a7" }),
						/* @__PURE__ */ v("stop", {
							offset: ".25",
							stopColor: "#939b88"
						}),
						/* @__PURE__ */ v("stop", {
							offset: ".5",
							stopColor: "#536565"
						}),
						/* @__PURE__ */ v("stop", {
							offset: ".8",
							stopColor: "#3b4d4f"
						}),
						/* @__PURE__ */ v("stop", {
							offset: "1",
							stopColor: "#8f9d8f"
						})
					]
				}),
				/* @__PURE__ */ y("linearGradient", {
					id: `${i}a`,
					x1: ".1",
					x2: "1",
					y2: ".4",
					children: [
						/* @__PURE__ */ v("stop", { stopColor: "#f6d16a" }),
						/* @__PURE__ */ v("stop", {
							offset: ".22",
							stopColor: "#bd721f"
						}),
						/* @__PURE__ */ v("stop", {
							offset: ".48",
							stopColor: "#f4b53a"
						}),
						/* @__PURE__ */ v("stop", {
							offset: ".7",
							stopColor: "#96501c"
						}),
						/* @__PURE__ */ v("stop", {
							offset: "1",
							stopColor: "#d78b21"
						})
					]
				}),
				/* @__PURE__ */ y("linearGradient", {
					id: `${i}p`,
					x2: ".5",
					y2: "1",
					children: [
						/* @__PURE__ */ v("stop", { stopColor: "#e4b86e" }),
						/* @__PURE__ */ v("stop", {
							offset: ".2",
							stopColor: "#b27937"
						}),
						/* @__PURE__ */ v("stop", {
							offset: ".5",
							stopColor: "#d5a858"
						}),
						/* @__PURE__ */ v("stop", {
							offset: ".8",
							stopColor: "#c18c46"
						}),
						/* @__PURE__ */ v("stop", {
							offset: "1",
							stopColor: "#ebc37d"
						})
					]
				}),
				/* @__PURE__ */ y("radialGradient", {
					id: `${i}cloth`,
					cx: ".32",
					cy: ".26",
					r: ".8",
					children: [
						/* @__PURE__ */ v("stop", { stopColor: "#fff0b1" }),
						/* @__PURE__ */ v("stop", {
							offset: ".35",
							stopColor: "#e8c17d"
						}),
						/* @__PURE__ */ v("stop", {
							offset: ".7",
							stopColor: "#bf8a49"
						}),
						/* @__PURE__ */ v("stop", {
							offset: "1",
							stopColor: "#8c6037"
						})
					]
				}),
				/* @__PURE__ */ y("radialGradient", {
					id: `${i}blackcloth`,
					cx: ".3",
					cy: ".22",
					r: ".9",
					children: [
						/* @__PURE__ */ v("stop", { stopColor: "#71746b" }),
						/* @__PURE__ */ v("stop", {
							offset: ".45",
							stopColor: "#434b43"
						}),
						/* @__PURE__ */ v("stop", {
							offset: ".8",
							stopColor: "#252e2d"
						}),
						/* @__PURE__ */ v("stop", {
							offset: "1",
							stopColor: "#101e21"
						})
					]
				}),
				/* @__PURE__ */ y("linearGradient", {
					id: `${i}blade`,
					x2: ".9",
					y2: ".7",
					children: [
						/* @__PURE__ */ v("stop", { stopColor: "#fff2ad" }),
						/* @__PURE__ */ v("stop", {
							offset: ".3",
							stopColor: "#e58936"
						}),
						/* @__PURE__ */ v("stop", {
							offset: ".55",
							stopColor: "#ffc564"
						}),
						/* @__PURE__ */ v("stop", {
							offset: "1",
							stopColor: "#a63924"
						})
					]
				})
			] }),
			/* @__PURE__ */ v("ellipse", {
				cx: "42",
				cy: "78",
				rx: "31",
				ry: "4",
				fill: "#3a2525",
				opacity: ".18"
			}),
			p
		]
	});
}
//#endregion
//#region src/games/jamaica/board.tsx
function tt({ rounded: e = 8 }) {
	let t = ae();
	return /* @__PURE__ */ v("svg", {
		className: "jamaica-target",
		"aria-hidden": "true",
		width: "100%",
		height: "100%",
		children: /* @__PURE__ */ v("rect", {
			x: "2",
			y: "2",
			width: "calc(100% - 4px)",
			height: "calc(100% - 4px)",
			rx: e,
			fill: "none",
			stroke: "#fff7cd",
			strokeWidth: "3",
			strokeDasharray: "8 5",
			children: !t && /* @__PURE__ */ v("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-26",
				dur: "1s",
				repeatCount: "indefinite"
			})
		})
	});
}
function nt({ x: e, y: t, scale: n = 1 }) {
	return /* @__PURE__ */ y("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		stroke: "#435632",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ v("path", {
				d: "M0 8Q11-13 7-38l6-1Q18-10 7 10z",
				fill: "#a77c40",
				stroke: "#6f542d",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ v("path", {
				d: "m8-31 4 3m-4 5 3 3m-7 5 4 3m-7 5 4 3",
				stroke: "#705330"
			}),
			/* @__PURE__ */ v("path", {
				d: "M9-38Q-9-59-26-42-11-46 3-34Q-22-38-29-16-14-29 6-32Q-5-14 2-5q0-16 12-27Q39-27 39-13q7-19-20-24 24-4 27 4-7-21-30-9 3-19 14-18-21-6-21 22",
				fill: "#668849",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ v("path", {
				d: "M9-38-17-42m26 4L-21-22m30-16 24 19m-24-19 27 1",
				fill: "none",
				stroke: "#9baf5d",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ v("circle", {
				cx: "11",
				cy: "-33",
				r: "4",
				fill: "#9d683b"
			})
		]
	});
}
function Y({ x: e, y: t, scale: n = 1 }) {
	let i = r().replaceAll(":", "");
	return /* @__PURE__ */ y("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		stroke: "#64442c",
		strokeLinejoin: "round",
		strokeWidth: ".8",
		children: [
			/* @__PURE__ */ y("defs", { children: [/* @__PURE__ */ y("linearGradient", {
				id: `${i}wall`,
				x2: ".9",
				y2: ".7",
				children: [/* @__PURE__ */ v("stop", { stopColor: "#ead59d" }), /* @__PURE__ */ v("stop", {
					offset: "1",
					stopColor: "#aa864d"
				})]
			}), /* @__PURE__ */ y("linearGradient", {
				id: `${i}roof`,
				x2: "0",
				y2: "1",
				children: [/* @__PURE__ */ v("stop", { stopColor: "#cc7950" }), /* @__PURE__ */ v("stop", {
					offset: "1",
					stopColor: "#8e432e"
				})]
			})] }),
			/* @__PURE__ */ v("path", {
				d: "M-47 21q-4-17 7-30l20-11 30 1 32 16 9 24-18 16-47 0z",
				fill: "#b79e62",
				stroke: "#deca90",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ v("path", {
				d: "m-41 11 8-8 67 6 5 14-17 6-49-4-14-6z",
				fill: "#9d8351"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-41 12h76v15h-76z",
				fill: `url(#${i}wall)`
			}),
			/* @__PURE__ */ v("path", {
				d: "m35 12 8-7v16l-8 6z",
				fill: "#937343"
			}),
			/* @__PURE__ */ v("path", {
				d: "m-44 10 0-6 8 0 0 5 7 0 0-5 8 0 0 5 7 0 0-5 8 0 0 5 7 0 0-5 8 0 0 5 7 0 0-5 8 0 0 5 10 0 0-5 8 0 0 6z",
				fill: "#c5ae77"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-32-9v22h24v-26l-13-9z",
				fill: `url(#${i}wall)`
			}),
			/* @__PURE__ */ v("path", {
				d: "m-8-13 10 8v18H-8z",
				fill: "#ac8a51"
			}),
			/* @__PURE__ */ v("path", {
				d: "m-36-11 15-15 19 13 7 1-11-13-15-7-18 17z",
				fill: `url(#${i}roof)`
			}),
			/* @__PURE__ */ v("path", {
				d: "m-20-28 15 15-28-1",
				stroke: "#e6a16a",
				fill: "none"
			}),
			/* @__PURE__ */ v("path", {
				d: "M2-2v19h23V-5L13-14z",
				fill: `url(#${i}wall)`
			}),
			/* @__PURE__ */ v("path", {
				d: "m25-5 11 7v15H25z",
				fill: "#aa8249"
			}),
			/* @__PURE__ */ v("path", {
				d: "m-2-5 15-14 24 17-12 0-12-12-11 11z",
				fill: `url(#${i}roof)`
			}),
			/* @__PURE__ */ v("path", {
				d: "M-8-20v27h21v-31L2-32z",
				fill: `url(#${i}wall)`
			}),
			/* @__PURE__ */ v("path", {
				d: "m13-24 9 6V7h-9z",
				fill: "#ae8950"
			}),
			/* @__PURE__ */ v("path", {
				d: "m-12-23 14-14 23 17-12-2L2-32-8-21z",
				fill: `url(#${i}roof)`
			}),
			/* @__PURE__ */ v("path", {
				d: "M-35-3v9m11-18v8m14-4v10m15-23v8m12 5v8m14-3v7",
				stroke: "#674d2e",
				strokeWidth: "2.8"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-23 16c0-7 9-7 9 0v11h-9zm29 1c0-7 9-7 9 0v11H6z",
				fill: "#5f4c32"
			}),
			/* @__PURE__ */ v("path", {
				d: "m-20 17 0 10m30-10 0 10",
				stroke: "#b18a4d",
				fill: "none"
			}),
			/* @__PURE__ */ v("path", {
				d: "m-39 17 7 0m5 6 9 0m18-6 7 0m13 6 7 0m-48-32 4 0m-10 10 6 0m21-23 6 0m-1 11 5 0m4 16 5 0",
				stroke: "#a98c55"
			}),
			/* @__PURE__ */ v("path", {
				d: "m-33-18 13-1m3-3 4 2m8-7 10 0m9 17 10 3m-23-21 6 4",
				stroke: "#83472e",
				fill: "none"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-46 24v19h9V25m64-1v21h9V24",
				fill: "#9b763f"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-45 37h80m-80 5h80m-75-12 69 0",
				stroke: "#654a2d",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ v("path", {
				d: "m-44 34 78 0m-73-7 68 0",
				stroke: "#d3b473"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-4-34v-21",
				stroke: "#78603b",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-4-55q10 0 18 5l-18 6z",
				fill: "#ac4932"
			}),
			/* @__PURE__ */ v("path", {
				d: "m0-53 0 6",
				stroke: "#e6b874"
			}),
			/* @__PURE__ */ v("path", {
				d: "m-39-5-5-9m5 8-9-1m10-1 2-11",
				fill: "none",
				stroke: "#657144",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-47-15q9-8 12 0m-12 0 6 2m-1-10 5 6",
				fill: "none",
				stroke: "#7c8b48",
				strokeWidth: "3"
			})
		]
	});
}
function X({ x: e, y: t, rotate: n = 0 }) {
	let i = r().replaceAll(":", "");
	return /* @__PURE__ */ y("g", {
		transform: `translate(${e} ${t}) rotate(${n})`,
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ v("defs", { children: /* @__PURE__ */ y("linearGradient", {
				id: `${i}rock`,
				x1: ".1",
				x2: ".9",
				y2: ".85",
				children: [
					/* @__PURE__ */ v("stop", { stopColor: "#d5bd7b" }),
					/* @__PURE__ */ v("stop", {
						offset: ".4",
						stopColor: "#a28c50"
					}),
					/* @__PURE__ */ v("stop", {
						offset: ".73",
						stopColor: "#766e42"
					}),
					/* @__PURE__ */ v("stop", {
						offset: "1",
						stopColor: "#4d5438"
					})
				]
			}) }),
			/* @__PURE__ */ v("path", {
				d: "M-44 20c-5-9 3-17 5-27l9-17 11 1 9-12 14 3 8-5 14 11 10 3 7 19-2 19-12 15-23 5-18-4-21 0-8-11z",
				fill: "#cbb77b",
				stroke: "#ddca95",
				strokeWidth: "6"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-36 3c-2-15 3-25 17-28 7-5 20-7 31-2 11 4 18 13 19 23l-7 12 0 12-13 11-20-2-8-12-15-5z",
				fill: `url(#${i}rock)`,
				stroke: "#685e3c",
				strokeWidth: "1.3"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-28-7q8-8 17 0l2 10-14 3-6-4zm34-5q9-7 16 0l-3 12-12 2-4-7z",
				fill: "#3d3c2d"
			}),
			/* @__PURE__ */ v("path", {
				d: "m-22-1 8 2m22-6 9-3",
				stroke: "#be4630",
				strokeWidth: "2.8"
			}),
			/* @__PURE__ */ v("path", {
				d: "m-3 4-6 11 12 0-2-12m-14 22 21 2m-21-7 0 9m7-7 0 9m7-8-1 8m7-10-2 7",
				fill: "#534d33",
				stroke: "#d2bd7f",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-29-10q-3-11 10-14m21-4 10 5m-42 24 9 6-1 8m42-22-3 12-7 8m-35-20-3 10m41-12 4 10m-22-30-4 7-1 7",
				stroke: "#e0c88d",
				strokeWidth: "1.2",
				fill: "none"
			}),
			/* @__PURE__ */ v("path", {
				d: "m-30 11 4 11m5-4 4 8m28-4 8-9m-12-35 7 5",
				stroke: "#76663d",
				fill: "none"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-24-25q14-16 32-6l-8 6-17 3z",
				fill: "#7f864b",
				stroke: "none"
			}),
			/* @__PURE__ */ v(nt, {
				x: 30,
				y: 5,
				scale: .42
			})
		]
	});
}
function rt({ x: e, y: t, scale: n = 1 }) {
	let i = r().replaceAll(":", "");
	return /* @__PURE__ */ y("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ v("defs", { children: /* @__PURE__ */ y("linearGradient", {
				id: `${i}mount`,
				x1: ".1",
				x2: ".9",
				y2: ".8",
				children: [
					/* @__PURE__ */ v("stop", { stopColor: "#cab989" }),
					/* @__PURE__ */ v("stop", {
						offset: ".35",
						stopColor: "#9d9566"
					}),
					/* @__PURE__ */ v("stop", {
						offset: ".7",
						stopColor: "#72774f"
					}),
					/* @__PURE__ */ v("stop", {
						offset: "1",
						stopColor: "#566444"
					})
				]
			}) }),
			/* @__PURE__ */ v("path", {
				d: "M-69 39c9-12 15-26 25-40l13-19 10-25 14 15 9 20 10-11 13-31 11-8 17 26 8 16 9 20 17 11 9 27-41 12-38-4-41 5z",
				fill: `url(#${i}mount)`,
				stroke: "#63704d",
				strokeWidth: "1.3"
			}),
			/* @__PURE__ */ v("path", {
				d: "m-48 7 17-27 10-25-3 34-14 19 1 19-16 12zm36 13L2-10l10-11 13-31 11-8-9 31-2 20-10 20-4 22zm48 15 3-30-8-22 5-26 16 28-2 22 14 20 13 10z",
				fill: "#5d6846",
				stroke: "none",
				opacity: ".55"
			}),
			/* @__PURE__ */ v("path", {
				d: "m-31-20 10-25 14 15-11-5-2 18-11 15m44-20 12-30 11-8 13 20-12-8-5 13-8 4-2 13m16 24 12 8 8 19",
				fill: "none",
				stroke: "#d0c393",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ v("path", {
				d: "M-54 28q11-4 19-11m7-7-9 19m22-23-4 17m19-19 8 14m8 10 7 9m19-18 11 7m-4-10 13 12m-34-62 4 13m-46-17 5 13",
				fill: "none",
				stroke: "#8a8a5b",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ v("path", {
				d: "m-59 42 18-5 15 4 16-4 17 4 17-3 25 3 20-5",
				fill: "none",
				stroke: "#b0a16a",
				strokeWidth: "2"
			})
		]
	});
}
function it() {
	let e = r().replaceAll(":", "");
	return /* @__PURE__ */ y("svg", {
		viewBox: "0 0 1000 700",
		className: "jamaica-sea-art",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ y("defs", { children: [
				/* @__PURE__ */ y("linearGradient", {
					id: `${e}sea`,
					x2: ".4",
					y2: "1",
					children: [
						/* @__PURE__ */ v("stop", { stopColor: "#347f9c" }),
						/* @__PURE__ */ v("stop", {
							offset: ".55",
							stopColor: "#5caaaa"
						}),
						/* @__PURE__ */ v("stop", {
							offset: "1",
							stopColor: "#2a748f"
						})
					]
				}),
				/* @__PURE__ */ y("linearGradient", {
					id: `${e}land`,
					x2: "0",
					y2: "1",
					children: [
						/* @__PURE__ */ v("stop", { stopColor: "#adad62" }),
						/* @__PURE__ */ v("stop", {
							offset: ".55",
							stopColor: "#75834b"
						}),
						/* @__PURE__ */ v("stop", {
							offset: "1",
							stopColor: "#9c934f"
						})
					]
				}),
				/* @__PURE__ */ v("pattern", {
					id: `${e}waves`,
					width: "100",
					height: "68",
					patternUnits: "userSpaceOnUse",
					children: /* @__PURE__ */ v("path", {
						d: "M7 33q8 5 16 0m33 26q9 5 19-1M80 13l9 1",
						stroke: "#e2f2db",
						fill: "none",
						opacity: ".18",
						strokeWidth: "2"
					})
				})
			] }),
			/* @__PURE__ */ v("rect", {
				width: "1000",
				height: "700",
				fill: `url(#${e}sea)`
			}),
			/* @__PURE__ */ v("rect", {
				width: "1000",
				height: "700",
				fill: `url(#${e}waves)`
			}),
			/* @__PURE__ */ v("path", {
				d: "M131 283q38-59 121-66l81-18 47-33 71-14 50-23 89 8 38-48 57-12 89 22 64 40-6 42-52 19-8 47 13 40-27 39 25 52-26 43-54 24-28 40-61 8-15 51-64 12-58-13-35 17-73-19-43 7-39-43-61-8-6-47-35-19 11-49-21-28z",
				fill: "#71b8ad",
				stroke: "#86c8b6",
				strokeWidth: "38"
			}),
			/* @__PURE__ */ v("path", {
				d: "M131 283q38-59 121-66l81-18 47-33 71-14 50-23 89 8 38-48 57-12 89 22 64 40-6 42-52 19-8 47 13 40-27 39 25 52-26 43-54 24-28 40-61 8-15 51-64 12-58-13-35 17-73-19-43 7-39-43-61-8-6-47-35-19 11-49-21-28z",
				fill: `url(#${e}land)`,
				stroke: "#e2ca8c",
				strokeWidth: "17"
			}),
			/* @__PURE__ */ v(rt, {
				x: 337,
				y: 252
			}),
			/* @__PURE__ */ v(rt, {
				x: 506,
				y: 215,
				scale: 1.12
			}),
			/* @__PURE__ */ v(rt, {
				x: 614,
				y: 398,
				scale: .95
			}),
			/* @__PURE__ */ v("path", {
				d: "M391 238q28 38 12 85t31 60q26 24 9 70",
				fill: "none",
				stroke: "#729d8b",
				strokeWidth: "12"
			}),
			/* @__PURE__ */ v("path", {
				d: "M391 238q28 38 12 85t31 60q26 24 9 70",
				fill: "none",
				stroke: "#bfd2a1",
				strokeWidth: "3"
			}),
			[
				[
					200,
					285,
					.8
				],
				[
					260,
					360,
					.8
				],
				[
					343,
					342,
					.8
				],
				[
					500,
					303,
					.95
				],
				[
					565,
					270,
					.8
				],
				[
					644,
					285,
					.8
				],
				[
					724,
					353,
					.9
				],
				[
					493,
					430,
					.7
				],
				[
					299,
					414,
					.6
				],
				[
					627,
					464,
					.5
				],
				[
					739,
					188,
					.6
				]
			].map(([e, t, n], r) => /* @__PURE__ */ v(nt, {
				x: e,
				y: t,
				scale: n
			}, r)),
			/* @__PURE__ */ v(Y, {
				x: 710,
				y: 117,
				scale: 1.4
			}),
			/* @__PURE__ */ v(Y, {
				x: 825,
				y: 404,
				scale: .72
			}),
			/* @__PURE__ */ v(Y, {
				x: 580,
				y: 503,
				scale: .7
			}),
			/* @__PURE__ */ v(Y, {
				x: 445,
				y: 492,
				scale: .67
			}),
			/* @__PURE__ */ v(Y, {
				x: 207,
				y: 461,
				scale: .73
			}),
			/* @__PURE__ */ v(Y, {
				x: 176,
				y: 353,
				scale: .6
			}),
			/* @__PURE__ */ v(Y, {
				x: 214,
				y: 264,
				scale: .65
			}),
			/* @__PURE__ */ v(Y, {
				x: 366,
				y: 189,
				scale: .65
			}),
			/* @__PURE__ */ v(X, {
				x: 916,
				y: 467,
				rotate: -15
			}),
			/* @__PURE__ */ v(X, {
				x: 864,
				y: 645,
				rotate: -20
			}),
			/* @__PURE__ */ v(X, {
				x: 765,
				y: 600,
				rotate: -10
			}),
			/* @__PURE__ */ v(X, {
				x: 525,
				y: 656
			}),
			/* @__PURE__ */ v(X, {
				x: 192,
				y: 591,
				rotate: 10
			}),
			/* @__PURE__ */ v(X, {
				x: 37,
				y: 558
			}),
			/* @__PURE__ */ v(X, {
				x: 72,
				y: 151
			}),
			/* @__PURE__ */ v(X, {
				x: 271,
				y: 51,
				rotate: -15
			}),
			/* @__PURE__ */ y("g", {
				transform: "translate(510 363) rotate(-7)",
				fill: "#f6e5af",
				stroke: "#685632",
				strokeWidth: "2",
				children: [
					/* @__PURE__ */ v("path", {
						d: "M-117-29q26-10 43-2l148 1q19-10 39-1l-5 57q-21 9-42 1l-141-1q-21 10-42 0z",
						fill: "#b5a164"
					}),
					/* @__PURE__ */ v("path", {
						d: "M-115-29q-15 17 3 17m222-19q16 18-4 20",
						fill: "none"
					}),
					/* @__PURE__ */ v("text", {
						x: "0",
						y: "9",
						fontFamily: "Georgia,serif",
						fontSize: "34",
						fontWeight: "800",
						textAnchor: "middle",
						stroke: "none",
						fill: "#4b4930",
						children: "JAMAICA"
					})
				]
			}),
			/* @__PURE__ */ y("g", {
				transform: "translate(82 360)",
				stroke: "#f1e3ad",
				opacity: ".8",
				children: [
					/* @__PURE__ */ v("circle", {
						r: "30",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "m0-44 9 35 35 9-35 9-9 35-9-35-35-9 35-9z",
						fill: "#f1e3ad"
					}),
					/* @__PURE__ */ v("path", {
						d: "m0-44 9 35L0 0l-9 9zM0 0l44 0-35 9zM0 0l0 44-9-35z",
						fill: "#4c746c"
					}),
					/* @__PURE__ */ v("text", {
						y: "-49",
						textAnchor: "middle",
						stroke: "none",
						fill: "#f1e3ad",
						fontFamily: "serif",
						fontSize: "13",
						children: "N"
					})
				]
			}),
			/* @__PURE__ */ v("rect", {
				x: "4",
				y: "4",
				width: "992",
				height: "692",
				rx: "10",
				fill: "none",
				stroke: "#674a2e",
				strokeWidth: "8"
			}),
			/* @__PURE__ */ v("rect", {
				x: "10",
				y: "10",
				width: "980",
				height: "680",
				rx: "7",
				fill: "none",
				stroke: "#d9bd78",
				strokeWidth: "4"
			})
		]
	});
}
function at({ index: e, token: t, choices: n, choose: r }) {
	let i = l(), a = k[e], { ref: o } = s(`node:${e}`), c = n.find((t) => t.node === e && t.kind === "space");
	if (e === 0) return /* @__PURE__ */ v("div", {
		ref: o,
		className: "jamaica-node jamaica-node-origin",
		style: {
			left: `${a.x}%`,
			top: `${a.y}%`
		},
		"aria-hidden": !0
	});
	let u = /* @__PURE__ */ y(_, { children: [a.kind === "royal" ? /* @__PURE__ */ v("span", {
		className: "jamaica-port-flag",
		children: "15"
	}) : a.kind === "lair" ? t ? /* @__PURE__ */ v(q, {
		kind: "lair",
		size: 26
	}) : /* @__PURE__ */ v("span", {
		className: "jamaica-lair-empty",
		children: "×"
	}) : /* @__PURE__ */ v(_, { children: /* @__PURE__ */ y("span", {
		className: a.kind === "gold" ? "jamaica-fee-gold" : "jamaica-fee-food",
		children: [a.kind === "gold" ? /* @__PURE__ */ v(q, {
			kind: "gold",
			size: 17
		}) : /* @__PURE__ */ v("span", {
			"aria-hidden": !0,
			children: "◆"
		}), a.cost]
	}) }), a.score > 0 && e !== 32 && /* @__PURE__ */ v("small", {
		className: "jamaica-map-points",
		children: a.score
	})] });
	return /* @__PURE__ */ v("div", {
		className: `jamaica-node${c ? " jamaica-node-legal" : ""}`,
		ref: o,
		style: {
			left: `${a.x}%`,
			top: `${a.y}%`
		},
		children: c ? /* @__PURE__ */ y("button", {
			onClick: () => r(c.id),
			"aria-label": i("games.jamaica.space", {
				kind: i(a.kind === "lair" ? "games.jamaica.treasures" : a.kind === "gold" ? "games.jamaica.gold" : "games.jamaica.food"),
				n: a.cost
			}),
			children: [u, /* @__PURE__ */ v(tt, { rounded: 18 })]
		}) : /* @__PURE__ */ v("div", {
			className: "jamaica-node-face",
			children: u
		})
	});
}
function ot({ ship: e, index: t, offset: n, count: r, members: i, name: a }) {
	let { ref: o, hidden: c } = s(`ship:${e.rid}`), l = k[e.node], u = le(e.node, n, r), d = b[i.find((t) => t.rid === e.rid)?.colorIndex ?? 0]?.hex;
	return /* @__PURE__ */ y("div", {
		ref: o,
		className: "jamaica-map-ship",
		style: {
			left: `clamp(34px,calc(${l.x}% + ${u.x}px),calc(100% - 34px))`,
			top: `calc(clamp(32px,${l.y}%,calc(100% - ${u.rows - 1} * var(--jamaica-ship-step) - 48px)) + ${u.row} * var(--jamaica-ship-step))`,
			visibility: c ? "hidden" : void 0
		},
		title: a,
		children: [/* @__PURE__ */ v(et, {
			color: d,
			number: e.rid === "$ghost" ? void 0 : t + 1,
			ghost: e.rid === j
		}), /* @__PURE__ */ v("span", {
			style: { background: e.rid === "$ghost" ? "#4b656c" : d },
			children: a
		})]
	});
}
function st({ pub: e, members: t, choices: n = [], choose: r = () => {}, nameOf: o }) {
	let c = l(), [u, d] = a(1), [f, p] = a({
		x: 0,
		y: 0
	}), { ref: te } = s("map-unit"), { ref: ne } = s("map-bounds"), g = i(null);
	return /* @__PURE__ */ y("div", {
		className: "jamaica-chart",
		"aria-label": c("games.jamaica.chart"),
		children: [/* @__PURE__ */ v("div", {
			className: "jamaica-map-viewport",
			onPointerDown: (e) => {
				u <= 1 || e.target.closest("button") || (g.current = {
					x: e.clientX,
					y: e.clientY,
					px: f.x,
					py: f.y,
					id: e.pointerId
				}, e.currentTarget.setPointerCapture(e.pointerId));
			},
			onPointerMove: (e) => {
				let t = g.current;
				t && t.id === e.pointerId && p({
					x: Math.max(-500, Math.min(500, t.px + e.clientX - t.x)),
					y: Math.max(-400, Math.min(400, t.py + e.clientY - t.y))
				});
			},
			onPointerUp: () => {
				g.current = null;
			},
			onPointerCancel: () => {
				g.current = null;
			},
			style: { touchAction: u > 1 ? "none" : "pan-y" },
			children: /* @__PURE__ */ y("div", {
				ref: ne,
				className: "jamaica-map-canvas",
				style: { transform: `translate(${f.x}px,${f.y}px) scale(${u})` },
				children: [
					/* @__PURE__ */ v("span", {
						ref: te,
						className: "jamaica-map-unit",
						"aria-hidden": !0
					}),
					/* @__PURE__ */ v(it, {}),
					/* @__PURE__ */ y("svg", {
						className: "jamaica-routes",
						viewBox: "0 0 1000 700",
						"aria-hidden": "true",
						children: [
							k.flatMap((e, t) => e.next.map((n) => /* @__PURE__ */ v("path", {
								d: `M${e.x * 10} ${e.y * 7}L${k[n].x * 10} ${k[n].y * 7}`,
								fill: "none",
								stroke: "#d6ecce",
								strokeWidth: "2",
								strokeDasharray: "4 7",
								opacity: ".65"
							}, `${t}:${n}`))),
							/* @__PURE__ */ v("path", {
								d: "M348 0V132",
								stroke: "#a33e2e",
								strokeWidth: "3"
							}),
							/* @__PURE__ */ v("text", {
								x: "336",
								y: "40",
								textAnchor: "end",
								fill: "#f7e5b2",
								fontSize: "20",
								fontWeight: "800",
								children: "−5"
							})
						]
					}),
					k.map((t, i) => /* @__PURE__ */ v(at, {
						index: i,
						token: e.lairs.includes(i),
						choices: n,
						choose: r
					}, i)),
					e.ships.map((n, r) => {
						let i = (e) => e.node === n.node || e.node === 0 && n.node === 32 || e.node === 32 && n.node === 0;
						return /* @__PURE__ */ v(ot, {
							ship: n,
							index: r,
							offset: e.ships.slice(0, r).filter(i).length,
							count: e.ships.filter(i).length,
							members: t,
							name: o(n.rid)
						}, n.rid);
					}),
					/* @__PURE__ */ v("span", {
						className: "jamaica-royal-label",
						children: c("games.jamaica.royal")
					})
				]
			})
		}), /* @__PURE__ */ y("div", {
			className: "jamaica-map-tools",
			children: [
				/* @__PURE__ */ v("button", {
					"aria-label": c("games.jamaica.zoomIn"),
					onClick: () => d(Math.min(3, u + .5)),
					children: /* @__PURE__ */ v(h, { size: 18 })
				}),
				/* @__PURE__ */ v("button", {
					"aria-label": c("games.jamaica.zoomOut"),
					onClick: () => {
						d(Math.max(1, u - .5)), u <= 1.5 && p({
							x: 0,
							y: 0
						});
					},
					children: /* @__PURE__ */ v(ee, { size: 18 })
				}),
				/* @__PURE__ */ v("button", {
					"aria-label": c("games.jamaica.resetMap"),
					onClick: () => {
						d(1), p({
							x: 0,
							y: 0
						});
					},
					children: /* @__PURE__ */ v(m, { size: 18 })
				})
			]
		})]
	});
}
//#endregion
//#region src/games/jamaica/card.tsx
function ct({ card: e, selected: t = !1, selectable: n = !1, onClick: r, dice: i }) {
	let a = l(), o = w[e], s = /* @__PURE__ */ y(_, { children: [
		/* @__PURE__ */ y("span", {
			className: "jamaica-card-half jamaica-card-day",
			children: [
				/* @__PURE__ */ v("small", { children: a("games.jamaica.day") }),
				/* @__PURE__ */ v(q, {
					kind: o[0],
					size: 36
				}),
				i && /* @__PURE__ */ v("b", { children: i[0] })
			]
		}),
		/* @__PURE__ */ y("span", {
			className: "jamaica-card-half jamaica-card-night",
			children: [
				/* @__PURE__ */ v("small", { children: a("games.jamaica.night") }),
				/* @__PURE__ */ v(q, {
					kind: o[1],
					size: 36
				}),
				i && /* @__PURE__ */ v("b", { children: i[1] })
			]
		}),
		n && /* @__PURE__ */ v(tt, {})
	] }), c = a("games.jamaica.cardAria", {
		day: a(T[o[0]]),
		night: a(T[o[1]])
	});
	return r ? /* @__PURE__ */ v("button", {
		className: `jamaica-action-card${t ? " jamaica-card-selected" : ""}`,
		"aria-label": c,
		"aria-pressed": t,
		onClick: r,
		children: s
	}) : /* @__PURE__ */ v("div", {
		className: "jamaica-action-card",
		"aria-label": c,
		children: s
	});
}
//#endregion
//#region src/games/jamaica/crew-art.tsx
function Z({ crew: e }) {
	let t = r().replaceAll(":", ""), n = `url(#${t}s)`, i = `url(#${t}m)`, a = `url(#${t}g)`, o = `url(#${t}n)`, s = `url(#${t}w)`, c = `url(#${t}h)`, l = `url(#${t}hat)`, u = `url(#${t}l)`, d = `url(#${t}v)`, f = `url(#${t}a)`, p = `url(#${t}p)`;
	return /* @__PURE__ */ y("svg", {
		viewBox: "0 0 120 136",
		"aria-hidden": "true",
		className: "jamaica-crew-art",
		children: [/* @__PURE__ */ y("defs", { children: [
			/* @__PURE__ */ y("radialGradient", {
				id: `${t}s`,
				cx: ".34",
				cy: ".3",
				r: ".78",
				children: [
					/* @__PURE__ */ v("stop", { stopColor: "#f4dfb6" }),
					/* @__PURE__ */ v("stop", {
						offset: ".48",
						stopColor: "#dfb487"
					}),
					/* @__PURE__ */ v("stop", {
						offset: ".82",
						stopColor: "#bd855e"
					}),
					/* @__PURE__ */ v("stop", {
						offset: "1",
						stopColor: "#966548"
					})
				]
			}),
			/* @__PURE__ */ y("linearGradient", {
				id: `${t}m`,
				x2: ".8",
				y2: "1",
				children: [
					/* @__PURE__ */ v("stop", { stopColor: "#aaa899" }),
					/* @__PURE__ */ v("stop", {
						offset: ".4",
						stopColor: "#575c5b"
					}),
					/* @__PURE__ */ v("stop", {
						offset: "1",
						stopColor: "#272f32"
					})
				]
			}),
			/* @__PURE__ */ y("linearGradient", {
				id: `${t}g`,
				x2: ".7",
				y2: "1",
				children: [
					/* @__PURE__ */ v("stop", { stopColor: "#fff09a" }),
					/* @__PURE__ */ v("stop", {
						offset: ".5",
						stopColor: "#d6a22e"
					}),
					/* @__PURE__ */ v("stop", {
						offset: "1",
						stopColor: "#8f5c20"
					})
				]
			}),
			/* @__PURE__ */ y("radialGradient", {
				id: `${t}n`,
				cx: ".3",
				cy: ".26",
				r: ".76",
				children: [
					/* @__PURE__ */ v("stop", { stopColor: "#f0b78a" }),
					/* @__PURE__ */ v("stop", {
						offset: ".43",
						stopColor: "#c47b58"
					}),
					/* @__PURE__ */ v("stop", {
						offset: ".8",
						stopColor: "#a7543d"
					}),
					/* @__PURE__ */ v("stop", {
						offset: "1",
						stopColor: "#703e2e"
					})
				]
			}),
			/* @__PURE__ */ y("linearGradient", {
				id: `${t}w`,
				x1: ".15",
				x2: ".9",
				y2: ".55",
				children: [
					/* @__PURE__ */ v("stop", { stopColor: "#fff5d4" }),
					/* @__PURE__ */ v("stop", {
						offset: ".45",
						stopColor: "#e8d7ac"
					}),
					/* @__PURE__ */ v("stop", {
						offset: "1",
						stopColor: "#a89b7a"
					})
				]
			}),
			/* @__PURE__ */ y("linearGradient", {
				id: `${t}h`,
				x1: ".1",
				x2: ".9",
				y2: ".6",
				children: [
					/* @__PURE__ */ v("stop", { stopColor: "#1f221f" }),
					/* @__PURE__ */ v("stop", {
						offset: ".35",
						stopColor: "#494331"
					}),
					/* @__PURE__ */ v("stop", {
						offset: ".6",
						stopColor: "#292a24"
					}),
					/* @__PURE__ */ v("stop", {
						offset: "1",
						stopColor: "#131b1c"
					})
				]
			}),
			/* @__PURE__ */ y("linearGradient", {
				id: `${t}hat`,
				x1: ".1",
				x2: ".85",
				y2: ".9",
				children: [
					/* @__PURE__ */ v("stop", { stopColor: "#777982" }),
					/* @__PURE__ */ v("stop", {
						offset: ".3",
						stopColor: "#3e404c"
					}),
					/* @__PURE__ */ v("stop", {
						offset: ".65",
						stopColor: "#252832"
					}),
					/* @__PURE__ */ v("stop", {
						offset: "1",
						stopColor: "#131c23"
					})
				]
			}),
			/* @__PURE__ */ y("linearGradient", {
				id: `${t}l`,
				x1: ".1",
				x2: "1",
				y2: ".75",
				children: [
					/* @__PURE__ */ v("stop", { stopColor: "#b67d4b" }),
					/* @__PURE__ */ v("stop", {
						offset: ".5",
						stopColor: "#795236"
					}),
					/* @__PURE__ */ v("stop", {
						offset: "1",
						stopColor: "#46382b"
					})
				]
			}),
			/* @__PURE__ */ y("linearGradient", {
				id: `${t}v`,
				x1: ".12",
				x2: ".95",
				y2: ".6",
				children: [
					/* @__PURE__ */ v("stop", { stopColor: "#8c85bd" }),
					/* @__PURE__ */ v("stop", {
						offset: ".35",
						stopColor: "#46517e"
					}),
					/* @__PURE__ */ v("stop", {
						offset: ".68",
						stopColor: "#24304e"
					}),
					/* @__PURE__ */ v("stop", {
						offset: "1",
						stopColor: "#111f31"
					})
				]
			}),
			/* @__PURE__ */ y("radialGradient", {
				id: `${t}a`,
				cx: ".3",
				cy: ".26",
				r: ".8",
				children: [
					/* @__PURE__ */ v("stop", { stopColor: "#d4d9ca" }),
					/* @__PURE__ */ v("stop", {
						offset: ".5",
						stopColor: "#9caaa0"
					}),
					/* @__PURE__ */ v("stop", {
						offset: ".8",
						stopColor: "#5d7474"
					}),
					/* @__PURE__ */ v("stop", {
						offset: "1",
						stopColor: "#344e55"
					})
				]
			}),
			/* @__PURE__ */ y("radialGradient", {
				id: `${t}p`,
				cx: ".25",
				cy: ".25",
				r: ".85",
				children: [
					/* @__PURE__ */ v("stop", { stopColor: "#dfb4cb" }),
					/* @__PURE__ */ v("stop", {
						offset: ".5",
						stopColor: "#b886ad"
					}),
					/* @__PURE__ */ v("stop", {
						offset: ".8",
						stopColor: "#816387"
					}),
					/* @__PURE__ */ v("stop", {
						offset: "1",
						stopColor: "#504665"
					})
				]
			})
		] }), /* @__PURE__ */ y("g", {
			stroke: "#49312a",
			strokeWidth: ".8",
			strokeLinejoin: "round",
			strokeLinecap: "round",
			children: [
				e === "strategist" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "M12 136c1-23 8-39 27-42l39-3c17 3 29 19 31 45",
						fill: u
					}),
					/* @__PURE__ */ v("path", {
						d: "M25 98c6-8 15-10 24-8l13 19-16 27H23l10-22zm61-4 15 9-5 33H73l-9-27z",
						fill: "#d2c087"
					}),
					/* @__PURE__ */ v("path", {
						d: "m29 110 10 5-5 9m55-18-11 7 4 10",
						stroke: "#8b7548",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M26 46c-5-18 7-31 27-33 25-5 42 10 42 29l-5 32c-2 17-14 31-30 32-18 0-30-16-32-34z",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M74 28c15 11 18 33 7 48L67 94l-9 8 19-7c17-12 15-34 16-50z",
						fill: "#94603c",
						opacity: ".58",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M22 48C4 36 1 48 10 57c5 6 13 10 21 6m58-17c17-14 28-5 18 5-6 6-13 10-20 11",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M14 48c4-3 10 1 13 8l-9-4m78-2 8-3-6 7",
						stroke: "#9b714b",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M27 23c-9 2-14 11-14 19l-8-1 9-10-7 2c5-10 14-16 26-16l-7-3 15-3-8 10c-5 10-3 22-8 31l-6 5 3-14-5 3zM80 16c15 4 23 15 24 29l-7-2 2 10-10 7c-6-10-4-20-10-31z",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "M33 18c13-14 34-15 48-3l-7 13c-7 6-18 8-28 4-7-2-10-9-13-14z",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "m42 16 6-2 4 4m10-4 6 3m-23 8 5 2m17-4 5-3",
						fill: "none",
						stroke: "#b19c72"
					}),
					/* @__PURE__ */ v("path", {
						d: "M30 42c6-9 14-7 23 0l-2 5c-8-2-12-5-21-2zm36 0c10-10 18-11 24-4l-1 5c-8-2-13 1-21 4z",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "M33 48q8-5 18 1l-2 6q-9 3-16-3zm36 1q10-7 17-2l-3 6q-8 5-14 1z",
						fill: "#efe7ba"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "44",
						cy: "50",
						rx: "2.7",
						ry: "3.6",
						fill: "#473f23"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "77",
						cy: "49",
						rx: "2.6",
						ry: "3.5",
						fill: "#473f23"
					}),
					/* @__PURE__ */ v("path", {
						d: "m44 49 .5 1m32-2 .5 1",
						stroke: "#fff9d9",
						strokeWidth: "1.5"
					}),
					/* @__PURE__ */ v("path", {
						d: "M55 45c-1 10-6 22-8 31-2 13 18 18 25 6 2-5-3-7-5-12l-5-25",
						fill: o
					}),
					/* @__PURE__ */ v("path", {
						d: "M56 51c1 8-4 21-2 26m1 7 6 1",
						fill: "none",
						stroke: "#edc89a",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M34 68c8-5 14 0 18 11l7 9 6-7c5-10 14-16 21-9-6 4-11 9-14 15l-3 18-6 25-5-9-5 9-2-14-6 9c-3-21-6-28-10-37-3-5-7-12-1-20z",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "M40 74c4 4 9 11 10 20m14-4-3 23m10-30-5 19M36 31l-4 8m58-7 5 7m-68 5-7 1",
						fill: "none",
						stroke: "#7c7550",
						strokeWidth: ".7"
					}),
					/* @__PURE__ */ v("path", {
						d: "M27 63q8 3 14 0m35 0 11-4M31 66q6 6 10 5m37-5 6-2",
						fill: "none",
						stroke: "#9f7550"
					}),
					/* @__PURE__ */ v("path", {
						d: "M69 135c-4-13-5-27 1-35l9-9c4-3 9 0 10 3 6-3 12 1 13 7l2 12-9 23",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M75 100c3-4 8-2 13 3m-12 3c5-3 11-1 15 3m-16 4c6-2 12 1 16 4m-14 2 11 7m2-31 7 6",
						stroke: "#a17046",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M70 102c-3 11 0 22 7 31m18-26 3 13-7 13",
						stroke: "#edcfa0",
						fill: "none",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "29",
						cy: "118",
						r: "2.5",
						fill: i
					})
				] }),
				e === "buccaneer" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "M12 136c3-23 8-36 25-41l47-3c18 4 26 21 28 44",
						fill: l
					}),
					/* @__PURE__ */ v("path", {
						d: "m21 119 15-19 11 9-3 27H23m58-38 16 11-8 27H71",
						fill: "#706675"
					}),
					/* @__PURE__ */ v("path", {
						d: "M33 44c7-13 27-18 42-8 21 8 26 25 19 44l-14 25-28 6-20-18c-10-17-11-33 1-49z",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M77 44c8 12 13 27 4 43l-18 16 10 7 21-25c7-15 3-34-17-41z",
						fill: "#8d6349",
						opacity: ".6",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M29 60c-15-12-25-4-16 8l17 7m60-13c12-11 22-5 18 4l-12 12",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "m18 62 8 6-6-1m77 1 7-3-5 7",
						stroke: "#a56f4d",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M28 47c8-9 17-12 27-6l7 11-18 0-15 9zm45-4c11-4 18 4 22 13l-14-5-9 4z",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "M9 37c9 1 16-8 14-19l18 4c7-4 15-12 24-11l17 18 23-5c3 10-2 21-11 27-22-5-51-5-72 3L10 47z",
						fill: l
					}),
					/* @__PURE__ */ v("path", {
						d: "M27 25c11 5 22 12 31 12 13-2 24-6 40-7m-68 5 7 9m42-23 7 13",
						fill: "none",
						stroke: "#8b8790",
						strokeWidth: "1.2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M45 17q10-10 21-4l10 13-16 8-17-5z",
						fill: "#5c626b",
						stroke: "#333b45"
					}),
					/* @__PURE__ */ v("path", {
						d: "M57 19q8-4 10 4l-1 5-5 3-6-3-1-4z",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "m56 30 10-10m-11 2 12 7",
						stroke: "#e1d3b3",
						strokeWidth: "1.4"
					}),
					/* @__PURE__ */ v("path", {
						d: "m58 23 2 1m3-1 1 2m-4 3 3 1",
						stroke: "#292c30",
						strokeWidth: "1.5"
					}),
					/* @__PURE__ */ v("path", {
						d: "M31 58q11-9 20-3l-1 4q-11-2-19 3m43-7 14-2",
						stroke: "#4e3b2d",
						fill: "none",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ v("path", {
						d: "m34 64 12-1m31-2 10 1",
						stroke: "#e4dfb5",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ v("path", {
						d: "M37 64q4-4 8 0m33-1 6-1",
						fill: "none",
						stroke: "#332e24",
						strokeWidth: "1.5"
					}),
					/* @__PURE__ */ v("path", {
						d: "M55 53c-3 8-1 14-8 17-9 2-11 15-3 19 7 3 15-3 21-5 9 2 15-7 9-13-4-3-9-9-10-14",
						fill: o
					}),
					/* @__PURE__ */ v("path", {
						d: "M48 72q-7 3-3 9m8-20 4 4",
						stroke: "#f1b994",
						fill: "none",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M51 84c-8-9-24-5-26 6-2 9 11 22 21 27 3-15 9-22 15-28-1 13-4 25-1 40 15-3 35-16 35-29 0-12-14-18-28-15l-7 6z",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "M31 87c11 0 13 11 13 20m27-18c14 4 15 15 7 28m-20-22-5 20m22-19c4 5 3 12-1 17",
						fill: "none",
						stroke: "#a99e80",
						strokeWidth: "1"
					}),
					/* @__PURE__ */ v("path", {
						d: "M24 88c-4 4-2 9 7 13l-10 1-7-8-5-14 6-4 7 13z",
						fill: u
					}),
					/* @__PURE__ */ v("path", {
						d: "M5 77c-2-3-1-11 4-13 5-2 13 1 14 6l-3 13c-7 5-13 0-15-6z",
						fill: s
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "14",
						cy: "69",
						rx: "7",
						ry: "4.5",
						fill: "#725d3c"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "14",
						cy: "68",
						rx: "4",
						ry: "2.5",
						fill: "#252a22"
					}),
					/* @__PURE__ */ v("path", {
						d: "m24 124 13-14m52 5 13 15m-81-1 16-1",
						stroke: "#9f96a0",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "m22 117 8 4m60 0 6 2",
						stroke: "#c5b6a1"
					})
				] }),
				e === "beth" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "M12 136c-4-19-7-39 10-49l21-8 36 6 30 19 9 32",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M24 33c3-18 19-26 35-20 13 3 20 19 24 37 4 17 6 36-1 47-5 11-16 15-29 12-23-1-32-21-34-41-3-14-1-25 5-35z",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M69 33c7 18 8 37 0 49-6 12-22 18-32 12 8 13 28 19 39 12 12-8 12-28 8-50z",
						fill: "#9e7750",
						opacity: ".48",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M21 45c-7-3-11 3-10 12l11 15m61-24c13-4 18 5 11 13l-8 4",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M22 39c-5 9-5 22-1 33l9 12 6-8-6-19m47-17 1 27 12 9 3-23-8-13",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "M15 22c9 0 13-5 14-17 14-5 29-4 40 0l7 20 14 3c-2 7-12 11-20 12l-45 1-15-8z",
						fill: u
					}),
					/* @__PURE__ */ v("path", {
						d: "M31 8c10 5 24 5 36-1l4 13c-11 4-29 6-40 1z",
						fill: "#342d28"
					}),
					/* @__PURE__ */ v("path", {
						d: "M17 28c20 4 42 3 62-1",
						fill: "none",
						stroke: "#c29a62",
						strokeWidth: "1.5"
					}),
					/* @__PURE__ */ v("path", {
						d: "M44 12q7-4 12 2l-1 7-5 3-6-3-2-5z",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "m46 16 2 1m3-1 2 1m-6 4 5 0",
						stroke: "#3b3127",
						strokeWidth: "1.7"
					}),
					/* @__PURE__ */ v("path", {
						d: "M28 43q6-7 14-1m17-1q10-5 15 1",
						stroke: "#44352b",
						strokeWidth: "4",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M27 49q5-9 12-4c6 4 3 13-3 13-6 0-9-3-9-9zm32-2c4-9 15-7 15 2 0 9-13 11-15-2z",
						fill: s
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "33",
						cy: "50",
						rx: "2.9",
						ry: "3.9",
						fill: "#4f5038"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "65",
						cy: "47",
						rx: "3",
						ry: "4",
						fill: "#4f5038"
					}),
					/* @__PURE__ */ v("path", {
						d: "m32 49 .5 .5m32-3 .5 1",
						stroke: "#fff8d9",
						strokeWidth: "1.7"
					}),
					/* @__PURE__ */ v("path", {
						d: "M44 47c-2 8-6 16-11 22-5 5-3 14 6 17 8 3 19-2 21-10-3-4-10-17-9-26",
						fill: o
					}),
					/* @__PURE__ */ v("path", {
						d: "M43 54c-1 8-7 13-7 18m-1 7 7 2",
						stroke: "#edc298",
						strokeWidth: "2",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M37 94q12-6 28-1c-4 7-17 9-27 4z",
						fill: "#79513c"
					}),
					/* @__PURE__ */ v("path", {
						d: "m42 94 1 3 5 1 2-4 4 0 1 3 4-2",
						fill: "#ddc491"
					}),
					/* @__PURE__ */ v("path", {
						d: "M31 65q5 3 10 0m20-2 9-3m-43 11 5 4m35-8 9 0m-5 7 9-1m-5 7 7-1m-53 6 8 3m-4 11 5 1",
						fill: "none",
						stroke: "#705338",
						strokeWidth: "2.3"
					}),
					/* @__PURE__ */ v("path", {
						d: "m42 88 1 1m-5-5 1 1m18 3 1-1m13 1 1 1m-23 14 1 1m9 1 1-1m-14-12 1 1",
						stroke: "#72573c",
						strokeWidth: "1.4"
					}),
					/* @__PURE__ */ v("path", {
						d: "M18 93c-6 12-3 27 7 34l8-9-8-21m64-6c14 7 16 17 18 33",
						fill: "#493d2d"
					}),
					/* @__PURE__ */ v("path", {
						d: "M81 104q13-10 23 5l-1 14-17-2-6-10z",
						fill: "none",
						stroke: "#4b4938",
						strokeWidth: "1.4"
					}),
					/* @__PURE__ */ v("path", {
						d: "m84 108 17 7m-13-12 8 18m-14-7 18-5",
						fill: "none",
						stroke: "#4b4938"
					}),
					/* @__PURE__ */ v("path", {
						d: "M33 136c2-16 6-20 16-18l20 5 13-5 13 18",
						fill: u
					}),
					/* @__PURE__ */ v("path", {
						d: "m34 127 17 4 26-1 14-4",
						stroke: "#c29b61",
						fill: "none"
					})
				] }),
				e === "saran" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "M11 136c2-21 12-37 30-43l42 3 24 40",
						fill: "#6f352b"
					}),
					/* @__PURE__ */ v("path", {
						d: "M104 128c-2-31-4-59 11-85-15 14-29 35-37 60z",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "M85 103q12-34 24-49",
						fill: "none",
						stroke: "#baa985"
					}),
					/* @__PURE__ */ v("path", {
						d: "M15 38c5-17 20-22 39-20 22 0 36 13 41 29 4 14 2 28-4 39-6 12-20 24-35 24-19 2-35-9-40-25-6-13-7-32-1-47z",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M76 41c17 9 18 34 4 48l-26 15 10 6c20-4 37-20 34-41-2-14-8-24-22-28z",
						fill: "#9b6547",
						opacity: ".55",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M89 53c15-12 26-6 18 6l-15 13",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "m97 56 7-2-5 7",
						fill: "none",
						stroke: "#9e6849"
					}),
					/* @__PURE__ */ v("path", {
						d: "M11 38c2-10 10-18 22-22l9-10 19 8c11 1 18 5 22 10l14 7-16 9-24-4-28 7z",
						fill: u
					}),
					/* @__PURE__ */ v("path", {
						d: "M25 27c9 2 16-2 22-12 9 9 18 13 28 13l-7 7-23-3m8-17 10 8",
						fill: "none",
						stroke: "#d2a15c",
						strokeWidth: "1.3"
					}),
					/* @__PURE__ */ v("path", {
						d: "M16 42q10-8 18-3m40-5q14-1 20 10",
						fill: "none",
						stroke: c,
						strokeWidth: "7"
					}),
					/* @__PURE__ */ v("path", {
						d: "M13 50c8-5 21-6 31-3l3 23c-10 7-23 8-30 1zm39-4c13-5 26-5 38-1l-2 24c-12 4-24 6-34 1z",
						fill: "#777b61",
						stroke: "#302d27",
						strokeWidth: "4"
					}),
					/* @__PURE__ */ v("path", {
						d: "M18 53q12-5 22 1l-1 12q-8 5-17 3zm39-3q15-4 27-1l-2 15-23 3z",
						fill: "#baaf80",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "m18 54 20-2m21-2 21-2",
						stroke: "#eee9c4",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M24 60q5-7 12-1m27-2q6-8 13-2",
						fill: "none",
						stroke: "#493b29",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "30",
						cy: "60",
						rx: "2.2",
						ry: "3",
						fill: "#463c27"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "70",
						cy: "56",
						rx: "2.2",
						ry: "3",
						fill: "#463c27"
					}),
					/* @__PURE__ */ v("path", {
						d: "m44 53 10-1m36-3 12-5",
						fill: "none",
						stroke: "#2e302b",
						strokeWidth: "4"
					}),
					/* @__PURE__ */ v("path", {
						d: "M49 56c-2 6-3 12-10 16-5 5 2 11 13 10 11-1 15-6 11-10l-7-13",
						fill: o
					}),
					/* @__PURE__ */ v("path", {
						d: "M47 66q-8 9 2 11",
						stroke: "#eab489",
						fill: "none",
						strokeWidth: "1.8"
					}),
					/* @__PURE__ */ v("path", {
						d: "M25 83c15-2 36-4 58-7-4 15-17 26-34 25-14 0-21-8-24-18z",
						fill: "#432d23"
					}),
					/* @__PURE__ */ v("path", {
						d: "M29 84l7 7 9-1 2-7 6-1 1 8 9-3 1-7 6-1 0 5 8-6",
						fill: "#e8d5a1"
					}),
					/* @__PURE__ */ v("path", {
						d: "M36 96q13 10 29-1M26 77q-6 8-1 14m54-21q11-2 13 5",
						fill: "none",
						stroke: "#976446"
					}),
					/* @__PURE__ */ v("path", {
						d: "m30 99 2 2m4 2 2 1m5 2 2 0m7-1 2 0m7-2 2-1m5-2 2-2m6-4 1-2M20 73l4 1m60-3 5-2",
						stroke: "#674b35",
						strokeWidth: "1.3"
					}),
					/* @__PURE__ */ v("path", {
						d: "M17 116c9-16 24-20 39-8l5 19c-14-4-27 0-33 9H15z",
						fill: a
					}),
					/* @__PURE__ */ v("path", {
						d: "M23 115q14-12 29-4m-25 7q14-9 25-4m-22 9q13-7 23-5",
						fill: "none",
						stroke: "#f4d982",
						strokeWidth: "1.4"
					}),
					/* @__PURE__ */ v("path", {
						d: "M55 110q-2 10 3 19l21 7",
						fill: "none",
						stroke: "#6f512c",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ v("path", {
						d: "m81 114 14 20 6-6-15-20z",
						fill: u
					}),
					/* @__PURE__ */ v("path", {
						d: "m79 111 12-5m-6 15 9-5",
						fill: "none",
						stroke: a,
						strokeWidth: "4"
					})
				] }),
				e === "cooper" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "M8 136c3-24 12-39 33-47l36-2c23 9 32 24 35 49",
						fill: u
					}),
					/* @__PURE__ */ v("path", {
						d: "M30 39c7-17 24-20 40-11 17 10 24 31 21 52-1 20-13 33-28 33-17-3-25-17-27-35-8-13-12-27-6-39z",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M70 40c20 16 18 40 4 53L62 106l9 4c22-7 25-40 15-57z",
						fill: "#9f643b",
						opacity: ".5",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M16 28c8-3 13-11 21-15 12 2 24 6 33 11l15 1 15 19c-7 5-17 4-24-1-21-4-38-5-55-2l-10-8z",
						fill: u
					}),
					/* @__PURE__ */ v("path", {
						d: "M23 25c17 5 37 9 54 7m-38-17 3 8m39 9 11 7",
						fill: "none",
						stroke: "#cb9c62",
						strokeWidth: "1.3"
					}),
					/* @__PURE__ */ v("path", {
						d: "M76 58c16-12 24-2 17 10l-12 5",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "m84 61 7-1-5 7",
						fill: "none",
						stroke: "#9f653e"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "89",
						cy: "72",
						r: "5",
						fill: "none",
						stroke: a,
						strokeWidth: "2.4"
					}),
					/* @__PURE__ */ v("path", {
						d: "M39 45c-1 11-5 20-1 33l12 10 5-14-5-25",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "M49 52q11-6 19 2m5 5 8-1",
						stroke: "#6e462b",
						strokeWidth: "4",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M53 57q7-5 13 1",
						stroke: "#3a2a21",
						strokeWidth: "2",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M47 48C34 43 18 45 18 57c-1 13 15 18 28 14 10-3 16-11 8-18z",
						fill: o
					}),
					/* @__PURE__ */ v("path", {
						d: "M24 51q10-6 21-1m-22 7q2 7 9 8",
						fill: "none",
						stroke: "#e09a70",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M45 71c5 6 11 7 19 5l7 11c-3 17-14 23-24 12l-9-15z",
						fill: "#3c251c"
					}),
					/* @__PURE__ */ v("path", {
						d: "M45 74q8 7 17 5l-1 7-9 2-7-6z",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "M52 98q6-7 13-5",
						stroke: "#a7553d",
						fill: "none",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ v("path", {
						d: "M64 66q13 6 14 18m-9-18 5-3m-2 30-5 10m-30-24-6-4",
						stroke: "#ac764a",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M21 136c-8-7-9-17-5-26l12-20 17 5 2 41",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M19 119q7-11 13-14m-14 21 14-12",
						stroke: "#b07b4d",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M30 81q13-5 25 1l1 46c-10 7-24 6-33-1z",
						fill: i
					}),
					/* @__PURE__ */ v("path", {
						d: "M31 83q12-4 22 1m-25 40q11 6 25 1",
						stroke: "#c9c8ad",
						fill: "none",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M54 87c20-6 25 4 21 19-3 9-12 12-20 8m3-21c10-4 12 2 9 10-2 5-7 6-10 6",
						fill: "#494a3e",
						stroke: "#c9b788",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "m32 88-3 31 7 3 3-33z",
						fill: "#a4aca0",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M68 95c11-3 19 2 22 12l1 18c-7 9-15 12-24 11l-4-13 3-13-4-7c-2-4 1-7 6-8z",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M65 103q10-5 16 3m-16 6q10-5 17 2m-16 6q10-4 17 3m-13 6q7-2 12 1",
						stroke: "#a97145",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M85 109q6 10 1 20m-16-28 6-1",
						stroke: "#efd09a",
						fill: "none",
						strokeWidth: "1.8"
					}),
					/* @__PURE__ */ v("path", {
						d: "M99 117l5 13m-83-5-3 10",
						stroke: "#c79d62",
						fill: "none"
					})
				] }),
				e === "venetian" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "M9 136c2-27 15-37 39-44h29c21 9 31 22 34 44",
						fill: "#45684a"
					}),
					/* @__PURE__ */ v("path", {
						d: "M29 97c-4 13-6 27-1 39h21l11-26-10-15m26-1 12 12-7 30H66l-6-26z",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "M30 47c0-22 15-30 35-23 22 8 27 27 20 48-2 18-10 33-23 35-16 0-28-17-31-34-5-10-6-18-1-26z",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M72 37c16 17 13 37 0 51l-19 12 11 5c16-4 24-28 23-44z",
						fill: "#aa7150",
						opacity: ".5",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M29 45c-3 10-1 21 5 28l8-9-1-21m40 0 10 20-8 10-7-19",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "M14 35c11 0 17-10 20-24l23 10c12-6 22-9 33-6l12 22c-17 13-55 15-87 7z",
						fill: u
					}),
					/* @__PURE__ */ v("path", {
						d: "M35 14c8 12 26 19 53 10l5 8c-19 10-41 11-62 5z",
						fill: "#8c2e25"
					}),
					/* @__PURE__ */ v("path", {
						d: "M21 39q35 9 72-6m-48-10 3 8",
						stroke: "#d5a764",
						fill: "none",
						strokeWidth: "1.4"
					}),
					/* @__PURE__ */ v("path", {
						d: "m41 22 4-22 17 3-4 23z",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "m49 6-1 12 8-7m-11-2 12 13m-10-3 9 1",
						fill: "none",
						stroke: "#624f38"
					}),
					/* @__PURE__ */ v("path", {
						d: "M33 52q10-5 18 0m16 1 13 3",
						stroke: "#533727",
						strokeWidth: "3",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "m38 56 10 1m22 2 8 1",
						stroke: "#eee1ba",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ v("path", {
						d: "m41 57 6 0m24 3 6 1",
						stroke: "#433328",
						strokeWidth: "1.3"
					}),
					/* @__PURE__ */ v("path", {
						d: "M53 56c-2 7-6 10-8 16-2 5 6 10 14 7 6-2 8-6 4-9l-5-10",
						fill: o
					}),
					/* @__PURE__ */ v("path", {
						d: "m49 68 2 4 6 1",
						fill: "none",
						stroke: "#edb789",
						strokeWidth: "1.5"
					}),
					/* @__PURE__ */ v("path", {
						d: "M50 78c-11-9-22-7-24-1-2 5 5 7 10 3 6-1 11 3 15 4m7-3c10-8 25-7 26-1 1 6-9 6-12 1l-10 3",
						fill: "none",
						stroke: c,
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M40 87q16 16 35 1l-6 10-17 3z",
						fill: "#643e2c"
					}),
					/* @__PURE__ */ v("path", {
						d: "M44 89q14 8 26 1",
						stroke: "#f0d59e",
						strokeWidth: "3",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "m55 101 5 6 4-8",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "m34 70 7 1m29-4 7 2m-34 8-6 3M32 112l5 20m43-20-4 20",
						stroke: "#ac8b60",
						fill: "none"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "35",
						cy: "77",
						r: "5",
						fill: "none",
						stroke: a,
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "44",
						cy: "120",
						r: "3",
						fill: a
					}),
					/* @__PURE__ */ v("path", {
						d: "M75 131c-1-18 1-29 11-34 11-2 18 3 20 16l-5 23",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M86 93c-2-14 5-26 16-23 10 3 11 13 6 21l-4 15-14 5z",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "M101 72c-1-8 6-12 8-6 5-5 10 2 4 6l-4 4",
						fill: "#aa352d"
					}),
					/* @__PURE__ */ v("path", {
						d: "M99 86q9 0 14 4l-11 6",
						fill: a
					}),
					/* @__PURE__ */ v("circle", {
						cx: "99",
						cy: "81",
						r: "2.3",
						fill: "#252d23"
					}),
					/* @__PURE__ */ v("path", {
						d: "M89 100c-6 1-9 8-8 15l16 11m-12-17 13 3m-13 4 12 3",
						fill: "none",
						stroke: "#a8784e"
					}),
					/* @__PURE__ */ v("path", {
						d: "m13 136 7-40 4 37",
						fill: i
					})
				] }),
				e === "prussian" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "M8 136c2-22 13-40 32-44l42 0c21 7 29 25 30 44",
						fill: u
					}),
					/* @__PURE__ */ v("path", {
						d: "M22 92c-8-12-8-26 0-36l21 3 10 42-16 23-13-13zm55-33 20-7c12 16 14 32 6 44l-9 28-19-19z",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "M28 41c4-19 22-25 40-17 20 9 26 27 22 49l-6 22c-3 14-12 22-25 22-18-1-28-18-31-34-7-12-7-30 0-42z",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M75 35c14 17 14 38 4 53l-21 22 9 5c16-6 25-26 25-45z",
						fill: "#ad7651",
						opacity: ".5",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M19 31C16 11 34 4 57 5c24 0 40 12 40 31l-16 9-47-1-19-7z",
						fill: a
					}),
					/* @__PURE__ */ v("path", {
						d: "M11 35c24 7 64 7 90-2l9 8-22 5-57 0-25-5z",
						fill: u
					}),
					/* @__PURE__ */ v("path", {
						d: "M22 33q37 9 73 0l-3 7q-31 8-69 0z",
						fill: "#cc9c34"
					}),
					/* @__PURE__ */ v("path", {
						d: "M28 28c-3-8 0-13 5-13 5 0 4 7 2 9m12 5c-2-10 2-15 6-14 6 1 3 8 2 11m12 3c-2-10 2-13 6-11 5 2 3 8 0 11m9 0c0-8 4-9 6-5l-1 8",
						fill: "none",
						stroke: "#5b5540",
						strokeWidth: "1.6"
					}),
					[
						31,
						51,
						70,
						86
					].map((e, t) => /* @__PURE__ */ v("circle", {
						cx: e,
						cy: [
							15,
							15,
							18,
							24
						][t],
						r: "3",
						fill: i
					}, e)),
					/* @__PURE__ */ v("path", {
						d: "M31 43c-8 11-8 32-2 53l13 9c-2-23-1-42 4-58m27-3c7 16 7 35 2 59l13-11 6-30-9-17",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "M32 52q11-12 22 1m8-2q11-11 22-2",
						fill: "none",
						stroke: "#372c24",
						strokeWidth: "4"
					}),
					/* @__PURE__ */ v("path", {
						d: "m37 57 12 2m19-2 10-1",
						stroke: "#483c2b",
						strokeWidth: "2.5"
					}),
					/* @__PURE__ */ v("path", {
						d: "M55 51c-5 9-3 17-9 24-5 8 3 14 13 13 10-2 13-8 7-15l-4-18",
						fill: o
					}),
					/* @__PURE__ */ v("path", {
						d: "M52 67q-5 12 3 14",
						fill: "none",
						stroke: "#edc292",
						strokeWidth: "1.7"
					}),
					/* @__PURE__ */ v("path", {
						d: "M43 86c7-5 12-1 17 3 7-8 15-8 23-1l-14 4-7 14-7-14z",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "m35 61 1 24m48-25-3 28m-33-20 4-2m14 1 4-2m-20 31 8 4",
						stroke: "#8e7251",
						fill: "none",
						strokeWidth: ".7"
					}),
					/* @__PURE__ */ v("path", {
						d: "M19 136c1-10 5-22 16-25 7-1 12 6 17 9l7 10-6 6H19m42-6 9-12c9-9 16-8 21-2l12 20H69z",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M36 112c6-13 14-23 18-24 6-1 5 5 2 9l-13 19m27 5c-3-8-9-15-12-20-2-5 2-9 6-6l13 16",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "m31 119 12 9m-8-3 11 9m-4-8 11 7m26-15-9 12m15-7-9 12m-29-33 7-9m12 17-3-9",
						stroke: "#a7754b",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M24 110c-4-13-6-25-4-36m80 36q7-19 0-37",
						fill: "none",
						stroke: "#f9eaca",
						strokeWidth: "2"
					})
				] }),
				e === "helvetian" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "M9 136c1-26 15-42 38-44l29-1c22 6 34 20 36 45",
						fill: "#547654"
					}),
					/* @__PURE__ */ v("path", {
						d: "M21 113c3-13 12-20 23-20l15 20-8 23H27m47-43 14 6 10 37H68l-9-23z",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "M24 43c5-19 21-25 41-18 24 7 31 25 30 45 0 20-16 35-32 37-21 3-36-10-39-25-6-12-6-28 0-39z",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M75 35c18 14 20 40 1 54l-25 11 11 6c21-1 36-17 36-36z",
						fill: "#ad7d43",
						opacity: ".48",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M25 66c-16-13-23-4-14 8l17 7m64-18c17-12 26-3 17 9l-15 8",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "m14 69 9 5m74-5 9-1-7 6",
						stroke: "#ac7847",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M17 34c12-2 18-11 19-27 15-7 31-5 40 6l5 19 23 5-3 10c-25-1-56-3-84 1l-8-8z",
						fill: "#284c39"
					}),
					/* @__PURE__ */ v("path", {
						d: "M40 8q18-8 31 4l5 19q-17-3-37-1z",
						fill: "#4c7150",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M18 36q41-8 79 4m-58-6 37-2",
						fill: "none",
						stroke: "#a3934a",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M29 27c-3-7-10-7-15-12L9 3 4 7l6 12-8-1 6 9 13 3z",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "m18 27 5-14 6 10 7-11",
						fill: "none",
						stroke: "#bd9737",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "11",
						cy: "17",
						r: "1.5",
						fill: "#302b21"
					}),
					/* @__PURE__ */ v("path", {
						d: "M29 52q10-10 19-4m18-1q11-8 21 2",
						fill: "none",
						stroke: "#775637",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ v("path", {
						d: "M30 58c0-12 17-14 18-2 3 13-16 17-18 2zm37-3c-1-12 17-14 18-2 2 14-15 17-18 2z",
						fill: s
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "39",
						cy: "57",
						rx: "5",
						ry: "6",
						fill: "#be9d32"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "76",
						cy: "54",
						rx: "5",
						ry: "6",
						fill: "#be9d32"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "39",
						cy: "57",
						rx: "2",
						ry: "3",
						fill: "#333727"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "76",
						cy: "54",
						rx: "2",
						ry: "3",
						fill: "#333727"
					}),
					/* @__PURE__ */ v("path", {
						d: "M55 53c-3 6-5 12-9 16-5 6 2 12 12 11 10-1 15-8 9-12l-6-12",
						fill: o
					}),
					/* @__PURE__ */ v("path", {
						d: "M50 67q-2 6 6 8",
						stroke: "#edc98d",
						fill: "none",
						strokeWidth: "1.5"
					}),
					/* @__PURE__ */ v("path", {
						d: "M26 82c17-2 37-5 64-7-6 14-19 22-37 22-16 0-23-6-27-15z",
						fill: "#58412b"
					}),
					/* @__PURE__ */ v("path", {
						d: "M31 82q25 1 51-4l-6 8-16 4-20-2z",
						fill: "#f3df9c"
					}),
					/* @__PURE__ */ v("path", {
						d: "m42 84 1 4m10-6 1 6m11-7 0 5m9-7-1 5",
						stroke: "#a68c53"
					}),
					/* @__PURE__ */ v("path", {
						d: "M28 76q-7 8-1 13m57-19q10 0 10 7M36 99q17 10 36-2",
						fill: "none",
						stroke: "#9e7746"
					}),
					/* @__PURE__ */ v("path", {
						d: "m26 91 2 1m4 2 2 1m4 1 2 0m5 2 2 0m29-5 2-1m6-2 2-1m-8 7 1-1",
						stroke: "#8f6f3e"
					}),
					/* @__PURE__ */ v("path", {
						d: "M34 108q13-5 28 0l-2 26H35z",
						fill: s
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "48",
						cy: "108",
						rx: "14",
						ry: "4",
						fill: "#bead7a"
					}),
					/* @__PURE__ */ v("path", {
						d: "M60 111c16-3 17 16 0 17m1-12c8 0 7 7-1 8",
						fill: "none",
						stroke: "#d8c694",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ v("path", {
						d: "M19 136c-3-10 1-18 7-22l9-1 7 7c4 3 2 8-2 9l3 7m26 0-3-14c0-6 8-9 13-5l11 19",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "m27 117 9 7m-10-2 9 7m37-9 8 9m-50 3 7 3",
						stroke: "#a57948",
						fill: "none"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "90",
						cy: "106",
						r: "4",
						fill: "#86a653",
						stroke: "#3a6337"
					})
				] }),
				e === "seafarer" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "M16 136c2-22 17-41 37-43l31 2c20 7 26 23 29 41",
						fill: u
					}),
					/* @__PURE__ */ v("path", {
						d: "m42 98 14 15-9 23H30l4-26m45-14 12 18-14 22H58l-2-23z",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "M34 39c7-20 25-24 42-13 18 11 22 32 16 50-2 17-12 28-25 29-17-1-29-11-34-26-6-12-6-29 1-40z",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M76 37c16 16 13 38 0 51l-19 11 11 6c17-2 27-19 25-39z",
						fill: "#a76c43",
						opacity: ".55",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M32 46C15 35 12 49 24 60l12 4m56-13c17-6 19 6 8 14l-10 5",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "m24 48 7 9m64 2 7-2-6 6",
						fill: "none",
						stroke: "#a47046"
					}),
					/* @__PURE__ */ v("path", {
						d: "M25 38c-7-13 2-20 11-25l8 7 16-11 11 10 17-7-1 16 13 8-11 9-16-6-21 1-14-7-1 20z",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "M35 24q13 7 28 1m9-2 10 4m-49 8 4 5",
						fill: "none",
						stroke: "#78613d"
					}),
					/* @__PURE__ */ v("path", {
						d: "M39 51q10-7 20 0m12-1 14 4",
						stroke: "#4a3024",
						strokeWidth: "3.5",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "m43 55 13 1m18 0 9 2",
						stroke: "#e8d7ac",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ v("path", {
						d: "m48 55 5 1m24 0 4 1",
						stroke: "#332e23",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M59 53c-3 7-6 12-10 17-5 6 1 12 11 11 10-1 14-7 8-11l-5-12",
						fill: o
					}),
					/* @__PURE__ */ v("path", {
						d: "M56 65q-5 7 2 10",
						stroke: "#ecc196",
						fill: "none",
						strokeWidth: "1.6"
					}),
					/* @__PURE__ */ v("path", {
						d: "M43 83q13-6 30 2m-23 6 15 1",
						fill: "none",
						stroke: "#63412c",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "m53 98 9 6 9-10-8 2z",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "m39 64 7 2m30-1 7-1m-38 13-4-3m32 2 6-3m-32 21 4 1m22-5 4-3",
						stroke: "#ab7951",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M23 136c-7-4-11-19-14-28L8 91l12-7 14 14 8 21-4 17",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M12 95c1-13 3-23 8-25 6-2 7 5 4 12l-4 14m1-22 3-19c1-8 8-8 8-1l-1 20m0-9 7-13c3-5 8-2 5 4l-7 16 4 7-5 8",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M17 88q7-2 15 5m-17 0 13 6m-11 1 13 6m-7-29 7 2",
						stroke: "#a57047",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M27 10 19 67c21-2 36-16 42-37L27 10z",
						fill: "none",
						stroke: a,
						strokeWidth: "3.5"
					}),
					/* @__PURE__ */ v("path", {
						d: "m27 11 6 46m-13 5 36-28m-27-9 19 17m-28 17 32-5",
						stroke: "#b58c37",
						fill: "none",
						strokeWidth: "1.3"
					}),
					/* @__PURE__ */ v("path", {
						d: "M22 54q12 0 26-15m-24 11 4 2m1-6 3 3m2-7 3 3m1-7 3 3",
						fill: "none",
						stroke: "#e3c56b"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "27",
						cy: "11",
						r: "5",
						fill: a
					}),
					/* @__PURE__ */ v("circle", {
						cx: "27",
						cy: "11",
						r: "2",
						fill: "#765326"
					}),
					/* @__PURE__ */ v("path", {
						d: "m28 30 22 7",
						stroke: "#443b27",
						strokeWidth: "5"
					}),
					/* @__PURE__ */ v("path", {
						d: "m29 29 22 7",
						stroke: a,
						strokeWidth: "3"
					}),
					/* @__PURE__ */ v("path", {
						d: "M84 103q12 0 16 13l-11 10-10-11m10-11 4 14m-12-9 18 4",
						fill: "none",
						stroke: "#595438",
						strokeWidth: "1.2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M101 121l6 10m-59-9-3 11m34-7-3 7",
						stroke: "#9a7848",
						fill: "none"
					})
				] }),
				e === "anchoree" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "M10 136c2-27 17-40 39-43h26c21 5 32 23 36 43",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "M22 112q37-10 73 0m-79 14q44-9 86 0m-72-25 5 35m48-35-4 35",
						fill: "none",
						stroke: "#517c91",
						strokeWidth: "7"
					}),
					/* @__PURE__ */ v("path", {
						d: "M27 36c10-15 30-16 46-5 20 12 25 34 20 52-2 18-17 29-34 28-20 0-33-13-37-29-7-16-5-34 5-46z",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M76 41c17 13 19 37 4 50l-22 13 10 6c20-2 31-22 28-41z",
						fill: "#a6754e",
						opacity: ".45",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M27 43c-7-7-16-2-15 8l10 13m70-12c14-7 20 5 9 12l-10 4",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "m18 49 5 7m75 0 4 3-4 2",
						fill: "none",
						stroke: "#a46f49"
					}),
					/* @__PURE__ */ v("path", {
						d: "M20 37C23 12 41 7 58 9c19 2 31 12 37 32l-17-6-30-3-24 8z",
						fill: "#ad453a"
					}),
					/* @__PURE__ */ v("path", {
						d: "M27 26c16-13 37-12 54 0m-52 8q28-9 56 1",
						fill: "none",
						stroke: "#dc8260",
						strokeWidth: "1.7"
					}),
					/* @__PURE__ */ v("path", {
						d: "m30 25 3-3m6-3 4-2m6 0 5 0m7 2 5 2",
						stroke: "#73372d",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M29 42q7-6 17-3m21 1 12 2",
						fill: "none",
						stroke: "#795434",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M29 49c1-11 16-12 17 0 0 13-15 14-17 0zm35-1c0-11 16-13 18-1 1 14-16 15-18 1z",
						fill: s
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "38",
						cy: "49",
						rx: "2.6",
						ry: "3.7",
						fill: "#3e3c2b"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "74",
						cy: "47",
						rx: "2.6",
						ry: "3.7",
						fill: "#3e3c2b"
					}),
					/* @__PURE__ */ v("path", {
						d: "M53 46C43 47 34 61 35 77c0 14 8 22 19 20 12-2 17-11 15-25-2-17-9-27-16-26z",
						fill: o
					}),
					/* @__PURE__ */ v("path", {
						d: "M47 54c-8 8-11 25-5 32m8 6q12 1 14-10",
						stroke: "#e4ba8c",
						strokeWidth: "1.8",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M71 84q13-1 17 5l-9 9-9-4",
						fill: "#70412d"
					}),
					/* @__PURE__ */ v("path", {
						d: "m73 85 8 1-2 4-7-1",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "m26 66 6 2m45-7 7 1m-54 13 4 4m45-9 5 1M40 101q12 9 25 4",
						stroke: "#b28555",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M18 113c-6-6-10-15-7-20 4-5 11-2 14 3l10 12 3 28H20z",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "m15 98 11 6m-9 2 11 5m-8 3 11 4",
						fill: "none",
						stroke: "#b18255"
					}),
					/* @__PURE__ */ v("path", {
						d: "M98 70c7-4 9 3 4 7-5 3-8 0-4-7z",
						fill: "none",
						stroke: a,
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "m17 87 10 49",
						stroke: "#253e46",
						strokeWidth: "9"
					}),
					/* @__PURE__ */ v("path", {
						d: "m17 86 10 50M8 99l25-7",
						stroke: "#97adb0",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M6 110q-2 19 21 23 15-10 13-28l-7 5m-28 0 9 6m19-6 7-5 0 10",
						fill: "none",
						stroke: i,
						strokeWidth: "5"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "17",
						cy: "85",
						r: "8",
						fill: "none",
						stroke: i,
						strokeWidth: "4"
					})
				] }),
				e === "seadog" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "M9 136c1-25 16-41 36-44l38 3c20 7 26 23 28 41",
						fill: u
					}),
					/* @__PURE__ */ v("path", {
						d: "M24 44c3-20 21-27 40-20 22 7 30 25 27 44l-8 32-28 16-25-21c-7-13-13-34-6-51z",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M77 39c16 14 18 32 6 47l-17 14 8 8c19-11 23-31 18-48z",
						fill: "#9d6646",
						opacity: ".5",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M23 48C7 39 3 51 13 63l16 8m59-16c18-9 25 4 11 14l-10 3",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "m14 51 8 8m74 3 8-2-5 7",
						stroke: "#9f6f4a",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M23 40c-6-13 7-27 24-27 10-8 28-8 38 2l6 21-23 3-21-5-20 9z",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "M31 26q20 5 43-4m-31-5 7 2m27 6 8 4",
						stroke: "#af9e72",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M24 30c-7 10-9 20-7 33l10 10 8-15-3-14m42-11c13 8 17 20 14 35l-9 5-6-24",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "M26 47c7-9 16-4 23 3l-2 6-21-4m36-2c6-11 16-16 25-10l-2 5-19 12",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "m32 57 12 2m24-2 12-4",
						stroke: "#e2d9b3",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ v("path", {
						d: "m36 58 4 1m30-3 5-1",
						stroke: "#3a3426",
						strokeWidth: "1.7"
					}),
					/* @__PURE__ */ v("path", {
						d: "M49 53c-5 7-4 17-9 23-6 7 3 14 13 12 11-1 17-8 10-14l-7-16",
						fill: o
					}),
					/* @__PURE__ */ v("path", {
						d: "M47 66q-5 11 4 15",
						stroke: "#e6ad82",
						strokeWidth: "1.6",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M22 66c7 7 13 9 24 7l12 14 12-13 17-9c2 9 6 14 3 24l-6 8 4 8-12 11 3 6-22 13-12-5-8 3-9-16-8-4 1-15-7-5 5-10z",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "M22 75c8 4 13 7 14 16m-9-10 8 28m4-22 8 32m2-27 6 33m4-36 2 37m6-39-1 35m12-42-4 33m10-43-3 23m-37-17q11 7 24 0",
						fill: "none",
						stroke: "#79745a",
						strokeWidth: ".65"
					}),
					/* @__PURE__ */ v("path", {
						d: "M13 83c-7-11-9-18-2-26 5-6 13-4 13 3 0 5-5 8-8 6m-2 2 2 14",
						fill: "none",
						stroke: i,
						strokeWidth: "5"
					}),
					/* @__PURE__ */ v("path", {
						d: "M9 84l13-1 0 21-14 0z",
						fill: u
					}),
					/* @__PURE__ */ v("path", {
						d: "m9 86 12 0m-12 15 12 0",
						stroke: a,
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M79 136c-2-13-1-24 8-27 8-2 17 4 20 13l2 14",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "m88 114 1 12m6-11 2 12m5-9 1 12m-13-3 11 5",
						stroke: "#a36f48",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M89 124q5-4 9 1l-1 8-7 0z",
						fill: i
					}),
					/* @__PURE__ */ v("path", {
						d: "m19 125 5 9m73-16 5 4",
						stroke: "#dbc297",
						fill: "none"
					})
				] }),
				e === "cartographer" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "M8 136c3-25 17-39 39-44l29 0c20 7 31 25 34 44",
						fill: "#4b6261"
					}),
					/* @__PURE__ */ v("path", {
						d: "M28 97c-9 1-14 8-12 20l14 19h20l8-28m18-13 19 8 6 33H70l-12-28",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "M26 44c4-18 19-24 37-17 20 7 31 24 29 43-1 16-12 30-28 32-19 1-34-9-39-24-7-12-7-25 1-34z",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M76 39c16 12 20 32 5 45l-21 12 7 5c18-2 28-17 27-33z",
						fill: "#b17e49",
						opacity: ".5",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M25 56C10 45 4 56 14 67l16 7m63-18c17-9 24 3 11 12l-12 4",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "m15 57 9 7m74 0 7-2-5 5",
						stroke: "#ab7846",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M15 33C25 27 34 7 33 0l25-2 13 12 12 22 21 4-4 9-28 0-31-7-29 7-7-7z",
						fill: l
					}),
					/* @__PURE__ */ v("path", {
						d: "M40 4c9 9 18 17 31 22m-50 9q37-5 69 2m-54-21 5 9",
						stroke: "#7c9290",
						fill: "none",
						strokeWidth: "1.2"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "54",
						cy: "19",
						rx: "10",
						ry: "6",
						fill: "#647b77",
						transform: "rotate(-12 54 19)"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "54",
						cy: "19",
						rx: "6.5",
						ry: "3.2",
						fill: "#1c3638"
					}),
					/* @__PURE__ */ v("path", {
						d: "M22 45q10-8 24-2m19 0q14-6 25 2",
						stroke: c,
						strokeWidth: "7",
						fill: "none"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "35",
						cy: "56",
						r: "15",
						fill: "#b5d0c9",
						stroke: "#323c3a",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "75",
						cy: "55",
						r: "15",
						fill: "#b5d0c9",
						stroke: "#323c3a",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ v("path", {
						d: "m49 53 11-1m-40 1-9-2m80-2 9-2",
						stroke: "#323c3a",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ v("path", {
						d: "M24 53q3-8 12-9m-8 17 4 5m32-16q3-6 10-7m-7 18 3 4",
						fill: "none",
						stroke: "#f4f2d5",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M53 60c-4 8-9 12-13 15-4 7 6 14 17 11 9-2 14-8 7-12l-5-10",
						fill: o
					}),
					/* @__PURE__ */ v("path", {
						d: "M50 69q-9 9 2 12",
						fill: "none",
						stroke: "#edcb92",
						strokeWidth: "1.5"
					}),
					/* @__PURE__ */ v("path", {
						d: "M48 84c-10-8-19-5-21 4-3 7-8 11-14 6 2 10 13 9 18 3l13-8 10 2 5 17 7-18c9 1 15 4 20 8 8 5 15-2 12-10-2 8-6 6-11 1-8-8-19-9-26-1z",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "M24 91q8-8 17-5m27 0q10-2 17 6m-32-2 5 8m-9-16 8 2",
						fill: "none",
						stroke: "#7c7958",
						strokeWidth: ".7"
					}),
					/* @__PURE__ */ v("path", {
						d: "M15 136c-1-14 10-21 20-17l13 17m31 0 8-15c11-6 20 2 21 15",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "m15 133 22-10 20 7 22-7 24 13H15z",
						fill: "#d1b477"
					}),
					/* @__PURE__ */ v("path", {
						d: "m36 126 5 10m17-6 0 6m21-10 0 10m-57-2 6-4 6 4m32-2 6-2",
						fill: "none",
						stroke: "#9a7447"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "32",
						cy: "112",
						r: "4.5",
						fill: i
					}),
					/* @__PURE__ */ v("circle", {
						cx: "85",
						cy: "112",
						r: "4.5",
						fill: i
					}),
					/* @__PURE__ */ v("path", {
						d: "m32 109 1 2m51-2 1 2",
						stroke: "#dfdcc1"
					})
				] }),
				e === "king" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "M14 136c0-24 13-42 36-44l28 2c18 10 26 25 27 42",
						fill: "#92362e"
					}),
					/* @__PURE__ */ v("path", {
						d: "M32 95c-9 11-7 29-6 41h63c1-17-3-29-13-41z",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "m35 116 3 12-5 8-3-9zm15-1 5 13-4 8-4-9zm17 0 3 14-4 7-3-8zm14 0 4 12-3 9-4-10z",
						fill: c,
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M30 40c4-15 18-21 34-15 18 7 23 21 23 39l-4 26c-4 14-14 19-27 17-17-2-26-13-29-26-5-14-3-29 3-41z",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M73 34c13 14 15 35 4 50l-21 16 6 6c15-1 26-11 26-32z",
						fill: "#a26745",
						opacity: ".45",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M28 56C8 43 5 57 17 68l12 6m55-17c17-10 26 1 14 11l-13 4",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "m18 57 7 6m65-1 8-2-6 7",
						fill: "none",
						stroke: "#a16e48"
					}),
					/* @__PURE__ */ v("path", {
						d: "M24 40 14 13l20 14 6-24 18 20L70 2l10 25 19-12-10 28z",
						fill: a
					}),
					/* @__PURE__ */ v("path", {
						d: "M24 33q30 7 65 1l-2 13q-30 5-59-1z",
						fill: "#c68e26"
					}),
					/* @__PURE__ */ v("path", {
						d: "M29 35q27 6 55 2m-60-15 5 9m13-20 9 15m19-16 6 18",
						fill: "none",
						stroke: "#f5df87",
						strokeWidth: "1.5"
					}),
					[
						14,
						40,
						70,
						99
					].map((e, t) => /* @__PURE__ */ v("circle", {
						cx: e,
						cy: [
							13,
							3,
							2,
							15
						][t],
						r: "3.3",
						fill: a
					}, e)),
					[
						34,
						49,
						64,
						79
					].map((e) => /* @__PURE__ */ y("g", { children: [/* @__PURE__ */ v("ellipse", {
						cx: e,
						cy: "40",
						rx: "5",
						ry: "4",
						fill: "#795a24"
					}), /* @__PURE__ */ v("ellipse", {
						cx: e,
						cy: "40",
						rx: "3",
						ry: "2.5",
						fill: a
					})] }, e)),
					/* @__PURE__ */ v("path", {
						d: "M31 53q9-5 16-1m19-1q8-5 14-2",
						stroke: "#7f4f30",
						strokeWidth: "2.7",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "m35 58 10 1m23-2 10-1",
						stroke: "#4f3f2c",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M46 57c-11 0-15 12-8 21 7 8 23 7 27-2 6-10-3-20-19-19z",
						fill: o
					}),
					/* @__PURE__ */ v("path", {
						d: "M40 61q-7 9 4 13",
						stroke: "#efb98c",
						strokeWidth: "2",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M49 92q9-5 21-1l-2 7-7 3-11-3z",
						fill: "#855338"
					}),
					/* @__PURE__ */ v("path", {
						d: "m52 94 1 4 5 1 1-5 4-1 1 5 4-2",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "m32 72 4 2m36-2 6-1m-44 9 6 2m33-5 4-1m-31 8 2 1m20-1 2-1",
						stroke: "#aa7650",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M26 100c4-5 6 7 12 2 6-5 5 8 12 2 7-6 6 8 13 1 6-6 6 7 12 0 7-6 9-3 10 5-5 4-9-2-13 2-6 5-9-3-13 2-6 4-9-3-14 1-5 2-9-4-13-1-5 2-9-8-6-14z",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "m33 104 2 8m10-6 2 7m10-6 2 7m10-6 1 4m10-6 1 4",
						stroke: "#b6a67c",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "m94 135 4-71",
						stroke: "#c59434",
						strokeWidth: "5"
					}),
					/* @__PURE__ */ v("path", {
						d: "M91 66q1-8 7-13 6 4 9 11l-4 9-9-1z",
						fill: a
					}),
					/* @__PURE__ */ v("path", {
						d: "m94 57-4-9 8 5 4-9 5 13",
						fill: a
					}),
					/* @__PURE__ */ v("circle", {
						cx: "91",
						cy: "48",
						r: "2.3",
						fill: a
					}),
					/* @__PURE__ */ v("circle", {
						cx: "103",
						cy: "45",
						r: "2.3",
						fill: a
					}),
					/* @__PURE__ */ v("path", {
						d: "M82 130c-3-7 0-19 6-22 5-3 8 2 8 5 8-1 11 6 7 11l-4 12H83z",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "m88 115 10 1m-10 5 10 1m-10 5 9 1",
						stroke: "#a97648",
						fill: "none"
					})
				] }),
				e === "nosey" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "M12 136c2-22 15-39 34-43l29 0c20 7 31 25 33 43",
						fill: u
					}),
					/* @__PURE__ */ v("path", {
						d: "m29 101 15-8 16 18-8 25H28l8-20m40-22 15 10-7 32H64l-4-25z",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "M33 45c7-18 25-20 41-10 19 12 21 33 15 49-4 17-17 24-30 22-16-3-25-16-28-29-6-13-5-23 2-32z",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M77 44c14 15 15 32 1 44l-21 13 11 4c19-7 27-25 23-43z",
						fill: "#a67042",
						opacity: ".5",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M28 46c-2 11-2 23 4 33l10-9-4-23m42-7 14 17-4 20-10-13",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "M19 32c12 1 18-10 23-23l19 7 14 2 17 22-30 7-33-1-15-6z",
						fill: u
					}),
					/* @__PURE__ */ v("path", {
						d: "M30 25c13 11 32 14 52 5m-42-17 9 10m17 1 8 4",
						stroke: "#cc9859",
						fill: "none",
						strokeWidth: "1.3"
					}),
					/* @__PURE__ */ v("path", {
						d: "M48 16c-3-8 1-14 8-13 9-7 23-2 26 6l-5 11-20 1z",
						fill: "#a49461"
					}),
					/* @__PURE__ */ v("path", {
						d: "M53 7c-3-10 8-12 10-4l-4 7m11-6c0-9 12-6 10 1l-6 5",
						fill: "#ba7871"
					}),
					/* @__PURE__ */ v("path", {
						d: "M78 13q14 9 16 0m-39 4-7 1m10 1-1 4m17-8 3 6",
						fill: "none",
						stroke: "#a18a55",
						strokeWidth: "1.3"
					}),
					/* @__PURE__ */ v("path", {
						d: "m48 13-7 4 9 2",
						fill: "#bfac7a"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "55",
						cy: "10",
						r: "1.5",
						fill: "#282d23"
					}),
					/* @__PURE__ */ v("path", {
						d: "M35 51q11-9 21-3m14-1q9-5 15-1",
						stroke: "#533729",
						strokeWidth: "3",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "m38 56 12-2m22-1 10-1",
						stroke: "#43362a",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M52 57C34 52 12 60 4 72c-5 9 4 12 14 10l38-10c8-2 10-9 5-12z",
						fill: o
					}),
					/* @__PURE__ */ v("path", {
						d: "M9 71q16-10 35-10M10 78q9 0 16-3",
						fill: "none",
						stroke: "#eac191",
						strokeWidth: "1.5"
					}),
					/* @__PURE__ */ v("path", {
						d: "m45 69 9 0",
						stroke: "#794b2e",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M38 86q20-9 43-4m-18 5 7 1m-20 8 10 2",
						fill: "none",
						stroke: "#785332",
						strokeWidth: "1.4"
					}),
					/* @__PURE__ */ v("path", {
						d: "m61 98 6 10 6-9",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "M86 55c12-9 24-1 14 9l-12 7",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "m92 59 8-2-6 7",
						stroke: "#a16f43",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M101 64c10 0 10 12 1 13",
						fill: "none",
						stroke: a,
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M18 136c-3-10-2-22 4-28l11 4 1 12 11 12m-22-24 1-21c0-8 7-9 8-2l0 20",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "m25 94 5 0m-6 6 6 0m-8 18 8 6m-6 0 7 8",
						stroke: "#a3724a",
						fill: "none"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "43",
						cy: "115",
						r: "4",
						fill: i
					}),
					/* @__PURE__ */ v("circle", {
						cx: "82",
						cy: "115",
						r: "4",
						fill: i
					}),
					/* @__PURE__ */ v("path", {
						d: "m42 112 1 1m38-1 1 1",
						stroke: "#d1ceb3"
					})
				] }),
				e === "bishop" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "M7 136c1-25 18-41 41-45l29 0c24 8 33 23 36 45",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "M31 43c13-17 35-15 50-3 18 14 22 40 13 57-6 15-23 22-43 16-20-7-29-25-28-42-2-12 1-21 8-28z",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M79 42c17 14 19 40 3 54l-25 11 10 8c27 0 36-22 30-45z",
						fill: "#b68251",
						opacity: ".45",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M27 50c-11-9-21 0-13 10l12 9m70-7c11-6 18 5 9 12l-9 2",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M29 37C23 22 33 7 45 1l13 30L72 0c15 10 23 26 20 42z",
						fill: a
					}),
					/* @__PURE__ */ v("path", {
						d: "M33 37 30 22 43 7l12 26M69 32 74 7q14 13 13 27",
						stroke: "#f0d78b",
						strokeWidth: "1.7",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "m45 11 3 19m-9-11 15-1",
						stroke: "#fff0b6",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ v("path", {
						d: "M30 36q26 7 60 3l-1 8-59-2z",
						fill: "#b28a34"
					}),
					/* @__PURE__ */ v("path", {
						d: "M29 46c-12 1-18 8-18 17l12 5 8-10m57-8q14-1 15 13l-10 3",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "M32 59q9-6 17-1m24 2 14 3",
						stroke: "#996a40",
						strokeWidth: "2.3",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M36 63q8 5 14 0m25 2 10 1",
						stroke: "#674932",
						strokeWidth: "1.8",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M60 61c-3 5-6 11-4 15 6 6 17 7 20 1 4-6-4-12-11-13",
						fill: o
					}),
					/* @__PURE__ */ v("path", {
						d: "m60 69 4 4 6 1",
						stroke: "#efbd8d",
						strokeWidth: "1.5",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M55 91q11-7 22 2c-2 6-12 8-19 4z",
						fill: "#9a6146"
					}),
					/* @__PURE__ */ v("path", {
						d: "M55 89q9-4 14-2",
						stroke: "#b67d53",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "m36 75 2 1m6 0 2 1m-7 6 1 1m44-5 2 1m-45 8q-3 12 10 17m19-3 10-3M38 113l-5 23m52-24 7 24",
						fill: "none",
						stroke: "#b18554"
					}),
					/* @__PURE__ */ v("path", {
						d: "M25 107q4 22 29 29m32-26-11 26",
						stroke: a,
						strokeWidth: "6",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M26 109q7 19 27 25m33-20-9 20",
						stroke: "#efe2ac",
						strokeWidth: "1.4",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M68 136c-4-10-3-22 2-30l7-9 10 2c5 6 3 12-2 15l3 22",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M79 104c-1-8-4-14-9-15-5-1-8 6-2 10l7 9",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "m73 108 9 2m-11 4 10 3m-10 3 10 3m-9 3 10 3",
						stroke: "#b58150",
						fill: "none"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "76",
						cy: "89",
						rx: "5",
						ry: "7",
						fill: a,
						transform: "rotate(25 76 89)"
					}),
					/* @__PURE__ */ v("path", {
						d: "m76 85-1 7m-2-5 5 1",
						stroke: "#8e692b",
						fill: "none"
					})
				] }),
				e === "shipowner" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "M9 136c-1-21 13-39 35-42l31-1c26 10 33 23 37 43",
						fill: u
					}),
					/* @__PURE__ */ v("path", {
						d: "M22 112q16-5 22-17l15 13-1 28H33m33-29 14-12 13 14-7 27H63",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "M24 40c9-16 29-22 47-11 20 12 26 32 22 50-3 19-19 30-37 29-21-1-33-14-36-29-5-15-4-29 4-39z",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "M79 39c15 17 16 37-1 51l-25 13 10 5c21-4 35-21 33-40z",
						fill: "#a16c46",
						opacity: ".5",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M22 46c-5 8-6 17-2 23l12 2 6-18m40-19 18 15-3 19-11-13",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "M11 30c10-1 19-13 27-23l20 12 25-5 21 22-15 12-28-6-29 5-23-8z",
						fill: "#943e2c"
					}),
					/* @__PURE__ */ v("path", {
						d: "M15 31q10 2 24-15l18 12 25-6 15 14M26 42q31-8 65-3",
						fill: "none",
						stroke: a,
						strokeWidth: "3"
					}),
					/* @__PURE__ */ v("path", {
						d: "m42 19 7 7m18-1 10-2m-53 9 6-4m57 3 6 5",
						stroke: "#efcf7d",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M27 54q9-8 19-3m18-3q13-8 21-2",
						stroke: "#67412b",
						strokeWidth: "3",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M30 59q8 6 16-1m20-2q10 5 17-2",
						stroke: "#6c4a31",
						strokeWidth: "1.8",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M52 54c-3 5-2 9-7 14-3 6 6 10 14 7 10-3 11-9 4-12l-6-6",
						fill: o
					}),
					/* @__PURE__ */ v("path", {
						d: "M50 64q-4 6 4 6",
						stroke: "#edc097",
						strokeWidth: "1.5",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M33 79q22 7 44-6c-2 12-16 20-31 17z",
						fill: "#69402d"
					}),
					/* @__PURE__ */ v("path", {
						d: "M36 79q20 5 38-3",
						stroke: "#f0d9ab",
						strokeWidth: "3",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M27 77q-5 8 2 16m49-25q10 0 11 6m-53 21q17 11 34-1m-25 8 12 2",
						fill: "none",
						stroke: "#ad784e"
					}),
					/* @__PURE__ */ v("path", {
						d: "M17 65c-15-8-19 4-7 13l14 2",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "m10 69 7 4",
						stroke: "#a9794e",
						fill: "none"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "17",
						cy: "84",
						r: "4.5",
						fill: "none",
						stroke: a,
						strokeWidth: "2.5"
					}),
					/* @__PURE__ */ v("path", {
						d: "M73 136c-2-16 2-28 14-33l15 3 9 30",
						fill: n
					}),
					/* @__PURE__ */ v("path", {
						d: "m81 114 14 1m-15 6 14 1m-13 5 14 1",
						stroke: "#aa764a",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M94 98c-6-12-5-23 4-27 10-2 17 8 12 18l-1 15 7 16-20-4z",
						fill: "#bc3c31"
					}),
					/* @__PURE__ */ v("path", {
						d: "M101 80c4-5 10-3 12 1l2 9-11 1-4-5",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "M109 81c9 1 12 6 9 12l-8-4",
						fill: a
					}),
					/* @__PURE__ */ v("circle", {
						cx: "107",
						cy: "82",
						r: "2",
						fill: "#2e3025"
					}),
					/* @__PURE__ */ v("path", {
						d: "M94 89c-8 3-9 14-3 20l7 4-1-18z",
						fill: "#9e3c30"
					}),
					/* @__PURE__ */ v("path", {
						d: "m96 99-2 8m3-4 3 7m1-15 4 4",
						stroke: "#df7350",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M90 108c-7-8-15-3-13 3l9 7 4 15",
						fill: n
					}),
					/* @__PURE__ */ v("circle", {
						cx: "87",
						cy: "117",
						r: "5",
						fill: a
					}),
					/* @__PURE__ */ v("circle", {
						cx: "87",
						cy: "117",
						r: "2.8",
						fill: "#9d542c"
					}),
					/* @__PURE__ */ v("path", {
						d: "m103 115 4 0m-7 1 1 3",
						stroke: "#483c25",
						strokeWidth: "1.5"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "42",
						cy: "121",
						r: "3",
						fill: a
					}),
					/* @__PURE__ */ v("path", {
						d: "m21 124 5 12m43-15 2 12",
						fill: "none",
						stroke: "#9b7847"
					})
				] }),
				e === "calypso" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "M21 136c-4-19 3-32 20-38l10-16 20-1 4 17c18 4 29 18 28 38",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "M30 45c4-20 23-29 41-20 20 9 22 32 15 53l-17 22-20-1c-18-6-26-20-27-35z",
						fill: f
					}),
					/* @__PURE__ */ v("path", {
						d: "M70 35c16 10 17 30 7 44l-22 15 8 6c19-4 29-20 28-39z",
						fill: "#385558",
						opacity: ".7",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M28 34c-9 13-9 32-6 52l-10 15 13 2 16-13-6-26m45-31c16 8 19 23 17 44l8 11-19 3-9-15z",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "M34 42c9 2 12 11 20 12 8-11 17-15 30-14l5 24c-9 9-18 9-25 4l-8-8-8 13-21-3-4-13z",
						fill: "#233336"
					}),
					/* @__PURE__ */ v("path", {
						d: "M29 58q9-10 19-1c-3 7-13 9-20 4zm35-2q12-9 21-2c-3 7-14 10-20 5z",
						fill: "#c6ca6e"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "40",
						cy: "58",
						rx: "2.5",
						ry: "3",
						fill: "#747a3d"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "74",
						cy: "55",
						rx: "2.5",
						ry: "3",
						fill: "#747a3d"
					}),
					/* @__PURE__ */ v("path", {
						d: "M27 55q12-7 23 0m13-2q13-7 22-3",
						fill: "none",
						stroke: "#172d30",
						strokeWidth: "2.5"
					}),
					/* @__PURE__ */ v("path", {
						d: "M50 61c-2 6-7 11-10 13-2 5 7 9 15 6 10-3 9-7 3-11l-3-6",
						fill: f
					}),
					/* @__PURE__ */ v("path", {
						d: "m44 74 9 2",
						stroke: "#e0e0cb",
						fill: "none",
						strokeWidth: "1.3"
					}),
					/* @__PURE__ */ v("path", {
						d: "M30 86q15-8 32-2l8 6-13 5-21-1z",
						fill: "#293337"
					}),
					/* @__PURE__ */ v("path", {
						d: "m35 89 22 1m-11-1 1 6m7-6 0 6",
						stroke: "#b2bbb0",
						strokeWidth: "1.2"
					}),
					/* @__PURE__ */ v("path", {
						d: "m29 100 9 2m0-6 2 8m8-8 0 9m8-9 0 8m9-10-2 8m-29 8 12 5 12-6",
						fill: "none",
						stroke: "#7e9690"
					}),
					/* @__PURE__ */ v("path", {
						d: "M25 29c6-14 23-19 42-13l21 18-18 8-31-1z",
						fill: "#6d4b6c"
					}),
					/* @__PURE__ */ v("path", {
						d: "M29 31q25-6 50 3m-44-5 0 8m8-9 0 7m8-7 0 7m8-6 0 7m8-5 0 6",
						fill: "none",
						stroke: "#bf93b6",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M27 23c-8-14-4-25 10-29h34c10 4 17 12 18 24l-14 9-36-2z",
						fill: a
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "43",
						cy: "10",
						rx: "10",
						ry: "14",
						fill: "#3e3346",
						transform: "rotate(-15 43 10)"
					}),
					/* @__PURE__ */ v("path", {
						d: "M39 4q8-6 11 3v8l-7 6-6-7z",
						fill: "none",
						stroke: "#b390a3"
					}),
					/* @__PURE__ */ v("path", {
						d: "m40 9 6 0m-5-5 0 12m4-12 0 12m-7-5 10 0",
						stroke: "#b390a3"
					}),
					/* @__PURE__ */ v("path", {
						d: "M50 3c13 9 26 7 37 3M30 22q25 8 53 1",
						fill: "none",
						stroke: "#84632f"
					}),
					/* @__PURE__ */ v("path", {
						d: "M83 81c13 2 19 11 14 20-4 8-17 8-23 1-6-8-1-18 9-21z",
						fill: a
					}),
					/* @__PURE__ */ v("path", {
						d: "M79 88q10-3 12 7l-5 4-9-2z",
						fill: "#d3a058"
					}),
					/* @__PURE__ */ v("path", {
						d: "m82 91 2 0m4 0 2 0m-6 4 5 0",
						stroke: "#925d2e",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("path", {
						d: "m11 20 11 110",
						stroke: "#3a2b35",
						strokeWidth: "4"
					}),
					/* @__PURE__ */ v("path", {
						d: "m4 9 14-3 5 14-16 4z",
						fill: a
					}),
					/* @__PURE__ */ v("circle", {
						cx: "15",
						cy: "35",
						r: "5",
						fill: "#96344e"
					}),
					/* @__PURE__ */ v("path", {
						d: "m14 41-6 26 14 17-6-25m-2 6 8 15 0 16-11-8",
						fill: "#a3356b"
					}),
					/* @__PURE__ */ v("path", {
						d: "M17 102c-10-8-15 0-9 5-7 1-5 9 1 11-6 3-3 10 4 10l3 8h15l-1-26-7-9z",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "m9 108 12 0m-11 10 13 1m-9 9 10 0",
						stroke: "#697572",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M41 111q7 6 16 0m-21 12 13 5m23-15 7 6m9-3 5 2",
						stroke: "#82656a",
						fill: "none"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "49",
						cy: "125",
						r: "3",
						fill: a
					})
				] }),
				e === "oracle" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "M13 136c-2-17 4-31 11-42 1-31 0-63 8-87 16 0 36 8 52 22 11 25 12 49 22 71l-12 16 7 20",
						fill: d
					}),
					/* @__PURE__ */ v("path", {
						d: "M34 23c-3 30-7 53-3 73l18 27h24l17-29c-8-16-9-39-17-54z",
						fill: c
					}),
					/* @__PURE__ */ v("path", {
						d: "M41 47c13-9 30-4 36 10 5 16 0 34-10 41-11 5-23-2-29-14-8-12-8-25 3-37z",
						fill: p
					}),
					/* @__PURE__ */ v("path", {
						d: "M66 53c13 14 10 31-3 39l-10 1 7 9c15-1 22-18 19-32z",
						fill: "#7d5a7b",
						opacity: ".6",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M31 7c20 6 35 17 49 32L68 19 40 4zm-7 38c-6 26-2 45-8 59l14 12 9-16-6-33M82 42c-3 29 2 44 10 62l10-4-15-32",
						fill: "#6676a5",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M34 28q15-5 30 8l0 18-29-4z",
						fill: "#68628c"
					}),
					/* @__PURE__ */ v("path", {
						d: "M37 34q12-3 24 4m-26 8 28 4",
						stroke: "#a3a6cb",
						fill: "none",
						strokeWidth: "1.2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M40 40q8-8 17 1l-9 4z",
						fill: "none",
						stroke: "#d3c2df",
						strokeWidth: "1.5"
					}),
					/* @__PURE__ */ v("path", {
						d: "m47 32 0 4m-8-2 2 3m14-1 3-2",
						stroke: "#d3c2df",
						strokeWidth: "1.4"
					}),
					/* @__PURE__ */ v("path", {
						d: "M43 49c-12-2-26 8-26 19 0 11 15 9 22 1l13-4 6-9z",
						fill: p
					}),
					/* @__PURE__ */ v("path", {
						d: "M25 64q5-8 16-10m-18 17 6-3",
						stroke: "#e7b9d3",
						strokeWidth: "1.7",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M42 78q12-8 25 0l-7 5-15-1z",
						fill: "#6f365a"
					}),
					/* @__PURE__ */ v("path", {
						d: "M44 79q9-2 17 1",
						stroke: "#d8a0c5",
						strokeWidth: "1.5",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M34 49q8 6 16 2m11 14 5 1m-20 24 11 1",
						stroke: "#916480",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M37 89c-7 19-7 35 0 47h25l7-17-13-20-10 0z",
						fill: p
					}),
					/* @__PURE__ */ v("path", {
						d: "M42 105 39 83c0-7 7-8 8-1l3 20m-1-1 0-20c1-8 8-7 8 0l-1 27 5 10-4 18",
						fill: p
					}),
					/* @__PURE__ */ v("path", {
						d: "m41 86 4 0m5-2 5 0m-13 16 5 1m-6 9 10 1m-9 7 11 2",
						fill: "none",
						stroke: "#8c6182"
					}),
					/* @__PURE__ */ v("path", {
						d: "m41 83 1 7 3 0 0-8zm10-2 0 8 3-1 1-7z",
						fill: "#566c9b",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M24 111q5 16 9 25h-17m51-27q7 16 5 27h26l-9-29",
						fill: d
					}),
					/* @__PURE__ */ v("path", {
						d: "M30 31c-4 24-4 44-6 61m55-43 9 40m-63 26 5 18m46-21 8 18",
						stroke: "#8998b9",
						fill: "none",
						strokeWidth: "1.2"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "70",
						cy: "115",
						r: "9",
						fill: "#497573",
						stroke: "#bfd2b8",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "70",
						cy: "115",
						r: "6",
						fill: "none",
						stroke: "#8aa89b"
					}),
					/* @__PURE__ */ v("path", {
						d: "m67 113 5-3 2 4-5 4-2-2",
						fill: "none",
						stroke: "#c3d0b3"
					})
				] }),
				e === "lookout" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "M36 112c-13 3-18 10-17 24h79c0-12-6-22-18-26z",
						fill: u
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "58",
						cy: "114",
						rx: "38",
						ry: "9",
						fill: "#4b4535"
					}),
					/* @__PURE__ */ v("path", {
						d: "M24 116q33 8 69-2l-2 22H26z",
						fill: u
					}),
					/* @__PURE__ */ v("path", {
						d: "M29 119q1 9 3 16m12-13 1 13m17-13v14m18-16-1 16",
						stroke: "#453b2d",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M24 119q34 7 68-3m-65 16q30 5 62-3",
						fill: "none",
						stroke: "#77724e",
						strokeWidth: "4"
					}),
					/* @__PURE__ */ v("path", {
						d: "M25 118q33 7 66-3m-62 16q30 5 59-3",
						fill: "none",
						stroke: "#b0a570"
					}),
					/* @__PURE__ */ v("path", {
						d: "M74 31c13 6 15 19 12 34-2 13-7 25-6 40l-13 8-15-3c-9-16-8-33-1-48l8-23z",
						fill: d
					}),
					/* @__PURE__ */ v("path", {
						d: "M74 45c9 17 5 34 0 48l-3 15 10-3c-1-15 5-27 5-41 1-9-2-15-5-20z",
						fill: "#19283e",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M54 64q8 6 22 2m-24 7q10 5 23 2m-23 8q8 5 21 1m-19 10 16 1",
						stroke: "#6976a0",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M76 44c-10-2-18 4-20 16 0 15-2 32-7 42l-8 7 5 2c13-4 21-13 23-26l2-23z",
						fill: "#4a4368"
					}),
					/* @__PURE__ */ v("path", {
						d: "M60 29c-2-12 9-20 20-17 12 2 18 10 14 21-4 11-14 18-27 17l-8-9z",
						fill: d
					}),
					/* @__PURE__ */ v("path", {
						d: "M66 14c-2-5 2-9 8-9l17 4 9-1-5 10-10 5-21-1z",
						fill: s
					}),
					/* @__PURE__ */ v("path", {
						d: "M67 11q13-3 22 3l-8 8-15-1m20-8 8 0",
						stroke: "#c1ad86",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M68 21c-1-8 12-12 17-4 3 6-4 13-11 12-4 0-7-3-6-8z",
						fill: "#203938",
						stroke: "#a3b6a0",
						strokeWidth: "1.4"
					}),
					/* @__PURE__ */ v("path", {
						d: "M72 19q5-6 10-1m-13 6 3 3",
						stroke: "#d2dac2",
						fill: "none"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "76",
						cy: "21",
						rx: "4",
						ry: "4.8",
						fill: "#091f26"
					}),
					/* @__PURE__ */ v("circle", {
						cx: "78",
						cy: "18",
						r: "1.8",
						fill: "#8fa5a2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M67 48c3 6 7 7 13 6m-10 2q5 4 10 2m-8-23 12 4",
						stroke: "#a3a1c2",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M56 29c-15-7-22-6-31-5l-2 10 21 5c-8 8-14 18-17 29l-7 22 7-5-3 14 8-7-1 12 9-9 1 9c12-15 18-35 16-57l7-9z",
						fill: "#9c3640"
					}),
					/* @__PURE__ */ v("path", {
						d: "M46 42c-7 10-13 26-16 39m20-31-10 35m10-20-4 25m-12-34-8 20m11-10-7 19m17-47-18-6",
						stroke: "#cf695f",
						fill: "none",
						strokeWidth: "1.3"
					}),
					/* @__PURE__ */ v("path", {
						d: "M31 33c6 2 14 4 21 3m-15-7 10 3m-16 21-4 5",
						stroke: "#e3876b",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M83 53c10 15 10 34 10 50l-7 9-2-8-4 6-2-10 1-16-2-22z",
						fill: "#b03c43"
					}),
					/* @__PURE__ */ v("path", {
						d: "M83 64q7 16 5 31m-4-17-1 19m6 0-2 9m-4-7-1 5",
						stroke: "#dd7266",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M67 39c-9-13-31-13-35 0-4 13 3 23 18 24l14-3c-9-3-6-10 2-11l7-1z",
						fill: a
					}),
					/* @__PURE__ */ v("path", {
						d: "M38 38q11-9 24 0m-25 6q4 11 12 12",
						stroke: "#f5d87d",
						strokeWidth: "2",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M35 54q12 9 28 5l-9 6-13-3z",
						fill: "#9c5a20",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M59 101c-2 4-3 9-1 13m14-11-1 12",
						stroke: "#a99b50",
						strokeWidth: "3",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M54 114q7-5 13 0l-4 3m5-2q8-5 14-1l-4 4m-22-5-4 3m21-3-4 5",
						stroke: "#d0b967",
						strokeWidth: "1.8",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M98 3 96 117",
						stroke: "#9b8852",
						strokeWidth: "2.4"
					}),
					/* @__PURE__ */ v("path", {
						d: "m96 45 7 0-5 7m-2 13 6-2m-6 24 6 0",
						stroke: "#506045",
						strokeWidth: "3",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M15 17 55 24 53 35 14 32z",
						fill: "#43625d"
					}),
					/* @__PURE__ */ v("path", {
						d: "M17 18 17 32m18-11-1 13m12-11-1 12",
						stroke: a,
						strokeWidth: "3"
					}),
					/* @__PURE__ */ v("path", {
						d: "m20 20 22 4",
						stroke: "#8dada2",
						fill: "none"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "15",
						cy: "25",
						rx: "11",
						ry: "13",
						fill: "#607d76",
						stroke: "#244947",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "15",
						cy: "25",
						rx: "7",
						ry: "9",
						fill: "#b8caca"
					}),
					/* @__PURE__ */ v("ellipse", {
						cx: "14",
						cy: "25",
						rx: "4.2",
						ry: "5.7",
						fill: "#0a2832"
					}),
					/* @__PURE__ */ v("path", {
						d: "M11 20q2-3 5-1",
						stroke: "#e0ebe3",
						strokeWidth: "1.7",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M8 12q7-8 20-8l-2 5-17 7z",
						fill: "#29473e"
					}),
					/* @__PURE__ */ v("path", {
						d: "m11 11 13-5",
						stroke: "#9db9a3",
						fill: "none"
					})
				] }),
				e === "witch" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("path", {
						d: "M12 136C7 108 20 84 24 65c4-22 16-44 32-61l14 30 17-10c13 37 13 74 24 112z",
						fill: d
					}),
					/* @__PURE__ */ v("path", {
						d: "M30 101c1-25 6-48 20-61l20 7c16 27 13 55 12 89H28z",
						fill: "#182b45"
					}),
					/* @__PURE__ */ v("path", {
						d: "M46 48c6-9 15-6 20 1 10 10 12 24 8 37l-6 16-23-1c-11-16-12-39 1-53z",
						fill: p
					}),
					/* @__PURE__ */ v("path", {
						d: "M64 51c13 15 11 32-2 43l6 8c15-8 16-33 5-48z",
						fill: "#6c688d",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M42 57c2-6 10-8 13-3 2 5-1 10-5 14l-7 2c-4-3-5-8-1-13zm22-3c6-3 12 4 11 10-1 6-7 3-11-1-3-3-4-6 0-9z",
						fill: "#263e5e"
					}),
					/* @__PURE__ */ v("path", {
						d: "M44 58q4-6 7-1c1 3-2 8-4 9l-4-2zm23 0q5-1 5 4l-1 3-4-3z",
						fill: "#b2c8da",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M56 66c-4 7-8 13-8 17 3 1 5-2 8-2l7 3c-1-8-3-13-5-16",
						fill: "#4a496c"
					}),
					/* @__PURE__ */ v("path", {
						d: "M50 91c4-7 11-7 16 0l2 8c-7-5-12-3-19 2z",
						fill: "#3b4366"
					}),
					/* @__PURE__ */ v("path", {
						d: "M51 94q7-8 14 0m-12-5 1 5m3-6 0 5m4-4 0 5M43 74q-5 7-1 11m27-12q8 7 2 14",
						stroke: "#cad5df",
						strokeWidth: "1.1",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M43 47c-11 26-7 55-14 69l8-4 6-33m25-31c15 18 16 45 15 70l9 9-5-33-7-36",
						fill: "#493b68"
					}),
					/* @__PURE__ */ v("path", {
						d: "M29 64c-2-23 8-42 27-60L44 38 40 60zm39-27 17-13-5 26 15 34-4 16-9-33M16 136c-4-23 3-48 14-60l1 28-9 32",
						fill: "#716c9e",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M34 50c-1 17-9 33-11 48m21-54 7-22m17 18 7 12m7 24 8 29M37 107l-1 27m47-24 8 24",
						stroke: "#a29ac6",
						strokeWidth: "1.2",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M17 101c-8-21-6-34 0-48l8-5 9 9-5 19-1 28",
						fill: p
					}),
					/* @__PURE__ */ v("path", {
						d: "M19 60c-5-7-10-12-10-18-1-7 5-9 8-3l8 13m-6-8-2-18c0-7 7-8 8-2l3 21m-1-6 6-14c3-5 8-3 6 3l-6 22",
						fill: p
					}),
					/* @__PURE__ */ v("path", {
						d: "m12 44 5 3m3-17 5 1m3 12 5 2m-16 18 11 3m-12 4 10 3m-8 6 8 3",
						stroke: "#8d729b",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M8 93q9 6 22 1l5 42H10z",
						fill: d
					}),
					/* @__PURE__ */ v("path", {
						d: "M15 103q4 12 3 30",
						stroke: "#aa9cc5",
						fill: "none",
						strokeWidth: "1.2"
					}),
					/* @__PURE__ */ v("path", {
						d: "M37 36c12 5 30 5 46 3l-2 9-40-3-16 8-7-5z",
						fill: d
					}),
					/* @__PURE__ */ v("path", {
						d: "M27 45q24-8 53-4",
						stroke: "#a2a5cc",
						fill: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "M72 113c-20-8-27 14-11 20-25 4-29-24-9-29 8-3 16 1 20 9z",
						fill: "#c4e4e2",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "m39 108 2-5 2 5 6 0-4 4 1 6-5-3-5 2 1-5-4-4zm39-10 2-4 2 5 5 0-4 3 0 5-4-3-4 2 2-5-3-3z",
						fill: "#c4e4e2",
						stroke: "none"
					}),
					/* @__PURE__ */ v("path", {
						d: "m46 126 2-1m26-6 2 1m-22-15 1 1m13 24 2-1",
						stroke: "#c1d3dd"
					})
				] })
			]
		})]
	});
}
//#endregion
//#region src/games/jamaica/view-player.tsx
var lt = {
	oracle: "games.jamaica.oracle",
	arrange: "games.jamaica.arrange",
	load: "games.jamaica.load",
	pay: "games.jamaica.pay",
	route: "games.jamaica.route",
	distance: "games.jamaica.distance",
	enemy: "games.jamaica.enemy",
	lair: "games.jamaica.lair",
	treasure: "games.jamaica.treasurePrompt",
	recruit: "games.jamaica.recruitPrompt",
	ghost: "games.jamaica.ghostPrompt",
	powder: "games.jamaica.powderPrompt",
	reroll: "games.jamaica.rerollPrompt",
	loot: "games.jamaica.lootPrompt"
}, ut = {
	sail: "games.jamaica.events.sail",
	retreat: "games.jamaica.events.retreat",
	load: "games.jamaica.events.load",
	pay: "games.jamaica.events.pay",
	discard: "games.jamaica.events.discard",
	ignored: "games.jamaica.events.ignored",
	shortage: "games.jamaica.events.shortage",
	treasure: "games.jamaica.events.treasure",
	battle: "games.jamaica.events.battle",
	winBattle: "games.jamaica.events.winBattle",
	drawBattle: "games.jamaica.events.drawBattle",
	recruit: "games.jamaica.events.recruit",
	steal: "games.jamaica.events.steal",
	destroy: "games.jamaica.events.destroy",
	curse: "games.jamaica.events.curse",
	finish: "games.jamaica.events.finish",
	calypso: "games.jamaica.events.calypso",
	end: "games.jamaica.events.end"
};
function dt({ crew: e, compact: t = !1 }) {
	let n = l(), r = E[e];
	return /* @__PURE__ */ y("div", {
		className: `jamaica-crew-card${t ? " jamaica-crew-compact" : ""}`,
		children: [/* @__PURE__ */ v(Z, { crew: e }), /* @__PURE__ */ y("div", { children: [
			/* @__PURE__ */ v("strong", { children: n(D[e]) }),
			/* @__PURE__ */ v("small", { children: n("games.jamaica.crewPoints", {
				arrived: r[0],
				sailing: r[1]
			}) }),
			!t && /* @__PURE__ */ v("p", { children: n(ce[e]) })
		] })]
	});
}
function ft({ id: e, crewSet: t = !1 }) {
	let n = l(), r = !e || e === "?" ? n("games.jamaica.privateTreasure") : P[e] ? n(P[e]) : n("games.jamaica.treasurePoints", { n: N[e] ?? 0 });
	return /* @__PURE__ */ y("div", {
		className: "jamaica-treasure-card",
		title: r,
		children: [/* @__PURE__ */ v(J, {
			id: e,
			crewSet: t
		}), /* @__PURE__ */ v("span", { children: r })]
	});
}
function pt({ hold: e, index: t, rid: n, choices: r, choose: i, inspect: a }) {
	let o = l(), { ref: c, hidden: u } = s(`hold:${n}:${t}`), d = r.find((e) => e.hold === t && [
		"store",
		"replace",
		"pay"
	].includes(e.kind)), f = e?.kind === "crew" ? e.crew : null;
	return /* @__PURE__ */ y("button", {
		ref: c,
		className: `jamaica-hold${d ? " jamaica-hold-legal" : ""}`,
		"aria-label": d ? o(d.kind === "pay" ? "games.jamaica.payHold" : d.kind === "replace" ? "games.jamaica.replace" : "games.jamaica.store", {
			n: t + 1,
			amount: d.n ?? 0,
			resource: d.resource && d.resource in T ? o(T[d.resource]) : ""
		}) : o("games.jamaica.hold", { n: t + 1 }),
		disabled: !d && !f,
		onClick: () => {
			d ? i(d.id) : f && a(f);
		},
		children: [
			/* @__PURE__ */ v("small", {
				className: "jamaica-hold-number",
				children: t + 1
			}),
			/* @__PURE__ */ v("div", {
				className: "jamaica-hold-content",
				style: { visibility: u ? "hidden" : void 0 },
				children: f ? /* @__PURE__ */ v(Z, { crew: f }) : e ? /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v(q, {
					kind: e.kind,
					size: 38
				}), /* @__PURE__ */ v("b", { children: e.n })] }) : /* @__PURE__ */ v("span", {
					className: "jamaica-empty-hold",
					children: o("games.jamaica.empty")
				})
			}),
			d && /* @__PURE__ */ v(tt, {})
		]
	});
}
function mt({ pub: e, inspect: t }) {
	let n = l();
	return /* @__PURE__ */ v("div", {
		className: "jamaica-tavern",
		children: /* @__PURE__ */ v("div", {
			className: "jamaica-tavern-tray",
			children: e.market.map((r, i) => /* @__PURE__ */ v("div", {
				className: "jamaica-tavern-slot",
				children: r === "?" ? /* @__PURE__ */ v("span", {
					className: "jamaica-crew-back",
					"aria-label": n("games.jamaica.facedownCrew"),
					children: /* @__PURE__ */ v(q, {
						kind: "crew",
						size: 24
					})
				}) : r ? /* @__PURE__ */ v("button", {
					title: n(D[r]),
					"aria-label": n("games.jamaica.inspect", { name: n(D[r]) }),
					onClick: () => t(r),
					children: /* @__PURE__ */ v(Z, { crew: r })
				}) : i === e.bottle ? /* @__PURE__ */ v("span", {
					className: "jamaica-bottle",
					"aria-label": n("games.jamaica.bottle"),
					children: /* @__PURE__ */ v(J, { id: "rum" })
				}) : /* @__PURE__ */ v("span", { className: "jamaica-tray-empty" })
			}, i))
		})
	});
}
function ht({ ships: e, crewSet: t, nameOf: n, inspect: r, selectShip: i }) {
	let a = l();
	return /* @__PURE__ */ v("div", {
		className: "jamaica-fleet",
		children: e.map((e) => /* @__PURE__ */ y("section", { children: [
			/* @__PURE__ */ y("button", {
				className: "jamaica-fleet-name",
				onClick: () => i(e.rid),
				children: [a("games.jamaica.ship", { name: n(e.rid) }), /* @__PURE__ */ v(f, { size: 15 })]
			}),
			/* @__PURE__ */ v("div", {
				className: "jamaica-holds",
				children: e.holds.map((t, n) => /* @__PURE__ */ v(pt, {
					hold: t,
					index: n,
					rid: e.rid,
					choices: [],
					choose: () => {},
					inspect: r
				}, n))
			}),
			e.treasures.length > 0 && /* @__PURE__ */ v("div", {
				className: "jamaica-treasures",
				children: e.treasures.map((e, n) => /* @__PURE__ */ v(ft, {
					id: e,
					crewSet: t
				}, n))
			})
		] }, e.rid))
	});
}
function gt({ choice: e, pub: t, choose: n, nameOf: r }) {
	let i = l(), a = "", o = null, s = e.n ?? 0, c = (e.hold ?? 0) + 1, u = r(e.rid ?? "");
	switch (e.kind) {
		case "dice":
			a = i("games.jamaica.dicePair", {
				day: s,
				night: e.cost ?? 0
			}), o = /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("span", {
				className: "jamaica-die",
				children: s
			}), /* @__PURE__ */ v("span", {
				className: "jamaica-die jamaica-die-night",
				children: e.cost
			})] });
			break;
		case "roll":
			a = i("games.jamaica.roll");
			break;
		case "die":
			a = i("games.jamaica.die", { n: s }), o = /* @__PURE__ */ v("span", {
				className: "jamaica-die",
				children: s
			});
			break;
		case "skip":
			a = i("games.jamaica.skip");
			break;
		case "keep":
			a = i("games.jamaica.keep");
			break;
		case "forward":
		case "backward":
			a = i("games.jamaica.move", {
				action: i(T[e.kind]),
				n: s
			}), o = /* @__PURE__ */ v(q, { kind: e.kind });
			break;
		case "space": {
			let t = k[e.node];
			a = t.kind === "royal" ? i("games.jamaica.royal") : i("games.jamaica.space", {
				kind: i(t.kind === "lair" ? "games.jamaica.treasures" : t.kind === "gold" ? "games.jamaica.port" : "games.jamaica.sea"),
				n: t.cost
			}), o = t.kind === "lair" ? /* @__PURE__ */ v(q, { kind: "lair" }) : /* @__PURE__ */ v(q, { kind: t.kind === "gold" ? "gold" : "food" });
			break;
		}
		case "store":
		case "replace":
			a = i(e.kind === "store" ? "games.jamaica.store" : "games.jamaica.replace", { n: c }), o = /* @__PURE__ */ v(q, { kind: e.resource === "crew" ? "crew" : e.resource });
			break;
		case "pay":
			a = i("games.jamaica.payHold", {
				n: c,
				amount: s,
				resource: i(T[e.resource])
			}), o = /* @__PURE__ */ v(q, { kind: e.resource });
			break;
		case "powder":
			a = i("games.jamaica.fire", { n: s }), o = /* @__PURE__ */ v(q, { kind: "powder" });
			break;
		case "attack":
		case "raid":
			a = i(e.kind === "attack" ? "games.jamaica.attack" : "games.jamaica.raid", { name: u });
			break;
		case "reroll":
			a = i("games.jamaica.reroll", { name: u });
			break;
		case "stealHold":
		case "destroy": {
			a = i(e.kind === "destroy" ? "games.jamaica.destroyHold" : "games.jamaica.stealHold", { n: c });
			let n = t.ships.find((e) => e.rid === (t.battle?.attacker === t.battle?.winner ? t.battle?.defender : t.battle?.attacker))?.holds[e.hold];
			o = n?.kind === "crew" ? /* @__PURE__ */ v(Z, { crew: n.crew }) : n ? /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v(q, { kind: n.kind }), /* @__PURE__ */ v("b", { children: n.n })] }) : null;
			break;
		}
		case "stealTreasure":
			a = i("games.jamaica.stealTreasure"), o = /* @__PURE__ */ v(J, { hidden: !0 });
			break;
		case "giveCurse":
			a = i("games.jamaica.giveCurse", { n: N[e.treasure] }), o = /* @__PURE__ */ v(J, {
				id: e.treasure,
				crewSet: t.config.crew
			});
			break;
		case "treasure":
			a = !e.treasure || e.treasure === "?" ? i("games.jamaica.privateTreasure") : P[e.treasure] ? i(P[e.treasure]) : i("games.jamaica.treasurePoints", { n: N[e.treasure] }), o = /* @__PURE__ */ v(J, {
				id: e.treasure,
				crewSet: t.config.crew
			});
			break;
		case "recruit": a = i("games.jamaica.recruitChoice", {
			name: i(D[e.crew]),
			n: e.cost ?? 0
		}), o = /* @__PURE__ */ v(Z, { crew: e.crew });
	}
	return /* @__PURE__ */ y("button", {
		className: "jamaica-choice",
		onClick: () => n(e.id),
		children: [
			o && /* @__PURE__ */ v("span", {
				className: "jamaica-choice-art",
				children: o
			}),
			/* @__PURE__ */ v("span", { children: a }),
			/* @__PURE__ */ v(tt, {})
		]
	});
}
function _t(e) {
	te();
	let t = l(), n = c((e) => e.locale), r = e.public, i = e.private, s = (r) => r === "$ghost" ? t("games.jamaica.ghost") : e.members.find((e) => e.rid === r) ? ie(e.members.find((e) => e.rid === r), n) : r, [u, d] = a(null), [m, h] = a(!1), [ee, ae] = a(e.myRid), [b, x] = a(null), [S, C] = a(null), oe = `${e.myRid}:${r.round}:${r.phase}`, [w, se] = a(oe);
	w !== oe && (se(oe), d(null), h(!1));
	let E = r.phase !== "done" && r.prompt?.actor === e.myRid, ce = E ? i?.choices ?? [] : [], O = r.phase === "select" && i?.selected === null, le = r.ships.find((t) => t.rid === e.myRid), A = E && ["load", "pay"].includes(r.prompt.kind) ? r.prompt.rid : ee, j = r.ships.find((e) => e.rid === A) ?? le ?? r.ships[0], M = (t) => {
		E && e.send({
			type: "choose",
			id: t
		});
	}, N = r.phase === "done" ? t("games.jamaica.result") : O ? t("games.jamaica.select") : E ? t(lt[r.prompt.kind] ?? "games.jamaica.resolving") : r.prompt ? t("games.jamaica.waiting", { name: s(r.prompt.actor) }) : r.phase === "select" ? t("games.jamaica.selected") : t("games.jamaica.resolving"), ue = j.rid === e.myRid && i ? i.treasures : j.treasures, de = E && j.rid === r.prompt?.rid ? ce : [], fe = le?.holds.some((e) => e?.crew === "witch"), P = r.ships.filter((e) => e.card !== null);
	return /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v(ne, {
		adaptive: !0,
		className: "jamaica-screen",
		scroll: !1,
		actionsHeight: "jamaica-actions-height",
		banner: /* @__PURE__ */ y("div", {
			className: "jamaica-top",
			children: [
				/* @__PURE__ */ v(g, {
					text: N,
					chip: t("games.jamaica.round", { n: r.round }),
					tone: r.phase === "done" ? "done" : E || O ? "accent" : "info",
					accent: me.accent
				}),
				/* @__PURE__ */ y("div", {
					className: "jamaica-helm",
					children: [
						/* @__PURE__ */ y("div", {
							className: "jamaica-dice-pair",
							children: [/* @__PURE__ */ y("span", { children: [t("games.jamaica.day"), /* @__PURE__ */ v("b", {
								className: "jamaica-die",
								children: r.dice[0] || "·"
							})] }), /* @__PURE__ */ y("span", { children: [t("games.jamaica.night"), /* @__PURE__ */ v("b", {
								className: "jamaica-die jamaica-die-night",
								children: r.dice[1] || "·"
							})] })]
						}),
						/* @__PURE__ */ v("strong", {
							className: "jamaica-captain",
							children: t("games.jamaica.captain", { name: s(r.captain) })
						}),
						/* @__PURE__ */ v("button", {
							className: "jamaica-tool",
							"aria-label": t("games.jamaica.details"),
							onClick: () => x("fleet"),
							children: /* @__PURE__ */ v(f, { size: 20 })
						}),
						/* @__PURE__ */ v("button", {
							className: "jamaica-tool",
							"aria-label": t("games.jamaica.log"),
							onClick: () => x("log"),
							children: /* @__PURE__ */ v(p, { size: 20 })
						}),
						r.config.crew && /* @__PURE__ */ v("button", {
							className: "jamaica-tool",
							"aria-label": t("games.jamaica.tavern"),
							onClick: () => x("tavern"),
							children: /* @__PURE__ */ v(q, {
								kind: "crew",
								size: 25
							})
						})
					]
				}),
				/* @__PURE__ */ v(re, {
					adaptive: !0,
					variant: "mini",
					scroll: !0,
					members: e.members.filter((e) => r.ships.some((t) => t.rid === e.rid)),
					myRid: e.myRid,
					anchorOf: (e) => `seat:${e}`,
					onPick: ae,
					picked: (e) => j.rid === e,
					action: (e) => r.phase === "select" ? r.ships.find((t) => t.rid === e)?.picked ? "done" : "pending" : (r.prompt?.actor ?? r.active) === e ? "pending" : null
				})
			]
		}),
		actions: /* @__PURE__ */ v("div", {
			className: "jamaica-actions",
			children: O ? /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("div", {
				className: "jamaica-hand",
				children: i.hand.map((e) => /* @__PURE__ */ v(ct, {
					card: e,
					selected: u === e,
					selectable: u === null,
					dice: m ? [...r.dice].reverse() : r.dice,
					onClick: () => d(e)
				}, e))
			}), /* @__PURE__ */ y("div", {
				className: "jamaica-confirm",
				children: [fe && /* @__PURE__ */ y("label", { children: [/* @__PURE__ */ v("input", {
					type: "checkbox",
					checked: m,
					onChange: (e) => h(e.target.checked)
				}), t("games.jamaica.swap")] }), /* @__PURE__ */ v("button", {
					className: "jamaica-main-button",
					disabled: u === null,
					onClick: () => {
						u !== null && e.send({
							type: "select",
							card: u,
							swap: m
						});
					},
					children: t("games.jamaica.confirm")
				})]
			})] }) : ce.length ? /* @__PURE__ */ v("div", {
				className: "jamaica-choices",
				children: ce.map((e) => /* @__PURE__ */ v(gt, {
					choice: e,
					pub: r,
					choose: M,
					nameOf: s
				}, e.id))
			}) : /* @__PURE__ */ v("div", {
				className: "jamaica-waiting-actions",
				children: P.length ? P.map((e) => /* @__PURE__ */ y("div", {
					className: "jamaica-revealed-card",
					children: [/* @__PURE__ */ v("span", { children: s(e.rid) }), /* @__PURE__ */ v(ct, {
						card: e.card,
						dice: e.swap ? [...r.dice].reverse() : r.dice
					})]
				}, e.rid)) : /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v(q, {
					kind: "forward",
					size: 44
				}), /* @__PURE__ */ v("strong", { children: N })] })
			})
		}),
		overlay: r.battle && r.active && /* @__PURE__ */ y("div", {
			className: "jamaica-battle",
			children: [
				/* @__PURE__ */ v("strong", { children: t("games.jamaica.battle", {
					a: s(r.battle.attacker),
					d: s(r.battle.defender)
				}) }),
				/* @__PURE__ */ y("div", { children: [
					/* @__PURE__ */ y("span", { children: [
						r.battle.a === -1 ? t("games.jamaica.star") : r.battle.a ?? "—",
						" + ",
						r.battle.powderA
					] }),
					/* @__PURE__ */ v("span", { children: " / " }),
					/* @__PURE__ */ y("span", { children: [
						r.battle.d === -1 ? t("games.jamaica.star") : r.battle.d ?? "—",
						" + ",
						r.battle.powderD
					] })
				] }),
				r.battle.winner && /* @__PURE__ */ v("b", { children: t("games.jamaica.winBattle", { name: s(r.battle.winner) }) })
			]
		}),
		children: /* @__PURE__ */ y("div", {
			className: "jamaica-table",
			children: [/* @__PURE__ */ v(st, {
				pub: r,
				members: e.members,
				choices: ce,
				choose: M,
				nameOf: s
			}), /* @__PURE__ */ y("aside", {
				className: "jamaica-manifest",
				children: [
					/* @__PURE__ */ y("header", { children: [/* @__PURE__ */ v("strong", { children: t("games.jamaica.ship", { name: s(j.rid) }) }), /* @__PURE__ */ y("span", {
						title: t("games.jamaica.tokenCount", { n: j.tokens }),
						children: [/* @__PURE__ */ v(q, {
							kind: "lair",
							size: 20
						}), j.tokens]
					})] }),
					/* @__PURE__ */ v("div", {
						className: "jamaica-holds",
						children: j.holds.map((e, t) => /* @__PURE__ */ v(pt, {
							rid: j.rid,
							hold: e,
							index: t,
							choices: de,
							choose: M,
							inspect: C
						}, t))
					}),
					/* @__PURE__ */ v("div", {
						className: "jamaica-treasures",
						children: ue.map((e, t) => /* @__PURE__ */ v(ft, {
							id: e,
							crewSet: r.config.crew
						}, t))
					}),
					/* @__PURE__ */ v("div", {
						className: "jamaica-crew-list",
						children: j.holds.flatMap((e, t) => e?.kind === "crew" ? /* @__PURE__ */ y("button", {
							onClick: () => C(e.crew),
							children: [/* @__PURE__ */ v(dt, {
								crew: e.crew,
								compact: !0
							}), /* @__PURE__ */ v(f, { size: 16 })]
						}, t) : [])
					}),
					/* @__PURE__ */ v("div", {
						className: "jamaica-desktop-fleet",
						children: /* @__PURE__ */ v(ht, {
							crewSet: r.config.crew,
							ships: r.ships.filter((e) => e.rid !== j.rid),
							nameOf: s,
							inspect: C,
							selectShip: ae
						})
					}),
					r.config.crew && /* @__PURE__ */ y("section", {
						className: "jamaica-desktop-tavern",
						children: [/* @__PURE__ */ v("h2", { children: t("games.jamaica.tavern") }), /* @__PURE__ */ v(mt, {
							pub: r,
							inspect: C
						})]
					})
				]
			})]
		})
	}), /* @__PURE__ */ y("div", {
		className: "jamaica-dialogs",
		children: [/* @__PURE__ */ v(o, {
			open: b !== null,
			onClose: () => x(null),
			label: t(b === "log" ? "games.jamaica.log" : b === "fleet" ? "games.jamaica.details" : "games.jamaica.tavern"),
			title: t(b === "log" ? "games.jamaica.log" : b === "fleet" ? "games.jamaica.details" : "games.jamaica.tavern"),
			tall: !0,
			children: /* @__PURE__ */ v("div", {
				className: "jamaica-sheet",
				children: b === "fleet" ? /* @__PURE__ */ v(ht, {
					crewSet: r.config.crew,
					ships: r.ships,
					nameOf: s,
					inspect: C,
					selectShip: (e) => {
						ae(e), x(null);
					}
				}) : b === "tavern" ? /* @__PURE__ */ v(mt, {
					pub: r,
					inspect: C
				}) : /* @__PURE__ */ v("ol", {
					className: "jamaica-log",
					children: r.log.map((e, n) => {
						let r = e.node === void 0 ? null : k[e.node], i = r ? r.kind === "royal" ? t("games.jamaica.royal") : r.kind === "lair" ? t("games.jamaica.treasures") : t("games.jamaica.space", {
							kind: t(r.kind === "gold" ? "games.jamaica.port" : "games.jamaica.sea"),
							n: r.cost
						}) : "";
						return /* @__PURE__ */ v("li", { children: t(ut[e.kind] ?? "games.jamaica.events.end", {
							name: s(e.rid),
							n: e.n ?? 0,
							target: s(e.target ?? ""),
							node: i,
							resource: e.resource === "crew" ? t("games.jamaica.crewScore") : e.resource && e.resource in T ? t(T[e.resource]) : ""
						}) }, n);
					})
				})
			})
		}), /* @__PURE__ */ v(o, {
			open: S !== null,
			onClose: () => C(null),
			label: t("games.jamaica.details"),
			title: S ? t(D[S]) : "",
			children: /* @__PURE__ */ v("div", {
				className: "jamaica-sheet",
				children: S && /* @__PURE__ */ v(dt, { crew: S })
			})
		})]
	})] });
}
//#endregion
//#region src/games/jamaica/bot.ts
var vt = {
	progress: 1.8,
	shortage: 4,
	treasure: 3,
	crew: 1,
	combat: 1.6
}, yt = (e, t) => e.reduce((e, n) => e + (n?.kind === t ? n.n : 0), 0);
function Q(e, t, n) {
	if (t === "gold") return n;
	if (t === "crew") return n * 4;
	let r = yt(e, t);
	return n * (t === "food" ? r < 3 ? 1.8 : r < 7 ? 1 : .45 : r < 3 ? .65 : .3);
}
function bt(e, t) {
	return (E[e]?.[1] ?? 0) + ({
		strategist: 6,
		buccaneer: 0,
		beth: 2,
		saran: 2,
		cooper: 5,
		venetian: 5,
		prussian: 3,
		helvetian: 4,
		seafarer: 5,
		anchoree: 2,
		seadog: 2,
		cartographer: 4,
		king: 1,
		nosey: 4,
		bishop: 2,
		shipowner: 2,
		calypso: 0,
		oracle: 5,
		lookout: 4,
		witch: 4
	}[e] ?? 0) * Math.min(1, A(t) / 16);
}
function $(e, t, n) {
	return e ? e.kind === "crew" ? bt(e.crew, n) : Q(t, e.kind, e.n) : 0;
}
function xt(e, t, n) {
	let r = Ce(e, t), i = e.flatMap((e, t) => e && e.kind !== "crew" && r.includes(e.kind) ? [t] : []).sort((t, n) => {
		let r = e[t], i = e[n];
		return Q(e, r.kind, 1) - Q(e, i.kind, 1) || r.n - i.n;
	});
	for (let t of i) {
		let r = e[t], i = Math.min(n, r.n);
		if (r.n -= i, n -= i, r.n || (e[t] = null), !n) break;
	}
}
function St(e, t, n) {
	if (t === 0 || n && e === 32) return [e];
	let r = n ? k[e].next : k[e].previous;
	return r.length ? [...new Set(r.flatMap((e) => St(e, t - 1, n)))] : [e];
}
function Ct(e, t, n, r, i) {
	if (e.node === 32) return e;
	if (t === "forward" || t === "backward") {
		let a = null, o = R({ holds: e.holds }), s = [n];
		o.includes("seafarer") && s.push(n + 1), o.includes("anchoree") && s.push(Math.max(0, n - 1)), o.includes("seadog") && t === "backward" && s.push(0);
		for (let n of s) for (let s of St(e.node, n, t === "forward")) {
			let t = structuredClone(e.holds), c = k[s], l = e.value + i.progress * (A(e.node) - A(s));
			if (n && (c.kind === "food" || c.kind === "gold")) {
				let e = K(t, c.kind), n = Math.min(e, c.cost);
				if (l -= Q(t, c.kind, n), xt(t, c.kind, n), e < c.cost) {
					l -= i.shortage;
					for (let e = 0; e < 60 && s !== 0; e++) {
						let e = [...k[s].previous].sort((e, t) => A(e) - A(t))[0];
						l -= i.progress * Math.max(0, A(e) - A(s)), s = e;
						let n = k[s];
						if (n.kind !== "food" && n.kind !== "gold" || K(t, n.kind) >= n.cost) {
							(n.kind === "food" || n.kind === "gold") && (l -= Q(t, n.kind, n.cost), xt(t, n.kind, n.cost));
							break;
						}
					}
				}
			}
			r.lairs.includes(s) && (l += i.treasure), s === 32 && (l += 8), r.ships.some((t) => t.node === s && t.rid !== "$ghost" && t.node !== e.node) && !o.includes("strategist") && (l -= .7);
			let u = {
				node: s,
				holds: t,
				value: l
			};
			(!a || l > a.value) && (a = u);
		}
		return a ?? e;
	}
	let a = structuredClone(e.holds), o = n + +!!R({ holds: a }).includes("cooper"), s = a.indexOf(null), c = s >= 0 ? [s] : a.flatMap((e, n) => e?.kind === t ? [] : [n]);
	if (!c.length) return e;
	let l = c.reduce((t, n) => $(a[n], a, e.node) < $(a[t], a, e.node) ? n : t, c[0]), u = e.value + Q(a, t, o) - $(a[l], a, e.node);
	return a[l] = {
		kind: t,
		n: o
	}, {
		...e,
		holds: a,
		value: u
	};
}
function wt(e, t, n, r, i) {
	let a = {
		node: t.node,
		holds: structuredClone(t.holds),
		value: 0
	};
	for (let [t, o] of w[n].entries()) a = Ct(a, o, e.dice[r ? 1 - t : t], e, i);
	return a.value;
}
function Tt(e, t, n, r) {
	let i = t.prompt?.rid ?? n, a = t.ships.find((e) => e.rid === i), o = e.rid ? t.ships.find((t) => t.rid === e.rid) : null;
	switch (e.kind) {
		case "store": return 0;
		case "replace": return -$(a.holds[e.hold], a.holds, a.node);
		case "pay": return -Q(a.holds, e.resource, e.n) + (a.holds[e.hold].n === e.n ? .3 : 0);
		case "space": {
			let n = k[e.node], i = n.kind === "food" || n.kind === "gold" ? n.cost : 0, o = n.kind === "food" || n.kind === "gold" ? K(a.holds, n.kind) >= i : !0;
			return -A(e.node) * r.progress - (o ? i * .2 : r.shortage * 2) + (t.lairs.includes(e.node) ? r.treasure : 0);
		}
		case "forward": return e.n * r.progress;
		case "backward": return -e.n * r.progress;
		case "dice": return (e.n - e.cost) * .01;
		case "recruit": {
			let t = a.holds.some((e) => !e) ? 0 : Math.min(...a.holds.filter((e) => e?.kind !== "crew").map((e) => $(e, a.holds, a.node)));
			return r.crew * bt(e.crew, a.node) - e.cost - t - (a.holds.filter(Boolean).length >= 4 ? .8 : 0);
		}
		case "skip":
		case "keep": return 0;
		case "stealHold": return Q(a.holds, e.resource, e.n) + (e.crew ? bt(e.crew, a.node) : 0) + .2 * $(o.holds[e.hold], o.holds, o.node);
		case "destroy": return $(o.holds[e.hold], o.holds, o.node);
		case "stealTreasure": return 3.6;
		case "giveCurse": return -(N[e.treasure] ?? 0) * 1.25;
		case "treasure": return N[e.treasure] ?? (e.treasure === "?" ? 2 : e.treasure === "hold" ? 6 : e.treasure === "map" ? 5 : 4);
		case "attack":
		case "raid": return o ? -K(o.holds, "powder") + (R({ holds: a.holds }).includes("strategist") ? 20 : 0) + Math.max(0, ...o.holds.map((e) => $(e, o.holds, o.node))) * (e.kind === "raid" ? .4 : .1) : 0;
		case "powder": {
			let n = t.battle, o = n.attacker === i, s = R({ holds: a.holds }).includes("beth") || a.treasures.includes("beth") ? 2 : 0, c = o ? n.defender : n.attacker, l = t.ships.find((e) => e.rid === c), u = R({ holds: l.holds }).includes("beth") || l.treasures.includes("beth") ? 2 : 0, d = o ? 6 + Math.min(2, K(l.holds, "powder")) + u : n.a + n.powderA + u, f = Math.max(3, ...l.holds.map((e) => $(e, l.holds, l.node)));
			return ([
				2,
				4,
				6,
				8,
				10
			].filter((t) => t + e.n + s > d).length / 6 + 1 / 6) * f * r.combat - e.n * .65;
		}
		case "reroll": {
			let n = t.battle, r = n.attacker === i ? "a" : "d", a = e.rid === n.attacker ? "a" : "d", o = n[a];
			if (o === null) return -100;
			let s = o === -1 ? -12 : 6 - o;
			return a === r ? s : -s;
		}
		case "die": return e.n * .1;
		case "roll": return 0;
		default: return 0;
	}
}
function Et(e) {
	let t = Math.floor(4294967296 / e.length) * e.length, n = /* @__PURE__ */ new Uint32Array(1);
	do
		crypto.getRandomValues(n);
	while (n[0] >= t);
	return e[n[0] % e.length];
}
function Dt(e = vt) {
	return (t, n) => {
		let r = t.public, i = t.private, a = r.ships.find((e) => e.rid === n.rid);
		if (!i || !a || r.phase === "done") return null;
		if (r.phase === "select" && i.selected === null) {
			let t = i.hand.flatMap((e) => [!1, ...R({ holds: a.holds }).includes("witch") ? [!0] : []].map((t) => ({
				card: e,
				swap: t
			}))), o = n.difficulty === "weak" ? Et(t) : t.reduce((t, n) => wt(r, a, n.card, n.swap, e) > wt(r, a, t.card, t.swap, e) ? n : t, t[0]);
			return o ? { action: {
				type: "select",
				...o
			} } : null;
		}
		if (r.prompt?.actor !== n.rid || !i.choices.length) return null;
		let o = (t) => {
			if (r.phase === "arrange") {
				let n = {
					...r,
					dice: [t.n, t.cost]
				};
				return Math.max(...i.hand.map((t) => wt(n, a, t, !1, e)));
			}
			return r.phase === "oracle" && t.kind === "die" ? Array.from({ length: 6 }, (n, o) => Math.max(...i.hand.flatMap((n) => [!1, !0].map((i) => wt({
				...r,
				dice: [t.n, o + 1]
			}, a, n, i, e))))).reduce((e, t) => e + t, 0) / 6 : Tt(t, r, n.rid, e);
		};
		return { action: {
			type: "choose",
			id: (n.difficulty === "weak" ? Et(i.choices) : i.choices.reduce((e, t) => o(t) > o(e) ? t : e, i.choices[0])).id
		} };
	};
}
var Ot = Dt(), kt = (e, t, n) => e.type === "select" ? n("games.jamaica.confirm") : e.type === "choose" ? n("games.jamaica.select") : "", At = {
	sail(e, t) {
		let n = e.data, r = t.anchor(`ship:${e.rid}`), i = t.anchor("map-bounds"), a = t.anchor("map-unit");
		if (!r || !i || !a || t.queued) return null;
		let o = a.w / 100, s = i.w / o, c = i.h / o, l = r.h / o < 45 ? 44 : 58, u = (e, t, n) => {
			let r = le(e, t, n);
			return {
				x: Math.max(34, Math.min(s - 34, k[e].x / 100 * s + r.x)),
				y: Math.max(32, Math.min(c - (r.rows - 1) * l - 48, k[e].y / 100 * c)) + r.row * l
			};
		}, d = u(n.from, n.fromRank, n.fromCount), f = u(n.to, n.toRank, n.toCount), p = {
			...r,
			x: r.x + (d.x - f.x) * o,
			y: r.y + (d.y - f.y) * o
		}, m = t.member(e.rid ?? "");
		return {
			ms: I.sail - 20,
			hide: [`ship:${e.rid}`],
			node: /* @__PURE__ */ v(S, {
				from: p,
				to: r,
				ms: I.sail - 30,
				children: /* @__PURE__ */ v("span", {
					style: {
						display: "block",
						width: r.w,
						height: r.h
					},
					children: /* @__PURE__ */ v(et, {
						color: b[m?.colorIndex ?? 0]?.hex,
						number: e.rid === "$ghost" ? void 0 : n.number,
						ghost: e.rid === j
					})
				})
			})
		};
	},
	load(e, t) {
		let n = e.data, r = t.anchor(`hold:${e.rid}:${n.hold}`), i = t.anchor(`seat:${e.rid}`) ?? t.anchor(`ship:${e.rid}`);
		if (!r || !i || t.queued) return null;
		let a = Math.min(36, r.w), o = {
			x: r.x + (r.w - a) / 2,
			y: r.y + (r.h - a) / 2,
			w: a,
			h: a
		};
		return {
			ms: I.event - 40,
			hide: [`hold:${e.rid}:${n.hold}`],
			node: /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v(S, {
				from: {
					...i,
					w: a,
					h: a
				},
				to: o,
				ms: 350,
				children: /* @__PURE__ */ v("span", {
					className: "jamaica-crew-flight",
					style: {
						display: "block",
						width: a,
						height: a
					},
					children: n.crew ? /* @__PURE__ */ v(Z, { crew: n.crew }) : /* @__PURE__ */ v(q, {
						kind: n.kind ?? "gold",
						size: a
					})
				})
			}), /* @__PURE__ */ y(x, {
				at: o,
				ms: 470,
				delay: 30,
				children: ["+", n.n]
			})] })
		};
	},
	pay(e, t) {
		let n = e.data, r = t.anchor(`hold:${e.rid}:${n.hold}`) ?? t.anchor(`seat:${e.rid}`);
		return r ? {
			ms: I.event - 40,
			node: /* @__PURE__ */ v(x, {
				at: r,
				ms: I.event - 50,
				children: /* @__PURE__ */ y("span", {
					style: {
						display: "inline-flex",
						alignItems: "center",
						background: "#f3dfb0",
						color: "#674329",
						padding: "3px 6px",
						borderRadius: 5
					},
					children: [
						"−",
						n.n,
						/* @__PURE__ */ v(q, {
							kind: n.kind ?? "gold",
							size: 23
						})
					]
				})
			})
		} : null;
	},
	combat(e, t) {
		let n = t.anchor(`ship:${e.rid}`), r = e.data;
		return n ? {
			ms: I.battle - 40,
			node: /* @__PURE__ */ v(x, {
				at: n,
				ms: I.battle - 60,
				children: /* @__PURE__ */ v("span", {
					style: {
						display: "inline-grid",
						placeItems: "center",
						width: 46,
						height: 43,
						border: "2px solid #70512f",
						borderRadius: 8,
						background: "#f3dfb0",
						color: "#412e23",
						fontSize: 27
					},
					children: r.face === -1 ? /* @__PURE__ */ v(q, {
						kind: "star",
						size: 29
					}) : r.face
				})
			})
		} : null;
	},
	battleResult(e, t) {
		let n = t.anchor(`ship:${e.rid}`);
		return n ? {
			ms: I.event - 30,
			node: /* @__PURE__ */ v(C, {
				at: n,
				ms: I.event - 40
			})
		} : null;
	},
	reveal(e, t) {
		let n = t.anchor(`seat:${t.myRid}`);
		return n ? {
			ms: I.reveal - 60,
			node: /* @__PURE__ */ v(C, {
				at: n,
				ms: I.reveal - 70
			})
		} : null;
	},
	treasure(e, t) {
		let n = t.anchor(`ship:${e.rid}`);
		return n ? {
			ms: I.event - 30,
			node: /* @__PURE__ */ v(x, {
				at: n,
				ms: I.event - 40,
				children: /* @__PURE__ */ v(q, {
					kind: "lair",
					size: 35
				})
			})
		} : null;
	},
	loot(e, t) {
		let n = t.anchor(`ship:${e.rid}`);
		return n ? {
			ms: I.event - 30,
			node: /* @__PURE__ */ v(C, {
				at: n,
				ms: I.event - 40
			})
		} : null;
	}
}, jt = [
	["games.jamaica.positionScore", "position"],
	["games.jamaica.goldScore", "gold"],
	["games.jamaica.treasureScore", "treasure"],
	["games.jamaica.crewScore", "crew"]
];
function Mt(e) {
	let t = l(), r = c((e) => e.locale), o = e.public, [s, f] = a(!0), [m, h] = a(null), ee = i(null), te = i(null), ne = (t) => {
		let n = e.members.find((e) => e.rid === t);
		return n ? ie(n, r) : t;
	}, g = (e) => {
		h(null), f(e), e || requestAnimationFrame(() => te.current?.focus());
	};
	return n(() => {
		s && ee.current?.querySelector("button")?.focus({ preventScroll: !0 });
	}, [s]), /* @__PURE__ */ y("div", {
		className: "jamaica-endgame",
		children: [
			/* @__PURE__ */ v("div", {
				className: "jamaica-review-board",
				inert: s,
				children: /* @__PURE__ */ v(_t, {
					public: e.public,
					private: e.private,
					members: e.members,
					myRid: e.myRid,
					send: () => {}
				})
			}),
			/* @__PURE__ */ v("div", {
				className: "jamaica-ledger-mask",
				hidden: !s,
				children: /* @__PURE__ */ y("section", {
					ref: ee,
					role: "dialog",
					"aria-modal": "true",
					"aria-label": t("games.jamaica.result"),
					className: "jamaica-ledger",
					onKeyDown: (e) => {
						if (e.key === "Escape" && (e.stopPropagation(), g(!1)), e.key === "Tab") {
							let t = Array.from(ee.current?.querySelectorAll("button:not(:disabled)") ?? []), n = t[0], r = t.at(-1);
							e.shiftKey && document.activeElement === n ? (e.preventDefault(), r?.focus()) : !e.shiftKey && document.activeElement === r && (e.preventDefault(), n?.focus());
						}
					},
					children: [
						/* @__PURE__ */ y("header", { children: [/* @__PURE__ */ y("div", { children: [/* @__PURE__ */ v("span", { children: "JAMAICA" }), /* @__PURE__ */ v("h1", { children: t("games.jamaica.result") })] }), /* @__PURE__ */ v("button", {
							"aria-label": t("games.jamaica.reviewHide"),
							title: t("games.jamaica.reviewHide"),
							onClick: () => g(!1),
							children: /* @__PURE__ */ v(d, { size: 23 })
						})] }),
						/* @__PURE__ */ y("div", {
							className: "jamaica-ledger-body",
							children: [
								o.specialWinner && /* @__PURE__ */ v("p", {
									className: "jamaica-calypso-win",
									children: t("games.jamaica.calypsoWin", { name: ne(o.specialWinner) })
								}),
								e.hintCount !== void 0 && /* @__PURE__ */ v("p", {
									className: "jamaica-hints",
									children: t("games.jamaica.hintCount", { n: e.hintCount })
								}),
								/* @__PURE__ */ v("div", {
									className: "jamaica-ledger-table-scroll",
									children: /* @__PURE__ */ y("table", { children: [
										/* @__PURE__ */ v("thead", { children: /* @__PURE__ */ y("tr", { children: [/* @__PURE__ */ v("th", { scope: "col" }), e.result.ranking.map((n, r) => {
											let i = e.members.find((e) => e.rid === n);
											return /* @__PURE__ */ y("th", {
												scope: "col",
												"data-winner": e.result.winner.includes(n) || void 0,
												children: [
													/* @__PURE__ */ v("span", {
														className: "jamaica-result-ship",
														children: /* @__PURE__ */ v(et, {
															color: b[i?.colorIndex ?? 0]?.hex,
															number: o.ships.findIndex((e) => e.rid === n) + 1
														})
													}),
													/* @__PURE__ */ v("strong", { children: ne(n) }),
													/* @__PURE__ */ v("small", { children: e.result.winner.includes(n) ? `♛ ${t("games.jamaica.winner")}` : `#${r + 1}` }),
													!!e.result.autopilot?.[n] && /* @__PURE__ */ y("small", {
														className: "jamaica-autopilot",
														children: [/* @__PURE__ */ v(u, { size: 13 }), t("games.jamaica.autopilot", { n: Math.round(e.result.autopilot[n] * 100) })]
													})
												]
											}, n);
										})] }) }),
										/* @__PURE__ */ v("tbody", { children: jt.filter(([, e]) => e !== "crew" || o.config.crew).map(([n, r]) => /* @__PURE__ */ y("tr", { children: [/* @__PURE__ */ v("th", {
											scope: "row",
											children: t(n)
										}), e.result.ranking.map((t) => /* @__PURE__ */ v("td", {
											"data-winner": e.result.winner.includes(t) || void 0,
											children: o.ships.find((e) => e.rid === t)?.score?.[r] ?? "—"
										}, t))] }, r)) }),
										/* @__PURE__ */ v("tfoot", { children: /* @__PURE__ */ y("tr", { children: [/* @__PURE__ */ v("th", {
											scope: "row",
											children: t("games.jamaica.total")
										}), e.result.ranking.map((t) => /* @__PURE__ */ v("td", {
											"data-winner": e.result.winner.includes(t) || void 0,
											children: e.result.scores?.[t] ?? "—"
										}, t))] }) })
									] })
								})
							]
						}),
						/* @__PURE__ */ v("footer", { children: m ? /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("button", {
							className: "jamaica-main-button",
							onClick: () => {
								let t = m;
								h(null), t === "again" && e.onPlayAgain?.(), t === "lobby" && e.onBackToLobby?.();
							},
							children: t(m === "again" ? "games.jamaica.confirmAgain" : "games.jamaica.confirmLobby")
						}), /* @__PURE__ */ v("button", {
							onClick: () => h(null),
							children: t("games.jamaica.cancel")
						})] }) : /* @__PURE__ */ y(_, { children: [
							e.onBackToLobby && /* @__PURE__ */ v("button", {
								onClick: () => h("lobby"),
								children: t("games.jamaica.lobby")
							}),
							e.onPlayAgain && /* @__PURE__ */ v("button", {
								className: "jamaica-main-button",
								onClick: () => h("again"),
								children: t("games.jamaica.again")
							}),
							!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ v("span", { children: t("games.jamaica.waitHost") })
						] }) })
					]
				})
			}),
			/* @__PURE__ */ v("div", {
				className: "jamaica-review-toolbar",
				hidden: s,
				children: /* @__PURE__ */ y("button", {
					ref: te,
					className: "jamaica-main-button",
					onClick: () => g(!0),
					children: [/* @__PURE__ */ v(p, { size: 18 }), t("games.jamaica.reviewShow")]
				})
			})
		]
	});
}
//#endregion
//#region src/games/jamaica/options.tsx
function Nt({ value: e, onChange: t }) {
	let n = l(), r = F.safeParse(e), i = r.success ? r.data : F.parse(void 0);
	return /* @__PURE__ */ y("div", { children: [/* @__PURE__ */ v(oe, {
		checked: i.crew,
		label: n("games.jamaica.crewOption"),
		hint: n("games.jamaica.crewHint"),
		accent: me.accent,
		onChange: () => t({
			...i,
			crew: !i.crew
		})
	}), /* @__PURE__ */ v(oe, {
		checked: i.extra,
		label: n("games.jamaica.extraOption"),
		hint: n("games.jamaica.extraHint"),
		accent: me.accent,
		onChange: () => t({
			...i,
			extra: !i.extra
		})
	})] });
}
//#endregion
//#region .bgparty/cache/pack-entry/jamaica/entry.tsx
var Pt = {
	definition: $e,
	View: _t,
	bot: Ot,
	describe: kt,
	fx: At,
	OverView: Mt,
	Options: Nt,
	locales: {
		zh: {
			name: "牙买加",
			desc: "扬帆绕岛、争夺宝藏，在海盗竞速中赚取最多金币。",
			rules: "目标：绕牙买加岛航行并积累财富。有人到达皇家港后，其他船只完成本轮；位置分、货舱金币、宝藏分和船员分合计最高者获胜。平分时较接近终点者胜，再平分则共享胜利。\n准备：每人拥有 11 张行动牌，手牌 3 张、五个货舱；分别装入 3 金币和 3 食物。九个海盗巢穴各放一枚宝藏标记，宝藏牌洗混后随机保留九张。\n日夜行动：队长掷两枚骰子并决定日夜顺序，所有人暗选一张牌。全部选好后，从队长开始按座位顺序行动，每人先完整完成白天行动，再完成夜晚行动。之后补足手牌并传递队长；牌堆用尽时洗混弃牌。行动牌左侧为白天、右侧为夜晚，行动数量取对应骰值。\n装货：将金币、食物或火药放入一个空舱，不能添入已有同类资源的舱。所有舱都满时，必须丢弃一个不同类型舱的全部内容，再装入新资源；全为同类时忽略装货。船员每人占一舱，也不能用新船员替换已有船员。\n航行：前进或后退对应格数，经过分叉时自行选路，只支付最终落点费用。海域支付白色菱形数量的食物，港口支付标示金币；皇家港与海盗巢穴免费。落点有其他船时先战斗，再支付费用。首次取得巢穴标记时抽取一张宝藏，分值和诅咒宝藏保密至终局，特殊宝藏立即公开。\n短缺：付出当前可支付的全部资源，然后后退到第一个付得起费用的位置，分叉仍自行选择。到达新位置后，先处理战斗，再支付新费用并收取可获得的宝藏。不能用尚未执行的夜晚装货支付白天费用。\n战斗：攻击者先决定消耗多少火药，再掷战斗骰；防守者看过结果后决定火药并掷骰。普通骰值加火药及能力修正后比较，较高者获胜，平手无事发生。星号直接获胜；攻击者掷出星号时防守者不能掷骰。胜者选择抢走败者一个完整货舱、抢一张宝藏，或把自己一张诅咒宝藏交给败者。抢货仍遵守装货规则。\n基础宝藏：分值为 3、4、5、6、7；诅咒为负 2、负 3、负 4。摩根的地图使手牌上限为 4；莎兰的军刀每场战斗允许把自己或对手的一次骰值重掷，第二次必须接受；贝丝夫人使战斗力增加 2；第六货舱增加一个舱，被夺走时舱内物品一并转移。\n终局：完成一圈的船停止剩余行动并获得 15 位置分。终点前各格依次为 10 至 2 分；红色分界及更远的格均为负 5 分。再加上货舱金币、宝藏和船员分。\n双人：增加幽灵船，初始两个货舱分别装 5 金币与 3 金币，持有不可夺取的贝丝夫人。两名玩家行动后，幽灵船按日夜骰移动两次；领先时后退，最后时前进，居中和分叉由队长决定。幽灵船免付费用并收取隐藏宝藏；战斗由其对手以外的玩家控制，抢来的非金币货物丢弃，不能送出诅咒。幽灵船参与竞速并可触发终局，但不参与玩家排名。\n可选扩展：\n· 额外宝藏：加入朗姆酒、六分仪、船锚。朗姆酒每次装货增加一个资源；六分仪允许多移动一格；船锚允许少移动一格。\n· The Crew：以船员扩展的 12 张宝藏替换基础宝藏，20 名船员随机放入招募托盘。完整支付港费后，可选择招募。朗姆瓶只能在连通的空位移动，每步支付一个金币，然后招募相邻船员；新空位边界上的船员立即翻开。船员的上下分值分别用于已到达皇家港与尚未到达的情况。\n· 船员能力：贝丝爵士战斗力增加 2；莎兰允许一次战斗重掷；海盗可攻击相邻船，获胜时丢弃对方一个指定货舱，失败无事发生；战略家作为攻击者自动获胜；船东使每名船员额外获得 3 分；好奇鬼取得宝藏时可查看最多三张并选一张；国王只提供分值；主教使每枚已收集标记额外获得 2 分；制图师使手牌上限为 4；老水手可忽略后退行动；抛锚手与航海家分别允许少或多移动一格；三名商人允许在支付时相互替换对应两类资源，能力可组合；桶匠每次装货增加一个资源；卡吕普索与三张诅咒护符同时在船时立即获胜；女巫可对自己交换日夜骰；神谕者当队长时可在掷骰前指定其中一骰；瞭望员可从相邻格收集一个宝藏标记。\n· 扩展宝藏：八张正分宝藏、三张诅咒护符和一张公开的 12 分钻石。好奇鬼未选中的牌保留在原处，从牌堆查看的未选牌重新混回剩余牌堆。",
			gold: "金币",
			food: "食物",
			powder: "火药",
			forward: "前进",
			backward: "后退",
			sea: "海域",
			port: "港口",
			tokenCount: "宝藏标记 {{n}} 枚",
			bottle: "朗姆瓶",
			facedownCrew: "未翻开的船员",
			crewPoints: "抵达 {{arrived}} / 未抵达 {{sailing}}",
			day: "白天",
			night: "夜晚",
			round: "第 {{n}} 轮",
			captain: "队长：{{name}}",
			ghost: "幽灵船",
			royal: "皇家港",
			select: "选择一张行动牌",
			confirm: "打出所选行动牌",
			selected: "等待其他玩家选牌",
			resolving: "航行中",
			waiting: "等待 {{name}}",
			oracle: "指定一枚骰子，或正常掷骰",
			arrange: "安排日夜骰子",
			load: "选择装货的货舱",
			pay: "选择支付资源的货舱",
			route: "选择航路",
			distance: "选择移动格数",
			enemy: "选择交战船只",
			lair: "选择宝藏巢穴",
			treasurePrompt: "选择一张宝藏",
			recruitPrompt: "招募船员，或放弃招募",
			ghostPrompt: "决定幽灵船的航行方向",
			powderPrompt: "选择消耗的火药数量",
			rerollPrompt: "决定是否重掷战斗骰",
			lootPrompt: "选择战利品",
			roll: "正常掷骰",
			skip: "放弃",
			keep: "接受骰值",
			die: "指定 {{n}} 点",
			move: "{{action}} {{n}} 格",
			space: "{{kind}} · {{n}}",
			store: "装入第 {{n}} 舱",
			replace: "弃货后装入第 {{n}} 舱",
			payHold: "从第 {{n}} 舱支付 {{amount}} {{resource}}",
			fire: "消耗 {{n}} 火药",
			attack: "攻击 {{name}}",
			raid: "袭击相邻的 {{name}}",
			reroll: "重掷 {{name}} 的战斗骰",
			stealHold: "夺取第 {{n}} 舱",
			destroyHold: "丢弃对方第 {{n}} 舱",
			stealTreasure: "夺取一张宝藏",
			giveCurse: "交出 {{n}} 分诅咒",
			recruitChoice: "招募 {{name}} · 支付 {{n}} 金币",
			dicePair: "白天 {{day}} · 夜晚 {{night}}",
			hold: "第 {{n}} 舱",
			empty: "空舱",
			privateTreasure: "隐藏宝藏",
			treasurePoints: "{{n}} 分宝藏",
			ship: "{{name}} 的船",
			treasures: "宝藏",
			cargo: "货舱",
			tavern: "港口酒馆",
			chart: "海图",
			details: "船只详情",
			log: "航海日志",
			swap: "女巫：交换自己的日夜骰",
			inspect: "查看 {{name}}",
			cardAria: "白天{{day}}，夜晚{{night}}",
			zoomIn: "放大海图",
			zoomOut: "缩小海图",
			resetMap: "显示完整海图",
			finish: "已抵达",
			battle: "{{a}} 对战 {{d}}",
			star: "星号",
			winBattle: "{{name}} 获胜",
			drawBattle: "战斗平手",
			finalRound: "最后一轮",
			errTurn: "当前不能行动。",
			errChoice: "请选择当前可用的行动。",
			on: "启用",
			off: "关闭",
			expansions: "扩展",
			crewOption: "The Crew 船员扩展",
			crewHint: "20 名船员与替换宝藏",
			extraOption: "额外宝藏",
			extraHint: "加入朗姆酒、六分仪与船锚",
			result: "皇家港航海账簿",
			reviewHide: "收起账簿，回看海图",
			reviewShow: "查看结算账簿",
			positionScore: "航程",
			goldScore: "金币",
			treasureScore: "宝藏",
			crewScore: "船员",
			total: "总分",
			winner: "获胜",
			calypsoWin: "{{name}} 集齐三张诅咒护符并拥有卡吕普索，立即获胜。",
			again: "再来一局",
			lobby: "返回大厅",
			confirmAgain: "确认重新开始",
			confirmLobby: "确认返回大厅",
			cancel: "取消",
			waitHost: "等待主机决定",
			hintCount: "本局提示 {{n}} 次",
			autopilot: "托管 {{n}}%",
			crew: {
				strategist: "战略家",
				buccaneer: "海盗",
				beth: "贝丝爵士",
				saran: "莎兰",
				cooper: "桶匠",
				venetian: "威尼斯商人",
				prussian: "普鲁士商人",
				helvetian: "瑞士商人",
				seafarer: "航海家",
				anchoree: "抛锚手",
				seadog: "老水手",
				cartographer: "制图师",
				king: "国王",
				nosey: "好奇鬼",
				bishop: "主教",
				shipowner: "船东",
				calypso: "卡吕普索",
				oracle: "神谕者",
				lookout: "瞭望员",
				witch: "女巫"
			},
			power: {
				strategist: "作为攻击者时自动赢得战斗。",
				buccaneer: "可袭击相邻船只。获胜时丢弃对方一个指定货舱，失败无事发生。",
				beth: "战斗力增加 2。",
				saran: "每场战斗可重掷自己或对手的战斗骰一次，第二次必须接受。",
				cooper: "每次装货增加一个同类资源。",
				venetian: "支付时金币与食物可相互替换。",
				prussian: "支付时食物与火药可相互替换。",
				helvetian: "支付时火药与金币可相互替换。",
				seafarer: "每次前进或后退可多移动一格。",
				anchoree: "每次前进或后退可少移动一格。",
				seadog: "可以忽略后退行动。",
				cartographer: "手牌上限为 4。",
				king: "到达皇家港获得 9 分，否则扣除 3 分。",
				nosey: "取得宝藏时查看最多三张并选一张。",
				bishop: "每枚已收集的宝藏标记额外获得 2 分。",
				shipowner: "每名船员额外获得 3 分，包括自己。",
				calypso: "与三张诅咒护符同时在船时立即获胜。",
				oracle: "担任队长时，可在掷骰前指定其中一枚骰子的数值。",
				lookout: "落点与相邻格的宝藏标记中，可以收集一枚。",
				witch: "可为自己交换日夜骰子的顺序。"
			},
			treasure: {
				map: "摩根的地图",
				sabre: "莎兰的军刀",
				beth: "贝丝夫人",
				hold: "第六货舱",
				rum: "朗姆酒",
				sextant: "六分仪",
				anchor: "船锚",
				diamond: "尤昆昆钻石"
			},
			events: {
				sail: "{{name}} 航行至 {{node}}。",
				retreat: "{{name}} 退航至 {{node}}。",
				load: "{{name}} 装入 {{n}} {{resource}}。",
				pay: "{{name}} 支付 {{n}} {{resource}}。",
				discard: "{{name}} 丢弃 {{n}} {{resource}}。",
				ignored: "{{name}} 的货舱无法装入同类资源。",
				shortage: "{{name}} 缺少 {{n}} {{resource}}，开始退航。",
				treasure: "{{name}} 收集一枚宝藏标记。",
				battle: "{{name}} 与 {{target}} 交战。",
				winBattle: "{{name}} 赢得战斗。",
				drawBattle: "战斗平手。",
				recruit: "{{name}} 招募一名船员。",
				steal: "{{name}} 从 {{target}} 夺取 {{n}} {{resource}}。",
				destroy: "{{name}} 丢弃 {{target}} 的 {{n}} {{resource}}。",
				curse: "{{name}} 将诅咒宝藏交给 {{target}}。",
				finish: "{{name}} 抵达皇家港。",
				calypso: "{{name}} 集齐护符与卡吕普索。",
				end: "本轮结束，结算财富。"
			}
		},
		en: {
			name: "Jamaica",
			desc: "Race around the island, seize treasure and return with the richest ship.",
			rules: "Goal: race around Jamaica and amass wealth. When a ship reaches Port Royal, finish the current round. Add position points, gold, treasures and crew points. The highest score wins; ties go to the ship closest to the finish, then tied players share victory.\nSetup: each player has 11 action cards, a hand of 3 and five holds. Load 3 gold and 3 food in separate holds. Place nine treasure tokens in the lairs. Shuffle the treasure deck and keep nine random cards.\nDay and night: the captain rolls two dice and assigns them to morning and evening. Everyone secretly selects a card. Reveal together, then each player in seating order from the captain fully resolves morning followed by evening. Refill hands and pass the captain. Reshuffle discards when a deck runs out. The left action is morning and the right is evening; quantities use the matching die.\nLoading: put the whole load into one empty hold. Never add it to an existing load. If all holds are full, discard a complete hold of a different type. If every hold contains that same type, ignore the action. Each crew member occupies a hold; a new crew member cannot replace another.\nSailing: move the indicated spaces forward or backward, choosing at forks. Only pay the final space: food equal to white diamonds at sea, gold at a port. Port Royal and lairs are free. Fight an occupying ship before paying. Taking a lair token draws one treasure. Point and cursed treasures stay secret until the end; special items are revealed immediately.\nShortage: pay everything currently available in the required resource, then retreat to the first space you can afford. Choose at forks. Fight there first, then pay and collect any available treasure. An evening load cannot pay a morning fee.\nCombat: the attacker chooses gunpowder, pays it and rolls. The defender sees that result before choosing gunpowder and rolling. Add normal die results, powder and bonuses; higher strength wins and a tie does nothing. A star wins immediately; an attacking star prevents a defense roll. The winner steals an entire hold, steals one treasure, or gives the loser one of their own cursed treasures. Stolen goods obey normal loading rules.\nBase treasures: points of 3, 4, 5, 6 and 7; curses of minus 2, 3 and 4. Morgan’s Map allows a hand of 4. Saran’s Sabre allows one reroll of either combat die per battle; accept the second result. Lady Beth adds 2 strength. The Sixth Hold is an extra hold and transfers with its contents when stolen.\nEnd: a ship completing the circuit stops its remaining actions and scores 15 position points. Spaces before the finish score 10 down to 2; the red boundary and all earlier spaces score minus 5. Add gold, treasure and crew points.\nTwo players: add the Ghost Ship with 5 gold and 3 gold in separate holds and an unstealable Lady Beth. It takes two moves using the morning and evening dice after both players. It moves backward when leading, forward when last; the captain chooses direction when it is between the players and chooses at forks. It pays no fees and collects secret treasure. The player other than its opponent controls combat. Stolen goods other than gold are discarded; it cannot give curses. It may trigger the end but is not included in player rankings.\nOptional expansions:\n· Extra Treasures adds Rum, Sextant and Anchor. Rum adds one matching resource when loading. Sextant allows one additional movement space; Anchor allows one fewer.\n· The Crew replaces the base treasures with 12 expansion treasures. Shuffle 20 crew into the tavern tray. After fully paying a port fee you may recruit. Move the rum bottle through connected empty spaces, paying one gold per step, then recruit an adjacent character. Reveal crew bordering the expanded empty area. Upper/lower character scores apply when your ship has/has not reached Port Royal.\n· Crew powers: Sir Beth adds 2 combat strength. Saran allows one combat reroll. The Buccaneer may attack an adjacent ship: a win discards a chosen enemy hold, a loss does nothing. The Strategist always wins as attacker. The Shipowner adds 3 points per crew member including himself. The Nosey Parker looks at up to three treasures and keeps one. The King only scores points. The Bishop adds 2 per collected token. The Cartographer allows a hand of 4. The Old Seadog may ignore backward actions. Anchoree/Seafarer allow one fewer/more space. Merchants interchange their paired resources when paying and can combine. The Cooper adds one resource when loading. Calypso with all three cursed amulets wins immediately. The Witch may swap her own day/night dice. The Oracle may set one die before rolling as captain. The Look-out may collect one token from the landing space or an adjacent space.\n· Crew treasures: eight positive treasures, three cursed amulets and the face-up 12-point diamond. Treasures not chosen by the Nosey Parker remain with their original owner; unchosen cards inspected from the draw pile are shuffled back into it.",
			gold: "Gold",
			food: "Food",
			powder: "Gunpowder",
			forward: "Forward",
			backward: "Backward",
			sea: "Sea",
			port: "Port",
			tokenCount: "{{n}} treasure tokens",
			bottle: "Rum bottle",
			facedownCrew: "Unrevealed crew",
			crewPoints: "Arrived {{arrived}} / Sailing {{sailing}}",
			day: "Morning",
			night: "Evening",
			round: "Round {{n}}",
			captain: "Captain: {{name}}",
			ghost: "Ghost Ship",
			royal: "Port Royal",
			select: "Choose an action card",
			confirm: "Play selected card",
			selected: "Waiting for other cards",
			resolving: "Under sail",
			waiting: "Waiting for {{name}}",
			oracle: "Set one die, or roll normally",
			arrange: "Assign morning and evening dice",
			load: "Choose a hold to load",
			pay: "Choose a hold to pay from",
			route: "Choose a route",
			distance: "Choose movement distance",
			enemy: "Choose a ship to fight",
			lair: "Choose a treasure lair",
			treasurePrompt: "Choose one treasure",
			recruitPrompt: "Recruit crew, or decline",
			ghostPrompt: "Choose the Ghost Ship’s direction",
			powderPrompt: "Choose gunpowder to spend",
			rerollPrompt: "Choose whether to reroll",
			lootPrompt: "Choose your spoils",
			roll: "Roll normally",
			skip: "Decline",
			keep: "Keep result",
			die: "Set to {{n}}",
			move: "{{action}} {{n}} spaces",
			space: "{{kind}} · {{n}}",
			store: "Load hold {{n}}",
			replace: "Discard and load hold {{n}}",
			payHold: "Pay {{amount}} {{resource}} from hold {{n}}",
			fire: "Spend {{n}} gunpowder",
			attack: "Attack {{name}}",
			raid: "Raid adjacent {{name}}",
			reroll: "Reroll {{name}}’s combat die",
			stealHold: "Steal hold {{n}}",
			destroyHold: "Discard enemy hold {{n}}",
			stealTreasure: "Steal one treasure",
			giveCurse: "Give {{n}}-point curse",
			recruitChoice: "Recruit {{name}} · {{n}} gold",
			dicePair: "Morning {{day}} · Evening {{night}}",
			hold: "Hold {{n}}",
			empty: "Empty",
			privateTreasure: "Hidden treasure",
			treasurePoints: "{{n}}-point treasure",
			ship: "{{name}}’s ship",
			treasures: "Treasures",
			cargo: "Cargo",
			tavern: "Port tavern",
			chart: "Sea chart",
			details: "Ship details",
			log: "Ship’s log",
			swap: "Witch: swap your dice",
			inspect: "Inspect {{name}}",
			cardAria: "Morning {{day}}, evening {{night}}",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			resetMap: "Fit sea chart",
			finish: "Arrived",
			battle: "{{a}} versus {{d}}",
			star: "Star",
			winBattle: "{{name}} wins",
			drawBattle: "Combat tied",
			finalRound: "Final round",
			errTurn: "You cannot act now.",
			errChoice: "Choose an available action.",
			on: "On",
			off: "Off",
			expansions: "Expansions",
			crewOption: "The Crew",
			crewHint: "20 crew and replacement treasures",
			extraOption: "Extra Treasures",
			extraHint: "Rum, Sextant and Anchor",
			result: "Port Royal ship’s ledger",
			reviewHide: "Close ledger and review the chart",
			reviewShow: "Open the final ledger",
			positionScore: "Position",
			goldScore: "Gold",
			treasureScore: "Treasure",
			crewScore: "Crew",
			total: "Total",
			winner: "Winner",
			calypsoWin: "{{name}} has Calypso and all three cursed amulets, winning immediately.",
			again: "Play again",
			lobby: "Back to lobby",
			confirmAgain: "Confirm new game",
			confirmLobby: "Confirm return to lobby",
			cancel: "Cancel",
			waitHost: "Waiting for the host",
			hintCount: "{{n}} hints used",
			autopilot: "{{n}}% autopilot",
			crew: {
				strategist: "The Strategist",
				buccaneer: "The Buccaneer",
				beth: "Sir Beth",
				saran: "Saran",
				cooper: "The Cooper",
				venetian: "The Venetian Merchant",
				prussian: "The Prussian Merchant",
				helvetian: "The Helvetian Merchant",
				seafarer: "The Seafarer",
				anchoree: "The Anchoree",
				seadog: "The Old Seadog",
				cartographer: "The Cartographer",
				king: "The King",
				nosey: "The Nosey Parker",
				bishop: "The Bishop",
				shipowner: "The Shipowner",
				calypso: "Calypso",
				oracle: "The Oracle",
				lookout: "The Look-out",
				witch: "The Witch"
			},
			power: {
				strategist: "Automatically wins every combat as attacker.",
				buccaneer: "May raid an adjacent ship. A win discards a chosen enemy hold; a loss does nothing.",
				beth: "Adds 2 combat strength.",
				saran: "Reroll your own or the enemy combat die once per battle. Accept the second result.",
				cooper: "Load one additional matching resource.",
				venetian: "Interchange gold and food when paying.",
				prussian: "Interchange food and gunpowder when paying.",
				helvetian: "Interchange gunpowder and gold when paying.",
				seafarer: "May move one additional space forward or backward.",
				anchoree: "May move one fewer space forward or backward.",
				seadog: "May ignore backward actions.",
				cartographer: "Hand limit is 4.",
				king: "Scores 9 at Port Royal; otherwise loses 3.",
				nosey: "Inspect up to three treasures and keep one.",
				bishop: "Adds 2 points per collected treasure token.",
				shipowner: "Adds 3 points per crew member, including himself.",
				calypso: "Wins immediately with all three cursed amulets aboard.",
				oracle: "As captain, may set one die before rolling.",
				lookout: "May collect one token from the landing space or an adjacent space.",
				witch: "May swap morning and evening dice for herself."
			},
			treasure: {
				map: "Morgan’s Map",
				sabre: "Saran’s Sabre",
				beth: "Lady Beth",
				hold: "Sixth Hold",
				rum: "Rum",
				sextant: "Sextant",
				anchor: "Anchor",
				diamond: "Youkounkoun Diamond"
			},
			events: {
				sail: "{{name}} sails to {{node}}.",
				retreat: "{{name}} retreats to {{node}}.",
				load: "{{name}} loads {{n}} {{resource}}.",
				pay: "{{name}} pays {{n}} {{resource}}.",
				discard: "{{name}} discards {{n}} {{resource}}.",
				ignored: "{{name}} cannot load another hold of this resource.",
				shortage: "{{name}} is short of {{n}} {{resource}} and retreats.",
				treasure: "{{name}} collects a treasure token.",
				battle: "{{name}} fights {{target}}.",
				winBattle: "{{name}} wins combat.",
				drawBattle: "Combat is tied.",
				recruit: "{{name}} recruits a crew member.",
				steal: "{{name}} steals {{n}} {{resource}} from {{target}}.",
				destroy: "{{name}} discards {{target}}’s {{n}} {{resource}}.",
				curse: "{{name}} gives a cursed treasure to {{target}}.",
				finish: "{{name}} reaches Port Royal.",
				calypso: "{{name}} has the amulets and Calypso.",
				end: "The round ends. Count the spoils."
			}
		}
	}
};
//#endregion
export { Pt as default };
