import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { IconBack as l, IconBot as u, IconCheck as d, IconClose as f, IconExpand as p, IconEye as m, IconLog as h, IconPile as g, IconPlayers as _, IconSearch as v } from "@bgparty/sdk/icons";
import { Fragment as y, jsx as b, jsxs as x } from "react/jsx-runtime";
import { GameScreen as S } from "@bgparty/sdk/ui/game-screen";
import { seatName as C } from "@bgparty/sdk/ui/player-strip";
import { useFxAnchor as w } from "@bgparty/sdk/fx/anchors";
import { AVATARS as T } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as ee } from "@bgparty/sdk/player-colors";
import { Floater as E, FlySprite as D, PulseBox as O } from "@bgparty/sdk/fx/primitives";
import { Confetti as te } from "@bgparty/sdk/ui/confetti";
//#region src/game/baddies.ts
function k(e, t, n, r, i, a, o, s, c, l = "") {
	let [u = "", d = ""] = c.split("/"), f = (e) => Object.fromEntries(e.split(",").filter(Boolean).map((e) => {
		let [t, n] = e.split(":");
		return [t, n === void 0 ? 1 : Number(n)];
	}));
	return {
		id: e,
		point: t,
		copies: n,
		creature: r,
		hp: i,
		initiative: a,
		attack: o,
		defense: s,
		ranged: l.includes("ranged"),
		target: l.includes("strongest") ? "strongest" : "weakest",
		targets: l.includes("three") ? 3 : l.includes("two") ? 2 : 1,
		diagonal: l.includes("diagonal"),
		extra: l.includes("extra2") ? 2 : +!!l.includes("extra1"),
		skills: f(u),
		backup: f(d),
		backupCost: l.includes("bp2") ? 2 : 1
	};
}
var ne = [
	k("direwolfpup", 1, 2, "beast", 3, 3, 1, 0, "lashback:1"),
	k("griffinyearling", 1, 2, "beast", 2, 5, 2, 0, "flight"),
	k("trollromper", 1, 2, "troll", 3, 2, 1, 0, "thickSkin:1/careless:1"),
	k("trollbrute", 1, 2, "troll", 3, 1, 1, 1, "thickSkin:1/careless:1", "ranged"),
	k("trollyoungun", 1, 1, "troll", 4, 3, 1, 1, "/careless:1"),
	k("orcscout", 1, 2, "orc", 3, 4, 1, 0, "raiding"),
	k("orcgrunt", 1, 1, "orc", 4, 2, 1, 1, "raiding", "strongest"),
	k("orcpeon", 1, 2, "orc", 3, 3, 1, 0, "rage:1"),
	k("bogpole", 1, 1, "bog", 3, 3, 0, 0, "poison:1", "two"),
	k("claygolem", 1, 2, "bog", 5, 2, 1, 0, "break", "strongest"),
	k("bogfrog", 1, 2, "bog", 4, 3, 0, 0, "poison:2", "strongest"),
	k("goblinrioter", 1, 1, "goblin", 3, 4, 1, 0, "mischief:1", "ranged two"),
	k("goblinbomber", 1, 2, "goblin", 3, 5, 1, 0, "mischief:1/careless:1", "ranged two"),
	k("goblinsandbagger", 1, 1, "goblin", 2, 4, 1, 1, "/mischief:1"),
	k("koboldgreenthumb", 1, 1, "scales", 3, 4, 1, 0, "hardy", "strongest"),
	k("dragonwhelp", 1, 1, "scales", 2, 5, 2, 1, "weaken:1", "strongest"),
	k("dragonhatchling", 1, 1, "scales", 3, 6, 1, 0, "engulf"),
	k("koboldtracker", 1, 2, "scales", 2, 6, 0, 0, "hardy,compound"),
	k("direwolf", 5, 1, "beast", 6, 4, 4, 0, "lashback:2"),
	k("owlbear", 5, 1, "beast", 6, 4, 4, 0, "inspire:1,terrify"),
	k("griffinhowler", 5, 2, "beast", 5, 5, 3, 0, "dive,flight,signal:1", "strongest"),
	k("trollsage", 5, 1, "troll", 6, 4, 2, 1, "thickSkin:1/inspire:1", "strongest"),
	k("trollenforcer", 5, 2, "troll", 5, 2, 3, 2, "thickSkin:1/taunt"),
	k("goblinalarmist", 5, 2, "goblin", 6, 6, 1, 2, "signal:3", "ranged strongest"),
	k("goblinsapper", 5, 2, "goblin", 5, 4, 3, 0, "mischief:2,signal:1", "ranged"),
	k("orcwarmonger", 5, 1, "orc", 6, 4, 3, 2, "raiding/taunt", "strongest"),
	k("orcrager", 5, 2, "orc", 5, 3, 2, 0, "raiding,rage:2"),
	k("koboldelite", 5, 1, "scales", 5, 3, 0, 0, "hardy,compound", "two"),
	k("dragondelinquent", 5, 1, "scales", 7, 6, 2, 2, "engulf/weaken:2"),
	k("koboldfanatic", 5, 1, "scales", 6, 3, 3, 0, "hardy,inspire:1", "strongest"),
	k("boglurk", 5, 1, "bog", 6, 4, 0, 0, "poison:2", "three"),
	k("stonegolem", 5, 1, "bog", 7, 3, 3, 2, "break/corrosive", "strongest bp2"),
	k("manticore", 5, 1, "bog", 6, 3, 0, 0, "poison:2,rage:2", "two"),
	k("goldengolem", 20, 1, "bog", 9, 5, 5, 3, "break/recover:2", "strongest diagonal extra1"),
	k("honorgriffin", 20, 1, "beast", 8, 5, 5, 0, "dive,flight/stun", "strongest diagonal extra2 bp2"),
	k("direwolfalpha", 20, 1, "beast", 7, 5, 4, 0, "lashback:3,terrify,thickSkin:2", "diagonal extra1"),
	k("ferociousowlbear", 20, 1, "beast", 8, 6, 5, 0, "inspire:2,terrify,thickSkin:2", "diagonal extra1"),
	k("dragonelder", 20, 1, "scales", 8, 5, 3, 2, "weaken:2,flight", "ranged two"),
	k("bonedragon", 20, 1, "scales", 8, 4, 3, 0, "hardy,undead", "ranged two"),
	k("bogwyrm", 20, 1, "bog", 9, 6, 1, 0, "corrosive,poison:2", "ranged two")
], re = {
	nom: {
		...k("nom", 0, 1, "troll", 6, 2, 1, 1, "thickSkin:3,recover:1", "strongest diagonal"),
		days: 8,
		progress: 6,
		creatures: [
			"troll",
			"orc",
			"scales"
		],
		encounters: [1],
		slot: 0,
		faces: [
			"omnom",
			"thunderclub",
			"thunderclub",
			"omnom",
			"thunderclub",
			"thunderclub"
		]
	},
	gendricks: {
		...k("gendricks", 0, 1, "scales", 9, 4, 3, 2, "hardy/limit", "ranged two"),
		days: 10,
		progress: 8,
		creatures: [
			"scales",
			"bog",
			"orc",
			"troll"
		],
		encounters: [3, 4],
		slot: 2,
		faces: [
			"orb:2",
			"orb:4",
			"charred",
			"orb:1",
			"orb:3",
			"charred"
		]
	},
	duster: {
		...k("duster", 0, 1, "scales", 9, 6, 3, 2, "shrouded/limit:1,hide:2", "two diagonal"),
		days: 13,
		progress: 10,
		creatures: [
			"goblin",
			"troll",
			"bog",
			"beast",
			"scales"
		],
		encounters: [
			6,
			7,
			8
		],
		slot: 5,
		faces: [
			"cloak",
			"cloak",
			"dagger",
			"cloak",
			"cloak",
			"dagger"
		]
	},
	mulmesh: {
		...k("mulmesh", 0, 1, "beast", 8, 6, 2, 0, "frenzy:2,retreat,shrouded", "diagonal"),
		days: 9,
		progress: 6,
		creatures: [
			"beast",
			"bog",
			"scales"
		],
		encounters: [10],
		slot: 9,
		faces: [
			"silverHide",
			"silverHide",
			"howl",
			"howl",
			"silverHide",
			"howl"
		]
	},
	drellen: {
		...k("drellen", 0, 1, "bog", 8, 5, 3, 2, "bogRuler", "two"),
		days: 10,
		progress: 6,
		creatures: [
			"bog",
			"goblin",
			"beast"
		],
		encounters: [12],
		slot: 11,
		faces: [
			"enhance",
			"poison",
			"poison",
			"enhance",
			"enhance",
			"poison"
		]
	},
	marrow: {
		...k("marrow", 0, 1, "orc", 9, 5, 3, 3, "raiding/callOrc"),
		days: 12,
		progress: 10,
		creatures: [
			"orc",
			"goblin",
			"bog",
			"scales"
		],
		encounters: [14, 15],
		slot: 13,
		faces: [
			"bloodRage",
			"skullAxe",
			"skullAxe",
			"bloodRage",
			"bloodRage",
			"skullAxe"
		]
	},
	goblinking: {
		...k("goblinking", 0, 1, "goblin", 9, 5, 2, 3, "boom,kaboom", "ranged two"),
		days: 12,
		progress: 8,
		creatures: [
			"goblin",
			"troll",
			"bog",
			"beast"
		],
		encounters: [17, 18],
		slot: 16,
		faces: [
			"callHelp",
			"callHelp",
			"carelessBomb",
			"callHelp",
			"callHelp",
			"carelessBomb"
		]
	}
};
function A(e) {
	return ne.find((t) => t.id === e) ?? re[e];
}
//#endregion
//#region src/game/cards.ts
var j = (e = 0, t = 0, n = 0, r = 0, i = 0, a = 0) => ({
	progress: e,
	training: t,
	loot: n,
	eachLoot: r,
	trove: i,
	eachTrove: a
}), M = (e, t, n, r, i, a = []) => ({
	id: e,
	sheet: t,
	slot: n,
	choices: r,
	reward: i,
	choiceRewards: a
}), N = [
	M("s1", 1, 0, 2, j(1), [j(0, 2), j(0, 1)]),
	M("s2", 1, 1, 2, j(1, 1, 0, 1), [j(), j(0, 1)]),
	M("s3", 1, 2, 2, j(1), [j(0, 1), j(0, 0, 0, 0, 1)]),
	M("s4", 1, 3, 2, j(), [j(), j(2, 2, 0, 0, 0, 1)]),
	M("s5", 1, 4, 2, j(), [j(0, 1), j(0, 2, 0, 1)]),
	M("s6", 1, 5, 2, j(), [j(), j(1, 2, 0, 1)]),
	M("g1", 29, 0, 2, j(1, 2, 0, 1), [j(1), j()]),
	M("g2", 29, 1, 2, j(1, 2, 0, 1), [j(0, 1), j()]),
	M("g3", 29, 2, 2, j(1, 1, 0, 1), [j(0, 2), j()]),
	M("g4", 29, 3, 2, j(1, 2, 0, 1)),
	M("g5", 29, 4, 2, j(1, 1), [j(), j(0, 1, 0, 1)]),
	M("g6", 29, 5, 2, j(1, 2, 0, 1)),
	M("g7", 29, 6, 2, j(1, 1, 0, 1), [j(1), j(0, 1)]),
	M("g8", 29, 7, 2, j(1, 1), [j(0, 0, 0, 2), j(0, 0, 1)]),
	M("g9", 29, 8, 2, j(1, 2, 0, 1), [j(0, 0, 0, 1), j()]),
	M("g10", 29, 9, 1, j(1, 2), [j(0, 0, 1)]),
	M("g11", 29, 10, 2, j(1, 2, 0, 1)),
	M("g12", 29, 11, 2, j(1, 2), [j(0, 0, 0, 0, 2), j()]),
	M("g13", 29, 12, 2, j(1, 2), [j(), j(0, 0, 0, 1)]),
	M("g14", 29, 13, 2, j(1, 2, 0, 1), [j(), j(0, 1)]),
	M("g15", 29, 14, 2, j(1, 2, 0, 1), [j(), j(0, 0, 0, 0, 0, 1)]),
	M("g16", 29, 15, 2, j(1, 2, 0, 1), [j(0, 1), j()]),
	M("g17", 29, 16, 2, j(1, 2, 0, 1)),
	M("g18", 29, 17, 3, j(2, 2, 0, 1), [
		j(0, 0, 0, 0, 1),
		j(0, 1),
		j()
	]),
	M("g19", 29, 18, 2, j(1, 2, 0, 1)),
	M("g20", 29, 19, 2, j(1, 2, 0, 1)),
	M("g21", 29, 20, 2, j(1, 2), [j(0, 1, 0, 0, 0, 1), j()]),
	M("g22", 29, 21, 2, j(2, 2), [j(0, 1, 0, 0, 0, 1), j(0, 1)]),
	M("g23", 29, 22, 2, j(), [j(1, 2), j(1, 0)]),
	M("g24", 29, 23, 2, j(1), [j(0, 0, 0, 2, 0, 1), j()]),
	M("g25", 29, 24, 1, j(1, 1, 0, 1)),
	M("g26", 29, 25, 2, j(1, 1)),
	M("g27", 29, 26, 1, j(1, 1, 1)),
	M("g28", 29, 27, 1, j(1, 1)),
	M("g29", 29, 28, 1, j(1, 2)),
	M("g30", 29, 29, 1, j()),
	M("o1", 0, 0, 2, j(1, 2), [j(0, 0, 0, 2), j()]),
	M("o2", 0, 1, 2, j(0, 1, 0, 1), [j(1, 1), j(0, 1)]),
	M("o3", 0, 2, 2, j(1, 1, 0, 1), [j(), j(0, 1, 0, 0, 0, 1)]),
	M("o4", 0, 3, 2, j(1, 2, 0, 1)),
	M("o5", 0, 4, 2, j(1, 1), [j(0, 0, 2), j()]),
	M("o6", 0, 5, 2, j(1, 2, 0, 1)),
	M("o7", 0, 6, 2, j(1, 1), [j(0, 1, 0, 2), j(0, 1)]),
	M("o8", 0, 7, 2, j(1, 1), [j(0, 1, 0, 1), j()]),
	M("o9", 0, 8, 2, j(1, 1, 0, 1), [j(0, 0, 0, 2), j(0, 0, 0, 0, 0, 1)]),
	M("o10", 0, 9, 2, j(1, 2, 0, 1)),
	M("o11", 0, 10, 2, j(1, 2, 0, 1)),
	M("o12", 0, 11, 2, j(1, 1)),
	M("t1", 2, 1, 2, j(1, 1, 0, 1), [j(1, 1, 0, 1), j()]),
	M("t3", 2, 3, 1, j(1, 2, 0, 1)),
	M("t4", 2, 4, 2, j(1, 1, 0, 1), [j(), j(0, 1)]),
	M("t6", 2, 6, 2, j(1, 1, 0, 1), [j(0, 0, 0, 1), j(0, 1)]),
	M("t7", 2, 7, 1, j(1, 2, 0, 1)),
	M("t8", 2, 8, 2, j(1, 0, 0, 1), [j(0, 1), j()]),
	M("t10", 2, 10, 1, j()),
	M("t12", 2, 12, 2, j(), [j(0, 2), j(1, 1)]),
	M("t14", 2, 14, 1, j(1, 3, 0, 1)),
	M("t15", 2, 15, 2, j(1, 2, 0, 1)),
	M("t17", 2, 17, 2, j(1, 1, 0, 1)),
	M("t18", 2, 18, 1, j(1, 1, 0, 1))
], ie = (e) => N.find((t) => t.id === e), P = (e, t = 1, n = 1, r = !1, i = !1) => ({
	id: "l" + e,
	slot: e,
	copies: t,
	uses: n,
	heavy: r,
	permanent: i,
	trove: !1,
	locks: [],
	backup: 0
}), F = (e, t, n = 0) => ({
	id: "v" + e,
	slot: e,
	copies: 1,
	uses: 1,
	heavy: !1,
	permanent: !0,
	trove: !0,
	locks: t,
	backup: n
}), ae = [
	P(0),
	P(1, 7),
	P(2),
	P(3, 1, 2),
	P(4),
	P(5, 1, 7),
	P(6),
	P(7),
	P(8, 2),
	P(9, 1, 3),
	P(10, 2, 3),
	P(11, 1, 2),
	P(12, 1, 1, !0, !0),
	P(13),
	P(14, 1, 2),
	P(15, 1, 1, !0, !0),
	P(16, 1, 2),
	P(17, 1, 3),
	P(18, 1, 1, !0, !0),
	P(19),
	P(20),
	P(21),
	P(22, 2),
	P(23, 1, 2),
	P(24),
	P(25),
	P(26, 2),
	P(27),
	P(28, 2),
	F(2, [
		2,
		3,
		3
	], 1),
	F(3, [
		3,
		3,
		6
	]),
	F(4, [
		4,
		2,
		2
	], 2),
	F(6, [
		3,
		5,
		2
	], 3),
	F(7, [
		1,
		6,
		1
	]),
	F(8, [
		4,
		3,
		2
	], 1),
	F(9, [
		3,
		2,
		3
	], 3),
	F(10, [
		3,
		3,
		3
	]),
	F(11, [
		4,
		1,
		1
	], 1),
	F(12, [
		5,
		3,
		1
	], 2),
	F(13, [
		3,
		2,
		4
	]),
	F(14, [
		1,
		4,
		3
	]),
	F(15, [
		1,
		2,
		3
	], 1),
	F(16, [
		2,
		6,
		4
	]),
	F(17, [
		3,
		1,
		3
	], 2),
	F(18, [
		2,
		3,
		5
	], 1),
	F(19, [
		5,
		2,
		3
	], 1),
	F(20, [
		4,
		4,
		4
	]),
	F(21, [
		3,
		6,
		3
	]),
	F(22, [
		5,
		2,
		5
	], 2)
], oe = {
	...P(29, 1, 2),
	id: "water"
}, se = (e) => e === "water" ? oe : ae.find((t) => t.id === e), I = (e, t, n = [], r = {}) => ({
	id: e,
	faces: t.split(","),
	requires: n,
	...r
}), ce = {
	boomer: [
		I(1, "bones,element:1,element:1,element:2,element:2,element:3"),
		I(2, "bones,casing:1,casing:1,casing:2,casing:2,casing:3"),
		I(3, "bones,fuse:1,fuse:1,fuse:2,fuse:2,fuse:3"),
		I(4, "grenades:0,grenades:1,grenades:2,grenades:3,blank,blank", [], { counter: !0 }),
		I(5, "forcedBones,explosion:3,explosion:3,explosion:3,explosion:3,explosion:4", [], { grenade: !0 }),
		I(6, "blast:1|partyBacklash:1,blast:1,blast:1,blast:2|partyBacklash:2,blast:2,blast:2", [5], { grenade: !0 }),
		I(7, "forcedBones,smoke:1,smoke:1,smoke:1,smoke:2,smoke:2", [], { grenade: !0 }),
		I(8, "cleanse:1,cleanse:1,cleanse:1,cleanse:2,cleanse:2,cleanse:2", [], { grenade: !0 }),
		I(9, "forcedBones,stun:5,stun:5,stun:5,stun:5,stun:5", [], { grenade: !0 }),
		I(10, "forcedBones,napalm:2:1|backlash:1,napalm:2:1,napalm:2:2,napalm:2:2,napalm:2:3", [9], { grenade: !0 }),
		I(11, "disable:1,disable:1,disable:1,disable:5,disable:5,disable:5", [], { grenade: !0 }),
		I(12, "grenades:1,parts:1,parts:1,parts:2,parts:2,parts:3", [], { consumable: !0 }),
		I(13, "bones,bones,buffHp:3,loot:1,parts:1,parts:2"),
		I(14, "bones,bones,biggerBoom:1,biggerBoom:1,biggerBoom:1,biggerBoom:2", [13]),
		I(15, "bones:2,bones:2,bones:2,holyAcquire,grenades:1,element325", [14]),
		I(16, "holyBlast:1:2,holyBlast:1:2,holyBlast:2:4,holyExplosion:2:5,holyExplosion:3:6,holyExplosion:3:6", [], { consumable: !0 })
	],
	patches: [
		I(1, "heal:1,heal:2,heal:2,heal:2,heal:3,heal:3"),
		I(2, "bones,healMultiply:2,healMultiply:2,healMultiply:2,healMultiply:3,healMultiply:3", [1]),
		I(3, "meleeDamage:1,meleeDamage:1,meleeDamage:2,meleeDamage:2,meleeDamage:3,meleeDamage:3", [2]),
		I(4, "revive:1,revive:2,revive:2,revive:2,revive:3,revive:3", [], { consumable: !0 }),
		I(5, "bones,heal:2,heal:3,healReroll:1,healReroll:2,loot:1"),
		I(6, "bones:2,bones:2,poisonTarget:1,poisonTarget:2,poisonTarget:2,poisonTarget:3"),
		I(7, "heal:3,heal:3,heal:4,heal:4,heal:5,heal:5", [2]),
		I(8, "poisonAny:1,poisonAny:2,poisonAny:2,poisonAny:2,poisonAny:3,poisonAny:3", [], { consumable: !0 }),
		I(9, "bones,tainted:1,buffHp:2,buffHp:3,buffHp:4,buffHp:5"),
		I(10, "bones,tainted:1,buffAttack:2,buffAttack:2,buffAttack:3,buffAttack:3", [9]),
		I(11, "trueDamage:3,trueDamage:4,reviveKo:3,reviveKo:4,reviveKo:4,reviveKo:5", [7]),
		I(12, "cells:1,cells:2,cells:2,cells:3,cells:3,cells:3", [], {
			consumable: !0,
			counter: !0
		}),
		I(13, "bones,buffReroll:1,buffReroll:1,buffReroll:1,buffReroll:2,buffReroll:2", [14]),
		I(14, "bones,tainted:1,buffHp:3,buffHp:4,buffHp:4,buffHp:5", [9]),
		I(15, "bones,bones,recover:1,recover:1,booster:1,booster:2", [14]),
		I(16, "tainted:1,tainted:2,permanentHp:1,permanentHp:1,permanentHp:1,permanentHp:2", [15])
	],
	picket: [
		I(1, "reusableBones,reusableBones,reusableBones,reusableBones,constantRegen:1,constantRegen:1", [], { reusable: !0 }),
		I(2, "reusableBones,reusableBones,reusableBones,constantMove:2,constantDefense:1,constantDefense:1", [1], { reusable: !0 }),
		I(3, "bones,bones,intercept:1,intercept:1,intercept:1,intercept:2"),
		I(4, "ale:1,ale:1,ale:1,ale:2,ale:2,ale:2", [], { consumable: !0 }),
		I(5, "reusableBones,reusableBones,reusableBones,constantMove:2,constantDamage:1,constantDamage:1", [1], { reusable: !0 }),
		I(6, "reusableBones,reusableBones,reusableBones,reusableBones,constantTaunt,constantTaunt", [2], { reusable: !0 }),
		I(7, "bones,intercept:1,intercept:1,intercept:2,intercept:2,intercept:3", [3]),
		I(8, "healSelf:2,healSelf:3,healSelf:3,healSelf:3,healSelf:4,healSelf:4", [], { consumable: !0 }),
		I(9, "switch,switch,switch,rush,rush,riposte"),
		I(10, "switch,rush,rush,rush,riposte,riposte"),
		I(11, "bones,advancedDefense:1,advancedDefense:1,advancedDefense:1,advancedDefense:2,advancedDefense:2"),
		I(12, "bones,advancedDefense:1,advancedDefense:2,advancedDefense:2,advancedDefense:2,advancedDefense:3", [11]),
		I(13, "switch,switch,rush,riposte,riposte,riposte"),
		I(14, "switch,switch,rush,rush,riposte,riposte"),
		I(15, "bones:2,bones:2,bones:2,bones:3,improvedDefense,improvedDefense", [11]),
		I(16, "bones,advancedDefense:1,advancedDefense:2,advancedDefense:3,advancedDefense:3,advancedDefense:4", [12])
	],
	tantrum: [
		I(1, "rage:10,rage:12,rage:14,rage:16,rage:18,breakdown", [], { counter: !0 }),
		I(2, "rage:20,rage:22,rage:24,rage:26,rage:28,breakdown", [1], { counter: !0 }),
		I(3, "rage:30,rage:32,rage:34,rage:36,rage:38,breakdown", [2], { counter: !0 }),
		I(4, "anger:2,anger:2,anger:4,anger:4,anger:6,advance"),
		I(5, "bones,axe:1,poisonArmor:1,poisonArmor:2,poisonArmor:2,poisonArmor:2"),
		I(6, "bones,axe:1,lashback:2,lashback:2,lashback:2,lashback:3"),
		I(7, "bones,axe:1,hardy:1,hardy:1,hardy:1,hardy:2"),
		I(8, "axes:0,axes:1,axes:2,axes:3,blank,blank", [], {
			counter: !0,
			consumable: !0
		}),
		I(9, "bones,bones,dropInitiative:3,dropInitiative:2,dropInitiative:2,dropInitiative:1"),
		I(10, "bones,bones,attackMinus:1,attackMinus:1,attackMinus:1,attackMinus:1"),
		I(11, "bones,bones,disable:5,disable:5,disable:5,disable:5"),
		I(12, "reusableBones,reusableBones,reusableBones,reusableBones,partyInspire,disorient:5", [], {
			consumable: !0,
			reusable: !0
		}),
		I(13, "bones,bones,jump,jump,jump,jump", [9]),
		I(14, "bones,bones,attackPlus:1,attackPlus:1,attackPlus:1,attackPlus:1|trainAttack", [10]),
		I(15, "bones,bones,taunt,taunt,taunt,taunt", [11]),
		I(16, "bodyCount:0,bodyCount:1,bodyCount:2,bodyCount:3,bodyCount:4,bodyCount:5", [], {
			counter: !0,
			consumable: !0
		})
	]
}, le = [
	"boomer",
	"patches",
	"picket",
	"tantrum"
], ue = {
	boomer: [
		2,
		3,
		4,
		4,
		5,
		6
	],
	patches: [
		3,
		3,
		3,
		3,
		4,
		4
	],
	picket: [
		2,
		2,
		3,
		3,
		3,
		5
	],
	tantrum: [
		3,
		4,
		4,
		4,
		5,
		5
	]
}, de = {
	boomer: [
		1,
		2,
		3,
		4
	],
	patches: [],
	picket: [],
	tantrum: [
		1,
		8,
		16
	]
}, fe = [
	1,
	1,
	1,
	1,
	2,
	0
], pe = [
	1,
	1,
	1,
	2,
	0,
	0
], me = [
	[
		"T1",
		"T2",
		"T3",
		"L1",
		"L3",
		"F2"
	],
	[
		"L1",
		"L2",
		"L3",
		"F1",
		"F3",
		"T2"
	],
	[
		"F1",
		"F2",
		"F3",
		"T1",
		"T3",
		"L2"
	]
], he = [
	"convert",
	"convert",
	"reroll",
	"reroll",
	"save",
	"save"
];
function ge(e, t) {
	return ce[e][t - 1];
}
function _e(e) {
	return e.split("|").map((e) => {
		let [t, n, r] = e.split(":");
		return {
			kind: t,
			n: n === void 0 ? 1 : Number(n),
			extra: r === void 0 ? 0 : Number(r)
		};
	});
}
//#endregion
//#region src/game/state.ts
var ve = {
	boomer: [
		3,
		3,
		1,
		2
	],
	patches: [
		5,
		2,
		1,
		1
	],
	picket: [
		5,
		2,
		1,
		2
	],
	tantrum: [
		4,
		3,
		3,
		0
	]
}, ye = () => ({
	kind: "none",
	by: "",
	step: 0,
	values: [],
	ids: [],
	wins: [],
	dice: [],
	data: {}
}), be = (e, t) => t + ":" + ++e.serial;
function L(t, n = 6) {
	let r = e(t.seed, t.cursor, n);
	return t.cursor += 1, r;
}
var xe = (e) => L(e) + 1;
function Se(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; t--) {
		let r = L(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
var R = (e, t) => e.actors.find((e) => e.id === t), Ce = (e, t) => e.actors.find((e) => e.owner === t && e.kind === "gearloc"), z = (e) => e.actors.filter((e) => e.kind === "gearloc"), B = (e) => e.actors.filter((e) => e.pos >= 0 && e.hp > 0), V = (e) => B(e).filter((e) => e.kind === "baddie" || e.kind === "object"), we = (e) => B(e).filter((e) => e.kind === "gearloc" || e.kind === "ally"), Te = (e) => e.kind === "gearloc" || e.kind === "object" ? void 0 : A(e.definition), Ee = (e, t) => e.inventory.some((e) => e.card === t && (!se(t)?.trove || e.locks === 3)), H = (e, t) => [...e.active, ...e.locked].filter((e) => e.kind === t).reduce((e, t) => e + t.n, 0), De = (e) => e.bones.reduce((e, t) => e + t.n, 0), Oe = (e, t, n, r = !1) => {
	if (!t.gearloc || !t.skills.includes(n) || t.exhausted.includes(n)) return !1;
	let i = r && t.gearloc === "picket" && [
		1,
		2,
		5,
		6
	].includes(n);
	if (e.actors.some((e) => [
		...e.active,
		...e.locked,
		...e.bones
	].some((r) => r.owner === t.id && r.skill === n && !(i && e === t && t.locked.includes(r))))) return !1;
	let a = ge(t.gearloc, n);
	return a.counter || t.effects.disable || (e.battle?.modifiers.noSkills ?? 0) >= (e.battle?.round ?? 0) || e.battle?.modifiers.untilLaneOne && !e.battle.defeated.some((t) => R(e, t)?.lane === 1) || t.gearloc === "boomer" && n === 13 && !e.battle?.defeated.length || t.gearloc === "patches" && n === 11 && !(t.counters.cells > 0) ? !1 : !a.grenade || t.counters.grenades > 0;
};
function U(e, t, n = "", r = "", i = 0, a = []) {
	e.log.push({
		key: t,
		who: n,
		target: r,
		n: i,
		values: a
	}), e.log.length > 250 && e.log.splice(0, e.log.length - 250);
}
function ke(e, t) {
	return {
		id: e,
		owner: t,
		kind: "gearloc",
		definition: "",
		gearloc: null,
		hp: 0,
		maxHp: 0,
		dex: 0,
		attack: 0,
		defense: 0,
		pos: -1,
		lane: 0,
		initiative: 0,
		ranged: !1,
		diagonal: !1,
		point: 0,
		target: "weakest",
		targets: 1,
		skills: [],
		exhausted: [],
		active: [],
		locked: [],
		bones: [],
		enemyDefense: [],
		effects: {},
		counters: {},
		inventory: [],
		training: 0,
		failedTraining: [],
		upgraded: !1,
		ready: !1,
		recovery: [],
		lockAttempted: !1
	};
}
function Ae(e, t, n) {
	let r = ke(t, t), [i, a, o, s] = ve[n], c = e.config.difficulty === "adventurer" ? 2 : +(e.config.difficulty === "heroic");
	return Object.assign(r, {
		definition: n,
		gearloc: n,
		hp: i + c,
		maxHp: i + c,
		dex: a,
		attack: o,
		defense: s,
		ranged: n === "boomer",
		skills: [...de[n]],
		training: e.config.difficulty === "legendary" ? 0 : 1
	}), r.counters = {
		baseHp: i,
		baseDex: a,
		baseAttack: o,
		baseDefense: s,
		hpTraining: 0,
		dexTraining: 0,
		attackTraining: 0,
		defenseTraining: 0,
		grenades: 0,
		axes: 0,
		bodyCount: 0,
		rageTier: 1,
		rageStep: 0
	}, r;
}
function je(e, t, n = "baddie") {
	let r = t.split("#")[0], i = A(r), a = ke(be(e, t), "");
	return Object.assign(a, {
		kind: n,
		definition: r,
		hp: i.hp,
		maxHp: i.hp,
		attack: i.attack,
		defense: i.defense,
		initiative: i.initiative,
		ranged: i.ranged,
		diagonal: i.diagonal,
		point: i.point,
		target: i.target,
		targets: i.targets
	}), a.counters.chip = Number(t.split("#")[1] ?? 0), e.actors.push(a), a;
}
function Me(e, t, n, r) {
	let i = ke(be(e, t), "");
	return Object.assign(i, {
		kind: "object",
		definition: t,
		hp: n,
		maxHp: n,
		pos: r
	}), e.actors.push(i), i;
}
function Ne(e, t, n, r, i = 0, a = t.id, o = !1, s = 0, c = !1) {
	let l = o ? t.locked : t.active;
	if (l.length >= 3) return null;
	let u = {
		uid: be(e, "slot"),
		owner: a,
		skill: i,
		kind: n,
		n: r,
		extra: s,
		reusable: c
	};
	return l.push(u), u;
}
function Pe(e, t) {
	if (!t || !e.gearloc) return;
	let n = ge(e.gearloc, t);
	n.consumable && !n.counter ? e.skills = e.skills.filter((e) => e !== t) : e.exhausted.includes(t) || e.exhausted.push(t);
}
function W(e, t, n) {
	t.active = t.active.filter((e) => e.uid !== n.uid), t.locked = t.locked.filter((e) => e.uid !== n.uid), t.bones = t.bones.filter((e) => e.uid !== n.uid);
	let r = R(e, n.owner);
	r && n.skill && !(n.kind === "bones" && n.reusable) && Pe(r, n.skill);
}
function Fe(e, t) {
	t.counters.cells--;
	for (let n of t.locked.filter((e) => e.kind === "cells")) n.n = t.counters.cells, n.n <= 0 && W(e, t, n);
}
function Ie(e, t, n) {
	if (De(t) < n) return !1;
	for (; n > 0 && t.bones.length;) {
		let r = t.bones[0];
		n -= r.n, W(e, t, r);
	}
	return !0;
}
function Le(e, t) {
	return !(!e.gearloc || !ge(e.gearloc, t)?.consumable || e.gearloc === "tantrum" && t === 16 || e.gearloc === "patches" && t === 12 && e.locked.length >= 3 && !e.locked.some((t) => t.owner === e.id && t.skill === 12));
}
function Re(e, t, n) {
	if (!Le(t, n)) return !1;
	if (t.skills.includes(n) || t.skills.push(n), t.exhausted = t.exhausted.filter((e) => e !== n), t.gearloc === "tantrum" && n === 8 && (t.counters.axes = 3), t.gearloc === "patches" && n === 12) {
		t.locked = t.locked.filter((e) => e.owner !== t.id || e.skill !== 12);
		let n = [
			1,
			2,
			2,
			3,
			3,
			3
		][L(e)];
		t.counters.cells = n, Ne(e, t, "cells", n, 12, t.id, !0);
	}
	return !0;
}
function ze(e, t, n, r = t.id) {
	if (e.phase === "battle" && t.hp <= 0 || t.effects.ale) return;
	let i = Math.max(0, Math.min(n, t.maxHp - t.hp));
	t.hp += i, i && U(e, "heal", r, t.id, i);
}
function Be(e, t, n, r) {
	if (n === "poison" && t.definition === "drellen") return;
	let i = [
		"poison",
		"bleed",
		"weaken",
		"stun",
		"disable",
		"terrify"
	];
	if (!(i.includes(n) && t.kind === "gearloc" && z(e).some((e) => H(e, "cleanse") > 0))) {
		if (i.includes(n) && t.kind === "gearloc" && Ee(t, "l19") && e.battle) {
			let i = "prevent:" + t.id + "|" + n;
			e.battle.reactions.includes(i) || e.battle.reactions.push(i), e.battle.pendingDamage[i] = r;
			return;
		}
		t.effects[n] = r, U(e, "effect", t.id, n, r);
	}
}
function Ve(e, t) {
	let n = se(t);
	return {
		uid: be(e, "loot"),
		card: t,
		uses: n?.uses ?? 2,
		locks: n?.trove ? 0 : 3
	};
}
function He(e, t, n = 1, r = !1) {
	let i = [];
	for (let a = 0; a < n; a++) {
		let n = r ? e.troveDeck : e.lootDeck, a = r ? e.troveDiscard : e.lootDiscard;
		!n.length && a.length && (n.push(...Se(e, a)), a.splice(0));
		let o = n.shift();
		if (!o) break;
		let s = Ve(e, o);
		t.inventory.push(s), i.push(s), U(e, r ? "trove" : "loot", t.id, o);
	}
	return i;
}
function Ue(e, t, n) {
	t.inventory = t.inventory.filter((e) => e.uid !== n.uid), n.card !== "water" && se(n.card) && (se(n.card).trove ? e.troveDiscard : e.lootDiscard).push(n.card);
}
var G = (e) => e.inventory.reduce((e, t) => e + (se(t.card)?.heavy && t.locks === 3 ? 3 : 1), 0);
function K(e) {
	let t = re[e.config.tyrant], n = Se(e, N.filter((t) => t.sheet === (e.players.length === 1 ? 0 : 29)).map((e) => e.id));
	e.unusedEncounters = n.slice(t.days - 3), e.encounterDeck = [
		"s1",
		"s2",
		"s3",
		...Se(e, [...n.slice(0, t.days - 3), ...t.encounters.map((e) => "t" + e)])
	], e.lootDeck = Se(e, ae.filter((e) => !e.trove).flatMap((e) => Array(e.copies).fill(e.id))), e.troveDeck = Se(e, ae.filter((e) => e.trove).map((e) => e.id));
	for (let n of [
		1,
		5,
		20
	]) e.stacks[n] = Se(e, ne.filter((e) => e.point === n && t.creatures.includes(e.creature)).flatMap((e) => Array.from({ length: e.copies }, (t, n) => e.id + "#" + n)));
	e.phase = z(e).some((e) => e.training > 0) ? "training" : "day", e.trainingReturn = "day";
}
function q(e, t, n, r, i) {
	let a = (e) => {
		let a = A(e.split("#")[0]);
		return a.point === t && (!n || a.creature === n) && (!r || a.id === r) && (i === void 0 || a.ranged === i);
	}, o = e.stacks[t] ?? [], s = o.findIndex(a);
	if (s < 0) {
		let t = e.defeatedStack.filter(a);
		e.defeatedStack = e.defeatedStack.filter((e) => !a(e)), o.push(...Se(e, t)), s = o.findIndex(a);
	}
	if (s < 0 && (n || r || i !== void 0)) {
		let t = ne.find((t) => a(t.id) && !e.persistent["removed:" + t.creature]);
		if (t) {
			let n = /* @__PURE__ */ new Set([
				...Object.values(e.stacks).flat(),
				...e.defeatedStack,
				...e.battle?.queue ?? [],
				...e.delayedBaddies.map((e) => e.chip),
				...Object.keys(e.persistent).filter((e) => e.startsWith("reserve:")).map((e) => e.slice(8)),
				...B(e).filter((e) => e.kind === "baddie" || e.kind === "ally").map((e) => e.definition + "#" + e.counters.chip)
			]), r = Array.from({ length: t.copies }, (e, n) => t.id + "#" + n).find((e) => !n.has(e));
			if (r) return r;
		}
	}
	if (s < 0) return null;
	let [c] = o.splice(s, 1);
	if (e.scouted[t] = (e.scouted[t] ?? []).filter((e) => e !== c), n || r || i !== void 0) {
		let n = e.scouted[t];
		e.stacks[t] = [...o.filter((e) => n.includes(e)), ...Se(e, o.filter((e) => !n.includes(e)))];
	}
	return c;
}
function We(e, t, n, r = !1, i = !1) {
	let a = [], o = Math.max(0, t);
	for (let t of r ? [1] : [
		20,
		5,
		1
	]) for (; o >= t;) {
		let r = q(e, t, n) ?? (n && !i ? q(e, t) : null);
		if (!r) break;
		a.push(r), o -= t;
	}
	return a;
}
function Ge(e, t) {
	!e.encounterDeck.includes(t) && !e.completed.includes(t) && e.encounter !== t && (e.encounterDeck = Se(e, [...e.encounterDeck, t]));
}
function Ke(e, t) {
	e.progress += t.progress;
	for (let n of z(e)) n.training += t.training, n.failedTraining = [], n.ready = !1, He(e, n, t.eachLoot), He(e, n, t.eachTrove, !0);
	let n = Ce(e, e.leader);
	He(e, n, t.loot), He(e, n, t.trove, !0);
}
function qe(e, t) {
	return {
		progress: e.progress + t.progress,
		training: e.training + t.training,
		loot: e.loot + t.loot,
		eachLoot: e.eachLoot + t.eachLoot,
		trove: e.trove + t.trove,
		eachTrove: e.eachTrove + t.eachTrove
	};
}
function J(e, t, n) {
	if (t && e.encounter) {
		let t = ie(e.encounter);
		Ke(e, n ?? qe(t.reward, t.choiceRewards[e.choice ?? 0] ?? j())), e.completed.includes(e.encounter) || e.completed.push(e.encounter);
	}
	U(e, t ? "encounterSuccess" : "encounterFailed", e.leader, e.encounter ?? ""), e.challenge = ye(), e.lock = null;
	for (let t of z(e)) t.ready = !1, t.recovery = [], t.lockAttempted = !1;
	e.trainingReturn = "recovery", e.persistent["today:skipRecovery"] && z(e).forEach((e) => {
		e.recovery = ["skip"];
	}), e.phase = t && z(e).some((e) => e.training > 0) ? "training" : "recovery";
}
function Je(e, t, n = !1) {
	let r = n ? pe : fe;
	return Array.from({ length: Math.max(0, t) }, () => r[L(e)]);
}
function Ye(e, t, n) {
	return {
		phase: "recruit",
		config: e,
		players: [...t],
		leader: t[0],
		actors: [],
		day: 1,
		progress: 0,
		encounter: null,
		choice: null,
		persistent: {},
		battle: null,
		lock: null,
		challenge: ye(),
		log: [],
		outcome: null,
		scouted: {},
		seed: n,
		cursor: 0,
		serial: 0,
		encounterDeck: [],
		unusedEncounters: [],
		lootDeck: [],
		troveDeck: [],
		lootDiscard: [],
		troveDiscard: [],
		stacks: {},
		defeatedStack: [],
		completed: [],
		trainingReturn: "day",
		pendingReward: j(),
		lastBattle: [],
		delayedBaddies: []
	};
}
//#endregion
//#region src/game/lockpicking.ts
function Xe(e, t, n, r, i, a) {
	let o = Ce(e, t), s = R(e, n)?.inventory.find((e) => e.uid === r);
	if (e.lock || !o || e.phase === "recovery" && o.lockAttempted || !i && (!s || !se(s.card)?.trove || s.locks === 3)) return !1;
	let c = z(e).filter((e) => Ee(e, "v10")).length, l = (i ?? [...se(s.card).locks]).map((e) => Math.max(1, e - c)), u = s?.locks ?? 0;
	return e.lock = {
		by: t,
		owner: n,
		loot: r,
		values: l,
		types: a ?? [
			"L",
			"T",
			"F"
		],
		at: u,
		startedAt: u,
		available: [
			0,
			1,
			2
		],
		rolled: [],
		intuition: "none",
		saved: null,
		retry: !1,
		usedIntuition: !1,
		returnTo: e.phase
	}, e.phase === "recovery" && (o.lockAttempted = !0), U(e, "lockStart", o.id, s?.card ?? "", u), !0;
}
function Ze(e) {
	let t = e.lock, n = Array.from({ length: 3 }, (e, n) => t.rolled[n] ?? "");
	for (let r of t.available) n[r] = me[r][L(e)];
	t.rolled = n, t.intuition = he[L(e)], t.usedIntuition = !1, t.saved = null;
}
function Qe(e, t) {
	let n = e.lock, r = R(e, n.owner)?.inventory.find((e) => e.uid === n.loot);
	r && (r.locks = n.at), e.persistent.lockSuccess = +!!t, e.persistent.lockOpened = n.at - n.startedAt, U(e, t ? "lockSuccess" : "lockFail", n.by, r?.card ?? "", n.at), e.lock = null;
}
function $e(e, t, n) {
	let r = e.lock;
	if (!r || r.by !== t) return !1;
	if (n.mode === "roll") return !r.rolled.length && (Ze(e), !0);
	if (n.mode === "stop") return r.at === r.startedAt && !r.retry ? (r.retry = !0, r.rolled = [], r.available = [
		0,
		1,
		2
	], r.saved = null, r.usedIntuition = !1, !0) : (Qe(e, !1), !0);
	if (!r.rolled.length) return !1;
	if (n.mode === "reroll") {
		if (r.intuition !== "reroll" || r.usedIntuition || n.dice?.length !== 1 || n.dice.some((e) => !r.available.includes(e))) return !1;
		for (let t of n.dice) r.rolled[t] = me[t][L(e)];
		return r.intuition = he[L(e)], r.saved = null, !0;
	}
	if (n.mode === "convert") return r.intuition !== "convert" || r.usedIntuition || n.die === void 0 || !r.available.includes(n.die) || !n.lockType ? !1 : (r.rolled[n.die] = n.lockType + r.rolled[n.die].slice(1), r.usedIntuition = !0, !0);
	if (n.mode === "save") {
		if (r.intuition !== "save" || r.usedIntuition || n.die === void 0 || !r.available.includes(n.die)) return !1;
		let e = r.rolled[n.die];
		return r.rolled[n.die] = e[0] + (Number(e.slice(1)) + 1), r.saved = n.die, r.usedIntuition = !0, !0;
	}
	if (n.mode === "solve") {
		let t = n.dice;
		if (!t?.length || new Set(t).size !== t.length || t.some((e) => !r.available.includes(e) || r.rolled[e][0] !== r.types[r.at]) || t.reduce((e, t) => e + Number(r.rolled[t].slice(1)), 0) < r.values[r.at]) return !1;
		r.available = r.available.filter((e) => !t.includes(e) || e === r.saved), r.at++;
		let i = R(e, r.owner)?.inventory.find((e) => e.uid === r.loot);
		return i && (i.locks = r.at), r.at >= r.values.length ? Qe(e, !0) : r.available.length ? (r.rolled = [], r.intuition = "none", r.usedIntuition = !1, r.saved = null) : Qe(e, !1), !0;
	}
	return !1;
}
//#endregion
//#region src/game/skills.ts
function et(e, t, n) {
	if (e.phase !== "training" || t.training <= 0 || t.failedTraining.includes(n.stat)) return !1;
	let r = n.stat;
	if (r === "skill") {
		if (!n.skill || !t.gearloc || t.skills.includes(n.skill)) return !1;
		let e = ge(t.gearloc, n.skill);
		if (e.consumable || !e.requires.every((e) => t.skills.includes(e))) return !1;
		t.skills.push(n.skill);
	} else {
		let n = t.counters[r + "Training"] ?? 0;
		if (n >= 5) return !1;
		let i = 0;
		if (r === "attack" || r === "defense") {
			let n = r === "attack" ? fe : pe, a = Array.from({ length: t[r] }, () => n[L(e)]), o = +!!Ee(t, "l18") + +!!Ee(t, "v16") + (t.counters.trainingIgnore ?? 0);
			i = e.persistent["today:trainingAuto"] ? 0 : Math.max(0, a.filter((e) => !e).length - o), t.counters.trainingIgnore = 0, r === "defense" && i && (i = Array.from({ length: i }, () => pe[L(e)]).filter((e) => !e).length, H(t, "improvedDefense") && (i = Math.max(0, i - 1))), U(e, "trainingRoll", t.id, r, i, a);
		}
		if (i) return t.failedTraining.push(r), !0;
		t.counters[r + "Training"] = n + 1, r === "hp" ? (t.maxHp++, t.hp++) : t[r]++;
	}
	return t.training--, t.failedTraining = [], U(e, "trained", t.id, r, n.skill ?? 1), !0;
}
function tt(e, t) {
	return Math.max(0, e[t] - (e.counters[t === "attack" ? "brokenAttack" : "brokenDefense"] ?? 0) - (t === "defense" ? e.active.filter((e) => e.kind === "defense").length : 0) + (t === "attack" ? H(e, "buffAttack") + (e.effects.attackMod ?? 0) - (e.effects.attackPenalty ?? 0) + (e.effects.extraAttack ?? 0) : 0));
}
var nt = (e) => Math.max(0, Math.min(e.dex, e.effects.dexCap || 99) - (e.effects.weaken ?? 0) - (e.effects.dexPenalty ?? 0) + (e.effects.extraDex ?? 0));
function rt(e, t, n) {
	let r = e.battle;
	if (r.stage !== "move" || r.startEffects.length || r.rolledOnce || !t.gearloc || new Set(n.skills).size !== n.skills.length) return !1;
	let i = n.target ? R(e, n.target) : void 0, a = [
		"troll",
		"orc",
		"scales",
		"goblin",
		"bog",
		"beast"
	].indexOf(i ? Te(i)?.creature ?? "" : "") + 1, o = Ee(t, "v7") && a === t.counters.necklaceType ? t.counters.necklace ?? 0 : 0, s = (t.effects.extraAttack ?? 0) + o, c = +!!Ee(t, "l15"), l = Math.max(0, n.attack - s) + Math.max(0, n.defense - c) + n.skills.length;
	if (!(n.attack + n.defense + n.skills.length) || l + r.spent > nt(t) || n.attack > tt(t, "attack") + o || n.defense > tt(t, "defense") + c || r.modifiers.noDefense && n.defense || r.modifiers.defenseOnly >= r.round && (n.attack || n.skills.length) || r.modifiers.meleeDefenseOnly >= r.round && !t.ranged && (n.attack || n.skills.length) || r.modifiers.skillOnly >= r.round && (n.attack || n.defense)) return !1;
	let u = (e) => t.gearloc === "picket" && [
		1,
		2,
		5,
		6
	].includes(e) && t.locked.some((n) => n.owner === t.id && n.skill === e);
	if (!n.skills.every((n) => Oe(e, t, n, u(n)))) return !1;
	let d = n.target ? R(e, n.target) : void 0;
	if (n.attack && (!d || !Dt(e, t, d)) && !Ee(t, "v14")) return !1;
	let f = n.skills.filter((e) => ge(t.gearloc, e).grenade);
	if (f.length > t.counters.grenades) return !1;
	for (let e of f) if (n.aims?.[String(e)] === void 0) return !1;
	let p = [];
	for (let [t, r, i] of [[
		"attack",
		n.attack,
		fe
	], [
		"defense",
		n.defense,
		pe
	]]) for (let n = 0; n < r; n++) {
		let n = i[L(e)];
		p.push({
			uid: be(e, "die"),
			kind: t,
			skill: 0,
			face: n ? t + ":" + n : "bones",
			used: !1,
			aim: -1
		});
	}
	for (let r of n.skills) {
		u(r) && (t.locked = t.locked.filter((e) => e.skill !== r || e.owner !== t.id));
		let i = ge(t.gearloc, r);
		p.push({
			uid: be(e, "die"),
			kind: "skill",
			skill: r,
			face: i.faces[L(e)],
			used: !1,
			aim: n.aims?.[String(r)] ?? -1
		}), t.gearloc === "patches" && r === 11 && Fe(e, t);
	}
	t.counters.grenades -= f.length, r.rolled = p, r.spent += l, r.rolledOnce = !0, r.stage = "resolve", r.target = n.target;
	let m = B(e).filter((e) => e.definition === "orb").length + +!!r.modifiers.orbBones, h = p.reduce((e, t) => e + _e(t.face).filter((e) => [
		"bones",
		"forcedBones",
		"reusableBones"
	].includes(e.kind)).reduce((e, t) => e + t.n, 0), 0);
	return m && h && Z(e, t, m * h), U(e, "roll", t.id, n.target ?? "", l), !0;
}
function it(e, t, n) {
	n.used = !0, n.skill && Pe(t, n.skill);
}
function at(e, t, n) {
	let r = (n.kind === "skill" ? ge(t.gearloc, n.skill).faces : n.kind === "attack" ? fe : pe)[L(e)];
	n.face = typeof r == "number" ? r ? n.kind + ":" + r : "bones" : r;
}
function ot(e, t) {
	let n = /* @__PURE__ */ new Set([t.pos]), r = [t.pos];
	for (let i = 0; i < 3; i++) {
		r = r.flatMap((n) => Lt(e, {
			...t,
			pos: n
		})).filter((e) => !n.has(e));
		for (let e of r) n.add(e);
	}
	return [...n];
}
function st(e, t, n, r, i, a = 1) {
	let o = r ? R(e, r) : void 0;
	if (n === "switch") {
		if (!o || o.hp <= 0 || !Y(t.pos, o.pos)) return !1;
		let n = t.pos;
		return t.pos = o.pos, o.pos = n, t.counters.switchUsed = (t.counters.switchUsed ?? 0) + a, t.counters.switchUsed >= 2 && (o.kind === "gearloc" || o.kind === "ally" ? ze(e, o, 3) : Z(e, o, 3, t)), !0;
	}
	return n !== "rush" || i === void 0 || !ot(e, t).includes(i) ? !1 : (t.pos = i, t.counters.rushUsed = (t.counters.rushUsed ?? 0) + a, t.counters.rushUsed >= 2 && o && o.kind === "baddie" && Y(i, o.pos) && Z(e, o, 3, t), !0);
}
function ct(e, t) {
	let n = t === "buffReroll" ? [
		9,
		10,
		14,
		16
	] : [1, 7];
	return e.filter((e) => !e.used && e.kind === "skill" && n.includes(e.skill) && (t !== "healMultiply" || e.face.startsWith("heal:")));
}
function lt(e, t, n, r, i) {
	let a = ct(e.battle.rolled, n).find((e) => e.uid === i);
	return a ? (n === "healMultiply" ? a.face = "heal:" + _e(a.face)[0].n * r : at(e, t, a), !0) : !1;
}
function ut(e, t, n) {
	let r = e.battle;
	if (r.stage !== "resolve" || new Set(n.dice).size !== n.dice.length) return !1;
	let i = n.dice.map((e) => r.rolled.find((t) => t.uid === e && !t.used));
	if (i.some((e) => !e)) return !1;
	let a = R(e, n.target ?? r.target ?? "");
	if (i.every((e) => e.kind === "attack" && e.face.startsWith("attack:")) && n.mode === "use") {
		let n = R(e, r.target ?? "");
		if (!n || !Dt(e, t, n)) return !1;
		let a = i.reduce((e, t) => e + _e(t.face)[0].n, 0) + (r.lastAttack.includes(t.id) ? 0 : H(t, "constantDamage"));
		return !n.effects.silverHide && Z(e, n, a, t) && X(n, "break") && (t.counters.brokenAttack = (t.counters.brokenAttack ?? 0) + i.length), X(n, "terrify") && Be(e, t, "terrify", 2), t.gearloc === "tantrum" && !r.lastAttack.includes(t.id) && Ot(t, 1), r.lastAttack.push(t.id), i.forEach((n) => it(e, t, n)), !0;
	}
	if (n.mode === "use" && i.length <= 2 && i.every((e) => e.kind === "skill" && ["switch", "rush"].includes(e.face) && e.face === i[0].face)) return st(e, t, i[0].face, n.target, n.pos, i.length) ? (i.forEach((n) => it(e, t, n)), !0) : !1;
	if (i.length !== 1) return !1;
	let o = i[0], s = _e(o.face), c = s[0];
	if (n.mode === "use" && [
		"healMultiply",
		"healReroll",
		"buffReroll"
	].includes(c.kind)) return lt(e, t, c.kind, c.n, n.target) ? (c.kind !== "healMultiply" && c.n > 1 ? o.face = c.kind + ":" + (c.n - 1) : it(e, t, o), !0) : !1;
	if (n.mode === "increase" && o.kind === "defense" && Ee(t, "l12") && !r.flags.includes("armor:" + o.uid) && ["bones", "defense:1"].includes(o.face)) return o.face = o.face === "bones" ? "defense:1" : "defense:2", r.flags.push("armor:" + o.uid), !0;
	if (n.mode === "bones") return [
		"bones",
		"forcedBones",
		"reusableBones"
	].includes(c.kind) ? (t.bones.push({
		uid: be(e, "bone"),
		owner: t.id,
		skill: o.skill,
		kind: "bones",
		n: c.n * (r.modifiers.doubleBones ? 2 : 1),
		extra: 0,
		reusable: c.kind === "reusableBones" || !o.skill
	}), o.used = !0, !0) : !1;
	if (n.mode === "discard") return o.face.includes("forcedBones") || o.face.includes("tainted") || t.gearloc === "boomer" && (o.skill === 16 || o.skill >= 5 && o.skill <= 11) ? !1 : (o.used = !0, !0);
	if (n.mode === "reroll") return !1;
	if (c.kind === "defense") return n.mode === "locked" && !(t.gearloc === "picket" && t.upgraded) || !Ne(e, t, "defense", c.n, 0, t.id, n.mode === "locked") ? !1 : (o.used = !0, !0);
	if (!o.skill) return !1;
	if ([
		"bones",
		"reusableBones",
		"forcedBones",
		"blank"
	].includes(c.kind)) {
		if (t.gearloc === "boomer" && t.upgraded && o.skill <= 3 && n.mode === "locked") {
			let n = [
				"element",
				"casing",
				"fuse"
			][o.skill - 1];
			return Ne(e, t, n, 1, o.skill, t.id, !0) ? (o.used = !0, !0) : !1;
		}
		return !1;
	}
	for (let r of s) if (!dt(e, t, o, r, n, a)) return !1;
	return o.used = !0, e.actors.some((e) => [...e.active, ...e.locked].some((e) => e.skill === o.skill && e.owner === t.id)) || Pe(t, o.skill), !0;
}
function dt(e, t, n, r, i, a) {
	let { kind: o, n: s, extra: c } = r, l = e.battle, u = (r, i = o, a = s, l = !1, u = c) => !!Ne(e, r, i, a, n.skill, t.id, l, u, ge(t.gearloc, n.skill).reusable), d = R(e, l.target ?? ""), f = B(e).find((e) => e.pos === n.aim);
	switch (o) {
		case "element":
		case "casing":
		case "fuse": return u(t, o, s + +!!t.upgraded, !0);
		case "parts": {
			let e = i.components ?? [
				i.amount === 1 ? s : 0,
				i.amount === 2 ? s : 0,
				i.amount === 3 ? s : 0
			];
			return e.reduce((e, t) => e + t, 0) === s && u(t, "parts", s, !0, e[0] * 100 + e[1] * 10 + e[2]);
		}
		case "grenades": return t.counters.grenades = Math.min(3, t.counters.grenades + s), !0;
		case "holyAcquire": return Re(e, t, 16);
		case "element325": return u(t, o, 1, !0);
		case "biggerBoom": return t.effects.biggerBoom = (t.effects.biggerBoom ?? 0) + s, !0;
		case "holyBlast":
		case "holyExplosion":
		case "explosion":
		case "blast": {
			let r = t.locked.find((e) => e.kind === "element325"), i = (o.startsWith("holy") && r ? c : s) + (n.skill === 5 || n.skill === 6 ? t.effects.biggerBoom ?? 0 : 0);
			if (o === "blast" || o === "holyBlast") for (let n of B(e).filter((e) => e.kind === "baddie")) Z(e, n, i, t);
			else {
				if (n.aim < 0) return !1;
				f && Z(e, f, i, t);
				for (let r of [...B(e)].filter((e) => Y(e.pos, n.aim))) Z(e, r, Math.floor(i / 2), t);
			}
			return o.startsWith("holy") && r && W(e, t, r), !0;
		}
		case "partyBacklash":
			for (let n of z(e)) Z(e, n, s, t);
			return !0;
		case "backlash": return Z(e, t, s, t), !0;
		case "stun":
		case "disable": {
			let n = t.gearloc === "boomer" ? f : a;
			return t.gearloc === "boomer" && (!n || n.kind !== "baddie" || n.point === 0 || n.point > s) ? !0 : !n || n.kind !== "baddie" || n.point === 0 || n.point > s || t.gearloc === "tantrum" && !Y(t.pos, n.pos) ? !1 : (Be(e, n, o, 1), !0);
		}
		case "napalm": return !f || f.kind !== "baddie" || (f.effects.napalm = s, f.effects.napalmRounds = c, f.counters.napalmSource = e.players.indexOf(t.owner) + 1, !0);
		case "smoke": return !f || f.kind !== "gearloc" || f.hp <= 0 || u(f);
		case "cleanse":
			for (let t of z(e)) for (let e of [
				"poison",
				"bleed",
				"weaken",
				"stun",
				"disable",
				"terrify"
			]) t.effects[e] = 0;
			return u(t);
		case "loot": return He(e, t, s), !0;
		case "healReroll": return u(t, o, s, !0);
		case "heal": return !a || a.kind !== "gearloc" || a.hp <= 0 ? !1 : (ze(e, a, s, t.id), !0);
		case "healSelf": return ze(e, t, s), !0;
		case "healMultiply":
		case "buffReroll": return u(t, o, s, !0);
		case "meleeDamage": return !d || !Dt(e, t, d, !1) ? !1 : (Z(e, d, s, t), !0);
		case "trueDamage": return !a || a.kind !== "baddie" || a.hp <= 0 ? !1 : (Z(e, a, s, t, "true"), !0);
		case "poisonTarget": return !d || !Dt(e, t, d, !1) ? !1 : (Be(e, d, "poison", s), !0);
		case "poisonAny": return !a || a.kind !== "baddie" || a.hp <= 0 ? !1 : (Be(e, a, "poison", s), !0);
		case "revive":
		case "reviveKo":
			if (!a || a.kind !== "gearloc" || o === "reviveKo" && a.hp > 0) return !1;
			if (a.hp <= 0) At(e, a, s);
			else return u(a, "revive", s);
			return !0;
		case "buffHp":
		case "buffAttack":
		case "recover":
		case "booster": return !a || a.kind !== "gearloc" || a.hp <= 0 ? !1 : u(a, o, s, !1, o === "buffHp" ? s : c);
		case "tainted": return Z(e, t, s, t, "true"), !0;
		case "permanentHp": return !a || a.kind !== "gearloc" ? !1 : (a.maxHp += s, a.hp += s, !0);
		case "constantRegen":
		case "constantMove":
		case "constantDefense":
		case "constantDamage":
		case "constantTaunt":
		case "improvedDefense": return u(t, o, s, !0);
		case "advancedDefense": return !a || a.kind !== "gearloc" || a.hp <= 0 ? !1 : u(a);
		case "intercept": return !a || a.kind !== "gearloc" || a === t ? !1 : u(a);
		case "ale": return u(t) ? (t.hp = 1, t.effects.ale = 1, !0) : !1;
		case "switch":
		case "rush":
		case "riposte": return u(t);
		case "anger": return Ot(t, i.mode === "decrease" ? -s / 2 : s / 2), !0;
		case "advance": return pt(e, t);
		case "axe": return t.counters.axes = Math.min(3, t.counters.axes + s), !0;
		case "poisonArmor":
		case "lashback":
		case "hardy": return u(t);
		case "dropInitiative": return !d || !Dt(e, t, d) ? !1 : (d.counters.dropInitiative = s, !0);
		case "attackMinus": return !a || a.kind !== "baddie" || !Y(a.pos, t.pos) ? !1 : (a.effects.attackMod = (a.effects.attackMod ?? 0) - s, u(a, "attackMod", -s));
		case "attackPlus": return u(t, "buffAttack", s);
		case "trainAttack": {
			let n = Array.from({ length: t.attack }, () => fe[L(e)]);
			return n.every(Boolean) && (t.attack++, t.counters.attackTraining++), U(e, "trainingRoll", t.id, "attack", 0, n), !0;
		}
		case "partyInspire": return l.flags.push("partyInspire"), !0;
		case "disorient":
			for (let t of B(e).filter((e) => e.kind === "baddie" && e.point > 0 && e.point <= s)) Be(e, t, "stun", 1);
			return !0;
		case "jump": return !a || a.kind !== "baddie" || i.pos === void 0 || B(e).some((e) => e.pos === i.pos) || !Y(i.pos, a.pos) ? !1 : (t.pos = i.pos, l.target = a.id, !0);
		case "taunt": return Be(e, t, "taunt", 1), u(t);
		default: return !1;
	}
}
function ft(e, t) {
	if (t.gearloc !== "boomer" || t.counters.grenades >= 3) return !1;
	let n = [
		"element",
		"casing",
		"fuse"
	].map((e, n) => t.locked.find((t) => t.kind === e && t.n > 0 || t.kind === "parts" && Math.floor(t.extra / [
		100,
		10,
		1
	][n]) % 10 > 0));
	if (n.some((e) => !e)) return !1;
	for (let [r, i] of n.entries()) i.n--, i.kind === "parts" && (i.extra -= [
		100,
		10,
		1
	][r]), i.n || W(e, t, i);
	return t.counters.grenades++, !0;
}
function pt(e, t) {
	let n = (t.counters.rageTier ?? 1) + 1, r = t.active.find((e) => e.kind === "rage");
	return !r || n > 3 || !t.skills.includes(n) || t.exhausted.includes(n) ? !1 : (t.counters.rageTier = n, t.counters.rageStep = 0, r.n = n * 10, r.skill = n, U(e, "rage", t.id, "", n), !0);
}
function mt(e, t, n, r) {
	if (t.gearloc !== "tantrum") return !1;
	let i = t.active.find((e) => e.kind === "rage");
	if (!i) return !1;
	let a = t.counters.rageTier, o = t.counters.rageStep;
	if (o === 5 && !t.upgraded) return !1;
	if (n === "advance") return o === 4 && pt(e, t);
	if (n === "execute") {
		if (o !== 4 || !r || r.kind !== "baddie" || r.point === 0 || r.point > [
			0,
			1,
			5,
			20
		][a] || !Y(r.pos, t.pos)) return !1;
		kt(e, r, t);
	} else if (n === "heal") {
		if (a !== 2 || o < 1 || o > 3) return !1;
		ze(e, t, o);
	} else if (n === "bones") {
		if (a !== 1 || o < 1 || o > 3) return !1;
		t.bones.push({
			uid: be(e, "bone"),
			owner: t.id,
			skill: 0,
			kind: "bones",
			n: o,
			extra: 0,
			reusable: !0
		});
	} else if (n === "damage") {
		if (a !== 3 || o < 1 || o > 3 || !r || r.id !== e.battle?.target || !Dt(e, t, r)) return !1;
		Z(e, r, 2, t);
	} else return !1;
	return W(e, t, i), a > 1 && !t.exhausted.includes(1) && (t.counters.rageTier = 1, t.counters.rageStep = 0, Ne(e, t, "rage", 10, 1)), !0;
}
function ht(e, t, n) {
	let r = e.battle, i = n.cost, a = R(e, n.target ?? r.target ?? ""), o = Math.max(0, i - (i < 6 && Ee(t, "v3") ? 1 : 0));
	if (r.backupUsed || De(t) < o || !t.gearloc || r.modifiers.noBackup) return !1;
	if (i === 6) {
		if (t.upgraded) return !1;
		t.upgraded = !0, t.gearloc === "patches" && (t.maxHp++, t.hp++);
	} else if (t.gearloc === "boomer") {
		if (i === 1 || i === 4) {
			if (!a || a.id !== r.target || !Dt(e, t, a)) return !1;
			Z(e, a, i === 1 ? 1 : 3, t);
		}
		if (i === 2) {
			let i = r.rolled.filter((e) => n.ids?.includes(e.uid) && e.skill >= 1 && e.skill <= 3 && !e.used);
			if (!i.length) return !1;
			i.forEach((n) => at(e, t, n));
		}
		if (i === 3) {
			if (!a || n.pos === void 0 || !Lt(e, a).includes(n.pos)) return !1;
			a.pos = n.pos;
		}
		i === 5 && Be(e, t, "untargetable", 1);
	} else if (t.gearloc === "patches") {
		if (i === 1) return !1;
		if (i === 2) {
			if (!a || a.kind !== "gearloc") return !1;
			ze(e, a, 1, t.id);
		}
		if (i === 3) {
			if (!a || a.id !== r.target || !Dt(e, t, a, !1)) return !1;
			Z(e, a, 2, t);
		}
		if (i === 4 && (!n.skill || !Re(e, t, n.skill))) return !1;
		if (i === 5) {
			if (t.counters.cells <= 0 || !a || a.kind !== "baddie") return !1;
			Fe(e, t), Z(e, a, 4, t, "true");
		}
	} else if (t.gearloc === "picket") {
		if (i === 1) return !1;
		if (i === 2 || i === 5) {
			if (!a || a.id !== r.target || !Dt(e, t, a, !1)) return !1;
			let n = 0;
			for (let r of [...t.active, ...t.locked].filter((e) => [
				"defense",
				"advancedDefense",
				"constantDefense"
			].includes(e.kind))) n += r.n, r.reusable = !1, W(e, t, r);
			for (let i of r.rolled.filter((e) => !e.used && (e.face.startsWith("defense:") || e.face.startsWith("advancedDefense:")))) n += _e(i.face)[0].n, it(e, t, i);
			Z(e, a, n, t), i === 5 && a.point > 0 && Be(e, a, "stun", 1);
		}
		if (i === 3) {
			let i = r.rolled.filter((e) => n.ids?.includes(e.uid) && !e.used);
			if (!i.length) return !1;
			i.forEach((n) => at(e, t, n));
		}
		if (i === 4 && (ze(e, t, 2), !Ne(e, t, "defense", 2))) return !1;
	} else {
		if (i === 1 && Ot(t, 1), i === 2 && Ot(t, -1), i === 3) return !1;
		i === 4 && (t.counters.axes = 3), i === 5 && ze(e, t, 4);
	}
	return Ie(e, t, o), r.backupUsed = !0, U(e, "backup", t.id, a?.id ?? "", i), !0;
}
var gt = (e) => e.gearloc ? ce[e.gearloc].filter((t) => !t.consumable && !e.skills.includes(t.id) && t.requires.every((t) => e.skills.includes(t))).map((e) => e.id) : [];
//#endregion
//#region src/game/loot.ts
function _t(e, t, n) {
	let r = t.inventory.find((e) => e.uid === n.loot);
	if (!r) return !1;
	let i = se(r.card), a = R(e, n.target ?? t.id), o = e.battle, s = e.phase === "battle" && o?.turn === t.id && ["move", "resolve"].includes(o.stage) && !o.startEffects.length;
	if (n.mode === "discard") return [
		"training",
		"recovery",
		"encounter",
		"day"
	].includes(e.phase) ? (Ue(e, t, r), !0) : !1;
	if (n.mode === "give") return e.phase !== "recovery" || !a || a.kind !== "gearloc" || a === t ? !1 : (t.inventory = t.inventory.filter((e) => e !== r), a.inventory.push(r), !0);
	if (!i || i.trove && r.locks < 3) return !1;
	if (i.trove) {
		if (n.mode === "use" && i.slot === 21) return bt(e, t, n.amount ?? 1);
		if (n.mode === "use" && i.slot === 13) return !["day", "encounter"].includes(e.phase) || !n.amount || n.amount > 4 ? !1 : (t.counters.squirrelLane = n.amount, !0);
		if (n.mode !== "backup" || !s || !o || o.backupUsed || !i.backup || !Ie(e, t, Math.max(0, i.backup - +!!Ee(t, "v3")))) return !1;
		if (i.slot === 2) {
			let i = n.amount === 0 ? "attack" : n.amount === 1 ? "defense" : "skill";
			if (i === "skill") {
				if (!n.skill || !t.gearloc || !Oe(e, t, n.skill)) return !1;
				let a = ge(t.gearloc, n.skill);
				if (a.grenade && (!(t.counters.grenades > 0) || n.pos === void 0)) return !1;
				let s = {
					uid: r.uid + ":" + e.cursor,
					kind: i,
					skill: n.skill,
					face: "",
					used: !1,
					aim: n.pos ?? -1
				};
				at(e, t, s), o.rolled.push(s), a.grenade && t.counters.grenades--, t.gearloc === "patches" && n.skill === 11 && Fe(e, t);
			} else {
				let t = Je(e, 1, i === "defense")[0];
				o.rolled.push({
					uid: r.uid + ":" + e.cursor,
					kind: i,
					skill: 0,
					face: t ? i + ":" + t : "bones",
					used: !1,
					aim: -1
				});
			}
			o.stage = "resolve";
		} else if (i.slot === 4) {
			let n = R(e, o.target ?? "");
			if (!n) return !1;
			let r = n.active.filter((e) => e.kind === "defense");
			if (t.active.length + r.length > 3 || (t.active.push(...r), n.active = n.active.filter((e) => e.kind !== "defense"), n.enemyDefense.length + t.active.length > 3)) return !1;
			for (let r of n.enemyDefense) Ne(e, t, "defense", r);
			n.enemyDefense = [];
		} else if (i.slot === 6) {
			if (t.counters["used:" + r.uid]) return !1;
			Be(e, t, "untargetable", 1), t.counters["used:" + r.uid] = 1;
		} else if (i.slot === 8) {
			let t = R(e, o.target ?? "");
			if (!t) return !1;
			t.counters.dropInitiative = (t.counters.dropInitiative ?? 0) + 1;
		} else if (i.slot === 9) {
			if (!a || a.kind !== "baddie" || ![1, 5].includes(a.point)) return !1;
			Be(e, a, "stun", 1), L(e) === 0 && Be(e, t, "stun", 1);
		} else if (i.slot === 11) {
			if (t.maxHp <= t.counters.baseHp) return !1;
			t.maxHp--, t.hp = Math.min(t.hp, t.maxHp), ze(e, t, 3);
		} else if (i.slot === 12) {
			if (!a || a.kind !== "baddie" || t.counters["used:" + r.uid]) return !1;
			Z(e, a, 2, t), L(e) >= 3 && (t.counters["used:" + r.uid] = 1);
		} else if (i.slot === 15) {
			if (!a || a.kind !== "gearloc") return !1;
			ze(e, a, 1, t.id);
		} else if (i.slot === 17) {
			let t = o.rolled.find((e) => n.ids?.includes(e.uid) && !e.used && e.face.startsWith("attack:")), r = R(e, o.target ?? "");
			if (!t || !r) return !1;
			Be(e, r, "poison", _e(t.face)[0].n);
		} else if (i.slot === 18) {
			let r = o.rolled.find((e) => e.uid === n.ids?.[0] && !e.used);
			if (!r) return !1;
			at(e, t, r);
		} else if (i.slot === 19) t.counters.dropInitiative = (t.counters.dropInitiative ?? 0) - 1;
		else if (i.slot === 22) {
			if (t.counters["used:" + r.uid] || !a || !n.skill || !a.exhausted.includes(n.skill)) return !1;
			a.exhausted = a.exhausted.filter((e) => e !== n.skill), t.counters["used:" + r.uid] = 1;
		} else return !1;
		return o.backupUsed = !0, U(e, "lootUsed", t.id, r.card), !0;
	}
	let c = 1;
	switch (i.slot) {
		case 29:
			if (!a || a.kind !== "gearloc" || !n.amount || n.amount > r.uses || e.phase === "battle" && !s) return !1;
			ze(e, a, n.amount, t.id), c = n.amount;
			break;
		case 0:
			if (!["day", "encounter"].includes(e.phase)) return !1;
			e.persistent.flare = (e.persistent.flare ?? 0) + 3;
			break;
		case 1:
			if (!n.skill || !Re(e, t, n.skill)) return !1;
			break;
		case 2:
			if (!s) return !1;
			ze(e, t, 5), Be(e, t, "poison", 2);
			break;
		case 3:
			if (e.phase !== "training" || !t.failedTraining.length) return !1;
			t.failedTraining = [];
			break;
		case 4:
			if (!s || !o || o.rolledOnce) return !1;
			t.effects.extraAttack = (t.effects.extraAttack ?? 0) + 2;
			break;
		case 5:
			if (e.phase === "battle" || !a || a.kind !== "gearloc" || !n.amount || n.amount > r.uses) return !1;
			ze(e, a, n.amount, t.id), c = n.amount;
			break;
		case 6:
			if (!s) return !1;
			t.effects.extraDex = (t.effects.extraDex ?? 0) + 3;
			break;
		case 7:
			if (e.lock?.by !== t.owner || e.lock.values[e.lock.at] > 4) return !1;
			e.lock.at++, e.lock.rolled = [], e.lock.at >= e.lock.values.length && Qe(e, !0);
			break;
		case 8:
			if (e.phase === "battle" && !s) return !1;
			ze(e, t, e.phase === "battle" ? 3 : 5);
			break;
		case 9:
		case 11:
		case 20: {
			let r = e.lock, a = n.amount;
			if (!r || i.slot !== 9 && r.by !== t.owner || a === void 0 || !r.available.includes(a) || !r.rolled[a]) return !1;
			r.rolled[a] = r.rolled[a][0] + (Number(r.rolled[a].slice(1)) + (i.slot === 9 ? 1 : i.slot === 11 ? 2 : 4));
			break;
		}
		case 10:
			if (!s) return !1;
			ze(e, t, 1);
			break;
		case 12:
		case 15:
		case 18: return !1;
		case 13:
			if (e.phase !== "training") return !1;
			t.counters.trainingIgnore = (t.counters.trainingIgnore ?? 0) + 1;
			break;
		case 14:
			if (e.lock && e.lock.by === t.owner && n.amount !== void 0 && e.lock.available.includes(n.amount)) {
				let t = n.amount;
				e.lock.rolled[t] = me[t][L(e)];
			} else if (s && o) {
				let r = o.rolled.find((e) => e.uid === n.ids?.[0] && !e.used);
				if (!r) return !1;
				at(e, t, r);
			} else if (e.phase === "battle" && o?.stage === "deployment") {
				if (!t.gearloc) return !1;
				t.initiative = ue[t.gearloc][L(e)];
			} else return !1;
			break;
		case 16:
			if (!o || o.stage !== "endRound") return !1;
			t.counters.dropInitiative = -3;
			break;
		case 17: {
			let t = e.lastBattle.find((t) => t === n.target || e.persistent["defeatedType:" + t] === n.amount);
			if (e.phase !== "day" || !t) return !1;
			let r = e.persistent["defeatedType:" + t];
			if (!r) return !1;
			e.persistent.skinning = r;
			break;
		}
		case 19: return !1;
		case 21:
			if (e.phase !== "day" || e.encounterDeck.length < 2) return !1;
			e.phase = "challenge", e.challenge = {
				kind: "decision",
				by: t.owner,
				step: 0,
				ids: ["pickEncounter", ...e.encounterDeck.splice(0, 2)],
				values: [],
				wins: [],
				dice: [],
				data: {}
			};
			break;
		case 22:
			if (e.phase !== "recovery") return !1;
			He(e, t, 1, !0);
			break;
		case 23:
			if (!s || !a || a.hp <= 0 || a.pos < 0) return !1;
			Z(e, a, Je(e, 1)[0], t);
			break;
		case 24:
			if (e.phase === "battle") return !1;
			Ge(e, "s4");
			break;
		case 25:
			if (e.phase === "battle") return !1;
			t.maxHp++, t.hp++, t.counters.brew = (t.counters.brew ?? 0) + 3;
			break;
		case 26:
			if (!s || !a || !n.skill || !a.exhausted.includes(n.skill)) return !1;
			a.exhausted = a.exhausted.filter((e) => e !== n.skill);
			break;
		case 27:
			if (!s) return !1;
			t.effects.zelfey = 1;
			break;
		case 28:
			if (!a || a.kind !== "gearloc" || e.phase === "battle" && !s) return !1;
			ze(e, a, 2, t.id);
			break;
		default: return !1;
	}
	return r.uses -= c, r.uses <= 0 && Ue(e, t, r), U(e, "lootUsed", t.id, r.card), !0;
}
function vt(e, t, n, r) {
	if (![
		1,
		5,
		20
	].includes(r) || r > n) return !1;
	let i = Ce(e, t), a = e.stacks[r]?.find((t) => !(e.scouted[r] ?? []).includes(t));
	return !i || !a ? !1 : (e.scouted[r] = [...e.scouted[r] ?? [], a], e.challenge = {
		kind: "scout",
		by: t,
		step: 0,
		values: [r],
		ids: [a],
		wins: [],
		dice: [],
		data: { max: n }
	}, !0);
}
function yt(e, t, n) {
	let r = e.challenge;
	if (r.kind !== "scout" || r.by !== t || ![0, 1].includes(n)) return !1;
	if (n === 1) {
		let t = e.stacks[r.values[0]], n = r.ids[0];
		e.stacks[r.values[0]] = [...t.filter((e) => e !== n), n], e.scouted[r.values[0]] = e.scouted[r.values[0]].filter((e) => e !== n);
	}
	return r.kind = "none", !0;
}
function bt(e, t, n) {
	return e.phase === "battle" || t.counters.scopeDay === e.day || !Ee(t, "v21") || !vt(e, t.owner, 20, n) ? !1 : (t.counters.scopeDay = e.day, !0);
}
function xt(e, t, n) {
	let r = Te(n)?.creature;
	if (!r) return;
	let i = [
		"troll",
		"orc",
		"scales",
		"goblin",
		"bog",
		"beast"
	].indexOf(r) + 1;
	e.persistent["defeatedType:" + n.id] = i, Ee(t, "v7") && (t.counters.necklaceType || (t.counters.necklaceType = i), t.counters.necklaceType === i && (t.counters.necklace = (t.counters.necklace ?? 0) + 1));
}
//#endregion
//#region src/game/combat.ts
var St = (e) => Math.floor(e / 4), Ct = (e) => e % 4;
function Y(e, t, n = !1) {
	if (e < 0 || t < 0 || e === t) return !1;
	let r = Math.abs(Ct(e) - Ct(t)), i = Math.abs(St(e) - St(t));
	return n ? Math.max(r, i) === 1 : r + i === 1;
}
var wt = (e, t) => B(e).some((e) => e.pos === t), Tt = (e) => e.battle?.flags.includes("tyrant") && e.config.tyrant === "drellen" ? 2 : 1;
function Et(e, t = !1) {
	return Array.from({ length: 16 }, (e, t) => t).filter((n) => Y(e, n, t));
}
var X = (e, t) => e.effects.disable ? 0 : Te(e)?.skills[t] ?? 0;
function Dt(e, t, n, r = t.ranged) {
	let i = (e) => e.kind === "gearloc" || e.kind === "ally";
	if (i(t) === i(n) || t.hp <= 0 || n.hp <= 0 || t.pos < 0 || n.pos < 0 || n.effects.untargetable || n.effects.flight || t.effects.terrify && X(n, "terrify") || n.counters.throne && B(e).some((e) => e.definition === "throne") || n.effects.throne && !Y(t.pos, n.pos) || X(n, "shrouded") && !Y(t.pos, n.pos, !0) || !r && !Y(t.pos, n.pos, t.diagonal)) return !1;
	let a = i(t) ? V(e) : we(e);
	if (t.kind === "gearloc" && e.battle?.modifiers.meleeFirst && n.ranged && V(e).some((e) => !e.ranged)) return !1;
	let o = a.filter((e) => (e.effects.taunt || H(e, "constantTaunt")) && Y(e.pos, t.pos, t.diagonal));
	return !o.length || o.includes(n);
}
function Ot(e, t) {
	let n = e.active.find((e) => e.kind === "rage");
	n && (e.counters.rageStep = Math.max(0, Math.min(5, (e.counters.rageStep ?? 0) + t)), n.n = (e.counters.rageTier ?? 1) * 10 + e.counters.rageStep * 2);
}
function kt(e, t, n) {
	if (t.pos < 0) return;
	let r = e.battle;
	if (t.hp = 0, t.pos = -1, t.kind === "gearloc") {
		for (let n of [...t.active, ...t.bones]) W(e, t, n);
		if (e.config.difficulty !== "adventurer") for (let n of [...t.locked]) W(e, t, n);
		U(e, "ko", t.id);
		for (let t of z(e).filter((e) => e.hp > 0 && e.counters.cloaked)) t.counters.cloaked = 0, r?.later.push(t.id), r?.flags.push("immediateEntry");
		r?.flags.includes("tyrant") && e.config.tyrant === "nom" && z(e).some((e) => e.hp > 0 && e.counters.reserve === 99) && r.reactions.push("nomNext");
	} else {
		let i = Te(t)?.creature;
		if (i && (e.persistent["defeatedType:" + t.id] = [
			"troll",
			"orc",
			"scales",
			"goblin",
			"bog",
			"beast"
		].indexOf(i) + 1), n?.kind === "gearloc" && t.kind === "baddie" && xt(e, n, t), n?.gearloc === "tantrum" && (n.counters.bodyCount = Math.min(5, n.counters.bodyCount + 1)), r?.defeated.push(t.id), t.kind === "baddie" && t.point > 0) {
			let n = t.definition + "#" + t.counters.chip;
			r && X(t, "undead") && !e.persistent["undead:" + n] ? (e.persistent["undead:" + n] = 1, r.queue.unshift(n)) : r && (r.modifiers.returnDead >= r.round || r.modifiers.returnOrcs >= r.round && A(t.definition).creature === "orc") ? r.queue.push(n) : e.defeatedStack.push(n);
		}
		U(e, "defeat", n?.id ?? "", t.id);
	}
	if (r?.modifiers.duel) {
		r.modifiers.duel = 0;
		for (let t of z(e).filter((e) => e.hp > 0 && e.counters.reserve > 0 && e.counters.reserve !== 99)) t.counters.reserve = 0, r.later.push(t.id);
		r.flags.push("immediateEntry");
	}
	if (r?.modifiers.singleLane) {
		let n = t.kind === "gearloc" ? 8 : 4, i = t.kind === "gearloc" ? 12 : 0, a = B(e).find((e) => e.pos === i);
		!wt(e, n) && a && (a.pos = n), t.kind === "gearloc" && z(e).some((e) => e.hp > 0 && e.counters.reserve === 98) && r.reactions.push("lineupNext");
	}
}
function Z(e, t, n, r, i = "normal") {
	if (t.hp <= 0 || t.pos < 0 || t.effects.ale || n <= 0 || t.definition === "goblinking" && r === t) return 0;
	let a = e.battle, o = n;
	if (X(t, "bogRuler") && V(e).some((e) => e !== t && Te(e)?.creature === "bog")) return 0;
	if (i === "normal") {
		let n = X(t, "thickSkin"), r = a?.hpLost[t.id + ":skin"] ?? 0, i = Math.min(o, Math.max(0, n - r));
		a && (a.hpLost[t.id + ":skin"] = r + i), o -= i;
		for (let n of [...t.active, ...t.locked].filter((e) => [
			"defense",
			"advancedDefense",
			"constantDefense"
		].includes(e.kind))) {
			if (o <= 0) break;
			let r = Math.min(o, n.n);
			o -= r, n.kind !== "constantDefense" && (n.n -= r, n.n || W(e, t, n));
		}
		for (let e of [...t.enemyDefense]) {
			if (o <= 0) break;
			let n = Math.min(o, e);
			if (o -= n, t.enemyDefense[0] -= n, t.enemyDefense[0] === 0) t.enemyDefense.shift();
			else break;
		}
		let s = t.counters.armor ?? 0, c = Math.min(o, s);
		o -= c, t.counters.armor = s - c;
	}
	if (i === "normal") {
		for (let n of [...t.active].filter((e) => e.kind === "buffHp")) {
			let r = Math.min(o, n.n);
			n.n -= r, o -= r, n.n || W(e, t, n);
		}
		if (!t.active.some((e) => e.kind === "buffHp")) for (let n of [...t.active].filter((e) => e.kind === "booster")) W(e, t, n);
	}
	(X(t, "hardy") || H(t, "hardy")) && (o = Math.min(o, Math.max(0, 1 - (a?.hpLost[t.id] ?? 0))));
	let s = Math.min(t.hp, o);
	if (t.hp -= s, a && (a.hpLost[t.id] = (a.hpLost[t.id] ?? 0) + s), t.gearloc === "tantrum" && Ot(t, s), s && U(e, "damage", r?.id ?? "", t.id, s), t.hp <= 0) {
		let n = t.active.find((e) => e.kind === "revive");
		n ? (t.hp = Math.min(t.maxHp, n.n), W(e, t, n)) : kt(e, t, r);
	}
	if (s && i === "normal" && r && r.hp > 0 && Y(r.pos, t.pos, r.diagonal) && t.hp > 0) {
		let n = X(t, "lashback");
		n && !a?.hpLost[t.id + ":lash"] && (a && (a.hpLost[t.id + ":lash"] = 1), Z(e, r, n, t)), t.kind === "gearloc" && (H(t, "lashback") || H(t, "poisonArmor")) && a && a.reactions.push("retaliate:" + t.id + "|" + r.id);
	}
	return s;
}
function At(e, t, n) {
	t.hp > 0 || !e.battle || (t.hp = Math.min(n, t.maxHp), e.battle.later.push(t.id), U(e, "revive", t.id, "", t.hp));
}
function jt(e, t = {}) {
	e.phase = "battle", e.challenge = {
		kind: "none",
		by: "",
		step: 0,
		values: [],
		ids: [],
		wins: [],
		dice: [],
		data: {}
	}, e.actors = z(e);
	let n = {
		round: 1,
		order: [],
		at: 0,
		stage: "deployment",
		turn: null,
		target: null,
		rolled: [],
		spent: 0,
		rolledOnce: !1,
		backupUsed: !1,
		queue: t.queue ?? We(e, t.points ?? e.day * e.players.length),
		modifiers: t.modifiers ?? {},
		flags: [],
		enemyTargets: [],
		enemyRolls: [],
		enemyBones: 0,
		tyrantFace: -1,
		startEffects: [],
		reactions: [],
		pendingDamage: {},
		defeated: [],
		later: [],
		lastAttack: [],
		hpLost: {}
	};
	if (e.battle = n, e.delayedBaddies = [], n.modifiers.singleLane) {
		for (let t of z(e)) t.counters.reserve = 98;
		z(e).some((e) => e.hp > 0) && n.reactions.push("lineupNext");
	}
	for (let t of z(e)) if (t.pos = -1, t.ready = t.hp <= 0, t.effects = {}, t.exhausted = [], t.active = [], t.bones = [], t.counters.brokenAttack = 0, t.counters.brokenDefense = 0, t.counters.armor = 0, t.initiative = ue[t.gearloc][L(e)], t.gearloc === "tantrum" && (t.counters.rageTier = 1, t.counters.rageStep = 0, Ne(e, t, "rage", 10, 1)), t.gearloc === "picket") {
		let r = Je(e, t.defense, !0).filter(Boolean).sort((e, t) => t - e);
		if (t.upgraded && r.length) r.forEach((e, n) => {
			t.counters["shield:" + n] = e;
		}), n.reactions.push("shield:" + t.id);
		else for (let n of r.slice(0, 3)) Ne(e, t, "defense", n);
	}
	if (t.tyrant) {
		if (n.flags.push("tyrant"), e.config.tyrant === "nom") {
			n.queue.push("nom");
			for (let t of z(e)) t.counters.reserve = 99;
			z(e).some((e) => e.hp > 0) && n.reactions.push("nomNext");
		} else if (e.config.tyrant === "mulmesh") n.queue = [
			...Object.keys(e.persistent).filter((e) => e.startsWith("reserve:")).map((e) => e.slice(8)),
			...n.queue,
			"mulmesh"
		];
		else if (e.config.tyrant === "duster") {
			for (let t of n.queue) (e.stacks[A(t.split("#")[0]).point] ??= []).unshift(t);
			n.queue = ["duster", ...Array.from({ length: e.players.length }, () => q(e, e.players.length <= 2 ? 1 : 5)).filter((e) => !!e)];
		} else if (e.config.tyrant === "gendricks") n.queue.unshift("gendricks", q(e, 1, "scales", "koboldgreenthumb") ?? "koboldgreenthumb#0");
		else {
			let t = je(e, e.config.tyrant);
			if (t.lane = e.config.tyrant === "marrow" ? 3 : 1, t.pos = e.config.tyrant === "marrow" ? 2 : t.ranged ? 0 : 4, e.config.tyrant === "goblinking" && (t.pos = 0, !e.persistent.goblinBomb)) {
				let n = Me(e, "throne", 2, 0);
				n.effects.throne = 1, t.counters.throne = 1;
			}
			e.config.tyrant === "drellen" && n.queue.unshift(...Array.from({ length: 2 }, () => q(e, e.players.length <= 2 ? 1 : 5, "bog")).filter((e) => !!e));
		}
	}
	for (let t of z(e)) {
		t.counters.freeMoveUsed = 0, t.counters.afterAttackMove = 0, t.effects.extraAttack = 0, t.effects.extraDex = 0, n.modifiers.ignoreAttackTraining && (t.effects.attackPenalty = t.counters.attackTraining), n.modifiers.attackPlus && (t.effects.attackMod = n.modifiers.attackPlus), n.modifiers.dexPenalty && (t.effects.dexPenalty = n.modifiers.dexPenalty), n.modifiers.dexCap && (t.effects.dexCap = n.modifiers.dexCap), t.counters.prepBuff && (Ne(e, t, "buffHp", t.counters.prepBuff), t.counters.prepBuff = 0);
		for (let n of t.skills) e.persistent["trip:" + t.id + ":" + n] && (t.exhausted.push(n), delete e.persistent["trip:" + t.id + ":" + n]);
		if (n.modifiers.shieldWall && t.gearloc !== "picket") for (let n of Je(e, t.defense, !0).filter(Boolean).slice(0, 3)) Ne(e, t, "defense", n);
		for (let e of Object.keys(t.counters).filter((e) => e.startsWith("used:"))) t.counters[e] = 0;
		t.counters.brew && (t.hp = Math.max(0, t.hp - t.counters.brew), t.counters.brew = 0);
	}
	if (n.modifiers.orbPillar && Me(e, "orbPillar", n.modifiers.orbPillar, 0), n.modifiers.trader) {
		let t = Me(e, "trader", 4, 8);
		t.kind = "ally", t.attack = 2, t.owner = e.players[0], t.initiative = z(e)[0].initiative;
	}
	if (n.modifiers.golemAlly) {
		let t = je(e, q(e, 20, "bog", "goldengolem") ?? "goldengolem#0", "ally");
		t.pos = 8, t.owner = e.players[0];
		for (let t of z(e)) t.counters.reserve = 3;
	}
	Mt(e), U(e, "battle", "", "", n.queue.length);
}
function Mt(e) {
	let t = e.battle, n = t.stage === "endRound" ? t.round + 1 : t.round, r = e.delayedBaddies.filter((e) => e.until <= n);
	e.delayedBaddies = e.delayedBaddies.filter((e) => e.until > n), t.queue.unshift(...r.map((e) => e.chip));
	for (let r = 1; r <= 4 && t.queue.length; r++) {
		if (t.modifiers.singleLane && r > 2 || t.modifiers.duel && t.round <= 3 && r > 1 || !t.modifiers.singleLane && V(e).some((e) => e.lane === r)) continue;
		let i = t.queue[0], a = je(e, i), o = a.point > 0 && z(e).find((e) => Ee(e, "v13") && e.counters.squirrelLane === r && !e.counters["used:squirrel"]);
		if (o) {
			o.counters["used:squirrel"] = 1, t.queue.shift(), e.actors.pop(), e.delayedBaddies.push({
				chip: i,
				until: n + 1
			});
			continue;
		}
		let s = [
			(a.ranged ? 0 : 4) + r - 1,
			...Array.from({ length: 4 }, (e, t) => (a.ranged ? 0 : 4) + t),
			...Array.from({ length: 4 }, (e, t) => (a.ranged ? 4 : 0) + t)
		], c = t.modifiers.singleLane ? [4, 0].find((t) => !wt(e, t)) : s.find((t) => !wt(e, t));
		if (c === void 0) {
			e.actors.pop();
			continue;
		}
		t.queue.shift(), a.lane = r, a.pos = c;
		let l = Te(a)?.extra ?? 0;
		for (let n = 0; n < l; n++) {
			let n = q(e, 5);
			n && t.queue.unshift(n);
		}
		if (a.definition === "duster" && (a.initiative = 99), e.persistent["undead:" + i] && (a.hp = 2, a.attack *= 2), a.counters.armor = 0, t.modifiers.weakenFirst && r === 1 && (a.effects.attackMod = -t.modifiers.weakenFirst, t.modifiers.weakenFirst = 0), t.modifiers.spawnHpLoss && (a.hp = Math.max(1, a.hp - t.modifiers.spawnHpLoss)), a.point === 20 && t.modifiers.reinforced20 && (a.maxHp += 3, a.hp += 3), t.modifiers.trapStun && L(e) >= 2 && (a.effects.stunRounds = 2), t.modifiers.reverseSetup && t.round === 1 && (a.pos = 12 + r - 1), t.modifiers.spikeMoves && Z(e, a, 1, void 0, "true"), t.modifiers.reinforceLarge && a.hp >= 5) {
			let n = q(e, 5);
			n && t.queue.push(n);
		}
		t.round > 1 && (a.point === 20 ? t.order.unshift(a.id) : t.order.push(a.id));
	}
}
function Nt(e, t) {
	return e.battle?.modifiers.singleLane ? e.battle.modifiers.oneAtTime ? wt(e, 8) ? [] : [8] : [8, 12].filter((t) => !wt(e, t)) : e.battle?.modifiers.reverseSetup ? Array.from({ length: 4 }, (e, t) => 8 + t).filter((t) => !wt(e, t)) : Array.from({ length: 4 }, (e, n) => (t.ranged ? 12 : 8) + n).filter((t) => !wt(e, t));
}
function Pt(e) {
	let t = e.battle;
	if (t.order = B(e).sort((e, t) => t.initiative - e.initiative || e.lane - t.lane).map((e) => e.id), t.modifiers.surprise && t.order.sort((t, n) => Number(R(e, n)?.kind === "gearloc") - Number(R(e, t)?.kind === "gearloc")), t.modifiers.enemySurprise && t.order.sort((t, n) => Number(R(e, t)?.kind === "gearloc") - Number(R(e, n)?.kind === "gearloc")), t.modifiers.rangedTop && t.order.sort((t, n) => Number(!!R(e, n)?.ranged && R(e, n)?.kind === "baddie") - Number(!!R(e, t)?.ranged && R(e, t)?.kind === "baddie")), e.persistent.skinning) {
		let n = [
			"troll",
			"orc",
			"scales",
			"goblin",
			"bog",
			"beast"
		][e.persistent.skinning - 1], r = (t) => Number(Te(R(e, t))?.creature === n);
		t.order.sort((e, t) => r(e) - r(t)), e.persistent.skinning = 0;
	}
	let n = B(e).find((e) => e.definition === "trader");
	n && (t.order = t.order.filter((e) => e !== n.id), t.order.splice(t.order.indexOf(n.owner) + 1, 0, n.id)), t.flags.push("orderPending"), t.stage = "startRound";
}
function Ft(e) {
	let t = e.battle;
	if (!t) return !1;
	if (t.modifiers.nomVisit) {
		let n = B(e).find((e) => e.definition === "nom");
		n && (n.hp <= 5 || t.round > 3) && (n.pos = -1, n.hp = 0);
	}
	return t.modifiers.trader && !B(e).some((e) => e.definition === "trader") ? (It(e, !1), !0) : (t.flags.includes("tyrant") ? t.defeated.some((t) => R(e, t)?.definition === e.config.tyrant) : V(e).length === 0 && t.queue.length === 0 && !e.delayedBaddies.length && !(t.modifiers.golemAlly && t.round <= 3)) ? t.flags.includes("tyrant") ? (e.outcome = "win", e.phase = "done", U(e, "victory"), !0) : (t.modifiers.rats && Ge(e, "s4"), It(e, !0), !0) : !we(e).length && !z(e).some((e) => e.hp > 0 && e.counters.reserve > 0) && !t.later.length && t.stage !== "deployment" && !t.reactions.includes("nomNext") && (It(e, !1), !0);
}
function It(e, t) {
	let n = e.battle;
	if (t && n.modifiers.ambushFirst) {
		jt(e, { points: Math.max(0, e.day * e.players.length - 8) });
		return;
	}
	let r = [
		...B(e).filter((e) => e.point > 0).map((e) => e.definition + "#" + e.counters.chip),
		...n.queue.filter((e) => e.includes("#")),
		...e.delayedBaddies.map((e) => e.chip)
	];
	for (let t of new Set(r)) {
		let n = e.stacks[A(t.split("#")[0]).point] ??= [];
		n.includes(t) || n.push(t);
	}
	if (e.delayedBaddies = [], !t && n.modifiers.retryEncounter && e.encounterDeck.unshift(e.encounter), (n.modifiers.reshuffleAlways || !t && n.modifiers.reshuffleFailure) && (e.encounterDeck = Se(e, [...e.encounterDeck, e.encounter])), t && n.modifiers.huntDragon && Ge(e, "s5"), t && n.modifiers.fullRecovery && (e.persistent["today:fullRecovery"] = 1), t && n.modifiers.trader && B(e).some((e) => e.definition === "trader") && (e.encounterDeck = e.encounterDeck.filter((e) => e !== "s6")), t && n.modifiers.removeCreature) {
		let t = [
			"troll",
			"orc",
			"scales",
			"goblin",
			"bog",
			"beast"
		][n.modifiers.removeCreature - 1];
		for (let n of Object.keys(e.stacks)) e.stacks[n] = e.stacks[n].filter((e) => A(e.split("#")[0]).creature !== t);
		e.defeatedStack = e.defeatedStack.filter((e) => A(e.split("#")[0]).creature !== t), e.persistent["removed:" + t] = 1;
	}
	e.lastBattle = e.battle?.defeated ?? [];
	for (let n of z(e)) {
		for (let e of [
			"hp",
			"dex",
			"attack",
			"defense"
		]) {
			let t = n.effects["limited:" + e] ?? 0;
			e === "hp" ? n.maxHp += t : n[e] += t;
		}
		for (let r of [
			...n.active,
			...n.bones,
			...t ? [] : n.locked
		]) W(e, n, r);
		n.exhausted = [], n.effects = {}, n.pos = -1, n.counters.reserve = 0, n.counters.brokenAttack = 0, n.counters.brokenDefense = 0;
	}
	e.actors = z(e), e.battle = null, J(e, t);
}
function Lt(e, t) {
	return t.effects.daze || t.effects.stuck || e.battle?.modifiers.singleLane || t.kind === "baddie" && (e.battle?.modifiers.enemyNoMove ?? 0) >= (e.battle?.round ?? 0) ? [] : Et(t.pos, t.diagonal || (e.battle?.round ?? 0) >= 6).filter((t) => !wt(e, t));
}
function Rt(e, t, n, r, i = r) {
	if (Y(t, n.pos, i)) return 0;
	let a = /* @__PURE__ */ new Set([t]), o = [t];
	for (let t = 1; o.length; t++) {
		let s = [];
		for (let c of o) for (let o of Et(c, r)) if (!(a.has(o) || wt(e, o))) {
			if (Y(o, n.pos, i)) return t;
			a.add(o), s.push(o);
		}
		o = s;
	}
	return 100;
}
function zt(e, t) {
	let n = e.battle, r = (t.kind === "ally" ? V(e) : we(e)).filter((r) => Dt(e, t, r, !n.flags.includes("movementComplete") || t.ranged)), i = r.filter((e) => (e.effects.taunt || H(e, "constantTaunt")) && Y(t.pos, e.pos, t.diagonal));
	if (i.length) return n.enemyTargets.length ? [] : i;
	let a = r.filter((e) => !n.enemyTargets.includes(e.id));
	if (!a.length) return [];
	if (t.ranged || t.kind === "ally") {
		let e = (t.target === "strongest" ? Math.max : Math.min)(...a.map((e) => e.hp));
		return a.filter((t) => t.hp === e);
	}
	let o = a.map((n) => Rt(e, t.pos, n, t.diagonal || e.battle.round >= 6, t.diagonal)), s = Math.min(...o);
	if (s === 100) return [];
	let c = a.filter((e, t) => o[t] === s), l = (t.target === "strongest" ? Math.max : Math.min)(...c.map((e) => e.hp));
	return c.filter((e) => e.hp === l);
}
function Bt(e, t, n) {
	if (t.ranged || Y(t.pos, n.pos, t.diagonal) || t.effects.daze) return [];
	let r = Lt(e, t), i = r.map((r) => Rt(e, r, n, t.diagonal || e.battle.round >= 6, t.diagonal)), a = Math.min(...i);
	return r.filter((e, t) => i[t] === a);
}
function Vt(e, t) {
	let n = [];
	t.effects.poison && n.push("poison"), t.effects.bleed && n.push("bleed"), t.gearloc === "patches" && n.push("innateHeal"), (X(t, "recover") || H(t, "recover") || H(t, "constantRegen")) && n.push("recover"), H(t, "booster") && t.active.some((e) => e.kind === "buffHp") && n.push("booster"), t.effects.napalm && n.push("napalm"), X(t, "retreat") && t.hp <= 3 && n.push("retreat"), X(t, "signal") && (t.counters.signals ?? 0) < X(t, "signal") && n.push("signal"), X(t, "dive") && t.effects.flight && we(e).some((n) => !n.effects.untargetable && Et(n.pos, t.diagonal).some((t) => !wt(e, t))) && n.push("dive");
	for (let e of t.active) [
		"cleanse",
		"hardy",
		"ale"
	].includes(e.kind) && n.push(e.uid);
	return n;
}
function Ht(e, t, n, r, i) {
	let a = e.battle;
	if (!a.startEffects.includes(n)) return !1;
	if (n === "poison") Z(e, t, t.effects.poison, void 0, "true"), t.effects.poison = Math.max(0, t.effects.poison - 1);
	else if (n === "bleed") Z(e, t, 1, void 0, "true");
	else if (n === "innateHeal") {
		if (t.upgraded && (!r || r.kind !== "gearloc")) return !1;
		ze(e, t.upgraded ? r : t, 1, t.id);
	} else if (n === "recover") ze(e, t, X(t, "recover") + H(t, "recover") + H(t, "constantRegen"));
	else if (n === "booster") {
		let e = H(t, "booster");
		for (let n of t.active.filter((e) => e.kind === "buffHp")) {
			let t = Math.min(e, n.extra - n.n);
			n.n += t, e -= t;
		}
	} else if (n === "napalm") Z(e, t, t.effects.napalm, R(e, e.players[(t.counters.napalmSource ?? 0) - 1] ?? "")), t.effects.napalmRounds--, t.effects.napalmRounds <= 0 && (t.effects.napalm = 0);
	else if (n === "retreat") t.pos = -1, t.hp = 0, a.queue.unshift(t.definition + "#" + t.counters.chip);
	else if (n === "signal") {
		let n = q(e, t.point === 20 ? 5 : 1);
		n && a.queue.push(n), t.counters.signals = (t.counters.signals ?? 0) + 1;
	} else if (n === "dive") {
		let o = we(e).filter((e) => !e.effects.untargetable), s = Math.min(...o.map((e) => e.hp));
		if (!o.some((n) => n.hp === s && Et(n.pos, t.diagonal).some((t) => !wt(e, t)))) return a.startEffects = a.startEffects.filter((e) => e !== n), !0;
		if (!r || r.hp !== s || !o.includes(r) || i === void 0 || wt(e, i) || !Y(i, r.pos, t.diagonal)) return !1;
		t.pos = i, a.target = r.id;
	} else {
		let r = t.active.find((e) => e.uid === n);
		if (!r) return !1;
		r.n--, r.n <= 0 && (r.kind === "ale" && (t.effects.ale = 0, t.hp = 1), W(e, t, r));
	}
	return a.startEffects = a.startEffects.filter((e) => e !== n), !0;
}
function Ut(e) {
	let t = e.battle;
	t.at++, t.turn = null, t.stage = t.at >= t.order.length ? "endRound" : "startTurn", t.later.length && t.flags.includes("immediateEntry") && (t.flags = t.flags.filter((e) => e !== "immediateEntry"), t.flags.push("resume:" + t.stage), t.stage = "deployment");
}
function Wt(e, t) {
	if (e.battle.rolled.some((e) => !e.used && (e.face.includes("forcedBones") || e.face.includes("tainted") || t.gearloc === "boomer" && (e.skill === 16 || e.skill >= 5 && e.skill <= 11)))) return !1;
	for (; t.bones.reduce((e, t) => e + t.n, 0) > 5;) W(e, t, t.bones[t.bones.length - 1]);
	if (t.gearloc === "tantrum" && t.counters.rageStep === 5 && !t.upgraded) {
		t.counters.rageTier = 1, t.counters.rageStep = 0;
		let e = t.active.find((e) => e.kind === "rage");
		e && (e.n = 10);
	}
	return t.effects.weaken = 0, t.effects.daze = 0, t.effects.terrify = +(t.effects.terrify === 2), Ut(e), !0;
}
function Gt(e) {
	let t = e.battle;
	if (!t || e.phase !== "battle") return !1;
	if (Ft(e)) return !0;
	if (t.stage === "startRound") {
		if (t.flags.includes("orderPending")) return !1;
		if (t.hpLost = {}, t.at = 0, t.round === 1 && t.modifiers.startDamage && !t.flags.includes("startDamage")) {
			for (let n of z(e)) Z(e, n, t.modifiers.startDamage);
			t.flags.push("startDamage");
		}
		if (t.round >= 6) for (let t of [...B(e)]) Z(e, t, 1, void 0, "fatigue");
		if (t.modifiers.wallArrows) for (let t of [...V(e)]) Z(e, t, 1, void 0, "true");
		if (t.modifiers.partyRoundDamage) for (let t of z(e)) Z(e, t, 1, void 0, "true");
		if (t.modifiers.bogRound && L(e) < 3) for (let t of z(e)) Z(e, t, 1, void 0, "true");
		if (t.modifiers.roundSignal && t.round >= 2 && t.round <= 5) {
			let n = q(e, 1);
			n && t.queue.push(n);
		}
		if (t.modifiers.exhaustedForStun && L(e) < t.modifiers.exhaustedForStun) {
			let t = V(e).find((e) => e.point === 20);
			t && (t.effects.stun = 1);
		}
		for (let t of z(e)) t.effects.zelfey && ze(e, t, 1);
		return t.stage = "startTurn", U(e, "round", "", "", t.round), !0;
	}
	if (t.stage === "startTurn") {
		let n = R(e, t.order[t.at]);
		return !n || n.hp <= 0 || n.pos < 0 ? (Ut(e), !0) : (t.turn = n.id, t.target = null, t.rolled = [], t.spent = 0, t.rolledOnce = !1, t.backupUsed = !1, t.hpLost = {}, t.lastAttack = [], t.enemyTargets = [], t.enemyRolls = [], t.enemyBones = 0, t.tyrantFace = -1, t.flags = t.flags.filter((e) => e !== "targetResponses" && e !== "movementComplete" && !e.startsWith("armor:")), n.effects.untargetable = 0, n.effects.taunt = 0, n.effects.silverHide = 0, n.counters.axeUsed = 0, n.counters.freeMoveUsed = 0, n.counters.afterAttackMove = 0, n.counters.moveCheck = 0, n.counters.switchUsed = 0, n.counters.rushUsed = 0, n.effects.stuck = 0, n.effects.extraAttack = 0, n.effects.extraDex = 0, t.startEffects = Vt(e, n), t.stage = "move", !0);
	}
	let n = t.turn ? R(e, t.turn) : void 0;
	if (n?.kind === "gearloc" && (n.hp <= 0 || n.pos < 0) && t.stage === "resolve") return Ut(e), !0;
	if (t.stage === "move" && n) return t.startEffects.length ? !1 : n.hp <= 0 || n.pos < 0 || n.effects.stun || n.effects.stunRounds || n.kind === "object" ? (n.effects.stun = 0, n.effects.stunRounds && n.effects.stunRounds--, Ut(e), !0) : n.kind === "gearloc" || n.kind === "ally" ? !1 : (t.stage = "enemyTarget", !0);
	if (t.stage === "enemyTarget" && n) {
		let r = zt(e, n).filter((e) => !t.enemyTargets.includes(e.id));
		return r.length > 1 ? !1 : (r.length === 1 && t.enemyTargets.push(r[0].id), t.flags.includes("movementComplete") ? (t.enemyTargets.length >= n.targets || !r.length) && (t.stage = "enemySkills") : (t.target = t.enemyTargets[0] ?? null, t.stage = "enemyMove"), !0);
	}
	if (t.stage === "enemyMove" && n) {
		let r = R(e, t.target ?? ""), i = r && t.spent < 2 ? Bt(e, n, r) : [];
		return i.length > 1 ? !1 : i.length === 1 ? (n.pos = i[0], t.spent++, t.modifiers.spikeMoves && Z(e, n, 1, void 0, "true"), !0) : (t.enemyTargets = t.enemyTargets.filter((t) => {
			let r = R(e, t);
			return r && Dt(e, n, r);
		}), t.flags.push("movementComplete"), t.stage = t.enemyTargets.length >= n.targets ? "enemySkills" : "enemyTarget", !0);
	}
	if (t.stage === "enemySkills" && n) {
		if (!t.flags.includes("targetResponses")) return t.flags.push("targetResponses"), t.enemyTargets = t.enemyTargets.flatMap((r) => {
			let i = R(e, r), a = i.active.find((t) => t.kind === "intercept" && (R(e, t.owner)?.hp ?? 0) > 0 && (R(e, t.owner)?.pos ?? -1) >= 0), o = a ? R(e, a.owner) : i;
			a && (a.n--, a.n || W(e, i, a));
			let s = o.active.find((e) => e.kind === "smoke");
			return s ? (s.n--, s.n || W(e, o, s), []) : (o.active.some((e) => e.kind === "riposte") && Y(o.pos, n.pos) && t.reactions.push("riposte:" + o.id), [o.id]);
		}), !0;
		for (let r of t.enemyTargets) {
			let i = R(e, r);
			for (let t of [
				"poison",
				"weaken",
				"stun"
			]) X(n, t) && Be(e, i, t, X(n, t));
			X(n, "mischief") && (i.kind === "gearloc" ? i.active.length : i.enemyDefense.length) && (t.reactions.push("mischief:" + i.id), t.pendingDamage[i.id] = X(n, "mischief"));
		}
		return t.stage = "enemyRoll", !0;
	}
	if (t.stage === "enemyRoll" && n) {
		if (t.reactions.length) return !1;
		if (n.point === 0 && n.kind === "baddie" && t.tyrantFace < 0) return Jt(e, n), !0;
		let r = Math.max(0, n.attack + (n.ranged ? t.modifiers.rangedExtra ?? 0 : 0) + (n.hp < n.maxHp ? X(n, "rage") : 0) + (X(n, "raiding") ? V(e).filter((e) => e !== n && Te(e)?.creature === "orc").length : 0) + (X(n, "compound") ? Math.min(t.round, 5) - n.attack : 0) - (n.effects.weaken ?? 0) + (n.effects.attackMod ?? 0) + (n.effects.inspired ?? 0));
		t.enemyRolls = (t.enemyTargets.length === 1 && R(e, t.enemyTargets[0])?.effects.taunt ? Array(n.targets).fill(t.enemyTargets[0]) : t.enemyTargets).map((i) => {
			let a = Je(e, r), o = X(n, "frenzy");
			return o && a.filter(Boolean).length >= o && a.push(...Je(e, o)), t.enemyBones += a.filter((e) => !e).length, {
				target: i,
				dice: a
			};
		});
		let i = Je(e, Math.max(0, n.defense - n.enemyDefense.length), !0);
		return n.enemyDefense.push(...i.filter(Boolean)), t.enemyBones += i.filter((e) => !e).length, t.stage = "enemyDamage", U(e, "enemyRoll", n.id, "", r, t.enemyRolls.flatMap((e) => e.dice)), !0;
	}
	if (t.stage === "enemyDamage" && n) {
		let r = t.enemyRolls.shift();
		if (!r) return t.stage = "enemyBackup", !0;
		let i = R(e, r.target);
		if (i && i.hp > 0) {
			let a = r.dice.reduce((e, t) => e + t, 0);
			if (Z(e, i, a, n, n.effects.skullAxe ? "true" : "normal") && n.effects.dagger && Be(e, i, "bleed", 1), X(n, "engulf")) for (let t of [...B(e)].filter((e) => e !== i && Y(e.pos, i.pos))) Z(e, t, a, n);
			if (X(n, "boom")) for (let t of [...B(e)].filter((e) => e !== i && e !== n && Y(e.pos, i.pos))) Z(e, t, Math.floor(a / 2), n);
			i.hp > 0 && Ee(i, "v20") && !Y(i.pos, n.pos) && t.reactions.push("sling:" + i.id + "|" + n.id);
		}
		return !0;
	}
	if (t.stage === "enemyBackup" && n) {
		let r = Te(n);
		if (r && !n.effects.disable && t.enemyBones >= r.backupCost) for (let [i, a] of Object.entries(r.backup)) if (i === "careless") Z(e, n, a, n, "true");
		else if (i === "recover") ze(e, n, a);
		else if (i === "taunt") Be(e, n, "taunt", 1);
		else if (i === "callOrc") {
			let n = q(e, t.enemyBones >= 2 ? 5 : 1, "orc");
			n && t.queue.unshift(n);
		} else if (i === "hide") t.enemyBones >= a && Be(e, n, "untargetable", 1);
		else if (i === "limit") {
			let n = t.enemyTargets.map((t) => R(e, t)).filter((e) => e?.kind === "gearloc" && e.hp > 0 && [
				"hp",
				"dex",
				"attack",
				"defense"
			].some((t) => e.counters[t + "Training"] > 0 && !e.effects["limited:" + t]));
			n.length === 1 ? t.reactions.push("limit:" + n[0].id) : n.length > 1 && t.reactions.push("limitTarget");
		} else for (let r of t.enemyTargets) {
			let o = R(e, r);
			if (i === "corrosive") for (let t of [...o.active].filter((e) => e.kind === "defense")) W(e, o, t);
			else i === "mischief" && (o.kind === "gearloc" ? o.active.length : o.enemyDefense.length) ? (t.reactions.push("mischief:" + o.id), t.pendingDamage[o.id] = a) : i === "inspire" ? Kt(e, n, a) : Be(e, o, i, a);
		}
		return t.stage = "enemyTyrant", !0;
	}
	if (t.stage === "enemyTyrant" && n) {
		if (t.reactions.length) return !1;
		if (n.point === 0 && n.kind === "baddie" && !t.flags.includes("tyrantAfter")) return Yt(e, n), t.flags.push("tyrantAfter"), !0;
		t.flags = t.flags.filter((e) => e !== "tyrantAfter"), X(n, "flight") && (n.effects.flight = +!n.effects.flight), X(n, "inspire") && Kt(e, n, X(n, "inspire"));
		for (let r of t.enemyTargets) {
			let t = R(e, r);
			if (t && X(n, "corrosive")) for (let n of [...t.active].filter((e) => e.kind === "defense")) W(e, t, n);
		}
		return n.effects.weaken = 0, n.effects.inspired = 0, n.effects.daze = 0, Ut(e), !0;
	}
	if (t.stage === "endRound") {
		if (!t.flags.includes("roundEndResponses")) {
			t.flags.push("roundEndResponses");
			for (let n of z(e).filter((e) => e.hp > 0 && e.inventory.some((e) => e.card === "l16"))) t.reactions.push("roundOptics:" + n.id);
			if (t.reactions.length) return !0;
		}
		if (t.modifiers.rats) {
			let t = V(e).length;
			return t || Ge(e, "s4"), It(e, t <= 1), !0;
		}
		if (t.modifiers.whirlwind && t.round >= 5) return It(e, !V(e).length), !0;
		if (t.modifiers.enemyEndFire) for (let n of [...V(e)]) Z(e, n, t.modifiers.enemyEndFire, void 0, "true");
		for (let t of B(e).filter((e) => e.definition === "orbPillar")) for (let n of [...we(e)].filter((e) => !Y(e.pos, t.pos))) Z(e, n, 1, t);
		if (t.modifiers.golemAlly && t.round === 3) for (let t of B(e).filter((e) => e.kind === "ally" && e.definition === "goldengolem")) t.kind = "baddie", t.owner = "", t.lane = 1;
		if (t.modifiers.lateSignal && t.round >= 3 && t.round <= 5 && L(e) < 3) {
			let n = q(e, 1);
			n && t.queue.push(n);
		}
		for (let n of z(e)) n.counters.reserve > 0 && n.counters.reserve < 98 && t.round >= n.counters.reserve && (n.counters.reserve = 0, t.later.push(n.id));
		for (let n of B(e)) if (n.counters.dropInitiative) {
			let e = t.order.indexOf(n.id);
			t.order.splice(e, 1), t.order.splice(Math.min(e + n.counters.dropInitiative, t.order.length), 0, n.id), n.counters.dropInitiative = 0;
		}
		t.flags.includes("partyInspire") && (t.order = [...t.order.filter((t) => R(e, t)?.kind === "gearloc"), ...t.order.filter((t) => R(e, t)?.kind !== "gearloc")], t.flags = t.flags.filter((e) => e !== "partyInspire")), Mt(e);
		for (let n of t.later) if (!(R(e, n).pos >= 0)) return t.flags.push("deployAtRoundEnd"), t.stage = "deployment", !0;
		return t.round++, t.stage = "startRound", t.at = 0, t.flags = t.flags.filter((e) => e !== "roundEndResponses"), !0;
	}
	return !1;
}
function Kt(e, t, n) {
	let r = e.battle, i = r.order.slice(r.at + 1).find((t) => {
		let n = R(e, t);
		return n && n.kind === "baddie" && n.hp > 0;
	});
	i && (r.order = r.order.filter((e) => e !== i), r.order.splice(r.at + 1, 0, i), R(e, i).effects.inspired = n, U(e, "inspire", t.id, i, n));
}
function qt(e) {
	let t = e.battle;
	return t.tyrantFace = L(e), re[e.config.tyrant].faces[t.tyrantFace];
}
function Jt(e, t) {
	let n = e.battle, r = qt(e);
	if (t.effects.skullAxe = +(r === "skullAxe"), t.effects.dagger = +(r === "dagger"), r === "omnom") for (let t of n.enemyTargets) {
		let n = R(e, t);
		for (let t of [...n.active, ...n.locked].filter((e) => [
			"defense",
			"advancedDefense",
			"constantDefense"
		].includes(e.kind))) W(e, n, t);
		n.counters.armor = 0;
	}
	if (r === "bloodRage" && (t.effects = { skullAxe: 0 }), r === "cloak") {
		let r = [...n.order.slice(n.at + 1), ...n.order.slice(0, n.at)].map((t) => R(e, t)).find((e) => e?.kind === "gearloc" && e.hp > 0 && e.pos >= 0);
		r && we(e).filter((e) => e.kind === "gearloc").length >= 2 && (t.pos = r.pos, r.pos = -1, r.counters.cloaked = 1, n.order = n.order.filter((e) => e !== r.id));
	}
	if (t.definition === "goblinking") for (let t of we(e)) n.reactions.push("knockback:" + t.id);
	U(e, "tyrantDie", t.id, r, n.tyrantFace);
}
function Yt(e, t) {
	let n = e.battle, r = re[e.config.tyrant].faces[n.tyrantFace];
	if (r === "thunderclub") for (let t of n.enemyTargets) R(e, t)?.hp && n.reactions.push("club:" + t);
	if (r.startsWith("orb:")) {
		let t = Number(r.split(":")[1]), n = [
			0,
			4,
			8,
			12
		].map((e) => e + t - 1).find((t) => !wt(e, t));
		n !== void 0 && Me(e, "orb", e.completed.includes("t3") ? 3 : 4, n);
	}
	if (r === "charred") {
		let t = V(e).filter((e) => e.definition.startsWith("kobold")), r = t.length ? Math.min(...t.map((e) => e.hp)) : 0;
		n.reactions.push(...t.length ? ["charred"] : []), n.pendingDamage.charredHp = r;
	}
	if (r === "silverHide" && (t.effects.silverHide = 1), r === "howl") {
		let r = n.order.filter((n) => {
			let r = R(e, n);
			return r?.kind === "baddie" && r !== t && r.hp > 0;
		});
		for (let e of r) {
			let r = n.order.indexOf(e);
			r > n.order.indexOf(t.id) + 1 && r > 0 && ([n.order[r], n.order[r - 1]] = [n.order[r - 1], n.order[r]]);
		}
	}
	if (r === "enhance" && !e.persistent.antidote) for (let t of n.enemyTargets) {
		let n = R(e, t);
		n?.effects.poison && Be(e, n, "poison", 3);
	}
	if (r === "poison") for (let t of n.enemyTargets) {
		let n = R(e, t);
		n && Be(e, n, "poison", 2);
	}
	if (r === "bloodRage" && (n.reactions.push("marrowRetreat"), n.pendingDamage.marrowSteps = 2), r === "callHelp") {
		let t = q(e, e.players.length <= 2 ? 1 : 5);
		t && n.queue.push(t);
	}
	if (r === "carelessBomb") {
		let t = V(e).filter((e) => e.kind === "baddie"), r = Math.max(...t.map((e) => e.hp));
		n.pendingDamage.bombHp = r, n.reactions.push("carelessBomb");
	}
}
function Xt(e, t) {
	let n = Array.from({ length: 16 }, (e, t) => t).filter((t) => !wt(e, t)), r = (e) => Math.abs(Ct(e) - Ct(t)) + Math.abs(St(e) - St(t)), i = Math.max(...n.map(r));
	return n.filter((e) => r(e) === i);
}
function Zt(e, t, n) {
	let r = e.battle, i = r.reactions[0];
	if (!i) return !1;
	let a = B(e).find((t) => t.definition === e.config.tyrant), o = R(e, n.target ?? "");
	if (i.startsWith("shield:")) {
		let r = R(e, i.slice(7)), a = "shield:" + n.amount;
		if (t !== r.owner || ![
			"active",
			"locked",
			"discard"
		].includes(n.mode ?? "") || !r.counters[a] || n.mode !== "discard" && !Ne(e, r, "defense", r.counters[a], 0, r.id, n.mode === "locked")) return !1;
		if (delete r.counters[a], Object.keys(r.counters).some((e) => e.startsWith("shield:"))) return !0;
	} else if (i.startsWith("sling:")) {
		let [r, a] = i.slice(6).split("|"), o = R(e, r), s = R(e, a);
		if (t !== o.owner || n.mode !== "use") return !1;
		s && s.hp > 0 && o.hp > 0 && Z(e, s, Je(e, 1)[0], o);
	} else if (i.startsWith("prevent:")) {
		let [a, o] = i.slice(8).split("|"), s = R(e, a);
		if (t !== s.owner || !["use", "pass"].includes(n.mode ?? "")) return !1;
		let c = s.inventory.find((e) => e.card === "l19");
		n.mode === "use" && c ? (Ue(e, s, c), U(e, "lootUsed", s.id, c.card)) : (s.effects[o] = r.pendingDamage[i], U(e, "effect", s.id, o, s.effects[o])), delete r.pendingDamage[i];
	} else if (i.startsWith("retaliate:")) {
		let [r, a] = i.slice(10).split("|"), o = R(e, r), s = R(e, a);
		if (t !== o.owner || ![
			"poison",
			"lashback",
			"both",
			"pass"
		].includes(n.mode ?? "")) return !1;
		s && s.hp > 0 && o.hp > 0 && ((n.mode === "poison" || n.mode === "both") && Be(e, s, "poison", H(o, "poisonArmor")), (n.mode === "lashback" || n.mode === "both") && Z(e, s, H(o, "lashback"), o));
	} else if (i.startsWith("roundOptics:")) {
		let r = R(e, i.slice(12)), a = r.inventory.find((e) => e.card === "l16");
		if (t !== r.owner || !["use", "pass"].includes(n.mode ?? "")) return !1;
		n.mode === "use" && a && (r.counters.dropInitiative = (r.counters.dropInitiative ?? 0) - 3, a.uses--, a.uses || Ue(e, r, a), U(e, "lootUsed", r.id, a.card));
	} else if (i.startsWith("riposte:")) {
		let a = R(e, i.slice(8));
		if (t !== a.owner || ![
			"use",
			"double",
			"pass"
		].includes(n.mode ?? "")) return !1;
		if (n.mode !== "pass") {
			let t = a.active.filter((e) => e.kind === "riposte"), i = R(e, r.turn ?? "");
			if (!t.length || n.mode === "double" && t.length < 2) return !1;
			W(e, a, t[0]), r.enemyTargets = r.enemyTargets.filter((e) => e !== a.id), n.mode === "double" && (W(e, a, t[1]), i && Z(e, i, 3, a));
		}
	} else if (i === "nomNext" || i === "lineupNext") {
		if (t !== e.leader || !o || o.kind !== "gearloc" || o.hp <= 0 || o.pos >= 0 || o.counters.reserve !== (i === "nomNext" ? 99 : 98)) return !1;
		o.counters.reserve = 0, r.stage !== "deployment" && (r.later.push(o.id), r.flags.push("resume:" + r.stage), r.stage = "deployment");
	} else if (i.startsWith("knockback:") || i.startsWith("club:")) {
		let o = R(e, i.slice(i.indexOf(":") + 1));
		if (!o || o.hp <= 0) return r.reactions.shift(), !0;
		if (t !== o.owner && t !== e.leader || n.pos === void 0 || !Xt(e, o.pos).includes(n.pos)) return !1;
		o.pos = n.pos, i.startsWith("club:") && Z(e, o, 1, a, "true");
	} else if (i === "charred") {
		if (t !== e.leader || !o || !o.definition.startsWith("kobold") || o.hp !== r.pendingDamage.charredHp) return !1;
		if (Z(e, o, 1, a), o.hp > 0) {
			let t = we(e), r = t.map((e) => Math.abs(Ct(e.pos) - Ct(o.pos)) + Math.abs(St(e.pos) - St(o.pos))), i = Math.min(...r), a = t.find((e) => e.id === n.mode);
			if (!a || r[t.indexOf(a)] !== i || n.pos === void 0 || wt(e, n.pos) || !Y(n.pos, a.pos)) return !1;
			o.pos = n.pos, Z(e, a, 2, o);
		}
	} else if (i === "carelessBomb") {
		if (t !== e.leader || !o || o.kind !== "baddie" || o.hp !== r.pendingDamage.bombHp) return !1;
		B(e).filter((e) => e === o || Y(e.pos, o.pos)).forEach((t) => Z(e, t, 3, a));
	} else if (i === "marrowRetreat") {
		if (t !== e.leader || !a) return !1;
		let i = Lt(e, a), o = (e) => Math.abs(Ct(e) - 2) + St(e), s = Math.min(...i.map(o));
		if (r.pendingDamage.marrowSteps > 0 && i.length && s < o(a.pos)) {
			if (n.pos === void 0 || !i.includes(n.pos) || o(n.pos) !== s) return !1;
			if (a.pos = n.pos, r.pendingDamage.marrowSteps--, r.pendingDamage.marrowSteps > 0 && a.pos !== 2) return !0;
		}
		ze(e, a, 3);
	} else if (i === "limitTarget") {
		if (t !== e.leader || !o || !r.enemyTargets.includes(o.id) || o.hp <= 0 || ![
			"hp",
			"dex",
			"attack",
			"defense"
		].some((e) => o.counters[e + "Training"] > 0 && !o.effects["limited:" + e])) return !1;
		r.reactions.splice(1, 0, "limit:" + o.id);
	} else if (i.startsWith("limit:")) {
		let r = R(e, i.slice(6));
		if (!r || t !== r.owner || ![
			"hp",
			"attack",
			"defense",
			"dex"
		].includes(n.mode ?? "")) return !1;
		let a = n.mode, o = r.counters[a + "Training"] ?? 0;
		if (!o || r.effects["limited:" + a]) return !1;
		if (r.effects["limited:" + a] = o, a === "hp") r.maxHp -= o, r.hp = Math.min(r.hp, r.maxHp);
		else if (a === "dex") r.dex -= o;
		else if (a === "attack") r.attack -= o;
		else {
			r.defense -= o;
			let t = r.active.filter((e) => e.kind === "defense");
			for (let n of t.slice(r.defense)) W(e, r, n);
		}
	} else return !1;
	return r.reactions.shift(), !0;
}
//#endregion
//#region src/game/adventure.ts
function Qt(e) {
	return {
		l2: 5,
		l5: e.uses,
		l8: 3,
		l10: e.uses,
		l28: 2
	}[e.card] ?? 0;
}
function $t(e, t, n = e.leader, r = [], i = []) {
	e.phase = "challenge", e.challenge = {
		...ye(),
		kind: "decision",
		by: n,
		values: r,
		ids: [t, ...i]
	};
}
function en(e, t = 0, n = {}, r = [], i) {
	let a = Math.max(0, e.day * e.players.length + t - (e.persistent.flare ?? 0)), o = r.filter((e) => !!e), s = We(e, a, i, !1, !!n.removeCreature), c = n.additionsBottom ? [...s, ...o] : [...o, ...s];
	if (e.persistent.flare = 0, e.persistent.goblinPursuit) {
		let t = [...e.defeatedStack].reverse().find((e) => e.startsWith("goblin"));
		t && (e.defeatedStack = e.defeatedStack.filter((e) => e !== t), c.push(t));
	}
	jt(e, {
		queue: c,
		modifiers: n
	});
}
function tn(e) {
	if (e.encounterDeck.length || (e.encounterDeck = Se(e, e.unusedEncounters.splice(0))), e.encounter = e.encounterDeck.shift() ?? null, e.choice = null, !e.encounter) {
		e.phase = "recovery";
		return;
	}
	e.phase = "encounter", e.challenge = ye(), U(e, "encounter", "", e.encounter);
}
function nn(e) {
	e.day++;
	for (let t of Object.keys(e.persistent).filter((e) => e.startsWith("today:"))) delete e.persistent[t];
	for (let t of z(e)) {
		t.ready = !1, t.recovery = [], t.lockAttempted = !1;
		for (let n of [...t.inventory].filter((e) => e.card === "l5")) n.uses--, n.uses <= 0 && Ue(e, t, n);
	}
	if (e.day > re[e.config.tyrant].days) {
		e.phase = "done", e.outcome = "lose", U(e, "defeatAdventure");
		return;
	}
	e.encounter = null, e.choice = null, e.phase = "day";
}
function rn(e, t, n) {
	t.hp = Math.max(0, t.hp - n), U(e, "damage", "", t.id, n);
}
function an(e, t) {
	z(e).forEach((n) => rn(e, n, t));
}
function on(e, t, n, r = {}, i, a) {
	jt(e, {
		queue: Array.from({ length: t }, () => q(e, n, i, a)).filter((e) => !!e),
		modifiers: r
	});
}
function sn(e, t, n) {
	if (e.phase !== "encounter" || t !== e.leader || !e.encounter || e.choice !== null) return !1;
	let r = ie(e.encounter), i = n.option, a = e.players.length, o = a <= 2;
	if (i >= r.choices || e.persistent["today:blocked:" + e.encounter + ":" + i]) return !1;
	let s = n.target ? R(e, n.target) : Ce(e, t);
	if (!s || s.kind !== "gearloc" || e.encounter === "g13" && i === 0 && z(e).reduce((e, t) => e + t.inventory.length, 0) < a || e.encounter === "o7" && i === 1 && !s.inventory.length || e.encounter === "o12" && i === 1 && s.skills.filter((e) => !ge(s.gearloc, e).counter).length < 3 || e.encounter === "t8" && i === 0 && z(e).flatMap((e) => e.inventory).reduce((e, t) => e + Qt(t), 0) < a * 2) return !1;
	e.choice = i;
	let c = (t = 0, n = {}, r = [], i) => en(e, t, n, r, i), l = () => J(e, !0), u = (e) => ({ noSkills: e });
	switch (e.encounter) {
		case "s1":
			if (i === 0) l();
			else {
				for (let t of z(e)) He(e, t, 2);
				$t(e, "startingLoot");
			}
			break;
		case "s2":
			c(0, i === 0 ? {
				wallArrows: 1,
				retryEncounter: 1
			} : { retryEncounter: 1 });
			break;
		case "s3":
			if (i === 0) {
				if (z(e).some(() => xe(e) <= 2)) {
					let t = e.encounterDeck.findIndex((e) => e.startsWith("t"));
					if (t >= 0) {
						let [n] = e.encounterDeck.splice(t, 1);
						e.encounterDeck = [n, ...Se(e, e.encounterDeck)];
					}
				}
			} else Ge(e, "s6");
			l();
			break;
		case "s4":
			i === 0 ? (e.encounterDeck = Se(e, [...e.encounterDeck, "s4"]), xe(e) <= 3 ? (an(e, 2), tn(e)) : $t(e, "discardThenRedraw", t, [1])) : c(0, { reinforced20: 3 }, [q(e, 20)]);
			break;
		case "s5":
			if (i === 0) {
				for (let t of z(e)) He(e, t, 1, !0);
				$t(e, "troveRedraw");
			} else e.persistent["today:trainingAuto"] = 1, l();
			break;
		case "s6":
			i === 0 ? (e.encounterDeck = Se(e, [...e.encounterDeck, "s6"]), dn(e)) : c(0, {
				startDamage: a,
				reshuffleFailure: 1
			});
			break;
		case "g1":
			if (i === 0) c(o ? 3 : 6, {}, [], "bog");
			else {
				c();
				for (let t of z(e)) t.hp <= xe(e) && (t.effects.poison = 2);
			}
			break;
		case "g2":
			i === 0 ? c(0, o ? {} : { huntDragon: 1 }, [q(e, o ? 5 : 20, "scales", o ? "dragondelinquent" : void 0)]) : c(0, { partyRoundDamage: 1 });
			break;
		case "g3":
			i === 0 ? c(0, { reinforceLarge: 1 }) : un(e, "g3", s, !0);
			break;
		case "g4":
			i === 0 ? un(e, "g4", s, !1, [
				3,
				4,
				5,
				2
			], [
				"L",
				"T",
				"F",
				"T"
			]) : c(0, { ignoreAttackTraining: 1 });
			break;
		case "g5":
			i === 0 ? l() : c(0, { surprise: 1 }, [q(e, o ? 1 : 5), q(e, o ? 1 : 5)]);
			break;
		case "g6":
			c(0, i === 0 ? {
				dexCap: 3,
				bogRound: 1
			} : {
				shieldWall: 1,
				rangedExtra: 1
			});
			break;
		case "g7":
			c(0, i === 0 ? { singleLane: 1 } : {
				dexPenalty: 1,
				stuck: 1
			});
			break;
		case "g8":
			c(i === 0 ? 0 : -2, {}, i === 0 ? Array.from({ length: o ? 1 : 2 }, () => q(e, 5)) : []);
			break;
		case "g9":
			i === 0 ? $t(e, "snipe", s.owner) : c(0, { roundSignal: 1 });
			break;
		case "g10":
			$t(e, "grab");
			break;
		case "g11":
			c(0, i === 0 ? { meleeFirst: 1 } : { meleeDefenseOnly: 2 });
			break;
		case "g12":
			c(i === 0 ? o ? 6 : 12 : 0, i === 0 ? {} : { surprise: 1 });
			break;
		case "g13":
			i === 0 ? $t(e, "bribe", t, [a]) : $t(e, "whirlwind");
			break;
		case "g14":
			i === 0 ? on(e, 2, 5, { ambushFirst: 1 }) : c(xe(e) + xe(e), { surprise: 1 });
			break;
		case "g15":
			c(0, i === 0 ? { spawnHpLoss: 2 } : { fullRecovery: 1 }, i === 0 ? [q(e, o ? 1 : 5), q(e, o ? 1 : 5)] : o ? [
				q(e, 1),
				q(e, 1),
				q(e, 5)
			] : [
				q(e, 5),
				q(e, 5),
				q(e, 5)
			]);
			break;
		case "g16":
			i === 0 ? un(e, "g16", s, !1, [4, 3], ["L", "T"]) : $t(e, "trapHp", t, [xe(e)]);
			break;
		case "g17":
			i === 0 ? $t(e, "duel") : c(o ? 4 : 8);
			break;
		case "g18":
			i === 2 ? $t(e, "scoutReturn", t, [2]) : c(i === 1 ? 6 : 0, { additionsBottom: 1 }, Array.from({ length: a }, () => q(e, i === 0 ? 5 : 1)));
			break;
		case "g19":
			c(0, i === 0 ? {
				noSkills: 99,
				doubleBones: 1
			} : { untilLaneOne: 1 });
			break;
		case "g20":
			c(0, i === 0 ? { noDefense: 1 } : { defenseOnly: 2 });
			break;
		case "g21":
			i === 0 ? $t(e, "exhaustStats") : c(0, { startDamage: 2 });
			break;
		case "g22":
			c(0, i === 0 ? { huntDragon: 1 } : {
				huntDragon: 1,
				enemyEndFire: 2
			}, [q(e, 20)]);
			break;
		case "g23":
			i === 0 ? fn(e, s.owner) : (Ge(e, "s6"), dn(e));
			break;
		case "g24":
			if (i === 0) {
				let t = e.troveDeck.find((e) => {
					let t = cn(e);
					return Math.max(...t) >= 5;
				});
				if (t ??= e.troveDeck[0], !t) return !1;
				e.troveDeck = e.troveDeck.filter((e) => e !== t), e.troveDeck.unshift(t), un(e, "g24", s, !0);
			} else dn(e);
			break;
		case "g25":
			pn(e);
			break;
		case "g26":
			i === 0 ? un(e, "g26", s, !0) : $t(e, "barrelCount");
			break;
		case "g27":
			mn(e);
			break;
		case "g28":
			hn(e);
			break;
		case "g29":
			gn(e);
			break;
		case "g30":
			$t(e, "gambleLoot");
			break;
		case "o1":
			if (i === 0) c(2, {
				singleLane: 1,
				oneAtTime: 1
			});
			else {
				let t = We(e, e.day);
				for (let n of t) A(n.split("#")[0]).ranged && rn(e, s, Je(e, 2).reduce((e, t) => e + t, 0));
				for (let n of t) e.stacks[A(n.split("#")[0]).point].push(n);
				J(e, s.hp > 0);
			}
			break;
		case "o2":
			c(2, i === 0 ? { rangedTop: 1 } : {
				surprise: 1,
				enemyNoMove: 1
			});
			break;
		case "o3":
			i === 0 ? on(e, 1, 5, {}, "bog", "stonegolem") : c(0, { golemAlly: 3 });
			break;
		case "o4":
			jt(e, {
				queue: [q(e, 1, "beast", "direwolfpup"), q(e, 5, "beast", "direwolf")].filter((e) => !!e),
				modifiers: i === 0 ? u(2) : { skillOnly: 2 }
			});
			break;
		case "o5":
			i === 0 ? un(e, "o5", s, !1, [3, 2], ["F", "L"]) : (rn(e, s, 3), e.persistent.noHealing = e.day, l());
			break;
		case "o6":
			on(e, 2, 5, i === 0 ? { trapStun: 2 } : {
				surprise: 1,
				spikeMoves: 1
			});
			break;
		case "o7":
			i === 0 ? c(0, { lateSignal: 1 }) : $t(e, "offering");
			break;
		case "o8":
			i === 0 ? (ln(e, s, 5), c(0, {}, [q(e, 5)])) : (s.inventory.push(Ve(e, "water")), l());
			break;
		case "o9":
			c(0, i === 0 ? { spawnHpLoss: 2 } : { trader: 1 }, [q(e, 5)]);
			break;
		case "o10":
			c(0, i === 0 ? {
				weakenFirst: 2,
				attackPlus: 1,
				noSkills: 2
			} : { noSkills: 1 });
			break;
		case "o11":
			i === 0 ? jt(e, {
				queue: We(e, e.day, void 0, !0),
				modifiers: { returnDead: 3 }
			}) : jt(e, {
				queue: [q(e, 5, void 0, void 0, !1), q(e, 5, void 0, void 0, !1)].filter((e) => !!e),
				modifiers: { freeAfterAttack: 3 }
			});
			break;
		case "o12":
			i === 0 ? (s.maxHp = Math.max(1, s.maxHp - 1), s.hp = Math.min(s.hp, s.maxHp), l()) : $t(e, "tripSkills", s.owner, [3]);
			break;
		case "t1":
			i === 0 ? c(0, { nomVisit: 1 }, [
				"nom",
				q(e, o ? 1 : 5),
				q(e, o ? 1 : 5)
			]) : (an(e, 2), e.persistent["today:skipRecovery"] = 1, e.encounterDeck = Se(e, [...e.encounterDeck, "t1"]), l());
			break;
		case "t3":
			c(0, { orbPillar: a * 3 });
			break;
		case "t4":
			c(0, i === 0 ? { noBackup: 1 } : { orbBones: 1 });
			break;
		case "t6":
			i === 0 ? c(0, {}, Array.from({ length: o ? 1 : 2 }, () => q(e, 5, "beast"))) : $t(e, "wolfHand");
			break;
		case "t7":
			c(0, {
				reverseSetup: 1,
				enemySurprise: 1
			}, [], "beast");
			break;
		case "t8":
			i === 0 ? $t(e, "healDuster", t, [a * 2]) : c();
			break;
		case "t10": {
			let t = q(e, o ? 1 : 5, "beast");
			if (t) {
				let n = e.persistent.mulmeshReserve ?? 0;
				e.persistent.mulmeshReserve = n + 1, e.persistent["reserve:" + t] = 1;
			}
			e.encounterDeck = Se(e, [...e.encounterDeck, "t10"]), tn(e);
			break;
		}
		case "t12":
			if (i === 0) $t(e, "bogIngredients");
			else {
				if (![
					["bogpole", "bogfrog"],
					["boglurk"],
					["stonegolem"],
					["claygolem"]
				].every((t) => e.defeatedStack.some((e) => t.includes(e.split("#")[0])))) return !1;
				e.persistent.antidote = 1, l();
			}
			break;
		case "t14":
			c(0, { returnOrcs: 3 }, [], "orc");
			break;
		case "t15":
			c(0, { removeCreature: i === 0 ? 5 : 3 }, [], i === 0 ? "bog" : "scales");
			break;
		case "t17":
			i === 0 ? c() : $t(e, "goblinBomb");
			break;
		case "t18":
			e.persistent.goblinPursuit = 1, c(0, {}, [q(e, o ? 1 : 5, "goblin")]);
			break;
		default: return !1;
	}
	return !0;
}
function cn(e) {
	return se(e).locks;
}
function ln(e, t, n) {
	t.counters.prepBuff = (t.counters.prepBuff ?? 0) + n, U(e, "buff", t.id, "", n);
}
function un(e, t, n, r, i, a) {
	e.phase = "challenge", e.challenge = {
		...ye(),
		kind: "lock",
		by: n.owner,
		ids: [t],
		values: [],
		data: { trove: +!!r }
	};
	let o = r ? He(e, n, 1, !0)[0] : void 0;
	o && e.challenge.ids.push(o.uid, n.id), Xe(e, n.owner, n.id, o?.uid ?? t, i, a);
}
function dn(e) {
	e.phase = "challenge", e.challenge = {
		...ye(),
		kind: "darts",
		by: e.players[0],
		ids: [...e.players],
		values: [
			10,
			10,
			0,
			0,
			0,
			0,
			0,
			0
		],
		data: { setup: 1 }
	};
}
function fn(e, t) {
	e.phase = "challenge", e.challenge = {
		...ye(),
		kind: "flick",
		by: t,
		values: [
			125,
			50,
			375,
			50,
			625,
			50,
			875,
			50
		],
		data: {}
	};
}
function pn(e) {
	jt(e, {
		queue: [],
		modifiers: { rats: e.players.length + 1 }
	});
	for (let t = 0; t <= e.players.length; t++) Me(e, "rat", xe(e), t < 4 ? 4 + t : t - 4);
}
function mn(e) {
	e.phase = "challenge", e.challenge = {
		...ye(),
		kind: "lanterns",
		by: e.players[0],
		values: z(e).map(() => xe(e)),
		ids: [...e.players]
	};
}
function hn(e) {
	e.phase = "challenge", e.challenge = {
		...ye(),
		kind: "critters",
		by: e.leader,
		values: Array(16).fill(1),
		ids: [...e.players],
		data: {
			deploy: 1,
			turn: 0,
			moved: 0
		}
	};
	for (let t of z(e)) t.pos = -1;
}
function gn(e) {
	e.phase = "challenge", e.challenge = {
		...ye(),
		kind: "rubble",
		by: e.leader,
		values: Array(16).fill(0),
		ids: [...e.players],
		data: {
			deploy: 1,
			rubblePlaced: 0
		}
	};
	for (let t of z(e)) t.pos = -1;
}
//#endregion
//#region src/game/darts.ts
function _n(e, t) {
	let n = t === 0 ? [
		e.data.attack,
		e.data.defense,
		e.data.poison
	] : [
		2,
		0,
		1
	];
	return [
		"attack",
		"defense",
		"status"
	].flatMap((e, t) => Array.from({ length: n[t] ?? 0 }, (t, n) => ({
		id: e + ":" + n,
		kind: e,
		index: n
	}))).filter((n) => n.kind === "attack" || !(e.data[n.kind + ":" + t + ":" + n.index] > 0));
}
function vn(e, t, n) {
	for (let r of Object.keys(e.data).filter((e) => e.startsWith("status:" + (1 - t) + ":"))) e.data[r] === n && (e.data[r] = 0);
	n === 1 ? e.values[4 + t] = 0 : e.data[(n === 2 ? "weaken:" : "stun:") + t] = 0;
}
function yn(e, t, n) {
	for (let r of Object.keys(e.data).filter((e) => e.startsWith("defense:" + t + ":"))) {
		let t = Math.min(n, e.data[r]);
		n -= t, e.data[r] -= t;
	}
	return e.values[2 + t] = Object.entries(e.data).filter(([e]) => e.startsWith("defense:" + t + ":")).reduce((e, [, t]) => e + t, 0), n;
}
function bn(e, t, n = []) {
	let r = e.challenge, i = +!t, a = 1 - i;
	if (r.values[i] -= r.values[4 + i], r.values[4 + i] = Math.max(0, r.values[4 + i] - 1), r.values[4 + i] || vn(r, i, 1), r.values[i] <= 0) return !0;
	if (r.data["stun:" + i]) return vn(r, i, 3), !0;
	let o = _n(r, i), s = Math.min(r.data["weaken:" + i] ?? 0, o.length), c = t ? n : o.slice(0, s).map((e) => e.id);
	if (new Set(c).size !== c.length || c.length !== s || c.some((e) => !o.some((t) => t.id === e))) return !1;
	vn(r, i, 2);
	let l = [], u = 0, d = 0;
	for (let t of o.filter((e) => !c.includes(e.id))) if (t.kind === "defense") {
		let n = Je(e, 1, !0)[0];
		r.data["defense:" + i + ":" + t.index] = n, l.push(n), n || u++;
	} else if (t.kind === "attack") {
		let t = Je(e, 1)[0];
		d += t, l.push(t), t || u++;
	} else {
		let n = L(e), o = n === 0 || n === 4 ? 2 : n === 3 ? 3 : 1;
		vn(r, a, o), r.data["status:" + i + ":" + t.index] = o, o === 1 ? r.values[4 + a] = n === 1 ? 1 : n === 2 ? 2 : 3 : r.data[(o === 2 ? "weaken:" : "stun:") + a] = o === 3 || n === 0 ? 1 : 2, l.push(n + 10);
	}
	return r.values[2 + i] = Object.entries(r.data).filter(([e]) => e.startsWith("defense:" + i + ":")).reduce((e, [, t]) => e + t, 0), r.values[a] -= yn(r, a, d), t && (r.data.bones = u), r.dice = l, U(e, "dartsRoll", t ? r.by : "opponent", "", d, l), !0;
}
//#endregion
//#region src/game/challenges.ts
function xn(e, t, n) {
	let r = e.challenge, i = r.ids[0], a = Ce(e, t), o = R(e, n.target ?? a?.id ?? "");
	if (r.kind !== "decision" || r.by !== t || !a) return !1;
	let s = e.players.length;
	switch (i) {
		case "pickEncounter": return r.ids.slice(1).includes(n.target ?? "") ? (e.encounterDeck.push(...r.ids.slice(1).filter((e) => e !== n.target)), e.encounter = n.target, e.choice = null, e.phase = "encounter", e.challenge = ye(), U(e, "encounter", "", e.encounter), !0) : !1;
		case "startingLoot": {
			let t = z(e)[r.step], i = t.inventory.find((e) => e.uid === n.target);
			if (!i) return !1;
			let a = t.inventory.slice(-2);
			return a.includes(i) ? (Ue(e, t, a.find((e) => e !== i)), r.step++, r.step === s && J(e, !0), !0) : !1;
		}
		case "troveRedraw": {
			let t = z(e)[r.step], i = t.inventory[t.inventory.length - 1];
			if (n.option === 1) Ue(e, t, i), He(e, t, 1, !0);
			else if (n.option !== 0) return !1;
			return r.step++, r.step === s && (r.ids = ["troveImmediate"], r.step = 0), !0;
		}
		case "troveImmediate": {
			let t = z(e)[r.step];
			if (n.option === 0) {
				let r = t.inventory.find((e) => e.uid === n.target && se(e.card).trove && e.locks < 3);
				if (!r) return !1;
				Xe(e, t.owner, t.id, r.uid);
			} else if (n.option !== 1) return !1;
			return r.step++, r.step === s && !e.lock && J(e, !0), !0;
		}
		case "discardThenRedraw":
		case "bribe": {
			let t = n.ids ?? [];
			if (t.length !== r.values[0] || new Set(t).size !== t.length) return !1;
			for (let n of t) {
				let t = z(e).find((e) => e.inventory.some((e) => e.uid === n));
				if (!t) return !1;
				Ue(e, t, t.inventory.find((e) => e.uid === n));
			}
			return i === "bribe" ? (Ge(e, "s6"), J(e, !0)) : tn(e), !0;
		}
		case "snipe": {
			let t = n.amount;
			if (t === void 0 || t > a.attack) return !1;
			let r = Je(e, t);
			return r.reduce((e, t) => e + t, 0) >= 2 ? (en(e, -2), a.counters.brokenAttack = t) : (e.choice = 1, en(e, 0, { roundSignal: 1 })), a.counters.brokenAttack = t, U(e, "challengeRoll", a.id, i, 0, r), !0;
		}
		case "grab": {
			let t = n.amount;
			if (!t || t > 6) return !1;
			let r = xe(e);
			return r > t && He(e, a, t), en(e, r > t ? 0 : t), U(e, "challengeRoll", a.id, i, r), !0;
		}
		case "whirlwind":
			if (!o || o.kind !== "gearloc") return !1;
			for (let t of z(e)) t !== o && (t.counters.reserve = 6);
			jt(e, {
				queue: [],
				modifiers: { whirlwind: 1 }
			});
			for (let [t, n] of [
				3,
				5,
				4,
				4
			].entries()) Me(e, "cloaked", n, 4 + t);
			return !0;
		case "trapHp": {
			let t = z(e).map((e) => Math.abs(e.hp - r.values[0])), n = Math.min(...t);
			return !o || o.kind !== "gearloc" || Math.abs(o.hp - r.values[0]) !== n ? !1 : (rn(e, o, 3), en(e), !0);
		}
		case "duel":
			if (!o || o.kind !== "gearloc") return !1;
			for (let t of z(e)) t.counters.reserve = t === o ? 0 : 3;
			return en(e, 0, { duel: 3 }), !0;
		case "scoutReturn": {
			let t = n.amount;
			if (!t || ![
				1,
				5,
				20
			].includes(t)) return !1;
			let r = e.stacks[t]?.slice(0, 2) ?? [];
			for (let i of r) n.ids?.includes(i) ? e.stacks[t] = [...e.stacks[t].filter((e) => e !== i), i] : e.scouted[t] = [...e.scouted[t] ?? [], i];
			return e.encounterDeck.unshift("g18"), J(e, !1), !0;
		}
		case "exhaustStats": {
			let t = n.amount ?? -1, r = n.option;
			if (t < 0 || t + r < 1 || t + r > 6 || z(e).some((e) => e.attack < t || e.defense < r)) return !1;
			en(e, 0, {
				exhaustedForStun: t + r,
				huntDragon: 1
			}, [q(e, 20)]);
			for (let n of z(e)) n.counters.brokenAttack = t, n.counters.brokenDefense = r;
			return !0;
		}
		case "barrelCount": {
			let t = n.amount;
			return !t || t > 4 ? !1 : (e.challenge = {
				...ye(),
				kind: "barrels",
				by: e.players[0],
				values: Array.from({ length: t }, () => xe(e)).sort((e, t) => t - e),
				ids: [...e.players]
			}, !0);
		}
		case "gambleLoot": {
			let t = n.ids ?? [];
			if (new Set(t).size !== t.length || t.length > (s === 1 ? 2 : 4)) return !1;
			for (let n of t) {
				let t = z(e).find((e) => e.inventory.some((e) => e.uid === n));
				if (!t) return !1;
				Ue(e, t, t.inventory.find((e) => e.uid === n));
			}
			let r = Array.from({ length: t.length * (s === 1 ? 2 : 1) }, () => xe(e)), o = r.reduce((e, t) => e + t, 0), c = o === 0 ? j(-1) : o <= 6 ? j(1, 1) : o <= 12 ? j(1, 2) : o <= 18 ? j(1, 2, 0, 0, 1) : j(1, 2, 0, 0, 2);
			return U(e, "challengeRoll", a.id, i, o, r), J(e, !0, c), !0;
		}
		case "offering": {
			let t = a.inventory.find((e) => e.uid === n.target);
			return t ? (Ue(e, a, t), xe(e) >= 4 ? J(e, !0) : (e.phase = "encounter", e.choice = null), !0) : !1;
		}
		case "tripSkills": {
			let t = (n.ids ?? []).map(Number);
			if (t.length !== 3 || new Set(t).size !== 3 || t.some((e) => !a.skills.includes(e) || ge(a.gearloc, e).counter)) return !1;
			for (let n of t) e.persistent["trip:" + a.id + ":" + n] = 1;
			return J(e, !0), !0;
		}
		case "wolfHand": return !o || o.kind !== "gearloc" ? !1 : (xe(e) <= 2 && (o.maxHp = Math.max(o.counters.baseHp, o.maxHp - 3), o.hp = Math.min(o.hp, o.maxHp)), J(e, !0), !0);
		case "healDuster": {
			let t = n.ids ?? [];
			if (new Set(t).size !== t.length) return !1;
			let i = 0;
			for (let n of t) {
				let t = z(e).find((e) => e.inventory.some((e) => e.uid === n)), r = t?.inventory.find((e) => e.uid === n);
				if (!t || !r) return !1;
				let a = Qt(r);
				if (!a) return !1;
				i += a, Ue(e, t, r);
			}
			return i < r.values[0] ? !1 : (J(e, !0), !0);
		}
		case "bogIngredients": return [0, 1].includes(n.option) ? (jt(e, {
			queue: Array.from({ length: n.option === 0 ? 6 : 3 }, () => q(e, n.option === 0 ? 1 : 5)).filter((e) => !!e),
			modifiers: { reshuffleAlways: 1 }
		}), !0) : !1;
		case "goblinBomb": return [
			"L",
			"T",
			"F"
		].includes(n.target ?? "") ? (r.kind = "lock", r.ids = ["t17"], r.data.bombType = "LTF".indexOf(n.target), Xe(e, t, a.id, "bomb", [3], [n.target]), !0) : !1;
		default: return !1;
	}
}
function Sn(e) {
	let t = e.challenge;
	if (t.kind !== "lock" || e.lock) return !1;
	let n = t.ids[0], r = !!e.persistent.lockSuccess, i = Ce(e, t.by), a = R(e, t.ids[2] ?? i.id) ?? i, o = a.inventory.find((e) => e.uid === t.ids[1]);
	if (n === "g4") {
		if (t.data.opened = (t.data.opened ?? 0) + e.persistent.lockOpened, t.data.opened >= e.players.length) return en(e, 0, { surprise: 1 }), !0;
		if (t.step++, t.step < e.players.length) {
			let n = Ce(e, e.players[t.step]);
			t.by = n.owner, Xe(e, n.owner, n.id, "shackle", [
				3,
				4,
				5,
				2
			], [
				"L",
				"T",
				"F",
				"T"
			]);
			let r = e.lock;
			r && (r.at = t.data.opened, r.startedAt = t.data.opened);
		} else z(e).forEach((t) => rn(e, t, 2)), e.choice = 1, en(e, 0, { ignoreAttackTraining: 1 });
		return !0;
	}
	if (n === "g24") return r ? J(e, !0) : (t.step++, t.step >= e.players.length ? J(e, !1) : (t.by = e.players[t.step], Xe(e, t.by, a.id, o.uid))), !0;
	if (n === "t17") return r || (t.data.failed = 1), t.step++, t.step < e.players.length ? (t.by = e.players[t.step], t.kind = "decision", t.ids = ["goblinBomb"]) : (t.data.failed || (e.persistent.goblinBomb = 1), en(e, 0, { startDamage: t.data.failed ? 2 : 0 })), !0;
	if (n === "g3") return !r && o && Ue(e, i, o), en(e), !0;
	if (n === "g16") return r ? en(e, 0, { enemySurprise: 1 }) : (e.choice = 1, $t(e, "trapHp", e.leader, [xe(e)])), !0;
	if (n === "g26") return !r && o && Ue(e, i, o), J(e, !0), !0;
	if (n === "o5") {
		if (r) {
			for (let t of [...i.inventory]) Ue(e, i, t);
			J(e, !0);
		} else rn(e, i, 2), e.persistent["today:blocked:o5:0"] = 1, e.phase = "encounter", e.choice = null;
		return !0;
	}
	return !1;
}
function Cn(e, t, n) {
	let r = e.challenge;
	if (r.kind !== "flick" || r.by !== t || r.data["shot:" + n.lane] || n.x < n.lane * 250 + 25 || n.x > n.lane * 250 + 225) return !1;
	let i = n.x, a = 940, o = n.vx, s = n.vy, c = Array.from({ length: 4 }, () => [0, 0]), l = /* @__PURE__ */ new Set(), u = [i, a];
	for (let e = 0; e < 600; e++) {
		let t = 1 / 120;
		i += o * t, a += s * t, o *= .99, s *= .99;
		for (let e = 0; e < 4; e++) {
			let n = r.values[2 * e], u = r.values[2 * e + 1], d = n - i, f = u - a, p = Math.hypot(d, f);
			if (p < 42 && p > .01 && o * d + s * f > 0) {
				let t = d / p, r = f / p, m = (o * t + s * r) * .75;
				c[e][0] += t * m, c[e][1] += r * m, o -= t * m, s -= r * m, l.add(e), i = n - t * 42, a = u - r * 42;
			}
			n += c[e][0] * t, u += c[e][1] * t, c[e][0] *= .97, c[e][1] *= .97, r.values[2 * e] = n, r.values[2 * e + 1] = u;
		}
		if (e % 8 == 0 && u.push(i, a), Math.hypot(o, s) < 5 && c.every(([e, t]) => Math.hypot(e, t) < 5)) break;
	}
	return r.dice = u, r.data["shot:" + n.lane] = 1, r.step++, l.has(n.lane) && (r.data["hit:" + n.lane] = 1), U(e, "flick", t, "", l.size), r.step === 4 && (r.data.complete = 1), !0;
}
function wn(e) {
	let t = e.challenge;
	if (t.values[1] <= 0 && t.values[0] > 0) t.wins.push(t.by), He(e, Ce(e, t.by), e.encounter === "s6" ? 2 : 1);
	else if (e.encounter === "s6" && Ce(e, t.by).inventory.length) {
		t.data.discard = 1;
		return;
	}
	t.step++, t.step >= e.players.length ? J(e, t.wins.length > 0 || e.encounter === "s6", e.encounter === "g23" || e.encounter === "g24" ? j(1) : j()) : (t.by = e.players[t.step], t.values = [
		10,
		10,
		0,
		0,
		0,
		0,
		0,
		0
	], t.data = { setup: 1 });
}
function Tn(e, t, n) {
	let r = e.challenge, i = Ce(e, t);
	if (r.by !== t || !i || e.lock) return !1;
	if (r.kind === "decision") return xn(e, t, n);
	if (r.kind === "flick" && r.data.complete) {
		let t = [
			0,
			1,
			2,
			3
		].filter((e) => r.data["hit:" + e] && r.values[e * 2] >= 21 && r.values[e * 2] <= 979 && r.values[e * 2 + 1] >= 21 && r.values[e * 2 + 1] <= 979).length;
		return J(e, t >= 3), !0;
	}
	if (r.kind === "darts") {
		if (r.data.discard) {
			let t = i.inventory.find((e) => e.uid === n.target);
			return t ? (Ue(e, i, t), r.data.discard = 0, r.step++, r.step >= e.players.length ? J(e, !0, j()) : (r.by = e.players[r.step], r.data = { setup: 1 }, r.values = [
				10,
				10,
				0,
				0,
				0,
				0,
				0,
				0
			]), !0) : !1;
		}
		if (r.data.setup) {
			let e = n.amount ?? -1, t = n.option, i = 3 - e - t;
			return ![
				e,
				t,
				i
			].some((e) => e < 0 || e > 2) && (r.data = {
				attack: e,
				defense: t,
				poison: i,
				enemyTurn: 1
			}, !0);
		}
		if (r.data.bones > 0) {
			let t = r.data.bones;
			if (n.option === 1 && t >= 1) {
				let [e, t, i] = (n.target ?? "poison:0").split(":"), a = Number(t);
				if (![0, 1].includes(a)) return !1;
				if (e === "defense") {
					let e = "defense:" + a + ":" + i;
					if (!r.data[e]) return !1;
					r.values[2 + a] -= r.data[e], r.data[e] = 0;
				} else {
					let t = [
						"poison",
						"weaken",
						"stun"
					].indexOf(e) + 1;
					if (!t) return !1;
					vn(r, a, t);
				}
			} else if (n.option === 2 && t >= 1) {
				let e = Object.keys(r.data).find((e) => e.startsWith("defense:1:") && r.data[e] > 0);
				e && (r.values[3] -= r.data[e], r.data[e] = 0);
			} else if (n.option === 3 && t >= 2) r.data["stun:1"] = 1;
			else if (n.option === 4 && t >= 3) r.values[1] = 0;
			else if (n.option !== 0) return !1;
			return r.data.bones = 0, r.values[0] <= 0 || r.values[1] <= 0 ? wn(e) : r.data.enemyTurn = 1, !0;
		}
		return r.data.enemyTurn || !bn(e, !0, n.ids) ? !1 : ((r.values[0] <= 0 || r.values[1] <= 0) && !r.data.bones ? wn(e) : r.data.bones || (r.data.enemyTurn = 1), !0);
	}
	if (r.kind === "barrels") {
		let t = Je(e, i.attack), n = t.reduce((e, t) => e + t, 0);
		return n >= r.values[0] && (r.values.shift(), r.data.destroyed = (r.data.destroyed ?? 0) + 1), r.step++, U(e, "challengeRoll", i.id, "barrels", n, t), r.step >= e.players.length || !r.values.length ? J(e, !0, {
			...ie(e.encounter).reward,
			loot: r.data.destroyed ?? 0
		}) : r.by = e.players[r.step], !0;
	}
	if (r.kind === "lanterns") {
		let t = n.option;
		if (t >= r.values.length || r.values[t] <= 0 || !i.gearloc) return !1;
		let a = ue[i.gearloc][L(e)];
		return a >= r.values[t] && (r.values[t] = 0, r.data.hits = (r.data.hits ?? 0) + 1), r.step++, U(e, "challengeRoll", i.id, "lanterns", a), r.step >= e.players.length ? J(e, !0, {
			...ie(e.encounter).reward,
			loot: r.data.hits ?? 0
		}) : r.by = e.players[r.step], !0;
	}
	if (r.kind === "critters") {
		if (r.data.deploy) return !1;
		if (r.data.critterSelect) {
			let t = r.values.flatMap((e, t) => e > 0 && t % 4 === r.data.lane ? [t] : []), i = Math.min(...r.values.filter((e) => e > 0)), a = t.length ? t : r.values.flatMap((e, t) => e === i ? [t] : []), o = n.option, s = Number(n.target);
			if (!a.includes(o)) return !1;
			let c = r.values.flatMap((e, t) => e > 0 && Y(o, t) ? [t] : []);
			if (t.length && c.length) {
				if (!c.includes(s)) return !1;
				r.values[s] += r.values[o];
			}
			return r.values[o] = 0, r.data.critterSelect = 0, r.values.some(Boolean) || J(e, !0), !0;
		}
		if (n.target === "pass") return r.data.enemyTurn = 1, r.data.moved = 0, r.step = (r.step + 1) % e.players.length, r.by = e.players[r.step], !0;
		let t = n.option;
		if (t > 15 || r.values[t] <= 0 || !i.ranged && !Y(i.pos, t) || (n.amount ?? 0) < 1 || n.amount > Math.min(i.attack, i.dex - r.data.moved)) return !1;
		let a = Je(e, n.amount), o = a.reduce((e, t) => e + t, 0);
		return o >= r.values[t] && (i.counters.prepBuff = (i.counters.prepBuff ?? 0) + r.values[t]), r.values[t] = 0, r.data.enemyTurn = 1, r.data.moved = 0, r.step = (r.step + 1) % e.players.length, r.by = e.players[r.step], U(e, "challengeRoll", i.id, "critters", o, a), r.values.some(Boolean) || J(e, !0), !0;
	}
	if (r.kind === "rubble") {
		if (r.data.deploy || r.data["throws:" + t] >= 2 || n.option >= 16) return !1;
		let a = n.option, o = Je(e, 2), s = o.reduce((e, t) => e + t, 0);
		for (let e = 0; e < 16; e++) {
			let t = e === a ? s : Y(e, a) ? Math.floor(s / 2) : 0;
			r.values[e] = Math.max(0, r.values[e] - t);
		}
		return r.data["throws:" + t] = (r.data["throws:" + t] ?? 0) + 1, U(e, "challengeRoll", i.id, "rubble", s, o), r.values.some(Boolean) ? e.players.every((e) => r.data["throws:" + e] >= 2) ? J(e, !1) : r.data["throws:" + t] >= 2 && (r.by = e.players.find((e) => !(r.data["throws:" + e] >= 2))) : J(e, !0), !0;
	}
	return !1;
}
function En(e, t, n) {
	let r = e.challenge, i = Ce(e, t);
	return !i || !["critters", "rubble"].includes(r.kind) || !r.data.deploy ? !1 : r.kind === "rubble" && (r.data.rubblePlaced ?? 0) < e.players.length * 2 ? t !== e.leader || n >= 8 || r.values[n] ? !1 : (r.values[n] = 3, r.data.rubblePlaced = (r.data.rubblePlaced ?? 0) + 1, !0) : i.pos >= 0 || n < (r.kind === "rubble" || i.ranged ? 12 : 8) || r.kind === "critters" && !i.ranged && n >= 12 || wt(e, n) ? !1 : (i.pos = n, r.values[n] = 0, z(e).every((e) => e.pos >= 0) && (r.data.deploy = 0, r.by = e.players[0], r.data.enemyTurn = +(r.kind === "critters")), !0);
}
function Dn(e, t, n) {
	let r = e.challenge, i = Ce(e, t);
	return r.kind !== "critters" || r.by !== t || r.data.deploy || r.data.enemyTurn || r.data.critterSelect || !i || r.data.moved >= i.dex || r.values[n] || wt(e, n) || !Y(i.pos, n) ? !1 : (i.pos = n, r.data.moved++, !0);
}
function On(e) {
	let t = e.challenge;
	if (t.kind === "lock") return Sn(e);
	if (t.kind === "decision" && t.ids[0] === "troveImmediate" && t.step >= e.players.length && !e.lock) return J(e, !0), !0;
	if (t.kind === "darts" && t.data.enemyTurn) return bn(e, !1), t.data.enemyTurn = 0, (t.values[0] <= 0 || t.values[1] <= 0) && wn(e), !0;
	if (t.kind === "critters" && t.data.enemyTurn) {
		let n = xe(e);
		return t.data.lane = (n - 1) % 4, t.dice = [n], t.data.enemyTurn = 0, t.data.critterSelect = 1, t.values.some(Boolean) || J(e, !0), !0;
	}
	return !1;
}
//#endregion
//#region src/game/schema.ts
var kn = t.enum([
	"boomer",
	"patches",
	"picket",
	"tantrum"
]), An = t.enum([
	"nom",
	"gendricks",
	"duster",
	"mulmesh",
	"drellen",
	"marrow",
	"goblinking"
]), jn = t.object({
	tyrant: An.default("nom"),
	difficulty: t.enum([
		"adventurer",
		"heroic",
		"legendary"
	]).default("adventurer")
}).prefault({}), Q = t.string().max(160), Mn = t.record(t.string(), t.number().finite()), Nn = t.object({
	uid: Q,
	owner: Q,
	skill: t.int().min(0).max(16),
	kind: Q,
	n: t.number(),
	extra: t.number(),
	reusable: t.boolean()
}), Pn = t.object({
	uid: Q,
	card: Q,
	uses: t.int().nonnegative(),
	locks: t.int().min(0).max(3)
}), Fn = t.object({
	id: Q,
	owner: Q,
	kind: t.enum([
		"gearloc",
		"baddie",
		"object",
		"ally"
	]),
	definition: Q,
	gearloc: kn.nullable(),
	hp: t.number(),
	maxHp: t.number(),
	dex: t.number(),
	attack: t.number(),
	defense: t.number(),
	pos: t.int().min(-1).max(15),
	lane: t.int().min(0).max(4),
	initiative: t.number(),
	ranged: t.boolean(),
	diagonal: t.boolean(),
	point: t.number(),
	target: t.enum(["weakest", "strongest"]),
	targets: t.int(),
	skills: t.array(t.int().min(1).max(16)),
	exhausted: t.array(t.int()),
	active: t.array(Nn),
	locked: t.array(Nn),
	bones: t.array(Nn),
	enemyDefense: t.array(t.number().nonnegative()),
	effects: Mn,
	counters: Mn,
	inventory: t.array(Pn),
	training: t.int().nonnegative(),
	failedTraining: t.array(Q),
	upgraded: t.boolean(),
	ready: t.boolean(),
	recovery: t.array(Q),
	lockAttempted: t.boolean()
}), In = t.object({
	uid: Q,
	kind: t.enum([
		"attack",
		"defense",
		"skill"
	]),
	skill: t.int(),
	face: Q,
	used: t.boolean(),
	aim: t.int().min(-1).max(15)
}), Ln = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("chooseGearloc"),
		gearloc: kn
	}),
	t.object({
		type: t.literal("choose"),
		option: t.int().min(0).max(15),
		target: Q.optional(),
		amount: t.int().min(0).max(40).optional(),
		ids: t.array(Q).max(20).optional()
	}),
	t.object({
		type: t.literal("train"),
		stat: t.enum([
			"hp",
			"dex",
			"attack",
			"defense",
			"skill"
		]),
		skill: t.int().min(1).max(16).optional()
	}),
	t.object({ type: t.literal("ready") }),
	t.object({
		type: t.literal("deploy"),
		pos: t.int().min(0).max(15),
		unit: Q.optional()
	}),
	t.object({
		type: t.literal("move"),
		pos: t.int().min(0).max(15),
		unit: Q.optional()
	}),
	t.object({
		type: t.literal("roll"),
		attack: t.int().min(0).max(30),
		defense: t.int().min(0).max(30),
		skills: t.array(t.int().min(1).max(16)).max(16),
		target: Q.nullable(),
		aims: t.record(Q, t.int().min(0).max(15)).optional()
	}),
	t.object({
		type: t.literal("resolve"),
		dice: t.array(Q).min(1).max(40),
		target: Q.optional(),
		mode: t.enum([
			"use",
			"bones",
			"active",
			"locked",
			"discard",
			"increase",
			"decrease",
			"reroll"
		]).default("use"),
		pos: t.int().min(0).max(15).optional(),
		amount: t.int().min(0).max(30).optional(),
		components: t.tuple([
			t.int().min(0).max(3),
			t.int().min(0).max(3),
			t.int().min(0).max(3)
		]).optional()
	}),
	t.object({
		type: t.literal("backup"),
		cost: t.int().min(1).max(6),
		target: Q.optional(),
		pos: t.int().min(0).max(15).optional(),
		ids: t.array(Q).max(40).optional(),
		skill: t.int().min(1).max(16).optional()
	}),
	t.object({
		type: t.literal("ability"),
		ability: t.enum([
			"craft",
			"axe",
			"bodyCount",
			"rage",
			"release",
			"activate",
			"effect",
			"startEffect",
			"reaction",
			"target",
			"initiative",
			"allyMove",
			"allyAttack",
			"allyEnd"
		]),
		target: Q.optional(),
		slot: Q.optional(),
		amount: t.int().min(-30).max(40).optional(),
		pos: t.int().min(0).max(15).optional(),
		mode: Q.optional()
	}),
	t.object({ type: t.literal("endTurn") }),
	t.object({
		type: t.literal("recover"),
		option: t.enum([
			"rest",
			"search",
			"scout"
		]),
		loot: Q.optional(),
		stack: t.enum([
			"1",
			"5",
			"20"
		]).optional()
	}),
	t.object({
		type: t.literal("loot"),
		loot: Q,
		target: Q.optional(),
		mode: t.enum([
			"use",
			"discard",
			"give",
			"backup",
			"acquire"
		]).default("use"),
		amount: t.int().min(0).max(30).optional(),
		skill: t.int().min(1).max(16).optional(),
		ids: t.array(Q).max(40).optional(),
		pos: t.int().min(0).max(15).optional()
	}),
	t.object({
		type: t.literal("lockStart"),
		loot: Q,
		owner: Q
	}),
	t.object({
		type: t.literal("lock"),
		mode: t.enum([
			"roll",
			"reroll",
			"convert",
			"save",
			"solve",
			"stop"
		]),
		dice: t.array(t.int().min(0).max(2)).max(3).optional(),
		die: t.int().min(0).max(2).optional(),
		lockType: t.enum([
			"L",
			"T",
			"F"
		]).optional()
	}),
	t.object({
		type: t.literal("flick"),
		lane: t.int().min(0).max(3),
		x: t.number().finite().min(0).max(1e3),
		vx: t.number().finite().min(-2500).max(2500),
		vy: t.number().finite().min(-4e3).max(-50)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number().finite()
	})
]), Rn = t.object({
	round: t.int(),
	order: t.array(Q),
	at: t.int(),
	stage: t.enum([
		"deployment",
		"startRound",
		"startTurn",
		"move",
		"resolve",
		"enemyTarget",
		"enemyMove",
		"enemySkills",
		"enemyRoll",
		"enemyDamage",
		"enemyBackup",
		"enemyTyrant",
		"reactions",
		"endRound"
	]),
	turn: Q.nullable(),
	target: Q.nullable(),
	rolled: t.array(In),
	spent: t.int(),
	rolledOnce: t.boolean(),
	backupUsed: t.boolean(),
	queue: t.array(Q),
	modifiers: Mn,
	flags: t.array(Q),
	enemyTargets: t.array(Q),
	enemyRolls: t.array(t.object({
		target: Q,
		dice: t.array(t.number())
	})),
	enemyBones: t.int(),
	tyrantFace: t.int(),
	startEffects: t.array(Q),
	reactions: t.array(Q),
	pendingDamage: Mn,
	defeated: t.array(Q),
	later: t.array(Q),
	lastAttack: t.array(Q),
	hpLost: Mn
}), zn = t.object({
	by: Q,
	owner: Q,
	loot: Q,
	values: t.array(t.int()),
	types: t.array(t.enum([
		"L",
		"T",
		"F"
	])),
	at: t.int(),
	startedAt: t.int(),
	available: t.array(t.int()),
	rolled: t.array(Q),
	intuition: t.enum([
		"none",
		"convert",
		"reroll",
		"save"
	]),
	saved: t.int().nullable(),
	retry: t.boolean(),
	usedIntuition: t.boolean(),
	returnTo: Q
}), Bn = t.object({
	kind: t.enum([
		"none",
		"darts",
		"flick",
		"rats",
		"barrels",
		"lanterns",
		"critters",
		"rubble",
		"lootGamble",
		"lock",
		"scout",
		"lootChoice",
		"decision"
	]),
	by: Q,
	step: t.int(),
	values: t.array(t.number()),
	ids: t.array(Q),
	wins: t.array(Q),
	dice: t.array(t.number()),
	data: Mn
}), Vn = t.object({
	phase: t.enum([
		"recruit",
		"training",
		"day",
		"encounter",
		"challenge",
		"battle",
		"recovery",
		"done"
	]),
	config: jn,
	players: t.array(Q),
	leader: Q,
	actors: t.array(Fn),
	day: t.int(),
	progress: t.int(),
	encounter: Q.nullable(),
	choice: t.int().nullable(),
	persistent: Mn,
	battle: Rn.nullable(),
	lock: zn.nullable(),
	challenge: Bn,
	log: t.array(t.object({
		key: Q,
		who: Q,
		target: Q,
		n: t.number(),
		values: t.array(t.number())
	})),
	outcome: t.enum(["win", "lose"]).nullable(),
	scouted: t.record(Q, t.array(Q)),
	drawCounts: Mn
}), Hn = t.object({ canAct: t.boolean() }), Un = {
	id: "toomanybones",
	uuid: "a55572cd-7dfc-4ec1-8d2e-38fce7013e73",
	tier: "alpha",
	nameKey: "games.toomanybones.name",
	descKey: "games.toomanybones.desc",
	rulesKey: "games.toomanybones.rules",
	icon: "🎲",
	iconImg: "games/toomanybones.webp",
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2],
	accent: "#986536",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/toomanybones/en.pdf" },
	mechanics: [
		"dice-rolling",
		"grid-movement",
		"action-points"
	],
	interactionTags: ["cooperative"],
	releasedAt: "2026-10-18T00:00:00+08:00",
	search: {
		py: "hai gu xian jing",
		init: "hgxj"
	},
	hotseat: "open"
};
//#endregion
//#region src/game/battle-events.ts
function Wn(e, t) {
	if (e.phase !== "battle" || !e.battle) return [];
	let n = new Map(e.actors.map((e) => [e.id, e])), r = {
		travel: [],
		life: [],
		removed: [],
		dice: [],
		gained: [],
		turn: null
	};
	if (!t.battle) {
		for (let n of e.actors) {
			if (n.pos < 0 || n.hp <= 0) continue;
			let e = t.actors.find((e) => e.id === n.id)?.hp ?? (t.lastBattle.includes(n.id) ? 0 : n.hp);
			e !== n.hp && r.life.push({
				pos: n.pos,
				change: e - n.hp
			}), e === 0 && r.removed.push({
				id: n.id,
				pos: n.pos,
				figure: n.definition
			});
		}
		return r.life.length ? [{
			kind: "tmbBattleBeat",
			data: {
				...r,
				closesBattle: !0
			}
		}] : [];
	}
	for (let e of t.actors) {
		let t = n.get(e.id);
		if (e.pos >= 0 && e.hp > 0 && (!t || t.pos !== e.pos) && r.travel.push({
			id: e.id,
			figure: e.definition,
			from: t?.pos ?? -1,
			to: e.pos
		}), t && t.hp !== e.hp && (e.pos >= 0 || t.pos >= 0) && r.life.push({
			pos: e.pos >= 0 ? e.pos : t.pos,
			change: e.hp - t.hp
		}), t && t.pos >= 0 && t.hp > 0 && (e.pos < 0 || e.hp <= 0) && r.removed.push({
			id: t.id,
			pos: t.pos,
			figure: t.definition
		}), !(!t || !e.gearloc || e.pos < 0)) for (let n of [
			"active",
			"locked",
			"bones"
		]) for (let i of e[n]) {
			let a = i.n - (t[n].find((e) => e.uid === i.uid)?.n ?? 0);
			a > 0 && r.gained.push({
				pos: e.pos,
				lane: n,
				face: `${n === "bones" ? "bones" : i.kind}:${a}`,
				seat: e.owner
			});
		}
	}
	if (t.battle) {
		r.dice = t.battle.rolled.filter((t) => !e.battle.rolled.some((e) => e.uid === t.uid && e.face === t.face)).map((e) => e.face), !r.dice.length && e.battle.stage === "enemyRoll" && t.battle.stage === "enemyDamage" && (r.dice = t.battle.enemyRolls.flatMap((e) => e.dice.map((e) => e ? `attack:${e}` : "bones")));
		let n = t.log.at(-1);
		if (n?.key === "tyrantDie" && JSON.stringify(n) !== JSON.stringify(e.log.at(-1))) {
			let e = re[t.config.tyrant].faces[t.battle.tyrantFace];
			e && r.dice.push(e);
		}
		r.turn = t.actors.find((e) => e.id === t.battle?.turn)?.pos ?? null;
	}
	return r.travel.length || r.life.length || r.removed.length || r.dice.length || r.gained.length ? [{
		kind: "tmbBattleBeat",
		data: r
	}] : [];
}
function Gn(e) {
	if (e.lock) return !1;
	if (e.phase === "recovery" && e.persistent["today:skipRecovery"]) return !0;
	let t = e.challenge, n = e.battle;
	if (e.phase === "challenge") return t.kind === "lock" || t.kind === "darts" && !!t.data.enemyTurn || t.kind === "critters" && !!t.data.enemyTurn || t.kind === "decision" && t.ids[0] === "troveImmediate" && t.step >= e.players.length;
	if (e.phase !== "battle" || !n || n.reactions.length) return !1;
	if (n.stage === "deployment") return z(e).every((e) => e.pos >= 0 || e.hp <= 0 || e.counters.reserve > 0);
	if (n.flags.includes("orderPending")) return !1;
	if ([
		"startRound",
		"startTurn",
		"enemySkills",
		"enemyRoll",
		"enemyDamage",
		"enemyBackup",
		"endRound"
	].includes(n.stage)) return !0;
	let r = R(e, n.turn ?? "");
	if (!r) return !1;
	if (r.kind === "gearloc" && (r.hp <= 0 || r.pos < 0) && n.stage === "resolve") return !0;
	if (n.stage === "move") return !n.startEffects.length && (r.kind !== "gearloc" && r.kind !== "ally" || r.hp <= 0 || r.pos < 0 || !!r.effects.stun || !!r.effects.stunRounds);
	if (n.stage === "enemyTarget") return zt(e, r).filter((e) => !n.enemyTargets.includes(e.id)).length <= 1;
	if (n.stage === "enemyMove") {
		let t = R(e, n.target ?? "");
		return !t || n.spent >= 2 || Bt(e, r, t).length <= 1;
	}
	return n.stage === "enemyTyrant";
}
function Kn(e, t) {
	if (!e.players.includes(t) || e.phase === "done") return !1;
	if (e.lock) return e.lock.by === t;
	if (e.phase === "recruit") return !Ce(e, t);
	if (e.phase === "training" || e.phase === "recovery") return !Ce(e, t)?.ready;
	if (e.phase === "day" || e.phase === "encounter") return t === e.leader;
	if (e.phase === "challenge") return e.challenge.by === t || e.challenge.data.deploy === 1;
	let n = e.battle;
	if (!n) return !1;
	if (n.reactions.length) {
		let r = n.reactions[0], i = r.includes(":") ? R(e, r.slice(r.indexOf(":") + 1).split("|")[0]) : void 0;
		return i?.kind === "gearloc" ? i.owner === t : t === e.leader;
	}
	if (n.stage === "deployment") {
		let n = Ce(e, t);
		return !!n && n.hp > 0 && n.pos < 0 && !(n.counters.reserve > 0);
	}
	let r = R(e, n.turn ?? "");
	return n.flags.includes("orderPending") || r?.kind !== "gearloc" ? t === e.leader : r.owner === t;
}
function qn(e, t, n, r) {
	let i = e.battle, a = R(e, r.target ?? i.target ?? "");
	if (r.ability === "allyMove" || r.ability === "allyAttack" || r.ability === "allyEnd") {
		let n = R(e, i.turn ?? "");
		return !n || n.kind !== "ally" || t !== n.owner || i.stage !== "move" || i.startEffects.length || i.reactions.length ? !1 : r.ability === "allyEnd" ? (Ut(e), !0) : r.ability === "allyMove" ? i.spent >= 2 || r.pos === void 0 || !Lt(e, n).includes(r.pos) ? !1 : (n.pos = r.pos, i.spent++, !0) : !a || !Dt(e, n, a) ? !1 : (i.target = a.id, i.enemyTargets = [a.id], i.stage = "enemySkills", !0);
	}
	if (r.ability === "target" && i.turn === n.id && i.stage === "resolve" && Ee(n, "v14") && !i.lastAttack.length && a && Dt(e, n, a)) return i.target = a.id, !0;
	if (r.ability === "initiative") {
		if (t !== e.leader || !i.flags.includes("orderPending") || !a || r.amount === void 0) return !1;
		let n = i.order.indexOf(a.id), o = r.amount;
		return n < 0 || o < 0 || o >= i.order.length || !i.order.slice(Math.min(n, o), Math.max(n, o) + 1).every((t) => R(e, t)?.initiative === a.initiative) || a.kind !== "gearloc" && i.order.slice(Math.min(n, o), Math.max(n, o) + 1).some((t) => t !== a.id && R(e, t)?.kind !== "gearloc") ? !1 : (i.order.splice(n, 1), i.order.splice(o, 0, a.id), !0);
	}
	if (r.ability === "startEffect") {
		let n = R(e, i.turn ?? "");
		return !!n && !!r.mode && (n.owner === t || n.kind !== "gearloc" && t === e.leader) && Ht(e, n, r.mode, a, r.pos);
	}
	if (r.ability === "target" && i.stage === "enemyTarget") {
		let n = R(e, i.turn ?? "");
		return t !== e.leader || !n || !a || i.enemyTargets.includes(a.id) || !zt(e, n).includes(a) ? !1 : (i.enemyTargets.push(a.id), i.flags.includes("movementComplete") ? i.enemyTargets.length >= n.targets && (i.stage = "enemySkills") : (i.target = i.enemyTargets[0], i.stage = "enemyMove"), !0);
	}
	if (r.ability === "reaction") {
		let n = i.reactions[0];
		if (!n) return !1;
		if (n.startsWith("mischief:")) {
			let a = R(e, n.slice(9)), o = a.active.find((e) => e.uid === r.slot);
			if (t !== (a.kind === "gearloc" ? a.owner : e.leader)) return !1;
			if (a.kind === "gearloc") {
				if (!a.active.length) return i.reactions.shift(), !0;
				if (!o) return !1;
				W(e, a, o);
			} else {
				let e = r.amount ?? 0;
				if (e < 0 || e >= a.enemyDefense.length) return !1;
				a.enemyDefense.splice(e, 1);
			}
			return i.pendingDamage[a.id]--, (i.pendingDamage[a.id] <= 0 || !(a.kind === "gearloc" ? a.active.length : a.enemyDefense.length)) && i.reactions.shift(), !0;
		}
		return Zt(e, t, r);
	}
	if (i.turn !== n.id || !["move", "resolve"].includes(i.stage) || i.startEffects.length) return !1;
	if (r.ability === "craft") return ft(e, n);
	if (r.ability === "rage") return !!r.mode && mt(e, n, r.mode, a);
	if (r.ability === "axe") return n.gearloc !== "tantrum" || n.counters.axes <= 0 || n.counters.axeUsed || !a || a.kind !== "baddie" || Y(n.pos, a.pos) ? !1 : (n.counters.axes--, n.counters.axeUsed = 1, Z(e, a, 2, n), !0);
	if (r.ability === "bodyCount") return n.gearloc !== "tantrum" || n.counters.bodyCount <= 0 ? !1 : (n.hp = Math.min(n.maxHp, n.hp + n.counters.bodyCount), n.counters.bodyCount = 0, !0);
	if (r.ability === "release") {
		let t = r.target ? R(e, r.target) : n, i = t && [...t.active, ...t.locked].find((e) => e.uid === r.slot && e.owner === n.id);
		return !t || !i ? !1 : (W(e, t, i), !0);
	}
	if (r.ability === "activate") {
		let t = [...n.active, ...n.locked].find((e) => e.uid === r.slot);
		if (!t) return !1;
		if (t.kind === "constantMove") return n.counters.freeMoveUsed >= t.n || r.pos === void 0 || !Lt(e, n).includes(r.pos) ? !1 : (n.pos = r.pos, n.counters.freeMoveUsed = (n.counters.freeMoveUsed ?? 0) + 1, !0);
		if (t.kind === "switch" || t.kind === "rush") {
			let i = r.mode === "double" ? n.active.find((e) => e !== t && e.kind === t.kind) : void 0;
			if (!st(e, n, t.kind, r.target, r.pos, i ? 2 : 1)) return !1;
			i && W(e, n, i);
		} else if (t.kind === "healMultiply" || t.kind === "healReroll" || t.kind === "buffReroll") {
			if (!lt(e, n, t.kind, t.n, r.target)) return !1;
			if (t.kind !== "healMultiply" && (t.n--, t.n > 0)) return !0;
		} else return !1;
		return W(e, n, t), !0;
	}
	return !1;
}
function Jn(e, t, n) {
	if (t.type === "tick") {
		if (n !== "$engine" || !Gn(e)) return !1;
		if (e.phase === "recovery") return nn(e), !0;
		if (e.phase === "challenge") return On(e);
		if (e.phase === "battle" && e.battle?.stage === "deployment") {
			if (e.battle.flags.some((e) => e.startsWith("resume:"))) {
				let t = e.battle, n = t.flags.find((e) => e.startsWith("resume:"));
				for (let e of t.later) t.order.includes(e) || t.order.splice(t.at + 1, 0, e);
				t.later = [], t.stage = n.slice(7), t.flags = t.flags.filter((e) => e !== n);
			} else if (e.battle.flags.includes("deployAtRoundEnd")) {
				let t = [...new Set(e.battle.later)];
				e.battle.order = [...t, ...e.battle.order.filter((e) => !t.includes(e))], e.battle.later = [], e.battle.round++, e.battle.stage = "startRound", e.battle.flags = e.battle.flags.filter((e) => e !== "deployAtRoundEnd" && e !== "roundEndResponses");
			} else Pt(e);
			return !0;
		}
		return Gt(e);
	}
	if (!e.players.includes(n) || e.phase === "done") return !1;
	let r = Ce(e, n);
	if (e.lock) return t.type === "lock" ? $e(e, n, t) : t.type === "loot" && r ? _t(e, r, t) : !1;
	if (t.type === "chooseGearloc") return e.phase !== "recruit" || r || z(e).some((e) => e.gearloc === t.gearloc) ? !1 : (e.actors.push(Ae(e, n, t.gearloc)), z(e).length === e.players.length && K(e), !0);
	if (!r) return !1;
	if (t.type === "loot") return _t(e, r, t);
	if (t.type === "ability" && t.ability === "release" && ["training", "recovery"].includes(e.phase)) {
		let n = R(e, t.target ?? r.id), i = n && [...n.active, ...n.locked].find((e) => e.uid === t.slot && e.owner === r.id);
		return !n || !i ? !1 : (W(e, n, i), !0);
	}
	if (t.type === "train") return et(e, r, t);
	if (t.type === "lockStart") return e.phase === "recovery" && Xe(e, n, t.owner, t.loot);
	if (t.type === "choose") {
		if (e.phase === "day" && n === e.leader) return z(e).some((e) => G(e) > 4) ? !1 : t.option === 0 ? (tn(e), !0) : t.option === 1 && e.progress >= re[e.config.tyrant].progress && (jt(e, {
			tyrant: !0,
			points: e.players.length === 1 ? 0 : e.day * e.players.length
		}), !0);
		if (e.challenge.kind === "scout") return yt(e, n, t.option);
		if (e.challenge.kind === "lootChoice") {
			if (e.challenge.by !== n || !e.challenge.ids.includes(t.target ?? "")) return !1;
			for (let n of e.challenge.ids) {
				let i = r.inventory.find((e) => e.uid === n);
				i && n !== t.target && Ue(e, r, i);
			}
			return e.challenge = ye(), !0;
		}
		return e.phase === "encounter" ? sn(e, n, t) : e.phase === "challenge" && Tn(e, n, t);
	}
	if (t.type === "flick") return Cn(e, n, t);
	if (t.type === "ready") return e.phase === "training" ? r.training || G(r) > 4 ? !1 : (r.ready = !0, z(e).every((e) => e.ready) && (e.phase = e.trainingReturn, z(e).forEach((e) => {
		e.ready = !1;
	})), !0) : e.phase === "recovery" ? !r.recovery.length || G(r) > 4 || e.challenge.kind !== "none" ? !1 : (r.ready = !0, z(e).every((e) => e.ready) && nn(e), !0) : e.phase === "battle" && n === e.leader && e.battle?.flags.includes("orderPending") ? (e.battle.flags = e.battle.flags.filter((e) => e !== "orderPending"), !0) : !1;
	if (t.type === "recover") {
		if (e.phase !== "recovery" || r.ready || r.recovery.length && !e.persistent["today:fullRecovery"] || r.recovery.includes(t.option) || e.challenge.kind !== "none") return !1;
		if (t.option === "rest") e.persistent.noHealing !== e.day && (r.hp = r.maxHp);
		else if (t.option === "search") {
			let i = r.inventory.find((e) => e.uid === t.loot);
			if (!i) return !1;
			Ue(e, r, i);
			let a = Je(e, 6), o = a.filter((e) => e === 0).length, s = He(e, r, o);
			s.length > 1 && (e.challenge = {
				...ye(),
				kind: "lootChoice",
				by: n,
				ids: s.map((e) => e.uid)
			}), U(e, "search", r.id, "", o, a);
		} else {
			let r = [
				1,
				1,
				1,
				5,
				5,
				20
			][L(e)];
			if (!vt(e, n, r, Number(t.stack ?? r))) return !1;
		}
		return r.recovery.push(t.option), !0;
	}
	if (e.phase === "challenge" && t.type === "deploy") return En(e, n, t.pos);
	if (e.phase === "challenge" && t.type === "move") return Dn(e, n, t.pos);
	if (e.phase !== "battle" || !e.battle) return !1;
	let i = e.battle;
	if (t.type === "ability") {
		let i = qn(e, n, r, t);
		return i && Ft(e), i;
	}
	if (t.type === "deploy") return i.stage !== "deployment" || r.hp <= 0 || r.pos >= 0 || r.counters.reserve > 0 || !Nt(e, r).includes(t.pos) ? !1 : (r.pos = t.pos, i.modifiers.singleLane && !wt(e, 12) && z(e).some((e) => e.hp > 0 && e.counters.reserve === 98) && i.reactions.push("lineupNext"), !0);
	if (t.type === "move" && i.stage === "enemyMove" && n === e.leader) {
		let n = R(e, i.turn ?? ""), r = R(e, i.target ?? "");
		return !r || i.spent >= 2 || !Bt(e, n, r).includes(t.pos) ? !1 : (n.pos = t.pos, i.spent++, i.modifiers.spikeMoves && Z(e, n, 1, void 0, "true"), !0);
	}
	if (i.turn !== r.id || r.hp <= 0 || i.startEffects.length || i.reactions.length || !["move", "resolve"].includes(i.stage)) return !1;
	if (t.type === "move") {
		if (i.stage === "resolve" && i.lastAttack.length && i.modifiers.freeAfterAttack > (r.counters.afterAttackMove ?? 0) && Lt(e, r).includes(t.pos)) return r.pos = t.pos, r.counters.afterAttackMove = (r.counters.afterAttackMove ?? 0) + 1, !0;
		if (i.stage !== "move" || i.rolledOnce || i.spent + Tt(e) > nt(r) || !Lt(e, r).includes(t.pos)) return !1;
		if (i.modifiers.stuck && !r.counters.moveCheck) {
			r.counters.moveCheck = 1;
			let t = L(e) + 1;
			if (U(e, "challengeRoll", r.id, "stuck", t), t <= 3) return r.effects.stuck = 1, !0;
		}
		return r.pos = t.pos, i.spent += Tt(e), !0;
	}
	if (t.type === "roll") return rt(e, r, t);
	if (t.type === "resolve") {
		let n = ut(e, r, t);
		return n && Ft(e), n;
	}
	if (t.type === "backup") {
		let n = ht(e, r, t);
		return n && Ft(e), n;
	}
	return t.type === "endTurn" && Wt(e, r);
}
var Yn = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: Un,
	schemas: {
		action: Ln,
		config: jn,
		publicView: Vn,
		privateView: Hn
	},
	setup(e, t, n) {
		return { state: Ye(jn.parse(e), t, n) };
	},
	reduce(e, t, n) {
		let r = structuredClone(e);
		return Jn(r, t, n.by) ? {
			state: r,
			fx: Wn(e, r)
		} : { code: "games.toomanybones.errAction" };
	},
	viewFor(e, t) {
		return {
			public: structuredClone({
				phase: e.phase,
				config: e.config,
				players: e.players,
				leader: e.leader,
				actors: e.actors,
				day: e.day,
				progress: e.progress,
				encounter: e.encounter,
				choice: e.choice,
				persistent: e.persistent,
				battle: e.battle ? {
					...e.battle,
					queue: [...e.battle.queue.map((t) => Object.values(e.scouted).some((e) => e.includes(t)) ? t : "?"), ...e.delayedBaddies.map(() => "?")]
				} : null,
				lock: e.lock,
				challenge: e.challenge,
				log: e.log,
				outcome: e.outcome,
				scouted: e.scouted,
				drawCounts: {
					encounters: e.encounterDeck.length,
					loot: e.lootDeck.length,
					trove: e.troveDeck.length,
					one: e.stacks[1]?.length ?? 0,
					five: e.stacks[5]?.length ?? 0,
					twenty: e.stacks[20]?.length ?? 0
				}
			}),
			private: { canAct: Kn(e, t) }
		};
	},
	status(e) {
		return e.phase === "done" ? {
			phase: "done",
			winner: e.outcome === "win" ? [...e.players] : [],
			ranking: [...e.players]
		} : { phase: e.phase };
	},
	nextTickIn(e) {
		return Gn(e) ? 650 : null;
	}
}, Xn = {
	bogfrog: "data:image/webp;base64,UklGRhAOAABXRUJQVlA4IAQOAADwOQCdASqQAHAAPnUwk0akoqGhLLUtcJAOiWkA0cOw/ob+Kvmb5mAB7Ruy52V8At5naNX9+D+mV0BvGo0YvtXqHfr5/0Oyt6LyS1hTAZ+zh6YejYYMOd8yg6YB/9faS5kvBB9/8CWXQE6Du/4XDvQ2MQWqHGIHC1/0daOZI4SvR9mmH718WdbRC9OvF2IV3swax71FR7LAAMX/MDZikygTRkbQeogeLstjmgwNPUQMcNdax/xEFZB0VFCeLvd2U9G7fkSlWlGQ1hRxUV20wtBkl5lLufths0yATeu9mfOPaE9RH7AL0xdqyjk1u8LxlrX1xnUHNJH3p0LhnqSQrLMHNDbLov6H6omwiN7WcmQ4jXe00cSMeLCW9TGV1Iqk6qJLO9VWokf6s5cB+fAL3cdCsap4pa4NecwbN7W4DXoQcTL5IUDyqc48BnkUvl/2jx1IFB61S3AsVmLoZ9dkfWym0lqL2pZqIbb6RyASz3kdcvrds3aaG368wlZFJlM4QDvxrDnnir//00342wWj/MWPCW+bdjQR6B1liIEDecUfbVMWiSiFAk8R8Ndct96iSRdWODjHx/xGGQYTFviLu2MlbKvomm89O37PqY0UoF8vimfi03S3VKYAAP79dghRId8uvy323xUa8ry/6za/mVqaBOg6BPHeB+Yuvclv2jZzgYMDjD8Th2K7/Z5r2ilgIOtyZKj1JKoCnPZVR9NnWI340kTqC7u//RqC794ah+EEwbdSuBPxDunmkBLAjngU566Mh+57QJmZNTOH/AnLYBC5cksPlWM/EX55IIWq4pUBJ10pPL6xbH3OE01fZOO9z7xDY4UO3sTCzwZ4MtV5UDd8P8JifJW921f+V+xY5uqfGTfwZejsZCpKysz24U1cuWJEfhcA3ouXDlXwfOEE5gYMMBy1yj/Y40yXa3//V4WpVqCjmYxwsPf8o5yvsZjO+5FtPt+uf/rFb1UdqnZingZv9kLqFjURedutb+QD2/H/8nRctPl1T5BDE/PjvCDTNwXjUOLv7FcBNDENs/hzRA1JA2LGz+hM803Skbp/NlFVG0/rBKfXlOa5W/6dKgAHmLing7GG9uC512RRSKjm93cHAtUYmqNjjxUcrH2Utn24SQaQTO8MxdpS+HKqNsE+byeo2OlvnA6Kz2+Rcr9Dbc8ZT3xBVF2GQL3O06H+1G1JQ412et3mMo1OkEIBifB3EqzP1etRutvFx7P/8R5tv/mL9xMiHrmej5ZgM1FuPv/paq/BD7jhmpqXSACl560HRTImP9CdbLdkrsEaWxwB+0Tv03IqwukJnf+z5/A8mNjK3cNQ+oV9RFbXscPFn/EmukE7sG3832HoEcInIxwfyz51/hzr7QDh+yGK/XVsjHM22Iki4G8kU0BO+0LWPKxt+8ZI1UfvX9atJPvQEIYRubXs+ycLdM91PkFNGJH06rnFp++D91Rohu4aAMZVU2VWnDp0HCrCd+nsmKWD5c5Ya9uH+6wT9lzRmRsXPkDCdX32neBLNh+msLkBOynjDQjK61ein7eqrgm9xfOlRgz3Jg8naiAkWc5D7veJ8p6SQsVraoAPTDfL11KEN0CiSbR1z0Wik7GRpH/TezIVYvNNQqudjqHqkAmLfPjhCGrDebh9FI0ZphBcijw1hdtPqDylb8wP7Hn5e3CEwFZH7zl8Xxip6dLiq1GcQ1Cag1Wzoq2fKuiGRm/ovS/C84PuYKFDy9GvagLfk38U6x2oESzn4XlTWmzanUC5sQFlFep/xbiaXl1XR2kPr9rFN8q8hKlDeU+br8iXn9z9dUmYPG8zaAeVaZu/xJgbiNDHlVPAZLyMJCJ/0w374Yoh8DtLU8/1AVy2CpaaH29vQ4WQC7wnx+u2TV69iKH2XVwn18cIjXJm15KpZk0jZ8mvx6GxqGmtBdNPEjVFzVuwHIl/ll+puwG011Hf84s6O5Ah0/fj0fn2me7YDpIXb8q+Z4RvEdh6X7tBpVQo/2uq2Y3P/7ACV7dZvDXhLOTwTRDPl0Y1QzS+lb99BU97Hl3/VKBFuGzXNbov3rmS5KbsTRcZf+uYT9Ix/L0PHkBmrpUafv2Mn3XkBmNN2QFj7QiQ2I6U0dLUHMIh42gDjKJcYtc46v88SAVd/ZzSaCKIqkkk1/3PdJJUkDm5UHox1tU60Qkv1retIkQ/qRtrQkXP3q7Sh098MOVyXZwDX8cnuk6mggW+BmNLIzR79jn55ZkXXjK9jF5mvVxMvcEZDrsuUEl6scKKPm8Ci/Nr46emkpxGK6wZubOg6SK4+iM74UC0+n9A/+NKyt+EjutqZabFr0/4dhMpAXHNWooaQgEJQzVGDu13UCNxjbb9spo/bDD31999XEaJ8f/cF6aclxWXDpgSCQoMDn+vTJD8GTH/lGXieaMR7gG3rjIgnnLspsD0ZINJJuXlnR7SyUu8QE494j6f9TV3KEeXoLnFDtG821xcy61I1a4/5aMPl3JxNPobIValbckrYUV658t/Nk+iearGual3Ic/0jcS3ZFfwG/NhhdGlTIuZZSc0AN9rhhoYd0Pi295wk4ZeC+fDLKB/cjzQaOhXeCEc9EgWnePTxQz2wDVmJ49RG4puo7TLYIcDxpIXK/cFU2hR39t2gXS+filY0yMuk6EqaSyNEnzo+O+M/iE8TpAObPBm5dxSh+gUxVUSYPnduuziE7Xnxj6Wnqh6F3kZtI7YlwqZenHHgR/JDcx/Lyef71/xKCMB2Zml4TbVs8Kr6ePceCty6qcYbARbch3YxZfKGtAZsUtkYAGYX6klqSUNYekBafCLunIBNybJPsQrIUWUzh5W+S97VtqZLwRFInFsFXzDMtCsLkdzAJWoH9wAH/WJK+tqMnq/qMH54KjmZoFyAd7EswMcQ7EdPsPdAq5u/OA/Ne/qbhsuC+G9ivloHlS9WK9uxDyF7vQciXRCohhgGVxWWp8CAS9kiHxwcf+VHnRaPNCSSIvOsvjCXiJ4/5N2QLJarMaY9uz+pw+DaHVBs/lUN+4T91iC4bDgAhnv0hei9ajjsalKRR2UF0grXViemEzZkV58701brdDG54/PmoHGFFj3p+t7evdyVXWCtQ1ZhKaVuHOZMUoIGHcBahSre959NEMnAQGAOIVHxD9kKuyhV7q45C8ff6tNTrSAgbycgI1DnBptiqSzVOv6ZDlUN4aFn2ja998LneCazMO+aN0U2W0cHzsuTSttZO5OB8p9s/N62SSTBP5xZ4c0DUnKJ3bjFS5pBIgAgygZsKPhEqAtWRY2u3ZTu5rLKpqyIAifUKcw46flrPHG2k46UVpwhUOQnlzZDNcSGQz+uq9uUejjl9n3/7Coy4ktdvi/rPkERzfOsxTY14lHYd/YNAA291HpgC3ZugOsPaDrl3KxbARbkUqR+7V7SMRkK5FsDQOqaCxxJpqBi+ljTDfbZEBiiZBep7mJeuv+Gc3mGUyB7nJ2iSRT7fVM2ViXhXHcyZTxPxZ0DuuvkHDCjtFGREsfbTc4CbyYlJ08ldtSauBLY+h1r84D1Fi7nHfq0CaQScF9iPZYeMNVXZ25K7V8MrcinBj0AjbR1CTVF8lbVnO+SigGF6prpxuAr+qy6uxEoGZzMj0bGRbBhI3GBu8YcAV+kZQGslvGFsStjp1i1CYfHGXusL4qzzl8xLbleQddCMrK8uKFQwTD0VXLs9DhqlRgHupCvbG/E8M/3g0/mXlwzuES+JJScbftC2000NJMhwfZW2DTCAhdWvLhqYBspsRbCvkOiPaYhGLmeXS4TZ4STBrxFFtmYCjsLx70skB7f05JCGKEtpVoDx//pXZvxnSG8vo/95W7nAUVRs2TIoP3PP8SgN8m1uVQoeuTsqMvUiFTa15NkP9so7LWTvtM9Ms0isC0vaPW0m3TvcqSaVwip+Ja5JcS8+qq1NVY7IfkFSYw+Iy/3sGw3O8nwb+DXKqd57vrzQbii3ewK6mhvfO9JbzkgMzT6iBwNxKTZfi+GCQCw25I4cKUrhCcSEOhCLgcnTi6wlt8c6TfHlUyz53zSaOdl+pdYRHxu1tVVexO85zy7SXh8+u6fd0d6PrVFBnTBrZDpkUVzdTVktp7IRpVW2SZKUX7sQEB3ckwKObqXn0QQEGI6gwAB0xbURb7hgapNZPRiNILzA+Ld8P9cP7Ugr6KMGJngii4TB1/6x0XC6XjAGIASahdia61+3TE1NnR6a9bAWSh1qbijoiUEIUGQ8bdmfDZdpN69T8RaTsEFX+/PKoS4agz2fi2aormUFXXRfybBtGUtdc9RKPqdEOHY31HceT03gETNlBWu5W3fiJt0GESEkNTeZRh6SMVisd+sKHpXhdPG1Dilom6Y+FUqp6HPTm0FthBDc2AeRDJaZ0U79vYaqaw6ocRB0lilbpv6DeTx2k9taZtXCfbM5ffijSDnSMtKmrImonQQ5joVy5eGkTvCjMDdQJLewXUPySbvNP7/5+dIS6BnErcnw5Kpxu5Ehoj4f8T4wevoaEKkqQopqqEHf8g+IEZp59OCpDZw+B6RTzrlZ5Vu9FFgI/9A1LT7adVKJUtpdlGNVOL4zzgQY9Ho2dFlwk3b8ZZDORPDagMayND/LJ34HVFXupbEzXZE+d7SJ1oGXTuHidrKGTcg2hzC9qQchGs1h4uJ9QZRfcDxGskkUK3vaPzs4cMzG6QS37IDh8HM2tCpkgdoDEJWYWYUjZxT8MkOGaBRvP2MSkgg6IBPjlMWbiaG4wW3ZDUo9WvOFCha38mlrBU8ck63VRX9x52XBq5bqy3cnehpAA=",
	boglurk: "data:image/webp;base64,UklGRjgTAABXRUJQVlA4ICwTAADQQQCdASqQAHAAPm0skUYkIqGhM9fM+IANiWkA0nes3v1+++BfjG+JfvX7n+uD/gd17qTzD+wL73+/eive38c/9P1BfZX+T3tu3XoEe6n1n/eekJ895nfZr2AfLj/l+F56X7A36V9Ff/y/1Xob+tP/d/rfgK/mv9q/63Y59Hj9wnKOZaGF8kuX//+2EX1n0Fi4jLyxjEJdg3ij4OVosM/9GJ9TtB3uGY2XjMbwY1iuBJnV/8ouc2z2oETi2Q3+1b0G4FoDdau2R23UVRlu/ci22JXfxZMEabaeSU7X5SVq995zI/K/fnxsX5Dv6jsF2TITnJZGnwckMxjvNaUm3Hz08IPbMt9P1H7fbW09DrBnmDE6u2zjssbHCQBzqm+3WN9z1dZgwU4Nz9Av30kBr/kPB75LPwgLO+NaVJFcQrw3UIDOQ77z1XaH1fEp+0vurZdqa//1Es4/MZvfZsFl2PcF3A0yTv+AmouogLoXw1x0vrkM/x4BhErfmGvSYcnDDWFN19zuKZWteScFDhnFFW62GXGlWWwlniyRf8Yzn7Noa9RUUXFPMZhUO5TGEGyrknwSeizzZGys56o0YKVkgcIWjyvcH/N/3kRonNEmsOM03ebHxvz3fjSPdts4qgfQ/ntWCUpGtvH5MHPJUBK0mIFFYLTngB8H3WJc9pf/K/bSMhLFvzqgWC6EihjMuk0SeDSCrjqNM/gAAP7/vcAHxdDwabG2U/IdjbXaTzo7J8v4OBlm2TqE8cRlwt3DO1vVPA3JUgy+gxP2mBDvazomGg5brKtv2MD8VnvxGmGem6IIUqv8VNiNNLH0e+DthUgz3vbYqeVjc5CEFI0zGf7u7oo1yPRcqh69JU+Qg+EsJcEfE/fST8LIg0MoZ5nyYI95a2WQX/UIu2J6mJ/yyNMT2GY6iPGUIuYgg/ivwn7M5EwcHDhme0WLk2VQYfbbT+VZoEoyG2dg/5oo1fVhb3zNj+LURDQUPL/TS7cTN4wARenG2RPrgcC6mWrxc+CVqzK/O6eA0TvE4lRUHFyLqtWkGWQGR6TpHr3hNU5Kb3h+tksT1wXsWs55zEHv+7evOsW9aYYMp6LTe/VJusyR2YRRhQS0fHLt9+xqpvPnW8JmgJA0mS2+3c/iIjqTFMAqptSOXnP4V8gRlpEJXeXhKd3ewpZ/JrH/S8hz6Of9VGsSImqWqaYewbqnzW6w/EenZO1uHDHNV/7JmwhaAL5/9+kM62gpwaHmX9/0Rv5U58Y3WyjhUNIWcWgIK4K18QbVi2M/GWkWCKzIU9rU7mAyP0P+ruIZ7nUnRDOmdN9K9KuaPKN3PHfOjzSoTgsFXT+BbYS8wii/f6FQRURSvCGCRZT5MmdeCdM9kTn8U2ypJZ5Locavj1N/UVPwJw3E4RcNWFdQ8N3tGK5cT0mnQsfC4IoOtcfLHnz04B8HOWtN0Ro8xvGFrPK81j/S4H6vkWUBG17ow9U9FCZDO9v9XPoI5InvS09cHY9sOlTyRDaf73/mOvwRLBwFWp75EPDswj0+Qd3rbFWVm4wCOQ1IdqUaVMgpPup38delBrFR3KMJ13k8XqnEVTfboG6n93q8hxr3ogkhC+abZkozmQ+Wuj1z4Ddq4RsQG4hmEwpsyjpc/LIU5ch2gh4qrSfhUlNkJQz7sngGqh6EeoZT0fRkW+4aylJbPavb/Sn6lJN3XQm0k5zGlSXXCHmZwK5sVqTWc37N493jW7gN7Ftf9SRHAT+mBc6/5usC3kLs806kPIf0H45bX/qFfWHihOtrIUurdjCm8B7rtvMGKd8I99kEqgej4mPp3IgHZgg5RiESKBXpV3HUn55+aZM7wjjtUpBLsuApyP2Zqx8vL+rn3XCljGFRs3fOodvpaESiHe9x0siHjfj0arrDq0J1mq3O3A8nUIDLYdQW3GlM4aqRPSOyjqwoNKor1Qpio0Wpj82SjKdddv3p4sBun0pkf2Xf1ANygH8+icgio2caKyY5JGVioODoZYpre+1SC6XGvdpna5u7F2/x8tl//HJ0YmVojgn2oulrtRNNpD9CkRUq6izjyPmCVQFcUZ48bPZ2K4UDx8Nt8oRa/bG/7rMyBs2cyVBdZcaO57HwZSrookWrSRr5PzA5BsfYMYLRLGO1oYI5/QecYeEea7WI9cJInjWgGNZfgECFLc39wp51un+vIiiU8cPtZzBENEBuglTFf4/8+0eqBEq7zrtpZotlCFYSWU5/84uz527AGh47j1MTzM1IOLkpj1ahVjurDQLvXzarGnrtuW6k6bbDwy2pzqmgZv7pACryY+3jqbzlkdeU7Li5/i1VwQrmctBudTsIRsAiDO6rSVoIShEsWciRdB6/nFo81PtyBS+UKCTuGfWLGst6i5FJY0eHkGDYSp9ggHg40ZDnrprXLSV4V4tE+U0ZsoRe9/borIhXlMkkbJih9lFYrqLygYdGygj0X1Cg3eSuiAn4v100IKQ4eFw4lLT2Nprb+r1GJZJ/zx/IllFYzW7IKi93OBALDGh/zJT62bK6mv4JbWJOww8QyJ55M4Mqb2F2a8ROO3sH/Qj87f9TgVB9AhFQn+NgCVNTUpJKFgWj8xjjFCLwpvgg/dgv3HNTtQO0FIiETh8D2z2kiTBICpwORzHD3g3esPHtyF0lHH+rJpPMcH4Mp9UN+GhR9LGwMDUgccQy6ySGZ0u7/8TH5y73Md3Wz1MebL+mALLJ/rh5dbeZfIkoNfKgg1m9ksAUE4AG1mfbsoYlzET8mEuaXOWOsjD90WDmPSO7xAPR9rl4AmqH6s1LA8DITumLGIK9VP1tXAVNXJ4y5ax3LGJ82iJy0uXiguFn/4UwmvgMxuYZedFHWXScaPeENBThngZg/jMtXxAQJQx6PPfhyJ180iA6NfcszFvnMo6IB7RlC+rLH0nSsgBkB3H6vwczdWN1CnOTRzUyip7vFMz+jH8iWaWJhDZK4Dq120RyCQYNH/TTXIPxMBXHswrb/HP0Hmpa7MxicDdvzoQJWF744rDTDr/l9SLOGffjmIzggTfSVIC9DOrRcDbtAnOWZ5cl3+HjVs00MGHJUX+zD5yElcq/fRq5BWQY4Ha4XL76Do2RGAVfv/xz9x2TGLvxM0N/TXrqu8m8SnrZcL98VQMfl3nifXYX4PyReoTwjfaxStN6NxA85XqjIczyZ/OvIRWvE1U4FIdHMWFt3UDubzm/ctpTbQGTqS5CfjZxLZVzkzZytHTaJtF3vO6/7JP1/6UX+fdlgKiNvt1TDUBMlkYeX5NSFUAUGWQ4LmwGjYqc5+AGYgbOyJj/SqFJSLgwb7txJzON43APzozU6+POhCPXtnHvQnP55+2ms4MOgwgVnVtChMPbyCYG6x9OIJcZ3poIitHh0CGc/rk93gDtVxbQKfU3h5ddFbztanmum5YJwskLFMrF5UfztMLtwQeuXBLhsAfRqGzskc5R4XxJngLhlNAgMnJ80vuHknR+FU6g4oVxmi6hi4NLjHlpP24c1pGwRD4XZsp7xMACZCmNTLfi+7/OY/Iq4atGSF6AuxavzraxIhiT9851DDN/1IO3ZI8lTp/UMRiSNXY0fp7XtaNwQss7p2zc28fDouSpSL9VHnUI03pHwlw2QJWLlPc1nfpOv1/+H2y67hEvV/A9Mw3lDnIujKbZTWDd/bjHUtYvhjhZpdrP3RJHtoXCk/lJ5o8qM1jXQJjsOMXe/CP+LPlMOdw4QJ7j5n/kQ6pZcAS8DwQb7QhyjzggtwkrHvtF+f0JYAnkw8ZvE2CGvre0dXlA5ev8t287G4fvmmIqFsVXn3OxjsNg/vuXzINOWu0t/aEuKWLT2MJ9uxsUZo1kc+sP0pPLalpTymrG8VOYcvlhiQsYRjfdFPrfTYIwgLrjOwhxA9b7cmRFXvA8o+ga856nptCT6W78P7u+q82CE9JL1C31cRYLOR3LbicnN19+ah83RwShZt6qGS/ObMvyA9RSTV5gymjhwIHqvdnQ4o9cpnlYX5wM7L4pQ4aoQwm/YLYB2PVpYvBkyXdJnN2PsFkBYJM8PM7LJKF9hYmDHkvza0zkkCQ6n7/0BQTd4+veM3Wa+5/9KFA58OozMm6/XlS/59mbYXjKU7vTypFiFEtmp2NVoyWGMEGCQ2QClUFgU4dOIWEvRZ3PCn+Op7FZdB1NfUwfNQlph2xZR3Wq3rRTMSb/YJtLjjXh/8OFSqU2dDaYD8HHV6XMULSk2FaZzdLB3wtW8jwPS2OrY+D8RICH8dsF5R0ajqaGIlyJUD9DXU8CKScrJaoQfBHWMheMiD4W+dkBNPqLGkVWXSAyRcd6wY+lkT9RpHIscsbIo89ohWbFURSZAn2eCK3AsDzaHLTDKw1BEENxpujQd5FNWJCJ/GEU6ntqJSzQ7wNIPT3rsnyYon1koW+YJpwaBF8NELXlFV66vBZVIYm6yXmjEZatg6mW8ZMWp8gQikXpAWn3GIP1/7xEh5R3J443gnsvHxlS0cff8TID62Dddtg/vUOD4vWoJvDyIJVEfb877qfBCMsxbu/WcTfT3ypeMMF1VS+DRbVF2i4fWbLcP4P3ZWJ1mkmPeI+pSSEzGo+Sw5PxUWpa685IEjKaYxbzVuzgYhlJL/6RQ78eMVRvbCQ7PQZ9PYFIVlaOPHlvOmUVOdHOuAvwzP/G7w/VF0YRn9/YP80bFZwlO71yPMqB/4E1uiBirrsbZP6jjvuq73q28F/rxbDuCFvRBqhtEN/40YIoTkv+ZZdUuCNd1VPKy/sTkL0u/kBiRO9bn7n2OaRDji961qnpXd7ZeBSnkd9fP2KEWaGDHQeYbU5V/wevRM2OVVC/bFBsDKHh7QZLaZZkJ4I4bMFYj0Qh1f5bvnEF+QgY0lXBWrrf0MrdDW3ta3R+GwE93UZO1DvDqg5uAL41VwgSKv0ptll0fLG93Vpc9COxQ6rwwt5j7Cx5YsKW9Hsb3dzgcBpkmMs6i1Ug+xeVcmsMPyz/a4tiSutzm74K70MAjLFkQA7amSkXNEGv0ITp8ju5vGXcaCE9mbu9TSJWz7njhRA+D7c8hPPoSJyUyhzYg+1ybBNl4InDVBUneezKDUMACRrMKNt1WQJpQ7XbaVXCN1pYEPhK2uCcWWeC6F0SG49yb4jC0YAOVsr9VhX4eGWwPVTKDBg4hNLgxP46jJt7RUsbjHj38aTgB4/VwLGrgrP15gqcFZxbVUAlcNU1GT7uuKJArXXqxo3v32s5rnO2Aae3QlniYjP+ka74ukKu/IDXAWG7usX0sxCoGx9EaSSerYrwVAClIp3qngjMubAP1LRjJb5OkzrRXgKamCc74FUMvL/H3RsKoDCpqj0NSe8ufY4LeyxCJjBws9RfYx7TWZZ3CZQS3hn50FfBYdP5f1nPqUOWXciAt7PyH71x1XGXjiPIyrJKsN53+VQt09uyeF6qSOCHMAxdsTT0dYVMNl70FHifBlYPMs5n2CCa8psJxAQ17PSa1Rvr82FiDTKrjprtpeEZFKibI+Biv408rG0jxsmnIzOhWvmkp1b+x4sV7rOU8vHUQIfZUah3Lh4V5eeITDyjeeVfSJi+Pxn8vD4ULsmeeFaOMIsVeCul+/MMmuiCO81tCzleOtwdYFOEYAr6lofhuHKzZFI7JhrPev4QmwPuOVMz98jYV//VBceMYJnJsDhJF0FitUdr2X+r18oai/TRSek5Q5uEO+VljGF9I6vxAdh6CDOmkDpeEAnAu9mKCwt3kX+OwN+V46EKdM3uft4JgN++y3QgJV9z5Lt2j7U91SdHtV5kgX8XQnz7idwJsGlhylMiCuesrr3fMWzq6od8GZ/rAKWXuO7oZyodsdTIOcvjULr4Lm038VsD3svfZApVZX0FAUa4EgKUmmVRk0jfym8cyuClGaA01fwSdUjG7dfwRLB9VePx2td3XmhPeUwBETesFc0smaXMC4qerAYVlys3oR3/y8uQRut8YKQJ9v/6sILAUXy4OhdDarOdHs2V2qst1RZRndyVBeoct4Fa7AFcSQfL4XvERK4pfNPezCJfARYW1CrydsLmG4y0Ejh1XeCbnzpC7rDQvmB5a47wFXKXIe3qKNKq2iLb1VBbkhIBEUnaCfgxMfHZHlbDlCeSUZoHGFIftBz2WAfJog71XORp9+g313euuS2l5PJ3jey2vWOsgA9CZBF4NkNbwhkEgNK82nmNGQoJyU10izKcRgYBo98l6383hYPNsjez3Cxm2aif2A5G4ZKxMb0M046G0RB0g1bXS6/Ymu6SMCTnW0CohCFB2UreXpPi9uDPLk4V0oTINn1iif7oQlo80xbjgzFOIOOXn9+DGwpCtVWT2NDTCn2hN9lOQ+4KeofjtIec9yjSkba4gvo9wA32h4PcoyqdPG4K6eZWNQUMs1bBpZ0QTNpy7lDovnjX2FkVhJk0JxtCSenJWKhxVL6DfbIJ/RSykgkJq33sm6qAzQoI5xTqYGWvEp3TST2mkSQ//5EuLIUhSwS5WYQexkbDmmXgqX7owuPMZAe9Eex8JPsncgo5FU2eTzGUZ2VEGUL8fOj7+xjxgAA=",
	bogpole: "data:image/webp;base64,UklGRtIMAABXRUJQVlA4IMYMAABwNACdASqQAHAAPnU0lUekoyIhKbQ7QJAOiWlltF3s0DWLPn/2jeyhFLevZrwAuJn38oFjgjArwq0zGRX0otF37X/w/YJ/XX/m9k70Sf3AFhCpJAaxA9rp99GVDspX//5GYk1gh4oBgex4MvG6s2q5U8Z8RiPGheP6J63Sa8/9XyhZq0n2hHTI2zSzdoz9mu47hGyqbtZMzpLKqsRHD+epR6IUjFnyKNIAaITNnnA3GGQ6yHedSH0Vl1BQOngSBSTj2nm9mhlEe7nLzheCvVGdpQVvykhG1x5ebqxfWZ8s9OsXZugViUDxqfGwtwQKJrzEkcm6slS5fTMSENPoClLp4IjPpbzjePv3eKoJrlaTczP6YFwppCb77bD6Fu2VkNa/6N2pkd7o/Rj8bNLBzYfJg6s90vmFNrCjvql1KUe8yx4svOgKWXpeuVwwhvVyw4N0W59h18NwGTjHg98f69KoZuvPFNGwsBlT1pC+qZ9EVaiDhB+RlLBfpS8jA4YLq89jqJ8lnJw2AqlOssHw4kijmqX5LNTOySpNqPQvV1staohaM42jh8Cu3Cj6AAD++uWxG+z7gsz6UEB/BXKubZYsrjs5ibN/ml9wfN098EgHJiSd5rS253fIfeWYm0YNJ3r/Fw6Awld/9zdPYuqS/M+HAozy+S+iW4q7iFcIORbc/+Xsxok10/zixBAZjW7KHuaFlRlq2Nojf0Y3ePDTwLdmc2QOd8IaSQFwBLzkna2chVPALujRXzI2dvBigyBcx6STSZAKbSctOfE1syBi+Ucs0CjaLkxclahDjMvNwFMiq5fzPE+Uk6Vc3hFf5N6pIS5IifD9suOTyf5q/ubMftbDsXhPt+OOq9kDYVWWFHKJpONBE4O5ImVB7a5vmmTShPN/1l99dyR4QWzL6XBOxCuoZ5nnI2J2aL4866J+aWzWAi1/5G9sb1FKPRiIOQ/VXR+sFQpf/bD2PyAs6ep+lnvkOEG6x0rc6dZDeZ7KuQeGgP5n1AvSzJcliN+awR4+n1+pn9tbfaH2b/S2bj5Rf+kEUgfEm6o/JVy+4uDWGgT/vJcp+6/PLR/Puh+PIuhSfQkurZALanp27+VXGCivlYJf4z9GSpNkF7QOEi22g0G4hEAQBBWnse0lo3ujbux0I0Pmk7YYaRdOUH6TjLxLj1YjY7l81jAjyH4NJV3+zHVGz8mDNH+LQgJODtoTyhaGvze7DxS8mJy5fkpQyN0GYX/obMA7PFOzdVUTE58096NgHnsjmwjU+WZLJHUKsrA4SgVsnU0gtAEeKaNtnSfFkSHeMQoplZYIxQ/PCwpEIqeKxSF5cQZ42n4SxO5guUwphfiKTF0ez+1M8IzdPNgPdx5jQYZv9LgZM9hAUSG3Q8Bo/Dmk/H7fm2QOzzEsQd7YfX52kIqm68rY3it2NUp2bSDZeGyhp0e3LkAivY95J93OTZuEJtxeF6znepr6Yb7HH57/RJcXm09yKk3Aw5Uxw2YPT9Pm+mRh8cp3mF84nrHa0+JbldgCva8tGXb6wO9nQK/PJ3CAmhhueKBkYmNvUaP8yWhVhRO0fXPxboZ2P288pfCgb1u+lC5vJv26nsQ8HmY6gGkFOezgnwXOsS9U6lmtGyLp8eMrIbgJamuPrnp65huHHZUoMqZzwkD71TQNdriZ95WuKIHlmmyyWtDyDZ9Xy0qJeg+xlLCpDBzP+u+2N81d02YGWcQ4Gl9Wy4q6CXg6fQO5ZyO+HDKtQR9kIDn2EKxK1z0clJLjj7zDj7O9Ll1LRFOwIHhFt6LZngMRBs0nW+5XN7h91bf9eW6epTB/4vzhl7NqUIBFVZXs85N4dlBzN+KBKyMJj+mHzEHE9TuFHolYg6N9gyIFpusWSQemYOs/sil5byrjWvSb9ShB/ZP2OSQwu7dQ8VKsXsMR7vFy9Ktllv+ZDf+u1+xsWDWXQ+hq/sWK3BIOBHZ91ZMB4azc0efstgflnSN45FZX0M5yAQ1IACT1JhAgTTX86my12xegsBA3sOeO/iWGqqFz5b4jJAGBoN/8Ql/HX89oZJHcUH6n3IB12YuMlD8FS4CBOvBtdF4+pZxCcU4mhC+0Pvigpk4wM3rL8YiRjCHZSEc/htepLEMQEXHPLyOjAfuyfMfyZB5vuVSbbGqmdUgOdt4hLZVpX48EGeeF/ZkXEAc+0HYrlLgNJ6/wpwmF1MQCO2J770jiWY8zA1PY53eVMheXRd/DzsOBKjlvLOTAalmRbQGNZdArrH2ntTo8wP+YouSY5dR8zjvPtjTcUIfKcytKEDBlTM8ZFE9w6S7deUpO9cVKflXj12vbW6IMPCGMfVzrP8pVsr5zJoNVN3R9Cfx1x0kK7pyJP7Ea+RmXYz/jRG9/TaECHmpaILIp54FbU0fjOBUxRqbhcBwV64RhUPdUeBdqOHyeLTmJkqrH6sNeQ3Q8ROnboBZ/4icHGtC/hkwi1h5k/JqQgWMkgvhMlmzsRwo74VRvhW+xOCUh35DY2bFMeTAXVZXOOyTm1MUEZTALbIy90eaq2jeKZu8HiE3UKD8cOoxnVdAe6uJpj7DPufs/5agkU5tcQXWSiPL4QXU692ceb7EenEwcWU7tTVp9yha0kVZ3f+MhVm5VSWcx6aTQCe0m9BAbInDIJT1ucxHj52YQ9MKdFAzqFTfwIENfuOhvO1iWQ6LM9mEGT/XXIjpqrbci2OW9qmt/8J7qT9SeQVV9bel8SVxTtxQpmKSzbiqnuXvom0mCGfnb6Lr6i+/GQ9KSymkoOGcLmSqRs66MfcbwZXDntHWw4R6FJ0svdN/t6aKGnsKLfauES05uvYn08JdhmFnyyqk+vCqYn7BA3V4xUAhwQCM8/f6+7y4FrQWiX1s9BtJKZuhWDLFJlPg2npHkB7iY69wNN7m7hC2indFCds+PIbbWz0TKqK/z/mrygsMT3pttMk/Gf+N6+yykMJQSAHIGnIHjnCUGl9gHWrzdmnLzriulNtFKT6Lg8F1W39Dvw6e1tkpjm14Y99Ul140YDg6UlV17r4qY8UBuku/HLfz5i7fhEaluZ90C/g3Gnmkfp4r4nCCsYs6bIgBBdjntO7Jtwty/nqBqA2bjR8VLiJSYu4jasj8M65fkBM+NQ43a8NhEfYuqbOYutqAk5wBhX5PKd6u6XVfigI/nrLMvz4fzIOEpSuDlTghtwgh8VYDQ5MtW3sTrdytoEaaRE7IyeNGsjJFcbXurp3uWUCx7kezIH5gqh2ceKM7gFmn3Dc37XHzsPrEbstb0lRzIt8fW+5wp7ewxw+Qjc9CKBSGGpZWRIQkUKz/idAbbRNT6X9LW91LGzh+TBay0sjd4YGG4W+difvQbR5NNA8LYVbKwPmWFR6iKUhtkanVOu2de/LzETbRp/kNKN+Ymhl4dnS6K88BlB2TKSsijyYbEK6vO2+caajTWNlISGzXsZtvo0KXq5pR2YlbcMQWnm2kXY61m5+wPYyBVYOdq3oXhRiKM2UFpQ2Br+tFTO20AYgY5UosJwANeHEGKZPcYr8hTcZ0WG68EZB69eh6Dpi5eR8kTq2sIn5vDcJBe9emjaIRapTqRA1QWfGapxBwXqpDuP4Q7VBvrZbyuUf3azCE83Rym9lSWQGGcH5Hw0RwkfvtniNkV6kA0DFWxslq3IT0Toz8VeA0yIGc3lZOVahkSryMk8PIQ2yJRt7pspO/y6B4e7RC6vVRIBD0oc9CoIx3q83Ve00xg/lMNyOy4YpUB1qUdueG0Sv/ivMDL2FVGRs2n1SCmRlw+JE0zsOuYmypv6O4eVuJUPQu1x2eTX1EsQImU6EonjH0FAgRVxh5qv2RMAWbriL+aJy+l15XvUAMM/toyQeVzLznaQpV7ibQpfE/omDJD5OzVjPyTiw8EI+3iRODZGMylWxfjdCbXx7evjQv4VeaX0dV0IiMNuawpBT/f7d8mtSGBusDx8g5PzZqPz7RFgkwq/mkjLnia1sr4QLf7KMMZ2DA9r4Df+v2KZ9paIB4PTtv9G6kmuEz1H1OgjIpAh0Z8uAQd985s68cK9yP9G+tUmZOrs1TDtzF9Bhpftb9qL574ir5YKOOod3/VK6H/J7bNpEQpsmyRUiSdkOy93Me8sd8semhg3FBVIS1sTGOkkXHte+az1vD6T2WhHZG1Rxm0npMLi6gpBRqaWjNr3rJHebS/yO2Y7+88FSZS5dcfTycHKXQV2RQfH9uD4/Hyu56VZLsIDV/eyMScIXoVNMh8M/+DyYZBisvhhjZiI0soF2HykDUknz1n3Iv5PiqylxHid9QJduoApfICqKwg4vP2a83KBpKP/WsIboXvdaxH8eNiuTnUd3qbmdb6bF1mQOt7gVui0FZk1C/AAAA=",
	bogwyrm: "data:image/webp;base64,UklGRlwSAABXRUJQVlA4IFASAABwQwCdASqQAHAAPnUqkEYkoiGhMFn8oJAOiWkA0rOvrwc/Ifj35o+SH4Z7i+xbib68dRT5v+H/4/rU/o++n5ZahftD/b+k79p2n1u/QO91/sX/Q9Ff8Lza8QL9av+b66/9LwtfVPYC/Svowf9/mD+rv/d/rfgI/n396/6vYz9HD9vlLuWSy8KafmFkBUCKhv9vH4xZ4Reen30mhVe5jD0BWwc63+3AVNZeHBsVhTH8ss/Ax+WeJPQJlzRdx/Qp4gXGw9HVNtz9RWO/iV2dk/IMmiDF35eALCRnfEQDRxDIOTyx3QFPmE9qQzSbU9+Fo28BGZd+LNZxu6ydF9jN93jltEgSBqEHjam4jLbpRVmLPjja9Vm5T10GBre43lAwezy5K8NVSTlh/VUxl6DKFIvZhPjPP+taqa8VwytyurlTrjNdMU/gtrrZnweyFzY4E867QXbpZhr4+pEcXeYkgGV7eDq9NdcGUQsSt+BmzjoGvWfBOFLpRI81h6wkiLPat4PxPEPuRczlg+BhM/Fgw4ud95vNpDTl6cnDYct6oNFfmsCHToyHrml+GGYHvg+6gnpUudieB84kuOIIuQXY5N30cCzEbstsiA2ORniGJfaKQRswXxaJOUcH38VOP/lqZ9UpS1xo/K1kTKf2LOe26DEHVOsSNOBiIdmt4b+p19U6wiCbkDwG+WFRNn0xUrXdGGZFEFtvoM/Q8laDo/hhXMm2MhFQoAD+/kq3xHBm72JlFWYBrn/8q6wPmrgRyJLx872oqv2av/LVWRkyqDwV/gg+vP4nifTfWXejPgIIf9opJGPEngyiyuZBC1EHl8El3nIQBsbn8RWP/43Hezk6OzRx9lof/OFJEZxHaRByAZ1xFZ+zXw95/08JY7TFftafV0OwQNI/RKYwKiEJspke3oSetMvBkZfyh+Fg68sB1r8IGsgCA/68Iwop+QIq/6vu/QePCV6Gf3sViM7wiGYZB/LobOToldnsAuFH3qq32f0sr+C9jGLQnEVIEt559j3qHnKl5dPMNbqL+MUtofx4PTq6b+JJ8pT1PYQa9971hJS8Intvd1rHC769ZR+VZI2q0Vw9TUDaQOi4DDxB4MXYyl8hClBCgKr3lItwkfBGD2Qg14vydVdCbDAa+nfpAeHWoYwyFIMDPP9lP/FR3B1vHmoZdqQro67QuJfgq4SQfbshM/Hf4cIN2NlBvBn/7qQE8d+uGCcOVFHHlEJDa3RPcrCDE1/zQ06RMywPO4dyMIZ7KBXytxf+V8Z80TUu79bFe3ffIV/XjGv0cyykcrhkOnbISZ/PfxFhEOC6Z845igVwCw8NnnPlZ2DuOJE3y1AcG1/Nc8fxTJFBTdhXwDdf3MVGmn7ZpiRznusR2lag7r7II6XKKRoRcBkqeb9b1jqwiepnj/YOWt5NbkHnpC1Udu92MhAqyNtcdMQThyLoTewQZz72dHYBqkMUsFzU49cMY9n2Gj2Dy1FU9gNk3UZBhDoNPIKTSiljfm3yC/pSzs+W+xfSrWk2h76RGGvx/xRoAh+QwZ7/MSz8TKtzuA/AQqpd5zy6FXQQ3H99fiv1MtnElv9lPQsItOjpj4xqjHBZjApn6yaJp5slc8/zA9KjZ/yH6lBebjcbRx3I7dZtQLpg28tAoKocVfTZ39RqrmRUVnGslLP2nSWdgJjgcGP4IxypzAm+L1f/P2RXegln0XqO4wKJUdjnNjbHL8D7e6GQFgIN2L5Q6V2ebDV8pPRev/EXnzQKIEToSSWyYKAof7obPDZSSCeTpXiiTYxcNuw8CFGr4eQCI8mex2yQ4pUnLBpgAnPM+I2f3v/x0o2jommiXqI4ZB7qhiv2bIz6J+GF1IxEa6SwpmddmK836MbwJJADbl6pyEMlzPjS3pROwOv+TiT32ajz8YkHexcBYkluDbece/srPCYTTfuIW/8M5nMkmyxnwJe4WIb7LJiaZiINbvdo19tcpxJFQhMSKyPVunV9Z1oSVcI8QY/0UYUmL8K7/eE+WXN0HDv27MLUnJxTV5IdEF6jmq+Cyn09T9GJMfYrfk/FIoG1n+FauVSoZ+AH1PbmBOr9eLttcbjVLNQUXHma97Yofs7ahgzrjMxe9IOalN+Bb191VnvGE11HLJKTWwrmOH6oQXHTXoOpiX+kevZZxDScWGhtiFSSxaxtLU3y2iMg/Au5az4jMtzOec3n8Q2g8rBvsjuya9pAN+hZn4X2uK+m1xrgIVjTo0xa7EkznThUow+AC/B0lv1OnTTyFSl6JK7+/KAE8n4X74Bv0/YJ59mdoC0Bx/oe8WcnPdyBehNXk788OFnqlP3JkuS62HeuUx+PAoZklfwHXKo0u9KzgC5lqffaBkLrnSoJJlVeSw3cu3nPQR/FpAMMC9ecAhVuGKY+Rnk4MhoM1W3bmwiltXaVMx+QkHQwWXkrg/+XP8WNIrsop4M0G9k0xtouqco6UWbdLZV9wjao4KtAVtYyd8vAnen+0uEzrd6cqsCzawlOTBZfE6ctpRP/6UxgcayFb4b710RAVfwF748W+LYooUKL6Sc/vjukbwZTEs73BOQJAKxnME99SzOGUpoeudzIVzMaKraG0K0aLDwskQBIB+F0rUrzjP8vmiyv+MPphcyGcoIE5FrVcZtPRqhqyv+x0Hi0kJL2yFmOH8U97FmyO/yj83pr7AjuHHS/Ftno+vxdNqAx8B3w2zAwI5MQUa43RmBcqytwtmCuN6cKjyBLQ2rpbV0DwtVRx+sEd0fiUdUBn2UsoUgBM8QLtbjZTEDr4d5sADH0eBr/9ZDjEKdliw1casxPJxwg/rQUZjy0YtOkOdCdL3Qaa9WJ9FYaI/21XrygO+m6YvB9x1HESpN2JVhAE/ko78dTvwcmk6diQqbf8hPCesshZ5mr3oolp0s3FTkqkKnOTfM5l7TlYcvBYgK9Z2jHlEdxcaiwusEkr9MdwIyI/2c1kYJAIM3GeS2NgLhqKp5cWQHZ+kv2OKBut3yKYbf0hR3EP3RcaYgIGoD5SNzrbpUI+HR9CN16ydJJcmGfxu474ZSzD5DnvkNzX9ydvskFaQQSi0r8ujaDK4OYEWzYmgAmp5uAcNKztTMoCjEZJlkjX6E1MywoO3MrnVLNLqDc4uG0D7qlEMCyrAcXUdmyDpdOP3wHNkXnPBeFctd4JpkFWixv29QL0YsXTXj1qha0LFEMFRuga8AShrvFEddRL7XLXR23sg4vNEX43UfDFnfjUCWrOl/S6rBoc/UeY0fZNOTcCQPuoyIFtzGxfX9+dfnBJJtVOUR23s6ZiKnKCPDuqNe5FqETvr80t/PVOj7cncNJeywySeMxkFKZUcvyBOcOsPUmtOCSEsb9/6ZEC7VVOdYs2+6zRkQXZexz3BmZ8NtvI5MlUJgnhdSvoVcnubPF3nXUnGHz0CryOA2NYfhHYaORMwqYOJl+OzkaiD3jhzVE/9TFOPcbHMzVPjnFe1MED0CBL3J+vK60dgMpBM9CBTh9SeTEoA6Wk6esG6yIt5G7eZyHNpuZYGSFk7KtFG+oDnD5tgbcJvIDyhRUFUzAB3Ufn5o09LBc/BXh+DgRi2PfXeMFzqvpsnt33I6QCnmanzA0OpZ88e+Ls22UEfRJcu/PksmyP+o8QK0T0B7nQgN+Des7/UD1BvDtGylXEANONNcFREVk/xhllmpMRm+2VkWsxP1e8ahpTL9LjBZXUrVI03EdommFvTtgkvZmXr2E6Us2+AJUw0FyjmkKBKnEvA2YX/URx3rmw4RuezmSCNng4uacOqCk17dLUNPoe/kws3rPv3zotIIUIJp+1Wx8GVjFhc8+upDEKjpyqKIfQGK2Ndk/MdTMIg5ydONUrvhW0LfAqSufC3jYkoMBCWnkywXnuvN5tYnLewGFfYF+fdXT0my+G4bsFVqAE/SFgUzIBDyh6YBhWXTKHkNJM5IRPZqVS/evt1BjFv568Alq8rN+z0V2701BnamPe2PORZnvevAoqqCBlTPR7T20L1G/HzdAymDrty7KVM8D/q0juPqhjxjxO44T87TO7rJcevG850djbFY8U5n0EtJvqoe1wEAwMo9FpTpvYvGR+05ObvLTcxRE3qHEb1immQ8WvommHzF3MJPUmzJ9yWOoqy4L688btTa5DY/5C0fN2hMe/e6aYrOoJQ+zTRmKUOsRCZUqNbvm2DxsNHM9Uedo+bSHZ3XKnoUOBy73QqXwN/xRTEl4R9CrZeyyIYCUAR42ppxUBfqvMEmndmnosyPWnMJzXhD0RFAYXzcu9RD/lMsSKSBav/2TqsGxtA7gJgMN/v1kCvQk5CI5Yr1+HZXoMZ12OtJvGsg7+jxOHgEn00BqrR0HDVKVlu+u8cRw2wccP8maQI/yy7Lt6dyG/VXhCKrX12xzlAtIvgunErx0sNAcxXGQqDqM45imhlL7g3g4zuDYOglIdqPKYdcRTYTJ4XxhigZ+ziwIL5y5bckZnsLjYnZJGgSmtUevhw2/1Pkn0TgR5RpzZlGJQWPCffVY6gsbN9eWx2CO3QStPqtsycxsIrHDpZDiVDKCd/SWDMcVsqohCcN0i0im0YG5tNTNxJ/BEWakBatWnUgkpvPWUs4twFk/WLiiy1CmO4emPW22pQNl4QP9CHxxDrNitrJgO4OuoUMcnxJPd97npQRVI0+xW92UGVJJAStMt3ig1EwVMhj1zkTvb7jpig1zb0Cy/7aRyFx4UahBLHn14fouz8rJq3e1l1BAGNWNPqZpgmJH4cs3X9OtA7oy77fSc7AMQ8C8uPp7jAjzYkAmRyvsLLmX5HHViRPeU5fT9fKQwrVb6nFGvfzMhw7YgEF6JI1ObGXwGZ6xcayUL3n79b/W3FHTmxLP533oB49AkZbu+UiLvSsQUdXFQBvOu6Y7qIOYd6pYJAPNsQ1zPsp14vmJiEJRn1kEKo1p0zeJKJGqe7CYVSeW0IsJeLUmmxX4WKIOEq0XwTOhDFo7FDjZ87l+nagJ7T30Bc9ET9+amBeLolj47BExVdIru8xiTJQfIpLWkXuZ0/+G5dVWPFqJsJ91shTIEQt4DgGX6xTQ9NFO341iI328xBMN/TY9ndCODHV3uQa6jUdMzrfU0+p9/IdRtUTUX/59uqKqlW9oGGgxZn5VJO3GytpqBnUKv4dGWWyoBm5ErRyiH2wrxPHGVpkTYcAdBhiXmj6eOgGvvhWLDgJBD9rftGL7VsfZrPurMYlixqj90pAXnG457YtHkeZj6xgo28P2eca1BLPSb1iFnK/I7gwodaEkdPBjHzxoqbTTDmdxZgLQjUnPTljttqiKFYq60BCMmvAIlJLXDX6OX3umHJiu3P78YUD8Jd9ELg5vROE09X5ySzY56BeL4UZuVMhd2KAQrACzAaZPGX2Gh32gICN98Ji+oGMMtZ317b7b7akXF+0DekK2GCZ2UI0Sq9ZYQN7zmrHTqRhgN+2gOhhXfJ8qW1fqWsL9fnLr56YyPTjWpjcOTsm/+BzdzpsA/G/RVpWOiX+kqVEaC6fWqAZICjKWvDZsIzVxRl8bpJrsR7Y4AFGGwGEAwbznRhvxLjJGKtE4zvHAAVFKQckP7iBz/fl4Vb+DMbmhTgFq2b9ypKZA58bB7NInHbZPQzYOArkqV4gy2U9yuOrR/q4pcEUQkURacl45y69uvuw547yM99NmglkD+3xVt+lblzotxX1jCc/tViokNrYE0ynXjTQXgff0e4H2WQS2aE6WsA4D8ATWcETuGU4yaRAriSttlkWftRBanhFfho7+ly84hvG4Eni5rZkpSAjV25HmX/R38Qu0Rr/RHMa+Abp6dNVYvwJS64CU59pT7o6AYuJ4CSVrRpHFC00s9AhC+aT9nZKL4U1IjgBinggKERh0kCp0U9l5D/TtV1zdsgdJua8PCGCHKyHcsDQepgG5Ep78T45WN/VMEIDHOHTsQjKvsFzmvTbITVvP+xLFiQ+7oltIerQLAeWp7Y1EZMiBRRkufq88siGt3C1oxhH/tCXpdS8PSiiHVEDQeaCf0YjJFu710xglCjvzxoedT0vXqkPE295QQwN/hvc8AkEwLZmeavRcGVMBItGHL8ufVdm4f5fBZixmF4c+8sB/SqCLlr3Tn0SFIEsH0Ul1qzcr6roOFc4kJUOj4NliYpVsrpiEIYdYMkYdMohHIUl0VsQd2t9SyvXEPrI4CdmHLNmNqE+m0RMeDvhYBelKqQGFyZgN9EORM0J2n5ngspfudG8ca11cH3+7E+bFt1/Do+wAAA==",
	bonedragon: "data:image/webp;base64,UklGRhoQAABXRUJQVlA4IA4QAABwPgCdASqQAHAAPnUwkkYkoyGhLTYuQJAOiWkAz2uuXxn/N+B/lL+PaFWJ/s51FO7P+N61f7Xvr+WuoX7L+7T33oDzgjwD5wn43nNx/eAhQC/T3pIf+Xm2+vP/X7hP67f8z12vZj6Kv7nJ/nMTlTUts+GSfdRKTqH2H4TLy5SsoO3GeMXG1+46MewLNittewK+uClHV8kjU0YPQQofpgOs2advAUyNY5dypthHYS9dur1ApjgAm/kmpVvOe/+FBvNXxI5p1oZ7y6oKFO+Ikjmek6ULB5Ubg2E2ih7kaKb1rESl+ux/uiBJ075yVcyTB9erF1UbWAnxjUZNnZSPDLcVDDVL819LnmljAriTmqBJptUOnwYNB0yl2jhtQs5XMx/3Rmo7jGr7XhWBVx+A7RlF6aGucPwV27ZOCa2MdB0FgwMIZdkauZYxf1mwANINH4fP9/KMu8IL56I/3SdbAIyBcO+u4ZmSqDivJAOdZ6C03L7loOsyGCv1Vlm/IroJEEN3Jl4xlzpXqJniNIL15jqmz0WI1e3JBXnuPNlAP6+Cfl855gG/FBEPsXkw/INCTY3ezsJq6rauUtyTSA/IFKrGJLoIrvBZnmnEFc4CRK9DsIsjT0IqoG7MpOzJDOxfmUEHMKVFM4QbKgLustwhpvGoDZ1fxD9zLhMIrMxgAP79ZyfZzHSfdmhOgxV6383HY9y7NvyDxHzwXNDc4kauzHYz7UzYfkD1HP4X7VR/9hYf+t7HPI5Dg9EpYAaJNO6+yDu8Tt907Jrc8qPz3D1r/xphr9VuYDeDbtQ9vH/jAvihK9Cex9a2CWOqL/f/oEY7/ExXlrxQPs8KptllHzK69mf5+cHHtcStg71SbHN3JiMfUygzheYAsogh19aQv27FPEN17QkVAZwBc0u8seV22mFHj2hJ9Wja+rrosm3RM+Ofr+b4LJzyeyvvobUcKtADzMW5M1N2gPzv+wAHbbh2igClk2BUGDVvBtOJBSt6Rc8fE9sqbLlsSPAuc/CLt63IWEYH5i7PFGNwHd+QgzKqZp7sz/PAE9w+XF0V18M5HLeN5qZ6luWlMlGkggV7ahHanwcWUnK4yBrDCv5TCF0c13tSShGAndB3nvCXbBi6Ceh/3TKk2mWmV5g1KRc0eXKtHSTOaQeOng9KV1iaimEAJ6nq7hCQZUAM2ursKaneeIb4zxwBVtzJWXZxIwC2pOwgkWfzFAzNnfoup5qdvX83GT/G90zf46i1cMVZeJGBuqPgta+FwIctG5rsKTb7oN/+3SfI4C0xMTzbFy4/blqHIaoOP5INd1yeXvNg6BG+4tB3o/nc0xbe0L+7FSt6tEtU68MMv8RqKQQwJ44edYtcwOTiiVhvrmnRbNimYjwPqsmQczkgvSw5vOBX4h4Bj6XdKf8ih6SChJawK/xoE6dM7X3pkZ3N1X9PmxltKr9rur/2DFwGHRY8Vdo4vSazh3AX+46KfkaEdnr7bTPJ1s/uigW20gK2gw5pSwn4nYE7ScOc9+HYbulTXPCigMyyRShziHT14tChQLcZxGdN2BRo46Saf3/ABUcEdso3m4zOxNZ6bVf90HEY9kYBcq2N8peXk03rtySYm7xE5dEk84xy/evu1PQKTQIqWesfxPt+nVR/oakBqsF8KWpoTQq/ZwS4QCxp66vYZuSNHZEnIn6HSO/yCNDj9NWCq7o+ELy1GADKktma5pqSQXnwVPIhY9mxRO8HbHn+jyaVjjkTnqOrHiecqwzyzDUsivPR86hxjxuzDD985VgFuoIxomN+OtQAJIFF/bsr1QbieN73U1QJ6uPD66A8xCVdMXsU4splGTYx0k07qB3jdCvsCT29tHCkbEuuujxgzMDlVNxjEC1LT+wV28khHIRWGfluQfrstvtq9blOrDABzQun5oV9MZP9dn3Fu5YxH2DPtJpa9tGT0QCstM1A7qC1GGsEJYoH7WzL/DDrLf/NGDkh5eKszeDoaFTw3cmZ7QLGpb89CLki5KqiqD7Uxt51QNEuKNOExK2plfCgjcsPSmKNwkXUvjLrfzOPgxqXlBHcHcsnub83dOIv07yvQTtBZHOWepBUlkelfMW049iOkrccxY+ww33Xk0f/eFcbSoGytKoCV0c520t+ATFVsPhpUbuTAayHURmXpcxpgTOPoVRKYEmUlnrm5fYAIAB2qckpRbTuL9RARD4QGT1cRFX2qTHyxYUTqlUpm0IS0LcQi5R08AQIthLchkEsteGAyuE5EBAR2uOlWQq5P3mfuR9QrG++NXJNU3n/iMQeTKwLj5LKubTDK9M+/MEKgqAJiOhPLYAgqk4w5B4HTKPoFwFywIsnT53ygtjYeTjroALu/SsEWSWl25iC7GscVc3WSOtHRA7f/qChRnJimbKCpIYsaJZHf6xyoNAU9RWQduYquKM1gdPuK9um4l53fxCnxwWMSmlympjHPKC5pwOlJmCtT1QYgbuv/25WQPM8Udsh8t3BubghkeIb/Ygx4MLtZuAsPYekZlqslN+Zv4zU5s2nEOW7z1tT6MToPGOjaHmDB83OsvZCAmwx84V7OzcUm0osxM4fppcEX3WPxh5F7qINWoS//Egkayz38smAlEFnH/UKqAnbF2slEdkw/x47O1lMjWv90Py4vU5BMzpR/J29sdB18SlzFmRMhx5A9OEPYu0yNb0P77ZByVkz5Z9QL7wc5zbNu9uxc8IpA1rgXgaaFAmq08Nh1XcJ01G21yS8r6FJ1r/18+Pv6hBrfxZ3/mM2qA6fPz8n16zUND/sq38xdpufDdI3fcq7t369c8I//q3ATo8wbWOU3++78vuvKUKJpFNXGM8opo5/zch5k46AsKhdgUo1UWukH35c0j02MuP8kO4GpKUMzTfqEB3QtGZ3l18mQGq6xww6SZC8i+nyf/3EP5eHsCOHVYkPDS1i7WVoBXGsWfGsrZjch3L8YdtsuohJDMkHKHbALqJZAg03YY0y4FcMvLeLZMdyvumzm4Dyvemys0Yt+7PGmrwQBnYWkXgHT0YfWfsQTnNZgqfmtuhHaoTYrfgLvq69gwUCqpjsjXGt/IQYhFUtd1iVtLfVVnEUWO3POY5Ll0xWe94TYGnb4fK2vtr2mewAQXYaneXEPnd+YtsASIlGxG27deYtu0FdWoiE/CVkVsciBb12s6h8cY1dJ7qpZgrSOyzapDz9cS3Y9hAqga9lk3ew1KY5YfLlBFse74IZ3SzGsa8CqVQNgMUtj44M53cOsgmcVeKCVqCIWH41Hy6AZonJCzIMBIkReQvra1C6OI0kU1lmhBNcKLtfGVhGMFxgb9wRoX3nakKn1MjkCnbl1yxepDUavqnbveSEACL+uegf3zkkiTqSYB7UZ0MY9AO05UZl5mN96H+YqPv1HutgvVauK7S66iIULDvRLB3s6+m99JtniX3MXgHh3yfosipBKmlo0WTJyaBqqNAHYG1EmYPaEANDPi8yIpQr7sBtV3THWWUoylIc8fuMeFL6RNHoXHF3NZmSxvNZKPOs+Fiy7URgTcymopHh80gpNQmCIhN6Zguyw82t5feiuvPCA/zXQVE1TwBT9kZJ325OCDhwKVn9GwSx2877f+KemCbFknxs9D6bBViLxLzTV7qHKHr16zUcfPh1O+OM8a+17nDzUlC86NNm/sofB0DtwkMLFIYnYGG57bPqf1FAH3kDVQa9HucQRvQZ6ZqOKkDtc+alXnbMw6zWyj/C9+rakVtyjHBuZ3VPJ4FkUDwyqmLClVSgTWWC2A1V8EEAN6tGyFiuAqpAN5+U/gWApkSCKm/OWHPEMKv8CxJQ26Cap0wfppgxU+ZLOeUv22CzK3+wo4gQWojUn7WvkLSh33xrQnbvXzIoJkBwIelHO5u+NmP+MUf069Yks2e4PvGK6tpcUbacHJv2fP0NjODAkshY24FP0tWV9QodWBr/HBvTOw021Yq+QpqqQmiZ+2Ft7eHL6HO3xYsBHEltUYJ5OYHFfKJZzj55lPwUVfzAeArK6KKbMXiT0koqpunUVukDf+p9ylVintBZDaVUPBug9PYCXxrF1isqwhfxdSocHYneqi6FKtpltupnUwN3VR+0YA/09pbFX6dldz6wqf6tVD44Vd3l+oa5Qa8XhMTnwiQmsj7HEG1KJryy3ymNJPN9o7dyB3VwNcld9o5KaWDsF4hSMiQ7c1mgaoliq5biYft7NnjIfwS/9exRWLg4bt/Qokavixvr5NsH9WA1Eep0qVcvr1oRxjbmMyci+pe/PHsgWtRzfkMVJN9NzydLx8lJJdDOJ9lyPSRY9cuMli/aY5CBn3CfN2+mrrhmFY/aQpP1y/htyHJWokYIhpKrLau5u7zTuPR/RQuOd+GJMVxMkbhlN6s73zXiR0y5rakTAFk083W59prcJ6/QfT8eqIziYapY95ieBosoB1j1rKCQjxgG972w6DrNCJQqziqlYaL1V75BNbvUvkq7fB6qPdcsRFz5X6x75wwm2lYEUid0t0/HsnAS+pCk7MjBBUvflkTsp6NoA8qYUX41XOQv1g1falKto9m/xIgflzZRWFDmFY8DDIJaOmtj459tr7vua3uUxHiJtH2miGwNuoK5kp4nDX0jcPQmqZD1ga4hQJlh65y5UWZS8gyvbuzn7xvFCLAVdCpllScKWRs2v5asJr+eV2gh+GcvaJ+5Fl6LFbYcBXoJ1BBT4/i1My6GdEMzQtKOvQh7IBgkEZ4DE0GFS4gYrtYIKPzvSqunkYkEoqvrq4iWXNbkhG4JhdTPxuRNQwK2tzu1uVQrlmBR1qymzz2Mz5rRnWLbWqwcftkqhRKDegr5fwuyUwOSteY/ykPelIn5idTbV/hZs2UBj8AQ0FEAu3dqktHCUkcqDDeSuTO5DKc4bmgwqOD7gbt2v4ni9hTTqt7o0iNoLukcRxsbeewLvKSxlg7s/Bzj9oHniKxHO3HWZI2Mg1+Q4ZZwI0fim4gbmwfbeRQIILI4Ew2IrqbUQTRqVbmAiXdnDMi6IPqaB6GtG0A/rQCsoDTO1r8FRkDaTUYlswG5v54HJdBC+wFsOfJMlgRvnUwznJR6AxK+RUBg2s46gtE411Vq/c0ANh1Hgkd0WFING8dd2QXoo9r5Mg20UXmfUzZ8Qnj+lS9wh3mt0XUvKM9fs41djIkVXgYzijYnsw+JDwJwdxvGfYx80ZT6EiZKKKS2XJBJIilbgHd6Dm0uAUTloY+3CudLQGNFBgieq8I0DxkMtFHBakP+xoAesuF4nbjn80XcenCuctiNo+8tEvvlCQcCv6Z/LLWurB63jxa31+ROm/gklvrLcUR2j4tBHyXPFCsqWbEp7xxK4nkDtTv6UTtBZ9tJ0H6TsWDTHTUnlw31LZbGqWuIFJwPoS9uTUFYX8e2E4RsD8/rFseIcE2KopCc9N69lx61mAl71SpzMHT3EG8CIPFcfab0rsyZUEVXLKthRTsqhWGvm9xxTgqvRjNeJA/Q2hFiAAA=",
	boomer: "data:image/webp;base64,UklGRlwiAABXRUJQVlA4IFAiAACQdwCdASrIAMgAPnUwk0YkoyGhLRVdGJAOiWIAzYJE3r6TfufPMu7+24MKzfOj6U84npN/UnsGc//zT/tz6tHqC/v3o7dUl6LXTLeVJg0fFL854K+d76v7ncceI14J/xvXN2Y/tviI+3Pu24VQA/18/6n2tfHRNc+gqGDLg9Z9gT9G+sh/v+Sr9x9RH9hetv+8/s8/uk5R8mX3x0jX//bgEH//WJCkEnwPubDWWb9EbNNplayoJn6TwggpZk2pq+/+tSTNAEdcj07zaj7M84qsHyWoYFy9BbpvmhoW+e8Chfi9rq2c7O9q79JaycC6lEnRicVtYd/Mww+8wyA/TKeOxMMcz2tvSMl/oh89xMEWiKF5HwyCU1rdwMnw9k2Bzu1YC58jKjMp/8mMUxNRVb5zbYfscEn9x1h7/82RKKV+Mgtqsi2Am8+kMrH5MKnwAqnHLiR/W4KLn7ZVVn6D/3XfxtUzQihXihZFP2H+XjbqRKGuf9FQhHbdu/OdJ6OGm9Z4P8yTOJXKK2nkYbaLbs/fU+Miw4t9fbrKVu5UYCJuE85Be06PNeq1GmPQ/VU1PYk/K7SyuAWMgi39G7J5yjg32Ss1hjRN55lJBpBwzg1NqAecSQWvMiPIqCCfV/bxZc7jeqhSJaG7tBvgaWYGwuw/6CRDJL5HD1BqUIkxj4rJrrR98eyeEiRdrriWx1tiJq1nT0BEmUpEzICSdxr0UX+A/gVtdTI/KyJzaCyRPGlk98prCwSmgNgCpuVYp9evcVJkW+u0HhYj6KpgJNTiyvptzSx1mN8uy2jRL57cYIgbptD/v/IZH9vZHJhT8Qc/YpvU2NfuHES5LJPLEuiDXsk5nrLq/Ydh1CNsJxckox4JJY9ljRT0CSPonpzeDJVmaHFOO4ePliDnyMggrTqYPvR73wtM7lYrbgBjYKH8+URaQe6xnTf5tpY61eKahQZUtUxlTlWzPgmRP57/bNwquytdHHdc6snXpqUYu9lt57JWJhFV7/9ovgSanfkpMxBTwnPqieQBmdEl85cgLObTQoUqcNThUesaEThJFGNQc71QbkvWjanCmSWGb6HfZ4Zi9TWMdAq3wcqHqMrafyIc7oG0dKvaJ5g53OxB0KkFgU5/PehEDKh+igR/cUagYgqf6mDCVtOlrxGYIkHvG3NbBBudUNcSGNheWCaPJgDBZDBtvqO6CcmxE27K07GM+AIw6ooVCH61gYw0m4ZZTR1zSDLFG8tp/5HVrGh8W//N88Ezb6BSVblSp/9ax36rBIO0N4gqXuWjAAD+/lXQFhotSCEnv8L3/cmQAiVTfeDPk73aLfgmRH+e+HyOF/hEtHDNh4DUV26h/acrrIrNoTrJin9NhYSDhV0WX3cXdPqWBy6+Cf25dSiSrBtL1r5uN5ZVfXQ279xUEafFm0X80o9X/vxU7T3uiDawAe60qgqBP4kDt5juZzWBB2eCj1ftBGD4Rrco6Z2ZSbRXR7/3ZWeTjSCJP9G9h5rLdMqH5FIJhrSbvv2joavFbiZu00fgxCPbJ1pkyJ69JX1K+vnA7e0njt9GRqJF5yyDiPimY8TEsXZgu0vb/aQ+2V59vZDueSDqqkEG3tfVI60UVWQ9xE2XnwN0lum/92XifQ7yMOF0m/eHkHYCFbmjOfvKgBDAuZBZRjJzwdzxfAJhFsWvfq1bibiCCLRINiWbWs84DwtzfGJDfeokNcjMIccOCyPvLZ3rVoCK6J2wl7dag6pXBb/4M8BM0dU9/WkQMYLUL+lRr5xAuPXKNoQPVpQuaeLh+ldqVrs1efu1HimseN+vIJWpjz5c3GpLWRmadkTktfI0yIgACgtCYqP1RZg2vyA0O4ZL9SLnnX/Sj8ecP80RzbI45rt9SKfCA+GpdefDM+CXnrTLZUV6QZYwf4a5am10+0LqN1BR6EBPE2oN41lnWGS9zwXtc0RTXeE6o1lXch5YMYzm7KI24KnFrajVhSWSTLKVDf37Mea/slDpCirASgHzjMcaoCuODX6wqxs8AYSoZI2J2Lra8dTqURQWBC7A1vfXIsi3+NgkS/DocZVAkhiMymeM/ub4M6333iXDDCdsx19lDpeN3Xy3IwSIHybEHrakhUSO4QPkzyuBYr+2b0HbLGVznbU4ckJc1Zcc3AC7/Zf7d1kfDxOqaKAEBY3Ki1k9rhG44PpfKJYj69jg8j77M5qDY7KKyprKJSj9YG91zkdiEFcUndDrOAjtP3ATlCryU2Yx090LTNkpGxl1DKA39Ujad3wI4XvznC6pPCHxfebVlyGJCJrX1YJt85aAoxvP0sEGEjtREaVCPX1EZxo0ve25Kvu8Zvxs9KC1pzfn8LneQmGjcN9MLSbMlsrA4CMmHEE7bzhDNz3forLIYm+JGUU69dq/ZizLVY8j0ignLy7AcIJiq1qnxoFofReyCWjoWCeSljM8iQy7lxOgTFASWyk7mqdZ/5FfVneu9Kz3oV/UeX/tCu9gkIR6ePnp03zXP0+b+SixkQQD/5a1ae7mGeACUhUSjHKLH7lKdoS2P5Fjjj/S/k4kJFx+rDygPAIbdZTjN3s4Tgg0T+0qsHoPcjr7Rb2k6bCxJ9bcWZW558iz1qgaSbol900IA5Rf1G4G0eV4So1iL4nnrYsczPtFWQq+/UZDk6f2gFh1b60+8KRCCqclK4dPE6cz5HgF/jf45BDZOOj6OeQ7b+3iDz4PnKhEiJjSWf+mk0346uPf8EXe8GPY7MhQvnXOdZe8DjkZfSx4AOmGPGUq1Ve6N2go2dCgrID9X3gpMd484I6GFgJSw7Wh4rWbGtTPkw8ZRiJMoZLRWW7VMZmPWFH5GkQMSWsCO0ZTDE/Zx7yqJ8evqv36vaph1RMWX4mVIgOZqsOy/THq8nVp+kHCvOKvpt13LyJELLXcXQiIkWxxjNfvPAnJ84EVjoKR9amtelqUzSgP1USbv5IwyGMA8xlM6gXGRWZjVQ73p5FB+v+bcerY5M/7Ac85WefcDU6EIRg+jZmnGQZpwee9RdPaX6Wh0fffQrtVFiCsNYaus1IdBZD2i1rXfoNVTyQBFrtCy3HppvmJz7nf1K4LxtQWidKx2oSsDsUNuh1iYmj8ky4Lzv1RjGanHLhvYEH+VqQhnvZhohafQuhAwMFXz+55XLZdY/icB2Q8KJpfCNk6pvR6Kw70ku9+lG0z+kAjvIqfmJE9zoAklyYHOV3H69I1ZHlgGcqx7tg2hDEJe8jc6l6ehEPqg+seiAxRQLGAerZwsPfZoczKcw/8sni+Pt92i8GV373QkQAlLqZ4HlEVorZCf7pDQduMrdzmbHMRw52YwZM49c5yc8l2frRj2d/twzJQdkZoTk6hucd5kMkZfxFTFlXfbB8iPgzjlTJEueruunLvVTANy658sGMPLsBo8efmqnVIJFLACryIxxvFQKCXcglrKysVqj+fu0OOFYGl9UxxMRZRdix8qopyNgyfphOiosNbaBgYMKuQM+GkJD+PzNb3ce70vQZrQiwAoxTMizIkQb+x0v3SIv1TNAbtoj+C9bIhx6IK1rh+keQjCs/RrVZfSYzbVOJG8jau+XWMHFwaLtErLTwyS4VDmP0tVxhj/4hLr6MINAYVk+FSKggKgoYv9MPNrn1Z07FadKYOICoJSo/x5mvObhn3VoSMkGYBYaTAzXmqAHVwJ6Za18dEkNPY57hFNKTYukFBjlQQC8Pl9HVokR8qgRLF3th1MJUdTIQ+fMDxFuwYYBKZCC+KMzIDBdSXQRjdDK4eN7i5IJr9cZkXvKCT38gGVTCgqXM8rd2xM1MnQfSJDDTtCKKNi3vICbEIch/OC2h+2SiiYqS6x19v3pkemWi1hjztQ1lcdTzFHTtNX8kZQHIy/BfnxRmICQiP0ZOUSa4ikv/488hRo4f0oDoDmMTwrmrER/2CO5MvrZXJl15+BmKqGjw8r2PGVmpM2CbLvvhAwPfqBGqYS9qORuoAtpGApHbxJn3tEzj3FlGF8PJzK8tcaUEEPdA9J9BUXWBd3szJPK6BqJoYeyaiRIC6CI7EFAbVpesfl3Plj1H2EvB9xQ2QvE30UtJQVi9X5PY3cgkb2WcrT6diOVsFBWai1uanFjzErM77L62/zeEV5YhRZnI2I2fvQ1gjgYk5JzYCRzU7Pqq1TiM51DQqBB6gpsnWzYymN/ardhDIYAwES7BMYp9UsHuS+fnr/WxCnbYIgweUMooijbgON1rSEBmk+YKbGyHTpQq6gAHY3Qm3nwGdSZGWs5bjvsNm1Wt+EytXN3Cfa9ooFGuBdx/ki4+K0r5v9kixCXTSypZwROcWVxe3W/T5E/kBSNP46pVnP3si2290w0Ry1+ExydORYlrS3AUlQYqihnpHsJmubXs4D12+PNrOHh8bO3orRFtNmKLEv4JbrEa0hT2wMAfo8ZOZokmBBlDsqYLdmRW7p+4b1gSgl7kvIcEu7wu8FQi96h1Xin3p8hiIMr2BTe4Aqykegw/QYBaAb1z9tMTVtaiyN/eyhuwRE8UzcuXimcYy1nw2FyeFmowE2sMFLYbZPFSFiMTT8JogCHAOZ3904u3vO7mkq5sQqcfkQkxSVVSrDe7IhEbgIyDebXG2YEcXPDcWxKOeeW9MUfLX8ZkBfhS0uKqL37fUG/mxgOKbj4xElasVAieRo4TnLZKu0HOo1kt76FyUhBKacW2+k+5VZC4imIjflRYEojSO8Qc0esk9+oRWxOPsfnxoQ441EOAoqR8HpNMKlBeLlSkDWOLNQdCTmsSE3OPHaXZw2qcY6G5hajU+1bKpjMmOq/Rpc2/UEyLomORl8l2i1ouM8c2L7URunlfRAnbHU4bzjp3ezVKAeBmD5lFpipbOX5XS5euDxKzU2OJYceFxDQdR4DySkFsKTDrD0kC7Xmwv55cR8va4kGZnuPFdkUaW8/ZjvVUHI8pu//Aezo23GPTsm6lY+ucVwG/p+xvc6XaHYUGNlizW1Jenzy3I5WtHhTpZE7LB7t7lsPcwyNTIz7ai6GSZjJxqgBREKE21ZXQUzf3Z0D/QVx84Q/iQIGUzLvvlUxCdmctREsKEXqXxHvZebLRP7YzURlj8xqqUU1LKReHctLZdtwY+fjQb1m5xFdMVPaKZad++WOhsjd6/zeMnpJ+VSazSHkaXfHJYcb1tcgJSKadBIwyIRDhnIF4v9CSidNVvLFuFHYquDC8seQmKnZAdD0N5MrdBn9k9GzlLVHGHB+c1CsiB5HDTy0eaCyWnTLkZrs6L9p3x30ZBdTo5YO5yPYI/myqdLiZkWUREN1e5nkw7XNboZ6B5g8/XdVRiBVpYw8Ks61/v9hfXPyiogvIudTRkA4f89Tl8eXyGV0jQu1fCNiyOv6la43octLyXGZgCcOqbZRjOuisN7U3ZCY1BJxtcPrZl4+rfFVWp+5iX+5mte9ViWpOiOp6XE0WNyUj+Ro5upQtFMPjgt/UHYfmKLRW8f8dJDga1eI+HnVV5bXs7Z2i2MvztdY6ue/SOBQc5iJ6S9eVkx87qIOSkqZBffB69U1CHaXqdXyTLXwZuXJSn1jcpZCLE5Ru47V7nS14RaAkx6jYia8213+L15AN0weIxxrp492Nka9E7FLGhbeaZojCmduD+BxTRj0h6fxlxVU7aqacNScRWZrdpe+4YSBlnbJ8rK8FbcstyZSsBIpF71E+eo4u7efz0H2VKpR9x8pl87ClZk6R3P5qzO+zLvx/LrT4WJaVVJ7Wx1LsiE2uVuO1L2woseJNegiE70xS6bP6BUPLCrLhUK01mh0n0MmFzqUduOM/Cl6mSxUYyPzppCejHwsKZU4Pkc8gsg+zqGQ9b/ZHS9sZB50VbVQSlbvHilQl6ofYJZg3Zx/U9So9xh0MOE6xACJ/4ReQJoCn1a8p6ptBTYbbXkg/EsIe/I/m47/rr9spjnO/qZTN+C30L36ZW7NuNDxvGNuADg2oVpS1DSpfyN4Lt+rhhDKNO3d49MMSQQ58tDAusr41VKJYwJ3PJHnG1AD0iGryejECw9qCcu3L8/3f6ZDXTgVtm/MJyLQnhy4PIcFfHOaUBG3jNZIgVUe2Jz9XN8b+zOFuo7lmT8niDDRtsAGTb+PqJtOVjNJnNJK3H+u/uzcuCGHKp6pCUCpo6OHpqMK0qayQrfc4IiovJ6WbjZX7VsY6/+6vsrw6p5EE0RN1YnpGlH4AoWnNspcTcMfqGoGC8SMa7+hVtiyTHMvEz9rBAJEPTrKmUPVMN9RgttIntzikA4phS053icpYzf8WbbOEtxZmlAmZDhAoFi9AW64876mvYk2vK4jAsMxlMqkGxOJFOBGHfXHbUuUYbh2XzTdqFAh7DfBRDBmBOwZiAfiseHdxnosSgyZXHzmNcTh1CA28mZGRyX0fK91WA0Ubu34ABI+afIYYQzROAvsw7Xan0tXVJJgXYbOOEbFP7zoNLFxaOpSKNlUBxz75toFfrwvp8dzHOU2fMRamPPkapY9OG1zuEEteTw8vNAIscwUKE7WdAxwN8wtgb7jx5rWWwyw/J4so0D7d09tzmWFRxsvGT2X5CCYERfGEb2swflCQ71/ntY9lQUEEkp5f2I2JNfu7O+kP4xlW+d5J4tR2IijaEXjaxpHxPBqXXtouzJxafdL8bPA08bSptLS7/YeXZeTmV4M2RbdSbxM845QeAuUgnN4NRDgz/cHmaq+olTMsD9OWg1EuI2FhiMTgmDJijkslnz69R0M6InlQW+D/toOp8BEYijj871dwYyUuGGnuhucp+fVaeft6UbsLhYc1u7gKzR9oSbuEptcr/BcK79PA75dcA4F1JGO+tDGQyg+2K/lSIRO/53GcfHCxLCXBgArf6f9NMP7Abu+H+f1UL1v04tzeBnUOhzTO07GMhr4QK/uyWPNSLbITzuGXntSVG/hWS1LTDv83eAxHMKJtsT3+CVqMZZKtaKhX5T6Luq4IVq/q0Kzj+1jvmaCFA2MfYNeT0JobjYbMrcurOofCFkwsQAbB97Ra0ejI/Q/RnksHFjoTKn45VJQl+08lgVvt6l7DF2i/e7fyxoQ04yu3nTeWpvVh/OfH6fQih2BruIIlRIFcR5lKGLzxZDRK2Jab9PogFgQ5Vd08J95kVomfCrE6GRZRt1KWrFAn2Cr8Wim55L8EOF2QSKQJ+zLotSxfsqXnYEoEepS+BQfmDRUoHtjJ0u92eBPqrH/B/MzB/N63vPjBmkE+NKX5XT7zaLI8pvN82kn8RvknH2EWT/x59yCt45mmOOtMCqy6n2Vj0vwzrf8ZUPU/Hja+lg/DErfD7WPd175i9LzTlXig+ptKWQBP3vRYXszBKA+3bsAFkhmhhTqWB/v02mBReYut9BWmkVYopsPH9Un+xgE/E73UOQOxnX9jFabVGw+K04Z7d+8mOKAeEw/cZUOcOkxZHY3C9NHfb/YhOr57QyjRBZjn7HDSPxhQ8XDnxptyreINJXMSr4PH99MZndMTguOoL8dMXmF6m3CsAKbn9iapPlkGzpVqN5A3qKoN0AegPRw2306VcIy2k9FWKLxUBMyQFLAWGHCi1LvNAod9VGko8eLmBikVzSTb8DaBzQrqiwkfBF7L/jDOwVCYIh61J/pLTyPy50Ij9b5jn4JxTG4EAyan60Or6+osvWChRKQG45Ew+qqXUO9sLR7EyZk+P2hiPXPgV2tZEECzNvjllMyCXCWh1WsEu1LBpWHYjTxme0V0tTbkd9VR8c4PQZk1GlDX+gjYKz1axxe6tHwlmVXa909oroykOV2ThEi1FzWQf0eOfKD9oH1NhO0QF0pDqDtjUWiQ///FjbFcXDx8pDJi5232Cs+446LWw6LqvXVm5/opws46krvEjI4bo49hYhTQcuuijv+DcHxuNKSrEtHGAWTXzzmAQ866aJl0a2sSLEu1Jo1wSyFha2GA1JsZpKNT7L2hhKmxSMP4KGXXQhcVr/h5r4/5xp24FbrUEvYFVkNU/aqFbtEs6mMid2xL+vsRNHX2EJF+ZceR73ZB46kEP96WFGY6byK3GEqZ4JBP/Vn7BoOJlYJh6QfgkchjARufFvtTIy615u4Gxe5d63PaolAoKQ1HV8oN6A32jdeJ6ZVaDXTe+Jtq+nCxQxVGIH9UWjHPA0Gg9Hyx1rUpjVj4VUq1rn3jGyVtg/wS+e8O49A/tPHEZxZV8yRpAtcSZq6Q1ukFUzVV/O5XYlnDgkNyZ28sE2CzyOnZvmCr7ovLb4yq18wUeEWqsLN0fMRqMc844eiqfFk7aIPcVXERtPIrZf+3ZzR9mYgbYTnlmqvkiUo3XjkVEA+UXUDheCtzEMgCywgFvJLt/Dw6MklVK6NPYOvMpIp5QxRAqwLHyLP4HRQlm9Oro1jg8B1PmBRk5i9uaezpQ4ohkvdrwopzwHak4tZ/o/1Aj/a+wIE5zlK1pl/ifn5+sey5nD8cR8owO9yvC4dAMShyJFuHTgLYaQFX9Y2MGVogzOCFopmbUa2gDi8YQMJBhY/WBf9ndmu3MW3emqapXpTUTKz+V3O3XuptR25INq86u4RqzIOiMNvxeW/YdDpDCfynstMraYOsv7pL6yxtpxkf1z2QUyeZQ/dKga3jo1IfXhmZcTPxaDB5NoDw9SthIrS8XXaMTP19SKKMkC+RgViatHyEEdnYMHxcDqIYduKulNbLGikzsNGpF+zZj6LmzKuF7WxRZDgMSr03e1GP+TqNTERlS47K5/7HFRvL3jOZ5XmLw+Exd8hgYNGTkRs7trrDo4odmL2zgEHG4tRDHMbUe0Qs9L0OyulMzX3B9oa/vSrJda0rj945bMoTvcy/+HIeIYsmZRKu/W771QDu9GvmlbmHkAS5K3oy3NpSOYKFnzOMlvZet2jHO/W1KUPDWiiIJxuCTaEfhVZzDcri5R6o9RYW72ravTfb5SVu846D3eMbi0USM9qTvZ9eBpHfqPe319MYLLH+G8mne7O3zBpczoNjw3ov1qCi2JTI5t/n/xSL5drmkIyfp/jioRhbSQvO3BddVuC3W0V1foGTXrWm7xC1dnwMc0ai2YxP3OXRJgCSWpx7Kvl6cfvbbtkqIpEbwjj3Po3xxNNjCW1wGOIhOq25R+sBXAmLKALN1Xomurm13fxrA9T7ZfhxRioyh+RNjQYjXGql4U1QeMJpRNIbbIvLloQyauit0BwtHUq2TBOkoq/LPShriA2eibumtZF1sHWBlCVZ0xpQ2NmCYh5Mao7GjeQINA1Su0aK9mQxtiSLX24IaQRx6p/yvH8cK2gUtgGSYL9SF1IJXaRwMwhelaz+G4SO+d7/TZALL/shOSZ9AuaGWM9o0Qu68KQqhgV4usXMvXDz2lXK/QGhDPq1dXeboZSapYTfyHoRkmZi5sBVWuXpZJnv9AySVgW4I9h1UEUVwKNQa7pOfqIKn++DoBrl4+hDka/W/4Vh98U9tVDC2awtfRA28uso85fXird1TX7l8Fzn/tSj3vjJLGAJZRzWYsnxeaUnjxzGXmFbENXy9a5RnsG77qUfJ9SGpsIKh7Kpgg571dqgzoMcr+jMO4DCC6XpnYhV1wDG+6q9nrj8qCs9+0NquDJjRAmsW4ylPPJw50XcQgPKdSbg/Xorw+EsZKohgEUD/VnQ6eDl0dMI48Id9B/7KO7DvRb44vVyeW5EwDbLcikrBHSw9qMSJofwKzp0HNuzfnnY4GWSEVkOBcIhZTW0FB3gatQOiffSJEO1gt2BOV5DYeJsOYG1+bJjg6ebImelmm/Z1Xc55bw13dmQTExaVT7y1QbBdSJiQIh2bKE6P/qyToP54CzyeVNIDTThqTf2EbiR5ny9QvEzEJRuYDSSUfDyaO/kyutsrIF80HJzQCHyBWL0LGGCadNYW2DbJHZvhfTjkU+uxiBgQDMk1RkvJez2i8hsr8NJTiPTnP9sQaL6KCe1Y52mSdGDCeGsxgfOsJHI6r8oOMR9FP1aGP5eHXUVXJ35gh12vw2Ty429GlbLoKp9tw+bgUZ5VjkW21XGef+LgomisbvGfa6CYQGtZKsfgVsfQmCjn1oSy4SJ2F52c1BNMCPRJ+qAQAPe7weILM3tUUeKjx9sDE7RC8TYMmLqZ4Ka1uWFXWYJYdKbeN55ijm2ObHPKC1xzK8RaPxzAYvWO1p4nb+S3D3FU96sBluT1sHrvDZ89nvc9wOQnteZ8JeoOcUrlysvbhDeBs+nfbZMW2COhzUJ8qAFw0e/XQ165vjqAG97r3JKr14WpJiy9v6QqbE2szQhuLuJZgRdk3JbepT4CTZwfafJB7I5doC09Ouzn0qjCFSVQrfE0H6j81B7HGd7vLgz+vn0BkANQHRGAh4CsnX9Zoyb9m3j3Nwb1XHY1M+P/zTcQt9RKd8P7EC9z149WKDVA7PC+gozH7euGeF7xaYBL/AXgwjIzueZy2seJQ5lO8JIj8pHcjiNupfe2jkvYBD9rHmQdA1CL687Nq2VDc/ExSTBqeynd78xrZhgjcILkyg56/JYKrYiDMywQ/n1tkMid5MI5IlQ3qtVCQVQMlgOskRkp2uzBwN/ovd8aKgQAgBQutRnNX3BWAv02X9k/PGeFDSvOSXTpcP95tp/ixDAlcUw6Q/9IG+0IfxOlOkxadujDaeVTuDdel/dDJdBd8BI8s45ILV3GbigzDmP/ryyl5/jnafWAomTrIYAAGRgLH95PGzRvxR//jo7xVRi8oLpI0Bk06wCo4BfRCy8Tjfub7d57Hs8gILwjKRb4U5YMPURLqLguej3WS9gH14AAuJ1NOQsVEhTml/O8tzbhjgy8mGYtCShiwz2OPxz3bAz7PfmeESn4F/R84U7qq9f0mrRDKqiEvMe+T41ChON7TLxSinL6vyTXbFCpx0p91o39oufh74Vx+8y//Zfh+t4vii+OxcmRYaaMdwFDolIFj4AYaIDByL/JhLf0t1ukmChWbBK92Ax8ZlknWM29UiVm4aT7Oi4xWi/D/sqb82UkWWVQq4BQycd1zhQbWbGSmgDP+HEcfX7eYVsXWHgpImyXjsHBL5vuS2Kel6bnd9iDWjAjuxJK1eLaQMWv7L3poVSceEJbsR5AbIBbwyFc+r9f3FilZwOxuFz0j9egoqfh3t5/sOrAP3g2edmjlME0JrDjtQ/0/pqTqcjbP2Q1PDgp/MaRzdrMeRVpkqrdeq0bcQEuePCzKIPjKaZo5JT/myHvw99qQCisQBKE6VutxLm3zNLPMhgEH8qB8dcvF763dMX/Ywh4JuY80fX+cqUDubcyGZiqD1TMJislxSskHQFF6qG98e1OBA31p/oTTBrko9EvX4/6rf5+qNuAGiwcrHnL558XMi4mhsbS8lc+9l41U5SAI10WcAAAGL0yNPbqSJgB4eBmHHd6vabLZP644jSdPZBAg+UlZ7EmkCE8cWh0m83tmlsVaQMV33CyXeDHtYx09GBOj+H+dYwWBwFUMKBMNArnlR/w4Zkf5bZFkMmkrCuS+s5H/8g2YSO/aum9uXXMCwj5YNxtwPH06snP5dCIRYDxs2r774RX/4a/MHZRGeC+rIvQR2N543DeoYP7xPEl0NwzBw+8zo3bcuDlsslh7IwDHK9mQ84rAcrwHMFqyDcxaIceZ23005N5fEFqZ/bAiFl/RzuBQMxwpXS5l9ldueAYr8uGmBQQ3R0+BPL75IIKWDaJjHD5Sduh4IgdycXXHIbTeVvz1hYMZATL5wWDy2EM8omBn99V1yQAAETwAAAAAAA=",
	claygolem: "data:image/webp;base64,UklGRqwPAABXRUJQVlA4IKAPAABwPwCdASqQAHAAPnUwkkckoqGhLDK+wJAOiWkA0juwDwc/F/jl5p+S/4BIyb8dRHuT/i+b3/H8M/k7qHflX9b88qBZ0+oE/S/714IWsN4i6QvBroC/pj0gdEn1z/7vcK/Xb/l9kD0a/2qUD/4Ge1nGGJYoUVMJvAubDOY1Qjpe0QkkxVjAn3J4rvfjntbk3K6EqS9J5LLeEvOTQ8aVIqdOrGZlTmg3x+ZVlee8AIatAnqSNuqWpTyCLdAqvwor3DeqmOM1c6M675lsXETfBB6K7TLCtXolI6L/SuMUJs3gh9af7elQ6spY8+hAfyr6ehOI6IXcTAQ6G2I248PHJPNFwgNqKe58ZyWCYi8HBQpPUHkEos+R4olY0Kmi5JqHfMo4weggX9cFOF+XPr9nl7tVnMmZfjTcDs8038DgkKJYS0IbFKDUOZR5DZqQjdNWKuVhaAZw3ymrOHHory5BXcyZgq68VcasYu2YIXHftCXpT81rw683h6YzVNJwH39q5TGdOM9JsUU8m8iQhNXHxf0Y0Q/wKsPCLmf1me335mxp+amJEfT+dmrWKH2CIWLvb7f4ljqjIwFJ39Tf49/oFXwioLpS+rz36ZHDhFOk7NDfzElpramf6DTJK3S58foHWXCIHxnO8itkS1epcdHcerTKF25yDj3nWuKr5fXoX11kB286gAAA/v1XL2cwhhoV8SKYoP8/8q/IT8qy9mQ0ffJv8Nuk04//tvFnQzwfJLCnBVmY8Ugk4vxXL1t1SiNHrphoX38vjXuzm3/19Ugp7ZPSDvcJ0LVH/jjW6cjUBoUVf8gDDfHyLfqlwhB7a7J2enu9N6V5T8a+D4fhBp79pTsuTz4KoPwIau5SmWDFGGWQcI+HRBz+OAEhoKIlvOFOom0xBK3zz4lTsfJbY4KDQg84u3w5h1OqAK40fWcNpxvSj/2Gl0dy8a2vxeNeiw87bYeRPyOJifIPiiFryoGWkgvB8IhajoIkeO/jfw6S+lCc5oxvuxH/eD9AtCTY8hfjttysai5s36qbotbAWknKecxnE6jQmYVtDE4RYIxX1IazGCScfVT84mASz2N6dyZUR/EM+PTDBHqayXbcBuPzkC+pBErEz+T2347KFo3WGnhpvzV47V5OMQRDqagYAYLxhnNHEUpYsdtdZm2rUhyGtt/zeC7O25DkDMv9DD/hSCdbBslkMHhJZQyJrnijiLRAVgnGFpSGSqk60ik40sDdsng8qaNSFIaQCqNAef5DxmdYf/awXXjq730lYDi89SRgIr/NZUb66NCZH2E8AQxndcUtYg6sdbfNKzspUd/DXN5PK2Qj0aXCyv3chNozmbMRNppTnC/qX1jfN/v1dG7ddAKhIoKmBtjAG/vFf7jKNGSvA9Ej2MKBGJT++2p8A1FlnAGim/FhvXEovFBOliuWW4DFpDXWHbM/8j0DaENByIBWLTGrbo0NkNQ7fgdojlv8LgOgOaSnExRvs4Au5VVf75NsrYNR75Rw/3XYOwipYjGLsyYmEBOUwsBZGkxSIfqFI6+uixD5VZLv7f2M5THsaT8j/qXcv8g+2puODv3JRSUFtyt2fO4FBiIb4jbrOwV6wKd2zPbOXyzxrsUBcr+XcOSZQtswwTmTxXHkB681HlKZuUhH5M8PmyfaD12hDOBTLjj6CY1XGMhkQ0vgs14nNlxIbPs86cVKBOQ9vd/wrzik/riw27QXW0SabRjHekmeJIwZMOKPKECpHVj8zFJX1MNOTFAEMEHIsl1T0GE1mhE94inLWU6/KBgtTg45x4wdKfBy6DRTrCkO3txXRqVQo6tB/djS4eWfaPGFi8Btg1e/v0d6tHfeUIcy0X+NMJp//Hvrc1Uvx3VfXyps+iwxIF93Q4q426J7NFGpCUgKyF9pZMqaCJObt8YZkMEvzDjnJ3YaJdB9wO7GAj7qtoQ4xM51tx6bSuiwbuoV6NjyRNCuB9Xdztkne1NnJO1BTlz1JVhx62kAVF9IiXnpuS5XS9S/o8MOxB/Dc9ZUT5vfc2ewX6iPWLLCtmjvfom2EJNtWYVTD/7Mg+1o8SX53fOsZGzOwkDjUmAz/lPl2QmdtDsKGT4jgzoobKuut6sG+8lv0mxgZusNUwwjcFCwwO3wcrftdkW7+1vZiSw6/vtNu5hbFyPxKknf2pupgd9BfbHCPqcgzo1QH4/tZu1FY6k7axZC+cxugaKPsWN7fTuB4ML712jWdY04u+wB3sNW91kGfU5s8zQNztcAWZOn6bSr2FXoJv7G//6LkByz4ZNwErpWdPgleheLnJZqtl/XDmGhiTS3c9MsqO0PeB5Gt54TpO9oMuiPC1Rcw2YdeAL9JVynlRjqJrOb89BF9lqDkDF42lvd4OVbnMC6SX+Fa0HFwnGm4h4n3i5A1Cifk6TSn6E9wlKo/b+0ya8M84vRND1jRJb4VstfYYmq9Q4LwQxqEOGxRVOxdKhEftiY+oRnb1+1i895xfNE1XAdntJ+IOoz1I4SFn8zlt81fzgvoOfP8aK65vJk0PPjhnFvvdpizeCtl2O9otqoRg4EyOgcYqB/sxW3Nl/Q0DoXkiDHO4jZY46iSp4RbQ5xIsCrLzk3V9VhiUSSLS89aQC/EbevnAZ4yiJInzY/sfMnjcSLrKQBGs8BaaVhFh8/pi1rALxnzjLZFa7iEQvDZ7iAvTfYllbMgTI7irOpqNI4SngRJAjXwDCsXlU0/8/Z4TDhtt5fnuMyMqRFOn61r0oHIyVqslcJQqdmGX30Iqb7sXXenfYf4W8jTOSL/aDWAp8LiJs9OnRG4dljtPtZmt/goIl2jv6C8Qo7lCOOlHzxCE274qLtbWBRyRA28rvQWjGoeUZNfBRSFwu0xB1VtcrgQ5AkN03xjkgKhPUryNqbYMtWEO2Rtry15gYK26WcVSnabtrl/d1YrS9TuCO0Wqae9P3Gj0f4pw0QVnWDHZdbcHPbzAij4yAI7tqMfo9nbNh2EI6hEzipNvK6d0eogcCDWfqovZ5T4Bpc/Bmtzx9eJozv7Xcr9tZTfD29hrERGkqPFxEaK/3fc+pehmOl1Xxzjp74qdI/0jr/8+aQ6GiOjs0DnkFcVEC94yhcsbQh2mJVAwtwQuvhUSG4XuhswRiv0Bo1dAtgzW/9dCk2blisKn6GqCn9mnqarV60qtmNkEzXl7T6nOJ1Jl459PTEnALHhJy2oOwBZiN9VBEYA+mIqN1eIB9MKXbtePOPuxgfFKEGLE8Y4f2cXMrjeoF4Ot0Kuxini0iQEjaA4TMbxTF7U29wA+Q/3jU4mV1BnpzC/BqQmLZFpKKBtFQ857nVrSDBodyUU6WUBV+egFuhCbP88VGbUY1zxxH7OnMizQNvSXZDNbLfJBrPFr0NWp5yZigQzU8zLtHiwvFxp238Iy4yxYlLFemAt1+lUoLmdxqj7KYJpTyc+/05seWttOnYHc88dnp+WXuUs0YfKHnShNfCALEtujsXDsl4HAZ6jjs8jy0TeZ3+ua5fh8LGdsSPf3T83Jro+7qPBJNLVv6GZ4QKZ4yO/geiI5BVmWGEkkGhkDiOiK6WxRIe4zPyJUDI7Y6tlKRJmZ11iWfp/BJ/3MBPbxnlrClwVc6ApLcQBkpOOnOQGHIAct3+ryNxuqf+hpSif6o+oq+yBREhW4e8TnPQ9h+HNArJJ3xwMFmq3pUcyb42fbfAIkghMhHwElR3I0sqqERo2aiy59TiK403wFDCcIY/c5epLHHRCqiCqMkD23ZYARebsiLbifbTbcHbUhPWDFPY44QDLn4rS8YGu2/mB5HAkOvSLKL8pmq8hfMZTqeRBo3gJN1iQhgzzMQqlKp1zuEtE8nTCwwCwcXphagGuB3MY6roOtD0Ku8AhDLmd8W240uPZrnqZkJ7td73h/p3/nRnc1LgqNeJTz6R3Q2a/NjwUz3YqkjS34wJppj/Hh0+cRhTZIR4iTZxPeLwSCBBKqzNyGa/X7x1qMReRCjmtjpbPEkWj5mLBV1PnP35EUFIva3tCok7Som0ZsQvz9klY3QAAOQNmjMKFp5RnH+/tKTEJerTTkw7R1bjyofa1hfz333lnM9RoYZQxnR67V1PHUHv0y4SeIjMFxEUpagHoH8h5N9+cbBazK6PC0G24kkKZ+QpvL7ma2FDFofRsscjoqGsY5c3LgWePfN2fZIgfrdNOn9qFvJUN15+J6yCHbVfWIhIKWxFV6ASVYKJ0PrS+3rRkCM7/Bir7CBOP68FYDlSIezJNNbBpCYcfbr9ifmhj8AUjsQdjIQvAveACXrMphBypmKx4n03d8K5VhjZk2BugAg/oVBMgDXz6jYkEmvRwLRF4JXHn/o885B2I62ikPDKYLje8Gh3Pl7tZKtgGhlqLvZO0SQmWgKjlZIj+aaQ8XoYlyL/cPfvufay9WyufL4vW9g9iv5ly10vIMdYH/daHZEW5uBXdcN7DCSeUQ3YhJvNQh1BGjbNB0Urb+TRiHJqMvqGhlVUfbTtBrejY4aoV4Z68plK6k4DVIccXFYUVEuQyQQy0NEIxcxMpiG7PyW6Wr90lVq3vwyWvTHpW0RTYIOeLPJazddYL9tUnETEf1Q4BNCB/4x02Aa965/otKLhDZxTymH1CmZ9c+1INL75c3kySo1T0TXfG5hmDJzfQKJy+1wXcNg5CNlGO4t9azP5rsjZ7zDUFu2P/PtxLFeDg2uWnQWbZtZvRPOAMyzid5jWOQr6Nc8syeWRBgtIgZvWnHI78KlUDt5uWhfowMMVWlFhIN278XI8CMJGalV8kWdUfeNlaYuSDlLu7mhAbHwGcT1VdcUN6LOXotIvwvv7vSzuxEClZUxY4kpKmSUnfcpyfEgCCMtCofV12htS/9njkUy5cuwdGJnWCBxQI3h7G4oy33o71eCf3Ul48jbyIZYQ6WhPgeU4/LE9QZiqA5FlScPcoRRENcQVb5eCwi6AO9Z4nLhOOoBKlDbHiA8h5bNWOD6N4tTpAhdwJfhZbM0NPIf8jjyVNXqJsF7rR/YYDQYQ6Z+7hMcfYeW7BFTJgaIHV4Jmcmtjpmn02HWmgXV1UAi7EK/Ap1dXaSrKbxyzEG2LtxC9QvpOKNUxJR4XuAcnD3lFfPndDxwPc49ht7d1B+H1sJbHZMBBzBqsQbiSUuJIKMIqCyOnV38/cW4OejpvcADtpQoe8Vfe8/3oJdu4EqpdxeshkgOpcM0DUhqmwhgZ1UFOSpH5MhoNzOUzHXCPAOw850V9m60exFV4J3YF901S8ZzMdE777TfncUNrgDd3MnOVs94cPGzbM628vCJOSWEKxzKk6giL9vdYJm5ndgWYNIXp4JeKzmFL0rXpkjwk1oAA",
	direwolf: "data:image/webp;base64,UklGRkYSAABXRUJQVlA4IDoSAACwQACdASqQAHAAPnUskkYkoqGhMdUM2JAOiWkA0cgVCzld5H43wH8ZvwbQDwl9meoL29/zvWt/O94/xw1C/bfngPWnAVqpqTeJ/YA/Mj1u75KgN+qfSZ0DftnqFfr9/1eyj6PX7Tlb/2WXz/HAHWQdAVxXbLTN+SitzxpZ0STaFv6E755yVYlO2tBbtaGU0LF8IS91X0YL36JyVavMnq6cXa1qLoV72SO7vwZGLuaLcZaO3mRJBct/IZFS2afDjX/FK5LqZ72voTD9XWp67B2FfApK9cJWjPWiQVV+8ECtRRUSry7cKl2CYhAxdts+BJxPsKnWPNpIMSuWh5dMwwc1hrRE0VW8Xx5axEwFhRaKd2Eb7Z100hQmXPUwAX1LGbfUAmFV6PaJwmzO4SCPvSmAHy3Ph9ErtR3hKKHcVo/2huL2YkB4gUkBPIdVF9f0NonEKcjG85g2AUKhFgu5TFOTjhkX7rI7Gi1dhtL5Mqc4k2c/bF4csyo6swb1lQhf++rlr/dCAAkz9nh7jPiiCsYwAZV7eCuFlV46C010sSh37H0fX33svKGb7wYibZLFHQp9uEOGS4KWHV/Vq1Zl3vxRY0DfaI/F493kC9k2SYtRk2YsduYWkqTavvek3sv0Zl8/fz71sSsCf8ub2vOdJ6zyqdnK4sMDNpadUB1TU53Gheswx9tDXY/Htnv5HXSAAP7+ryqtJG6bj/yLea7R+cpfsBKLkA3bnveX9K1xsdLc2KsikNuIiSL+YtLyZ6/06/Zrw0oOqmzM368eNm6T8gOQtuY8mlobpSj7adMNHaeeYbKfjNzf4aoiEdqEC/snKF+xlbLtcMeDQUwFAQQ5o/82YPX/l3yOuHhwR6Gau2FD/61B2yKvuD/ioOvJ+bgqxtUv9zNW7/q5ZSzZB3JTkt+unUhEtvpy7/w5O0SKv7kr4vC9l9hwc6HADbdYoBJQHIDUyxPFte6M5lYnPiNXvR1rp8N68ZpQhHjHTmKBkxN15LhS7v1Xr5hfbNnCd3grM3NvXp2ioHpDdplwf+Pr8v33IbY2Ln/U4pxo5JrA1OgOx0KvyEA2wlA6jPlwBQPsXkYUR8+2cdjTtcCho8vTX56/xQbqKYzRBbKXtAHuQt0shR7JUDQMVn1YpilBYFJnDynFjjbA2AEfu53aQoCZVFtsCu+tDmZv04xOsasYi+xgGZqyDnJDulpioNK63zoNOI5rMO9ghzuALcX2eHePXZqbZaYYBOI5bcxUBiJt5tkisXI7aLkh+ci+qeE5R0Qf4ZLRrWPafebo7EbuD79/n8TG1/df27s+IqhV2R5pXEQbO6VjfjMTBo7zmUFkXbFvfEreFqnZZtO1nwPBPd2vccDbM/6u/LO/NQCROVhQv3r+JVpnzjoZa30JGZU1XGLu/WDUA1AtcZgftQWozvEceqUdsdJevg3kVietbiwvPGikz4De+7Jd/PfqmfQizbCcSXZb3YM2kXZabOgePQczryM+BJYxVnGMT5QDKHysK9/tUs7OhWOb1XueZFgAX1Jpcur6Dr2t/SVMFlM2RFRxweE8Q7fRDq//2UQT6GXyMAj728jM65EbWUrxyuMqDehjlOcH+n5gT3laZhoU8o0HoX1pSxeg3bFLbnsTxtsOXVx+ZTo6OBE8lUY+OhCf+dPZS//RbXYr0N9D3rhjGEhfkrPFhQLcZ3fYa3mol9heDNpX5RJhW9YqPFuBBAp751bzvQKgup41fJpb6WuasTZATKnrfK/JkugsY3c1G+7UZowwrmfva4snfIF6EUgSjtz+ZAo6lJC7QfD9P+CU+X4g/ywdgxuBabwxqzXOsm6suPlAjmQqxkKqQz2jtPG6i4yZdjlmnCmJUjjoL01xZIcOglrMNveWytBQzg5UYbv3rPtuKvSNyQbZphygz869ZleJE8YCdj+sSqMaZrF2wnbdGeAY12gwYLFYP4f3IbL0tt55fS6rLUrIuje7JVIRwdBbgb3WjGoIXURHo2jwv9RF6d7AJQxpJYsNExE3S8T9DV9SoHAnmbPzTbfQRnpuC/BfQc2McVfRT7F3L4j6948+IRwUFUHfef2g8Wq4bn1xtW6GFhYCfCV12ackEzbLX4Rk1JO8YwEBbxn8NnhV+9Sr5SN4eOsXPsXLNrLc+6seuCLiXPcZ3MK3/PPq6cWflPjpxdV6BM4mD3cLal2pXUCAf8JG9YuaIYfYlKolVz4Bjz1D/3Zb5yUV3DpH/6QmxRF8XWsfY9uDNZQ/dFgo1SParizj6zQNbUYOZ7BdclebdMHRrDC1magWvlfv80/vJDCw38PT3AezqvTTP2WsNjNDhIgs5bcAHJrRWC1NU1RExn2CqzfhjZ7kKe69kczJhuIUPOry5+PQtGPCMJja/dna8myd9wROwoBttPFcP+Vz4edbsbOGBn+UT7kNI+ZwteB1SIpuZfhsVceZ6IKzt0OPDIJUOHru9Qxi05nLOiBzfY7x2vK2JAjAtPduNpQukmVZbbimeefCfIsdfYMpXES0NCo8IadYB0K88usu7RC2NLHrWVsJYhJVAskJObUb0Jy8rt05DP4GWzzmIFJmeRNqwEAbW5hmTHc6R2ksVQ7GSJzw8ZPZQK48t8cJEX9W9C71hExOcVld4UvOdq16OFfablmvh6eSWljrXeTK6X4LJGi8XSnAc3Nfzs7wb6pll88NLu1u7cDD/FCdmiAa9BptI7juGKezDMgBSJAaZ4yvl4s4ENFyXHNRIpKoGWy9MQxRowkQImLcECwaBc9qbg1llaqHlNLRx3n6JcxYgFWbCF65c0c/HB97wgKUGxAQfCGE95DH1MgjMAUQZoks5JZNpKSpul0VaXgn/8pi+Zzpaxp1AWRKynytYC0PkWvO4b5ZeVoYt1CaJvAjCSrGff5ZpNrBMUgXADO6sUUts2szRpzXTHhgEvxe1dj4krM5Ux8SSbbAldOoGyjGJ971xUuZyEErWLv+FkC2gdqhFH78Mbu7hoejqHvwTo7VQSDRRvbkSjxA//odbHKNmHdA+BjGDMbBYE0bzT/ldBcE1TEqQ15X7/6mfIxbVHeAG1xxOvuZKpZae841bVRArl7Pp7qEtZV5Xl5NyB3AwcxeEoBCfHmrzv4nNHulN2rH6erlFSxmFMac+udJQMf3CclQLXC6Y5Eq53dd7z3ry1PR4TO+Zuqt/MqcyL3vtBjBHPsGaNME8UUyZipJdySXA0sXrMcmvQq8DrFHmlKBNFQ57ZoqhfeHKAVFuja/AU1fwwxmdSSlT10pEVup6MoWKWl6kl1KlkAP1OCXg5PDq+z34eT1oc0M5gQKOWWYtzczEdoeAyufUa4v3K0KEjj+8O/rfsXyozF2Z5hsy2oo7vIaGWF7cvHt6PsiRzXtRwoYLYt2kFJDVqqFGrDG1b3isqOotDEksLr7xS1gV9uGOLKBdrFK5K+YtMksgzHtzcgoli2exbjbmelu4gkO+AZ0cIxYaKBXeTe8wx8ZN7Gn3wnNkvETqwI5ybfLU2W01keiq9+pcUXVhpbRGQQe95N0lsv0v6rYVKqP4q6PydojnxnuWGM+J8JWeWR/nFoqPee6Ds7r0o5GS9+WqIyypZg366Ddg7tsiVQvHdp3h6F8ms0cccTKbPBVrsb1Fr9uFluSPjBHhDDO2e+93ysYeYapTnaS5/B+Laqi0ph+xm4vnhTMgMRtPJeSXvhTIEF+YGlnoLFIg3QiShQj/pvNeVBye2dm6Sorf3gnCq7rIrmuektsbIR3rXhB127nXi+poqxoDmo5ISawEreM/ybRj4wBIqgmT83NJH2LA8DdEdVC1jvnCHHu72flBhYsr1yC7jyqg438MBku0SCODuS1SA3EOZbmXk/EvlcLSddQxX33VkP9foPKetYfGEQ5+Xcoge81Bf6/kEie+Bm83XfC1raf4U2hYThel2ppOdFksdS5zvw010yzMw+Ib6CIfk2aGq2R2tD3CKXjFVzr6MN+uP6WE8OKPpZnVKEF21tHSZHgW4W458IQMoXCABGbmk6qI4gtjElrPWFEKIpeaItmhWY1A/BUJpp/FHq0X1aSMnyG8snkthkOTsaBf3a3gAPj3RGos8c6m2P20H9Tx5YH6xD24+Wzbe9Xq1ysLTiAWq5Sij5GzSk5zm6TggklvvnM2zkri6w8MZtXS6GhW2b5Ke26I3ETQ6fwWG/bya/0xg8ZfNLMPCCyUtnmwYzSNth5cx8hC3eI7GOhb/T5iwiZOrJl9LACHgeHfWnYnH2nTp6GNNteSOn1F+cyTy88ueWu0pOoWyBjrLP/i0OoS0FRBrKphZ4xF+i7tcKKiDxfncFe/R6bKoZn7+0bxcBcztk/14j+A36eVWJRjEsES8lHZxYeKWtsdDVvDJkHOi3xsrBBJmG0p08ZwkD9XR5eEbH+nn5C53iG4fzkx/phRbUEquQQ4zlJWDSzm3SdpRZKhD8sQjLNigoDQqcPUH86xj+TxKUNgpILtWHSCjSoLyxn2uLux0xVHY2kwgbC1yPFp+Vph+xLVZnqf0b4zJNlnXI1JoFZs9/XpZzCCyQANhA0whS1oVw5ohdYvIOs2mMvQEntieuBtz6X4GiAGXBS83FaYJ4/+r+2QK3a7Fe6ezXKEnKPPTR0K1dx2veKrVYRlx+aGMBChE7INjYGW74MHFse5FKwU4iZlFLgtSKiSKfztvz8UtVbNFoZGNoN6PRy8M0RLBfmgUepNJrSMfy5kYuFGg4A/UGTKhnHkNl8i/XE+w6oH+SLWpH6mKo6yGUk7Pjs2Trfea/DhjKxIQcN4bqUFEctBIW9v1HILyMjQf3pYCC5x18BzyyQGFZaRgZFN7YCCJIMRYfabP3zg4pq3Bg2FJPj4Xz0UhWu6tYICg/iv8HuOnszI7VyiqZ3COgbas1kERDzv5u9fVDRGSWxLP4tQweTR1i/71mepOUz9Hj6UZCBvSVwvR76SGUCxeSQxnL1YHcaVF0sd0reLq3yz2IOF5Z3LFADGObnV+ORWzOBp03Zs8HCPe74ipdxFqd87MRzWuYoXV63Te9nDNSrfcsVM4ek3zNY8qKQvLTQu0SO+DqCWO5esbdjlM3oHTbfu142NqGc1Xa+f6dyFg3G7PVg3WMv8QA25yre4B9eedMCZFHqUW0V4QFya5kHyQem58ukKQSAOdIubTV0Uf0yivp8m/rLdW3sf34/38ch10IXo3PSU/sFQWNljVPtnis0aK83jqcOVQ+Oc8VXthAm12xJM0W5TPu1TLHjG8bysOo/+LKr1cqaWYltNtjYEMTWlYFFUQAunxXVvAEix/hpich+8m+qkJJMEUPMbf7vfGkMyHE5XVl4LgyuqEvMIdmJiH49AM8WUusQDzyXW5rTp+y05HqwiXAGCrChFryEMo+5+CoJ8Tr52MeVXAzE+G2RFOPk9nzx+9uPV4MofHJCHJJXNOpRhJ1Vd+BSP7M0/6UQmsqeyb+jp/r38ikeNZR7NvebS+w2kdOky0aD1us5VVhOhKMO8LtIAqLUz6DQZRvMpf0dPGNIOZVFsap34DY9zRH2ho47tJFqDVQBaQklUCwh7h55xxB70xd8t6zKx9BiyM3hXRBYH7bLZDk/0fEZhz1COo940cr+wzy5kLk1gFSwiovBz93lFRTT9bsPoVMGssnofRKDqY5EctAytI0+iqRKZEg8pypHIZrsgjeSNLOpHysR+B/zLXcKXKYLIzrPP7igVldNnhkmcbA2I9Fi6FWbsh5aVfVElNAmzcbtX1hZay71G8fpukSCCAFGnTGkK++8y7UUHkTzezbkAB+X/YM8L6kRKP+ipNiyp7hmcNuI/5zQb6f549pWrg1Lzi1iDDLwkKXhzFxX9ovHXCYtjqy6Z54VbLX5fGNrVbfiFxG1CI9yBKIofFoP7F7SDd6Mf2oF1p18snWORxW8RVs67FJa/OWC50mQbgSCWrmAtqosihX0jpIFwTIVswuPhn47UZvS92uOLYmpG5IKfutdCnYglYjwM7DdoqyOvCckwz4WYL6mLpMwl9REUYvV7txz5I13RyFfkEEyRsKZ+mirBv3XUbWr7+mneWrj8lADaWvePPXNxE1P1/OfYZ+2g0rwnaNKWL4+EK/420zI702mFq1ut4PIcVXMcJysYMl1oFbS6bo0jLVlpOdY15VDFOAVNeHymoG40dn8krrY9OesQCM4LsrIfHIzWEyZ08HZygF/MAFd0kt2yaZVgnTYPXsPsU46gAAA",
	direwolfalpha: "data:image/webp;base64,UklGRrIPAABXRUJQVlA4IKYPAADQPwCdASqQAHAAPnUwkkakoyGhLTTtmJAOiWkA0JeuLwB+9fjp5n+Sj55oT4c7RPtS/N9av913v/L7UFdz2hffvz3pvX1SxNUB/0z6xH/D5S/sL/2+4R+v3/W7If7qezr+2KZqZzCWKUgkaG/NySCOWSBcFcAD9FIJluQFufgzxQ9eJuOoRynY0kHLO0sPkJWO25esxA0Lrki88y3d1M3EYrvN7awgVJAzAZvwFez5dXWOcwW2202amK6AUEsRvUyiF6Qr0RFBxe3F0Yy5voxJadvU5Ii19KCaRNSh/i+C/HUBKs7a8YhRfq19zxINMR3+pqLbgSy2BucTBLuZYuplKJatwhnvaz8y3nYKGjKKPqHWB9v96ZwuDBceyEGWRHHtWDZH2Fd73vkjZU2lw5suceyIlgyOAcgYYGESsIx1aGuFcD4zxplJpmWbRHMnor/MIhws/7PnsWKg4wKwyw0OCYVA1y3LPQNLsszMYPj0cFHDqZFoJV8x1vkJAqBuoiBs2RmKwSw2qieYks5O78Tye64V5NuKHNkfu9Tf7+arF6GLB9xIFnWcsg/CbjCgym2xANwIA+x9SGep+jTihAAHoV/VE2zRBLq8jai9sZ8NcfBrJ2FJOrK4dNUoQGtg+uTcExB/6hmnoEgFrSQLqvzynabsOnbk+r14IuXhPC6ToOt/W3w73gAA/v2f/5oYQz3BQmzkigX2j8q+DHyuN1DSLmw796lTLdH3/rSD2WLaeJC6zyb7Tun9z6OzvVDhFT71drT40raGkJ6DpZzuxI+85XDVMhAcvv9pH3O/4HzeRrbwv5NlE/yBKQ5SIzxLnVX2abH1X5YLRvGJVdjP2K/USZp3VnIQGk15Lnf+0nb4sGX6vPK6CZaoznXCE2FQsdE2wF+cd26T7bzH5wt1pVthPndqGyai9O91vVKLkFk+YyNcAhbJJfKJ7n67rgBRb4tsnr8Iw17j5F7q0L5blv9Kc+sbuEadjNV6f2Yk1AnXlC6rC63WOqp8eu4wwhN0JFzDzzcOIfeKd/KnOAGXfHAMY4itZPI7VJTWTTyw1fnp953oYwImw3cl4rU+Aa1yC6ZIo20pKFgOYBQL87pgVV+Xr36TAobRlH1FT+ZOGwiUSSlLEx+Q8kUhBEi7EycfyaELCZ2KARL07DF8SDmZSw04fOrkSeg0E+rHNzpH/zpSpEXpp4xfcIF24QQ834aMKnaMa5Vph4dqTRkSxzPRoQ4PqY6V2B/cCV+t5DxP0xXNBJ8PZTSlfGKnFlw4NwwFlWvPcWTofgoQf7ap9H1LPLivDhbnZtDZHEhGGyT4gccujMRcvWK3C+cwJ5nNw2LR8ZmZ0CkOEPldv2HIpWWUTS6w8sDrQPhDm9RJj4l3EVtx0QZdwbLJRGMexpJ9d9sNv8T37mVQzF08bHgDJZVnetIbuhrFQdFRFOVvsliMqV7h4YKi5kPP5ur8g5KBoMSfqeewqq4zKl7jRv/zrcEh2dUxWEWIrn0jNjDXxbxpITn+8n+eIPnC3R1/T/j79HavkdRW42vikEKwH+HfTPteyAmDw73520rrzCNtoI2n4QxuuMU6GYwiULGjkNgnBD9tlHVml53UhFfG5lyjLRR1fq81e6D1fCzBHtJC6Ouw/J0Ece1d48d5sBHfE+e4WcVLYVXRTODuiHDVjLxgDAkGTGA9cpAHcyFtHAf+fRNqMPBbbJacgSPSI2DdSjA5wwZ4gp2er13N2lRvn3dtM3xAdC9GnyRZDlH7qBHWZlJroL1LG42TCra1FdtuoQP6P++vSevFOHZW7s2g4k/16LkMHZCsIa1QZ2fdnIOJ9ns5CTjGf3m+wpaP3io3zzIYcWQz0tz2UxAO3ZrOMEFqg7QPZb20r4UE63bSWIvssF7ptm80E+NwdDdZ46tjIueyNdxZC/31r0NnrB1dWU06aXk/XsaRrCtRzXKJrqGpG1g1ZaLVCeWoX+KPiTm6tRw/lCkmCXJcPXFy+7UJwmylFkFVeGBo7uqRqMIsBPqMjGcKSE0Nmm+7lYWAlGloxeYrlf/az+rqfotDV5J8w136QD0Hd+Y81tjwmvNCrkeWEsWU4aUnPW+7/n7fSCfVF69w0TblSROwm90E45PmRKzZDYvIo8eAhmIuIqTDKuwexZcVJ2vhyTzYlqwoxhcb44IiYRl76kGaIEXNsilWUBTGaHDGIusyVibL6OytqboiKa8aZ8HG4wKIQHNrmxmiMWfrjuIrgJFgJDvhKBfkJmFUX5UitxRaKUzAxkVK0gydjKjuxAZEJ4bspajmvQPz0/6K137J5PwP4qiKJh74vw7VOkp50Me7pJhu59EGYcAaqugleujw735DHAFaBT9kF8sgpHKQyxuBSYI+pQ3pPbrNfpnzugC8Klc74rYC9NcnyPotctVeVmdm8fG+Lx5aVLOzfk3RHQnTFRnFfMV3GlYw5Hx4LNw85k49hKPWOGMBugnB0DTga+L2l3VVFYpAeJ84sh5f2o4iCFIp6XziD8tnQQBhsbfx8k5qwwW2TEKzDXLV3s1fP8LIvwQxph99m6ZPvvsOp6od7Xytp9cLZNis35Ge/7SR1KpOz+RBLjlDWz5J7q3drX3fMadamTi4JQC7SM2EnXfYODGJtk6UZPj3LSYpM8oO/liQLjmm37cYPGRli7NTQ7uKV4cZbEMImYSeAmoi4OIJgK1y2qFK0G/0x+HPQrxq9oDOTHHOgjpih3mJXcKtk8lrdy6glOkcqFWdAqk9O53TNkEXLJbKZmL6ktDmjKBGKJdx0E7CgVBRUbNnbutNnnphpuWUnT9C4MPoD+FDCrNma1G82FUHGCgqLYFfBbaI7A2sjUZR91CnDuWAbpJpfWjOL3+iaLqsXzfNz4dzFTIB2lyCVb3otr+UFlWXdZkTdBrP2Z/ZvDr/PjpNGa2cvUiEWsgTDHLBoLdTLqYhCJm98tIPvyeZDrXIygf4LS2sPEd0lHWlP7mm8OVaJAe8vONag+l5c1CiQdk/PC2DxxpWLskR5Sn1zrVzXJV7or752giqmbiyNH6rIfXE8WG3zCL0HQdGJXMx6FM8IWv3318sVZdjH73hffb/MTuwhwcj82SxrIwJrBXLMNLY1XS8fwNBEBjloPC9s457nLMLS2OlVRUaGfpRuOHQaN6dz8fuRrbEg7PHcHNH/NFotJlYWsmzpb8VE+YGrwend4FcGE/+7VnsWfP/jQUfmaxCe+dXDB42gRyAf49i3AGeCQJC+DqPLMnTNw761vsuITDliDNSa3m/U68JVta3a64UCy6gXPJ75E6jvuGxaQ/SK8zVl8O8yuHk6vK8P9y6Vn313UxSAqKAyJkIYIDDnT7Zpecloef2xXOg0LMJzktRARDh/FZWyt0GHCCdFS/GBXR5Iarlk9wXfNAm6geTX6HJe1EyvXrppOP5Y142fCz49zVGCX4sk/vOZFXu2L2mkK9C7DY1qqv1sOe3m6Aqtk6ChlADpWKgDZL3F1VXR5VSYljuuzRYabIjwe2EEes9MLRe/HcRox2jnOOyuNpv9yNTn+Q6s/qrMf+FJBHLautKN7Gm5vBw/D328+Q8vEmIY655qTbOHx1baRLXTTgoydKLmASEIyMDoZ+jyXFzLWlm/nKAqu8eoZSJ46Ml4m6GpJkmDsALbYp2YQuwTknFH6W9imfSxsLQRPnw1Lud0NJBezWRuzWN6J7bdvS88gRkWiU19Yi33TPIYYIUsTQiTX4gsYfp9BNehj5/gO/frlJ+1ht95mYZHSGWITa/pFBXkIBdkVfVpKdiXZjIJvm3jEY2xdHj0z3PgbliPtC4L5mG/ZO6DZZmRou39DJYVJtiPV63Y6BapRtHK3HzKmOdLCK5hTBrCnQxJllqMVFQ49k14Do5KLOj5b/Mq/C5GNFtB2aOqquQ3Mg2NW6tKh8c748n3MR/yl70iHidDivpbj65wKpTdFR2V+yvatYIgf1uC99vSJeRd2GOiQqe0e+60E5WwwGcobfj3qnIIen7v6Opd3hh+cpnVkid4WXuV1v+zIC6M98h82DmU352iGcprrM+dSddHzZibydQwtabRbynCbGrf4ZQliAhAbTOxpWjdFFy1Va3KPGYKtPVrW9tdIU/7cLafen1a9m+5Ube9wkL6Uz19RkUfzo9M4Q9Lm9L3c+8v3fLJEFaP5NcLOnhwVrJqKO5LuSP9UMe45S4YS3jt/yr15OeTaOUx0+zt7b+SkZae8Z6OUNwsBHgjUkUmlWXABaTLNvcr734/4OVjF7Zw/SGNQBimOofkuMvgkhGJiToW7rkCv7Ng5MfnfACn9/TRz5w4mRKQDloyuP1QyD7lPgcOtXI5x0yA/ClOYle9yyx/P/YaF4RvjKaKpI11KYgd1hulbmK/7XicIP0yv4e9an637T5LQSaL4NV3KiAJEHM3s1Q5KDsG/Km930qh6HAGebDn1uCTIgW+wmfZ0moUKxkb5K6vsJrDMjfC9av1iNONW/mAqdJY7uCSdR2aooig6HKH18xO0rrnDuSfP4v8iA7v7BjBateTrHR75i88jADoiPVf6s/1WUSqeDwSTbf+tLxKzjb91J1G6cyagD1UzzOrKNpDH4LmVjfey3UoEquL3OCHz+lPreV1nOnfeg4uZkylMQG+pPKm5DC82TAEYIgWr2n2/1Ycj6QOKTxLM+DefD1y0Fe6M0M7xcn22kJnhgqEBreT+nX0hym/A8OtCWCk29CTr4kjx7EIODAUs5JG+n9YVxQYuJmfjs6t0Qj/vaA3G5w4+GThIjaOFbzPQvsfwyVZN2nKcGNoUTqCs7OfP+TnhgDT2UQ/W/Ym5AyuPJdWno/kJYqwn0pn1wmmtMAHZ1lPdKUripyx7Oq2BMmZrHRs408igIfaldr68CmoUwA2Oh2l0DuiVYcmVHEY+iCzrffIZJY5te0hBVlq/ojKHlMQQcaTucnzjFR9HKEgvPjuCJie5jFEaS0IGACxFa4PI2I1tMNgqrnFZMt/LZjNGixxroX408oUxr6ZJ+Vfe1xOvjULzUUprdEHSekbvqVeYcr79GVUoepVmRO/9mKn2w6fP3mMALWjzt3BZiQ4cW8k7Hggom9qKiBzXt8EpFYqoPdweU/8fFSOS8D+Hj6Oz2qob0+DBbi1wJoWC5mfL2gojaD96C7eiSSnu/wmybIUQvo6isH3zoU+A7HMKX1bfbXRxcwWkDtDQzNdDTBHd1TuZ3L6H9v/epzyO5BytWjUVNxRdkHWf0xIh5XEwPmhdyU0XBRWThgzoy/IPT+NNoEzk7FtSjoRV1j2OmpF+MxouYczBlQdL+XH1xlp7PbQq2GlO9uXQJmP71ec4sk1J6GX+Y2IyAA",
	direwolfpup: "data:image/webp;base64,UklGRhgKAABXRUJQVlA4IAwKAADwNgCdASqQAHUAPnUwlEYkoyIhLdOseJAOiWkAzce2Oxf8/+wb5aJNYH5pECYvZkY3zVj11Wz6GfVz7ij7T+Ovbj2DBEqMrQvYzXyC4wkvjLVGtDQJxtlDqw+zgufrpjhzsuYUP1Sw7wDdwMClxfvLSzLh/M+zgkjSIODzVIkibRqbIUNT9GvIvV26ZGQlMe07+DXPNszEUzL/gjptOW19FHACUPBQ+iMJKQ/QxQbANwc6ZRITB3KMZTIxkZesESi9RmZlX/37jMD3pf4CrKW/NOrTg9+bRmjSQGXSzKTeuOPDd3ju2XRTeLfWbs4Zd8XWg1Oi+5Co89daFFjkQjB1qZbI8FIzDKYRvDF9IS+chNLPY+FgbQ1iW8qR84SLmsJTmyIWo8TO0wbFGaFcnyqllG++evsHDeQAIfv9eLpB2GJs0g4Q2lm6eG3mKrcJpZ9CAL3G8jc4NL+CCuCGTXAj8jpt0WKKjmrWNR8DGd7dld2HWNMEytAVvYHkCe9SVKs+PfqrY+W871r8jHARy/6dUCJ7WrZLxNIx8INtVqMpc60epjeLNrq6Cb1yANo1WZiR9rVTzkpt63rnzccgl2YAAP78B92R/opsLeLtVKuwH+ryr9gGvQz1twny5qvgdz6/dTXUnxXgrS+OMXIt/+tOZRF0/17ATelUK2PiemL0SKGOZYtHchMmGg78vB8nPhkw+lQ4xjwBcGCE7aFV6uMAZ8LQRoslECtWXcp3D0xRIaB8I8xdhR3C8i6SkwHVwnqOwIgf/+Qj6wmb8nHSPX4Mu+QPGh3xAkwZiR4Q6CqJr6kkUWs+HLo/SbE7TIfBDHAU4m6IDW42lNraVMMFG4rfrQKepcGSnXEKqaDlUmDgL9SxSa+0ukIKbAxzFmlVR3z0vFfRZL5tqVwGCfhPWz5egNkoFcHP23bJYnT2pwBc8wH/g9t0hUST+ash2HamXLPeisAaRa2HGfwefL0N9zG3kdA1ZB+Lkdqwo5sA8U+F4sLU7zl/yGbgC/OQIansRwIToSaxO/iMitfKyMz59arK1O8jkXoyay0q20hI/PD/RJVXNW+88N9JYTUA87I2/ovY16TlN9mx/huzWu3atikuVoraMSBZ6Ax0tPKhBsdtLYWShpEFEKLsoXP9EGfqqS2MI85PskaDCTwwFMJLE3Zl5iGYXwRuuO9EHjtX5o/PFfjQr2phVuvYZ0kCYSioq44j2QTWIqvbr80pjeOpYd9GDuHpIpT8XZGgUS2nPUYjOguMxgiAiRiLEmHw/cxcqLAC3OnvUV8spoNPHYT9iab8oMBxd7BU6KvrXHjLMpQNKd+e0yb30qhiCR/lgYo1DXQXVzfu2wbPW35quybasZRW0VPsUQi35xTub1AqUbCtIUCOf1rgC/1VFfXF+AQGp7sUA15mEGv50c2fZHw/QoDuX6jD/a75uludfrQGseVmOehf22N2ITVaYKsibszG5XcR1i+9RBJfYweLzgbYNc5XWJPdoVaY/bjVtCGot/sKy6nAdO5LHNzAZupSBXsg0uDqT1N9zAMw7G4HtaadhF+t/Wr9rkBOsoGcxFEFKWjEbKaWxffuLCXFtGq8gUNOSzXEaD28N9A40gu1Ixh5Gy4S5GuHd2M8Gc6mQ80tVZlLJnBmmRp3kxtYfK77fNGxYZ+jEH6zl/onZsE533jLLgkLpff+TK3wLkp0Zum3WWO33MxKLakvu1DgrBfGNNPx5Cpp8TJSC/rICUyncDI/5XCf54fOzOo8tAvaJoHpDiSj9/WvePyLr8y5eqFR9OgcXIPkvybHa0vjbOBRoCLQlgIF0PiicJeZclFH5zskJCz2FQiZ3kkiAwlQUmsSw8fKHKLiGUWeA2BhUlMY3KHKMdlwR6vpADFMMwjjMBQbdagtnAkEyatGsfmtYr85m636GMXF0jAVj1cdFVZcahdrVancp3vrTM44E3V8gKB9bfBMiDW7L8MgJq0lpYgssHtXnICloAyYc7W73nK6tDUJKjjt8d+uTUX/KZLW7C4LmhA0bJFPopudpnOGAVkMESJ894ZXelzMFp0i/pevU/+0uUa+7F463H00yITAytJqC/DIM+6ZT30fYHUkEdNk7ZfWqeBY5bmsMzDdrTlh6uOCG6Xc/A/1FOA+1YKfvt00Ar1xFUUtaJzhCzIdHxh/WG001JRrmCNKXZ7gjWqOMGCOz0z5Y8QTyMB7wND3BYFHQ7+i0peNE2FpsRkhsvvEM5NKsQRjgJGwvb3CFlTvtm1q3+5ttamjEomBfVy5yEkSVSi7D87Y8r/sxL+YsbEZDT3YAysZH/t9TcTts3mBeq79ijfSqZm91PSpODpbD1ogAIW01GSmgEzwJfTp9uNK6psiGFICaUVlPLPGpie+V53GKny5wpz/MlutDzstgR5dKgnPgUjTj5n7vYAooVVRV3o/HujakKUbvil+xrBUmFohL3+X4Rv5qdo8Y17qEQGqln/VOa9LD8FrAFBQQahlu4eVXbWOHRts03nhFmv0tFbo+7Dqz1TDcASwHXYiC4CP7I0+Iqbh4kmEG+yZoxmu3LPPvgR3dZ0BK0wk1Emhby55dl1hAAB5krknFKClXolcg/5j+6SGxOxzPHmcqtC853Fr2KDWKEDizpe6ZbKlXze2C7X7ibMYFQ7cbGEazakm+VADg5Wj6RzSZH9lT+Ba54DBZI8vd34MkiXga3JeV1sTOpEUotilbvS3I4Vwv+jRerpMzSsR2M4NCvXgUCmh5XXwGoWeCGBA48gKxnttZ3F2h3EbYyFO34FffoA2jAu17xMoNlvchtaPjRxfG14aag2AxAKbBB+poncc791AjTk/mMBB7XADp8hyiZLf9jkRlrSAP/65rLzLTxTBnpFvmg+DyQ5bjQv3HyjKk73t5bSFvxTixAC/XFS4IWNHSWLoT6ahOifFEhVU/odVmr1NUPV3W+UMYt8JKlTwYw/NctdUrivTAKVrOQDKuP5w409CBMSgzce9qY8zyak11L5gZtnxwTHZIAVsTrdKFdeqKfXPCMn41wVutRZxkuTXx+29O7D7zJSZKY9bXmAzm4LVtR4l4Lul4QiHltAlt9ZwSM20djmAsrqtwowC53Jd/9TkhANRFbKhG/WyFxVLsGZKTV0GCGFhgPsHn+PMh0SqjvfqNoUYQP1gUdBHLvlY9g4CI5pZp2gaIFAy8KPvMHuCHz03MZtOvz6fz60+FPjgMI8dpHpRXjSiwgCfuwCdeISMVEahO/9/cN83Yg/+vAZXC8pX+xdemRWxKa6HYGEyt+IwUIeueSu07cL9xL0I3Ywr6nSP5+ZbwT1UApLOjJfRqXK5QocvRUiCqGijHquT+SicFu1Wiuhow+6K0ndsxO0aZOCCPzAZ0dviQchKOAK04ALKSkMIAqqeXTiCy2gHb5KFQHhkZE69Sw5nEe7IOwAA",
	dragondelinquent: "data:image/webp;base64,UklGRi4SAABXRUJQVlA4ICISAADQPgCdASqQAHAAPm0qj0YkIqEhNVgM8IANiWdg611oTueA/3j8e/M/yX/AP3H0JML/Xj/pegn1q8++1n+n72/lZqC+yt29tT6BHfn/oeilM48HewF5a99P617A/6i9GzP59bewP+uv/Z9ef2ifuz7M37oicv6RdORMpa6aL4YLVYIPTVNLKrW8ZgnfCE3t4p1yExddE6ccfCdh+ytWtaUFEq4Bqsjb6se3A1ceNusb9onK3hIfH5M6nPQmKUDEfVgv2Y67c6VaxvQfYY2ORonVSWxafiEJUZwKh3BQs1HQWvm/KXDF8dps21nkd4rK2Mecv6e55M2CNp7bjbTr14zwHcETV3+rOlVS2wxpjf84bocthFBlvtlZ/LlRmsTvUuJVC3vQ+g2Ra+/GaCREqrS+qKc9X3d0XgDbJPLkdfkum9PmSC//ZIUxOYOIkeYs/r21awCk6yaB+k0CFflt5KAWtvcYyge0X2ndCkeorp8yZ5qzJSPBWYHkBeAGEtPXQtvFMVrY0O+AOlbp4rWkEdjZAxSrl+q/BAEIZkNpN7E7FEt5PD0JxLwjFoUQtmDy7jLp4hTNU2Z3PkxGzHLil1s78ramo7wLWe35Pxa93HDMihaGeiChcDCW/w3fc222/N8JrRXmjMF5OAesaBwKbRvrZ4fHmOqsb7cdmhnhok5AAP7+Lo7iB3weu7Jr2Rp/6fOkX++mtvO5P1PvjzSUPN4m/D5JU60jcVTgOJsWqwIJTpjL2OToxfI0q9em912tSj22fcbSbBLA58waBs1uxzLlMuj9RWnqymzBtWpMnSQ/2/Q/sV/9CxLdL4lWyO061vjHzPga033/5TB0d0a7xd8MePlVMc/Tie669rR/9yebVKHScpD4E9u+4LW0HA14bcP1Gb14vFkOoJwafp9L5+hlNBcAo4wqzyvqvNRNTPhBB4jmgpJlW4U0z5dytbQyTJVjCuRxSJrvid1mc2P/EYpLoC34S0B7AVcLI2FLuYz5xD2vBXpwBQM1vw08fen/g0JWamYLcZipIEVflIAaa6XaPuy9L/XLWP53CENsGh/ep3uGoOD9nwCk6JFSSpjYdAYxk+FudIAK86x8+Bt+LJVhXAoAEJgTPW8P+SONJPjI4MKps1kMO8hhdkwxroIWS/+EpYwKRzOYOHJ6S98YQSijzIf+Q+tbsn8x3bqpNKbXv+4bxn/kSDpnTP7hgVjc/0afsX80W13fJt7yo1LfRgfTz8Ms42/yK2A5B+Kol2fd15exWVICFA1JuSHrl+P0atrdJDetbPbphq6t4G55iyEpKA0eDWLWoQb7VmDvltQJsGsS2TyHWYtaJpqmC4qGhUkvkL0MRQsGG3ewZ9E8+m/+0OX/vN9iO/+FoIK1SUZljgkrnVHibeKb+KGVAxpb60m/8vDnB67e77+q4Q7PiR6nCyKPlaEGF7nmueltoN0+1bLCTlhHUsoOF4QxMqFhj1/+LD5twS87wuQXhC9/lP5qy6xN2LMd/+nrEP/AFWneq+5ftizPu5h20cM0KUbdJDfXWu/WAAZkrrfuDd/8/+mS+VvTVjSF0cENqkRq97wBQlRiuCQTbj03qZA/IjZaDbZsMl4rY5VUjXSpdDFXzRw+UcslU0E4YlicOrTZ2S4iHVxAkMU/vQf1BWy8t9w/gPiReiQvJBCCRxfhbdxuYkz8HlIWD0zHHvzYCbNuH4DVlEAFsbjgyIRRjVRN4zxb8mp6dGOYIYGrTg4bvED/6c/k+PZP0+iqrihNAjIYiZ7Apdx4UDXgW4PVAw7c0vZANvxVwCtjylp/Ak7eWoKXZDVclwbr+C2mlD0cd4AXaUHDcOt3sFRJnGNHCia1fU6mExYTs9dEy4CGHfYbDRnhDJvLDw8C6CX05lJVbRaHFGVSTZRgAsfaqHWYMt1WRrREgiqwT4a+QYtOadz3Fk8rEm2yJWaJ47eQHhRP8c3OrTcmpTxZ3ZwX+yxQ4SsAjt/FWaWTClIgy/VIY/R5FdbwfsMqLT2NWzPsRpAs/UBHcy2OmR8TqhV3ZafXn6vmjyLeRiuQcINIFc2najL8dxs+g/R4my4+7Blb0ARFmXbhqZy0/BB5cBFu7GYNOML6avwVzYeby+gJ/CWV/cZl7DBfjgSDlMyvZHyU0+Ebxc/IuF5/gFAz7FT1SuPqkJDCG52bX+j+SA+GPnEyy+p6jZf6kERRaU1HrJTNIk8WXoMBRxIUq/22Wq7Xh6HDI5hqARXev7nJtu3PZ5dgtSYf8jnSEOeb2u54jXjgHNHvubicyrc1r5owt8u3tT2mvUuKNZJjWTZFx/j6xSDve2JXqSsslDShrv3njCFvObobsHEPGR+lhEbyS2zIgmum1iYRa0ZFwV4my6rDv3pjaGJwsggL0D4+U3W2Kyfz/cSXuYWfXPK8h3UB5jV/qInruHb/EGwkV1t282zN/IGpZhMrGigJRpP6THmDhjXr5Wdp5lWAWiaqqU5uX5MAhJbabTR7bxnfD7g2GV275L/1/59/oT6VRhIIVpReTePLEtkx5wo6R418xhlJNv7Pl4PmLSTC5f4VG2/kXkqKwchtytfd090sNEGQVU0lJPLDAvubLBYwHlAxf4J9KPtuIvCQLhlmBqoQONzVE3AS1f4I+cYggPv2ACEGfR05QdCV/xwvYK3ALCFvuouQzS/gqJNv29FB1jacJhDng6owZJaExLjwxoPQLs2VpditxQSi6cSOSrym9USfQlyUS1Ayh07FLi6sHmGGmI851il8JTBif47Tc0Z9GvnG4QOcfUqjl8H00Y/E5Ty3PJBJKEsffbkjPyVAFMnav+q7Cq2oryiOhBAMT2l33YVaUyjzX5zxxH75VApidYDJjeyzAs15oA8G/sXscYlq+C4Ci0M1CtFCIOXJjhAtOGguPHQmW4PFp4jsVtY9W5/ubezuzXLTXv644zCRXATgLgnYqhPKjlVh77htVjl9zJb5qhlfc9uC8s+ORQ/Mfvw00lB104xxSmSrmCeual+bpubuzn0vIxRbXyW5QhAF7LxzBMBsFzIf7RXp18BOc15ZzPqh5btyuKegaPKcjrbo9k6Z6GSaxOHSe2gL4rZ3MRAqyffwva4c8dcovfgyDNi1WL2rhYDlHVnSKTP+D7gwSbqfUPPNjgzWIP8Q4CbyzojZ423P9zps8f3KesHYO9MJwuB0hWPBNIw6D2XN13/AK8f9kcboRa5fmM9fOCO6ihsDHuwtDL90k57O4X8DaERyVSdopayvxQ+FWG6HWBN1LtkB50W9b+aSRvzpXgRSf8D9jwsgKoq+aU2/3/X4+wZr24N7SzCTKOAzoNqCsmG5hcFY484yA6EQKgPQCjcJ48zBfNa8fCikan5aWAFE40SKcZ9p9eOA9A9iqrlZlFYG0i7z4MmOt3jSsy+e6QZDEO9skAqG5wjp/bjZb+KAYff3rrZONCaGTOBXJjMby8ZAvn8mXthdYvzE/RkNvj0C8EXq50j5jF8jLMocOkGrykXtAPqq8NxJgQNOREoyobxQ/rDB+A7Vn7cZ8fkSN0v33lo9KHKtfjEBQh3GseXaKJbUsfc/ziSWvifQEWDgpYYJk9+7zUirihpOCz33D/VqMyDQ4mglzgwdGKw/uESdc7suWIbdf8Z+RZZuikAucslickeAPAns5U61SuebNjFjugdCvb1qpUTxupS+2PAyjkLIBR95OatUYsbHgkX5ZPbf7Rd/8ZWHzUohn/5RjqbTlrPlT6E3/1Is7b+Qn3D+fMUM7+yYWIV77ZQceZwOjUKyMXNTyAiuJLz2YE3ZePD/kcQ6Y/CgfDh7LfaHlEu4hZCZXt//rAquwu/KZ5R8qKz5ePlt/k8+5Ib1fwHMUPLwUmh3gsAYpH0VuevF9alQDrwivUNRt5hNlMdT/Kgiy3v7OWlSRlArZo/bUId3ShDs2wxXt01Rf4naSO0x0DZGGoI/lRSPZkoDCDoss4mgt98YlMq2JAz7rUBBYyNNv/zg7Jxj0nUwO/27RRQcfbNQAOAMk5FH8SdMz28H/zLUJNgpb5Gc8YO69txOFFqGxCWckZ9nkxtYoA6gONysQy8nw3YbeUC/YuUNXj+5XismNsgpi8o/NGpXeN0MDUPSgPLkKDytDtyoPwP/2UjbjuyGdllfjk5Fmc/jAOPtnsUEn2D+YElmG3amF/IvYcjIPa7DoWiDDPnGPMtqwa7IYwYD0FEUfyMPnOLo+7pGdln9rUz9kerl+sjYz2qSN6XybMVS4ooiicwgGL27q/AW3Ni8J1/2d9Ip6Cyv/dpqG2C3Lulwb39fVJC8c8DypvJk1/onMLFRbvPQJcILmXahaJQ2cDjsabEWHnDIXO5bAl6a4zNn0BzcYPBAV72scnoMlSoyWoWPFI1qTdFhFx5VPU5umdn9ovBjCgTMSafC8i+eYKdtGt5p4bRYyTLextbSqMjyjMBMYDp/Nnq/kwX30oa2z4y54WqL7RscesZSiVytqzLYJP6/gwZFkWgrHZofVFbsYABN3PV2/dTy1GoooLBEIIPNo+MvUIx00fC+OWt5qHuByriTWqQ3xa1bRhMsF3/41d+g7LesoiP7jcAqxe+3PsVIZuG1igA2cI1ZgeMT4XCmOwP28qA91BY8R8l1MwONlopRJHnVfvgGk2MM4qDrGFUr1vXH6Cpby97v5tMi3Bj+JHrHXZxgdtJeMTKSaykHglkBB5OgkxCAYDbCRs2c2L/78rjP55yHMAgbJXcYYHpdt/Tg4z+rRb42JxhlrUqnaq++K4rT+wrAyzGWhoZ3XvrWNAxYu08Bs2m0Axcx1iQkU2lfN25XDsaXqB0GhLgUJ6BZnfD41/0UD9dxqbOZomSZrp7P6cNNGbiMDq8pxPbDRupMIAjR8BHf/tU9FvmQP6jpA+U/3HV+j8ZDDtYtBdyyc2aikYrBb5+yAc8mQL1JSULoPMbqmg/ZxiLINsgtrDg9QNQZg8EONsZoQ3UzLD4oM7y2GFsVDBE38gYXNOC0tbeLWkhKLmUhsNdGR7XMLQWFR7N64hAuUYmTKGgNU2lY5M3Sn5+O3IPZ4EfzboINYIWMVZ8CTZjSih8rzAYMNSDm/TxysZownKoNfKCq76mmV0Sh94N1JGaaZjdKzz/OFOpxtbwG2j5FBw0/W+LlbvNslSMYWfoF8MH4DbKeUcw/I8NaYSorYscsM2ZFJL2qtuAUSPLe0dJaf0Bd4sNro+y3o1jKASQqjfMZXdXb9f2LBtZszIJQcuyfMAVlKwwkOVtvKmJYSSnYojkq69eUpcULzofdTA/osMAxf5XdP0yK0mjDXMggQCAD+EEtMIm4NbI/dKppZ2e8uVCsWR13MnS92iGFo36DgUDrEKdhC6D6i2Leospq4MGh5s3GwE6pm1Qp5wO5PNTHzuavCIJjJ+GA+y7HZBr48BJrJM/6dvzgKXtuGMO/WbuPXAm7CES0J9jqrEGjQLM6Uo2mZKix2anLfXpDFNFXc8vzZiZAC0BXgw/C+H0DVtT83EBk4tcgL4TzMpCx+FIfD2cyAKZtd31msS5UqFZQLcHpOsRsgLTFBZwvW0NhI4qZy0xMWMBMHoJl1iQMGc1anglRKoVab4AY4YqtjwFypqE4f6Xb9B91aFOppfswRNOvmKnq4l+yN1I2Vx8WEk2SdpLLvukoBVKBYRuiL/R52haIQOk8ZiiOLb3aPdTu3vb31/dZ9T++q57WTasP3iL5vbMPn0KrQkFHFdnyUvRN6L0tFEptmK12hKeXn4J8BFCJPsxqwgScaGxZamdsM6//yO89+f1o9iBBkb3c1ZT8nTZkBcGmP73gWZIVlnoMZ9r8oM9IbZjezGiNkDiTu4Ypwbqkt4yiIiRawteXiW5/zzmzpaWBJajoyBktKQUtGNLhtTdXcMSk06k9EtL6i7+hqwpGaeobR7w31vHhue2G+cBUWdQjEBJAJYsDHANCe1/dXGxWSMxDlm++zIv6I0ZS8mXlZbA5zbwRiveyt9SAAnW1I8XP5+CclYLD0QbaweDlsFaC9ZGsnBW6kgT4+hgTmD3j39r04Z55O0i9wLhlZnwgpSfkyvZE0y9rImNRIZ34NRILPyMYf9YWzRbI94WvcKZNPj9I6+4y4ngkiArHB5P69yb3fHgzcpzDVdBMKg2vkjSOfZRMs3/kEEKA37qwQfXzXt6xjRP+jA8lAyRyNW/hYJWmZiABMAAA",
	dragonelder: "data:image/webp;base64,UklGRhATAABXRUJQVlA4IAQTAADwQgCdASqQAHAAPnEukUYkoqGhMFj9aJAOCWkA0f+uvwc/R+BfkT97+5/rs/5PeL6X8w/r4/D84+9/4t6hH5N/N/9t9tn7Vch9t3+19Aj3a+1f8fxLdUrwx7AX63eln/a8KCgJ+mfRX/9P9n6Evqf/3/6j4Cf1x/73rue0P0d/3TED/xjjYJj9/tIXMKtcMnpJVCfCGO9bqHmLBDGfTKLGDL3bdtFEC2OvUyfQklOH9xZ577ZRrqM4JriryoGuD2Q3B8/1r+IhART98HRqIyES5CSVHNiIJAeByQfO1fbflLbexzYDu2lm7wbue6fW6++28azlYDJwilRaHb9cmHT6UsbUOV0KxrQYSQzHGl/iC6aDm/Pv7K3BU/XCb4YSfhWIa4l9fk7f8cXDQbW3T+G3mOUrBGQ4hnisPQTI0+8iB/AB4QENf9QR2VDzuAWFKtVdbytC3o2AW4xfsDs14Vs4XBb3MLrt5qtOKm2+z3pp7IhJIng9WRxZnVybq/QOOaRv4IjG1/rCbnyELFPulizcewW75V9RyqDcNJN2oWm6X+AZnPzX25dIv0NRwaSA3FFV5QOTgaCamLC19PIo/OIljVXx5F4qjhWynNiA5yjueXsFTxqtKab7LEE0YxGBaslSqF+HS3of6hU9jab4EoDcPM/m1RhVdKz7n5pI7Gm+VVjI/QnSCl5pfJpn/+0rPT/Z9UBdyULvOr7Dqwru5BqAAP7+AVK8nGaly7KrieDZY1btyjJJs2kYa/0S0jCTodLh8KV7WArlVyIfYCjEu5woozFl8F77Oj1ApMvcWgO9s1gmL87/TJwxvC9d/9+X8cCI0ZisOjLqPouyzg/JsjCcrVGeU6HADVqS8/Q979Nn3iRe7HErz0SnTv/VujzMs6GiDSp/DwUNRhrV3d75177V2A74Sb/XutpI39hd34dSSUvT0LFWlYGjga2XiJql3R9dMjiEsr+y1uOf7wTTInhkRe5HiKTTfR1hJ3poyG/2OgyRjq0cU4cZJVV6Eo288oITUwRf/vGz7+hJhzHX+NBTS5n8VzWhNTmj6/EI26xHt5mPleeijGagpkj1pI6MjyRjWziBezM5BlLU7vW7b1jNxjjxZR4p39Wl+71GciYuyunKdkb7K8teZgBoik8kQTalkYAzkTYtb5ZGKhgr846y2D8fv/TxN7mv+P+k20TQQ2VQmXtLeaP8wPsHyclflyLQCK8zbF0FAOiMeSBvhFquZp/JK2fXwxDKCRgMGHB5a0k3ltegifDdndSqTz+33XQffMdUQSNzPwEG6PYUOkZzcrUAbS8cWa59CY4hFfWiEYq2nZ8EvO69zpQ3xAZRM42GKf+nQdus04Rr1AlmvkgHMZXaKfJ33I/27ySLDswlMphTmxu0t5bpmzwHal8kM6DMR+ODq+QfX9LsnZwRJAtWOJdgCOv6wY6Y0YHAQeOnpfS+dt3+ouLUaki1I97r/Lj/OUXdRFjZWBMI+ZK5eNkVcmSl0IDb9KugyNvBXxCrqys1bSYZcIl+VJeXoi9Sf6NwtUX3KAmHhFLgBAsCnBgM3v/4SX6r1JCRP6EOu6KU+fDIQzpRNSrxfIgjH33VQFOnca3rdmCluGFxr1HBVm5kOzgzJ8rteKycYgQX3aKI8mnziYaGho6Pfz+GFrL8r5BuTYRk9ycQhk0+kdeajoW1R4z3a9FjBhhHPPgfV+FVkTZ07H6QALYgOpqTG6mbRZuH5je6HnR12ERtRTR990n6QAboTLoWqL9o+x9ATC56cBxNvA/2lzeosKk/b/Vl+jcAAMu1llM1+S378UI9hTk+PW4KmpNGXzOyva4TdrgudEbIPHjGrmXedaBRQ1YR3wimBiCACDgdxKRV7hf1uhIea8EeAE4R2sC5i3MWZGlyq/erJX/NzvD1BQGM73ApjXyWLceSfasXohaBRxcjHD5m4WFesXLEpCn3cgB2xatyyxUvOPsEw5OvpPGOOmnaUTdv9AaQkODGboVq7s51N4OK239ywJ+j1GHk4fDEOFwGDhhQycT/hCatNEp7VkVCwN9KiU0hSsG7xyq+8F8iNjq+vi1duNOzzlVJtERl/knHsFCLO4LKU4PBEuBi+ofbK+Bo+qpV4pe9TzmWtHa66mqJ8MXpv7oVj0vddKjdtTrRXi5/2BMsRMpaBCKl1lbVvZ28zDVeOS27tz9TjEBCJ2IxklIAx5rvczMyDa2m2vsN8qXwIse/+Xip0H5FjY7m0ej2DpOw8p7j3NOwM7M6+3jzwXYaLfokmcMJKmmrcqDLNmb5j22aR+zB/P+herynkapF7ANtOl+1a+EZSslM5Es1xIyuj5n3ez4WTV14SI7NRsmBCwaqDLxPtPu99nzA1reEkGqQx54kGKLpiEdqPLYm8XeGlMbnz5tNMxKp8QvIydSzEdoUbybwrpXwaSlz3rsbxXuFqv0rElz0irzz+7wMQlo9Y2ExgxWA7IhPif/t+wTqzXjL25ixMvZxm9s++dBlj0wtrJN7+3DDNKNesGxcbG71fb/9fAN5nc/7CGrRijinrgBXIBPVOdY/Fm0gGrvbnWNT+J6EtGHcEmiJOZiSc0cHd1faAePd7TdWPGbn+bLNQCaw4cpVYZa9JUVvER4RO54J7++5V1nLwdBr8lQuh6Siw7kwNHwFwVYglW0dC9SLkETrEkhOxdsezLPGOB/SbYwDwC2Mb+g6DoWcAvrhn2fUw4ymJfZM9C/aKi0TQYWU9UkGAuK8pXJ0QZ+LNPQXu5+n8N2tCzTnf78RHUIUMl0hAUDY8M653Mt4aLXDIk48BtPda9k5tL4nsNHazkxESsJokXhf7Csxj5iX50U1B30qMuYNZWHsA8s7ytmO9IyIQ2dqdJZ6jqShxjYbBlig2kbXjl8sK8oPNN/RHrvL+n2pVRHV47J7MHyATgtmUKYNxjzCBa4c9yoQbEQJSxdLwuMIamycTyM839+LgoF1PyhSZzcqMaaLYb4hHcswvkfbeH++fS0xXUE9DpA7RWOUNRWmzOoX5XO+ZixupuXYxNHl394wKWCj703Tm4eqy0ChZYvQOM5bqXMXl/phry8QSDKRKYDwx7LklmZ3YN0ISvad+GK0A3YTkjx8kN6B6wXtC1oIxRzpKoaTOoiH+ZNxOS1KuNkpGfFCWJhWvrj54w1IywLHkkftsxp+Jk+yGHmuR5VkaMslikOa3LuneBmMQOMOfyhgc2KwVsNsgcSuuvWBe+JvcppE+fzVftbuRjICvLQoamK9CeVp4HAi0X7X0bdS1zijkEa+mfiOB1bGWkFojedmQRW9xi9DEFqZhPmgp9jUGEcmVVGIdkF5XYZhpLjaiI0Kpe5II35n8Zl6sy1jESOQeo2p2Y53Zn+PKDNuTwoLjPTuiZPCOETDMU33cN3Iar+7gmnHrsZARgP/b9t5zMJ4B9UoDfm99PUXRP49OMzrL0dKtoc85BwFltZAOunJQrDccLnKGS1Un/mpmt61ZSC5B1TdBP0XWVhg7CBbUET6pOCuv5VjC/LVIc1/LXeTJ4cMib5afhF5RuDQKc97+JBrhzfcxRrffYBbrKvwejz9013FmX0xZsjilWA6GoGf5/e8fWFmpNakVYF1WJIzA43vWxSZqt9EwPsqLT1LLPVHyVPrw7vHappeSuQBzNSWKOKjvqYSdOBZ5blfhcRe/QEGO5uaXJ5BuQeSJetYCOLdw7vk73L7zY++/Wowlmv7QExWvwoi0DN1sDl47Ocqpdwf0C2SEpDaec3V+wxtc4rbxRONLhB6HlIvj4Z+/Im6RMMaCvBwyGkhcKwr5H1bFv/x4MkOOiDuIf1sHEK94HChvVqqyi22sm9PhiSE0YSQFFiOVxegXEMcwXgmDXAchgDzB3fgB8UEoxFdSKCkY0A9TK83l+L6eMjKZokKcnug9EPKvX/LfCYQUok6BHycB/o8uCQUNGPEFfuP09P+Lk7zA65u4VTLYEbTrgRWGe2sevtMckzrg5Ly+Qx9blMmm8GfbTa7KgLRrU4CXupBA7/ID8GBy0iFY/LmixpA1a/H4hC1Eps3HAeHwQgyJk+W80eGtJh9O7y/JmZxSfDsZLXfleIlDVoHhtduUx1GNyzaRmapLgww/vqyHt0xGCt2ArZ0F6PoHKZ+M5RYXXAMsNP8Wk7f70sJvIO53EXeXu2BdUn2hAGjA3SH26Pyh/OV4Ai8LSjY5HCfO/k+brtrAoTW+uQB/ZwvmvX8gSNOawXJzh+lJts10JSf6Ze81v5wZ4KNWJA7Yidi1OzLM9hGz05FU5ckVZELKGInfd0FW8G5EgJ+AxoafUz5zNKKjg3j7z+dsnNz/wdXtPlXYTJ3vVfbhrxpuRbsp9sROkyTwYld8hDYeN1gtnbzWEYmKWR6/rUAQ70yISd7n2Gocz/XaEfq0PtnTQqsQxty3UezWMKeFMptWJNeFHaYYPG4COaLG1znXuMr4aQI1G9kmLEqxI1pEQ97EhDQYseUWDnZ7Sg9mwu4uKfZWBb2Hqr7PiNXBvjOKp9vzP664cyG8sISElpNdLpOqK3s5aXtIVVzYvk6vXu8JzBUgpJbmfiWOKYOLzdrO/tcfHwQ+2uQ3TpamEFMRpFWQGgqo9CmpaZlueaGMvK6QMXz5STW/kvAtCRhKNSSAxiFdSml+BuZI2PxvMnblwaVotcKEB1MPh/QmSaM7pGiOC9AzDje3GOkFc3mCpJuAnLu/COLgw7/8O8iW/eyvfibeKTyPkSt8TuCv5deXp4KzCyDc0V5Qe4Mkgjh6olcWMYAjEhIaAiCQ7pJpuHVbi5+0MiUoPM4GAXvNdOYftvxYD8yHzH2rWFqYe+UZuxHELiZ20PKd/Dxo8f/yuX+ux9RjJ3iqTDhlraN9wqto0ZyWSjaizbMKmppLU9fhBQGiA7lKhpk7/7zXvSjWGnqVD02QQdD4FlObUfbkqaQa316yf3x854uN4IY2T1ILvBGq+W69dHFFLHm6DyUm0SI2HSPLqqp+alC+E+1SgHGlsQYt899/Mn3UommSHQSKrZtsNglmaX98WuStEHrBzP3VrfbYtsNwAf62kr5v3Xe/KU5KkKGiim6629CVxcP2fnzHn288r3+Oth92a5XNsT+s74nT2EH/Go9B+crpyCA6zVnQxPd3lb6kTVPnsx4ZZHzzDZwxhF4Tp5H61Al2zgOv9EYDPtTqqnzM+4cOm4qi65G5jp8NJgL/C7desS3V+KkUh9HXGBTshwWWT4w7AthHGFwXvoxBbB4cvDLiZWp8BAkAeqTOhAQwV7xMEhwS3q34UDPR5JtpJt5O8vPY6JW1G/ztqaEuy0DgAa+gwhwB15dw8w1AJO9TefTvUWrK509EZXzpXsjIvo2kSouQdzGkBD8uzC9Q78RXMK18SQvMd79WjvcRvPtYNCgUdgunu7mrhEiRdD+fGn+Imz3e30jBHj+f6o7/KtNhz5LikSMokLRbNYBQRbHi824LbY7AU+0fJlaxUT8ReyrvGTWURFDkN+GoGGQulNtmLnYqSGoJdOITge8LsUWMH+WrhWrwMOyFB2q5KwzQcvVnM9fxrwMwTB77QtnG1SPOE9tiq0It5fGEUxNNLeKdykgK5+mWjDGU1MkdtxkqzxcTu27DcR1XsHhh7wjoypOh/M1aGnUVmksFhuZl/STmwqTI+GoSRZw8uZ7j/f1s8NxJIXdVCTytw94mh2D+lNS9ZM4t5Dd++In7RkIdWaSa+JpfBJUTm+NsEnqKBhTgR+GjtYzFU39phXv2YKpMsfC/66CvT3YZ3V77aWuCHUc3BiQzCiV619RZP3Psk1MfVeKOhVqpOq5kvwxuYx7Yv0+LT/Or4pW5zf16m1zsppLftKIWQ7uhqHC3xnMOyzCBJ7iRRjBHs103buirIetJ9iub2gN2ea6ulcMSp6LH5j8nU5xzonOMdCWMeTJHfVnWDosiyCpJBFMMoRimFP19f+5bXUPS0ZTk0MxTa1wE5adp/T6C8CvPxlPCXrHXrG8f4kM5CiZL6PRJ80cMT61+WBJGsYIQV1m3wvh5gVtvXk6A9PuFBWMBtku9Ta33AwUDw5u+3TGe0OC5A63QfcDbdqX/W23rxcgMjNJM3LcRR6EIpPWuuf4uHtKeg/bpLKx+orsUD1fuGqSdy0t+OshM7Zd4vFlQ3ju0W9yqW+yVOMSA+6kL4pJwBQ9pbPC3hdud5hMvtgcdsDZQ11zrWmTRhpGEadLK0+bf1PYSGeJJ0dG3AyCeAum/4EOGDAsCOB1tvFcBw2oe0WmqYSblkVtcfl6ETvI+oQwp7sBiXB9T6Swf3kMvLpk2ncICTE8mHVKyrJsnOJ6byVVvyBOaOKuNebyVlMjIrR5n1WJ160bCIWPXzXxfjnxSO+g/Z2ztVOFyWnyh+tWPGAFZuxhi3ESt0eUgOFDueUrhKd1ANm8Cp5wfyNCIlSnUUJxBe5X/XfR2+vtIWXr0L4ryxAfbnwfa1+JF9jxhadQEtbl3vlHi+691dyTeHGAAA==",
	dragonhatchling: "data:image/webp;base64,UklGRioQAABXRUJQVlA4IB4QAADQOgCdASqQAHAAPnEukkYkoqGhL7jMeJAOCWlltF2dUK+L35LwT8ifxKRW316h3b/6B9rn9b3x/KbUF/Jv5r/nfy+4VS2/oF+7X1//meivNQlTv9bw9KA36A9Gb/081v1X7BH66/9HsU+kN+6RbX+bhk3ZfssHgETkhd4O7dqrbgS91uCrrWrb2vZxOjw/tr3kj/Bs279hrh+DQ3pEKVNgLl68Hsir4n/gV76x5o3NTs0eQKCLKphV00ikfEF5g8gM+Kxfl47Bmz4hpZW2c8xKF6Yw0cpSnjg0ap3YLhnFNI7n6UYgDM4FMy7XMvanBXFn7wv7m1OqdgEDys5EACBVsAYN/f/C2U4VfXaS3V0qt4Zmg67ydmsfRvAPfU+i7KYINi27xOVDiSTmXGrMiMHvrAUPdeHUu9AxQLgFY6e0KWTNHZ0AS1rActU4EnSrzxVLgXRmIf1D4PnaWlXyYMDzqkH/nqMLBWYVg4rWXVpCx/E5bdsCJcjspO17j/n34DMbu6MLwZe3j3k7a75k9ROw5PYf+9OvfTx8/dDsz3gSOkdhkmt30zHbczBE+Q6IIq+tUIMqwKoR5w+HXe25RVXTdWU1xsAiroWISToJBZteNpAqj7qZT3i0xH9YXNXYMAD+/pft/m80R+VeJfnpHHl+42cuwPJ8C7vN3IXN1d66C3OwCkw5U6eIYJfuSea2plnLO4r63wRm7pN9Vj5GUXzN7XgH4m44Y9u/lYcW+fzBWD/C+W8YBaiiLxJrctHJHP2h3bzojIVkM0/znyAK9w7ruwhBSVvZadiWUVlV6vwRlAuW49LNZ2PqFFed1jpvToc/qqrJgntA++yFGNq3AA3KS3DYCzFCZacAukQLNZO01VBPuAsbPkfwV80hWYiyue47x2zXnspUUcJ7GE3k+BYvwigkdq1YXijBkPCkWVVVRbPf9W13pmSbKhiPuGZHTGsGdwOOApnHxAhJKvrY4z69hXLpYxJP6Kfk1rrm4gLs1xBEIXftR09FNgwFD+Nc92NtYx0FduMaGXIO/RWK+znC4OCklyU1J0MgBpZ8KezGIb4AFcITPUV1q9g9wtVYviWnQSBjKHPAX3VIyEiEugJWM9OErHk8O2MZAEv+rLfjgLj8v5Sal2VBsGWCiWNQXLP7S2nQ9XZLF5xjD8s9FfNO/qerHqAq4jmwYbZP7b1pP/fpmB2sfn1wnZF6S2GSpTAudu/vk2RQP3mPRjQOHUWEJfJ0UUtB+VC6XVFS4lxcBsdXRtd6tlkUp6QI35tCaWwiFyiVG+kaDOLBQI3/maN8cz30T+YJeJ3BvQA9inQ7uRhe3+yc/1odyQ6Ka1HFYh3em/bpm8oPqbEFncpGOy/l1BRn8Zm+b+UmWuCPtfjLd3hcb+k8F4c5jPe+AmL7BffALtwDzOWP6Hl444Khp84pPGhWkqtqzBEjHXMqEsjOFHRiFHmWzOw+Kn/OcHl6jWW9EdH9W25YNGZvxGrjjkhAF7Owwy+NGXSMsA3/+9BZId5D/cpQwK4vL5X+DPuDvRKY0TH6q05jmQuVh7ktJski4VTcPyyn57VASaZU66hAzQuXCDrEslIM7yOLEQjMghHgDRp3aLw+f9YIKiEc/rLsDEIfv+VPye1BGjMKrz4JBGqsAKygCc/NuL7EjQuWzsXyGT1pdJXpqY9vIn4jvH8c9I0EF+Lj35gzb/w1NfNMCScKVrgm+O6mDeXiqySl3Mi++9VbOd79zyzG7DT5aygC3DVrmXkDxLoO+AxKQSxKoACwCRzJPXKLNnm7I3BasHltuhKboNfEtpZBPafJDF74pkd7vYML1hPOXGsVjR0UgRtTFI39q4sP+IR1niv8E4CX1tI5E0RjM0Vea3v1VWNea7nPz4iGJXA0tEHrbvhZIMoQyI4tlvBuO+nQJIHnMWcmvO/Wiu/Xr+PE1w/dIXGPSuKxAOEiJ1SVRkblwrIruWZgjGL+uFmJp1ShefOIbQNtzvxWT5EVAUGFVibw2srIB+0zxqFivYALhhRFGUrRBp4Z9dBjPLmjuUhPuNPBdDYdA3mIF27vpm0/Gd52AqU3AfIfQXAIW9oOEctyWqp6x7FZWSOk278Gk/j015x1fNgMuvt4wKcprTQMoKTvcC5NGr18+mjFpZ0lOjvy+aVkPox6YHpu6X4hPCYpzuQs0IelpvRn/0ml+ZafvnxSMJIRk3NPKmfJj2YmvpKkcYcLC76lCsVMrd0qvc/iLwjgHJnOOKBGf5ttRf25tF/79C6enNDxTJBb/ig0ce82QYWaHL87jmc+pUq4QDEblbgOzY1ZAJIHlLH4M+CICP3TANrB4r2W/lcVGdPII604CNcJgmvTYATnJUPXCTtBccQY/QMh8ts86VCeoN9hdXaU1SiufRlzWttM1pXCSOs8Tvj5wCtXzsRqQmNG5ddi/CC9VqM3jeCCx/KOmW6jyMHyYrdO+YH84oEEvWi2glngrqFaGYlplUyr7t0nOLB63qMlMg48uW0vEy/Lk2x/10zvpQUklgewTzdz3PvY20rPDDFfCYFhkNiswvl59+F6tmbxSKyVMguglMg+TrRi47q8EboZeq7vK6sGPZkGYBYOMEw4aR9r2/aUanaUNe5tcnu0sUJdWmhMtmnt8axTdvDTPwF5oSO+cw7i5v836ANgH8ldn6esiacNhk6dDi0z+72u+M8B6CZJdkY1GOKuKP+IVohDObrJjR57nLAZ+Noou7frAZBNPlaDxyNGtvZUyCH0rMocLD0VBCkcpasFvjOMDCkiNoPdkJpMr/hMU/jo/3jBlJKpRn/75f+CH+m0qF85CwQobJso3ntShocI1ZlH+np3kMCNhwH5erKM/Tdk9eB2YFxpWtbmxn0utpSL7HDPpkXeaNceR7V6He2IP4+18G+ckYE8zX5z6ODVv1LafFsuAfaicqmRQzGJThXaV6LBrmhL9iqGRIH2qQkTcBsyMaZ7kfen1seAk9Lo0FLQUR/6yut55NCppgakmHTwgpac6pO2PACOm1x/HmMYtsjX6IvBebUAFf1/Fyr7GY+ujWzde+SYHJuCFd5ff597UP4qLJMaiwlz+AreJ8OU57j68XtIuV/YSlrtW1IPfnIhub2/cwNOS2t/M1kPax7O9oosd6lPponrpGVleknZrdBXYTYyZ4tJWR272EXkx6YdmGXpiYlhbLCYJZDmCxYuoklXjcjP2nqchGkDMOKOnfyfiNTnDrjJWGrbLdUzubPcbb47bLn2Ku0161dGJsRv13iEP/pr/u1mC3UgDP/fwTfQUDG0h69pBFMlUC1W+n1fcfAnzobyLbDH1va6XoIVD14+2xbaWyyiYj9IBu/PUjjmRUw0S5AdIQCd2w5mH5mvbTRpCkJO/c/Yxy6BBT0hY+NB5WEedQRCY+6E1xuPjm3w+nDxP3H98oGVqJldKnMUrtMHWZgDqNkDTvy5zfsbEWTGD5sQFRA2fqSG7yffWfoS3h8TvWbBniNrHyKZGLouOLL540fkcOTlQJ4veIwrTelpmiLJbP2AfwC6lNFDcVDa09WfpYlGO3uRafqfcTSjfnUqoxcgT3CZUd40bRG5GuZazf9jW0SBPul6XLx3Kj0/JoMhOnTxHieMFOa5WXvXHsuSR2BGGO6Kah6nGddArSFBqVpL507YXfYl2MvbjUrguXWFk81vShCH3nlws/MdOAOE7JPjlekSB8/48y5TOjYv2rXe44HgoNqbZcPCrhTvzpOTCSTsNn4ANTQbbxwX45HIBK2yx/+NFPhw+f6czhlupy3Sj4OGY6tbG39see7/SaP9vdUM4J6yTnnUNoqhBXX1OftfvuD5rT3K50pWuEWYvZHcK/7YqS/bJA9QlirUTwSH2KbehjM5d4xWeZDaNl8/jsc2DUbDgFbPwlFIyOtT4yqSWEQ0seHbioCeHy7Tn5E4O7qaeNxwiCja3s//x7zC7eizpJTix5XMPOweyUIzjiEkVZ7w5Dx0jRNyUzUi6niDDPMQ5vSfn61T0UL1lHZTdiC/Qwx5z7G5INMEsO/qSlt35Is5ZNDzr32x+gQ5VoShmSt8Rgd13hpwmqwVR2Bd/04wa0z1fLYhVj06ZDYIswYsVaOAKMKEWeqRCQppylDxfzlL54PW6donbYYb9M7M5jhVHGkXFM4pq8WVXh74Yu0S7duYiZYO3ysWdLXvKXlEnH7eSQ28Iya9ImKmX3sp4H1zyeMcoZB8k9x6vkHO8gKxDCVAybU/R6kFez705jG3kDgsLdTk5ugqYF/7q8dXEf1JP53OE6BcJ17cfR355Mn5KHqwfD2niNfMH4I8NowpIu1MO8N/W0dOgTtjxRYb6M0hDeOy3cq1K9OK5U5VmR54SkbrXXVZ+gVkCuEfs31TR0VAlDbUha6O87JY5rtCNY6j6Zw/APes31fs+Z6ZVBWDPTJBSFskrcNU0aokoHhAdaGhErmPwWywlYxJThscqXNVgufkTplIc3Mp8d4IO/hsr7E1tSvtUfO5jocEcic1oLtKQ5fL8yDkTYqeuxVPDaiHofUKptEWN5m/lO+i1JiKkQ/7G5r5hMp2RiT5S7ad8ed+gbj9D6b0cQHPfL+Bby5cO9udEWWQ2N+weSV5opoyvkV4achzwzibe0KylfPo/BOV7kuXiL2O4/VI4NBVYiwfA0tzapKNLrOSsbVq2ItXTpjFS1oCK7ppZ1XXrK/iqjoBYYp+Zn2t5pun+fr/yAPoC/xdI2tFmZgMqECLBK9slpxgBZ8Rdhd0K3U7mc1ZvgQaAZrgagH/lf6CGa9bBEzfupMMmi0Jja1ecKV7uMPMZD+8AWWAZloaAFs6QMrKjTp/Xwbkx+RKV+EPlLj4f6gtkkpUP04qTNFqDdSKMgzo44pOGZcZUeJrawisoOl+Pln0Vw3NRk7rTtXrPHXmsGiTeNFB2m+CliaD36yKvczk0YzgAfMoKhNnVpqds/rzr/78lfndxP8X6yAIXkCDtnbVIvKpl6RYb94Q0UJ66eNmuvrZqPWpHLSko2avzIW4Awcmxnhg5bICPknuG9P8EAhXLKAxPRm9NoJ8ChmMG7+DeWI91tgMnVM9QPiV6hYqGYWwNG3xU062myWUcG8ScN9Xpc48xlQqodcZWS7j4wYa2j0oEF4m5jZ9qAC4Ao+/k2aaAIWHXlq+z4nLZeMV9bJ8fTrtbcKSnBYF+t+v6ro0O2ZonSg2H6G3WzIu1FNOwVnvbJ2TH2h0RFc9H4Ouh2WveYOYUaAidT2tp93Hnw2rjCB9Zzj/VExU/srrYgi2gunhejSWWL7a3NLeATkVA1UbL7h7iulyowTLN/ffEK6vZnscMgwk+B17Ab9KKR3IWgAZ1Zwmpk2nmCgAZO5kiG9u1ivtLaqk1AmN7I8nM3+q9pvXsWc700SUKgNAF7aN/hHLjAhTkf7aeSjfu3YKAB8TnTbgihqKDuRafQ/U4o+tLm0wa7CRXaFuybX3ON0hoaEmgOMJwG5AOwhxnBbM32GnZXZuezM5Vur4AAAA",
	dragonwhelp: "data:image/webp;base64,UklGRoQPAABXRUJQVlA4IHgPAADwOgCdASqQAHAAPnUwk0YkoyGhLTWM+JAOiWlpzlzj0VdFfBnyJ/MP2ziBxEe8f9p62P6jvh+S+oj+Rf0D/Y/ll+UnIkgD/Sv7X+wHq6zUJU7LboDfpf0e//H/W+hX6w9gn+ef3D/sdkX9z/aA/aog3+9Aijm0uVzZOgJcnxUkm2FlW/ykz+sUq0RKtWrDNbcs8GNgo5l3KC8EeuZAJgmvY/ebRN9eaOP+T9+03U96wMihQ55wVuAb7XI+DN4CKcbw9DaDSVMgWbitVgN6zD1b7iNmMUdg+f6zqAbCTsElXnvFRBgmhwIi6dzdE7iVafQfUqtLafOFiWQ9shgjPxQtPQMGQ7vBlhD7cfZ1yTHMhPJA9o6p+7qtnmPudZFS9/yS1930sv26fNZ0vlVnYqy7Lwhh6089lWRtofmHBoa8x/s4kF7+dDooME925T2cRvyN/P/c1TlHpqYdpn/3HvIuRoJgHjPE1tSDS9xc9FvZnF37RGdJPLfh7mUdNuzZxUa/tcNPcLP2MF/4M1wZezo7ZH48U+uNazUNklO74xig/XDWXon5B2PTo0Iy7t14EQkKAd/bFDsWzP56eTP/1E9c1eJXMv3i2tUlZeUh1E6TdzywJPMfu/XJ28nP4LkdabAA/v5/MTPIYXVMraUYrlhpBaXXA1r6oxQd5RArxLcPXpsqIQ3zdOiZkpONjuwopP1LBBQpJhEEeo/yaPDkQGprgjZ/7QL01R9vfjYwGyBiH/SdRYjK3ugu39jazGgqxw55CtXc+DNO1NxaPWHgHfjJtneXVNswh4KNKvF5krfcxb0/0VNtAnfogBionLVX5duAQXT5Z1ZFuum/1SvNPOgR+J+OcmFgr+G8UGbr/J4L0wY6FhoFhawNbBDHwRvKU5Pr+CulH++JG2TiiKTM68/UseVZviEZPUTn09Oze+7XWpJQSTzDlfx/c4/7QFz88S8B9g6tWPRnXgoI4x1HOUpS9MpRyD+uvpmlhEiPpP+ai6qF7gyx+vR3kjhAPvBdGJYr2t79ROXbUgSnn9gbgnKez8hXRcc6Hjw9BENCD/nAPGB8yYxvRJZts37SvA0l+yhGXfvdjWqOiaXm2jaZ8knqlfhKULQH4k9OBv+AK1CNDarMRf5z9frxDUPCuoyQilOd0pDldpoN/lvXb+1TsKfNGeEhvsnroixgCIgY/Dl/aNiSGL3Kz5QfPNJKpurc7Eng1IPF1PNUZa4KJLlamqp1cv4fP+hwjqCp+LY+O3m/+0Me2CTuEuvUqzyDj1mECwtAJrG7ZNOhqPx5A4h76v/FudT0qPjjgp+x3xNPSyXGozEVjMkOy1fb8WN5IrGiZvlFDB7uxLEygZN0Rfevt/db5wv6zw9AKUZqIpDyzyjm+7I/iWife/Zv0j1ZPTJQ0B+AAlpyKeGMvDytOSLy3k/vowZqYeWgXtLBSsLFvdNX+whzG0v/B90h8GOchKrjj/ws1t+cuqOWDnATommcc3BtHAextv9KHv0v8dPpPoecfUdpVnB/vXprAYCH/Dl9e4DYzPh6PSwvXgdY0JzCFbEJpyglnilrEvY7LSCcIgd2YelGqckMRtu0sOD/tE6PuOgkbWL/qMMspFlC9VMfWJpHgB6h6fv7KAxQXAu0u2EQ4EY1PzfSmBiH6qcWR+mZ+mTI6QeWJ1WtTnkH/XYpyYttyb/24sH5rN2CpY1jA9KSZtOpDeSvpU13l18mGpXSRvOtbqSpNuT9Vj2Ehdl5hyBdpK1Spj54GAS7Vyu/RFlfIp2LD2vXkIAXoPi5krUuyWmdSJ1VuYsxeWUL3iqSQ4HXPkYHFoj/TSCsHel8HwaziR5ONbweRbJs+HnXoqYh1LclmHKbyl8sJNUkpCYuJgZ8w985wmIvjEQeHG+KKhYqMTxmunWZ9DkNPwT+R2R56opZQX7+HiLKun+Rfn7tVRpxQdrmf2MC7MgDinBBAp6l/n7RrzjU1QZmN8a9ElDgpi6ybRt5zAiyN4vrbpwMJcKG1G6/rcAVw+KNCgfH2Dt0T9+HiW/5/1Jj8QH6AUDqG4W0jtzIJFbeX2ellAmwd44uFgtO7z2W+fckguusb61zC9HedXzegpmcuB8A98+94VyDPIakI7jp0f5BQKsCN/2RiRXe8bLNE8HQbZoTeBWSSYXwV+K1xqP7vK3Ihqa4swS1YFa7CsiPYFFHTWzXpK7nhu8Ul58vpECCfC13EcDhHV1SFrqfmZiGUUYJdEBeqVUCg4TqJGE3NEgjmfc6fQ+SDC0HZMtleGs/feepm1DIR5SNi2jW8WH7fnlTMPTyiDv4V/5XGOHF1EKDMrtYbfP8Mj+IuLJMJEQbGhZTnVnfLVw4bcbIV0JlOr+ithUkZe8v0YU543V8eRtn/QtOydnBpQsvuYMjMbNnlE4snSh7UH56CrQSn9uqUXpPGyKVOgRkroyE8H6cJY8EKgnprh9QZVgU26+HVNO/N4Qklzc/gVnzKjAiX8vG+CDB5uhYkpbqug7MkOIiowRP7wqMe7ycekiUI9Bv0o6u+0BFlSgm0Jz0LbKR80cuaR2hg5Lw9OGIV2FvsaXJXIJIynwXyjJrubah9PJ9sIC+dgLYWBgAPj4nflEPGaMv2k9a8csjbOGeGTVVqa+3BUoBrFG8bhMf7e0jYqr9zzNtzX0tsyC40zIXYwvW10oZAL8Gx7qPXlWSyPkIMjC5Oq12C6gi7cjWc4It6zJCBOZlCZ0C/Rc5TULvVqL72djcxkz2G9D2P+95akMI44U4rVppCq2O6hbrSdzC6NKomhOvUPIze3ikFEWlKh7Tj7HPpQAHenG/CY5aNz6sb6r/HGpIIxK8zwC/BQWmSmFrgGg+SvnWVIcecfBpY7mHDKAYWTFp1CiUea6bS6qtlDx581P7vKGzTWMjs3nObIRZrgUcALFHiEdGKOfgSAphGeEyVn8iud5tuZMpWNqXBEyedKc2nvLJsKplFgHbGpZfutgGv8ruchziwBMqC3Z24paWfB3nH29gflt157JirfNYJbu9sHY7BvkTkl7HoTtjpyzbesA8ROxB5zJxUmiKHMCSodOE91P7669Y+J3Yl3g7fcnMFyIgwypWaFjpoDHnG+nVMzEMstYBMDZW2zf4oE1KB0t0gR/D5keQSunUyRPFq2Mo/nF1DLpjQTSjy8IeYbjCCvgbyvlvg+c0oQQUfErC6nltLT92rwz0ffFTe3hwlG23sL7DhH/zICDHfy7U1enUK5lRWfAFtxX8UEkDq7+CZH2uc5vxQ6TCx/bSWAdAkxCL43fkdrSm7t3HLK66kPMdwEuX0rRUHbxF2mSeSzkds6avm50hHvreuMt4aAeLEzxwU8zy5p+9HPLyeMg8Fi3s4wFI2Ul2W6TS0wG5TdftEeHnQWRyaTEpA5/REEPVSztMTvj/202BhGcEv0Eaa8rlNoFrhuGWugl97XGPLp60AUPqu45dwQBuimMZ/UhXFt4kMb8UhX7KPYVruNSRp86spl3p9KjCXz1TidYZR1hGdpWl+XTx4IYzCi8HBTsHIehNiM16+Qw5B5OcyEFali6ikF9GZ5G3aaZVZ2by/pHDz/tsUzVe7C0x35Jd3sWsuWb02HM8Gsb//iw/oXeEGOUs7adD/F0NA+ZFs+dcM1F5fBxvPkqRXUhGET1X6C0Zvl4aAPeuI+7kOnW6Ya45JQvO4p0/y+O3gHQmx6DFWBl/lOHD22qUlEFsQkGt6HXYm2+tubNT+jGQRwJIXu7EOdmqSc9zBvqJKF1siGgFsRynGjwDhSt2rPdr9VugWRr/mVuHX4jNZYuWaQcBx+HxvjO7PXseh9vVywlG3IxaBbx6OcIjboXa+pZHWu4QZusKWsQx6bPYMpQU9KpAlfKdpBj9sEDp2dLYCV2RIE1iOrfI1C53nAUtAsByrDWl9qtqMqvgDTuXIYGzR2b0rV5PzzW4CxDY+QC07gO9kRc9bMAw8OUHFmK83uPvYwP7g8zZo9Z85Vkx388AuJ6dd6U8FsoyblNzTM/JKtUXS6XVIHY3K5UEaXL5kc1S3FQ+kCQnZRgXLw08V7L/vKhKmbbMfeIZD/HNmQLIlENmu1LQF0RUwXueEYfG9oJD5F4a3VtaQMhTzEiUp6OBoUMCRtmvqd7lLfb4VzfkWqEVYRELDuOBczBTAKdTJFbP24LwtFnyj8jyWdfV091HpElU2+NIV8hrVEKo5rV5PqlGx+sQcsZmWv4BrZzdsaEe2oNEJMOq5drQv8RyO8kIJPlQIODGzGusrz/DWv3frXvPAxqnagqJSLRnd5oy/qu6mU90/W7TUXWpl51/F0gwOynHyLZ3kZ3elh1BA+hzX8u0f+HdtkG9gwcLCFQ52jDsm6vQc8LFLZD6zz/Yj8HOCrcwPodLYkSHnfiuDzo5duBEMG43HIJivDxmZ/BIoSSYymwn4acule3WjYLKh0MERRQ3DOTQoK3th2caQ5V3Y1O04nfLmDsreR85q6z4qaYa3IVisvo/IlM8u9Aycamz0dt1tnhHaN5yGcUAjn7Iw7wSk3UERI1jKTCsVgq6H6ElCfCH0fNJapq7qOicGJnMfjx9haCpIylB6m2X+z1IOPwiRGHbTSccTs7wcFsaPwtxF8Z+oXCy1ftUdCnYY6gLho5ky/1XwiS+GZdRPjidX4nZr9y7yU2H5z+J7cGueM2u5lel1gwwdlssoffbh3CAHr8XMZqpqfwdArEK7e4lQ60JWdWwz51NkEhw1Es1GOk4re++4KI8nTO2UKk+SNdqwLkSU8qbkSBwIJJITOoOZDAfkuR338fABkxGqubw7QNlXBS5rQv1/xRoey7JKN2BdGAo7zDBs/TwECmg7RhtiGhlId1Rrvou1zT3cke9UGop1sCicj+AVTUleeyV9baMHayBkn24jA9pIdNGXdb4i4N/ELLOkMnTTlxEdpn0dPoAZHKVmstBhdJwC0qFzK9TM1tGZ8pm2Nd5AAqYhfXKRRikTsU1mDoUjvAgXQt6azB0UpKpmx4ON/DnzC+Nfo3+pYsZEZXJmJ9OgJi98oGo7HxAsjs2HNJXlFpWHXB3khRY0UoFvEP/sYGAfkK4nZ1v4UM1D+gLovLMt5gW7u/BrB+PmOLFE6hWKWngVmCC8yA6WR/UbseBcl9UKTvmQ6uhAPzad4/RrX4EA6NTs7E5PqdoFyWtMuH5QnbyFpiOU4FRvkw/W5mI0oMRnyMN2WLrnsXZ2DOghEZ+u+BkkyEbIVI93HoC74ClYflDdLRAJudlyzS1iIKUyx71Q/ujTbRTMDCQ90YAAAA=",
	drellen: "data:image/webp;base64,UklGRqAXAABXRUJQVlA4IJQXAACQTACdASqQAJAAPmkqkEYkIqGhNbkMmIANCUAYdT1a+9cfzPm+co+PAI2rvp18wD9aeoF5oPOU9LX9735X0AOmLrxz6P+QHmT5IfhP7z+5nsH4Z+znUO+Y/jH9z61f6v/o+B/y1/z/UC/K/6H/vfmq+t58W4I72f9D02fw/MvxAfzS9g+9o9W9gD+jf5b0V/+3/b+gb6x/+X+p+A39c/+/2Lv3k9l79wHYBPbCYluej/2OrUVr872LYbXSD+jk/DzTEVGw7d1c5JBdGd+gqU5MvmBIlBNTr5g1niKzp09lBWw0cTUowSLesswDQTvJekBt0nc9sMltBxAsWnil5/Sv8KWuCVosZvyRXBqkG9rAD9qWJ+V5PaUOwuF5yCHR0ACM1C5QsBi9W8pwBZR4wZ4V8xTDAyqEGVwgmVtDk5id0cfOMKT6ZKsXYS91kBY6E3o9Zg8z5RhT6P9Ckk3ujqraQIKo9+XEcl5epWHwE2VvM3AOuESIueooJXgd4I97TnnVTf34l2E9jgGcB7Xqp8C+yxyl4ZhpvbvY5oZq8V874JXCzMuThjx7iloWiNnKrR/nTymXbYkTJiOYzVX9nb/UuzpYOrbQqTh0JkpuizK+Pwq7c6TQD1NM1vcuahzmvmyv1gyP9g+bS2ADgxKn6xDQawt97ZbKNO9dvARw5MPPTSO01KsN+wE6o/n3VKxzKY+1r3FCKfvIhv7H7ZY3FVp+lJXI1yufSPg7T5iPqCPwktEH1+tcucY+WLe8LHm6hy649MKl3nSXu3QQ2uJBdXq13D7crBjg8dLMkdDaqgmBB4B4S8XHkduQV72+OAAA/v5V0B7ToqkwPTMbybx3rjlvB8UpYc2PJ8SFcT3D8UvNe+e6+30h6tvFpBO/bn39O+atdOr/lNUdm8bY2sVt1lbuTIldWQSykgmi29qfLfxtaNdfhRji0T9fFlGHqYeqLUB+EHF3beRPi6m/BrHg/cZTQm866rerBHb00P6yuBiQdZb/5UnyA3uSp9MycvQZchI1xfRxaLu+yiK/lfn7CatFyUYS4mCtIDmLVSnIdnliEwLyRhkBRyKzjzTrdoZdN/yyoafT5sIhNhVAG/6P7pfYmQvn+2pEf+dRF9APZPK0rzCuR8+skakDGnfX4OHyvWPUiKt2Z9P+E6hCwyzyLovJkMpammVANUG/qBseNxDZMhFPQANq+uNGZ5L8bMYr5l5EoI3hgiKIK5CrcO+aAiF5/9b3oVzfn71RygxDrosAEIUteyddVdZZr9MarxdDE8vwl7caATMto3J/UNwajn6EcKicwgxSD8BC6l8nU5MQMz3XBRrey7IOfCxkU5ulgRbg3AKoByimHAB/5T2F4+S6rH65L1+ueu9rx8uCe2adPoq+mdUVc53T6WBeDNp6hm0n7ZZ9MhtD05cQCl57TgmDYErRasIQRZ2Cv/C/X5GzfzGZ2+P5ugiB+Qw/jPUQBIi3u8PrtQFpoEhBSlphd0aoFqYoX0pzJUNKo81fYDudLq/MTvRovlI7a4X554248JiEQSwqagMRWbDMogKN+Os2GZA72qWuI4wWbNO7vaUAr8HFBJnqC4OVnedqVRNqEJMuW/dcZmw0A+uVcSyawIR6B1kww+VwDxahy3bhMglOtDTwsixntv3vn3wYZsjQ58S4DcWJUNFniMqv8mcN22qSj84GJdQvYKcFZWn7SUUp/CrJ6T1VlHKn91M7h1eqvmClgfbrgPikb232Ft/ycf7wVDsUR6wDE2irPOX63sHeWC+uX7f2nCd8VB/Knl57upjoNWoJPgEkHY71BHn/ojeESQ92P/0mv5e7HMwf9GZymLlR88036juim/dMnw43dP8M8GB82pcc0vL1Cj4CJRgpWSEButSXhz5SA+cosMoaS/7mDdyBmMzPxo/xQP0JLga2cXvlO+GHEXa7PkfwQ9E2TbcmvKEycBzHgVVPVMPNpv/Sy77Xa7VFgkxEUJWPF43n8NY3qFrUHzRL8cTVRgCw2NFZsrLpHkJV1gKzjLqhm56b1FlfaI4rrWFX9va4/KaNur9bBRtriiGY0C3pvAemIlsQriPn0n2TeF6AZIQRhirKi9AQPcMNeKUUUsngHMCMAiOOfxSbEwVKwVHtpeVDxbL6ynEyGBA2wD1P8sNAqh4sPdYX98PcJkd9ns8MJ964gzDelj/7anK+iZ/L5/KxIRKPxnU8MBtlCNuDHVob8AkRaLdAG1N69Wy7jLfArLgo8L9nJa8DJrX14GYjUbbdb+21r4VIqKZG7EpcPdjAQfvdt/W5zjl0VG7qy5I/tqQMfy5Fc3bqaVknIe9CAPgX1Q8K0kmjXxc/BOzKIldVH7jboVgLxz0BJ4t1jjJY8XATX6TGo2dhN1O2M8MekloftJNCk9nnG8NCwOykfcee5ofcl8tKLGkEIYrk4/KJLnc1JWCj4+r7Ryi1TbgdqRZCgtU7EkIn5eXjl4ur6LspGi+dqKKwIpuH8ahHvne/B1DRLtYdbUHXxszdVZUnhkoqUIEhjIaofaRP0CxW4bRUPKrqPxCxAtOclbTw0ZdWjEqYxDc3xh/xI3AxexptjsNQsjB2snH/U4Yadxtpu3pXjTHlhhzAqN8F/uoVvcl+ptMhipDKcon1soI6dSGD49LS9wr4HcTIyeCiANbMGqukj6zeCh25s5brKusPa5VusNylHrXChM597JZo9qp/X90TqxyJYzLlwN030vivJ+n99gWSK289BC2T7dcQQOLSO2JhEVTTUx2+xqmNx5hRS1XuBUFQ4wXGlF/AklPdvsofS4cTR5n9SnI7Kr0i/h8gB0UvJTHa3T0GgNye2+XRSgPN7RNnyOM98vey/F6/zArR29aERr6APL/C0V2Mx8B/GOIN6Wi0l6Z0ocS4OEkPz9qEtAbqqllQvqjV0XvFlmBrkFZmY1WyxrPv9GqSAW+K48bYmMbGnRH5G1fNLNMXqbkNW52eC7zKbOtNHXMoRzVG/g4X3JefvFvPRu/P34Gy8m+Gwk74D2LKt+2BfuOr/NMYTQ53xCX7l+aCBPYlgqTcZE9w4LDw/C9F/7gk8FgwaazCPnCLl9K2sXNlEJBZdAJFH8SFz1u1AAFAE6zSbYX+fINJtBFnfym3pa0dCTLzUxaiZ2sTNb9sXEgJifnbkTGu6OS9R3ifMVyjmcGNIB6yMF7V3OsqP/mvBh47TU29xo2H4kwZSKaHn/sUjGw4jKTODbNC+6XQCG1czTJkR5WxT+hSXxhp3OEz81dpR+m7z1WtZLR8FYXSVk+pzG1Q3NCSkbL3DJMiO5O4oVCU9VCH4c8EJM6EcqLJ5PKMMkvZaUIrsQb3zgDpvhdAqpJ/qWhbQFesMxDXa7AsfOVZvDu8vzr2AOgVojYgD9JB1nuttgn20xHKuy+yoXgOh6sN7awAFU6CR011upHXcUGWWtX9R3eGWIyGmXgIpDC7aPa55RSpKMG3bMs83Lko1+7FNaxYpQhujTDGbOd1ZJ7eEbcrCO0jP97XyfLyLxv2Hj2lLfYsi9V2xTTkW0sOJCOwCo2mvrANdFh4pgHhdf3Mn+CDJCekvsouWn5WJMRT9KjEAPU2f+6dzoqFT6hkICVSu6d5aOCqZtNv8RpNDS3VtYzEzHlfxx01qk0k+XAXT8z3n5hEHyQwoyv6TkeOwO0efgYcTT6r1/X6Z7X6J25y6NLZPYRgkz+p0RJgMa4mIwWhg09u6ECeTxvbpdZiD85TZfHsdyQOsdHaLz4rGD/trAa0JmWyaGyAR2TDQ8IfLTUr7xybkrK1jXq8MHzEi/zq8A7M9QQp06fVTbvy0Z+Y6Gz+prvejDy/u5iQ0OGonBHsL6x1/V001fcJDpUY9Y9XOFQZymIL6299e0KPvf6mksTOMl8CEoBlV/jdNyIiyE9LlcwaAwjWLLtjCKrWIhkBLAyh2ROLbd+JwRtsgIas3JEqxI5+hMROO9bkUFummlpws8YGFfUttCz3Na4Z0ExfLtOKxYAYIXq2vZSxLDhYqA/m7icwkX003UfkXCLB84Bup/LEQdhUZ0koO4hCN/gUQJNxFhYbjJqLYwTXRm9qhBUXqRG0Lyw31c6mhlC2ka5rgkOYn8tODcdVhHw7b41PL5MGFvLB5vj7NqGK1JQRScw6goivmxxu8CkLI6RFqGswB8kzHQ9+d+l2LXNJdoH25MOrzWLmK7o4plat8OAW8yaah/eQbab55dvaNHUhQEAa3XtksHGxs8csDdv7KOoyHPuMz9yDsL1v5iUBnP/5E3jztXffKcknf1ZuqyeRvFLsLZqV+uaskCg9O3k8e0po3k6Dhp/+GtQEtHup8EN9xm0Qtu30f+/wmohZgqtXeMXc9KQBIdHl0ZmD6hmwfpGKinBfRvjTVGMBM4Tyz66D3PKtVb95hRmzk0GJ91SqsqTZLzFEjrHiuKgbn4CLUAdIWHk+cAEacBiOh74jvc0XjfikyeuuOyeBQrSn/C3mFA1Hj1s3UU9PdFjBzxMO4d6hwjfZY2k3NfcZyT0a+KjfEKrhCkbrhGN1PvSVOmtC192SPNbU2O6/+2/XUEa4+JVzEsDLDUY31FUHZcvEeCrzrKDVQBWCKMZAxaFMQIhUy0ROcqhdoqgHbfarDUFtO0uyKjXPXyiy5pkEnvq8TvfhJk5d0WRfECqcpbCPDZKsh+RM39Zho5T+1Ixrqmc/epR9jfytoAILYhqCcnlQ3pu5dTtjXztDCyD4lpaCiQo2bkLp4iycQjBnMn5pPduxONKofl5phkheEN51jVnItMwfUf4b0RVO+PkfjLSLzJ8fn2MWjmQDbtA4crVlbSpddlMN4MrMWJUxEJa/U2w20QGqja6lqCzl0k//jE6y1FW4m5I8MIXVjW8gCuMW2tveliWbnCBjvkbXAsEBFlsZVtSwGBosVE48KuMxCNQ9TcnqELgreT4lzC3ZfUl/HglPDL6HIp/wnSsGUYbNEPhZYGbA/vpjLLp/LUzs5JAH9W6NxfqLDEHbyRQWPbkkdh4YsOsZVAoqe13NQgTTq84xBf9m4b7sGQMiw8j0afdgyCI3awWKtGGnAU08M2Gyr8dq0pTILjxv+2gKsngisERbwnLvx6UdH8TD5wzd4QqPP5nN8IdJhx/IBcNyBYVPLLOWZ3glRPqCz9eioaTju9s7QLVfLfr0ZFsi060WRjJ9JYovvEsD4szrd/xrIJ7085NhUMB9NUzHObhVxscP9IXOLWjUn9dSJyWFTk7cRrGAlbr5Zf74vjs2qIuhMCUTXagZ4xdUR53fQ8NOruMC3TVnUTlClPdGpu+erVzTgxWojR4qJWBTvDvSQM4+AWZQ9hAVVg5NMbRkiDkoQU9vBgfZ01fkoVjp45WkOWycLM7F2dfghasA7wtKfE3bAcpeoAU7zVJGZLTEYXQUh+8Wxzq0wWoUU2pHHTTA7hvDCloIelxU+eUGxMQybSEX72/bkAppZspkcm9lNQggO373TaIldK1L8J+fdixcdQxTPHawEseWRh3FOpw+Qjte0pLz2tsOxzD5uHwhaujPXFXL9GbGFV+oOmo3n/nK2ze4kutZ4XY1DjQvsfsLCz/GqxqmRg+Yd59Al8c6K/zjvcHHcqcQEdxVA3UOZR/XO8pXKvY8gSsMX5pgoBXmpA2cAsCfheSKmZCQ55pw4yTNkTYG3zHvp3jZfSy1mFyipplaF8cWE7FVelFcJj/bxCFETML8ccr0vkJzv7Q//WUiQh/8O/dFS+o0RI2EaqoCCekYFqNqMpKrLBGwbTT0/jjrB0m8vbM/GfXJDUaWU+7JAs4p9fCLSVphEcZH4n8FjsQWNHclXI6MiDqle778m076xXe2UzyuFZm3/EBbZPOFVmJwO3ZIiG9Sw4twJBCuJp40OmTz7Oxwg38P2bdTQ/+S8HAVhiGY3irxQCdzMKXFV6dMKeSKOAv6CERNJx0FnwxqUs+ov3IVFgIc0KcIVAkR//e86dTQ3XLW4JDWq0l8CzZtI/IXqgxBcs81lxSpQU+/GkmMDL7cpY9qLxVIprcDZJjLN7mh1Y7ZQ2/8ONME/25BeA4BvdasQrzuKkGhd9nvHMZ3rxTMdWrv5l+p3m+3DFBpVpe5QP8g0uFPOJZMrY3MEvn6pBE6Pv9y3d/p3S53AHnVMysG3tUfrFEw4s+Azfp1EMg3IMh3kWfvtVr51gsAmOc6VPtovgLYjFs3xSx9b2+47OJvrol3K7w07fCWKVqVk77sGQX753YFIlRKfI8bb9X+7XUqhvIKkakiy1ZmLXuguwCqmeNUEEpYIexYRqFg/LYzedYG4rfjMEccwUVC2qJDoDq5un0HGB4o3CzucxiKpmw4MrKXEbfywHLi2r34oCdKSrfTQ7BseX0DFhUbR6GwoqIbPympsGugJaxa+rLDH0y5B1R6UO8vyyhTwNxUYdBNSA4GUEKIkquVI8tvTDfE0FvndkbcPzRCgbowfmMyRfmKV+W8HcgzePgXwLSVunY6BD+nQESHK1Iz8VvqFSRsKnfX72BuNZdM1JdSh+Cxz1oMflr1+fotneUxH6orY6zDSiGvY01EwGB5k1jRIhOlO4RB7Bp5fk6nWowUoODFEr5a76Zbng0lGqejHbQCCP6eiAqnRW6Y/AruIF70uxD+qyNoL7u14O2X5+kUeShNEV+o3Rw2Vt3/urwqHBqq/M1SwoDX+tf/lh+1cvAWENCQo7SwYRzXsXw3DkVTZ1hmODSwI9//8+GncyU8GwuvbLlKCkTFPxj3Rv7tFfrnkjE+mD/3p7RhdfcBKk9IcvyBTyPvyMm+N31wQ/8QFynJiljUKxfOWNBJXf2iPCDBnzmHsGBBTVcYBX2nQ5VcNkaaV/WbLCrDrE5XW8EapfvZ5yOeIqoBJzZqqSokaaPEspowRP+7pq0/6P1OYgQbRvsc8eZDZ+vpJSA6fL01ztavgq3laV0laYJFrZEjpcgkvSdOtneqMtMEGhu0MthJ6GgqHxqgCv4U4XUa+8G+3WWGR/BnCwy4XQnMvHksz5OZELW7CoHku6/UHLdbDsX6bBqHM4loz5B4xwWR8vNzOdisBnaGzNl+GXaa1ztUSf2W+l1jr0106nN37eI9y15EInwajdNQnkLrIZ4EDe7ZO9/1wVTKLYGyf5CC3t0ExCEfX7OI+rte5o+LmVs63SsVXvdw9DpJqoHOCvyyJDNFA2GsarMyOSpkybpK35O7LAxo4131uB7ylM+IT8zbI3Z/eRD71bWZMaR1EIKs2jIPGP05DryvtKZ/aC8307KEwwRTLZI/GFIBygSZ+3/T/+UiU05jtJmW5+ci2uuLLH47SxG/i6dOq4Xtx778Z7UtQtfXe2mCS1z5633OfiCRuyjXxM9a5i0kBKM2HItKtw44XtUEGSfF/HU2UpBK4PX13/xO2Og4ECABkwdk0r2wB2ialm3oVHV0xmA94la7efXu7+CqE4Fd5DhMRZH05UTq1JgbSD8a/Jj1oq2t8gqw1+kNQTHFM81wwuKHibgUi9IV+ppQA1HIWKt3Qmt/9pY1xwcCWPGVMs9mde0e2dMUyKNvYi4v9FHasc63F3zY73RmwN5/7WWDHy06OWGJ+o7QhzkjUxt+EzmkHj2+r/8A4i0kG9XD/DEsopsLX5Z39PIQiP+KMrc3PkKt9PnLeHFt5699ISX3xdob/R828C5AT4tNXGXPRP2fBSNz7w4g+FgXOpgrnNu2yQ0DKCgNbJetomWeYToIMB9dkujPLamV98pr4Q4WWf4qJ+VybASaEFagambe3ID6pvv+mx97AlonLftYBAQw6y3FOovpIQ5YVShBN8rOL9zeD56rseUumVR+4+GwLEXoJH6N07Quq2vRs1iAkj35VGJO4iO9XOa7CV1DNhOLW8IZ4PfoP/jOxwBw6buweMlQSLYdkmS+5KIYDYyvjKSfbxRASSuA6yR68ja0rG3aLlO7YTzVamK0aEgWF4Z9uAcQQZ1QfsPhOtGBXRgZbcYC8iyLwdLz/igAodQWVORP/c0B/6JPUtH92tpd9e0NeE9XXKED8DN71Uvo9z86b7agC4jvyCiaAAAAAAA=",
	duster: "data:image/webp;base64,UklGRu4RAABXRUJQVlA4IOIRAABwRgCdASqQAJAAPnUwk0akoqGhK3T9qJAOiWMA1IpPXp6v/p8ONq56c5aXlQvvn/C/kL5u+Yr4x7mcfmI13H/wPXr/Z9+/yd1C/Zf+t+Y7kwgDfXzzwPwvNnxA/zB5B70j9bvgH/TPrD/5//v/Zj1Z/Wn/v/1XwIfz/+8/9T15vZ1+6/sh/ta54KQKU2SdD/esM1O7vCnpyhQEUPUjQ/838UYYa3/7YNKTzpQ1jkRn28rf5XW51033FQSVEr7MKyb333b/yzve4L29NjrJjRhl7aFCcfq56JOFtVMwKn1ufvqVgaaxwrA/14W7AruUEMJB50abnJ+qj1GhAlE1fIbLR7DhHsqat7J/sCEaD5kebba6QPTud26jmkOHX4EbAqd1xEfVpTh4iumHnwZ08GWEUhQdudhlQfjuTmEBF9YfdYY6sjOABUQur5yFyYih8OWfIN/buforh76mSAb4yWTmPW30Sf+O6oEAeqaCJRqesxDy1d40Q79QlEAmsb5Le0igWBeS1lAEsoBZkWTtLAaqIc9PV5Hf+oP//oo7qUVhP2Wz2uWtNgQPGif+tSu9BYxmOeKht31mUM7WdrfuUvmIq4aFFgTeqOMQ5uRqsMlObduM2SlWX+P49eNUCmlIPihMKuVvFU/f1IXRjKhrkASxp8oHoJ93+88uERvLqfzhl4nx1C0VfpXtn0YAoa4Zq5uwqZ4oxnSiVcn8JLbKGwqpS5ruh4H2cBRXX2B2uywuspNahG6qjhv6TNyIAAD+/hSlq3rSJZEUwI/XGbiSd6cwIopiXyPTjVaAUlnKM76L2DuyluGdTd0nUwZweetGrrHw/nPmLgLq7VV/WscnDqozKt/FWdS9IR+FmJv3vbsNiSmML24IX8fs6paXaeAk9hz811bWQKbCwhSeOOtfswMh5rb9zZRDtG+am6mCqvk+F676U2T/L9QESsRDiVpBr10WfOOXn+tQzAseQ4s1v7cKYMNoIOPjH9tkTkOypZcdtD6vmo3kJkGrft28RIBpE8oOKUHRhZ9L0yAWzgzrt4ZWI2Rz1xjbRPRjjtqEfN/MgWgEpVc1MgsUHZlTAxfVkPU6ccrMGtLKgi0HY0bxvh3NOJc9fsLA50kGRtKqAmQveojK2cdqX7KGa2jnFEdqRGyyw2jlv2d7f0/3VckPf3eIkbkJ4uRI0rFfK0Zp/rP/9tpZQfcS6K42PFmnBU6kP6hx2adFwhsrcGvnJyrWrRckYNyXyT5QCRfXFg3ZeBiUtxfRYWeXj834Lm+KO8hQvpbUDMN2OA5Os3PIDNhBB0RYyqEqCDCf76PTnwu/HpXgSGNuX5a/IAWBbHAyadjxf4qOHRGup1XSty/vU4ZJ2YWKNrTKhTkD3gF868vRPXE8owvoIqXmF9obQavxNPx3XeP36nRanREF1jlZq5p4ZpRYQf8EFKY0oMGzHlkb4CgtWVj+6d95QvLRIwJbqn6zvBxtqHHSFvT5tMBCNbGSrvuwj/OujCL1OewaF8IcalQqwton381oOzQFcNsu4XBubahWqLMFIQIEFZb8GGZbmKwKMfAcMEFLt03/vlQ1TXhXKe/TggH6YYVM4KIryow1Vccp51E88+PyRU0lZGvNnX4Hpess92+0GCJN0ZJWePk7Wn0wUMjH++eIHLbcJqObM2M2TbRRbx/2vnAsj/onBQXvBhuLcifmymj4Tfd/imDQPE/TZjCdqq+AUScJSDV7vU590uUR3vco9qsgPzwzwM2Om5WQn6y8PtUeu3wR2C+ELIoPvKwF/EenEeyQiutCCRYQjpnrVS497C0WJ1OleD73mjT+QdH/JUZDIL2O7Gloi33K+RAdlVR+XFc2BoEVkrQzz02JPNQVeRJPMeiMatFpe3iP1eQIfMcaYvnUnLk+v0txCrb7P9LMUh0K5B4aDdjGQUa9kVEWBHA61hqvBPKaVfYdrOngiqYkUDAwDnO48TJ4Obr65hR43+XsVnm5UvPoV8ONFeyoiuj4QEon0GNyQQmupKNToY65eqtyMiNLiePZw9Fsr+cOFqGmUo1g1/h0RGada9XpjxaEZ3qIeQxDHZk7fFedBm18Hj2yGz1aKJI2M9TqAxv+wwuw2Eg5wBrBPVZE5QzZEX2PLOYG+nFPrTKSVYSnA2xqKxgb8QxZgzCkuOdSQknvPg6WhFvm03Oqs0gRJgfs+mJ1pXswudftcBaMfsbbhV6Olo6lK3WmV8UX4GPx58ZpRKWviPQ3FD5w8insurFcQfp1JdxwFh3Faxpb2jmMXip47NLCW/QVjOjUVgXsI0Y8GO5+4Hsa/c7PbbhfoMupXkvIEPoi4TxvJTATwtdM6A6xp+NwgAxAfJDvRVTe+0qAeBMuCtcKaLXKbpOMaaKLT8uDP65kS91cvAXJmh+z/9me9pl+fUy9XpnKv3UYmOib9RlWU9X1mRhbDuW7f5Y5xGer1tba33c27e8SwJD6ADMItzDBFrT/D0txJyWjVlbdPZKZCQzKtJlVP+ZJv91aCR5XBzIImdvsC9VChjkBxI3zZPM1gC0rYoaRcEpgygqPqrz8gw7hEb8jXC2xHbWVp1WDAsM2RSsLMhEW8OPklgX0NB7vBav5WWPQcxKaAo8xwUemqEN5XBTTHzWHkeawOka+jF832heC8RJ4ZcOTuusd4XpnqhkU1ibQ2+gqb2OBPfUiPYoG6xlP0o0crjV4q2zSMyPsxty7Hbvz+zKsbtpX4MkfyEReiG5hNM2K6DjtpI85Hm5avHpbaDx/t6Tt3LWVg8OS7Z/tzl1+QcnBV3G6p7c+VHOqRjxDdISDC3ubBv3VqDDbq1M/oij0Pt7QQWIrqnz2N+Wz2nooafnevKQn/dTLCZSB38ECHRubrVarok4KJYIOGuFn2US3KL0FHlSp7yQKXQ/9RxUZHhQfAVdZa3n+KRXAS+53+m6+is0cTXIdqc1kNX1mquhxlTGZewSkl6K7juSJgnNwxgOIF19xrvZ7pWFVfxnrj87Ywa4rbuH8sdCdM1mo87am66rKUd28aDCwLOt5Bpp0QsKLCQUgM8I7IUh81+sPLkQxbpxcnf/6xEXamDc+k3knJrEonsrmptI9b1W6OMegPSqDl78edL0yrhUGtIg5QNMp1rhJ9ZWs+o/d77NKTuWYVvXyh2Ph3ytw4phaxZeLVZMRRDwZm6W3pRu40SS+OFMh5e0q0z88SrHuLzL/8R6FkembfSvU9tS6St0Ps70YFa6XR3GcMRPYSA7qg/7IorkJP/fcBdGi2qiXF1rXW0tU3x7ZJtP2IwV8LhvrB0ppEfGNe54DNJfe6nnHUrZKvyQQVTjPO3eORqa+7w0OtEVBBGBCWAXK3Oxa9xLI6uSvfR6XLuZBTAS9S2b91AkHBv8cUm5nAAwLt/HNgtGa0zWG/EBTWrN9Dfce4JMIrmh3MLQXI3JZ902vf/Rs7ftjsXt2ItPqB1dE2YOCTNKQz+o1CJGMSf+y78B7KrrWeBIGiVMb5b/nKiOfL14g6E3s6mlZNS/KJ3x50JCfCvWPX9yY1GOfoshZ96q8t/NHTGWjWe/gGZp8b4SDF7qv3rvBH5iNirUHJIPhfDlzwN/lA36u22W451+AirbLf+ybUEvKf+VsR4Pis0jYRo7URygzWjTwXLzxrYPKZayc0AzxLx7PJJBVYuw++OBbf6zLE1o9x1fPYpFja+ckLQxRRPd6I4RMT44QEU3DTbMzySpRw0MEidbiEH+Dez4ApEbo6H4W0yG5s+QQDOrNAOSV4ZuGA/hCvLXntdRf8FG6MLf/DACYvjLC4z+JFp6yVmwAQBI+lXRD1njJRQTCEv3S28OZPlvcjmE3Jl452pq40Q1TUoAB6w/1k1vqnEa7UO0yI5PRI0n5ejt14JXggqd+A7SAb/Wfv+kkI9VAuAOtW2T9k3BloPura1iC2az8NPb7WGlA3AMrGOgUPJqGuFqJa5UAuZhSvBACfKcY17VQ0NqXyLxjsfJx+XHiF8TMsFSyB1drJ7+WK8onPT8A5FizyaFgS6YK/KEkcC4Rp5hGcfX8WRH2zsx+nhHK8jKgGzGv1AZVo4tqfNz3+CqFJhqp1w1ra+ctJTkU/Yx7rtiyUGzpoO2C+Nn2mG5BsImM6rdyFSsZXD3BPeykHi1J61KfBZ1lFOQhAkUSpkkn1wsoM6U0ZFvWegjFg30/Mr4duJdBUXmvFBBQ0VB4uYOQpRI/WAiFV3uikd0LQYGrLrqMpW6qomynzO8LDeVi7PCAV66PYegnDaOy+5Xisb66uD9Bp97OJT3V7Ea8UmjccyHz0LKiPaf00tLEnOPgkRhm4O0Bbn81dziQhiKArcmsk1MT+wajtzRCVQBhsbA+UZY0cp8IfG+5ybXk2CFkXfyvcoW3g81/3+2ikXf3tP8CzZTwWBXKDUJahb3vGzQwezWwodpzfhzk8UdZgsvm3TBuYbN6jCfkiMyy7GjB7q8yXHRp2BDj9YHW45oUDXtfvOgy/y4z2mLrJ0vE+gFz4lM68ARI4AQFCsfJFKYkU5qsq3Jgcz6yo0n9RfFE6+YJlyDpiHq+gkAHFzhDE+sQHebpPKv9rz7czA1GjEPDv9+PJPgux9qu6eFoIVHmWxbY8b4jzBxdtqrdt8RJIK652JnO+obs2eKTJ7n1ne+ldPbRXqgwRKyGpEn5mJy3ErgJ+DV6pKeKxCUi+hYih0k6Hrqm6vPGEBVVfFBZM7lolTgi/ia+/sFVLkTkoKIqAr3Lmq5smi3ocXJIFNT2PuDEmXWVZ6D1GH0cpetX/EG73oFCssLtnsVqgEkLUobSHIOX6XrPoyGoLrcxYBnv3tboYuGqJMOcQIArenikpXvtPi1DWx5UXOvck+detD6XdwoZ5hTZ2+HfXfZoSOdoqvslUilcsIlAcqR6NcDkHiPMBKfLPrCcZVNeKaksA6Dq7/ktHKSil/Jz/JgDOfybe0ld8LBkQcJmlOVqjjU7IVbngyJUd6gVTJh/Aeg2gFO+yeS3TfNxSxq2waaPyki3rqdz2WdjOidFHHqtnanDDgpXrL1yvy59WvdFTTgKL2Q+EvB9Dm1XJ+A6yE0H6O1wZUg2GCUXhGT0xRqX91TA595UeOCr9bkuEiABR0VD8zXlpLSU3HJHZOLGa0MTENLJ4h3OaztoYd64+OjBBiE4hb8UuKXosknrU/O6r9SwLHFz0+Aop3H7gRMoYaImyzalZb+sjZwbgRltY1t7QWguw/WFcI/SFFkB4j6RmEZWoc/MUuoEIxn+q4K3fiCBczCH4Fh72GkYxlILleqUJcHR+aN1YA1fUNpyJPmyjyktdR1/vf3TwibkP636AT3Y66SgAg9ExUb4BkNu5DZQJ4KuJ0KcBtVhbp2Teqez63MP5xJHIyaT+KWqS0DRGu0dOTEBUS7x/JJFjPYKMbNBQv+wTSrQLz2K42gjcKIA9F4Q0oX4++ePbiFvpPXhCnwBm8Uq8YS0pfGiYNaerCJwl9fWnwXwP+N3LnSpnc2X3L0AIXNBqEEGOOj5xtuxCU1KqgmANb4YpdtEnRI13KC7PFWfZmbTVe1/pkTLrW0cQ0OR+e8qvuJ/HPWSSvewBvUDs8MsrePzlPY8bXxfU2VpZ6aNW36OQqCycE5bPupqIx5xIFN5Sp7fTsqDZd+POAAA0yF0v7yeXdvYHGTLZflX1f0rTegEVjILtWcdOdFiA8MlbqEETMGw4gJwIYjBaGHR4itUdMwEizYTqXn9+1oqBTXHlcAbKp+EaZtnuKebXuBiGaJZfn94QuTeFM41a5l4Xi54sjAkn+PhaDiiBgJ1r0KompyCxBJ/8XNsB0mP/1q4R4J26hphImc6ek21HA9zDxMq/PTaGLLPkP3zWpDVgGFJypCo65iPuYd4zYFkBdh7oImv2FLR2c6yPklP8xgLDjtVRPPXu1knfKKG2kIJ5TSQmQVnGnctaIUm7AyzOdzxW/nxDjvp1eIGdGk0lxyTwExFDPqiDnAgNDSe4VPoM5q5PlG17t8PKEvJcnhaoIrh9EhQBVTQMmhRyP5iQsHVWEfmpdtuEHPQea+nh6MJhavUo79quPP8+6Yg3k4DorQAdluoV8l+PiNAnmkERLVilWLW45MWAL4HtjtgAAA=",
	ferociousowlbear: "data:image/webp;base64,UklGRvQOAABXRUJQVlA4IOgOAABQPACdASqQAHAAPnU2lkikoqIhJjQLIJAOiWkAz+OxLv7/L+CvkF+Me5/7j8syI13Z/v/zC9r+/P5a6gv5N/Pv9Bv1oCP0v+2f7v0454X1YyB+gewR5QH+x/7POX9YewV/Nf7Z/0Oxj6VH7brg1uCncqplNsJv6wERDJKzbFpfazleEmn60gGaRwLDZRaIonFnUZbcLlfj9KymeUUOEOvVvWUDAFtUcOJ0tkI7lZNqb1Z63v8RTbqS+oOkupOIv+RTx9UKT/+D3fr7WaT+RsUSFs8YCNi7c6BSWoBOtE5CwPx6/NWtiAwP4QnCN2EBk1Bw6M97vbofev+TkPdcm2iOzfsu99vcIFiPTGywR1ga98vbJldD/XvN5kmdpd2qqvdShu48QVZRwKru+ZJvaONvmSnjca4mSr2bTWwoJ/xKarVmtGp/Az8RUBCDbJrNfaUse4LgjQKd+GPj9eJ7YBTOFR+jXcYPU7rOYNJUpyqIGAMsmNp5pp22Z9IgLS+wNfZTHG6aBjAN1+2kFerJQTvESpzdljWVzpBe0kJbI6o9jp92DrHG1gwP1k1WekLtDebufmEJWmy1JoG72xjmTpIGFmP64EUn2rSYqgCTAUZ8TUir847hRql+k0SVN82kpmpd+B8HBmP6tDJfAAD+/zJATVSt3G3h/xYaT8JbB/bMtY326TjwgLd3r8NoMTI38fwLG2/01ShM0ZbSYBw/kac15Kk+6yEfWfNATVHaTiM2tfWzLKr0eCMvE2TPQiW3EonHbaeyfDHM82voO6RZxsaQMWr7oPjgUyVnQl7Wb/Y/a/rfltbYFF2zmfc3lLJzn0uJX/q3jA5r/0wTcT0F5YdGjDz0Yc9axP0ZtpMGMMtNUuUoamFUrGrVhSlrrLXP37sv/9ByHD1WPmyrKVhP4Y4h/lK6A9UXkEKJacFVrVYSLAR80xFevRiNKP9a8SuOFC7/v9r6d+g78V11yb3uWW/Xz+RJfokxHxBYDnkLCcB+be+LYi7Jj4Ebz8Z9ESetaFQ3sLPhrskE3LSGdzbyIH1u7qM/0sX3rU2gKh4VjWu4nxzssc6xaWO213M/TJ/HblBtdbbBnWnhnHvB0V/yz5qebEzcK4X7ZoACPIT2+3XCvzr3ly4KPQI99ik95iOHKxm5pfA0mB+WJprOmpDEnT1WzRNb/+/8TC/+yvhewf5RPQygeUVRfmt55EB9xKsBLWRFXNlVlxUKiYQrVfX7YpkjZliIYAiA8XFOdkPzSvwC+0uwDvTs5RH692N/uSNt13z/N9GgpGFKz3x2LvGf3//O/vdLO01nVyzU4g/5huYh/RCMe/T4FRy1vIFFcsgU7EYFIQLijEbwX0mBWEbe2ls9VuvTRLpR0gYJxoRFQZz/yep3SkvqUB26dKxJFKKzZo/VkjppZvXIBMnTHmtffXaa4cvcIlzwzKb1Wc8svabD6Ww9HIfHytQA4z013TELUy1Z98NxIOoXDlwsfSnNffKRQl2/fxDUUDhARFDqnaAN1Uugq3AE+/kjyHCuvmNNb3DTX5lREMnk+9uzYrUcRMU4CIHR+7WlWEX4W6TdSLPygGPa/x1CL2Ft5NWY2r/hLncwBaN19cvUsT/9+7TL8a3cSK1rBV76p4Uf++6/9S5lsJVVZk8VEqZjJM2jIKSjPyNW1pwqAOYeFMuI2apLPjYCkwZsTLK1dH50GrVHodpAYWje4tuJBzzQ++EOIWJzu14thgbT+RBSbo/iAVjux+Pd14snfIBvCBTIExZlbph/YbGk41q7AZsthdXAbRXKBD6OHOxSAKAYAcfye2ZDmOPXaj0NqA7/N/ddNq3TI+FsRmE/xSZF5im4SjEP3F/4wRTgankGxZQjbnHZXHfPixy2S2AY9OWttFWmCvUbroUl7HD+ncBNxRUC1rZPDODXXMHY4F9HvMLiQ97q4oS5MsDzSiklOsmMY6eUmW+aBJK/jmgJ59+UvBoBwVdqDoRHsK/8a8GU8diEfj5HQIEwmk8oo3GgUb8j/5kgtiPLxjmpBNpDvVb598EomjObrk3sAtKPkrTEkRgIHjFgLTf329Rtlt364bOV39/c5eN8VwyOM2Z9e4C0JSFRtM/O9hA6toVUPSQ6GqfMdXeGSBcZxcSnUEIuf/F3exrSngmty4hr5Bfop4ydme9erhsVLUbFATDlohg0oLFAuK+ksHj85s3aVLf/fSkmB8x09hGx8x+eWmsaLp8O16ZHe50kONElAK/KEmeZw25xH9zv3aWj9wfMB3C0kSoPL8yovCrEIUFWUoAbKDAf/DTzwfmiJ3kiBeyzfmWCEukQgeN98RAeWSNRFDlwfUEsMAVSFMNSu9bMvT7tlPDzkepRdhxj6y+cK2keuiIpeGeYcL2il1TAaJu9bC7qbgI2CevGhnaGG8AFEWWUTUIuXO0mXQa5ZwNRqzkGrRrxUCsWF/XbjfhtQNKMvp2TrP9YHszWzg4wSRkowKzEhbVL/Tt0tTE7iSkOr4jzzQ5Lme+613L2+L1x2MFJu41uYadtwIgKZeGdxz+/C+xfT/Evgd4WMEdZEV5yqJVsLXfM7iYdlHlhSpD8QdQgV+396zAADauSHm3mDzjfCtbA7iVNZUJhJbxrDhORThimolc8qUuoUOYknZzM2Cm04DWBvB2gLVf7UpSHqEXN4ToUc5oAre9M26VW/mRkqrE0GIdXneCSFyO8RxixMAKPoB9DPGAbwigisVTVlXky9/zm1L3aLyALPCYKYtfCI8+h8yl8feEkXcrLqsdq0Ir/xx3uwfQb8JR9rCemc2xShtHdy9tuwY1CAkHAI4LakhQchPpCuHkV/ueKGbd9biEAuVVwA0nwGrWqScQRkhY32og+wwN51fz5xurf/y4Dz4WGiSCKdU8jEyCXrbz7yjTYEFkHBXuS2T+eFUoAmeyHKVgDh/B8/x3d/x/TpQ/4U5MyT+SEdAybK7qSIaAWlcBJs5YNGpDluMR6bqo9HOykOevt9a6ReJcaDyeLpYNg5L5mZU1BKuR6J6KPLVhDqHo/yzEymkwUPA6phO0wcl7nc91QvTeSKnSkapfWR3XW1VrOQuS0L8M85BsAcOGtBJz1lJVkGvJ/DqvNli8egfC1qOPAv2LCYa/PLtSbueprkcpfm8Cy/05KuJeOHDW6Ladm6n73rs+baV1Sc7vE6szmwyqicSGGeo6R2X1+f9RGLkuwQ6eQRVDfH44VhUXJJjg8jeJL3UfsYu2XnZ8Db9lk9So0oUpZkE9ipCbCmirlC95Hs/P1iEyVgoNYtyxafqahavw3bQBN6As+h/gjkb+Oaun5fCCq3WtW5/Ymqc1FT81IZI9sQdb776T8IjZvX1ISyb7yMqGgEHgvSkZCjzzB+7I7Ci0Yvr3gV6z4FOqVAA0aXkjlu0aR2efbvde78aJhU/rsKrNsZo4tYovf5Qvr7aCMaMynVfBD9bSCXMWKw/u0mRApNFBo5A1B9I0tUWpwjAEvHMUJZyOo0BClX3uknez4yih0pCFEBSwUK8/TInam0ijIvATcE0VERm3mvQ/uGrYInfrve+GCdEeKxPTiHsJsEfyWCSJhuy5Q0dziuD3eJXAv8IHzIxUJEBa8EYEZX2LrYhf6Z4LhFw/w/7O/WnVdRnHbqALuX/cR1lJtB1vwJT/Y0MmTXEGPEMiE5cpOjwrnnvLXJbXMt7uPaLsSUgOpCgem2pspnb+tZ2I/1mh0lY2stjzTfVC9rQ7Ll/i+5FPEJkGXfpQ3pB1lBO/WlBfAw30Lxzg6huKlvs3UN4B7BeW8BEXIOqafDb9QccJWhG02WLF5QPBeJHDL7tKmpZTgi7XYWwRktM6dvTH3UAcX85/y8zgmkjPJGlfpa43vpqLrPXkD3kgMqSRxoPLY5d75FQ8zxy+qprOC7nB6Fkr3lmj2gnZuoDl9Q1YSXbvc2Eib0adPPE4vETs5+s1zhrgTNkKLKdISmIio3+w0DJ4AY6eYmkYO76tErvm9ASuHiOdyTxPFxNYvVoYEMx8XxREmrqXbP8WdmpqqvTH3ePjEYg8F5dw8/rQOxZD0AEfLa4QWO7i+3zMCoxGryq6bzaOM1FdgMVInXE26q+xDkDU1yZ3GMDbDqmqVUTdMG38RgCSLc+Mf+9bpKf3SJvW+IZwNooqiuHo/wtENx6LHV398S7AoPQ+sTK1S23UohWLA71fevetYcg3EFg1hzNuH3VEXGO9ojsF3ad7SdSkF0CeEeRutnI00bVVC4G0P4RIPTngxHnG8rSQmIudHapqhOCHG3xY8bPk99/PbX6JGbeIKckGrRkiYG2gWFeTkgacwB5hRs3am9MK1Mx1C+6CUBzzBcLJ3hEgRjkUPkNwEZTSFMuoX7KUFK1aX2eGaVmJajlLVHy7VnKE+vg2L0IamnVpDGfIsa087aBJONkbGQSeAa3lYiw/BlSfijIWDu0wz75DOvvlksaaQxyjDRty6Dr3rXl7Zhx8x2BzhaJDlr7W4QmsHS+SNcwVtzoa9l2AY55a1MESg44+EI65vNJRadfjyaIQmCPX+zX+0AA/2x6u/3aKY44HaIZEB/7MV8aoGrHF+XTiGIfDMRHJzXvc4S5bxL6tVOr1IEzsjIcTBHAWmcqXMfOxDe/VJ83jmp+/tH9RaaAXZ9/dPx8MG8WmBLAPOXq/sCMj6Sx8865Jz2uCFT1ECfPOOuRrY4B3AmJ5JNsWoQkUkc38M6DqjCT68NVNHPdGFubZT4bztSA1MjdF0QdDJM9iuGPIEikVPvn2ApyTk8+By4oGdgnhnTlrqK5Uy0mtAfdxqVHhHS9S43bUo09Qi81LRa+dl2UnUv29SI6kk6fFkOt+OwUYCO2IGTiOq+aYgHoPf/2TgsKL/d2wpDyhFFPnMcDgqFI9Fo/JpZtoLbtYKszCQAS6PD+XLNhcvTMO2Gf+t6a2XgtitR2rS1qVqNqRKsJ4GtKUd3SAnTJtuy9Nx6iY2uG8roBC2wD8yu31mmDK/wgEGb+Y5S0To/tPAJZ8qUFgUKnvqgxbM79voWcHARDh2IuCV7Uj6clLOtYKBwk4hZBwZTXJe8Xtn+vopHvQ0wrXChRdZ8ycFegdeBbchAAA=",
	gendricks: "data:image/webp;base64,UklGRiwVAABXRUJQVlA4ICAVAACQSwCdASqQAJAAPnEqkUYkoqGhNJZ88JAOCWgAyB3UfxXR6cu8n5tHJPcH8e8d8dxXnnKPw+ir9R+wJ9r/XI8yP7Qerv6SP73+IHwGf1X+3da16DHl3+zh/cvPCwXHil+A/I3zX82nxiRW4f6jvdv+99bf9l30/LLULeV74XqHeAfO2msq9VAL9J+sB/p//T/Y/5z1W/WP/p9w39ef+367vsp/dz2av20dh3RDQTif436o14oOiEbnucn7ubC/CJcqM9U2a2YtDU1OTYCso7SUGtHruffm6VJQ1PRmC1oLh2Z/EDg9uZ/3PJ9dwOGkzrP3wzOj6PTT/mhnps4oCntcyLMb8rrT/06qwEm0O6Kyl7FLTPkjSIGV++13/Mbav3d5D3UQGBeQQOc4fJusA0hT7zfegv6zS9LaITf/WJkUcOYUOLng/Fcs9j86pRSxog0ePjnqNnDdnNu4eh6+zF7Av6b0gPFFkGo67MojKo/bp6E2Oybt+Yrbokp0uRD5zCU0bK/3adrAB26KiWc73+ZxH2uxKcU1nn15DPjX/MOZ9JOwbWL54psmocHPR1fBrjvevdEg8DOb8TEEscgo6uZ/G5lAWG3PRUC023/IF/AqTnuZ4qksS4vB+76sACTkrKT7OzKaZPs7/eQMsL5EMNVoZyI1meWpxOGj/XRYR3hySzohj/iojrxkrBS0c26rTnlWqeKyBKvg0CUX3irZ/6DUNOV48bzNzZqc+BgYgthiHPjLykCRqvGmvHsU6PKh5swDKM4FvSmX/OwCy6imwiz/BDCzFlgJx6DZK8lwmicpFn6z+epAAP7+VdCGghcQKQPGBCY9eNX/m+Pge+K26m9KW3qATwrwdAn+LAeA4jCLf1j2Rjv096OD2xr8j5PoOfC5Qbbu81VcJbu8RmfV2xUQt+dwteAAaexl/fAJF6O0R1z4/mLit8ARV9XmUTQQ93/9tv1v8VF9aRfZoHdL/GF+xTOw89f5/7YQ6F8TIhC5fU+Vr5W3Dmeo535kKhk/bpKvH/bwFUxg2iKQ0+XGPql+d65Pi4Dn5Wmsub4ngFSUpcQnsJwymTRlnv5rQTKjisAerKaldkkQSSx3FPC3bb5Av74dsjNECtq/WkGICcz83qob+P/kJF4R2r5ch6aBjNZZwc6WlrWfFFHnFIlLUMDz+t/RUzfCI78wdN00QW0FT0N6jrDZXhZH35XUxx0DcL1NCmZEkADkSub8JIKkKtlDTFtQcX1Lv6rFfjJb/LqnkdCM73qo+f7fq5TqGtWdzIRbhHh/dcrafCjJvXuBUnzkuob/HCv8dYOTi5OSXHRwghB2buezOP1H2vO8mg1SA5W20trbhxUF+s//4nD/IKQ75/MZl5F1geR5AdjWXh9/WBgNt905e9cN7TuZeDTkrtKEPT23xpvp1dvo5CaoGQszHX7uCb7T/w2Vh8J/SX2vuW8Eqm+tSE8leaR7QjJ+299SlOwJwVP02Qi7H+BrNZ2sJGhzSqnUCI0Eo6LR2lx1yV3MLyZhIueb8J9z3fh3szztusAzVLYVZ7540xhr6zOv7xp5Wy2Ntb8O/W/gzvv3UF4byIXBQhAeuABwwVGsrpNaDlP0I3pnlrDuxQuPznwbTUCMS+lQQpXxLi0HOpuFHGRmgwXgrBxAISktuubW9anONLO+qTnaoEycJbjdDkVJf6jtBM5GiLY3U7d/YbOO8lJBesvo18cgfsfeaYotYz8471vgVtZu9mKWpGqAeTfPIz/hN8283S2xd8zHKYSaaGaZY3fhSCVvt7TUkcT8rOZELT2MXua37ztKwA06X56Ox3uCFkCW9gOefNRQCMV0KB6fteq1lif9Y8H6HQfZFDDH0W4ZbI8p/lI//n2GL+XrtDCmb+1q1m3j9xQvX00VxmfJZ3mi+a7fJ9gTECQE+ZZCMIp++lzeBDVtS4MHgPZW2p0NVfsOuB+GmOmaismLTAdqZEz9+AHycPfMj5UqV8cBUrOgy7YAlCNKBgWmk+lz0BVP/J1r4p/M/1+WPnZ2YE76GgcvSiZsPaVbH1MRsPx161mirkTJOhCA5wJuTbkl4UIkGC9pHJcFtkJt5QVrc05BdUzY6BXl3O9MUWzeSYKde34JMTpzOTSdYXrqBHosFC3PmEteDKy+veTnVPzmto5w6irwfJ3x4BolxiQYMnxPR/J9nJKxKv29tXVMHt27IceUswUW7i1pH7LA/UxvWcqdoMn34O2Hwjx+oNcLpgJ/2nFD5b10odirY2lb/UFg6vJOpquwNGjqYLrYDvM/ZxH8NyVKv5S9NXcB1/Au5+7KSPPe8LJhW4dBggzDOOH+GtsKyaR1Om3DPUkGRgArOQLC6uiWUkGnJ2PF4pRyRxaqovMbmQK02nx/eVDR7TFR8FMXiHghK54KHmHMUvu03VpBoA9gVNQ7K6rcBaf6JnvH5E+zBfxSMBoFcgaQX9QP566w3Z+crg/EjgjLmrTzI2trA1qY1kulTnKGQDRA85o2T6M/38blBc7jhjlVUhg4nYrCiDNv+PU21AlZgNz574JTzvgd72DVt1/ECYeVVXVoZPtKysUM18w57idnWtRXcWJz8ZQyJ92jHpHbX05FDC9OCgSwlk+LLJu3pQevkGthJlkvLlj6TeEUzvFYa0x2QscfpQ4Oq8ksjxvorA/kco3ceeu9r/NaFkITtKlZw8JfaIdnbe2oGJk6bi20e4Qm70UHxYwYlWsn9CITWYP05gSN07y6TQ46Y8qLdqOfX+SsrHtYoEDFJhzyazWhb0z6Br+lR0QhtFRvfvKmVdWhaZNt/CLbcPRq7pP9ruFd03JjaqJHX36TlWV0+RrXoJBFl720aC8O4b25R1iJErGThOBfvvXEf8/tk169ZIrPNgvfLOoG51FtEluNtgFEH9Rrgo7J/iLC9zZmFiqJblEE2KkYoDFk4ty1x2yLx6tQgnAd+y460i/7zchQh8mMr1zEffAL+QDeU7bofvYPFdeerZTYqfL8sWRtDJSnI5d1N+U+wja7IpUsYjK3EZUPSxQWa7xEdsOWZCNmMRw4i5qgzmxXC99OpdaiVcSyBFWW+biXoXHhEYfKFSZwjayZ70ikLvyXpjbXlHhCHGdexLTTOirKPumw6T/2ms2BAKZWkThiABd9+4CdnB4zvsXww0+Dp8z6pJh1weNf01Ir5r5D/SaydiE3bT1SRLMcgPD6oWYANigbGUfRmlH65k/LerbvhAtTbjq6XL1wG5GwUeTonjpK+fzlxtOcjoRFjGsUkbGKc1Sdj72kQzTNdy3EtH4qDajCghUkF0t0pdS+Kqv16rzpMB8tRAmtwAPThGqO3xaZiREln4X9R4NBvUJiSH8I3kmx7isEx89MR5KbvWp60ARaWioEN+MgSaRDGF8+YFuRYkhPfazNv9Q2VBaSwyPD9xbE8DEd5na/ifNNgjWEM/VuFD9lEgOcazUVdEMEzIpi7JmqsU1PDKgfRe77NV1zV4YU3J+BEOH76YUSS+D1k3DSQqp396nYmicxZ3SATlAbrTTw6p0jWtJIE+eN0n8pEM2j6bBr1M2/5xHOQU63OwUI5iau4nAg/wd+D1N0ld13/RxLiy+EwP/lU2vwNntexG0t6Lb3B3gLZgsQEFOtJc3oCmRzzW5DSavGMerQl3Uv/dFFmay4jgntIa3E4dARW7W4iPVLjFVuiW5509JlO3+0MZ7W6tQpf0S0QYl+MjfJ/qtVsvp0bC2isAHUmV3Gi0SRNOy0ImSxehVelKSHJjqYkEKzDwpnzsqWXYU6w9kqEVGkW0IKB98SPT1gC+aW/ie6AMhdTVtDQHnYy/ws7cxeP0Uadf7fO6vnzyw5GRfGYHqHPY/O580hiupZ6cpg/sCv78OJBImBMHES7YKNEbT18Le0XVs+PxWGmYKgD145yE5Lc5o+K16B0VSr/okvWEVvZ+vzcJNQK5Wl7isP7FVh5tpe+0hFWZLktj8oGbIkwQB/NIzYK90vCku/0ru2tn6lbbrAsx1p50jqzsUp7ZLPSoKyfAoZecFHjO8knUPILJrUpQzFPmJNRjsDgFIFjyHuLYAjX/c6sEdwIr64Qffkl6OK/wuL9I0iGQ7H2669YMPcbzhX2+cYCfSW+TJWMwBM0LgqMRWvHRfEPlo+iK5VWY0xHV0FX/pcIc8DJhIMn/E4fdUwtxZc90srT4d2RY5q+WDrxSCgmE8JdBa5bbWmIuXls256zIMcWmX+FigddWk55xmMN1I1vOsMrNqYkZ4ApIbZXGsqjmynhPaD1/kEuhfpdvG6Z570z5P0ATaGpp+NYN3kdRhGy4folGKbnT4VmesI/MmuM6p1gIkEjDniu4UJ+sY07ikFAycLUgdLggQxM0OWZ463bCKk5PBsI9WwIUnu6f7HUeHJM8F/jho6wVCDaZJH/eCQiXpGa7v0mb+aLiKhEunbAM/DzwG10mYw0coX2gHcc9otpHHyPrhym37MTbnaGF4SctEt9SHSAKwUf6daq8xDVTNThf0lytMSUVLVuoTaPiqlZATmj0v0akPEmYxFWfqawzqmA3DTKhPBb5vD+Lv6mXdBxWOAMQJUByU+D78+CVVlgxuIBD0SLpsC0zjwWTcQwQm9zQKay1CEfGJgL8nHMaC+h043EYpyNZbyWWa7Fbxn/JE6bT2jU3hH2B+sNM8k48PMvt84SFElT1m02Z0R53aDM21cv0/oWKUJ/pikEpQkSjNfvYZcrGtawWH0PHPngyFs2TeIJ4faqv983HuzYy7MnV4xyMG1vgS2ekaij6pHe9jciGMeI3sEQom/8zXkfSgpGFukKX2N7l+Qsd3qPH9x6P3pDxMRdMxuEzMZwxhhDhtSvJNk5TkvKmKHNaYyrprA8LIDr8tthEWI4CaAUd5clw8xz1Bf2/ONNPze5qPBd+g+wtKkFZD/8dqvDrnVJ55bkwMco6j7laQwuK75t+mMJmes/z2JSnAh4MqXd0VZUbHTu93IYD+peP6M1Qls59//JIpAz++jeP4YHQT9nYMjN10CwFO4XAlNee/PLBeatdKJeLD6xiTpJiMheQy/jdsgGxOp/l9qNPi5yM7emmTFsaYV0ipgCOQNTVqYU+Hj7d73QN/WZOFJ0pH3BySWU4YVr7UxtUvM/OcCTk9CdmdA0ZKeWHbMxiDl7WX2/T7uIX7/y6Rf3//ScvHvKqxg/VB3jrk+bMBo9XI2UE7g5tmI5a6lHO/1J968TD0SXxd6O7yeI/G0E7q4GKLfWNZd7UuBkZGf+6y3wTG67i/1x3Iz63b8/eUqW5F74SWpyRx66QWQjA00W4yuOdxq8yIXFujBFnK3A9NCIzf4vQSljwbdw5XMHfY5mD9aCMVKHUI9z72N68mdp4NrkF1jxN8emjQI8cFgNbjdsk26rNt+hUXFvVQv59EAhCZ2y2/M1VN5SWJDlF1eign2jOjq/Z8KstdT9qFUdioPqfSFaUzUTNMvT7HGkUbYkpDoocU3erz9byA0vgGrYqI0mlnLwELczoror98i3YtW2BqTWNffzvyKUPmkMw0IikrcSnjGz0h6mkVY2jgTrl6f3T0Ms2SiR1ys2AEow5cgHsGXwDQwQ+a1FZ/LGXjdo19B1Mr2WoxCVelX1grzg5Qpf3kw0R6ARU5n+C8PJKTv34nNdjlALIUL1iTREUkBSNz8NoDKTtY/dgkjL0m2DJhuWBmCxcR8kO5Xa2GSHHAccPFzO/lIGo6JdyjDfeFp73E89+f0HKaVsrWbGt6Tpm5N5wWlceaS9JU8+/fz5+duW+naeSCHxb4xt/TfAnznPmTmfz0iv2eOM6CKpnX5QWnG8OM4zSElcHdU5eFiC+7e3V72mYVe8sAMJsZJoVrwhCnr9waKGd7lGd89cQgdTtL61/ZmsSyPWeHOwteJ9rmljpBnppeaZzw45/aCu3cbrmAY5ZMVI+UY395iokYsCRSmlbHwSmnz/fbGe7nPd1eKfNoeGM7RcWfC2STSHWQl64OXnpoKRXekGC105T29gvG0hJGpb+NjfuZgnnHT4coJlm/yxY30ECSXIrgfOLvHEN8u/kqpr5p/Y/Lb6FGR5IIKwkimZgv0AKXZVomJ6eS7/Reqg5spLqrNIoTHDNEFp502No945wL8Wsc/lqEKbWE3Z4ZISE92vsSmnBJSr3Y0KeRXGkoZNFfs3LXIt00qbG3LUseYvkDXZ/Cr6FfPvwYDtw5P4IUupg1fOr3QSWX2HV+YNPIn6puWZeLq9FsY4qSfC1snn35NvPYZaNWlgATYalnlgqQ15aiGmLQN75vEZ/9YAVi1eGf04i29O1+97UXFfgjAJPbYFUzeE9ehdyFv3WnRcpAc5mC1IeeTAi+UU7Hwtd0V34VnWaje3n4jr77ayuREvkNNjJHR7DqABiF7EM6XJKEomFS+ESNctBlHbyZ9dBg4Ty7ys86FKkTgMan9dSPyK2epvukmsV9V36cVe7b2c1uR8ZIsW6V8rR4j7sP3MJoQjKzIEbdDBMwA+qGB2IgLvhuA9kgZbD5T8Saqq8D6d+oXC0LuIj+Bo0OKGDPBh1APo3p5/f7xXQ7mYNjNqTd+CpdHjyzepFLhZ6AFeJNxYgfJJvKQ8E0k+W69VCLqu0+Op1iMRau2hoGAtJk79Bz/UUio7m6W7ezWSBtHLW35b3wsACD1Cm34ImnHrqVz+sYEXm/FQ19c0lywAt6J7YcaebwHle22l0NwnKgFbn6bT/rB//IxQE0X9mWEcj8osks3o4p1Rz46NiJkIlD/02sPIamN0FlFUBOa7Nz+AIpwyj+1cZjdgwT0Ksq4sURTYAFMQ9OQGEhOeYli7p0IsvgyVEPNYYJ24RME61jprvraMAnl7X4KqXzniBNQAbdt5OpUFBa/a/WSHzUozlxqvN6GnljL0mOC1drqWsfmztpd5pH8hKk0bI1k50k1QP/m9BB96TBVAyhDkPCP8Ag8aK9Dr7moUz5n1l0f4IgpNJ3KSNDpNOkRQGu+E9Dh76VY8YA4yhVM8te9e5YQ+EBODN5Ow9u/nRJNqF3K819svjzgLR+jufw/YtMpQkW0r5AioX8NURAecJpKG7nmUpsjvcSofOnBdc3rnOgJys8O+yzbDgHRGf/57FArHsRUWJ4cMkUfVAOlY7v9R+FqXmYZjH/6LKTbetSgNYeVjeH9C49LY4G847CDxdnCKl2iGCPcopzgfna4XWchWM5+w5jEA1zkM8MgAAAAAA==",
	goblinalarmist: "data:image/webp;base64,UklGRv4OAABXRUJQVlA4IPIOAAAQOwCdASqQAHAAPnUylEekoqIhKDgNGJAOiWkA0rgTyzx9EPxy80/MUBXaP9q/43969tPZTwC/Zn+p35mb31CO9X/M9KKa/kAeXfgE0BP0j6wH+95Rf3D1DP1r61Xo1GTeqMMX+n/E0/KPM6bhv9Y+GgkPwR1Ot4+2KX2mvjok6K6lwoF61pYgsh1XVqBaS91CoM2rwjd/k+EsT7tOYJiXIYU67zfv+mEfgRujlCNkkN7PNZkN+n+icmbHzZ4lfFiI6X+bJWaWCLGYFME23xzjl5rRCyAJF0ZvbKDfIUeFSDw4PnJZBqjo91Thlcp8nRBCwkMYXK6bgO+e+O8h/CCt2AmF2Y2gLef7SJYOJBu8dkdh3ZmI6ZQsfTCb8Z2KLX+ZqBu3ljM+0x363vpeHjE3Wz5zw3gVmiIwZJjYxNgvB+sdDxUCJPGarIdZjqAqnre4Ix5L3gkg5/02kQPUiV/VjxOKa9YqtLjSQyPp23V3pG8T3owXs+bQzCuJl3O0iY1eA+/E9bfRO50sGjQ/X/5crbwpenD9cA3YOqeHSlATUko7WVOBY6paGBaq6xl1Xob4C7kmFb25m48AlAk8iNSVJZ7nFIsf7TdmUAMUbIGqWZed2G7pASDG8/oRt+a8AmzgAP78z+fwbUZ6JcgcYqfz3j+f/vv/29vc+v3/drVc7F6941Tr/6ucE26dbnDDgesdJk767xmnuj7MIRWZJKNm2fox7XBRR2TUY12bpYafpjTsfRcjM4zn/AAe9/tACJfjTn66F8wtPUVMGKYu1Wh0MisoJZrYgyzdQkBgougITkNXMXbdWQKixVzXul0uDPC4c8WfwXPs5XZz/ISHzN0tk3b8/0rFUCiPqaNL2g6g2ozk3M3+KvwFIywaXbG23zv6+ddrV+uxsufmOzuMC++605u9ip9aFn7jpSwmeob3xQ+87SBsn/XNQ5bvNpdcLB5whjZtdx6MFvaLn6kxYXTbw9SHTDHP+3bUJywqe5BYT7/S4WssTaSsJMIPYE0O4ETxTMCttRhRCrCzsN7sUf5lJWChUyPhHzlEsigrNKR0Tp/YxP916E83dc4kZ94Nojd1aR4TBiYfzHZxBp/C8bhWFN49iOzemj4yob1xpdJvRBve6OPS/NwGxYCWrmHXGD95VG8CpF/+Gs+ijOENqANoChqGxqR9ITYhZ4ncafel+bHxP14l8WiNauoLM/L7BSMI9WkOzXMmudz1bbek2BSEKjDYUMCmPxLJ85HDv+icmy5gOKVJ9edFHR/TvN17a9t4GUliM6s+kImiHmnHizYEuTMVvRLV/wFO4Dso3joqIbOvvGeHfGlKF/msj1dlztb43/2r9+NhZ5XyhYsQXgIeQSu1miCaGf1f5jv4SzMuTi7pQQdBf9PHPXt4ciGxdiOny0b/pkq4lgcBMfVlgX/N0vbs5BxGemcRp8X+ykz0COlHD+/E4Wf7n/j0Lo2O55AXf3kobq5xzeQJ8qU/LuSCjML6imGOXLcleSv6+j2fjv2n/F9ZuWq7dIFuR6C1F4boYZcCBqkMLecuyJYyPr4nJp96b/xKBDVzqhUA80RmmSUmkbhlIdMqxkop7Ntp7b/qtSd5d+w0TSjCik8LFNXRcxE9BpsU6ARFX8RlhM+3rFe8zaqktgjOdHcXEJzW/hfAnQGGbkAvrew+zIC8kzu89z8VtOcB8NYvHxERcKKj/CA0vQRfw/nGKOW0iHqfakfRYnz741sTBpfq5ITiCvBe2LzymYCm4CkMIY2U4c7MOSE3gW/EhDS90OeEAthNAkNHMEOTXh2CH9Mux8HVtEkVf5uwQodJgyYHxkCYa6Sk3ha424iPT1TZYCOlRbriQETy+EoBEOw5Y81xGXpOpv1hhDGX+8t6XTdw34JWkGmEKAd6WxA80oHm7PNzZNwc2KZMrajxkVUF/xpMjyHU0Tm5iabX7RgJNzI4K7j4qdO3AqlBve2aYC4GP6nE8wFWK9EIgIUMo+Oh1S/nBlkFu1k8ymN4fzzPlBerYeUrKePcQYI/8NHxLuDGzD2c07SeVq6H8I66gGPgZX4D0wfG0IfovjnXbrSFAPfU0RAAz3vwq08oyw9tpYgLWjF4DMJ4sfa34HAZpWHQlj7Qjft0y2qxziEJ99aiB/+KTLPzrIgem2PF9bPV1ZIMnUxJClL/jRfLf/4OIpyWcZxEZU5MI8cJ3iWPYqsb2LucS0AudgDF/hMyhJJtHv7oWIbivgQ5CRhq5N4QAVdrvWAkb5OI9KXSy3o35JXwDwPg+Y7JtyQG6zvoPdZJ8DG/6rqi/CMbO+xc1OvekbV03CNHIGUdCfJKaD4AH5Lo21XFoSHIj/DEAiqDFh0I9o7+UjTu7LhFA1g9HTFzXOeVanEJo6fXOYbpe91elpcK8xh14mlfL6VA1kLOVOgcP1xYbZYXrOzRUZtEXsCKguVSn1QkkjUl1uXMnKgc7i+Pl2BvxOx34OHI9ClZUwaypxRuf2QlVsjDTJ2eo7gifebPR5TN9YHsN7MrRcRnYjHKtyoXh9v3zPqjdKdfp9UkxOk/0yrFu7sykDnqy7k4MGm07UzHLTALvYPk1+VD1+WXOYd+J3Hvteog7zSXWvj3dnb1sMzBvBJTD/XyU3fkDc0x1qHvg/c3TvObQBL1YL66hA398wafx6dWOHVhOERcu5pzhOIS4IukjAWu/o9o0Mt17v5bFNIv+QP4g+XqGAdl0ZrmyIHLW1xEtXlVc1drYGQvbtsfCGHmp/wbsGFgAEGz2WbwiEeHjK4vs86Fnyp7tfcb8dUukz0s53EiXdq3Wt5eQh1LysAKGl0E6w5vQDlpcxx6wii7DHtjdxBsCQn2186n6sRqcWzJG65mwJgjTEgE8rsRDNzOyz/1xX4+6lR0bm2twQ9oxlME1jh1i2UWWiywmv3C1IEO32Nl9SKAaYLH1K8ZJJODngxgV8fbvVLSUDjweTV4u4ktKFBkrTap2uvFJdCE2UH5xDvc+haZBo9OIC3ws5X5JGsVRMyZf2lpBb7GfAaDrrVe3/PjIp1FiIf8IfMusPEQlTWjw3svRtqX2PPOc7aS8QEtb1elBht/sDHzJS0xmnfATTGaM6xKAwp4gQdlfmg/dMzO00bUw539r5+J2ker/kYz4tZ60mfL7PjfHCD6mxXX3yERLdXmNqwH1fI2iCBg113s1uxCeXJTqdATg8eD5R2YciVYihl65fZRiVa9BtSAhJ3VgiJubbWZjFuLqkKsa3nps2YLyadlnyUvP3MVksw7tCmGo6izi3lAKZXhRZz+510JvTM19aTjcvIGRkKOALNffxarKcpsM8aG3Y6NFZGpPueSH3XFA8/F21sjgzTqrZyXP+E1kdavfMTfpuGVO+qA6d9TbsG0joBeqTpkQ4QfPQbXiwRihYhwlVg+/1LqvtyxaCjh2VmGnAqhidvJfIjhW5g1oog6p/H5oY9NWvrUx8H9N0AqgU2MWDJHtIHACV4IgCjmeYaItgo583GYJFiwrOHZAkti1D80Pjo+djIyEC9PQca+ztOkRbAIr1YBu+PHI269C8/2G4d++OGWuKnLp2T+fNLEtenhLZcldIIrVGM6CWYkGww3X/G08QdRCyB76kfYEExNTC0MJQBW4cE86/6w5k3sQ/jEWBNTSQ73eLIb9VaFhVdo1M3d2bD7ItmM96YZ5c+zeU8pySFxAV4Nc1Iw0X5vjJg2aQ9BST9G/tAUjHTJpu4P/ZSGbr3yNvxwn9jZSdg4+V02nd6Gmm97EUVbbMPgjciF+2YYpVakSBjfMbEY+fCKrUlLCU0UbYsTj7KA8UfsbEVpd62AJN60scpIbP7Z1RGoMh6O9IgYGLkRqGV+jRrHe4zrgtOV1xnUVO0kpGIRypdq3xXw3rx+AD+qXMr2CVh6rZlx7rl9IHZQJLHim6T7rRHHSgEESf8Nc55r9bEPN+b1dXf+vL9RUYl8lfqY/iB59eYPJDwINjX2GN5oA8T3/REv9FQZvvp01rI8tuCb1hq6YfLCJ4MMLpXw/dZ4n4Iew/AG8jwKGslCwVyciNs+P38OohOUBy9tsWSqTyRhkbZsSzp4aBQIW7DvPacokMT/L5c0yn4S/GIihUS2CLbhM0LacCI7PiRAW16uB1zsPPS8s5MRkU4AlUI8zIVZttjVPAAM2bbvx1jBYVqcFFV1ZqW0DCI5x+nUbssNVBHA+JdFwGmTeulO8pFZk7W+nlj1W5ZZr+SA/nB4l3KrSe6jLdhyCPxQoG5LKVUZMJPpZXV84Adhd0hIzf0HsXbNlOyBNGUC+zewSgNH3H5tuB7RWWzw9qDhVni05hcXyQORDbYvGRwSqQXv8t1OEIGNhtD5i3k5H+okcxvj3kBK7NZdo9JP68SBfFtJdr0JYN62WeSdVghSYC1OiNLFj/O1gBrpMHmc89RSkrWBtNToAHlJHV4J5B/k6wgjZ5dTnxwwESp/boqzEv9HE1HGKgunWxtfhLgd4ppd4VI2xkiR8GnIEv04y3yOoxLSN24kDzwWNR/VZ2plzr4mE0/l3Jq+1I8vuUTU+XETJoBkHKF+hzwlqqEVtryi2VIwgJMVTcUeHVV5GAKsyhKvZ3kAbLaz9C6T8Ghmj48ywVky1qU69eVb9BH86YrluMqcu6jBz96QMQX4Lh26ZRdtLsB3F4TyVS3GycxyONcatsuIHXIXt7e6cWLme7tiWP1qDC3UgyC8AppE/2DVC0oRKEKoDKhapHBJhwHqRRmeRPbGT+o7ldMUCvdM0OJHg4HD1IEkUjq59XFfqG75Lg4Khwf0Uw7Laa0Zwkt5UtgHJdR6A1Qu31HSVUWbWQiQga5U3+v+bt+88Pz8PhmDqAC8q2NbY4OcUW6T10IJsKp2TZeYP+KPmmT6H3ptmVlxFdfx9vfvB03mKxZ//ZLSlLMp+JetcmoWTSvXGE6o87B2q7R6bi4Dd1PDKmadT3GulfEi59X5ErIHonJo3gGIOKvmSu9VCZ8ceXh5Ey5S3ZQWdErm5ET2vjD5ijgIUfMCvm3aTAY08fBmuItFCwcBA5TQye6zfSn4tSdpfFJKsIfMUbw0MA6UBHvf+jhJBtm5h/m0EmjQW1uNMyNwv2NueMAA",
	goblinbomber: "data:image/webp;base64,UklGRlgPAABXRUJQVlA4IEwPAADQOgCdASqQAHAAPnUwk0akoyGhLTWNYJAOiWkAz+gTOz/uNuJ3pF+TyGfCHUU76/5Xrn/t++v1k+oF4o33G3XoI39/33nL4gHl94C9Aj9ReknoV/Z/9x7A/67enH7M/Rz/bcilDe59DK/2m+QA/E5auciXZXmb+/wDA8L4DgwmRJXz+JkbvrM9aJA4bLZr5q5wqSo1DyVpfjZs7mPRDzeDDV7K1vXPeUDKUg+nHC8BXcDCHAE7+B/GIXYeSBASqyV115V0RKH99kHdFdti0Z5Ue5wvA3rrD9tto71/BmS4f0ocgxlvAu2cbrAxwks3CzkT4Xv+lmmNQQAUyDuO0Zj2qS06p+r44bmdU3n3hxibTOxsqwPeOLaIv4hVW84T+1cikNsrNNt9TTGaad8FOZ2JqCQ4BXjWFx/SgdL5wnLf6mL0kZz4y4EqLYpdpbZ0dfxql83CZV/IzIdd3fXPXLa4ZQ8+Uo5JWMuqiudWFpb37xnxsONGKFWRYk6Gy25XXRNDnl6VXVjG1oGQQmyFLt/CNXQJBN+jy1johixhamyF7ss+EwCv660V7QIU/KSi2pzMOMEgNmA0mz+ewbT69f3rhsmZ5HpgZYda/JeRUS2zfzz1Y0Ze4nqz2tEWHy+6sAD++lmezd//npfNY/v3zR+PP3u3wHw/b/6PYMz28bmz2sv7+MeS/r33f0oobwyXv+5bGGc6PwRFbN0IU4pJ+DOHPl6HRrf7+NqOVY2rrJpzvVRnfBUn4v/okP+DPLlT+9c6LCx/CWUiSQeahzHQKd/gaKycCRIbfC9efqYinxSY4yddmQoMkV8CqLZyyK96mEisXhFDwdCunv1NIxAKHpBGGxW/3zfjrpKlD3yIuvqUIBAN3qOgNdhV0TFJhWTuTHeWTeL5UKvzIgE7B6pIoH/fxWpax1C+4bgq5lvca8N5xXaen0QGsHHAX6RXFtr5G/WG/JfD8C8Ahjq0ImbDQJKjrdmW6VHmr98iSxj47s66m+ieAjgbOTzoRVhQRMK7gFRvnqx23RbPj6CA8DIFNKZD8H6snz8Of88wEMUpUnOnXAbSVXkpGOiIWhgwfgPh6c/zDaJqJp5j7O9uHv/p4F1wB5+kI09dg7Nw4ZYltyHh4t/45tzj//R97M3J+KXa1vueGlLG942jBmY73tICimq/0frxT69LU4SaIEBJxhejcmCehl9zA8+4f91be0jK+0U0z/0duS+/jotj8wCCcV28IW5JIHr4ZRXHjfv35/+qI0Nh4PqzE5+M5kPZSd6ewD/7N/0NRHi8BcGnVuINDpkpVy8y5zB6ujROXoeh/IztcPWXXxP11L6KiTj6n51gao/zKP+tB5xy+xv+ErvwP8/9b8Z1JUjGkA+GWnQUIga2PAhmJsq811cfpWyJvAeT6So9Fpp083LTYXbZTcwmzt/T1YdE+8PpdYfKLhOS5b9/i7ap1MQt+Qs42Bi6ikt0yMopEhlxPTD1O3tbPgzJfJU5nlII9ABiPVstCq3uWfqZR7UloZ7heO+MhbjHPaepSz022+5y131K4jD3Js3N7uRYTrXMUZh34/rjnb/3B69PSC0rceypvjgIV1Colg7zbjcHMnlGvDi4pLynR7MnzwIH4vR++38KQ0W7jJiohXaTgY23Ufqd/AszWQ/WowyznKWZmZ9l3smc2cfLXBDNyGdiABOiguohpu/OY/SJ68ruUo1oml7jIMFLhI/4jhU0XiWwtjXYagClJ0bMHOeplQicJEGOsi5W6its9jXC2dOx8YGqdJ0bsFzB50OtVUcQ+RDXmRoieICO9wMaFSz8x6ZTdekJztjBiqM9YOqX7TakekLM6hP+t7ZJ3zXDnyaaUjUHQhhl+Uj6TCN0L6E0xAeHUuGJdnHjEysSgcOJhR1iNNj25yfDH26ZQ0rsI6oS1ekSiMvuKNyzeHjZ4R2bo7M49j5prYhCl4UhDmrr9p4zhej3GP04Pl+fmROy1M7+yu+thtWgoRZcHkGkmlefB8xC64RQIgTX87OqYTT1AEtA6wjEaYTQXCM34mw33GQf5ynM/k7+WJ9kZRF7lxLbuTcgmdJFIsf4Aows/NTSZkxbDPxoXbTeHJCHorHABEUz/vLt2mU9jdlIgIFGCbfX9UbJj6IEU1cMPPEqmy1ueanUWxszo3BTEdKoN+9itVPfRM8qaFI6zpcoRrYPuG96uQHbU6cVWMq2whr+AwNURKbRGs8xGEaaG07EmlCNIUjH27wxH5A0agjzKhir5Tb/Yl8D3URg/cl0ctQ6Elwd32dig1i1G4/mt3y0Teb+G78b/ET4qYP3AvCin1nURyHIkhtB0auQ7Lo0lX4gZddtKb0wJf+W+q2XTcNEkpvc/9IkBJ579FiQuKRjZn4B04fpYvLDa+XK1Ev+sMUFRcWCWXRbWLkW7Ycj/Gqh0FI6CGleCM0gilAPOKq5QNHF/x2MtyKB7y1zWYcFWo8NDHTl/Vb+9jbPXVSQduqdHG6pOIRbIO4AZQZ/T2CuRGIxm4gpKvX5RrzrBcD+4+yNPljuIbjhyMF6alYicIs3sDLd/THo7Qd/aSkHUjuTPihKS9zydh6G2N+tmzIyyD1AjHjEL9BNMu+NZ1R1SlJsbVOkxJb99MMxV/f48/8mzTyUlS2TjAltZLekgXa7Dwoh5Pfoy52ucPOC2VF93ke+1tGzaoiRl3qe2pVYQuvya3lsBlQNmxbbTNqpejXzbQ8egE6u7HIVdPjXg5UmBc3bGf8HGi5iUxEYnacvF0Yv+pRCpHOlD8ZVYF2l+boRZRLqHLVEh3HGBaT8JTCV6KAVLOXSPkgBZ/CAV7wqm29CsR8xzTXmux72ZjDM9AnWTYRUXPt2sN3IeBfS621jq9BaZpoybR8D/WzDHXWVC4VPkI7Uno3MdiU84wsCEkZ2Vj84iBs6SLiMQ3TcB9G6dpjMHy2N7jWvDmr7unjGeBOxG9cCbnaGnhiPrdU9W1B6RdQ6HkCZrnETVA1FeBOIem//iBPwS5scMIQsPmVVVsFu2PuY4g9mLgBhl4JhZBsNdHEcZDPcdps/x0AMBOl8RmGZBBgel8LD9ertdi2QxDwf4gkW+9IuYLKqlDceXX3juiwimtStizWv+dVfKOrIs3j5/4mpgx3ssjTiiri9mQiyMNg+DYozVDLWAQzXxq0kn5abXFiP2xO2a5HwG1YECqVPBrZ0qZazAKN1p9bkzWhsIK9/mfgWf3F3Rk0chBsgjlgdN1pvn0mjftlKVGzc7o+7DuHFLmAWX/KTXOuxzjdz+680AXo9tu/kKeZexDWtKHSRJtyVev74sA7xZ4FU8e27/UuAYKUZg5o4G18lSAZHyoXAzIOFPDEBl6HhBeip53eZx3LBVrJk7zI4iTcpUYGcPtW0DqAss64FIPGmYNOWoW7VkisOeVMPzgfd4pRqMcE4YMWoggkDGRaFDv0jgQcZFhDPhDsltah2EBNVNRe4Di2ytXdnZI64XKu+FEVTafPJmZSilw4rEd7+8EADrOJ+9ljtEtNXeXBN2hloZfsGA8tmIma3z/N8FjFPbi6wNhETEAVGxemI1obj9ULQNhLZF3QkArm+eu+Dxn8pP95hSD26ojOsvak6zRIrJWDoS7ccyaMNsHWm9VLfteNkgGyjbHw5QC6Ncvjan1EYDlxnAXOlg51XtSVttT/PdbtkKXOaHj0Z+HPUCT38jQBQ0iPWtTnwozjiE+Djzy+ALLOiju3ulWwxjJm7bgemWhOlVYqP41X5Hnn9sj0m+PmHdHHT+KWiGzkOkzygK6Ao1Yi7Z/fc4FvGUQ/NUAA6AQD8YvkUDv2JfEPnFyPk7VFnFO9YmvMFJ0/ya4UaZGznpzJvsAkaYtGSyvehZg3Iz9yhAdxJeDAxgjycl5walRhCtHx9DAIjjRgC3m9yhDDiNW0MgpGEyZYqJdqV+9q8QG3nykG98jDtwFBZhEUJh3tj94cdk5W+dSXLTjCW2JkhKeFsa3AmNkyn3GuKHMAoa7uZ4o1CFk9PAHG8rPdwRV1SJA2wzrjjQ9HZ7euMZkZg4Y70k1t7xdILIeYSvqX4n/cHV3h1iIF99f9Jpq1i0h3hq7PzeH2cjF9yHJm9yJige1aOAW0rbwf83O9fXf5TMoBcilazJIfg4GH3du3LAnN9xLnnuouhR/9dSeXk/3CIuMZJr9Svr8iWdja4ascGbj/75PBwGBTriGLYX2ZEYbeBAFCLcI79HdLA856kF96+sRVb3Hnlpeukb4AdZVdjO5Pi0RKxnCsPlRk+ztjld9Gp5et3Tj5b8WFSYUKb2BK0cgjYzgmZPJh9D6I9Rg/+Koz7qgTcTHrcwORc90UaZWrQYlXy2KURnG06pBXyt8xe2cIED7pFBDsaOnfOq8iyeHZ9CD5LKbu6D++tMhRpIjX1vF6N0ojJhzig2t+iYzqPnL8yX80REosGUgSCsubI4ntnPZuxYg1Rg9lAQ+sfCFOXV/zO/+JHUXEph8F634QufXaGy6497T8yDwRpKPBT+O8foYllxsy85+V7+BoeXYj6A3ier9dCFfL1EhvdQIITKmYB6DAEi9+6IgVqb3L5e6Ql3LOT9iCU1j7UDmhL0sCYB0074wlNRl46YNzWzs0aVhGvUH6w0WEztvSPDozwoX97sI2dBkb8n7YOzj32OJnGhyPsikUSjVhgw+8Uir7Plvyii8Nn2/JgIDuq/cPgQvOnMLU2TYcIxz8oMddywlCNFKpzmtiCXwwnySaAKRL8X8/xHA25eROPa6xUYFuqayxa/zB0RFFcF0j1dD7ZbOiZYhh5LlRW1K8ST6tapUbWTDEnsvjdpZnyhcr9vDao2n7XTVoCwntVqV2d1XiLtfeWQhVNfeSxLISW3n0uMtm+y6yUxQM8Xjk3nXmnMZiYvUos8SjmjKZ/e5QmPu/OpM88y8/m2mT5yTx1H5nA2+wkjZjvwpUjX/mKx1PtcWeLUicNnSYo6y7MjMhq8ZUpnRPo4Q42z/Mf+1hN0p4PS74bjIdV39zHKuB0MocIK3RsR42yw8BaLZGkZlUAl33K9RuD98EEZVP89vQMFtYUYmx2fZ0MQd+XPkG9JSqqXCeT6YoF7gUEbWOQ2yuJXd/6afIJOibvvMlYpysSrbZ4rqPR6IMcOeNBK2IjzVyxtNwpp72L8QTAoJP3jzfQ2dqYMc/7HrVYtVF17luUhAU+WcJCpYbm0MnsWPKE4gZ7g4zuch4dy8URuqAA",
	goblinking: "data:image/webp;base64,UklGRp4WAABXRUJQVlA4IJIWAACwTACdASqQAJAAPm0skUYkIqGhMpd9oIANiUAYuMWbU9OP3/no3xvlPT+Ze+16WNw35nvNc9O29S+ir0vVpC8K/svgb46fhnur7CWFvsh1Du5P+P62P5zvR+YP+f6gv5X/SP9v+Y35b8gOAP65f9T095lPif2AfzR9ge99oB/pH1hf9D/3/7f8wPcx+yf7j2C/55/ev+v69Hsv/cj2WP3DdpHgH4awdf+GP2QxA5oD6g0pHSIxduAzNzAdv+ihQ/j3W7AZ1/qDkFObGV7/BINNXKJO5BqQMMr+u1e8ahhHT/tp1ZPXX61bDdZlY55qg2ME5xMBizCSwajUTPnGfxHI71ruS/c4TnW5b6tDT/AWC6pmAUve9pV2vpzzS4dp58EWZJF/FfpaJa8ZaUi8jKUEwYad3VHqlJPxrbR1nHO5OFkyTNhT72UC493TDIt+knN6PsWLZS+qz66iuGglFlwgfsN9ZcRvNPx/pCyrrs5hndTjr0UjG/0XPxZe8MsLPy4TyPSkdm8GCKq30/i0vLqPPHXqRWTo9Y+bYDluKFtzcCs8bJJnbSgYLlDq86F1nDubgRuxSnttEa+PWUfeYJ2Ro7womEDiRrY2wc7X4lOuMMbOuMTPmNaC3mdgb9cE40Ay0Ytwz9WQa17JdtKjc2CPhPA4vn1R8bdqbfRtmT/VW/qLJMhy4y6c0auI0sOi4S2mT+LY9aSLmAIf4NTdfPJVRvWa2nt/5P8Dp4Slusy4bVS7R7o/cQQBxuS30NiSOukKIkleRNnzvk5UoRGfG50okdB4eWEwtjzztpSMmDYgViVFu5bBYefv3ux0BUgAAP7+VdAu3JLMRwH/RAepX5JpytYhA9GkjS0EK9DW12Yur8qoBcKPb+opZOYyzwQZtnv6/1h8CtNuf4p7UZY/sZYFeKGg+xKgvlIVR2NLg84z7238/tTVaq+bdvjImv9I53FleRfR9EnBPxj8//+Sk05mXpp2tN0uCMaB2yJoD+HGL9YbP1+1ifjUf2IHM0BPITMGfb4p5fRtpiFm+QorgBVBlhVBXDokSxIV6bGBdYyBnwmmSCAebevRvTNYCetqNwqrLkz36g91OytPfGhoWMLhaRHZogztLdU6ZT6nmpxgunCbgixR1mrPUVmI/okwZhWdhmm56e4Yp5sM1IQGrJHwCpVEYicc4n6QIqS0XwCGH02wmmdoPgFc3uNUJMYT6X8AfsOtX/pu7XBh/dWYkAi8sKKjN86zERM9l8PDnZULTm1uhB2zDhN+eP5gzz1h2pyc3gwh9nL5DRixk52ND/miEoqFChL19Jm/tMDWqaBpJUgFtZkkgQVNEw53Vhl6kOx+s/qy/DVg+5MOmiifQUDQyclYOH70dDebA+yTkpW6jvT+c73/KUDrKEh+awKIZS2/yyoqjJXwK/uM7SLjwGyIQwAAvnJLMRwH/RAen9n/th/+9XfWW4fDW9ZN/EcB/Ut2hI9apqdTewMlOLYM/BGv4WfaqRTlgt/wh9sgYDuGfU3HP7jwv1MlZRPBw6hfytwyNm6qJy++9pkbBK2a3tbDT6K+/DnUzW0O7qEsNkf7Gy0P9g2OXL1gWlul5AmztXnTFO2PpG70RokeJdsodjuCamkdrSlbuOek+uUMtSbOy5iqITCHKHBFfP2Y0R420PFI/gOZaoW78ZDIp7oFLElUicoP2Rbwf3odoMV6TgNsBcr9vVy2GIgLfK5rXS978lhpMNZUeNh+RJ5bATLz1nefPbSseR/q+dd3VPAr37r6SaEYskjS5LUE3SRweb10G6cLpMte8f4PanO2PIL9CHlTFVDJ0qd83EVdHOh/hcGvX0jKVeNkRGcg2t83oY6B6XKb171xi9Giez7MRvqIWQg7ReUPVjCiavQ7xibU6jHtXL74h2W521DHayGfsNtfGa308QhH7imDfiFO+hYl2z7XKd0ZU2sf+Hovbx+y+sqMdvqh6mK0rKZ/MEVQDOyOYqsoYi/VkA3nWlI5O7xqVizrZ1bWNsKfPyLAzyKC6Q0PF/24hQxTkjgoP01zKrOSKyhLD/66b7hr2qfmr7VxYYFBMxZKT8qy5ePhj+SINLCwIfLrLESqgkIrp6i6eWC0U6bySq1UNGL09zAzkMF4Z/WkDNiies2CwL0Bj0d1lqD8ZyoAFqji99IUT/RrJ1jq9VXWgNYppP+be4/hchXy3kAYdj0IbeUo5MnUK20w0wq/r44iyIUry8qMWOoT58eBnI3vUuY5c137XNeW12IFM71IW7A+PANzdWOjj9/g2ndnmO557EMZLOenDUDVj5ALBGqweK+zG1baU9qChAznBlBNJECV8EiL4KVrATy0ei1q7kpt/bkoaxgPZtB/SPgxfVPDXP561agBthbtsNDwZKeg8kZm7ShFIE6DzBoHV/QiYterrpoVI3e3PpWLtJoXb7tfUe0RvZ59DVYLgLpg2baBiT4aziaAmzqApa6raTlKesuPlFdM8Gf8RzUsjSWZpZVfsZUTj19qT7Q0trCxlZkVJ+4xBc9iJiUbCmOQQ7UUum//D9Z+1af9+vjYu66/Ia7W3sdBhCsRQshvx4JxKaHcVcD1T1ZKA1EF5zxw6NR525EKS3wluKmRAq37lLkVV7kSUc8GeYFCyQCGqG0CtblKSl48VaAAHAi65wNEw1hgr0h3D+Zht36oCyt1rxaXGXWEEIMF4hEMa1Ln9bTffgwRUXrkF155ZbwH3brhtjOlvtHrTUpltHkDA9MN8tT8N/gg30A5lkTBw3UrscTBMtIFfE1Hs/l+TKF2yktpjxS+IXw5xpQdZE6+cLRUL4jFPLTZZysEEN+rHoqijtZSm0Op+8D1wSexubeyjvaUGjMecCq9Oi+Bn0h/4THdO/rmXz1bjh0MoXjXzrBi6HRYFpcf6AvMjaIhQqCNJBUTBJRv91yw9b/mgVQP5vURNXppkV6Es4BeJ6Ls/uWMzYtD3ROeRlWYTgKFU6Id682CUKOuS5L5lXEmf51EPj86zTvGbNC9LHaJIRIjE/euOjpAPYxrT5OuAJtyV/+48v+t9bxSMfdfDMNMyr1p6AgTfItGd7F5AQK1LGMtfmR4dyiMqOm2CWld+z8XacDhKewrf/BbvYgkHDp+Gpn2zvL9V8gnNVrl+QzKFINlW5IULn2Ca+qJ+/zfEwAmd1+/Q3S1oOV5K9scgKg7UFqXldPjbigiSW6MYqJav/ZtwSbBtcUPilFcwdrftWuCvcLPHQgKW3IiUkoknoxbXXiH76MX6I/vQEzpyOYXPNnqFHTVpqMv2y5tNBtHfQ08wjUJX7QHAXdXDxlCH26cMS3pOSb03FqYrjKC9MvsRpTBfR1n1x+Gz5/8/VMiRRSn+FfTxvIHx3D3gC7vb2Xkyy0LksHRHQRdXRTjGfMlZ8HpXNadgpDrysMhsKd+QccHQn/yQNd8Pzye7QKtfYE+8zrMwggIG9FaebSXjReRFg0kqQWKWgMJK3Z2YPITMOT1pcs5fa9L8wFlqrC/TjhZ5ZznbmUhvjQjyuWlQckxeiYbO8KlYdLIe0wbk39/DrfdzPXu+iDbwfftxQCHOJObJkPVkR0vkzKSvi3KkCqBOU4gv4Ei+9mBtVz9NQ7xEqB1QdppktuLqsBRihAQDpYnUmy6rYLAmcx2UPfwwt5h+X4Gyd5j0R6fg+SeGk9Um/E+MzBv0Qdw/0azrdQEAU8i2Qua11WxoAuK9zNL8LhUC5bKFRMeCHtxThnGJ9AxKkJdmEJH4tZTrNuir7PqjftK5mGS0zFn9IWRu6zvjQmsEk202s+mu5i8+v3bjOdLzNnmfC9xCDP9WduXWTUPYL5tzWSyFOyfsQtskVdzuL39uIZEcF8scZwLfdUTFBBbKP69iU4V4dfFFgLoOD1XYWl3fIousWCsu2dB7BE3tV+e6jf0shGQBLEMRXbKTloOHzn3SjFWSiE2TCaDWnp6InhEUNvA/OkrQh+dtkjSX+fCAykC7d5HPs8gKiLQRwQds4ZF3aaQYbtkWtE/QJ4M0eyYtOvsEkTBo3XPPFox+traLxTFzrHLRzOk/drV3ZPiE3AOCam2piGXGe+Sv6hzZLIyn17Fap7awaMShilBlyqwkJQ3o4ssHCwwPYojORWo3IovLdVQKmB+xMzQNaVpXVHQ4HoxzGkT/O75s7YcLFtwgr6717tnTdAlpIexrwD9Dr5DbXVu2zQgRUOg4Bd07M/NY8fti5IpiLqoNWixzHOdnCm5OlE88/wo8npuyFbWDpa8Fdf/qPQ+oMv7SbhHB1DnzhdaN8GMRay6a30WuK2TsKBboppwnS8bHWZQE6170bE9hgbiv/tssQhTb3Vg2zgHdE1za3d/cZ1PC1cZW0TPhpUyocJeNgqKcWhaVxUCLvVunZ2iLmrROFvjhyvhtIlwFyJV1uVJ+Jb5G9OiB/zZe6GUvi91an9puBl0qHuJBaVNI+XHDlBCpJPzbjB4F/OEuX786vIi9G2ClLogmucIt27oRcuCNQHyEVQ1aSBp9CmwgExPofZOI9S3wkA9TaTm6BzUO8ngaH557ZTpqtPC6VL6G7iWoPG5mjZr0qIe5MjAirJM1DnNE/XVRMPy3EZBw1lnIWx5giZ8q+Vbdv9ip8XK9fyUAltho9uPBAoYybgpUfbiu/5T5STChR/7t7nyizQF/0PL3Hi5/WsJWUGcnrvUed2cMK6EXwiTBA8eWlxiPI3dPM2/ZDsysJp9XmFmy5lnQHO10OErE5ik7r7gr5njHAPwSh48DTvsEv1ZlHvLUkxG181WP5a2x1hhLQYed/wyGcLcOtzSHcXD4zkqfH6722jkQzCIgTps+k0bPmfaK+CYkuN79TJhKiuiug/Iax5TnzStuLpaEQr3lu7GpizL0qrmC40HM3376SsODowWtR8zHMG/sU3ZGo8kLevw6cScpANRahlh1MTbTLR3MQWbdvQDDTrdJMnFI9STKS37JOa21F5AYgllDiMGZOfaopq7B+4CfRZP32ONjmpndlW9TYsMRbQVffJ6JPwkJAPO3kLZ2/8anwdJaYEO9u7Kuqc+xLW71XRcRKLBfY3094i6d19+cVCn0nSnCOhK9W73ZMgXJn5E4bZkGSlSVOH3koN20u7OKJ0H+jVUzXJuOF6WuCG3zHSDFxRf5uq3TuDj24txT2aBKT/GiZfev9DGkb0mNEI8oZYzUmglsRjklcWCQGPreolp9bH/u4r8YflSCPCPWTcvOiqZVARvCaHzF0ch9CXZhR26qpEZkrCy+ol1YVrvrlF8oD4BCVCw8fNq8nQbB3+yfOtq51wYhoi036dtyGdG3jNkSm+ZUlYAt47mTNJcJfKVsaO7JCok2fSxagONlG5zqVT2EJsVxGIqCPunC4Ny6tHqzGoiF7MQ+eHDx/oAkBterSoGabkU8G8emFzG0P+pJrfM9lbUufpie553jFXYH2kMEDpUivUrVm5D13fhdS6jogRQR/QUSSrjwxuuQlm6IOIFALW6AyjipZmlIg0/pbJ1MfaJtDy5o1Ds43fLDRudgaZV3ILdXuoz8J5FA7E71NwtAZU7eYP+llgXpQQfeVAQj3PkYLm2NmoN1Qv/xvUpI2zfextAccmGPD7MJb3SoZHk0OKcaaIlZMcHK+Brf9dLdvH7uSGio1Flp6wgVK+M+eKOoq5H/yAlv6zpWA78JEsPJ+ufp6v0JyhP0qiY/QrsJbKnS7WAZUJ9+DT1e3jkAJSsxZbmkO/vYEL7jSBofsb+9QLkhW9aEitT7IDWl9+0Gv6muF9AclrcfKHFaIl/r9oexrCCmIQM8aZP4DRJaqGjArUpikBLiq/rqWk+1kwVaXFhXvAjam0OkpdQfLqGMaYQmHKFZvIS7Ivi43opPZgnbZKdBBOoTvhlAG2jsNkmllMkWgA9dJtqrvr8mePNocubw2WEfql3bnlgm+y4xo6pzTWiUb275fBc1QfrgowI2d7Zxw5Ebz5y17n7pLFiqLe4V+8WPZI4EMO7D7gN5gml+gQSG9Ypv3Qa8Y0r1UUjj3tEi2evlmqVM2FCJJWHNw65WRzHjUg9GMKKkqeXStU6Mo2sMpWJcIUgzMAAVE2PYBkcIXDCte6ZO2uOb1qxJe8OgXMlvm109SLwnqMmNRee0HIAAQAvQVLs0JXmcc7EE52cpIdkf7H7wnLsuhEmt3rjg6cqG/AAru5TmrINcwaMgrSjbrhPSGK1P8wSJcBKEFDUfwc1scfAwzpYEa++vFO4KTgItrs6PEY/Ke8CXizqNUWffkot8FN24nBgVuow76n7TEF9meDozyGhrO13OT2mNPH5CAg7EhoK3GMxRAziw6Cl2dnHff8YNZFo6BxcAXRjImHUqzQMw/UwMhsf3oX+2FmEAhAAg02YHNA3wqctDrK5LOXcshOI7Uq2udmRcpI9RG3RBYe+qstipyrybpaatJd1kRnq6RasS+HGwp4PS5LgBv40jiNLcYrDGQGm3ygwlL1Foo0S8SafofaGqhE6NAuAT2CarjMuzch3VJ1zUiS1scpj7CoezGq2A1p7swfEyX5t0K4WMogtzxiaz9O/y99oXzDDvj4RlZ809B30f9i/v032rAev8WKY7dxWgckZel7KzifdE4vzBj4f33+w377cZ3y58DPbBqfDqi7CiyymseCyKUkjZzbfXmdZhZM7IhXAu0jvwUAbkXFK+CVwzXbJuyIcAlBzHYeZMN5D7hRkIuH8R5cfRmZvwq2thZT1ehUVxb5ggGtT3aNajt87RAmXsVL9N+CmFw4nRoYVv8MZCE+OwDHTAAoA+5rK1/HKGwDIGpW2FUrlHuzAM0Ly+VIoQSvRZKHIM59alPsQJvhvlBNKSoJ1MWORsf/JjVQzsxmf+MtAL1P5wJ4469Ut2BQJQTdXN4LRWXKOTM+eSiTzR97HXLoTicm4jLHklcEcclrQRhlpgqltc+HkCdnQtBBNhGdwj5RgdQTpYNRtebEjhkJDmyhlg3iQvwwE1S3S+ASSMtGcboLcMCMXvXM2zffO/Sj3Itiv/sDcfEucj2YtWzfB/+sAzqyC7VaXivsf25BKflifRGTA48H/kNVYGHolYYxRCCJ7EKimGSt7i/N+4Ft8yaqZGgyYPWQrnojtcI/Lg0kAN4CMdEA67EmM8CKIMqX/YEi64VZ86rO2CnsZ+l6JQYAANxHhnFVAurCHS9D9KoECMZTcraFXica0ZWmPTGR8jsnakmmgJqE5zhNFF0e4mkkMTCNzehDlB7pNiSc4zhnuiwV77kSQUtwtYNV+xjMlHnJDVM4nSkd8GuE36ehgLHP5qAf2nVIS4D+WQ2Rha1uXmZx0LQ7hcNLvwEzeX938nPqXqEMkTpRIsyRg3J78Wf1DwHFxUTOgCrQv7BBEO6kaNx53AtYnDoE1N3U1Px9VEdr/9BKwB7kl8m3nZ/Uuzr4h3xeaMkvXnlasNyC1GMrfLUcOraoqqi+KDPTF/yEBp+MzuFAMIN9IBe1d6w/nIIDCOEc0gx9xTV7FPCoO3nzz42Niz7DLl6TDeQtiNBKTdhUR/FAjWjI7yJDTF/6N6Bx5dgOGRGnpuqZ38B9JBp6ETa/W+VCykY5vtRDl2cWFV4NOe3QVHHMkZI+P4gWXMPI8T20O+WK8nFIMbyZut8YY+ybQRZbjrygCjpjd5mXgztvmtlYWbIFcaT2+yZZvPgHSyamw1JWUnnRlFwhT7v9AFAQKtJMVwAAAAAA=",
	goblinrioter: "data:image/webp;base64,UklGRuYRAABXRUJQVlA4INoRAABQQgCdASqQAHoAPnUwkkakoyGhLHW9+JAOiWldgFykPRc5jSzT39t5lWJfsw1Ee6/+P66v7Hvt+U2oE7ztEe//mafk+af2m9gPy68CX8V/2/YJ/U/pFaGv2j/jewX+vXXC9IVMBv338u6tAAoZq/qWdTNNoeCgYzAbbrU3rDOevyJXWUpsz1WPnhgGMj6lAySvmkHeg5EuSmzlZZV36l223g8i9ORo/XkFrTPGD0O1jZMusq32B7g3hMUcurTV9zMFpFMawa1ybwKJMEFUG8Z2X2wIJX5u1dXYonILOOEqCwoejQcnvyh4SXbxVcY6Y4oH7R93BjC4AZpscyaZYlNQ/kMM59DvNGRARyxAOyzWXMFMOsbQbP3d/UpED5yHyfFlfqYgxtA4wmGm2rUPMl+yLwD4weDvIJR03kJH4zy1Tzijt2e0VcB6/Qkg2nFb+R6CJc648enHGvd5nOZon1++OQRBXT15Te2KRzIj2KVl7WsdTSjK8lNCLkbtgzGaRSLHsqPJz0U5ejQzj07Mms9oNMfbuQNmbjVr9gXdGxGuiCktPYTo1uaUTaSPi+rcdt0lXOSEwxXN9fVloLB0weVnvgqZpz+EKMsICUH4mFU9XT0GPOvU9OBZgxAr5QWNOFjAb+ol9AlMrbNuoDyT/25nIfPTavZiLiiF3DKZoEtL7GmF+3FoYFdAt8C34DqoL5UY5MXKUv4jIVPCAAD+/ZkNd+DkMoU+Ri0f18y7/fVFekOQAdwxw3zh+YD9c2hhkv+qz5G/16+Nkz5jC69NCdRUyFAqqdzvduVtvBxEQzUA/mtGNsAiPwOaskiNm7e/Gn3uh71xmkhsAs0I8T23XNDXlN6hIWCjhAs3ktH6yoxWDZiBmLV4o4AIDL11fnGjvReOLPxedB/0s5WkboyeUpI7fCsO3aaRo92OSCvQm3bf+v9b9aR0C9y1qI/l8/VKJbHglihSDpu9uLC+bfRrTWQI6qDb3RRAlXX13JUZzdKsabfCEgm7I41cnugyVctKFhuqaQ5pj54LbQQMUTOH+WW0sJ9Bh8+B+MBZTcssHuBJwb1e7d8g3KiMc8d9moW2vYZROVbpb3JZrsjE35l0zs8QdLJ/Pcg/TQmPDhSXw4yK3AiYOI2bcD1QvFFecD1lgqJNkisr1Z/PmGVru4JHHUbhcgs+0+imtvqGfiD7evKAwW8gzoxONIlwO+64ttY8MrbRl68EGrrD4fLODh3Wt9gaymbhn90+0Fw2v6ULb/DP+n5XO6bB0cBB4GETEfOBgKfJUR1wlXYeSxRfaXciKKl2gX9jymsqUxDipdrUt7EVbs9J2rAv4u6NvWJMKXzcDDMWdZvJTQggkR2iZV0Fkp44ocg3nIvK/59HlWS/HwS2DA4mqz1jL25E3rDtjMx+6V5HDpZ7f/XwHg/fZpQYwN2O8mRPp5Vie8Xi1Efwghri1vkgpeQHWcojTdROsACqfcmSZoGfCJy4QQx+tFjmZxcTHMd0uDlyoeZPn2pVe0dtGOre3wHz2CZhPl/31UCgZtUCNRztra48hocdiQWfMyKO8ngD09WGxRGuDuvSuxxaZufTraX/u9GILyIg22+lztft5U8bpcZidMKivzcMiZJo5tTLo++Pu9XwmQQ3mxiKsYMYrLuOesKp0gXK723EoLqu0EorBokt/ozTGX3eECY4zn6V5ln2NL1U4O83/dcn/voGwpgTJexLJ52X2RxBO9Wy5YwHV2ShtkDm/QV9MVvG0rmKgVnZdempR3AvdeRlyz+cntHt9WwKrKj+H1jYXyam3Wy0KQ/CvZQn053UQZ20os+TSYiwz45Kxv0v3MuXGh6ksQx56W6S1lckddN/lOczO7LOFBaNy4KPAZXx0jz9Y0ffvWiAXqXa9+T11P7kPUhnb56m63Han+38yQbuPZU7HrtN0pTuMBuRBqQaCuF4SWiP0AAcw7486rIcTq2jKaejSvbyGphDgMN0MUTBbjSU/yKPr7yeGm/ow8n+DrJTruou+eAb74g14hpI1EGQsvn1o4IORgUOn5ne38YViePz7OcNlWOj8UTonji5rpexZNx19HS/D3s7ibE3mgslnr9f/drjtJMXamSL5Ks1FxJg4anP3z+R8ayAEOxr4Evcg6DQeVRjiwX6DSNBqsgoVn2uB6eq/IeFI6lLM1V5YoBaqWC13SCAUF82oKd1NARNeooh4f/1rZ3MVQ39f9u1P9AP7ltGRIFoz/f9M+tTYw2QVvHxSlGvZjgYLo05z+/aK59ffV4rknv6nYhwKzi0k/SXhW1ihJp8M9SGvL9Yc7VcMg9jafPPZUFrGaQ6lSLhJJlQVGxx5ccpLhrnmlHWkiyjauXLfGQeRr2I3ELWIarNyvXtFgn5E3kHYExqpJPmEnLO+K87VvUa+O6UgYVuuUNoBBGw/P+So9r6/vJfH8LwnDWUQvCAoVdDlkPaQGSahOxVGVans1NTq368TpUuuJ2Xzzyr4EcYtOzo2+iwUJ55+cpgZDs7/pVfQy57BiVSMi/mD0cTskiuHhoKhRNiZ/Lab5u0c3Fa8vtEw0NU56Zq3Zlk5y47Rs/R8H2UTp7PEXaaWPf/pmU5Q6gECtbxo112yC6XnTLnhhQ9r4IBBQXSFYZQQ7VpDtMpzXUJMhWlKN65Tp8KbLafOn+x/9Ykb152AeHHmB8pCcjEt4Ht3nyYqff9WrRL7ZzlOp5O7w/qijfD5vvXC90/VCrRUhrvFbgYKUhlMKLCNuk/drRwuwm7quA9b2WquNRRs/+StoHygt46qXGMHzgS/jYKruJQvpb1SJawGbj2pGFUb9rbnPCZmqv0ktilYBL0ZA0qhSYrgIiouIRebwyrm69YIhN5maowUMGDbh1cvGWP8vR0mJFVMN8TVlzVv/jRx3Ol0wXhEjvcaYIXFBElnqRf+01f4yJ6PjYkdNoQPe6wDhwPNQte95iQ7vjlw48BshnCsTFgWkDIBO94tiXmXjZi5EpsCjvmWmQ6+trDx0I8HAbkDr9xRk1bdgVCWsTdZvSEeC2+OcsGFMsZj1N8Qu3Nu4X4/Ckd2l+gUQ2e8XcGJx/P6Plwt/rfWGFdfHXd09vErXfwyCo1OXVABFzWDiTY4YM2M6diyQ53duppRugjXdXeq95w2fa/F3n1nfXFdTcLr4v/QYUqGaqSZ1WRNeVs2i6NDsIHyJiqtpcZy3Xu7ve8QtU9UMc8oTPSYWuyOvcco3BKQDZTB7lPrGOtK/wtjTOH+GrBxvCT41lFJ6KHpyEoR1z9Rzk8hE0YIQRvTq3pY2vGAVsDpg0weeBieL4Gvk5Pt193S7pY7zuuThRppWLGhLIfBRT8lclnp07UdthtnA/vtTqmGP/JGx/sDdCC0ee/sfa7jGT20Zp+5epBX5D+LpgG5VT75ivNXBTwdKX8EnDRXGKzYZdKUTqi55knw77L/RgTr/bH5j4s7pDNnUkHog/5NixvLd2Y9SAAFNxkcnkrfunWGCN7Lh/DB7RIFowq2IYBolB4NFPeC5mT+Eh3QTevujqJvw/XHr+CyVc1VjnIWpHT6P9W+vGiGhbbG5WZg9V8cSXBSOsabDxGH5X6YSbZK6+WIA6ycoUwz1PwEuvJw6sO4P2MksMgljSjvKHoZmryPZAspq3dl5rBHTOmYbrlW+GZ9E40Hx03QXxWG6MTl3S+VZOZGNICo+fpA+8cCaPLc3APP/6mD+VGvaRfIrXNOB3hUIGdTrSxuRbCLwTGa9NLX77EisPO9znam7fonym416ZSFKvghZeN+bjmXSMHMj1pYwAg3E4p1rufw9h37QDPgNtIf9Sva2NITXYStA3zaIllvG2flcpvrbhDGLjhR7djMQANRy2bpN/lVyab/gV7agqsteMMB9HXGJXIyWvpR+bBV+6MC7LhHfY4Cw4I/SgnnVjyBbOG/F0fHrwHqNhmj+eTe7kDqoalgMYKgdlbEOXPZACxr2i1oe/EfWwGSmMthvaWTRItQa4nC6dBazqNtNdDEL1h8bPhU1ZyS0iPKYepUq7kJS+gEZUN1C4hWSgjIAido6caYVi5qepS8Ve7dp8LkLnC63vlmPRSzjCHgb3X8g9g0H9Tc+jA9/vY+Mr0wj8qDfB1lkZRqJsOMYY8nRPD3y5iZ18dr/4o24VKCrNZocLpIWXZ6MNdk1K5rAs2/18m79bC5+JMdIzTUF3Kdra4y0QqcFYoPACiZIxDu5L5Qvgv20KQdrG6lEF1/78T561Rv6+yoAXHy1x8MchDhkW6iCyzwNO4kdGzDHYfJkbQWLfaUhxA6X7RPpUaOo0ThDYfPCv2MVeB5v4mldvLCb7VXxJXJEgeAUOX4KxHUTLOUb1VuBTKaXie/dmIwS/HN1vQW8vipBqwgNXmsY0KZLFvj3stxZuECemRPHbsVReL7M9x9nnmKOrwJ+/pOgUTgsPMATgABsYgdlotGkVfcy489DiD0NrflPN2LxgbfCd+h4SXbqUYHhesKDxgOd+mgXHUHej7oDU8w+5Cb9MUtRUeFe8oQ0vrbQlkz9Jf4eddeSCr1MI7UodyvpET8L+BPLAhTHdcICPDu2P2LjD3qT+Qve8rYsPChquFWzmb6KNoFJe/qFH2x0oRyp1YVfHktUyWiofnRSkVn7ZMBFow8lPz91J4hJHRlKPXgsMd7C9KbEwfJa1sXOYQmCIJlI7nVxrtKSjTDndPLwUcD+ZfcxTGrv47a8Ay3v5SuSGALeZTLj/F/B+/buBzGYs7lFqhdtDeSCD8pb6kUWAFtm4la+rpS6uF7yoTN/boVULhpSdJjnIFyUJ4GQd3oQsHYE8QUHyQy0IJFTObTZzF0tA601p8gRMIW16eJug/9xhPo/iWBXp3TyaUnu88puZWP2WxbUVLJHkUyOMx7wwNnkBYNw7sf6UCxFTvBelfiITwdBhhLf+yv1duyCIc943TAsnl3GcoPGH1pM8BvOzH9YUc55xMewswfJuFe1but77pKbQwCvMpe7naB/Q4+gx7lFttkz4ZlEvtDxnmtZHW+CoJXnbKjqMmiHsUmjHN8Y6bLmWSEpaaJCXvLZPFC+uOxOYQWrAoLJrh2oUXEG88a4+bShVNjtDpoeRVBpT89/ZoIl/B5gBLL1taid57gKyAAJ26Uv2u3JlQgb3VQ2BuBfR37NVP+Xn1KoGEfRXgosS6pfJkgZv9u8g1/9uwk51ZL+RVX1+ovs0SOYzcGNyntbFsFcOnYsXiqtgSw6SDVkpb+HCl5kpZrbmtmyLIXnnjw4QQrfumF50KYUPV19BUQn+BrtwyHiTiA9MrW1nHreX9L3/T3OZTk5G4LSlP5ChcLVq5kwPN6ieVmtqT4rXR1KOe5GudBV7zEPvgRKH7LhOWTloNtgshwXsmMr9OtNtpk50J/e0chAbjNYs8A9/8D3+fUXPiKCbWd+6dYxW277I14K41e8qwKpHgj464rjzkUqwqoINGQEcGC6fYpVCEbm5Nkd5nutviC5Y4kaCpGUKBqdNCNNewpl5LsFtemSmIMQfxnmJq6AsD3E1WhN12npVkcWHAAaincgGpsrbbzQrnVcoTJbFCp0MR/AO68ESxvg67i8ZbM9FSdQ7+UJRU0ym1HyJVXWzk44eNqVl/MWNYRuGJoRyrOoGqYqSBkODTQD6ViuJzw/08415DSv5KJgOwXGe4enyZ1anth93doc4a8PHUcXSw3iMvkF4vx61VE/X1IYSIwPoi+jUqk5VXEzRmEBzKFW9FCpvBIGUpR3KutuUkkcS1iHJGSZNogGP8lTOCijQfT/1VtH9Pfb7PLoa3zmxWBp0I4lbWn8VFr/sktyhFLFX2KuQ1jwCVVoPDpvC/4edUXa4xM2vclN2mrqF26JZhcICWuBQ2sQqhK9b44EIGxfgsFz3GSGwCzmdDHWPYUWnPAed1Jv4uTfAIHlCIOZmZUBmhWSWK8uwos10Mkr9B0kZLP5AXdjyEUS/OZeOTSiOngIEUZ78SBgEvulejW+WGfBURyWdxFLy7ZS09b/o1OBWcOEhPMqf/Fzrd7pGjAOJIu0Q6dwFwqN92cDphd5sfEyxB58otbgH5WnK8jp3U23wJpkVWKDU2h3g4HvzDnesFXAAA",
	goblinsandbagger: "data:image/webp;base64,UklGRgYOAABXRUJQVlA4IPoNAABQOACdASqQAG4APnUwk0akoqGhLTRdKJAOiWkA0Ux9CWnSn5dfkkgE4n7Q56v7jv3+ZWoF7S3l0AnckTesgDzG8CWgT40ui79t9RPpk+jgjPqfLaqH796r/bPjk/4Svk9vWiHj35WVDVisaYMH17mZ3zMm/IZacLesEvikxoQv0Nj062pKk2ESkXpEJ9aPVp9G2ibohjz0x2u2CE5OLXz673A/moz+o1VWiEfDXvxwyrO/1YRp1SnUENGO/lhRG6L9COWEtGOe7LjOMoBNIGJtVDr4eAf8q2An6OJceklQljCh3vEtjy5DDExuW3CmjVPEmKQbyV4DCRJgxTf+Dxd5c6BMU5VIHng+sz0370gu6N7C0WeKZOVAKPIH25AICORi2J/Np4s1aCKKx6wGWvim/rfYTK77xjUvyrZVhX7wJWSKNq8/3PSNx1P+65jkeUjMaKFvVNcwJXRtoQJXuE7Z3aLuD//liSRAgC5jYsL6yIgVSE2lJVH6G/Tsb9PYJ8hx1jocTmLqBQB97os9NdCH+bnBi1yjyTPTnmjqHBYkPDz+jYPpszkfPffxVbAsHb3avJ/RL/OQkvP1irDT4Au3E6w0GbYgsMy7ScAA/nT/q1f/HN7/0jGq7jPn3jlI46P/zYb45eajFASoY7ouIvmaBY5s1uX9guiUP4blQkSwL1uLKWob5gFIgWeZKnL6BgHrPESuYDq2lejlJsICVc3x8bNghqLmLug6PQraqBw7OtGLvhSyJipOserP5d+aTgFijdgcpia4g9uNG86LIkk7EdFZ8Cj+yAudn5ElNNQH7HfGi93b7aianhSSisdDNxP6YebTJt9iEg3H/KOWkcWuDJrQhgqh+iZ/1jyGt15HzvQna6gFmX93wZuu2GJECZC0C/QRsB8Opue56/4GxtOOUdc4YbGZnoowz8XyPmn2vXRxZiy16hrvbbGv/FRSpoezupL7GpTf8mDLZbGM8xeLuEPZLD/v//qxUCin4zc8b2pa3GiELwgyf2cmmNuXGucuw3mO4dRWUoPebPmxXR3NrGjF/AEjlvVEwHBPVmNDPFjEPFVZlUeJDfPcEQrscw8Fbky3sHwtlKTb+oDh1M8FYO/SwEgPPHTE2qZbFtfmjfvWWUfnGeSrtyOntu0CMubelxPtsHKc/ds4K/y32vww2ZDYGqTeEy3SmHMjOPHQIBtl7TTEmMKHkvd23m7osjqTm0MuP2AESF/mK1+4OTsMHyxEcuS2EyAc/BgQXK8NTFDi46+N7PCDcrfcdzE9m9hFxLjaVj/PoWM0yV/H5rmx1xphgIrpUrk6+K3LkBTTK1+Xhe3tvzh/UNUmQfygRhHQ7REfHbT7kU/vCmHlhEdsRfeE7Up3gxwrpnhjH9OiO5//FyvHj5LQCdxnQ93sfSH+0h5qh04gmstsSAN/wOJcPI2hlNXHT34JJQwO1nXJ5jiBzKomOJXklprWzVfxMJ/yeMooG5GH9qbcC4pCsUbN2TXmA+K/VRrO0+gtYMDXkNUWE8gbwSAdqDBokGGOg1qtm3mg4X381lO+2WQ7/h8AfUy67n7TXlUZ5RvjdO/IIo4g+Z5o9sPA54xnZLcMeSPtjdkdj3LAmRTCRQ0PEzwd4UdUVj5Y0V5uGo7u0HrQ1tlqBOvkFJs6KOmKNY/7OoQvQh5eYk9x7UglaPT0mNCNJ5lylpsfFLF4OReW/3hdnbUO3TaOyeWwCEiYjo/fVvBvVHP8XosAl5N7wWpfGI8npbklJ04c4g4vrRAKz9AQmpmS22O/iADAmw9oCCk8s3TfEk8CsljwozgoOqzNQx7fH27CgKGeRL4dZtFfS+9VBrB7UT7ymvgjhNUwI9rDgo2RCi5p6lm23RayrfPAtrVDwF54JuCwCZ6eQPnAkr6iQAPUrrwDZ1/4F2pwpXeWON/34WeIzoLV5tub/qfdtosPmp81utkjyBAt+foHK3kNguKGArnnDqjZMXQz0fmWOOlpk2+dx+RAEmjgA/MTLrtsa2ZUp8jHj9qEIYQnWIAryYBXmwbrhlnFwMD7dR9vG8n1g7PcTVQUAUsgPyJCWDent5Y6RrlKgoVG4A0lNVANkyLmJ1KYHus4WGUGFf37p7yPzmk8ulWTFoIZWkJgXB8yFHdjNH+EVPInbARjHPQkPdItznD0d2c4VWXedox3dXlJHpsl4FBygn6oofwgJVsD3AVoF5Ps1NyRi6dYr7BizyyM8MkV6UV8T749yLyA3BDFiLPAxQZdJ8xdcwUJPF7UhM33RnjCj8/JDUOteqT5HYS0DYDu3VcVss+nDVvhCYNJ+CIOzx0YfgPtPdEdq0rqFPq6kO0ZQIqND2U4k3snPEiYo4EPhSUOoyd6hg5kyQ1hDgXHjZNCHO1eaYDfxavNbpRw9+B6+AUqzLNk4xocGhqrMjIngbANAiX7QVmQQDPYOaqpdEakAS2uC+RQJI79kev5fkQ2WHazrT0KX91aeHOkaL1NEqJLs2juxXgwuP2IPVUAdFy/USHcn4madklrW7GUi7uQlihj03VGSDD0XcCQB+oAxOh/MlZZ9Z+baHzo2qIMPV+NvGC/hvVh86myb7q/GyBD81tmtWTgMxnmobR1QIf+V5eBpKJt5mr+oLINiXFduYvIiAs87Qw9xC/jOzvu9sT4ZicQ8sK3EOv4NOph9WPmmoC+F5PAQVgKMfkWoLF9AaKCJhG2vO5vxppwlq26MbhyLPUG8lugxU3jRBx2372YQZCI1eM2bHcsqzhZUrzgXuRbAPKlcMHI4ZqFiIUCr2WOCAlVYuRoFbeskQ35NlGbOzUm13jYUCG8PaqjSRcDCXj1TkXDZq5FGZFgiaqL5Kl0ZfM8WRbAaJpAmjNM4G838XeiXrYjlFLU9wrV06CzKkSUcdqZqo3U3JWkyuVHpwzq2B6jAcBKWJydV2auU4Mnk32AEn9fFRwlChct3m4NUEAwZVfOTrx9r8nXGMt82HC4KuRtCDB5bq2S3phuUaqS/yTgkt8PfJLxpKSM1OGItcJ+BwawE59bIKNMJ51LdgNjHN2uktNa6PZIDZRSBQZVfitmqVjdm0WUr1FpUQZvhTTj4KSPuMbP3gA3FiS8si4LtyraRPjGI8FT+ZzRABag1tBx9NwiNCVU0BPTCEg0IKxbJEdCOsherg5yGmIzeSCZNNu3YYGYvNOfA0ixnAmaLBuw3NrM7PtVKRU+kRz21nhogWuyM3Jf2Gg8rkHMkqDjq+reA0B/vAxM1QeSFnxnVXODxqw2v8vPpIex02rLPiY4g0ic/b/ofysQ8iBDHhixaLhaIxBaZ8+Eh0kMjh5b8txzp58lA0TIRFZq1F6+CpFkFrIskxBcWrLcodVTbvNNyOicSJu/BUBcjLEgAyxyBaLWoNb/hI2jPQzTbo8dZjTKLYws8h0HnImha119RUbctNH78MwIekFLdSpa4dPvO+dFOhvrH3GZLTjLPgRkDEftEM5Wl5YCoed9/KWYu9aC5YB6Tz8qO/JN9FBGJTcC7wObWu62e6yDJfCEy59id8LgAIF0eSaZvU2Miv5iY8uEHG1u7PAIwAer6hBNBp1h9s0jkofXkWtx2nWziaBC8Z/94g2sWQvAr9an7l9GZsqUcPjBUx6pRfr5gzs2VURXOXX53KkDUJI5ME8RJO3FUlDHc1KWmZCGY2nET34peQwX0p0jqyzBfQXMlnakgiRWKxOLZBpjWZYIEXWtEPz3AnKV4+FyvGjfXLwyQ0gSKdZqOWvpKY+Th7MErpLlD+APYXe7y261DGnAfoKRB4VS+KD6gLkEZN0le3hRmfO5BeSNgcwgnjzkVGiGn/2FtanNP9rXu/4HxcQU3eIn/Qe2yw1ZLCx5X6Y2vo7cwI3UIe10lu4bWa0uaUxeWXNNjfTbY1F2ipLeYVd69j8VnqkSn2U9NtS2ai3x+lOFYTi+eZduqMIf2UQNwk3qzO8QFz2vy28MUoX34QR8MvdqwtYggVA/b3c5pccPSPYRUYUaRI44PS6E9EIW6zH0awvTleLKxyD7BSBfaT//VMUisfGIXYhC7YjUwSRV2YHXx5E9ESOFHyX+BZ6yM4W8mDlF4k7AUbAC0Q7XHDeBp+7sGQmBaQOdF0bz7bwreC5f/PXHOIla+TK92aPlRmEin2vm95nu0G2lXpcM72jw3wGWXpJFJ/rqzIghaecA3BIf3qxB6RWTP+bdVbiDS8prDnn+4RGwJoDplH0kboh8Wefg6bQIafg0Zwi3IW7Hq+p0xGszwTSJ8My/2kOu7+/Xay4lFw3jrQDkF5EFGXAf6JA91svV02q5/v9nKihlcWJ0sWP5brONNqQ5PFE4aIpuNX4je1RzgNdXMEDdIzNPlh7VWcoi7phYWiFrwqWLSCT9NTCfEQt93rMpdSpE2YwSPSaN9KbUaej0vSXZJISb1xvYo4AZ+lj8802wzFkalyGyz8JuSPEy0rliuD3+O/piw2VbCoIQagTgkr4yKlBBuB7DQlA5aVtN45Ol+zSABpfd7u3/5z6NSuE0sJKZCYI9KN3r3hwVplg+FZobzfsYqIKAVWdpf2P0D6zaGG/4Xf4VPBKXJW5U0lNluULBY7vHcNkesmvYBuEWpeYPGsxRr7nErsuKxl5cVo1OO2zNgkizPcX4FAWorsCnmlYLKN1bqLYXHnqa5z/WRWEXOgCYG82U/5qg/H9zSA5cchTbrBXEfP2zDljD/2NAlc7IHPCukSN1oMOFCtewZPV2YxwReosIBVZcn8qAiIsbQPAdL4DMKsBoD3NkhcAAAA==",
	goblinsapper: "data:image/webp;base64,UklGRpoNAABXRUJQVlA4II4NAADwNwCdASqQAHAAPnUylUckoqIhKbXsWJAOiWkA0cgUTFFo+nGr8v4L+Yr6jIguG+3qeDst4BftLehQCd07N9lSMu82Lyx/t37ye4Z+unXP9Gn9sRZ8tKUUCVtJuCsJ82YHF/KNejDhcGPWJYalnwEKqLdRGdVI/OWVFqKydRWXJW/vRNSeL/B6Wj3cd2ln4ewaqRicNJTwJ8c7BNMuPKCraOPQkcMkG3sWdTKuuX4lZ8yTxJIPxSQxCtNd6aAgS3Dp134PwU/iQl2xEVRTeceTGRm27rOalzLQ45DjN1O95mCw0DpqqSBbNGdbuc+pMcFy00EYjpMwpi5zfFlEXIERwmwF0NrvkCIomaMxXrdgV5kZXfGO6HTpFbf+S0+fkHj6/y+g4TnJH1/qHHL3tH2wNr+EdQDoinsiBk6gKbf4Ear3jx4BfjRRbKYgdmJjNw+AYtWNqH1ItAdoodoTbwEN18G/blLLJgntkwfAC8vQipe1P1LK2peICscjObe9+cgVLRG4WBYy5HYBqj9VIeG13ymDKjMZM0igxlAh4XhsqEAUWp6smzDet152mK1d4EqAnkXTiJVCbwdmDXMUHwxxOUlxruyMcRAA/ummz786cYmNRi8COxk/iOGigHO/goaMpp4g/f48D/jV5zeae9sn7fHkhhXSpSLDLCnEcAXybof7lf+h9RfWVHeXUjsfyn0MYqnO0F5e4Jt4FPnQByIGFf+Jvk9yfPkAbG15uxxjyk5vUF/NbaEpGWuTf6iYlULyRS0qAB9H5WdRN/4MiOevJDgCB01tqv+RMgdwCIYqKe881u51htgq5YI5mT74xTF+DB1uBOzgwflT5Y5R9vH/pvXeMbuJYNsRF51TkchXrIQPWQxD6MdvbJnMoWLGsqC3d/G2wFrZfwJ3U5FOKT+X81suhdyzrLiI6taeWfZfyhOhm9O8fnHX3kSZlsRpsX2dkAbOMkczQk/mGyk7SveygdNPh5jWombYcgy29Jyz+AaUC4LKVD/nqbrVmh1J/h/v2ez8Fqg4oJd9i+dna7Z1QCH5igP+Axn3LWQ/mongNgGsM7wGHuABpIV+B2qnIfBo9qNG5+yJxFaw58RNXAr+FREFWKgrvZjV3XRot4G4x83Jfhvnm/Zzh57ysPD/NvG/PJAqbv6xRpqThieb9D9OjPjJmGTKKJIvY39v2wl97OkOhwc26rTESx8v2d0/PlgOBbEq9xmLWyfx+PEG/nbWP3AcRk5kPhMzk+n0F2M+9Slkut8sZ09cmcfTDlOWpsiwabd24ThN+iLI32lfIXv5H0KkJ8OkPGYX2p35dZXUbUBvRPKEnE6+4Hct3qt9xLk7xYWIJ7GAgQJgVAK+NpT+6VbhPtcWJXx2astTSqleJUu4LuxDSBSpz85JDqmJBfiEokTNWXfiLp3Lme0D0O9Eg4fhJoCxj9v0UE4ydK4ooeGaqNcW3jingo9GgNJOAkWwe7ZdSFHE41sYjW5qEMtCLnIZX/91TEKCDRPdAEaIy1Rx4Okd5e1PPuw70pyVnvUOjtrVfdyEkpnK/N5t//eIpGuGtm0vKYWGDDAXjwBhT7P9pS5bXIM0nMaveh3yeVCZAsBSV0qwmU2fq/+wKR/qAAw36jEDSGNwOBYGmqjPZGDwEjTwKQRdDE1nzhr23jSNtkVG9N/wSqcohzqN3gTasTjaz8XI7a0lGY1qlu2oQ+3f/P3q7Oh8pkrhy8N5+BlfBJYDY2iZQQOww6pz4ZhZpYKJdcvH/nMf+Lrll5hu0mmLR9y+qUkK/VHvZIXxhBVQfaQFOatQSblR8UlX+6wbRUnwaMj5H5YNGBLq2s4cRA/ZKhX0m9Kbl+gfpqE2aKaX6CWk8Xqzd9xsaAJ3II98A0rnT4uLJzhYtDaTdnhAmtaGtiSnnx3cs8HlZv/SSvsWFoXbQGDei8BV9MhICE02wHm9Elut3u7T3Mj5urSUpbvaGudXVbfz9ft6GdxjxjbqGSfpz1oL+61Y39ORfAdqDDT00R6xlKPU4SpJcXBzZ7nXTohO1n4bbwbqq5BYc1ifdnfxioPc+qxR8d3uesfo5BV33SWHHd3/Jlv8Dd5kDOg0J0+lErLZ2bzilsDkYn1ME9bWlu2IzN7Owt+pfpiBo/tYbIz7upQqWShPLq2AGw2TukLN6KrlWdSudyUKn1WtOnZn/fEnGZyB2iIePRslc9X92/9Yge0vLQZP0D8xQCdOBuk+DGo+cuU3cyg3B9eLnWNXaLRh+fzm+8QqziDTn3m0M5TS+ASpL2y9AKwCsyTnpPGCAj+ShCSyNL+RdbmzR1plHnH9ObBwrEiVzMXOg3y6iqTXXY+Eu6Muvze1qXNHzINp+TpNDFGwUwbKoQqMchuypn52lzWbH2ssLmAsMyjP4DLg0lo9h/YBJQ+muPdhcqAvlp/Xs4hWnmHQjbvwfVlGyUUI5G6qkocEXx8ZjmdmUEAHo63Lpa9fDz03WQf8rbMA3yY1eF93/uPinty4TourvruwYKSQijXUl512aibDDb5MYJkcAzfKJ4/224Jcj1gV9gTX3dn6YWGPBBcOT8R4KkKSyvjwlex8ZWQaAXmTYY7LBZvIuS1GYBRQiuJ3SO8hw16ofTWEbodkyodTkKD8nltOwT305IF4SFj8pKvZpqOBRvgts8a6rxzCRNhd/x8JTPMFA5E1ZnuyLm/WjWOdRH/A2jAOn9duj4kyrrP5CsXIbqg4XQdVH3q+HqKx5pcQFISmxGIJm46RyoKrZVTxoRbyo4c5P04TjbURIgPMfWfXRv6uHtdrzKOuv5U4REjixI/OVdvODpmxlEWGbtNjEdSvukatIoVTOBB++geKZpELRVe6OdzYN/Bs8OmZktDvWfL78NsqVZIBoHJnumuNTgw0NuyNN8qSy/aih/doklZQCIVRRlhAkfvq576a9nRoSNIhR4DQ8lcHQ3DIKuJ1tlDXxMSrMKHzfMI+uPSduIYvtOTSyhqtVDh0T2l/OdOfOTJaqDqOZidVUGTuM4/cOyJPK8xDxAS1q3/epnnhgigQ0KjGHDB6R7tr2cvpkSpuu/yFm8W+sy+jIsztZdNRM2rZnNevbVDSjrnfd3qHfJM+h2EUfiisnIGi/aidTyz70H3HnDOAoOpFU/lDnZUrPw636J+aWVnb+fv8XJ+y0hbtUuLHJoZti8blYPCyxdyAHboLNm0Wj9T3e8zXENb2QgZ9n210PJESj/ZA6UuBpCOVGRGG+vD4UKRW/h5y7O7RtpK2m5xo3lYFRHvg2HnCRS9PUTv88w9dy4a1wtPq/1Ogx550f+uvB3mCq5uQPvuMPaWqKSAra+psB4ZQqjQ7zwES3QRgueoadO3CRSdGNzJ+JmOzJLPnbGBmyE/rmnQE9rI33/Sy/xGKWZYbopcCg8moM2mnl7uDYtAcU9Ba0VcaSeUZpxh2yI0YjqA9XsxymKY3BwqmcziXdS53Ige0i9StDm5mJgo0Y4Gk7CKHjyTA/STnFGiHaNU8U/B9a+rvzQFGICb3KqrWBvgW7fbfsaqPBca6rsECAnM6yuLw1qvpuRAnbqTyJEsrFdPI5e/d+E5PSza3W0LPjJZQ+PYHimRhDBddYr4G5wHJ510Oxx6zpEuTMg+cB6EMoFoX3HoCloYxbMNVeHcMMhUM5rkw6yy6Y3aMeWPeokXC2T8JkGWYibM/mZiXbx8FOZKOuTeL/sQ7l8wapqPW2UF20aOxlGtiQu1p3H34Vh3xKtytJ+8N3FIsbTC7cA5jv99qrLd3w5nE+KcvOMfaWPfD2EIcGdIKLHtrQZnS0RzSg5JU8gvtfo+Bq0LLZoqlKtGvQBCXtQfgtgAksmA5ZzLOV55ngY2TAPW+Msr8jbOidPCBZJPxCCR0WRDXaC3K23FD7LDcJbGlLBtORI+C3OcMwqlBf7EeHJyfIkj+jiqJMnNWOUuRcqbQY2+HbXjQouV3iS0gDsAIoe49eIiHa3sPYMz6s4ahM3Jbdvq2J5cGSHY20JGrEK3C14gdljdbzy1Zemg7viH68d449XpSerhtkvoQpzcmdDOM23JdMcRWNOAceRRPgvuky+y43MdqUOnQgVkNq03+cWTF42aCxH+9gjZ0u2jCLLrkogYokX10Sy65ZJvQN7ki2EVkmKGq1TPQirMFwGVjTkJJFUkt8WygO53/0J3dxx3otTq7Y91JvjZup+bOWethyPI//J6lRYu94WrooKGEf+r4/fEbQG1P4KYLNriRRSaYYfv4FIP9FgWsmy47SfOzPcYswYtiw5L0cJu05Lvel6BsCKyYr092oa1O9T/Bc8yjTjNNEuKEhbpR9sD3WUoFy21vyh3FJCyiFZV3qvN975SuqJZ0ASaH/v8BIHolpLhHSyNwNpOZPDrQCRbA3Q5lJc0O2exuw9F+vRxSNk2gCuUpRWie9IKUIWMDrDL/fXDBuutH/r1Nv13PBw6fcNlruz8zBccPH3fL7zY4plEahtSX/aPJCPoJvEyISz0fFu0oDcXF85sUxnkmdkQEn2ZPnga3oJWDZEKa7+yCU1n2IwTJ7tfUQVwisChfzhidAFryXFM8k0lKx72Ub2Z0gdurd/oQwJHDAupQSpjXPY0FhfbLr0j7ixSUO6ZT3mfao6O8JZAAAA==",
	goldengolem: "data:image/webp;base64,UklGRi4PAABXRUJQVlA4ICIPAAAwOwCdASqQAHAAPnU2lEekoyIhKDcMaJAOiWkA0nexvo94M+Uv4f7ochLrDzI+wz831x/3Hfz8qdQv8m/o/+r38u2foF+7X2Xif5A/BIoAfqH0jdDX1z7Av6+f9Psf+joZEtRJkibsZ3gbn/j84ow7bRoTw3vg1vsC0r+wTgfq26G2ixQUmm4dmQwTp6j/JYuMlXGbPrTfx3n3dBN7EHh5op8sKSX/49pitERxo4/xFunjtH1j/ycXH7PkdJfPu5loVookFWTZhdjuYxNcwarnsrAx2esedUF1WZX9b3Fbml0OhSQeErfe9lEnHlcEcAzgXbgCAVb3x+aQMIuwaweOGPDjHvfASnTOk7yzN15esKQ/JY1Y27aRf2jqWXI4QmZHzTtItxVZ7rj7Fd02ncRmvVK6WAcO5HVnpU/zFHTXYkbIAdit5eKrjFBcTGUB2eGk3GMOwS4fmdnAfTP/hturP675AaKfoF8oZhStaA0M7jXqR62IhGrUSb7lTxObqfzesLgTyPfPHxXFiX9SPoH7AZGzLqs+J8erTz+xsX1l6vN+B5PUKbVigJz4eojoKHxOlOK5tJ0ocfNuo7X3IEjfhSil3amzxIM9LiIBkEXTNRWFoOhaauG9x/1W5DA+wV6gAAD+9+GxmKM/gdIRCd3mytO+oRPgWTv55X7VGl27X9V+16/6uLqbYIz4Nh0BIbfUd6YCj4eER78zuCeHGOWxub/05/X849c6/DkauHI+MzRZ41wWOUwPeBu9dbQRaANOlEtqGv98eaP2OCbg/3S/Sl3yNNzSWj6qM10ClgZgmNE13kyrnWTkhyQRyRSFie1sJEpOLh0TJpTaOga4cp/JJ9p3ATmfJkuoAPhbKMlDK9N3cmr4pbi4stgYw3h6VyMyRZn7jHpDapR/bGy3PW/j+sIrov8mH7ZdfWekxD0Fpc65rK4QFWvsEHysscSvqg90xYbPgi5rj3FjLyQe72HihFd2FBf8FyNGXpQboDlIej+kkJyX6+Jfy5U6hvCoAgA8x3emo9XxRXT+wR9zL9A7LYIvkhbJTAj6qkP+L4/Q4GGTR2iowtN/o5OrpYPRuWRsEbfxpodehZpoRMz6SRlNlzOKmVj8KuFQNSTngxEjSy8Sk0+gkRLurEsxRsm888NlAwhUw68i0Sh2GbIOJkmKAhAHSOL7bhRtMwzQXDOqAFMEBt6UpxmVnLsmNTSW51T1Jc0JDWH+dIaBXwkJtyrvrxyJAJuA4vH5b3m85fR7NTOf9Ofb1Y4VBMfrf48ehhTqQn55yGkq1sUYUez3Dom/26MHRn6H+Qpb7n6T1QN7l4VDKc5iU+9U7/2lZTXopiZZIGZDcSjl6N2mWVUBa8ytyUzbtyEJPr8P33FTUR73AO9zH/4bv2CGNLxcrTiCUtK92IM/UasfELjMjAnJkjsxR9sP9aif4nfgb9IBZzgig2/JQXAKL+7EmOwsD6sKmLoLhqk0aXuDYPpQVyW1+q0k6d8SDPunwy9OFSfx/ZD1G9RwGGwYFTPbFGmM906aankeLSQSOI2aMulaITmxj1U9tO/5ufbG27KL+xLZx+PeI+MBOrQaUjygLXJVaXgRxydZuBF/3BgVOd4QtSf42voJVflY6Wd9/IxDInerI0OWRV1l4XqN+7PfVuQcx0PIQwIBn01ou18VsT5CUXs/QT5FvCmUACpxzj1J45Th3AeRs1/JBfRdC9Qiyfye7yo0SsBMSbbEN9QkyiKbIpRnmFJ1yr3GEhoyCsLfiUnlAAfnflkCCqRdfbfVsyfv2NlKEaMl2NukhBb/KO98LYiVuyk7JuLdWP+euxdbHYila8jpcIjOtbTFH0z4gvXLzp1wMFtb7nIQF2eL4RvdIkJEy1stPGFFrJMHpYTJyUIoLHKQvv//uhB8aFkPJJWyazHPr8q5G4yrx9ah0xUU620KXApB+dSA12gWzo+piYMRLu7KWprMyOChL22v86rN0JAIwudCAyphREOlX1SoOqxpq0dSASUJYloXU+DUf7//0Onk7iSrv/VuJjoTGgKtPDbdehW0aEeF7tX/MFs8MvTv3i1NdZ8GvL5VfGtv8bdMHTmufuGKRmN9AfZ9nBmFkJ/dXvYYPACfLR5Jb7QH3H8PlA0lgucQSD3oBkpcTcdF+y/8gMW+7gT3FFxOfSKMuFoF40ZjBAP+OcFM42FyYfAD9s8Sj7sZ8Y366arGVwp9/JVXh9SeUPfGXpNkZ6WQmmeRpmyL2z1ZahvfqjLbBN5auu5zMA4O1/32emUoavW0KsofLm6xI7A2Oe11G3RhN+9y+e2ir/yBvgvJMk9odjubg3/G057xW0bHow5PVCl7Sj158BDYS+yAnGPZ41vCEK0yOfjzZuw7U/SCkm5xfYattKCqLfc+ZGb34NCA7SOKDH+VoCJg5Rr3Po11BLQfLVKMHMjxxU3AAE/7Q3WyDaPTxzlw39dRYgznG9IOewm8ha08pT5qhgDV1UWzSkQmTvnyjK0edZHYZGrHKClSOvnbFb1rDzWsGJ/Cm9YyDlMsIls5HSc110+86r3M676ej4IZdmVmC6UaKBndN2/rDZDOTUbZ7PpzPTZLbPRaldUoawWHxcYn/JQsryGIHMRMWf1CWzSlTTOrNdaeDyL0x44NcDl5LrfKZyYI3WQ5MPaNtH6EZLVQ5xw6hLQJtAOCPso2RqCA9z+lXs9lyBcPapSTqm1w5i0LfJ9jgGrPJmUX6JgrdM+8RSG0RnWqf4v8FeXQG260EKr6C0V384pLY4BC2fATHxAP7HYkCfvjS5fVfeid7SUbL8viFwm/KvbqD8jskAlOJ5YruM9gz3B8iFp5v5lt3WoXQbR9S1rPSC41IIudcJSTTkMH2OHkU1thWyCnRUZMr9IZwGTAIzYfPBpjd9vb2Ppp0IDf5wAw4VQqB9oeBYF234+pg+VvVtY6/dkbfiq8TfNXuBHcr2kyUQ2SUE7+pwY2yZz74/o5khBdk7bJ+40Yn4mTu6EZyFzmiQCMFiubuaaBGt28Q6ktnTyPnaHd8X9kj7eQWNzp6q7f7zkC/ZBIKK5KG7BhAW7DwhOBjgz9rREVjfyj1BQ/rAfeAzPh6LlIIkUBjdUbRbr1Dn8AOv6ee32k95hNkxutvqPzgZ270Mc2nZgU8C2i1R45P9ADk1p4AeTsk5bJFjIHkZDVkmVPHnBr4Drtyc8818Q3ijygtozLeQHE5D1z/FprcIqQDFlRZgkGwtWwJZ48czc5XAXWSSz7NKJWzCPdrLWdAPVj+YJXXvMNcmeyAL2NP9UoGYN0T4qd8O1Ysg1rwOYRbBijXMzhDau8u80YT9cWffd5ij4KViDnVkwqNn3+vodnwFxuIa+Ue5wfSO5sI3uOEjn+p26c9pQ9egKcjiTLB40rNEX15O12SaGKb/2nMekM3Y2orYnd1nn0pSllMmaxLTPGA0Y5heNWIBkc+A6YWF8BlWcINSBbYBYXmOVL1m3er3ZffXUUQML0I+DGqrZzVkNRuWcNeOMYkkXz8Q8snYKomYzoWb9OZ3LOu1lfh+9lGyoS4zdUS0uQZwR/e1vSGmmwRiPWtdOxaMkG49uZK5AqXho7ZXaeFofJYS/YVFgV50RD1jG4SOaK01EAZBeASlHwDAkD9nrqWloSwRiaadplQSoR28f5ljbMPpNENdQmFyhox8McXLkvYXV6N1cGAskDdo1OxsGC7ppo6UPw+Rduqwz+9Ac7qVZxuJ4OFQ7jZ2VsC22uCc0MaXBw+wNaY3JCLQpDovr6o1P9d+/iY+0wrmZ3YTIQnS4XyoUr1mkBaP0YXw1yX4eZdHQnUdKbpUEZBlaGKw0dOd/84hNpCayGXFjBt7aQD3e9ARHXd8iXtY5w7BR+0mtJbdqOFtjGIqbBlnsBCS88dCoxUXvNAmqnZnDCPHYloPMcBuRHKDgNgx+sjVxI8Nuw3ROgW/tWblDW4A7Efmzr0y2ETaXwzvNPiuuZHNmUASiEMJKwq07v6Wb7Qvp33VHEXM1LO21UuTNZK5+bEMTNNiOfG8zE2k1z1h3lC1HImqWd4a0LVz9ay29uXbiqYeX348uoaxF5IcP67B8sMmAXwJlPdjOs0jFSo30QK7lzvNTZCkpf22hcmO/h9e766G4EEOHfkx+Ksbw886Fuq9Z/ePtyH27TkziMRnPk9ABoAv0KWnf8drsvt8w5lXvZwEgxkMeWnqSEvCAjbdKyITtqTKXsuZhPvP19Pln8Eh4CVIwDiTUOToeXcTlHMwOJwaPaMWiY0eLT3/1YSO8meBGW3jGKzoKTbdNm/iV6KYkMMsZIDdCy7YO60xfLIiCCDWx7z05liFulnUH001NM0yOWaaYcyTP9ymi3qg3mUnLxNLOtJ6iyENlZjbDF1fx9sk7VDSCPk+4sHO2mOhDkNoluTqBCWZctLr1LzIenLIAMBkUYpSX3DTbye6GfDogW7NGM51KN0X2qpExzKmuriEMUjgvP+bsL/tq9Ips53dbZ1yLR2Xc2+5P3IoOrs0ASLpbNpcV0y3kP26lfcTZB7/GG9XAKzi5Jd1GZ6uBqjyl6fNFv0Hyq8WpyxLIoI5ARs/umvvGy6vQ2ZTYLJBhcSQ2C+tYVHCsXgi5/loZyxBlZibIPY35cOwBaEvfGs8l0rEHjlRHjKCYEKsf5SnApBcjcgYRPTXx42gBoj6UijPEGuGRKd0vPioQjUbZyP2E6yEVdWyTr5uewgI2r2tRSzYfVeoKommv2aiVTQHoBYKwpXfpBEZGH7m7AiaAdxot6uQ3+yL9hnhA/WsIQGJcd3qrEgGDoxNUgQEGDIdQOJqqvAR6zeCWpC5hJnglO5FuCXCaDccF0HG+IzM+RAm9i0cYBYcYi4S+ixSM06XmfQVphNiLdYy98SZoLr3+hTg4qxGIXIQziZZ647SlEPRisiSF2xirTiiYWJZr3/k9dQgwcAd6VTthpKgRFSl5qpZ5vcJ2O/ZPZZi1xIyGrifdvfAhok4/YUpkfXNlu2VoXIn1TxQlZKvd9mO5EHEf6x1k8sC8jBs9aR0PYwDc8ae0ctP/ZS/Inb1/+BIrHhqBbhFCo6ehAVur1mx0pKwVt2Ynl40j+lpD24HDk3rolZqO146rmTgnjYfh7+PHM7g38E3LR1Tdw2PUTLnMpWMyl0QCwbyVemtcoXqbTRDAA",
	griffinhowler: "data:image/webp;base64,UklGRvANAABXRUJQVlA4IOQNAADQNwCdASqQAHAAPnUwkkYkoyGhK7ZPMJAOiWkNzIWqDyJiOsf7RfwX8e/zDPWxz9m2od3J51v7DwD4C/tnfGwEbsemt0BPGT+rPS79d+wh+uH/T7JHopBB8+0f+1YCSuf+I3uzkDU94bfmFGSXfHV8JY7NOfqZTxWFypPG+dkwxlhkxk92J9ihzbhotJucX6pQPALUT76TmiQatX/lmulUQEYIVC4tSZXdcWBQXUp1frV9P7IDAQlhOuw/Vu5rJbBeS9Wdn/2GMSMoQlN93oZF8MyWbGC3c5YIOca8AETqb97MWC4QZFJZMrDW7Rwl/9oFVKYFjLEtNWhMcJuGlCgmnCFp+kVFCS9agXVmna3XcX/9c4G8mIG2WL8uEu4BlrkYXG18QS8cfswQildSN9uCof8N9efDIe18y+lDwiuJ7A/czSr/Svk1M4Hra3E6IwkYY2+Z/0wspHjdJ2GQpiWSKClXNyTb+OScA5zHpr/FQeGjTgfEcPkktJRRwsmz40FGHxPXGuDsePjjsmkVznR6QbxVmQuNudw3SoDZepoWUOqa8KDaGYfFXP0LHhVsnzLCxi++xaXuxdQptMZGR+rsaXrGew9XgAD++cDq68jXS5sIVC8zV5OZKS+xa94itqVKEm0sZ2C3I8cLgYmIKxZiKmZPOARM+vPxWCb+6ZaoJbugxd+eZKljHShtiNvtYSb1kP16m2pze/BxeyG9VWSrGsVWcF/la+1vdtIUmmdsSHU9EY1/0wrQ+NznojlBFmbj3jZVh/3Whjoc4OUZ6CaVjYTz1TeibxhtXrowg/GlLHEvMV7QqG0KDRd9VAJxIrwXiNXVnjr4aRJnzWe/b7fV139CRQ7oUWdD3lmQZS2mO03OBHi/l4ugDgV/vlp7hSxxmpyf/r1DQFUoV9hUHD32kJ6yGDbBTXUUPf3blRcb/hGzclqqcXYszLU3pNkyUTbjJ+L99whxlRCRZ8MHzN5M8FYpx7ussXFqOt9nwC/POeo2AuLd8lDB80gH0aId1nWMjp9E2mPBcXK7khdrEGy1dLtbOf73f/dg3ft8fAAnBMZ6DrS7JHmz/5hDZ6/ThJSRAXWJYmVTqK/x36brgvPs97WW1VSDUJnK9AdUsnwuP+3Y9kDz3fwL5OIhoyOUXp3/avF+M47+cW+PcfjJwmPTb1kdWIZFET0Xo+TBuj2zLLpTKoJqrSytGO0WHWRvQQdsYkJagNLzFBrzJ52OcZb515zkDK1R53v/i/9ckb+F1SO4W0+1Go0Ksq6JtBhCMV6PZARds5ar43sKLhMJ3gg1SHtOLlgRabEAPH2+1T5ZhtBP7ouh9EIxB3s0a/5Wn1IREs9v09+9c9z8HzRCkPpb6U8do2Rmj6k9OIQm1lygvp4BeumKnlhag+iX+4EBz5FsllmXxurnBxEksdhSj3alR96a/2l+27MkhY5uroV2DWIkNfI72YMGY4T8DoSHAQQEm5i1nP0UpQGfs4i6fd1UBf8bi1MZov0M/PHlL1t6qbQDrKqSVtcFrnxn3r8abDYLnYBOhFH6dGCxwIZuUv9XO9Wp83zCw7Gp51DPQ4wPHynPvd611e9Xe90ijsQuv2NxNlp/8qKSMPLAY31d+AAeAwPhSKGPlIgyqlFept82MANPMam2PC8eWrrGuyIPtJe8H+Xm8uHSYpiq+SG88VdgZ/vsB25MsZ8HXRuf7XOZQB5qpNofJ5OJ03IX5vHDIN8NNvKfEyVgMUzC9tn/N9DdK9mHxxtxDQ6w0K3G1Q7i/wNUFxPYvWlFM1F9tL5jl/SR4RDbW2YuHmxSsuwNNm9Mnwpi5mOL/gqIv8KaxX/I4I88Shcznue7F4wn/+a20zh8z6+P2mO3JNicMphnQNCGiPU0RFf4cMH54GpBFnjYqlzOMTBbAM3EvgNfLi69+hrpSKt9V2hf4yahynVT72xzwuU2qjfhYKH7WDH85yP/rdPs3z0b5DsjZQMfUp3391W4AtbccNHTGd/cDYw8G2dWAIly8+2921pXT3jKZlg/FoxZaVEctnUyaUVGIcTvL+lATXWN2vonrvOyTiSX+iKpK5fvHjkPNYNsT4tbR2v/AP+UUNWh7/9quvHGhP1NtN1udpcQv6yWIaH20jTsRYJwWjitUbMMdZ/Q7ObFjfAIuizG8nqEm1wdNtmK6E0Js4uIHEmtHwPAHlrqDmvnLrSejOzGHuWdSLoeXTRo04jV/px4hSOUMpwiUfBfkZnrFBsA93QpOxFIqrRI9RS1XdkAgeUp1ctFPZC2jfdHasAi14wYlSa6gx6Uij2yUHaJcaYoqswwT+9o6UA+ZcpB67A+HLdWEEOqPPJNZRcXNsrltZJcIyyVOTPMRB0qsyExYX7iQVa7jDEMhCMMbAHpKpX84cO/yrGSYQUZ4AGtI8DUkn+m/6XBQNZ1A2ooY53VTAbReN5eIG/q33KLlri9n/D3gAIxiaG9Q9IDVN8zE/EJ3vlnWEn911xJlQAheO4RGDWbYX4ZBgfcG1VKdrXCpbAg5uuGbfRZrayQ8olWPZ1on1qtgg3RD+VQAjQe8TvfOlv4xV5LPPdUKAN2xAxoANO9OdrvOB1WU2Zl6XEzcYf3RHC87QWIoDV3by+ugUOmj/mL8Ktmht8TZ2dnkLPR/8YZzrV/PD2obxEXjPTYbgDfn3XrEPn9obLzxkhmLHUS5UPvVrQkP1+mTy/gRuyM3bSAooUmLGlVr2YbJSNkbbMENTgRGkLReNoH222i8+Ew9/kHQ2qqhti9pOXB2XOhfLQxr1q5EFvz6M5QG2T6v3knpGDfTnUe2l6uxfl4MYXQ8bic9JFbfUqFIma0YMtqtQRk1vq/IUCK0aVVSsE0ifmrA8mjVCPRqfUIoBmf14VdWctYfC3LTfDzNzRkcsMRmiChvqjSG7BfSKFThzR05WNa74Ghh7xP/9RzAxhLbG/vqZp26zrppwN63uFpfv4pITtEzoFrawtpqSUnrAwmV+wxC37hXlq18X4W6GM1E4/5W9ITSm4TAH2+1jQkuTt7AmdcnK8uBpA0lWhQxkI5DHMvNtWPSMbKBdmUJoLw8cp7rgZsm0P35WKUB/gFyR3dLIcSNbwiNF5R2IpQrA+tQP5uZAN5+6CooI8EtFYuppZyQy5wRf7xx0rbgjmdqgKVbdcdPxgVFTL/PewfbvH6w81EaDlWG4glq15wRYHMJjZJHC8BF3U13WHRuTmpKv0Ifhw62SGTtfVfZFMUuBjNrGK+AKoT6+hh02MsxDYUNreK9LMwJ2fTIIs5b0nwsY2N2WywhElHCmohho7ulz7DtpP2MzmFa6P92oyci28TuZT1FhZgYcJwzyQE6JPauCdw5j6kY4x37iePGfpaBm3RqYT5djIy++46P2jKLgJA2YRFKRe2KCsrYHBslENJI+9kLm1uMJafZrhXUmNJv+EYwbzcRGiDbjyRJ5LGn0RDIzxrt/eFCN4WWI1yxnORVlnYJdw8GzL50QArVE4qpaerkfT5IuhxbeCyDhXic5jADnxT+Oy+9Cy/EvcgmjxLvhB+hTobSbLiEpcu1BjShOB/gKUN8nKbhC9MwH3D1qO0ssvSCdFfDj4OPIx+z4nJ4k9ykHVj6WZ1e56tm7BTJms/KsHbPYPXTK7XBrzXbu7opCe52uLfiv7UNOKRejAkjxIx46v0BnZw71swuGFRq7I0n6BfPOAXsMVrqQtky29bEUkxfDvGLhx7F9TxewM9bPm3DLmiwDyxbL3l65iAnxGsCf3bBNfLfjQ3MsKeqNM+pE+r0tgFbbFze/E4AVLi5L2vVfeiRXWFZTF0IdMJFbSt8HHgGqxabLp1gO02BF3oOEy8rCQIva4aaldpuxEWMQQmd6d7npcUxgBgKffdhauhLQ6FzTDY8eaV5npIaF7PMJXn14SXYvkD+MzCzmrVtiBPRjqao+4oPzsi2R5gkoy68+ssI9ZluYB4UV4CvEZVjTvSIbxmHPEJ6WeF8uQJpV1L98TzO5PZGCAspRG/xM7WpeNerjQ4rIp+g/+pCEK6PGJt2VGRULa2CuN52sq71Bn604j29sm8ptc1i4ZdD980COBzqVyxjg3MHpY+66iuUE4l2QvzPXgivMm1Aw9qI7PjDsTAng2ZNtSV1xEswrsRy+XlXNUXh2E4qUZC6x7VRqCX+AlMV5C+AXM2p0+CdWFn0gjbUh4k/TVjjA+a4oeUuXBgtavERyWBxTupqV3CwG2uA+LQ1v5N1+HlplwHFgJeHJg0GcrfZ+SOvD0+Pz2YsDPHjmKJahKR0yRWQN1cHlVitOXa86+FLLqTLvJZTeZNSFg6nGtixMjfOuqOqXNCt/MEAS43L62K99jMWk/EnGKN4Rg8HQld/l2uqyinDMmAfugce2Pnv4j6NwOUorfKYQGHfQW6VrjBdrhUlPwJ9yKOgE14/HmMo+I7HHyT2UUy3e6PCt6/TTUzK6EfO0C811LuweVz6Y4hitPApBqeIp4AaH27660fcfKIeClTebceR3rm2JguWfvqskVv4tI/yJlV7JPdMKkuuZPfTCzsXedyIv42h3iqCCcO5vQw5v9EvuKrzNDUMJbNlkBR1RA+P+0UHnxzO8vHyPaVUSBXzddtRMnDdyMsD1R7zb7MG8hTI/dDF2GMB/1M+1JBts20qCXwLzVus4ZJZZLmKmR6Ar7j2rAanBHDbrfQQkGvvu5m/wYGMwUOD/mdbtihFD2DJ4+wvCuQFvcal4BcBYqsIhYhLiyiLfAA",
	griffinyearling: "data:image/webp;base64,UklGRsAQAABXRUJQVlA4ILQQAABQPQCdASqQAHAAPnEskkYkoqGhMdV9sJAOCWlg61x6Fr4LfE/734I+P74r+68LPqr9g/UP6/fw/Wp/Qd8PyO1BfYP+y+2HhrwA/WvzUpq2QF5d9/bQE8YTQm+z/7v2Cv51/d/+n2TvSZ/aBYEwWfw/Mmv6TecSkuEEfWOF6hNpeccf3P5namI0gNLzvBEbkRTbPpXftwd2ZI4PtQhLvBm0enpucZJZ97eljSk/UkXf9xtwJLU+1qEq73R9wF5whBn18qrxaFZjCWbepXnaVTZJMqKS4FpPH8MseDgHKcgH46O7KzWM2oZiW4aTeyK9KIWgdNH5Ewv6BDGfYxeRZQBmxiY7j3aAxbsLmNNahlmCtgKFUgqGq293T9m3WqLsbjMiT2VRLJfJSA2Zap8m5frpY5KRYZPTb7AzVDCLrCY9oq3xmr0y5pqONGg1pyIwrx832Bv2qRXAwUSywuPwBN8pmUhNND9EBojBfBzg6Gei7KSPMcOcHotPh+cBNbuH9Jg2cnEHMnCzHVyNIHMo/BCLByQ9otn2FWfngcy1cOlrZQdL7pvhoWh6kyzmsYEfIY/vu4i1DZhyDqx4o3Zff44tQMzR8dy8hQszhme9lr0l0JKS6g9rUqoscDHN/sA/46ggYT0rHHasaossi5Zd6u99LcAAAP7r31RwTb+IOn1DjsYtIP695YrV5IPa44lX9CCnqh/+jU0X8XjKS5N3e0rvWRzuX+XbFscJ9UrjMvDmkWxLgXHefN/w7LshUIf8E9KutlsJFM5B9vWUN/K6scfFnqnWo+WbJv+5w9FijT3zq1Sh7b91e5/gsP8BlDUmKq8/6pQGZ3PCVB5wZE4wHExszAiDqJweibfNYzRtFhJBqA00IH4QQ5KdgH6uZYfhSfASJyS2eucs8ELkWAITtqBf78qzYyqXKeLxwbYpitSTVC5vRo8Ma0YuhnJ67MVvEf+OigyVH7tZ1Yf64+MIAKx/5EQrH7fw/uQff4OiM7PEiFepkWmjqwDTR3R5ec45w6av/o5oU05lo3KTVqfVN+8lbIyh75Cv6P+nedkdudJo0w1Yu/3lPtWoQyPeGRqexPFoNzTnVMroxAnXSvMtJSaHnQcCEX9YsMLK3uv5fxdLd0JnueWc/D0mKV3W9c+qdW3jXC+B01zSiD+xbrs4ex15kq+PsTX7rm4XGAM/Dtt4K14AARH1VwHWCF60+3Vv69QxB8P4R8GPprptDplJyf6i9JRzW55svsmlfm9/kafKO+/kfdahv/WwoXw6tEwsaHI4ZQOjScg1KGPtzVe+mUF4qprAiLtye2sOqk4bexgtEjT8udspgB+mPFC5EJ3PIZau7806DIz5Q2W3el5rhmQAPxcgUottdMsbs7Rg4LSVXBuxE9sevrJXclFH8yRZ+EqcqpAuUDl1TRTGeBn11a2oFEAQobEqnCB1fLQC8SOjKTgd6kBOU5dtm89sThAFOWZqnrdrvbhGu0EuicbL2UIMdXSO2R3ou9oRtwNLNU8mrbvN4UYVE7+p4Wx8LJaZ3eGCeQqNrNrGtEeFGg7iKGpY4SZFROu4F1e9rPUEG+irEYOIxfm2iX7/i4sBvpMUR3hBcUD/e/m+3EEGMaKmBQ5WDuX7NrFbK62ZDi+6qpsjifO8a6o1IDYfz08oYaL6/4SvbjSJe/KdlbLz8d+muUUItRt2TXzl+188S5RlBitdgQFcA9pSKwFsJbhRpTpccDX3PmdHthn55fvq41CAvKjHR1/hgKIe3bL5rP7CZZGp9f+LcJW+bGJ/mX/jrhUP5ZvQeor/7ac0FsYgnRFUy8E0hMuZQNhRxt07ZNuBVqUdidF/IFxy1v1+iTmoD1BcdBQIunCkS08lDahFIHL1gBikRRTIPxwlhvsPcmM/ul0TwZ72UfvZzc5mijyYyV/Qn1tQv5L7VNymPTXY1BK2yCIjMWtXtVVUEX5MUD24oS8s5dcsfVbetNflFwKqL6B2x/gbTjvUGaqJslDst1jiOt8ui1etsS1mi3uZKugF2wPLuw4BXiDJ9Sd4QXIayEEirtw8u2zwZzhYuaiHIrs2uFcfV1AmpehncNi9qosngQlKbWsWf1kzKo/letTP+iv5ftfS1u9SotQ0uqZZ4ePSnQAuNDwoTo6EgpmJGvEAJtAh6aATu1WjPNA2mkD2rAXLz9q6NM/3JCaVTz1C8VRt/Cbd1MZqK5Sb9wTrBUoDosq5miAsDD2UL84LUsXbgdYgdTEvujE+MAzzgRNCQGjGf2WKrSmcjGRSXhk2pf09l5WiYuSy3vmqlGUu1SHx3wSGURg4t4pWqvvt5MDsgOcB3YhVHQvDOZJxybu+qCZAIA74grKOgLvvZT/dFHaHG4a5p5sSDnc2/f3x/rQPF79nM4tj9fXGfQR8pisQDTOcQCtv48ZvXW57lQx2n35QUq0xEpkRBJLO1JnUI6lN9Qx0oaOMByeP8tra6PedrZ1PGKjBWdSLTr4Uwoal1cUShDPARBLKz1lV+l6jHoTbbKdLQQ/8S4VpOJcoGNDbAqC5WXxxEj4t9Q5ZEbHQPBVQ4G+N52v3ewWk2DB+cN1GhnU6EqmN/nFUSEBalfI52u32t150eteB4QVxMIzQ4S8/a6l71GP5ogK5GPKcUm6AtEhNRsy+9L8zFkyW3bDgGVjwqU6tc60cR3P+3nEyaCwo71b4CIj7jP8l4W2mw6wH7ObEKx8YxzWBiuon67LqjtPHHu7D6U3F7bnyJWQbgbf4fAJvzP+QIbPYTVej2KfZDQsz/Jsc09SXdaA9y8tZdMTlNRFRk3tzhNFEKtH/cZLgoIbNYeXaRTP/qX4Ccd1IhXdAcS7qrrV3SvWuP2KaZaW1tyVE2WJk4rCH23N9KicsFjneqq2bVyb+8ZksEwvKW5ySNG66C9yB8t7NMi8S9YGcewLYnc2gwRX82KeJUeQTbM+fqTrWwJr+qfa/h1efe+qiPCgvW+4OvpbLPpT23/3qe7UbVZnG+sBryE3WZFsZ6+nNrQnB9l02xFlkPHOgzpIJ8hvMk4U5DbXzy2w4q4LX+OUGYBlLA8nlMjcbLNCCDdLDLfeBdctCfGEwOP7u/A4mjs9Hvkrau6QIetZZ76Zc6o8TvCUiR/xfTf4o6eGPBcY5eNq5HzWPvS88F0/hUfcstLMP9r5gLDTOQHOXXZAF3pImrLxxXvBVICi6JH/9NVpnEA8l7briypg5SLh64sjHnB2NJYZoirt+Ckh/o3LQOKMyYr9DCJHAQ2ljD9iJbdiObwGeu+J7L8raTSo5FVkbbGzOGwIOeargjctlNaWGv31z03ZyHrbzgw7Ao5UP8hgdL+YRXhLqXAHLM0jHbzl4theoerM2B2Jp1NUWT/NhkIlNb9jCZ8Co5rZYjLUmxN0wu+IMv8iIgj0cp3UK9WflEq4QPU4sz+0d3dZNbNZWvBhGTQecu2Fh1LH40bssM44YIm3TUmxrkNrO5HrPYPr9pXSYDM8o2jmkhbg+uvASEE2xZa0lcO1w8+zOkfobun2zO/kW09Ub8svzI88xolkkZCz3F8lBK+zYDl4ER3D8OXVkck3cxQvgqhl3Gnrhks1/IxVPaCLd4IKzd9be4pfAmPL+uqpEI3vTfP3rHnRmu48YVx0xsoc1d+T4kQIFNILyNmCSQofeyb08K6KJTGheqoTzH/KNjP9rUuHJ67OrPm4cB9xz8kAcLYRnwS7HV64H1aOCsKWUgr6P3qoWxAVo7Kh9EW2921BdvjSR5OZ+82/bIHAIofqacaVl88IEG/hx3PZUhE+igLKeN2wuFh4RqB0oYP/uXh4OVC9I2oGv0sLRnpGeHDAIG+ro7BFjjGOkSYoubxTO/1pQZ6EKX7spEHMIyELjXXOjmT2tq/n3OadQyHqtcEX1T7F3sUS99oCgKVpc/akAxb1ad7PSHrJhIJUbWylFN1l8imkQGRoxRXSsiu8IUr+ek0nP15evi1fazsiAgod6Dp8q4+4xR3fWd8nAZKhJkc6RjXyX0jN2XXJQ6H+HCPipo8oovUUw0prWnoHGfT5kPP9xpkdt1a0CheaFXGSt6LynTPP+/IXZn9AnpN2niRXAM0TvStfiIZbakN+yP1BED+hTZoX0dmS1G5bgHgoV6Ph3rwpRaguWjVxWh3tgI/obO1opgZTl6B3wHCjgvpLUg/wYDCSc7EEar88PQ+YV0XirecokD8gPSQCMtl8J4q+KEpYPMc3zXF3lWrSD95fE1Uj0/SdcWgrSVIh3qOLq9KEm8pW8PBiW0aCW1pYZiQ+UP+bF1UuKcwdTAcn9/fGsQaY/aJJcg9Vl7taObEzp7LYFjJZA+wjvAhEO9js+xjfRJvI0H04XiyB/q/2Mo9wJOyMDEXJ3obyY7DXBQb1ucSF7s7ttq/q/Q6fzlXVXL/9sMJnWFmBSTKYOaFqPV9cr9K/LG9snvt/g3t9xGN5377mQMuvL1Aem9edPFJiiLSgHfaDGOVuKOqmNBnVyXbXvIbuDM7oaFqg9trL/bs+OO4NyftCr9vxm1F0ns/HHiwvBcBSyCNcqnHEAg36f4hPijzuH7ZDW1LNZkwETRPhHJRb17ULJHohkLGb/hiEXMGKQ3l7JkQfQ96HwEvIwWLOtBthaxpakzpAYScVTmym5rRP8WbopfEUwxWl8Noasfa/nbX03vPSvn4jFoP2J7r4rmXmhB4xmZSod2p8gWaQp6Mp5+SU8psxEJnbIvChVVVcOiXrHjztJgqnQzI5DX/uJIr6WtrpOHc7U9VTWSh2ABeK+v3K1Ck962BVCbDA0xMHPdFaPIh452Xje8xHk/C9I+hd0D0LyDErf08mzzEcWrVg/o2YUOleNX5Q7lRhDmwN5VYRTNFe/Jc+VJN8rmwkeCvu4G7SRpBy9bAlArsmARueNGmtB8D0Piv7mmPYoiMuhlISxVkZ+kFAAG5DiUruQ6NQjApKOvkreiQMY+wVxypi7YOzcHRU/OJOCPU4PWfVdlr0KPk5HVKpdr2UyR09Bo1bSs4qJzpxOzl/Qk89YOE5/VFR6h0xA9rH3JP/Y3Ddc2+XZ/YWJAGSy1tEUPKXToiAkMxC0q1oQF7akMVU9s0+vAzPPv6lNZupGEO/gzj8EfGY3McXrguW4vOdT9QJ99KtAEH97sZsWa27xvV/1fM+TH58Hz39r0TO8/+JB4uDnCFlFVT9qNNO1cru7JQ7IaF7XE28AUL0KppVW6YwoJApv+eFL17Nv/65k6Llmxq7C5guPIoVccqDqW7UaUENjW5BpsiX9ZkUAaBX3F2q2+F6OqIhDqFGVZHXHeN4gfMaxmVjoyF97m936KgYZJbKtxiFeReWo/QCWiuwAiwm7H/gKqFuU5s9uncwefEKE6tFK7hTNBzNsOFwZhw/SJAhXPkUk0ztyqvZh067rJe/vCHHd+oTPMTJ/wxt533CmIjkUJXWoM9ANedMCDzJVhMKwF0b6cWnNa6eRhc/3Fu4BbKYANukZ0BdTdqD8rWWFtWDWxMvswQ9HcVBE8iwFW2bTC88O6O/qBZS6DjhirEMl1ayBOLpOgqvFcpOxacLLsgrCI1Iw2puiz6TuIiVGyDKxXI6KVqtW1qdG5umzRk0NjKiMym2B+uk+G2ozSp+rtac+WP8ejXIrALQgCMgy4MyOZ92AGp5jj//LRAG1dLqLa2S7mbUh3au8U4UW69+psKKJi0iOvBw7l9BHCf06AAAA",
	honorgriffin: "data:image/webp;base64,UklGRr4PAABXRUJQVlA4ILIPAACQPACdASqQAHAAPnUwk0ekoqGhKzUceJAOiWkA0JwSKzht8f378cvMnxt/J8/TBn1v6h3ennf/oe+P5oagTte0Rvv/yvNrTJTw/+95XfsD2DP1964HpFA4MKkZCt5k6ftdF5pfb4Jruynz9qie/9MNYFhG/p1Nc8RidfN9IcuglfaOin7BIpuLZDgdCxz48EJ6eoL3XnhG27/5Dq/t22V8eKwhfiV14v5IQsJllJWJAYjXTfor9SVG2kE968matWlHjyJnUUvmcSg/PdfiXvEqjJ3Ny/eBqppKllp+Nj7hyGg7tPJBU6b7Ay4nxefOjDi8tIgABqXZ0h7hm0FTBTFRR2N/Q6GuhIP+tu/D8pNM4pweYK/v1UHDFFkb4BmG5qaGU3y2J1jC92i+Mvtc14dYzbgpbQBtKjCTbuxsUbw/NhW9dSpdk3GxkKbx8I3DvnmEXNEAfCeODsS7OylJHzUbYuKEGIUdNUZ8vgAryiuYpIjguEhkUm2xLOxloCXSwQKC5FzmiNeHQb5sxACYRZOj4WiiS6iLb/gEEtO4DK4WVpCRqPp/Oqpo8N4q51C4Zf7YwVecA0OFyMl53yJ80sCJOyT3ydGinhbQ9SKslwCWlZ6tae7yWTomwhn9QxrSUQO19KAaX6CNCpQEPIsgAP0DK/hBvzPkKwLz4fcqB+QVbdCfTPnf/lf3Uc1agdxbr75Bb8WzfFVnQ0HscJLvBydnVUcf/wzdVh/+ay2jiK6aUKJ5r6aun/6I+CvsQvZs8EeP34JvTg81GiiMldnF6du/8X0Hcit1g46PS2E5jbpL3hO/Hf3v7S9XEPbOl+ITIJ+8DG35Vg9OkjLvFQr0ENiziohymwciddcjL42EdX2nPFDwH/pGeFWQsg9bbjNxlh1x5YBQnm7fhc05VKpcpIpsRyB1NkBpCmt/pyknLXNjJaN9X2I4i/wnI4rn2teooRL1zvQnK0cj+oZtsGlBclT1oO/sDg7zUlgujv/Q7tpuplNdr6H2xy7wsNmjBWW1rtaWwV1uA/jfEbNsGHmzdJH8WmIeEbwfEZKgOTGzoBbije8vtdssoaDfF9nzkHu6kxykqbbQea9DSxVHDBq0sqQvJDZ6sJXghuMJs3ApIytDMOnQvhEHodXkpGmX48xG1GDCruuA6CBZSGO6P55hHTMTaRbS1b+TLMEdBnmBdR8kWI1Rz1KXl1yoAVpWkS8ctWpKkYq9NdooKfmrkPuvizc59jDRYT/9AM9M6NvBEHOO5mMByCAOXUFEeMOGRyQ0ZvIa9MRsn2hBBI2N/cjb3DE9sflEM4nGWFRNMf7JIX0p8nkEE1v/qG5EBxqvNHVqVlDsRJQmlbSmP7WaOC4pakKfjIrx3qL/yEUr2t8qW3mqrsRnn0t+44bSSqPLfVpDIxGHbiuTaGY7zsZjcACZ+rm6hqHClbwM+PV3mZWCD6l47naEM5UwWQat2rqJ3Ze8ZLc+kMa0qN4SQY/4v+6WNfcDo2G1W/80rPXNviz4jspjJAagfRzV0MfJzewnBAq8Hsvf1nVlexO2CG/hHPYejrwyMtcjTphMctgqdaLDsJJCz5K4W3q2sXFeeVoGNIoQBJxNe8gEj78/w7l0Om+h94OczoPUDWrkWTTLBxjuVGYPP8yVT5x9eGdk8REl26sSvXAAA0w+37kuSuUPX+LLQpk/0x7wTrgLsJhWCPbC1RH/1iV/Lk8EgbD3CYe4M5FbtKeTooYIvSXUV0rvWmS4m/z5o1rZGPZRhYxtYrG+7EaEug9SNKf/V57ki7/Ww0QUdJr7lagN6jzsLgBVP5jaiKQ5OVTznSAr8lUjJvlKE51vRJ82cyq7A17kn471I069dYAlfIPcI8BrrJBwbWN3KtMyltCcZUXQ/EvAralKEyJhv7yAurI9jG0arktGdECearfzWcDlbDyViahyzlS3KsGzPigShqKAd6IM8kzwwwrqvB1FqyfvtnL/MjkMO8HlfAIfgtsDbHWysqHZv/FRkYO8RksE5MA+k0ufPcZvucCJuD71jvbpud2b0JVTFd19FBCLCLH1w/dLdLZfpEjGFGeo2/XQWWoJsNmZSXh7xBBLGdzfqEj1qE1tTjdRnx3tIo5au5SZCkTREk/tphxcOx5/YpXLQoZze5GAAfSVj+z3eKA0SGV/9UPP0nb3M77fzGRW3uYnnRsK7PvRfjMHjw7uA19SfDVGIehemX6Ngn8pl/gsgdbAzxEQv23nc0lsSbZ5XcsKLEzV3aNRkvMPii6/hcuF81jvB/a802RYUg7Qsn7KP7C9fzzWwkEA5ngzM6YdD5Wev5Q/5++/zT0HdFvckEcRRAhyZnWTVhFjNTcSM2UCIwMImzL7eaGaRqvh2YoUbFiSP7lAqOJq5/Fa16xCo/2DMh2a/NsTwZTdjsAvxvzwZ4N+FYqI2WHg2QwvkLxV3ZKVTEA548nuDS0Ik4kHvfpbJ+j6I6mTZ6VTjK5TmpVkI3la1HfKX8svwv9w5J388Hd421ItX8mC3r84h9YDiO+oAQ3IF7jMDvgSITsXGCV+XbpNfnX1ztcwY+U8G6OmQDw4J2pWq8ojLhSQjBCzkx9JYrEeOuNVs4Pn3YKrmFmAskwgXmzhpXc6JX4W1kad3P/McDDOP/0ktEt6BhDu8K5RTRqODxVfsE5CrJ/go/B4pzOh+dF7QMnA5NEwce+4cPeDm8E6VyT7MLUCvGl+STXjJ91SakI3z10wWrA3icJ0xdOp9fRA2u4cRuf7i35fcHpvoeN7Sgc6+f0PO+vee0BLGluNIk17AWjVv8KJYCGIMHKw7iPsYlNoT1RYPbK76GXlt/UeKv/IR1BvIw4i5prKV0DJ7L/bif8NfDX5CbkDGrjHixR0gek8o08XZ+vyo+nzmJzRe8C4r3LXutJf2YqbS1MoaNea2OvnzklIuq942MyLl98y+SFzCmPhx+Vh2jJfBY1N7qL/kG6EhYN09pi15SUGGSbDJ3NNShywAgR20b8SE9S/nNbfvMmO4U/XHL3V5QdfAEyGJIjzoGh1fZZ3w545VGfNIfxvWToxSAWgLfEMOUdDKktuZxmjHUQbGk7sOHlQyhybYSbWDrK6y3adBkMq3c4UKsdAYjIxXcQj6ZNIQUdtnqDIgiB+pa40Ty46vdxI/rOC6LWC6KkJ0o4fqRmWxnchKx0fQgYwtkVfRpVyTwLSAeyqfR9M6f5VeXBvx2zHO2ULhwa+8i0fY6OPVviTFd6+FZHPac5i+o1SjP2xAsyoorwyfCge+s/pF/+TLUp2L/d70YOy+iXjLA5DxNob60wdw3a2fGPyjceENdBELCW5VqMLh2vwh0eaKFwPU8NA9/nAvrMZEpLlXv4KGZ4QQFpB3DVYEwb8DX8vqpJDdFfzblX4aMwcxbBX31IyDofBshtR3sux0G8TbmDedUCFooCppQDLT1ZvLcqPVWvVABDoHQ+hJeK11r0Dl6tiaLVyk6RIRJlDDmrsOMI7ezasKwtreF96J2fyT3XTooXn4Dq/V4DQnk53IV8NgDB2R9ZlBdOHtAewyygarwOMFX25ogE7wbSX2mwgjkjZayfikQP5jr3JJpsny9lP0E4+uHvCTLqV2cfYfArS6ogTpH71V4Ek1jd4Er3BFTO21JBtMQPUaYNmXHIDQWrDyfw+rjW6UZ6MLtbZ+jpRD6SzFHb2BMRNRZ5MmHdHJNE9gArugogNooTA9UIdxLIDQU0wpgnguMssGKjG5iWwZUaJ7ZXC3ZW3/Go2Z43zyhuqalA5m9kz8yZnmJG9UD5QT5kItVdjEccZ8/huCTUf+jZgur6w3HX0SzzRilT8BtFbCXMG7h4ohhks0DAUXALJ8YWX2U+l9zhyAyptl1s7//WDU+h6OHQ4e3C261Kd+4JhVjhq6P5f1L71ZMDQZ8IfcWwmBGSTlSuAHnQq5Z8wZxNVzWLoop6jQRTJru89ntLqeSnUYboaZV2DdqnHB7GMojuMejWiicu0nNzCdzIRbJuDQxwv5f3iwnvTw8lkK/GYr+i5w3N6fQEQRdxkoAVVOoOLxzmzg1I1Jiv0ipOMn2A1mxVQLHeVvbaRgfKpfa0m/D3wNmhLn+e+ah7NgXMSCMSHaDRH877rlSYPu7GbfavEXxVmFS4g2vrGWEoQ/B9VRXfrvXN2Bvsk43CKPbZywfF9PaZqIAuavFz+9K4aNWTEejNqOmwZmdFxqHIbEMwMPKZE0FzTVIqCXKY9AWwPMGS2puMy1DMI3gI3/Wsh+MpMRFiYwndsW+bEq54mrt69pGDqrEWSng+K11Eh0C82+4daclXVDYRYqz/PuDWO13gCD9HPJ7/GsmOits2qVC3uf81teNhf5vIESSw4xVCx4EF79fwZa8IyOtNJ/R4rCWEGs0sAZCtrOIT9j9bD55Ul4YwP0Y+vUK8F6wk8NrZbrJnMJqu61GFjWsRrsHHVoC/AF7y6vKXZVfSwBDos8jAhRi1BMJ4mp/e7TOsrkML8J1hsf6IUuEhkttZSvLakqcozfIZTcaCb7+ViAu2GNjTTkOwc10nQzBs7c1N/Zwp+00SosalcWWYGidHlroFoGmSydyzuCkRbfoldC0+5yM/Z68QITc1WW3kONxzbQra5I3BpEEKRzLVDsqn+Ho5LR8cbvxQLMlh7/BNEcAiUUVxRgwqAjQxmsH/flbAwuLXvnKF2eHKrSz8tDV0IFctDv7Opob6mNSLK5YpbVP7q2FJumVHDGLcQkyKwnNmXKOJJuLZ9KEk41RWMYeZ29dadQpAEhWVjlMmedrDPiP8jPiy5j/daYHCUBTk1CUiFAipI5N5eJI08fbNnqQrtm/prZkiNFrDcLN+9tSFH8zLF+dLuiil76o/Uy1K4EiZ96LsgBA01LGJkgIn6hhUgWUcxwCqBo52I5uD+TXaZlLxd3yxypmJwlZeTJbrdjoT3pBg4RbuGV5SyonWzK2WkXlhZYU6iShy1B3BJ0HgI8sulJHjqDRJmhRRqN73ZlkODuEFVex3Ru71XHUR/yCqDkXQ/PVMrfs5iXhzJhdsrQ/j5RDtbElD8wHeX5la1jS2tObHd7ZVBo+QFN3+EMM5X0ZKByXzcdcQ1wSojADp6AnZZEYHmIy7ILgygklJGBCRVRv54H1W41sQC2SYha/UX3L48Bu58NtcypzpdOIbaJgEuTd4iZTydLXrHzMT0wBXCsu7fYbbotz7IyeZgnhC5VrC00w5a8xVgrzS5qGkb+5RiSbr4EzJvyWQoVuf/WVx8ugyar2XbHB25fkaOqE2B5r3JsQeUyR5TzZL57ByBnI+09CMn2+p59mchwFf3FclYoeA6hUsDL6GXMzHp7BaAX8hkw3SNfxGz33Y8FQ7qylaUwAAA",
	koboldelite: "data:image/webp;base64,UklGRnYQAABXRUJQVlA4IGoQAABQPQCdASqQAHAAPnUskUYkoqGhMNk8iJAOiWkA0jx62Wf3b/kPBXx4e6NCHFf2AaiPd3++86O+/5ZahfsjeZ7aegd318EvVZyAv1o9Q/AQoCeLZoL+u/YL/X3rl+jR+1xfS19enR/4Ws6m46ZW4p/Nfq4+QUBUPhc41pkJ0T47QTW9wJaBySJRBT9uDDoXCq03bmVZ+vzq+4ieiffkcLt95xGuaf0tTg51JkbzQH254AoBoWsdmRSQDS0xjiZOCEWYM5TsOUcSCWeVYdRrD+b1Z3MWccupaHGyMA6r4iOO8LAwwLWdN4TEdAbDXIERuebuA/yefbwh4JjgXX7zxcDzKVzGGPYsmHPACRiLOf2BWPS0wETPVvi+SNEaqcY0+OSb0b9sgWWPGPqNCI87WQWgNbtT57rSHleWSNVX6xGAviv0xryrIb5zXpBcglfFRVRGt4FGw0m9wvUzmeMDRbxJsVxrILaN0imMRFGAfLh406kGhkNBb6KotMV+MntoUHYPRPct1v4RavGsunKDHiErH9Yv74o1JWz0eU7lI+s+BMcQH3cDnpDNbBH2SuuBWiaSyaAZJ+Z9HM/oPDOhr3y8Rk24WNiif4uWgClHQ4/IDWXQOZh/Db21ONN2eSPB269LCtUP3JSG3kU6Ccm7xl+4fLYAAP7pneeYWPoSney9A0tc/+HO8as7e1lohvFnmr818n7/uxUwGYuDVkfPNGRxm08+04sZcWThgv04ZN4s3R+tc/zijnof4bZ8WBUH8h/e8ao/asonlCKjMCRWL5Xxv1MQw2NTMyKiAk6ln6yd39R9o072mlYuWxuIpmbSJGFASkkn4vXEG/E1Y5rFUcl5sb0O7bpRhQe0nlLe4Kk6dA1CjbwWWSCtW9YTNUed2qTKL18blR6q9MKRpFUEfoyUZ2+nxElM2/iaoCGonshgEo0sNUkA9hxxpWihgRHdTANDAJezc5ElOzRg/a37CI3Gd0nZPkgspUnWfyCZ5rxFmuNwvxJYt6urObmfI9VDmRytcefiXrHXzZxti3q/BZVZEUiKDKN7/md+D1QhHkD8/C6+nAzi6X3YIQJ4v6z5eZCvV1wnrkp/73K3eVxy0rHLIn+cbBTUIaBa+T9kddG4CrIsZizEx0oS9qLMBDhPHeQne3cJ/8RAJhzoILo+R7pvdT2mjAg9RwgTG7rf4kSbNskCdov5CiTgNGchRnGkB7vFdYYRgUItnPp6usXgoO73qTXf1XMqqgJ5SoKrQcO9G9HR7EBdduY8ww6T/o2hvoachpclx8V3CAS9zYBvj6PnmvqCzLuRAHEqrCBML4g9aQmtCYmY+4XqdHI617+5cZ+hTINm0wRtCJQ+cHuwNT8ICS39efFHI2q85FwK5Uy3kQPLJHrCRiBdO7f0aLrvlHQc7a9HVcy+cQhH1+xk+odXoLaQGcpP0m7oEzP99iDdGOfilwVZeBvhTgWM/prOwnZ28YtP9Mg/oKGzT/yzuZ/tbu6acEnr3jdGPe/J9YEsFdX9JLMZ52wsC+Lcc21+WMNVNjg8sdLXbx9pT+ZsIFsJCzvXldw7n5ZfmjA9gmaL0bfWHNtMxk4Wi9F/sdZ0ynRfEqLcuP69CnfTleF9p/v+1T9L5HoWH71lLXTk01Myvborb3Z7udcQSLQDmR3ex6F6s38x9+7Y7oAFuNLKmg8L0Iu45SCBZKmCg5Bjpitl0z5t5s1R4vz0+29vKASJuQI6Qsf10bxBOfAm9TnSQ/OoFZiFcq+Fizr74R2detAJTLk7OWT7SRD8yvLaSc2s2DiAO2z1pNsvYAGTQfwBsxnfKYR6DoCXQMd6YWGzg+QBIL5WONDmtBru+bypSsemA60Q3wZcXBakzHQQpRzU1R9S9x2pBO0q25q60r02aHnkXa8sS4BcJvpyNTVymL+dadvNeu8PSOqOlq5ilY/5SMeV3WpqQKGFb5dlIz2YpbZsaz/2v1U2HIPkleQYcK2yUon7JIn/lQlG7xCa41RXdXfDukwmeLLclYZf53olnmhr6HZjsfl17yc/e5Dy3Mt0v7cugd4guvIcGdkN4zTuPxW+bCUaOFOpJIbNxPt6HprxUs/RhiciossjkvrqRx/NhRIlT3GivCukQmROXTvaoZT5parYIFj65SpV9I56AVaTJ4GV1lD4yPtR3foU3S2lwsdMHILtQEnYGuO1vs6r12FtX3ElR4L3DAI+AJYk77oziaW4hkEaaVLOTijZJYTjz99oT4OwX21UFc0Ir+MH3YABmhYagyUKcy0lX3+r1lL9NHLJM+pj/APLoXy8v1SkT53iZpVgo4Aj0i7KwyUViC9uCdpVv0NxD7gtAl3YHGXohZkbi39vfBrLSEGOsTetR94EEpGn5s2Ahpx3h/cyQ/HDc8LPTkr+BkO2a6MHt8ug4SH4E0PEuKPYE2xp2PVS9avDOns1QWGD0C/VNtmC6a0lurN7Ha0KcirWnASU8F8fxeKz9UN1q/u1XLzJT3Puncz/0gjQP6sADg8y+PABiwfn0gowm9T9sbmyJjIAcI2D8OfJHTKX3GtVf9UyB3zwtpBGaPbtWWEaXp+l/oOv69CUwPZc9xjYuqAWTBtgdW+dfdJHCSwRMTbMbRSAn6hZU5lrfGFdICs5bi7pJ/YAOlN8YY+TGzzQTAC2wBGKuKt5yqzk5Gbu8Y8rdbTTexQQd0EYv0+L/Tzusk8fpUyHKkVRQ2oN7yr3gJDXMZlzy7W1GYgoUO7YoLZaNmb8maQb1k5xc3GVK70q5zG5tq6isUQtrdyWMAiX6RmVMFprBdCbvp9zCEs+2YoKgLc1DhnjvIna9BB4n9NXwprt0Yps34E7IEP4JZcvzlM9ZFhroMpG2QCKA3eYvbFwDyskJfYnbEgNk1LzO0vyOJVbMErB+oiuPFXFVzrNUBUnnLhjAgL0MFHyU0zvy4c30V79k+M2e3SO/Fua2ykOOB/eGZAlMMtrtc2bijsUf2KtguztZjcIaYjN7wsMhdlELNsaHNf62+ka7pOP7HRUAw41rXiTSjibAJ4IyB2eLO2PIRi2LZqIvEf7Wj7/aqND6IbqtGnbpFrv8T+xB5ir/UFcmVsZf5QgrpPuojpbnCRIfk3TidLCTBbHAotFyzo9BYDrIBUBIzIWFT1XcvKjAEuc7fqE+eK4zXQIQGmZbg4RZ9LT7MmCO6G9UMoNdL21ee4lXnV3FgX7NmN9nhC8Y/zGGiUlOU5A5IBiQHyM1wi7itMOUVN+B4kpMuw0QCQMM/NKjuLADmHMctpc1E4xrtlZ+CF6poePhX9Gs4grGCvYFrSTXGi8cOigHmnO0glaaIdgXBW+x+hmnHyVaxvKEe3h2QnAj03Y5O/P5bgkLxEzyieLVZxxj0+D+tRKN6AOnH2x555092MWkBP2Luu6P5+kzAQkehIWgIB5dfVjeJqL43YkJq+l/8kk3VZYoqRZZz/mADCWVg10JhmtWfvXgewlFz9UWGAwQcCaBhQYIizD3Qp6ZLl08MDrV0vjrhvuGGU+K7L3Z8TrRX7tEi7Xim9l3rTo84+RReoJaR64ZdPpEVpsuXpJk0G7bl/+xofL0QN6uO1anYinMojoAx/6F7liNT0N4817olypZGgPIVe1+WF8SV1hLA7I+IT8Y9FlS7ER3rC7CzbtBbASpAzwW6ccCgwSKXHPkMwayVwN6WJeYsyo0DBbV0g98yZsPAjkXQFMpDUIvDCBN/SAHLJqBcsDKiEoYUHA9zOAZT4oxpi+tdThVYDNUbOg7x8FNAAnkK+K1/xO+03dxkfLLMmllLcDfiAs3AxMnychZEL0tSfBU1VgkfJhftll9JyDllY/3UCN0Tn/cXgvwWanVCOV4Ycr8d32T2MnQ5g7Nc79zeTH1NLerru4XuLwFUXUE0yTO6XRe4uEoMj1GArmr6UtdSBFQbVlXW4Hy0CjW4RhJnzAd3njUEtXck5rnASpQYA+e12IzcypYJ5dDoQrSKlWJ3iT/pR9s5XzICFJTSDxitwkARToFC1ZTntc4ORruzsi30DTV6fVU/i2Qphf4bbK2EGSN5uqCRqLjYZSSaGAyQvx2EM+/u6hE9wTRo2gmVXqlrYDZX06va7GR3H4Unjx5Vi3YtXkV27QXpOmiL7zpb9eEjeyv6UgsQ4glJu0ij5Wia5p0TYQFrCU8IzLPfB+PzbJyyxU9Ob5iEbXAu8yLPR96TrtHAgeTmgqT6OigHHZnoh32muxMzYM624v0ckozUjWGAPe0EmWWjB2Ewlelk9OJnTDYdE3FWUWLIzF2SBBq+VlU90yBO3jJQUiz1+6vwIdD6TJlEfCf6PmmogSLtXvf1Bu+6+KYCZOE1oRlDPddil7uU8Kd6rXiGKCfUDqgaVUjWM35S/QoL7FMEW+b7uq1bPDMgxMiDrAovKG9KN84VDbBbA0R2qRMeJFwYTwxFfi9DLL5GvHyefLNcdAEAGakD8MiJrKV+zUd1HSzbnjcpoNe7EApT9q93dGTP0GoaxRyYCW9ttwMITznrHOuzuqNsK7o7AouqqmbWP1Rf+OXF/nrkad4ULkdf/0ZXho95AUmhGFmevr9KZbzkoDPrH+22z537r89Yv05IgvmwkygmOaBK/jWC5bLrrnhS+IZlHwFHdAziLWP/SpB/en1ISX/87o3OGjjZx9BZ7YAg+R6RIloowRF4RVGeb1pCVqX7hmEdgPWsOiUr2pp4G++DaaE4VQFGDxl5CKLG8k2V92LYjWByZs10Q8HXmydqXPpgKblMBOiXXkZhtNYA77596NlH31jMdU9Go7E5aPz1VIAmMUYYt2lCyODKks2EgN29Gyn7Y0YEx8brXMITl2IiGc94fQsuKSdgqv8D7/LiwLK8pnEJnRBaG7DZjtFBbNfsG9dKiwPMCrrHe8ZJ7DbpQgT/dDT3r+SOvkRfLJnVtpv6PyuJBV/DpG2oMCypgB+cfdiCq+eKtSD/3QkhN4rIsjKyonb3Y6GiKIMoVeISVAiz1CLVKHqX03omqm/JS+BQ/82F2qivLTLkg+j5k6XlhMam/aLotRlDu/KTRdy1zfOsDoDxLDalbwiFJFLq3hK8qn4hwcrl8LlPTac9l3d+5jKaWhajaZUBRyUJ2lh1CXeZClZXRdDv8JXkT3m+Z89dzbwoCWf0l5vIZC6oZZOk/SvdU1EN1x+xIWaXXdns54sD5TydUtW72Wd8OG7NTFjpYYrNCouJ+WzFRlCOG+sI91iTpphAIxG8Bass8S1k0veQqwtAxz4RGZc+Son7ev1yInS3oqX5a+8r4/RKOiZx0VB5lh5f6uFjyeaPABi8zYj9vsSiGs2UJdwPZ0/4FbAVoM5SDNfyN2aBsRKvnO89RfIqyYhHBdNcnq6aYm7BKlppj9f104x2aZ9HiMbo+qgykFBwItA+bWfqVzKJsfbmcmRfAyinEkpWyUdYdYPrcBWQ7scaTgL6XBr4WbHqMj6TIQP0Nz1VtfkwZtcP9LPu4TsoInwiIDAab3N3dXlhtKE1psF8VNC+wi5uYfg5gb1dWrDvuNxTi9fIktOEyiqN42AJOGNxvWInoDyoCSQLXjA4Z49I4kljJOjdOl7w3WemvqI8J46/eYGC5cFvZqrzcAAA==",
	koboldfanatic: "data:image/webp;base64,UklGRsIRAABXRUJQVlA4ILYRAADwQQCdASqQAHAAPnUukUYkoqGhLzXuiJAOiWkA0B+sTv1/M/jZ5n+M33F7reu5hb7J9Qj5x+Iv43nP3z/Jf/Q9Qv8t/pP+s+ZnkPrbegj31/5foh/deaviCfmP65+CD6X7A/6s9HjQm9Y/tP8B/89/uP/U7HPpAKhI4xVSJfBtUKTcSq5dASAJhqpW1F97n+8btufwbtFCO69gOF/9haFZje7bhmI/aNGywA/AtrXirduSaq46kXRNunsefH+qcBgPrgEsa/TYy0M36DkmUe7h+PVJ8kM+r8OchQ0XED1K73Wt0oaGI7LQmP1qw58KVx3fO+Sa/Q0nv12vlPY3r7zHgO0L979t1v3pc+PoXeJF5ZGnrOioTOcG70iS4uY0Uqt1BXxwd/36c1v6CREet6wtO/7nmszeLDWDMAwF/yeHi+UXyroRtD4yn7VeyV79HFKjNVWuxA8BT4hO3f/cDGhsJQHnu2MDyRwM9IIrR/N2l3YihniC0d/rlwU1VKc4UW/ofzWytvX9h2J8gcUG5bk/NlPnA+IbUyrcq6Hfi139BSMGd6WEr2HhrjszibjYs9Ckj62f5drsGwhIttb2YlWPIyhrkkbUbw3cFKwQ2VQbju4ts2y03nn8LHNZKqM2cNX9apZeBbIZvhjqFo4q3Wk4T/1XVeK0P3ATXI+/p6kodqS+teCJ4fu6yHoAYpJMCoeaqoaVMhswAAD++g/EFKE3xHs//BZhh/v/aKLlFylPnLj2sfPIf+7aVWa/5YXzxBp92b/55HBLoescU2Z09VN9jr+YyU9hAUuvDovz9fVMh/j/QHryefezKf5ZVQnY8QPnXXKVDzE3cpif6G01XRemcbk+yI/tn5Kc9iZe/sxWa7ZZ7HR6iQnW6E/4JyRxGwM9DTAF66Y/3ISENNFwvlwN/4p5vYUUude1G0iImLBazpvNG16YnxB/JXcFzPeDH5Ko6vRPcWh5fjjc2Wg3XF6nYLv6vpuWGJk8heehD5GFupVy5Fe2EONfqqZiNTWgNqZl2wNBpzC7gbF64isW4GhHERkvXG7XmSvCDe9AShZR3Cno2D45kOReqENsNKbCQJurQl70S5+0cZm48k/5hhEerpXMXJPdeIldk7XfGXQpF+85kaA/BTqd73VyJ7Shz4huO4PtUWLQkOjp73GO/hrsgSFNDEAs6twD3RA83Ltf9yrM+UHUtXRIjYA/maQfOQ5oqDQ1FauHuXthyXqX70zUNYOgOO2Nfq3uBxci+u1QJetulMgYOQeG25vkhvusg49V1s0pGjcFmr4zd1kPSfM3418KXZpAGXkqEAFHILNqjltvVvfc8tFtXA2rrDg9eQ3BtOFSF0L6wRyrJqqfLI+BP3x8QfatVPke0jgJISSUJO0NIeaJFyRZEnc1r4hKank5JwJmrnOgl9s7P0ztAWMcnTpDLfs7imTThZ0SflwCqDphes79TH0413TibtHInOj+VP0/or+obdYh/wKFztIFiYaKGlgJf5UPgkq8on80YGa7MC2KIH154qblOpuJ8Am+twto9qx+yNORpH6m6yu/0kXSpi4FjrlzDAdnjPo9Etd04j+DLlT24werNwwjXoQx+TiBa/pk/6CeNA7wExFhqK9vf7u6kTBsGf2teZ9LaLjZ9P3ZXdkQfuvUWr84HwYxBFBSnAbVCdcCVpggWZ11PHLqzx7nJh37SLcep9ikKrrGPqSMXINnUxix+M7Ghb7YyclJV21P+IKwu+qvQ14CRo/5eRYqD7Ge6vlWL5FQh/f2zNksIXQf8dAxwIrj+kz5Fw43lnFihBDrrnDsgvdF7+4+/d0Zr4aX5M26/4XbRFAXPBK7NFFidiz4SvpybyKehwqZ6Qcl9Nc4++Au3dRdt9j0+Iv7z3Fow1a/BwRndhNiDVPn78MQCETMk2BTTR77piX+4Dx+uVAvxM+6w3qc9ndy+7rpogAqrCrWmOljD2Oy974lYsy9NDgvEufET904GjmtJfNWrGX/bQTO68zeWni5TGngR1/ey2LrSuELhMvW8Qkn+a1AIHSUq4b0CxyxfZlAB6jtX74n2dzcjViFUsT9YCEmDldM1h7oQAQYNL5Og2adlPLf0uuTNGKCkhF4fTTAUaJKBotrQTiEuxaR1p0gUgOKe/MgMx4V66cPUA7lNB/VyvPpDXLftXJVPyc3Mb5ppbLXUfod6yaAZp/EWVNObfhNhaWQ2ocu4Hke3fvcUEFDOQAAsJL1u70hU6zOucfNevNSZdeY+5vk3scDZcNGbEsTZBDPIKDV55SAuj/Ny8lu8zz58SJHRP00wObwuPA5zrZ9uH3ka+U9TFB9rv++FCaX6atCSPgETNF8EYgWvyRrblX/AldqbpZdvYvgxMRaY3dzv56Iz3mncS9TbWgYf/pE1fF8zOnl5URhIJJx4YwxDbA0LBHsm8WoGkgodhc4ASRzkBl5TEcTQrnrCePry+pRtqP7dOgdcN/ryH6XwfnJHYIuF/a73pweStKGymkMyMpwIlfVFUrv0Pox9ZeEoLPl8YYDvW8LRwkdzzAUzMi0tGmI6iIiCJ7NhchZNJrHULqo9ovc9A+f9gFbvOMNzScBuYh050YaaJ/HNg50SMALAYMDcEzE0z7m1qVUG0qjW9wHiLUArncYdmDSlMlECBCCye1hch1tzjXhdqfvhPhyACHgSL0EzTTuzq4CEZdrnvajrTOaT/af+rg+DGGEXxy7Xs87+TCk/gJZ+9SsDTf9712Jbo02D/YMORJB7Nz6vqk79TTQZTu/xe1TOy1Lz27w6BqrxA+e3cqHhIU8InGlRFMTlOpIDg5gauQceznjHIXVlqMp0rBhI4HhW2AwCB6o5aQ9ctlu+EdNEJBzs6uv3MOLAAp9S7kI83cuvx4JB7Vob0zaf9TB9qRUJqBmBSXWUoof50wUSBJq5Sad14rNF4MpXbEUoajZKHgGCIbzXnz5zvqF+dGbEVI2CbqJsJT3MkUg6OB8zb1g6Jn+8y1G4DqYzFumN1J5Du6TMSZCmaHI/eEAY9Zx0fhMEwpY6BUAjgxT7/l1sSUgItgGM2+iS/S/fArnwJqFWajxg5XRWaWxQWjsYXTdcpXzwI+IODFzUo6j1B3ivEeSxdfVO+Cl6MmXX9Zaix+6XDgqtztgWMqklLEPdzKiVkg3vQY3ySIT/w6C1dEUuiX8bf4WSV7BSiS+PpYUHx75F2ojDc861taqgk8Cp9PkCZPfIttLvgpO6igs47Cl5mN5CDXbqCisBm0uG4+55X4RWswuChOPO+m3F3KAVOt7XXSL4y3uBk7q+zstB1iJCCYWXrYclZXX/MQpaPfbNug9wG0lj/ZrghaIc7qhwv8LIIGQu5OqjGvy8N7OlwGeROlU7kmr+41dXYG2XWhu4DfJ8KxsHkeKd11hzE19LyYSby8BzZ2mZBKOD+ZL+eK5y7bnMn5YvOIrFsQAtj7h+8zJ/d/YZ4vUTN9doFL4LctGTqSGq7wj4PRJS38b3ZmzamGJgzLg+TtCrhGv5zxMyHrG+5vT+9SxxdngaVBixoVrfg9bqmj5YxZ/jwR5BihNsVwNB6Pi55JlSz32NODf3ugWwAMC6/pWegmBA/kQKFEaTIflkGDo8PJzu62jXGSlGJ8Uer1aL2mYyJak+q6ije02I4l6B5KbgsgLJsDBRrn2C0isFbpLqC5rmY4mi8kxMuDAjRQBnE2w08t8uwgwqC7eRLXPJcB8zoxOWPGeMqQYuIKDpGOREBjWEThSql0kq2Je2S9ELeBvlXs8ZxLHvHd2ElaPUfreDiCuVoXDagOewMws2eWrZ3zUDq/AwqsZA3Imcg7T1j+zmeaz38PO44xp68hU3F+OX8Hp5QB+NstN6MIabKvNOjts/HIhYH5znaif8ao9+14VLcKg4iSYO4EAHMA+Mk1LFja/8TcvphwPHxcbyqghGtaxpZ4nQ8l2F/aW0LHRPMtbb5OGy/osHvit1Dxdh0bC7qRBb9OxftImL2KcpdnUcFYXBqZ+7SCURMUthOVdw0HG2530SZJTDf3gRHM45qiajqvHOTOkYT5iYnbSbv0G20R3Z1mLqNGgmh4+ypAZNKK1kNkG7oJYgKk2DQUzyvzv+sgahiNiEL/gSR5QALibBkFf7QgGFHHa3TbGNipmpdv549v5U40KcIm0qMVpI4C04y6iCqRTJMP2Spu/hmuLKyutDS83hfIer6w3TTI13E5WmpMu5K/ZrTrlrnUbrKbqbKQCpUIRzXopFEVkRmuWFQ9uEUokgqa/qr00ux0ie4fG0YA51xP2rxi8zJqzjhqH4MLMpzh9godKwUgEH+Zjb8IixOYmOQHdFXD8/wT0Lcyg0KWrkIE32/wzMrXc5n5R6rA5NbVLs7lS3njV7/eAN2IK7EVKM7nHIzqhyiHdY602LyGVR3yb/68rlqDukQSBVb/qDry8yTnKxo0ywPWzjH89LEzvZ1kaigQoveaIxOFGR5VSoZxJYXWnqp3Pta4wnjfG63lBSGeokvLvQkfI2EifCUHRVlT8U14+QkstWB1WRhzNG33FC8JNqKinn93waG7qrBZTdSHoZToX9548IluzShUmGvosouCx5XpYwv3x38yqSiQq0bGy+3HXA5rPoKNSKjdMloJwLexe24ZYYUKUgdm4hh+8Lz0sDLUHD2zJmwXmyqhJfMTro9/1AGaAXDyuMVOMbGns6PdWTionxJI1z0dRL7M7gz1Dcty6BPat3TvB9Hwlwbq8QvZrO2zZBREYxZu/5H7IplEQ7cn3mVYfPzqH2Bxctr8A7iY/mPUUraPn2JQDy1ne+0mGR95CFXRmf4jNlXhea0X5StezmbPE4wX/gfM7HSFoJhnbb0B2hmbk+V33dOf89UCYmLE5HFtz3J1TN4Xo9E+fcZlJkfifQFip9r8h3+aKByHQuF1y5J+qFNBORgcRJVuHlyIPqGxslIWzQSudEMPx/oib/d9aFrdWAXHU5RPiVcmkVk/rIFjC0lf88YckV6pa9cbUsRnda8bZsmng4nU0s5DRigeWIMjLzta94IzUdAFLb+EBSO0WuGqyP0K/1XDi93ygr2KTwP58uqya4MUqv9hyKBtB6GstS8nxJ4DW2fneCSTPPpertLmRQ69MT3VDWNZYQ/L2Pf3yoTmS5v96gMoAQCzD9sU/bQGUO+voMu1Qzc88tSMFS8T24CwYv6Ow8CHcc0buIZw6B2MrQYvEuenPw6uBp58HokawoOwO466B6oduobq/xfQpf0nnztwu35cDussWzCVtqki3kmuCGV407pbYQgL/r1AyLBLJDfk20sZhlcuKvYwUBb6QZYMWsUylY8j9fx+PYbBzLtov3BWCmGn0irq7vC0xJGHrn5Tj2uqIuHtrBqFULqDVrbFCh9KxZTZZjv2Y5wACTR/W0VpuRMBXEtvDPIuCZnykMg5Q2Z1/hVOzBpy2KIzr7D4foIwEnDfd6eQHFdLfwKVsOxNlrMP/h4ScPofe57FtDGitJc4ydNU3VtHV8HP+7d4n3Jrcjfzb30m6foQultU4m7RJhSCxrWOD7tF7gGKcizHmfuf7mzlfPFRbYqmouDXmFVXHhnHdnnES9z26uN0X1ZHk35BzV04ZjtIyyi4tFxxVfsdCCct/vy4Dx2UFe5ISTy88AfMJcdQdxGuPWJJyZgceFyCpZgwkZLX9hmjX0UBuMDEWIMqP9glw1kZ5QWDvztG/2Ch+lfG7BX4Ptv7MxJjaqfMicFkMNH3AMZJzt8XB2Y9ODJHl9JG2lh4NmscD47A6hm9GYlOE7MhnGE58hGyQh2VvCYRHJhM2HQiL5OMJ2+9wwSw7bF/pdsn5clc8aiTu0uY53anheyuu1SvlNVdQdR4wW8s6mMOgyb9wlkL9zJ5pkbKOfXa9D1SOEBTdcgvqodN7P7URXcYMDvnbUN8D4whZbRg8itESJJSbQzOBiIRQ0Zr/WC3vxj22NFVz86bVNVKIX/z227Go5QVIgFIaZe1MQbycIVDUsrD3ZtLNjuJsOY2ySQzqZnixlQubsh5kUq+e8gHnd6F9PgAKf28kbfAA",
	koboldgreenthumb: "data:image/webp;base64,UklGRk4RAABXRUJQVlA4IEIRAADQPACdASqQAHAAPnEukkYkoqGhMFYNqJAOCWkA0B+wnnn4G+Tb437pcb3qDzE/mX4c/g/332r/3nfL8o9QL2v/pt7vAJ9efAM1PvEPsB+Wnfv+newV+o/R+/8vNV9d/+v3B/1x/7nY49Gv9zAwvI4brurZEanFR++SslthQtz9F2SppzR25kekGS9Fev/6AgJ0YyyzUUnmiEO2hz7IT0iYiZO/vq0VsGlvlAGKHVsMCJA0qh58+INtjG5vXxAgOQOsmvxtcU3fBhcc6QSOc4nawkDRwGYfelGj95RGK8D58WvhixpLuEpGNArmWP/VxtBNUd641BKzWWGBMXwNkTvFyxzGETB70pFoQA4vpnJUtP9MXbiMU7RJQ0pCogEspPdo1tz57fjYvYCKr2hrll+b1mJLagw0kmqRlokK3c6m9txrr+HN2X7T8Dr2Q9b5gyLiiEtLGldeyWQy/EyvKOkUL7XAv170HG/qtJWCR+wCN2wnoW1zK9GMnwGrt/d3OYJoD/BdWh1gmpaAQ7YujRK5iyFaboqqwVTVM15oRjgdsB/MceaGGhOxJGp5Cp2IsrAG/KjGoplHdGgdlHsIoTI/XPAhWOzgZT1IWy504T1hCBCz9wEgx2PnivhR6sS2OpZ0at1ChZ4pNcy6hv/0K4AA/v3DfTU81HK3npCtOKGFdgvTkb0fRKptzR5xwn8/7gv814J4Vx05BjY6LTLT+/NrHkK3V5QVhEoCjzFmCzjqchpob+r0OqBB86+1P9ANHR212bD9lAum/ukgikMB+nkVadFj3Hvvm3PNhXrqx6IrX5siEtaPxlN49ruCF2VEGTJ0dfiIDXQjqlsiKjZH/hHVfn3IUa1kAEaQZP488SBBgWGxXmjenukKrNs/cPkjbBQ5qv642b7lrSJpxh4VxuFkSnx2eZYdoTBYijAoY/eOH53kMY3Elp2NpHN6MAlaCbcueEwl8Qw8LVUujhpRaXlqFGQ5N5TAGH+2TnFWh6fa+RvyLZnceSE+WlojrOWveP01QtOoJbvTFmq+jzlUoGiK46M25r72/Zo3xcm8cszNPByyLXV6XfcEH/ldaag2MlX+eiyHpL0Dw0ONNC6dnMtkWRCdl8Odfaamsm+sn8MJovVeet4wlKIK/9T5fLprf1q26FxnNK8q+L7JIwBc+HV+e22l2L0lfyepXNiAPFGOBtF6kbKP+EJm3s8C0lg/dTIdN7BOiGTCf7x/ZwWTJBhzf76/WBYh+uyJ/yn8XPQbjn6B1L6pQPGurDPZMv5GnlwiryJ0hHBJC6MYQ6lbgL6Jh/bvS8Lun3il3cqEYv8zqAMgEbDIMWsOhVsWwHvmHZDbLxNCyT6oP8xdbCM33q0OTGKwcJYI9JxTPvk7/c2qPpQv0dc/9dymGkDIJvEwVxVP7M8Q2y+DDQxAibXYFQ22pLDF8Smh+e1lCqyn8InJf8nf1/5tx5y0GqWxCkcFETWqt84mYrSlxxcTJRt386rOx5TnHfT39dINw7hktqW7UgFmoCchQeT+ivAzhZpnCK4LRZ5atakvcGFPWxPHh/vmses0v2uSp9zusnjt/RRQYrBl44oRLWWjSGmtEs5x93BKTOrsJYJn2fzJOqny5m4Ymzq9kU2SdtEiYBbNkiiV1fsjoElpRPjt7wsJk3N8Tx+/JEvpHBGZGYLqGGw85DuSrkBLx2tXVZcVNJgMwA9td49Y/YCLhBI7wt8owvSUw1S343nh/Cbh/swpM6eRIrnRfm4c+VwI/SE2KRMlRmWREoJF4Pbv/5bhL17bca5G7LkGGjY3y2lJsxOwL3L/LiDzIQGYYd2lT/UejazukDxQHFpNHIj74GRwi03lR5sTodoqfSx2x9aPpWRfBfcIYljlrAO773VC06Smv8LpSXOLaz05Et0yCuWNpdJ9JwILDcqS+Zs++pwcFoxLpfkd/RlrnkEj0jBNqI85CbdqJtK3J6N0XBHKQC1iRyxEHq0LG8S/cCC/Bicm3ckBF/L0lzZBI90sm74kyAF8xk/9r/IHwBzH/LUcwuyBTpRfBTw0VhoJxe9ZvArI2HvcLUdAtJMYwnBMoVjFCa5gPwabX1wcbDwdeWP6ZyUgm4lLNdCAasVLoop03dx3jeWwoWkeUOL2UxQF54x5uD5RqiuCQiiOr/u4oHPAadXi9Ypu/WGXKsm8mZQuO4FpGVwC6cRRVzL/oMln+r0c3/5WHin/p/bYyKxrC4d5MwtL9Fr40hBRLntxOZ7R5HSQABLWZmHS78ftkU2nb9yADuAKa8MHB/r/ycv1pkznD7R2/dX5VSwfl+k00fZ6LA4eSc4Fyg1EiexB0brQjTMQc5LmrHNTMga1gBSO0uyNUh9va7OnBR5smtpIa6+bHhEuFHUOSp+I+gxxdXwGmHBZoabpxjcv/2Q/URnzgGaDYi8TPR+6h6eXky8JJP5TuZVTPdqssP0NhxF8p6Fww3s06xbBJiKvnVf80Ro7Kd13TNcjXFIynL5463t6m7auZ2IVWLZM8y7mUwmsX7azbxenk+gjFFZq8WAhNIixxif/63kZrUSMAodSDA0H+sCpoVitT79yCp2nVILdD1ni679G7Bh16pUHMvxFXMGfLAK/nQTXCSz6vvLhj2TxiQHDbKh/uuFg0P+djIOzPB8ETYhetiSsv3QBgfEgEMgI7NFDPQigi8yO9MrpN6ATvnGnofVcFjj94b1VDBmMZFZ3EB4cxKqZufM6CVqCZmMm544ffaUzZW7N/w2mrTSEnXETRDBZnGsK/p425/J+aN1vqz1SDkT/DcC5ZzChJTgeisER/lBBjXVGh3SuyiV5fX9D30cXF9Ls+doqJ6J2r/l9n7j+D5eFcfhHZLIybP+uXOORwspOhy+v/TlhVQLHcdFq4koOzK1nl7piI6p4maxHhgnh6aKLn4nj1op+dkk+D6F/Wg2yyk8nHdB6TE1100FRefJlYYtKP/gGeU+J/z/en+mIPr0vPjVfDg4t7bVm5GbIL0dHYLFg9fd6CRImvlrFcqGD238y4RfZXZm5gTkUgOaWIg88QAZSTRFRadHFrdmJ0AcTmMdRZVhLhha2/Og5Coyo5IMO1xmvCo8vtcAemX0hD3Tq8uo/4FCb5Godmm0o08V6eBAiWslfl7n63CboLizxqnljhf1LvfE9pHgUxTkq9ilOHZ35dQezbMnwhKsyB3bFvIHzfj9cBFyZb3KY/AOPZf/mXge8sXn4SBTCIVZGQMucVFIj0QAa8hEwKbhl2o2kLWeyCe2GobBPhVUM7x/XxRfhVnMu2Jz2an42CUS3GtD+hodPt903Qidfyuvy7niwCiZ4VScCOuVJ51c/nnrMs5dh2ADWVRn9+IExac1bun/NK8wY6NrQz6OXaA23f/HinvmHGjzmDnzYs/5o1+wKh548xPT812YIJfCBov2hfJ+JeJ1OZPfevsOBUmvqpj4oPwqF6BpIMiFLbAOV9UwQXKYewBNnTRlPOwiYr5Y2HUzaw7ZcEU8xMJx5W+moq4GylYi1RcdKn4Lg+rBlXJm3gjPBe1olaLn4vvVyKErvftdeSS9HBzWE7A0qFbjZCIZjvp5Sidx7wEE6IeoLZIcanG1m+t3/skJMhfgJxhsPriPGnoO+9dlyMtftEnKRLZsJv/ZCV5r1zWDf9TydJ2rPy+69ld2F4RNobrQj3u3RCzb3LwS2lZfURQATan9Qtbd+174QaDte/c0984A27wMrsl6kp6YR2bOczxQ/HSPOuKdWYJ+MSDTSd0ySAlSufIKM4z+TechdldYQ9zExUWFUcxJKiB1zCRLXa4QimEbjEbm8AXffdeGCB547oNAOlL491Qq/QbnbQi/OVFNCLdcAv2ZhW5fG2ygfZ+zn4+dg5lC4GUoe6vZIjx4FIUmiu9nPn0jg8AI2FpjPFfc644CoLZYd2d4gt4FVUfa5ub7f/Xq2szXCzV9tIlanUKSoIlDI88eXy6U9kJB7djUMYvI2/kUtGhZL8GWQHpJ+5Q50W6nS3Ulie/eQMCYHO72To0ZK3AQa2US1fSUXXBOGCaoWE76YWozfiZ3JKwsR2RxU59/1lUeeKoZuJJwZrJ/SkkTpOBqCJL8DKb9UeQvVfOCOw5gcy9qH9KWbSY4DJsnIrYAo7x3LrVWqNSDLLsV2xNNpsOoUOsc2bFMeSrxnzQbavP+15lFFECuSJKceXwviNfDthK+ZQKV+Vh6DGbJ3SF4H4QF1kkEyYsfUZCp7DiiZR4zoYVp/hItFKTEBSrQsxIaSYGCRsWZSF28UGGUlI2WCoATKmoJ6ka9Zws+6kWSJXEKM/QRsldNHRtc9B+1ya6urPSvYM/PMe75AZiZt0icezXRrbXrzQ0mIHXNWDkbt2llq3+QgaC/3QiH2tnMCGuNP6Mh7PbtyI6GZ0JX7LzAZS7Lnul6yNjS58WoNdVMuGtm9nEZBnbfohzm36Z7qELSFbkzGrcTZdLPBGIo/dvqC7/7MeZgk9Y8J+D7AvOF7EiRpJnq4oIJqBAoAZ8Ss1teeplq8pMpM89F4EiglZdRDZDJnrzCMgH7CitYqEskM8ImXiGKtgoyrWJO6mmmxIFrf5ONNEaaLP3bS9xgYAlYqy9+fApxOc30ZyKDG7dToAnor3USbrvsDBu8qKYSLZ2IdFYbB8A7mOxLc1MPGZvL+W5mU7bzs5UmQ0+fiRVWSOVATX0MSLU4GxzUNDMrw2hq9JJqNoTIXm33lPFMHODC0WlOHmG22bPKXKGhXRnqXHa9uWqMYcGK8/cYZnrgLbIotGm7RIUv9QcWsvXtFYU2IH/Hj2CVIZL++OuCWLT8oWhWYdU2r3BNp4dyP7fplgcCm209NparR3NkoeU4ru8BTWLkC77IVHWSpZGpY05zbPvy/hhyuOjuxj8TvZXSEutAT//twaOW71SJsm2uO6mxcywCiPaq33e9WFvqXMXa4+2xqGrGgv4LdIDK04c63IcipDtQrV6hjV7ljtsedXSIIK95SsupukAdCbMUD50dadLpDyh88Z2M56ZQfi+3jnufpEIj7jzcvxEUZ2cnCSDJzDj4S1h300olmM0aSrL4RM5DWXy87O3HwVEWqeLkkMXO1PTw8qlNgVHbixmYVqsCYlFFAoDxkt2umWwjSv+OVsRsRvYle+H5JPEBFPn/5Wfo1rwGBeJv1ItK2B+AloOVFnPxtC6VZacZAWxweK3ouJuPM3/03+CF6gd1edr2wZJZenqSYRltCSqWIBme+ZROgLWhyHUBIykBMqGDM40+FD19G3aHO18LPN6B7qLbk5k7g35Qc5DrFjD2vqACsQ49W1JE+pXnBccIelR/RCZpeFNWOyMVjeagjxMuwIhaIsITZpSTC/czAVTNeTObDCBYgPak6vkHaQ0cFn+quY40bh+c3tOflA2+Ptd6YDea3xR9B46YGZhKcH4FAeRBEBKt8GfSlSDGQobPKOWQPrmCS2e0Y3sVwTt9aeX+O/ddyBhdZ491FbD4GXQeKpex86sWhdnh4DXFoq5u/e+SW/GaBMSjr//X7PWnxIROyxBmqUmdFvXYNdEmWPs3tBLhfMkbn88gnaeqW1qVUUnuYaDu8lbcFnZKWS3mleJRnzlLdywUt0OjToppqQfI6pcsXC++7dDn32fH6fEEZeVtKYJu92hxlGRJUR730pzPApIGgGu3H6ocSNNpMU48nwzsIvDxZtJ0uojk3CxOizaTlfH85mfsSnChyAJ74i4ldOvunOliO0BtrcIK9anKdF6a4YxasG4zFj/wa+OIkSVHyPN086kpjfx7KyL3RqA1KenlZjwjpdbEDE7GBMUsR8gvxAKzbqPPmUyQQLwvmtzyoFNW40JbIp1MnXhq5ifMUlZmMb0RVpaQBvYZpptm31gZMeIpzEPY1ijzhpKAAAA==",
	koboldtracker: "data:image/webp;base64,UklGRkwOAABXRUJQVlA4IEAOAAAQOQCdASqQAHAAPnUukkYkoqGhMFONqJAOiWljPl0Y0Z2IOff4xIWcJ9RHvn/l+t3+278/mPqHexP9h+XvD8gE+s//Q9KebQrhUCPKF/3/KjqGfrv/0eyV+4ANTNVaUVCh4MXmNhkJIk9YqIuS74J5RkjLWU2jSizKL4+NgdbAr82q/g9EIQRObE4jXYDOUCEwPJo35mRM3SHWF67T0vaDytqcETTPL/f/8R7pTj0pFsWnPOi2ZVq9AB6S81416MPmX1D9H37ZL9UZacbPdKZbrzVdGogeJbcWIaDCjak8zP6dXo3BsiWPNzgNnYmB1Mnoa0l+HcSv0rsEU6ZEs4lUeASU9CBO2mq3qRGxM7svQyhQR6LnhcvJPOAX5s5Y9JT/Gwn/kd/kowjqx+4NGewGF/oo2uZM8i0Ot+vizONKEvfjzilt2pSE3Dnm40V/pdHGMNIAo3Tn8roSGuaI1VwU7tjxUltb4Wv2WQvOfplD5GmsQWZbJc81BSoe+QWMEAyyK1fIt7t7nkcr6sK0yqugTwaYFdudAo3Pelb+5Rf9uGmqyZSkCASrDqgTmPh7j2YDurkpVkyETd1Lcqr2ck8AOk7KErG1RMRIpIgVYqQTDAAA/v2PQfieqcKsrWQJT19XtSXEL4/bGqZmWxQhGlir+PfMEOR2Uv2cMcD/sWjUu5J3okzddpU2eXolMNwy4xbER9fhuznShe36ePIk16JR3zL5TGR8ebeMmz6uYY04Hbb0fkyf/kiKalPvLTsggOnwWLH2tb1o2v8imOdXpbrMMibfuS3+ce51/JP+fG6orlFyK8vnPdlZV4RxRLwkoKqnFc70Kl/ETPGkAiJkos3jEmEqhupkiiNbfYPTdVoa2Jp7x5IXC90qjGNDDpwX1MMapZEcnLyyOlpwces7v/I66lxxYn8UYu1kYC3K/8pGAx3SGNDPDsxCyIfT/Ob7o+5qMAa4BclfiRDoJJ32bgrC7K5bF6Ily0unpZQ9FWNWF2W6BkcTBKAzWsGOIn/WIuW4qQPUDgv2+zTknoVukOrkZWRkRhKlAENUsZmRfOeDS77cesYrPD62/zX2UNMCk86MeP5u2PjL2X7hn9NX5fJVInFUdbg//z8dhzu15W/HTQcKrbuaTAag8gLChyPtu7+Utq02VbzOu6W3dzAKcTZcezT6/+H/KROeMhDadZoi/X0AAWzALzqjFne3NKNBWb6Hl606Qulj8KpFW6Z+rizbXayinADg1P6lvFP8/ZgPwKmMLc+oEqEftBQKzzSOJ+33taVfi4oTXtIK5DmzlLu0h7/ZKx5JIk3cxlllGAXH/3mzvdYcOEjWdYnZy3lziU+t7LbKrgjfU5NuHFG5LPSXNcjbspEyXVx466s9wam+GI2GwxX5OOhl+O49YcNAwIt5M6lKKVnsgRxL9ZwKQ0gFI2pGHo21BRAMPcIkR38xoK7mbzmgaYxk0qjX/fx2Fwm5leobH32Dj+V0pFTDLAc/JXxONt9C7FXDLwu35AFDOcE9/gPzxisxYbyU90XU7rLpzJ7CqJ7mEC51ljyF0ns7wWteCJnbSjQ0XJ+TnM/KIm9f3ouoPL7K7Uf8S7mO/WDb//nUfnLU55Kl//KjVaaoJqADkZDEj6dXh1bjeunysW4VSpfaTTQnyNx2ff0wUEv20lEPBZDp/aJIF8+xoIP2T5L8FBhGJcP5+Dt0uGRIvf9PDcB6Dsn7aR+Vm6ybP9c8isJ9udVGF66MYmyeSMq7Mrs/SNFTtbjFcNdSUBdFDINHZwSbBfEO84cxxFMyOMzN/Tb1tXnFBBH+hlgvYWhTHuY6uYP1Ip0Bn/5H9if/8ac7qwaLx77FSzU+Sk9nkQD74Lgy6CFxSV//vE2T29QmS/ukQ7yOVnMwxY00IOwV9Jz6cre3wFdx57T3THkmZpvwDl/qOJyZDAJg1if/8nm+g4tNMTzlybl9Vqi8WFcMMRnQdGx4siEmBtN/q+3v4byiW3VaRWnOcmeDDyvv/iKiE3+pintA+Pwp9gXF03Lhu6hn1yboGUZq+BK5Y43M4Bg+4e79S8kOKhfeYBOyCpbZJC64IonMnruyz/ZzIraCuK/MbsDyo+NjkMUNk+HzEBPqiajx3BIgp5JDc8TQp10xTDsalaBZGLlqbLlZOAvah+8Xxd3y7DLr/jZgtTcNHwFOirS+Io4wujviKJPJjHOxzp+1W8uMz9QJ2ngnLUxlA5/WD2AuEokU4qPHFHzinJFXpnHLez4eOHUNoE62jOYbJI5jXPSFQ2DRMcyNP9cJ04AmzumszB3EDPEJC8XCv+raBUaDKbADmqVltMKIiVVNrw+skYJ39Hk9C8btgWzYenISlVTPG6yxLpzyjVKK++zHGtYNIcLU1G8yK7LIMuCp1jyKbMx9TUVdpEfMZ3pqBxp8l/DSy5U0teLNf0gqS8W7BvBfLmwxoUhA5ptKLdMFzC0Z9jkAX6lnAOYmoaRv0CAWVpxKCeOdWaA6rp7M0HMuEQgq0BWDpiOn5uoAXX74/jDnYZA0oBAb8ipAOx5gh6ziP/1Z16ACj/gyvKhO4YIf0jtDo9sVkyaLBn/b7zRSAEg9BOGzeCBAmOlecvsOsDyoPKXIEz9C9EefA9C0ecn9R8v4y19hNfYWVe5+f/eHG9eBAuo/nwPdFG1W2m2nw9aE4AwY33nO0TKqlP4nFOIgfLL+qJkVmcKliuPbRjDOqwmq+K3v9XvBzhOdmehB4IV8vsGDymkZy7lpxklkbO664ebgXxWLyM8332ImURBMqIrUUhN6tLtycQ8onkH/CkCr2bqU5toHRgm/UkRcmLFBML3FA+sUDXqxPlaAiJ14v3IeKW5uXYCSCoW578xmHUNDG+6PlUJ5oypjyTzR6tWvZwtuwXIbwGGWvYxzKhqXvDsvvH6jHFueBU65R5BWmzFzJ/Q+SPvKLEUAqMjX7E81g32hxR3S2tnRF5npnxO4oo68jZ4Du/tpZAjVHAWyp46uQx7YhJbvYs3Ln4v54CDmqn/KAIglvNCM/RXElFWbkyexifpcXHCGtLGrSccaDQdDOEiLstKavUjhCmcUmpZZT+Yu931pC6Vl8ce0SAP/ckAlQ7uYCQrayARInwK00niZXbcbx5K8r791x2CA/4B86ieDZPbbLLLpQrHJ0zwg4rjO55mejlK8ZnrflHhKFbA6qNjMuVIKE8cSaqgQ2lQJHT4ZpuDRulPZT3MCD9/jqZU6cRF3Py/CeCSkEDxnUTd5274v5BybtPzHxlS4fcoToHj8DJYk786Qp0thdDGz/Hz0xPGsMhJKUS5r9I/PalJG8ich40LG7CHp2F/7C/7SHH9arXmmeOgZBGmILZsNisFB/J46rUh8lIDgKEI3HGSLPouXL3GxY1kyQDvncPKwPOvSE4mHFdFRPLPQhQUoM4Oi5wm9pUnMj7cXMBWghisEzqW2QH6AX28y7AhIxQ3DnynG8NOep0gLRy0a5g9dwXK8UxGRB6eMLuU9LvhYZhmZ6g5A/co5a7QhEk1Dc8RgJa14zLO/Sb0wmep/2Q7GrsfgQoDrbC+IzmR43Je3FBhnGkG1yS+aqLaXqB3a9H3eHu8L7tjDbAJFn2mSaFWNmFtGO5+DDKTT9LvMmB/9SXiTHQFD/ivdrowe9N0vX3+hcMHBrycWZw7O6fGFgXwj8aQ5wuBSDlXAg6LTiS29iHfn587xLsdR1r5Gv3UWVO0+boLODDfHAtrV/oQQE6o3BGG3zpXP6hmfLjCwtUF3HwqxBhGgErgbAtPr9i64fgpF5LGcSSUG9+hONkG+SR6nq/U/yueVYe163Y9ARlzjHB5h+k55Eqk+fD+k56go/8xz617lta8fWOEF8CbTwQZDsKeCM+G125w4NQ2Zq/qmqsrx2Rken0/CIdiMwoGcZU6LmR3yEpu/b1G5cYKmq9Nui5D0nhv7yd+WaXqaKbF4psJ1J7XtLNtNPSUVClQWwtBT2OihO7nLL/nHOzx/JDEVk4XV+0CZB8FRU1V4i7l5iiqgOo3zNOeA/ZhYNO46HR8Fe64cTYNzI1og9pVUi3ZaxiVgHzTWGrXBzLV2yD9rj9QjULZVw/9jEU1rxXLP5WbF1hR1Lb/KLSTRladzBG3OQ4f4P0quxBPiU59kKH7pIN0VFdJztMmxcGUQTRrPW4EM1C9paaRMF10hV/85YMyuDFsVOEwICQjBEIlpOU1TRn0MLpQbnYvmi6BfxQCEpyI0NvCnq3W7yxih2H5R6CnOyS9LdWYBODLIeL9QGPuHnuDJuHdL7HHmqTvt6ar1oNIlcUl7aTAvPeRoYxt0RafzZgGbRPqlMZWdb1aFThWw3LFaQaGBr2UEL3GjThl7tVGjOF55AvybGlrOJauoFEC3LXjFSVvUbDWYU406IaClDd+t/H7hVHvXOn36Vymsx7JVFDf7O45nZbduDVGGC/MY/kE1cLZBwxqaWeLi+vPNo2fjcIObVBUjpKzQBpZkYBmqYZHWklWflCjO7DoOy91Llip95uCBfyPpfCP0Vq4jS3mOB2Nw9smejz5ShNeRLpgPcuhh9oPwKt8klOA32ISICGcA4b8A1IbUvkZ6ipNY46yT+TbJXKalSLItbT5EZixyuB4eFsMSD0/vvTIrT7OYAc9IIQF5SIkxudqLYE6sCzFjbxAClDxek9fkzB8wyRenfj7rTBeFyXJ/9xBGlXtIzCXY6a55dtaV98eXzan0N+jDhtXNt+PC7TfzrE2qd9ci27tp9izhSr5TEabnkKeo+Z7/p8KonVkQYGenRwBvL82THjsgngjTxTHZ5TrWpWxM0xeIEce4ra/Q+e/1QEQMmAjkAoMI8K+vjVcfBo/qKTriGN+Dk3f4wTe+Zt+k5AA=",
	manticore: "data:image/webp;base64,UklGRoYNAABXRUJQVlA4IHoNAACQOACdASqQAHAAPnU0lUekoyIhKDYLuJAOiWkA0u+u7xP/QeCflL+YaA2Lfs21FO8/Hjv14Bzw+0OgmFjqgXxeP2/1E+mJ6EorIyAxfIg1YDdjVzcMy1JeL4XQp6fzVQb4T8BnvqcdAfen9l3howdBjV0IGkXPs9sxreDMNqnkaE6QCdrw4MMcaJEOH26DWkFkqtFKC8rsohGjn0DUNe7bjPFPsoJ6lF1OlUbRAMmofOrfZIjnvFsQv7R6bxWj2jeg/if2PayrIPRJEGK/sFv6SLDMDHgvhLOcmLQkTJmoweQufQZg2STG10/k/Tvs+cl0ckYbomrRmIV9FMwgE9OYUXhfNevseArRKhS1MdPhGRIQ5YX9vJDt6YfTeeK2u3WZ5k8IOcaNXJgw9YHeISqgFjwsVWMe4CWjAVaBeFgJENeEycVBOgZQpV64buspqMX1BdSdMRd1RtILo205Plo6HJjXmDoZ8r0WQR568e8+wg/dPZs+/eUiiDiLVugJGYdYnRkhFJzswlCx0bvpBKj5Biu10HVxZ1IfNYvWSODTbC92nkqyFnmxLkfrpXmYUujFhosoP1Z0d1kRvi3AuuEnZH8KyIY/RtGzTSV7gAD++WcDNETZSgidD+w365I2gnEjz8ofT1vyrv5pv+1zotapjUU35LjEyaoTfv1Mka+upcoy/zODNJ2XXH57M/Vc9tOKuDJGWN78Kq6fdSNvCT7SOxuiKM5dZAnfM2/4fCdwsK8vtNXL9C/Z5rAX+f/u88j7hDXheP272aj5AOs9j38SqH+TmEjw5rxYz+UQmbhKO7nD04L0zebOdN3S6HeAbWqgsYmaJyUpdKKs2QDgh4gvX/rbe3RxoUQZ6pgTy5dwBDLvJyqKawAn7jpXmBo7TNkqpozHYFbbVgjWWnU+vqwL23HWp1OYH7a9IOU17/5YjzwDMlFMe592GTpkwRMNcnIsizu2MMWGD6Vd20rWWaT6/Yab4kcTzJFGtJ8TbL9lbKYM9JC6wpQvEZqMkiQUGNVcRzcG2jf0/mnNLv5F7qVB19tHzkfbKeK/v4ZIcoZwso5r2wwXs/VPlDlZIkMx9AlzbBd9Df3utpykyclSyp3LBFFGsBKUDw4Dprq/tZ3J8n06e8XVAKdSP3Rr166fHKuqXlAu0HmsuOv78/UhRg1/SoM/4/mOmduOweYRSbzf86mM0JAngyoKWatjXcXfGxEAjiRcNP5z5x9ski3vV/pv7sf/EuCbCe9y6JV91E8RV0yzurXAgZWPCkxDqId8Lpe+ndtZ7wmvjrs/TV9qLOE6/rwx1Gar+Phhp3TBr4a5BRhjSfmZsb1/7/F5UVMKS431xh06gUGVnZQkVG/js0Q/XdSwZidxfgYiZY4cJDYJBKDL+xwrPbbqChU1XAKejVr8kPfS6CeNm7+lWZE/T2KvLD0UajviwOJT5VI39eRxQd5k1tZgN5hdvHFwvjG1s+vphdP3Rk3oIXZZs7hYg3nXU6mxqYItgFXJQQ2Fjgj7VRzfJat38GNGaJO47uLURHK81bkctmwxrwFEf5J/AQWIZvNSWRh26xpGmcOHougnXQsMwCrnXUICtDvdjlFUe07y+4LuQvq2zSpy6yM6D2lkhCnYCviyU416pRZz8OrwPWHFXzF6+f0ffeHAaTRyTUWAn6Vg2dryRY8q+5u7RnUkvOK7B8OW+EOMSYOmTHLnDm3vhanK6KkWQt16ccIulqdyxlfTQa8KYIdiiFbd1qf1iI35/a1IziOchnmNfl0VBosyfADTGuq7WURJOk3f8gebM459ef4jJ4u/Djza3CYGQ6B20FoV167EBIHV+j5fTOqhtnhTopZ6yF4knxC0B77rx2d8+S8E6+pcPrHHd8kERcIH4KcrdweDLitLtw4G14pV9O+Ys0UP+dqNdoTKWSVt+Pr/8P3unTDGxxANEsruT4E2I5hIfCAXsf90qyUwYkFzfWAnO6Y7FeL5EplNGtFywGNnlfe7ehQT9b6tS9yvqTE/IRlBEdqaGcSTPi+XZg58AKNwMwtcDgNqKyVw9V8m/D8K7vCt9CbYK5ppLpPYcmQztMaQsVb+o4PPjKCBVW+4dsR4jIjIVYI9cHMwy+9clWIng0MSEYrqVPAOYNv1QZ+8aL90DqGuyRCxoX03Uvze1gs4qf/PvqRkh2Sw10M6f/diARI5TYf95bU2ipHnAEhrBr4UvfYCpFfz2XBaVmV9OfS3qYvFNeXTq/89sLEw72uShOH6f1Rnx986OL7f920xLvn36fD4mMoTB5qO1GuBju2x0v9UsaWQgKfZ0NdMmdX/r7EEi6zwvNg18HI3lI9sFTCgAFS+hp0vFBmjeGjydypf1ZkrbdZaXaw+L4KApSASHuTnvjTISQL14kALOmV6BPYJQjeHRc5JiwUxNeAel73hIIqFqj6SlVOFAo4Md/3ss7TJJh9+bQG+/+F4koO/kc3fXZrCRczJpr61ioKtW6HHgyOvSUgQq5BiKyCnNCLlrKvKjVNE8aDbGK1Iw/scxMjKo8Y25tDrs7jq/sW6/5nF8MyaRpk9mIlSmNFePA9uj60aolNWVbqordKcVVRi37mu+5yLR84dfKy6e9puupBahlBfP5JtnM7+xrHQswnM3ykB3iRxdg+HWsGGoIKG6DU502wwQo2N9ONuRCMPCxO+enJ6mkdMk6UvgyHKEaVT/TQzJne8YUqfn4XZOlA/KfI7y0z22CWWcoWf4yiuFLlBku02kAP0kaIwIH0qaZ/JNG+hblopMp7NYym54VLeqH7Vd+8LueMJlQdsgjyZRyHZ6GqCZSdRRBVQEJtG9ip3nVKH6P+61/Mpe960zIbYMH8PeMAMScSPaDpzzrmmzrspyIpqtJqxV8xn+KBOn0Ju879/NOS29BvsLHJNK5D9KKkHozu9SCeMIYDrmPjvmld3UEFdfziUDmauS5SskvLwbVof9VdZuN2zDsFI+NN+XG8hGh7j/NolY2VvwTcjBiGeaBkUBPpt9xO2M7MUNtciA2REDTHYbqNXTM9zoqvwPRsrD5tNxMcz9eW2ezRfbTi+8Y8XUJih3sB7PM+7vK/sjk2QzXYv29KAjGzEeyA1fg802H6Dxut+fk7OLxcsWjTAOik6cI2YBlSX7oKQEvBJ8ahMo4uLycSD3DnNjQusTTn1K0rCwgcQHvb8cYdfIsYgDOrG1/L7YgypQB1afA3Y0w3A1pqcXC/zEdr/O4eB2y4FSzwQ/h7lwPZjCwKwqA4jBuE5Io0f8ktUNMxKBJimXr3VyLJhbSxnYcRJiEpimOGFtRvk90QidIugV4GRgCkOL05lSVNRhRVAriv6aKPFwAInKKfw7OTPnUPiVbocenxs/Df0lQxY67zuOsS+h8dP8F0Na/iW07B7dIJyCgkMcRgj5fDRwy4LV1oavomN0bNMoeuMdSP51w2yZC08P0VANqU9JHFbL5KjIPyjIZOQrnkqRJUv0akF4Pyji1tRJqrncsehveU9/VNtuJUIG/owzTXnQ0AyAJ2RrFhctEC1hok84MAxQGr27eCns+7NGstQuyszpPay6Y2DN6FT3UhCNnk3SsgDVnvrXE3lUSoN7QwT8rX4e4STfxL88JE0phKA6b7uUMvW2+RaZfEHsEtxXVHRTODltTqW5ebYhA9wYP92uxMUXy6RxtetGaRKL1rDXHKu5NhxEchEz36LJqR6ihlmganV0X6FnNqKrciAV40Lq8JHcEK5yDfxBBRGx0FTb17cTNrW75cF3GpqNoXv7QO2Qhlsynl+3i6lrxkPDnZWhzoY7FQdwoirsx4hDYYTQBmg8flI3IrKy85vblzSQjODMlpBbJryKef73Da+rcj9kLwBqgtNnsART9wPRWItO6t+LWrHT2hp1OwgCsfQT9fjtdON/nheI/SBlpKKP+o9gFPaBqH5H94aRFGw2s46XMyhHuNX7lSDyRk4WPdZPTawWgHceSARDt+zfNu5vjZwwsRcne/BxREu+qIlxhiVV4SsogMosBErtMgV+TERNIM/WsSxCAhTyETkkZJs4l6G2k0eSjvAOEsKs7LONroei8+SZnY0QFipTh0uEf8QG2QBtrQCrrW7C/htHMkkHJG0qLVyM9Ebzz2/AlKTchfAN17INJACdASekRBOyZjsE5DeJSZGKXOzM6XWhgVpTOU8ukUg03XvPQlEfaGsp/j00j4UMlWHe7aqzO1e3rQaVsspiLFqrA7cagJShugX8LkIuvNHl2geAMvomIQIyMywm8Cxk2OWFHQSCuFuWr3UlL5yGYrJnfbzTcLNRgHTzpc5e2EX5Si/rrq+LArnQlVeawwo+6G4vMr3kNDUmAz+58NaiSvGZ1i6zdhzzzz1ONxduDXRKWy2XxDKi8KUuQ81gkByiNuqudmSeaL2zEIYuqCkFUyfC7ZEbVfEoaRhPuTDQuaqniOoLELRC1ZfMrw+hvZV3AWSkkoSZAc4kSgn1swSn2hSjFbvO2OB+quWhYuCu/yCYlr2z8hXV6XBXEuo+okq6NTb47wcevuHAz5VDLzENWN6MlwN94C7TJDB07pmVY5cw6+hIexCLtVzwXrjfB+Ts7y4O1RQbvSiPtFPOQgAAAA=",
	marrow: "data:image/webp;base64,UklGRuoRAABXRUJQVlA4IN4RAAAwRACdASqQAJAAPnEskUYkoqGhM1SduJAOCUAY7T2LT9WfzfnIXVuvCIraPpM2/vmq82n09/4N5y/HD9L4T+W743JjcHtSDun/geuL+47+/kvqI+z98HAD85Xp5Telj+gB+g/WF/1f/Z5yPrn2Cv51/dv+j2L/3V9kL9uHcRnLlYUV/6rjHy+9ftHH2X4rd8upbGt/LI9lZ5Pcq7KT+S+1Q/X7npP5ywzeNLzU4BhIgFeNJu+ULf4VeMK7Y8kxDhaW8/kizuhSh89aJ3PYHP9+XtAfOuyfK2Cq6Zfc/dFj4bXpEagtv245VyFsODcj9TTPvdNfBbw4eoOKsm5/ip7NThB5dQI1MHmelMznawXtzoClVQFhrWWAjB6jfCI7Drcd9M4E68z1VdasV7BXPku9k0THQtD6yxh9EezTP+tzuKc6hSyi+O6hmC7rz5VjFzsDOIREwfjh3UjSFjSrmZxDMivnrJAPKLXELqfeeOsePlrnkqYgqYuv/+GUIAQd2WR8kbl95EKoEoGlZcyG5G3aa3sBgKdMznuo2ZvuQHU5qVjIUBWKGbFvTJbREPR2tfdhMX3KO2nJQzqipMohJsAdcN2cBIr3QJ1SbTEGwjLrR03WOr6YKegCS/eFj3P8x6DpEK8SBB4dGCxeJbNSoNGs7ln3lqk0tQdRjq0ol89WPJvlVFxqMCP1A6FWAi9UfbipBrjikFdgNU6fYsocJh6VrKuyuG0vlCu2gAD+/lXQd988MZ/znzBRNNOmf7/spgzaYd1+m1BH/DHIXD0lxK7qSA/ulou2XYx623GvlN57fb2BPHY/CgNcmgasCxp828Dgl6GgaUBu0LzGY5IuvELwCa3PAHUA/BSH4P7ItH/2Icz/FRr5+C1drY/S3JhPxPVouatnv2szlWuuln7GdMJjNIBKPw8vV5EP15bgvxoi2jpLlZu0lMVXF8VNOZxxP7hF4JLmsS9PcxglzHYDGzCoysXMHU4/EQ6MUFqf9bkykERzv7WPF5i+MFUrL/5B5Xt5lG5h13/g3FrR1rw2rdk8K5BjS0TglTAobnFtlXHJr5J6/RjhNom0WLeQtkstOgC3nonMpCYpXkktnbnFqs+gS/DqS+SGffe4IAfbjfB7j52lN8RvzqKr695BdI3Pjfsn8hr5HDrm1YtqTGzbViw3xIt2km+wT0AzjfBT0hRXNP+71WRATD8efTf9mv/3bX+nu6e59lI88++Ac2QVIrDmuKETegGQBEDzzLl50jqta7egnK3qwuDqMbD5RpNkqJqjzOsthosVkqihths8M2xuAgtcCOfg4v6M0/f20LndCoKrx2k8n3+lqHZYupf51/hoAbxXDkLxbNQBlDga6fSDMFtiaBiN4clUa38qxtsT2JD8wA/ms727KbRvPIL2iuc9H+LnijuTlnCRBEMsscVysojJdtchVu+ZkESeTIwwpSWIFkdTGU5BQPAdg0b77kEEv4nBd2JUJwup7c281oeI8fvVv8xe8gOBRgw6wdqXMfn4sdH/RjEAknCNyNBGyOubd8dJqJkcTsMdMyr75mSqFB2qU2Ny2NjkV9o7tOe4DoSryEsNoe0RU8B9LH6Mfoz2DrDZbckW0lhDe0QTQFcREvpbhv7nNJ4M/XR8WwIB3JshfQwog0V8XbOZLaK1E6dgeNZuULaL3p7UdWVEwW+0j8DizTQfrLj4w1u60dzaxPnHxBDvrWhG+EpKQ1xNmeWuHVFuYCutTTucKEXAQBYZEPalRU+sMB7sTKiyGIdfufSNPW0llH4BQHnY82+CcDG0pjk1voBwoHEMnfGd4OzPjTFUM0G7FhzyQ2/EL/sHc8vKv7dlz1OOguOdNklo3jdQB01OkMz4QYE9N/eIEFuYjXDQzlvQ7rAPYTctz/I+QVSTGdeysLJnouV7mKUV10LXjjLugjjbYodZHdgCHumV8SElmayhwWZa6TYgs87yNYcxbaXikv0c+ej8kpBykqx5vrdrO/zkys1FU6w2F6UzIvWHHD5cfzZ6dsmwU5cSogpEyFQ3nQ7Lrtr7k3Nw0X3FbMLlYhzq8Xlosf2C9jaZWBr4mMdNFbGDJeS2y2KZLQ/TjhDGkC/WfJmNouTjfPrfttTl20WqI8FqTHwLS0Kh2375MEchHmHfCeLEZTWu7sxghZR6zChCeSqo9T700B92IxWgZ1crjOoB8OnJGdIOtFWO62jwnsJMVqRxfLFpnVprOuNUhTgoz+Com8OFxfsixFjk8w3E6u3zrx9SrLAE6xeQFCEPAfEQhu3EHsbqWRxtQljFA7kl6gLjybAW6nHNQAzn354zwAH3sr14FW8uvSW5NhxYI/bjCJJnnS9j1l6qx0BpG6bUf9mSbcz7zjvvZ51aA/M+vU7NZzayZIh7qHwH6U8eSpNhQf+5bgWfmWmOds0i+g8cL82HDho3y1Nd/A/0xk+6eqMd05YARyxC/B157FlmEqt2TrsQt+AZz/QyvftVqudcZqmnK5M95vwyU65mINSVLs4TuT3oFXZXLY+7HyX1R1spUYtQ9DRnFUw0E6hQ8IJ/+W1c4GYJ0vZRzdCIeW2kFydWH3ChCQQN2nrmZE2dzqnZ5nZt9NusmqZ0b15XsBWdke8L37oDpexqHqdR3XQzRDnAc8lEHkNU4t9+tVI9+pCPem2XvbJvxsnJyyroyL4fKgPhvb+IoTckdFDZ+Gf8BmnvlcdG3YBsKU/5NgiKlpfWwdaDYzhng/lUmK0frZp/j5ptKJ36m7BCBl+DunD0rclccE/6/kqkKhSQsJAAj6v0W71C17ySRI6FI8wyq+gWo1hM5BncwHuFXoyHoe2wY5LOu0fPctz6/QzPPpZm6CJOusKfipNLEtP7NXvIE9h2Zf26/Jktco6ztPnKwaaywgeqSdIXYnGP160cyqYn8FXL9MBc6czDpFUG3hyAiL6NeY3EHwPr/ZRJyIj4RY8xhoZveBnqdsqlHRMn//Xjcy4CK5whdrxJoe6U7yYQQVL0JQCMssLeC7lleQxuUmC+Yfi5DXs8t3zVbCIrlfXKx19ncEvmrxgY0nQMmMxyD/qAlbS2vxhLonQWMdCVTZBStJT6aDBWXg8hXWYmVNWn/ktpPtSFXypeZS7mDZAxruRRlGR3PVBk6+Kxi3tNksFMplZbZpPau2lU2baB/uToDB+Q6zACUe7Rg29Bh5kn19UZ4+zGK6or7YgxSZfcckGpk0oEOvQOsA16NRwTaZ+l3SMsjoOt2N2A1FNocaNHjyY25Yx7Y0Crx9H8IIWplInW1CtYIpOhG0B3DygyUhOfpqQcwI/K8IMUAK8DQLOUBjxTAGvBJKx3Q56EIRjW+cseVUdGhYrIJk//V+ZBHkjOwcW+sTkYSgZhtPfgzwc9RfSfWNK0JYwz7FgyY34SUE9l4L5/QyIjnS5Vt9FQP5VbcKiCCOVoOMmR3KRSeSqvlFzDC54EWt4scqAxEM8b92PwxXsFRA9MpRio5vhjitf3JKNxuen+PFKGUz/cyXO935cqanf2magYi26SpLSuwyiDYIGa3KKOv9K53UF6Kp0qq0MisTgA0dKjUbDQQf2N9zYInXTVmNx9OBSJfeBRKsZswjhIp+GTrPl2JtL7mVTsQce1FMYz5ar0udEPGfy3E6mTCSkXl6nOC1aKrgzR2uB++CTA6w51kso1KQATtvp+OHdu7PH6M9XBBNVrjum2J+QiKzYAmAvy7PMJ8wK1klQuK4ueZMjhiJ0/31sMmlkAP2xSi+ux9ncso03/bh6gT4/SddOhiiFh1SOMaTWp2k0rhuLGySDce4MGbkS5dKtgLQNp+a3O+0VAD0dKo13gemtVQgiP8buxbr8afIIdYPe6sj6brEjODCsQ+wCtjJ8yQBBaBQgjZ7stiicDnXwEv3clXZsDwXM+q5cDkvqghMvfBLse1tUg0w2pUUCm/AaPuWEpSTNmOvdesbjHTaXqwBUhnimM0MyjKdJhxFL4X7+R5osJ9m1v3R0no/hZsiBWllp8TUMNnBFQ5xavdcWwJPE1GQq/L5TLqi1sQ8XRj8P9H5m43McfsMyQFfOFzZyRR+19cvMfTtn8W4UcQmeGj6RXRizQA+Ap6nT3QDMnTANhG7GXfvG2cpdwze57A/U5LQcpXwoB9jEe6xCBqXilI0IjzBnfqZ7eONF0J4kgh1nXVp/0Y4IsHHE5nAIJ2eiDvqtKRXy284ZXSyIjWp4P/SHAM1/IWnPeKRmzYuP7UgoD5rPyWny2hov0XzSOPVmIrmRU3yEvrmju06/+acYc6Gwt1p6VcvuOFtTiw+7TUBocJKcP3ACmNy8LZ6mwBqCY+nmudoHplDBVWXJOIE7bpPsPzBZ6YWU1iFa0M8a07UvuSylnxdW12lnANil7fO14RqeossV6Az0PAJX+v4Mlva50P5eJQSDc1tvgbRkBpxyQIzsrfmbMo5bUeA17nVEb1FbV3xE6CZlqePD6XOaSyOS+KoFwNTGlu0JGawRAd4XDrkcMhBbK5I6lGtnFFF5mEWjjO4xKBEe/QajyxQ6k984PqSxceDEHuEm4j5x7hD3XyiFvqxWu3WMSBRodnTUqpAMA2rfa6w0k3UmepKtqlZf4XlC+RvRcBmz+DkuLRWcJWS1jeWzDIumYU5ghxD9uMOpfCeh0VojuPhDhiE8Am4tMgPjOaFhmm3m192gXPnQPKVfET99UJfn3CoytoxoqsTd/wLvuENpB5WZKvuLOqxIETsKuegQZDSDAHPK3/yj2l/Nvzfo/PDdPRlm2ZilpNnSXhPh1pRBpJKGKHT40lESkWrw//0J+j2mXqdenX2eD9U/XKKbKeQZITkcgj2xjC25dsdqGeHQoDXighRQy6SsstPex0Tbnx3l5wk/IcQLQ9yEXTmYDEHAfn5HO+c2Dab9fpR643jZ1OJ8cIGVC56yQ/Lfxt6b48fwcCTfqA1876PyzPcR51AlbQLIn4OX0/0F8lkTFQoWZ4Hw0lv+Hy4lWk+wwsQ8XJf4jjHCi/0njZyynj72icHTb2SB59YMHaRBnbx4V9jhg7wgxtGO8Y/32iiuMwTeUuA88NrBTipLG4JeZwTPSFxxL07LPwwYxUxRroUUMos2YdlVkL07XRpXw2Kr6ml41VWlJBOdP0RzC22A6qdBEh3Alj67VJBSA4KwfEa1/11bWbs/F+YlXqH0yK+0IXrFkSFLj3bpjWxF6O/9JCBsQl921GV56MKUCm7p+yN+4ZUCQ6wEbRf7HnSluCL2vd8npNUEBt3Qz8vipN9fagkuJuVR8JqGOmCiepcYti7MZa/lOyv5WOB9ydPrOVe+OVh+hLeNYGfrgc2p7b3c88aelUlR/QlcS64ribbL8UApN9MlNmJTHqJx4cxPpk8FxdY/dcDSKxYyA5tQC5C12+txUs3E9t2ApKSzks1/9Qwjk1Vq0duODKHPONVsJU53ceVyF6THcGuANoxgjwhq8qP8Qa254hPgvNPt6PX1b9LaSNXKpqGw5HUnoh7a5ji72322DmqAyR6gCns/vg0AsyixYHeTXyfaxtuf/0gfYCz+bgh+I+aNM4z/IfdJQiuyspugHL5PbAJQwndWZlio5izXMySEqdq2Of889sdCJ/4CKU5ckegbVvf8tAJYG7yvG/kXtLbM65/LMN6wAGtZFJaump5WYLVrz4r/H22zh2Lz8fyJ1NxA2UiEA1tRo6t7gjHX8ma/21GBUegnQMs/0WZ1uFRSpXCjOFFcr0k/Llx5bE2dVuQLDRz7kIQj4uHFHn3+VJGIdvh4fEhq6/nAY6XnTc5/Ck6KKhuul1eN+Qi7UsCednsvBKOaM+0vKcAaZvAeJ5r32oJmCRC4/6r2jfyTurRcPnpcrBWLMEwXPINUt+Ix424YIXc8jC48CtfOxvObggti8UfbAXyLX9MvaviJFftG3k0oARw6CZdQE7u3hJKu+s+KWfetMbzPRoNznvJp8oljPOPgr0P5JJUb+QeUwofikaLTKStV2hfrYFJHg6ni+HBPkGaOYqPzwRDlMjuvlcGD4M6w5NJBivTXBUI+igZm55m0hMgPuZR4lFx5/Dyj6fu5Lt+ubUcacvOKEzZXoyRXj/p3rwADJz3kEAAAAAA==",
	mulmesh: "data:image/webp;base64,UklGRoYXAABXRUJQVlA4IHoXAACQTwCdASqQAJAAPmkojkYkIqEhONgriIANCUAYR4rCJ5VPLvdoEu74fY9JO3k8zHnJdDp1XfoV9MV5QGC7b1PwXgf49/gH7t+5fsZ4f+uv/R9Av5p+Fv4X+B9q/8d/1PA/5QagX5T/U/9lvcoA/rr/0/Sx+w8z/tD7AX61/8n2C75L1f2Av6L/lf+p/jvZp/9P9j6Cf2D/Z/tf8BX9B/vf/Z9dr2Y/vL7Lv7ZO07wIRsaOQrafxOcsLnKqpccvPy9zrmeCm4Sd+PV3fkwYNh+F/T/NsVYTJxwqNPjeck+O1Bizsw6zp5J1UU/cSKM2ZkkB2IRx3mFZwu2kuamTaDjhYqKTEzSxfGWv/oTF02YBr8na/7nR173Lm3k+hyMMBCgaHMUQoPSKuAxtBrSi7YUHjcPIecmRVLI/9xk4TR/f0Kl0b0SzI5+kqlfh0okybZcclU15ojM3/JcIjA3o/pfTMoo+FcJ98PdXvbFTOclKhmYDV7WI6MK8e0MZtVuAMOJuoE+L4B37fPAEb3vvgJoWEY+TmJ1A4r6ppY7nBKYJuyFhC4VMLKn6+6/1fVMcZ5zq+Rf9qPRvBCv21oa0+06UoH7D/v80FS1n7vOhg2VDYIQQ92a3u2Ccfj6mYuTDARejr/TeCA+sKHE9eApIAAuUTU+lIf9SvFQwxqj/pmlppYt1KBCpKTwKc32RcpYDuZWtbmEVu0dlOJ4HmjzMbHgvZv0ykSWqdWP8LtdhXJJjPZX0zmUAxrwCtIKsAs4ijKGcDJU3fWGjPnRLaG/lwg90G5/qnxL4emCazStbsRU//aDdxtfcB62iXUxYjxdmUiAeq7fJ51YMPAPT9Kft3I23imULsQAA/v5V0C4S+qPf/i25b6rHHuP6Pyo/4FO/3kcGxwsArDwwIoY07bTedZ9lCdEBFKWXk//+/J51GPF7SkNNkqRUx4Tfx+qF2SHuFmwRhnc9fzGArTMi4+1Fz3bvF4aDt1Fihgo1NnQuhQ03UK9qA4tj9xMP05I4LCxBWfL6Hoim1RGf8MnkhYgP1l5enzqK2Ffm4gtL+vbOLQXKGcwyovGHMDbE429ljCcw4pR560nXJkWyggiN1lVdFQCbfNZ1i//+ov83q+BBOiktKi3tyDsLcfrybv2H0LPN7sDYxqatYOpWM9Qf0PgFntMG/ipkexpYgGWKj+SSq64j2QZeuF8lLHmjlvzPBF7STLAvBX2/BwdScVRTgRuJlmkCA42DPeyxJ4IdGyPYZVuo6q2WnmzVUBUrlWn+41qr1QCn77ZKSPTdbJ5ILzerCaen5tB3Hr6Qpj+Et/SEfgeap+YonaTJEr10f7Ts8GD+znDNKbIJylLfJjdzdY0Dd3X3Xd6wXTVy8pn9bTQUiUV39itUHl2+I6BVlbpY7WcwtrGh0FiVlFHD/hi1LivjZy1LAhzqvFPbxl447E54/pf/0xv4qf+f/fp6v57E87Mo3k0OP/cT8QOCf+h58R0KcWvy6bLi04GbTVSxTni6/gUJ7ZDtE5VVoixVx4vLAozvag8ZbIVYvZnnUo8Zi/x4mj+RS29EAlx0TW/+BxvZEOvoFlhH07DtORzhjbp7jEoD/4BuB5/CEx2OIq8BfZi4OlijXA0JUzxxFrdJYJ9TQPhVnRlAGf2WqSVFfmS0QuuWVPORCPKjn5R3Lsxzdyvfre7/QIm6Czsc/KWslFm/QRT4Ko0gMoWBoTmQNHscEy7d+F6yQUEu5WTpnelHdtbClIUZ6yv1YE1UdDZVlyjxg3wZrD9FJ8poY4z6DiHCWw4ajuiJDuokdx7GgMxj1OI/mDi29tgL7L/KLG1lAHU2ntqh2D8Y5QBzOFVc2TGiOHkbI+oKfEI7n0hS3ubicHYD5IPENJS3OfV32tD9s0Dt74rpI61wYBx9wh8QP/dWggtcidLzb6oVSDVloEj0fswYCpviUh5HQOQWBqdCZsDK0xrAX4D5lZYd4nva7Rp2wAMwL+yo8jrvPB1Wj+1nNrFONR3fbGUBRoxmmBBlvQ06Mb9/td5+cTOw8Z2k94xEiAnLf36dsbXvBWZeldeXztG/yB6uACKb98sMIfKPlHDHjKDhHp1x+9ISAmJyb+pVFZSTSSTPuhp8Buvt8eggFpzHr5xSToxBWtNZlM8HS+ZPPOazPlSE9zkU5f1HcfJk8Ob0Sb4oDzpf9a4LCs0EmV0rDWQnElYGabjVooA0yvUKLFk83qpXjJkdbFXS9USdy/RT/2BmSWhlI7mQoP9eWB1ezLt95UjPThlxsWtCGC8EgT1NX7hLZi1b+GQEiWoFLElOLUT8KtaUPIZihtL8iTr0lI2SPru4gVcVGQjfqxd/NSq0ZyZ63Ue1T1W6bAYCwejtGiyKDYSAhgrqtf6kAfAhGuBGHHdbW32/Czveu+w85UGELH3MLTmks1KcfJZAMNULdnw5pOZN9x3uiDpALQ1PSDDAfbapY62BPlKfnRZY+VQnghjayY0zp9Uesdd/iA9hp2f0KE2WJ+DU11fnr/11moLSEvc+UQ9u3pF63BpZ1aLvCXmqbIrFXPefyRNZJV480okVhGiELibCK/9kbY80/VjxT9+ZjaHx3nOrvwHDvMcy2tsIbsnknGr0tYdSmwFRzPKSYvg/bS+fL4MXbYde9FrqRAoW7lJ+/7BibXOEtXeR/kBKcSn5hA2LYdI/P/uJQ7UNn4NzRJ1QHxm3Gp8RSgO6cyfOOylbzXU+/WSHxyLqSYr3lwUlgv7wjp0PG6HoiKh9ZFdYPRlZPk/prfWunzcrtRxAzK9Wi/2z0IEERCCnR16ynaasMVdRnLEAmbLtvoQQo7giIw6zEZj8TjmkstQ6tFG9ASlgffTUq8ToXbPGkgdrICCcSTYwH9L8E6mXpnVoS0cAhBL3odW1xVjRh7GqGPIwsEcs29B+Yz1qejQRNZDAEcmjmnNdMP/yLBvQ5CSG6DXA67t7Zp1diTHNFQwE2B45QMh003mK9XC3B3M6JKqhe/JzL9ADPGFM7j0cln2pcvKl2ooX4DkPctaZhAaT6btCaN4rjdYwzZHVEzcMdW9WdKnoK35hBsOGIh5cjFBhKlAs+r1Vo4W69AZJo6RlbL0HmLExb8kgjV6CefNPCCkfpDMpoIya5YRRlO9ni7V6/yKhmFw8K692nZeQ3wUyYxsvmWdte3m+x5rO1K5ZDujs0m8Zk/MObfzXuGDCA7g1yphyxe5JIQ66au3F1/exHDNo6/NCTjs9pWC+isB39fc3r3xVPUqaUtD9msS2tDaiHGap8S5ruYWd07Q9QHqqg3zVMFeQ44wV4vFJH0N0NUb6cud5mRfkjeOi6kzHMFYdXjJdGlvpKi+s7uxgJXYWUZ2wNoGtx7WGJJQymbM7kU0QnOVSDeIvesDBBdQp+cSgaKj5BnT7jOCBHuaV440t/sSdIx10pXDbezv1//7SKrpcvjNV4RroAAOMVzqg48f4JnnfEPV4am1Sp1A/n9Hbp89T/r/lMJyXNeejwhLOb1FAV5qvpX2OEERnbOpa4LB/Ty82zq744fg8wLWRXioW2lzN6RsmjMlWy2449d9pDJXL7q2p4lKHhW+81vn5B39uZ0GJ+jzZvPTarcrkr9ViFYF9jQY0fiiBEvunXjqOpiD9PMfAQG/Qy/LZbiR2HtgRkaT8TYqZb1IS8ponRcuQbSAcADRhJTOXRoyJ9nKuy5eDjuDiwmzMA42qwCbpOuETlR9x6ncARGnEP5rlsJ7xT3IHvZ9KB/05Hd+Q8B5MpG7l4NO0HSv3npWMHQo8FY3XZjgsJpL35Nhyu5CXAOI8K/kOfFcy2BvkAPMCt/rnLNlQCNnngV5Slutem5uyMC43IhwZLJVDwmwc3cfQcySUKMiqOPwSugRuH7kiZAQGnRFki/gmHSbvUAIDYU47QvXP55bhn+y4nFTBhoHGgmqoJy1uM4xIbNvAtghS/ZGCf2cXo62pomT0ZrxXWopHJDxvaH92oUskNYGca1vwbWjFcLYceoXOP7zfziqLsFqTRD3w9GfCQkfIoIe8r+oBg7AFgn4Pa9Kmmkq6XJ/e68YRmam/FBXheOm8Z3ZNuTDpUdu6ft2sdpgXyGdOKnKV7olHx9ZmaN9kChTw0qwQLtPDWy+EPAyKs7qsJTjwdUQ1BYHIkG2ZId81Hr2jFkcISwgoH2Yxxe7yocA3NvO/76lvswS7+9zAnteDfR8MPpZKgQ8PYWLxXylIStUYBznFOo5ecY+LBMlIbddOOBxajgzGV9Scw01TsaIl/excqR8HDRLCac3va2D07QEah6LDi1h/pv6l7qa0i7BK1USgJYeoCztzHVM5H9S1pfXIVBoHwvJaNN9MSZl5hCXcwhi0oGF+Rr5qU0f/ATD05B1C0ISJk8Yyo3PPVA2ARifbDGUyyAuoO8KsuozzIxSsK2odcwGOIIW9d2Z8cCcWvNh/84qC9y4jUN2VDaVPY7f1XYp3wWCJKYbegZtjqd8iLzxZINmyo20coUB8UApMzLBBwG7z2SbhRzYI/sBhgduc/gW2YZadWqN8rAowVrI/DwA8M2eYDRPENLWaUVBUnoACo2t40B4e1D5dKUjjguWRquRhSqMV5WboWOgKjCIy8a1gzuQuSaLzFb9Vb92hYsh4FW2bKpNiR2bAqXd/mHeTOubMXf09YKWR1X7pfxN9Mum0u9rjriSh94ntG3EAg5d6RTOb4GKDMOIOGyqzAIj9wSpSxnFBaZJgoCa7t0YtreAjZt41tMo1zjqiMDpcaECe/1nwOZF3fl6b4rYmKYucSeoHyiuXzqQgdafGgUOLxXgNGfJrGSyKZ+Cy6GcaCY/77BBM7OV1kF1V5UgfHeJ0Ac61W4tBxdl6Jv52HCFL11Yja63jNcw13YDfoiRwMuc9ChYL4xvztmEwAfE3P/IMdksoEwRswKYTsDDve+ktvVnnG8dXpyUdNy2BY6HLTPeMHUNJqhMzIyWdpKWvSYm942xaKicgWSpP/gLkzKAnA7A8DfudSNr8/UoSBx5DrpXZT75naGMEMt3hnTzc307U/nv8yVMnGYlUwOin9BIAjuvwhEbduw+X8VRdbsVAoTbD/z2hePVg4W7siFNodsmHTqfB4iNQ9v1VrLCslSf8qqdIHin1tU/t19lk46yYWl6Aammi1pgHvdsh9NlAW8BhutkW+sTc7stlSh1ZVK04McZusm1y5g4FRJ3SZ9Sb/7kW9eEyr6Dr+lEhWwwJ7aHc52aEzWu8WjRLQDNYg/2v4EUQmNnNFNYzx9KBuvrS20GXNKCcwB70wUg+8tFTl54sPHhFc68hZsVcY7AVVkFU8gluLYuVQJeSaTj8HLoosdH/9Wbo6j666W2BeM0Oq5pYKc4eE9puKyZyHURu8oVlJhGd9XICqv4mmUPaMmJuBv0AsZQSUPQ5/WUS3dAjhUi7IgU07bKmluJZtGmXd51gKfF2QRYcFwG98vZ3IwWfgijisx/TcEKmzrTfPqGfgEvXR2yWTZzVjK1gmNobn6AGzIVwdW4TRRwuxkq3gbWWo0M+4EXS1dvlyws0LOCDZXgJq9XBaQqdvzFqSuPWJtILxtmQjYJRKGWtkzGnSuY/toH9cdP23Q1l6F/EKqCJgr/ImeeER6I/g4+oT3ALqcobkEuqj/cCV9UORT41z7bQ/b7m3Dl4SpBD0MUM6iXa42fblpGnHMK3T91Wy7cll14BW9P02gG8bjmcyOLEf9Ma+HvRCZdlP++ztfIzStpEgLyG/I8/8woSeJvm/U50x3LGnFJhoWO4EjQZT+5rxke2mpF1f9NrytmWMXTYvbm8a4Ev0DRTHIVSRi0aBPcMs188vJA6Zuyox5EOaUG/ILdHrYu5KsA4mNipH6i3Iy11wJtyewtl27/WBVu2+8IQXq74UmD5EuKkFKgLdQTglwvaXwlUlvZ0uqUB9Bxjr358HqChyLIJR6np8pIkKTo3yl4lFxf8FWURwiVB8vWWrXpv1PqVjHTTFWRmby+UxlU5ZfgCKDeNaJePZlfRIt2tQ+UxKnn8xzY8mJfeQRL9yX7zo4O3g7g4vhv+BnoxKiSOdWiWToGGWLsIOO+mC6c7mU50d/D3HVWQAVMn0pcMDKkvMhXA1P8PfK+IamoLb7/aRVXccBVNYPmhDWmL1Ilp6i7ZGTD4pVQ3zwBW7hy8PKGBt2A41D+yWJFQpY5thsyhiY+7JpwMs56kU3+lmgMMYNCX0tn7391DrrnIqWP79mhwPuBbQWgk8b7egx1k7CnWg2vfrdJfuJytx+Ubh2MWkSmn2+aj1qGXsJaARWPUH3zNusUCE6Eid6x4kaqD9Xr2A3e5a2KbYT7JMSqmK2MnT5aDqrc8GvTkR1BGYVM4LwwkEg2tFtKRz/jLVeeNNIh11N/KedJuntrV8mA6GBK+fjMxEQ4vp1DO807GZ2ZW3uy8a/azXuXZruB/pUb/Pq8P5HaE6ee6mztSnKs+ghnnArIlOlvUeM+qGkDB23XRhQfwx4pC/K5oOaGEHrTOQL1viMLPF3909MU4QB7A4gQYC4qx4Y6DMqtap06IdLRnRWodjPEQybMFGXBmbq+4yiCbuTHj4yhcy3pn+d8DrZxe9C90uUIEzHNKlupeciZG0dlfX8DO7V94QAFFQPCvOMC/ZE25KEzuuKg7OkVWq6mnyJvkBCLXrueNtxGHloLUr0dbahcnMhVtqDPF3iaR9LqcPY1ibHgciflzJPsFGWiqQPW21L/ZiLNYiONh5GNwQzZxhpMGEQKB3VEiYDPGNGZg75nxPqi4Mt3D80z0IGdD7NmgL3iMqbnIH+8uGtVSbHC2+Z/B2rxe6NTO4bhX/2HrcIOHb5ZsoNL36ylFdIASY7HlHOubkfMnai8GFuyKdvgQF5xWt8wjk34Lf7p5lJSgrlgkxJl8N4npESE/Xtm/JoY+1ruQErzvn+pQxbqj/3ZlyvkgfguGHqE0AQZwutkJp97O8kwMGD6YuBvMCbb7/OHvxDD60iokn2ZP7y5kJMpfgHa4EXJ9l8WjKzu/RGi9E5695LMpm6uAAgmf2GcNTP99Do07nS3CqECcr+X8UcMz4f9QwL9iEJvdN0uouhQyQf8281HwoQprCVhKRpwJ/xU13Rul1kcgeXClpzz1ZjAj2qnz+m3aT4/YrHK+T4jWeEFV8rFxSJvjm8Dy95qnsd1S54ztyE03brMbMMmbMr7OwrSdFx0VrcWFmX2/HIwYJCF6udxXLM8K0JANqeFM+0adoXywERqsznMxV4wLD6PXdgZzaOfMmxjkQIbiKEl/3+p/wiQBnjhSGMVX837VBmI5FaKO1GSMCRGh1yWTxGBIcS2ynU7puba1618bcRaWGPyElv7E0lO+0mWew5GvgL69BSZXRECg0HoLf2zEz99AYKOtSssVUe1eE9RhKMu2n9XBJ+DN+SFwBeBD0JcdTpb1LAMonsuR/mu3PQ/xWDyzpVAAP5L40kGzuYjO+r84PiDpXHTN0YQ9v3Dc1/QwSnjIjY48n+fEKwNSVQhv+XgUhvGEBkijc4Kf/ba8Y1LRQ7+oZARFVa7YEtB4EvBvHSulRUOTdRRXf2PGuwvVkdCMFvkG9m0Hod2VrUqu+sbLpiW43235CsFoVAy8WgH0q+zVuGP/MEl/2aVPvFpHnHmG5H1sZW+XzaaKOd1XzYwDhvNqxOVyk+y+rhvGy2+1LUbxcPWFCfbVoCGJ3odPwMfGPqrNWdVlKl/3yn+WGZeFPXSxI7xpvFTH4lQk9YBkAlbaAHmZb34O516PFWeGPkXJWxS+iO0ak3pErfPpy5ICrrpi+KS9Xs9cvXt91oy/ZBgJ+Yj7wDBOYcSllxiPLgn5oK5XCYVI1U0MX1+L+IP4mMj+AJxWYCGUTIs/sDxg1drCg9Q9/Gdtm+XMTUK+DQ9F0ej6dHXR/8c+89xlXYxSgqgIxI0rMHCPs/4n4NX5/yvNx75Q4qmzwQGoAkdTedyc67NCs3tnm1+afa9ARrcWD4PyOgmDSP4XlT9cM9q+x9DDloyrwmYAFoY4ZZAAAAAA",
	nom: "data:image/webp;base64,UklGRv4RAABXRUJQVlA4IPIRAABQQwCdASqQAJAAPnUukkYkoqGhMJQ8GJAOiWIAycIm3F6L/rvOBu7cjkXdu2dH0j7frzKecB6Y/8T6QHU77ztaVGhHhP5fPivuByZ4kfdX+79enZ/wDvYP+s/r37g8MWAH64/8j06Jt2QBwmdAP9B+kD/3ec7629gj+df3D/r/m73vf3D9mX9jXGyF2vaSRZ/VI8Aey2Kf5cIO1zBuoJn7m2B9uhSWXBLWooI062bndIMuXJLHsRgHrx+0IDQo/twmU6IAsshwvd/Dz7uD2mGSi5Pj9XM7aO4/hVbzhQ+pNOIbfk79aG/UFSssZsd5tV2ifhT25DyBq7Iy4nl+WfOonz0SGXnh/FhPQDBCuEsfzaaiarM4fv/aP1u4ZRBRRI0N1RQ7cbiCylnRa/s6wkr1BEHNhdqx4etIeiLLz8gB4IRiV28b/sNVl/fmldC2JWkoxLw7iNAwjght5iJeXT7sb8anaQ0lcsV88dkJ0f6XR3UVJngpjQHbQRzaVCbNjnZFi6XIpZIupJM4yHlZXhPSCHJGmet7DDhnbo6/AJoyG3wy+XxPLgh0Y0aQl/J4mcx8lrSX4XNbEuv3XZRjKw6knxm34ZDu9ep5EgRRD0JTQcoG8dAu5r8dMtlASr84RlLm7LflLsTOYklO7mv3WEUriBNstabQFZOVJbMsgVmeOfZrf20h2GP9+RQArxdgp1V4sl76wZj450gLJzB+q++JNVxgAP7+VdBh+VchsL0y5SgPqSu+byjTDbsWV0nSkpVHd9ED8Hknj/urlFjcBHmyesDFf9zMlaib/PtpAlXh2o/kBviRtmHbIc/UYDYG9D6Q6bXsYYFHTYb4FFihZVa/HSghZj/nPfk/T+iKqVZwVHgjIft2QyXK/Me69vO9FCvdir55WZNg1Q5gIPiOfUsbX8nUXm2HxJFp6WFvWqVDAhyf/UZSXn5Lyz+fuhzAH4KTDKDNU3dRKZ3Ial/8UZbFozvpzp5iYv1bmXnbaeXsX8pAfwHHT8J60E9Z1/9Krcho8Y8gd3gLq3CyP6dHWc1nPUAKZCo8uo8BOFfrh53f9oIrdY3uB6EfSiDH32Wcu9tQB044fqnurg5Bh5ryALIM6bMDdcIHTJvYjmoBcTaMzQ/l3FavPiG3uyAJIHzPlBMg+fx4scS7Ti23laa3/Zr/+CB8rSXjtoeGu9jejj39Y88uhXkV6MUsKrk7OnncDPEmpsf8TbnQTOluStn6twmSEV2hjvX41YPBLigk6PR5CqQvyNrkK+XfZkXMeSbVOMQKywp+ya/DtStoWOW6RFhjiitAMLEkDh4K6vdsG+uCof1/x6AJI12tVILYh6+Rqh3PahpY1seewvk22/Zhk5Cskn9qGHJADfwpyJUaD40g8EazyrCU2pPgxfe/ebrYFeHJMnF47P0MwAWt2JsoWqyCdce/iauWvZITugQlsufr5G76GRgv8oKr8kFrDgS4QYpAS+DaBm+UMx6xvJkaQ330jv8lPJBNEfgA0oxaclnK8XgTosHflIWrNegyOswW2rpAqB6CaDDnYR5401i91qCLY41+UzdfRnBsjHuauH2J6skun4kqioPnPjGrjyFXRSRtx8aZh3SciFuWeJ9hRG3znLA568Fqq5tgKEi2H94vgglP27aaAInrKHduiC7PMxQJ/q0xhL2ZhIzzxb5/Z7pmznxeTz0uxKrv0zHPTjRAtX9BbpJHyaQ7CcDTOe44P5KnKIIXQPVERVX3qFeShz1hGE6iidU7vyKQUuqny6dPlJD/IfyRBCry09o398fwiG8bjWYsJmdsbYpInxINTvM6jNdmqNaRRWoEHmpnsdIQoSJvtivSP7BWi8tRYvbRu5YKIN4GRXBDg4E5zrQutr5/iJKt3f2hoL2DP3U2L5zqOC1E39vY+UvrxViiYW55s1ZVyIUNQS4XUFFnvOgjlm6+c/6OqNcywiOaH5FYEjcogY8zWqWbmkyk3UPMzpIlyiNqnMrSpg5QyOidgVbL6oWVYHqGUAt0maQt1Ml8APe0gnlja4Fy+YMvVaHgml5OKluLajU+7+Zy99cAQWMeYC64csmm5creukezWiHjHre7vzgK+I9zim/wToiYz9hGJ6VIAQj8FyxIEPqZsXYBUdGqFVdmwLhWhQ1CLYZQRFyCioQcrMlku6Bw7y8Jy+TM4L7P4PVjrfICejnd35WE5alGzsTrUVQZhS08vcnsSCkrjGFCrJCepcrQ466Q7BI1Ughw1yiHUvwoUBE8tl2sCexO2qZ5qZef8esL0IwsvVuGmqlXTfsLuH5IZ1jQSIcACry9wibi9YkPM5hUuUexqw85keWkdqbhKqt9CoFYRE1zlVA7j6cvYfYtxG1/Y5uZvk05xcC700U0a3EoiFz1MWPJ64xbdc7veJktnGIeYczqkny1DW1nKCwUtRzfQGgbXv48qX+iUSRgJ5XGL5qUyd3jJB6Q8cchEPT74ZJTpoxe/HkDGXY19DW1/jLt5Em9iopyaFqViJtNDtf4IEhG9k3oqR3R3m356b466qb5vts64h3EcuxLqpyMA5kxCHEyzMBN+DYb9SW2JWYVQb466jpUtCqaEOlkPDXfREnE88CPvG+Gxywpx97I5Yn0gVklPQfu2Pxlb6mGX8K/6oIKB62a75WvN8X3QL2ZA/xmoEewr+eJEpUb6+pJUnJUPbzwSLn6fOw1192HW28EjyRl9TDvDv8WkYFObqjRqBSxqIG7UO3eLZmGYSo9x8KZKYJTW5a6PGuAAdnXJ8LUXaeucBr0EZ5vf6dBx9KqHs3ASt5dBxQe9N/ALSy3w50ynMfxs+m1vNALQB9ILC9cAMo0O3NfRzT5MmUsGovEpu0f+h2E7kXEqy0v8P5CW9sfORLTPzIcOZHarx2lIrxQbUhR4n4JX8Rz7fQo59Fql4rsCWicGcP4W6pFcd2RKAHVUuf213lG7QqVsFq3157o1qIs0rcdkp4SRIughgJHsOAme6mAIT5Hya2k4HE0dTG5EcubepSkRbKft6pVNZon5s8wX3zc83nUF5633o1Gyz65A+VkWKVzKHRuPa0HyKc2NIi9Ukpt0se/DdPGzABjZXu/bQKnsiIUglhLPhXN0sywEk7qmcWQB9Eao6joLdf25PAlLQzR/fiEsJ/mJC0m64HWrtzxdoNiyRCUcPct8nSTtSOKXSHw3hRJX4g7ZVG5zzGFXnIL+IXt7SsmsOn5u9vsfg7VU+MTWHnb2GcrBGYb357p633wSLcns/Wpgg8PdO1Nmf80OECz3YtTp8glvzciGHJ6j9gmB/3Dmt0HkjfTfWvYThOv2qDHEZcfI+o9zwsXvxm8A0RYeAnRK3RQJMhyvDfcsaX4/AfVbZQjfrcx3SGoXbep3tBsRa5bx9toYrFvFDjG+wh9/loeIQU9NUgqPa71gNm7gNBDXSRXc7gdpm4jyS9gJiwv4mAwJ7gobiMUh86DQ3ZEQ5cO9RGW0iaaK45/8irYy5sBRrn7uQQ0aEsPQQ2HbE5TX0Aef7wycr9zmJKgrVrctJUY8BXJIcNqGNk+CHWtDlx1ITjl0qj6OnXzo4yaQNDDOsCtn7cdeWgmST5NcqmlsuwAV9EdB62aPeifFhhUJJBzMW41gq/B1GowcOFu9tCkzSbWeD982OwN4BPvCbGCods4d3PqBgiqOvjhKWruJSynWFQ6993EJGo8sDulILZ5npzB7VYyn/+gv7otcDFi+dL/rQv2olFEOdbUBNVvmP4G2tJKLo6yIs9WaWMo7F3JXQwwS/ukvO3YYIOgKZ6s/9tvQrosTJH/fGeJEBFTNOpXdqB9WPv4HRy/JjQ4nL6xKG2XyuJEdW2J0A+ru/UPN1ICFVtQU0KCCDCfjemCG1mCNYtX3icOoYYawV3rBg5+BltpjvyCp58zqtyqmcSYTxWFUwn/NQ7iGqAFu4IMm8sngQxbdUkXqPZPW+2V+IInDNXp/sSOsqR/aWf9xLIV34y9IQ589sq2b6SpJTfZ5u7AiDlm/5on6n3Agp9vlH6undvjYjs7G6tdcziONf+748+3q6L/UIFnM658NezX6ldvqYbej7N/ibbJC15AnzZCZCAThjHzooP1yW7cDWG5TfjyuodCE3GvHi9IAOfwxUfRKUkE37ynm2p/KJJIlWTyWJ0s0T2oWcekPE7xPncY2nCj+f4m45JvW5OnZTMRq8VJTzVFfgy/LbV1O1yiaxe/hPNVNpKHlPyKBFUY804/moLme5arNVP43DemBQuB/Mq/OlVFaT/u1C3gY7jACAGv2VS2dH0zjwewuu3aM+IkDnw1Zqn6aG5HtfWGhZxOMOVSk2vAesHNc6EQ7jYUUJp7hHm0Hm7sJy/Bjvff8sSRP4tIE+olSASPeoZ/EHF17/+B+70wbY1RJ3HVpUAPrwBzfNw5K7PgxIHCdUoepL9VDiMG6RYtPaGq3DP16RZTLofh2C4TYY9RcIoZ333G7rrfKQbnimtHNyoMBnCIlh/x6IyOuPUck7/Rl8f3rgMQgwqtqvJKWwPSNkdjehYNdleplnu47o8C70+/5X/69ydEMKMCoookNpMA+ONy/4N+Zw1YP3VaMy4xhpTJlb37UBRvSfKVK849SrmOmb7vVSRZCo55zjxnMZQ2eXmu/wu/SIunNUua6AyowTwh3oHEgvKM3aRGdQ/jp4TNZ6tk9rw9rR+l/0PM5//vmE7yQoyVEHDop1E7ObVZynxLfIKv9yqz10bLDe3JFMslpzRlDIvMa1L+C0tblTDFi0k9h2rjo0AL4qP+d5C2AsrOpF07kYf9Zg/WpKEjhi1oDnK56GGh4LCCEozBs7Y4qhepqjkyEKMf9M7YfnhwxnKVQIoLdJ75jSdh5Tr8IZZJwt5FHap0W1mfbqXj3YZvtx7t3av9JjNhuApVrGpJLmn3NhoUGHQl32xpfsEapFJamvhO1fJV34M4J9R654xNqcFLwuNwdSjnRAJKwaRDwAeBcd5IK3gtwuSyfaXo23P24FEbi1N5o9A66HJrHPbJM5QoVWVDbqf8xLFza84Q8tJBmgHqIQeXmfhdkG5sNL3Xj/qcrydUCL1zM2FK5bV6596Oo+NGs8fStpd59/88enC2eoBi+gTZ5kvM0MHWKVObX/3rZuap+A70czmOB61SEFixQrbfGSCN0uyYgnaIu2g/33jsbK5MiqDRdVFOCXp23WpHgAjlYyieT4oGghJC21F+p9N2TlBkXxqBas137bD0NfNjKJHwNEkAeUnkQnAahMrEZyiCMv4Lyc7ghq7zgklfwsJCvRlmG8brIbDCv3YDRNSV4V8TWAAU2jeaDmQ/Or0EiN/KczUo0OgXwVVMF/yDYYcxEjPuWNp8XgGW6aIiS8t7nBQ2yXTdWcj389fAr4t2g8EzgBUDHL58nNYF40+lnLxiaRgCGEgubXkUkGLi1nsnQWNHiCLx9qu5TKfzdWFc/adGg447FF2Djpb23TE9Sk6RsZ7lif3Rdj1pXVktbKQoaUZ033lApjM8vhPufLQPHXtVS7LPbMkkBXjKBOBfQHdT7+eeSzhGjTN3uzDM+Zg2YOt/7Yhd7t0xwYPL64MxOiH/gfHqlf2uGmjeNPF3y/4iA42npGpkOaB9wqFNkA7PyWqpucwNfg6ye+go6lcZcfOOktrHobA9Mn6pVn1/hy2nhJ4QcX0BAF7/gFcVaiRRg5nJ0XuAAcN8waB7+upuSSS6zvTrlmI6i35K2T2GVmJAfHgzqG22ixJqqaw5RcUSevkVyHrzX68XC8/xQPqeB1yyyXV4huaS1UJRmo9wxT91bPciYUziDhzpI4TVEGx3/zO/HJGqnQT+zJPR4+YGX34ErBHTo7kT/lH+pigwvC0+6bCCC4/0+nbvDZZt0e29hNZYw1BhFUTXnDeFywZmts3u1RoHLqCGGkm5R4EGxDeBE1FvU0YvxckwlW9kvqwo30Qi+t1cRUWWrqh8cMvMEaY96zacD5FW7DtFTPw0HpWTIXwEkewaPtpCsISzILN8mJc7ZqR+J+lpI0WZfirbZ8sPwkjyBOFE3kutO73xTfnlOTbHHrCrmxtGNxgYby9fRhdn56b/c0ryLVavEKmb2ureHZMUeLzmnlQMfU4z9IoRfzsx6AB1+7gZZwAAAAAA",
	orcgrunt: "data:image/webp;base64,UklGRoAOAABXRUJQVlA4IHQOAABQOwCdASqQAHAAPnUyk0ckoqGhKjZtYJAOiWlbClz+TxeKX6fwV8m3yqQQcR9mkgnKn5g6gvsve/BcP1HWVlLcyagN+lP1t9pnRJ9iewh+wH/O9eD2i+jmhYrC+6YXHkjqf3N7AziHz+ACDRBXUKIK9EKx1o4+wZiRWNtG5NzM2NX7AvnCuO06Brmk877jPsyhzMpdK4iZBpGnNU0Yuhos5YLmfFm7WbU9fiey3O3ogXmgqB9dlmqG943kxb+l/USYXfnIgi8cn/gdznkC996CZP0CviRRSVRjFSoTOITOv35LTtMM1VugsXAyOF//YMS6tKG/UCIIjEJ9kWksh3WPqdDkn3mbiCzPUCrk0BWUPtH97nCOrNfofv5EMm9a1Q4eA6DMwZ1dkQvUVdPMqxiRcixQqSEHoeG/Sit35iB+ZbRTwUM7Qmo3TbnEJpotNBKLdK2aDYrBa2ZcxfUUlS0LEUnrSVut1Tf+bGfJpjcF7Yjuw2MXArzkRIAivb0I7yYscSQ73c/fc0R6EwYYsohr6kR+Fi8vDDNSJDVpI7cbz4FSpueKcAdpyP5lswnV3PoLKcuF1Qhak457qQ7vLQSB0qiGA+bMpx6YiIKZqgTylICt+huiLADvKG0HPHnO6kG8DMAA/vfh5i8+WfxC0P2+ZmXq7/qEZTkJeyd8FuIGlBlZv/9HXNAvxREiIhM1J2lCnGoVIqT5/moc/8KyShON8nB6xH64r/xkqt/dTQ/G+dDeyBndVHPZFK4sfzJaOEv8v4blDD5A6yf/3K7M/BxODH78WeyXbFFK2LG7dr5VDcHR+A7WDnGthaEjYdSuTqb3oZGhiK+UMOs26rfbvKzt25Dfw8aXdkAUiJA/CcRy1ZG79ccAB2cidIL74m93pvgtbmPA16bh9qY83gWdjEB1uZgH1SF3PjiBmNZyH69FQ0bdRkv6Voaca819mMYeHKtyjtwWNUFeoQHzFdbrUFrhY0zOLbSYubmwyexf+abJ53ggVNKkn66PexlVqP7tL7hFBbUB+NDA9g77EaWk/gUpMwZvmJEHXJXBIsninSjEZidggeQZXzmwAlx+1gDKogB9F5gQKXR9eWVQFUTAupTLiKPT1yaEGcNAZoY9b/Pc639v/i8sH4yoF7dq063Su60X57oazKJYYvAJP6utnBbp32xWh/7/8CTE7XtHVeWvRe1jZdw2VHg6UOZEsD0X/R9/dm1vTngAiyXcpV5eeb/Tn42G3ORlVEbVqeNaZW/RJidc2Mz6pbXX+ndtHYEbyQaI9tnmz3R4xzBPRlSF9bNKyOcBo6P7RU/kQqgwcuOZI5d7N4XIFQWUgHsZgaVHs2tCVTDAzkDCSD5rmeJDFVe3jaZ3gPtR9tEwjpkUZDgkNJuww8FuiVgi8PuFufyBnnROkmP5pFS/A6blGHzlWM+HoWrtrvalGWQ8dd0YsunENXO50UUVkDwE3NiU9ENp5/Al0tAzptrl0v60UVfRMeMMpAIYp3e3zR+69xxlZajWiweKdl6TjM4yr4b0FE+P+6MLb2jfR8AWcwMT1d0bvMFq+08IkFZkSsM+YISE816NT/3ccUJZMSPUNSRiAKle1mM6Vk499lc1UiI0UqJAR2JuVyPr6NJqdE2lOwxhIulg5yGxuVJlf044fKOUi0f81RAvg1+Pa8ChOyxkB7cNv8uXPLKQOIW+yKc6wuRtCQ+Rj1A7jL6cpszRw05vjggjg+fhw73+u2Udj6ZTcID5NFCnso+pPsWr9Gvp+zp6HO3aGTEvWRFM+DVsGV5LptVtDzkEzKUme8Ax6JrAyU1YlDBMgzBDS/CWCwgcEpLF6VWClZlxZnzdAg0FRmtMg+RQLioUJxKstnXnvZAWbteXleHGU+p4SAJxR7N2wDvJW8P1KdatBeBLZ/RW7qU/0hU8wv1Co6WxIOULqcyroLvnOv5izppsOC+jDB4utUs5sXDx230FrfOBYQdDSs9msIN6ud48n8dvGaNYCpD+aWx185LrlRNVgtg/CdCHYVsTmdOM1jjKMKVa+2JzjaJRKkF8td2FCJfxzVj2+fBAdYEAarQrYgK957EuZkEV54s3ZpID92t1B+NIz2964e6wa25+kI+CPIVBOltCbu5y7dyZZih1Zf85lzwI13opwv/ddXG8+YIZrnxC0aNC8EXyDxAGqpXyv4LmfA/n6EYvJAbJ8ecMDuq7YzrnPYOch5CQfxoY7LnN1cIFz5f7TQSkDA+mksu+p7Dn/r3pBLHs9Lm6WVqQZ/+CpG3qvAH4q0VObejWe9S6/GReExYOG+uOd8GgE//s/zHheVvaSFCK/SpUJCW2EgYrrlRDJ2XGhhklHT+ODocK7p3IvsHI2C70GkB0F/qGYUKF97umQZHCCvrxD9T1C9/6wLaboUfj/HxvTMRv4o/3S3z/9yO1xaQEDYtZfOQvaKbMY8Kq2gDsxc2wFwFXy+Z+mnkebAFy5aXyG5PGDF3c73411PFRfduutQos7/5MML9aZrKKYZXrOpbLrHh12/1w7t9XU/uagb69p8y89ftmps+D90CKRWg0EDrRqqhb1cEw0oMCGaN3sACuJvyvyL3Rr46fqfBXZl/KgvhIObqSRQtH7nGcL9blD+QjvaRK2oPrV0aN/5LP5NHAExeNjOWvqTaunM/yCq3fv23tRn8Sf1LmeWJtk82L11+UO29WOdNXCEEDatcOPoeIQsr0MHsiiUq2NHCZG2BXPlDCiEFZ9HmY7Qn9GmG+dnpX2vYK8Bgpb6eGW6EbbPJugXsmGMvcB1hs4VETngYZ1jeZ0QvkzUj+2hGxn3ebYFigTO12rbYjHz+d0XcytGdb2RcOjiJdpjDJP7Bw3jz/obkjwU+cCX2mu1DNYCgDmSkkfvA4mQ6VkWs00wFTfNPpuyevmSTx92n8vjGDaQ6JtZNDQzya34n4bVxPFRN88/E3PITB2nZUtiEGqrq8qyU+SJr/eUP98F2TZ+qa9ZnOvPe5dQRm6eLMLSlrjZMLxJ/uokotZuf0AWEPhNGXABYaX4XmnFjebQVrV2K1jkdt8sjXOwsBKcrhb4gYe88wm16K9UavRls86Xm9nuNvuXjCGzgIx2/rEKjkMJatBiwJ4tHxJeBRswwRYB/izz1g6hzTksgDMDK8xfd3Q3RGrIKOfJYqwnSYtoKfSR3KrPJPwPBGsV2NqLnWHu67z9R+AQ7PfO4SWczWjL2Qi5AkdnmHnJtcPLowbDIsLs3LAJQo0faLqNKU8ku61Hv+3+cNKFNinLSLhiuSecZ/NUQLNLDzwI1ImjG8Vkqxj9Ad3EyD6qT2y9nfRIpe+rL5WR8+jnSpRMLrGbOKwVdU41skGcE3r0UTJJcBlsZZtKJ3un8F1USJ8ibvRNt86lNXqjw4P1Yru/bGduW9TkvZNlg+bS1y6Ym2VkZKW5eyxQM+V3I0ZLZIvMMuPeefBWc/hh5057DLd3ENameuQq+MmK8RMaUInTm4nDOiUirVkh/DJe5mOmdISutSGP7elJqdPySQQI74a3mwiCJDRUSuE8LX8+Zen2e685a+gmgxX230UMDXb22oWhkUDtVH94mLuqJ8O0rvo290YNoFlru32ugepZmhFMVbLhXWSxZ9v6xx5IvBfZxzKeD9fZTDqQ3IT4xW2zsSX1El8YIWGxSPupT/GIQa1LapiwUq7UMAo0tqD7umBdB0SobA6fDsOfwyqOG9hA/X4WIBmaFrZUCsAdTVFjgEdYOKEu6nPkUOtRvE0eUFSjLe9l8w7DWeFH+6Qvr3bI/bKe5mRK906QJ6gjor5poQ80afTdaUV6/3rfSfL3Pbnf4b+9/Yzpz01XrfkgWouJYfpPFiDZVUkn6Ewbw5DTsIYhHFLfSNTHuRjuVCuTzGKHBU8mBbWqqTHsnbUDwNQNUNf/CRPLwBsgt+VKpXEACry/yb0k8I2j1D5/b9HJhpa7qDJWDk3pmUp9KkEsQIWls4YNXix1ueGV9s4jcA3E9O/7xo14sWXMYR/zt6XisS3GaGaccFoEPywP+tlupTOmJobigGc65ilokMFVfc5bGtj2E6nzZP3MFvfhMHZO/fMw9VlhTtIzir4jZ6xEGgr8xZyDn8aDuLl1ORp0IyLXur4ch9HJP2Nh+D+S11VkLoIVdQX28uVzSOB+fP6GouNlbj1ALrcxNLe6JJKWI96OFEMnXfYiVg9qRnah+JHvsalcsmMnQJwWNAV4anCzWCNrBGIdXjpjGfSIX/l8IT6eI4CPpR7O1gq2Vyuc8VOcJEkIw9Q3bsYjMaw2wabZl0t4SfFz4RGmSa82ZRrRKAQq4MPSvVbZLGAlfpZ2KImW//7j6Yszp3ha9aAonOU4zq+8fJdbKSEjSMFqPKWdZSBmBWCjrCYQF8Jd9S3hc+xAM8gcac0LUeTlZ5JAu2/9GUpWkiq72Z/VLg1iH+HQC8q3c6170dIBj+EanIeymD3++NQQejGsHDzh2WWNtNEEyzaW4PB4ZcQWcIUp+RRqjlK6Fm+GpRrjPk9Kwqd4slyfyeJ/HzyAG3WXdWLEv/Qe+5OZWrKnN50bvXZPka793PBliORCLgC8CXz1VIdADyikYNYdkemZ8D7EVx1xlXvUfaGccufuLGsXllhBGfRAMNgv53z7ZnFDw+zxtA3erQtXtf6QrGq5xwoVo+rnuZmHq4J8qpqmcmRHWADr7e1ElRcdLmH9Ba6HRDocqBETbEJ03bUS89l917BFBuk7r40FR+CaWP6D9+iFS4cR/l5pkKIooyQge2ddNpPGOPuJdBGeCy3tioBrMt8P+I/6kmJonJn17WE1WaDODOWNMH1wI2ol2L1WH4DSSquI+odFiYXfQqKzDljfhypRF/Znev6LT9XKPL9iTgVrzUIzlvRdYXDNjMI7O0EJJmJ9x8MQtx66AU8H9kX65+fgYFH4T9OufeCzgJLqBYSAAA",
	orcpeon: "data:image/webp;base64,UklGRsANAABXRUJQVlA4ILQNAAAwOACdASqQAHAAPnUwk0ckoqGhKzUdoJAOiWkA0VIgDeS8UdkTaReCvl8+lyGbiftrnc/uu/ngEPF7QvAbwj5BvBOw9+wvYP6avoo/rsDgy5+UbB+YekseEk+NuiHQpfr8dqbNlHKu0gjMf9b3Zvb86PneckoDQE+CWt+sy3XOHKGQSNrgE6CTwowX9ZVjtwt0cmLiepbX0/3PbZOkZhA5hVKzuVtMm74zBP1hhmL3rpBNhBe/p5P245hn5n++UwXxAbqpvQ8CQ+GO4aS4wiEkyCsFq27/RQw2plw39MMLVkoMRDoz94ePZjAATGIHIhF5EUElPnQ8VJ4sFpsedpDXFg/flpc0bKWnxHcHtlDNxxYBH6+AM1slMV9e2pQoQOcke5rA6aV9jzejpbaMCeHfnNVoa7Ch2PiMea+wz1kKHSSZJ6D6IRNUMezj5pYoDR8R5ZnKOJBlp4Ztv1NjqM0GmI+2n/EIjPgJ+98qJCGawBNJxuC/1FwC6s/Q9EXkE1ncBmqttEFRLbiNknl5bqyHg4XuXWk5WIE+f2jU3Bv0rs1YCejhrneAQkaLdL5YrvoDtPomwY9rqqJ/feR5WGe8XMt3e9xLAgdUAAD+96HBeBtsvbb5DGR14uRZC8vHGT/MQ/F2NavrLuybd/zX/YC8n9gJ2BxeI57amFeF7U9e7fDDJy9kTeGbzTyoLdAdQ84lKN1B+zbg8rAAZ2t1n/FUy9wIhYd8qZe8OOnjqcTd+4KfVcDzl85j73eVPHyDEIvsLPH8NZ+I8jmzkmjOrcLkOhFHzHsJ7qv+nllagFaWW30RBqAZRrJBlv4XmwwmwB6OMsA016b/QV5vPMYZNPUM/Ax6DOCpii9JOtJyXw0X2AT5aSEM1um1OxcdEcDqeX9eZZBJ2ruvAhCvaPam8RXWwnSjKWgosvTS8MqZBcjTgLep7+2pO4AWN/kffixqvbqHVJwlHscVOII7caZTW66DmCWiwIdJj38hyJ8fNfxlT+OiR+O1T1w9eczTBpalY0LOa8tPk2GtBI7uQ1Kkp/AyiEL81MqS5lMFHbUJJXnodTjQW1WSM/5O8FddDNt9wVQ9I5T5V/o5vHZBMYYKCgFgMIFeL77aa0L5H/sX/BN7/lvPfae4PU12ihYJSeqv9foOb4RxVGnmJM+8rxwSOD/E/fptuoNN+Gj+aJ8QKn4Gf4XbVaz70uSEAVF8ueseyI9VCAjPdpoJPAfH5e7vcOZ8YVQIf1FDYuWkqfIbLRBEws/09i68AAcipTe9kRn/7y5fq9BfGRofA4i6GaonnDoq7W5tpPlH/inyZHl2Q27pT2FUAaR49XTRyTabStRzkWV/B1kBbTA6V+rLiMOhkWdD0YVFkC8FxgQz0bbPncIvY8cWzLZZ1f/e+vOFDbh2s3WWpahqkVsVhdfdKlEbGMaGOfBX1PWcK5WxBUo21JjHUpESmC7/zGmslRd7cjVucUpq6lp9SRCqLTxaK2UEst9UjxsI2dF+BWy//Vrq30UUjGnWSimyru6t9oOYg6xIxxAGAD/JcgRvPWGsnlt0nbjpyUY+ypBeB9p6I6p8XIvTrOhBIcQQsmhPt1NOZgh+AX4Spwvn9uuSpOVwhE+QIVYm0qL/v/6yzZMqHOKf+7053asNn213ZzZywgLtK4pbdA+ux/v38Tfd5iJNOpjJySC+E1t3oq3Q6hE3Up7Xb//n/ol7HqAn5lw+ByyuCB39oQ6O8uhsUM+gR9G/4hpc12tlG269xeKx1GZvnWGFnGTZfCfHT+hH0b3XXtRim1uZcMHEVbsO/YyoX68G9l8IeQPoVknj557E/gkWmz9o7k64HzrS0sbya+4tVqHfJ9Nr/ww/XriDzzboVzxpzzifgHsBBZg0vhf2PevVpRyqeocCSaxM1Z5FhyGCzJiKVAHxKwLHnqVT9Tuz6BhTWmAs4bUrtRWEq4RX3OlAGfXfVZvuIUOFbU2bpQCF7n1jz1jO1Cd3wd8zu72bEt2HFI74TEzDMsxPjU6EJjdFIwZI0w/+StsDXLGfCwWb+EItSj7ucEtxZm4q7y+Rv4wgLIu/sYJ2EjPmW7wciZbx0+S1Zc3X3X8Gm5RDUo0tKc+IyI5RtQjywR0Wy6+cwIxkvlHJc/RKICclX1Dj246CuGHwFOHD3HSRMBSMY3anDQOeZKoFHF3S1Mu2X3R73vYNGmS94FoHZ0rV2R4kGEvNKzn+I/f6/Hb4wYP+xh6VZNTiw8f3AgfbGvPZDyYg43Y85tmQ2FubyO9nMo5fmZMP1k3hZI3ivTqXU6T3gEGOImNtv515Bm6s0rMGWeyvcdUX//EsEMz2O+ud4PmVJEO8b4tiPwKheHxiMt96/5wYEnlhTiFsKk7aIAgGIzv2OTJeMMsr1V7QyegQ7B4dSzVKG3hL73Yd7usKUp0S1tAoxsrbyk1X/bJbyq/0G37n8XZSgSfQoClztiyfsM8N7MDjnjgzhBN1aAFrIQDRBUxX00BcAB4ki9G6jL79dhh8YfU3Bjo9j5kGQhic6I9CprUX7aGjqeTOhqh+ziEEjJVoP/theHxasWVnv2VI+cZRaMlIvnepJAZaae+iAVKFImzzLus1/5LfIyMIA5C9DA6G6i9Y3QOYQVUbS9Fa0oJd3MWMuDoPmcFixw+bPvlh0dbIRLMEBGpQfXzk6suyzMU9uJx8Zn8FWQf0KVGeKAImC/rLB86SZC1clUYuM98fNaCCHRk/rSPVDW1jSx9aYZtH+j15GqPUx51zSbQ/xJhiksmCmGAlJKNc9fHCaldCuPUUSDG48b/jDVqoZemsB32UdI+w4ZXsph97/qGoKTeW3rnGQE1wOhzCAnz6AEIYWgeV55h++ILDtr/mJUr0vo/GW9Fu/3fn0TfF3hHEDdWSQrM7XJRoWfI3qrG5CYzjZF+9w9NLScK8/wOBaIqzt58rXyJSrwKRoV3FPq1wISzCKTL/45JoZi+NSur3As/KAT3q9axiKViIkVatGDffN2TX0Be1MZwe0YRvM6xtKearFoiOZnpKuv0O2sQfJFZSe5jLbA5Hh/KwcMOAI8RE4DgC8wdhBt0LhkRNIzop34xi4nSuvQrumms2DyZL1k4ocqxLFkhqtn5YHc0HZnq6Xf+mBAtcSkUtNmIu92BPVxPOP6v8bkF7QPLQT4Jn7Km8CcsOFmOeGuqMSWAHOpsEPVGbwcwTrv/vNIIyPE86jmG+AdxEcYetUbgvCPmweqNS6qmmtP1XwOnBnKriFiS6u2PtrdGCXE3VbTmLzhO4QXq3TnEnBmncCB+M+2rtSY2aHOLywe3eMzciy7GLY0OstvlYw5KQeupw6qnaGhn8dL9u0d+A4O/OdW1IyDCuCBduZOeOJWDl0FcJZv9mDB7Jl/AyP2YJeg+KdzW5YE2mm46qrRq/7ov2sEB6OnzZpSaAocGARE4B+MU7+dUPUIzLtYTKyC9vJrTJn5gG6eemGDNE8vc1zUH2Xxr/yAnXmjSIzIKHOonmDcSNIgWWkevvwAaI79XFAYiU0kINoSGkhWsosfL/4IwTaXUcK+KwyPZOgSBavzx8X38wEPQZ+8jW75kiAKTRwEcTIiTU61mqVQ82f+oy3WOCdBs0gXGEzjpisPn+KVAQggo64oCFX8LVY7kkNwEiv0E9rCSNvgQTd4KA8VjmZQZLVW6ZW/jhkvW+DKdug3qiGK3KI4FdBbZajRQT/8nT3dPLWIfbuRfMGP3yhcjjlE5QW1XcS2d/rxtKti4kHKjcClksQ0fyuyJk9ykK2A4FI7xA2n4Brkth0QLc2Lu0eIs0EIRhluaxmZ/VRanO/Xw255lGYxU1YKfdLU3LmO0kWHN/DTqdV66TzaSLy+bwu3yV83lh/o6mlhxSU9ZdIym2c8+2tyEVOWAyX3FEoBTGWVqpSJ7aE8XN0dJB3/n1s9wWqElJvlQOXvGAwtfSd/3Z+bkj3lrcC/R1MvBQYpr5RCxtv4oHga+Cq8h3hgLawIhELDG1jiWIKVJkLpm0nB4doXt1YaDsngiAsAeRUeAee/jV+CxSJpoVAUAXEJvmlBQXV3LY7x+GrMG4bP5/mZS9jx8VVYplEYinUnoGuPAXKB8n5yY9bqd5rkOG8WY8iQW5rQU+slqIEDM4pIFk/o3sd5rSKudJ7L8W/USNVeu0k/kFCGmxb2GtDaFPnQ2EXjueDk/i6qonyEyvLxoYvT0Ank+mn9VxUGYNZ4/g2f5AD9Y6YP5XsmEUmgrQhYQ/acWTTcKZcbviqdOTag9habTqCNvGzQz8PARAyUYegDgRhxZdtflPJtL7VK8+bEg238Rkujx4y8+KDbjBXHjINbl6Qg7RlHABDRJDpXeGA+aXOI/8C/9T4lhV00zlOG1kEWYKx4m55l1E+baCWQHBNluYNTKyUzVN8gVJMFVDaoJZSHkRpyxD1Sq/K2XhyK6Mz01kEDAgOw2RByL4Xnmh94btf6iynVVrp3bbePgTsUPpwfhpoV+kO9eCLjkSqvwx7GxW+Xgf2YMXN/frYp+V+rj7eWMdDyHUfJlFrHVbUwRANMHf7WZc8BkD37NAMTXdOmCa6sGDJ5LxnlaJ6aICEjTnScsM1/cUyUZCGvQzqa0jAeqzUc1wgPCkv55t7za7NhlJ+cpe4sqIMagst0PccbwPgTy2GFnKyGdPKBC2QBvne8C1kcnZAAAA",
	orcrager: "data:image/webp;base64,UklGRnYPAABXRUJQVlA4IGoPAADQPQCdASqQAHAAPnUwkkakoqGhLjN+KJAOiWkA0UuxLxw+7+Dfko+Pe5PISiI91/8z8rPy3+7n9R34/MrUC9l/6f8nffUgkac+gj7o/eP95+ZnvYzdL2jjT6BH6K9IrQw9bf+n3B/53/bP992QPSQT6g5R1jskD/2FiwAHdN8OdtugEBOJRXzGfYlaUyz9fi61pgN0b6haMo3cme+EHHKUx27/YJSHFikmnorn4E79Wt+DXX6f/KSGFJC/i8q/3h0OtqjdVwbmt5bfuF7u/jXSwmPwBpp2gb2LvHkyFDXgvPojUeckLU6wCcJLtbldO807Ufbe77AR6cFvToXmnzFhFKv4VRPveKrXY+4Nj9jfiMFIdz/afKLUY61bp1i6wCp+RNkEhWdFXj3XIotnVkIZzXQmTzIfTPkt+32a7QT7hT0Njl95Jz1mLiSgJe8QaLW+GYBOXX2zD6U2YTL7ArH3tyoJlLSkUL2dJ1wNlkCybaXOw1nzq0T2R+ThrkQaxv+sCQ8+IPDn2qxXRsBnOXpAO+ViH/fa1DUr9Di2UAX28WvxGpoP3gbAs8DaEasO0dg/59Ubw0qawgGIwoDiGjZz6wBzcFbn3eTPL6ZvhFFZbsxGRPRVziMN6HT4YC5Em2e2kXj643nDZzPfA2gw0R5QpEViCmIUAAD+/xIAwRoBdfI3cmEgot2y+fTZ85c70NJR57sXnDfikj1zsGFoZj7bfPBewXrDkTsbCob2cZ8Z0D7i58CaonYOfBWv4Zuu7VmIzsYPR99n+StwEcjZ+rQDb742TJze9ebDIy6njQaqfmrmaHWTcsxfWpSyiCLJcX8RP6j02t5u3//F7HixzB3IQxeKFe9CHsidGf7rIP+Wt0BWc8e/Zqz7UMOVEaBSP/JV2QjQl6P8rC/WNZblJPrL9jmxpyONCni+0Hh/DKLDJPTLE6NtaHIdrW21ctpzVP+tNQBu5SgEKZElv/ECdgmfS7WealxsdADbHuElxJ+bZb/7PcQppqw8D1amSZIX93gJAylxqzW3UvYeLMSzgyY7Vf/BP6TbpaWGzGC/1HPo3J+qMHZsp0hazrKr/1f/jt+cEJt1EEX3rQofPry76gW3TPqTyByN1eRfQTCWcQrBeeALHZdC9BBoO//uZu7x9bELorlyI3WTfT4uHQ42+Jtklj+/33TTO/Aj9lnz4r7rIEvfs6F8WknVHF3XTjer0dRo5G1CSOJuH+e3Wi7OiGWwwJ6/R9CsWJTiRX9Wpvuf/EFi+xZQ8FVzWOWjrKURDLe1IflukwwjpN+HCoP5z+XSdGumNGv/4L5VNa2y9CGgjv1zj1CbCHsoRrtUB7C3uZPx7FY0K7r9vz1RmtL/YI1osKEFjOJDscCHkyEgAfb5kXc1Kf4YwQyzsD9XZAwJxL9LjexNsAXF/Fx/NgR7eZlhUaVEYzsY/5j8M/jBgtyet+siGq9BrdllNV7HHmjwS1BaxQX9KBVm765UGiyEZJ6HX8iQwSzHiOYKQnPFEY96CM3qN50dhiwkpstIKx0VIr+KdIJOsMWUeKwqUiM6HNoSnvCPbRqAFBYGoKP7f71pfDRGEMRyXor/X/sZZXsoyp/1GQMMtYEQUqRT/9DpN05Sfr8Su9Ns8cjUcdrmck4B1gEOG0Y/EcLzTgGn92G/8qkVhc4qjgNmM6BH2S4fjumBGpQdOC9IoizTfvbIJ3Q4VqFolJ6hCVdNfplhepUXGDnOYytz74ASXCrnblZ20sUEBZIXOUhRqM3IXSHEzsPgTm9A01ZsSW/POruWACqXVq3D7l3wYdyztYHo+s3PVhn8jKEFQXxBt9oY5PH7YRGiOpdgaxJE6Eewg3giyrghx3pACxtsFH1yk+wzLR7Wy8we/DnTr7WMWgD3tWOnTr8Ey+hOfbEVN96mRz2d0Gh9sfPK9zuJ7wUlVRWnBH8Foy1kxS8vPIOOSntSYlx2ogWGxDuSDnNGw1WUOLiwhEu2lj3CE9lLj9ZBrcGaI3joaVkWqcrStv9PMwpWjboEMgNLzHrF1ODFF9/3EI46Lka5/n/yIt2hSs9hCk8NBlKM3QMKltoNb+FDUEXD4rF21vZ1m8CIqgGDuVYDlcP/xi/LWFMqPChn864iV9o6VnO4TPO1DPKWQOqJhN937zaoK35Ymk7sKrShZ1Ckhwh+e6eFd10JLjlspeBLd7jp/zP7tC3HL/PEADXZYvEl7aO94JMxjXP8Y5/cffuw142hGLBIe4KI5a64n4FLRWxKmRdyoZGMzGtlOzLaTWn11oKy4IrYiJLbBe443a7yKr6c/XnWkT8kHGTOvaYEyOLBcRFLWDc9FWWzBJVhD9HamHoMrQtlkJ8x0ES3gGzJNOZojH2tW1fkIzhViZ+StUrUJFMQOMbfIh3un6CTLOMVOyC8TRgNAIg6e4JoL+akiiG2PEfBP8TVFQlxvqMasLtbS2uc+bPfxETyEG4BOV3LqhiAOwcaQb/APJcUkpjLAuCZDgc8erI+FrI24XTbKYK32/cks+kUb3cmRq9M6lobCPmWc15SfKuK+8/qRhDU/ERm9Vj6Z8aDtAy/q40p+cxRD/bKuM1kVKeAFrJrBw/TxpDyMHRwL4CwZqMh3Eyw6mq69OUUZN02u4EWzLw1NWvxrHLUAm37ABu7aNyO2RyQxkFGjS6tFrohSy6+TLvE+feaVUZwa9j/YJKIhR5nbsSOWOP5J0csmSl9vuStc1sd5+m53HLynE7zKGbfE1BSh9YRGOz6ZnK0MWG3AbEaKtZ8QVEWyKDq1qDY+mGOIP0vjn4DaE5JFiKKrmqD9j7qoAm4K98JNNWVIO5/mX3AutgkV5NXhq7vRHmLy31PK5o+OpI2DO+sGKqA/1p3gJUz6OV859UXc9GF2eOWyT6C1LnQrk8qvY9CucOR7IzfYxz1AEl7WShGNdsLmwwTadXUeTm3VOJEAppOX059UlloXbVxwMRJrOKElJrcn/7NaOe3+zgX5T8S7q7BnSLalxeE9h3k/7PccNrkgrev51lGvnkYpjW6EQE/ymwq8w22porIuuUFRRwYmpvwDclN8nbT8SMWbk3/ZzElmPlIWV17KZw0vsW6JRWT+5AyoGEIOblSdW3bLB6Ee+tDZieuuAxYNcdfb8hYc71YafouDqH4eZt+vUuqPpm2QrMvwhI0/+xw75yMXpKsM+T+ILarNqlVsCGb+v0DuS0tm9aUJqXMv4bWNs9UXxRQGoNCcr1J8xo1ph3rPxhApdY6dITIEABizP16x9GR0PdoQ2Z8FpCKA2WyZ1+Mh3/VV1J/w87QUp/KMvbRZSwjYqbSkUiBgkmu7q7W6fnEp5iQ3RnSwrYM9JrBJVGFrIHkUN8vBbdl69yN6THi9yiDNYfdUx0gcKMz5PtxL2jS8xGR993SCVy0tE66fK7D/RwZWKznHCMbYjZW6CZ6e47fII5oVCuhQY4t7JM//X6Zv07B9ahYs7AsPsoK2q/JVI8GZynVypvJzIrESCTrm28+afMkY9ozF83okgUF1j7Mg+39P+bZqNfYOkH4xc7Y89n/WrjvJhqmR36iwCBKPktdacvih0bTHnpOBmEfKnnUjhu4MCYHvXkvbTjENNnyFnBm57w3iiMNcnX2yWEYhrpWPR5+QU8bdx6f95vs1YYUOiDLCbKXyLvCo2Bk2ReDxW9E12wvowNaAywDXHv5pHythxQrWYCMlTrGb6dhzg4uOhxymvWluuJl8eos7qiqBfbisFP36DbAYdfy/uwYePY1TkoWhF5I5jtV5Ka4tiN3gJOeRwAREFaXk/XHExeV5IAVlH3qwrvaIimBs4lhrmSy7DJXbSHKLzpWHmjrI87oj2cVQ/lQv0IoO5kJTaN0+TXtQ+6WTfAEcoVWyQjkXtahjz1nPVV5+R7Mvzi+xpX0qlFUGkWX3h6Iqc/GnsE0v0K2U+n7Cg6DUovyKqH4oOo1GePVTxy25VV5zhyNkMmCI0dRo8hgutKjYJlUh3lITev3/jh+rImMVVWcrri6xvRIi/8ksH4E+fK37O1CdS6I0KOcES54e7iexhWIJLD42B4MTUxSbN0rmP5ZSf+sLYNruaKSpsNmW5cjhfIHCQQuOqFz9VU3OtxQIL7hvP4ID1+ozd5LiA1HFXzc8FSuIbTOVrYGVMkU0yTGMZHOQqn9DC3F2AD/ic/wPUaqzrrq1ToRSh7okJP2g4oo5ivE8AmGxa0nRykR0hltYCe92jPC5bOA7a1xHBjVdTpu84tHL3k9e5RsSmKsuPll9p3QSmiMsa6YdjOkXNKK2lMsB5UJZNkowmVGF8CNU/le4GEZQ6rsX2Epqoxgx/ucaZXLyQnyBHKNl6shWSvmpJwtrlUtVemeJXjRalc9h1r2pBBodOFotgGIYKcepxgbrYMT813/3Z2fAXre8h08vS3K1J4r7zHpzwmrl9ayYKATBjXNNb6jVWsDfkaCh0QuI6OiUvWHPMsOIDn4JY06zt6ZyUnGg0vYHwQi3Hm1+C/bOTvYperM/hBzI/LyZrPG2b1BIbquqWfImI5Ac+Zra3IpNlxqnPYCnbM/jnk2RsVVuz1F1haJqCs/0K55WqZoCx9snhTkl14mEXOSgBdI20NLU8x6VakzEcNrst6GRh6Q0qWfYFjOItJrVCTvLflLqTUV09eeegpS+oFeHMlOXtz6gVS5nqQMml/lf4A1R2/KjHSGf7kzTCDrns9G/9eXi1cAOXMNloxI/8g9fzXLTbqbHGp+XeCHuWTWzWoq2cv/BsEkeWxcd8YE/p3Gz1chdAknG3qp0vY/SSRDcDY5KscbDk90xw40AAaVG1b5grjrmwE9+cFnxaw5h4SHsuT2rf5//9Garb1Pr4UgUvLwWLTp5OHanTNhgIhZYF6xFabzzm9Gx72xPk4M9HE1zKtaw2/hougcVGJi2lV/7vb2i1+kX9k2za3OWibXvzfqk/m3Zatx+4K3745EAmosCDdV0I11InT7VcYrz+yb9Lm+BF6Zhs1l+80A3rvgjbuaCCWkFL6HJLAM6dU8LPXoWsw9t7sRWNJuXgZ/Ld6uu0eiBiJ21kgYu3sN7VQGYwPa/nI6aR5YHYLI+MgH2CNSEt219zqalQlqKKk7wJ/4QOukoilgX5Tvg1zp6L1ohgHyKSqrHZXYH7QOffsvYCbWT0szJsDRNwdALM+EwhyQ1zlEywETs5jIX77331NfsS5mRqfn//2LOw4HE8s+9xSQdXjoq0ec4u2ojr+d5F3G4vyBf9XOUJmkvTiJeZSi7QbuT4AA",
	orcscout: "data:image/webp;base64,UklGRiYNAABXRUJQVlA4IBoNAACwNwCdASqQAHAAPnU0lUekoyIhJzJNYJAOiWkcMA7HG5Pvn/PeDfl8+fyR3DPUO7286f99398BF53aHdY/ozTnpU7M6oB+NLpM/aPUP/XXrf+jGb33A9MBukFbSh+XMcrppdLKbcymdDLASMJM+LwNAPnE7vwMX+Hmd/ms5tgjrU++JXVAUMsNA1nL8dTbKfbxQJD8AftTzYAPr87oCPKMCqGHuqOQJyFzNX+RJHirDFET5clEpGKotLU3mNn+kCUUbe/t8u2umsi600kXmbcOpTaFHVTRzMDWCA+jaoCoEi7hNqfAji+Nt4iR/cYgMO5159bndvMSYj6l1LK/CH44jQExz0OJkOiXpdQO+UTBgByOZmZa1hVw7s4bmykgBXZ6Kh6X2yirnsRGuiGlsKOHNY60qJq2ET3DP0V2t5A7Ut1tqScjvrVuOu/tjC5xqdJIRNko4vRk1Cj89sKobRppv+9R2V/pBq/tp5PHgWO8sAwHQygiCK6ueyEz4JFMaf7xfXv4k2tfb6ECyQGKsvhTsIjlxnOD8lHW4wCCod9JDp3ep0Gv3ZeIyZX7LmZDuPzkM+7btUD32ndpEWfsGSVyC3Iv9e/AAP72/83uZ9n+B7eMM480gP9/vIp41U1iHbsXTSyzT/7Zz3+Egeh4g1Kw/+e7t/8kBLuTvBL1Tn/Rz38FcXqm8Z/CfMfvr2fToXVP3Yy7mVG8jFlNUiIKT/ynP/PXHtQjBfI3ofxzYmz6/ThAJrgbSDGP5nX4zORkxevuR4zo8QOSletvgR1n258Dkf4PdfideRbVNczt6E8mMXSgiGEdhTeKlvrJlt2mEA+VrpiTWTxsXsxvJpcb5xhZy1GQrXoNo0bGiBhqViTVQ7Ttnmr4SQB1pZXF9kmGFsnzKeP+NaUf3y5Sc1xsgFHYS/8+CVxNWzCtv8rwUuMJ2Mc16L9fzgQt6/k+rbHr7qdwf8dqSLKQeQaHGSGSJwcR3sGrYSThD+ztIwiGzn76fDH+4QrTnOA0FrwgE2pCVRNiADphlJ+Dt3UXIV5ikuo7ekA0HlFn0HrHSZ7g+8WBvir3IwH6n+W0s5LC3GOt64MyehnIoRPb/+6q22dOwWUG/ac9rB6tA+eSmQ1lFzp/IRzxml7wUh4sy58P9PRoUJm+/CG2dO421C+59xgPS7OC76585JCZDR8KroNQLYaUsdMiyIRPOP7gEWfutjO25CqTIXdbsS4olHCAT1If3csrV4eQAOZzEoAgIsmTJkmATfKRZiD84DEld/W6gEwF1Fx80H30WNppwg5LdMLMgjRKwBqck7v2RZE6HsQ4vHsbNr43t1KfefdzwhSyke83FQP+tLj4yi+huQI7hs4m1TW71Ks3OKQ8ruAOXIpwBZ/N4PggEvegH4I1R/exf9EJq19ucMZPsP8BjnE8bQg7PLTjZy7KCY5D522/3rCZpbxwFJMaPUXfmkrih2H+c0Ab6rG3slosBgWZUV7D2L2oTazhTZFOg2WPanWJjgA0fTKCuhyPB2s9iYLZcFpfnS5SKLEgqmy8i8hkRQo+Q7yeAXPl8/T/Myjw0smYPLSBqJ1gYkWi7nxfQ11+VfeOsJuc/mIJy2/x48vid57EzABEkIejXKLHid9NlJ8jIFnrOO8hY+Ua+0FypPYi1E8OZS8YDHgsOu8ijZN5U8aJFw3P2uWO22OCykWYV9+sbK1GujEnVD7MSBwR3tbuZ5/91DL407a20/H5m33YMrp/W7q5UFRYzjt1eqTI2LpMUYmvZKYEw29sui/75dpnMMXrojiE1UidsK4xNZpyWf5GtmBdPW5Mr0m83gxjW7kcRxLFHj7MUrLB4rZ9/Z8eIjDmhLMMMML2UfmlNoAstX8ZdtOlfhEJII6pcfoBqaF5ctSc6RFnbzYWrQPyaUh4dpf1u4T1th8WTg5jgbNOSRnowomgV2+q0kIjcIHzMN/r6Se8ESDsrjRRwcB8rq0HqcqQsgZdYami1pCLWjRYk1EaneC5dkLsPV9FjASiKURZiclyfLDf/0WSWHj5ZPMQAv+vbXmQPahbH7YhemUKT55gIKdz/QfKpdCFsYn17oY/Z5hmRLNw4YV+M0EBfDF23swLCYReqKrpOCLsWBUCxJmh8a/v5bAF6cDlrY16ceebHFBX6kMo584Ye5BF62GfBsHkXtsg7tZ+QA/nYxykD7rkVoLUGUnZSwBs4gVxtDIbhZfAAhx2IeyI6k+KFiONDgX3LrqLwi5vhcZCVHRi0jgqk3DSjjV7cUMXJcT1WX2Uw2iwT7vk/84Zyw9Y5MWzfmsPsbOWMnxooPpRLytz8hb1b7QU27Rh5uJ8+rVJfP+MGfhlk4moDD03Kp7+4C8WYCzTFYH/ooxArdfo9DRWaw+h+zjzTLCkmFK7SwDVHHVTIKS0uaKtjkeUhRiqPCs8+n47Nh9+7GYcveQQ3IrhLJU3etEhBPFCePyVTT1pCzj9lyfI7R9wmGweBqwqHRyFm7lRjY8msStewZuelTL2dPdAtpcWxPY9GWtqnrYl8P8SvcZpCx86ClFzqQE5TrO62OcLrBi+rnHwMosq72HKSkJcqskSC8JhSugcLHocg4MwbZQieTlE2GErcZlcyacJNY9kxFqONV3R0IwaCeObB1xpncezQohqX7a3jPdbZ3Of9kbgdPWp1C85PFZ4esL9iDN0DhFJcclfWyQYYakeV40P+cD1836NKMkGoIKHVDBMSd9PqHOZmRXOi7uyRv3JIOZ+BMcyU2nwpuXa0kMpqBRpmDfPC8CDwL4+uhGqqGYFPCKNN1e8j4Mi2BDN8kZXWoYtajUHvDxH8conbo/LJq5BkWPOrUGxEETkzLAJNBgg28w1LV2XmuNKTXCcx+WP/NkMmawDKdU4HL2wM6od3bCCYqx+XW0sbkK77H/HPlC3hhRX+yBSQwYnARnCeC+1Jw2MKfi5Ze00qnVjufikbUwQ6rP05u3wcSgx27jgftUyPIPu2Ra9yPRbOnRVlv0sYzGF/Bv9Eas0hNv6UR7azNQfxGF4JiTHHql3cUjNtPQxkV/62cXMtNyVMWq6KLyjjJ1UkMsZn6l7VMRZUHCRsQi29+H56czTBtzQlqUGOuFXjN4N7Fr+uhPcvFMXAJ8qD5k3E8DpKvQqoR9xllraFKkaPGICupMoLWb8a9YAMhLrygz5Q0RtMfH2sa7eH9gaptdtfHWjrYbG+yJlT/yUrynoz28Ngij8+VRLhzP+08rx2jXi5iAU8ngNaZqKWWO1Ak/lW79ICQHKAlvGaOOxZtCU2xckKbdRnJvMt+UeNq+lTuFlBHolMceyKN4Y224ykECtAuYLX5tW4zRwK8XvDKQNi+2QiKh1RB5AEo3MfsxKTW0VLIrRGbsE7m+h3VIUsNXQWxRA29XxcICdf2iMGdeQAF9jQLDtgL+rZoP9VFFSepoMqXHV7hgXLlBHBEZiEOz9c7UsvSGDbU5qvg9u2hbq8SCNjfxNie6ZHlcDB7LzSB2DkM8VlA2ikU5m/uKGcuRskWTpNXGormyOeVyAJwP01fj11tCS+6FQ33X67Z3daz06Cd82iQc7yPDBdJ/2LCl/JwMy6V1biQb8MADbPqhP9rCMNfrrXotk1GvTokj0QD8urN+GGFKxitlYkhRxWEAoSzVEdkxlEqoyFgktHTVC+ZC+6I9hxYnoRhQ73LmBw8wIsPpagZoW5Dt66ewoOkXlU6TZcTqzsRQpg9BKkrLYHFmSJBa2AD9FabZvhDZNPA+HcC3xR09udOPauuYH9p5o9rZzpYms3X1/4Ax8zPA7DibFZTtvlzR5vSbcmmmI5b8356469FnK2UF+xfNSszN4dDCNUCQXdpexPJIRLxBX/+h/7hYA+llVqVVaFL1kmDCj3LmGfHEkgXQ+gQYPpy2/KPE4jK3pt+8oItzzvVSgr3ZsRs3qILdyo2OJQAXuJHLX1uYfQElQm72B+6JAGlIM/MOZ4N6z93skEVK8pgjZKWgpz//YHl27dO0iHh+WTN+L3RFxsOFU3V36tP/yVSBu+1GWWjKglSL+xjcbq3wZeNrGB2Ud5UhwezlJFvcNKnkVp0KYK9MvpA8WpBN+KCc2iU6neNRdMnv7InqDOwgjqXfqm0XEi1RVUtsnH7IvBKGWZF+4NDhOnydO4FgfFPv3Cj+3xcro8Jwz/FF8yHPPejc2xkV2vMsX0n9dOi6q25IPvFPezY7KvM4nsdQRBznGHcG70Gba76C4eEzgiUmPNwNstyXkPd5Wlmboj4nD8hoF230gNbjnolxI9HBZ6JbhyfZKrWwRy1/ujKssRxw1HX/z8V8EkfWzAWg8jBy32rdM2VhMSJsiuEuBrCPEzWyW/Y6xS7FarcC7sQxriQgaJBvrYgzBSgJ5hQBf+xw1BxdzfPiP+FdIUErYm4KRstbhWfn5xEvj0ZhgiTM+zGj0KQ84kMLX9pRKb47IhgSOgLUWaob8sDblfAfF44YFoAA=",
	orcwarmonger: "data:image/webp;base64,UklGRhwOAABXRUJQVlA4IBAOAADQOgCdASqQAHAAPnUylEckoqIhKjJtkJAOiWkA0JevHxP/YeCvmf+kSErhPtDnZ7N+AW8vtEcA/C3kA7/SgL5RH/D5YP2v1Df18/3/Y+9Ev9qjzqql2/P+hWyhzvMMR+DDtDgY19r+TYtviA4zer4dttSTkYCN6M96fx1bpLMq1JGJ7dKFUylf7+Yt5iQQuYhbDdxXBVIx/4zLBA7lOkRd53yLx2TOhI/r0420IeLu01+0r8IAN+zOu1d3BVBzG72fqBM2TVB28xg7wpgz/jMvKAKktEh9kQJALBgX67SErBj+wpkPJDl1DMcrXPnGUo3QNfP4c09lby7ODS4NeMz4fyeGUWFaGyEwB1HKdrb9d5jPNz/5gqhRnZ/Bv0x29cqaBlUj08Nd6ubcm5D3UILAd/UZLPIRuwZMoJOqVKwhRqml2gP3tSaqJn04jrWkPrxAQ1V7Y6/92ji658nu7W6AyZ9tWlbPnuN6gd93n5q/JvHpA6HtT/cNIMX+vJfOw3vKmm+FGvaupv4gs+ME/WsEQp6hvdKkjTFzv/Cv2ZqJVa1lkN+1E0DWdpqNGpdPrOcOvGzuBzC3BSo5StznwoJWp5u2Nv59kod/eFQUh+xr9YapKP4rOnr43ua6INeVAAD+9MfNb3271yDrnoV3ZHaHzKifA15+6+tOnC7UKO/7T9bT/1aLxw8C3hwTyD/ccTGmuSKnnR8LLvkZLF0aq/3/d99+Q2ANPt9tfGHVP9n+Jz/NNvwKjsVSqxpZi/PmhUkpf4vj5r9wXou5urq5rUGl/L8P53lr83dOSCLkgqTS8zPxQRzscKWORNRQ+Ex+ivNOSuOYEiW0+hY1DxkfSQmYqlz71w1UiBy0ZY8NtvESc//pSonVxy8HyZ810FgRWaRgK2lKn5mFDGz7XMrEtHmIjSl3Pcseb2os3+Vy3T0R0iQEkDA/RaMQdfcsRDGgTzCYY6DgX3r9a0sSRpxThZger+uSILs6FxABjU0Wreu72SIF/d9LGO+3tfSUp+g0DvyHgRq+vjN4/HBHQYqUYB+PYKu7EWCQXd4N7cfKLvhVhHpxBU5AzH3ApESkjxs5iNtzSPjZeYPRqb+t4C1MI7K+q/HEboKWNsXnDC6Zhj+BPB130IUyWNkDNZevHz3Z7B54f6t9OPX+yiHIjOY3qfKCcSCSFAEKBk9ZGTbpxPBZ1va84GqbNGjBax2WU//v+eW+F+ND1PkVvjkpUfLxKH4dd1TjO33ZV2xSEqGtkHSmBIgtQx1m+TW1Bqdiv745uPzq/rd+zF9nIb5XcP0eBtmB2dvRVnmGuChyNZx8t4VJ+mcJJy8Tr/jI68YPPAmvxwLj7FvujQHCz9F0gy7rWKJnvjZXWESjs16dMf489GydrEpRnLHrwC2il7j572q0tvnCR3HnhSjEDa0+J7DPl1v4ekqY+KjGPpvCHU17NwJkG1X/1kq78YZKxK6pxCp4ib4Kkc6WsbMXQNkbI1dSvN0AKSrAheJolcQUlw7BVRJtMPffSyOQLxR9paw7N6pJ09fvwutTUYlBnv1D8NNPLtE0IcsPrWlJVhdYvrbfp47GBponN5Vj4Uh0BwyDf00dbPftCEXzkQvgHZPvZ9XDqYcfJrEcFyZFWlLrgwoRMRDiAKDQ/2JWNdlgKDmjDbtLW+gZKLJR7Dxznx9qpTby/oROuDaaYM82HbdCPq+mLHqlcZnVfNbjpZjQhm15/PvaaqAeEQKx6hd3k/J3LLhSze78wMJpu5tCqWmj56lohIKMaPChAfNDREI6b3KqN0DYZFBW+XNxiCBCxNh3fFka+m2uv8fDcpVwIWstMaYzlpoB+tL6UIThOcpjmX9w5gNqN+DVL0HYH7vglO19c+VC4VMg80dqG+9Tr7Yt2dkBtWZNqJg755nYHReP9BLGgXTB8p1jzqz4gs3sftyOsFzx9WRlxpD2T/O9VmgVK/LvubZNE8NnLbHC5fl4AIadyWumkTyXl1kr5faxwuUaotTd8w18FoUKj0uSYVeP6ubQLx9Zp8yS3Ln5wcMb7mjBLdo68pBO8uDtb/H73Gw9khxiDi6pypa2p0Nuk3gTNzm18FPg24/3bFpSId1d6BlL36i2kIH9mV0kB5Vxw4+ACAAg3ExS6wBI00glEedmIvoh6r2ev83eBxvukGIrNZOoIxvB8BlmAXBjn9TEl0VRl9DMdh/bAPI+fy6Zv443Y8TWAqy0B7MaO/DHsb7MsocCElsqW8Fzvm4Y5PnQ1RC3q1AMrsL7qhFhmhGHlZ329O+8iBAUV7M0Ke1z97uqNnF22XX0pUHakdy0ssJSMf++AfhlqmZuLmNXUy60TD+izTN9wkPP1RB9tw15xdfQo5iAKRXWEOuR8o+SLfq+OXhvRrtsm36eHDkyO/JXLFyNzXhziRXUDjhomYqT73IyMj1i69qZl8/zahFuNJmlQ0ZPRjurYhsoSAONGmd9ta5m0AcPzMSKZ3jPt4b90s/yf+Eaks68wnuss7WqhcewB47NmoHLhwOCKMoO1wrPMrXcPGkBbD39jd7VyDMZkWSuHAMdx2JfY7IFeHZ9/dFkAyPI2VgUT5X221Hg9L1EnTZ44M0wHDw380CHb2nvvvuIoBvzgl6jZPjEeJg6FOqtCmwC9dSw0GhQUcyW7mq0FwtxopxE6E3TSZi0Stjc7pq5qGjfc34m3UyqLHrScD+r3/5Ws+lrQfaJwnOi0Etdsrl7bBLD3I8g8hnAVNfV+E6Ju223NSCG4vN8zWhH8AZYzv6qaqJDx+IIkhHyukNboUYtJk8wMS5u53U/ztfKdj6egsxVZ9cJKxsql60d+yTxVSVbxipNLsSIrlZCNd6n9y2ZR3b1N6PA1FjafE57lt3+hTMN4VuWOj5/j/Nx6uYy5dRLdWMbysFH9ep6/LUnfszv+9veCfmt9mSzYUGLbvOUMrH2maADV0ZQ1t+AccNL5QylGBZUzbJpHQ6u7WqsZbBwQCX0ie3Sc0Xf5bN7qFtK2ZXNnfIidGR/4J46w/213cq7WLz0uw+P3pwqaI299uOvt8L3MJOoF0cOeARcKDGTK5ny2PXV1gMjlpVF6rnfKCVyfu0DqPRflZzIsy8ts5YO2nOwZfJ7n9NzbIKcx8lybeg9OuD/weKVkBu+nS2JOVgj9fpsejcJKmv28rcufIZ0Cr2vJoTCrMAGcEstZWJvQbvF6UI8JgZWHVdRpIuW7uG1UEZ4iseRE5wDV0ZsUqXZLh+HWGoBUxQmJ4bWtnp+PiCABAb46yLTDJ8Gw6Q1BX4OajEEYJ22AF4RAICFeyes7yTPmVDOEH8L/snrBoendw4+Jy7VdYis+Fe1R1KXWk2jIZlZel1TrcVqkzItx6d4IJG61mu2eEY8c1m4v9UJK0eC2D69+6zgS6vI0v3xXxqkcUXMlA0ox8wCTGZxBjVaPJHJsSqwzoY5KjvcrHlmBuyFhUt1Iecc1l8O75C5NMR+DSm6sDU3mxgHObFtZqTlKRe1D90kWf09lUZvOY2cmIJclJNPeEUOkiuvo+fET2U6pyHZ0/6QeFOHPE+5oxq1VlkBP3kedcf6wVmpQ87BRnCZu6ZmnizmvUqmz9pWjzEVf8+jcIDottmJ5+ZauZrcAybjAP7ZaZH3mFy8yzPlHlglV/WqulV/1WKGrZaSoRDwRAZRPBuxXlkG4U37eYZ7A+CbCFO2tpRKxVaoWfqi9LcAU1O5umtYkY4oCPeNy0jd5cA6RkbzBX7MMQykB1MIw+BWCSrOWl5i1OvizKfEhj2d3wJ16ipgRC6KJyftlacZbbYDZYCUc2NW3D6A7bWlkRmcSFIi4zOD3cu34kAXUZeryY/KfuZSYcFDSTlHqvt0SrO2i554skWGcn2Tp7hsB9jw3YlLPNZx2U1AbzTumRFNbu79AEYFZgFC0DjDP9p+JTtpXmCbM20fkeISjLsmR16X/3oWYVfndlZIYkYmGU6AYa/revQ6QxjlxaPwve4Swu5C90Rvk9CDV7oSgxTKiEU34kzz/SVieTWOpTSNDiv+RosLWISFNZOvXrQnMbdEruq/j/hiEBWILcx4Avl8ILzcrSWsXy2COYi9InKZdHY7zvb/Bt266hNFFARkSlW+vWMhLMNtaoTuRaNgcr3do00I8RICkMD0CYbeLMMvxsAXAFOtjma5ogHxTeBZyChaUgW3yGG46Zir+LmlFLswV7EjbxBCOSRI43omCUj+cUxebBvx7aR9lh7AG3moEtjz/Xz5xiSXxWVzQAPb4ar86ApOO3192D+N3e/AeDPGZ/qqGOiheHNwW1GEMWZH7nE2gvz1/rR8cELdEP0aimB3bh+0ys9/ssNz45IxYiGyDaovnYUacPMPOsY0p2QOLdYfDCDUQkoL/aT+Xhzs15MUbGFUWJa6x+lUnO61S8T4QUCfM4hqd1oRUusrfPJY1nhQZ6aCDNaBO0TUWI32uOw3v9QIB4czURCs5auy8l0B3YGr1Xmt2C/h3tPQ3Jtmd59u7J9/gdI0IuA1/X82OAsLU+/zF0WWeAVIA0O6vUvqRff7oplvbusTY2Ys8+nQMmSJoDFpKqeyKDlVT0MH66J1qJcFMNtFFPrvT4A4FcbI0N5AcLd+W4xlbteuvTVXByebketq/b1dJKk3bBAa/4YaGEKiqve7ffg3U3hkuJ00LIhmzTYP7LND5QyyGn2baeDScmkeC7+OAwRSEIhK3nlXbU07qVwKOuep8K1aiI1h64mVfvysrjhf3/0q9rZ4pW+NJsm1piEpebebVkU/GQlEAB8mvIWwBmHR7MdXiTR/jYeWWBJoAAA=",
	owlbear: "data:image/webp;base64,UklGRjQNAABXRUJQVlA4ICgNAACwOQCdASqQAHAAPnU0lEekoyIhKDMMwJAOiWkA0gQVC0ErJPnD5pvnkjXwt1FO7P+T65u0ngF+0t7fAL3R03G669g/COoE8Wz9t9Qj9cP+L2NP239nv9nTgBPkpdtz8zHSWbMIjLog8kGQbqWefGBb+fdyWBAJAlGuOpEwicitrYO0pMCD1F6Gj48xq8UEoXsL8JBKu+uX+BElYex6ymoJK0ngzx//+bINuTowQXhePhW+qfp7jbRMkdVH2AgaFHTzHhuyh+AlKidMaeyirfe6mfmPyW8wDNKTF897Vz8chRXe5FJsPly5mvZvXKcBEzPhDGuwTlfL6KXb3sFEM521ewmLTUUrJHK2L/VEKfHGTIRCP6ZNyJTmtcp6OMbZ592u0iYhmiKMPey0KUZ1wmuL4gND6et/WkUmmpR/3L2ZUABV1vqaXgwatHwdIbu6/UgsFZWKoDb4yFRo6gk278oYZxpf02d56SOXZ2VA7eyz78GHeKPAsuj8t4l9SMGez7qTNrXiPKCH0IRkYxjuhmkK+us3SSrtSrFnGfxgobdXLnGjZljGSxKr5PIjJTtrbi/cWaSkl9bf5GRw9lPvjRCA5OjvPEjH1DICFMRRHGn0IUd2krC+gAD+9v+mPN2X4HtWrIBnj9/4a/hbluVGjztn9jazs9Of/kbsjwruv+/Zrwe9l8wUoHUlUF/yvvSjZktL00fGK//h5/gzb/x7h3x6eTPUwvA5LaoX0nMRaGeyY6Tm54xiMoPIBltk0/72vbd3Xtf3IgiKnZtHFngtP/9KPHHc48NqjGNMsy07lssv6oUtirRp1o6Mgvt/tnKdosXWf4qSI4G8wQ56JEG7Bv+DHAnwDhuklEW3U/okeRZP565SoIaQMoEjCSplqd5JtQUWj1o5gMgSVWm1Vm8ZaieOvY5E0hmenmSS16PVfgOnlzQgxhvgQZZX1YNTkw0i7unvDTLXA49as1cpdCGK7JHSFYzbTl2H1ujgD5QqJBjH8Sce5H17PLTMImUZtw9V6yOk5AmI67Z7xAA0KseXyKN6TS+Mvl5jmc1RWiNQ8/9wGMY2j3+6siipCHP8WWnBPDnjRRFU0KggSZWZaq6ZrIl6Ky46kKnYaPtpWdZsxOt4Cx5HFMr4G1Ckx/kCtrh8bgjAzt+s0y+egc/fSnH3I2kdCFxm7qqhOlmS0BwkWp3aHj8/9updYDA44f/v+eX4J5yW2nOQ9AnhR2KPHX5kChrD/Ila22ZLmhH/ENTa2IpQ2XP3qy/XevpL05Zq37NU3kWDkOupf1TJcwWm5c1aSTsWRSwaBfnZKftP373bAL2K+gvPxxDfMnpxVY13+s74cOv65t95P45lNEu1H7yvdK1lioF9UB/xKX35chNdoEvwdbaH2nlZX3H29t7fJvztv+KFJCx0qSdN93H29v6NPVHtKmBemK1Ypi4cQhp3Ec6VkODXm/SbY6IhJkZJKMRNehJyhUjr6w9DOQKBjoCmpZmjpugYOqoTPWmInW4Pqdf/HFdw07qnjJfC2GvO0eNT9YqiSe0ogEhJEIQn45cAtsxSFRTB88cD2J56Elc38KvTjvqMS5atznRgCvRO3vVumqZbbHJAtBYYEDFa1kshsJjspLk4h/ewxkewb4sGd66WBgah2dBTIVuKOR1okQoIwp/DisXn/Lu1qOOA+5dAA14id6s0rB8qqh2xCfVy1OMy05vy9ooo38hEQwu31sLS3RZ3GjzxgmcO7xPo2QgGQCkcyRRF2oVlK+SLwWGFZbaBRZGiuVj74omDh5ucNCgiteCkhAaexOzwBVT+HqIZ90ihYXDw5jy0xT2gTf7/pg9TnUUJ2vYc92s+/b2hjFhJMNuW8Ce258VM62VPMAhOT247rHAWkQtNiXXh92G980Sliy2BuHSSmVYzV2RFOZwUVESmjBG7kHNE2byA6MItJQRUmP0T/wecDOb/9/fmd1ACRnuVC503zluDqo6vQFl+e223cGHkVw4HyBSDcpxClVbzxA16dxYfysww+U1RSdfedsn7vnOcnV34efKdwNzmepeTkzitqT8qZuT+XYvc4a66FOXDmF71YpnvbXKh2psf/owerpf5BGqtGm3xjQL5eQdsM5bQybQQxvHXXJ/bzbLuU1IJ9wqfc63gQ+Xj9LCS89geYoUD1d2FWPq4tKQVsA1Xt7Wyn5dwNJBR7XrutrVWt2R7nh2OJiEc6IxvnZBSmZq9U6D+n/4C5+6zi9h0YSl/DmRV7hX8Ta5OJFHFlWG4qpl6Nb/R+5i5wxtjvQiW9p7kimMXhXYIskxpmRJ8bE12H8ogemZ9XEp7+wIdHmkH1M2KcCZt3tfa7po07ksGIqNmyFYnyEtZXsmW6LM3+2Ep9DXEVV0OPtleAu5+K9DHEfb0rGnVXS91xjq+Qh8t3bcNudPWahbCVp/gv/8GVvPVbaiXlTwVmZrGFCptxiODRkcEYo/sQgpEYjhZi8oM/4mt25nsCKTrVOj/KDFMY2VfOGOCadNQ9XvPpzWl1khzwi61CrczXxWprf+ilwribwc9FyNG3j5xU8yRMg6T3jUzlGw3z7gZdOvtiGMg/0b6Lwewib6AkjKHtxH2YX05EOsK66SJyMyAQe1SROB9NAbfGhQi2ZfLhA/Uozt4IDnH3qEt3B2Ru+VKs0MP01kcvgVVYGQmTD1hUKYQdjEn8FzeN2JruAH/Bk7T/PJ4nT9XQ7PCz5n7bmF3pELbeddicolO+iN8XJWhv7JOGmGG/tzPVf9IYeVgAeWJc6WhFMxYIQ57iwj5asp2LPHOpylc2ncib/ReelnQN3XVclEWXo49gKCXFiUdfpjNBa5pSxhEFfMaUzYbJ0Q5tPOQPPPU2PUdfrVApPFg9rjgKHszdvZqajh/NLqvLAkIazthrmiMSa2dB8NBylTwJmRiQhJf+DyvFVe7+3TP6pZ1F2IXbRRp9rgKlG5RL8CV0XTHAjaomardTCUEhT9Ce4F2kNww+fRr/Db79W8q9vEDEH+SYV27ejELfvl9CzGhh5k6G+pUFEvQUO5PdeLIF/ukN/tJ7wCL4MEerefmTTmsZ0+YIMkijsME9Lh5SEC1+6C7YlU5IFGVSyl5MhWAIoFX79epZysjqBepKwjANsXjxgqUnAhPnXYJJeG3o1ly0HiZ+ofJJcptQ2+aR12yuzZot0c1t7ERL99tkWDeiVwu2N0JXnD4EK+N2XZ365UDHSPfFmsiyHF/VdWWzM/ZQwWtpGFP0HyCum1rIrupfzQXYs0atcBvEptFJWF7MpT73bktPwR2QxIsaMKWKoSBrRqcg+6LVcIVcQDSwEvf5Anby0ITZFAstqO+/MG1rJ6iWiCsRZgsdjoPcCz0O9gGNRsZV6sabk/eHilbzMfksJezHFBnBwaebwhDREnTAfBMto324gyRnkzthTF1Mf7hx0PaORygBN054V9X2JJKRt6OuDGUYDnnRZqKdtOrjbPPmV6Wd2HIFJwrZYM+iUcwDaJT+6+Veysgzxp8QoAQx0+I8slYxly/MMYogIA/Usawb/aiNwrSRpsU+hvTTA4+OoB5MiD6Dn4DxMYr3eNU9aIXjwL/c9e/NgC0ocuUGeMJAutJ/zSpRBskmkfDzn8IPmH20WDcLjc3cc5s0ppyOqmpIS0I20djjQp/iMhiZffXKeW5RFX+6VlhhhxXZpJi+0ECaChfxyYRQCu8HGm2/Qem8OkqZhdO5hoQ6UPx9IpzSZtDKAPVTsU3QTv4poHtEgpJaEdCj0YLsobmU/n863ktpiDuEi+UdGj1h9YXq9gLTZDygvCAuSXNcI+nrXBU8y0AQaLC0M2zofCP8l1qK8gVpmVWkZeMX5x/L0aODHVuWWyE2ZPmhQa3jT3FUo1O/T6ESg6vGJe8H3fcEHdi05uJuaTEsVe8E7Nvd37eh2eBP4hjMQK2PE/vc9n5WbJRwlr4CSLvjr+ZWaDzARlorkI2ayISuU9vJjEo0NkNQbDguMxCl3VceIoAC1aNf5iIiuB7Ua+VmU6aTfDQCTGRiF2IrLIh/wknyqIkUQ5F209HD9KPEepFMnUnOJw2fXMW0FMVtnw/QU4H8xMariVqkov8duxq3Dl2Mrgqqyl5C72AL8iDzECqA/cTQJ6VJwAPpweh75M9PxcIAjlPfs1KJmDbX4GgnBXvd2lvmnZ9oM9odTGMFATv9CtnLIp5wuIiPS8/RBsqTcvf+x2M+Nz+01NugLVN2pMkmFWIXzvctL9BJY1Gz6hmHo6wv+Mc4VDqILd7M0gtVssgiBfAscrjvbEOB6sYALZzMxCsIpkCdmqxl7eloAnfevTivd9nqByE1Xvj+KrHR9sx/MQTdB6YzDeuLC9zrZMI3egsOj42mZMsoZSpFWFbu1ykn2Eyhj4IVzULjPnJHTyuZXDAvPWISfqIcqiTGp4MAExFUVCR/lIXQVNyzJ5+SBkTqOtZor9J1Kg+4C0G9LNw0yh3u/oSSSXaMOIZOSxi7j150gAAAA==",
	patches: "data:image/webp;base64,UklGRpoiAABXRUJQVlA4II4iAACwdwCdASrIAMgAPnUulEYkoqIhL5XcUJAOiWYA0fXmf2fVWgG9Z5vlv/2P0vcddYPmidLfNv8yP+n61P1n7BP7C9OzzMebD6b/7D6h39k/43W3ehr5dPtC/2v/welNg1vJf8B4Q+ab3p498rXrPzI/lv4r/hf4z25f2Xfj8xP9L1CPbH+z3yG3foHd9/+x6YE2XID/XXjVvYPYG/TvrDf63/0/2/pU+v//f7hf69dcv92vaQ/Y5xxOfa5JpiP//YHA1jCrM9cAQccpCa7M7I/HbyVxfEbuBI26F6blxaa0mxky6uRHwYsMKDg5MiizpVTDaV03WSY21gCcd6PGiI2NSFuHslrS3M+1A2M4c+NNWsoUvhRe87H8RAo9OpknWKJfKVTDkoF/54JnzcZSRDgvCCgLM/B/pHAib7U0UhXnpOOY/oj7WWXG3FWjvaxdPhJeS94ABkksDJJ9t+J8n0f9LmTxyxmBzIb8HatebCgI3QCrQwPBNMRtH669CNsvc4TiaMT2WSTRHiBGQMDTeo8xSMJ4INXWtB8s6442tVvTGa+XGHxGNGFtpMcvWdZg/FWrCgX7CXMBAtG9EQKbuB7T2kbSnsHuxtrQV+uKuOo9aBi97IqGbogTji4eJxFeU8sXQObh+TXQ89jsmsNs90luGtm8DjR3rBvhe1r5fiDTmAhC36yZhsHfYx/Jy8tN7ghdSHGLab6JHXTYJGer784/XLbHI8+HyJ9AWZxCv58YMMpt6ohUNItJlhDOZPC9bOEF3wzFhi5vFXbXUK/8rNAsqfP2RHp1DE8no4sXqR2tqGgwVEJiCkrAfMzE/U+It7srbubVdjpspaRLRqwjm2zeWHyFFZ/Ll+7KBXpNu9Q4285xPbrkSXPr61xbu0MLOQCglkD9Ter6mLzR8I4BtwfPp8xzZ5xN8YOlAIZjRd2SQUIIvKQIE4br5isfn+K46lU+sTb9KdUs+NCc0RReswbtuHS0aspWzdvB21GNS9PvepLNLP91LjPUssWVHJw8r+Xyb2B3ZXdCasi6DVW1/WQYhwcJHT0Gh1OGE/Q2FNOXSihyyW8tazAzvWMwGYCPMozwknobTZpYyAjgOkHu60sRwJ0XZqS5SpuQjStt9ve6s14opFNQ95gIdxDsDYac+blIOoC4bSSdbdyZA+H721OnCxPUW6w3ry+1Sm7mRj4zhLznlRRwJMYpFta1UHA2GtqzJVS/fkA4MesfexY1HHX5Y4xX6VDPbLFWKnx5Vn1x2SsCuZb61ZYQehr1SlH9xwQ0z+VLugAA/v5V0CspapZ780kFyHwOqw6sLQQ8J8mGa19Lzq8mi+CsJB9Z6kiQn355rxNhy+Xj0Ml3yffxqT9qkokVlhO1nqA6svPzU0mz+oEUzOORYO+Lbs1B/CBMfk/IyOUQapG9GkS4fKZ7Jxfwbl9OuZZlJLMtMxoIv22xVeU75p+snauRqxLqijq41nGMMP77aH85IW2OamF7CAyIVMRvWaLO0BKh5AUcwLC8hKwcvpBkxX2sFVUC8lZyA6iq7NZ3ClMEZOHTp4wjtTu8UGqnsx0o6hV4AAFsCh6WHIcTQnsAi21BqVf/joX7SxcpkBn3eLLKBaxQYuu92H2kY5U/GLlGliPD7XlKsbE2yfqKDYhzd/ekb9KddNF0meFRT9ajRlcH6h+Y1NM1scH4iEpdjx86pmNP6bIvC6hN4FVxgrMTa+DN0ebKXA5+6YAhJrf35wtcMyO5X2cEH6zMv/Y8f4O1Dvy3vDM76gyQ/5ge7MpD63D8AtiZHA292z4mNhDfOF+EjORxJRlP6Zz7VcaQ8iqnq9wXIcDZGnV/ZY8BPKPpbXtCRfbnQ6bQHZz1tRf4HhebZ2RAHSVgKO4seULCRZsCg5EABgBjz6piQbVX/Ui2rC3TpVnYU2XJ97mDwtQHzqD1llfXkThQ32K3bgl046rFAjAsVisysRnFvXdh0MNyqbqOAv4q30xoV3slKotCa9eYfRmXFQ7+zy4iuJlnYN2bDH3jFUhe5O4qir2355kadJt9v/dz9+90YfVGkVbJfgGSV0gaVkzDVt0fKvitMSX2HiVZoXLqGlXKeAfR7ClE8CEvy6/tvphDtUBGQx3SHFqS0YO5ibVlGa5+qnjxFvokbIH2MDPw3looiW4qS+SJRYI+x/XMt6ApXd+rZKV5VXvm4qqhek/ZITuGGv8tuIUL6vcGDeGJGUU3/fJ9J9JAsa58ksomSY8GPiQyeVN1LALFNDH9rqg5S9vvLgEZwuz3KL+wgqtbTi4nryQU2n0kBfSCB1Y1gbTsvZ5+U+b5RiWgQhv/1Qp5NBk4aM+E5+jNVW3KBaOHihhcE2ngDbH3lCLMu5603wrWJGaZitos07+QR/aSbpJkx8Gn5jBGhQTftWU4VKCquHaAH/pUT8T/38EFXlbvEt5zPPyYBKU8p9d//O1uWb+a9Tam5leHNPOV8OCM+NU2LGcOxo1sUw+nJC84EBM411VCQhZXnVU/upBowOo5Kv+CN0nPbGjIwFWVXhP0GgSu/yZkkqd/mexHmr+Li6nVA2+L83VRoss11C4Bm36AsWYMVTKJz8rRFoK7+qNsx6lPJOo0qrk9GPGtx3hYOdaKIyS+rg6WO6KFge/A2hMOMyT7sKpIZe0kUbCr9Jl4wTdTSIk3IUAR2p6k7a8Wjfg2k556W73ePUIdmT9J3qWC0tUHcE4Omc5H56cEZC0rnHE36mcNsdpMS1CbqoJp9ETx5QbyZbQyUY3EZzuMxDaxQsPu+EJ/3uuM/3huBqTaJimKE8djvinOK9K/m0WnTtct2815JaGCQ9xKdS2WS7jdDihURMSootLVXjcKn0xkMwCcq9WqHj3I+M3b99x8MbMn095OpKQaR0nhLW1mLaB9Rh7Mft+d1ZeRnRTrdGpeA4o6Pe/mYRPTnGKZvy5cn4L7Hcpl5t99TXzgwOipUC8oCKrLm3wuSeTRl0Hxn8Z5esTt5aV4VnJjlBTdAksPR5lNha066VH6BtoMxx/C+Rbvhx7/3+iWJNgD9dx684I6CpfLpxIomnfzD/2GbqFDIQUt3vltb+RnDJlqU6F5d063qtIgLnEtjC0sknQK8LDo+MUVPIYN55kkUhaE6coPPr8axfdooZI0YPzTudQBU1XKs5XWv2qJ8evZHVejGhNypkWQbb87GnzMxUEUruFFPBSiYXMPPIMMjRlrX00s+kxRM8lNMnK8MbqYoDhEvkjUgTRzrTzJ77DTPpdE+upfXfhMcxf8VV4MSAOpuOSrwW8w/y18lr8RJevwShoCjlq17DUnkVcH6CtXf0XMmoB2xIxiG1OIRmM5UICaMMhUQxGLIJh+dfH4gmTajo4oWUUXavD/TpfvCm9wuWzv3MP82HigPJjiKQ4VQCN8sZdquWfNpMwvfheOwcGcpCxv6XltqZxc61O2/ztOGmP6IBDRgNyQIRFii8LJicUH9+CYZF1RSmBIYPgW5XRBNGq68yVmPkZvyJ6jh0Fx5Uo06fLUEgVBNNe/P8Dkx7/pnT8V9VPbEHeWX1IHzZCkckrE9siwLkht+H7iGTLb9s1qJg/enZUGfZcQeSXmRNbSEZMVIyYUDAsVDVtg4/YQ0T5PtnHQ/GbVmADQ56hwIyy9sYvqaZDsQ6dImNkN0PcxqIX+Nj+1nk5xArXxsVIsU+Wrt7mAISy4zCOQ/gzGB4CwOQtxQd+2I+j9e4MOZhGDS+et+95oh5ZYPjFQjqdUm2kY8250abD2MJykImIMxtnug5n52eay8sXFUC3ReOMWoKCIok4wp7bNb2qbSfTKCgJcR1sANw1hDdZjUe5NDTGQdoozEFdB2EmLGNDbFtNImHNDKKmMKdoCV1bcf+wMXK7iopMT9KJ/6Q7ffDyt/jS4tZoSHbCGRz4otbrOfaArrp4nD3VB+to9Up9bm+C8JBOxQ0te5OGukykjx0mPRaiyikU6aJjMCqnJ6/PURKQH+z3xQS3xpWWWee3KQtXVfPkfORRVdzVEsu/xt9vPvCsbZ4k0hg+iK2fwXX/bnci6n+AzUgKFMtbLc3AsHLpvn1cPDCZyVbqRZkIs9QzetsdV5eybp2ADm7Wc99vSCfOpgrHFRiUDdFUidWNl/VjCirkVUBDcqkW5gyB0veNKzJov83gG1cmCZML3vAth48ESOZ54JCcB7d1QxNuQDtbZHF6D76jo71Id0BMsvKthCkRwY5OvzVM5AbJDWeEzvFZ+rEHzH6Tmm3bj/YU2hSZGqLi+kRPVUcCUOjDp5s6N+F4/0TswnlTYorGtXFfv0wcfrqWmqW5d1EkWcAQAzhxLFbgc7ZqbTXtoJqgl8wrFyZzRHHimlYKlyJYojPgEpoks8pGHUo12Ze0jbOaf4MTOrJY06ze08V25cs4NVe9xG540nfiKUJlcm3jCgQyXTdFxQPOaM5VdpxA8e5zzF4yl6UL4jY3dlqKHRU/1mKghgmD2ZQXYehDrAzYs/TP7/4q7DdVtdJjP9aGNT6Ixjyv9GTgy+Ne9PMov/6dqA2ARLN5Zp7n2z1ha4sxNlCdSr2XC1AUJdBz4b39gLdAz3fgqOCL9cKaQ9ErbgoE4cl5oMX1MHAA4Dz2vU1Dwva2Y462G3jPcZE9biyjTg315LjQqLhX/XXI0Z+9SrMzuUiBvF644M2cLLCdSTShKKV1zilIZm8MQ2OX+2ErMkmR+Seulz2gRH1Aj/oiK2fJFJt0r4pkqKMZEQYV95fTdWwMK9Qo/If4gJm6OsvDJvotojZb7j8Gghc5us5fEcv3+v6o+/Mbmb3OmGOowHebUy/e8LEJCY2Ee6XQy2Ts9lGS8HTdx5WqDZd3+V4UU0cxj9PIGPlLAUgZ0qLFMtPeB3Iv20WodOM2haF39ETariZ7Gx3xXENA5mn8DWodncDI9539t1c4fejnwQp4yvZBGkBTl4RxE86yL6GZoxdE7km1aPIrAXf/O2p9hbSQ+0oIf3s2c+4f9gNW5foMd1P/B0mY9JVA501YinfkSO5E/cPHiDpLNXdn9OObePtLiwa8i9lZzw1n4A+KpE/mU4z1OpRPEd0mKqPVDRAohXKtylXyApHyqGRmVaPBlf+jvHEPGlCsFWloZQYFllTAePNn50mCdlTdT4Et8bhlR0oCKEVIPAOQIPMWKfgCQazTLUHvqw/SEIeZ2IgNQaMNZHqA1Y/Ue3LL7wSc8/7EYQhh4YUPOhf4SxV4t04WgULvkUSAb/1xOlFAwKRJ1Utb/LIN7SGPcV9XB3/0JU76h2AnvpI3fOBEqavm/vA2IDC5jSLKB+36xHDIzORraUwN7QnRh/u31iAAEIUoRbK0jmE2xDtZReFSTgvtoAlI1y5W3RE5W8PKCooKhDD9fl9xF24I+Lzo4TA5/LpaVaw1yTpu3cskq6jq7rLwByOmT2kzSAtYVZaAECK9mI1dXMLONUZVlTuO+1mM849s06daLfoEiF/KPex6P415749pxlAyMD/WI0lhIDj5aGkeoD6IMSfU2m6MYL7qDja2Cy7C8BvV7pzPfbKtGx/n9yGrCefe1elYlCLSksSJIb1VTwrprh89jn2Bhm0903WoJ00AnDjjPwTncK11G18QaMX59F6NxqIsZvATo6ItGpSg8febiUkEcIc+Q/0yEPB4k8e0NWqYdLG0mlOqD+4FNmnBuZu+e8lK3PqmVv8NakkTcr+netsEPjGPnxZNGYiBE8uM699iJGHwHh00ErL9jYxbRI46Mz/0abEDogBNFjcQ/wn9yJ9/t8izgwC7qSLIuWmKUMIMUJE3awnrCdW2BEkjs57QCYbNI4QtiTjWVEvrPzyQyQ2oxlO/Vbw71/ESvX20CSj0XBXjV0+lx0OTPMgmg+pXLOFy84MtBq2AZysX3Vu5bgYlL72sVqHUqqST6fV+OG+3IIxjqEYMQEk6hp0zVacgU0Cvxl8m85fpcXEsbONLtD0eAGGq2SqpZtsG2DHuQL2bHE6YOAEiElBFMO/wf5TlWnbntOXL1BBH+S7lBG7zOLyIkD1P9GrpWKygya8xgRmADzf/BvvoWw+jtq31maYdKWUaA5UqOrZutEyuexVYxiCKwO5lfqGWMRozcg9v/6W4hCj5Geu+rwfWK3IKC7BAv+6yPuxaKab0bv73c7Wkihe8lQim6EQLhWZVmkwd1E5OVLT/56WzNIZeVG2QLrjgMrYH8xWPYet6DFGEoKKWKFWVsZhiWM2BQ2gx0JB7M6lldyRS6Kd61IoZXAPwjccFBFW5Zwo0h9lIyTMXX5mgKOEBP9bFEkm5zxzKiiTKoSN4FOSFXOL2Nwg/o8yrkyl2FMhTIdMNL8P2ljj6EKi5DN4hFt+cTpChofW49we9IIjynNOD6FzLdU8AJwR+jWfWFTe9VjwLNHC3um3dq4n7QfLhHniCwm3ZbphcGBD57gjWFZ49mVZnWBgavs6Q5UAkhW1Tm04Fvtfb3hS4+7VSHvmfaKEGIRZgEG4qQNSni2R28hmlQKZNmh1weNHlPXs+T3mYT2JyiN0aPDivcGfZp+ZG9lVivoIlgMGIIMP2SIqZ//CR+fupFKAt+JyOzK7lv054Xfsldt03pEbm3fwv2O6TkFXmSqConLkLCQYOjL3YFr3WD2eQOuadqpvh2bmU1HTbn1kVuSSeqoNNscxfsFNqbJ71Ug8YpP6EDsOLamiF54F4lYxKU5Mg/Cpoy4RU+kEy7ACiXaXbshCMikBvVlsoEl2Qzgfz23TY03P0PX8WaPOkB8ylsFRSPE4VOJCIruY8zdA2SSGuiI4mlO5AEzT9vNLVfrZkszBRe/0p8RYUlQy6SV6yCdOg6nDIhxsk5dY99+aW4kblfsCA+86m9qCIcWfpFMh/HsrmLbC9giXAqSU1m3n4rJNMFypvVa84UeVTOgxvkAukJVdN/0NASe5XvizRjqougl0kUGhn4HDHPHiUReI661+DlN71c4Mw+FBw60tO/rkmKHHe/OzbVc75tCdUfDXn9kfkzRetBNN+L0ESdyCZKxozD2n+f1RfuLl4wP+8g1R/1nlSXaery+5EJBCWxwSIOKLVb5kHK2IlBwUud+zhKD7uwkm2VS/J2giL8R1EW8FfQjjlG5wN1Y711ViWRXXauOfZzAJq1RjDNQ6DYP+SaPCmYmK3qABtdrz9Po6bnAs5LEdSuB7yk9uKPJD0IgggHXxFd1KwBioOZEBG22fq1ssHz1QowZ1CLOtWQDqN01EtzpwmcP6toFHw3MJHXermpTMCdK4R/O+KscFRAanK/+b9CFjxdHnLsCm7M+FRB3y04yMJqhKH+q9bxA7puj3hcDoLMKF0ctUnCP5hb36DLsvIw08jhYeFA/Wv6IBFRn/L/H3144bfliJ0EgjdPlfVhzZHv4qaTJlmburgh1KR4b2CC3zIOoyJJhGf6QynlsBBe9c+nnE6ZnXyMBNxfuLhqBBxZMH3sEztk7p2nl24u7ZQtNrdU8Ilfmmwixgq+0psNHQRtJ6kG65b0z0xDFqmHVCxfFDGXmyQ0QP0zeBNW7qO6qyy1b1FXtMtcZtiynDv4wtrBfbP6XI7MStB8EKGP7W6wlZzFZ/ICBFplDxNG+1Etg/pmF3A3YHkc2RwBCKCefWSzzX3xA+du5W5jAZKs6hdu8ScBfH9n1k2gV/HZUOUByBcLwoT57DF3/91VGF2+Py6iiA/xTdC7mMqtiwgewd59fQ7T8zAnSs1RUBZjlY+RcPFVe+hISF11paHiQz70+5IohjI4BgmyT6c6H4m8XUTdyOUy5jZtfhwNdYYgEOeIx0Y2Oyw17E6E6eUJwQ/sIm30iainb4eDRCsq/lwcrR7OsFxiRxMNo4WA45FihKeWm0isv1A7GkNsfmONmf+VKVaGTwc1jNDolU8g7xXVmMuUCuhn7NBnO1MNiMjdqlczXqT8Kp5oI0KDgpKupsG3X2nvmlezmJoC+iN9cbEoWVMwAKWeSXdOjdZmd4M6u2LsCeXQDuxubUicKG3Zfp9qBb7Fpw/81/M9MHC24AGE55BipHtd++QOH43Pdu+js0JZCqY/KZZKG8fFEY420jM5qKDkmvnpeLntgppETUTTXY5xRAEZ0VbT60FHZ1xGMgdgmGkYtoSKHqzVaY4TFFkDgHQhln/VpQYu/ocC0Mx4b1KUwDkuT25pVbMHxP5vZc3yJ2pFbvSQMH97V3BmW8G1G6hOrFY2NxBIHJTkmvNtp6WwOBuLvSfhTgu9RRdyMMou12XR7wNSl9yUHtUnh4Gku32D3X14nn/lNqkllX/59iPhHTuPyyBiOf8HjcRKN2w1tanGUoAGDym4OPscY53EtTnY7hzJiOc7AWZnBHIxbXtydvVhsoEPm2Z0/L52YasH10VsGB5uLBq1XchzHssUkX0ug6088rMd/DjPVEZMCI9MSe2AZaBmDoKG+eCyoUOVAdutPyT+eqAcMn706p6b2J9rmR1C7zRPVn7FSVR/1rMn1D+n4xMcsPCtraadJWQsow5x0TK2qpg9iWrsN7dWg6fYMFPGbcOdIyU9vRsQjUxsZt2b/9B1B6qVuc8eeF63KaXMBWUIdOHSKl2U2gWpBEJvr5YO8XknmRtmFq0gscYV6kswu9CiweLXt0z3P9rNn9uauSC1IzWG7K6RtHmEZTCpqxv34Q86se4OZ2hXDYqtDUVFBnacDwyBoHLKE9YeYfdFR2RQOX4LDijvg7a2LpcLDO8bH9/7expjDFfIb66QH0qV/9XnX2ROe8pcguVC8BLFLbYVO6OW5TdAil8ifUuxxiLN8wNC+IIbkMJHx92pXfGC7WDdLNVrA27Or3iBQdGRN0LhuExC3/dJJIUI0UrXbTfeDsc/n1U3FgZnM9JslJ/XD6CQ7pBUipmhpxoHfz3qbTikQshNrJaFletAts884klklVCjs8ZMsiOalwK9jb2ZY49THFdjzzWk01h56hZmrFdLB92s8BziCO0ip7+Jop9uYBB/TOW+L+3qwwpphow/kwkJPk+ME1Eu8+7m4tfSlcB/e7vw1YL9pCdbDUEnW2dwi7TItG0p5JzbHoXLv6ICj1MYWm/0sycPR8i8ExutK2/JkK3cbjVJMPVGtL4IcxuzXhrvxM0GvKmSPX5zO68cLho2cHNC1hKD1DDCI6wBu8BpngDD9O5xVa6pZf5Xo2OdHsoe+gumDuRzNx/GzIITngRav1JSfL1k/19/2c6/8AT06kqMEl6hdZtZPwIosLrGTN3qgRo5Yi38xT3/QoTED17j7Z9zq2J+h9Y4CPXnoFWriwKRc11/Pk3lZ3HhVcSZmu3Okve0py4D17aaglSp7bTSKo2SOSgLj9eyYjdtl3x6zU6TeYd8/LsHo06kvjZi+8ZhwzcAM5lubBG1Hwr/u6lVLTvoLaQfFuNAoFqN1+7R5U51AzW53zGdgcL8f1PzIv+5YtxHud9q0OKFqbZ3yDXKC1P/N/nHJtYRmPU5PXZqUPR7R5bZSAmbBYPXTjOhT6vMGiTaZVojreoiNSf4LaF/wslPftUtRZ1Jgf3/YkCagPhKHM7z3SV7/ts1GHIy2usVRdXeGiDV408hu5+A+WVst0/Tx38dmaHfOsLF41pQphB2bpZOQb/KLBALSFPPisSx6fsE7PgEm22BgPcdpjYISAS5ThEgbfme8xTGg3WoY6nBRr8YNNnFtScC9WfgWcYglnWgWd7NkW3Nculq4/zZBRzIyU/FSqNpZlxpxAYOQEUCBQQ/w2LZDvA7Sg9lLx+qgkxJlvqoYH7WyVSq/3X5eAYrqdOYqfruHZLloR4GAo7m4gNk1goGy7j6D89BkY0DL8tjMFDQJlDlicYLeqEAMMCLQW4PSfC4oB0F3ksVN4qZ9K05dk8YjEF3TsYbv9YYkihrpRlbKauA0W+dqVkGe5X8lyPKgwJVL0XrbSpBu0S797C+DmNmL0jQDXetX4YUIs8TmfOJ4/36MbvfZaTXDukXDrlAvuP2czQKDnioPL+AYYMi+dcF6s4+VPxJbuIB1Cig/iHSQ3D+UJ5F703ElHGbVwdN6UIjulKk3RnGavaNY44Ysw0tb72t6PMuFMu0CWTSk8AgWlzoKS/YuXEMTID2cmPWxPu5z8hm8Fo0TmqqeAyGIKoYiktaVL4dzJrExEle7JL8Y9NMc2yQ/tb2JQnYFFyas4Oph/vLnUL9yzYYlcUfIAVEIiS9UKTA5v5CU0PZ7abVr6FbAWDY7dyP/ApMDxQFnLMTJ/se2k630fywqQOCnwiT/nyVBoNcq7OIxzUBv5ZPt28YtZgvHESSbWq766B1z/gpwR5SrAlQm+mOxAe3oYNtru5tZEFHXZZDE/0oJ34RbnYQb8of+FJzDo63EyYvbiFhcNPDMiYXibVF87KJhlY+A0j/kw1OKIgKb+YhIw/4qXHK4sd3B5Jb/Gw5lsNVW4FbPDnc3uG3eW20NxmDXulOqLcBw4vGaTo6uKGif8kN7YPLq74FqSs+iyRT3whOU43N92bHGpUrhAbyVCf49ThSutHqc1LTodts/25hzSePhk7Tqox1OQW6+FAnbiDT0aLLo8U7yGcQAfhBpDTWiNAAb2Or7VuitVAt4a2H1RiQXNoNxbFmtFH/QClZcgIAI+zfPhQyLlqyTm5n+bIfAfydbFnc3dBW7DRYyFl187QV1r4afPuFJTRBK5+qJRah/quhLXMNYx88fBPogHGmS4oL3DjdGFqo1srbk0AOPq4i/i8hYxaHmvMawbmucJlLgkdODS3S8d9La+eW08HNfXog8tILYNI8y1gvrZj3LaLfDhvA4CrJm/c1W8D2UDwm8TDHZdxnuChOXM2xcZrtXr1LOPt6529/kDnE6abwVk8EQNpmYJmZGi/plIT3loXU1pzBo1lHqIbICwI1sKTeHdp5Lx/FRZHK8SJAqufy2h2AABxyADAH4EeVL+7vaulMW0QcUGtEIrt5ydekhutZXA9JeKp4mpQ5cpueTBc8uZ2g7wp4rn6L5Fl8pnzd5WusCPVpJ2aUZ/kAxoBDmD37FciHtXrcRYZeRBdLo9BkE4dok6Hy4irW3smJle7uzTVrbmSG71DykzSS9QiE4IFhF3YzEjVvUmu7HhEezaiG1rOb8gBjtHlKlD4xYENInDdgAnYweUPCmQ66ovI3n3U2dLuhxXA+Cwj9cjTkaI45YWDtL7+n7Bqd1lGCoJLbhreqfvUqLhiEU/4N5AdLOss6WUi4K3WK7G8P2E8sZpq4EMW3dn9fDmMs5QXmjHDW+xXN5enqPzDSfAoBzMNKzpIxI8CKdzb/IdZ4yPW2YJn0Rt4ZHdzNyB0wDNhK/xPQjV+o2LZ8INsbbQ4mGh1k7dojpYco8yW4EzwUDPpsxL5eovtdITBuxtuokxHDfr1C+GTQNOA9HYEw7nhyvbPBBbPW+0WnjaMgRlqy6sFlGr8Xb2Jd6w7WOA+4W+n792IQq7e2tOukU6KAY1YNNzFyHTkM1g4/9tS79nZcCa9QG1fX9jz9psbENktAgGzYTsOoD1vcSWIkFqtVs9OG80w8sIBGyJ7VJ+8e6TQpPSAAAAAAAfVF7+VvTQBkAsdPIjA4+yOZa8ZIoUIOEinJOtt00pzIynL91pBtsiT55910FDObOZAumj1BlKXdNnPNvCHEzY1FfE5jyuHbCJ8vFOpnhlSaXem3dhYDIEegq5kMhMxZc58osMX99/+xucfqyJ7AvZtPAqD9SbJsQhhhjl8P7eDacmEcDXJnVvAZdmXzA5Ehp/yjt00uI3L8NXOZECqfNYgLKZiY8lA1Dn/aI/x3LMywnUFxTmu3U2Mkgep66LkNKOsAADO5KwAK3gAAAA==",
	picket: "data:image/webp;base64,UklGRiAhAABXRUJQVlA4IBQhAADQdQCdASrIAMgAPnUylEYkoyIhLdV8AJAOiWQIcAGOZcO2vTj149Iu2f6f8ich4bbu+ztf9D1c+YNz6PM1+437Fe736fP696l/976oz0KPNv9Yj90sE789/lB+M8I/Nb8qkuOFupN3n/yvXn/Z+Afym1CPyz+qf77gVwDfYDz6Jw31NqC8MBQG/T37Ae8X/s//P/bemD9m/2/7WfAh+w3p0+z/93vZ6/a5vs37Wkvr///McQ/LD2v4Ln9/6eqnERT//fjZpWIyQakBiPYj38cvFGnW+Pqd2JXhiNEV4MkuvBP/UGHk4MNOyW7wMJJlIgIn23+MWjZKW2U4VuNBErtQ2FpZ98zxSP0IweneX0h20S9IkvpXjb6j7gybAI7FOkFTBrdOPwPE8xlwUUbFitFqP51h8RqVu1OF2mttdbSrBDVqI4gC20ZNFLGkz50m9slP7qnDfaUyw/qNNPdi9lpHi1LN29Ilvm2TjKS4A2b/ECp2QeouYhhGaydw4i3bQb584qoq6p7ky/A4q9Wh21veZUY3LWaf7kbzrz/9Z4o3hWHGvnwf6jkbGuBLe0w4FDEg7UXfRYMqhcQ3AKh0dirCC/PzwFPhGCNrQbWKOf81EziAJWP3Nq34eAZSw2VdPkZ9V8ojys6RBMxapdIgFlzij2v7YYY7ip+wZ+9+3t//hvcqbMav4h9m6VSUovd8UDrYDNP8XXWvpkj7zkSxdiwfeN/C7LwUhlzLz4DH3kSwUSizTp0ZZoa29uCnbrvfEJ5975f955Uc1ijcAwzwGmOWlvx/Enuj11K4+6mNdMRhs4AqrXyLFHRQwcI5+r3yqitKEdQaJ6gix/GbA5THX3AK0O6m/0OYqKbBiC0p+dXrBEBNwJCyubLw2aD/uxFx7ZVEuXpy3UCuuOF+mxoAlln8iLAn9vZHNjUBicCK3JwH7EnKCYmad3nzldXGe+wmi7IvDlcLaI3dN6r51UO/TbflL1eg2nRlaKA+z+bMYNCR3kWJ4leasq+jLzPpYiaXlthSGZPhEpqsF0tw3RCKP4oNyPGlT07KsvO/EuTsSNkOJ3y+dF6T7FJYX1SAjz8CDiKJ0kU8YFDOwVaDghNgKyvmDKy0O2NJB5X4JTheeOW/jVYBJwWpEJ0BspT82K0G4Ap8C1BaT++CuGnRSync5LpzXPg3ZS/RYBlLUy4l0KWs6qtCIb2yl8JYHB5UjgnGqMr2+DkWKiLf/UMUm0eukMNoSS+hp+GCYxlKw52ije44Ok5cXj11tmAA/ugygZYQydPV/u9G5KbaR+giagYcnRime9j20cmSB5H4D3uoZL3h/WM6+0zZ8lPvNl1Wi75MlxwGLfvvgYY56sBlhnP8owFZg6tDwPRdZAw8z7epDd/EzN4B35bqdOL59MehC1C/XqrarmlLrRKlQktMdrHwmnyDazllOH41X87EmvmHAgZlKRxuoay1k+fmDUCwprntE5Kd2S4uq6fqKE1Owodmxdn6WA8p77AldhrVTpPvyLEkarvGijt8avf0BjvRXpWf3n3ETgooU73QxYvOPMKOSNrm123EKrpRBC020p5lwMyY0hSd8NQloajzfMoG2SQHJoVRbyDNM2sR0J1/F0ZyURl93PAAidGPoRToK5UwONFUo4kkbbgvRPZ0ix+KANVn0qkfbjO6jg86XDUah/TpX9//T6NLkC/vaHcCYubFI5v+Wv6YVv250vrsl7iQsT084oB5PLIVxKOOMMLqQwJyS9caMosgXWOncTaXPSWeSWFSFkmIZnDGlfGifOPq5Un0Vdu2SPqe7RF2Z4cIujxxHRUNtgOOvxO355nRNLv5XFu18GRhTqleQGL37CcKnuYl89uxg0+JhlKWFvqJeG+p0q0fcuU1fWg4AARMoxF+i+xKfYV6bp27fkvSGwf6k/vEH/NEfs1B3b8MFIL87r7RpsdsZ7VYW0WkrfU4iHCUgzGjh+17T4PuODdFRGVxVURLmq5OvTpWbnGmNaFHq2zmkS7Jkfjo9Rkutr1OMWYTpiVoe3IPSYui1vpOtvtvOCiktYvGSa9qDieRa/F0QCnr3xxo1cRjG+k9YfyUvFQoKpzjC+sVYVeYaqJ9FrxYY6HCFHa6nKiD30NvkRZ0JP6s/XqCJZvcuzhxDweW8FTuBbxRAffO4/LZpZQoIdeq/CwhJ2QFMUwm2CJkv2D1b1ApiqEfJmS9PwZPcIsX0cD6k1ozd81SeDwyBhilOyPm/lEmWiFAE4yCSB/1YSWet2JFE6gXONsh3T4nr4O4De9b32ln1BX0X6WSym/0KGwBJa0WaqA+/YSmm8xucKyTX5vHCtyQiwUkozDMGsjFZaA7myB277DxGULGXMtHdfnrUUuxyg+KURk3JUonxKYfSJ9a4FGdFqFRjG0pcnzW3uleygl0pNTqewML3T+rvR2OUnOYcJvYqzhMGE576QK9odxeVvY770ytD1qKn+Tqt6mivdipMhSJX9hr5Lxe9Sb9jf4DnEDWUaDKGOncrhiaVp9S8qTQmrmcDEOgxu6gCVqMuKE+Zf86uHI+VP4R7C3SN4d+bkOz8Z2aWSKUM0pGyrDlzixdmLByuYXyWkdDjK8dahOAaWrgr0pTjv/ZK5hPoc+vMsAOzbifnf/fqo6/gUmUN4GmL852MXxx85hJQDQbhfdZQ6+bTXzlsH9YpOx1QPKrEgI4+1/IJYYX4u4COTuXVYdj196uQdh2Dd3yoVzKINDxXUWENWoWZTRJmTcgd4KUmAbi1IvG8BsatB++x9zrLqIWiW0jFlwdGM4ug/c58XenRuEjLLoMCs/rX12sx35gzjUCzq3qJdAKBuUUyOYWRbDYHhZToIEcbvyQiqCpRsM+y7NxhmLdvKiPNzDd22ZGJy1XVdOy5hee5SdsPDhWGFZ96On0qGdEU6jEE4vXjQW/JBoCYntsWAqS6YNiPPnSSLBAEyCkuftbEM1gph+dQi5+MTtN20Ro1tW0m9817S/iP0tWzsz0auffKNXaTxteBk2fSnnyOSZNi2YFpCDRSI601rFiLxSEzGqnYpzPKqQF07wikjkrCRrBDweTVusUgDPzYZM2cHZW+hUL7MR7B98Eia5tE5K7KxvwZEqx3+sQmgdAauVdsvzQCOjH0fUnwc33neWogn0PdcvClh1tYfyYoH5t2I4Wkm9/Wn1f8qkR9H5SaLm7heu7BBDp3mmh3RVFZroWHtBY4KkrHh6gWW+7ZrY3Otz7WqIEHf3vhn0O8epMXwErMVJ0FWD8wwK/vuhIdjrigdn0gWaNfOQ0wGR5tv0HzP3xkAyu3WW8LLOaFtFRuRKTXjEcJ8ZTY2VXJztgwclk2zyawcUFP3cKsxLmIyO1JXoEaCLlwtdRSHenkC8NE7HWu8+ZzIbtZpNG+RywjUCymMUNQiMan56be4z0mz3Nv46fEK+ypmu7D+4x+kXJjZwVoLYEq/KV0Nh99XiAjuhH4xPCuAjbGn72sJfHXF2983t0iiLXNi40TYXzK7Dvex6yp30hrTP283ew4HoE9OOCp7IuWQXz68oOyLBRS7PohWRyaclrePstAc23+OQJfDHuMB2koKsAEX++BRI2BjURPDUQsJXbziVhAC6nlDw51zXlh1ZId/iLcVoYZ8yYcc0Ger6Gz5FpCb3G4o5AVbIkS9C1ZfuHu/9LnDxjLthnL/kKBVhruMoPEc5Jf8eIH5bCHywwSOeuoKbQMYR/hZKb1xd5VZ6WbCPZ6uieCQxzLdFUznRexHXn6cUB9J+LuRz0+/ZdI/OXmIt6crO7fdyaXGaKJn5cuZv68XUB2wSxvhX3oDIPDoPptryZMQ+4eclD5BdatdHlFP2qA7pVGvkNybX1MYpddKRVYPKOSMrX3DN7YtMJhojGbIkJ0OJ9cdtemmJjK684iZovZKh/mgLU2TZtI3URoG0C3gZDPQbmIhLRZLkCcTG73hsLNoQQw9FBnSHERNtd0t1mCyz+9ChkjJTri4w9neTsW1AgeYzQQHGJ/uUnatwbDYhIV7TaJqv8WQugPlj4OpDUJUqdDDqw9WICGHzcXPRLk1eyg5+5MEo0F669HNTj+ZfnDxI4B2tqNNU3hUXYXLhfkfJa/gk8YO+vw6STkUjm+6ZiMbo4uBmlt92cJWt7fOoXyvNl41Qq3RfWaCYVbZjClpbzFhfwiHbG8z5XC159yGQ9ZTvhgSm6Va65qpNfJPPHP0hj2mLd5jRlLavSJdeMm35558L6siR/6jxRGW07WNdF/noj7YkfKt5+g//9VOaRWvIgXEOqGiCSdCyohryGtWlWP53GczdyFPmv1zEq/TAg48barOPi65QE8cbadJEO8vauNhNw1WaBTw3hESGus1xSAO8OuFTS0wJrK7+7+BItc/O+lTrxHqxeqYD79I/ooMbZ9JN1RtJoXkDkt7CXPkJ4ITufzQRsiZyLn2X1O+LaKXPodpN67FQn6P6MyMktsjUxMssVUVcu1Ja29zQLJRKsAjuhPAAWctBN9ephjvSNCl+RPZozsBDTNUZUcNPrU5L8r4YW2M16fnqgg+woMy5Nfp2W/Yxl3NJqoN58wG2t6JkZgeo1anoaL8vXeb2KZ+qB7k7JnLBtCpiSlxgZAP51Kiq41bWYvoZYOtZ2up4gS+dYcRwQ5maCcQ0W8+BnhoQpMoRyull1upvJ31gY8JEhIn0A383PZciagGxh6jTk8kqFT8/ThkDJiRBmme/d/h9vnckayEJvq3GQ53Gs6haksCxrsNlzaqURXFzPwSjESufAaC9AiTAUBDPepcdLMijfHGYjorIDRkgt9FbX+1Yyc3ZURM0Qn2hQNJLb/QY8K7Op3y2uUNwM/WwsDaf4cVMjJibq61z+kkiOaQ9Ydl22/0IbAiYUNK61aF6sJow2b+DLspBXDhFq+NRVYhlP2oW6QPd/L7Cq6Av0H+fYQQIaEbXygsMyEp1PuSSMfqtw5GDymhur4krVSy39nWCIr90GI+NGM+k4byq+aCrHb+LQjB6doJzaoLWdiIZ2KnvU9BSFqTnjuGK3HtyZeLIhDbISxTSXJUjG9VREAyf8Y3oxZNeKHjY1LhGDKzVbX5ImcEP62ATopYaKs630bMhB3wJ3mcqbbBAGe9sNUEgtAEhUM4+ORReS/+kU0fnVxnutH0mYN5FQzTndSSnuYFzfvXSKQhykn/cpyw7CAr4t0O+1+zH+Rgf/ZS/9RoxStZ3QLNiaz5/1ygEye9BGO/fdfWinKjbSay7fLy6P0SAnaGdgXHwfaxjMjIXEyTDdD5Fh0odx7Y0K6PT0ydSXtXGvq7KXcwSiSa6xw9QgSXKVPFoAJU0QjbUS0SHSvPqFIJg+H4IQjPmrjtugeKEyd1d3Q1/ZaugLVX5pNgA+WrPo3WF3iJ8AAUjDGW+SbfNd2Mi1NnCEra0D/fUse6RIqG9W78ylYlEo/IRbMGgax/v8krIYmQCUbwSvCctRxMmpFHHMvvOMrK6PsAJfHc8vqIOetZzfRw136oeiVQXhqn55CXW0JW0jkEmpkDvDtj75alIneMWJOCtxLccG4XrVZxGj3sNLmLHKlB/AMfHyw00eKRSaRGojOknIpfGdNky/1RB1os9mp3oFGQe2QdKJrbO0lr5Uw7LcsKkzrjoNWWj7b8nGbFlmTcDJUz53+UAKFHhYWYy/66uNGvfgut77pDOxX8l1VtCLEgutUD8JZplBGYTs0n0VdE+R8bJEaOc5WWqqMwHmbusIbFfXDsqAfpuqf/d3XvVIVKWlR1AVrp9okEEpllky1eiBit/t+EMYkuF/ReX+1dzL5JIxtowwdxgnVQA2ElUjICIpHbBwcsqbuO6UCTy0HQ75gp2s7IDw6e8YriDxegn0biOX+WqyRO+5/+lnsTdBIeK9Aqw/3ltI2l0Rj1ypgdqjOpoLsA3o4zcNlNqv448bSJ2paAOc5GzZq2EG0Fw7UQKzS8yJhlAk6JjBiGvrdNqafLI2SQEEjQ/YIgmtiX1FFyfqtARx+XyoVbihVM52IQzYvf/26zDPLD5FiJmsJy+SvisafxobHWtoIu4JvCwtCn9WGQpkdK3PvxEFnYKcEFyItOFK7AbZPHGKKNvaRQ6J4pdFQi7flhzUTUtgCy6RH7+atU5mrq/mrT7hGi3njxve6WfTp0asb3OMTjFVK1jrw0mgmpBlh/SdfBHbXENHhMnm6l3JvM0HuBgth9pRGmxXgJIJzHCABr5kAN5cwy7ToFgkKkAAOeOlmBCy4blvZVJHBXASPnkUN+bUb4gYhrCEmHs68+ciS0kRhHlcfdyxqNV1y2Te1ZiXACB60HzIelLP1DQ0craf7GVKZYRQeAPti44/ldW2NXX+tpxQX4VNBlDf79x87wR7C1S83hpE2Gg+EzAKg0a/m1sEtON2My0409lpT15yYTTdz2LqhI40KsOHN+SuZGYft6M8jxtC18JOEq/a5x8WaYynuvkj+FnqjS5emxLG7KIDlnF/jucs7oGzO2wBBG03JHRcOS0LXDdcoba22/l/C6Pck26B8kkOl3EL0MMX5G2HFr4PS5i4sfmv9FBskJ4WDs6D+DqXyBeMEbEJ02Zrf9Ljmdrlg1YZCy6z8rzbUE4Zjp0S1G+SoYjX5EhXzd0qNrI54ilS6C+tctPKRbIQwf36GymFqVtFpxdkmHftyxS1Og/jlmw/GkI5FXEVVQOlbvckclSJGti5GPICPjMSHWrX9RlmZR1Ve4a60olrj8kq9CknJ9EjvL5CqHE8k+9/wYn+VcpHfTBjgq5vDyeA88b/OP9zJ3Su1L/ZADn6y7vhBfJBpo8K1J2FGwz6CaNL8XSQlPf34UD5rdNR3OuXk8QunrpNvY0XpN6im0Ve4NLinG4kTtUNBQg1eCVf21uTjEoanT6wO7dmxXKy2hrRUIZeg73Hlzm0tM8hBrXuw1s7VfQdloH2Ah7n420aEO/WCq+2DppvW+wYqZuZtZmrNooItPBbpkMg9RC8TGqOd2gMu4YTo6jODojIIjgcwWgwDTg/u7xhrUnnF3QomhGifnDpgQRFGqhSn6KImuxpO9QnFHbYp3kp4xY+id6uFFey3snKevkx/Xvu8PrwT4agknrp8WvFEBsH5Yg+Nny1lxUyXG1kPtAefcRNd5TjjHqdxiGwV8N1FCy33uZ0dVIfQvMvdK+J39skZ6kPv+aT45/lxVlzA7j3kAvY308+dI+x4Yt4qqZFhO2636kwZFKCAROfBJ0mxGiHNaZRwmhYgSDdb3cI8KQNLX6X+qaFd/7wGiikZzyrik2+iUKuiJBUVyb97puXoNOMboMzJmqrC1AFcGb+srI143AKU/yflPVVmxEmHgWhdx4su1sjoOmfRQ5bAf3iRx4rZVEH4j1eKzLWSFbBcUti+V2Qf7Jr541JI0ZvEKBwD5VMAS0D5j1kSoD3eFGDSWIKcQsqqu4v2I40aGEtpvnLr6U8SFl5YJCbrtru+/A5ac+lEUO6J9NQcv62JtgJGdwLnC5ZEBxe7EzCn3XKxgrh4KriiRLU8HjhEhu7QNgBrW/UDwbDXphkR8BDebhpucNPCOYZlHR05V4pK32OSJElDFyUbw1mR+ya/BtNLfYXMSVxocpFQMN2RW270yvpANHwZFYB2O4cZI5v5IsuZUxq43bm3iRjr8NKto7As1L8vP3mqrb2g3V5a7sQ6d+ZuIiTkU4I/DrIk7fnR6taWuc2nWzn/eTu0CiQodCbdjues/dbgDuf4MPbqviJOISEDsKSOcINZXW+B/u0NZZpm8bMOBk6gN+FL4H378VDLY8Ym52fTDc0iY1X8k9SUtV7hJ5pF+PtsGp49oujiXPx/GpZOvGnfvf/gv5Vh9mCoj/zF2rozu4mzxLE8mZ/L91SyyNR9Y2cfFFdZKfFJKogiIZyml3aZoVZ/dP0EZ9fVlqzh7OxT/E55WpLDy5e+PE0BjnntHzf8vxPya4d5D43h9tVaLXofNECLUwN0Fy70MYV5wdu2AZDOAnTIfZ1g6sU7tmaUhDIJnZUqYstq8fXXGUl8tBqaDRhiD3rijsDRh+P5gDHF8PRmh1Y+qgKAJ/j4ndhK3fw6VeulNeRyUUj8Npc9OmCgR/9Sr6dkyrq0zaZNO6OVEdnj/Ml3VqZifviCNLVQgfKlbCI9qWhDHvvMeJA1tCJrFvpMMigHQMuJzNtHebRoYKYZSOZFCv+MNrOESUe1tj7Ey27w2nYfQ3dLaCRjd3tzWpW7vhrDUCkUAoOtwVeIbV/x7SV4FWT3vmvFN8r1DMFBCET49bDopfxl1qZPHESWshi5HEMboXYRi+++dtbfE6b31eDDl0OnX4sOX8IH9sKiuvIA0hcehcqYrpUROLVTlUAxzcPVHi9kx+wZAs4MTDUHfnSOGUsy3R+FjlKI3b3OWQ0yCQkerm+WA5yJb5kXZ6eJwt20WK0aoae2AWp4As+1EefGSAs0XZuxmMPlm/zVu4eRv5kqgOWvO28Ln6FkZKpxx4UfYtbi9yJz4+GljLR6jXQaQNcIc44p5kdtHcYxBiboYKRjqyOQlL7+CLbdEG9AMWbKF9f9wOOXhgEeNxmrEfbB2rBPaNFW2FGiK/WQ9SiQfUR6SJ+uHvqO29HoZMY465d11oLWMCQzt08Y5nTLgZDIao/q42JikLPZAk4h7X79LVpHraj3ADMGwcWHKS0etiz/tBX+q4RB6hKBbjU+Op/HNQWUdXzdJJiW9t80+X4d3KOC51r1wZzmOEAWc/N6Uh+zfxu+Wi+8WmCe3EGggFlsIDJ1Njp6OyFLxf3JI1bZV8v3GHqYYpYJfdKz6MkowiWzYHpoE7mGn5UfVMBSkBQkg+dqJmfOFsT+OTpHu0aOHdtsCG0IKhLtz6FIRrKRgwEF6tC8ADq2auxMMaCAl1ttq0mbYf424q1WgZHPDaINdH0Zf4I/MwW0zfUQ68QxVWZC5e15oFQb2QGllJ9AqdO0+DqFQ9St5mZJW1B9p7fjOdYjGnM5AbOpmoqxYcODwl0aEoUQ+/vO0JG4S1IIUa5tLFoT6YQ7OMmlKkYW5vOMIeTayFaPdk42DbP6/QLwld1XjZ+itmqVa7J3zz4HOI7GQ76QJYXk8+qhQHsuK1Q4O7NRd4TF8fwt2GBdsIIXZn37kkj63cUB1BTU7dFL7X9nKp5uur3OIINedIz36iJD6QjCaxtr8HiZZonDL7xEO4fBaq/WA2g+2cZWyPXc9LRLa6fb1fQm2st0J/OyWV57wWq3RWXxTzHq84R/B5D4/V7qFlUECM1ZL86eFZEFYAL8DDXYCS4JizSNBPLwucZQhe7qParS+5vn1P3icTY7EeARFy3nVw2hPiMsRZP/hLaYTWB9IduuaTBzdrMy05WNw81HNbesCgcm9ePMxk7OuogEpnmwR8AlZQkyFGvI4X0JnzFmjOvQAE8ys2jJvE/cnnJFd0TKCQkXzhrE/HM3WQpNUpj0fbwYdI13bnASa5RY8qAlqf9N1H0dP/8yPPknjQQ5qCbObK7BLraJbeYo707ANddS5YfsmomWA72KeAtE+EcjOl1SqhP/EK/gPUkRKAdTHZqu3eCt/0Amgf6+xq0g4lC7iQ8JWc7drNFR2K0ltFVTvMAZPJHl/feAF++j7Pd2uilC6w4+arnwShMwpOcWWQ0UkNgNxpakTvAP98GoG2EFaQsZAIgZx08OaVkEQZXL0eJRiDOoe+lHnnsrAymgUQeOqQ+VpPkeK/s1yBdCjN1EKDzfIyBuvTZS4vhpHJ88nk/d5T+lqJ118xQZOTGoLlNto6sq6JJxTuRBxN7rzNVkOe4xRjK1eKBL31YVPt5mckJPCZ07mhaIND12XiAbeFApo1nExkLX/ItGveHQrkfeueCatqGGzE9iwc90UIusXaovrtEuGBW8hsh0fzfZMpKu9xk/JIhfbTCEqAw0gNIa32pqzzFC6V/6i6v7ByJ/Z74Z1aQbYY4SJosERryj4BUak883befQi4KXMRXDoSKc25gbcYioLuASn97u18I0DnhK1sXqx3ks5KQaUdnkxVJfpCPBX8erHIr70Cb+Z6YVywaiaG9OBnqwFmtvaf7QKXZfE9989/c2Hp0bv4verLsxeqXeBnJiwL+M9PSSSB4bv9rGE2ui6rIUH1GuGX4lMKt4ZlXJpM+tmljtllu+IgZnfnPbpWlN7P/PfIdIYFy+2NTs8H3lqnkMn9cLYTNTC/1Kfa1rQdRM70V31Q9Efzr+0n3PDjSNGCqZy7jggEhHXYDiRu6VxqPOeJC8PEesfa7/ldkrESRptsjLGKhl42elHYLdmPIe3jk4vzUfL0cADKh7ycADIZBMcmGgjd1yp7oAnPbcl1Msjrw1EDo+OkKMD1lNVUts9XykuI3A9mIhydG6A8S6tNAtTlp3ltfIjqaKTmb5NP1RCIVXf92bPSWhPChxBlAK5mb8buyFwJGmduce2vOY1oZMQ7Jv0lBcUV6SBHujepP2sdkjN97EOGyFdLklcvm7SbyP6pXrkcG8YXcN/rq7ZM2LM5elTOVuzzNoGpqv1T7i0eiop/xTBhSpk3dH15MHr6mV6uTc5WdACWISn5D5hWiA7sS8Khv62C+WZG5ntN8Wf6Fo7yiRqN/lmBhNmrDXUZgEbDh9PBRwZUWgL8VmK1zZEPYzULBlCNnXTz6DAqU7pACndaW8zV5ozzaezeD9PtlSsf5Y8SwpSaNrHwFb2iCVDlfkhT4MFi6W65h0PSwOZhET2rGBQ2AhG//d7PxZy/Eg6kuWZV+6QHsns0Z7PBKTX0MSFtCtBglbFqWto3V3aM7AhoK9MFgifNBjOZXOv3OsSpPU9ajl4+ACcOr9sds55k7QwDBKU9MbDL379ji+6XswXHZyccVpb1jGGazRP2cja1of9Wc2rlXe41CjG84KMCAHlLWRy6Z+ATPbMB1mCaJaM8HkH4dpSE1oyiw/B05poVDQzw63UmXo5tDGII1ShOP/oBBN7xFY5K+1B4zy61m0Kwxg9gAAAAF+wVyhNsMQE7AVh57im5RUE8mrMecIEM1Efio+Gz4/DGe6Y0ZTNnD0YU1Lue+1hydKftHkUIwpTXU5dzMtsszH8Jk8sK2SD/cb7eqGepeHm3/pLmZLzLjSwJ/PQ656vrVbDlNsARvgd+HSDlwC+undgI+jhptscyfoNaC4oKOErDWPIdjojZL+hM3ga3samw0GezYBF++22j8RBmddd1CN1FViHugtzEOnukV5fEOo2rxUuT0qKhgtmv2aEH4SnN4PEAYBDyQX4idQmPUmpt6b5xMC/unbrnk6y1FzD2AXM+y/g2gHoADP3fCAAAAAA==",
	stonegolem: "data:image/webp;base64,UklGRvASAABXRUJQVlA4IOQSAABQQgCdASqQAHAAPnEqkUYkoiGhMddeiJAOCWkA0Q+rXvy/LfjF5k+Jz3d+5+fFhD60NQj5f+Df4v+A9Bu9n5C6gvs//db0Duf/A9ALvz4E+p34i9gLyt/6Ph90Bv0v6Peg59i/4HsF/sH/1ex16RP67LL/0x2nH5Uxr/AhwJObHSyq4kjJYuUhZybkv+utd0NEp0h6RkOCKgfwXf5RcnPV8ZxPX2OmjSgvrFY86OsKISO+Gmtc5VApbqOe12Whko3W9PdxI8tWjug+kmz3PGsdb7ba1kNcTnf3FlI/2Lj61UmF3tZ6lKFpb94zOar6R5hAUDWodSI0ZaJLrjfTTpDbAXREEPIoDUS3bTudXu38dqi+xSdaQE7Bgfv1BHw/zTDq+0fY5/fqCMKbDNwtUU76msfGqMws//oiIS5UZCgRv/wYz2PiJRKvb74kyEXlrTEGevR5/eVL2ZrKgObhSGGC+0iXrXBqpKXNim/dwU4Pxuf7DC0jibWlUE5i70p/M8erkeyqH9vxL7mxJAlKToL+O0FGciGfYnL9IdXHXzf2iIb69+DBHnB2pBrAYzJx97VRzGgknnL6dYxibSGNbkgxOZrLO8SrjOjC9kqkBpNYTK9yv3Ys+TC9DpJqwESse1ZOBmzx7LSriCxm4X++uU9gw2utz09Sm0EQiTC9hvoWIW7lW27TNPcpXRlj5aqHu0/A+9zLW1CGl52SAAD+/XdtpMv8GhThMGbLcb9f4Z0Qc/8Gv5ZY6RaDs00G/onH997eVuPBkyYUWVA2O8CL0W6w8K0wdZezPXJvvJ7FGIbYAz7pzsRcg/5sTFTJxqqVVHgdx/m0/wMkka+p3zk0dGk63QvrwOI3rGYATZvf9nh/6v/+oh3o/vUuKduUAEmq1qO8qRcM1QAynvV7/vDunL2+EvPeE7UoOrIXwDRhf6i16LFHf1wYB31xWt6H3LwDSYcWhg/ZQ90jyol7TzOnyK8LTfqWsIwZtQHv3Xf/4wUH5cBbLGhSxag4GSlTLaAwCz/q4kVwDz1RtmfmiA3Ek+1G9Cnz0ciYPOI0bqGA0Z6w8W2DcJjoehCH7vJT8ekiHwlurU88Z8xzboO7Y/NiOj5y9PljYO5Z9A7tT2IX/zUb69nr3KeI6O6/q4YhoT26rWnojrgfZGsUsaaLqC9VTf/2PHAB/6bEU4cqaYvKJ45hp2n6CmfjSssLO/Y+89/P5+da4Hmg/0oCvHUu0m6i6ZBLz9vDkJdsWwhUEW6I9MZg/myT9mvQa5LP29PYWW2IirfSWT4XYmsA8vE4b8LS99Lt8Z58sL/lr0BKDB1XBKKb3uzlRUxUWLlR0j6ISOiVe9m6qgXa0ip+SlYLnYz1Kr4uYue9sSCoUp3FONJeDxGMwenOjPboPIYzLD73oIy8yvDQu4ypEZ3IG4L0wIKerNmKnvXmdZWGcva4aVpNWaw2Nu5nfdcLlbSdq6Ccx1vCX09J1LbPW0+XDbts2oxMJFKf7h0sIft9uoV/bJY0PsXr/xYR+Xj25if0/5nKKM/FoO6WRGoArVuHXp1/VFemXa+v4mWFwcMUrJvfcW3wo2eiA8MCggADDVabN9z3L+LGD57ZnO1/uvXlRa0x3zOXzma3CglYbUJ9pHynOGP5MYu/KhRpBlExXGUqWJzCvJueFu9609Ygcd28V9XtbAh5zNxEe3HwJNcZiqh7H6o9Dta1cIq1bIe7/4mT+d3gd/7M2lrSSirt9mrkIrZ9PodAqwIjTguZwxm29HG1Cx6NjR27CWO/7yj9uo8H+FFRMJoh8Zjyei3DEzC2ZCIb7Ng4BRXYrC8pbdK2SEFu3NY/Wba5qZ+FKgO3vrNAfoY8cElgP671QeY0kD4398i8jzW9ewDaptocKtFXUGd7ji9tNOZIzqUBATdthvPAB8lrBLKCOhM/qR/uqXAdKo4PMuJCc02wpsw+tv5WzzO5kOnKI8TMrCmjOfQLzgdcbY44B4mr8dW+MbjqBeUV9+xI8Eg+YxLmHeAs+qegDxQhd6ykRqZG31Z/R8fMf1Sy4n4MpZq8v5DQV/I1Me+3ePNjaj9TzK6Yxau1C2swWsN/g6i7P0KJ1Do5AFkYU6bYq2YggKv2DpHyQ9DaDuq2NCQkVo59yH0F8BSxBr0q9JrslFEqIkupAOG+VtopqUGFaeK8uw9ixCfU9tlVpBbQpMnoWqIk47zKLffMLKQgKHpz7p2+Afmyoiu4uT+hZhdWYvcpInD7n6ATppxHgaRBhFCX84oa544ZAFUDyVFJPe1dAg4g6frjGUszz+4Ee1lYE6G/7hfQ2mlMyj2p1hCggkwrL8VwaQal+ID1z6Yl22jki6S0ZArrYouUdlhzzBtYeZ10aWRuEqzr+TnixFWaMBU5QBxPziipEVzOod8kvjtNkc4NYxTJibdGxrVORNzuOG+cvWPaD3qDKTcIo0nGLaSZhGDtBf/1HOQ4PYZyU/7e+B0kBU3ikAPJYxh6lDfjqD9VJ445SlJA8eb7O+cq4hsv7ij7OeLu8ehbWG8Y4/TQf/ycP62uUYLkaQoTC0ucKKLUD8l2ojw/7i3+eHNxQ8qOuxfwV26CJ5gN9khzkGI7oUqIIm/weCAQIyVoAqiOGT7m+qS0ICZwbG8q+k7AbHQjJTwq2hdDmxpAjDEA3g/uF25+EDRk4EUDmw2wZv1h/q9suBSIRZBuStYjFsoMarBqh7G3es87mh+tJwEiabhOno+I8sESPFYrhIAsevh1bztCRk2VQoVsup8pyxP/MJ74DaRLtkLlx2J4kFXynJYfMvSCn8mcIDdYmDqScsvcMBTSZz4nN/PNntCxNuGxShX1fH/i3RIg4MM3lPuPJ1LHV3B+Vv1214wsEilubMkK4FYeQKUIBTKb2f40iG8hktjpTY7MEYR/6XRFlWma8Z3uzkdBhnDzYgkN8sHIoKKejuSct7eDdHiPaRhwL3pKlNeqhoXDb+g1mYwBAwKS57NIq5AAYzdBq2RQXB9TxussBOaFWZV3S0Vw9IbaCvBZSRLs4IjfByHd/IyV5WQYPrrVogJHyvdLCyTyoyb9h+IvfYUYCkDvHXIVsn/G1axfHaN3zgGRa0LtHf2DwmW3yyIyuA0W9GoV1MQIE8S/OdXXDeNLWWM+Wzde3S/6LE7M4q4b5Yj3vjTP8Zs99ui9aJKygkOej9uUo982691u8yYEnmkZbkRjrgywVw8qzkk/b1ybDeaeBveFq4rsqbTrPVTtWUWi3AeowKh1RrDGZTpFjcGp9qpRbLXNFyWo0/Tp7ngOP/FEqmuFcoSCrUhksubw9666Vl4viHP6J47OzGJu+p6SerjbyJ7meLNcg9NmO1i8CZKbajMuPjiGrbJqXAJhyYzJHY1htMqu/I3Y/sUMaFrzbgW1OXQl5gO2rOvaFYPq11/ctGbfMW4vtBUnqLLFFVlX6TiRxwoIpY6e13vaX2E8CooscTGTFlrVUxto0/BjrsQn/EYrPzpB9jNgLhFXI1e+wfS6sgafcbC45bdeTTXNVZ/JSofcESiWYFffx7N3nBYv7SnLHIbiCyZHIVGg3KpuMXj2a6D6HFfvBHeet4/Ms0l1daxBvMmlUjqo0sR1Z2H660sWhEAl95gJQ2yF9rFxPsURU0T6k9XGAJEYdBySQwSqWlhnNcmiljh5tTjrdC5hqEJ7cc66iJuqXX5Bv5hGqgM13nwlxmwTpV2bbLJQT8G2WWCpIRczeRzPN+HsDgwTrVYVolewbyn8qStTniT+KlXVMvYICeM2gI9CK8w5roVj2l0jZkovdZscsvU9BAizDFFQ57jyQsWpFuR58VBhPFjIrTZatnfYwM6mJor14ohBCkOzYpgEA8pEA8pgwBqNqMY7Meq7s90fV4eDP3bnsz7ZgHMkrNVHShZb6Ph5VGckvWuOgs7rpFsEzfQ4dAaRM3+N6FXjmvz78dGHMlJ6jv178QGntGL5sN917HoOaX5s4NU/mAHA46raaETUYuC0fMfI4Ij0UOCMn1vfCWWlbQ93OkrRzcc7gHj4QdrFhfEQabVHPmV3+7LmsNI2oBcZ6hMeH/TdJuog7CfZ7UT8xG6BT3BY5bYd7RMVAaL7l+DbAH6MslgRprG5Ydh9NyP3PGQDoz9HOfDN/W0ibCpxDveIHhhcbqwU6NJPJl0sCeML/vKXGwK4C2aVC/FuVAp/41fznLeNpiaw6cLQzgVl1yyC0JFnKOEpmSL2FDAS1TME0+rAVAw/+RIrcZdvqzdqlYhOJ5+Ewe/zbC5gvNkT9r5qksoBu2jSFwzlcwCGZCqfbybjlttCKoVvMjMP63wt3D7GgQlqr0EEy09f/8j8YkaQrBDiM8U4uhzLEnrgxxtxKuGYbaSL3RfeNcxtAffQKGij/LG+S1XaXV1Q/u0V4bWQeGde5oNsopEJ7TNmhmQ8foxuFTORnFtLqCDSKfmcKWcozHduyYQSsw5Gu6bVnijz2X0+aqs/FShaYDIip4cOaSRdkN6uU3DU7nO9sQ8k6Xi/UXq9y1oWBVOgUuFpnZN+YdKvjbqsUOHh38ZaaDFtJzVZhjw6QP8/1GLqysq8vfILcvXfBkjKQWKKEbzv+uen/jzjB/9wsWO59YZSTgxi2YkAdtwi1Z5JX7yrekQKlXyN28/D/It+Ww0KeOm5TBKZeC+8mxychHW0th5bRllms0EUqnxiq79/yOiHnSTiXnKy3SrDmX8ves/a9HO+tRdUpMkndnqaG+9UYK3WYWopV8311tQwppkl8QGNYRnPgssk3eezy3ruWIf86korXYeO9XTL9ojGVAp72wzsJYfNOehc7KH+jrP8YW92/wv54jslbKzswlV3s/dmZgeI67ZG3PbXnM3yfVBs2neVpXGntFQy2RdTnLJ+wt6+vsqN3yl/lgAuH75H0p8qQZrpZKVpbF80LHH1zCWkfZuJRTDd3XRBIQDpi/s3y+njH+NQY+kqqj/7XYv2m+JqDTtHQafC73GbA9BN+avfdppMghhsogX/NtFrE8RR1POORPKmJQl3Aw2tBgUTi96T6u/mnSjdcl4UQF/5LCWu3hMDss3/ZMLzRQQGvCiwUoivQqfE6B771zJC+gwFq0onq37odewNa2lYlXJucdsz+IrHvgTGHJyzWfJ/F1zwZ896t9TyehSMFFThb+81kGDV9wuou7a7A7tXN8roKXu3iBmtIlFn5IpzDWdjMYylVDYnATVYnh8HkFK2b112ODAHabQjUwhPc02CA5YxPUorCDqZjVA2wMWmRwrlNKh1yKCZIC/POj9/hLZr56xdAJR3784KLMIleqnL4uwGzvX4KEffz28XdKMJc3yxn2RVdxqGWVt6U5nxVjQ8BmeC9uySe9RCdgrdRjNUUd7vEqld9KtMvFQ/te1h6+dr57rE7QlWRK4ID7FBarQyR8TinOF/7i79fVDl1rKO41jBrucOGj9Sf7bMOfY0XHZdi1zoq21ieIE8GEJ/c20yudaO0oRlvXfUBjmh5z0tdTXrirzXozaRre8dtkuUU5OSZ4W5PrGXQYWWyANiyYHYG2XG8kDa+Ux2p3IYt8Q2WB6IAUsHs6Ryt3P2WTvj8qeXOoe4Hj7CqitF1pt5/emAOYq1rXKp01yIDYqCP3PGryBnFk3jcoc4vrEsv9czSGo5jumvbIZ4SEKcMOHBv3cUtFYTbVcAZz5Fb3KK7cg4rKb0+pplIsDAERnilpKk1W5DkCCy04NCcNlQEfMiRQajQIhPU3ZNAVAtonxFgofKdpLpAe0e4O181RIZjIz1hzOYZhYDYEvUWOi2qWyQxVYDplhVfWtwsoePmsSUqeZbj4lsVT7MTkl7jYJCcHUeiG0WnRQsnfOA7WkIwqeNVQk27obw9jNS05w+QxD4FmBbAEZalUUnUba6tFul+vUlPEtjQwwbmrEN85gtxTY+iFiQRZUjxVqCmPgN53x7MZYb6gDE0Cg83GJHUBjG/xqEZXrsn6IptNdAz5D4srcQuPG3F2rXUT90MuP1rO8hEw1mIEvHSbSrCdZwOjc5mtB1HKCNAKKYpsPzK525AODUfUu6NDfH1sIUBQZ9L+ZdJ9wZmwHNL7gL4mZhviZMXbEIF0bzLVZONRMDLjzLx91UyAfDc5JXr45fCSJBe+aUlgTbrGNHcKq8XpWQYAFkI3wNk5wSUHvU4EcqKymoUUAsU1RnsLB2C25XPw1p3uPvCzXLiZ0thCzrys1YCeNR2zI+sv3UjKKXCghFVnJl7w0XwRznAqjoeJn+7/2Q88/qfMJX2Rgy4ezC6pJYoIxE5Hp50gznM2GDwWv9BX4Wud7CAuXmTXn1g3GhlmaIAVk3BloHuRBjEGCu4qVnPX1sYaZNqLlRQ4JHC/vuUGf2TtIChGwZf/Djeg4BFQxcje8Clxj810XBDP4dYvZ1G4fXnRwRilVFD7puI3k437gAZh0iA08yco+soTa/hn6mUPGULwhsgAA=",
	tantrum: "data:image/webp;base64,UklGRqYfAABXRUJQVlA4IJofAAAQdQCdASrIAMgAPnUylEakoyIhKzSdEJAOiWMIcAGV+in7zqc5Z945zfXrsmNQAjsieljcM+a/zSvOH36jeq79V9APkj+m8K/LP7u/dP3R/wPur5E+z/Uj+Zfij+Z/hPbb/d+Afyy1CPzL+nf73fjwB/Xv/o+lF+R5y+ID+t3GdbbvgE/TvrB/6f/x/2Xo2+vfYO/YLrbfu37OH7OuMmmppwtk9f/WIvo///iahxMFFATn+Lo/ypLgBRiZRq8x0tkCSfPiOHG221tARMH8jOzVzq+ZZABXh6dvxd/+pfoiAzf8esioEN1Gr7xyTNfsa0gqGQ5ahYh2y7bx5fTZ3u0HZ+hSMyZR4FZ1M0g8Uz1CHWMqeXKa74sfGn2K4fk7g/9V/x5FPrRC2iPLOLCFN9sL4P3UKgbbgfx+oo7nN5WEH16bvtVyurvdQny6IcSMGSyh5chJL94izAySTe3Oqj2hb7vT0Acahx9RCgLB8nIuxhU5oN7b/9xJePAqn3Arg/sz1qNDT7oRNmfcSzG9C0zaPLdUw7KLhOpmTxyxd99tWzFvoLPLwMyGf9WI5XI0FDnV4V5puc+S5b61BOW0Ov1Fece70bTqCTXFM34bR5kqmcUa28T5+PC5PONGJP1++14Cp3JKeTHf7mq2r/BpHfrixU+XkdUFZwGr4baTfUXtRWc2XbkMLxmm4UhPdva7SVGC1INOFsSAcyBKFX6eI3S0f7eo1jVzju61CVetCGPwqg5ifX6OsnH8fEUVTgIvo1cGtN9HjJQoZRpDNKn2Pfszf2ct7syS/6wHW3haQu0Yx0XkNE0a9/I5bZ2k4aolUwpXduy9EdfqxuwSAL1pEdaf6aRYOgFE93Q/NYs2Dh/I9d2kEVTRGEOtFh4or01zauSU1UbpiHse+RBmMOupvJKpF+fp/mV/6q1kPjSdZpXyC+RXXLrbZjzwwlekV8TNdUI4c19NOJbanfB1yAMqqAy3SKA5N2nSANjVEjekPnIDbXlp5qDT/eRw/gIOmM7Tv2ZsYG3EBqLK4DaKzbkIFm1L21ylO6uZgSTDk90/3yFLmlq5K6Vu16HLRcvqrI1VVDNPZYkm8qcs6nK6js1WhyX7orbzufK4Cqs7rrasgy0gJ1dLhE1/GR5LRFcYhH6cjTIoaEEuscqh+dusUA3mhfz63kk48Le4/nD3WTx7C58uOCH+wBhTNwofyuJ9+hl8DfDJID4sZRV9yVCAPQep3h7QIuJRNoVQP4r8PlB45yNJarAA/uTdB0Ln6L+pbtNl+KgTn98RfPh2XixVrMz7KW39atpLGEenmA+zfJw4X/OHNUZmQFdMgB+SeOBBQSNz02TzQT17XZvjl/Q4+MulnLLfpL4o3S4xSgWf56QOHeY1Jd/77b2a61laxCK/ZweRDlRyKAYLufmElfEAfHj0sBfgPOzi3RG6sEFQgzwpbqNWaCzmYbuy5AsbmSX/HY0hO2dSxBhqsTxrusDXEdzkFf12tRqjXUi7+Twbyc1TQUYvIt4RgMP8Ks2SUsEgGqcJaX8nTph3v8sqd5Ac8kCKtbua6fNR+yGWlB8aVBXAkiyQMv9Sg3W1Mfb2dUcyAmwXlHHyaQoEAjYndxiFUUXi5znN5NuiHqUl+cQr9Skx3TNvvR/pNt1B+jPvIvme+f7OeaPNuJIH6kabYkNlmwKE9vDCF+NkWK0yXUDLK0w0rW+zgX8UB0qjTwt6qmifWOTXhBJsTF6pnUlMk+M9Typa2Gz299ALeP60IFAo5kecsXUQ1d9qbAO2j35NKYhJIFslc7zKVybmTq0LbTMsXRObJrt8gwBUTwTrNYI1a0YZ+K5T4WwOApVXosQGchdDqeWa4iwYZ3aP9KP0Pefy3nqep27VDWjl3dbtDJDQu2YsylMmiWBFrEo1zMdVqbMGbI6HB5Uc6HW4Ey2mlPXaW04kFrG/wssz6suvF/sP/JfPWTRu3fNP+QK6swjjh4KhFeYeADr7R5E37y+ZsM0cM9HHVwhLEMrQqVMZl5EZ1PpL4M+A/qXJPjGirU3y2tztYNZtFvRP+ksSb3gh73iPcLsxgdZ53pS3AOyb0BcveZp7+mXDBzr4RirPD4oLunbBcIEiRMb4kfv4t1Yhz57Spdez5WhREk5OTTCMP1AbE0ykxyFelmsB1U7aAzSspsLdzjZlTQky+23zBXpMnlm30UwnzAIMWCucFs8xXSbKcbRXiug9m3jchW3a8EsYISzOX89Sm4A9kOjvxdzpMdehMHB7Xe6TMnz8O4hu0ZFSoWUX0px5iNtrIIRdxJqU0M5AbNKJrGd7h4UFPIbpd4VSaROTVYxm4rLKdm7CyXpUsnBwjZyX1HbhjJ3OWJAEZg9s7CSZMRKg2Cq6F6sAXrq+74JvJasogmv97DrmUv9nsp0oWW6L79uA6Yoqh+bqNf/GLwx3ax/DoJecK5hmmrX98A1Tme1HoVlYafruV92WGgHxIKLxoBYdyNmkbo6STcPpYOkOgyXB+YEAqXZ5fgXiAaye4iJ5NcX8YUxpWls/nW5hZGWeBImymUJxeja/EQqRSNdpvFjWwYfCOmtt/+ChT9rJr91Bq8JMutmNA5ma2bTHUc5zsco+So/VhGbMMXGE2FcEWeiCZGnpym/kISsnH3bEf7K5hDAqAcrAsD0UGeESHf7A8XvfuXWf8owSJgBQ9wQAl7vc0JMEzKlOzReiP/vOE0U1Ki0wvRmBL5qZ72v7yndv1eS/LnOz9KNqcsFT1L1oWp85V2g83xonEuttdCrLAnlmSFXx26Si3Uyun/fTEQjCyWM3nq/5HhhKmL4N4a+B8lzjtr7mem/BQF4c/2gxZqe2mdh6AJooLRUSHovKEeACbDhWHU0lhkmIFaiin1AK3chImDonVvtet26Fm6dZQ09Ghuc/8/xP2qt8KxUHP6imWCr7Z0k88nnoce+m4agvO5qgtiKM1nPYymHaJXtUMKdVvom2qxd2GezcdJ1jrUjfVXUEc1l8s73zC/zLwIDppgcCWDAWCVhZ5AaV5Ff/3GF0pffxP8Y1Vh6uSSzFnRQNjsqxTE0FKCgdK2hlflL0oVMinq0aeoZ2UXCR9PRVYIU7xg4PzzTw5CW8zmgnq6haw1FWHpg2F2RtU28QFNuGjHDzjsmq3APdBzNo0Js6CDoSJC14VbHl54oL+gJaYPaYcjRmTqobBVcxNHpee95taFBJOjBa9YEevMErc7/a8l3XNQ6UT5UDBUVgXKrFCORT0xo+FQJwt2dSaVj0598/xdHUTR1jb0hPi+Vu66av34Hc1mWkio8yjem96kIFP801KoRrx0S0evqdHZI+bF2Z+zCbEdboCLpjbUole4Gy/z50L8noqkRuQ9GDAhtFT13R1dUIE2ibx/hW+P7yLUtdKN3gmJFCx3e2gAJFfBOavqPZJxjzWJOSZRgoHq5amJ62Z5trg9cwXk1vENFrfNCIGuS7tclmwdJnLFmvn7V8zi3bipV9IX9k6haqryMtGUNHFGex8RYJ+kY40C1p1LpefMKsEu8dGaixojTd78TG2KA/sONcesZkW3xxobAawDl15jQCvdhNDtOLJIZ1/hTkI+areJoD6m2sG9NWDOZQ2gyfmISLiiLuDTCSaw/t+6ZzUzhJ24VQr5YJt2SHSkwOx5KtCAu8w2m/UogFoGVNdNzrMDmgSysKo4PxTsJ6wCLPdQS4H15ADeKl3xsBu/hoIJvi5JOJ8aP4xsMs94ht9JU9x9D++tFtshboSyZ7BXDjmH+qp/52m/Tvq5n2M8wl5D9hoxIyN4TWL9JutzETIiXg4uqfxnW7X8/dsPp9AuHmJwQKOiI9e2Z2v/t1mjGn8is8t+/HYBZPvAI753lR7SaZiLu+Mx7KLNR7jw0bF/SrqE7DqnV1L4Hs3cZOv/fXBWv7kcegO3fqzjD1Y9Jx8yvTjiWLMLSJ7+UzzhEbEtimE0Bz5xlQZaWypeo1bSRR7zhsH+toz/AybZQ+SCm7UeuNKgQ/+RAA/3ceTpM0fVu4F+RdA2HNlL+SWOfZ8HCZk6s/7BmNOuPnT8AlFhG662Xt/yFFXDLsa7I9VTzcP6yrhRd0sJ1bcnkp9dQ7IJiVtUru67VReWSQVlq0DSk4cO1favtVCvPasQImCw7nPoqY2eZ4L/8bLyg95a5BBjJRxT/Qznxih6WbpHyJNKWP8EiEOnDIMXwa3Rcyjl4ORdXjUdz4OcJJMTUCNX4OfSYL+9bDjaQElAqdy9AaYGcWazIhX+NWRa0hnQQNrmQ6aZZRRujMoswqqb20GdRiH/IK959SqW4gL2B7SwwuZgZ0FBIF9OmWuBoN0gvWpvwqqGwCGpmAIJN/vLkpEkclwqv4PdwAPMukOfjyupNzd0OqiSkeKlTAecYhbW4O7KkpZ54C+6WQgDwWOzf1Ioijwirrkv/Oo7D0O+sutCnpConRW48szj+Usjr0JZqGCOV1XshBCtr3SULyYlN2PFLLgpKAxWqSRKJJQo75fb9+dndrp9D4gx2TFk92TzoMzycajf4uZyjtTbXOkYxw/4kdhRgJCshil8pHYLiA3pUoCuHbsIlOCJny7EjN/nO06P4li7L2b2Y9EacthhBGKgxQDLf/Gp9ATSV0l8OaRqyK+btIRYm1MIV3NRHC3aYwLA9eG6cCqWD04MWHks9oDBCL1RrxQbRR3JAKFtVKel3FkTD1IrNf7s7P6qHWtd2fklQZv/TP3G0/vjlHwwzW5EE70LKYO31dOrIhYmoU2IfJJu58N/2OPVAEA2EbOzQHJyGQIBJR4zqhrA4EQm2MxZjBx9bLCIn2wcJA/aZcSjGp3ucjWG/m59qlg6XXKOMyA4dg3WyJpldw1mthlRsY8W/Rxf1MDGt1USpWff8fds4eTD3eTAFAqmafm+sekhjI1MUKFgiyKrsDjIMRTvwtl7/CV/Nvwy05NpYXJMV0T3V6yTvkBjHGh8VJwSotwHfuL87ewHmCGR/wZcBQyjdjKFOe1lYJ1eK59KvD+G7sLBtPwqhbIdlOQg6fisjmVBLewudsAGg2y+57WhycWehBdeNvz2XRQ1tZoUX+BeM17x75LfEL4b+Um8Myx/q7w7Pokj8i2dydLndNSI3hbcVixJsNMGLs0UeJlYSbZaMcXJu7Y5Ai305uTWl/RoRPSIivJoaydey7o9UhnU0c+9oTlWJFyfb2IeG1v4OYvdPNKQuDjxmjcfARLlaiA6mhPtOhQZemO56hhlZ9Jthn5+R/SzrvLO1MmAHDNJqfad57q9JWksppQXo4p6UyecRoQh2mbjnRJHVIQn+PAK8WBX1Wbl2R9tlQ48YpoNvStl2F5XIbPMc0O5/YobkBtzOhDEewqpEVtwNVYLQBogTbYa5HWmbAk1cKrwFh5d6SdHXcBstCb9O4rcbStWSkEF5sZYKueB3yWRZruJ4uhLvBu+qgph08Q7e6w8NMbfsNHneS1DutL71f6gQOqRJHNW7uHwh0vahtYbENy76FBg78ipmYP9g9jZ8FYH3qH2gBrPHeOH4tMX5a9A7Zfudd58yvT/OKN9kNFBw1FFl5CTfSjW4cbfzVGCIS85rdkhZLt8t3byDiQ/qZrgFDvSGqsGoJheIfF4iKB76uyXx7arYoem7y8Ha5nIcL9VdDBfkqkvCt3ab9UFU++pCY4LYuvnCd5lqhDSQ6U0eO5yVCrklP3Z7Giq1qGpQF/zo3IM9vXGOPXJBUQ2FYmuRU4o4Z4i/rDDJYCbWPb03NE0bz6bhR6Uh2Pq3P4GP1+qYibBjHZ5NEZvR55iA0jLTAFXdLj7LvRt6/rZvKXQ2u6/zS+xIO7XERGCJogh0PWKb9hV8C+Rm3jur939z152sVjvFCx3wNXimHg00TLaZX/p73stAEQF+zfaCP7nJRfATLndIlww+LmLdWTIh/IBITEhSE++vqsfY4Hx39HKGUz/aGh+TOYbo/6cBM1dKpWs9YyDyvqwhPaVjA610YkD78O8qYrWZtayvUVorwYPSh8nTcwdeTvrS3HUshaNrNYnojpDL82PrENlmkpgqp9ZfN1MOkCPjUzFMLiMbhGzQiADiIDT3OXFgvr+AdObjjq3BeccH4IkyxKaiMm4mtYmqATDeH35/N8VeOS40Qw7OkbwmJd/+PNiNVMKVebmOLy9ZyTyzj7DG7TqqqVW4Flq8avT5wP3f419W4ARb7ijZtRK5xkfWWnx7jn8U0w1L2qDAuu/tBSAVR6DgC1Kbk6gzcbJaf5B7dCtr2y9rzjz0j8oQk37oQCsTMUYu5RFIkKqCCu0+T6neJkwigO+Ayd4stgGmRB32zhN+XD6eky8OMx9CAUj1j1goNxX3nGP0eQhDOhJty5K0ZVnOFQb5tcWh7foF8hHTSHivDmPzBPlkBz3zUwQb80MsfD6bVJu8npMBEH45ydx4FKNiUib+sG2YhMQsrefcofNcNUbscmR5tjj9m4D9lHQ/ZASSyCvqDly/0ZhQwA7sma9b3NHgReO2iAgbYAJmsNRFkDborGF3bM0cQ7DWa0SsCFSCGWmsOmfI801QBbmI71wzhkzBVPr40vYDMrJHVK2Fo5uwKxpNxlm8opD9Rc68svW9ExJyMsS9yl2DRo529xF5wcrls/IOWkBR+qCiOyYn1V7reJVan0121KbHbjiYpJ07/e0hyQG4EpuosAGfC2iXVCT7hZdh/Ak8u2I1zcfH/EbspUfJUihuatdLoFcCpwMKC3ZINSMAcQogMw65ncmfDTn0b4Mrtcq80xTCNCg4b/SzMon3ZQpQJtVUyw5EbKlF7C6nvcvFL7fElv/UxAM2mKx5E8zzSn+8IHFOj4Cmwd+QY7ACl5uISerfmcRQPSMB/vJ9pT5obPtVj1ub47Dtkw92TM5FJJcse0psHuBDjRpK0aYPCkHB917I3dv28x+2sROu8Pj8uT0A+4BnPVAC9/OLgK1dCdAXM1W82qIWeeYfAbTFOG8oWf9PBMbxx6vpycB+tLrvi8Gdrv1llaADAEQ9dekKQGrPSqaSAZk9iqeWID8av1ioZPM/kvqRT1skciDfaXDgQIf3AYuGgvNfCE0nE4E3K/Nzr/TQH7whmKRdDFmNaHnRHkEQipf9f3K81DWxxyl/cAMNy/ipO0/9XonEyHMPduIlVHtNLu63qBA8wPa1tcKgc7eKT9aK0JbZP9ItXwSJXA712eRTJWTYMrE5lTCthveKEvx4u7RNAt2vTdfvgDAXsErPl0X7JP657klVcS4k5/s+YoihADXD34y+j3lsjrJd5yarfswlxCkgV4uQ1qBhSua6w6P8U8UitY1ryFXtZRogxnc7dpBEgFNWsfUUfg0uGVqHGm9bElBJhNa+218ANk4pXg1PoPJ52Aff9Xg2UoML3lg/425qwVuMW/IeHxCw5+HcHA0lmlQyPztCJ8uzAsO6ytcLDwBXOlOEHbjU2SKil6+rt6FFCtc00eAwNjmQ/zMrFt4iJ6FLlCQOJbtMIQc1N7EmQ5pSLY1Y+YtxjwIIPerLChjuvrAbg+3auf9RrYjSzdTG+lUrXjeueLkY7WSsPNnIB8mJ2zSYiuCpLpk8dQMjF2Bg/xrCZ78btyaOL+xTpfUruPORKZjjshV661DJke9qbLTWngv1RQMtWKEguWa2wo+yQC9vnxkDb8CqoYrqFZwwmFbH+zPTMr6b+9gbY9Th+bpLdJHLm/nfypp18mm9NWAhrZCoZfSzgHsrGhVE0NLGHuWc+JmhffJxd+dW5KOGksPmrkAA58yX0Hx5Sjt5U49J8DC9pF0Uq2taGmZOaBye+9GguiQaDjltQbwJ4d1rklzn0R1xTjD9qDFqriOshKkwnNui6qVpNP/ze0wqiF8acZDjx/jGF7f1ZXAhUP8ZDMREmfu7CC/oce+KecS410b6GKf5ehcBK6kdHN0nqcllVr5fkIiwJHsGYWrw/4mER2M1rf8d0fGdsht5J/phdmZYwZNfJTvRpHFUEyQk9mrrxO5KnTVFV6a+r1Ab2tfjIrfTDVPZlhSucT/2e7RnNWBPWgdi3yqddk31Z8aZ8yXdOAQkFO9OTglvwWvj/QZLg4kLs/Hv7axOiDlM6Hn1G09wcpnK3rXTw+pbrgTtaFTuQNHHVfbGNMS1CnN5sP8Nvqs+6NlsCq3RXJXPKZU/fCO2A3sTbIx+XzLMw7cnxaEhEcf03JWtsWzS4OibYJjsX01o0uGjQdpQ5Vgh6/AKICZcXVZhijEVPzhJGs9ddK6i0VCaGt8RVGTnJPoKXeL4ly/UHYJ5dS9UbbnuTsclqSqO4LnPyjxpWJVCFVVMZsWuAL5BUOgmAuq9WUI2M/nZetFFdcUtRluC/j7UXUn1o2Ni3CidJTjoOZa/dpCMZEa0+xEQ4K7UxhCOeqKGe/bD3yVszJK84K3T1e0ZRiglCNIYeQIMYfbC/d6kKHCb61sZ32CSYq/n3w+7LHmOf3JzBUch0PhvuLrl0ImiGmh495F2mF2on+QGjt3y/xaw9TzsCoHpStbiEiAj5MbWXdqstPoHUyd8wKAhQzAlrdP2RGPK6EOPYNZY+8c//xgeBoLObHrfPcwPj3/r8K/eut4VFzxZKjYSVW/DUSM+Y66MQeEJKwh5dwOl7vkPR5qR7zROho4XfgS2K9QnHDHMCY6sYlRb8A/2I/Fu3AsixcvQC4IdxdOBxHCaemCQiBOJc5rSrjBvkgRdyfDi22DrooxQNtEc38ukSKaEABezQxx2ymyl/VTvt7cx0Ey9U6zfxBd2PsASMYvrGEkKSFBNWQ/w2SvzPDXHG5H+8777B28b0jUEgQgIR2b6aVKeVZR19vu4FicHsrSBnY2etCtGOON3X8HAEHyzAyNKU397clZPhymYPLJEaA8YDxL/6O9MeBLVBKoXt905xC/m0BMS+WMjAJpxL5lhNyVnEODAeY27XJPhR/O2Ptw8pvattBkGejGBhr5zMHwxZgUiaRvqYZqHLsbOgQkIWvdeD22j+meug5u7GTojrgTVau3rtNbTpvfgelcDp4OsCCtK0Lrkn9fUXyMDQfuZF2ACkfPwrxZZeDny2WwYaa9p5d2jcwfmCUYkVj1jFJOx08bJXnDpdjVQOgiV86C1sptZItj3SjVi8y2XbrM47nG8jKqnJyGh4XB/a2cSZbwN2RPs80eUGhvGmVVbdV4m3EJVObta1GzanezHus8r0O77O3hlf6LJPe8U9eC64qU4kjpctZeZ2WusWUoBJ5eAHc8+3mGvE8cQQ09doc/+Fo90ACR8rYjlChxssAa6RfcIc4/0+b1/Romu8tue6J2ZD2Zvy2MmNCtUHAbzEFiHY9ZD24QE+dGXEfq3GCT/m6MWIP/VjgDkgk83kF6DR2eBLRhdJgIJUiKb72K9OStvR9+d04g8MH/CqE5mVkCDfkV/Eop+BmfkGi7gTT58QDMJpb2CfYmeicIRM+HfXMNvS4/UctoaJHNOKtfQou+lelabtD41lSY08iwSHeKyHDNccgfrDSBISP/ryyYYbvIBUlYjOcViUaoec+Y/j9y2/cKSkuK4ci7OEWGj2mRCXJDN4qQo5U3f8W4fmupxtBFEquh4ud2eRg2uTN0GGJsXkIjIGythJtkEH4mi+Zg9aV8rp3kQpBOIIy2dHCHjHg/oWX/BAMJr6OhcznORKepDeUe1HawE1H1gf2ebUpKQLsReRMLxYsMK9XfaCZKtzlPEbnBz1dR8fk4aF10BQpqrfHsrbw0FqBRFYArrXZA2VoFRUsi6Z0NtC8yvGxf+KUx9AVhWi1X5+AhyMKcblMjK/7MCg/DX0PJxJ9lf+249RHLho88kNLMDvZTkzIGTvZdx2JV8zuXrrXT4VoB0/eMK95NNVcmyD3jhfq0ynIbhOrI04BOPnkzve0ZVIZ3UcCf4HNWajAhYttB+7rRGPbaP+dnNgGNcx6h/c/jSUXCRj/zR0JUtPbhRqHovV3Pdz0EGY/SecuaDUxyfkUdb6wEe9+zRp8g4VSIb8ScagACAEzmSwZaIeJ/DYX+Ymztvqqx+rWBto8MosLOXVq01wj5G6iI70ZhNH3xZXvme2dvM0gtugrCHFK2/35385Uexa8a20WlCuU5x80V1COwHA1M5h6IcmDDD7k7juwCC4PJmACIgZ+OrlRZUFq+5MgZivJFbjc2x4Bzz4krq2dNiD5nEi1A6bEVVKU0vSwyzpfawgolEAG06ExfJa94Oy+bgNcG6JKhv1MmfZb3L8UTnai8241ldbolu+vlm47WELt4eo0R8SCjiSQEJ+0dwKxBHWpy/XkK6lPNh4c/YcSkmsxnBFgoE45I5SYoQTEhs17pyWFa5LIBwdbPYsDC5QyNW4CJsBVhCNY+E7K2y1clQsXJqb5NG70INu+iX8rFsz8A6Er+/ybc16FAGHUa6A35tXOOgG8QrRtoADeezptkjXR+uFD4jKRPvDiMxT2Ob4O0M3z2putMH4C9eegpwa312UPUi6pcaCgnfsJltTcdxE9rLK5fkmCXuDpPGGAAZAdErdYBXPqS47Gozp86WGJqDnqQj7OlNOHFocAlITssu2lnsFkYv6m9kL9bKLWUn8Zx9qs4bDoizmtLvp/AP5mi452O/F1U3zuuA7723//SG8Sn/Y4tM9/TXsFUQm7PutRJjKjQC0Lm1MCBOWB8RaO/9fMCnT89Lg2ai+EJVtYxN+OnEhrV/Jqnkj/3gjbO0gui+PXIjW4/114r+R4fsmrB9Aj8SA//wriKof4PTzdxmNTNFiAMvisS/N75GJQnDH/MI7jNgH23a1PHj6+NWFXsTu43n+hMByB7AAxC8AAAAAAA==",
	trollbrute: "data:image/webp;base64,UklGRmILAABXRUJQVlA4IFYLAAAQNgCdASqQAHAAPnUuk0YkoqGhLbaNGJAOiWkA0gCAyW/yu8IfLP8n0PP7vwuxIO6uCXgF/kf9O/23BTdI4htQ/Ne83WbiEamppENY2/VHd5pENCB3bf5Rd3yjqwxdEpI2pGRnp1lkgP27rpTGGBEBRoZFMl8s/LXaeosYSekRI8aoKtVZ/lQsk7f/dnltGSr8DKgRjqRQaRqdVJkOwuxMi6KfsCAC+cf8c3paHfHX+qEDmxSkkQJUPaW+wxTcRvmKusF6tFDsmP4OdBOLRFPFeKdkyljoMkV3rGcj1gB//UzdWeHHnVzBf/RsT4BUAO/aBxsspAy+PVG+CQcTK8lJwFv+izi8K0vx57AUQb2tTBmAvaqFsqBffUeOfnBIUGFCnpyd89p6z1lWLcrmvtoxcakb/PsEo/EPaf/8KpLhhC43kpeSR/GGQtJHiG1SM/oDM+Lb7UU1n85R+fy01lI9RTD8AQE3/Y/G1HwIvLk3jcZfyf5DPx+9EULEu8+XD+2b0f4Us5wP3lIsK0T12R7bWc9utNIMVriwDDNXuhVSTerva27Mf9wrdOLGD5ER/CmYiXPlDQ+1IAAA/vho4Y7O5lfGHddHeS2EydaTSWD/gYNWbvebABJ6lMdUJkvxZvI5gOnvx0N6nOKd569HP9sDIv9N+SH8PSGh9NyDeBbgkK3ZLSPu/mdIEnnvO58+FJJxbPx3ke28O6JiJIAu+kyUkHsri3kzHcgj4KnAaMs+InTV749ivJOLtBJPyvhXUZ1m+dcVsPvZdsLpA4dmh13hktxe6jLWe7Sgwgy+V/7uGAAmtCfdWmlAOI26cDmcNdUHECuBOtRfJpPcJb6g7APRgLklNikAn2sbdigLOgdpq6i1C06qCvr7thZZYJCzTK3xyG+LvnWGW0zonA/yqxq+gNCvWjajjGmqy7cZ1+RRGzgt/dLT5QKG6an7kf6K3r/svmfeOgioMWGNtLPuMwgv6RwZHtfZwWroUzGv/Rj9UruOaQYbQr54XIePoF2NBvJt8Un/SiLSAa34RhOnNlOvRkG5gQu/FAZ+/cl6F55Zkj9sJOWU/jxAMzMk0GYwtXcdKqSwVQJLNCXFTonZ7dXoo5FV1hylueSyKsjm/IPX6lNmYkmzXSL2pLbXa6AIv6PgdaVkkmtwehbgESD95Fob4RppmHAYF3JvvB3663wtG6sQhdORNoWr+jOY98nVETP66+a/n97hHQV1W8atSNloVrzX53nXV/6AIB5emU5K1erETKf1t5LV4KcjaJw/ttM8KCIQdXVG6QfvA+JUxA9fzPc5OPPCGzfkhCiP+YBbY4SYqTL9HOrZHajpznCODuylzCkcIaBTwjQ1KEvvZIHYb1QYZj12fBgtflge2VE0El/yJmZroRtXci3Ps3nX2AcMjDQIaSlbq+io0MytIKHkpn4yXvx4FWCP69GquM/6rM7ljMN3ufDhf0n7bzKqBpmgKVBGTo8wqObzrjGGJnZbVK3PjwV2Bmh3OMHAzLbbhc5SWZST6NK+ucYua+BoDMT+6qkyDceSvnA8ol3mD2iNju+qxoHuVSD1o3+ZarnRvYdV6vR97dxdfETt/rIha09P1/a53ix7HaLdSdTtZgCf0wXFs6GckTPZBuK8lid5AqYVYPHVEVPptsuOqzuLpQWYtxrIZ8m8/4iaryDznHzywVTh7OrTe9GpOX//yc7+tP86cDS/enZG8bMhCx2J37MxkPXPIg6VtB9hvEdT19zIMQPwaTE3y1fXwtNZOlEPocJPooCAU0dTfOkUg6CYM6MuUvo6/gyJrWMyYXZCnlx4GTp3EYowFhSyuGLL+OvAl6Hvxndpj8Ysyf5dg23RUeKVwBDAdbvYcJ1H/s8F314H0q4aZJqap/JZ+2bPSzv6eB7BeWJ3bfw4RojW9uIkBgBnc2t5VhE1J4SJi+PoOAR6XDuupFpPJUxio10ZvDhoHJOsG2EqgA6if2mq6fGmcATkdK6Fz6yfTsS4Fwel5nEYmFy10+sbwpqr6yOoLpoe9h1WSv4YT4Kx1QE6eKKPz3Xs5XxR+NFIg25o0Xjc9z4GEstL/nl4SRv99Ml4EsSrh3lem+wbsiWxuDMlwpI3PSDNgyJT6KIXisDuUn9DWIW+9ZvOq+gVI7xjZDAg+IgYNuHfAbveGYlYu9XQQXimDB5OdZhzgcAWOilYsUIa76Zgf6G5WU/e5qhRRB/1Q51Hqxs4yCvMp6Glozp4TT16/28Hxccd1OHeZDWJq+qnkNqTlcang5ThKArJu0sMCQfGg+jEAQ8HdVjXEbOStlQzHp/c1lO3yfJmKIigYGDzuAoJe76Ts11/PcbiJfrkHTYJcObQaZa5S/V9m2z4s5deOZNO4tch5s+laqybO5MqbcKSsaLPQ5AnRfUsbLOnPIv/tAf9HDMbau9nBMzRGPYfyGQhYM0NL6I0OXBrdG9fYuTBnE7a99W/V0hCzZuCnOYDWlrBm3TbGVsoc0ZtqkhezTPKgOGDI0iG5WoxFwwp60bUiIZUbnrJ9k3DOHns2E2xqeuViHsuzgjDetMHJyzqCnJNAYyX+y9487WPl/tbM7EmDioJMAnr3KuPFePCWiAezo2hwphdehr5VSxgkfxiTUTM1H/nLACjVh7AW929mbNIgrMA8huwj7nbe9hTI5H33EWuPFYFRrD8CMj3wjC1IdOiTJRC/hbPjChnTNzDyidkcHh27gQvFGpSzdk7L57BxavMLCqJL0026yIQFDQq8QEjf8fv5tyvswuEauOa8ZkY5MjzrcKrmcF4pn23Z3ccH4jP60jQEHe0VqXuSVEHdRvxCLdOl/qIif31xIYyKPeIe9BTWufgNzUeJE6ZSeHFGei7hLFLE2An05yX75L0Qc4HVn3DLecMi6dx14klM+Iwmzcx5JFGZ95a9+d5v7Z04IK2AzPNHsByOTuEx1EoDojTGNs1LsdWuFkZEoRhjwXVPBBf5rX+zMR5TnxdrULGjXQpXw6TuNYT0O1VG8I7U98/VIQF8OCfkIxg01ddRWsZ74QA70kckvGt4RgfhhPWJj+0P7/krJ0K7J2ckIEpCDlz3ugaPeWnArCOsbvsW/SaWxBKNJooP7MFnNW81ERnOQVQ/vreQcMROOOS8jQ2bGedOQ3vGWI3LXAtfGXxBFv39oSgPSGTCUBzwohTiouRY1LH5xT4G/eiUWFUBzpgLi058HBz7Dvcb43Krb1RRFfbwB/OLHS+93oeEKNg2yUXt57qTyZjyf6ej9Vr5XBM9hhuILtGuNHqmJHxBgJV1ZFrK7R8xspBrwa1rMi9q4NKyaQbp+SvkWhSg4RWOVYalPqcmhBPl4+AH1yzjYnOdDteI9aA3inX9QCMQVzncugS8aAk75ZbT1VDwh/cR96fhs5yY++0SDxvq9VKVLJHJWp4+63SGUmZ5r5RVqNAybts+in7jiLlqmdOVf4aDGZchROWO6yIJJInbJOh8W3WRk+oG1I7g743hPygyVrisM9ZVMlEJfbr9X+hsn/67Dd79KyEkYZ33pe1yimUakkK53dwxJXQjy5bGsOO9N/QHq0Ja+E2tpLLRgd3iq837C1j/ZYE1JNhaAcrjq5TBGkMarWSg5NKLaX8Lf12GnczpwJONXOHkOiCw7xSu/DK9o9K3ltBxAKuy1gG93a7Z3qNhmqt3v9ZjFKSPy29IP82gX9WZw2iijKC4X1oWjPD7gyRVA3ZbrtMN0Pcs8MYgAQhcbRPNC/WxOyCpF9ieiXLPXGJt2K/xMB5iRCNknJcmeXvsJ263pzmMGWyBUkkF5D1fPOhKv6Cw3Qhph/RpmbvCN9zSUwSDuoH/fO7xZnfr9n5HpWFlnHUsM2N0hhjw/XeNge5oE+s1AAA",
	trollenforcer: "data:image/webp;base64,UklGRroJAABXRUJQVlA4IK4JAADQMgCdASqQAHAAPnUuk0YkoqGhMNLtEJAOiWkA0rSFKYf4B/pPDnzB/LdCHMfad9rhBJ9Xg74mag2a952Qx23KUg0qlxfVubsuLUo9E8UQXDo7CbJ54q1SNQbnEfxB+09HqsR0KN7zuFw+TdxnvwDmGY/xHDeTt82VXsKwBTBYTfEA0WBTd1dlt358/yfep4fmv9SOijtubQoj+rFTgNrWitDd8iTcfDvhWSRgHRM21RhvXIJBqygdaz/E+1kNbptmr6AaV89vnmi5YcIg3uxL79SN6B/cu8tOcmnQpk60CvflgBNvb5QWmVQSz9sMjJojN9zWoiPjyOC6fO80tqWtwE9QKhkdBXHxsjwU5H21rHcA6+YnfYvgC6a6SyBk/h8i1evXSxs0/5Zhm7QcXRK2/dqlKiBhexf/48110picdt+Pp0wnpQ5w2IMqZaGSp/M04EHhF8G0c3oXsIvoJcN/7UJ/7dBBK1rNC+ktruBdT4NwYFZ0Ngq7VSBhzd5pVmHuhevn/9s37aWcH5l5qg4dGyqo2w1xMaAspD5FbchAAP75PtjjJXY8y7YCQq9CPqmHHhxT9ehun+AeFrG2M2gW4zhxDIvQGpJSvMz01wgxL8oV2gNEHzMcYfrAXO+DIM/gCS/zQ68A97W8BQ//vzaOsgKuxaOXx+gwv9vGt4Xm39Ce1RuDCWEZ01MqoPkOLm6MlaGb6IAJhhUadJVIQuPgiCD/DwGWVI8CMueGHwPHp1WPvqP7ifO5mvqetQZgxnyYZBQ9wEufvP36HWyGCHc8O6Yl4Gnh9oJ3kLCeiKEQw5lYQncjBUMgeg5b3hHWTYf6qPZ95B9D31qkR6sc8rTpUtOZt7WqXCZ2OU/3ZH67lAMa1MflW9o8SmNAWeiBYVGvKqRyXS3yXAF/7TGZwP3uyeSGWYnW4ryA39UF7AIwcBva+zg65fofqhmqLcaBGqL7THdKsn4tIDqm8hYwp6xIkDOOcX3Su93khBNjMz3ryhr/a/WXoYb4WK9pSWtEnGnXDrOXfnE/U8vlvyP/JZjMr0ICZwhHRHBK+I9FQXcf7Ly1uz1JwqJb9bH9aF3SBOZlfafX0jPXn/Cf/NWm+SBlGyGSK3y3BfCtFyN9DkS6EenD9ZvmOtH6fTd6PeKFTwxbHcgvFi1Lm4Eu1wfEWmsMpvxFVoEQVGIyOEupIJTYLrbdnStkGyZa1LYaS1rk1k3c7BVmcQKlYVkB0Vx9APgoOk1Nxa9BiKh1IPLvb38KIHvS8nqOl/PUSBQ18Ky2L8RmFpLsqPPPb5whdl6X7lxXjD/jIRkyZSTDrT6WUHu+Rbs13YMx5RbbjRouAN+AFhS2TcCb9bdKSLz/Dj8tFpUdPNGmnehDZLk9DsaGAUGgSUF8Z2VwguF6H6D84oBcF1gp7ooN1z96kyziz3+OgJkdpmdYxX+8ZvM2SPz/dYQCT1Zy4eRdFk+MahkVkx9Nr0ciUUDYn/j0KVqu9MgbUWgT3xATGaCh5ibELpClLERWIrUaSM6Dk8z33Ki45zNy2Khgm0y1raWQrCR+rnt4fgU06R1ZUauSm8HCPH4OK74Z0/E2xma7VlfrxMhYiBpMSOOlm8EinI/elvTKX4ujpJ6PVOIZ3y+XgvReM6cNpzgLq1Ury7445MAWzdQBKqGyPhXvv/T/NrwBYFZVTryLddP8ESurlrqK0arZeD5KgAp6Zy7PyznvTZLCD20L9jLmofrFANq9GNarQv08i7bMOmvNLHGQUJpYmu239+v8gEOUDmp+9ljGfTnlvRlXc/tqRNGTsZ0ViqNTqMTz2FCIjmMRWWtgLXHoNiI5i0wjRzivJH3qwfurjMTP1PJ6l2vWp20Qx7hTT/fpJeVORsTWd5scrYjCUtHrw3twdzh1ck5UDbcfU4Hch7LD/HziK1N8lAONc/fXsTZhZ8ansNUXcTIjLNNHAxa8tUmRB4D2R6Io6yzSnfzvcxny6kPpA3WQpNr0R+dBpv4tijFVnw9KHYNbTUjBo/P24Bm7p/gan2J6Xe7zMy5nKw+BXO0wkOjO4pL6p2fO2jrOFHYEiOjr3Z43kp66dSS1yESa4zXvF84lMp/2zXeIxaijK8mTU0+wFLFabX3PwERD+N1NfjpuuWXCHP1tnWFakXSrT+QRzOiN92WdqdUzVzyZmvuRo8dd8/x7dao743g3+JQI4jELeaz/ueujbdhybb/S4sVcUGwrlDqCIyPCHzvJeFUhqSI5A0JdSxNO5CSgZvGs6SsucuH4etgHthfB1Tjr1kkAp++EisbOG1xKGhdliTtBMXXLcCoBLxfl4/mpvn1tZXYnloIiWDU0ok9QAvIA7uQ7Q+DCCM5DpETYaXvd6zCPJMAU61xxxLOX+ITSWxRBXDpzzfaA/yZ64eVYT2STZ/VEn6gLHWFGaBiMZY3GlzKkqPAr69yJtMKOG+cw9CtWDSMkwJnCuPtzK8AQRN4iOypKsAPztSp6bbZX7FO7uM9psnSFJ4C8TN1qlTQAeKUItvL8Gha/2UGu/A56WKOMb8aXYREHfGKY3sfMNrdivTgpkRNs0c7xQn7X7zWHdZrRLNdRazf4eLu1Kc0Q7uIe1Z23YH1wkIhpKN6VieIgcae74qostRyucd2N7ZKvEAb4ngyH6fdEU+j5r6iBMWs7EEkvce1h8NY1mX3Scd+K2nYsdEYrLZg0C5sivNy30iyjp5KESEFZbxP4Ppg8Z1B5O+kxdlHz5fgyVZ1snQG2PKKYeuwVWr2EDEupWFaubN3A1Otbxs90Kb9ijOk55Qt5v/9sQhuCYoDtbjE97teBk7plxry5Was2INhMw13c9LNCHbGIFQBvV7VrbuICs1sj6V2nHj5DVAAzT8H9Az2hfa6W2UAn2usDLPBMBR+SM4XCUfpo5WoBXqWMqrfIAADw3/1y9mzMuVX3GcbMI1E53YYzQHqD6EzLYV+41N6WyqsyTJ9jR6Vlncm5ya73LSR3HkviRIgt1qiBe9zidGtmtsSXyekiDz737upSjdQBWf0UpYapKuVXfc4wytgKVshRIBRJb6AX1T7KmJgtX9saT+gHkXTdCQU/J2NfACp64fKsHdYoi77fzKBcWvRmXu0VQAFp6sht5L8SGGtCcZ93K1UxeygMlQKjpFWEDZYKC5E61w49x4V+rqzSDkJJS5Bg0M8WoopGh/sIH5XkRTLciB9vqz4CztVm9kw5MqTlz8OC8huap+4sHtC4LD9lNNlLumhA5A5qLGD1XOKz9uuqhZRi95qeZYGxx/LW51zyAJKiPEvcl0lzGLM0mnWDW2vQxP/5gAA=",
	trollromper: "data:image/webp;base64,UklGRvwRAABXRUJQVlA4IPARAABQRACdASqQAHAAPnUukUYkoqGhL7nKgJAOiWkA1OnsK17ev9p/IPzR8X/w/9v8/fGH1y6hfzX8Rfx/OPv1+MOoX+Sf0//Z+Kbtodw/zvoHe833X/q+ib935t+IH+uP/J9df+t4mfpHsBfpH/p+rT/4+aH639gn9dv+f2N/SKRbg9NDIVJk5WS+up+ninzAvrx6wg0uY8nbnwFbsnkk/Tu5kDtTjWc2JEteydz355QxQpM7lbz2rWnF0MiezHRPIM3wxrwv5r1e/Qfwa/Qw0/SzDnppqKYJ9Com3YWmcm48j7T4a+HF/kdgQLm1h361mMrBOXAKjg9ezfMaLYw40V7q8Rkfwcw1YFErcXwqjwDUY101lq0pjdLcAE8ZQdoEk7gRv58jl4J9h4x/KlGpt9lCFq0gf6j7bTsXJfNGcNsIrjxFMA4eHPtwKEgW2BUe5irnE7AeU2Zx/zWji+guHfif1EcRj1McKYNvTr+wk/X2sCQOSJ4JJVAx7lqJXWx6er/8NJh6gqF/58e2EgrzL410C2572qUO1m3sf4SEXL8YpsW5a28Q/66np3AtktvQGAZXYCrXngWJ4V/zbcrY+8ZWeKzTP/WVLMSCULancWpGggM2JBbIBXxksIvgm4qJes6VD1vh+GbFa95d9k8//43gMswNiCeq9V/3I1eyOr7/C5zsA79GIkGG5vFV9CxLUxFo983NEHHlvXbMrCc5X8PPU7WJuUH+F8GPagAA/v0prIZt/Ba2RjKbmYf/Xn86HfYfBtdvabjC/5zzM9we91JoSoWIaVXQnrIxH7Q2SXvzX0atbH0wIqQf9IOWfWuv6/SL7j+6F10d2Pe5aXPJxwXbvv1kTGTxUXFo1a9mrMtPOptMBNQOIHATyOD7sCJ0iLkB/pRg4ZxIeNen+MPMQafS1UpIJCS1T2iy46UO9M+uFd0jK6MkTB98+wPDLyB5QE83BzQPpdxPuRHQyz7ZHcGLdZX1UBh7L5L/jt9eQahVw++3fw9sGW74l3XvyCBKkHYubQIUNWOaaGEaqdp+24wijB3VfplMlT/KAIpQjs+hRy9Q6VP91KpCGl1I2X3/2mYqaBwH0lXFQBJXNbvADy0Mb+Sr9rZIk5PrIBksSNmiVO+Ef+gszr5FL1b2q1iVOddLj1k3RZCHuybOMn+B/uJKFK1d76ZD9zdyn0jhwosCvAd6CNQtfZQSZzu89oPr7owBUPHgjk1AcQP0xhHs85wgJ0vJSkz5tG7cakwTsGbT0Ok6/EzQCwrAIVsvnbh6T5GS0m4Tlf7vOPaSRFS3mZ4tF1g1jFPW0ENuX0+TLN86WDz1bDzWrMp6s30QNkZ+WwUbIKYrg/lY1ChEGkDQI9FkmUQnFzWsIwktwc1gDTta4RmjwPVcd98MNfi8DSw2bbqMSp10sPpB6c6RC8XQppjOTVfMrWPbBXeD3k7VxQ/wXZ8uRFb11Ylbf7Dcw3fTkgGIo4u6EEKj661pxNUxW9tp7HoIdwQICkJq8FSykXKBZjV4k6Oz1K/Puf60GiUcaKjYXFuQgXUMBpoyX6lMdEAVjgw7Uc2jj/J6AW9sDc/osV5vyycrEV8Snr0oXBtA8KJW/py8jk+KfZRcZU9YbV3JIxnCOKzePao+FVt4GlfPwaHJZAJymKgAZl5AxZqJMS53/snIUrNB/keX91O2zRZfKXkX/BbOi2x8CHiCnO1XysZECCPHjt8nBauVLNXC7vZ/orPbuHaHzmxzVrb+hPc+Y9KSAp3vUe2DAN4Il2D4gX8ViUy6p7bNpaHaXPMgmG1iPdP9PYq3o4qDfQlHgi0I21Ptry1kke4ZA+/JwnLZkMliv1rKcGAQ2KmY673T0F4mXwBr3Zx70/tyPj6eeU0SDp/W6jHZ6oLxcevkhbxuLtO2H7nXnOg93hEdHt99Gtfwsc/xJHNiBVfOZNROhDVWdLFpHql/4ezx0mtp3hYca6gnCT0myKvGyL9HnOnCMhWbBiKQL5FljYNkD2Vh7Zcnza44R9Y9D9NKp1RfG9/wNPMa3yAYuJy41GYZZ48YH9nRl3NT5xB/YXh5e5j6og50hZNr6gO2+PsYxA3lts/HG3yvXroq3RbGbxAa9JtXvF8EcIhSG8+4R/dThlGCm0tNolSotdJZ4Ym1Am+En+INxkxShZlmy6SIufXBeqiMlQbiqjSR9laWYZjAaFNfYMq6ikUdEWlk/ZeHGO8LsZFkvnXPdO0YAUnKulk5zZpfJLGn7+FkQdmPpWPvuCFLFydBmFBBbNGTfWO7xhj+mbl8xO8nuNX/L94y4EMqk4sIACvBXV42ybiqUkubZu0DBH/TCkmxUqkz4HfkqaGa9gZ4xv7r6YWMGAZiHam96WpghGP2dxTYF3teRGwoSOV7Faf0gM3WzYkto+8cHzmkgSG7AeYHLVjEJaM0CIKA/hOCAfrC52AKLlbjP5osJ813Pmd+P89M36B4UbiaMj1nB3kC/LAtQZkS32jHBttp/P6NOUI9wJ6ALUgrST0kuw80b8SBsFJekkH8V4L+IkOsP+GGDTUzBmb26ilpCxPdx03pETb0+enMyavXlQ7pYo1HW9PRe2KgtENVBJZElybOsPQ4GgsfgtKBOh3FsQGMrf/pJKiIOmqm16V9yb9K+XL3T/2fvhx2PtdgjdGdc8NWt0zlKFuOhVMXP95KjVTkhLG45LFO/lERw3YaXSRPoJ0RVZVwSfS/qTSo6VO4Y3ATsmQiZHdd6tUcm/5yQtWzTTjGa33RB4kO5osSKwNxk5qdl+rbVRkHDwxb7EqaCj+eOMfxKk8bbfp6mvf/F6f59I62npG6taveI1GJV72m2SiA18VYB5hECT2F6GTRC1vrY6s7qFCmZuWwmk/LqvgG9gqom0iIn2houqwqPfOFjFhguAC+3TOq/JWNfZu0QJOpyF+DrWvZ/caLPSDe2bgZ12YsoxTXUVdhvi6kyoNPT75XM4acxvSyJOaFRC7iLflThjqUtMgfxxLFCS2hlg/PfLET8b+IhA/nqWJAeDQ12BfxgD1VNPfFPpL8aa61XuVokvuar2CIlEjQ5DWA4gIhIgahzsE897hOn98xWG/MTNm9QL7lQngvbgcu9mBvA03LT3ipyapw684Q2FT1U/dVyakT8rcc9Dt90f6XRXIDmY6vxcfGeqLJqqXJkacs4PvRXPhaDOr9dOhR6lK7B0L1AqG/daIlNXTcE6x1IeV4Q0WN/MhRapJgaWBGwXUVMN3I6NmdWaXHz4XW3red6/7UWJsoRHDWIrMx0AnYwa86hJj6zm6AMsGNjo1C4j0zWezYkxrrKYKEYdw5yN9v/V/LSb6Eqv9/MesOWNexjK7rzz57K/VKWeroYhBApzJwUS0J4CI3b0rj8kxU1Cr10i4Kyp7PdNYTBVr4qAzyfbAI/C5TV2sMMg+xzHUoDEGWW6h/Phb7ecDgwPQLEOJKFk8EIlmxlLaMasj9uq2x5Sc+QMvbVLpt2Zm1Pa9m8OIaoh0e+Jt2t4U5/uEwCvWHyAaby0ZtUMsscoBc1VK0l5nMV1kEo27uXsUSaUyJ1+tia6L0EjNfzlftHk2emdX52e2CdyNOnJiSf2C/rrLg4j7NNkH/4XDaRpmH58UMyx53CHlywYH4YsoeG2t+sT/1/6OeYcXI5KtghG9K3qQ1Y/CI+s8mXTyiYastVAv5OLftnzpFs0bKaKeTmAXkxFgMx5kvWpR/nzDzvLYknK2VW6mh6jZOZ3ga3Z/AfgdZ9nc4TSLgFsfIBUwR/A14F01CUqwHewUgClI/SBBE0tX0WICGbuzu4va+Qym7Sn15jrd+yqi28g9TKCzU9TiDTcMbXnM4DzhGqf3pwpN1HYVH9w0HvD0J/dzTIqt2yJlANsoKzXsMhpxXZG34pHb2hTyh/VR3mza+Itiqh0EQL05YBKH7p9ULUKTTOvhy00X5XVC75XMoY1m+Khrg7n0m48gfd0cnUY57nMo/K26/xaoQD87biA9VsNdMHgIvpqDM3+k99qnOUXHuI4k13H7CgWEWHe7itNiBW0HWc2utCBfsukRdMQ7ij73qNdj5P6xVqRThCNEqBLY7joiC+hoHFcNxCalCGoyUv5lwMK9LFSim8RGP2XwVKTcFXsZ1n2FRzoxi9fRSkyPYKfVwfFjaznKjG4b3Osf/abLqzPfXFe+9R80o+tREVTk6HxhMdx9Sp9zYqjlkzStlqzc+CtUk/DsrBF7AJX5bKo2pE4EAQEHpDkN94ZS6JwKwBcF/Y0yo+UAbwFHYdXT5/mAiO9P3QOW3kZIqHz7yf5vEZvIgbue+XeF2tk50eMJwSu8dTWsK4cdDJllq1bKyiyYzTsxQlhlqK6CNX20TP/N/kBBmAl4L4VHGmFYzw4mBd+9rRvlqv1TRcRyoAIZlPxAZuIvcDjxkWqJ2KFRw9qtg9HxVSQV8DA1xO3Y/ewCeCfgupicZHSiXivESqGXlUy1oOhY1X100qgIJ7ZOULtyCulQOPe5QHCEym9jf+6EoLgFLPPkRxSNbwvULva1awOdVjPHCYShbF/72Kj6lc/3UJ3rOb3BcvXmBPUY0MeLPZB+IQKwP3HBGnPB+04tAeVuXutk0FKsNZsStJAkiY6vOXh15+NjLoRoNkHZh2XN0LqmM8sg/gn9Mgz9Y2mn2mPMePqXi/31kh0hVfymsY1wPUkP0WxM9xFTq+sr1VU8u1/S9eEq5wHB61LmGbLm/Jn7kFmdR5sbZtmRCdJ3zVj2Bf1O9LhSEq5chdP6g/fMscWsoLYF6BTFmtwn24St1Sf6qPFNG8M9a0KInGxAN0MxGDnWH1nFQ4rTG7Q1vuZY9WBPrA1SY68p/mKOF6OFGDyc9HnJ+Emc/xaIhoI/AW5b+a6ydOxryZyHBm2cnTc6EJZdgPpJcHjzOfRjFso9vcLTzP8lDsfo8evCdJG186z7Lp2FlMEZAivWDQJieYs6dggwz7tgwb2uk5BrFT7LdAnvFV2WN3S7D6tscZVSTOukiqZ4dgpsLCcqFgLorNiMu/8q7uEzltgESF6cXEL9vMBg3sJF2hbD1olTu6EdJ+RZFkgsxrn2IC/QOtXqvRo0LNY4eXHZGJqMcQKnClXZV/JbUMeQDL2xNB5WPjrZIBCoti5IN+189fMcTlqGL7E+PacYDO5MjEj59SqFVjeauzKM4Tzt9WNn2w9BF7T3VitKK/xZqNInfXz6mAtc1mgJmHHqOJEwepEJqWZY+HeeC4tpuEce/C+VOlS7jeNSislL20RCyELNmufL8HYOJfeeAl+EYBrSBgLrsA1+QIz7TpEIgfkHJmdO6fHNHuWbE1smx7tPiw/mSADbmerXuWoe1JDr3x32O2DHjIZQZqw2l+c8PpQCar1x7Nxgss4/EVV+Pfid7JUt5tE3LAf0OiN4VSaDfNM9lbi1siuUkI2bKhQRVMY3qXO+kTzUwdfmMt5AkIQrlEdFL59rGcptnt7xaCEcSe9Z458kllpeFU/ElkeTKBVqhEph5oja/qn+3MsDUCby53mYz8j6/PCBLg8HYWb2F+yeFpxtZKszK+JbNFwJpLc8baL3vm22r3WojdXrZPi/6fbX7xtedc6ag0TXE+xRAlMzdHqSpBWo/x/SGK0tvNGvSMim9Sqol0/KpSFWUp2JB5ilxlYEKytpFH1r7PG/oaDtZEX7oQlhrFiac9D0TGm0nlqagUTt24OkYMQnzd6b/ou1wdCHPGAVjKwhAl6TAxwYUw8FtLBnkjv6P07HaOpzEM7DRCJhvFo4E6UHS/+NratzmNVfoLmfNzqJBA+UmyH+oHJx8scRSwVZdXr8N2JCGgEfRqZ54NzHuKbYZZRtuQUJK15kU9PYRF3j8Fi91urCUuFk1tEdtkfC51ckYQzQyO4f/SP3GZ4mJBUTTeFC+FnfctDB3CJeULYP+XYcNZ0ygy8ZDhpHknoM2/Odo47O2gaiE4VCdmpUeiMlgDELgmZqYan56OWSa91LczvpwsGFIAz4EsHDJNlQNb5/0Z+UkF7v/teP9ssIThyof+7gNiykEe6N/onM8GLSXFB7Ud2h1ziifojMCFqT5wePryTslKYVqh0wBItQubCLlI4nCAMqAe+p0Q6tK4DYiosIeYgKcgrjVVgUUH4BIAA==",
	trollsage: "data:image/webp;base64,UklGRpAKAABXRUJQVlA4IIQKAACQNwCdASqQAHAAPnUuk0ckoiGhLLUs0JAOiWcA0Q+zzw6/L/kZ5t+Yr5bKbOK+xaQBmqtq/6/hRCpWs/25BgwDPyX8NxNaSg8IF2yzz8S3C+Kx99vHEMX9puvnh8AT29lbzCRRGtOHvlBMt9A107rj6GLBjHF/ZietbCFD/+6CGNOPe9CjX3oYBHTqkBZnM8vqO8rECHcNuSKXtn97vLwJ/XceHYtCYPo5ksAU5EEnV7NZ8dbmn8td+18is1rcDxf9LGP2KiSinp9TyuEG6KhzvYfcxKD7JHH8/U2WzWZGikFrwsOa5Wuf4nnBIxDjpH2gma1+PvoNRAvGPmqRiJ0gIFbmlp6zBVIQBFRwnIM+YNy9QD3O74WZc/iZl0/APdlR91ZpQUA62493Vle1+kJuJhBHkhcLbqihd4zfu0t1kSW53AShczcCwm5Vlgcmef2er+RB3OviMfWhFoq4quWnRUtAeZRITuJHycM/PUGiedczq75rIIwr6EIWA/7aeqZUEeQulUhEO1SSz1IvOTwC067vsAw3hotVQtydk4hseBf1LjJ+r6HsGMtFk8WV5/+u8GL/UxPm+2d4CU+KaOA8GEitzYAA/v1RecXPZXHu992olGMKK8u4nWfsEJp8/pLYcfCDegcxfh59+C6SUQnttEnwFCshivJaVtHqubxp7ewAf/mZD4D812p7ppcMaWraRZn9i17s//CZz4myXHuC1hJADae+/KPkqXxkNbntBTqIeGFM/Xgm3OoAFa2/zq5bXClZ6TT++Gu/V8an3CtLaUXo/bvl+Zx9zPmEYaRsW0IYA8fjBRUYxssIdQRRfQhrgd7FSdn0Akk5yyLbM5IXGmpq3GMdlAuWBNa136H4Gg9yfeNjMndlEXbYKrRegSqcItyiqcK8gaMwfRhxuoS1ZtdaWVb5mOeESJvQkGr/ku+CZUsU7kkDaMfGJ/pRKT7Cv4gg3APtwyPMoDHVSNCTN50Vxk8nm+3wLH35jwWsWUv9/mIX7dEKcvGSPSru6v9dsuettT+O4BQ7qXlJa14odQ1jf0G8ELmOI6dQZveCHwaO0aO2dgy/gsnVfux8Mydi7+lFAURnSLrZHQChf6cIPbkLCvFJMDqLg8bHhx83UUkmW7p0AyNr/1avYzoFdtVU3o/maxrNMX7Xs0jpc/plxRwmSjCxqZGFDPQnNkYsNNG02vN7RYvSEYXyIrpaTdR3Fszk/WA/Ycdm5JaiLtOVYnJyGOpC8JaW7tqPRZn0Iy5yY3DrQNj/ydeqsxjkDSQ9YQlOhTwPZwCaje94n3/iyPDk2+MZkVct13JAJMaH6HtAsl9jQXlZQd9A/9tkmnKwf3CsMjcUpD1WqvI0B+4rm3poLDrfM/1EJS4xkQ0pgdoX43z7MJuwsJ+gDRpzhAzymxrt8BtQ5jXaxp7Wv7IF5+GEf5i/PBU+EctYBaBXXha497Fd+uA7lLjAV+l61OKgLcOtpK4PoLbk8eRrhix47eAvPcGCND51WadaKUcSFcRAr5wo4+CdBmFuma6nzO/u8zQ37RSJECg4YLHUICa87CGcB7ArgeqgIZ6PWjFficu1NkO/G09a8Fie2X3pKo9/JujZMNWPrLf8gAL+KMKqgNMdkSe9kjpxy6vnMEZhl2UaF1NYA3umW1E/ZiV2sMWrsu2L9vEBY7ZZU9nI60rfKq8PPpfZqOmHAPgBZs27X/6p8aOxKVBqnqpWH/NKNY90NWECJAYzqDp0zdSQvSI5Bx2tleguca/OGT2d5VAyoCzZZxPVh8QwoiBicIyF23POVlAv0MwZz4e4/yFY3IX+UdgzfLIdAwQIkgM1Xit4PV8CbSprpNYWNt6eizGduuQkwmawutxkxAADiGG4nJ5+Xl9jxEyVqx9ycxd2qNhWJgh3xI9POGbxaRu9IOdlAaIe6sjz+XHKBDngTJ93AobE0na1i9q3bTWHXWLFrXFXRT4V5V8DZ2OYDV79ddyeXbRaVg0zH4psIy4diXq7Jg6Ky3f1nwsRb+w/Aop/3vNGON7saXj7NA2jz29Te5Y68uQ1HY0CwA3T0mva4w0HUI8FTw5iK+QSnaPz+acPJKww/hM7iDDYK0LKjvjqK/KQavhfhqogXtib4jhA2yprrUL7eiqskBku0PyCNZ4LRgVO6FBdw/AdssGn3VomjnIXYBLdlLzfGNxmRoXrHIwSMOMRnoNfGEPGINJjA9bQ53YB1TzanqCrP+G9WECQBQH5c8WumkwT6NGLP6NtEcqHY6rDjvSyRA91wLSM4oWbwDVaqzlMDiiLQZvU8hRS4w6nbTKe+j4h+NNz3Ymv8hF21wKW6A8+NtI4oPYuct4YDlcV6tZyvDW2Vy82Nc5rqVRCN60udDtdz6Xvsm37nfwW/p6crA1j04llCKjfixu6WvN4QWkFLbQlrNW5WwP5DoaXR3NNLKqvxMViqi4fR4meF46UDgCcZEW/DWDgwRN+dsnGOEdKcDCfqZOdPkr5/I/GaUUdlxTgh3GGENErAIykeWiGzn8AVje3nKV2N89mghrq7PYKeLZs5olFgyq8XzLwnItRRG0Bbz3UdYZhkSAIwN2v8KJ+qvLYSEQTztQfJHLMa1A2YwV+HyUT6UiqZocMGBLNiJejwTwbI2BJVcwmf75c2/WaSeVJEc8C8RAM6wPg65pNsbXdNtG93S+0FQh4bzl1sklWYU6K4eYZi3mHBHuPf2kQfYzFEfdxw59lACKkb7SuF1kfbluqcy1kbIRz2HeTtfEIBa0pXG+E9FcG/hWgWIwR01igVOu3RBU46Qui/BrvEMuQnX1TUgZsAY1YPAELOQHKO7om73Su5rQTwE81c4KGxwWgDBG/DzjEDITY+UKl0S7+nI4xz4QKgCYS5Ne3VMJ5cseQa9uZtE39h8TTWNi+sfN+y6IMWpbPxb7yt5jdWLEjmpuRn3hsY00EqNIiE62SzBapJLnghcnT6HA0lUm3Tnk05AZ+98Dj2DKAmYMFHkjVioDK9u/lbc3PDebZIJAGCzszaMThZHbKK3ZU06SqEbdMLYHgNISHK8vRWYXk3zwWAncjowTKe9hFdx5UnsKTHSPgS/qjCZ5eGSuerCtZp8zPK/ogWYj2yUdSfE7726z8oI2UZHIHMzgHwVwNUSWYq04eK+/kekl6/vHZMcfpYu3Im6XGQi3hmdwL53FY81uGI9uQm6oKtLN4/K4I1+N209MUzr7WutRc7hfGCXB781uMEdeJCInf/Xxf4pWLMJpIzQBVC6oAyOrInwjRp71l5ydPdhdSpyfkUzThZbU4S2Sk1cwej0zaduZ+vX+UmXSuMmNTYOLwIN5YWEujOZAc26bFGIsE8dJ1mPAyccczrEIVQxBUdBQamhi79wg4e2O8qMy0tiIuz8t3/xv1o1wXUHaCljRwsphr0jklsVrqJj+NBzaySs/zHh8JDIeVC1yDoVien1yXQZkOfIGR+xCZiQwS1dTc3A4YJJFUKV0D/OyQJ5xjrr3lmzW9wd7McZL8iFn/dlxxNUOCVE3OiKlvGf6kIntIGAvk3BVl4CzDe5Rzg2RwnxXiR+78okf6E+yj/NfJS5wV4jMV/kOyAAAA",
	trollyoungun: "data:image/webp;base64,UklGRnYNAABXRUJQVlA4IGoNAADwOwCdASqQAHAAPnU0lUikoqIhKDMKuJAOiWkA0Q+w/xn/MeC/lnBP7OdSDvH/l+tbtB4B3tH7suLJz55wk6eVLzIaAfk//8Plg/bvUP/W7/odkb0S/2lLfdaAeN8kIuDyPW4qvSqcKL9a4bdfVfI+Z8Xu6vQg3xy6L8T/0Jo9Yq/I34d/LJVFtCqE5fja28rycFKC8AhX53WaDu9aBmrIp1GUM+q3f+kmLyLrTxgBLQddGG/f7cPPwAqKO7FfWbMeOPU4LO5+quleRZ9yv+QOZostuo0CPaWeLZcsXbstqM+3yOyKWx4rDjIiyFc21RIO1CKzbR6rfdjQdLUKpVDUcsnVDmMDrbsUo8/Oa1wmSigJROChmEhepaoACByG2dA6Nbj+96MajR+/hKHXg2/MjcBPPOSBuHnNc8Zez3S1tA3FG14AfrBzPxaVt9N8le7uny51k6IWjY/MmbZAlrfZSGvrX2ic8+9wI/mURqgMUOyTe3p3fp3fYs6+AJgb+5Zd1WbUHqPnUJpi/ba0ZlfeuH9d90HjHlkqA+3wGqZLTmb9IKcjXBtvTm4jZ3/WWXktW2MvjxBTWN2X0sS3NDCQJo9m4R/yyx/JNCvpY+07bEf8OtQLOSw0p+Gxwm+ps1mSN4N4p/U76AD++g+RcI/vFIhzYjxauf+81rkJ4z82c9WJD9UROeSfdMurTjr2NAL8K3b+ESvpiY/a12wioozMzxuf1EuX/nvWQ7//lLYdGzbbli1/9BfvytXpJ9F/pUwO/j7GGlPUs5FOwGYKgg/bXG4pDqvzgC6+H6FF4K7v/vjnkGkiNtwi3f+Ork0QGRx9ZhnW6Bb29/j1L+2tlk5w3XEKxKXmo9WIZ809ggq7YZXV1glOHOAQ711tg63593oaMkAEH8fYWs4IAVU4uQpe63pSPCfo3IJHoxPmByIOTa0FijFifKc41rSwUGhov6p2kPwrKzeA6xRDeJbvR3L8npSZKo52g0RRfo8NbnQjn+0tjq+72gKdmfPB4qHotx1aom6ZNprQ2JPszqZP2gVQ3/Iq9vqljqAXi5DPkVdj7r6vPdHx1++VHYdnvwaXNZfNAplAf1lxwrb78zzHqmYXBA2M5AN4+fBctIdlOATruLoZzF52s9k4aybZJGddn7pD6N8pm50NA6IykrFcUNKnwAGUeWr17/taF/g99iL52xu/mj+sufEj9fC/X+8l9Ad+6u3ynPafCdwvHpZJE/YY3hvyo9SDjt99Z/+04s130KHGJWRuOnBgQb6wTPPIjbIkTWPg77+G2cz9cy3xXj5olEMf3Wl9K8HbI9io4nOtPNXS747+OWgyQdTFLd7K9MT8b7kyYHZ1GXu5A+JpFBWk9freCpM4QI0vgBD9dep4tRv/UTiSJ7MQi+9nH8oMp2KWbyOObUjAZCcX7JIIiqHFuxIeWaxz6yQy8w6vUutWtOZsbOhjFs3tu3FGX78DghUSPSN2+/0Y2vA3dAZGcsST5LaK5QqnP9Vt6Qrz9JLAlJ2x9gBe2oyNowGloq1CrxLfQiDUUQ/dI08uPKScnd8GvBvjFcWDUA8m1pPteZDhUekFHGNmG67OhVDV47jtuF096SXXUf/Zlan5kYhh3591PweTsDCxYaPNAM1bsAv2CpjvMQ+KTxg7nWoCfx538Qlz5hCeq7UJ79XxfK0Xfrm9og3kla55MkJD5uFnCkp2CoTcDDkE43tJKvJfFhDWrFKHheaOWh/fn0ulkfdXfeRapoSzbMdvUosUvLT+eLP/dUHpMMRu2LyvyaVYwk3m13u4RNFwk+Th1vDGdO9atewDNsRNS586+bnbL8S6FdBeCV9LAH0CxPYF0fPI7/LX9hP6m7aTc+OgT3oRyTQFjzwlY/EALUSGD4GLW4Tzi5Ta+OMcEnmrAtD/MvgiNzaNjTN9n9Usp0fQNv8cRLipLuwceVwb2LgeJMQfj2D/n33+njepBaqOyH0ajy9l66+MvT475GwKeCOJIl6b07LuVcfihBtUb+Iuzz8gY/eqWK+n0WPphs3mZDTyg183XVgWK5xAVjsdz3MTaPsjti0CfYiAW59Uj7dK7r3UiHcemRFD1TgjIJ06M8fskU7m1zZBwPXeh+ddsQdFkl61fqcaeYNKSFO8CIY+Pw5VHa/sJeRfVLQ2E/yrXK1VLDaNe6j5h6HaBPokXM67AFBHyVUWOJBn4/qUp74NFVgn0+k+ajvnZzQbpTgxURepub5lnn/iRmMyvsnu1vbF2JQuV2wRg01c/tTMV/RrDTPbQEYalMzEPY+OMeaWsUgetrXWIwYZjrxis8z+9RKzYQlVJ3c9Xq0UZhLvEYJqckY9ozK7D38Ag+3ajAkTop1xEk7+WV721pYihPUvimJ43hWUN9D2SRmZsHHtMAVFqDpngSu3KTumxLJvzjZOBg609gIMr/C6G3RkSIi8tTPKrC8JZm11+cOw3OudNY2eWHx0ABP+zyZ8t3yZTJ6oqtbokkAv/AFXtW+dsSfMk9v9iOaJ5ECl+AJL80TDdEJjAve3zjAhwKrTcR1UVh4KqBpIZxyJEVXQXUWK+eZ/qE8UwqceYJjfQWvvzn+nkBQb3cdGJfP3S4lwu2a4LjhXTZiIgFj1ImKRwd3MxyS9oezR6JA5mmvnDo/zivKtCVVwWsq4MNQZajwTG3pkM6l0Xglez01BCYrjZ31VzRRLJn5UHmHHWvusKeiSC/D2zkK/HfO+qnZRY9BOIXQNeofT4aED7XOnUH3JoAnNR9cwAGJjMnqDp+pYDCqtusDYFZ8ou5DKR++PhJ5pK0esykwG+lbKsQsRN5EIwnX9eO4fFl0j94oTBeonvLzc+5biOdQBr6xF4abKNn8cuIgCkT6vjd8v5vQJFV7shh2Vdoz64P7e6TDly4ghQyT+rita5pqKJms3LcZyRLoW3XsPLJc4R1HSV9wJ/R89r3cBr/euaovDQyOoaUARcVdtAwY6wFwhHvj2jPaBmQ005ex6WkQj6H+/8MDyNXGv4QGiJ2KbxAQZzqAojut3u25miyn4PilUUjacy4d33X+uMcSjTb42vqRi9YR/9mAaO6uB5jhQ9ZQe5celUmt02FOPk4Wwz+DOfuuyaM6kjDwAI2hTNJ9wvkYbvRrUTurWllnWtoRDsmFxL+IPmPJ4rgE2MqRqFbjnvVZlJEArDnhVp8ENtwraLuLBL/lhg7GUY/E1EX9RghfNKHcYZGlZCyWwK0oK04z8WO9SMW8auQeiKV7fUGbA8Eyx/XBXKpk4vaJsvnBu7/MWFxtPF3mmm8j4BSgPSNvuupiMpM4dTB0xMRjDfbL1S4utyRaD9f1EzGVIo2AZjnOh7Hisr8ljxgvQZ5WIozpfpw0Yrspbyd4ZBzMZ2HNPuomRdS0m2ljV3k5TO6KyVJuIT+dsT3gUSrFJg0GsP8vrWVNVT/U9f/7I+cRBZnnGtij8g68FECsTczFRHJbZGGKDXv4Pr6DjsgBiFnm92HCaD/PB5nKNFCV4hLLoTY43O6IJ/L6F7LiX0Zy6Hd+vDpc0/pK/Pm94TFVM7qEQiZC+wEw/gJ7dcrvsKMfBtJpMIe/njifIp3cZB4+zWOseThvSk2QByIydmCa2+gS7easjDYJnB3GGC0YUds7cr6aB7vQC/m9wGnZLl4R1gks7MJsGdlY4hQLPedhh4ZtKRkOBbOGGzTWxquhpLq4O3UygS63QPHQC0mGoPZZ6CbHBmyMzdg90sOZlj0nJz8SkMlGYkEw9nlnN3IbPOwnb9OdKQIrXH0r6+CvHIUfp0VgbOdh7G3ssVeXyyO9zj87r1f7BwR+yoVkb5HrE1w5pN/+D2XTmlG/kgWaNRPBzYjQzkf/RQbbsGDqkYMLQvs2eeI/umCITpmgzLWuBsIUi8kOzS/nr+vx52SCoHDItIZqrFCn+lvCBDrEzQX/zq7BzalKn2xzK65xZvkNxK3/YuNQEMqFYtb6WC7SGco2Bkg9OJA/+Llo02lcgjIvJRxHxcPkhnLXSI5roZw3yZCSWG8sCt4zKKptVYJe71ul98Q0Okk2FEa/QIm2ivt2PSto+UTJBLnV7D6yWRZc4ySZaJ1vUWNs+bhCmRk11GMSjT40oTep+piexejj+0GlX5JzM5WPSCYzbsBDUPSuPi3VQUC/H82zu9o70lZOBgmGa4GrS7Sm8sDrug7SfP4f/xYhqj7SAwas7M+lkLCF5g0yAMMnOloXkRnhvY7TeNPzKAkoOmvZawnZ1qdf5fkfbef9Zh/Qs6HjDGVXZSK7Vh0+DmjwAY7aR7RxLcfeLcG0Udp5P6KkT8Ui/4ih+98Ieb3V9Dfq6whagH+f85WAnhS+LzgN0aJhSI/yQsGmugmMpoLGjG1oAL6R1lEkCZPmfcTSVh2TZZFe8IHtUWKlowNqtvsoeKvdKbplXNwPpBTiah6wseRVQ1f2e4eVY++n4IF58UgrBPRZrN9nMIiIaQgdl8iIV1sO5EM5NGgRygJrXvmdqa7eaHEIxHokQTaB8pI+fBh1sRrASw59O08/eHx+f0jurQpWoKg5TQ8P8uXUlTHUE1VyJYzXYKE3+hG5DqcTrUuFZjPAAAA=="
}, Zn = {
	dex: "M8 3c2-1 4 1 4 3l-2 4-3-1-1-3zM6 12l3 1-1 3-3-1zM17 8c2-1 4 1 4 3l-2 4-3-1-1-3zM15 17l3 1-1 3-3-1z",
	hp: "M12 2C10 7 5 13 5 16a7 7 0 0014 0c0-3-5-9-7-14z",
	initiative: "M3 7h18M3 12h18M3 17h18",
	attack: "M4 20l6-6m-3-3l6 6M10 14l9-9 3-2-1 4-9 9M2 22l3-3",
	defense: "M12 2l8 4v5c0 5-3 8-8 11-5-3-8-6-8-11V6z M12 6v10 M8 10h8",
	melee: "M5 19L19 5M14 5h5v5M5 5l14 14M10 5H5v5",
	ranged: "M4 20L20 4M7 4l13 13M7 4Q1 19 20 17 M14 4h6v6",
	weakest: "M4 12a8 8 0 1116 0M12 2v5M2 12h4m12 0h4M12 9h.1m-2 9 2-5 2 5",
	strongest: "M4 12a8 8 0 1116 0M12 2v5M2 12h4m12 0h4M12 9h.1m-4 9 4-5 4 5m-7 3 3-3 3 3",
	beast: "M6 7h.1M12 5h.1M18 7h.1M20 12h.1M6 17c1-2 3-5 6-5s5 3 6 5-1 4-3 3l-3-1-3 1c-2 1-4-1-3-3z",
	goblin: "M6 19C3 13 8 8 17 3c2 9-2 16-7 18z M8 17l6-7",
	orc: "M12 13v9M3 4l9 5 9-5-1 10-8-1-8 1z",
	troll: "M10 13l9-8 2 2-8 9M3 12l5-4 8 9-5 4z",
	scales: "M12 3C5 8 4 15 12 21c8-6 7-13 0-18zm0 5v8",
	bog: "M3 10c0-3 3-6 9-6s9 3 9 6l-4 2v5l-5 3-5-3v-5z M8 10h.1m8 0h.1",
	object: "M12 2 22 12 12 22 2 12z M12 7v10"
};
function Qn({ kind: e }) {
	return /* @__PURE__ */ b("svg", {
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2.25",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: /* @__PURE__ */ b("path", { d: Zn[e] })
	});
}
function $n(e, t) {
	let n = t.enemyDefense.reduce((e, t) => e + t, 0);
	return [
		{
			kind: "hp",
			label: e("games.toomanybones.hp"),
			value: t.hp + "/" + t.maxHp
		},
		{
			kind: "initiative",
			label: e("games.toomanybones.initiativeScore"),
			value: t.initiative
		},
		{
			kind: "attack",
			label: e("games.toomanybones.attack"),
			value: t.attack
		},
		{
			kind: "defense",
			label: e("games.toomanybones.defense"),
			value: n ? t.defense + "+" + n : t.defense
		}
	];
}
function er({ stats: e }) {
	return /* @__PURE__ */ b("span", {
		className: "tmb-chip-stats",
		children: e.map(({ kind: e, label: t, value: n }) => /* @__PURE__ */ x("span", {
			className: "tmb-chip-stat",
			"data-stat": e,
			title: t + " " + n,
			children: [/* @__PURE__ */ b(Qn, { kind: e }), /* @__PURE__ */ b("b", {
				"data-compact": String(n).length > 3 || void 0,
				children: n
			})]
		}, e))
	});
}
function tr({ actor: e, name: t, selected: n, current: r }) {
	let i = c(), a = Te(e), o = Xn[e.gearloc ?? e.definition], s = e.kind === "baddie", l = $n(i, e);
	return /* @__PURE__ */ x(y, { children: [
		/* @__PURE__ */ b("span", {
			className: "tmb-chip-portrait",
			children: o ? /* @__PURE__ */ b("img", {
				alt: "",
				src: o,
				draggable: !1
			}) : /* @__PURE__ */ b(Qn, { kind: e.kind === "object" ? "object" : "defense" })
		}),
		s ? /* @__PURE__ */ x(y, { children: [
			/* @__PURE__ */ b(er, { stats: l.slice(0, 2) }),
			/* @__PURE__ */ b(er, { stats: l.slice(2) }),
			/* @__PURE__ */ x("span", {
				className: "tmb-chip-badges",
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ b("span", { children: /* @__PURE__ */ b(Qn, { kind: e.ranged ? "ranged" : "melee" }) }),
					/* @__PURE__ */ b("span", { children: /* @__PURE__ */ b(Qn, { kind: e.target }) }),
					a && /* @__PURE__ */ b("span", {
						"data-creature": a.creature,
						children: /* @__PURE__ */ b(Qn, { kind: a.creature })
					})
				]
			})
		] }) : /* @__PURE__ */ x("span", {
			className: "tmb-chip-friendly-hp",
			children: [/* @__PURE__ */ b(Qn, { kind: "hp" }), l[0].value]
		}),
		/* @__PURE__ */ b("span", {
			className: "tmb-chip-plaque",
			children: /* @__PURE__ */ b("span", { children: t })
		}),
		n && /* @__PURE__ */ b("span", {
			className: "tmb-target-tag",
			children: i("games.toomanybones.target")
		}),
		(n || r) && /* @__PURE__ */ b("span", {
			className: "tmb-chip-status",
			"aria-hidden": "true"
		})
	] });
}
//#endregion
//#region src/game/gearlocs.ts
var nr = {
	boomer: [
		{
			key: "games.toomanybones.profBoomerScavenger",
			briefKey: "games.toomanybones.profBoomerScavengerBrief",
			skills: [
				1,
				2,
				3,
				4
			]
		},
		{
			key: "games.toomanybones.profBoomerGrenadier",
			briefKey: "games.toomanybones.profBoomerGrenadierBrief",
			skills: [
				5,
				6,
				9,
				10
			]
		},
		{
			key: "games.toomanybones.profBoomerBomber",
			briefKey: "games.toomanybones.profBoomerBomberBrief",
			skills: [
				7,
				8,
				11
			]
		},
		{
			key: "games.toomanybones.profBoomerKeenEye",
			briefKey: "games.toomanybones.profBoomerKeenEyeBrief",
			skills: [
				13,
				14,
				15
			]
		},
		{
			key: "games.toomanybones.profBoomerConsumables",
			briefKey: "games.toomanybones.profBoomerConsumablesBrief",
			skills: [12, 16]
		}
	],
	patches: [
		{
			key: "games.toomanybones.profPatchesMedic",
			briefKey: "games.toomanybones.profPatchesMedicBrief",
			skills: [
				1,
				2,
				3,
				7,
				11
			]
		},
		{
			key: "games.toomanybones.profPatchesForester",
			briefKey: "games.toomanybones.profPatchesForesterBrief",
			skills: [5, 6]
		},
		{
			key: "games.toomanybones.profPatchesStim",
			briefKey: "games.toomanybones.profPatchesStimBrief",
			skills: [
				9,
				10,
				13,
				14,
				15,
				16
			]
		},
		{
			key: "games.toomanybones.profPatchesConsumables",
			briefKey: "games.toomanybones.profPatchesConsumablesBrief",
			skills: [
				4,
				8,
				12
			]
		}
	],
	picket: [
		{
			key: "games.toomanybones.profPicketCaptain",
			briefKey: "games.toomanybones.profPicketCaptainBrief",
			skills: [
				1,
				2,
				5,
				6
			]
		},
		{
			key: "games.toomanybones.profPicketHero",
			briefKey: "games.toomanybones.profPicketHeroBrief",
			skills: [
				11,
				12,
				15,
				16
			]
		},
		{
			key: "games.toomanybones.profPicketProtector",
			briefKey: "games.toomanybones.profPicketProtectorBrief",
			skills: [3, 7]
		},
		{
			key: "games.toomanybones.profPicketWarden",
			briefKey: "games.toomanybones.profPicketWardenBrief",
			skills: [
				9,
				10,
				13,
				14
			]
		},
		{
			key: "games.toomanybones.profPicketConsumables",
			briefKey: "games.toomanybones.profPicketConsumablesBrief",
			skills: [4, 8]
		}
	],
	tantrum: [
		{
			key: "games.toomanybones.profTantrumZerker",
			briefKey: "games.toomanybones.profTantrumZerkerBrief",
			skills: [
				1,
				2,
				3,
				4
			]
		},
		{
			key: "games.toomanybones.profTantrumMimic",
			briefKey: "games.toomanybones.profTantrumMimicBrief",
			skills: [
				5,
				6,
				7
			]
		},
		{
			key: "games.toomanybones.profTantrumSkirmisher",
			briefKey: "games.toomanybones.profTantrumSkirmisherBrief",
			skills: [
				9,
				10,
				11,
				13,
				14,
				15
			]
		},
		{
			key: "games.toomanybones.profTantrumConsumables",
			briefKey: "games.toomanybones.profTantrumConsumablesBrief",
			skills: [
				8,
				12,
				16
			]
		}
	]
}, rr = {
	boomer: {
		key: "games.toomanybones.backupBoomer",
		costs: [
			1,
			2,
			3,
			4,
			5,
			6
		]
	},
	patches: {
		key: "games.toomanybones.backupPatches",
		costs: [
			2,
			3,
			4,
			5,
			6
		]
	},
	picket: {
		key: "games.toomanybones.backupPicket",
		costs: [
			2,
			3,
			4,
			5,
			6
		]
	},
	tantrum: {
		key: "games.toomanybones.backupTantrum",
		costs: [
			1,
			2,
			4,
			5,
			6
		]
	}
}, ir = {
	boomer: {
		key: "games.toomanybones.innateScavenger",
		briefKey: "games.toomanybones.innateScavengerBrief",
		upgradeKey: "games.toomanybones.innateScavengerUpgrade",
		upgradeBriefKey: "games.toomanybones.innateScavengerUpgradeBrief"
	},
	patches: {
		key: "games.toomanybones.innateRecovery",
		briefKey: "games.toomanybones.innateRecoveryBrief",
		upgradeKey: "games.toomanybones.innateRecoveryUpgrade",
		upgradeBriefKey: "games.toomanybones.innateRecoveryUpgradeBrief"
	},
	picket: {
		key: "games.toomanybones.innateShieldWall",
		briefKey: "games.toomanybones.innateShieldWallBrief",
		upgradeKey: "games.toomanybones.innateShieldWallUpgrade",
		upgradeBriefKey: "games.toomanybones.innateShieldWallUpgradeBrief"
	},
	tantrum: {
		key: "games.toomanybones.innateRage",
		briefKey: "games.toomanybones.innateRageBrief",
		upgradeKey: "games.toomanybones.innateRageUpgrade",
		upgradeBriefKey: "games.toomanybones.innateRageUpgradeBrief"
	}
}, ar = {
	boomer: "games.toomanybones.boomer",
	patches: "games.toomanybones.patches",
	picket: "games.toomanybones.picket",
	tantrum: "games.toomanybones.tantrum"
}, or = {
	nom: "games.toomanybones.nom",
	gendricks: "games.toomanybones.gendricks",
	duster: "games.toomanybones.duster",
	mulmesh: "games.toomanybones.mulmesh",
	drellen: "games.toomanybones.drellen",
	marrow: "games.toomanybones.marrow",
	goblinking: "games.toomanybones.goblinking"
}, sr = {
	recruit: "games.toomanybones.recruit",
	training: "games.toomanybones.training",
	day: "games.toomanybones.day",
	encounter: "games.toomanybones.encounter",
	challenge: "games.toomanybones.challenge",
	battle: "games.toomanybones.battle",
	recovery: "games.toomanybones.recovery",
	done: "games.toomanybones.done"
}, cr = {
	boomer: "games.toomanybones.skillsBoomer",
	patches: "games.toomanybones.skillsPatches",
	picket: "games.toomanybones.skillsPicket",
	tantrum: "games.toomanybones.skillsTantrum"
}, lr = {
	boomer: "games.toomanybones.skillRulesBoomer",
	patches: "games.toomanybones.skillRulesPatches",
	picket: "games.toomanybones.skillRulesPicket",
	tantrum: "games.toomanybones.skillRulesTantrum"
}, ur = (e, t, n) => e(lr[t]).split("|")[n - 1] ?? "", dr = "attack,defense,bones,forcedBones,reusableBones,element,casing,fuse,grenades,explosion,blast,partyBacklash,backlash,stun,napalm,cleanse,smoke,disable,parts,loot,buffHp,biggerBoom,holyAcquire,element325,holyBlast,holyExplosion,heal,healMultiply,healReroll,meleeDamage,trueDamage,revive,reviveKo,poisonTarget,poisonAny,buffAttack,buffReroll,recover,booster,permanentHp,tainted,constantRegen,constantMove,constantDefense,constantDamage,constantTaunt,improvedDefense,advancedDefense,intercept,ale,healSelf,switch,rush,riposte,anger,advance,axe,poisonArmor,lashback,hardy,dropInitiative,attackMinus,attackPlus,trainAttack,partyInspire,disorient,jump,taunt,rage,axes,bodyCount,cells,blank,poison,bleed,weaken,terrify,untargetable,flight,limit,initiative".split(","), fr = (e, t, n) => e(cr[t]).split("|")[n - 1] ?? String(n), pr = (e, t) => e("games.toomanybones.effectNames").split("|")[dr.indexOf(t)] ?? e("games.toomanybones.effect"), mr = (e, t) => {
	let n = se(t);
	return n ? e(n.trove ? "games.toomanybones.troveNames" : "games.toomanybones.lootNames").split("|")[n.slot] : e("games.toomanybones.loot");
}, hr = (e, t) => {
	let n = se(t);
	return n ? e(n.trove ? "games.toomanybones.troveRules" : "games.toomanybones.lootRules").split("|")[n.slot] ?? "" : "";
}, gr = "lashback,flight,thickSkin,careless,raiding,rage,poison,break,mischief,hardy,weaken,engulf,compound,inspire,terrify,dive,signal,taunt,corrosive,recover,undead,limit,shrouded,hide,frenzy,retreat,bogRuler,callOrc,boom,kaboom".split(","), _r = (e, t) => e("games.toomanybones.baddieRules").split("|")[gr.indexOf(t)] ?? "";
function vr(e) {
	let t = e.indexOf("："), n = e.indexOf(": "), r = t >= 0 ? t : n;
	return r < 0 ? ["", e] : [e.slice(0, r).trim(), e.slice(r + (t >= 0 ? 1 : 2)).trim()];
}
var yr = (e, t) => {
	let n = rr[t];
	return n.costs.map((t, r) => ({
		cost: t,
		text: e(n.key).split("|")[r] ?? ""
	}));
}, br = [
	"omnom",
	"thunderclub",
	"orb",
	"charred",
	"cloak",
	"dagger",
	"silverHide",
	"howl",
	"enhance",
	"poison",
	"bloodRage",
	"skullAxe",
	"callHelp",
	"carelessBomb"
], xr = (e) => br.findIndex((t) => e === t || e.startsWith(t + ":")), Sr = (e, t) => e("games.toomanybones.tyrantFaceNames").split("|")[xr(t)] ?? t, Cr = (e, t) => e("games.toomanybones.tyrantFaceRules").split("|")[xr(t)] ?? "", wr = "buff,damage,defeatAdventure,encounter,challengeRoll,flick,battle,defeat,effect,enemyRoll,inspire,ko,lootUsed,revive,round,tyrantDie,victory,dartsRoll,lockStart,lockSuccess,lockFail,search,backup,rage,roll,trained,trainingRoll,heal,loot,trove,encounterSuccess,encounterFailed".split(","), Tr = (e, t) => e("games.toomanybones.logEvents").split("|")[wr.indexOf(t)] ?? pr(e, t);
function Er(e, t) {
	if (t.gearloc) return e(ar[t.gearloc]);
	let n = or[t.definition];
	if (n) return e(n);
	let r = ne.findIndex((e) => e.id === t.definition);
	return r >= 0 ? e("games.toomanybones.baddieNames").split("|")[r] : e("games.toomanybones.objectNames").split("|")[[
		"orb",
		"orbPillar",
		"throne",
		"rat",
		"cloaked",
		"trader"
	].indexOf(t.definition)] ?? e("games.toomanybones.target");
}
var Dr = {
	startingLoot: "games.toomanybones.startingLoot",
	troveRedraw: "games.toomanybones.troveRedraw",
	troveImmediate: "games.toomanybones.troveImmediate",
	discardThenRedraw: "games.toomanybones.discardThenRedraw",
	bribe: "games.toomanybones.bribe",
	snipe: "games.toomanybones.snipe",
	grab: "games.toomanybones.grab",
	whirlwind: "games.toomanybones.whirlwind",
	trapHp: "games.toomanybones.trapHp",
	duel: "games.toomanybones.duel",
	scoutReturn: "games.toomanybones.scoutReturn",
	exhaustStats: "games.toomanybones.exhaustStats",
	barrelCount: "games.toomanybones.barrelCount",
	gambleLoot: "games.toomanybones.gambleLoot",
	offering: "games.toomanybones.offering",
	tripSkills: "games.toomanybones.tripSkills",
	wolfHand: "games.toomanybones.wolfHand",
	healDuster: "games.toomanybones.healDuster",
	bogIngredients: "games.toomanybones.bogIngredients",
	goblinBomb: "games.toomanybones.goblinBomb"
}, Or = {
	s1: "games.toomanybones.encounters.s1",
	s2: "games.toomanybones.encounters.s2",
	s3: "games.toomanybones.encounters.s3",
	s4: "games.toomanybones.encounters.s4",
	s5: "games.toomanybones.encounters.s5",
	s6: "games.toomanybones.encounters.s6",
	g1: "games.toomanybones.encounters.g1",
	g2: "games.toomanybones.encounters.g2",
	g3: "games.toomanybones.encounters.g3",
	g4: "games.toomanybones.encounters.g4",
	g5: "games.toomanybones.encounters.g5",
	g6: "games.toomanybones.encounters.g6",
	g7: "games.toomanybones.encounters.g7",
	g8: "games.toomanybones.encounters.g8",
	g9: "games.toomanybones.encounters.g9",
	g10: "games.toomanybones.encounters.g10",
	g11: "games.toomanybones.encounters.g11",
	g12: "games.toomanybones.encounters.g12",
	g13: "games.toomanybones.encounters.g13",
	g14: "games.toomanybones.encounters.g14",
	g15: "games.toomanybones.encounters.g15",
	g16: "games.toomanybones.encounters.g16",
	g17: "games.toomanybones.encounters.g17",
	g18: "games.toomanybones.encounters.g18",
	g19: "games.toomanybones.encounters.g19",
	g20: "games.toomanybones.encounters.g20",
	g21: "games.toomanybones.encounters.g21",
	g22: "games.toomanybones.encounters.g22",
	g23: "games.toomanybones.encounters.g23",
	g24: "games.toomanybones.encounters.g24",
	g25: "games.toomanybones.encounters.g25",
	g26: "games.toomanybones.encounters.g26",
	g27: "games.toomanybones.encounters.g27",
	g28: "games.toomanybones.encounters.g28",
	g29: "games.toomanybones.encounters.g29",
	g30: "games.toomanybones.encounters.g30",
	o1: "games.toomanybones.encounters.o1",
	o2: "games.toomanybones.encounters.o2",
	o3: "games.toomanybones.encounters.o3",
	o4: "games.toomanybones.encounters.o4",
	o5: "games.toomanybones.encounters.o5",
	o6: "games.toomanybones.encounters.o6",
	o7: "games.toomanybones.encounters.o7",
	o8: "games.toomanybones.encounters.o8",
	o9: "games.toomanybones.encounters.o9",
	o10: "games.toomanybones.encounters.o10",
	o11: "games.toomanybones.encounters.o11",
	o12: "games.toomanybones.encounters.o12",
	t1: "games.toomanybones.encounters.t1",
	t3: "games.toomanybones.encounters.t3",
	t4: "games.toomanybones.encounters.t4",
	t6: "games.toomanybones.encounters.t6",
	t7: "games.toomanybones.encounters.t7",
	t8: "games.toomanybones.encounters.t8",
	t10: "games.toomanybones.encounters.t10",
	t12: "games.toomanybones.encounters.t12",
	t14: "games.toomanybones.encounters.t14",
	t15: "games.toomanybones.encounters.t15",
	t17: "games.toomanybones.encounters.t17",
	t18: "games.toomanybones.encounters.t18"
}, kr = {
	bones: "M7 6l11 11m-9-9c-4 1-6-2-4-4 1-2 3-1 4 0 2-1 4 1 3 3l6 6c4-1 6 2 4 4-1 2-3 1-4 0-2 1-4-1-3-3L9 8z M17 6 6 17m-1-4c-3 0-4 3-2 4 0 2 2 3 4 1l1-2 8-8c3 1 5-1 4-3-1-2-3-2-4-1",
	sword: "M3 22l7-7m-4-3l6 6m-3-3L20 4l2-2-1 5-10 10",
	shield: "M12 3l8 3v6c0 4-3 7-8 10-5-3-8-6-8-10V6z",
	heart: "M12 21C1 14 1 10 3 7c3-4 7-3 9 0 2-3 6-4 9 0 2 3 2 7-9 14z",
	move: "M5 18c-2-3 1-6 5-6s5-5 8-5c4 0 3 4 2 6-2 4-5 4-9 5-1 2-5 3-6 0z M4 6h8m-3-3 3 3-3 3",
	taunt: "M3 4h18v13H11l-5 5v-5H3z M7 12l3-4 3 5 3-5",
	bomb: "M17 8a8 8 0 1 1-11 11A8 8 0 0 1 17 8zm-2-2 3-3 4 1",
	poison: "M9 2h6M10 2v7l-6 9a2 2 0 0 0 2 3h12a2 2 0 0 0 2-3l-6-9V2M7 16h10",
	flame: "M13 2c1 6-3 7-2 11-3-1-3-4-3-5-7 7-4 14 4 14 8 0 11-8 1-20z",
	bolt: "M14 2 4 14h7l-1 8 10-13h-7z",
	swap: "M2 8h18m-5-5 5 5-5 5M22 17H4m5-5-5 5 5 5",
	bag: "M8 3h8v6c11 7 6 13-4 13S-3 16 8 9zM8 9h8",
	cup: "M4 4h13v15H4z M17 7h5v6h-5 M8 4v15m5-15v15",
	rings: "M9 5a6 6 0 1 0 0 12 6 6 0 1 0 0-12zm6 2a6 6 0 1 0 0 12 6 6 0 1 0 0-12z",
	repeat: "M19 9a8 8 0 1 0 0 7m0-12v5h-5",
	phial: "M8 3h8v4l-2 2v4l3 5v3H7v-3l3-5V9L8 7z M9 16h6",
	target: "M12 2v5m0 10v5M2 12h5m10 0h5M12 5a7 7 0 1 0 0 14 7 7 0 1 0 0-14z",
	shock: "M3 13h4l3-9 4 15 3-8h4",
	cross: "M9 3h6v6h6v6h-6v6H9v-6H3V9h6z",
	eye: "M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z M9 12a3 3 0 1 0 6 0 3 3 0 1 0-6 0",
	star: "M12 2l3 7 7 1-5 5 1 7-6-4-6 4 1-7-5-5 7-1z",
	blank: "M7 12h10"
}, Ar = {
	attack: "sword",
	defense: "shield",
	bones: "bones",
	forcedBones: "bones",
	reusableBones: "bones",
	blank: "blank",
	element: "poison",
	casing: "bomb",
	fuse: "flame",
	grenades: "bomb",
	explosion: "bomb",
	blast: "bomb",
	napalm: "flame",
	cleanse: "cross",
	smoke: "eye",
	heal: "heart",
	healSelf: "heart",
	revive: "cross",
	reviveKo: "cross",
	poison: "poison",
	poisonAny: "poison",
	tainted: "poison",
	attackPlus: "sword",
	attackMinus: "sword",
	trueDamage: "sword",
	poisonTarget: "poison",
	partyBacklash: "shock",
	backlash: "shock",
	disable: "target",
	biggerBoom: "bomb",
	holyAcquire: "bag",
	element325: "phial",
	holyBlast: "bomb",
	holyExplosion: "bomb",
	healMultiply: "rings",
	healReroll: "repeat",
	meleeDamage: "sword",
	buffReroll: "repeat",
	recover: "heart",
	booster: "phial",
	constantRegen: "heart",
	constantMove: "move",
	constantDefense: "shield",
	constantDamage: "sword",
	constantTaunt: "taunt",
	switch: "swap",
	rush: "move",
	jump: "move",
	riposte: "sword",
	intercept: "shield",
	advancedDefense: "shield",
	improvedDefense: "shield",
	anger: "flame",
	advance: "move",
	axe: "sword",
	axes: "sword",
	rage: "flame",
	bodyCount: "bones",
	cells: "bolt",
	stun: "bolt",
	loot: "bag",
	parts: "bag",
	buffHp: "heart",
	buffAttack: "sword",
	permanentHp: "heart",
	ale: "cup",
	poisonArmor: "shield",
	lashback: "shock",
	hardy: "shield",
	dropInitiative: "target",
	trainAttack: "sword",
	partyInspire: "star",
	disorient: "shock",
	taunt: "taunt",
	bleed: "heart",
	weaken: "shock",
	terrify: "taunt",
	untargetable: "eye",
	flight: "move",
	limit: "target",
	initiative: "bolt",
	omnom: "taunt",
	thunderclub: "shock",
	orb: "target",
	charred: "flame",
	cloak: "eye",
	dagger: "sword",
	silverHide: "shield",
	howl: "taunt",
	enhance: "phial",
	bloodRage: "flame",
	skullAxe: "sword",
	callHelp: "taunt",
	carelessBomb: "bomb"
}, jr = /* @__PURE__ */ new Set([
	"constantRegen",
	"constantMove",
	"constantDefense",
	"constantDamage",
	"constantTaunt"
]);
function Mr({ face: e }) {
	let t = c(), n = _e(e), r = n.map(({ kind: e, n, extra: r }) => [
		pr(t, e),
		n || "",
		r ? `× ${r}` : ""
	].filter(Boolean).join(" ")).join(" · ");
	return /* @__PURE__ */ b("span", {
		className: "tmb-face-art",
		role: "img",
		"aria-label": r,
		title: r,
		children: n.map(({ kind: e, n: t, extra: n }, r) => {
			let i = Ar[e] ?? "star", a = !!t && !(t === 1 && [
				"bones",
				"forcedBones",
				"reusableBones",
				"constantTaunt",
				"blank"
			].includes(e));
			return /* @__PURE__ */ x("svg", {
				viewBox: "0 0 28 28",
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ b("path", {
						d: kr[i],
						transform: "translate(2 1)",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "1.8",
						strokeLinecap: "round",
						strokeLinejoin: "round"
					}),
					(jr.has(e) || e === "reusableBones") && /* @__PURE__ */ b("path", {
						className: "tmb-face-repeat",
						d: "M4 24c4 0 7-5 11-5 4 0 4 5 1 5-4 0-7-5-11-5-3 0-4 5-1 5z",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "1.4"
					}),
					a && /* @__PURE__ */ x("text", {
						x: "25",
						y: "10",
						textAnchor: "end",
						children: [t, n ? `×${n}` : ""]
					})
				]
			}, r);
		})
	});
}
//#endregion
//#region src/game/battle-pickers.tsx
function Nr({ label: e, options: t, value: n, onChange: r }) {
	return t.length ? /* @__PURE__ */ x("fieldset", {
		className: "tmb-picker",
		children: [/* @__PURE__ */ b("legend", { children: e }), /* @__PURE__ */ b("div", {
			className: "tmb-picker-tiles",
			children: t.map((e) => /* @__PURE__ */ x("button", {
				type: "button",
				"aria-pressed": e.value === n,
				disabled: e.disabled,
				onClick: () => r(e.value),
				children: [e.art, e.label]
			}, e.value))
		})]
	}) : null;
}
function Pr({ label: e, value: t, min: n = 0, max: r, onChange: i }) {
	return /* @__PURE__ */ x("fieldset", {
		className: "tmb-picker tmb-counter-dial",
		children: [
			/* @__PURE__ */ b("legend", { children: e }),
			/* @__PURE__ */ b("button", {
				type: "button",
				"aria-label": `${e} −1`,
				disabled: t <= n,
				onClick: () => i(t - 1),
				children: "−"
			}),
			/* @__PURE__ */ b("output", {
				"aria-live": "polite",
				children: t
			}),
			/* @__PURE__ */ b("button", {
				type: "button",
				"aria-label": `${e} +1`,
				disabled: t >= r,
				onClick: () => i(t + 1),
				children: "+"
			})
		]
	});
}
function Fr({ gearloc: e, ids: t, value: n, onChange: r }) {
	let i = c();
	return /* @__PURE__ */ b(Nr, {
		label: i("games.toomanybones.chooseSkills"),
		value: n,
		onChange: r,
		options: t.map((t) => ({
			value: t,
			label: fr(i, e, t),
			art: /* @__PURE__ */ b(Mr, { face: ce[e][t - 1].faces[0] })
		}))
	});
}
function Ir({ actor: e }) {
	let t = Xn[e.definition];
	return /* @__PURE__ */ x("span", {
		className: "tmb-picker-piece",
		children: [t ? /* @__PURE__ */ b("img", {
			src: t,
			alt: ""
		}) : /* @__PURE__ */ b(Qn, { kind: "defense" }), /* @__PURE__ */ b("small", { children: e.hp })]
	});
}
function Lr({ actors: e, legal: t, selected: n, onPick: r, targets: i }) {
	let a = c();
	return t.length ? /* @__PURE__ */ x("fieldset", {
		className: "tmb-picker",
		children: [/* @__PURE__ */ b("legend", { children: a(i ? "games.toomanybones.target" : "games.toomanybones.position") }), /* @__PURE__ */ b("div", {
			className: "tmb-picker-board",
			children: Array.from({ length: 16 }, (i, o) => {
				let s = e.find((e) => e.pos === o && e.hp > 0), c = t.includes(o), l = s ? Er(a, s).split(" · ")[0] : a("games.toomanybones.boardPosition", {
					x: o % 4 + 1,
					y: Math.floor(o / 4) + 1
				}), u = s ? /* @__PURE__ */ b(Ir, { actor: s }) : n === o ? /* @__PURE__ */ b(d, { size: 17 }) : c ? "+" : "·";
				return c ? /* @__PURE__ */ b("button", {
					type: "button",
					"aria-label": l,
					title: l,
					"aria-pressed": n === o,
					onClick: () => r(o),
					children: u
				}, o) : /* @__PURE__ */ b("span", {
					title: l,
					"aria-hidden": "true",
					children: u
				}, o);
			})
		})]
	}) : null;
}
function Rr({ actors: e, targets: t, value: n, onChange: r }) {
	let i = c(), a = t.filter((e) => e.pos < 0 || !e.hp), o = t.filter((e) => e.pos >= 0 && e.hp > 0);
	return /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b(Lr, {
		actors: e,
		targets: !0,
		legal: o.map((e) => e.pos),
		selected: o.find((e) => e.id === n)?.pos ?? -1,
		onPick: (e) => {
			let t = o.find((t) => t.pos === e);
			t && r(t.id);
		}
	}), /* @__PURE__ */ b(Nr, {
		label: i("games.toomanybones.target"),
		value: n,
		onChange: r,
		options: a.map((e) => ({
			value: e.id,
			label: Er(i, e),
			art: /* @__PURE__ */ b(Ir, { actor: e })
		}))
	})] });
}
//#endregion
//#region src/game/rule-text.tsx
function zr({ text: e }) {
	let t = [], n = [], r = () => {
		n.length && (t.push(/* @__PURE__ */ b("ul", {
			style: {
				listStyle: "disc",
				paddingLeft: 20,
				margin: "8px 0"
			},
			children: n.map((e, t) => /* @__PURE__ */ b("li", { children: e }, t))
		}, t.length)), n = []);
	};
	for (let i of e.split("\n")) i.startsWith("· ") ? n.push(i.slice(2)) : (r(), i.trim() && t.push(/* @__PURE__ */ b("p", { children: i }, t.length)));
	return r(), /* @__PURE__ */ b(y, { children: t });
}
//#endregion
//#region src/game/adventure-inventory.tsx
function Br({ title: e, close: t, closeLabel: n, children: i }) {
	let o = c(), s = a(null);
	return r(() => {
		let e = s.current;
		return e?.showModal(), () => e?.close();
	}, []), /* @__PURE__ */ x("dialog", {
		ref: s,
		className: "tmb-flow-dialog",
		"aria-label": e,
		onCancel: (e) => {
			e.preventDefault(), t();
		},
		children: [/* @__PURE__ */ x("header", { children: [/* @__PURE__ */ b("h2", { children: e }), /* @__PURE__ */ b("button", {
			className: "tmb-dialog-close",
			type: "button",
			"aria-label": n ?? o("games.toomanybones.close"),
			onClick: t,
			children: /* @__PURE__ */ b(f, { size: 20 })
		})] }), /* @__PURE__ */ b("div", {
			className: "tmb-flow-dialog-content",
			children: i
		})]
	});
}
function Vr({ card: e }) {
	let t = se(e), n = "M14 3a5 5 0 0 0-5 7l-6 8a2 2 0 0 0 3 3l8-8a5 5 0 0 0 7-5l-4 3-4-4z", r = {
		7: "M12 8a5 5 0 1 1-10 0 5 5 0 0 1 10 0zm-1 4 10 9m-2-3 2-2m-5 0 2-2",
		9: n,
		11: n,
		10: "M12 22C2 15 1 10 4 7c3-3 6-3 8 0 3-3 6-3 9 0s2 8-9 15z"
	};
	return /* @__PURE__ */ b("svg", {
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.65",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: /* @__PURE__ */ b("path", { d: t.trove ? "M7 11V8a5 5 0 0 1 10 0v3M5 11h14v11H5z M12 15v3" : r[t.slot] ?? "M4 8h16v12H4zM3 8l3-4h12l3 4M9 12h6v4H9z" })
	});
}
function Hr({ item: e, selected: t, showEffect: n, onClick: r }) {
	let i = c(), a = se(e.card);
	return /* @__PURE__ */ x("button", {
		className: "tmb-loot-card",
		type: "button",
		"aria-pressed": t,
		onClick: r,
		children: [
			/* @__PURE__ */ x("span", {
				className: "tmb-loot-engraving",
				children: [/* @__PURE__ */ b(Vr, { card: e.card }), /* @__PURE__ */ b("small", { children: b(t ? d : v, { size: 17 }) })]
			}),
			/* @__PURE__ */ b("strong", { children: mr(i, e.card) }),
			n && (!a.trove || e.locks === 3) && /* @__PURE__ */ b("span", {
				className: "tmb-loot-effect",
				children: hr(i, e.card)
			}),
			/* @__PURE__ */ b("small", { children: a.trove ? i("games.toomanybones.flowLockProgress", {
				n: e.locks,
				total: 3
			}) : i("games.toomanybones.flowLootUses", { n: e.uses }) })
		]
	});
}
function Ur({ items: e, recipient: t, acting: n, send: r }) {
	let i = c(), [a, s] = o(), [l, u] = o(!1), d = e.find((e) => e.uid === a), f = /* @__PURE__ */ b("button", {
		className: "tmb-flow-primary",
		type: "button",
		disabled: !d || !n,
		onClick: () => {
			n && d && (u(!1), r({
				type: "choose",
				option: 0,
				target: d.uid
			}));
		},
		children: d ? i("games.toomanybones.flowKeepName", { name: mr(i, d.card) }) : i("games.toomanybones.keep")
	});
	return /* @__PURE__ */ x("section", {
		className: "tmb-flow-stack tmb-reward-pick",
		children: [
			/* @__PURE__ */ b("h2", { children: i("games.toomanybones.startingLoot") }),
			t && /* @__PURE__ */ b("p", { children: i("games.toomanybones.flowRewardRecipient", { name: t }) }),
			n ? /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("div", {
				className: "tmb-loot-grid",
				children: e.map((e) => /* @__PURE__ */ b(Hr, {
					item: e,
					showEffect: !0,
					selected: a === e.uid,
					onClick: () => {
						s(e.uid), u(!0);
					}
				}, e.uid))
			}), f] }) : /* @__PURE__ */ b("div", {
				className: "tmb-loot-grid",
				"aria-hidden": "true",
				children: e.map((e) => /* @__PURE__ */ b("span", {
					className: "tmb-loot-back",
					children: "◇"
				}, e.uid))
			}),
			n && d && l && /* @__PURE__ */ x(Br, {
				title: mr(i, d.card),
				close: () => u(!1),
				children: [/* @__PURE__ */ x("div", {
					className: "tmb-item-paper tmb-flow-paper",
					children: [/* @__PURE__ */ b(Vr, { card: d.card }), /* @__PURE__ */ b(zr, { text: hr(i, d.card) })]
				}), f]
			})
		]
	});
}
var Wr = {
	L: "games.toomanybones.lever",
	T: "games.toomanybones.trip",
	F: "games.toomanybones.force"
}, Gr = {
	L: "M3 19h18M9 19l3-7 3 7M3 15l18-8M19 7l3-1",
	T: "M3 16V8m18 8V8M3 11l6 4 6-4 6 4",
	F: "M5 21 17 5m-9 1 13 7 2-5L12 3z"
};
function Kr({ lock: e, title: t, canAct: n, open: r, close: i, send: a, supplies: s }) {
	let l = c(), [u, d] = o([]), [f, p] = o("L"), m = (e) => l(Wr[e] ?? "games.toomanybones.die"), h = e.types[e.at], g = e.values[e.at], _ = u.filter((t) => e.available.includes(t) && !!e.rolled[t]), v = _.filter((t) => e.rolled[t][0] === h), S = v.reduce((t, n) => t + Number(e.rolled[n].slice(1)), 0), C = (e) => {
		n && a(e), d([]);
	};
	return r ? /* @__PURE__ */ x(Br, {
		title: t,
		close: i,
		closeLabel: l("games.toomanybones.flowMinimize"),
		children: [
			/* @__PURE__ */ b("ol", {
				className: "tmb-flow-lock-track",
				children: e.values.map((t, n) => /* @__PURE__ */ x("li", {
					"data-current": n === e.at || void 0,
					children: [
						m(e.types[n]),
						" ",
						/* @__PURE__ */ b("strong", { children: n < e.at ? "✓" : t })
					]
				}, n))
			}),
			e.rolled.length > 0 ? /* @__PURE__ */ x(y, { children: [
				/* @__PURE__ */ b("div", {
					className: "tmb-flow-lock-dice",
					children: e.available.map((t) => /* @__PURE__ */ b("button", {
						type: "button",
						disabled: !n || !e.rolled[t],
						"aria-pressed": _.includes(t),
						"aria-label": e.rolled[t] ? `${m(e.rolled[t][0])} ${e.rolled[t].slice(1)}` : void 0,
						onClick: () => d((e) => e.includes(t) ? e.filter((e) => e !== t) : [...e, t]),
						children: e.rolled[t] && /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("svg", {
							viewBox: "0 0 24 24",
							fill: "none",
							stroke: "currentColor",
							strokeWidth: "1.8",
							strokeLinecap: "round",
							"aria-hidden": "true",
							children: /* @__PURE__ */ b("path", { d: Gr[e.rolled[t][0]] })
						}), /* @__PURE__ */ b("strong", { children: e.rolled[t].slice(1) })] })
					}, t))
				}),
				/* @__PURE__ */ b("p", { children: l("games.toomanybones.flowLockTotal", {
					type: m(h),
					n: S,
					total: g
				}) }),
				n && _.length === 1 && !e.usedIntuition && /* @__PURE__ */ x("div", {
					className: "tmb-flow-buttons",
					children: [
						e.intuition === "save" && /* @__PURE__ */ b("button", {
							type: "button",
							onClick: () => C({
								type: "lock",
								mode: "save",
								die: _[0]
							}),
							children: l("games.toomanybones.save")
						}),
						e.intuition === "reroll" && /* @__PURE__ */ b("button", {
							type: "button",
							onClick: () => C({
								type: "lock",
								mode: "reroll",
								dice: _
							}),
							children: l("games.toomanybones.reroll")
						}),
						e.intuition === "convert" && /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("select", {
							"aria-label": l("games.toomanybones.convert"),
							value: f,
							onChange: (e) => p(e.target.value),
							children: Object.entries(Wr).map(([e, t]) => /* @__PURE__ */ b("option", {
								value: e,
								children: l(t)
							}, e))
						}), /* @__PURE__ */ b("button", {
							type: "button",
							onClick: () => C({
								type: "lock",
								mode: "convert",
								die: _[0],
								lockType: f
							}),
							children: l("games.toomanybones.convert")
						})] })
					]
				}),
				/* @__PURE__ */ b("button", {
					className: "tmb-flow-primary",
					type: "button",
					disabled: !n || _.length !== v.length || S < g,
					onClick: () => C({
						type: "lock",
						mode: "solve",
						dice: v
					}),
					children: l("games.toomanybones.solve")
				})
			] }) : /* @__PURE__ */ b("button", {
				className: "tmb-flow-primary",
				type: "button",
				disabled: !n,
				onClick: () => C({
					type: "lock",
					mode: "roll"
				}),
				children: l("games.toomanybones.rollLock")
			}),
			s(_.length === 1 ? _[0] : void 0),
			n && /* @__PURE__ */ b("div", {
				className: "tmb-lock-secondary",
				children: /* @__PURE__ */ b("button", {
					type: "button",
					onClick: () => C({
						type: "lock",
						mode: "stop"
					}),
					children: l(e.at === e.startedAt && !e.retry ? "games.toomanybones.flowRetryLock" : "games.toomanybones.stop")
				})
			})
		]
	}) : null;
}
function qr({ s: e, actor: t, holder: n, item: r, canUse: i, close: a, send: s }) {
	let l = c(), u = se(r.card), [d, f] = o(t?.id ?? ""), [p, m] = o(1), [h, g] = o(), [_, v] = o(!1), [S, C] = o(""), [w, T] = o(!1), ee = e.actors.filter((e) => e.gearloc), E = t?.id === n.id, D = !u.trove || r.locks === 3, O = e.phase === "recovery", te = !!t && O && !t.ready && !t.lockAttempted, k = !u.trove && [
		5,
		28,
		29
	].includes(u.slot), ne = !u.trove && [5, 29].includes(u.slot), re = !u.trove && u.slot === 1, A = u.trove && u.slot === 21, j = u.trove && u.slot === 13, M = !u.trove && u.slot === 17, N = e.phase === "day", ie = e.phase === "encounter", P = e.phase === "training", F = t?.gearloc && re ? Array.from({ length: 16 }, (e, t) => t + 1).filter((e) => Le(t, e)) : [], ae = i && E && D && !e.lock && e.challenge.kind === "none";
	return u.trove ? ae &&= A && t?.counters.scopeDay !== e.day || j && (N || ie) : ae &&= [
		1,
		5,
		8,
		24,
		25,
		28,
		29
	].includes(u.slot) || u.slot === 0 && (N || ie) || u.slot === 3 && P && !!t?.failedTraining.length || u.slot === 13 && P || u.slot === 17 && N || u.slot === 21 && N && e.drawCounts.encounters >= 2 || u.slot === 22 && O, /* @__PURE__ */ x(Br, {
		title: mr(l, r.card),
		close: a,
		closeLabel: l("games.toomanybones.flowBackLoot"),
		children: [
			/* @__PURE__ */ x("div", {
				className: "tmb-flow-paper tmb-item-paper",
				children: [
					/* @__PURE__ */ b(Vr, { card: r.card }),
					/* @__PURE__ */ x("p", { children: [Er(l, n), u.trove && /* @__PURE__ */ x(y, { children: [" · ", l("games.toomanybones.flowLockProgress", {
						n: r.locks,
						total: 3
					})] })] }),
					D && /* @__PURE__ */ b(zr, { text: hr(l, r.card) })
				]
			}),
			u.trove && !D && /* @__PURE__ */ b("button", {
				className: "tmb-flow-primary",
				type: "button",
				disabled: !te || !!e.lock || e.challenge.kind !== "none",
				onClick: () => s({
					type: "lockStart",
					owner: n.id,
					loot: r.uid
				}),
				children: l(t?.lockAttempted ? "games.toomanybones.flowLockUsed" : "games.toomanybones.lockpick")
			}),
			ae && /* @__PURE__ */ x(y, { children: [
				k && /* @__PURE__ */ x("label", { children: [l("games.toomanybones.target"), /* @__PURE__ */ b("select", {
					value: d,
					onChange: (e) => f(e.target.value),
					children: ee.map((e) => /* @__PURE__ */ b("option", {
						value: e.id,
						children: Er(l, e)
					}, e.id))
				})] }),
				ne && /* @__PURE__ */ x("label", { children: [l("games.toomanybones.amount"), /* @__PURE__ */ b("input", {
					type: "number",
					min: 1,
					max: r.uses,
					value: p,
					onChange: (e) => m(Math.max(1, Math.min(r.uses, Number(e.target.value))))
				})] }),
				re && t?.gearloc && /* @__PURE__ */ b(Fr, {
					gearloc: t.gearloc,
					ids: F,
					value: h ?? 0,
					onChange: g
				}),
				j && /* @__PURE__ */ x("label", { children: [l("games.toomanybones.position"), /* @__PURE__ */ b("select", {
					value: p,
					onChange: (e) => m(Number(e.target.value)),
					children: [
						1,
						2,
						3,
						4
					].map((e) => /* @__PURE__ */ b("option", { children: e }, e))
				})] }),
				A && /* @__PURE__ */ x("label", { children: [l("games.toomanybones.scout"), /* @__PURE__ */ b("select", {
					value: p,
					onChange: (e) => m(Number(e.target.value)),
					children: [
						1,
						5,
						20
					].map((e) => /* @__PURE__ */ b("option", {
						value: e,
						children: l("games.toomanybones.point", { n: e })
					}, e))
				})] }),
				M && /* @__PURE__ */ x("label", { children: [l("games.toomanybones.creature"), /* @__PURE__ */ b("select", {
					value: p,
					onChange: (e) => m(Number(e.target.value)),
					children: l("games.toomanybones.creatureNames").split("|").map((e, t) => /* @__PURE__ */ b("option", {
						value: t + 1,
						children: e
					}, e))
				})] }),
				/* @__PURE__ */ b("button", {
					className: "tmb-flow-primary",
					type: "button",
					disabled: re && (h === void 0 || !F.includes(h)),
					onClick: () => s({
						type: "loot",
						loot: r.uid,
						mode: "use",
						target: d,
						amount: p,
						skill: h
					}),
					children: l("games.toomanybones.use")
				})
			] }),
			E && i && !e.lock && e.challenge.kind === "none" && (O || P || N || ie) && /* @__PURE__ */ x("div", {
				className: "tmb-flow-buttons",
				children: [O && ee.length > 1 && /* @__PURE__ */ b("button", {
					type: "button",
					onClick: () => {
						v(!_), T(!1);
					},
					children: l("games.toomanybones.trade")
				}), /* @__PURE__ */ b("button", {
					type: "button",
					onClick: () => {
						T(!w), v(!1);
					},
					children: l("games.toomanybones.discard")
				})]
			}),
			_ && /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ x("label", { children: [l("games.toomanybones.target"), /* @__PURE__ */ x("select", {
				value: S,
				onChange: (e) => C(e.target.value),
				children: [/* @__PURE__ */ b("option", {
					value: "",
					children: "—"
				}), ee.filter((e) => e.id !== n.id).map((e) => /* @__PURE__ */ b("option", {
					value: e.id,
					children: Er(l, e)
				}, e.id))]
			})] }), /* @__PURE__ */ b("button", {
				type: "button",
				disabled: !S,
				onClick: () => s({
					type: "loot",
					mode: "give",
					loot: r.uid,
					target: S
				}),
				children: l("games.toomanybones.confirm")
			})] }),
			w && /* @__PURE__ */ b("button", {
				type: "button",
				onClick: () => s({
					type: "loot",
					mode: "discard",
					loot: r.uid
				}),
				children: l("games.toomanybones.flowConfirmDiscard")
			})
		]
	});
}
//#endregion
//#region src/game/battle-inventory.tsx
function Jr({ s: e, myRid: t, initialTarget: n, initialPos: r, send: i }) {
	let a = c(), s = e.battle, l = e.actors.find((e) => e.gearloc && e.owner === t), [u, d] = o(""), [f, p] = o(n), [m, h] = o(r), [g, _] = o(""), [v, y] = o(1), [S, C] = o(0);
	if (!l?.gearloc) return null;
	let w = l.gearloc, T = l.inventory.find((e) => e.uid === u), ee = s.turn === l.id && ["move", "resolve"].includes(s.stage) && !s.startEffects.length && !s.reactions.length && e.phase === "battle";
	if (!T) return /* @__PURE__ */ x("div", {
		className: "tmb-loot-grid",
		children: [l.inventory.map((e) => /* @__PURE__ */ b(Hr, {
			item: e,
			onClick: () => d(e.uid)
		}, e.uid)), !l.inventory.length && /* @__PURE__ */ b("p", { children: a("games.toomanybones.flowEmptyLoot") })]
	});
	let E = se(T.card), { slot: D, trove: O } = E, te = e.actors.filter((e) => e.hp > 0 && e.pos >= 0), k = O && [9, 12].includes(D), ne = k || O && [15, 22].includes(D) || !O && [
		23,
		26,
		28,
		29
	].includes(D), re = k ? te.filter((e) => e.kind === "baddie" && (D !== 9 || [1, 5].includes(e.point))) : !O && D === 23 ? te : te.filter((e) => e.kind === "gearloc"), A = re.find((e) => e.id === f) ?? re.find((e) => e.id === l.id), j = O && [17, 18].includes(D) || !O && D === 14 && s.stage !== "deployment", M = O && D === 2, N = M && v === 2 || !O && D === 1 || !!A && (O && D === 22 || !O && D === 26), ie = M ? l.skills.filter((t) => Oe(e, l, t)) : !O && D === 1 ? ce[w].map((e) => e.id).filter((e) => Le(l, e)) : A?.exhausted ?? [], P = s.rolled.filter((e) => !e.used && (!O || D !== 17 || e.face.startsWith("attack:"))), F = M && v === 2 && !!ce[w][S - 1]?.grenade, ae = O ? T.locks === 3 && E.backup > 0 && ee && !s.backupUsed && De(l) >= Math.max(0, E.backup - +!!Ee(l, "v3")) : D === 14 && s.stage === "deployment" || D === 16 && s.stage === "endRound" || D === 1 || ee && [
		2,
		4,
		6,
		8,
		10,
		14,
		23,
		26,
		27,
		28,
		29
	].includes(D) && (D !== 4 || !s.rolledOnce);
	return /* @__PURE__ */ x("div", {
		className: "tmb-controls tmb-flow-stack",
		children: [
			/* @__PURE__ */ b("button", {
				type: "button",
				onClick: () => {
					d(""), _(""), y(1), C(0);
				},
				children: a("games.toomanybones.flowBackLoot")
			}),
			/* @__PURE__ */ x("div", {
				className: "tmb-item-paper tmb-flow-paper",
				children: [
					/* @__PURE__ */ b(Vr, { card: T.card }),
					/* @__PURE__ */ b("strong", { children: mr(a, T.card) }),
					/* @__PURE__ */ b(zr, { text: hr(a, T.card) })
				]
			}),
			ae && ne && /* @__PURE__ */ b(Rr, {
				actors: e.actors,
				targets: re,
				value: A?.id ?? "",
				onChange: (e) => {
					p(e), C(0);
				}
			}),
			ae && j && /* @__PURE__ */ b(Nr, {
				label: a("games.toomanybones.chooseDice"),
				value: g,
				onChange: _,
				options: P.map((e) => ({
					value: e.uid,
					label: "",
					art: /* @__PURE__ */ b(Mr, { face: e.face })
				}))
			}),
			ae && M && /* @__PURE__ */ b(Nr, {
				label: a("games.toomanybones.die"),
				value: v,
				onChange: y,
				options: [
					"attack",
					"defense",
					"skill"
				].map((e, t) => ({
					value: t,
					label: a(e === "attack" ? "games.toomanybones.attack" : e === "defense" ? "games.toomanybones.defense" : "games.toomanybones.skill")
				}))
			}),
			ae && N && /* @__PURE__ */ b(Fr, {
				gearloc: M || D === 1 && !O ? w : A?.gearloc ?? w,
				ids: ie,
				value: S,
				onChange: C
			}),
			ae && F && /* @__PURE__ */ b(Lr, {
				actors: e.actors,
				legal: Array.from({ length: 16 }, (e, t) => t),
				selected: m,
				onPick: h
			}),
			ae && !O && D === 29 && /* @__PURE__ */ b(Pr, {
				label: a("games.toomanybones.amount"),
				min: 1,
				max: T.uses,
				value: v,
				onChange: y
			}),
			ae && /* @__PURE__ */ b("button", {
				type: "button",
				className: "tmb-flow-primary",
				disabled: ne && !A || j && !P.some((e) => e.uid === g) || N && !ie.includes(S) || F && !(l.counters.grenades > 0),
				onClick: () => i({
					type: "loot",
					loot: T.uid,
					mode: O ? "backup" : "use",
					target: ne ? A?.id : void 0,
					pos: m,
					amount: v,
					skill: S || void 0,
					ids: g ? [g] : []
				}),
				children: a(O ? "games.toomanybones.backup" : "games.toomanybones.use")
			})
		]
	});
}
//#endregion
//#region src/game/inspect.tsx
function Yr({ gearloc: e, id: t, compact: n = !1 }) {
	let r = c(), i = ce[e][t - 1];
	return i.counter ? /* @__PURE__ */ b("p", {
		className: "tmb-counter-note",
		children: r("games.toomanybones.counterDie")
	}) : /* @__PURE__ */ b("ol", {
		className: `tmb-faces${n ? " tmb-faces-compact" : ""}`,
		"aria-label": r("games.toomanybones.facesLabel"),
		children: i.faces.map((e, t) => /* @__PURE__ */ b("li", { children: /* @__PURE__ */ b(Mr, { face: e }) }, t))
	});
}
function Xr(e, t, n) {
	let r = ce[e][t - 1];
	return n.includes(t) ? "learned" : r.requires.every((e) => n.includes(e)) ? r.consumable ? "consumable" : "open" : "locked";
}
function Zr({ gearloc: e, learned: t, selected: n, onSelect: r, group: i = 0, onGroup: a, pending: o, unlocked: s = [] }) {
	let l = c(), u = nr[e], d = {
		learned: "games.toomanybones.learned",
		open: "games.toomanybones.flowCanLearn",
		locked: "games.toomanybones.flowSkillLocked",
		consumable: "games.toomanybones.consumableTag"
	}, f = (i, a, c) => {
		let f = Math.ceil(i.length / a), p = (e) => [(e % a + .5) * 100 / a, (Math.floor(e / a) + .37) * 100 / f], m = [
			"#97584b",
			"#6d6389",
			"#9a6948",
			"#42658a",
			"#6d5c5e"
		];
		return /* @__PURE__ */ x("div", {
			className: c ? "tmb-dice-grid tmb-dice-grid-phone" : "tmb-dice-grid tmb-dice-grid-desktop",
			style: { gridTemplateColumns: `repeat(${a}, minmax(0, 1fr))` },
			children: [/* @__PURE__ */ b("svg", {
				className: "tmb-dice-routes",
				viewBox: "0 0 100 100",
				preserveAspectRatio: "none",
				"aria-hidden": "true",
				children: i.flatMap((r, o) => ce[e][r - 1].requires.filter((e) => i.includes(e)).map((e) => {
					let [s, c] = p(i.indexOf(e)), [l, d] = p(o), f = m[u.findIndex((e) => e.skills.includes(r))], h = c === d ? `M${s} ${c}H${l}` : `M${s} ${c}H${s + 100 / a * .32}V${d}H${l}`;
					return /* @__PURE__ */ b("path", {
						d: h,
						fill: "none",
						stroke: f,
						strokeWidth: n === r ? 3.5 : 2.5,
						vectorEffect: "non-scaling-stroke",
						strokeDasharray: t.includes(e) ? void 0 : "6 5"
					}, `${e}-${r}`);
				}))
			}), i.map((i) => {
				let a = ce[e][i - 1], c = Xr(e, i, t), f = fr(l, e, i), p = m[u.findIndex((e) => e.skills.includes(i))], h = a.faces.find((e) => !e.includes("Bones") && e !== "bones" && e !== "blank") ?? a.faces[0];
				return /* @__PURE__ */ x("button", {
					type: "button",
					className: "tmb-dice-node",
					"aria-pressed": i === n,
					"aria-label": `${f} · ${l(d[c])}`,
					"data-state": c,
					"data-pending": o === i || void 0,
					"data-unlocked": s.includes(i) || void 0,
					onClick: () => r(i),
					children: [/* @__PURE__ */ x("span", {
						className: "tmb-dice-slot",
						style: { borderBottomColor: p },
						children: [
							/* @__PURE__ */ b("small", { children: i }),
							h && /* @__PURE__ */ b(Mr, { face: h }),
							/* @__PURE__ */ b("i", {
								"aria-hidden": "true",
								children: c === "learned" ? "✓" : c === "locked" ? "⊘" : c === "consumable" ? "◇" : "+"
							})
						]
					}), /* @__PURE__ */ b("strong", { children: f })]
				}, i);
			})]
		});
	};
	return /* @__PURE__ */ x("div", {
		className: "tmb-dice-tree",
		children: [/* @__PURE__ */ b("nav", {
			"aria-label": l("games.toomanybones.skillTree"),
			children: u.map((e, t) => /* @__PURE__ */ b("button", {
				type: "button",
				"aria-pressed": i === t,
				onClick: () => a(t),
				children: l(e.key)
			}, e.key))
		}), /* @__PURE__ */ x("div", {
			className: "tmb-dice-mat",
			children: [f(ce[e].map((e) => e.id), 4, !1), f(u[i].skills, u[i].skills.length > 4 ? 3 : 2, !0)]
		})]
	});
}
function Qr({ gearloc: e, id: t, learned: n, onSelect: r }) {
	let i = c(), a = ce[e][t - 1], o = Xr(e, t, n);
	return /* @__PURE__ */ x("div", {
		className: "tmb-skill-detail",
		children: [
			/* @__PURE__ */ x("h4", { children: [
				t,
				". ",
				fr(i, e, t),
				de[e].includes(t) && /* @__PURE__ */ b("span", {
					className: "tmb-skill-tag",
					children: i("games.toomanybones.startingDie")
				}),
				a.consumable && /* @__PURE__ */ b("span", {
					className: "tmb-skill-tag",
					children: i("games.toomanybones.consumableTag")
				}),
				o === "learned" && /* @__PURE__ */ b("span", {
					className: "tmb-skill-tag",
					children: i("games.toomanybones.learned")
				})
			] }),
			a.requires.length > 0 && /* @__PURE__ */ b("div", {
				className: "tmb-prereq",
				children: r ? a.requires.map((t) => /* @__PURE__ */ b("button", {
					type: "button",
					onClick: () => r(t),
					children: i("games.toomanybones.flowSkillPrerequisite", { name: fr(i, e, t) })
				}, t)) : i("games.toomanybones.prereqList", { skills: a.requires.map((t) => fr(i, e, t)).join(i("games.toomanybones.skillSeparator")) })
			}),
			/* @__PURE__ */ b(zr, { text: ur(i, e, t) }),
			/* @__PURE__ */ b(Yr, {
				gearloc: e,
				id: t
			})
		]
	});
}
function $r({ gearloc: e, showUpgrade: t = !1, compact: n = !1 }) {
	let r = c(), i = ir[e], a = /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ x("b", { children: [
		r("games.toomanybones.innate"),
		" · ",
		r(i.key)
	] }), r(i.briefKey)] });
	return n ? /* @__PURE__ */ b("p", {
		className: "tmb-recruit-innate",
		children: a
	}) : /* @__PURE__ */ x("div", {
		className: "tmb-innate",
		children: [
			/* @__PURE__ */ x("h4", { children: [
				r("games.toomanybones.innate"),
				" · ",
				r(i.key)
			] }),
			/* @__PURE__ */ b("p", { children: r(i.briefKey) }),
			t && /* @__PURE__ */ x("p", {
				className: "tmb-innate-upgrade",
				children: [/* @__PURE__ */ x("b", { children: [
					r("games.toomanybones.innateUpgrade"),
					" · ",
					r(i.upgradeKey)
				] }), r(i.upgradeBriefKey)]
			})
		]
	});
}
function ei({ gearloc: e, upgraded: t = !1 }) {
	let n = c();
	return /* @__PURE__ */ x("section", {
		className: "tmb-backup",
		children: [
			/* @__PURE__ */ b("h4", { children: n("games.toomanybones.backup") }),
			/* @__PURE__ */ b("p", {
				className: "tmb-backup-note",
				children: n("games.toomanybones.backupNote")
			}),
			/* @__PURE__ */ b("ul", { children: yr(n, e).map(({ cost: e, text: r }) => /* @__PURE__ */ x("li", {
				className: e === 6 && t ? "tmb-backup-spent" : "",
				children: [/* @__PURE__ */ x("b", { children: [
					e,
					" ",
					n("games.toomanybones.bones")
				] }), /* @__PURE__ */ b("span", { children: r })]
			}, e)) })
		]
	});
}
function ti({ gearloc: e }) {
	let t = c(), n = de[e], [r, i] = o(), [a, s] = o(0), l = (t) => {
		i(t), s(nr[e].findIndex((e) => e.skills.includes(t)));
	};
	return /* @__PURE__ */ x("div", {
		className: "tmb-tree-view",
		children: [
			/* @__PURE__ */ b($r, {
				gearloc: e,
				showUpgrade: !0
			}),
			/* @__PURE__ */ b(Zr, {
				gearloc: e,
				learned: n,
				selected: r,
				onSelect: l,
				group: a,
				onGroup: s
			}),
			r !== void 0 && /* @__PURE__ */ b(Qr, {
				gearloc: e,
				id: r,
				learned: n,
				onSelect: l
			}),
			/* @__PURE__ */ b(ei, { gearloc: e }),
			nr[e].map((e) => /* @__PURE__ */ x("section", {
				className: "tmb-tree-reference",
				children: [/* @__PURE__ */ b("h4", { children: t(e.key) }), /* @__PURE__ */ b("p", { children: t(e.briefKey) })]
			}, e.key))
		]
	});
}
function ni({ gearloc: e, ids: t }) {
	let n = c();
	return /* @__PURE__ */ b(y, { children: t.map((t) => {
		let r = ce[e][t - 1];
		return /* @__PURE__ */ x("details", {
			className: "tmb-reference",
			children: [
				/* @__PURE__ */ x("summary", { children: [
					t,
					". ",
					fr(n, e, t)
				] }),
				/* @__PURE__ */ b(zr, { text: ur(n, e, t) }),
				!r.counter && /* @__PURE__ */ b(Yr, {
					gearloc: e,
					id: t
				})
			]
		}, t);
	}) });
}
function ri({ t: e, id: t, n, label: r }) {
	let [i, a] = vr(_r(e, t));
	return /* @__PURE__ */ x("p", {
		className: "tmb-reference-skill",
		children: [
			r && /* @__PURE__ */ x("span", {
				className: "tmb-reference-label",
				children: [r, " · "]
			}),
			/* @__PURE__ */ b("b", { children: i || pr(e, t) }),
			n > 1 && /* @__PURE__ */ x("span", {
				className: "tmb-reference-count",
				children: [" × ", n]
			}),
			a && /* @__PURE__ */ x("span", { children: [" ", a] })
		]
	});
}
function ii({ actor: e }) {
	let t = c(), n = e.gearloc ? void 0 : A(e.definition), r = e.enemyDefense.reduce((e, t) => e + t, 0);
	return /* @__PURE__ */ x("details", {
		className: "tmb-reference",
		children: [
			/* @__PURE__ */ x("summary", { children: [
				Er(t, e),
				" · ",
				e.hp,
				"/",
				e.maxHp,
				" ♥"
			] }),
			/* @__PURE__ */ x("p", { children: [
				t("games.toomanybones.attack"),
				" ",
				e.attack,
				" · ",
				t("games.toomanybones.defense"),
				" ",
				e.defense,
				" · ",
				t("games.toomanybones.initiative"),
				" ",
				e.initiative,
				r > 0 && /* @__PURE__ */ x(y, { children: [" · ", t("games.toomanybones.defenseDiceLine", { n: r })] })
			] }),
			n && /* @__PURE__ */ x(y, { children: [
				/* @__PURE__ */ x("p", { children: [
					t(n.target === "strongest" ? "games.toomanybones.strongest" : "games.toomanybones.weakest"),
					" · ",
					t("games.toomanybones.targets", { n: n.targets }),
					" · ",
					t(n.ranged ? "games.toomanybones.ranged" : "games.toomanybones.melee")
				] }),
				Object.entries(n.skills).map(([e, n]) => /* @__PURE__ */ b(ri, {
					t,
					id: e,
					n
				}, e)),
				Object.entries(n.backup).map(([e, r]) => /* @__PURE__ */ b(ri, {
					t,
					id: e,
					n: r,
					label: t("games.toomanybones.backup") + " " + n.backupCost
				}, "backup:" + e))
			] }),
			e.gearloc && /* @__PURE__ */ b(ni, {
				gearloc: e.gearloc,
				ids: e.skills
			}),
			e.gearloc && /* @__PURE__ */ b(ei, {
				gearloc: e.gearloc,
				upgraded: e.upgraded
			}),
			e.inventory.map((e) => /* @__PURE__ */ x("details", { children: [/* @__PURE__ */ b("summary", { children: mr(t, e.card) }), /* @__PURE__ */ b("p", { children: hr(t, e.card) })] }, e.uid)),
			Object.entries(e.effects).filter(([, e]) => e > 0).map(([e, n]) => /* @__PURE__ */ x("p", { children: [
				pr(t, e),
				" ",
				n
			] }, e))
		]
	});
}
function ai() {
	let e = c();
	return /* @__PURE__ */ b("section", {
		className: "flex flex-col gap-3",
		children: le.map((t) => /* @__PURE__ */ x("details", { children: [/* @__PURE__ */ b("summary", { children: e(ar[t]) }), /* @__PURE__ */ b(ni, {
			gearloc: t,
			ids: ce[t].map((e) => e.id)
		})] }, t))
	});
}
//#endregion
//#region src/game/battle-view.tsx
var oi = (e) => e === "attack" || e === "defense" ? /* @__PURE__ */ b(Qn, { kind: e }) : [
	"bones",
	"forcedBones",
	"reusableBones"
].includes(e) ? "⚅" : "◆";
function si({ pos: e, children: t }) {
	let { ref: n } = w(`tmb:cell:${e}`);
	return /* @__PURE__ */ b("div", {
		ref: n,
		className: "tmb-battle-socket",
		"data-lane": e < 8 ? e % 4 : void 0,
		children: t
	});
}
function ci({ id: e, children: t }) {
	let { ref: n, hidden: r } = w(e ? `tmb:chip:${e}` : null);
	return /* @__PURE__ */ b("span", {
		ref: n,
		className: "tmb-chip-anchor",
		style: { visibility: r ? "hidden" : void 0 },
		children: t
	});
}
function li(e, t, n, r) {
	let i = (e) => Er(r, e).split(" · ")[0], a = e.actors.find((e) => e.owner === n && e.kind === "gearloc"), o = t?.actors.find((e) => e.id === a?.id);
	if (a && o) {
		let e = a.bones.reduce((e, t) => e + t.n, 0) - o.bones.reduce((e, t) => e + t.n, 0);
		if (e) return r("games.toomanybones.bones") + " " + (e > 0 ? "+" : "−") + Math.abs(e);
		let t = [...a.active, ...a.locked].filter((e) => ![...o.active, ...o.locked].some((t) => t.uid === e.uid));
		if (t.length) return t.map((e) => pr(r, e.kind) + (e.n ? " +" + e.n : "")).join(" · ");
		let n = H(a, "defense") + H(a, "advancedDefense") - H(o, "defense") - H(o, "advancedDefense");
		if (n) return r("games.toomanybones.defense") + " " + (n > 0 ? "+" : "−") + Math.abs(n);
		if (a.pos >= 0 && o.pos >= 0 && a.pos !== o.pos) return r("games.toomanybones.moveTo", {
			x: a.pos % 4 + 1,
			y: Math.floor(a.pos / 4) + 1
		});
	}
	let s = e.log.at(-1), c = t?.log.at(-1);
	if (!s || t && JSON.stringify(s) === JSON.stringify(c)) return "";
	let l = e.actors.find((e) => e.id === s.who), u = e.actors.find((e) => e.id === s.target);
	if (s.key === "enemyRoll") {
		let t = s.values.map((e) => e ? String(e) : "⚅").join(" · "), n = e.battle?.enemyBones ? " · " + r("games.toomanybones.enemyRolledBones", { n: e.battle.enemyBones }) : "";
		return (l ? i(l) + " · " : "") + r("games.toomanybones.enemyRolled", {
			n: s.values.length,
			values: t
		}) + n;
	}
	return s.key === "tyrantDie" ? r("games.toomanybones.tyrantRolled", { face: Sr(r, s.target) }) : u && ["damage", "heal"].includes(s.key) ? i(u) + " · " + r("games.toomanybones.hp") + (s.key === "damage" ? " −" : " +") + s.n : r("games.toomanybones.logLine", {
		who: l ? i(l) : "",
		event: Tr(r, s.key),
		target: u ? i(u) : "",
		n: s.n || ""
	});
}
function ui({ Screen: e, s: t, myRid: n, names: r, canAct: i, send: a, tools: o, settling: s }) {
	let c = t.battle;
	return /* @__PURE__ */ b(di, {
		Screen: e,
		s: t,
		b: c,
		myRid: n,
		names: r,
		canAct: i,
		send: a,
		tools: o,
		settling: s
	});
}
function di({ Screen: e, s: t, b: n, myRid: i, names: s, canAct: l, send: u, tools: m, settling: h }) {
	let g = c(), _ = t.actors.find((e) => e.kind === "gearloc" && e.owner === i), v = t.actors.find((e) => e.id === n.turn), S = v?.id === _?.id && !!_, C = (e) => Er(g, e).split(" · ")[0], [T, ee] = o(""), [E, D] = o(-1), [O, te] = o([]), [k, ne] = o(""), [A, j] = o(0), [M, N] = o(null), [ie, P] = o(!1), F = a(null), { ref: ae } = w("tmb:tray"), { ref: oe } = w("tmb:slot:active"), { ref: se } = w("tmb:slot:locked"), { ref: I } = w("tmb:slot:bones");
	r(() => {
		if (!M) return;
		let e = document.activeElement;
		return F.current?.querySelector("button")?.focus(), () => {
			e instanceof HTMLElement && e.isConnected && e.focus();
		};
	}, [M]);
	let [le, ue] = o({}), [de, me] = o(null), he = i + ":" + n.round + ":" + n.at + ":" + n.turn, [ge, ve] = o({
		key: he,
		seat: i
	}), [ye, be] = o({
		view: t,
		feedbackView: t
	});
	ge.key !== he && (ve({
		key: he,
		seat: i
	}), ee(""), D(-1), te([]), ne(""), j(0), (ge.seat !== i || M !== "enemies" && M !== "inspect") && N(null), P(!1), ue({}), me(null)), ye.view !== t && be(li(t, ye.view, i, g) ? {
		view: t,
		feedbackView: t,
		previous: ye.view
	} : {
		...ye,
		view: t
	});
	let L = n.flags.includes("orderPending"), xe = !!n.reactions.length || !!n.startEffects.length || L, Se = n.reactions[0]?.split(":")[1]?.split("|")[0], R = Se && t.actors.find((e) => e.id === Se && e.kind === "gearloc"), Ce = n.stage === "deployment" && !n.reactions.length ? t.actors.filter((e) => e.gearloc && e.hp > 0 && e.pos < 0 && !(e.counters.reserve > 0)).map((e) => s[e.owner] ?? C(e)) : [s[n.reactions.length ? R ? R.owner : t.leader : L || v?.kind !== "gearloc" ? t.leader : v.owner]].filter(Boolean), z = S ? g("games.toomanybones.yourTurn") : !l && t.phase === "battle" && Ce.length ? g("games.toomanybones.flowWaiting", { name: Ce.join(" · ") }) : g("games.toomanybones.battle"), B = t.actors.filter((e) => e.kind === "baddie" && e.pos >= 0 && e.hp > 0), V = l && S && n.stage === "move" && !n.rolledOnce && !xe, we = l && S && n.stage === "resolve" && !xe, De = _ ? t.actors.filter((e) => Dt(t, _, e)) : [], U = t.actors.find((e) => e.id === n.target), ke = n.rolledOnce ? U : De.find((e) => e.id === T) ?? De[0], Ae = [
		"troll",
		"orc",
		"scales",
		"goblin",
		"bog",
		"beast"
	].indexOf(ke ? Te(ke)?.creature ?? "" : "") + 1, je = _ && Ee(_, "v7") && Ae === _.counters.necklaceType ? _.counters.necklace ?? 0 : 0, Me = (_?.effects.extraAttack ?? 0) + je, Ne = _ && Ee(_, "l15") ? 1 : 0, Pe = n.modifiers.defenseOnly >= n.round || n.modifiers.meleeDefenseOnly >= n.round && !_?.ranged, W = n.modifiers.skillOnly >= n.round, Fe = _ ? [
		...Array.from({ length: !Pe && !W ? Math.min(30, tt(_, "attack") + je) : 0 }, (e, t) => ({
			id: "attack:" + t,
			kind: "attack",
			skill: 0
		})),
		...Array.from({ length: !n.modifiers.noDefense && !W ? Math.min(30, tt(_, "defense") + Ne) : 0 }, (e, t) => ({
			id: "defense:" + t,
			kind: "defense",
			skill: 0
		})),
		...Pe ? [] : _.skills.filter((e) => Oe(t, _, e, !0)).map((e) => ({
			id: "skill:" + e,
			kind: "skill",
			skill: e
		}))
	] : [], Ie = Fe.filter((e) => O.includes(e.id)), Le = Ie.filter((e) => e.kind === "attack").length, Re = Ie.filter((e) => e.kind === "defense").length, ze = Ie.filter((e) => e.kind === "skill").map((e) => e.skill), Be = (e) => Math.max(0, e.filter((e) => e.kind === "attack").length - Me) + Math.max(0, e.filter((e) => e.kind === "defense").length - Ne) + e.filter((e) => e.kind === "skill").length, Ve = _ ? Math.max(0, nt(_) - n.spent) : 0, He = ze.filter((e) => _?.gearloc && ce[_.gearloc][e - 1].grenade), Ue = n.rolled.filter((e) => !e.used), G = Ue.find((e) => e.uid === k) ?? Ue[0], K = G && _e(G.face)[0], q = v && v.kind === "baddie" ? Te(v) : void 0, We = !!K && [
		"heal",
		"buffHp",
		"buffAttack",
		"recover",
		"booster",
		"permanentHp",
		"advancedDefense",
		"intercept"
	].includes(K.kind), Ge = !!K && ([
		"trueDamage",
		"poisonAny",
		"attackMinus"
	].includes(K.kind) || ["stun", "disable"].includes(K.kind) && _?.gearloc !== "boomer"), Ke = we && (We || Ge), qe = !Ke || !_ || !K ? [] : t.actors.filter((e) => e.hp <= 0 || e.pos < 0 ? !1 : We ? e.kind === "gearloc" && (K.kind !== "intercept" || e.id !== _.id) : e.kind === "baddie" ? ["stun", "disable"].includes(K.kind) ? e.point > 0 && e.point <= K.n && (_.gearloc !== "tantrum" || Y(e.pos, _.pos)) : K.kind !== "attackMinus" || Y(e.pos, _.pos) : !1), J = qe.find((e) => e.id === T) ?? qe.find((e) => e.id === _?.id) ?? qe[0], Je = Ke ? J : ke, Ye = l && !xe && n.stage === "deployment" && _ && _.pos < 0 && _.hp > 0 && !_.counters.reserve, Xe = l && !xe && n.stage === "move" && v?.kind === "ally", Ze = we && n.lastAttack.length > 0 && n.modifiers.freeAfterAttack > (_?.counters.afterAttackMove ?? 0), Qe = l && !xe && n.stage === "enemyMove" && v, $e = l && !xe && n.stage === "enemyTarget" && v, et = de === null ? Ye ? Nt(t, _) : (V && Ve >= Tt(t) || Ze) && _ ? Lt(t, _) : Xe && n.spent < 2 ? Lt(t, v) : Qe && U ? Bt(t, v, U) : [] : Array.from({ length: 16 }, (e, t) => t), rt = $e ? zt(t, v) : Ke ? qe : V || Xe ? t.actors.filter((e) => v && Dt(t, v, e)) : [], it = E >= 0 && et.includes(E) && de === null, at = (e) => {
		P(!1), de === null ? D(e === E ? -1 : e) : (ue((t) => ({
			...t,
			[de]: e
		})), me(null), D(-1));
	}, ot = (e) => {
		D(-1), P(!1), e.skill && j(e.skill), te((t) => t.includes(e.id) ? t.filter((t) => t !== e.id) : [...t, e.id]), e.skill && _?.gearloc && ce[_.gearloc][e.skill - 1].grenade && !O.includes(e.id) ? me(e.skill) : de === e.skill && me(null);
	}, st = (e) => {
		u(e), D(-1), P(!1);
	}, ct = Ue.some((e) => e.face.includes("forcedBones") || e.face.includes("tainted") || _?.gearloc === "boomer" && (e.skill === 16 || e.skill >= 5 && e.skill <= 11)), lt = g("games.toomanybones.wait"), ut = "", dt, ft = !l, pt;
	if (l && xe) {
		lt = g(n.reactions.length ? "games.toomanybones.reaction" : L ? "games.toomanybones.orderReady" : "games.toomanybones.startEffect");
		let e = n.startEffects[0];
		L && !n.reactions.length ? dt = { type: "ready" } : !n.reactions.length && n.startEffects.length === 1 && v && e !== "dive" && !(e === "innateHeal" && v.upgraded) ? (ut = pr(g, v.active.find((t) => t.uid === e)?.kind ?? (e === "innateHeal" ? "heal" : e)), dt = {
			type: "ability",
			ability: "startEffect",
			mode: e,
			target: v.id
		}) : pt = "special";
	} else if (Ye) lt = g("games.toomanybones.deploy"), ut = g("games.toomanybones.chooseDeployment"), ft = !it, dt = it ? {
		type: "deploy",
		pos: E
	} : void 0;
	else if ($e) lt = g("games.toomanybones.enemyTarget"), ut = g("games.toomanybones.chooseBoardTarget"), ft = !rt.some((e) => e.id === T), dt = {
		type: "ability",
		ability: "target",
		target: T
	};
	else if (it) lt = g("games.toomanybones.moveTo", {
		x: E % 4 + 1,
		y: Math.floor(E / 4) + 1
	}), ut = Xe || Qe ? "" : Ze ? g("games.toomanybones.free") : g("games.toomanybones.moveCost", { n: Tt(t) }), dt = Xe ? {
		type: "ability",
		ability: "allyMove",
		pos: E
	} : {
		type: "move",
		pos: E
	};
	else if (Qe) lt = g("games.toomanybones.enemyMove"), ut = g("games.toomanybones.chooseMove"), ft = !0;
	else if (Xe) {
		let e = rt.find((e) => e.id === T);
		lt = e ? g("games.toomanybones.attackTarget", { name: C(e) }) : g("games.toomanybones.endTurn"), dt = e ? {
			type: "ability",
			ability: "allyAttack",
			target: e.id
		} : {
			type: "ability",
			ability: "allyEnd"
		};
	} else if (V) lt = g("games.toomanybones.rollCount", { n: Ie.length }), ut = Le ? ke ? g("games.toomanybones.attackTarget", { name: C(ke) }) : g("games.toomanybones.noAttackTarget") : "", de !== null && _?.gearloc ? ut = g("games.toomanybones.aim", { skill: fr(g, _.gearloc, de) }) : Be(Ie) > Ve && (ut = g("games.toomanybones.notEnoughDex")), ft = !Ie.length || Be(Ie) > Ve || He.length > (_?.counters.grenades ?? 0) || He.some((e) => le[e] === void 0) || de !== null, Le && !ke && _ && !Ee(_, "v14") && (ft = !0), dt = {
		type: "roll",
		attack: Le,
		defense: Re,
		skills: ze,
		target: ke?.id ?? null,
		aims: Object.fromEntries(He.map((e) => [e, le[e]]))
	};
	else if (we && G && K) {
		if (K.kind === "attack") {
			let e = U && _ && Dt(t, _, U);
			lt = e ? g("games.toomanybones.attackFor", {
				name: C(U),
				n: K.n + (n.lastAttack.includes(_.id) ? 0 : H(_, "constantDamage"))
			}) : g("games.toomanybones.discard"), dt = {
				type: "resolve",
				dice: [G.uid],
				mode: e ? "use" : "discard"
			};
		} else if (K.kind === "defense") lt = g("games.toomanybones.storeDefense", { n: K.n }), dt = {
			type: "resolve",
			dice: [G.uid],
			mode: "active"
		}, _ && _.active.length >= 3 && (lt = g("games.toomanybones.chooseResolution"), ut = g("games.toomanybones.activeFull"), pt = "dice", dt = void 0);
		else if ([
			"bones",
			"forcedBones",
			"reusableBones"
		].includes(K.kind)) lt = g("games.toomanybones.collectBones", { n: K.n * (n.modifiers.doubleBones ? 2 : 1) }), dt = {
			type: "resolve",
			dice: [G.uid],
			mode: "bones"
		};
		else if (K.kind === "blank") lt = g("games.toomanybones.discard"), dt = {
			type: "resolve",
			dice: [G.uid],
			mode: "discard"
		};
		else if (lt = g("games.toomanybones.useSkill", { name: _?.gearloc ? fr(g, _.gearloc, G.skill) : pr(g, K.kind) }), [
			"parts",
			"jump",
			"revive",
			"reviveKo"
		].includes(K.kind)) pt = "dice";
		else {
			let e = [
				"healMultiply",
				"healReroll",
				"buffReroll"
			].includes(K.kind) ? "locked" : ["switch", "rush"].includes(K.kind) ? "active" : "use";
			dt = {
				type: "resolve",
				dice: [G.uid],
				mode: e,
				target: J?.id
			}, [
				"meleeDamage",
				"poisonTarget",
				"dropInitiative"
			].includes(K.kind) && (!U || !_ || !Dt(t, _, U, K.kind === "dropInitiative" && _.ranged)) && (ft = !0, ut = g("games.toomanybones.noAttackTarget")), Ke && (ft = !J, J && (ut = g("games.toomanybones.skillTarget", { name: C(J) })));
			let n = We ? J : _, r = [
				"buffHp",
				"buffAttack",
				"recover",
				"booster",
				"advancedDefense",
				"intercept",
				"switch",
				"rush",
				"ale",
				"poisonArmor",
				"lashback",
				"hardy",
				"taunt",
				"riposte"
			].includes(K.kind), i = [
				"element",
				"casing",
				"fuse",
				"element325",
				"healMultiply",
				"healReroll",
				"buffReroll",
				"constantRegen",
				"constantMove",
				"constantDefense",
				"constantDamage",
				"constantTaunt",
				"improvedDefense"
			].includes(K.kind);
			n && (r && n.active.length >= 3 || i && n.locked.length >= 3) && (pt = "dice", dt = void 0, ut = g("games.toomanybones.slotsFull"));
		}
		ut ||= _e(G.face).map((e) => pr(g, e.kind) + (e.n ? " " + e.n : "")).join(" · ");
	} else we ? (lt = g("games.toomanybones.endTurn"), dt = { type: "endTurn" }) : v && (lt = g("games.toomanybones.unitTurn", { name: C(v) }), q && (ut = g("games.toomanybones.intentLine", {
		attack: v.attack,
		defense: v.defense + v.enemyDefense.reduce((e, t) => e + t, 0),
		hp: v.hp,
		max: v.maxHp
	})), ft = !0);
	let mt = li(ye.feedbackView, ye.previous, i, g), ht = V && A > 0 && O.includes("skill:" + A) && _?.gearloc ? A : 0, gt = V && O.some((e) => e.startsWith("attack:")) ? fe : V && O.some((e) => e.startsWith("defense:")) ? pe : we && G && !G.skill && G.kind === "attack" ? fe : we && G && !G.skill && G.kind === "defense" ? pe : void 0, _t = ht && _?.gearloc ? /* @__PURE__ */ x("div", {
		className: "tmb-die-peek",
		role: "group",
		"aria-label": fr(g, _.gearloc, ht) + " · " + g("games.toomanybones.facesLabel"),
		children: [/* @__PURE__ */ x("b", { children: [
			ht,
			". ",
			fr(g, _.gearloc, ht)
		] }), /* @__PURE__ */ b(Yr, {
			gearloc: _.gearloc,
			id: ht,
			compact: !0
		})]
	}) : gt ? /* @__PURE__ */ b("div", {
		className: "tmb-die-peek tmb-die-peek-white",
		role: "group",
		"aria-label": g(gt === fe ? "games.toomanybones.whiteAttackDie" : "games.toomanybones.whiteDefenseDie"),
		children: /* @__PURE__ */ b("ol", {
			className: "tmb-faces tmb-faces-compact",
			children: gt.map((e, t) => /* @__PURE__ */ b("li", { children: /* @__PURE__ */ b(Mr, { face: e ? `${gt === fe ? "attack" : "defense"}:${e}` : "bones" }) }, t))
		})
	}) : void 0;
	return /* @__PURE__ */ x("div", {
		className: "tmb-root tmb-focused h-full",
		inert: h || void 0,
		children: [/* @__PURE__ */ b(e, {
			adaptive: !0,
			scroll: !1,
			actionsHeight: "tmb-battle-actions",
			banner: /* @__PURE__ */ b("header", {
				className: "tmb-battle-header",
				children: /* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("strong", { children: g("games.toomanybones.name") }), /* @__PURE__ */ b("span", { children: g("games.toomanybones.battleProgress", {
					day: t.day,
					days: re[t.config.tyrant].days,
					p: t.progress,
					total: re[t.config.tyrant].progress
				}) })] })
			}),
			actions: /* @__PURE__ */ x("div", {
				className: "tmb-battle-footer",
				children: [/* @__PURE__ */ x("button", {
					type: "button",
					className: "tmb-current-player",
					"aria-label": g("games.toomanybones.moreOptions"),
					onClick: () => N("menu"),
					children: [/* @__PURE__ */ x("div", { children: [/* @__PURE__ */ x("strong", { children: [
						_ ? C(_) : g("games.toomanybones.wait"),
						" ",
						/* @__PURE__ */ b(p, { size: 16 })
					] }), /* @__PURE__ */ b("span", { children: z })] }), _ && /* @__PURE__ */ x("div", {
						className: "tmb-player-totals",
						children: [/* @__PURE__ */ x("b", { children: [
							"♥ ",
							_.hp,
							/* @__PURE__ */ x("small", { children: ["/", _.maxHp] })
						] }), /* @__PURE__ */ x("span", {
							className: "tmb-player-slots",
							children: [
								/* @__PURE__ */ x("span", {
									ref: oe,
									title: g("games.toomanybones.defense"),
									children: ["⛨ ", H(_, "defense") + H(_, "advancedDefense") + H(_, "constantDefense")]
								}),
								/* @__PURE__ */ x("span", {
									ref: se,
									title: g("games.toomanybones.locked"),
									children: ["▣ ", _.locked.length]
								}),
								/* @__PURE__ */ x("span", {
									ref: I,
									title: g("games.toomanybones.bones"),
									children: ["⚅ ", _.bones.reduce((e, t) => e + t.n, 0)]
								})
							]
						})]
					})]
				}), /* @__PURE__ */ x("div", {
					className: "tmb-battle-tray",
					children: [
						/* @__PURE__ */ x("div", {
							className: "tmb-tray-heading",
							children: [/* @__PURE__ */ b("h2", { children: g(it ? "games.toomanybones.move" : V ? "games.toomanybones.chooseDice" : we ? "games.toomanybones.resolveDice" : "games.toomanybones.battle") }), _ && /* @__PURE__ */ x("span", { children: [
								g("games.toomanybones.dex"),
								" ",
								/* @__PURE__ */ b("b", { children: Ve }),
								V && /* @__PURE__ */ x(y, { children: [" → ", /* @__PURE__ */ b("b", { children: Ve - (it ? Tt(t) : Be(Ie)) })] })
							] })]
						}),
						/* @__PURE__ */ b("div", {
							ref: ae,
							className: "tmb-dice-tray",
							"aria-label": g("games.toomanybones.chooseDice"),
							children: V ? Fe.map((e) => /* @__PURE__ */ x("button", {
								type: "button",
								className: "tmb-die-item",
								"aria-pressed": O.includes(e.id),
								onClick: () => ot(e),
								children: [/* @__PURE__ */ x("span", {
									className: `tmb-physical-die tmb-physical-${e.kind}`,
									children: [
										/* @__PURE__ */ b("span", {
											className: "tmb-die-check",
											children: /* @__PURE__ */ b(d, { size: 14 })
										}),
										/* @__PURE__ */ b("span", {
											className: "tmb-die-mark",
											children: oi(e.kind)
										}),
										e.skill > 0 && /* @__PURE__ */ b("small", { children: e.skill })
									]
								}), /* @__PURE__ */ b("span", { children: e.skill && _?.gearloc ? fr(g, _.gearloc, e.skill) : pr(g, e.kind) })]
							}, e.id)) : S && n.rolledOnce ? n.rolled.map((e) => /* @__PURE__ */ x("button", {
								type: "button",
								disabled: e.used || !we,
								className: `tmb-die-item tmb-die-revealed ${e.used ? "tmb-die-spent" : ""}`,
								"aria-pressed": G?.uid === e.uid,
								onClick: () => {
									ne(e.uid), D(-1), P(!1);
								},
								children: [/* @__PURE__ */ x("span", {
									className: `tmb-physical-die tmb-physical-${e.kind}`,
									children: [/* @__PURE__ */ b("span", {
										className: "tmb-die-check",
										children: /* @__PURE__ */ b(d, { size: 14 })
									}), /* @__PURE__ */ b(Mr, { face: e.face })]
								}), /* @__PURE__ */ b("span", { children: e.skill && _?.gearloc ? fr(g, _.gearloc, e.skill) : pr(g, e.kind) })]
							}, e.uid)) : q && v ? /* @__PURE__ */ x("div", {
								className: "tmb-enemy-intent",
								children: [
									/* @__PURE__ */ b("p", { children: g("games.toomanybones.intentLine", {
										attack: v.attack,
										defense: v.defense + v.enemyDefense.reduce((e, t) => e + t, 0),
										hp: v.hp,
										max: v.maxHp
									}) }),
									n.enemyTargets.length > 0 && /* @__PURE__ */ b("p", { children: g("games.toomanybones.intentTargets", { names: n.enemyTargets.map((e) => t.actors.find((t) => t.id === e)).filter((e) => !!e).map(C).join(", ") }) }),
									n.tyrantFace >= 0 && /* @__PURE__ */ b("p", { children: g("games.toomanybones.tyrantRolled", { face: Sr(g, re[t.config.tyrant].faces[n.tyrantFace] ?? "") }) }),
									n.enemyRolls.length > 0 && /* @__PURE__ */ b("p", { children: g("games.toomanybones.enemyRolled", {
										n: n.enemyRolls.reduce((e, t) => e + t.dice.length, 0),
										values: n.enemyRolls.flatMap((e) => e.dice).map((e) => e ? String(e) : "⚅").join(" · ")
									}) }),
									n.enemyBones > 0 && /* @__PURE__ */ b("p", { children: g("games.toomanybones.enemyRolledBones", { n: n.enemyBones }) }),
									Object.keys(q.skills).length > 0 && /* @__PURE__ */ x("p", {
										className: "tmb-enemy-skills",
										children: [
											g("games.toomanybones.skillsLabel"),
											" · ",
											Object.entries(q.skills).map(([e, t]) => (vr(_r(g, e))[0] || pr(g, e)) + (t > 1 ? " × " + t : "")).join(" · ")
										]
									})
								]
							}) : /* @__PURE__ */ b("span", {
								className: "tmb-tray-placeholder",
								children: Ye ? g(_?.ranged ? "games.toomanybones.ranged" : "games.toomanybones.melee") : L ? g("games.toomanybones.orderReady") : ""
							})
						}),
						/* @__PURE__ */ b("div", {
							className: "tmb-tray-preview",
							children: _t
						}),
						/* @__PURE__ */ b("div", {
							className: "tmb-action-context",
							"aria-live": "polite",
							children: ut
						}),
						/* @__PURE__ */ b("button", {
							type: "button",
							className: "tmb-main-action",
							disabled: ft || !dt && !pt,
							onClick: () => {
								pt ? N(pt) : dt && st(dt);
							},
							children: lt
						})
					]
				})]
			}),
			children: /* @__PURE__ */ x("div", {
				className: "tmb-battle-scene",
				children: [
					/* @__PURE__ */ x("div", {
						className: "tmb-battle-goal",
						children: [
							/* @__PURE__ */ b("span", { children: g(n.flags.includes("tyrant") ? "games.toomanybones.defeatTyrant" : "games.toomanybones.defeatEnemies") }),
							/* @__PURE__ */ b("span", { children: g("games.toomanybones.round", { n: n.round }) }),
							B.length > 0 && /* @__PURE__ */ b("button", {
								type: "button",
								onClick: () => N("enemies"),
								children: g("games.toomanybones.enemyRoster")
							})
						]
					}),
					/* @__PURE__ */ b("div", {
						className: "tmb-battle-board-wrap",
						children: /* @__PURE__ */ b("div", {
							className: "tmb-battle-board",
							"aria-label": g("games.toomanybones.battlefield"),
							children: Array.from({ length: 16 }, (e, r) => {
								let i = t.actors.find((e) => e.pos === r && e.hp > 0), a = i ? rt.some((e) => e.id === i.id) && de === null : et.includes(r), o = i ? $e || Xe ? T === i.id : (V || we) && Je?.id === i.id : it && E === r, s = !!i && i.id === n.turn, c = i ? /* @__PURE__ */ b(ci, {
									id: i.id,
									children: /* @__PURE__ */ b(tr, {
										actor: i,
										name: C(i),
										selected: o,
										current: s
									})
								}) : /* @__PURE__ */ b("span", {
									className: "tmb-socket-mark",
									"aria-hidden": "true",
									children: a ? E === r ? /* @__PURE__ */ b(d, { size: 20 }) : "+" : /* @__PURE__ */ b(Qn, { kind: Math.floor(r / 4) % 3 ? "melee" : "ranged" })
								}), l = `tmb-battle-cell ${i ? "tmb-unit " + (i.kind === "baddie" ? "tmb-unit-enemy" : "tmb-unit-hero") : ""} ${a ? "tmb-board-legal" : ""} ${o ? "tmb-board-selected" : ""} ${s ? "tmb-unit-turn" : ""}`, u = a && /* @__PURE__ */ b("svg", {
									className: "tmb-target-outline",
									viewBox: "0 0 100 100",
									"aria-hidden": "true",
									children: /* @__PURE__ */ b("circle", {
										cx: "50",
										cy: "50",
										r: "48",
										children: /* @__PURE__ */ b("animate", {
											attributeName: "stroke-dashoffset",
											from: "0",
											to: "-12",
											dur: "900ms",
											repeatCount: "indefinite"
										})
									})
								}), f = i ? [C(i), ...$n(g, i).map(({ label: e, value: t }) => e + " " + t)].join(" · ") : g("games.toomanybones.boardPosition", {
									x: r % 4 + 1,
									y: Math.floor(r / 4) + 1
								});
								return /* @__PURE__ */ b(si, {
									pos: r,
									children: a || de !== null ? /* @__PURE__ */ x("button", {
										type: "button",
										className: l,
										"aria-pressed": o,
										"aria-label": f,
										onClick: () => {
											de !== null || !i ? at(r) : (ee(i.id), D(-1));
										},
										children: [c, u]
									}) : /* @__PURE__ */ b("div", {
										className: l,
										children: c
									})
								}, r);
							})
						})
					}),
					/* @__PURE__ */ b("div", {
						className: "tmb-battle-feedback",
						role: "status",
						"aria-live": "polite",
						children: mt
					}),
					/* @__PURE__ */ b("div", {
						className: "tmb-battle-order",
						"aria-label": g("games.toomanybones.initiativeScore"),
						children: n.order.map((e) => {
							let r = t.actors.find((t) => t.id === e);
							return r && /* @__PURE__ */ x("span", {
								className: n.turn === e ? "tmb-order-current" : "",
								children: [
									C(r),
									" ",
									/* @__PURE__ */ b("b", { children: r.initiative })
								]
							}, e);
						})
					})
				]
			})
		}), M && !h && /* @__PURE__ */ b("div", {
			className: "tmb-modal",
			onClick: (e) => {
				e.target === e.currentTarget && N(null);
			},
			children: /* @__PURE__ */ x("section", {
				ref: F,
				className: "tmb-modal-body",
				role: "dialog",
				"aria-modal": "true",
				"aria-labelledby": "tmb-battle-dialog-title",
				onKeyDown: (e) => {
					if (e.key === "Escape" && N(null), e.key !== "Tab") return;
					let t = [...e.currentTarget.querySelectorAll("button:not(:disabled),summary")].filter((e) => e.getClientRects().length), n = e.shiftKey && document.activeElement === t[0] ? t.at(-1) : !e.shiftKey && document.activeElement === t.at(-1) ? t[0] : void 0;
					n && (e.preventDefault(), n.focus());
				},
				children: [/* @__PURE__ */ x("header", {
					className: "tmb-modal-head",
					children: [/* @__PURE__ */ b("b", {
						id: "tmb-battle-dialog-title",
						children: g(M === "menu" ? "games.toomanybones.moreOptions" : M === "enemies" ? "games.toomanybones.enemyRoster" : M === "backup" ? "games.toomanybones.backup" : M === "slots" ? "games.toomanybones.activate" : M === "loot" ? "games.toomanybones.loot" : M === "inspect" ? "games.toomanybones.inspect" : M === "dice" ? "games.toomanybones.resolveDice" : "games.toomanybones.battle")
					}), /* @__PURE__ */ b("button", {
						type: "button",
						"aria-label": g("games.toomanybones.close"),
						onClick: () => N(null),
						children: /* @__PURE__ */ b(f, { size: 20 })
					})]
				}), M === "enemies" ? /* @__PURE__ */ b("ul", {
					className: "tmb-enemy-roster",
					children: B.map((e) => /* @__PURE__ */ x("li", { children: [/* @__PURE__ */ b("strong", { children: C(e) }), /* @__PURE__ */ b("dl", { children: $n(g, e).map(({ kind: e, label: t, value: n }) => /* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("dt", { children: t }), /* @__PURE__ */ b("dd", { children: n })] }, e)) })] }, e.id))
				}) : M === "menu" ? /* @__PURE__ */ x("div", {
					className: "tmb-battle-menu",
					children: [
						[
							["backup", "games.toomanybones.backup"],
							["slots", "games.toomanybones.activate"],
							["loot", "games.toomanybones.loot"],
							["inspect", "games.toomanybones.inspect"]
						].map(([e, t]) => /* @__PURE__ */ b("button", {
							type: "button",
							onClick: () => N(e),
							disabled: e === "loot" ? !_ : e !== "inspect" && (!l || !S || xe),
							children: g(t)
						}, e)),
						l && xe && /* @__PURE__ */ b("button", {
							type: "button",
							onClick: () => N("special"),
							children: g("games.toomanybones.details")
						}),
						V && He.map((e) => /* @__PURE__ */ b("button", {
							type: "button",
							onClick: () => {
								me(e), N(null);
							},
							children: g("games.toomanybones.aim", { skill: fr(g, _.gearloc, e) })
						}, e)),
						we && G && /* @__PURE__ */ b("button", {
							type: "button",
							onClick: () => N("dice"),
							children: g("games.toomanybones.chooseResolution")
						}),
						(V || we) && /* @__PURE__ */ b("button", {
							type: "button",
							disabled: ct,
							onClick: () => {
								Ue.length && !ie ? P(!0) : st({ type: "endTurn" });
							},
							children: g(ie ? "games.toomanybones.endUnused" : "games.toomanybones.endTurn")
						})
					]
				}) : m(M, Je?.id ?? T, E >= 0 ? E : Math.max(0, _?.pos ?? 0), M === "dice" ? G?.uid : void 0, () => N(null))]
			})
		})]
	});
}
//#endregion
//#region src/game/reaction-controls.tsx
function fi({ s: e, send: t, target: n, pos: r, slot: i, mode: a, setMode: o, blocked: s }) {
	let l = c(), u = e.battle.reactions[0], d = u.slice(u.indexOf(":") + 1).split("|")[0], f = e.actors.find((e) => e.id === d);
	if (u.startsWith("mischief:") && f && f.kind !== "gearloc") return /* @__PURE__ */ b("div", {
		className: "tmb-buttons",
		children: f.enemyDefense.map((e, n) => /* @__PURE__ */ x("button", {
			type: "button",
			onClick: () => t({
				type: "ability",
				ability: "reaction",
				amount: n
			}),
			children: [
				l("games.toomanybones.discard"),
				" · ",
				l("games.toomanybones.defense"),
				" ",
				e
			]
		}, n))
	});
	if (u.startsWith("shield:") && f) return /* @__PURE__ */ b("div", {
		className: "tmb-buttons",
		children: Object.entries(f.counters).filter(([e]) => e.startsWith("shield:")).map(([e, n]) => /* @__PURE__ */ x("div", { children: [/* @__PURE__ */ x("b", { children: [
			l("games.toomanybones.defense"),
			" ",
			n
		] }), [
			"active",
			"locked",
			"discard"
		].map((n) => /* @__PURE__ */ b("button", {
			type: "button",
			onClick: () => t({
				type: "ability",
				ability: "reaction",
				amount: Number(e.slice(7)),
				mode: n
			}),
			children: l(n === "active" ? "games.toomanybones.store" : n === "locked" ? "games.toomanybones.lockStore" : "games.toomanybones.discard")
		}, n))] }, e))
	});
	let p = u.startsWith("riposte:") ? [
		"use",
		"double",
		"pass"
	] : u.startsWith("retaliate:") ? [
		"poison",
		"lashback",
		"both",
		"pass"
	] : u.startsWith("prevent:") || u.startsWith("roundOptics:") ? ["use", "pass"] : u.startsWith("sling:") ? ["use"] : [];
	return /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ x("p", { children: [l("games.toomanybones.pendingReaction", { name: f ? Er(l, f) : l("games.toomanybones.target") }), u.startsWith("prevent:") && " · " + pr(l, u.split("|")[1])] }), /* @__PURE__ */ b("div", {
		className: "tmb-buttons",
		children: p.length ? p.map((e) => /* @__PURE__ */ b("button", {
			type: "button",
			onClick: () => t({
				type: "ability",
				ability: "reaction",
				mode: e
			}),
			children: l(e === "use" ? "games.toomanybones.use" : e === "double" || e === "both" ? "games.toomanybones.double" : e === "pass" ? "games.toomanybones.pass" : e === "poison" ? "games.toomanybones.poison" : "games.toomanybones.damage")
		}, e)) : /* @__PURE__ */ x(y, { children: [u.startsWith("limit:") && /* @__PURE__ */ b(Nr, {
			label: l("games.toomanybones.skill"),
			value: a,
			onChange: o,
			options: [
				"hp",
				"dex",
				"attack",
				"defense"
			].filter((e) => (f?.counters[e + "Training"] ?? 0) > 0 && !f?.effects["limited:" + e]).map((e) => ({
				value: e,
				label: l(e === "hp" ? "games.toomanybones.hp" : e === "dex" ? "games.toomanybones.dex" : e === "attack" ? "games.toomanybones.attack" : "games.toomanybones.defense"),
				art: /* @__PURE__ */ b(Qn, { kind: e })
			}))
		}), /* @__PURE__ */ b("button", {
			type: "button",
			disabled: s || u.startsWith("limit:") && ![
				"hp",
				"dex",
				"attack",
				"defense"
			].includes(a),
			onClick: () => t({
				type: "ability",
				ability: "reaction",
				target: n,
				pos: r,
				mode: a,
				slot: i
			}),
			children: l("games.toomanybones.confirm")
		})] })
	})] });
}
//#endregion
//#region src/game/battle-details.tsx
function pi({ s: e, myRid: t, tab: n, target: r, pos: i, initialDie: a, send: s }) {
	let l = c(), u = e.actors.find((e) => e.owner === t && e.kind === "gearloc"), d = e.battle, [f, p] = o(r), [m, h] = o(Math.max(0, i)), [g, _] = o(a ? [a] : []), [v, S] = o("use"), [C, w] = o(1), [T, ee] = o(1), [E, D] = o(() => {
		let e = d.rolled.find((e) => e.uid === a), t = e && _e(e.face)[0];
		return [
			t?.kind === "parts" ? t.n : 1,
			0,
			0
		];
	}), [O, te] = o(""), [k, ne] = o(""), A = (e, t, n = !1) => /* @__PURE__ */ b("button", {
		type: "button",
		disabled: n,
		onClick: () => s(t),
		children: e
	}, e + JSON.stringify(t)), j = e.actors.filter((e) => e.hp > 0 && e.pos >= 0), M = j.filter((e) => e.kind === "gearloc"), N = j.filter((e) => e.kind === "baddie"), ie = Array.from({ length: 16 }, (e, t) => t), P = (t) => /* @__PURE__ */ b(Rr, {
		actors: e.actors,
		targets: t,
		value: f,
		onChange: p
	}), F = (t = ie) => /* @__PURE__ */ b(Lr, {
		actors: e.actors,
		legal: t,
		selected: m,
		onPick: h
	}), ae = (e) => _((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]);
	if (n === "inspect") {
		let t = re[e.config.tyrant].faces.reduce((e, t) => {
			let n = t.split(":")[0], r = e.find((e) => e.id === n);
			return r ? r.count += 1 : e.push({
				id: n,
				face: t,
				count: 1
			}), e;
		}, []);
		return /* @__PURE__ */ x("div", {
			className: "tmb-controls",
			children: [
				e.encounter && /* @__PURE__ */ x("details", { children: [/* @__PURE__ */ b("summary", { children: l("games.toomanybones.encounter") }), /* @__PURE__ */ b("p", {
					className: "whitespace-pre-line",
					children: l(Or[e.encounter])
				})] }),
				e.actors.map((e) => /* @__PURE__ */ b(ii, { actor: e }, e.id)),
				/* @__PURE__ */ x("details", { children: [/* @__PURE__ */ b("summary", { children: l("games.toomanybones.tyrantFaces") }), /* @__PURE__ */ b("ol", {
					className: "tmb-tyrant-faces",
					children: t.map(({ id: e, face: t, count: n }) => /* @__PURE__ */ x("li", { children: [
						/* @__PURE__ */ b("b", { children: Sr(l, t) }),
						n > 1 && /* @__PURE__ */ x("span", {
							className: "tmb-reference-count",
							children: [" × ", n]
						}),
						/* @__PURE__ */ b("span", { children: Cr(l, t) })
					] }, e))
				})] }),
				/* @__PURE__ */ x("details", { children: [/* @__PURE__ */ b("summary", { children: l("games.toomanybones.history") }), e.log.slice().reverse().map((t, n) => /* @__PURE__ */ b("p", { children: l("games.toomanybones.logLine", {
					who: e.actors.some((e) => e.id === t.who) ? Er(l, e.actors.find((e) => e.id === t.who)) : "",
					event: Tr(l, t.key),
					target: e.actors.some((e) => e.id === t.target) ? Er(l, e.actors.find((e) => e.id === t.target)) : "",
					n: t.n || ""
				}) }, n))] })
			]
		});
	}
	if (!u) return null;
	let oe = (e) => /* @__PURE__ */ b(Nr, {
		label: l("games.toomanybones.chooseDice"),
		value: k,
		onChange: ne,
		options: e.map((e) => ({
			value: e.uid,
			label: u.gearloc ? fr(l, u.gearloc, e.skill) : pr(l, e.kind),
			art: /* @__PURE__ */ b(Mr, { face: e.face })
		}))
	});
	if (n === "special") {
		let t = d.reactions[0], n = e.actors.find((e) => e.id === t?.split(":")[1]?.split("|")[0]), r = j.find((t) => t.definition === e.config.tyrant), i = t === "limitTarget" ? M.filter((e) => d.enemyTargets.includes(e.id) && [
			"hp",
			"dex",
			"attack",
			"defense"
		].some((t) => e.counters[t + "Training"] > 0 && !e.effects["limited:" + t])) : t === "carelessBomb" ? N.filter((e) => e.hp === d.pendingDamage.bombHp) : t === "charred" ? N.filter((e) => e.definition.startsWith("kobold") && e.hp === d.pendingDamage.charredHp) : t === "nomNext" || t === "dusterNext" ? e.actors.filter((e) => e.gearloc && e.hp > 0 && e.pos < 0 && e.counters.reserve === (t === "nomNext" ? 99 : 98)) : [], a = i.find((e) => e.id === f), o = (e, t) => Math.abs(e % 4 - t % 4) + Math.abs(Math.floor(e / 4) - Math.floor(t / 4)), c = t === "charred" && a ? we(e).filter((e, t, n) => o(e.pos, a.pos) === Math.min(...n.map((e) => o(e.pos, a.pos)))) : [], h = c.find((e) => e.id === v), g = t === "marrowRetreat" && r ? Lt(e, r).filter((e, t, n) => o(e, 2) < o(r.pos, 2) && o(e, 2) === Math.min(...n.map((e) => o(e, 2)))) : [], _ = n && (t?.startsWith("club:") || t?.startsWith("knockback:")) ? Xt(e, n.pos) : t === "marrowRetreat" && d.pendingDamage.marrowSteps > 0 ? g : h ? ie.filter((t) => !wt(e, t) && Y(t, h.pos)) : [];
		return d.flags.includes("orderPending") ? /* @__PURE__ */ x("div", {
			className: "tmb-controls",
			children: [
				/* @__PURE__ */ b(Nr, {
					label: l("games.toomanybones.initiative"),
					value: f,
					onChange: p,
					options: d.order.flatMap((t) => {
						let n = e.actors.find((e) => e.id === t);
						return n ? [{
							value: t,
							label: Er(l, n),
							art: /* @__PURE__ */ b(Ir, { actor: n })
						}] : [];
					})
				}),
				/* @__PURE__ */ b(Nr, {
					label: l("games.toomanybones.position"),
					value: C,
					onChange: w,
					options: d.order.map((t, n) => ({
						value: n + 1,
						label: `${n + 1} · ${Er(l, e.actors.find((e) => e.id === t))}`
					}))
				}),
				/* @__PURE__ */ x("div", {
					className: "tmb-buttons",
					children: [A(l("games.toomanybones.initiative"), {
						type: "ability",
						ability: "initiative",
						target: f,
						amount: C - 1
					}, !d.order.includes(f)), A(l("games.toomanybones.orderReady"), { type: "ready" })]
				})
			]
		}) : t ? /* @__PURE__ */ x("div", {
			className: "tmb-controls",
			children: [
				P(i),
				t === "charred" && /* @__PURE__ */ b(Rr, {
					actors: e.actors,
					targets: c,
					value: v,
					onChange: S
				}),
				F(_),
				t.startsWith("mischief:") && n?.gearloc && /* @__PURE__ */ b(Nr, {
					label: l("games.toomanybones.active"),
					value: O,
					onChange: te,
					options: n.active.map((e) => ({
						value: e.uid,
						label: pr(l, e.kind),
						art: /* @__PURE__ */ b(Mr, { face: `${e.kind}:${e.n}` })
					}))
				}),
				/* @__PURE__ */ b(fi, {
					s: e,
					send: s,
					target: f,
					pos: m,
					slot: O,
					mode: v,
					setMode: S,
					blocked: !!i.length && !a || !!_.length && !_.includes(m) || t === "charred" && !!a && a.hp > 1 && !h || t.startsWith("mischief:") && !!n?.gearloc && n.active.length > 0 && !O
				})
			]
		}) : /* @__PURE__ */ x("div", {
			className: "tmb-controls",
			children: [
				d.startEffects.includes("innateHeal") && u.upgraded && P(M),
				d.startEffects.includes("dive") && F(ie.filter((t) => !wt(e, t))),
				/* @__PURE__ */ b("div", {
					className: "tmb-buttons",
					children: d.startEffects.map((e) => A(pr(l, u.active.find((t) => t.uid === e)?.kind ?? (e === "innateHeal" ? "heal" : e)), {
						type: "ability",
						ability: "startEffect",
						mode: e,
						target: f || u.id,
						pos: m
					}))
				})
			]
		});
	}
	if (n === "dice") {
		let t = d.rolled.filter((e) => g.includes(e.uid) && !e.used), n = t[0], r = n && _e(n.face)[0], i = [];
		n && r && ([
			"bones",
			"forcedBones",
			"reusableBones"
		].includes(r.kind) ? i.push("bones") : r.kind !== "blank" && i.push(r.kind === "defense" ? "active" : "use"), r.kind === "defense" && u.gearloc === "picket" && u.upgraded && i.push("locked"), ["switch", "rush"].includes(r.kind) && i.push("active"), [
			"healMultiply",
			"healReroll",
			"buffReroll"
		].includes(r.kind) && i.push("locked"), r.kind === "anger" && i.push("decrease"), u.gearloc === "boomer" && u.upgraded && n.skill > 0 && n.skill <= 3 && [
			"bones",
			"blank",
			"forcedBones",
			"reusableBones"
		].includes(r.kind) && i.push("locked"), n.kind === "defense" && Ee(u, "l12") && ["bones", "defense:1"].includes(n.face) && !d.flags.includes("armor:" + n.uid) && i.push("increase"), !n.face.includes("forcedBones") && !n.face.includes("tainted") && !(u.gearloc === "boomer" && (n.skill === 16 || n.skill >= 5 && n.skill <= 11)) && i.push("discard"));
		let a = i.includes(v) ? v : i[0], o = t.length <= 1 || a === "use" && (t.every((e) => e.kind === "attack" && e.face.startsWith("attack:")) || t.length <= 2 && t.every((e) => ["switch", "rush"].includes(e.face) && e.face === n.face)), s = r?.kind !== "parts" || a === "discard" || E.reduce((e, t) => e + t, 0) === r.n, c = {
			use: "games.toomanybones.use",
			active: "games.toomanybones.store",
			locked: "games.toomanybones.lockStore",
			bones: "games.toomanybones.saveBones",
			discard: "games.toomanybones.discard",
			increase: "games.toomanybones.increase",
			decrease: "games.toomanybones.decrease",
			reroll: "games.toomanybones.reroll"
		}, p = !!r && a === "use" && [
			"heal",
			"trueDamage",
			"poisonAny",
			"revive",
			"reviveKo",
			"buffHp",
			"buffAttack",
			"recover",
			"booster",
			"permanentHp",
			"advancedDefense",
			"intercept",
			"switch",
			"rush",
			"attackMinus",
			"jump"
		].includes(r.kind), h = r?.kind === "revive" || r?.kind === "reviveKo" ? e.actors.filter((e) => e.gearloc && (r.kind === "revive" || e.hp <= 0)) : r?.kind === "switch" ? j.filter((e) => e.id !== u.id && Y(u.pos, e.pos)) : [
			"trueDamage",
			"poisonAny",
			"attackMinus",
			"jump"
		].includes(r?.kind ?? "") ? N : M, _ = (u.counters.rushUsed ?? 0) + t.length >= 2 ? N.filter((e) => Y(m, e.pos)) : [], w = a === "use" && !!r && [
			"healMultiply",
			"healReroll",
			"buffReroll"
		].includes(r.kind), T = w ? ct(d.rolled, r.kind) : [], ee = N.find((e) => e.id === f), O = r?.kind === "rush" ? ot(e, u) : ie.filter((t) => !wt(e, t) && (r?.kind !== "jump" || !!ee && Y(t, ee.pos)));
		return /* @__PURE__ */ x("div", {
			className: "tmb-controls",
			children: [
				n?.skill && u.gearloc ? /* @__PURE__ */ x(y, { children: [
					/* @__PURE__ */ b("h3", { children: fr(l, u.gearloc, n.skill) }),
					/* @__PURE__ */ b(zr, { text: ur(l, u.gearloc, n.skill) }),
					/* @__PURE__ */ b(Yr, {
						gearloc: u.gearloc,
						id: n.skill,
						compact: !0
					})
				] }) : null,
				/* @__PURE__ */ b("div", {
					className: "tmb-buttons",
					children: d.rolled.map((e) => /* @__PURE__ */ b("button", {
						type: "button",
						disabled: e.used,
						className: g.includes(e.uid) ? "tmb-selected" : "",
						onClick: () => ae(e.uid),
						children: /* @__PURE__ */ b(Mr, { face: e.face })
					}, e.uid))
				}),
				p && r.kind !== "rush" && P(h),
				a === "use" && r && ["rush", "jump"].includes(r.kind) && F(O),
				p && r.kind === "rush" && P(_),
				w && oe(T),
				r?.kind === "parts" && /* @__PURE__ */ b("div", {
					className: "tmb-select-row",
					children: [
						"element",
						"casing",
						"fuse"
					].map((e, t) => /* @__PURE__ */ b(Pr, {
						label: pr(l, e),
						value: E[t],
						max: r.n,
						onChange: (e) => D((n) => n.map((n, r) => r === t ? e : n))
					}, e))
				}),
				i.length > 1 && /* @__PURE__ */ b(Nr, {
					label: l("games.toomanybones.chooseResolution"),
					value: a ?? "",
					onChange: S,
					options: i.flatMap((e) => e ? [{
						value: e,
						label: l(c[e])
					}] : [])
				}),
				/* @__PURE__ */ b("div", {
					className: "tmb-buttons",
					children: A(l(a ? c[a] : "games.toomanybones.use"), {
						type: "resolve",
						dice: t.map((e) => e.uid),
						mode: a,
						target: w ? k : r?.kind === "rush" ? _.find((e) => e.id === f)?.id : f || void 0,
						pos: m,
						amount: C,
						components: E
					}, !t.length || !a || !o || !s || w && !T.some((e) => e.uid === k) || a === "use" && !!r && [
						"heal",
						"trueDamage",
						"poisonAny",
						"revive",
						"reviveKo",
						"buffHp",
						"buffAttack",
						"recover",
						"booster",
						"permanentHp",
						"advancedDefense",
						"intercept",
						"switch",
						"jump"
					].includes(r.kind) && !h.some((e) => e.id === f) || a === "use" && !!r && ["rush", "jump"].includes(r.kind) && !O.includes(m))
				}),
				u.inventory.some((e) => e.card === "v14" && e.locks === 3) && !d.lastAttack.length && /* @__PURE__ */ x("details", { children: [
					/* @__PURE__ */ b("summary", { children: l("games.toomanybones.enemyTarget") }),
					P(N),
					A(l("games.toomanybones.confirm"), {
						type: "ability",
						ability: "target",
						target: f
					}, !N.some((e) => e.id === f))
				] })
			]
		});
	}
	if (n === "backup") {
		let t = De(u), n = u.gearloc ? yr(l, u.gearloc).map(({ cost: n, text: r }) => {
			let i = Math.max(0, n - (n < 6 && Ee(u, "v3") ? 1 : 0)), a = N.find((e) => e.id === d.target), o = !(u.gearloc === "picket" && [2, 5].includes(n) || u.gearloc === "boomer" && [1, 4].includes(n) || u.gearloc === "patches" && n === 3) || !!a && Dt(e, u, a, u.gearloc === "boomer" && u.ranged);
			return {
				price: n,
				text: r,
				paid: i,
				spent: n === 6 && u.upgraded,
				affordable: o && t >= i
			};
		}).filter((e) => !e.spent) : [], r = (n.find((e) => e.price === C && e.affordable) ?? n.find((e) => e.affordable))?.price, i = u.gearloc === "patches" && r === 2 ? M : u.gearloc === "patches" && r === 5 ? N : u.gearloc === "boomer" && r === 3 ? j : [], a = i.find((e) => e.id === f) ?? (u.gearloc === "patches" && r === 2 ? u : void 0), o = u.gearloc === "boomer" && r === 2 || u.gearloc === "picket" && r === 3, s = d.rolled.filter((e) => !e.used && (u.gearloc !== "boomer" || e.skill >= 1 && e.skill <= 3)), c = u.gearloc === "boomer" && r === 3 && a ? Lt(e, a) : [], h = ce.patches.map((e) => e.id).filter((e) => Le(u, e));
		return /* @__PURE__ */ x("div", {
			className: "tmb-controls",
			children: [
				/* @__PURE__ */ x("p", { children: [
					l("games.toomanybones.bones"),
					" ",
					t
				] }),
				/* @__PURE__ */ b("ul", {
					className: "tmb-backup-options",
					children: n.map((e) => /* @__PURE__ */ b("li", { children: /* @__PURE__ */ x("button", {
						type: "button",
						"aria-pressed": r === e.price,
						disabled: !e.affordable,
						onClick: () => w(e.price),
						children: [
							/* @__PURE__ */ x("b", { children: [
								e.price,
								" ",
								l("games.toomanybones.bones")
							] }),
							/* @__PURE__ */ b("span", { children: e.text }),
							e.paid < e.price && /* @__PURE__ */ b("span", {
								className: "tmb-backup-discount",
								children: l("games.toomanybones.backupCostPaid", { n: e.paid })
							})
						]
					}) }, e.price))
				}),
				r !== void 0 && /* @__PURE__ */ x(y, { children: [
					/* @__PURE__ */ b(Rr, {
						actors: e.actors,
						targets: i,
						value: a?.id ?? "",
						onChange: p
					}),
					F(c),
					u.gearloc === "patches" && r === 4 && /* @__PURE__ */ b(Fr, {
						gearloc: "patches",
						ids: h,
						value: T,
						onChange: ee
					}),
					o && /* @__PURE__ */ b("div", {
						className: "tmb-buttons",
						children: s.map((e) => /* @__PURE__ */ b("button", {
							type: "button",
							"aria-pressed": g.includes(e.uid),
							onClick: () => ae(e.uid),
							children: /* @__PURE__ */ b(Mr, { face: e.face })
						}, e.uid))
					}),
					A(l("games.toomanybones.backup"), {
						type: "backup",
						cost: r,
						target: a?.id ?? d.target ?? void 0,
						pos: m,
						ids: g,
						skill: T
					}, d.backupUsed || !!d.modifiers.noBackup || !!i.length && !a || u.gearloc === "boomer" && r === 3 && !c.includes(m) || o && !s.some((e) => g.includes(e.uid)) || u.gearloc === "patches" && (r === 4 && !h.includes(T) || r === 5 && !(u.counters.cells > 0)))
				] })
			]
		});
	}
	let se = e.actors.flatMap((e) => [...e.active, ...e.locked].filter((e) => e.owner === u.id).map((t) => ({
		holder: e,
		slot: t
	}))), I = se.find(({ slot: e }) => e.uid === O), le = I?.slot.kind ?? "", ue = [
		"healMultiply",
		"healReroll",
		"buffReroll"
	].includes(le), de = I?.holder.id === u.id && (ue || [
		"constantMove",
		"switch",
		"rush"
	].includes(le)), fe = ["switch", "rush"].includes(le) && u.active.some((e) => e.uid !== O && e.kind === le), pe = fe && v === "double" ? "double" : "use", me = le === "rush" ? ot(e, u) : le === "constantMove" && (u.counters.freeMoveUsed ?? 0) < (I?.slot.n ?? 0) ? Lt(e, u) : [], he = le === "switch" ? j.filter((e) => e !== u && Y(e.pos, u.pos)) : le === "rush" && (u.counters.rushUsed ?? 0) + (pe === "double" ? 2 : 1) >= 2 ? N.filter((e) => Y(m, e.pos)) : [], ge = ue ? ct(d.rolled, le) : [], ve = ue ? k : he.find((e) => e.id === f)?.id, ye = ue && !ge.some((e) => e.uid === k) || le === "switch" && !ve || ["rush", "constantMove"].includes(le) && !me.includes(m);
	return /* @__PURE__ */ x("div", {
		className: "tmb-controls",
		children: [
			/* @__PURE__ */ b(Nr, {
				label: l("games.toomanybones.activate"),
				value: O,
				onChange: (e) => {
					te(e), ne(""), S("use");
				},
				options: se.map(({ holder: e, slot: t }) => ({
					value: t.uid,
					label: Er(l, e).split(" · ")[0] + " · " + pr(l, t.kind),
					art: /* @__PURE__ */ b(Mr, { face: `${t.kind}:${t.n}` })
				}))
			}),
			I && /* @__PURE__ */ x(y, { children: [de && /* @__PURE__ */ x(y, { children: [
				fe && /* @__PURE__ */ b(Nr, {
					label: l("games.toomanybones.activate"),
					value: pe,
					onChange: S,
					options: ["use", "double"].map((e) => ({
						value: e,
						label: l(e === "use" ? "games.toomanybones.use" : "games.toomanybones.double")
					}))
				}),
				F(me),
				P(he),
				ue && oe(ge)
			] }), /* @__PURE__ */ x("div", {
				className: "tmb-buttons",
				children: [de && A(l("games.toomanybones.activate"), {
					type: "ability",
					ability: "activate",
					slot: O,
					target: ve,
					pos: m,
					mode: pe
				}, ye), A(l("games.toomanybones.release"), {
					type: "ability",
					ability: "release",
					slot: O,
					target: I.holder.id
				})]
			})] }),
			u.gearloc === "boomer" && A(l("games.toomanybones.craft"), {
				type: "ability",
				ability: "craft"
			}, u.counters.grenades >= 3),
			u.gearloc === "tantrum" && /* @__PURE__ */ x(y, { children: [
				P(N),
				/* @__PURE__ */ x("div", {
					className: "tmb-buttons",
					children: [u.counters.axes > 0 && A(l("games.toomanybones.axe"), {
						type: "ability",
						ability: "axe",
						target: f
					}, !!u.counters.axeUsed || !e.actors.some((e) => e.id === f && e.kind === "baddie" && !Y(u.pos, e.pos))), u.counters.bodyCount > 0 && A(l("games.toomanybones.bodyCount"), {
						type: "ability",
						ability: "bodyCount"
					})]
				}),
				/* @__PURE__ */ x("details", { children: [/* @__PURE__ */ b("summary", { children: l("games.toomanybones.rage") }), /* @__PURE__ */ b("div", {
					className: "tmb-buttons",
					children: [
						"heal",
						"damage",
						"bones",
						"execute",
						"advance"
					].map((e) => A(l(e === "heal" ? "games.toomanybones.heal" : e === "damage" ? "games.toomanybones.damage" : e === "bones" ? "games.toomanybones.bones" : e === "execute" ? "games.toomanybones.execute" : "games.toomanybones.advance"), {
						type: "ability",
						ability: "rage",
						mode: e,
						target: f
					}))
				})] })
			] })
		]
	});
}
//#endregion
//#region src/game/challenge-controls.tsx
function mi({ s: e, a: t, send: n }) {
	let r = c(), i = e.challenge, a = i.ids[0], [s, l] = o([]), [u, d] = o(t.id), [f, p] = o(1), [m, h] = o(0), g = (e) => l((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]), _ = (e = 0, t = u, r = f) => {
		n({
			type: "choose",
			option: e,
			target: t,
			amount: r,
			ids: s
		}), l([]);
	}, v = (e, t = 0, n = u, r = f) => /* @__PURE__ */ b("button", {
		type: "button",
		onClick: () => _(t, n, r),
		children: e
	}, e + t + n + r), S = (e, t, n, r = 30) => /* @__PURE__ */ x("label", { children: [e, /* @__PURE__ */ b("input", {
		type: "number",
		min: 0,
		max: r,
		value: t,
		onChange: (e) => n(Math.max(0, Math.min(r, Number(e.target.value))))
	})] }), C = e.actors.filter((e) => e.kind === "gearloc").flatMap((e) => e.inventory.map((t) => ({
		p: e,
		l: t
	}))), w = (e = () => !0, t = !1) => /* @__PURE__ */ b("div", {
		className: "tmb-buttons",
		children: C.filter(({ p: t, l: n }) => e(n.uid, t)).map(({ p: e, l: n }) => /* @__PURE__ */ x("button", {
			type: "button",
			className: (t ? s.includes(n.uid) : u === n.uid) ? "tmb-selected" : "",
			onClick: () => t ? g(n.uid) : d(n.uid),
			children: [
				e.gearloc && r(ar[e.gearloc]),
				" · ",
				mr(r, n.card)
			]
		}, n.uid))
	}), T = /* @__PURE__ */ x("label", { children: [r("games.toomanybones.target"), /* @__PURE__ */ b("select", {
		value: u,
		onChange: (e) => d(e.target.value),
		children: e.actors.filter((e) => e.kind === "gearloc").map((e) => /* @__PURE__ */ x("option", {
			value: e.id,
			children: [
				Er(r, e),
				" · ",
				e.hp,
				" ♥"
			]
		}, e.id))
	})] });
	if (i.kind === "decision") {
		let n;
		switch (a) {
			case "pickEncounter":
				n = /* @__PURE__ */ b("div", {
					className: "tmb-buttons",
					children: i.ids.slice(1).map((e) => /* @__PURE__ */ b("button", {
						type: "button",
						onClick: () => _(0, e),
						children: r(Or[e])
					}, e))
				});
				break;
			case "startingLoot":
				n = /* @__PURE__ */ x(y, { children: [w((t, n) => n.id === e.actors.filter((e) => e.kind === "gearloc")[i.step]?.id && n.inventory.slice(-2).some((e) => e.uid === t)), v(r("games.toomanybones.keep"))] });
				break;
			case "troveRedraw":
				n = /* @__PURE__ */ x(y, { children: [v(r("games.toomanybones.keep"), 0), v(r("games.toomanybones.draw"), 1)] });
				break;
			case "troveImmediate":
				n = /* @__PURE__ */ x(y, { children: [
					w((t, n) => n === e.actors.filter((e) => e.kind === "gearloc")[i.step] && n.inventory.some((e) => e.uid === t && e.locks < 3)),
					v(r("games.toomanybones.lockpick"), 0),
					v(r("games.toomanybones.pass"), 1)
				] });
				break;
			case "bribe":
			case "discardThenRedraw":
			case "gambleLoot":
				n = /* @__PURE__ */ x(y, { children: [w(() => !0, !0), v(r("games.toomanybones.confirm"))] });
				break;
			case "healDuster": {
				let e = C.filter(({ l: e }) => Qt(e) > 0), t = e.reduce((e, { l: t }) => e + (s.includes(t.uid) ? Qt(t) : 0), 0);
				n = /* @__PURE__ */ x("div", {
					className: "tmb-flow-stack",
					children: [
						/* @__PURE__ */ b("div", {
							className: "tmb-loot-grid",
							children: e.map(({ l: e }) => /* @__PURE__ */ b(Hr, {
								item: e,
								selected: s.includes(e.uid),
								onClick: () => g(e.uid)
							}, e.uid))
						}),
						/* @__PURE__ */ x("p", {
							role: "status",
							children: [
								r("games.toomanybones.heal"),
								" ",
								t,
								"/",
								i.values[0]
							]
						}),
						/* @__PURE__ */ b("button", {
							type: "button",
							disabled: t < i.values[0],
							onClick: () => _(),
							children: r("games.toomanybones.confirm")
						})
					]
				});
				break;
			}
			case "offering":
				n = /* @__PURE__ */ x(y, { children: [w((e, n) => n.id === t.id), v(r("games.toomanybones.confirm"))] });
				break;
			case "whirlwind":
			case "trapHp":
			case "duel":
			case "wolfHand":
				n = /* @__PURE__ */ x(y, { children: [
					T,
					i.values.length > 0 && /* @__PURE__ */ b("p", { children: i.values.join(" · ") }),
					v(r("games.toomanybones.confirm"))
				] });
				break;
			case "snipe": {
				let e = Array.from({ length: t.attack }, (e, t) => t + 1), i = Math.min(t.attack, f);
				n = /* @__PURE__ */ x("div", {
					className: "tmb-flow-stack",
					children: [/* @__PURE__ */ b("div", {
						className: "tmb-challenge-dice",
						children: e.map((e) => /* @__PURE__ */ b("button", {
							"aria-label": `${r("games.toomanybones.attack")} ${e}`,
							"aria-pressed": e <= i,
							type: "button",
							onClick: () => p(e),
							children: /* @__PURE__ */ b(Qn, { kind: "attack" })
						}, e))
					}), /* @__PURE__ */ b("button", {
						type: "button",
						className: "tmb-flow-primary",
						disabled: !i,
						onClick: () => _(0, t.id, i),
						children: r("games.toomanybones.roll")
					})]
				});
				break;
			}
			case "grab":
			case "barrelCount":
				n = /* @__PURE__ */ x(y, { children: [S(r("games.toomanybones.amount"), f, p, a === "grab" ? 6 : 4), v(r("games.toomanybones.confirm"))] });
				break;
			case "exhaustStats":
				n = /* @__PURE__ */ x(y, { children: [
					S(r("games.toomanybones.attack"), f, p, 6),
					S(r("games.toomanybones.defense"), m, h, 6),
					v(r("games.toomanybones.confirm"), m)
				] });
				break;
			case "scoutReturn":
				n = /* @__PURE__ */ b(y, { children: [
					1,
					5,
					20
				].map((e) => v(r("games.toomanybones.point", { n: e }), 0, void 0, e)) });
				break;
			case "tripSkills":
				n = /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("div", {
					className: "tmb-buttons",
					children: t.skills.filter((e) => !ge(t.gearloc, e).counter).map((e) => /* @__PURE__ */ b("button", {
						type: "button",
						className: s.includes(String(e)) ? "tmb-selected" : "",
						onClick: () => g(String(e)),
						children: fr(r, t.gearloc, e)
					}, e))
				}), v(r("games.toomanybones.confirm"))] });
				break;
			case "bogIngredients":
				n = /* @__PURE__ */ x(y, { children: [v(r("games.toomanybones.point", { n: 1 }) + " × 6", 0), v(r("games.toomanybones.point", { n: 5 }) + " × 3", 1)] });
				break;
			case "goblinBomb":
				n = /* @__PURE__ */ b(y, { children: [
					"L",
					"T",
					"F"
				].map((e) => v(r(e === "L" ? "games.toomanybones.lever" : e === "T" ? "games.toomanybones.trip" : "games.toomanybones.force"), 0, e)) });
				break;
			default: n = null;
		}
		return /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("h3", { children: r(Dr[a] ?? "games.toomanybones.decision") }), /* @__PURE__ */ b("div", {
			className: "tmb-buttons",
			children: n
		})] });
	}
	if (i.kind === "scout") {
		let e = i.ids[0]?.split("#")[0], t = A(e), n = ne.findIndex((t) => t.id === e);
		return /* @__PURE__ */ x("div", {
			className: "tmb-scout-result",
			children: [
				Xn[e] && /* @__PURE__ */ b("img", {
					alt: "",
					src: Xn[e]
				}),
				/* @__PURE__ */ b("h3", { children: r("games.toomanybones.baddieNames").split("|")[n] ?? r("games.toomanybones.scout") }),
				/* @__PURE__ */ x("p", { children: [r("games.toomanybones.point", { n: i.values[0] }), t && /* @__PURE__ */ x(y, { children: [
					" · ",
					r("games.toomanybones.hp"),
					" ",
					t.hp,
					" · ",
					r("games.toomanybones.attack"),
					" ",
					t.attack,
					" · ",
					r(t.ranged ? "games.toomanybones.ranged" : "games.toomanybones.melee")
				] })] }),
				/* @__PURE__ */ x("div", {
					className: "tmb-flow-confirm",
					children: [v(r("games.toomanybones.cycle"), 1), v(r("games.toomanybones.keep"), 0)]
				})
			]
		});
	}
	return i.kind === "lootChoice" ? /* @__PURE__ */ x(y, { children: [w((e) => i.ids.includes(e)), v(r("games.toomanybones.keep"))] }) : i.kind === "flick" ? i.data.complete ? v(r("games.toomanybones.confirm")) : /* @__PURE__ */ b("p", { children: r("games.toomanybones.shots", { n: i.step }) }) : i.kind === "darts" ? /* @__PURE__ */ x(y, { children: [
		!!i.data["weaken:0"] && !i.data.setup && /* @__PURE__ */ b("div", {
			className: "tmb-buttons",
			children: _n(i, 0).map((e) => /* @__PURE__ */ x("button", {
				type: "button",
				className: s.includes(e.id) ? "tmb-selected" : "",
				onClick: () => g(e.id),
				children: [
					r(e.kind === "attack" ? "games.toomanybones.attack" : e.kind === "defense" ? "games.toomanybones.defense" : "games.toomanybones.poison"),
					" ",
					e.index + 1
				]
			}, e.id))
		}),
		/* @__PURE__ */ x("div", {
			className: "tmb-darts-board",
			children: [[0, 1].map((e) => /* @__PURE__ */ x("div", { children: [
				/* @__PURE__ */ b("strong", { children: i.values[e] }),
				/* @__PURE__ */ b("b", { children: r(e === 0 ? "games.toomanybones.playerSide" : "games.toomanybones.opponentSide") }),
				/* @__PURE__ */ x("p", { children: [
					r("games.toomanybones.defense"),
					" ",
					i.values[2 + e],
					" · ",
					r("games.toomanybones.poison"),
					" ",
					i.values[4 + e]
				] })
			] }, e)), !i.data.setup && i.dice.length > 0 && /* @__PURE__ */ b("div", {
				className: "tmb-challenge-dice",
				children: i.dice.map((e, t) => /* @__PURE__ */ b("span", { children: e > 0 && e < 10 ? e : /* @__PURE__ */ b(Mr, { face: e === 0 ? "bones" : {
					10: "weaken:1",
					11: "poison:1",
					12: "poison:2",
					13: "stun",
					14: "weaken:2",
					15: "poison:3"
				}[e] ?? "blank" }) }, t))
			})]
		}),
		i.data.discard ? /* @__PURE__ */ x(y, { children: [w((e, n) => n.id === t.id), v(r("games.toomanybones.discard"))] }) : i.data.setup ? /* @__PURE__ */ x(y, { children: [
			/* @__PURE__ */ b("p", { children: r("games.toomanybones.dartsSetup") }),
			S(r("games.toomanybones.attack"), f, p, 2),
			S(r("games.toomanybones.defense"), m, h, 2),
			/* @__PURE__ */ x("p", { children: [
				r("games.toomanybones.poison"),
				" ",
				3 - f - m
			] }),
			v(r("games.toomanybones.confirm"), m)
		] }) : i.data.bones ? /* @__PURE__ */ x("div", {
			className: "tmb-buttons",
			children: [
				v(r("games.toomanybones.dartsPass"), 0),
				[0, 1].flatMap((e) => [
					"poison",
					"weaken",
					"stun"
				].map((t) => /* @__PURE__ */ b("span", { children: v(r("games.toomanybones.discard") + " · " + r(e === 0 ? "games.toomanybones.playerSide" : "games.toomanybones.opponentSide") + " " + r(t === "poison" ? "games.toomanybones.poison" : "games.toomanybones.effect"), 1, t + ":" + e) }, t + e))),
				Object.entries(i.data).filter(([e, t]) => e.startsWith("defense:") && t > 0).map(([e, t]) => /* @__PURE__ */ b("span", { children: v(r("games.toomanybones.discard") + " · " + r(e.split(":")[1] === "0" ? "games.toomanybones.playerSide" : "games.toomanybones.opponentSide") + " " + r("games.toomanybones.defense") + " " + t, 1, e) }, e)),
				i.data.bones >= 2 && v(r("games.toomanybones.dartsStun"), 3),
				i.data.bones >= 3 && v(r("games.toomanybones.dartsWin"), 4)
			]
		}) : i.data.enemyTurn ? /* @__PURE__ */ b("p", { children: r("games.toomanybones.wait") }) : v(r("games.toomanybones.dartsRoll"))
	] }) : i.kind === "barrels" ? /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ x("p", { children: [i.values.join(" ♥ · "), " ♥"] }), v(r("games.toomanybones.roll"))] }) : i.kind === "lanterns" ? /* @__PURE__ */ b("div", {
		className: "tmb-buttons",
		children: i.values.map((e, t) => e > 0 && v(r("games.toomanybones.target") + " " + (t + 1) + " · " + e, t))
	}) : i.kind === "critters" && i.data.critterSelect ? /* @__PURE__ */ x(y, { children: [
		/* @__PURE__ */ x("p", { children: [
			r("games.toomanybones.die"),
			" ",
			i.dice.join(" · ")
		] }),
		/* @__PURE__ */ b("div", {
			className: "tmb-choice-board",
			children: i.values.map((e, t) => /* @__PURE__ */ x("button", {
				type: "button",
				className: f === t ? "tmb-selected" : "",
				disabled: !e,
				onClick: () => p(t),
				children: [
					t % 4 + 1,
					"·",
					Math.floor(t / 4) + 1,
					" · ",
					e,
					" ♥"
				]
			}, t))
		}),
		/* @__PURE__ */ x("div", {
			className: "tmb-buttons",
			children: [i.values.map((e, t) => e > 0 && Y(t, f) && /* @__PURE__ */ x("button", {
				type: "button",
				onClick: () => _(f, String(t)),
				children: [
					r("games.toomanybones.move"),
					" ",
					t % 4 + 1,
					"·",
					Math.floor(t / 4) + 1
				]
			}, t)), v(r("games.toomanybones.confirm"), f)]
		})
	] }) : i.kind === "critters" || i.kind === "rubble" ? /* @__PURE__ */ x(y, { children: [
		S(r("games.toomanybones.attack"), f, p, t.attack),
		/* @__PURE__ */ b("div", {
			className: "tmb-choice-board",
			children: Array.from({ length: 16 }, (e, t) => /* @__PURE__ */ x("button", {
				type: "button",
				onClick: () => i.data.deploy ? n({
					type: "deploy",
					pos: t
				}) : _(t),
				children: [
					t % 4 + 1,
					"·",
					Math.floor(t / 4) + 1,
					/* @__PURE__ */ b("br", {}),
					i.values[t] ? i.values[t] + " ♥" : "·"
				]
			}, t))
		}),
		i.kind === "critters" && !i.data.deploy && v(r("games.toomanybones.endTurn"), 0, "pass")
	] }) : null;
}
//#endregion
//#region src/game/adventure-view.tsx
var hi = [
	"hp",
	"dex",
	"attack",
	"defense"
], gi = [
	[
		"rest",
		"games.toomanybones.flowRest",
		"games.toomanybones.rest"
	],
	[
		"search",
		"games.toomanybones.flowSearch",
		"games.toomanybones.search"
	],
	[
		"scout",
		"games.toomanybones.flowScout",
		"games.toomanybones.scout"
	]
], _i = {
	g3: [1],
	g4: [0],
	g9: [0],
	g16: [0],
	g23: [0],
	g24: [0],
	g26: [0],
	o1: [1],
	o5: [0, 1],
	o7: [1],
	o8: [0, 1],
	o12: [0, 1]
};
function vi({ id: e }) {
	let t = Xn[e];
	return /* @__PURE__ */ b("span", {
		className: "tmb-flow-portrait",
		children: t ? /* @__PURE__ */ b("img", {
			alt: "",
			src: t,
			draggable: !1
		}) : /* @__PURE__ */ b(_, { size: 23 })
	});
}
function yi({ member: e }) {
	let t = e && ee[e.colorIndex % ee.length]?.hex, n = e && T[e.avatar % T.length];
	return /* @__PURE__ */ b("span", {
		className: "tmb-flow-portrait tmb-player-avatar",
		style: { borderColor: t },
		"aria-hidden": "true",
		children: n ? /* @__PURE__ */ b("img", {
			src: n,
			alt: "",
			draggable: !1
		}) : /* @__PURE__ */ b(_, { size: 19 })
	});
}
function bi({ reward: e }) {
	let t = c();
	return /* @__PURE__ */ x("ul", {
		className: "tmb-flow-rewards",
		children: [
			e.progress > 0 && /* @__PURE__ */ b("li", { children: t("games.toomanybones.progressShort", { n: e.progress }) }),
			e.training > 0 && /* @__PURE__ */ b("li", { children: t("games.toomanybones.flowEachTraining", { n: e.training }) }),
			e.loot > 0 && /* @__PURE__ */ b("li", { children: t("games.toomanybones.flowLeaderLoot", { n: e.loot }) }),
			e.eachLoot > 0 && /* @__PURE__ */ b("li", { children: t("games.toomanybones.flowEachLoot", { n: e.eachLoot }) }),
			e.trove > 0 && /* @__PURE__ */ b("li", { children: t("games.toomanybones.flowLeaderTrove", { n: e.trove }) }),
			e.eachTrove > 0 && /* @__PURE__ */ b("li", { children: t("games.toomanybones.flowEachTrove", { n: e.eachTrove }) })
		]
	});
}
function xi({ s: e, canAct: t, send: n }) {
	let r = c(), i = re[e.config.tyrant], a = Math.max(0, i.progress - e.progress), o = e.actors.some((e) => e.gearloc && G(e) > 4);
	return /* @__PURE__ */ x("section", {
		className: "tmb-flow-stack tmb-day-table",
		children: [
			/* @__PURE__ */ b("ol", {
				className: "tmb-day-track",
				"aria-label": r("games.toomanybones.flowDeadline", { n: i.days }),
				children: Array.from({ length: i.days }, (t, n) => /* @__PURE__ */ b("li", {
					"data-past": n + 1 < e.day || void 0,
					"aria-current": n + 1 === e.day ? "step" : void 0,
					children: n + 1
				}, n))
			}),
			/* @__PURE__ */ x("div", {
				className: "tmb-day-cards",
				children: [/* @__PURE__ */ x("button", {
					type: "button",
					className: "tmb-draw-card",
					disabled: !t || o,
					onClick: () => n({
						type: "choose",
						option: 0
					}),
					children: [
						t && !o && /* @__PURE__ */ b("svg", {
							className: "tmb-draw-outline",
							"aria-hidden": "true",
							children: /* @__PURE__ */ b("rect", {
								x: "2",
								y: "2",
								rx: "7"
							})
						}),
						/* @__PURE__ */ b("span", {
							"aria-hidden": "true",
							children: "▱"
						}),
						/* @__PURE__ */ b("strong", { children: r("games.toomanybones.draw") }),
						/* @__PURE__ */ b("small", { children: e.drawCounts.encounters })
					]
				}), /* @__PURE__ */ x("div", {
					className: "tmb-flow-paper tmb-flow-stack",
					children: [/* @__PURE__ */ x("div", {
						className: "tmb-flow-identity",
						children: [/* @__PURE__ */ b(vi, { id: e.config.tyrant }), /* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("h2", { children: r(or[e.config.tyrant]) }), /* @__PURE__ */ b("p", { children: r("games.toomanybones.flowDeadline", { n: i.days }) })] })]
					}), /* @__PURE__ */ x("label", {
						className: "tmb-flow-progress",
						children: [r("games.toomanybones.flowProgress", {
							n: e.progress,
							total: i.progress
						}), /* @__PURE__ */ b("progress", {
							max: i.progress,
							value: Math.min(e.progress, i.progress)
						})]
					})]
				})]
			}),
			o && /* @__PURE__ */ b("p", {
				role: "status",
				children: r("games.toomanybones.flowOverload")
			}),
			a ? /* @__PURE__ */ b("p", {
				className: "tmb-flow-action-note",
				children: r("games.toomanybones.flowBossLocked", { n: a })
			}) : t && /* @__PURE__ */ b("button", {
				type: "button",
				disabled: o,
				onClick: () => n({
					type: "choose",
					option: 1
				}),
				children: r("games.toomanybones.fightTyrant")
			})
		]
	});
}
function Si({ s: e, actor: t, canAct: n, send: r }) {
	let i = c(), a = e.encounter, s = ie(a), [l, u] = o(), [f, p] = o(t?.id ?? ""), m = n ? l : e.choice ?? void 0, h = i(Or[a]), g = a === "t15" ? h.lastIndexOf("\n") : -1, _ = (g < 0 ? h : h.slice(0, g)).split(/\n(?=[①②③④⑤]|\d+\.)/), v = Array.from({ length: s.choices }, (e, t) => {
		let n = _[t]?.trim().replace(/^(?:[①②③④⑤]|\d+\.)\s*/, "") ?? "", r = n.search(/：|: /);
		return r < 0 ? {
			title: i("games.toomanybones.choice", { n: t + 1 }),
			text: n
		} : {
			title: n.slice(0, r),
			text: n.slice(r + 1).trim()
		};
	}), S = l !== void 0 && _i[a]?.includes(l), C = e.actors.filter((e) => e.gearloc), w = Ci[a], T = (e) => !(a === "o7" && l === 1 && !e.inventory.length || a === "o12" && l === 1 && e.skills.filter((t) => !ce[e.gearloc][t - 1].counter).length < 3), ee = (t) => !!e.persistent["today:blocked:" + a + ":" + t], E = l === void 0 || ee(l) || l === 0 && a === "g13" && C.reduce((e, t) => e + t.inventory.length, 0) < C.length || l === 0 && a === "t8" && C.flatMap((e) => e.inventory).reduce((e, t) => e + Qt(t), 0) < C.length * 2 || S && !C.some((e) => e.id === f && T(e));
	return /* @__PURE__ */ x("section", {
		className: "tmb-flow-panel tmb-flow-stack tmb-flow-encounter",
		children: [
			/* @__PURE__ */ x("div", {
				className: "tmb-flow-encounter-head",
				children: [
					/* @__PURE__ */ b("h2", { children: i(w ?? "games.toomanybones.encounter") }),
					/* @__PURE__ */ b("p", { children: i("games.toomanybones.flowEncounterReward") }),
					/* @__PURE__ */ b(bi, { reward: s.reward })
				]
			}),
			g >= 0 && /* @__PURE__ */ b("p", {
				className: "tmb-flow-action-note",
				children: h.slice(g + 1)
			}),
			/* @__PURE__ */ b("div", {
				className: "tmb-flow-choices",
				children: v.map(({ title: e, text: r }, i) => {
					let a = s.choiceRewards[i];
					return /* @__PURE__ */ x("article", {
						className: "tmb-flow-paper tmb-flow-route",
						"data-selected": m === i || void 0,
						children: [n ? /* @__PURE__ */ x("button", {
							type: "button",
							"aria-pressed": m === i,
							disabled: ee(i),
							onClick: () => {
								u(i), p(t?.id ?? "");
							},
							children: [
								/* @__PURE__ */ b("strong", { children: e }),
								/* @__PURE__ */ b("span", { children: r }),
								m === i && /* @__PURE__ */ b(d, { size: 18 })
							]
						}) : /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("h3", { children: e }), /* @__PURE__ */ b("p", { children: r })] }), a && /* @__PURE__ */ b(bi, { reward: a })]
					}, i);
				})
			}),
			n && S && /* @__PURE__ */ x("fieldset", {
				className: "tmb-flow-targets",
				children: [/* @__PURE__ */ b("legend", { children: i("games.toomanybones.flowChooseHero") }), C.map((e) => /* @__PURE__ */ x("button", {
					type: "button",
					"aria-pressed": f === e.id,
					disabled: !T(e),
					onClick: () => p(e.id),
					children: [/* @__PURE__ */ b(vi, { id: e.gearloc }), Er(i, e)]
				}, e.id))]
			}),
			n && l !== void 0 && /* @__PURE__ */ b("button", {
				type: "button",
				className: "tmb-flow-primary",
				disabled: !!E,
				onClick: () => r({
					type: "choose",
					option: l,
					target: S ? f : t?.id
				}),
				children: i("games.toomanybones.flowConfirmRoute", { name: v[l].title })
			})
		]
	});
}
var Ci = {
	s1: "games.toomanybones.flowFirstEncounter",
	g1: "games.toomanybones.flowBogEncounter"
};
function wi({ a: e, canAct: t, send: n }) {
	let r = c(), i = e.gearloc, [a, s] = o(), [l, u] = o(0), [d, f] = o(), [p, m] = o(), h = a === void 0 ? void 0 : ce[i][a - 1], g = t && e.training > 0, _ = !!h && !h.consumable && !e.skills.includes(h.id) && h.requires.every((t) => e.skills.includes(t)), v = (t) => g && !e.failedTraining.includes(t) && (e.counters[t + "Training"] ?? 0) < 5, S = (e) => {
		s(e), f(void 0), u(nr[i].findIndex((t) => t.skills.includes(e)));
	}, C = () => {
		d === "skill" && g && _ && h ? (m(h.id), n({
			type: "train",
			stat: "skill",
			skill: h.id
		})) : d && d !== "skill" && v(d) && n({
			type: "train",
			stat: d
		}), f(void 0);
	}, w = p && e.skills.includes(p) ? ce[i].filter((t) => !t.consumable && !e.skills.includes(t.id) && t.requires.includes(p) && t.requires.every((t) => e.skills.includes(t))).map((e) => e.id) : [], T = (e) => r(e === "hp" ? "games.toomanybones.hp" : e === "dex" ? "games.toomanybones.dex" : e === "attack" ? "games.toomanybones.attack" : "games.toomanybones.defense"), ee = /* @__PURE__ */ x("div", {
		className: "tmb-flow-confirm",
		children: [/* @__PURE__ */ b("button", {
			type: "button",
			onClick: () => f(void 0),
			children: r("games.toomanybones.flowUndo")
		}), /* @__PURE__ */ b("button", {
			type: "button",
			className: "tmb-flow-primary",
			disabled: d === "skill" ? !g || !_ : !d || !v(d),
			onClick: C,
			children: r(d === "skill" ? "games.toomanybones.flowConfirmLearn" : "games.toomanybones.flowConfirmTraining")
		})]
	});
	return /* @__PURE__ */ x("section", {
		className: "tmb-flow-stack tmb-training-stage",
		children: [
			/* @__PURE__ */ x("div", {
				className: "tmb-flow-panel tmb-flow-stack tmb-training-actor",
				children: [
					/* @__PURE__ */ x("div", {
						className: "tmb-flow-between",
						children: [/* @__PURE__ */ x("div", {
							className: "tmb-flow-identity",
							children: [/* @__PURE__ */ b(vi, { id: i }), /* @__PURE__ */ b("h2", { children: Er(r, e) })]
						}), /* @__PURE__ */ b("b", { children: r("games.toomanybones.trainingPoints", { n: e.training }) })]
					}),
					/* @__PURE__ */ b("div", {
						className: "tmb-flow-stats",
						children: hi.map((t) => /* @__PURE__ */ x("button", {
							type: "button",
							disabled: !v(t),
							"aria-pressed": d === t,
							onClick: () => f(t),
							children: [
								/* @__PURE__ */ b(Qn, { kind: t }),
								/* @__PURE__ */ b("strong", { children: t === "hp" ? e.hp + "/" + e.maxHp : e[t] }),
								/* @__PURE__ */ x("span", { children: [T(t), " +"] })
							]
						}, t))
					}),
					e.failedTraining.length > 0 && /* @__PURE__ */ b("p", {
						role: "status",
						children: r("games.toomanybones.flowTrainFailed", { name: e.failedTraining.map((e) => T(e)).join(" · ") })
					})
				]
			}),
			/* @__PURE__ */ b(Zr, {
				gearloc: i,
				learned: e.skills,
				selected: a,
				group: l,
				onSelect: S,
				onGroup: (e) => {
					u(e), s(void 0), f(void 0);
				},
				pending: d === "skill" ? a : void 0,
				unlocked: w
			}),
			/* @__PURE__ */ x("div", {
				className: "tmb-flow-stack tmb-training-controls",
				children: [d && d !== "skill" ? /* @__PURE__ */ x("section", {
					className: "tmb-flow-panel tmb-flow-stack",
					children: [
						/* @__PURE__ */ b("h2", { children: T(d) }),
						/* @__PURE__ */ x("strong", {
							className: "tmb-stat-preview",
							children: [
								d === "hp" ? `${e.hp}/${e.maxHp}` : e[d],
								" → ",
								d === "hp" ? `${e.hp + 1}/${e.maxHp + 1}` : e[d] + 1
							]
						}),
						(d === "attack" || d === "defense") && /* @__PURE__ */ b("p", { children: r("games.toomanybones.flowTrainingRollInfo") }),
						ee
					]
				}) : h && /* @__PURE__ */ x("section", {
					className: "tmb-flow-panel tmb-flow-stack",
					children: [
						/* @__PURE__ */ b(Qr, {
							gearloc: i,
							id: h.id,
							learned: e.skills,
							onSelect: S
						}),
						h.consumable && /* @__PURE__ */ b("p", { children: r("games.toomanybones.consumableNote") }),
						d === "skill" ? ee : g && _ && /* @__PURE__ */ b("button", {
							type: "button",
							className: "tmb-flow-primary",
							onClick: () => f("skill"),
							children: r("games.toomanybones.flowTrainSkill", { name: fr(r, i, h.id) })
						}),
						w.length > 0 && /* @__PURE__ */ b("p", {
							role: "status",
							children: r("games.toomanybones.flowUnlocked", { names: w.map((e) => fr(r, i, e)).join(r("games.toomanybones.skillSeparator")) })
						})
					]
				}), t && e.training === 0 && /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("button", {
					type: "button",
					className: "tmb-flow-primary",
					disabled: G(e) > 4,
					onClick: () => n({ type: "ready" }),
					children: r("games.toomanybones.flowFinishTraining")
				}), G(e) > 4 && /* @__PURE__ */ b("p", { children: r("games.toomanybones.flowOverload") })] })]
			})
		]
	});
}
function Ti({ s: e, a: t, canAct: n, send: r }) {
	let i = c(), [a, s] = o(), [l, u] = o(!1), [d, f] = o(""), p = !!e.lock || e.challenge.kind !== "none", h = n && !p && (!t.recovery.length || !!e.persistent["today:fullRecovery"]), _ = (e) => !t.recovery.includes(e) && (e !== "search" || t.inventory.length > 0), v = t.inventory.find((e) => e.uid === d);
	return /* @__PURE__ */ x("section", {
		className: "tmb-flow-stack tmb-recovery-stage",
		children: [
			/* @__PURE__ */ x("div", {
				className: "tmb-flow-between",
				children: [/* @__PURE__ */ x("div", {
					className: "tmb-flow-identity",
					children: [/* @__PURE__ */ b(vi, { id: t.gearloc }), /* @__PURE__ */ b("h2", { children: Er(i, t) })]
				}), /* @__PURE__ */ x("b", { children: [
					i("games.toomanybones.hp"),
					" ",
					t.hp,
					"/",
					t.maxHp
				] })]
			}),
			h && /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("div", {
				className: "tmb-recovery-choices",
				children: gi.map(([t, n, r]) => /* @__PURE__ */ x("button", {
					type: "button",
					className: "tmb-flow-rest-choice",
					"aria-pressed": a === t,
					disabled: !_(t),
					onClick: () => s(t),
					children: [
						t === "rest" ? /* @__PURE__ */ b(Qn, { kind: "hp" }) : b(t === "search" ? g : m, {}),
						/* @__PURE__ */ b("strong", { children: i(n) }),
						/* @__PURE__ */ b("span", { children: t === "rest" && e.persistent.noHealing === e.day ? i("games.toomanybones.flowNoHealing") : i(r) })
					]
				}, t))
			}), a && _(a) && /* @__PURE__ */ b("button", {
				type: "button",
				className: "tmb-flow-primary",
				onClick: () => {
					a === "search" ? (f(""), u(!0)) : a && r({
						type: "recover",
						option: a
					});
				},
				children: i("games.toomanybones.flowConfirmRest", { name: i(gi.find(([e]) => e === a)[1]) })
			})] }),
			t.recovery.length > 0 && /* @__PURE__ */ b("p", {
				role: "status",
				children: i("games.toomanybones.flowRestDone", { name: gi.filter(([e]) => t.recovery.includes(e)).map(([, e]) => i(e)).join(" · ") || i("games.toomanybones.recovery") })
			}),
			n && t.recovery.length > 0 && /* @__PURE__ */ x(y, { children: [G(t) > 4 && /* @__PURE__ */ b("p", { children: i("games.toomanybones.flowOverload") }), /* @__PURE__ */ b("button", {
				type: "button",
				className: "tmb-flow-primary",
				disabled: p || G(t) > 4,
				onClick: () => r({ type: "ready" }),
				children: i("games.toomanybones.ready")
			})] }),
			l && !p && /* @__PURE__ */ x(Br, {
				title: i("games.toomanybones.flowSearchDiscard"),
				close: () => u(!1),
				children: [
					/* @__PURE__ */ b("div", {
						className: "tmb-loot-grid",
						children: t.inventory.map((e) => /* @__PURE__ */ b(Hr, {
							selected: d === e.uid,
							item: e,
							onClick: () => f(e.uid)
						}, e.uid))
					}),
					v && /* @__PURE__ */ b(zr, { text: hr(i, v.card) }),
					/* @__PURE__ */ b("button", {
						type: "button",
						className: "tmb-flow-primary",
						disabled: !v,
						onClick: () => {
							v && r({
								type: "recover",
								option: "search",
								loot: v.uid
							}), u(!1);
						},
						children: i("games.toomanybones.flowSearchRoll")
					})
				]
			})
		]
	});
}
function Ei({ Screen: e, s: t, props: n, recruit: r, flick: i }) {
	let a = c(), l = s((e) => e.locale), { myRid: u, send: d } = n, f = !!n.private?.canAct && t.phase !== "done", p = t.actors.filter((e) => e.gearloc), m = p.find((e) => e.owner === u), h = (e) => {
		let t = n.members.find((t) => t.rid === e), r = p.find((t) => t.owner === e);
		return t ? C(t, l) : r ? Er(a, r).split(" · ")[0] : a("games.toomanybones.wait");
	}, g = t.lock, _ = g && [
		t.day,
		g.by,
		g.owner,
		g.loot,
		g.startedAt
	].join(":"), v = g?.by === u && g.returnTo === "recovery" ? g : void 0, [y, S] = o(v?.owner), [w, T] = o(v?.loot), [ee, E] = o(), [D, O] = o(!!v), [te, k] = o(_);
	_ !== te && (k(_), v && (S(v.owner), T(v.loot), O(!0)), _ || E(void 0));
	let ne = p.find((e) => e.id === y) ?? m ?? p[0], A = p.find((e) => e.inventory.some((e) => e.uid === w)), j = A?.inventory.find((e) => e.uid === w), M = g && p.find((e) => e.id === g.owner)?.inventory.find((e) => e.uid === g.loot), N = t.challenge, ie = N.by === u || t.phase === "challenge" && f && N.data.deploy === 1, P = N.kind === "decision" && N.ids[0] === "startingLoot", F = P || N.kind === "lootChoice", ae = F || N.kind === "scout", oe = P ? p[N.step]?.inventory.slice(-2) ?? [] : p.flatMap((e) => e.inventory.filter((e) => N.ids.includes(e.uid))), I = P ? p.slice(N.step).flatMap((e) => e.inventory.slice(-2)) : F ? oe : [], ce = t.phase === "training" || t.phase === "recovery" ? p.filter((e) => !e.ready).map((e) => e.owner) : t.phase === "challenge" ? N.data.deploy === 1 ? p.filter((e) => e.pos < 0).map((e) => e.owner) : [N.by] : t.phase === "recruit" ? t.players.filter((e) => !p.some((t) => t.owner === e)) : [t.leader], le = (g ? [g.by] : ae ? [N.by] : ce).filter(Boolean), ue = (ae ? ie && !g : f) ? a("games.toomanybones.yourTurn") : a("games.toomanybones.flowWaiting", { name: le.map(h).join(" · ") || a("games.toomanybones.wait") }), de = t.day + ":" + t.phase + ":" + t.encounter, fe = (e) => {
		e.type === "lockStart" && E(void 0), e.type === "loot" && (e.mode === "give" || e.mode === "discard") && T(void 0), d(e);
	}, pe = g && _ && /* @__PURE__ */ b(Kr, {
		lock: g,
		canAct: g.by === u && f,
		open: ee !== _,
		title: M ? a("games.toomanybones.flowLockTitle", { name: mr(a, M.card) }) : a("games.toomanybones.lockpick"),
		close: () => E(_),
		send: d,
		supplies: (e) => m && /* @__PURE__ */ b("div", {
			className: "tmb-flow-buttons",
			children: m.inventory.filter((e) => !se(e.card).trove).filter((t) => {
				let n = se(t.card).slot;
				return n === 7 ? g.by === u && g.values[g.at] <= 4 : e !== void 0 && (n === 9 || g.by === u && [
					11,
					14,
					20
				].includes(n));
			}).map((t) => /* @__PURE__ */ x("button", {
				type: "button",
				onClick: () => d({
					type: "loot",
					loot: t.uid,
					mode: "use",
					amount: e
				}),
				children: [
					a("games.toomanybones.use"),
					" · ",
					mr(a, t.card)
				]
			}, t.uid))
		})
	}, _), me = P ? p[N.step] : p.find((e) => e.owner === N.by), he = F ? /* @__PURE__ */ b(Ur, {
		items: oe,
		recipient: me && Er(a, me).split(" · ")[0],
		acting: ie,
		send: d
	}, `${t.day}:${N.by}:${N.step}:${oe.map((e) => e.uid).join(",")}`) : t.phase === "day" ? /* @__PURE__ */ b(xi, {
		s: t,
		canAct: f && !ae,
		send: d
	}) : t.phase === "encounter" && t.encounter ? /* @__PURE__ */ b(Si, {
		s: t,
		actor: m,
		canAct: f && !ae,
		send: d
	}, de) : t.phase === "training" && m ? /* @__PURE__ */ b(wi, {
		a: m,
		canAct: f && !ae && !g,
		send: d
	}, de) : t.phase === "recovery" && m ? /* @__PURE__ */ b(Ti, {
		s: t,
		a: m,
		canAct: f && !ae,
		send: d
	}, de) : t.phase === "challenge" ? /* @__PURE__ */ x("section", {
		className: "tmb-flow-panel tmb-flow-stack tmb-controls",
		children: [N.kind === "flick" && i, !g && !ae && m && ie && N.kind !== "lock" && /* @__PURE__ */ b(mi, {
			s: t,
			a: m,
			send: d
		}, N.kind + ":" + N.ids[0] + ":" + N.step)]
	}) : null;
	return /* @__PURE__ */ x("div", {
		className: "tmb-root tmb-flow h-full",
		children: [
			/* @__PURE__ */ b(e, {
				adaptive: !0,
				className: "tmb-flow-screen",
				banner: /* @__PURE__ */ x("header", {
					className: "tmb-flow-banner",
					children: [
						/* @__PURE__ */ b("strong", { children: a("games.toomanybones.name") }),
						/* @__PURE__ */ x("span", { children: [
							a(sr[t.phase]),
							" · ",
							a("games.toomanybones.dayCount", {
								n: t.day,
								p: t.progress,
								total: re[t.config.tyrant].progress
							})
						] }),
						t.phase !== "done" && /* @__PURE__ */ b("span", {
							role: "status",
							children: ue
						})
					]
				}),
				children: t.phase === "recruit" ? /* @__PURE__ */ b("div", {
					className: "tmb-flow-recruit",
					children: r
				}) : /* @__PURE__ */ x("div", {
					className: "tmb-flow-layout",
					children: [/* @__PURE__ */ x("aside", {
						className: "tmb-flow-tools",
						children: [
							/* @__PURE__ */ b("ul", {
								className: "tmb-flow-party",
								children: t.players.map((e) => {
									let r = p.find((t) => t.owner === e);
									return /* @__PURE__ */ x("li", { children: [
										/* @__PURE__ */ b(yi, { member: n.members.find((t) => t.rid === e) }),
										/* @__PURE__ */ x("span", { children: [/* @__PURE__ */ b("b", { children: h(e) }), r && /* @__PURE__ */ b("small", { children: Er(a, r).split(" · ")[0] })] }),
										/* @__PURE__ */ b("small", { children: t.phase === "done" ? "" : r?.ready ? a("games.toomanybones.flowReady") : le.includes(e) ? a("games.toomanybones.flowActing") : a("games.toomanybones.wait") })
									] }, e);
								})
							}),
							ne && !g && /* @__PURE__ */ b("button", {
								type: "button",
								onClick: () => O(!0),
								children: a("games.toomanybones.flowBag")
							}),
							m && f && !g && !ae && ["training", "recovery"].includes(t.phase) && p.some((e) => [...e.active, ...e.locked].some((e) => e.owner === m.id)) && /* @__PURE__ */ x("details", {
								className: "tmb-slot-tools",
								children: [/* @__PURE__ */ x("summary", { children: [
									a("games.toomanybones.active"),
									" · ",
									a("games.toomanybones.locked")
								] }), /* @__PURE__ */ b("div", {
									className: "tmb-flow-buttons",
									children: p.flatMap((e) => [...e.active, ...e.locked].filter((e) => e.owner === m.id).map((t) => /* @__PURE__ */ x("button", {
										type: "button",
										onClick: () => d({
											type: "ability",
											ability: "release",
											slot: t.uid,
											target: e.id
										}),
										children: [
											a("games.toomanybones.release"),
											" · ",
											pr(a, t.kind),
											" ",
											t.n
										]
									}, t.uid)))
								})]
							})
						]
					}), /* @__PURE__ */ b("main", {
						className: "tmb-flow-stack",
						children: g ? /* @__PURE__ */ x("section", {
							className: "tmb-flow-panel tmb-flow-stack tmb-resume-lock",
							children: [
								M && /* @__PURE__ */ b("strong", { children: mr(a, M.card) }),
								/* @__PURE__ */ b("p", { children: a("games.toomanybones.flowLockProgress", {
									n: g.at,
									total: g.values.length
								}) }),
								/* @__PURE__ */ b("button", {
									className: "tmb-flow-primary",
									type: "button",
									onClick: () => E(void 0),
									children: a(g.by === u ? "games.toomanybones.flowResumeLock" : "games.toomanybones.flowViewLock")
								})
							]
						}) : N.kind === "scout" ? ie && m && /* @__PURE__ */ b("div", {
							className: "tmb-controls tmb-flow-panel",
							children: /* @__PURE__ */ b(mi, {
								s: t,
								a: m,
								send: d
							}, N.kind + ":" + N.ids[0])
						}) : he
					})]
				})
			}, de),
			pe,
			!g && D && A && j && /* @__PURE__ */ b(qr, {
				s: t,
				actor: m,
				holder: A,
				item: j,
				canUse: t.phase !== "done" && !ae,
				close: () => T(void 0),
				send: fe
			}, j.uid),
			!g && D && ne && !j && /* @__PURE__ */ x(Br, {
				title: a("games.toomanybones.flowBag"),
				close: () => O(!1),
				children: [
					p.length > 1 && /* @__PURE__ */ b("div", {
						className: "tmb-flow-buttons",
						children: p.map((e) => /* @__PURE__ */ b("button", {
							type: "button",
							"aria-pressed": ne.id === e.id,
							onClick: () => S(e.id),
							children: h(e.owner)
						}, e.id))
					}),
					/* @__PURE__ */ b("div", {
						className: "tmb-loot-grid",
						children: ne.inventory.filter((e) => !I.some((t) => t.uid === e.uid)).map((e) => /* @__PURE__ */ b(Hr, {
							item: e,
							onClick: () => T(e.uid)
						}, e.uid))
					}),
					!ne.inventory.some((e) => !I.some((t) => t.uid === e.uid)) && /* @__PURE__ */ b("p", { children: a("games.toomanybones.flowEmptyLoot") })
				]
			})
		]
	});
}
//#endregion
//#region src/game/view-player.tsx
function Di(e) {
	let t = e.public, n = e.private, i = s((e) => e.locale), [a, c] = o(t);
	t.battle && a !== t && c(t);
	let l = !!a.battle && !t.battle && t.day === a.day && t.encounter === a.encounter && !window.matchMedia("(prefers-reduced-motion: reduce)").matches && a.actors.some((e) => {
		if (e.hp <= 0 || e.pos < 0) return !1;
		let n = t.actors.find(({ id: t }) => t === e.id);
		return n ? n.hp !== e.hp : t.log.some((t) => t.key === "defeat" && t.target === e.id);
	});
	r(() => {
		if (!l) return;
		let e = window.setTimeout(() => c(t), 750);
		return () => window.clearTimeout(e);
	}, [l, t]);
	let u = l ? a : t, d = u.battle, f = Object.fromEntries(e.members.map((e) => [e.rid, C(e, i)]));
	return (u.phase === "battle" || u.phase === "done") && d ? /* @__PURE__ */ b(ui, {
		Screen: S,
		s: u,
		myRid: e.myRid,
		names: f,
		settling: l,
		canAct: !l && t.phase === "battle" && !!n?.canAct,
		send: e.send,
		tools: (n, r, i, a, o) => t.phase === "done" ? /* @__PURE__ */ b("div", {
			className: "tmb-controls",
			children: t.actors.map((e) => /* @__PURE__ */ b(ii, { actor: e }, e.id))
		}) : n === "loot" ? /* @__PURE__ */ b(Jr, {
			s: t,
			myRid: e.myRid,
			initialTarget: r,
			initialPos: i,
			send: (t) => {
				e.send(t), o();
			}
		}, n) : /* @__PURE__ */ b(pi, {
			s: t,
			myRid: e.myRid,
			tab: n,
			target: r,
			pos: i,
			initialDie: a,
			send: (t) => {
				e.send(t), o();
			}
		}, n + ":" + a + ":" + d.reactions[0] + ":" + d.startEffects.join(","))
	}) : /* @__PURE__ */ b(Ei, {
		Screen: S,
		s: t,
		props: e,
		recruit: /* @__PURE__ */ b(Oi, {
			s: t,
			canAct: !!n?.canAct,
			send: e.send
		}),
		flick: /* @__PURE__ */ b(ki, {
			s: t,
			myRid: e.myRid,
			send: e.send
		})
	}, e.myRid);
}
function Oi({ s: e, canAct: t, send: n }) {
	let r = c(), i = e.config.difficulty === "adventurer" ? 2 : +(e.config.difficulty === "heroic"), [a, s] = o(), [l, u] = o(!1), f = a && e.actors.some((e) => e.gearloc === a), [p, m, h, g] = a ? ve[a] : [];
	return /* @__PURE__ */ x("div", {
		className: "tmb-recruit",
		children: [
			/* @__PURE__ */ b("div", {
				className: "tmb-recruit-grid",
				children: le.map((t) => {
					let n = e.actors.some((e) => e.gearloc === t), [i, o] = r(ar[t]).split(" · ");
					return /* @__PURE__ */ x("button", {
						type: "button",
						className: "tmb-recruit-tile",
						"aria-pressed": a === t,
						onClick: () => s(t),
						children: [
							/* @__PURE__ */ b("span", {
								className: "tmb-recruit-tile-mark",
								children: b(a === t ? d : v, { size: 20 })
							}),
							/* @__PURE__ */ b(vi, { id: t }),
							/* @__PURE__ */ b("strong", { children: i }),
							/* @__PURE__ */ x("small", { children: [
								o,
								" · ",
								r(t === "boomer" ? "games.toomanybones.ranged" : "games.toomanybones.melee")
							] }),
							n && /* @__PURE__ */ b("small", { children: r("games.toomanybones.chosen") })
						]
					}, t);
				})
			}),
			a && /* @__PURE__ */ x("section", {
				className: "tmb-recruit-preview tmb-flow-stack",
				children: [
					/* @__PURE__ */ b("dl", {
						className: "tmb-recruit-stats",
						children: [
							[r("games.toomanybones.hp"), p + i],
							[r("games.toomanybones.dex"), m],
							[r("games.toomanybones.attack"), h],
							[r("games.toomanybones.defense"), g]
						].map(([e, t]) => /* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("dt", { children: e }), /* @__PURE__ */ b("dd", { children: t })] }, e))
					}),
					/* @__PURE__ */ b($r, {
						gearloc: a,
						compact: !0
					}),
					/* @__PURE__ */ x("div", {
						className: "tmb-flow-confirm",
						children: [/* @__PURE__ */ b("button", {
							type: "button",
							onClick: () => u(!0),
							children: r("games.toomanybones.viewSkillTree")
						}), t && !f && /* @__PURE__ */ b("button", {
							type: "button",
							className: "tmb-flow-primary",
							onClick: () => n({
								type: "chooseGearloc",
								gearloc: a
							}),
							children: r("games.toomanybones.flowRecruitName", { name: r(ar[a]).split(" · ")[0] })
						})]
					})
				]
			}),
			l && a && /* @__PURE__ */ b(Br, {
				title: r(ar[a]),
				close: () => u(!1),
				children: /* @__PURE__ */ b(ti, { gearloc: a })
			})
		]
	});
}
function ki({ s: e, send: t, myRid: n }) {
	let r = c(), i = a(null), s = e.challenge, [l, u] = o(0), [d, f] = o(0), [p, m] = o(65), [h, g] = o(null);
	return /* @__PURE__ */ x("div", { children: [
		/* @__PURE__ */ b("p", { children: r("games.toomanybones.flick") }),
		/* @__PURE__ */ x("svg", {
			className: "tmb-flick",
			viewBox: "0 0 1000 1000",
			role: "img",
			"aria-label": r("games.toomanybones.flick"),
			onPointerDown: (e) => {
				if (s.by !== n) return;
				let t = e.currentTarget.getBoundingClientRect(), r = (e.clientX - t.left) / t.width * 1e3, a = (e.clientY - t.top) / t.height * 1e3, o = Math.floor(r / 250);
				a < 800 || s.data["shot:" + o] || (i.current = {
					x: r,
					y: a,
					lane: o
				}, g({
					x: r,
					y: a,
					fromX: r,
					fromY: a
				}), e.currentTarget.setPointerCapture(e.pointerId));
			},
			onPointerUp: (e) => {
				let n = i.current;
				if (!n) return;
				let r = e.currentTarget.getBoundingClientRect(), a = (e.clientX - r.left) / r.width * 1e3, o = (e.clientY - r.top) / r.height * 1e3;
				i.current = null, g(null), t({
					type: "flick",
					lane: n.lane,
					x: Math.max(n.lane * 250 + 25, Math.min(n.lane * 250 + 225, n.x)),
					vx: Math.max(-2500, Math.min(2500, (a - n.x) * 4)),
					vy: Math.max(-4e3, Math.min(-50, (o - n.y) * 4))
				});
			},
			onPointerMove: (e) => {
				if (!i.current) return;
				let t = e.currentTarget.getBoundingClientRect();
				g({
					fromX: i.current.x,
					fromY: i.current.y,
					x: (e.clientX - t.left) / t.width * 1e3,
					y: (e.clientY - t.top) / t.height * 1e3
				});
			},
			onPointerCancel: () => {
				i.current = null, g(null);
			},
			children: [
				/* @__PURE__ */ b("rect", {
					width: "1000",
					height: "1000",
					fill: "#30394e"
				}),
				h && /* @__PURE__ */ b("line", {
					x1: h.fromX,
					y1: h.fromY,
					x2: h.x,
					y2: h.y,
					stroke: "#dfaa9c",
					strokeWidth: "8",
					strokeDasharray: "18 12"
				}),
				[
					0,
					1,
					2,
					3
				].map((e) => /* @__PURE__ */ x("g", { children: [
					/* @__PURE__ */ b("path", {
						d: `M${e * 250} 0V1000`,
						stroke: "#8792aa",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ b("circle", {
						cx: s.values[e * 2],
						cy: s.values[e * 2 + 1],
						r: "21",
						fill: s.data["hit:" + e] ? "#e3a44f" : "#dae0c3"
					}),
					!s.data["shot:" + e] && /* @__PURE__ */ b("path", {
						d: `M${125 + e * 250} 965v-60l-16 22m16-22 16 22`,
						stroke: "#f7e7c4",
						strokeWidth: "8",
						fill: "none"
					})
				] }, e)),
				/* @__PURE__ */ b("polyline", {
					points: s.dice.reduce((e, t, n) => n % 2 == 0 ? [...e, t + "," + s.dice[n + 1]] : e, []).join(" "),
					fill: "none",
					stroke: "#ddbf76",
					strokeWidth: "4"
				})
			]
		}),
		/* @__PURE__ */ b("p", { children: r("games.toomanybones.shots", { n: s.step }) }),
		/* @__PURE__ */ x("details", { children: [/* @__PURE__ */ b("summary", { children: r("games.toomanybones.flickAdjust") }), /* @__PURE__ */ x("div", {
			className: "tmb-controls",
			children: [
				/* @__PURE__ */ x("label", { children: [r("games.toomanybones.flickLane", { n: l + 1 }), /* @__PURE__ */ b("select", {
					value: l,
					onChange: (e) => u(Number(e.target.value)),
					children: [
						0,
						1,
						2,
						3
					].map((e) => /* @__PURE__ */ b("option", {
						value: e,
						children: r("games.toomanybones.flickLane", { n: e + 1 })
					}, e))
				})] }),
				/* @__PURE__ */ x("label", { children: [
					r("games.toomanybones.flickAngle"),
					" ",
					d,
					"°",
					/* @__PURE__ */ b("input", {
						type: "range",
						min: -60,
						max: 60,
						value: d,
						onChange: (e) => f(Number(e.target.value))
					})
				] }),
				/* @__PURE__ */ x("label", { children: [
					r("games.toomanybones.flickPower"),
					" ",
					p,
					/* @__PURE__ */ b("input", {
						type: "range",
						min: 2,
						max: 100,
						value: p,
						onChange: (e) => m(Number(e.target.value))
					})
				] }),
				/* @__PURE__ */ b("button", {
					type: "button",
					disabled: s.by !== n || !!s.data["shot:" + l],
					onClick: () => t({
						type: "flick",
						lane: l,
						x: l * 250 + 125,
						vx: Math.max(-2500, Math.min(2500, Math.sin(d * Math.PI / 180) * p * 40)),
						vy: -Math.max(50, Math.cos(d * Math.PI / 180) * p * 40)
					}),
					children: r("games.toomanybones.flickShoot")
				})
			]
		})] })
	] });
}
//#endregion
//#region src/game/bot.ts
var Ai = (e, t) => Math.abs(Ct(e) - Ct(t)) + Math.abs(St(e) - St(t)), $ = (e = 0, t, n, r) => ({
	type: "choose",
	option: e,
	target: t,
	amount: n,
	ids: r
});
function ji(e) {
	let t = e.lock;
	if (!t.rolled.length) return {
		type: "lock",
		mode: "roll"
	};
	let n = t.available.filter((e) => t.rolled[e][0] === t.types[t.at]), r = Array.from({ length: 1 << n.length }, (e, t) => n.filter((e, n) => t & 1 << n)).filter((e) => e.reduce((e, n) => e + Number(t.rolled[n].slice(1)), 0) >= t.values[t.at]);
	if (r.sort((e, t) => e.length - t.length), r[0]) return {
		type: "lock",
		mode: "solve",
		dice: r[0]
	};
	let i = [...t.available].sort((e, n) => Number(t.rolled[n].slice(1)) - Number(t.rolled[e].slice(1)))[0];
	if (!t.usedIntuition && t.intuition === "convert") {
		let e = t.available.find((e) => !n.includes(e));
		if (e !== void 0) return {
			type: "lock",
			mode: "convert",
			die: e,
			lockType: t.types[t.at]
		};
	}
	return !t.usedIntuition && t.intuition === "save" && i !== void 0 ? {
		type: "lock",
		mode: "save",
		die: i
	} : t.intuition === "reroll" && t.available.length ? {
		type: "lock",
		mode: "reroll",
		dice: [t.available.find((e) => !n.includes(e)) ?? t.available[0]]
	} : {
		type: "lock",
		mode: "stop"
	};
}
function Mi(e, t) {
	let n = e.challenge, r = z(e).flatMap((e) => e.inventory);
	if (n.kind === "scout") return $(0);
	if (n.kind === "lootChoice") return $(0, n.ids[0]);
	if (n.kind === "flick") {
		if (n.data.complete) return $();
		let e = [
			0,
			1,
			2,
			3
		].find((e) => !n.data["shot:" + e]);
		return e === void 0 ? null : {
			type: "flick",
			lane: e,
			x: e * 250 + 125,
			vx: 0,
			vy: -1900
		};
	}
	if (n.kind === "decision") switch (n.ids[0]) {
		case "pickEncounter": return $(0, n.ids[1]);
		case "startingLoot": return $(0, z(e)[n.step].inventory.at(-1)?.uid);
		case "troveRedraw": return $(0);
		case "troveImmediate": return $(1);
		case "discardThenRedraw":
		case "bribe": return $(0, void 0, void 0, r.slice(0, n.values[0]).map((e) => e.uid));
		case "snipe": return $(0, void 0, t.attack);
		case "grab": return $(0, void 0, 1);
		case "whirlwind":
		case "trapHp":
		case "duel":
		case "wolfHand": {
			let t = z(e).filter((e) => e.hp > 0);
			return t.sort((e, t) => n.ids[0] === "trapHp" ? Math.abs(e.hp - n.values[0]) - Math.abs(t.hp - n.values[0]) : t.hp - e.hp), $(0, t[0]?.id);
		}
		case "scoutReturn": return $(0, void 0, 1);
		case "exhaustStats": return $(0, void 0, 1);
		case "barrelCount": return $(0, void 0, Math.min(e.players.length, 4));
		case "gambleLoot": return $(0, void 0, void 0, r.slice(0, e.players.length === 1 ? 2 : 4).map((e) => e.uid));
		case "offering": return $(0, t.inventory[0]?.uid);
		case "tripSkills": return $(0, void 0, void 0, t.skills.filter((e) => !ge(t.gearloc, e).counter).slice(0, 3).map(String));
		case "healDuster": return $(0, void 0, void 0, r.filter((e) => [
			"l2",
			"l5",
			"l8",
			"l10",
			"l28"
		].includes(e.card)).map((e) => e.uid));
		case "bogIngredients": return $(0);
		case "goblinBomb": return $(0, "L");
		default: return null;
	}
	if (n.kind === "darts") return n.data.discard ? $(0, t.inventory[0]?.uid) : n.data.setup ? $(0, void 0, 2) : n.data.enemyTurn ? null : n.data.bones ? $(n.data.bones >= 3 ? 4 : n.data.bones >= 2 ? 3 : n.values[4] > 0 ? 1 : n.values[3] > 0 ? 2 : 0) : $(0, void 0, void 0, _n(n, 0).slice(0, n.data["weaken:0"] ?? 0).map((e) => e.id));
	if (n.kind === "barrels") return $();
	if (n.kind === "lanterns") return $(n.values.findIndex((e) => e > 0));
	if (n.kind === "critters" || n.kind === "rubble") {
		if (n.data.deploy) {
			if (n.kind === "rubble" && (n.data.rubblePlaced ?? 0) < e.players.length * 2) return t.owner === e.leader ? {
				type: "deploy",
				pos: n.values.findIndex((e, t) => t < 8 && !e)
			} : null;
			if (t.pos >= 0) return null;
			let r = Array.from({ length: 4 }, (e, r) => (n.kind === "rubble" || t.ranged ? 12 : 8) + r).find((t) => !e.actors.some((e) => e.pos === t));
			return r === void 0 ? null : {
				type: "deploy",
				pos: r
			};
		}
		if (n.data.enemyTurn) return null;
		if (n.kind === "rubble") return $(n.values.indexOf(Math.max(...n.values)));
		if (n.data.critterSelect) {
			let e = n.values.findIndex((e, t) => e > 0 && t % 4 === n.data.lane), t = e >= 0 ? e : n.values.indexOf(Math.min(...n.values.filter((e) => e > 0))), r = n.values.findIndex((e, n) => e > 0 && Y(t, n));
			return $(t, String(r));
		}
		let r = n.values.findIndex((e, n) => e > 0 && (t.ranged || Y(t.pos, n))), i = t.dex - (n.data.moved ?? 0);
		return r >= 0 && i && t.attack ? $(r, void 0, Math.min(t.attack, i)) : $(0, "pass");
	}
	return null;
}
function Ni(e) {
	let t = e.battle, n = t.reactions[0];
	if (n.startsWith("shield:")) {
		let t = R(e, n.slice(7)), r = Object.keys(t.counters).find((e) => e.startsWith("shield:"));
		return {
			type: "ability",
			ability: "reaction",
			amount: Number(r.slice(7)),
			mode: t.locked.length < 3 ? "locked" : t.active.length < 3 ? "active" : "discard"
		};
	}
	if (n.startsWith("prevent:") || n.startsWith("roundOptics:") || n.startsWith("sling:")) return {
		type: "ability",
		ability: "reaction",
		mode: "use"
	};
	if (n.startsWith("retaliate:")) return {
		type: "ability",
		ability: "reaction",
		mode: "both"
	};
	if (n.startsWith("mischief:")) return {
		type: "ability",
		ability: "reaction",
		slot: R(e, n.slice(9)).active[0]?.uid
	};
	if (n.startsWith("riposte:")) return {
		type: "ability",
		ability: "reaction",
		mode: "use"
	};
	if (n === "nomNext" || n === "lineupNext") return {
		type: "ability",
		ability: "reaction",
		target: z(e).find((e) => e.hp > 0 && e.counters.reserve === (n === "nomNext" ? 99 : 98))?.id
	};
	if (n.startsWith("knockback:") || n.startsWith("club:")) return {
		type: "ability",
		ability: "reaction",
		pos: Xt(e, R(e, n.slice(n.indexOf(":") + 1)).pos)[0]
	};
	if (n === "carelessBomb") return {
		type: "ability",
		ability: "reaction",
		target: V(e).find((e) => e.kind === "baddie" && e.hp === t.pendingDamage.bombHp)?.id
	};
	if (n === "charred") {
		let n = V(e).find((e) => e.definition.startsWith("kobold") && e.hp === t.pendingDamage.charredHp);
		if (!n) return null;
		let r = z(e).filter((e) => e.hp > 0 && e.pos >= 0).sort((e, t) => Ai(e.pos, n.pos) - Ai(t.pos, n.pos))[0], i = r && Array.from({ length: 16 }, (e, t) => t).find((t) => Y(t, r.pos) && !e.actors.some((e) => e.hp > 0 && e.pos === t));
		return {
			type: "ability",
			ability: "reaction",
			target: n.id,
			mode: r?.id,
			pos: i
		};
	}
	if (n === "marrowRetreat") return {
		type: "ability",
		ability: "reaction",
		pos: Lt(e, e.actors.find((e) => e.definition === "marrow")).sort((e, t) => Ai(e, 2) - Ai(t, 2))[0]
	};
	if (n === "limitTarget") return {
		type: "ability",
		ability: "reaction",
		target: t.enemyTargets.find((t) => {
			let n = R(e, t);
			return n && n.hp > 0 && [
				"hp",
				"dex",
				"attack",
				"defense"
			].some((e) => n.counters[e + "Training"] > 0 && !n.effects["limited:" + e]);
		})
	};
	if (n.startsWith("limit:")) {
		let t = R(e, n.slice(6));
		return {
			type: "ability",
			ability: "reaction",
			mode: [
				"attack",
				"defense",
				"dex",
				"hp"
			].find((e) => t.counters[e + "Training"] > 0 && !t.effects["limited:" + e])
		};
	}
	return null;
}
function Pi(e, t, n = !0) {
	if (!n || e.phase === "done") return null;
	let r = Ce(e, t), i = e.battle;
	if (e.phase === "recruit") {
		let t = le.find((t) => !z(e).some((e) => e.gearloc === t));
		return t ? {
			type: "chooseGearloc",
			gearloc: t
		} : null;
	}
	if (!r) return null;
	if (e.lock) return e.lock.by === t ? ji(e) : null;
	if (G(r) > 4 && e.phase !== "battle" && e.phase !== "challenge") return {
		type: "loot",
		loot: r.inventory[0].uid,
		mode: "discard"
	};
	if (e.challenge.kind === "scout" || e.challenge.kind === "lootChoice" || e.phase === "challenge") return Mi(e, r);
	if (e.phase === "training") {
		if (!r.training) return { type: "ready" };
		let e = (r.attack < 3 ? [
			"attack",
			"dex",
			"hp",
			"defense"
		] : [
			"dex",
			"attack",
			"hp",
			"defense"
		]).find((e) => !r.failedTraining.includes(e) && r.counters[e + "Training"] < 5);
		if (e) return {
			type: "train",
			stat: e
		};
		let t = gt(r)[0];
		return t ? {
			type: "train",
			stat: "skill",
			skill: t
		} : null;
	}
	if (e.phase === "day") return $(+(e.progress >= re[e.config.tyrant].progress));
	if (e.phase === "encounter") {
		let t = +!![
			"g3",
			"g4",
			"g9",
			"g13",
			"g17",
			"g21",
			"g24",
			"o3",
			"o7",
			"t6"
		].includes(e.encounter ?? "");
		return e.encounter === "t8" && (t = 1), e.encounter === "o7" && !r.inventory.length && (t = 0), e.encounter === "o5" && e.persistent["today:blocked:o5:0"] && (t = 1), $(t, r.id);
	}
	if (e.phase === "recovery") return r.recovery.length ? { type: "ready" } : {
		type: "recover",
		option: "rest"
	};
	if (!i) return null;
	if (i.reactions.length) return Ni(e);
	if (i.stage === "deployment") {
		let t = Nt(e, r)[0];
		return t === void 0 ? null : {
			type: "deploy",
			pos: t
		};
	}
	if (i.flags.includes("orderPending")) return { type: "ready" };
	let a = R(e, i.turn ?? "");
	if (!a) return null;
	if (i.startEffects.length) {
		let t = i.startEffects[0], n = a.id, r;
		if (t === "dive") {
			let t = z(e).filter((e) => e.hp > 0 && e.pos >= 0 && !e.effects.untargetable).sort((e, t) => e.hp - t.hp);
			n = t[0]?.id, r = Array.from({ length: 16 }, (e, t) => t).find((n) => t[0] && Y(n, t[0].pos, a.diagonal) && !e.actors.some((e) => e.hp > 0 && e.pos === n));
		}
		return {
			type: "ability",
			ability: "startEffect",
			mode: t,
			target: n,
			pos: r
		};
	}
	if (i.stage === "enemyTarget") return {
		type: "ability",
		ability: "target",
		target: zt(e, a)[0]?.id
	};
	if (i.stage === "enemyMove") {
		let t = R(e, i.target ?? ""), n = t && Bt(e, a, t)[0];
		return n === void 0 ? null : {
			type: "move",
			pos: n
		};
	}
	if (a.kind === "ally" && i.stage === "move") {
		let t = V(e).filter((t) => Dt(e, a, t)).sort((e, t) => e.hp - t.hp)[0];
		if (t) return {
			type: "ability",
			ability: "allyAttack",
			target: t.id
		};
		let n = Lt(e, a).sort((t, n) => Math.min(...V(e).map((e) => Ai(t, e.pos))) - Math.min(...V(e).map((e) => Ai(n, e.pos))));
		return i.spent < 2 && n.length ? {
			type: "ability",
			ability: "allyMove",
			pos: n[0]
		} : {
			type: "ability",
			ability: "allyEnd"
		};
	}
	if (a !== r || !["move", "resolve"].includes(i.stage)) return null;
	if (De(r) >= 6 && !i.backupUsed && !r.upgraded && !i.modifiers.noBackup) return {
		type: "backup",
		cost: 6
	};
	let o = V(e).filter((t) => Dt(e, r, t)).sort((e, t) => e.hp - t.hp);
	if (i.stage === "move") {
		let t = nt(r) - i.spent;
		if (!o.length && !r.ranged && t > Tt(e)) {
			let t = Lt(e, r), n = V(e);
			if (t.sort((e, t) => Math.min(...n.map((t) => Ai(e, t.pos))) - Math.min(...n.map((e) => Ai(t, e.pos)))), t[0] !== void 0) return {
				type: "move",
				pos: t[0]
			};
		}
		let n = o.length ? Math.min(tt(r, "attack"), t) : 0, a = Math.min(tt(r, "defense"), Math.max(0, t - n), Math.max(0, 3 - r.active.length));
		i.modifiers.noDefense && (a = 0), (i.modifiers.defenseOnly >= i.round || i.modifiers.meleeDefenseOnly >= i.round && !r.ranged) && (n = 0, a = Math.min(tt(r, "defense"), t, Math.max(0, 3 - r.active.length))), i.modifiers.skillOnly >= i.round && (n = 0, a = 0);
		let s = [];
		return !(i.modifiers.defenseOnly >= i.round || i.modifiers.meleeDefenseOnly >= i.round && !r.ranged) && r.gearloc === "patches" && r.hp < r.maxHp && t > n + a && Oe(e, r, 1) && r.active.length < 3 && s.push(1), n + a + s.length ? {
			type: "roll",
			attack: n,
			defense: a,
			skills: s,
			target: o[0]?.id ?? null
		} : { type: "endTurn" };
	}
	let s = i.rolled.filter((e) => !e.used && e.kind === "attack" && e.face.startsWith("attack:"));
	if (s.length && R(e, i.target ?? "")?.hp && Dt(e, r, R(e, i.target))) return {
		type: "resolve",
		dice: s.map((e) => e.uid),
		mode: "use"
	};
	let c = i.rolled.find((e) => !e.used);
	if (c) {
		let e = _e(c.face)[0];
		return [
			"bones",
			"forcedBones",
			"reusableBones"
		].includes(e.kind) ? {
			type: "resolve",
			dice: [c.uid],
			mode: "bones"
		} : e.kind === "defense" && r.active.length < 3 ? {
			type: "resolve",
			dice: [c.uid],
			mode: "active"
		} : e.kind === "heal" || c.skill && r.gearloc && ge(r.gearloc, c.skill).grenade ? {
			type: "resolve",
			dice: [c.uid],
			mode: "use",
			target: r.id
		} : {
			type: "resolve",
			dice: [c.uid],
			mode: "discard"
		};
	}
	if (!i.backupUsed && !i.modifiers.noBackup) {
		if (r.gearloc === "tantrum" && De(r) >= 5 && r.hp < r.maxHp) return {
			type: "backup",
			cost: 5
		};
		if (r.gearloc === "patches" && De(r) >= 2 && r.hp < r.maxHp) return {
			type: "backup",
			cost: 2,
			target: r.id
		};
		if (r.gearloc === "picket" && De(r) >= 2 && H(r, "defense") && i.target && o.some((e) => e.id === i.target)) return {
			type: "backup",
			cost: 2,
			target: i.target
		};
		if (r.gearloc === "boomer" && De(r) && i.target && o.some((e) => e.id === i.target)) return {
			type: "backup",
			cost: 1,
			target: i.target
		};
	}
	return { type: "endTurn" };
}
var Fi = (e, t) => {
	let n = Pi(e.public, t.rid, !!e.private?.canAct);
	return n ? { action: n } : null;
};
//#endregion
//#region src/game/fx.tsx
function Ii({ id: e }) {
	let t = Xn[e];
	return /* @__PURE__ */ b("div", {
		className: "tmb-fx-figure",
		children: t ? /* @__PURE__ */ b("img", {
			src: t,
			alt: ""
		}) : /* @__PURE__ */ b(Qn, { kind: "defense" })
	});
}
var Li = { tmbBattleBeat(e, t) {
	let n = e.data, r = t.queued ? 210 : 490, i = [], a = (e) => t.anchor(`tmb:cell:${e}`), o = t.anchor("tmb:tray"), s = n.travel.flatMap(({ id: e, figure: n, from: s }) => {
		let c = t.anchor(`tmb:chip:${e}`), l = s >= 0 ? a(s) : o;
		return !c || !l ? [] : (t.queued || i.push(`tmb:chip:${e}`), /* @__PURE__ */ b(D, {
			from: l,
			to: c,
			ms: r,
			children: /* @__PURE__ */ b(Ii, { id: n })
		}, e));
	}), c = n.life.flatMap(({ pos: e, change: t }, n) => {
		let i = a(e);
		return i ? /* @__PURE__ */ x("div", {
			"data-tmb-fx": "life",
			"data-change": t,
			children: [/* @__PURE__ */ b(O, {
				at: i,
				ms: r
			}), /* @__PURE__ */ b(E, {
				at: {
					...i,
					y: i.y + i.h * .34
				},
				ms: r,
				children: /* @__PURE__ */ x("span", {
					className: "tmb-fx-life",
					"data-heal": t > 0 || void 0,
					children: [
						t > 0 ? "+" : "−",
						Math.abs(t),
						" ♥"
					]
				})
			})]
		}, n) : [];
	}), l = n.removed.flatMap(({ id: e, figure: o, pos: s }, c) => {
		let l = a(s);
		return l && n.closesBattle && t.anchor(`tmb:chip:${e}`) && i.push(`tmb:chip:${e}`), l ? /* @__PURE__ */ b("div", {
			className: "tmb-fx-fallen",
			"data-tmb-fx": "ko",
			style: {
				left: l.x,
				top: l.y,
				width: l.w,
				height: l.h,
				animationDuration: `${r}ms`
			},
			children: /* @__PURE__ */ b(Ii, { id: o })
		}, c) : [];
	}), u = o ?? (n.turn === null ? null : a(n.turn)), d = u && n.dice.length > 0 && /* @__PURE__ */ b("div", {
		className: "tmb-fx-roll",
		"data-tmb-fx": "roll",
		style: {
			left: u.x,
			top: u.y,
			width: u.w,
			height: u.h
		},
		children: n.dice.map((e, t) => /* @__PURE__ */ b("span", {
			className: "tmb-fx-die",
			"data-face": e,
			style: { animationDuration: `${r}ms` },
			children: /* @__PURE__ */ b(Mr, { face: e })
		}, t))
	}), f = n.gained.flatMap(({ pos: e, lane: n, face: i, seat: s }, c) => {
		let l = s === t.myRid ? t.anchor(`tmb:slot:${n}`) : a(e), u = o ?? a(e);
		return !u || !l ? [] : /* @__PURE__ */ b(D, {
			from: u,
			to: l,
			ms: r,
			children: /* @__PURE__ */ b("span", {
				className: "tmb-fx-die",
				"data-tmb-fx": n,
				"data-face": i,
				children: /* @__PURE__ */ b(Mr, { face: i })
			})
		}, c);
	});
	return s.length || c.length || l.length || d || f.length ? {
		ms: r,
		hide: i,
		node: /* @__PURE__ */ x("div", {
			className: "tmb-fx-scene",
			"data-tmb-fx": "beat",
			children: [
				s,
				c,
				l,
				d,
				f
			]
		})
	} : null;
} };
//#endregion
//#region src/game/endgame-review.tsx
function Ri({ board: e, renderResult: t, ...n }) {
	let s = c(), [u, d] = o(!0), [f, m] = o(null), g = a(null), _ = a(null), v = a(null);
	r(() => {
		if (!f) return;
		v.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => m(null), 5e3);
		return () => clearTimeout(e);
	}, [f]);
	let y = (e) => {
		m(null), d(e), requestAnimationFrame(() => (e ? g : _).current?.focus({ preventScroll: !0 }));
	}, S = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => m({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => m({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => m({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), C = {
		...n,
		...S
	};
	return /* @__PURE__ */ x("div", {
		className: "toomanybones-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ b("div", {
				className: "toomanybones-endgame-board",
				inert: u,
				children: e
			}),
			/* @__PURE__ */ b("div", {
				className: "toomanybones-endgame-overlay",
				hidden: !u,
				children: /* @__PURE__ */ x("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), y(!1));
					},
					className: "toomanybones-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ x("header", {
							className: "toomanybones-endgame-heading",
							children: [/* @__PURE__ */ b("div", {
								className: "toomanybones-endgame-brand",
								children: s("games.toomanybones.flowReport")
							}), /* @__PURE__ */ b("button", {
								type: "button",
								ref: g,
								className: "btn-quiet",
								"aria-label": s("games.toomanybones.reviewHide"),
								title: s("games.toomanybones.reviewHide"),
								onClick: () => y(!1),
								children: /* @__PURE__ */ b(p, { size: 19 })
							})]
						}),
						/* @__PURE__ */ b("div", {
							className: "toomanybones-endgame-result",
							inert: f !== null,
							children: t(C)
						}),
						f && /* @__PURE__ */ x("div", {
							className: "toomanybones-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || m(null);
							},
							children: [/* @__PURE__ */ b("button", {
								type: "button",
								ref: v,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = f.run;
									m(null), e();
								},
								children: s(f.label === "again" ? "games.toomanybones.reviewConfirmAgain" : "games.toomanybones.reviewConfirmLobby")
							}), /* @__PURE__ */ b("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									m(null), g.current?.focus({ preventScroll: !0 });
								},
								children: s("games.toomanybones.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ b("div", {
				className: "toomanybones-endgame-toolbar",
				hidden: u,
				children: /* @__PURE__ */ x("button", {
					type: "button",
					className: "btn-base",
					ref: _,
					onClick: () => y(!0),
					children: [
						/* @__PURE__ */ b(h, { size: 18 }),
						s("games.toomanybones.reviewShow"),
						/* @__PURE__ */ b(l, { size: 18 })
					]
				})
			})
		]
	});
}
function zi({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: l, rows: d, renderRowExtra: f, summary: m, navigation: h, content: g, afterRanking: _, scoreUnit: v, rankOf: S }) {
	let w = c(), T = s((e) => e.locale), [ee, E] = o({}), D = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? C(n, T) : e;
	}, O = (t, n) => S?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), k = e.ranking.some((t) => e.scores?.[t] !== void 0), ne = (t, n) => /* @__PURE__ */ x("div", {
		className: "toomanybones-score-identity",
		children: [
			/* @__PURE__ */ x("span", {
				className: "toomanybones-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ b("span", {
					"aria-label": w("games.toomanybones.reviewWinner"),
					children: "♛ "
				}), k && O(t, n)]
			}),
			/* @__PURE__ */ x("span", {
				className: "toomanybones-score-name",
				children: [D(t), t === r && /* @__PURE__ */ b("small", { children: w("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ x("small", {
				className: "toomanybones-score-autopilot",
				children: [
					/* @__PURE__ */ b(u, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), re = (t) => e.ranking.map((n) => /* @__PURE__ */ b("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ x("div", {
		className: "toomanybones-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ b(te, {}),
			h,
			/* @__PURE__ */ x("div", {
				className: "toomanybones-score-body",
				children: [
					m && /* @__PURE__ */ b("div", {
						className: "toomanybones-score-summary",
						children: m
					}),
					i !== void 0 && /* @__PURE__ */ b("p", {
						className: "toomanybones-score-hints",
						children: w("session.hint.usedCount", { n: i })
					}),
					g ?? (d?.length ? /* @__PURE__ */ b("div", {
						className: "toomanybones-score-table-scroll",
						children: /* @__PURE__ */ x("table", {
							className: "toomanybones-score-table",
							"aria-label": w(Un.nameKey),
							children: [
								/* @__PURE__ */ b("thead", { children: /* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ b("th", { scope: "col" }), /* @__PURE__ */ b(y, { children: e.ranking.map((t, n) => /* @__PURE__ */ b("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: ne(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ b("tbody", { children: d.map((e, t) => /* @__PURE__ */ x(n, { children: [/* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ b("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ x("button", {
										type: "button",
										"aria-expanded": !!ee[t],
										onClick: () => E((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ b(p, { size: 15 }), e.label]
									}) : e.label
								}), re(e)] }), ee[t] && e.details?.map((e, t) => /* @__PURE__ */ x("tr", {
									className: "toomanybones-score-sub",
									children: [/* @__PURE__ */ b("th", {
										scope: "row",
										children: e.label
									}), re(e)]
								}, t))] }, t)) }),
								k && /* @__PURE__ */ b("tfoot", { children: /* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ b("th", {
									scope: "row",
									children: w("games.toomanybones.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ b("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ b("ol", {
						className: "toomanybones-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ x("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ x("div", {
								className: "toomanybones-score-rankline",
								children: [ne(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ x("strong", {
									className: "toomanybones-score-points",
									children: [e.scores[t], v && /* @__PURE__ */ b("small", { children: v })]
								})]
							}), f?.(t)]
						}, t))
					})),
					_,
					!!d?.length && f && /* @__PURE__ */ b("div", {
						className: "toomanybones-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ x("details", { children: [/* @__PURE__ */ b("summary", { children: D(e) }), f(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ x("footer", {
				className: "toomanybones-score-actions",
				children: [
					l && /* @__PURE__ */ b("button", {
						type: "button",
						className: "btn-quiet",
						onClick: l,
						children: w("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ b("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: w("session.result.playAgain")
					}),
					!a && !l && /* @__PURE__ */ b("p", { children: w("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/game/game-over.tsx
function Bi(e) {
	let t = c(), n = s((e) => e.locale), r = e.public, i = re[r.config.tyrant], a = r.outcome === "win";
	return /* @__PURE__ */ b(zi, {
		...e,
		accent: "#ad7062",
		summary: /* @__PURE__ */ x("section", {
			className: "tmb-flow-paper tmb-flow-stack toomanybones-report-summary",
			children: [/* @__PURE__ */ x("div", {
				className: "tmb-flow-identity",
				children: [/* @__PURE__ */ b(vi, { id: r.config.tyrant }), /* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("h2", { children: t(a ? "games.toomanybones.flowVictory" : "games.toomanybones.flowDefeat") }), /* @__PURE__ */ b("p", { children: t(a ? "games.toomanybones.flowTyrantDefeated" : "games.toomanybones.flowTyrantUnbeaten", { name: t(or[r.config.tyrant]) }) })] })]
			}), /* @__PURE__ */ x("div", {
				className: "toomanybones-report-metrics",
				children: [/* @__PURE__ */ b("b", { children: t("games.toomanybones.flowLastDay", {
					n: Math.min(r.day, i.days),
					total: i.days
				}) }), /* @__PURE__ */ b("b", { children: t("games.toomanybones.flowProgress", {
					n: r.progress,
					total: i.progress
				}) })]
			})]
		}),
		content: /* @__PURE__ */ x("section", {
			className: "toomanybones-report-party",
			children: [/* @__PURE__ */ b("h3", { children: t("games.toomanybones.flowParty") }), /* @__PURE__ */ b("ul", { children: r.players.map((i) => {
				let a = e.members.find((e) => e.rid === i), o = r.actors.find((e) => e.gearloc && e.owner === i);
				return /* @__PURE__ */ x("li", { children: [
					/* @__PURE__ */ b(yi, { member: a }),
					/* @__PURE__ */ b("b", { children: a ? C(a, n) : o ? Er(t, o).split(" · ")[0] : t("games.toomanybones.wait") }),
					o?.gearloc && /* @__PURE__ */ x("span", { children: [/* @__PURE__ */ b(vi, { id: o.gearloc }), Er(t, o).split(" · ")[0]] })
				] }, i);
			}) })]
		})
	});
}
function Vi(e) {
	return /* @__PURE__ */ b(Ri, {
		...e,
		board: /* @__PURE__ */ b(Di, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ b(Bi, { ...e })
	});
}
//#endregion
//#region src/game/options.tsx
function Hi({ value: e, onChange: t }) {
	let n = c(), r = jn.safeParse(e), i = r.success ? r.data : jn.parse(void 0);
	return /* @__PURE__ */ x("div", {
		className: "tmb-options",
		children: [/* @__PURE__ */ x("fieldset", { children: [/* @__PURE__ */ b("legend", { children: n("games.toomanybones.tyrant") }), /* @__PURE__ */ b("div", {
			className: "tmb-tyrant-cards",
			children: Object.keys(or).map((e) => /* @__PURE__ */ x("label", {
				className: "tmb-tyrant-card",
				children: [
					/* @__PURE__ */ b("input", {
						type: "radio",
						name: "tmb-tyrant",
						value: e,
						checked: i.tyrant === e,
						onChange: () => t({
							...i,
							tyrant: e
						})
					}),
					/* @__PURE__ */ b("img", {
						alt: "",
						src: Xn[e]
					}),
					/* @__PURE__ */ b("strong", { children: n(or[e]) }),
					/* @__PURE__ */ x("small", { children: [
						n("games.toomanybones.flowDeadline", { n: re[e].days }),
						/* @__PURE__ */ b("br", {}),
						n("games.toomanybones.flowRequiredProgress", { n: re[e].progress })
					] })
				]
			}, e))
		})] }), /* @__PURE__ */ x("fieldset", { children: [/* @__PURE__ */ b("legend", { children: n("games.toomanybones.difficulty") }), /* @__PURE__ */ b("div", {
			className: "tmb-difficulty-cards",
			children: [
				"adventurer",
				"heroic",
				"legendary"
			].map((e) => /* @__PURE__ */ x("label", {
				className: "tmb-tyrant-card tmb-difficulty-card",
				children: [
					/* @__PURE__ */ b("input", {
						type: "radio",
						name: "tmb-difficulty",
						value: e,
						checked: i.difficulty === e,
						onChange: () => t({
							...i,
							difficulty: e
						})
					}),
					/* @__PURE__ */ b("strong", { children: n(e === "adventurer" ? "games.toomanybones.adventurer" : e === "heroic" ? "games.toomanybones.heroic" : "games.toomanybones.legendary") }),
					/* @__PURE__ */ b("small", { children: n("games.toomanybones.trainingPoints", { n: e === "legendary" ? 0 : 1 }) })
				]
			}, e))
		})] })]
	});
}
//#endregion
//#region src/game/guide.tsx
function Ui() {
	return /* @__PURE__ */ b(ai, {});
}
//#endregion
//#region src/game/locales/encounters.ts
var Wi = {
	s1: ["① 最后训练：每人获得2个训练点。\n② 敲诈商贩：每人获得1个训练点，抽2张普通战利品并保留1张。", "1. Last-minute improvement: each Gearloc gains 2 training points.\n2. Shady peddler: each gains 1 training point; draw 2 Loot each and keep 1."],
	s2: ["① 向守卫求助：进行标准战斗，每轮开始箭雨对每名敌人造成1点真实伤害。\n② 展示实力：进行标准战斗，额外获得1个训练点。失败则把本遭遇放回牌堆顶。", "1. Hail the guards: standard BQ; arrows deal 1 True Damage to every baddie at each round start.\n2. Show Obendar: standard battle; gain an extra training point. On either loss, return this Encounter to the top."],
	s3: ["① 伪装平民：每人投六面骰；出现1或2，将牌堆中第一张暴君遭遇放到顶端。额外获得1进度和1训练点。\n② 雇用莫尔诺：每人获得1张珍宝，将特殊遭遇006洗入牌堆。", "1. Walk like a commoner: roll a D6 per member; any 1–2 moves the first Tyrant Encounter to the top. Gain 1 extra progress and training.\n2. Hire the Mohlnor: gain a Trove Loot each; shuffle Special 006 into the deck."],
	s4: ["① 逃跑：投六面骰；1–3时每人受到2伤害，4–6时全队弃置1张战利品。将本牌洗回牌堆，另抽今天的遭遇。\n② 迎战：标准敌人队列末尾增加一名20点敌人，入场时增加3生命。成功获得2进度、2训练点和每人1珍宝。", "1. Duck and cover: D6 1–3 deals 2 Damage to each member; 4–6 discards 1 party Loot. Reshuffle this card and draw another today.\n2. Fight: standard BQ plus a 20Pt at the bottom with +3 starting HP. Earn 2 progress, 2 training and a Trove each."],
	s5: ["① 珍宝室：每人抽1珍宝，可以弃置再抽1张且必须保留，随后可立即尝试开锁。获得1训练点。\n② 作战室：获得2训练点，这次攻击与防御训练忽略全部骨头。", "1. Trove room: each draws a Trove, may discard and redraw once, then may immediately attempt lockpicking. Gain 1 training.\n2. War room: gain 2 training; these Attack and Defense training attempts ignore all Bones."],
	s6: ["① 飞镖挑战：每人参赛；胜者抽2战利品，败者弃置1战利品。本遭遇洗回牌堆。\n② 拒绝游戏：标准战斗，开战时每人受到等于队伍人数的伤害。失败洗回本遭遇。", "1. Dangerous Darts: each competes; winners draw 2 Loot, losers discard 1 if able. Reshuffle this Encounter.\n2. No more games: standard BQ; each takes party-size Damage at battle start. Reshuffle this card on failure."],
	g1: ["① 对抗沼泽生物：敌人点数增加3（1–2人）或6（3–4人），尽可能使用沼泽类。额外1进度。\n② 穿过沼泽：标准战斗；每人投六面骰，当前生命不大于结果则以中毒2开始战斗。", "1. Fight bog creatures: add 3 Baddie Points (1–2 players) or 6 (3–4); use as many Bog baddies as possible. Extra 1 progress.\n2. Wade through: standard BQ; each rolls D6. Current HP must exceed it or start with Poison 2."],
	g2: ["① 对抗巨龙：标准队列顶增加一条5点龙（1–2人）或20点龙（3–4人）。击败20点龙后洗入特殊遭遇005。额外1训练点。\n② 低头前进：标准战斗；每轮开始所有角色受到1点真实伤害。", "1. Fight the dragon: add a 5Pt dragon (1–2 players) or 20Pt dragon (3–4) atop standard BQ. Defeat a 20Pt dragon to shuffle Special 005 in. Extra 1 training.\n2. Keep heads down: all Gearlocs take 1 True Damage each round start."],
	g3: ["① 迎战：每有一名初始生命至少5的敌人入场，向队列末尾增加一名1点敌人。额外2训练点。\n② 虚张声势：先抽1珍宝，指定角色尝试开锁一次；失败弃置，成功保留。然后进行标准战斗。", "1. Have fun: whenever a baddie with at least 5 HP enters, add a 1Pt baddie to the bottom. Extra 2 training.\n2. Call the bluff: draw a Trove and let one Gearloc attempt its locks; keep if opened, otherwise discard. Then standard battle."],
	g4: ["① 解开脚镣：全队依次尝试3机关、4绊线、5蛮力、2绊线锁，进度共享。开锁数至少等于人数则获得突袭；否则每人受2伤害并改选②。\n② 负手作战：本场忽略攻击训练属性。", "1. Escape: attempt shared locks 3L–4T–5F–2T in party order. Open at least party-size locks for Surprise; otherwise each takes 2 Damage and must choose option 2.\n2. Hands tied: ignore trained Attack stats for this battle."],
	g5: ["① 放走蜥蜴：和平成功。\n② 救它：标准队列顶增加两名1点敌人（1–2人）或两名5点敌人（3–4人），全队突袭；额外1训练点和每人1战利品。", "1. Back away: peaceful success.\n2. Save the lizard: add two 1Pt baddies (1–2 players) or two 5Pt (3–4) atop BQ; party has Surprise. Extra training and Loot each."],
	g6: ["① 沼泽：每人敏捷上限3；每轮开始投六面骰，1–3时全队受1真实伤害。\n② 林间路：每人开战前可投全部防御骰，骨头弃置；远程敌人每次多投1攻击骰。", "1. Bog: cap Dex at 3; D6 at round start, 1–3 deals 1 True Damage to all Gearlocs.\n2. Quiet path: roll Defense dice before battle, discarding Bones; ranged baddies roll +1 Attack."],
	g7: ["① 单列：双方只能使用第一路线，先填近战格再填远程格，禁止移动；额外1进度。\n② 挣扎：每人敏捷减少1；每回合首次移动前投六面骰，1–3则本回合不能移动；额外1训练点。", "1. Single file: use Lane 1 only, melee before ranged, no movement. Extra progress.\n2. Struggle: each loses 1 Dex; before moving, D6 1–3 prevents movement that turn. Extra training."],
	g8: ["① 充当沙包：队列顶增加一名5点敌人（1–2人）或两名5点敌人（3–4人）；每人额外2战利品。\n② 穿上战靴：敌人点数减少2；全队额外1战利品。", "1. Punching bags: add one 5Pt (1–2 players) or two 5Pt (3–4) atop BQ. Extra 2 Loot each.\n2. Boots: subtract 2 Baddie Points; extra 1 party Loot."],
	g9: ["① 狙击：指定角色投任意数量攻击骰；总伤害至少2则敌人点数减少2，否则改选②。本场减少该角色等量攻击骰。额外每人1战利品。\n② 放行：第2–5轮开始各向队列末尾增加1点敌人。", "1. Snipe: one Gearloc rolls any number of Attack dice; 2+ Damage subtracts 2 Baddie Points, otherwise choose option 2. Rolled dice are unavailable this battle. Extra Loot each.\n2. Let go: add a 1Pt baddie at the start of rounds 2–5."],
	g10: ["选择1–6并投六面骰。结果大于选择值：抽等量战利品；否则敌人点数增加选择值。随后战斗。", "Choose 1–6 and roll D6. Above the choice draws that many Loot; otherwise add the chosen number to Baddie Points. Then battle."],
	g11: ["① 正面冲锋：必须消灭全部近战敌人后，才能选远程敌人为目标。\n② 保持距离：前两轮近战角色只能投防御骰。", "1. Charge: defeat all melee baddies before targeting ranged baddies.\n2. Keep distance: melee Gearlocs may only roll Defense dice in rounds 1–2."],
	g12: ["① 追逐闪光：敌人点数增加6（1–2人）或12（3–4人）；全队额外2珍宝。\n② 不拒绝蛋糕：全队获得突袭。", "1. Shiny: add 6 Baddie Points (1–2 players) or 12 (3–4); extra 2 party Troves.\n2. Cake: party has Surprise."],
	g13: ["① 贿赂：全队弃置与人数相同的战利品；洗入特殊遭遇006，和平成功。\n② 旋风测试：指定一名角色在5轮内击破四个不行动的目标，生命依次3、5、4、4；额外每人1战利品。", "1. Bribe: discard party-size Loot; shuffle Special 006 in; peaceful success.\n2. Whirlwind: one Gearloc has 5 rounds to defeat four stationary non-attacking figures with 3, 5, 4, 4 HP. Extra Loot each."],
	g14: ["① 跟踪伏击：先战两名5点敌人；获胜后再战标准敌人点数减8。必须两战皆胜。\n② 黄昏进攻：投两次六面骰，将总和加到敌人点数；全队获得突袭。额外1训练点。", "1. Follow: fight two 5Pt baddies, then standard Baddie Points minus 8; must win both.\n2. Dusk: add the sum of two D6 to Baddie Points; party has Surprise. Extra training."],
	g15: ["① 设置陷阱：队列顶增加两名1点敌人（1–2人）或两名5点敌人（3–4人）；敌人入场失去2生命。\n② 吹响号角：顶增两名1点及一名5点（1–2人），或三名5点（3–4人）；成功后可选全部恢复项目。额外每人1珍宝。", "1. Traps: add two 1Pt (1–2 players) or two 5Pt (3–4) atop BQ; baddies lose 2 HP on entry.\n2. Horn: add two 1Pt and a 5Pt (1–2) or three 5Pt (3–4); on success choose all recovery options. Extra Trove each."],
	g16: ["① 拆弹：敌人获得突袭；指定角色尝试4机关、3绊线锁。失败则改选②且仍保留敌方突袭。额外1训练点。\n② 中计：投六面骰，当前生命最接近结果的角色失去3生命；平手由全队选择。", "1. Disarm: baddies have Surprise; one Gearloc attempts 4L–3T. Failure forces option 2, retaining baddie Surprise. Extra training.\n2. Trap: D6; the Gearloc with HP closest to the result loses 3 HP, party breaks ties."],
	g17: ["① 单挑：队列首名敌人与指定角色先战3轮，或直至一方倒下，其余单位再加入。\n② 一拥而上：敌人点数增加4（1–2人）或8（3–4人）。", "1. Duel: the first baddie faces one chosen Gearloc for 3 rounds or until either falls, then others join.\n2. Take him: add 4 Baddie Points (1–2 players) or 8 (3–4)."],
	g18: ["① 深入洞穴：每名角色增加一名5点敌人在队列末尾，额外1珍宝。\n② 清哨兵：敌人点数增加6，再每人增加一名1点敌人在末尾，额外1训练点。\n③ 侦察返回：揭示两名敌人，可放至各自牌堆底；本牌放回顶端，没有遭遇奖励。", "1. Rabbit hole: add a 5Pt per Gearloc to BQ bottom; extra Trove.\n2. Sentries: add 6 points, then a 1Pt per Gearloc to BQ bottom; extra training.\n3. Scout: reveal two baddies, optionally cycle; return this card to top, no rewards."],
	g19: ["① 棍石作战：不能使用技能骰，投出的每个骨头计作2个。\n② 寻找窃贼：第一路线的首名敌人倒下前，不能使用技能骰。", "1. Sticks and stones: no skill dice; each rolled Bone counts as two.\n2. Find thieves: no skill dice until the first baddie in Lane 1 is defeated."],
	g20: ["① 当场作战：整场不能使用防御骰。\n② 躲入树林：前两轮只能投防御骰。", "1. Fight now: no Defense dice this battle.\n2. Woods: roll only Defense dice for the first two rounds."],
	g21: ["① 四散奔逃：顶增一名20点敌人；全队共同耗尽1–6颗攻击及防御骰。每轮六面骰不大于耗尽数时眩晕该敌人。成功洗入特殊遭遇005。额外1训练点和每人1珍宝。\n② 逃跑：开战前每人受到2伤害。", "1. Scatter: add a 20Pt atop BQ; exhaust the same chosen 1–6 Attack/Defense dice per Gearloc. Each round, D6 at or below the total stuns that 20Pt. On success shuffle Special 005 in; extra training and Trove each.\n2. Run: each takes 2 Damage before battle."],
	g22: ["① 藏宝图：顶增一名20点敌人；额外1训练点和每人1珍宝。\n② 火攻：顶增一名20点敌人；每轮结束所有敌人受到2真实伤害；额外1训练点。任一选项成功均洗入特殊遭遇005。", "1. Map: add a 20Pt atop BQ; extra training and Trove each.\n2. Fire: add a 20Pt atop BQ; all baddies take 2 True Damage each round end; extra training. Either success shuffles Special 005 in."],
	g23: ["① 箭矢弹射：指定角色有4次弹射机会，每路线各一次。至少命中3个树目标，且目标不能被撞离桌面；获得1进度和2训练点。\n② 飞镖：每人挑战，至少一人胜利才获得1进度；胜者各获得1战利品。洗入特殊遭遇006。", "1. Flick arrows: one Gearloc has 4 shots, one per lane. Hit at least 3 tree targets without knocking them off the table; earn 1 progress and 2 training.\n2. Darts: each competes; any win earns 1 progress, each winner gains Loot. Shuffle Special 006 in."],
	g24: ["① 开锁挑战：找到至少有一道难度5的珍宝，全队依次尝试，已打开的锁保留；全部打开才成功，获得每人2战利品及1珍宝。\n② 飞镖：每人挑战，至少一人胜利获得1进度，胜者各1战利品。", "1. Locks: find a Trove with a lock difficulty at least 5; each attempts, opened locks persist. Fully open to succeed; extra 2 Loot and a Trove each.\n2. Darts: each competes; any win earns 1 progress, each winner gains Loot."],
	g25: ["老鼠数量为人数加1，各投六面骰决定生命。每名角色可正常行动1回合；消灭至少全部减一只即成功，若全部消灭，再洗入特殊遭遇004。", "Face party-size plus 1 rats, each with D6 HP. Each Gearloc gets one normal battle turn. Kill all but one to succeed; killing all shuffles Special 004 in."],
	g26: ["① 珍宝箱：指定角色尝试打开新珍宝，成功保留，失败弃置；遭遇始终成功。\n② 木桶：选择1–4桶，投六面骰决定各自生命，由强到弱排列。每人投全部攻击骰，只攻击最强的一桶；每打破一桶，全队获得1战利品，遭遇始终成功。", "1. Trove: one Gearloc attempts a new Trove; keep if opened, discard otherwise. Encounter always succeeds.\n2. Barrels: choose 1–4, roll D6 HP each, strongest first. Each Gearloc rolls all Attack against one barrel. Gain 1 party Loot per destroyed barrel; always succeeds."],
	g27: ["每人投六面骰生成一盏灯的距离。每人选择一盏灯投自己的先攻骰，结果不小于距离则熄灭；每熄灭一盏，全队获得1战利品。遭遇始终成功。", "Roll D6 per Gearloc for lantern distances. Each chooses a lantern and rolls their Initiative die; meet its distance to extinguish it. Each extinguished lantern grants party Loot. Always succeeds."],
	g28: ["放置角色，其余格各1生命小动物。动物先行动，随后与角色交替；六面骰决定路线，5视作1、6视作2。动物堆叠相邻动物，否则离场。角色只用攻击与敏捷追捕，必须一击击败，否则目标逃跑；捕获生命作为下一战临时生命。", "Deploy Gearlocs; fill other positions with 1HP critters. Critters act first, alternating with Gearlocs. D6 selects lane (5→1, 6→2); a critter stacks onto an adjacent critter or leaves. Hunt with Attack and Dex only; kill in one attempt or it escapes. Captured HP becomes next-battle Buff HP."],
	g29: ["每人放置两堆3生命碎石于敌方区域，角色处于远程起始格。每人可投掷两次炸药：选任意格投2攻击骰，对目标格造成全部伤害、相邻格造成一半伤害向下取整。清除全部碎石才成功。", "Place two 3HP rubble piles per Gearloc on baddie positions and Gearlocs at ranged starts. Each has two explosives: roll 2 Attack at any position; full Damage there, half rounded down to adjacent positions. Clear all rubble to succeed."],
	g30: ["全队交出最多4战利品，每张投六面骰；单人每张投2颗。总和0失去1进度；1–6获1进度1训练；7–12获1进度2训练；13–18再获1珍宝；19以上再获2珍宝。", "Pay up to 4 party Loot, rolling D6 each (two per Loot solo). Total 0 loses 1 progress; 1–6 earns 1 progress/1 training; 7–12 earns 1 progress/2 training; 13–18 also gains 1 Trove; 19+ also gains 2 Troves."],
	o1: ["① 排队作战：标准点数加2，只用第一路线，一次只对抗一名敌人；额外2战利品。\n② 切断吊桥：揭示标准队列，每名远程敌人投2攻击骰并失去等量生命；存活即成功。", "1. Line up: Baddie Points +2, Lane 1 only, one baddie at a time; extra 2 Loot.\n2. Cut the bridge: reveal standard BQ; roll 2 Attack for each ranged baddie and lose that much HP. Survive to succeed."],
	o2: ["① 空地迎战：标准点数加2，远程敌人在先攻最顶端；额外1进度和1训练点。\n② 爬上绳索：标准点数加2，己方突袭，敌人第一轮不能移动；额外1训练点。", "1. Open air: points +2; ranged baddies start atop initiative; extra progress and training.\n2. Climb: points +2; Surprise and baddies cannot move in round 1; extra training."],
	o3: ["① 立即作战：只对抗一名5点魔像。\n② 引向袭击者：标准战斗，先用20点魔像替代角色战斗3轮，然后角色入场，魔像转为敌人；额外1训练点和每人1珍宝。", "1. Fight now: one 5Pt golem.\n2. Lead to raiders: standard BQ; control a 20Pt golem for 3 rounds instead of your Gearloc. Then deploy the Gearloc and turn the golem hostile; extra training and a Trove."],
	o4: ["① 找武器：对抗一名1点狼和一名5点狼，前两轮不能使用技能骰。\n② 找背包：同样敌人，前两轮只能使用技能骰。", "1. Find weapon: fight a 1Pt and 5Pt wolf; no skills for rounds 1–2.\n2. Find pack: same baddies; only skill dice for rounds 1–2."],
	o5: ["① 开锁逃走：尝试3蛮力、2机关锁；成功弃置原有全部战利品并获得2张新的，失败失去2生命并改选②。\n② 欺骗巨魔：失去3生命，本晚恢复阶段不能治疗。", "1. Pick locks: 3F–2L; success discards all current Loot and draws 2 new Loot. Failure loses 2 HP and forces option 2.\n2. Trick trolls: lose 3 HP and cannot heal in tonight’s recovery."],
	o6: ["① 充当诱饵：两名5点敌人，入场投六面骰，3–6则眩晕前两轮。\n② 自己设伏：两名5点敌人，己方突袭，敌人每次移动及入场受1真实伤害。", "1. Bait: two 5Pt baddies; D6 on entry, 3–6 stuns for first two rounds.\n2. Trap: two 5Pt baddies; Surprise, baddies take 1 True Damage on every movement including entry."],
	o7: ["① 固守：标准战斗，第3–5轮末投六面骰，1–3时队列末尾增加1点敌人；额外1训练点及2战利品。\n② 供品：弃置1战利品，投六面骰；4–6和平成功，1–3重新选择遭遇方案；额外1训练点。", "1. Stand: standard BQ, at ends of rounds 3–5, D6 1–3 adds a 1Pt to BQ bottom; extra training and 2 Loot.\n2. Offer: discard Loot; D6 4–6 succeeds peacefully, 1–3 choose again; extra training."],
	o8: ["① 留一天：标准队列增加5点敌人，获得本场5临时生命；额外1训练点1战利品。\n② 装水离开：获得可在战斗内外使用的2生命治疗，额外1训练点。", "1. Stay: add a 5Pt to standard BQ; gain 5 Buff HP this battle; extra training and Loot.\n2. Bottle water: keep a 2HP heal usable in or out of battle; extra training."],
	o9: ["① 袭击：队列顶增5点敌人，所有敌人初始生命减少2；额外2战利品。\n② 保护商人：顶增5点敌人，控制4生命、2攻击、2移动的商人于角色回合后行动；商人必须存活，成功移除特殊遭遇006；额外每人1珍宝。", "1. Attack: add a 5Pt atop BQ; all baddies start at -2 HP; extra 2 Loot.\n2. Defend trader: add a 5Pt; control a 4HP/2Atk/2Move melee trader after your turn. Trader must survive; remove Special 006 on success; extra Trove."],
	o10: ["① 抢武器：第一路线首名敌人攻击减少2，角色本场攻击增加1，前两轮不能用技能。\n② 抢装备：第一轮不能用技能。", "1. Grab weapon: first Lane 1 baddie has -2 Attack, Gearloc has +1 Attack; no skills in rounds 1–2.\n2. Gear: no skills in round 1."],
	o11: ["① 砍杀：标准点数只用1点敌人；前三轮倒下的敌人回到队列末尾。\n② 游击：只战两名5点近战敌人；每次攻击后可免费移动最多3格。", "1. Hack and slash: points in 1Pt baddies only; baddies defeated in rounds 1–3 return to BQ bottom.\n2. Kite: two 5Pt melee baddies; move up to 3 positions free after attacking."],
	o12: ["① 拒绝同伴：永久生命属性减少1，和平成功。\n② 接受同伴：选3颗技能骰，下次战斗开始时耗尽，和平成功。", "1. Refuse: permanently reduce Health Stat by 1; peaceful success.\n2. Accept: choose 3 skill dice to exhaust at next battle start; peaceful success."],
	t1: ["① 迎战诺姆：标准队列增加两名1点（1–2人）或5点（3–4人）敌人，诺姆位于队列顶。诺姆在第三轮末或生命降至5时离场，仍须击败其他敌人。\n② 退避：每人失去2生命并跳过恢复，本牌洗回牌堆。", "1. Face Nom: add two 1Pt (1–2 players) or 5Pt (3–4) to standard BQ with Nom on top. Nom leaves after round 3 or at 5 HP; defeat remaining baddies.\n2. Back away: each loses 2 HP, skip recovery, reshuffle this card."],
	t3: ["标准战斗。敌人入场后，在空闲敌方远程格放置人数乘3生命的能量球。每轮结束对不与其相邻的敌对单位造成1伤害；击败球和敌人才成功。此后暴君战能量球只有3生命。", "Standard BQ. After deployment place an Orb with 3 HP per Gearloc on an open baddie ranged position. At round end it deals 1 Damage to non-adjacent opposing units. Destroy it and baddies. Future Tyrant Orbs start at 3 HP."],
	t4: ["① 没有备用方案：标准战斗，不能使用备用计划。\n② 另类方案：标准战斗，每个角色投出的骨头使能量球对该角色造成1伤害。额外1训练点。", "1. No Plan B: standard battle, no Backup Plans.\n2. Plan C: standard battle; each Bone a Gearloc rolls causes 1 Damage to that Gearloc. Extra training."],
	t6: ["① 迎战：标准队列顶增加一名5点野兽（1–2人）或两名5点野兽（3–4人）；额外每人1战利品。\n② 友好伸手：指定角色投六面骰，1–2永久生命减少3但不低于初始值；3–6无事，和平成功。额外1训练点。", "1. Fight: add one 5Pt Beast (1–2 players) or two (3–4) atop BQ; extra Loot each.\n2. Offer hand: chosen Gearloc rolls D6; 1–2 permanently loses 3 max HP, no lower than starting Health; 3–6 harmless. Peaceful success, extra training."],
	t7: ["尽可能用野兽组成标准队列。角色只放己方近战格，敌人先放己方远程格；敌人突袭，之后入场恢复正常规则。", "Standard BQ with as many Beasts as possible. Deploy Gearlocs in Gearloc melee and baddies in Gearloc ranged positions; baddies have Surprise. Later entries use normal positions."],
	t8: ["① 帮助达丝特：全队用战利品提供合计人数乘2的治疗；和平成功，额外1训练点。\n② 怀疑陷阱：标准战斗。", "1. Help Duster: provide 2 HP healing per party member using Loot; peaceful success, extra training.\n2. Suspect a trap: standard battle."],
	t10: ["在当前或已击败敌人中找一名狼、枭熊或狮鹫，1–2人找1点、3–4人找5点。将它留作暴君战的额外敌人。将本牌洗回，另抽今天的遭遇。", "Find a wolf, owlbear or griffin from Active/Defeated stacks: 1Pt for 1–2 players, 5Pt for 3–4. Reserve it for the Tyrant battle. Reshuffle this card and draw another today."],
	t12: ["① 收集材料：选择六名1点或三名5点敌人，获胜后本牌洗回；获得2训练点。\n② 制作解毒剂：已击败敌人中须有沼泽蝌蚪或蛙、沼泽潜伏者、石魔像、泥魔像各一种。获得持续免疫暴君的毒性增强、1进度和1训练点。", "1. Ingredients: fight six 1Pt or three 5Pt baddies; reshuffle on completion; gain 2 training.\n2. Antidote: defeated stack must contain bog pole/frog, bog lurk, stone golem and clay golem. Gain immunity to Tyrant Poison Enhancer, 1 progress and 1 training."],
	t14: ["标准队列尽可能使用兽人。前三轮被击败的兽人回到队列末尾。", "Use as many Orcs as possible in standard BQ. Orcs defeated in rounds 1–3 return to the bottom."],
	t15: ["① 对抗沼泽类。\n② 对抗鳞族。\n只使用所选类型组成标准点数队列，成功后该类型从本次冒险的当前与已击败牌堆中移除。", "1. Fight Bog.\n2. Fight Scales.\nBuild standard Baddie Points using only that type. On success remove that type from Active and Defeated stacks for this adventure."],
	t17: ["① 忽略炸弹：标准战斗。\n② 拆弹：每人选择锁类型并尝试达到3；全员成功可在最终战开场立即炸毁王座，失败则开战前全队受2伤害。随后标准战斗。", "1. Ignore: standard battle.\n2. Disarm: each names a lock type and attempts difficulty 3. All succeed to destroy the throne at final-battle start; otherwise each takes 2 Damage before battle. Then standard BQ."],
	t18: ["标准队列顶增加一名1点哥布林（1–2人）或5点哥布林（3–4人）。此后每次标准敌人点数战斗，额外加入最近被击败的哥布林。", "Add a 1Pt Goblin (1–2 players) or 5Pt Goblin (3–4) atop BQ. Persistently add the most recently defeated Goblin to every future standard Baddie Points battle."]
}, Gi = Object.fromEntries(Object.entries(Wi).map(([e, t]) => [e, t[0]])), Ki = Object.fromEntries(Object.entries(Wi).map(([e, t]) => [e, t[1]])), qi = [
	["获得元素并锁定；每次合成消耗一个元素、弹壳和引信。", "Lock Element components; crafting spends one Element, Casing and Fuse."],
	["获得弹壳并锁定，剩余数量跨战斗保留。", "Lock Casing components; unused components persist between battles."],
	["获得引信并锁定，剩余数量跨战斗保留。", "Lock Fuse components; unused components persist between battles."],
	["这是炸弹库存的计数骰，不能投掷；最多可储存3个炸弹。", "This die tracks your grenade supply and is never rolled. You may store at most three grenades."],
	["预先选择落点，消耗一个炸弹；命中单位承受全额伤害，相邻单位承受向下取整的一半伤害。", "Declare an aim and spend a grenade. Deal full damage on that position and half, rounded down, to adjacent units."],
	["消耗一个炸弹，对所有敌人造成伤害；反冲结果同时伤害所有队员。", "Spend a grenade to damage every baddie; Party Backlash also damages all party members."],
	["预先瞄准友方角色并消耗一个炸弹；烟幕使其下几次被敌人选为目标时免受攻击和技能。", "Aim at a Gearloc and spend a grenade. Smoke cancels the next indicated number of enemy attacks and skills targeting them."],
	["消耗一个炸弹，移除全队负面状态；持续期间阻止新的负面状态，自己回合开始时减少剩余回合。", "Spend a grenade to clear party negative effects and prevent new ones. Reduce duration at the start of your turn."],
	["预先选择瞄准目标并消耗1个炸弹。若目标为非暴君敌人，且其点数不高于骰面结果，使其眩晕，失去下个回合。", "Aim and spend a grenade. Stun a non-Tyrant whose points do not exceed the result; it misses its next turn."],
	["预先瞄准并消耗一个炸弹；目标每次回合开始承受燃烧伤害，持续骰面回合数；反冲伤害自己。", "Aim and spend a grenade. Napalm damages the baddie at turn start for the indicated rounds; Backlash damages you."],
	["预先瞄准并消耗一个炸弹；禁用点数不高于骰面的敌人技能，持续本场战斗。", "Choose your aim before rolling and spend one grenade. Disable the skills of a baddie whose point value does not exceed the die result, for the rest of this battle."],
	["这是消耗品技能。按骰面结果获得完整炸弹，或将所示数量的零件分配为元素、弹壳与引信。", "This is a consumable skill. Depending on the result, gain grenades or distribute the indicated number of components among Element, Casing and Fuse."],
	["至少有一名敌人倒下后才能投掷；获得临时生命、战利品或可分配零件。", "Roll only after a baddie has been defeated. Gain Buff HP, Loot or components."],
	["本场战斗中，破片炸弹和大爆炸造成的伤害增加骰面结果所示的点数。", "Increase Frag and Big Boom damage by the result for this battle."],
	["获得神圣手榴弹、炸弹或锁定元素325；也可能获得两个骨头。", "Depending on the result, gain a Holy Hand Grenade, gain a grenade, lock Element 325, or gain two Bones."],
	["这是消耗品技能，使用时不消耗炸弹库存，且必须结算骰面效果。若使用元素325，以强化伤害替代正常伤害，并耗尽元素325。", "This is a consumable skill. It costs no grenade from your supply, and you must resolve its result. If you use Element 325, replace the normal damage with enhanced damage and exhaust Element 325."]
], Ji = [
	["治疗一名存活角色，不能超过生命上限。", "Heal a living Gearloc up to their maximum HP."],
	["可以立即使用此骰，也可以将其放入锁定槽。选择1颗尚未使用的医疗包或大医疗包骰，将其治疗数值乘以此骰所示的倍数。", "Use this die immediately or place it in a Locked slot. Choose an unused Med Kit or Med Pack die and multiply its healing result by the multiplier shown on this die."],
	["对已宣告的相邻目标造成伤害。", "Damage your declared adjacent target."],
	["这是消耗品技能。可以先将复活骰放在一名存活角色的主动槽中，在该角色濒死时恢复生命；也可以直接复活一名已倒下的角色。", "This is a consumable skill. Place a revive die in a living Gearloc’s Active slot to restore HP when they would be knocked out, or use it to revive a Gearloc who is already knocked out."],
	["治疗存活角色、获得战利品，或锁定医疗包重掷次数。", "Heal, gain Loot, or lock rerolls for Med Kit dice."],
	["使已宣告的相邻目标中毒；中毒在其回合开始造成真实伤害后递减。", "Poison your declared adjacent target; poison deals True Damage at turn start and then decreases."],
	["治疗一名存活角色，不能超过生命上限。", "Heal a living Gearloc up to maximum HP."],
	["这是消耗品技能，可以使任意1名敌人中毒。", "This is a consumable skill. Poison any one baddie."],
	["放入存活角色主动槽，增加临时生命；临时生命耗尽时移除骰子。有毒结果伤害自己。", "Place this die in a living Gearloc’s Active slot to give them Buff HP. Exhaust the die when that Buff HP is depleted. A Tainted result damages you."],
	["放入存活角色主动槽，增加本场战斗的可用攻击骰，仍需支付敏捷。", "Give a living Gearloc additional Attack dice for this battle. Rolling those dice still costs Dexterity."],
	["每次投掷消耗一格能量电池；造成真实伤害或复活倒下的角色。", "Spend one Battery charge per roll to deal True Damage or revive a KO’d Gearloc."],
	["这是消耗品计数骰。取得此骰时，将其投掷并放入锁定槽，用于记录电击背包剩余的能量电池数量。", "This is a consumable counter die. Roll it when acquired, then place it in a Locked slot to track the Battery charges available for Zappack."],
	["可以立即使用此骰，也可以将其放入锁定槽。重掷本回合已投掷但尚未使用的临时生命、临时攻击或永久生命药剂骰。", "Use instantly or lock; reroll an unused Buff HP, Buff Attack or permanent HP die rolled this turn."],
	["为一名存活角色增加临时生命；有毒结果造成真实伤害。", "Give a living Gearloc Buff HP; Tainted results deal True Damage to you."],
	["将此骰放入一名存活角色的主动槽。按骰面效果，在该角色每回合开始时治疗生命，或将仍然存在的临时生命恢复至原上限。", "Place this die in a living Gearloc’s Active slot. Depending on the result, heal that Gearloc at the start of each turn, or replenish existing Buff HP up to its original amount."],
	["永久增加所选角色生命上限和当前生命；有毒结果伤害自己。", "Permanently increase the chosen Gearloc’s maximum and current HP; Tainted results damage you."]
], Yi = [
	["此骰可复用。将其锁定后，每回合开始时恢复1点生命；该效果跨战斗保留。", "This die is reusable. Lock it to heal 1 HP at the start of each turn. The effect persists between battles."],
	["此骰可复用。将其锁定后，按骰面结果获得免费移动，或使每次受到的普通伤害减少1点。", "This die is reusable. Lock it to gain the free movement shown by the result, or reduce each instance of normal damage by 1."],
	["将此骰放入另一名角色的主动槽。该角色接下来被选为目标的所示次数攻击与效果，改由皮克特承担。", "Place this die in another Gearloc’s Active slot. Redirect the next indicated number of attacks and effects targeting that Gearloc to Picket."],
	["这是消耗品技能。将皮克特的生命降至1点；在所示持续回合内，皮克特不能获得或失去生命。在皮克特每回合开始时，剩余持续回合数减少1。", "This is a consumable skill. Set Picket’s HP to 1 and prevent all HP gains and losses for the indicated number of turns. Reduce the remaining duration by one at the start of Picket’s turn."],
	["此骰可复用。将其锁定后，按骰面结果获得免费移动，或使每回合攻击造成的总伤害增加1点。", "This die is reusable. Lock it to gain the free movement shown by the result, or add 1 to the total damage of your Attack each turn."],
	["此骰可复用。将其锁定后，持续产生嘲讽效果，使相邻的敌方单位必须选择皮克特作为目标。", "This die is reusable. Lock it to maintain Taunt, requiring adjacent enemy units to choose Picket as their target."],
	["将此骰放入另一名角色的主动槽。该角色接下来被选为目标的所示次数攻击与效果，改由皮克特承担。", "Place this die in another Gearloc’s Active slot. Redirect the next indicated number of attacks and effects targeting that Gearloc to Picket."],
	["这是消耗品技能。按骰面数值治疗皮克特，但不能超过其生命上限。", "This is a consumable skill. Heal Picket by the result, without exceeding maximum HP."],
	["换位、突进或还击，可先存入主动槽。换位与突进可在本回合使用；同回合第二次同类效果可额外造成三点伤害或治疗。", "Store Switch, Rush or Riposte in an Active slot. Switch and Rush may be used on the turn they are rolled. Using a second matching effect in the same turn grants the corresponding bonus of 3 damage or 3 HP of healing."],
	["突进最多免费移动三格；同回合第二次突进可对相邻敌人造成三点伤害。", "Rush lets you move up to three positions without spending Dexterity. A second Rush used in the same turn may deal 3 damage to an adjacent baddie."],
	["可以将高级防御骰放入自己或一名存活队友的主动槽，用于吸收普通伤害；它也可以用于皮克特的盾击。", "Advanced Defense may be Active on you or a living ally; absorbs normal damage and counts for Picket’s Shield Bash."],
	["高级防御放在自己或存活队友主动槽。", "Place Advanced Defense in your or a living ally’s Active slot."],
	["还击在相邻敌人选中皮克特时发动，避免该次伤害和效果；同时移除第二颗可对敌人造成三点伤害。", "Riposte cancels damage and effects when an adjacent baddie targets Picket; spend a second Active Riposte to deal three damage."],
	["按骰面结果执行对应效果：\n· 换位：交换相邻单位的位置。\n· 突进：免费移动。\n· 还击：取消相邻敌人对皮克特的一次攻击及其效果。", "Resolve the effect shown by the result:\n· Switch: Exchange the positions of adjacent units.\n· Rush: Move without spending Dexterity.\n· Riposte: Cancel an adjacent enemy’s attack against Picket and its effects."],
	["按骰面结果获得骨头，或将强化防御训练骰放入锁定槽。强化防御训练使你在防御训练失败并重掷后，还可以忽略1枚骨头。", "Depending on the result, gain Bones or lock the Improved Defense Training die. During Defense training, this lets you ignore one Bones after rerolling failed dice."],
	["高级防御放在自己或存活队友主动槽。", "Place Advanced Defense in your or a living ally’s Active slot."]
], Xi = [
	["这是怒气计数骰。受到伤害时，按失去的生命增加怒气；每回合首次攻击时，计数骰前进1格。释放怒气时，按当前怒气值获得骨头：\n· 怒气为2时，获得1个骨头。\n· 怒气为4时，获得2个骨头。\n· 怒气为6时，获得3个骨头。", "This die tracks Rage. Advance it for HP lost and once for your first Attack each turn. When you release Rage, gain Bones according to its current value:\n· At 2 Rage, gain 1 Bones.\n· At 4 Rage, gain 2 Bones.\n· At 6 Rage, gain 3 Bones."],
	["这是怒气计数骰。释放怒气时，按当前怒气值结算：\n· 怒气为2、4或6时，分别恢复1、2或3点生命。\n· 怒气为8时，可以提升怒气等级，或处决1名点数不超过5的非暴君敌人。", "This die tracks Rage. When you release Rage, resolve the effect for its current value:\n· At 2, 4 or 6 Rage, heal 1, 2 or 3 HP respectively.\n· At 8 Rage, advance to the next Rage tier or execute one non-Tyrant baddie worth up to 5 points."],
	["这是怒气计数骰。释放怒气时，按当前怒气值结算：\n· 怒气为2、4或6时，对已宣告的目标造成2点伤害。\n· 怒气为8时，可以处决1名点数不超过20的非暴君敌人。", "This die tracks Rage. When you release Rage, resolve the effect for its current value:\n· At 2, 4 or 6 Rage, deal 2 damage to your declared target.\n· At 8 Rage, execute one non-Tyrant baddie worth up to 20 points."],
	["增加或降低怒气；提升结果可直接进入已训练的下一级怒气。", "Increase or decrease Rage; Advance enters the next trained Rage tier."],
	["按骰面结果获得斧头，或将毒甲骰放入主动槽。毒甲效果生效时，受到相邻敌人伤害后，可以使该敌人获得所示数值的中毒。", "Depending on the result, gain axes or place Poison Armor in an Active slot. While it is active, after an adjacent enemy damages you, you may apply the indicated Poison value to that enemy."],
	["按骰面结果获得斧头，或将反击骰放入主动槽。反击效果生效时，受到相邻敌人伤害后，可以对该敌人造成所示点数的伤害。", "Depending on the result, gain axes or place Lashback in an Active slot. While it is active, after an adjacent enemy damages you, you may deal the indicated damage to that enemy."],
	["按骰面结果获得斧头，或暂时获得坚韧效果。坚韧效果生效时，每个回合最多失去1点生命；在自己每回合开始时，剩余持续回合数减少1。", "Depending on the result, gain axes or gain Hardy for the indicated duration. While Hardy is active, lose at most 1 HP per turn. Reduce its remaining duration by one at the start of your turn."],
	["这是斧头库存的计数骰，不能投掷。每回合可以投掷1把斧头，对1名不相邻的敌人造成2点伤害。", "This die tracks your axe supply and is never rolled. Once per turn, throw one axe at a non-adjacent baddie to deal 2 damage."],
	["使宣告目标在本轮结束时降低先攻位置。", "Lower your declared target’s initiative position at round end."],
	["降低一名相邻敌人的攻击，持续本场战斗。", "Reduce an adjacent baddie’s Attack for this battle."],
	["禁用一名相邻的五点以下敌人技能，持续本场战斗。", "Disable the skills of one adjacent non-Tyrant baddie worth up to 5 points for the rest of this battle."],
	["这是消耗品技能。按骰面结果，使全队在下一轮先于敌人行动，或眩晕所有点数不超过5的非暴君敌人。此骰产生的骨头可以复用。", "This is a consumable skill. Depending on the result, place the party before all enemies in the next round’s initiative order, or stun every non-Tyrant baddie worth up to 5 points. Bones from this die are reusable."],
	["跳到任意敌人相邻空格，并将其设为宣告目标。", "Jump to an empty position adjacent to a baddie and declare it as your target."],
	["增加本场战斗的攻击；特殊结果还会立即进行一次攻击训练。", "Gain Attack for this battle; the special result also makes an Attack Training Attempt immediately."],
	["嘲讽相邻敌人，持续至自己下次回合开始。", "Taunt adjacent enemies until the start of your next turn."],
	["这是击杀数的计数骰，不能投掷。每击败1名敌人，计数增加1，最多累计至5。可以消耗全部计数，按消耗的数值恢复自己的生命。", "This die tracks Body Count and is never rolled. Increase it by one each time you defeat a baddie, to a maximum of five. Spend the entire count to heal yourself by that amount."]
], Zi = [
	["下次战斗的敌人点数减少三点。", "Reduce next battle’s Baddie Points by three."],
	["取得一颗本角色可用的消耗品技能；选择技能编号。", "Acquire an eligible consumable skill for your Gearloc; choose its skill number."],
	["自己回合治疗五点，然后获得中毒二。", "On your turn, heal five HP and gain Poison 2."],
	["训练失败后可重置失败项目限制，重新尝试。可用两次。", "After failed training, reset failed choices and try again. Two uses."],
	["投骰前获得两颗额外攻击骰，本回合投掷它们不消耗敏捷。", "Before rolling, gain two additional Attack dice free of Dex this turn."],
	["仅战斗外治疗队友，共有七点治疗量，按所选数量消耗；每天结束减少一点。", "Outside battle, spend from seven HP of healing on an ally; lose one remaining use each day."],
	["本回合敏捷增加三点。", "Gain three Dex this turn."],
	["自动打开当前难度不超过四的锁。", "Automatically solve the current lock if its value is at most four."],
	["战斗中治疗自己三点，战斗外治疗五点。", "Heal yourself for three in battle or five outside battle."],
	["为所选开锁行动骰增加一点，可用三次。", "Add one to a chosen lockpicking action die. Three uses."],
	["自己回合治疗一点，可用三次。", "Heal yourself for one on your turn. Three uses."],
	["为自己所选开锁骰增加两点，可用两次。", "Add two to your chosen lockpicking die. Two uses."],
	["永久、占三个背包位；每颗防御骰可将骨头转为防御一，或将防御一转为二，一骰只能转换一次。", "Permanent, occupies three slots. Each Defense die may convert Bones to one Defense or one Defense to two once."],
	["下次训练可忽略一枚骨头。", "Ignore one Bones in the next training attempt."],
	["重掷一颗未使用骰子、开锁骰或部署阶段的先攻骰。可用两次。", "Reroll an unused die, lockpicking die or initiative during deployment. Two uses."],
	["永久、占三个背包位；每回合可额外免费投掷一颗防御骰。", "Permanent, occupies three slots. Roll one extra Defense die free of Dex each turn."],
	["本轮结束时，选择将自己的先攻提高三个位置。可用两次。", "At round end, optionally move up three initiative positions. Two uses."],
	["下一战斗使最近战斗击败过的一类敌人先攻降低；选择敌人种类。可用三次。", "Give Surprise against one creature type defeated last battle; select its creature type. Three uses."],
	["永久、占三个背包位；训练攻击和防御时可忽略一枚骨头。", "Permanent, occupies three slots. Ignore one Bones in Attack and Defense training."],
	["即将受到负面效果时，可弃置此物阻止该次效果。", "Discard when a negative effect would be applied to prevent it."],
	["为自己所选开锁骰增加四点。", "Add four to your chosen lockpicking die."],
	["抽两张遭遇，选择当天面对的一张，另一张放回遭遇牌堆底。", "Draw two Encounters; choose one for today and put the other at the deck bottom."],
	["恢复阶段取得一张珍宝。", "Gain a Trove Loot during Recovery."],
	["自己回合对任意存活单位投一颗攻击骰并造成伤害。可用两次。", "On your turn roll one Attack die against any living unit. Two uses."],
	["战斗外将宝藏鼠特殊遭遇加入遭遇牌堆。", "Outside battle, shuffle the treasure-rat Special Encounter into the deck."],
	["永久生命增加一点；下一次战斗开始失去三点生命。", "Gain one permanent maximum and current HP; lose three HP at the next battle start."],
	["自己回合恢复一名角色已经耗尽的技能骰。", "On your turn recover an exhausted skill of a Gearloc."],
	["本场战斗每轮开始治疗自己一点。", "Heal yourself for one at each round start this battle."],
	["治疗一名存活角色两点。", "Heal a living Gearloc for two."],
	["遭遇获得；占一个背包位，可在战斗内外按所选数量消耗两点治疗量。", "Encounter Loot; occupies one slot and holds two HP to spend healing inside or outside battle."]
], Qi = [
	["", ""],
	["", ""],
	["备用计划一：免费额外投掷一颗可用骰子；数量选择零为攻击、一为防御、二为技能。", "Backup 1: roll one additional available die free of Dex. Choose amount 0 for Attack, 1 for Defense or 2 for a skill."],
	["你的备用计划与珍宝备用计划消耗的骨头减少一，天赋升级仍需六个骨头。", "Reduce your Backup Plan and extension costs by one Bones; the Innate upgrade still costs six."],
	["备用计划二：将宣告目标的防御骰移至自己的主动槽，必须有足够空槽。", "Backup 2: steal your declared target’s Defense dice into your Active slots, if space permits."],
	["", ""],
	["备用计划三：变为不可选目标，持续至自己下回合；每场一次。", "Backup 3: become Untargetable until your next turn, once per battle."],
	["击杀第一名敌人后记录其种类；以后同类击杀继续累计，攻击该类敌人时，每次累计提供一颗免费攻击骰。", "Record the first creature type you kill. Each matching kill adds one free Attack die when attacking that type."],
	["备用计划一：宣告目标在本轮末降低一个先攻位置。", "Backup 1: lower your declared target one initiative position at round end."],
	["备用计划三：眩晕一名一点或五点敌人；掷出一时，自己下回合也眩晕。", "Backup 3: stun a 1Pt or 5Pt baddie; on a D6 roll of one, you are also stunned next turn."],
	["全队面对的所有锁难度减少一。", "Reduce every lock difficulty the party faces by one."],
	["备用计划一：永久生命属性减少一并治疗三点，不可低于初始生命属性。", "Backup 1: permanently lose one maximum HP and heal three; cannot go below starting Health."],
	["备用计划二：对任意敌人造成两点伤害；掷六面骰，四至六时本场不能再用。", "Backup 2: deal two damage to any baddie; on D6 four to six, unavailable for the rest of this battle."],
	["战前选择一至四号路线；该路线第一名入场的一点、五点或二十点敌人延迟一轮，每场一次。", "Before battle choose lane one to four; delay its first 1Pt, 5Pt or 20Pt entrant for one round, once per battle."],
	["本回合投掷后再选择宣告攻击目标。", "Choose your declared Attack target after rolling this turn."],
	["备用计划一：治疗任意存活角色一点。", "Backup 1: heal any living Gearloc for one."],
	["任何训练尝试都可忽略一枚骨头。", "Ignore one Bones in any training attempt."],
	["备用计划二：选择本回合一颗未使用的攻击骰，按其伤害为目标施加同等中毒。", "Backup 2: choose an unused Attack result this turn and poison its target for that amount."],
	["备用计划一：重掷本回合一颗未使用的骰子。", "Backup 1: reroll one unused die this turn."],
	["备用计划一：本轮末提高自己一个先攻位置。", "Backup 1: move up one initiative position at round end."],
	["被不相邻敌人攻击后，立即投一颗攻击骰并对该敌人造成伤害；骨头不能用于备用计划。", "After a non-adjacent baddie attacks you, roll one Attack die against it; Bones cannot enter your Backup Plan."],
	["每天战斗外可侦察任一等级的一名敌人，选择保留或放回敌人堆底。", "Once per day outside battle, scout a baddie of any point value and optionally cycle it to the bottom."],
	["备用计划二：恢复任意角色一颗已耗尽骰子，每场一次。", "Backup 2: recover any Gearloc’s exhausted die, once per battle."]
], $i = [
	["反击：每个回合首次受到相邻敌方造成的普通伤害并失去生命后，若仍存活，反击所示伤害。", "Lashback: once per turn after losing HP from an adjacent enemy’s damage, deal the indicated damage back if still alive."],
	["飞行：回合末交替获得或移除飞行；飞行时不能被选为目标。", "Flight: toggle Flight at turn end; cannot be targeted while flying."],
	["厚皮：每个回合忽略最先受到的所示普通伤害，不抵消真实伤害。", "Thick Skin: ignore the first indicated normal damage each turn; does not block True Damage."],
	["粗心：受到所示真实伤害。", "Careless: suffer the indicated True Damage."],
	["掠夺：场上每有另一名兽人敌人，攻击增加一骰。", "Raiding: gain one Attack die for every other Orc baddie on the mat."],
	["狂暴：生命未满时增加所示攻击骰。", "Rage: gain the indicated Attack dice while below full HP."],
	["中毒：将目标中毒设为所示数值；目标回合开始承受同等真实伤害，随后递减。", "Poison: set target Poison to the result; deal that True Damage at turn start, then decrease by one."],
	["破坏：使其失去生命的白色攻击骰在本场战斗耗尽。", "Break: exhaust white Attack dice that reduce this unit’s HP for this battle."],
	["恶作剧：目标选择移除所示数量的主动骰；其他单位移除防御骰。", "Mischief: the target chooses the indicated Active dice to remove; other units remove Defense dice."],
	["坚韧：每个回合总共最多失去一点生命，包括真实伤害。", "Hardy: lose at most one total HP per turn, including True Damage."],
	["虚弱：角色下回合敏捷降低；其他单位下回合攻击降低。", "Weaken: reduce a Gearloc’s Dex or another unit’s Attack on its next turn."],
	["吞噬：掷出的总攻击伤害也伤害目标相邻的所有单位，包括攻击者。", "Engulf: rolled Attack damage also hits all units adjacent to the target, including the attacker."],
	["递增：攻击骰数等于当前轮数，最多五骰。", "Compound: Attack equals the current round, up to five dice."],
	["鼓舞：先攻表中的下一名敌人移至此单位之后，且该回合增加所示攻击骰。", "Inspire: move the next baddie directly after this unit and give it the indicated extra Attack dice that turn."],
	["恐惧：攻击此单位后获得恐惧，持续至下回合末；下回合不能选择带恐惧技能的目标。", "Terrify: attackers gain Terrify until the end of their next turn and cannot target Terrify units on that turn."],
	["俯冲：带飞行状态开始回合时，移动至最弱可用敌方单位相邻空格并选择它。", "Dive: if flying at turn start, move next to the weakest available opposing unit and target it."],
	["信号：回合开始向待入场敌人末尾加入一名低等级敌人，共触发所示回合数。", "Signal: at turn start add a lesser baddie to the waiting stack for the indicated number of turns."],
	["嘲讽：相邻敌方必须选其为目标，直至其下回合；多目标攻击集中于该单位。", "Taunt: adjacent enemies must target this unit until its next turn; multiple attacks focus on it."],
	["腐蚀：回合末使目标主动槽剩余的防御骰全部耗尽。", "Corrosive: at turn end remove all remaining Defense dice in the target’s Active slots."],
	["恢复：回合开始恢复所示生命，不超过上限。", "Recover: heal the indicated HP at turn start, up to maximum."],
	["不死：首次倒下后回到待入场敌人顶端；再次入场时两点生命、双倍攻击。", "Undead: after first defeat, return to the top of the waiting stack; re-enter at two HP with doubled Attack."],
	["限制：目标选择移除一个已提升的属性，持续本场战斗。", "Limit: the target removes one upgraded Stat for this battle."],
	["隐蔽：只有相邻单位能选择此单位为目标。", "Shrouded: only adjacent units may target this unit."],
	["隐藏：直到自己下回合不能被选为目标。", "Hide: cannot be targeted until your next turn."],
	["狂乱：至少所示数量的攻击骰命中时，额外投掷所示数量的攻击骰并加入伤害。", "Frenzy: if at least the indicated Attack dice hit, roll that many additional dice and add their damage."],
	["撤退：三点生命或更低时开始回合，退出战场并回到待入场敌人顶端；再次入场恢复全部生命。", "Retreat: at turn start with three HP or less, return to the waiting stack top; re-enter at full HP."],
	["沼泽统治者：场上有其他沼泽敌人时不能失去生命，且免疫中毒。", "Bog Ruler: cannot lose HP while another Bog baddie is on the mat; immune to Poison."],
	["召唤兽人：一个骨头加入一点兽人，两个或更多加入五点兽人。", "Call Orc: add a 1Pt Orc for one Bones or a 5Pt Orc for at least two."],
	["爆破：总攻击伤害的一半向下取整，波及目标相邻单位。哥布林王免受自己造成的伤害。", "Boom: half the rolled Attack damage, rounded down, hits units adjacent to the target. The Goblin King ignores self-inflicted damage."],
	["击退：哥布林王攻击前，所有角色移至距离自己原位置最远的空格。", "Kaboom: before the Goblin King attacks, move every Gearloc to an empty position farthest from its current position."]
], ea = (e, t) => e.map((e) => e[t]).join("|"), ta = {
	skillRulesBoomer: ea(qi, 0),
	skillRulesPatches: ea(Ji, 0),
	skillRulesPicket: ea(Yi, 0),
	skillRulesTantrum: ea(Xi, 0),
	lootRules: ea(Zi, 0),
	troveRules: ea(Qi, 0),
	baddieRules: ea($i, 0)
}, na = {
	skillRulesBoomer: ea(qi, 1),
	skillRulesPatches: ea(Ji, 1),
	skillRulesPicket: ea(Yi, 1),
	skillRulesTantrum: ea(Xi, 1),
	lootRules: ea(Zi, 1),
	troveRules: ea(Qi, 1),
	baddieRules: ea($i, 1)
}, ra = {
	definition: Yn,
	View: Di,
	bot: Fi,
	fx: Li,
	OverView: Vi,
	Options: Hi,
	Guide: Ui,
	locales: {
		zh: {
			flowCanLearn: "可学习",
			flowSkillLocked: "未解锁",
			flowSkillPrerequisite: "前置技能 · {{name}}",
			flowRequiredProgress: "挑战需{{n}}点进度",
			flowUndo: "撤回",
			flowConfirmLearn: "确认学习",
			flowConfirmTraining: "确认训练",
			flowFinishTraining: "完成训练",
			flowTrainingRollInfo: "确认后掷骰。训练成功时才消耗1个训练点。",
			flowUnlocked: "已解锁：{{names}}",
			flowBag: "背包",
			flowLootUses: "可用{{n}}次",
			flowKeepName: "保留{{name}}",
			flowRecruitName: "征召{{name}}",
			flowRewardRecipient: "领取角色：{{name}}",
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			creature: "敌人种类",
			creatureNames: "巨魔|兽人|鳞族|地精|沼泽生物|野兽",
			flickAdjust: "调整弹射",
			flickAngle: "方向",
			flickPower: "力度",
			flickShoot: "弹射",
			...ta,
			encounters: Gi,
			playerAid: "角色提示",
			startingSkills: "起始技能",
			noStartingSkills: "没有起始技能",
			chosen: "已选择",
			skillTree: "技能树",
			viewSkillTree: "查看技能树",
			innate: "天赋",
			innateUpgrade: "天赋升级",
			learned: "已取得",
			startingDie: "起始",
			consumableTag: "消耗品",
			consumableNote: "消耗品技能不能通过训练取得。",
			facesLabel: "骰面",
			counterDie: "计数骰，不投掷。",
			noPrereq: "无前置技能。",
			prereqList: "前置：{{skills}}",
			trainSkill: "训练此技能",
			treeLegend: "实心：已取得；铜框：可以训练；半透明：前置未满足；虚线：消耗品。",
			backupNote: "每回合最多使用一次。持有减少消耗的珍宝时，除升级天赋外的项目成本减少1点。已升级天赋后不能再次选择升级项目。",
			backupCostPaid: "实际消耗{{n}}个骨头",
			tyrantFaces: "暴君骰面一览",
			tyrantFaceNames: "大快朵颐|雷神之锤|宝珠|焦灼|披风|匕首|银皮|嚎叫|强化|剧毒|血怒|骸骨战斧|呼救|粗心炸弹",
			tyrantFaceRules: "攻击前移除目标的主动槽与锁定槽中的全部防御骰，并清空其护甲。|攻击后目标受到1点真实伤害，并被移到距离自己最远的空格。|在对应路线生成4点生命的宝珠；第三格宝珠柱完成后改为3点。|生命最低的狗头人受到1点伤害；若仍存活，跳到最近的队员旁并造成2点伤害。|与下一名队员交换位置，并使其离开战场；任意队员倒下后重新入场。|本回合的攻击使目标流血1点。|本回合内，针对该暴君的攻击造成0点伤害；暴君下回合开始时重置。|其他存活的敌人先攻前移一位。|目标已有中毒时，将其中毒提高到3点。|每个目标获得2点中毒。|清除骸骨战斧，后退至多两格，然后恢复3点生命。|本回合的攻击造成真实伤害。|向待入场队列加入增援：两名或更少队员时加入1点敌人，否则加入5点敌人。|生命最高的敌人及与其相邻的单位受到3点伤害。",
			enemyRolled: "掷出{{n}}颗攻击骰：{{values}}",
			enemyRolledBones: "获得{{n}}个骨头",
			tyrantRolled: "暴君骰面：{{face}}",
			intentLine: "攻击{{attack}} · 防御{{defense}} · 生命{{hp}}/{{max}}",
			intentTargets: "目标：{{names}}",
			defenseDiceLine: "已存防御{{n}}点",
			whiteAttackDie: "白色攻击骰六面",
			whiteDefenseDie: "白色防御骰六面",
			profBoomerScavenger: "拾荒者",
			profBoomerScavengerBrief: "收集元素、弹壳和引信，合成炸弹。",
			profBoomerGrenadier: "掷弹兵",
			profBoomerGrenadierBrief: "炸弹伤害的主要来源，投掷时消耗炸弹。",
			profBoomerBomber: "多面爆破手",
			profBoomerBomberBrief: "以烟幕、净化和闪光控制战场。",
			profBoomerKeenEye: "锐眼",
			profBoomerKeenEyeBrief: "补充部件、强化炸弹并寻找元素325。",
			profBoomerConsumables: "消耗品",
			profBoomerConsumablesBrief: "炸弹袋与神圣手榴弹等消耗品。",
			profPatchesMedic: "战地医疗",
			profPatchesMedicBrief: "核心治疗、近战伤害和复活手段。",
			profPatchesForester: "林地行者",
			profPatchesForesterBrief: "兼顾治疗、中毒与战利品。",
			profPatchesStim: "兴奋剂师",
			profPatchesStimBrief: "提供临时生命、攻击与持续效果，部分结果反噬自身。",
			profPatchesConsumables: "消耗品",
			profPatchesConsumablesBrief: "复活、毒镖与能量电池等消耗品。",
			profPicketCaptain: "队长",
			profPicketCaptainBrief: "可长期锁定的防御、再生、位移和伤害加成。",
			profPicketHero: "英雄",
			profPicketHeroBrief: "把防御转化为伤害的主要输出线。",
			profPicketProtector: "守护者",
			profPicketProtectorBrief: "替队友承担攻击与效果。",
			profPicketWarden: "守望者",
			profPicketWardenBrief: "以换位、突进和还击控制位置。",
			profPicketConsumables: "消耗品",
			profPicketConsumablesBrief: "兽人麦酒与哥布林肉干等消耗品。",
			profTantrumZerker: "狂战士",
			profTantrumZerkerBrief: "累积并释放怒气，是输出的核心。",
			profTantrumMimic: "模仿者",
			profTantrumMimicBrief: "毒甲、反击与坚韧等战斗姿态。",
			profTantrumSkirmisher: "游斗者",
			profTantrumSkirmisherBrief: "调整先攻、走位、削弱和嘲讽敌人。",
			profTantrumConsumables: "消耗品",
			profTantrumConsumablesBrief: "斧头库存、派对鼓舞与击杀计数。",
			innateScavenger: "拾荒者",
			innateScavengerBrief: "起始技能区放置元素、弹壳、引信和炸弹计数，炸弹计数初始为0。集齐各一件即可合成炸弹。",
			innateScavengerUpgrade: "足智多谋的拾荒者",
			innateScavengerUpgradeBrief: "投掷元素、弹壳和引信时可先各加1再锁定；掷出骨头时，也可改为将该部件提升到1。",
			innateRecovery: "恢复",
			innateRecoveryBrief: "每回合开始时，治疗自己1点生命。",
			innateRecoveryUpgrade: "强力恢复",
			innateRecoveryUpgradeBrief: "冒险中一次永久提升1点生命上限；每回合开始时，改为治疗任意角色1点生命。",
			innateShieldWall: "盾墙",
			innateShieldWallBrief: "战斗开始时，可以投掷全部白色防御骰，并把结果放入主动槽；这次投掷的骨头不能放入备用计划。",
			innateShieldWallUpgrade: "齿轮族之墙",
			innateShieldWallUpgradeBrief: "战斗中也可以把白色防御骰放入锁定槽；锁定的防御骰不减少可用的防御骰数量。",
			innateRage: "怒气",
			innateRageBrief: "起始持有怒气骰并置于主动槽，数值为1.0。攻击或失去生命时怒气上升，可在自己回合释放。",
			innateRageUpgrade: "无畏怒气",
			innateRageUpgradeBrief: "忽略所有怒气崩溃结果，怒气不会因此重置。",
			boardPlaceholder: "选择角色后显示玩家面板",
			skillsLabel: "技能",
			skillSeparator: "、",
			noSkills: "尚未取得技能骰",
			grenades: "炸弹",
			axes: "斧头",
			bodyCountShort: "击杀数",
			cellsLabel: "能量电池",
			rageShort: "怒气",
			name: "骸骨险境",
			moreOptions: "更多操作",
			battleProgress: "第{{day}}/{{days}}天 · 进度{{p}}/{{total}}",
			battlefield: "四乘四战场",
			enemyRoster: "敌人一览",
			initiativeScore: "先攻",
			flowDeadline: "期限至第{{n}}天",
			flowProgress: "远征进度 {{n}}/{{total}}",
			flowBossLocked: "还需{{n}}点进度才可挑战暴君。",
			flowOverload: "请先整理战利品。每名队员最多携带4格战利品。",
			flowParty: "队伍",
			flowReady: "已准备完成",
			flowActing: "待行动",
			flowWaiting: "等待{{name}}",
			flowEmptyLoot: "暂无战利品。",
			flowLockProgress: "已打开{{n}}/{{total}}道锁",
			flowLockTitle: "开锁 · {{name}}",
			flowLockTotal: "{{type}}合计 {{n}}/{{total}}",
			flowRetryLock: "重试本次面对的第一道锁",
			flowMinimize: "暂时收起",
			flowResumeLock: "继续开锁",
			flowViewLock: "查看开锁",
			flowLockUsed: "今日开锁机会已用",
			flowConfirmDiscard: "确认弃置",
			flowBackLoot: "返回物品栏",
			flowEncounterReward: "成功奖励",
			flowFirstEncounter: "首日遭遇",
			flowBogEncounter: "沼泽遭遇",
			flowEachTraining: "每人{{n}}个训练点",
			flowEachLoot: "每人{{n}}张战利品",
			flowLeaderLoot: "队长获得{{n}}张战利品",
			flowEachTrove: "每人{{n}}张珍宝",
			flowLeaderTrove: "队长获得{{n}}张珍宝",
			flowChooseHero: "选择出战角色",
			flowSelectRoute: "先选择路线",
			flowConfirmRoute: "确认「{{name}}」",
			flowTrainFailed: "{{name}}训练失败，请先训练另一项。",
			flowTrainSkill: "学习「{{name}}」 · 1训练点",
			flowTrainingPending: "请先用完训练点。",
			flowRest: "休息",
			flowSearch: "搜寻",
			flowScout: "侦察",
			flowNoHealing: "今天休息无法恢复生命。",
			flowSelectRest: "先选择休整行动",
			flowConfirmRest: "确认{{name}}",
			flowRestDone: "已完成{{name}}",
			flowSearchDiscard: "选择要弃置的战利品",
			flowSearchRoll: "弃置所选并投骰",
			flowReport: "远征简报",
			flowVictory: "队伍获胜",
			flowDefeat: "远征失败",
			flowTyrantDefeated: "暴君{{name}}已被击败。",
			flowTyrantUnbeaten: "未能在期限内击败暴君{{name}}。",
			flowLastDay: "结束日 {{n}}/{{total}}",
			yourTurn: "你的回合",
			chooseDice: "选择骰子",
			resolveDice: "使用骰子",
			rollCount: "投掷{{n}}颗骰子",
			chooseDeployment: "选择高亮起始格",
			chooseBoardTarget: "选择高亮目标",
			chooseMove: "选择高亮移动格",
			boardPosition: "第{{x}}列，第{{y}}行",
			unitHp: "{{name}}，生命{{n}}",
			moveTo: "移动至{{x}}·{{y}}",
			moveCost: "消耗{{n}}点敏捷",
			attackTarget: "攻击目标：{{name}}",
			noAttackTarget: "没有可攻击的目标",
			notEnoughDex: "剩余敏捷不足",
			attackFor: "攻击{{name}}（{{n}}点攻击）",
			storeDefense: "存入{{n}}点防御",
			collectBones: "收集{{n}}个骨头",
			skillTarget: "技能目标：{{name}}",
			slotsFull: "槽位已满，请选择其他用途或移除槽内骰子",
			useSkill: "使用{{name}}",
			chooseResolution: "选择骰子用途",
			activeFull: "主动槽已满，请选择其他用途或移除槽内骰子",
			defeatEnemies: "击倒全部敌人",
			defeatTyrant: "击败暴君",
			endUnused: "跳过未用骰子并结束回合",
			backupBoomer: "对宣告目标造成1点伤害。|重掷本回合所选的元素、弹壳或引信骰。|将任意一个单位移动到合法空格。|对宣告目标造成3点伤害。|本回合不能被选为目标。|升级天赋。",
			backupPatches: "治疗任意角色1点生命。|对宣告的相邻目标造成2点近战伤害。|取得一颗技能骰。|消耗一枚能量电池，对一名敌人造成4点真实伤害。|升级天赋；生命上限与当前生命各提高1点。",
			backupPicket: "移除自身全部防御骰和已投出的防御结果，对宣告的相邻目标造成等量伤害。|重掷本回合所选骰子。|恢复2点生命，并获得2点防御。|移除自身全部防御骰和已投出的防御结果，对宣告的相邻目标造成等量伤害；若目标是敌人，再将其眩晕。|升级天赋。",
			backupTantrum: "怒气提高一档。|怒气降低一档。|将斧头补至3枚。|恢复4点生命。|升级天赋。",
			desc: "骸骨险境：成长骰驱动的合作冒险",
			rules: "目标：\n· 在暴君规定的天数内积累进度，挑战并击败暴君。\n准备：\n· 每人选择一名不同的齿轮族角色。\n· 选择暴君与难度，按角色板取得初始属性。\n每日流程：\n· 队长抽取遭遇，或在进度足够时挑战暴君。\n· 全队选择遭遇选项，执行挑战或战斗。\n· 成功后领取进度、战利品和训练点。\n· 恢复阶段可以交易战利品，每人可尝试开锁一次。\n· 每人选择休息、换取战利品或侦察，然后进入次日。\n战斗：\n· 角色放入近战或远程起始格，确定先攻顺序。\n· 每格移动消耗1点敏捷，投掷每颗骰子消耗1点敏捷。\n· 每回合可以投掷一次骰子，须将所选骰子同时投出；通常只能指定一个攻击目标。\n· 选择骰子的结算顺序，技能也可以暂不使用。\n· 按骰子的类型和技能说明，将防御骰或技能骰放入主动槽或锁定槽；主动槽和锁定槽各有三个。\n· 骨头可以用于备用计划，每回合最多使用一次。\n· 回合结束时，最多保留5个骨头。积累6个骨头时，可以升级天赋。\n· 第6轮开始，每轮开始时所有单位失去1点生命。\n· 击倒全部敌人赢得普通战斗，击败暴君赢得冒险。\n训练与开锁：\n· 训练生命、敏捷，或学习已经满足前置条件的技能时，训练必定成功。\n· 攻击训练不能出现骨头；防御训练可重掷失败骰一次。\n· 训练失败后，必须将该训练点用于另一种训练项目。\n· 开锁依次处理机关、绊线与蛮力锁，同类骰的数值可相加。\n· 使用过的开锁骰耗尽，已打开的锁跨日保留。\n· 直觉骰可以转换骰子类型、重新投掷一颗骰子，或保留一颗骰子并使其数值增加1。\n· 第一道面对的锁失败时，当天可立即重试一次。\n挑战与失败：\n· 弹骰遭遇采用拖拽瞄准、松手弹射，共有4次机会。\n· 至少命中3个树目标，且被命中的目标不能离开桌面。\n· 每张小游戏遭遇的目标、机会与奖励见当前遭遇说明。\n· 全队倒下会失去当日奖励，仍可恢复并继续冒险。\n· 超过暴君的天数限制仍未通关，冒险失败。",
			errAction: "当前不能这样行动，请检查阶段、目标和剩余资源。",
			recruit: "选择角色",
			training: "使用训练点",
			day: "新的冒险日",
			encounter: "选择遭遇方案",
			challenge: "完成遭遇挑战",
			battle: "战斗",
			recovery: "恢复与整备",
			done: "冒险结束",
			dayCount: "第{{n}}天 · 进度{{p}}/{{total}}",
			round: "第{{n}}轮",
			wait: "等待其他队员",
			boomer: "布玛 · 炸弹专家",
			patches: "帕奇斯 · 战地医师",
			picket: "皮克特 · 护卫",
			tantrum: "坦特朗 · 狂战士",
			tyrant: "暴君",
			difficulty: "难度",
			adventurer: "冒险者",
			heroic: "英雄",
			legendary: "传奇",
			nom: "诺姆",
			gendricks: "根德里克斯",
			duster: "达丝特",
			mulmesh: "穆尔梅什",
			drellen: "德雷伦",
			marrow: "马罗",
			goblinking: "哥布林王",
			hp: "生命",
			dex: "敏捷",
			attack: "攻击",
			defense: "防御",
			skill: "技能",
			trainingPoints: "训练点{{n}}",
			active: "主动槽",
			locked: "锁定槽",
			bones: "骨头",
			loot: "战利品",
			trove: "珍宝",
			exhausted: "已耗尽",
			available: "可用",
			ready: "准备完成",
			draw: "抽取遭遇",
			fightTyrant: "挑战暴君",
			choice: "选项{{n}}",
			confirm: "确认",
			cancel: "取消",
			target: "目标",
			position: "位置",
			deploy: "放置角色",
			move: "移动",
			roll: "投掷所选骰子",
			endTurn: "结束回合",
			remainingDex: "剩余敏捷{{n}}",
			use: "使用",
			store: "放入主动槽",
			lockStore: "放入锁定槽",
			discard: "弃置",
			saveBones: "放入备用计划",
			backup: "备用计划",
			rest: "休息并恢复全部生命",
			search: "弃置战利品并搜寻",
			scout: "侦察敌人",
			keep: "保留",
			cycle: "放至牌堆底",
			trade: "交给队友",
			lockpick: "尝试开锁",
			rollLock: "投掷开锁骰",
			reroll: "重掷",
			convert: "转换类型",
			save: "保留并增加1",
			solve: "打开当前锁",
			stop: "结束尝试",
			lever: "机关",
			trip: "绊线",
			force: "蛮力",
			lockPrompt: "第{{n}}道锁 · {{type}} {{value}}",
			craft: "合成炸弹",
			axe: "投掷斧头",
			bodyCount: "以击杀数治疗",
			rage: "释放怒气",
			advance: "提升怒气等级",
			execute: "处决",
			heal: "治疗",
			decrease: "降低",
			increase: "提高",
			release: "移除骰子",
			activate: "发动技能",
			startEffect: "结算回合开始效果",
			reaction: "结算响应",
			initiative: "调整先攻",
			orderReady: "确认先攻顺序",
			enemyTarget: "选择敌人攻击目标",
			enemyMove: "选择敌人移动路线",
			inspect: "查看组件",
			close: "关闭",
			history: "冒险记录",
			card: "遭遇{{id}}",
			inventory: "背包{{n}}/4",
			flick: "拖拽箭矢瞄准，松手弹射",
			flickLane: "第{{n}}条路线",
			shots: "已弹射{{n}}/4次",
			dartsSetup: "选择3颗骰子，每种最多2颗",
			poison: "状态骰",
			dartsRoll: "投掷飞镖骰",
			dartsPass: "放弃本次骨头",
			dartsClean: "移除中毒",
			dartsDefense: "移除对方防御",
			dartsStun: "眩晕对手",
			dartsWin: "直接击倒对手",
			amount: "数量",
			damage: "伤害",
			effect: "效果",
			point: "{{n}}点敌人",
			logLine: "{{who}} {{event}} {{target}} {{n}}",
			actions: "行动",
			details: "详情",
			noTarget: "不指定目标",
			die: "骰子",
			free: "免费",
			selected: "已选择",
			aim: "选择{{skill}}的落点",
			strongest: "目标：生命最高者",
			weakest: "目标：生命最低者",
			targets: "{{n}}个目标",
			ranged: "远程",
			melee: "近战",
			logEvents: "获得临时生命|受到伤害|冒险失败|抽取遭遇|挑战掷骰|完成弹射|进入战斗|击败|施加状态|敌人掷骰|鼓舞|倒下|使用战利品|复活|进入战斗轮次|暴君掷骰|冒险成功|飞镖掷骰|开始开锁|开锁成功|开锁失败|搜寻战利品|发动备用计划|提升怒气|掷骰|完成训练|尝试训练|恢复生命|获得战利品|获得珍宝|遭遇成功|遭遇失败",
			decision: "完成当前遭遇步骤",
			startingLoot: "选择保留的一张战利品",
			troveRedraw: "保留珍宝，或弃置后重抽一次",
			troveImmediate: "选择珍宝立即开锁，或跳过",
			discardThenRedraw: "选择需要弃置的战利品",
			bribe: "全队每名队员支付一张战利品",
			snipe: "选择本场战斗耗尽的攻击骰数量",
			grab: "选择尝试取得的战利品数量",
			whirlwind: "选择独自应战的角色",
			trapHp: "选择生命最接近掷骰结果的角色",
			duel: "选择先行出战的角色",
			scoutReturn: "选择侦察的敌人等级",
			exhaustStats: "选择全队各自耗尽的攻击骰和防御骰数量",
			barrelCount: "选择一至四个木桶",
			gambleLoot: "选择投入赌局的战利品",
			offering: "选择献出的战利品",
			tripSkills: "选择下次战斗耗尽的三颗技能骰",
			wolfHand: "选择伸出手的角色",
			healDuster: "选择用于治疗达丝特的战利品",
			bogIngredients: "选择六枚1点敌人，或三枚5点敌人",
			goblinBomb: "选择准备拆解的锁类型",
			pendingReaction: "处理{{name}}的响应",
			pass: "跳过",
			double: "同时使用两颗",
			unitTurn: "{{name}}的回合",
			challengeValues: "挑战状态",
			playerSide: "我方",
			opponentSide: "对手",
			chooseLoot: "选择战利品",
			chooseSkills: "选择技能骰",
			scoutLevels: "1点|5点|20点",
			baddiesWaiting: "待入场敌人{{n}}枚",
			baddieNames: "幼恶狼|幼狮鹫|顽童巨魔|蛮力巨魔|年轻巨魔|兽人侦察兵|兽人士兵|兽人苦工|沼泽蝌蚪|黏土魔像|沼泽蛙|哥布林暴徒|哥布林投弹手|哥布林沙袋手|狗头人园丁|幼龙|雏龙|狗头人追踪者|恶狼|枭熊|嚎叫狮鹫|巨魔贤者|巨魔执法者|哥布林警报兵|哥布林工兵|兽人战争贩子|兽人狂暴者|狗头人精锐|叛逆龙|狗头人狂热者|沼泽潜伏者|石魔像|蝎尾狮|黄金魔像|荣耀狮鹫|恶狼首领|凶猛枭熊|远古巨龙|骨龙|沼泽蠕龙",
			objectNames: "宝珠|宝珠柱|王座|老鼠|黑衣人|商人",
			progressShort: "进度奖励：{{n}}",
			effectNames: "攻击|防御|骨头|骨头|可复用骨头|元素|弹壳|引信|炸弹库存|爆炸|全体敌人伤害|全队反冲|自身反冲|眩晕|燃烧|净化|烟幕|禁用|零件|战利品|临时生命|更大爆炸|获得神圣手榴弹|元素325|神圣爆破|神圣爆炸|治疗|治疗倍增|治疗重掷|近战伤害|真实伤害|复活|复活|中毒|中毒|临时攻击|药剂重掷|持续治疗|强化注射|永久生命|有毒混合物|持续再生|免费移动|持续防御|持续伤害|持续嘲讽|强化防御训练|高级防御|拦截|麦酒|自我治疗|换位|突进|还击|怒气调整|提升怒气|获得斧头|毒甲|反击|坚韧|降低先攻|削弱攻击|提高攻击|攻击训练|全队鼓舞|全体眩晕|跳跃|嘲讽|怒气|斧头|击杀数|能量电池|空白|中毒|流血|虚弱|恐惧|不可选为目标|飞行|限制|先攻",
			skillsBoomer: "元素|弹壳|引信|炸弹计数|破片炸弹|大爆炸|烟幕|净化音爆|震撼弹|燃烧弹|闪光弹|炸弹袋|搜身|更大爆炸|寻找325|神圣手榴弹",
			skillsPatches: "医疗包|快手|骨锯|生命药水|营养剂|毒素|大医疗包|毒镖|兴奋剂|化学药剂|电击背包|能量电池|蒸馏器|兴奋剂腰带|链式反应|致命兴奋剂",
			skillsPicket: "坚守阵地|盾牌阵形|红衫替身|兽人麦酒|挥剑推进|封锁|拦截|哥布林肉干|换位|突进|信心|毅力|还击|随机应变|勇武|威望",
			skillsTantrum: "怒气|盛怒|狂怒|愤怒管理|模仿蠕龙|模仿恶狼|模仿狗头人|斧头收藏|威吓|致残|荒野之道|狂战士号角|振奋|强化|乌木之道|击杀计数",
			lootNames: "信号干扰弹|幸运发现|新鲜沼泽肉|机械臂|浸香|上场战斗的炖菜|机械助力|机械开锁器|混合浆果|多用工具|奥格特草药|撬棍|掠夺者护甲|红牛头人|反射粉|加固小圆盾|生锈目镜|剥皮刀|陪练武器|乌木烈酒|石锤|破旧地图|特瓦伦宝石|投掷斧|藏宝图|巨魔酿酒|实用零件|泽尔菲根|泽尔菲种子|瓶装水",
			troveNames: "||敏捷注射器|爆炸蘑菇|闪光箭||抓钩枪|猎人战绩项链|激光笔|闪电棒|锁匠手册|极效兴奋剂|机械回旋镖|机械松鼠|微型神经植入物|小型修补包|点锁 2000 型|毒瓶套装|反射粉罐|电击诱导器|肩扛石弹发射器|小型望远镜|实用腰带",
			win: "暴君已被击败，冒险成功！",
			lose: "天数耗尽，冒险失败。"
		},
		en: {
			flowCanLearn: "Available to learn",
			flowSkillLocked: "Locked",
			flowSkillPrerequisite: "Prerequisite · {{name}}",
			flowRequiredProgress: "{{n}} progress to challenge",
			flowUndo: "Undo",
			flowConfirmLearn: "Confirm skill",
			flowConfirmTraining: "Confirm training",
			flowFinishTraining: "Finish training",
			flowTrainingRollInfo: "Confirm to roll. Spend one training point only if training succeeds.",
			flowUnlocked: "Unlocked: {{names}}",
			flowBag: "Backpack",
			flowLootUses: "{{n}} uses",
			flowKeepName: "Keep {{name}}",
			flowRecruitName: "Recruit {{name}}",
			flowRewardRecipient: "Recipient: {{name}}",
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			creature: "Baddie type",
			creatureNames: "Troll|Orc|Scales|Goblin|Bog|Beast",
			flickAdjust: "Adjust shot",
			flickAngle: "Direction",
			flickPower: "Power",
			flickShoot: "Shoot",
			...na,
			encounters: Ki,
			playerAid: "Player aid",
			startingSkills: "Starting skills",
			noStartingSkills: "No starting skills",
			chosen: "Chosen",
			skillTree: "Skill tree",
			viewSkillTree: "View skill tree",
			innate: "Innate",
			innateUpgrade: "Innate +1",
			learned: "Learned",
			startingDie: "Starting",
			consumableTag: "Consumable",
			consumableNote: "Consumable skills cannot be acquired by training.",
			facesLabel: "Faces",
			counterDie: "Counter die; never rolled.",
			noPrereq: "No prerequisite.",
			prereqList: "Requires: {{skills}}",
			trainSkill: "Train this skill",
			treeLegend: "Filled: learned; brass outline: available to train; faded: prerequisites unmet; dashed: consumable.",
			backupNote: "Use at most once per turn. Loot that reduces the cost applies to every option except the Innate upgrade. The Innate upgrade cannot be chosen again after it is upgraded.",
			backupCostPaid: "Costs {{n}} Bones",
			tyrantFaces: "Tyrant die faces",
			tyrantFaceNames: "Om Nom|Thunderclub|Orb|Charred|Cloak|Dagger|Silver Hide|Howl|Enhance|Poison|Blood Rage|Skull Axe|Call Help|Careless Bomb",
			tyrantFaceRules: "Before attacking, remove all Defense dice from the target’s Active and Locked slots and clear its armor.|After attacking, the target suffers 1 True Damage and moves to the farthest empty space from it.|Spawn a 4 HP Orb on the indicated lane; it has 3 HP if the third Orb Pillar is complete.|The lowest-HP Kobold suffers 1 damage; if it survives, it jumps next to the nearest Gearloc and deals 2 damage.|Swap with the next Gearloc and remove it from the mat; it returns after any Gearloc is knocked out.|This turn’s attack makes the target Bleed 1.|Attacks against this Tyrant deal 0 damage this round; resets at the Tyrant’s next turn start.|Every other living baddie moves up one initiative position.|If a target is already poisoned, raise its Poison to 3.|Each target gains Poison 2.|Remove Skull Axe, retreat up to two spaces, then heal 3 HP.|This turn’s attack deals True Damage.|Add a reinforcement to the waiting stack: a 1Pt baddie with two or fewer Gearlocs, otherwise a 5Pt baddie.|The highest-HP baddie and its adjacent units suffer 3 damage.",
			enemyRolled: "Rolled {{n}} Attack dice: {{values}}",
			enemyRolledBones: "Gained {{n}} Bones",
			tyrantRolled: "Tyrant face: {{face}}",
			intentLine: "Attack {{attack}} · Defense {{defense}} · HP {{hp}}/{{max}}",
			intentTargets: "Targets: {{names}}",
			defenseDiceLine: "{{n}} stored Defense",
			whiteAttackDie: "Six faces of a white Attack die",
			whiteDefenseDie: "Six faces of a white Defense die",
			profBoomerScavenger: "Scavenger",
			profBoomerScavengerBrief: "Gather Element, Casing and Fuse to craft grenades.",
			profBoomerGrenadier: "Grenadier",
			profBoomerGrenadierBrief: "The main grenade damage line; each roll spends a grenade.",
			profBoomerBomber: "Utility Bomber",
			profBoomerBomberBrief: "Control the battle with Smoke Screen, Sonic Cleanse and Flashbang.",
			profBoomerKeenEye: "Keen Eye",
			profBoomerKeenEyeBrief: "Extra components, stronger grenades and Element 325.",
			profBoomerConsumables: "Consumables",
			profBoomerConsumablesBrief: "Bag’a Booms and Holy Hand Grenade consumables.",
			profPatchesMedic: "Combat Medic",
			profPatchesMedicBrief: "Core healing, melee damage and revival.",
			profPatchesForester: "Forester",
			profPatchesForesterBrief: "Healing, poison and the occasional Loot.",
			profPatchesStim: "Stim Stacker",
			profPatchesStimBrief: "Buff HP, Attack and lasting effects, with some self-harm.",
			profPatchesConsumables: "Consumables",
			profPatchesConsumablesBrief: "Liquid Life, Poison Dart and E-Cells consumables.",
			profPicketCaptain: "Captain",
			profPicketCaptainBrief: "Lockable Defense, regeneration, movement and damage bonuses.",
			profPicketHero: "Hero",
			profPicketHeroBrief: "The main line that turns Defense into damage.",
			profPicketProtector: "Protector",
			profPicketProtectorBrief: "Take attacks and effects aimed at allies.",
			profPicketWarden: "Warden",
			profPicketWardenBrief: "Control positions with Switch, Rush and Riposte.",
			profPicketConsumables: "Consumables",
			profPicketConsumablesBrief: "Orcish Ale and Gobby Jerky consumables.",
			profTantrumZerker: "Zerker",
			profTantrumZerkerBrief: "Build and release Rage, the core damage line.",
			profTantrumMimic: "Mimic",
			profTantrumMimicBrief: "Poison Armor, Lashback and Hardy battle stances.",
			profTantrumSkirmisher: "Skirmisher",
			profTantrumSkirmisherBrief: "Adjust initiative, reposition, cripple and taunt.",
			profTantrumConsumables: "Consumables",
			profTantrumConsumablesBrief: "Axe supply, party inspire and Body Count.",
			innateScavenger: "Scavenger",
			innateScavengerBrief: "Start with Element, Casing, Fuse and Boom Counter dice in your Skills Area, with the counter at 0. One of each component crafts a grenade.",
			innateScavengerUpgrade: "Resourceful Scavenger",
			innateScavengerUpgradeBrief: "Before locking Element, Casing or Fuse dice, add 1 to each result. On Bones, you may instead uptick that component to 1.",
			innateRecovery: "Recovery",
			innateRecoveryBrief: "At the start of your turn, heal yourself for 1 HP.",
			innateRecoveryUpgrade: "Major Recovery",
			innateRecoveryUpgradeBrief: "Once per Adventure, permanently increase your HP stat by 1. At the start of your turn, heal any Gearloc for 1 HP instead.",
			innateShieldWall: "Shield Wall",
			innateShieldWallBrief: "At battle start, you may roll all your white Defense dice and place the results in Active slots. Bones from this roll cannot enter your Backup Plan.",
			innateShieldWallUpgrade: "Gearloc Wall",
			innateShieldWallUpgradeBrief: "You may also place rolled white Defense dice in Locked slots, even during battle. Locked Defense dice do not reduce your available Defense dice.",
			innateRage: "Rage",
			innateRageBrief: "Start with the RAGE! die in an Active slot at 1.0. Attacking or losing HP raises your Rage, which you may release during your turn.",
			innateRageUpgrade: "Fearless Rage",
			innateRageUpgradeBrief: "Ignore all Breakdown results, so your Rage never resets because of them.",
			boardPlaceholder: "Choose a Gearloc to see your board",
			skillsLabel: "Skills",
			skillSeparator: ", ",
			noSkills: "No skill dice yet",
			grenades: "Grenades",
			axes: "Axes",
			bodyCountShort: "Body count",
			cellsLabel: "Batteries",
			rageShort: "Rage",
			name: "Too Many Bones",
			moreOptions: "More options",
			battleProgress: "Day {{day}}/{{days}} · Progress {{p}}/{{total}}",
			battlefield: "Four by four battle mat",
			enemyRoster: "Baddies",
			initiativeScore: "Initiative",
			flowDeadline: "Deadline: Day {{n}}",
			flowProgress: "Adventure progress {{n}}/{{total}}",
			flowBossLocked: "Earn {{n}} more progress to challenge the Tyrant.",
			flowOverload: "Organize your loot first. Each Gearloc can carry up to four slots of loot.",
			flowParty: "Party",
			flowReady: "Ready",
			flowActing: "To act",
			flowWaiting: "Waiting for {{name}}",
			flowEmptyLoot: "No loot yet.",
			flowLockProgress: "{{n}} of {{total}} locks opened",
			flowLockTitle: "Lockpicking · {{name}}",
			flowLockTotal: "{{type}} total {{n}}/{{total}}",
			flowRetryLock: "Retry the first lock of this attempt",
			flowMinimize: "Minimize",
			flowResumeLock: "Resume lockpicking",
			flowViewLock: "View lockpicking",
			flowLockUsed: "Lockpicking attempt used today",
			flowConfirmDiscard: "Confirm discard",
			flowBackLoot: "Back to loot",
			flowEncounterReward: "Rewards for success",
			flowFirstEncounter: "First-day encounter",
			flowBogEncounter: "Bog encounter",
			flowEachTraining: "{{n}} training points each",
			flowEachLoot: "{{n}} loot each",
			flowLeaderLoot: "{{n}} loot for the party leader",
			flowEachTrove: "{{n}} trove loot each",
			flowLeaderTrove: "{{n}} trove loot for the party leader",
			flowChooseHero: "Choose a Gearloc",
			flowSelectRoute: "Select a route first",
			flowConfirmRoute: "Confirm “{{name}}”",
			flowTrainFailed: "Training failed for {{name}}. Train something else first.",
			flowTrainSkill: "Learn {{name}} · 1 training point",
			flowTrainingPending: "Spend your remaining training points first.",
			flowRest: "Rest",
			flowSearch: "Search",
			flowScout: "Scout",
			flowNoHealing: "Rest cannot restore HP today.",
			flowSelectRest: "Select a recovery action first",
			flowConfirmRest: "Confirm {{name}}",
			flowRestDone: "Completed: {{name}}",
			flowSearchDiscard: "Choose loot to discard",
			flowSearchRoll: "Discard and roll",
			flowReport: "Adventure report",
			flowVictory: "Party victory",
			flowDefeat: "Adventure lost",
			flowTyrantDefeated: "{{name}} was defeated.",
			flowTyrantUnbeaten: "The deadline passed before {{name}} was defeated.",
			flowLastDay: "Final day {{n}}/{{total}}",
			yourTurn: "Your turn",
			chooseDice: "Choose dice",
			resolveDice: "Use dice",
			rollCount: "Roll {{n}} dice",
			chooseDeployment: "Choose a highlighted starting space",
			chooseBoardTarget: "Choose a highlighted target",
			chooseMove: "Choose a highlighted space",
			boardPosition: "Column {{x}}, row {{y}}",
			unitHp: "{{name}}, {{n}} HP",
			moveTo: "Move to {{x}}·{{y}}",
			moveCost: "Spend {{n}} Dexterity",
			attackTarget: "Attack target: {{name}}",
			noAttackTarget: "No target in attack range",
			notEnoughDex: "Not enough Dexterity",
			attackFor: "Attack {{name}} for {{n}}",
			storeDefense: "Store {{n}} Defense",
			collectBones: "Collect {{n}} Bones",
			skillTarget: "Skill target: {{name}}",
			slotsFull: "Slots full: choose another use or release a die",
			useSkill: "Use {{name}}",
			chooseResolution: "Choose die use",
			activeFull: "Active slots full: choose another use or release a die",
			defeatEnemies: "Defeat all baddies",
			defeatTyrant: "Defeat the Tyrant",
			endUnused: "Skip unused dice and end turn",
			backupBoomer: "Deal 1 damage to the declared target.|Reroll the Element, Casing or Fuse dice selected this turn.|Move any unit to a legal space.|Deal 3 damage to the declared target.|Become untargetable this turn.|Upgrade your Innate.",
			backupPatches: "Heal any Gearloc 1 HP.|Deal 2 melee damage to the declared adjacent target.|Acquire one skill die.|Spend a cell to deal 4 True Damage to a baddie.|Upgrade your Innate; increase maximum and current HP by 1.",
			backupPicket: "Remove all your Defense dice and rolled Defense results to deal that much damage to the declared adjacent target.|Reroll the dice selected this turn.|Heal 2 HP and gain 2 Defense.|Remove all your Defense dice and rolled Defense results to deal that much damage to the declared adjacent target; if it is a baddie, also Stun it.|Upgrade your Innate.",
			backupTantrum: "Raise Rage one step.|Lower Rage one step.|Refill your axes to 3.|Heal 4 HP.|Upgrade your Innate.",
			desc: "A cooperative dice-building adventure",
			rules: "Goal:\n· Earn progress and defeat the Tyrant within its day limit.\nSetup:\n· Each player chooses a different Gearloc.\n· Choose a Tyrant and difficulty, then take starting stats.\nEach day:\n· The leader draws an Encounter or challenges the Tyrant when eligible.\n· Choose an option together and resolve its challenge or battle.\n· On success, gain progress, loot and training points.\n· During recovery, trade loot and make one lockpicking attempt each.\n· Each Gearloc rests, searches for loot or scouts, then starts a new day.\nBattle:\n· Deploy in melee or ranged starting positions and set initiative.\n· Moving one position costs 1 Dex; rolling each die costs 1 Dex.\n· Roll selected dice together once per turn, normally declaring one target.\n· Choose the order of die resolution; unused skills can be kept.\n· Place defense dice or skill dice in Active or Locked slots according to their type and skill rules. There are three slots of each kind.\n· Spend Bones on a Backup Plan at most once per turn.\n· Keep up to 5 Bones at the end of your turn. Accumulating 6 Bones lets you upgrade your Innate.\n· From round 6, all units lose 1 HP at each round start.\n· Defeat all baddies in ordinary battles; defeat the Tyrant to win.\nTraining and locks:\n· Health, Dex and eligible skill training always succeed.\n· Attack training succeeds only if you roll no Bones. When training Defense, you may reroll the failed dice once.\n· After failure, spend the point on a different training choice.\n· Solve Lever, Trip and Force locks in order by totaling matching dice.\n· Used action dice exhaust; opened locks stay open across days.\n· Intuition lets you convert a die’s type, reroll one die, or keep one die and increase its value by 1.\n· Failure on the first lock faced allows one immediate retry that day.\nChallenges and defeat:\n· Flick challenges use drag to aim and release to shoot, with 4 shots.\n· Hit at least 3 tree targets without knocking those targets off the table.\n· Each minigame lists its own objectives, attempts and rewards.\n· A party knockout loses today’s rewards; recover and continue.\n· Exceeding the Tyrant’s day limit ends the adventure in defeat.",
			errAction: "That action is unavailable. Check the phase, target and resources.",
			recruit: "Choose a Gearloc",
			training: "Spend training points",
			day: "A new day",
			encounter: "Choose an Encounter option",
			challenge: "Complete the challenge",
			battle: "Battle",
			recovery: "Recovery",
			done: "Adventure over",
			dayCount: "Day {{n}} · Progress {{p}}/{{total}}",
			round: "Round {{n}}",
			wait: "Waiting for the party",
			boomer: "Boomer · Grenadier",
			patches: "Patches · Combat medic",
			picket: "Picket · Protector",
			tantrum: "Tantrum · Zerker",
			tyrant: "Tyrant",
			difficulty: "Difficulty",
			adventurer: "Adventurer",
			heroic: "Heroic",
			legendary: "Legendary",
			nom: "Nom",
			gendricks: "Gendricks",
			duster: "Duster",
			mulmesh: "Mulmesh",
			drellen: "Drellen",
			marrow: "Marrow",
			goblinking: "Goblin King",
			hp: "Health",
			dex: "Dexterity",
			attack: "Attack",
			defense: "Defense",
			skill: "Skill",
			trainingPoints: "{{n}} training points",
			active: "Active",
			locked: "Locked",
			bones: "Bones",
			loot: "Loot",
			trove: "Trove",
			exhausted: "Exhausted",
			available: "Available",
			ready: "Ready",
			draw: "Draw Encounter",
			fightTyrant: "Challenge Tyrant",
			choice: "Option {{n}}",
			confirm: "Confirm",
			cancel: "Cancel",
			target: "Target",
			position: "Position",
			deploy: "Deploy",
			move: "Move",
			roll: "Roll selected dice",
			endTurn: "End turn",
			remainingDex: "{{n}} Dex remaining",
			use: "Use",
			store: "Place in Active",
			lockStore: "Place in Locked",
			discard: "Discard",
			saveBones: "Add to Backup Plan",
			backup: "Backup Plan",
			rest: "Rest and recover all HP",
			search: "Discard loot and search",
			scout: "Scout",
			keep: "Keep",
			cycle: "Move to bottom",
			trade: "Give to ally",
			lockpick: "Attempt lockpicking",
			rollLock: "Roll lock dice",
			reroll: "Reroll",
			convert: "Convert type",
			save: "Save and add 1",
			solve: "Open current lock",
			stop: "End attempt",
			lever: "Lever",
			trip: "Trip",
			force: "Force",
			lockPrompt: "Lock {{n}} · {{type}} {{value}}",
			craft: "Craft grenade",
			axe: "Throw axe",
			bodyCount: "Heal with Body Count",
			rage: "Release Rage",
			advance: "Advance Rage",
			execute: "Execute",
			heal: "Heal",
			decrease: "Decrease",
			increase: "Increase",
			release: "Remove die",
			activate: "Activate skill",
			startEffect: "Resolve start-of-turn effect",
			reaction: "Resolve reaction",
			initiative: "Adjust initiative",
			orderReady: "Confirm initiative",
			enemyTarget: "Choose baddie target",
			enemyMove: "Choose baddie route",
			inspect: "Inspect components",
			close: "Close",
			history: "Adventure log",
			card: "Encounter {{id}}",
			inventory: "Inventory {{n}}/4",
			flick: "Drag the arrow to aim; release to shoot",
			flickLane: "Lane {{n}}",
			shots: "{{n}}/4 shots taken",
			dartsSetup: "Choose 3 dice, at most 2 of each kind",
			poison: "Status die",
			dartsRoll: "Roll darts dice",
			dartsPass: "Skip Bones",
			dartsClean: "Remove Poison",
			dartsDefense: "Remove enemy defense",
			dartsStun: "Stun opponent",
			dartsWin: "Knock out opponent",
			amount: "Amount",
			damage: "Damage",
			effect: "Effect",
			point: "{{n}} point baddie",
			logLine: "{{who}} {{event}} {{target}} {{n}}",
			actions: "Actions",
			details: "Details",
			noTarget: "No target",
			die: "Die",
			free: "Free",
			selected: "Selected",
			aim: "Choose a position for {{skill}}",
			strongest: "Targets highest HP",
			weakest: "Targets lowest HP",
			targets: "{{n}} targets",
			ranged: "Ranged",
			melee: "Melee",
			logEvents: "Gained Buff HP|Took damage|Adventure lost|Drew Encounter|Challenge roll|Flicked|Started battle|Defeated|Applied effect|Baddie roll|Inspired|Knocked out|Used Loot|Revived|Started round|Tyrant roll|Adventure won|Darts roll|Started lockpicking|Lock solved|Lock failed|Searched for Loot|Used Backup Plan|Advanced Rage|Rolled|Trained|Training attempt|Healed|Gained Loot|Gained Trove|Encounter succeeded|Encounter failed",
			decision: "Complete this Encounter step",
			startingLoot: "Choose one Loot to keep",
			troveRedraw: "Keep the Trove or discard it and draw again once",
			troveImmediate: "Choose a Trove to pick now, or skip",
			discardThenRedraw: "Choose the Loot to discard",
			bribe: "Pay one Loot per party member",
			snipe: "Choose Attack dice to exhaust for this battle",
			grab: "Choose how many Loot to attempt to grab",
			whirlwind: "Choose the Gearloc to fight alone",
			trapHp: "Choose the Gearloc whose HP is closest to the roll",
			duel: "Choose the Gearloc to enter first",
			scoutReturn: "Choose a Baddie point value to scout",
			exhaustStats: "Choose Attack and Defense dice each Gearloc exhausts",
			barrelCount: "Choose one to four barrels",
			gambleLoot: "Choose Loot to wager",
			offering: "Choose the offered Loot",
			tripSkills: "Choose three skills to exhaust at the next battle",
			wolfHand: "Choose the Gearloc to offer a hand",
			healDuster: "Choose Loot used to heal Duster",
			bogIngredients: "Choose six 1Pt or three 5Pt Baddies",
			goblinBomb: "Choose the lock type to disarm",
			pendingReaction: "Resolve {{name}}’s response",
			pass: "Pass",
			double: "Use two together",
			unitTurn: "{{name}}’s turn",
			challengeValues: "Challenge state",
			playerSide: "You",
			opponentSide: "Opponent",
			chooseLoot: "Choose Loot",
			chooseSkills: "Choose skill dice",
			scoutLevels: "1Pt|5Pt|20Pt",
			baddiesWaiting: "{{n}} Baddies waiting",
			baddieNames: "Dire Wolf Pup|Griffin Yearling|Troll Romper|Troll Brute|Troll Young’un|Orc Scout|Orc Grunt|Orc Peon|Bog Pole|Clay Golem|Bog Frog|Goblin Rioter|Goblin Bomber|Goblin Sandbagger|Kobold Greenthumb|Dragon Whelp|Dragon Hatchling|Kobold Tracker|Dire Wolf|Owlbear|Griffin Howler|Troll Sage|Troll Enforcer|Goblin Alarmist|Goblin Sapper|Orc Warmonger|Orc Rager|Kobold Elite|Dragon Delinquent|Kobold Fanatic|Bog Lurk|Stone Golem|Manticore|Golden Golem|Honor Griffin|Dire Wolf Alpha|Ferocious Owlbear|Dragon Elder|Bone Dragon|Bog Wyrm",
			objectNames: "Orb|Orb pillar|Throne|Rat|Cloaked figure|Trader",
			progressShort: "Progress reward: {{n}}",
			effectNames: "Attack|Defense|Bones|Bones|Reusable Bones|Element|Casing|Fuse|Grenades|Explosion|Damage all baddies|Party Backlash|Backlash|Stun|Napalm|Cleanse|Smoke|Disable|Parts|Loot|Buff HP|Bigger Boom|Acquire Holy Hand Grenade|Element 325|Holy Blast|Holy Explosion|Heal|Heal Assist|Reroll Heal|Melee Damage|True Damage|Revive|Revive|Poison|Poison|Buff Attack|Reroll Buff|Recover|Booster|Permanent HP|Tainted Mixture|Constant Regen|Free Move|Constant Defense|Constant Damage|Constant Taunt|Improved Defense Training|Advanced Defense|Intercept|Ale|Heal Self|Switch|Rush|Riposte|Anger|Advance Rage|Steal Axe|Poison Armor|Lashback|Hardy|Drop Initiative|Reduce Attack|Increase Attack|Train Attack|Party Inspire|Disorient All|Jump|Taunt|Rage|Axes|Body Count|Energy Cells|Blank|Poison|Bleed|Weaken|Terrify|Untargetable|Flight|Limit|Initiative",
			skillsBoomer: "Element|Casing|Fuse|Boom Counter|Frag|Big Boom|Smoke Screen|Sonic Cleanse|Stunner|Napalm|Flashbang|Bag’a Booms|Body Search|Bigger Boom|Search for 325|Holy Hand Grenade",
			skillsPatches: "Med Kit|Fast Hands|Bone Saw|Liquid Life|Nutrients|Toxins|Med Pack|Poison Dart|Stim Kit|Chem Kit|Zappack|E-Cells|Distiller|Stim Belt|Chain Reactor|Stim Lethal",
			skillsPicket: "Stand Ground|Shield Form|Redshirt|Orcish Ale|Sword Advance|Lockdown|Intercept|Gobby Jerky|Switch|Rush|Confidence|Tenacity|Riposte|Situational Awareness|Bravado|Renown",
			skillsTantrum: "RAGE!|RAAAGE!|RAAAAAGE!|Anger Management|Like a Wyrm|Like a Wolf|Like a Kobold|Axe Collector|Intimidate|Cripple|Way of the Wild|Horn o’ the Zerker|Innervate|Strengthen|Way of the Ebon|Body Count",
			lootNames: "Flare Distraction|Fortunate Discovery|Fresh Bog Meat|Gadget Arm|Infused Incense|Last Battle Stew|Mechanical Assistance|Mech-pick|Mixed Berries|Multi-tool|Oggot Herbs|Prying Iron|Raider Armor|Red Minotaur|Reflex Powder|Reinforced Buckler|Rusty Optics|Skinning Knife|Sparring Weapon|Spirits of Ebon|Stone Hammer|Tattered Map|Tewaren Gem|Throwing Axe|Treasure Trove Map|Troll Brew|Utility Parts|Zelfey Root|Zelfey Seeds|Bottled Water",
			troveNames: "||Dex Infuser|Exploding Shrooms|Flash Arrows||Grappling Gun|Hunter’s Body Count Necklace|Laser Pointer|Lightning on a Stick|Locksmith Manual|Maximizer Stim|Mechanical Boomerang|Mechanical Squirrel|Micro Neural Implant|Minor Patch Kit|Pip-Loc 2000|Poison Vial Kit|Reflex Powder Tin|Shock Inducer|Shoulder-mounted Rock Slinger|Small Spotting Scope|Utility Belt",
			win: "The Tyrant is defeated. Adventure won!",
			lose: "The day limit is exceeded. Adventure lost."
		}
	}
};
//#endregion
export { ra as default };
