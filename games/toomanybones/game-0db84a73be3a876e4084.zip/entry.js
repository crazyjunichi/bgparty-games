import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as u } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { IconBack as m, IconBot as h, IconCheck as g, IconClose as _, IconExpand as v, IconLog as y } from "@bgparty/sdk/icons";
import { seatName as b } from "@bgparty/sdk/ui/player-strip";
import { Confetti as x } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as S, OptionSection as ee } from "@bgparty/sdk/ui/game-options";
//#region src/games/toomanybones/baddies.ts
function C(e, t, n, r, i, a, o, s, c, l = "") {
	let [u = "", d = ""] = c.split("/"), f = (e) => Object.fromEntries(e.split(",").filter(Boolean).map((e) => {
		let [t, n] = e.split(":");
		return [t, n === void 0 ? 1 : Number(n)];
	}));
	return {
		id: e,
		point: t,
		copies: n,
		creature: r,
		hp: i,
		initiative: a,
		attack: o,
		defense: s,
		ranged: l.includes("ranged"),
		target: l.includes("strongest") ? "strongest" : "weakest",
		targets: l.includes("three") ? 3 : l.includes("two") ? 2 : 1,
		diagonal: l.includes("diagonal"),
		extra: l.includes("extra2") ? 2 : +!!l.includes("extra1"),
		skills: f(u),
		backup: f(d),
		backupCost: l.includes("bp2") ? 2 : 1
	};
}
var w = [
	C("direwolfpup", 1, 2, "beast", 3, 3, 1, 0, "lashback:1"),
	C("griffinyearling", 1, 2, "beast", 2, 5, 2, 0, "flight"),
	C("trollromper", 1, 2, "troll", 3, 2, 1, 0, "thickSkin:1/careless:1"),
	C("trollbrute", 1, 2, "troll", 3, 1, 1, 1, "thickSkin:1/careless:1", "ranged"),
	C("trollyoungun", 1, 1, "troll", 4, 3, 1, 1, "/careless:1"),
	C("orcscout", 1, 2, "orc", 3, 4, 1, 0, "raiding"),
	C("orcgrunt", 1, 1, "orc", 4, 2, 1, 1, "raiding", "strongest"),
	C("orcpeon", 1, 2, "orc", 3, 3, 1, 0, "rage:1"),
	C("bogpole", 1, 1, "bog", 3, 3, 0, 0, "poison:1", "two"),
	C("claygolem", 1, 2, "bog", 5, 2, 1, 0, "break", "strongest"),
	C("bogfrog", 1, 2, "bog", 4, 3, 0, 0, "poison:2", "strongest"),
	C("goblinrioter", 1, 1, "goblin", 3, 4, 1, 0, "mischief:1", "ranged two"),
	C("goblinbomber", 1, 2, "goblin", 3, 5, 1, 0, "mischief:1/careless:1", "ranged two"),
	C("goblinsandbagger", 1, 1, "goblin", 2, 4, 1, 1, "/mischief:1"),
	C("koboldgreenthumb", 1, 1, "scales", 3, 4, 1, 0, "hardy", "strongest"),
	C("dragonwhelp", 1, 1, "scales", 2, 5, 2, 1, "weaken:1", "strongest"),
	C("dragonhatchling", 1, 1, "scales", 3, 6, 1, 0, "engulf"),
	C("koboldtracker", 1, 2, "scales", 2, 6, 0, 0, "hardy,compound"),
	C("direwolf", 5, 1, "beast", 6, 4, 4, 0, "lashback:2"),
	C("owlbear", 5, 1, "beast", 6, 4, 4, 0, "inspire:1,terrify"),
	C("griffinhowler", 5, 2, "beast", 5, 5, 3, 0, "dive,flight,signal:1", "strongest"),
	C("trollsage", 5, 1, "troll", 6, 4, 2, 1, "thickSkin:1/inspire:1", "strongest"),
	C("trollenforcer", 5, 2, "troll", 5, 2, 3, 2, "thickSkin:1/taunt"),
	C("goblinalarmist", 5, 2, "goblin", 6, 6, 1, 2, "signal:3", "ranged strongest"),
	C("goblinsapper", 5, 2, "goblin", 5, 4, 3, 0, "mischief:2,signal:1", "ranged"),
	C("orcwarmonger", 5, 1, "orc", 6, 4, 3, 2, "raiding/taunt", "strongest"),
	C("orcrager", 5, 2, "orc", 5, 3, 2, 0, "raiding,rage:2"),
	C("koboldelite", 5, 1, "scales", 5, 3, 0, 0, "hardy,compound", "two"),
	C("dragondelinquent", 5, 1, "scales", 7, 6, 2, 2, "engulf/weaken:2"),
	C("koboldfanatic", 5, 1, "scales", 6, 3, 3, 0, "hardy,inspire:1", "strongest"),
	C("boglurk", 5, 1, "bog", 6, 4, 0, 0, "poison:2", "three"),
	C("stonegolem", 5, 1, "bog", 7, 3, 3, 2, "break/corrosive", "strongest bp2"),
	C("manticore", 5, 1, "bog", 6, 3, 0, 0, "poison:2,rage:2", "two"),
	C("goldengolem", 20, 1, "bog", 9, 5, 5, 3, "break/recover:2", "strongest diagonal extra1"),
	C("honorgriffin", 20, 1, "beast", 8, 5, 5, 0, "dive,flight/stun", "strongest diagonal extra2 bp2"),
	C("direwolfalpha", 20, 1, "beast", 7, 5, 4, 0, "lashback:3,terrify,thickSkin:2", "diagonal extra1"),
	C("ferociousowlbear", 20, 1, "beast", 8, 6, 5, 0, "inspire:2,terrify,thickSkin:2", "diagonal extra1"),
	C("dragonelder", 20, 1, "scales", 8, 5, 3, 2, "weaken:2,flight", "ranged two"),
	C("bonedragon", 20, 1, "scales", 8, 4, 3, 0, "hardy,undead", "ranged two"),
	C("bogwyrm", 20, 1, "bog", 9, 6, 1, 0, "corrosive,poison:2", "ranged two")
], te = {
	nom: {
		...C("nom", 0, 1, "troll", 6, 2, 1, 1, "thickSkin:3,recover:1", "strongest diagonal"),
		days: 8,
		progress: 6,
		creatures: [
			"troll",
			"orc",
			"scales"
		],
		encounters: [1],
		slot: 0,
		faces: [
			"omnom",
			"thunderclub",
			"thunderclub",
			"omnom",
			"thunderclub",
			"thunderclub"
		]
	},
	gendricks: {
		...C("gendricks", 0, 1, "scales", 9, 4, 3, 2, "hardy/limit", "ranged two"),
		days: 10,
		progress: 8,
		creatures: [
			"scales",
			"bog",
			"orc",
			"troll"
		],
		encounters: [3, 4],
		slot: 2,
		faces: [
			"orb:2",
			"orb:4",
			"charred",
			"orb:1",
			"orb:3",
			"charred"
		]
	},
	duster: {
		...C("duster", 0, 1, "scales", 9, 6, 3, 2, "shrouded/limit:1,hide:2", "two diagonal"),
		days: 13,
		progress: 10,
		creatures: [
			"goblin",
			"troll",
			"bog",
			"beast",
			"scales"
		],
		encounters: [
			6,
			7,
			8
		],
		slot: 5,
		faces: [
			"cloak",
			"cloak",
			"dagger",
			"cloak",
			"cloak",
			"dagger"
		]
	},
	mulmesh: {
		...C("mulmesh", 0, 1, "beast", 8, 6, 2, 0, "frenzy:2,retreat,shrouded", "diagonal"),
		days: 9,
		progress: 6,
		creatures: [
			"beast",
			"bog",
			"scales"
		],
		encounters: [10],
		slot: 9,
		faces: [
			"silverHide",
			"silverHide",
			"howl",
			"howl",
			"silverHide",
			"howl"
		]
	},
	drellen: {
		...C("drellen", 0, 1, "bog", 8, 5, 3, 2, "bogRuler", "two"),
		days: 10,
		progress: 6,
		creatures: [
			"bog",
			"goblin",
			"beast"
		],
		encounters: [12],
		slot: 11,
		faces: [
			"enhance",
			"poison",
			"poison",
			"enhance",
			"enhance",
			"poison"
		]
	},
	marrow: {
		...C("marrow", 0, 1, "orc", 9, 5, 3, 3, "raiding/callOrc"),
		days: 12,
		progress: 10,
		creatures: [
			"orc",
			"goblin",
			"bog",
			"scales"
		],
		encounters: [14, 15],
		slot: 13,
		faces: [
			"bloodRage",
			"skullAxe",
			"skullAxe",
			"bloodRage",
			"bloodRage",
			"skullAxe"
		]
	},
	goblinking: {
		...C("goblinking", 0, 1, "goblin", 9, 5, 2, 3, "boom,kaboom", "ranged two"),
		days: 12,
		progress: 8,
		creatures: [
			"goblin",
			"troll",
			"bog",
			"beast"
		],
		encounters: [17, 18],
		slot: 16,
		faces: [
			"callHelp",
			"callHelp",
			"carelessBomb",
			"callHelp",
			"callHelp",
			"carelessBomb"
		]
	}
};
function T(e) {
	return w.find((t) => t.id === e) ?? te[e];
}
//#endregion
//#region src/games/toomanybones/cards.ts
var E = (e = 0, t = 0, n = 0, r = 0, i = 0, a = 0) => ({
	progress: e,
	training: t,
	loot: n,
	eachLoot: r,
	trove: i,
	eachTrove: a
}), D = (e, t, n, r, i, a = []) => ({
	id: e,
	sheet: t,
	slot: n,
	choices: r,
	reward: i,
	choiceRewards: a
}), ne = [
	D("s1", 1, 0, 2, E(1), [E(0, 2), E(0, 1)]),
	D("s2", 1, 1, 2, E(1, 1, 0, 1), [E(), E(0, 1)]),
	D("s3", 1, 2, 2, E(1), [E(0, 1), E(0, 0, 0, 0, 1)]),
	D("s4", 1, 3, 2, E(), [E(), E(2, 2, 0, 0, 0, 1)]),
	D("s5", 1, 4, 2, E(), [E(0, 1), E(0, 2, 0, 1)]),
	D("s6", 1, 5, 2, E(), [E(), E(1, 2, 0, 1)]),
	D("g1", 29, 0, 2, E(1, 2, 0, 1), [E(1), E()]),
	D("g2", 29, 1, 2, E(1, 2, 0, 1), [E(0, 1), E()]),
	D("g3", 29, 2, 2, E(1, 1, 0, 1), [E(0, 2), E()]),
	D("g4", 29, 3, 2, E(1, 2, 0, 1)),
	D("g5", 29, 4, 2, E(1, 1), [E(), E(0, 1, 0, 1)]),
	D("g6", 29, 5, 2, E(1, 2, 0, 1)),
	D("g7", 29, 6, 2, E(1, 1, 0, 1), [E(1), E(0, 1)]),
	D("g8", 29, 7, 2, E(1, 1), [E(0, 0, 0, 2), E(0, 0, 1)]),
	D("g9", 29, 8, 2, E(1, 2, 0, 1), [E(0, 0, 0, 1), E()]),
	D("g10", 29, 9, 1, E(1, 2), [E(0, 0, 1)]),
	D("g11", 29, 10, 2, E(1, 2, 0, 1)),
	D("g12", 29, 11, 2, E(1, 2), [E(0, 0, 0, 0, 2), E()]),
	D("g13", 29, 12, 2, E(1, 2), [E(), E(0, 0, 0, 1)]),
	D("g14", 29, 13, 2, E(1, 2, 0, 1), [E(), E(0, 1)]),
	D("g15", 29, 14, 2, E(1, 2, 0, 1), [E(), E(0, 0, 0, 0, 0, 1)]),
	D("g16", 29, 15, 2, E(1, 2, 0, 1), [E(0, 1), E()]),
	D("g17", 29, 16, 2, E(1, 2, 0, 1)),
	D("g18", 29, 17, 3, E(2, 2, 0, 1), [
		E(0, 0, 0, 0, 1),
		E(0, 1),
		E()
	]),
	D("g19", 29, 18, 2, E(1, 2, 0, 1)),
	D("g20", 29, 19, 2, E(1, 2, 0, 1)),
	D("g21", 29, 20, 2, E(1, 2), [E(0, 1, 0, 0, 0, 1), E()]),
	D("g22", 29, 21, 2, E(2, 2), [E(0, 1, 0, 0, 0, 1), E(0, 1)]),
	D("g23", 29, 22, 2, E(), [E(1, 2), E(1, 0)]),
	D("g24", 29, 23, 2, E(1), [E(0, 0, 0, 2, 0, 1), E()]),
	D("g25", 29, 24, 1, E(1, 1, 0, 1)),
	D("g26", 29, 25, 2, E(1, 1)),
	D("g27", 29, 26, 1, E(1, 1, 1)),
	D("g28", 29, 27, 1, E(1, 1)),
	D("g29", 29, 28, 1, E(1, 2)),
	D("g30", 29, 29, 1, E()),
	D("o1", 0, 0, 2, E(1, 2), [E(0, 0, 0, 2), E()]),
	D("o2", 0, 1, 2, E(0, 1, 0, 1), [E(1, 1), E(0, 1)]),
	D("o3", 0, 2, 2, E(1, 1, 0, 1), [E(), E(0, 1, 0, 0, 0, 1)]),
	D("o4", 0, 3, 2, E(1, 2, 0, 1)),
	D("o5", 0, 4, 2, E(1, 1), [E(0, 0, 2), E()]),
	D("o6", 0, 5, 2, E(1, 2, 0, 1)),
	D("o7", 0, 6, 2, E(1, 1), [E(0, 1, 0, 2), E(0, 1)]),
	D("o8", 0, 7, 2, E(1, 1), [E(0, 1, 0, 1), E()]),
	D("o9", 0, 8, 2, E(1, 1, 0, 1), [E(0, 0, 0, 2), E(0, 0, 0, 0, 0, 1)]),
	D("o10", 0, 9, 2, E(1, 2, 0, 1)),
	D("o11", 0, 10, 2, E(1, 2, 0, 1)),
	D("o12", 0, 11, 2, E(1, 1)),
	D("t1", 2, 1, 2, E(1, 1, 0, 1), [E(1, 1, 0, 1), E()]),
	D("t3", 2, 3, 1, E(1, 2, 0, 1)),
	D("t4", 2, 4, 2, E(1, 1, 0, 1), [E(), E(0, 1)]),
	D("t6", 2, 6, 2, E(1, 1, 0, 1), [E(0, 0, 0, 1), E(0, 1)]),
	D("t7", 2, 7, 1, E(1, 2, 0, 1)),
	D("t8", 2, 8, 2, E(1, 0, 0, 1), [E(0, 1), E()]),
	D("t10", 2, 10, 1, E()),
	D("t12", 2, 12, 2, E(), [E(0, 2), E(1, 1)]),
	D("t14", 2, 14, 1, E(1, 3, 0, 1)),
	D("t15", 2, 15, 2, E(1, 2, 0, 1)),
	D("t17", 2, 17, 2, E(1, 1, 0, 1)),
	D("t18", 2, 18, 1, E(1, 1, 0, 1))
], O = (e) => ne.find((t) => t.id === e), k = (e, t = 1, n = 1, r = !1, i = !1) => ({
	id: "l" + e,
	slot: e,
	copies: t,
	uses: n,
	heavy: r,
	permanent: i,
	trove: !1,
	locks: [],
	backup: 0
}), A = (e, t, n = 0) => ({
	id: "v" + e,
	slot: e,
	copies: 1,
	uses: 1,
	heavy: !1,
	permanent: !0,
	trove: !0,
	locks: t,
	backup: n
}), re = [
	k(0),
	k(1, 7),
	k(2),
	k(3, 1, 2),
	k(4),
	k(5, 1, 7),
	k(6),
	k(7),
	k(8, 2),
	k(9, 1, 3),
	k(10, 2, 3),
	k(11, 1, 2),
	k(12, 1, 1, !0, !0),
	k(13),
	k(14, 1, 2),
	k(15, 1, 1, !0, !0),
	k(16, 1, 2),
	k(17, 1, 3),
	k(18, 1, 1, !0, !0),
	k(19),
	k(20),
	k(21),
	k(22, 2),
	k(23, 1, 2),
	k(24),
	k(25),
	k(26, 2),
	k(27),
	k(28, 2),
	A(2, [
		2,
		3,
		3
	], 1),
	A(3, [
		3,
		3,
		6
	]),
	A(4, [
		4,
		2,
		2
	], 2),
	A(6, [
		3,
		5,
		2
	], 3),
	A(7, [
		1,
		6,
		1
	]),
	A(8, [
		4,
		3,
		2
	], 1),
	A(9, [
		3,
		2,
		3
	], 3),
	A(10, [
		3,
		3,
		3
	]),
	A(11, [
		4,
		1,
		1
	], 1),
	A(12, [
		5,
		3,
		1
	], 2),
	A(13, [
		3,
		2,
		4
	]),
	A(14, [
		1,
		4,
		3
	]),
	A(15, [
		1,
		2,
		3
	], 1),
	A(16, [
		2,
		6,
		4
	]),
	A(17, [
		3,
		1,
		3
	], 2),
	A(18, [
		2,
		3,
		5
	], 1),
	A(19, [
		5,
		2,
		3
	], 1),
	A(20, [
		4,
		4,
		4
	]),
	A(21, [
		3,
		6,
		3
	]),
	A(22, [
		5,
		2,
		5
	], 2)
], ie = {
	...k(29, 1, 2),
	id: "water"
}, ae = (e) => e === "water" ? ie : re.find((t) => t.id === e), j = (e, t, n = [], r = {}) => ({
	id: e,
	faces: t.split(","),
	requires: n,
	...r
}), oe = {
	boomer: [
		j(1, "bones,element:1,element:1,element:2,element:2,element:3"),
		j(2, "bones,casing:1,casing:1,casing:2,casing:2,casing:3"),
		j(3, "bones,fuse:1,fuse:1,fuse:2,fuse:2,fuse:3"),
		j(4, "grenades:0,grenades:1,grenades:2,grenades:3,blank,blank", [], { counter: !0 }),
		j(5, "forcedBones,explosion:3,explosion:3,explosion:3,explosion:3,explosion:4", [], { grenade: !0 }),
		j(6, "blast:1|partyBacklash:1,blast:1,blast:1,blast:2|partyBacklash:2,blast:2,blast:2", [5], { grenade: !0 }),
		j(7, "forcedBones,smoke:1,smoke:1,smoke:1,smoke:2,smoke:2", [], { grenade: !0 }),
		j(8, "cleanse:1,cleanse:1,cleanse:1,cleanse:2,cleanse:2,cleanse:2", [], { grenade: !0 }),
		j(9, "forcedBones,stun:5,stun:5,stun:5,stun:5,stun:5", [], { grenade: !0 }),
		j(10, "forcedBones,napalm:2:1|backlash:1,napalm:2:1,napalm:2:2,napalm:2:2,napalm:2:3", [9], { grenade: !0 }),
		j(11, "disable:1,disable:1,disable:1,disable:5,disable:5,disable:5", [], { grenade: !0 }),
		j(12, "grenades:1,parts:1,parts:1,parts:2,parts:2,parts:3", [], { consumable: !0 }),
		j(13, "bones,bones,buffHp:3,loot:1,parts:1,parts:2"),
		j(14, "bones,bones,biggerBoom:1,biggerBoom:1,biggerBoom:1,biggerBoom:2", [13]),
		j(15, "bones:2,bones:2,bones:2,holyAcquire,grenades:1,element325", [14]),
		j(16, "holyBlast:1:2,holyBlast:1:2,holyBlast:2:4,holyExplosion:2:5,holyExplosion:3:6,holyExplosion:3:6", [], { consumable: !0 })
	],
	patches: [
		j(1, "heal:1,heal:2,heal:2,heal:2,heal:3,heal:3"),
		j(2, "bones,healMultiply:2,healMultiply:2,healMultiply:2,healMultiply:3,healMultiply:3", [1]),
		j(3, "meleeDamage:1,meleeDamage:1,meleeDamage:2,meleeDamage:2,meleeDamage:3,meleeDamage:3", [2]),
		j(4, "revive:1,revive:2,revive:2,revive:2,revive:3,revive:3", [], { consumable: !0 }),
		j(5, "bones,heal:2,heal:3,healReroll:1,healReroll:2,loot:1"),
		j(6, "bones:2,bones:2,poisonTarget:1,poisonTarget:2,poisonTarget:2,poisonTarget:3"),
		j(7, "heal:3,heal:3,heal:4,heal:4,heal:5,heal:5", [2]),
		j(8, "poisonAny:1,poisonAny:2,poisonAny:2,poisonAny:2,poisonAny:3,poisonAny:3", [], { consumable: !0 }),
		j(9, "bones,tainted:1,buffHp:2,buffHp:3,buffHp:4,buffHp:5"),
		j(10, "bones,tainted:1,buffAttack:2,buffAttack:2,buffAttack:3,buffAttack:3", [9]),
		j(11, "trueDamage:3,trueDamage:4,reviveKo:3,reviveKo:4,reviveKo:4,reviveKo:5", [7]),
		j(12, "cells:1,cells:2,cells:2,cells:3,cells:3,cells:3", [], {
			consumable: !0,
			counter: !0
		}),
		j(13, "bones,buffReroll:1,buffReroll:1,buffReroll:1,buffReroll:2,buffReroll:2", [14]),
		j(14, "bones,tainted:1,buffHp:3,buffHp:4,buffHp:4,buffHp:5", [9]),
		j(15, "bones,bones,recover:1,recover:1,booster:1,booster:2", [14]),
		j(16, "tainted:1,tainted:2,permanentHp:1,permanentHp:1,permanentHp:1,permanentHp:2", [15])
	],
	picket: [
		j(1, "reusableBones,reusableBones,reusableBones,reusableBones,constantRegen:1,constantRegen:1", [], { reusable: !0 }),
		j(2, "reusableBones,reusableBones,reusableBones,constantMove:2,constantDefense:1,constantDefense:1", [1], { reusable: !0 }),
		j(3, "bones,bones,intercept:1,intercept:1,intercept:1,intercept:2"),
		j(4, "ale:1,ale:1,ale:1,ale:2,ale:2,ale:2", [], { consumable: !0 }),
		j(5, "reusableBones,reusableBones,reusableBones,constantMove:2,constantDamage:1,constantDamage:1", [1], { reusable: !0 }),
		j(6, "reusableBones,reusableBones,reusableBones,reusableBones,constantTaunt,constantTaunt", [2], { reusable: !0 }),
		j(7, "bones,intercept:1,intercept:1,intercept:2,intercept:2,intercept:3", [3]),
		j(8, "healSelf:2,healSelf:3,healSelf:3,healSelf:3,healSelf:4,healSelf:4", [], { consumable: !0 }),
		j(9, "switch,switch,switch,rush,rush,riposte"),
		j(10, "switch,rush,rush,rush,riposte,riposte"),
		j(11, "bones,advancedDefense:1,advancedDefense:1,advancedDefense:1,advancedDefense:2,advancedDefense:2"),
		j(12, "bones,advancedDefense:1,advancedDefense:2,advancedDefense:2,advancedDefense:2,advancedDefense:3", [11]),
		j(13, "switch,switch,rush,riposte,riposte,riposte"),
		j(14, "switch,switch,rush,rush,riposte,riposte"),
		j(15, "bones:2,bones:2,bones:2,bones:3,improvedDefense,improvedDefense", [11]),
		j(16, "bones,advancedDefense:1,advancedDefense:2,advancedDefense:3,advancedDefense:3,advancedDefense:4", [12])
	],
	tantrum: [
		j(1, "rage:10,rage:12,rage:14,rage:16,rage:18,breakdown", [], { counter: !0 }),
		j(2, "rage:20,rage:22,rage:24,rage:26,rage:28,breakdown", [1], { counter: !0 }),
		j(3, "rage:30,rage:32,rage:34,rage:36,rage:38,breakdown", [2], { counter: !0 }),
		j(4, "anger:2,anger:2,anger:4,anger:4,anger:6,advance"),
		j(5, "bones,axe:1,poisonArmor:1,poisonArmor:2,poisonArmor:2,poisonArmor:2"),
		j(6, "bones,axe:1,lashback:2,lashback:2,lashback:2,lashback:3"),
		j(7, "bones,axe:1,hardy:1,hardy:1,hardy:1,hardy:2"),
		j(8, "axes:0,axes:1,axes:2,axes:3,blank,blank", [], {
			counter: !0,
			consumable: !0
		}),
		j(9, "bones,bones,dropInitiative:3,dropInitiative:2,dropInitiative:2,dropInitiative:1"),
		j(10, "bones,bones,attackMinus:1,attackMinus:1,attackMinus:1,attackMinus:1"),
		j(11, "bones,bones,disable:5,disable:5,disable:5,disable:5"),
		j(12, "reusableBones,reusableBones,reusableBones,reusableBones,partyInspire,disorient:5", [], {
			consumable: !0,
			reusable: !0
		}),
		j(13, "bones,bones,jump,jump,jump,jump", [9]),
		j(14, "bones,bones,attackPlus:1,attackPlus:1,attackPlus:1,attackPlus:1|trainAttack", [10]),
		j(15, "bones,bones,taunt,taunt,taunt,taunt", [11]),
		j(16, "bodyCount:0,bodyCount:1,bodyCount:2,bodyCount:3,bodyCount:4,bodyCount:5", [], {
			counter: !0,
			consumable: !0
		})
	]
}, se = [
	"boomer",
	"patches",
	"picket",
	"tantrum"
], ce = {
	boomer: [
		2,
		3,
		4,
		4,
		5,
		6
	],
	patches: [
		3,
		3,
		3,
		3,
		4,
		4
	],
	picket: [
		2,
		2,
		3,
		3,
		3,
		5
	],
	tantrum: [
		3,
		4,
		4,
		4,
		5,
		5
	]
}, le = {
	boomer: [
		1,
		2,
		3,
		4
	],
	patches: [],
	picket: [],
	tantrum: [
		1,
		8,
		16
	]
}, ue = [
	1,
	1,
	1,
	1,
	2,
	0
], de = [
	1,
	1,
	1,
	2,
	0,
	0
], fe = [
	[
		"T1",
		"T2",
		"T3",
		"L1",
		"L3",
		"F2"
	],
	[
		"L1",
		"L2",
		"L3",
		"F1",
		"F3",
		"T2"
	],
	[
		"F1",
		"F2",
		"F3",
		"T1",
		"T3",
		"L2"
	]
], pe = [
	"convert",
	"convert",
	"reroll",
	"reroll",
	"save",
	"save"
];
function M(e, t) {
	return oe[e][t - 1];
}
function me(e) {
	return e.split("|").map((e) => {
		let [t, n, r] = e.split(":");
		return {
			kind: t,
			n: n === void 0 ? 1 : Number(n),
			extra: r === void 0 ? 0 : Number(r)
		};
	});
}
//#endregion
//#region src/games/toomanybones/state.ts
var he = {
	boomer: [
		3,
		3,
		1,
		2
	],
	patches: [
		5,
		2,
		1,
		1
	],
	picket: [
		5,
		2,
		1,
		2
	],
	tantrum: [
		4,
		3,
		3,
		0
	]
}, N = () => ({
	kind: "none",
	by: "",
	step: 0,
	values: [],
	ids: [],
	wins: [],
	dice: [],
	data: {}
}), ge = (e, t) => t + ":" + ++e.serial;
function P(t, n = 6) {
	let r = e(t.seed, t.cursor, n);
	return t.cursor += 1, r;
}
var _e = (e) => P(e) + 1;
function ve(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; t--) {
		let r = P(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
var F = (e, t) => e.actors.find((e) => e.id === t), ye = (e, t) => e.actors.find((e) => e.owner === t && e.kind === "gearloc"), I = (e) => e.actors.filter((e) => e.kind === "gearloc"), L = (e) => e.actors.filter((e) => e.pos >= 0 && e.hp > 0), R = (e) => L(e).filter((e) => e.kind === "baddie" || e.kind === "object"), be = (e) => L(e).filter((e) => e.kind === "gearloc" || e.kind === "ally"), xe = (e) => e.kind === "gearloc" || e.kind === "object" ? void 0 : T(e.definition), Se = (e, t) => e.inventory.some((e) => e.card === t && (!ae(t)?.trove || e.locks === 3)), z = (e, t) => [...e.active, ...e.locked].filter((e) => e.kind === t).reduce((e, t) => e + t.n, 0), Ce = (e) => e.bones.reduce((e, t) => e + t.n, 0), we = (e, t, n, r = !1) => {
	if (!t.gearloc || !t.skills.includes(n) || t.exhausted.includes(n)) return !1;
	let i = r && t.gearloc === "picket" && [
		1,
		2,
		5,
		6
	].includes(n);
	if (e.actors.some((e) => [
		...e.active,
		...e.locked,
		...e.bones
	].some((r) => r.owner === t.id && r.skill === n && !(i && e === t && t.locked.includes(r))))) return !1;
	let a = M(t.gearloc, n);
	return a.counter || t.effects.disable || (e.battle?.modifiers.noSkills ?? 0) >= (e.battle?.round ?? 0) || e.battle?.modifiers.untilLaneOne && !e.battle.defeated.some((t) => F(e, t)?.lane === 1) || t.gearloc === "boomer" && n === 13 && !e.battle?.defeated.length || t.gearloc === "patches" && n === 11 && !(t.counters.cells > 0) ? !1 : !a.grenade || t.counters.grenades > 0;
};
function B(e, t, n = "", r = "", i = 0, a = []) {
	e.log.push({
		key: t,
		who: n,
		target: r,
		n: i,
		values: a
	}), e.log.length > 250 && e.log.splice(0, e.log.length - 250);
}
function Te(e, t) {
	return {
		id: e,
		owner: t,
		kind: "gearloc",
		definition: "",
		gearloc: null,
		hp: 0,
		maxHp: 0,
		dex: 0,
		attack: 0,
		defense: 0,
		pos: -1,
		lane: 0,
		initiative: 0,
		ranged: !1,
		diagonal: !1,
		point: 0,
		target: "weakest",
		targets: 1,
		skills: [],
		exhausted: [],
		active: [],
		locked: [],
		bones: [],
		enemyDefense: [],
		effects: {},
		counters: {},
		inventory: [],
		training: 0,
		failedTraining: [],
		upgraded: !1,
		ready: !1,
		recovery: [],
		lockAttempted: !1
	};
}
function Ee(e, t, n) {
	let r = Te(t, t), [i, a, o, s] = he[n], c = e.config.difficulty === "adventurer" ? 2 : +(e.config.difficulty === "heroic");
	return Object.assign(r, {
		definition: n,
		gearloc: n,
		hp: i + c,
		maxHp: i + c,
		dex: a,
		attack: o,
		defense: s,
		ranged: n === "boomer",
		skills: [...le[n]],
		training: e.config.difficulty === "legendary" ? 0 : 1
	}), r.counters = {
		baseHp: i,
		baseDex: a,
		baseAttack: o,
		baseDefense: s,
		hpTraining: 0,
		dexTraining: 0,
		attackTraining: 0,
		defenseTraining: 0,
		grenades: 0,
		axes: 0,
		bodyCount: 0,
		rageTier: 1,
		rageStep: 0
	}, r;
}
function De(e, t, n = "baddie") {
	let r = t.split("#")[0], i = T(r), a = Te(ge(e, t), "");
	return Object.assign(a, {
		kind: n,
		definition: r,
		hp: i.hp,
		maxHp: i.hp,
		attack: i.attack,
		defense: i.defense,
		initiative: i.initiative,
		ranged: i.ranged,
		diagonal: i.diagonal,
		point: i.point,
		target: i.target,
		targets: i.targets
	}), a.counters.chip = Number(t.split("#")[1] ?? 0), e.actors.push(a), a;
}
function Oe(e, t, n, r) {
	let i = Te(ge(e, t), "");
	return Object.assign(i, {
		kind: "object",
		definition: t,
		hp: n,
		maxHp: n,
		pos: r
	}), e.actors.push(i), i;
}
function V(e, t, n, r, i = 0, a = t.id, o = !1, s = 0, c = !1) {
	let l = o ? t.locked : t.active;
	if (l.length >= 3) return null;
	let u = {
		uid: ge(e, "slot"),
		owner: a,
		skill: i,
		kind: n,
		n: r,
		extra: s,
		reusable: c
	};
	return l.push(u), u;
}
function H(e, t) {
	if (!t || !e.gearloc) return;
	let n = M(e.gearloc, t);
	n.consumable && !n.counter ? e.skills = e.skills.filter((e) => e !== t) : e.exhausted.includes(t) || e.exhausted.push(t);
}
function U(e, t, n) {
	t.active = t.active.filter((e) => e.uid !== n.uid), t.locked = t.locked.filter((e) => e.uid !== n.uid), t.bones = t.bones.filter((e) => e.uid !== n.uid);
	let r = F(e, n.owner);
	r && n.skill && !(n.kind === "bones" && n.reusable) && H(r, n.skill);
}
function ke(e, t) {
	t.counters.cells--;
	for (let n of t.locked.filter((e) => e.kind === "cells")) n.n = t.counters.cells, n.n <= 0 && U(e, t, n);
}
function Ae(e, t, n) {
	if (Ce(t) < n) return !1;
	for (; n > 0 && t.bones.length;) {
		let r = t.bones[0];
		n -= r.n, U(e, t, r);
	}
	return !0;
}
function je(e, t, n) {
	if (!t.gearloc || !M(t.gearloc, n).consumable || t.gearloc === "tantrum" && n === 16 || t.gearloc === "patches" && n === 12 && t.locked.length >= 3 && !t.locked.some((e) => e.owner === t.id && e.skill === 12)) return !1;
	if (t.skills.includes(n) || t.skills.push(n), t.exhausted = t.exhausted.filter((e) => e !== n), t.gearloc === "tantrum" && n === 8 && (t.counters.axes = 3), t.gearloc === "patches" && n === 12) {
		t.locked = t.locked.filter((e) => e.owner !== t.id || e.skill !== 12);
		let n = [
			1,
			2,
			2,
			3,
			3,
			3
		][P(e)];
		t.counters.cells = n, V(e, t, "cells", n, 12, t.id, !0);
	}
	return !0;
}
function W(e, t, n, r = t.id) {
	if (e.phase === "battle" && t.hp <= 0 || t.effects.ale) return;
	let i = Math.max(0, Math.min(n, t.maxHp - t.hp));
	t.hp += i, i && B(e, "heal", r, t.id, i);
}
function G(e, t, n, r) {
	if (n === "poison" && t.definition === "drellen") return;
	let i = [
		"poison",
		"bleed",
		"weaken",
		"stun",
		"disable",
		"terrify"
	];
	if (!(i.includes(n) && t.kind === "gearloc" && I(e).some((e) => z(e, "cleanse") > 0))) {
		if (i.includes(n) && t.kind === "gearloc" && Se(t, "l19") && e.battle) {
			let i = "prevent:" + t.id + "|" + n;
			e.battle.reactions.includes(i) || e.battle.reactions.push(i), e.battle.pendingDamage[i] = r;
			return;
		}
		t.effects[n] = r, B(e, "effect", t.id, n, r);
	}
}
function Me(e, t) {
	let n = ae(t);
	return {
		uid: ge(e, "loot"),
		card: t,
		uses: n?.uses ?? 2,
		locks: n?.trove ? 0 : 3
	};
}
function Ne(e, t, n = 1, r = !1) {
	let i = [];
	for (let a = 0; a < n; a++) {
		let n = r ? e.troveDeck : e.lootDeck, a = r ? e.troveDiscard : e.lootDiscard;
		!n.length && a.length && (n.push(...ve(e, a)), a.splice(0));
		let o = n.shift();
		if (!o) break;
		let s = Me(e, o);
		t.inventory.push(s), i.push(s), B(e, r ? "trove" : "loot", t.id, o);
	}
	return i;
}
function Pe(e, t, n) {
	t.inventory = t.inventory.filter((e) => e.uid !== n.uid), n.card !== "water" && ae(n.card) && (ae(n.card).trove ? e.troveDiscard : e.lootDiscard).push(n.card);
}
var Fe = (e) => e.inventory.reduce((e, t) => e + (ae(t.card)?.heavy && t.locks === 3 ? 3 : 1), 0);
function Ie(e) {
	let t = te[e.config.tyrant], n = ve(e, ne.filter((t) => t.sheet === (e.players.length === 1 ? 0 : 29)).map((e) => e.id));
	e.unusedEncounters = n.slice(t.days - 3), e.encounterDeck = [
		"s1",
		"s2",
		"s3",
		...ve(e, [...n.slice(0, t.days - 3), ...t.encounters.map((e) => "t" + e)])
	], e.lootDeck = ve(e, re.filter((e) => !e.trove).flatMap((e) => Array(e.copies).fill(e.id))), e.troveDeck = ve(e, re.filter((e) => e.trove).map((e) => e.id));
	for (let n of [
		1,
		5,
		20
	]) e.stacks[n] = ve(e, w.filter((e) => e.point === n && t.creatures.includes(e.creature)).flatMap((e) => Array.from({ length: e.copies }, (t, n) => e.id + "#" + n)));
	e.phase = I(e).some((e) => e.training > 0) ? "training" : "day", e.trainingReturn = "day";
}
function K(e, t, n, r, i) {
	let a = (e) => {
		let a = T(e.split("#")[0]);
		return a.point === t && (!n || a.creature === n) && (!r || a.id === r) && (i === void 0 || a.ranged === i);
	}, o = e.stacks[t] ?? [], s = o.findIndex(a);
	if (s < 0) {
		let t = e.defeatedStack.filter(a);
		e.defeatedStack = e.defeatedStack.filter((e) => !a(e)), o.push(...ve(e, t)), s = o.findIndex(a);
	}
	if (s < 0 && (n || r || i !== void 0)) {
		let t = w.find((t) => a(t.id) && !e.persistent["removed:" + t.creature]);
		if (t) {
			let n = /* @__PURE__ */ new Set([
				...Object.values(e.stacks).flat(),
				...e.defeatedStack,
				...e.battle?.queue ?? [],
				...e.delayedBaddies.map((e) => e.chip),
				...Object.keys(e.persistent).filter((e) => e.startsWith("reserve:")).map((e) => e.slice(8)),
				...L(e).filter((e) => e.kind === "baddie" || e.kind === "ally").map((e) => e.definition + "#" + e.counters.chip)
			]), r = Array.from({ length: t.copies }, (e, n) => t.id + "#" + n).find((e) => !n.has(e));
			if (r) return r;
		}
	}
	if (s < 0) return null;
	let [c] = o.splice(s, 1);
	if (e.scouted[t] = (e.scouted[t] ?? []).filter((e) => e !== c), n || r || i !== void 0) {
		let n = e.scouted[t];
		e.stacks[t] = [...o.filter((e) => n.includes(e)), ...ve(e, o.filter((e) => !n.includes(e)))];
	}
	return c;
}
function Le(e, t, n, r = !1, i = !1) {
	let a = [], o = Math.max(0, t);
	for (let t of r ? [1] : [
		20,
		5,
		1
	]) for (; o >= t;) {
		let r = K(e, t, n) ?? (n && !i ? K(e, t) : null);
		if (!r) break;
		a.push(r), o -= t;
	}
	return a;
}
function Re(e, t) {
	!e.encounterDeck.includes(t) && !e.completed.includes(t) && e.encounter !== t && (e.encounterDeck = ve(e, [...e.encounterDeck, t]));
}
function ze(e, t) {
	e.progress += t.progress;
	for (let n of I(e)) n.training += t.training, n.failedTraining = [], n.ready = !1, Ne(e, n, t.eachLoot), Ne(e, n, t.eachTrove, !0);
	let n = ye(e, e.leader);
	Ne(e, n, t.loot), Ne(e, n, t.trove, !0);
}
function Be(e, t) {
	return {
		progress: e.progress + t.progress,
		training: e.training + t.training,
		loot: e.loot + t.loot,
		eachLoot: e.eachLoot + t.eachLoot,
		trove: e.trove + t.trove,
		eachTrove: e.eachTrove + t.eachTrove
	};
}
function q(e, t, n) {
	if (t && e.encounter) {
		let t = O(e.encounter);
		ze(e, n ?? Be(t.reward, t.choiceRewards[e.choice ?? 0] ?? E())), e.completed.includes(e.encounter) || e.completed.push(e.encounter);
	}
	B(e, t ? "encounterSuccess" : "encounterFailed", e.leader, e.encounter ?? ""), e.challenge = N(), e.lock = null;
	for (let t of I(e)) t.ready = !1, t.recovery = [], t.lockAttempted = !1;
	e.trainingReturn = "recovery", e.persistent["today:skipRecovery"] && I(e).forEach((e) => {
		e.recovery = ["skip"];
	}), e.phase = t && I(e).some((e) => e.training > 0) ? "training" : "recovery";
}
function Ve(e, t, n = !1) {
	let r = n ? de : ue;
	return Array.from({ length: Math.max(0, t) }, () => r[P(e)]);
}
function He(e, t, n) {
	return {
		phase: "recruit",
		config: e,
		players: [...t],
		leader: t[0],
		actors: [],
		day: 1,
		progress: 0,
		encounter: null,
		choice: null,
		persistent: {},
		battle: null,
		lock: null,
		challenge: N(),
		log: [],
		outcome: null,
		scouted: {},
		seed: n,
		cursor: 0,
		serial: 0,
		encounterDeck: [],
		unusedEncounters: [],
		lootDeck: [],
		troveDeck: [],
		lootDiscard: [],
		troveDiscard: [],
		stacks: {},
		defeatedStack: [],
		completed: [],
		trainingReturn: "day",
		pendingReward: E(),
		lastBattle: [],
		delayedBaddies: []
	};
}
//#endregion
//#region src/games/toomanybones/lockpicking.ts
function Ue(e, t, n, r, i, a) {
	let o = ye(e, t), s = F(e, n)?.inventory.find((e) => e.uid === r);
	if (e.lock || !o || e.phase === "recovery" && o.lockAttempted || !i && (!s || !ae(s.card)?.trove || s.locks === 3)) return !1;
	let c = I(e).filter((e) => Se(e, "v10")).length, l = (i ?? [...ae(s.card).locks]).map((e) => Math.max(1, e - c)), u = s?.locks ?? 0;
	return e.lock = {
		by: t,
		owner: n,
		loot: r,
		values: l,
		types: a ?? [
			"L",
			"T",
			"F"
		],
		at: u,
		startedAt: u,
		available: [
			0,
			1,
			2
		],
		rolled: [],
		intuition: "none",
		saved: null,
		retry: !1,
		usedIntuition: !1,
		returnTo: e.phase
	}, e.phase === "recovery" && (o.lockAttempted = !0), B(e, "lockStart", o.id, s?.card ?? "", u), !0;
}
function We(e) {
	let t = e.lock, n = Array.from({ length: 3 }, (e, n) => t.rolled[n] ?? "");
	for (let r of t.available) n[r] = fe[r][P(e)];
	t.rolled = n, t.intuition = pe[P(e)], t.usedIntuition = !1, t.saved = null;
}
function Ge(e, t) {
	let n = e.lock, r = F(e, n.owner)?.inventory.find((e) => e.uid === n.loot);
	r && (r.locks = n.at), e.persistent.lockSuccess = +!!t, e.persistent.lockOpened = n.at - n.startedAt, B(e, t ? "lockSuccess" : "lockFail", n.by, r?.card ?? "", n.at), e.lock = null;
}
function Ke(e, t, n) {
	let r = e.lock;
	if (!r || r.by !== t) return !1;
	if (n.mode === "roll") return !r.rolled.length && (We(e), !0);
	if (n.mode === "stop") return r.at === r.startedAt && !r.retry ? (r.retry = !0, r.rolled = [], r.available = [
		0,
		1,
		2
	], r.saved = null, r.usedIntuition = !1, !0) : (Ge(e, !1), !0);
	if (!r.rolled.length) return !1;
	if (n.mode === "reroll") {
		if (r.intuition !== "reroll" || r.usedIntuition || n.dice?.length !== 1 || n.dice.some((e) => !r.available.includes(e))) return !1;
		for (let t of n.dice) r.rolled[t] = fe[t][P(e)];
		return r.intuition = pe[P(e)], r.saved = null, !0;
	}
	if (n.mode === "convert") return r.intuition !== "convert" || r.usedIntuition || n.die === void 0 || !r.available.includes(n.die) || !n.lockType ? !1 : (r.rolled[n.die] = n.lockType + r.rolled[n.die].slice(1), r.usedIntuition = !0, !0);
	if (n.mode === "save") {
		if (r.intuition !== "save" || r.usedIntuition || n.die === void 0 || !r.available.includes(n.die)) return !1;
		let e = r.rolled[n.die];
		return r.rolled[n.die] = e[0] + (Number(e.slice(1)) + 1), r.saved = n.die, r.usedIntuition = !0, !0;
	}
	if (n.mode === "solve") {
		let t = n.dice;
		if (!t?.length || new Set(t).size !== t.length || t.some((e) => !r.available.includes(e) || r.rolled[e][0] !== r.types[r.at]) || t.reduce((e, t) => e + Number(r.rolled[t].slice(1)), 0) < r.values[r.at]) return !1;
		r.available = r.available.filter((e) => !t.includes(e) || e === r.saved), r.at++;
		let i = F(e, r.owner)?.inventory.find((e) => e.uid === r.loot);
		return i && (i.locks = r.at), r.at >= r.values.length ? Ge(e, !0) : r.available.length ? (r.rolled = [], r.intuition = "none", r.usedIntuition = !1, r.saved = null) : Ge(e, !1), !0;
	}
	return !1;
}
//#endregion
//#region src/games/toomanybones/skills.ts
function qe(e, t, n) {
	if (e.phase !== "training" || t.training <= 0 || t.failedTraining.includes(n.stat)) return !1;
	let r = n.stat;
	if (r === "skill") {
		if (!n.skill || !t.gearloc || t.skills.includes(n.skill)) return !1;
		let e = M(t.gearloc, n.skill);
		if (e.consumable || !e.requires.every((e) => t.skills.includes(e))) return !1;
		t.skills.push(n.skill);
	} else {
		let n = t.counters[r + "Training"] ?? 0;
		if (n >= 5) return !1;
		let i = 0;
		if (r === "attack" || r === "defense") {
			let n = r === "attack" ? ue : de, a = Array.from({ length: t[r] }, () => n[P(e)]), o = +!!Se(t, "l18") + +!!Se(t, "v16") + (t.counters.trainingIgnore ?? 0);
			i = e.persistent["today:trainingAuto"] ? 0 : Math.max(0, a.filter((e) => !e).length - o), t.counters.trainingIgnore = 0, r === "defense" && i && (i = Array.from({ length: i }, () => de[P(e)]).filter((e) => !e).length, z(t, "improvedDefense") && (i = Math.max(0, i - 1))), B(e, "trainingRoll", t.id, r, i, a);
		}
		if (i) return t.failedTraining.push(r), !0;
		t.counters[r + "Training"] = n + 1, r === "hp" ? (t.maxHp++, t.hp++) : t[r]++;
	}
	return t.training--, t.failedTraining = [], B(e, "trained", t.id, r, n.skill ?? 1), !0;
}
function Je(e, t) {
	return Math.max(0, e[t] - (e.counters[t === "attack" ? "brokenAttack" : "brokenDefense"] ?? 0) - (t === "defense" ? e.active.filter((e) => e.kind === "defense").length : 0) + (t === "attack" ? z(e, "buffAttack") + (e.effects.attackMod ?? 0) - (e.effects.attackPenalty ?? 0) + (e.effects.extraAttack ?? 0) : 0));
}
var Ye = (e) => Math.max(0, Math.min(e.dex, e.effects.dexCap || 99) - (e.effects.weaken ?? 0) - (e.effects.dexPenalty ?? 0) + (e.effects.extraDex ?? 0));
function Xe(e, t, n) {
	let r = e.battle;
	if (r.stage !== "move" || r.startEffects.length || r.rolledOnce || !t.gearloc || new Set(n.skills).size !== n.skills.length) return !1;
	let i = n.target ? F(e, n.target) : void 0, a = [
		"troll",
		"orc",
		"scales",
		"goblin",
		"bog",
		"beast"
	].indexOf(i ? xe(i)?.creature ?? "" : "") + 1, o = Se(t, "v7") && a === t.counters.necklaceType ? t.counters.necklace ?? 0 : 0, s = (t.effects.extraAttack ?? 0) + o, c = +!!Se(t, "l15"), l = Math.max(0, n.attack - s) + Math.max(0, n.defense - c) + n.skills.length;
	if (!(n.attack + n.defense + n.skills.length) || l + r.spent > Ye(t) || n.attack > Je(t, "attack") + o || n.defense > Je(t, "defense") + c || r.modifiers.noDefense && n.defense || r.modifiers.defenseOnly >= r.round && (n.attack || n.skills.length) || r.modifiers.meleeDefenseOnly >= r.round && !t.ranged && (n.attack || n.skills.length) || r.modifiers.skillOnly >= r.round && (n.attack || n.defense)) return !1;
	let u = (e) => t.gearloc === "picket" && [
		1,
		2,
		5,
		6
	].includes(e) && t.locked.some((n) => n.owner === t.id && n.skill === e);
	if (!n.skills.every((n) => we(e, t, n, u(n)))) return !1;
	let d = n.target ? F(e, n.target) : void 0;
	if (n.attack && (!d || !yt(e, t, d)) && !Se(t, "v14")) return !1;
	let f = n.skills.filter((e) => M(t.gearloc, e).grenade);
	if (f.length > t.counters.grenades) return !1;
	for (let e of f) if (n.aims?.[String(e)] === void 0) return !1;
	let p = [];
	for (let [t, r, i] of [[
		"attack",
		n.attack,
		ue
	], [
		"defense",
		n.defense,
		de
	]]) for (let n = 0; n < r; n++) {
		let n = i[P(e)];
		p.push({
			uid: ge(e, "die"),
			kind: t,
			skill: 0,
			face: n ? t + ":" + n : "bones",
			used: !1,
			aim: -1
		});
	}
	for (let r of n.skills) {
		u(r) && (t.locked = t.locked.filter((e) => e.skill !== r || e.owner !== t.id));
		let i = M(t.gearloc, r);
		p.push({
			uid: ge(e, "die"),
			kind: "skill",
			skill: r,
			face: i.faces[P(e)],
			used: !1,
			aim: n.aims?.[String(r)] ?? -1
		}), t.gearloc === "patches" && r === 11 && ke(e, t);
	}
	t.counters.grenades -= f.length, r.rolled = p, r.spent += l, r.rolledOnce = !0, r.stage = "resolve", r.target = n.target;
	let m = L(e).filter((e) => e.definition === "orb").length + +!!r.modifiers.orbBones, h = p.reduce((e, t) => e + me(t.face).filter((e) => [
		"bones",
		"forcedBones",
		"reusableBones"
	].includes(e.kind)).reduce((e, t) => e + t.n, 0), 0);
	return m && h && X(e, t, m * h), B(e, "roll", t.id, n.target ?? "", l), !0;
}
function Ze(e, t, n) {
	n.used = !0, n.skill && H(t, n.skill);
}
function Qe(e, t, n) {
	let r = (n.kind === "skill" ? M(t.gearloc, n.skill).faces : n.kind === "attack" ? ue : de)[P(e)];
	n.face = typeof r == "number" ? r ? n.kind + ":" + r : "bones" : r;
}
function $e(e, t) {
	let n = /* @__PURE__ */ new Set([t.pos]), r = [t.pos];
	for (let i = 0; i < 3; i++) {
		r = r.flatMap((n) => kt(e, {
			...t,
			pos: n
		})).filter((e) => !n.has(e));
		for (let e of r) n.add(e);
	}
	return [...n];
}
function et(e, t, n, r, i, a = 1) {
	let o = r ? F(e, r) : void 0;
	if (n === "switch") {
		if (!o || o.hp <= 0 || !J(t.pos, o.pos)) return !1;
		let n = t.pos;
		return t.pos = o.pos, o.pos = n, t.counters.switchUsed = (t.counters.switchUsed ?? 0) + a, t.counters.switchUsed >= 2 && (o.kind === "gearloc" || o.kind === "ally" ? W(e, o, 3) : X(e, o, 3, t)), !0;
	}
	return n !== "rush" || i === void 0 || !$e(e, t).includes(i) ? !1 : (t.pos = i, t.counters.rushUsed = (t.counters.rushUsed ?? 0) + a, t.counters.rushUsed >= 2 && o && o.kind === "baddie" && J(i, o.pos) && X(e, o, 3, t), !0);
}
function tt(e, t, n, r, i) {
	let a = e.battle.rolled.find((e) => e.uid === i && !e.used && e.kind === "skill");
	if (!a || !(n === "buffReroll" ? [
		9,
		10,
		14,
		16
	] : [1, 7]).includes(a.skill)) return !1;
	if (n === "healMultiply") {
		if (!a.face.startsWith("heal:")) return !1;
		a.face = "heal:" + me(a.face)[0].n * r;
	} else Qe(e, t, a);
	return !0;
}
function nt(e, t, n) {
	let r = e.battle;
	if (r.stage !== "resolve" || new Set(n.dice).size !== n.dice.length) return !1;
	let i = n.dice.map((e) => r.rolled.find((t) => t.uid === e && !t.used));
	if (i.some((e) => !e)) return !1;
	let a = F(e, n.target ?? r.target ?? "");
	if (i.every((e) => e.kind === "attack" && e.face.startsWith("attack:")) && n.mode === "use") {
		let n = F(e, r.target ?? "");
		if (!n || !yt(e, t, n)) return !1;
		let a = i.reduce((e, t) => e + me(t.face)[0].n, 0) + (r.lastAttack.includes(t.id) ? 0 : z(t, "constantDamage"));
		return !n.effects.silverHide && X(e, n, a, t) && Y(n, "break") && (t.counters.brokenAttack = (t.counters.brokenAttack ?? 0) + i.length), Y(n, "terrify") && G(e, t, "terrify", 2), t.gearloc === "tantrum" && !r.lastAttack.includes(t.id) && bt(t, 1), r.lastAttack.push(t.id), i.forEach((n) => Ze(e, t, n)), !0;
	}
	if (n.mode === "use" && i.length <= 2 && i.every((e) => e.kind === "skill" && ["switch", "rush"].includes(e.face) && e.face === i[0].face)) return et(e, t, i[0].face, n.target, n.pos, i.length) ? (i.forEach((n) => Ze(e, t, n)), !0) : !1;
	if (i.length !== 1) return !1;
	let o = i[0], s = me(o.face), c = s[0];
	if (n.mode === "use" && [
		"healMultiply",
		"healReroll",
		"buffReroll"
	].includes(c.kind)) return tt(e, t, c.kind, c.n, n.target) ? (c.kind !== "healMultiply" && c.n > 1 ? o.face = c.kind + ":" + (c.n - 1) : Ze(e, t, o), !0) : !1;
	if (n.mode === "increase" && o.kind === "defense" && Se(t, "l12") && !r.flags.includes("armor:" + o.uid) && ["bones", "defense:1"].includes(o.face)) return o.face = o.face === "bones" ? "defense:1" : "defense:2", r.flags.push("armor:" + o.uid), !0;
	if (n.mode === "bones") return [
		"bones",
		"forcedBones",
		"reusableBones"
	].includes(c.kind) ? (t.bones.push({
		uid: ge(e, "bone"),
		owner: t.id,
		skill: o.skill,
		kind: "bones",
		n: c.n * (r.modifiers.doubleBones ? 2 : 1),
		extra: 0,
		reusable: c.kind === "reusableBones" || !o.skill
	}), o.used = !0, !0) : !1;
	if (n.mode === "discard") return o.face.includes("forcedBones") || o.face.includes("tainted") || t.gearloc === "boomer" && (o.skill === 16 || o.skill >= 5 && o.skill <= 11) ? !1 : (o.used = !0, !0);
	if (n.mode === "reroll") return !1;
	if (c.kind === "defense") return n.mode === "locked" && !(t.gearloc === "picket" && t.upgraded) || !V(e, t, "defense", c.n, 0, t.id, n.mode === "locked") ? !1 : (o.used = !0, !0);
	if (!o.skill) return !1;
	if ([
		"bones",
		"reusableBones",
		"forcedBones",
		"blank"
	].includes(c.kind)) {
		if (t.gearloc === "boomer" && t.upgraded && o.skill <= 3 && n.mode === "locked") {
			let n = [
				"element",
				"casing",
				"fuse"
			][o.skill - 1];
			return V(e, t, n, 1, o.skill, t.id, !0) ? (o.used = !0, !0) : !1;
		}
		return !1;
	}
	for (let r of s) if (!rt(e, t, o, r, n, a)) return !1;
	return o.used = !0, e.actors.some((e) => [...e.active, ...e.locked].some((e) => e.skill === o.skill && e.owner === t.id)) || H(t, o.skill), !0;
}
function rt(e, t, n, r, i, a) {
	let { kind: o, n: s, extra: c } = r, l = e.battle, u = (r, i = o, a = s, l = !1, u = c) => !!V(e, r, i, a, n.skill, t.id, l, u, M(t.gearloc, n.skill).reusable), d = F(e, l.target ?? ""), f = L(e).find((e) => e.pos === n.aim);
	switch (o) {
		case "element":
		case "casing":
		case "fuse": return u(t, o, s + +!!t.upgraded, !0);
		case "parts": {
			let e = i.components ?? [
				i.amount === 1 ? s : 0,
				i.amount === 2 ? s : 0,
				i.amount === 3 ? s : 0
			];
			return e.reduce((e, t) => e + t, 0) === s && u(t, "parts", s, !0, e[0] * 100 + e[1] * 10 + e[2]);
		}
		case "grenades": return t.counters.grenades = Math.min(3, t.counters.grenades + s), !0;
		case "holyAcquire": return je(e, t, 16);
		case "element325": return u(t, o, 1, !0);
		case "biggerBoom": return t.effects.biggerBoom = (t.effects.biggerBoom ?? 0) + s, !0;
		case "holyBlast":
		case "holyExplosion":
		case "explosion":
		case "blast": {
			let r = t.locked.find((e) => e.kind === "element325"), i = (o.startsWith("holy") && r ? c : s) + (n.skill === 5 || n.skill === 6 ? t.effects.biggerBoom ?? 0 : 0);
			if (o === "blast" || o === "holyBlast") for (let n of L(e).filter((e) => e.kind === "baddie")) X(e, n, i, t);
			else {
				if (n.aim < 0) return !1;
				f && X(e, f, i, t);
				for (let r of [...L(e)].filter((e) => J(e.pos, n.aim))) X(e, r, Math.floor(i / 2), t);
			}
			return o.startsWith("holy") && r && U(e, t, r), !0;
		}
		case "partyBacklash":
			for (let n of I(e)) X(e, n, s, t);
			return !0;
		case "backlash": return X(e, t, s, t), !0;
		case "stun":
		case "disable": {
			let n = t.gearloc === "boomer" ? f : a;
			return t.gearloc === "boomer" && (!n || n.kind !== "baddie" || n.point === 0 || n.point > s) ? !0 : !n || n.kind !== "baddie" || n.point === 0 || n.point > s || t.gearloc === "tantrum" && !J(t.pos, n.pos) ? !1 : (G(e, n, o, 1), !0);
		}
		case "napalm": return !f || f.kind !== "baddie" || (f.effects.napalm = s, f.effects.napalmRounds = c, f.counters.napalmSource = e.players.indexOf(t.owner) + 1, !0);
		case "smoke": return !f || f.kind !== "gearloc" || f.hp <= 0 || u(f);
		case "cleanse":
			for (let t of I(e)) for (let e of [
				"poison",
				"bleed",
				"weaken",
				"stun",
				"disable",
				"terrify"
			]) t.effects[e] = 0;
			return u(t);
		case "loot": return Ne(e, t, s), !0;
		case "healReroll": return u(t, o, s, !0);
		case "heal": return !a || a.kind !== "gearloc" || a.hp <= 0 ? !1 : (W(e, a, s, t.id), !0);
		case "healSelf": return W(e, t, s), !0;
		case "healMultiply":
		case "buffReroll": return u(t, o, s, !0);
		case "meleeDamage": return !d || !yt(e, t, d, !1) ? !1 : (X(e, d, s, t), !0);
		case "trueDamage": return !a || a.kind !== "baddie" || a.hp <= 0 ? !1 : (X(e, a, s, t, "true"), !0);
		case "poisonTarget": return !d || !yt(e, t, d, !1) ? !1 : (G(e, d, "poison", s), !0);
		case "poisonAny": return !a || a.kind !== "baddie" || a.hp <= 0 ? !1 : (G(e, a, "poison", s), !0);
		case "revive":
		case "reviveKo":
			if (!a || a.kind !== "gearloc" || o === "reviveKo" && a.hp > 0) return !1;
			if (a.hp <= 0) St(e, a, s);
			else return u(a, "revive", s);
			return !0;
		case "buffHp":
		case "buffAttack":
		case "recover":
		case "booster": return !a || a.kind !== "gearloc" || a.hp <= 0 ? !1 : u(a, o, s, !1, o === "buffHp" ? s : c);
		case "tainted": return X(e, t, s, t, "true"), !0;
		case "permanentHp": return !a || a.kind !== "gearloc" ? !1 : (a.maxHp += s, a.hp += s, !0);
		case "constantRegen":
		case "constantMove":
		case "constantDefense":
		case "constantDamage":
		case "constantTaunt":
		case "improvedDefense": return u(t, o, s, !0);
		case "advancedDefense": return !a || a.kind !== "gearloc" || a.hp <= 0 ? !1 : u(a);
		case "intercept": return !a || a.kind !== "gearloc" || a === t ? !1 : u(a);
		case "ale": return u(t) ? (t.hp = 1, t.effects.ale = 1, !0) : !1;
		case "switch":
		case "rush":
		case "riposte": return u(t);
		case "anger": return bt(t, i.mode === "decrease" ? -s / 2 : s / 2), !0;
		case "advance": return at(e, t);
		case "axe": return t.counters.axes = Math.min(3, t.counters.axes + s), !0;
		case "poisonArmor":
		case "lashback":
		case "hardy": return u(t);
		case "dropInitiative": return !d || !yt(e, t, d) ? !1 : (d.counters.dropInitiative = s, !0);
		case "attackMinus": return !a || a.kind !== "baddie" || !J(a.pos, t.pos) ? !1 : (a.effects.attackMod = (a.effects.attackMod ?? 0) - s, u(a, "attackMod", -s));
		case "attackPlus": return u(t, "buffAttack", s);
		case "trainAttack": {
			let n = Array.from({ length: t.attack }, () => ue[P(e)]);
			return n.every(Boolean) && (t.attack++, t.counters.attackTraining++), B(e, "trainingRoll", t.id, "attack", 0, n), !0;
		}
		case "partyInspire": return l.flags.push("partyInspire"), !0;
		case "disorient":
			for (let t of L(e).filter((e) => e.kind === "baddie" && e.point > 0 && e.point <= s)) G(e, t, "stun", 1);
			return !0;
		case "jump": return !a || a.kind !== "baddie" || i.pos === void 0 || L(e).some((e) => e.pos === i.pos) || !J(i.pos, a.pos) ? !1 : (t.pos = i.pos, l.target = a.id, !0);
		case "taunt": return G(e, t, "taunt", 1), u(t);
		default: return !1;
	}
}
function it(e, t) {
	if (t.gearloc !== "boomer" || t.counters.grenades >= 3) return !1;
	let n = [
		"element",
		"casing",
		"fuse"
	].map((e, n) => t.locked.find((t) => t.kind === e && t.n > 0 || t.kind === "parts" && Math.floor(t.extra / [
		100,
		10,
		1
	][n]) % 10 > 0));
	if (n.some((e) => !e)) return !1;
	for (let [r, i] of n.entries()) i.n--, i.kind === "parts" && (i.extra -= [
		100,
		10,
		1
	][r]), i.n || U(e, t, i);
	return t.counters.grenades++, !0;
}
function at(e, t) {
	let n = (t.counters.rageTier ?? 1) + 1, r = t.active.find((e) => e.kind === "rage");
	return !r || n > 3 || !t.skills.includes(n) || t.exhausted.includes(n) ? !1 : (t.counters.rageTier = n, t.counters.rageStep = 0, r.n = n * 10, r.skill = n, B(e, "rage", t.id, "", n), !0);
}
function ot(e, t, n, r) {
	if (t.gearloc !== "tantrum") return !1;
	let i = t.active.find((e) => e.kind === "rage");
	if (!i) return !1;
	let a = t.counters.rageTier, o = t.counters.rageStep;
	if (o === 5 && !t.upgraded) return !1;
	if (n === "advance") return o === 4 && at(e, t);
	if (n === "execute") {
		if (o !== 4 || !r || r.kind !== "baddie" || r.point === 0 || r.point > [
			0,
			1,
			5,
			20
		][a] || !J(r.pos, t.pos)) return !1;
		xt(e, r, t);
	} else if (n === "heal") {
		if (a !== 2 || o < 1 || o > 3) return !1;
		W(e, t, o);
	} else if (n === "bones") {
		if (a !== 1 || o < 1 || o > 3) return !1;
		t.bones.push({
			uid: ge(e, "bone"),
			owner: t.id,
			skill: 0,
			kind: "bones",
			n: o,
			extra: 0,
			reusable: !0
		});
	} else if (n === "damage") {
		if (a !== 3 || o < 1 || o > 3 || !r || r.id !== e.battle?.target || !yt(e, t, r)) return !1;
		X(e, r, 2, t);
	} else return !1;
	return U(e, t, i), a > 1 && !t.exhausted.includes(1) && (t.counters.rageTier = 1, t.counters.rageStep = 0, V(e, t, "rage", 10, 1)), !0;
}
function st(e, t, n) {
	let r = e.battle, i = n.cost, a = F(e, n.target ?? r.target ?? ""), o = Math.max(0, i - (i < 6 && Se(t, "v3") ? 1 : 0));
	if (r.backupUsed || Ce(t) < o || !t.gearloc || r.modifiers.noBackup) return !1;
	if (i === 6) {
		if (t.upgraded) return !1;
		t.upgraded = !0, t.gearloc === "patches" && (t.maxHp++, t.hp++);
	} else if (t.gearloc === "boomer") {
		if (i === 1 || i === 4) {
			if (!a || a.id !== r.target || !yt(e, t, a)) return !1;
			X(e, a, i === 1 ? 1 : 3, t);
		}
		if (i === 2) {
			let i = r.rolled.filter((e) => n.ids?.includes(e.uid) && e.skill >= 1 && e.skill <= 3 && !e.used);
			if (!i.length) return !1;
			i.forEach((n) => Qe(e, t, n));
		}
		if (i === 3) {
			if (!a || n.pos === void 0 || !kt(e, a).includes(n.pos)) return !1;
			a.pos = n.pos;
		}
		i === 5 && G(e, t, "untargetable", 1);
	} else if (t.gearloc === "patches") {
		if (i === 1) return !1;
		if (i === 2) {
			if (!a || a.kind !== "gearloc") return !1;
			W(e, a, 1, t.id);
		}
		if (i === 3) {
			if (!a || a.id !== r.target || !yt(e, t, a, !1)) return !1;
			X(e, a, 2, t);
		}
		if (i === 4 && (!n.skill || !je(e, t, n.skill))) return !1;
		if (i === 5) {
			if (t.counters.cells <= 0 || !a || a.kind !== "baddie") return !1;
			ke(e, t), X(e, a, 4, t, "true");
		}
	} else if (t.gearloc === "picket") {
		if (i === 1) return !1;
		if (i === 2 || i === 5) {
			if (!a || a.id !== r.target || !yt(e, t, a, !1)) return !1;
			let n = 0;
			for (let r of [...t.active, ...t.locked].filter((e) => [
				"defense",
				"advancedDefense",
				"constantDefense"
			].includes(e.kind))) n += r.n, r.reusable = !1, U(e, t, r);
			for (let i of r.rolled.filter((e) => !e.used && (e.face.startsWith("defense:") || e.face.startsWith("advancedDefense:")))) n += me(i.face)[0].n, Ze(e, t, i);
			X(e, a, n, t), i === 5 && a.point > 0 && G(e, a, "stun", 1);
		}
		if (i === 3) {
			let i = r.rolled.filter((e) => n.ids?.includes(e.uid) && !e.used);
			if (!i.length) return !1;
			i.forEach((n) => Qe(e, t, n));
		}
		if (i === 4 && (W(e, t, 2), !V(e, t, "defense", 2))) return !1;
	} else {
		if (i === 1 && bt(t, 1), i === 2 && bt(t, -1), i === 3) return !1;
		i === 4 && (t.counters.axes = 3), i === 5 && W(e, t, 4);
	}
	return Ae(e, t, o), r.backupUsed = !0, B(e, "backup", t.id, a?.id ?? "", i), !0;
}
var ct = (e) => e.gearloc ? oe[e.gearloc].filter((t) => !t.consumable && !e.skills.includes(t.id) && t.requires.every((t) => e.skills.includes(t))).map((e) => e.id) : [];
//#endregion
//#region src/games/toomanybones/loot.ts
function lt(e, t, n) {
	let r = t.inventory.find((e) => e.uid === n.loot);
	if (!r) return !1;
	let i = ae(r.card), a = F(e, n.target ?? t.id), o = e.battle, s = e.phase === "battle" && o?.turn === t.id && ["move", "resolve"].includes(o.stage) && !o.startEffects.length;
	if (n.mode === "discard") return [
		"training",
		"recovery",
		"encounter",
		"day"
	].includes(e.phase) ? (Pe(e, t, r), !0) : !1;
	if (n.mode === "give") return e.phase !== "recovery" || !a || a.kind !== "gearloc" || a === t ? !1 : (t.inventory = t.inventory.filter((e) => e !== r), a.inventory.push(r), !0);
	if (!i || i.trove && r.locks < 3) return !1;
	if (i.trove) {
		if (n.mode === "use" && i.slot === 21) return ft(e, t, n.amount ?? 1);
		if (n.mode === "use" && i.slot === 13) return !["day", "encounter"].includes(e.phase) || !n.amount || n.amount > 4 ? !1 : (t.counters.squirrelLane = n.amount, !0);
		if (n.mode !== "backup" || !s || !o || o.backupUsed || !i.backup || !Ae(e, t, Math.max(0, i.backup - +!!Se(t, "v3")))) return !1;
		if (i.slot === 2) {
			let i = n.amount === 0 ? "attack" : n.amount === 1 ? "defense" : "skill";
			if (i === "skill") {
				if (!n.skill || !t.gearloc || !we(e, t, n.skill)) return !1;
				let a = M(t.gearloc, n.skill);
				if (a.grenade && (!(t.counters.grenades > 0) || n.pos === void 0)) return !1;
				let s = {
					uid: r.uid + ":" + e.cursor,
					kind: i,
					skill: n.skill,
					face: "",
					used: !1,
					aim: n.pos ?? -1
				};
				Qe(e, t, s), o.rolled.push(s), a.grenade && t.counters.grenades--, t.gearloc === "patches" && n.skill === 11 && ke(e, t);
			} else {
				let t = Ve(e, 1, i === "defense")[0];
				o.rolled.push({
					uid: r.uid + ":" + e.cursor,
					kind: i,
					skill: 0,
					face: t ? i + ":" + t : "bones",
					used: !1,
					aim: -1
				});
			}
			o.stage = "resolve";
		} else if (i.slot === 4) {
			let n = F(e, o.target ?? "");
			if (!n) return !1;
			let r = n.active.filter((e) => e.kind === "defense");
			if (t.active.length + r.length > 3 || (t.active.push(...r), n.active = n.active.filter((e) => e.kind !== "defense"), n.enemyDefense.length + t.active.length > 3)) return !1;
			for (let r of n.enemyDefense) V(e, t, "defense", r);
			n.enemyDefense = [];
		} else if (i.slot === 6) {
			if (t.counters["used:" + r.uid]) return !1;
			G(e, t, "untargetable", 1), t.counters["used:" + r.uid] = 1;
		} else if (i.slot === 8) {
			let t = F(e, o.target ?? "");
			if (!t) return !1;
			t.counters.dropInitiative = (t.counters.dropInitiative ?? 0) + 1;
		} else if (i.slot === 9) {
			if (!a || a.kind !== "baddie" || ![1, 5].includes(a.point)) return !1;
			G(e, a, "stun", 1), P(e) === 0 && G(e, t, "stun", 1);
		} else if (i.slot === 11) {
			if (t.maxHp <= t.counters.baseHp) return !1;
			t.maxHp--, t.hp = Math.min(t.hp, t.maxHp), W(e, t, 3);
		} else if (i.slot === 12) {
			if (!a || a.kind !== "baddie" || t.counters["used:" + r.uid]) return !1;
			X(e, a, 2, t), P(e) >= 3 && (t.counters["used:" + r.uid] = 1);
		} else if (i.slot === 15) {
			if (!a || a.kind !== "gearloc") return !1;
			W(e, a, 1, t.id);
		} else if (i.slot === 17) {
			let t = o.rolled.find((e) => n.ids?.includes(e.uid) && !e.used && e.face.startsWith("attack:")), r = F(e, o.target ?? "");
			if (!t || !r) return !1;
			G(e, r, "poison", me(t.face)[0].n);
		} else if (i.slot === 18) {
			let r = o.rolled.find((e) => e.uid === n.ids?.[0] && !e.used);
			if (!r) return !1;
			Qe(e, t, r);
		} else if (i.slot === 19) t.counters.dropInitiative = (t.counters.dropInitiative ?? 0) - 1;
		else if (i.slot === 22) {
			if (t.counters["used:" + r.uid] || !a || !n.skill || !a.exhausted.includes(n.skill)) return !1;
			a.exhausted = a.exhausted.filter((e) => e !== n.skill), t.counters["used:" + r.uid] = 1;
		} else return !1;
		return o.backupUsed = !0, B(e, "lootUsed", t.id, r.card), !0;
	}
	let c = 1;
	switch (i.slot) {
		case 29:
			if (!a || a.kind !== "gearloc" || !n.amount || n.amount > r.uses || e.phase === "battle" && !s) return !1;
			W(e, a, n.amount, t.id), c = n.amount;
			break;
		case 0:
			if (!["day", "encounter"].includes(e.phase)) return !1;
			e.persistent.flare = (e.persistent.flare ?? 0) + 3;
			break;
		case 1:
			if (!n.skill || !je(e, t, n.skill)) return !1;
			break;
		case 2:
			if (!s) return !1;
			W(e, t, 5), G(e, t, "poison", 2);
			break;
		case 3:
			if (e.phase !== "training" || !t.failedTraining.length) return !1;
			t.failedTraining = [];
			break;
		case 4:
			if (!s || !o || o.rolledOnce) return !1;
			t.effects.extraAttack = (t.effects.extraAttack ?? 0) + 2;
			break;
		case 5:
			if (e.phase === "battle" || !a || a.kind !== "gearloc" || !n.amount || n.amount > r.uses) return !1;
			W(e, a, n.amount, t.id), c = n.amount;
			break;
		case 6:
			if (!s) return !1;
			t.effects.extraDex = (t.effects.extraDex ?? 0) + 3;
			break;
		case 7:
			if (e.lock?.by !== t.owner || e.lock.values[e.lock.at] > 4) return !1;
			e.lock.at++, e.lock.rolled = [], e.lock.at >= e.lock.values.length && Ge(e, !0);
			break;
		case 8:
			if (e.phase === "battle" && !s) return !1;
			W(e, t, e.phase === "battle" ? 3 : 5);
			break;
		case 9:
		case 11:
		case 20: {
			let r = e.lock, a = n.amount;
			if (!r || i.slot !== 9 && r.by !== t.owner || a === void 0 || !r.available.includes(a) || !r.rolled[a]) return !1;
			r.rolled[a] = r.rolled[a][0] + (Number(r.rolled[a].slice(1)) + (i.slot === 9 ? 1 : i.slot === 11 ? 2 : 4));
			break;
		}
		case 10:
			if (!s) return !1;
			W(e, t, 1);
			break;
		case 12:
		case 15:
		case 18: return !1;
		case 13:
			if (e.phase !== "training") return !1;
			t.counters.trainingIgnore = (t.counters.trainingIgnore ?? 0) + 1;
			break;
		case 14:
			if (e.lock && e.lock.by === t.owner && n.amount !== void 0 && e.lock.available.includes(n.amount)) {
				let t = n.amount;
				e.lock.rolled[t] = fe[t][P(e)];
			} else if (s && o) {
				let r = o.rolled.find((e) => e.uid === n.ids?.[0] && !e.used);
				if (!r) return !1;
				Qe(e, t, r);
			} else if (e.phase === "battle" && o?.stage === "deployment") {
				if (!t.gearloc) return !1;
				t.initiative = ce[t.gearloc][P(e)];
			} else return !1;
			break;
		case 16:
			if (!o || o.stage !== "endRound") return !1;
			t.counters.dropInitiative = -3;
			break;
		case 17: {
			let t = e.lastBattle.find((t) => t === n.target || e.persistent["defeatedType:" + t] === n.amount);
			if (e.phase !== "day" || !t) return !1;
			let r = e.persistent["defeatedType:" + t];
			if (!r) return !1;
			e.persistent.skinning = r;
			break;
		}
		case 19: return !1;
		case 21:
			if (e.phase !== "day" || e.encounterDeck.length < 2) return !1;
			e.phase = "challenge", e.challenge = {
				kind: "decision",
				by: t.owner,
				step: 0,
				ids: ["pickEncounter", ...e.encounterDeck.splice(0, 2)],
				values: [],
				wins: [],
				dice: [],
				data: {}
			};
			break;
		case 22:
			if (e.phase !== "recovery") return !1;
			Ne(e, t, 1, !0);
			break;
		case 23:
			if (!s || !a || a.hp <= 0 || a.pos < 0) return !1;
			X(e, a, Ve(e, 1)[0], t);
			break;
		case 24:
			if (e.phase === "battle") return !1;
			Re(e, "s4");
			break;
		case 25:
			if (e.phase === "battle") return !1;
			t.maxHp++, t.hp++, t.counters.brew = (t.counters.brew ?? 0) + 3;
			break;
		case 26:
			if (!s || !a || !n.skill || !a.exhausted.includes(n.skill)) return !1;
			a.exhausted = a.exhausted.filter((e) => e !== n.skill);
			break;
		case 27:
			if (!s) return !1;
			t.effects.zelfey = 1;
			break;
		case 28:
			if (!a || a.kind !== "gearloc" || e.phase === "battle" && !s) return !1;
			W(e, a, 2, t.id);
			break;
		default: return !1;
	}
	return r.uses -= c, r.uses <= 0 && Pe(e, t, r), B(e, "lootUsed", t.id, r.card), !0;
}
function ut(e, t, n, r) {
	if (![
		1,
		5,
		20
	].includes(r) || r > n) return !1;
	let i = ye(e, t), a = e.stacks[r]?.find((t) => !(e.scouted[r] ?? []).includes(t));
	return !i || !a ? !1 : (e.scouted[r] = [...e.scouted[r] ?? [], a], e.challenge = {
		kind: "scout",
		by: t,
		step: 0,
		values: [r],
		ids: [a],
		wins: [],
		dice: [],
		data: { max: n }
	}, !0);
}
function dt(e, t, n) {
	let r = e.challenge;
	if (r.kind !== "scout" || r.by !== t || ![0, 1].includes(n)) return !1;
	if (n === 1) {
		let t = e.stacks[r.values[0]], n = r.ids[0];
		e.stacks[r.values[0]] = [...t.filter((e) => e !== n), n], e.scouted[r.values[0]] = e.scouted[r.values[0]].filter((e) => e !== n);
	}
	return r.kind = "none", !0;
}
function ft(e, t, n) {
	return e.phase === "battle" || t.counters.scopeDay === e.day || !Se(t, "v21") || !ut(e, t.owner, 20, n) ? !1 : (t.counters.scopeDay = e.day, !0);
}
function pt(e, t, n) {
	let r = xe(n)?.creature;
	if (!r) return;
	let i = [
		"troll",
		"orc",
		"scales",
		"goblin",
		"bog",
		"beast"
	].indexOf(r) + 1;
	e.persistent["defeatedType:" + n.id] = i, Se(t, "v7") && (t.counters.necklaceType || (t.counters.necklaceType = i), t.counters.necklaceType === i && (t.counters.necklace = (t.counters.necklace ?? 0) + 1));
}
//#endregion
//#region src/games/toomanybones/combat.ts
var mt = (e) => Math.floor(e / 4), ht = (e) => e % 4;
function J(e, t, n = !1) {
	if (e < 0 || t < 0 || e === t) return !1;
	let r = Math.abs(ht(e) - ht(t)), i = Math.abs(mt(e) - mt(t));
	return n ? Math.max(r, i) === 1 : r + i === 1;
}
var gt = (e, t) => L(e).some((e) => e.pos === t), _t = (e) => e.battle?.flags.includes("tyrant") && e.config.tyrant === "drellen" ? 2 : 1;
function vt(e, t = !1) {
	return Array.from({ length: 16 }, (e, t) => t).filter((n) => J(e, n, t));
}
var Y = (e, t) => e.effects.disable ? 0 : xe(e)?.skills[t] ?? 0;
function yt(e, t, n, r = t.ranged) {
	let i = (e) => e.kind === "gearloc" || e.kind === "ally";
	if (i(t) === i(n) || t.hp <= 0 || n.hp <= 0 || t.pos < 0 || n.pos < 0 || n.effects.untargetable || n.effects.flight || t.effects.terrify && Y(n, "terrify") || n.counters.throne && L(e).some((e) => e.definition === "throne") || n.effects.throne && !J(t.pos, n.pos) || Y(n, "shrouded") && !J(t.pos, n.pos, !0) || !r && !J(t.pos, n.pos, t.diagonal)) return !1;
	let a = i(t) ? R(e) : be(e);
	if (t.kind === "gearloc" && e.battle?.modifiers.meleeFirst && n.ranged && R(e).some((e) => !e.ranged)) return !1;
	let o = a.filter((e) => (e.effects.taunt || z(e, "constantTaunt")) && J(e.pos, t.pos, t.diagonal));
	return !o.length || o.includes(n);
}
function bt(e, t) {
	let n = e.active.find((e) => e.kind === "rage");
	n && (e.counters.rageStep = Math.max(0, Math.min(5, (e.counters.rageStep ?? 0) + t)), n.n = (e.counters.rageTier ?? 1) * 10 + e.counters.rageStep * 2);
}
function xt(e, t, n) {
	if (t.pos < 0) return;
	let r = e.battle;
	if (t.hp = 0, t.pos = -1, t.kind === "gearloc") {
		for (let n of [...t.active, ...t.bones]) U(e, t, n);
		if (e.config.difficulty !== "adventurer") for (let n of [...t.locked]) U(e, t, n);
		B(e, "ko", t.id);
		for (let t of I(e).filter((e) => e.hp > 0 && e.counters.cloaked)) t.counters.cloaked = 0, r?.later.push(t.id), r?.flags.push("immediateEntry");
		r?.flags.includes("tyrant") && e.config.tyrant === "nom" && I(e).some((e) => e.hp > 0 && e.counters.reserve === 99) && r.reactions.push("nomNext");
	} else {
		let i = xe(t)?.creature;
		if (i && (e.persistent["defeatedType:" + t.id] = [
			"troll",
			"orc",
			"scales",
			"goblin",
			"bog",
			"beast"
		].indexOf(i) + 1), n?.kind === "gearloc" && t.kind === "baddie" && pt(e, n, t), n?.gearloc === "tantrum" && (n.counters.bodyCount = Math.min(5, n.counters.bodyCount + 1)), r?.defeated.push(t.id), t.kind === "baddie" && t.point > 0) {
			let n = t.definition + "#" + t.counters.chip;
			r && Y(t, "undead") && !e.persistent["undead:" + n] ? (e.persistent["undead:" + n] = 1, r.queue.unshift(n)) : r && (r.modifiers.returnDead >= r.round || r.modifiers.returnOrcs >= r.round && T(t.definition).creature === "orc") ? r.queue.push(n) : e.defeatedStack.push(n);
		}
		B(e, "defeat", n?.id ?? "", t.id);
	}
	if (r?.modifiers.duel) {
		r.modifiers.duel = 0;
		for (let t of I(e).filter((e) => e.hp > 0 && e.counters.reserve > 0 && e.counters.reserve !== 99)) t.counters.reserve = 0, r.later.push(t.id);
		r.flags.push("immediateEntry");
	}
	if (r?.modifiers.singleLane) {
		let n = t.kind === "gearloc" ? 8 : 4, i = t.kind === "gearloc" ? 12 : 0, a = L(e).find((e) => e.pos === i);
		!gt(e, n) && a && (a.pos = n), t.kind === "gearloc" && I(e).some((e) => e.hp > 0 && e.counters.reserve === 98) && r.reactions.push("lineupNext");
	}
}
function X(e, t, n, r, i = "normal") {
	if (t.hp <= 0 || t.pos < 0 || t.effects.ale || n <= 0 || t.definition === "goblinking" && r === t) return 0;
	let a = e.battle, o = n;
	if (Y(t, "bogRuler") && R(e).some((e) => e !== t && xe(e)?.creature === "bog")) return 0;
	if (i === "normal") {
		let n = Y(t, "thickSkin"), r = a?.hpLost[t.id + ":skin"] ?? 0, i = Math.min(o, Math.max(0, n - r));
		a && (a.hpLost[t.id + ":skin"] = r + i), o -= i;
		for (let n of [...t.active, ...t.locked].filter((e) => [
			"defense",
			"advancedDefense",
			"constantDefense"
		].includes(e.kind))) {
			if (o <= 0) break;
			let r = Math.min(o, n.n);
			o -= r, n.kind !== "constantDefense" && (n.n -= r, n.n || U(e, t, n));
		}
		for (let e of [...t.enemyDefense]) {
			if (o <= 0) break;
			let n = Math.min(o, e);
			if (o -= n, t.enemyDefense[0] -= n, t.enemyDefense[0] === 0) t.enemyDefense.shift();
			else break;
		}
		let s = t.counters.armor ?? 0, c = Math.min(o, s);
		o -= c, t.counters.armor = s - c;
	}
	if (i === "normal") {
		for (let n of [...t.active].filter((e) => e.kind === "buffHp")) {
			let r = Math.min(o, n.n);
			n.n -= r, o -= r, n.n || U(e, t, n);
		}
		if (!t.active.some((e) => e.kind === "buffHp")) for (let n of [...t.active].filter((e) => e.kind === "booster")) U(e, t, n);
	}
	(Y(t, "hardy") || z(t, "hardy")) && (o = Math.min(o, Math.max(0, 1 - (a?.hpLost[t.id] ?? 0))));
	let s = Math.min(t.hp, o);
	if (t.hp -= s, a && (a.hpLost[t.id] = (a.hpLost[t.id] ?? 0) + s), t.gearloc === "tantrum" && bt(t, s), s && B(e, "damage", r?.id ?? "", t.id, s), t.hp <= 0) {
		let n = t.active.find((e) => e.kind === "revive");
		n ? (t.hp = Math.min(t.maxHp, n.n), U(e, t, n)) : xt(e, t, r);
	}
	if (s && i === "normal" && r && r.hp > 0 && J(r.pos, t.pos, r.diagonal) && t.hp > 0) {
		let n = Y(t, "lashback");
		n && !a?.hpLost[t.id + ":lash"] && (a && (a.hpLost[t.id + ":lash"] = 1), X(e, r, n, t)), t.kind === "gearloc" && (z(t, "lashback") || z(t, "poisonArmor")) && a && a.reactions.push("retaliate:" + t.id + "|" + r.id);
	}
	return s;
}
function St(e, t, n) {
	t.hp > 0 || !e.battle || (t.hp = Math.min(n, t.maxHp), e.battle.later.push(t.id), B(e, "revive", t.id, "", t.hp));
}
function Ct(e, t = {}) {
	e.phase = "battle", e.challenge = {
		kind: "none",
		by: "",
		step: 0,
		values: [],
		ids: [],
		wins: [],
		dice: [],
		data: {}
	}, e.actors = I(e);
	let n = {
		round: 1,
		order: [],
		at: 0,
		stage: "deployment",
		turn: null,
		target: null,
		rolled: [],
		spent: 0,
		rolledOnce: !1,
		backupUsed: !1,
		queue: t.queue ?? Le(e, t.points ?? e.day * e.players.length),
		modifiers: t.modifiers ?? {},
		flags: [],
		enemyTargets: [],
		enemyRolls: [],
		enemyBones: 0,
		tyrantFace: -1,
		startEffects: [],
		reactions: [],
		pendingDamage: {},
		defeated: [],
		later: [],
		lastAttack: [],
		hpLost: {}
	};
	if (e.battle = n, e.delayedBaddies = [], n.modifiers.singleLane) {
		for (let t of I(e)) t.counters.reserve = 98;
		I(e).some((e) => e.hp > 0) && n.reactions.push("lineupNext");
	}
	for (let t of I(e)) if (t.pos = -1, t.ready = t.hp <= 0, t.effects = {}, t.exhausted = [], t.active = [], t.bones = [], t.counters.brokenAttack = 0, t.counters.brokenDefense = 0, t.counters.armor = 0, t.initiative = ce[t.gearloc][P(e)], t.gearloc === "tantrum" && (t.counters.rageTier = 1, t.counters.rageStep = 0, V(e, t, "rage", 10, 1)), t.gearloc === "picket") {
		let r = Ve(e, t.defense, !0).filter(Boolean).sort((e, t) => t - e);
		if (t.upgraded && r.length) r.forEach((e, n) => {
			t.counters["shield:" + n] = e;
		}), n.reactions.push("shield:" + t.id);
		else for (let n of r.slice(0, 3)) V(e, t, "defense", n);
	}
	if (t.tyrant) {
		if (n.flags.push("tyrant"), e.config.tyrant === "nom") {
			n.queue.push("nom");
			for (let t of I(e)) t.counters.reserve = 99;
			I(e).some((e) => e.hp > 0) && n.reactions.push("nomNext");
		} else if (e.config.tyrant === "mulmesh") n.queue = [
			...Object.keys(e.persistent).filter((e) => e.startsWith("reserve:")).map((e) => e.slice(8)),
			...n.queue,
			"mulmesh"
		];
		else if (e.config.tyrant === "duster") {
			for (let t of n.queue) (e.stacks[T(t.split("#")[0]).point] ??= []).unshift(t);
			n.queue = ["duster", ...Array.from({ length: e.players.length }, () => K(e, e.players.length <= 2 ? 1 : 5)).filter((e) => !!e)];
		} else if (e.config.tyrant === "gendricks") n.queue.unshift("gendricks", K(e, 1, "scales", "koboldgreenthumb") ?? "koboldgreenthumb#0");
		else {
			let t = De(e, e.config.tyrant);
			if (t.lane = e.config.tyrant === "marrow" ? 3 : 1, t.pos = e.config.tyrant === "marrow" ? 2 : t.ranged ? 0 : 4, e.config.tyrant === "goblinking" && (t.pos = 0, !e.persistent.goblinBomb)) {
				let n = Oe(e, "throne", 2, 0);
				n.effects.throne = 1, t.counters.throne = 1;
			}
			e.config.tyrant === "drellen" && n.queue.unshift(...Array.from({ length: 2 }, () => K(e, e.players.length <= 2 ? 1 : 5, "bog")).filter((e) => !!e));
		}
	}
	for (let t of I(e)) {
		t.counters.freeMoveUsed = 0, t.counters.afterAttackMove = 0, t.effects.extraAttack = 0, t.effects.extraDex = 0, n.modifiers.ignoreAttackTraining && (t.effects.attackPenalty = t.counters.attackTraining), n.modifiers.attackPlus && (t.effects.attackMod = n.modifiers.attackPlus), n.modifiers.dexPenalty && (t.effects.dexPenalty = n.modifiers.dexPenalty), n.modifiers.dexCap && (t.effects.dexCap = n.modifiers.dexCap), t.counters.prepBuff && (V(e, t, "buffHp", t.counters.prepBuff), t.counters.prepBuff = 0);
		for (let n of t.skills) e.persistent["trip:" + t.id + ":" + n] && (t.exhausted.push(n), delete e.persistent["trip:" + t.id + ":" + n]);
		if (n.modifiers.shieldWall && t.gearloc !== "picket") for (let n of Ve(e, t.defense, !0).filter(Boolean).slice(0, 3)) V(e, t, "defense", n);
		for (let e of Object.keys(t.counters).filter((e) => e.startsWith("used:"))) t.counters[e] = 0;
		t.counters.brew && (t.hp = Math.max(0, t.hp - t.counters.brew), t.counters.brew = 0);
	}
	if (n.modifiers.orbPillar && Oe(e, "orbPillar", n.modifiers.orbPillar, 0), n.modifiers.trader) {
		let t = Oe(e, "trader", 4, 8);
		t.kind = "ally", t.attack = 2, t.owner = e.players[0], t.initiative = I(e)[0].initiative;
	}
	if (n.modifiers.golemAlly) {
		let t = De(e, K(e, 20, "bog", "goldengolem") ?? "goldengolem#0", "ally");
		t.pos = 8, t.owner = e.players[0];
		for (let t of I(e)) t.counters.reserve = 3;
	}
	wt(e), B(e, "battle", "", "", n.queue.length);
}
function wt(e) {
	let t = e.battle, n = t.stage === "endRound" ? t.round + 1 : t.round, r = e.delayedBaddies.filter((e) => e.until <= n);
	e.delayedBaddies = e.delayedBaddies.filter((e) => e.until > n), t.queue.unshift(...r.map((e) => e.chip));
	for (let r = 1; r <= 4 && t.queue.length; r++) {
		if (t.modifiers.singleLane && r > 2 || t.modifiers.duel && t.round <= 3 && r > 1 || !t.modifiers.singleLane && R(e).some((e) => e.lane === r)) continue;
		let i = t.queue[0], a = De(e, i), o = a.point > 0 && I(e).find((e) => Se(e, "v13") && e.counters.squirrelLane === r && !e.counters["used:squirrel"]);
		if (o) {
			o.counters["used:squirrel"] = 1, t.queue.shift(), e.actors.pop(), e.delayedBaddies.push({
				chip: i,
				until: n + 1
			});
			continue;
		}
		let s = [
			(a.ranged ? 0 : 4) + r - 1,
			...Array.from({ length: 4 }, (e, t) => (a.ranged ? 0 : 4) + t),
			...Array.from({ length: 4 }, (e, t) => (a.ranged ? 4 : 0) + t)
		], c = t.modifiers.singleLane ? [4, 0].find((t) => !gt(e, t)) : s.find((t) => !gt(e, t));
		if (c === void 0) {
			e.actors.pop();
			continue;
		}
		t.queue.shift(), a.lane = r, a.pos = c;
		let l = xe(a)?.extra ?? 0;
		for (let n = 0; n < l; n++) {
			let n = K(e, 5);
			n && t.queue.unshift(n);
		}
		if (a.definition === "duster" && (a.initiative = 99), e.persistent["undead:" + i] && (a.hp = 2, a.attack *= 2), a.counters.armor = 0, t.modifiers.weakenFirst && r === 1 && (a.effects.attackMod = -t.modifiers.weakenFirst, t.modifiers.weakenFirst = 0), t.modifiers.spawnHpLoss && (a.hp = Math.max(1, a.hp - t.modifiers.spawnHpLoss)), a.point === 20 && t.modifiers.reinforced20 && (a.maxHp += 3, a.hp += 3), t.modifiers.trapStun && P(e) >= 2 && (a.effects.stunRounds = 2), t.modifiers.reverseSetup && t.round === 1 && (a.pos = 12 + r - 1), t.modifiers.spikeMoves && X(e, a, 1, void 0, "true"), t.modifiers.reinforceLarge && a.hp >= 5) {
			let n = K(e, 5);
			n && t.queue.push(n);
		}
		t.round > 1 && (a.point === 20 ? t.order.unshift(a.id) : t.order.push(a.id));
	}
}
function Tt(e, t) {
	return e.battle?.modifiers.singleLane ? e.battle.modifiers.oneAtTime ? gt(e, 8) ? [] : [8] : [8, 12].filter((t) => !gt(e, t)) : e.battle?.modifiers.reverseSetup ? Array.from({ length: 4 }, (e, t) => 8 + t).filter((t) => !gt(e, t)) : Array.from({ length: 4 }, (e, n) => (t.ranged ? 12 : 8) + n).filter((t) => !gt(e, t));
}
function Et(e) {
	let t = e.battle;
	if (t.order = L(e).sort((e, t) => t.initiative - e.initiative || e.lane - t.lane).map((e) => e.id), t.modifiers.surprise && t.order.sort((t, n) => Number(F(e, n)?.kind === "gearloc") - Number(F(e, t)?.kind === "gearloc")), t.modifiers.enemySurprise && t.order.sort((t, n) => Number(F(e, t)?.kind === "gearloc") - Number(F(e, n)?.kind === "gearloc")), t.modifiers.rangedTop && t.order.sort((t, n) => Number(!!F(e, n)?.ranged && F(e, n)?.kind === "baddie") - Number(!!F(e, t)?.ranged && F(e, t)?.kind === "baddie")), e.persistent.skinning) {
		let n = [
			"troll",
			"orc",
			"scales",
			"goblin",
			"bog",
			"beast"
		][e.persistent.skinning - 1], r = (t) => Number(xe(F(e, t))?.creature === n);
		t.order.sort((e, t) => r(e) - r(t)), e.persistent.skinning = 0;
	}
	let n = L(e).find((e) => e.definition === "trader");
	n && (t.order = t.order.filter((e) => e !== n.id), t.order.splice(t.order.indexOf(n.owner) + 1, 0, n.id)), t.flags.push("orderPending"), t.stage = "startRound";
}
function Dt(e) {
	let t = e.battle;
	if (!t) return !1;
	if (t.modifiers.nomVisit) {
		let n = L(e).find((e) => e.definition === "nom");
		n && (n.hp <= 5 || t.round > 3) && (n.pos = -1, n.hp = 0);
	}
	return t.modifiers.trader && !L(e).some((e) => e.definition === "trader") ? (Ot(e, !1), !0) : (t.flags.includes("tyrant") ? t.defeated.some((t) => F(e, t)?.definition === e.config.tyrant) : R(e).length === 0 && t.queue.length === 0 && !e.delayedBaddies.length && !(t.modifiers.golemAlly && t.round <= 3)) ? t.flags.includes("tyrant") ? (e.outcome = "win", e.phase = "done", B(e, "victory"), !0) : (t.modifiers.rats && Re(e, "s4"), Ot(e, !0), !0) : !be(e).length && !I(e).some((e) => e.hp > 0 && e.counters.reserve > 0) && !t.later.length && t.stage !== "deployment" && !t.reactions.includes("nomNext") && (Ot(e, !1), !0);
}
function Ot(e, t) {
	let n = e.battle;
	if (t && n.modifiers.ambushFirst) {
		Ct(e, { points: Math.max(0, e.day * e.players.length - 8) });
		return;
	}
	let r = [
		...L(e).filter((e) => e.point > 0).map((e) => e.definition + "#" + e.counters.chip),
		...n.queue.filter((e) => e.includes("#")),
		...e.delayedBaddies.map((e) => e.chip)
	];
	for (let t of new Set(r)) {
		let n = e.stacks[T(t.split("#")[0]).point] ??= [];
		n.includes(t) || n.push(t);
	}
	if (e.delayedBaddies = [], !t && n.modifiers.retryEncounter && e.encounterDeck.unshift(e.encounter), (n.modifiers.reshuffleAlways || !t && n.modifiers.reshuffleFailure) && (e.encounterDeck = ve(e, [...e.encounterDeck, e.encounter])), t && n.modifiers.huntDragon && Re(e, "s5"), t && n.modifiers.fullRecovery && (e.persistent["today:fullRecovery"] = 1), t && n.modifiers.trader && L(e).some((e) => e.definition === "trader") && (e.encounterDeck = e.encounterDeck.filter((e) => e !== "s6")), t && n.modifiers.removeCreature) {
		let t = [
			"troll",
			"orc",
			"scales",
			"goblin",
			"bog",
			"beast"
		][n.modifiers.removeCreature - 1];
		for (let n of Object.keys(e.stacks)) e.stacks[n] = e.stacks[n].filter((e) => T(e.split("#")[0]).creature !== t);
		e.defeatedStack = e.defeatedStack.filter((e) => T(e.split("#")[0]).creature !== t), e.persistent["removed:" + t] = 1;
	}
	e.lastBattle = e.battle?.defeated ?? [];
	for (let n of I(e)) {
		for (let e of [
			"hp",
			"dex",
			"attack",
			"defense"
		]) {
			let t = n.effects["limited:" + e] ?? 0;
			e === "hp" ? n.maxHp += t : n[e] += t;
		}
		for (let r of [
			...n.active,
			...n.bones,
			...t ? [] : n.locked
		]) U(e, n, r);
		n.exhausted = [], n.effects = {}, n.pos = -1, n.counters.reserve = 0, n.counters.brokenAttack = 0, n.counters.brokenDefense = 0;
	}
	e.actors = I(e), e.battle = null, q(e, t);
}
function kt(e, t) {
	return t.effects.daze || t.effects.stuck || e.battle?.modifiers.singleLane || t.kind === "baddie" && (e.battle?.modifiers.enemyNoMove ?? 0) >= (e.battle?.round ?? 0) ? [] : vt(t.pos, t.diagonal || (e.battle?.round ?? 0) >= 6).filter((t) => !gt(e, t));
}
function At(e, t, n, r, i = r) {
	if (J(t, n.pos, i)) return 0;
	let a = /* @__PURE__ */ new Set([t]), o = [t];
	for (let t = 1; o.length; t++) {
		let s = [];
		for (let c of o) for (let o of vt(c, r)) if (!(a.has(o) || gt(e, o))) {
			if (J(o, n.pos, i)) return t;
			a.add(o), s.push(o);
		}
		o = s;
	}
	return 100;
}
function jt(e, t) {
	let n = e.battle, r = (t.kind === "ally" ? R(e) : be(e)).filter((r) => yt(e, t, r, !n.flags.includes("movementComplete") || t.ranged)), i = r.filter((e) => (e.effects.taunt || z(e, "constantTaunt")) && J(t.pos, e.pos, t.diagonal));
	if (i.length) return n.enemyTargets.length ? [] : i;
	let a = r.filter((e) => !n.enemyTargets.includes(e.id));
	if (!a.length) return [];
	if (t.ranged || t.kind === "ally") {
		let e = (t.target === "strongest" ? Math.max : Math.min)(...a.map((e) => e.hp));
		return a.filter((t) => t.hp === e);
	}
	let o = a.map((n) => At(e, t.pos, n, t.diagonal || e.battle.round >= 6, t.diagonal)), s = Math.min(...o);
	if (s === 100) return [];
	let c = a.filter((e, t) => o[t] === s), l = (t.target === "strongest" ? Math.max : Math.min)(...c.map((e) => e.hp));
	return c.filter((e) => e.hp === l);
}
function Mt(e, t, n) {
	if (t.ranged || J(t.pos, n.pos, t.diagonal) || t.effects.daze) return [];
	let r = kt(e, t), i = r.map((r) => At(e, r, n, t.diagonal || e.battle.round >= 6, t.diagonal)), a = Math.min(...i);
	return r.filter((e, t) => i[t] === a);
}
function Nt(e, t) {
	let n = [];
	t.effects.poison && n.push("poison"), t.effects.bleed && n.push("bleed"), t.gearloc === "patches" && n.push("innateHeal"), (Y(t, "recover") || z(t, "recover") || z(t, "constantRegen")) && n.push("recover"), z(t, "booster") && t.active.some((e) => e.kind === "buffHp") && n.push("booster"), t.effects.napalm && n.push("napalm"), Y(t, "retreat") && t.hp <= 3 && n.push("retreat"), Y(t, "signal") && (t.counters.signals ?? 0) < Y(t, "signal") && n.push("signal"), Y(t, "dive") && t.effects.flight && be(e).some((n) => !n.effects.untargetable && vt(n.pos, t.diagonal).some((t) => !gt(e, t))) && n.push("dive");
	for (let e of t.active) [
		"cleanse",
		"hardy",
		"ale"
	].includes(e.kind) && n.push(e.uid);
	return n;
}
function Pt(e, t, n, r, i) {
	let a = e.battle;
	if (!a.startEffects.includes(n)) return !1;
	if (n === "poison") X(e, t, t.effects.poison, void 0, "true"), t.effects.poison = Math.max(0, t.effects.poison - 1);
	else if (n === "bleed") X(e, t, 1, void 0, "true");
	else if (n === "innateHeal") {
		if (t.upgraded && (!r || r.kind !== "gearloc")) return !1;
		W(e, t.upgraded ? r : t, 1, t.id);
	} else if (n === "recover") W(e, t, Y(t, "recover") + z(t, "recover") + z(t, "constantRegen"));
	else if (n === "booster") {
		let e = z(t, "booster");
		for (let n of t.active.filter((e) => e.kind === "buffHp")) {
			let t = Math.min(e, n.extra - n.n);
			n.n += t, e -= t;
		}
	} else if (n === "napalm") X(e, t, t.effects.napalm, F(e, e.players[(t.counters.napalmSource ?? 0) - 1] ?? "")), t.effects.napalmRounds--, t.effects.napalmRounds <= 0 && (t.effects.napalm = 0);
	else if (n === "retreat") t.pos = -1, t.hp = 0, a.queue.unshift(t.definition + "#" + t.counters.chip);
	else if (n === "signal") {
		let n = K(e, t.point === 20 ? 5 : 1);
		n && a.queue.push(n), t.counters.signals = (t.counters.signals ?? 0) + 1;
	} else if (n === "dive") {
		let o = be(e).filter((e) => !e.effects.untargetable), s = Math.min(...o.map((e) => e.hp));
		if (!o.some((n) => n.hp === s && vt(n.pos, t.diagonal).some((t) => !gt(e, t)))) return a.startEffects = a.startEffects.filter((e) => e !== n), !0;
		if (!r || r.hp !== s || !o.includes(r) || i === void 0 || gt(e, i) || !J(i, r.pos, t.diagonal)) return !1;
		t.pos = i, a.target = r.id;
	} else {
		let r = t.active.find((e) => e.uid === n);
		if (!r) return !1;
		r.n--, r.n <= 0 && (r.kind === "ale" && (t.effects.ale = 0, t.hp = 1), U(e, t, r));
	}
	return a.startEffects = a.startEffects.filter((e) => e !== n), !0;
}
function Ft(e) {
	let t = e.battle;
	t.at++, t.turn = null, t.stage = t.at >= t.order.length ? "endRound" : "startTurn", t.later.length && t.flags.includes("immediateEntry") && (t.flags = t.flags.filter((e) => e !== "immediateEntry"), t.flags.push("resume:" + t.stage), t.stage = "deployment");
}
function It(e, t) {
	if (e.battle.rolled.some((e) => !e.used && (e.face.includes("forcedBones") || e.face.includes("tainted") || t.gearloc === "boomer" && (e.skill === 16 || e.skill >= 5 && e.skill <= 11)))) return !1;
	for (; t.bones.reduce((e, t) => e + t.n, 0) > 5;) U(e, t, t.bones[t.bones.length - 1]);
	if (t.gearloc === "tantrum" && t.counters.rageStep === 5 && !t.upgraded) {
		t.counters.rageTier = 1, t.counters.rageStep = 0;
		let e = t.active.find((e) => e.kind === "rage");
		e && (e.n = 10);
	}
	return t.effects.weaken = 0, t.effects.daze = 0, t.effects.terrify = +(t.effects.terrify === 2), Ft(e), !0;
}
function Lt(e) {
	let t = e.battle;
	if (!t || e.phase !== "battle") return !1;
	if (Dt(e)) return !0;
	if (t.stage === "startRound") {
		if (t.flags.includes("orderPending")) return !1;
		if (t.hpLost = {}, t.at = 0, t.round === 1 && t.modifiers.startDamage && !t.flags.includes("startDamage")) {
			for (let n of I(e)) X(e, n, t.modifiers.startDamage);
			t.flags.push("startDamage");
		}
		if (t.round >= 6) for (let t of [...L(e)]) X(e, t, 1, void 0, "fatigue");
		if (t.modifiers.wallArrows) for (let t of [...R(e)]) X(e, t, 1, void 0, "true");
		if (t.modifiers.partyRoundDamage) for (let t of I(e)) X(e, t, 1, void 0, "true");
		if (t.modifiers.bogRound && P(e) < 3) for (let t of I(e)) X(e, t, 1, void 0, "true");
		if (t.modifiers.roundSignal && t.round >= 2 && t.round <= 5) {
			let n = K(e, 1);
			n && t.queue.push(n);
		}
		if (t.modifiers.exhaustedForStun && P(e) < t.modifiers.exhaustedForStun) {
			let t = R(e).find((e) => e.point === 20);
			t && (t.effects.stun = 1);
		}
		for (let t of I(e)) t.effects.zelfey && W(e, t, 1);
		return t.stage = "startTurn", B(e, "round", "", "", t.round), !0;
	}
	if (t.stage === "startTurn") {
		let n = F(e, t.order[t.at]);
		return !n || n.hp <= 0 || n.pos < 0 ? (Ft(e), !0) : (t.turn = n.id, t.target = null, t.rolled = [], t.spent = 0, t.rolledOnce = !1, t.backupUsed = !1, t.hpLost = {}, t.lastAttack = [], t.enemyTargets = [], t.enemyRolls = [], t.enemyBones = 0, t.tyrantFace = -1, t.flags = t.flags.filter((e) => e !== "targetResponses" && e !== "movementComplete" && !e.startsWith("armor:")), n.effects.untargetable = 0, n.effects.taunt = 0, n.effects.silverHide = 0, n.counters.axeUsed = 0, n.counters.freeMoveUsed = 0, n.counters.afterAttackMove = 0, n.counters.moveCheck = 0, n.counters.switchUsed = 0, n.counters.rushUsed = 0, n.effects.stuck = 0, n.effects.extraAttack = 0, n.effects.extraDex = 0, t.startEffects = Nt(e, n), t.stage = "move", !0);
	}
	let n = t.turn ? F(e, t.turn) : void 0;
	if (n?.kind === "gearloc" && (n.hp <= 0 || n.pos < 0) && t.stage === "resolve") return Ft(e), !0;
	if (t.stage === "move" && n) return t.startEffects.length ? !1 : n.hp <= 0 || n.pos < 0 || n.effects.stun || n.effects.stunRounds || n.kind === "object" ? (n.effects.stun = 0, n.effects.stunRounds && n.effects.stunRounds--, Ft(e), !0) : n.kind === "gearloc" || n.kind === "ally" ? !1 : (t.stage = "enemyTarget", !0);
	if (t.stage === "enemyTarget" && n) {
		let r = jt(e, n).filter((e) => !t.enemyTargets.includes(e.id));
		return r.length > 1 ? !1 : (r.length === 1 && t.enemyTargets.push(r[0].id), t.flags.includes("movementComplete") ? (t.enemyTargets.length >= n.targets || !r.length) && (t.stage = "enemySkills") : (t.target = t.enemyTargets[0] ?? null, t.stage = "enemyMove"), !0);
	}
	if (t.stage === "enemyMove" && n) {
		let r = F(e, t.target ?? ""), i = r && t.spent < 2 ? Mt(e, n, r) : [];
		return i.length > 1 ? !1 : i.length === 1 ? (n.pos = i[0], t.spent++, t.modifiers.spikeMoves && X(e, n, 1, void 0, "true"), !0) : (t.enemyTargets = t.enemyTargets.filter((t) => {
			let r = F(e, t);
			return r && yt(e, n, r);
		}), t.flags.push("movementComplete"), t.stage = t.enemyTargets.length >= n.targets ? "enemySkills" : "enemyTarget", !0);
	}
	if (t.stage === "enemySkills" && n) {
		if (!t.flags.includes("targetResponses")) return t.flags.push("targetResponses"), t.enemyTargets = t.enemyTargets.flatMap((r) => {
			let i = F(e, r), a = i.active.find((t) => t.kind === "intercept" && (F(e, t.owner)?.hp ?? 0) > 0 && (F(e, t.owner)?.pos ?? -1) >= 0), o = a ? F(e, a.owner) : i;
			a && (a.n--, a.n || U(e, i, a));
			let s = o.active.find((e) => e.kind === "smoke");
			return s ? (s.n--, s.n || U(e, o, s), []) : (o.active.some((e) => e.kind === "riposte") && J(o.pos, n.pos) && t.reactions.push("riposte:" + o.id), [o.id]);
		}), !0;
		for (let r of t.enemyTargets) {
			let i = F(e, r);
			for (let t of [
				"poison",
				"weaken",
				"stun"
			]) Y(n, t) && G(e, i, t, Y(n, t));
			Y(n, "mischief") && (i.kind === "gearloc" ? i.active.length : i.enemyDefense.length) && (t.reactions.push("mischief:" + i.id), t.pendingDamage[i.id] = Y(n, "mischief"));
		}
		return t.stage = "enemyRoll", !0;
	}
	if (t.stage === "enemyRoll" && n) {
		if (t.reactions.length) return !1;
		if (n.point === 0 && n.kind === "baddie" && t.tyrantFace < 0) return Bt(e, n), !0;
		let r = Math.max(0, n.attack + (n.ranged ? t.modifiers.rangedExtra ?? 0 : 0) + (n.hp < n.maxHp ? Y(n, "rage") : 0) + (Y(n, "raiding") ? R(e).filter((e) => e !== n && xe(e)?.creature === "orc").length : 0) + (Y(n, "compound") ? Math.min(t.round, 5) - n.attack : 0) - (n.effects.weaken ?? 0) + (n.effects.attackMod ?? 0) + (n.effects.inspired ?? 0));
		t.enemyRolls = (t.enemyTargets.length === 1 && F(e, t.enemyTargets[0])?.effects.taunt ? Array(n.targets).fill(t.enemyTargets[0]) : t.enemyTargets).map((i) => {
			let a = Ve(e, r), o = Y(n, "frenzy");
			return o && a.filter(Boolean).length >= o && a.push(...Ve(e, o)), t.enemyBones += a.filter((e) => !e).length, {
				target: i,
				dice: a
			};
		});
		let i = Ve(e, Math.max(0, n.defense - n.enemyDefense.length), !0);
		return n.enemyDefense.push(...i.filter(Boolean)), t.enemyBones += i.filter((e) => !e).length, t.stage = "enemyDamage", B(e, "enemyRoll", n.id, "", r, t.enemyRolls.flatMap((e) => e.dice)), !0;
	}
	if (t.stage === "enemyDamage" && n) {
		let r = t.enemyRolls.shift();
		if (!r) return t.stage = "enemyBackup", !0;
		let i = F(e, r.target);
		if (i && i.hp > 0) {
			let a = r.dice.reduce((e, t) => e + t, 0);
			if (X(e, i, a, n, n.effects.skullAxe ? "true" : "normal") && n.effects.dagger && G(e, i, "bleed", 1), Y(n, "engulf")) for (let t of [...L(e)].filter((e) => e !== i && J(e.pos, i.pos))) X(e, t, a, n);
			if (Y(n, "boom")) for (let t of [...L(e)].filter((e) => e !== i && e !== n && J(e.pos, i.pos))) X(e, t, Math.floor(a / 2), n);
			i.hp > 0 && Se(i, "v20") && !J(i.pos, n.pos) && t.reactions.push("sling:" + i.id + "|" + n.id);
		}
		return !0;
	}
	if (t.stage === "enemyBackup" && n) {
		let r = xe(n);
		if (r && !n.effects.disable && t.enemyBones >= r.backupCost) for (let [i, a] of Object.entries(r.backup)) if (i === "careless") X(e, n, a, n, "true");
		else if (i === "recover") W(e, n, a);
		else if (i === "taunt") G(e, n, "taunt", 1);
		else if (i === "callOrc") {
			let n = K(e, t.enemyBones >= 2 ? 5 : 1, "orc");
			n && t.queue.unshift(n);
		} else if (i === "hide") t.enemyBones >= a && G(e, n, "untargetable", 1);
		else if (i === "limit") {
			let n = t.enemyTargets.map((t) => F(e, t)).filter((e) => e?.kind === "gearloc" && e.hp > 0 && [
				"hp",
				"dex",
				"attack",
				"defense"
			].some((t) => e.counters[t + "Training"] > 0 && !e.effects["limited:" + t]));
			n.length === 1 ? t.reactions.push("limit:" + n[0].id) : n.length > 1 && t.reactions.push("limitTarget");
		} else for (let r of t.enemyTargets) {
			let o = F(e, r);
			if (i === "corrosive") for (let t of [...o.active].filter((e) => e.kind === "defense")) U(e, o, t);
			else i === "mischief" && (o.kind === "gearloc" ? o.active.length : o.enemyDefense.length) ? (t.reactions.push("mischief:" + o.id), t.pendingDamage[o.id] = a) : i === "inspire" ? Rt(e, n, a) : G(e, o, i, a);
		}
		return t.stage = "enemyTyrant", !0;
	}
	if (t.stage === "enemyTyrant" && n) {
		if (t.reactions.length) return !1;
		if (n.point === 0 && n.kind === "baddie" && !t.flags.includes("tyrantAfter")) return Vt(e, n), t.flags.push("tyrantAfter"), !0;
		t.flags = t.flags.filter((e) => e !== "tyrantAfter"), Y(n, "flight") && (n.effects.flight = +!n.effects.flight), Y(n, "inspire") && Rt(e, n, Y(n, "inspire"));
		for (let r of t.enemyTargets) {
			let t = F(e, r);
			if (t && Y(n, "corrosive")) for (let n of [...t.active].filter((e) => e.kind === "defense")) U(e, t, n);
		}
		return n.effects.weaken = 0, n.effects.inspired = 0, n.effects.daze = 0, Ft(e), !0;
	}
	if (t.stage === "endRound") {
		if (!t.flags.includes("roundEndResponses")) {
			t.flags.push("roundEndResponses");
			for (let n of I(e).filter((e) => e.hp > 0 && e.inventory.some((e) => e.card === "l16"))) t.reactions.push("roundOptics:" + n.id);
			if (t.reactions.length) return !0;
		}
		if (t.modifiers.rats) {
			let t = R(e).length;
			return t || Re(e, "s4"), Ot(e, t <= 1), !0;
		}
		if (t.modifiers.whirlwind && t.round >= 5) return Ot(e, !R(e).length), !0;
		if (t.modifiers.enemyEndFire) for (let n of [...R(e)]) X(e, n, t.modifiers.enemyEndFire, void 0, "true");
		for (let t of L(e).filter((e) => e.definition === "orbPillar")) for (let n of [...be(e)].filter((e) => !J(e.pos, t.pos))) X(e, n, 1, t);
		if (t.modifiers.golemAlly && t.round === 3) for (let t of L(e).filter((e) => e.kind === "ally" && e.definition === "goldengolem")) t.kind = "baddie", t.owner = "", t.lane = 1;
		if (t.modifiers.lateSignal && t.round >= 3 && t.round <= 5 && P(e) < 3) {
			let n = K(e, 1);
			n && t.queue.push(n);
		}
		for (let n of I(e)) n.counters.reserve > 0 && n.counters.reserve < 98 && t.round >= n.counters.reserve && (n.counters.reserve = 0, t.later.push(n.id));
		for (let n of L(e)) if (n.counters.dropInitiative) {
			let e = t.order.indexOf(n.id);
			t.order.splice(e, 1), t.order.splice(Math.min(e + n.counters.dropInitiative, t.order.length), 0, n.id), n.counters.dropInitiative = 0;
		}
		t.flags.includes("partyInspire") && (t.order = [...t.order.filter((t) => F(e, t)?.kind === "gearloc"), ...t.order.filter((t) => F(e, t)?.kind !== "gearloc")], t.flags = t.flags.filter((e) => e !== "partyInspire")), wt(e);
		for (let n of t.later) if (!(F(e, n).pos >= 0)) return t.flags.push("deployAtRoundEnd"), t.stage = "deployment", !0;
		return t.round++, t.stage = "startRound", t.at = 0, t.flags = t.flags.filter((e) => e !== "roundEndResponses"), !0;
	}
	return !1;
}
function Rt(e, t, n) {
	let r = e.battle, i = r.order.slice(r.at + 1).find((t) => {
		let n = F(e, t);
		return n && n.kind === "baddie" && n.hp > 0;
	});
	i && (r.order = r.order.filter((e) => e !== i), r.order.splice(r.at + 1, 0, i), F(e, i).effects.inspired = n, B(e, "inspire", t.id, i, n));
}
function zt(e) {
	let t = e.battle;
	return t.tyrantFace = P(e), te[e.config.tyrant].faces[t.tyrantFace];
}
function Bt(e, t) {
	let n = e.battle, r = zt(e);
	if (t.effects.skullAxe = +(r === "skullAxe"), t.effects.dagger = +(r === "dagger"), r === "omnom") for (let t of n.enemyTargets) {
		let n = F(e, t);
		for (let t of [...n.active, ...n.locked].filter((e) => [
			"defense",
			"advancedDefense",
			"constantDefense"
		].includes(e.kind))) U(e, n, t);
		n.counters.armor = 0;
	}
	if (r === "bloodRage" && (t.effects = { skullAxe: 0 }), r === "cloak") {
		let r = [...n.order.slice(n.at + 1), ...n.order.slice(0, n.at)].map((t) => F(e, t)).find((e) => e?.kind === "gearloc" && e.hp > 0 && e.pos >= 0);
		r && be(e).filter((e) => e.kind === "gearloc").length >= 2 && (t.pos = r.pos, r.pos = -1, r.counters.cloaked = 1, n.order = n.order.filter((e) => e !== r.id));
	}
	if (t.definition === "goblinking") for (let t of be(e)) n.reactions.push("knockback:" + t.id);
	B(e, "tyrantDie", t.id, r, n.tyrantFace);
}
function Vt(e, t) {
	let n = e.battle, r = te[e.config.tyrant].faces[n.tyrantFace];
	if (r === "thunderclub") for (let t of n.enemyTargets) F(e, t)?.hp && n.reactions.push("club:" + t);
	if (r.startsWith("orb:")) {
		let t = Number(r.split(":")[1]), n = [
			0,
			4,
			8,
			12
		].map((e) => e + t - 1).find((t) => !gt(e, t));
		n !== void 0 && Oe(e, "orb", e.completed.includes("t3") ? 3 : 4, n);
	}
	if (r === "charred") {
		let t = R(e).filter((e) => e.definition.startsWith("kobold")), r = t.length ? Math.min(...t.map((e) => e.hp)) : 0;
		n.reactions.push(...t.length ? ["charred"] : []), n.pendingDamage.charredHp = r;
	}
	if (r === "silverHide" && (t.effects.silverHide = 1), r === "howl") {
		let r = n.order.filter((n) => {
			let r = F(e, n);
			return r?.kind === "baddie" && r !== t && r.hp > 0;
		});
		for (let e of r) {
			let r = n.order.indexOf(e);
			r > n.order.indexOf(t.id) + 1 && r > 0 && ([n.order[r], n.order[r - 1]] = [n.order[r - 1], n.order[r]]);
		}
	}
	if (r === "enhance" && !e.persistent.antidote) for (let t of n.enemyTargets) {
		let n = F(e, t);
		n?.effects.poison && G(e, n, "poison", 3);
	}
	if (r === "poison") for (let t of n.enemyTargets) {
		let n = F(e, t);
		n && G(e, n, "poison", 2);
	}
	if (r === "bloodRage" && (n.reactions.push("marrowRetreat"), n.pendingDamage.marrowSteps = 2), r === "callHelp") {
		let t = K(e, e.players.length <= 2 ? 1 : 5);
		t && n.queue.push(t);
	}
	if (r === "carelessBomb") {
		let t = R(e).filter((e) => e.kind === "baddie"), r = Math.max(...t.map((e) => e.hp));
		n.pendingDamage.bombHp = r, n.reactions.push("carelessBomb");
	}
}
function Ht(e, t) {
	let n = Array.from({ length: 16 }, (e, t) => t).filter((t) => !gt(e, t)), r = (e) => Math.abs(ht(e) - ht(t)) + Math.abs(mt(e) - mt(t)), i = Math.max(...n.map(r));
	return n.filter((e) => r(e) === i);
}
function Ut(e, t, n) {
	let r = e.battle, i = r.reactions[0];
	if (!i) return !1;
	let a = L(e).find((t) => t.definition === e.config.tyrant), o = F(e, n.target ?? "");
	if (i.startsWith("shield:")) {
		let r = F(e, i.slice(7)), a = "shield:" + n.amount;
		if (t !== r.owner || ![
			"active",
			"locked",
			"discard"
		].includes(n.mode ?? "") || !r.counters[a] || n.mode !== "discard" && !V(e, r, "defense", r.counters[a], 0, r.id, n.mode === "locked")) return !1;
		if (delete r.counters[a], Object.keys(r.counters).some((e) => e.startsWith("shield:"))) return !0;
	} else if (i.startsWith("sling:")) {
		let [r, a] = i.slice(6).split("|"), o = F(e, r), s = F(e, a);
		if (t !== o.owner || n.mode !== "use") return !1;
		s && s.hp > 0 && o.hp > 0 && X(e, s, Ve(e, 1)[0], o);
	} else if (i.startsWith("prevent:")) {
		let [a, o] = i.slice(8).split("|"), s = F(e, a);
		if (t !== s.owner || !["use", "pass"].includes(n.mode ?? "")) return !1;
		let c = s.inventory.find((e) => e.card === "l19");
		n.mode === "use" && c ? (Pe(e, s, c), B(e, "lootUsed", s.id, c.card)) : (s.effects[o] = r.pendingDamage[i], B(e, "effect", s.id, o, s.effects[o])), delete r.pendingDamage[i];
	} else if (i.startsWith("retaliate:")) {
		let [r, a] = i.slice(10).split("|"), o = F(e, r), s = F(e, a);
		if (t !== o.owner || ![
			"poison",
			"lashback",
			"both",
			"pass"
		].includes(n.mode ?? "")) return !1;
		s && s.hp > 0 && o.hp > 0 && ((n.mode === "poison" || n.mode === "both") && G(e, s, "poison", z(o, "poisonArmor")), (n.mode === "lashback" || n.mode === "both") && X(e, s, z(o, "lashback"), o));
	} else if (i.startsWith("roundOptics:")) {
		let r = F(e, i.slice(12)), a = r.inventory.find((e) => e.card === "l16");
		if (t !== r.owner || !["use", "pass"].includes(n.mode ?? "")) return !1;
		n.mode === "use" && a && (r.counters.dropInitiative = (r.counters.dropInitiative ?? 0) - 3, a.uses--, a.uses || Pe(e, r, a), B(e, "lootUsed", r.id, a.card));
	} else if (i.startsWith("riposte:")) {
		let a = F(e, i.slice(8));
		if (t !== a.owner || ![
			"use",
			"double",
			"pass"
		].includes(n.mode ?? "")) return !1;
		if (n.mode !== "pass") {
			let t = a.active.filter((e) => e.kind === "riposte"), i = F(e, r.turn ?? "");
			if (!t.length || n.mode === "double" && t.length < 2) return !1;
			U(e, a, t[0]), r.enemyTargets = r.enemyTargets.filter((e) => e !== a.id), n.mode === "double" && (U(e, a, t[1]), i && X(e, i, 3, a));
		}
	} else if (i === "nomNext" || i === "lineupNext") {
		if (t !== e.leader || !o || o.kind !== "gearloc" || o.hp <= 0 || o.pos >= 0 || o.counters.reserve !== (i === "nomNext" ? 99 : 98)) return !1;
		o.counters.reserve = 0, r.stage !== "deployment" && (r.later.push(o.id), r.flags.push("resume:" + r.stage), r.stage = "deployment");
	} else if (i.startsWith("knockback:") || i.startsWith("club:")) {
		let o = F(e, i.slice(i.indexOf(":") + 1));
		if (!o || o.hp <= 0) return r.reactions.shift(), !0;
		if (t !== o.owner && t !== e.leader || n.pos === void 0 || !Ht(e, o.pos).includes(n.pos)) return !1;
		o.pos = n.pos, i.startsWith("club:") && X(e, o, 1, a, "true");
	} else if (i === "charred") {
		if (t !== e.leader || !o || !o.definition.startsWith("kobold") || o.hp !== r.pendingDamage.charredHp) return !1;
		if (X(e, o, 1, a), o.hp > 0) {
			let t = be(e), r = t.map((e) => Math.abs(ht(e.pos) - ht(o.pos)) + Math.abs(mt(e.pos) - mt(o.pos))), i = Math.min(...r), a = t.find((e) => e.id === n.mode);
			if (!a || r[t.indexOf(a)] !== i || n.pos === void 0 || gt(e, n.pos) || !J(n.pos, a.pos)) return !1;
			o.pos = n.pos, X(e, a, 2, o);
		}
	} else if (i === "carelessBomb") {
		if (t !== e.leader || !o || o.kind !== "baddie" || o.hp !== r.pendingDamage.bombHp) return !1;
		L(e).filter((e) => e === o || J(e.pos, o.pos)).forEach((t) => X(e, t, 3, a));
	} else if (i === "marrowRetreat") {
		if (t !== e.leader || !a) return !1;
		let i = kt(e, a), o = (e) => Math.abs(ht(e) - 2) + mt(e), s = Math.min(...i.map(o));
		if (r.pendingDamage.marrowSteps > 0 && i.length && s < o(a.pos)) {
			if (n.pos === void 0 || !i.includes(n.pos) || o(n.pos) !== s) return !1;
			if (a.pos = n.pos, r.pendingDamage.marrowSteps--, r.pendingDamage.marrowSteps > 0 && a.pos !== 2) return !0;
		}
		W(e, a, 3);
	} else if (i === "limitTarget") {
		if (t !== e.leader || !o || !r.enemyTargets.includes(o.id) || o.hp <= 0 || ![
			"hp",
			"dex",
			"attack",
			"defense"
		].some((e) => o.counters[e + "Training"] > 0 && !o.effects["limited:" + e])) return !1;
		r.reactions.splice(1, 0, "limit:" + o.id);
	} else if (i.startsWith("limit:")) {
		let r = F(e, i.slice(6));
		if (!r || t !== r.owner || ![
			"hp",
			"attack",
			"defense",
			"dex"
		].includes(n.mode ?? "")) return !1;
		let a = n.mode, o = r.counters[a + "Training"] ?? 0;
		if (!o || r.effects["limited:" + a]) return !1;
		if (r.effects["limited:" + a] = o, a === "hp") r.maxHp -= o, r.hp = Math.min(r.hp, r.maxHp);
		else if (a === "dex") r.dex -= o;
		else if (a === "attack") r.attack -= o;
		else {
			r.defense -= o;
			let t = r.active.filter((e) => e.kind === "defense");
			for (let n of t.slice(r.defense)) U(e, r, n);
		}
	} else return !1;
	return r.reactions.shift(), !0;
}
//#endregion
//#region src/games/toomanybones/adventure.ts
function Wt(e, t, n = e.leader, r = [], i = []) {
	e.phase = "challenge", e.challenge = {
		...N(),
		kind: "decision",
		by: n,
		values: r,
		ids: [t, ...i]
	};
}
function Gt(e, t = 0, n = {}, r = [], i) {
	let a = Math.max(0, e.day * e.players.length + t - (e.persistent.flare ?? 0)), o = r.filter((e) => !!e), s = Le(e, a, i, !1, !!n.removeCreature), c = n.additionsBottom ? [...s, ...o] : [...o, ...s];
	if (e.persistent.flare = 0, e.persistent.goblinPursuit) {
		let t = [...e.defeatedStack].reverse().find((e) => e.startsWith("goblin"));
		t && (e.defeatedStack = e.defeatedStack.filter((e) => e !== t), c.push(t));
	}
	Ct(e, {
		queue: c,
		modifiers: n
	});
}
function Kt(e) {
	if (e.encounterDeck.length || (e.encounterDeck = ve(e, e.unusedEncounters.splice(0))), e.encounter = e.encounterDeck.shift() ?? null, e.choice = null, !e.encounter) {
		e.phase = "recovery";
		return;
	}
	e.phase = "encounter", e.challenge = N(), B(e, "encounter", "", e.encounter);
}
function qt(e) {
	e.day++;
	for (let t of Object.keys(e.persistent).filter((e) => e.startsWith("today:"))) delete e.persistent[t];
	for (let t of I(e)) {
		t.ready = !1, t.recovery = [], t.lockAttempted = !1;
		for (let n of [...t.inventory].filter((e) => e.card === "l5")) n.uses--, n.uses <= 0 && Pe(e, t, n);
	}
	if (e.day > te[e.config.tyrant].days) {
		e.phase = "done", e.outcome = "lose", B(e, "defeatAdventure");
		return;
	}
	e.encounter = null, e.choice = null, e.phase = "day";
}
function Jt(e, t, n) {
	t.hp = Math.max(0, t.hp - n), B(e, "damage", "", t.id, n);
}
function Yt(e, t) {
	I(e).forEach((n) => Jt(e, n, t));
}
function Xt(e, t, n, r = {}, i, a) {
	Ct(e, {
		queue: Array.from({ length: t }, () => K(e, n, i, a)).filter((e) => !!e),
		modifiers: r
	});
}
function Zt(e, t, n) {
	if (e.phase !== "encounter" || t !== e.leader || !e.encounter || e.choice !== null) return !1;
	let r = O(e.encounter), i = n.option, a = e.players.length, o = a <= 2;
	if (i >= r.choices || e.persistent["today:blocked:" + e.encounter + ":" + i]) return !1;
	let s = n.target ? F(e, n.target) : ye(e, t);
	if (!s || s.kind !== "gearloc" || e.encounter === "g13" && i === 0 && I(e).reduce((e, t) => e + t.inventory.length, 0) < a || e.encounter === "o7" && i === 1 && !s.inventory.length || e.encounter === "o12" && i === 1 && s.skills.filter((e) => !M(s.gearloc, e).counter).length < 3 || e.encounter === "t8" && i === 0 && I(e).flatMap((e) => e.inventory).reduce((e, t) => e + ({
		l2: 5,
		l5: t.uses,
		l8: 3,
		l10: t.uses,
		l28: 2
	}[t.card] ?? 0), 0) < a * 2) return !1;
	e.choice = i;
	let c = (t = 0, n = {}, r = [], i) => Gt(e, t, n, r, i), l = () => q(e, !0), u = (e) => ({ noSkills: e });
	switch (e.encounter) {
		case "s1":
			if (i === 0) l();
			else {
				for (let t of I(e)) Ne(e, t, 2);
				Wt(e, "startingLoot");
			}
			break;
		case "s2":
			c(0, i === 0 ? {
				wallArrows: 1,
				retryEncounter: 1
			} : { retryEncounter: 1 });
			break;
		case "s3":
			if (i === 0) {
				if (I(e).some(() => _e(e) <= 2)) {
					let t = e.encounterDeck.findIndex((e) => e.startsWith("t"));
					if (t >= 0) {
						let [n] = e.encounterDeck.splice(t, 1);
						e.encounterDeck = [n, ...ve(e, e.encounterDeck)];
					}
				}
			} else Re(e, "s6");
			l();
			break;
		case "s4":
			i === 0 ? (e.encounterDeck = ve(e, [...e.encounterDeck, "s4"]), _e(e) <= 3 ? (Yt(e, 2), Kt(e)) : Wt(e, "discardThenRedraw", t, [1])) : c(0, { reinforced20: 3 }, [K(e, 20)]);
			break;
		case "s5":
			if (i === 0) {
				for (let t of I(e)) Ne(e, t, 1, !0);
				Wt(e, "troveRedraw");
			} else e.persistent["today:trainingAuto"] = 1, l();
			break;
		case "s6":
			i === 0 ? (e.encounterDeck = ve(e, [...e.encounterDeck, "s6"]), tn(e)) : c(0, {
				startDamage: a,
				reshuffleFailure: 1
			});
			break;
		case "g1":
			if (i === 0) c(o ? 3 : 6, {}, [], "bog");
			else {
				c();
				for (let t of I(e)) t.hp <= _e(e) && (t.effects.poison = 2);
			}
			break;
		case "g2":
			i === 0 ? c(0, o ? {} : { huntDragon: 1 }, [K(e, o ? 5 : 20, "scales", o ? "dragondelinquent" : void 0)]) : c(0, { partyRoundDamage: 1 });
			break;
		case "g3":
			i === 0 ? c(0, { reinforceLarge: 1 }) : en(e, "g3", s, !0);
			break;
		case "g4":
			i === 0 ? en(e, "g4", s, !1, [
				3,
				4,
				5,
				2
			], [
				"L",
				"T",
				"F",
				"T"
			]) : c(0, { ignoreAttackTraining: 1 });
			break;
		case "g5":
			i === 0 ? l() : c(0, { surprise: 1 }, [K(e, o ? 1 : 5), K(e, o ? 1 : 5)]);
			break;
		case "g6":
			c(0, i === 0 ? {
				dexCap: 3,
				bogRound: 1
			} : {
				shieldWall: 1,
				rangedExtra: 1
			});
			break;
		case "g7":
			c(0, i === 0 ? { singleLane: 1 } : {
				dexPenalty: 1,
				stuck: 1
			});
			break;
		case "g8":
			c(i === 0 ? 0 : -2, {}, i === 0 ? Array.from({ length: o ? 1 : 2 }, () => K(e, 5)) : []);
			break;
		case "g9":
			i === 0 ? Wt(e, "snipe", s.owner) : c(0, { roundSignal: 1 });
			break;
		case "g10":
			Wt(e, "grab");
			break;
		case "g11":
			c(0, i === 0 ? { meleeFirst: 1 } : { meleeDefenseOnly: 2 });
			break;
		case "g12":
			c(i === 0 ? o ? 6 : 12 : 0, i === 0 ? {} : { surprise: 1 });
			break;
		case "g13":
			i === 0 ? Wt(e, "bribe", t, [a]) : Wt(e, "whirlwind");
			break;
		case "g14":
			i === 0 ? Xt(e, 2, 5, { ambushFirst: 1 }) : c(_e(e) + _e(e), { surprise: 1 });
			break;
		case "g15":
			c(0, i === 0 ? { spawnHpLoss: 2 } : { fullRecovery: 1 }, i === 0 ? [K(e, o ? 1 : 5), K(e, o ? 1 : 5)] : o ? [
				K(e, 1),
				K(e, 1),
				K(e, 5)
			] : [
				K(e, 5),
				K(e, 5),
				K(e, 5)
			]);
			break;
		case "g16":
			i === 0 ? en(e, "g16", s, !1, [4, 3], ["L", "T"]) : Wt(e, "trapHp", t, [_e(e)]);
			break;
		case "g17":
			i === 0 ? Wt(e, "duel") : c(o ? 4 : 8);
			break;
		case "g18":
			i === 2 ? Wt(e, "scoutReturn", t, [2]) : c(i === 1 ? 6 : 0, { additionsBottom: 1 }, Array.from({ length: a }, () => K(e, i === 0 ? 5 : 1)));
			break;
		case "g19":
			c(0, i === 0 ? {
				noSkills: 99,
				doubleBones: 1
			} : { untilLaneOne: 1 });
			break;
		case "g20":
			c(0, i === 0 ? { noDefense: 1 } : { defenseOnly: 2 });
			break;
		case "g21":
			i === 0 ? Wt(e, "exhaustStats") : c(0, { startDamage: 2 });
			break;
		case "g22":
			c(0, i === 0 ? { huntDragon: 1 } : {
				huntDragon: 1,
				enemyEndFire: 2
			}, [K(e, 20)]);
			break;
		case "g23":
			i === 0 ? nn(e, s.owner) : (Re(e, "s6"), tn(e));
			break;
		case "g24":
			if (i === 0) {
				let t = e.troveDeck.find((e) => {
					let t = Qt(e);
					return Math.max(...t) >= 5;
				});
				if (t ??= e.troveDeck[0], !t) return !1;
				e.troveDeck = e.troveDeck.filter((e) => e !== t), e.troveDeck.unshift(t), en(e, "g24", s, !0);
			} else tn(e);
			break;
		case "g25":
			rn(e);
			break;
		case "g26":
			i === 0 ? en(e, "g26", s, !0) : Wt(e, "barrelCount");
			break;
		case "g27":
			an(e);
			break;
		case "g28":
			on(e);
			break;
		case "g29":
			sn(e);
			break;
		case "g30":
			Wt(e, "gambleLoot");
			break;
		case "o1":
			if (i === 0) c(2, {
				singleLane: 1,
				oneAtTime: 1
			});
			else {
				let t = Le(e, e.day);
				for (let n of t) T(n.split("#")[0]).ranged && Jt(e, s, Ve(e, 2).reduce((e, t) => e + t, 0));
				for (let n of t) e.stacks[T(n.split("#")[0]).point].push(n);
				q(e, s.hp > 0);
			}
			break;
		case "o2":
			c(2, i === 0 ? { rangedTop: 1 } : {
				surprise: 1,
				enemyNoMove: 1
			});
			break;
		case "o3":
			i === 0 ? Xt(e, 1, 5, {}, "bog", "stonegolem") : c(0, { golemAlly: 3 });
			break;
		case "o4":
			Ct(e, {
				queue: [K(e, 1, "beast", "direwolfpup"), K(e, 5, "beast", "direwolf")].filter((e) => !!e),
				modifiers: i === 0 ? u(2) : { skillOnly: 2 }
			});
			break;
		case "o5":
			i === 0 ? en(e, "o5", s, !1, [3, 2], ["F", "L"]) : (Jt(e, s, 3), e.persistent.noHealing = e.day, l());
			break;
		case "o6":
			Xt(e, 2, 5, i === 0 ? { trapStun: 2 } : {
				surprise: 1,
				spikeMoves: 1
			});
			break;
		case "o7":
			i === 0 ? c(0, { lateSignal: 1 }) : Wt(e, "offering");
			break;
		case "o8":
			i === 0 ? ($t(e, s, 5), c(0, {}, [K(e, 5)])) : (s.inventory.push(Me(e, "water")), l());
			break;
		case "o9":
			c(0, i === 0 ? { spawnHpLoss: 2 } : { trader: 1 }, [K(e, 5)]);
			break;
		case "o10":
			c(0, i === 0 ? {
				weakenFirst: 2,
				attackPlus: 1,
				noSkills: 2
			} : { noSkills: 1 });
			break;
		case "o11":
			i === 0 ? Ct(e, {
				queue: Le(e, e.day, void 0, !0),
				modifiers: { returnDead: 3 }
			}) : Ct(e, {
				queue: [K(e, 5, void 0, void 0, !1), K(e, 5, void 0, void 0, !1)].filter((e) => !!e),
				modifiers: { freeAfterAttack: 3 }
			});
			break;
		case "o12":
			i === 0 ? (s.maxHp = Math.max(1, s.maxHp - 1), s.hp = Math.min(s.hp, s.maxHp), l()) : Wt(e, "tripSkills", s.owner, [3]);
			break;
		case "t1":
			i === 0 ? c(0, { nomVisit: 1 }, [
				"nom",
				K(e, o ? 1 : 5),
				K(e, o ? 1 : 5)
			]) : (Yt(e, 2), e.persistent["today:skipRecovery"] = 1, e.encounterDeck = ve(e, [...e.encounterDeck, "t1"]), l());
			break;
		case "t3":
			c(0, { orbPillar: a * 3 });
			break;
		case "t4":
			c(0, i === 0 ? { noBackup: 1 } : { orbBones: 1 });
			break;
		case "t6":
			i === 0 ? c(0, {}, Array.from({ length: o ? 1 : 2 }, () => K(e, 5, "beast"))) : Wt(e, "wolfHand");
			break;
		case "t7":
			c(0, {
				reverseSetup: 1,
				enemySurprise: 1
			}, [], "beast");
			break;
		case "t8":
			i === 0 ? Wt(e, "healDuster", t, [a * 2]) : c();
			break;
		case "t10": {
			let t = K(e, o ? 1 : 5, "beast");
			if (t) {
				let n = e.persistent.mulmeshReserve ?? 0;
				e.persistent.mulmeshReserve = n + 1, e.persistent["reserve:" + t] = 1;
			}
			e.encounterDeck = ve(e, [...e.encounterDeck, "t10"]), Kt(e);
			break;
		}
		case "t12":
			if (i === 0) Wt(e, "bogIngredients");
			else {
				if (![
					["bogpole", "bogfrog"],
					["boglurk"],
					["stonegolem"],
					["claygolem"]
				].every((t) => e.defeatedStack.some((e) => t.includes(e.split("#")[0])))) return !1;
				e.persistent.antidote = 1, l();
			}
			break;
		case "t14":
			c(0, { returnOrcs: 3 }, [], "orc");
			break;
		case "t15":
			c(0, { removeCreature: i === 0 ? 5 : 3 }, [], i === 0 ? "bog" : "scales");
			break;
		case "t17":
			i === 0 ? c() : Wt(e, "goblinBomb");
			break;
		case "t18":
			e.persistent.goblinPursuit = 1, c(0, {}, [K(e, o ? 1 : 5, "goblin")]);
			break;
		default: return !1;
	}
	return !0;
}
function Qt(e) {
	return ae(e).locks;
}
function $t(e, t, n) {
	t.counters.prepBuff = (t.counters.prepBuff ?? 0) + n, B(e, "buff", t.id, "", n);
}
function en(e, t, n, r, i, a) {
	e.phase = "challenge", e.challenge = {
		...N(),
		kind: "lock",
		by: n.owner,
		ids: [t],
		values: [],
		data: { trove: +!!r }
	};
	let o = r ? Ne(e, n, 1, !0)[0] : void 0;
	o && e.challenge.ids.push(o.uid, n.id), Ue(e, n.owner, n.id, o?.uid ?? t, i, a);
}
function tn(e) {
	e.phase = "challenge", e.challenge = {
		...N(),
		kind: "darts",
		by: e.players[0],
		ids: [...e.players],
		values: [
			10,
			10,
			0,
			0,
			0,
			0,
			0,
			0
		],
		data: { setup: 1 }
	};
}
function nn(e, t) {
	e.phase = "challenge", e.challenge = {
		...N(),
		kind: "flick",
		by: t,
		values: [
			125,
			50,
			375,
			50,
			625,
			50,
			875,
			50
		],
		data: {}
	};
}
function rn(e) {
	Ct(e, {
		queue: [],
		modifiers: { rats: e.players.length + 1 }
	});
	for (let t = 0; t <= e.players.length; t++) Oe(e, "rat", _e(e), t < 4 ? 4 + t : t - 4);
}
function an(e) {
	e.phase = "challenge", e.challenge = {
		...N(),
		kind: "lanterns",
		by: e.players[0],
		values: I(e).map(() => _e(e)),
		ids: [...e.players]
	};
}
function on(e) {
	e.phase = "challenge", e.challenge = {
		...N(),
		kind: "critters",
		by: e.leader,
		values: Array(16).fill(1),
		ids: [...e.players],
		data: {
			deploy: 1,
			turn: 0,
			moved: 0
		}
	};
	for (let t of I(e)) t.pos = -1;
}
function sn(e) {
	e.phase = "challenge", e.challenge = {
		...N(),
		kind: "rubble",
		by: e.leader,
		values: Array(16).fill(0),
		ids: [...e.players],
		data: {
			deploy: 1,
			rubblePlaced: 0
		}
	};
	for (let t of I(e)) t.pos = -1;
}
//#endregion
//#region src/games/toomanybones/darts.ts
function cn(e, t) {
	let n = t === 0 ? [
		e.data.attack,
		e.data.defense,
		e.data.poison
	] : [
		2,
		0,
		1
	];
	return [
		"attack",
		"defense",
		"status"
	].flatMap((e, t) => Array.from({ length: n[t] ?? 0 }, (t, n) => ({
		id: e + ":" + n,
		kind: e,
		index: n
	}))).filter((n) => n.kind === "attack" || !(e.data[n.kind + ":" + t + ":" + n.index] > 0));
}
function ln(e, t, n) {
	for (let r of Object.keys(e.data).filter((e) => e.startsWith("status:" + (1 - t) + ":"))) e.data[r] === n && (e.data[r] = 0);
	n === 1 ? e.values[4 + t] = 0 : e.data[(n === 2 ? "weaken:" : "stun:") + t] = 0;
}
function un(e, t, n) {
	for (let r of Object.keys(e.data).filter((e) => e.startsWith("defense:" + t + ":"))) {
		let t = Math.min(n, e.data[r]);
		n -= t, e.data[r] -= t;
	}
	return e.values[2 + t] = Object.entries(e.data).filter(([e]) => e.startsWith("defense:" + t + ":")).reduce((e, [, t]) => e + t, 0), n;
}
function dn(e, t, n = []) {
	let r = e.challenge, i = +!t, a = 1 - i;
	if (r.values[i] -= r.values[4 + i], r.values[4 + i] = Math.max(0, r.values[4 + i] - 1), r.values[4 + i] || ln(r, i, 1), r.values[i] <= 0) return !0;
	if (r.data["stun:" + i]) return ln(r, i, 3), !0;
	let o = cn(r, i), s = Math.min(r.data["weaken:" + i] ?? 0, o.length), c = t ? n : o.slice(0, s).map((e) => e.id);
	if (new Set(c).size !== c.length || c.length !== s || c.some((e) => !o.some((t) => t.id === e))) return !1;
	ln(r, i, 2);
	let l = [], u = 0, d = 0;
	for (let t of o.filter((e) => !c.includes(e.id))) if (t.kind === "defense") {
		let n = Ve(e, 1, !0)[0];
		r.data["defense:" + i + ":" + t.index] = n, l.push(n), n || u++;
	} else if (t.kind === "attack") {
		let t = Ve(e, 1)[0];
		d += t, l.push(t), t || u++;
	} else {
		let n = P(e), o = n === 0 || n === 4 ? 2 : n === 3 ? 3 : 1;
		ln(r, a, o), r.data["status:" + i + ":" + t.index] = o, o === 1 ? r.values[4 + a] = n === 1 ? 1 : n === 2 ? 2 : 3 : r.data[(o === 2 ? "weaken:" : "stun:") + a] = o === 3 || n === 0 ? 1 : 2, l.push(n + 10);
	}
	return r.values[2 + i] = Object.entries(r.data).filter(([e]) => e.startsWith("defense:" + i + ":")).reduce((e, [, t]) => e + t, 0), r.values[a] -= un(r, a, d), t && (r.data.bones = u), r.dice = l, B(e, "dartsRoll", t ? r.by : "opponent", "", d, l), !0;
}
//#endregion
//#region src/games/toomanybones/challenges.ts
function fn(e, t, n) {
	let r = e.challenge, i = r.ids[0], a = ye(e, t), o = F(e, n.target ?? a?.id ?? "");
	if (r.kind !== "decision" || r.by !== t || !a) return !1;
	let s = e.players.length;
	switch (i) {
		case "pickEncounter": return r.ids.slice(1).includes(n.target ?? "") ? (e.encounterDeck.push(...r.ids.slice(1).filter((e) => e !== n.target)), e.encounter = n.target, e.choice = null, e.phase = "encounter", e.challenge = N(), B(e, "encounter", "", e.encounter), !0) : !1;
		case "startingLoot": {
			let t = I(e)[r.step], i = t.inventory.find((e) => e.uid === n.target);
			if (!i) return !1;
			let a = t.inventory.slice(-2);
			return a.includes(i) ? (Pe(e, t, a.find((e) => e !== i)), r.step++, r.step === s && q(e, !0), !0) : !1;
		}
		case "troveRedraw": {
			let t = I(e)[r.step], i = t.inventory[t.inventory.length - 1];
			if (n.option === 1) Pe(e, t, i), Ne(e, t, 1, !0);
			else if (n.option !== 0) return !1;
			return r.step++, r.step === s && (r.ids = ["troveImmediate"], r.step = 0), !0;
		}
		case "troveImmediate": {
			let t = I(e)[r.step];
			if (n.option === 0) {
				let r = t.inventory.find((e) => e.uid === n.target && ae(e.card).trove && e.locks < 3);
				if (!r) return !1;
				Ue(e, t.owner, t.id, r.uid);
			} else if (n.option !== 1) return !1;
			return r.step++, r.step === s && !e.lock && q(e, !0), !0;
		}
		case "discardThenRedraw":
		case "bribe": {
			let t = n.ids ?? [];
			if (t.length !== r.values[0] || new Set(t).size !== t.length) return !1;
			for (let n of t) {
				let t = I(e).find((e) => e.inventory.some((e) => e.uid === n));
				if (!t) return !1;
				Pe(e, t, t.inventory.find((e) => e.uid === n));
			}
			return i === "bribe" ? (Re(e, "s6"), q(e, !0)) : Kt(e), !0;
		}
		case "snipe": {
			let t = n.amount;
			if (t === void 0 || t > a.attack) return !1;
			let r = Ve(e, t);
			return r.reduce((e, t) => e + t, 0) >= 2 ? (Gt(e, -2), a.counters.brokenAttack = t) : (e.choice = 1, Gt(e, 0, { roundSignal: 1 })), a.counters.brokenAttack = t, B(e, "challengeRoll", a.id, i, 0, r), !0;
		}
		case "grab": {
			let t = n.amount;
			if (!t || t > 6) return !1;
			let r = _e(e);
			return r > t && Ne(e, a, t), Gt(e, r > t ? 0 : t), B(e, "challengeRoll", a.id, i, r), !0;
		}
		case "whirlwind":
			if (!o || o.kind !== "gearloc") return !1;
			for (let t of I(e)) t !== o && (t.counters.reserve = 6);
			Ct(e, {
				queue: [],
				modifiers: { whirlwind: 1 }
			});
			for (let [t, n] of [
				3,
				5,
				4,
				4
			].entries()) Oe(e, "cloaked", n, 4 + t);
			return !0;
		case "trapHp": {
			let t = I(e).map((e) => Math.abs(e.hp - r.values[0])), n = Math.min(...t);
			return !o || o.kind !== "gearloc" || Math.abs(o.hp - r.values[0]) !== n ? !1 : (Jt(e, o, 3), Gt(e), !0);
		}
		case "duel":
			if (!o || o.kind !== "gearloc") return !1;
			for (let t of I(e)) t.counters.reserve = t === o ? 0 : 3;
			return Gt(e, 0, { duel: 3 }), !0;
		case "scoutReturn": {
			let t = n.amount;
			if (!t || ![
				1,
				5,
				20
			].includes(t)) return !1;
			let r = e.stacks[t]?.slice(0, 2) ?? [];
			for (let i of r) n.ids?.includes(i) ? e.stacks[t] = [...e.stacks[t].filter((e) => e !== i), i] : e.scouted[t] = [...e.scouted[t] ?? [], i];
			return e.encounterDeck.unshift("g18"), q(e, !1), !0;
		}
		case "exhaustStats": {
			let t = n.amount ?? -1, r = n.option;
			if (t < 0 || t + r < 1 || t + r > 6 || I(e).some((e) => e.attack < t || e.defense < r)) return !1;
			Gt(e, 0, {
				exhaustedForStun: t + r,
				huntDragon: 1
			}, [K(e, 20)]);
			for (let n of I(e)) n.counters.brokenAttack = t, n.counters.brokenDefense = r;
			return !0;
		}
		case "barrelCount": {
			let t = n.amount;
			return !t || t > 4 ? !1 : (e.challenge = {
				...N(),
				kind: "barrels",
				by: e.players[0],
				values: Array.from({ length: t }, () => _e(e)).sort((e, t) => t - e),
				ids: [...e.players]
			}, !0);
		}
		case "gambleLoot": {
			let t = n.ids ?? [];
			if (new Set(t).size !== t.length || t.length > (s === 1 ? 2 : 4)) return !1;
			for (let n of t) {
				let t = I(e).find((e) => e.inventory.some((e) => e.uid === n));
				if (!t) return !1;
				Pe(e, t, t.inventory.find((e) => e.uid === n));
			}
			let r = Array.from({ length: t.length * (s === 1 ? 2 : 1) }, () => _e(e)), o = r.reduce((e, t) => e + t, 0), c = o === 0 ? E(-1) : o <= 6 ? E(1, 1) : o <= 12 ? E(1, 2) : o <= 18 ? E(1, 2, 0, 0, 1) : E(1, 2, 0, 0, 2);
			return B(e, "challengeRoll", a.id, i, o, r), q(e, !0, c), !0;
		}
		case "offering": {
			let t = a.inventory.find((e) => e.uid === n.target);
			return t ? (Pe(e, a, t), _e(e) >= 4 ? q(e, !0) : (e.phase = "encounter", e.choice = null), !0) : !1;
		}
		case "tripSkills": {
			let t = (n.ids ?? []).map(Number);
			if (t.length !== 3 || new Set(t).size !== 3 || t.some((e) => !a.skills.includes(e) || M(a.gearloc, e).counter)) return !1;
			for (let n of t) e.persistent["trip:" + a.id + ":" + n] = 1;
			return q(e, !0), !0;
		}
		case "wolfHand": return !o || o.kind !== "gearloc" ? !1 : (_e(e) <= 2 && (o.maxHp = Math.max(o.counters.baseHp, o.maxHp - 3), o.hp = Math.min(o.hp, o.maxHp)), q(e, !0), !0);
		case "healDuster": {
			let t = n.ids ?? [];
			if (new Set(t).size !== t.length) return !1;
			let i = 0;
			for (let n of t) {
				let t = I(e).find((e) => e.inventory.some((e) => e.uid === n)), r = t?.inventory.find((e) => e.uid === n);
				if (!t || !r) return !1;
				let a = {
					l2: 5,
					l5: r.uses,
					l8: 3,
					l10: r.uses,
					l28: 2
				};
				if (!a[r.card]) return !1;
				i += a[r.card], Pe(e, t, r);
			}
			return i < r.values[0] ? !1 : (q(e, !0), !0);
		}
		case "bogIngredients": return [0, 1].includes(n.option) ? (Ct(e, {
			queue: Array.from({ length: n.option === 0 ? 6 : 3 }, () => K(e, n.option === 0 ? 1 : 5)).filter((e) => !!e),
			modifiers: { reshuffleAlways: 1 }
		}), !0) : !1;
		case "goblinBomb": return [
			"L",
			"T",
			"F"
		].includes(n.target ?? "") ? (r.kind = "lock", r.ids = ["t17"], r.data.bombType = "LTF".indexOf(n.target), Ue(e, t, a.id, "bomb", [3], [n.target]), !0) : !1;
		default: return !1;
	}
}
function pn(e) {
	let t = e.challenge;
	if (t.kind !== "lock" || e.lock) return !1;
	let n = t.ids[0], r = !!e.persistent.lockSuccess, i = ye(e, t.by), a = F(e, t.ids[2] ?? i.id) ?? i, o = a.inventory.find((e) => e.uid === t.ids[1]);
	if (n === "g4") {
		if (t.data.opened = (t.data.opened ?? 0) + e.persistent.lockOpened, t.data.opened >= e.players.length) return Gt(e, 0, { surprise: 1 }), !0;
		if (t.step++, t.step < e.players.length) {
			let n = ye(e, e.players[t.step]);
			t.by = n.owner, Ue(e, n.owner, n.id, "shackle", [
				3,
				4,
				5,
				2
			], [
				"L",
				"T",
				"F",
				"T"
			]);
			let r = e.lock;
			r && (r.at = t.data.opened, r.startedAt = t.data.opened);
		} else I(e).forEach((t) => Jt(e, t, 2)), e.choice = 1, Gt(e, 0, { ignoreAttackTraining: 1 });
		return !0;
	}
	if (n === "g24") return r ? q(e, !0) : (t.step++, t.step >= e.players.length ? q(e, !1) : (t.by = e.players[t.step], Ue(e, t.by, a.id, o.uid))), !0;
	if (n === "t17") return r || (t.data.failed = 1), t.step++, t.step < e.players.length ? (t.by = e.players[t.step], t.kind = "decision", t.ids = ["goblinBomb"]) : (t.data.failed || (e.persistent.goblinBomb = 1), Gt(e, 0, { startDamage: t.data.failed ? 2 : 0 })), !0;
	if (n === "g3") return !r && o && Pe(e, i, o), Gt(e), !0;
	if (n === "g16") return r ? Gt(e, 0, { enemySurprise: 1 }) : (e.choice = 1, Wt(e, "trapHp", e.leader, [_e(e)])), !0;
	if (n === "g26") return !r && o && Pe(e, i, o), q(e, !0), !0;
	if (n === "o5") {
		if (r) {
			for (let t of [...i.inventory]) Pe(e, i, t);
			q(e, !0);
		} else Jt(e, i, 2), e.persistent["today:blocked:o5:0"] = 1, e.phase = "encounter", e.choice = null;
		return !0;
	}
	return !1;
}
function mn(e, t, n) {
	let r = e.challenge;
	if (r.kind !== "flick" || r.by !== t || r.data["shot:" + n.lane] || n.x < n.lane * 250 + 25 || n.x > n.lane * 250 + 225) return !1;
	let i = n.x, a = 940, o = n.vx, s = n.vy, c = Array.from({ length: 4 }, () => [0, 0]), l = /* @__PURE__ */ new Set(), u = [i, a];
	for (let e = 0; e < 600; e++) {
		let t = 1 / 120;
		i += o * t, a += s * t, o *= .99, s *= .99;
		for (let e = 0; e < 4; e++) {
			let n = r.values[2 * e], u = r.values[2 * e + 1], d = n - i, f = u - a, p = Math.hypot(d, f);
			if (p < 42 && p > .01 && o * d + s * f > 0) {
				let t = d / p, r = f / p, m = (o * t + s * r) * .75;
				c[e][0] += t * m, c[e][1] += r * m, o -= t * m, s -= r * m, l.add(e), i = n - t * 42, a = u - r * 42;
			}
			n += c[e][0] * t, u += c[e][1] * t, c[e][0] *= .97, c[e][1] *= .97, r.values[2 * e] = n, r.values[2 * e + 1] = u;
		}
		if (e % 8 == 0 && u.push(i, a), Math.hypot(o, s) < 5 && c.every(([e, t]) => Math.hypot(e, t) < 5)) break;
	}
	return r.dice = u, r.data["shot:" + n.lane] = 1, r.step++, l.has(n.lane) && (r.data["hit:" + n.lane] = 1), B(e, "flick", t, "", l.size), r.step === 4 && (r.data.complete = 1), !0;
}
function hn(e) {
	let t = e.challenge;
	if (t.values[1] <= 0 && t.values[0] > 0) t.wins.push(t.by), Ne(e, ye(e, t.by), e.encounter === "s6" ? 2 : 1);
	else if (e.encounter === "s6" && ye(e, t.by).inventory.length) {
		t.data.discard = 1;
		return;
	}
	t.step++, t.step >= e.players.length ? q(e, t.wins.length > 0 || e.encounter === "s6", e.encounter === "g23" || e.encounter === "g24" ? E(1) : E()) : (t.by = e.players[t.step], t.values = [
		10,
		10,
		0,
		0,
		0,
		0,
		0,
		0
	], t.data = { setup: 1 });
}
function gn(e, t, n) {
	let r = e.challenge, i = ye(e, t);
	if (r.by !== t || !i || e.lock) return !1;
	if (r.kind === "decision") return fn(e, t, n);
	if (r.kind === "flick" && r.data.complete) {
		let t = [
			0,
			1,
			2,
			3
		].filter((e) => r.data["hit:" + e] && r.values[e * 2] >= 21 && r.values[e * 2] <= 979 && r.values[e * 2 + 1] >= 21 && r.values[e * 2 + 1] <= 979).length;
		return q(e, t >= 3), !0;
	}
	if (r.kind === "darts") {
		if (r.data.discard) {
			let t = i.inventory.find((e) => e.uid === n.target);
			return t ? (Pe(e, i, t), r.data.discard = 0, r.step++, r.step >= e.players.length ? q(e, !0, E()) : (r.by = e.players[r.step], r.data = { setup: 1 }, r.values = [
				10,
				10,
				0,
				0,
				0,
				0,
				0,
				0
			]), !0) : !1;
		}
		if (r.data.setup) {
			let e = n.amount ?? -1, t = n.option, i = 3 - e - t;
			return ![
				e,
				t,
				i
			].some((e) => e < 0 || e > 2) && (r.data = {
				attack: e,
				defense: t,
				poison: i,
				enemyTurn: 1
			}, !0);
		}
		if (r.data.bones > 0) {
			let t = r.data.bones;
			if (n.option === 1 && t >= 1) {
				let [e, t, i] = (n.target ?? "poison:0").split(":"), a = Number(t);
				if (![0, 1].includes(a)) return !1;
				if (e === "defense") {
					let e = "defense:" + a + ":" + i;
					if (!r.data[e]) return !1;
					r.values[2 + a] -= r.data[e], r.data[e] = 0;
				} else {
					let t = [
						"poison",
						"weaken",
						"stun"
					].indexOf(e) + 1;
					if (!t) return !1;
					ln(r, a, t);
				}
			} else if (n.option === 2 && t >= 1) {
				let e = Object.keys(r.data).find((e) => e.startsWith("defense:1:") && r.data[e] > 0);
				e && (r.values[3] -= r.data[e], r.data[e] = 0);
			} else if (n.option === 3 && t >= 2) r.data["stun:1"] = 1;
			else if (n.option === 4 && t >= 3) r.values[1] = 0;
			else if (n.option !== 0) return !1;
			return r.data.bones = 0, r.values[0] <= 0 || r.values[1] <= 0 ? hn(e) : r.data.enemyTurn = 1, !0;
		}
		return r.data.enemyTurn || !dn(e, !0, n.ids) ? !1 : ((r.values[0] <= 0 || r.values[1] <= 0) && !r.data.bones ? hn(e) : r.data.bones || (r.data.enemyTurn = 1), !0);
	}
	if (r.kind === "barrels") {
		let t = Ve(e, i.attack), n = t.reduce((e, t) => e + t, 0);
		return n >= r.values[0] && (r.values.shift(), r.data.destroyed = (r.data.destroyed ?? 0) + 1), r.step++, B(e, "challengeRoll", i.id, "barrels", n, t), r.step >= e.players.length || !r.values.length ? q(e, !0, {
			...O(e.encounter).reward,
			loot: r.data.destroyed ?? 0
		}) : r.by = e.players[r.step], !0;
	}
	if (r.kind === "lanterns") {
		let t = n.option;
		if (t >= r.values.length || r.values[t] <= 0 || !i.gearloc) return !1;
		let a = ce[i.gearloc][P(e)];
		return a >= r.values[t] && (r.values[t] = 0, r.data.hits = (r.data.hits ?? 0) + 1), r.step++, B(e, "challengeRoll", i.id, "lanterns", a), r.step >= e.players.length ? q(e, !0, {
			...O(e.encounter).reward,
			loot: r.data.hits ?? 0
		}) : r.by = e.players[r.step], !0;
	}
	if (r.kind === "critters") {
		if (r.data.deploy) return !1;
		if (r.data.critterSelect) {
			let t = r.values.flatMap((e, t) => e > 0 && t % 4 === r.data.lane ? [t] : []), i = Math.min(...r.values.filter((e) => e > 0)), a = t.length ? t : r.values.flatMap((e, t) => e === i ? [t] : []), o = n.option, s = Number(n.target);
			if (!a.includes(o)) return !1;
			let c = r.values.flatMap((e, t) => e > 0 && J(o, t) ? [t] : []);
			if (t.length && c.length) {
				if (!c.includes(s)) return !1;
				r.values[s] += r.values[o];
			}
			return r.values[o] = 0, r.data.critterSelect = 0, r.values.some(Boolean) || q(e, !0), !0;
		}
		if (n.target === "pass") return r.data.enemyTurn = 1, r.data.moved = 0, r.step = (r.step + 1) % e.players.length, r.by = e.players[r.step], !0;
		let t = n.option;
		if (t > 15 || r.values[t] <= 0 || !i.ranged && !J(i.pos, t) || (n.amount ?? 0) < 1 || n.amount > Math.min(i.attack, i.dex - r.data.moved)) return !1;
		let a = Ve(e, n.amount), o = a.reduce((e, t) => e + t, 0);
		return o >= r.values[t] && (i.counters.prepBuff = (i.counters.prepBuff ?? 0) + r.values[t]), r.values[t] = 0, r.data.enemyTurn = 1, r.data.moved = 0, r.step = (r.step + 1) % e.players.length, r.by = e.players[r.step], B(e, "challengeRoll", i.id, "critters", o, a), r.values.some(Boolean) || q(e, !0), !0;
	}
	if (r.kind === "rubble") {
		if (r.data.deploy || r.data["throws:" + t] >= 2 || n.option >= 16) return !1;
		let a = n.option, o = Ve(e, 2), s = o.reduce((e, t) => e + t, 0);
		for (let e = 0; e < 16; e++) {
			let t = e === a ? s : J(e, a) ? Math.floor(s / 2) : 0;
			r.values[e] = Math.max(0, r.values[e] - t);
		}
		return r.data["throws:" + t] = (r.data["throws:" + t] ?? 0) + 1, B(e, "challengeRoll", i.id, "rubble", s, o), r.values.some(Boolean) ? e.players.every((e) => r.data["throws:" + e] >= 2) ? q(e, !1) : r.data["throws:" + t] >= 2 && (r.by = e.players.find((e) => !(r.data["throws:" + e] >= 2))) : q(e, !0), !0;
	}
	return !1;
}
function _n(e, t, n) {
	let r = e.challenge, i = ye(e, t);
	return !i || !["critters", "rubble"].includes(r.kind) || !r.data.deploy ? !1 : r.kind === "rubble" && (r.data.rubblePlaced ?? 0) < e.players.length * 2 ? t !== e.leader || n >= 8 || r.values[n] ? !1 : (r.values[n] = 3, r.data.rubblePlaced = (r.data.rubblePlaced ?? 0) + 1, !0) : i.pos >= 0 || n < (r.kind === "rubble" || i.ranged ? 12 : 8) || r.kind === "critters" && !i.ranged && n >= 12 || gt(e, n) ? !1 : (i.pos = n, r.values[n] = 0, I(e).every((e) => e.pos >= 0) && (r.data.deploy = 0, r.by = e.players[0], r.data.enemyTurn = +(r.kind === "critters")), !0);
}
function vn(e, t, n) {
	let r = e.challenge, i = ye(e, t);
	return r.kind !== "critters" || r.by !== t || r.data.deploy || r.data.enemyTurn || r.data.critterSelect || !i || r.data.moved >= i.dex || r.values[n] || gt(e, n) || !J(i.pos, n) ? !1 : (i.pos = n, r.data.moved++, !0);
}
function yn(e) {
	let t = e.challenge;
	if (t.kind === "lock") return pn(e);
	if (t.kind === "decision" && t.ids[0] === "troveImmediate" && t.step >= e.players.length && !e.lock) return q(e, !0), !0;
	if (t.kind === "darts" && t.data.enemyTurn) return dn(e, !1), t.data.enemyTurn = 0, (t.values[0] <= 0 || t.values[1] <= 0) && hn(e), !0;
	if (t.kind === "critters" && t.data.enemyTurn) {
		let n = _e(e);
		return t.data.lane = (n - 1) % 4, t.dice = [n], t.data.enemyTurn = 0, t.data.critterSelect = 1, t.values.some(Boolean) || q(e, !0), !0;
	}
	return !1;
}
//#endregion
//#region src/games/toomanybones/schema.ts
var bn = t.enum([
	"boomer",
	"patches",
	"picket",
	"tantrum"
]), xn = t.enum([
	"nom",
	"gendricks",
	"duster",
	"mulmesh",
	"drellen",
	"marrow",
	"goblinking"
]), Sn = t.object({
	tyrant: xn.default("nom"),
	difficulty: t.enum([
		"adventurer",
		"heroic",
		"legendary"
	]).default("adventurer")
}).prefault({}), Z = t.string().max(160), Cn = t.record(t.string(), t.number().finite()), wn = t.object({
	uid: Z,
	owner: Z,
	skill: t.int().min(0).max(16),
	kind: Z,
	n: t.number(),
	extra: t.number(),
	reusable: t.boolean()
}), Tn = t.object({
	uid: Z,
	card: Z,
	uses: t.int().nonnegative(),
	locks: t.int().min(0).max(3)
}), En = t.object({
	id: Z,
	owner: Z,
	kind: t.enum([
		"gearloc",
		"baddie",
		"object",
		"ally"
	]),
	definition: Z,
	gearloc: bn.nullable(),
	hp: t.number(),
	maxHp: t.number(),
	dex: t.number(),
	attack: t.number(),
	defense: t.number(),
	pos: t.int().min(-1).max(15),
	lane: t.int().min(0).max(4),
	initiative: t.number(),
	ranged: t.boolean(),
	diagonal: t.boolean(),
	point: t.number(),
	target: t.enum(["weakest", "strongest"]),
	targets: t.int(),
	skills: t.array(t.int().min(1).max(16)),
	exhausted: t.array(t.int()),
	active: t.array(wn),
	locked: t.array(wn),
	bones: t.array(wn),
	enemyDefense: t.array(t.number().nonnegative()),
	effects: Cn,
	counters: Cn,
	inventory: t.array(Tn),
	training: t.int().nonnegative(),
	failedTraining: t.array(Z),
	upgraded: t.boolean(),
	ready: t.boolean(),
	recovery: t.array(Z),
	lockAttempted: t.boolean()
}), Dn = t.object({
	uid: Z,
	kind: t.enum([
		"attack",
		"defense",
		"skill"
	]),
	skill: t.int(),
	face: Z,
	used: t.boolean(),
	aim: t.int().min(-1).max(15)
}), On = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("chooseGearloc"),
		gearloc: bn
	}),
	t.object({
		type: t.literal("choose"),
		option: t.int().min(0).max(15),
		target: Z.optional(),
		amount: t.int().min(0).max(40).optional(),
		ids: t.array(Z).max(20).optional()
	}),
	t.object({
		type: t.literal("train"),
		stat: t.enum([
			"hp",
			"dex",
			"attack",
			"defense",
			"skill"
		]),
		skill: t.int().min(1).max(16).optional()
	}),
	t.object({ type: t.literal("ready") }),
	t.object({
		type: t.literal("deploy"),
		pos: t.int().min(0).max(15),
		unit: Z.optional()
	}),
	t.object({
		type: t.literal("move"),
		pos: t.int().min(0).max(15),
		unit: Z.optional()
	}),
	t.object({
		type: t.literal("roll"),
		attack: t.int().min(0).max(30),
		defense: t.int().min(0).max(30),
		skills: t.array(t.int().min(1).max(16)).max(16),
		target: Z.nullable(),
		aims: t.record(Z, t.int().min(0).max(15)).optional()
	}),
	t.object({
		type: t.literal("resolve"),
		dice: t.array(Z).min(1).max(40),
		target: Z.optional(),
		mode: t.enum([
			"use",
			"bones",
			"active",
			"locked",
			"discard",
			"increase",
			"decrease",
			"reroll"
		]).default("use"),
		pos: t.int().min(0).max(15).optional(),
		amount: t.int().min(0).max(30).optional(),
		components: t.tuple([
			t.int().min(0).max(3),
			t.int().min(0).max(3),
			t.int().min(0).max(3)
		]).optional()
	}),
	t.object({
		type: t.literal("backup"),
		cost: t.int().min(1).max(6),
		target: Z.optional(),
		pos: t.int().min(0).max(15).optional(),
		ids: t.array(Z).max(40).optional(),
		skill: t.int().min(1).max(16).optional()
	}),
	t.object({
		type: t.literal("ability"),
		ability: t.enum([
			"craft",
			"axe",
			"bodyCount",
			"rage",
			"release",
			"activate",
			"effect",
			"startEffect",
			"reaction",
			"target",
			"initiative",
			"allyMove",
			"allyAttack",
			"allyEnd"
		]),
		target: Z.optional(),
		slot: Z.optional(),
		amount: t.int().min(-30).max(40).optional(),
		pos: t.int().min(0).max(15).optional(),
		mode: Z.optional()
	}),
	t.object({ type: t.literal("endTurn") }),
	t.object({
		type: t.literal("recover"),
		option: t.enum([
			"rest",
			"search",
			"scout"
		]),
		loot: Z.optional(),
		stack: t.enum([
			"1",
			"5",
			"20"
		]).optional()
	}),
	t.object({
		type: t.literal("loot"),
		loot: Z,
		target: Z.optional(),
		mode: t.enum([
			"use",
			"discard",
			"give",
			"backup",
			"acquire"
		]).default("use"),
		amount: t.int().min(0).max(30).optional(),
		skill: t.int().min(1).max(16).optional(),
		ids: t.array(Z).max(40).optional(),
		pos: t.int().min(0).max(15).optional()
	}),
	t.object({
		type: t.literal("lockStart"),
		loot: Z,
		owner: Z
	}),
	t.object({
		type: t.literal("lock"),
		mode: t.enum([
			"roll",
			"reroll",
			"convert",
			"save",
			"solve",
			"stop"
		]),
		dice: t.array(t.int().min(0).max(2)).max(3).optional(),
		die: t.int().min(0).max(2).optional(),
		lockType: t.enum([
			"L",
			"T",
			"F"
		]).optional()
	}),
	t.object({
		type: t.literal("flick"),
		lane: t.int().min(0).max(3),
		x: t.number().finite().min(0).max(1e3),
		vx: t.number().finite().min(-2500).max(2500),
		vy: t.number().finite().min(-4e3).max(-50)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number().finite()
	})
]), kn = t.object({
	round: t.int(),
	order: t.array(Z),
	at: t.int(),
	stage: t.enum([
		"deployment",
		"startRound",
		"startTurn",
		"move",
		"resolve",
		"enemyTarget",
		"enemyMove",
		"enemySkills",
		"enemyRoll",
		"enemyDamage",
		"enemyBackup",
		"enemyTyrant",
		"reactions",
		"endRound"
	]),
	turn: Z.nullable(),
	target: Z.nullable(),
	rolled: t.array(Dn),
	spent: t.int(),
	rolledOnce: t.boolean(),
	backupUsed: t.boolean(),
	queue: t.array(Z),
	modifiers: Cn,
	flags: t.array(Z),
	enemyTargets: t.array(Z),
	enemyRolls: t.array(t.object({
		target: Z,
		dice: t.array(t.number())
	})),
	enemyBones: t.int(),
	tyrantFace: t.int(),
	startEffects: t.array(Z),
	reactions: t.array(Z),
	pendingDamage: Cn,
	defeated: t.array(Z),
	later: t.array(Z),
	lastAttack: t.array(Z),
	hpLost: Cn
}), An = t.object({
	by: Z,
	owner: Z,
	loot: Z,
	values: t.array(t.int()),
	types: t.array(t.enum([
		"L",
		"T",
		"F"
	])),
	at: t.int(),
	startedAt: t.int(),
	available: t.array(t.int()),
	rolled: t.array(Z),
	intuition: t.enum([
		"none",
		"convert",
		"reroll",
		"save"
	]),
	saved: t.int().nullable(),
	retry: t.boolean(),
	usedIntuition: t.boolean(),
	returnTo: Z
}), jn = t.object({
	kind: t.enum([
		"none",
		"darts",
		"flick",
		"rats",
		"barrels",
		"lanterns",
		"critters",
		"rubble",
		"lootGamble",
		"lock",
		"scout",
		"lootChoice",
		"decision"
	]),
	by: Z,
	step: t.int(),
	values: t.array(t.number()),
	ids: t.array(Z),
	wins: t.array(Z),
	dice: t.array(t.number()),
	data: Cn
}), Mn = t.object({
	phase: t.enum([
		"recruit",
		"training",
		"day",
		"encounter",
		"challenge",
		"battle",
		"recovery",
		"done"
	]),
	config: Sn,
	players: t.array(Z),
	leader: Z,
	actors: t.array(En),
	day: t.int(),
	progress: t.int(),
	encounter: Z.nullable(),
	choice: t.int().nullable(),
	persistent: Cn,
	battle: kn.nullable(),
	lock: An.nullable(),
	challenge: jn,
	log: t.array(t.object({
		key: Z,
		who: Z,
		target: Z,
		n: t.number(),
		values: t.array(t.number())
	})),
	outcome: t.enum(["win", "lose"]).nullable(),
	scouted: t.record(Z, t.array(Z)),
	drawCounts: Cn
}), Nn = t.object({ canAct: t.boolean() }), Pn = {
	id: "toomanybones",
	tier: "alpha",
	nameKey: "games.toomanybones.name",
	descKey: "games.toomanybones.desc",
	rulesKey: "games.toomanybones.rules",
	icon: "🎲",
	iconImg: "games/toomanybones.webp",
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2],
	accent: "#986536",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/toomanybones/en.pdf" },
	mechanics: [
		"dice-rolling",
		"grid-movement",
		"action-points"
	],
	interactionTags: ["cooperative"],
	releasedAt: "2026-10-18T00:00:00+08:00",
	search: {
		py: "ku gu wei cheng",
		init: "kgwc"
	},
	hotseat: "open"
};
function Fn(e) {
	if (e.lock) return !1;
	if (e.phase === "recovery" && e.persistent["today:skipRecovery"]) return !0;
	let t = e.challenge, n = e.battle;
	if (e.phase === "challenge") return t.kind === "lock" || t.kind === "darts" && !!t.data.enemyTurn || t.kind === "critters" && !!t.data.enemyTurn || t.kind === "decision" && t.ids[0] === "troveImmediate" && t.step >= e.players.length;
	if (e.phase !== "battle" || !n || n.reactions.length) return !1;
	if (n.stage === "deployment") return I(e).every((e) => e.pos >= 0 || e.hp <= 0 || e.counters.reserve > 0);
	if (n.flags.includes("orderPending")) return !1;
	if ([
		"startRound",
		"startTurn",
		"enemySkills",
		"enemyRoll",
		"enemyDamage",
		"enemyBackup",
		"endRound"
	].includes(n.stage)) return !0;
	let r = F(e, n.turn ?? "");
	if (!r) return !1;
	if (r.kind === "gearloc" && (r.hp <= 0 || r.pos < 0) && n.stage === "resolve") return !0;
	if (n.stage === "move") return !n.startEffects.length && (r.kind !== "gearloc" && r.kind !== "ally" || r.hp <= 0 || r.pos < 0 || !!r.effects.stun || !!r.effects.stunRounds);
	if (n.stage === "enemyTarget") return jt(e, r).filter((e) => !n.enemyTargets.includes(e.id)).length <= 1;
	if (n.stage === "enemyMove") {
		let t = F(e, n.target ?? "");
		return !t || n.spent >= 2 || Mt(e, r, t).length <= 1;
	}
	return n.stage === "enemyTyrant";
}
function In(e, t) {
	if (!e.players.includes(t) || e.phase === "done") return !1;
	if (e.lock) return e.lock.by === t;
	if (e.phase === "recruit") return !ye(e, t);
	if (e.phase === "training" || e.phase === "recovery") return !ye(e, t)?.ready;
	if (e.phase === "day" || e.phase === "encounter") return t === e.leader;
	if (e.phase === "challenge") return e.challenge.by === t || e.challenge.data.deploy === 1;
	let n = e.battle;
	if (!n) return !1;
	if (n.reactions.length) {
		let r = n.reactions[0], i = r.includes(":") ? F(e, r.slice(r.indexOf(":") + 1).split("|")[0]) : void 0;
		return i?.kind === "gearloc" ? i.owner === t : t === e.leader;
	}
	if (n.stage === "deployment") {
		let n = ye(e, t);
		return !!n && n.hp > 0 && n.pos < 0 && !(n.counters.reserve > 0);
	}
	let r = F(e, n.turn ?? "");
	return n.flags.includes("orderPending") || r?.kind !== "gearloc" ? t === e.leader : r.owner === t;
}
function Ln(e, t, n, r) {
	let i = e.battle, a = F(e, r.target ?? i.target ?? "");
	if (r.ability === "allyMove" || r.ability === "allyAttack" || r.ability === "allyEnd") {
		let n = F(e, i.turn ?? "");
		return !n || n.kind !== "ally" || t !== n.owner || i.stage !== "move" || i.startEffects.length || i.reactions.length ? !1 : r.ability === "allyEnd" ? (Ft(e), !0) : r.ability === "allyMove" ? i.spent >= 2 || r.pos === void 0 || !kt(e, n).includes(r.pos) ? !1 : (n.pos = r.pos, i.spent++, !0) : !a || !yt(e, n, a) ? !1 : (i.target = a.id, i.enemyTargets = [a.id], i.stage = "enemySkills", !0);
	}
	if (r.ability === "target" && i.turn === n.id && i.stage === "resolve" && Se(n, "v14") && !i.lastAttack.length && a && yt(e, n, a)) return i.target = a.id, !0;
	if (r.ability === "initiative") {
		if (t !== e.leader || !i.flags.includes("orderPending") || !a || r.amount === void 0) return !1;
		let n = i.order.indexOf(a.id), o = r.amount;
		return n < 0 || o < 0 || o >= i.order.length || !i.order.slice(Math.min(n, o), Math.max(n, o) + 1).every((t) => F(e, t)?.initiative === a.initiative) || a.kind !== "gearloc" && i.order.slice(Math.min(n, o), Math.max(n, o) + 1).some((t) => t !== a.id && F(e, t)?.kind !== "gearloc") ? !1 : (i.order.splice(n, 1), i.order.splice(o, 0, a.id), !0);
	}
	if (r.ability === "startEffect") {
		let n = F(e, i.turn ?? "");
		return !!n && !!r.mode && (n.owner === t || n.kind !== "gearloc" && t === e.leader) && Pt(e, n, r.mode, a, r.pos);
	}
	if (r.ability === "target" && i.stage === "enemyTarget") {
		let n = F(e, i.turn ?? "");
		return t !== e.leader || !n || !a || i.enemyTargets.includes(a.id) || !jt(e, n).includes(a) ? !1 : (i.enemyTargets.push(a.id), i.flags.includes("movementComplete") ? i.enemyTargets.length >= n.targets && (i.stage = "enemySkills") : (i.target = i.enemyTargets[0], i.stage = "enemyMove"), !0);
	}
	if (r.ability === "reaction") {
		let n = i.reactions[0];
		if (!n) return !1;
		if (n.startsWith("mischief:")) {
			let a = F(e, n.slice(9)), o = a.active.find((e) => e.uid === r.slot);
			if (t !== (a.kind === "gearloc" ? a.owner : e.leader)) return !1;
			if (a.kind === "gearloc") {
				if (!a.active.length) return i.reactions.shift(), !0;
				if (!o) return !1;
				U(e, a, o);
			} else {
				let e = r.amount ?? 0;
				if (e < 0 || e >= a.enemyDefense.length) return !1;
				a.enemyDefense.splice(e, 1);
			}
			return i.pendingDamage[a.id]--, (i.pendingDamage[a.id] <= 0 || !(a.kind === "gearloc" ? a.active.length : a.enemyDefense.length)) && i.reactions.shift(), !0;
		}
		return Ut(e, t, r);
	}
	if (i.turn !== n.id || !["move", "resolve"].includes(i.stage) || i.startEffects.length) return !1;
	if (r.ability === "craft") return it(e, n);
	if (r.ability === "rage") return !!r.mode && ot(e, n, r.mode, a);
	if (r.ability === "axe") return n.gearloc !== "tantrum" || n.counters.axes <= 0 || n.counters.axeUsed || !a || a.kind !== "baddie" || J(n.pos, a.pos) ? !1 : (n.counters.axes--, n.counters.axeUsed = 1, X(e, a, 2, n), !0);
	if (r.ability === "bodyCount") return n.gearloc !== "tantrum" || n.counters.bodyCount <= 0 ? !1 : (n.hp = Math.min(n.maxHp, n.hp + n.counters.bodyCount), n.counters.bodyCount = 0, !0);
	if (r.ability === "release") {
		let t = r.target ? F(e, r.target) : n, i = t && [...t.active, ...t.locked].find((e) => e.uid === r.slot && e.owner === n.id);
		return !t || !i ? !1 : (U(e, t, i), !0);
	}
	if (r.ability === "activate") {
		let t = [...n.active, ...n.locked].find((e) => e.uid === r.slot);
		if (!t) return !1;
		if (t.kind === "constantMove") return n.counters.freeMoveUsed >= t.n || r.pos === void 0 || !kt(e, n).includes(r.pos) ? !1 : (n.pos = r.pos, n.counters.freeMoveUsed = (n.counters.freeMoveUsed ?? 0) + 1, !0);
		if (t.kind === "switch" || t.kind === "rush") {
			let i = r.mode === "double" ? n.active.find((e) => e !== t && e.kind === t.kind) : void 0;
			if (!et(e, n, t.kind, r.target, r.pos, i ? 2 : 1)) return !1;
			i && U(e, n, i);
		} else if (t.kind === "healMultiply" || t.kind === "healReroll" || t.kind === "buffReroll") {
			if (!tt(e, n, t.kind, t.n, r.target)) return !1;
			if (t.kind !== "healMultiply" && (t.n--, t.n > 0)) return !0;
		} else return !1;
		return U(e, n, t), !0;
	}
	return !1;
}
function Rn(e, t, n) {
	if (t.type === "tick") {
		if (n !== "$engine" || !Fn(e)) return !1;
		if (e.phase === "recovery") return qt(e), !0;
		if (e.phase === "challenge") return yn(e);
		if (e.phase === "battle" && e.battle?.stage === "deployment") {
			if (e.battle.flags.some((e) => e.startsWith("resume:"))) {
				let t = e.battle, n = t.flags.find((e) => e.startsWith("resume:"));
				for (let e of t.later) t.order.includes(e) || t.order.splice(t.at + 1, 0, e);
				t.later = [], t.stage = n.slice(7), t.flags = t.flags.filter((e) => e !== n);
			} else if (e.battle.flags.includes("deployAtRoundEnd")) {
				let t = [...new Set(e.battle.later)];
				e.battle.order = [...t, ...e.battle.order.filter((e) => !t.includes(e))], e.battle.later = [], e.battle.round++, e.battle.stage = "startRound", e.battle.flags = e.battle.flags.filter((e) => e !== "deployAtRoundEnd" && e !== "roundEndResponses");
			} else Et(e);
			return !0;
		}
		return Lt(e);
	}
	if (!e.players.includes(n) || e.phase === "done") return !1;
	let r = ye(e, n);
	if (e.lock) return t.type === "lock" ? Ke(e, n, t) : t.type === "loot" && r ? lt(e, r, t) : !1;
	if (t.type === "chooseGearloc") return e.phase !== "recruit" || r || I(e).some((e) => e.gearloc === t.gearloc) ? !1 : (e.actors.push(Ee(e, n, t.gearloc)), I(e).length === e.players.length && Ie(e), !0);
	if (!r) return !1;
	if (t.type === "loot") return lt(e, r, t);
	if (t.type === "ability" && t.ability === "release" && ["training", "recovery"].includes(e.phase)) {
		let n = F(e, t.target ?? r.id), i = n && [...n.active, ...n.locked].find((e) => e.uid === t.slot && e.owner === r.id);
		return !n || !i ? !1 : (U(e, n, i), !0);
	}
	if (t.type === "train") return qe(e, r, t);
	if (t.type === "lockStart") return e.phase === "recovery" && Ue(e, n, t.owner, t.loot);
	if (t.type === "choose") {
		if (e.phase === "day" && n === e.leader) return I(e).some((e) => Fe(e) > 4) ? !1 : t.option === 0 ? (Kt(e), !0) : t.option === 1 && e.progress >= te[e.config.tyrant].progress && (Ct(e, {
			tyrant: !0,
			points: e.players.length === 1 ? 0 : e.day * e.players.length
		}), !0);
		if (e.challenge.kind === "scout") return dt(e, n, t.option);
		if (e.challenge.kind === "lootChoice") {
			if (e.challenge.by !== n || !e.challenge.ids.includes(t.target ?? "")) return !1;
			for (let n of e.challenge.ids) {
				let i = r.inventory.find((e) => e.uid === n);
				i && n !== t.target && Pe(e, r, i);
			}
			return e.challenge = N(), !0;
		}
		return e.phase === "encounter" ? Zt(e, n, t) : e.phase === "challenge" && gn(e, n, t);
	}
	if (t.type === "flick") return mn(e, n, t);
	if (t.type === "ready") return e.phase === "training" ? r.training || Fe(r) > 4 ? !1 : (r.ready = !0, I(e).every((e) => e.ready) && (e.phase = e.trainingReturn, I(e).forEach((e) => {
		e.ready = !1;
	})), !0) : e.phase === "recovery" ? !r.recovery.length || Fe(r) > 4 || e.challenge.kind !== "none" ? !1 : (r.ready = !0, I(e).every((e) => e.ready) && qt(e), !0) : e.phase === "battle" && n === e.leader && e.battle?.flags.includes("orderPending") ? (e.battle.flags = e.battle.flags.filter((e) => e !== "orderPending"), !0) : !1;
	if (t.type === "recover") {
		if (e.phase !== "recovery" || r.ready || r.recovery.length && !e.persistent["today:fullRecovery"] || r.recovery.includes(t.option) || e.challenge.kind !== "none") return !1;
		if (t.option === "rest") e.persistent.noHealing !== e.day && (r.hp = r.maxHp);
		else if (t.option === "search") {
			let i = r.inventory.find((e) => e.uid === t.loot);
			if (!i) return !1;
			Pe(e, r, i);
			let a = Ve(e, 6), o = a.filter((e) => e === 0).length, s = Ne(e, r, o);
			s.length > 1 && (e.challenge = {
				...N(),
				kind: "lootChoice",
				by: n,
				ids: s.map((e) => e.uid)
			}), B(e, "search", r.id, "", o, a);
		} else {
			let r = [
				1,
				1,
				1,
				5,
				5,
				20
			][P(e)];
			if (!ut(e, n, r, Number(t.stack ?? r))) return !1;
		}
		return r.recovery.push(t.option), !0;
	}
	if (e.phase === "challenge" && t.type === "deploy") return _n(e, n, t.pos);
	if (e.phase === "challenge" && t.type === "move") return vn(e, n, t.pos);
	if (e.phase !== "battle" || !e.battle) return !1;
	let i = e.battle;
	if (t.type === "ability") {
		let i = Ln(e, n, r, t);
		return i && Dt(e), i;
	}
	if (t.type === "deploy") return i.stage !== "deployment" || r.hp <= 0 || r.pos >= 0 || r.counters.reserve > 0 || !Tt(e, r).includes(t.pos) ? !1 : (r.pos = t.pos, i.modifiers.singleLane && !gt(e, 12) && I(e).some((e) => e.hp > 0 && e.counters.reserve === 98) && i.reactions.push("lineupNext"), !0);
	if (t.type === "move" && i.stage === "enemyMove" && n === e.leader) {
		let n = F(e, i.turn ?? ""), r = F(e, i.target ?? "");
		return !r || i.spent >= 2 || !Mt(e, n, r).includes(t.pos) ? !1 : (n.pos = t.pos, i.spent++, i.modifiers.spikeMoves && X(e, n, 1, void 0, "true"), !0);
	}
	if (i.turn !== r.id || r.hp <= 0 || i.startEffects.length || i.reactions.length || !["move", "resolve"].includes(i.stage)) return !1;
	if (t.type === "move") {
		if (i.stage === "resolve" && i.lastAttack.length && i.modifiers.freeAfterAttack > (r.counters.afterAttackMove ?? 0) && kt(e, r).includes(t.pos)) return r.pos = t.pos, r.counters.afterAttackMove = (r.counters.afterAttackMove ?? 0) + 1, !0;
		if (i.stage !== "move" || i.rolledOnce || i.spent + _t(e) > Ye(r) || !kt(e, r).includes(t.pos)) return !1;
		if (i.modifiers.stuck && !r.counters.moveCheck) {
			r.counters.moveCheck = 1;
			let t = P(e) + 1;
			if (B(e, "challengeRoll", r.id, "stuck", t), t <= 3) return r.effects.stuck = 1, !0;
		}
		return r.pos = t.pos, i.spent += _t(e), !0;
	}
	if (t.type === "roll") return Xe(e, r, t);
	if (t.type === "resolve") {
		let n = nt(e, r, t);
		return n && Dt(e), n;
	}
	if (t.type === "backup") {
		let n = st(e, r, t);
		return n && Dt(e), n;
	}
	return t.type === "endTurn" && It(e, r);
}
var zn = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: Pn,
	schemas: {
		action: On,
		config: Sn,
		publicView: Mn,
		privateView: Nn
	},
	setup(e, t, n) {
		return { state: He(Sn.parse(e), t, n) };
	},
	reduce(e, t, n) {
		let r = structuredClone(e);
		return Rn(r, t, n.by) ? { state: r } : { code: "games.toomanybones.errAction" };
	},
	viewFor(e, t) {
		return {
			public: structuredClone({
				phase: e.phase,
				config: e.config,
				players: e.players,
				leader: e.leader,
				actors: e.actors,
				day: e.day,
				progress: e.progress,
				encounter: e.encounter,
				choice: e.choice,
				persistent: e.persistent,
				battle: e.battle ? {
					...e.battle,
					queue: [...e.battle.queue.map((t) => Object.values(e.scouted).some((e) => e.includes(t)) ? t : "?"), ...e.delayedBaddies.map(() => "?")]
				} : null,
				lock: e.lock,
				challenge: e.challenge,
				log: e.log,
				outcome: e.outcome,
				scouted: e.scouted,
				drawCounts: {
					encounters: e.encounterDeck.length,
					loot: e.lootDeck.length,
					trove: e.troveDeck.length,
					one: e.stacks[1]?.length ?? 0,
					five: e.stacks[5]?.length ?? 0,
					twenty: e.stacks[20]?.length ?? 0
				}
			}),
			private: { canAct: In(e, t) }
		};
	},
	status(e) {
		return e.phase === "done" ? {
			phase: "done",
			winner: e.outcome === "win" ? [...e.players] : [],
			ranking: [...e.players]
		} : { phase: e.phase };
	},
	nextTickIn(e) {
		return Fn(e) ? 650 : null;
	}
}, Bn = {
	boomer: "games.toomanybones.boomer",
	patches: "games.toomanybones.patches",
	picket: "games.toomanybones.picket",
	tantrum: "games.toomanybones.tantrum"
}, Vn = {
	nom: "games.toomanybones.nom",
	gendricks: "games.toomanybones.gendricks",
	duster: "games.toomanybones.duster",
	mulmesh: "games.toomanybones.mulmesh",
	drellen: "games.toomanybones.drellen",
	marrow: "games.toomanybones.marrow",
	goblinking: "games.toomanybones.goblinking"
}, Hn = {
	recruit: "games.toomanybones.recruit",
	training: "games.toomanybones.training",
	day: "games.toomanybones.day",
	encounter: "games.toomanybones.encounter",
	challenge: "games.toomanybones.challenge",
	battle: "games.toomanybones.battle",
	recovery: "games.toomanybones.recovery",
	done: "games.toomanybones.done"
}, Un = {
	boomer: "games.toomanybones.skillsBoomer",
	patches: "games.toomanybones.skillsPatches",
	picket: "games.toomanybones.skillsPicket",
	tantrum: "games.toomanybones.skillsTantrum"
}, Wn = {
	boomer: "games.toomanybones.skillRulesBoomer",
	patches: "games.toomanybones.skillRulesPatches",
	picket: "games.toomanybones.skillRulesPicket",
	tantrum: "games.toomanybones.skillRulesTantrum"
}, Gn = (e, t, n) => e(Wn[t]).split("|")[n - 1] ?? "", Kn = "attack,defense,bones,forcedBones,reusableBones,element,casing,fuse,grenades,explosion,blast,partyBacklash,backlash,stun,napalm,cleanse,smoke,disable,parts,loot,buffHp,biggerBoom,holyAcquire,element325,holyBlast,holyExplosion,heal,healMultiply,healReroll,meleeDamage,trueDamage,revive,reviveKo,poisonTarget,poisonAny,buffAttack,buffReroll,recover,booster,permanentHp,tainted,constantRegen,constantMove,constantDefense,constantDamage,constantTaunt,improvedDefense,advancedDefense,intercept,ale,healSelf,switch,rush,riposte,anger,advance,axe,poisonArmor,lashback,hardy,dropInitiative,attackMinus,attackPlus,trainAttack,partyInspire,disorient,jump,taunt,rage,axes,bodyCount,cells,blank,poison,bleed,weaken,terrify,untargetable,flight,limit,initiative".split(","), qn = (e, t, n) => e(Un[t]).split("|")[n - 1] ?? String(n), Q = (e, t) => e("games.toomanybones.effectNames").split("|")[Kn.indexOf(t)] ?? e("games.toomanybones.effect"), Jn = (e, t) => {
	let n = ae(t);
	return n ? e(n.trove ? "games.toomanybones.troveNames" : "games.toomanybones.lootNames").split("|")[n.slot] : e("games.toomanybones.loot");
}, Yn = (e, t) => {
	let n = ae(t);
	return n ? e(n.trove ? "games.toomanybones.troveRules" : "games.toomanybones.lootRules").split("|")[n.slot] ?? "" : "";
}, Xn = "lashback,flight,thickSkin,careless,raiding,rage,poison,break,mischief,hardy,weaken,engulf,compound,inspire,terrify,dive,signal,taunt,corrosive,recover,undead,limit,shrouded,hide,frenzy,retreat,bogRuler,callOrc,boom,kaboom".split(","), Zn = (e, t) => e("games.toomanybones.baddieRules").split("|")[Xn.indexOf(t)] ?? "", Qn = "buff,damage,defeatAdventure,encounter,challengeRoll,flick,battle,defeat,effect,enemyRoll,inspire,ko,lootUsed,revive,round,tyrantDie,victory,dartsRoll,lockStart,lockSuccess,lockFail,search,backup,rage,roll,trained,trainingRoll,heal,loot,trove,encounterSuccess,encounterFailed".split(","), $n = (e, t) => e("games.toomanybones.logEvents").split("|")[Qn.indexOf(t)] ?? Q(e, t);
function er(e, t) {
	if (t.gearloc) return e(Bn[t.gearloc]);
	let n = Vn[t.definition];
	if (n) return e(n);
	let r = w.findIndex((e) => e.id === t.definition);
	return r >= 0 ? e("games.toomanybones.baddieNames").split("|")[r] : e("games.toomanybones.objectNames").split("|")[[
		"orb",
		"orbPillar",
		"throne",
		"rat",
		"cloaked",
		"trader"
	].indexOf(t.definition)] ?? e("games.toomanybones.target");
}
var tr = {
	startingLoot: "games.toomanybones.startingLoot",
	troveRedraw: "games.toomanybones.troveRedraw",
	troveImmediate: "games.toomanybones.troveImmediate",
	discardThenRedraw: "games.toomanybones.discardThenRedraw",
	bribe: "games.toomanybones.bribe",
	snipe: "games.toomanybones.snipe",
	grab: "games.toomanybones.grab",
	whirlwind: "games.toomanybones.whirlwind",
	trapHp: "games.toomanybones.trapHp",
	duel: "games.toomanybones.duel",
	scoutReturn: "games.toomanybones.scoutReturn",
	exhaustStats: "games.toomanybones.exhaustStats",
	barrelCount: "games.toomanybones.barrelCount",
	gambleLoot: "games.toomanybones.gambleLoot",
	offering: "games.toomanybones.offering",
	tripSkills: "games.toomanybones.tripSkills",
	wolfHand: "games.toomanybones.wolfHand",
	healDuster: "games.toomanybones.healDuster",
	bogIngredients: "games.toomanybones.bogIngredients",
	goblinBomb: "games.toomanybones.goblinBomb"
}, nr = {
	s1: "games.toomanybones.encounters.s1",
	s2: "games.toomanybones.encounters.s2",
	s3: "games.toomanybones.encounters.s3",
	s4: "games.toomanybones.encounters.s4",
	s5: "games.toomanybones.encounters.s5",
	s6: "games.toomanybones.encounters.s6",
	g1: "games.toomanybones.encounters.g1",
	g2: "games.toomanybones.encounters.g2",
	g3: "games.toomanybones.encounters.g3",
	g4: "games.toomanybones.encounters.g4",
	g5: "games.toomanybones.encounters.g5",
	g6: "games.toomanybones.encounters.g6",
	g7: "games.toomanybones.encounters.g7",
	g8: "games.toomanybones.encounters.g8",
	g9: "games.toomanybones.encounters.g9",
	g10: "games.toomanybones.encounters.g10",
	g11: "games.toomanybones.encounters.g11",
	g12: "games.toomanybones.encounters.g12",
	g13: "games.toomanybones.encounters.g13",
	g14: "games.toomanybones.encounters.g14",
	g15: "games.toomanybones.encounters.g15",
	g16: "games.toomanybones.encounters.g16",
	g17: "games.toomanybones.encounters.g17",
	g18: "games.toomanybones.encounters.g18",
	g19: "games.toomanybones.encounters.g19",
	g20: "games.toomanybones.encounters.g20",
	g21: "games.toomanybones.encounters.g21",
	g22: "games.toomanybones.encounters.g22",
	g23: "games.toomanybones.encounters.g23",
	g24: "games.toomanybones.encounters.g24",
	g25: "games.toomanybones.encounters.g25",
	g26: "games.toomanybones.encounters.g26",
	g27: "games.toomanybones.encounters.g27",
	g28: "games.toomanybones.encounters.g28",
	g29: "games.toomanybones.encounters.g29",
	g30: "games.toomanybones.encounters.g30",
	o1: "games.toomanybones.encounters.o1",
	o2: "games.toomanybones.encounters.o2",
	o3: "games.toomanybones.encounters.o3",
	o4: "games.toomanybones.encounters.o4",
	o5: "games.toomanybones.encounters.o5",
	o6: "games.toomanybones.encounters.o6",
	o7: "games.toomanybones.encounters.o7",
	o8: "games.toomanybones.encounters.o8",
	o9: "games.toomanybones.encounters.o9",
	o10: "games.toomanybones.encounters.o10",
	o11: "games.toomanybones.encounters.o11",
	o12: "games.toomanybones.encounters.o12",
	t1: "games.toomanybones.encounters.t1",
	t3: "games.toomanybones.encounters.t3",
	t4: "games.toomanybones.encounters.t4",
	t6: "games.toomanybones.encounters.t6",
	t7: "games.toomanybones.encounters.t7",
	t8: "games.toomanybones.encounters.t8",
	t10: "games.toomanybones.encounters.t10",
	t12: "games.toomanybones.encounters.t12",
	t14: "games.toomanybones.encounters.t14",
	t15: "games.toomanybones.encounters.t15",
	t17: "games.toomanybones.encounters.t17",
	t18: "games.toomanybones.encounters.t18"
};
//#endregion
//#region src/games/toomanybones/inspect.tsx
function rr({ gearloc: e, ids: t }) {
	let n = c();
	return /* @__PURE__ */ f(d, { children: t.map((t) => {
		let r = oe[e][t - 1];
		return /* @__PURE__ */ p("details", {
			className: "tmb-reference",
			children: [
				/* @__PURE__ */ p("summary", { children: [
					t,
					". ",
					qn(n, e, t)
				] }),
				/* @__PURE__ */ f("p", { children: Gn(n, e, t) }),
				!r.counter && /* @__PURE__ */ f("ol", { children: r.faces.map((e, t) => /* @__PURE__ */ p("li", { children: [
					t + 1,
					". ",
					me(e).map((e) => Q(n, e.kind) + " " + e.n + (e.extra ? " × " + e.extra : "")).join(" / ")
				] }, t)) })
			]
		}, t);
	}) });
}
function ir({ actor: e }) {
	let t = c(), n = e.gearloc ? void 0 : T(e.definition);
	return /* @__PURE__ */ p("details", {
		className: "tmb-reference",
		children: [
			/* @__PURE__ */ p("summary", { children: [
				er(t, e),
				" · ",
				e.hp,
				"/",
				e.maxHp,
				" ♥"
			] }),
			/* @__PURE__ */ p("p", { children: [
				t("games.toomanybones.attack"),
				" ",
				e.attack,
				" · ",
				t("games.toomanybones.defense"),
				" ",
				e.defense,
				" · ",
				t("games.toomanybones.initiative"),
				" ",
				e.initiative
			] }),
			n && /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ p("p", { children: [
					t(n.target === "strongest" ? "games.toomanybones.strongest" : "games.toomanybones.weakest"),
					" · ",
					t("games.toomanybones.targets", { n: n.targets }),
					" · ",
					t(n.ranged ? "games.toomanybones.ranged" : "games.toomanybones.melee")
				] }),
				Object.entries(n.skills).map(([e, n]) => /* @__PURE__ */ p("p", { children: [
					Zn(t, e),
					" ",
					n
				] }, e)),
				Object.entries(n.backup).map(([e, r]) => /* @__PURE__ */ p("p", { children: [
					t("games.toomanybones.backup"),
					" ",
					n.backupCost,
					" · ",
					Zn(t, e),
					" ",
					r
				] }, e))
			] }),
			e.gearloc && /* @__PURE__ */ f(rr, {
				gearloc: e.gearloc,
				ids: e.skills
			}),
			e.inventory.map((e) => /* @__PURE__ */ p("details", { children: [/* @__PURE__ */ f("summary", { children: Jn(t, e.card) }), /* @__PURE__ */ f("p", { children: Yn(t, e.card) })] }, e.uid)),
			Object.entries(e.effects).filter(([, e]) => e > 0).map(([e, n]) => /* @__PURE__ */ p("p", { children: [
				Q(t, e),
				" ",
				n
			] }, e))
		]
	});
}
function ar() {
	let e = c();
	return /* @__PURE__ */ f("section", {
		className: "flex flex-col gap-3",
		children: se.map((t) => /* @__PURE__ */ p("details", { children: [/* @__PURE__ */ f("summary", { children: e(Bn[t]) }), /* @__PURE__ */ f(rr, {
			gearloc: t,
			ids: oe[t].map((e) => e.id)
		})] }, t))
	});
}
//#endregion
//#region src/games/toomanybones/challenge-controls.tsx
function or({ s: e, a: t, send: n }) {
	let r = c(), i = e.challenge, a = i.ids[0], [s, l] = o([]), [u, m] = o(t.id), [h, g] = o(1), [_, v] = o(0), y = (e) => l((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]), b = (e = 0, t = u, r = h) => {
		n({
			type: "choose",
			option: e,
			target: t,
			amount: r,
			ids: s
		}), l([]);
	}, x = (e, t = 0, n = u, r = h) => /* @__PURE__ */ f("button", {
		type: "button",
		onClick: () => b(t, n, r),
		children: e
	}, e + t + n + r), S = (e, t, n, r = 30) => /* @__PURE__ */ p("label", { children: [e, /* @__PURE__ */ f("input", {
		type: "number",
		min: 0,
		max: r,
		value: t,
		onChange: (e) => n(Math.max(0, Math.min(r, Number(e.target.value))))
	})] }), ee = e.actors.filter((e) => e.kind === "gearloc").flatMap((e) => e.inventory.map((t) => ({
		p: e,
		l: t
	}))), C = (e = () => !0, t = !1) => /* @__PURE__ */ f("div", {
		className: "tmb-buttons",
		children: ee.filter(({ p: t, l: n }) => e(n.uid, t)).map(({ p: e, l: n }) => /* @__PURE__ */ p("button", {
			type: "button",
			className: (t ? s.includes(n.uid) : u === n.uid) ? "tmb-selected" : "",
			onClick: () => t ? y(n.uid) : m(n.uid),
			children: [
				e.gearloc && r(Bn[e.gearloc]),
				" · ",
				Jn(r, n.card)
			]
		}, n.uid))
	}), w = /* @__PURE__ */ p("label", { children: [r("games.toomanybones.target"), /* @__PURE__ */ f("select", {
		value: u,
		onChange: (e) => m(e.target.value),
		children: e.actors.filter((e) => e.kind === "gearloc").map((e) => /* @__PURE__ */ p("option", {
			value: e.id,
			children: [
				er(r, e),
				" · ",
				e.hp,
				" ♥"
			]
		}, e.id))
	})] });
	if (i.kind === "decision") {
		let n;
		switch (a) {
			case "pickEncounter":
				n = /* @__PURE__ */ f("div", {
					className: "tmb-buttons",
					children: i.ids.slice(1).map((e) => /* @__PURE__ */ f("button", {
						type: "button",
						onClick: () => b(0, e),
						children: r(nr[e])
					}, e))
				});
				break;
			case "startingLoot":
				n = /* @__PURE__ */ p(d, { children: [C((t, n) => n.id === e.actors.filter((e) => e.kind === "gearloc")[i.step]?.id && n.inventory.slice(-2).some((e) => e.uid === t)), x(r("games.toomanybones.keep"))] });
				break;
			case "troveRedraw":
				n = /* @__PURE__ */ p(d, { children: [x(r("games.toomanybones.keep"), 0), x(r("games.toomanybones.draw"), 1)] });
				break;
			case "troveImmediate":
				n = /* @__PURE__ */ p(d, { children: [
					C((t, n) => n === e.actors.filter((e) => e.kind === "gearloc")[i.step] && n.inventory.some((e) => e.uid === t && e.locks < 3)),
					x(r("games.toomanybones.lockpick"), 0),
					x(r("games.toomanybones.pass"), 1)
				] });
				break;
			case "bribe":
			case "discardThenRedraw":
			case "gambleLoot":
			case "healDuster":
				n = /* @__PURE__ */ p(d, { children: [C(() => !0, !0), x(r("games.toomanybones.confirm"))] });
				break;
			case "offering":
				n = /* @__PURE__ */ p(d, { children: [C((e, n) => n.id === t.id), x(r("games.toomanybones.confirm"))] });
				break;
			case "whirlwind":
			case "trapHp":
			case "duel":
			case "wolfHand":
				n = /* @__PURE__ */ p(d, { children: [
					w,
					i.values.length > 0 && /* @__PURE__ */ f("p", { children: i.values.join(" · ") }),
					x(r("games.toomanybones.confirm"))
				] });
				break;
			case "snipe":
			case "grab":
			case "barrelCount":
				n = /* @__PURE__ */ p(d, { children: [S(r("games.toomanybones.amount"), h, g, a === "snipe" ? t.attack : a === "grab" ? 6 : 4), x(r("games.toomanybones.confirm"))] });
				break;
			case "exhaustStats":
				n = /* @__PURE__ */ p(d, { children: [
					S(r("games.toomanybones.attack"), h, g, 6),
					S(r("games.toomanybones.defense"), _, v, 6),
					x(r("games.toomanybones.confirm"), _)
				] });
				break;
			case "scoutReturn":
				n = /* @__PURE__ */ f(d, { children: [
					1,
					5,
					20
				].map((e) => x(r("games.toomanybones.point", { n: e }), 0, void 0, e)) });
				break;
			case "tripSkills":
				n = /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("div", {
					className: "tmb-buttons",
					children: t.skills.filter((e) => !M(t.gearloc, e).counter).map((e) => /* @__PURE__ */ f("button", {
						type: "button",
						className: s.includes(String(e)) ? "tmb-selected" : "",
						onClick: () => y(String(e)),
						children: qn(r, t.gearloc, e)
					}, e))
				}), x(r("games.toomanybones.confirm"))] });
				break;
			case "bogIngredients":
				n = /* @__PURE__ */ p(d, { children: [x(r("games.toomanybones.point", { n: 1 }) + " × 6", 0), x(r("games.toomanybones.point", { n: 5 }) + " × 3", 1)] });
				break;
			case "goblinBomb":
				n = /* @__PURE__ */ f(d, { children: [
					"L",
					"T",
					"F"
				].map((e) => x(r(e === "L" ? "games.toomanybones.lever" : e === "T" ? "games.toomanybones.trip" : "games.toomanybones.force"), 0, e)) });
				break;
			default: n = null;
		}
		return /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("h3", { children: r(tr[a] ?? "games.toomanybones.decision") }), /* @__PURE__ */ f("div", {
			className: "tmb-buttons",
			children: n
		})] });
	}
	return i.kind === "scout" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("p", { children: r("games.toomanybones.point", { n: i.values[0] }) }), /* @__PURE__ */ p("div", {
		className: "tmb-buttons",
		children: [x(r("games.toomanybones.keep"), 0), x(r("games.toomanybones.cycle"), 1)]
	})] }) : i.kind === "lootChoice" ? /* @__PURE__ */ p(d, { children: [C((e) => i.ids.includes(e)), x(r("games.toomanybones.keep"))] }) : i.kind === "flick" ? i.data.complete ? x(r("games.toomanybones.confirm")) : /* @__PURE__ */ f("p", { children: r("games.toomanybones.shots", { n: i.step }) }) : i.kind === "darts" ? /* @__PURE__ */ p(d, { children: [
		!!i.data["weaken:0"] && !i.data.setup && /* @__PURE__ */ f("div", {
			className: "tmb-buttons",
			children: cn(i, 0).map((e) => /* @__PURE__ */ p("button", {
				type: "button",
				className: s.includes(e.id) ? "tmb-selected" : "",
				onClick: () => y(e.id),
				children: [
					r(e.kind === "attack" ? "games.toomanybones.attack" : e.kind === "defense" ? "games.toomanybones.defense" : "games.toomanybones.poison"),
					" ",
					e.index + 1
				]
			}, e.id))
		}),
		/* @__PURE__ */ f("div", {
			className: "tmb-select-row",
			children: [0, 1].map((e) => /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("b", { children: r(e === 0 ? "games.toomanybones.playerSide" : "games.toomanybones.opponentSide") }), /* @__PURE__ */ p("p", { children: [
				i.values[e],
				" ♥ · ",
				r("games.toomanybones.defense"),
				" ",
				i.values[2 + e],
				" · ",
				r("games.toomanybones.poison"),
				" ",
				i.values[4 + e]
			] })] }, e))
		}),
		i.data.discard ? /* @__PURE__ */ p(d, { children: [C((e, n) => n.id === t.id), x(r("games.toomanybones.discard"))] }) : i.data.setup ? /* @__PURE__ */ p(d, { children: [
			/* @__PURE__ */ f("p", { children: r("games.toomanybones.dartsSetup") }),
			S(r("games.toomanybones.attack"), h, g, 2),
			S(r("games.toomanybones.defense"), _, v, 2),
			/* @__PURE__ */ p("p", { children: [
				r("games.toomanybones.poison"),
				" ",
				3 - h - _
			] }),
			x(r("games.toomanybones.confirm"), _)
		] }) : i.data.bones ? /* @__PURE__ */ p("div", {
			className: "tmb-buttons",
			children: [
				x(r("games.toomanybones.dartsPass"), 0),
				[0, 1].flatMap((e) => [
					"poison",
					"weaken",
					"stun"
				].map((t) => /* @__PURE__ */ f("span", { children: x(r("games.toomanybones.discard") + " · " + r(e === 0 ? "games.toomanybones.playerSide" : "games.toomanybones.opponentSide") + " " + r(t === "poison" ? "games.toomanybones.poison" : "games.toomanybones.effect"), 1, t + ":" + e) }, t + e))),
				Object.entries(i.data).filter(([e, t]) => e.startsWith("defense:") && t > 0).map(([e, t]) => /* @__PURE__ */ f("span", { children: x(r("games.toomanybones.discard") + " · " + r(e.split(":")[1] === "0" ? "games.toomanybones.playerSide" : "games.toomanybones.opponentSide") + " " + r("games.toomanybones.defense") + " " + t, 1, e) }, e)),
				i.data.bones >= 2 && x(r("games.toomanybones.dartsStun"), 3),
				i.data.bones >= 3 && x(r("games.toomanybones.dartsWin"), 4)
			]
		}) : i.data.enemyTurn ? /* @__PURE__ */ f("p", { children: r("games.toomanybones.wait") }) : x(r("games.toomanybones.dartsRoll"))
	] }) : i.kind === "barrels" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("p", { children: [i.values.join(" ♥ · "), " ♥"] }), x(r("games.toomanybones.roll"))] }) : i.kind === "lanterns" ? /* @__PURE__ */ f("div", {
		className: "tmb-buttons",
		children: i.values.map((e, t) => e > 0 && x(r("games.toomanybones.target") + " " + (t + 1) + " · " + e, t))
	}) : i.kind === "critters" && i.data.critterSelect ? /* @__PURE__ */ p(d, { children: [
		/* @__PURE__ */ p("p", { children: [
			r("games.toomanybones.die"),
			" ",
			i.dice.join(" · ")
		] }),
		/* @__PURE__ */ f("div", {
			className: "tmb-choice-board",
			children: i.values.map((e, t) => /* @__PURE__ */ p("button", {
				type: "button",
				className: h === t ? "tmb-selected" : "",
				disabled: !e,
				onClick: () => g(t),
				children: [
					t % 4 + 1,
					"·",
					Math.floor(t / 4) + 1,
					" · ",
					e,
					" ♥"
				]
			}, t))
		}),
		/* @__PURE__ */ p("div", {
			className: "tmb-buttons",
			children: [i.values.map((e, t) => e > 0 && J(t, h) && /* @__PURE__ */ p("button", {
				type: "button",
				onClick: () => b(h, String(t)),
				children: [
					r("games.toomanybones.move"),
					" ",
					t % 4 + 1,
					"·",
					Math.floor(t / 4) + 1
				]
			}, t)), x(r("games.toomanybones.confirm"), h)]
		})
	] }) : i.kind === "critters" || i.kind === "rubble" ? /* @__PURE__ */ p(d, { children: [
		S(r("games.toomanybones.attack"), h, g, t.attack),
		/* @__PURE__ */ f("div", {
			className: "tmb-choice-board",
			children: Array.from({ length: 16 }, (e, t) => /* @__PURE__ */ p("button", {
				type: "button",
				onClick: () => i.data.deploy ? n({
					type: "deploy",
					pos: t
				}) : b(t),
				children: [
					t % 4 + 1,
					"·",
					Math.floor(t / 4) + 1,
					/* @__PURE__ */ f("br", {}),
					i.values[t] ? i.values[t] + " ♥" : "·"
				]
			}, t))
		}),
		i.kind === "critters" && !i.data.deploy && x(r("games.toomanybones.endTurn"), 0, "pass")
	] }) : null;
}
//#endregion
//#region src/games/toomanybones/battle-view.tsx
var sr = (e) => e === "attack" ? "⚔" : e === "defense" ? "⛨" : [
	"bones",
	"forcedBones",
	"reusableBones"
].includes(e) ? "⚅" : "◆";
function cr(e, t, n, r) {
	let i = (e) => er(r, e).split(" · ")[0], a = e.actors.find((e) => e.owner === n && e.kind === "gearloc"), o = t?.actors.find((e) => e.id === a?.id);
	if (a && o) {
		let e = a.bones.reduce((e, t) => e + t.n, 0) - o.bones.reduce((e, t) => e + t.n, 0);
		if (e) return r("games.toomanybones.bones") + " " + (e > 0 ? "+" : "−") + Math.abs(e);
		let t = [...a.active, ...a.locked].filter((e) => ![...o.active, ...o.locked].some((t) => t.uid === e.uid));
		if (t.length) return t.map((e) => Q(r, e.kind) + (e.n ? " +" + e.n : "")).join(" · ");
		let n = z(a, "defense") + z(a, "advancedDefense") - z(o, "defense") - z(o, "advancedDefense");
		if (n) return r("games.toomanybones.defense") + " " + (n > 0 ? "+" : "−") + Math.abs(n);
		if (a.pos >= 0 && o.pos >= 0 && a.pos !== o.pos) return r("games.toomanybones.moveTo", {
			x: a.pos % 4 + 1,
			y: Math.floor(a.pos / 4) + 1
		});
	}
	let s = e.log.at(-1), c = t?.log.at(-1);
	if (!s || t && JSON.stringify(s) === JSON.stringify(c)) return "";
	let l = e.actors.find((e) => e.id === s.who), u = e.actors.find((e) => e.id === s.target);
	return u && ["damage", "heal"].includes(s.key) ? i(u) + " · " + r("games.toomanybones.hp") + (s.key === "damage" ? " −" : " +") + s.n : r("games.toomanybones.logLine", {
		who: l ? i(l) : "",
		event: $n(r, s.key),
		target: u ? i(u) : "",
		n: s.n || ""
	});
}
function lr({ s: e, myRid: t, canAct: n, send: r, tools: i }) {
	let a = e.battle;
	return /* @__PURE__ */ f(ur, {
		s: e,
		b: a,
		myRid: t,
		canAct: n,
		send: r,
		tools: i
	}, t + ":" + a.round + ":" + a.at + ":" + a.turn);
}
function ur({ s: e, b: t, myRid: n, canAct: i, send: s, tools: u }) {
	let m = c(), h = e.actors.find((e) => e.kind === "gearloc" && e.owner === n), y = e.actors.find((e) => e.id === t.turn), b = y?.id === h?.id && !!h, x = (e) => er(m, e).split(" · ")[0], [S, ee] = o(""), [C, w] = o(-1), [T, E] = o([]), [D, ne] = o(""), [O, k] = o(null), [A, re] = o(!1), ie = a(null);
	r(() => {
		if (!O) return;
		let e = document.activeElement;
		return ie.current?.querySelector("button,select,input")?.focus(), () => {
			e instanceof HTMLElement && e.isConnected && e.focus();
		};
	}, [O]);
	let [ae, j] = o({}), [se, ce] = o(null), [le, ue] = o(() => ({
		view: e,
		feedback: cr(e, void 0, n, m)
	}));
	le.view !== e && ue({
		view: e,
		feedback: cr(e, le.view, n, m) || le.feedback
	});
	let de = t.flags.includes("orderPending"), fe = !!t.reactions.length || !!t.startEffects.length || de, pe = i && b && t.stage === "move" && !t.rolledOnce && !fe, M = i && b && t.stage === "resolve" && !fe, he = h ? e.actors.filter((t) => yt(e, h, t)) : [], N = e.actors.find((e) => e.id === t.target), ge = t.rolledOnce ? N : he.find((e) => e.id === S) ?? he[0], P = [
		"troll",
		"orc",
		"scales",
		"goblin",
		"bog",
		"beast"
	].indexOf(ge ? xe(ge)?.creature ?? "" : "") + 1, _e = h && Se(h, "v7") && P === h.counters.necklaceType ? h.counters.necklace ?? 0 : 0, ve = (h?.effects.extraAttack ?? 0) + _e, F = h && Se(h, "l15") ? 1 : 0, ye = t.modifiers.defenseOnly >= t.round || t.modifiers.meleeDefenseOnly >= t.round && !h?.ranged, I = t.modifiers.skillOnly >= t.round, L = h ? [
		...Array.from({ length: !ye && !I ? Math.min(30, Je(h, "attack") + _e) : 0 }, (e, t) => ({
			id: "attack:" + t,
			kind: "attack",
			skill: 0
		})),
		...Array.from({ length: !t.modifiers.noDefense && !I ? Math.min(30, Je(h, "defense") + F) : 0 }, (e, t) => ({
			id: "defense:" + t,
			kind: "defense",
			skill: 0
		})),
		...ye ? [] : h.skills.filter((t) => we(e, h, t, !0)).map((e) => ({
			id: "skill:" + e,
			kind: "skill",
			skill: e
		}))
	] : [], R = L.filter((e) => T.includes(e.id)), be = R.filter((e) => e.kind === "attack").length, Ce = R.filter((e) => e.kind === "defense").length, B = R.filter((e) => e.kind === "skill").map((e) => e.skill), Te = (e) => Math.max(0, e.filter((e) => e.kind === "attack").length - ve) + Math.max(0, e.filter((e) => e.kind === "defense").length - F) + e.filter((e) => e.kind === "skill").length, Ee = h ? Math.max(0, Ye(h) - t.spent) : 0, De = B.filter((e) => h?.gearloc && oe[h.gearloc][e - 1].grenade), Oe = t.rolled.filter((e) => !e.used), V = Oe.find((e) => e.uid === D) ?? Oe[0], H = V && me(V.face)[0], U = !!H && [
		"heal",
		"buffHp",
		"buffAttack",
		"recover",
		"booster",
		"permanentHp",
		"advancedDefense",
		"intercept"
	].includes(H.kind), ke = !!H && ([
		"trueDamage",
		"poisonAny",
		"attackMinus"
	].includes(H.kind) || ["stun", "disable"].includes(H.kind) && h?.gearloc !== "boomer"), Ae = M && (U || ke), je = !Ae || !h || !H ? [] : e.actors.filter((e) => e.hp <= 0 || e.pos < 0 ? !1 : U ? e.kind === "gearloc" && (H.kind !== "intercept" || e.id !== h.id) : e.kind === "baddie" ? ["stun", "disable"].includes(H.kind) ? e.point > 0 && e.point <= H.n && (h.gearloc !== "tantrum" || J(e.pos, h.pos)) : H.kind !== "attackMinus" || J(e.pos, h.pos) : !1), W = je.find((e) => e.id === S) ?? je.find((e) => e.id === h?.id) ?? je[0], G = Ae ? W : ge, Me = i && !fe && t.stage === "deployment" && h && h.pos < 0 && h.hp > 0 && !h.counters.reserve, Ne = i && !fe && t.stage === "move" && y?.kind === "ally", Pe = M && t.lastAttack.length > 0 && t.modifiers.freeAfterAttack > (h?.counters.afterAttackMove ?? 0), Fe = i && !fe && t.stage === "enemyMove" && y, Ie = i && !fe && t.stage === "enemyTarget" && y, K = se === null ? Me ? Tt(e, h) : (pe && Ee >= _t(e) || Pe) && h ? kt(e, h) : Ne && t.spent < 2 ? kt(e, y) : Fe && N ? Mt(e, y, N) : [] : Array.from({ length: 16 }, (e, t) => t), Le = Ie ? jt(e, y) : Ae ? je : pe || Ne ? e.actors.filter((t) => y && yt(e, y, t)) : [], Re = C >= 0 && K.includes(C) && se === null, ze = (e) => {
		re(!1), se === null ? w(e === C ? -1 : e) : (j((t) => ({
			...t,
			[se]: e
		})), ce(null), w(-1));
	}, Be = (e) => {
		w(-1), re(!1), E((t) => t.includes(e.id) ? t.filter((t) => t !== e.id) : [...t, e.id]), e.skill && h?.gearloc && oe[h.gearloc][e.skill - 1].grenade && !T.includes(e.id) ? ce(e.skill) : se === e.skill && ce(null);
	}, q = (e) => {
		s(e), w(-1), re(!1);
	}, Ve = Oe.some((e) => e.face.includes("forcedBones") || e.face.includes("tainted") || h?.gearloc === "boomer" && (e.skill === 16 || e.skill >= 5 && e.skill <= 11)), He = m("games.toomanybones.wait"), Ue = "", We, Ge = !i, Ke;
	if (i && fe) {
		He = m(t.reactions.length ? "games.toomanybones.reaction" : de ? "games.toomanybones.orderReady" : "games.toomanybones.startEffect");
		let e = t.startEffects[0];
		de && !t.reactions.length ? We = { type: "ready" } : !t.reactions.length && t.startEffects.length === 1 && y && e !== "dive" && !(e === "innateHeal" && y.upgraded) ? (Ue = Q(m, y.active.find((t) => t.uid === e)?.kind ?? (e === "innateHeal" ? "heal" : e)), We = {
			type: "ability",
			ability: "startEffect",
			mode: e,
			target: y.id
		}) : Ke = "special";
	} else if (Me) He = m("games.toomanybones.deploy"), Ue = m("games.toomanybones.chooseDeployment"), Ge = !Re, We = Re ? {
		type: "deploy",
		pos: C
	} : void 0;
	else if (Ie) He = m("games.toomanybones.enemyTarget"), Ue = m("games.toomanybones.chooseBoardTarget"), Ge = !Le.some((e) => e.id === S), We = {
		type: "ability",
		ability: "target",
		target: S
	};
	else if (Re) He = m("games.toomanybones.moveTo", {
		x: C % 4 + 1,
		y: Math.floor(C / 4) + 1
	}), Ue = Ne || Fe ? "" : Pe ? m("games.toomanybones.free") : m("games.toomanybones.moveCost", { n: _t(e) }), We = Ne ? {
		type: "ability",
		ability: "allyMove",
		pos: C
	} : {
		type: "move",
		pos: C
	};
	else if (Fe) He = m("games.toomanybones.enemyMove"), Ue = m("games.toomanybones.chooseMove"), Ge = !0;
	else if (Ne) {
		let e = Le.find((e) => e.id === S);
		He = e ? m("games.toomanybones.attackTarget", { name: x(e) }) : m("games.toomanybones.endTurn"), We = e ? {
			type: "ability",
			ability: "allyAttack",
			target: e.id
		} : {
			type: "ability",
			ability: "allyEnd"
		};
	} else if (pe) He = m("games.toomanybones.rollCount", { n: R.length }), Ue = be ? ge ? m("games.toomanybones.attackTarget", { name: x(ge) }) : m("games.toomanybones.noAttackTarget") : "", se !== null && h?.gearloc ? Ue = m("games.toomanybones.aim", { skill: qn(m, h.gearloc, se) }) : Te(R) > Ee && (Ue = m("games.toomanybones.notEnoughDex")), Ge = !R.length || Te(R) > Ee || De.length > (h?.counters.grenades ?? 0) || De.some((e) => ae[e] === void 0) || se !== null, be && !ge && h && !Se(h, "v14") && (Ge = !0), We = {
		type: "roll",
		attack: be,
		defense: Ce,
		skills: B,
		target: ge?.id ?? null,
		aims: Object.fromEntries(De.map((e) => [e, ae[e]]))
	};
	else if (M && V && H) {
		if (H.kind === "attack") {
			let n = N && h && yt(e, h, N);
			He = n ? m("games.toomanybones.attackFor", {
				name: x(N),
				n: H.n + (t.lastAttack.includes(h.id) ? 0 : z(h, "constantDamage"))
			}) : m("games.toomanybones.discard"), We = {
				type: "resolve",
				dice: [V.uid],
				mode: n ? "use" : "discard"
			};
		} else if (H.kind === "defense") He = m("games.toomanybones.storeDefense", { n: H.n }), We = {
			type: "resolve",
			dice: [V.uid],
			mode: "active"
		}, h && h.active.length >= 3 && (He = m("games.toomanybones.chooseResolution"), Ue = m("games.toomanybones.activeFull"), Ke = "dice", We = void 0);
		else if ([
			"bones",
			"forcedBones",
			"reusableBones"
		].includes(H.kind)) He = m("games.toomanybones.collectBones", { n: H.n * (t.modifiers.doubleBones ? 2 : 1) }), We = {
			type: "resolve",
			dice: [V.uid],
			mode: "bones"
		};
		else if (H.kind === "blank") He = m("games.toomanybones.discard"), We = {
			type: "resolve",
			dice: [V.uid],
			mode: "discard"
		};
		else if (He = m("games.toomanybones.useSkill", { name: h?.gearloc ? qn(m, h.gearloc, V.skill) : Q(m, H.kind) }), [
			"parts",
			"jump",
			"revive",
			"reviveKo"
		].includes(H.kind)) Ke = "dice";
		else {
			let t = [
				"healMultiply",
				"healReroll",
				"buffReroll"
			].includes(H.kind) ? "locked" : ["switch", "rush"].includes(H.kind) ? "active" : "use";
			We = {
				type: "resolve",
				dice: [V.uid],
				mode: t,
				target: W?.id
			}, [
				"meleeDamage",
				"poisonTarget",
				"dropInitiative"
			].includes(H.kind) && (!N || !h || !yt(e, h, N, H.kind === "dropInitiative" && h.ranged)) && (Ge = !0, Ue = m("games.toomanybones.noAttackTarget")), Ae && (Ge = !W, W && (Ue = m("games.toomanybones.skillTarget", { name: x(W) })));
			let n = U ? W : h, r = [
				"buffHp",
				"buffAttack",
				"recover",
				"booster",
				"advancedDefense",
				"intercept",
				"switch",
				"rush",
				"ale",
				"poisonArmor",
				"lashback",
				"hardy",
				"taunt",
				"riposte"
			].includes(H.kind), i = [
				"element",
				"casing",
				"fuse",
				"element325",
				"healMultiply",
				"healReroll",
				"buffReroll",
				"constantRegen",
				"constantMove",
				"constantDefense",
				"constantDamage",
				"constantTaunt",
				"improvedDefense"
			].includes(H.kind);
			n && (r && n.active.length >= 3 || i && n.locked.length >= 3) && (Ke = "dice", We = void 0, Ue = m("games.toomanybones.slotsFull"));
		}
		Ue ||= me(V.face).map((e) => Q(m, e.kind) + (e.n ? " " + e.n : "")).join(" · ");
	} else M ? (He = m("games.toomanybones.endTurn"), We = { type: "endTurn" }) : y && (He = m("games.toomanybones.unitTurn", { name: x(y) }), Ge = !0);
	let qe = le.feedback;
	return /* @__PURE__ */ p("div", {
		className: "tmb-root tmb-focused h-full",
		children: [/* @__PURE__ */ f(l, {
			adaptive: !0,
			scroll: !1,
			actionsHeight: "tmb-battle-actions",
			banner: /* @__PURE__ */ f("header", {
				className: "tmb-battle-header",
				children: /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("strong", { children: m("games.toomanybones.name") }), /* @__PURE__ */ f("span", { children: m("games.toomanybones.battleProgress", {
					day: e.day,
					days: te[e.config.tyrant].days,
					p: e.progress,
					total: te[e.config.tyrant].progress
				}) })] })
			}),
			actions: /* @__PURE__ */ p("div", {
				className: "tmb-battle-footer",
				children: [/* @__PURE__ */ p("button", {
					type: "button",
					className: "tmb-current-player",
					"aria-label": m("games.toomanybones.moreOptions"),
					onClick: () => k("menu"),
					children: [/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ p("strong", { children: [
						h ? x(h) : m("games.toomanybones.wait"),
						" ",
						/* @__PURE__ */ f(v, { size: 16 })
					] }), /* @__PURE__ */ f("span", { children: m(b ? "games.toomanybones.yourTurn" : "games.toomanybones.battle") })] }), h && /* @__PURE__ */ p("div", {
						className: "tmb-player-totals",
						children: [/* @__PURE__ */ p("b", { children: [
							"♥ ",
							h.hp,
							/* @__PURE__ */ p("small", { children: ["/", h.maxHp] })
						] }), /* @__PURE__ */ p("span", { children: [
							"⛨ ",
							z(h, "defense") + z(h, "advancedDefense") + z(h, "constantDefense"),
							" · ⚅ ",
							h.bones.reduce((e, t) => e + t.n, 0)
						] })]
					})]
				}), /* @__PURE__ */ p("div", {
					className: "tmb-battle-tray",
					children: [
						/* @__PURE__ */ p("div", {
							className: "tmb-tray-heading",
							children: [/* @__PURE__ */ f("h2", { children: m(Re ? "games.toomanybones.move" : pe ? "games.toomanybones.chooseDice" : M ? "games.toomanybones.resolveDice" : "games.toomanybones.battle") }), h && /* @__PURE__ */ p("span", { children: [
								m("games.toomanybones.dex"),
								" ",
								/* @__PURE__ */ f("b", { children: Ee }),
								pe && /* @__PURE__ */ p(d, { children: [" → ", /* @__PURE__ */ f("b", { children: Ee - (Re ? _t(e) : Te(R)) })] })
							] })]
						}),
						/* @__PURE__ */ f("div", {
							className: "tmb-dice-tray",
							"aria-label": m("games.toomanybones.chooseDice"),
							children: pe ? L.map((e) => /* @__PURE__ */ p("button", {
								type: "button",
								className: "tmb-die-item",
								"aria-pressed": T.includes(e.id),
								onClick: () => Be(e),
								children: [/* @__PURE__ */ p("span", {
									className: `tmb-physical-die tmb-physical-${e.kind}`,
									children: [
										/* @__PURE__ */ f("span", {
											className: "tmb-die-check",
											children: /* @__PURE__ */ f(g, { size: 14 })
										}),
										/* @__PURE__ */ f("span", {
											className: "tmb-die-mark",
											children: sr(e.kind)
										}),
										e.skill > 0 && /* @__PURE__ */ f("small", { children: e.skill })
									]
								}), /* @__PURE__ */ f("span", { children: e.skill && h?.gearloc ? qn(m, h.gearloc, e.skill) : Q(m, e.kind) })]
							}, e.id)) : b && t.rolledOnce ? t.rolled.map((e) => /* @__PURE__ */ p("button", {
								type: "button",
								disabled: e.used || !M,
								className: `tmb-die-item ${e.used ? "tmb-die-spent" : ""}`,
								"aria-pressed": V?.uid === e.uid,
								onClick: () => {
									ne(e.uid), w(-1), re(!1);
								},
								children: [/* @__PURE__ */ p("span", {
									className: `tmb-physical-die tmb-physical-${e.kind}`,
									children: [
										/* @__PURE__ */ f("span", {
											className: "tmb-die-check",
											children: /* @__PURE__ */ f(g, { size: 14 })
										}),
										/* @__PURE__ */ f("span", {
											className: "tmb-die-mark",
											children: sr(me(e.face)[0].kind)
										}),
										/* @__PURE__ */ f("small", { children: me(e.face)[0].n || "" })
									]
								}), /* @__PURE__ */ f("span", { children: e.skill && h?.gearloc ? qn(m, h.gearloc, e.skill) : Q(m, e.kind) })]
							}, e.uid)) : /* @__PURE__ */ f("span", {
								className: "tmb-tray-placeholder",
								children: Me ? m(h?.ranged ? "games.toomanybones.ranged" : "games.toomanybones.melee") : de ? m("games.toomanybones.orderReady") : ""
							})
						}),
						/* @__PURE__ */ f("div", {
							className: "tmb-action-context",
							"aria-live": "polite",
							children: Ue
						}),
						/* @__PURE__ */ f("button", {
							type: "button",
							className: "tmb-main-action",
							disabled: Ge || !We && !Ke,
							onClick: () => {
								Ke ? k(Ke) : We && q(We);
							},
							children: He
						})
					]
				})]
			}),
			children: /* @__PURE__ */ p("div", {
				className: "tmb-battle-scene",
				children: [
					/* @__PURE__ */ p("div", {
						className: "tmb-battle-goal",
						children: [/* @__PURE__ */ f("span", { children: m(t.flags.includes("tyrant") ? "games.toomanybones.defeatTyrant" : "games.toomanybones.defeatEnemies") }), /* @__PURE__ */ f("span", { children: m("games.toomanybones.round", { n: t.round }) })]
					}),
					/* @__PURE__ */ f("div", {
						className: "tmb-battle-board-wrap",
						children: /* @__PURE__ */ f("div", {
							className: "tmb-battle-board",
							"aria-label": m("games.toomanybones.battlefield"),
							children: Array.from({ length: 16 }, (n, r) => {
								let i = e.actors.find((e) => e.pos === r && e.hp > 0), a = i ? Le.some((e) => e.id === i.id) && se === null : K.includes(r), o = i ? Ie || Ne ? S === i.id : (pe || M) && G?.id === i.id : Re && C === r, s = i ? /* @__PURE__ */ p(d, { children: [
									/* @__PURE__ */ f("span", {
										className: "tmb-unit-name",
										children: x(i)
									}),
									/* @__PURE__ */ f("span", {
										className: "tmb-unit-mark",
										children: i.gearloc ? i.gearloc.slice(0, 1).toUpperCase() : i.point || "◆"
									}),
									/* @__PURE__ */ p("span", {
										className: "tmb-unit-hp",
										children: ["♥ ", i.hp]
									}),
									o && /* @__PURE__ */ f("span", {
										className: "tmb-target-tag",
										children: m("games.toomanybones.target")
									})
								] }) : /* @__PURE__ */ f("span", {
									"aria-hidden": "true",
									children: a ? C === r ? /* @__PURE__ */ f(g, { size: 20 }) : "+" : ""
								}), c = `tmb-battle-cell ${i ? "tmb-unit " + (i.kind === "gearloc" || i.kind === "ally" ? "tmb-unit-hero" : "tmb-unit-enemy") : ""} ${a ? "tmb-board-legal" : ""} ${o ? "tmb-board-selected" : ""} ${i?.id === t.turn ? "tmb-unit-turn" : ""}`;
								return /* @__PURE__ */ f("div", {
									className: "tmb-battle-socket",
									children: a || se !== null ? /* @__PURE__ */ f("button", {
										type: "button",
										className: c,
										"aria-pressed": o,
										"aria-label": i ? m("games.toomanybones.unitHp", {
											name: x(i),
											n: i.hp
										}) : m("games.toomanybones.boardPosition", {
											x: r % 4 + 1,
											y: Math.floor(r / 4) + 1
										}),
										onClick: () => {
											se !== null || !i ? ze(r) : (ee(i.id), w(-1));
										},
										children: s
									}) : /* @__PURE__ */ f("div", {
										className: c,
										children: s
									})
								}, r);
							})
						})
					}),
					/* @__PURE__ */ f("div", {
						className: "tmb-battle-feedback",
						role: "status",
						"aria-live": "polite",
						children: qe
					}),
					/* @__PURE__ */ f("div", {
						className: "tmb-battle-order",
						"aria-label": m("games.toomanybones.initiative"),
						children: t.order.map((n) => {
							let r = e.actors.find((e) => e.id === n);
							return r && /* @__PURE__ */ p("span", {
								className: t.turn === n ? "tmb-order-current" : "",
								children: [
									x(r),
									" ",
									/* @__PURE__ */ f("b", { children: r.initiative })
								]
							}, n);
						})
					})
				]
			})
		}), O && /* @__PURE__ */ f("div", {
			className: "tmb-modal",
			onClick: (e) => {
				e.target === e.currentTarget && k(null);
			},
			children: /* @__PURE__ */ p("section", {
				ref: ie,
				className: "tmb-modal-body",
				role: "dialog",
				"aria-modal": "true",
				"aria-labelledby": "tmb-battle-dialog-title",
				onKeyDown: (e) => {
					if (e.key === "Escape" && k(null), e.key !== "Tab") return;
					let t = [...e.currentTarget.querySelectorAll("button:not(:disabled),select:not(:disabled),input:not(:disabled),summary")].filter((e) => e.getClientRects().length), n = e.shiftKey && document.activeElement === t[0] ? t.at(-1) : !e.shiftKey && document.activeElement === t.at(-1) ? t[0] : void 0;
					n && (e.preventDefault(), n.focus());
				},
				children: [/* @__PURE__ */ p("header", {
					className: "tmb-modal-head",
					children: [/* @__PURE__ */ f("b", {
						id: "tmb-battle-dialog-title",
						children: m(O === "menu" ? "games.toomanybones.moreOptions" : O === "backup" ? "games.toomanybones.backup" : O === "slots" ? "games.toomanybones.activate" : O === "loot" ? "games.toomanybones.loot" : O === "inspect" ? "games.toomanybones.inspect" : O === "dice" ? "games.toomanybones.resolveDice" : "games.toomanybones.battle")
					}), /* @__PURE__ */ f("button", {
						type: "button",
						"aria-label": m("games.toomanybones.close"),
						onClick: () => k(null),
						children: /* @__PURE__ */ f(_, { size: 20 })
					})]
				}), O === "menu" ? /* @__PURE__ */ p("div", {
					className: "tmb-battle-menu",
					children: [
						[
							["backup", "games.toomanybones.backup"],
							["slots", "games.toomanybones.activate"],
							["loot", "games.toomanybones.loot"],
							["inspect", "games.toomanybones.inspect"]
						].map(([e, t]) => /* @__PURE__ */ f("button", {
							type: "button",
							onClick: () => k(e),
							disabled: e === "loot" ? !h : e !== "inspect" && (!i || !b || fe),
							children: m(t)
						}, e)),
						i && fe && /* @__PURE__ */ f("button", {
							type: "button",
							onClick: () => k("special"),
							children: m("games.toomanybones.details")
						}),
						pe && De.map((e) => /* @__PURE__ */ f("button", {
							type: "button",
							onClick: () => {
								ce(e), k(null);
							},
							children: m("games.toomanybones.aim", { skill: qn(m, h.gearloc, e) })
						}, e)),
						M && V && /* @__PURE__ */ f("button", {
							type: "button",
							onClick: () => k("dice"),
							children: m("games.toomanybones.chooseResolution")
						}),
						(pe || M) && /* @__PURE__ */ f("button", {
							type: "button",
							disabled: Ve,
							onClick: () => {
								Oe.length && !A ? re(!0) : q({ type: "endTurn" });
							},
							children: m(A ? "games.toomanybones.endUnused" : "games.toomanybones.endTurn")
						})
					]
				}) : u(O, G?.id ?? S, C >= 0 ? C : Math.max(0, h?.pos ?? 0), O === "dice" ? V?.uid : void 0, () => k(null))]
			})
		})]
	});
}
//#endregion
//#region src/games/toomanybones/reaction-controls.tsx
function dr({ s: e, send: t, target: n, pos: r, slot: i, mode: a, setMode: o }) {
	let s = c(), l = e.battle.reactions[0], u = l.slice(l.indexOf(":") + 1).split("|")[0], m = e.actors.find((e) => e.id === u);
	if (l.startsWith("mischief:") && m && m.kind !== "gearloc") return /* @__PURE__ */ f("div", {
		className: "tmb-buttons",
		children: m.enemyDefense.map((e, n) => /* @__PURE__ */ p("button", {
			type: "button",
			onClick: () => t({
				type: "ability",
				ability: "reaction",
				amount: n
			}),
			children: [
				s("games.toomanybones.discard"),
				" · ",
				s("games.toomanybones.defense"),
				" ",
				e
			]
		}, n))
	});
	if (l.startsWith("shield:") && m) return /* @__PURE__ */ f("div", {
		className: "tmb-buttons",
		children: Object.entries(m.counters).filter(([e]) => e.startsWith("shield:")).map(([e, n]) => /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ p("b", { children: [
			s("games.toomanybones.defense"),
			" ",
			n
		] }), [
			"active",
			"locked",
			"discard"
		].map((n) => /* @__PURE__ */ f("button", {
			type: "button",
			onClick: () => t({
				type: "ability",
				ability: "reaction",
				amount: Number(e.slice(7)),
				mode: n
			}),
			children: s(n === "active" ? "games.toomanybones.store" : n === "locked" ? "games.toomanybones.lockStore" : "games.toomanybones.discard")
		}, n))] }, e))
	});
	let h = l.startsWith("riposte:") ? [
		"use",
		"double",
		"pass"
	] : l.startsWith("retaliate:") ? [
		"poison",
		"lashback",
		"both",
		"pass"
	] : l.startsWith("prevent:") || l.startsWith("roundOptics:") ? ["use", "pass"] : l.startsWith("sling:") ? ["use"] : [];
	return /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("p", { children: [s("games.toomanybones.pendingReaction", { name: m ? er(s, m) : s("games.toomanybones.target") }), l.startsWith("prevent:") && " · " + Q(s, l.split("|")[1])] }), /* @__PURE__ */ f("div", {
		className: "tmb-buttons",
		children: h.length ? h.map((e) => /* @__PURE__ */ f("button", {
			type: "button",
			onClick: () => t({
				type: "ability",
				ability: "reaction",
				mode: e
			}),
			children: s(e === "use" ? "games.toomanybones.use" : e === "double" || e === "both" ? "games.toomanybones.double" : e === "pass" ? "games.toomanybones.pass" : e === "poison" ? "games.toomanybones.poison" : "games.toomanybones.damage")
		}, e)) : /* @__PURE__ */ p(d, { children: [
			l.startsWith("limit:") && /* @__PURE__ */ p("select", {
				value: a,
				onChange: (e) => o(e.target.value),
				children: [/* @__PURE__ */ f("option", {
					value: "",
					children: s("games.toomanybones.skill")
				}), [
					"hp",
					"dex",
					"attack",
					"defense"
				].filter((e) => (m?.counters[e + "Training"] ?? 0) > 0 && !m?.effects["limited:" + e]).map((e) => /* @__PURE__ */ f("option", {
					value: e,
					children: s(e === "hp" ? "games.toomanybones.hp" : e === "dex" ? "games.toomanybones.dex" : e === "attack" ? "games.toomanybones.attack" : "games.toomanybones.defense")
				}, e))]
			}),
			l === "charred" && /* @__PURE__ */ p("select", {
				value: a,
				onChange: (e) => o(e.target.value),
				children: [/* @__PURE__ */ f("option", {
					value: "",
					children: s("games.toomanybones.target")
				}), e.actors.filter((e) => e.kind === "gearloc" && e.hp > 0 && e.pos >= 0).map((e) => /* @__PURE__ */ f("option", {
					value: e.id,
					children: er(s, e)
				}, e.id))]
			}),
			/* @__PURE__ */ f("button", {
				type: "button",
				onClick: () => t({
					type: "ability",
					ability: "reaction",
					target: n,
					pos: r,
					mode: a,
					slot: i
				}),
				children: s("games.toomanybones.confirm")
			})
		] })
	})] });
}
//#endregion
//#region src/games/toomanybones/battle-details.tsx
function fr({ s: e, myRid: t, tab: n, target: r, pos: i, initialDie: a, send: s }) {
	let l = c(), u = e.actors.find((e) => e.owner === t && e.kind === "gearloc"), m = e.battle, [h, g] = o(r), [_, v] = o(Math.max(0, i)), [y, b] = o(a ? [a] : []), [x, S] = o("use"), [ee, C] = o(1), [w, te] = o(1), [T, E] = o(() => {
		let e = m.rolled.find((e) => e.uid === a), t = e && me(e.face)[0];
		return [
			t?.kind === "parts" ? t.n : 1,
			0,
			0
		];
	}), [D, ne] = o(""), O = (e, t, n = !1) => /* @__PURE__ */ f("button", {
		type: "button",
		disabled: n,
		onClick: () => s(t),
		children: e
	}, e + JSON.stringify(t)), k = /* @__PURE__ */ p("label", { children: [l("games.toomanybones.target"), /* @__PURE__ */ p("select", {
		value: h,
		onChange: (e) => g(e.target.value),
		children: [
			/* @__PURE__ */ f("option", {
				value: "",
				children: l("games.toomanybones.noTarget")
			}),
			e.actors.map((e) => /* @__PURE__ */ p("option", {
				value: e.id,
				children: [
					er(l, e),
					" · ♥ ",
					e.hp
				]
			}, e.id)),
			m.rolled.filter((e) => !e.used && e.kind === "skill").map((e) => /* @__PURE__ */ f("option", {
				value: e.uid,
				children: u?.gearloc ? qn(l, u.gearloc, e.skill) : l("games.toomanybones.die")
			}, e.uid))
		]
	})] }), A = /* @__PURE__ */ p("label", { children: [l("games.toomanybones.position"), /* @__PURE__ */ f("select", {
		value: _,
		onChange: (e) => v(Number(e.target.value)),
		children: Array.from({ length: 16 }, (e, t) => /* @__PURE__ */ p("option", {
			value: t,
			children: [
				t % 4 + 1,
				"·",
				Math.floor(t / 4) + 1
			]
		}, t))
	})] }), re = (e) => b((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]);
	if (n === "inspect") return /* @__PURE__ */ p("div", {
		className: "tmb-controls",
		children: [
			e.encounter && /* @__PURE__ */ p("details", { children: [/* @__PURE__ */ f("summary", { children: l("games.toomanybones.encounter") }), /* @__PURE__ */ f("p", {
				className: "whitespace-pre-line",
				children: l(nr[e.encounter])
			})] }),
			e.actors.map((e) => /* @__PURE__ */ f(ir, { actor: e }, e.id)),
			/* @__PURE__ */ p("details", { children: [/* @__PURE__ */ f("summary", { children: l("games.toomanybones.history") }), e.log.slice().reverse().map((t, n) => /* @__PURE__ */ f("p", { children: l("games.toomanybones.logLine", {
				who: e.actors.some((e) => e.id === t.who) ? er(l, e.actors.find((e) => e.id === t.who)) : "",
				event: $n(l, t.key),
				target: e.actors.some((e) => e.id === t.target) ? er(l, e.actors.find((e) => e.id === t.target)) : "",
				n: t.n || ""
			}) }, n))] })
		]
	});
	if (!u) return null;
	if (n === "special") return /* @__PURE__ */ p("div", {
		className: "tmb-controls",
		children: [k, m.flags.includes("orderPending") ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("label", { children: [l("games.toomanybones.initiative"), /* @__PURE__ */ f("select", {
			value: ee,
			onChange: (e) => C(Number(e.target.value)),
			children: m.order.map((e, t) => /* @__PURE__ */ f("option", {
				value: t + 1,
				children: t + 1
			}, e))
		})] }), /* @__PURE__ */ p("div", {
			className: "tmb-buttons",
			children: [O(l("games.toomanybones.initiative"), {
				type: "ability",
				ability: "initiative",
				target: h,
				amount: ee - 1
			}), O(l("games.toomanybones.orderReady"), { type: "ready" })]
		})] }) : /* @__PURE__ */ f(d, { children: m.reactions.length ? /* @__PURE__ */ p(d, { children: [
			m.reactions[0].startsWith("mischief:") && /* @__PURE__ */ p("select", {
				"aria-label": l("games.toomanybones.active"),
				value: D,
				onChange: (e) => ne(e.target.value),
				children: [/* @__PURE__ */ f("option", {
					value: "",
					children: l("games.toomanybones.active")
				}), e.actors.flatMap((e) => e.active.map((e) => /* @__PURE__ */ p("option", {
					value: e.uid,
					children: [
						Q(l, e.kind),
						" ",
						e.n
					]
				}, e.uid)))]
			}),
			A,
			/* @__PURE__ */ f(dr, {
				s: e,
				send: s,
				target: h,
				pos: _,
				slot: D,
				mode: x,
				setMode: S
			})
		] }) : /* @__PURE__ */ p(d, { children: [A, /* @__PURE__ */ f("div", {
			className: "tmb-buttons",
			children: m.startEffects.map((e) => O(Q(l, e) + " · " + l("games.toomanybones.startEffect"), {
				type: "ability",
				ability: "startEffect",
				mode: e,
				target: h || u.id,
				pos: _
			}))
		})] }) })]
	});
	if (n === "dice") {
		let e = m.rolled.filter((e) => y.includes(e.uid) && !e.used), t = e[0], n = t && me(t.face)[0], r = [];
		t && n && ([
			"bones",
			"forcedBones",
			"reusableBones"
		].includes(n.kind) ? r.push("bones") : n.kind !== "blank" && r.push(n.kind === "defense" ? "active" : "use"), n.kind === "defense" && u.gearloc === "picket" && u.upgraded && r.push("locked"), ["switch", "rush"].includes(n.kind) && r.push("active"), [
			"healMultiply",
			"healReroll",
			"buffReroll"
		].includes(n.kind) && r.push("locked"), n.kind === "anger" && r.push("decrease"), u.gearloc === "boomer" && u.upgraded && t.skill > 0 && t.skill <= 3 && [
			"bones",
			"blank",
			"forcedBones",
			"reusableBones"
		].includes(n.kind) && r.push("locked"), t.kind === "defense" && Se(u, "l12") && ["bones", "defense:1"].includes(t.face) && !m.flags.includes("armor:" + t.uid) && r.push("increase"), !t.face.includes("forcedBones") && !t.face.includes("tainted") && !(u.gearloc === "boomer" && (t.skill === 16 || t.skill >= 5 && t.skill <= 11)) && r.push("discard"));
		let i = r.includes(x) ? x : r[0], a = e.length <= 1 || i === "use" && (e.every((e) => e.kind === "attack" && e.face.startsWith("attack:")) || e.length <= 2 && e.every((e) => ["switch", "rush"].includes(e.face) && e.face === t.face)), o = n?.kind !== "parts" || i === "discard" || T.reduce((e, t) => e + t, 0) === n.n, s = {
			use: "games.toomanybones.use",
			active: "games.toomanybones.store",
			locked: "games.toomanybones.lockStore",
			bones: "games.toomanybones.saveBones",
			discard: "games.toomanybones.discard",
			increase: "games.toomanybones.increase",
			decrease: "games.toomanybones.decrease",
			reroll: "games.toomanybones.reroll"
		}, c = !!n && [
			"heal",
			"healMultiply",
			"healReroll",
			"buffReroll",
			"trueDamage",
			"poisonAny",
			"revive",
			"reviveKo",
			"buffHp",
			"buffAttack",
			"recover",
			"booster",
			"permanentHp",
			"advancedDefense",
			"intercept",
			"switch",
			"rush",
			"attackMinus",
			"jump"
		].includes(n.kind);
		return /* @__PURE__ */ p("div", {
			className: "tmb-controls",
			children: [
				t?.skill && u.gearloc ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("h3", { children: qn(l, u.gearloc, t.skill) }), /* @__PURE__ */ f("p", { children: Gn(l, u.gearloc, t.skill) })] }) : null,
				/* @__PURE__ */ f("div", {
					className: "tmb-buttons",
					children: m.rolled.map((e) => /* @__PURE__ */ f("button", {
						type: "button",
						disabled: e.used,
						className: y.includes(e.uid) ? "tmb-selected" : "",
						onClick: () => re(e.uid),
						children: me(e.face).map((e) => Q(l, e.kind) + " " + e.n).join(" / ")
					}, e.uid))
				}),
				c && k,
				n && [
					"switch",
					"rush",
					"jump"
				].includes(n.kind) && A,
				n?.kind === "parts" && /* @__PURE__ */ f("div", {
					className: "tmb-select-row",
					children: [
						"element",
						"casing",
						"fuse"
					].map((e, t) => /* @__PURE__ */ p("label", { children: [Q(l, e), /* @__PURE__ */ f("input", {
						type: "number",
						min: 0,
						max: 3,
						value: T[t],
						onChange: (e) => E((n) => n.map((n, r) => r === t ? Math.max(0, Math.min(3, Number(e.target.value))) : n))
					})] }, e))
				}),
				r.length > 1 && /* @__PURE__ */ p("label", { children: [l("games.toomanybones.chooseResolution"), /* @__PURE__ */ f("select", {
					value: i,
					onChange: (e) => S(e.target.value),
					children: r.map((e) => /* @__PURE__ */ f("option", {
						value: e,
						children: l(s[e])
					}, e))
				})] }),
				/* @__PURE__ */ f("div", {
					className: "tmb-buttons",
					children: O(l(i ? s[i] : "games.toomanybones.use"), {
						type: "resolve",
						dice: e.map((e) => e.uid),
						mode: i,
						target: h || void 0,
						pos: _,
						amount: ee,
						components: T
					}, !e.length || !i || !a || !o)
				}),
				u.inventory.some((e) => e.card === "v14" && e.locks === 3) && !m.lastAttack.length && /* @__PURE__ */ p("details", { children: [
					/* @__PURE__ */ f("summary", { children: l("games.toomanybones.enemyTarget") }),
					k,
					O(l("games.toomanybones.confirm"), {
						type: "ability",
						ability: "target",
						target: h
					})
				] })
			]
		});
	}
	if (n === "backup") {
		let e = (u.gearloc === "patches" || u.gearloc === "picket" ? [
			2,
			3,
			4,
			5,
			6
		] : u.gearloc === "tantrum" ? [
			1,
			2,
			4,
			5,
			6
		] : [
			1,
			2,
			3,
			4,
			5,
			6
		]).filter((e) => !(e === 6 && u.upgraded) && Ce(u) >= Math.max(0, e - (e < 6 && Se(u, "v3") ? 1 : 0))), t = e.includes(ee) ? ee : e[0];
		return /* @__PURE__ */ p("div", {
			className: "tmb-controls",
			children: [
				/* @__PURE__ */ p("p", { children: [
					l("games.toomanybones.bones"),
					" ",
					Ce(u)
				] }),
				u.gearloc && /* @__PURE__ */ f("p", { children: l(u.gearloc === "boomer" ? "games.toomanybones.backupBoomer" : u.gearloc === "patches" ? "games.toomanybones.backupPatches" : u.gearloc === "picket" ? "games.toomanybones.backupPicket" : "games.toomanybones.backupTantrum") }),
				e.length > 0 && /* @__PURE__ */ p(d, { children: [
					/* @__PURE__ */ p("label", { children: [l("games.toomanybones.backup"), /* @__PURE__ */ f("select", {
						value: t,
						onChange: (e) => C(Number(e.target.value)),
						children: e.map((e) => /* @__PURE__ */ p("option", {
							value: e,
							children: [e, " Bones"]
						}, e))
					})] }),
					k,
					u.gearloc === "boomer" && t === 3 && A,
					u.gearloc === "patches" && t === 4 && /* @__PURE__ */ p("label", { children: [l("games.toomanybones.chooseSkills"), /* @__PURE__ */ f("select", {
						value: w,
						onChange: (e) => te(Number(e.target.value)),
						children: Array.from({ length: 16 }, (e, t) => /* @__PURE__ */ f("option", {
							value: t + 1,
							children: qn(l, "patches", t + 1)
						}, t))
					})] }),
					(u.gearloc === "boomer" && t === 2 || u.gearloc === "picket" && t === 3) && /* @__PURE__ */ f("div", {
						className: "tmb-buttons",
						children: m.rolled.filter((e) => !e.used).map((e) => /* @__PURE__ */ f("button", {
							type: "button",
							className: y.includes(e.uid) ? "tmb-selected" : "",
							onClick: () => re(e.uid),
							children: me(e.face).map((e) => Q(l, e.kind) + " " + e.n).join(" / ")
						}, e.uid))
					}),
					O(l("games.toomanybones.backup"), {
						type: "backup",
						cost: t,
						target: h,
						pos: _,
						ids: y,
						skill: w
					}, m.backupUsed || !!m.modifiers.noBackup)
				] })
			]
		});
	}
	let ie = e.actors.flatMap((e) => [...e.active, ...e.locked].filter((e) => e.owner === u.id).map((t) => ({
		holder: e,
		slot: t
	}))), ae = ie.find(({ slot: e }) => e.uid === D), j = ae?.holder.id === u.id && [
		"constantMove",
		"switch",
		"rush",
		"healMultiply",
		"healReroll",
		"buffReroll"
	].includes(ae.slot.kind);
	return /* @__PURE__ */ p("div", {
		className: "tmb-controls",
		children: [
			ie.length > 0 && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("div", {
				className: "tmb-buttons",
				children: ie.map(({ holder: e, slot: t }) => /* @__PURE__ */ p("button", {
					type: "button",
					className: D === t.uid ? "tmb-selected" : "",
					onClick: () => ne(t.uid),
					children: [
						er(l, e).split(" · ")[0],
						" · ",
						Q(l, t.kind),
						" ",
						t.n
					]
				}, t.uid))
			}), ae && /* @__PURE__ */ p(d, { children: [j && /* @__PURE__ */ p(d, { children: [
				k,
				A,
				/* @__PURE__ */ p("label", { children: [l("games.toomanybones.activate"), /* @__PURE__ */ p("select", {
					value: x,
					onChange: (e) => S(e.target.value),
					children: [/* @__PURE__ */ f("option", {
						value: "use",
						children: l("games.toomanybones.use")
					}), /* @__PURE__ */ f("option", {
						value: "double",
						children: l("games.toomanybones.double")
					})]
				})] })
			] }), /* @__PURE__ */ p("div", {
				className: "tmb-buttons",
				children: [j && O(l("games.toomanybones.activate"), {
					type: "ability",
					ability: "activate",
					slot: D,
					target: h,
					pos: _,
					mode: x
				}), O(l("games.toomanybones.release"), {
					type: "ability",
					ability: "release",
					slot: D,
					target: ae.holder.id
				})]
			})] })] }),
			u.gearloc === "boomer" && O(l("games.toomanybones.craft"), {
				type: "ability",
				ability: "craft"
			}, u.counters.grenades >= 3),
			u.gearloc === "tantrum" && /* @__PURE__ */ p(d, { children: [
				k,
				/* @__PURE__ */ p("div", {
					className: "tmb-buttons",
					children: [u.counters.axes > 0 && O(l("games.toomanybones.axe"), {
						type: "ability",
						ability: "axe",
						target: h
					}, !!u.counters.axeUsed || !e.actors.some((e) => e.id === h && e.kind === "baddie" && !J(u.pos, e.pos))), u.counters.bodyCount > 0 && O(l("games.toomanybones.bodyCount"), {
						type: "ability",
						ability: "bodyCount"
					})]
				}),
				/* @__PURE__ */ p("details", { children: [/* @__PURE__ */ f("summary", { children: l("games.toomanybones.rage") }), /* @__PURE__ */ f("div", {
					className: "tmb-buttons",
					children: [
						"heal",
						"damage",
						"bones",
						"execute",
						"advance"
					].map((e) => O(l(e === "heal" ? "games.toomanybones.heal" : e === "damage" ? "games.toomanybones.damage" : e === "bones" ? "games.toomanybones.bones" : e === "execute" ? "games.toomanybones.execute" : "games.toomanybones.advance"), {
						type: "ability",
						ability: "rage",
						mode: e,
						target: h
					}))
				})] })
			] })
		]
	});
}
//#endregion
//#region src/games/toomanybones/view-player.tsx
function pr(e) {
	let t = e.public, n = e.private, r = c(), [i, a] = o(!1), [s, m] = o(""), [h, g] = o(0), _ = t.actors.find((t) => t.owner === e.myRid && t.kind === "gearloc"), v = t.battle;
	if ((t.phase === "battle" || t.phase === "done") && v) return /* @__PURE__ */ f(lr, {
		s: t,
		myRid: e.myRid,
		canAct: t.phase === "battle" && !!n?.canAct,
		send: e.send,
		tools: (n, r, i, a, o) => t.phase === "done" ? /* @__PURE__ */ f("div", {
			className: "tmb-controls",
			children: t.actors.map((e) => /* @__PURE__ */ f(ir, { actor: e }, e.id))
		}) : n === "loot" ? /* @__PURE__ */ f(mr, {
			s: t,
			myRid: e.myRid,
			target: r,
			pos: i,
			send: (t) => {
				e.send(t), o();
			}
		}, n) : /* @__PURE__ */ f(fr, {
			s: t,
			myRid: e.myRid,
			tab: n,
			target: r,
			pos: i,
			initialDie: a,
			send: (t) => {
				e.send(t), o();
			}
		}, n + ":" + a + ":" + v.reactions[0] + ":" + v.startEffects.join(","))
	});
	let y = (e) => er(r, e), b = (t) => e.send(t), x = (e) => {
		g(e), t.phase === "battle" && v?.stage === "move" && t.actors.some((e) => e.id === v.turn && e.kind === "ally") ? b({
			type: "ability",
			ability: "allyMove",
			pos: e
		}) : t.phase === "battle" && v?.stage === "deployment" || t.phase === "challenge" && t.challenge.data.deploy ? b({
			type: "deploy",
			pos: e
		}) : (t.phase === "battle" && v?.stage === "enemyMove" || t.phase === "battle" && v?.stage === "move" && v.turn === _?.id || t.phase === "challenge" && t.challenge.kind === "critters") && b({
			type: "move",
			pos: e
		});
	}, S = /* @__PURE__ */ f("div", {
		className: "tmb-board",
		children: Array.from({ length: 16 }, (e, n) => {
			let i = t.actors.filter((e) => e.pos === n && e.hp > 0), a = t.challenge.values[n];
			return /* @__PURE__ */ p("div", {
				className: `tmb-cell ${h === n ? "tmb-cell-selected" : ""}`,
				children: [/* @__PURE__ */ p("button", {
					type: "button",
					className: "tmb-cell-hit",
					"aria-label": r("games.toomanybones.position") + " " + (n + 1),
					onClick: () => x(n),
					children: [/* @__PURE__ */ p("span", {
						className: "tmb-coord",
						children: [
							n % 4 + 1,
							"·",
							Math.floor(n / 4) + 1
						]
					}), t.phase === "challenge" && ["critters", "rubble"].includes(t.challenge.kind) && a > 0 && /* @__PURE__ */ p("span", {
						className: "tmb-object",
						children: [a, " ♥"]
					})]
				}), i.map((e) => /* @__PURE__ */ p("button", {
					type: "button",
					className: `tmb-chip ${e.kind === "gearloc" || e.kind === "ally" ? "tmb-chip-hero" : "tmb-chip-enemy"} ${s === e.id ? "tmb-chip-selected" : ""}`,
					onClick: () => {
						m(e.id), g(n), v?.stage === "enemyTarget" && b({
							type: "ability",
							ability: "target",
							target: e.id
						});
					},
					"aria-label": y(e),
					children: [/* @__PURE__ */ f("span", { children: e.gearloc ? {
						boomer: "B",
						patches: "Pa",
						picket: "Pi",
						tantrum: "T"
					}[e.gearloc] : e.point || "◆" }), /* @__PURE__ */ p("small", { children: [e.hp, " ♥"] })]
				}, e.id))]
			}, n);
		})
	});
	return /* @__PURE__ */ p("div", {
		className: "tmb-root h-full",
		children: [/* @__PURE__ */ f(l, {
			adaptive: !0,
			className: "tmb-adventure",
			actionsHeight: "tmb-adventure-actions",
			banner: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(u, {
				tone: n?.canAct ? "accent" : "info",
				accent: Pn.accent,
				text: r(Hn[t.phase]),
				chip: r("games.toomanybones.dayCount", {
					n: t.day,
					p: t.progress,
					total: te[t.config.tyrant].progress
				})
			}), /* @__PURE__ */ f("div", {
				className: "tmb-party",
				children: t.actors.filter((e) => e.gearloc).map((e) => /* @__PURE__ */ p("button", {
					className: s === e.id ? "tmb-selected" : "",
					type: "button",
					onClick: () => m(e.id),
					children: [
						y(e).split(" · ")[0],
						" ",
						/* @__PURE__ */ p("b", { children: [
							e.hp,
							"/",
							e.maxHp,
							" ♥"
						] }),
						e.training > 0 && /* @__PURE__ */ p("small", { children: [" ↑", e.training] })
					]
				}, e.id))
			})] }),
			actions: /* @__PURE__ */ p("div", {
				className: "tmb-footer",
				children: [/* @__PURE__ */ p("div", {
					className: "tmb-footnote",
					children: [
						v ? r("games.toomanybones.round", { n: v.round }) : r(Hn[t.phase]),
						" · ",
						s ? y(t.actors.find((e) => e.id === s) ?? _) : r("games.toomanybones.noTarget")
					]
				}), /* @__PURE__ */ p("div", {
					className: "tmb-buttons",
					children: [/* @__PURE__ */ f("button", {
						type: "button",
						onClick: () => a(!0),
						children: r("games.toomanybones.actions")
					}), t.phase === "battle" && v?.turn === _?.id && /* @__PURE__ */ f("button", {
						type: "button",
						onClick: () => b({ type: "endTurn" }),
						children: r("games.toomanybones.endTurn")
					})]
				})]
			}),
			children: /* @__PURE__ */ p("div", {
				className: "tmb-adventure-scene",
				children: [/* @__PURE__ */ f("div", {
					className: "tmb-adventure-field",
					children: t.phase === "challenge" && t.challenge.kind === "flick" ? /* @__PURE__ */ f(_r, {
						s: t,
						send: b,
						myRid: e.myRid
					}) : S
				}), /* @__PURE__ */ p("div", {
					className: "tmb-adventure-panel",
					children: [
						/* @__PURE__ */ f("div", {
							className: "tmb-initiative",
							children: v?.order.map((e, n) => {
								let r = t.actors.find((t) => t.id === e);
								return r && /* @__PURE__ */ p("button", {
									type: "button",
									className: v.turn === e ? "tmb-selected" : "",
									onClick: () => m(e),
									children: [
										n + 1,
										". ",
										y(r).split(" · ")[0],
										" · ",
										r.initiative
									]
								}, e);
							})
						}),
						_ && /* @__PURE__ */ f(hr, {
							a: _,
							s: t
						}),
						t.encounter && /* @__PURE__ */ p("div", {
							className: "tmb-card",
							children: [
								/* @__PURE__ */ f("h3", { children: r(nr[t.encounter]).split("\n")[0] }),
								/* @__PURE__ */ f("p", { children: r("games.toomanybones.progressShort", { n: O(t.encounter).reward.progress }) }),
								/* @__PURE__ */ f("p", {
									className: "whitespace-pre-line",
									children: r(nr[t.encounter]).split("\n").slice(1).join("\n")
								})
							]
						})
					]
				})]
			})
		}), i && /* @__PURE__ */ f("div", {
			className: "tmb-modal",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": r("games.toomanybones.actions"),
			children: /* @__PURE__ */ p("div", {
				className: "tmb-modal-body",
				children: [/* @__PURE__ */ p("div", {
					className: "tmb-modal-head",
					children: [/* @__PURE__ */ f("b", { children: r(Hn[t.phase]) }), /* @__PURE__ */ f("button", {
						type: "button",
						onClick: () => a(!1),
						children: r("games.toomanybones.close")
					})]
				}), t.phase === "done" ? /* @__PURE__ */ f("div", {
					className: "tmb-controls",
					children: t.actors.map((e) => /* @__PURE__ */ f(ir, { actor: e }, e.id))
				}) : /* @__PURE__ */ f(gr, {
					s: t,
					myRid: e.myRid,
					target: s,
					pos: h,
					setPos: g,
					setTarget: m,
					send: b
				}, t.phase + ":" + v?.turn + ":" + v?.round)]
			})
		})]
	});
}
function mr({ s: e, myRid: t, target: n, pos: r, send: i }) {
	let [a, s] = o(n), [c, l] = o(r);
	return /* @__PURE__ */ f(gr, {
		inventoryOnly: !0,
		s: e,
		myRid: t,
		target: a,
		pos: c,
		setTarget: s,
		setPos: l,
		send: i
	});
}
function hr({ a: e, s: t }) {
	let n = c();
	return /* @__PURE__ */ p("div", {
		className: "tmb-mat",
		children: [
			/* @__PURE__ */ f("div", {
				className: "tmb-stats",
				children: [
					n("games.toomanybones.hp") + " " + e.hp + "/" + e.maxHp,
					n("games.toomanybones.dex") + " " + e.dex,
					n("games.toomanybones.attack") + " " + e.attack,
					n("games.toomanybones.defense") + " " + e.defense
				].map((e) => /* @__PURE__ */ f("span", { children: e }, e))
			}),
			[
				["active", e.active],
				["locked", e.locked],
				["bones", e.bones]
			].map(([e, t]) => /* @__PURE__ */ p("div", {
				className: "tmb-slots",
				children: [/* @__PURE__ */ f("b", { children: n(e === "active" ? "games.toomanybones.active" : e === "locked" ? "games.toomanybones.locked" : "games.toomanybones.bones") }), t.map((e) => /* @__PURE__ */ p("span", {
					className: "tmb-die",
					children: [
						Q(n, e.kind),
						" ",
						e.n
					]
				}, e.uid))]
			}, e)),
			/* @__PURE__ */ f("div", {
				className: "tmb-slots",
				children: (t.battle?.turn === e.id ? t.battle.rolled : []).map((e) => /* @__PURE__ */ f("span", {
					className: `tmb-die ${e.used ? "tmb-used" : ""}`,
					children: me(e.face).map((e) => Q(n, e.kind) + " " + e.n).join(" / ")
				}, e.uid))
			})
		]
	});
}
function gr({ s: e, myRid: t, target: n, pos: r, setPos: i, setTarget: a, send: s, inventoryOnly: l = !1 }) {
	let u = c(), m = e.actors.find((e) => e.kind === "gearloc" && e.owner === t), h = e.battle, [g, _] = o(1), [v, y] = o([]), [b, x] = o(1), [S, ee] = o(1), C = (e) => y((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e]), w = (t, n, r = !1) => /* @__PURE__ */ f("button", {
		type: "button",
		disabled: r || e.phase === "done",
		onClick: () => {
			s(n), [
				"resolve",
				"backup",
				"loot",
				"lock"
			].includes(n.type) && y([]);
		},
		children: t
	}, JSON.stringify(n) + t), T = (e, t, n, r) => /* @__PURE__ */ p("label", {
		className: "tmb-number",
		children: [e, /* @__PURE__ */ f("input", {
			type: "number",
			min: 0,
			max: r,
			value: t,
			onChange: (e) => n(Math.max(0, Math.min(r, Number(e.target.value))))
		})]
	}), E = /* @__PURE__ */ p("label", { children: [u("games.toomanybones.target"), /* @__PURE__ */ p("select", {
		value: n,
		onChange: (e) => a(e.target.value),
		children: [
			/* @__PURE__ */ f("option", {
				value: "",
				children: u("games.toomanybones.noTarget")
			}),
			e.actors.map((e) => /* @__PURE__ */ p("option", {
				value: e.id,
				children: [
					er(u, e),
					" · ",
					e.hp,
					" ♥"
				]
			}, e.id)),
			h?.rolled.filter((e) => !e.used).map((e) => /* @__PURE__ */ p("option", {
				value: e.uid,
				children: [
					e.skill && m?.gearloc ? qn(u, m.gearloc, e.skill) : u("games.toomanybones.die"),
					" · ",
					Q(u, me(e.face)[0].kind)
				]
			}, e.uid))
		]
	})] }), D = l && m && /* @__PURE__ */ p(d, { children: [T(u("games.toomanybones.amount"), g, _, 30), /* @__PURE__ */ f("div", {
		className: "tmb-buttons",
		children: h?.rolled.filter((e) => !e.used).map((e) => /* @__PURE__ */ f("button", {
			type: "button",
			className: v.includes(e.uid) ? "tmb-selected" : "",
			onClick: () => C(e.uid),
			children: me(e.face).map((e) => Q(u, e.kind) + " " + e.n).join(" / ")
		}, e.uid))
	})] }), ne = null;
	if (l) ne = null;
	else if (e.phase === "recruit") ne = /* @__PURE__ */ f("div", {
		className: "tmb-buttons",
		children: se.map((t) => w(u(Bn[t]), {
			type: "chooseGearloc",
			gearloc: t
		}, e.actors.some((e) => e.gearloc === t)))
	});
	else if (!m) ne = /* @__PURE__ */ f("p", { children: u("games.toomanybones.wait") });
	else if (e.lock) {
		let t = e.lock;
		ne = /* @__PURE__ */ p(d, { children: [
			/* @__PURE__ */ f("h3", { children: u("games.toomanybones.lockPrompt", {
				n: t.at + 1,
				type: t.types[t.at],
				value: t.values[t.at]
			}) }),
			/* @__PURE__ */ f("div", {
				className: "tmb-buttons",
				children: t.available.map((e) => /* @__PURE__ */ f("button", {
					type: "button",
					className: v.includes(String(e)) ? "tmb-selected" : "",
					onClick: () => C(String(e)),
					children: t.rolled[e] ?? "◇"
				}, e))
			}),
			/* @__PURE__ */ f("p", { children: t.intuition === "none" ? "" : u(t.intuition === "reroll" ? "games.toomanybones.reroll" : t.intuition === "convert" ? "games.toomanybones.convert" : "games.toomanybones.save") }),
			/* @__PURE__ */ p("div", {
				className: "tmb-buttons",
				children: [
					w(u("games.toomanybones.rollLock"), {
						type: "lock",
						mode: "roll"
					}),
					w(u("games.toomanybones.solve"), {
						type: "lock",
						mode: "solve",
						dice: v.map(Number)
					}),
					w(u("games.toomanybones.reroll"), {
						type: "lock",
						mode: "reroll",
						dice: v.map(Number)
					}),
					w(u("games.toomanybones.save"), {
						type: "lock",
						mode: "save",
						die: Number(v[0])
					}),
					[
						"L",
						"T",
						"F"
					].map((e) => w(u("games.toomanybones.convert") + " " + e, {
						type: "lock",
						mode: "convert",
						die: Number(v[0]),
						lockType: e
					})),
					w(u("games.toomanybones.stop"), {
						type: "lock",
						mode: "stop"
					})
				]
			})
		] });
	} else e.challenge.kind === "scout" || e.challenge.kind === "lootChoice" ? ne = /* @__PURE__ */ f(or, {
		s: e,
		a: m,
		send: s
	}) : e.phase === "training" ? ne = /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("p", { children: u("games.toomanybones.trainingPoints", { n: m.training }) }), /* @__PURE__ */ p("div", {
		className: "tmb-buttons",
		children: [
			[
				"hp",
				"dex",
				"attack",
				"defense"
			].map((e) => w(u(e === "hp" ? "games.toomanybones.hp" : e === "dex" ? "games.toomanybones.dex" : e === "attack" ? "games.toomanybones.attack" : "games.toomanybones.defense"), {
				type: "train",
				stat: e
			}, !m.training || m.failedTraining.includes(e))),
			m.gearloc && oe[m.gearloc].filter((e) => !e.consumable && !m.skills.includes(e.id) && e.requires.every((e) => m.skills.includes(e))).map((e) => w(qn(u, m.gearloc, e.id), {
				type: "train",
				stat: "skill",
				skill: e.id
			}, !m.training)),
			w(u("games.toomanybones.ready"), { type: "ready" }, m.training > 0)
		]
	})] }) : e.phase === "day" ? ne = /* @__PURE__ */ p("div", {
		className: "tmb-buttons",
		children: [w(u("games.toomanybones.draw"), {
			type: "choose",
			option: 0
		}), w(u("games.toomanybones.fightTyrant"), {
			type: "choose",
			option: 1
		}, e.progress < te[e.config.tyrant].progress)]
	}) : e.phase === "encounter" ? ne = /* @__PURE__ */ p(d, { children: [
		E,
		T(u("games.toomanybones.amount"), g, _, 30),
		/* @__PURE__ */ f("div", {
			className: "tmb-buttons",
			children: Array.from({ length: O(e.encounter).choices }, (e, t) => w(u("games.toomanybones.choice", { n: t + 1 }), {
				type: "choose",
				option: t,
				target: n || m.id,
				amount: g,
				ids: v
			}))
		})
	] }) : e.phase === "recovery" ? ne = /* @__PURE__ */ p("div", {
		className: "tmb-buttons",
		children: [
			w(u("games.toomanybones.rest"), {
				type: "recover",
				option: "rest"
			}),
			w(u("games.toomanybones.search"), {
				type: "recover",
				option: "search",
				loot: v[0]
			}),
			w(u("games.toomanybones.scout"), {
				type: "recover",
				option: "scout"
			}),
			w(u("games.toomanybones.ready"), { type: "ready" })
		]
	}) : e.phase === "challenge" && (ne = /* @__PURE__ */ f(or, {
		s: e,
		a: m,
		send: s
	}, e.challenge.kind + ":" + e.challenge.ids[0] + ":" + e.challenge.step));
	return /* @__PURE__ */ p("div", {
		className: "tmb-controls",
		children: [
			!l && e.encounter && /* @__PURE__ */ f("p", {
				className: "whitespace-pre-line",
				children: u(nr[e.encounter])
			}),
			e.battle && /* @__PURE__ */ p("label", { children: [u("games.toomanybones.position"), /* @__PURE__ */ f("select", {
				value: r,
				onChange: (e) => i(Number(e.target.value)),
				children: Array.from({ length: 16 }, (e, t) => /* @__PURE__ */ p("option", {
					value: t,
					children: [
						t % 4 + 1,
						"·",
						Math.floor(t / 4) + 1
					]
				}, t))
			})] }),
			ne,
			D,
			m && !h && ["training", "recovery"].includes(e.phase) && /* @__PURE__ */ f("div", {
				className: "tmb-buttons",
				children: e.actors.flatMap((e) => [...e.active, ...e.locked].filter((e) => e.owner === m.id).map((t) => w(u("games.toomanybones.release") + " · " + Q(u, t.kind) + " " + t.n, {
					type: "ability",
					ability: "release",
					slot: t.uid,
					target: e.id
				})))
			}),
			m?.gearloc && /* @__PURE__ */ p("label", { children: [u("games.toomanybones.chooseSkills"), /* @__PURE__ */ f("select", {
				value: b,
				onChange: (e) => x(Number(e.target.value)),
				children: oe[m.gearloc].map((e) => /* @__PURE__ */ f("option", {
					value: e.id,
					children: qn(u, m.gearloc, e.id)
				}, e.id))
			})] }),
			m?.inventory.some((e) => v.includes(e.uid) && e.card === "l17") && /* @__PURE__ */ p("label", { children: [u("games.toomanybones.creature"), /* @__PURE__ */ f("select", {
				value: S,
				onChange: (e) => ee(Number(e.target.value)),
				children: u("games.toomanybones.creatureNames").split("|").map((e, t) => /* @__PURE__ */ f("option", {
					value: t + 1,
					children: e
				}, t))
			})] }),
			m && /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("h3", { children: u("games.toomanybones.loot") }),
				E,
				/* @__PURE__ */ p("div", {
					className: "tmb-buttons",
					children: [
						e.actors.filter((e) => e.gearloc).flatMap((e) => e.inventory.map((t) => /* @__PURE__ */ p("button", {
							type: "button",
							className: v.includes(t.uid) ? "tmb-selected" : "",
							onClick: () => C(t.uid),
							children: [
								er(u, e).split(" · ")[0],
								" · ",
								Jn(u, t.card),
								" · ",
								ae(t.card).trove && t.locks < 3 ? `${t.locks}/3` : t.uses
							]
						}, t.uid))),
						(l ? ["use", "backup"] : [
							"use",
							"discard",
							"give",
							"backup"
						]).map((e) => w(u(e === "use" ? "games.toomanybones.use" : e === "discard" ? "games.toomanybones.discard" : e === "give" ? "games.toomanybones.trade" : "games.toomanybones.backup"), {
							type: "loot",
							loot: v.find((e) => m.inventory.some((t) => t.uid === e)) ?? "",
							mode: e,
							target: n,
							amount: m.inventory.some((e) => v.includes(e.uid) && e.card === "l17") ? S : g,
							skill: b,
							ids: v.filter((e) => !m.inventory.some((t) => t.uid === e)),
							pos: r
						}, !v.length)),
						e.phase === "recovery" && w(u("games.toomanybones.lockpick"), {
							type: "lockStart",
							loot: v.find((t) => e.actors.some((e) => e.inventory.some((e) => e.uid === t))) ?? "",
							owner: e.actors.find((e) => e.inventory.some((e) => v.includes(e.uid)))?.id ?? m.id
						})
					]
				})
			] }),
			/* @__PURE__ */ p("details", { children: [/* @__PURE__ */ f("summary", { children: u("games.toomanybones.inspect") }), e.actors.map((e) => /* @__PURE__ */ f(ir, { actor: e }, e.id))] }),
			/* @__PURE__ */ p("details", { children: [/* @__PURE__ */ f("summary", { children: u("games.toomanybones.history") }), e.log.slice(-40).reverse().map((t, n) => /* @__PURE__ */ f("p", { children: u("games.toomanybones.logLine", {
				who: e.actors.some((e) => e.id === t.who) ? er(u, e.actors.find((e) => e.id === t.who)) : "",
				event: $n(u, t.key),
				target: e.actors.some((e) => e.id === t.target) ? er(u, e.actors.find((e) => e.id === t.target)) : "",
				n: t.n || ""
			}) }, n))] })
		]
	});
}
function _r({ s: e, send: t, myRid: n }) {
	let r = c(), i = a(null), s = e.challenge, [l, u] = o(0), [d, m] = o(0), [h, g] = o(65), [_, v] = o(null);
	return /* @__PURE__ */ p("div", { children: [
		/* @__PURE__ */ f("p", { children: r("games.toomanybones.flick") }),
		/* @__PURE__ */ p("svg", {
			className: "tmb-flick",
			viewBox: "0 0 1000 1000",
			role: "img",
			"aria-label": r("games.toomanybones.flick"),
			onPointerDown: (e) => {
				if (s.by !== n) return;
				let t = e.currentTarget.getBoundingClientRect(), r = (e.clientX - t.left) / t.width * 1e3, a = (e.clientY - t.top) / t.height * 1e3, o = Math.floor(r / 250);
				a < 800 || s.data["shot:" + o] || (i.current = {
					x: r,
					y: a,
					lane: o
				}, v({
					x: r,
					y: a,
					fromX: r,
					fromY: a
				}), e.currentTarget.setPointerCapture(e.pointerId));
			},
			onPointerUp: (e) => {
				let n = i.current;
				if (!n) return;
				let r = e.currentTarget.getBoundingClientRect(), a = (e.clientX - r.left) / r.width * 1e3, o = (e.clientY - r.top) / r.height * 1e3;
				i.current = null, v(null), t({
					type: "flick",
					lane: n.lane,
					x: Math.max(n.lane * 250 + 25, Math.min(n.lane * 250 + 225, n.x)),
					vx: Math.max(-2500, Math.min(2500, (a - n.x) * 4)),
					vy: Math.max(-4e3, Math.min(-50, (o - n.y) * 4))
				});
			},
			onPointerMove: (e) => {
				if (!i.current) return;
				let t = e.currentTarget.getBoundingClientRect();
				v({
					fromX: i.current.x,
					fromY: i.current.y,
					x: (e.clientX - t.left) / t.width * 1e3,
					y: (e.clientY - t.top) / t.height * 1e3
				});
			},
			onPointerCancel: () => {
				i.current = null, v(null);
			},
			children: [
				/* @__PURE__ */ f("rect", {
					width: "1000",
					height: "1000",
					fill: "#253a37"
				}),
				_ && /* @__PURE__ */ f("line", {
					x1: _.fromX,
					y1: _.fromY,
					x2: _.x,
					y2: _.y,
					stroke: "#f3dc99",
					strokeWidth: "8",
					strokeDasharray: "18 12"
				}),
				[
					0,
					1,
					2,
					3
				].map((e) => /* @__PURE__ */ p("g", { children: [
					/* @__PURE__ */ f("path", {
						d: `M${e * 250} 0V1000`,
						stroke: "#c5b58b",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ f("circle", {
						cx: s.values[e * 2],
						cy: s.values[e * 2 + 1],
						r: "21",
						fill: s.data["hit:" + e] ? "#e3a44f" : "#dae0c3"
					}),
					!s.data["shot:" + e] && /* @__PURE__ */ f("path", {
						d: `M${125 + e * 250} 965v-60l-16 22m16-22 16 22`,
						stroke: "#f7e7c4",
						strokeWidth: "8",
						fill: "none"
					})
				] }, e)),
				/* @__PURE__ */ f("polyline", {
					points: s.dice.reduce((e, t, n) => n % 2 == 0 ? [...e, t + "," + s.dice[n + 1]] : e, []).join(" "),
					fill: "none",
					stroke: "#ddbf76",
					strokeWidth: "4"
				})
			]
		}),
		/* @__PURE__ */ f("p", { children: r("games.toomanybones.shots", { n: s.step }) }),
		/* @__PURE__ */ p("details", { children: [/* @__PURE__ */ f("summary", { children: r("games.toomanybones.flickAdjust") }), /* @__PURE__ */ p("div", {
			className: "tmb-controls",
			children: [
				/* @__PURE__ */ p("label", { children: [r("games.toomanybones.flickLane", { n: l + 1 }), /* @__PURE__ */ f("select", {
					value: l,
					onChange: (e) => u(Number(e.target.value)),
					children: [
						0,
						1,
						2,
						3
					].map((e) => /* @__PURE__ */ f("option", {
						value: e,
						children: r("games.toomanybones.flickLane", { n: e + 1 })
					}, e))
				})] }),
				/* @__PURE__ */ p("label", { children: [
					r("games.toomanybones.flickAngle"),
					" ",
					d,
					"°",
					/* @__PURE__ */ f("input", {
						type: "range",
						min: -60,
						max: 60,
						value: d,
						onChange: (e) => m(Number(e.target.value))
					})
				] }),
				/* @__PURE__ */ p("label", { children: [
					r("games.toomanybones.flickPower"),
					" ",
					h,
					/* @__PURE__ */ f("input", {
						type: "range",
						min: 2,
						max: 100,
						value: h,
						onChange: (e) => g(Number(e.target.value))
					})
				] }),
				/* @__PURE__ */ f("button", {
					type: "button",
					disabled: s.by !== n || !!s.data["shot:" + l],
					onClick: () => t({
						type: "flick",
						lane: l,
						x: l * 250 + 125,
						vx: Math.max(-2500, Math.min(2500, Math.sin(d * Math.PI / 180) * h * 40)),
						vy: -Math.max(50, Math.cos(d * Math.PI / 180) * h * 40)
					}),
					children: r("games.toomanybones.flickShoot")
				})
			]
		})] })
	] });
}
//#endregion
//#region src/games/toomanybones/bot.ts
var vr = (e, t) => Math.abs(ht(e) - ht(t)) + Math.abs(mt(e) - mt(t)), $ = (e = 0, t, n, r) => ({
	type: "choose",
	option: e,
	target: t,
	amount: n,
	ids: r
});
function yr(e) {
	let t = e.lock;
	if (!t.rolled.length) return {
		type: "lock",
		mode: "roll"
	};
	let n = t.available.filter((e) => t.rolled[e][0] === t.types[t.at]), r = Array.from({ length: 1 << n.length }, (e, t) => n.filter((e, n) => t & 1 << n)).filter((e) => e.reduce((e, n) => e + Number(t.rolled[n].slice(1)), 0) >= t.values[t.at]);
	if (r.sort((e, t) => e.length - t.length), r[0]) return {
		type: "lock",
		mode: "solve",
		dice: r[0]
	};
	let i = [...t.available].sort((e, n) => Number(t.rolled[n].slice(1)) - Number(t.rolled[e].slice(1)))[0];
	if (!t.usedIntuition && t.intuition === "convert") {
		let e = t.available.find((e) => !n.includes(e));
		if (e !== void 0) return {
			type: "lock",
			mode: "convert",
			die: e,
			lockType: t.types[t.at]
		};
	}
	return !t.usedIntuition && t.intuition === "save" && i !== void 0 ? {
		type: "lock",
		mode: "save",
		die: i
	} : t.intuition === "reroll" && t.available.length ? {
		type: "lock",
		mode: "reroll",
		dice: [t.available.find((e) => !n.includes(e)) ?? t.available[0]]
	} : {
		type: "lock",
		mode: "stop"
	};
}
function br(e, t) {
	let n = e.challenge, r = I(e).flatMap((e) => e.inventory);
	if (n.kind === "scout") return $(0);
	if (n.kind === "lootChoice") return $(0, n.ids[0]);
	if (n.kind === "flick") {
		if (n.data.complete) return $();
		let e = [
			0,
			1,
			2,
			3
		].find((e) => !n.data["shot:" + e]);
		return e === void 0 ? null : {
			type: "flick",
			lane: e,
			x: e * 250 + 125,
			vx: 0,
			vy: -1900
		};
	}
	if (n.kind === "decision") switch (n.ids[0]) {
		case "pickEncounter": return $(0, n.ids[1]);
		case "startingLoot": return $(0, I(e)[n.step].inventory.at(-1)?.uid);
		case "troveRedraw": return $(0);
		case "troveImmediate": return $(1);
		case "discardThenRedraw":
		case "bribe": return $(0, void 0, void 0, r.slice(0, n.values[0]).map((e) => e.uid));
		case "snipe": return $(0, void 0, t.attack);
		case "grab": return $(0, void 0, 1);
		case "whirlwind":
		case "trapHp":
		case "duel":
		case "wolfHand": {
			let t = I(e).filter((e) => e.hp > 0);
			return t.sort((e, t) => n.ids[0] === "trapHp" ? Math.abs(e.hp - n.values[0]) - Math.abs(t.hp - n.values[0]) : t.hp - e.hp), $(0, t[0]?.id);
		}
		case "scoutReturn": return $(0, void 0, 1);
		case "exhaustStats": return $(0, void 0, 1);
		case "barrelCount": return $(0, void 0, Math.min(e.players.length, 4));
		case "gambleLoot": return $(0, void 0, void 0, r.slice(0, e.players.length === 1 ? 2 : 4).map((e) => e.uid));
		case "offering": return $(0, t.inventory[0]?.uid);
		case "tripSkills": return $(0, void 0, void 0, t.skills.filter((e) => !M(t.gearloc, e).counter).slice(0, 3).map(String));
		case "healDuster": return $(0, void 0, void 0, r.filter((e) => [
			"l2",
			"l5",
			"l8",
			"l10",
			"l28"
		].includes(e.card)).map((e) => e.uid));
		case "bogIngredients": return $(0);
		case "goblinBomb": return $(0, "L");
		default: return null;
	}
	if (n.kind === "darts") return n.data.discard ? $(0, t.inventory[0]?.uid) : n.data.setup ? $(0, void 0, 2) : n.data.enemyTurn ? null : n.data.bones ? $(n.data.bones >= 3 ? 4 : n.data.bones >= 2 ? 3 : n.values[4] > 0 ? 1 : n.values[3] > 0 ? 2 : 0) : $(0, void 0, void 0, cn(n, 0).slice(0, n.data["weaken:0"] ?? 0).map((e) => e.id));
	if (n.kind === "barrels") return $();
	if (n.kind === "lanterns") return $(n.values.findIndex((e) => e > 0));
	if (n.kind === "critters" || n.kind === "rubble") {
		if (n.data.deploy) {
			if (n.kind === "rubble" && (n.data.rubblePlaced ?? 0) < e.players.length * 2) return t.owner === e.leader ? {
				type: "deploy",
				pos: n.values.findIndex((e, t) => t < 8 && !e)
			} : null;
			if (t.pos >= 0) return null;
			let r = Array.from({ length: 4 }, (e, r) => (n.kind === "rubble" || t.ranged ? 12 : 8) + r).find((t) => !e.actors.some((e) => e.pos === t));
			return r === void 0 ? null : {
				type: "deploy",
				pos: r
			};
		}
		if (n.data.enemyTurn) return null;
		if (n.kind === "rubble") return $(n.values.indexOf(Math.max(...n.values)));
		if (n.data.critterSelect) {
			let e = n.values.findIndex((e, t) => e > 0 && t % 4 === n.data.lane), t = e >= 0 ? e : n.values.indexOf(Math.min(...n.values.filter((e) => e > 0))), r = n.values.findIndex((e, n) => e > 0 && J(t, n));
			return $(t, String(r));
		}
		let r = n.values.findIndex((e, n) => e > 0 && (t.ranged || J(t.pos, n))), i = t.dex - (n.data.moved ?? 0);
		return r >= 0 && i && t.attack ? $(r, void 0, Math.min(t.attack, i)) : $(0, "pass");
	}
	return null;
}
function xr(e) {
	let t = e.battle, n = t.reactions[0];
	if (n.startsWith("shield:")) {
		let t = F(e, n.slice(7)), r = Object.keys(t.counters).find((e) => e.startsWith("shield:"));
		return {
			type: "ability",
			ability: "reaction",
			amount: Number(r.slice(7)),
			mode: t.locked.length < 3 ? "locked" : t.active.length < 3 ? "active" : "discard"
		};
	}
	if (n.startsWith("prevent:") || n.startsWith("roundOptics:") || n.startsWith("sling:")) return {
		type: "ability",
		ability: "reaction",
		mode: "use"
	};
	if (n.startsWith("retaliate:")) return {
		type: "ability",
		ability: "reaction",
		mode: "both"
	};
	if (n.startsWith("mischief:")) return {
		type: "ability",
		ability: "reaction",
		slot: F(e, n.slice(9)).active[0]?.uid
	};
	if (n.startsWith("riposte:")) return {
		type: "ability",
		ability: "reaction",
		mode: "use"
	};
	if (n === "nomNext" || n === "lineupNext") return {
		type: "ability",
		ability: "reaction",
		target: I(e).find((e) => e.hp > 0 && e.counters.reserve === (n === "nomNext" ? 99 : 98))?.id
	};
	if (n.startsWith("knockback:") || n.startsWith("club:")) return {
		type: "ability",
		ability: "reaction",
		pos: Ht(e, F(e, n.slice(n.indexOf(":") + 1)).pos)[0]
	};
	if (n === "carelessBomb") return {
		type: "ability",
		ability: "reaction",
		target: R(e).find((e) => e.kind === "baddie" && e.hp === t.pendingDamage.bombHp)?.id
	};
	if (n === "charred") {
		let n = R(e).find((e) => e.definition.startsWith("kobold") && e.hp === t.pendingDamage.charredHp);
		if (!n) return null;
		let r = I(e).filter((e) => e.hp > 0 && e.pos >= 0).sort((e, t) => vr(e.pos, n.pos) - vr(t.pos, n.pos))[0], i = r && Array.from({ length: 16 }, (e, t) => t).find((t) => J(t, r.pos) && !e.actors.some((e) => e.hp > 0 && e.pos === t));
		return {
			type: "ability",
			ability: "reaction",
			target: n.id,
			mode: r?.id,
			pos: i
		};
	}
	if (n === "marrowRetreat") return {
		type: "ability",
		ability: "reaction",
		pos: kt(e, e.actors.find((e) => e.definition === "marrow")).sort((e, t) => vr(e, 2) - vr(t, 2))[0]
	};
	if (n === "limitTarget") return {
		type: "ability",
		ability: "reaction",
		target: t.enemyTargets.find((t) => {
			let n = F(e, t);
			return n && n.hp > 0 && [
				"hp",
				"dex",
				"attack",
				"defense"
			].some((e) => n.counters[e + "Training"] > 0 && !n.effects["limited:" + e]);
		})
	};
	if (n.startsWith("limit:")) {
		let t = F(e, n.slice(6));
		return {
			type: "ability",
			ability: "reaction",
			mode: [
				"attack",
				"defense",
				"dex",
				"hp"
			].find((e) => t.counters[e + "Training"] > 0 && !t.effects["limited:" + e])
		};
	}
	return null;
}
function Sr(e, t, n = !0) {
	if (!n || e.phase === "done") return null;
	let r = ye(e, t), i = e.battle;
	if (e.phase === "recruit") {
		let t = se.find((t) => !I(e).some((e) => e.gearloc === t));
		return t ? {
			type: "chooseGearloc",
			gearloc: t
		} : null;
	}
	if (!r) return null;
	if (e.lock) return e.lock.by === t ? yr(e) : null;
	if (Fe(r) > 4 && e.phase !== "battle" && e.phase !== "challenge") return {
		type: "loot",
		loot: r.inventory[0].uid,
		mode: "discard"
	};
	if (e.challenge.kind === "scout" || e.challenge.kind === "lootChoice" || e.phase === "challenge") return br(e, r);
	if (e.phase === "training") {
		if (!r.training) return { type: "ready" };
		let e = (r.attack < 3 ? [
			"attack",
			"dex",
			"hp",
			"defense"
		] : [
			"dex",
			"attack",
			"hp",
			"defense"
		]).find((e) => !r.failedTraining.includes(e) && r.counters[e + "Training"] < 5);
		if (e) return {
			type: "train",
			stat: e
		};
		let t = ct(r)[0];
		return t ? {
			type: "train",
			stat: "skill",
			skill: t
		} : null;
	}
	if (e.phase === "day") return $(+(e.progress >= te[e.config.tyrant].progress));
	if (e.phase === "encounter") {
		let t = +!![
			"g3",
			"g4",
			"g9",
			"g13",
			"g17",
			"g21",
			"g24",
			"o3",
			"o7",
			"t6"
		].includes(e.encounter ?? "");
		return e.encounter === "t8" && (t = 1), e.encounter === "o7" && !r.inventory.length && (t = 0), e.encounter === "o5" && e.persistent["today:blocked:o5:0"] && (t = 1), $(t, r.id);
	}
	if (e.phase === "recovery") return r.recovery.length ? { type: "ready" } : {
		type: "recover",
		option: "rest"
	};
	if (!i) return null;
	if (i.reactions.length) return xr(e);
	if (i.stage === "deployment") {
		let t = Tt(e, r)[0];
		return t === void 0 ? null : {
			type: "deploy",
			pos: t
		};
	}
	if (i.flags.includes("orderPending")) return { type: "ready" };
	let a = F(e, i.turn ?? "");
	if (!a) return null;
	if (i.startEffects.length) {
		let t = i.startEffects[0], n = a.id, r;
		if (t === "dive") {
			let t = I(e).filter((e) => e.hp > 0 && e.pos >= 0 && !e.effects.untargetable).sort((e, t) => e.hp - t.hp);
			n = t[0]?.id, r = Array.from({ length: 16 }, (e, t) => t).find((n) => t[0] && J(n, t[0].pos, a.diagonal) && !e.actors.some((e) => e.hp > 0 && e.pos === n));
		}
		return {
			type: "ability",
			ability: "startEffect",
			mode: t,
			target: n,
			pos: r
		};
	}
	if (i.stage === "enemyTarget") return {
		type: "ability",
		ability: "target",
		target: jt(e, a)[0]?.id
	};
	if (i.stage === "enemyMove") {
		let t = F(e, i.target ?? ""), n = t && Mt(e, a, t)[0];
		return n === void 0 ? null : {
			type: "move",
			pos: n
		};
	}
	if (a.kind === "ally" && i.stage === "move") {
		let t = R(e).filter((t) => yt(e, a, t)).sort((e, t) => e.hp - t.hp)[0];
		if (t) return {
			type: "ability",
			ability: "allyAttack",
			target: t.id
		};
		let n = kt(e, a).sort((t, n) => Math.min(...R(e).map((e) => vr(t, e.pos))) - Math.min(...R(e).map((e) => vr(n, e.pos))));
		return i.spent < 2 && n.length ? {
			type: "ability",
			ability: "allyMove",
			pos: n[0]
		} : {
			type: "ability",
			ability: "allyEnd"
		};
	}
	if (a !== r || !["move", "resolve"].includes(i.stage)) return null;
	if (Ce(r) >= 6 && !i.backupUsed && !r.upgraded && !i.modifiers.noBackup) return {
		type: "backup",
		cost: 6
	};
	let o = R(e).filter((t) => yt(e, r, t)).sort((e, t) => e.hp - t.hp);
	if (i.stage === "move") {
		let t = Ye(r) - i.spent;
		if (!o.length && !r.ranged && t > _t(e)) {
			let t = kt(e, r), n = R(e);
			if (t.sort((e, t) => Math.min(...n.map((t) => vr(e, t.pos))) - Math.min(...n.map((e) => vr(t, e.pos)))), t[0] !== void 0) return {
				type: "move",
				pos: t[0]
			};
		}
		let n = o.length ? Math.min(Je(r, "attack"), t) : 0, a = Math.min(Je(r, "defense"), Math.max(0, t - n), Math.max(0, 3 - r.active.length));
		i.modifiers.noDefense && (a = 0), (i.modifiers.defenseOnly >= i.round || i.modifiers.meleeDefenseOnly >= i.round && !r.ranged) && (n = 0, a = Math.min(Je(r, "defense"), t, Math.max(0, 3 - r.active.length))), i.modifiers.skillOnly >= i.round && (n = 0, a = 0);
		let s = [];
		return !(i.modifiers.defenseOnly >= i.round || i.modifiers.meleeDefenseOnly >= i.round && !r.ranged) && r.gearloc === "patches" && r.hp < r.maxHp && t > n + a && we(e, r, 1) && r.active.length < 3 && s.push(1), n + a + s.length ? {
			type: "roll",
			attack: n,
			defense: a,
			skills: s,
			target: o[0]?.id ?? null
		} : { type: "endTurn" };
	}
	let s = i.rolled.filter((e) => !e.used && e.kind === "attack" && e.face.startsWith("attack:"));
	if (s.length && F(e, i.target ?? "")?.hp && yt(e, r, F(e, i.target))) return {
		type: "resolve",
		dice: s.map((e) => e.uid),
		mode: "use"
	};
	let c = i.rolled.find((e) => !e.used);
	if (c) {
		let e = me(c.face)[0];
		return [
			"bones",
			"forcedBones",
			"reusableBones"
		].includes(e.kind) ? {
			type: "resolve",
			dice: [c.uid],
			mode: "bones"
		} : e.kind === "defense" && r.active.length < 3 ? {
			type: "resolve",
			dice: [c.uid],
			mode: "active"
		} : e.kind === "heal" || c.skill && r.gearloc && M(r.gearloc, c.skill).grenade ? {
			type: "resolve",
			dice: [c.uid],
			mode: "use",
			target: r.id
		} : {
			type: "resolve",
			dice: [c.uid],
			mode: "discard"
		};
	}
	if (!i.backupUsed && !i.modifiers.noBackup) {
		if (r.gearloc === "tantrum" && Ce(r) >= 5 && r.hp < r.maxHp) return {
			type: "backup",
			cost: 5
		};
		if (r.gearloc === "patches" && Ce(r) >= 2 && r.hp < r.maxHp) return {
			type: "backup",
			cost: 2,
			target: r.id
		};
		if (r.gearloc === "picket" && Ce(r) >= 2 && z(r, "defense") && i.target && o.some((e) => e.id === i.target)) return {
			type: "backup",
			cost: 2,
			target: i.target
		};
		if (r.gearloc === "boomer" && Ce(r) && i.target && o.some((e) => e.id === i.target)) return {
			type: "backup",
			cost: 1,
			target: i.target
		};
	}
	return { type: "endTurn" };
}
var Cr = (e, t) => {
	let n = Sr(e.public, t.rid, !!e.private?.canAct);
	return n ? { action: n } : null;
};
//#endregion
//#region src/games/toomanybones/endgame-review.tsx
function wr({ board: e, renderResult: t, ...n }) {
	let s = c(), [l, u] = o(!0), [d, h] = o(null), g = a(null), _ = a(null), b = a(null);
	r(() => {
		if (!d) return;
		b.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => h(null), 5e3);
		return () => clearTimeout(e);
	}, [d]);
	let x = (e) => {
		h(null), u(e), requestAnimationFrame(() => (e ? g : _).current?.focus({ preventScroll: !0 }));
	}, S = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => h({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => h({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => h({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), ee = {
		...n,
		...S
	};
	return /* @__PURE__ */ p("div", {
		className: "toomanybones-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ f("div", {
				className: "toomanybones-endgame-board",
				inert: l,
				children: e
			}),
			/* @__PURE__ */ f("div", {
				className: "toomanybones-endgame-overlay",
				hidden: !l,
				children: /* @__PURE__ */ p("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), x(!1));
					},
					className: "toomanybones-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ p("header", {
							className: "toomanybones-endgame-heading",
							children: [/* @__PURE__ */ p("div", {
								className: "toomanybones-endgame-brand",
								children: [/* @__PURE__ */ f("span", {
									"aria-hidden": "true",
									children: Pn.icon
								}), s(Pn.nameKey)]
							}), /* @__PURE__ */ f("button", {
								type: "button",
								ref: g,
								className: "btn-quiet",
								"aria-label": s("games.toomanybones.reviewHide"),
								title: s("games.toomanybones.reviewHide"),
								onClick: () => x(!1),
								children: /* @__PURE__ */ f(v, { size: 19 })
							})]
						}),
						/* @__PURE__ */ f("div", {
							className: "toomanybones-endgame-result",
							inert: d !== null,
							children: t(ee)
						}),
						d && /* @__PURE__ */ p("div", {
							className: "toomanybones-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || h(null);
							},
							children: [/* @__PURE__ */ f("button", {
								type: "button",
								ref: b,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = d.run;
									h(null), e();
								},
								children: s(d.label === "again" ? "games.toomanybones.reviewConfirmAgain" : "games.toomanybones.reviewConfirmLobby")
							}), /* @__PURE__ */ f("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									h(null), g.current?.focus({ preventScroll: !0 });
								},
								children: s("games.toomanybones.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ f("div", {
				className: "toomanybones-endgame-toolbar",
				hidden: l,
				children: /* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-base",
					ref: _,
					onClick: () => x(!0),
					children: [
						/* @__PURE__ */ f(y, { size: 18 }),
						s("games.toomanybones.reviewShow"),
						/* @__PURE__ */ f(m, { size: 18 })
					]
				})
			})
		]
	});
}
function Tr({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: l, rows: u, renderRowExtra: m, summary: g, navigation: _, content: y, afterRanking: S, scoreUnit: ee, rankOf: C }) {
	let w = c(), te = s((e) => e.locale), [T, E] = o({}), D = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? b(n, te) : e;
	}, ne = (t, n) => C?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), O = e.ranking.some((t) => e.scores?.[t] !== void 0), k = (t, n) => /* @__PURE__ */ p("div", {
		className: "toomanybones-score-identity",
		children: [
			/* @__PURE__ */ p("span", {
				className: "toomanybones-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ f("span", {
					"aria-label": w("games.toomanybones.reviewWinner"),
					children: "♛ "
				}), O && ne(t, n)]
			}),
			/* @__PURE__ */ p("span", {
				className: "toomanybones-score-name",
				children: [D(t), t === r && /* @__PURE__ */ f("small", { children: w("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ p("small", {
				className: "toomanybones-score-autopilot",
				children: [
					/* @__PURE__ */ f(h, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), A = (t) => e.ranking.map((n) => /* @__PURE__ */ f("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ p("div", {
		className: "toomanybones-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ f(x, {}),
			_,
			/* @__PURE__ */ p("div", {
				className: "toomanybones-score-body",
				children: [
					g && /* @__PURE__ */ f("div", {
						className: "toomanybones-score-summary",
						children: g
					}),
					i !== void 0 && /* @__PURE__ */ f("p", {
						className: "toomanybones-score-hints",
						children: w("session.hint.usedCount", { n: i })
					}),
					y ?? (u?.length ? /* @__PURE__ */ f("div", {
						className: "toomanybones-score-table-scroll",
						children: /* @__PURE__ */ p("table", {
							className: "toomanybones-score-table",
							"aria-label": w(Pn.nameKey),
							children: [
								/* @__PURE__ */ f("thead", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", { scope: "col" }), /* @__PURE__ */ f(d, { children: e.ranking.map((t, n) => /* @__PURE__ */ f("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: k(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ f("tbody", { children: u.map((e, t) => /* @__PURE__ */ p(n, { children: [/* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ p("button", {
										type: "button",
										"aria-expanded": !!T[t],
										onClick: () => E((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ f(v, { size: 15 }), e.label]
									}) : e.label
								}), A(e)] }), T[t] && e.details?.map((e, t) => /* @__PURE__ */ p("tr", {
									className: "toomanybones-score-sub",
									children: [/* @__PURE__ */ f("th", {
										scope: "row",
										children: e.label
									}), A(e)]
								}, t))] }, t)) }),
								O && /* @__PURE__ */ f("tfoot", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", {
									scope: "row",
									children: w("games.toomanybones.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ f("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ f("ol", {
						className: "toomanybones-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ p("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ p("div", {
								className: "toomanybones-score-rankline",
								children: [k(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ p("strong", {
									className: "toomanybones-score-points",
									children: [e.scores[t], ee && /* @__PURE__ */ f("small", { children: ee })]
								})]
							}), m?.(t)]
						}, t))
					})),
					S,
					!!u?.length && m && /* @__PURE__ */ f("div", {
						className: "toomanybones-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ p("details", { children: [/* @__PURE__ */ f("summary", { children: D(e) }), m(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ p("footer", {
				className: "toomanybones-score-actions",
				children: [
					l && /* @__PURE__ */ f("button", {
						type: "button",
						className: "btn-quiet",
						onClick: l,
						children: w("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ f("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: w("session.result.playAgain")
					}),
					!a && !l && /* @__PURE__ */ f("p", { children: w("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/toomanybones/game-over.tsx
function Er(e) {
	return /* @__PURE__ */ f(Tr, {
		...e,
		accent: Pn.accent
	});
}
function Dr(e) {
	return /* @__PURE__ */ f(wr, {
		...e,
		board: /* @__PURE__ */ f(pr, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ f(Er, { ...e })
	});
}
//#endregion
//#region src/games/toomanybones/options.tsx
function Or({ value: e, onChange: t }) {
	let n = c(), r = Sn.safeParse(e), i = r.success ? r.data : Sn.parse(void 0);
	return /* @__PURE__ */ p("div", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ f(ee, {
			title: n("games.toomanybones.tyrant"),
			columns: 2,
			children: Object.keys(Vn).map((e) => /* @__PURE__ */ f(S, {
				name: "tmb-tyrant",
				value: e,
				checked: i.tyrant === e,
				label: n(Vn[e]),
				accent: Pn.accent,
				onChange: () => t({
					...i,
					tyrant: e
				})
			}, e))
		}), /* @__PURE__ */ f(ee, {
			title: n("games.toomanybones.difficulty"),
			columns: 3,
			children: [
				"adventurer",
				"heroic",
				"legendary"
			].map((e) => /* @__PURE__ */ f(S, {
				name: "tmb-difficulty",
				value: e,
				checked: i.difficulty === e,
				label: n(e === "adventurer" ? "games.toomanybones.adventurer" : e === "heroic" ? "games.toomanybones.heroic" : "games.toomanybones.legendary"),
				accent: Pn.accent,
				onChange: () => t({
					...i,
					difficulty: e
				})
			}, e))
		})]
	});
}
//#endregion
//#region src/games/toomanybones/guide.tsx
function kr() {
	return /* @__PURE__ */ f(ar, {});
}
//#endregion
//#region src/games/toomanybones/locales/encounters.ts
var Ar = {
	s1: ["① 最后训练：每人获得2个训练点。\n② 敲诈商贩：每人获得1个训练点，抽2张普通战利品并保留1张。", "1. Last-minute improvement: each Gearloc gains 2 training points.\n2. Shady peddler: each gains 1 training point; draw 2 Loot each and keep 1."],
	s2: ["① 向守卫求助：进行标准战斗，每轮开始箭雨对每名敌人造成1点真实伤害。\n② 展示实力：进行标准战斗，额外获得1个训练点。失败则把本遭遇放回牌堆顶。", "1. Hail the guards: standard BQ; arrows deal 1 True Damage to every baddie at each round start.\n2. Show Obendar: standard battle; gain an extra training point. On either loss, return this Encounter to the top."],
	s3: ["① 伪装平民：每人投D6；出现1或2，将牌堆中第一张暴君遭遇放到顶端。额外获得1进度和1训练点。\n② 雇用莫尔诺：每人获得1张珍宝，将特殊遭遇006洗入牌堆。", "1. Walk like a commoner: roll a D6 per member; any 1–2 moves the first Tyrant Encounter to the top. Gain 1 extra progress and training.\n2. Hire the Mohlnor: gain a Trove Loot each; shuffle Special 006 into the deck."],
	s4: ["① 逃跑：投D6；1–3时每人受到2伤害，4–6时全队弃置1张战利品。将本牌洗回牌堆，另抽今天的遭遇。\n② 迎战：标准敌人队列末尾增加一名20点敌人，入场时增加3生命。成功获得2进度、2训练点和每人1珍宝。", "1. Duck and cover: D6 1–3 deals 2 Damage to each member; 4–6 discards 1 party Loot. Reshuffle this card and draw another today.\n2. Fight: standard BQ plus a 20Pt at the bottom with +3 starting HP. Earn 2 progress, 2 training and a Trove each."],
	s5: ["① 珍宝室：每人抽1珍宝，可以弃置再抽1张且必须保留，随后可立即尝试开锁。获得1训练点。\n② 作战室：获得2训练点，这次攻击与防御训练忽略全部Bones。", "1. Trove room: each draws a Trove, may discard and redraw once, then may immediately attempt lockpicking. Gain 1 training.\n2. War room: gain 2 training; these Attack and Defense training attempts ignore all Bones."],
	s6: ["① 飞镖挑战：每人参赛；胜者抽2战利品，败者弃置1战利品。本遭遇洗回牌堆。\n② 拒绝游戏：标准战斗，开战时每人受到等于队伍人数的伤害。失败洗回本遭遇。", "1. Dangerous Darts: each competes; winners draw 2 Loot, losers discard 1 if able. Reshuffle this Encounter.\n2. No more games: standard BQ; each takes party-size Damage at battle start. Reshuffle this card on failure."],
	g1: ["① 对抗沼泽生物：敌人点数增加3（1–2人）或6（3–4人），尽可能使用沼泽类。额外1进度。\n② 穿过沼泽：标准战斗；每人投D6，当前生命不大于结果则以中毒2开始战斗。", "1. Fight bog creatures: add 3 Baddie Points (1–2 players) or 6 (3–4); use as many Bog baddies as possible. Extra 1 progress.\n2. Wade through: standard BQ; each rolls D6. Current HP must exceed it or start with Poison 2."],
	g2: ["① 对抗巨龙：标准队列顶增加一条5点龙（1–2人）或20点龙（3–4人）。击败20点龙后洗入特殊遭遇005。额外1训练点。\n② 低头前进：标准战斗；每轮开始所有角色受到1点真实伤害。", "1. Fight the dragon: add a 5Pt dragon (1–2 players) or 20Pt dragon (3–4) atop standard BQ. Defeat a 20Pt dragon to shuffle Special 005 in. Extra 1 training.\n2. Keep heads down: all Gearlocs take 1 True Damage each round start."],
	g3: ["① 迎战：每有一名初始生命至少5的敌人入场，向队列末尾增加一名1点敌人。额外2训练点。\n② 虚张声势：先抽1珍宝，指定角色尝试开锁一次；失败弃置，成功保留。然后进行标准战斗。", "1. Have fun: whenever a baddie with at least 5 HP enters, add a 1Pt baddie to the bottom. Extra 2 training.\n2. Call the bluff: draw a Trove and let one Gearloc attempt its locks; keep if opened, otherwise discard. Then standard battle."],
	g4: ["① 解开脚镣：全队依次尝试3机关、4绊线、5蛮力、2绊线锁，进度共享。开锁数至少等于人数则获得突袭；否则每人受2伤害并改选②。\n② 负手作战：本场忽略攻击训练属性。", "1. Escape: attempt shared locks 3L–4T–5F–2T in party order. Open at least party-size locks for Surprise; otherwise each takes 2 Damage and must choose option 2.\n2. Hands tied: ignore trained Attack stats for this battle."],
	g5: ["① 放走蜥蜴：和平成功。\n② 救它：标准队列顶增加两名1点敌人（1–2人）或两名5点敌人（3–4人），全队突袭；额外1训练点和每人1战利品。", "1. Back away: peaceful success.\n2. Save the lizard: add two 1Pt baddies (1–2 players) or two 5Pt (3–4) atop BQ; party has Surprise. Extra training and Loot each."],
	g6: ["① 沼泽：每人敏捷上限3；每轮开始投D6，1–3时全队受1真实伤害。\n② 林间路：每人开战前可投全部防御骰，Bones弃置；远程敌人每次多投1攻击骰。", "1. Bog: cap Dex at 3; D6 at round start, 1–3 deals 1 True Damage to all Gearlocs.\n2. Quiet path: roll Defense dice before battle, discarding Bones; ranged baddies roll +1 Attack."],
	g7: ["① 单列：双方只能使用第一路线，先填近战格再填远程格，禁止移动；额外1进度。\n② 挣扎：每人敏捷减少1；每回合首次移动前投D6，1–3则本回合不能移动；额外1训练点。", "1. Single file: use Lane 1 only, melee before ranged, no movement. Extra progress.\n2. Struggle: each loses 1 Dex; before moving, D6 1–3 prevents movement that turn. Extra training."],
	g8: ["① 充当沙包：队列顶增加一名5点敌人（1–2人）或两名5点敌人（3–4人）；每人额外2战利品。\n② 穿上战靴：敌人点数减少2；全队额外1战利品。", "1. Punching bags: add one 5Pt (1–2 players) or two 5Pt (3–4) atop BQ. Extra 2 Loot each.\n2. Boots: subtract 2 Baddie Points; extra 1 party Loot."],
	g9: ["① 狙击：指定角色投任意数量攻击骰；总伤害至少2则敌人点数减少2，否则改选②。本场减少该角色等量攻击骰。额外每人1战利品。\n② 放行：第2–5轮开始各向队列末尾增加1点敌人。", "1. Snipe: one Gearloc rolls any number of Attack dice; 2+ Damage subtracts 2 Baddie Points, otherwise choose option 2. Rolled dice are unavailable this battle. Extra Loot each.\n2. Let go: add a 1Pt baddie at the start of rounds 2–5."],
	g10: ["选择1–6并投D6。结果大于选择值：抽等量战利品；否则敌人点数增加选择值。随后战斗。", "Choose 1–6 and roll D6. Above the choice draws that many Loot; otherwise add the chosen number to Baddie Points. Then battle."],
	g11: ["① 正面冲锋：必须消灭全部近战敌人后，才能选远程敌人为目标。\n② 保持距离：前两轮近战角色只能投防御骰。", "1. Charge: defeat all melee baddies before targeting ranged baddies.\n2. Keep distance: melee Gearlocs may only roll Defense dice in rounds 1–2."],
	g12: ["① 追逐闪光：敌人点数增加6（1–2人）或12（3–4人）；全队额外2珍宝。\n② 不拒绝蛋糕：全队获得突袭。", "1. Shiny: add 6 Baddie Points (1–2 players) or 12 (3–4); extra 2 party Troves.\n2. Cake: party has Surprise."],
	g13: ["① 贿赂：全队弃置与人数相同的战利品；洗入特殊遭遇006，和平成功。\n② 旋风测试：指定一名角色在5轮内击破四个不行动的目标，生命依次3、5、4、4；额外每人1战利品。", "1. Bribe: discard party-size Loot; shuffle Special 006 in; peaceful success.\n2. Whirlwind: one Gearloc has 5 rounds to defeat four stationary non-attacking figures with 3, 5, 4, 4 HP. Extra Loot each."],
	g14: ["① 跟踪伏击：先战两名5点敌人；获胜后再战标准敌人点数减8。必须两战皆胜。\n② 黄昏进攻：投两次D6，将总和加到敌人点数；全队获得突袭。额外1训练点。", "1. Follow: fight two 5Pt baddies, then standard Baddie Points minus 8; must win both.\n2. Dusk: add the sum of two D6 to Baddie Points; party has Surprise. Extra training."],
	g15: ["① 设置陷阱：队列顶增加两名1点敌人（1–2人）或两名5点敌人（3–4人）；敌人入场失去2生命。\n② 吹响号角：顶增两名1点及一名5点（1–2人），或三名5点（3–4人）；成功后可选全部恢复项目。额外每人1珍宝。", "1. Traps: add two 1Pt (1–2 players) or two 5Pt (3–4) atop BQ; baddies lose 2 HP on entry.\n2. Horn: add two 1Pt and a 5Pt (1–2) or three 5Pt (3–4); on success choose all recovery options. Extra Trove each."],
	g16: ["① 拆弹：敌人获得突袭；指定角色尝试4机关、3绊线锁。失败则改选②且仍保留敌方突袭。额外1训练点。\n② 中计：投D6，当前生命最接近结果的角色失去3生命；平手由全队选择。", "1. Disarm: baddies have Surprise; one Gearloc attempts 4L–3T. Failure forces option 2, retaining baddie Surprise. Extra training.\n2. Trap: D6; the Gearloc with HP closest to the result loses 3 HP, party breaks ties."],
	g17: ["① 单挑：队列首名敌人与指定角色先战3轮，或直至一方倒下，其余单位再加入。\n② 一拥而上：敌人点数增加4（1–2人）或8（3–4人）。", "1. Duel: the first baddie faces one chosen Gearloc for 3 rounds or until either falls, then others join.\n2. Take him: add 4 Baddie Points (1–2 players) or 8 (3–4)."],
	g18: ["① 深入洞穴：每名角色增加一名5点敌人在队列末尾，额外1珍宝。\n② 清哨兵：敌人点数增加6，再每人增加一名1点敌人在末尾，额外1训练点。\n③ 侦察返回：揭示两名敌人，可放至各自牌堆底；本牌放回顶端，没有遭遇奖励。", "1. Rabbit hole: add a 5Pt per Gearloc to BQ bottom; extra Trove.\n2. Sentries: add 6 points, then a 1Pt per Gearloc to BQ bottom; extra training.\n3. Scout: reveal two baddies, optionally cycle; return this card to top, no rewards."],
	g19: ["① 棍石作战：不能使用技能骰，投出的每个Bones计作2个。\n② 寻找窃贼：第一路线的首名敌人倒下前，不能使用技能骰。", "1. Sticks and stones: no skill dice; each rolled Bone counts as two.\n2. Find thieves: no skill dice until the first baddie in Lane 1 is defeated."],
	g20: ["① 当场作战：整场不能使用防御骰。\n② 躲入树林：前两轮只能投防御骰。", "1. Fight now: no Defense dice this battle.\n2. Woods: roll only Defense dice for the first two rounds."],
	g21: ["① 四散奔逃：顶增一名20点敌人；全队共同耗尽1–6颗攻击及防御骰。每轮D6不大于耗尽数时眩晕该敌人。成功洗入特殊遭遇005。额外1训练点和每人1珍宝。\n② 逃跑：开战前每人受到2伤害。", "1. Scatter: add a 20Pt atop BQ; exhaust the same chosen 1–6 Attack/Defense dice per Gearloc. Each round, D6 at or below the total stuns that 20Pt. On success shuffle Special 005 in; extra training and Trove each.\n2. Run: each takes 2 Damage before battle."],
	g22: ["① 藏宝图：顶增一名20点敌人；额外1训练点和每人1珍宝。\n② 火攻：顶增一名20点敌人；每轮结束所有敌人受到2真实伤害；额外1训练点。任一选项成功均洗入特殊遭遇005。", "1. Map: add a 20Pt atop BQ; extra training and Trove each.\n2. Fire: add a 20Pt atop BQ; all baddies take 2 True Damage each round end; extra training. Either success shuffles Special 005 in."],
	g23: ["① 箭矢弹射：指定角色有4次弹射机会，每路线各一次。至少命中3个树目标，且目标不能被撞离桌面；获得1进度和2训练点。\n② 飞镖：每人挑战，至少一人胜利才获得1进度；胜者各获得1战利品。洗入特殊遭遇006。", "1. Flick arrows: one Gearloc has 4 shots, one per lane. Hit at least 3 tree targets without knocking them off the table; earn 1 progress and 2 training.\n2. Darts: each competes; any win earns 1 progress, each winner gains Loot. Shuffle Special 006 in."],
	g24: ["① 开锁挑战：找到至少有一道难度5的珍宝，全队依次尝试，已打开的锁保留；全部打开才成功，获得每人2战利品及1珍宝。\n② 飞镖：每人挑战，至少一人胜利获得1进度，胜者各1战利品。", "1. Locks: find a Trove with a lock difficulty at least 5; each attempts, opened locks persist. Fully open to succeed; extra 2 Loot and a Trove each.\n2. Darts: each competes; any win earns 1 progress, each winner gains Loot."],
	g25: ["老鼠数量为人数加1，各投D6决定生命。每名角色可正常行动1回合；消灭至少全部减一只即成功，若全部消灭，再洗入特殊遭遇004。", "Face party-size plus 1 rats, each with D6 HP. Each Gearloc gets one normal battle turn. Kill all but one to succeed; killing all shuffles Special 004 in."],
	g26: ["① 珍宝箱：指定角色尝试打开新珍宝，成功保留，失败弃置；遭遇始终成功。\n② 木桶：选择1–4桶，投D6决定各自生命，由强到弱排列。每人投全部攻击骰，只攻击最强的一桶；每打破一桶，全队获得1战利品，遭遇始终成功。", "1. Trove: one Gearloc attempts a new Trove; keep if opened, discard otherwise. Encounter always succeeds.\n2. Barrels: choose 1–4, roll D6 HP each, strongest first. Each Gearloc rolls all Attack against one barrel. Gain 1 party Loot per destroyed barrel; always succeeds."],
	g27: ["每人投D6生成一盏灯的距离。每人选择一盏灯投自己的先攻骰，结果不小于距离则熄灭；每熄灭一盏，全队获得1战利品。遭遇始终成功。", "Roll D6 per Gearloc for lantern distances. Each chooses a lantern and rolls their Initiative die; meet its distance to extinguish it. Each extinguished lantern grants party Loot. Always succeeds."],
	g28: ["放置角色，其余格各1生命小动物。动物先行动，随后与角色交替；D6决定路线，5视作1、6视作2。动物堆叠相邻动物，否则离场。角色只用攻击与敏捷追捕，必须一击击败，否则目标逃跑；捕获生命作为下一战临时生命。", "Deploy Gearlocs; fill other positions with 1HP critters. Critters act first, alternating with Gearlocs. D6 selects lane (5→1, 6→2); a critter stacks onto an adjacent critter or leaves. Hunt with Attack and Dex only; kill in one attempt or it escapes. Captured HP becomes next-battle Buff HP."],
	g29: ["每人放置两堆3生命碎石于敌方区域，角色处于远程起始格。每人可投掷两次炸药：选任意格投2攻击骰，对目标格造成全部伤害、相邻格造成一半伤害向下取整。清除全部碎石才成功。", "Place two 3HP rubble piles per Gearloc on baddie positions and Gearlocs at ranged starts. Each has two explosives: roll 2 Attack at any position; full Damage there, half rounded down to adjacent positions. Clear all rubble to succeed."],
	g30: ["全队交出最多4战利品，每张投D6；单人每张投2颗。总和0失去1进度；1–6获1进度1训练；7–12获1进度2训练；13–18再获1珍宝；19以上再获2珍宝。", "Pay up to 4 party Loot, rolling D6 each (two per Loot solo). Total 0 loses 1 progress; 1–6 earns 1 progress/1 training; 7–12 earns 1 progress/2 training; 13–18 also gains 1 Trove; 19+ also gains 2 Troves."],
	o1: ["① 排队作战：标准点数加2，只用第一路线，一次只对抗一名敌人；额外2战利品。\n② 切断吊桥：揭示标准队列，每名远程敌人投2攻击骰并失去等量生命；存活即成功。", "1. Line up: Baddie Points +2, Lane 1 only, one baddie at a time; extra 2 Loot.\n2. Cut the bridge: reveal standard BQ; roll 2 Attack for each ranged baddie and lose that much HP. Survive to succeed."],
	o2: ["① 空地迎战：标准点数加2，远程敌人在先攻最顶端；额外1进度和1训练点。\n② 爬上绳索：标准点数加2，己方突袭，敌人第一轮不能移动；额外1训练点。", "1. Open air: points +2; ranged baddies start atop initiative; extra progress and training.\n2. Climb: points +2; Surprise and baddies cannot move in round 1; extra training."],
	o3: ["① 立即作战：只对抗一名5点魔像。\n② 引向袭击者：标准战斗，先用20点魔像替代角色战斗3轮，然后角色入场，魔像转为敌人；额外1训练点和每人1珍宝。", "1. Fight now: one 5Pt golem.\n2. Lead to raiders: standard BQ; control a 20Pt golem for 3 rounds instead of your Gearloc. Then deploy the Gearloc and turn the golem hostile; extra training and a Trove."],
	o4: ["① 找武器：对抗一名1点狼和一名5点狼，前两轮不能使用技能骰。\n② 找背包：同样敌人，前两轮只能使用技能骰。", "1. Find weapon: fight a 1Pt and 5Pt wolf; no skills for rounds 1–2.\n2. Find pack: same baddies; only skill dice for rounds 1–2."],
	o5: ["① 开锁逃走：尝试3蛮力、2机关锁；成功弃置原有全部战利品并获得2张新的，失败失去2生命并改选②。\n② 欺骗巨魔：失去3生命，本晚恢复阶段不能治疗。", "1. Pick locks: 3F–2L; success discards all current Loot and draws 2 new Loot. Failure loses 2 HP and forces option 2.\n2. Trick trolls: lose 3 HP and cannot heal in tonight’s recovery."],
	o6: ["① 充当诱饵：两名5点敌人，入场投D6，3–6则眩晕前两轮。\n② 自己设伏：两名5点敌人，己方突袭，敌人每次移动及入场受1真实伤害。", "1. Bait: two 5Pt baddies; D6 on entry, 3–6 stuns for first two rounds.\n2. Trap: two 5Pt baddies; Surprise, baddies take 1 True Damage on every movement including entry."],
	o7: ["① 固守：标准战斗，第3–5轮末投D6，1–3时队列末尾增加1点敌人；额外1训练点及2战利品。\n② 供品：弃置1战利品，投D6；4–6和平成功，1–3重新选择遭遇方案；额外1训练点。", "1. Stand: standard BQ, at ends of rounds 3–5, D6 1–3 adds a 1Pt to BQ bottom; extra training and 2 Loot.\n2. Offer: discard Loot; D6 4–6 succeeds peacefully, 1–3 choose again; extra training."],
	o8: ["① 留一天：标准队列增加5点敌人，获得本场5临时生命；额外1训练点1战利品。\n② 装水离开：获得可在战斗内外使用的2生命治疗，额外1训练点。", "1. Stay: add a 5Pt to standard BQ; gain 5 Buff HP this battle; extra training and Loot.\n2. Bottle water: keep a 2HP heal usable in or out of battle; extra training."],
	o9: ["① 袭击：队列顶增5点敌人，所有敌人初始生命减少2；额外2战利品。\n② 保护商人：顶增5点敌人，控制4生命、2攻击、2移动的商人于角色回合后行动；商人必须存活，成功移除特殊遭遇006；额外每人1珍宝。", "1. Attack: add a 5Pt atop BQ; all baddies start at -2 HP; extra 2 Loot.\n2. Defend trader: add a 5Pt; control a 4HP/2Atk/2Move melee trader after your turn. Trader must survive; remove Special 006 on success; extra Trove."],
	o10: ["① 抢武器：第一路线首名敌人攻击减少2，角色本场攻击增加1，前两轮不能用技能。\n② 抢装备：第一轮不能用技能。", "1. Grab weapon: first Lane 1 baddie has -2 Attack, Gearloc has +1 Attack; no skills in rounds 1–2.\n2. Gear: no skills in round 1."],
	o11: ["① 砍杀：标准点数只用1点敌人；前三轮倒下的敌人回到队列末尾。\n② 游击：只战两名5点近战敌人；每次攻击后可免费移动最多3格。", "1. Hack and slash: points in 1Pt baddies only; baddies defeated in rounds 1–3 return to BQ bottom.\n2. Kite: two 5Pt melee baddies; move up to 3 positions free after attacking."],
	o12: ["① 拒绝同伴：永久生命属性减少1，和平成功。\n② 接受同伴：选3颗技能骰，下次战斗开始时耗尽，和平成功。", "1. Refuse: permanently reduce Health Stat by 1; peaceful success.\n2. Accept: choose 3 skill dice to exhaust at next battle start; peaceful success."],
	t1: ["① 迎战Nom：标准队列增加两名1点（1–2人）或5点（3–4人）敌人，Nom位于队列顶。Nom在第三轮末或生命降至5时离场，仍须击败其他敌人。\n② 退避：每人失去2生命并跳过恢复，本牌洗回牌堆。", "1. Face Nom: add two 1Pt (1–2 players) or 5Pt (3–4) to standard BQ with Nom on top. Nom leaves after round 3 or at 5 HP; defeat remaining baddies.\n2. Back away: each loses 2 HP, skip recovery, reshuffle this card."],
	t3: ["标准战斗。敌人入场后，在空闲敌方远程格放置人数乘3生命的能量球。每轮结束对不与其相邻的敌对单位造成1伤害；击败球和敌人才成功。此后暴君战能量球只有3生命。", "Standard BQ. After deployment place an Orb with 3 HP per Gearloc on an open baddie ranged position. At round end it deals 1 Damage to non-adjacent opposing units. Destroy it and baddies. Future Tyrant Orbs start at 3 HP."],
	t4: ["① 没有备用方案：标准战斗，不能使用备用计划。\n② 另类方案：标准战斗，每个角色投出的Bones使能量球对该角色造成1伤害。额外1训练点。", "1. No Plan B: standard battle, no Backup Plans.\n2. Plan C: standard battle; each Bone a Gearloc rolls causes 1 Damage to that Gearloc. Extra training."],
	t6: ["① 迎战：标准队列顶增加一名5点野兽（1–2人）或两名5点野兽（3–4人）；额外每人1战利品。\n② 友好伸手：指定角色投D6，1–2永久生命减少3但不低于初始值；3–6无事，和平成功。额外1训练点。", "1. Fight: add one 5Pt Beast (1–2 players) or two (3–4) atop BQ; extra Loot each.\n2. Offer hand: chosen Gearloc rolls D6; 1–2 permanently loses 3 max HP, no lower than starting Health; 3–6 harmless. Peaceful success, extra training."],
	t7: ["尽可能用野兽组成标准队列。角色只放己方近战格，敌人先放己方远程格；敌人突袭，之后入场恢复正常规则。", "Standard BQ with as many Beasts as possible. Deploy Gearlocs in Gearloc melee and baddies in Gearloc ranged positions; baddies have Surprise. Later entries use normal positions."],
	t8: ["① 帮助Duster：全队用战利品提供合计人数乘2的治疗；和平成功，额外1训练点。\n② 怀疑陷阱：标准战斗。", "1. Help Duster: provide 2 HP healing per party member using Loot; peaceful success, extra training.\n2. Suspect a trap: standard battle."],
	t10: ["在当前或已击败敌人中找一名狼、枭熊或狮鹫，1–2人找1点、3–4人找5点。将它留作暴君战的额外敌人。将本牌洗回，另抽今天的遭遇。", "Find a wolf, owlbear or griffin from Active/Defeated stacks: 1Pt for 1–2 players, 5Pt for 3–4. Reserve it for the Tyrant battle. Reshuffle this card and draw another today."],
	t12: ["① 收集材料：选择六名1点或三名5点敌人，获胜后本牌洗回；获得2训练点。\n② 制作解毒剂：已击败敌人中须有沼泽蝌蚪或蛙、沼泽潜伏者、石魔像、泥魔像各一种。获得持续免疫暴君的毒性增强、1进度和1训练点。", "1. Ingredients: fight six 1Pt or three 5Pt baddies; reshuffle on completion; gain 2 training.\n2. Antidote: defeated stack must contain bog pole/frog, bog lurk, stone golem and clay golem. Gain immunity to Tyrant Poison Enhancer, 1 progress and 1 training."],
	t14: ["标准队列尽可能使用兽人。前三轮被击败的兽人回到队列末尾。", "Use as many Orcs as possible in standard BQ. Orcs defeated in rounds 1–3 return to the bottom."],
	t15: ["① 对抗沼泽类。\n② 对抗鳞族。\n只使用所选类型组成标准点数队列，成功后该类型从本次冒险的当前与已击败牌堆中移除。", "1. Fight Bog.\n2. Fight Scales.\nBuild standard Baddie Points using only that type. On success remove that type from Active and Defeated stacks for this adventure."],
	t17: ["① 忽略炸弹：标准战斗。\n② 拆弹：每人选择锁类型并尝试达到3；全员成功可在最终战开场立即炸毁王座，失败则开战前全队受2伤害。随后标准战斗。", "1. Ignore: standard battle.\n2. Disarm: each names a lock type and attempts difficulty 3. All succeed to destroy the throne at final-battle start; otherwise each takes 2 Damage before battle. Then standard BQ."],
	t18: ["标准队列顶增加一名1点哥布林（1–2人）或5点哥布林（3–4人）。此后每次标准敌人点数战斗，额外加入最近被击败的哥布林。", "Add a 1Pt Goblin (1–2 players) or 5Pt Goblin (3–4) atop BQ. Persistently add the most recently defeated Goblin to every future standard Baddie Points battle."]
}, jr = Object.fromEntries(Object.entries(Ar).map(([e, t]) => [e, t[0]])), Mr = Object.fromEntries(Object.entries(Ar).map(([e, t]) => [e, t[1]])), Nr = [
	["获得元素并锁定；每次合成消耗一个元素、弹壳和引信。", "Lock Element components; crafting spends one Element, Casing and Fuse."],
	["获得弹壳并锁定，剩余数量跨战斗保留。", "Lock Casing components; unused components persist between battles."],
	["获得引信并锁定，剩余数量跨战斗保留。", "Lock Fuse components; unused components persist between battles."],
	["炸弹库存计数骰，不能投掷；最多储存三个炸弹。", "Grenade counter; never rolled. Store at most three grenades."],
	["预先选择落点，消耗一个炸弹；命中单位承受全额伤害，相邻单位承受向下取整的一半伤害。", "Declare an aim and spend a grenade. Deal full damage on that position and half, rounded down, to adjacent units."],
	["消耗一个炸弹，对所有敌人造成伤害；反冲结果同时伤害所有队员。", "Spend a grenade to damage every baddie; Party Backlash also damages all party members."],
	["预先瞄准友方角色并消耗一个炸弹；烟幕使其下几次被敌人选为目标时免受攻击和技能。", "Aim at a Gearloc and spend a grenade. Smoke cancels the next indicated number of enemy attacks and skills targeting them."],
	["消耗一个炸弹，移除全队负面状态；持续期间阻止新的负面状态，自己回合开始时减少剩余回合。", "Spend a grenade to clear party negative effects and prevent new ones. Reduce duration at the start of your turn."],
	["预先瞄准并消耗一个炸弹；眩晕点数不高于骰面的敌人，使其失去下次回合。", "Aim and spend a grenade. Stun a non-Tyrant whose points do not exceed the result; it misses its next turn."],
	["预先瞄准并消耗一个炸弹；目标每次回合开始承受燃烧伤害，持续骰面回合数；反冲伤害自己。", "Aim and spend a grenade. Napalm damages the baddie at turn start for the indicated rounds; Backlash damages you."],
	["预先瞄准并消耗一个炸弹；禁用点数不高于骰面的敌人技能，持续本场战斗。", "Aim and spend a grenade. Disable skills on a baddie at or below the result for this battle."],
	["消耗品；获得完整炸弹，或分配所示数量的元素、弹壳与引信。", "Consumable: gain grenades or allocate the indicated components among Element, Casing and Fuse."],
	["至少有一名敌人倒下后才能投掷；获得临时生命、战利品或可分配零件。", "Roll only after a baddie has been defeated. Gain Buff HP, Loot or components."],
	["本场战斗的破片炸弹和大爆炸伤害增加骰面数值。", "Increase Frag and Big Boom damage by the result for this battle."],
	["获得神圣手榴弹、炸弹或锁定元素325；也可能获得两个Bones。", "Gain a Holy Hand Grenade, grenade or locked Element 325; may instead yield two Bones."],
	["消耗品，不消耗炸弹库存；必须结算。若使用元素325，采用强化伤害并耗尽元素325。", "Consumable, costs no grenade and must resolve. Element 325 replaces normal damage with enhanced damage and is exhausted."]
], Pr = [
	["治疗一名存活角色，不能超过生命上限。", "Heal a living Gearloc up to their maximum HP."],
	["立即使用或锁定；选择未使用的医疗包或大医疗包骰，使其治疗数值乘以骰面倍数。", "Use instantly or lock; multiply an unused Med Kit or Med Pack result."],
	["对已宣告的相邻目标造成伤害。", "Damage your declared adjacent target."],
	["消耗品；可先放在存活角色主动槽，濒死时恢复生命；也可复活已倒下角色。", "Consumable: protect a living Gearloc with a revive die, or revive a KO’d Gearloc."],
	["治疗存活角色、获得战利品，或锁定医疗包重掷次数。", "Heal, gain Loot, or lock rerolls for Med Kit dice."],
	["使已宣告的相邻目标中毒；中毒在其回合开始造成真实伤害后递减。", "Poison your declared adjacent target; poison deals True Damage at turn start and then decreases."],
	["治疗一名存活角色，不能超过生命上限。", "Heal a living Gearloc up to maximum HP."],
	["消耗品；使任意敌人中毒。", "Consumable: poison any baddie."],
	["放入存活角色主动槽，增加临时生命；临时生命耗尽时移除骰子。有毒结果伤害自己。", "Give a living Gearloc Buff HP in an Active slot; exhaust when depleted. Tainted results damage you."],
	["放入存活角色主动槽，增加本场战斗的可用攻击骰，仍需支付敏捷。", "Give a living Gearloc extra Attack dice for this battle; rolling them still costs Dex."],
	["每次投掷消耗一格能量电池；造成真实伤害或复活倒下的角色。", "Spend one Battery charge per roll to deal True Damage or revive a KO’d Gearloc."],
	["消耗品计数骰；取得时投掷并锁定，记录电击背包剩余能量。", "Consumable counter: roll and lock when acquired to supply Zappack charges."],
	["立即使用或锁定；重掷本回合未使用的临时生命、临时攻击或永久生命药剂骰。", "Use instantly or lock; reroll an unused Buff HP, Buff Attack or permanent HP die rolled this turn."],
	["为一名存活角色增加临时生命；有毒结果造成真实伤害。", "Give a living Gearloc Buff HP; Tainted results deal True Damage to you."],
	["放入存活角色主动槽；每回合开始治疗，或恢复仍存在的临时生命至原上限。", "Active on a living Gearloc: heal at turn start, or replenish existing Buff HP up to its original amount."],
	["永久增加所选角色生命上限和当前生命；有毒结果伤害自己。", "Permanently increase the chosen Gearloc’s maximum and current HP; Tainted results damage you."]
], Fr = [
	["可复用；锁定后每回合开始恢复一点生命，跨战斗保留。", "Reusable: lock to heal one HP at turn start; persists between battles."],
	["可复用；锁定后获得免费移动，或每次受到伤害时抵消一点普通伤害。", "Reusable: lock free movement or one point of constant Defense against normal damage."],
	["放在另一角色主动槽；其接下来被选为目标的攻击与效果由Picket承担。", "Active on another Gearloc: redirect the next indicated attacks and effects to Picket."],
	["消耗品；生命降到一点，持续期间不能获得或失去生命，自己回合开始递减。", "Consumable: set HP to one and prevent all HP changes for the indicated turns; reduce at turn start."],
	["可复用；锁定免费移动，或每回合的攻击总伤害增加一点。", "Reusable: lock free movement or one extra total Attack damage each turn."],
	["可复用；锁定后持续嘲讽，相邻敌方单位必须选择Picket。", "Reusable: lock constant Taunt; adjacent enemies must target Picket."],
	["放在另一角色主动槽；其下几次被选为目标的攻击与效果由Picket承担。", "Active on another Gearloc: redirect the next attacks and effects to Picket."],
	["消耗品；治疗Picket，不能超过生命上限。", "Consumable: heal Picket up to maximum HP."],
	["换位、突进或还击，可先存入主动槽。换位与突进可在本回合使用；同回合第二次同类效果可额外造成三点伤害或治疗。", "Switch, Rush or Riposte may be stored Active. Switch/Rush may be used this turn; the second matching effect grants its three-point damage or healing bonus."],
	["突进最多免费移动三格；同回合第二次突进可对相邻敌人造成三点伤害。", "Rush moves up to three positions free; the second Rush that turn may damage an adjacent baddie for three."],
	["高级防御放在自己或存活队友主动槽；吸收普通伤害，也可用于Picket盾击。", "Advanced Defense may be Active on you or a living ally; absorbs normal damage and counts for Picket’s Shield Bash."],
	["高级防御放在自己或存活队友主动槽。", "Place Advanced Defense in your or a living ally’s Active slot."],
	["还击在相邻敌人选中Picket时发动，避免该次伤害和效果；同时移除第二颗可对敌人造成三点伤害。", "Riposte cancels damage and effects when an adjacent baddie targets Picket; spend a second Active Riposte to deal three damage."],
	["换位交换相邻单位位置；突进免费移动；还击取消相邻敌人的一次攻击与效果。", "Switch exchanges adjacent units; Rush moves free; Riposte cancels an adjacent enemy’s attack and effects."],
	["获得Bones，或锁定强化防御训练：失败重掷后还可忽略一枚Bones。", "Gain Bones or lock Improved Defense Training to ignore one Bones after failed Defense rerolls."],
	["高级防御放在自己或存活队友主动槽。", "Place Advanced Defense in your or a living ally’s Active slot."]
], Ir = [
	["怒气计数骰；受伤按失去生命增加怒气，每回合首次攻击增加一格。二、四、六点怒气可转换为一、二、三个Bones。", "Rage counter: advance for HP lost and once for attacking each turn. At steps two/four/six, spend for one/two/three Bones."],
	["怒气计数骰；二、四、六点怒气可治疗一、二、三点。八点时可提升等级或处决五点以下敌人。", "Rage counter: steps two/four/six heal one/two/three HP. At eight, advance tier or execute a non-Tyrant up to 5Pt."],
	["怒气计数骰；二、四、六点怒气均可对宣告目标造成两点伤害。八点时可处决二十点以下敌人。", "Rage counter: steps two/four/six deal two damage to your declared target. At eight, execute a non-Tyrant up to 20Pt."],
	["增加或降低怒气；提升结果可直接进入已训练的下一级怒气。", "Increase or decrease Rage; Advance enters the next trained Rage tier."],
	["获得斧头，或主动毒甲：受到相邻敌人伤害后可使其获得所示中毒。", "Gain axes or Active Poison Armor: after damage from an adjacent enemy, optionally poison it."],
	["获得斧头，或主动反击：受到相邻敌人伤害后可反击所示伤害。", "Gain axes or Active Lashback: after damage from an adjacent enemy, optionally deal the indicated damage back."],
	["获得斧头，或暂时坚韧：每个回合最多失去一点生命；自己回合开始递减持续时间。", "Gain axes or temporary Hardy: lose at most one HP per turn; reduce duration at your turn start."],
	["斧头库存计数骰，不可投掷；每回合可投掷一把，对不相邻敌人造成两点伤害。", "Axe counter, never rolled. Throw one per turn at a non-adjacent baddie for two damage."],
	["使宣告目标在本轮结束时降低先攻位置。", "Lower your declared target’s initiative position at round end."],
	["降低一名相邻敌人的攻击，持续本场战斗。", "Reduce an adjacent baddie’s Attack for this battle."],
	["禁用一名相邻的五点以下敌人技能，持续本场战斗。", "Disable an adjacent non-Tyrant up to 5Pt for this battle."],
	["消耗品；下轮全队优先行动，或眩晕所有五点以下敌人；Bones可复用。", "Consumable: move the party above enemies next round, or stun every non-Tyrant up to 5Pt. Bones are reusable."],
	["跳到任意敌人相邻空格，并将其设为宣告目标。", "Jump to an empty position adjacent to a baddie and declare it as your target."],
	["增加本场战斗的攻击；特殊结果还会立即进行一次攻击训练。", "Gain Attack for this battle; the special result also makes an Attack Training Attempt immediately."],
	["嘲讽相邻敌人，持续至自己下次回合开始。", "Taunt adjacent enemies until the start of your next turn."],
	["击杀计数骰，不可投掷；击败敌人后累计，最多五点，可消耗全部计数治疗自己。", "Body Count counter, never rolled. Gain one per kill up to five; spend all to heal yourself."]
], Lr = [
	["下次战斗的敌人点数减少三点。", "Reduce next battle’s Baddie Points by three."],
	["取得一颗本角色可用的消耗品技能；选择技能编号。", "Acquire an eligible consumable skill for your Gearloc; choose its skill number."],
	["自己回合治疗五点，然后获得中毒二。", "On your turn, heal five HP and gain Poison 2."],
	["训练失败后可重置失败项目限制，重新尝试。可用两次。", "After failed training, reset failed choices and try again. Two uses."],
	["投骰前获得两颗额外攻击骰，本回合投掷它们不消耗敏捷。", "Before rolling, gain two additional Attack dice free of Dex this turn."],
	["仅战斗外治疗队友，共有七点治疗量，按所选数量消耗；每天结束减少一点。", "Outside battle, spend from seven HP of healing on an ally; lose one remaining use each day."],
	["本回合敏捷增加三点。", "Gain three Dex this turn."],
	["自动打开当前难度不超过四的锁。", "Automatically solve the current lock if its value is at most four."],
	["战斗中治疗自己三点，战斗外治疗五点。", "Heal yourself for three in battle or five outside battle."],
	["为所选开锁行动骰增加一点，可用三次。", "Add one to a chosen lockpicking action die. Three uses."],
	["自己回合治疗一点，可用三次。", "Heal yourself for one on your turn. Three uses."],
	["为自己所选开锁骰增加两点，可用两次。", "Add two to your chosen lockpicking die. Two uses."],
	["永久、占三个背包位；每颗防御骰可将Bones转为防御一，或将防御一转为二，一骰只能转换一次。", "Permanent, occupies three slots. Each Defense die may convert Bones to one Defense or one Defense to two once."],
	["下次训练可忽略一枚Bones。", "Ignore one Bones in the next training attempt."],
	["重掷一颗未使用骰子、开锁骰或部署阶段的先攻骰。可用两次。", "Reroll an unused die, lockpicking die or initiative during deployment. Two uses."],
	["永久、占三个背包位；每回合可额外免费投掷一颗防御骰。", "Permanent, occupies three slots. Roll one extra Defense die free of Dex each turn."],
	["本轮结束时，选择将自己的先攻提高三个位置。可用两次。", "At round end, optionally move up three initiative positions. Two uses."],
	["下一战斗使最近战斗击败过的一类敌人先攻降低；选择敌人种类。可用三次。", "Give Surprise against one creature type defeated last battle; select its creature type. Three uses."],
	["永久、占三个背包位；训练攻击和防御时可忽略一枚Bones。", "Permanent, occupies three slots. Ignore one Bones in Attack and Defense training."],
	["即将受到负面效果时，可弃置此物阻止该次效果。", "Discard when a negative effect would be applied to prevent it."],
	["为自己所选开锁骰增加四点。", "Add four to your chosen lockpicking die."],
	["抽两张遭遇，选择当天面对的一张，另一张放回遭遇牌堆底。", "Draw two Encounters; choose one for today and put the other at the deck bottom."],
	["恢复阶段取得一张珍宝。", "Gain a Trove Loot during Recovery."],
	["自己回合对任意存活单位投一颗攻击骰并造成伤害。可用两次。", "On your turn roll one Attack die against any living unit. Two uses."],
	["战斗外将宝藏鼠特殊遭遇加入遭遇牌堆。", "Outside battle, shuffle the treasure-rat Special Encounter into the deck."],
	["永久生命增加一点；下一次战斗开始失去三点生命。", "Gain one permanent maximum and current HP; lose three HP at the next battle start."],
	["自己回合恢复一名角色已经耗尽的技能骰。", "On your turn recover an exhausted skill of a Gearloc."],
	["本场战斗每轮开始治疗自己一点。", "Heal yourself for one at each round start this battle."],
	["治疗一名存活角色两点。", "Heal a living Gearloc for two."],
	["遭遇获得；占一个背包位，可在战斗内外按所选数量消耗两点治疗量。", "Encounter Loot; occupies one slot and holds two HP to spend healing inside or outside battle."]
], Rr = [
	["", ""],
	["", ""],
	["备用计划一：免费额外投掷一颗可用骰子；数量选择零为攻击、一为防御、二为技能。", "Backup 1: roll one additional available die free of Dex. Choose amount 0 for Attack, 1 for Defense or 2 for a skill."],
	["你的备用计划与珍宝备用计划消耗的Bones减少一，天赋升级仍需六个Bones。", "Reduce your Backup Plan and extension costs by one Bones; the Innate upgrade still costs six."],
	["备用计划二：将宣告目标的防御骰移至自己的主动槽，必须有足够空槽。", "Backup 2: steal your declared target’s Defense dice into your Active slots, if space permits."],
	["", ""],
	["备用计划三：变为不可选目标，持续至自己下回合；每场一次。", "Backup 3: become Untargetable until your next turn, once per battle."],
	["击杀第一名敌人后记录其种类；以后同类击杀继续累计，攻击该类敌人时，每次累计提供一颗免费攻击骰。", "Record the first creature type you kill. Each matching kill adds one free Attack die when attacking that type."],
	["备用计划一：宣告目标在本轮末降低一个先攻位置。", "Backup 1: lower your declared target one initiative position at round end."],
	["备用计划三：眩晕一名一点或五点敌人；掷出一时，自己下回合也眩晕。", "Backup 3: stun a 1Pt or 5Pt baddie; on a D6 roll of one, you are also stunned next turn."],
	["全队面对的所有锁难度减少一。", "Reduce every lock difficulty the party faces by one."],
	["备用计划一：永久生命属性减少一并治疗三点，不可低于初始生命属性。", "Backup 1: permanently lose one maximum HP and heal three; cannot go below starting Health."],
	["备用计划二：对任意敌人造成两点伤害；掷D6，四至六时本场不能再用。", "Backup 2: deal two damage to any baddie; on D6 four to six, unavailable for the rest of this battle."],
	["战前选择一至四号路线；该路线第一名入场的一点、五点或二十点敌人延迟一轮，每场一次。", "Before battle choose lane one to four; delay its first 1Pt, 5Pt or 20Pt entrant for one round, once per battle."],
	["本回合投掷后再选择宣告攻击目标。", "Choose your declared Attack target after rolling this turn."],
	["备用计划一：治疗任意存活角色一点。", "Backup 1: heal any living Gearloc for one."],
	["任何训练尝试都可忽略一枚Bones。", "Ignore one Bones in any training attempt."],
	["备用计划二：选择本回合一颗未使用的攻击骰，按其伤害为目标施加同等中毒。", "Backup 2: choose an unused Attack result this turn and poison its target for that amount."],
	["备用计划一：重掷本回合一颗未使用的骰子。", "Backup 1: reroll one unused die this turn."],
	["备用计划一：本轮末提高自己一个先攻位置。", "Backup 1: move up one initiative position at round end."],
	["被不相邻敌人攻击后，立即投一颗攻击骰并对该敌人造成伤害；Bones不能用于备用计划。", "After a non-adjacent baddie attacks you, roll one Attack die against it; Bones cannot enter your Backup Plan."],
	["每天战斗外可侦察任一等级的一名敌人，选择保留或放回敌人堆底。", "Once per day outside battle, scout a baddie of any point value and optionally cycle it to the bottom."],
	["备用计划二：恢复任意角色一颗已耗尽骰子，每场一次。", "Backup 2: recover any Gearloc’s exhausted die, once per battle."]
], zr = [
	["反击：每个回合首次受到相邻敌方造成的普通伤害并失去生命后，若仍存活，反击所示伤害。", "Lashback: once per turn after losing HP from an adjacent enemy’s damage, deal the indicated damage back if still alive."],
	["飞行：回合末交替获得或移除飞行；飞行时不能被选为目标。", "Flight: toggle Flight at turn end; cannot be targeted while flying."],
	["厚皮：每个回合忽略最先受到的所示普通伤害，不抵消真实伤害。", "Thick Skin: ignore the first indicated normal damage each turn; does not block True Damage."],
	["粗心：受到所示真实伤害。", "Careless: suffer the indicated True Damage."],
	["掠夺：场上每有另一名兽人敌人，攻击增加一骰。", "Raiding: gain one Attack die for every other Orc baddie on the mat."],
	["狂暴：生命未满时增加所示攻击骰。", "Rage: gain the indicated Attack dice while below full HP."],
	["中毒：将目标中毒设为所示数值；目标回合开始承受同等真实伤害，随后递减。", "Poison: set target Poison to the result; deal that True Damage at turn start, then decrease by one."],
	["破坏：使其失去生命的白色攻击骰在本场战斗耗尽。", "Break: exhaust white Attack dice that reduce this unit’s HP for this battle."],
	["恶作剧：目标选择移除所示数量的主动骰；其他单位移除防御骰。", "Mischief: the target chooses the indicated Active dice to remove; other units remove Defense dice."],
	["坚韧：每个回合总共最多失去一点生命，包括真实伤害。", "Hardy: lose at most one total HP per turn, including True Damage."],
	["虚弱：角色下回合敏捷降低；其他单位下回合攻击降低。", "Weaken: reduce a Gearloc’s Dex or another unit’s Attack on its next turn."],
	["吞噬：掷出的总攻击伤害也伤害目标相邻的所有单位，包括攻击者。", "Engulf: rolled Attack damage also hits all units adjacent to the target, including the attacker."],
	["递增：攻击骰数等于当前轮数，最多五骰。", "Compound: Attack equals the current round, up to five dice."],
	["鼓舞：先攻表中的下一名敌人移至此单位之后，且该回合增加所示攻击骰。", "Inspire: move the next baddie directly after this unit and give it the indicated extra Attack dice that turn."],
	["恐惧：攻击此单位后获得恐惧，持续至下回合末；下回合不能选择带恐惧技能的目标。", "Terrify: attackers gain Terrify until the end of their next turn and cannot target Terrify units on that turn."],
	["俯冲：带飞行状态开始回合时，移动至最弱可用敌方单位相邻空格并选择它。", "Dive: if flying at turn start, move next to the weakest available opposing unit and target it."],
	["信号：回合开始向待入场敌人末尾加入一名低等级敌人，共触发所示回合数。", "Signal: at turn start add a lesser baddie to the waiting stack for the indicated number of turns."],
	["嘲讽：相邻敌方必须选其为目标，直至其下回合；多目标攻击集中于该单位。", "Taunt: adjacent enemies must target this unit until its next turn; multiple attacks focus on it."],
	["腐蚀：回合末使目标主动槽剩余的防御骰全部耗尽。", "Corrosive: at turn end remove all remaining Defense dice in the target’s Active slots."],
	["恢复：回合开始恢复所示生命，不超过上限。", "Recover: heal the indicated HP at turn start, up to maximum."],
	["不死：首次倒下后回到待入场敌人顶端；再次入场时两点生命、双倍攻击。", "Undead: after first defeat, return to the top of the waiting stack; re-enter at two HP with doubled Attack."],
	["限制：目标选择移除一个已提升的属性，持续本场战斗。", "Limit: the target removes one upgraded Stat for this battle."],
	["隐蔽：只有相邻单位能选择此单位为目标。", "Shrouded: only adjacent units may target this unit."],
	["隐藏：直到自己下回合不能被选为目标。", "Hide: cannot be targeted until your next turn."],
	["狂乱：至少所示数量的攻击骰命中时，额外投掷所示数量的攻击骰并加入伤害。", "Frenzy: if at least the indicated Attack dice hit, roll that many additional dice and add their damage."],
	["撤退：三点生命或更低时开始回合，退出战场并回到待入场敌人顶端；再次入场恢复全部生命。", "Retreat: at turn start with three HP or less, return to the waiting stack top; re-enter at full HP."],
	["沼泽统治者：场上有其他沼泽敌人时不能失去生命，且免疫中毒。", "Bog Ruler: cannot lose HP while another Bog baddie is on the mat; immune to Poison."],
	["召唤兽人：一个Bones加入一点兽人，两个或更多加入五点兽人。", "Call Orc: add a 1Pt Orc for one Bones or a 5Pt Orc for at least two."],
	["爆破：总攻击伤害的一半向下取整，波及目标相邻单位。哥布林王免受自己造成的伤害。", "Boom: half the rolled Attack damage, rounded down, hits units adjacent to the target. The Goblin King ignores self-inflicted damage."],
	["击退：哥布林王攻击前，所有角色移至距离自己原位置最远的空格。", "Kaboom: before the Goblin King attacks, move every Gearloc to an empty position farthest from its current position."]
], Br = (e, t) => e.map((e) => e[t]).join("|"), Vr = {
	skillRulesBoomer: Br(Nr, 0),
	skillRulesPatches: Br(Pr, 0),
	skillRulesPicket: Br(Fr, 0),
	skillRulesTantrum: Br(Ir, 0),
	lootRules: Br(Lr, 0),
	troveRules: Br(Rr, 0),
	baddieRules: Br(zr, 0)
}, Hr = {
	skillRulesBoomer: Br(Nr, 1),
	skillRulesPatches: Br(Pr, 1),
	skillRulesPicket: Br(Fr, 1),
	skillRulesTantrum: Br(Ir, 1),
	lootRules: Br(Lr, 1),
	troveRules: Br(Rr, 1),
	baddieRules: Br(zr, 1)
}, Ur = {
	definition: zn,
	View: pr,
	bot: Cr,
	OverView: Dr,
	Options: Or,
	Guide: kr,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			creature: "敌人种类",
			creatureNames: "巨魔|兽人|鳞族|地精|沼泽生物|野兽",
			flickAdjust: "调整弹射",
			flickAngle: "方向",
			flickPower: "力度",
			flickShoot: "弹射",
			...Vr,
			encounters: jr,
			name: "枯骨围城",
			moreOptions: "更多操作",
			battleProgress: "第{{day}}/{{days}}天 · 进度{{p}}/{{total}}",
			battlefield: "四乘四战场",
			yourTurn: "你的回合",
			chooseDice: "选择骰子",
			resolveDice: "使用骰子",
			rollCount: "投掷{{n}}颗骰子",
			chooseDeployment: "选择高亮起始格",
			chooseBoardTarget: "选择高亮目标",
			chooseMove: "选择高亮移动格",
			boardPosition: "第{{x}}列，第{{y}}行",
			unitHp: "{{name}}，生命{{n}}",
			moveTo: "移动至{{x}}·{{y}}",
			moveCost: "消耗{{n}}点敏捷",
			attackTarget: "攻击目标：{{name}}",
			noAttackTarget: "没有可攻击的目标",
			notEnoughDex: "剩余敏捷不足",
			attackFor: "攻击{{name}}（{{n}}点攻击）",
			storeDefense: "存入{{n}}点防御",
			collectBones: "收集{{n}}个Bones",
			skillTarget: "技能目标：{{name}}",
			slotsFull: "槽位已满，请选择其他用途或移除槽内骰子",
			useSkill: "使用{{name}}",
			chooseResolution: "选择骰子用途",
			activeFull: "主动槽已满，请选择其他用途或移除槽内骰子",
			defeatEnemies: "击倒全部敌人",
			defeatTyrant: "击败暴君",
			endUnused: "跳过未用骰子并结束回合",
			backupBoomer: "1：造成1点伤害；2：重掷所选零件骰；3：移动一个单位；4：造成3点伤害；5：暂时不可选为目标；6：升级天赋。",
			backupPatches: "2：治疗1点生命；3：造成2点近战伤害；4：取得技能骰；5：消耗电池造成4点真实伤害；6：升级天赋。",
			backupPicket: "2：将防御转为攻击；3：重掷所选骰子；4：恢复2点生命并获得2点防御；5：盾击并眩晕；6：升级天赋。",
			backupTantrum: "1：提高怒气；2：降低怒气；4：补满斧头；5：恢复4点生命；6：升级天赋。",
			desc: "Too Many Bones：成长骰驱动的合作冒险",
			rules: "目标：\n· 在暴君规定的天数内积累进度，挑战并击败暴君。\n准备：\n· 每人选择一名不同的齿轮族角色。\n· 选择暴君与难度，按角色板取得初始属性。\n每日流程：\n· 队长抽取遭遇，或在进度足够时挑战暴君。\n· 全队选择遭遇选项，执行挑战或战斗。\n· 成功后领取进度、战利品和训练点。\n· 恢复阶段可以交易战利品，每人可尝试开锁一次。\n· 每人选择休息、换取战利品或侦察，然后进入次日。\n战斗：\n· 角色放入近战或远程起始格，确定先攻顺序。\n· 每格移动消耗1点敏捷，投掷每颗骰子消耗1点敏捷。\n· 每回合一次同时投掷所选骰子，通常只宣告一个攻击目标。\n· 选择骰子的结算顺序，技能也可以暂不使用。\n· 防御骰与技能分别放入三个主动槽或三个锁定槽。\n· Bones可以用于备用计划，每回合最多使用一次。\n· 回合结束最多保留5个Bones，6个可升级天赋。\n· 第6轮开始，每轮开始时所有单位失去1点生命。\n· 击倒全部敌人赢得普通战斗，击败暴君赢得冒险。\n训练与开锁：\n· 生命、敏捷和符合前置的技能训练必定成功。\n· 攻击训练不能出现Bones；防御训练可重掷失败骰一次。\n· 训练失败后，该训练点必须改练其他项目。\n· 开锁依次处理机关、绊线与蛮力锁，同类骰的数值可相加。\n· 使用过的开锁骰耗尽，已打开的锁跨日保留。\n· 直觉骰可转换类型、重掷一骰或保留一骰并使其数值增加1。\n· 第一道面对的锁失败时，当天可立即重试一次。\n挑战与失败：\n· 弹骰遭遇采用拖拽瞄准、松手弹射，共有4次机会。\n· 至少命中3个树目标，且被命中的目标不能离开桌面。\n· 每张小游戏遭遇的目标、机会与奖励见当前遭遇说明。\n· 全队倒下会失去当日奖励，仍可恢复并继续冒险。\n· 超过暴君的天数限制仍未通关，冒险失败。",
			errAction: "当前不能这样行动，请检查阶段、目标和剩余资源。",
			recruit: "选择角色",
			training: "使用训练点",
			day: "新的冒险日",
			encounter: "选择遭遇方案",
			challenge: "完成遭遇挑战",
			battle: "战斗",
			recovery: "恢复与整备",
			done: "冒险结束",
			dayCount: "第{{n}}天 · 进度{{p}}/{{total}}",
			round: "第{{n}}轮",
			wait: "等待其他队员",
			boomer: "Boomer · 炸弹专家",
			patches: "Patches · 战地医师",
			picket: "Picket · 护卫",
			tantrum: "Tantrum · 狂战士",
			tyrant: "暴君",
			difficulty: "难度",
			adventurer: "冒险者",
			heroic: "英雄",
			legendary: "传奇",
			nom: "Nom",
			gendricks: "Gendricks",
			duster: "Duster",
			mulmesh: "Mulmesh",
			drellen: "Drellen",
			marrow: "Marrow",
			goblinking: "Goblin King",
			hp: "生命",
			dex: "敏捷",
			attack: "攻击",
			defense: "防御",
			skill: "技能",
			trainingPoints: "训练点{{n}}",
			active: "主动槽",
			locked: "锁定槽",
			bones: "Bones",
			loot: "战利品",
			trove: "珍宝",
			exhausted: "已耗尽",
			available: "可用",
			ready: "准备完成",
			draw: "抽取遭遇",
			fightTyrant: "挑战暴君",
			choice: "选项{{n}}",
			confirm: "确认",
			cancel: "取消",
			target: "目标",
			position: "位置",
			deploy: "放置角色",
			move: "移动",
			roll: "投掷所选骰子",
			endTurn: "结束回合",
			remainingDex: "剩余敏捷{{n}}",
			use: "使用",
			store: "放入主动槽",
			lockStore: "放入锁定槽",
			discard: "弃置",
			saveBones: "放入备用计划",
			backup: "备用计划",
			rest: "休息并恢复全部生命",
			search: "弃置战利品并搜寻",
			scout: "侦察敌人",
			keep: "保留",
			cycle: "放至牌堆底",
			trade: "交给队友",
			lockpick: "尝试开锁",
			rollLock: "投掷开锁骰",
			reroll: "重掷",
			convert: "转换类型",
			save: "保留并增加1",
			solve: "打开当前锁",
			stop: "结束尝试",
			lever: "机关",
			trip: "绊线",
			force: "蛮力",
			lockPrompt: "第{{n}}道锁 · {{type}} {{value}}",
			craft: "合成炸弹",
			axe: "投掷斧头",
			bodyCount: "以击杀数治疗",
			rage: "释放怒气",
			advance: "提升怒气等级",
			execute: "处决",
			heal: "治疗",
			decrease: "降低",
			increase: "提高",
			release: "移除骰子",
			activate: "发动技能",
			startEffect: "结算回合开始效果",
			reaction: "结算响应",
			initiative: "调整先攻",
			orderReady: "确认先攻顺序",
			enemyTarget: "选择敌人攻击目标",
			enemyMove: "选择敌人移动路线",
			inspect: "查看组件",
			close: "关闭",
			history: "冒险记录",
			card: "遭遇{{id}}",
			inventory: "背包{{n}}/4",
			flick: "拖拽箭矢瞄准，松手弹射",
			flickLane: "第{{n}}条路线",
			shots: "已弹射{{n}}/4次",
			dartsSetup: "选择3颗骰子，每种最多2颗",
			poison: "状态骰",
			dartsRoll: "投掷飞镖骰",
			dartsPass: "放弃本次Bones",
			dartsClean: "移除中毒",
			dartsDefense: "移除对方防御",
			dartsStun: "眩晕对手",
			dartsWin: "直接击倒对手",
			amount: "数量",
			damage: "伤害",
			effect: "效果",
			point: "{{n}}点敌人",
			logLine: "{{who}} {{event}} {{target}} {{n}}",
			actions: "行动",
			details: "详情",
			noTarget: "不指定目标",
			die: "骰子",
			free: "免费",
			selected: "已选择",
			aim: "选择{{skill}}的落点",
			strongest: "目标：生命最高者",
			weakest: "目标：生命最低者",
			targets: "{{n}}个目标",
			ranged: "远程",
			melee: "近战",
			logEvents: "获得临时生命|受到伤害|冒险失败|抽取遭遇|挑战掷骰|完成弹射|进入战斗|击败|施加状态|敌人掷骰|鼓舞|倒下|使用战利品|复活|进入战斗轮次|暴君掷骰|冒险成功|飞镖掷骰|开始开锁|开锁成功|开锁失败|搜寻战利品|发动备用计划|提升怒气|掷骰|完成训练|尝试训练|恢复生命|获得战利品|获得珍宝|遭遇成功|遭遇失败",
			decision: "完成当前遭遇步骤",
			startingLoot: "选择保留的一张战利品",
			troveRedraw: "保留珍宝，或弃置后重抽一次",
			troveImmediate: "选择珍宝立即开锁，或跳过",
			discardThenRedraw: "选择需要弃置的战利品",
			bribe: "全队每名队员支付一张战利品",
			snipe: "选择本场战斗耗尽的攻击骰数量",
			grab: "选择尝试取得的战利品数量",
			whirlwind: "选择独自应战的角色",
			trapHp: "选择生命最接近掷骰结果的角色",
			duel: "选择先行出战的角色",
			scoutReturn: "选择侦察的敌人等级",
			exhaustStats: "选择全队各自耗尽的攻击骰和防御骰数量",
			barrelCount: "选择一至四个木桶",
			gambleLoot: "选择投入赌局的战利品",
			offering: "选择献出的战利品",
			tripSkills: "选择下次战斗耗尽的三颗技能骰",
			wolfHand: "选择伸出手的角色",
			healDuster: "选择用于治疗Duster的战利品",
			bogIngredients: "选择六枚1点敌人，或三枚5点敌人",
			goblinBomb: "选择准备拆解的锁类型",
			pendingReaction: "处理{{name}}的响应",
			pass: "跳过",
			double: "同时使用两颗",
			unitTurn: "{{name}}的回合",
			challengeValues: "挑战状态",
			playerSide: "我方",
			opponentSide: "对手",
			chooseLoot: "选择战利品",
			chooseSkills: "选择技能骰",
			scoutLevels: "1点|5点|20点",
			baddiesWaiting: "待入场敌人{{n}}枚",
			baddieNames: "幼恶狼|幼狮鹫|顽童巨魔|蛮力巨魔|年轻巨魔|兽人侦察兵|兽人士兵|兽人苦工|沼泽蝌蚪|黏土魔像|沼泽蛙|哥布林暴徒|哥布林投弹手|哥布林沙袋手|狗头人园丁|幼龙|雏龙|狗头人追踪者|恶狼|枭熊|嚎叫狮鹫|巨魔贤者|巨魔执法者|哥布林警报兵|哥布林工兵|兽人战争贩子|兽人狂暴者|狗头人精锐|叛逆龙|狗头人狂热者|沼泽潜伏者|石魔像|蝎尾狮|黄金魔像|荣耀狮鹫|恶狼首领|凶猛枭熊|远古巨龙|骨龙|沼泽蠕龙",
			objectNames: "宝珠|宝珠柱|王座|老鼠|黑衣人|商人",
			progressShort: "进度奖励：{{n}}",
			effectNames: "攻击|防御|Bones|Bones|可复用Bones|元素|弹壳|引信|炸弹库存|爆炸|全体敌人伤害|全队反冲|自身反冲|眩晕|燃烧|净化|烟幕|禁用|零件|战利品|临时生命|更大爆炸|获得神圣手榴弹|元素325|神圣爆破|神圣爆炸|治疗|治疗倍增|治疗重掷|近战伤害|真实伤害|复活|复活|中毒|中毒|临时攻击|药剂重掷|持续治疗|强化注射|永久生命|有毒混合物|持续再生|免费移动|持续防御|持续伤害|持续嘲讽|强化防御训练|高级防御|拦截|麦酒|自我治疗|换位|突进|还击|怒气调整|提升怒气|获得斧头|毒甲|反击|坚韧|降低先攻|削弱攻击|提高攻击|攻击训练|全队鼓舞|全体眩晕|跳跃|嘲讽|怒气|斧头|击杀数|能量电池|空白|中毒|流血|虚弱|恐惧|不可选为目标|飞行|限制|先攻",
			skillsBoomer: "元素|弹壳|引信|炸弹计数|破片炸弹|大爆炸|烟幕|净化音爆|震撼弹|燃烧弹|闪光弹|炸弹袋|搜身|更大爆炸|寻找325|神圣手榴弹",
			skillsPatches: "医疗包|快手|骨锯|生命药水|营养剂|毒素|大医疗包|毒镖|兴奋剂|化学药剂|电击背包|能量电池|蒸馏器|兴奋剂腰带|链式反应|致命兴奋剂",
			skillsPicket: "坚守阵地|盾牌阵形|红衫替身|兽人麦酒|挥剑推进|封锁|拦截|哥布林肉干|换位|突进|信心|毅力|还击|随机应变|勇武|威望",
			skillsTantrum: "怒气|盛怒|狂怒|愤怒管理|模仿蠕龙|模仿恶狼|模仿狗头人|斧头收藏|威吓|致残|荒野之道|狂战士号角|振奋|强化|乌木之道|击杀计数",
			lootNames: "信号干扰弹|幸运发现|新鲜沼泽肉|机械臂|浸香|上场战斗的炖菜|机械助力|机械开锁器|混合浆果|多用工具|奥格特草药|撬棍|掠夺者护甲|红牛头人|反射粉|加固小圆盾|生锈目镜|剥皮刀|陪练武器|乌木烈酒|石锤|破旧地图|特瓦伦宝石|投掷斧|藏宝图|巨魔酿酒|实用零件|泽尔菲根|泽尔菲种子|瓶装水",
			troveNames: "||敏捷注射器|爆炸蘑菇|闪光箭||抓钩枪|猎人战绩项链|激光笔|闪电棒|锁匠手册|极效兴奋剂|机械回旋镖|机械松鼠|微型神经植入物|小型修补包|Pip-Loc 2000|毒瓶套装|反射粉罐|电击诱导器|肩扛石弹发射器|小型望远镜|实用腰带",
			win: "暴君已被击败，冒险成功！",
			lose: "天数耗尽，冒险失败。"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			creature: "Baddie type",
			creatureNames: "Troll|Orc|Scales|Goblin|Bog|Beast",
			flickAdjust: "Adjust shot",
			flickAngle: "Direction",
			flickPower: "Power",
			flickShoot: "Shoot",
			...Hr,
			encounters: Mr,
			name: "Too Many Bones",
			moreOptions: "More options",
			battleProgress: "Day {{day}}/{{days}} · Progress {{p}}/{{total}}",
			battlefield: "Four by four battle mat",
			yourTurn: "Your turn",
			chooseDice: "Choose dice",
			resolveDice: "Use dice",
			rollCount: "Roll {{n}} dice",
			chooseDeployment: "Choose a highlighted starting space",
			chooseBoardTarget: "Choose a highlighted target",
			chooseMove: "Choose a highlighted space",
			boardPosition: "Column {{x}}, row {{y}}",
			unitHp: "{{name}}, {{n}} HP",
			moveTo: "Move to {{x}}·{{y}}",
			moveCost: "Spend {{n}} Dexterity",
			attackTarget: "Attack target: {{name}}",
			noAttackTarget: "No target in attack range",
			notEnoughDex: "Not enough Dexterity",
			attackFor: "Attack {{name}} for {{n}}",
			storeDefense: "Store {{n}} Defense",
			collectBones: "Collect {{n}} Bones",
			skillTarget: "Skill target: {{name}}",
			slotsFull: "Slots full: choose another use or release a die",
			useSkill: "Use {{name}}",
			chooseResolution: "Choose die use",
			activeFull: "Active slots full: choose another use or release a die",
			defeatEnemies: "Defeat all baddies",
			defeatTyrant: "Defeat the Tyrant",
			endUnused: "Skip unused dice and end turn",
			backupBoomer: "1: Deal 1 damage; 2: Reroll selected component dice; 3: Move a unit; 4: Deal 3 damage; 5: Become untargetable; 6: Upgrade Innate.",
			backupPatches: "2: Heal 1 HP; 3: Deal 2 melee damage; 4: Acquire a skill die; 5: Spend a cell for 4 true damage; 6: Upgrade Innate.",
			backupPicket: "2: Turn Defense into damage; 3: Reroll selected dice; 4: Heal 2 HP and gain 2 Defense; 5: Shield Bash and Stun; 6: Upgrade Innate.",
			backupTantrum: "1: Increase Rage; 2: Decrease Rage; 4: Refill axes; 5: Heal 4 HP; 6: Upgrade Innate.",
			desc: "A cooperative dice-building adventure",
			rules: "Goal:\n· Earn progress and defeat the Tyrant within its day limit.\nSetup:\n· Each player chooses a different Gearloc.\n· Choose a Tyrant and difficulty, then take starting stats.\nEach day:\n· The leader draws an Encounter or challenges the Tyrant when eligible.\n· Choose an option together and resolve its challenge or battle.\n· On success, gain progress, loot and training points.\n· During recovery, trade loot and make one lockpicking attempt each.\n· Each Gearloc rests, searches for loot or scouts, then starts a new day.\nBattle:\n· Deploy in melee or ranged starting positions and set initiative.\n· Moving one position costs 1 Dex; rolling each die costs 1 Dex.\n· Roll selected dice together once per turn, normally declaring one target.\n· Choose the order of die resolution; unused skills can be kept.\n· Place defense and skills in three Active or three Locked slots.\n· Spend Bones on a Backup Plan at most once per turn.\n· Keep up to 5 Bones at turn end; 6 upgrades your Innate.\n· From round 6, all units lose 1 HP at each round start.\n· Defeat all baddies in ordinary battles; defeat the Tyrant to win.\nTraining and locks:\n· Health, Dex and eligible skill training always succeed.\n· Attack training needs no Bones; reroll failed defense dice once.\n· After failure, spend the point on a different training choice.\n· Solve Lever, Trip and Force locks in order by totaling matching dice.\n· Used action dice exhaust; opened locks stay open across days.\n· Intuition converts, rerolls one die, or saves a die and adds 1.\n· Failure on the first lock faced allows one immediate retry that day.\nChallenges and defeat:\n· Flick challenges use drag to aim and release to shoot, with 4 shots.\n· Hit at least 3 tree targets without knocking those targets off the table.\n· Each minigame lists its own objectives, attempts and rewards.\n· A party knockout loses today’s rewards; recover and continue.\n· Exceeding the Tyrant’s day limit ends the adventure in defeat.",
			errAction: "That action is unavailable. Check the phase, target and resources.",
			recruit: "Choose a Gearloc",
			training: "Spend training points",
			day: "A new day",
			encounter: "Choose an Encounter option",
			challenge: "Complete the challenge",
			battle: "Battle",
			recovery: "Recovery",
			done: "Adventure over",
			dayCount: "Day {{n}} · Progress {{p}}/{{total}}",
			round: "Round {{n}}",
			wait: "Waiting for the party",
			boomer: "Boomer · Grenadier",
			patches: "Patches · Combat medic",
			picket: "Picket · Protector",
			tantrum: "Tantrum · Zerker",
			tyrant: "Tyrant",
			difficulty: "Difficulty",
			adventurer: "Adventurer",
			heroic: "Heroic",
			legendary: "Legendary",
			nom: "Nom",
			gendricks: "Gendricks",
			duster: "Duster",
			mulmesh: "Mulmesh",
			drellen: "Drellen",
			marrow: "Marrow",
			goblinking: "Goblin King",
			hp: "Health",
			dex: "Dexterity",
			attack: "Attack",
			defense: "Defense",
			skill: "Skill",
			trainingPoints: "{{n}} training points",
			active: "Active",
			locked: "Locked",
			bones: "Bones",
			loot: "Loot",
			trove: "Trove",
			exhausted: "Exhausted",
			available: "Available",
			ready: "Ready",
			draw: "Draw Encounter",
			fightTyrant: "Challenge Tyrant",
			choice: "Option {{n}}",
			confirm: "Confirm",
			cancel: "Cancel",
			target: "Target",
			position: "Position",
			deploy: "Deploy",
			move: "Move",
			roll: "Roll selected dice",
			endTurn: "End turn",
			remainingDex: "{{n}} Dex remaining",
			use: "Use",
			store: "Place in Active",
			lockStore: "Place in Locked",
			discard: "Discard",
			saveBones: "Add to Backup Plan",
			backup: "Backup Plan",
			rest: "Rest and recover all HP",
			search: "Discard loot and search",
			scout: "Scout",
			keep: "Keep",
			cycle: "Move to bottom",
			trade: "Give to ally",
			lockpick: "Attempt lockpicking",
			rollLock: "Roll lock dice",
			reroll: "Reroll",
			convert: "Convert type",
			save: "Save and add 1",
			solve: "Open current lock",
			stop: "End attempt",
			lever: "Lever",
			trip: "Trip",
			force: "Force",
			lockPrompt: "Lock {{n}} · {{type}} {{value}}",
			craft: "Craft grenade",
			axe: "Throw axe",
			bodyCount: "Heal with Body Count",
			rage: "Release Rage",
			advance: "Advance Rage",
			execute: "Execute",
			heal: "Heal",
			decrease: "Decrease",
			increase: "Increase",
			release: "Remove die",
			activate: "Activate skill",
			startEffect: "Resolve start-of-turn effect",
			reaction: "Resolve reaction",
			initiative: "Adjust initiative",
			orderReady: "Confirm initiative",
			enemyTarget: "Choose baddie target",
			enemyMove: "Choose baddie route",
			inspect: "Inspect components",
			close: "Close",
			history: "Adventure log",
			card: "Encounter {{id}}",
			inventory: "Inventory {{n}}/4",
			flick: "Drag the arrow to aim; release to shoot",
			flickLane: "Lane {{n}}",
			shots: "{{n}}/4 shots taken",
			dartsSetup: "Choose 3 dice, at most 2 of each kind",
			poison: "Status die",
			dartsRoll: "Roll darts dice",
			dartsPass: "Skip Bones",
			dartsClean: "Remove Poison",
			dartsDefense: "Remove enemy defense",
			dartsStun: "Stun opponent",
			dartsWin: "Knock out opponent",
			amount: "Amount",
			damage: "Damage",
			effect: "Effect",
			point: "{{n}} point baddie",
			logLine: "{{who}} {{event}} {{target}} {{n}}",
			actions: "Actions",
			details: "Details",
			noTarget: "No target",
			die: "Die",
			free: "Free",
			selected: "Selected",
			aim: "Choose a position for {{skill}}",
			strongest: "Targets highest HP",
			weakest: "Targets lowest HP",
			targets: "{{n}} targets",
			ranged: "Ranged",
			melee: "Melee",
			logEvents: "Gained Buff HP|Took damage|Adventure lost|Drew Encounter|Challenge roll|Flicked|Started battle|Defeated|Applied effect|Baddie roll|Inspired|Knocked out|Used Loot|Revived|Started round|Tyrant roll|Adventure won|Darts roll|Started lockpicking|Lock solved|Lock failed|Searched for Loot|Used Backup Plan|Advanced Rage|Rolled|Trained|Training attempt|Healed|Gained Loot|Gained Trove|Encounter succeeded|Encounter failed",
			decision: "Complete this Encounter step",
			startingLoot: "Choose one Loot to keep",
			troveRedraw: "Keep the Trove or discard it and draw again once",
			troveImmediate: "Choose a Trove to pick now, or skip",
			discardThenRedraw: "Choose the Loot to discard",
			bribe: "Pay one Loot per party member",
			snipe: "Choose Attack dice to exhaust for this battle",
			grab: "Choose how many Loot to attempt to grab",
			whirlwind: "Choose the Gearloc to fight alone",
			trapHp: "Choose the Gearloc whose HP is closest to the roll",
			duel: "Choose the Gearloc to enter first",
			scoutReturn: "Choose a Baddie point value to scout",
			exhaustStats: "Choose Attack and Defense dice each Gearloc exhausts",
			barrelCount: "Choose one to four barrels",
			gambleLoot: "Choose Loot to wager",
			offering: "Choose the offered Loot",
			tripSkills: "Choose three skills to exhaust at the next battle",
			wolfHand: "Choose the Gearloc to offer a hand",
			healDuster: "Choose Loot used to heal Duster",
			bogIngredients: "Choose six 1Pt or three 5Pt Baddies",
			goblinBomb: "Choose the lock type to disarm",
			pendingReaction: "Resolve {{name}}’s response",
			pass: "Pass",
			double: "Use two together",
			unitTurn: "{{name}}’s turn",
			challengeValues: "Challenge state",
			playerSide: "You",
			opponentSide: "Opponent",
			chooseLoot: "Choose Loot",
			chooseSkills: "Choose skill dice",
			scoutLevels: "1Pt|5Pt|20Pt",
			baddiesWaiting: "{{n}} Baddies waiting",
			baddieNames: "Dire Wolf Pup|Griffin Yearling|Troll Romper|Troll Brute|Troll Young’un|Orc Scout|Orc Grunt|Orc Peon|Bog Pole|Clay Golem|Bog Frog|Goblin Rioter|Goblin Bomber|Goblin Sandbagger|Kobold Greenthumb|Dragon Whelp|Dragon Hatchling|Kobold Tracker|Dire Wolf|Owlbear|Griffin Howler|Troll Sage|Troll Enforcer|Goblin Alarmist|Goblin Sapper|Orc Warmonger|Orc Rager|Kobold Elite|Dragon Delinquent|Kobold Fanatic|Bog Lurk|Stone Golem|Manticore|Golden Golem|Honor Griffin|Dire Wolf Alpha|Ferocious Owlbear|Dragon Elder|Bone Dragon|Bog Wyrm",
			objectNames: "Orb|Orb pillar|Throne|Rat|Cloaked figure|Trader",
			progressShort: "Progress reward: {{n}}",
			effectNames: "Attack|Defense|Bones|Bones|Reusable Bones|Element|Casing|Fuse|Grenades|Explosion|Damage all baddies|Party Backlash|Backlash|Stun|Napalm|Cleanse|Smoke|Disable|Parts|Loot|Buff HP|Bigger Boom|Acquire Holy Hand Grenade|Element 325|Holy Blast|Holy Explosion|Heal|Heal Assist|Reroll Heal|Melee Damage|True Damage|Revive|Revive|Poison|Poison|Buff Attack|Reroll Buff|Recover|Booster|Permanent HP|Tainted Mixture|Constant Regen|Free Move|Constant Defense|Constant Damage|Constant Taunt|Improved Defense Training|Advanced Defense|Intercept|Ale|Heal Self|Switch|Rush|Riposte|Anger|Advance Rage|Steal Axe|Poison Armor|Lashback|Hardy|Drop Initiative|Reduce Attack|Increase Attack|Train Attack|Party Inspire|Disorient All|Jump|Taunt|Rage|Axes|Body Count|Energy Cells|Blank|Poison|Bleed|Weaken|Terrify|Untargetable|Flight|Limit|Initiative",
			skillsBoomer: "Element|Casing|Fuse|Boom Counter|Frag|Big Boom|Smoke Screen|Sonic Cleanse|Stunner|Napalm|Flashbang|Bag’a Booms|Body Search|Bigger Boom|Search for 325|Holy Hand Grenade",
			skillsPatches: "Med Kit|Fast Hands|Bone Saw|Liquid Life|Nutrients|Toxins|Med Pack|Poison Dart|Stim Kit|Chem Kit|Zappack|E-Cells|Distiller|Stim Belt|Chain Reactor|Stim Lethal",
			skillsPicket: "Stand Ground|Shield Form|Redshirt|Orcish Ale|Sword Advance|Lockdown|Intercept|Gobby Jerky|Switch|Rush|Confidence|Tenacity|Riposte|Situational Awareness|Bravado|Renown",
			skillsTantrum: "RAGE!|RAAAGE!|RAAAAAGE!|Anger Management|Like a Wyrm|Like a Wolf|Like a Kobold|Axe Collector|Intimidate|Cripple|Way of the Wild|Horn o’ the Zerker|Innervate|Strengthen|Way of the Ebon|Body Count",
			lootNames: "Flare Distraction|Fortunate Discovery|Fresh Bog Meat|Gadget Arm|Infused Incense|Last Battle Stew|Mechanical Assistance|Mech-pick|Mixed Berries|Multi-tool|Oggot Herbs|Prying Iron|Raider Armor|Red Minotaur|Reflex Powder|Reinforced Buckler|Rusty Optics|Skinning Knife|Sparring Weapon|Spirits of Ebon|Stone Hammer|Tattered Map|Tewaren Gem|Throwing Axe|Treasure Trove Map|Troll Brew|Utility Parts|Zelfey Root|Zelfey Seeds|Bottled Water",
			troveNames: "||Dex Infuser|Exploding Shrooms|Flash Arrows||Grappling Gun|Hunter’s Body Count Necklace|Laser Pointer|Lightning on a Stick|Locksmith Manual|Maximizer Stim|Mechanical Boomerang|Mechanical Squirrel|Micro Neural Implant|Minor Patch Kit|Pip-Loc 2000|Poison Vial Kit|Reflex Powder Tin|Shock Inducer|Shoulder-mounted Rock Slinger|Small Spotting Scope|Utility Belt",
			win: "The Tyrant is defeated. Adventure won!",
			lose: "The day limit is exceeded. Adventure lost."
		}
	}
};
//#endregion
export { Ur as default };
