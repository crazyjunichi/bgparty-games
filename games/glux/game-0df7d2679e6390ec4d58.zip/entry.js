import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useMemo as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as s } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { IconBot as u, IconClose as d } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as f } from "@bgparty/sdk/player-colors";
import { PhaseBanner as p } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as m } from "@bgparty/sdk/ui/game-screen";
import { PlayerStrip as h, seatName as g } from "@bgparty/sdk/ui/player-strip";
import { SheetFxProbe as _, SheetView as v } from "@bgparty/sdk/sheet-view";
import { Fragment as y, jsx as b, jsxs as x } from "react/jsx-runtime";
import { Floater as S, FlySprite as C } from "@bgparty/sdk/fx/primitives";
import { botAvatarOf as w } from "@bgparty/sdk/lobby";
import { AVATARS as T } from "@bgparty/sdk/avatars";
import { Confetti as E } from "@bgparty/sdk/ui/confetti";
//#region src/games/glux/board.ts
var D = (e, t) => `${e},${t}`;
function O(e) {
	let t = e.indexOf(",");
	return [Number(e.slice(0, t)), Number(e.slice(t + 1))];
}
var k = (e, t, n, r) => {
	let i = [];
	for (let a = e; a <= n; a += 1) for (let e = t; e <= r; e += 1) i.push(D(a, e));
	return i;
}, A = (e) => e.map(([e, t]) => D(e, t)), j = {
	kind: "party",
	rows: 16,
	cols: 16,
	rooms: [
		{
			id: 0,
			cells: k(0, 0, 1, 1)
		},
		{
			id: 1,
			cells: k(0, 14, 1, 15)
		},
		{
			id: 2,
			cells: k(14, 0, 15, 1)
		},
		{
			id: 3,
			cells: k(14, 14, 15, 15)
		},
		{
			id: 4,
			cells: A([
				[3, 4],
				[3, 5],
				[4, 4],
				[4, 5],
				[4, 6],
				[5, 4],
				[5, 5]
			])
		},
		{
			id: 5,
			cells: A([
				[3, 10],
				[3, 11],
				[4, 9],
				[4, 10],
				[4, 11],
				[5, 10],
				[5, 11]
			])
		},
		{
			id: 6,
			cells: A([
				[11, 4],
				[11, 5],
				[12, 4],
				[12, 5],
				[12, 6],
				[13, 4],
				[13, 5]
			])
		},
		{
			id: 7,
			cells: A([
				[11, 10],
				[11, 11],
				[12, 9],
				[12, 10],
				[12, 11],
				[13, 10],
				[13, 11]
			])
		},
		{
			id: 8,
			cells: k(7, 1, 9, 2)
		},
		{
			id: 9,
			cells: k(7, 13, 9, 14)
		},
		{
			id: 10,
			cells: k(7, 7, 9, 9)
		}
	],
	centerRoom: 10
}, M = {
	kind: "duel",
	rows: 13,
	cols: 9,
	rooms: [
		{
			id: 0,
			cells: k(0, 0, 1, 1)
		},
		{
			id: 1,
			cells: k(0, 7, 1, 8)
		},
		{
			id: 2,
			cells: k(11, 0, 12, 1)
		},
		{
			id: 3,
			cells: k(11, 7, 12, 8)
		},
		{
			id: 4,
			cells: A([
				[1, 3],
				[1, 4],
				[1, 5],
				[2, 3],
				[2, 4],
				[2, 5],
				[3, 4]
			])
		},
		{
			id: 5,
			cells: A([
				[9, 4],
				[10, 3],
				[10, 4],
				[10, 5],
				[11, 3],
				[11, 4],
				[11, 5]
			])
		},
		{
			id: 6,
			cells: A([
				[4, 0],
				[5, 0],
				[6, 0],
				[7, 0],
				[8, 0],
				[4, 1],
				[6, 1],
				[8, 1]
			])
		},
		{
			id: 7,
			cells: A([
				[4, 8],
				[5, 8],
				[6, 8],
				[7, 8],
				[8, 8],
				[4, 7],
				[6, 7],
				[8, 7]
			])
		},
		{
			id: 8,
			cells: k(5, 3, 7, 5)
		}
	],
	centerRoom: 8
}, N = (e) => e === 2 ? M : j;
function P(e) {
	return e === 2 ? [D(0, 0), D(12, 8)] : e === 3 ? [
		D(0, 15),
		D(15, 15),
		D(8, 1)
	] : [
		D(0, 0),
		D(0, 15),
		D(15, 0),
		D(15, 15)
	];
}
var F = /* @__PURE__ */ new Map();
function I(e, t) {
	let n = F.get(e.kind);
	if (!n) {
		n = /* @__PURE__ */ new Map();
		for (let t of e.rooms) for (let e of t.cells) n.set(e, t.id);
		F.set(e.kind, n);
	}
	return n.get(t);
}
var L = [
	[-1, 0],
	[1, 0],
	[0, -1],
	[0, 1]
];
function R(e, t, n, r, i) {
	let a = /* @__PURE__ */ new Set(), o = new Set(Object.entries(r).filter(([e]) => e !== n).map(([, e]) => e));
	for (let [r, i] of Object.entries(t)) {
		let s = i[i.length - 1];
		if (!s || s.rid !== n) continue;
		let [c, l] = O(r);
		for (let [n, r] of L) {
			let i = !0;
			for (let a = 1; a <= s.value; a += 1) {
				let o = c + n * a, u = l + r * a;
				if (o < 0 || u < 0 || o >= e.rows || u >= e.cols) {
					i = !1;
					break;
				}
				if (a < s.value && (t[D(o, u)]?.length ?? 0) > 0) {
					i = !1;
					break;
				}
			}
			if (!i) continue;
			let u = D(c + n * s.value, l + r * s.value);
			o.has(u) || (t[u]?.length ?? 0) >= 2 || a.add(u);
		}
	}
	let s = t[r[n]]?.length ?? 0;
	return {
		normal: [...a],
		viaStart: !i[n] && s <= 1
	};
}
//#endregion
//#region src/games/glux/meta.ts
var z = {
	id: "glux",
	tier: "beta",
	mechanics: ["tile-placement", "area-control"],
	interactionTags: [],
	nameKey: "games.glux.name",
	descKey: "games.glux.desc",
	rulesKey: "games.glux.rules",
	icon: "💡",
	iconImg: "games/glux.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/glux/en.pdf" },
	precacheAssets: ["board-duel.webp", "board-party.webp"],
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [4],
	accent: "#eab308",
	releasedAt: "2026-09-23",
	search: {
		py: "guang yuan",
		init: "gy"
	},
	hotseat: "cover"
}, B = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("chooseStart"),
		high: t.boolean()
	}),
	t.object({
		type: t.literal("place"),
		key: t.string(),
		high: t.boolean()
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), V = t.string(), H = t.object({
	rid: V,
	value: t.int().min(1).max(6)
}), U = t.object({
	room: t.int().nonnegative(),
	pips: t.record(t.string(), t.int().positive()),
	awards: t.record(t.string(), t.union([t.literal(4), t.literal(2)]))
}), W = t.object({
	board: t.enum(["duel", "party"]),
	phase: t.enum([
		"choose",
		"play",
		"scoring",
		"done"
	]),
	cells: t.record(t.string(), t.array(H)),
	startCells: t.record(t.string(), t.string()),
	players: t.array(t.object({
		rid: V,
		left: t.int().nonnegative(),
		excluded: t.boolean(),
		startUsed: t.boolean(),
		score: t.number()
	})),
	chosen: t.record(t.string(), t.number()),
	turn: V.nullable(),
	lastPlace: t.object({
		rid: V,
		key: t.string()
	}).nullable(),
	revealed: t.array(U),
	roomTotal: t.int().nonnegative()
}), G = t.object({
	hand: t.number().nullable(),
	start: t.number().nullable()
}), K = [
	[1, 6],
	[2, 5],
	[3, 4]
], q = (e, t) => K[e][+!!t], J = 1500;
function ee(t, n, r) {
	let i = N(n.length), a = P(n.length), o = 0, s = {}, c = {}, l = {}, u = {}, d = {}, f = {};
	for (let [t, i] of n.entries()) {
		let n = Array.from({ length: K.length }, (e, t) => Array(8).fill(t)).flat();
		for (let t = n.length - 1; t > 0; --t) {
			let i = e(r, o, t + 1);
			o += 1, [n[t], n[i]] = [n[i], n[t]];
		}
		l[i] = n.pop(), c[i] = n.pop(), s[i] = n, u[i] = a[t], d[i] = !1, f[i] = 0;
	}
	let p = e(r, o, n.length);
	return o += 1, {
		state: {
			players: [...n],
			board: i,
			cells: {},
			startCells: u,
			startUsed: d,
			bags: s,
			hands: c,
			startPairs: l,
			chosen: {},
			excluded: [],
			turn: p,
			phase: "choose",
			scores: f,
			results: [],
			revealed: 0,
			lastPlace: null,
			rngCursor: o,
			beatMs: 0
		},
		fx: []
	};
}
function Y(e, t) {
	let n = {};
	for (let r of t) {
		let t = e[r];
		if (!t || t.length === 0) continue;
		let i = t[t.length - 1];
		n[i.rid] = (n[i.rid] ?? 0) + i.value;
	}
	return n;
}
function te(e) {
	let t = [];
	for (let n of e.board.rooms) {
		let r = Y(e.cells, n.cells), i = Object.entries(r);
		if (i.length === 0) continue;
		let a = i.map(([e, t]) => ({
			rid: e,
			p: t
		})).sort((e, t) => t.p - e.p), o = {}, s = a[0].p, c = a.filter((e) => e.p === s);
		for (let e of c) o[e.rid] = 4;
		if (e.board.kind === "party" && c.length === 1) {
			let e = a.filter((e) => e.p < s);
			if (e.length > 0) {
				let t = e[0].p;
				for (let n of e.filter((e) => e.p === t)) o[n.rid] = 2;
			}
		}
		t.push({
			room: n.id,
			pips: r,
			awards: o
		});
	}
	e.phase = "scoring", e.results = t, e.revealed = 0, e.beatMs = J;
}
function ne(e, t) {
	if (e.players.filter((t) => !e.excluded.includes(t)).every((t) => e.hands[t] == null)) {
		te(e);
		return;
	}
	for (let n = 0; n < e.players.length; n += 1) {
		e.turn = (e.turn + 1) % e.players.length;
		let n = e.players[e.turn];
		if (e.excluded.includes(n) || e.hands[n] == null) continue;
		let r = R(e.board, e.cells, n, e.startCells, e.startUsed);
		if (r.normal.length > 0 || r.viaStart) return;
		e.excluded.push(n), t.push({
			kind: "exclude",
			rid: n
		});
	}
	te(e);
}
function re(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "scoring") return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		if (t.revealed < t.results.length) {
			let e = t.results[t.revealed];
			t.revealed += 1;
			for (let [n, r] of Object.entries(e.awards)) t.scores[n] += r;
			return {
				state: t,
				fx: [{
					kind: "scoreRoom",
					data: e
				}]
			};
		}
		return t.phase = "done", {
			state: t,
			fx: []
		};
	}
	if (t.type === "chooseStart") {
		if (e.phase !== "choose" || n.by in e.chosen) return { code: "games.glux.errNotYourTurn" };
		let r = e.startPairs[n.by];
		if (r == null) return { code: "games.glux.errNoChip" };
		let i = structuredClone(e), a = q(r, t.high);
		i.chosen[n.by] = a;
		let o = [{
			kind: "placeStart",
			rid: n.by,
			data: {
				key: i.startCells[n.by],
				value: a
			}
		}];
		if (Object.keys(i.chosen).length === i.players.length) {
			for (let e of i.players) i.cells[i.startCells[e]] = [{
				rid: e,
				value: i.chosen[e]
			}];
			i.startPairs = {}, i.phase = "play";
		}
		return {
			state: i,
			fx: o
		};
	}
	if (e.phase !== "play" || e.players[e.turn] !== n.by) return { code: "games.glux.errNotYourTurn" };
	let r = e.hands[n.by];
	if (r == null) return { code: "games.glux.errNoChip" };
	let i = R(e.board, e.cells, n.by, e.startCells, e.startUsed), a = t.key === e.startCells[n.by], o = !i.normal.includes(t.key);
	if (o && !(a && i.viaStart)) return { code: "games.glux.errBadCell" };
	let s = structuredClone(e), c = q(r, t.high), l = s.cells[t.key] ?? [];
	l.push({
		rid: n.by,
		value: c
	}), s.cells[t.key] = l, o && (s.startUsed[n.by] = !0), s.hands[n.by] = s.bags[n.by].pop() ?? null, s.lastPlace = {
		rid: n.by,
		key: t.key
	};
	let u = [{
		kind: "place",
		rid: n.by,
		data: {
			key: t.key,
			value: c,
			viaStart: o
		}
	}];
	return ne(s, u), {
		state: s,
		fx: u
	};
}
function ie(e, t) {
	return {
		public: {
			board: e.board.kind,
			phase: e.phase,
			cells: e.cells,
			startCells: e.startCells,
			players: e.players.map((t) => ({
				rid: t,
				left: e.bags[t].length + (e.hands[t] == null ? 0 : 1),
				excluded: e.excluded.includes(t),
				startUsed: e.startUsed[t],
				score: e.scores[t]
			})),
			chosen: e.chosen,
			turn: e.phase === "play" ? e.players[e.turn] : null,
			lastPlace: e.lastPlace,
			revealed: e.results.slice(0, e.revealed),
			roomTotal: e.results.length
		},
		private: {
			hand: e.hands[t] ?? null,
			start: e.phase === "choose" ? e.startPairs[t] ?? null : null
		}
	};
}
function ae(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = e.board.rooms.find((t) => t.id === e.board.centerRoom), n = t ? Y(e.cells, t.cells) : {}, r = new Map(e.players.map((e, t) => [e, t])), i = [...e.players].sort((t, i) => {
		if (e.scores[i] !== e.scores[t]) return e.scores[i] - e.scores[t];
		let a = (n[i] ?? 0) - (n[t] ?? 0);
		return a === 0 ? (r.get(t) ?? 0) - (r.get(i) ?? 0) : a;
	}), a = i[0];
	return {
		phase: "done",
		winner: i.filter((t) => e.scores[t] === e.scores[a] && (n[t] ?? 0) === (n[a] ?? 0)),
		ranking: i,
		scores: { ...e.scores }
	};
}
function oe(e) {
	return e.phase === "scoring" ? e.beatMs : null;
}
var se = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: z,
	schemas: {
		action: B,
		publicView: W,
		privateView: G
	},
	setup: ee,
	reduce: re,
	viewFor: ie,
	status: ae,
	nextTickIn: oe
}, ce = {
	1: [[0, 0]],
	2: [[-.38, -.38], [.38, .38]],
	3: [
		[-.38, -.38],
		[0, 0],
		[.38, .38]
	],
	4: [
		[-.38, -.38],
		[.38, -.38],
		[-.38, .38],
		[.38, .38]
	],
	5: [
		[-.38, -.38],
		[.38, -.38],
		[0, 0],
		[-.38, .38],
		[.38, .38]
	],
	6: [
		[-.38, -.38],
		[.38, -.38],
		[-.38, 0],
		[.38, 0],
		[-.38, .38],
		[.38, .38]
	]
};
function le(e, t) {
	return (ce[e] ?? ce[1]).map(([e, n]) => [e * t, n * t]);
}
function X({ value: e, color: t, radius: n = 18, dim: r = !1 }) {
	let i = n * .92;
	return /* @__PURE__ */ x("g", {
		opacity: r ? .75 : 1,
		children: [
			/* @__PURE__ */ b("circle", {
				cy: n * .16,
				r: n,
				fill: "#06112b"
			}),
			/* @__PURE__ */ b("circle", {
				r: n,
				fill: "#d9e4ec",
				stroke: "#fff8e8",
				strokeWidth: n * .11
			}),
			/* @__PURE__ */ b("circle", {
				r: i,
				fill: t,
				stroke: "#17304c",
				strokeWidth: n * .1
			}),
			/* @__PURE__ */ b("circle", {
				r: n * .77,
				fill: "none",
				stroke: "#ffedb0",
				strokeWidth: n * .055,
				opacity: .85
			}),
			/* @__PURE__ */ b("path", {
				d: `M ${-n * .59} ${-n * .59} l ${n * .16} ${-n * .12} M ${n * .59} ${-n * .59} l ${-n * .16} ${-n * .12} M ${-n * .59} ${n * .59} l ${n * .16} ${n * .12} M ${n * .59} ${n * .59} l ${-n * .16} ${n * .12}`,
				stroke: "#fff5d6",
				strokeWidth: n * .06,
				opacity: .7
			}),
			le(e, n * .57).map(([e, t], r) => /* @__PURE__ */ b("circle", {
				cx: e,
				cy: t,
				r: n * .135,
				fill: "#fffefa"
			}, r))
		]
	});
}
function Z({ value: e, color: t, size: n }) {
	let r = n / 2;
	return /* @__PURE__ */ b("svg", {
		width: n,
		height: n,
		viewBox: `${-r - 2} ${-r - 2} ${n + 4} ${n + 5}`,
		"aria-hidden": !0,
		children: /* @__PURE__ */ b(X, {
			value: e,
			color: t,
			radius: r - 2
		})
	});
}
var ue = 28, de = 48, fe = 34, pe = "#ca6ec8";
function me(e) {
	let t = e.kind === "duel" ? ue : fe, n = e.kind === "duel" ? de : fe;
	return {
		x0: t,
		y0: n,
		w: e.cols * 44 + t * 2,
		h: e.rows * 44 + n * 2
	};
}
function Q(e, t, n) {
	let [r, i] = O(e);
	return {
		x: t + i * 44,
		y: n + r * 44,
		w: 44,
		h: 44
	};
}
function $(e, t, n) {
	let r = Q(e, t, n);
	return [r.x + 22, r.y + 22];
}
function he(e, t, n) {
	let [r, i] = O(n);
	for (let [n, a] of Object.entries(e.cells)) {
		let o = a.at(-1);
		if (!o || o.rid !== t) continue;
		let [s, c] = O(n), l = Math.sign(r - s), u = Math.sign(i - c), d = Math.abs(r - s) + Math.abs(i - c);
		if (l !== 0 && u !== 0 || d !== o.value) continue;
		let f = !1;
		for (let t = 1; t < d; t += 1) if (e.cells[D(s + l * t, c + u * t)]?.length) {
			f = !0;
			break;
		}
		if (!f) return n;
	}
	return null;
}
function ge({ pub: e, colorOf: t, myRid: n, legal: r, specialStartKey: i, onPickCell: a, pending: o, activeRoom: s }) {
	let c = N(e.players.length), { x0: l, y0: u, w: d, h: f } = me(c), p = r?.map((e) => ({
		key: e,
		rect: Q(e, l, u)
	})), m = [.../* @__PURE__ */ new Set([...Object.values(e.startCells), ...Object.keys(e.cells)])], h = s == null ? void 0 : c.rooms.find((e) => e.id === s), g = s == null ? void 0 : e.revealed.find((e) => e.room === s), y = o && o !== i ? he(e, n, o) : null;
	return /* @__PURE__ */ x(v, {
		image: `games/glux/board-${c.kind === "duel" ? "duel" : "party"}.webp`,
		sheetW: d,
		sheetH: f,
		eligible: p,
		onTapEligible: a,
		readOnly: !p?.length,
		fitKey: e.board,
		highlight: "off",
		clampToSheet: !0,
		children: [
			/* @__PURE__ */ b("rect", {
				x: l,
				y: u,
				width: c.cols * 44,
				height: c.rows * 44,
				fill: "#06112b",
				fillOpacity: .34,
				stroke: "#f0bddd",
				strokeWidth: 2
			}),
			c.rooms.map((e) => /* @__PURE__ */ b(Te, {
				room: e,
				center: e.id === c.centerRoom,
				x0: l,
				y0: u
			}, e.id)),
			/* @__PURE__ */ b(De, {
				rows: c.rows,
				cols: c.cols,
				x0: l,
				y0: u
			}),
			Object.entries(e.startCells).map(([n, r]) => {
				let [i, a] = $(r, l, u), o = e.players.find((e) => e.rid === n)?.startUsed ?? !1;
				return /* @__PURE__ */ b(be, {
					x: i,
					y: a,
					color: t(n),
					used: o
				}, n);
			}),
			Object.entries(e.cells).map(([e, n]) => {
				let [r, i] = $(e, l, u);
				return /* @__PURE__ */ b(_e, {
					cellKeyValue: e,
					stack: n,
					x: r,
					y: i,
					colorOf: t
				}, e);
			}),
			r?.map((t) => /* @__PURE__ */ b(xe, {
				cellKeyValue: t,
				x0: l,
				y0: u,
				occupied: !!e.cells[t]?.length,
				special: t === i,
				selected: t === o
			}, t)),
			y && o && /* @__PURE__ */ b(Se, {
				from: $(y, l, u),
				to: $(o, l, u)
			}),
			o && /* @__PURE__ */ b(Ce, {
				point: $(o, l, u),
				color: t(n),
				occupied: !!e.cells[o]?.length
			}, o),
			e.lastPlace && !o && /* @__PURE__ */ b(we, { point: $(e.lastPlace.key, l, u) }, `${e.lastPlace.rid}:${e.lastPlace.key}`),
			h && /* @__PURE__ */ b(Ee, {
				room: h,
				result: g,
				colorOf: t,
				x0: l,
				y0: u,
				boardW: d,
				boardH: f
			}, h.id),
			m.map((e) => /* @__PURE__ */ b(_, {
				name: `cell:${e}`,
				r: Q(e, l, u)
			}, e)),
			m.map((t) => {
				let [n, r] = $(t, l, u), i = (e.cells[t]?.length ?? 0) > 1, a = 14.96;
				return /* @__PURE__ */ b(_, {
					name: `chip:${t}`,
					r: {
						x: n + (i ? 3 : 0) - a,
						y: r + (i ? -5 : 0) - a,
						w: a * 2,
						h: a * 2
					}
				}, `chip:${t}`);
			})
		]
	});
}
function _e({ cellKeyValue: e, stack: t, x: n, y: r, colorOf: i }) {
	let { hidden: a } = o(`cell:${e}`);
	return /* @__PURE__ */ b(ve, {
		stack: t,
		x: n,
		y: r,
		colorOf: i,
		hidden: a
	});
}
function ve({ stack: e, x: t, y: n, colorOf: r, hidden: i = !1 }) {
	return /* @__PURE__ */ b("g", { children: e.map((a, o) => {
		let s = o === e.length - 1, c = e.length > 1 ? s ? 3 : -3 : 0, l = e.length > 1 ? s ? -5 : 5 : 0;
		return /* @__PURE__ */ b("g", {
			opacity: s && i ? 0 : 1,
			transform: `translate(${t + c} ${n + l})`,
			children: /* @__PURE__ */ b(X, {
				value: a.value,
				color: r(a.rid),
				radius: 14.96,
				dim: !s
			})
		}, o);
	}) });
}
function ye({ pub: e, roomId: t, colorOf: n }) {
	let r = N(e.players.length), i = r.rooms.find((e) => e.id === t);
	if (!i) return null;
	let { x0: a, y0: o } = me(r), s = i.cells.map((e) => Q(e, a, o)), c = Math.min(...s.map((e) => e.x)) - 5, l = Math.min(...s.map((e) => e.y)) - 5, u = Math.max(...s.map((e) => e.x + 44)) - c + 5, d = Math.max(...s.map((e) => e.y + 44)) - l + 5;
	return /* @__PURE__ */ x("svg", {
		viewBox: `${c} ${l} ${u} ${d}`,
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ b("rect", {
				x: c,
				y: l,
				width: u,
				height: d,
				rx: 8,
				fill: "#06112b"
			}),
			/* @__PURE__ */ b(Te, {
				room: i,
				center: i.id === r.centerRoom,
				x0: a,
				y0: o
			}),
			i.cells.map((t) => {
				let [r, i] = $(t, a, o);
				return /* @__PURE__ */ b(ve, {
					stack: e.cells[t] ?? [],
					x: r,
					y: i,
					colorOf: n
				}, t);
			})
		]
	});
}
function be({ x: e, y: t, color: n, used: r }) {
	return /* @__PURE__ */ x("g", {
		pointerEvents: "none",
		children: [/* @__PURE__ */ b("circle", {
			cx: e,
			cy: t,
			r: 44 * .43,
			fill: "none",
			stroke: n,
			strokeWidth: 3.5,
			strokeDasharray: r ? void 0 : "5 3",
			opacity: .95
		}), !r && /* @__PURE__ */ b("path", {
			d: `M ${e + 13} ${t - 21} l 2 6 6 2 -6 2 -2 6 -2 -6 -6 -2 6 -2 Z`,
			fill: "#ffe29c",
			stroke: "#192341",
			strokeWidth: 1.3
		})]
	});
}
function xe({ cellKeyValue: e, x0: t, y0: n, occupied: r, special: i, selected: a }) {
	let o = Q(e, t, n), s = o.x + 22, c = o.y + 22;
	return /* @__PURE__ */ x("g", {
		pointerEvents: "none",
		className: a ? "glux-legal glux-legal-selected" : "glux-legal",
		children: [/* @__PURE__ */ b("rect", {
			x: o.x + 4,
			y: o.y + 4,
			width: 36,
			height: 36,
			rx: 5,
			fill: a ? "#fff2b1" : "#b1ffff",
			fillOpacity: r ? .08 : a ? .26 : .16,
			stroke: a ? "#ffe59a" : "#c7ffff",
			strokeWidth: a ? 3 : 2
		}), i ? /* @__PURE__ */ b("path", {
			d: `M ${s + 12} ${c - 18} l 2 5 5 2 -5 2 -2 5 -2 -5 -5 -2 5 -2 Z`,
			fill: "#ffe7a6",
			stroke: "#18243e",
			strokeWidth: 1.4
		}) : r ? /* @__PURE__ */ b("circle", {
			cx: s + 13,
			cy: c - 13,
			r: 3.5,
			fill: "#d9ffff"
		}) : /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("circle", {
			cx: s,
			cy: c,
			r: 4,
			fill: "#efffff"
		}), /* @__PURE__ */ b("circle", {
			cx: s,
			cy: c,
			r: 8,
			fill: "none",
			stroke: "#e5ffff",
			strokeWidth: 1.2
		})] })]
	});
}
function Se({ from: e, to: t }) {
	let [n, r] = e, [i, a] = t, o = Math.sign(i - n), s = Math.sign(a - r);
	return /* @__PURE__ */ x("g", {
		pointerEvents: "none",
		className: "glux-route",
		children: [/* @__PURE__ */ b("line", {
			x1: n + o * 15,
			y1: r + s * 15,
			x2: i - o * 15,
			y2: a - s * 15,
			stroke: "#07172f",
			strokeWidth: 8,
			strokeLinecap: "round",
			opacity: .8
		}), /* @__PURE__ */ b("line", {
			x1: n + o * 15,
			y1: r + s * 15,
			x2: i - o * 15,
			y2: a - s * 15,
			stroke: "#ffed9e",
			strokeWidth: 3,
			strokeLinecap: "round",
			strokeDasharray: "7 4"
		})]
	});
}
function Ce({ point: e, color: t, occupied: n }) {
	let [r, i] = e;
	return /* @__PURE__ */ x("g", {
		transform: `translate(${r} ${i})`,
		pointerEvents: "none",
		className: "glux-pending-chip",
		children: [/* @__PURE__ */ b("circle", {
			r: n ? 17 : 15,
			fill: t,
			fillOpacity: n ? .3 : .42,
			stroke: "#ffedae",
			strokeWidth: 2.3,
			strokeDasharray: "4 3"
		}), /* @__PURE__ */ b("circle", {
			r: 5,
			fill: "#fff9dd",
			opacity: .9
		})]
	});
}
function we({ point: e }) {
	let [t, n] = e;
	return /* @__PURE__ */ b("circle", {
		className: "glux-last-place",
		cx: t,
		cy: n,
		r: 19.8,
		fill: "none",
		stroke: "#ffda73",
		strokeWidth: 3,
		pointerEvents: "none"
	});
}
function Te({ room: e, center: t, x0: n, y0: r }) {
	let i = new Set(e.cells), a = [];
	for (let t of e.cells) {
		let [e, o] = O(t), s = n + o * 44, c = r + e * 44;
		i.has(D(e - 1, o)) || a.push(/* @__PURE__ */ b("line", {
			x1: s + 2,
			y1: c + 2,
			x2: s + 44 - 2,
			y2: c + 2
		}, `${t}t`)), i.has(D(e + 1, o)) || a.push(/* @__PURE__ */ b("line", {
			x1: s + 2,
			y1: c + 44 - 2,
			x2: s + 44 - 2,
			y2: c + 44 - 2
		}, `${t}b`)), i.has(D(e, o - 1)) || a.push(/* @__PURE__ */ b("line", {
			x1: s + 2,
			y1: c + 2,
			x2: s + 2,
			y2: c + 44 - 2
		}, `${t}l`)), i.has(D(e, o + 1)) || a.push(/* @__PURE__ */ b("line", {
			x1: s + 44 - 2,
			y1: c + 2,
			x2: s + 44 - 2,
			y2: c + 44 - 2
		}, `${t}r`));
	}
	let o = t ? "#e9b663" : e.id >= 6 && e.id <= 9 ? "#2ccdbf" : "#4ccbe9";
	return /* @__PURE__ */ x("g", {
		pointerEvents: "none",
		children: [e.cells.map((e) => {
			let { x: i, y: a } = Q(e, n, r);
			return /* @__PURE__ */ x("g", { children: [/* @__PURE__ */ b("rect", {
				x: i + 1,
				y: a + 1,
				width: 42,
				height: 42,
				rx: 2.5,
				fill: o,
				fillOpacity: t ? .42 : .34
			}), /* @__PURE__ */ b("line", {
				x1: i + 6,
				y1: a + 44 - 7,
				x2: i + 44 - 7,
				y2: a + 6,
				stroke: "#e8ffff",
				strokeOpacity: .13,
				strokeWidth: 1.2
			})] }, e);
		}), /* @__PURE__ */ b("g", {
			stroke: t ? "#ffe7b3" : "#dffaff",
			strokeWidth: 2.8,
			strokeLinecap: "round",
			children: a
		})]
	});
}
function Ee({ room: e, result: t, colorOf: n, x0: r, y0: i, boardW: a, boardH: o }) {
	let s = t ? Object.entries(t.pips).sort((e, t) => t[1] - e[1]) : [], c = e.cells.map((e) => $(e, r, i)), l = c.reduce((e, t) => e + t[0], 0) / c.length, u = c.reduce((e, t) => e + t[1], 0) / c.length, d = 20 + s.length * 18, f = Math.max(4, Math.min(a - 112 - 4, l - 56)), p = Math.max(4, Math.min(o - d - 4, u - d / 2));
	return /* @__PURE__ */ x("g", {
		pointerEvents: "none",
		className: "glux-room-reveal",
		children: [e.cells.map((e) => {
			let { x: t, y: n } = Q(e, r, i);
			return /* @__PURE__ */ b("rect", {
				x: t + 2,
				y: n + 2,
				width: 40,
				height: 40,
				rx: 3,
				fill: "#fff2bc",
				fillOpacity: .24
			}, e);
		}), s.length > 0 && /* @__PURE__ */ x("g", {
			className: "glux-room-reveal-readings",
			children: [/* @__PURE__ */ b("rect", {
				x: f,
				y: p,
				width: 112,
				height: d,
				rx: 7,
				fill: "#09162d",
				fillOpacity: .95,
				stroke: "#ffebae",
				strokeWidth: 2
			}), s.map(([e, r], i) => /* @__PURE__ */ x("g", { children: [
				/* @__PURE__ */ b("circle", {
					cx: f + 13,
					cy: p + 15 + i * 18,
					r: 5,
					fill: n(e),
					stroke: "#fff",
					strokeWidth: 1
				}),
				/* @__PURE__ */ b("text", {
					x: f + 27,
					y: p + 19 + i * 18,
					fontSize: 12,
					fontWeight: 800,
					fill: "#f5f9fc",
					children: r
				}),
				/* @__PURE__ */ b("text", {
					x: f + 91,
					y: p + 19 + i * 18,
					textAnchor: "end",
					fontSize: 11,
					fontWeight: 800,
					fill: "#ffe19a",
					children: t?.awards[e] ? `+${t.awards[e]}` : "—"
				})
			] }, e))]
		})]
	});
}
function De({ rows: e, cols: t, x0: n, y0: r }) {
	let i = [];
	for (let a = 0; a <= t; a += 1) i.push(/* @__PURE__ */ b("line", {
		x1: n + a * 44,
		y1: r,
		x2: n + a * 44,
		y2: r + e * 44
	}, `v${a}`));
	for (let a = 0; a <= e; a += 1) i.push(/* @__PURE__ */ b("line", {
		x1: n,
		y1: r + a * 44,
		x2: n + t * 44,
		y2: r + a * 44
	}, `h${a}`));
	return /* @__PURE__ */ b("g", {
		stroke: pe,
		strokeWidth: 1,
		opacity: .54,
		pointerEvents: "none",
		children: i
	});
}
//#endregion
//#region src/games/glux/view-player.tsx
function Oe(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ b(Ae, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function ke(e, t) {
	let r = i(null);
	return n(() => {
		let n = r.current, i = n?.querySelector(".game-screen-layout");
		if (!n || !i) return;
		let a = window.matchMedia("(orientation: landscape)"), o = [
			"--glux-pad",
			"--glux-gap",
			"--glux-board-width",
			"--glux-board-height",
			"--glux-info-width",
			"--glux-info-height",
			"--glux-action-width",
			"--glux-action-height",
			"--glux-phase-height",
			"--glux-phase-font",
			"--glux-player-cols",
			"--glux-player-rows",
			"--glux-avatar-size",
			"--glux-name-font",
			"--glux-status-font",
			"--glux-player-gap",
			"--glux-tray-font",
			"--glux-chip-size",
			"--glux-face-size",
			"--glux-cancel-size",
			"--glux-result-top",
			"--glux-score-row-height",
			"--glux-score-title-font",
			"--glux-score-name-font",
			"--glux-score-value-font"
		], s = () => {
			delete n.dataset.gluxLayout, delete n.dataset.gluxResultLayout, delete n.dataset.gluxPlayerLayout;
			for (let e of o) i.style.removeProperty(e);
		}, c = (e, t, n = "px") => {
			let r = n ? `${t.toFixed(4)}${n}` : String(t);
			i.style.getPropertyValue(e) !== r && i.style.setProperty(e, r);
		}, l = (e, t, n) => Math.min(n, Math.max(e, t)), u = () => {
			let { width: r, height: i } = n.getBoundingClientRect();
			if (!a.matches || r < 900 || i < 400) {
				s();
				return;
			}
			let o = l(6, Math.min(r, i) * .01, 12), u = l(6, Math.min(r, i) * .012, 14), d = r - 2 * o, f = i - 2 * o, [p, m] = e === "duel" ? [452, 668] : [772, 772], h = (f - 4) * p / m + 4, g = Math.max(264, d * .28), _ = h, v = f, y, b = f, x, S = f, C;
			if (d - h - 2 * u >= 520 && f >= t * 180) C = "flanks", y = (d - h - 2 * u) / 2, x = y;
			else {
				let e = Math.min((d - g - u - 4) / p, (f - 4) / m);
				_ = p * e + 4, v = m * e + 4;
				let t = f - v - u;
				y = d - _ - u, t >= Math.max(148, f * .18) ? (C = "shelf", x = _, S = t) : (C = "rail", x = y, S = Math.max(174, Math.min(f * .38, y * .65)), b = f - S - u);
			}
			let w = Math.max(58, b * .13), T = l(6, f * .012, 14), E = C === "rail" && y >= 380 ? 2 : 1, D = Math.ceil(t / E), O = (y - 12 - (E - 1) * T) / E, k = (b - w - u - 12 - (D - 1) * T) / D, A = C !== "flanks" && k >= 220 && k >= O * .72, j = C === "flanks" ? Math.min(O * .64, k * (t > 2 ? .38 : .48)) : Math.min(O * .28, k - 24), M = Math.max(16, Math.min(O * .085, k * (C === "flanks" ? .12 : .17))), N = A ? Math.max(M, 18, Math.min(O * .12, k * .09)) : M, P = Math.max(16, N * .84), F = A ? Math.min(O * .82, k - 22 - T - 6 - N * 1.25 - P * 2.5 - 2) : j, I = Math.max(18, Math.min(x * .075, S * (C === "flanks" ? .1 : .12))), L = Math.max(48, Math.min(x * .17, S * .12)), R = C === "flanks" ? Math.min(x - 32, (S - I * 3.75 - L - 3 * u - 32) / 2) : C === "shelf" ? Math.min(S - 32, (x - Math.max(120, x * .22) - L - 4 * u - 32) / 2) : Math.min((x - L - 3 * u - 32) / 2, S - I * 2.5 - u - 32), z = x >= 420 && S < x * .8, B = z ? "side" : S >= 300 ? "stack" : "compact", V = z ? (x - 36) * .6 : x - 24, H = Math.max(16, Math.min(V * .08, S * .045, 32)), U = S - 24 - H * 1.25 - 8 - (t - 1) * 4, W = B === "stack" ? Math.min(V * .28, U * .55 / t) : U / t, G = {
				"--glux-pad": o,
				"--glux-gap": u,
				"--glux-board-width": _,
				"--glux-board-height": v,
				"--glux-info-width": y,
				"--glux-info-height": b,
				"--glux-action-width": x,
				"--glux-action-height": S,
				"--glux-phase-height": w,
				"--glux-phase-font": Math.max(16, Math.min(y * .075, w * .27)),
				"--glux-avatar-size": Math.max(44, F),
				"--glux-name-font": N,
				"--glux-status-font": P,
				"--glux-player-gap": T,
				"--glux-tray-font": I,
				"--glux-chip-size": Math.max(48, R - 12),
				"--glux-face-size": Math.max(56, R),
				"--glux-cancel-size": L,
				"--glux-result-top": o + (C === "flanks" ? 0 : (C === "rail" ? b : v) + u),
				"--glux-score-row-height": W,
				"--glux-score-title-font": H,
				"--glux-score-name-font": Math.max(16, Math.min(V * .085, W * .34)),
				"--glux-score-value-font": Math.max(22, Math.min(V * .16, W * .65))
			};
			n.dataset.gluxResultLayout !== B && (n.dataset.gluxResultLayout = B);
			let K = A ? "stack" : "row";
			n.dataset.gluxPlayerLayout !== K && (n.dataset.gluxPlayerLayout = K), n.dataset.gluxLayout !== C && (n.dataset.gluxLayout = C);
			for (let [e, t] of Object.entries(G)) c(e, t);
			c("--glux-player-cols", E, ""), c("--glux-player-rows", D, "");
		}, d = new ResizeObserver(u);
		return d.observe(n), a.addEventListener("change", u), u(), () => {
			d.disconnect(), a.removeEventListener("change", u), s();
		};
	}, [e, t]), r;
}
function Ae({ pub: e, priv: t, members: n, myRid: i, send: c }) {
	let u = l(), g = ke(e.board, n.length), _ = (e) => n.find((t) => t.rid === e)?.name ?? e, v = (e) => {
		let t = n.find((t) => t.rid === e);
		return f[(t?.colorIndex ?? 0) % f.length].hex;
	}, { ref: S } = o("board"), C = e.players.find((e) => e.rid === i), w = e.phase === "play" && e.turn === i && !C?.excluded, T = e.chosen[i] !== void 0, E = r(() => {
		if (!w || t?.hand == null) return null;
		let n = N(e.players.length), r = {};
		for (let t of e.players) r[t.rid] = t.startUsed;
		let a = R(n, e.cells, i, e.startCells, r), o = [...a.normal];
		return a.viaStart && !o.includes(e.startCells[i]) && o.push(e.startCells[i]), {
			keys: o,
			viaStartForced: a.normal.length === 0 && a.viaStart,
			specialStartKey: a.viaStart && !a.normal.includes(e.startCells[i]) ? e.startCells[i] : null
		};
	}, [
		w,
		t?.hand,
		e,
		i
	]), [D, O] = a(null), k = `${e.phase}:${e.turn}:${t?.hand}:${C?.excluded}`, [A, j] = a(k);
	A !== k && (j(k), O(null));
	let M, P;
	e.phase === "choose" ? (M = T ? "info" : "accent", P = u(T ? "games.glux.chooseWaiting" : "games.glux.choosePrompt")) : e.phase === "play" ? C?.excluded ? (M = "warn", P = u("games.glux.excludedBanner")) : w ? (M = "accent", P = E?.viaStartForced ? u("games.glux.startOnlyPrompt") : u("games.glux.placePrompt")) : (M = "info", P = u("games.glux.placeWaiting", { name: _(e.turn ?? "") })) : (M = "info", P = u("games.glux.scoring", {
		n: e.revealed.length,
		total: e.roomTotal
	}));
	let F = e.phase === "scoring" || e.phase === "done" ? e.revealed[e.revealed.length - 1]?.room ?? null : null, I = e.phase === "scoring" ? e.revealed.at(-1) : void 0, L = v(i), B = /* @__PURE__ */ x("div", {
		className: "glux-banner flex flex-col gap-2",
		children: [/* @__PURE__ */ b(p, {
			tone: M,
			text: P,
			accent: z.accent
		}), /* @__PURE__ */ b("div", {
			className: "glux-players",
			children: /* @__PURE__ */ b(h, {
				variant: "plate",
				members: n,
				myRid: i,
				anchorOf: (e) => `seat:${e}`,
				action: (t) => e.phase === "choose" ? e.chosen[t] === void 0 ? "pending" : "done" : e.phase === "play" && e.turn === t ? "pending" : null,
				status: (t) => {
					let n = e.players.find((e) => e.rid === t);
					return n ? /* @__PURE__ */ x("span", {
						className: "glux-player-status flex items-center gap-1.5 text-xs leading-4.5 font-bold",
						children: [
							/* @__PURE__ */ b("span", {
								className: "font-mono tabular-nums",
								children: u("games.glux.chipsLeft", { n: n.left })
							}),
							(e.phase === "scoring" || e.phase === "done" || n.score > 0) && /* @__PURE__ */ x("span", {
								className: "font-mono tabular-nums text-amber-600",
								children: ["★", /* @__PURE__ */ b(s, {
									value: n.score,
									className: "font-mono tabular-nums"
								})]
							}),
							n.excluded && /* @__PURE__ */ b("span", {
								className: "rounded-md bg-ink/10 px-1",
								children: u("games.glux.excludedBadge")
							})
						]
					}) : null;
				}
			})
		})]
	}), V = /* @__PURE__ */ x("div", {
		className: "glux-control-tray",
		children: [
			e.phase === "choose" && t?.start != null && !T && /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("span", {
				className: "glux-tray-label",
				children: u("games.glux.chooseFaceLabel")
			}), /* @__PURE__ */ b("div", {
				className: "glux-tray-well glux-tray-well-pair",
				children: /* @__PURE__ */ b(je, {
					pair: t.start,
					color: L,
					onPick: (e) => c({
						type: "chooseStart",
						high: e
					})
				})
			})] }),
			e.phase === "choose" && T && e.chosen[i] !== void 0 && /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b(Z, {
				value: e.chosen[i],
				color: L,
				size: 46
			}), /* @__PURE__ */ b("span", {
				className: "glux-tray-label",
				children: u("games.glux.chooseWaiting")
			})] }),
			w && t?.hand != null && D == null && /* @__PURE__ */ x(y, { children: [
				/* @__PURE__ */ b("span", {
					className: "glux-tray-label",
					children: E?.specialStartKey ? u("games.glux.startOptionHint") : u("games.glux.handLabel")
				}),
				/* @__PURE__ */ b("div", {
					className: "glux-tray-well",
					children: /* @__PURE__ */ b(Z, {
						value: q(t.hand, !1),
						color: L,
						size: 48
					})
				}),
				/* @__PURE__ */ x("span", {
					className: "glux-hand-pair font-mono tabular-nums",
					children: [
						q(t.hand, !1),
						" / ",
						q(t.hand, !0)
					]
				})
			] }),
			w && t?.hand != null && D != null && /* @__PURE__ */ x(y, { children: [
				/* @__PURE__ */ b("span", {
					className: "glux-tray-label",
					children: u("games.glux.chooseFaceLabel")
				}),
				/* @__PURE__ */ b("div", {
					className: "glux-tray-well glux-tray-well-pair",
					children: /* @__PURE__ */ b(je, {
						pair: t.hand,
						color: L,
						onPick: (e) => c({
							type: "place",
							key: D,
							high: e
						})
					})
				}),
				/* @__PURE__ */ b("button", {
					type: "button",
					"aria-label": u("games.glux.cancelPick"),
					onClick: () => O(null),
					className: "glux-cancel-pick",
					children: /* @__PURE__ */ b(d, { size: 20 })
				})
			] }),
			e.phase !== "choose" && !w && /* @__PURE__ */ b("span", {
				className: "glux-tray-label glux-tray-idle",
				children: e.phase === "play" ? u("games.glux.placeWaiting", { name: _(e.turn ?? "") }) : u("games.glux.scoring", {
					n: e.revealed.length,
					total: e.roomTotal
				})
			})
		]
	}), H = I && /* @__PURE__ */ x("div", {
		className: "glux-score-overlay",
		children: [
			/* @__PURE__ */ b("div", {
				className: "glux-score-title text-xs font-extrabold",
				children: u("games.glux.roomReveal")
			}),
			/* @__PURE__ */ b("div", {
				className: "glux-score-visual",
				children: /* @__PURE__ */ b(ye, {
					pub: e,
					roomId: I.room,
					colorOf: v
				})
			}),
			/* @__PURE__ */ x("div", {
				className: "glux-score-list",
				children: [Object.entries(I.pips).sort((e, t) => t[1] - e[1]).map(([e, t]) => /* @__PURE__ */ x("div", {
					className: "glux-score-row font-mono tabular-nums",
					children: [
						/* @__PURE__ */ b("span", {
							className: "glux-score-dot",
							style: { background: v(e) }
						}),
						/* @__PURE__ */ b("span", {
							className: "glux-score-name max-w-28 truncate",
							title: _(e),
							children: _(e)
						}),
						/* @__PURE__ */ b("span", {
							className: "glux-score-value",
							children: t
						}),
						/* @__PURE__ */ b("span", {
							className: "glux-score-award",
							children: I.awards[e] ? `+${I.awards[e]}` : "—"
						})
					]
				}, e)), Object.keys(I.pips).length === 0 && /* @__PURE__ */ b("p", {
					className: "glux-score-empty",
					children: u("games.glux.roomEmpty")
				})]
			})
		]
	});
	return /* @__PURE__ */ b("div", {
		ref: g,
		className: "glux-screen h-full min-h-0",
		"data-glux-scoring": !!I,
		children: /* @__PURE__ */ b(m, {
			adaptive: !0,
			banner: B,
			actions: V,
			actionsHeight: "h-20",
			overlay: H,
			scroll: !1,
			children: /* @__PURE__ */ b("div", {
				ref: S,
				className: "glux-board-frame h-full min-h-0 overflow-hidden",
				children: /* @__PURE__ */ b(ge, {
					pub: e,
					colorOf: v,
					myRid: i,
					legal: E?.keys,
					specialStartKey: E?.specialStartKey,
					onPickCell: (e) => O(e),
					pending: D,
					activeRoom: F
				})
			})
		})
	});
}
function je({ pair: e, color: t, onPick: n }) {
	let r = l();
	return /* @__PURE__ */ b(y, { children: [!1, !0].map((i) => /* @__PURE__ */ b("button", {
		type: "button",
		"aria-label": r("games.glux.faceAria", { n: q(e, i) }),
		onClick: () => n(i),
		className: "glux-face-button",
		children: /* @__PURE__ */ b(Z, {
			value: q(e, i),
			color: t,
			size: 48
		})
	}, String(i))) });
}
//#endregion
//#region src/games/glux/bot.ts
function Me(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var Ne = (e, t) => {
	let n = e.public, r = e.private;
	if (n.phase === "choose") return n.chosen[t.rid] !== void 0 || r?.start == null ? null : { action: {
		type: "chooseStart",
		high: t.difficulty !== "weak" || Me([!0, !1])
	} };
	if (n.phase !== "play" || n.turn !== t.rid) return null;
	let i = r?.hand;
	if (i == null || n.players.find((e) => e.rid === t.rid)?.excluded) return null;
	let a = N(n.players.length), o = {};
	for (let e of n.players) o[e.rid] = e.startUsed;
	let s = R(a, n.cells, t.rid, n.startCells, o), c = s.normal.length > 0 ? s.normal : s.viaStart ? [n.startCells[t.rid]] : [];
	if (c.length === 0) return null;
	let l = c.flatMap((e) => [{
		key: e,
		high: !1
	}, {
		key: e,
		high: !0
	}]);
	if (t.difficulty === "weak") {
		let e = Me(l);
		return { action: {
			type: "place",
			key: e.key,
			high: e.high
		} };
	}
	let u = (e) => {
		let t = a.rooms.find((t) => t.id === e), r = {};
		if (!t) return r;
		for (let e of t.cells) {
			let t = n.cells[e];
			if (!t || t.length === 0) continue;
			let i = t[t.length - 1];
			r[i.rid] = (r[i.rid] ?? 0) + i.value;
		}
		return r;
	}, d = l[0], f = -Infinity;
	for (let e of l) {
		let r = q(i, e.high), o = r * .4, s = I(a, e.key);
		if (s !== void 0) {
			let e = u(s), n = e[t.rid] ?? 0, i = Math.max(0, ...Object.entries(e).filter(([e]) => e !== t.rid).map(([, e]) => e));
			o = 2 * r, n + r > i ? o += 4 : i - (n + r) <= 3 && (o += 2);
		}
		let c = n.cells[e.key]?.[0];
		c && (o += c.rid === t.rid ? -.8 * c.value : 1.2 * c.value), o += crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32, o > f && (f = o, d = e);
	}
	return { action: {
		type: "place",
		key: d.key,
		high: d.high
	} };
}, Pe = (e, t, n) => {
	if (e.type === "chooseStart") {
		let r = t.private?.start;
		return r == null ? "" : n("games.glux.hintChoose", { n: q(r, e.high) });
	}
	if (e.type === "place") {
		let r = t.private?.hand;
		if (r == null) return "";
		let [i, a] = O(e.key);
		return n("games.glux.hintPlace", {
			n: q(r, e.high),
			row: i + 1,
			col: a + 1
		});
	}
	return "";
};
//#endregion
//#region src/games/glux/fx.tsx
function Fe(e, t) {
	let n = t ? e.member(t) : void 0;
	return f[(n?.colorIndex ?? 0) % f.length].hex;
}
function Ie(e, t, n) {
	let r = e.data;
	if (typeof r?.value != "number" || !e.rid) return null;
	let i = t.anchor(`seat:${e.rid}`), a = typeof r.key == "string" ? t.anchor(`chip:${r.key}`) : null;
	if (!i || !a) return null;
	let o = t.queued > 0, s = Math.min(i.w, i.h), c = 14.96;
	return {
		ms: o ? 220 : n,
		hide: typeof r.key == "string" && !o ? [`cell:${r.key}`] : void 0,
		node: /* @__PURE__ */ b(C, {
			from: i,
			to: a,
			ms: o ? 180 : Math.min(420, n - 80),
			children: /* @__PURE__ */ b("div", {
				style: {
					width: s,
					height: s
				},
				children: /* @__PURE__ */ b("svg", {
					width: "100%",
					height: "100%",
					viewBox: `-14.96 -14.96 ${c * 2} ${c * 2}`,
					style: { overflow: "visible" },
					"aria-hidden": !0,
					children: /* @__PURE__ */ b(X, {
						value: r.value,
						color: Fe(t, e.rid),
						radius: c
					})
				})
			})
		})
	};
}
var Le = {
	placeStart: (e, t) => Ie(e, t, 500),
	place: (e, t) => Ie(e, t, 500),
	exclude(e, t) {
		if (!e.rid) return null;
		let n = t.anchor(`seat:${e.rid}`);
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ b(S, {
				at: n,
				ms: 900,
				children: /* @__PURE__ */ b("span", {
					className: "font-display font-extrabold text-ink/60",
					style: { fontSize: Math.max(18, Math.min(n.w, n.h) * .45) },
					children: "✕"
				})
			})
		} : null;
	},
	scoreRoom(e, t) {
		let n = e.data;
		if (!n?.awards || typeof n.awards != "object") return null;
		let r = [], i = 0;
		for (let [e, a] of Object.entries(n.awards)) {
			let n = t.anchor(`seat:${e}`);
			n && (r.push(/* @__PURE__ */ b(S, {
				at: n,
				ms: 1100,
				delay: i * 150,
				children: /* @__PURE__ */ x("span", {
					className: "font-display font-extrabold text-amber-500",
					style: { fontSize: Math.max(18, Math.min(n.w, n.h) * .45) },
					children: ["+", a]
				})
			}, e)), i += 1);
		}
		return r.length ? {
			ms: J,
			node: r
		} : {
			ms: 700,
			node: null
		};
	}
}, Re = [
	"games.glux.roomTopLeftCorner",
	"games.glux.roomTopRightCorner",
	"games.glux.roomBottomLeftCorner",
	"games.glux.roomBottomRightCorner"
], ze = [
	...Re,
	"games.glux.roomTop",
	"games.glux.roomBottom",
	"games.glux.roomLeft",
	"games.glux.roomRight",
	"games.glux.roomCenter"
], Be = [
	...Re,
	"games.glux.roomTopLeft",
	"games.glux.roomTopRight",
	"games.glux.roomBottomLeft",
	"games.glux.roomBottomRight",
	"games.glux.roomLeft",
	"games.glux.roomRight",
	"games.glux.roomCenter"
];
function Ve(e) {
	let t = i(null);
	return n(() => {
		let n = t.current, r = n?.querySelector(".game-screen-layout");
		if (!n || !r) return;
		let i = window.matchMedia("(orientation: landscape)"), a = [
			"--glux-over-gap",
			"--glux-over-top",
			"--glux-over-bottom",
			"--glux-over-board-width",
			"--glux-over-board-height",
			"--glux-over-rank-cols",
			"--glux-over-rank-height",
			"--glux-over-avatar",
			"--glux-over-name-font",
			"--glux-over-score-font",
			"--glux-over-ledger-font",
			"--glux-over-ledger-name-font",
			"--glux-over-room-height",
			"--glux-over-room-cols",
			"--glux-over-room-title-font",
			"--glux-over-room-row-height"
		], o = (e, t, n = "px") => {
			let i = n ? `${t.toFixed(4)}${n}` : String(t);
			r.style.getPropertyValue(e) !== i && r.style.setProperty(e, i);
		}, s = () => {
			let { width: t, height: r } = n.getBoundingClientRect(), a = Math.max(8, Math.min(16, Math.min(t, r) * .012)), s = Math.max(64, Math.min(104, r * .1)), c = Math.max(60, Math.min(88, r * .09)), l = Math.max(0, r - s - c - 2 * a), u = i.matches && t >= 760 && r >= 280, [d, f] = e === 2 ? [452, 668] : [772, 772], p = Math.max(e === 2 ? 300 : 310, t * (e === 2 ? .34 : .37)), m = u ? Math.min((l - 4) / f, (t - p - a - 4) / d) : (t - 4) / d, h = d * m + 4, g = f * m + 4, _ = u ? t - h - a : t, v = _ >= e * 150 || u && l < 430 && _ >= e * 108 ? e : e === 4 ? 2 : Math.min(e, Math.max(1, Math.floor(_ / 150))), y = Math.ceil(e / v), b = u ? l < 260 ? 64 : Math.max(100, Math.min(160, l * .19)) : 100, x = b * y + (y - 1) * 8, S = (_ - (v - 1) * 8) / v, C = u ? _ >= 1e3 && e === 2 ? 3 : _ >= 650 ? 2 : 1 : 1, w = (_ - 24 - (C - 1) * 8) / C, T = u && !(l < 260) && w >= 285, E = T ? (w - 24) * .6 : w - 16, D = u ? Math.max(22, Math.min(32, E * .13)) : 16, O = u ? Math.max(16, Math.min(20, E * .08)) : 14, k = u ? Math.max(16, Math.min(24, w * .065)) : 16, A = u ? Math.max(34, D * 1.2 + 6) : 28, j = Math.max(T ? e === 2 ? 200 : 230 : 44, 16 + k * 1.25 + 8 + e * A + (e - 1) * 4), M = {
				"--glux-over-gap": a,
				"--glux-over-top": s,
				"--glux-over-bottom": c,
				"--glux-over-board-width": h,
				"--glux-over-board-height": g,
				"--glux-over-rank-height": x,
				"--glux-over-avatar": Math.max(28, Math.min(64, b * .36)),
				"--glux-over-name-font": Math.max(16, Math.min(S * .11, b * .17)),
				"--glux-over-score-font": Math.max(28, Math.min(S * .21, b * .35)),
				"--glux-over-ledger-font": D,
				"--glux-over-ledger-name-font": O,
				"--glux-over-room-height": j,
				"--glux-over-room-title-font": k,
				"--glux-over-room-row-height": A
			}, N = u ? "side" : "stack", P = String(u && b < 100), F = T ? "preview" : "compact";
			n.dataset.gluxOverLayout !== N && (n.dataset.gluxOverLayout = N), n.dataset.gluxOverCompact !== P && (n.dataset.gluxOverCompact = P), n.dataset.gluxOverLedger !== F && (n.dataset.gluxOverLedger = F);
			for (let [e, t] of Object.entries(M)) o(e, t);
			o("--glux-over-rank-cols", v, ""), o("--glux-over-room-cols", C, "");
		}, c = new ResizeObserver(s);
		return c.observe(n), i.addEventListener("change", s), s(), () => {
			c.disconnect(), i.removeEventListener("change", s), delete n.dataset.gluxOverLayout, delete n.dataset.gluxOverCompact, delete n.dataset.gluxOverLedger;
			for (let e of a) r.style.removeProperty(e);
		};
	}, [e]), t;
}
function He({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: o }) {
	let s = t, d = l(), p = c((e) => e.locale), h = Ve(s.players.length), _ = N(s.players.length), [v, y] = a(null), S = s.board === "duel" ? ze : Be, C = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? g(t, p) : e;
	}, D = (e) => f[(n.find((t) => t.rid === e)?.colorIndex ?? 0) % f.length].hex;
	return /* @__PURE__ */ x("div", {
		ref: h,
		className: "glux-over",
		style: { "--glux-over-accent": z.accent },
		children: [e.winner.length > 0 && /* @__PURE__ */ b(E, {}), /* @__PURE__ */ b(m, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ x("header", {
				className: "glux-over-heading",
				children: [/* @__PURE__ */ b("h1", { children: d("session.result.title") }), e.winner.length > 0 && /* @__PURE__ */ b("p", {
					title: e.winner.map(C).join(" / "),
					children: d("games.glux.matchWinner", { name: e.winner.map(C).join(" / ") })
				})]
			}),
			actionsHeight: "glux-over-actions-height",
			actions: i || o ? /* @__PURE__ */ x("div", {
				className: "glux-over-actions",
				children: [i && /* @__PURE__ */ b("button", {
					type: "button",
					onClick: i,
					children: d("session.result.playAgain")
				}), o && /* @__PURE__ */ b("button", {
					type: "button",
					onClick: o,
					children: d("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ b("p", {
				className: "glux-over-wait",
				children: d("session.result.waitHost")
			}),
			children: /* @__PURE__ */ x("div", {
				className: "glux-over-main",
				children: [/* @__PURE__ */ b("div", {
					className: "glux-over-board glux-board-frame",
					children: /* @__PURE__ */ b(ge, {
						pub: s,
						colorOf: D,
						myRid: r,
						activeRoom: v
					})
				}), /* @__PURE__ */ x("div", {
					className: "glux-over-details",
					children: [/* @__PURE__ */ b("ol", {
						className: "glux-over-ranking",
						"aria-label": d("games.glux.matchRanking"),
						children: e.ranking.map((t, i) => {
							let a = n.find((e) => e.rid === t), o = e.winner.includes(t), c = e.autopilot?.[t], l = s.revealed.reduce((e, n) => e + (n.awards[t] ?? 0), 0);
							return /* @__PURE__ */ x("li", {
								"data-winner": o,
								"data-awarded": l,
								"data-result": e.scores?.[t],
								children: [/* @__PURE__ */ x("div", {
									className: "glux-over-rank-person",
									children: [/* @__PURE__ */ x("span", {
										className: "glux-over-avatar",
										style: { background: D(t) },
										children: [a && /* @__PURE__ */ b("img", {
											src: T[a.avatar % T.length],
											alt: "",
											draggable: !1
										}), o && /* @__PURE__ */ b("b", {
											"aria-label": d("games.glux.matchWinnerMark"),
											children: "👑"
										})]
									}), /* @__PURE__ */ x("span", {
										className: "glux-over-rank-name",
										children: [/* @__PURE__ */ b("strong", {
											title: C(t),
											children: C(t)
										}), /* @__PURE__ */ x("span", {
											className: "glux-over-badges",
											children: [
												t === r && /* @__PURE__ */ b("span", { children: d("lobby.you") }),
												w(t) !== null && /* @__PURE__ */ b("span", { children: d("lobby.bot") }),
												c !== void 0 && c > 0 && /* @__PURE__ */ x("span", {
													className: "glux-over-autopilot",
													title: d("session.autopilot.share", { n: Math.round(c * 100) }),
													children: [/* @__PURE__ */ b(u, { size: 12 }), /* @__PURE__ */ b("span", { children: d("session.autopilot.share", { n: Math.round(c * 100) }) })]
												})
											]
										})]
									})]
								}), /* @__PURE__ */ x("div", {
									className: "glux-over-rank-score",
									children: [/* @__PURE__ */ b("span", { children: [
										"🥇",
										"🥈",
										"🥉"
									][i] ?? i + 1 }), /* @__PURE__ */ x("strong", {
										className: "font-mono tabular-nums",
										children: [e.scores?.[t] ?? "—", /* @__PURE__ */ b("small", { children: d("games.glux.victoryPoints") })]
									})]
								})]
							}, t);
						})
					}), /* @__PURE__ */ x("section", {
						className: "glux-over-ledger",
						children: [/* @__PURE__ */ b("h2", { children: d("games.glux.roomLedger") }), /* @__PURE__ */ b("div", {
							className: "glux-over-ledger-scroll",
							children: /* @__PURE__ */ b("div", {
								className: "glux-over-rooms",
								children: _.rooms.map((t) => {
									let n = s.revealed.find((e) => e.room === t.id);
									return /* @__PURE__ */ x("button", {
										type: "button",
										className: "glux-over-room",
										"aria-pressed": v === t.id,
										onClick: () => y(v === t.id ? null : t.id),
										children: [
											/* @__PURE__ */ b("strong", {
												className: "glux-over-room-title",
												children: d(S[t.id])
											}),
											/* @__PURE__ */ b("span", {
												className: "glux-over-room-visual",
												children: /* @__PURE__ */ b(ye, {
													pub: s,
													roomId: t.id,
													colorOf: D
												})
											}),
											/* @__PURE__ */ b("span", {
												className: "glux-over-room-players",
												children: e.ranking.map((e) => /* @__PURE__ */ x("span", {
													className: "glux-over-room-player",
													children: [
														/* @__PURE__ */ b("i", { style: { background: D(e) } }),
														/* @__PURE__ */ b("span", {
															className: "glux-over-room-name",
															title: C(e),
															children: C(e)
														}),
														/* @__PURE__ */ b("span", {
															className: "glux-over-room-pips font-mono tabular-nums",
															"data-pips": n?.pips[e],
															children: n?.pips[e] ?? "—"
														}),
														/* @__PURE__ */ b("b", {
															className: "glux-over-room-award font-mono tabular-nums",
															"data-award": n?.awards[e] ?? 0,
															children: n?.awards[e] ? `+${n.awards[e]}` : "—"
														})
													]
												}, e))
											})
										]
									}, t.id);
								})
							})
						})]
					})]
				})]
			})
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/glux/entry.tsx
var Ue = {
	definition: se,
	View: Oe,
	bot: Ne,
	describe: Pe,
	fx: Le,
	OverView: He,
	locales: {
		zh: {
			name: "光源",
			desc: "直线数格点亮版图,逐房间比拼点数",
			rules: "目标:所有房间结算后,胜利分最高者获胜。\n准备:\n· 2 人用斜对角,3-4 人用四角等指定格放起始标记。\n· 每人 24 枚双面筹码(1/6、2/5、3/4 各 8 枚)。\n· 抽 1 枚自选一面放到起始标记上,再抽 1 枚扣在手中。\n流程:\n· 回合内先放后抽:从自己场上一枚顶层筹码出发,沿横或竖的直线数出等于其点数的格数。\n· 把手中筹码放到数出的落点,任选一面朝上。\n· 起点与落点之间有任意筹码则该方向被挡,出界也不行。\n· 落点已有 1 枚筹码(任何人的)可以叠放,已有 2 枚则不行;叠放后只有顶层筹码参与计分。\n· 落点不能是他人的起始标记;整局限一次,可不经计数直接把手中筹码叠到自己的起始标记上。\n· 不能跳过;无法合法放置时必须用掉那次免计数机会,机会已用过则出局,只等终局结算。\n结算:\n· 所有玩家无筹码可抽,或无人能放置时,逐房间结算。\n· 按各自顶层筹码点数总和排名。\n· 第 1 名 4 分、第 2 名 2 分(2 人局只发第 1 名)。\n· 并列第 1 名则都获得 4 分且不发第 2 名的分,并列第 2 名则都获得 2 分。\n· 房间里没有筹码的玩家不参与该房间排名。\n· 总分最高者胜;平分则中央 9 格房间点数多者胜,仍平分则共享胜利。",
			choosePrompt: "选起始筹码朝上的一面",
			chooseWaiting: "已就位,等其他人选择…",
			placePrompt: "点亮发光格,再选择筹码面",
			startOnlyPrompt: "只能叠到★起点,再选择筹码面",
			placeWaiting: "等 {{name}} 放置…",
			excludedBanner: "你已出局,等终局结算",
			scoring: "逐房间结算 {{n}}/{{total}}",
			startOptionHint: "★起点免计数",
			chooseFaceLabel: "选择朝上的一面",
			handLabel: "手中光源",
			roomReveal: "房间点数 · 奖分",
			roomEmpty: "房间内没有光源",
			cancelPick: "重选",
			faceAria: "{{n}} 点朝上",
			chipsLeft: "剩 {{n}} 枚",
			excludedBadge: "出局",
			hintChoose: "起始筹码 {{n}} 点朝上",
			hintPlace: "把 {{n}} 点放到第 {{row}} 行第 {{col}} 列",
			matchWinner: "获胜者：{{name}}",
			matchWinnerMark: "获胜者",
			matchRanking: "最终排名",
			victoryPoints: "分",
			roomLedger: "房间点数 / 奖分",
			roomColumn: "房间",
			roomTopLeftCorner: "左上角房间",
			roomTopRightCorner: "右上角房间",
			roomBottomLeftCorner: "左下角房间",
			roomBottomRightCorner: "右下角房间",
			roomTop: "上方房间",
			roomBottom: "下方房间",
			roomLeft: "左侧房间",
			roomRight: "右侧房间",
			roomTopLeft: "左上方房间",
			roomTopRight: "右上方房间",
			roomBottomLeft: "左下方房间",
			roomBottomRight: "右下方房间",
			roomCenter: "中央房间",
			errNotYourTurn: "现在轮不到你",
			errNoChip: "你手里没有筹码",
			errBadCell: "这格不能放"
		},
		en: {
			name: "Glüx",
			desc: "Count straight lines, light up rooms, outscore rivals",
			rules: "Goal: after every room is scored, the player with the most victory points wins.\nSetup:\n· With 2 players use the diagonal start squares; with 3-4 players use the illustrated squares (corners for 4).\n· Each player has 24 two-sided chips (8 each of 1/6, 2/5, 3/4).\n· Draw one chip, choose a face, and place it on your start marker; then draw one more chip and keep it hidden in your hand.\nPlay:\n· On your turn, place then draw: from any of your own top chips, count exactly its pip value in a straight horizontal or vertical line.\n· Place your hand chip on the destination square, either face up.\n· Any chip between the start and the destination blocks that direction, and you may not count off the board.\n· A destination holding a single chip (anyone's) may be stacked on; a stack of two may not. Only the top chip of a stack counts.\n· You may never place on another player's start marker. Once per game you may place your chip onto your own start marker without counting.\n· No passing. If you cannot place legally, you must use that once-per-game option; if it is already used, you are out until the final scoring.\nScoring:\n· When no player can draw a chip, or nobody can place, rooms are scored one by one.\n· Sum your top-chip pips per room to rank the players.\n· 1st place scores 4 VP, 2nd place 2 VP (in a 2-player game only 1st place scores).\n· Tied for 1st: all tied players get 4 VP and no 2nd place is awarded; tied for 2nd: all tied players get 2 VP.\n· Players with no chip in a room do not rank in it.\n· Most VP wins; ties are broken by pips in the central 3×3 room, and a persisting tie is a shared victory.",
			choosePrompt: "Pick a face for your start chip",
			chooseWaiting: "Placed — waiting for others…",
			placePrompt: "Light a marked square, then pick a face",
			startOnlyPrompt: "Place on your ★ start, then pick a face",
			placeWaiting: "Waiting for {{name}}…",
			excludedBanner: "You are out — wait for scoring",
			scoring: "Scoring rooms {{n}}/{{total}}",
			startOptionHint: "★ free start move",
			chooseFaceLabel: "Choose the face up",
			handLabel: "Light in hand",
			roomReveal: "Room pips · points",
			roomEmpty: "No chips in this room",
			cancelPick: "Repick",
			faceAria: "place with {{n}} up",
			chipsLeft: "{{n}} left",
			excludedBadge: "out",
			hintChoose: "start chip with {{n}} up",
			hintPlace: "place {{n}} at row {{row}}, column {{col}}",
			matchWinner: "Winner: {{name}}",
			matchWinnerMark: "Winner",
			matchRanking: "Final ranking",
			victoryPoints: "VP",
			roomLedger: "Room pips / points",
			roomColumn: "Room",
			roomTopLeftCorner: "Upper-left corner",
			roomTopRightCorner: "Upper-right corner",
			roomBottomLeftCorner: "Lower-left corner",
			roomBottomRightCorner: "Lower-right corner",
			roomTop: "Upper room",
			roomBottom: "Lower room",
			roomLeft: "Left room",
			roomRight: "Right room",
			roomTopLeft: "Upper-left room",
			roomTopRight: "Upper-right room",
			roomBottomLeft: "Lower-left room",
			roomBottomRight: "Lower-right room",
			roomCenter: "Central room",
			errNotYourTurn: "Not your move right now",
			errNoChip: "You have no chip in hand",
			errBadCell: "Can't place there"
		}
	}
};
//#endregion
export { Ue as default };
