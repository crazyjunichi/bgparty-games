import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useI18nSettings as n, useT as r } from "@bgparty/sdk/i18n";
import { seatName as i } from "@bgparty/sdk/ui/player-strip";
import { useState as a } from "react";
import { AVATARS as o } from "@bgparty/sdk/avatars";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as c } from "@bgparty/sdk/fx/delta-number";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { Floater as h, FlySprite as g, PulseBox as _ } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as v } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as y, OptionSection as b } from "@bgparty/sdk/ui/game-options";
//#region src/games/camelup/meta.ts
var x = {
	id: "camelup",
	tier: "released",
	mechanics: ["betting", "dice-rolling"],
	interactionTags: [],
	nameKey: "games.camelup.name",
	descKey: "games.camelup.desc",
	rulesKey: "games.camelup.rules",
	icon: "🐫",
	iconImg: "games/camelup.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/camelup/en.pdf" },
	minPlayers: 3,
	maxPlayers: 8,
	bestPlayers: [5, 6],
	accent: "#e07b39",
	releasedAt: "2026-09-16",
	search: {
		py: "kuang ye luo tuo",
		init: "kylt"
	},
	hotseat: "cover"
}, S = t.enum([
	"blue",
	"yellow",
	"green",
	"orange",
	"purple"
]), C = t.enum([
	"blue",
	"yellow",
	"green",
	"orange",
	"purple",
	"black",
	"white"
]), w = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("takeTicket"),
		color: S
	}),
	t.object({
		type: t.literal("placeTile"),
		space: t.int().min(2).max(16),
		side: t.enum(["cheer", "boo"])
	}),
	t.object({ type: t.literal("roll") }),
	t.object({
		type: t.literal("betFinal"),
		target: t.enum(["winner", "loser"]),
		color: S
	})
]), T = t.object({ crazy: t.boolean().catch(!0) }).default({ crazy: !0 }), E = t.string(), D = t.object({
	die: t.union([S, t.literal("grey")]),
	value: t.int().min(1).max(3),
	face: t.enum(["black", "white"]).optional()
}), O = t.object({
	crazy: t.boolean(),
	track: t.array(t.array(C)).length(16),
	leg: t.int().min(1),
	phase: t.enum(["play", "done"]),
	turn: E,
	pyramidLeft: t.int().min(0).max(5),
	rolled: t.array(D),
	tickets: t.array(t.object({
		color: S,
		top: t.int().nullable(),
		count: t.int().nonnegative()
	})),
	players: t.array(t.object({
		rid: E,
		money: t.int().nonnegative(),
		held: t.array(t.object({
			color: S,
			value: t.int()
		})),
		pyramid: t.int().nonnegative()
	})),
	tiles: t.array(t.object({
		space: t.int().min(2).max(16),
		owner: E,
		side: t.enum(["cheer", "boo"])
	})),
	betWinner: t.array(E),
	betLoser: t.array(E),
	crossed: t.object({
		dir: t.union([t.literal(1), t.literal(-1)]),
		unit: t.array(C)
	}).nullable()
}), k = t.object({
	cards: t.array(S),
	myWinner: t.array(S),
	myLoser: t.array(S)
}), A = [
	"blue",
	"yellow",
	"green",
	"orange",
	"purple"
], j = ["black", "white"], M = [
	5,
	3,
	2,
	2
], N = 3, P = [
	8,
	5,
	3,
	2
];
function F(e) {
	return e === "black" || e === "white";
}
function I(t, n, r) {
	let i = 0, a = Array.from({ length: 16 }, () => []);
	for (let t of A) {
		let n = a[e(r, i++, 3)];
		n.splice(e(r, i++, n.length + 1), 0, t);
	}
	if (t.crazy) for (let t of j) a[15 - e(r, i++, 3)].push(t);
	let o = {}, s = {}, c = {}, l = {};
	for (let e of n) o[e] = N, s[e] = [], c[e] = 0, l[e] = [...A];
	let u = Object.fromEntries(A.map((e) => [e, [...M]]));
	return {
		state: {
			players: n,
			crazy: t.crazy,
			seed: r,
			rngCursor: i,
			track: a,
			money: o,
			tickets: u,
			held: s,
			pyramidHeld: c,
			pyramidLeft: 5,
			diceIn: [...A, ...t.crazy ? ["grey"] : []],
			rolled: [],
			tiles: [],
			cardsLeft: l,
			betWinner: [],
			betLoser: [],
			crossed: null,
			turn: 0,
			leg: 1,
			phase: "play"
		},
		fx: []
	};
}
function L(e) {
	let t = [], n = (e) => {
		for (let n = e.length - 1; n >= 0; n--) F(e[n]) || t.push(e[n]);
	};
	e.crossed?.dir === 1 && n(e.crossed.unit);
	for (let t = e.track.length - 1; t >= 0; t--) n(e.track[t]);
	return e.crossed?.dir === -1 && n(e.crossed.unit), t;
}
function R(e, t) {
	for (let n = 0; n < 16; n++) {
		let r = e.track[n].indexOf(t);
		if (r >= 0) return {
			sp: n,
			h: r
		};
	}
	throw Error(`camel not on track: ${t}`);
}
function z(e, t, n) {
	let r = F(t) ? -1 : 1, { sp: i, h: a } = R(e, t), o = e.track[i].splice(a), s = i + r * n, c = null, l = 0;
	if (s >= 0 && s < 16) {
		e.track[s].push(...o);
		let t = e.tiles.find((e) => e.space === s + 1);
		if (t) {
			c = t, e.money[t.owner] += 1, e.track[s].splice(e.track[s].length - o.length, o.length);
			let n = s + (t.side === "cheer" ? r : -r);
			n >= 0 && n < 16 ? (t.side === "cheer" ? e.track[n].push(...o) : e.track[n].unshift(...o), s = n) : (s = n, l = n < 0 ? -1 : 1);
		}
	} else l = s < 0 ? -1 : 1;
	return l && (e.crossed = {
		dir: l,
		unit: o
	}), {
		from: i + 1,
		to: s + 1,
		unit: o,
		tile: c,
		crossed: l
	};
}
function B(e, t) {
	let n = (t) => {
		let { sp: n, h: r } = R(e, t);
		return e.track[n].slice(r + 1).some((e) => !F(e));
	}, r = n("black");
	if (r !== n("white")) return r ? "black" : "white";
	let i = R(e, "black"), a = R(e, "white");
	return i.sp === a.sp && Math.abs(i.h - a.h) === 1 ? i.h > a.h ? "black" : "white" : t;
}
function V(e) {
	let [t, n] = L(e), r = {};
	for (let i of e.players) {
		let a = 0;
		for (let r of e.held[i]) r.color === t ? a += r.value : r.color === n ? a += 1 : --a;
		a += e.pyramidHeld[i], e.money[i] = Math.max(0, e.money[i] + a), r[i] = a;
	}
	return r;
}
function ee(e) {
	for (let t of A) e.tickets[t] = [...M];
	for (let t of e.players) e.held[t] = [], e.pyramidHeld[t] = 0;
	e.pyramidLeft = 5, e.diceIn = [...A, ...e.crazy ? ["grey"] : []], e.rolled = [], e.tiles = [], e.leg += 1;
}
function te(e) {
	let t = L(e), n = [[e.betWinner, t[0]], [e.betLoser, t[t.length - 1]]], r = Object.fromEntries(e.players.map((e) => [e, 0]));
	for (let [e, t] of n) {
		let n = 0;
		for (let i of e) i.color === t ? (r[i.rid] += P[n] ?? 1, n += 1) : --r[i.rid];
	}
	for (let t of e.players) e.money[t] = Math.max(0, e.money[t] + r[t]);
	return r;
}
function H(e) {
	e.turn = (e.turn + 1) % e.players.length;
}
function ne(t, n, r) {
	if (t.phase !== "play") return { code: "games.camelup.errOver" };
	if (r.by !== t.players[t.turn]) return { code: "games.camelup.errNotYourTurn" };
	if (n.type === "takeTicket") {
		let e = t.tickets[n.color];
		if (!e || e.length === 0) return { code: "games.camelup.errNoTicket" };
		let i = structuredClone(t), a = i.tickets[n.color].shift();
		return i.held[r.by].push({
			color: n.color,
			value: a
		}), H(i), {
			state: i,
			fx: [{
				kind: "takeTicket",
				rid: r.by,
				data: {
					color: n.color,
					value: a
				}
			}]
		};
	}
	if (n.type === "placeTile") {
		if (t.track[n.space - 1].length > 0) return { code: "games.camelup.errBadTile" };
		let e = t.tiles.filter((e) => e.owner !== r.by);
		if (e.some((e) => Math.abs(e.space - n.space) <= 1) || t.tiles.find((e) => e.owner === r.by)?.space === n.space) return { code: "games.camelup.errBadTile" };
		let i = structuredClone(t);
		return i.tiles = [...e, {
			space: n.space,
			owner: r.by,
			side: n.side
		}], H(i), {
			state: i,
			fx: [{
				kind: "placeTile",
				rid: r.by,
				data: {
					space: n.space,
					side: n.side
				}
			}]
		};
	}
	if (n.type === "betFinal") {
		if (!t.cardsLeft[r.by].includes(n.color)) return { code: "games.camelup.errNoCard" };
		let e = structuredClone(t);
		return e.cardsLeft[r.by] = e.cardsLeft[r.by].filter((e) => e !== n.color), (n.target === "winner" ? e.betWinner : e.betLoser).push({
			rid: r.by,
			color: n.color
		}), H(e), {
			state: e,
			fx: [{
				kind: "betFinal",
				rid: r.by,
				data: { target: n.target }
			}]
		};
	}
	if (t.pyramidLeft <= 0) return { code: "games.camelup.errNoPyramid" };
	let i = structuredClone(t);
	--i.pyramidLeft, i.pyramidHeld[r.by] += 1;
	let a = i.rngCursor, o = e(i.seed, a++, i.diceIn.length), s = i.diceIn.splice(o, 1)[0], c = e(i.seed, a++, 3) + 1, l, u;
	s === "grey" ? (l = e(i.seed, a++, 2) === 0 ? "black" : "white", u = B(i, l)) : u = s, i.rngCursor = a, i.rolled.push({
		die: s,
		value: c,
		...l ? { face: l } : {}
	});
	let d = z(i, u, c), f = [{
		kind: "roll",
		rid: r.by,
		data: {
			die: s,
			value: c,
			...l ? { face: l } : {},
			camel: u,
			from: d.from,
			to: d.to,
			carried: d.unit.length - 1,
			crossed: d.crossed
		}
	}];
	if (d.tile && f.push({
		kind: "tileHit",
		with: !0,
		data: {
			space: d.tile.space,
			side: d.tile.side,
			owner: d.tile.owner,
			camel: u
		}
	}), H(i), d.crossed !== 0) {
		let e = V(i), t = te(i);
		i.phase = "done";
		let n = L(i);
		f.push({
			kind: "gameOver",
			with: !0,
			data: {
				deltas: e,
				finalDeltas: t,
				winnerCamel: n[0],
				loserCamel: n[n.length - 1]
			}
		});
	} else if (i.pyramidLeft === 0) {
		let e = V(i);
		ee(i), f.push({
			kind: "legEnd",
			with: !0,
			data: {
				deltas: e,
				leg: i.leg
			}
		});
	}
	return {
		state: i,
		fx: f
	};
}
function re(e, t) {
	return {
		public: {
			crazy: e.crazy,
			track: e.track,
			leg: e.leg,
			phase: e.phase,
			turn: e.players[e.turn],
			pyramidLeft: e.pyramidLeft,
			rolled: e.rolled,
			tickets: A.map((t) => ({
				color: t,
				top: e.tickets[t][0] ?? null,
				count: e.tickets[t].length
			})),
			players: e.players.map((t) => ({
				rid: t,
				money: e.money[t],
				held: e.held[t],
				pyramid: e.pyramidHeld[t]
			})),
			tiles: e.tiles,
			betWinner: e.betWinner.map((e) => e.rid),
			betLoser: e.betLoser.map((e) => e.rid),
			crossed: e.crossed
		},
		private: {
			cards: e.cardsLeft[t] ?? [],
			myWinner: e.betWinner.filter((e) => e.rid === t).map((e) => e.color),
			myLoser: e.betLoser.filter((e) => e.rid === t).map((e) => e.color)
		}
	};
}
function ie(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.money[n] - e.money[t]), n = e.money[t[0]];
	return {
		phase: "done",
		winner: t.filter((t) => e.money[t] === n),
		ranking: t,
		scores: { ...e.money }
	};
}
var ae = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: x,
	schemas: {
		action: w,
		publicView: O,
		privateView: k,
		config: T
	},
	setup: I,
	reduce: ne,
	viewFor: re,
	status: ie
}, U = {
	blue: "#3b82f6",
	yellow: "#facc15",
	green: "#22c55e",
	orange: "#fb923c",
	purple: "#a855f7",
	black: "#292524",
	white: "#f8f4e8"
};
function oe({ camel: e, size: t = "md" }) {
	let n = e === "black" || e === "white";
	return /* @__PURE__ */ p("span", {
		"aria-hidden": !0,
		className: `grid place-items-center rounded-full border-2 border-ink shadow-[1px_1px_0_var(--color-ink)] ${t === "sm" ? "size-6 text-xs" : "size-8 text-sm"} ${n ? "border-dashed" : ""}`,
		style: { backgroundColor: U[e] },
		children: /* @__PURE__ */ p("span", {
			className: n ? "-scale-x-100" : "",
			children: "🐫"
		})
	});
}
//#endregion
//#region src/games/camelup/view-player.tsx
var W = {
	blue: "games.camelup.camelBlue",
	yellow: "games.camelup.camelYellow",
	green: "games.camelup.camelGreen",
	orange: "games.camelup.camelOrange",
	purple: "games.camelup.camelPurple",
	black: "games.camelup.camelBlack",
	white: "games.camelup.camelWhite"
}, G = Array.from({ length: 16 }, (e, t) => {
	let n = (112.5 + t * 22.5) * Math.PI / 180;
	return {
		space: t + 1,
		x: 50 + 40.5 * Math.cos(n),
		y: 50 + 40.5 * Math.sin(n)
	};
}), K = "./games/camelup/", q = (e) => K + "camel-" + e + ".webp";
function se(e) {
	return /* @__PURE__ */ p(ce, {
		pub: e.public,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function ce({ pub: e, priv: t, members: o, myRid: s, send: c }) {
	let h = n((e) => e.locale), g = r(), [_, v] = a(null), [y, b] = a(null), [S, C] = a(null), w = e.leg + ":" + e.turn + ":" + e.phase, [T, E] = a(w);
	T !== w && (E(w), v(null), b(null), C(null));
	let D = e.phase === "play" && e.turn === s, O = _ === "tileCheer" || _ === "tileBoo", k = _ === "betWin" || _ === "betLose", A = S === null ? null : e.track[S - 1], j = S !== null && A && A.length > 1, M = (e) => {
		let t = o.find((t) => t.rid === e);
		return t ? i(t, h) : e;
	}, N = (t) => t >= 2 && e.track[t - 1].length === 0 && !e.tiles.some((e) => e.owner !== s && Math.abs(e.space - t) <= 1) && e.tiles.find((e) => e.owner === s)?.space !== t, P = G.some(({ space: e }) => N(e)), F = "info", I = g("games.camelup.waitTurn", { name: M(e.turn) });
	e.phase === "done" ? (F = "done", I = g("games.camelup.over")) : D && (F = O || k ? "warn" : "accent", I = g(O ? "games.camelup.tilePickSpace" : k ? "games.camelup.betPick" : "games.camelup.yourTurn"));
	let L = (e) => {
		C(null), b(null), v(e);
	}, R = () => {
		b(null), v(null);
	}, z = g(_ === "betLose" ? "games.camelup.pileLose" : "games.camelup.pileWin"), B = /* @__PURE__ */ m("div", {
		className: "cu-header",
		children: [/* @__PURE__ */ p("div", {
			className: "cu-banner",
			children: /* @__PURE__ */ p(d, {
				tone: F,
				text: I,
				chip: g("games.camelup.legChip", { n: e.leg }),
				accent: x.accent
			})
		}), /* @__PURE__ */ p("div", {
			className: "cu-players",
			"aria-label": g("games.camelup.playersAria"),
			children: o.map((t) => {
				let n = e.players.find((e) => e.rid === t.rid);
				return /* @__PURE__ */ p(le, {
					member: t,
					player: n,
					current: e.phase === "play" && e.turn === t.rid,
					myRid: s
				}, t.rid);
			})
		})]
	}), V = /* @__PURE__ */ p("div", {
		className: "cu-actions",
		children: D && _ === null ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("button", {
			type: "button",
			className: "cu-action",
			disabled: !P,
			onClick: () => L("tileCheer"),
			children: [/* @__PURE__ */ p("span", {
				"aria-hidden": !0,
				className: "cu-action-icon",
				children: "😄"
			}), g("games.camelup.actTileCheer")]
		}), /* @__PURE__ */ m("button", {
			type: "button",
			className: "cu-action",
			disabled: !P,
			onClick: () => L("tileBoo"),
			children: [/* @__PURE__ */ p("span", {
				"aria-hidden": !0,
				className: "cu-action-icon",
				children: "👎"
			}), g("games.camelup.actTileBoo")]
		})] }) : D ? /* @__PURE__ */ p("button", {
			type: "button",
			className: "cu-action cu-action-cancel",
			onClick: R,
			children: g("games.camelup.cancel")
		}) : /* @__PURE__ */ p("div", {
			className: "cu-action-wait plate",
			children: I
		})
	});
	return /* @__PURE__ */ p("div", {
		className: "cu-shell",
		style: { "--cu-accent": x.accent },
		children: /* @__PURE__ */ p(u, {
			adaptive: !0,
			className: "cu-screen",
			scroll: !1,
			children: /* @__PURE__ */ m("div", {
				className: "cu-content",
				children: [/* @__PURE__ */ p("section", {
					className: "cu-stage",
					"aria-label": g("games.camelup.boardAria"),
					children: /* @__PURE__ */ m("div", {
						className: "cu-board",
						children: [
							/* @__PURE__ */ p("img", {
								className: "cu-board-art",
								src: K + "board.webp",
								alt: "",
								draggable: !1
							}),
							/* @__PURE__ */ m("svg", {
								className: "cu-track-arrows",
								viewBox: "0 0 375 375",
								"aria-hidden": !0,
								children: [
									/* @__PURE__ */ p("defs", { children: /* @__PURE__ */ p("marker", {
										id: "cu-arrow",
										markerWidth: "5",
										markerHeight: "5",
										refX: "4",
										refY: "2.5",
										orient: "auto",
										children: /* @__PURE__ */ p("path", { d: "M0 0L5 2.5L0 5" })
									}) }),
									/* @__PURE__ */ p("path", { d: "M86 69 C126 38 202 32 266 53" }),
									/* @__PURE__ */ p("path", { d: "M300 291 C253 328 168 341 102 316" })
								]
							}),
							G.map(({ space: t, x: n, y: r }) => {
								let i = e.track[t - 1], a = e.tiles.find((e) => e.space === t), s = D && O && N(t);
								return /* @__PURE__ */ p(ue, {
									space: t,
									x: n,
									y: r,
									stack: i,
									tile: a,
									tileColor: a ? l[(o.find((e) => e.rid === a.owner)?.colorIndex ?? 0) % l.length].hex : void 0,
									tileOwner: a ? M(a.owner) : void 0,
									tileAvatar: o.find((e) => e.rid === a?.owner)?.avatar ?? 0,
									legal: s,
									dimmed: O && !s,
									inspectable: !O && !k && i.length > 1,
									onPick: s ? () => {
										c({
											type: "placeTile",
											space: t,
											side: _ === "tileCheer" ? "cheer" : "boo"
										}), v(null);
									} : void 0,
									onInspect: () => C(t)
								}, t);
							}),
							/* @__PURE__ */ p(de, {
								left: e.pyramidLeft,
								enabled: D && _ === null && e.pyramidLeft > 0,
								onRoll: () => c({ type: "roll" })
							}),
							/* @__PURE__ */ p("span", {
								className: "cu-pyramid-stock",
								children: g("games.camelup.pyramidStock", {
									n: e.pyramidLeft,
									total: 5
								})
							}),
							/* @__PURE__ */ p(fe, { rolled: e.rolled }),
							!e.crossed && /* @__PURE__ */ p("span", {
								className: "cu-track-hint",
								children: g(O ? "games.camelup.tileBoardHint" : e.crazy ? "games.camelup.directionCrazy" : "games.camelup.directionClassic")
							}),
							/* @__PURE__ */ m("span", {
								className: "cu-finish" + (e.crossed ? " cu-finish-crossed" : ""),
								children: ["🏁 ", g("games.camelup.finishLine")]
							}),
							e.crossed && /* @__PURE__ */ m("span", {
								className: "cu-crossed-unit",
								"aria-label": g("games.camelup.crossedUnitAria", { order: e.crossed.unit.map((e) => g(W[e])).join(" → ") }),
								children: [/* @__PURE__ */ p("img", {
									src: q(e.crossed.unit.at(-1) ?? "blue"),
									alt: "",
									draggable: !1
								}), e.crossed.unit.length > 1 && /* @__PURE__ */ m("small", { children: ["×", e.crossed.unit.length] })]
							}),
							k && t && /* @__PURE__ */ p("div", {
								className: "cu-board-shade",
								children: /* @__PURE__ */ m("div", {
									className: "cu-bet-sheet card",
									role: "dialog",
									"aria-label": g("games.camelup.betDialogAria", { target: z }),
									children: [
										/* @__PURE__ */ p("strong", {
											className: "cu-sheet-title",
											children: z
										}),
										/* @__PURE__ */ p("p", {
											className: "cu-sheet-note",
											children: g("games.camelup.betPrivateNote")
										}),
										/* @__PURE__ */ p("div", {
											className: "cu-finish-cards",
											children: t.cards.map((e) => /* @__PURE__ */ m("button", {
												type: "button",
												className: "cu-finish-card" + (y === e ? " is-selected" : ""),
												"aria-pressed": y === e,
												"aria-label": g("games.camelup.selectFinalAria", { name: g(W[e]) }),
												onClick: () => b(e),
												children: [/* @__PURE__ */ p("img", {
													src: q(e),
													alt: "",
													draggable: !1
												}), /* @__PURE__ */ p("span", { children: g(W[e]) })]
											}, e))
										}),
										/* @__PURE__ */ p("button", {
											type: "button",
											className: "cu-bet-commit btn-base",
											disabled: !y,
											onClick: () => {
												y && (c({
													type: "betFinal",
													target: _ === "betWin" ? "winner" : "loser",
													color: y
												}), R());
											},
											children: y ? g("games.camelup.confirmFinal", {
												name: g(W[y]),
												target: z
											}) : g("games.camelup.selectFinalFirst")
										})
									]
								})
							}),
							j && /* @__PURE__ */ p("div", {
								className: "cu-board-shade",
								children: /* @__PURE__ */ p(me, {
									space: S,
									stack: A,
									onClose: () => C(null)
								})
							})
						]
					})
				}), /* @__PURE__ */ m("aside", {
					className: "cu-sidebar",
					children: [
						B,
						/* @__PURE__ */ m("section", {
							className: "cu-market",
							"aria-label": g("games.camelup.marketAria"),
							children: [/* @__PURE__ */ p("div", {
								className: "cu-tickets",
								children: e.tickets.map((e) => /* @__PURE__ */ p(pe, {
									color: e.color,
									top: e.top,
									count: e.count,
									enabled: D && _ === null && e.count > 0,
									onTake: () => c({
										type: "takeTicket",
										color: e.color
									})
								}, e.color))
							}), /* @__PURE__ */ m("div", {
								className: "cu-piles",
								children: [/* @__PURE__ */ p(J, {
									anchor: "pile:win",
									icon: "🏆",
									label: g("games.camelup.pileWin"),
									pile: e.betWinner,
									mine: t?.myWinner ?? [],
									members: o,
									enabled: D && _ === null && (t?.cards.length ?? 0) > 0,
									onPick: () => L("betWin")
								}), /* @__PURE__ */ p(J, {
									anchor: "pile:lose",
									icon: "🐌",
									label: g("games.camelup.pileLose"),
									pile: e.betLoser,
									mine: t?.myLoser ?? [],
									members: o,
									enabled: D && _ === null && (t?.cards.length ?? 0) > 0,
									onPick: () => L("betLose")
								})]
							})]
						}),
						/* @__PURE__ */ p("div", {
							className: "cu-actions-slot",
							children: V
						})
					]
				})]
			})
		})
	});
}
function le({ member: e, player: t, current: r, myRid: a }) {
	let u = n((e) => e.locale), { ref: d } = s("seat:" + e.rid), f = l[e.colorIndex % l.length].hex;
	return /* @__PURE__ */ m("div", {
		className: "cu-player" + (r ? " is-current" : "") + (e.rid === a ? " is-me" : ""),
		children: [/* @__PURE__ */ p("span", {
			ref: d,
			className: "cu-avatar",
			style: { backgroundColor: f },
			children: /* @__PURE__ */ p("img", {
				src: o[e.avatar % o.length],
				alt: "",
				draggable: !1
			})
		}), /* @__PURE__ */ m("span", {
			className: "cu-player-text",
			children: [/* @__PURE__ */ p("span", {
				className: "cu-player-name",
				children: i(e, u)
			}), /* @__PURE__ */ m("span", {
				className: "cu-player-score",
				children: [
					/* @__PURE__ */ m("span", { children: ["🪙 ", /* @__PURE__ */ p(c, { value: t?.money ?? 0 })] }),
					/* @__PURE__ */ m("span", { children: ["🎫 ", t?.held.length ?? 0] }),
					(t?.pyramid ?? 0) > 0 && /* @__PURE__ */ m("span", { children: ["🔺 ", t?.pyramid] })
				]
			})]
		})]
	});
}
function ue({ space: e, x: t, y: n, stack: i, tile: a, tileColor: c, tileOwner: l, tileAvatar: u, legal: d, dimmed: f, inspectable: h, onPick: g, onInspect: _ }) {
	let v = r(), { ref: y } = s("cell:" + e), b = i.at(-1), x = i.slice(0, -1), S = x.slice(-3), C = x.length - S.length, w = i.map((e) => v(W[e])).join(" → "), T = (d ? v("games.camelup.spaceLegalAria", { n: e }) : i.length > 1 ? v("games.camelup.spaceStackAria", {
		n: e,
		order: w
	}) : b ? v("games.camelup.spaceCamelAria", {
		n: e,
		name: v(W[b])
	}) : v("games.camelup.spaceEmptyAria", { n: e })) + (a ? v("games.camelup.spaceTileSuffix", {
		owner: l ?? "",
		side: v(a.side === "cheer" ? "games.camelup.tileCheer" : "games.camelup.tileBoo")
	}) : "");
	return /* @__PURE__ */ m("button", {
		ref: y,
		type: "button",
		disabled: !d && !h,
		"aria-label": T,
		onClick: d ? g : h ? _ : void 0,
		className: "cu-cell" + (i.length > 1 ? " is-stacked" : "") + (d ? " is-legal" : "") + (f ? " is-dimmed" : "") + (a ? " has-tile" : ""),
		style: {
			left: t + "%",
			top: n + "%"
		},
		children: [
			/* @__PURE__ */ p("span", {
				className: "cu-cell-number",
				children: e
			}),
			b && /* @__PURE__ */ p("img", {
				className: "cu-camel-piece" + (i.length > 1 ? " is-top" : ""),
				src: q(b),
				alt: "",
				draggable: !1
			}),
			i.length > 1 && /* @__PURE__ */ m("span", {
				className: "cu-camel-chips",
				"aria-hidden": !0,
				children: [C > 0 && /* @__PURE__ */ m("span", {
					className: "cu-hidden-chip",
					children: ["+", C]
				}), S.map((e) => /* @__PURE__ */ p("span", {
					className: "cu-camel-chip",
					style: { backgroundColor: U[e] }
				}, e))]
			}),
			i.some((e) => e === "black" || e === "white") && /* @__PURE__ */ p("span", {
				className: "cu-reverse-mark",
				"aria-hidden": !0,
				children: "↶"
			}),
			a && /* @__PURE__ */ m("span", {
				className: "cu-placed-tile",
				style: { borderColor: c },
				title: l,
				"aria-hidden": !0,
				children: [/* @__PURE__ */ p("span", { children: a.side === "cheer" ? "😄" : "👎" }), /* @__PURE__ */ p("small", { children: /* @__PURE__ */ p("img", {
					src: o[(u ?? 0) % o.length],
					alt: "",
					draggable: !1,
					style: {
						width: "1.75em",
						height: "1.75em",
						maxWidth: "100%",
						maxHeight: "100%",
						display: "block",
						objectFit: "contain",
						pointerEvents: "none",
						borderRadius: "inherit"
					}
				}) })]
			})
		]
	});
}
function de({ left: e, enabled: t, onRoll: n }) {
	let i = r(), { ref: a } = s("pyramid");
	return /* @__PURE__ */ m("button", {
		ref: a,
		type: "button",
		className: "cu-pyramid",
		disabled: !t,
		onClick: n,
		"aria-label": i("games.camelup.pyramidAria", { n: e }),
		children: [/* @__PURE__ */ m("svg", {
			viewBox: "0 0 116 95",
			"aria-hidden": !0,
			children: [
				/* @__PURE__ */ p("path", {
					className: "cu-pyramid-base",
					d: "M12 86L57 10L105 86Z"
				}),
				/* @__PURE__ */ p("path", {
					className: "cu-pyramid-shade",
					d: "M57 10L105 86L60 86Z"
				}),
				/* @__PURE__ */ p("path", {
					className: "cu-pyramid-light",
					d: "M12 86L57 10L60 86Z"
				}),
				/* @__PURE__ */ p("path", {
					className: "cu-pyramid-lines",
					d: "M17 76H99M22 66H94M28 56H88M34 46H82M40 36H76M47 26H69"
				}),
				/* @__PURE__ */ p("path", {
					className: "cu-pyramid-door",
					d: "M44 86V68Q58 52 73 68V86"
				}),
				/* @__PURE__ */ p("path", {
					className: "cu-pyramid-arrow",
					d: "M52 81L58 73L65 81"
				})
			]
		}), /* @__PURE__ */ p("span", {
			className: "cu-pyramid-tag",
			children: i("games.camelup.actRoll")
		})]
	});
}
function fe({ rolled: e }) {
	let t = r(), { ref: n } = s("tents");
	return /* @__PURE__ */ p("div", {
		ref: n,
		className: "cu-dice-tray" + (e.length ? "" : " is-empty"),
		"aria-label": t("games.camelup.rolledLabel"),
		children: e.length === 0 ? /* @__PURE__ */ m("span", { children: ["🎲 ", t("games.camelup.noDice")] }) : e.map((e, n) => {
			let r = e.die === "grey" ? e.face ?? "black" : e.die;
			return /* @__PURE__ */ p("span", {
				className: "cu-die",
				style: {
					backgroundColor: U[r],
					color: r === "yellow" || r === "white" ? "var(--color-ink)" : "var(--color-surface)"
				},
				title: t(W[r]),
				children: e.value
			}, n);
		})
	});
}
function pe({ color: e, top: t, count: n, enabled: i, onTake: a }) {
	let o = r(), { ref: c } = s("tickets:" + e);
	return /* @__PURE__ */ m("button", {
		ref: c,
		type: "button",
		disabled: !i,
		onClick: a,
		className: "cu-ticket" + (n === 0 ? " is-empty" : ""),
		"aria-label": o("games.camelup.ticketAria", {
			name: o(W[e]),
			value: t ?? "—",
			n
		}),
		children: [
			/* @__PURE__ */ p("span", {
				className: "cu-ticket-band",
				style: { backgroundColor: U[e] }
			}),
			/* @__PURE__ */ m("span", {
				className: "cu-ticket-middle",
				children: [/* @__PURE__ */ p("img", {
					src: q(e),
					alt: "",
					draggable: !1
				}), /* @__PURE__ */ p("strong", { children: t ?? "—" })]
			}),
			/* @__PURE__ */ m("span", {
				className: "cu-ticket-bottom",
				children: [/* @__PURE__ */ p("span", { children: o(W[e]) }), /* @__PURE__ */ m("span", { children: ["×", n] })]
			})
		]
	});
}
function J({ anchor: e, icon: t, label: n, pile: i, mine: a, members: c, enabled: l, onPick: u }) {
	let d = r(), { ref: f } = s(e);
	return /* @__PURE__ */ m("button", {
		ref: f,
		type: "button",
		disabled: !l,
		onClick: u,
		className: "cu-pile",
		"aria-label": d(l ? "games.camelup.pileAria" : "games.camelup.pileReadonlyAria", {
			target: n,
			n: i.length
		}),
		children: [
			/* @__PURE__ */ p("span", {
				className: "cu-pile-icon",
				"aria-hidden": !0,
				children: t
			}),
			/* @__PURE__ */ m("span", {
				className: "cu-pile-body",
				children: [/* @__PURE__ */ p("strong", { children: n }), /* @__PURE__ */ p("span", {
					className: "cu-pile-sub",
					children: i.length === 0 ? d("games.camelup.pileEmpty") : i.map((e, t) => {
						let n = c.find((t) => t.rid === e)?.avatar ?? 0;
						return /* @__PURE__ */ p("img", {
							src: o[n % o.length],
							alt: "",
							draggable: !1
						}, t);
					})
				})]
			}),
			/* @__PURE__ */ p("span", {
				className: "cu-pile-mine",
				"aria-label": d("games.camelup.myFinalCards"),
				children: a.map((e) => /* @__PURE__ */ p("span", {
					style: { backgroundColor: U[e] },
					title: d(W[e])
				}, e))
			}),
			/* @__PURE__ */ p("span", {
				className: "cu-pile-count",
				children: i.length
			})
		]
	});
}
function me({ space: e, stack: t, onClose: n }) {
	let i = r();
	return /* @__PURE__ */ m("div", {
		className: "cu-stack-sheet card",
		role: "dialog",
		"aria-label": i("games.camelup.stackTitle", {
			n: e,
			count: t.length
		}),
		children: [
			/* @__PURE__ */ p("strong", {
				className: "cu-sheet-title",
				children: i("games.camelup.stackTitle", {
					n: e,
					count: t.length
				})
			}),
			/* @__PURE__ */ p("p", {
				className: "cu-sheet-note",
				children: i("games.camelup.stackOrderHint")
			}),
			/* @__PURE__ */ p("div", {
				className: "cu-stack-list",
				children: t.map((e, n) => /* @__PURE__ */ m("div", {
					className: "cu-stack-detail" + (n === t.length - 1 ? " is-top" : ""),
					children: [
						/* @__PURE__ */ p("span", {
							className: "cu-stack-rank",
							children: n === 0 ? i("games.camelup.stackBottom") : n === t.length - 1 ? i("games.camelup.stackTop") : n + 1
						}),
						/* @__PURE__ */ p("img", {
							src: q(e),
							alt: "",
							draggable: !1
						}),
						/* @__PURE__ */ p("strong", { children: i(W[e]) })
					]
				}, e))
			}),
			/* @__PURE__ */ p("button", {
				type: "button",
				className: "cu-stack-close",
				onClick: n,
				children: i("games.camelup.backTrack")
			})
		]
	});
}
//#endregion
//#region src/games/camelup/bot.ts
function Y(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function X(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n = 0; n < 16; n++) e.track[n].forEach((e, r) => {
		e !== "black" && e !== "white" && t.set(e, {
			space: n + 1,
			height: r
		});
	});
	return t;
}
function he(e) {
	let t = X(e), n = new Set(e.rolled.map((e) => e.die)), r = /* @__PURE__ */ new Map();
	for (let e of A) {
		let i = t.get(e);
		i && r.set(e, i.space + i.height * .8 + (n.has(e) ? 0 : 2));
	}
	let i = Math.max(...r.values()), a = 0, o = /* @__PURE__ */ new Map();
	for (let [e, t] of r) {
		let n = Math.exp((t - i) / 2.5);
		o.set(e, n), a += n;
	}
	let s = /* @__PURE__ */ new Map();
	for (let [e, t] of o) s.set(e, t / a);
	return s;
}
function Z(e, t) {
	let n = [];
	for (let r = 2; r <= 16; r++) e.track[r - 1].length > 0 || e.tiles.some((e) => e.owner !== t && Math.abs(e.space - r) <= 1) || e.tiles.find((e) => e.owner === t)?.space !== r && n.push(r);
	return n;
}
var ge = (e, t) => {
	let n = e.public, r = e.private;
	if (n.phase !== "play" || n.turn !== t.rid) return null;
	let i = t.difficulty === "weak", a = n.players.find((e) => e.rid === t.rid);
	if (!a) return null;
	if (i) {
		let e = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % 100;
		if (e < 62) return { action: { type: "roll" } };
		if (e < 87) {
			let e = n.tickets.filter((e) => e.count > 0);
			return e.length > 0 ? { action: {
				type: "takeTicket",
				color: Y(e).color
			} } : { action: { type: "roll" } };
		}
		if (e < 97) {
			let e = Z(n, t.rid);
			return e.length > 0 ? { action: {
				type: "placeTile",
				space: Y(e),
				side: Y(["cheer", "boo"])
			} } : { action: { type: "roll" } };
		}
		let i = r?.cards ?? [];
		return i.length > 0 ? { action: {
			type: "betFinal",
			target: Y(["winner", "loser"]),
			color: Y(i)
		} } : { action: { type: "roll" } };
	}
	let o = he(n), s = (e) => (o.get(e) ?? 0) * .6 * (1 - (o.get(e) ?? 0)), c = (e, t) => {
		let n = o.get(e) ?? 0, r = s(e);
		return t * n + r - (1 - n - r);
	}, l = r?.cards ?? [];
	if (n.leg >= 2 && l.length > 0) {
		let e = [...A].sort((e, t) => (o.get(t) ?? 0) - (o.get(e) ?? 0)), t = e[0], n = e[e.length - 1];
		if (l.includes(t) && (o.get(t) ?? 0) > .45) return { action: {
			type: "betFinal",
			target: "winner",
			color: t
		} };
		if (l.includes(n) && (o.get(n) ?? 0) < .08) return { action: {
			type: "betFinal",
			target: "loser",
			color: n
		} };
	}
	let u = null, d = 1.4;
	for (let e of n.tickets) {
		if (e.count === 0 || e.top === null) continue;
		let t = c(e.color, e.top);
		t > d && (d = t, u = e.color);
	}
	if (u) return { action: {
		type: "takeTicket",
		color: u
	} };
	let f = Z(n, t.rid);
	if (f.length > 0 && a.held.length > 0 && !n.tiles.some((e) => e.owner === t.rid)) {
		let e = X(n), t = /* @__PURE__ */ new Map();
		for (let e of a.held) t.set(e.color, (t.get(e.color) ?? 0) + 1);
		let r = [...t.entries()].filter(([, e]) => e >= 2).map(([e]) => e), i = new Set(n.rolled.map((e) => e.die));
		for (let t of r) {
			let n = e.get(t);
			if (n && !i.has(t)) {
				for (let e of [1, 2]) if (f.includes(n.space + e)) return { action: {
					type: "placeTile",
					space: n.space + e,
					side: "cheer"
				} };
			}
		}
		let s = [...A].sort((e, t) => (o.get(t) ?? 0) - (o.get(e) ?? 0))[0];
		if (!t.has(s)) {
			let t = e.get(s);
			if (t) {
				for (let e of [2, 3]) if (f.includes(t.space + e)) return { action: {
					type: "placeTile",
					space: t.space + e,
					side: "boo"
				} };
			}
		}
	}
	return { action: { type: "roll" } };
}, Q = {
	blue: "games.camelup.camelBlue",
	yellow: "games.camelup.camelYellow",
	green: "games.camelup.camelGreen",
	orange: "games.camelup.camelOrange",
	purple: "games.camelup.camelPurple"
}, _e = (e, t, n) => e.type === "takeTicket" ? n("games.camelup.takeTicketAria", { name: n(Q[e.color]) }) : e.type === "placeTile" ? n(e.side === "cheer" ? "games.camelup.hintTileCheer" : "games.camelup.hintTileBoo", { n: e.space }) : e.type === "roll" ? n("games.camelup.actRoll") : e.type === "betFinal" ? n(e.target === "winner" ? "games.camelup.hintBetWinner" : "games.camelup.hintBetLoser", { name: n(Q[e.color]) }) : "";
//#endregion
//#region src/games/camelup/fx.tsx
function ve(e, t) {
	let n = e.anchor(`cell:${t}`);
	if (!n) return null;
	let r = n.w * (32 / 46), i = r;
	return {
		x: n.x + n.w / 2 - r / 2,
		y: n.y + n.h / 2 - i / 2,
		w: r,
		h: i
	};
}
function $(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
var ye = {
	roll(e, t) {
		let n = e.data;
		if (typeof n?.camel != "string" || typeof n.from != "number" || typeof n.to != "number") return null;
		let r = ve(t, n.from);
		if (!r) return null;
		let i = ve(t, Math.min(16, Math.max(1, n.to)));
		if (!i) return null;
		let a = typeof n.carried == "number" ? n.carried : 0;
		return {
			ms: 650,
			node: /* @__PURE__ */ p(g, {
				from: r,
				to: i,
				ms: 500,
				children: /* @__PURE__ */ m("span", {
					className: "relative inline-flex",
					style: {
						width: r.w,
						height: r.h
					},
					children: [/* @__PURE__ */ p("span", {
						style: {
							transform: `scale(${r.w / 32})`,
							transformOrigin: "top left"
						},
						children: /* @__PURE__ */ p(oe, { camel: n.camel })
					}), a > 0 && /* @__PURE__ */ m("span", {
						className: "absolute -top-1.5 -right-1.5 grid size-4 place-items-center rounded-full border-2 border-ink bg-surface font-mono text-[9px] font-black",
						children: ["+", a]
					})]
				})
			})
		};
	},
	tileHit(e, t) {
		let n = e.data;
		if (typeof n?.space != "number" || typeof n.owner != "string") return null;
		let r = t.anchor(`cell:${n.space}`), i = $(t, n.owner);
		return r ? {
			ms: 700,
			node: /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(_, {
				at: r,
				ms: 700
			}), i && /* @__PURE__ */ p(h, {
				at: i,
				ms: 700,
				children: /* @__PURE__ */ p("span", {
					className: "text-done-ink",
					children: "+1 🪙"
				})
			})] })
		} : null;
	},
	takeTicket(e, t) {
		let n = e.data;
		if (typeof n?.color != "string" || typeof n.value != "number") return null;
		let r = t.anchor(`tickets:${n.color}`), i = $(t, e.rid);
		return !r || !i ? null : {
			ms: 550,
			node: /* @__PURE__ */ p(g, {
				from: r,
				to: i,
				ms: 450,
				children: /* @__PURE__ */ m("span", {
					className: "grid size-8 place-items-center rounded-lg border-2 border-ink font-mono text-sm font-black text-white shadow-[2px_2px_0_var(--color-ink)]",
					style: { backgroundColor: "var(--color-ink)" },
					children: ["🎫", n.value]
				})
			})
		};
	},
	placeTile(e, t) {
		let n = e.data;
		if (typeof n?.space != "number") return null;
		let r = t.anchor(`cell:${n.space}`);
		return r ? {
			ms: 600,
			node: /* @__PURE__ */ p(_, {
				at: r,
				ms: 600
			})
		} : null;
	},
	betFinal(e, t) {
		let n = e.data, r = $(t, e.rid), i = t.anchor(n?.target === "loser" ? "pile:lose" : "pile:win");
		return !r || !i ? null : {
			ms: 550,
			node: /* @__PURE__ */ p(g, {
				from: r,
				to: i,
				ms: 450,
				children: /* @__PURE__ */ p("span", {
					className: "grid size-8 place-items-center rounded-lg border-2 border-ink bg-ink text-surface shadow-[2px_2px_0_var(--color-ink)]",
					children: "🂠"
				})
			})
		};
	},
	legEnd(e, t) {
		let n = e.data;
		return !n?.deltas || typeof n.deltas != "object" ? null : {
			ms: 900,
			node: /* @__PURE__ */ p(be, {
				deltas: n.deltas,
				ctx: t
			})
		};
	},
	gameOver(e, t) {
		let n = e.data;
		if (!n?.deltas || typeof n.deltas != "object") return null;
		let r = { ...n.deltas };
		if (n.finalDeltas && typeof n.finalDeltas == "object") for (let [e, t] of Object.entries(n.finalDeltas)) r[e] = (r[e] ?? 0) + t;
		return {
			ms: 1100,
			node: /* @__PURE__ */ p(be, {
				deltas: r,
				ctx: t
			})
		};
	}
};
function be({ deltas: e, ctx: t }) {
	return /* @__PURE__ */ p(f, { children: Object.entries(e).map(([e, n], r) => {
		let i = $(t, e);
		return !i || n === 0 ? null : /* @__PURE__ */ p(h, {
			at: i,
			ms: 900,
			delay: r * 80,
			children: /* @__PURE__ */ m("span", {
				className: n > 0 ? "text-done-ink" : "text-danger-ink",
				children: [
					n > 0 ? "+" : "",
					n,
					" 🪙"
				]
			})
		}, e);
	}) });
}
//#endregion
//#region src/games/camelup/game-over.tsx
function xe({ hintCount: e, result: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	return /* @__PURE__ */ p(u, {
		adaptive: !0,
		className: "cu-over",
		scroll: !1,
		children: /* @__PURE__ */ p(v, {
			hintCount: e,
			result: t,
			members: n,
			myRid: r,
			accent: x.accent,
			onPlayAgain: i,
			onBackToLobby: a
		})
	});
}
//#endregion
//#region src/games/camelup/options.tsx
function Se({ value: e, onChange: t }) {
	let n = r(), i = T.safeParse(e), a = i.success ? i.data : T.parse(void 0);
	return /* @__PURE__ */ p(b, {
		title: n("games.camelup.optCrazy"),
		children: [!0, !1].map((e) => /* @__PURE__ */ p(y, {
			name: "camelup-crazy",
			value: String(e),
			checked: a.crazy === e,
			label: n(e ? "games.camelup.crazyOn" : "games.camelup.crazyOff"),
			hint: n(e ? "games.camelup.crazyOnHint" : "games.camelup.crazyOffHint"),
			accent: x.accent,
			onChange: () => t({ crazy: e })
		}, String(e)))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/camelup/entry.tsx
var Ce = {
	definition: ae,
	View: se,
	bot: ge,
	describe: _e,
	fx: ye,
	OverView: xe,
	Options: Se,
	locales: {
		zh: {
			name: "狂野骆驼",
			desc: "骆驼赛跑下注:赛段拿票赚快钱,总冠垫底押大牌,小心逆行的疯狂骆驼",
			rules: "目标:比赛结束时,持有埃及镑最多的玩家获胜;平局则共享胜利。\n准备:\n· 5 只竞赛骆驼各自掷骰,放在第 1 至 3 格。\n· 疯狂模式下,2 只疯狂骆驼(黑色、白色)放在第 16 至 14 格,朝相反方向行进。\n· 每名玩家起始持有 3 埃及镑、五种颜色的终点卡各 1 张、观众板块 1 块。\n流程:\n· 顺时针轮流行动,每回合从以下四种行动中选择一种。\n· 拿取任意一叠顶部的下注票,表示你押注该颜色的骆驼在本赛段领先。\n· 放置或移动自己的观众板块:只能放在没有骆驼的空格,不得与已有板块相邻,不能放在第 1 格。\n· 拿取 1 张金字塔票并摇骰:摇出某色骰子,该色骆驼前进 1 至 3 格。\n· 灰色骰子按骰面颜色移动对应的黑色或白色疯狂骆驼,前进掷出的点数格。\n· 将 1 张终点卡面朝下押到最终第一名或最终最后一名牌堆,押出后不可收回。\n移动:\n· 骆驼移动时会驮走位于其上方的所有骆驼;落在已有骆驼的格子时,跳到该栈顶部。\n· 停在观众板块上时,板块主人获得 1 埃及镑;板块对疯狂骆驼的作用方向相反。\n· 欢呼面使骆驼再前进 1 格,嘘声面使骆驼后退 1 格(落格时塞到栈底)。\n· 同一栈内位置靠上的骆驼视为领先;疯狂骆驼不参与任何名次。\n赛段结算:\n· 5 张金字塔票全部被拿走后,本赛段结束,结算下注票:\n· 领先骆驼的票按票面价值(5、3、2)获得埃及镑,第二名的每张获得 1 埃及镑。\n· 其余票每张失去 1 埃及镑,金字塔票每张获得 1 埃及镑。\n· 观众板块归还、下注票重置、骰子放回金字塔,由下一位玩家开始新赛段。\n终局:\n· 任何骆驼(包括逆行的疯狂骆驼)越过终点线时,比赛立即结束,并追加一次赛段结算。\n· 终点卡结算:每堆按押注先后依次翻开。\n· 押中者第 1、2、3、4 张分别获得 8、5、3、2 埃及镑,之后每张获得 1 埃及镑;押错每张失去 1 埃及镑。\n· 最终最后一名为最落后的竞赛骆驼;被疯狂骆驼逆行驮过终点线的骆驼视为最落后。\n· 金钱不会低于 0。\n说明:6 人以上的「投注伙伴」规则未收录。",
			optCrazy: "疯狂骆驼",
			crazyOn: "狂野模式",
			crazyOnHint: "黑白疯狂骆驼逆行捣乱(推荐)",
			crazyOff: "经典模式",
			crazyOffHint: "只有五色竞赛骆驼",
			legChip: "第 {{n}} 赛段",
			rolledLabel: "已出骰子",
			pyramidStock: "金字塔票 {{n}}/{{total}}",
			yourTurn: "你的回合:请选择一种行动",
			waitTurn: "等待 {{name}} 行动…",
			over: "比赛结束",
			actRoll: "摇金字塔",
			actTileCheer: "放欢呼板块",
			actTileBoo: "放嘘声板块",
			tilePickSpace: "点一个空赛道格放置板块",
			betPick: "选一只骆驼押注",
			pileWin: "总冠军",
			pileLose: "总垫底",
			finishLine: "终点",
			takeTicketAria: "拿{{name}}骆驼的下注票",
			cancel: "取消",
			camelBlue: "蓝色",
			camelYellow: "黄色",
			camelGreen: "绿色",
			camelOrange: "橙色",
			camelPurple: "紫色",
			camelBlack: "黑色",
			camelWhite: "白色",
			playersAria: "本局玩家",
			boardAria: "沙漠环形赛道",
			marketAria: "下注票与终点押注",
			tileBoardHint: "高亮空格可放板块",
			crossedUnitAria: "冲过终点的骆驼从底到顶：{{order}}",
			directionCrazy: "顺时针竞赛 · 黑白逆行",
			directionClassic: "顺时针竞赛",
			betDialogAria: "押{{target}}终点牌",
			betPrivateNote: "牌面朝下，押出后不可收回",
			selectFinalAria: "选择{{name}}骆驼终点牌",
			confirmFinal: "确认押{{name}} · {{target}}",
			selectFinalFirst: "先选一张终点牌",
			spaceLegalAria: "{{n}}号格，空位，可放观众板块",
			spaceStackAria: "{{n}}号格，骆驼从底到顶：{{order}}，点按查看",
			spaceCamelAria: "{{n}}号格，{{name}}骆驼",
			spaceEmptyAria: "{{n}}号格，空位",
			spaceTileSuffix: "，{{owner}}的{{side}}板块",
			tileCheer: "欢呼",
			tileBoo: "嘘声",
			pyramidAria: "摇金字塔，剩余{{n}}张金字塔票",
			noDice: "骰子帐篷 · 尚未开骰",
			ticketAria: "拿{{name}}骆驼下注票，票面{{value}}，剩余{{n}}张",
			pileAria: "{{target}}押注堆，已押{{n}}张，点按押牌",
			pileReadonlyAria: "{{target}}押注堆，已押{{n}}张",
			pileEmpty: "押一张终点牌",
			myFinalCards: "自己已押的终点牌",
			stackTitle: "{{n}}号格 · {{count}}只骆驼",
			stackOrderHint: "从底到顶，上方骆驼领先",
			stackBottom: "底",
			stackTop: "顶",
			backTrack: "返回赛道",
			errNotYourTurn: "还没轮到你",
			errNoTicket: "这叠票已拿完",
			errBadTile: "这里不能放板块",
			errNoPyramid: "本赛段的金字塔票已拿完",
			errNoCard: "这张终点卡已押出",
			errOver: "对局已结束",
			hintTileCheer: "在 {{n}} 号格放欢呼板块",
			hintTileBoo: "在 {{n}} 号格放嘘声板块",
			hintBetWinner: "押{{name}}骆驼争总冠军",
			hintBetLoser: "押{{name}}骆驼当总垫底"
		},
		en: {
			name: "Camel Up",
			desc: "Bet on the camel race: leg tickets for quick cash, long-shot cards for glory — and beware the crazy camels",
			rules: "Goal: when the race ends, the player with the most Egyptian Pounds wins; tied players share the victory.\nSetup:\n· The 5 racing camels each roll a die and start on spaces 1 to 3.\n· In crazy mode, the 2 crazy camels (black and white) start on spaces 16 to 14, running in the opposite direction.\n· Each player starts with 3 Egyptian Pounds, one finish card of each color, and 1 spectator tile.\nPlay:\n· Players take turns clockwise, choosing one of the following four actions each turn.\n· Take the top betting ticket of any stack, backing that camel to lead the leg.\n· Place or move your spectator tile: only on a space without camels, never adjacent to another tile, and never on space 1.\n· Take 1 pyramid ticket and roll: the camel of the rolled color moves 1 to 3 spaces.\n· The grey die shows a black or white face: the matching crazy camel moves forward the rolled number of spaces.\n· Place 1 finish card face down onto the overall winner or overall loser pile; once placed, it cannot be taken back.\nMovement:\n· A moving camel carries every camel stacked on top of it; when landing on an occupied space, it jumps on top of that stack.\n· When a unit stops on a spectator tile, the tile’s owner gains 1 Egyptian Pound; tiles affect crazy camels in the opposite direction.\n· The cheering side moves the unit 1 space forward, and the booing side moves it 1 space back (sliding under any stack there).\n· Within a stack, the higher camel is considered ahead; crazy camels never count for any ranking.\nLeg scoring:\n· Once all 5 pyramid tickets have been taken, the leg ends and betting tickets are scored:\n· The leading camel’s tickets pay their printed value (5, 3, 2); each ticket of the runner-up pays 1 Egyptian Pound.\n· Every other ticket loses 1 Egyptian Pound, and each pyramid ticket pays 1 Egyptian Pound.\n· Spectator tiles are returned, betting tickets are restocked, the dice go back into the pyramid, and the next player opens the new leg.\nGame end:\n· The race ends the instant any camel (including a crazy camel running backwards) crosses the finish line, followed by one final leg scoring.\n· Finish cards: each pile is revealed in the order the cards were placed.\n· Correct backers earn 8, 5, 3, and 2 Egyptian Pounds for their 1st, 2nd, 3rd, and 4th correct cards, then 1 Egyptian Pound each; every wrong card loses 1 Egyptian Pound.\n· The overall loser is the least advanced racing camel; racing camels carried backwards across the finish line count as least advanced.\n· Your money can never drop below 0.\nNote: the “betting partnership” rule for 6 or more players is not included.",
			optCrazy: "Crazy camels",
			crazyOn: "Crazy mode",
			crazyOnHint: "Black & white camels run backwards (recommended)",
			crazyOff: "Classic mode",
			crazyOffHint: "Only the five racing camels",
			legChip: "Leg {{n}}",
			rolledLabel: "Rolled dice",
			pyramidStock: "Pyramid tickets {{n}}/{{total}}",
			yourTurn: "Your turn: choose an action",
			waitTurn: "Waiting for {{name}}…",
			over: "Race over",
			actRoll: "Shake the pyramid",
			actTileCheer: "Cheering tile",
			actTileBoo: "Booing tile",
			tilePickSpace: "Tap an empty track space to place the tile",
			betPick: "Pick a camel to back",
			pileWin: "Winner",
			pileLose: "Loser",
			finishLine: "Finish",
			takeTicketAria: "Take a betting ticket of the {{name}} camel",
			cancel: "Cancel",
			camelBlue: "blue",
			camelYellow: "yellow",
			camelGreen: "green",
			camelOrange: "orange",
			camelPurple: "purple",
			camelBlack: "black",
			camelWhite: "white",
			playersAria: "Players in this race",
			boardAria: "Desert race track",
			marketAria: "Betting tickets and finish cards",
			tileBoardHint: "Place a tile on a highlighted space",
			crossedUnitAria: "Camels over the finish, bottom to top: {{order}}",
			directionCrazy: "Clockwise · B/W reverse",
			directionClassic: "Racers move clockwise",
			betDialogAria: "Bet a finish card for {{target}}",
			betPrivateNote: "Played face down and cannot be taken back",
			selectFinalAria: "Select the {{name}} camel finish card",
			confirmFinal: "Bet {{name}} · {{target}}",
			selectFinalFirst: "Choose a finish card first",
			spaceLegalAria: "Space {{n}}, empty, place a spectator tile",
			spaceStackAria: "Space {{n}}, camels bottom to top: {{order}}; tap to inspect",
			spaceCamelAria: "Space {{n}}, {{name}} camel",
			spaceEmptyAria: "Space {{n}}, empty",
			spaceTileSuffix: ", {{owner}}'s {{side}} tile",
			tileCheer: "cheering",
			tileBoo: "booing",
			pyramidAria: "Shake the pyramid; {{n}} pyramid tickets remain",
			noDice: "Dice tent · no dice rolled",
			ticketAria: "Take the {{name}} camel ticket, value {{value}}, {{n}} remain",
			pileAria: "{{target}} finish pile, {{n}} cards played; tap to bet",
			pileReadonlyAria: "{{target}} finish pile, {{n}} cards played",
			pileEmpty: "Play a finish card",
			myFinalCards: "Your played finish cards",
			stackTitle: "Space {{n}} · {{count}} camels",
			stackOrderHint: "Bottom to top; the upper camel leads",
			stackBottom: "Base",
			stackTop: "Top",
			backTrack: "Back to track",
			errNotYourTurn: "Not your turn",
			errNoTicket: "That ticket stack is empty",
			errBadTile: "You can’t place a tile there",
			errNoPyramid: "No pyramid tickets left this leg",
			errNoCard: "That finish card is already played",
			errOver: "The game is over",
			hintTileCheer: "Place a cheer tile on space {{n}}",
			hintTileBoo: "Place a boo tile on space {{n}}",
			hintBetWinner: "Bet {{name}} for overall winner",
			hintBetLoser: "Bet {{name}} for overall loser"
		}
	}
};
//#endregion
export { Ce as default };
