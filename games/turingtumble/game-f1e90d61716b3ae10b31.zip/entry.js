import e from "@dimforge/rapier3d-compat";
import { z as t } from "zod";
import { useCallback as n, useEffect as r, useLayoutEffect as i, useMemo as a, useRef as o, useState as s } from "react";
import { useT as c } from "@bgparty/sdk/i18n";
import { IconBack as l, IconCheck as u, IconClose as d, IconInfo as f, IconLayoutCompact as p, IconMirror as m, IconMove as h, IconPlay as g, IconRecenter as _, IconSettings as v, IconTrash as y, IconZoomIn as b, IconZoomOut as x } from "@bgparty/sdk/icons";
import { useWakeLock as S } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as C } from "@bgparty/sdk/ui/game-screen";
import { useFrame as w, useThree as ee } from "@react-three/fiber";
import * as T from "three";
import { Box2 as E, BufferAttribute as D, BufferGeometry as O, CanvasTexture as te, ClampToEdgeWrapping as ne, Color as k, DoubleSide as A, FileLoader as j, Float32BufferAttribute as M, Loader as N, Matrix3 as P, MeshBasicMaterial as F, MirroredRepeatWrapping as I, Path as re, RepeatWrapping as ie, SRGBColorSpace as L, ShapePath as ae, ShapeUtils as oe, Vector2 as R, Vector3 as z } from "three";
import { ResilientCanvas as se } from "@bgparty/sdk/three/resilient-canvas";
import { Fragment as ce, jsx as B, jsxs as V } from "react/jsx-runtime";
//#region src/games/turingtumble/initialize.ts
var le;
function H() {
	return le ??= e.init().catch((e) => {
		throw le = void 0, e;
	});
}
//#endregion
//#region src/games/turingtumble/data.ts
var ue = await fetch("games/turingtumble/data/challenges.json").then((e) => e.json()), de = {
	ramp: "games.turingtumble.ramp",
	crossover: "games.turingtumble.crossover",
	bit: "games.turingtumble.bit",
	interceptor: "games.turingtumble.interceptor",
	gearbit: "games.turingtumble.gearbit",
	gear: "games.turingtumble.gear"
};
function fe(e, t) {
	let n = e.find((e) => e.id === t);
	if (!n || !["gear", "gearbit"].includes(n.kind)) return n ? [n] : [];
	let r = [n];
	for (let t = 0; t < r.length; t++) {
		let n = r[t];
		for (let t of e) ["gear", "gearbit"].includes(t.kind) && !r.includes(t) && Math.abs(t.row - n.row) + Math.abs(t.col - n.col) === 1 && r.push(t);
	}
	return r;
}
//#endregion
//#region src/games/turingtumble/meta.ts
var pe = {
	id: "turingtumble",
	tier: "beta",
	mechanics: [
		"tile-placement",
		"route-building",
		"deduction"
	],
	interactionTags: [],
	nameKey: "games.turingtumble.name",
	descKey: "games.turingtumble.desc",
	rulesKey: "games.turingtumble.rules",
	icon: "⚙️",
	iconImg: "games/turingtumble.webp",
	rulesUrl: { zh: "https://rules.bgparty.uuppi.com/turingtumble/zh.pdf" },
	minPlayers: 1,
	maxPlayers: 1,
	bestPlayers: [1],
	accent: "#398169",
	releasedAt: "2026-10-18T23:26:13+08:00",
	search: {
		py: "tu ling fan zhuan",
		init: "tlfz"
	},
	hotseat: "open"
}, me = {
	ramp: [
		[
			{
				x: 13.000001,
				y: -13.999998
			},
			{
				x: -32.000005,
				y: -24.999972
			},
			{
				x: -34.000006,
				y: -29.999985
			},
			{
				x: -34.000006,
				y: -31.999997
			},
			{
				x: -32.000005,
				y: -32.999985
			},
			{
				x: 16.000001,
				y: -21.000023
			}
		],
		[
			{
				x: 16.000001,
				y: -21.000023
			},
			{
				x: 25.000001,
				y: -24.000023
			},
			{
				x: 30.000002,
				y: -21.000023
			},
			{
				x: 23,
				y: -16.000011
			},
			{
				x: 14,
				y: -16.000011
			}
		],
		[
			{
				x: 25.000001,
				y: -24.000023
			},
			{
				x: 27.759381,
				y: -30.97446
			},
			{
				x: 30.000002,
				y: -31.999997
			},
			{
				x: 33.000002,
				y: -30.000023
			},
			{
				x: 30.000002,
				y: -21.000023
			}
		],
		[
			{
				x: -8.000006,
				y: 3.000014
			},
			{
				x: -27.999999,
				y: 10.999989
			},
			{
				x: -33,
				y: 18.000014
			},
			{
				x: -33,
				y: 25.999988
			},
			{
				x: -27.000004,
				y: 33.000013
			},
			{
				x: -16.000007,
				y: 33.000013
			},
			{
				x: -11.000006,
				y: 25.000001
			},
			{
				x: -5.000006,
				y: 6.000014
			}
		],
		[
			{
				x: -4,
				y: -7.000011
			},
			{
				x: -7.999998,
				y: -3.000024
			},
			{
				x: -7.999998,
				y: 1.999989
			},
			{
				x: -4,
				y: 7.000001
			},
			{
				x: 8.999999,
				y: 13.999989
			},
			{
				x: 14,
				y: 13.999989
			},
			{
				x: 14,
				y: 9.000014
			},
			{
				x: 5.999999,
				y: -6.000023
			}
		],
		[
			{
				x: -4,
				y: -17.999985
			},
			{
				x: 12.999997,
				y: -13.999998
			},
			{
				x: 5.999999,
				y: -6.000023
			},
			{
				x: -4,
				y: -7.000011
			}
		]
	],
	bit: [
		[
			{
				x: -1.05523,
				y: -32.311157
			},
			{
				x: .083096,
				y: -27.714949
			},
			{
				x: -27.716345,
				y: .194329
			},
			{
				x: -32.193815,
				y: -1.017236
			},
			{
				x: -34.041082,
				y: -34.054879
			}
		],
		[
			{
				x: -9.275339,
				y: -18.69934
			},
			{
				x: -18.644512,
				y: -8.976619
			},
			{
				x: -1e-6,
				y: 14.000036
			},
			{
				x: 12.203027,
				y: 15.153396
			},
			{
				x: 15.29662,
				y: 11.971412
			},
			{
				x: 13.999992,
				y: 24e-6
			}
		],
		[
			{
				x: 26.999991,
				y: -2.999976
			},
			{
				x: 27.62537,
				y: -30.03864
			},
			{
				x: 27.844205,
				y: -31.163654
			},
			{
				x: 28.781679,
				y: -32.163642
			},
			{
				x: 30.000425,
				y: -32.538571
			},
			{
				x: 31.156696,
				y: -32.288366
			},
			{
				x: 32.156683,
				y: -31.507138
			},
			{
				x: 32.625458,
				y: -30.163364
			},
			{
				x: 31.999992,
				y: -2.999976
			}
		],
		[
			{
				x: -4.000007,
				y: 27.000023
			},
			{
				x: -30.292815,
				y: 27.954316
			},
			{
				x: -31.416144,
				y: 28.181465
			},
			{
				x: -32.409014,
				y: 29.126461
			},
			{
				x: -32.774721,
				y: 30.348004
			},
			{
				x: -32.515786,
				y: 31.502385
			},
			{
				x: -31.727017,
				y: 32.496401
			},
			{
				x: -30.37974,
				y: 32.955008
			},
			{
				x: -4.000007,
				y: 32.000035
			}
		],
		[
			{
				x: 26.999991,
				y: -2.999976
			},
			{
				x: 13.999992,
				y: 24e-6
			},
			{
				x: 15.385008,
				y: 12.059815
			},
			{
				x: 28.731649,
				y: 2.602266
			},
			{
				x: 31.999992,
				y: -2.999976
			}
		],
		[
			{
				x: -4.000007,
				y: 27.000023
			},
			{
				x: 33e-6,
				y: 14.000036
			},
			{
				x: 11.959138,
				y: 15.360666
			},
			{
				x: 2.501589,
				y: 28.707311
			},
			{
				x: -4.000007,
				y: 32.000035
			}
		]
	],
	gearbit: [
		[
			{
				x: -19.999999,
				y: 16.000007
			},
			{
				x: -22.637134,
				y: 25.233204
			},
			{
				x: -19.101594,
				y: 28.768725
			},
			{
				x: -14.858953,
				y: 22.316391
			},
			{
				x: -14.682185,
				y: 16.040826
			}
		],
		[
			{
				x: -22.637134,
				y: 25.144801
			},
			{
				x: -30.857243,
				y: 28.326785
			},
			{
				x: -30.945646,
				y: 32.569418
			},
			{
				x: -23.962966,
				y: 32.216032
			},
			{
				x: -18.748057,
				y: 28.326936
			}
		],
		[
			{
				x: 15.999997,
				y: -20.000005
			},
			{
				x: 25.16811,
				y: -23.063501
			},
			{
				x: 28.703632,
				y: -19.527961
			},
			{
				x: 22.251298,
				y: -15.285321
			},
			{
				x: 15.975733,
				y: -15.108552
			}
		],
		[
			{
				x: 25.079707,
				y: -23.063501
			},
			{
				x: 28.261691,
				y: -31.283611
			},
			{
				x: 32.504324,
				y: -31.372014
			},
			{
				x: 32.150939,
				y: -24.389333
			},
			{
				x: 28.261843,
				y: -19.174424
			}
		],
		[
			{
				x: -27.999999,
				y: -32.000001
			},
			{
				x: 15.999997,
				y: -20.000002
			},
			{
				x: 6.999994,
				y: 7.000024
			},
			{
				x: -20.000002,
				y: 16.000001
			},
			{
				x: -32.000001,
				y: -28.000003
			},
			{
				x: -31.999994,
				y: -31.999986
			}
		]
	],
	crossover: [
		[
			{
				x: -.125001,
				y: -48.25001
			},
			{
				x: -2.75,
				y: -46.000019
			},
			{
				x: -2.75,
				y: -15.874993
			},
			{
				x: 2.999999,
				y: -15.874993
			},
			{
				x: 2.999999,
				y: -46.374986
			}
		],
		[
			{
				x: -3.000008,
				y: -15.999982
			},
			{
				x: -12.000004,
				y: -9.999982
			},
			{
				x: -2.249999,
				y: 4.250008
			},
			{
				x: 2.374997,
				y: 4.250008
			},
			{
				x: 11.999991,
				y: -9.999982
			},
			{
				x: 2.999991,
				y: -15.999982
			}
		],
		[
			{
				x: -32.250002,
				y: 31.999979
			},
			{
				x: -.051777,
				y: 29.50258
			},
			{
				x: 31.124997,
				y: 31.499985
			},
			{
				x: 32.874998,
				y: 34.374996
			},
			{
				x: 30.374999,
				y: 36.999991
			},
			{
				x: -30.250001,
				y: 36.999991
			},
			{
				x: -32.749999,
				y: 35.125005
			}
		],
		[
			{
				x: -36.000004,
				y: -27.999982
			},
			{
				x: -43.000006,
				y: -5.000008
			},
			{
				x: -48.000003,
				y: -2.999995
			},
			{
				x: -45.000003,
				y: -20.999995
			},
			{
				x: -36.000004,
				y: -35.999994
			}
		],
		[
			{
				x: -43.000006,
				y: -5.000008
			},
			{
				x: -33.000004,
				y: 6.999992
			},
			{
				x: -39.000004,
				y: 6.999992
			},
			{
				x: -48.000003,
				y: -2.999995
			}
		],
		[
			{
				x: -35.999992,
				y: -35.999994
			},
			{
				x: -32.000005,
				y: -35.999994
			},
			{
				x: -31.999994,
				y: -31.999969
			},
			{
				x: -36,
				y: -27.999982
			}
		],
		[
			{
				x: 35.999937,
				y: -27.999982
			},
			{
				x: 42.99994,
				y: -5.000008
			},
			{
				x: 47.999937,
				y: -2.999995
			},
			{
				x: 44.999937,
				y: -20.999995
			},
			{
				x: 35.999937,
				y: -35.999994
			}
		],
		[
			{
				x: 42.99994,
				y: -5.000008
			},
			{
				x: 32.999938,
				y: 6.999992
			},
			{
				x: 38.999937,
				y: 6.999992
			},
			{
				x: 47.999937,
				y: -2.999995
			}
		],
		[
			{
				x: 35.999926,
				y: -35.999994
			},
			{
				x: 31.999992,
				y: -35.999994
			},
			{
				x: 31.999988,
				y: -31.999969
			},
			{
				x: 35.999934,
				y: -27.999982
			}
		]
	],
	interceptor: [
		[
			{
				x: -45.691339,
				y: -8.678367
			},
			{
				x: 45.525428,
				y: -8.678367
			},
			{
				x: 46.50767,
				y: -3.375047
			},
			{
				x: -46.60035,
				y: -3.375047
			}
		],
		[
			{
				x: -40.374999,
				y: -8.249995
			},
			{
				x: -28.5,
				y: -30.875002
			},
			{
				x: -33.125,
				y: -33.624986
			},
			{
				x: -42,
				y: -20.749988
			},
			{
				x: -45.625001,
				y: -9.124993
			}
		],
		[
			{
				x: 40.624998,
				y: -8.249995
			},
			{
				x: 28.749999,
				y: -30.875002
			},
			{
				x: 33.374999,
				y: -33.624986
			},
			{
				x: 42.249998,
				y: -20.749988
			},
			{
				x: 45.875,
				y: -9.124993
			}
		],
		[
			{
				x: -6.999999,
				y: -3.499998
			},
			{
				x: -6.50001,
				y: 3.625016
			},
			{
				x: -12e-6,
				y: 6.999982
			},
			{
				x: 6.374988,
				y: 3.624978
			},
			{
				x: 6.499977,
				y: -3.499998
			}
		]
	]
}, he = [
	.5,
	1,
	2,
	4,
	6,
	8
], ge = 16.1, _e = 13.8, ve = [
	-.055,
	-.035,
	0
], ye = [
	[5.62, -5.88],
	[4.25, -6.05],
	[2.72, -6.25],
	[1.2, -6.5],
	[.52, -6.59]
], be = (e) => e === "blue" ? -1 : 1, xe = (e, t) => ({
	x: (e === 0 ? -1 : 1) * (2.48 + t * .4),
	y: 6.29
}), Se = [
	"ramp",
	"crossover",
	"bit",
	"interceptor",
	"gearbit",
	"gear"
], U = (e, t) => `${e},${t}`, W = (e, t) => ({
	x: t - 5,
	y: 4.75 - e
});
function Ce(e, t, n) {
	return e < 0 || e > 10 || t < 0 || t > 10 || e === 0 && (t < 2 || t > 8 || t === 5) || e === 1 && (t === 0 || t === 10) || e === 10 && t !== 5 ? !1 : n === "gear" || (e + t) % 2 == 1;
}
//#endregion
//#region src/games/turingtumble/physics.ts
var we = 1 / 120, Te = .66, G = Math.PI / 2, Ee = 65538, De = 131075, Oe = (e) => ({
	x: 0,
	y: 0,
	z: Math.sin(e / 2),
	w: Math.cos(e / 2)
}), ke = (e) => 2 * Math.atan2(e.rotation().z, e.rotation().w), Ae = (e) => e.kind === "gear" && (e.row + e.col) % 2 == 0 ? -1 : 1, K = (e) => e.kind === "gear" || e.kind === "gearbit", je = (e) => {
	let t = "";
	for (let n = 0; n < e.length; n += 8192) t += String.fromCharCode(...e.subarray(n, n + 8192));
	return btoa(t);
}, Me = (e) => Uint8Array.from(atob(e), (e) => e.charCodeAt(0));
function Ne(t, n) {
	let r = [];
	for (let [e, t] of ye) for (let i of [-.065, .065]) for (let a of [-.3, .3]) r.push(n * e, t + i, a);
	let i = e.ColliderDesc.convexHull(new Float32Array(r));
	t.createCollider(i.setTranslation(0, 0, Te).setFriction(.04).setRestitution(0).setCollisionGroups(Ee));
}
function Pe(e) {
	let t = [], n = /* @__PURE__ */ new Set();
	for (let r = 0; r < e.length; r++) {
		if (!K(e[r]) || n.has(r)) continue;
		let i = [r];
		n.add(r);
		for (let t = 0; t < i.length; t++) {
			let r = e[i[t]];
			for (let t = 0; t < e.length; t++) {
				let a = e[t];
				!n.has(t) && K(a) && Math.abs(r.row - a.row) + Math.abs(r.col - a.col) === 1 && (n.add(t), i.push(t));
			}
		}
		i.length > 1 && t.push(i);
	}
	return t;
}
function Fe(e, t, n, r) {
	for (let i of r) {
		let r = 0, a = 0, o = 0;
		for (let s of i) {
			let i = e.getRigidBody(n[s]), c = Math.max(i.principalInertia().z, 1e-5);
			r += c, a += ke(i) * Ae(t[s]) * c, o += i.angvel().z * Ae(t[s]) * c;
		}
		a = Math.max(-G, Math.min(0, a / r)), o /= r, (a === 0 && o > 0 || a === -G && o < 0) && (o = 0);
		for (let r of i) {
			let i = e.getRigidBody(n[r]);
			i.setRotation(Oe(a * Ae(t[r])), !0), i.setAngvel({
				x: 0,
				y: 0,
				z: o * Ae(t[r])
			}, !0);
		}
	}
}
function Ie(e, t) {
	return {
		readout: {
			step: t.step,
			remaining: [...t.remaining],
			outputCount: t.output.length,
			caughtCount: t.caught.length,
			feedback: t.feedback
		},
		angles: t.handles.map((t) => ke(e.getRigidBody(t))),
		balls: t.ballHandles.map((t) => {
			let n = e.getRigidBody(t.handle).translation();
			return {
				id: t.id,
				color: t.color,
				x: n.x,
				y: n.y
			};
		})
	};
}
function Le(t, n, r) {
	let i = r === "blue" ? 0 : 1;
	if (n.remaining[i] <= 0) return !1;
	n.remaining[i]--;
	let a = n.reservoirs?.[i].shift() ?? r, o = t.createRigidBody(e.RigidBodyDesc.dynamic().setTranslation(r === "blue" ? -2.15 : 2.15, 5.92, Te).enabledTranslations(!0, !0, !1).enabledRotations(!1, !1, !0).setCcdEnabled(!0));
	return t.createCollider(e.ColliderDesc.ball(.147).setDensity(4.5).setFriction(.035).setRestitution(0).setCollisionGroups(De), o), o.setLinvel({
		x: r === "blue" ? .15 : -.15,
		y: 0,
		z: 0
	}, !0), n.ballHandles.push({
		handle: o.handle,
		id: n.nextId++,
		color: a,
		row: -1,
		col: r === "blue" ? 3 : 7,
		entered: "",
		direction: r === "blue" ? 1 : -1,
		age: 0,
		stopped: 0
	}), n.finished = !1, n.waiting = !1, !0;
}
function Re(t, n, r, i) {
	let a = new e.World({
		x: 0,
		y: -7.2,
		z: 0
	});
	a.timestep = we, a.numSolverIterations = 16, a.integrationParameters.erp = .05;
	let o = a.createRigidBody(e.RigidBodyDesc.fixed()), s = [];
	for (let n of t) {
		let t = W(n.row, n.col), r = n.kind === "ramp" || n.kind === "bit" || K(n), i = n.kind === "bit" || K(n) ? (n.right ? -G : 0) * Ae(n) : 0, c = r ? e.RigidBodyDesc.dynamic() : e.RigidBodyDesc.fixed(), l = a.createRigidBody(c.setTranslation(t.x, t.y, Te).setGravityScale(0).setAngularDamping(1.4).setCanSleep(!1).setCcdEnabled(!0));
		if (s.push(l.handle), n.kind === "gear") a.createCollider(e.ColliderDesc.cylinder(.08, .38).setRotation({
			x: Math.SQRT1_2,
			y: 0,
			z: 0,
			w: Math.SQRT1_2
		}).setDensity(.08).setCollisionGroups(0), l);
		else for (let t of me[n.kind]) {
			let r = [];
			for (let e of [-.24, .24]) for (let i of t) r.push(i.x / 68 * (n.kind === "ramp" && !n.right ? -1 : 1), -i.y / 68, e);
			let i = e.ColliderDesc.convexHull(new Float32Array(r));
			i && a.createCollider(i.setDensity(n.kind === "ramp" ? .4 : .16).setFriction(.035).setRestitution(0).setCollisionGroups(Ee), l);
		}
		if (r) {
			let r = a.createImpulseJoint(e.JointData.revolute({
				...t,
				z: Te
			}, {
				x: 0,
				y: 0,
				z: 0
			}, {
				x: 0,
				y: 0,
				z: 1
			}), o, l, !0);
			n.kind === "ramp" ? (r.setLimits(n.right ? -1.5 : 0, n.right ? 0 : 1.5), r.configureMotorPosition(0, 1.2, .55)) : r.setLimits(Ae(n) > 0 ? -G : 0, Ae(n) > 0 ? 0 : G);
		}
		l.setRotation(Oe(i), !0);
	}
	for (let e of [-1, 1]) Ne(a, e);
	let c = {
		snapshot: "",
		handles: s,
		ballHandles: [],
		step: 0,
		remaining: [...n],
		output: [],
		caught: [],
		failure: null,
		nextId: 0,
		waiting: !0,
		finished: !1,
		pose: {
			angles: [],
			balls: []
		},
		frames: [],
		...i ? { reservoirs: structuredClone(i) } : {}
	};
	return r && Le(a, c, r), c.pose = Ie(a, c), c.snapshot = je(a.takeSnapshot()), a.free(), c;
}
function ze(t, n) {
	let r = structuredClone(t), i = e.World.restoreSnapshot(Me(r.snapshot));
	return Le(i, r, n), r.pose = Ie(i, r), r.snapshot = je(i.takeSnapshot()), i.free(), r;
}
function Be(t, n, r = 12, i = !1, a = !1, o = !0, s) {
	let c = structuredClone(t), l = e.World.restoreSnapshot(Me(c.snapshot)), u = Pe(n), d = new Map(n.map((e) => [U(e.row, e.col), e]));
	c.frames = [];
	try {
		c.pendingRelease && !c.finished && (Le(l, c, c.pendingRelease), c.pendingRelease = void 0);
		for (let e = 0; e < r && !c.finished; e++) {
			for (let e of c.ballHandles) {
				let t = l.getRigidBody(e.handle), n = t.linvel();
				(Math.abs(n.x) > 1.15 || n.y < -2.4) && t.setLinvel({
					x: Math.max(-1.15, Math.min(1.15, n.x)),
					y: Math.max(-2.4, n.y),
					z: 0
				}, !0);
			}
			for (let e = 0; e < n.length; e++) {
				let t = n[e];
				if (t.kind !== "bit" && t.kind !== "gearbit") continue;
				let r = l.getRigidBody(c.handles[e]), i = ke(r), a = i < -G / 2 ? -G : 0;
				r.applyTorqueImpulse({
					x: 0,
					y: 0,
					z: ((a - i) * .012 - r.angvel().z * .002) * we
				}, !0);
			}
			l.step(), Fe(l, n, c.handles, u), c.step++;
			let e = /* @__PURE__ */ new Set(), t;
			for (let r of c.ballHandles) {
				let a = l.getRigidBody(r.handle), o = a.translation(), u = a.linvel();
				r.age++;
				let f = Math.floor(5.3 - o.y);
				if (f >= 0 && f <= 10 && f > r.row && o.y > -5.5) {
					let e = (f + 1) % 2, t = Math.round((o.x + 5 - e) / 2) * 2 + e, n = d.get(U(f, t));
					f < 10 && Ce(f, t, "ramp") && (!n || n.kind === "gear") && (c.failure = "gap"), r.row >= 0 && t !== r.col && (r.direction = Math.sign(t - r.col)), r.row = f, r.col = t, r.entered = n?.id ?? "";
				}
				let p = n.find((e) => e.id === r.entered);
				if (p) {
					let t = W(p.row, p.col), i = o.y - t.y;
					if (p.kind === "interceptor" && Math.abs(o.x - t.x) < .62 && i > -.1 && i < .7 && Math.hypot(u.x, u.y) < .3) {
						if (r.stopped++, r.stopped > 25) {
							c.caught.push({
								color: r.color,
								part: p.id
							}), e.add(r.id), l.removeRigidBody(a);
							continue;
						}
					} else if (Math.abs(u.x) < .35 && Math.abs(u.y) < .4 && Math.abs(i) < .7 && p.kind !== "interceptor") {
						let e = p.kind === "ramp" ? p.right ? 1 : -1 : r.direction, t = n.indexOf(p);
						p.kind === "bit" && (e = ke(l.getRigidBody(c.handles[t])) < -G / 2 ? i > 0 ? -1 : 1 : i > 0 ? 1 : -1), p.kind === "gearbit" && (e = ke(l.getRigidBody(c.handles[t])) < -G / 2 ? -1 : 1), a.applyImpulse({
							x: e * 15e-5,
							y: 0,
							z: 0
						}, !0);
					}
				}
				if (o.y < -5.65 && !r.feedback && (r.feedback = o.x < 0 ? "blue" : "red"), o.y < -6.55 && r.stopped !== -1 && Math.abs(o.x) < 5.6) {
					r.stopped = -1, c.output.push(r.color);
					let n = c.output.length - 1;
					if (s !== void 0 && s[n] !== (r.color === "blue" ? "b" : "r")) {
						c.failure = "goal";
						break;
					}
					c.feedback = {
						id: r.id,
						side: r.feedback ?? (o.x < 0 ? "blue" : "red")
					}, i || (t = c.feedback.side), e.add(r.id), l.removeRigidBody(a);
				} else o.y < -9 || Math.abs(o.x) > 6 ? c.failure = "escaped" : r.age > 7200 && (c.failure = "stalled");
			}
			if (c.ballHandles = c.ballHandles.filter((t) => !e.has(t.id)), a && n.every((e, t) => e.kind !== "gearbit" || ke(l.getRigidBody(c.handles[t])) < -G / 2) && (t = void 0), t && c.remaining[t === "blue" ? 0 : 1] > 0 && !c.failure && (o ? c.pendingRelease = t : Le(l, c, t)), (c.failure || c.step > 72e3) && (c.finished = !0), !c.ballHandles.length && !c.pendingRelease && (c.finished = !i || c.remaining.every((e) => e === 0) || c.caught.length > 0, c.waiting = !c.finished), o && (c.pose = Ie(l, c), c.frames.push(c.pose)), c.pendingRelease) break;
		}
		return c.pose = Ie(l, c), c.snapshot = je(l.takeSnapshot()), c;
	} finally {
		l.free();
	}
}
function Ve(e, t) {
	return Object.fromEntries(e.map((e, n) => [e.id, e.kind === "ramp" ? e.right : t.pose.angles[n] * Ae(e) < -G / 2]));
}
function He(t, n, r) {
	let i = structuredClone(t), a = e.World.restoreSnapshot(Me(i.snapshot));
	for (let e = 0; e < n.length; e++) {
		if (!K(n[e])) continue;
		let t = a.getRigidBody(i.handles[e]);
		t.setRotation(Oe((r ? -G : 0) * Ae(n[e])), !0), t.setAngvel({
			x: 0,
			y: 0,
			z: 0
		}, !0);
	}
	return i.pose = Ie(a, i), i.snapshot = je(a.takeSnapshot()), a.free(), i;
}
//#endregion
//#region src/games/turingtumble/schema.ts
var q = t.int().min(0).max(10), J = t.enum(["blue", "red"]), Ue = t.object({
	id: t.string().max(30),
	kind: t.enum(Se),
	row: q,
	col: q,
	right: t.boolean(),
	fixed: t.boolean(),
	label: t.string().max(8).optional()
}), Y = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("place"),
		kind: t.enum(Se),
		row: q,
		col: q,
		right: t.boolean()
	}),
	t.object({
		type: t.literal("move"),
		id: t.string(),
		row: q,
		col: q
	}),
	t.object({
		type: t.literal("flip"),
		id: t.string()
	}),
	t.object({
		type: t.literal("remove"),
		id: t.string()
	}),
	t.object({ type: t.literal("undo") }),
	t.object({ type: t.literal("reset") }),
	t.object({ type: t.literal("edit") }),
	t.object({ type: t.literal("run") }),
	t.object({ type: t.literal("pause") }),
	t.object({
		type: t.literal("speed"),
		value: t.union([
			t.literal(.5),
			t.literal(1),
			t.literal(2),
			t.literal(4),
			t.literal(6),
			t.literal(8)
		])
	}),
	t.object({
		type: t.literal("goto"),
		n: t.int().min(1).max(60)
	}),
	t.object({
		type: t.literal("input"),
		blue: t.int().min(0).max(20),
		start: J
	}),
	t.object({ type: t.literal("release") }),
	t.object({ type: t.literal("end-turn") }),
	t.object({
		type: t.literal("tick"),
		now: t.number().finite()
	})
]), We = t.object({
	angles: t.array(t.number()),
	balls: t.array(t.object({
		id: t.int(),
		color: J,
		x: t.number(),
		y: t.number()
	})),
	readout: t.object({
		step: t.int(),
		remaining: t.tuple([t.int(), t.int()]),
		outputCount: t.int(),
		caughtCount: t.int(),
		feedback: t.object({
			id: t.int(),
			side: J
		}).optional()
	}).optional()
}), Ge = t.object({
	challenge: t.int().min(1).max(60),
	parts: t.array(Ue),
	phase: t.enum([
		"build",
		"running",
		"paused",
		"checking",
		"passed",
		"failed"
	]),
	balls: t.tuple([t.int(), t.int()]),
	start: J,
	speed: t.number(),
	remaining: t.tuple([t.int(), t.int()]),
	output: t.array(J),
	caught: t.array(t.object({
		color: J,
		part: t.string()
	})),
	pose: We.nullable(),
	frames: t.array(We),
	revision: t.int(),
	canUndo: t.boolean(),
	check: t.object({
		done: t.int(),
		total: t.int()
	}),
	failure: t.enum([
		"gap",
		"escaped",
		"stalled",
		"goal",
		"nim"
	]).nullable(),
	nim: t.object({
		turn: t.enum(["human", "machine"]),
		taken: t.int()
	})
}), Ke = t.object({});
//#endregion
//#region src/games/turingtumble/verification.ts
function qe(e, t) {
	let n = structuredClone(e);
	for (let [e, r] of Object.entries(t.values)) for (let t of fe(n, e)) t.right = r;
	return n;
}
function Je(e, t, n, r) {
	if (e.output !== void 0) return e.output;
	if ([
		21,
		22,
		31,
		40,
		53
	].includes(e.n)) return "b".repeat(n[0]);
	if (e.n === 32) return r === "blue" ? "b" : "r";
	if (e.n === 38) {
		let n = Ye(e, "A", Object.fromEntries(t.map((e) => [e.id, e.right])));
		return "b" + [
			0,
			1,
			2
		].map((e) => n & 2 ** e ? "b" : "r").join("");
	}
	if (e.n === 41) return "b";
}
function Ye(e, t, n) {
	return e.registers.find((e) => e.name === t)?.cells.reduce((e, t, r) => e + (n[t] ? 2 ** r : 0), 0) ?? 0;
}
var Xe = /* @__PURE__ */ new WeakMap();
function Ze(e) {
	let t = Xe.get(e);
	if (t) return t;
	let n = [], r = e.variables;
	e.n === 32 && (r = ["4,5"]), e.n === 33 && (r = ["5,2", "5,8"]);
	for (let t = 0; t < 2 ** r.length; t++) {
		let i = Object.fromEntries(r.map((e, n) => [e, !!(t & 2 ** n)])), a = Ye(e, "A", i), o = Ye(e, "B", i);
		if (e.n === 44 && a > o || e.n === 47 && a + o > 7 || e.n === 48 && a > 5 || e.n === 56 && a * o > 7 || e.n === 57 && Object.values(i).filter(Boolean).length > 1) continue;
		let s = [e.balls[0]];
		[21, 22].includes(e.n) && (s = Array.from({ length: 16 }, (e, t) => t)), e.n === 30 && (s = Array.from({ length: 21 }, (e, t) => t)), [31, 40].includes(e.n) && (s = Array.from({ length: 8 }, (e, t) => t)), e.n === 53 && (s = Array.from({ length: 21 }, (e, t) => t));
		for (let t of s) {
			let r = e.n === 32 ? ["blue", "red"] : [e.start];
			for (let a of r) n.push({
				values: i,
				balls: [t, e.balls[1]],
				start: a
			});
		}
	}
	return Xe.set(e, n), n;
}
function Qe(e, t, n, r, i) {
	if (i.failure) return !1;
	let a = Object.fromEntries(t.map((e) => [e.id, e.right])), o = Ve(t, i), s = t.filter((e) => e.kind === "bit" || e.kind === "gearbit"), c = e.variables.map((e) => t.find((t) => t.id === e)).filter((e) => !!e), l = Ye(e, "A", a), u = Ye(e, "B", a), d = Ye(e, "A", o), f = Ye(e, "B", o), p = Ye(e, "C", o), m = i.output.map((e) => e === "blue" ? "b" : "r").join(""), h = (e) => i.caught.length === 1 && i.caught[0].color === (e ? "blue" : "red"), g = c[0] ? a[c[0].id] : !1, _ = c.length >= 2 && a[c[0].id] && a[c[1].id], v = c.length >= 2 && a[c[0].id] !== a[c[1].id];
	switch (e.n) {
		case 5:
		case 6:
		case 8: return m === "br".repeat(8);
		case 9: return m === "bbr".repeat(5);
		case 10: return m === "bbrr".repeat(8);
		case 11: return s.filter((e) => e.row === 6).every((e) => o[e.id] === (e.label === "2" || e.label === "5"));
		case 12: return h(!0);
		case 13: return h(!1);
		case 14: return h(!g);
		case 15: return h(!a["8,5"]);
		case 16: return m === "bbb" && h(!0);
		case 18: return i.caught.length === 1 && t.find((e) => e.id === i.caught[0].part)?.label === (_ ? "T" : "F");
		case 19:
		case 36: return h(_);
		case 20: return h(c.some((e) => a[e.id]));
		case 21: return d === n[0] && i.output.length === n[0];
		case 22: return d === 15 - n[0] && i.output.length === n[0];
		case 23: return m === "bbbb" && h(!0);
		case 24: return m === "bbbbbbbbb" && h(!0);
		case 27:
		case 46: return e.variables.every((e) => o[e] !== a[e]);
		case 30: return d === n[0] % 8 && o["5,2"] === n[0] > 7;
		case 31: return d === (a["0,3"] ? 0 : n[0]) && f === (a["0,3"] ? n[0] : 0) && i.output.length === n[0];
		case 32: return o["4,5"] === (r === "red") && i.output.length === 1;
		case 33: return o["5,8"] === a["5,2"] && o["5,2"] === a["5,2"];
		case 34:
		case 43: return h(v);
		case 35: return h(l % 2 == 0);
		case 37: return l + u < 16 ? f === l + u && h(!0) : h(!1);
		case 38: return m === "b" + [
			0,
			1,
			2
		].map((e) => l & 2 ** e ? "b" : "r").join("");
		case 39: return m === "bbbr".repeat(4);
		case 40: return d === n[0] * 4 && i.output.length === n[0];
		case 41: return d === 0 && i.output.length === 1;
		case 42: return h(l > u);
		case 44: return f === u - l;
		case 45: return h(l <= u);
		case 47: return f === l + u;
		case 48: return f === 3 * l;
		case 52: return f === 5 * l;
		case 53: return d === l * 2 ** n[0] % 8 && i.output.length === n[0];
		case 54: return t.filter((e) => e.row === 9).every((e) => o[e.id] === (Number(e.label) === l));
		case 55: return f === Math.floor(l / 3);
		case 56: return p === l * u;
		case 57: {
			let e = c.find((e) => e.kind === "ramp" && e.right);
			return d === (e ? Number(e.label) : 0);
		}
		case 59: return !1;
		case 60: return i.caught.length === 1 && t.find((e) => e.id === i.caught[0].part)?.label === (l < u ? "L" : l === u ? "E" : "G");
		default: return e.output !== void 0 && m === e.output;
	}
}
//#endregion
//#region src/games/turingtumble/rules.ts
var X = () => ({ code: "games.turingtumble.invalid" }), $e = (e) => structuredClone({
	parts: e.parts,
	balls: e.balls,
	start: e.start
});
function et(e) {
	e.history.push($e(e)), e.history.length > 100 && e.history.shift();
}
function tt(e) {
	e.phase = "build", e.machine = null, e.checkMachine = null, e.failure = null, e.checkIndex = 0, e.counterexample = null, e.nim = {
		turn: "human",
		taken: 0
	};
}
function nt(e, t, n) {
	let r = fe(e, t), i = r.filter((e) => e.fixed && e.kind === "gearbit" && !n.includes(e.id));
	if (i.some((e) => e.right !== i[0].right)) return !1;
	let a = i[0] ?? r.find((e) => e.id !== t && e.kind === "gearbit") ?? r.find((e) => e.id !== t) ?? r[0];
	for (let e of r) e.right = a.right;
	return !0;
}
function rt(e, t, n = !1) {
	let r = ue[t - 1];
	e.challenge = t;
	let i = !n && e.saved[t];
	Object.assign(e, i ? structuredClone(i) : {
		parts: structuredClone(r.parts),
		balls: [...r.balls],
		start: r.start
	}), e.history = [], tt(e);
}
function it(e) {
	let t = ue[e.challenge - 1];
	if (e.machine) {
		if (t.n === 59) {
			if (e.machine.failure) {
				e.phase = "failed", e.failure = e.machine.failure;
				return;
			}
			e.machine.remaining[0] === 0 ? (e.phase = e.nim.turn === "machine" ? "passed" : "failed", e.phase === "failed" && (e.failure = "nim")) : (e.phase = "paused", e.nim.turn === "machine" && (e.nim = {
				turn: "human",
				taken: 0
			}));
			return;
		}
		if (!Qe(t, e.parts, e.balls, e.start, e.machine)) {
			e.failure = e.machine.failure ?? "goal", e.phase = "failed";
			return;
		}
		if (Ze(t).length <= 1) {
			e.phase = "passed";
			return;
		}
		e.phase = "checking", e.checkIndex = 0, e.checkMachine = null;
	}
}
function at(e) {
	let t = ue[e.challenge - 1];
	if (e.phase === "checking" || e.phase === "paused" && e.pausedFrom === "checking") {
		let n = Ze(t), r = n[e.checkIndex];
		if (!r) {
			e.phase = "passed";
			return;
		}
		e.checkMachine ||= (e.checkParts = qe(e.parts, r), Re(e.checkParts, r.balls, r.balls[r.start === "blue" ? 0 : 1] ? r.start : void 0, t.reservoirs)), e.checkMachine = Be(e.checkMachine, e.checkParts, 2400, t.n === 32, !1, !1, Je(t, e.checkParts, r.balls, r.start)), (e.checkMachine.finished || e.checkMachine.waiting) && (Qe(t, e.checkParts, r.balls, r.start, e.checkMachine) ? (e.checkIndex++, e.checkMachine = null, e.checkIndex === n.length && (e.phase = "passed")) : (e.phase = "failed", e.failure = e.checkMachine.failure ?? "goal", e.machine = e.checkMachine, e.counterexample = r));
		return;
	}
	e.machine ||= Re(e.parts, e.balls, e.balls[e.start === "blue" ? 0 : 1] ? e.start : void 0, t.reservoirs), e.machine = Be(e.machine, e.parts, Math.max(1, Math.round(12 * e.speed)), t.n === 32 || t.n === 59 && e.nim.turn === "human", t.n === 59 && e.nim.turn === "machine", !0, Je(t, e.parts, e.balls, e.start)), (e.machine.finished || e.machine.waiting) && it(e);
}
var ot = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: pe,
	schemas: {
		action: Y,
		publicView: Ge,
		privateView: Ke
	},
	setup(e, t) {
		let n = {
			host: t[0],
			challenge: 1,
			parts: [],
			balls: [8, 0],
			start: "blue",
			phase: "build",
			speed: 1,
			history: [],
			saved: {},
			serial: 0,
			revision: 0,
			machine: null,
			checkMachine: null,
			checkParts: [],
			checkIndex: 0,
			pausedFrom: "running",
			failure: null,
			counterexample: null,
			nim: {
				turn: "human",
				taken: 0
			}
		};
		return rt(n, 1), { state: n };
	},
	reduce(e, t, n) {
		if (t.type === "tick" ? n.by !== "$engine" : n.by !== e.host) return X();
		let r = structuredClone(e), i = ue[r.challenge - 1], a = "id" in t ? r.parts.find((e) => e.id === t.id) : void 0, o = (e, t, n) => Ce(e, t, n) && !r.parts.some((n) => n.row === e && n.col === t);
		switch (t.type) {
			case "tick":
				if (r.phase !== "running" && r.phase !== "checking") return { state: e };
				at(r);
				break;
			case "goto":
				r.saved[r.challenge] = $e(r), rt(r, t.n);
				break;
			case "reset":
				rt(r, r.challenge, !0);
				break;
			case "edit":
				tt(r);
				break;
			case "speed":
				r.speed = t.value;
				break;
			case "pause":
				if (r.phase !== "running" && r.phase !== "checking") return X();
				r.pausedFrom = r.phase, r.phase = "paused";
				break;
			case "run":
				if (i.n === 59 && !(r.phase === "paused" && r.machine?.ballHandles.length)) return X();
				if (r.phase === "paused") r.phase = r.pausedFrom;
				else if (r.phase === "build") r.phase = "running", r.machine = Re(r.parts, r.balls, r.balls[r.start === "blue" ? 0 : 1] ? r.start : void 0, i.reservoirs);
				else return X();
				break;
			case "release":
				if (i.n !== 59 || r.nim.turn !== "human" || r.nim.taken >= 3 || r.machine?.ballHandles.length || r.phase === "passed" || r.phase === "failed" || (r.machine ||= Re(r.parts, r.balls), !r.machine.remaining[0])) return X();
				r.machine = ze(r.machine, "blue"), r.nim.taken++, r.phase = "running";
				break;
			case "end-turn":
				if (i.n !== 59 || !r.machine || r.machine.ballHandles.length || r.nim.turn !== "human" || !r.nim.taken || !r.machine.remaining[0]) return X();
				r.machine = ze(He(r.machine, r.parts, !1), "blue"), r.nim = {
					turn: "machine",
					taken: 0
				}, r.phase = "running";
				break;
			default:
				if (r.phase !== "build") return X();
				switch (t.type) {
					case "undo": {
						let e = r.history.pop();
						e && Object.assign(r, e);
						break;
					}
					case "input":
						if (![
							21,
							22,
							30,
							31,
							40,
							53
						].includes(i.n) && t.blue !== r.balls[0] || t.blue > ([21, 22].includes(i.n) ? 15 : [31, 40].includes(i.n) ? 7 : 20) || i.n !== 32 && t.start !== i.start) return X();
						et(r), r.balls[0] = t.blue, r.start = t.start;
						break;
					case "place": {
						if (!o(t.row, t.col, t.kind) || i.stock[t.kind] < 60 && r.parts.filter((e) => !e.fixed && e.kind === t.kind).length >= i.stock[t.kind]) return X();
						et(r);
						let e = {
							id: `u${++r.serial}`,
							kind: t.kind,
							row: t.row,
							col: t.col,
							right: t.right,
							fixed: !1
						};
						if (r.parts.push(e), !nt(r.parts, e.id, [...i.variables, ...i.adjustable ?? []])) return X();
						break;
					}
					case "move":
						if (!a || a.fixed || !o(t.row, t.col, a.kind) || (et(r), a.row = t.row, a.col = t.col, !nt(r.parts, a.id, [...i.variables, ...i.adjustable ?? []]))) return X();
						break;
					case "flip": {
						if (!a || ["crossover", "interceptor"].includes(a.kind) || a.fixed && !i.variables.includes(a.id) && !i.adjustable?.includes(a.id)) return X();
						let e = fe(r.parts, a.id);
						if (e.some((e) => e.fixed && !i.variables.includes(e.id) && !i.adjustable?.includes(e.id) && e.kind === "gearbit")) return X();
						et(r);
						let t = !a.right;
						for (let n of e) n.right = t;
						break;
					}
					case "remove":
						if (!a || a.fixed) return X();
						et(r), r.parts = r.parts.filter((e) => e.id !== a.id);
				}
		}
		return r.revision++, { state: r };
	},
	viewFor(e) {
		let t = e.machine, n = e.counterexample ? {
			parts: e.checkParts,
			balls: e.counterexample.balls,
			start: e.counterexample.start
		} : e;
		return { public: {
			challenge: e.challenge,
			parts: n.parts,
			phase: e.phase,
			balls: n.balls,
			start: n.start,
			speed: e.speed,
			remaining: t?.remaining ?? e.balls,
			output: t?.output ?? [],
			caught: t?.caught ?? [],
			pose: t?.pose ?? null,
			frames: t?.frames ?? [],
			revision: e.revision,
			canUndo: e.history.length > 0,
			check: {
				done: e.checkIndex,
				total: Ze(ue[e.challenge - 1]).length
			},
			failure: e.failure,
			nim: e.nim
		} };
	},
	status: () => ({ phase: "play" }),
	nextTickIn: (e) => e.phase === "running" || e.phase === "checking" ? 100 : null
}, st = L, ct = class e extends N {
	constructor(e) {
		super(e), this.defaultDPI = 90, this.defaultUnit = "px";
	}
	load(e, t, n, r) {
		let i = this, a = new j(i.manager);
		a.setPath(i.path), a.setRequestHeader(i.requestHeader), a.setWithCredentials(i.withCredentials), a.load(e, function(n) {
			try {
				t(i.parse(n));
			} catch (t) {
				r ? r(t) : console.error(t), i.manager.itemError(e);
			}
		}, n, r);
	}
	parse(e) {
		let t = this;
		function n(e, t) {
			if (e.nodeType !== 1) return;
			e.hasAttribute("filter") && console.warn("THREE.SVGLoader: Filters are not supported.");
			let a = b(e), o = !1, p = null;
			switch (e.nodeName) {
				case "svg":
					t = m(e, t);
					break;
				case "style":
					i(e);
					break;
				case "g":
					t = m(e, t);
					break;
				case "path":
					t = m(e, t), e.hasAttribute("d") && (p = r(e));
					break;
				case "rect":
					t = m(e, t), p = s(e);
					break;
				case "polygon":
					t = m(e, t), p = c(e);
					break;
				case "polyline":
					t = m(e, t), p = l(e);
					break;
				case "circle":
					t = m(e, t), p = u(e);
					break;
				case "ellipse":
					t = m(e, t), p = d(e);
					break;
				case "line":
					t = m(e, t), p = f(e);
					break;
				case "defs":
					o = !0;
					break;
				case "use":
					t = m(e, t);
					let a = (e.getAttributeNS("http://www.w3.org/1999/xlink", "href") || "").substring(1), h = e.viewportElement.getElementById(a);
					h ? n(h, t) : console.warn("SVGLoader: 'use node' references non-existent node id: " + a);
			}
			if (p) {
				t.fill !== void 0 && t.fill !== "none" && !t.fill.startsWith("url") && p.color.setStyle(t.fill, st), C(p, L), te.push(p);
				let n = Object.assign({}, t);
				n.strokeWidth = t.strokeWidth * D(L), p.userData = {
					node: e,
					style: n,
					transform: L.clone(),
					gradients: k
				};
			}
			let h = e.childNodes;
			for (let e = 0; e < h.length; e++) {
				let r = h[e];
				o && r.nodeName !== "style" && r.nodeName !== "defs" || n(r, t);
			}
			a && (A.pop(), A.length > 0 ? L.copy(A[A.length - 1]) : L.identity());
		}
		function r(e) {
			let t = new ae(), n = new R(), r = new R(), i = new R(), o = !0, s = !1, c = e.getAttribute("d");
			if (c === "" || c === "none") return null;
			let l = c.match(/[a-df-z][^a-df-z]*/gi);
			for (let e = 0, c = l.length; e < c; e++) {
				let c = l[e], u = c.charAt(0), d = c.slice(1).trim();
				o === !0 && (s = !0, o = !1);
				let f;
				switch (u) {
					case "M":
						f = g(d);
						for (let e = 0, a = f.length; e < a; e += 2) n.x = f[e + 0], n.y = f[e + 1], r.x = n.x, r.y = n.y, e === 0 ? t.moveTo(n.x, n.y) : t.lineTo(n.x, n.y), e === 0 && i.copy(n);
						break;
					case "H":
						f = g(d);
						for (let e = 0, a = f.length; e < a; e++) n.x = f[e], r.x = n.x, r.y = n.y, t.lineTo(n.x, n.y), e === 0 && s === !0 && i.copy(n);
						break;
					case "V":
						f = g(d);
						for (let e = 0, a = f.length; e < a; e++) n.y = f[e], r.x = n.x, r.y = n.y, t.lineTo(n.x, n.y), e === 0 && s === !0 && i.copy(n);
						break;
					case "L":
						f = g(d);
						for (let e = 0, a = f.length; e < a; e += 2) n.x = f[e + 0], n.y = f[e + 1], r.x = n.x, r.y = n.y, t.lineTo(n.x, n.y), e === 0 && s === !0 && i.copy(n);
						break;
					case "C":
						f = g(d);
						for (let e = 0, a = f.length; e < a; e += 6) t.bezierCurveTo(f[e + 0], f[e + 1], f[e + 2], f[e + 3], f[e + 4], f[e + 5]), r.x = f[e + 2], r.y = f[e + 3], n.x = f[e + 4], n.y = f[e + 5], e === 0 && s === !0 && i.copy(n);
						break;
					case "S":
						f = g(d);
						for (let e = 0, a = f.length; e < a; e += 4) t.bezierCurveTo(h(n.x, r.x), h(n.y, r.y), f[e + 0], f[e + 1], f[e + 2], f[e + 3]), r.x = f[e + 0], r.y = f[e + 1], n.x = f[e + 2], n.y = f[e + 3], e === 0 && s === !0 && i.copy(n);
						break;
					case "Q":
						f = g(d);
						for (let e = 0, a = f.length; e < a; e += 4) t.quadraticCurveTo(f[e + 0], f[e + 1], f[e + 2], f[e + 3]), r.x = f[e + 0], r.y = f[e + 1], n.x = f[e + 2], n.y = f[e + 3], e === 0 && s === !0 && i.copy(n);
						break;
					case "T":
						f = g(d);
						for (let e = 0, a = f.length; e < a; e += 2) {
							let a = h(n.x, r.x), o = h(n.y, r.y);
							t.quadraticCurveTo(a, o, f[e + 0], f[e + 1]), r.x = a, r.y = o, n.x = f[e + 0], n.y = f[e + 1], e === 0 && s === !0 && i.copy(n);
						}
						break;
					case "A":
						f = g(d, [3, 4], 7);
						for (let e = 0, o = f.length; e < o; e += 7) {
							if (f[e + 5] == n.x && f[e + 6] == n.y) continue;
							let o = n.clone();
							n.x = f[e + 5], n.y = f[e + 6], r.x = n.x, r.y = n.y, a(t, f[e], f[e + 1], f[e + 2], f[e + 3], f[e + 4], o, n), e === 0 && s === !0 && i.copy(n);
						}
						break;
					case "m":
						f = g(d);
						for (let e = 0, a = f.length; e < a; e += 2) n.x += f[e + 0], n.y += f[e + 1], r.x = n.x, r.y = n.y, e === 0 ? t.moveTo(n.x, n.y) : t.lineTo(n.x, n.y), e === 0 && i.copy(n);
						break;
					case "h":
						f = g(d);
						for (let e = 0, a = f.length; e < a; e++) n.x += f[e], r.x = n.x, r.y = n.y, t.lineTo(n.x, n.y), e === 0 && s === !0 && i.copy(n);
						break;
					case "v":
						f = g(d);
						for (let e = 0, a = f.length; e < a; e++) n.y += f[e], r.x = n.x, r.y = n.y, t.lineTo(n.x, n.y), e === 0 && s === !0 && i.copy(n);
						break;
					case "l":
						f = g(d);
						for (let e = 0, a = f.length; e < a; e += 2) n.x += f[e + 0], n.y += f[e + 1], r.x = n.x, r.y = n.y, t.lineTo(n.x, n.y), e === 0 && s === !0 && i.copy(n);
						break;
					case "c":
						f = g(d);
						for (let e = 0, a = f.length; e < a; e += 6) t.bezierCurveTo(n.x + f[e + 0], n.y + f[e + 1], n.x + f[e + 2], n.y + f[e + 3], n.x + f[e + 4], n.y + f[e + 5]), r.x = n.x + f[e + 2], r.y = n.y + f[e + 3], n.x += f[e + 4], n.y += f[e + 5], e === 0 && s === !0 && i.copy(n);
						break;
					case "s":
						f = g(d);
						for (let e = 0, a = f.length; e < a; e += 4) t.bezierCurveTo(h(n.x, r.x), h(n.y, r.y), n.x + f[e + 0], n.y + f[e + 1], n.x + f[e + 2], n.y + f[e + 3]), r.x = n.x + f[e + 0], r.y = n.y + f[e + 1], n.x += f[e + 2], n.y += f[e + 3], e === 0 && s === !0 && i.copy(n);
						break;
					case "q":
						f = g(d);
						for (let e = 0, a = f.length; e < a; e += 4) t.quadraticCurveTo(n.x + f[e + 0], n.y + f[e + 1], n.x + f[e + 2], n.y + f[e + 3]), r.x = n.x + f[e + 0], r.y = n.y + f[e + 1], n.x += f[e + 2], n.y += f[e + 3], e === 0 && s === !0 && i.copy(n);
						break;
					case "t":
						f = g(d);
						for (let e = 0, a = f.length; e < a; e += 2) {
							let a = h(n.x, r.x), o = h(n.y, r.y);
							t.quadraticCurveTo(a, o, n.x + f[e + 0], n.y + f[e + 1]), r.x = a, r.y = o, n.x += f[e + 0], n.y += f[e + 1], e === 0 && s === !0 && i.copy(n);
						}
						break;
					case "a":
						f = g(d, [3, 4], 7);
						for (let e = 0, o = f.length; e < o; e += 7) {
							if (f[e + 5] == 0 && f[e + 6] == 0) continue;
							let o = n.clone();
							n.x += f[e + 5], n.y += f[e + 6], r.x = n.x, r.y = n.y, a(t, f[e], f[e + 1], f[e + 2], f[e + 3], f[e + 4], o, n), e === 0 && s === !0 && i.copy(n);
						}
						break;
					case "Z":
					case "z":
						t.currentPath.autoClose = !0, t.currentPath.curves.length > 0 && (n.copy(i), t.currentPath.currentPoint.copy(n), o = !0);
						break;
					default: console.warn(c);
				}
				s = !1;
			}
			return t;
		}
		function i(e) {
			if (e.sheet && e.sheet.cssRules && e.sheet.cssRules.length) for (let t = 0; t < e.sheet.cssRules.length; t++) {
				let n = e.sheet.cssRules[t];
				if (n.type !== 1) continue;
				let r = n.selectorText.split(/,/gm).filter(Boolean).map((e) => e.trim());
				for (let e = 0; e < r.length; e++) {
					let t = Object.fromEntries(Object.entries(n.style).filter(([, e]) => e !== ""));
					ne[r[e]] = Object.assign(ne[r[e]] || {}, t);
				}
			}
		}
		function a(e, t, n, r, i, a, s, c) {
			if (t == 0 || n == 0) {
				e.lineTo(c.x, c.y);
				return;
			}
			r = r * Math.PI / 180, t = Math.abs(t), n = Math.abs(n);
			let l = (s.x - c.x) / 2, u = (s.y - c.y) / 2, d = Math.cos(r) * l + Math.sin(r) * u, f = -Math.sin(r) * l + Math.cos(r) * u, p = t * t, m = n * n, h = d * d, g = f * f, _ = h / p + g / m;
			if (_ > 1) {
				let e = Math.sqrt(_);
				t = e * t, n = e * n, p = t * t, m = n * n;
			}
			let v = p * g + m * h, y = (p * m - v) / v, b = Math.sqrt(Math.max(0, y));
			i === a && (b = -b);
			let x = b * t * f / n, S = -b * n * d / t, C = Math.cos(r) * x - Math.sin(r) * S + (s.x + c.x) / 2, w = Math.sin(r) * x + Math.cos(r) * S + (s.y + c.y) / 2, ee = o(1, 0, (d - x) / t, (f - S) / n), T = o((d - x) / t, (f - S) / n, (-d - x) / t, (-f - S) / n) % (Math.PI * 2);
			e.currentPath.absellipse(C, w, t, n, ee, ee + T, a === 0, r);
		}
		function o(e, t, n, r) {
			let i = e * n + t * r, a = Math.sqrt(e * e + t * t) * Math.sqrt(n * n + r * r), o = Math.acos(Math.max(-1, Math.min(1, i / a)));
			return e * r - t * n < 0 && (o = -o), o;
		}
		function s(e) {
			let t = y(e.getAttribute("x") || 0), n = y(e.getAttribute("y") || 0), r = y(e.getAttribute("rx") || e.getAttribute("ry") || 0), i = y(e.getAttribute("ry") || e.getAttribute("rx") || 0), a = y(e.getAttribute("width")), o = y(e.getAttribute("height")), s = .448084975506, c = new ae();
			return c.moveTo(t + r, n), c.lineTo(t + a - r, n), (r !== 0 || i !== 0) && c.bezierCurveTo(t + a - r * s, n, t + a, n + i * s, t + a, n + i), c.lineTo(t + a, n + o - i), (r !== 0 || i !== 0) && c.bezierCurveTo(t + a, n + o - i * s, t + a - r * s, n + o, t + a - r, n + o), c.lineTo(t + r, n + o), (r !== 0 || i !== 0) && c.bezierCurveTo(t + r * s, n + o, t, n + o - i * s, t, n + o - i), c.lineTo(t, n + i), (r !== 0 || i !== 0) && c.bezierCurveTo(t, n + i * s, t + r * s, n, t + r, n), c;
		}
		function c(e) {
			function t(e, t, n) {
				let a = y(t), o = y(n);
				i === 0 ? r.moveTo(a, o) : r.lineTo(a, o), i++;
			}
			let n = /([+-]?\d*\.?\d+(?:e[+-]?\d+)?)(?:,|\s)([+-]?\d*\.?\d+(?:e[+-]?\d+)?)/g, r = new ae(), i = 0;
			return e.getAttribute("points").replace(n, t), r.currentPath.autoClose = !0, r;
		}
		function l(e) {
			function t(e, t, n) {
				let a = y(t), o = y(n);
				i === 0 ? r.moveTo(a, o) : r.lineTo(a, o), i++;
			}
			let n = /([+-]?\d*\.?\d+(?:e[+-]?\d+)?)(?:,|\s)([+-]?\d*\.?\d+(?:e[+-]?\d+)?)/g, r = new ae(), i = 0;
			return e.getAttribute("points").replace(n, t), r.currentPath.autoClose = !1, r;
		}
		function u(e) {
			let t = y(e.getAttribute("cx") || 0), n = y(e.getAttribute("cy") || 0), r = y(e.getAttribute("r") || 0), i = new re();
			i.absarc(t, n, r, 0, Math.PI * 2);
			let a = new ae();
			return a.subPaths.push(i), a;
		}
		function d(e) {
			let t = y(e.getAttribute("cx") || 0), n = y(e.getAttribute("cy") || 0), r = y(e.getAttribute("rx") || 0), i = y(e.getAttribute("ry") || 0), a = new re();
			a.absellipse(t, n, r, i, 0, Math.PI * 2);
			let o = new ae();
			return o.subPaths.push(a), o;
		}
		function f(e) {
			let t = y(e.getAttribute("x1") || 0), n = y(e.getAttribute("y1") || 0), r = y(e.getAttribute("x2") || 0), i = y(e.getAttribute("y2") || 0), a = new ae();
			return a.moveTo(t, n), a.lineTo(r, i), a.currentPath.autoClose = !1, a;
		}
		function p(e) {
			let t = e.querySelectorAll("linearGradient, radialGradient"), n = [
				"x1",
				"y1",
				"x2",
				"y2",
				"cx",
				"cy",
				"r",
				"fx",
				"fy",
				"gradientUnits",
				"gradientTransform",
				"spreadMethod"
			], r = {};
			for (let e of t) {
				let t = e.getAttribute("id");
				if (!t) continue;
				let i = {
					type: e.nodeName === "radialGradient" ? "radialGradient" : "linearGradient",
					attrs: {},
					stops: null,
					href: null
				}, a = e.getAttributeNS("http://www.w3.org/1999/xlink", "href") || e.getAttribute("href") || "";
				a.startsWith("#") && (i.href = a.substring(1));
				for (let t of n) e.hasAttribute(t) && (i.attrs[t] = e.getAttribute(t));
				let o = e.querySelectorAll("stop");
				if (o.length > 0) {
					i.stops = [];
					for (let e of o) {
						let t = e.getAttribute("stop-color");
						!t && e.style && (t = e.style["stop-color"]), t ||= "#000";
						let n = e.getAttribute("stop-opacity");
						(n === null || n === "") && e.style && (n = e.style["stop-opacity"]), n = n === null || n === "" || n === void 0 ? 1 : Math.max(0, Math.min(1, parseFloat(n)));
						let r = Math.max(0, Math.min(1, parseFloat(e.getAttribute("offset") || "0")));
						i.stops.push({
							offset: r,
							color: t,
							opacity: n
						});
					}
				}
				r[t] = i;
			}
			function i(e, t) {
				let n = r[e];
				if (!n || t.has(e)) return n;
				if (t.add(e), n.href && r[n.href]) {
					let e = i(n.href, t);
					if (e) {
						n.stops ||= e.stops;
						for (let t in e.attrs) t in n.attrs || (n.attrs[t] = e.attrs[t]);
					}
				}
				return n;
			}
			for (let e in r) i(e, /* @__PURE__ */ new Set());
			for (let e in r) {
				let t = r[e], n = t.attrs, i = n.gradientUnits === "userSpaceOnUse" ? "userSpaceOnUse" : "objectBoundingBox", a = {
					type: t.type,
					gradientUnits: i,
					spreadMethod: n.spreadMethod === "reflect" || n.spreadMethod === "repeat" ? n.spreadMethod : "pad",
					gradientTransform: null,
					stops: (t.stops || []).slice().sort((e, t) => e.offset - t.offset)
				};
				n.gradientTransform && (a.gradientTransform = new P(), S(n.gradientTransform, a.gradientTransform));
				function o(e) {
					return typeof e == "string" ? e.endsWith("%") ? parseFloat(e) / 100 : y(e) : 0;
				}
				if (t.type === "linearGradient") a.x1 = n.x1 === void 0 ? 0 : o(n.x1), a.y1 = n.y1 === void 0 ? 0 : o(n.y1), a.x2 = n.x2 === void 0 ? +(i === "objectBoundingBox") : o(n.x2), a.y2 = n.y2 === void 0 ? 0 : o(n.y2);
				else {
					let e = i === "objectBoundingBox" ? .5 : 0, t = i === "objectBoundingBox" ? .5 : 0;
					a.cx = n.cx === void 0 ? e : o(n.cx), a.cy = n.cy === void 0 ? e : o(n.cy), a.r = n.r === void 0 ? t : o(n.r), a.fx = n.fx === void 0 ? a.cx : o(n.fx), a.fy = n.fy === void 0 ? a.cy : o(n.fy);
				}
				k[e] = a;
			}
		}
		function m(e, t) {
			t = Object.assign({}, t);
			let n = {};
			if (e.hasAttribute("class")) {
				let t = e.getAttribute("class").split(/\s/).filter(Boolean).map((e) => e.trim());
				for (let e = 0; e < t.length; e++) n = Object.assign(n, ne["." + t[e]]);
			}
			e.hasAttribute("id") && (n = Object.assign(n, ne["#" + e.getAttribute("id")]));
			function r(r, i, a) {
				a === void 0 && (a = function(e) {
					return e;
				}), e.hasAttribute(r) && (t[i] = a(e.getAttribute(r))), n[i] && (t[i] = a(n[i])), e.style && e.style[r] !== "" && (t[i] = a(e.style[r]));
			}
			function i(e) {
				return Math.max(0, Math.min(1, y(e)));
			}
			function a(e) {
				return Math.max(0, y(e));
			}
			return r("fill", "fill"), r("fill-opacity", "fillOpacity", i), r("fill-rule", "fillRule"), r("opacity", "opacity", i), r("stroke", "stroke"), r("stroke-opacity", "strokeOpacity", i), r("stroke-width", "strokeWidth", a), r("stroke-linejoin", "strokeLineJoin"), r("stroke-linecap", "strokeLineCap"), r("stroke-miterlimit", "strokeMiterLimit", a), r("visibility", "visibility"), t;
		}
		function h(e, t) {
			return e - (t - e);
		}
		function g(e, t, n) {
			if (typeof e != "string") throw TypeError("Invalid input: " + typeof e);
			let r = {
				SEPARATOR: /[ \t\r\n\,.\-+]/,
				WHITESPACE: /[ \t\r\n]/,
				DIGIT: /[\d]/,
				SIGN: /[-+]/,
				POINT: /\./,
				COMMA: /,/,
				EXP: /e/i,
				FLAGS: /[01]/
			}, i = 0, a = !0, o = "", s = "", c = [];
			function l(e, t, n) {
				let r = /* @__PURE__ */ SyntaxError("Unexpected character \"" + e + "\" at index " + t + ".");
				throw r.partial = n, r;
			}
			function u() {
				o !== "" && (s === "" ? c.push(Number(o)) : c.push(Number(o) * 10 ** Number(s))), o = "", s = "";
			}
			let d, f = e.length;
			for (let p = 0; p < f; p++) {
				if (d = e[p], Array.isArray(t) && t.includes(c.length % n) && r.FLAGS.test(d)) {
					i = 1, o = d, u();
					continue;
				}
				if (i === 0) {
					if (r.WHITESPACE.test(d)) continue;
					if (r.DIGIT.test(d) || r.SIGN.test(d)) {
						i = 1, o = d;
						continue;
					}
					if (r.POINT.test(d)) {
						i = 2, o = d;
						continue;
					}
					r.COMMA.test(d) && (a && l(d, p, c), a = !0);
				}
				if (i === 1) {
					if (r.DIGIT.test(d)) {
						o += d;
						continue;
					}
					if (r.POINT.test(d)) {
						o += d, i = 2;
						continue;
					}
					if (r.EXP.test(d)) {
						i = 3;
						continue;
					}
					r.SIGN.test(d) && o.length === 1 && r.SIGN.test(o[0]) && l(d, p, c);
				}
				if (i === 2) {
					if (r.DIGIT.test(d)) {
						o += d;
						continue;
					}
					if (r.EXP.test(d)) {
						i = 3;
						continue;
					}
					r.POINT.test(d) && o[o.length - 1] === "." && l(d, p, c);
				}
				if (i === 3) {
					if (r.DIGIT.test(d)) {
						s += d;
						continue;
					}
					if (r.SIGN.test(d)) {
						if (s === "") {
							s += d;
							continue;
						}
						s.length === 1 && r.SIGN.test(s) && l(d, p, c);
					}
				}
				r.WHITESPACE.test(d) ? (u(), i = 0, a = !1) : r.COMMA.test(d) ? (u(), i = 0, a = !0) : r.SIGN.test(d) ? (u(), i = 1, o = d) : r.POINT.test(d) ? (u(), i = 2, o = d) : l(d, p, c);
			}
			return u(), c;
		}
		let _ = [
			"mm",
			"cm",
			"in",
			"pt",
			"pc",
			"px"
		], v = {
			mm: {
				mm: 1,
				cm: .1,
				in: 1 / 25.4,
				pt: 72 / 25.4,
				pc: 6 / 25.4,
				px: -1
			},
			cm: {
				mm: 10,
				cm: 1,
				in: 1 / 2.54,
				pt: 72 / 2.54,
				pc: 6 / 2.54,
				px: -1
			},
			in: {
				mm: 25.4,
				cm: 2.54,
				in: 1,
				pt: 72,
				pc: 6,
				px: -1
			},
			pt: {
				mm: 25.4 / 72,
				cm: 2.54 / 72,
				in: 1 / 72,
				pt: 1,
				pc: 6 / 72,
				px: -1
			},
			pc: {
				mm: 25.4 / 6,
				cm: 2.54 / 6,
				in: 1 / 6,
				pt: 12,
				pc: 1,
				px: -1
			},
			px: { px: 1 }
		};
		function y(e) {
			let n = "px";
			if (typeof e == "string" || e instanceof String) for (let t = 0, r = _.length; t < r; t++) {
				let r = _[t];
				if (e.endsWith(r)) {
					n = r, e = e.substring(0, e.length - r.length);
					break;
				}
			}
			let r;
			return n === "px" && t.defaultUnit !== "px" ? r = v.in[t.defaultUnit] / t.defaultDPI : (r = v[n][t.defaultUnit], r < 0 && (r = v[n].in * t.defaultDPI)), r * parseFloat(e);
		}
		function b(e) {
			if (!(e.hasAttribute("transform") || e.nodeName === "use" && (e.hasAttribute("x") || e.hasAttribute("y")))) return null;
			let t = x(e);
			return A.length > 0 && t.premultiply(A[A.length - 1]), L.copy(t), A.push(t), t;
		}
		function x(e) {
			let t = new P();
			if (e.nodeName === "use" && (e.hasAttribute("x") || e.hasAttribute("y"))) {
				let n = y(e.getAttribute("x") || 0), r = y(e.getAttribute("y") || 0);
				t.makeTranslation(n, r);
			}
			return e.hasAttribute("transform") && S(e.getAttribute("transform"), t), t;
		}
		function S(e, t) {
			let n = j, r = e.split(")");
			for (let e = r.length - 1; e >= 0; e--) {
				let i = r[e].trim();
				if (i === "") continue;
				let a = i.indexOf("("), o = i.length;
				if (a > 0 && a < o) {
					let e = i.slice(0, a), r = g(i.slice(a + 1));
					switch (n.identity(), e) {
						case "translate":
							if (r.length >= 1) {
								let e = r[0], t = 0;
								r.length >= 2 && (t = r[1]), n.makeTranslation(e, t);
							}
							break;
						case "rotate":
							if (r.length >= 1) {
								let e = 0, t = 0, i = 0;
								e = r[0] * Math.PI / 180, r.length >= 3 && (t = r[1], i = r[2]), M.makeTranslation(-t, -i), N.makeRotation(e), F.multiplyMatrices(N, M), M.makeTranslation(t, i), n.multiplyMatrices(M, F);
							}
							break;
						case "scale":
							if (r.length >= 1) {
								let e = r[0], t = e;
								r.length >= 2 && (t = r[1]), n.makeScale(e, t);
							}
							break;
						case "skewX":
							r.length === 1 && n.set(1, Math.tan(r[0] * Math.PI / 180), 0, 0, 1, 0, 0, 0, 1);
							break;
						case "skewY":
							r.length === 1 && n.set(1, 0, 0, Math.tan(r[0] * Math.PI / 180), 1, 0, 0, 0, 1);
							break;
						case "matrix": r.length === 6 && n.set(r[0], r[2], r[4], r[1], r[3], r[5], 0, 0, 1);
					}
					t.premultiply(n);
				}
			}
			return t;
		}
		function C(e, t) {
			function n(e) {
				ie.set(e.x, e.y, 1).applyMatrix3(t), e.set(ie.x, ie.y);
			}
			function r(e) {
				let n = e.xRadius, r = e.yRadius, i = Math.cos(e.aRotation), a = Math.sin(e.aRotation), o = new z(n * i, n * a, 0), s = new z(-r * a, r * i, 0), c = o.applyMatrix3(t), l = s.applyMatrix3(t), u = j.set(c.x, l.x, 0, c.y, l.y, 0, 0, 0, 1), d = M.copy(u).invert(), f = N.copy(d).transpose().multiply(d).elements, p = O(f[0], f[1], f[4]), m = Math.sqrt(p.rt1), h = Math.sqrt(p.rt2);
				if (e.xRadius = 1 / m, e.yRadius = 1 / h, e.aRotation = Math.atan2(p.sn, p.cs), !((e.aEndAngle - e.aStartAngle) % (2 * Math.PI) < 2 ** -52)) {
					let n = M.set(m, 0, 0, 0, h, 0, 0, 0, 1), r = N.set(p.cs, p.sn, 0, -p.sn, p.cs, 0, 0, 0, 1), i = n.multiply(r).multiply(u), a = (e) => {
						let { x: t, y: n } = new z(Math.cos(e), Math.sin(e), 0).applyMatrix3(i);
						return Math.atan2(n, t);
					};
					e.aStartAngle = a(e.aStartAngle), e.aEndAngle = a(e.aEndAngle), w(t) && (e.aClockwise = !e.aClockwise);
				}
			}
			function i(e) {
				let n = T(t), r = E(t);
				e.xRadius *= n, e.yRadius *= r;
				let i = n > 2 ** -52 ? Math.atan2(t.elements[1], t.elements[0]) : Math.atan2(-t.elements[3], t.elements[4]);
				e.aRotation += i, w(t) && (e.aStartAngle *= -1, e.aEndAngle *= -1, e.aClockwise = !e.aClockwise);
			}
			let a = e.subPaths;
			for (let e = 0, o = a.length; e < o; e++) {
				let o = a[e].curves;
				for (let e = 0; e < o.length; e++) {
					let a = o[e];
					a.isLineCurve ? (n(a.v1), n(a.v2)) : a.isCubicBezierCurve ? (n(a.v0), n(a.v1), n(a.v2), n(a.v3)) : a.isQuadraticBezierCurve ? (n(a.v0), n(a.v1), n(a.v2)) : a.isEllipseCurve && (I.set(a.aX, a.aY), n(I), a.aX = I.x, a.aY = I.y, ee(t) ? r(a) : i(a));
				}
			}
		}
		function w(e) {
			let t = e.elements;
			return t[0] * t[4] - t[1] * t[3] < 0;
		}
		function ee(e) {
			let t = e.elements, n = t[0] * t[3] + t[1] * t[4];
			if (n === 0) return !1;
			let r = T(e), i = E(e);
			return Math.abs(n / (r * i)) > 2 ** -52;
		}
		function T(e) {
			let t = e.elements;
			return Math.sqrt(t[0] * t[0] + t[1] * t[1]);
		}
		function E(e) {
			let t = e.elements;
			return Math.sqrt(t[3] * t[3] + t[4] * t[4]);
		}
		function D(e) {
			let t = e.elements, n = t[0] * t[4] - t[1] * t[3];
			return Math.sqrt(Math.abs(n));
		}
		function O(e, t, n) {
			let r, i, a, o, s, c = e + n, l = e - n, u = Math.sqrt(l * l + 4 * t * t);
			return c > 0 ? (r = .5 * (c + u), s = 1 / r, i = e * s * n - t * s * t) : c < 0 ? i = .5 * (c - u) : (r = .5 * u, i = -.5 * u), a = l > 0 ? l + u : l - u, Math.abs(a) > 2 * Math.abs(t) ? (s = -2 * t / a, o = 1 / Math.sqrt(1 + s * s), a = s * o) : Math.abs(t) === 0 ? (a = 1, o = 0) : (s = -.5 * a / t, a = 1 / Math.sqrt(1 + s * s), o = s * a), l > 0 && (s = a, a = -o, o = s), {
				rt1: r,
				rt2: i,
				cs: a,
				sn: o
			};
		}
		let te = [], ne = {}, k = {}, A = [], j = new P(), M = new P(), N = new P(), F = new P(), I = new R(), ie = new z(), L = new P(), oe = new DOMParser().parseFromString(e, "image/svg+xml");
		return p(oe), n(oe.documentElement, {
			fill: "#000",
			fillOpacity: 1,
			strokeOpacity: 1,
			strokeWidth: 1,
			strokeLineJoin: "miter",
			strokeLineCap: "butt",
			strokeMiterLimit: 4
		}), {
			paths: te,
			gradients: k,
			xml: oe.documentElement
		};
	}
	static createFillMaterial(e) {
		let t = e.userData.style;
		if (t.fill === void 0 || t.fill === "none") return null;
		let n = e.color, r = null, i = lt.exec(t.fill);
		i && (r = ut(e.userData.gradients && e.userData.gradients[i[1]], e));
		let a = new F({
			opacity: t.fillOpacity * (t.opacity || 1),
			transparent: !0,
			side: A,
			depthWrite: !1
		});
		return r === null ? a.color = n : a.map = r, a;
	}
	static createStrokeMaterial(e) {
		let t = e.userData.style;
		return t.stroke === void 0 || t.stroke === "none" ? null : (lt.test(t.stroke) && console.warn("THREE.SVGLoader: Gradient strokes are not supported."), new F({
			color: new k().setStyle(t.stroke, st),
			opacity: t.strokeOpacity * (t.opacity || 1),
			transparent: !0,
			side: A,
			depthWrite: !1
		}));
	}
	static createShapes(e) {
		return console.warn("SVGLoader: createShapes() is deprecated. Use shapePath.toShapes() instead."), e.toShapes();
	}
	static getStrokeStyle(e, t, n, r, i) {
		return e = e === void 0 ? 1 : e, t = t === void 0 ? "#000" : t, n = n === void 0 ? "miter" : n, r = r === void 0 ? "butt" : r, i = i === void 0 ? 4 : i, {
			strokeColor: t,
			strokeWidth: e,
			strokeLineJoin: n,
			strokeLineCap: r,
			strokeMiterLimit: i
		};
	}
	static pointsToStroke(t, n, r, i) {
		let a = [], o = [], s = [];
		if (e.pointsToStrokeWithBuffers(t, n, r, i, a, o, s) === 0) return null;
		let c = new O();
		return c.setAttribute("position", new M(a, 3)), c.setAttribute("normal", new M(o, 3)), c.setAttribute("uv", new M(s, 2)), c;
	}
	static pointsToStrokeWithBuffers(e, t, n, r, i, a, o, s) {
		let c = new R(), l = new R(), u = new R(), d = new R(), f = new R(), p = new R(), m = new R(), h = new R(), g = new R(), _ = new R(), v = new R(), y = new R(), b = new R(), x = new R(), S = new R(), C = new R(), w = new R();
		n = n === void 0 ? 12 : n, r = r === void 0 ? .001 : r, s = s === void 0 ? 0 : s, e = V(e);
		let ee = e.length;
		if (ee < 2) return 0;
		let T = e[0].equals(e[ee - 1]), E, D = e[0], O, te = t.strokeWidth / 2, ne = 1 / (ee - 1), k = 0, A, j, M, N, P = !1, F = 0, I = s * 3, re = s * 2;
		ie(e[0], e[1], c).multiplyScalar(te), h.copy(e[0]).sub(c), g.copy(e[0]).add(c), _.copy(h), v.copy(g);
		for (let n = 1; n < ee; n++) {
			E = e[n], O = n === ee - 1 ? T ? e[1] : void 0 : e[n + 1];
			let r = c;
			if (ie(D, E, r), u.copy(r).multiplyScalar(te), y.copy(E).sub(u), b.copy(E).add(u), A = k + ne, j = !1, O !== void 0) {
				ie(E, O, l), u.copy(l).multiplyScalar(te), x.copy(E).sub(u), S.copy(E).add(u), M = !0, u.subVectors(O, D), r.dot(u) < 0 && (M = !1), n === 1 && (P = M), u.subVectors(O, E), u.normalize();
				let e = Math.abs(r.dot(u));
				if (e > 2 ** -52) {
					let n = te / e;
					u.multiplyScalar(-n), d.subVectors(E, D), f.copy(d).setLength(n).add(u), C.copy(f).negate();
					let r = f.length(), i = d.length();
					d.divideScalar(i), p.subVectors(O, E);
					let a = p.length();
					if (p.divideScalar(a), d.dot(C) < i && p.dot(C) < a && (j = !0), w.copy(f).add(E), C.add(E), j) {
						let e = M ? g : h, t = (w.x - e.x) * (C.y - e.y) - (w.y - e.y) * (C.x - e.x);
						(M && t < 0 || !M && t > 0) && C.copy(e);
					}
					switch (N = !1, j ? M ? (S.copy(C), b.copy(C)) : (x.copy(C), y.copy(C)) : z(), t.strokeLineJoin) {
						case "bevel":
							se(M, j, A);
							break;
						case "round":
							ce(M, j), M ? ae(E, y, x, A, 0) : ae(E, S, b, A, 1);
							break;
						default:
							let e = te * t.strokeMiterLimit / r;
							if (e < 1) {
								if (t.strokeLineJoin !== "miter-clip") {
									se(M, j, A);
									break;
								}
								ce(M, j), M ? (p.subVectors(w, y).multiplyScalar(e).add(y), m.subVectors(w, x).multiplyScalar(e).add(x), L(y, A, 0), L(p, A, 0), L(E, A, .5), L(E, A, .5), L(p, A, 0), L(m, A, 0), L(E, A, .5), L(m, A, 0), L(x, A, 0)) : (p.subVectors(w, b).multiplyScalar(e).add(b), m.subVectors(w, S).multiplyScalar(e).add(S), L(b, A, 1), L(p, A, 1), L(E, A, .5), L(E, A, .5), L(p, A, 1), L(m, A, 1), L(E, A, .5), L(m, A, 1), L(S, A, 1));
							} else j ? (M ? (L(g, k, 1), L(h, k, 0), L(w, A, 0), L(g, k, 1), L(w, A, 0), L(C, A, 1)) : (L(g, k, 1), L(h, k, 0), L(w, A, 1), L(h, k, 0), L(C, A, 0), L(w, A, 1)), M ? x.copy(w) : S.copy(w)) : M ? (L(y, A, 0), L(w, A, 0), L(E, A, .5), L(E, A, .5), L(w, A, 0), L(x, A, 0)) : (L(b, A, 1), L(w, A, 1), L(E, A, .5), L(E, A, .5), L(w, A, 1), L(S, A, 1)), N = !0;
					}
				} else z();
			} else z();
			!T && n === ee - 1 && B(e[0], _, v, M, !0, k), k = A, D = E, h.copy(x), g.copy(S);
		}
		if (!T) B(E, y, b, M, !1, A);
		else if (j && i) {
			let e = w, t = C;
			P !== M && (e = C, t = w), M ? (N || P) && (t.toArray(i, 0), t.toArray(i, 9), N && e.toArray(i, 3)) : (N || !P) && (t.toArray(i, 3), t.toArray(i, 9), N && e.toArray(i, 0));
		}
		if (i) {
			let e = [
				new R(),
				new R(),
				new R()
			], t = s * 3;
			for (let n = t; n < I; n += 9) e[0].set(i[n], i[n + 1]), e[1].set(i[n + 3], i[n + 4]), e[2].set(i[n + 6], i[n + 7]), oe.area(e) < 0 && (i[n + 3] = e[0].x, i[n + 4] = e[0].y);
		}
		return F;
		function ie(e, t, n) {
			return n.subVectors(t, e), n.set(-n.y, n.x).normalize();
		}
		function L(e, t, n) {
			i && (i[I] = e.x, i[I + 1] = e.y, i[I + 2] = 0, a && (a[I] = 0, a[I + 1] = 0, a[I + 2] = 1), I += 3, o && (o[re] = t, o[re + 1] = n, re += 2)), F += 3;
		}
		function ae(e, t, r, i, a) {
			c.copy(t).sub(e).normalize(), l.copy(r).sub(e).normalize();
			let o = Math.PI, s = c.dot(l);
			Math.abs(s) < 1 && (o = Math.abs(Math.acos(s))), o /= n, u.copy(t);
			for (let t = 0, r = n - 1; t < r; t++) d.copy(u).rotateAround(e, o), L(u, i, a), L(d, i, a), L(e, i, .5), u.copy(d);
			L(u, i, a), L(r, i, a), L(e, i, .5);
		}
		function z() {
			L(g, k, 1), L(h, k, 0), L(y, A, 0), L(g, k, 1), L(y, A, 0), L(b, A, 1);
		}
		function se(e, t, n) {
			t ? e ? (L(g, k, 1), L(h, k, 0), L(y, A, 0), L(g, k, 1), L(y, A, 0), L(C, A, 1), L(y, n, 0), L(x, n, 0), L(C, n, .5)) : (L(g, k, 1), L(h, k, 0), L(b, A, 1), L(h, k, 0), L(C, A, 0), L(b, A, 1), L(b, n, 1), L(C, n, 0), L(S, n, 1)) : e ? (L(y, n, 0), L(x, n, 0), L(E, n, .5)) : (L(b, n, 1), L(S, n, 0), L(E, n, .5));
		}
		function ce(e, t) {
			t && (e ? (L(g, k, 1), L(h, k, 0), L(y, A, 0), L(g, k, 1), L(y, A, 0), L(C, A, 1), L(y, k, 0), L(E, A, .5), L(C, A, 1), L(E, A, .5), L(x, k, 0), L(C, A, 1)) : (L(g, k, 1), L(h, k, 0), L(b, A, 1), L(h, k, 0), L(C, A, 0), L(b, A, 1), L(b, k, 1), L(C, A, 0), L(E, A, .5), L(E, A, .5), L(C, A, 0), L(S, k, 1)));
		}
		function B(e, n, r, a, s, f) {
			switch (t.strokeLineCap) {
				case "round":
					s ? ae(e, r, n, f, .5) : ae(e, n, r, f, .5);
					break;
				case "square": if (s) c.subVectors(n, e), l.set(c.y, -c.x), u.addVectors(c, l).add(e), d.subVectors(l, c).add(e), a ? (u.toArray(i, 3), d.toArray(i, 0), d.toArray(i, 9)) : (u.toArray(i, 3), o[7] === 1 ? d.toArray(i, 9) : u.toArray(i, 9), d.toArray(i, 0));
				else {
					c.subVectors(r, e), l.set(c.y, -c.x), u.addVectors(c, l).add(e), d.subVectors(l, c).add(e);
					let t = i.length;
					a ? (u.toArray(i, t - 3), d.toArray(i, t - 6), d.toArray(i, t - 12)) : (d.toArray(i, t - 6), u.toArray(i, t - 3), d.toArray(i, t - 12));
				}
			}
		}
		function V(e) {
			let t = !1;
			for (let n = 1, i = e.length - 1; n < i; n++) if (e[n].distanceTo(e[n + 1]) < r) {
				t = !0;
				break;
			}
			if (!t) return e;
			let n = [];
			n.push(e[0]);
			for (let t = 1, i = e.length - 1; t < i; t++) e[t].distanceTo(e[t + 1]) >= r && n.push(e[t]);
			return n.push(e[e.length - 1]), n;
		}
	}
}, lt = /^\s*url\(\s*(?:["']\s*)?#([^)'"\s]+)(?:\s*["'])?\s*\)\s*$/;
function ut(e, t, n = 256) {
	if (!e || !Array.isArray(e.stops) || e.stops.length === 0) return null;
	let r = t.userData.transform, i = e.gradientUnits === "objectBoundingBox", a = null;
	if (i && (a = dt(t, r), a === null)) return null;
	function o(t, n, o) {
		o.set(t, n, 1), e.gradientTransform && o.applyMatrix3(e.gradientTransform), i && o.set(a.minX + o.x * a.width, a.minY + o.y * a.height, 1), r && o.applyMatrix3(r);
	}
	let s = document.createElement("canvas"), c;
	if (e.type === "linearGradient") {
		s.width = n, s.height = 1;
		let t = s.getContext("2d"), r = t.createLinearGradient(0, 0, n, 0);
		ft(r, e.stops), t.fillStyle = r, t.fillRect(0, 0, n, 1);
		let i = new z(), a = new z();
		o(e.x1, e.y1, i), o(e.x2, e.y2, a);
		let l = a.x - i.x, u = a.y - i.y, d = l * l + u * u || 1e-20, f = l / d, p = u / d, m = -(f * i.x + p * i.y);
		c = new P().set(f, p, m, 0, 0, .5, 0, 0, 1);
	} else {
		let t = e.cx, o = e.cy, l = e.fx, u = e.fy, d = e.r;
		if (e.gradientTransform) {
			let n = new z();
			n.set(t, o, 1).applyMatrix3(e.gradientTransform), t = n.x, o = n.y, n.set(l, u, 1).applyMatrix3(e.gradientTransform), l = n.x, u = n.y;
		}
		if (i && (t = a.minX + t * a.width, o = a.minY + o * a.height, l = a.minX + l * a.width, u = a.minY + u * a.height, d *= Math.sqrt((a.width * a.width + a.height * a.height) / 2)), d <= 0) return null;
		s.width = n, s.height = n;
		let f = s.getContext("2d"), p = t - d, m = o - d, h = 2 * d, g = n / h;
		f.setTransform(g, 0, 0, g, -p * g, -m * g);
		let _ = f.createRadialGradient(l, u, 0, t, o, d);
		ft(_, e.stops), f.fillStyle = _, f.fillRect(p, m, h, h);
		let v = r ? r.clone().invert() : new P();
		c = new P().set(1 / h, 0, -p / h, 0, 1 / h, -m / h, 0, 0, 1).multiply(v);
	}
	let l = new te(s);
	l.colorSpace = st, l.flipY = !1, l.matrixAutoUpdate = !1, l.matrix = c;
	let u = e.spreadMethod === "reflect" ? I : e.spreadMethod === "repeat" ? ie : ne;
	return l.wrapS = u, l.wrapT = u, l;
}
function dt(e, t) {
	let n = t ? t.clone().invert() : null, r = new R(), i = new E();
	for (let t of e.subPaths) for (let e of t.getPoints()) r.copy(e), n && r.applyMatrix3(n), i.expandByPoint(r);
	return i.isEmpty() ? null : {
		minX: i.min.x,
		minY: i.min.y,
		width: i.max.x - i.min.x,
		height: i.max.y - i.min.y
	};
}
function ft(e, t) {
	let n = new k();
	for (let r of t) {
		let t = r.color;
		if (r.opacity < 1) {
			n.setStyle(r.color, st);
			let e = /rgb\(([^)]+)\)/.exec(n.getStyle(st));
			e && (t = `rgba(${e[1]},${r.opacity})`);
		}
		e.addColorStop(Math.max(0, Math.min(1, r.offset)), t);
	}
}
//#endregion
//#region node_modules/three/examples/jsm/utils/BufferGeometryUtils.js
function pt(e, t = !1) {
	let n = e[0].index !== null, r = new Set(Object.keys(e[0].attributes)), i = new Set(Object.keys(e[0].morphAttributes)), a = {}, o = {}, s = e[0].morphTargetsRelative, c = new O(), l = 0;
	for (let u = 0; u < e.length; ++u) {
		let d = e[u], f = 0;
		if (n !== (d.index !== null)) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + u + ". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."), null;
		for (let e in d.attributes) {
			if (!r.has(e)) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + u + ". All geometries must have compatible attributes; make sure \"" + e + "\" attribute exists among all geometries, or in none of them."), null;
			a[e] === void 0 && (a[e] = []), a[e].push(d.attributes[e]), f++;
		}
		if (f !== r.size) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + u + ". Make sure all geometries have the same number of attributes."), null;
		if (s !== d.morphTargetsRelative) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + u + ". .morphTargetsRelative must be consistent throughout all geometries."), null;
		for (let e in d.morphAttributes) {
			if (!i.has(e)) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + u + ".  .morphAttributes must be consistent throughout all geometries."), null;
			o[e] === void 0 && (o[e] = []), o[e].push(d.morphAttributes[e]);
		}
		if (t) {
			let e;
			if (n) e = d.index.count;
			else if (d.attributes.position !== void 0) e = d.attributes.position.count;
			else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index " + u + ". The geometry must have either an index or a position attribute"), null;
			c.addGroup(l, e, u), l += e;
		}
	}
	if (n) {
		let t = 0, n = [];
		for (let r = 0; r < e.length; ++r) {
			let i = e[r].index;
			for (let e = 0; e < i.count; ++e) n.push(i.getX(e) + t);
			t += e[r].attributes.position.count;
		}
		c.setIndex(n);
	}
	for (let e in a) {
		let t = mt(a[e]);
		if (!t) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the " + e + " attribute."), null;
		c.setAttribute(e, t);
	}
	for (let e in o) {
		let t = o[e][0].length;
		if (t !== 0) {
			c.morphAttributes = c.morphAttributes || {}, c.morphAttributes[e] = [];
			for (let n = 0; n < t; ++n) {
				let t = [];
				for (let r = 0; r < o[e].length; ++r) t.push(o[e][r][n]);
				let r = mt(t);
				if (!r) return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the " + e + " morphAttribute."), null;
				c.morphAttributes[e].push(r);
			}
		}
	}
	return c;
}
function mt(e) {
	let t, n, r, i = -1, a = 0;
	for (let o = 0; o < e.length; ++o) {
		let s = e[o];
		if (t === void 0 && (t = s.array.constructor), t !== s.array.constructor) return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."), null;
		if (n === void 0 && (n = s.itemSize), n !== s.itemSize) return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."), null;
		if (r === void 0 && (r = s.normalized), r !== s.normalized) return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."), null;
		if (i === -1 && (i = s.gpuType), i !== s.gpuType) return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."), null;
		a += s.count * n;
	}
	let o = new t(a), s = new D(o, n, r), c = 0;
	for (let t = 0; t < e.length; ++t) {
		let r = e[t];
		if (r.isInterleavedBufferAttribute) {
			let e = c / n;
			for (let t = 0, i = r.count; t < i; t++) for (let i = 0; i < n; i++) {
				let n = r.getComponent(t, i);
				s.setComponent(t + e, i, n);
			}
		} else o.set(r.array, c);
		c += r.count * n;
	}
	return i !== void 0 && (s.gpuType = i), s;
}
//#endregion
//#region \0bgparty-json:D:/Other/BG/BGParty/src/games/turingtumble/models.json.mjs
var ht = await fetch("games/turingtumble/data/models.json").then((e) => e.json()), Z = {
	ink: "#24434e",
	background: "#d5e4e9",
	board: "#f8eed8",
	back: "#779da5",
	rim: "#456874",
	socket: "#536e78",
	socketCore: "#e6eeee",
	helper: "#a3b4af",
	cradle: "#7e9b9c",
	ramp: "#7bce4c",
	crossover: "#ffd34c",
	bit: "#66bcec",
	interceptor: "#81979c",
	gearbit: "#bd91e5",
	gear: "#fa9277",
	blue: "#46a9df",
	red: "#ed827c",
	accent: "#40876a"
}, gt = /* @__PURE__ */ new Map();
function _t(e, t = !1) {
	let n = e + t;
	return gt.has(n) || gt.set(n, t ? new T.MeshBasicMaterial({
		color: e,
		side: T.DoubleSide
	}) : new T.MeshLambertMaterial({
		color: e,
		side: T.DoubleSide
	})), gt.get(n);
}
function vt(e, t, n) {
	let r = new T.Shape();
	return r.moveTo(-e / 2 + n, -t / 2), r.lineTo(e / 2 - n, -t / 2), r.quadraticCurveTo(e / 2, -t / 2, e / 2, -t / 2 + n), r.lineTo(e / 2, t / 2 - n), r.quadraticCurveTo(e / 2, t / 2, e / 2 - n, t / 2), r.lineTo(-e / 2 + n, t / 2), r.quadraticCurveTo(-e / 2, t / 2, -e / 2, t / 2 - n), r.lineTo(-e / 2, -t / 2 + n), r.quadraticCurveTo(-e / 2, -t / 2, -e / 2 + n, -t / 2), r;
}
function yt(e, t, n, r, i, a = 0, o = 0, s = 0, c = .12) {
	let l = new T.Mesh(new T.ExtrudeGeometry(vt(t, n, c), {
		depth: r,
		bevelEnabled: !0,
		bevelSize: .035,
		bevelThickness: .035,
		bevelSegments: 2,
		curveSegments: 10
	}), _t(i));
	return l.position.set(a, o, s), e.add(l), l;
}
function bt(e, t, n, r = .035, i = .32) {
	let a = new T.CatmullRomCurve3(t.map((e) => new T.Vector3(e[0], e[1], e[2] ?? i)));
	e.add(new T.Mesh(new T.TubeGeometry(a, Math.max(12, t.length * 7), r, 7, !1), _t(n)));
}
function xt(e, t, n, r, i = 0, a = 0, o = 0, s = !1) {
	let c = new T.Mesh(new T.CylinderGeometry(t, t, n, 24), _t(r, s));
	return c.rotation.x = Math.PI / 2, c.position.set(i, a, o), e.add(c), c;
}
function St(e, t, n, r, i = 0, a = 0, o = 0) {
	let s = new T.Mesh(new T.RingGeometry(t, n, 24), _t(r));
	return s.position.set(i, a, o), e.add(s), s;
}
function Ct(e, t, n, r) {
	let i = new T.CatmullRomCurve3(t.map((e) => new T.Vector3(e[0], e[1], 0))).getPoints(40), a = [], o = [];
	for (let e = 0; e < i.length; e++) {
		let t = i[Math.min(e + 1, i.length - 1)].clone().sub(i[Math.max(0, e - 1)]).normalize(), r = new T.Vector2(-t.y, t.x).multiplyScalar(n / 2);
		a.push(new T.Vector2(i[e].x + r.x, i[e].y + r.y)), o.push(new T.Vector2(i[e].x - r.x, i[e].y - r.y));
	}
	e.add(new T.Mesh(new T.ExtrudeGeometry(new T.Shape([...a, ...o.reverse()]), {
		depth: .16,
		bevelEnabled: !0,
		bevelThickness: .009,
		bevelSize: .008,
		bevelSegments: 2,
		curveSegments: 10
	}), _t(r)));
}
var wt = {
	ramp: "Ramp",
	crossover: "Crossover",
	bit: "Bit",
	interceptor: "Interceptor",
	gearbit: "Gearbit",
	gear: "Gear"
}, Tt, Et = /* @__PURE__ */ new Map();
function Dt(e, t) {
	let n = e.subPaths.flatMap((e) => e.getPoints(12));
	if (!n.length) return !1;
	let r = new T.Box2().setFromPoints(n), i = r.getCenter(new T.Vector2());
	return i.x > t.x && i.x < t.x + t.width && i.y > t.y && i.y < t.y + t.height && r.min.x >= t.x - .4 && r.max.x <= t.x + t.width + .4 && r.min.y >= t.y - .4 && r.max.y <= t.y + t.height + .4;
}
function Ot(e) {
	let t = Et.get(e);
	if (t) return t.clone();
	let n = new T.Group();
	if (e === "crossover") {
		for (let e of [-1, 1]) Ct(n, [
			[.43 * e, .67],
			[.58 * e, .41],
			[.64 * e, .12],
			[.5 * e, -.17],
			[.33 * e, -.44],
			[.14 * e, -.57],
			[0, -.6]
		], .075, Z.crossover);
		Ct(n, [
			[-.63, .1],
			[-.23, .1],
			[-.11, .19],
			[0, .22],
			[.11, .19],
			[.23, .1],
			[.63, .1]
		], .065, Z.crossover), Ct(n, [[0, .76], [0, .23]], .065, Z.crossover), Ct(n, [
			[-.47, -.61],
			[0, -.59],
			[.47, -.61]
		], .075, Z.crossover), xt(n, .082, .065, "#eaeadd", 0, 0, .22), xt(n, .039, .015, "#758575", 0, 0, .26), n.scale.setScalar(.8);
	} else {
		Tt ??= new ct().parse(ht.svg).paths;
		let t = e === "gear" ? ["Gear-f"] : [`${wt[e]}-m`, ...["bit", "gearbit"].includes(e) ? [`${wt[e]}-f`] : []], r = ht.boxes;
		for (let i = 0; i < t.length; i++) {
			let a = r[t[i]], o = a.x + a.width / 2, s = a.y + a.height / 2, c = [], l = null, u = 0, d = 0;
			for (let t of Tt.filter((e) => {
				let t = e.userData?.style;
				return t?.fill !== "none" && Number(t?.fillOpacity ?? 1) > .72 && Dt(e, a);
			})) for (let n of t.toShapes()) {
				let r = n.extractPoints(20), a = (e) => e.map((e) => new T.Vector2((e.x - o) / 22.48958333, -(e.y - s) / 22.48958333)), f = new T.Shape(a(r.shape));
				f.holes = r.holes.map((e) => new T.Path(a(e)));
				let p = Math.abs(T.ShapeUtils.area(f.getPoints(20)));
				if (p < 2e-5) continue;
				p > u && (l = f, u = p);
				let m = new T.ShapeGeometry(f, 20);
				m.translate(0, 0, .16 + i * .09 + d++ * 25e-5);
				let h = new T.Color(Z[e]), g = {
					h: 0,
					s: 0,
					l: 0
				};
				t.color.getHSL(g), h.multiplyScalar(Math.max(.72, Math.min(1.17, .82 + g.l * .7)));
				let _ = [];
				for (let e = 0; e < m.attributes.position.count; e++) _.push(h.r, h.g, h.b);
				m.setAttribute("color", new T.Float32BufferAttribute(_, 3)), c.push(m);
			}
			if (l) {
				let t = new T.Mesh(new T.ExtrudeGeometry(l, {
					depth: .15,
					bevelEnabled: !0,
					bevelThickness: .012,
					bevelSize: .01,
					bevelSegments: 2,
					curveSegments: 20
				}), _t(new T.Color(Z[e]).multiplyScalar(.88).getStyle()));
				t.position.z = i * .09, n.add(t);
			}
			c.length && n.add(new T.Mesh(pt(c), new T.MeshLambertMaterial({
				vertexColors: !0,
				side: T.DoubleSide
			})));
		}
		xt(n, .082, .065, "#eaeadd", 0, 0, .27), xt(n, .039, .015, "#758575", 0, 0, .31);
	}
	return Et.set(e, n), n.clone();
}
var kt;
function At() {
	if (kt) return kt.clone();
	let e = new T.Group();
	yt(e, 12.8, 15.25, .34, Z.rim, .07, -.13, -.48, .55), yt(e, 12.6, 15.05, .24, Z.back, 0, -.04, -.25, .52), yt(e, 12.36, 14.82, .13, Z.board, 0, 0, 0, .47), yt(e, 11.98, 14.45, .05, "#fff6e3", 0, .02, .14, .38);
	for (let t = 0; t < 11; t++) for (let n = 0; n < 11; n++) {
		let { x: r, y: i } = W(t, n);
		(t + n) % 2 == 1 ? (xt(e, .102, .018, Z.socket, r, i, .225, !0), xt(e, .049, .02, Z.socketCore, r, i, .24, !0), bt(e, [
			[r - .18, i - .29],
			[r - .12, i - .38],
			[r, i - .4],
			[r + .12, i - .38],
			[r + .18, i - .29]
		], Z.cradle, .034, .23)) : xt(e, .046, .016, Z.helper, r, i, .23, !0);
	}
	for (let t of [-1, 1]) {
		let n = (e) => e.map(([e, n]) => [e * t, n]), r = t === -1 ? "#65aed8" : "#e19b90";
		yt(e, 3.25, .69, .15, "#d2d7c6", t * 3.62, 6.2, .27, .3), yt(e, 3.19, .62, .1, "#fffdf2", t * 3.6, 6.25, .42, .28), yt(e, 2.83, .27, .035, t === -1 ? "#d6eaf0" : "#f1dfd5", t * 3.56, 6.25, .55, .13);
		let i = [
			[4.95, 6.08],
			[3.4, 6.08],
			[2.25, 6.08],
			[2.15, 5.85],
			[2.15, 5.64]
		];
		bt(e, n(i), "#e5e7d6", .12, .48), bt(e, n(i), "#fffdf2", .075, .6), bt(e, n([[2.15, 5.96], [2.15, 5.68]]), r, .105, .58), xt(e, .12, .02, t === -1 ? "#4b7d91" : "#a36d60", t * 2.15, 5.62, .66).scale.set(1.2, .48, 1);
		let a = n(ye);
		bt(e, a, "#b1c3be", .115, .32), bt(e, a, "#fffdf2", .096, .47), bt(e, a, r, .047, .58), xt(e, .13, .055, "#a7bcba", t * 5.62, -5.88, .4), xt(e, .067, .02, "#e9eddf", t * 5.62, -5.88, .45), xt(e, .225, .095, "#93adaa", t * .52, -6.59, .4), xt(e, .17, .04, r, t * .52, -6.59, .49), xt(e, .08, .02, t === -1 ? "#4384a2" : "#b77669", t * .52, -6.59, .53);
	}
	e.updateMatrixWorld(!0);
	let t = /* @__PURE__ */ new Map();
	e.traverse((e) => {
		if (e instanceof T.Mesh && !Array.isArray(e.material)) {
			let n = t.get(e.material) ?? [];
			n.push(e), t.set(e.material, n);
		}
	});
	for (let [n, r] of t) {
		if (r.length < 2) continue;
		let t = pt(r.map((e) => (e.geometry.index ? e.geometry.toNonIndexed() : e.geometry.clone()).applyMatrix4(e.matrixWorld)), !1);
		for (let e of r) e.removeFromParent();
		e.add(new T.Mesh(t, n));
	}
	return kt = e, e.clone();
}
function jt(e) {
	let t = new T.Group(), n = be(e), r = e === "blue" ? "#80ceef" : "#eda78f";
	bt(t, ye.map(([e, t]) => [e * n, t]), e === "blue" ? "#b7eaff" : "#ffc9b9", .026, .65), St(t, .225, .255, r, n * .52, -6.59, .56), bt(t, [[n * 2.15, 5.98], [n * 2.15, 5.67]], r, .045, .71);
	for (let [e, i, a, o] of [
		[
			n * .52,
			-6.22,
			0,
			.16
		],
		[
			n * .91,
			-6.63,
			n * .15,
			0
		],
		[
			n * .52,
			-6.95,
			0,
			-.15
		],
		[
			n * 1.9,
			5.72,
			-n * .14,
			0
		],
		[
			n * 2.42,
			5.72,
			n * .14,
			0
		]
	]) bt(t, [[e, i], [e + a, i + o]], r, .024, .68);
	return t;
}
//#endregion
//#region src/games/turingtumble/playback.ts
var Mt = class {
	key = "";
	previous = null;
	frames = [];
	started = 0;
	delivered = "";
	signal = -1;
	litUntil = 0;
	start(e, t) {
		let n = JSON.stringify(e.pose);
		n !== this.key && (this.key = n, this.frames = e.frames.length ? [...this.previous ? [this.previous] : [], ...e.frames] : e.pose ? [e.pose] : [], this.previous = e.pose, this.started = t, e.pose || (this.signal = -1, this.litUntil = 0, this.delivered = ""));
	}
	sample(e, t) {
		if (!this.frames.length) return null;
		let n = Math.min(1, (e - this.started) / 100), r = n * Math.max(0, this.frames.length - 1), i = Math.floor(r), a = this.frames[i], o = this.frames[Math.min(i + 1, this.frames.length - 1)], s = a.readout;
		if (s) {
			let r = JSON.stringify([
				s.remaining,
				s.outputCount,
				s.caughtCount,
				n === 1 ? s.step : null
			]);
			r !== this.delivered && (this.delivered = r, t(s)), s.feedback && s.feedback.id !== this.signal && (this.signal = s.feedback.id, this.litUntil = e + 180);
		}
		return {
			a,
			b: o,
			alpha: r - i,
			lit: e < this.litUntil ? s?.feedback?.side : void 0,
			active: n < 1 || e < this.litUntil
		};
	}
}, Nt = new T.SphereGeometry(.147, 16, 12), Pt = new T.MeshPhongMaterial({
	color: Z.blue,
	shininess: 64,
	specular: "#b3d8e8"
}), Ft = new T.MeshPhongMaterial({
	color: Z.red,
	shininess: 64,
	specular: "#f8c2bb"
}), It = (e) => e === "blue" ? Pt : Ft, Lt = (e) => e.kind === "bit" || e.kind === "gearbit" || e.kind === "gear" ? (e.right ? -Math.PI / 2 : 0) * (e.kind === "gear" && (e.row + e.col) % 2 == 0 ? -1 : 1) : 0;
function Rt({ part: e, onPose: t }) {
	let n = a(() => Ot(e.kind), [e.kind]), { x: r, y: i } = W(e.row, e.col), o = Lt(e);
	return /* @__PURE__ */ V("group", {
		position: [
			r,
			i,
			.42
		],
		children: [/* @__PURE__ */ B("group", {
			ref: (e) => {
				e && t(e);
			},
			rotation: [
				0,
				0,
				o
			],
			scale: [
				e.kind === "ramp" && !e.right ? -1 : 1,
				1,
				1
			],
			children: /* @__PURE__ */ B("primitive", {
				object: n,
				dispose: null
			})
		}), e.fixed && /* @__PURE__ */ V("mesh", {
			position: [
				.25,
				-.15,
				.08
			],
			children: [/* @__PURE__ */ B("sphereGeometry", { args: [
				.045,
				8,
				6
			] }), /* @__PURE__ */ B("meshBasicMaterial", { color: "#8f9d8b" })]
		})]
	});
}
function zt({ part: e }) {
	let t = a(() => {
		let t = document.createElement("canvas");
		t.width = 128, t.height = 64;
		let n = t.getContext("2d");
		return n.font = "bold 34px system-ui", n.textAlign = "center", n.textBaseline = "middle", n.fillStyle = Z.ink, n.fillText(e.label ?? "", 64, 32), new T.CanvasTexture(t);
	}, [e.label]);
	r(() => () => t.dispose(), [t]);
	let n = W(e.row, e.col);
	return /* @__PURE__ */ B("sprite", {
		position: [
			n.x + .38,
			n.y - .38,
			.8
		],
		scale: [
			.6,
			.3,
			1
		],
		children: /* @__PURE__ */ B("spriteMaterial", {
			map: t,
			transparent: !0,
			depthTest: !1
		})
	});
}
function Bt({ pub: e, selected: t, targets: n, cameraView: r, onProject: s, onReadout: c }) {
	let l = a(() => At(), []), u = a(() => ({
		blue: jt("blue"),
		red: jt("red")
	}), []), d = o([]), f = a(() => new Mt(), []), p = o(null), m = o([]), h = o(/* @__PURE__ */ new Map()), g = o([[], []]), _ = o([]), { camera: v, size: y, invalidate: b } = ee(), x = a(() => {
		let t = /* @__PURE__ */ new Map();
		for (let n of [...e.frames, ...e.pose ? [e.pose] : []]) for (let e of n.balls) t.set(e.id, e.color);
		let n = e.pose?.readout?.feedback;
		return n && e.output.length && t.set(n.id, e.output.at(-1)), [...t].map(([e, t]) => ({
			id: e,
			color: t
		}));
	}, [
		e.frames,
		e.pose,
		e.output
	]);
	i(() => {
		if (!(v instanceof T.PerspectiveCamera)) return;
		let e = Math.max(ge, _e / (y.width / y.height)) / r.zoom / (2 * Math.tan(T.MathUtils.degToRad(v.fov / 2)));
		v.position.set(r.panX, r.panY - .25, e), v.lookAt(r.panX, r.panY - .25, 0), v.updateProjectionMatrix(), p.current?.updateMatrixWorld(!0);
		let t = {};
		for (let e = 0; e < 11; e++) for (let n = 0; n < 11; n++) {
			let r = W(e, n), i = new T.Vector3(r.x, r.y, .7);
			p.current?.localToWorld(i), i.project(v), t[U(e, n)] = {
				x: (i.x + 1) * y.width / 2,
				y: (1 - i.y) * y.height / 2
			};
		}
		for (let [e, n] of [["blue", -4.94], ["red", 4.43]]) {
			let r = new T.Vector3(n, 6.9, .8);
			p.current?.localToWorld(r), r.project(v), t[e] = {
				x: (r.x + 1) * y.width / 2,
				y: (1 - r.y) * y.height / 2
			};
		}
		s(t), b();
	}, [
		v,
		r,
		b,
		s,
		y
	]), i(() => {
		b();
	}, [
		b,
		t,
		n
	]), i(() => {
		if (f.start(e, performance.now()), !e.pose) for (let t = 0; t < e.parts.length; t++) m.current[t] && (m.current[t].rotation.z = Lt(e.parts[t]));
		b();
	}, [
		e,
		f,
		b
	]), w(() => {
		let t = f.sample(performance.now(), c), n = t?.a.readout?.remaining ?? e.remaining;
		for (let t of [0, 1]) {
			let r = ue[e.challenge - 1].reservoirs?.[t];
			for (let i = 0; i < g.current[t].length; i++) {
				let a = g.current[t][i];
				a.visible = i < n[t], a.material = It(r?.[e.balls[t] - n[t] + i] ?? (t === 0 ? "blue" : "red"));
			}
		}
		for (let n = 0; n < _.current.length; n++) _.current[n] && (_.current[n].visible = n < (t?.a.readout?.caughtCount ?? e.caught.length));
		if (d.current[0] && (d.current[0].visible = t?.lit === "blue"), d.current[1] && (d.current[1].visible = t?.lit === "red"), !t) return;
		let { a: r, b: i, alpha: a } = t;
		for (let e = 0; e < r.angles.length; e++) m.current[e] && (m.current[e].rotation.z = T.MathUtils.lerp(r.angles[e], i.angles[e], a));
		for (let [e, t] of h.current) {
			let n = r.balls.find((t) => t.id === e), o = i.balls.find((t) => t.id === e) ?? n;
			t.visible = !!(n && o), n && o && t.position.set(T.MathUtils.lerp(n.x, o.x, a), T.MathUtils.lerp(n.y, o.y, a), .66);
		}
		t.active && b();
	});
	let S = e.parts.find((e) => e.id === t), C = S && W(S.row, S.col);
	return /* @__PURE__ */ V(ce, { children: [
		/* @__PURE__ */ B("color", {
			attach: "background",
			args: [Z.background]
		}),
		/* @__PURE__ */ B("ambientLight", {
			color: "#fffef8",
			intensity: .85
		}),
		/* @__PURE__ */ B("directionalLight", {
			color: "#fff8e6",
			intensity: 1.4,
			position: [
				-7,
				12,
				18
			]
		}),
		/* @__PURE__ */ B("directionalLight", {
			color: "#e8ffff",
			intensity: .35,
			position: [
				8,
				-3,
				9
			]
		}),
		/* @__PURE__ */ V("group", {
			ref: p,
			rotation: [...ve],
			children: [
				/* @__PURE__ */ B("primitive", {
					object: l,
					dispose: null
				}),
				/* @__PURE__ */ B("group", {
					ref: (e) => {
						d.current[0] = e;
					},
					visible: !1,
					children: /* @__PURE__ */ B("primitive", {
						object: u.blue,
						dispose: null
					})
				}),
				/* @__PURE__ */ B("group", {
					ref: (e) => {
						d.current[1] = e;
					},
					visible: !1,
					children: /* @__PURE__ */ B("primitive", {
						object: u.red,
						dispose: null
					})
				}),
				e.parts.map((e, t) => /* @__PURE__ */ B(Rt, {
					part: e,
					onPose: (e) => {
						m.current[t] = e;
					}
				}, e.id)),
				e.parts.filter((e) => e.label).map((e) => /* @__PURE__ */ B(zt, { part: e }, e.id)),
				C && /* @__PURE__ */ V("mesh", {
					position: [
						C.x,
						C.y,
						.36
					],
					children: [/* @__PURE__ */ B("ringGeometry", { args: [
						.48,
						.53,
						40
					] }), /* @__PURE__ */ B("meshBasicMaterial", {
						color: "#328ba3",
						side: T.DoubleSide
					})]
				}),
				n.map((e) => {
					let [t, n] = e.split(",").map(Number), r = W(t, n);
					return /* @__PURE__ */ V("mesh", {
						position: [
							r.x,
							r.y,
							.34
						],
						children: [/* @__PURE__ */ B("ringGeometry", { args: [
							.14,
							.21,
							20
						] }), /* @__PURE__ */ B("meshBasicMaterial", {
							color: "#328ba3",
							side: T.DoubleSide
						})]
					}, e);
				}),
				[0, 1].flatMap((t) => Array.from({ length: Math.min(5, e.balls[t]) }, (e, n) => {
					let r = xe(t, n), i = t === 0 ? "blue" : "red";
					return /* @__PURE__ */ B("mesh", {
						ref: (e) => {
							e && (g.current[t][n] = e);
						},
						position: [
							r.x,
							r.y,
							.69
						],
						geometry: Nt,
						material: It(i)
					}, `r${t}-${n}`);
				})),
				e.caught.map((t, n) => {
					let r = e.parts.find((e) => e.id === t.part);
					if (!r) return null;
					let i = W(r.row, r.col);
					return /* @__PURE__ */ B("mesh", {
						ref: (e) => {
							e && (_.current[n] = e);
						},
						geometry: Nt,
						material: It(t.color),
						position: [
							i.x,
							i.y + .28,
							.66
						]
					}, `c${n}`);
				}),
				x.map((e) => /* @__PURE__ */ B("mesh", {
					ref: (t) => {
						t ? h.current.set(e.id, t) : h.current.delete(e.id);
					},
					geometry: Nt,
					material: It(e.color),
					visible: !1
				}, `m${e.id}`))
			]
		})
	] });
}
function Vt({ fallback: e, ...t }) {
	return /* @__PURE__ */ B(se, {
		camera: {
			fov: 34,
			near: .1,
			far: 100
		},
		dpr: [1, 2],
		frameloop: "demand",
		gl: {
			antialias: !0,
			alpha: !1
		},
		recoveryFallback: e,
		onCreated: ({ gl: e }) => {
			e.outputColorSpace = T.SRGBColorSpace, e.toneMapping = T.NeutralToneMapping, e.toneMappingExposure = 1.05;
		},
		children: /* @__PURE__ */ B(Bt, { ...t })
	});
}
//#endregion
//#region src/games/turingtumble/part-glyph.tsx
function Ht({ kind: e, right: t = !1 }) {
	let n = e === "ramp" ? `scale(${t ? 1 : -1} 1)` : `rotate(${t && e !== "crossover" && e !== "interceptor" ? 90 : 0})`, r = e === "gear" ? /* @__PURE__ */ B("path", { d: Array.from({ length: 32 }, (e, t) => {
		let n = t % 4 < 2 ? 38 : 46, r = t * Math.PI / 16;
		return `${t ? "L" : "M"}${Math.cos(r) * n},${Math.sin(r) * n}`;
	}).join(" ") + "Z" }) : me[e].map((e, t) => /* @__PURE__ */ B("polygon", { points: e.map((e) => `${e.x},${e.y}`).join(" ") }, t));
	return /* @__PURE__ */ V("svg", {
		viewBox: "-55 -55 110 110",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ B("g", {
			transform: "translate(0 4)",
			fill: Z.ink,
			opacity: ".35",
			children: /* @__PURE__ */ B("g", {
				transform: n,
				children: r
			})
		}), /* @__PURE__ */ V("g", {
			transform: n,
			fill: Z[e],
			stroke: Z.ink,
			strokeOpacity: ".6",
			strokeWidth: "1.2",
			strokeLinejoin: "round",
			children: [
				r,
				/* @__PURE__ */ B("circle", {
					r: "6",
					fill: Z.socketCore
				}),
				/* @__PURE__ */ B("circle", {
					r: "2.5",
					fill: Z.ink
				}),
				/* @__PURE__ */ B("circle", {
					cx: "-1.5",
					cy: "-2",
					r: "1.4",
					fill: "#fffdf2",
					stroke: "none"
				})
			]
		})]
	});
}
//#endregion
//#region src/games/turingtumble/board2d.tsx
var Q = (e) => e * 100 + 710, $ = (e) => 810 - e * 100, Ut = (e) => [
	"bit",
	"gearbit",
	"gear"
].includes(e.kind) ? (e.right ? -Math.PI / 2 : 0) * (e.kind === "gear" && (e.row + e.col) % 2 == 0 ? -1 : 1) : 0;
function Wt({ pub: e, selected: t, targets: n, cameraView: r, onProject: s, onReadout: c }) {
	let l = o(null), u = o([]), d = o(/* @__PURE__ */ new Map()), f = o([[], []]), p = o([]), m = o([]), h = a(() => new Mt(), []), g = a(() => {
		let t = /* @__PURE__ */ new Map();
		for (let n of [...e.frames, ...e.pose ? [e.pose] : []]) for (let e of n.balls) t.set(e.id, e.color);
		let n = e.pose?.readout?.feedback;
		return n && e.output.length && t.set(n.id, e.output.at(-1)), [...t].map(([e, t]) => ({
			id: e,
			color: t
		}));
	}, [
		e.frames,
		e.pose,
		e.output
	]);
	return i(() => {
		let e = l.current;
		if (!e) return;
		let t = () => {
			let { width: t, height: n } = e.getBoundingClientRect(), i = Math.max(ge, _e / (t / n)) / r.zoom, a = i * t / n, o = r.panX - a / 2, c = r.panY - .25 + i / 2;
			e.setAttribute("viewBox", `${Q(o)} ${$(c)} ${a * 100} ${i * 100}`);
			let l = {}, u = (e, r) => ({
				x: (e - o) / a * t,
				y: (c - r) / i * n
			});
			for (let e = 0; e < 11; e++) for (let t = 0; t < 11; t++) {
				let n = W(e, t);
				l[U(e, t)] = u(n.x, n.y);
			}
			l.blue = u(-4.94, 6.9), l.red = u(4.43, 6.9), s(l);
		}, n = new ResizeObserver(t);
		return n.observe(e), t(), () => n.disconnect();
	}, [r, s]), i(() => {
		h.start(e, performance.now()), e.pose || e.parts.forEach((e, t) => u.current[t]?.setAttribute("transform", `rotate(${-Ut(e) * 180 / Math.PI})`));
		let t = 0, n = () => {
			let r = h.sample(performance.now(), c), i = r?.a.readout?.remaining ?? e.remaining;
			for (let t of [0, 1]) {
				let n = ue[e.challenge - 1].reservoirs?.[t];
				f.current[t].forEach((r, a) => {
					r.style.display = a < i[t] ? "" : "none", r.setAttribute("fill", Z[n?.[e.balls[t] - i[t] + a] ?? (t === 0 ? "blue" : "red")]);
				}), m.current[t] && (m.current[t].style.display = r?.lit === (t === 0 ? "blue" : "red") ? "" : "none");
			}
			if (p.current.forEach((t, n) => {
				t.style.display = n < (r?.a.readout?.caughtCount ?? e.caught.length) ? "" : "none";
			}), !r) return;
			let { a, b: o, alpha: s } = r;
			a.angles.forEach((e, t) => u.current[t]?.setAttribute("transform", `rotate(${-(e + ((o.angles[t] ?? e) - e) * s) * 180 / Math.PI})`));
			for (let [e, t] of d.current) {
				let n = a.balls.find((t) => t.id === e), r = o.balls.find((t) => t.id === e) ?? n;
				t.style.display = n && r ? "" : "none", n && r && (t.setAttribute("cx", String(Q(n.x + (r.x - n.x) * s))), t.setAttribute("cy", String($(n.y + (r.y - n.y) * s))));
			}
			r.active && (t = requestAnimationFrame(n));
		};
		return t = requestAnimationFrame(n), () => cancelAnimationFrame(t);
	}, [
		e,
		h,
		c
	]), /* @__PURE__ */ V("svg", {
		ref: l,
		className: "tt-fallback",
		viewBox: "0 0 1420 1620",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ B("rect", {
				x: "70",
				y: "46",
				width: "1280",
				height: "1525",
				rx: "57",
				fill: Z.rim
			}),
			/* @__PURE__ */ B("rect", {
				x: "85",
				y: "34",
				width: "1260",
				height: "1510",
				rx: "47",
				fill: Z.board
			}),
			[0, 1].map((e) => {
				let t = e === 0 ? -1 : 1, n = e === 0 ? Z.blue : Z.red, r = ye.map(([e, n]) => `${Q(e * t)},${$(n)}`).join(" ");
				return /* @__PURE__ */ V("g", { children: [
					/* @__PURE__ */ B("rect", {
						x: Q(e === 0 ? -5.25 : 2.05),
						y: $(6.65),
						width: "320",
						height: "77",
						rx: "30",
						fill: "#f4f0d9",
						stroke: "#b3c4af",
						strokeWidth: "4"
					}),
					/* @__PURE__ */ B("path", {
						d: `M ${Q(t * 4.95)} ${$(6.28)} H ${Q(t * 2.3)} Q ${Q(t * 2.15)} ${$(6.28)} ${Q(t * 2.15)} ${$(5.86)}`,
						fill: "none",
						stroke: n,
						strokeOpacity: ".4",
						strokeWidth: "16",
						strokeLinecap: "round"
					}),
					/* @__PURE__ */ B("polyline", {
						points: r,
						fill: "none",
						stroke: "#aabeb4",
						strokeWidth: "26",
						strokeLinecap: "round",
						strokeLinejoin: "round"
					}),
					/* @__PURE__ */ B("polyline", {
						points: r,
						fill: "none",
						stroke: "#fff8df",
						strokeWidth: "19",
						strokeLinecap: "round",
						strokeLinejoin: "round"
					}),
					/* @__PURE__ */ B("polyline", {
						points: r,
						fill: "none",
						stroke: n,
						strokeWidth: "7",
						strokeOpacity: ".75"
					}),
					/* @__PURE__ */ B("circle", {
						cx: Q(t * .52),
						cy: $(-6.59),
						r: "21",
						fill: n,
						stroke: "#9bbcb6",
						strokeWidth: "5"
					}),
					/* @__PURE__ */ V("g", {
						ref: (t) => {
							m.current[e] = t;
						},
						style: { display: "none" },
						fill: "none",
						stroke: n,
						strokeWidth: "5",
						children: [
							/* @__PURE__ */ B("polyline", {
								points: r,
								strokeWidth: "12"
							}),
							/* @__PURE__ */ B("circle", {
								cx: Q(t * .52),
								cy: $(-6.59),
								r: "30"
							}),
							/* @__PURE__ */ B("path", { d: `M ${Q(t * .52)} ${$(-6.59) - 49} v 12 m 0 74 v 12 M ${Q(t * .52) - 49} ${$(-6.59)} h 12 m 74 0 h 12 M ${Q(t * 2.15) - 39} ${$(5.86)} h 15 m 48 0 h 15` })
						]
					})
				] }, e);
			}),
			Array.from({ length: 121 }, (e, t) => {
				let r = Math.floor(t / 11), i = t % 11, a = W(r, i), o = U(r, i);
				return /* @__PURE__ */ V("g", {
					transform: `translate(${Q(a.x)} ${$(a.y)})`,
					children: [/* @__PURE__ */ B("circle", {
						r: (r + i) % 2 ? 10 : 4.6,
						fill: (r + i) % 2 ? Z.socket : Z.helper
					}), n.includes(o) && /* @__PURE__ */ B("circle", {
						r: "20",
						fill: "none",
						stroke: "#328ba3",
						strokeWidth: "7"
					})]
				}, o);
			}),
			e.parts.map((e, n) => {
				let r = W(e.row, e.col);
				return /* @__PURE__ */ V("g", {
					transform: `translate(${Q(r.x)} ${$(r.y)})`,
					children: [
						t === e.id && /* @__PURE__ */ B("circle", {
							r: "53",
							fill: "none",
							stroke: "#328ba3",
							strokeWidth: "5"
						}),
						/* @__PURE__ */ B("g", {
							ref: (e) => {
								e && (u.current[n] = e);
							},
							transform: `rotate(${-Ut(e) * 180 / Math.PI})`,
							children: /* @__PURE__ */ B("svg", {
								x: "-80.9",
								y: "-80.9",
								width: "161.8",
								height: "161.8",
								children: /* @__PURE__ */ B(Ht, {
									kind: e.kind,
									right: e.kind === "ramp" && e.right
								})
							})
						}),
						e.label && /* @__PURE__ */ B("text", {
							x: "32",
							y: "51",
							fontSize: "24",
							fontWeight: "700",
							fill: Z.ink,
							children: e.label
						}),
						e.fixed && /* @__PURE__ */ B("circle", {
							cx: "27",
							cy: "20",
							r: "4.5",
							fill: Z.ink
						})
					]
				}, e.id);
			}),
			[0, 1].flatMap((t) => Array.from({ length: Math.min(5, e.balls[t]) }, (e, n) => {
				let r = xe(t, n);
				return /* @__PURE__ */ B("circle", {
					ref: (e) => {
						e && (f.current[t][n] = e);
					},
					cx: Q(r.x),
					cy: $(r.y),
					r: "14.7",
					fill: t === 0 ? Z.blue : Z.red
				}, `r${t}-${n}`);
			})),
			e.caught.map((t, n) => {
				let r = e.parts.find((e) => e.id === t.part);
				if (!r) return null;
				let i = W(r.row, r.col);
				return /* @__PURE__ */ B("circle", {
					ref: (e) => {
						e && (p.current[n] = e);
					},
					cx: Q(i.x),
					cy: $(i.y + .28),
					r: "14.7",
					fill: Z[t.color]
				}, `c${n}`);
			}),
			g.map((e) => /* @__PURE__ */ B("circle", {
				ref: (t) => {
					t ? d.current.set(e.id, t) : d.current.delete(e.id);
				},
				r: "14.7",
				fill: Z[e.color],
				style: { display: "none" }
			}, `m${e.id}`))
		]
	});
}
//#endregion
//#region src/games/turingtumble/progress.ts
var Gt = "bgparty:turingtumble", Kt;
function qt() {
	if (Kt) return Kt;
	try {
		let e = JSON.parse(localStorage.getItem(Gt) ?? "[]");
		Array.isArray(e) && (Kt = [...new Set(e.filter((e) => Number.isInteger(e) && e >= 1 && e <= 60))]);
	} catch {}
	return Kt ??= [];
}
function Jt(e) {
	let t = qt();
	if (!t.includes(e)) {
		Kt = [...t, e];
		try {
			localStorage.setItem(Gt, JSON.stringify(Kt));
		} catch {}
	}
}
//#endregion
//#region src/games/turingtumble/view-player.tsx
var Yt = {
	zoom: 1,
	panX: 0,
	panY: 0
}, Xt = Array.from({ length: 121 }, (e, t) => [Math.floor(t / 11), t % 11]), Zt = (e) => e !== "crossover" && e !== "interceptor", Qt = {
	build: "games.turingtumble.build",
	running: "games.turingtumble.running",
	paused: "games.turingtumble.paused",
	checking: "games.turingtumble.checking",
	passed: "games.turingtumble.passed",
	failed: "games.turingtumble.failed"
}, $t = {
	gap: "games.turingtumble.gap",
	escaped: "games.turingtumble.escaped",
	stalled: "games.turingtumble.stalled",
	goal: "games.turingtumble.goal",
	nim: "games.turingtumble.nimLost"
};
function en() {
	try {
		return !!document.createElement("canvas").getContext("webgl2");
	} catch {
		return !1;
	}
}
function tn(e) {
	let t = e.public;
	return /* @__PURE__ */ B(nn, {
		pub: t,
		send: e.send
	}, t.challenge);
}
function nn({ pub: e, send: t }) {
	let i = c();
	S();
	let w = ue[e.challenge - 1], [ee] = s(en), [T, E] = s(null), [D, O] = s(null), [te, ne] = s({}), [k, A] = s(!1), [j, M] = s(null), [N, P] = s(Yt), [F, I] = s({}), [re, ie] = s({
		width: 375,
		height: 500
	}), [L, ae] = s(null), oe = o(null), R = o(null), z = o(/* @__PURE__ */ new Map()), se = o(null), le = o(!1), H = e.parts.find((e) => e.id === T), pe = e.phase === "build", me = (t) => w.stock[t] >= 60 ? Infinity : w.stock[t] - e.parts.filter((e) => !e.fixed && e.kind === t).length, ve = [
		21,
		22,
		30,
		31,
		40,
		53
	].includes(w.n), ye = [21, 22].includes(w.n) ? 15 : [31, 40].includes(w.n) ? 7 : 20, be = a(() => {
		let t = new Set(e.parts.map((e) => U(e.row, e.col)));
		return Object.fromEntries(Se.map((e) => [e, Xt.filter(([n, r]) => Ce(n, r, e) && !t.has(U(n, r))).map(([e, t]) => U(e, t))]));
	}, [e.parts]);
	D && (!pe || me(D) <= 0 || !be[D].length) && O(null);
	let xe = D ?? (k ? H?.kind : void 0), W = pe && xe ? be[xe] : [], we = n((e) => I((t) => JSON.stringify(t) === JSON.stringify(e) ? t : e), []), Te = n((e) => ae(e), []);
	r(() => {
		e.phase === "passed" && Jt(e.challenge);
	}, [e.challenge, e.phase]), r(() => {
		let e = oe.current;
		if (!e) return;
		let t = new ResizeObserver(([e]) => ie({
			width: e.contentRect.width,
			height: e.contentRect.height
		}));
		return t.observe(e), () => t.disconnect();
	}, []), r(() => {
		let e = (e) => {
			e.key === "Escape" && (M(null), E(null), A(!1), O(null));
		};
		return window.addEventListener("keydown", e), () => window.removeEventListener("keydown", e);
	}, []);
	let G = (n, r) => {
		if (!pe || j || !oe.current) return;
		let i = oe.current.getBoundingClientRect(), a = n - i.left, o = r - i.top, s = (e) => F[e] ? Math.hypot(F[e].x - a, F[e].y - o) : Infinity;
		if (D || k) {
			let e = Xt.map(([e, t]) => U(e, t)).sort((e, t) => s(e) - s(t))[0];
			if (!e || s(e) > 25 || !W.includes(e)) return;
			let [n, r] = e.split(",").map(Number);
			if (D) {
				if (me(D) <= 0) return;
				t({
					type: "place",
					kind: D,
					row: n,
					col: r,
					right: te[D] ?? !0
				});
			} else T && t({
				type: "move",
				id: T,
				row: n,
				col: r
			});
			A(!1);
		} else {
			let t = [...e.parts].sort((e, t) => s(U(e.row, e.col)) - s(U(t.row, t.col)))[0];
			E(t && s(U(t.row, t.col)) < 25 ? t.id : null);
		}
	}, Ee = (e) => {
		if (!e.target.closest("button, input, [role=dialog]")) {
			if (z.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			}), z.current.size === 2) {
				let [t, n] = [...z.current.values()];
				se.current = {
					distance: Math.max(1, Math.hypot(t.x - n.x, t.y - n.y)),
					x: (t.x + n.x) / 2,
					y: (t.y + n.y) / 2,
					camera: N
				}, R.current = null, le.current = !0, e.currentTarget.setPointerCapture(e.pointerId);
				return;
			}
			R.current = {
				id: e.pointerId,
				x: e.clientX,
				y: e.clientY,
				camera: N,
				moved: !1
			}, le.current = !1, e.currentTarget.setPointerCapture(e.pointerId);
		}
	}, De = (e) => {
		z.current.has(e.pointerId) && z.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
		let t = se.current, n = Math.max(ge / re.height, _e / re.width);
		if (t && z.current.size === 2) {
			let [e, r] = [...z.current.values()], i = Math.max(1, Math.min(2.5, t.camera.zoom * Math.hypot(e.x - r.x, e.y - r.y) / t.distance));
			P({
				...t.camera,
				zoom: i,
				panX: t.camera.panX - ((e.x + r.x) / 2 - t.x) * n / i,
				panY: t.camera.panY + ((e.y + r.y) / 2 - t.y) * n / i
			});
			return;
		}
		let r = R.current;
		if (!r || r.id !== e.pointerId) return;
		let i = e.clientX - r.x, a = e.clientY - r.y;
		Math.hypot(i, a) < 6 && !r.moved || (r.moved = !0, le.current = !0, P({
			...r.camera,
			panX: r.camera.panX - i * n / r.camera.zoom,
			panY: r.camera.panY + a * n / r.camera.zoom
		}));
	}, Oe = (e) => {
		z.current.delete(e.pointerId), se.current && (le.current = !0), se.current = null, R.current = null;
	}, ke = (e) => w.variables.includes(e) || w.adjustable?.includes(e), Ae = H && Zt(H.kind) && (!H.fixed || ke(H.id)) && !fe(e.parts, H.id).some((e) => e.fixed && e.kind === "gearbit" && !ke(e.id)), K = H && F[U(H.row, H.col)], je = re.width, Me = re.height, Ne = H?.fixed ? +!!Ae : 3, Pe = Ne * 54 + (Ne - 1) * 6 + 14, Fe = K && (K.x + 38 + Pe <= je - 8 ? "right" : K.x - 38 - Pe >= 8 ? "left" : null), Ie = K && Ne ? {
		left: Math.max(8, Math.min(je - Pe - 8, Fe === "right" ? K.x + 38 : Fe === "left" ? K.x - 38 - Pe : K.x - Pe / 2)),
		top: Math.max(8, Math.min(Me - 64 - 8, Fe ? K.y - 32 : K.y - 38 - 64 >= 8 ? K.y - 38 - 64 : K.y + 38))
	} : void 0, Le = /* @__PURE__ */ new Set([...qt(), ...e.phase === "passed" ? [e.challenge] : []]), Re = () => {
		O(null), A(!1), t({ type: e.phase === "running" || e.phase === "checking" ? "pause" : "run" });
	}, ze = () => {
		O(null), A(!1), t({ type: "edit" });
	}, Be = e.pose ? L && L.step <= (e.pose.readout?.step ?? 0) ? L : e.frames[0]?.readout ?? e.pose.readout : null, Ve = Be?.remaining ?? e.remaining, He = e.output.slice(0, Be?.outputCount ?? e.output.length), q = Je(w, e.parts, e.balls, e.start), J = q === void 0 ? -1 : He.findIndex((e, t) => q[t] !== (e === "blue" ? "b" : "r")), Ue = J < 0 ? He.length : J, Y = e.pose?.readout && (!Be || Be.step < e.pose.readout.step) && [
		"passed",
		"failed",
		"checking"
	].includes(e.phase) ? "running" : e.phase, We = /* @__PURE__ */ B(Wt, {
		pub: e,
		selected: pe ? T : null,
		targets: W,
		cameraView: N,
		onProject: we,
		onReadout: Te
	}), Ge = (e, t, n, r = !1) => /* @__PURE__ */ B("button", {
		type: "button",
		className: "tt-control",
		onClick: n,
		"aria-label": i(e),
		title: i(e),
		disabled: r,
		children: t
	}), Ke = i(Qt[Y], {
		n: String(e.check.done),
		total: String(e.check.total)
	}), qe = e.failure === "goal" && q !== void 0 && J >= 0 ? i(J >= q.length ? "games.turingtumble.extraOutput" : "games.turingtumble.wrongOutput", {
		n: String(J + 1),
		color: i(q[J] === "b" ? "games.turingtumble.blue" : "games.turingtumble.red")
	}) : e.failure === "goal" && q !== void 0 && He.length < q.length ? i("games.turingtumble.missingOutput", { n: String(He.length + 1) }) : e.failure ? i($t[e.failure]) : "", Ye = e.phase === "running" || e.phase === "paused" && !!e.pose?.balls.length, Xe = /* @__PURE__ */ V("div", {
		className: "tt-controls",
		children: [
			(ve || w.n === 32) && Ge("games.turingtumble.input", /* @__PURE__ */ B(v, { size: 19 }), () => M("inputs"), !pe),
			Ge("games.turingtumble.undo", /* @__PURE__ */ B(l, { size: 19 }), () => t({ type: "undo" }), !pe || !e.canUndo),
			Ge("games.turingtumble.reset", /* @__PURE__ */ B(y, { size: 18 }), () => M("reset")),
			Ge("games.turingtumble.zoomOut", /* @__PURE__ */ B(x, { size: 19 }), () => P({
				...N,
				zoom: Math.max(1, N.zoom - .35)
			}), N.zoom <= 1),
			Ge("games.turingtumble.zoomIn", /* @__PURE__ */ B(b, { size: 19 }), () => P({
				...N,
				zoom: Math.min(2.5, N.zoom + .35)
			}), N.zoom >= 2.5),
			Ge("games.turingtumble.fit", /* @__PURE__ */ B(_, { size: 19 }), () => P(Yt))
		]
	});
	return /* @__PURE__ */ B("div", {
		className: "tt-game",
		children: /* @__PURE__ */ B(C, {
			adaptive: !0,
			className: "tt-screen",
			scroll: !1,
			banner: /* @__PURE__ */ V("header", {
				className: `tt-header${(w.output?.length ?? 0) > 16 || w.n === 53 ? " tt-header-long" : ""}`,
				children: [
					/* @__PURE__ */ V("div", {
						className: "tt-info",
						children: [/* @__PURE__ */ V("button", {
							className: "tt-level",
							onClick: () => M("levels"),
							"aria-label": `${i("games.turingtumble.level", { n: String(w.n) })} · ${i("games.turingtumble.levels")}`,
							children: [/* @__PURE__ */ B("span", { children: String(w.n).padStart(2, "0") }), /* @__PURE__ */ B(p, { size: 12 })]
						}), /* @__PURE__ */ V("div", {
							className: "tt-title",
							children: [/* @__PURE__ */ B("span", { children: i("games.turingtumble.challenge") }), /* @__PURE__ */ B("strong", { children: i(w.titleKey) })]
						})]
					}),
					/* @__PURE__ */ V("span", {
						className: `tt-status tt-status-${Y}`,
						children: [Y === "passed" ? /* @__PURE__ */ B(u, { size: 13 }) : Y === "failed" ? /* @__PURE__ */ B(d, { size: 13 }) : Y === "running" ? /* @__PURE__ */ B(g, { size: 12 }) : /* @__PURE__ */ B("i", { "aria-hidden": "true" }), Ke]
					}),
					/* @__PURE__ */ V("button", {
						className: "tt-goal",
						onClick: () => M("goal"),
						"aria-label": i("games.turingtumble.goalDetails"),
						children: [/* @__PURE__ */ B("span", { children: i(w.goalKey) }), /* @__PURE__ */ B(f, { size: 15 })]
					}),
					q !== void 0 && /* @__PURE__ */ V("div", {
						className: "tt-sequence",
						"aria-label": i("games.turingtumble.required"),
						children: [/* @__PURE__ */ V("div", {
							className: "tt-sequence-label",
							children: [/* @__PURE__ */ B("strong", { children: i("games.turingtumble.required") }), /* @__PURE__ */ V("span", { children: [
								Math.min(Ue, q.length),
								" / ",
								q.length
							] })]
						}), /* @__PURE__ */ B("ol", {
							className: "tt-sequence-balls",
							children: [...q].map((e, t) => {
								let n = t === J ? "error" : t < Ue ? "done" : t === He.length && Y !== "build" && Y !== "passed" ? "current" : "pending";
								return /* @__PURE__ */ V("li", {
									className: `tt-sequence-item tt-sequence-${n}`,
									"aria-label": i(n === "error" ? "games.turingtumble.sequenceError" : n === "done" ? "games.turingtumble.sequenceDone" : "games.turingtumble.sequencePending", {
										n: String(t + 1),
										color: i(e === "b" ? "games.turingtumble.blue" : "games.turingtumble.red")
									}),
									"aria-current": n === "current" ? "step" : void 0,
									children: [
										/* @__PURE__ */ B("i", { className: e === "b" ? "tt-blue-ball" : "tt-red-ball" }),
										n === "done" && /* @__PURE__ */ B("b", { children: /* @__PURE__ */ B(u, { size: 9 }) }),
										n === "error" && /* @__PURE__ */ B("b", { children: /* @__PURE__ */ B(d, { size: 9 }) })
									]
								}, t);
							})
						})]
					})
				]
			}),
			actionsHeight: "tt-footer-slot",
			actions: /* @__PURE__ */ V("footer", {
				className: "tt-footer",
				children: [
					/* @__PURE__ */ V("div", {
						className: "tt-workbench",
						"aria-label": i("games.turingtumble.available"),
						children: [/* @__PURE__ */ V("div", {
							className: "tt-trays",
							children: [Se.filter((e) => w.stock[e] > 0).map((e) => {
								let t = w.stock[e] >= 60 ? 99 : me(e), n = te[e] ?? !0, r = Zt(e) ? i("games.turingtumble.inputDirection", {
									part: i(de[e]),
									direction: i(n ? "games.turingtumble.right" : "games.turingtumble.left")
								}) : i(de[e]);
								return /* @__PURE__ */ V("button", {
									className: "tt-tray",
									disabled: !pe || t <= 0 || !be[e].length,
									"aria-pressed": D === e,
									"aria-label": `${r} ${t >= 60 ? "∞" : t}`,
									onClick: () => {
										O(D === e ? null : e), E(null), A(!1);
									},
									children: [
										/* @__PURE__ */ B(Ht, {
											kind: e,
											right: n
										}),
										Zt(e) && /* @__PURE__ */ B("span", {
											className: "tt-tray-direction",
											"aria-hidden": "true",
											children: n ? "→" : "←"
										}),
										/* @__PURE__ */ B("span", {
											className: "tt-tray-name",
											children: i(de[e])
										}),
										/* @__PURE__ */ B("span", {
											className: "tt-tray-count",
											children: t >= 60 ? "∞" : t
										}),
										D === e && /* @__PURE__ */ B("span", {
											className: "tt-tray-selected",
											"aria-hidden": "true",
											children: /* @__PURE__ */ B(u, { size: 11 })
										})
									]
								}, e);
							}), w.n === 59 && /* @__PURE__ */ B("span", {
								className: "tt-nim-status",
								children: i(e.nim.turn === "human" ? "games.turingtumble.yourTurn" : "games.turingtumble.machineTurn", { n: String(e.nim.taken) })
							})]
						}), /* @__PURE__ */ V("button", {
							className: "tt-tray-flip",
							disabled: !pe || !D || !Zt(D),
							"aria-label": i("games.turingtumble.flipPlacement"),
							onClick: () => {
								D && ne((e) => ({
									...e,
									[D]: !(e[D] ?? !0)
								}));
							},
							children: [/* @__PURE__ */ B(m, { size: 21 }), /* @__PURE__ */ B("span", { children: i("games.turingtumble.flip") })]
						})]
					}),
					Xe,
					/* @__PURE__ */ V("div", {
						className: "tt-bottom",
						children: [
							w.n === 59 ? /* @__PURE__ */ V(ce, { children: [/* @__PURE__ */ V("button", {
								className: "tt-start",
								onClick: () => Ye ? Re() : t({ type: "release" }),
								disabled: !Ye && (e.nim.taken >= 3 || ["passed", "failed"].includes(e.phase)),
								children: [/* @__PURE__ */ B(g, { size: 18 }), i(Ye ? e.phase === "running" ? "games.turingtumble.pause" : "games.turingtumble.resume" : "games.turingtumble.release")]
							}), /* @__PURE__ */ B("button", {
								className: "tt-secondary",
								onClick: () => t({ type: "end-turn" }),
								disabled: Ye || !e.nim.taken || ["passed", "failed"].includes(e.phase),
								children: i("games.turingtumble.endTurn")
							})] }) : ["passed", "failed"].includes(e.phase) ? /* @__PURE__ */ V("button", {
								className: "tt-start",
								onClick: ze,
								children: [/* @__PURE__ */ B(l, { size: 18 }), i("games.turingtumble.edit")]
							}) : /* @__PURE__ */ V("button", {
								className: "tt-start",
								onClick: Re,
								children: [e.phase !== "running" && e.phase !== "checking" && /* @__PURE__ */ B(g, { size: 18 }), i(e.phase === "running" || e.phase === "checking" ? "games.turingtumble.pause" : e.phase === "paused" ? "games.turingtumble.resume" : "games.turingtumble.start")]
							}),
							/* @__PURE__ */ B("button", {
								className: "tt-stop",
								disabled: ![
									"running",
									"paused",
									"checking"
								].includes(e.phase),
								onClick: ze,
								children: i("games.turingtumble.stop")
							}),
							/* @__PURE__ */ V("button", {
								className: "tt-speed",
								"aria-label": `${i("games.turingtumble.speed")} ${e.speed}×`,
								onClick: () => t({
									type: "speed",
									value: he[(he.findIndex((t) => t === e.speed) + 1) % he.length]
								}),
								children: [e.speed, "×"]
							})
						]
					})
				]
			}),
			children: /* @__PURE__ */ V("div", {
				ref: oe,
				className: "tt-stage",
				onPointerDown: Ee,
				onPointerMove: De,
				onPointerUp: Oe,
				onPointerCancel: (e) => {
					Oe(e), le.current = !0;
				},
				onClick: (e) => {
					!le.current && !e.target.closest("button,input,[role=dialog]") && G(e.clientX, e.clientY);
				},
				children: [
					ee ? /* @__PURE__ */ B(Vt, {
						pub: e,
						selected: pe ? T : null,
						targets: W,
						cameraView: N,
						onProject: we,
						onReadout: Te,
						fallback: We
					}) : We,
					["blue", "red"].map((e, t) => F[e] && /* @__PURE__ */ V("span", {
						className: `tt-stock tt-stock-${e}`,
						style: {
							left: F[e].x,
							top: F[e].y
						},
						"aria-label": `${i(e === "blue" ? "games.turingtumble.blue" : "games.turingtumble.red")} ${i("games.turingtumble.remaining")} ${Ve[t]}`,
						children: ["● ", Ve[t]]
					}, e)),
					pe && !D && !k && H && Ie && /* @__PURE__ */ V("div", {
						className: "tt-part-actions",
						style: Ie,
						role: "toolbar",
						"aria-label": i("games.turingtumble.selected"),
						children: [
							!H.fixed && /* @__PURE__ */ V("button", {
								onClick: () => {
									A(!0), O(null);
								},
								children: [/* @__PURE__ */ B(h, { size: 19 }), /* @__PURE__ */ B("span", { children: i("games.turingtumble.move") })]
							}),
							/* @__PURE__ */ V("button", {
								disabled: !Ae,
								onClick: () => t({
									type: "flip",
									id: H.id
								}),
								children: [/* @__PURE__ */ B(m, { size: 19 }), /* @__PURE__ */ B("span", { children: i("games.turingtumble.flip") })]
							}),
							!H.fixed && /* @__PURE__ */ V("button", {
								onClick: () => {
									t({
										type: "remove",
										id: H.id
									}), A(!1), O(null);
								},
								children: [/* @__PURE__ */ B(y, { size: 19 }), /* @__PURE__ */ B("span", { children: i("games.turingtumble.remove") })]
							})
						]
					}),
					(D || k) && pe && /* @__PURE__ */ V("div", {
						className: "tt-place-cancel",
						children: [/* @__PURE__ */ B("span", { children: i("games.turingtumble.place") }), /* @__PURE__ */ V("button", {
							onClick: () => {
								A(!1), O(null);
							},
							children: [/* @__PURE__ */ B(d, { size: 17 }), i("games.turingtumble.cancel")]
						})]
					}),
					[
						"passed",
						"failed",
						"checking"
					].includes(Y) && /* @__PURE__ */ V("div", {
						className: `tt-result tt-result-${Y}`,
						role: "status",
						children: [
							/* @__PURE__ */ V("strong", { children: [Y === "passed" && /* @__PURE__ */ B(u, { size: 20 }), Ke] }),
							qe && /* @__PURE__ */ B("p", { children: qe }),
							Y === "checking" && /* @__PURE__ */ B("progress", {
								value: e.check.done,
								max: e.check.total
							}),
							Y === "passed" && e.challenge < 60 && /* @__PURE__ */ B("button", {
								onClick: () => t({
									type: "goto",
									n: e.challenge + 1
								}),
								children: i("games.turingtumble.next")
							})
						]
					}),
					j && /* @__PURE__ */ B("div", {
						className: "tt-modal-shade",
						onClick: () => M(null),
						children: /* @__PURE__ */ V("section", {
							className: "tt-dialog",
							role: "dialog",
							"aria-modal": "true",
							"aria-label": i(j === "levels" ? "games.turingtumble.levels" : j === "inputs" ? "games.turingtumble.input" : j === "goal" ? "games.turingtumble.goalDetails" : "games.turingtumble.reset"),
							onClick: (e) => e.stopPropagation(),
							children: [/* @__PURE__ */ B("button", {
								className: "tt-dialog-close",
								"aria-label": i("games.turingtumble.close"),
								onClick: () => M(null),
								children: /* @__PURE__ */ B(d, { size: 20 })
							}), j === "levels" ? /* @__PURE__ */ V(ce, { children: [/* @__PURE__ */ B("strong", { children: i("games.turingtumble.completed", { n: String(Le.size) }) }), /* @__PURE__ */ B("div", {
								className: "tt-level-grid",
								children: ue.map((n) => /* @__PURE__ */ V("button", {
									"aria-label": `${i("games.turingtumble.level", { n: String(n.n) })} ${i(n.titleKey)}`,
									"aria-current": n.n === e.challenge ? "step" : void 0,
									className: Le.has(n.n) ? "tt-level-done" : "",
									onClick: () => {
										t({
											type: "goto",
											n: n.n
										}), M(null);
									},
									children: [n.n, Le.has(n.n) && /* @__PURE__ */ B(u, { size: 12 })]
								}, n.n))
							})] }) : j === "goal" ? /* @__PURE__ */ V(ce, { children: [/* @__PURE__ */ B("strong", { children: i(w.titleKey) }), /* @__PURE__ */ B("p", {
								className: "tt-goal-full",
								children: i(w.goalKey)
							})] }) : j === "reset" ? /* @__PURE__ */ V(ce, { children: [/* @__PURE__ */ B("p", { children: i("games.turingtumble.resetConfirm") }), /* @__PURE__ */ V("div", {
								className: "tt-confirm-row",
								children: [/* @__PURE__ */ B("button", {
									onClick: () => M(null),
									children: i("games.turingtumble.cancel")
								}), /* @__PURE__ */ B("button", {
									onClick: () => {
										t({ type: "reset" }), E(null), O(null), A(!1), M(null);
									},
									children: i("games.turingtumble.confirm")
								})]
							})] }) : /* @__PURE__ */ V(ce, { children: [
								/* @__PURE__ */ B("strong", { children: i("games.turingtumble.input") }),
								ve && /* @__PURE__ */ V("label", {
									className: "tt-input-label",
									children: [i("games.turingtumble.blueCount"), /* @__PURE__ */ B("input", {
										type: "number",
										min: "0",
										max: ye,
										value: e.balls[0],
										onChange: (n) => {
											let r = Number(n.target.value);
											Number.isInteger(r) && r >= 0 && r <= ye && t({
												type: "input",
												blue: r,
												start: e.start
											});
										}
									})]
								}),
								w.n === 32 && /* @__PURE__ */ V("label", {
									className: "tt-input-label",
									children: [i("games.turingtumble.releaseColor"), /* @__PURE__ */ V("select", {
										value: e.start,
										onChange: (n) => t({
											type: "input",
											blue: e.balls[0],
											start: n.target.value
										}),
										children: [/* @__PURE__ */ B("option", {
											value: "blue",
											children: i("games.turingtumble.blue")
										}), /* @__PURE__ */ B("option", {
											value: "red",
											children: i("games.turingtumble.red")
										})]
									})]
								})
							] })]
						})
					})
				]
			})
		})
	});
}
//#endregion
//#region src/games/turingtumble/guide.tsx
function rn() {
	let e = c();
	return /* @__PURE__ */ V("div", { children: [
		/* @__PURE__ */ B("div", {
			className: "grid grid-cols-3 gap-3 py-3",
			children: Se.map((t) => /* @__PURE__ */ V("div", {
				className: "flex flex-col items-center text-center text-xs",
				children: [/* @__PURE__ */ B("div", {
					className: "h-16 w-16",
					children: /* @__PURE__ */ B(Ht, {
						kind: t,
						right: !0
					})
				}), e(de[t])]
			}, t))
		}),
		/* @__PURE__ */ B("p", {
			className: "text-xs leading-relaxed",
			children: e("games.turingtumble.sourceAttribution")
		}),
		/* @__PURE__ */ B("p", {
			className: "text-xs leading-relaxed",
			children: e("games.turingtumble.geometryAttribution")
		})
	] });
}
//#endregion
//#region src/games/turingtumble/locales/zh.ts
var an = {
	name: "图灵反转",
	desc: "单人机械解谜：搭建零件，让钢珠完成六十道挑战",
	rules: "目标：\n· 利用给定零件完成当前关卡的目标。\n搭建：\n· 点击零件托盘，可在底部翻转朝向，再连续点击空安装位放置。\n· 再次点击当前托盘、点击取消或按 Esc 结束放置；库存耗尽时自动结束。\n· 点击已放零件，在旁边移动、翻转或移除；撤销位于盘面右下方，每次撤销一个操作。\n· 带固定标记的零件不能移动或移除。\n· 可变输入的方向和蓝球数量可在启动前调整。\n运行：\n· 启动后可暂停、停止或调整速度；停止后保留摆放并恢复初始形态。\n· 球到达底部触发点后，该侧导轨和上方出口短暂亮起；蓝色触发点释放蓝球仓中的下一球，红色触发点释放红球仓中的下一球。\n· 目标顺序逐球核对，正确时打勾，错误时立即停止。\n· 拖动盘面平移，双指或缩放按钮调整大小。\n· 每颗球必须连续经过零件，不能越过空安装位。\n· 拦截器留住球；位元件受球推动后改变方向。\n· 齿轮连接的位元件一起转动，斜坡通过后复位。\n过关：\n· 输出顺序、捕获位置和寄存器结果须满足题目。\n· 任意初态题须通过所有有效输入；向左为 0，向右为 1。\n· 寄存器标签 1、2、4、8 表示各位的权重。\n· 第 59 关每回合取 1—3 个球，取最后一个者输。",
	ramp: "斜坡",
	crossover: "交叉件",
	bit: "位元件",
	interceptor: "拦截器",
	gearbit: "齿轮位元件",
	gear: "齿轮",
	level: "第 {{n}} 关",
	challenge: "关卡",
	levels: "选择关卡",
	build: "搭建中",
	running: "运行中",
	paused: "已暂停",
	checking: "验证输入 {{n}} / {{total}}",
	passed: "挑战完成",
	failed: "未达成目标",
	start: "启动",
	pause: "暂停",
	resume: "继续",
	stop: "停止",
	speed: "运行速度",
	edit: "返回搭建",
	reset: "重置关卡",
	resetConfirm: "重置本关的全部搭建？",
	cancel: "取消",
	confirm: "重置",
	move: "移动",
	flip: "翻转",
	flipPlacement: "翻转待放零件",
	remove: "移除",
	undo: "撤销",
	zoom: "缩放",
	zoomIn: "放大",
	zoomOut: "缩小",
	fit: "适应盘面",
	close: "关闭",
	next: "下一关",
	back: "返回盘面",
	available: "可用零件",
	selected: "组件操作",
	place: "选择安装位",
	fixed: "固定零件",
	input: "输入设置",
	blueCount: "蓝球数量",
	releaseColor: "首个放球颜色",
	blue: "蓝球",
	red: "红球",
	output: "输出顺序",
	required: "目标顺序",
	sequenceDone: "第 {{n}} 颗，{{color}}，已完成",
	sequencePending: "第 {{n}} 颗，{{color}}",
	sequenceError: "第 {{n}} 颗，应为{{color}}，输出错误",
	wrongOutput: "第 {{n}} 颗应为{{color}}。",
	extraOutput: "输出了多余的球。",
	missingOutput: "第 {{n}} 颗球尚未输出。",
	remaining: "球仓剩余",
	invalid: "当前无法执行此操作。",
	gap: "钢珠越过了空安装位，请补齐路径。",
	escaped: "钢珠离开了盘面，请调整路径。",
	stalled: "钢珠被卡住了，请调整零件。",
	goal: "运行结果未满足本关目标。",
	nimLost: "你取走了最后一个球。",
	release: "放出一个球",
	endTurn: "结束回合",
	yourTurn: "你的回合 · 已取 {{n}} / 3",
	machineTurn: "机器的回合",
	completed: "已完成 {{n}} / 60",
	left: "向左",
	right: "向右",
	inputDirection: "{{part}} · {{direction}}",
	board: "机械盘面",
	saved: "进度保存在此设备",
	checkFailed: "有一组输入未通过，请检查盘面。",
	fullInputs: "验证全部输入",
	choosePart: "选择零件",
	empty: "尚未输出",
	turn: "改变初始方向",
	goalDetails: "关卡目标",
	sourceAttribution: "题目改编自 Turing Tumble LLC（2019）练习册，依 CC BY-NC-SA 4.0 许可使用。",
	geometryAttribution: "零件轮廓参考 Jesse Crossen 的 ttsim，采用 Unlicense 许可。",
	c1Title: "重力",
	c1Goal: "让所有蓝球到达底部，红球留在球仓。",
	c2Title: "重返",
	c2Goal: "让所有蓝球到达底部，红球留在球仓。",
	c3Title: "点火",
	c3Goal: "先放出一个蓝球，再放出所有红球。",
	c4Title: "聚变",
	c4Goal: "先放出一个红球，再放出所有蓝球。",
	c5Title: "熵",
	c5Goal: "依次输出蓝、红、蓝、红，持续交替。",
	c6Title: "全内反射",
	c6Goal: "依次输出蓝、红、蓝、红，持续交替。",
	c7Title: "阻力最小的路径",
	c7Goal: "只用六个斜坡，让所有蓝球到达底部。",
	c8Title: "去极化",
	c8Goal: "依次输出蓝、红、蓝、红，持续交替。",
	c9Title: "二聚体",
	c9Goal: "依次输出蓝、蓝、红，重复这一顺序。",
	c10Title: "双键",
	c10Goal: "依次输出蓝、蓝、红、红，重复这一顺序。",
	c11Title: "选择性",
	c11Goal: "将编号 2 和 5 的位元件转向右侧，其余编号位元件保持向左。",
	c12Title: "二元性（一）",
	c12Goal: "用拦截器捕获一个蓝球。",
	c13Title: "二元性（二）",
	c13Goal: "用拦截器捕获一个红球。",
	c14Title: "二元性（三）",
	c14Goal: "A 最初向左时捕获蓝球，最初向右时捕获红球。",
	c15Title: "反转",
	c15Goal: "A 最初向左时捕获蓝球，最初向右时捕获红球。",
	c16Title: "终止",
	c16Goal: "让三个蓝球到达底部，并拦截第四个蓝球。",
	c17Title: "固定比例",
	c17Goal: "依次输出三个蓝球、三个红球。",
	c18Title: "纠缠（一）",
	c18Goal: "上下两个位元件最初均向右时，将球送入 T；否则送入 F。",
	c19Title: "纠缠（二）",
	c19Goal: "上下两个位元件最初均向右时捕获蓝球，否则捕获红球。",
	c20Title: "共生",
	c20Goal: "上下两个位元件最初至少一个向右时捕获蓝球，否则捕获红球。",
	c21Title: "量子数",
	c21Goal: "用寄存器 A 记录蓝球数量，适用于 0—15 个蓝球。",
	c22Title: "耗减",
	c22Goal: "A 从 15 开始，减去蓝球数量，适用于 0—15 个蓝球。",
	c23Title: "四重奏",
	c23Goal: "让四个蓝球到达底部，并拦截第五个蓝球。",
	c24Title: "九重奏",
	c24Goal: "让九个蓝球到达底部，并拦截第十个蓝球。",
	c25Title: "正则表达式",
	c25Goal: "按图示顺序输出六个蓝球、三个红球。",
	c26Title: "原子核",
	c26Goal: "按图示顺序输出四个蓝球、一个红球、四个蓝球。",
	c27Title: "镜像",
	c27Goal: "无论初始方向如何，都将九个位元件各翻转一次。",
	c28Title: "锁存",
	c28Goal: "只放出蓝球，将红球留在球仓。",
	c29Title: "单次切换",
	c29Goal: "先输出蓝球、红球，再输出其余蓝球。",
	c30Title: "溢出",
	c30Goal: "用 A 记录蓝球数量；超过 7 时，OV 转向右侧并保持。",
	c31Title: "监督学习",
	c31Goal: "控制件 A 向左时用寄存器 A 计数，向右时用寄存器 B 计数。",
	c32Title: "置位与复位",
	c32Goal: "无论 A 初始方向如何，蓝球使其向左，红球使其向右。",
	c33Title: "传送",
	c33Goal: "将 A 的方向复制到 B，保持 A 最终方向不变。",
	c34Title: "互斥",
	c34Goal: "A、B 初始方向不同时捕获蓝球，否则捕获红球。",
	c35Title: "泡利不相容",
	c35Goal: "A 为偶数时捕获蓝球，为奇数时捕获红球。",
	c36Title: "信息论",
	c36Goal: "A、B 最初均向右时捕获蓝球，否则捕获红球。",
	c37Title: "求和",
	c37Goal: "计算 A＋B 并存入 B；溢出时捕获红球，否则捕获蓝球。",
	c38Title: "串行化",
	c38Goal: "从低位到高位输出 A：0 为红球，1 为蓝球；忽略首个蓝球。",
	c39Title: "三重奏",
	c39Goal: "依次输出蓝、蓝、蓝、红，重复这一顺序。",
	c40Title: "自组装",
	c40Goal: "将蓝球数量乘以 4 并存入 A，适用于 0—7 个蓝球。",
	c41Title: "硬复位",
	c41Goal: "无论 A 初值如何，只放出一个蓝球就将 A 清零。",
	c42Title: "轨道",
	c42Goal: "A 大于 B 时捕获蓝球，否则捕获红球。",
	c43Title: "抗磁性",
	c43Goal: "A、B 初始方向不同时捕获蓝球，否则捕获红球。",
	c44Title: "侵蚀",
	c44Goal: "计算 B－A 并存入 B，初值须满足 A≤B。",
	c45Title: "活化能",
	c45Goal: "A≤B 时捕获蓝球，否则捕获红球。",
	c46Title: "分配",
	c46Goal: "无论初始方向如何，都将五个位元件各翻转一次。",
	c47Title: "叠加",
	c47Goal: "计算 A＋B 并存入 B。",
	c48Title: "中间层",
	c48Goal: "将 A 乘以 3 并存入 B，A 的范围为 0—5。",
	c49Title: "悖论（一）",
	c49Goal: "按图示顺序输出钢珠。",
	c50Title: "悖论（二）",
	c50Goal: "球仓沿用上一关的输出顺序，生成图示顺序。",
	c51Title: "悖论（三）",
	c51Goal: "球仓沿用上一关的输出顺序，生成图示顺序。",
	c52Title: "外逸层",
	c52Goal: "将 A 乘以 5 并存入 B。",
	c53Title: "指数增长",
	c53Goal: "每个蓝球使 A 翻倍，超出寄存器的高位舍去。",
	c54Title: "解码器",
	c54Goal: "将 A 指定编号的位元件转向右侧。",
	c55Title: "分解",
	c55Goal: "将 A 除以 3，把整数商存入 B，舍去余数。",
	c56Title: "完整乘法",
	c56Goal: "在 A×B≤7 的范围内，计算 A×B，并将结果存入 C。",
	c57Title: "编码器",
	c57Goal: "将向右斜坡的编号存入 A；三个斜坡均向左表示 0。",
	c58Title: "方阵",
	c58Goal: "按图示顺序输出钢珠。",
	c59Title: "尼姆博士",
	c59Goal: "与机器轮流取 1—3 个球，取走最后一个球的一方输。你先行动。",
	c60Title: "比较器",
	c60Goal: "A<B 时送入 L，A=B 时送入 E，A>B 时送入 G。"
}, on = {
	name: "Turing Tumble",
	desc: "Solo mechanical puzzles: build a marble computer across 60 challenges",
	rules: "Goal:\n· Use the available parts to meet the challenge.\nBuild:\n· Select a tray part, flip its direction at the bottom if needed, then tap empty mounting points to place several parts.\n· Tap the selected tray again, choose Cancel, or press Esc to finish placing. Placement ends automatically when stock runs out.\n· Select a placed part to move, flip, or remove beside it. Undo is at the bottom right and reverses one action at a time.\n· Parts with a fixed marker cannot be moved or removed.\n· Adjust variable directions and blue ball counts before running.\nRun:\n· Start, pause, stop, or change speed. Stopping restores the initial shapes and keeps the build.\n· At a receiver, the rail and matching outlet light briefly. The blue receiver releases the next ball from the blue reservoir; the red receiver releases from the red reservoir.\n· Each output is checked against the target: a match earns a check; a mismatch stops the run immediately.\n· Drag to pan. Pinch or use the zoom buttons to resize the board.\n· Every ball must follow a continuous path of parts, without gaps.\n· Interceptors hold balls; a passing ball changes a bit’s direction.\n· Connected gear bits turn together; ramps return after use.\nPass:\n· Meet the required output, capture, and register conditions.\n· Variable challenges must pass every valid input: left is 0, right is 1.\n· Register labels 1, 2, 4, 8 give the binary place values.\n· In challenge 59, take 1–3 balls per turn; taking the last loses.",
	ramp: "Ramp",
	crossover: "Crossover",
	bit: "Bit",
	interceptor: "Interceptor",
	gearbit: "Gear bit",
	gear: "Gear",
	level: "Challenge {{n}}",
	challenge: "Challenge",
	levels: "Choose challenge",
	build: "Building",
	running: "Running",
	paused: "Paused",
	checking: "Checking {{n}} / {{total}}",
	passed: "Challenge complete",
	failed: "Goal not met",
	start: "Start",
	pause: "Pause",
	resume: "Resume",
	stop: "Stop",
	speed: "Speed",
	edit: "Back to build",
	reset: "Reset challenge",
	resetConfirm: "Reset the entire build for this challenge?",
	cancel: "Cancel",
	confirm: "Reset",
	move: "Move",
	flip: "Flip",
	flipPlacement: "Flip the next part",
	remove: "Remove",
	undo: "Undo",
	zoom: "Zoom",
	zoomIn: "Zoom in",
	zoomOut: "Zoom out",
	fit: "Fit board",
	close: "Close",
	next: "Next",
	back: "Back to board",
	available: "Available parts",
	selected: "Part actions",
	place: "Choose a mounting point",
	fixed: "Fixed part",
	input: "Input settings",
	blueCount: "Blue ball count",
	releaseColor: "First ball",
	blue: "Blue",
	red: "Red",
	output: "Output",
	required: "Target",
	sequenceDone: "Ball {{n}}, {{color}}, complete",
	sequencePending: "Ball {{n}}, {{color}}",
	sequenceError: "Ball {{n}}, expected {{color}}, incorrect output",
	wrongOutput: "Ball {{n}} should be {{color}}.",
	extraOutput: "An extra ball reached the output.",
	missingOutput: "Ball {{n}} has not reached the output.",
	remaining: "Reservoirs",
	invalid: "This action is not available now.",
	gap: "A ball crossed a gap. Complete its path.",
	escaped: "A ball left the board. Adjust its path.",
	stalled: "A ball is stuck. Adjust the parts.",
	goal: "The result does not meet this challenge’s goal.",
	nimLost: "You took the last ball.",
	release: "Release one ball",
	endTurn: "End turn",
	yourTurn: "Your turn · {{n}} / 3 taken",
	machineTurn: "Machine’s turn",
	completed: "Completed {{n}} / 60",
	left: "Left",
	right: "Right",
	inputDirection: "{{part}} · {{direction}}",
	board: "Mechanical board",
	saved: "Progress is saved on this device",
	checkFailed: "An input failed. Inspect the board.",
	fullInputs: "Check all inputs",
	choosePart: "Choose a part",
	empty: "No output yet",
	turn: "Change initial direction",
	goalDetails: "Challenge goal",
	sourceAttribution: "Challenges adapted from the Turing Tumble LLC workbook (2019), under CC BY-NC-SA 4.0.",
	geometryAttribution: "Part outlines based on Jesse Crossen’s ttsim, released under the Unlicense.",
	c1Title: "Gravity",
	c1Goal: "Make all of the blue balls (and only the blue balls) reach the end.",
	c2Title: "Re-entry",
	c2Goal: "Make all of the blue balls (and only the blue balls) reach the end.",
	c3Title: "Ignition",
	c3Goal: "Release one blue ball and then all of the red balls.",
	c4Title: "Fusion",
	c4Goal: "Release one red ball and then all of the blue balls.",
	c5Title: "Entropy",
	c5Goal: "Make the pattern blue, red, blue, red, blue, red...",
	c6Title: "Total Internal Reflection",
	c6Goal: "Make the pattern blue, red, blue, red, blue, red...",
	c7Title: "Path of Least Resistance",
	c7Goal: "Create a path for the blue balls to reach the output with only 6 ramps.",
	c8Title: "Depolarization",
	c8Goal: "Make the pattern blue, red, blue, red, blue, red...",
	c9Title: "Dimers",
	c9Goal: "Make the pattern blue, blue, red, blue, blue, red...",
	c10Title: "Double Bond",
	c10Goal: "Make the pattern blue, blue, red, red, blue, blue, red, red...",
	c11Title: "Selectivity",
	c11Goal: "Flip bits 2 and 5 to the right. See the puzzle book for further details.",
	c12Title: "Duality",
	c12Goal: "Intercept a blue ball.",
	c13Title: "Duality - Part 2",
	c13Goal: "Intercept a red ball.",
	c14Title: "Duality - Part 3",
	c14Goal: "If the machine starts with bit A pointing to the left, intercept a blue ball. Otherwise, intercept a red ball. See the puzzle book for further details.",
	c15Title: "Inversion",
	c15Goal: " If bit A starts to the left, intercept a blue ball. If bit A starts to the right, intercept a red ball. See the puzzle book for further details.",
	c16Title: "Termination",
	c16Goal: "Let only 3 blue balls reach the bottom and catch the 4th ball in the interceptor.",
	c17Title: "Fixed Ratio",
	c17Goal: "Make the pattern blue, blue, blue, red, red, red.",
	c18Title: "Entanglement",
	c18Goal: " If the top bit AND the bottom bit start pointed to the right, put a ball in interceptor T. Otherwise put a ball in interceptor F. See the puzzle book for further details.",
	c19Title: "Entanglement",
	c19Goal: "If the top bit AND the bottom bit start pointed to the right, intercept a blue ball. Otherwise, intercept a red ball.",
	c20Title: "Symbiosis",
	c20Goal: "If the top bit OR the bottom bit start pointed to the right, intercept a blue ball. Otherwise, intercept a red ball.",
	c21Title: "Quantum Number",
	c21Goal: " Use register A to count the number of blue balls. (Use 15 or fewer balls.) See the puzzle book for further details. See the puzzle book for further details.",
	c22Title: "Depletion",
	c22Goal: "Register A starts at 15. Subtract the number of blue balls from the register. (Use 15 or fewer balls.) See the puzzle book for further details.",
	c23Title: "Tetrad",
	c23Goal: "Let exactly 4 blue balls reach the end. (Intercept the 5th.)",
	c24Title: "Ennead",
	c24Goal: "Let exactly 9 blue balls reach the end. (Intercept the 10th.)",
	c25Title: "Regular Expression",
	c25Goal: "Generate the required pattern.",
	c26Title: "Nucleus",
	c26Goal: "Generate the required pattern.",
	c27Title: "Reflection",
	c27Goal: "Reverse the direction of each of the 9 starting bits, regardless of the direction they point to start.",
	c28Title: "Latch",
	c28Goal: "Release only the blue balls.",
	c29Title: "One Shot Switch",
	c29Goal: "Release a blue ball, a red ball, and then the rest of the blue balls.",
	c30Title: "Overflow",
	c30Goal: "Count the blue balls in register A. If there are more than 7, gear bit OV must flip right (and stay right) to indicate the overflow. See the puzzle book for further details.",
	c31Title: "Supervised Learning",
	c31Goal: "If gear bit A points left, count all blue balls in register A. Otherwise count them in register B.",
	c32Title: "Set Reset",
	c32Goal: "For either starting direction of A, set it left with a blue ball or right with a red ball.",
	c33Title: "Teleportation",
	c33Goal: "Copy the direction of gear bit A into B while preserving the final direction of A.",
	c34Title: "Exclusivity",
	c34Goal: "Intercept blue if A and B initially point in opposite directions; otherwise intercept red.",
	c35Title: "Pauli Exclusion",
	c35Goal: "Intercept blue if register A is even; otherwise intercept red.",
	c36Title: "Information Theory",
	c36Goal: "Intercept blue if A and B both initially point right; otherwise intercept red.",
	c37Title: "Summation",
	c37Goal: "Add A to B and store the result in B. Intercept red on overflow; otherwise intercept blue.",
	c38Title: "Serialization",
	c38Goal: "Output A from its lowest bit: zero is red and one is blue. Ignore the first blue ball.",
	c39Title: "Triplets",
	c39Goal: "Output blue, blue, blue, red repeatedly.",
	c40Title: "Self-Assembly",
	c40Goal: "Multiply the number of blue balls by 4 and record the result in A. Use 0–7 blue balls.",
	c41Title: "Hard Reset",
	c41Goal: "Set register A to zero after releasing just one blue ball, for every initial value.",
	c42Title: "Orbitals",
	c42Goal: "Intercept blue if A is greater than B; otherwise intercept red.",
	c43Title: "Diamagnetic",
	c43Goal: "Intercept blue if A and B initially point in opposite directions; otherwise intercept red.",
	c44Title: "Erosion",
	c44Goal: "Subtract A from B and store the result in B. Initially A must be no greater than B.",
	c45Title: "Activation Energy",
	c45Goal: "Intercept blue if A is less than or equal to B; otherwise intercept red.",
	c46Title: "Distribution",
	c46Goal: "Reverse each of the five starting bits, for every initial direction.",
	c47Title: "Superimposition",
	c47Goal: "Add A to B and store the result in B.",
	c48Title: "Mesosphere",
	c48Goal: "Multiply A by 3 and store the result in B. A must be between 0 and 5.",
	c49Title: "Paradox - 1",
	c49Goal: "Generate the required output pattern.",
	c50Title: "Paradox - 2",
	c50Goal: "Generate the next required output pattern. The reservoirs start in the order produced by the previous challenge.",
	c51Title: "Paradox - 3",
	c51Goal: "Generate the next required output pattern. The reservoirs start in the order produced by the previous challenge.",
	c52Title: "Exosphere",
	c52Goal: "Multiply A by 5 and store the result in B.",
	c53Title: "Exponential Growth",
	c53Goal: "Each blue ball doubles A. Discard any bits that overflow.",
	c54Title: "Decoder",
	c54Goal: "Turn the bit numbered by A to the right.",
	c55Title: "Dissection",
	c55Goal: "Divide A by 3 and store the integer quotient in B. Ignore the remainder.",
	c56Title: "Complete Multiplication",
	c56Goal: "For A × B ≤ 7, multiply A by B and store the result in C.",
	c57Title: "Encoder",
	c57Goal: "Record in A the number of the ramp pointing right. Leave all three ramps left to encode zero.",
	c58Title: "Square Matrix",
	c58Goal: "Generate the required output pattern.",
	c59Title: "Dr. Nim",
	c59Goal: "Take turns removing 1–3 balls. Whoever takes the last ball loses. You play first.",
	c60Title: "Comparator",
	c60Goal: "Catch a ball in L if A < B, E if A = B, or G if A > B."
};
//#endregion
//#region .bgparty/cache/pack-entry/turingtumble/entry.tsx
await H();
var sn = {
	definition: ot,
	View: tn,
	Guide: rn,
	locales: {
		zh: an,
		en: on
	}
};
//#endregion
export { sn as default };
