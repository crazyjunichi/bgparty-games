import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { CANVAS_SIZE as n, PALETTE as r, STROKE_WIDTHS as i, strokeSchema as a } from "@bgparty/sdk/drawing/strokes";
import { Fragment as o, useEffect as s, useRef as c, useState as l } from "react";
import { useT as u } from "@bgparty/sdk/i18n";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as f } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { DrawingPad as m } from "@bgparty/sdk/drawing/canvas";
import { DrawingView as h } from "@bgparty/sdk/drawing/view";
import { jsx as g, jsxs as _ } from "react/jsx-runtime";
import { AVATARS as v } from "@bgparty/sdk/avatars";
import { BottomSheet as y } from "@bgparty/sdk/bottom-sheet";
import { IconDown as b } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as x } from "@bgparty/sdk/player-colors";
import { Confetti as S } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as C, OptionSection as ee } from "@bgparty/sdk/ui/game-options";
//#region src/games/telestrations/meta.ts
var w = {
	id: "telestrations",
	tier: "released",
	mechanics: ["drawing", "word-association"],
	interactionTags: [],
	nameKey: "games.telestrations.name",
	descKey: "games.telestrations.desc",
	rulesKey: "games.telestrations.rules",
	icon: "🎨",
	iconImg: "games/telestrations.webp",
	rulesUrl: { en: "https://cdn.shopify.com/s/files/1/0611/3958/3198/files/Compressed_Telestrations_8P_Rules_2025-1.pdf?v=1749053807" },
	minPlayers: 3,
	maxPlayers: 8,
	bestPlayers: [8],
	accent: "#c026d3",
	releasedAt: "2026-09-11",
	search: {
		py: "chuan qing hua yi",
		init: "cqhy"
	},
	hotseat: "cover"
}, T = t.object({
	kind: t.literal("word"),
	text: t.string().max(30),
	by: t.string()
}), te = t.object({
	kind: t.literal("drawing"),
	strokes: t.array(a).max(200),
	by: t.string()
}), E = t.discriminatedUnion("kind", [T, te]), D = t.discriminatedUnion("type", [t.object({
	type: t.literal("submit"),
	entry: t.discriminatedUnion("kind", [t.object({
		kind: t.literal("word"),
		text: t.string().trim().min(1).max(30)
	}), t.object({
		kind: t.literal("drawing"),
		strokes: t.array(a).min(1).max(200)
	})])
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), ne = [
	0,
	60,
	90,
	120
], O = t.object({ timeLimitSec: t.union([
	t.literal(0),
	t.literal(60),
	t.literal(90),
	t.literal(120)
]).default(0) }).default({ timeLimitSec: 0 }), k = t.string(), A = t.object({
	phase: t.enum(["play", "done"]),
	round: t.int().min(0),
	totalRounds: t.int().min(2),
	mode: t.enum(["draw", "guess"]),
	players: t.array(k),
	submitted: t.array(k),
	timeLimitSec: t.int(),
	books: t.array(t.object({ entries: t.array(E) }))
}), j = t.object({
	bookOwner: k,
	entry: E,
	mySubmitted: t.boolean()
}), M = /* @__PURE__ */ "猫.狗.兔子.大象.长颈鹿.狮子.老虎.熊猫.猴子.企鹅.鸭子.青蛙.蛇.乌龟.金鱼.鲨鱼.鲸鱼.章鱼.螃蟹.蝴蝶.蜜蜂.蚂蚁.蜘蛛.蜗牛.恐龙.孔雀.猫头鹰.鹦鹉.袋鼠.松鼠.刺猬.河马.鳄鱼.骆驼.绵羊.奶牛.马.公鸡.猪.老鼠.狐狸.狼.熊.树懒.火烈鸟.海马.水母.龙虾.蝙蝠.苹果.香蕉.西瓜.葡萄.草莓.菠萝.橙子.樱桃.蘑菇.胡萝卜.玉米.茄子.辣椒.西红柿.火锅.汉堡.披萨.热狗.三明治.饺子.包子.面条.蛋糕.冰淇淋.甜甜圈.棒棒糖.爆米花.薯条.寿司.烧烤.奶茶.咖啡.啤酒.煎蛋.月饼.粽子.糖葫芦.巧克力.雨伞.眼镜.帽子.手表.书包.钥匙.剪刀.牙刷.镜子.梳子.灯笼.气球.风筝.蜡烛.台灯.闹钟.电话.电视.冰箱.洗衣机.电风扇.沙发.床.马桶.水龙头.电梯.汽车.自行车.公交车.火车.飞机.轮船.火箭.直升机.摩托车.红绿灯.桥.灯塔.城堡.帐篷.太阳.月亮.星星.彩虹.闪电.火山.仙人掌.椰子树.河流.沙滩.瀑布.雪人.医生.警察.老师.厨师.消防员.超人.公主.国王.海盗.宇航员.机器人.外星人.幽灵.圣诞老人.天使.小丑.魔术师.跑步.游泳.跳绳.踢足球.打篮球.钓鱼.露营.野餐.洗澡.刷牙.睡觉.打喷嚏.唱歌.跳舞.弹吉他.打鼓.画画.拍照.滑雪.冲浪.划船.爬山.过生日".split("."), N = (e) => e % 2 == 0 ? e : e - 1, P = (e) => e % 2 == 0 ? "draw" : "guess";
function F(t, n, r) {
	let i = [...r];
	for (let r = i.length - 1; r > 0; --r) {
		let a = e(t, n, r + 1);
		n += 1;
		let o = i[r];
		i[r] = i[a], i[a] = o;
	}
	return {
		out: i,
		cursor: n
	};
}
function I(e, t, n) {
	let r = F(n, 0, t), i = F(n, r.cursor, M);
	return { state: {
		players: r.out,
		books: r.out.map((e, t) => ({ entries: [{
			kind: "word",
			text: i.out[t],
			by: ""
		}] })),
		round: 0,
		submitted: [],
		config: e,
		roundStartedAt: null,
		phase: "play"
	} };
}
function L(e, t) {
	let n = e.players.length;
	return (e.players.indexOf(t) - e.round + n * 2) % n;
}
function R(e) {
	e.round += 1, e.submitted = [], e.roundStartedAt = null, e.round >= N(e.players.length) && (e.phase = "done");
}
function z(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "play" || e.config.timeLimitSec === 0) return { state: e };
		if (e.roundStartedAt === null) {
			let n = structuredClone(e);
			return n.roundStartedAt = t.now, { state: n };
		}
		if (t.now - e.roundStartedAt < e.config.timeLimitSec * 1e3) return { state: e };
		let n = structuredClone(e), r = P(n.round);
		for (let e of n.players) {
			if (n.submitted.includes(e)) continue;
			let t = r === "draw" ? {
				kind: "drawing",
				strokes: [],
				by: e
			} : {
				kind: "word",
				text: "",
				by: e
			};
			n.books[L(n, e)].entries.push(t);
		}
		return R(n), { state: n };
	}
	if (e.phase !== "play") return { code: "games.telestrations.errNotPlaying" };
	if (e.submitted.includes(n.by)) return { code: "games.telestrations.errAlreadySubmitted" };
	let r = P(e.round);
	if (r === "draw" && t.entry.kind !== "drawing") return { code: "games.telestrations.errNeedDrawing" };
	if (r === "guess" && t.entry.kind !== "word") return { code: "games.telestrations.errNeedWord" };
	let i = structuredClone(e);
	return i.books[L(i, n.by)].entries.push({
		...t.entry,
		by: n.by
	}), i.submitted.push(n.by), i.submitted.length === i.players.length && R(i), { state: i };
}
function B(e, t) {
	let n = {
		phase: e.phase,
		round: e.round,
		totalRounds: N(e.players.length),
		mode: P(e.round),
		players: [...e.players],
		submitted: [...e.submitted],
		timeLimitSec: e.config.timeLimitSec,
		books: e.phase === "done" ? structuredClone(e.books) : []
	};
	if (e.phase === "done") return { public: n };
	let r = L(e, t), i = e.books[r];
	return {
		public: n,
		private: {
			bookOwner: e.players[r],
			entry: i.entries[i.entries.length - 1],
			mySubmitted: e.submitted.includes(t)
		}
	};
}
function V(e) {
	return e.phase === "done" ? {
		phase: "done",
		winner: [...e.players],
		ranking: [...e.players]
	} : { phase: e.phase };
}
function H(e, t) {
	return e.phase !== "play" || e.config.timeLimitSec === 0 ? null : e.roundStartedAt === null ? 0 : e.roundStartedAt + e.config.timeLimitSec * 1e3 - t;
}
var U = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: w,
	schemas: {
		action: D,
		publicView: A,
		privateView: j,
		config: O
	},
	setup: I,
	reduce: z,
	viewFor: B,
	status: V,
	nextTickIn: H
};
//#endregion
//#region src/games/telestrations/board.tsx
function W() {
	let e = c(null), [t, n] = l({
		size: 0,
		toolbarHeight: 52
	});
	return s(() => {
		let t = e.current;
		if (!t) return;
		let r = () => {
			let e = Number.parseFloat(getComputedStyle(t).getPropertyValue("--telestrations-toolbar-h")) || 52, r = Math.max(0, Math.floor(Math.min(t.clientWidth - 8, t.clientHeight - e - 8)));
			n((t) => t.size === r && t.toolbarHeight === e ? t : {
				size: r,
				toolbarHeight: e
			});
		}, i = new ResizeObserver(r);
		return i.observe(t), r(), () => i.disconnect();
	}, []), {
		ref: e,
		...t
	};
}
function G({ width: e }) {
	let t = Math.max(5, Math.round(e / 40));
	return /* @__PURE__ */ g("div", {
		"aria-hidden": !0,
		className: "pointer-events-none absolute inset-x-3 top-0 z-10 flex -translate-y-1/2 justify-between",
		children: Array.from({ length: t }, (e, t) => /* @__PURE__ */ g("span", { className: "block h-4 w-2 rounded-full border-2 border-ink bg-surface" }, t))
	});
}
function K({ size: e, children: t }) {
	return /* @__PURE__ */ _("div", {
		className: "telestrations-paper relative mx-auto flex-none",
		style: {
			width: e,
			maxWidth: "100%"
		},
		children: [/* @__PURE__ */ g("div", {
			className: "frame relative overflow-hidden p-1",
			style: {
				width: "100%",
				height: typeof e == "number" ? e : void 0,
				aspectRatio: "1"
			},
			children: t
		}), /* @__PURE__ */ g(G, { width: typeof e == "number" ? e : 600 })]
	});
}
//#endregion
//#region src/games/telestrations/view-player.tsx
function q(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ g(J, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function J({ pub: e, priv: t, members: n, myRid: r, send: i }) {
	let a = u(), o = (e) => n.find((t) => t.rid === e)?.name ?? e, s = e.players.map((e) => n.find((t) => t.rid === e)).filter((e) => e !== void 0), c = t?.mySubmitted ?? !1, l, m;
	return c ? (l = "info", m = a("games.telestrations.waitingOthers", {
		n: e.submitted.length,
		total: e.players.length
	})) : e.mode === "draw" ? (l = "accent", m = a("games.telestrations.drawPrompt")) : (l = "accent", m = a("games.telestrations.guessPrompt")), /* @__PURE__ */ g(p, {
		adaptive: !0,
		scroll: !1,
		className: "telestrations-screen",
		banner: /* @__PURE__ */ _("div", {
			className: "telestrations-banner",
			children: [/* @__PURE__ */ g(d, {
				tone: l,
				text: m,
				sub: t ? t.bookOwner === r ? a("games.telestrations.ownerSelf") : a("games.telestrations.ownerFrom", { name: o(t.bookOwner) }) : void 0,
				chip: a("games.telestrations.roundShort", {
					n: e.round + 1,
					total: e.totalRounds
				}),
				accent: w.accent
			}), /* @__PURE__ */ _("div", {
				className: "telestrations-progress",
				children: [/* @__PURE__ */ g("div", {
					className: "min-w-0 flex-1",
					children: /* @__PURE__ */ g(f, {
						adaptive: !0,
						scroll: !0,
						variant: "mini",
						members: s,
						myRid: r
					})
				}), e.timeLimitSec > 0 && /* @__PURE__ */ g(Y, { limitSec: e.timeLimitSec }, e.round)]
			})]
		}),
		children: t && /* @__PURE__ */ g(X, {
			pub: e,
			priv: t,
			send: i
		}, e.round)
	});
}
function Y({ limitSec: e }) {
	let [t, n] = l(e);
	return s(() => {
		let e = window.setInterval(() => n((e) => Math.max(0, e - 1)), 1e3);
		return () => window.clearInterval(e);
	}, []), /* @__PURE__ */ _("span", {
		className: `telestrations-countdown flex h-9 flex-none items-center rounded-xl border-2 border-ink px-2 font-mono text-sm font-extrabold tabular-nums ${t <= 10 ? "bg-warn-soft text-warn-ink" : "bg-surface"}`,
		children: ["⏱", t]
	});
}
function X({ pub: e, priv: t, send: n }) {
	let r = u(), [i, a] = l([]), [o, s] = l(""), { ref: c, size: d, toolbarHeight: f } = W(), p = e.mode === "draw", v = t.entry.kind === "word" ? t.entry.text : "", y = t.entry.kind === "drawing" ? t.entry.strokes : [], b = o.trim();
	return /* @__PURE__ */ _("div", {
		className: "telestrations-round",
		children: [
			/* @__PURE__ */ g("div", {
				className: "telestrations-prompt-slot",
				children: p && /* @__PURE__ */ g("p", {
					className: "telestrations-word frame font-display font-extrabold",
					children: v
				})
			}),
			/* @__PURE__ */ g("div", {
				ref: c,
				className: "telestrations-board-stage",
				children: d > 0 && /* @__PURE__ */ g("div", {
					className: "telestrations-board-wrap",
					style: {
						width: d,
						height: d + f
					},
					children: p && !t.mySubmitted ? /* @__PURE__ */ _("div", {
						className: "telestrations-pad relative h-full w-full",
						children: [/* @__PURE__ */ g(m, {
							value: i,
							onChange: a
						}), /* @__PURE__ */ g(G, { width: d })]
					}) : /* @__PURE__ */ g(K, {
						size: d,
						children: p || y.length > 0 ? /* @__PURE__ */ g(h, {
							strokes: p ? i : y,
							className: "h-full w-full rounded-lg bg-white"
						}) : /* @__PURE__ */ g("div", {
							className: "grid h-full w-full place-items-center rounded-lg bg-white p-4",
							children: /* @__PURE__ */ g("p", {
								className: "telestrations-blank font-bold opacity-60",
								children: r("games.telestrations.blankDrawing")
							})
						})
					})
				})
			}),
			/* @__PURE__ */ g("div", {
				className: "telestrations-actions",
				children: t.mySubmitted ? !p && /* @__PURE__ */ g("p", {
					className: "telestrations-submitted frame font-display font-extrabold",
					children: o
				}) : p ? /* @__PURE__ */ g("button", {
					className: "telestrations-submit btn-base w-full cursor-pointer text-white disabled:opacity-40",
					style: { background: w.accent },
					disabled: i.length === 0,
					onClick: () => n({
						type: "submit",
						entry: {
							kind: "drawing",
							strokes: i
						}
					}),
					children: r("games.telestrations.submit")
				}) : /* @__PURE__ */ _("form", {
					className: "telestrations-guess",
					onSubmit: (e) => {
						e.preventDefault(), b && n({
							type: "submit",
							entry: {
								kind: "word",
								text: b
							}
						});
					},
					children: [/* @__PURE__ */ g("input", {
						value: o,
						onChange: (e) => s(e.target.value),
						maxLength: 30,
						placeholder: r("games.telestrations.guessPlaceholder"),
						"aria-label": r("games.telestrations.guessPlaceholder"),
						className: "telestrations-input min-w-0 rounded-xl border-2 border-ink bg-surface px-3 font-bold"
					}), /* @__PURE__ */ g("button", {
						type: "submit",
						className: "telestrations-submit btn-base cursor-pointer px-6 text-white disabled:opacity-40",
						style: { background: w.accent },
						disabled: !b,
						children: r("games.telestrations.submit")
					})]
				})
			})
		]
	});
}
//#endregion
//#region src/games/telestrations/bot.ts
var Z = (e) => crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e;
function re() {
	let e = [], t = 1 + Z(3);
	for (let a = 0; a < t; a += 1) {
		let t = [], a = 200 + Z(600), o = 200 + Z(600);
		t.push(a, o);
		let s = 4 + Z(8);
		for (let e = 0; e < s; e += 1) a = Math.max(0, Math.min(n, a + Z(301) - 150)), o = Math.max(0, Math.min(n, o + Z(301) - 150)), t.push(a, o);
		e.push({
			c: Z(r.length),
			w: Z(i.length),
			pts: t
		});
	}
	return e;
}
var Q = (e) => {
	let t = e.private;
	return e.public.phase !== "play" || !t || t.mySubmitted ? null : e.public.mode === "draw" ? { action: {
		type: "submit",
		entry: {
			kind: "drawing",
			strokes: re()
		}
	} } : { action: {
		type: "submit",
		entry: {
			kind: "word",
			text: M[Z(M.length)]
		}
	} };
};
//#endregion
//#region src/games/telestrations/game-over.tsx
function ie({ public: e, members: t, onPlayAgain: n, onBackToLobby: r }) {
	let i = u(), a = e, [s, c] = l(null), d = (e) => t.find((t) => t.rid === e)?.name ?? e, f = n ?? r;
	return /* @__PURE__ */ _("div", {
		className: "telestrations-final relative flex h-full min-h-0 flex-col items-center gap-2",
		children: [
			/* @__PURE__ */ g(S, {}),
			/* @__PURE__ */ _("h1", {
				className: "telestrations-final-title flex flex-none items-center gap-2 text-center font-display text-xl font-extrabold",
				children: [/* @__PURE__ */ g("span", {
					"aria-hidden": !0,
					children: "🎉"
				}), i("games.telestrations.endTitle")]
			}),
			/* @__PURE__ */ g("p", {
				className: "telestrations-final-sub flex-none text-sm opacity-70",
				children: i("games.telestrations.pickBook")
			}),
			/* @__PURE__ */ g("div", {
				className: "telestrations-books",
				children: a.books.map((e, n) => {
					let r = a.players[n], i = t.find((e) => e.rid === r), o = e.entries[0];
					return /* @__PURE__ */ _("button", {
						className: "telestrations-book card flex w-full cursor-pointer items-center gap-2 p-3 text-left",
						onClick: () => c(n),
						children: [/* @__PURE__ */ g("span", {
							className: "telestrations-book-word min-w-0 flex-1 font-display text-lg font-extrabold",
							children: o?.kind === "word" ? o.text : ""
						}), i && /* @__PURE__ */ g($, {
							name: i.name,
							avatar: i.avatar,
							colorIndex: i.colorIndex
						})]
					}, n);
				})
			}),
			f ? /* @__PURE__ */ _("div", {
				className: "telestrations-final-actions safe-b flex w-full flex-none flex-col gap-2 pb-1",
				children: [n && /* @__PURE__ */ g("button", {
					className: "btn-base w-full cursor-pointer text-white",
					style: { background: w.accent },
					onClick: n,
					children: i("session.result.playAgain")
				}), r && /* @__PURE__ */ g("button", {
					className: "btn-quiet w-full cursor-pointer",
					onClick: r,
					children: i("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ g("p", {
				className: "safe-b flex-none pb-1 text-sm font-bold opacity-70",
				children: i("session.result.waitHost")
			}),
			/* @__PURE__ */ g(y, {
				open: s !== null,
				onClose: () => c(null),
				label: i("games.telestrations.endTitle"),
				title: i("games.telestrations.endTitle"),
				tall: !0,
				children: s !== null && a.books[s] && /* @__PURE__ */ g("div", {
					className: "telestrations-chain flex w-full flex-col items-center gap-3",
					children: a.books[s].entries.map((e, n) => /* @__PURE__ */ _(o, { children: [n > 0 && /* @__PURE__ */ g("span", {
						"aria-hidden": !0,
						className: "-my-1.5 grid size-7 place-items-center rounded-full border-2 border-ink text-white shadow-[2px_2px_0_var(--color-ink)]",
						style: { background: w.accent },
						children: /* @__PURE__ */ g(b, { size: 14 })
					}), /* @__PURE__ */ g(ae, {
						entry: e,
						members: t,
						nameOf: d
					})] }, n))
				})
			})
		]
	});
}
function $({ name: e, avatar: t, colorIndex: n }) {
	let r = x[n % x.length];
	return /* @__PURE__ */ _("span", {
		className: "telestrations-owner flex items-center gap-1 rounded-full border-2 border-ink bg-surface py-0.5 pr-2 pl-0.5 text-xs font-bold",
		children: [/* @__PURE__ */ g("img", {
			src: v[t % v.length],
			alt: "",
			draggable: !1,
			className: "size-5 rounded-full object-contain",
			style: { backgroundColor: r.hex }
		}), /* @__PURE__ */ g("span", {
			className: "min-w-0 truncate",
			title: e,
			children: e
		})]
	});
}
function ae({ entry: e, members: t, nameOf: n }) {
	let r = u(), i = t.find((t) => t.rid === e.by), a = e.kind === "word" ? e.text === "" : e.strokes.length === 0, o = e.by === "" ? r("games.telestrations.entryOrigin") : a ? n(e.by) : e.kind === "word" ? r("games.telestrations.entryByGuess", { name: n(e.by) }) : r("games.telestrations.entryByDraw", { name: n(e.by) });
	return e.kind === "drawing" && e.strokes.length > 0 ? /* @__PURE__ */ g("div", {
		className: "telestrations-chain-drawing",
		children: /* @__PURE__ */ _(K, {
			size: "100%",
			children: [/* @__PURE__ */ g(h, {
				strokes: e.strokes,
				className: "h-full w-full rounded-lg bg-white"
			}), i && /* @__PURE__ */ g("span", {
				className: "absolute bottom-2 left-2",
				children: /* @__PURE__ */ g($, {
					name: i.name,
					avatar: i.avatar,
					colorIndex: i.colorIndex
				})
			})]
		})
	}) : /* @__PURE__ */ _("p", {
		className: "telestrations-chain-word frame flex w-full flex-col items-center gap-1 p-3 text-center",
		children: [e.kind === "word" && e.text !== "" ? /* @__PURE__ */ g("span", {
			className: "font-display text-xl font-extrabold",
			children: e.text
		}) : /* @__PURE__ */ g("span", {
			className: "text-sm font-bold opacity-60",
			children: r(e.kind === "word" ? "games.telestrations.blankWord" : "games.telestrations.blankDrawing")
		}), /* @__PURE__ */ g("span", {
			className: "text-xs font-bold opacity-60",
			children: o
		})]
	});
}
//#endregion
//#region src/games/telestrations/options.tsx
function oe({ value: e, onChange: t }) {
	let n = u(), r = O.safeParse(e), i = r.success ? r.data : O.parse(void 0);
	return /* @__PURE__ */ g("div", {
		className: "flex flex-col gap-2",
		children: /* @__PURE__ */ g(ee, {
			title: n("games.telestrations.optTimeLimit"),
			children: ne.map((e) => /* @__PURE__ */ g(C, {
				name: "telestrations-time-limit",
				value: String(e),
				checked: i.timeLimitSec === e,
				label: e === 0 ? n("games.telestrations.optOff") : n("games.telestrations.optSec", { n: e }),
				accent: w.accent,
				onChange: () => t({ timeLimitSec: e })
			}, e))
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/telestrations/entry.tsx
var se = {
	definition: U,
	View: q,
	bot: Q,
	OverView: ie,
	Options: oe,
	locales: {
		zh: {
			name: "传情画意",
			desc: "接力传画:画词猜画,看词一路歪成什么样",
			rules: "目标:没有胜负的聚会游戏,看一个初始词在接力传画中会变成什么。\n流程:\n· 每人一本画册,系统为每本分配一个初始词;传递顺序随机。\n· 所有人同时进行每一棒:画画与猜词交替——画出面前写着的词,或猜出面前这幅画画的是什么。\n· 第一棒恒为画画,最后一棒恒为猜词。\n· 所有玩家提交后，将所有画册同时传给各自的下一位玩家。主机可以为每次接力设置时间限制；倒计时结束后，尚未提交的画册也会按当前内容传出。\n结束:\n· 最后一棒结束后,可逐本回看每本画册的完整传递过程。",
			roundShort: "{{n}}/{{total}}",
			drawPrompt: "画一画这个词",
			guessPrompt: "这幅画是什么?",
			submit: "提交",
			waitingOthers: "已提交,等其他人 {{n}}/{{total}}…",
			guessPlaceholder: "写下你的猜测…",
			ownerSelf: "自己的画册",
			ownerFrom: "{{name}} 的画册",
			blankDrawing: "(超时没画)",
			blankWord: "(超时没猜)",
			optTimeLimit: "每棒限时",
			optOff: "不限时",
			optSec: "{{n}} 秒",
			endTitle: "画册回看",
			pickBook: "选一本画册,看词一路歪成什么样",
			entryOrigin: "系统出题",
			entryByDraw: "{{name}} 画的",
			entryByGuess: "{{name}} 猜的",
			errNotPlaying: "对局已结束",
			errAlreadySubmitted: "这一棒已提交",
			errNeedDrawing: "这一棒要画画",
			errNeedWord: "这一棒要猜词"
		},
		en: {
			name: "Telestrations",
			desc: "Pass-it-on drawing: draw the word, guess the drawing",
			rules: "Goal: a party game with no winner — watch what a starting word becomes after a relay of drawing and guessing.\nPlay:\n· Everyone holds a sketchbook, and the system assigns each book a starting word; the passing order is shuffled.\n· All players work on every step at the same time, and drawing alternates with guessing: draw the word in front of you, or guess what the drawing in front of you shows.\n· The first step is always drawing and the last step is always guessing.\n· Books pass to the next player only when everyone has submitted; the host may set a time limit per step, and an unfinished book passes on as-is.\nEnd:\n· After the final guess, browse each book to retrace its full chain.",
			roundShort: "{{n}}/{{total}}",
			drawPrompt: "Draw this word",
			guessPrompt: "What is this drawing?",
			submit: "Submit",
			waitingOthers: "Submitted — waiting {{n}}/{{total}}…",
			guessPlaceholder: "Type your guess…",
			ownerSelf: "Your own book",
			ownerFrom: "{{name}}'s book",
			blankDrawing: "(timed out, blank)",
			blankWord: "(timed out, no guess)",
			optTimeLimit: "Round timer",
			optOff: "Off",
			optSec: "{{n}}s",
			endTitle: "Book gallery",
			pickBook: "Pick a book and watch the word drift",
			entryOrigin: "Original prompt",
			entryByDraw: "Drawn by {{name}}",
			entryByGuess: "Guessed by {{name}}",
			errNotPlaying: "The game is over",
			errAlreadySubmitted: "Already submitted this round",
			errNeedDrawing: "This round is drawing",
			errNeedWord: "This round is guessing"
		}
	}
};
//#endregion
export { se as default };
