import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useId as r, useRef as i, useState as a } from "react";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { useT as c } from "@bgparty/sdk/i18n";
import { IconCheck as l, IconClose as u, IconEye as d, IconLog as ee } from "@bgparty/sdk/icons";
import { Texture as te } from "@bgparty/sdk/texture";
import { useWakeLock as f } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { FlySprite as _ } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as v } from "@bgparty/sdk/confirm-button";
import { readGameStorage as ne, writeGameStorage as re } from "@bgparty/sdk/storage";
import { OptionCheckbox as ie, OptionRadio as y, OptionSection as b, OptionSwitch as x } from "@bgparty/sdk/ui/game-options";
//#region src/games/palmisland/data.ts
var S = (e = 0, t = 0, n = 0) => [
	e,
	t,
	n
], C = (e = [], t = 0, n = 0, r = {}) => ({
	resources: e,
	points: t,
	upgrades: n,
	actions: r
}), w = [S()], T = [
	S(1),
	S(0, 1),
	S(0, 0, 1)
], E = [
	S(2),
	S(0, 2),
	S(0, 0, 2)
], D = [
	C([S(0, 1)], 0, 0, {
		store: w,
		rotate: [S(0, 1)],
		flip: [S(0, 1)]
	}),
	C([S(0, 2)], 0, 1, {
		store: w,
		flip: [S(1, 1)]
	}),
	C([S(1, 1)], 0, 1, {
		store: w,
		rotate: [S(1, 1)]
	}),
	C([S(1, 2)], 0, 2, { store: w })
], O = [
	C([S(1)], 0, 0, {
		store: w,
		rotate: [S(1, 1)]
	}),
	C([S(1, 0, 1)], 1, 1, {
		store: w,
		flip: [S(1, 0, 1)]
	}),
	C([], 5, 3),
	C([S(2)], 2, 2, {
		store: w,
		rotate: [S(2, 0, 2)]
	})
], k = [
	C([], 0, 0, {
		rotate: [S(2)],
		flip: [S(0, 2)]
	}),
	C([S(0, 0, 1)], 0, 1, {
		store: w,
		flip: [S(2, 1)]
	}),
	C([S(0, 0, 2)], 0, 1, {
		store: w,
		rotate: [S(1, 2)]
	}),
	C([S(0, 0, 2)], 2, 2, { store: w })
], ae = [
	C([], 0, 0, { rotate: [S(1, 1)] }),
	C([], 1, 1, { flip: [S(1, 1, 1)] }),
	C([], 6, 3),
	C([], 3, 2, { rotate: [S(2, 2, 2)] })
], A = [
	C([], 0, 0, { rotate: [S(1, 1, 2)] }),
	C([], 3, 1, { flip: [S(2, 2, 3)] }),
	C([], 10, 3),
	C([], 6, 2, { rotate: [S(3, 3, 4)] })
], oe = {
	1: D,
	2: D,
	3: D,
	4: O,
	5: O,
	6: O,
	7: k,
	8: k,
	9: k,
	10: [
		C([S(0, 0, 1)], 0, 0, {
			store: [S(1), S(0, 1)],
			rotate: [S(2)],
			flip: [S(0, 2)]
		}),
		C([S(0, 1, 1)], 0, 1, {
			store: [S(1)],
			flip: [S(1, 0, 1)]
		}),
		C([S(1, 0, 1)], 0, 1, {
			store: [S(0, 1)],
			rotate: [S(0, 1, 1)]
		}),
		C([S(1, 1, 1)], 0, 2, { store: T })
	],
	11: [
		C([S(1, 1)], 0, 0, {
			store: [S(0, 2), S(2)],
			rotate: [S(0, 1)],
			flip: [S(1)]
		}),
		C([S(3)], 0, 1, {
			store: [S(0, 2), S(0, 0, 1)],
			flip: [S(1, 1)]
		}),
		C([S(0, 3)], 0, 1, {
			store: [S(2), S(0, 0, 2)],
			rotate: [S(1, 1)]
		}),
		C([S(0, 0, 3)], 0, 2, {
			store: [S(2), S(0, 2)],
			rotate: [S(0, 0, 1)],
			flip: [S(0, 0, 1)]
		})
	],
	12: [
		C([], 0, 0, {
			rotate: [S(1, 1, 2)],
			flip: [S(1, 1)]
		}),
		C([], 4, 3),
		C([S(1, 1)], 0, 1, {
			store: w,
			rotate: [S(1, 1, 1)]
		}),
		C([S(1, 1, 1)], 0, 2, {
			store: w,
			flip: [S(2, 2, 2)]
		})
	],
	13: ae,
	14: ae,
	15: A,
	16: A,
	17: [
		C(),
		C([], 0, 0, { flip: [S(1, 1)] }),
		C(E, 2, 0, { store: w }),
		C(T, 1, 0, {
			store: w,
			rotate: [S(1, 1, 1)]
		})
	],
	18: [
		C(),
		C(),
		C([S(0, 0, 1)], 0, 0, { store: w }),
		C()
	],
	19: [
		C(),
		C([], 0, 0, { flip: w }),
		C([], 5, 0),
		C([], 1, 0, { rotate: [S(3, 3, 3)] })
	],
	20: [
		C(),
		C([], 0, 0, { flip: [S(1, 1)] }),
		C([S(0, 0, 4)], 1, 0, {
			store: [S(2, 1)],
			rotate: w
		}),
		C([S(1, 2)], 1, 0, {
			store: [S(0, 0, 3)],
			rotate: w
		})
	],
	21: [
		C(),
		C(),
		C(),
		C()
	],
	22: [
		C(),
		C(),
		C(),
		C()
	],
	23: [
		C(),
		C(),
		C(),
		C()
	],
	24: [
		C(),
		C(),
		C([S(1, 1, 1)], 0, 0, { store: w }),
		C()
	],
	25: [
		C(),
		C(),
		C([S(1, 1)], 0, 0, { store: w }),
		C()
	]
}, se = [
	17,
	18,
	19,
	20,
	21,
	22,
	23,
	24,
	25
], ce = {
	17: 1,
	18: 2,
	19: 1,
	20: 1,
	21: 2,
	22: 2,
	23: 2,
	24: 2,
	25: 2
}, le = [
	30,
	31,
	32,
	33,
	34,
	35,
	36
], ue = [
	S(0, 2, 2),
	S(1, 1, 1),
	S(2, 0, 2),
	S(2, 2),
	S(0, 0, 5),
	S(),
	S()
];
for (let [e, t] of le.entries()) oe[t] = [
	C([], 0, 0, { rotate: [ue[e]] }),
	C(t === 35 ? E : t === 36 ? [S(1, 1, 1)] : [], [
		0,
		0,
		0,
		1,
		5,
		-4,
		-6
	][e], 0),
	C(),
	C()
];
var de = {
	famine: [
		S(1, 2, 1),
		S(2, 3, 1),
		S(3, 4, 2)
	],
	eruption: [
		S(1, 2, 2),
		S(2, 2, 3),
		S(3, 2, 4)
	],
	hurricane: [
		S(3, 1, 2),
		S(4, 2, 2),
		S(5, 2, 2)
	]
}, j = [
	{
		id: 40,
		type: 0,
		points: 2,
		villager: 30
	},
	{
		id: 41,
		type: 1,
		points: 3,
		villager: 31
	},
	{
		id: 42,
		type: 1,
		points: 1,
		villager: 32
	},
	{
		id: 43,
		type: 0,
		points: 1,
		villager: 33
	},
	{
		id: 44,
		type: 2,
		points: 2,
		villager: 34
	},
	{
		id: 45,
		type: 2,
		points: 2,
		villager: 35
	},
	{
		id: 46,
		type: 0,
		points: 1,
		villager: 36
	},
	{
		id: 47,
		type: 2,
		points: 1,
		villager: 30
	},
	{
		id: 48,
		type: 1,
		points: 3,
		villager: 31
	},
	{
		id: 49,
		type: 1,
		points: 2,
		villager: 32
	},
	{
		id: 50,
		type: 1,
		points: 2,
		villager: 33
	},
	{
		id: 51,
		type: 2,
		points: 4,
		villager: 34
	},
	{
		id: 52,
		type: 2,
		points: 2,
		villager: 35
	},
	{
		id: 53,
		type: 0,
		points: 1,
		villager: 36
	}
], M = (e) => oe[e.id]?.[e.face] ?? C(), fe = (e, t) => [
	e[0] + t[0],
	e[1] + t[1],
	e[2] + t[2]
], pe = (e) => e[0] + e[1] + e[2], N = {
	id: "palmisland",
	tier: "alpha",
	sdkApi: 2,
	mechanics: ["hand-management", "engine-building"],
	interactionTags: ["cooperative"],
	nameKey: "games.palmisland.name",
	descKey: "games.palmisland.desc",
	rulesKey: "games.palmisland.rules",
	icon: "🏝️",
	iconImg: "games/palmisland.webp",
	minPlayers: 1,
	maxPlayers: 2,
	bestPlayers: [1],
	playerRange: (e) => ({
		min: e && typeof e == "object" && "mode" in e && e.mode !== "solo" ? 2 : 1,
		max: e && typeof e == "object" && "mode" in e && e.mode !== "solo" ? 2 : 1
	}),
	accent: "#137c76",
	releasedAt: "2026-10-30T14:07:34+08:00",
	search: {
		py: "zong lv dao",
		init: "zld"
	},
	hotseat: "off",
	botDelayMs: 450
}, P = t.int().min(0).max(53), F = t.tuple([
	t.int().nonnegative(),
	t.int().nonnegative(),
	t.int().nonnegative()
]), me = t.object({
	id: P,
	face: t.int().min(0).max(3),
	stored: t.boolean(),
	used: t.boolean()
}), I = t.object({
	cards: t.array(P).max(5),
	choices: t.array(t.int().min(0).max(2)).max(5)
}), he = t.object({
	rid: t.string(),
	payment: I
}), ge = t.object({
	type: t.literal("play"),
	card: P,
	operation: t.enum([
		"store",
		"rotate",
		"flip",
		"discard",
		"release"
	]),
	payment: I,
	release: P.nullable(),
	support: he.nullable().default(null)
}), _e = t.discriminatedUnion("type", [
	ge,
	t.object({
		type: t.literal("begin"),
		active: t.array(P).max(4),
		release: t.array(P).max(5).default([]),
		reorder: P.nullable(),
		canoe: t.int().min(1).max(3),
		canoeFace: t.union([t.literal(1), t.literal(2)]),
		logger: t.int().min(4).max(6)
	}),
	t.object({
		type: t.literal("shipping"),
		to: t.string().nullable(),
		payment: I
	}),
	t.object({
		type: t.literal("project"),
		target: t.enum([
			"disaster",
			"abilityRotate",
			"abilityFlip",
			"finish"
		])
	}),
	t.object({
		type: t.literal("pledge"),
		payment: I
	}),
	t.object({ type: t.literal("resolve") }),
	t.object({
		type: t.literal("buy"),
		card: P.nullable(),
		payment: I
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), ve = t.object({
	mode: t.enum([
		"solo",
		"cooperative",
		"casual",
		"speed"
	]).default("solo"),
	villagers: t.boolean().default(!1),
	feats: t.array(t.int().min(17).max(25)).max(9).default([]),
	disaster: t.enum([
		"famine",
		"eruption",
		"hurricane"
	]).default("famine"),
	ability: t.enum([
		"none",
		"storage",
		"rebuild",
		"shipping"
	]).default("none")
}).default({
	mode: "solo",
	villagers: !1,
	feats: [],
	disaster: "famine",
	ability: "none"
}), ye = t.object({
	rid: t.string(),
	ready: t.boolean(),
	arrived: t.boolean(),
	points: t.int(),
	scoreDetails: t.object({
		buildings: t.int(),
		feats: t.int(),
		villagers: t.int(),
		outposts: t.int()
	}),
	upgrades: t.int(),
	resources: F,
	storedCount: t.int(),
	capacity: t.union([t.literal(4), t.literal(5)]),
	outposts: t.array(t.int()),
	buildings: t.array(t.object({
		id: P,
		face: t.int()
	})),
	pledge: F.nullable()
}), be = t.object({
	phase: t.enum([
		"begin",
		"play",
		"council",
		"resolve",
		"done"
	]),
	round: t.int().min(1).max(8),
	config: ve,
	players: t.array(ye),
	market: t.array(P),
	turn: t.string().nullable(),
	disasterLevel: t.int().min(0).max(3),
	abilityFace: t.int().min(0).max(3),
	project: t.enum([
		"disaster",
		"abilityRotate",
		"abilityFlip",
		"finish"
	]),
	cost: F,
	projectAvailable: t.boolean(),
	revision: t.int(),
	match: t.string(),
	shipping: t.array(t.object({
		rid: t.string(),
		to: t.string(),
		resources: F
	})),
	shippingAvailable: t.array(t.string()),
	finalDecks: t.record(t.string(), t.array(me)),
	unlocked: t.record(t.string(), t.array(P))
}), L = t.object({
	top: t.array(me).max(3),
	stored: t.array(me).max(5),
	moves: t.array(ge),
	inspect: t.array(me),
	active: t.array(P),
	payments: t.array(I)
}), xe = () => ({
	cards: [],
	choices: []
}), R = () => [
	0,
	0,
	0
], z = (e, t = 0) => ({
	id: e,
	face: t,
	stored: !1,
	used: !1
});
function Se(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function B(e, t) {
	return e.deck.filter((e) => t.includes(e.id)).reduce((e, t) => e + M(t).upgrades, 0);
}
function V(e) {
	let t = (t, n) => e.deck.filter((e) => e.id >= t && e.id <= n).reduce((e, t) => e + M(t).points, 0), n = t(30, 36) + (e.deck.some((e) => e.id === 30 && e.face === 1) ? B(e, [13, 14]) : 0) + (e.deck.some((e) => e.id === 31 && e.face === 1) ? B(e, [10, 11]) : 0);
	return {
		buildings: t(1, 16),
		feats: t(17, 25),
		villagers: n,
		outposts: e.outposts.reduce((e, t) => e + (j.find((e) => e.id === t)?.points ?? 0), 0)
	};
}
function H(e) {
	return Object.values(V(e)).reduce((e, t) => e + t, 0);
}
function U(e) {
	return e.deck.filter((e) => e.stored);
}
function W(e, t) {
	if (t.cards.length !== t.choices.length || new Set(t.cards).size !== t.cards.length) return null;
	let n = R();
	for (let r = 0; r < t.cards.length; r++) {
		let i = e.deck.find((e) => e.id === t.cards[r] && e.stored), a = i && M(i).resources[t.choices[r]];
		if (!a) return null;
		n = fe(n, a);
	}
	return n;
}
function Ce(e) {
	let t = [xe()];
	for (let n of U(e)) {
		let e = t.flatMap((e) => M(n).resources.map((t, r) => ({
			cards: [...e.cards, n.id],
			choices: [...e.choices, r]
		})));
		t = [...t, ...e];
	}
	return t;
}
function we(e, t, n) {
	return t.reduce((t, n, r) => t + Math.max(0, n - e[r]), 0) <= +!!n;
}
function Te(e, t) {
	for (let n of e.deck) t.cards.includes(n.id) && (n.stored = !1);
}
function Ee(e) {
	return e.active.includes(33) ? 5 : 4;
}
function De(e, t) {
	e.deck.splice(e.deck.indexOf(t), 1), e.deck.push(t);
}
function Oe(e, t) {
	let n = e.deck.findIndex((e) => e.id === 0);
	e.deck.splice(n + 1, 0, t);
}
function ke(e, t) {
	return JSON.stringify(e) === JSON.stringify(t);
}
function Ae(e) {
	return e.active.includes(32);
}
function je(e) {
	return e.deck[0]?.id === 0;
}
function Me(e, t) {
	let n = e.islands[t];
	if (e.phase !== "play" || !n?.ready || je(n)) return [];
	let r = [], i = (e, t, n = xe(), r = null, i = null) => ({
		type: "play",
		card: e,
		operation: t,
		payment: n,
		release: r,
		support: i
	}), a = n.deck[0];
	if (a.stored) return [i(a.id, "discard")];
	r.push(i(a.id, "discard"));
	let o = Ce(n), s = [null, ...e.players.flatMap((n) => {
		let r = e.islands[n];
		return r.offer?.to === t && !r.shippingUsed && W(r, r.offer.payment) ? [{
			rid: n,
			payment: r.offer.payment
		}] : [];
	})];
	for (let t of n.deck.slice(0, 2)) {
		if (t.id === 0 || t.stored || t.id >= 30 && t.face === 1) continue;
		let a = M(t);
		for (let c of [
			"store",
			"rotate",
			"flip"
		]) {
			if (t.id === 24 && t.used && c === "store" || t.id === 19 && t.face === 1 && c === "flip" && !n.deck.filter((e) => [13, 14].includes(e.id)).every((e) => M(e).upgrades === 3)) continue;
			let l = a.actions[c];
			if (l) for (let a of o) for (let o of s) {
				let s = fe(W(n, a), o ? W(e.islands[o.rid], o.payment) : R());
				if (!l.some((e) => we(s, e, Ae(n)))) continue;
				let u = U(n).filter((e) => !a.cards.includes(e.id));
				if (c === "store" && u.length >= Ee(n)) for (let e of u) r.push(i(t.id, c, a, e.id, o));
				else r.push(i(t.id, c, a, null, o));
			}
		}
	}
	for (let e of U(n)) r.push(i(e.id, "release"));
	return r;
}
function Ne(e) {
	let t = H(e), n = (t) => M(e.deck.find((e) => e.id === t)).upgrades, r = [
		t >= 30,
		U(e).reduce((e, t) => e + Math.max(...M(t).resources.map((e) => e[2])), 0) >= 9 && t >= 25,
		n(15) + n(16) === 0 && t >= 30,
		n(10) >= 2 && n(11) >= 2 && t >= 32,
		[
			1,
			2,
			3
		].every((e) => n(e) >= 2) && t >= 30,
		[
			4,
			5,
			6
		].every((e) => n(e) >= 2) && t >= 34,
		t >= 40,
		n(15) >= 3 && n(16) >= 3 && t >= 30,
		Array.from({ length: 16 }, (e, t) => t + 1).every((e) => n(e) >= 2)
	];
	return se.filter((e, t) => r[t]);
}
function G(e) {
	let t = e.players.length;
	if (e.project === "finish") return {
		cost: R(),
		available: !0
	};
	if (e.project === "disaster") {
		let n = de[e.config.disaster][e.disasterLevel], r = e.config.ability === "storage" && e.abilityFace >= 2 ? e.abilityFace === 2 ? [
			2,
			2,
			0
		] : [
			0,
			0,
			4
		] : R();
		return {
			cost: n ? n.map((e, n) => Math.max(0, e * t - r[n])) : R(),
			available: !!n
		};
	}
	let n = e.abilityFace;
	return e.config.ability === "storage" ? {
		cost: e.project === "abilityRotate" ? R() : n === 0 ? [
			2,
			2,
			2
		] : [
			1,
			1,
			4
		],
		available: n < 2
	} : e.config.ability === "rebuild" ? {
		cost: [
			t,
			t,
			t
		],
		available: e.project === "abilityRotate" && n === 0
	} : e.config.ability === "shipping" ? {
		cost: [
			0,
			0,
			t
		],
		available: e.project === "abilityRotate" && n === 0 && e.players.reduce((t, n) => t + B(e.islands[n], [15, 16]), 0) >= t
	} : {
		cost: R(),
		available: !1
	};
}
function Pe(e, t) {
	je(e.islands[t]) && !e.arrival.includes(t) && e.arrival.push(t), !(e.arrival.length < e.players.length) && (e.phase = e.config.mode === "cooperative" || e.config.mode === "speed" ? "council" : "resolve", e.turnIndex = 0, e.passed = [], e.project = "disaster");
}
function Fe(e) {
	if (e.round === 8) {
		e.phase = "done";
		return;
	}
	e.round++, e.phase = "begin", e.arrival = [];
	for (let t of Object.values(e.islands)) {
		let e = t.deck.shift();
		t.deck.push(e), t.ready = !1, t.active = [], t.pledge = null, t.shippingUsed = !1, t.offer = null;
		for (let e of t.deck) [35, 36].includes(e.id) && (e.stored = !1);
	}
}
function Ie(e) {
	if (e.config.mode === "casual") for (let t of [...e.market]) {
		let n = [
			1,
			4,
			7
		][j.find((e) => e.id === t).type], r = e.players.filter((t) => [
			n,
			n + 1,
			n + 2
		].every((n) => e.islands[t].deck.some((e) => e.id === n && M(e).upgrades >= 1)));
		r.length === 1 && e.islands[r[0]].outposts.push(t), r.length && e.market.splice(e.market.indexOf(t), 1);
	}
	Fe(e);
}
function Le(e, t, n) {
	let r = {
		players: t,
		islands: {},
		config: e,
		seed: n,
		cursor: 0,
		round: 1,
		phase: "begin",
		arrival: [],
		market: [],
		turnIndex: 0,
		passed: [],
		disasterLevel: 0,
		abilityFace: 0,
		project: "disaster",
		revision: 0,
		match: `${n}:${t.join(":")}`
	}, i = Se(r, Array.from({ length: 16 }, (e, t) => t + 1)), a = [];
	if (e.mode === "casual") {
		let t = Se(r, j);
		for (let e of [
			0,
			1,
			2
		]) r.market.push(t.find((t) => t.type === e).id);
		let n = r.market.map((e) => j.find((t) => t.id === e).villager);
		e.villagers && (a = Se(r, le.filter((e) => !n.includes(e))).slice(0, 3));
	} else e.mode === "speed" ? r.market = e.villagers ? Se(r, le).slice(0, 3) : j.filter((e) => e.points >= 2).sort((e, t) => t.points - e.points || e.id - t.id).map((e) => e.id) : e.villagers && e.mode === "solo" && (a = Se(r, le).slice(0, 3));
	for (let [n, o] of t.entries()) {
		let t = n === 0 || e.mode === "casual" || e.mode === "speed" ? i : Se(r, i);
		r.islands[o] = {
			deck: [
				...t.map((e) => z(e)),
				...a.map((e) => z(e)),
				z(0),
				...e.mode === "solo" ? [...new Set(e.feats)].map((e) => z(e, ce[e])) : []
			],
			ready: !1,
			active: [],
			outposts: [],
			pledge: null,
			shippingUsed: !1,
			offer: null
		};
	}
	return { state: r };
}
var K = () => ({ code: "games.palmisland.error" });
function Re(e, t, { by: n }) {
	if (t.type === "tick") {
		if (n !== "$engine" || e.phase !== "resolve") return K();
		let t = structuredClone(e);
		return Ie(t), t.revision++, { state: t };
	}
	if (!e.players.includes(n) || e.phase === "done" || e.phase === "resolve") return K();
	let r = structuredClone(e), i = r.islands[n];
	if (t.type === "begin") {
		if (r.phase !== "begin" || i.ready || new Set(t.active).size !== t.active.length) return K();
		let e = i.deck.filter((e) => e.face === 1 && [
			32,
			33,
			35,
			36
		].includes(e.id)).map((e) => e.id);
		if (t.active.some((t) => !e.includes(t)) || new Set(t.release).size !== t.release.length || t.release.some((e) => !i.deck.some((t) => t.id === e && t.stored))) return K();
		Te(i, {
			cards: t.release,
			choices: []
		});
		for (let e of [...i.deck]) e.id >= 30 && e.face === 1 && (i.deck.splice(i.deck.indexOf(e), 1), Oe(i, e));
		let n = r.round === 1 && r.config.mode === "solo" && r.config.feats.includes(23) || r.config.mode === "cooperative" && r.config.ability === "rebuild" && r.abilityFace === 1;
		if (t.reorder !== null) {
			let e = i.deck.find((e) => e.id === t.reorder && e.id !== 0);
			if (!n || !e) return K();
			i.deck.splice(i.deck.indexOf(e), 1), i.deck.unshift(e);
		}
		r.round === 1 && r.config.mode === "solo" && (r.config.feats.includes(21) && (i.deck.find((e) => e.id === t.canoe).face = t.canoeFace), r.config.feats.includes(22) && (i.deck.find((e) => e.id === t.logger).face = 1)), i.active = t.active;
		for (let e of t.active.filter((e) => e === 35 || e === 36)) {
			let t = i.deck.find((t) => t.id === e);
			if (!t.stored && U(i).length >= Ee(i)) return K();
			t.stored = !0;
		}
		if (U(i).length > Ee(i)) return K();
		if (i.ready = !0, r.players.every((e) => r.islands[e].ready)) {
			r.phase = "play";
			for (let e of r.players) Pe(r, e);
		}
	} else if (t.type === "shipping") {
		if (r.phase !== "play" || r.config.mode !== "cooperative" || r.config.ability !== "shipping" || r.abilityFace !== 1 || i.shippingUsed || t.to !== null && (t.to === n || !r.players.includes(t.to) || !t.payment.cards.length || !W(i, t.payment))) return K();
		i.offer = t.to === null ? null : {
			to: t.to,
			payment: t.payment
		};
	} else if (t.type === "play") {
		if (!Me(r, n).some((e) => e.card === t.card && e.operation === t.operation && e.release === t.release && ke(e.payment, t.payment) && JSON.stringify(e.support) === JSON.stringify(t.support))) return K();
		let e = i.deck.find((e) => e.id === t.card);
		if (t.operation === "discard") e.stored = !1, De(i, e);
		else if (t.operation === "release") e.stored = !1;
		else {
			if (Te(i, t.payment), t.support) {
				let e = r.islands[t.support.rid];
				Te(e, t.support.payment), e.shippingUsed = !0, e.offer = null;
			}
			t.release !== null && (i.deck.find((e) => e.id === t.release).stored = !1), t.operation === "store" ? (e.stored = !0, e.id === 24 && (e.used = !0)) : e.face ^= t.operation === "rotate" ? 1 : 2, e.id >= 30 && e.face === 1 ? (i.deck.splice(i.deck.indexOf(e), 1), Oe(i, e)) : De(i, e);
		}
		Pe(r, n);
	} else if (t.type === "project") {
		if (r.phase !== "council" || r.config.mode !== "cooperative") return K();
		r.project = t.target;
		for (let e of Object.values(r.islands)) e.pledge = null;
	} else if (t.type === "pledge") {
		if (r.phase !== "council" || r.config.mode !== "cooperative" || !W(i, t.payment)) return K();
		i.pledge = t.payment;
	} else if (t.type === "resolve") {
		if (r.phase !== "council" || r.config.mode !== "cooperative") return K();
		if (r.project === "finish") r.phase = "resolve";
		else {
			let e = G(r);
			if (!e.available || r.players.some((e) => !r.islands[e].pledge) || !we(r.players.reduce((e, t) => fe(e, W(r.islands[t], r.islands[t].pledge)), R()), e.cost, !1)) return K();
			for (let e of Object.values(r.islands)) Te(e, e.pledge), e.pledge = null;
			r.project === "disaster" ? (r.disasterLevel++, r.config.ability === "storage" && r.abilityFace >= 2 && (r.abilityFace ^= 2), r.disasterLevel === 3 && (r.phase = "done")) : r.project === "abilityFlip" ? r.abilityFace ^= 2 : r.abilityFace ^= 1;
		}
	} else if (t.type === "buy") {
		if (r.phase !== "council" || r.config.mode !== "speed" || r.arrival[r.turnIndex] !== n) return K();
		if (t.card === null) r.passed.push(n);
		else {
			let e = t.card, a = r.market.indexOf(e), o = W(i, t.payment), s = j.find((t) => t.id === e), c = s ? [
				1,
				1,
				1
			] : M(z(e)).actions.rotate[0];
			if (a < 0 || !o || !we(o, c, !1) || s && r.market.some((e) => (j.find((t) => t.id === e)?.points ?? 0) > s.points)) return K();
			Te(i, t.payment), r.market.splice(a, 1), s ? i.outposts.push(e) : Oe(i, z(e, 1)), r.passed = r.passed.filter((e) => e !== n);
		}
		if (r.players.every((e) => r.passed.includes(e)) || !r.market.length) r.phase = "resolve";
		else do
			r.turnIndex = (r.turnIndex + 1) % r.players.length;
		while (r.passed.includes(r.arrival[r.turnIndex]));
	}
	for (let e of Object.values(r.islands)) e.offer && !W(e, e.offer.payment) && (e.offer = null);
	r.revision++;
	let a = t.type === "play" ? e.islands[n].deck.find((e) => e.id === t.card) : null;
	return {
		state: r,
		fx: a && t.type === "play" ? [{
			kind: "palmCard",
			rid: n,
			for: [n],
			ephemeral: !0,
			with: !0,
			secret: {
				card: { ...a },
				source: e.islands[n].deck.indexOf(a),
				operation: t.operation
			}
		}] : []
	};
}
function ze(e, t) {
	let n = e.islands[t], r = G(e);
	return {
		public: {
			phase: e.phase,
			round: e.round,
			config: e.config,
			players: e.players.map((t) => {
				let n = e.islands[t];
				return {
					rid: t,
					ready: n.ready,
					arrived: je(n),
					points: H(n),
					scoreDetails: V(n),
					upgrades: B(n, Array.from({ length: 16 }, (e, t) => t + 1)),
					resources: U(n).reduce((e, t) => fe(e, M(t).resources[0] ?? R()), R()),
					storedCount: U(n).length,
					capacity: Ee(n),
					outposts: n.outposts,
					buildings: n.deck.filter((e) => e.id >= 1 && e.id <= 16 || e.id >= 30).map(({ id: e, face: t }) => ({
						id: e,
						face: t
					})).sort((e, t) => e.id - t.id),
					pledge: n.pledge ? W(n, n.pledge) : null
				};
			}),
			market: e.market,
			turn: e.phase === "council" && e.config.mode === "speed" ? e.arrival[e.turnIndex] : null,
			disasterLevel: e.disasterLevel,
			abilityFace: e.abilityFace,
			project: e.project,
			cost: r.cost,
			projectAvailable: r.available,
			revision: e.revision,
			match: e.phase === "done" ? e.match : "",
			finalDecks: e.phase === "done" ? Object.fromEntries(e.players.map((t) => [t, e.islands[t].deck])) : {},
			shipping: e.players.flatMap((t) => {
				let n = e.islands[t].offer;
				return n ? [{
					rid: t,
					to: n.to,
					resources: W(e.islands[t], n.payment)
				}] : [];
			}),
			shippingAvailable: e.phase === "play" && e.config.mode === "cooperative" && e.config.ability === "shipping" && e.abilityFace === 1 ? e.players.filter((t) => !e.islands[t].shippingUsed) : [],
			unlocked: e.phase === "done" && e.config.mode === "solo" ? Object.fromEntries(e.players.map((t) => [t, Ne(e.islands[t])])) : {}
		},
		private: n ? {
			top: n.deck.slice(0, 3),
			stored: U(n),
			moves: Me(e, t),
			inspect: e.phase === "begin" && (e.round === 1 || e.config.mode === "cooperative" && e.config.ability === "rebuild" && e.abilityFace === 1) ? n.deck : [],
			active: n.active,
			payments: e.phase === "council" ? Ce(n) : []
		} : void 0
	};
}
var Be = {
	meta: N,
	saveCompatibility: { version: "1" },
	schemas: {
		action: _e,
		publicView: be,
		privateView: L,
		config: ve
	},
	setup: Le,
	reduce: Re,
	viewFor: ze,
	nextTickIn: (e) => e.phase === "resolve" ? 400 : null,
	status: (e) => {
		if (e.phase !== "done") return { phase: e.phase };
		let t = [...e.players].sort((t, n) => H(e.islands[n]) - H(e.islands[t]) || B(e.islands[n], Array.from({ length: 16 }, (e, t) => t + 1)) - B(e.islands[t], Array.from({ length: 16 }, (e, t) => t + 1)) || U(e.islands[n]).reduce((e, t) => e + pe(M(t).resources[0] ?? R()), 0) - U(e.islands[t]).reduce((e, t) => e + pe(M(t).resources[0] ?? R()), 0)), n = e.config.mode === "cooperative", r = e.islands[t[0]], i = t.filter((t) => H(e.islands[t]) === H(r) && B(e.islands[t], Array.from({ length: 16 }, (e, t) => t + 1)) === B(r, Array.from({ length: 16 }, (e, t) => t + 1)) && U(e.islands[t]).reduce((e, t) => e + pe(M(t).resources[0] ?? R()), 0) === U(r).reduce((e, t) => e + pe(M(t).resources[0] ?? R()), 0));
		return {
			phase: "done",
			winner: n ? e.disasterLevel === 3 ? e.players : [] : i,
			ranking: t,
			scores: Object.fromEntries(e.players.map((t) => [t, H(e.islands[t])]))
		};
	}
}, Ve = "#463d32";
function q({ kind: e, x: t, y: n, paint: r }) {
	let i = e === 30, a = e === 33 || e === 34;
	return /* @__PURE__ */ g("g", {
		transform: `translate(${t} ${n})`,
		stroke: Ve,
		strokeWidth: "1",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ h("path", {
				d: i ? "M-21-2C-29-11-28 9-20 11M21-2C29-11 28 9 20 11" : "M-16-2C-23-9-22 9-15 10M16-2C23-9 22 9 15 10",
				fill: `url(#${r})`
			}),
			/* @__PURE__ */ h("path", {
				d: i ? "M-23-14C-22-30 17-34 23-14L22 9C20 24 8 28 0 27C-13 27-23 16-23 6Z" : e === 31 ? "M-17-15C-16-31 15-30 18-13L15 10C11 22 1 25-7 19C-14 14-18 3-17-15Z" : e === 35 ? "M-15-15C-11-31 17-29 18-11L14 8C10 21 0 25-8 16L-16 2Z" : "M-17-15C-13-30 15-30 18-12L17 6C16 18 8 25-1 23C-12 23-17 10-17 0Z",
				fill: `url(#${r})`
			}),
			/* @__PURE__ */ h("path", {
				d: "M-11-7Q-6-11-2-7M6-7Q11-10 15-6",
				fill: "none",
				stroke: "#554031",
				strokeWidth: "1.8"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-11-3Q-7-6-3-2M6-2Q10-5 14-2",
				fill: "#faf0cf"
			}),
			/* @__PURE__ */ h("ellipse", {
				cx: "-6",
				cy: "-2",
				rx: "1.6",
				ry: "2",
				fill: "#34352d",
				stroke: "none"
			}),
			/* @__PURE__ */ h("ellipse", {
				cx: "10",
				cy: "-1",
				rx: "1.5",
				ry: "2",
				fill: "#34352d",
				stroke: "none"
			}),
			/* @__PURE__ */ h("path", {
				d: "M2-4Q0 2-1 7Q2 10 6 7M-8 14Q1 18 11 12",
				fill: "none",
				stroke: "#85573d"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-5 14Q2 17 8 13",
				fill: "none",
				stroke: "#edd0ac"
			}),
			/* @__PURE__ */ h("path", {
				d: a ? "M-17-5Q-24-30 0-29Q24-28 18-5L14-16Q3-9-9-17L-14-6Z" : e === 30 ? "M-23-13Q-25-31-4-32Q19-36 24-17L20-12Q5-21-16-13Z" : e === 35 || e === 31 ? "M-16-9Q-26-26-7-31Q19-35 22-13Q25 8 18 29L12 28Q15 3 11-15Q-1-13-11-20Z" : "M-17-6Q-26-29-3-31Q20-35 21-11L16-5L12-17Q0-10-12-17Z",
				fill: a ? "#c7c5ae" : "#3e352b"
			}),
			(e === 31 || e === 35) && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("path", {
					d: "M-16-14Q1-29 18-13",
					fill: "none",
					stroke: "#e7d0a1",
					strokeWidth: "2.4"
				}),
				/* @__PURE__ */ h("path", {
					d: "M-12-17L-7-19M-2-20L3-21M9-19L14-17",
					stroke: "#ac7845",
					strokeWidth: ".8"
				}),
				/* @__PURE__ */ h("path", {
					d: "M-14 8Q-27 21-18 35Q-11 44-19 48",
					fill: "none",
					stroke: "#4c392b",
					strokeWidth: "6"
				}),
				/* @__PURE__ */ h("path", {
					d: "M-16 17L-21 21M-16 28L-20 32M-16 40L-18 43",
					stroke: "#9b7750",
					strokeWidth: "1"
				})
			] }),
			e === 33 && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
				d: "M-8-28Q-14-40-3-43Q8-44 11-34L7-28",
				fill: "#bcbfac"
			}), /* @__PURE__ */ h("path", {
				d: "M-7-34Q-1-39 6-33M-3-40L-2-31",
				stroke: "#e7e6d3",
				fill: "none"
			})] }),
			a && /* @__PURE__ */ h("path", {
				d: "M-12 6L-7 8M10 6L15 5M-9-12L9-13",
				fill: "none",
				stroke: "#986e50"
			}),
			e === 34 && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
				d: "M-14 9Q-16 26-2 38Q12 29 15 9L7 15Q0 10-6 16Z",
				fill: "#e8e1c9"
			}), /* @__PURE__ */ h("path", {
				d: "M-8 20L-3 31M5 21L1 34",
				stroke: "#b7b49d"
			})] }),
			e === 32 && /* @__PURE__ */ h("path", {
				d: "M-14 8Q-19 29 0 30Q18 25 15 7L9 14L3 11L-4 15Z",
				fill: "#3d332a"
			}),
			e === 30 && /* @__PURE__ */ h("path", {
				d: "M-12 20L-9 27M-5 22L-3 28M3 22L4 27",
				stroke: "#644d3b",
				strokeWidth: "1.5"
			})
		]
	});
}
function J({ x: e, y: t, angle: n = 0 }) {
	return /* @__PURE__ */ h("g", {
		transform: `translate(${e} ${t}) rotate(${n})`,
		fill: "none",
		stroke: "#775139",
		strokeWidth: ".8",
		children: /* @__PURE__ */ h("path", { d: "M-5-2Q-2 0-2 5M-2-3Q1 0 1 6M1-3Q4 0 4 5M4-2Q7 0 7 4" })
	});
}
function He({ kind: e }) {
	let t = r().replaceAll(":", ""), n = `skin${t}`, i = `cloth${t}`;
	return /* @__PURE__ */ g("g", {
		stroke: Ve,
		strokeWidth: "1.4",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ g("defs", { children: [/* @__PURE__ */ g("linearGradient", {
				id: n,
				x1: "0",
				y1: "0",
				x2: "1",
				y2: ".5",
				children: [
					/* @__PURE__ */ h("stop", { stopColor: "#d7a77c" }),
					/* @__PURE__ */ h("stop", {
						offset: ".5",
						stopColor: "#be8259"
					}),
					/* @__PURE__ */ h("stop", {
						offset: "1",
						stopColor: "#8d5b41"
					})
				]
			}), /* @__PURE__ */ g("linearGradient", {
				id: i,
				children: [
					/* @__PURE__ */ h("stop", { stopColor: e === 33 ? "#cf623c" : "#84965a" }),
					/* @__PURE__ */ h("stop", {
						offset: ".5",
						stopColor: e === 33 ? "#b6432b" : "#acb874"
					}),
					/* @__PURE__ */ h("stop", {
						offset: "1",
						stopColor: e === 33 ? "#883b2c" : "#576d43"
					})
				]
			})] }),
			e === 30 && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("g", {
					stroke: "#6a6940",
					fill: "#a8a568",
					children: [
						[-60, 34],
						[-44, 22],
						[-27, 14],
						[-10, 9],
						[7, 13],
						[24, 23],
						[40, 36]
					].map(([e, t], n) => /* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("path", { d: `M${150 + e} 143L${139 + e} ${t}Q${143 + e} ${t - 8} ${151 + e} ${t - 4}L${172 + e} 142Z` }), /* @__PURE__ */ h("path", {
						d: `M${142 + e} ${t + 9}L${155 + e} ${t + 8}M${146 + e} ${t + 41}L${160 + e} ${t + 40}M${151 + e} ${t + 75}L${165 + e} ${t + 74}`,
						stroke: "#d1c68a"
					})] }, n))
				}),
				/* @__PURE__ */ h("path", {
					d: "M101 140Q72 120 78 105Q85 90 106 108L129 137M184 137Q215 121 211 104Q204 89 182 108L162 137",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M111 154Q91 162 76 150L79 139Q97 139 112 143M176 151Q198 162 214 148L211 137Q191 139 177 141",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M108 69Q143 55 178 71Q189 85 189 111Q190 131 178 142Q145 155 109 140Q97 126 99 107Q98 84 108 69Z",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M110 97Q139 106 177 96M113 126Q144 138 176 125M143 78Q136 104 144 125",
					fill: "none",
					stroke: "#a9704f"
				}),
				/* @__PURE__ */ h("path", {
					d: "M115 131Q146 142 180 129L180 149L109 151Z",
					fill: `url(#${i})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M117 136L114 149M127 138L128 151M139 140L140 151M153 139L155 150M167 135L172 149",
					stroke: "#596d40"
				}),
				/* @__PURE__ */ h("path", {
					d: "M108 75Q95 63 85 78Q76 89 83 101L105 108L117 86M178 74Q193 63 202 79L207 95L196 101L184 88",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M89 90Q72 98 78 117L99 132Q111 140 114 130Q117 122 107 118L94 108L101 98M194 90Q205 103 215 91L225 72Q234 63 241 70Q246 80 236 90L227 112Q216 126 200 114L181 100",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M112 72Q140 91 178 72",
					fill: "none",
					stroke: "#6b4b33",
					strokeWidth: "4"
				}),
				/* @__PURE__ */ h("path", {
					d: "M112 73Q141 90 177 73",
					fill: "none",
					stroke: "#c9ad6d",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ h(q, {
					kind: e,
					x: 144,
					y: 51,
					paint: n
				}),
				/* @__PURE__ */ h("g", {
					stroke: "#aa4628",
					strokeWidth: ".8",
					children: [
						0,
						1,
						2,
						3,
						4,
						5
					].map((e) => /* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("path", {
						d: `M${84 + e * 4} ${81 + e * 2}q-7-15 2-15q10 2 5 18q5-9 10-3q3 8-7 14Z`,
						fill: e % 2 ? "#ed8d25" : "#d45a28"
					}), /* @__PURE__ */ h("path", {
						d: `M${186 + e * 3} ${79 + e * 3}q-3-15 6-12q7 7-1 19q10-8 12 1q-2 9-12 10Z`,
						fill: e % 2 ? "#e57926" : "#c74d27"
					})] }, e))
				}),
				/* @__PURE__ */ h("path", {
					d: "M160 77L163 127M165 80L168 128M160 87L168 91L161 96L168 100L162 105L169 111L163 117L170 122",
					stroke: "#71583d",
					strokeWidth: "1.2",
					fill: "none"
				}),
				/* @__PURE__ */ h("path", {
					d: "M234 28L230 166",
					stroke: "#765332",
					strokeWidth: "5"
				}),
				/* @__PURE__ */ h("path", {
					d: "M226 30L234 7L242 31L235 36Z",
					fill: "#9fb9bd"
				}),
				/* @__PURE__ */ h("path", {
					d: "M225 36Q218 44 227 54L233 43M236 36Q247 43 237 56L234 44",
					fill: "#356d9f"
				}),
				/* @__PURE__ */ h(J, {
					x: 234,
					y: 77,
					angle: -15
				}),
				/* @__PURE__ */ h(J, {
					x: 108,
					y: 129,
					angle: 45
				})
			] }),
			e === 31 && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("path", {
					d: "M126 119Q148 112 168 121L182 172L115 172Z",
					fill: `url(#${i})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M126 130L121 169M134 132L132 171M144 130L145 171M155 128L159 170M165 129L174 170",
					fill: "none",
					stroke: "#436740",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ h("path", {
					d: "M119 75Q139 66 157 74L170 105L165 129Q144 140 125 128L110 98Z",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M146 72L161 75L171 106L154 115L139 98Z",
					fill: "#ddd0a1"
				}),
				/* @__PURE__ */ h("path", {
					d: "M149 77L148 101L157 110M157 78L162 101",
					stroke: "#b1a472",
					fill: "none",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ h("path", {
					d: "M125 121Q145 129 167 119L171 129Q144 143 123 133Z",
					fill: "#b8442b"
				}),
				/* @__PURE__ */ h("path", {
					d: "M129 129Q145 135 164 126",
					stroke: "#e56f3b",
					fill: "none"
				}),
				/* @__PURE__ */ h("path", {
					d: "M159 78Q173 76 191 88L206 103Q211 111 202 116L190 114L180 103L158 96",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M157 104Q178 94 204 103L198 127Q179 142 158 127Z",
					fill: "#9c6638"
				}),
				/* @__PURE__ */ h("path", {
					d: "M159 108Q180 99 203 107M160 119Q181 130 200 119M166 106L169 129M176 104L179 132M189 103L190 128",
					fill: "none",
					stroke: "#d3aa67",
					strokeWidth: "1.6"
				}),
				/* @__PURE__ */ h("ellipse", {
					cx: "172",
					cy: "103",
					rx: "10",
					ry: "11",
					transform: "rotate(20 172 103)",
					fill: "#9bb74b"
				}),
				/* @__PURE__ */ h("ellipse", {
					cx: "189",
					cy: "100",
					rx: "10",
					ry: "11",
					transform: "rotate(35 189 100)",
					fill: "#bfca57"
				}),
				/* @__PURE__ */ h("path", {
					d: "M165 100Q170 94 176 99M182 97Q187 91 192 97",
					stroke: "#e2e792",
					fill: "none",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ h("path", {
					d: "M120 78Q105 76 104 91Q104 107 120 119L153 130Q165 133 173 125L175 118Q172 111 166 116L158 121L129 108L122 94",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M205 104Q211 121 198 127L194 122L198 113L195 106",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h(q, {
					kind: e,
					x: 127,
					y: 53,
					paint: n
				}),
				/* @__PURE__ */ h(J, {
					x: 169,
					y: 122,
					angle: -40
				}),
				/* @__PURE__ */ h(J, {
					x: 200,
					y: 114,
					angle: 25
				})
			] }),
			e === 32 && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("path", {
					d: "M70 42L68 178M232 57L229 178",
					stroke: "#795538",
					strokeWidth: "7"
				}),
				/* @__PURE__ */ h("path", {
					d: "M22 32L273 59",
					stroke: "#795538",
					strokeWidth: "10"
				}),
				/* @__PURE__ */ h("path", {
					d: "M25 29L270 56M67 47L66 174M231 62L228 175",
					stroke: "#bd9764",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ h("path", {
					d: "M67 26L74 42M75 28L69 44M229 47L236 61M237 48L231 64",
					stroke: "#87382a",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ h("path", {
					d: "M123 132Q144 127 171 133L177 178H115Z",
					fill: "#b29b6e"
				}),
				/* @__PURE__ */ h("path", {
					d: "M127 145L122 178M157 145L167 178",
					stroke: "#816c4a",
					fill: "none"
				}),
				/* @__PURE__ */ h("path", {
					d: "M124 78Q141 69 162 76Q180 80 183 96L174 138Q145 151 117 137L114 105Z",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M127 100Q146 112 169 101M145 111L142 133",
					fill: "none",
					stroke: "#a16a48"
				}),
				/* @__PURE__ */ h("path", {
					d: "M122 81Q106 78 100 94L92 118Q88 131 100 139L117 145L124 132L107 126L120 104M163 77Q180 71 191 86L207 107Q213 117 200 124L158 143L150 130L184 111L169 99",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M158 80Q176 78 189 88L197 105M165 84L171 95L178 84L183 99L189 90M162 91Q177 97 191 102M165 96L171 106L179 99L184 110L192 103M100 116L114 121M98 121L110 127",
					fill: "none",
					stroke: "#6e5940",
					strokeWidth: "1.1"
				}),
				/* @__PURE__ */ h("path", {
					d: "M42 119L257 162L257 176L42 132Z",
					fill: "#997449"
				}),
				/* @__PURE__ */ h("path", {
					d: "M45 121L254 164",
					stroke: "#dab27a",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ h("path", {
					d: "M45 130L253 173",
					stroke: "#674a31",
					fill: "none"
				}),
				/* @__PURE__ */ h("path", {
					d: "M118 129Q115 120 123 121L131 125L137 125L142 130L138 139L127 139L121 145L116 141ZM151 126Q153 118 160 122L163 127L171 129L171 139L165 140L159 136L151 137Z",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h(J, {
					x: 126,
					y: 128,
					angle: 15
				}),
				/* @__PURE__ */ h(J, {
					x: 160,
					y: 128,
					angle: 15
				}),
				/* @__PURE__ */ h(q, {
					kind: e,
					x: 143,
					y: 56,
					paint: n
				})
			] }),
			e === 33 && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("path", {
					d: "M121 129Q96 119 80 136L60 156Q58 167 79 170L139 162L196 171Q217 167 211 154L184 133Q170 121 151 131Z",
					fill: `url(#${i})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M71 159Q102 149 130 157M163 153Q186 148 202 160M87 140L112 146M178 136L166 147",
					fill: "none",
					stroke: "#ecaa57",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ h("path", {
					d: "M119 78Q143 66 166 80L179 139Q149 155 111 138L107 106Z",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M163 76L172 80Q181 102 178 140L145 153L123 145L124 113Z",
					fill: "#b5432b"
				}),
				/* @__PURE__ */ h("path", {
					d: "M163 75Q147 89 124 112L117 132L125 136Q139 110 170 82Z",
					fill: "#e1a52f"
				}),
				/* @__PURE__ */ h("path", {
					d: "M158 91L147 134M168 87L160 139M137 117L134 139",
					stroke: "#843525",
					fill: "none",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ h("path", {
					d: "M119 80Q104 81 101 99Q96 117 104 135L128 153Q135 158 140 151L138 143L121 126L122 104M169 83Q182 92 182 112L179 138L155 154Q146 158 143 151L146 144L166 130L165 105",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h(q, {
					kind: e,
					x: 145,
					y: 54,
					paint: n
				}),
				/* @__PURE__ */ h(J, {
					x: 135,
					y: 147,
					angle: -30
				}),
				/* @__PURE__ */ h(J, {
					x: 149,
					y: 149,
					angle: 25
				}),
				/* @__PURE__ */ h("path", {
					d: "M76 141Q102 140 117 154M170 150Q189 141 203 151",
					stroke: "#edb33b",
					strokeWidth: "5",
					fill: "none"
				})
			] }),
			e === 34 && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("path", {
					d: "M124 144L114 176L127 180L141 150M157 145L165 179L179 177L171 144",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M124 77Q144 67 164 80L170 115Q143 129 119 114Z",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M126 84Q144 91 159 83M143 91L141 108",
					fill: "none",
					stroke: "#a27051"
				}),
				/* @__PURE__ */ h("path", {
					d: "M126 82Q114 78 104 91L82 108L59 103L51 97Q46 93 43 98L46 104L35 105Q30 106 33 112L45 118Q52 122 61 119L84 123Q93 123 102 115L126 101M162 82Q175 76 183 91L204 108L226 103L234 96Q240 92 241 98L237 104L249 104Q255 105 253 111L242 119Q235 123 227 119L205 124Q194 125 186 115L161 100",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M158 74L167 78Q169 104 149 115L129 122L122 115Q155 102 158 74Z",
					fill: "#f3efdb"
				}),
				/* @__PURE__ */ h("path", {
					d: "M162 82Q161 104 138 116M165 89Q160 107 150 112",
					stroke: "#bdc5b7",
					strokeWidth: "2",
					fill: "none"
				}),
				/* @__PURE__ */ h("path", {
					d: "M124 115L165 114Q174 133 174 158Q156 163 145 155Q132 165 114 157L119 139Z",
					fill: "#ecebd7"
				}),
				/* @__PURE__ */ h("path", {
					d: "M159 119Q152 144 134 158M167 120Q165 142 157 156M130 124L123 151",
					stroke: "#b3bdb0",
					strokeWidth: "2",
					fill: "none"
				}),
				/* @__PURE__ */ h("path", {
					d: "M122 110Q146 118 167 109L169 120Q145 129 120 120Z",
					fill: "#c45232"
				}),
				/* @__PURE__ */ h("path", {
					d: "M124 115Q145 123 165 114",
					stroke: "#ec8b4a",
					fill: "none",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ h(q, {
					kind: e,
					x: 145,
					y: 49,
					paint: n
				}),
				/* @__PURE__ */ h(J, {
					x: 45,
					y: 111,
					angle: 70
				}),
				/* @__PURE__ */ h(J, {
					x: 241,
					y: 111,
					angle: -60
				})
			] }),
			e === 35 && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("path", {
					d: "M134 114Q151 110 171 116L178 178Q148 184 123 177L126 146Z",
					fill: `url(#${i})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M137 124Q133 149 136 177M147 127L151 180M161 123Q158 145 169 176",
					fill: "none",
					stroke: "#597345",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ h("path", {
					d: "M133 75Q148 68 164 78L175 102L166 121Q145 130 129 118L123 94Z",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M133 76L160 73L165 84L137 108L130 118L126 102Z",
					fill: "#bd482d"
				}),
				/* @__PURE__ */ h("path", {
					d: "M135 88L152 79M129 103L162 89M134 112L167 101M135 116Q150 124 168 112",
					fill: "none",
					stroke: "#e2743c",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ h("path", {
					d: "M132 119Q150 125 170 115L173 124Q150 137 131 128Z",
					fill: "#d6c48e"
				}),
				/* @__PURE__ */ h("path", {
					d: "M135 125L167 123",
					stroke: "#9e946a",
					fill: "none"
				}),
				/* @__PURE__ */ h("path", {
					d: "M129 79Q117 84 118 99L116 125L111 157L108 164L110 172L117 174L122 168L122 157L128 131L131 104M164 78Q173 76 183 87L200 105Q204 111 198 119L178 140L169 135L181 113L170 103L161 97",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M178 129L171 127Q166 128 165 134L160 141Q161 146 166 143L171 139L177 139Z",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h(J, {
					x: 114,
					y: 167,
					angle: -10
				}),
				/* @__PURE__ */ h(J, {
					x: 170,
					y: 135,
					angle: 35
				}),
				/* @__PURE__ */ h(q, {
					kind: e,
					x: 146,
					y: 52,
					paint: n
				})
			] }),
			e === 36 && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("path", {
					d: "M119 128Q99 118 90 132Q83 143 96 154L117 171L111 179L130 179L136 168L115 144L138 143M165 128Q188 117 197 131Q205 142 190 155L178 172L189 177L186 181L166 180L163 168L171 145L151 145",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M120 80Q140 71 164 82L177 127Q148 143 114 126L111 104Z",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M128 86Q144 94 163 87M144 97L139 119",
					fill: "none",
					stroke: "#9b6748"
				}),
				/* @__PURE__ */ h("path", {
					d: "M121 120Q145 130 171 118L185 147L161 148L149 140L139 152L115 149L101 136Z",
					fill: "#d1bf81"
				}),
				/* @__PURE__ */ h("path", {
					d: "M119 127L113 142M126 130L123 147M137 133L133 148M153 130L160 143M163 127L173 143",
					stroke: "#938158",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ h("path", {
					d: "M119 117Q146 125 172 114L175 123Q146 135 115 126Z",
					fill: "#a6462c"
				}),
				/* @__PURE__ */ h("path", {
					d: "M124 121Q144 129 168 119",
					stroke: "#db753c",
					fill: "none"
				}),
				/* @__PURE__ */ h("path", {
					d: "M119 82Q105 80 101 94L91 111L84 101Q79 94 73 98Q68 102 75 112L86 125Q93 133 102 124L122 102M165 82Q178 78 187 88L200 99Q206 106 201 117L188 140L175 135L183 109L168 104",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M186 132Q183 128 178 132L171 141Q170 148 178 149L187 142Z",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M154 81L161 119M159 82L166 117M155 87L162 92L157 97L164 102L159 107L166 112M177 86L173 103M183 89L179 106",
					stroke: "#6c5840",
					strokeWidth: "1.1",
					fill: "none"
				}),
				/* @__PURE__ */ h("path", {
					d: "M122 56Q113 26 139 25Q167 23 170 51L167 73L153 83L129 78Z",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M118 46Q113 26 125 21Q133 17 139 25Q144 13 155 22Q170 23 170 45L163 40L157 29L151 40L143 29L136 41L127 30Z",
					fill: "#393731"
				}),
				/* @__PURE__ */ h("path", {
					d: "M117 49Q116 37 127 38Q137 32 148 38Q161 33 168 43L171 54Q168 69 152 70L135 72Q119 69 117 59Z",
					fill: "#c6a17c"
				}),
				/* @__PURE__ */ h("path", {
					d: "M121 49Q123 39 132 43Q140 48 135 57Q127 61 122 57ZM145 46Q152 39 160 44Q168 51 158 59Q149 61 145 54Z",
					fill: "#32372e"
				}),
				/* @__PURE__ */ h("path", {
					d: "M127 63Q143 58 158 63L163 70L157 77L130 79L121 73Z",
					fill: "#976a49"
				}),
				[
					0,
					1,
					2,
					3,
					4,
					5
				].map((e) => /* @__PURE__ */ h("path", {
					d: `M${126 + e * 5} 66l1 ${18 + Math.sin(e) * 3}l2 1l1-${19 + Math.sin(e) * 3}Z`,
					fill: "#eadbb0",
					stroke: "#8e7c5c",
					strokeWidth: ".7"
				}, e)),
				/* @__PURE__ */ h("path", {
					d: "M126 68L155 67",
					stroke: "#f6e9c8",
					strokeWidth: "1.4"
				}),
				/* @__PURE__ */ h("path", {
					d: "M82 31L76 179",
					stroke: "#795839",
					strokeWidth: "3.5"
				}),
				/* @__PURE__ */ h("path", {
					d: "M78 34L84 11L88 34L83 39Z",
					fill: "#b5b7a0"
				}),
				/* @__PURE__ */ h("path", {
					d: "M73 101Q68 95 75 91L82 91L86 97L85 106L80 109Z",
					fill: `url(#${n})`
				}),
				/* @__PURE__ */ h(J, {
					x: 78,
					y: 98,
					angle: -5
				}),
				/* @__PURE__ */ h(J, {
					x: 180,
					y: 139,
					angle: 30
				})
			] })
		]
	});
}
//#endregion
//#region src/games/palmisland/feat-art.tsx
var Ue = "#443f35";
function We({ kind: e }) {
	let t = r().replaceAll(":", ""), n = `featwood${t}`, i = `featbone${t}`, a = `featstone${t}`, o = `featfiber${t}`;
	return /* @__PURE__ */ g("g", {
		stroke: Ue,
		strokeWidth: "1.5",
		strokeLinejoin: "round",
		strokeLinecap: "round",
		children: [
			/* @__PURE__ */ g("defs", { children: [
				/* @__PURE__ */ g("linearGradient", {
					id: n,
					x1: "0",
					y1: ".5",
					x2: "1",
					y2: ".2",
					children: [
						/* @__PURE__ */ h("stop", { stopColor: "#715034" }),
						/* @__PURE__ */ h("stop", {
							offset: ".35",
							stopColor: "#a77a4e"
						}),
						/* @__PURE__ */ h("stop", {
							offset: ".7",
							stopColor: "#c99c66"
						}),
						/* @__PURE__ */ h("stop", {
							offset: "1",
							stopColor: "#8c603e"
						})
					]
				}),
				/* @__PURE__ */ g("linearGradient", {
					id: i,
					x1: "0",
					y1: "0",
					x2: "1",
					y2: "1",
					children: [
						/* @__PURE__ */ h("stop", { stopColor: "#f0dfac" }),
						/* @__PURE__ */ h("stop", {
							offset: ".4",
							stopColor: "#cbb581"
						}),
						/* @__PURE__ */ h("stop", {
							offset: "1",
							stopColor: "#927c50"
						})
					]
				}),
				/* @__PURE__ */ g("linearGradient", {
					id: a,
					x1: "0",
					y1: "0",
					x2: "1",
					y2: ".5",
					children: [
						/* @__PURE__ */ h("stop", { stopColor: "#94a39c" }),
						/* @__PURE__ */ h("stop", {
							offset: ".24",
							stopColor: "#667c72"
						}),
						/* @__PURE__ */ h("stop", {
							offset: ".64",
							stopColor: "#3f554d"
						}),
						/* @__PURE__ */ h("stop", {
							offset: "1",
							stopColor: "#2e423b"
						})
					]
				}),
				/* @__PURE__ */ g("linearGradient", {
					id: o,
					x1: "0",
					y1: "0",
					x2: ".3",
					y2: "1",
					children: [
						/* @__PURE__ */ h("stop", { stopColor: "#edd3bc" }),
						/* @__PURE__ */ h("stop", {
							offset: ".45",
							stopColor: "#cba58a"
						}),
						/* @__PURE__ */ h("stop", {
							offset: "1",
							stopColor: "#9e7560"
						})
					]
				})
			] }),
			e === 17 && /* @__PURE__ */ g("g", {
				transform: "translate(151 109) rotate(-7)",
				children: [
					/* @__PURE__ */ h("path", {
						d: "M-33-47Q1-65 36-49L33 51Q13 65-25 58L-37 18Z",
						fill: `url(#${n})`
					}),
					/* @__PURE__ */ h("path", {
						d: "M17-45Q29-47 36-49L33 51L20 57Z",
						fill: "#b28a5b"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-39-48Q-10-64 30-59Q45-55 41-43L35-34Q5-47-36-33Z",
						fill: `url(#${n})`
					}),
					/* @__PURE__ */ h("path", {
						d: "M-38-47Q0-60 39-49",
						fill: "none",
						stroke: "#e0b77d",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-32-35L-31-28Q0-41 34-29L35-36Q5-48-32-35Z",
						fill: "#715033"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-29-39L-28-31M-22-42L-21-34M-14-44L-13-36M-5-45L-4-37M5-45L5-38M15-44L15-37",
						stroke: "#d4a674",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-33-25Q-10-39 9-27Q27-27 29-9Q32 13 14 27Q2 36-15 27L-27 17L-33 12L-38 7L-31-1L-35-10Z",
						fill: "#9a6e47"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-33-23Q-13-33 1-24Q-8-17-11-9Q-21-6-29-13Z",
						fill: "#c09561"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-29-20Q-14-26-4-20",
						fill: "none",
						stroke: "#e1b77d",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-5-17C23-32 40 6 13 22C-4 31-20 18-18 3Q-16-8-5-17Z",
						fill: "#654a34"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-4-12C18-26 32 4 11 17C-4 23-13 12-12 3Q-10-7-4-12Z",
						fill: `url(#${n})`,
						stroke: "#d9ad74",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-6-4Q2-15 12-8Q22-4 18 5Q4 12-6 7Z",
						fill: "#503d2e"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-6-3L-2-8M1-10L5-12M10-11L14-9M18-5L20-1M20 3L18 7M14 10L9 12",
						stroke: "#e0b580",
						strokeWidth: "1.4"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-23 2Q-15 4-16 12L-23 16L-14 20Q-13 28-24 31Q-34 32-38 25L-31 22L-40 16L-38 9Z",
						fill: "#b38454"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-37 17L-22 19M-30 26L-21 26",
						stroke: "#6d4b32"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-27 35Q-4 48 17 32L17 42Q1 57-20 45Z",
						fill: "#7e573a"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-20 37Q-2 49 13 37M-21 43Q-4 55 12 44",
						fill: "none",
						stroke: "#cba16a"
					}),
					/* @__PURE__ */ h("path", {
						d: "M22 8L31 13L22 19L30 27L21 32L29 40L20 44L28 52M22 21L29 22M21 35L28 35M-19 51Q-2 60 14 51",
						fill: "none",
						stroke: "#e0b580",
						strokeWidth: "1.4"
					})
				]
			}),
			e === 18 && /* @__PURE__ */ g("g", {
				transform: "translate(150 111)",
				children: [
					/* @__PURE__ */ h("path", {
						d: "M-25 47L-30 1L-26-36L-8-62L13-58L29-33L24 44L8 57Z",
						fill: "#466846"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-26-36L-8-62L-5-21L-29 1Z",
						fill: "#729150"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-8-62L13-58L29-33L4-23Z",
						fill: "#506d3e"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-5-21L4-23L24 44L8 57L-5 26Z",
						fill: "#324f3b"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-29 1L-5-21L-5 26L-25 47Z",
						fill: "#597d46"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-21-28L-15-42M-18-1L-20 18M9-41L17-30M10-11L13 13",
						stroke: "#8ca65d",
						fill: "none"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-43 43L-34 21L-22 25L-12 52L-25 60ZM12 54L22 29L37 37L42 56L24 62ZM-12 54L-8 37L7 36L17 59L0 65Z",
						fill: "#626e5e"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-34 21L-32 42L-43 43M22 29L28 46L37 37M-8 37L0 50L7 36",
						fill: "none",
						stroke: "#9da18b"
					})
				]
			}),
			e === 19 && /* @__PURE__ */ g("g", {
				transform: "translate(151 108)",
				children: [
					/* @__PURE__ */ h("path", {
						d: "M-75 17C-66 52-22 72 17 57C65 38 61-19 30-56L25-48C48-9 40 21 14 33C-15 46-47 36-69 14Q-74 10-75 17Z",
						fill: `url(#${i})`
					}),
					/* @__PURE__ */ h("path", {
						d: "M-70 20C-49 52-6 61 24 43C50 27 53-8 33-44",
						fill: "none",
						stroke: "#efdda8",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-64 28Q-30 58 10 43M34 27Q49 0 34-29",
						fill: "none",
						stroke: "#9c895d",
						strokeWidth: "1.3"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-40 31Q-23 18-20-12L-13-15Q-10 16-30 35ZM-8 40L-12-8L-4-10L1 39ZM18 33L3-14L10-20L28 25ZM37 9L11-7L15-14L41 0Z",
						fill: `url(#${i})`
					}),
					/* @__PURE__ */ h("path", {
						d: "M-35 29Q-24 10-23-8M-6 34L-9-3M23 24L7-10M35 3L18-6",
						fill: "none",
						stroke: "#e8d39d",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-28-24L24-57Q34-29 24-10Q7 3-19-5L-30-18Z",
						fill: `url(#${i})`
					}),
					/* @__PURE__ */ h("path", {
						d: "M-24-21L20-48Q25-29 18-14Q3-6-17-10Z",
						fill: "#c8b17c",
						stroke: "none"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-22-20L-15-20L-18-13M-12-26L-7-22L-11-16M-2-31L0-22L-4-15M9-38L10-30L6-24M18-44L17-35L21-29M-22-7L-13-8M-5-7L4-8M12-10L18-14",
						fill: "none",
						stroke: "#eedba7",
						strokeWidth: "1.5"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-3-66L-1-44Q3-39 7-45L8-67Z",
						fill: "#845133"
					}),
					/* @__PURE__ */ h("ellipse", {
						cx: "3",
						cy: "-69",
						rx: "28",
						ry: "7",
						fill: "#98643d"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-22-69Q3-79 28-69M-19-67Q4-62 24-67",
						fill: "none",
						stroke: "#bd905a"
					}),
					Array.from({ length: 18 }, (e, t) => /* @__PURE__ */ h("path", {
						d: `M${-53 + t * 5} ${35 + Math.sin(t / 4) * 13}l2-2m0 5l3-1`,
						stroke: "#ac9767",
						strokeWidth: ".8",
						fill: "none"
					}, t))
				]
			}),
			e === 20 && /* @__PURE__ */ g("g", {
				transform: "translate(150 109)",
				children: [
					/* @__PURE__ */ h("path", {
						d: "M-54 40Q-62 16-40-3Q-46-28-21-38Q-9-61 16-43Q36-51 42-29Q48-19 62-21Q66-21 62-15Q52-3 39-1Q29 16 14 14Q9 40-13 42Q-36 64-54 40Z",
						fill: "#aa744e"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-49 37Q-51 14-29 7Q-28-15-8-15Q-4-33 15-30Q29-36 35-22Q39-15 49-15L39-9Q24-13 16-1Q17 15-5 21Q-9 42-29 41Z",
						fill: "#e5bb87"
					}),
					/* @__PURE__ */ h("path", {
						d: "M15-42Q30-39 36-26Q41-15 60-19Q48-4 34-7Q29-7 25 0Q21-18 12-22Z",
						fill: "#f0cf9c"
					}),
					/* @__PURE__ */ h("path", {
						d: "M19-34Q31-32 34-23Q38-10 50-13Q42-7 34-10Q26-12 24-4Q26-21 15-23Z",
						fill: "#bc5744"
					}),
					/* @__PURE__ */ h("path", {
						d: "M20-31Q27-29 29-22Q29-16 34-12",
						fill: "none",
						stroke: "#e58c66",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ h("path", {
						d: "M35-26Q43-16 60-19",
						fill: "none",
						stroke: "#f7dfb4",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-46 38Q-42 25-33 28Q-24 32-30 42Q-39 49-46 38M-38 12Q-24 6-20 23M-25-6Q-9-6-5 13M-8-25Q10-28 16-7M17-36Q25-33 28-24",
						fill: "none",
						stroke: "#81593d",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-46 32Q-52 37-44 43Q-41 45-39 41Q-37 37-42 34Z",
						fill: "#554032"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-39 21Q-24 19-23 34M-27 2Q-7-2-4 15M-9-20Q8-26 17-9M-38 16L-32 16M-21-1L-15-1M-3-19L4-19",
						fill: "none",
						stroke: "#f4d4a9",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-22 20L-20 29M-6 1L-2 11M11-16L17-8",
						stroke: "#9b6b46"
					}),
					/* @__PURE__ */ h("path", {
						d: "M3-42Q-8-57-5-66M23-43Q31-52 33-60",
						fill: "none",
						stroke: "#998c4f"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-6-62L-9-70L-3-67L-1-73L2-62M30-57L30-68L35-64L40-68L35-56",
						fill: "#d9ca7d"
					})
				]
			}),
			e === 21 && /* @__PURE__ */ g("g", {
				transform: "translate(150 108)",
				children: [
					/* @__PURE__ */ h("path", {
						d: "M-13-34Q22-44 32-18Q39 15 13 44Q4 54-15 57Q1 28-6 8Q-18-2-13-34Z",
						fill: "#4d514c"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-10-29Q10-31 17-17Q24 10 7 37L-7 49Q7 19-2 0Z",
						fill: "#74796b"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-14-34Q-22-56-4-59Q11-63 21-44L33-40L27-22L15-30L4-22L-3-31Z",
						fill: "#807c62"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-9-41L-1-47L10-42M16-43L21-33M-2-30L0-40",
						fill: "none",
						stroke: "#b4a37c"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-11-44Q-76-55-78-31Q-77-15-16-30M23-42Q78-57 80-31Q81-13 30-26",
						fill: "none",
						stroke: "#6d573d",
						strokeWidth: "3"
					})
				]
			}),
			e === 22 && /* @__PURE__ */ g("g", {
				transform: "translate(147 112) rotate(36)",
				children: [
					/* @__PURE__ */ h("path", {
						d: "M-8-58Q-2-64 5-59L9 52Q7 63 0 63Q-6 61-6 53Z",
						fill: "#895638"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-4-54L0 53M6-18L8 40",
						stroke: "#bd8855"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-27-47Q6-66 34-48L30-25Q12-38-18-27Z",
						fill: "#6c786d"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-27-47Q6-60 34-48L31-41Q7-51-25-39Z",
						fill: "#a3aa91"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-18-27L-14-33Q6-40 30-25L27-21Q3-33-18-27Z",
						fill: "#4c5d55"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-13-47L13-18M-14-39L13-12M-14-31L11-6M-10-50L14-27",
						stroke: "#dbc58a",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-5 40L4 44M-5 47L4 51",
						stroke: "#b59c68"
					})
				]
			}),
			e === 23 && /* @__PURE__ */ g("g", {
				transform: "translate(150 121) rotate(-12)",
				children: [
					/* @__PURE__ */ h("path", {
						d: "M-65 3Q-60-29-8-33Q45-37 65-10L65 7Q52 31 0 33Q-58 33-65 3Z",
						fill: "#4a6662"
					}),
					/* @__PURE__ */ h("ellipse", {
						cy: "-3",
						rx: "64",
						ry: "28",
						fill: "#78948a"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-49-4Q-31-29-5-16Q24 4 47-14Q60-22 53-3Q35 25 6 11Q-19-5-43 9Q-57 15-49-4Z",
						fill: "#45615b"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-46-6Q-32-21-13-14Q2-9 9 0Q20 11 36-2Q48-11 52-7M-39 11Q-24-3-8 5",
						fill: "none",
						stroke: "#b1c3a3",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-59 10Q-19 34 35 19M-24-27L-12-30M42 11L51 6",
						fill: "none",
						stroke: "#a2b8a5"
					})
				]
			}),
			e === 24 && /* @__PURE__ */ g("g", {
				transform: "translate(153 109)",
				children: [
					/* @__PURE__ */ h("path", {
						d: "M-22-22Q-32-9-26 8L-29 22Q-44 30-37 48Q-30 62-9 63L28 59Q40 44 29 28L22 7L25-16Z",
						fill: `url(#${a})`
					}),
					/* @__PURE__ */ h("path", {
						d: "M-23-38Q-25-62-5-65Q17-68 25-48Q34-26 20-11L3-5L-14-15L-27-19L-30-25L-23-30Z",
						fill: `url(#${a})`
					}),
					/* @__PURE__ */ h("path", {
						d: "M-21-45Q-10-55 0-45L-1-37L-13-35L-14-27L-25-25L-24-30L-20-32Z",
						fill: "#617e74"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-21-40L-12-42L-7-39",
						fill: "none",
						stroke: "#233a32",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-16-34L-21-28L-31-24Q-35-19-26-18L-15-17L-11-20Z",
						fill: "#84988a"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-26-13Q-10-16-4-10L-11-6L-25-7L-30-10Z",
						fill: "#92a092"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-26-7L-14-6M-19-2Q-7 3 6-2",
						stroke: "#263d35",
						fill: "none"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-10 4Q-31 3-33 16Q-34 29-20 31L-12 27L1 29Q19 29 25 19L19 9Q3 5-10 4Z",
						fill: `url(#${a})`
					}),
					/* @__PURE__ */ h("path", {
						d: "M-27 13Q-20 9-10 14Q-7 19-11 24M-6 13Q7 8 18 15",
						fill: "none",
						stroke: "#90a396",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-27 14Q-36 26-28 37L-11 43Q0 42-4 35L-18 28L-17 19M20 14Q33 25 24 37L6 43Q-3 41 2 34L16 27L12 19",
						fill: `url(#${a})`
					}),
					/* @__PURE__ */ h("path", {
						d: "M-23 20Q-28 28-18 32M19 22Q22 29 11 33",
						fill: "none",
						stroke: "#92a497",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-17 39Q-36 36-38 49Q-39 59-23 63L-8 58L-3 47ZM10 39Q30 34 34 47Q39 57 24 62L5 57L0 47Z",
						fill: `url(#${a})`
					}),
					/* @__PURE__ */ h("path", {
						d: "M-30 45Q-20 40-12 47M14 45Q24 39 29 46M-29 56L-19 56M17 56L25 55",
						stroke: "#82988c",
						fill: "none",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-8 57L-8 65L-28 66Q-37 63-28 60ZM13 56L16 64L29 64Q37 60 29 58Z",
						fill: "#425d51"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-3-60Q8-62 14-53M-21-52L-16-55",
						stroke: "#9caca1",
						fill: "none",
						strokeWidth: "2"
					})
				]
			}),
			e === 25 && /* @__PURE__ */ g("g", {
				transform: "translate(149 111) rotate(-27)",
				children: [
					/* @__PURE__ */ h("path", {
						d: "M-99 5L-30-2L-20 3L-29 7L-97 11Q-106 11-104 7Z",
						fill: "#75432d"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-96 6L-31 1",
						stroke: "#b47648",
						fill: "none"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-29-8Q-34 0-29 13L-13 18L-7-15Z",
						fill: "#5c3d2d"
					}),
					/* @__PURE__ */ h("path", {
						d: "M-24-12L-27-17L-19-19L-20-24L-11-24L-7-29L0-27L7-31L12-28L20-30L26-26L34-28L40-24L49-25L56-21L64-22L70-17L77-17L78-10L84-6L81 1L84 7L78 12L79 18L72 20L67 25L60 24L54 29L46 27L40 31L33 28L25 31L18 28L10 31L3 28L-5 30L-9 24L-18 25L-19 20L-26 17Q-17 0-24-12Z",
						fill: `url(#${o})`,
						stroke: "#b28d73"
					}),
					Array.from({ length: 10 }, (e, t) => {
						let n = -18 + t * 9, r = (t % 3 - 1) * 2;
						return /* @__PURE__ */ g("g", {
							fill: "none",
							strokeLinecap: "round",
							children: [
								/* @__PURE__ */ h("path", {
									d: `M${n} ${-18 + r}Q${n + 15} ${-6 + r} ${n + 5} ${22 + r}M${n + 3} ${-22 + r}Q${n + 18} ${-4 + r} ${n + 9} ${19 + r}`,
									stroke: t % 2 ? "#e8cdb2" : "#d5b092",
									strokeWidth: "4"
								}),
								/* @__PURE__ */ h("path", {
									d: `M${n + 2} ${-15 + r}Q${n + 12} ${-2 + r} ${n + 4} ${20 + r}M${n + 5} -7l7-7m-6 16l8-6m-10 13l8-3`,
									stroke: "#a98169",
									strokeWidth: ".8"
								}),
								/* @__PURE__ */ h("path", {
									d: `M${n} ${-18 + r}l-3-5m6 7l1-6m-2 29l-4 9m6-5l1 8`,
									stroke: "#f1dcc4",
									strokeWidth: "1.2"
								})
							]
						}, t);
					}),
					/* @__PURE__ */ h("path", {
						d: "M-21-12Q-12 0-23 18M74-14Q85-2 74 15",
						stroke: "#e3c0a2",
						fill: "none",
						strokeWidth: "2"
					})
				]
			})
		]
	});
}
//#endregion
//#region src/games/palmisland/scenery.tsx
var Ge = /* #__PURE__ */ Object.assign({
	"./assets/canoe-0.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='320'%20viewBox='0%200%20400%20320'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(301%20163)%20scale(0.51)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3c/g%3e%3cg%20stroke='%23645039'%20stroke-linejoin='round'%3e%3cpath%20d='M77%20243Q164%20268%20303%20222Q286%20262%20198%20277Q111%20287%2077%20243Z'%20fill='%23a27746'%20stroke-width='3'/%3e%3cpath%20d='M77%20243Q163%20263%20303%20222Q253%20252%20173%20261Q111%20262%2077%20243'%20fill='%235c573a'%20stroke-width='1.6'/%3e%3cpath%20d='M81%20244Q164%20264%20296%20226'%20fill='none'%20stroke='%23dfba76'%20stroke-width='4'/%3e%3cpath%20d='M95%20254Q173%20278%20284%20241'%20fill='none'%20stroke='%23c59b5f'%20stroke-width='2'/%3e%3cpath%20d='M134%20256L135%20272M207%20255L213%20271M267%20240L275%20254'%20stroke-width='3'/%3e%3cpath%20d='M120%20254L134%20249L158%20255L146%20260ZM215%20243L226%20239L247%20242L235%20247Z'%20fill='%23ba955e'%20stroke-width='1'/%3e%3cpath%20d='M195%20203L284%20286'%20stroke='%236f5739'%20stroke-width='5'/%3e%3cpath%20d='M271%20271Q291%20278%20301%20297Q279%20293%20269%20280Z'%20fill='%23a37c44'%20stroke-width='2'/%3e%3cpath%20d='M193%20203L208%20216'%20stroke='%23d6b57b'%20stroke-width='1.5'/%3e%3cpath%20d='M92%20223Q97%20210%20105%20222L110%20233L88%20237Z'%20fill='%23d4b178'%20stroke-width='1.4'/%3e%3cpath%20d='M90%20230L108%20226M95%20218L101%20234'%20stroke='%23a18552'%20stroke-width='1'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3c/svg%3e",
	"./assets/canoe-1.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='320'%20viewBox='0%200%20400%20320'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(301%20163)%20scale(0.51)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3cpath%20d='M-61%207L-60-13L-32-14M-64-15L-30-17L-27-9L-64-8Z'%20fill='%23bf9853'%20stroke='%23705a35'%20stroke-width='1.5'/%3e%3cpath%20d='M-64-13L-29-14'%20stroke='%23e2c78c'/%3e%3cpath%20d='M-60-8L-61%2028'%20stroke='%237b643d'%20stroke-width='3'/%3e%3c/g%3e%3cg%20stroke='%23645039'%20stroke-linejoin='round'%3e%3cpath%20d='M77%20243Q164%20268%20303%20222Q286%20262%20198%20277Q111%20287%2077%20243Z'%20fill='%23a27746'%20stroke-width='3'/%3e%3cpath%20d='M77%20243Q163%20263%20303%20222Q253%20252%20173%20261Q111%20262%2077%20243'%20fill='%235c573a'%20stroke-width='1.6'/%3e%3cpath%20d='M81%20244Q164%20264%20296%20226'%20fill='none'%20stroke='%23dfba76'%20stroke-width='4'/%3e%3cpath%20d='M95%20254Q173%20278%20284%20241'%20fill='none'%20stroke='%23c59b5f'%20stroke-width='2'/%3e%3cpath%20d='M134%20256L135%20272M207%20255L213%20271M267%20240L275%20254'%20stroke-width='3'/%3e%3cpath%20d='M120%20254L134%20249L158%20255L146%20260ZM215%20243L226%20239L247%20242L235%20247Z'%20fill='%23ba955e'%20stroke-width='1'/%3e%3cpath%20d='M195%20203L284%20286'%20stroke='%236f5739'%20stroke-width='5'/%3e%3cpath%20d='M271%20271Q291%20278%20301%20297Q279%20293%20269%20280Z'%20fill='%23a37c44'%20stroke-width='2'/%3e%3cpath%20d='M193%20203L208%20216'%20stroke='%23d6b57b'%20stroke-width='1.5'/%3e%3cpath%20d='M92%20223Q97%20210%20105%20222L110%20233L88%20237Z'%20fill='%23d4b178'%20stroke-width='1.4'/%3e%3cpath%20d='M90%20230L108%20226M95%20218L101%20234'%20stroke='%23a18552'%20stroke-width='1'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3c/svg%3e",
	"./assets/canoe-2.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='320'%20viewBox='0%200%20400%20320'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(301%20163)%20scale(0.51)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3cpath%20d='M-61%207L-60-13L-32-14M-64-15L-30-17L-27-9L-64-8Z'%20fill='%23bf9853'%20stroke='%23705a35'%20stroke-width='1.5'/%3e%3cpath%20d='M-64-13L-29-14'%20stroke='%23e2c78c'/%3e%3cpath%20d='M-60-8L-61%2028'%20stroke='%237b643d'%20stroke-width='3'/%3e%3cpath%20d='M88%2046L103%2042L110%2056L91%2061Z'%20fill='%239ba893'%20stroke='%23526b55'/%3e%3cpath%20d='M90%2046L99%2051L103%2042'%20fill='none'%20stroke='%23d3d7b8'/%3e%3c/g%3e%3cg%20stroke='%23645039'%20stroke-linejoin='round'%3e%3cpath%20d='M77%20243Q164%20268%20303%20222Q286%20262%20198%20277Q111%20287%2077%20243Z'%20fill='%23a27746'%20stroke-width='3'/%3e%3cpath%20d='M77%20243Q163%20263%20303%20222Q253%20252%20173%20261Q111%20262%2077%20243'%20fill='%235c573a'%20stroke-width='1.6'/%3e%3cpath%20d='M81%20244Q164%20264%20296%20226'%20fill='none'%20stroke='%23dfba76'%20stroke-width='4'/%3e%3cpath%20d='M95%20254Q173%20278%20284%20241'%20fill='none'%20stroke='%23c59b5f'%20stroke-width='2'/%3e%3cpath%20d='M134%20256L135%20272M207%20255L213%20271M267%20240L275%20254'%20stroke-width='3'/%3e%3cpath%20d='M120%20254L134%20249L158%20255L146%20260ZM215%20243L226%20239L247%20242L235%20247Z'%20fill='%23ba955e'%20stroke-width='1'/%3e%3cpath%20d='M195%20203L284%20286'%20stroke='%236f5739'%20stroke-width='5'/%3e%3cpath%20d='M271%20271Q291%20278%20301%20297Q279%20293%20269%20280Z'%20fill='%23a37c44'%20stroke-width='2'/%3e%3cpath%20d='M193%20203L208%20216'%20stroke='%23d6b57b'%20stroke-width='1.5'/%3e%3cpath%20d='M92%20223Q97%20210%20105%20222L110%20233L88%20237Z'%20fill='%23d4b178'%20stroke-width='1.4'/%3e%3cpath%20d='M90%20230L108%20226M95%20218L101%20234'%20stroke='%23a18552'%20stroke-width='1'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3c/svg%3e",
	"./assets/canoe-3.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='320'%20viewBox='0%200%20400%20320'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(301%20163)%20scale(0.51)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3cpath%20d='M-61%207L-60-13L-32-14M-64-15L-30-17L-27-9L-64-8Z'%20fill='%23bf9853'%20stroke='%23705a35'%20stroke-width='1.5'/%3e%3cpath%20d='M-64-13L-29-14'%20stroke='%23e2c78c'/%3e%3cpath%20d='M-60-8L-61%2028'%20stroke='%237b643d'%20stroke-width='3'/%3e%3cpath%20d='M88%2046L103%2042L110%2056L91%2061Z'%20fill='%239ba893'%20stroke='%23526b55'/%3e%3cpath%20d='M90%2046L99%2051L103%2042'%20fill='none'%20stroke='%23d3d7b8'/%3e%3c/g%3e%3cg%20stroke='%23645039'%20stroke-linejoin='round'%3e%3cpath%20d='M77%20243Q164%20268%20303%20222Q286%20262%20198%20277Q111%20287%2077%20243Z'%20fill='%23a27746'%20stroke-width='3'/%3e%3cpath%20d='M77%20243Q163%20263%20303%20222Q253%20252%20173%20261Q111%20262%2077%20243'%20fill='%235c573a'%20stroke-width='1.6'/%3e%3cpath%20d='M81%20244Q164%20264%20296%20226'%20fill='none'%20stroke='%23dfba76'%20stroke-width='4'/%3e%3cpath%20d='M95%20254Q173%20278%20284%20241'%20fill='none'%20stroke='%23c59b5f'%20stroke-width='2'/%3e%3cpath%20d='M134%20256L135%20272M207%20255L213%20271M267%20240L275%20254'%20stroke-width='3'/%3e%3cpath%20d='M120%20254L134%20249L158%20255L146%20260ZM215%20243L226%20239L247%20242L235%20247Z'%20fill='%23ba955e'%20stroke-width='1'/%3e%3cpath%20d='M195%20203L284%20286'%20stroke='%236f5739'%20stroke-width='5'/%3e%3cpath%20d='M271%20271Q291%20278%20301%20297Q279%20293%20269%20280Z'%20fill='%23a37c44'%20stroke-width='2'/%3e%3cpath%20d='M193%20203L208%20216'%20stroke='%23d6b57b'%20stroke-width='1.5'/%3e%3cpath%20d='M92%20223Q97%20210%20105%20222L110%20233L88%20237Z'%20fill='%23d4b178'%20stroke-width='1.4'/%3e%3cpath%20d='M90%20230L108%20226M95%20218L101%20234'%20stroke='%23a18552'%20stroke-width='1'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%23645039'%20stroke-linejoin='round'%3e%3cpath%20d='M41%20252Q84%20266%20138%20245Q124%20271%2081%20275Q52%20271%2041%20252Z'%20fill='%23a27746'%20stroke-width='2'/%3e%3cpath%20d='M44%20253Q87%20268%20135%20247'%20fill='none'%20stroke='%23dfba76'%20stroke-width='3'/%3e%3cpath%20d='M67%20263L69%20272M106%20258L109%20268'%20stroke-width='2'/%3e%3cpath%20d='M40%20248V280M37%20252Q29%20236%2045%20236Q56%20241%2042%20252'%20fill='none'%20stroke='%239a8353'%20stroke-width='2'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/card-canoe-0.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='420'%20viewBox='0%200%20400%20420'%3e%3cpath%20d='M0%200H400V420H0Z'%20fill='%23a8d3cb'/%3e%3cpath%20d='M0%20370H400V420H0Z'%20fill='%23cfba87'/%3e%3cg%20transform='translate(0%2060)'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(301%20163)%20scale(0.51)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3c/g%3e%3cg%20stroke='%23645039'%20stroke-linejoin='round'%3e%3cpath%20d='M77%20243Q164%20268%20303%20222Q286%20262%20198%20277Q111%20287%2077%20243Z'%20fill='%23a27746'%20stroke-width='3'/%3e%3cpath%20d='M77%20243Q163%20263%20303%20222Q253%20252%20173%20261Q111%20262%2077%20243'%20fill='%235c573a'%20stroke-width='1.6'/%3e%3cpath%20d='M81%20244Q164%20264%20296%20226'%20fill='none'%20stroke='%23dfba76'%20stroke-width='4'/%3e%3cpath%20d='M95%20254Q173%20278%20284%20241'%20fill='none'%20stroke='%23c59b5f'%20stroke-width='2'/%3e%3cpath%20d='M134%20256L135%20272M207%20255L213%20271M267%20240L275%20254'%20stroke-width='3'/%3e%3cpath%20d='M120%20254L134%20249L158%20255L146%20260ZM215%20243L226%20239L247%20242L235%20247Z'%20fill='%23ba955e'%20stroke-width='1'/%3e%3cpath%20d='M195%20203L284%20286'%20stroke='%236f5739'%20stroke-width='5'/%3e%3cpath%20d='M271%20271Q291%20278%20301%20297Q279%20293%20269%20280Z'%20fill='%23a37c44'%20stroke-width='2'/%3e%3cpath%20d='M193%20203L208%20216'%20stroke='%23d6b57b'%20stroke-width='1.5'/%3e%3cpath%20d='M92%20223Q97%20210%20105%20222L110%20233L88%20237Z'%20fill='%23d4b178'%20stroke-width='1.4'/%3e%3cpath%20d='M90%20230L108%20226M95%20218L101%20234'%20stroke='%23a18552'%20stroke-width='1'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/card-canoe-1.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='420'%20viewBox='0%200%20400%20420'%3e%3cpath%20d='M0%200H400V420H0Z'%20fill='%23a8d3cb'/%3e%3cpath%20d='M0%20370H400V420H0Z'%20fill='%23cfba87'/%3e%3cg%20transform='translate(0%2060)'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(301%20163)%20scale(0.51)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3cpath%20d='M-61%207L-60-13L-32-14M-64-15L-30-17L-27-9L-64-8Z'%20fill='%23bf9853'%20stroke='%23705a35'%20stroke-width='1.5'/%3e%3cpath%20d='M-64-13L-29-14'%20stroke='%23e2c78c'/%3e%3cpath%20d='M-60-8L-61%2028'%20stroke='%237b643d'%20stroke-width='3'/%3e%3c/g%3e%3cg%20stroke='%23645039'%20stroke-linejoin='round'%3e%3cpath%20d='M77%20243Q164%20268%20303%20222Q286%20262%20198%20277Q111%20287%2077%20243Z'%20fill='%23a27746'%20stroke-width='3'/%3e%3cpath%20d='M77%20243Q163%20263%20303%20222Q253%20252%20173%20261Q111%20262%2077%20243'%20fill='%235c573a'%20stroke-width='1.6'/%3e%3cpath%20d='M81%20244Q164%20264%20296%20226'%20fill='none'%20stroke='%23dfba76'%20stroke-width='4'/%3e%3cpath%20d='M95%20254Q173%20278%20284%20241'%20fill='none'%20stroke='%23c59b5f'%20stroke-width='2'/%3e%3cpath%20d='M134%20256L135%20272M207%20255L213%20271M267%20240L275%20254'%20stroke-width='3'/%3e%3cpath%20d='M120%20254L134%20249L158%20255L146%20260ZM215%20243L226%20239L247%20242L235%20247Z'%20fill='%23ba955e'%20stroke-width='1'/%3e%3cpath%20d='M195%20203L284%20286'%20stroke='%236f5739'%20stroke-width='5'/%3e%3cpath%20d='M271%20271Q291%20278%20301%20297Q279%20293%20269%20280Z'%20fill='%23a37c44'%20stroke-width='2'/%3e%3cpath%20d='M193%20203L208%20216'%20stroke='%23d6b57b'%20stroke-width='1.5'/%3e%3cpath%20d='M92%20223Q97%20210%20105%20222L110%20233L88%20237Z'%20fill='%23d4b178'%20stroke-width='1.4'/%3e%3cpath%20d='M90%20230L108%20226M95%20218L101%20234'%20stroke='%23a18552'%20stroke-width='1'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/card-canoe-2.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='420'%20viewBox='0%200%20400%20420'%3e%3cpath%20d='M0%200H400V420H0Z'%20fill='%23a8d3cb'/%3e%3cpath%20d='M0%20370H400V420H0Z'%20fill='%23cfba87'/%3e%3cg%20transform='translate(0%2060)'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(301%20163)%20scale(0.51)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3cpath%20d='M-61%207L-60-13L-32-14M-64-15L-30-17L-27-9L-64-8Z'%20fill='%23bf9853'%20stroke='%23705a35'%20stroke-width='1.5'/%3e%3cpath%20d='M-64-13L-29-14'%20stroke='%23e2c78c'/%3e%3cpath%20d='M-60-8L-61%2028'%20stroke='%237b643d'%20stroke-width='3'/%3e%3cpath%20d='M88%2046L103%2042L110%2056L91%2061Z'%20fill='%239ba893'%20stroke='%23526b55'/%3e%3cpath%20d='M90%2046L99%2051L103%2042'%20fill='none'%20stroke='%23d3d7b8'/%3e%3c/g%3e%3cg%20stroke='%23645039'%20stroke-linejoin='round'%3e%3cpath%20d='M77%20243Q164%20268%20303%20222Q286%20262%20198%20277Q111%20287%2077%20243Z'%20fill='%23a27746'%20stroke-width='3'/%3e%3cpath%20d='M77%20243Q163%20263%20303%20222Q253%20252%20173%20261Q111%20262%2077%20243'%20fill='%235c573a'%20stroke-width='1.6'/%3e%3cpath%20d='M81%20244Q164%20264%20296%20226'%20fill='none'%20stroke='%23dfba76'%20stroke-width='4'/%3e%3cpath%20d='M95%20254Q173%20278%20284%20241'%20fill='none'%20stroke='%23c59b5f'%20stroke-width='2'/%3e%3cpath%20d='M134%20256L135%20272M207%20255L213%20271M267%20240L275%20254'%20stroke-width='3'/%3e%3cpath%20d='M120%20254L134%20249L158%20255L146%20260ZM215%20243L226%20239L247%20242L235%20247Z'%20fill='%23ba955e'%20stroke-width='1'/%3e%3cpath%20d='M195%20203L284%20286'%20stroke='%236f5739'%20stroke-width='5'/%3e%3cpath%20d='M271%20271Q291%20278%20301%20297Q279%20293%20269%20280Z'%20fill='%23a37c44'%20stroke-width='2'/%3e%3cpath%20d='M193%20203L208%20216'%20stroke='%23d6b57b'%20stroke-width='1.5'/%3e%3cpath%20d='M92%20223Q97%20210%20105%20222L110%20233L88%20237Z'%20fill='%23d4b178'%20stroke-width='1.4'/%3e%3cpath%20d='M90%20230L108%20226M95%20218L101%20234'%20stroke='%23a18552'%20stroke-width='1'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/card-canoe-3.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='420'%20viewBox='0%200%20400%20420'%3e%3cpath%20d='M0%200H400V420H0Z'%20fill='%23a8d3cb'/%3e%3cpath%20d='M0%20370H400V420H0Z'%20fill='%23cfba87'/%3e%3cg%20transform='translate(0%2060)'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(301%20163)%20scale(0.51)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3cpath%20d='M-61%207L-60-13L-32-14M-64-15L-30-17L-27-9L-64-8Z'%20fill='%23bf9853'%20stroke='%23705a35'%20stroke-width='1.5'/%3e%3cpath%20d='M-64-13L-29-14'%20stroke='%23e2c78c'/%3e%3cpath%20d='M-60-8L-61%2028'%20stroke='%237b643d'%20stroke-width='3'/%3e%3cpath%20d='M88%2046L103%2042L110%2056L91%2061Z'%20fill='%239ba893'%20stroke='%23526b55'/%3e%3cpath%20d='M90%2046L99%2051L103%2042'%20fill='none'%20stroke='%23d3d7b8'/%3e%3c/g%3e%3cg%20stroke='%23645039'%20stroke-linejoin='round'%3e%3cpath%20d='M77%20243Q164%20268%20303%20222Q286%20262%20198%20277Q111%20287%2077%20243Z'%20fill='%23a27746'%20stroke-width='3'/%3e%3cpath%20d='M77%20243Q163%20263%20303%20222Q253%20252%20173%20261Q111%20262%2077%20243'%20fill='%235c573a'%20stroke-width='1.6'/%3e%3cpath%20d='M81%20244Q164%20264%20296%20226'%20fill='none'%20stroke='%23dfba76'%20stroke-width='4'/%3e%3cpath%20d='M95%20254Q173%20278%20284%20241'%20fill='none'%20stroke='%23c59b5f'%20stroke-width='2'/%3e%3cpath%20d='M134%20256L135%20272M207%20255L213%20271M267%20240L275%20254'%20stroke-width='3'/%3e%3cpath%20d='M120%20254L134%20249L158%20255L146%20260ZM215%20243L226%20239L247%20242L235%20247Z'%20fill='%23ba955e'%20stroke-width='1'/%3e%3cpath%20d='M195%20203L284%20286'%20stroke='%236f5739'%20stroke-width='5'/%3e%3cpath%20d='M271%20271Q291%20278%20301%20297Q279%20293%20269%20280Z'%20fill='%23a37c44'%20stroke-width='2'/%3e%3cpath%20d='M193%20203L208%20216'%20stroke='%23d6b57b'%20stroke-width='1.5'/%3e%3cpath%20d='M92%20223Q97%20210%20105%20222L110%20233L88%20237Z'%20fill='%23d4b178'%20stroke-width='1.4'/%3e%3cpath%20d='M90%20230L108%20226M95%20218L101%20234'%20stroke='%23a18552'%20stroke-width='1'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%23645039'%20stroke-linejoin='round'%3e%3cpath%20d='M41%20252Q84%20266%20138%20245Q124%20271%2081%20275Q52%20271%2041%20252Z'%20fill='%23a27746'%20stroke-width='2'/%3e%3cpath%20d='M44%20253Q87%20268%20135%20247'%20fill='none'%20stroke='%23dfba76'%20stroke-width='3'/%3e%3cpath%20d='M67%20263L69%20272M106%20258L109%20268'%20stroke-width='2'/%3e%3cpath%20d='M40%20248V280M37%20252Q29%20236%2045%20236Q56%20241%2042%20252'%20fill='none'%20stroke='%239a8353'%20stroke-width='2'/%3e%3c/g%3e%3c/g%3e%3c/svg%3e",
	"./assets/card-housing-0.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='420'%20viewBox='0%200%20400%20420'%3e%3cpath%20d='M0%200H400V420H0Z'%20fill='%23a8d3cb'/%3e%3cpath%20d='M0%20370H400V420H0Z'%20fill='%23cfba87'/%3e%3cg%20transform='translate(0%2060)'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(187%20185)%20scale(1.2)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/card-housing-1.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='420'%20viewBox='0%200%20400%20420'%3e%3cpath%20d='M0%200H400V420H0Z'%20fill='%23a8d3cb'/%3e%3cpath%20d='M0%20370H400V420H0Z'%20fill='%23cfba87'/%3e%3cg%20transform='translate(0%2060)'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(187%20185)%20scale(1.2)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3cpath%20d='M-61%207L-60-13L-32-14M-64-15L-30-17L-27-9L-64-8Z'%20fill='%23bf9853'%20stroke='%23705a35'%20stroke-width='1.5'/%3e%3cpath%20d='M-64-13L-29-14'%20stroke='%23e2c78c'/%3e%3cpath%20d='M-60-8L-61%2028'%20stroke='%237b643d'%20stroke-width='3'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/card-housing-2.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='420'%20viewBox='0%200%20400%20420'%3e%3cpath%20d='M0%200H400V420H0Z'%20fill='%23a8d3cb'/%3e%3cpath%20d='M0%20370H400V420H0Z'%20fill='%23cfba87'/%3e%3cg%20transform='translate(0%2060)'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(187%20185)%20scale(1.2)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3cpath%20d='M-61%207L-60-13L-32-14M-64-15L-30-17L-27-9L-64-8Z'%20fill='%23bf9853'%20stroke='%23705a35'%20stroke-width='1.5'/%3e%3cpath%20d='M-64-13L-29-14'%20stroke='%23e2c78c'/%3e%3cpath%20d='M-60-8L-61%2028'%20stroke='%237b643d'%20stroke-width='3'/%3e%3cpath%20d='M88%2046L103%2042L110%2056L91%2061Z'%20fill='%239ba893'%20stroke='%23526b55'/%3e%3cpath%20d='M90%2046L99%2051L103%2042'%20fill='none'%20stroke='%23d3d7b8'/%3e%3c/g%3e%3cg%20transform='translate(312%20205)%20scale(0.48)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/card-housing-3.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='420'%20viewBox='0%200%20400%20420'%3e%3cpath%20d='M0%200H400V420H0Z'%20fill='%23a8d3cb'/%3e%3cpath%20d='M0%20370H400V420H0Z'%20fill='%23cfba87'/%3e%3cg%20transform='translate(0%2060)'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(187%20185)%20scale(1.2)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3cpath%20d='M-61%207L-60-13L-32-14M-64-15L-30-17L-27-9L-64-8Z'%20fill='%23bf9853'%20stroke='%23705a35'%20stroke-width='1.5'/%3e%3cpath%20d='M-64-13L-29-14'%20stroke='%23e2c78c'/%3e%3cpath%20d='M-60-8L-61%2028'%20stroke='%237b643d'%20stroke-width='3'/%3e%3cpath%20d='M88%2046L103%2042L110%2056L91%2061Z'%20fill='%239ba893'%20stroke='%23526b55'/%3e%3cpath%20d='M90%2046L99%2051L103%2042'%20fill='none'%20stroke='%23d3d7b8'/%3e%3c/g%3e%3cg%20transform='translate(312%20205)%20scale(0.48)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%23675239'%20stroke-linejoin='round'%3e%3cpath%20d='M49%20275L121%20252L169%20269L96%20293Z'%20fill='%23ad8851'%20stroke-width='2'/%3e%3cpath%20d='M49%20275V302M96%20293V314M169%20269V292M50%20258V279M96%20274V294M169%20252V273M49%20259L96%20275L169%20252'%20fill='none'%20stroke-width='3'/%3e%3cpath%20d='M61%20275L132%20256M73%20280L144%20260M85%20285L156%20265'%20stroke='%23d0b57b'%20stroke-width='1.3'/%3e%3c/g%3e%3c/g%3e%3c/svg%3e",
	"./assets/card-logger-0.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='420'%20viewBox='0%200%20400%20420'%3e%3cpath%20d='M0%200H400V420H0Z'%20fill='%23a8d3cb'/%3e%3cpath%20d='M0%20370H400V420H0Z'%20fill='%23cfba87'/%3e%3cg%20transform='translate(0%2060)'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(60%20130)%20scale(0.7%200.7)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%23625038'%20stroke-linejoin='round'%3e%3cg%20stroke-width='3'%3e%3cpath%20d='M70%20233L195%20184L222%20215L96%20261Z'%20fill='%238e6741'/%3e%3cpath%20d='M90%20234L203%20194M106%20248L211%20207'%20stroke='%23b69660'%20stroke-width='1.2'/%3e%3cellipse%20cx='96'%20cy='246'%20rx='23'%20ry='18'%20fill='%23d0b37a'/%3e%3cellipse%20cx='96'%20cy='246'%20rx='16'%20ry='12'%20fill='none'%20stroke='%239b7c49'%20stroke-width='1.2'/%3e%3cellipse%20cx='97'%20cy='246'%20rx='9'%20ry='7'%20fill='none'%20stroke='%23b09259'%20stroke-width='1'/%3e%3cpath%20d='M95%20242L98%20250M102%20251L106%20256M83%20240L78%20236'%20stroke-width='1'/%3e%3c/g%3e%3cpath%20d='M142%20213L157%20239M149%20210L164%20236'%20stroke='%23d4bb87'%20stroke-width='3'/%3e%3cpath%20d='M138%20212L160%20239'%20stroke='%23846c44'%20stroke-width='1'/%3e%3cg%20fill='none'%20stroke='%23715e3c'%20stroke-width='6'%3e%3cpath%20d='M248%20199L228%20264M247%20200L274%20262M229%20219L268%20218M231%20255L268%20227'/%3e%3c/g%3e%3cpath%20d='M215%20212L270%20170L283%20179L227%20222Z'%20fill='%23b8c8bb'%20stroke-width='2'/%3e%3cpath%20d='M219%20215L225%20215L226%20211L231%20211L231%20207L236%20207L236%20202L242%20202L242%20197L247%20198L248%20193L253%20193L253%20188L260%20189L262%20184'%20fill='none'%20stroke='%236a7e6c'%20stroke-width='1.1'/%3e%3cpath%20d='M273%20173L288%20165L295%20173L282%20182Z'%20fill='%23947443'%20stroke-width='2'/%3e%3cpath%20d='M82%20265L152%20238L173%20258L102%20282Z'%20fill='%239b7549'%20stroke-width='1.5'/%3e%3cellipse%20cx='102'%20cy='274'%20rx='14'%20ry='10'%20fill='%23d7b981'%20stroke-width='1.5'/%3e%3cellipse%20cx='102'%20cy='274'%20rx='7'%20ry='5'%20fill='none'%20stroke='%239c7c48'%20stroke-width='1'/%3e%3cpath%20d='M118%20266L128%20263M127%20253L138%20250M148%20251L161%20257'%20stroke='%23c2a06b'%20stroke-width='1'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/card-logger-1.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='420'%20viewBox='0%200%20400%20420'%3e%3cpath%20d='M0%200H400V420H0Z'%20fill='%23a8d3cb'/%3e%3cpath%20d='M0%20370H400V420H0Z'%20fill='%23cfba87'/%3e%3cg%20transform='translate(0%2060)'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(60%20130)%20scale(0.7%200.7)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%23625038'%20stroke-linejoin='round'%3e%3cg%20stroke-width='3'%3e%3cpath%20d='M70%20233L195%20184L222%20215L96%20261Z'%20fill='%238e6741'/%3e%3cpath%20d='M90%20234L203%20194M106%20248L211%20207'%20stroke='%23b69660'%20stroke-width='1.2'/%3e%3cellipse%20cx='96'%20cy='246'%20rx='23'%20ry='18'%20fill='%23d0b37a'/%3e%3cellipse%20cx='96'%20cy='246'%20rx='16'%20ry='12'%20fill='none'%20stroke='%239b7c49'%20stroke-width='1.2'/%3e%3cellipse%20cx='97'%20cy='246'%20rx='9'%20ry='7'%20fill='none'%20stroke='%23b09259'%20stroke-width='1'/%3e%3cpath%20d='M95%20242L98%20250M102%20251L106%20256M83%20240L78%20236'%20stroke-width='1'/%3e%3c/g%3e%3cpath%20d='M142%20213L157%20239M149%20210L164%20236'%20stroke='%23d4bb87'%20stroke-width='3'/%3e%3cpath%20d='M138%20212L160%20239'%20stroke='%23846c44'%20stroke-width='1'/%3e%3cg%20fill='none'%20stroke='%23715e3c'%20stroke-width='6'%3e%3cpath%20d='M248%20199L228%20264M247%20200L274%20262M229%20219L268%20218M231%20255L268%20227'/%3e%3c/g%3e%3cpath%20d='M215%20212L270%20170L283%20179L227%20222Z'%20fill='%23b8c8bb'%20stroke-width='2'/%3e%3cpath%20d='M219%20215L225%20215L226%20211L231%20211L231%20207L236%20207L236%20202L242%20202L242%20197L247%20198L248%20193L253%20193L253%20188L260%20189L262%20184'%20fill='none'%20stroke='%236a7e6c'%20stroke-width='1.1'/%3e%3cpath%20d='M273%20173L288%20165L295%20173L282%20182Z'%20fill='%23947443'%20stroke-width='2'/%3e%3cpath%20d='M82%20265L152%20238L173%20258L102%20282Z'%20fill='%239b7549'%20stroke-width='1.5'/%3e%3cellipse%20cx='102'%20cy='274'%20rx='14'%20ry='10'%20fill='%23d7b981'%20stroke-width='1.5'/%3e%3cellipse%20cx='102'%20cy='274'%20rx='7'%20ry='5'%20fill='none'%20stroke='%239c7c48'%20stroke-width='1'/%3e%3cpath%20d='M118%20266L128%20263M127%20253L138%20250M148%20251L161%20257'%20stroke='%23c2a06b'%20stroke-width='1'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%23645039'%20stroke-linejoin='round'%3e%3cpath%20d='M36%20236V187M102%20221V174M32%20195L106%20180M33%20216L105%20201'%20fill='none'%20stroke-width='5'/%3e%3cpath%20d='M32%20215L97%20195L109%20205L45%20226Z'%20fill='%239b7549'%20stroke-width='1.5'/%3e%3cellipse%20cx='44'%20cy='221'%20rx='10'%20ry='7'%20fill='%23d7b981'/%3e%3cellipse%20cx='44'%20cy='221'%20rx='5'%20ry='3.5'%20fill='none'%20stroke='%239c7c48'/%3e%3cpath%20d='M34%20202L98%20183L109%20193L45%20214Z'%20fill='%238e6741'%20stroke-width='1.5'/%3e%3cellipse%20cx='44'%20cy='209'%20rx='10'%20ry='7'%20fill='%23d7b981'/%3e%3cellipse%20cx='44'%20cy='209'%20rx='5'%20ry='3.5'%20fill='none'%20stroke='%239c7c48'/%3e%3c/g%3e%3c/g%3e%3c/svg%3e",
	"./assets/card-logger-2.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='420'%20viewBox='0%200%20400%20420'%3e%3cpath%20d='M0%200H400V420H0Z'%20fill='%23a8d3cb'/%3e%3cpath%20d='M0%20370H400V420H0Z'%20fill='%23cfba87'/%3e%3cg%20transform='translate(0%2060)'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(60%20130)%20scale(0.7%200.7)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%23625038'%20stroke-linejoin='round'%3e%3cg%20stroke-width='3'%3e%3cpath%20d='M70%20233L195%20184L222%20215L96%20261Z'%20fill='%238e6741'/%3e%3cpath%20d='M90%20234L203%20194M106%20248L211%20207'%20stroke='%23b69660'%20stroke-width='1.2'/%3e%3cellipse%20cx='96'%20cy='246'%20rx='23'%20ry='18'%20fill='%23d0b37a'/%3e%3cellipse%20cx='96'%20cy='246'%20rx='16'%20ry='12'%20fill='none'%20stroke='%239b7c49'%20stroke-width='1.2'/%3e%3cellipse%20cx='97'%20cy='246'%20rx='9'%20ry='7'%20fill='none'%20stroke='%23b09259'%20stroke-width='1'/%3e%3cpath%20d='M95%20242L98%20250M102%20251L106%20256M83%20240L78%20236'%20stroke-width='1'/%3e%3c/g%3e%3cpath%20d='M142%20213L157%20239M149%20210L164%20236'%20stroke='%23d4bb87'%20stroke-width='3'/%3e%3cpath%20d='M138%20212L160%20239'%20stroke='%23846c44'%20stroke-width='1'/%3e%3cg%20fill='none'%20stroke='%23715e3c'%20stroke-width='6'%3e%3cpath%20d='M248%20199L228%20264M247%20200L274%20262M229%20219L268%20218M231%20255L268%20227'/%3e%3c/g%3e%3cpath%20d='M215%20212L270%20170L283%20179L227%20222Z'%20fill='%23b8c8bb'%20stroke-width='2'/%3e%3cpath%20d='M219%20215L225%20215L226%20211L231%20211L231%20207L236%20207L236%20202L242%20202L242%20197L247%20198L248%20193L253%20193L253%20188L260%20189L262%20184'%20fill='none'%20stroke='%236a7e6c'%20stroke-width='1.1'/%3e%3cpath%20d='M273%20173L288%20165L295%20173L282%20182Z'%20fill='%23947443'%20stroke-width='2'/%3e%3cpath%20d='M82%20265L152%20238L173%20258L102%20282Z'%20fill='%239b7549'%20stroke-width='1.5'/%3e%3cellipse%20cx='102'%20cy='274'%20rx='14'%20ry='10'%20fill='%23d7b981'%20stroke-width='1.5'/%3e%3cellipse%20cx='102'%20cy='274'%20rx='7'%20ry='5'%20fill='none'%20stroke='%239c7c48'%20stroke-width='1'/%3e%3cpath%20d='M118%20266L128%20263M127%20253L138%20250M148%20251L161%20257'%20stroke='%23c2a06b'%20stroke-width='1'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%23645039'%20stroke-linejoin='round'%3e%3cpath%20d='M36%20236V187M102%20221V174M32%20195L106%20180M33%20216L105%20201'%20fill='none'%20stroke-width='5'/%3e%3cpath%20d='M32%20215L97%20195L109%20205L45%20226Z'%20fill='%239b7549'%20stroke-width='1.5'/%3e%3cellipse%20cx='44'%20cy='221'%20rx='10'%20ry='7'%20fill='%23d7b981'/%3e%3cellipse%20cx='44'%20cy='221'%20rx='5'%20ry='3.5'%20fill='none'%20stroke='%239c7c48'/%3e%3cpath%20d='M34%20202L98%20183L109%20193L45%20214Z'%20fill='%238e6741'%20stroke-width='1.5'/%3e%3cellipse%20cx='44'%20cy='209'%20rx='10'%20ry='7'%20fill='%23d7b981'/%3e%3cellipse%20cx='44'%20cy='209'%20rx='5'%20ry='3.5'%20fill='none'%20stroke='%239c7c48'/%3e%3c/g%3e%3cg%20stroke='%23675239'%20stroke-linejoin='round'%3e%3cpath%20d='M219%20177V236M299%20176V232M224%20192L241%20177M281%20177L297%20191'%20fill='none'%20stroke-width='4'/%3e%3cpath%20d='M202%20177L249%20142L312%20169L265%20185Z'%20fill='%23cfa450'%20stroke-width='2'/%3e%3cpath%20d='M249%20142L265%20185L312%20169Z'%20fill='%23ac823d'/%3e%3cpath%20d='M216%20171L255%20149M230%20177L261%20156M246%20181L267%20164M269%20181L278%20161M284%20176L289%20167'%20fill='none'%20stroke='%23e7c887'%20stroke-width='1.2'/%3e%3cpath%20d='M203%20177L265%20185L311%20169'%20fill='none'%20stroke-width='3'/%3e%3c/g%3e%3c/g%3e%3c/svg%3e",
	"./assets/card-logger-3.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='420'%20viewBox='0%200%20400%20420'%3e%3cpath%20d='M0%200H400V420H0Z'%20fill='%23a8d3cb'/%3e%3cpath%20d='M0%20370H400V420H0Z'%20fill='%23cfba87'/%3e%3cg%20transform='translate(0%2060)'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(60%20130)%20scale(0.7%200.7)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%23625038'%20stroke-linejoin='round'%3e%3cg%20stroke-width='3'%3e%3cpath%20d='M70%20233L195%20184L222%20215L96%20261Z'%20fill='%238e6741'/%3e%3cpath%20d='M90%20234L203%20194M106%20248L211%20207'%20stroke='%23b69660'%20stroke-width='1.2'/%3e%3cellipse%20cx='96'%20cy='246'%20rx='23'%20ry='18'%20fill='%23d0b37a'/%3e%3cellipse%20cx='96'%20cy='246'%20rx='16'%20ry='12'%20fill='none'%20stroke='%239b7c49'%20stroke-width='1.2'/%3e%3cellipse%20cx='97'%20cy='246'%20rx='9'%20ry='7'%20fill='none'%20stroke='%23b09259'%20stroke-width='1'/%3e%3cpath%20d='M95%20242L98%20250M102%20251L106%20256M83%20240L78%20236'%20stroke-width='1'/%3e%3c/g%3e%3cpath%20d='M142%20213L157%20239M149%20210L164%20236'%20stroke='%23d4bb87'%20stroke-width='3'/%3e%3cpath%20d='M138%20212L160%20239'%20stroke='%23846c44'%20stroke-width='1'/%3e%3cg%20fill='none'%20stroke='%23715e3c'%20stroke-width='6'%3e%3cpath%20d='M248%20199L228%20264M247%20200L274%20262M229%20219L268%20218M231%20255L268%20227'/%3e%3c/g%3e%3cpath%20d='M215%20212L270%20170L283%20179L227%20222Z'%20fill='%23b8c8bb'%20stroke-width='2'/%3e%3cpath%20d='M219%20215L225%20215L226%20211L231%20211L231%20207L236%20207L236%20202L242%20202L242%20197L247%20198L248%20193L253%20193L253%20188L260%20189L262%20184'%20fill='none'%20stroke='%236a7e6c'%20stroke-width='1.1'/%3e%3cpath%20d='M273%20173L288%20165L295%20173L282%20182Z'%20fill='%23947443'%20stroke-width='2'/%3e%3cpath%20d='M82%20265L152%20238L173%20258L102%20282Z'%20fill='%239b7549'%20stroke-width='1.5'/%3e%3cellipse%20cx='102'%20cy='274'%20rx='14'%20ry='10'%20fill='%23d7b981'%20stroke-width='1.5'/%3e%3cellipse%20cx='102'%20cy='274'%20rx='7'%20ry='5'%20fill='none'%20stroke='%239c7c48'%20stroke-width='1'/%3e%3cpath%20d='M118%20266L128%20263M127%20253L138%20250M148%20251L161%20257'%20stroke='%23c2a06b'%20stroke-width='1'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%23645039'%20stroke-linejoin='round'%3e%3cpath%20d='M36%20236V187M102%20221V174M32%20195L106%20180M33%20216L105%20201'%20fill='none'%20stroke-width='5'/%3e%3cpath%20d='M32%20215L97%20195L109%20205L45%20226Z'%20fill='%239b7549'%20stroke-width='1.5'/%3e%3cellipse%20cx='44'%20cy='221'%20rx='10'%20ry='7'%20fill='%23d7b981'/%3e%3cellipse%20cx='44'%20cy='221'%20rx='5'%20ry='3.5'%20fill='none'%20stroke='%239c7c48'/%3e%3cpath%20d='M34%20202L98%20183L109%20193L45%20214Z'%20fill='%238e6741'%20stroke-width='1.5'/%3e%3cellipse%20cx='44'%20cy='209'%20rx='10'%20ry='7'%20fill='%23d7b981'/%3e%3cellipse%20cx='44'%20cy='209'%20rx='5'%20ry='3.5'%20fill='none'%20stroke='%239c7c48'/%3e%3c/g%3e%3cg%20stroke='%23675239'%20stroke-linejoin='round'%3e%3cpath%20d='M219%20177V236M299%20176V232M224%20192L241%20177M281%20177L297%20191'%20fill='none'%20stroke-width='4'/%3e%3cpath%20d='M202%20177L249%20142L312%20169L265%20185Z'%20fill='%23cfa450'%20stroke-width='2'/%3e%3cpath%20d='M249%20142L265%20185L312%20169Z'%20fill='%23ac823d'/%3e%3cpath%20d='M216%20171L255%20149M230%20177L261%20156M246%20181L267%20164M269%20181L278%20161M284%20176L289%20167'%20fill='none'%20stroke='%23e7c887'%20stroke-width='1.2'/%3e%3cpath%20d='M203%20177L265%20185L311%20169'%20fill='none'%20stroke-width='3'/%3e%3c/g%3e%3cg%20stroke-linejoin='round'%3e%3cpath%20d='M106%20196V120M102%20124L180%20119M108%20146L137%20122M105%20197L92%20217M107%20197L121%20210'%20fill='none'%20stroke='%236c5738'%20stroke-width='5'/%3e%3cpath%20d='M107%20125L176%20121'%20stroke='%23b39460'%20stroke-width='1.4'/%3e%3ccircle%20cx='173'%20cy='123'%20r='7'%20fill='%23a1814d'%20stroke='%23615238'%20stroke-width='2'/%3e%3ccircle%20cx='173'%20cy='123'%20r='2'%20fill='%234c5140'/%3e%3cpath%20d='M170%20129V184Q177%20196%20185%20183M176%20129V183'%20fill='none'%20stroke='%23bfa879'%20stroke-width='2'/%3e%3cpath%20d='M163%20184L193%20178L196%20195L169%20203Z'%20fill='%23957445'%20stroke='%235b5038'%20stroke-width='1.5'/%3e%3cpath%20d='M167%20187L193%20182M171%20194L194%20188'%20stroke='%23ccad74'/%3e%3c/g%3e%3c/g%3e%3c/svg%3e",
	"./assets/card-quarry-0.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='420'%20viewBox='0%200%20400%20420'%3e%3cpath%20d='M0%200H400V420H0Z'%20fill='%23a8d3cb'/%3e%3cpath%20d='M0%20370H400V420H0Z'%20fill='%23cfba87'/%3e%3cg%20transform='translate(0%2060)'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%234c6551'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M74%20252L98%20201L132%20169L164%20182L192%20211L218%20200L264%20235L278%20268Z'%20fill='%23819584'/%3e%3cpath%20d='M132%20169L145%20202L113%20223L98%20201ZM145%20202L164%20182L192%20211L171%20235L137%20232Z'%20fill='%23a5b6a0'/%3e%3cpath%20d='M113%20223L137%20232L132%20252L88%20255ZM171%20235L192%20211L218%20200L213%20242L190%20263Z'%20fill='%23667e6d'/%3e%3cpath%20d='M145%20204L161%20215L151%20226M114%20227L125%20239M214%20206L228%20225L243%20231M245%20245L252%20264'%20fill='none'%20stroke='%23c5cfb2'%20stroke-width='2'/%3e%3cpath%20d='M120%20252H191V260H115V269H195V278H112'%20fill='none'%20stroke='%23b7c4a9'%20stroke-width='5'/%3e%3cpath%20d='M243%20256L258%20242L279%20249L286%20270L260%20280L241%20269Z'%20fill='%23b3beaa'/%3e%3cpath%20d='M243%20256L263%20262L279%20249M263%20262L260%20280'%20fill='none'%20stroke='%23728876'/%3e%3cpath%20d='M212%20209L254%20279'%20stroke='%23927048'%20stroke-width='5'/%3e%3cpath%20d='M198%20219Q216%20195%20243%20202'%20fill='none'%20stroke='%234c6254'%20stroke-width='7'/%3e%3cpath%20d='M200%20216Q215%20201%20237%20202'%20fill='none'%20stroke='%23bdc7b6'%20stroke-width='2'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/card-quarry-1.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='420'%20viewBox='0%200%20400%20420'%3e%3cpath%20d='M0%200H400V420H0Z'%20fill='%23a8d3cb'/%3e%3cpath%20d='M0%20370H400V420H0Z'%20fill='%23cfba87'/%3e%3cg%20transform='translate(0%2060)'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%234c6551'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M74%20252L98%20201L132%20169L164%20182L192%20211L218%20200L264%20235L278%20268Z'%20fill='%23819584'/%3e%3cpath%20d='M132%20169L145%20202L113%20223L98%20201ZM145%20202L164%20182L192%20211L171%20235L137%20232Z'%20fill='%23a5b6a0'/%3e%3cpath%20d='M113%20223L137%20232L132%20252L88%20255ZM171%20235L192%20211L218%20200L213%20242L190%20263Z'%20fill='%23667e6d'/%3e%3cpath%20d='M145%20204L161%20215L151%20226M114%20227L125%20239M214%20206L228%20225L243%20231M245%20245L252%20264'%20fill='none'%20stroke='%23c5cfb2'%20stroke-width='2'/%3e%3cpath%20d='M120%20252H191V260H115V269H195V278H112'%20fill='none'%20stroke='%23b7c4a9'%20stroke-width='5'/%3e%3cpath%20d='M243%20256L258%20242L279%20249L286%20270L260%20280L241%20269Z'%20fill='%23b3beaa'/%3e%3cpath%20d='M243%20256L263%20262L279%20249M263%20262L260%20280'%20fill='none'%20stroke='%23728876'/%3e%3cpath%20d='M212%20209L254%20279'%20stroke='%23927048'%20stroke-width='5'/%3e%3cpath%20d='M198%20219Q216%20195%20243%20202'%20fill='none'%20stroke='%234c6254'%20stroke-width='7'/%3e%3cpath%20d='M200%20216Q215%20201%20237%20202'%20fill='none'%20stroke='%23bdc7b6'%20stroke-width='2'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%23526b55'%20stroke-width='1.4'%20stroke-linejoin='round'%3e%3cpath%20d='M47%20260L48%20221L71%20203L92%20209L102%20240L89%20267Z'%20fill='%238fa28b'/%3e%3cpath%20d='M48%20221L71%20203L75%20229L60%20247L47%20260Z'%20fill='%23b7c4a9'/%3e%3cpath%20d='M75%20229L92%20209L102%20240L89%20267L64%20266Z'%20fill='%236b846f'/%3e%3cpath%20d='M47%20245H78V253H61V263H88'%20fill='none'%20stroke='%23d1d3af'%20stroke-width='4'/%3e%3cpath%20d='M74%20211L83%20224M81%20243L90%20254'%20fill='none'%20stroke='%23c2ccb0'/%3e%3c/g%3e%3c/g%3e%3c/svg%3e",
	"./assets/card-quarry-2.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='420'%20viewBox='0%200%20400%20420'%3e%3cpath%20d='M0%200H400V420H0Z'%20fill='%23a8d3cb'/%3e%3cpath%20d='M0%20370H400V420H0Z'%20fill='%23cfba87'/%3e%3cg%20transform='translate(0%2060)'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%234c6551'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M74%20252L98%20201L132%20169L164%20182L192%20211L218%20200L264%20235L278%20268Z'%20fill='%23819584'/%3e%3cpath%20d='M132%20169L145%20202L113%20223L98%20201ZM145%20202L164%20182L192%20211L171%20235L137%20232Z'%20fill='%23a5b6a0'/%3e%3cpath%20d='M113%20223L137%20232L132%20252L88%20255ZM171%20235L192%20211L218%20200L213%20242L190%20263Z'%20fill='%23667e6d'/%3e%3cpath%20d='M145%20204L161%20215L151%20226M114%20227L125%20239M214%20206L228%20225L243%20231M245%20245L252%20264'%20fill='none'%20stroke='%23c5cfb2'%20stroke-width='2'/%3e%3cpath%20d='M120%20252H191V260H115V269H195V278H112'%20fill='none'%20stroke='%23b7c4a9'%20stroke-width='5'/%3e%3cpath%20d='M243%20256L258%20242L279%20249L286%20270L260%20280L241%20269Z'%20fill='%23b3beaa'/%3e%3cpath%20d='M243%20256L263%20262L279%20249M263%20262L260%20280'%20fill='none'%20stroke='%23728876'/%3e%3cpath%20d='M212%20209L254%20279'%20stroke='%23927048'%20stroke-width='5'/%3e%3cpath%20d='M198%20219Q216%20195%20243%20202'%20fill='none'%20stroke='%234c6254'%20stroke-width='7'/%3e%3cpath%20d='M200%20216Q215%20201%20237%20202'%20fill='none'%20stroke='%23bdc7b6'%20stroke-width='2'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%23526b55'%20stroke-width='1.4'%20stroke-linejoin='round'%3e%3cpath%20d='M47%20260L48%20221L71%20203L92%20209L102%20240L89%20267Z'%20fill='%238fa28b'/%3e%3cpath%20d='M48%20221L71%20203L75%20229L60%20247L47%20260Z'%20fill='%23b7c4a9'/%3e%3cpath%20d='M75%20229L92%20209L102%20240L89%20267L64%20266Z'%20fill='%236b846f'/%3e%3cpath%20d='M47%20245H78V253H61V263H88'%20fill='none'%20stroke='%23d1d3af'%20stroke-width='4'/%3e%3cpath%20d='M74%20211L83%20224M81%20243L90%20254'%20fill='none'%20stroke='%23c2ccb0'/%3e%3c/g%3e%3cg%20stroke='%235b6149'%20stroke-linejoin='round'%3e%3cpath%20d='M289%20265L300%20218L324%20216L336%20258M300%20231L332%20244'%20fill='none'%20stroke-width='4'/%3e%3cpath%20d='M293%20226L327%20220'%20stroke='%238a7249'%20stroke-width='7'/%3e%3ccircle%20cx='323'%20cy='222'%20r='12'%20fill='%23a08655'%20stroke-width='2'/%3e%3ccircle%20cx='323'%20cy='222'%20r='6'%20fill='none'%20stroke='%23d2b97c'/%3e%3cpath%20d='M323%20210V234M311%20222H335M330%20231L339%20237'%20stroke-width='2'/%3e%3cpath%20d='M300%20228L291%20266L310%20272'%20fill='none'%20stroke='%23c7b687'%20stroke-width='2'/%3e%3c/g%3e%3c/g%3e%3c/svg%3e",
	"./assets/card-quarry-3.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='420'%20viewBox='0%200%20400%20420'%3e%3cpath%20d='M0%200H400V420H0Z'%20fill='%23a8d3cb'/%3e%3cpath%20d='M0%20370H400V420H0Z'%20fill='%23cfba87'/%3e%3cg%20transform='translate(0%2060)'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%234c6551'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M74%20252L98%20201L132%20169L164%20182L192%20211L218%20200L264%20235L278%20268Z'%20fill='%23819584'/%3e%3cpath%20d='M132%20169L145%20202L113%20223L98%20201ZM145%20202L164%20182L192%20211L171%20235L137%20232Z'%20fill='%23a5b6a0'/%3e%3cpath%20d='M113%20223L137%20232L132%20252L88%20255ZM171%20235L192%20211L218%20200L213%20242L190%20263Z'%20fill='%23667e6d'/%3e%3cpath%20d='M145%20204L161%20215L151%20226M114%20227L125%20239M214%20206L228%20225L243%20231M245%20245L252%20264'%20fill='none'%20stroke='%23c5cfb2'%20stroke-width='2'/%3e%3cpath%20d='M120%20252H191V260H115V269H195V278H112'%20fill='none'%20stroke='%23b7c4a9'%20stroke-width='5'/%3e%3cpath%20d='M243%20256L258%20242L279%20249L286%20270L260%20280L241%20269Z'%20fill='%23b3beaa'/%3e%3cpath%20d='M243%20256L263%20262L279%20249M263%20262L260%20280'%20fill='none'%20stroke='%23728876'/%3e%3cpath%20d='M212%20209L254%20279'%20stroke='%23927048'%20stroke-width='5'/%3e%3cpath%20d='M198%20219Q216%20195%20243%20202'%20fill='none'%20stroke='%234c6254'%20stroke-width='7'/%3e%3cpath%20d='M200%20216Q215%20201%20237%20202'%20fill='none'%20stroke='%23bdc7b6'%20stroke-width='2'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%23526b55'%20stroke-width='1.4'%20stroke-linejoin='round'%3e%3cpath%20d='M47%20260L48%20221L71%20203L92%20209L102%20240L89%20267Z'%20fill='%238fa28b'/%3e%3cpath%20d='M48%20221L71%20203L75%20229L60%20247L47%20260Z'%20fill='%23b7c4a9'/%3e%3cpath%20d='M75%20229L92%20209L102%20240L89%20267L64%20266Z'%20fill='%236b846f'/%3e%3cpath%20d='M47%20245H78V253H61V263H88'%20fill='none'%20stroke='%23d1d3af'%20stroke-width='4'/%3e%3cpath%20d='M74%20211L83%20224M81%20243L90%20254'%20fill='none'%20stroke='%23c2ccb0'/%3e%3c/g%3e%3cg%20stroke='%235b6149'%20stroke-linejoin='round'%3e%3cpath%20d='M289%20265L300%20218L324%20216L336%20258M300%20231L332%20244'%20fill='none'%20stroke-width='4'/%3e%3cpath%20d='M293%20226L327%20220'%20stroke='%238a7249'%20stroke-width='7'/%3e%3ccircle%20cx='323'%20cy='222'%20r='12'%20fill='%23a08655'%20stroke-width='2'/%3e%3ccircle%20cx='323'%20cy='222'%20r='6'%20fill='none'%20stroke='%23d2b97c'/%3e%3cpath%20d='M323%20210V234M311%20222H335M330%20231L339%20237'%20stroke-width='2'/%3e%3cpath%20d='M300%20228L291%20266L310%20272'%20fill='none'%20stroke='%23c7b687'%20stroke-width='2'/%3e%3c/g%3e%3cg%20stroke-linejoin='round'%3e%3cpath%20d='M106%20196V120M102%20124L180%20119M108%20146L137%20122M105%20197L92%20217M107%20197L121%20210'%20fill='none'%20stroke='%236c5738'%20stroke-width='5'/%3e%3cpath%20d='M107%20125L176%20121'%20stroke='%23b39460'%20stroke-width='1.4'/%3e%3ccircle%20cx='173'%20cy='123'%20r='7'%20fill='%23a1814d'%20stroke='%23615238'%20stroke-width='2'/%3e%3ccircle%20cx='173'%20cy='123'%20r='2'%20fill='%234c5140'/%3e%3cpath%20d='M170%20129V184Q177%20196%20185%20183M176%20129V183'%20fill='none'%20stroke='%23bfa879'%20stroke-width='2'/%3e%3cpath%20d='M163%20184L193%20178L196%20195L169%20203Z'%20fill='%23957445'%20stroke='%235b5038'%20stroke-width='1.5'/%3e%3cpath%20d='M167%20187L193%20182M171%20194L194%20188'%20stroke='%23ccad74'/%3e%3c/g%3e%3c/g%3e%3c/svg%3e",
	"./assets/card-temple-0.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='420'%20viewBox='0%200%20400%20420'%3e%3cpath%20d='M0%200H400V420H0Z'%20fill='%23a8d3cb'/%3e%3cpath%20d='M0%20370H400V420H0Z'%20fill='%23cfba87'/%3e%3cg%20transform='translate(0%2060)'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%2350634c'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M64%20278H302V265H286V253H269V240H253V154H118V240H101V253H84V265H64Z'%20fill='%2391a28a'/%3e%3cpath%20d='M118%20154L180%20118L253%20154Z'%20fill='%237a8f74'/%3e%3cpath%20d='M180%20118L187%20149L253%20154Z'%20fill='%23617a62'/%3e%3cpath%20d='M128%20165H151V235H128ZM217%20165H239V235H217Z'%20fill='%23c2c8a7'/%3e%3cpath%20d='M131%20170H148M132%20183H148M132%20196H148M132%20209H148M132%20221H148M220%20176H236M220%20190H236M220%20204H236M220%20218H236'%20stroke='%239aa889'%20stroke-width='1'/%3e%3cpath%20d='M171%20175H198V240H171Z'%20fill='%233c5747'/%3e%3cpath%20d='M176%20182H194V240H176Z'%20fill='%23314c3e'/%3e%3cpath%20d='M103%20241H268M86%20254H284M68%20266H299M119%20156H250'%20stroke='%23c3c9a5'%20stroke-width='3'/%3e%3cpath%20d='M153%20239V251M209%20253V265M121%20267V277M260%20265V276M235%20242V252'%20stroke-width='1'/%3e%3cpath%20d='M93%20202Q77%20196%2089%20177Q90%20189%2098%20184Q105%20196%2093%20202M272%20203Q261%20191%20272%20178Q269%20188%20278%20185Q288%20201%20272%20203'%20fill='%23d1a654'%20stroke='%23b98539'/%3e%3cpath%20d='M80%20202H106L103%20208H84ZM262%20203H287L283%20210H267Z'%20fill='%237d6844'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/card-temple-1.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='420'%20viewBox='0%200%20400%20420'%3e%3cpath%20d='M0%200H400V420H0Z'%20fill='%23a8d3cb'/%3e%3cpath%20d='M0%20370H400V420H0Z'%20fill='%23cfba87'/%3e%3cg%20transform='translate(0%2060)'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%2350634c'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M64%20278H302V265H286V253H269V240H253V154H118V240H101V253H84V265H64Z'%20fill='%2391a28a'/%3e%3cpath%20d='M118%20154L180%20118L253%20154Z'%20fill='%237a8f74'/%3e%3cpath%20d='M180%20118L187%20149L253%20154Z'%20fill='%23617a62'/%3e%3cpath%20d='M128%20165H151V235H128ZM217%20165H239V235H217Z'%20fill='%23c2c8a7'/%3e%3cpath%20d='M131%20170H148M132%20183H148M132%20196H148M132%20209H148M132%20221H148M220%20176H236M220%20190H236M220%20204H236M220%20218H236'%20stroke='%239aa889'%20stroke-width='1'/%3e%3cpath%20d='M171%20175H198V240H171Z'%20fill='%233c5747'/%3e%3cpath%20d='M176%20182H194V240H176Z'%20fill='%23314c3e'/%3e%3cpath%20d='M103%20241H268M86%20254H284M68%20266H299M119%20156H250'%20stroke='%23c3c9a5'%20stroke-width='3'/%3e%3cpath%20d='M153%20239V251M209%20253V265M121%20267V277M260%20265V276M235%20242V252'%20stroke-width='1'/%3e%3cpath%20d='M93%20202Q77%20196%2089%20177Q90%20189%2098%20184Q105%20196%2093%20202M272%20203Q261%20191%20272%20178Q269%20188%20278%20185Q288%20201%20272%20203'%20fill='%23d1a654'%20stroke='%23b98539'/%3e%3cpath%20d='M80%20202H106L103%20208H84ZM262%20203H287L283%20210H267Z'%20fill='%237d6844'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%2350634c'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M94%20241V166H109V241M264%20241V166H280V241'%20fill='%23c2c8a7'/%3e%3cpath%20d='M90%20163H113V172H90ZM260%20163H284V172H260Z'%20fill='%23a8b496'/%3e%3cpath%20d='M97%20180H106M97%20196H106M97%20212H106M267%20182H277M267%20198H277M267%20214H277'%20stroke='%2396a389'/%3e%3cpath%20d='M81%20245H115V252H78ZM260%20245H293V252H260Z'%20fill='%23b6c0a1'/%3e%3c/g%3e%3c/g%3e%3c/svg%3e",
	"./assets/card-temple-2.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='420'%20viewBox='0%200%20400%20420'%3e%3cpath%20d='M0%200H400V420H0Z'%20fill='%23a8d3cb'/%3e%3cpath%20d='M0%20370H400V420H0Z'%20fill='%23cfba87'/%3e%3cg%20transform='translate(0%2060)'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%2350634c'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M64%20278H302V265H286V253H269V240H253V154H118V240H101V253H84V265H64Z'%20fill='%2391a28a'/%3e%3cpath%20d='M118%20154L180%20118L253%20154Z'%20fill='%237a8f74'/%3e%3cpath%20d='M180%20118L187%20149L253%20154Z'%20fill='%23617a62'/%3e%3cpath%20d='M128%20165H151V235H128ZM217%20165H239V235H217Z'%20fill='%23c2c8a7'/%3e%3cpath%20d='M131%20170H148M132%20183H148M132%20196H148M132%20209H148M132%20221H148M220%20176H236M220%20190H236M220%20204H236M220%20218H236'%20stroke='%239aa889'%20stroke-width='1'/%3e%3cpath%20d='M171%20175H198V240H171Z'%20fill='%233c5747'/%3e%3cpath%20d='M176%20182H194V240H176Z'%20fill='%23314c3e'/%3e%3cpath%20d='M103%20241H268M86%20254H284M68%20266H299M119%20156H250'%20stroke='%23c3c9a5'%20stroke-width='3'/%3e%3cpath%20d='M153%20239V251M209%20253V265M121%20267V277M260%20265V276M235%20242V252'%20stroke-width='1'/%3e%3cpath%20d='M93%20202Q77%20196%2089%20177Q90%20189%2098%20184Q105%20196%2093%20202M272%20203Q261%20191%20272%20178Q269%20188%20278%20185Q288%20201%20272%20203'%20fill='%23d1a654'%20stroke='%23b98539'/%3e%3cpath%20d='M80%20202H106L103%20208H84ZM262%20203H287L283%20210H267Z'%20fill='%237d6844'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%2350634c'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M94%20241V166H109V241M264%20241V166H280V241'%20fill='%23c2c8a7'/%3e%3cpath%20d='M90%20163H113V172H90ZM260%20163H284V172H260Z'%20fill='%23a8b496'/%3e%3cpath%20d='M97%20180H106M97%20196H106M97%20212H106M267%20182H277M267%20198H277M267%20214H277'%20stroke='%2396a389'/%3e%3cpath%20d='M81%20245H115V252H78ZM260%20245H293V252H260Z'%20fill='%23b6c0a1'/%3e%3c/g%3e%3cg%20stroke='%2350634c'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M69%20241V198H93V241M281%20241V198H306V241'%20fill='%2391a28a'/%3e%3cpath%20d='M64%20199L81%20180L99%20199ZM276%20199L294%20180L312%20199Z'%20fill='%23b4bfa0'/%3e%3cpath%20d='M74%20208H87V231H74ZM286%20208H301V231H286Z'%20fill='%23536e58'/%3e%3cpath%20d='M70%20241H92M282%20241H306'%20stroke='%23d0d1ac'%20stroke-width='3'/%3e%3c/g%3e%3c/g%3e%3c/svg%3e",
	"./assets/card-temple-3.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='420'%20viewBox='0%200%20400%20420'%3e%3cpath%20d='M0%200H400V420H0Z'%20fill='%23a8d3cb'/%3e%3cpath%20d='M0%20370H400V420H0Z'%20fill='%23cfba87'/%3e%3cg%20transform='translate(0%2060)'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%2350634c'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M64%20278H302V265H286V253H269V240H253V154H118V240H101V253H84V265H64Z'%20fill='%2391a28a'/%3e%3cpath%20d='M118%20154L180%20118L253%20154Z'%20fill='%237a8f74'/%3e%3cpath%20d='M180%20118L187%20149L253%20154Z'%20fill='%23617a62'/%3e%3cpath%20d='M128%20165H151V235H128ZM217%20165H239V235H217Z'%20fill='%23c2c8a7'/%3e%3cpath%20d='M131%20170H148M132%20183H148M132%20196H148M132%20209H148M132%20221H148M220%20176H236M220%20190H236M220%20204H236M220%20218H236'%20stroke='%239aa889'%20stroke-width='1'/%3e%3cpath%20d='M171%20175H198V240H171Z'%20fill='%233c5747'/%3e%3cpath%20d='M176%20182H194V240H176Z'%20fill='%23314c3e'/%3e%3cpath%20d='M103%20241H268M86%20254H284M68%20266H299M119%20156H250'%20stroke='%23c3c9a5'%20stroke-width='3'/%3e%3cpath%20d='M153%20239V251M209%20253V265M121%20267V277M260%20265V276M235%20242V252'%20stroke-width='1'/%3e%3cpath%20d='M93%20202Q77%20196%2089%20177Q90%20189%2098%20184Q105%20196%2093%20202M272%20203Q261%20191%20272%20178Q269%20188%20278%20185Q288%20201%20272%20203'%20fill='%23d1a654'%20stroke='%23b98539'/%3e%3cpath%20d='M80%20202H106L103%20208H84ZM262%20203H287L283%20210H267Z'%20fill='%237d6844'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%2350634c'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M94%20241V166H109V241M264%20241V166H280V241'%20fill='%23c2c8a7'/%3e%3cpath%20d='M90%20163H113V172H90ZM260%20163H284V172H260Z'%20fill='%23a8b496'/%3e%3cpath%20d='M97%20180H106M97%20196H106M97%20212H106M267%20182H277M267%20198H277M267%20214H277'%20stroke='%2396a389'/%3e%3cpath%20d='M81%20245H115V252H78ZM260%20245H293V252H260Z'%20fill='%23b6c0a1'/%3e%3c/g%3e%3cg%20stroke='%2350634c'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M69%20241V198H93V241M281%20241V198H306V241'%20fill='%2391a28a'/%3e%3cpath%20d='M64%20199L81%20180L99%20199ZM276%20199L294%20180L312%20199Z'%20fill='%23b4bfa0'/%3e%3cpath%20d='M74%20208H87V231H74ZM286%20208H301V231H286Z'%20fill='%23536e58'/%3e%3cpath%20d='M70%20241H92M282%20241H306'%20stroke='%23d0d1ac'%20stroke-width='3'/%3e%3c/g%3e%3cg%20stroke='%2350634c'%20stroke-linejoin='round'%3e%3cpath%20d='M134%20148V123L180%2092L234%20122V148H219V130L181%20108L149%20132V148Z'%20fill='%23b2bc9b'%20stroke-width='1.6'/%3e%3cpath%20d='M180%2092L184%20104L234%20128V122Z'%20fill='%2382977c'/%3e%3cpath%20d='M169%20109L180%20102L194%20110M152%20128V144M218%20129V144'%20stroke='%23d4d6b1'%20stroke-width='2'%20fill='none'/%3e%3ccircle%20cx='181'%20cy='119'%20r='6'%20fill='%23bc9e57'%20stroke='%236f794e'/%3e%3c/g%3e%3c/g%3e%3c/svg%3e",
	"./assets/housing-0.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='320'%20viewBox='0%200%20400%20320'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(187%20185)%20scale(1.2)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3c/svg%3e",
	"./assets/housing-1.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='320'%20viewBox='0%200%20400%20320'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(187%20185)%20scale(1.2)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3cpath%20d='M-61%207L-60-13L-32-14M-64-15L-30-17L-27-9L-64-8Z'%20fill='%23bf9853'%20stroke='%23705a35'%20stroke-width='1.5'/%3e%3cpath%20d='M-64-13L-29-14'%20stroke='%23e2c78c'/%3e%3cpath%20d='M-60-8L-61%2028'%20stroke='%237b643d'%20stroke-width='3'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3c/svg%3e",
	"./assets/housing-2.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='320'%20viewBox='0%200%20400%20320'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(187%20185)%20scale(1.2)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3cpath%20d='M-61%207L-60-13L-32-14M-64-15L-30-17L-27-9L-64-8Z'%20fill='%23bf9853'%20stroke='%23705a35'%20stroke-width='1.5'/%3e%3cpath%20d='M-64-13L-29-14'%20stroke='%23e2c78c'/%3e%3cpath%20d='M-60-8L-61%2028'%20stroke='%237b643d'%20stroke-width='3'/%3e%3cpath%20d='M88%2046L103%2042L110%2056L91%2061Z'%20fill='%239ba893'%20stroke='%23526b55'/%3e%3cpath%20d='M90%2046L99%2051L103%2042'%20fill='none'%20stroke='%23d3d7b8'/%3e%3c/g%3e%3cg%20transform='translate(312%20205)%20scale(0.48)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3c/svg%3e",
	"./assets/housing-3.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='320'%20viewBox='0%200%20400%20320'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(187%20185)%20scale(1.2)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3cpath%20d='M-61%207L-60-13L-32-14M-64-15L-30-17L-27-9L-64-8Z'%20fill='%23bf9853'%20stroke='%23705a35'%20stroke-width='1.5'/%3e%3cpath%20d='M-64-13L-29-14'%20stroke='%23e2c78c'/%3e%3cpath%20d='M-60-8L-61%2028'%20stroke='%237b643d'%20stroke-width='3'/%3e%3cpath%20d='M88%2046L103%2042L110%2056L91%2061Z'%20fill='%239ba893'%20stroke='%23526b55'/%3e%3cpath%20d='M90%2046L99%2051L103%2042'%20fill='none'%20stroke='%23d3d7b8'/%3e%3c/g%3e%3cg%20transform='translate(312%20205)%20scale(0.48)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%23675239'%20stroke-linejoin='round'%3e%3cpath%20d='M49%20275L121%20252L169%20269L96%20293Z'%20fill='%23ad8851'%20stroke-width='2'/%3e%3cpath%20d='M49%20275V302M96%20293V314M169%20269V292M50%20258V279M96%20274V294M169%20252V273M49%20259L96%20275L169%20252'%20fill='none'%20stroke-width='3'/%3e%3cpath%20d='M61%20275L132%20256M73%20280L144%20260M85%20285L156%20265'%20stroke='%23d0b57b'%20stroke-width='1.3'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/island-final.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='900'%20height='650'%20viewBox='0%200%20900%20650'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8cfc4'/%3e%3cstop%20offset='1'%20stop-color='%23e6e6bc'/%3e%3c/linearGradient%3e%3clinearGradient%20id='water'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%2375b5a4'/%3e%3cstop%20offset='1'%20stop-color='%23bfd3aa'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20d='M0%200H900V650H0Z'%20fill='url(%23sky)'/%3e%3ccircle%20cx='685'%20cy='100'%20r='48'%20fill='%23f4e6b1'/%3e%3cpath%20d='M0%20291L130%20202L244%20239L396%2090L488%20203L601%20147L733%20266L822%20215L900%20236V415H0Z'%20fill='%2391ae91'/%3e%3cpath%20d='M244%20239L396%2090L411%20164L461%20212L383%20189L341%20244Z'%20fill='%23b8c3a1'/%3e%3cpath%20d='M0%20329Q157%20272%20303%20330T626%20319T900%20290V650H0Z'%20fill='url(%23water)'/%3e%3cpath%20d='M0%20435Q154%20335%20307%20385Q458%20428%20611%20379Q756%20347%20900%20420V650H0Z'%20fill='%23e4d09d'/%3e%3cpath%20d='M0%20450Q161%20353%20307%20399Q449%20444%20625%20394T900%20437'%20fill='none'%20stroke='%23f5edc8'%20stroke-width='7'/%3e%3cpath%20d='M0%20475Q175%20406%20292%20438M672%20429Q785%20413%20900%20473'%20fill='none'%20stroke='%23f2e6bb'%20stroke-width='3'/%3e%3cg%20transform='translate(180%20-30)%20scale(1.7)'%3e%3cg%20stroke='%2350634c'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M64%20278H302V265H286V253H269V240H253V154H118V240H101V253H84V265H64Z'%20fill='%2391a28a'/%3e%3cpath%20d='M118%20154L180%20118L253%20154Z'%20fill='%237a8f74'/%3e%3cpath%20d='M180%20118L187%20149L253%20154Z'%20fill='%23617a62'/%3e%3cpath%20d='M128%20165H151V235H128ZM217%20165H239V235H217Z'%20fill='%23c2c8a7'/%3e%3cpath%20d='M131%20170H148M132%20183H148M132%20196H148M132%20209H148M132%20221H148M220%20176H236M220%20190H236M220%20204H236M220%20218H236'%20stroke='%239aa889'%20stroke-width='1'/%3e%3cpath%20d='M171%20175H198V240H171Z'%20fill='%233c5747'/%3e%3cpath%20d='M176%20182H194V240H176Z'%20fill='%23314c3e'/%3e%3cpath%20d='M103%20241H268M86%20254H284M68%20266H299M119%20156H250'%20stroke='%23c3c9a5'%20stroke-width='3'/%3e%3cpath%20d='M153%20239V251M209%20253V265M121%20267V277M260%20265V276M235%20242V252'%20stroke-width='1'/%3e%3cpath%20d='M93%20202Q77%20196%2089%20177Q90%20189%2098%20184Q105%20196%2093%20202M272%20203Q261%20191%20272%20178Q269%20188%20278%20185Q288%20201%20272%20203'%20fill='%23d1a654'%20stroke='%23b98539'/%3e%3cpath%20d='M80%20202H106L103%20208H84ZM262%20203H287L283%20210H267Z'%20fill='%237d6844'/%3e%3c/g%3e%3c/g%3e%3cg%20transform='translate(235%20357)%20scale(1.3)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3cpath%20d='M-61%207L-60-13L-32-14M-64-15L-30-17L-27-9L-64-8Z'%20fill='%23bf9853'%20stroke='%23705a35'%20stroke-width='1.5'/%3e%3cpath%20d='M-64-13L-29-14'%20stroke='%23e2c78c'/%3e%3cpath%20d='M-60-8L-61%2028'%20stroke='%237b643d'%20stroke-width='3'/%3e%3cpath%20d='M88%2046L103%2042L110%2056L91%2061Z'%20fill='%239ba893'%20stroke='%23526b55'/%3e%3cpath%20d='M90%2046L99%2051L103%2042'%20fill='none'%20stroke='%23d3d7b8'/%3e%3c/g%3e%3cg%20transform='translate(580%20350)%20scale(0.85)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3cpath%20d='M-61%207L-60-13L-32-14M-64-15L-30-17L-27-9L-64-8Z'%20fill='%23bf9853'%20stroke='%23705a35'%20stroke-width='1.5'/%3e%3cpath%20d='M-64-13L-29-14'%20stroke='%23e2c78c'/%3e%3cpath%20d='M-60-8L-61%2028'%20stroke='%237b643d'%20stroke-width='3'/%3e%3c/g%3e%3cg%20transform='translate(735%20400)%20scale(0.9)'%20stroke-linejoin='round'%3e%3cellipse%20cx='8'%20cy='107'%20rx='98'%20ry='14'%20fill='%2350664a'%20opacity='.13'/%3e%3cg%20stroke='%23594b34'%20stroke-width='3.5'%3e%3cpath%20d='M-49%2065L-51%20107M44%2061L44%20101M-5%2068L-5%20105M72%2049L74%2086'/%3e%3cpath%20d='M-49%2082L-6%2096M-48%20101L-6%2082M-3%2078L44%2096M-2%20100L42%2078'%20stroke-width='2'/%3e%3c/g%3e%3cpath%20d='M-55%2019L38%2010L38%2071L-55%2080Z'%20fill='%23c9ae74'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cpath%20d='M38%2010L74%2027L74%2060L38%2071Z'%20fill='%23a98a52'%20stroke='%2363533a'%20stroke-width='1.5'/%3e%3cg%20fill='none'%20stroke='%23a78e5c'%20stroke-width='.7'%20opacity='.75'%3e%3cpath%20d='M-54%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-44%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-34%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-24%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-14%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M-4%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M6%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M16%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M26%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M36%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3cpath%20d='M46%2031l25%2027m-25-20l25%2027m-25-7l25-27'/%3e%3c/g%3e%3cpath%20d='M-55%2020V78M38%2013V71M73%2028V60M-10%2022V73'%20stroke='%23846c42'%20stroke-width='3.5'/%3e%3cpath%20d='M-29%2036L-5%2033V76L-29%2078Z'%20fill='%23364a3b'%20stroke='%23705d3d'%20stroke-width='3'/%3e%3cpath%20d='M-27%2039L-10%2037V76L-27%2077Z'%20fill='%23273f35'/%3e%3cpath%20d='M6%2033L25%2031V48L6%2050Z'%20fill='%23587c65'%20stroke='%23806b45'%20stroke-width='2'/%3e%3cpath%20d='M15%2032V49M6%2041L25%2039'%20stroke='%23c1a16b'%20stroke-width='1.5'/%3e%3cpath%20d='M49%2034L64%2039V51L49%2048Z'%20fill='%23455e46'/%3e%3cpath%20d='M-72%2080L43%2068L88%2081L-28%2096L-72%2088Z'%20fill='%239e7645'%20stroke='%23675239'%20stroke-width='1.5'/%3e%3cpath%20d='M-72%2080L-28%2088L88%2074V81L-28%2096L-72%2088Z'%20fill='%23795b38'/%3e%3cg%20fill='none'%20stroke='%23c3a36d'%20stroke-width='.9'%3e%3cpath%20d='M-64%2075L48%2064'/%3e%3cpath%20d='M-64%2078L48%2067'/%3e%3cpath%20d='M-64%2081L48%2070'/%3e%3cpath%20d='M-64%2084L48%2073'/%3e%3cpath%20d='M-64%2087L48%2076'/%3e%3cpath%20d='M-64%2090L48%2079'/%3e%3cpath%20d='M-64%2093L48%2082'/%3e%3c/g%3e%3cpath%20d='M-36%2092L-8%2089L-8%2095L-36%2098M-38%2098L-6%2095V101L-38%20104'%20fill='%23b79257'%20stroke='%23765c37'%20stroke-width='1'/%3e%3cpath%20d='M-81%2021Q-43-3-6-56Q29-20%2087%2026L38%2036Z'%20fill='%23cfa450'%20stroke='%236c5834'%20stroke-width='2'/%3e%3cpath%20d='M-6-56Q32-20%2087%2026L38%2036Q22-8-6-56'%20fill='%23b48b42'/%3e%3cpath%20d='M-81%2021L-76%2030L-67%2025L-63%2032L-54%2028L-48%2034L-41%2030L-33%2035L-24%2030L-18%2036L-11%2032L-4%2037L4%2032L12%2038L20%2033L28%2039L37%2034L45%2039L51%2032L58%2037L64%2031L72%2036L78%2029L85%2032L87%2026L38%2031Z'%20fill='%23af813c'%20stroke='%23755a32'%20stroke-width='.8'/%3e%3cg%20fill='none'%20stroke='%23ead096'%20stroke-width='1.2'%20opacity='.85'%3e%3cpath%20d='M-14%20-20Q-42%20-8%20-70%2018.6'/%3e%3cpath%20d='M-12%20-24Q-36%20-8%20-60%2017.8'/%3e%3cpath%20d='M-10%20-28Q-30%20-8%20-50%2017'/%3e%3cpath%20d='M-8%20-32Q-24%20-8%20-40%2016.2'/%3e%3cpath%20d='M-6%20-36Q-18%20-8%20-30%2015.4'/%3e%3cpath%20d='M-4%20-40Q-12%20-8%20-20%2014.6'/%3e%3cpath%20d='M-2%20-44Q-6%20-8%20-10%2013.8'/%3e%3cpath%20d='M0%20-48Q0%20-8%200%2013'/%3e%3cpath%20d='M2%20-44Q6%20-8%2010%2013.8'/%3e%3cpath%20d='M4%20-40Q12%20-8%2020%2014.6'/%3e%3cpath%20d='M6%20-36Q18%20-8%2030%2015.4'/%3e%3cpath%20d='M8%20-32Q24%20-8%2040%2016.2'/%3e%3cpath%20d='M10%20-28Q30%20-8%2050%2017'/%3e%3cpath%20d='M12%20-24Q36%20-8%2060%2017.8'/%3e%3cpath%20d='M14%20-20Q42%20-8%2070%2018.6'/%3e%3c/g%3e%3cpath%20d='M-5-55Q22-16%2038%2031M-78%2021L38%2031L84%2026'%20fill='none'%20stroke='%23735c36'%20stroke-width='1.6'/%3e%3cpath%20d='M-37-18Q-15-12%2010-9M-54%203Q-20%208%2025%209'%20stroke='%2396713a'%20stroke-width='1'%20fill='none'/%3e%3cg%20fill='%23a57e44'%20stroke='%235e5038'%20stroke-width='1'%3e%3cellipse%20cx='62'%20cy='71'%20rx='8'%20ry='11'/%3e%3cellipse%20cx='62'%20cy='63'%20rx='7'%20ry='3'%20fill='%23d6b976'/%3e%3cpath%20d='M58%2064L58%2078M62%2065V81M66%2064V77M55%2072H69'%20fill='none'%20stroke='%23d0b276'/%3e%3c/g%3e%3cpath%20d='M-61%207L-60-13L-32-14M-64-15L-30-17L-27-9L-64-8Z'%20fill='%23bf9853'%20stroke='%23705a35'%20stroke-width='1.5'/%3e%3cpath%20d='M-64-13L-29-14'%20stroke='%23e2c78c'/%3e%3cpath%20d='M-60-8L-61%2028'%20stroke='%237b643d'%20stroke-width='3'/%3e%3cpath%20d='M88%2046L103%2042L110%2056L91%2061Z'%20fill='%239ba893'%20stroke='%23526b55'/%3e%3cpath%20d='M90%2046L99%2051L103%2042'%20fill='none'%20stroke='%23d3d7b8'/%3e%3c/g%3e%3cg%20transform='translate(93%20318)%20scale(1.8%201.8)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(820%20300)%20scale(-1.65%201.65)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(678%20325)%20scale(0.8%200.8)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(85%20222)%20scale(1.1)'%3e%3cg%20stroke='%23645039'%20stroke-linejoin='round'%3e%3cpath%20d='M77%20243Q164%20268%20303%20222Q286%20262%20198%20277Q111%20287%2077%20243Z'%20fill='%23a27746'%20stroke-width='3'/%3e%3cpath%20d='M77%20243Q163%20263%20303%20222Q253%20252%20173%20261Q111%20262%2077%20243'%20fill='%235c573a'%20stroke-width='1.6'/%3e%3cpath%20d='M81%20244Q164%20264%20296%20226'%20fill='none'%20stroke='%23dfba76'%20stroke-width='4'/%3e%3cpath%20d='M95%20254Q173%20278%20284%20241'%20fill='none'%20stroke='%23c59b5f'%20stroke-width='2'/%3e%3cpath%20d='M134%20256L135%20272M207%20255L213%20271M267%20240L275%20254'%20stroke-width='3'/%3e%3cpath%20d='M120%20254L134%20249L158%20255L146%20260ZM215%20243L226%20239L247%20242L235%20247Z'%20fill='%23ba955e'%20stroke-width='1'/%3e%3cpath%20d='M195%20203L284%20286'%20stroke='%236f5739'%20stroke-width='5'/%3e%3cpath%20d='M271%20271Q291%20278%20301%20297Q279%20293%20269%20280Z'%20fill='%23a37c44'%20stroke-width='2'/%3e%3cpath%20d='M193%20203L208%20216'%20stroke='%23d6b57b'%20stroke-width='1.5'/%3e%3cpath%20d='M92%20223Q97%20210%20105%20222L110%20233L88%20237Z'%20fill='%23d4b178'%20stroke-width='1.4'/%3e%3cpath%20d='M90%20230L108%20226M95%20218L101%20234'%20stroke='%23a18552'%20stroke-width='1'/%3e%3c/g%3e%3c/g%3e%3cpath%20d='M115%20599Q139%20574%20150%20573M114%20599L110%20582M116%20594L136%20589M763%20597L778%20577L789%20590M798%20609L807%20593L821%20603'%20stroke='%238b9c66'%20stroke-width='4'%20fill='none'%20stroke-linecap='round'/%3e%3cpath%20d='M70%2092Q93%2065%20126%2088Q153%2064%20178%2096H70M488%2073Q512%2049%20536%2065Q565%2042%20589%2075Z'%20fill='%23f2ebc9'%20opacity='.8'/%3e%3c/svg%3e",
	"./assets/logger-0.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='320'%20viewBox='0%200%20400%20320'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(60%20130)%20scale(0.7%200.7)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%23625038'%20stroke-linejoin='round'%3e%3cg%20stroke-width='3'%3e%3cpath%20d='M70%20233L195%20184L222%20215L96%20261Z'%20fill='%238e6741'/%3e%3cpath%20d='M90%20234L203%20194M106%20248L211%20207'%20stroke='%23b69660'%20stroke-width='1.2'/%3e%3cellipse%20cx='96'%20cy='246'%20rx='23'%20ry='18'%20fill='%23d0b37a'/%3e%3cellipse%20cx='96'%20cy='246'%20rx='16'%20ry='12'%20fill='none'%20stroke='%239b7c49'%20stroke-width='1.2'/%3e%3cellipse%20cx='97'%20cy='246'%20rx='9'%20ry='7'%20fill='none'%20stroke='%23b09259'%20stroke-width='1'/%3e%3cpath%20d='M95%20242L98%20250M102%20251L106%20256M83%20240L78%20236'%20stroke-width='1'/%3e%3c/g%3e%3cpath%20d='M142%20213L157%20239M149%20210L164%20236'%20stroke='%23d4bb87'%20stroke-width='3'/%3e%3cpath%20d='M138%20212L160%20239'%20stroke='%23846c44'%20stroke-width='1'/%3e%3cg%20fill='none'%20stroke='%23715e3c'%20stroke-width='6'%3e%3cpath%20d='M248%20199L228%20264M247%20200L274%20262M229%20219L268%20218M231%20255L268%20227'/%3e%3c/g%3e%3cpath%20d='M215%20212L270%20170L283%20179L227%20222Z'%20fill='%23b8c8bb'%20stroke-width='2'/%3e%3cpath%20d='M219%20215L225%20215L226%20211L231%20211L231%20207L236%20207L236%20202L242%20202L242%20197L247%20198L248%20193L253%20193L253%20188L260%20189L262%20184'%20fill='none'%20stroke='%236a7e6c'%20stroke-width='1.1'/%3e%3cpath%20d='M273%20173L288%20165L295%20173L282%20182Z'%20fill='%23947443'%20stroke-width='2'/%3e%3cpath%20d='M82%20265L152%20238L173%20258L102%20282Z'%20fill='%239b7549'%20stroke-width='1.5'/%3e%3cellipse%20cx='102'%20cy='274'%20rx='14'%20ry='10'%20fill='%23d7b981'%20stroke-width='1.5'/%3e%3cellipse%20cx='102'%20cy='274'%20rx='7'%20ry='5'%20fill='none'%20stroke='%239c7c48'%20stroke-width='1'/%3e%3cpath%20d='M118%20266L128%20263M127%20253L138%20250M148%20251L161%20257'%20stroke='%23c2a06b'%20stroke-width='1'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3c/svg%3e",
	"./assets/logger-1.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='320'%20viewBox='0%200%20400%20320'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(60%20130)%20scale(0.7%200.7)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%23625038'%20stroke-linejoin='round'%3e%3cg%20stroke-width='3'%3e%3cpath%20d='M70%20233L195%20184L222%20215L96%20261Z'%20fill='%238e6741'/%3e%3cpath%20d='M90%20234L203%20194M106%20248L211%20207'%20stroke='%23b69660'%20stroke-width='1.2'/%3e%3cellipse%20cx='96'%20cy='246'%20rx='23'%20ry='18'%20fill='%23d0b37a'/%3e%3cellipse%20cx='96'%20cy='246'%20rx='16'%20ry='12'%20fill='none'%20stroke='%239b7c49'%20stroke-width='1.2'/%3e%3cellipse%20cx='97'%20cy='246'%20rx='9'%20ry='7'%20fill='none'%20stroke='%23b09259'%20stroke-width='1'/%3e%3cpath%20d='M95%20242L98%20250M102%20251L106%20256M83%20240L78%20236'%20stroke-width='1'/%3e%3c/g%3e%3cpath%20d='M142%20213L157%20239M149%20210L164%20236'%20stroke='%23d4bb87'%20stroke-width='3'/%3e%3cpath%20d='M138%20212L160%20239'%20stroke='%23846c44'%20stroke-width='1'/%3e%3cg%20fill='none'%20stroke='%23715e3c'%20stroke-width='6'%3e%3cpath%20d='M248%20199L228%20264M247%20200L274%20262M229%20219L268%20218M231%20255L268%20227'/%3e%3c/g%3e%3cpath%20d='M215%20212L270%20170L283%20179L227%20222Z'%20fill='%23b8c8bb'%20stroke-width='2'/%3e%3cpath%20d='M219%20215L225%20215L226%20211L231%20211L231%20207L236%20207L236%20202L242%20202L242%20197L247%20198L248%20193L253%20193L253%20188L260%20189L262%20184'%20fill='none'%20stroke='%236a7e6c'%20stroke-width='1.1'/%3e%3cpath%20d='M273%20173L288%20165L295%20173L282%20182Z'%20fill='%23947443'%20stroke-width='2'/%3e%3cpath%20d='M82%20265L152%20238L173%20258L102%20282Z'%20fill='%239b7549'%20stroke-width='1.5'/%3e%3cellipse%20cx='102'%20cy='274'%20rx='14'%20ry='10'%20fill='%23d7b981'%20stroke-width='1.5'/%3e%3cellipse%20cx='102'%20cy='274'%20rx='7'%20ry='5'%20fill='none'%20stroke='%239c7c48'%20stroke-width='1'/%3e%3cpath%20d='M118%20266L128%20263M127%20253L138%20250M148%20251L161%20257'%20stroke='%23c2a06b'%20stroke-width='1'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%23645039'%20stroke-linejoin='round'%3e%3cpath%20d='M36%20236V187M102%20221V174M32%20195L106%20180M33%20216L105%20201'%20fill='none'%20stroke-width='5'/%3e%3cpath%20d='M32%20215L97%20195L109%20205L45%20226Z'%20fill='%239b7549'%20stroke-width='1.5'/%3e%3cellipse%20cx='44'%20cy='221'%20rx='10'%20ry='7'%20fill='%23d7b981'/%3e%3cellipse%20cx='44'%20cy='221'%20rx='5'%20ry='3.5'%20fill='none'%20stroke='%239c7c48'/%3e%3cpath%20d='M34%20202L98%20183L109%20193L45%20214Z'%20fill='%238e6741'%20stroke-width='1.5'/%3e%3cellipse%20cx='44'%20cy='209'%20rx='10'%20ry='7'%20fill='%23d7b981'/%3e%3cellipse%20cx='44'%20cy='209'%20rx='5'%20ry='3.5'%20fill='none'%20stroke='%239c7c48'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/logger-2.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='320'%20viewBox='0%200%20400%20320'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(60%20130)%20scale(0.7%200.7)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%23625038'%20stroke-linejoin='round'%3e%3cg%20stroke-width='3'%3e%3cpath%20d='M70%20233L195%20184L222%20215L96%20261Z'%20fill='%238e6741'/%3e%3cpath%20d='M90%20234L203%20194M106%20248L211%20207'%20stroke='%23b69660'%20stroke-width='1.2'/%3e%3cellipse%20cx='96'%20cy='246'%20rx='23'%20ry='18'%20fill='%23d0b37a'/%3e%3cellipse%20cx='96'%20cy='246'%20rx='16'%20ry='12'%20fill='none'%20stroke='%239b7c49'%20stroke-width='1.2'/%3e%3cellipse%20cx='97'%20cy='246'%20rx='9'%20ry='7'%20fill='none'%20stroke='%23b09259'%20stroke-width='1'/%3e%3cpath%20d='M95%20242L98%20250M102%20251L106%20256M83%20240L78%20236'%20stroke-width='1'/%3e%3c/g%3e%3cpath%20d='M142%20213L157%20239M149%20210L164%20236'%20stroke='%23d4bb87'%20stroke-width='3'/%3e%3cpath%20d='M138%20212L160%20239'%20stroke='%23846c44'%20stroke-width='1'/%3e%3cg%20fill='none'%20stroke='%23715e3c'%20stroke-width='6'%3e%3cpath%20d='M248%20199L228%20264M247%20200L274%20262M229%20219L268%20218M231%20255L268%20227'/%3e%3c/g%3e%3cpath%20d='M215%20212L270%20170L283%20179L227%20222Z'%20fill='%23b8c8bb'%20stroke-width='2'/%3e%3cpath%20d='M219%20215L225%20215L226%20211L231%20211L231%20207L236%20207L236%20202L242%20202L242%20197L247%20198L248%20193L253%20193L253%20188L260%20189L262%20184'%20fill='none'%20stroke='%236a7e6c'%20stroke-width='1.1'/%3e%3cpath%20d='M273%20173L288%20165L295%20173L282%20182Z'%20fill='%23947443'%20stroke-width='2'/%3e%3cpath%20d='M82%20265L152%20238L173%20258L102%20282Z'%20fill='%239b7549'%20stroke-width='1.5'/%3e%3cellipse%20cx='102'%20cy='274'%20rx='14'%20ry='10'%20fill='%23d7b981'%20stroke-width='1.5'/%3e%3cellipse%20cx='102'%20cy='274'%20rx='7'%20ry='5'%20fill='none'%20stroke='%239c7c48'%20stroke-width='1'/%3e%3cpath%20d='M118%20266L128%20263M127%20253L138%20250M148%20251L161%20257'%20stroke='%23c2a06b'%20stroke-width='1'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%23645039'%20stroke-linejoin='round'%3e%3cpath%20d='M36%20236V187M102%20221V174M32%20195L106%20180M33%20216L105%20201'%20fill='none'%20stroke-width='5'/%3e%3cpath%20d='M32%20215L97%20195L109%20205L45%20226Z'%20fill='%239b7549'%20stroke-width='1.5'/%3e%3cellipse%20cx='44'%20cy='221'%20rx='10'%20ry='7'%20fill='%23d7b981'/%3e%3cellipse%20cx='44'%20cy='221'%20rx='5'%20ry='3.5'%20fill='none'%20stroke='%239c7c48'/%3e%3cpath%20d='M34%20202L98%20183L109%20193L45%20214Z'%20fill='%238e6741'%20stroke-width='1.5'/%3e%3cellipse%20cx='44'%20cy='209'%20rx='10'%20ry='7'%20fill='%23d7b981'/%3e%3cellipse%20cx='44'%20cy='209'%20rx='5'%20ry='3.5'%20fill='none'%20stroke='%239c7c48'/%3e%3c/g%3e%3cg%20stroke='%23675239'%20stroke-linejoin='round'%3e%3cpath%20d='M219%20177V236M299%20176V232M224%20192L241%20177M281%20177L297%20191'%20fill='none'%20stroke-width='4'/%3e%3cpath%20d='M202%20177L249%20142L312%20169L265%20185Z'%20fill='%23cfa450'%20stroke-width='2'/%3e%3cpath%20d='M249%20142L265%20185L312%20169Z'%20fill='%23ac823d'/%3e%3cpath%20d='M216%20171L255%20149M230%20177L261%20156M246%20181L267%20164M269%20181L278%20161M284%20176L289%20167'%20fill='none'%20stroke='%23e7c887'%20stroke-width='1.2'/%3e%3cpath%20d='M203%20177L265%20185L311%20169'%20fill='none'%20stroke-width='3'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/logger-3.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='320'%20viewBox='0%200%20400%20320'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(60%20130)%20scale(0.7%200.7)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%23625038'%20stroke-linejoin='round'%3e%3cg%20stroke-width='3'%3e%3cpath%20d='M70%20233L195%20184L222%20215L96%20261Z'%20fill='%238e6741'/%3e%3cpath%20d='M90%20234L203%20194M106%20248L211%20207'%20stroke='%23b69660'%20stroke-width='1.2'/%3e%3cellipse%20cx='96'%20cy='246'%20rx='23'%20ry='18'%20fill='%23d0b37a'/%3e%3cellipse%20cx='96'%20cy='246'%20rx='16'%20ry='12'%20fill='none'%20stroke='%239b7c49'%20stroke-width='1.2'/%3e%3cellipse%20cx='97'%20cy='246'%20rx='9'%20ry='7'%20fill='none'%20stroke='%23b09259'%20stroke-width='1'/%3e%3cpath%20d='M95%20242L98%20250M102%20251L106%20256M83%20240L78%20236'%20stroke-width='1'/%3e%3c/g%3e%3cpath%20d='M142%20213L157%20239M149%20210L164%20236'%20stroke='%23d4bb87'%20stroke-width='3'/%3e%3cpath%20d='M138%20212L160%20239'%20stroke='%23846c44'%20stroke-width='1'/%3e%3cg%20fill='none'%20stroke='%23715e3c'%20stroke-width='6'%3e%3cpath%20d='M248%20199L228%20264M247%20200L274%20262M229%20219L268%20218M231%20255L268%20227'/%3e%3c/g%3e%3cpath%20d='M215%20212L270%20170L283%20179L227%20222Z'%20fill='%23b8c8bb'%20stroke-width='2'/%3e%3cpath%20d='M219%20215L225%20215L226%20211L231%20211L231%20207L236%20207L236%20202L242%20202L242%20197L247%20198L248%20193L253%20193L253%20188L260%20189L262%20184'%20fill='none'%20stroke='%236a7e6c'%20stroke-width='1.1'/%3e%3cpath%20d='M273%20173L288%20165L295%20173L282%20182Z'%20fill='%23947443'%20stroke-width='2'/%3e%3cpath%20d='M82%20265L152%20238L173%20258L102%20282Z'%20fill='%239b7549'%20stroke-width='1.5'/%3e%3cellipse%20cx='102'%20cy='274'%20rx='14'%20ry='10'%20fill='%23d7b981'%20stroke-width='1.5'/%3e%3cellipse%20cx='102'%20cy='274'%20rx='7'%20ry='5'%20fill='none'%20stroke='%239c7c48'%20stroke-width='1'/%3e%3cpath%20d='M118%20266L128%20263M127%20253L138%20250M148%20251L161%20257'%20stroke='%23c2a06b'%20stroke-width='1'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%23645039'%20stroke-linejoin='round'%3e%3cpath%20d='M36%20236V187M102%20221V174M32%20195L106%20180M33%20216L105%20201'%20fill='none'%20stroke-width='5'/%3e%3cpath%20d='M32%20215L97%20195L109%20205L45%20226Z'%20fill='%239b7549'%20stroke-width='1.5'/%3e%3cellipse%20cx='44'%20cy='221'%20rx='10'%20ry='7'%20fill='%23d7b981'/%3e%3cellipse%20cx='44'%20cy='221'%20rx='5'%20ry='3.5'%20fill='none'%20stroke='%239c7c48'/%3e%3cpath%20d='M34%20202L98%20183L109%20193L45%20214Z'%20fill='%238e6741'%20stroke-width='1.5'/%3e%3cellipse%20cx='44'%20cy='209'%20rx='10'%20ry='7'%20fill='%23d7b981'/%3e%3cellipse%20cx='44'%20cy='209'%20rx='5'%20ry='3.5'%20fill='none'%20stroke='%239c7c48'/%3e%3c/g%3e%3cg%20stroke='%23675239'%20stroke-linejoin='round'%3e%3cpath%20d='M219%20177V236M299%20176V232M224%20192L241%20177M281%20177L297%20191'%20fill='none'%20stroke-width='4'/%3e%3cpath%20d='M202%20177L249%20142L312%20169L265%20185Z'%20fill='%23cfa450'%20stroke-width='2'/%3e%3cpath%20d='M249%20142L265%20185L312%20169Z'%20fill='%23ac823d'/%3e%3cpath%20d='M216%20171L255%20149M230%20177L261%20156M246%20181L267%20164M269%20181L278%20161M284%20176L289%20167'%20fill='none'%20stroke='%23e7c887'%20stroke-width='1.2'/%3e%3cpath%20d='M203%20177L265%20185L311%20169'%20fill='none'%20stroke-width='3'/%3e%3c/g%3e%3cg%20stroke-linejoin='round'%3e%3cpath%20d='M106%20196V120M102%20124L180%20119M108%20146L137%20122M105%20197L92%20217M107%20197L121%20210'%20fill='none'%20stroke='%236c5738'%20stroke-width='5'/%3e%3cpath%20d='M107%20125L176%20121'%20stroke='%23b39460'%20stroke-width='1.4'/%3e%3ccircle%20cx='173'%20cy='123'%20r='7'%20fill='%23a1814d'%20stroke='%23615238'%20stroke-width='2'/%3e%3ccircle%20cx='173'%20cy='123'%20r='2'%20fill='%234c5140'/%3e%3cpath%20d='M170%20129V184Q177%20196%20185%20183M176%20129V183'%20fill='none'%20stroke='%23bfa879'%20stroke-width='2'/%3e%3cpath%20d='M163%20184L193%20178L196%20195L169%20203Z'%20fill='%23957445'%20stroke='%235b5038'%20stroke-width='1.5'/%3e%3cpath%20d='M167%20187L193%20182M171%20194L194%20188'%20stroke='%23ccad74'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/quarry-0.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='320'%20viewBox='0%200%20400%20320'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%234c6551'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M74%20252L98%20201L132%20169L164%20182L192%20211L218%20200L264%20235L278%20268Z'%20fill='%23819584'/%3e%3cpath%20d='M132%20169L145%20202L113%20223L98%20201ZM145%20202L164%20182L192%20211L171%20235L137%20232Z'%20fill='%23a5b6a0'/%3e%3cpath%20d='M113%20223L137%20232L132%20252L88%20255ZM171%20235L192%20211L218%20200L213%20242L190%20263Z'%20fill='%23667e6d'/%3e%3cpath%20d='M145%20204L161%20215L151%20226M114%20227L125%20239M214%20206L228%20225L243%20231M245%20245L252%20264'%20fill='none'%20stroke='%23c5cfb2'%20stroke-width='2'/%3e%3cpath%20d='M120%20252H191V260H115V269H195V278H112'%20fill='none'%20stroke='%23b7c4a9'%20stroke-width='5'/%3e%3cpath%20d='M243%20256L258%20242L279%20249L286%20270L260%20280L241%20269Z'%20fill='%23b3beaa'/%3e%3cpath%20d='M243%20256L263%20262L279%20249M263%20262L260%20280'%20fill='none'%20stroke='%23728876'/%3e%3cpath%20d='M212%20209L254%20279'%20stroke='%23927048'%20stroke-width='5'/%3e%3cpath%20d='M198%20219Q216%20195%20243%20202'%20fill='none'%20stroke='%234c6254'%20stroke-width='7'/%3e%3cpath%20d='M200%20216Q215%20201%20237%20202'%20fill='none'%20stroke='%23bdc7b6'%20stroke-width='2'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3c/svg%3e",
	"./assets/quarry-1.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='320'%20viewBox='0%200%20400%20320'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%234c6551'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M74%20252L98%20201L132%20169L164%20182L192%20211L218%20200L264%20235L278%20268Z'%20fill='%23819584'/%3e%3cpath%20d='M132%20169L145%20202L113%20223L98%20201ZM145%20202L164%20182L192%20211L171%20235L137%20232Z'%20fill='%23a5b6a0'/%3e%3cpath%20d='M113%20223L137%20232L132%20252L88%20255ZM171%20235L192%20211L218%20200L213%20242L190%20263Z'%20fill='%23667e6d'/%3e%3cpath%20d='M145%20204L161%20215L151%20226M114%20227L125%20239M214%20206L228%20225L243%20231M245%20245L252%20264'%20fill='none'%20stroke='%23c5cfb2'%20stroke-width='2'/%3e%3cpath%20d='M120%20252H191V260H115V269H195V278H112'%20fill='none'%20stroke='%23b7c4a9'%20stroke-width='5'/%3e%3cpath%20d='M243%20256L258%20242L279%20249L286%20270L260%20280L241%20269Z'%20fill='%23b3beaa'/%3e%3cpath%20d='M243%20256L263%20262L279%20249M263%20262L260%20280'%20fill='none'%20stroke='%23728876'/%3e%3cpath%20d='M212%20209L254%20279'%20stroke='%23927048'%20stroke-width='5'/%3e%3cpath%20d='M198%20219Q216%20195%20243%20202'%20fill='none'%20stroke='%234c6254'%20stroke-width='7'/%3e%3cpath%20d='M200%20216Q215%20201%20237%20202'%20fill='none'%20stroke='%23bdc7b6'%20stroke-width='2'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%23526b55'%20stroke-width='1.4'%20stroke-linejoin='round'%3e%3cpath%20d='M47%20260L48%20221L71%20203L92%20209L102%20240L89%20267Z'%20fill='%238fa28b'/%3e%3cpath%20d='M48%20221L71%20203L75%20229L60%20247L47%20260Z'%20fill='%23b7c4a9'/%3e%3cpath%20d='M75%20229L92%20209L102%20240L89%20267L64%20266Z'%20fill='%236b846f'/%3e%3cpath%20d='M47%20245H78V253H61V263H88'%20fill='none'%20stroke='%23d1d3af'%20stroke-width='4'/%3e%3cpath%20d='M74%20211L83%20224M81%20243L90%20254'%20fill='none'%20stroke='%23c2ccb0'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/quarry-2.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='320'%20viewBox='0%200%20400%20320'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%234c6551'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M74%20252L98%20201L132%20169L164%20182L192%20211L218%20200L264%20235L278%20268Z'%20fill='%23819584'/%3e%3cpath%20d='M132%20169L145%20202L113%20223L98%20201ZM145%20202L164%20182L192%20211L171%20235L137%20232Z'%20fill='%23a5b6a0'/%3e%3cpath%20d='M113%20223L137%20232L132%20252L88%20255ZM171%20235L192%20211L218%20200L213%20242L190%20263Z'%20fill='%23667e6d'/%3e%3cpath%20d='M145%20204L161%20215L151%20226M114%20227L125%20239M214%20206L228%20225L243%20231M245%20245L252%20264'%20fill='none'%20stroke='%23c5cfb2'%20stroke-width='2'/%3e%3cpath%20d='M120%20252H191V260H115V269H195V278H112'%20fill='none'%20stroke='%23b7c4a9'%20stroke-width='5'/%3e%3cpath%20d='M243%20256L258%20242L279%20249L286%20270L260%20280L241%20269Z'%20fill='%23b3beaa'/%3e%3cpath%20d='M243%20256L263%20262L279%20249M263%20262L260%20280'%20fill='none'%20stroke='%23728876'/%3e%3cpath%20d='M212%20209L254%20279'%20stroke='%23927048'%20stroke-width='5'/%3e%3cpath%20d='M198%20219Q216%20195%20243%20202'%20fill='none'%20stroke='%234c6254'%20stroke-width='7'/%3e%3cpath%20d='M200%20216Q215%20201%20237%20202'%20fill='none'%20stroke='%23bdc7b6'%20stroke-width='2'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%23526b55'%20stroke-width='1.4'%20stroke-linejoin='round'%3e%3cpath%20d='M47%20260L48%20221L71%20203L92%20209L102%20240L89%20267Z'%20fill='%238fa28b'/%3e%3cpath%20d='M48%20221L71%20203L75%20229L60%20247L47%20260Z'%20fill='%23b7c4a9'/%3e%3cpath%20d='M75%20229L92%20209L102%20240L89%20267L64%20266Z'%20fill='%236b846f'/%3e%3cpath%20d='M47%20245H78V253H61V263H88'%20fill='none'%20stroke='%23d1d3af'%20stroke-width='4'/%3e%3cpath%20d='M74%20211L83%20224M81%20243L90%20254'%20fill='none'%20stroke='%23c2ccb0'/%3e%3c/g%3e%3cg%20stroke='%235b6149'%20stroke-linejoin='round'%3e%3cpath%20d='M289%20265L300%20218L324%20216L336%20258M300%20231L332%20244'%20fill='none'%20stroke-width='4'/%3e%3cpath%20d='M293%20226L327%20220'%20stroke='%238a7249'%20stroke-width='7'/%3e%3ccircle%20cx='323'%20cy='222'%20r='12'%20fill='%23a08655'%20stroke-width='2'/%3e%3ccircle%20cx='323'%20cy='222'%20r='6'%20fill='none'%20stroke='%23d2b97c'/%3e%3cpath%20d='M323%20210V234M311%20222H335M330%20231L339%20237'%20stroke-width='2'/%3e%3cpath%20d='M300%20228L291%20266L310%20272'%20fill='none'%20stroke='%23c7b687'%20stroke-width='2'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/quarry-3.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='320'%20viewBox='0%200%20400%20320'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%234c6551'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M74%20252L98%20201L132%20169L164%20182L192%20211L218%20200L264%20235L278%20268Z'%20fill='%23819584'/%3e%3cpath%20d='M132%20169L145%20202L113%20223L98%20201ZM145%20202L164%20182L192%20211L171%20235L137%20232Z'%20fill='%23a5b6a0'/%3e%3cpath%20d='M113%20223L137%20232L132%20252L88%20255ZM171%20235L192%20211L218%20200L213%20242L190%20263Z'%20fill='%23667e6d'/%3e%3cpath%20d='M145%20204L161%20215L151%20226M114%20227L125%20239M214%20206L228%20225L243%20231M245%20245L252%20264'%20fill='none'%20stroke='%23c5cfb2'%20stroke-width='2'/%3e%3cpath%20d='M120%20252H191V260H115V269H195V278H112'%20fill='none'%20stroke='%23b7c4a9'%20stroke-width='5'/%3e%3cpath%20d='M243%20256L258%20242L279%20249L286%20270L260%20280L241%20269Z'%20fill='%23b3beaa'/%3e%3cpath%20d='M243%20256L263%20262L279%20249M263%20262L260%20280'%20fill='none'%20stroke='%23728876'/%3e%3cpath%20d='M212%20209L254%20279'%20stroke='%23927048'%20stroke-width='5'/%3e%3cpath%20d='M198%20219Q216%20195%20243%20202'%20fill='none'%20stroke='%234c6254'%20stroke-width='7'/%3e%3cpath%20d='M200%20216Q215%20201%20237%20202'%20fill='none'%20stroke='%23bdc7b6'%20stroke-width='2'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%23526b55'%20stroke-width='1.4'%20stroke-linejoin='round'%3e%3cpath%20d='M47%20260L48%20221L71%20203L92%20209L102%20240L89%20267Z'%20fill='%238fa28b'/%3e%3cpath%20d='M48%20221L71%20203L75%20229L60%20247L47%20260Z'%20fill='%23b7c4a9'/%3e%3cpath%20d='M75%20229L92%20209L102%20240L89%20267L64%20266Z'%20fill='%236b846f'/%3e%3cpath%20d='M47%20245H78V253H61V263H88'%20fill='none'%20stroke='%23d1d3af'%20stroke-width='4'/%3e%3cpath%20d='M74%20211L83%20224M81%20243L90%20254'%20fill='none'%20stroke='%23c2ccb0'/%3e%3c/g%3e%3cg%20stroke='%235b6149'%20stroke-linejoin='round'%3e%3cpath%20d='M289%20265L300%20218L324%20216L336%20258M300%20231L332%20244'%20fill='none'%20stroke-width='4'/%3e%3cpath%20d='M293%20226L327%20220'%20stroke='%238a7249'%20stroke-width='7'/%3e%3ccircle%20cx='323'%20cy='222'%20r='12'%20fill='%23a08655'%20stroke-width='2'/%3e%3ccircle%20cx='323'%20cy='222'%20r='6'%20fill='none'%20stroke='%23d2b97c'/%3e%3cpath%20d='M323%20210V234M311%20222H335M330%20231L339%20237'%20stroke-width='2'/%3e%3cpath%20d='M300%20228L291%20266L310%20272'%20fill='none'%20stroke='%23c7b687'%20stroke-width='2'/%3e%3c/g%3e%3cg%20stroke-linejoin='round'%3e%3cpath%20d='M106%20196V120M102%20124L180%20119M108%20146L137%20122M105%20197L92%20217M107%20197L121%20210'%20fill='none'%20stroke='%236c5738'%20stroke-width='5'/%3e%3cpath%20d='M107%20125L176%20121'%20stroke='%23b39460'%20stroke-width='1.4'/%3e%3ccircle%20cx='173'%20cy='123'%20r='7'%20fill='%23a1814d'%20stroke='%23615238'%20stroke-width='2'/%3e%3ccircle%20cx='173'%20cy='123'%20r='2'%20fill='%234c5140'/%3e%3cpath%20d='M170%20129V184Q177%20196%20185%20183M176%20129V183'%20fill='none'%20stroke='%23bfa879'%20stroke-width='2'/%3e%3cpath%20d='M163%20184L193%20178L196%20195L169%20203Z'%20fill='%23957445'%20stroke='%235b5038'%20stroke-width='1.5'/%3e%3cpath%20d='M167%20187L193%20182M171%20194L194%20188'%20stroke='%23ccad74'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/table.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='1920'%20height='1080'%20viewBox='0%200%201920%201080'%20preserveAspectRatio='xMidYMid%20slice'%3e%3cdefs%3e%3clinearGradient%20id='table'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23dce8d5'/%3e%3cstop%20offset='1'%20stop-color='%23d2dfc8'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20d='M0%200H1920V1080H0Z'%20fill='url(%23table)'/%3e%3cpath%20d='M0%20830Q213%20719%20433%20827T877%20830T1298%20837T1755%20798T1920%20817V1080H0Z'%20fill='%23c5d5bc'%20opacity='.35'/%3e%3cpath%20d='M0%20851Q218%20740%20432%20849T878%20852T1298%20859T1755%20820T1920%20839'%20fill='none'%20stroke='%23edf0d7'%20stroke-width='2'%20opacity='.6'/%3e%3cpath%20d='M-40%201040Q-4%20846%2077%20722Q50%20867%208%201041M-9%201048Q44%20934%20130%20896Q91%20991%2014%201060M1935%201066Q1853%20957%201742%20935Q1840%201028%201910%201074M1928%201066Q1904%20872%201839%20808Q1859%20962%201905%201082'%20fill='%23829f78'%20opacity='.13'/%3e%3c/svg%3e",
	"./assets/temple-0.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='320'%20viewBox='0%200%20400%20320'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%2350634c'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M64%20278H302V265H286V253H269V240H253V154H118V240H101V253H84V265H64Z'%20fill='%2391a28a'/%3e%3cpath%20d='M118%20154L180%20118L253%20154Z'%20fill='%237a8f74'/%3e%3cpath%20d='M180%20118L187%20149L253%20154Z'%20fill='%23617a62'/%3e%3cpath%20d='M128%20165H151V235H128ZM217%20165H239V235H217Z'%20fill='%23c2c8a7'/%3e%3cpath%20d='M131%20170H148M132%20183H148M132%20196H148M132%20209H148M132%20221H148M220%20176H236M220%20190H236M220%20204H236M220%20218H236'%20stroke='%239aa889'%20stroke-width='1'/%3e%3cpath%20d='M171%20175H198V240H171Z'%20fill='%233c5747'/%3e%3cpath%20d='M176%20182H194V240H176Z'%20fill='%23314c3e'/%3e%3cpath%20d='M103%20241H268M86%20254H284M68%20266H299M119%20156H250'%20stroke='%23c3c9a5'%20stroke-width='3'/%3e%3cpath%20d='M153%20239V251M209%20253V265M121%20267V277M260%20265V276M235%20242V252'%20stroke-width='1'/%3e%3cpath%20d='M93%20202Q77%20196%2089%20177Q90%20189%2098%20184Q105%20196%2093%20202M272%20203Q261%20191%20272%20178Q269%20188%20278%20185Q288%20201%20272%20203'%20fill='%23d1a654'%20stroke='%23b98539'/%3e%3cpath%20d='M80%20202H106L103%20208H84ZM262%20203H287L283%20210H267Z'%20fill='%237d6844'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3c/svg%3e",
	"./assets/temple-1.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='320'%20viewBox='0%200%20400%20320'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%2350634c'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M64%20278H302V265H286V253H269V240H253V154H118V240H101V253H84V265H64Z'%20fill='%2391a28a'/%3e%3cpath%20d='M118%20154L180%20118L253%20154Z'%20fill='%237a8f74'/%3e%3cpath%20d='M180%20118L187%20149L253%20154Z'%20fill='%23617a62'/%3e%3cpath%20d='M128%20165H151V235H128ZM217%20165H239V235H217Z'%20fill='%23c2c8a7'/%3e%3cpath%20d='M131%20170H148M132%20183H148M132%20196H148M132%20209H148M132%20221H148M220%20176H236M220%20190H236M220%20204H236M220%20218H236'%20stroke='%239aa889'%20stroke-width='1'/%3e%3cpath%20d='M171%20175H198V240H171Z'%20fill='%233c5747'/%3e%3cpath%20d='M176%20182H194V240H176Z'%20fill='%23314c3e'/%3e%3cpath%20d='M103%20241H268M86%20254H284M68%20266H299M119%20156H250'%20stroke='%23c3c9a5'%20stroke-width='3'/%3e%3cpath%20d='M153%20239V251M209%20253V265M121%20267V277M260%20265V276M235%20242V252'%20stroke-width='1'/%3e%3cpath%20d='M93%20202Q77%20196%2089%20177Q90%20189%2098%20184Q105%20196%2093%20202M272%20203Q261%20191%20272%20178Q269%20188%20278%20185Q288%20201%20272%20203'%20fill='%23d1a654'%20stroke='%23b98539'/%3e%3cpath%20d='M80%20202H106L103%20208H84ZM262%20203H287L283%20210H267Z'%20fill='%237d6844'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%2350634c'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M94%20241V166H109V241M264%20241V166H280V241'%20fill='%23c2c8a7'/%3e%3cpath%20d='M90%20163H113V172H90ZM260%20163H284V172H260Z'%20fill='%23a8b496'/%3e%3cpath%20d='M97%20180H106M97%20196H106M97%20212H106M267%20182H277M267%20198H277M267%20214H277'%20stroke='%2396a389'/%3e%3cpath%20d='M81%20245H115V252H78ZM260%20245H293V252H260Z'%20fill='%23b6c0a1'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/temple-2.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='320'%20viewBox='0%200%20400%20320'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%2350634c'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M64%20278H302V265H286V253H269V240H253V154H118V240H101V253H84V265H64Z'%20fill='%2391a28a'/%3e%3cpath%20d='M118%20154L180%20118L253%20154Z'%20fill='%237a8f74'/%3e%3cpath%20d='M180%20118L187%20149L253%20154Z'%20fill='%23617a62'/%3e%3cpath%20d='M128%20165H151V235H128ZM217%20165H239V235H217Z'%20fill='%23c2c8a7'/%3e%3cpath%20d='M131%20170H148M132%20183H148M132%20196H148M132%20209H148M132%20221H148M220%20176H236M220%20190H236M220%20204H236M220%20218H236'%20stroke='%239aa889'%20stroke-width='1'/%3e%3cpath%20d='M171%20175H198V240H171Z'%20fill='%233c5747'/%3e%3cpath%20d='M176%20182H194V240H176Z'%20fill='%23314c3e'/%3e%3cpath%20d='M103%20241H268M86%20254H284M68%20266H299M119%20156H250'%20stroke='%23c3c9a5'%20stroke-width='3'/%3e%3cpath%20d='M153%20239V251M209%20253V265M121%20267V277M260%20265V276M235%20242V252'%20stroke-width='1'/%3e%3cpath%20d='M93%20202Q77%20196%2089%20177Q90%20189%2098%20184Q105%20196%2093%20202M272%20203Q261%20191%20272%20178Q269%20188%20278%20185Q288%20201%20272%20203'%20fill='%23d1a654'%20stroke='%23b98539'/%3e%3cpath%20d='M80%20202H106L103%20208H84ZM262%20203H287L283%20210H267Z'%20fill='%237d6844'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%2350634c'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M94%20241V166H109V241M264%20241V166H280V241'%20fill='%23c2c8a7'/%3e%3cpath%20d='M90%20163H113V172H90ZM260%20163H284V172H260Z'%20fill='%23a8b496'/%3e%3cpath%20d='M97%20180H106M97%20196H106M97%20212H106M267%20182H277M267%20198H277M267%20214H277'%20stroke='%2396a389'/%3e%3cpath%20d='M81%20245H115V252H78ZM260%20245H293V252H260Z'%20fill='%23b6c0a1'/%3e%3c/g%3e%3cg%20stroke='%2350634c'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M69%20241V198H93V241M281%20241V198H306V241'%20fill='%2391a28a'/%3e%3cpath%20d='M64%20199L81%20180L99%20199ZM276%20199L294%20180L312%20199Z'%20fill='%23b4bfa0'/%3e%3cpath%20d='M74%20208H87V231H74ZM286%20208H301V231H286Z'%20fill='%23536e58'/%3e%3cpath%20d='M70%20241H92M282%20241H306'%20stroke='%23d0d1ac'%20stroke-width='3'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/temple-3.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='400'%20height='320'%20viewBox='0%200%20400%20320'%3e%3cdefs%3e%3clinearGradient%20id='sky'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23a8d3cb'/%3e%3cstop%20offset='1'%20stop-color='%23e6eac7'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sea'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%236fb5a4'/%3e%3cstop%20offset='1'%20stop-color='%23afcdb0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='sand'%20x2='0'%20y2='1'%3e%3cstop%20stop-color='%23eddaaa'/%3e%3cstop%20offset='1'%20stop-color='%23cfba87'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20fill='url(%23sky)'%20d='M0%200H400V320H0Z'/%3e%3ccircle%20cx='294'%20cy='52'%20r='27'%20fill='%23f6e8b4'%20opacity='.8'/%3e%3cpath%20d='M0%20134L57%2086L108%20105L166%2040L208%2087L247%2066L306%20129L358%2092L400%20114V205H0Z'%20fill='%2391b29a'/%3e%3cpath%20d='M108%20105L166%2040L175%2078L199%20101L161%2086L143%20117Z'%20fill='%23c0c8a5'/%3e%3cpath%20d='M204%20104L247%2066L253%2090L275%20111L244%2097L227%20123Z'%20fill='%23abbfa1'/%3e%3cpath%20d='M0%20152Q83%20116%20155%20150T301%20147T400%20137V320H0Z'%20fill='url(%23sea)'/%3e%3cpath%20d='M0%20206Q72%20161%20147%20183Q196%20204%20272%20179Q340%20159%20400%20202V320H0Z'%20fill='url(%23sand)'/%3e%3cpath%20d='M0%20215Q76%20172%20148%20192T281%20189T400%20211'%20fill='none'%20stroke='%23f5efce'%20stroke-width='4'/%3e%3cpath%20d='M13%20230Q94%20200%20147%20211M0%20155Q41%20145%2070%20149M289%20158L335%20152M345%20148L365%20145'%20fill='none'%20stroke='%23e5eed0'%20stroke-width='1.4'%20opacity='.7'/%3e%3cpath%20d='M35%2042Q47%2027%2064%2039Q77%2027%2090%2045H35M204%2031Q216%2015%20230%2026Q244%2014%20258%2032Z'%20fill='%23f2edcf'%20opacity='.8'/%3e%3cg%20transform='translate(46%20138)%20scale(0.78%200.78)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20transform='translate(354%20147)%20scale(-0.85%200.85)'%3e%3cpath%20d='M-7%20108C2%2074%2015%2036%205%201L13-2C29%2036%2011%2081%204%20109Z'%20fill='%2394714b'%20stroke='%233c5141'%20stroke-width='1.8'/%3e%3cpath%20d='M-3%2096L10%2097M0%2083L13%2085M4%2070L17%2071M8%2056L21%2058M10%2041L22%2043M11%2025L21%2026'%20stroke='%23c3a271'%20stroke-width='2'/%3e%3cg%20fill='%232f6c51'%20stroke='%23234c3d'%20stroke-width='1.3'%20stroke-linejoin='round'%3e%3cpath%20d='M9%204C-11-16-34-26-63-5C-40-11-20%201%209%207L-10-2L-18-8L-15%200L-27-4L-36-9L-32-1L-44-3Z'/%3e%3cpath%20d='M10%205C-18-3-47%206-56%2030C-38%2020-10%2022%2011%209L-7%2013L-17%2010L-15%2017L-31%2017L-37%2015L-33%2021Z'/%3e%3cpath%20d='M10%204C1-26%2012-48%2033-59C26-38%2029-11%2014%206L17-18L22-28L16-25L21-41L16-36L14-15Z'/%3e%3cpath%20d='M11%205C33-23%2057-27%2082-11C57-14%2039%204%2012%209L35-4L43-4L41-9L56-13L49-15L27-5Z'/%3e%3cpath%20d='M11%206C46-4%2068%207%2078%2030C54%2016%2036%2023%2011%2010L38%2014L47%2010L46%2017L62%2021L54%2013L35%2011Z'/%3e%3cpath%20d='M9%204C-5-12-9-34-1-48C3-26%2017-16%2013%203L6-13L0-23L4-21L0-36L0-26L7-5Z'/%3e%3c/g%3e%3cpath%20d='M10%206C-12-8-35-12-53-6M11%207C35-9%2055-17%2073-13M10%207C-13%2010-33%2016-48%2024M11%206L28-49M12%208C35%2011%2057%2013%2070%2023'%20fill='none'%20stroke='%2382a26b'%20stroke-width='1.6'/%3e%3cellipse%20cx='10'%20cy='9'%20rx='6'%20ry='7'%20fill='%236b6040'/%3e%3cellipse%20cx='18'%20cy='10'%20rx='4'%20ry='5'%20fill='%239b7b49'/%3e%3c/g%3e%3cg%20stroke='%2350634c'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M64%20278H302V265H286V253H269V240H253V154H118V240H101V253H84V265H64Z'%20fill='%2391a28a'/%3e%3cpath%20d='M118%20154L180%20118L253%20154Z'%20fill='%237a8f74'/%3e%3cpath%20d='M180%20118L187%20149L253%20154Z'%20fill='%23617a62'/%3e%3cpath%20d='M128%20165H151V235H128ZM217%20165H239V235H217Z'%20fill='%23c2c8a7'/%3e%3cpath%20d='M131%20170H148M132%20183H148M132%20196H148M132%20209H148M132%20221H148M220%20176H236M220%20190H236M220%20204H236M220%20218H236'%20stroke='%239aa889'%20stroke-width='1'/%3e%3cpath%20d='M171%20175H198V240H171Z'%20fill='%233c5747'/%3e%3cpath%20d='M176%20182H194V240H176Z'%20fill='%23314c3e'/%3e%3cpath%20d='M103%20241H268M86%20254H284M68%20266H299M119%20156H250'%20stroke='%23c3c9a5'%20stroke-width='3'/%3e%3cpath%20d='M153%20239V251M209%20253V265M121%20267V277M260%20265V276M235%20242V252'%20stroke-width='1'/%3e%3cpath%20d='M93%20202Q77%20196%2089%20177Q90%20189%2098%20184Q105%20196%2093%20202M272%20203Q261%20191%20272%20178Q269%20188%20278%20185Q288%20201%20272%20203'%20fill='%23d1a654'%20stroke='%23b98539'/%3e%3cpath%20d='M80%20202H106L103%20208H84ZM262%20203H287L283%20210H267Z'%20fill='%237d6844'/%3e%3c/g%3e%3cg%20fill='none'%20stroke='%238e9e65'%20stroke-width='2'%20stroke-linecap='round'%3e%3cpath%20d='M21%20292Q23%20276%2030%20272M24%20282L14%20279M25%20280L35%20279M333%20287L340%20277L346%20285M349%20291L356%20282L361%20288'/%3e%3c/g%3e%3cpath%20d='M39%20303L84%20299M281%20299L309%20297M176%20309L192%20309'%20stroke='%23b9a16e'%20stroke-width='1'/%3e%3cg%20stroke='%2350634c'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M94%20241V166H109V241M264%20241V166H280V241'%20fill='%23c2c8a7'/%3e%3cpath%20d='M90%20163H113V172H90ZM260%20163H284V172H260Z'%20fill='%23a8b496'/%3e%3cpath%20d='M97%20180H106M97%20196H106M97%20212H106M267%20182H277M267%20198H277M267%20214H277'%20stroke='%2396a389'/%3e%3cpath%20d='M81%20245H115V252H78ZM260%20245H293V252H260Z'%20fill='%23b6c0a1'/%3e%3c/g%3e%3cg%20stroke='%2350634c'%20stroke-width='1.5'%20stroke-linejoin='round'%3e%3cpath%20d='M69%20241V198H93V241M281%20241V198H306V241'%20fill='%2391a28a'/%3e%3cpath%20d='M64%20199L81%20180L99%20199ZM276%20199L294%20180L312%20199Z'%20fill='%23b4bfa0'/%3e%3cpath%20d='M74%20208H87V231H74ZM286%20208H301V231H286Z'%20fill='%23536e58'/%3e%3cpath%20d='M70%20241H92M282%20241H306'%20stroke='%23d0d1ac'%20stroke-width='3'/%3e%3c/g%3e%3cg%20stroke='%2350634c'%20stroke-linejoin='round'%3e%3cpath%20d='M134%20148V123L180%2092L234%20122V148H219V130L181%20108L149%20132V148Z'%20fill='%23b2bc9b'%20stroke-width='1.6'/%3e%3cpath%20d='M180%2092L184%20104L234%20128V122Z'%20fill='%2382977c'/%3e%3cpath%20d='M169%20109L180%20102L194%20110M152%20128V144M218%20129V144'%20stroke='%23d4d6b1'%20stroke-width='2'%20fill='none'/%3e%3ccircle%20cx='181'%20cy='119'%20r='6'%20fill='%23bc9e57'%20stroke='%236f794e'/%3e%3c/g%3e%3c/svg%3e"
}), Ke = Ge["./assets/island-final.svg"], qe = Ge["./assets/table.svg"];
function Je(e, t, n = !1) {
	let r = e >= 1 && e <= 3 ? "canoe" : e <= 6 && e >= 4 ? "logger" : e <= 9 && e >= 7 ? "quarry" : e >= 13 && e <= 14 ? "housing" : e >= 15 && e <= 16 ? "temple" : null;
	return r ? Ge[`./assets/${n ? "card-" : ""}${r}-${Math.min(3, t)}.svg`] : void 0;
}
//#endregion
//#region src/games/palmisland/art.tsx
var Y = {
	sky: "#c4ecea",
	sea: "#4cbbb6",
	foam: "#e8f8ee",
	sand: "#f0d49a",
	leaf: "#286954",
	lightLeaf: "#74a86b",
	wood: "#885937",
	bark: "#573f2e",
	ink: "#293e39",
	rock: "#7c9990",
	thatch: "#c99646"
};
function Ye({ x: e, y: t, size: n = 1 }) {
	return /* @__PURE__ */ g("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ h("path", {
				d: "M0 50Q15 18 8-15L13-15Q23 15 8 50",
				fill: Y.wood,
				stroke: Y.bark,
				strokeWidth: "2"
			}),
			/* @__PURE__ */ h("path", {
				d: "M10-13Q-14-37-38-13Q-7-21 10-11M10-13Q-17-13-29 8Q-2-7 11-9M10-14Q21-43 43-32Q22-25 13-10M11-12Q38-26 57-4Q32-13 12-8M10-13Q14-46-4-49Q5-30 9-13",
				fill: Y.leaf,
				stroke: Y.ink,
				strokeWidth: "1.7"
			}),
			/* @__PURE__ */ h("path", {
				d: "M10-13L-30-14M11-12L47-5",
				fill: "none",
				stroke: Y.lightLeaf,
				strokeWidth: "2"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "9",
				cy: "-9",
				r: "4",
				fill: Y.wood
			})
		]
	});
}
function Xe({ x: e, y: t, scale: n = 1, tall: r = !1 }) {
	return /* @__PURE__ */ g("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		stroke: Y.bark,
		strokeWidth: "2",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ h("path", {
				d: "M-33 34V55M29 34V55M-26 24H27V44H-26Z",
				fill: "#d1ac68"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-29 9H31V35H-29Z",
				fill: "#c8a363"
			}),
			/* @__PURE__ */ h("path", {
				d: "M13 10L31 9V35L13 41Z",
				fill: "#a77e46"
			}),
			/* @__PURE__ */ h("path", {
				d: r ? "M-42 11L-8-31L43 11Z" : "M-43 11L-7-21L43 11Z",
				fill: Y.thatch
			}),
			/* @__PURE__ */ h("path", {
				d: r ? "M-8-31L43 11L28 7Z" : "M-7-21L43 11L28 7Z",
				fill: "#aa7438",
				stroke: "none"
			}),
			/* @__PURE__ */ h("path", {
				d: r ? "M-36 8L-10-25M-25 9L-6-24M-13 9L-3-21M1 9L0-17M14 9L2-13M27 9L6-9" : "M-36 8L-10-17M-25 9L-7-16M-13 9L-4-14M1 9L-1-11M14 9L2-8M27 9L6-5",
				stroke: "#ead093",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-40 11L-34 16L-27 12L-21 15L-14 12L-7 15L0 12L7 15L14 12L21 15L28 12L35 14L41 11",
				fill: "#b8843d",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-4 16H10V35H-4Z",
				fill: Y.bark
			}),
			/* @__PURE__ */ h("path", {
				d: "M-1 19H7V35H-1Z",
				fill: "#34463b",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-24 20H-15V27H-24Z",
				fill: Y.sky
			}),
			/* @__PURE__ */ h("path", {
				d: "M-20 20V27M-24 23H-15",
				stroke: "#9f824d",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-34 37H36L45 44H-40Z",
				fill: "#aa7846"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-27 39H32M-30 42H39M-24 44L-29 52M25 44L31 52M-26 30H-6M14 30H29M-27 17H-7M13 17H28M-27 24H-7M14 24H29",
				stroke: "#a27a46",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ h("path", {
				d: "M-28 18L-8 30M-28 29L-9 17M15 17L29 30M15 30L29 17",
				stroke: "#d3b477",
				strokeWidth: ".7"
			})
		]
	});
}
function X({ kind: e = 1, level: t = 0, className: n, portrait: r = !1 }) {
	let i = Je(e, t, r);
	return i ? /* @__PURE__ */ h("img", {
		src: i,
		className: n,
		alt: "",
		draggable: !1
	}) : /* @__PURE__ */ h(Ze, {
		kind: e,
		level: t,
		className: n
	});
}
function Ze({ kind: e = 1, level: t = 0, className: n }) {
	let r;
	return r = e <= 3 ? /* @__PURE__ */ g("g", { children: [
		/* @__PURE__ */ h(Xe, {
			x: 212,
			y: 79,
			scale: .68
		}),
		/* @__PURE__ */ h("path", {
			d: "M35 141Q77 160 139 136L122 159Q77 177 43 156Z",
			fill: Y.wood,
			stroke: Y.bark,
			strokeWidth: "3"
		}),
		/* @__PURE__ */ h("path", {
			d: "M37 142Q80 151 137 138M53 148L52 160M115 146L112 161",
			fill: "none",
			stroke: "#dfb16e",
			strokeWidth: "3"
		}),
		/* @__PURE__ */ h("path", {
			d: "M91 122L128 165M117 153L136 174",
			stroke: Y.bark,
			strokeWidth: "4"
		}),
		/* @__PURE__ */ h("path", {
			d: "M68 126L78 111L85 126",
			fill: Y.thatch
		}),
		t >= 1 && /* @__PURE__ */ h("path", {
			d: "M154 136Q178 144 197 130L190 146Q170 153 157 145Z",
			fill: Y.wood,
			stroke: Y.bark,
			strokeWidth: "2"
		})
	] }) : e <= 6 ? /* @__PURE__ */ g("g", { children: [
		/* @__PURE__ */ h(Ye, {
			x: 54,
			y: 97,
			size: .8
		}),
		/* @__PURE__ */ h(Ye, {
			x: 98,
			y: 79,
			size: .7
		}),
		/* @__PURE__ */ h("path", {
			d: "M80 133L170 103L198 124L109 156Z",
			fill: Y.wood,
			stroke: Y.bark,
			strokeWidth: "3"
		}),
		/* @__PURE__ */ h("ellipse", {
			cx: "105",
			cy: "144",
			rx: "16",
			ry: "12",
			fill: "#d6b77a",
			stroke: Y.bark,
			strokeWidth: "2"
		}),
		/* @__PURE__ */ h("ellipse", {
			cx: "105",
			cy: "144",
			rx: "8",
			ry: "6",
			fill: "none",
			stroke: Y.wood
		}),
		/* @__PURE__ */ h("path", {
			d: "M105 138V151M98 144H112M138 117L157 140",
			stroke: "#b9a06e",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ h("path", {
			d: "M207 102L190 150M207 103L227 148M192 116H221",
			stroke: Y.bark,
			strokeWidth: "5"
		}),
		/* @__PURE__ */ h("path", {
			d: "M179 113L225 83L234 91L188 120Z",
			fill: "#bdc8bb",
			stroke: Y.ink,
			strokeWidth: "2"
		}),
		t >= 2 && /* @__PURE__ */ h("path", {
			d: "M123 158L184 137L205 151L145 171Z",
			fill: Y.wood,
			stroke: Y.bark,
			strokeWidth: "2"
		})
	] }) : e <= 9 ? /* @__PURE__ */ g("g", {
		stroke: Y.ink,
		strokeWidth: "2",
		children: [
			/* @__PURE__ */ h("path", {
				d: "M24 137L68 73L109 89L135 117L190 105L226 139Z",
				fill: Y.rock
			}),
			/* @__PURE__ */ h("path", {
				d: "M68 73L76 99L109 89M76 99L58 120L93 130L112 111L135 117M29 133L58 120M93 130L98 146M144 132L167 114L190 105L189 136",
				fill: "none",
				stroke: "#b9ccc0",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ h("path", {
				d: "M186 148L197 130L217 131L225 153Z",
				fill: "#a2b7aa"
			}),
			/* @__PURE__ */ h("path", {
				d: "M211 109L190 156",
				stroke: Y.wood,
				strokeWidth: "5"
			}),
			/* @__PURE__ */ h("path", {
				d: "M197 112Q215 100 227 120",
				fill: "none",
				stroke: Y.ink,
				strokeWidth: "5"
			}),
			t >= 1 && /* @__PURE__ */ h("path", {
				d: "M92 136H158V148H89V160H166",
				fill: "none",
				stroke: "#d6dbb8",
				strokeWidth: "6"
			})
		]
	}) : e === 15 || e === 16 ? /* @__PURE__ */ g("g", {
		stroke: Y.ink,
		strokeWidth: "2",
		children: [
			/* @__PURE__ */ h("path", {
				d: "M53 159H248V147H233V135H218V123H201V73H104V123H86V135H69V147H53Z",
				fill: "#839d89"
			}),
			/* @__PURE__ */ h("path", {
				d: "M104 73L149 46L201 73Z",
				fill: "#556e5c"
			}),
			/* @__PURE__ */ h("path", {
				d: "M121 80H137V122H121ZM168 80H184V122H168Z",
				fill: "#bfcbac"
			}),
			/* @__PURE__ */ h("path", {
				d: "M145 85H162V124H145Z",
				fill: Y.ink
			}),
			/* @__PURE__ */ h("path", {
				d: "M89 136H217M70 148H232M106 124H200",
				stroke: "#bdc8a7",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ h("path", {
				d: "M72 110L82 91L91 110M218 108L229 89L239 108",
				fill: "#e5a447"
			}),
			/* @__PURE__ */ h("path", {
				d: "M74 110H91M218 110H240",
				stroke: Y.bark,
				strokeWidth: "6"
			})
		]
	}) : e >= 17 && e <= 25 ? /* @__PURE__ */ h(We, { kind: e }) : e >= 30 && e <= 36 ? /* @__PURE__ */ h(He, { kind: e }) : e === 10 ? /* @__PURE__ */ g("g", {
		stroke: Y.bark,
		strokeWidth: "1.7",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ h("path", {
				d: "M35 119L60 102L94 114L83 135L47 139ZM181 123L217 107L254 121L243 148L197 149Z",
				fill: "#b2b3a0"
			}),
			/* @__PURE__ */ h("path", {
				d: "M39 121L68 125L92 115M68 125L64 138M185 126L219 134L251 123M219 134L218 149",
				stroke: "#e1d7b5",
				fill: "none"
			}),
			/* @__PURE__ */ h("path", {
				d: "M47 114L91 107L96 117L51 126Z",
				fill: "#aa7950"
			}),
			/* @__PURE__ */ h("path", {
				d: "M51 126L52 148M87 121L86 142",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ h("path", {
				d: "M49 112L88 110M55 118L91 114",
				stroke: "#d8b379",
				fill: "none"
			}),
			/* @__PURE__ */ h("path", {
				d: "M50 111Q64 100 76 109L73 118L55 120Z",
				fill: "#d2b064"
			}),
			/* @__PURE__ */ h("path", {
				d: "M54 113L73 111M58 109L61 120M67 107L68 118",
				stroke: "#8f7548",
				fill: "none"
			}),
			/* @__PURE__ */ h("path", {
				d: "M111 147Q134 133 157 142L168 155Q133 169 103 157Z",
				fill: "#bca273"
			}),
			/* @__PURE__ */ h("path", {
				d: "M109 150Q137 154 164 149M114 158L121 147M136 160L141 144M153 157L157 147",
				stroke: "#ddc99e",
				fill: "none"
			}),
			/* @__PURE__ */ h("path", {
				d: "M194 122Q204 113 216 122Q208 132 194 122Z",
				fill: "#cd7770"
			}),
			/* @__PURE__ */ h("path", {
				d: "M211 121L220 115L220 126Z",
				fill: "#bb625e"
			}),
			/* @__PURE__ */ h("path", {
				d: "M227 116L235 112L240 122L228 127Z",
				fill: "#829383"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "205",
				cy: "121",
				r: "1",
				fill: "#313e36"
			}),
			/* @__PURE__ */ h("path", {
				d: "M139 133Q146 111 155 95Q161 82 164 65",
				stroke: "#e7dbaa",
				strokeWidth: "7",
				fill: "none"
			}),
			t >= 1 && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
				d: "M46 103L42 80M94 108L97 85M38 80Q69 67 101 84L97 91Q69 78 42 87Z",
				fill: "#a8b77b"
			}), /* @__PURE__ */ h("path", {
				d: "M45 81Q70 73 94 84M54 78L52 85M68 76L68 83M82 79L84 87",
				fill: "none",
				stroke: "#d3dc9c"
			})] }),
			t >= 2 && /* @__PURE__ */ h("path", {
				d: "M189 112L190 92L238 87L247 108M190 93L237 88M196 95L195 110M227 91L232 108",
				fill: "none",
				stroke: "#b38b53",
				strokeWidth: "3"
			})
		]
	}) : e === 11 ? /* @__PURE__ */ g("g", {
		stroke: Y.bark,
		strokeWidth: "1.8",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ h("path", {
				d: "M82 101H207V149H82Z",
				fill: "#bd985a"
			}),
			/* @__PURE__ */ h("path", {
				d: "M181 100L207 101V149L181 160Z",
				fill: "#947044"
			}),
			/* @__PURE__ */ h("path", {
				d: "M57 100L135 44L230 101L220 111L57 110Z",
				fill: "#c59a4f"
			}),
			/* @__PURE__ */ h("path", {
				d: "M135 44L230 101L216 110L178 91Z",
				fill: "#98743f"
			}),
			/* @__PURE__ */ h("path", {
				d: "M67 100L128 53M83 102L131 55M102 102L135 56M124 102L139 60M146 102L143 63M165 102L148 65M186 103L152 68M209 104L157 71",
				stroke: "#e0c17d",
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ h("path", {
				d: "M58 107L67 113L76 108L85 113L95 108L106 112L117 108L128 112L139 109L151 113L163 109L176 113L188 109L201 113L217 109",
				fill: "#ac7e40"
			}),
			/* @__PURE__ */ h("path", {
				d: "M115 115H147V152H115Z",
				fill: "#3e4938"
			}),
			/* @__PURE__ */ h("path", {
				d: "M91 117H105V133H91ZM160 116H178V132H160Z",
				fill: "#d4c598"
			}),
			/* @__PURE__ */ h("path", {
				d: "M98 117V133M91 125H105M169 116V132M160 124H178M85 139H111M151 139H180",
				stroke: "#85653f",
				fill: "none"
			}),
			/* @__PURE__ */ h("path", {
				d: "M70 151H218L228 160H67Z",
				fill: "#a37949"
			}),
			/* @__PURE__ */ h("path", {
				d: "M78 155H216M86 162V174M203 162V171",
				stroke: "#694f32",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ h("path", {
				d: "M211 135Q223 127 238 134L236 151Q223 158 211 150Z",
				fill: "#ab7c49"
			}),
			/* @__PURE__ */ h("path", {
				d: "M213 139H236M214 146H236M218 133V153M229 132V154",
				fill: "none",
				stroke: "#d4b77a"
			}),
			/* @__PURE__ */ h("path", {
				d: "M42 149L72 138L87 151L55 164Z",
				fill: "#795535"
			}),
			/* @__PURE__ */ h("ellipse", {
				cx: "55",
				cy: "157",
				rx: "9",
				ry: "7",
				fill: "#c1a56b"
			}),
			/* @__PURE__ */ h("ellipse", {
				cx: "55",
				cy: "157",
				rx: "4",
				ry: "3",
				fill: "none"
			}),
			t >= 1 && /* @__PURE__ */ h("path", {
				d: "M91 143L98 138L110 143L107 153H92ZM153 141L171 138L178 146L171 154L153 150Z",
				fill: "#cdc194"
			}),
			t >= 2 && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
				d: "M32 142L62 129L73 137L43 152Z",
				fill: "#8a633b"
			}), /* @__PURE__ */ h("ellipse", {
				cx: "42",
				cy: "146",
				rx: "8",
				ry: "6",
				fill: "#c7a875"
			})] })
		]
	}) : e === 12 ? /* @__PURE__ */ g("g", {
		stroke: Y.bark,
		strokeWidth: "2",
		strokeLinejoin: "round",
		children: [
			/* @__PURE__ */ h(Xe, {
				x: 224,
				y: 87,
				scale: .72
			}),
			/* @__PURE__ */ h("path", {
				d: "M213 64L232 77M232 64L217 75",
				stroke: "#89613d",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ h("path", {
				d: "M82 117L79 169M191 116L199 170M93 127L183 155M185 127L95 157",
				fill: "none",
				stroke: "#765536",
				strokeWidth: "7"
			}),
			/* @__PURE__ */ h("path", {
				d: "M61 112L177 89L223 109L105 139Z",
				fill: "#b58b55"
			}),
			/* @__PURE__ */ h("path", {
				d: "M61 112L105 139V148L62 121ZM105 139L223 109V119L105 148Z",
				fill: "#8e633a"
			}),
			/* @__PURE__ */ h("path", {
				d: "M68 114L179 96M82 121L190 99M97 129L207 104",
				stroke: "#d8b97d",
				strokeWidth: "2",
				fill: "none"
			}),
			/* @__PURE__ */ h("path", {
				d: "M102 113L156 101L166 108L115 122Z",
				fill: "#c3aa78"
			}),
			/* @__PURE__ */ h("path", {
				d: "M121 119L132 106M143 115L150 104",
				stroke: "#8f7851",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ h("path", {
				d: "M121 70L155 127",
				stroke: "#8d623c",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ h("path", {
				d: "M112 76Q124 57 147 62L152 75Q133 70 123 86Z",
				fill: "#8c9c88"
			}),
			/* @__PURE__ */ h("path", {
				d: "M114 75Q130 63 147 65",
				stroke: "#d2d7ba",
				fill: "none",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ h("path", {
				d: "M122 76L138 89M125 71L142 85",
				stroke: "#c5ad73",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ h("path", {
				d: "M169 83L194 122",
				stroke: "#95683d",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ h("path", {
				d: "M157 82L169 73L182 78L186 87L172 93Z",
				fill: "#7f9184"
			}),
			/* @__PURE__ */ h("path", {
				d: "M158 82L172 80L184 86",
				stroke: "#c1c8a9",
				fill: "none"
			}),
			/* @__PURE__ */ h("path", {
				d: "M187 154L214 146L225 156L198 168Z",
				fill: "#9ea896"
			}),
			/* @__PURE__ */ h("path", {
				d: "M188 154L203 158L214 146M203 158L198 168",
				stroke: "#cbd2b8",
				fill: "none"
			}),
			t >= 1 && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("path", {
					d: "M72 106L101 83L107 88L82 113Z",
					fill: "#a7b4a4"
				}),
				/* @__PURE__ */ h("path", {
					d: "M98 84L103 75",
					stroke: "#805e3c",
					strokeWidth: "5"
				}),
				/* @__PURE__ */ h("path", {
					d: "M68 106L92 92",
					stroke: "#d9dfc6",
					fill: "none"
				})
			] }),
			t >= 2 && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
				d: "M203 93L220 70L227 75L211 102Z",
				fill: "#758e83"
			}), /* @__PURE__ */ h("path", {
				d: "M213 79L234 118",
				stroke: "#976c44",
				strokeWidth: "4"
			})] })
		]
	}) : /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(Xe, {
		x: 105,
		y: 95,
		scale: 1.2,
		tall: t >= 2
	}), /* @__PURE__ */ h(Xe, {
		x: 218,
		y: 117,
		scale: .6
	})] }), /* @__PURE__ */ g("svg", {
		viewBox: "0 0 300 180",
		className: n,
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ h("rect", {
				width: "300",
				height: "180",
				fill: Y.sky
			}),
			/* @__PURE__ */ h("path", {
				d: "M0 95L65 70L92 84L146 33L187 81L234 63L300 90V180H0Z",
				fill: "#8bb49c"
			}),
			/* @__PURE__ */ h("path", {
				d: "M96 82L146 33L156 65L174 82L147 75L129 89Z",
				fill: "#bed0ad"
			}),
			/* @__PURE__ */ h("path", {
				d: "M0 113Q82 92 153 118T300 104V180H0Z",
				fill: Y.sea
			}),
			/* @__PURE__ */ h("path", {
				d: "M0 140Q50 100 111 117Q179 135 247 113L300 133V180H0Z",
				fill: Y.sand
			}),
			/* @__PURE__ */ h("path", {
				d: "M0 159Q55 129 100 143T196 153T300 139",
				fill: "none",
				stroke: Y.foam,
				strokeWidth: "4"
			}),
			/* @__PURE__ */ h("path", {
				d: "M25 45Q39 26 51 43Q62 32 78 48H25M210 31Q219 18 231 28Q243 12 260 32Z",
				fill: "#ecf6e3"
			}),
			/* @__PURE__ */ h(Ye, {
				x: 272,
				y: 100,
				size: .8
			}),
			r,
			/* @__PURE__ */ h("path", {
				d: "M11 173L21 164L28 173M250 169L258 160L265 170",
				fill: "none",
				stroke: Y.lightLeaf,
				strokeWidth: "3"
			})
		]
	});
}
//#endregion
//#region src/games/palmisland/card.tsx
var Qe = /* @__PURE__ */ "games.palmisland.cards.tracker,games.palmisland.cards.canoe,games.palmisland.cards.logger,games.palmisland.cards.quarry,games.palmisland.cards.market,games.palmisland.cards.trade,games.palmisland.cards.tool,games.palmisland.cards.housing,games.palmisland.cards.temple,games.palmisland.cards.statue,games.palmisland.cards.heart,games.palmisland.cards.spirit,games.palmisland.cards.horn,games.palmisland.cards.tooth,games.palmisland.cards.axe,games.palmisland.cards.vision,games.palmisland.cards.monument,games.palmisland.cards.balance,games.palmisland.cards.chief,games.palmisland.cards.merchant,games.palmisland.cards.builder,games.palmisland.cards.elder,games.palmisland.cards.priest,games.palmisland.cards.wayfinder,games.palmisland.cards.raider,games.palmisland.cards.sea,games.palmisland.cards.forest,games.palmisland.cards.mountain".split(",");
function Z(e, t) {
	return t(Qe[e === 0 ? 0 : e <= 3 ? 1 : e <= 6 ? 2 : e <= 9 ? 3 : e === 10 ? 4 : e === 11 ? 5 : e === 12 ? 6 : e <= 14 ? 7 : e <= 16 ? 8 : e <= 25 ? e - 8 : e >= 30 && e <= 36 ? e - 12 : 25 + (j.find((t) => t.id === e)?.type ?? 0)]);
}
function $e({ type: e }) {
	let t = r().replaceAll(":", "");
	return /* @__PURE__ */ g("svg", {
		viewBox: "0 0 28 28",
		"aria-hidden": !0,
		className: "palm-resource-icon",
		children: [/* @__PURE__ */ h("defs", { children: /* @__PURE__ */ g("linearGradient", {
			id: `r${t}`,
			x1: "0",
			y1: "1",
			x2: "1",
			y2: "0",
			children: [
				/* @__PURE__ */ h("stop", { stopColor: e === 0 ? "#30342e" : e === 1 ? "#ae4e4d" : "#49424c" }),
				/* @__PURE__ */ h("stop", {
					offset: ".45",
					stopColor: e === 0 ? "#62665a" : e === 1 ? "#d57875" : "#bbb2bc"
				}),
				/* @__PURE__ */ h("stop", {
					offset: "1",
					stopColor: e === 0 ? "#969183" : e === 1 ? "#edb2a6" : "#e1d6da"
				})
			]
		}) }), e === 0 ? /* @__PURE__ */ g("g", {
			stroke: "#48483d",
			strokeWidth: ".5",
			children: [
				/* @__PURE__ */ h("path", {
					d: "M3 5Q5 1 9 3L24 16L16 26L2 12Q0 9 3 5Z",
					fill: `url(#r${t})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M3 5Q8 5 13 9M2 8Q10 10 15 15M3 12Q12 14 17 20M8 4L9 7M7 10L9 13M13 11L14 15M12 17L14 18M18 14L19 17",
					fill: "none",
					stroke: "#b0aaa0",
					strokeWidth: ".6"
				}),
				/* @__PURE__ */ h("path", {
					d: "M6 4L20 16M3 9L17 22M9 8L21 20",
					stroke: "#3b4037",
					fill: "none"
				}),
				/* @__PURE__ */ h("ellipse", {
					cx: "20",
					cy: "21",
					rx: "6.5",
					ry: "4.7",
					transform: "rotate(-48 20 21)",
					fill: "#b19b76",
					strokeWidth: ".8"
				}),
				/* @__PURE__ */ h("path", {
					d: "M17 23C14 20 19 15 22 18C26 22 19 27 17 23M19 23C16 21 20 18 22 20C24 22 20 25 19 23M21 21L20 22",
					stroke: "#6e5b43",
					strokeWidth: ".55",
					fill: "none"
				})
			]
		}) : e === 1 ? /* @__PURE__ */ g("g", {
			stroke: "#9d4946",
			strokeWidth: ".5",
			children: [
				/* @__PURE__ */ h("path", {
					d: "M10 5Q14 3 18 7L16 11M8 13L9 19L14 19M13 11Q17 9 20 16L24 18L27 19L23 21L22 27L19 23L17 21Q7 20 4 11L2 4Q3 2 6 4Q7 1 9 3Z",
					fill: `url(#r${t})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M2 4L5 6L4 8L3 8M7 4Q4 10 8 13Q13 16 18 20M8 8Q11 10 13 14M8 6Q12 7 15 11",
					fill: "none",
					stroke: "#f4c6b7",
					strokeWidth: "1"
				}),
				/* @__PURE__ */ h("path", {
					d: "M8 7Q8 11 5 13M11 11L10 15L13 17M18 19L23 20M20 21L22 24M11 5L14 8M14 5L16 9",
					fill: "none",
					stroke: "#a44946",
					strokeWidth: ".6"
				}),
				/* @__PURE__ */ h("path", {
					d: "M7 12Q7 16 11 18L11 14",
					fill: "#e29b8e"
				}),
				/* @__PURE__ */ h("circle", {
					cx: "5",
					cy: "5.2",
					r: ".9",
					fill: "#563832"
				}),
				/* @__PURE__ */ h("circle", {
					cx: "4.8",
					cy: "5",
					r: ".25",
					fill: "#f9d0bb"
				})
			]
		}) : /* @__PURE__ */ g("g", {
			stroke: "#5a505b",
			strokeWidth: ".5",
			children: [
				/* @__PURE__ */ h("path", {
					d: "M3 21L6 14L11 11L14 8L18 7L24 2L23 8L25 5L23 13L18 21L9 26L5 25Z",
					fill: `url(#r${t})`
				}),
				/* @__PURE__ */ h("path", {
					d: "M3 21Q9 21 15 16L23 8M5 24Q12 24 18 19L22 13M6 16L12 14L17 10L22 7M10 12L15 9L19 8L24 2",
					fill: "none",
					stroke: "#e0d4d8",
					strokeWidth: "1.1"
				}),
				/* @__PURE__ */ h("path", {
					d: "M3 21Q9 22 17 17L22 12L20 17Q14 23 6 24Z",
					fill: "#514951"
				}),
				/* @__PURE__ */ h("path", {
					d: "M7 18L12 17L16 14M8 25L13 23",
					stroke: "#9b8d9b",
					fill: "none"
				})
			]
		})]
	});
}
function et({ operation: e }) {
	let t = r().replaceAll(":", ""), n = e === "store" ? [
		"#7dc565",
		"#55b652",
		"#2c9849"
	] : e === "rotate" ? [
		"#ffe13d",
		"#f6c20f",
		"#dca400"
	] : [
		"#569bc9",
		"#2583c1",
		"#186bb0"
	];
	return /* @__PURE__ */ g("svg", {
		viewBox: "0 0 24 24",
		width: "17",
		height: "17",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ h("defs", { children: /* @__PURE__ */ g("radialGradient", {
				id: `a${t}`,
				cx: "35%",
				cy: "25%",
				r: "80%",
				children: [
					/* @__PURE__ */ h("stop", { stopColor: n[0] }),
					/* @__PURE__ */ h("stop", {
						offset: ".55",
						stopColor: n[1]
					}),
					/* @__PURE__ */ h("stop", {
						offset: "1",
						stopColor: n[2]
					})
				]
			}) }),
			/* @__PURE__ */ h("circle", {
				cx: "12",
				cy: "12",
				r: "10.5",
				fill: `url(#a${t})`
			}),
			/* @__PURE__ */ h("path", {
				d: "M3 11Q3 2 12 2Q18 2 21 8",
				fill: "none",
				stroke: n[0],
				strokeWidth: ".7"
			}),
			e === "flip" ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
				d: "M6 10C7 5 19 6 19 12C19 17 11 18 7 15",
				fill: "none",
				stroke: "white",
				strokeWidth: "2.7",
				strokeLinecap: "round"
			}), /* @__PURE__ */ h("path", {
				d: "M10 10.5L4 14L10 18Z",
				fill: "white"
			})] }) : e === "store" ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
				d: "M5 17Q6 8 15 10",
				fill: "none",
				stroke: "white",
				strokeWidth: "3"
			}), /* @__PURE__ */ h("path", {
				d: "M14 6.5L20 10L14 14.5Z",
				fill: "white"
			})] }) : /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
				d: "M7 18V11C7 4 18 4 18 12",
				fill: "none",
				stroke: "white",
				strokeWidth: "2.6"
			}), /* @__PURE__ */ h("path", {
				d: "M14 11.5L18 18L21.5 11.5Z",
				fill: "white"
			})] })
		]
	});
}
function tt() {
	let e = r().replaceAll(":", "");
	return /* @__PURE__ */ g("svg", {
		viewBox: "0 0 24 24",
		className: "palm-value-icon",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ h("defs", { children: /* @__PURE__ */ g("linearGradient", {
				id: `p${e}`,
				x1: "0",
				y1: "0",
				x2: ".5",
				y2: "1",
				children: [
					/* @__PURE__ */ h("stop", { stopColor: "#fff26b" }),
					/* @__PURE__ */ h("stop", {
						offset: ".45",
						stopColor: "#f4d126"
					}),
					/* @__PURE__ */ h("stop", {
						offset: "1",
						stopColor: "#d6a80c"
					})
				]
			}) }),
			/* @__PURE__ */ h("path", {
				d: "M12 1L15.2 8.3L23.3 8.9L17.2 14.2L19 22.2L12 18L4.9 22.2L6.6 14.2L.6 8.9L8.7 8.3Z",
				fill: `url(#p${e})`
			}),
			/* @__PURE__ */ h("path", {
				d: "M12 2.3L12 12L2.2 9.3L9.3 8.8Z",
				fill: "#fff18b",
				opacity: ".65"
			})
		]
	});
}
function nt() {
	return /* @__PURE__ */ g("svg", {
		viewBox: "0 0 24 24",
		className: "palm-value-icon palm-value-icon--upgrade",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ h("rect", {
				width: "24",
				height: "24",
				rx: "3",
				fill: "#967347"
			}),
			/* @__PURE__ */ h("path", {
				d: "M12 1L1 11H7V15H17V11H23Z",
				fill: "#fffdf1"
			}),
			/* @__PURE__ */ h("path", {
				d: "M7 17.5H17M7 20H17M7 22.5H17",
				fill: "none",
				stroke: "#fffdf1",
				strokeWidth: "1.5"
			})
		]
	});
}
function Q({ value: e, score: t = !1 }) {
	let n = c();
	return /* @__PURE__ */ g("span", {
		className: "palm-card-value",
		"aria-label": n(t ? "games.palmisland.score" : "games.palmisland.upgrades", { n: e }),
		children: [/* @__PURE__ */ h("b", { children: e }), h(t ? tt : nt, {})]
	});
}
function $({ value: e, zeroLabel: t = !0 }) {
	let n = c();
	return /* @__PURE__ */ h("span", {
		className: "palm-r palm-resource-line",
		children: e.every((e) => e === 0) ? t ? n("games.palmisland.free") : null : e.map((e, t) => e > 0 && /* @__PURE__ */ g("span", {
			"aria-label": `${n(t === 0 ? "games.palmisland.wood" : t === 1 ? "games.palmisland.fish" : "games.palmisland.stone")} ${e}`,
			children: [/* @__PURE__ */ h($e, { type: t }), /* @__PURE__ */ h("b", { children: e })]
		}, t))
	});
}
function rt({ card: e, compact: t = !1, controls: n, preview: r }) {
	let i = c(), a = M(e), o = j.find((t) => t.id === e.id), s = e.id === 19 && e.face === 1 ? "games.palmisland.effect.spirit" : e.id === 21 ? "games.palmisland.effect.tooth" : e.id === 22 ? "games.palmisland.effect.axe" : e.id === 23 ? "games.palmisland.effect.vision" : e.id === 24 ? "games.palmisland.effect.monument" : e.id === 30 ? "games.palmisland.effect.chief" : e.id === 31 ? "games.palmisland.effect.merchant" : e.id === 32 ? "games.palmisland.effect.builder" : e.id === 33 ? "games.palmisland.effect.elder" : e.id === 34 ? "games.palmisland.effect.priest" : e.id === 35 ? "games.palmisland.effect.wayfinder" : e.id === 36 ? "games.palmisland.effect.raider" : null, l = /* @__PURE__ */ g(m, { children: [
		/* @__PURE__ */ h("span", {
			className: "palm-card-number",
			children: String(e.id).padStart(2, "0")
		}),
		/* @__PURE__ */ h("strong", { children: Z(e.id, i) }),
		/* @__PURE__ */ g("span", {
			className: "palm-card-marks",
			children: [(a.points !== 0 || o) && /* @__PURE__ */ h(Q, {
				value: o?.points ?? a.points,
				score: !0
			}), a.upgrades > 0 && /* @__PURE__ */ h(Q, { value: a.upgrades })]
		})
	] });
	return /* @__PURE__ */ g("div", {
		className: `palm-card-content${t ? " palm-card-content--compact" : ""}`,
		children: [
			n ? /* @__PURE__ */ h("button", {
				className: "palm-card-select",
				onClick: n.onSelect,
				"aria-pressed": n.selected,
				children: l
			}) : /* @__PURE__ */ h("div", {
				className: "palm-card-select",
				children: l
			}),
			/* @__PURE__ */ g("div", {
				className: "palm-card-picture",
				...n?.pointer,
				children: [
					/* @__PURE__ */ h(X, {
						kind: o ? [
							1,
							4,
							7
						][o.type] : e.id,
						level: a.upgrades,
						portrait: !t
					}),
					a.resources.length > 0 && /* @__PURE__ */ h("div", {
						className: "palm-card-yield",
						children: a.resources.map((e, t) => /* @__PURE__ */ g("span", { children: [t > 0 && /* @__PURE__ */ h("small", { children: "/" }), /* @__PURE__ */ h($, { value: e })] }, t))
					}),
					r && /* @__PURE__ */ g("div", {
						className: "palm-upgrade-preview",
						children: [/* @__PURE__ */ h(X, {
							kind: r.id,
							level: M(r).upgrades
						}), /* @__PURE__ */ g("div", { children: [
							/* @__PURE__ */ h("strong", { children: i(n?.pending === "rotate" ? "games.palmisland.afterRotate" : "games.palmisland.afterFlip") }),
							/* @__PURE__ */ g("span", {
								className: "palm-card-marks",
								children: [M(r).points !== 0 && /* @__PURE__ */ h(Q, {
									value: M(r).points,
									score: !0
								}), M(r).upgrades > 0 && /* @__PURE__ */ h(Q, { value: M(r).upgrades })]
							}),
							M(r).resources.length ? M(r).resources.map((e, t) => /* @__PURE__ */ h($, { value: e }, t)) : /* @__PURE__ */ h("small", { children: i("games.palmisland.noYield") })
						] })]
					})
				]
			}),
			/* @__PURE__ */ h("div", {
				className: "palm-card-actions",
				children: [
					"store",
					"rotate",
					"flip"
				].map((e) => {
					if (!a.actions[e]) return null;
					let t = /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("span", {
						className: "palm-action-name",
						children: [/* @__PURE__ */ h(et, { operation: e }), i(e === "store" ? "games.palmisland.store" : e === "rotate" ? "games.palmisland.rotate" : "games.palmisland.flip")]
					}), /* @__PURE__ */ h("span", {
						className: "palm-action-cost",
						children: a.actions[e].map((e, t) => /* @__PURE__ */ g("span", { children: [t > 0 && /* @__PURE__ */ h("small", { children: " / " }), /* @__PURE__ */ h($, { value: e })] }, t))
					})] });
					return n ? /* @__PURE__ */ h("button", {
						className: `palm-action${n.pending === e ? " is-active" : ""}`,
						disabled: !n.legal.includes(e),
						onClick: () => n.onAction(e),
						children: t
					}, e) : /* @__PURE__ */ h("div", {
						className: "palm-action",
						children: t
					}, e);
				})
			}),
			s && /* @__PURE__ */ h("div", {
				className: "palm-card-effect",
				children: i(s)
			}),
			/* @__PURE__ */ g("div", {
				className: "palm-card-footer",
				children: [/* @__PURE__ */ h("span", {
					className: "palm-face-marks",
					"aria-label": i(it[e.face]),
					children: [
						0,
						1,
						2,
						3
					].map((t) => /* @__PURE__ */ h("i", { className: t === e.face ? "is-current" : "" }, t))
				}), n ? /* @__PURE__ */ g("button", {
					className: "palm-inspect",
					onClick: n.onInspect,
					children: [/* @__PURE__ */ h(d, { size: 14 }), i("games.palmisland.preview")]
				}) : /* @__PURE__ */ h("span", {
					className: "palm-face-label",
					children: i(it[e.face])
				})]
			})
		]
	});
}
var it = [
	"games.palmisland.faceFront",
	"games.palmisland.faceFrontTurned",
	"games.palmisland.faceBack",
	"games.palmisland.faceBackTurned"
];
//#endregion
//#region src/games/palmisland/table.tsx
function at() {
	return /* @__PURE__ */ h("svg", {
		className: "palm-ants",
		viewBox: "0 0 100 160",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: /* @__PURE__ */ h("rect", {
			x: ".5",
			y: ".5",
			width: "99",
			height: "159",
			rx: "2",
			children: /* @__PURE__ */ h("animate", {
				attributeName: "stroke-dashoffset",
				from: "26",
				to: "0",
				dur: "1.2s",
				repeatCount: "indefinite"
			})
		})
	});
}
function ot({ card: e, onClick: t, selected: n }) {
	let r = c(), i = M(e), a = j.find((t) => t.id === e.id);
	return /* @__PURE__ */ g("button", {
		className: "palm-building",
		onClick: t,
		"aria-pressed": n,
		"aria-label": `${r("games.palmisland.cardDetails")} · ${Z(e.id, r)} #${e.id}`,
		children: [
			/* @__PURE__ */ h(X, {
				kind: a ? [
					1,
					4,
					7
				][a.type] : e.id,
				level: i.upgrades
			}),
			/* @__PURE__ */ g("span", {
				className: "palm-building-name",
				children: [/* @__PURE__ */ h("span", { children: Z(e.id, r) }), /* @__PURE__ */ h("small", { children: String(e.id).padStart(2, "0") })]
			}),
			(i.points !== 0 || i.upgrades > 0 || a) && /* @__PURE__ */ g("span", {
				className: "palm-building-marks",
				children: [(i.points !== 0 || a) && /* @__PURE__ */ h(Q, {
					value: a?.points ?? i.points,
					score: !0
				}), i.upgrades > 0 && /* @__PURE__ */ h(Q, { value: i.upgrades })]
			})
		]
	});
}
function st({ card: e, canRelease: t, onRelease: n, selecting: r, selected: i, candidate: a, choice: o, onSelect: u, onChoice: d, onInspect: ee, anchor: te = !0 }) {
	let f = c(), { ref: p, hidden: m } = s(te ? `palm-stored:${e.id}` : null);
	return /* @__PURE__ */ g("div", {
		className: "palm-resource-shell",
		ref: p,
		style: m ? { visibility: "hidden" } : void 0,
		children: [
			/* @__PURE__ */ g("button", {
				className: `palm-resource${i ? " is-chosen" : ""}${r && !a ? " is-disabled" : ""}`,
				disabled: r && !a,
				onClick: r ? u : ee,
				"aria-pressed": r ? i : void 0,
				"aria-label": `${f(r ? "games.palmisland.choose" : "games.palmisland.cardDetails")} · ${Z(e.id, f)} #${e.id}`,
				children: [
					/* @__PURE__ */ h("span", {
						className: "palm-resource-art",
						children: /* @__PURE__ */ h(X, {
							kind: e.id,
							level: M(e).upgrades
						})
					}),
					/* @__PURE__ */ g("span", {
						className: "palm-resource-info",
						children: [/* @__PURE__ */ g("span", {
							className: "palm-resource-name",
							children: [
								Z(e.id, f),
								" ",
								/* @__PURE__ */ h("small", {
									className: "palm-resource-id",
									children: String(e.id).padStart(2, "0")
								})
							]
						}), /* @__PURE__ */ h("span", {
							className: `palm-resource-yields${M(e).resources.length > 1 ? " has-alternatives" : ""}`,
							children: M(e).resources.map((e, t) => /* @__PURE__ */ g("span", {
								className: "palm-resource-option",
								children: [t > 0 && !i && " / ", (!r || !i || t === o) && /* @__PURE__ */ h($, { value: e })]
							}, t))
						})]
					}),
					r && /* @__PURE__ */ h("span", {
						className: "palm-resource-choice",
						children: i && /* @__PURE__ */ h(l, { size: 13 })
					}),
					r && a && !i && /* @__PURE__ */ h(at, {})
				]
			}),
			!r && t && /* @__PURE__ */ h("button", {
				className: "palm-resource-reset",
				onClick: n,
				"aria-label": `${f("games.palmisland.release")} ${Z(e.id, f)} #${e.id}`,
				children: f("games.palmisland.release")
			}),
			r && i && M(e).resources.length > 1 && /* @__PURE__ */ h("div", {
				className: "palm-resource-alternatives",
				role: "group",
				"aria-label": f("games.palmisland.chooseYield"),
				children: M(e).resources.map((e, t) => /* @__PURE__ */ h("button", {
					className: "palm-resource-alternative",
					"aria-pressed": t === o,
					onClick: () => d(t),
					children: /* @__PURE__ */ h($, { value: e })
				}, t))
			})
		]
	});
}
function ct(e, t) {
	let n = e.cards.indexOf(t);
	return n >= 0 ? {
		cards: e.cards.filter((e, t) => t !== n),
		choices: e.choices.filter((e, t) => t !== n)
	} : {
		cards: [...e.cards, t],
		choices: [...e.choices, 0]
	};
}
//#endregion
//#region src/games/palmisland/view-player.tsx
var lt = () => ({
	cards: [],
	choices: []
});
function ut(e, t) {
	return e.cards.length === t.cards.length && e.cards.every((n, r) => t.cards.includes(n) && e.choices[r] === t.choices[t.cards.indexOf(n)]);
}
function dt(e) {
	return j.some((t) => t.id === e) ? [
		1,
		1,
		1
	] : M({
		id: e,
		face: 0
	}).actions.rotate[0];
}
function ft(e) {
	let t = e.public, n = e.private, r = `${t.phase}:${t.round}:${n?.top.map((e) => `${e.id}-${e.face}-${e.stored}`).join(",")}:${n?.stored.map((e) => e.id).join(",")}`;
	return /* @__PURE__ */ h(pt, {
		...e,
		viewKey: r,
		pub: t,
		priv: n
	});
}
function pt({ pub: e, priv: t, members: r, myRid: u, send: d, viewKey: ee }) {
	f();
	let _ = c(), v = e.players.find((e) => e.rid === u), { ref: ne } = s("palm-top:0"), { ref: re } = s("palm-top:1"), { ref: ie } = s("palm-bottom"), [y, b] = a(t?.top[0]?.id ?? 0), [x, S] = a(null), [C, w] = a("store"), [T, E] = a(lt), [D, O] = a(null), [k, ae] = a([]), [A, oe] = a(null), [se, ce] = a(1), [le, ue] = a(1), [de, pe] = a(4), [N, P] = a(null), [F, me] = a(!1), [I, he] = a([]), ge = i(null), _e = i(null), ve = i(null), [ye, be] = a(null), L = i(null), xe = i(0), [R, z] = a({
		x: 0,
		y: 0,
		id: -1
	}), [Se, B] = a(ee);
	Se !== ee && (B(ee), b(t?.top[0]?.id ?? 0), S(null), be(null), E(lt()), O(null), me(!1));
	let V = t?.top.find((e) => e.id === y) ?? t?.top[0], H = t?.moves.filter((e) => e.card === V?.id && e.operation === C) ?? [], U = H.find((e) => ut(e.payment, T) && e.release === D && !!e.support === F), W = e.phase === "begin" && !v?.ready || e.phase === "play" && !v?.arrived || e.phase === "council", Ce = e.phase === "begin" ? v?.ready ? _("games.palmisland.wait") : _("games.palmisland.begin") : e.phase === "play" ? v?.arrived ? _("games.palmisland.wait") : _("games.palmisland.play") : e.phase === "resolve" ? _("games.palmisland.resolving") : _("games.palmisland.council");
	function we(e, n) {
		let r = t?.moves.filter((t) => t.card === e && t.operation === n) ?? [];
		if (!r.length) return;
		b(e), w(n);
		let i = r.find((e) => !e.payment.cards.length && e.release === null && !e.support);
		i ? d(i) : (E(lt()), O(null), me(!1), S("payment"));
	}
	function Te(t, n) {
		e.phase === "play" && !v?.arrived && x === null && t.isPrimary && t.button === 0 && (L.current = {
			x: t.clientX,
			y: t.clientY,
			id: n
		}, t.currentTarget.setPointerCapture(t.pointerId));
	}
	function Ee(e) {
		let t = L.current;
		if (L.current = null, z({
			x: 0,
			y: 0,
			id: -1
		}), !t) return;
		let n = e.clientX - t.x, r = e.clientY - t.y;
		Math.max(Math.abs(n), Math.abs(r)) < 42 || (xe.current = e.timeStamp + 250, e.preventDefault(), we(t.id, Math.abs(n) > Math.abs(r) ? n > 0 ? "store" : "flip" : r < 0 ? "rotate" : "discard"));
	}
	let De = () => ({
		type: "begin",
		active: k,
		release: I,
		reorder: A,
		canoe: se,
		canoeFace: le,
		logger: de
	}), Oe = (t?.stored.filter((e) => !I.includes(e.id)).length ?? 0) + k.filter((e) => [35, 36].includes(e) && !t?.stored.some((t) => t.id === e && !I.includes(e))).length, ke = e.round === 1 && e.config.mode === "solo" && e.config.feats.includes(23) || e.config.mode === "cooperative" && e.config.ability === "rebuild" && e.abilityFace === 1, Ae = e.project === "finish" || e.projectAvailable && e.players.every((e) => e.pledge !== null) && e.cost.every((t, n) => e.players.reduce((e, t) => e + (t.pledge?.[n] ?? 0), 0) >= t), je = T.cards.reduce((e, n, r) => {
		let i = t?.stored.find((e) => e.id === n);
		return fe(e, i ? M(i).resources[T.choices[r]] ?? [
			0,
			0,
			0
		] : [
			0,
			0,
			0
		]);
	}, [
		0,
		0,
		0
	]), Me = j.find((e) => e.id === N), Ne = e.turn === u && N !== null && e.market.includes(N) && dt(N).every((e, t) => je[t] >= e) && (!Me || !e.market.some((e) => (j.find((t) => t.id === e)?.points ?? 0) > Me.points)), G = x === "payment", Pe = H.filter((e) => ut(e.payment, T) && !!e.support === F), Fe = Pe.flatMap((e) => e.release === null ? [] : [e.release]), Ie = Fe.length > 0 && !Pe.some((e) => e.release === null), Le = fe(je, F ? e.shipping.find((e) => e.to === u)?.resources ?? [
		0,
		0,
		0
	] : [
		0,
		0,
		0
	]), K = [...V && [
		"store",
		"rotate",
		"flip"
	].includes(C) ? M(V).actions[C] ?? [] : []].sort((e, t) => e.reduce((e, t, n) => e + Math.max(0, t - Le[n]), 0) - t.reduce((e, t, n) => e + Math.max(0, t - Le[n]), 0))[0] ?? [
		0,
		0,
		0
	], Re = (e) => {
		ge.current = x, be(e), S("preview");
	}, ze = (e) => {
		E(e), O(null);
	}, Be = R.id < 0 || Math.max(Math.abs(R.x), Math.abs(R.y)) < 18 ? null : Math.abs(R.x) > Math.abs(R.y) ? R.x > 0 ? "store" : "flip" : R.y < 0 ? "rotate" : "discard", Ve = C === "store" ? "games.palmisland.store" : C === "rotate" ? "games.palmisland.rotate" : "games.palmisland.flip", q = x !== null && !G;
	return n(() => {
		q ? (ve.current ??= document.activeElement, _e.current?.querySelector(".bottom-sheet__panel button")?.focus({ preventScroll: !0 }), _e.current?.querySelector(".bottom-sheet__content")?.scrollTo(0, 0)) : (ve.current?.focus({ preventScroll: !0 }), ve.current = null);
	}, [
		q,
		x,
		ye
	]), /* @__PURE__ */ g("div", {
		ref: _e,
		className: `palm-root${G ? " is-paying" : ""}`,
		onKeyDown: (e) => {
			if (q && (e.key === "Escape" && (e.stopPropagation(), S(x === "preview" ? ge.current : null)), e.key === "Tab")) {
				let t = [..._e.current.querySelectorAll(".bottom-sheet__panel button:not(:disabled),.bottom-sheet__panel input:not(:disabled),.bottom-sheet__panel select")].filter((e) => e.getClientRects().length), n = t[0], r = t.at(-1);
				e.shiftKey && document.activeElement === n ? (e.preventDefault(), r?.focus()) : !e.shiftKey && document.activeElement === r && (e.preventDefault(), n?.focus());
			}
		},
		onClickCapture: (e) => {
			xe.current > e.timeStamp && e.detail > 0 && (xe.current = 0, e.preventDefault(), e.stopPropagation());
		},
		children: [
			/* @__PURE__ */ h("img", {
				className: "palm-table-background",
				src: qe,
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ h(te, {
				kind: "sheen",
				base: "#dce8d5",
				className: "palm-texture"
			}),
			/* @__PURE__ */ h("div", {
				className: "palm-gameplay",
				inert: q,
				children: /* @__PURE__ */ h(p, {
					adaptive: !0,
					scroll: !1,
					className: "palm-screen",
					banner: /* @__PURE__ */ g("header", {
						className: "palm-topbar",
						children: [
							/* @__PURE__ */ g("div", {
								className: "palm-brand",
								children: [/* @__PURE__ */ h("div", {
									className: "palm-brand-mark",
									"aria-hidden": !0,
									children: "P"
								}), /* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("h1", { children: _("games.palmisland.name") }), /* @__PURE__ */ h("small", { children: "PALM ISLAND" })] })]
							}),
							/* @__PURE__ */ g("div", {
								className: "palm-round",
								children: [/* @__PURE__ */ h("span", {
									className: "palm-round-number",
									children: _("games.palmisland.round", { n: e.round })
								}), /* @__PURE__ */ h("span", {
									className: "palm-round-track",
									"aria-hidden": !0,
									children: Array.from({ length: 8 }, (t, n) => /* @__PURE__ */ h("span", { className: n < e.round - 1 ? "is-past" : n === e.round - 1 ? "is-now" : "" }, n))
								})]
							}),
							/* @__PURE__ */ h("div", {
								className: "palm-players",
								children: e.players.map((t) => /* @__PURE__ */ g("div", {
									className: `palm-player${t.rid === u ? " is-me" : ""}`,
									children: [
										/* @__PURE__ */ h("span", {
											className: "palm-player-avatar",
											"aria-hidden": !0,
											children: (r.find((e) => e.rid === t.rid)?.name ?? "?").slice(0, 1)
										}),
										/* @__PURE__ */ g("span", {
											className: "palm-player-name",
											children: [r.find((e) => e.rid === t.rid)?.name, /* @__PURE__ */ h("small", { children: t.arrived || t.ready && e.phase === "begin" ? /* @__PURE__ */ h(l, { size: 12 }) : null })]
										}),
										/* @__PURE__ */ g("span", {
											className: "palm-player-score",
											children: [t.points, /* @__PURE__ */ h(tt, {})]
										})
									]
								}, t.rid))
							})
						]
					}),
					actionsHeight: "palm-actions-height",
					actions: /* @__PURE__ */ g("footer", {
						className: "palm-bottom",
						children: [/* @__PURE__ */ h("div", {
							ref: ie,
							className: "palm-bottom-anchor",
							"aria-hidden": !0
						}), G ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("div", {
							className: "palm-pay-line",
							children: [/* @__PURE__ */ g("div", {
								className: "palm-pay-target",
								children: [
									/* @__PURE__ */ h(et, { operation: C }),
									V && Z(V.id, _),
									" · ",
									_(Ve)
								]
							}), /* @__PURE__ */ g("div", {
								className: "palm-pay-balance",
								children: [K.map((e, t) => e > 0 && /* @__PURE__ */ g("span", {
									className: `palm-r${Le[t] >= e ? " is-met" : ""}`,
									"aria-label": _("games.palmisland.paymentBalance", {
										resource: _(t === 0 ? "games.palmisland.wood" : t === 1 ? "games.palmisland.fish" : "games.palmisland.stone"),
										n: Le[t],
										cost: e
									}),
									children: [
										/* @__PURE__ */ h($e, { type: t }),
										/* @__PURE__ */ h("b", { children: Le[t] }),
										/* @__PURE__ */ g("small", { children: ["/ ", e] })
									]
								}, t)), Ie && /* @__PURE__ */ h("span", { children: _("games.palmisland.replacement") })]
							})]
						}), /* @__PURE__ */ g("div", {
							className: "palm-pay-buttons",
							children: [/* @__PURE__ */ h("button", {
								className: "palm-button",
								onClick: () => {
									S(null), E(lt()), O(null);
								},
								children: _("games.palmisland.cancel")
							}), /* @__PURE__ */ h("button", {
								className: "palm-button palm-button-primary",
								disabled: !U,
								onClick: () => {
									U && (d(U), S(null));
								},
								children: _(Ie ? "games.palmisland.resetStore" : "games.palmisland.payConfirm")
							})]
						})] }) : /* @__PURE__ */ g(m, { children: [e.phase === "play" && !v?.arrived ? /* @__PURE__ */ h("div", {
							className: "palm-next",
							children: t?.top[2] && /* @__PURE__ */ g("button", {
								className: "palm-next-card",
								onClick: () => S("next"),
								children: [
									/* @__PURE__ */ h(X, {
										kind: t.top[2].id || 15,
										level: M(t.top[2]).upgrades
									}),
									/* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h("small", { children: _("games.palmisland.next") }), /* @__PURE__ */ h("strong", { children: Z(t.top[2].id, _) })] }),
									/* @__PURE__ */ g("span", { children: [
										"#",
										t.top[2].id,
										" ↗"
									] })
								]
							})
						}) : /* @__PURE__ */ h("button", {
							className: "palm-button palm-button-primary",
							disabled: !W || e.phase === "resolve" || e.phase === "play",
							onClick: () => S(e.phase === "begin" ? "begin" : "council"),
							children: e.phase === "begin" && !v?.ready ? _("games.palmisland.start") : Ce
						}), /* @__PURE__ */ h("button", {
							className: "palm-button palm-mobile-buildings",
							onClick: () => S("village"),
							children: _("games.palmisland.viewVillage")
						})] })]
					}),
					children: /* @__PURE__ */ g("div", {
						className: "palm-main",
						children: [
							/* @__PURE__ */ g("aside", {
								className: "palm-supply-panel",
								children: [
									/* @__PURE__ */ g("header", {
										className: "palm-section-head",
										children: [/* @__PURE__ */ h("h2", { children: _(G ? Ie ? "games.palmisland.replacement" : "games.palmisland.payment" : "games.palmisland.supply") }), /* @__PURE__ */ g("span", { children: [
											t?.stored.length ?? 0,
											" / ",
											v?.capacity ?? 4
										] })]
									}),
									/* @__PURE__ */ g("div", {
										className: "palm-resource-stack",
										children: [t?.stored.map((e) => /* @__PURE__ */ h(st, {
											card: e,
											canRelease: t.moves.some((t) => t.card === e.id && t.operation === "release"),
											onRelease: () => we(e.id, "release"),
											selecting: G,
											selected: G && (T.cards.includes(e.id) || D === e.id),
											candidate: Ie ? Fe.includes(e.id) : H.some((t) => t.payment.cards.includes(e.id)),
											choice: T.choices[T.cards.indexOf(e.id)] ?? 0,
											onSelect: () => Ie ? O(D === e.id ? null : e.id) : ze(ct(T, e.id)),
											onChoice: (t) => ze({
												...T,
												choices: T.choices.map((n, r) => T.cards[r] === e.id ? t : n)
											}),
											onInspect: () => Re(e)
										}, e.id)), (t?.stored.length ?? 0) < (v?.capacity ?? 4) && /* @__PURE__ */ h("div", {
											className: "palm-empty-slot",
											children: _("games.palmisland.emptySlot")
										})]
									}),
									/* @__PURE__ */ g("div", {
										className: "palm-supply-tools",
										children: [
											e.shippingAvailable.includes(u) && /* @__PURE__ */ h("button", {
												className: "palm-button",
												onClick: () => {
													E(lt()), S("shipping");
												},
												children: _("games.palmisland.shippingOffer")
											}),
											G && e.shipping.filter((e) => e.to === u).map((e) => /* @__PURE__ */ g("label", {
												className: "palm-support",
												children: [/* @__PURE__ */ h("input", {
													type: "checkbox",
													checked: F,
													onChange: (e) => {
														me(e.target.checked), O(null);
													}
												}), /* @__PURE__ */ g("span", { children: [
													_("games.palmisland.useShipping"),
													" · ",
													r.find((t) => t.rid === e.rid)?.name,
													/* @__PURE__ */ h($, { value: e.resources })
												] })]
											}, e.rid)),
											G && t?.active.includes(32) && /* @__PURE__ */ h("small", { children: _("games.palmisland.builderDiscount") })
										]
									})
								]
							}),
							/* @__PURE__ */ g("main", {
								className: "palm-hand",
								children: [/* @__PURE__ */ h("div", {
									className: "palm-hand-status",
									children: Be ? /* @__PURE__ */ g(m, { children: [_(Be === "store" ? "games.palmisland.store" : Be === "rotate" ? "games.palmisland.rotate" : Be === "flip" ? "games.palmisland.flip" : "games.palmisland.discard"), !t?.moves.some((e) => e.card === R.id && e.operation === Be) && ` · ${_("games.palmisland.unavailable")}`] }) : G || e.phase !== "play" || v?.arrived ? null : Ce
								}), /* @__PURE__ */ h("div", {
									className: "palm-card-pair",
									children: t?.top.slice(0, 2).map((n, r) => {
										let i = G ? [] : t.moves.filter((e) => e.card === n.id).map((e) => e.operation);
										return /* @__PURE__ */ g("div", {
											className: "palm-card-slot",
											children: [
												/* @__PURE__ */ g("div", {
													className: "palm-card-position",
													children: [/* @__PURE__ */ h("b", { children: _(r === 0 ? "games.palmisland.top" : "games.palmisland.second") }), r === 0 && /* @__PURE__ */ g("button", {
														className: "palm-discard",
														disabled: !i.includes("discard"),
														onClick: () => we(n.id, "discard"),
														children: [_("games.palmisland.discard"), " ↓"]
													})]
												}),
												/* @__PURE__ */ h("div", {
													className: `palm-card-stack${y === n.id ? " is-selected" : ""}`,
													style: R.id === n.id ? { transform: `translate(${R.x}px,${R.y}px) rotate(${R.x / 20}deg)` } : void 0,
													children: /* @__PURE__ */ g("article", {
														ref: r === 0 ? ne : re,
														className: "palm-card",
														"aria-label": `${Z(n.id, _)} #${n.id}`,
														children: [
															n.id === 0 ? /* @__PURE__ */ g("div", {
																className: "palm-tracker",
																children: [
																	/* @__PURE__ */ h(X, {
																		kind: 15,
																		level: e.round >= 4 ? 2 : 0
																	}),
																	/* @__PURE__ */ g("strong", { children: [e.round, "/8"] }),
																	/* @__PURE__ */ h("span", { children: _("games.palmisland.cards.tracker") })
																]
															}) : /* @__PURE__ */ h(rt, {
																card: n,
																preview: G && y === n.id && (C === "rotate" || C === "flip") ? {
																	...n,
																	face: n.face ^ (C === "rotate" ? 1 : 2)
																} : void 0,
																controls: {
																	selected: y === n.id,
																	legal: i,
																	pending: G && y === n.id ? C : void 0,
																	onSelect: () => {
																		G || b(n.id);
																	},
																	onAction: (e) => we(n.id, e),
																	onInspect: () => Re(n),
																	pointer: {
																		onPointerDown: (e) => Te(e, n.id),
																		onPointerMove: (e) => {
																			L.current?.id === n.id && z({
																				id: n.id,
																				x: Math.max(-70, Math.min(70, e.clientX - L.current.x)),
																				y: Math.max(-70, Math.min(70, e.clientY - L.current.y))
																			});
																		},
																		onPointerUp: Ee,
																		onPointerCancel: () => {
																			L.current = null, z({
																				x: 0,
																				y: 0,
																				id: -1
																			});
																		}
																	}
																}
															}),
															" ",
															i.some((e) => e !== "release") && /* @__PURE__ */ h(at, {}),
															n.stored && /* @__PURE__ */ h("span", {
																className: "palm-stored-badge",
																children: _("games.palmisland.supply")
															})
														]
													})
												}),
												y === n.id && /* @__PURE__ */ h("span", {
													className: "palm-card-signal",
													children: /* @__PURE__ */ h(l, { size: 14 })
												})
											]
										}, n.id);
									})
								})]
							}),
							/* @__PURE__ */ g("aside", {
								className: "palm-village-panel",
								children: [
									/* @__PURE__ */ h("header", {
										className: "palm-section-head",
										children: /* @__PURE__ */ h("h2", { children: _("games.palmisland.village") })
									}),
									/* @__PURE__ */ h("div", {
										className: "palm-building-grid",
										children: v?.buildings.map((e) => /* @__PURE__ */ h(ot, {
											card: e,
											onClick: () => Re({
												...e,
												stored: !1,
												used: !1
											})
										}, e.id))
									}),
									/* @__PURE__ */ g("div", {
										className: "palm-village-total",
										children: [/* @__PURE__ */ h("span", { children: _("games.palmisland.buildingScore") }), /* @__PURE__ */ h(Q, {
											value: v?.scoreDetails.buildings ?? 0,
											score: !0
										})]
									}),
									e.config.mode === "cooperative" && /* @__PURE__ */ g("div", {
										className: "palm-disaster",
										children: [/* @__PURE__ */ h("strong", { children: _(`games.palmisland.${e.config.disaster}`) }), /* @__PURE__ */ h("span", { children: _("games.palmisland.disasterProgress", { n: e.disasterLevel }) })]
									})
								]
							})
						]
					})
				})
			}),
			/* @__PURE__ */ g(o, {
				open: x !== null && x !== "payment",
				onClose: () => S(x === "preview" ? ge.current : null),
				label: _(x === "payment" ? "games.palmisland.payment" : x === "preview" || x === "next" ? "games.palmisland.preview" : x === "village" ? "games.palmisland.village" : x === "shipping" ? "games.palmisland.shippingOffer" : x === "begin" ? "games.palmisland.start" : "games.palmisland.council"),
				title: _(x === "payment" ? "games.palmisland.payment" : x === "preview" || x === "next" ? "games.palmisland.preview" : x === "village" ? "games.palmisland.village" : x === "shipping" ? "games.palmisland.shippingOffer" : x === "begin" ? "games.palmisland.start" : "games.palmisland.council"),
				tall: !0,
				children: [
					x === "begin" && /* @__PURE__ */ g(m, { children: [
						ke && /* @__PURE__ */ h("p", { children: _("games.palmisland.reorder") }),
						/* @__PURE__ */ h("div", {
							className: "palm-begin-cards",
							children: t?.inspect.map((e) => /* @__PURE__ */ h(ot, {
								card: e,
								selected: ke ? A === e.id : void 0,
								onClick: () => ke && e.id !== 0 ? oe(A === e.id ? null : e.id) : Re(e)
							}, e.id))
						}),
						e.round === 1 && e.config.mode === "solo" && e.config.feats.includes(21) && /* @__PURE__ */ g("label", { children: [
							_("games.palmisland.canoePerk"),
							/* @__PURE__ */ h("select", {
								value: se,
								onChange: (e) => ce(Number(e.target.value)),
								children: [
									1,
									2,
									3
								].map((e) => /* @__PURE__ */ g("option", {
									value: e,
									children: ["#", e]
								}, e))
							}),
							/* @__PURE__ */ g("select", {
								value: le,
								onChange: (e) => ue(Number(e.target.value)),
								children: [/* @__PURE__ */ h("option", {
									value: 1,
									children: _("games.palmisland.rotate")
								}), /* @__PURE__ */ h("option", {
									value: 2,
									children: _("games.palmisland.flip")
								})]
							})
						] }),
						e.round === 1 && e.config.mode === "solo" && e.config.feats.includes(22) && /* @__PURE__ */ g("label", { children: [_("games.palmisland.loggerPerk"), /* @__PURE__ */ h("select", {
							value: de,
							onChange: (e) => pe(Number(e.target.value)),
							children: [
								4,
								5,
								6
							].map((e) => /* @__PURE__ */ g("option", {
								value: e,
								children: ["#", e]
							}, e))
						})] }),
						v?.buildings.filter((e) => e.face === 1 && [
							32,
							33,
							35,
							36
						].includes(e.id)).map((e) => /* @__PURE__ */ g("label", {
							className: "palm-active",
							children: [/* @__PURE__ */ h("input", {
								type: "checkbox",
								checked: k.includes(e.id),
								onChange: () => ae((t) => t.includes(e.id) ? t.filter((t) => t !== e.id) : [...t, e.id])
							}), Z(e.id, _)]
						}, e.id)),
						(t?.stored.length ?? 0) > 0 && /* @__PURE__ */ g("fieldset", { children: [/* @__PURE__ */ h("legend", { children: _("games.palmisland.beginRelease") }), t?.stored.map((e) => /* @__PURE__ */ g("label", {
							className: "palm-active",
							children: [
								/* @__PURE__ */ h("input", {
									type: "checkbox",
									checked: I.includes(e.id),
									onChange: () => he((t) => t.includes(e.id) ? t.filter((t) => t !== e.id) : [...t, e.id])
								}),
								Z(e.id, _),
								" #",
								e.id
							]
						}, e.id))] }),
						/* @__PURE__ */ h("button", {
							className: "btn-base palm-primary",
							disabled: Oe > (k.includes(33) ? 5 : 4),
							onClick: () => {
								d(De()), he([]), S(null);
							},
							children: _("games.palmisland.start")
						})
					] }),
					x === "next" && t?.top[2] && /* @__PURE__ */ h("div", {
						className: "palm-preview palm-preview--single",
						children: /* @__PURE__ */ h("div", {
							className: "palm-card",
							children: /* @__PURE__ */ h(rt, { card: t.top[2] })
						})
					}),
					x === "preview" && (ye ?? V) && /* @__PURE__ */ h("div", {
						className: "palm-preview",
						children: [
							0,
							1,
							2,
							3
						].map((e) => /* @__PURE__ */ h("div", {
							className: "palm-card",
							children: /* @__PURE__ */ h(rt, { card: {
								...ye ?? V,
								face: e
							} })
						}, e))
					}),
					x === "village" && /* @__PURE__ */ h("div", {
						className: "palm-building-grid",
						children: v?.buildings.map((e) => /* @__PURE__ */ h(ot, {
							card: e,
							onClick: () => Re({
								...e,
								stored: !1,
								used: !1
							})
						}, e.id))
					}),
					x === "shipping" && /* @__PURE__ */ g(m, { children: [
						/* @__PURE__ */ h("p", { children: _("games.palmisland.shippingHint") }),
						/* @__PURE__ */ h(mt, {
							cards: t?.stored ?? [],
							value: T,
							onChange: E
						}),
						/* @__PURE__ */ h("button", {
							className: "btn-base palm-primary",
							disabled: !T.cards.length,
							onClick: () => {
								let t = e.players.find((e) => e.rid !== u);
								t && d({
									type: "shipping",
									to: t.rid,
									payment: T
								}), S(null);
							},
							children: _("games.palmisland.shippingOffer")
						}),
						/* @__PURE__ */ h("button", {
							className: "btn-quiet",
							onClick: () => {
								d({
									type: "shipping",
									to: null,
									payment: lt()
								}), S(null);
							},
							children: _("games.palmisland.shippingCancel")
						})
					] }),
					x === "council" && e.config.mode === "cooperative" && /* @__PURE__ */ g(m, { children: [
						/* @__PURE__ */ g("p", { children: [
							_(`games.palmisland.${e.config.disaster}`),
							" · ",
							_("games.palmisland.disasterProgress", { n: e.disasterLevel })
						] }),
						/* @__PURE__ */ h("div", {
							className: "palm-projects",
							children: [
								"disaster",
								"abilityRotate",
								"abilityFlip",
								"finish"
							].map((t) => /* @__PURE__ */ g("button", {
								className: "btn-quiet",
								"aria-pressed": e.project === t,
								onClick: () => d({
									type: "project",
									target: t
								}),
								children: [e.project === t && "✓ ", _(`games.palmisland.${t}`)]
							}, t))
						}),
						/* @__PURE__ */ h($, { value: e.cost }),
						/* @__PURE__ */ h(mt, {
							cards: t?.stored ?? [],
							value: T,
							onChange: E
						}),
						/* @__PURE__ */ h("button", {
							className: "btn-base",
							onClick: () => d({
								type: "pledge",
								payment: T
							}),
							children: v?.pledge ? _("games.palmisland.paid") : _("games.palmisland.pledge")
						}),
						/* @__PURE__ */ h("div", { children: e.players.map((e) => /* @__PURE__ */ g("p", { children: [
							r.find((t) => t.rid === e.rid)?.name,
							" ",
							e.pledge ? /* @__PURE__ */ h($, { value: e.pledge }) : _("games.palmisland.waitingPledge")
						] }, e.rid)) }),
						/* @__PURE__ */ h("button", {
							className: "btn-base palm-primary",
							disabled: !Ae,
							onClick: () => {
								d({ type: "resolve" }), E(lt());
							},
							children: _(e.project === "finish" ? "games.palmisland.finish" : "games.palmisland.resolve")
						})
					] }),
					x === "council" && e.config.mode === "speed" && /* @__PURE__ */ g(m, { children: [
						/* @__PURE__ */ h("p", { children: e.turn === u ? _("games.palmisland.buy") : _("games.palmisland.wait") }),
						/* @__PURE__ */ h("div", {
							className: "palm-market",
							children: e.market.map((e) => {
								let t = j.find((t) => t.id === e);
								return /* @__PURE__ */ g("button", {
									className: "btn-quiet",
									"aria-pressed": N === e,
									onClick: () => P(e),
									children: [
										/* @__PURE__ */ h("span", {
											className: "palm-market-card",
											children: /* @__PURE__ */ h(X, {
												kind: t ? [
													1,
													4,
													7
												][t.type] : e,
												level: +!t
											})
										}),
										/* @__PURE__ */ g("span", { children: [
											N === e && "✓ ",
											Z(e, _),
											t && /* @__PURE__ */ h(Q, {
												value: t.points,
												score: !0
											})
										] }),
										/* @__PURE__ */ g("span", { children: [
											_("games.palmisland.cost"),
											" ",
											/* @__PURE__ */ h($, { value: dt(e) })
										] })
									]
								}, e);
							})
						}),
						N !== null && e.market.includes(N) && /* @__PURE__ */ g("details", {
							className: "palm-market-detail",
							children: [/* @__PURE__ */ g("summary", { children: [
								_("games.palmisland.cardDetails"),
								" · ",
								Z(N, _)
							] }), /* @__PURE__ */ h("div", {
								className: "palm-preview palm-preview--single",
								children: /* @__PURE__ */ h("div", {
									className: "palm-card",
									children: /* @__PURE__ */ h(rt, { card: {
										id: N,
										face: +!Me,
										stored: !1,
										used: !1
									} })
								})
							})]
						}),
						/* @__PURE__ */ h(mt, {
							cards: t?.stored ?? [],
							value: T,
							onChange: E
						}),
						/* @__PURE__ */ h("button", {
							className: "btn-base palm-primary",
							disabled: !Ne,
							onClick: () => d({
								type: "buy",
								card: N,
								payment: T
							}),
							children: _("games.palmisland.buy")
						}),
						/* @__PURE__ */ h("button", {
							className: "btn-quiet",
							disabled: e.turn !== u,
							onClick: () => d({
								type: "buy",
								card: null,
								payment: lt()
							}),
							children: _("games.palmisland.pass")
						})
					] })
				]
			})
		]
	});
}
function mt({ cards: e, value: t, onChange: n }) {
	return /* @__PURE__ */ h("div", {
		className: "palm-payment-cards",
		children: e.map((e) => {
			let r = t.cards.indexOf(e.id);
			return /* @__PURE__ */ h(st, {
				card: e,
				anchor: !1,
				canRelease: !1,
				onRelease: () => {},
				selecting: !0,
				selected: r >= 0,
				candidate: !0,
				choice: t.choices[r] ?? 0,
				onSelect: () => n(ct(t, e.id)),
				onChoice: (e) => n({
					...t,
					choices: t.choices.map((t, n) => n === r ? e : t)
				}),
				onInspect: () => {}
			}, e.id);
		})
	});
}
//#endregion
//#region src/games/palmisland/bot.ts
var ht = () => ({
	cards: [],
	choices: []
}), gt = {
	pointsBase: 1,
	pointsGrowth: .3,
	production: .4,
	store: 2.5,
	spent: .16,
	crowding: .45
};
function _t(e, t, n = !1, r = gt) {
	let i, a = -Infinity;
	for (let o of t.moves) {
		let s = t.top.find((e) => e.id === o.card), c = s && M(s), l = -20;
		if (s && c && (o.operation === "rotate" || o.operation === "flip")) {
			let t = M({
				...s,
				face: s.face ^ (o.operation === "rotate" ? 1 : 2)
			}), i = (e) => Math.max(0, ...e.resources.map((e) => e[0] * 1.1 + e[1] + e[2] * 1.4));
			l = (t.points - c.points) * (n ? 1 : r.pointsBase + e.round * r.pointsGrowth) + (i(t) - i(c)) * (n ? .8 : Math.max(.4, (9 - e.round) * r.production)) + (t.upgrades - c.upgrades) * .4 + .5, s.id >= 30 && s.face === 0 && (l += [30, 31].includes(s.id) ? 3 : s.id === 32 ? (9 - e.round) * .7 : s.id === 33 ? 3 : s.id === 34 ? 4 : -5);
		} else s && c && o.operation === "store" ? (l = Math.max(0, ...c.resources.map(pe)) * (n ? .6 : r.store) - t.stored.length * r.crowding, e.round === 8 && --l) : o.operation === "discard" && (l = -.5);
		o.operation === "release" && (l = -100);
		let u = o.payment.cards.reduce((e, n, r) => e + pe(M(t.stored.find((e) => e.id === n)).resources[o.payment.choices[r]]), 0);
		l -= u * (n ? .1 : r.spent), o.release !== null && (l -= 2), l > a && (a = l, i = o);
	}
	return i;
}
function vt(e = gt) {
	return (t, n) => {
		let r = t.public, i = t.private, a = r.players.find((e) => e.rid === n.rid);
		if (!i || !a) return null;
		if (r.phase === "begin") return a.ready ? null : { action: {
			type: "begin",
			active: a.buildings.filter((e) => e.face === 1 && [32, 33].includes(e.id)).map((e) => e.id),
			release: i.stored.slice(4).map((e) => e.id),
			reorder: null,
			canoe: 1,
			canoeFace: 1,
			logger: 4
		} };
		if (r.phase === "play") {
			let t = _t(r, i, n.difficulty === "weak", e);
			return t ? { action: t } : null;
		}
		if (r.phase !== "council") return null;
		let o = (e) => e.cards.reduce((t, n, r) => {
			let a = M(i.stored.find((e) => e.id === n)).resources[e.choices[r]];
			return [
				t[0] + a[0],
				t[1] + a[1],
				t[2] + a[2]
			];
		}, [
			0,
			0,
			0
		]);
		if (r.config.mode === "speed") {
			if (r.turn !== n.rid) return null;
			for (let e of r.market) {
				let t = j.find((t) => t.id === e), n = t ? [
					1,
					1,
					1
				] : M({
					id: e,
					face: 0
				}).actions.rotate[0];
				if (t && r.market.some((e) => (j.find((t) => t.id === e)?.points ?? 0) > t.points)) continue;
				let a = i.payments.find((e) => n.every((t, n) => o(e)[n] >= t));
				if (a) return { action: {
					type: "buy",
					card: e,
					payment: a
				} };
			}
			return { action: {
				type: "buy",
				card: null,
				payment: ht()
			} };
		}
		if (r.config.mode === "cooperative") {
			if (r.project === "finish") return { action: { type: "resolve" } };
			let e = r.players.find((e) => e.rid !== n.rid), t = r.cost.map((t, n) => Math.max(0, t - (e?.pledge?.[n] ?? 0)));
			if (a.pledge === null) {
				let e = [...i.payments].sort((e, t) => e.cards.length - t.cards.length);
				return { action: {
					type: "pledge",
					payment: e.find((e) => t.every((t, n) => o(e)[n] >= t)) ?? e.at(-1) ?? ht()
				} };
			}
			if (r.players.every((e) => e.pledge !== null)) return r.projectAvailable && r.cost.every((e, t) => r.players.reduce((e, n) => e + (n.pledge?.[t] ?? 0), 0) >= e) ? { action: { type: "resolve" } } : { action: {
				type: "project",
				target: "finish"
			} };
		}
		return null;
	};
}
var yt = vt(), bt = { palmCard(e, t) {
	let n = e.secret;
	if (!n || n.source < 0 || n.operation === "release") return null;
	let r = t.anchor(`palm-top:${n.source}`), i = n.operation === "store" ? t.anchor(`palm-stored:${n.card.id}`) : null, a = t.anchor("palm-bottom");
	if (!r || !a) return null;
	let o = i ?? {
		x: a.x + a.w / 2 - r.w * .1,
		y: a.y,
		w: r.w * .2,
		h: r.h * .2
	};
	return {
		ms: 300,
		hide: i ? [`palm-stored:${n.card.id}`] : [],
		node: /* @__PURE__ */ h(_, {
			from: r,
			to: o,
			ms: 280,
			children: /* @__PURE__ */ h("div", {
				className: `palm-card palm-flying palm-flying--${n.operation}`,
				style: {
					width: r.w,
					height: r.h
				},
				children: /* @__PURE__ */ h(rt, { card: n.card })
			})
		})
	};
} }, xt = t.object({
	version: t.literal(1),
	unlocked: t.array(t.int().min(17).max(25)),
	matches: t.array(t.string())
});
function St(e) {
	try {
		let t = xt.safeParse(JSON.parse(e ?? "{}"));
		if (t.success) return t.data;
	} catch {}
	return {
		version: 1,
		unlocked: [],
		matches: []
	};
}
async function Ct() {
	return St((await ne()).values.progress);
}
async function wt(e, t) {
	for (let n = 0; n < 5; n++) {
		let n = await ne(), r = St(n.values.progress);
		if (r.matches.includes(e)) return r;
		let i = {
			version: 1,
			unlocked: [.../* @__PURE__ */ new Set([...r.unlocked, ...t])].sort((e, t) => e - t),
			matches: [...r.matches, e]
		};
		if ((await re({
			revision: n.revision,
			values: {
				...n.values,
				progress: JSON.stringify(i)
			}
		})).status === "saved") return i;
	}
	throw Error("progress-conflict");
}
//#endregion
//#region src/games/palmisland/result.tsx
function Tt(e, t) {
	if (e.key === "Escape" && (e.stopPropagation(), t()), e.key !== "Tab") return;
	let n = [...e.currentTarget.querySelectorAll("button:not(:disabled),[tabindex=\"0\"]")].filter((e) => e.getClientRects().length), r = n[0], i = n.at(-1);
	e.shiftKey && document.activeElement === r ? (e.preventDefault(), i?.focus()) : !e.shiftKey && document.activeElement === i && (e.preventDefault(), r?.focus());
}
function Et({ public: e, result: t, myRid: r, members: o, onPlayAgain: s, onBackToLobby: l, hintCount: te }) {
	let f = e, p = c(), [_, ne] = a("saving"), [re, ie] = a(0), [y, b] = a(r), [x, S] = a(!0), [C, w] = a(null), T = i(null), E = i(null), D = i(null), O = i(null), k = f.config.mode === "solo", ae = f.config.mode === "cooperative", A = f.unlocked[r] ?? [], oe = A.join(",");
	n(() => {
		(x ? T : E).current?.focus({ preventScroll: !0 });
	}, [x]), n(() => {
		C ? D.current?.focus({ preventScroll: !0 }) : O.current?.focus({ preventScroll: !0 });
	}, [C]), n(() => {
		if (!k) return;
		let e = !0;
		return wt(`${f.match}:${r}`, oe ? oe.split(",").map(Number) : []).then(() => {
			e && ne("saved");
		}).catch(() => {
			e && ne("failed");
		}), () => {
			e = !1;
		};
	}, [
		f.match,
		r,
		oe,
		k,
		re
	]);
	let se = (e) => {
		O.current = document.activeElement, w(e);
	}, ce = t.scores?.[r] ?? 0, le = ce >= 40 ? "amazing" : ce >= 30 ? "great" : ce >= 20 ? "good" : ce >= 10 ? "work" : "low", ue = [
		["buildings", "games.palmisland.buildingScore"],
		["feats", "games.palmisland.featScore"],
		["villagers", "games.palmisland.villagerScore"],
		["outposts", "games.palmisland.outpostScore"]
	], de = (e) => o.find((t) => t.rid === e)?.name ?? e, j = [...(f.finalDecks[y] ?? []).filter((e) => e.id !== 0), ...(f.players.find((e) => e.rid === y)?.outposts ?? []).map((e) => ({
		id: e,
		face: 1,
		stored: !1,
		used: !1
	}))], M = ae ? p(f.disasterLevel === 3 ? "games.palmisland.won" : "games.palmisland.lost") : k ? p(`games.palmisland.rating.${le}`) : `${p(t.winner.length > 1 ? "games.palmisland.jointWinners" : "games.palmisland.winner")} · ${t.winner.map(de).join(" / ")}`;
	return /* @__PURE__ */ g("div", {
		className: "palm-root palm-final",
		children: [/* @__PURE__ */ g("main", {
			className: "palm-end",
			children: [
				/* @__PURE__ */ h("img", {
					className: "palm-final-backdrop",
					src: Ke,
					alt: ""
				}),
				/* @__PURE__ */ g("header", {
					className: "palm-review-header",
					inert: x || !!C,
					children: [/* @__PURE__ */ h("h1", { children: p("games.palmisland.finalCards") }), /* @__PURE__ */ h("div", { children: f.players.map((e) => /* @__PURE__ */ g("button", {
						onClick: () => b(e.rid),
						"aria-pressed": y === e.rid,
						children: [
							de(e.rid),
							" · ",
							p("games.palmisland.score", { n: e.points })
						]
					}, e.rid)) })]
				}),
				/* @__PURE__ */ h("div", {
					className: "palm-final-grid",
					tabIndex: 0,
					"aria-label": p("games.palmisland.finalCards"),
					inert: x || !!C,
					children: j.map((e) => /* @__PURE__ */ h(ot, {
						card: e,
						onClick: () => se(e)
					}, e.id))
				}),
				/* @__PURE__ */ h("div", {
					className: "palm-ending-shade",
					hidden: !x,
					children: /* @__PURE__ */ g("section", {
						className: "palm-result",
						role: "dialog",
						"aria-modal": "true",
						"aria-label": p("games.palmisland.result"),
						onKeyDown: (e) => Tt(e, () => S(!1)),
						inert: !!C,
						children: [
							/* @__PURE__ */ g("header", {
								className: "palm-result-head",
								children: [
									/* @__PURE__ */ h("small", { children: "PALM ISLAND" }),
									/* @__PURE__ */ h("h2", { children: p(ae ? f.disasterLevel === 3 ? "games.palmisland.won" : "games.palmisland.lost" : "games.palmisland.result") }),
									/* @__PURE__ */ h("button", {
										className: "palm-result-close",
										ref: T,
										onClick: () => S(!1),
										"aria-label": p("games.palmisland.reviewCards"),
										children: /* @__PURE__ */ h(u, { size: 22 })
									})
								]
							}),
							/* @__PURE__ */ g("div", {
								className: "palm-result-body",
								children: [/* @__PURE__ */ g("div", {
									className: "palm-result-island",
									children: [/* @__PURE__ */ h("img", {
										src: Ke,
										alt: ""
									}), /* @__PURE__ */ g("div", {
										className: "palm-result-score",
										children: [/* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("b", { children: ae ? Math.min(...f.players.map((e) => e.points)) : ce }), /* @__PURE__ */ h(tt, {})] }), /* @__PURE__ */ h("p", { children: M })]
									})]
								}), /* @__PURE__ */ g("div", {
									className: "palm-result-details",
									children: [
										/* @__PURE__ */ g("table", {
											className: "palm-score-table",
											children: [
												/* @__PURE__ */ h("thead", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", { children: p("games.palmisland.scoreItem") }), t.ranking.map((e) => /* @__PURE__ */ g("th", { children: [
													de(e),
													t.winner.includes(e) && /* @__PURE__ */ h(tt, {}),
													t.autopilot?.[e] ? /* @__PURE__ */ h("small", { children: p("session.autopilot.share", { n: Math.round(t.autopilot[e] * 100) }) }) : null
												] }, e))] }) }),
												/* @__PURE__ */ h("tbody", { children: ue.filter(([e]) => e === "buildings" || f.players.some((t) => t.scoreDetails[e] !== 0)).map(([e, n]) => /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", { children: p(n) }), t.ranking.map((t) => /* @__PURE__ */ h("td", { children: f.players.find((e) => e.rid === t)?.scoreDetails[e] }, t))] }, e)) }),
												/* @__PURE__ */ h("tfoot", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", { children: p("games.palmisland.total") }), t.ranking.map((e) => /* @__PURE__ */ h("td", { children: t.scores?.[e] }, e))] }) })
											]
										}),
										te !== void 0 && /* @__PURE__ */ h("p", {
											className: "palm-save-state",
											children: p("session.hint.usedCount", { n: te })
										}),
										k && /* @__PURE__ */ g(m, { children: [
											A.length ? A.map((e) => /* @__PURE__ */ g("button", {
												className: "palm-earned",
												onClick: () => se({
													id: e,
													face: 0,
													stored: !1,
													used: !1
												}),
												children: [
													/* @__PURE__ */ h(X, { kind: e }),
													/* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h("small", { children: p("games.palmisland.earned") }), /* @__PURE__ */ h("h3", { children: Z(e, p) })] }),
													/* @__PURE__ */ h(d, { size: 17 })
												]
											}, e)) : /* @__PURE__ */ h("p", {
												className: "palm-save-state",
												children: p("games.palmisland.noFeats")
											}),
											/* @__PURE__ */ h("p", {
												className: "palm-save-state",
												role: "status",
												children: p(_ === "saved" ? "games.palmisland.saved" : _ === "failed" ? "games.palmisland.saveFailed" : "games.palmisland.saving")
											}),
											_ === "failed" && /* @__PURE__ */ h("button", {
												className: "palm-button",
												onClick: () => {
													ne("saving"), ie((e) => e + 1);
												},
												children: p("games.palmisland.retry")
											})
										] })
									]
								})]
							}),
							/* @__PURE__ */ g("footer", {
								className: "palm-result-actions",
								children: [
									/* @__PURE__ */ g("button", {
										className: "palm-button palm-review-button",
										onClick: () => S(!1),
										children: [/* @__PURE__ */ h(d, { size: 18 }), p("games.palmisland.reviewCards")]
									}),
									l && /* @__PURE__ */ h(v, {
										className: "palm-button",
										label: p("session.result.backToLobby"),
										confirmLabel: p("games.palmisland.confirmLobby"),
										onConfirm: l
									}),
									" ",
									s && /* @__PURE__ */ h(v, {
										className: "palm-button palm-button-primary",
										label: p("session.result.playAgain"),
										confirmLabel: p("games.palmisland.confirmAgain"),
										onConfirm: s
									}),
									" ",
									!s && !l && /* @__PURE__ */ h("p", { children: p("session.result.waitHost") })
								]
							})
						]
					})
				}),
				/* @__PURE__ */ h("div", {
					className: "palm-end-restore",
					hidden: x,
					inert: !!C,
					children: /* @__PURE__ */ g("button", {
						className: "palm-button palm-button-primary",
						ref: E,
						onClick: () => S(!0),
						children: [/* @__PURE__ */ h(ee, { size: 18 }), p("games.palmisland.showResult")]
					})
				})
			]
		}), /* @__PURE__ */ h("div", {
			className: "palm-modal-shade palm-review-details",
			hidden: !C,
			onClick: (e) => {
				e.target === e.currentTarget && w(null);
			},
			children: C && /* @__PURE__ */ g("section", {
				className: "palm-detail-panel",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": `${p("games.palmisland.cardDetails")} · ${Z(C.id, p)}`,
				onKeyDown: (e) => Tt(e, () => w(null)),
				children: [/* @__PURE__ */ g("header", {
					className: "palm-detail-head",
					children: [/* @__PURE__ */ g("h2", { children: [
						Z(C.id, p),
						" #",
						C.id
					] }), /* @__PURE__ */ h("button", {
						className: "palm-detail-close",
						ref: D,
						onClick: () => w(null),
						"aria-label": p("common.close"),
						children: /* @__PURE__ */ h(u, { size: 22 })
					})]
				}), /* @__PURE__ */ h("div", {
					className: "palm-preview",
					children: [
						0,
						1,
						2,
						3
					].map((e) => /* @__PURE__ */ h("div", {
						className: "palm-card",
						children: /* @__PURE__ */ h(rt, { card: {
							...C,
							face: e
						} })
					}, e))
				})]
			})
		})]
	});
}
//#endregion
//#region src/games/palmisland/game-over.tsx
function Dt(e) {
	return /* @__PURE__ */ h(Et, { ...e });
}
//#endregion
//#region src/games/palmisland/options.tsx
function Ot({ value: e, onChange: t }) {
	let r = c(), i = ve.safeParse(e), o = i.success ? i.data : ve.parse(void 0), [s, l] = a([]), [u, d] = a(!1), [ee, te] = a(0);
	return n(() => {
		let e = !0;
		return Ct().then((t) => {
			e && (l(t.unlocked), d(!1));
		}).catch(() => {
			e && d(!0);
		}), () => {
			e = !1;
		};
	}, [ee]), /* @__PURE__ */ g("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ h(b, {
				title: r("games.palmisland.mode"),
				children: [
					"solo",
					"cooperative",
					"casual",
					"speed"
				].map((e) => /* @__PURE__ */ h(y, {
					name: "palm-mode",
					value: e,
					checked: e === o.mode,
					label: r(`games.palmisland.${e}`),
					accent: N.accent,
					onChange: () => t({
						...o,
						mode: e
					})
				}, e))
			}),
			o.mode !== "cooperative" && /* @__PURE__ */ h(x, {
				checked: o.villagers,
				label: r("games.palmisland.villagers"),
				accent: N.accent,
				onChange: () => t({
					...o,
					villagers: !o.villagers
				})
			}),
			o.mode === "cooperative" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(b, {
				title: r("games.palmisland.disaster"),
				columns: 3,
				children: [
					"famine",
					"eruption",
					"hurricane"
				].map((e) => /* @__PURE__ */ h(y, {
					name: "palm-disaster",
					value: e,
					checked: e === o.disaster,
					label: r(`games.palmisland.${e}`),
					onChange: () => t({
						...o,
						disaster: e
					})
				}, e))
			}), /* @__PURE__ */ h(b, {
				title: r("games.palmisland.ability"),
				children: [
					"none",
					"storage",
					"rebuild",
					"shipping"
				].map((e) => /* @__PURE__ */ h(y, {
					name: "palm-ability",
					value: e,
					checked: e === o.ability,
					label: r(`games.palmisland.${e}`),
					onChange: () => t({
						...o,
						ability: e
					})
				}, e))
			})] }),
			o.mode === "solo" && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("p", {
					className: "text-sm",
					children: r("games.palmisland.featsHint")
				}),
				/* @__PURE__ */ h(b, {
					title: r("games.palmisland.feats"),
					children: s.map((e) => /* @__PURE__ */ h(ie, {
						name: "palm-feats",
						value: String(e),
						checked: o.feats.includes(e),
						label: Z(e, r),
						onChange: () => t({
							...o,
							feats: o.feats.includes(e) ? o.feats.filter((t) => t !== e) : [...o.feats, e]
						})
					}, e))
				}),
				u && /* @__PURE__ */ h("button", {
					className: "btn-quiet",
					onClick: () => te((e) => e + 1),
					children: r("games.palmisland.retry")
				})
			] })
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/palmisland/entry.tsx
var kt = {
	definition: Be,
	View: ft,
	bot: yt,
	fx: bt,
	OverView: Dt,
	Options: Ot,
	locales: {
		zh: {
			name: "棕榈岛",
			desc: "将十七张牌握在掌中，储存资源，建设你的海岛村落。",
			rules: "目标:\n用16张建设牌和1张轮次牌发展海岛。第8轮结束时，按每张牌当前朝向的星星计分。单人挑战高分并解锁成就；竞赛由分数最高者获胜，平分依次比较升级箭头总数和储存资源数量，仍相同则共同获胜。\n准备:\n所有建设牌从太阳标记朝向开始，洗牌后将轮次牌置于牌堆底部。开局可以查看并记忆牌序，确认开始后只可查看最上方3张牌。双方竞赛使用相同的初始牌序，合作各自洗牌。可选村民和成就默认关闭。\n行动:\n· 每次选择最上方两张牌之一，执行其当前朝向列出的储存、旋转或翻面操作，随后将该牌移至牌堆底部。第二张不能直接弃置；可以不付费用，将最上方一张移至牌堆底部。顶牌为储存牌时，必须先复位并移至牌堆底部。\n· 储存将牌横置，提供当前朝向的资源。通常最多同时储存4张牌，每张可以提供多个资源；满额时先复位一张已储存牌。旋转将牌转动180度，翻面仅切换正反面，不同时旋转。可查看最上方两张牌的其他朝向。\n· 费用只能用已储存的整张牌支付。支付后将资源牌复位，原牌序不变，多余资源丢弃。斜杠表示任选一种资源或费用，不能同时获得所有种类。可随时复位已储存牌。\n· 在本界面右划储存、上划旋转、左划翻面、向下滑动以弃置牌堆顶的牌。也可选择牌后点按按钮。付费操作须选择资源牌并确认。\n轮次与结束:\n轮次牌到达最上方才结束本轮；它在第二张时不能操作。资源跨轮保留。双方均到轮末后处理合作或竞赛，再开始下一轮。单人10–19分为尚需努力，20–29分为表现不错，30–39分为出类拔萃，40分以上为令人惊叹。\n合作:\n开局选择饥荒、火山喷发或飓风。每轮末可以共同支付当前灾难等级的全部费用，推进1个等级；所列费用乘以人数，可以任意分摊。最迟第8轮末完成3个等级则全员获胜，否则全员失败。团队得分取所有人中的最低分。\n可选择一张合作能力：\n· 仓储可存入资源抵扣下一次灾难费用；\n· 重建启用后每轮开始可将任意一张牌移至牌堆顶；\n· 航运启用后每人每轮可为另一名玩家支付一次全部或部分费用。\n竞赛:\n· 休闲竞赛随机选择森林、海洋、山地哨站各1张。轮末3张相应的伐木场、独木舟屋或采石场均达到至少1级，即获得对应哨站；同一轮双方均达标则该哨站移出游戏，无人获得。\n· 速度竞赛按到达轮次牌的先后顺序轮流购买哨站，费用为 1 份木材、1 份鱼和 1 份石料，从4分向2分牌依次购买；每次购买1张，双方继续轮流，放弃后不再参与本轮购买。启用村民时以随机3种村民替代哨站。\n村民:\n单人或休闲竞赛随机将3种村民加入建设牌与轮次牌之间；休闲竞赛排除所选哨站背面的同名村民。支付费用招募后放到轮次牌之后，永久保留。酋长按住房的升级总数得分，商人按市场与贸易所的升级总数得分，祭司获得5分。\n每轮开始时，选择启用的主动能力：\n· 建造师使本轮每项费用减少1个资源，\n· 长老将本轮储存上限提高至5张，\n· 领航员和劫掠者可储存所示资源；它们分别扣4分与6分。\n成就:\n单人终局自动核对9项条件并保存解锁。未来开局可选择已解锁成就，放在轮次牌之后；使用任意数量为简单难度，1张为中等，不使用为困难。信任雕像、精神力量与荣誉号角仍须按牌面付费升级后获得能力。精神力量要求两张住房均升到3级后才能翻面。\n· 伟兽之牙和伟大之斧开局各升级1张对应建设牌；\n· 预见之石开局可将任意1张牌移到顶；\n· 荣誉纪念碑每局只能储存一次。",
			round: "第 {{n}} / 8 轮",
			score: "{{n}} 分",
			upgrades: "升级 {{n}}",
			stored: "储存 {{n}} / {{max}}",
			begin: "查看牌序，然后启程",
			play: "选择顶端两张牌之一",
			wait: "等待另一座岛屿",
			council: "轮末决策",
			resolving: "正在结束本轮",
			store: "储存",
			rotate: "旋转",
			flip: "翻面",
			discard: "弃顶牌",
			release: "复位",
			free: "免费",
			wood: "木材",
			fish: "鱼",
			stone: "石料",
			cards: {
				canoe: "独木舟屋",
				logger: "伐木场",
				quarry: "采石场",
				market: "市场",
				trade: "贸易所",
				tool: "工具坊",
				housing: "住房",
				temple: "神庙",
				tracker: "轮次牌",
				statue: "信任雕像",
				heart: "山之心",
				spirit: "精神力量",
				horn: "荣誉号角",
				tooth: "伟兽之牙",
				axe: "伟大之斧",
				vision: "预见之石",
				monument: "荣誉纪念碑",
				balance: "平衡印记",
				chief: "酋长",
				merchant: "商人",
				builder: "建造师",
				elder: "长老",
				priest: "祭司",
				wayfinder: "领航员",
				raider: "劫掠者",
				sea: "海洋哨站",
				forest: "森林哨站",
				mountain: "山地哨站"
			},
			mode: "玩法",
			solo: "单人挑战",
			cooperative: "合作",
			casual: "休闲竞赛",
			speed: "速度竞赛",
			villagers: "加入村民",
			feats: "已解锁成就",
			featsHint: "单人终局解锁的成就可用于未来对局。",
			disaster: "灾难",
			famine: "饥荒",
			eruption: "火山喷发",
			hurricane: "飓风",
			ability: "合作能力",
			none: "不使用",
			storage: "仓储",
			rebuild: "重建",
			shipping: "航运",
			start: "开始本轮",
			inspect: "查看牌序",
			preview: "查看其他朝向",
			top: "顶牌",
			second: "第二张",
			next: "下一张",
			supply: "已储存资源",
			noSupply: "尚未储存资源",
			swipe: "右划储存 · 上划旋转 · 左划翻面",
			payment: "选择支付的资源牌",
			confirm: "确认",
			cancel: "取消",
			replacement: "选择一张储存牌复位",
			cost: "费用",
			back: "返回",
			active: "本轮主动能力",
			reorder: "将一张牌移至顶端",
			noReorder: "保持牌序",
			canoePerk: "伟兽之牙：选择升级的独木舟屋",
			loggerPerk: "伟大之斧：选择升级的伐木场",
			project: "共同支付",
			disasterProgress: "灾难 {{n}} / 3",
			abilityRotate: "旋转合作能力",
			abilityFlip: "翻转合作能力",
			finish: "结束本轮",
			pledge: "确认分摊",
			resolve: "支付并推进",
			waitingPledge: "等待双方确认资源",
			buy: "购买",
			pass: "放弃购买",
			requirement: "三张对应建设牌均达到1级",
			effect: {
				chief: "每个住房升级箭头获得1分",
				merchant: "市场和贸易所每个升级箭头获得1分",
				builder: "本轮每项费用减少1个资源",
				elder: "本轮储存上限提高至5张",
				priest: "获得5分",
				wayfinder: "储存2个同类资源，扣4分",
				raider: "储存木材、鱼、石料各1个，扣6分",
				tooth: "开局升级一张独木舟屋",
				axe: "开局升级一张伐木场",
				vision: "开局将任意一张牌移至顶端",
				spirit: "两张住房均达到3级后可翻面",
				monument: "每局仅能储存一次",
				shipping: "每人每轮可替另一人支付一次费用"
			},
			result: "你的海岛",
			won: "成功抵御灾难",
			lost: "未能抵御灾难",
			teamScore: "团队得分 {{n}}",
			finalCards: "最终建设",
			earned: "本局达成成就",
			saved: "成就已保存",
			saving: "正在保存成就",
			saveFailed: "成就保存失败，请重试",
			retry: "重试保存",
			noFeats: "本局未达成新的成就条件",
			rating: {
				low: "继续探索",
				work: "尚需努力",
				good: "表现不错",
				great: "出类拔萃",
				amazing: "令人惊叹"
			},
			error: "当前无法执行这个操作，请重新选择。",
			selected: "已选",
			locked: "未解锁",
			recruit: "招募",
			paid: "已确认分摊",
			choose: "选择",
			shippingOffer: "提供航运援助",
			shippingCancel: "撤回援助",
			useShipping: "使用航运援助",
			shippingHint: "选择愿意支付的资源牌。对方确认使用后才会消费；本轮最多援助一次。",
			beginRelease: "复位资源牌以腾出储存位置",
			hintPlay: "{{action}} #{{id}}",
			cardDetails: "卡牌详情",
			afterRotate: "旋转后",
			afterFlip: "翻面后",
			noYield: "无资源产出",
			chooseYield: "选择本牌支付的资源",
			featScore: "成就",
			faceFront: "正面 · 正向",
			faceFrontTurned: "正面 · 旋转",
			faceBack: "背面 · 正向",
			faceBackTurned: "背面 · 旋转",
			village: "岛屿建设",
			viewVillage: "查看建设",
			emptySlot: "空位",
			payConfirm: "确认支付",
			resetStore: "复位并储存",
			paymentBalance: "{{resource}}，已选 {{n}}，需要 {{cost}}",
			builderDiscount: "建造师减免 1 个资源",
			unavailable: "当前不可执行",
			reviewCards: "回看最终卡牌",
			showResult: "查看结算",
			confirmLobby: "确认返回大厅",
			confirmAgain: "确认再来一局",
			buildingScore: "建设牌",
			villagerScore: "村民",
			outpostScore: "哨站",
			scoreItem: "计分项目",
			total: "总分",
			winner: "获胜者",
			jointWinners: "共同获胜"
		},
		en: {
			name: "Palm Island",
			desc: "Hold seventeen cards in your palm. Store resources and grow your island village.",
			rules: "Goal:\nDevelop your island using 16 building cards and 1 round tracker. After round 8, score stars on each card’s active area. In competitive play, the highest score wins; ties are broken by total upgrade arrows, then stored resource units. Remaining ties are shared.\nSetup:\nStart all buildings with the sun marker upright. Shuffle and place the tracker at the back. You may inspect and memorize the order before starting; during play, inspect only the top 3 cards. Competitive players use identical starting orders; cooperative players shuffle separately. Villagers and earned Feats are optional and off by default.\nActions:\n· Choose either of the top 2 cards and take an available Store, Rotate, or Flip action, then move that card to the back. Only the top card may be discarded without payment. A stored card at the top must immediately be reset and discarded.\n· Store turns a card sideways to provide its active resources. Normally at most 4 cards may be stored; reset a stored card first if full. Rotate turns a card 180 degrees. Flip changes its side without rotating. You may inspect the other states of the top 2 cards.\n· Pay with whole stored cards. Reset paid cards without changing their order; excess resources are lost. A slash means choose one resource type or cost, never all alternatives. You may reset stored cards at any time.\n· Swipe right to Store, up to Rotate, left to Flip, and down to discard the top card. Buttons provide the same actions. Paid actions require selecting resource cards and confirming.\nRounds and scoring:\nThe round ends only when the tracker reaches the top; it cannot be used in second position. Stored resources carry over. Both players finish before cooperative or competitive decisions and the next round. Solo ratings: 10–19 Needs work, 20–29 Respectable, 30–39 Exceptional, 40+ Astounding.\nCooperative:\nChoose Famine, Eruption, or Hurricane. At a round end, jointly pay the full current disaster cost, multiplied by the player count, to advance one level. Contributions can be split freely. Complete all 3 levels by the end of round 8 to win together; otherwise everyone loses. The group score is the lowest individual score.\nChoose one optional ability:\n· Storage banks resources for the next disaster payment;\n· Rebuild lets each player move any one card to the top at each round start after activation;\n· Shipping lets each player pay all or part of another player’s cost once per round after activation.\nCompetitive:\n· Casual: randomly choose one Forest, Sea, and Mountain Outpost. At a round end, upgrade all 3 corresponding Loggers, Canoe Houses, or Quarries to at least level 1 to claim it. If both qualify in the same round, remove it without an award.\n· Speed: purchase in the order players reached their trackers, one Outpost at a time for 1 wood, 1 fish, and 1 stone. Purchase from 4 points down to 2 points. Continue alternating until both pass; passing ends that player’s purchases for this round. With Villagers enabled, 3 random Villagers replace Outposts.\nVillagers:\nSolo and Casual add 3 random unique Villagers between the buildings and tracker; Casual excludes Villagers printed on the chosen Outpost backs. Recruit by paying their cost, then place them after the tracker permanently. Chief scores Housing upgrade arrows, Merchant scores Market and Trade House arrows, and Priest scores 5.\nAt each round start, choose Active abilities:\n· Builder reduces each cost by 1 resource for the round;\n· Elder raises storage capacity to 5;\n· Wayfinder and Raider can store their resources but score −4 and −6 respectively.\nFeats:\nSolo endings check 9 achievements and save unlocks for future games. Selected earned Feats begin after the tracker. Any number is Easy, one is Medium, none is Hard. Statue of Trust, Strength of Spirit, and Horn of Honor still require the printed upgrades. Strength of Spirit requires both Housing cards at level 3 before flipping.\n· Tooth of the Beast and Axe of Greatness each upgrade one matching building at setup;\n· Vision Stone moves any one card to the top at setup;\n· Monument of Glory may be stored only once per game.",
			round: "Round {{n}} / 8",
			score: "{{n}} points",
			upgrades: "{{n}} upgrades",
			stored: "Stored {{n}} / {{max}}",
			begin: "Inspect your deck",
			play: "Choose a top card",
			wait: "Waiting for partner",
			council: "End of round",
			resolving: "Finishing round",
			store: "Store",
			rotate: "Rotate",
			flip: "Flip",
			discard: "Discard top",
			release: "Reset",
			free: "Free",
			wood: "Wood",
			fish: "Fish",
			stone: "Stone",
			cards: {
				canoe: "Canoe House",
				logger: "Logger",
				quarry: "Quarry",
				market: "Market",
				trade: "Trade House",
				tool: "Tool Maker",
				housing: "Housing",
				temple: "Temple",
				tracker: "Round Tracker",
				statue: "Statue of Trust",
				heart: "Heart of the Mountain",
				spirit: "Strength of Spirit",
				horn: "Horn of Honor",
				tooth: "Tooth of the Beast",
				axe: "Axe of Greatness",
				vision: "Vision Stone",
				monument: "Monument of Glory",
				balance: "Mark of Balance",
				chief: "Chief",
				merchant: "Merchant",
				builder: "Builder",
				elder: "Elder",
				priest: "Priest",
				wayfinder: "Wayfinder",
				raider: "Raider",
				sea: "Sea Outpost",
				forest: "Forest Outpost",
				mountain: "Mountain Outpost"
			},
			mode: "Mode",
			solo: "Solo",
			cooperative: "Cooperative",
			casual: "Casual competitive",
			speed: "Competitive speed",
			villagers: "Add Villagers",
			feats: "Earned Feats",
			featsHint: "Feats unlocked in solo endings are available in future games.",
			disaster: "Disaster",
			famine: "Famine",
			eruption: "Eruption",
			hurricane: "Hurricane",
			ability: "Cooperative ability",
			none: "None",
			storage: "Storage",
			rebuild: "Rebuild",
			shipping: "Shipping",
			start: "Start round",
			inspect: "Inspect deck order",
			preview: "Inspect other states",
			top: "Top card",
			second: "Second card",
			next: "Next card",
			supply: "Stored resources",
			noSupply: "No resources stored yet",
			swipe: "Right: Store · Up: Rotate · Left: Flip",
			payment: "Choose resource cards to pay",
			confirm: "Confirm",
			cancel: "Cancel",
			replacement: "Choose a stored card to reset",
			cost: "Cost",
			back: "Back",
			active: "Active abilities this round",
			reorder: "Move one card to the top",
			noReorder: "Keep current order",
			canoePerk: "Tooth of the Beast: choose a Canoe House",
			loggerPerk: "Axe of Greatness: choose a Logger",
			project: "Joint payment",
			disasterProgress: "Disaster {{n}} / 3",
			abilityRotate: "Rotate ability",
			abilityFlip: "Flip ability",
			finish: "End round",
			pledge: "Confirm contribution",
			resolve: "Pay and advance",
			waitingPledge: "Waiting for both contributions",
			buy: "Purchase",
			pass: "Pass purchases",
			requirement: "All 3 matching buildings at level 1+",
			effect: {
				chief: "1 point for each Housing upgrade arrow",
				merchant: "1 point per Market and Trade House upgrade arrow",
				builder: "Reduce each cost by 1 resource this round",
				elder: "Raise storage capacity to 5 this round",
				priest: "Score 5 points",
				wayfinder: "Store 2 of one resource type; −4 points",
				raider: "Store 1 wood, 1 fish, 1 stone; −6 points",
				tooth: "Upgrade one Canoe House at setup",
				axe: "Upgrade one Logger at setup",
				vision: "Move any one card to the top at setup",
				spirit: "Flip only after both Housing cards reach level 3",
				monument: "Store only once per game",
				shipping: "Each player may pay another’s cost once per round"
			},
			result: "Your island",
			won: "Disaster averted",
			lost: "The disaster prevailed",
			teamScore: "Group score {{n}}",
			finalCards: "Final buildings",
			earned: "Achievements met",
			saved: "Feats saved",
			saving: "Saving Feats",
			saveFailed: "Could not save Feats. Please retry.",
			retry: "Retry saving",
			noFeats: "No achievement conditions met this game",
			rating: {
				low: "Keep exploring",
				work: "Needs work",
				good: "Respectable",
				great: "Exceptional",
				amazing: "Astounding"
			},
			error: "That action is unavailable. Please choose again.",
			selected: "Selected",
			locked: "Locked",
			recruit: "Recruit",
			paid: "Contribution confirmed",
			choose: "Choose",
			shippingOffer: "Offer shipping aid",
			shippingCancel: "Withdraw aid",
			useShipping: "Use shipping aid",
			shippingHint: "Choose whole resource cards to offer. They are spent when your partner confirms an action. You may help once per round.",
			beginRelease: "Reset resources to make room",
			hintPlay: "{{action}} #{{id}}",
			cardDetails: "Card details",
			afterRotate: "After rotating",
			afterFlip: "After flipping",
			noYield: "No resource yield",
			chooseYield: "Choose this card’s resource",
			featScore: "Feats",
			faceFront: "Front · Upright",
			faceFrontTurned: "Front · Rotated",
			faceBack: "Back · Upright",
			faceBackTurned: "Back · Rotated",
			village: "Island buildings",
			viewVillage: "Buildings",
			emptySlot: "Empty",
			payConfirm: "Pay",
			resetStore: "Reset and store",
			paymentBalance: "{{resource}}: selected {{n}}, need {{cost}}",
			builderDiscount: "Builder: 1 resource discount",
			unavailable: "Unavailable",
			reviewCards: "Review final cards",
			showResult: "Show results",
			confirmLobby: "Confirm return to lobby",
			confirmAgain: "Confirm new game",
			buildingScore: "Buildings",
			villagerScore: "Villagers",
			outpostScore: "Outposts",
			scoreItem: "Scoring",
			total: "Total",
			winner: "Winner",
			jointWinners: "Joint winners"
		}
	}
};
//#endregion
export { kt as default };
