import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, jsx as r, jsxs as i } from "react/jsx-runtime";
import { useLayoutEffect as a, useRef as o, useState as s } from "react";
import { createPortal as c } from "react-dom";
import { useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { useFxAnchor as d } from "@bgparty/sdk/fx/anchors";
import { SheetView as f } from "@bgparty/sdk/sheet-view";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { Floater as m, FlySprite as ee, PulseBox as h } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as te } from "@bgparty/sdk/confirm-button";
import { OptionRadio as g, OptionSection as _ } from "@bgparty/sdk/ui/game-options";
//#region src/games/spooktacular/data.ts
var v = (e, t) => ({
	zh: e,
	en: t
}), y = [
	"red",
	"purple",
	"yellow",
	"blue",
	"green"
], ne = {
	red: "#ef5759",
	purple: "#c878ee",
	yellow: "#f4d35e",
	blue: "#65bdfa",
	green: "#74ce93",
	white: "#f4e8d0"
}, b = {
	red: v("红色", "Red"),
	purple: v("紫色", "Purple"),
	yellow: v("黄色", "Yellow"),
	blue: v("蓝色", "Blue"),
	green: v("绿色", "Green"),
	white: v("队员", "Team member")
}, x = [
	{
		name: v("青幕放映厅", "Cyan auditorium"),
		x: 0,
		y: 0,
		w: 3,
		h: 3,
		doors: [
			1,
			4,
			6
		],
		edge: !0
	},
	{
		name: v("红幕放映厅", "Red auditorium"),
		x: 3,
		y: 0,
		w: 1.5,
		h: 3,
		doors: [
			0,
			2,
			4
		],
		edge: !0
	},
	{
		name: v("紫幕放映厅", "Violet auditorium"),
		x: 4.5,
		y: 0,
		w: 2.3,
		h: 3,
		doors: [
			1,
			3,
			5,
			4
		],
		edge: !0
	},
	{
		name: v("洗手间", "Restrooms"),
		x: 6.8,
		y: 0,
		w: 2.2,
		h: 1.8,
		doors: [2, 5],
		edge: !0
	},
	{
		name: v("中央休息厅", "Central lounge"),
		x: 1.5,
		y: 3,
		w: 5.3,
		h: 2,
		doors: [
			0,
			1,
			2,
			5,
			9,
			8,
			7
		],
		edge: !1
	},
	{
		name: v("红毯长廊", "Red carpet hall"),
		x: 6.8,
		y: 1.8,
		w: 2.2,
		h: 5,
		doors: [
			3,
			2,
			4,
			9,
			10
		],
		edge: !0
	},
	{
		name: v("西侧走廊", "West passage"),
		x: 0,
		y: 3,
		w: 1.5,
		h: 4.5,
		doors: [0, 7],
		edge: !0
	},
	{
		name: v("零食吧", "Snack bar"),
		x: 1.5,
		y: 5,
		w: 1.5,
		h: 4.5,
		doors: [
			4,
			8,
			11,
			6
		],
		edge: !0
	},
	{
		name: v("绿幕放映厅", "Green auditorium"),
		x: 3,
		y: 5,
		w: 1.5,
		h: 3,
		doors: [
			4,
			10,
			7
		],
		edge: !1
	},
	{
		name: v("放映室", "Projection booth"),
		x: 4.5,
		y: 5,
		w: 2.3,
		h: 1.8,
		doors: [
			4,
			5,
			10
		],
		edge: !1
	},
	{
		name: v("道具库", "Prop room"),
		x: 4.5,
		y: 6.8,
		w: 4.5,
		h: 1.2,
		doors: [
			9,
			5,
			11,
			8
		],
		edge: !0
	},
	{
		name: v("入口门厅", "Entrance foyer"),
		x: 3,
		y: 8,
		w: 4.5,
		h: 1.5,
		doors: [10, 7],
		edge: !0
	}
], re = [
	{
		id: "wolfpack",
		name: "Meet the Wolfpack",
		icon: "☾",
		level: 2,
		cards: [
			"dogpile",
			"packHunt",
			"howling"
		],
		art: 1583,
		steps: v("依次结算在场狼人的能力；选择本回合使用的狼人并打出一张牌；移动除 Cristophe 之外的每只狼人；补至三张手牌。如果本回合交过一组观众，再从供应区选择一只狼人放入任意房间。", "Resolve each werewolf from left to right, choose a werewolf and play a card, move every werewolf except Cristophe, then draw back to three. If you turned in a set this turn, place another werewolf from your supply in any room."),
		ability: v("准备时选择两只不同狼人，放在不同房间。Marcia：每有一名其他玩家在她的房间，你获得 1 分。Iggy：移动本房另一枚棋子。Cristophe：移动他自己。Orphea：抽一张牌。", "Start with two different werewolves in different rooms. Marcia scores one per other player in her room. Iggy moves another figure in his room. Cristophe moves himself. Orphea draws one card.")
	},
	{
		id: "beasts",
		name: "Beasts of Business",
		icon: "↗",
		level: 3,
		cards: [
			"teamExercise",
			"accounting",
			"violentMarkets"
		],
		art: 1543,
		steps: v("打出一张牌；评估惊吓期货；补至三张手牌；移动；调整一枚惊吓期货。", "Play a card, evaluate Spook Futures, draw back to three, move, then adjust one Spook Future."),
		ability: v("准备时调整一枚期货。四枚期货分别覆盖 3、2、1、1 格，不得重叠或跨过计分轨道的转角。通胀使持有者失去 2 分；崩盘失去 3 分；利润使其在自己的房间吞噬三次；回报使其获得 4 分。评估时从你开始依次检查每名玩家，每人只触发一次。", "Adjust one Future during setup. Inflation spans three spaces and costs two points; Market Crash spans two and costs three; Eat the Profits spans one and devours three times; ROI spans one and gains four. Futures cannot overlap or cross a track corner. Evaluate each player once, starting with you.")
	},
	{
		id: "charles",
		name: "Charles",
		icon: "✦",
		level: 1,
		cards: [
			"clownCar",
			"pie",
			"switcheroo"
		],
		art: 1546,
		steps: v("打出一张牌；如果本回合惊吓过，吞噬本房全部观众；移动；移动本房另一枚棋子；补至三张手牌。", "Play a card. If you spooked this turn, devour every guest in your room. Move, move another figure in your room, then draw back to three."),
		ability: v("Charles 可以把其他怪物当作观众惊吓，并照常获得分数。", "Charles spooks other monsters as though they were guests and scores for them normally.")
	},
	{
		id: "deadLine",
		name: "The Dead Line",
		icon: "☎",
		level: 3,
		cards: [
			"openLines",
			"robocalls",
			"imHere"
		],
		art: 1549,
		steps: v("选择一部电话并打牌；反复接听有其他玩家怪物在场的电话；从交换台取一部电话放在没有电话的房间；补至三张手牌。", "Choose a phone and play a card, answer phones, place a phone in a room without one, then draw back to three."),
		ability: v("准备时将一部电话放在任意房间，其余七部电话分别占据交换台的七个能力位置。接听电话时，选择一部与其他玩家怪物同处一室的电话，将它放回交换台的一个空位，并执行该空位的效果。只要仍有符合条件的电话和空位，就继续接听。放置电话时，从交换台取走哪部电话，会决定之后留下哪个能力空位。", "During setup, place one phone in any room and place the remaining seven phones in the seven switchboard slots. To answer a phone, choose one sharing a room with another player’s monster, return it to an empty switchboard slot, and resolve that slot. Keep answering while eligible phones and empty slots remain. When deploying a phone, the slot you take it from determines which effect will be available on a later return.")
	},
	{
		id: "devil",
		name: "Devil’s Game II",
		icon: "◈",
		level: 1,
		cards: [
			"replayAward",
			"bonusRound",
			"kickback"
		],
		art: 1552,
		steps: v("打出一张牌；移动；发射；补至三张手牌。", "Play a card, move, launch, then draw back to three."),
		ability: v("发射时移动一名观众。可从其目的房间再移动另一名同色观众，然后可重复一次。最终房间按颜色结算：红色让其中一名玩家按移动数失分；紫色按移动数吞噬；黄色按移动数从相邻房拉入棋子；蓝色把你放入该房；绿色按移动数得分。", "Launch moves a guest. You may move a different guest of that color from its destination and repeat once more. In the final room: red makes one player lose one per moved guest; purple devours once per moved guest; yellow pulls one figure per moved guest; blue places you there; green scores one per moved guest.")
	},
	{
		id: "doctor",
		name: "Doctor Terror’s Basement of Horrors",
		icon: "ϟ",
		level: 3,
		cards: [
			"zappyZaps",
			"renovations",
			"klaxxon"
		],
		art: 1555,
		steps: v("打出一张牌；可以触发一枚陷阱；移动；补至三张手牌。", "Play a card, optionally trigger one trap, move, then draw back to three."),
		ability: v("准备时，将四种陷阱分别放在不同房间。四人以上时，再放置一枚火焰喷口；五人时，再放置一道暗门。触发陷阱时，在它所在的房间执行相应效果。\n\n· 特斯拉线圈让你惊吓。\n· 火焰喷口让你吞噬一名观众。\n· 暗门让你交换本房与相邻房间各一枚棋子的位置。\n· 克隆舱让你向该房间的每名其他玩家偷取 2 分。", "During setup, place the four different traps in different rooms. Add another Flamejet with four or more players and another Secret Door with five players. Trigger a trap to resolve its effect in its room.\n\n· Tesla Coil lets you spook.\n· Flamejet lets you devour one guest.\n· Secret Door lets you swap a figure in its room with a figure in an adjacent room.\n· Cloning Chamber lets you steal two points from each other player in that room.")
	},
	{
		id: "doombox",
		name: "Doombox",
		icon: "♫",
		level: 1,
		cards: ["remix", "crankIt"],
		art: 1570,
		steps: v("打出一张牌；可以播放一条音轨；移动；补至三张手牌。", "Play a card, optionally play a track, move, then draw back to three."),
		ability: v("播放音轨时，吞噬本房的一名观众，将同色磁带向前推进一格，并执行新位置的效果。每条轨道共有起点与四个效果格；磁带从最后一格继续前进时回到起点。起点没有效果。混音只推进磁带，不执行新位置的效果。", "To play a track, devour one guest in your room, advance the matching cassette one space, and perform its new space. Each track has a start and four effect spaces. Advancing from the final space returns the cassette to the start, which has no effect. Remix advances a cassette without performing its new effect.")
	},
	{
		id: "angler",
		name: "Lantern Glow 2: Revenge of the Angler",
		icon: "◉",
		level: 2,
		cards: [
			"flood",
			"chomp",
			"lanternGlow"
		],
		art: 1572,
		steps: v("打出一张牌；从深处升起；把灯笼放入任意暴露房间；补至三张手牌。", "Play a card, rise from the depths, place the lantern in any exposed room, then draw back to three."),
		ability: v("准备时在不同外缘房间各放一扇新门，再把灯笼放在暴露房间。新门通向外侧，只有观众可通过，通过者由你吞噬。弃牌数为 1—3 时放新门，4 时移动本房每枚棋子并按移动数得分，5 时惊吓一个暴露房间，6 时每个暴露房间加两观众，7 时向暴露房间中的每名其他玩家偷 4 分。", "Start with two new doors on different outer rooms and a lantern in an exposed room. Only guests may use outside doors; you devour guests that pass through them. With 1–3 discards place a door; 4 moves every figure in your room and scores per move; 5 spooks an exposed room; 6 adds two guests to each exposed room; 7 steals four from each player in an exposed room.")
	},
	{
		id: "grimhive",
		name: "Grimhive",
		icon: "⬡",
		level: 2,
		cards: [
			"swarm",
			"pheromones",
			"temptation"
		],
		art: 1575,
		steps: v("打出一张牌；收获蜂巢；移动或把女王放在一个有蜂巢的房间；补至三张手牌。", "Play a card, harvest hives, move or place the Queen in a room with a hive, then draw back to three."),
		ability: v("准备时在不同房间各放一枚蜂巢。每枚在场蜂巢让你得 1 分；每有一名玩家占据有蜂巢的已征服房间，你失去 1 分。一个房间的全部怪物归同一玩家时，该房被征服；女王所在房间永不被征服。", "Start with two hives in different rooms. Gain one per placed hive, then lose one per player in a conquered room with a hive. A room is conquered when all its monsters belong to the same player; the Queen’s room is never conquered.")
	},
	{
		id: "chef",
		name: "Hell Chef",
		icon: "♨",
		level: 2,
		cards: ["appetizer", "seconds"],
		art: 1578,
		steps: v("可以上菜；打出一张牌；可以备菜；移动；补至三张手牌。", "Optionally serve a dish, play a card, optionally prepare a dish, move, then draw back to three."),
		ability: v("准备时，将六道菜肴留在供应区。备菜时，将供应区的一道菜放入自己的房间或相邻房间。上菜时，从任意房间收回一道菜，在该菜原先所在的房间执行它的效果。\n\n· 腐臭泡芙让你移动该房间的每枚棋子。\n· 九重地狱辣汤让你把任意怪物放入该房间。\n· 恶臭蛋沙拉让你向该房间的每名其他玩家偷取 4 分。\n· 鞑靼触须让你惊吓该房间。\n· 恶魔蛋糕让你在该房间吞噬三次。\n· 五血布丁让你向该房间增加五名观众。", "Keep the six dishes in your supply during setup. To prepare, place one supply dish in your room or an adjacent room. To serve, return a dish from any room to your supply and perform its effect in the room it came from.\n\n· Putrid Popovers lets you move every figure in that room.\n· Ninth Circle Chili lets you place any monster in that room.\n· Effluvient Egg Salad lets you steal four points from each other player in that room.\n· Tentacles Tartar lets you spook that room.\n· Devil’s Food Cake lets you devour three times in that room.\n· Five-Blood Pudding lets you add five guests to that room.")
	},
	{
		id: "host",
		name: "Host",
		icon: "♜",
		level: 1,
		cards: [
			"iconsOfTerror",
			"look",
			"spooktacular"
		],
		art: 1580,
		steps: v("打出一张牌或介绍怪物；移动；补至三张手牌。", "Play a card or introduce a monster, move, then draw back to three."),
		ability: v("准备时按距离五人局缺少的人数，放置相同数量的无主机械怪物，且彼此不同房。介绍时选相邻房的一只怪物，以它为行动中心打出你的一张牌。得分和吞噬归你；若它属于另一名玩家，你们各得 2 分。机械怪物没有能力，也没有分数。", "Start with one animatronic per player fewer than five, in different rooms. Introduce chooses a monster in an adjacent room and plays your card through it. You receive all points and devoured guests. If it belongs to another player, both of you gain two. Animatronics have no abilities or score.")
	},
	{
		id: "car",
		name: "Killer Car",
		icon: "◆",
		level: 1,
		cards: [
			"overdrive",
			"mowDown",
			"getIn"
		],
		art: 1586,
		steps: v("打出一张牌；接一名乘客；移动；补至三张手牌。", "Play a card, pick up a passenger, move, then draw back to three."),
		ability: v("每次接乘客时，从本房选择一名与空座颜色相同的观众，将其放入该座位，然后执行该颜色的效果。五个座位都坐满后，将乘客作为一组观众交回，再把车放入任意房间。\n\n· 红色乘客让你抽三张牌。\n· 紫色乘客让你向本房的每名其他玩家偷取 2 分。\n· 黄色乘客让你先移动，再吞噬一次。\n· 蓝色乘客让你惊吓一次。\n· 绿色乘客让你把车放入任意房间。", "Pick up a guest from your room whose color matches an empty seat, place it in that seat, and resolve the matching effect. When all five seats are full, turn the passengers in as a set and place the Car in any room.\n\n· A red passenger lets you draw three cards.\n· A purple passenger lets you steal two points from each other player in your room.\n· A yellow passenger lets you move, then devour once.\n· A blue passenger lets you spook once.\n· A green passenger lets you place the Car in any room.")
	},
	{
		id: "killtron",
		name: "Killtron",
		icon: "⌘",
		level: 2,
		cards: [
			"guidance",
			"rollOut",
			"grapple",
			"exterminate",
			"arcLightning"
		],
		art: 1568,
		steps: v("从左至右执行程序中的三张牌；弃掉最右牌，其余右移，从手牌放一张牌到左端；补至三张手牌。", "Execute the three program cards from left to right, discard the rightmost card, shift the other cards right, insert a hand card on the left, then draw back to three."),
		ability: v("准备时程序依次为 Guidance System、Roll Out、Grapple，其余牌与基础牌洗成牌库。忽略所有「再打牌」效果。Guidance System 会立即用一张手牌替换自己并执行替换牌。", "Start with Guidance System, Roll Out and Grapple in the program. Shuffle the remaining unique and basic cards. Ignore all play-a-card effects. Guidance System immediately replaces itself with a hand card and executes that replacement.")
	},
	{
		id: "mummy",
		name: "Mummygator II: Tomb of the Mummygator",
		icon: "▣",
		level: 2,
		cards: ["relocateTomb", "drag"],
		art: 1589,
		steps: v("解除诅咒；打出一张牌；移动；补至三张手牌。", "Unseal the curse, play a card, move, then draw back to three."),
		ability: v("陵墓是附属于所在影院房间的独立房间。观众可以进入陵墓，但不能离开，也不能直接向陵墓增加观众。只有 Mummygator 可以进入陵墓。准备时放置陵墓，并把鳄鱼放在与陵墓相连的影院房间。\n\n解除诅咒时，吞噬陵墓中的一名观众；如果成功，在一个空罐位放置诅咒罐并执行该位置的效果。重复这一过程，直到陵墓内没有观众。七个罐位都填满后，仍要吞噬陵墓中的剩余观众，只是不再获得罐位效果。", "The Tomb is a separate room attached to its theater room. Guests can enter but cannot leave it, and guests cannot be added directly to it. Only Mummygator may enter the Tomb. During setup, place the Tomb and start Mummygator in the connected theater room.\n\nTo unseal the curse, devour one guest in the Tomb. If successful, fill an empty jar slot and resolve its effect. Repeat until no guests remain in the Tomb. Once all seven jar slots are filled, continue devouring the remaining guests without further jar effects.")
	},
	{
		id: "nightslayerr",
		name: "Nightslayerr",
		icon: "♬",
		level: 1,
		cards: [
			"shred",
			"chainLight",
			"callOut",
			"sing",
			"pose"
		],
		art: 1591,
		steps: v("打出一张牌；若本回合交过一组观众，进行狂欢；与相邻房一名观众交换位置，若该房没有观众则直接移入；补至三张手牌。", "Play a card. If you turned in a set this turn, mosh. Switch places with a guest in an adjacent room, or move there normally if it has no guests. Draw back to three."),
		ability: v("狂欢会先在本房增加五名观众，再惊吓本房。", "Mosh adds five guests to your room, then spooks.")
	},
	{
		id: "outlander",
		name: "Mask of the Outlander",
		icon: "✧",
		level: 1,
		cards: [
			"abduct",
			"gangUp",
			"mosey"
		],
		art: 1596,
		steps: v("召集队伍；打出一张牌；移动；补至三张手牌。", "Get ’em, posse, play a card, move, then draw back to three."),
		ability: v("准备时，在自己的起始房间吞噬一次。召集队伍时，按吞噬区实际拥有的普通观众颜色，从红色到绿色依次执行下列效果。队员的百搭能力只适用于交回一组观众，不为这些能力提供颜色。\n\n· 红色让你移动一次。\n· 紫色让你从相邻房间拉入一枚棋子。\n· 黄色让你向本房增加两名观众，并获得 2 分。\n· 蓝色让你向本房的每名其他玩家偷取 1 分。\n· 绿色让你失去 2 分，然后惊吓本房。", "During setup, devour once in your starting room. For Get ’Em, Posse, resolve each ordinary color actually present in your pile from red to green. A team member is wild only when turning in a set and does not activate these colors.\n\n· Red lets you move once.\n· Purple lets you pull one figure from an adjacent room.\n· Yellow lets you add two guests to your room and gain two points.\n· Blue lets you steal one point from each other player in your room.\n· Green makes you lose two points, then spook your room.")
	},
	{
		id: "regoo",
		name: "ReGoo",
		icon: "●",
		level: 2,
		cards: [
			"squelch",
			"blurp",
			"schlorp"
		],
		art: 1563,
		steps: v("消化；选择一团黏液并打牌；生长；补至三张手牌。若本回合交过一组观众，再把一团黏液放在任意房间。", "Consume, choose a Blob and play a card, grow, then draw back to three. If you turned in a set this turn, place another Blob in any room."),
		ability: v("消化时对每名其他玩家选择其所在的一个房间，按该房黏液数向其偷分。生长在选定黏液的房间或相邻房放一团黏液。十团全用完时，可先移除一团再生长。", "For each other player, choose one room they occupy and steal one per Blob there. Grow places a Blob in the chosen Blob’s room or an adjacent room. If all ten are placed, you may remove one first.")
	},
	{
		id: "remover",
		name: "Remover",
		icon: "↝",
		level: 1,
		cards: ["flex", "coaching"],
		art: 1602,
		steps: v("打出一张牌；进行恐怖健身；沿减重计划前进一或两格；移动；补至三张手牌。", "Play a card, do Fearsonal Fitness, advance one or two spaces on the Weight Loss Plan, move, then draw back to three."),
		ability: v("进行恐怖健身时，执行哑铃当前位置的效果。随后在移动哑铃的回合步骤中，选择前进一格或两格，但不能越过轨道终点。再次执行终点格的健身效果时，回到起点并获得 10 分。", "When doing Fearsonal Fitness, perform the effect of the dumbbell’s current space. During the later advance step, move it one or two spaces without passing the end of the track. Performing Fitness on the final space returns the dumbbell to the start and gains ten points.")
	},
	{
		id: "eagle",
		name: "Screamin’ Eagle",
		icon: "⌁",
		level: 2,
		cards: [
			"partyHard",
			"dumbStunt",
			"accomplice"
		],
		art: 1599,
		steps: v("打出一张牌；移动；恐吓队员；补至三张手牌。", "Play a card, move, terrorize, then draw back to three."),
		ability: v("准备时把七名队员分别放在不同房间，四人以上改为九名。任何怪物都能惊吓队员，但只有 Eagle 能吞噬他们。只有交回一组观众时，吞噬区中的队员才能代替任意一种颜色；交回的队员离开游戏。恐吓只惊吓本房队员。吞噬影院最后一名队员时获得 10 分。", "Start with seven team members in different rooms, or nine with four or more players. All monsters can spook them; only Eagle can devour them. They are wild only for turning in a set from the devour pile, and leave the game when turned in. Terrorize spooks only team members. Devouring the last team member in the theater scores ten.")
	},
	{
		id: "listener",
		name: "The Listener Below",
		icon: "≈",
		level: 1,
		cards: [
			"emergence",
			"skittering",
			"nudge",
			"bump",
			"listen"
		],
		art: 1606,
		steps: v("打出一张牌；再打出一张牌；移动；补至三张手牌。", "Play a card, play another card, move, then draw back to three."),
		ability: v("Listener 的专属牌提供额外移动、抽牌和吞噬机会。各张牌结算完毕后才进入下一步。", "The Listener’s unique cards provide movement, drawing and devouring. Finish resolving each card before proceeding to the next step.")
	}
], S = (e) => re.find((t) => t.id === e), C = [
	"jumpscare",
	"consume",
	"haunt",
	"mash",
	"search"
], w = Object.fromEntries([
	[
		"jumpscare",
		"突然惊吓",
		"Jumpscare",
		"移动，然后打出一张牌。",
		"Move, then play a card."
	],
	[
		"consume",
		"吞食",
		"Consume",
		"吞噬本房每种颜色各一名观众。",
		"Devour one guest of each color in your room."
	],
	[
		"haunt",
		"闹鬼",
		"Haunt",
		"惊吓，然后再惊吓一次。",
		"Spook, then spook again."
	],
	[
		"mash",
		"怪物派对",
		"Mash",
		"移动本房全部怪物。每移动一名玩家的怪物，你获得 2 分；同一玩家只计算一次。",
		"Move all monsters in your room. Gain two points per player moved, counting each player once."
	],
	[
		"search",
		"搜寻",
		"Search",
		"本房增加三名观众，然后打出一张牌。",
		"Add three guests, then play a card."
	],
	[
		"teamExercise",
		"团队锻炼",
		"Team Exercise",
		"本房每名玩家分别获得或失去 1 分，由你为每人选择。然后抽三张牌。",
		"Each player in your room gains or loses one point, chosen separately by you. Draw three cards."
	],
	[
		"accounting",
		"算账",
		"Accounting",
		"选择任意一名玩家，使其获得或失去 1 分，然后打出一张牌。",
		"Choose any player to gain or lose one point, then play a card."
	],
	[
		"violentMarkets",
		"剧烈波动",
		"Violent Markets",
		"调整一枚惊吓期货，或评估惊吓期货。",
		"Adjust Spook Futures or evaluate Spook Futures."
	],
	[
		"clownCar",
		"小丑车",
		"Clown Car",
		"增加三名观众，然后惊吓。",
		"Add three guests, then spook."
	],
	[
		"pie",
		"奶油袭面",
		"Pie to the Face",
		"向本房一名其他玩家偷取 3 分，然后惊吓。",
		"Steal three points from one player in your room, then spook."
	],
	[
		"switcheroo",
		"调包",
		"Ol’ Switcheroo",
		"与相邻房的一枚棋子交换位置，然后打出一张牌。",
		"Switch places with a figure in an adjacent room, then play a card."
	],
	[
		"openLines",
		"开放线路",
		"Open Lines",
		"将两部电话分别放入没有电话的房间。",
		"Place two phones in rooms without phones."
	],
	[
		"robocalls",
		"自动来电",
		"Robocalls",
		"每部电话分别向其房间内一名其他玩家偷取 2 分。",
		"For each phone, steal two points from one player in its room."
	],
	[
		"imHere",
		"我在这里",
		"I’m Here",
		"每部电话分别在其房间吞噬一次。",
		"For each phone, devour in its room."
	],
	[
		"replayAward",
		"重播奖励",
		"Replay Award",
		"每个相邻房间增加一名观众。",
		"Add a guest to each adjacent room."
	],
	[
		"bonusRound",
		"奖励回合",
		"Bonus Round",
		"本回合发射后，惊吓最终房间。",
		"After you launch this turn, spook the final room."
	],
	[
		"kickback",
		"回弹",
		"Kickback",
		"把吞噬区全部观众放入本房，每放一名获得 1 分。",
		"Place all your devoured guests into your room. Gain one point per guest."
	],
	[
		"zappyZaps",
		"电击",
		"Zappy Zaps",
		"触发一枚陷阱。",
		"Trigger a trap."
	],
	[
		"renovations",
		"改建",
		"Renovations",
		"将一枚陷阱移至没有陷阱的房间，然后打出一张牌。",
		"Pick up a trap and place it in a room with no traps, then play a card."
	],
	[
		"klaxxon",
		"警报",
		"Klaxxon",
		"每枚陷阱分别移动其房间的一枚棋子。",
		"For each trap, move a figure in its room."
	],
	[
		"remix",
		"混音",
		"Remix",
		"任选一条磁带轨道前进一格，不执行该格效果。",
		"Advance one cassette one space without performing its effect."
	],
	[
		"crankIt",
		"调高音量",
		"Crank It",
		"播放一条音轨。",
		"Play a track."
	],
	[
		"flood",
		"洪水",
		"Flood",
		"弃掉全部手牌，然后惊吓。",
		"Discard your hand, then spook."
	],
	[
		"chomp",
		"咬住",
		"Chomp",
		"放置一扇新门。若成功，在该房间吞噬两次。",
		"Place a new door. If you did, devour twice in that room."
	],
	[
		"lanternGlow",
		"灯笼微光",
		"Lantern Glow",
		"从每个相邻房间各移动一枚棋子进入本房。",
		"Move one figure from each adjacent room into your room."
	],
	[
		"swarm",
		"蜂群",
		"Swarm",
		"移动，在本房放一枚蜂巢，然后打出一张牌。",
		"Move, place a hive in your room, then play a card."
	],
	[
		"pheromones",
		"信息素",
		"Pheromones",
		"每枚蜂巢分别移动其房间的一枚棋子，然后打出一张牌。",
		"For each hive, move a figure in its room, then play a card."
	],
	[
		"temptation",
		"诱惑",
		"Temptation",
		"每枚蜂巢分别在其房间吞噬一次。",
		"For each hive, devour a guest in its room."
	],
	[
		"appetizer",
		"开胃菜",
		"Appetizer",
		"上菜，但不收回该菜肴。",
		"Serve a dish without returning it to your board."
	],
	[
		"seconds",
		"再来一份",
		"Seconds",
		"吞噬，然后备菜。",
		"Devour, then prepare a dish."
	],
	[
		"iconsOfTerror",
		"恐怖偶像",
		"Icons of Terror",
		"把一只机械怪物放入相邻房间，然后惊吓该房间。",
		"Place an animatronic in an adjacent room, then spook that room."
	],
	[
		"look",
		"看这里",
		"Look",
		"移动，然后介绍一只怪物。",
		"Move, then introduce a monster."
	],
	[
		"spooktacular",
		"恐怖盛会",
		"Spooktacular",
		"选择有至少三只怪物的房间并惊吓，获得三倍惊吓分数。",
		"Spook any room with at least three monsters and score triple points for that spook."
	],
	[
		"dogpile",
		"一拥而上",
		"Dogpile",
		"每只狼人分别从本房一名其他玩家的吞噬区取一名观众。",
		"For each werewolf, take a guest from one player’s devour pile in its room."
	],
	[
		"packHunt",
		"狼群狩猎",
		"Pack Hunt",
		"每只狼人分别在其房间吞噬一次。",
		"For each werewolf, devour in its room."
	],
	[
		"howling",
		"嚎叫",
		"Howling",
		"每只狼人分别移动本房两名观众，每移动一名获得 1 分。",
		"For each werewolf, move two guests in its room and score one per guest moved."
	],
	[
		"overdrive",
		"超速",
		"Overdrive",
		"移动，然后打出一张牌。",
		"Move, then play a card."
	],
	[
		"mowDown",
		"碾过",
		"Mow Down",
		"把本房全部棋子通过同一扇门移出。每移动一枚获得 1 分。",
		"Move every figure in your room through one door. Gain one point per figure moved."
	],
	[
		"getIn",
		"上车",
		"Get In",
		"接一名乘客。",
		"Pick up a passenger."
	],
	[
		"guidance",
		"制导系统",
		"Guidance System",
		"弃掉这张程序牌，用一张手牌替换它，并立即执行替换牌。",
		"Discard this program card, replace it with a hand card, then execute that card."
	],
	[
		"rollOut",
		"出动",
		"Roll Out",
		"移动。",
		"Move."
	],
	[
		"grapple",
		"抓钩",
		"Grapple",
		"从相邻房间移动一枚棋子进入本房。",
		"Move a figure from an adjacent room into your room."
	],
	[
		"exterminate",
		"歼灭",
		"Exterminate",
		"惊吓。",
		"Spook."
	],
	[
		"arcLightning",
		"电弧",
		"Arc Lightning",
		"向本房及相邻房间每名其他玩家偷取 1 分。",
		"Steal one point from each player in your room and adjacent rooms."
	],
	[
		"relocateTomb",
		"迁陵",
		"Relocate",
		"把陵墓放在任意影院房间，然后把鳄鱼放在该影院房间。",
		"Place the Tomb in any theater room, then move the Mummygator to that room."
	],
	[
		"drag",
		"拖行",
		"Drag",
		"移动，可以携带至多两名观众一同移动。",
		"Move. You may bring up to two guests along."
	],
	[
		"shred",
		"狂奏",
		"Shred",
		"抽牌至三张手牌，然后打出一张牌。",
		"Draw back to three, then play a card."
	],
	[
		"chainLight",
		"连环聚光",
		"Chain Light",
		"移动并吞噬，然后把这两步再重复两次。",
		"Move and devour. Repeat twice more."
	],
	[
		"callOut",
		"呼唤",
		"Call Out",
		"在相邻房间吞噬一次，然后打出一张牌。",
		"Devour in an adjacent room, then play a card."
	],
	[
		"sing",
		"歌唱",
		"Sing",
		"从每个相邻房间各拉一名观众进入本房，每移动一名获得 1 分。",
		"Move a guest from each adjacent room into your room and score one per guest moved."
	],
	[
		"pose",
		"摆姿势",
		"Pose",
		"获得 1 分，然后打出一张牌。",
		"Gain one point, then play a card."
	],
	[
		"abduct",
		"绑走",
		"Abduct",
		"移动并吞噬，然后把这两步再重复两次。",
		"Move and devour. Repeat twice more."
	],
	[
		"gangUp",
		"围攻",
		"Gang Up",
		"选择本房一名其他玩家，按你吞噬区的不同颜色数向其偷取相同分数。",
		"Steal from one player in your room, one point per different color in your devour pile."
	],
	[
		"mosey",
		"缓步",
		"Mosey",
		"交换吞噬区与本房各一名观众，然后打出一张牌。",
		"Swap a guest in your devour pile with one in your room, then play a card."
	],
	[
		"squelch",
		"黏液涌动",
		"Squelch",
		"移动每团黏液。",
		"Move each Blob."
	],
	[
		"blurp",
		"黏液吞食",
		"Blurp",
		"每团黏液分别在其房间吞噬一次。",
		"For each Blob, devour in its room."
	],
	[
		"schlorp",
		"黏液生长",
		"Schlorp",
		"进行生长。",
		"Grow."
	],
	[
		"flex",
		"屈伸",
		"Flex",
		"进行恐怖健身。",
		"Do Fearsonal Fitness."
	],
	[
		"coaching",
		"指导",
		"Coaching",
		"从每个相邻房间各拉一名观众进入本房，每移动一名获得 1 分。",
		"Move a guest from each adjacent room into your room and score one per guest moved."
	],
	[
		"partyHard",
		"尽情狂欢",
		"Party Hard",
		"从每个相邻房间各拉一名观众进入本房，每移动一名获得 1 分。",
		"Move a guest from each adjacent room into your room and score one per guest moved."
	],
	[
		"dumbStunt",
		"鲁莽特技",
		"Dumb Stunt",
		"吞噬任意房间一名队员。若成功，在该房间再吞噬两次。",
		"Devour a team member in any room. If you did, devour twice more there."
	],
	[
		"accomplice",
		"同伙",
		"Accomplice",
		"与任意队员交换位置，然后打出一张牌。",
		"Switch the Eagle with any team member, then play a card."
	],
	[
		"emergence",
		"破土",
		"Emergence",
		"吞噬三次，弃掉全部手牌，然后抽一张牌。",
		"Devour three times, discard your hand, then draw one card."
	],
	[
		"skittering",
		"疾行",
		"Skittering",
		"移动，然后抽一张牌。",
		"Move, then draw a card."
	],
	[
		"nudge",
		"推挤",
		"Nudge",
		"移动本房一枚棋子，然后抽一张牌。",
		"Move a figure in your room, then draw a card."
	],
	[
		"bump",
		"撞击",
		"Bump",
		"从相邻房间拉入一枚棋子，然后抽一张牌。",
		"Move a figure from an adjacent room into your room, then draw a card."
	],
	[
		"listen",
		"倾听",
		"Listen",
		"向本房一名其他玩家偷取 3 分。",
		"Steal three points from one player in your room."
	]
].map(([e, t, n, r, i]) => [e, {
	name: v(t, n),
	text: v(r, i)
}])), T = [
	{
		name: v("通胀", "Inflation"),
		span: 3,
		effect: "lose",
		n: 2
	},
	{
		name: v("市场崩盘", "Market Crash"),
		span: 2,
		effect: "lose",
		n: 3
	},
	{
		name: v("吞食利润", "Eat the Profits"),
		span: 1,
		effect: "devour",
		n: 3
	},
	{
		name: v("投资回报", "ROI"),
		span: 1,
		effect: "score",
		n: 4
	}
], E = [
	v("腐臭泡芙", "Putrid Popovers"),
	v("九重地狱辣汤", "Ninth Circle Chili"),
	v("恶臭蛋沙拉", "Effluvient Egg Salad"),
	v("鞑靼触须", "Tentacles Tartar"),
	v("恶魔蛋糕", "Devil’s Food Cake"),
	v("五血布丁", "Five-Blood Pudding")
], D = [
	v("特斯拉线圈", "Tesla Coil"),
	v("火焰喷口", "Flamejet"),
	v("暗门", "Secret Door"),
	v("克隆舱", "Cloning Chamber")
], O = [
	"Marcia",
	"Iggy",
	"Cristophe",
	"Orphea"
], k = "@killtron", ie = [
	v("获得本回合已回收电话数的分数。", "Gain points equal to the phones returned this turn."),
	v("你与接听者各抽两张牌。", "You and the answering player each draw two cards."),
	v("从交换台放置另一部电话。", "Place another phone from the switchboard."),
	v("你与接听者各获得 2 分。", "You and the answering player each gain two points."),
	v("接听房间增加两名观众，你获得 2 分。", "Add two guests to the answering room and gain two points."),
	v("移动接听的怪物。", "Move the answering monster."),
	v("在接听的怪物所在房间吞噬一次。", "Devour once in the answering monster’s room.")
], ae = [
	v("立即抽取自己牌库与弃牌堆中的全部牌。", "Immediately draw every card in your deck and discard pile."),
	v("立即向陵墓所在影院房间的每名其他玩家偷取 5 分。", "Immediately steal five points from every other player in the theater room containing the Tomb."),
	v("在自己的回合进入房间后，可以移动该房间的另一枚棋子。", "After entering a room on your turn, you may move another figure in that room."),
	v("每次惊吓后获得 2 分。", "Gain two points after each spook."),
	v("每回合可以重复一次回合步骤中的移动。", "You may repeat the movement step once each turn."),
	v("两个奖励罐位都放满时，立即获得 5 分。", "Immediately gain five points when both bonus jar slots are filled."),
	v("两个奖励罐位都放满时，立即获得 5 分。", "Immediately gain five points when both bonus jar slots are filled.")
], A = [
	v("无效果。", "No effect."),
	v("抽三张牌。", "Draw three cards."),
	v("增加两名观众并获得 2 分。", "Add two guests and gain two points."),
	v("惊吓。", "Spook."),
	v("吞噬本房全部观众。", "Devour every guest in your room."),
	v("向本房及相邻房间的每名其他玩家偷取 1 分。", "Steal one point from each other player in your room and adjacent rooms."),
	v("增加三名观众并获得 3 分。", "Add three guests and gain three points."),
	v("惊吓，其中一扇门可重复使用一次。", "Spook; you may reuse one door once."),
	v("按本房棋子数，每枚获得 1 分。", "Gain one point for each figure in your room."),
	v("抽取自己的全部牌。", "Draw all your cards."),
	v("把自己放在任意房间。", "Place yourself in any room."),
	v("惊吓两次。", "Spook twice."),
	v("向本房及相邻房间的每名其他玩家偷取 2 分。", "Steal two points from each other player in your room and adjacent rooms."),
	v("回到起点并获得 10 分。", "Return to the start and gain ten points.")
], oe = [
	[v("起点，无效果。", "Start; no effect."), ...[
		2,
		3,
		4,
		5
	].map((e) => v(`增加 ${e} 名观众并获得 ${e} 分。`, `Add ${e} guests and gain ${e} points.`))],
	[
		v("起点，无效果。", "Start; no effect."),
		v("抽两张牌。", "Draw two cards."),
		v("从弃牌堆取回一张牌。", "Recover one card from your discard pile."),
		v("打出一张牌。", "Play a card."),
		v("抽取自己的全部牌。", "Draw all your cards.")
	],
	[
		v("起点，无效果。", "Start; no effect."),
		v("把自己放入任意房间。", "Place yourself in any room."),
		v("把任意怪物放入任意房间。", "Place any monster in any room."),
		v("把自己放入任意房间。", "Place yourself in any room."),
		v("移动本房每枚棋子，每移动一枚获得 1 分。", "Move every figure in your room and gain one point for each moved figure.")
	],
	[v("起点，无效果。", "Start; no effect."), ...[
		2,
		3,
		4,
		5
	].map((e) => v(`向本房每名其他玩家偷取 ${e} 分。`, `Steal ${e} points from every other player in your room.`))],
	[
		v("起点，无效果。", "Start; no effect."),
		v("吞噬一次。", "Devour once."),
		v("吞噬两次。", "Devour twice."),
		v("吞噬三次。", "Devour three times."),
		v("吞噬本房全部观众。", "Devour every guest in your room.")
	]
], se = [
	v("移动菜肴房间中的每枚棋子。", "Move every figure in the dish’s room."),
	v("把任意怪物放入菜肴房间。", "Place any monster in the dish’s room."),
	v("向菜肴房间中的每名其他玩家偷取 4 分。", "Steal four points from every other player in the dish’s room."),
	v("惊吓菜肴房间。", "Spook the dish’s room."),
	v("在菜肴房间吞噬三次。", "Devour three times in the dish’s room."),
	v("在菜肴房间增加五名观众，并按通常规则获得分数。", "Add five guests to the dish’s room and score as usual.")
], ce = [
	v("惊吓陷阱房间。", "Spook the trap’s room."),
	v("在陷阱房间吞噬一名观众。", "Devour one guest in the trap’s room."),
	v("交换陷阱房间与一个相邻房间中的各一枚棋子。", "Switch a figure in the trap’s room with a figure in an adjacent room."),
	v("向陷阱房间中的每名其他玩家偷取 2 分。", "Steal two points from every other player in the trap’s room.")
], le = {
	id: "spooktacular",
	tier: "alpha",
	mechanics: ["hand-management", "set-collection"],
	interactionTags: [],
	nameKey: "games.spooktacular.name",
	descKey: "games.spooktacular.desc",
	rulesKey: "games.spooktacular.rules",
	icon: "🎬",
	iconImg: "games/spooktacular.webp",
	accent: "#28b5ad",
	minPlayers: 1,
	maxPlayers: 5,
	bestPlayers: [3, 4],
	hotseat: "cover",
	search: {
		py: "",
		init: ""
	},
	rulesUrl: { en: "https://drive.google.com/file/d/1Kggd73HG8X-I2lpr5RbAHpzpIFfgQqEf/view" },
	releasedAt: "2026-11-07T15:45:00+08:00"
}, ue = t.object({
	autoKilltron: t.boolean().default(!1),
	difficulty: t.enum([
		"easy",
		"normal",
		"hard",
		"nightmare"
	]).default("normal")
}).default({
	autoKilltron: !1,
	difficulty: "normal"
}), de = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	revision: t.int().nonnegative(),
	id: t.int().nonnegative()
}).strict(), t.object({
	type: t.literal("tick"),
	now: t.number().finite()
}).strict()]), fe = t.enum([
	"red",
	"purple",
	"yellow",
	"blue",
	"green",
	"white"
]), pe = t.object({
	id: t.string(),
	color: fe,
	room: t.int()
}), me = t.object({
	id: t.string(),
	owner: t.string(),
	kind: t.string(),
	room: t.int()
}), he = t.object({
	id: t.int(),
	key: t.string(),
	text: t.object({
		zh: t.string(),
		en: t.string()
	}),
	room: t.int().optional(),
	target: t.string().optional(),
	piece: t.string().optional(),
	card: t.string().optional(),
	color: fe.optional(),
	n: t.number().optional()
}), ge = t.object({
	phase: t.enum([
		"draft",
		"setup",
		"play",
		"done"
	]),
	revision: t.int(),
	round: t.int(),
	turn: t.string(),
	players: t.array(t.object({
		rid: t.string(),
		monster: t.string(),
		score: t.number(),
		tickets: t.int(),
		ticketValues: t.array(t.int()).nullable(),
		pile: t.array(pe),
		seats: t.array(pe),
		handCount: t.int(),
		deckCount: t.int(),
		discard: t.array(t.string()),
		program: t.array(t.string()),
		tracks: t.array(t.int()),
		jars: t.array(t.int()),
		fitness: t.int(),
		switchboard: t.array(t.string())
	})),
	guests: t.array(pe),
	pieces: t.array(me),
	locked: t.array(t.int()),
	bagCount: t.int(),
	ticketsLeft: t.int(),
	tombRoom: t.int().nullable(),
	futures: t.array(t.object({
		owner: t.string(),
		kind: t.int(),
		start: t.int()
	})),
	pending: t.object({
		rid: t.string(),
		actor: t.string(),
		key: t.string(),
		text: t.object({
			zh: t.string(),
			en: t.string()
		}),
		room: t.int().optional()
	}).nullable(),
	endRound: t.boolean(),
	autoCards: t.array(t.string()),
	last: t.object({
		kind: t.string(),
		rid: t.string(),
		room: t.int().optional(),
		to: t.int().optional(),
		piece: t.string().optional(),
		color: fe.optional(),
		n: t.number().optional(),
		card: t.string().optional(),
		pieceKind: t.string().optional(),
		monster: t.string().optional(),
		playerIndex: t.int().optional()
	}).nullable()
}), _e = t.object({
	hand: t.array(t.string()),
	choices: t.array(he)
}), j = (e, t) => e.players.find((e) => e.rid === t), M = (e, t) => e.pieces.find((e) => e.id === t), N = (e, t) => e.guests.find((e) => e.id === t), P = (e) => [
	"monster",
	"blob",
	"phone",
	"wolf",
	"animatronic"
].includes(e.kind), F = (e, t) => e.pieces.filter((e) => e.owner === t && P(e)), I = (e, t) => F(e, t).filter((e) => e.room >= 0), L = (e, t) => M(e, t.piece ?? e.focus[t.who]) ?? I(e, t.who)[0], R = (e, t) => t.room ?? L(e, t)?.room ?? 4, z = (e, t, n = {}) => ({
	who: e.who,
	piece: e.piece,
	room: e.room,
	k: t,
	...n
}), B = (e, t) => {
	e.queue.unshift(...t);
}, V = (e) => x.map((e, t) => t).filter((t) => !e.locked.includes(t)), H = (e) => e === 12 ? v("陵墓", "Tomb") : x[e].name, U = (e, t) => t === 12 ? e.tombRoom === null ? [] : [e.tombRoom] : [...x[t].doors, ...e.tombRoom === t ? [12] : []].filter((t) => !e.locked.includes(t));
function W(e, t) {
	if (t.room < 0 || "color" in t && t.room === 12) return [];
	let n = U(e, t.room).filter((n) => n !== 12 || "color" in t || j(e, t.owner)?.monster === "mummy");
	return "color" in t && t.color !== "white" && e.pieces.some((e) => e.kind === "door" && e.room === t.room) && n.push(-10), n;
}
var G = (e, t) => [...e.guests.filter((e) => e.room === t), ...e.pieces.filter((e) => P(e) && e.room === t)], ve = (e, t, n) => e.players.filter((r) => r.rid !== t && I(e, r.rid).some((e) => n.includes(e.room)));
function K(t, n, r) {
	for (let i = r.length - 1; i > 0; i--) {
		let a = e(n, t.rngCursor++, i + 1);
		[r[i], r[a]] = [r[a], r[i]];
	}
	return r;
}
function q(e, t, n, r, i = {}) {
	e.last = {
		kind: n,
		rid: r.who,
		...i
	}, t.push({
		kind: "spookEvent",
		rid: r.who,
		data: e.last
	});
}
function ye(e, t, n, r, i) {
	let a = j(e, r);
	if (!a) return;
	let o = Math.max(0, a.score + i) - a.score;
	a.score += o, a.score >= 50 && (e.endRound = !0), o && q(e, t, "score", {
		...n,
		who: r
	}, { n: o });
}
function J(e, t, n = {}) {
	return {
		id: 0,
		key: "choice",
		text: e,
		effects: t,
		...n
	};
}
function Y(e, t, n, r, i, a) {
	if (i.length) {
		if (i.forEach((e, t) => {
			e.id = t;
		}), i.length === 1) {
			B(e, i[0].effects);
			return;
		}
		if (t.who === "@killtron" && [
			"move",
			"spook",
			"pull",
			"mashMove"
		].includes(n) && !(n === "mashMove" && i.every((e) => !e.target)) && !(n === "pull" && i.every((t) => !t.color && !j(e, M(e, t.piece ?? "")?.owner ?? "")))) {
			let r = e.autoCards[2], a = [
				"red",
				"yellow",
				"green",
				"blue",
				"purple",
				"white"
			], o = i.map((i) => {
				if (n === "spook") {
					let n = i.room ?? 4, r = x[R(e, t)] ?? x[e.tombRoom ?? 4], o = x[n] ?? {
						x: r.x,
						y: -1,
						w: 0,
						h: 0
					}, s = (Math.atan2(o.x + o.w / 2 - r.x - r.w / 2, -(o.y + o.h / 2 - r.y - r.h / 2)) + Math.PI * 2) % (Math.PI * 2);
					return -(a.indexOf(i.color ?? "white") * 100 + s);
				}
				if (n === "pull") {
					let t = e.pieces.find((e) => e.id === i.piece);
					return t?.owner && j(e, t.owner) && t.owner !== "@killtron" ? 1e3 + (j(e, t.owner)?.score ?? 0) : i.color ? (j(e, "@killtron").pile.some((t) => N(e, t).color === i.color) ? 0 : 100) - a.indexOf(i.color ?? "white") : -1e4;
				}
				let o = i.room ?? 4, s = e.guests.filter((e) => e.room === o), c = x[o]?.doors.length ?? 1;
				if (n === "mashMove" && i.target !== "@killtron") return -s.length * 100 - c;
				if (r === "consume") {
					let t = j(e, k).pile.map((t) => N(e, t).color);
					return new Set(s.filter((e) => !t.includes(e.color)).map((e) => e.color)).size * 100 + new Set(s.map((e) => e.color)).size;
				}
				return s.length * 100 + c;
			}), s = Math.max(...o), c = i.filter((e, t) => o[t] === s);
			if (c.length === 1) {
				B(e, c[0].effects);
				return;
			}
			i = c, i.forEach((e, t) => {
				e.id = t;
			});
		}
		e.pending = {
			rid: t.who === "@killtron" ? e.humans[0] : t.who,
			actor: t.who,
			key: n,
			text: r,
			options: i,
			...a === void 0 ? {} : { room: a }
		};
	}
}
function X(e, t, n, r) {
	Y(e, t, "optional", n, [J(v("执行", "Perform"), r), J(v("跳过", "Skip"), [])]);
}
var be = (e, t, n, r, i = {}) => n.map((e) => J(e === 12 ? v("陵墓", "Mummy’s Tomb") : H(e), [z(t, r, {
	...i,
	to: e
})], {
	room: e,
	key: r
}));
function xe(e, t, n, r) {
	if (n.who === "@killtron") return;
	let i = j(e, n.who), a = n.n === -1 ? i.deck.length + i.discard.length : n.n === -2 ? Math.max(0, 3 - i.hand.length) : n.n ?? 1, o = [];
	for (let t = 0; t < a; t++) {
		i.deck.length || (i.deck = K(e, r, i.discard), i.discard = []);
		let t = i.deck.shift();
		if (!t) break;
		i.hand.push(t), o.push(t);
	}
	o.length && (e.last = {
		kind: "draw",
		rid: n.who,
		n: o.length
	}, t.push({
		kind: "spookEvent",
		rid: n.who,
		data: e.last,
		for: [n.who],
		secret: { cards: o }
	}));
}
function Se(e, t, n) {
	let r = ue.parse(e), i = t.length === 1 || r.autoKilltron && t.length < 5 ? [k, ...t] : [...t], a = i.map((e) => ({
		rid: e,
		monster: e === "@killtron" ? "killtron" : "",
		score: e === "@killtron" ? {
			easy: 5,
			normal: 10,
			hard: 15,
			nightmare: 20
		}[r.difficulty] : 10,
		tickets: [],
		pile: [],
		seats: [],
		hand: [],
		deck: [],
		discard: [],
		program: [],
		tracks: [
			0,
			0,
			0,
			0,
			0
		],
		jars: [],
		fitness: 0,
		slots: [],
		returned: 0,
		sets: 0,
		spooked: !1,
		bonus: !1
	})), o = y.flatMap((e) => Array.from({ length: 12 }, (t, n) => ({
		id: `${e}-${n}`,
		color: e,
		room: -1
	}))), s = {
		humans: t,
		order: i,
		players: a,
		guests: o,
		pieces: [],
		locked: [
			...i.length === 2 ? [6] : [],
			...i.length <= 3 ? [3] : [],
			...i.length <= 4 ? [11] : []
		],
		bag: o.map((e) => e.id),
		tickets: [],
		tombRoom: null,
		futures: [],
		phase: "draft",
		turn: 0,
		round: 1,
		revision: 0,
		rngCursor: 0,
		seed: n,
		queue: t.map((e) => ({
			k: "draft",
			who: e
		})),
		pending: null,
		focus: {},
		endRound: !1,
		last: null,
		autoDecks: [],
		autoDiscard: [
			[],
			[],
			[]
		],
		autoCards: [],
		difficulty: r.difficulty
	};
	K(s, n, s.bag), s.tickets = K(s, n, [
		4,
		4,
		5,
		5,
		6,
		6,
		7,
		7,
		8,
		8
	]).slice(0, i.length * 2), s.queue.push({
		k: "prepare",
		who: t[0]
	});
	let c = [];
	return ke(s, c, n), {
		state: s,
		fx: c
	};
}
function Z(e, t, n, r) {
	e.pieces.push({
		id: `${t}:${r}`,
		owner: n == "animatronic" ? "" : t,
		kind: n,
		room: -1
	});
}
function Ce(e, t) {
	let n = j(e, t), r = {
		k: "",
		who: t
	}, i = n.monster;
	if (t === "@killtron") return Z(e, t, "monster", "main"), e.focus[t] = `${t}:main`, [z(r, "putPiece", {
		piece: e.focus[t],
		to: 4
	})];
	let a = i === "wolfpack" ? "wolf" : i === "regoo" ? "blob" : i === "deadLine" ? "phone" : "monster", o = i === "wolfpack" ? 4 : i === "regoo" ? 10 : i === "deadLine" ? 8 : 1;
	for (let n = 0; n < o; n++) Z(e, t, a, n === 0 && o === 1 ? "main" : String(n));
	e.focus[t] = F(e, t)[0].id, n.deck = [...C, ...S(i).cards], i === "killtron" && (n.program = [
		"guidance",
		"rollOut",
		"grapple"
	], n.deck = n.deck.filter((e) => !n.program.includes(e)));
	let s = [];
	if (i === "doctor" && [
		0,
		1,
		2,
		3,
		...e.order.length >= 4 ? [1] : [],
		...e.order.length === 5 ? [2] : []
	].forEach((n, i) => {
		Z(e, t, `trap${n}`, `trap${i}`), s.push(z(r, "placeMarker", {
			piece: `${t}:trap${i}`,
			filter: "trapsUnique"
		}));
	}), i === "grimhive") {
		for (let n = 0; n < 6; n++) Z(e, t, "hive", `hive${n}`);
		s.push(z(r, "placeMarker", {
			piece: `${t}:hive0`,
			filter: "hivesUnique"
		}), z(r, "placeMarker", {
			piece: `${t}:hive1`,
			filter: "hivesUnique"
		}));
	}
	if (i === "angler") {
		for (let n = 0; n < 7; n++) Z(e, t, "door", `door${n}`);
		s.push(z(r, "newDoor"), z(r, "newDoor", { flag: !0 }));
	}
	if (i === "chef") for (let n = 0; n < 6; n++) Z(e, t, `dish${n}`, `dish${n}`);
	if (i === "host") {
		for (let n = 0; n < re.filter((t) => !e.players.some((e) => e.monster === t.id)).length; n++) Z(e, t, "animatronic", `anim${n}`);
		for (let n = 0; n < 5 - e.order.length; n++) s.push(z(r, "placeMarker", {
			piece: `${t}:anim${n}`,
			filter: "animUnique"
		}));
	}
	if (i === "eagle") {
		let t = e.order.length >= 4 ? 9 : 7;
		for (let n = 0; n < t; n++) e.guests.push({
			id: `team-${n}`,
			color: "white",
			room: -3
		}), s.push(z(r, "placeTeam", { target: `team-${n}` }));
	}
	return i === "mummy" && s.push(z(r, "tombPlace")), i === "wolfpack" ? s.push(z(r, "wolfPlace", { filter: "different" }), z(r, "wolfPlace", { filter: "different" })) : i === "deadLine" ? (n.slots = F(e, t).slice(1).map((e) => e.id), s.push(z(r, "placeSelf"))) : s.push(z(r, "placeSelf", { filter: i === "angler" ? "exposed" : i === "mummy" ? "tombHost" : void 0 })), i === "outlander" && s.push(z(r, "devour")), i === "beasts" && s.push(z(r, "futureAdjust")), s.push(z(r, "shuffleDeck"), z(r, "draw", { n: 3 })), s;
}
function we(e, t) {
	let n = j(e, t), r = {
		who: t,
		k: ""
	}, i = [], a = n.monster;
	if (n.sets = 0, n.spooked = !1, n.bonus = !1, n.returned = 0, a === "wolfpack" && i.push(z(r, "wolfAbilities")), a === "mummy" && i.push(z(r, "unseal")), a === "outlander" && i.push(z(r, "posse")), a === "regoo" && i.push(z(r, "blobConsume")), a === "chef" && i.push(z(r, "mayServe")), [
		"wolfpack",
		"regoo",
		"deadLine"
	].includes(a) && i.push(z(r, "focus")), a === "killtron") i.push(z(r, "executeProgram"), z(r, "updateProgram"));
	else {
		i.push(z(r, a === "host" ? "hostPlay" : "play")), a === "listener" && i.push(z(r, "play"));
		let e = {
			beasts: "futureEvaluate",
			charles: "charlesDevour",
			deadLine: "answer",
			devil: "afterMoveLaunch",
			doctor: "mayTrap",
			doombox: "mayTrack",
			angler: "rise",
			grimhive: "harvest",
			chef: "mayPrepare",
			car: "passenger",
			nightslayerr: "mosh",
			regoo: "grow",
			remover: "fitness"
		};
		e[a] && a !== "devil" && i.push(z(r, e[a])), a === "remover" && i.push(z(r, "fitnessAdvance")), a === "beasts" && i.push(z(r, "draw", { n: -2 })), a === "deadLine" ? i.push(z(r, "phonePlace")) : a === "angler" ? i.push(z(r, "placeSelf", { filter: "exposed" })) : a === "wolfpack" ? i.push(z(r, "wolfMoves")) : a === "nightslayerr" ? i.push(z(r, "nightMove")) : a === "grimhive" ? i.push(z(r, "hiveMove")) : a !== "regoo" && i.push(z(r, "move")), a === "devil" && i.push(z(r, "launch")), a === "charles" && i.push(z(r, "moveFigure", { filter: "other" })), a === "mummy" && i.push(z(r, "mummyExtraMove")), a === "eagle" && i.push(z(r, "spook", { filter: "team" })), i.push(z(r, "draw", { n: -2 })), a === "beasts" && i.push(z(r, "futureAdjust")), ["wolfpack", "regoo"].includes(a) && i.push(z(r, "setGrowth"));
	}
	return i.push(z(r, "endTurn")), i;
}
function Te(e, t, n) {
	let r = e.guests.find((e) => e.id === n.target) ?? M(e, n.target ?? n.piece ?? "");
	if (!r || n.to === void 0 || n.to === 12 && !("color" in r) && P(r) && j(e, r.owner)?.monster !== "mummy") return;
	let i = r.room;
	if ("color" in r && n.to === -10) {
		let t = e.players.find((e) => e.monster === "angler");
		t && B(e, [{
			k: "eat",
			who: t.rid,
			target: r.id
		}]);
	} else r.room = n.to;
	q(e, t, i < 0 ? "place" : "move", n, {
		room: i,
		to: n.to,
		piece: r.id,
		..."color" in r ? { color: r.color } : {
			pieceKind: r.kind,
			monster: j(e, r.owner)?.monster,
			playerIndex: e.players.findIndex((e) => e.rid === r.owner)
		}
	}), !("color" in r) && r.room !== i && r.owner === e.order[e.turn] && j(e, r.owner)?.monster === "mummy" && j(e, r.owner).jars.includes(2) && B(e, [{
		k: "mummyEntry",
		who: r.owner,
		piece: r.id
	}]);
}
function Ee(e, t, n) {
	let r = e.guests.filter((r) => r.room === n && (r.color !== "white" || j(e, t.who).monster === "eagle") && (!t.color || r.color === t.color));
	return r.filter((e, t) => r.findIndex((t) => t.color === e.color) === t).map((e) => J(b[e.color], [z(t, "eat", { target: e.id })], {
		color: e.color,
		room: n,
		piece: e.id,
		key: "devour"
	}));
}
function De(e, t) {
	let n = j(e, t.who), r = n.pile.filter((t) => N(e, t).color === "white"), i = [];
	for (let a = 0; a < 32; a++) {
		let o = [], s = 0, c = !0;
		if (y.forEach((t, i) => {
			let l = a & 1 << i ? r[s++] : n.pile.find((n) => N(e, n).color === t);
			l ? o.push(l) : c = !1;
		}), c && s <= r.length) {
			let n = o.map((t) => b[N(e, t).color]);
			i.push(J(v(n.map((e) => e.zh).join("、"), n.map((e) => e.en).join(", ")), [z(t, "returnSet", { ids: o })], { key: "set" }));
		}
	}
	Y(e, t, "set", v("选择交回的一组观众。", "Choose the set to turn in."), i);
}
function Q(e, t, n, r = "moveFigure", i) {
	return n.flatMap((n) => W(e, n).filter((e) => i === void 0 || e === i).map((e) => J(e === 12 ? v("移入陵墓", "Enter the Tomb") : e === -10 ? v("通过外侧门", "Use an outside door") : H(e), [z(t, "moveTo", {
		target: n.id,
		to: e
	}), ...t.n ? [z(t, "score", { n: t.n })] : []], {
		key: r,
		room: e,
		piece: n.id,
		..."color" in n ? { color: n.color } : { target: n.owner }
	})));
}
function Oe(e, t) {
	let n = R(e, t), r = U(e, n).map((e) => ({
		id: `room:${e}`,
		to: e
	}));
	e.pieces.filter((e) => e.kind === "door" && e.room === n).forEach((e) => r.push({
		id: e.id,
		to: -10
	}));
	let i = [], a = t.used ?? [], o = e.guests.filter((e) => e.room === n && (t.filter !== "team" || e.color === "white")), s = [...o.filter((e, t) => o.findIndex((t) => t.color === e.color) === t), ...j(e, t.who).monster === "charles" && t.filter !== "team" ? e.pieces.filter((e) => P(e) && e.room === n && e.owner !== t.who) : []];
	for (let n of s) for (let o of r) {
		let r = a.includes(o.id);
		if (r && (!t.flag || !t.n || a.filter((e) => e === o.id).length >= 2) || !W(e, n).includes(o.to)) continue;
		let s = o.to === 12 ? v("陵墓", "Tomb") : o.to === -10 ? v("外侧", "Outside") : x[o.to].name;
		i.push(J(s, [
			z(t, "moveTo", {
				target: n.id,
				to: o.to
			}),
			z(t, "score", { n: t.slot ?? 1 }),
			{
				...t,
				used: [...a, o.id],
				n: r ? 0 : t.n
			}
		], {
			key: "spook",
			room: o.to,
			piece: n.id,
			..."color" in n ? { color: n.color } : { target: n.owner }
		}));
	}
	if (!i.length) {
		j(e, t.who).monster === "mummy" && j(e, t.who).jars.includes(3) && B(e, [z(t, "score", { n: 2 })]);
		return;
	}
	Y(e, t, "spook", v("惊吓：为观众选择尚可使用的门。", "Spook: choose a figure and an available door."), i, n);
}
function ke(e, t, n) {
	for (let r = 0; r < 200 && e.queue.length && !e.pending && !t.length && e.phase !== "done"; r++) Ae(e, t, e.queue.shift(), n);
}
function Ae(e, t, n, r) {
	let i = j(e, n.who), a = R(e, n);
	switch (n.k) {
		case "draft":
			Y(e, n, "draft", v("选择本局怪物。", "Choose your monster."), re.filter((t) => !e.players.some((e) => e.monster === t.id)).map((e) => J(v(e.name, e.name), [z(n, "setMonster", { target: e.id })], {
				key: "monster",
				target: e.id
			})));
			break;
		case "setMonster":
			i.monster = n.target;
			break;
		case "prepare": {
			e.phase = "setup";
			let t = V(e).map((e) => z(n, "add", {
				room: e,
				n: x[e].doors.length - 1
			}));
			e.order.forEach((n) => {
				t.push(...Ce(e, n));
			}), e.order.includes("@killtron") && (e.autoDecks = [
				[
					"grapple",
					"rollOut",
					"jumpscare"
				],
				[
					"mash",
					"search",
					"arcLightning"
				],
				[
					"haunt",
					"exterminate",
					"consume"
				]
			].map((t) => K(e, r, t))), t.push(z(n, "begin")), B(e, t);
			break;
		}
		case "begin":
			e.phase = "play", B(e, [{
				k: "startTurn",
				who: e.order[0]
			}]);
			break;
		case "startTurn":
			n.who === "@killtron" ? (e.autoCards = e.autoDecks.map((t, n) => (t.length || (e.autoDecks[n] = K(e, r, e.autoDiscard[n]), e.autoDiscard[n] = []), e.autoDecks[n].shift())), e.autoCards.forEach((t, n) => e.autoDiscard[n].push(t)), B(e, [...e.autoCards.map((e) => z(n, "cardEffect", { card: e })), z(n, "endTurn")]), q(e, t, "autoReveal", n)) : B(e, we(e, n.who));
			break;
		case "endTurn":
			if (e.turn === e.order.length - 1 && e.endRound) {
				e.phase = "done", q(e, t, "finale", n);
				break;
			}
			e.turn = (e.turn + 1) % e.order.length, e.turn || e.round++, B(e, [{
				k: "startTurn",
				who: e.order[e.turn]
			}]), q(e, t, "turn", {
				k: "",
				who: e.order[e.turn]
			});
			break;
		case "shuffleDeck":
			K(e, r, i.deck);
			break;
		case "draw":
			xe(e, t, n, r);
			break;
		case "add": {
			if (a === 12) break;
			let r = e.bag.splice(0, n.n ?? 1);
			r.forEach((t) => {
				N(e, t).room = a;
			}), r.length && q(e, t, "add", n, {
				room: a,
				n: r.length
			});
			break;
		}
		case "score":
			ye(e, t, n, n.target ?? n.who, n.n ?? 1);
			break;
		case "steal": {
			let r = j(e, n.target);
			if (!r || r.rid === n.who) break;
			let i = Math.min(r.score, n.n ?? 1);
			r.score -= i, ye(e, t, n, n.who, i);
			break;
		}
		case "stealAll":
			B(e, ve(e, n.who, n.filter === "nearby" ? [a, ...U(e, a)] : n.filter === "exposed" ? e.pieces.filter((e) => e.kind === "door" && e.room >= 0).map((e) => e.room) : [a]).map((e) => z(n, "steal", {
				target: e.rid,
				n: n.n
			})));
			break;
		case "stealOne":
			Y(e, n, "steal", v("选择偷取分数的对象。", "Choose a player to steal from."), ve(e, n.who, [a]).map((e) => J(v("偷取分数", "Steal points"), [z(n, "steal", {
				target: e.rid,
				n: n.n
			})], {
				key: "steal",
				target: e.rid,
				n: Math.min(e.score, n.n ?? 1)
			})), a);
			break;
		case "discardHand":
			i.discard.push(...i.hand), i.hand = [], q(e, t, "discard", n);
			break;
		case "play":
			if (n.who === "@killtron" || i.monster === "killtron" && !n.flag) break;
			Y(e, n, "play", v("打出一张手牌。", "Play a card from your hand."), i.hand.map((e) => J(v("", ""), [z(n, "playCard", { card: e })], {
				key: "card",
				card: e
			})), a);
			break;
		case "playCard": {
			let r = i.hand.indexOf(n.card);
			if (r < 0) break;
			i.hand.splice(r, 1), B(e, [z(n, "cardEffect"), z(n, "discardCard", { card: n.card })].map((e) => ({
				...e,
				card: n.card
			}))), q(e, t, "card", n, {
				card: n.card,
				room: a
			});
			break;
		}
		case "discardCard":
			i.discard.push(n.card);
			break;
		case "cardEffect":
			je(e, n);
			break;
		case "focus":
			Y(e, n, "focus", v("选择本回合的行动怪物。", "Choose the monster to act through this turn."), I(e, n.who).map((e) => J(v("选择怪物", "Choose monster"), [z(n, "setFocus", { target: e.id })], {
				key: "focus",
				piece: e.id,
				room: e.room
			})));
			break;
		case "setFocus":
			e.focus[n.who] = n.target;
			break;
		case "placeSelf": {
			let t = n.filter === "exposed" ? V(e).filter((t) => e.pieces.some((e) => e.kind === "door" && e.room === t)) : n.filter === "tombHost" ? [e.tombRoom] : [...V(e), ...i.monster === "mummy" && e.tombRoom !== null ? [12] : []];
			Y(e, n, "place", v("选择放置怪物的房间。", "Choose a room for your monster."), be(e, n, t, "putPiece", { piece: L(e, n)?.id }));
			break;
		}
		case "placeMarker": {
			let t = M(e, n.piece).kind, r = V(e).filter((r) => !e.pieces.some((e) => e.room === r && (n.filter === "trapsUnique" ? e.kind.startsWith("trap") : n.filter === "hivesUnique" ? e.kind === "hive" : n.filter === "animUnique" && e.kind === t)));
			Y(e, n, "marker", v("选择组件的房间。", "Choose a room for this component."), be(e, n, r, "putPiece", { piece: n.piece }));
			break;
		}
		case "putPiece":
			Te(e, t, {
				...n,
				target: n.piece
			});
			break;
		case "moveTo":
			Te(e, t, n);
			break;
		case "move": {
			let t = L(e, n);
			t && Y(e, n, "move", v("通过一扇门移动怪物。", "Move your monster through one door."), Q(e, n, [t], "move"), a);
			break;
		}
		case "moveFigure": {
			let t = G(e, a).filter((t) => n.filter !== "other" || t.id !== L(e, n)?.id);
			n.filter === "guest" && (t = t.filter((e) => "color" in e)), Y(e, n, "moveFigure", v("选择棋子和目的房间。", "Choose a figure and a destination."), Q(e, n, t), a);
			break;
		}
		case "pull": {
			let t = (n.to === void 0 ? U(e, a) : [n.to]).flatMap((t) => G(e, t)).filter((e) => n.filter !== "guest" || "color" in e);
			Y(e, n, "pull", v("从相邻房间拉入一枚棋子。", "Pull a figure from an adjacent room."), Q(e, n, t, "pull", a), a);
			break;
		}
		case "spook":
			i.spooked = !0, q(e, t, "spook", n, { room: a }), B(e, [z(n, "spookStep", {
				room: a,
				filter: n.filter,
				used: [],
				flag: n.flag,
				n: +!!n.flag,
				slot: n.slot
			})]);
			break;
		case "spookStep":
			Oe(e, n);
			break;
		case "devour": {
			if ((n.n ?? 1) < 1) break;
			let t = Ee(e, n, a);
			t.forEach((e) => {
				(n.n ?? 1) > 1 && e.effects.push({
					...n,
					n: n.n - 1
				});
			}), Y(e, n, "devour", v("选择吞噬的观众。", "Choose a guest to devour."), t, a);
			break;
		}
		case "eat": {
			let r = N(e, n.target);
			if (!r || r.color === "white" && i.monster !== "eagle") break;
			let a = r.room;
			r.room = -2, i.pile.push(r.id), q(e, t, "devour", n, {
				room: a,
				piece: r.id,
				color: r.color
			}), B(e, [z(n, "checkSet")]), r.color === "white" && !e.guests.some((e) => e.color === "white" && e.room >= 0) && B(e, [z(n, "score", { n: 10 })]);
			break;
		}
		case "checkSet":
			De(e, n);
			break;
		case "returnSet": {
			let a = n.ids;
			i.pile = i.pile.filter((e) => !a.includes(e)), i.seats = i.seats.filter((e) => !a.includes(e));
			for (let t of a) {
				let n = N(e, t);
				n.room = n.color === "white" ? -3 : -1, n.color !== "white" && e.bag.push(t);
			}
			K(e, r, e.bag), i.sets++;
			let o = e.tickets.shift();
			o === void 0 ? B(e, [z(n, "score", { n: 5 })]) : i.tickets.push(o), e.tickets.length || (e.endRound = !0), q(e, t, "set", n), B(e, [z(n, "refill")]);
			break;
		}
		case "refill": {
			let t = V(e), r = Math.min(...t.map((t) => G(e, t).length));
			Y(e, n, "refill", v("向棋子最少的房间补入三名观众。", "Add three guests to a room with the fewest figures."), t.filter((t) => G(e, t).length === r).map((e) => J(H(e), [z(n, "add", {
				room: e,
				n: 3
			})], {
				key: "refill",
				room: e
			})));
			break;
		}
		default: Me(e, t, n, r);
	}
}
function je(e, t) {
	let n = R(e, t), r = j(e, t.who), i = [], a = (e, n = {}) => i.push(z(t, e, n));
	switch (t.card) {
		case "jumpscare":
		case "overdrive":
			a("move"), a("play");
			break;
		case "consume":
			[...y, "white"].forEach((e) => a("devour", { color: e }));
			break;
		case "haunt":
			a("spook"), a("spook");
			break;
		case "mash":
			a("mash");
			break;
		case "search":
			a("add", { n: 3 }), a("play");
			break;
		case "teamExercise":
			a("pointsChoice", { filter: "roomAll" }), a("draw", { n: 3 });
			break;
		case "accounting":
			a("pointsChoice"), a("play");
			break;
		case "violentMarkets":
			a("futureEither");
			break;
		case "clownCar":
			a("add", { n: 3 }), a("spook");
			break;
		case "pie":
			a("stealOne", { n: 3 }), a("spook");
			break;
		case "switcheroo":
			a("swapSelf"), a("play");
			break;
		case "openLines":
			a("phonePlace"), a("phonePlace");
			break;
		case "robocalls":
		case "imHere":
			I(e, t.who).forEach((e) => a(t.card === "robocalls" ? "stealOne" : "devour", {
				room: e.room,
				n: t.card === "robocalls" ? 2 : 1
			}));
			break;
		case "replayAward":
			U(e, n).filter((e) => e !== 12).forEach((e) => a("add", {
				room: e,
				n: 1
			}));
			break;
		case "bonusRound":
			a("setBonus");
			break;
		case "kickback":
			a("kickback");
			break;
		case "zappyZaps":
			a("triggerTrap");
			break;
		case "renovations":
			a("renovate"), a("play");
			break;
		case "klaxxon":
			e.pieces.filter((e) => e.owner === t.who && e.kind.startsWith("trap") && e.room >= 0).forEach((e) => a("moveFigure", { room: e.room }));
			break;
		case "remix":
			a("remix");
			break;
		case "crankIt":
			a("track");
			break;
		case "flood":
			a("discardHand"), a("spook");
			break;
		case "chomp":
			a("newDoor", { n: 2 });
			break;
		case "lanternGlow":
			a("pullEach");
			break;
		case "swarm":
			a("move"), a("hivePlace"), a("play");
			break;
		case "pheromones":
		case "temptation":
			e.pieces.filter((e) => e.owner === t.who && e.kind === "hive" && e.room >= 0).forEach((e) => a(t.card === "pheromones" ? "moveFigure" : "devour", { room: e.room })), t.card === "pheromones" && a("play");
			break;
		case "appetizer":
			a("serve", { flag: !0 });
			break;
		case "seconds":
			a("devour"), a("prepareDish");
			break;
		case "iconsOfTerror":
			a("animPlace");
			break;
		case "look":
			a("move"), a("introduce");
			break;
		case "spooktacular":
			a("tripleSpook");
			break;
		case "dogpile":
		case "packHunt":
		case "howling":
			I(e, t.who).forEach((e) => {
				a(t.card === "dogpile" ? "dogpile" : t.card === "packHunt" ? "devour" : "howling", { room: e.room });
			});
			break;
		case "mowDown":
			a("mow");
			break;
		case "getIn":
			a("passenger");
			break;
		case "guidance":
			a("guidance", { slot: t.slot });
			break;
		case "rollOut":
			a("move");
			break;
		case "grapple":
			a("pull");
			break;
		case "exterminate":
			a("spook");
			break;
		case "arcLightning":
			a("stealAll", {
				filter: "nearby",
				n: 1
			});
			break;
		case "relocateTomb":
			a("tombPlace", { flag: !0 });
			break;
		case "drag":
			a("drag");
			break;
		case "shred":
			a("draw", { n: -2 }), a("play");
			break;
		case "chainLight":
		case "abduct":
			for (let e = 0; e < 3; e++) a("move"), a("devour");
			break;
		case "callOut":
			a("adjacentDevour"), a("play");
			break;
		case "sing":
		case "coaching":
		case "partyHard":
			a("pullEach", {
				filter: "guest",
				n: 1
			});
			break;
		case "pose":
			a("score", { n: 1 }), a("play");
			break;
		case "gangUp":
			a("stealOne", { n: new Set(r.pile.map((t) => N(e, t).color)).size });
			break;
		case "mosey":
			a("mosey"), a("play");
			break;
		case "squelch":
		case "blurp":
			I(e, t.who).forEach((e) => a(t.card === "squelch" ? "move" : "devour", {
				piece: e.id,
				room: void 0
			}));
			break;
		case "schlorp":
			a("grow");
			break;
		case "flex":
			a("fitness");
			break;
		case "dumbStunt":
			a("dumbStunt");
			break;
		case "accomplice":
			a("swapSelf", { filter: "team" }), a("play");
			break;
		case "emergence":
			a("devour", { n: 3 }), a("discardHand"), a("draw", { n: 1 });
			break;
		case "skittering":
			a("move"), a("draw", { n: 1 });
			break;
		case "nudge":
			a("moveFigure"), a("draw", { n: 1 });
			break;
		case "bump":
			a("pull"), a("draw", { n: 1 });
			break;
		case "listen": a("stealOne", { n: 3 });
	}
	B(e, i);
}
function Me(e, t, n, r) {
	let i = j(e, n.who), a = R(e, n), o = (t) => e.pieces.filter((e) => e.id.startsWith(`${n.who}:`) && e.kind === t), s = L(e, n);
	switch (n.k) {
		case "charlesDevour":
			i.spooked && B(e, [z(n, "devour", { n: e.guests.filter((e) => e.room === a).length })]);
			break;
		case "setBonus":
			i.bonus = !0;
			break;
		case "kickback": {
			let r = [...i.pile];
			i.pile = [], r.forEach((t) => {
				N(e, t).room = a;
			}), r.length && (q(e, t, "add", n, {
				room: a,
				n: r.length
			}), B(e, [z(n, "score", { n: r.length })]));
			break;
		}
		case "adjacentDevour":
			Y(e, n, "room", v("选择相邻房间进行吞噬。", "Choose an adjacent room to devour in."), U(e, a).filter((t) => Ee(e, n, t).length).map((e) => J(e === 12 ? v("陵墓", "Tomb") : H(e), [z(n, "devour", { room: e })], {
				key: "devourRoom",
				room: e
			})));
			break;
		case "pullEach":
			B(e, U(e, a).map((e) => z(n, "pull", {
				room: a,
				to: e,
				filter: n.filter,
				n: n.n
			})));
			break;
		case "swapSelf": {
			if (!s) break;
			let t = n.filter === "team" ? e.guests.filter((e) => e.color === "white" && e.room >= 0) : U(e, a).flatMap((t) => G(e, t));
			Y(e, n, "swap", v("选择交换位置的棋子。", "Choose a figure to switch places with."), t.filter((t) => t.id !== s.id && (n.filter === "team" ? t.room !== 12 : W(e, t).includes(a)) && (t.room !== 12 || i.monster === "mummy")).map((e) => J(v("交换位置", "Switch places"), [z(n, "swap", {
				piece: s.id,
				target: e.id
			})], {
				key: "swap",
				piece: e.id,
				room: e.room
			})), a);
			break;
		}
		case "swap": {
			let t = M(e, n.piece) ?? e.guests.find((e) => e.id === n.piece), r = M(e, n.target) ?? e.guests.find((e) => e.id === n.target);
			if (!t || !r) break;
			let i = t.room, a = r.room;
			B(e, [z(n, "moveTo", {
				target: t.id,
				to: a
			}), z(n, "moveTo", {
				target: r.id,
				to: i
			})]);
			break;
		}
		case "mash": {
			let t = e.pieces.filter((e) => P(e) && e.room === a), r = new Set(t.filter((t) => j(e, t.owner) && W(e, t).length).map((e) => e.owner));
			B(e, [...t.map((e) => z(n, "mashMove", { piece: e.id })), z(n, "score", { n: r.size * 2 })]);
			break;
		}
		case "mashMove": {
			let t = M(e, n.piece);
			t && Y(e, n, "mashMove", v("为怪物选择目的房间。", "Choose a destination for the monster."), Q(e, n, [t], "mashMove"), t.room);
			break;
		}
		case "mow": {
			let t = G(e, a), r = [...new Set(t.flatMap((t) => W(e, t)))];
			Y(e, n, "mow", v("选择所有棋子通过的同一扇门。", "Choose one door for all figures."), r.map((r) => {
				let i = t.filter((t) => W(e, t).includes(r));
				return J(r === 12 ? v("陵墓", "Tomb") : r === -10 ? v("外侧", "Outside") : H(r), [...i.map((e) => z(n, "moveTo", {
					target: e.id,
					to: r
				})), z(n, "score", { n: i.length })], {
					key: "mow",
					room: r,
					n: i.length
				});
			}), a);
			break;
		}
		case "pointsChoice": {
			let t = n.filter === "roomAll" ? e.players.filter((t) => I(e, t.rid).some((e) => e.room === a)) : e.players;
			if (n.filter === "roomAll") {
				B(e, t.map((e) => z(n, "pointPlayer", { target: e.rid })));
				break;
			}
			Y(e, n, "points", v("选择玩家并调整其分数。", "Choose a player and adjust their score."), t.flatMap((e) => [-1, 1].map((t) => J(t > 0 ? v("获得 1 分", "Gain one point") : v("失去 1 分", "Lose one point"), [z(n, "score", {
				target: e.rid,
				n: t
			})], {
				key: "points",
				target: e.rid,
				n: t
			}))));
			break;
		}
		case "pointPlayer":
			Y(e, n, "points", v("决定该玩家获得或失去 1 分。", "Choose whether this player gains or loses one point."), [-1, 1].map((e) => J(e > 0 ? v("获得 1 分", "Gain one point") : v("失去 1 分", "Lose one point"), [z(n, "score", {
				target: n.target,
				n: e
			})], {
				key: "points",
				target: n.target,
				n: e
			})));
			break;
		case "futureEither":
			Y(e, n, "future", v("选择惊吓期货行动。", "Choose a Spook Futures action."), [J(v("调整期货", "Adjust Futures"), [z(n, "futureAdjust")]), J(v("评估期货", "Evaluate Futures"), [z(n, "futureEvaluate")])]);
			break;
		case "futureAdjust": {
			let t = [];
			T.forEach((r, i) => {
				for (let a = 0; a <= 50; a++) {
					let o = a + r.span - 1, s = (e) => e <= 12 ? 0 : e <= 25 ? 1 : e <= 38 ? 2 : 3;
					o > 50 || s(a) !== s(o) || e.futures.some((e) => (e.owner !== n.who || e.kind !== i) && a <= e.start + T[e.kind].span - 1 && o >= e.start) || t.push(J(v(`${r.name.zh}：${a}${o > a ? `—${o}` : ""} 分`, `${r.name.en}: ${a}${o > a ? `–${o}` : ""} points`), [z(n, "futureSet", {
						slot: i,
						n: a
					})], {
						key: "future",
						n: a,
						target: String(i)
					}));
				}
			}), Y(e, n, "futureAdjust", v("选择一枚期货及覆盖的计分格。", "Choose a Future and the score spaces it covers."), t);
			break;
		}
		case "futureSet":
			e.futures = e.futures.filter((e) => e.owner !== n.who || e.kind !== n.slot), e.futures.push({
				owner: n.who,
				kind: n.slot,
				start: n.n
			}), q(e, t, "future", n, { n: n.n });
			break;
		case "futureEvaluate":
			B(e, [...e.order.slice(e.order.indexOf(n.who)), ...e.order.slice(0, e.order.indexOf(n.who))].map((e) => z(n, "futurePlayer", { target: e })));
			break;
		case "futurePlayer": {
			let t = j(e, n.target), r = e.futures.filter((e) => t.score >= e.start && t.score < e.start + T[e.kind].span);
			Y(e, n, "futureEffect", v("选择该玩家触发的期货。", "Choose the Future this player triggers."), r.map((e) => {
				let n = T[e.kind];
				return J(n.name, [{
					k: n.effect === "lose" ? "score" : n.effect,
					who: t.rid,
					n: n.effect === "lose" ? -n.n : n.n
				}], {
					key: "futureEffect",
					target: t.rid
				});
			}));
			break;
		}
		case "fitness": {
			let t = i.fitness;
			B(e, [
				[],
				[z(n, "draw", { n: 3 })],
				[z(n, "add", { n: 2 }), z(n, "score", { n: 2 })],
				[z(n, "spook")],
				[z(n, "devour", { n: e.guests.filter((e) => e.room === a).length })],
				[z(n, "stealAll", {
					filter: "nearby",
					n: 1
				})],
				[z(n, "add", { n: 3 }), z(n, "score", { n: 3 })],
				[z(n, "spook", { flag: !0 })],
				[z(n, "score", { n: G(e, a).length })],
				[z(n, "draw", { n: -1 })],
				[z(n, "placeSelf")],
				[z(n, "spook"), z(n, "spook")],
				[z(n, "stealAll", {
					filter: "nearby",
					n: 2
				})],
				[z(n, "fitnessReset"), z(n, "score", { n: 10 })]
			][t] ?? []);
			break;
		}
		case "fitnessReset":
			i.fitness = 0, q(e, t, "fitness", n, { n: 0 });
			break;
		case "fitnessAdvance":
			Y(e, n, "fitness", v("让哑铃前进一格或两格。", "Advance the dumbbell one or two spaces."), [1, 2].filter((e) => i.fitness + e <= 13).map((e) => J(v(`前进 ${e} 格`, `Advance ${e} space${e > 1 ? "s" : ""}`), [z(n, "fitnessSet", { n: i.fitness + e })], {
				key: "fitness",
				n: i.fitness + e
			})));
			break;
		case "fitnessSet":
			i.fitness = n.n, q(e, t, "fitness", n, { n: n.n });
			break;
		case "wolfPlace": {
			let t = F(e, n.who).filter((e) => e.room < 0).flatMap((t) => V(e).filter((t) => n.filter !== "different" || !I(e, n.who).some((e) => e.room === t)).map((e) => J(v(O[Number(t.id.split(":").at(-1))], O[Number(t.id.split(":").at(-1))]), [z(n, "putPiece", {
				piece: t.id,
				to: e
			})], {
				key: "wolf",
				piece: t.id,
				room: e
			})));
			Y(e, n, "wolfPlace", v("选择一只狼人及其房间。", "Choose a werewolf and its room."), t);
			break;
		}
		case "wolfAbilities": {
			let t = F(e, n.who), r = [];
			t.forEach((t, i) => {
				if (t.room < 0) return;
				let a = {
					...n,
					room: void 0,
					piece: t.id
				};
				i || r.push(z(a, "score", { n: ve(e, n.who, [t.room]).length })), i === 1 && r.push(z(a, "moveFigure", { filter: "other" })), i === 2 && r.push(z(a, "move")), i === 3 && r.push(z(a, "draw", { n: 1 }));
			}), B(e, r);
			break;
		}
		case "wolfMoves":
			B(e, I(e, n.who).filter((e) => !e.id.endsWith(":2")).map((e) => z(n, "move", {
				piece: e.id,
				room: void 0
			})));
			break;
		case "dogpile": {
			let t = ve(e, n.who, [a]).flatMap((t) => t.pile.map((r) => J(b[N(e, r).color], [z(n, "takePile", {
				target: t.rid,
				ids: [r]
			})], {
				key: "takePile",
				target: t.rid,
				color: N(e, r).color
			})));
			Y(e, n, "dogpile", v("从本房另一名玩家的吞噬区取一名观众。", "Take a guest from another player’s devour pile in this room."), t, a);
			break;
		}
		case "takePile": {
			let r = j(e, n.target), o = n.ids[0];
			r.pile = r.pile.filter((e) => e !== o), i.pile.push(o), B(e, [z(n, "checkSet")]), q(e, t, "devour", n, {
				room: a,
				color: N(e, o).color
			});
			break;
		}
		case "howling":
			B(e, [z(n, "moveFigure", {
				filter: "guest",
				n: 1
			}), z(n, "moveFigure", {
				filter: "guest",
				n: 1
			})]);
			break;
		case "setGrowth":
			i.sets && B(e, [z(n, i.monster === "wolfpack" ? "wolfPlace" : "blobPlace", { filter: "any" })]);
			break;
		case "blobConsume":
			B(e, e.players.filter((e) => e.rid !== n.who).map((e) => z(n, "blobPlayer", { target: e.rid })));
			break;
		case "blobPlayer": {
			let t = [...new Set(I(e, n.target).map((e) => e.room))];
			Y(e, n, "blobConsume", v("选择对方所在的一个房间进行消化。", "Choose one room occupied by this player to consume in."), t.map((t) => {
				let r = I(e, n.who).filter((e) => e.room === t).length;
				return J(x[t]?.name ?? v("陵墓", "Tomb"), [z(n, "steal", {
					target: n.target,
					n: r
				})], {
					key: "steal",
					target: n.target,
					room: t,
					n: r
				});
			}));
			break;
		}
		case "grow":
		case "blobPlace": {
			let t = F(e, n.who).find((e) => e.room < 0);
			if (!t) {
				if (n.k !== "grow") break;
				X(e, n, v("所有黏液都已在场。是否移除一团再生长？", "All Blobs are placed. Remove one to grow again?"), [z(n, "removeBlob", { filter: n.filter })]);
				break;
			}
			let r = n.filter === "any" ? V(e) : [.../* @__PURE__ */ new Set([a, ...U(e, a)])].filter((e) => e !== 12);
			Y(e, n, "grow", v("选择放置新黏液的房间。", "Choose a room for the new Blob."), be(e, n, r, "putPiece", { piece: t.id }));
			break;
		}
		case "removeBlob":
			Y(e, n, "removeBlob", v("选择移除的黏液。", "Choose a Blob to remove."), I(e, n.who).map((e) => J(v("移除黏液", "Remove Blob"), [z(n, "putPiece", {
				piece: e.id,
				to: -1
			}), z(n, "blobPlace", {
				filter: n.filter,
				room: a
			})], {
				key: "remove",
				piece: e.id,
				room: e.room
			})));
			break;
		case "posse": {
			let t = [], r = [
				[z(n, "move")],
				[z(n, "pull")],
				[z(n, "add", { n: 2 }), z(n, "score", { n: 2 })],
				[z(n, "stealAll", { n: 1 })],
				[z(n, "score", { n: -2 }), z(n, "spook")]
			];
			y.forEach((n, a) => {
				i.pile.some((t) => N(e, t).color === n) && t.push(...r[a]);
			}), B(e, t);
			break;
		}
		case "mosey": {
			let t = e.guests.filter((e) => e.room === a && e.room !== 12);
			Y(e, n, "mosey", v("交换本房与吞噬区各一名观众。", "Swap a room guest with one from your devour pile."), i.pile.flatMap((r) => t.map((t) => J(v(`${b[N(e, r).color].zh} → ${b[t.color].zh}`, `${b[N(e, r).color].en} → ${b[t.color].en}`), [z(n, "moseySwap", {
				target: r,
				ids: [t.id],
				room: a
			})], {
				key: "mosey",
				color: t.color,
				piece: t.id
			}))), a);
			break;
		}
		case "moseySwap":
			i.pile = i.pile.filter((e) => e !== n.target), N(e, n.target).room = a, N(e, n.ids[0]).room = -2, i.pile.push(n.ids[0]), q(e, t, "devour", n, {
				room: a,
				color: N(e, n.ids[0]).color
			}), B(e, [z(n, "checkSet")]);
			break;
		case "mayServe":
			X(e, n, v("是否上菜？", "Serve a dish?"), [z(n, "serve")]);
			break;
		case "mayPrepare":
			X(e, n, v("是否备菜？", "Prepare a dish?"), [z(n, "prepareDish")]);
			break;
		case "prepareDish": {
			let t = e.pieces.filter((e) => e.owner === n.who && e.kind.startsWith("dish") && e.room < 0).flatMap((t) => [a, ...U(e, a)].map((e) => J(E[Number(t.kind.at(-1))], [z(n, "putPiece", {
				piece: t.id,
				to: e
			})], {
				key: "dish",
				piece: t.id,
				room: e
			})));
			Y(e, n, "prepare", v("选择一道菜及其房间。", "Choose a dish and its room."), t);
			break;
		}
		case "serve":
			Y(e, n, "serve", v("选择上菜的菜肴。", "Choose a dish to serve."), e.pieces.filter((e) => e.owner === n.who && e.kind.startsWith("dish") && e.room >= 0).map((e) => J(E[Number(e.kind.at(-1))], [...n.flag ? [] : [z(n, "putPiece", {
				piece: e.id,
				to: -1
			})], z(n, "dishEffect", {
				room: e.room,
				slot: Number(e.kind.at(-1))
			})], {
				key: "dish",
				piece: e.id,
				room: e.room
			})));
			break;
		case "dishEffect":
			B(e, [
				[z(n, "moveEvery")],
				[z(n, "placeMonster", { to: a })],
				[z(n, "stealAll", { n: 4 })],
				[z(n, "spook")],
				[z(n, "devour", { n: 3 })],
				[z(n, "add", { n: 5 })]
			][n.slot]);
			break;
		case "moveEvery":
			B(e, G(e, a).map((e) => z(n, "moveExact", {
				target: e.id,
				n: n.n
			})));
			break;
		case "moveExact": {
			let t = e.guests.find((e) => e.id === n.target) ?? M(e, n.target);
			t && Y(e, n, "moveFigure", v("选择棋子的目的房间。", "Choose a destination for this figure."), Q(e, n, [t]), t.room);
			break;
		}
		case "placeMonster": {
			let t = e.pieces.filter((e) => P(e) && e.room >= 0);
			Y(e, n, "placeMonster", v("选择怪物与放置房间。", "Choose a monster and a room."), t.flatMap((t) => (n.to === void 0 ? [...V(e), ...j(e, t.owner)?.monster === "mummy" && e.tombRoom !== null ? [12] : []] : [n.to]).filter((n) => n !== 12 || j(e, t.owner)?.monster === "mummy").map((e) => J(x[e]?.name ?? v("陵墓", "Tomb"), [z(n, "putPiece", {
				piece: t.id,
				to: e
			})], {
				key: "placeMonster",
				piece: t.id,
				room: e,
				target: t.owner
			}))));
			break;
		}
		case "hostPlay":
			Y(e, n, "hostPlay", v("直接打牌，或介绍相邻房的怪物。", "Play a card or introduce a monster in an adjacent room."), [J(v("打出手牌", "Play a card"), [z(n, "play")]), ...e.pieces.some((t) => P(t) && U(e, a).includes(t.room)) ? [J(v("介绍怪物", "Introduce a monster"), [z(n, "introduce")])] : []]);
			break;
		case "introduce":
			Y(e, n, "introduce", v("选择相邻房间的怪物。", "Choose a monster in an adjacent room."), e.pieces.filter((t) => P(t) && U(e, a).includes(t.room)).map((t) => J(v("介绍怪物", "Introduce monster"), [...t.owner !== n.who && j(e, t.owner) ? [z(n, "score", { n: 2 }), z(n, "score", {
				target: t.owner,
				n: 2
			})] : [], z(n, "play", {
				piece: t.id,
				room: void 0
			})], {
				key: "introduce",
				piece: t.id,
				room: t.room,
				target: t.owner
			})));
			break;
		case "animPlace": {
			let t = o("animatronic").find((e) => e.room < 0);
			if (!t) break;
			Y(e, n, "animPlace", v("在相邻房间放机械怪物并惊吓。", "Place an animatronic in an adjacent room and spook there."), U(e, a).filter((e) => e !== 12).map((e) => J(H(e), [z(n, "putPiece", {
				piece: t.id,
				to: e
			}), z(n, "spook", { room: e })], {
				key: "animPlace",
				room: e
			})));
			break;
		}
		case "tripleSpook":
			Y(e, n, "tripleSpook", v("选择至少有三只怪物的房间。", "Choose a room with at least three monsters."), V(e).filter((t) => e.pieces.filter((e) => P(e) && e.room === t).length >= 3).map((e) => J(H(e), [z(n, "spook", {
				room: e,
				slot: 3
			})], {
				key: "tripleSpook",
				room: e
			})));
			break;
		case "passenger": {
			let t = y.filter((t) => !i.seats.some((n) => N(e, n).color === t)), r = e.guests.filter((e) => e.room === a && t.includes(e.color));
			Y(e, n, "passenger", v("选择与空座同色的乘客。", "Choose a guest matching an empty seat."), r.filter((e, t) => r.findIndex((t) => t.color === e.color) === t).map((e) => J(b[e.color], [z(n, "seatPassenger", { target: e.id })], {
				key: "passenger",
				color: e.color,
				room: a
			})), a);
			break;
		}
		case "seatPassenger": {
			let r = N(e, n.target);
			r.room = -4, i.seats.push(r.id), B(e, [...{
				red: [z(n, "draw", { n: 3 })],
				purple: [z(n, "stealAll", { n: 2 })],
				yellow: [z(n, "move"), z(n, "devour")],
				blue: [z(n, "spook")],
				green: [z(n, "placeSelf")]
			}[r.color], z(n, "checkSeats")]), q(e, t, "passenger", n, {
				room: a,
				color: r.color,
				piece: r.id
			});
			break;
		}
		case "checkSeats":
			i.seats.length === 5 && B(e, [z(n, "returnSet", { ids: [...i.seats] }), z(n, "placeSelf")]);
			break;
		case "executeProgram":
			B(e, [
				0,
				1,
				2
			].map((e) => z(n, "programSlot", { slot: e })));
			break;
		case "programSlot": {
			let r = i.program[n.slot];
			r && (B(e, [z(n, "cardEffect", {
				card: r,
				slot: n.slot
			})]), q(e, t, "card", n, {
				card: r,
				room: a
			}));
			break;
		}
		case "updateProgram":
			Y(e, n, "program", v("选择放入程序左端的手牌。", "Choose a hand card for the left end of your program."), i.hand.map((e) => J(v("", ""), [z(n, "programUpdate", { card: e }), z(n, "draw", { n: -2 })], {
				key: "card",
				card: e
			})));
			break;
		case "programUpdate":
			i.discard.push(i.program.pop()), i.program.unshift(n.card), i.hand.splice(i.hand.indexOf(n.card), 1), q(e, t, "program", n, { card: n.card });
			break;
		case "guidance":
			Y(e, n, "guidance", v("选择立即替换制导系统的手牌。", "Choose a hand card to replace Guidance System now."), i.hand.map((e) => J(v("", ""), [z(n, "guidanceReplace", {
				card: e,
				slot: n.slot
			})], {
				key: "card",
				card: e
			})));
			break;
		case "guidanceReplace": {
			let r = n.slot ?? i.program.indexOf("guidance");
			if (r < 0) break;
			i.discard.push(i.program[r]), i.program[r] = n.card, i.hand.splice(i.hand.indexOf(n.card), 1), B(e, [z(n, "programSlot", { slot: r })]), q(e, t, "program", n, { card: n.card });
			break;
		}
		case "mayTrack":
			X(e, n, v("是否播放音轨？", "Play a track?"), [z(n, "track")]);
			break;
		case "track": {
			let t = Ee(e, n, a).filter((e) => e.color !== "white");
			t.forEach((e) => e.effects.push(z(n, "advanceTrack", { color: e.color }))), Y(e, n, "track", v("吞噬一名观众并推进同色音轨。", "Devour a guest and advance its matching track."), t, a);
			break;
		}
		case "remix":
			Y(e, n, "remix", v("选择前进一格的磁带。", "Choose a cassette to advance."), y.map((e) => J(b[e], [z(n, "advanceTrack", {
				color: e,
				flag: !0
			})], {
				key: "track",
				color: e
			})));
			break;
		case "advanceTrack": {
			let r = y.indexOf(n.color);
			i.tracks[r] = (i.tracks[r] + 1) % 5;
			let o = i.tracks[r];
			if (q(e, t, "track", n, {
				color: n.color,
				n: o
			}), n.flag || !o) break;
			r || B(e, [z(n, "add", { n: o + 1 }), z(n, "score", { n: o + 1 })]), r === 1 && B(e, [z(n, o === 2 ? "recover" : o === 3 ? "play" : "draw", { n: o === 4 ? -1 : 2 })]), r === 2 && B(e, [z(n, o === 2 ? "placeMonster" : o === 4 ? "moveEvery" : "placeSelf", { n: o === 4 ? 1 : void 0 })]), r === 3 && B(e, [z(n, "stealAll", { n: o + 1 })]), r === 4 && B(e, [z(n, "devour", { n: o === 4 ? e.guests.filter((e) => e.room === a).length : o })]);
			break;
		}
		case "recover":
			Y(e, n, "recover", v("从弃牌中回收一张牌。", "Recover a card from your discard pile."), [...new Set(i.discard)].map((e) => J(v("", ""), [z(n, "recoverCard", { card: e })], {
				key: "card",
				card: e
			})));
			break;
		case "recoverCard":
			i.discard.splice(i.discard.indexOf(n.card), 1), i.hand.push(n.card), q(e, t, "draw", n, { n: 1 });
			break;
		case "newDoor": {
			let t = o("door").find((e) => e.room < 0);
			if (!t) break;
			let r = V(e).filter((e) => x[e].edge && (!n.flag || !o("door").some((t) => t.room === e)));
			Y(e, n, "newDoor", v("选择朝向影院外侧的新门位置。", "Choose an outer room for the new door."), r.map((e) => J(H(e), [z(n, "putPiece", {
				piece: t.id,
				to: e
			}), ...n.n ? [z(n, "devour", {
				room: e,
				n: n.n
			})] : []], {
				key: "newDoor",
				room: e
			})));
			break;
		}
		case "rise": {
			let t = i.discard.length;
			t >= 1 && t <= 3 && B(e, [z(n, "newDoor")]), t === 4 && B(e, [z(n, "moveEvery", { n: 1 })]), t === 5 && Y(e, n, "exposedSpook", v("选择一个暴露房间进行惊吓。", "Choose an exposed room to spook."), [...new Set(o("door").filter((e) => e.room >= 0).map((e) => e.room))].map((e) => J(H(e), [z(n, "spook", { room: e })], {
				key: "spookRoom",
				room: e
			}))), t === 6 && B(e, [...new Set(o("door").filter((e) => e.room >= 0).map((e) => e.room))].map((e) => z(n, "add", {
				room: e,
				n: 2
			}))), t === 7 && B(e, [z(n, "stealAll", {
				filter: "exposed",
				n: 4
			})]);
			break;
		}
		case "harvest": {
			let t = o("hive").filter((e) => e.room >= 0), r = s?.room, i = [...new Set(t.map((e) => e.room))].filter((t) => t !== r && new Set(e.pieces.filter((e) => P(e) && e.room === t).map((e) => e.owner)).size === 1), a = new Set(e.pieces.filter((t) => P(t) && i.includes(t.room) && j(e, t.owner)).map((e) => e.owner));
			B(e, [z(n, "score", { n: t.length }), z(n, "score", { n: -a.size })]);
			break;
		}
		case "hivePlace": {
			let t = o("hive").find((e) => e.room < 0);
			t && B(e, [z(n, "putPiece", {
				piece: t.id,
				to: a
			})]);
			break;
		}
		case "hiveMove": {
			let t = s ? Q(e, n, [s], "move") : [];
			o("hive").filter((e) => e.room >= 0).forEach((e) => t.push(J(H(e.room), [z(n, "putPiece", {
				piece: s.id,
				to: e.room
			})], {
				key: "move",
				room: e.room,
				piece: s.id
			}))), Y(e, n, "move", v("移动，或把女王放在有蜂巢的房间。", "Move or place the Queen in a room with a hive."), t, a);
			break;
		}
		case "mayTrap":
			X(e, n, v("是否触发陷阱？", "Trigger a trap?"), [z(n, "triggerTrap")]);
			break;
		case "triggerTrap":
			Y(e, n, "trap", v("选择触发的陷阱。", "Choose a trap to trigger."), e.pieces.filter((e) => e.owner === n.who && e.kind.startsWith("trap") && e.room >= 0).map((e) => J(D[Number(e.kind.at(-1))], [z(n, "trapEffect", {
				room: e.room,
				slot: Number(e.kind.at(-1))
			})], {
				key: "trap",
				room: e.room,
				piece: e.id
			})));
			break;
		case "trapEffect":
			B(e, [
				[z(n, "spook")],
				[z(n, "devour")],
				[z(n, "trapSwap")],
				[z(n, "stealAll", { n: 2 })]
			][n.slot]);
			break;
		case "trapSwap": {
			let t = G(e, a).flatMap((t) => U(e, a).flatMap((r) => G(e, r).filter((n) => W(e, t).includes(n.room) && W(e, n).includes(t.room)).map((e) => J(v("交换棋子", "Switch figures"), [z(n, "swap", {
				piece: t.id,
				target: e.id
			})], {
				key: "swap",
				piece: t.id,
				room: e.room,
				target: e.id
			}))));
			Y(e, n, "trapSwap", v("交换陷阱房间与相邻房间各一枚棋子。", "Switch a figure here with one in an adjacent room."), t, a);
			break;
		}
		case "renovate": {
			let t = e.pieces.filter((e) => e.kind.startsWith("trap") && e.room >= 0);
			Y(e, n, "renovate", v("选择陷阱并移到没有陷阱的房间。", "Move a trap to a room without traps."), t.filter((e) => e.owner === n.who).flatMap((r) => V(e).filter((e) => !t.some((t) => t.id !== r.id && t.room === e)).map((e) => J(D[Number(r.kind.at(-1))], [z(n, "putPiece", {
				piece: r.id,
				to: e
			})], {
				key: "trap",
				piece: r.id,
				room: e
			}))));
			break;
		}
		case "tombPlace":
			Y(e, n, "tomb", v("选择陵墓附属的影院房间。", "Choose the theater room attached to the Tomb."), V(e).map((e) => J(H(e), [z(n, "tombSet", { to: e }), ...n.flag ? [z(n, "putPiece", {
				piece: s.id,
				to: e
			})] : []], {
				key: "tomb",
				room: e
			})));
			break;
		case "tombSet":
			e.tombRoom = n.to, q(e, t, "tomb", n, { room: n.to });
			break;
		case "unseal":
			Ee(e, n, 12).length && B(e, [
				z(n, "devour", { room: 12 }),
				z(n, "jar"),
				z(n, "unseal")
			]);
			break;
		case "jar":
			Y(e, n, "jar", v("选择一个空罐位。", "Choose an empty jar slot."), Array.from({ length: 7 }, (e, t) => t).filter((e) => !i.jars.includes(e)).map((e) => J([
				v("抽取全部牌", "Draw all your cards"),
				v("向陵墓所在房间的每名其他玩家偷 5 分", "Steal five from each player in the Tomb’s theater room"),
				v("获得进房后移动其他棋子的能力", "Gain the entry movement ability"),
				v("每次惊吓后获得 2 分", "Gain two after each spook"),
				v("每回合可以额外移动", "Gain an optional extra move each turn"),
				v("放置奖励罐：两罐齐全时得 5 分", "Fill a bonus jar: score five when both are filled"),
				v("放置奖励罐：两罐齐全时得 5 分", "Fill a bonus jar: score five when both are filled")
			][e], [z(n, "jarSet", { slot: e })], {
				key: "jar",
				n: e
			})));
			break;
		case "jarSet": {
			i.jars.push(n.slot);
			let r = [];
			n.slot === 0 && r.push(z(n, "draw", { n: -1 })), n.slot === 1 && r.push(z(n, "stealAll", {
				room: e.tombRoom,
				n: 5
			})), (n.slot === 5 || n.slot === 6) && i.jars.includes(5) && i.jars.includes(6) && r.push(z(n, "score", { n: 5 })), B(e, r), q(e, t, "jar", n, { n: n.slot });
			break;
		}
		case "mummyEntry":
			X(e, n, v("是否移动本房另一枚棋子？", "Move another figure in this room?"), [z(n, "moveFigure", { filter: "other" })]);
			break;
		case "mummyExtraMove":
			i.jars.includes(4) && X(e, n, v("是否再移动一次？", "Move one more time?"), [z(n, "move")]);
			break;
		case "drag":
			if (!s) break;
			Y(e, n, "drag", v("选择移动方向。", "Choose where to move."), W(e, s).map((e) => J(e === 12 ? v("陵墓", "Tomb") : H(e), [z(n, "moveTo", {
				target: s.id,
				to: e
			}), z(n, "dragGuests", {
				room: a,
				to: e,
				n: 2
			})], {
				key: "move",
				room: e
			})), a);
			break;
		case "dragGuests": {
			let t = e.guests.filter((t) => t.room === a && W(e, t).includes(n.to));
			if (!t.length || !n.n) break;
			Y(e, n, "dragGuests", v("可携带观众一同移动。", "You may bring guests along."), [J(v("不再携带", "Bring no more"), []), ...t.filter((e, n) => t.findIndex((t) => t.color === e.color) === n).map((e) => J(b[e.color], [z(n, "moveTo", {
				target: e.id,
				to: n.to
			}), {
				...n,
				n: n.n - 1
			}], {
				key: "carry",
				color: e.color,
				room: n.to
			}))]);
			break;
		}
		case "mosh":
			i.sets && B(e, [z(n, "add", { n: 5 }), z(n, "spook")]);
			break;
		case "nightMove": {
			if (!s) break;
			let t = W(e, s).flatMap((t) => {
				let r = e.guests.filter((n) => n.room === t && W(e, n).includes(a));
				return r.length ? r.map((e) => J(b[e.color], [z(n, "swap", {
					piece: s.id,
					target: e.id
				})], {
					key: "swap",
					color: e.color,
					piece: e.id,
					room: t
				})) : [J(x[t]?.name ?? v("陵墓", "Tomb"), [z(n, "moveTo", {
					target: s.id,
					to: t
				})], {
					key: "move",
					room: t
				})];
			});
			Y(e, n, "nightMove", v("与相邻房间的观众交换位置。", "Switch places with a guest in an adjacent room."), t, a);
			break;
		}
		case "placeTeam":
			Y(e, n, "team", v("将队员放入尚无队员的房间。", "Place this team member in a room without a team member."), V(e).filter((t) => !e.guests.some((e) => e.color === "white" && e.room === t)).map((e) => J(H(e), [z(n, "moveTo", {
				target: n.target,
				to: e
			})], {
				key: "team",
				room: e
			})));
			break;
		case "dumbStunt":
			Y(e, n, "teamDevour", v("选择任意房间的一名队员。", "Choose a team member in any room."), e.guests.filter((e) => e.color === "white" && e.room >= 0).map((e) => J(x[e.room]?.name ?? v("陵墓", "Tomb"), [z(n, "eat", { target: e.id }), z(n, "devour", {
				room: e.room,
				n: 2
			})], {
				key: "devour",
				piece: e.id,
				room: e.room,
				color: "white"
			})));
			break;
		case "phonePlace": {
			let t = i.slots.filter((e) => e && !n.ids?.includes(e)).flatMap((t) => V(e).filter((t) => !I(e, n.who).some((e) => e.room === t)).map((e) => J(v(`取走电话：${ie[i.slots.indexOf(t)].zh}`, `Take phone: ${ie[i.slots.indexOf(t)].en}`), [z(n, "phoneDeploy", {
				target: t,
				to: e
			})], {
				key: "phone",
				piece: t,
				room: e,
				n: i.slots.indexOf(t)
			})));
			Y(e, n, "phonePlace", v("从交换台取一部电话并选择房间。", "Take a switchboard phone and choose its room."), t);
			break;
		}
		case "phoneDeploy": {
			let t = i.slots.indexOf(n.target);
			t >= 0 && (i.slots[t] = ""), B(e, [z(n, "putPiece", {
				piece: n.target,
				to: n.to
			})]);
			break;
		}
		case "answer": {
			let t = I(e, n.who).flatMap((t) => e.pieces.filter((r) => P(r) && r.owner !== n.who && j(e, r.owner) && r.room === t.room).flatMap((e) => i.slots.map((e, t) => ({
				id: e,
				slot: t
			})).filter((e) => !e.id).map(({ slot: r }) => J([
				v(`获得 ${i.returned + 1} 分`, `Gain ${i.returned + 1} points`),
				v("双方各抽两张牌", "Both draw two cards"),
				v("放置另一部电话", "Place another phone"),
				v("双方各得 2 分", "Both gain two points"),
				v("加两名观众并得 2 分", "Add two guests and gain two points"),
				v("移动接听的怪物", "Move the answering monster"),
				v("在接听房间吞噬", "Devour in the answering room")
			][r], [z(n, "answerResolve", {
				piece: t.id,
				target: e.id,
				slot: r
			}), z(n, "answer")], {
				key: "answer",
				piece: t.id,
				room: t.room,
				target: e.owner,
				n: r
			}))));
			Y(e, n, "answer", v("选择电话、接听者和空交换台位置。", "Choose a phone, answering monster and empty switchboard slot."), t);
			break;
		}
		case "answerResolve": {
			let r = M(e, n.piece), a = M(e, n.target), o = a.room;
			i.slots[n.slot] = r.id, i.returned++, r.room = -1, B(e, [
				[z(n, "score", { n: i.returned })],
				[z(n, "draw", { n: 2 }), {
					k: "draw",
					who: a.owner,
					n: 2
				}],
				[z(n, "phonePlace", { ids: [r.id] })],
				[z(n, "score", { n: 2 }), z(n, "score", {
					target: a.owner,
					n: 2
				})],
				[z(n, "add", {
					room: o,
					n: 2
				}), z(n, "score", { n: 2 })],
				[z(n, "move", {
					piece: a.id,
					room: void 0
				})],
				[z(n, "devour", { room: o })]
			][n.slot]), q(e, t, "answer", n, {
				room: o,
				piece: r.id
			});
			break;
		}
		case "launch": {
			let t = n.room ?? a, r = n.used ?? [], i = e.guests.filter((e) => e.room === t && (!n.color || e.color === n.color) && !r.includes(e.id)).flatMap((t) => W(e, t).map((e) => J(e === 12 ? v("陵墓", "Tomb") : e === -10 ? v("外侧", "Outside") : H(e), [z(n, "moveTo", {
				target: t.id,
				to: e
			}), z(n, "launchContinue", {
				room: e,
				color: t.color,
				used: [...r, t.id],
				n: (n.n ?? 0) + 1
			})], {
				key: "launch",
				color: t.color,
				piece: t.id,
				room: e
			})));
			Y(e, n, "launch", v("发射：移动一名观众。", "Launch: move a guest."), i, t);
			break;
		}
		case "launchContinue":
			(n.n ?? 0) < 3 && a >= 0 && e.guests.some((t) => t.room === a && t.color === n.color && !n.used.includes(t.id) && W(e, t).length) ? Y(e, n, "launchContinue", v("是否继续移动另一名同色观众？", "Move a different guest of the same color?"), [J(v("继续发射", "Continue launching"), [{
				...n,
				k: "launch"
			}]), J(v("在此结算", "Resolve here"), [{
				...n,
				k: "launchFinish"
			}])], a) : B(e, [{
				...n,
				k: "launchFinish"
			}]);
			break;
		case "launchFinish": {
			if (a < 0) break;
			let t = n.n ?? 1, r = [];
			if (n.color === "red" && r.push(z(n, "launchRed", {
				room: a,
				n: t
			})), n.color === "purple" && r.push(z(n, "devour", {
				room: a,
				n: t
			})), n.color === "yellow") for (let e = 0; e < t; e++) r.push(z(n, "pull", { room: a }));
			n.color === "blue" && r.push(z(n, "putPiece", {
				piece: s.id,
				to: a
			})), n.color === "green" && r.push(z(n, "score", { n: t })), i.bonus && r.push(z(n, "spook", { room: a })), B(e, r);
			break;
		}
		case "launchRed": Y(e, n, "losePoints", v("选择最终房间中失分的玩家。", "Choose a player in the final room to lose points."), e.players.filter((t) => I(e, t.rid).some((e) => e.room === a)).map((e) => J(v(`失去 ${n.n} 分`, `Lose ${n.n} points`), [z(n, "score", {
			target: e.rid,
			n: -n.n
		})], {
			key: "points",
			target: e.rid,
			n: -n.n
		})), a);
	}
}
function Ne(e, t, n) {
	if (t.type === "tick" && n.by !== "$engine") return { code: "games.spooktacular.errChoice" };
	if (t.type === "tick" && (e.pending || !e.queue.length || e.phase === "done")) return {
		state: e,
		fx: []
	};
	if (t.type === "choose" && (!e.pending || e.pending.rid !== n.by || t.revision !== e.revision || !e.pending.options.some((e) => e.id === t.id))) return { code: "games.spooktacular.errChoice" };
	let r = structuredClone(e), i = [];
	if (t.type === "choose") {
		let e = r.pending.options.find((e) => e.id === t.id);
		r.pending = null, B(r, e.effects);
	}
	return r.revision++, ke(r, i, r.seed), {
		state: r,
		fx: i
	};
}
function Pe(e, t) {
	let n = j(e, t);
	return {
		public: {
			phase: e.phase,
			revision: e.revision,
			round: e.round,
			turn: e.pending?.rid ?? e.order[e.turn],
			players: e.players.map((t) => ({
				rid: t.rid,
				monster: t.monster,
				score: t.score,
				tickets: t.tickets.length,
				ticketValues: e.phase === "done" ? t.tickets : null,
				pile: t.pile.map((t) => N(e, t)),
				seats: t.seats.map((t) => N(e, t)),
				handCount: t.hand.length,
				deckCount: t.deck.length,
				discard: t.discard,
				program: t.program,
				tracks: t.tracks,
				jars: t.jars,
				fitness: t.fitness,
				switchboard: t.slots
			})),
			guests: e.guests.filter((e) => e.room >= 0),
			pieces: e.pieces.filter((e) => e.room >= 0),
			locked: e.locked,
			bagCount: e.bag.length,
			ticketsLeft: e.tickets.length,
			tombRoom: e.tombRoom,
			futures: e.futures,
			pending: e.pending ? {
				rid: e.pending.rid,
				actor: e.pending.actor,
				key: e.pending.key,
				text: e.pending.text,
				...e.pending.room === void 0 ? {} : { room: e.pending.room }
			} : null,
			endRound: e.endRound,
			autoCards: e.autoCards,
			last: e.last
		},
		private: {
			hand: n?.hand ?? [],
			choices: e.pending?.rid === t ? e.pending.options.map(({ effects: e, ...t }) => t) : []
		}
	};
}
function Fe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = (e) => e.score + e.tickets.reduce((e, t) => e + t, 0), n = [...e.players].sort((e, n) => t(n) - t(e) || n.tickets.length - e.tickets.length);
	return {
		phase: "done",
		winner: n.filter((e) => t(e) === t(n[0]) && e.tickets.length === n[0].tickets.length).map((e) => e.rid),
		ranking: n.map((e) => e.rid),
		scores: Object.fromEntries(n.map((e) => [e.rid, t(e)]))
	};
}
var Ie = {
	meta: le,
	schemas: {
		action: de,
		config: ue,
		publicView: ge,
		privateView: _e
	},
	saveCompatibility: { version: "1" },
	setup: Se,
	reduce: Ne,
	viewFor: Pe,
	status: Fe,
	nextTickIn: (e) => e.phase !== "done" && !e.pending && e.queue.length ? 540 : null
};
//#endregion
//#region src/games/spooktacular/rule-text.tsx
function Le({ text: e }) {
	return /* @__PURE__ */ r(n, { children: e.split("\n\n").map((e, t) => e.startsWith("· ") ? /* @__PURE__ */ r("ul", { children: e.split("\n").map((e, t) => /* @__PURE__ */ r("li", { children: e.replace(/^· /, "") }, t)) }, t) : /* @__PURE__ */ r("p", { children: e }, t)) });
}
//#endregion
//#region src/games/spooktacular/art.tsx
var Re = [
	"#55d5cb",
	"#f48185",
	"#ecc76c",
	"#c1a0eb",
	"#97d29c"
];
function ze({ color: e, size: t = 23 }) {
	return /* @__PURE__ */ i("svg", {
		width: t,
		height: t,
		viewBox: "0 0 28 32",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ r("path", {
				d: "M5 30V17Q5 12 10 12H18Q23 12 23 17V30H17V23H11V30Z",
				fill: ne[e],
				stroke: "#101b25",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ r("circle", {
				cx: "14",
				cy: "6.5",
				r: "5.5",
				fill: ne[e],
				stroke: "#101b25",
				strokeWidth: "1.5"
			}),
			e === "white" && /* @__PURE__ */ r("path", {
				d: "m14 14 1.5 3 3 .4-2.3 2.2.6 3.2-2.8-1.6-2.8 1.6.6-3.2L9.5 17l3-.4Z",
				fill: "#27323a"
			})
		]
	});
}
function Be({ guest: e, locale: t, anchor: n }) {
	let { ref: i, hidden: a } = d(n && e.id ? `sp-guest:${e.id}` : null);
	return /* @__PURE__ */ r("span", {
		ref: i,
		style: { visibility: a ? "hidden" : void 0 },
		title: b[e.color][t],
		"aria-label": b[e.color][t],
		children: /* @__PURE__ */ r(ze, { color: e.color })
	});
}
function Ve({ guests: e, locale: t, anchor: n = !1 }) {
	return /* @__PURE__ */ r("span", {
		className: "sp-guests",
		children: e.map((e, i) => /* @__PURE__ */ r(Be, {
			guest: e,
			locale: t,
			anchor: n
		}, e.id ?? i))
	});
}
var He = (e, t = "✦") => e === "animatronic" ? "⚙" : e === "phone" ? "☎" : e === "blob" ? "●" : e === "wolf" ? "☾" : e === "hive" ? "⬡" : e === "door" ? "↗" : e.startsWith("trap") ? "ϟ" : e.startsWith("dish") ? "♨" : t, Ue = (e) => ({ "--sp-player": Re[e % Re.length] });
function We(e, t, n) {
	return e.startsWith("trap") ? D[Number(e.at(-1))][n] : e.startsWith("dish") ? E[Number(e.at(-1))][n] : e === "wolf" ? O[Number(t.split(":").at(-1))] ?? "Wolf" : {
		monster: ["怪物", "Monster"],
		blob: ["黏液", "Blob"],
		phone: ["电话", "Phone"],
		animatronic: ["机械怪物", "Animatronic"],
		hive: ["蜂巢", "Hive"],
		door: ["外侧门", "Outside door"]
	}[e]?.[n === "zh" ? 0 : 1] ?? (e.startsWith("trap") ? n === "zh" ? "陷阱" : "Trap" : n === "zh" ? "菜肴" : "Dish");
}
function Ge(e, t) {
	return (e.startsWith("trap") ? ce[Number(e.at(-1))] : e.startsWith("dish") ? se[Number(e.at(-1))] : void 0)?.[t] ?? "";
}
//#endregion
//#region src/games/spooktacular/view-player.tsx
function Ke(e, t, n) {
	return (r) => r === "@killtron" ? "Auto-Killtron" : t.find((e) => e.rid === r)?.name || S(e.players.find((e) => e.rid === r)?.monster ?? "")?.name || (n === "zh" ? "访客" : "Guest");
}
function qe({ piece: e, pub: t, label: n, selected: i, onClick: a }) {
	let { ref: o, hidden: s } = d(`sp-piece:${e.id}`), c = t.players.find((t) => t.rid === e.owner), l = t.players.findIndex((t) => t.rid === e.owner), u = He(e.kind, S(c?.monster ?? "")?.icon);
	return /* @__PURE__ */ r("button", {
		ref: o,
		type: "button",
		"aria-label": n,
		title: n,
		className: `sp-piece${i ? " sp-picked" : ""}${l < 0 ? " sp-neutral" : ""}`,
		style: {
			...Ue(Math.max(0, l)),
			visibility: s ? "hidden" : void 0
		},
		onPointerDown: (e) => e.stopPropagation(),
		onPointerUp: (e) => e.stopPropagation(),
		onClick: (e) => {
			e.stopPropagation(), a();
		},
		children: u
	});
}
function Je({ index: e, room: t, pub: a, locale: o, eligible: s, selected: c, name: l, onPiece: u }) {
	let { ref: f } = d(`sp-room:${e}`), p = a.locked.includes(e), m = a.pieces.filter((t) => t.room === e);
	return /* @__PURE__ */ r("foreignObject", {
		x: t.x + 5,
		y: t.y + 5,
		width: t.w - 10,
		height: t.h - 10,
		children: /* @__PURE__ */ i("div", {
			ref: f,
			className: `sp-room${p ? " sp-locked" : ""}${s ? " sp-eligible" : ""}`,
			style: { "--sp-room": {
				0: "#174d56",
				1: "#6c263f",
				2: "#482e64",
				3: "#303d43",
				4: "#34494a",
				5: "#5e2635",
				6: "#293d42",
				7: "#60492e",
				8: "#254b43",
				9: "#35424f",
				10: "#3f3e40",
				11: "#42404c",
				12: "#524737"
			}[e] },
			children: [/* @__PURE__ */ r("div", {
				className: "sp-room-name",
				children: t.name
			}), p ? /* @__PURE__ */ r("div", {
				className: "sp-lock",
				children: "×"
			}) : /* @__PURE__ */ i(n, { children: [
				/* @__PURE__ */ r("div", {
					className: "sp-room-furnishing",
					"aria-hidden": "true",
					children: [
						0,
						1,
						2,
						8
					].includes(e) ? "▰ ▰ ▰\n▰ ▰ ▰" : e === 7 ? "SNACKS" : e === 4 ? "1986" : e === 9 ? "◉ ◉" : e === 12 ? "☥" : ""
				}),
				/* @__PURE__ */ r("div", {
					className: "sp-room-population",
					children: /* @__PURE__ */ r(Ve, {
						guests: a.guests.filter((t) => t.room === e),
						locale: o,
						anchor: !0
					})
				}),
				/* @__PURE__ */ r("div", {
					className: "sp-room-pieces",
					children: m.map((t) => /* @__PURE__ */ r(qe, {
						piece: t,
						pub: a,
						selected: c === t.id,
						label: `${t.owner ? l(t.owner) + " · " : ""}${We(t.kind, t.id, o)} ${Ge(t.kind, o)}`,
						onClick: () => u(t.id, e)
					}, t.id))
				})
			] })]
		})
	});
}
function Ye({ pub: e, locale: t, choices: n, selected: a, fit: o, name: s, onRoom: c, onPiece: l }) {
	let u = x.map((e) => ({
		x: e.x * 100 + 25,
		y: e.y * 100 + 25,
		w: e.w * 100,
		h: e.h * 100,
		name: e.name[t]
	}));
	e.tombRoom !== null && u.push({
		x: 25,
		y: 800,
		w: 270,
		h: 175,
		name: t === "zh" ? "陵墓" : "Tomb"
	});
	let d = new Set(n.filter((e) => e.room !== void 0 && e.room >= 0).map((e) => e.room));
	return /* @__PURE__ */ i(f, {
		sheetW: 950,
		sheetH: 1010,
		clampToSheet: !0,
		fitKey: `sp-theater:${o}`,
		eligible: u.map((e, t) => ({
			key: String(t),
			rect: {
				x: e.x + 5,
				y: e.y + 5,
				w: e.w - 10,
				h: e.h - 10
			}
		})),
		onTapEligible: (e) => c(Number(e)),
		highlight: "off",
		children: [
			/* @__PURE__ */ r("rect", {
				x: "0",
				y: "0",
				width: "950",
				height: "1010",
				rx: "18",
				fill: "#0c1b23"
			}),
			u.map((n, i) => /* @__PURE__ */ r(Je, {
				index: i,
				room: n,
				pub: e,
				locale: t,
				eligible: d.has(i),
				selected: a,
				name: s,
				onPiece: l
			}, i)),
			/* @__PURE__ */ r("g", {
				stroke: "#bad6c9",
				strokeWidth: "9",
				opacity: ".8",
				children: x.flatMap((e, t) => e.doors.filter((e) => e > t).map((e) => {
					let n = u[t], i = u[e], a = Math.max(n.x, i.x), o = Math.min(n.x + n.w, i.x + i.w), s = Math.max(n.y, i.y), c = Math.min(n.y + n.h, i.y + i.h), l = c <= s, d = l ? (a + o) / 2 : a, f = l ? s : (s + c) / 2;
					return /* @__PURE__ */ r("line", {
						x1: d - (l ? 20 : 0),
						y1: f - (l ? 0 : 20),
						x2: d + (l ? 20 : 0),
						y2: f + (l ? 0 : 20)
					}, `${t}:${e}`);
				}))
			}),
			e.tombRoom !== null && /* @__PURE__ */ i("text", {
				x: "36",
				y: "997",
				fill: "#d3c4a4",
				fontSize: "17",
				children: ["☥ → ", x[e.tombRoom].name[t]]
			})
		]
	});
}
function Xe({ player: e, index: t, locale: n, name: a, active: o, onClick: s }) {
	let c = u(), { ref: l } = d(`sp-player:${e.rid}`), { ref: f } = d(`sp-pile:${e.rid}`), p = S(e.monster);
	return /* @__PURE__ */ i("button", {
		ref: l,
		type: "button",
		className: `sp-player-ticket${o ? " sp-active" : ""}`,
		style: Ue(t),
		onClick: s,
		children: [
			/* @__PURE__ */ r("span", {
				className: "sp-avatar",
				children: p?.icon ?? "✦"
			}),
			/* @__PURE__ */ i("span", {
				className: "sp-identity",
				children: [
					/* @__PURE__ */ r("b", { children: a }),
					/* @__PURE__ */ r("small", { children: p?.name ?? c("games.spooktacular.monster") }),
					/* @__PURE__ */ r("span", {
						ref: f,
						children: /* @__PURE__ */ r(Ve, {
							guests: e.pile,
							locale: n,
							anchor: !0
						})
					})
				]
			}),
			/* @__PURE__ */ i("span", {
				className: "sp-score",
				children: [/* @__PURE__ */ r("strong", { children: e.score }), /* @__PURE__ */ i("small", { children: ["▱ ", e.tickets] })]
			})
		]
	});
}
function Ze({ id: e, locale: t, close: n, player: a }) {
	let o = u(), s = S(e);
	return s ? c(/* @__PURE__ */ r("div", {
		className: "sp-modal-backdrop",
		onClick: n,
		children: /* @__PURE__ */ i("section", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": s.name,
			className: "sp-modal sp-game",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ i("button", {
					className: "sp-close",
					onClick: n,
					children: [o("games.spooktacular.close"), " ×"]
				}),
				/* @__PURE__ */ r("img", {
					className: "sp-detail-art",
					src: `games/spooktacular/${e}.webp`,
					alt: ""
				}),
				/* @__PURE__ */ r("h2", { children: s.name }),
				/* @__PURE__ */ r("h3", { children: t === "zh" ? "回合顺序" : "Turn sequence" }),
				/* @__PURE__ */ r(Le, { text: s.steps[t] }),
				/* @__PURE__ */ r("h3", { children: t === "zh" ? "准备与能力" : "Setup and ability" }),
				/* @__PURE__ */ r(Le, { text: s.ability[t] }),
				/* @__PURE__ */ r(et, {
					player: a ?? {
						monster: e,
						program: [],
						tracks: [
							0,
							0,
							0,
							0,
							0
						],
						jars: [],
						fitness: 0,
						seats: [],
						switchboard: []
					},
					locale: t
				}),
				a && /* @__PURE__ */ i("div", {
					className: "sp-component",
					children: [
						/* @__PURE__ */ r("b", { children: o("games.spooktacular.pile") }),
						/* @__PURE__ */ r(Ve, {
							guests: a.pile,
							locale: t
						}),
						/* @__PURE__ */ i("p", { children: [
							o("games.spooktacular.discards"),
							": ",
							a.discard.map((e) => w[e]?.name[t]).join(" · ") || o("games.spooktacular.empty")
						] })
					]
				}),
				/* @__PURE__ */ r("div", {
					className: "sp-detail-cards",
					children: s.cards.map((e) => /* @__PURE__ */ i("div", { children: [/* @__PURE__ */ r("b", { children: w[e].name[t] }), /* @__PURE__ */ r("p", { children: w[e].text[t] })] }, e))
				})
			]
		})
	}), document.body) : null;
}
function Qe({ card: e, locale: t, monster: n, playable: a, send: o }) {
	let { ref: s } = d(`sp-card:${e}`);
	return /* @__PURE__ */ i("button", {
		ref: s,
		type: "button",
		disabled: !a,
		className: `sp-action-card${a ? " sp-card-available" : ""}`,
		onClick: o,
		children: [
			/* @__PURE__ */ r("span", {
				className: "sp-card-title",
				children: w[e]?.name[t] ?? e
			}),
			/* @__PURE__ */ r("span", {
				className: "sp-card-art",
				style: { backgroundImage: `url(games/spooktacular/${n}.webp)` }
			}),
			/* @__PURE__ */ r("span", {
				className: "sp-card-effect",
				children: w[e]?.text[t] ?? ""
			})
		]
	});
}
function $e(e) {
	let t = e.public, n = e.private, a = u(), o = l((e) => e.locale), [c, d] = s(null), [f, m] = s(null), [ee, h] = s(null), [te, g] = s(0), [_, v] = s(0), [y, ne] = s(e.myRid);
	y !== e.myRid && (ne(e.myRid), m(null), h(null));
	let C = Ke(t, e.members, o), E = n?.choices ?? [], D = E.some((e) => e.piece === f) ? f : null, O = D ? E.filter((e) => e.piece === D) : E, k = t.players.find((t) => t.rid === e.myRid), ie = t.players.find((e) => e.rid === t.pending?.actor), ae = S(k?.monster ?? ""), A = (n) => e.send({
		type: "choose",
		revision: t.revision,
		id: n.id
	}), oe = (e) => {
		d(e);
		let t = O.filter((t) => t.room === e && !t.card);
		t.length === 1 && A(t[0]);
	}, se = (e, t) => {
		m(D === e ? null : e), d(t);
		let n = E.filter((t) => t.piece === e);
		n.length === 1 && A(n[0]);
	}, ce = (e) => e === 12 ? a("games.spooktacular.tomb") : e === -10 ? a("games.spooktacular.outside") : x[e]?.name[o] ?? "";
	function le(e) {
		if (e.card) return w[e.card]?.name[o] ?? e.card;
		let n = t.pieces.find((t) => t.id === e.piece), r = [
			e.color ? b[e.color][o] : "",
			e.target && t.players.some((t) => t.rid === e.target) ? C(e.target) : "",
			n ? We(n.kind, n.id, o) : "",
			e.room === void 0 ? "" : ce(e.room),
			e.text[o]
		];
		return [...new Set(r.filter(Boolean))].join(" · ");
	}
	let ue = c === null ? [] : O.filter((e) => e.room === c && !e.card), de = E.filter((e) => e.key === "future"), fe = O.some((e) => e.room !== void 0 && e.room >= 0 && !e.card), pe = E.filter((e) => !e.card && e.key !== "future" && !(e.room !== void 0 && e.room >= 0));
	return /* @__PURE__ */ i(p, {
		adaptive: !0,
		scroll: !1,
		className: "sp-game",
		banner: /* @__PURE__ */ i("header", {
			className: "sp-header",
			children: [/* @__PURE__ */ i("div", {
				className: "sp-marquee",
				children: [
					/* @__PURE__ */ r("strong", { children: "SPOOKTACULAR" }),
					/* @__PURE__ */ i("span", { children: [
						a("games.spooktacular.round", { n: t.round }),
						" ",
						/* @__PURE__ */ r("i", { children: "◆" }),
						" ",
						a("games.spooktacular.tickets", { n: t.ticketsLeft }),
						" ",
						/* @__PURE__ */ r("i", { children: "◆" }),
						" ",
						a("games.spooktacular.bag", { n: t.bagCount })
					] }),
					t.endRound && /* @__PURE__ */ r("em", { children: a("games.spooktacular.finalRound") })
				]
			}), /* @__PURE__ */ r("div", {
				className: "sp-player-strip",
				children: t.players.map((e, n) => /* @__PURE__ */ r(Xe, {
					player: e,
					index: n,
					name: C(e.rid),
					locale: o,
					active: (t.pending?.actor ?? t.turn) === e.rid,
					onClick: () => h(e.monster)
				}, e.rid))
			})]
		}),
		children: [t.phase === "draft" ? /* @__PURE__ */ i("div", {
			className: "sp-casting",
			children: [/* @__PURE__ */ i("div", {
				className: "sp-casting-heading",
				children: [
					/* @__PURE__ */ r("span", { children: "NOW CASTING" }),
					/* @__PURE__ */ r("h1", { children: t.pending?.text[o] }),
					!E.length && /* @__PURE__ */ r("p", { children: a("games.spooktacular.waiting", { name: C(t.pending?.rid ?? t.turn) }) })
				]
			}), /* @__PURE__ */ r("div", {
				className: "sp-monster-grid",
				children: re.map((e) => {
					let n = E.find((t) => t.target === e.id), o = t.players.some((t) => t.monster === e.id);
					return /* @__PURE__ */ i("article", {
						className: `sp-monster-poster${o ? " sp-taken" : ""}`,
						children: [/* @__PURE__ */ i("button", {
							className: "sp-cast-image",
							disabled: !n,
							onClick: () => n && A(n),
							"aria-label": e.name,
							children: [
								/* @__PURE__ */ r("img", {
									src: `games/spooktacular/${e.id}.webp`,
									alt: ""
								}),
								/* @__PURE__ */ r("b", { children: e.name }),
								/* @__PURE__ */ r("span", { children: "●".repeat(e.level) })
							]
						}), /* @__PURE__ */ i("button", {
							className: "sp-inspect",
							onClick: () => h(e.id),
							children: [a("games.spooktacular.inspect"), " ↗"]
						})]
					}, e.id);
				})
			})]
		}) : /* @__PURE__ */ i("div", {
			className: "sp-main-layout",
			children: [/* @__PURE__ */ i("div", {
				className: "sp-theater",
				children: [/* @__PURE__ */ i("div", {
					className: "sp-theater-tools",
					children: [/* @__PURE__ */ r("button", {
						onClick: () => g((e) => e + 1),
						"aria-label": o === "zh" ? "回到全景" : "Fit theater",
						children: "⌖"
					}), D && /* @__PURE__ */ i("button", {
						onClick: () => m(null),
						children: [a("games.spooktacular.back"), " ×"]
					})]
				}), /* @__PURE__ */ r(Ye, {
					pub: t,
					locale: o,
					choices: O,
					selected: D,
					fit: te,
					name: C,
					onRoom: oe,
					onPiece: se
				})]
			}), /* @__PURE__ */ i("aside", {
				className: "sp-decision",
				children: [
					/* @__PURE__ */ i("div", {
						className: "sp-prompt",
						"aria-live": "polite",
						children: [/* @__PURE__ */ r("span", {
							className: "sp-projector",
							"aria-hidden": "true",
							children: "◉"
						}), /* @__PURE__ */ i("div", { children: [/* @__PURE__ */ r("b", { children: t.pending ? E.length ? t.pending.actor === "@killtron" ? a("games.spooktacular.autoChoice") : a("games.spooktacular.yourChoice") : a("games.spooktacular.waiting", { name: C(t.pending.rid) }) : a("games.spooktacular.resolving") }), /* @__PURE__ */ r("p", { children: t.pending?.text[o] })] })]
					}),
					ae && /* @__PURE__ */ i("button", {
						className: "sp-mini-poster",
						onClick: () => h(ae.id),
						children: [/* @__PURE__ */ r("img", {
							src: `games/spooktacular/${ae.id}.webp`,
							alt: ""
						}), /* @__PURE__ */ i("span", { children: [/* @__PURE__ */ r("b", { children: ae.name }), /* @__PURE__ */ i("small", { children: [a("games.spooktacular.inspect"), " ↗"] })] })]
					}),
					/* @__PURE__ */ i("div", {
						className: "sp-decision-scroll",
						children: [
							(fe || c !== null) && /* @__PURE__ */ i("div", {
								className: "sp-room-picker",
								children: [/* @__PURE__ */ i("label", { children: [a("games.spooktacular.room"), /* @__PURE__ */ i("select", {
									value: c ?? "",
									onChange: (e) => oe(Number(e.target.value)),
									children: [/* @__PURE__ */ r("option", {
										value: "",
										disabled: !0,
										children: "—"
									}), [...new Set(O.filter((e) => e.room !== void 0 && e.room >= 0).map((e) => e.room))].map((e) => /* @__PURE__ */ r("option", {
										value: e,
										children: ce(e)
									}, e))]
								})] }), c !== null && /* @__PURE__ */ i("div", {
									className: "sp-room-detail",
									children: [
										/* @__PURE__ */ r("b", { children: ce(c) }),
										/* @__PURE__ */ r(Ve, {
											guests: t.guests.filter((e) => e.room === c),
											locale: o
										}),
										/* @__PURE__ */ r("div", { children: t.pieces.filter((e) => e.room === c && Ge(e.kind, o)).map((e) => /* @__PURE__ */ i("p", { children: [
											/* @__PURE__ */ r("b", { children: We(e.kind, e.id, o) }),
											" · ",
											Ge(e.kind, o)
										] }, e.id)) }),
										/* @__PURE__ */ r("div", {
											className: "sp-near-choices",
											children: ue.map((e) => /* @__PURE__ */ i("button", {
												onClick: () => A(e),
												children: [e.color && /* @__PURE__ */ r(ze, { color: e.color }), /* @__PURE__ */ r("span", { children: le(e) })]
											}, e.id))
										})
									]
								})]
							}),
							de.length > 0 && /* @__PURE__ */ i("div", {
								className: "sp-future-choice",
								children: [/* @__PURE__ */ r("div", {
									className: "sp-future-tabs",
									children: T.map((e, t) => /* @__PURE__ */ r("button", {
										className: _ === t ? "sp-selected" : "",
										onClick: () => v(t),
										children: e.name[o]
									}, t))
								}), /* @__PURE__ */ r("div", {
									className: "sp-score-track",
									children: de.filter((e) => Number(e.target) === _).map((e) => /* @__PURE__ */ i("button", {
										title: e.text[o],
										onClick: () => A(e),
										children: [
											e.n,
											"–",
											e.n + T[_].span - 1
										]
									}, e.id))
								})]
							}),
							pe.length > 0 && /* @__PURE__ */ r("div", {
								className: "sp-abstract-choices",
								children: pe.map((e) => /* @__PURE__ */ r("button", {
									onClick: () => A(e),
									children: le(e)
								}, e.id))
							}),
							E.some((e) => e.card && !(n?.hand ?? []).includes(e.card)) && /* @__PURE__ */ r("div", {
								className: "sp-card-choices",
								children: E.filter((e) => e.card && !(n?.hand ?? []).includes(e.card)).map((e) => /* @__PURE__ */ r(Qe, {
									card: e.card,
									locale: o,
									monster: k?.monster || ie?.monster || "killtron",
									playable: !0,
									send: () => A(e)
								}, e.id))
							}),
							k && /* @__PURE__ */ i("div", {
								className: "sp-hand",
								children: [/* @__PURE__ */ i("h3", { children: [
									a("games.spooktacular.hand"),
									" ",
									/* @__PURE__ */ r("span", { children: k.handCount })
								] }), /* @__PURE__ */ r("div", {
									className: "sp-cards",
									children: (n?.hand ?? []).map((e, t) => {
										let n = E.find((t) => t.card === e);
										return /* @__PURE__ */ r(Qe, {
											card: e,
											locale: o,
											monster: k.monster,
											playable: !!n,
											send: () => n && A(n)
										}, `${e}:${t}`);
									})
								})]
							}),
							t.autoCards.length > 0 && /* @__PURE__ */ i("div", {
								className: "sp-component",
								children: [/* @__PURE__ */ r("b", { children: "Auto-Killtron" }), /* @__PURE__ */ r("div", { children: t.autoCards.map((e, t) => /* @__PURE__ */ r("span", { children: w[e]?.name[o] }, t)) })]
							}),
							k && /* @__PURE__ */ r(et, {
								player: k,
								locale: o,
								anchorSeats: !0
							}),
							t.futures.length > 0 && /* @__PURE__ */ i("div", {
								className: "sp-component",
								children: [/* @__PURE__ */ r("b", { children: a("games.spooktacular.futures") }), t.futures.map((e, t) => /* @__PURE__ */ i("p", { children: [
									T[e.kind].name[o],
									" · ",
									e.start,
									"–",
									e.start + T[e.kind].span - 1
								] }, t))]
							})
						]
					})
				]
			})]
		}), ee && /* @__PURE__ */ r(Ze, {
			id: ee,
			locale: o,
			close: () => h(null),
			player: t.players.find((e) => e.monster === ee)
		})]
	});
}
function et({ player: e, locale: t, anchorSeats: a = !1 }) {
	let o = u();
	return /* @__PURE__ */ i(n, { children: [
		e.program.length > 0 && /* @__PURE__ */ i("div", {
			className: "sp-component",
			children: [/* @__PURE__ */ r("b", { children: o("games.spooktacular.program") }), /* @__PURE__ */ r("ol", {
				className: "sp-program",
				children: e.program.map((e, n) => /* @__PURE__ */ i("li", { children: [/* @__PURE__ */ r("b", { children: w[e]?.name[t] }), /* @__PURE__ */ r("p", { children: w[e]?.text[t] })] }, n))
			})]
		}),
		e.monster === "deadLine" && /* @__PURE__ */ i("details", {
			className: "sp-component",
			children: [/* @__PURE__ */ r("summary", { children: o("games.spooktacular.switchboard") }), /* @__PURE__ */ r("ol", {
				className: "sp-switchboard",
				children: ie.map((n, a) => /* @__PURE__ */ i("li", { children: [/* @__PURE__ */ i("b", { children: [
					e.switchboard[a] ? "☎" : "○",
					" ",
					e.switchboard[a] ? o("games.spooktacular.occupied") : o("games.spooktacular.empty")
				] }), /* @__PURE__ */ r("p", { children: n[t] })] }, a))
			})]
		}),
		e.monster === "doombox" && /* @__PURE__ */ i("details", {
			className: "sp-component",
			children: [/* @__PURE__ */ r("summary", { children: o("games.spooktacular.tracks") }), e.tracks.map((e, n) => /* @__PURE__ */ i("div", {
				className: "sp-track-detail",
				children: [/* @__PURE__ */ i("b", { children: [
					/* @__PURE__ */ r(ze, { color: [
						"red",
						"purple",
						"yellow",
						"blue",
						"green"
					][n] }),
					" ",
					b[[
						"red",
						"purple",
						"yellow",
						"blue",
						"green"
					][n]][t]
				] }), /* @__PURE__ */ r("ol", { children: oe[n].map((n, i) => /* @__PURE__ */ r("li", {
					className: i === e ? "sp-selected" : "",
					children: n[t]
				}, i)) })]
			}, n))]
		}),
		e.monster === "mummy" && /* @__PURE__ */ i("details", {
			className: "sp-component",
			children: [/* @__PURE__ */ i("summary", { children: [
				o("games.spooktacular.jars"),
				" · ",
				e.jars.length,
				"/7"
			] }), /* @__PURE__ */ r("ol", {
				className: "sp-jar-list",
				children: ae.map((n, a) => /* @__PURE__ */ i("li", {
					className: e.jars.includes(a) ? "sp-selected" : "",
					children: [
						/* @__PURE__ */ r("b", { children: e.jars.includes(a) ? "♜" : "○" }),
						" ",
						n[t]
					]
				}, a))
			})]
		}),
		e.monster === "remover" && /* @__PURE__ */ i("details", {
			className: "sp-component",
			children: [/* @__PURE__ */ i("summary", { children: [
				o("games.spooktacular.fitness"),
				" · ",
				e.fitness
			] }), /* @__PURE__ */ r("ol", {
				start: 0,
				className: "sp-fitness-list",
				children: A.map((n, i) => /* @__PURE__ */ r("li", {
					className: i === e.fitness ? "sp-selected" : "",
					children: n[t]
				}, i))
			})]
		}),
		e.monster === "car" && /* @__PURE__ */ i("div", {
			className: "sp-component",
			children: [/* @__PURE__ */ r("b", { children: o("games.spooktacular.seats") }), /* @__PURE__ */ r(Ve, {
				guests: e.seats,
				locale: t,
				anchor: a
			})]
		})
	] });
}
//#endregion
//#region src/games/spooktacular/bot.ts
function tt(e, t, n) {
	let r = e.players.find((e) => e.rid === n);
	if (!r) return 0;
	let i = e.pieces.filter((e) => e.owner === n && [
		"monster",
		"phone",
		"wolf",
		"blob"
	].includes(e.kind)), a = t.room ?? i[0]?.room ?? 4, o = e.guests.filter((e) => e.room === a), s = y.filter((e) => !r.pile.some((t) => t.color === e)), c = new Set(o.filter((e) => s.includes(e.color)).map((e) => e.color)).size * 1.4 + Math.min(o.length, x[a]?.doors.length ?? 1) * .65, l = e.guests.filter((t) => t.room === (e.pending?.room ?? i[0]?.room)), u = (e) => e === "white" ? 3.8 : s.includes(e) ? 3.1 + (s.length === 1 ? 3 : 0) : .6;
	if (t.key === "monster") return t.target === "listener" ? 2 : t.target === "remover" ? 1.8 : 1;
	if (t.card) {
		let n = t.card, r = l.length;
		return {
			consume: new Set(l.filter((e) => s.includes(e.color)).map((e) => e.color)).size * 3 + new Set(l.map((e) => e.color)).size * .5,
			haunt: Math.min(r, 2 * (x[a]?.doors.length ?? 3)),
			search: 4,
			jumpscare: 2.5,
			mash: new Set(e.pieces.filter((e) => e.room === a && [
				"monster",
				"blob",
				"wolf",
				"phone"
			].includes(e.kind)).map((e) => e.owner)).size * 2,
			exterminate: Math.min(r, x[a]?.doors.length ?? 3),
			flex: 3.5,
			emergence: Math.min(r, 3) * 3,
			listen: 2,
			pose: 3,
			packHunt: i.length * 2,
			blurp: i.length * 2,
			schlorp: 2.5,
			getIn: 3,
			crankIt: 4,
			zappyZaps: 3,
			overdrive: 2.5,
			chainLight: 7,
			abduct: 7
		}[n] ?? 2.8;
	}
	if ([
		"devour",
		"passenger",
		"track",
		"carry",
		"mosey",
		"takePile"
	].includes(t.key)) return u(t.color) + +(t.color === "white");
	if (t.key === "spook") return 2 + (t.target && t.target !== n ? -c * .15 : c * .03) + (a === -10 ? .1 : 0) + (t.color && !s.includes(t.color) ? .1 : 0);
	if (t.key === "points") return (t.n ?? 0) * (t.target === n ? 1 : -1 / Math.max(1, e.players.length - 1));
	if (t.key === "steal") return t.n ?? 1;
	if (t.key === "future") {
		let r = T[Number(t.target)];
		return r ? e.players.reduce((e, i) => e + (i.score >= t.n && i.score < t.n + r.span ? (r.effect === "lose" ? -r.n : r.effect === "score" ? r.n : 3) * (i.rid === n ? 1 : -.5) : 0), 0) : 0;
	}
	return t.key === "jar" ? [
		3,
		3,
		2.7,
		5.5,
		3.5,
		r.jars.includes(6) ? 5 : 1.8,
		r.jars.includes(5) ? 5 : 1.8
	][t.n ?? 0] : t.key === "fitness" ? [
		0,
		2,
		4,
		4,
		6,
		3,
		5,
		4,
		4,
		3,
		2,
		5,
		4,
		10
	][t.n ?? 0] : t.key === "mow" ? t.n ?? 0 : t.key === "pull" ? (t.color ? u(t.color) : 1) + (t.target && t.target !== n ? .2 : 0) : t.key === "answer" ? [
		2,
		2.5,
		2,
		2,
		3.5,
		1,
		3
	][t.n ?? 0] : t.key === "refill" ? c * .2 - e.pieces.filter((e) => e.owner !== n && e.room === a).length * .5 : [
		"place",
		"putPiece",
		"move",
		"focus",
		"wolf",
		"grow",
		"swap",
		"newDoor",
		"dish",
		"trap",
		"animPlace",
		"spookRoom",
		"tripleSpook",
		"devourRoom",
		"tomb",
		"phone"
	].includes(t.key) ? c : t.text.en === "Skip" || t.text.en === "Bring no more" ? -.1 : .5;
}
var nt = (e, t) => {
	let n = e.private?.choices ?? [];
	if (!n.length || e.public.pending?.rid !== t.rid) return null;
	let r = t.difficulty === "weak" ? n[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % n.length] : n.reduce((n, r) => tt(e.public, r, t.rid) > tt(e.public, n, t.rid) ? r : n);
	return { action: {
		type: "choose",
		revision: e.public.revision,
		id: r.id
	} };
}, $ = 421;
function rt({ at: e }) {
	let t = o(null);
	return a(() => {
		let e = t.current?.animate([{
			transform: "scale(.25)",
			opacity: .9
		}, {
			transform: "scale(1.1)",
			opacity: 0
		}], {
			duration: $,
			easing: "ease-out",
			fill: "both"
		});
		return () => e?.cancel();
	}, []), /* @__PURE__ */ r("div", {
		ref: t,
		style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h,
			border: "5px solid #c5f8bb",
			borderRadius: "45%",
			boxShadow: "0 0 16px #adf9cf",
			pointerEvents: "none"
		}
	});
}
var it = { spookEvent(e, t) {
	let n = e.data, a = t.anchor(`sp-player:${n.rid}`), o = t.anchor(`sp-room:${n.room}`);
	if (n.kind === "score" && a) return {
		ms: $,
		node: /* @__PURE__ */ r(m, {
			at: a,
			ms: $,
			children: /* @__PURE__ */ i("span", {
				style: {
					color: n.n > 0 ? "#dff7ab" : "#ff9792",
					background: "#0c1b25",
					padding: "2px 8px",
					borderRadius: 4,
					fontSize: 23
				},
				children: [n.n > 0 ? "+" : "", n.n]
			})
		})
	};
	if (n.kind === "spook" && o) return {
		ms: $,
		node: /* @__PURE__ */ r(rt, { at: o })
	};
	if ([
		"move",
		"place",
		"devour",
		"passenger"
	].includes(n.kind)) {
		let e = n.color ? `sp-guest:${n.piece}` : `sp-piece:${n.piece}`, i = t.anchor(e), s = i ?? t.anchor(`sp-room:${n.to}`) ?? t.anchor(`sp-pile:${n.rid}`) ?? a;
		if (!s) return null;
		if (!o || t.queued) return {
			ms: 260,
			node: /* @__PURE__ */ r(h, {
				at: s,
				ms: 260
			})
		};
		let c = i?.w ?? 24, l = i ?? {
			...s,
			x: s.x + (s.w - c) / 2,
			y: s.y + (s.h - c) / 2,
			w: c,
			h: c
		}, u = {
			x: o.x + o.w / 2 - l.w / 2,
			y: o.y + o.h / 2 - l.h / 2,
			w: l.w,
			h: l.h
		};
		return {
			ms: $,
			hide: i ? [e] : [],
			node: /* @__PURE__ */ r(ee, {
				from: u,
				to: l,
				ms: $,
				children: n.color ? /* @__PURE__ */ r(ze, {
					color: n.color,
					size: l.w
				}) : /* @__PURE__ */ r("div", {
					className: `sp-piece${n.playerIndex === -1 ? " sp-neutral" : ""}`,
					style: {
						...Ue(Math.max(0, n.playerIndex ?? 0)),
						width: l.w,
						height: l.h,
						fontSize: l.h * .6
					},
					children: He(n.pieceKind ?? "monster", S(n.monster ?? "")?.icon)
				})
			})
		};
	}
	let s = n.kind === "card" ? t.anchor(`sp-card:${n.card}`) ?? o : o ?? a;
	return s ? {
		ms: 350,
		node: /* @__PURE__ */ r(h, {
			at: s,
			ms: 350
		})
	} : null;
} };
//#endregion
//#region src/games/spooktacular/game-over.tsx
function at(e) {
	let t = e.public, a = u(), o = l((e) => e.locale), [c, d] = s(!1), [f, m] = s(null), [ee, h] = s(0), g = Ke(t, e.members, o), _ = [...t.players].sort((e, t) => t.score + (t.ticketValues ?? []).reduce((e, t) => e + t, 0) - e.score - (e.ticketValues ?? []).reduce((e, t) => e + t, 0) || t.tickets - e.tickets), v = /* @__PURE__ */ i("div", {
		className: "sp-end-actions",
		children: [
			/* @__PURE__ */ r("button", {
				onClick: () => d(!c),
				children: a(c ? "games.spooktacular.hideTable" : "games.spooktacular.viewTable")
			}),
			e.onPlayAgain && /* @__PURE__ */ r(te, {
				compact: !0,
				label: a("games.spooktacular.playAgain"),
				confirmLabel: a("games.spooktacular.confirmAgain"),
				onConfirm: e.onPlayAgain
			}),
			" ",
			e.onBackToLobby && /* @__PURE__ */ r(te, {
				compact: !0,
				label: a("games.spooktacular.lobby"),
				confirmLabel: a("games.spooktacular.confirmLobby"),
				onConfirm: e.onBackToLobby
			})
		]
	});
	return /* @__PURE__ */ r(p, {
		adaptive: !0,
		scroll: !1,
		className: "sp-game",
		children: /* @__PURE__ */ i("div", {
			className: c ? "sp-over-table" : "sp-ending",
			children: [c ? /* @__PURE__ */ i(n, { children: [/* @__PURE__ */ i("div", {
				className: "sp-theater",
				children: [/* @__PURE__ */ r("div", {
					className: "sp-theater-tools",
					children: /* @__PURE__ */ r("button", {
						"aria-label": o === "zh" ? "回到全景" : "Fit theater",
						onClick: () => h((e) => e + 1),
						children: "⌖"
					})
				}), /* @__PURE__ */ r(Ye, {
					pub: t,
					locale: o,
					choices: [],
					selected: null,
					fit: ee,
					name: g,
					onRoom: () => {},
					onPiece: (e) => {
						let n = t.pieces.find((t) => t.id === e), r = t.players.find((e) => e.rid === n?.owner)?.monster;
						r && m(r);
					}
				})]
			}), v] }) : /* @__PURE__ */ i(n, { children: [
				/* @__PURE__ */ r("h1", { children: a("games.spooktacular.resultTitle") }),
				/* @__PURE__ */ i("div", {
					className: "sp-winning",
					children: [
						a("games.spooktacular.resultWinner"),
						" · ",
						e.result.winner.map(g).join(" / ")
					]
				}),
				/* @__PURE__ */ r("div", {
					className: "sp-credit-grid",
					children: _.map((n) => {
						let o = n.ticketValues ?? [], s = o.reduce((e, t) => e + t, 0), c = S(n.monster);
						return /* @__PURE__ */ i("article", {
							className: `sp-credit${e.result.winner.includes(n.rid) ? " sp-win" : ""}`,
							style: Ue(t.players.indexOf(n)),
							children: [/* @__PURE__ */ r("img", {
								src: `games/spooktacular/${n.monster}.webp`,
								alt: ""
							}), /* @__PURE__ */ i("div", {
								className: "sp-credit-main",
								children: [
									/* @__PURE__ */ r("h2", { children: g(n.rid) }),
									/* @__PURE__ */ r("h3", { children: c.name }),
									/* @__PURE__ */ i("dl", { children: [
										/* @__PURE__ */ i("div", { children: [/* @__PURE__ */ r("dt", { children: a("games.spooktacular.resultBase") }), /* @__PURE__ */ r("dd", { children: n.score })] }),
										/* @__PURE__ */ i("div", { children: [/* @__PURE__ */ r("dt", { children: a("games.spooktacular.resultTickets") }), /* @__PURE__ */ i("dd", { children: ["+", s] })] }),
										/* @__PURE__ */ i("div", {
											className: "sp-credit-total",
											children: [/* @__PURE__ */ r("dt", { children: a("games.spooktacular.resultTotal") }), /* @__PURE__ */ r("dd", { children: n.score + s })]
										})
									] }),
									/* @__PURE__ */ r("div", {
										className: "sp-revealed-tickets",
										children: o.map((e, t) => /* @__PURE__ */ i("span", { children: ["▱ ", e] }, t))
									})
								]
							})]
						}, n.rid);
					})
				}),
				e.hintCount !== void 0 && e.hintCount > 0 && /* @__PURE__ */ r("p", { children: a("session.hint.usedCount", { n: e.hintCount }) }),
				v
			] }), f && /* @__PURE__ */ r(Ze, {
				id: f,
				locale: o,
				close: () => m(null)
			})]
		})
	});
}
//#endregion
//#region src/games/spooktacular/options.tsx
function ot({ value: e, onChange: t }) {
	let n = u(), a = ue.safeParse(e), o = a.success ? a.data : ue.parse(void 0);
	return /* @__PURE__ */ i("div", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ r(_, {
			title: n("games.spooktacular.optAuto"),
			children: [!1, !0].map((e) => /* @__PURE__ */ r(g, {
				name: "spook-auto",
				value: String(e),
				checked: o.autoKilltron === e,
				label: n(e ? "games.spooktacular.autoOn" : "games.spooktacular.autoOff"),
				accent: le.accent,
				onChange: () => t({
					...o,
					autoKilltron: e
				})
			}, String(e)))
		}), /* @__PURE__ */ r(_, {
			title: n("games.spooktacular.optDifficulty"),
			columns: 2,
			children: [
				"easy",
				"normal",
				"hard",
				"nightmare"
			].map((e) => /* @__PURE__ */ r(g, {
				name: "spook-difficulty",
				value: e,
				checked: o.difficulty === e,
				label: n(e === "easy" ? "games.spooktacular.easy" : e === "normal" ? "games.spooktacular.normal" : e === "hard" ? "games.spooktacular.hard" : "games.spooktacular.nightmare"),
				accent: le.accent,
				onChange: () => t({
					...o,
					difficulty: e
				})
			}, e))
		})]
	});
}
//#endregion
//#region src/games/spooktacular/guide.tsx
function st() {
	let e = l((e) => e.locale);
	return /* @__PURE__ */ i("div", {
		className: "sp-guide",
		children: [
			/* @__PURE__ */ r("h2", { children: e === "zh" ? "角色与行动牌" : "Monsters and action cards" }),
			/* @__PURE__ */ r("p", { children: e === "zh" ? "展开角色可查看准备方式、能力、回合顺序及全部专属行动牌。" : "Expand a monster to read its setup, abilities, turn sequence and every unique action card." }),
			/* @__PURE__ */ i("details", { children: [/* @__PURE__ */ r("summary", { children: e === "zh" ? "五张基础行动牌" : "The five basic cards" }), /* @__PURE__ */ r("div", { children: /* @__PURE__ */ r("ul", { children: C.map((t) => /* @__PURE__ */ i("li", { children: [/* @__PURE__ */ i("b", { children: [w[t].name[e], "："] }), w[t].text[e]] }, t)) }) })] }),
			re.map((t) => /* @__PURE__ */ i("details", { children: [/* @__PURE__ */ i("summary", { children: [
				t.icon,
				" ",
				t.name
			] }), /* @__PURE__ */ i("div", { children: [
				/* @__PURE__ */ r("img", {
					src: `games/spooktacular/${t.id}.webp`,
					alt: ""
				}),
				/* @__PURE__ */ r("h3", { children: e === "zh" ? "准备与能力" : "Setup and ability" }),
				/* @__PURE__ */ r(Le, { text: t.ability[e] }),
				/* @__PURE__ */ r("h3", { children: e === "zh" ? "回合顺序" : "Turn sequence" }),
				/* @__PURE__ */ r(Le, { text: t.steps[e] }),
				/* @__PURE__ */ r(et, {
					player: {
						monster: t.id,
						program: [],
						tracks: [
							0,
							0,
							0,
							0,
							0
						],
						jars: [],
						fitness: 0,
						seats: [],
						switchboard: []
					},
					locale: e
				}),
				/* @__PURE__ */ r("ul", { children: t.cards.map((t) => /* @__PURE__ */ i("li", { children: [/* @__PURE__ */ i("b", { children: [w[t].name[e], "："] }), w[t].text[e]] }, t)) }),
				t.id === "doctor" && /* @__PURE__ */ r("ul", { children: D.map((t, n) => /* @__PURE__ */ r("li", { children: t[e] }, n)) }),
				t.id === "chef" && /* @__PURE__ */ r("ul", { children: E.map((t, n) => /* @__PURE__ */ r("li", { children: t[e] }, n)) }),
				t.id === "beasts" && /* @__PURE__ */ r("ul", { children: T.map((t, n) => /* @__PURE__ */ i("li", { children: [
					t.name[e],
					" · ",
					t.span,
					" ",
					e === "zh" ? "格" : "spaces"
				] }, n)) })
			] })] }, t.id))
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/spooktacular/entry.tsx
var ct = {
	definition: Ie,
	View: $e,
	bot: nt,
	fx: it,
	OverView: at,
	Options: ot,
	Guide: st,
	locales: {
		zh: {
			playAgain: "再放映一场",
			confirmAgain: "确认重新开局？",
			lobby: "返回大厅",
			confirmLobby: "确认返回大厅？",
			discards: "弃牌堆",
			switchboard: "电话交换台",
			occupied: "有电话",
			language: "zh",
			name: "Spooktacular",
			desc: "逃出银幕，化身二十种电影怪物，在万圣夜影院中惊吓观众、收集票券。",
			rules: "目标：\n你扮演一部恐怖电影的怪物，在影院中惊吓和吞噬观众，争取最高总分。基础版包含二十款怪物，每款都有独立的准备步骤、回合顺序和能力。角色详情可在下方图鉴中查阅。\n\n准备：\n· 每名玩家选择一款不同的怪物，起始获得 10 分。先手采用房间中的座次顺序。\n· 影院共有十二个房间。双人局关闭西侧走廊；两至三人局关闭洗手间；两至四人局关闭入口门厅。关闭房间不能进入。\n· 红、紫、黄、蓝、绿五种观众各有十二名。每个开放房间随机放入「印刷门数减一」名观众。其余观众留在袋中。\n· 票券共十张，4、5、6、7、8 分各两张。洗匀后随机取玩家人数两倍的票券组成票池。任何人都不能在终局前查看票券面值，包括持有者。\n· 每名玩家将五张基础行动牌与本怪物的专属牌洗成自己的牌库，按角色说明摆放组件并抽三张牌。Killtron 将三张指定牌放入程序，其余牌洗成牌库。\n\n回合流程：\n从先手开始按座次轮流行动。请严格按照自己怪物面板上列出的顺序完成回合。界面会依次提供当前步骤的合法选择；除非效果明确允许选择不执行，否则必须尽可能执行。不能完成某部分时，跳过该部分并继续后续效果。\n打出一张牌时，先完整执行牌面效果，再把它放进弃牌堆。抽牌时若牌库用尽，将自己的弃牌堆洗成新牌库。补至三张手牌不会让你弃掉超过三张的牌。\n\n移动与组件：\n· 默认的「移动」指把本次使用的己方怪物通过一扇门移入相邻房间。指定移动观众、其他怪物或任意棋子时，以效果说明为准。\n· 「棋子」指观众和怪物，不包含蜂巢、菜肴、陷阱或新门等标记。一名玩家可能控制多只怪物；计算玩家数时，每人只计算一次。\n· 「放在任意房间」允许留在原房间。角色增加的新门和陵墓遵守各自的限制。\n\n惊吓：\n惊吓某房间时，为每扇可用的门选择一名观众，将其移入门另一侧的房间。同一次惊吓不能重复使用同一扇门，除非能力明确允许。每移出一名观众，惊吓者获得 1 分。没有足够观众时，只移动能移动的部分。\nCharles 也能把其他玩家的怪物当作观众惊吓，并照常得分。Eagle 的队员可以被任何怪物惊吓。Angler 的外侧门只允许普通观众通过，通过者由 Angler 吞噬。陵墓中的观众不能离开。\n\n吞噬与票券：\n· 吞噬把指定房间的一名观众移入你的公开吞噬区，通常不会立即得分。普通吞噬只影响当前行动怪物所在房间。\n· 吞噬区一旦凑齐五种普通颜色，立即交回每色一名观众并获得一张暗置票券。交回一组观众时，吞噬区中的队员可代替任意颜色；存在多种组合时，由你选择交回的组合。\n· 交回的普通观众返回袋中；交回的队员离开游戏。若票池已经空了，本次改为获得 5 分。\n· 每交回一组观众后，在棋子总数最少的一个开放影院房间增加三名随机观众。若多个房间并列，由交回观众的玩家选择。\n· Killer Car 的乘客座位与普通吞噬区分开。五个座位坐满后，乘客作为一组交回。\n\n基础行动牌：\n· 突然惊吓：移动，然后打出一张牌。\n· 吞食：吞噬本房每种颜色各一名观众。\n· 闹鬼：惊吓，然后再惊吓一次。\n· 怪物派对：移动本房全部怪物。出牌者按被移动的玩家人数，每名获得 2 分；同一玩家的多只怪物只计算一次。\n· 搜寻：本房增加三名观众，然后打出一张牌。\n\n分数与结束：\n分数不会低于零。偷取分数时，最多拿走对方现有的分数。\n任意玩家达到 50 分，或最后一张票券被拿走时，触发结束。继续完成当前整轮，让尚未行动的玩家各完成本轮回合，然后揭开全部票券并把票面分数加到持有者分数中。\n总分最高者获胜。总分相同时，票券较多者获胜；仍相同则共享胜利。\n\n单人及自动 Killtron：\n单人局自动加入 Killtron；二至四名真人也可在开局选项中加入它，且总人数不超过五名。自动 Killtron 占据先手，起始分数按简单、普通、困难、噩梦分别为 5、10、15、20 分。它从门数最多的房间开始。\n· 它有三个独立牌堆。甲堆为抓钩、出动、突然惊吓；乙堆为怪物派对、搜寻、电弧；丙堆为闹鬼、歼灭、吞食。每回合同时揭开各堆顶牌，依次执行甲、乙、丙，再各自弃牌。各堆用尽后分别重洗。\n· 它忽略所有抽牌和再打牌效果。它按本回合最后揭开的牌选择移动目的地：闹鬼或歼灭偏好观众最多的相邻房间，再比门数；吞食偏好能补齐吞噬区颜色的相邻房间，再比不同颜色数。\n· 惊吓时，它从上方开始顺时针选门，优先移动红、黄、绿、蓝、紫色观众。抓钩优先拉入玩家怪物，并优先分数最高者；没有玩家可拉时，优先吞噬区缺少的颜色，颜色顺序同上。\n· 怪物派对把其他玩家怪物移到观众最少的房间，再比门数较少。官方优先级仍无法解决的决定，由 Killtron 后的真人选择。\n",
			errChoice: "这个选择已经失效，请按当前提示重新选择。",
			round: "第 {{n}} 轮",
			tickets: "票池 {{n}}",
			bag: "观众袋 {{n}}",
			finalRound: "本轮结束后揭票",
			resolving: "正在结算…",
			waiting: "等待 {{name}}",
			yourChoice: "轮到你选择",
			autoChoice: "为自动 Killtron 作决定",
			choose: "确认选择",
			inspect: "查看角色",
			close: "关闭",
			hand: "手牌",
			noHand: "暂无手牌",
			pile: "吞噬区",
			seats: "乘客座位",
			score: "分数",
			ticketCount: "{{n}} 张票券",
			empty: "空",
			monster: "怪物",
			room: "房间",
			back: "返回",
			zoomHint: "滚轮缩放，拖动查看",
			rulesDetail: "角色与组件",
			program: "程序",
			tracks: "磁带轨道",
			jars: "诅咒罐",
			fitness: "减重计划",
			futures: "惊吓期货",
			locked: "此房间已关闭",
			tomb: "陵墓",
			outside: "外侧门",
			animatronic: "机械怪物",
			resultTitle: "片尾字幕",
			resultWinner: "最恐怖的怪物",
			resultTotal: "总分",
			resultBase: "影院得分",
			resultTickets: "票券得分",
			viewTable: "回看影院",
			hideTable: "返回字幕",
			optAuto: "自动 Killtron",
			autoOn: "加入自动对手",
			autoOff: "仅真人座位（单人局仍自动加入）",
			optDifficulty: "自动 Killtron 难度",
			easy: "简单 · 5 分",
			normal: "普通 · 10 分",
			hard: "困难 · 15 分",
			nightmare: "噩梦 · 20 分",
			choiceCount: "{{n}} 个合法选择",
			selectedRoom: "查看中的房间",
			supply: "供应区",
			eventMove: "棋子移动",
			eventSpook: "惊吓",
			eventDevour: "吞噬",
			eventSet: "收集完成",
			eventCard: "行动牌",
			eventScore: "得分",
			hint: "建议：{{choice}}"
		},
		en: {
			playAgain: "Play again",
			confirmAgain: "Start another game?",
			lobby: "Back to lobby",
			confirmLobby: "Return to lobby?",
			discards: "Discard pile",
			switchboard: "Switchboard",
			occupied: "Phone present",
			language: "en",
			name: "Spooktacular",
			desc: "Escape the screen as one of twenty movie monsters, spook cinema guests and collect tickets on Halloween night.",
			rules: "Goal:\nBecome a horror movie monster and earn the highest total by spooking and devouring guests. All twenty base-game monsters have their own setup, turn sequence and abilities. Their details appear in the reference below.\n\nSetup:\n· Each player chooses a different monster and starts with 10 points. Seating order determines the first player in this adaptation.\n· The theater has twelve rooms. Close the West passage with two players, the Restrooms with two or three, and the Entrance foyer with two to four. Closed rooms cannot be entered.\n· There are twelve guests in each of five colors: red, purple, yellow, blue and green. Add random guests to each open room equal to its printed number of doors minus one. Leave the rest in the bag.\n· There are ten tickets, two each worth 4, 5, 6, 7 and 8 points. Shuffle all tickets and take twice the player count for the ticket pool. Nobody, including the holder, may see ticket values before the game ends.\n· Shuffle your five basic cards with your monster’s unique cards, follow its setup, and draw three. Killtron places its three specified cards in its program and shuffles the remaining cards into its deck.\n\nTaking a turn:\nTake turns in seating order and follow your monster’s turn steps in order. The interface offers legal choices for the current step. Unless an effect explicitly says it is optional, do as much of it as possible. If part cannot be completed, skip that part and continue.\nResolve a played card completely before discarding it. If you need to draw from an empty deck, shuffle your discard pile to form a new deck. Drawing back to three never requires you to discard excess cards.\n\nMovement and components:\n· An unspecified move takes your acting monster through one door to an adjacent room. Effects that specify guests, other monsters or figures follow their own instructions.\n· A figure means a guest or a monster, excluding hives, dishes, traps and new doors. A player may control several monsters; count that player only once when an effect counts players.\n· Placing a monster in any room allows it to remain where it is. New doors and the Tomb follow their own restrictions.\n\nSpooking:\nFor each available door in the affected room, move one guest through it into the connected room. Each door may be used once per spook unless an ability permits otherwise. Score one point per moved guest. If there are not enough guests, move as many as possible.\nCharles can also spook other players’ monsters as guests and scores normally. Anyone may spook Eagle’s team members. Only ordinary guests can use Angler’s outside doors; Angler devours them as they leave. Guests in the Tomb cannot leave.\n\nDevouring and tickets:\n· Devouring moves a guest from the specified room into your public devour pile, usually without scoring immediately. An unspecified devour affects the acting monster’s room.\n· As soon as your pile contains all five ordinary colors, return one guest of each color and take a face-down ticket. For turning in a set only, team members are wild in the pile; choose which valid set to return if several are available.\n· Ordinary returned guests go back into the bag. Returned team members leave the game. If no ticket remains, gain five points instead.\n· After returning a set, add three random guests to an open theater room containing the fewest figures. Choose the room if several tie.\n· Killer Car’s seats are separate from its devour pile. When all five seats are filled, return those passengers as a set.\n\nBasic action cards:\n· Jumpscare: move, then play a card.\n· Consume: devour one guest of each color in your room.\n· Haunt: spook, then spook again.\n· Mash: move every monster in your room. The acting player gains two points per player moved; several monsters belonging to one player still count as one player.\n· Search: add three guests to your room, then play a card.\n\nScores and ending:\nScores cannot fall below zero. Stealing takes no more points than the target currently has.\nReaching 50 points or taking the last ticket triggers the end. Finish the current round, allowing every remaining player to finish their turn. Reveal tickets and add their printed values to their holders’ scores.\nThe highest total wins. Break a tie by the number of tickets; tied players with equal ticket counts share victory.\n\nSolo and Auto-Killtron:\nA solo game automatically includes Auto-Killtron. With two to four human seats, you may enable it in the options, up to five total players. It goes first, starting with 5, 10, 15 or 20 points on Easy, Normal, Hard or Nightmare. It begins in the room with the most doors.\n· It has three separate decks. Deck A contains Grapple, Roll Out and Jumpscare; B contains Mash, Search and Arc Lightning; C contains Haunt, Exterminate and Consume. Reveal the top card of each deck together and resolve A, B, C in order, then discard separately. Reshuffle each empty deck independently.\n· It ignores all draw and play-a-card effects. When its final card is Haunt or Exterminate, it moves toward the most guests, breaking ties by more doors. With Consume, it prefers the most missing pile colors, breaking ties by more different colors.\n· It spooks through doors clockwise from the top, moving red, yellow, green, blue, then purple guests first. Grapple prioritizes player monsters, then the highest score. Otherwise it seeks a guest color missing from its pile, using that color order.\n· Mash moves other players toward the fewest guests, breaking ties by fewer doors. Decisions not resolved by the official priorities are made by the human after Killtron.\n",
			errChoice: "That choice is no longer available. Please follow the current prompt.",
			round: "Round {{n}}",
			tickets: "{{n}} tickets left",
			bag: "{{n}} guests in bag",
			finalRound: "Reveal tickets after this round",
			resolving: "Resolving…",
			waiting: "Waiting for {{name}}",
			yourChoice: "Your choice",
			autoChoice: "Decide for Auto-Killtron",
			choose: "Confirm choice",
			inspect: "Inspect monster",
			close: "Close",
			hand: "Hand",
			noHand: "No cards in hand",
			pile: "Devour pile",
			seats: "Passenger seats",
			score: "Score",
			ticketCount: "{{n}} tickets",
			empty: "Empty",
			monster: "Monster",
			room: "Room",
			back: "Back",
			zoomHint: "Scroll to zoom; drag to explore",
			rulesDetail: "Monsters and components",
			program: "Program",
			tracks: "Cassette tracks",
			jars: "Curse jars",
			fitness: "Weight Loss Plan",
			futures: "Spook Futures",
			locked: "This room is closed",
			tomb: "Tomb",
			outside: "Outside door",
			animatronic: "Animatronic",
			resultTitle: "End Credits",
			resultWinner: "The most terrifying monster",
			resultTotal: "Total",
			resultBase: "Theater score",
			resultTickets: "Ticket score",
			viewTable: "Revisit the theater",
			hideTable: "Back to credits",
			optAuto: "Auto-Killtron",
			autoOn: "Include the automatic opponent",
			autoOff: "Human seats only (still included in solo)",
			optDifficulty: "Auto-Killtron difficulty",
			easy: "Easy · 5 points",
			normal: "Normal · 10 points",
			hard: "Hard · 15 points",
			nightmare: "Nightmare · 20 points",
			choiceCount: "{{n}} legal choices",
			selectedRoom: "Inspected room",
			supply: "Supply",
			eventMove: "Figure moved",
			eventSpook: "Spook",
			eventDevour: "Devour",
			eventSet: "Set completed",
			eventCard: "Action card",
			eventScore: "Score",
			hint: "Suggestion: {{choice}}"
		}
	}
};
//#endregion
export { ct as default };
