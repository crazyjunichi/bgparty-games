import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useId as r, useMemo as i, useRef as a, useState as o } from "react";
import { useT as s } from "@bgparty/sdk/i18n";
import { IconRecenter as c } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { PhaseBanner as u } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { PlayerStrip as f } from "@bgparty/sdk/ui/player-strip";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { PulseBox as g } from "@bgparty/sdk/fx/primitives";
import { Confetti as _ } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as v, OptionSection as y } from "@bgparty/sdk/ui/game-options";
var b = [
	"water",
	"forest",
	"desert",
	"mountain",
	"swamp"
], x = [
	[
		[0, 0],
		[0, 0],
		[0, 0],
		[0, 0],
		[1, 0],
		[1, 0],
		[4, 0],
		[4, 0],
		[0, 0],
		[2, 0],
		[1, 0],
		[1, 0],
		[4, 0],
		[4, 0],
		[2, 0],
		[2, 2],
		[2, 2],
		[1, 2]
	],
	[
		[4, 1],
		[1, 1],
		[1, 1],
		[1, 0],
		[1, 0],
		[1, 0],
		[4, 0],
		[4, 0],
		[1, 0],
		[2, 0],
		[2, 0],
		[2, 0],
		[4, 0],
		[3, 0],
		[3, 0],
		[3, 0],
		[3, 0],
		[2, 0]
	],
	[
		[4, 0],
		[4, 0],
		[1, 0],
		[1, 0],
		[1, 0],
		[0, 0],
		[4, 1],
		[4, 1],
		[1, 0],
		[3, 0],
		[0, 0],
		[0, 0],
		[3, 1],
		[3, 0],
		[3, 0],
		[3, 0],
		[0, 0],
		[0, 0]
	],
	[
		[2, 0],
		[2, 0],
		[3, 0],
		[3, 0],
		[3, 0],
		[3, 0],
		[2, 0],
		[2, 0],
		[3, 0],
		[0, 0],
		[0, 0],
		[0, 1],
		[2, 0],
		[2, 0],
		[2, 0],
		[1, 0],
		[1, 0],
		[1, 1]
	],
	[
		[4, 0],
		[4, 0],
		[4, 0],
		[3, 0],
		[3, 0],
		[3, 0],
		[4, 0],
		[2, 0],
		[2, 0],
		[0, 0],
		[3, 0],
		[3, 2],
		[2, 0],
		[2, 0],
		[0, 0],
		[0, 0],
		[0, 2],
		[0, 2]
	],
	[
		[2, 2],
		[2, 0],
		[4, 0],
		[4, 0],
		[4, 0],
		[1, 0],
		[3, 2],
		[3, 0],
		[4, 0],
		[4, 0],
		[1, 0],
		[1, 0],
		[3, 0],
		[0, 0],
		[0, 0],
		[0, 0],
		[0, 0],
		[1, 0]
	],
	[
		[1, 2],
		[2, 2],
		[2, 2],
		[2, 0],
		[4, 0],
		[4, 0],
		[1, 0],
		[1, 0],
		[2, 0],
		[0, 0],
		[4, 0],
		[4, 0],
		[1, 0],
		[1, 0],
		[0, 0],
		[0, 0],
		[0, 0],
		[0, 0]
	],
	[
		[2, 0],
		[3, 0],
		[3, 0],
		[3, 0],
		[3, 0],
		[4, 0],
		[2, 0],
		[2, 0],
		[2, 0],
		[1, 0],
		[4, 0],
		[4, 0],
		[1, 0],
		[1, 0],
		[1, 0],
		[1, 1],
		[1, 1],
		[4, 1]
	],
	[
		[0, 0],
		[0, 0],
		[3, 0],
		[3, 0],
		[3, 0],
		[3, 1],
		[0, 0],
		[0, 0],
		[3, 0],
		[1, 0],
		[4, 1],
		[4, 1],
		[0, 0],
		[1, 0],
		[1, 0],
		[1, 0],
		[4, 0],
		[4, 0]
	],
	[
		[1, 1],
		[1, 0],
		[1, 0],
		[2, 0],
		[2, 0],
		[2, 0],
		[0, 1],
		[0, 0],
		[0, 0],
		[3, 0],
		[2, 0],
		[2, 0],
		[3, 0],
		[3, 0],
		[3, 0],
		[3, 0],
		[2, 0],
		[2, 0]
	],
	[
		[0, 2],
		[0, 2],
		[0, 0],
		[0, 0],
		[2, 0],
		[2, 0],
		[3, 2],
		[3, 0],
		[0, 0],
		[2, 0],
		[2, 0],
		[4, 0],
		[3, 0],
		[3, 0],
		[3, 0],
		[4, 0],
		[4, 0],
		[4, 0]
	],
	[
		[1, 0],
		[0, 0],
		[0, 0],
		[0, 0],
		[0, 0],
		[3, 0],
		[1, 0],
		[1, 0],
		[4, 0],
		[4, 0],
		[3, 0],
		[3, 2],
		[1, 0],
		[4, 0],
		[4, 0],
		[4, 0],
		[2, 0],
		[2, 2]
	]
];
function S(e) {
	return e % 12 + 1;
}
function C(e) {
	return Math.floor(e / 12) + 1;
}
function w(e, t) {
	let n = e - 1, r = t - 1 - (n - (n & 1)) / 2;
	return {
		q: n,
		r,
		s: -n - r
	};
}
function T(e, t) {
	let n = w(S(e), C(e)), r = w(S(t), C(t));
	return Math.max(Math.abs(n.q - r.q), Math.abs(n.r - r.r), Math.abs(n.s - r.s));
}
function E(e) {
	let t = Array(108);
	for (let n = 0; n < 108; n++) {
		let r = S(n), i = C(n), a = Math.floor((i - 1) / 3) * 2 + (r <= 6 ? 0 : 1), o = e.tiles[a] - 1, s = (r - 1) % 6, c = (i - 1) % 3, [l, u] = x[o][c * 6 + s];
		t[n] = {
			terrain: b[l],
			animal: u === 1 ? "cougar" : u === 2 ? "bear" : null
		};
	}
	return t;
}
var D = [
	"within_forest",
	"within_water",
	"within_swamp",
	"within_mountain",
	"within_desert",
	"within_animal",
	"within_animal_cougar",
	"within_animal_bear",
	"within_stone",
	"within_shack",
	"within_green",
	"within_blue",
	"within_white",
	"within_black",
	"desert_or_swamp",
	"forest_or_mountain",
	"forest_or_swamp",
	"mountain_or_swamp",
	"water_or_desert",
	"water_or_forest",
	"water_or_swamp",
	"water_or_mountain",
	"forest_or_desert",
	"desert_or_mountain"
];
function O(e) {
	return e ? [...D, ...D.map((e) => `not_${e}`)] : [...D];
}
function k(e, t, n, r) {
	return e.some((e, i) => e.terrain === n && T(t, i) <= r);
}
function ee(e, t, n, r) {
	return e.some((e, i) => e.animal !== null && (n === null || e.animal === n) && T(t, i) <= r);
}
function A(e, t, n, r, i) {
	return e.some((e) => (n === null || e.type === n) && (r === null || e.color === r) && T(t, e.hex) <= i);
}
function j(e, t, n, r) {
	if (r.startsWith("not_")) return !j(e, t, n, r.slice(4));
	let i = e[n].terrain;
	switch (r) {
		case "within_forest": return k(e, n, "forest", 1);
		case "within_water": return k(e, n, "water", 1);
		case "within_swamp": return k(e, n, "swamp", 1);
		case "within_mountain": return k(e, n, "mountain", 1);
		case "within_desert": return k(e, n, "desert", 1);
		case "within_animal": return ee(e, n, null, 1);
		case "within_animal_cougar": return ee(e, n, "cougar", 2);
		case "within_animal_bear": return ee(e, n, "bear", 2);
		case "within_stone": return A(t, n, "stone", null, 2);
		case "within_shack": return A(t, n, "shack", null, 2);
		case "within_green": return A(t, n, null, "green", 3);
		case "within_blue": return A(t, n, null, "blue", 3);
		case "within_white": return A(t, n, null, "white", 3);
		case "within_black": return A(t, n, null, "black", 3);
		case "desert_or_swamp": return i === "desert" || i === "swamp";
		case "forest_or_mountain": return i === "forest" || i === "mountain";
		case "forest_or_swamp": return i === "forest" || i === "swamp";
		case "mountain_or_swamp": return i === "mountain" || i === "swamp";
		case "water_or_desert": return i === "water" || i === "desert";
		case "water_or_forest": return i === "water" || i === "forest";
		case "water_or_swamp": return i === "water" || i === "swamp";
		case "water_or_mountain": return i === "water" || i === "mountain";
		case "forest_or_desert": return i === "forest" || i === "desert";
		case "desert_or_mountain": return i === "desert" || i === "mountain";
		default: return !1;
	}
}
function M(e, t, n) {
	let r = [];
	for (let i = 0; i < 108; i++) j(e, t, i, n) && r.push(i);
	return r;
}
//#endregion
//#region src/games/cryptid/gen.ts
var te = 30, ne = 200, N = class {
	seed;
	cursor = 0;
	constructor(e) {
		this.seed = e;
	}
	int(t) {
		return e(this.seed, this.cursor++, t);
	}
	shuffle(e) {
		for (let t = e.length - 1; t > 0; t--) {
			let n = this.int(t + 1);
			[e[t], e[n]] = [e[n], e[t]];
		}
		return e;
	}
};
function P(e) {
	let t = [
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9,
		10,
		11,
		12
	], n = [];
	for (let r = 0; r < 6; r++) {
		let r = t[e.int(t.length)];
		n.push(r);
		let i = r <= 6 ? r + 6 : r - 6;
		for (let e of [r, i]) {
			let n = t.indexOf(e);
			n !== -1 && t.splice(n, 1);
		}
	}
	return n;
}
function F(e, t) {
	let n = e.shuffle(Array.from({ length: 108 }, (e, t) => t)), r = [], i = 0;
	for (let a of ["stone", "shack"]) {
		let o = e.shuffle([
			"white",
			"green",
			"blue",
			"black"
		]), s = t ? 4 : 3;
		for (let e = 0; e < s; e++) r.push({
			hex: n[i++],
			type: a,
			color: o[e]
		});
	}
	return r;
}
function I(e, t, n, r) {
	let i = t.filter((e) => {
		let t = n.get(e);
		return t.has(r) && t.size > 1;
	});
	if (i.sort((e, t) => n.get(e).size - n.get(t).size), i.length < e) return null;
	let a = null, o = [], s = new Set(Array.from({ length: 108 }, (e, t) => t));
	function c(t) {
		if (a) return;
		if (o.length === e) {
			s.size === 1 && (a = [...o]);
			return;
		}
		let l = i.length - (e - o.length);
		for (let e = t; e <= l; e++) {
			let t = i[e], l = n.get(t), u = /* @__PURE__ */ new Set();
			for (let e of s) l.has(e) && u.add(e);
			if (!u.has(r) || u.size >= s.size) continue;
			o.push(t);
			let d = s;
			if (s = u, c(e + 1), s = d, o.pop(), a) return;
		}
	}
	c(0);
	let l = a;
	if (!l) return null;
	for (let e = 0; e < l.length; e++) {
		let t = new Set(Array.from({ length: 108 }, (e, t) => t));
		for (let r = 0; r < l.length; r++) {
			if (r === e) continue;
			let i = n.get(l[r]), a = /* @__PURE__ */ new Set();
			for (let e of t) i.has(e) && a.add(e);
			t = a;
		}
		if (t.size === 1) return null;
	}
	return l;
}
function L(e, t, n, r) {
	let i = E(t), a = O(r), o = /* @__PURE__ */ new Map();
	for (let e of a) o.set(e, new Set(M(i, t.structures, e)));
	for (let r = 0; r < ne; r++) {
		let r = e.int(108), i = I(n, a, o, r);
		if (i) return {
			map: t,
			clues: e.shuffle(i),
			solution: r
		};
	}
	return null;
}
function R(e, t, n) {
	let r = new N(e);
	for (let e = 0; e < te; e++) {
		let e = L(r, {
			tiles: P(r),
			structures: F(r, n)
		}, t, n);
		if (e) return e;
	}
	let i = new N(e ^ 2654435769);
	for (let e = 0; e < 60; e++) {
		let e = L(i, {
			tiles: P(i),
			structures: F(i, n)
		}, t, n);
		if (e) return e;
	}
	throw Error("cryptid: setup generation failed");
}
//#endregion
//#region src/games/cryptid/meta.ts
var z = {
	id: "cryptid",
	tier: "beta",
	mechanics: ["deduction"],
	interactionTags: [],
	nameKey: "games.cryptid.name",
	descKey: "games.cryptid.desc",
	rulesKey: "games.cryptid.rules",
	icon: "👣",
	iconImg: "games/cryptid.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/cryptid/en.pdf" },
	minPlayers: 3,
	maxPlayers: 5,
	bestPlayers: [4],
	accent: "#0f766e",
	releasedAt: "2026-09-16",
	search: {
		py: "gui ying xun zong",
		init: "gyxz"
	},
	hotseat: "cover"
}, B = t.int().min(0).max(107), re = t.string(), ie = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("initCube"),
		hex: B
	}),
	t.object({
		type: t.literal("question"),
		hex: B,
		target: re
	}),
	t.object({
		type: t.literal("search"),
		hex: B
	}),
	t.object({
		type: t.literal("searchDisc"),
		hex: B
	}),
	t.object({
		type: t.literal("placeCube"),
		hex: B
	}),
	t.object({
		type: t.literal("note"),
		hex: B,
		mark: t.enum([
			"yes",
			"no",
			"maybe"
		]).nullable()
	})
]), V = t.object({ advanced: t.boolean().default(!1) }).default({ advanced: !1 }), H = t.object({
	hex: B,
	type: t.enum(["stone", "shack"]),
	color: t.enum([
		"white",
		"green",
		"blue",
		"black"
	])
}), U = t.object({
	hex: B,
	seat: t.int().min(0),
	kind: t.enum(["cube", "disc"])
}), W = t.object({
	mode: t.enum(["normal", "advanced"]),
	players: t.array(re),
	map: t.object({
		tiles: t.array(t.int().min(1).max(12)),
		structures: t.array(H)
	}),
	pieces: t.array(U),
	phase: t.enum([
		"init",
		"turn",
		"searchDisc",
		"mustCube",
		"done"
	]),
	active: t.int().min(0),
	pendingHex: B.nullable(),
	last: t.object({
		kind: t.enum([
			"init",
			"question",
			"search",
			"cube"
		]),
		by: t.int().min(0),
		hex: B,
		target: t.int().min(0).optional(),
		answers: t.array(t.object({
			seat: t.int().min(0),
			answer: t.enum([
				"yes",
				"no",
				"pass"
			])
		})).optional()
	}).nullable(),
	reveal: t.object({
		clues: t.array(t.string()),
		solution: B,
		winner: t.int().min(0)
	}).nullable()
}), G = t.object({
	clue: t.string(),
	notes: t.record(t.string(), t.enum([
		"yes",
		"no",
		"maybe"
	]))
});
//#endregion
//#region src/games/cryptid/rules.ts
function K(e, t, n) {
	let r = R(n, t.length, e.advanced), i = {
		players: t,
		mode: e.advanced ? "advanced" : "normal",
		map: r.map,
		clues: r.clues,
		solution: r.solution,
		pieces: [],
		phase: "init",
		step: 0,
		active: 0,
		pendingHex: null,
		notes: {},
		last: null,
		winner: null
	};
	return {
		state: i,
		fx: [{
			kind: "setup",
			data: { mode: i.mode }
		}]
	};
}
function ae(e) {
	return E(e.map);
}
function q(e, t) {
	return e.pieces.some((e) => e.hex === t && e.kind === "cube");
}
function J(e, t, n) {
	return e.pieces.find((e) => e.hex === n && e.seat === t)?.kind ?? null;
}
function oe(e, t, n, r) {
	return !j(t, e.map.structures, r, e.clues[n]) && !q(e, r) && !J(e, n, r);
}
function se(e, t, n) {
	for (let r = 0; r < 108; r++) if (oe(e, t, n, r)) return !0;
	return !1;
}
function Y(e) {
	e.active = (e.active + 1) % e.players.length, e.phase = "turn", e.pendingHex = null;
}
function ce(e, t, n) {
	let r = [], i = [], a = e.players.length;
	for (let o = 1; o < a; o++) {
		let s = (e.active + o) % a;
		if (J(e, s, n) === "disc") {
			i.push({
				seat: s,
				answer: "pass"
			});
			continue;
		}
		let c = j(t, e.map.structures, n, e.clues[s]);
		if (e.pieces.push({
			hex: n,
			seat: s,
			kind: c ? "disc" : "cube"
		}), r.push({
			kind: "place",
			rid: e.players[s],
			data: {
				hex: n,
				piece: c ? "disc" : "cube"
			}
		}), i.push({
			seat: s,
			answer: c ? "yes" : "no"
		}), !c) return e.last = {
			kind: "search",
			by: e.active,
			hex: n,
			answers: i
		}, e.phase = "mustCube", r;
	}
	return e.last = {
		kind: "search",
		by: e.active,
		hex: n,
		answers: i
	}, e.phase = "done", e.winner = e.active, r.push({
		kind: "win",
		rid: e.players[e.active],
		data: { hex: n }
	}), r;
}
function le(e, t, n) {
	if (t.type === "note") {
		if (e.phase === "done") return { code: "games.cryptid.errNotYourTurn" };
		let r = structuredClone(e), i = r.notes[n.by] ??= {};
		return t.mark === null ? delete i[String(t.hex)] : i[String(t.hex)] = t.mark, {
			state: r,
			fx: []
		};
	}
	let r = e.players.indexOf(n.by);
	if (r === -1 || r !== e.active || e.phase === "done") return { code: "games.cryptid.errNotYourTurn" };
	let i = ae(e);
	if (t.type === "initCube") {
		if (e.phase !== "init") return { code: "games.cryptid.errNotYourTurn" };
		if (!oe(e, i, r, t.hex)) return { code: "games.cryptid.errBadHex" };
		let a = structuredClone(e);
		return a.pieces.push({
			hex: t.hex,
			seat: r,
			kind: "cube"
		}), a.last = {
			kind: "init",
			by: r,
			hex: t.hex
		}, a.step += 1, a.step >= a.players.length * 2 ? (a.phase = "turn", a.active = 0) : a.active = a.step % a.players.length, {
			state: a,
			fx: [{
				kind: "place",
				rid: n.by,
				data: {
					hex: t.hex,
					piece: "cube"
				}
			}]
		};
	}
	if (t.type === "question") {
		if (e.phase !== "turn") return { code: "games.cryptid.errNotYourTurn" };
		if (q(e, t.hex)) return { code: "games.cryptid.errBadHex" };
		let n = e.players.indexOf(t.target);
		if (n === -1 || n === r) return { code: "games.cryptid.errBadTarget" };
		let a = structuredClone(e), o = [], s = j(i, a.map.structures, t.hex, a.clues[n]), c;
		return J(a, n, t.hex) ? c = "yes" : (a.pieces.push({
			hex: t.hex,
			seat: n,
			kind: s ? "disc" : "cube"
		}), o.push({
			kind: "place",
			rid: t.target,
			data: {
				hex: t.hex,
				piece: s ? "disc" : "cube"
			}
		}), c = s ? "yes" : "no"), a.last = {
			kind: "question",
			by: r,
			hex: t.hex,
			target: n,
			answers: [{
				seat: n,
				answer: c
			}]
		}, c === "no" && se(a, i, r) ? (a.phase = "mustCube", a.pendingHex = null) : Y(a), {
			state: a,
			fx: o
		};
	}
	if (t.type === "search") {
		if (e.phase !== "turn") return { code: "games.cryptid.errNotYourTurn" };
		if (!j(i, e.map.structures, t.hex, e.clues[r]) || q(e, t.hex)) return { code: "games.cryptid.errBadHex" };
		let a = structuredClone(e), o = [];
		return J(a, r, t.hex) === "disc" ? (a.phase = "searchDisc", a.pendingHex = t.hex, {
			state: a,
			fx: o
		}) : (a.pieces.push({
			hex: t.hex,
			seat: r,
			kind: "disc"
		}), o.push({
			kind: "place",
			rid: n.by,
			data: {
				hex: t.hex,
				piece: "disc"
			}
		}), o.push(...ce(a, i, t.hex)), {
			state: a,
			fx: o
		});
	}
	if (t.type === "searchDisc") {
		if (e.phase !== "searchDisc" || e.pendingHex === null) return { code: "games.cryptid.errNotYourTurn" };
		if (t.hex === e.pendingHex || !j(i, e.map.structures, t.hex, e.clues[r]) || q(e, t.hex) || J(e, r, t.hex)) return { code: "games.cryptid.errBadHex" };
		let a = structuredClone(e), o = a.pendingHex;
		a.pendingHex = null, a.pieces.push({
			hex: t.hex,
			seat: r,
			kind: "disc"
		});
		let s = [{
			kind: "place",
			rid: n.by,
			data: {
				hex: t.hex,
				piece: "disc"
			}
		}];
		return s.push(...ce(a, i, o)), {
			state: a,
			fx: s
		};
	}
	if (e.phase !== "mustCube") return { code: "games.cryptid.errNotYourTurn" };
	if (!oe(e, i, r, t.hex)) return { code: "games.cryptid.errBadHex" };
	let a = structuredClone(e);
	return a.pieces.push({
		hex: t.hex,
		seat: r,
		kind: "cube"
	}), a.last = {
		kind: "cube",
		by: r,
		hex: t.hex
	}, Y(a), {
		state: a,
		fx: [{
			kind: "place",
			rid: n.by,
			data: {
				hex: t.hex,
				piece: "cube"
			}
		}]
	};
}
function ue(e, t) {
	let n = e.players.indexOf(t);
	return {
		public: {
			mode: e.mode,
			players: e.players,
			map: e.map,
			pieces: e.pieces,
			phase: e.phase,
			active: e.active,
			pendingHex: e.pendingHex,
			last: e.last,
			reveal: e.winner === null ? null : {
				clues: e.clues,
				solution: e.solution,
				winner: e.winner
			}
		},
		private: {
			clue: n >= 0 ? e.clues[n] : "",
			notes: e.notes[t] ?? {}
		}
	};
}
function de(e) {
	if (e.phase !== "done" || e.winner === null) return { phase: e.phase };
	let t = e.players[e.winner];
	return {
		phase: "done",
		winner: [t],
		ranking: [t, ...e.players.filter((t, n) => n !== e.winner)]
	};
}
var fe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: z,
	schemas: {
		action: ie,
		publicView: W,
		privateView: G,
		config: V
	},
	setup: K,
	reduce: le,
	viewFor: ue,
	status: de
}, X = 30, pe = Math.sqrt(3);
function Z(e) {
	let t = S(e) - 1, n = C(e) - 1;
	return [t * 1.5 * X, n * pe * X + (t & 1 ? pe * X / 2 : 0)];
}
var Q = `M${[
	0,
	1,
	2,
	3,
	4,
	5
].map((e) => {
	let t = Math.PI / 3 * e;
	return `${(X * Math.cos(t)).toFixed(2)},${(X * Math.sin(t)).toFixed(2)}`;
}).join("L")}Z`, me = {
	water: "#48b7c5",
	forest: "#346c51",
	desert: "#e5b955",
	mountain: "#89889a",
	swamp: "#71557e"
}, he = {
	white: "#f8f5e7",
	green: "#4ab37a",
	blue: "#60add8",
	black: "#33414a"
}, ge = {
	cougar: "🐆",
	bear: "🐻"
}, _e = {
	yes: "✓",
	no: "✕",
	maybe: "?"
}, ve = {
	yes: "fill-done-ink",
	no: "fill-rose-600",
	maybe: "fill-warn-ink"
}, $ = {
	minX: -39,
	maxX: 534,
	minY: -pe * X,
	maxY: 9 * pe * X + pe * X * .2
};
function ye(e, t) {
	if (e.w === 0) return {
		cx: 0,
		cy: 0,
		s: 1
	};
	let n = Math.min((e.w - 12) / ($.maxX - $.minX), (e.h - 12) / ($.maxY - $.minY));
	if (t != null) {
		let [e, r] = Z(t);
		return {
			cx: e,
			cy: r,
			s: Math.max(n, .86)
		};
	}
	return {
		cx: ($.minX + $.maxX) / 2,
		cy: ($.minY + $.maxY) / 2,
		s: n
	};
}
function be({ map: e, pieces: t, notes: c, active: l, selected: u, pendingHex: d, revealHex: f, lastHex: g, fitKey: _, colorOf: v, pieceAria: y, onTapHex: b, previewSeat: x, previewKind: S }) {
	let C = s(), w = r().replace(/:/g, ""), D = a(null), [O, k] = o({
		w: 0,
		h: 0
	}), [ee, A] = o(null), j = a({
		cx: 0,
		cy: 0,
		s: 1
	});
	n(() => {
		let e = D.current, t = new ResizeObserver(() => k({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let M = `${_}:${O.w}:${O.h}`, [te, ne] = o("");
	te !== M && O.w > 0 && (ne(M), A(ye(O, f)));
	let N = ee ?? ye(O, f);
	n(() => {
		j.current = N;
	}), n(() => {
		let e = D.current, t = (t) => {
			t.preventDefault();
			let n = e.getBoundingClientRect(), r = j.current, i = t.deltaY < 0 ? 1.15 : 1 / 1.15, a = Math.min(Math.max(r.s * i, .4), 3), o = t.clientX - n.left - n.width / 2, s = t.clientY - n.top - n.height / 2, c = r.cx + o / r.s, l = r.cy + s / r.s, u = {
				s: a,
				cx: c - o / a,
				cy: l - s / a
			};
			j.current = u, A(u);
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, []);
	let P = a(/* @__PURE__ */ new Map()), F = a(0), I = a(0), L = (e) => {
		if (e.currentTarget.setPointerCapture(e.pointerId), P.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), P.current.size === 1 && (F.current = 0), P.current.size === 2) {
			let [e, t] = [...P.current.values()];
			I.current = Math.hypot(e.x - t.x, e.y - t.y);
		}
	}, R = (e) => {
		let t = P.current.get(e.pointerId);
		if (!t) return;
		let n = D.current.getBoundingClientRect();
		if (P.current.size === 1) {
			let n = e.clientX - t.x, r = e.clientY - t.y;
			F.current += Math.abs(n) + Math.abs(r);
			let i = j.current, a = {
				...i,
				cx: i.cx - n / i.s,
				cy: i.cy - r / i.s
			};
			j.current = a, A(a);
		} else if (P.current.size === 2) {
			P.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			let [t, r] = [...P.current.values()], i = Math.hypot(t.x - r.x, t.y - r.y);
			if (I.current > 0 && i > 0) {
				let e = j.current, a = Math.min(Math.max(e.s * i / I.current, .4), 3), o = (t.x + r.x) / 2 - n.left - n.width / 2, s = (t.y + r.y) / 2 - n.top - n.height / 2, c = e.cx + o / e.s, l = e.cy + s / e.s, u = {
					s: a,
					cx: c - o / a,
					cy: l - s / a
				};
				j.current = u, A(u);
			}
			I.current = i, F.current = 99;
			return;
		}
		P.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
	}, z = (e) => {
		let t = P.current.size === 1 && F.current < 10;
		if (P.current.delete(e.pointerId), I.current = 0, !t || !b) return;
		let n = D.current.getBoundingClientRect(), r = j.current, i = r.cx + (e.clientX - n.left - n.width / 2) / r.s, a = r.cy + (e.clientY - n.top - n.height / 2) / r.s, o = -1, s = X * .95;
		for (let e = 0; e < 108; e++) {
			let [t, n] = Z(e), r = Math.hypot(t - i, n - a);
			r < s && (s = r, o = e);
		}
		if (!(o < 0)) {
			if (r.s * X * 1.5 < 44) {
				let [e, t] = Z(o), n = {
					cx: e,
					cy: t,
					s: Math.max(r.s, 1.02)
				};
				j.current = n, A(n);
				return;
			}
			(!l || l.has(o)) && b(o);
		}
	}, B = i(() => E(e), [e]), re = i(() => {
		let e = /* @__PURE__ */ new Map();
		for (let n of t) {
			let t = e.get(n.hex);
			t ? t.push(n) : e.set(n.hex, [n]);
		}
		return e;
	}, [t]), ie = i(() => {
		let t = /* @__PURE__ */ new Map();
		for (let n of e.structures) t.set(n.hex, n);
		return t;
	}, [e]), V = i(() => {
		let e = /* @__PURE__ */ new Set(), t = [];
		for (let n = 0; n < B.length; n++) {
			let r = B[n].animal;
			if (!r || e.has(n)) continue;
			let i = [], a = [n];
			for (e.add(n); a.length;) {
				let t = a.shift();
				i.push(t);
				for (let n = 0; n < B.length; n++) !e.has(n) && B[n].animal === r && T(t, n) === 1 && (e.add(n), a.push(n));
			}
			t.push({
				animal: r,
				hexes: i
			});
		}
		return t;
	}, [B]), H = (e, t, n, r, i = 1, a = !1) => /* @__PURE__ */ h("g", {
		transform: `translate(${n},${r}) scale(${i})`,
		opacity: a ? .7 : 1,
		role: a ? void 0 : "img",
		"aria-label": a ? void 0 : y?.(e, t),
		children: [t === "cube" ? /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("rect", {
				x: -11,
				y: -7,
				width: 23,
				height: 23,
				rx: 3,
				fill: "var(--color-cryptid-deep)",
				opacity: .35
			}),
			/* @__PURE__ */ m("path", {
				d: "M-11 -12h21l3 4v17h-24z",
				fill: v(e),
				stroke: "var(--color-cryptid-ink)",
				strokeWidth: 2.4
			}),
			/* @__PURE__ */ m("path", {
				d: "M-11 -12h21l3 4h-21z",
				fill: "var(--color-cryptid-paper)",
				opacity: .58
			})
		] }) : /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("circle", {
				cy: 3,
				r: 13,
				fill: "var(--color-cryptid-deep)",
				opacity: .35
			}),
			/* @__PURE__ */ m("circle", {
				r: 13,
				fill: v(e),
				fillOpacity: .86,
				stroke: "var(--color-cryptid-ink)",
				strokeWidth: 2.6
			}),
			/* @__PURE__ */ m("circle", {
				cx: -3,
				cy: -4,
				r: 5,
				fill: "white",
				opacity: .28
			})
		] }), /* @__PURE__ */ m("text", {
			y: 4,
			textAnchor: "middle",
			dominantBaseline: "central",
			fontSize: 12,
			fontWeight: 900,
			fill: "white",
			stroke: "var(--color-cryptid-deep)",
			strokeWidth: 2,
			paintOrder: "stroke",
			children: e + 1
		})]
	});
	return /* @__PURE__ */ m("div", {
		ref: D,
		className: "cryptid-board-viewport",
		children: /* @__PURE__ */ h("svg", {
			className: "cryptid-board-svg",
			role: "img",
			"aria-label": C("games.cryptid.mapAria"),
			onPointerDown: L,
			onPointerMove: R,
			onPointerUp: z,
			onPointerCancel: z,
			children: [/* @__PURE__ */ m("defs", { children: [
				"water",
				"forest",
				"desert",
				"mountain",
				"swamp"
			].map((e) => /* @__PURE__ */ m("pattern", {
				id: `${w}-${e}`,
				patternUnits: "userSpaceOnUse",
				width: 235,
				height: 235,
				children: /* @__PURE__ */ m("image", {
					href: `./games/cryptid/terrain-${e}.webp`,
					width: 235,
					height: 235
				})
			}, e)) }), /* @__PURE__ */ h("g", {
				transform: `translate(${O.w / 2 - N.cx * N.s}, ${O.h / 2 - N.cy * N.s}) scale(${N.s})`,
				children: [
					B.map((e, t) => {
						let [n, r] = Z(t);
						return /* @__PURE__ */ h("g", {
							transform: `translate(${n}, ${r})`,
							children: [
								/* @__PURE__ */ m("path", {
									d: Q,
									fill: me[e.terrain],
									stroke: "var(--color-cryptid-ink)",
									strokeWidth: 1.6
								}),
								/* @__PURE__ */ m("path", {
									d: Q,
									fill: `url(#${w}-${e.terrain})`,
									stroke: "var(--color-cryptid-ink)",
									strokeWidth: 1.4
								}),
								/* @__PURE__ */ m("path", {
									d: Q,
									transform: "scale(.93)",
									fill: "none",
									stroke: "var(--color-cryptid-paper)",
									strokeWidth: .7,
									opacity: .55
								}),
								l && !l.has(t) && /* @__PURE__ */ m("path", {
									d: Q,
									fill: "var(--color-cryptid-deep)",
									opacity: .25
								}),
								l?.has(t) && /* @__PURE__ */ m("path", {
									d: Q,
									fill: "none",
									stroke: "var(--color-cryptid-paper)",
									strokeWidth: 1.6,
									opacity: .72
								}),
								e.animal && /* @__PURE__ */ m("circle", {
									r: 23,
									fill: "none",
									stroke: "var(--color-cryptid-paper)",
									strokeWidth: 2,
									strokeDasharray: "3 4",
									opacity: .86
								})
							]
						}, t);
					}),
					V.map(({ animal: e, hexes: t }, n) => {
						let r = t.map(Z), i = r.reduce((e, t) => e + t[0], 0) / r.length, a = r.reduce((e, t) => e + t[1], 0) / r.length;
						return /* @__PURE__ */ h("g", {
							transform: `translate(${i},${a})`,
							pointerEvents: "none",
							role: "img",
							"aria-label": C(e === "bear" ? "games.cryptid.bearTerritory" : "games.cryptid.cougarTerritory"),
							children: [
								/* @__PURE__ */ m("circle", {
									cy: 2,
									r: 17,
									fill: "var(--color-cryptid-deep)",
									opacity: .35
								}),
								/* @__PURE__ */ m("circle", {
									r: 16,
									fill: "var(--color-cryptid-gold)",
									stroke: "var(--color-cryptid-ink)",
									strokeWidth: 2.4
								}),
								/* @__PURE__ */ m("text", {
									y: .5,
									textAnchor: "middle",
									dominantBaseline: "central",
									fontSize: 17,
									children: ge[e]
								})
							]
						}, `animal${n}`);
					}),
					e.structures.map((e) => {
						let [t, n] = Z(e.hex);
						return /* @__PURE__ */ h("g", {
							transform: `translate(${t},${n})`,
							pointerEvents: "none",
							role: "img",
							"aria-label": C(e.type === "stone" ? "games.cryptid.kindStone" : "games.cryptid.kindShack"),
							children: [
								/* @__PURE__ */ m("circle", {
									cy: 3,
									r: 18,
									fill: "var(--color-cryptid-deep)",
									opacity: .25
								}),
								/* @__PURE__ */ m("circle", {
									r: 17,
									fill: "var(--color-cryptid-paper)",
									stroke: "var(--color-cryptid-ink)",
									strokeWidth: 2
								}),
								e.type === "stone" ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
									d: "M-9 9L-12 -2L-5 -12L5 -12L12 -2L9 9Z",
									fill: "var(--color-cryptid-mat)",
									stroke: "var(--color-cryptid-ink)",
									strokeWidth: 2.6
								}), /* @__PURE__ */ m("path", {
									d: "M-4 -10L-1 5L8 8",
									fill: "none",
									stroke: "var(--color-cryptid-line)",
									strokeWidth: 2
								})] }) : /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("path", {
									d: "M-12 5L-2 -11L9 -7L13 9L-12 9Z",
									fill: "var(--color-cryptid-gold)",
									stroke: "var(--color-cryptid-ink)",
									strokeWidth: 2.6
								}), /* @__PURE__ */ m("path", {
									d: "M-4 9L-3 0L4 0L5 9",
									fill: "var(--color-cryptid-deep)",
									stroke: "var(--color-cryptid-ink)",
									strokeWidth: 1.5
								})] }),
								/* @__PURE__ */ m("circle", {
									cx: 11,
									cy: -11,
									r: 5.5,
									fill: he[e.color],
									stroke: "var(--color-cryptid-ink)",
									strokeWidth: 1.8
								})
							]
						}, `s${e.hex}`);
					}),
					g != null && (() => {
						let [e, t] = Z(g);
						return /* @__PURE__ */ m("path", {
							className: "cryptid-last-ring",
							d: Q,
							transform: `translate(${e}, ${t}) scale(1.06)`,
							fill: "none",
							stroke: "var(--color-cryptid-gold)",
							strokeWidth: 3,
							opacity: .8,
							pointerEvents: "none"
						}, g);
					})(),
					d != null && (() => {
						let [e, t] = Z(d);
						return /* @__PURE__ */ m("path", {
							d: Q,
							transform: `translate(${e}, ${t}) scale(1.1)`,
							fill: "none",
							className: "stroke-warn-ink",
							strokeWidth: 4,
							pointerEvents: "none"
						});
					})(),
					u != null && (() => {
						let [e, t] = Z(u);
						return /* @__PURE__ */ h("g", {
							pointerEvents: "none",
							children: [/* @__PURE__ */ m("path", {
								d: Q,
								transform: `translate(${e}, ${t}) scale(1.09)`,
								fill: "var(--color-cryptid-paper)",
								fillOpacity: .18,
								stroke: "var(--color-cryptid-paper)",
								strokeWidth: 4
							}), /* @__PURE__ */ m("path", {
								d: Q,
								transform: `translate(${e}, ${t}) scale(1.12)`,
								fill: "none",
								stroke: "var(--color-cryptid-deep)",
								strokeWidth: 2.5
							})]
						});
					})(),
					[...re.entries()].map(([e, t]) => {
						let [n, r] = Z(e), i = ie.has(e) ? X * .38 : 0, a = t.find((e) => e.kind === "cube"), o = t.filter((e) => e.kind === "disc");
						return /* @__PURE__ */ h("g", {
							transform: `translate(${n}, ${r + i})`,
							pointerEvents: "none",
							children: [a && H(a.seat, "cube", 0, 0), o.map((e, t) => {
								let n = o.length, r = n === 1 ? 0 : -Math.PI / 2 + Math.PI * 2 * t / n, i = n === 1 ? 0 : X * .36;
								return /* @__PURE__ */ m("g", { children: H(e.seat, "disc", i * Math.cos(r), i * Math.sin(r), n > 2 ? .77 : 1) }, `${e.seat}-${t}`);
							})]
						}, `p${e}`);
					}),
					u != null && x != null && S && (() => {
						let [e, t] = Z(u);
						return /* @__PURE__ */ m("g", {
							pointerEvents: "none",
							children: H(x, S, e, t, 1, !0)
						});
					})(),
					c && Object.entries(c).map(([e, t]) => {
						let [n, r] = Z(Number(e));
						return /* @__PURE__ */ h("g", {
							transform: `translate(${n + X * .5}, ${r - X * .58})`,
							pointerEvents: "none",
							children: [/* @__PURE__ */ m("circle", {
								r: 9.5,
								fill: "var(--color-cryptid-paper)",
								stroke: "var(--color-cryptid-ink)",
								strokeWidth: 2
							}), /* @__PURE__ */ m("text", {
								y: .5,
								textAnchor: "middle",
								dominantBaseline: "central",
								fontSize: 12,
								fontWeight: 900,
								className: ve[t],
								children: _e[t]
							})]
						}, `n${e}`);
					}),
					f != null && (() => {
						let [e, t] = Z(f);
						return /* @__PURE__ */ h("g", {
							transform: `translate(${e}, ${t})`,
							pointerEvents: "none",
							children: [
								/* @__PURE__ */ m("path", {
									d: Q,
									transform: "scale(1.14)",
									fill: "var(--color-cryptid-paper)",
									fillOpacity: .28,
									stroke: "var(--color-cryptid-gold)",
									strokeWidth: 5
								}),
								/* @__PURE__ */ m("circle", {
									r: 19,
									fill: "var(--color-cryptid-gold)",
									stroke: "var(--color-cryptid-deep)",
									strokeWidth: 3
								}),
								/* @__PURE__ */ m("text", {
									y: 1,
									textAnchor: "middle",
									dominantBaseline: "central",
									fontSize: 22,
									children: "👣"
								})
							]
						});
					})()
				]
			})]
		})
	});
}
//#endregion
//#region src/games/cryptid/clue-text.ts
var xe = {
	within_forest: "games.cryptid.clue.within_forest",
	within_water: "games.cryptid.clue.within_water",
	within_swamp: "games.cryptid.clue.within_swamp",
	within_mountain: "games.cryptid.clue.within_mountain",
	within_desert: "games.cryptid.clue.within_desert",
	within_animal: "games.cryptid.clue.within_animal",
	within_animal_cougar: "games.cryptid.clue.within_animal_cougar",
	within_animal_bear: "games.cryptid.clue.within_animal_bear",
	within_stone: "games.cryptid.clue.within_stone",
	within_shack: "games.cryptid.clue.within_shack",
	within_green: "games.cryptid.clue.within_green",
	within_blue: "games.cryptid.clue.within_blue",
	within_white: "games.cryptid.clue.within_white",
	within_black: "games.cryptid.clue.within_black",
	desert_or_swamp: "games.cryptid.clue.desert_or_swamp",
	forest_or_mountain: "games.cryptid.clue.forest_or_mountain",
	forest_or_swamp: "games.cryptid.clue.forest_or_swamp",
	mountain_or_swamp: "games.cryptid.clue.mountain_or_swamp",
	water_or_desert: "games.cryptid.clue.water_or_desert",
	water_or_forest: "games.cryptid.clue.water_or_forest",
	water_or_swamp: "games.cryptid.clue.water_or_swamp",
	water_or_mountain: "games.cryptid.clue.water_or_mountain",
	forest_or_desert: "games.cryptid.clue.forest_or_desert",
	desert_or_mountain: "games.cryptid.clue.desert_or_mountain",
	not_within_forest: "games.cryptid.clue.not_within_forest",
	not_within_water: "games.cryptid.clue.not_within_water",
	not_within_swamp: "games.cryptid.clue.not_within_swamp",
	not_within_mountain: "games.cryptid.clue.not_within_mountain",
	not_within_desert: "games.cryptid.clue.not_within_desert",
	not_within_animal: "games.cryptid.clue.not_within_animal",
	not_within_animal_cougar: "games.cryptid.clue.not_within_animal_cougar",
	not_within_animal_bear: "games.cryptid.clue.not_within_animal_bear",
	not_within_stone: "games.cryptid.clue.not_within_stone",
	not_within_shack: "games.cryptid.clue.not_within_shack",
	not_within_green: "games.cryptid.clue.not_within_green",
	not_within_blue: "games.cryptid.clue.not_within_blue",
	not_within_white: "games.cryptid.clue.not_within_white",
	not_within_black: "games.cryptid.clue.not_within_black",
	not_desert_or_swamp: "games.cryptid.clue.not_desert_or_swamp",
	not_forest_or_mountain: "games.cryptid.clue.not_forest_or_mountain",
	not_forest_or_swamp: "games.cryptid.clue.not_forest_or_swamp",
	not_mountain_or_swamp: "games.cryptid.clue.not_mountain_or_swamp",
	not_water_or_desert: "games.cryptid.clue.not_water_or_desert",
	not_water_or_forest: "games.cryptid.clue.not_water_or_forest",
	not_water_or_swamp: "games.cryptid.clue.not_water_or_swamp",
	not_water_or_mountain: "games.cryptid.clue.not_water_or_mountain",
	not_forest_or_desert: "games.cryptid.clue.not_forest_or_desert",
	not_desert_or_mountain: "games.cryptid.clue.not_desert_or_mountain"
}, Se = [
	void 0,
	"yes",
	"no",
	"maybe"
], Ce = {
	water: "games.cryptid.terrain.water",
	forest: "games.cryptid.terrain.forest",
	desert: "games.cryptid.terrain.desert",
	mountain: "games.cryptid.terrain.mountain",
	swamp: "games.cryptid.terrain.swamp"
};
function we(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ m(Te, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Te({ pub: e, priv: t, members: r, myRid: a, send: g }) {
	let _ = s(), v = e.players.indexOf(a), [y, b] = o("question"), [x, w] = o(null), [T, D] = o(null), [O, k] = o(0), [ee, A] = o(() => window.matchMedia("(orientation: landscape) and (max-height: 480px)").matches);
	n(() => {
		let e = window.matchMedia("(orientation: landscape) and (max-height: 480px)"), t = () => A(e.matches);
		return e.addEventListener("change", t), () => e.removeEventListener("change", t);
	}, []);
	let M = e.active === v && e.phase !== "done", [te, ne] = o(""), N = `${e.phase}:${e.active}:${e.pieces.length}`;
	te !== N && (ne(N), w(null), D(null));
	let P = i(() => E(e.map), [e.map]), F = i(() => new Set(e.pieces.filter((e) => e.kind === "cube").map((e) => e.hex)), [e.pieces]), I = i(() => new Set(e.pieces.filter((e) => e.seat === v).map((e) => e.hex)), [e.pieces, v]), L = (t) => l[(r.find((n) => n.rid === e.players[t])?.colorIndex ?? 0) % l.length].hex, R = (e) => r.find((t) => t.rid === e)?.name ?? e, B = i(() => {
		if (!M || y === "note") return;
		let n = /* @__PURE__ */ new Set();
		for (let r = 0; r < 108; r++) e.phase === "init" || e.phase === "mustCube" ? !j(P, e.map.structures, r, t.clue) && !F.has(r) && !I.has(r) && n.add(r) : e.phase === "searchDisc" ? r !== e.pendingHex && j(P, e.map.structures, r, t.clue) && !F.has(r) && !I.has(r) && n.add(r) : y === "question" ? F.has(r) || n.add(r) : y === "search" && j(P, e.map.structures, r, t.clue) && !F.has(r) && n.add(r);
		return n;
	}, [
		M,
		y,
		e.phase,
		e.pendingHex,
		P,
		e.map.structures,
		t.clue,
		F,
		I
	]), re = (n) => {
		if (y === "note") {
			let e = t.notes[String(n)], r = Se[(Se.indexOf(e) + 1) % Se.length];
			g({
				type: "note",
				hex: n,
				mark: r ?? null
			});
			return;
		}
		M && B?.has(n) && (w(n), (e.phase !== "turn" || y === "search") && D(null));
	}, ie = () => {
		if (x !== null) {
			if (e.phase === "init") g({
				type: "initCube",
				hex: x
			});
			else if (e.phase === "mustCube") g({
				type: "placeCube",
				hex: x
			});
			else if (e.phase === "searchDisc") g({
				type: "searchDisc",
				hex: x
			});
			else if (y === "search") g({
				type: "search",
				hex: x
			});
			else if (y === "question" && T) g({
				type: "question",
				hex: x,
				target: T
			});
			else return;
			w(null), D(null);
		}
	}, V, H, U = R(e.players[e.active] ?? "");
	e.phase === "init" ? (V = M ? "accent" : "info", H = M ? _("games.cryptid.initPlace") : _("games.cryptid.waitInit", { name: U })) : e.phase === "mustCube" ? (V = M ? "warn" : "info", H = M ? _("games.cryptid.mustCube") : _("games.cryptid.waitTurn", { name: U })) : e.phase === "searchDisc" ? (V = M ? "warn" : "info", H = M ? _("games.cryptid.searchDisc") : _("games.cryptid.waitTurn", { name: U })) : (V = M ? "accent" : "info", H = M ? _("games.cryptid.yourTurn") : _("games.cryptid.waitTurn", { name: U }));
	let W = null;
	if (e.last) {
		let t = R(e.players[e.last.by] ?? "");
		if (e.last.kind === "init") W = _("games.cryptid.evInit", { name: t });
		else if (e.last.kind === "cube") W = _("games.cryptid.evCube", { name: t });
		else if (e.last.kind === "search") W = _("games.cryptid.evSearch", { name: t });
		else if (e.last.kind === "question") {
			let n = e.last.answers?.[0]?.answer, r = _(n === "no" ? "games.cryptid.answerNo" : n === "pass" ? "games.cryptid.answerPass" : "games.cryptid.answerYes");
			W = `${_("games.cryptid.evQuestion", {
				name: t,
				target: R(e.players[e.last.target ?? 0] ?? "")
			})} → ${r}`;
		}
	}
	let G = (e, t) => /* @__PURE__ */ m("button", {
		type: "button",
		className: "cryptid-mode",
		"aria-pressed": y === e,
		onClick: () => {
			b(y === e && e === "note" ? "question" : e), w(null), D(null);
		},
		children: _(t)
	}, e), K = y === "note", ae = e.phase === "turn" && M && y === "question" && x !== null, q = x === null ? null : _("games.cryptid.selectedHex", {
		col: String.fromCharCode(64 + S(x)),
		row: C(x),
		terrain: _(Ce[P[x].terrain])
	}), J = K ? _("games.cryptid.noteHint") : q ?? (M ? _(e.phase === "init" || e.phase === "mustCube" ? "games.cryptid.pickHexCube" : e.phase === "searchDisc" ? "games.cryptid.pickHexDisc" : y === "search" ? "games.cryptid.pickHexSearch" : "games.cryptid.pickHexQuestion") : _("games.cryptid.waitTurn", { name: U })), oe = M && !K && x !== null && (!ae || T !== null), se = K ? _("games.cryptid.modeNote") : e.phase === "turn" && y === "search" ? _("games.cryptid.confirmSearch") : e.phase === "turn" ? _("games.cryptid.confirmQuestion") : _("games.cryptid.confirmPlace"), Y = x !== null && !K && M ? e.phase === "init" || e.phase === "mustCube" ? "cube" : e.phase === "searchDisc" || y === "search" ? "disc" : void 0 : void 0, ce = K ? _("games.cryptid.actionNote") : M ? e.phase === "init" || e.phase === "mustCube" ? _("games.cryptid.actionCube") : e.phase === "searchDisc" || y === "search" ? _("games.cryptid.actionDisc") : _("games.cryptid.actionQuestion") : _("games.cryptid.actionWaiting"), le = q ? ce : _(K ? "games.cryptid.noteZoomHint" : M ? "games.cryptid.zoomHint" : "games.cryptid.browseHint");
	return /* @__PURE__ */ m(d, {
		adaptive: !0,
		scroll: !1,
		className: "cryptid-adaptive",
		children: /* @__PURE__ */ h("div", {
			className: "cryptid-screen",
			children: [/* @__PURE__ */ h("div", {
				className: "cryptid-sidebar",
				children: [/* @__PURE__ */ h("div", {
					className: "cryptid-top",
					children: [/* @__PURE__ */ m(u, {
						tone: V,
						text: H,
						accent: z.accent
					}), /* @__PURE__ */ m("div", {
						className: "cryptid-players",
						children: /* @__PURE__ */ m(f, {
							members: r.filter((t) => e.players.includes(t.rid)),
							myRid: a,
							variant: ee ? "mini" : "medal",
							anchorOf: (e) => `seat:${e}`,
							action: (t) => e.phase !== "done" && t === e.players[e.active] ? "pending" : null
						})
					})]
				}), /* @__PURE__ */ h("div", {
					className: "cryptid-side",
					children: [/* @__PURE__ */ h("div", {
						className: "cryptid-clue",
						children: [/* @__PURE__ */ h("div", {
							className: "flex min-w-0 items-center gap-2",
							children: [
								/* @__PURE__ */ m("span", {
									"aria-hidden": !0,
									className: "cryptid-clue-icon grid size-8 flex-none place-items-center rounded-lg border border-cryptid-ink bg-cryptid-gold text-lg",
									children: "⌕"
								}),
								/* @__PURE__ */ h("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ m("div", {
										className: "cryptid-clue-title",
										children: _("games.cryptid.myClue")
									}), /* @__PURE__ */ m("div", {
										className: "cryptid-clue-value",
										children: _(xe[t.clue] ?? "games.cryptid.myClue")
									})]
								}),
								/* @__PURE__ */ m("span", {
									className: "cryptid-clue-secret",
									children: _("games.cryptid.clueHidden")
								})
							]
						}), /* @__PURE__ */ h("div", {
							className: "cryptid-clue-legend",
							children: [
								"■ ",
								_("games.cryptid.kindCube"),
								" · ● ",
								_("games.cryptid.kindDisc"),
								" · ",
								_("games.cryptid.legendShort")
							]
						})]
					}), /* @__PURE__ */ h("div", {
						className: "cryptid-actions",
						children: [
							/* @__PURE__ */ m("div", {
								className: "cryptid-mode-row",
								children: e.phase === "turn" && M ? /* @__PURE__ */ h(p, { children: [
									G("question", "games.cryptid.modeQuestion"),
									G("search", "games.cryptid.modeSearch"),
									G("note", "games.cryptid.modeNote")
								] }) : /* @__PURE__ */ h(p, { children: [
									/* @__PURE__ */ m("div", {
										className: "cryptid-note-toggle",
										children: G("note", "games.cryptid.modeNote")
									}),
									K && /* @__PURE__ */ m("button", {
										type: "button",
										className: "cryptid-mode",
										onClick: () => {
											b("question"), w(null);
										},
										children: _("games.cryptid.backToAction")
									}),
									/* @__PURE__ */ m("span", {
										className: "cryptid-mode-context",
										children: ce
									})
								] })
							}),
							/* @__PURE__ */ m("div", {
								className: "cryptid-selection",
								title: J,
								children: J
							}),
							/* @__PURE__ */ m("div", {
								className: "cryptid-target-row",
								children: ae ? e.players.filter((e) => e !== a).map((t) => /* @__PURE__ */ h("button", {
									type: "button",
									className: "cryptid-target",
									"aria-pressed": T === t,
									onClick: () => D(t),
									children: [
										/* @__PURE__ */ m("span", {
											"aria-hidden": !0,
											className: "mr-1 inline-block size-3 rounded-full border border-cryptid-ink align-middle",
											style: { backgroundColor: L(e.players.indexOf(t)) }
										}),
										R(t),
										T === t ? " ✓" : ""
									]
								}, t)) : /* @__PURE__ */ h("div", {
									className: "cryptid-action-preview",
									children: [/* @__PURE__ */ m("span", {
										className: `cryptid-action-piece ${Y === "disc" ? "cryptid-action-piece--disc" : ""}`,
										style: { backgroundColor: L(Math.max(0, v)) },
										children: Math.max(0, v) + 1
									}), /* @__PURE__ */ m("span", { children: le })]
								})
							}),
							/* @__PURE__ */ m("button", {
								type: "button",
								className: "cryptid-confirm",
								disabled: !oe,
								onClick: ie,
								children: se
							})
						]
					})]
				})]
			}), /* @__PURE__ */ h("div", {
				className: "cryptid-map",
				children: [
					/* @__PURE__ */ h("div", {
						className: "cryptid-map-head",
						children: [/* @__PURE__ */ h("span", { children: ["✦ ", _("games.cryptid.mapTitle")] }), /* @__PURE__ */ m("small", { children: _("games.cryptid.mapCount") })]
					}),
					/* @__PURE__ */ m("div", {
						className: "cryptid-map-canvas",
						children: /* @__PURE__ */ m(be, {
							map: e.map,
							pieces: e.pieces,
							notes: t.notes,
							active: B,
							selected: x,
							pendingHex: e.phase === "searchDisc" ? e.pendingHex : null,
							revealHex: e.reveal?.solution ?? null,
							lastHex: e.last?.hex ?? null,
							fitKey: String(O),
							colorOf: L,
							pieceAria: (t, n) => _("games.cryptid.pieceAria", {
								name: R(e.players[t] ?? ""),
								kind: _(n === "cube" ? "games.cryptid.kindCube" : "games.cryptid.kindDisc")
							}),
							onTapHex: re,
							previewSeat: Y ? v : void 0,
							previewKind: Y
						})
					}),
					W && /* @__PURE__ */ m("div", {
						className: "cryptid-map-event",
						title: W,
						children: W
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						"aria-label": _("games.cryptid.recenter"),
						onClick: () => k((e) => e + 1),
						className: "cryptid-map-recenter",
						children: /* @__PURE__ */ m(c, {
							size: 20,
							"aria-hidden": !0
						})
					}),
					/* @__PURE__ */ h("div", {
						className: "cryptid-map-foot",
						children: [/* @__PURE__ */ m("span", { children: _("games.cryptid.terrainLegend") }), [
							"water",
							"forest",
							"desert",
							"mountain",
							"swamp"
						].map((e) => /* @__PURE__ */ h("span", {
							className: "flex items-center gap-0.5 whitespace-nowrap",
							children: [/* @__PURE__ */ m("span", {
								"aria-hidden": !0,
								className: "cryptid-terrain-chip",
								style: { backgroundImage: `url(./games/cryptid/terrain-${e}.webp)` }
							}), _(Ce[e])]
						}, e))]
					})
				]
			})]
		})
	});
}
//#endregion
//#region src/games/cryptid/bot.ts
var Ee = {
	gambleAt: 2,
	gambleProb: .5,
	clusterBonus: 1
};
function De(e, t) {
	return !j(e.cells, e.structures, t, e.myClue) && !e.cubeHexes.has(t) && !e.myPieces.has(t);
}
function Oe(e, t, n) {
	let r = [];
	for (let t = 0; t < 108; t++) De(e, t) && r.push(t);
	if (r.length === 0) return null;
	let i = [...e.myPieces].filter((t) => e.pub.pieces.some((e) => e.hex === t && e.kind === "cube")), a = r.map((e) => ({
		hex: e,
		score: n() + t.clusterBonus * i.filter((t) => T(t, e) <= 2).length
	}));
	return a.sort((e, t) => t.score - e.score), a[0].hex;
}
function ke(e) {
	let t = O(e.pub.mode === "advanced"), n = /* @__PURE__ */ new Map();
	for (let r = 0; r < e.pub.players.length; r++) {
		if (r === e.seat) continue;
		let i = t.filter((t) => e.pub.pieces.every((n) => n.seat !== r || j(e.cells, e.structures, n.hex, t) === (n.kind === "disc")));
		n.set(r, i);
	}
	let r = [];
	for (let t = 0; t < 108; t++) {
		if (e.cubeHexes.has(t) || !j(e.cells, e.structures, t, e.myClue)) continue;
		let i = !0;
		for (let [, r] of n) if (r.length === 0 || !r.some((n) => j(e.cells, e.structures, t, n))) {
			i = !1;
			break;
		}
		i && r.push(t);
	}
	return r;
}
function Ae(e, t, n) {
	let r = O(e.pub.mode === "advanced"), i = null;
	for (let n = 0; n < e.pub.players.length; n++) {
		if (n === e.seat) continue;
		let a = r.filter((t) => e.pub.pieces.every((r) => r.seat !== n || j(e.cells, e.structures, r.hex, t) === (r.kind === "disc")));
		if (!(a.length <= 1)) for (let r of t) {
			let t = a.filter((t) => j(e.cells, e.structures, r, t)).length, o = Math.min(t, a.length - t);
			o > 0 && (!i || o > i.score) && (i = {
				hex: r,
				seat: n,
				score: o
			});
		}
	}
	if (i) return {
		hex: i.hex,
		target: e.pub.players[i.seat]
	};
	let a = e.pub.players.map((e, t) => t).filter((t) => t !== e.seat), o = a[Math.floor(n() * a.length)];
	return {
		hex: t[Math.floor(n() * t.length)],
		target: e.pub.players[o]
	};
}
function je(e = {}) {
	let t = {
		...Ee,
		...e
	}, n = 0, r = () => (n = n * 1103515245 + 12345 & 2147483647, n / 2147483647);
	return (e, n) => {
		let i = e.public, a = e.private;
		if (!a) return null;
		let o = i.players.indexOf(n.rid);
		if (o === -1 || i.phase === "done") return null;
		let s = E(i.map), c = {
			pub: i,
			seat: o,
			cells: s,
			structures: i.map.structures,
			myClue: a.clue,
			cubeHexes: new Set(i.pieces.filter((e) => e.kind === "cube").map((e) => e.hex)),
			myPieces: new Set(i.pieces.filter((e) => e.seat === o).map((e) => e.hex))
		}, l = n.difficulty === "weak";
		if (i.phase === "init") {
			if (i.active !== o) return null;
			let e = [];
			for (let t = 0; t < 108; t++) De(c, t) && e.push(t);
			let n = l ? e[Math.floor(r() * e.length)] : Oe(c, t, r);
			return n === null ? null : { action: {
				type: "initCube",
				hex: n
			} };
		}
		if (i.active !== o) return null;
		if (i.phase === "mustCube") {
			let e = [];
			for (let t = 0; t < 108; t++) De(c, t) && e.push(t);
			let n = l ? e[Math.floor(r() * e.length)] : Oe(c, t, r);
			return n === null ? null : { action: {
				type: "placeCube",
				hex: n
			} };
		}
		if (i.phase === "searchDisc") {
			let e = [];
			for (let t = 0; t < 108; t++) t !== i.pendingHex && j(s, c.structures, t, c.myClue) && !c.cubeHexes.has(t) && !c.myPieces.has(t) && e.push(t);
			return e.length === 0 ? null : { action: {
				type: "searchDisc",
				hex: e[Math.floor(r() * e.length)]
			} };
		}
		let u = ke(c);
		if (u.length === 0) {
			let e = [];
			for (let t = 0; t < 108; t++) c.cubeHexes.has(t) || e.push(t);
			let t = i.players.filter((e) => e !== n.rid);
			return { action: {
				type: "question",
				hex: e[Math.floor(r() * e.length)],
				target: t[Math.floor(r() * t.length)]
			} };
		}
		if (l ? r() < .08 : u.length === 1 || u.length <= t.gambleAt && r() < t.gambleProb) return { action: {
			type: "search",
			hex: u[Math.floor(r() * u.length)]
		} };
		if (l) {
			let e = i.players.filter((e) => e !== n.rid);
			return { action: {
				type: "question",
				hex: u[Math.floor(r() * u.length)],
				target: e[Math.floor(r() * e.length)]
			} };
		}
		let d = Ae(c, u, r);
		return d ? { action: {
			type: "question",
			...d
		} } : null;
	};
}
var Me = je(), Ne = (e, t, n) => {
	switch (e.type) {
		case "initCube": return n("games.cryptid.initPlace");
		case "question": return n("games.cryptid.hintQuestion");
		case "search": return n("games.cryptid.confirmSearch");
		case "searchDisc": return n("games.cryptid.searchDisc");
		case "placeCube": return n("games.cryptid.mustCube");
		default: return "";
	}
}, Pe = {
	setup() {
		return null;
	},
	place(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ m(g, {
				at: n,
				ms: 600
			})
		} : null;
	},
	win(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ m(g, {
				at: n,
				ms: 900
			})
		} : null;
	}
};
//#endregion
//#region src/games/cryptid/game-over.tsx
function Fe({ result: e, public: t, members: n, onPlayAgain: r, onBackToLobby: i }) {
	let a = s(), o = t, c = (e) => n.find((t) => t.rid === e)?.name ?? e, u = (e) => l[(n.find((t) => t.rid === o.players[e])?.colorIndex ?? 0) % l.length].hex, d = r ?? i, f = o.reveal;
	return /* @__PURE__ */ m("div", {
		className: "cryptid-over-shell",
		children: /* @__PURE__ */ h("div", {
			className: "cryptid-over",
			children: [
				e.winner.length > 0 && /* @__PURE__ */ m(_, {}),
				/* @__PURE__ */ h("h1", {
					className: "flex flex-none items-center justify-center gap-2 text-center font-display text-xl font-extrabold",
					children: [/* @__PURE__ */ m("span", {
						"aria-hidden": !0,
						children: z.icon
					}), a("games.cryptid.revealTitle")]
				}),
				f && /* @__PURE__ */ m("div", {
					className: "cryptid-over-map",
					children: /* @__PURE__ */ m(be, {
						map: o.map,
						pieces: o.pieces,
						revealHex: f.solution,
						fitKey: "over",
						colorOf: u
					})
				}),
				/* @__PURE__ */ h("div", {
					className: "cryptid-over-details",
					children: [f && /* @__PURE__ */ h("section", {
						className: "cryptid-over-clues",
						children: [/* @__PURE__ */ m("p", {
							className: "section-label",
							children: a("games.cryptid.revealClues")
						}), /* @__PURE__ */ m("ul", {
							className: "mt-1 flex flex-col gap-1",
							children: o.players.map((e, t) => /* @__PURE__ */ h("li", {
								className: "cryptid-over-clue flex items-baseline gap-1.5 text-xs font-bold",
								children: [
									/* @__PURE__ */ m("span", {
										"aria-hidden": !0,
										className: "cryptid-over-seat inline-grid size-5 flex-none translate-y-0.5 place-items-center rounded border border-cryptid-ink text-[10px] font-black text-white",
										style: { backgroundColor: u(t) },
										children: t + 1
									}),
									/* @__PURE__ */ h("span", {
										className: "cryptid-over-name flex-none",
										children: [f.winner === t ? "🏆 " : "", c(e)]
									}),
									/* @__PURE__ */ m("span", {
										className: "cryptid-over-clue-text min-w-0 flex-1 opacity-80",
										children: a(xe[f.clues[t]] ?? "games.cryptid.myClue")
									})
								]
							}, e))
						})]
					}), d ? /* @__PURE__ */ h("div", {
						className: "cryptid-over-actions safe-b pb-1",
						children: [r && /* @__PURE__ */ m("button", {
							className: "cryptid-confirm cursor-pointer",
							onClick: r,
							children: a("session.result.playAgain")
						}), i && /* @__PURE__ */ m("button", {
							className: "btn-quiet w-full cursor-pointer",
							onClick: i,
							children: a("session.result.backToLobby")
						})]
					}) : /* @__PURE__ */ m("p", {
						className: "safe-b flex-none pb-1 text-sm font-bold opacity-70",
						children: a("session.result.waitHost")
					})]
				})
			]
		})
	});
}
//#endregion
//#region src/games/cryptid/options.tsx
function Ie({ value: e, onChange: t }) {
	let n = s(), r = V.safeParse(e), i = r.success ? r.data : V.parse(void 0);
	return /* @__PURE__ */ h("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ m(y, {
			title: n("games.cryptid.optMode"),
			children: [!1, !0].map((e) => /* @__PURE__ */ m(v, {
				name: "cryptid-mode",
				value: String(e),
				checked: i.advanced === e,
				label: n(e ? "games.cryptid.optAdvanced" : "games.cryptid.optNormal"),
				accent: z.accent,
				onChange: () => t({
					...i,
					advanced: e
				})
			}, String(e)))
		}), /* @__PURE__ */ m("p", {
			className: "text-xs opacity-60",
			children: n("games.cryptid.optModeHint")
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/cryptid/entry.tsx
var Le = {
	definition: fe,
	View: we,
	bot: Me,
	describe: Ne,
	fx: Pe,
	OverView: Fe,
	Options: Ie,
	locales: {
		zh: {
			name: "诡影寻踪",
			desc: "每人一条秘密线索,推理神秘生物的唯一栖息地",
			rules: "目标:率先综合所有人的线索,找到神秘生物唯一的栖息地。\n准备:版图由 6 块板块随机拼成;每位玩家秘密获得一条关于栖息地的线索(仅自己可见),所有人线索的交集只有 1 格。\n初始放置:\n· 从起始玩家开始顺时针,每人轮流把自己的 2 个方块放到「按自己线索不可能是栖息地」的格子,每次 1 个,共 2 轮。\n流程(每回合二选一):\n· 问人:任选 1 个没有方块的格子,指定 1 名其他玩家。\n· 系统按对方线索自动作答:可能是栖息地则放对方的圆片,不可能则放对方的方块。\n· 若对方放了方块,你必须再把自己的 1 个方块放到按你线索不可能是栖息地的格子。\n· 搜索:选 1 个按你线索可能是栖息地且没有方块的格子,先放上自己的圆片。\n· 其余玩家从你左手边开始依次自动作答:全部放圆片则你直接获胜;一旦有人放方块,搜索中止,你同样须再放 1 个自己的方块。\n约束:\n· 有方块的格子不能再放任何标记,也不能再问人或搜索。\n· 同一格子不能放自己的第二个标记;圆片可以多人叠放。\n· 任何时刻都可给格子做私人笔记(✓/✗/?),仅自己可见。\n结束:有人搜索成功即获胜,终局揭示所有人的线索与栖息地。\n线索一览(距离均含所在格本身):\n· 在两种地形之一上(如「在森林或沼泽上」)。\n· 距某种地形 1 格以内;距熊或狮的领地 1 格以内。\n· 距立石或棚屋 2 格以内;距熊或狮的领地 2 格以内。\n· 距某种颜色的结构物 3 格以内。\n· 进阶模式另含以上全部线索的否定式。",
			optMode: "模式",
			optNormal: "普通",
			optAdvanced: "进阶",
			optModeHint: "进阶模式加入否定式线索,8 个结构物全部上场",
			myClue: "我的线索",
			clueHidden: "仅自己可见",
			modeQuestion: "问人",
			modeSearch: "搜索",
			modeNote: "笔记",
			pickHexQuestion: "点选要问的格子",
			pickHexSearch: "点选要搜索的格子(高亮为符合你线索的格子)",
			pickHexCube: "点选要放方块的格子",
			pickHexDisc: "点选另一格放圆片",
			zoomHint: "轻点地图先放大，再点格子落件",
			noteZoomHint: "轻点格子添加仅自己可见的笔记",
			browseHint: "拖动地图查看；双指可缩放",
			actionCube: "方块 · 排除不可能的地点",
			actionDisc: "圆片 · 标记可能的地点",
			actionQuestion: "询问 · 由对方给出答案",
			actionNote: "私人笔记 · 仅自己可见",
			actionWaiting: "等待其他玩家行动",
			pickTarget: "问谁?",
			confirmQuestion: "询问",
			confirmSearch: "搜索这里",
			confirmPlace: "放在这里",
			noteHint: "点格子在 ✓、✗、?、清除之间循环切换",
			initPlace: "初始放置:把方块放在不可能是栖息地的格子",
			waitTurn: "等 {{name}} 操作…",
			waitInit: "等 {{name}} 放方块…",
			yourTurn: "你的回合:问人或搜索",
			mustCube: "对方回答「不可能」:你须再放一个自己的方块",
			searchDisc: "你的圆片已在该格,另选一格放圆片",
			evQuestion: "{{name}} 问 {{target}}:这里可能是栖息地吗?",
			evSearch: "{{name}} 搜索了一格",
			evInit: "{{name}} 放置了方块",
			evCube: "{{name}} 被迫补放方块",
			answerYes: "可能",
			answerNo: "不可能",
			answerPass: "已确认过",
			recenter: "回到版图",
			legendCube: "方块:按该玩家线索不可能是栖息地",
			legendDisc: "圆片:按该玩家线索可能是栖息地",
			revealTitle: "栖息地揭晓",
			revealClues: "所有人的线索",
			pieceAria: "{{name}} 的{{kind}}",
			kindCube: "方块",
			kindDisc: "圆片",
			kindStone: "立石",
			kindShack: "棚屋",
			bearTerritory: "熊的领地",
			cougarTerritory: "美洲狮领地",
			mapAria: "诡影寻踪调查地图",
			mapTitle: "调查地图",
			mapCount: "六块板图 · 108 格",
			legendShort: "颜色及编号对应玩家",
			backToAction: "返回行动",
			selectedHex: "已选 {{col}}{{row}} · {{terrain}}",
			terrainLegend: "地形",
			terrain: {
				water: "水",
				forest: "林",
				desert: "沙",
				mountain: "山",
				swamp: "沼"
			},
			clue: {
				within_forest: "距森林 1 格以内",
				within_water: "距水域 1 格以内",
				within_swamp: "距沼泽 1 格以内",
				within_mountain: "距山地 1 格以内",
				within_desert: "距沙漠 1 格以内",
				within_animal: "距熊或狮的领地 1 格以内",
				within_animal_cougar: "距美洲狮领地 2 格以内",
				within_animal_bear: "距熊领地 2 格以内",
				within_stone: "距立石 2 格以内",
				within_shack: "距棚屋 2 格以内",
				within_green: "距绿色结构物 3 格以内",
				within_blue: "距蓝色结构物 3 格以内",
				within_white: "距白色结构物 3 格以内",
				within_black: "距黑色结构物 3 格以内",
				desert_or_swamp: "在沙漠或沼泽上",
				forest_or_mountain: "在森林或山地上",
				forest_or_swamp: "在森林或沼泽上",
				mountain_or_swamp: "在山地或沼泽上",
				water_or_desert: "在水域或沙漠上",
				water_or_forest: "在水域或森林上",
				water_or_swamp: "在水域或沼泽上",
				water_or_mountain: "在水域或山地上",
				forest_or_desert: "在森林或沙漠上",
				desert_or_mountain: "在沙漠或山地上",
				not_within_forest: "距森林超过 1 格",
				not_within_water: "距水域超过 1 格",
				not_within_swamp: "距沼泽超过 1 格",
				not_within_mountain: "距山地超过 1 格",
				not_within_desert: "距沙漠超过 1 格",
				not_within_animal: "距熊和狮的领地都超过 1 格",
				not_within_animal_cougar: "距美洲狮领地超过 2 格",
				not_within_animal_bear: "距熊领地超过 2 格",
				not_within_stone: "距立石超过 2 格",
				not_within_shack: "距棚屋超过 2 格",
				not_within_green: "距绿色结构物超过 3 格",
				not_within_blue: "距蓝色结构物超过 3 格",
				not_within_white: "距白色结构物超过 3 格",
				not_within_black: "距黑色结构物超过 3 格",
				not_desert_or_swamp: "不在沙漠或沼泽上",
				not_forest_or_mountain: "不在森林或山地上",
				not_forest_or_swamp: "不在森林或沼泽上",
				not_mountain_or_swamp: "不在山地或沼泽上",
				not_water_or_desert: "不在水域或沙漠上",
				not_water_or_forest: "不在水域或森林上",
				not_water_or_swamp: "不在水域或沼泽上",
				not_water_or_mountain: "不在水域或山地上",
				not_forest_or_desert: "不在森林或沙漠上",
				not_desert_or_mountain: "不在沙漠或山地上"
			},
			errNotYourTurn: "还没轮到你",
			errBadHex: "这格不能选:有方块、不符合你线索、或已有你的标记",
			errBadTarget: "要问的是其他玩家",
			hintQuestion: "问一名玩家:这格可能是栖息地吗?"
		},
		en: {
			name: "Cryptid",
			desc: "One secret clue each — deduce the creature’s only habitat",
			rules: "Goal: be the first to locate the creature’s only possible habitat by combining everyone’s clues.\nSetup: the board is assembled from 6 random map tiles; each player secretly receives one clue about the habitat (visible only to you). The intersection of all clues is exactly one space.\nOpening:\n· Starting with the first player and going clockwise, each player takes turns placing their 2 cubes on spaces that CANNOT be the habitat according to their own clue, one at a time, for 2 rounds.\nPlay (each turn, choose one):\n· Question: pick any space without a cube and name another player.\n· The system answers by their clue: their disc if the habitat could be there, their cube if not.\n· If they placed a cube, you must also place one of your cubes on a space that cannot be the habitat by your clue.\n· Search: pick a space that could be the habitat by your clue and has no cube; place your disc there first.\n· Every other player answers clockwise from your left: if everyone places a disc, you win; as soon as anyone places a cube the search stops, and you must place one of your cubes too.\nConstraints:\n· A space with a cube cannot take any more pieces and cannot be questioned or searched.\n· You can never have two of your own pieces on one space; discs of different players may stack.\n· At any time you may mark spaces with private notes (✓/✗/?), visible only to you.\nEnd: a successful search wins the game; all clues and the habitat are then revealed.\nClue list (distances include the element’s own space):\n· On one of two terrain types (e.g. “on forest or swamp”).\n· Within 1 space of a terrain type; within 1 space of bear or cougar territory.\n· Within 2 spaces of a standing stone or a shack; within 2 spaces of bear or cougar territory.\n· Within 3 spaces of a structure of one colour.\n· Advanced mode adds the negation of every clue above.",
			optMode: "Mode",
			optNormal: "Normal",
			optAdvanced: "Advanced",
			optModeHint: "Advanced adds negative clues and uses all 8 structures",
			myClue: "My clue",
			clueHidden: "Only you can see this",
			modeQuestion: "Question",
			modeSearch: "Search",
			modeNote: "Notes",
			pickHexQuestion: "Tap a space to ask about",
			pickHexSearch: "Tap a space to search (highlighted = fits your clue)",
			pickHexCube: "Tap a space to place your cube",
			pickHexDisc: "Tap another space for your disc",
			zoomHint: "Tap the map to zoom in, then tap a space",
			noteZoomHint: "Tap a space to add a private note",
			browseHint: "Drag to explore; pinch to zoom",
			actionCube: "Cube · rule out an impossible space",
			actionDisc: "Disc · mark a possible space",
			actionQuestion: "Question · another player answers",
			actionNote: "Private note · only you can see it",
			actionWaiting: "Waiting for another player",
			pickTarget: "Ask whom?",
			confirmQuestion: "Ask",
			confirmSearch: "Search here",
			confirmPlace: "Place here",
			noteHint: "Tap a space to cycle through ✓, ✗, ? and clear",
			initPlace: "Opening: place a cube where the habitat cannot be",
			waitTurn: "Waiting for {{name}}…",
			waitInit: "Waiting for {{name}} to place a cube…",
			yourTurn: "Your turn: question or search",
			mustCube: "They said “cannot be” — place one of your cubes",
			searchDisc: "Your disc is already there — place it elsewhere",
			evQuestion: "{{name}} asked {{target}}: could the habitat be here?",
			evSearch: "{{name}} searched a space",
			evInit: "{{name}} placed a cube",
			evCube: "{{name}} had to place a cube",
			answerYes: "Could be",
			answerNo: "Cannot be",
			answerPass: "Already confirmed",
			recenter: "Recenter board",
			legendCube: "Cube: the habitat cannot be here, per that player’s clue",
			legendDisc: "Disc: the habitat could be here, per that player’s clue",
			revealTitle: "Habitat revealed",
			revealClues: "Everyone’s clues",
			pieceAria: "{{name}}’s {{kind}}",
			kindCube: "cube",
			kindDisc: "disc",
			kindStone: "standing stone",
			kindShack: "shack",
			bearTerritory: "bear territory",
			cougarTerritory: "cougar territory",
			mapAria: "Cryptid investigation map",
			mapTitle: "Investigation map",
			mapCount: "6 tiles · 108 spaces",
			legendShort: "Colour and number identify players",
			backToAction: "Back to action",
			selectedHex: "Selected {{col}}{{row}} · {{terrain}}",
			terrainLegend: "Terrain",
			terrain: {
				water: "Water",
				forest: "Forest",
				desert: "Desert",
				mountain: "Mountain",
				swamp: "Swamp"
			},
			clue: {
				within_forest: "Within 1 space of forest",
				within_water: "Within 1 space of water",
				within_swamp: "Within 1 space of swamp",
				within_mountain: "Within 1 space of mountains",
				within_desert: "Within 1 space of desert",
				within_animal: "Within 1 space of either animal territory",
				within_animal_cougar: "Within 2 spaces of cougar territory",
				within_animal_bear: "Within 2 spaces of bear territory",
				within_stone: "Within 2 spaces of a standing stone",
				within_shack: "Within 2 spaces of an abandoned shack",
				within_green: "Within 3 spaces of a green structure",
				within_blue: "Within 3 spaces of a blue structure",
				within_white: "Within 3 spaces of a white structure",
				within_black: "Within 3 spaces of a black structure",
				desert_or_swamp: "On desert or swamp",
				forest_or_mountain: "On forest or mountains",
				forest_or_swamp: "On forest or swamp",
				mountain_or_swamp: "On mountains or swamp",
				water_or_desert: "On water or desert",
				water_or_forest: "On water or forest",
				water_or_swamp: "On water or swamp",
				water_or_mountain: "On water or mountains",
				forest_or_desert: "On forest or desert",
				desert_or_mountain: "On desert or mountains",
				not_within_forest: "NOT within 1 space of forest",
				not_within_water: "NOT within 1 space of water",
				not_within_swamp: "NOT within 1 space of swamp",
				not_within_mountain: "NOT within 1 space of mountains",
				not_within_desert: "NOT within 1 space of desert",
				not_within_animal: "NOT within 1 space of either animal territory",
				not_within_animal_cougar: "NOT within 2 spaces of cougar territory",
				not_within_animal_bear: "NOT within 2 spaces of bear territory",
				not_within_stone: "NOT within 2 spaces of a standing stone",
				not_within_shack: "NOT within 2 spaces of an abandoned shack",
				not_within_green: "NOT within 3 spaces of a green structure",
				not_within_blue: "NOT within 3 spaces of a blue structure",
				not_within_white: "NOT within 3 spaces of a white structure",
				not_within_black: "NOT within 3 spaces of a black structure",
				not_desert_or_swamp: "NOT on desert or swamp",
				not_forest_or_mountain: "NOT on forest or mountains",
				not_forest_or_swamp: "NOT on forest or swamp",
				not_mountain_or_swamp: "NOT on mountains or swamp",
				not_water_or_desert: "NOT on water or desert",
				not_water_or_forest: "NOT on water or forest",
				not_water_or_swamp: "NOT on water or swamp",
				not_water_or_mountain: "NOT on water or mountains",
				not_forest_or_desert: "NOT on forest or desert",
				not_desert_or_mountain: "NOT on desert or mountains"
			},
			errNotYourTurn: "Not your turn",
			errBadHex: "Cannot pick this space: cube present, fails your clue, or your piece is there",
			errBadTarget: "You must ask another player",
			hintQuestion: "Ask a player: could this hex be the habitat?"
		}
	}
};
//#endregion
export { Le as default };
