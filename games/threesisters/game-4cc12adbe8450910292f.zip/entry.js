import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as u, seatName as d } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { SheetView as p } from "@bgparty/sdk/sheet-view";
import "@bgparty/sdk/sheet-geometry";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { IconBack as _, IconBot as v, IconExpand as y, IconLog as b } from "@bgparty/sdk/icons";
import { Confetti as x } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as S, OptionSection as C } from "@bgparty/sdk/ui/game-options";
//#region src/games/threesisters/meta.ts
var w = {
	id: "threesisters",
	tier: "alpha",
	mechanics: [
		"roll-and-write",
		"drafting",
		"dice-rolling"
	],
	interactionTags: [],
	nameKey: "games.threesisters.name",
	descKey: "games.threesisters.desc",
	rulesKey: "games.threesisters.rules",
	icon: "🌻",
	iconImg: "games/threesisters.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/threesisters/en.pdf" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#d97706",
	releasedAt: "2026-09-17",
	search: {
		py: "nong chang san jie mei",
		init: "ncsjm"
	},
	hotseat: "cover"
}, T = t.object({
	zone: t.int().min(0).max(5),
	kind: t.enum([
		"corn",
		"bean",
		"pumpkin"
	]),
	idx: t.int().min(0).max(4)
}), E = t.int().min(0), D = t.discriminatedUnion("type", [
	t.object({ type: t.literal("roll") }),
	t.object({
		type: t.literal("pick"),
		value: t.int().min(1).max(6)
	}),
	t.object({
		type: t.literal("plant"),
		index: E,
		crops: t.array(T).min(1).max(3),
		adjust: t.int().min(-5).max(5).optional()
	}),
	t.object({
		type: t.literal("water"),
		index: E,
		adjust: t.int().min(-5).max(5).optional(),
		zone: t.int().min(0).max(5).optional()
	}),
	t.object({
		type: t.literal("shed"),
		index: E,
		item: t.int().min(0).max(14)
	}),
	t.object({
		type: t.literal("apiary"),
		index: E,
		section: t.enum([
			"main",
			"wax",
			"honey",
			"split"
		])
	}),
	t.object({
		type: t.literal("fruit"),
		index: E,
		row: t.enum([
			"apple",
			"peach",
			"blackberry",
			"raspberry"
		])
	}),
	t.object({
		type: t.literal("perennial"),
		index: E,
		flower: t.int().min(0).max(5)
	}),
	t.object({
		type: t.literal("bonus"),
		index: E,
		target: t.enum([
			"perennial",
			"apiary",
			"fruit",
			"shed"
		])
	}),
	t.object({
		type: t.literal("market"),
		index: E
	}),
	t.object({
		type: t.literal("mulch"),
		index: E
	}),
	t.object({ type: t.literal("shovel") }),
	t.object({
		type: t.literal("skip"),
		index: E
	}),
	t.object({
		type: t.literal("edithCrop"),
		index: E,
		kind: t.enum([
			"corn",
			"bean",
			"pumpkin"
		]),
		idx: t.int().min(0).max(4)
	}),
	t.object({ type: t.literal("done") })
]), O = t.object({
	corn: t.array(t.array(t.int()).max(5)).length(6),
	bean: t.array(t.array(t.int()).max(5)).length(6),
	pumpkin: t.array(t.array(t.int()).max(3)).length(6),
	ringClaimed: t.array(t.boolean()).length(12),
	perennials: t.array(t.int().min(0).max(6)).length(6),
	perennialBlocked: t.array(t.int().min(0).max(6)).length(6),
	apiaryMain: t.int().min(0).max(5),
	apiaryWax: t.int().min(0).max(5),
	apiaryHoney: t.int().min(0).max(5),
	apiarySplit: t.int().min(0).max(4),
	apiaryBlocked: t.object({
		wax: t.int().min(0).max(5),
		honey: t.int().min(0).max(5),
		split: t.int().min(0).max(4)
	}),
	fruit: t.array(t.int().min(0).max(9)).length(4),
	fruitBlocked: t.array(t.int().min(0).max(9)).length(4),
	shed: t.array(t.int().min(0).max(6)).length(15),
	shedCrossed: t.array(t.boolean()).length(15),
	goods: t.int().min(0).max(120),
	deadStars: t.array(t.int()),
	compost: t.int().min(0).max(40),
	compostGained: t.int().min(0).max(40)
}), k = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("grow"),
		zone: t.int().min(0).max(5),
		mode: t.enum([
			"choose",
			"plant",
			"water"
		]),
		ctx: t.string(),
		rondel: t.boolean(),
		banked: t.boolean()
	}),
	t.object({
		kind: t.literal("waterAny"),
		banked: t.boolean()
	}),
	t.object({
		kind: t.literal("plantAny"),
		banked: t.boolean()
	}),
	t.object({
		kind: t.literal("growAny"),
		banked: t.boolean()
	}),
	t.object({
		kind: t.literal("shed"),
		rondel: t.boolean(),
		banked: t.boolean()
	}),
	t.object({
		kind: t.literal("apiaryOrFruit"),
		rondel: t.boolean(),
		banked: t.boolean()
	}),
	t.object({
		kind: t.literal("apiary"),
		banked: t.boolean()
	}),
	t.object({
		kind: t.literal("fruit"),
		row: t.enum([
			"apple",
			"peach",
			"blackberry",
			"raspberry"
		]).nullable(),
		banked: t.boolean()
	}),
	t.object({
		kind: t.literal("perennial"),
		flower: t.int().min(0).max(5).nullable(),
		banked: t.boolean()
	}),
	t.object({
		kind: t.literal("bonus"),
		banked: t.boolean()
	}),
	t.object({
		kind: t.literal("market"),
		rondel: t.boolean(),
		banked: t.boolean()
	}),
	t.object({
		kind: t.literal("edithCrop"),
		zone: t.int().min(0).max(5),
		cropKind: t.enum([
			"corn",
			"bean",
			"pumpkin"
		]),
		candidates: t.array(t.int().min(0).max(4)).min(2),
		banked: t.boolean()
	})
]), A = t.object({ weather: t.boolean().default(!1) }).default({ weather: !1 }), ee = t.object({
	players: t.array(t.string()).min(1).max(4),
	solo: t.boolean(),
	round: t.int().min(1).max(8),
	phase: t.enum([
		"planning",
		"gardening",
		"lowest",
		"event",
		"done"
	]),
	firstIdx: t.int().min(0),
	weatherOn: t.boolean(),
	weather: t.int().min(0).max(5),
	rondel: t.object({
		pawn: t.int().min(0).max(6),
		dice: t.array(t.object({
			value: t.int().min(1).max(6),
			space: t.int().min(0).max(6),
			taken: t.boolean()
		}))
	}),
	pickQueue: t.array(t.string()),
	window: t.string().nullable(),
	lowestDie: t.object({
		value: t.int(),
		space: t.int()
	}).nullable(),
	event: t.enum([
		"shed",
		"rain",
		"market"
	]).nullable(),
	sheets: t.record(t.string(), O),
	pendings: t.record(t.string(), t.array(k)),
	done: t.array(t.string()),
	edith: t.object({
		die: t.int(),
		space: t.int(),
		step: t.enum([
			"crop1",
			"crop2",
			"rondel"
		])
	}).nullable()
}), j = t.object({}), M = [
	"tulip",
	"hydrangea",
	"iris",
	"hyacinth",
	"crocus",
	"daffodil"
], N = {
	tulip: 0,
	hydrangea: 1,
	iris: 2,
	hyacinth: 3,
	crocus: 4,
	daffodil: 5
}, te = [
	"apple",
	"peach",
	"blackberry",
	"raspberry"
], P = {
	apple: 0,
	peach: 1,
	blackberry: 2,
	raspberry: 3
}, F = [
	8,
	8,
	7,
	9
], I = [
	[
		2,
		4,
		5,
		6,
		7,
		8
	],
	[
		2,
		4,
		6,
		8
	],
	[
		1,
		2,
		3,
		4,
		5,
		6,
		7
	],
	[
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9
	]
], L = [
	{
		corn: 3,
		pumpkins: [
			{
				g: 1,
				h: 1
			},
			{
				g: 2,
				h: 3
			},
			{
				g: 3,
				h: 4
			}
		]
	},
	{
		corn: 5,
		pumpkins: [{
			g: 3,
			h: 4
		}]
	},
	{
		corn: 4,
		pumpkins: [{
			g: 1,
			h: 2
		}, {
			g: 2,
			h: 3
		}]
	},
	{
		corn: 3,
		pumpkins: [
			{
				g: 3,
				h: 4
			},
			{
				g: 3,
				h: 3
			},
			{
				g: 1,
				h: 1
			}
		]
	},
	{
		corn: 5,
		pumpkins: [{
			g: 1,
			h: 2
		}]
	},
	{
		corn: 4,
		pumpkins: [{
			g: 2,
			h: 3
		}, {
			g: 3,
			h: 4
		}]
	}
], ne = [
	[1, 5],
	[
		0,
		2,
		4
	],
	[1, 3],
	[2, 4],
	[
		1,
		3,
		5
	],
	[0, 4]
], R = [
	{
		flower: 2,
		a: {
			zone: 0,
			idx: 0
		},
		b: {
			zone: 1,
			idx: 0
		}
	},
	{
		flower: 0,
		a: {
			zone: 1,
			idx: 0
		},
		b: {
			zone: 2,
			idx: 0
		}
	},
	{
		flower: 3,
		a: {
			zone: 2,
			idx: 0
		},
		b: {
			zone: 2,
			idx: 1
		}
	},
	{
		flower: 2,
		a: {
			zone: 2,
			idx: 1
		},
		b: {
			zone: 3,
			idx: 0
		}
	},
	{
		flower: 5,
		a: {
			zone: 3,
			idx: 0
		},
		b: {
			zone: 3,
			idx: 1
		}
	},
	{
		flower: 4,
		a: {
			zone: 3,
			idx: 1
		},
		b: {
			zone: 3,
			idx: 2
		}
	},
	{
		flower: 1,
		a: {
			zone: 3,
			idx: 2
		},
		b: {
			zone: 4,
			idx: 0
		}
	},
	{
		flower: 0,
		a: {
			zone: 4,
			idx: 0
		},
		b: {
			zone: 5,
			idx: 1
		}
	},
	{
		flower: 3,
		a: {
			zone: 5,
			idx: 1
		},
		b: {
			zone: 5,
			idx: 0
		}
	},
	{
		flower: 5,
		a: {
			zone: 5,
			idx: 0
		},
		b: {
			zone: 0,
			idx: 2
		}
	},
	{
		flower: 4,
		a: {
			zone: 0,
			idx: 2
		},
		b: {
			zone: 0,
			idx: 1
		}
	},
	{
		flower: 1,
		a: {
			zone: 0,
			idx: 1
		},
		b: {
			zone: 0,
			idx: 0
		}
	}
], re = [
	[
		{ kind: "fruitAny" },
		{ kind: "none" },
		{ kind: "none" },
		{ kind: "none" },
		{ kind: "none" },
		{ kind: "none" }
	],
	[
		{
			kind: "fruit",
			row: "apple"
		},
		{ kind: "none" },
		{
			kind: "fruit",
			row: "blackberry"
		},
		{
			kind: "fruit",
			row: "raspberry"
		},
		{
			kind: "fruit",
			row: "peach"
		},
		{ kind: "none" }
	],
	[
		{
			kind: "compost",
			n: 1
		},
		{ kind: "none" },
		{ kind: "none" },
		{ kind: "none" },
		{ kind: "none" },
		{ kind: "none" }
	],
	[
		{
			kind: "goods",
			n: 2
		},
		{
			kind: "goods",
			n: 2
		},
		{ kind: "none" },
		{
			kind: "goods",
			n: 2
		},
		{ kind: "none" },
		{ kind: "none" }
	],
	[
		{
			kind: "compost",
			n: 2
		},
		{
			kind: "compost",
			n: 1
		},
		{
			kind: "compost",
			n: 1
		},
		{
			kind: "compost",
			n: 2
		},
		{ kind: "none" },
		{ kind: "none" }
	],
	[
		{ kind: "shed" },
		{ kind: "none" },
		{ kind: "shed" },
		{ kind: "shed" },
		{ kind: "shed" },
		{ kind: "none" }
	]
], ie = [
	15,
	7,
	12,
	10,
	6,
	4
], ae = {
	wax: 4,
	honey: 4,
	split: 4
}, oe = [
	2,
	4,
	4
], se = [
	2,
	2,
	5
], ce = [
	5,
	5,
	8
], z = [
	1,
	2,
	4
], le = [
	"masonJars",
	"pieSafe",
	"shovel",
	"fruitBowl",
	"rainBarrel",
	"casseroleDish",
	"fancyLabels",
	"hiveTool",
	"pitchfork",
	"stringTrimmer",
	"wheelbarrow",
	"mulch",
	"tractor",
	"carvingKit",
	"seedSpreader"
], B = [
	1,
	2,
	2,
	3,
	2,
	2,
	3,
	3,
	1,
	3,
	2,
	1,
	6,
	3,
	4
], V = [
	1,
	3,
	1,
	0,
	2,
	0,
	2,
	2,
	1,
	6,
	3,
	1,
	18,
	0,
	2
], ue = Object.fromEntries(le.map((e, t) => [e, t])), de = [
	{
		goods: 0,
		perennial: 0,
		fruit: 0,
		compost: 1,
		bonus: 0
	},
	{
		goods: 4,
		perennial: 1,
		fruit: 0,
		compost: 1,
		bonus: 0
	},
	{
		goods: 20,
		perennial: 1,
		fruit: 1,
		compost: 0,
		bonus: 0
	},
	{
		goods: 35,
		perennial: 2,
		fruit: 0,
		compost: 1,
		bonus: 0
	},
	{
		goods: 50,
		perennial: 2,
		fruit: 1,
		compost: 0,
		bonus: 0
	},
	{
		goods: 70,
		perennial: 2,
		fruit: 0,
		compost: 0,
		bonus: 1
	}
], fe = [
	"shed",
	"rain",
	"market",
	"rain",
	"market",
	"shed",
	"market",
	"rain"
], pe = [
	"foggy",
	"lightning",
	"cold",
	"cloudy",
	"hot",
	"windy"
], H = [
	0,
	1,
	2,
	3,
	4,
	5
], me = [
	6,
	7,
	8,
	9,
	10,
	11
], he = [
	0,
	40,
	50,
	65,
	80,
	100
];
function ge() {
	return {
		corn: L.map((e) => Array.from({ length: e.corn }, () => 0)),
		bean: L.map((e) => Array.from({ length: e.corn }, () => 0)),
		pumpkin: L.map((e) => Array.from({ length: e.pumpkins.length }, () => 0)),
		ringClaimed: Array.from({ length: R.length }, () => !1),
		perennials: [
			0,
			0,
			0,
			0,
			0,
			0
		],
		perennialBlocked: [
			0,
			0,
			0,
			0,
			0,
			0
		],
		apiaryMain: 0,
		apiaryWax: 0,
		apiaryHoney: 0,
		apiarySplit: 0,
		apiaryBlocked: {
			wax: 0,
			honey: 0,
			split: 0
		},
		fruit: [
			0,
			0,
			0,
			0
		],
		fruitBlocked: [
			0,
			0,
			0,
			0
		],
		shed: Array.from({ length: 15 }, () => 0),
		shedCrossed: Array.from({ length: 15 }, () => !1),
		goods: 0,
		deadStars: [],
		compost: 1,
		compostGained: 1
	};
}
function _e(e) {
	let t = e.perennials[N.iris];
	return t >= 4 ? 2 : +(t >= 2);
}
function ve(e) {
	let t = e.perennials[N.tulip];
	return t >= 4 ? 3 : t >= 2 ? 2 : 0;
}
function U(e, t) {
	let n = ue[t];
	return !e.shedCrossed[n] && e.shed[n] >= B[n];
}
function W(e) {
	return e.corn.flat().filter((e) => e >= 4).length;
}
function ye(e) {
	return e.bean.flat().filter((e) => e >= 2).length;
}
function be(e) {
	return te.reduce((t, n) => {
		let r = P[n];
		return t + I[r].filter((t) => t <= e.fruit[r]).length;
	}, 0);
}
function xe(e) {
	let t = e.goods;
	for (let n of [...e.deadStars].sort((e, t) => e - t)) n <= t && (t += 1);
	return t;
}
var Se = {
	lightning: !1,
	cold: !1,
	hot: !1,
	windy: !1
};
function G(e, t, n, r = !0) {
	for (let i = 0; i < t; i += 1) {
		let t = xe(e);
		if (t >= 120) return;
		e.goods += 1;
		let i = t + 1;
		i % 5 == 0 && !e.deadStars.includes(i) && n.push({
			kind: "bonus",
			banked: r
		});
	}
}
function K(e, t) {
	e.compost = Math.min(40, e.compost + t), e.compostGained = Math.min(40, e.compostGained + t);
}
function Ce(e, t, n, r) {
	let i = L[t];
	return n === "corn" ? r < i.corn && e.corn[t][r] === 0 : n === "bean" ? r < i.corn && e.bean[t][r] === 0 && e.corn[t][r] >= 2 : r < i.pumpkins.length && e.pumpkin[t][r] === 0;
}
function we(e, t, n, r, i, a) {
	if (n !== "pumpkin") return;
	let o = L[t].pumpkins[r].g;
	G(e, o, i, a), R.forEach((n, o) => {
		if (e.ringClaimed[o]) return;
		let s = n.a.zone === t && n.a.idx === r, c = n.b.zone === t && n.b.idx === r;
		if (!s && !c) return;
		let l = s ? n.b : n.a;
		e.pumpkin[l.zone][l.idx] >= L[l.zone].pumpkins[l.idx].h && (e.ringClaimed[o] = !0, i.push({
			kind: "perennial",
			flower: n.flower,
			banked: a
		}));
	});
}
function q(e, t, n, r = !0) {
	for (let i of t) i.kind === "corn" ? e.corn[i.zone][i.idx] = 1 : i.kind === "bean" ? e.bean[i.zone][i.idx] = 1 : (e.pumpkin[i.zone][i.idx] = 1, e.pumpkin[i.zone][i.idx] >= L[i.zone].pumpkins[i.idx].h && we(e, i.zone, "pumpkin", i.idx, n, r));
}
function Te(e, t, n, r = !0) {
	let i = L[t];
	for (let n = 0; n < i.corn; n += 1) e.corn[t][n] > 0 && e.corn[t][n] < 4 && (e.corn[t][n] += 1), e.bean[t][n] > 0 && e.bean[t][n] < 2 && (e.bean[t][n] += 1);
	for (let a = 0; a < i.pumpkins.length; a += 1) {
		let o = i.pumpkins[a].h;
		e.pumpkin[t][a] > 0 && e.pumpkin[t][a] < o && (e.pumpkin[t][a] += 1, e.pumpkin[t][a] >= o && we(e, t, "pumpkin", a, n, r));
	}
}
function Ee(e, t) {
	return e.perennials[t] + e.perennialBlocked[t] < 6;
}
function De(e, t, n, r = !0) {
	if (!Ee(e, t)) return;
	e.perennials[t] += 1;
	let i = e.perennials[t] + e.perennialBlocked[t] - 1, a = re[t][i];
	a.kind === "fruitAny" ? n.push({
		kind: "fruit",
		row: null,
		banked: r
	}) : a.kind === "fruit" ? n.push({
		kind: "fruit",
		row: a.row,
		banked: r
	}) : a.kind === "shed" ? n.push({
		kind: "shed",
		rondel: !1,
		banked: r
	}) : a.kind === "goods" ? G(e, a.n, n, r) : a.kind === "compost" && K(e, a.n), t === N.crocus && U(e, "hiveTool") && n.push({
		kind: "apiary",
		banked: r
	}), t === N.hydrangea && U(e, "pitchfork") && K(e, 1);
}
function Oe(e) {
	return e.apiaryMain >= 5;
}
function ke(e, t) {
	return t === "main" ? e.apiaryMain < 5 : Oe(e) ? e[`apiary${t === "wax" ? "Wax" : t === "honey" ? "Honey" : "Split"}`] + e.apiaryBlocked[t] < ae[t] : !1;
}
function Ae(e, t, n, r = !0) {
	if (!ke(e, t)) return;
	if (t === "main") {
		e.apiaryMain += 1, e.apiaryMain === 2 && n.push({
			kind: "fruit",
			row: null,
			banked: r
		}), e.apiaryMain === 4 && n.push({
			kind: "fruit",
			row: null,
			banked: r
		}, {
			kind: "fruit",
			row: null,
			banked: r
		});
		return;
	}
	if (t === "wax") {
		e.apiaryWax += 1;
		let t = e.apiaryWax + e.apiaryBlocked.wax, i = z.indexOf(t);
		i >= 0 && G(e, oe[i], n, r);
		return;
	}
	if (t === "honey") {
		e.apiaryHoney += 1;
		return;
	}
	e.apiarySplit += 1;
	let i = e.apiarySplit + e.apiaryBlocked.split;
	i === 2 && n.push({
		kind: "plantAny",
		banked: r
	}), i === 3 && n.push({
		kind: "fruit",
		row: null,
		banked: r
	}, {
		kind: "fruit",
		row: null,
		banked: r
	}, {
		kind: "fruit",
		row: null,
		banked: r
	}), i === 4 && n.push({
		kind: "growAny",
		banked: r
	}, {
		kind: "growAny",
		banked: r
	});
}
function J(e, t) {
	return e.fruit[t] + e.fruitBlocked[t] < F[t];
}
function je(e, t, n, r, i = !0) {
	if (!J(e, t)) return;
	e.fruit[t] += 1;
	let a = e.fruit[t];
	if (I[t].includes(a)) {
		if (r.hot && G(e, 1, n, i), t === P.peach) {
			n.push({
				kind: "waterAny",
				banked: i
			});
			let t = ve(e);
			t > 0 && G(e, t, n, i), U(e, "pieSafe") && G(e, 1, n, i);
		} else t === P.apple ? U(e, "pieSafe") && G(e, 1, n, i) : t === P.blackberry ? U(e, "masonJars") && G(e, 1, n, i) : G(e, 3, n, i);
	}
}
function Me(e, t) {
	return !e.shedCrossed[t] && e.shed[t] < B[t];
}
function Ne(e, t, n, r = !0) {
	Me(e, t) && (e.shed[t] += 1, U(e, "wheelbarrow") && G(e, 1, n, r));
}
function Pe(e) {
	let t = W(e) * 3 + ye(e) * 1, n = 0;
	M.forEach((t, r) => {
		e.perennials[r] >= 6 && (n += r === 0 ? Math.min(ie[0], be(e)) : ie[r]);
	});
	let r = 0, i = e.apiaryWax + e.apiaryBlocked.wax;
	z.forEach((e, t) => {
		i >= e && (r += se[t]);
	});
	let a = e.apiaryHoney + e.apiaryBlocked.honey;
	z.forEach((e, t) => {
		a >= e && (r += ce[t]);
	}), e.apiarySplit + e.apiaryBlocked.split >= 1 && (r += 3);
	let o = 0, s = I[0].filter((t) => t <= e.fruit[0]).length;
	o += s * 3;
	let c = I[2].filter((t) => t <= e.fruit[2]).length;
	o += c * 2;
	let l = I[3].filter((t) => t <= e.fruit[3]).length;
	l >= 3 && (o += 1), l >= 6 && (o += 2), l >= 9 && (o += 3);
	let u = 0;
	return le.forEach((t, n) => {
		if (U(e, t)) {
			if (t === "fruitBowl") {
				let t = te.filter((t) => {
					let n = P[t];
					return I[n].some((t) => t <= e.fruit[n]);
				}).length;
				u += [
					0,
					1,
					4,
					7,
					10
				][t];
			} else u += t === "casseroleDish" ? Math.floor(ye(e) / 2) : t === "carvingKit" ? Fe(e) : V[n];
		}
	}), {
		garden: t,
		perennials: n,
		apiary: r,
		fruit: o,
		shed: u,
		total: t + n + r + o + u
	};
}
function Fe(e) {
	let t = [R[0].a];
	for (let e of R) t.push(e.b);
	let n = t.map((t) => e.pumpkin[t.zone][t.idx] >= L[t.zone].pumpkins[t.idx].h), r = n.length, i = 0;
	for (let e = 0; e < r; e += 1) {
		if (!n[e]) continue;
		let t = 0;
		for (; t < r && n[(e + t) % r];) t += 1;
		i = Math.max(i, t);
	}
	return i;
}
function Ie(e) {
	for (let t = he.length - 1; t >= 0; --t) if (e >= he[t]) return t;
	return 0;
}
//#endregion
//#region src/games/threesisters/rules.ts
var Y = [
	"pw",
	"shedA",
	"compost",
	"afFruit",
	"shedB",
	"market",
	"afApiary"
], Le = 6, X = {
	over: "games.threesisters.errOver",
	notYourTurn: "games.threesisters.errNotYourTurn",
	badDie: "games.threesisters.errBadDie",
	badPending: "games.threesisters.errBadPending",
	badCrop: "games.threesisters.errBadCrop",
	badTarget: "games.threesisters.errBadTarget",
	noCompost: "games.threesisters.errNoCompost",
	badAdjust: "games.threesisters.errBadAdjust",
	blocked: "games.threesisters.errBlocked",
	unresolved: "games.threesisters.errUnresolved"
};
function Re(t, n, r) {
	let i = {}, a = {};
	for (let e of n) i[e] = ge(), a[e] = [];
	return {
		state: {
			players: n,
			solo: n.length === 1,
			round: 1,
			phase: "planning",
			firstIdx: e(r, 0, n.length),
			weatherOn: t.weather,
			weather: 0,
			rondel: {
				pawn: Le,
				dice: []
			},
			pickQueue: [],
			window: null,
			lowestDie: null,
			event: null,
			sheets: i,
			pendings: a,
			done: [],
			adjustments: {},
			edith: null,
			edithPicks: 0,
			lastPick: 0,
			seed: r,
			rngCursor: 1
		},
		fx: []
	};
}
function ze(e) {
	return e.weatherOn ? {
		lightning: e.weather === 1,
		cold: e.weather === 2,
		hot: e.weather === 4,
		windy: e.weather === 5
	} : Se;
}
function Be(e) {
	return e.solo ? 4 : e.players.length + 2;
}
function Ve(e, t, n) {
	switch (Y[e]) {
		case "pw": return [{
			kind: "grow",
			zone: t - 1,
			mode: "choose",
			ctx: n,
			rondel: !0,
			banked: !1
		}];
		case "shedA":
		case "shedB": return [{
			kind: "shed",
			rondel: !0,
			banked: !1
		}];
		case "afFruit":
		case "afApiary": return [{
			kind: "apiaryOrFruit",
			rondel: !0,
			banked: !1
		}];
		case "market": return [{
			kind: "market",
			rondel: !0,
			banked: !1
		}];
		default: return [];
	}
}
function He(e) {
	let t = e.rondel.dice.filter((e) => !e.taken);
	if (t.length === 0) return null;
	if (e.edithPicks > 0) return t.reduce((e, t) => t.value < e.value ? t : e);
	for (let e = 0; e < 7; e += 1) {
		let n = t.find((t) => t.space === (Le + e) % 7);
		if (n) return n;
	}
	return null;
}
function Ue(e) {
	let t = e.players[0], n = e.sheets[t], r = e.edith.die - 1, i = L[r], a = e.pendings[t], o = (e, t) => (a.some((e) => e.kind === "edithCrop") || a.push({
		kind: "edithCrop",
		zone: r,
		cropKind: e,
		candidates: t,
		banked: !1
	}), !1), s = i.pumpkins.map((e, t) => ({
		i: t,
		h: e.h
	})).filter((e) => n.pumpkin[r][e.i] === 0);
	if (s.length > 0) {
		let e = Math.max(...s.map((e) => e.h)), t = s.filter((t) => t.h === e).map((e) => e.i);
		return t.length === 1 ? (n.pumpkin[r][t[0]] = -1, !0) : o("pumpkin", t);
	}
	let c = Array.from({ length: i.corn }, (e, t) => t).filter((e) => n.corn[r][e] === 0);
	if (c.length > 0) return c.length === 1 ? (n.corn[r][c[0]] = -1, !0) : o("corn", c);
	let l = Array.from({ length: i.corn }, (e, t) => t).filter((e) => n.bean[r][e] === 0);
	return l.length > 0 ? l.length === 1 ? (n.bean[r][l[0]] = -1, !0) : o("bean", l) : !0;
}
function We(e) {
	let t = e.sheets[e.players[0]], n = e.edith.die;
	switch (Y[e.edith.space]) {
		case "shedA":
		case "shedB": {
			let r = (Y[e.edith.space] === "shedA" ? H : me)[n - 1];
			Me(t, r) && (t.shedCrossed[r] = !0);
			return;
		}
		case "compost": {
			let e = t.goods;
			for (let n of [...t.deadStars].sort((e, t) => e - t)) n <= e && (e += 1);
			let n = Math.floor(e / 5) * 5 + 5;
			for (; n <= 120 && t.deadStars.includes(n);) n += 5;
			n <= 120 && t.deadStars.push(n);
			return;
		}
		case "afApiary": {
			if (!Oe(t)) return;
			let e = n <= 2 ? "honey" : n <= 4 ? "wax" : "split";
			ke(t, e) && (t.apiaryBlocked[e] += 1);
			return;
		}
		case "afFruit": {
			let e = n <= 2 ? P.apple : n === 3 ? P.peach : n <= 5 ? P.blackberry : P.raspberry;
			J(t, e) && (t.fruitBlocked[e] += 1);
			return;
		}
		case "market":
			Ee(t, n - 1) && (t.perennialBlocked[n - 1] += 1);
			return;
		default: return;
	}
}
function Ge(e) {
	if (e.phase = "gardening", e.window = null, e.done = [], e.edithPicks = 0, e.solo) {
		let t = e.players[0];
		e.pickQueue = e.round % 2 == 1 ? [
			t,
			"edith",
			t,
			"edith"
		] : [
			"edith",
			t,
			"edith",
			t
		];
	} else e.pickQueue = e.players.map((t, n) => e.players[(e.firstIdx + n) % e.players.length]);
}
function Ke(e) {
	let t = e.rondel.dice.filter((e) => !e.taken).reduce((e, t) => t.value < e.value ? t : e);
	e.phase = "lowest", e.lowestDie = {
		value: t.value,
		space: t.space
	}, e.done = [];
	for (let n of e.players) {
		let r = `L${e.round}`;
		e.pendings[n].push({
			kind: "grow",
			zone: t.value - 1,
			mode: "choose",
			ctx: r,
			rondel: !1,
			banked: !1
		}), e.pendings[n].push(...Ve(t.space, t.value, r));
	}
}
function qe(e) {
	e.phase = "event", e.event = fe[e.round - 1], e.done = [];
	for (let t of e.players) {
		let n = e.sheets[t], r = e.pendings[t];
		if (e.event === "shed") r.push({
			kind: "shed",
			rondel: !1,
			banked: !0
		});
		else if (e.event === "rain") {
			for (let e = 0; e < 6; e += 1) Te(n, e, r, !0);
			U(n, "rainBarrel") && r.push({
				kind: "waterAny",
				banked: !0
			});
		} else r.push({
			kind: "market",
			rondel: !1,
			banked: !0
		});
	}
}
function Je(e) {
	if (e.weatherOn) {
		if (e.solo) e.weather = Math.max(0, e.lastPick - 1);
		else {
			let t = e.rondel.dice.filter((e) => !e.taken);
			t.length > 0 && (e.weather = Math.max(...t.map((e) => e.value)) - 1);
		}
	}
	if (e.round += 1, e.round > 8) {
		e.round = 8, e.phase = "done";
		return;
	}
	e.phase = "planning", e.rondel.dice = [], e.event = null, e.lowestDie = null, e.done = [], e.solo || (e.firstIdx = (e.firstIdx + 1) % e.players.length);
}
function Ye(e, t) {
	return e.phase === "gardening" ? e.window === t || e.window === null && e.edith !== null && (e.pendings[t]?.some((e) => e.kind === "edithCrop") ?? !1) : e.phase === "lowest" || e.phase === "event" ? !e.done.includes(t) : !1;
}
function Xe(e, t) {
	return e.pendings[t].some((e) => !e.banked);
}
function Ze(e) {
	if (e.phase === "gardening" && e.window === null) {
		for (; e.edith !== null || e.pickQueue.length > 0 && e.pickQueue[0] === "edith";) {
			if (!e.edith) {
				let t = He(e);
				if (e.pickQueue.shift(), !t) continue;
				t.taken = !0, e.lastPick = t.value, e.edithPicks += 1, e.edith = {
					die: t.value,
					space: t.space,
					step: "crop1"
				};
			}
			if (e.edith.step === "crop1" || e.edith.step === "crop2") {
				if (!Ue(e)) return;
				if (e.edith.step = e.edith.step === "crop1" && Y[e.edith.space] === "pw" ? "crop2" : "rondel", e.edith.step === "crop2") continue;
			}
			We(e), e.edith = null;
		}
		e.pickQueue.length === 0 && !e.edith && (e.solo ? qe(e) : Ke(e));
	}
}
function Qe(t, n, r) {
	if (t.phase === "done") return { code: X.over };
	if (n.type === "roll") {
		if (t.phase !== "planning" || r.by !== t.players[t.firstIdx]) return { code: X.notYourTurn };
		let n = structuredClone(t), i = Be(n), a = [];
		for (let t = 0; t < i; t += 1) a.push(e(n.seed, n.rngCursor + t, 6) + 1);
		n.rngCursor += i;
		let o = [...new Set(a)].sort((e, t) => e - t), s = [];
		if (o.forEach((e, t) => {
			let r = (n.rondel.pawn + t) % 7;
			for (let t of a) t === e && s.push({
				value: e,
				space: r,
				taken: !1
			});
		}), n.rondel.dice = s, n.rondel.pawn = (n.rondel.pawn + o.length) % 7, n.lastPick = 0, n.weatherOn && n.weather === 3) for (let e of n.players) n.pendings[e].push({
			kind: "perennial",
			flower: null,
			banked: !0
		});
		return Ge(n), Ze(n), {
			state: n,
			fx: []
		};
	}
	if (n.type === "pick") {
		if (t.phase !== "gardening" || t.window !== null || t.pickQueue[0] !== r.by) return { code: X.notYourTurn };
		let e = t.rondel.dice.find((e) => !e.taken && e.value === n.value);
		if (!e) return { code: X.badDie };
		if (t.solo && t.pickQueue.length === 2) {
			let e = Math.min(...t.rondel.dice.filter((e) => !e.taken).map((e) => e.value));
			if (n.value !== e) return { code: X.badDie };
		}
		let i = structuredClone(t);
		i.rondel.dice.find((e) => !e.taken && e.value === n.value).taken = !0, i.lastPick = n.value, i.pickQueue.shift(), i.window = r.by;
		let a = `r${i.round}p${i.rngCursor}`;
		return i.rngCursor += 1, Y[e.space] === "compost" && (K(i.sheets[r.by], 1), G(i.sheets[r.by], 4, i.pendings[r.by], !1)), i.pendings[r.by].push({
			kind: "grow",
			zone: n.value - 1,
			mode: "choose",
			ctx: a,
			rondel: !1,
			banked: !1
		}), i.pendings[r.by].push(...Ve(e.space, n.value, a)), {
			state: i,
			fx: []
		};
	}
	if (n.type === "done") {
		if (!Ye(t, r.by)) return { code: X.notYourTurn };
		if ((t.phase === "gardening" || t.phase === "lowest") && Xe(t, r.by)) return { code: X.unresolved };
		let e = structuredClone(t);
		return e.phase === "gardening" ? (e.window = null, Ze(e), {
			state: e,
			fx: []
		}) : (e.done.push(r.by), e.players.every((t) => e.done.includes(t)) && (e.phase === "lowest" ? qe(e) : Je(e)), {
			state: e,
			fx: []
		});
	}
	if (n.type === "shovel") {
		if (!Ye(t, r.by)) return { code: X.notYourTurn };
		let e = t.sheets[r.by];
		if (!U(e, "shovel")) return { code: X.badTarget };
		if (e.compost < 3) return { code: X.noCompost };
		let n = structuredClone(t);
		return n.sheets[r.by].compost -= 3, n.pendings[r.by].push({
			kind: "bonus",
			banked: !0
		}), {
			state: n,
			fx: []
		};
	}
	if (!Ye(t, r.by)) return { code: X.notYourTurn };
	let i = t.pendings[r.by][n.index];
	if (!i) return { code: X.badPending };
	if (n.type === "skip") {
		if (i.kind === "edithCrop") return { code: X.badPending };
		let e = structuredClone(t);
		return e.pendings[r.by].splice(n.index, 1), {
			state: e,
			fx: []
		};
	}
	if (n.type === "mulch") {
		if (!("rondel" in i) || !i.rondel) return { code: X.badPending };
		if (!U(t.sheets[r.by], "mulch")) return { code: X.badTarget };
		let e = structuredClone(t);
		return e.pendings[r.by].splice(n.index, 1, {
			kind: "perennial",
			flower: null,
			banked: !0
		}), {
			state: e,
			fx: []
		};
	}
	if (n.type === "edithCrop") {
		if (i.kind !== "edithCrop" || !t.edith || t.edith.step !== "crop1" && t.edith.step !== "crop2") return { code: X.badPending };
		if (n.kind !== i.cropKind || !i.candidates.includes(n.idx)) return { code: X.badCrop };
		let e = structuredClone(t), a = e.sheets[r.by];
		if (n.kind === "corn" ? a.corn[i.zone][n.idx] = -1 : n.kind === "bean" ? a.bean[i.zone][n.idx] = -1 : a.pumpkin[i.zone][n.idx] = -1, e.pendings[r.by].splice(n.index, 1), e.edith.step = e.edith.step === "crop1" && Y[e.edith.space] === "pw" ? "crop2" : "rondel", e.edith.step === "crop2") {
			if (!Ue(e)) return {
				state: e,
				fx: []
			};
			e.edith = null;
		} else We(e), e.edith = null;
		return Ze(e), {
			state: e,
			fx: []
		};
	}
	let a = structuredClone(t), o = a.sheets[r.by], s = [], c = ze(a), l = n.index;
	if (n.type === "plant" || n.type === "water") {
		let e = n.type === "plant";
		if (i.kind !== "grow" && i.kind !== "plantAny" && i.kind !== "growAny" && i.kind !== "waterAny" || i.kind === "waterAny" && e || i.kind === "plantAny" && !e || i.kind === "grow" && i.mode === "plant" && !e || i.kind === "grow" && i.mode === "water" && e) return { code: X.badPending };
		if (!e && c.lightning) return { code: X.blocked };
		let t = -1;
		if (i.kind === "grow") {
			let e = n.adjust ?? 0, s = a.adjustments[r.by]?.[i.ctx];
			if (s !== void 0) {
				if (s !== e) return { code: X.badAdjust };
			} else {
				let t = Math.max(0, Math.abs(e) - _e(o));
				if (o.compost < t) return { code: X.noCompost };
				o.compost -= t, a.adjustments[r.by] || (a.adjustments[r.by] = {}), a.adjustments[r.by][i.ctx] = e;
			}
			t = ((i.zone + e) % 6 + 6) % 6;
		} else {
			if ((n.adjust ?? 0) !== 0) return { code: X.badAdjust };
			if (!e) {
				if (n.zone === void 0) return { code: X.badTarget };
				t = n.zone;
			}
		}
		if (e) {
			let e = U(o, "seedSpreader") ? 3 : 2;
			if (n.crops.length > e) return { code: X.badCrop };
			let r = /* @__PURE__ */ new Set();
			for (let e of n.crops) {
				let n = `${e.zone}:${e.kind}:${e.idx}`;
				if (r.has(n) || (r.add(n), !Ce(o, e.zone, e.kind, e.idx)) || i.kind === "grow" && !(e.zone === t || c.windy && ne[t].includes(e.zone))) return { code: X.badCrop };
			}
			if (i.kind === "grow" && c.windy && !n.crops.some((e) => ne[t].includes(e.zone))) return { code: X.badCrop };
			q(o, n.crops, s, !0);
		} else Te(o, t, s, !0);
		return a.pendings[r.by].splice(l, 1), a.pendings[r.by].push(...s), {
			state: a,
			fx: []
		};
	}
	if (n.type === "shed") return i.kind === "shed" ? Me(o, n.item) ? (Ne(o, n.item, s, !0), a.pendings[r.by].splice(l, 1), a.pendings[r.by].push(...s), {
		state: a,
		fx: []
	}) : { code: X.badTarget } : { code: X.badPending };
	if (n.type === "apiary") return i.kind !== "apiary" && i.kind !== "apiaryOrFruit" ? { code: X.badPending } : c.cold ? { code: X.blocked } : ke(o, n.section) ? (Ae(o, n.section, s, !0), a.pendings[r.by].splice(l, 1), a.pendings[r.by].push(...s), {
		state: a,
		fx: []
	}) : { code: X.badTarget };
	if (n.type === "fruit") {
		if (i.kind === "fruit") {
			if (i.row !== null && i.row !== n.row) return { code: X.badTarget };
		} else if (i.kind !== "apiaryOrFruit") return { code: X.badPending };
		let e = P[n.row];
		return J(o, e) ? (je(o, e, s, c, !0), a.pendings[r.by].splice(l, 1), a.pendings[r.by].push(...s), {
			state: a,
			fx: []
		}) : { code: X.badTarget };
	}
	if (n.type === "perennial") return i.kind === "perennial" ? i.flower !== null && i.flower !== n.flower || !Ee(o, n.flower) ? { code: X.badTarget } : (De(o, n.flower, s, !0), a.pendings[r.by].splice(l, 1), a.pendings[r.by].push(...s), {
		state: a,
		fx: []
	}) : { code: X.badPending };
	if (n.type === "bonus") {
		if (i.kind !== "bonus") return { code: X.badPending };
		if (n.target === "apiary" && c.cold) return { code: X.blocked };
		let e = n.target === "perennial" ? {
			kind: "perennial",
			flower: null,
			banked: !0
		} : n.target === "apiary" ? {
			kind: "apiary",
			banked: !0
		} : n.target === "fruit" ? {
			kind: "fruit",
			row: null,
			banked: !0
		} : {
			kind: "shed",
			rondel: !1,
			banked: !0
		};
		return a.pendings[r.by].splice(l, 1, e), {
			state: a,
			fx: []
		};
	}
	if (n.type === "market") {
		if (i.kind !== "market") return { code: X.badPending };
		let e = de[0];
		for (let t of de) o.goods >= t.goods && (e = t);
		K(o, e.compost);
		let t = +!!U(o, "fancyLabels"), n = [];
		for (let r = 0; r < e.perennial + t; r += 1) n.push({
			kind: "perennial",
			flower: null,
			banked: !0
		});
		for (let t = 0; t < e.fruit; t += 1) n.push({
			kind: "fruit",
			row: null,
			banked: !0
		});
		for (let t = 0; t < e.bonus; t += 1) n.push({
			kind: "bonus",
			banked: !0
		});
		return a.pendings[r.by].splice(l, 1, ...n), {
			state: a,
			fx: []
		};
	}
	return { code: X.badPending };
}
function $e(e) {
	return {
		public: {
			players: e.players,
			solo: e.solo,
			round: e.round,
			phase: e.phase,
			firstIdx: e.firstIdx,
			weatherOn: e.weatherOn,
			weather: e.weather,
			rondel: {
				pawn: e.rondel.pawn,
				dice: e.rondel.dice.map((e) => ({ ...e }))
			},
			pickQueue: [...e.pickQueue],
			window: e.window,
			lowestDie: e.lowestDie ? { ...e.lowestDie } : null,
			event: e.event,
			sheets: e.sheets,
			pendings: e.pendings,
			done: [...e.done],
			edith: e.edith ? {
				die: e.edith.die,
				space: e.edith.space,
				step: e.edith.step
			} : null
		},
		private: {}
	};
}
function et(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {}, n = {};
	for (let r of e.players) {
		let i = Pe(e.sheets[r]);
		t[r] = i.total, n[r] = i.garden;
	}
	let r = [...e.players].sort((r, i) => t[i] - t[r] || n[i] - n[r] || e.players.indexOf(r) - e.players.indexOf(i)), i = r[0];
	return {
		phase: "done",
		winner: r.filter((e) => t[e] === t[i] && n[e] === n[i]),
		ranking: r,
		scores: t
	};
}
var tt = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: w,
	schemas: {
		action: D,
		publicView: ee,
		privateView: j,
		config: A
	},
	setup: Re,
	reduce: Qe,
	viewFor: $e,
	status: et
}, nt = 1029, rt = 1528, it = 27, at = 32;
function ot(e, t, n) {
	return Array.from({ length: n }, (r, i) => ({
		x: e - it / 2,
		y: t - it / 2 + (n - 1 - i) * at,
		w: it,
		h: it
	}));
}
var st = [
	[
		[186, 204],
		[186, 348],
		[186, 495]
	],
	[
		[337, 204],
		[489, 204],
		[337, 348],
		[489, 348],
		[337, 495]
	],
	[
		[642, 204],
		[801, 205],
		[642, 348],
		[801, 349]
	],
	[
		[801, 533],
		[800, 676],
		[801, 815]
	],
	[
		[642, 533],
		[490, 676],
		[641, 676],
		[490, 815],
		[641, 815]
	],
	[
		[186, 675],
		[337, 675],
		[186, 815],
		[337, 815]
	]
], ct = {
	x: 33,
	y: 32
}, lt = [
	[
		[203, 112],
		[59, 237],
		[59, 496]
	],
	[[518, 68]],
	[[801, 99], [954, 237]],
	[
		[954, 533],
		[954, 847],
		[814, 1057]
	],
	[[487, 1024]],
	[[59, 848], [222, 961]]
];
function ut(e, t, n) {
	let [r, i] = st[e][t];
	return ot(r, i, 4)[n];
}
function dt(e, t, n) {
	let [r, i] = st[e][t];
	return ot(r + ct.x, i + ct.y, 2)[n];
}
function ft(e, t, n) {
	let [r, i] = lt[e][t];
	return ot(r, i, L[e].pumpkins[t].h)[n];
}
var pt = [
	{
		x: 14,
		y: 52,
		w: 257,
		h: 537
	},
	{
		x: 281,
		y: 52,
		w: 257,
		h: 537
	},
	{
		x: 548,
		y: 52,
		w: 467,
		h: 432
	},
	{
		x: 719,
		y: 480,
		w: 295,
		h: 565
	},
	{
		x: 424,
		y: 480,
		w: 286,
		h: 565
	},
	{
		x: 14,
		y: 599,
		w: 400,
		h: 447
	}
], mt = [
	{
		cx: 383,
		cy: 116,
		r: 21
	},
	{
		cx: 626,
		cy: 116,
		r: 21
	},
	{
		cx: 895,
		cy: 165,
		r: 21
	},
	{
		cx: 988,
		cy: 398,
		r: 21
	},
	{
		cx: 987,
		cy: 726,
		r: 21
	},
	{
		cx: 894,
		cy: 959,
		r: 21
	},
	{
		cx: 624,
		cy: 1054,
		r: 21
	},
	{
		cx: 368,
		cy: 1054,
		r: 21
	},
	{
		cx: 115,
		cy: 958,
		r: 21
	},
	{
		cx: 114,
		cy: 726,
		r: 21
	},
	{
		cx: 115,
		cy: 390,
		r: 21
	},
	{
		cx: 111,
		cy: 170,
		r: 21
	}
], ht = [
	37,
	222,
	399,
	574,
	727,
	902
], gt = 27.5, _t = 1366, vt = 36.4;
function yt(e, t) {
	return {
		x: ht[e] - gt / 2,
		y: _t - t * vt - gt / 2,
		w: gt,
		h: gt
	};
}
var bt = 1025, xt = 1535, Z = 28, St = {
	wax: 112,
	honey: 163,
	split: 257,
	main: 139
};
function Ct(e, t) {
	return e === "main" ? {
		x: St.main,
		y: 385 - t * 33,
		w: Z,
		h: Z
	} : {
		x: St[e],
		y: 192 - t * 33,
		w: Z,
		h: Z
	};
}
var wt = [
	{
		y: 611,
		xs: [
			27,
			77,
			127,
			178,
			228,
			278,
			329,
			380
		]
	},
	{
		y: 794,
		xs: [
			28,
			78,
			129,
			179,
			229,
			279,
			330,
			380
		]
	},
	{
		y: 936,
		xs: [
			30,
			88,
			146,
			205,
			263,
			322,
			381
		]
	},
	{
		y: 1059,
		xs: [
			31,
			74,
			117,
			161,
			204,
			247,
			290,
			334,
			377
		]
	}
];
function Tt(e, t) {
	return {
		x: wt[e].xs[t],
		y: wt[e].y,
		w: Z,
		h: Z
	};
}
var Et = [
	[[507, 186]],
	[[673, 188], [706, 188]],
	[[860, 186], [894, 187]],
	[
		[488, 360],
		[522, 360],
		[555, 360]
	],
	[[673, 361], [706, 361]],
	[[881, 361], [914, 362]],
	[
		[465, 539],
		[498, 539],
		[531, 539]
	],
	[
		[656, 540],
		[688, 540],
		[721, 540]
	],
	[[875, 540]],
	[
		[465, 713],
		[499, 713],
		[532, 712]
	],
	[[656, 713], [689, 713]],
	[[876, 715]],
	[
		[472, 889],
		[505, 889],
		[539, 889],
		[472, 922],
		[506, 922],
		[539, 922]
	],
	[
		[657, 891],
		[690, 891],
		[723, 891]
	],
	[
		[849, 892],
		[883, 892],
		[917, 893],
		[949, 893]
	]
];
function Dt(e, t) {
	let [n, r] = Et[e][t];
	return {
		x: n,
		y: r,
		w: Z,
		h: Z
	};
}
var Ot = 34.4, kt = 47.6, At = 1209.6, jt = 35.5, Mt = 27;
function Nt(e) {
	return {
		x: Ot + e % 15 * kt,
		y: At + Math.floor(e / 15) * jt,
		w: Mt,
		h: Mt
	};
}
var Pt = 776.7, Ft = 49.7, It = 1221.5, Lt = 33.9;
function Rt(e) {
	return {
		x: Pt + e % 5 * Ft,
		y: It + Math.floor(e / 5) * Lt,
		w: Mt,
		h: Mt
	};
}
var zt = 1515, Bt = 1038, Vt = [
	{
		x: 121,
		y: 303,
		w: 227,
		h: 227
	},
	{
		x: 436,
		y: 299,
		w: 193,
		h: 186
	},
	{
		x: 659,
		y: 295,
		w: 152,
		h: 129
	},
	{
		x: 864,
		y: 364,
		w: 235,
		h: 167
	},
	{
		x: 693,
		y: 671,
		w: 201,
		h: 163
	},
	{
		x: 379,
		y: 693,
		w: 223,
		h: 121
	},
	{
		x: 98,
		y: 606,
		w: 280,
		h: 159
	}
], Ht = [
	{
		x: 989,
		y: 606,
		w: 64,
		h: 64
	},
	{
		x: 1114,
		y: 618,
		w: 64,
		h: 61
	},
	{
		x: 1239,
		y: 633,
		w: 64,
		h: 61
	},
	{
		x: 1364,
		y: 644,
		w: 64,
		h: 61
	},
	{
		x: 977,
		y: 727,
		w: 61,
		h: 61
	},
	{
		x: 1102,
		y: 739,
		w: 64,
		h: 61
	},
	{
		x: 1227,
		y: 750,
		w: 61,
		h: 61
	},
	{
		x: 1352,
		y: 765,
		w: 61,
		h: 61
	}
], Ut = {
	foggy: "🌫️",
	lightning: "⚡",
	cold: "❄️",
	cloudy: "☁️",
	hot: "☀️",
	windy: "💨"
}, Wt = {
	foggy: "games.threesisters.weather.foggy",
	lightning: "games.threesisters.weather.lightning",
	cold: "games.threesisters.weather.cold",
	cloudy: "games.threesisters.weather.cloudy",
	hot: "games.threesisters.weather.hot",
	windy: "games.threesisters.weather.windy"
}, Gt = {
	1: [[.5, .5]],
	2: [[.28, .28], [.72, .72]],
	3: [
		[.25, .25],
		[.5, .5],
		[.75, .75]
	],
	4: [
		[.28, .28],
		[.72, .28],
		[.28, .72],
		[.72, .72]
	],
	5: [
		[.25, .25],
		[.75, .25],
		[.5, .5],
		[.25, .75],
		[.75, .75]
	],
	6: [
		[.3, .25],
		[.7, .25],
		[.3, .5],
		[.7, .5],
		[.3, .75],
		[.7, .75]
	]
};
function Kt({ x: e, y: t, size: n, value: r, taken: i, label: a }) {
	return /* @__PURE__ */ g("g", {
		role: "img",
		"aria-label": a,
		opacity: i ? .3 : 1,
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ h("rect", {
				x: e,
				y: t,
				width: n,
				height: n,
				rx: n * .22,
				fill: "#ffffff",
				stroke: "var(--color-ink)",
				strokeWidth: n * .055
			}),
			Gt[r].map(([r, i], a) => /* @__PURE__ */ h("circle", {
				cx: e + r * n,
				cy: t + i * n,
				r: n * .095,
				fill: "var(--color-ink)"
			}, a)),
			i && /* @__PURE__ */ g("g", {
				stroke: "var(--color-ink)",
				strokeWidth: n * .07,
				strokeLinecap: "round",
				children: [/* @__PURE__ */ h("line", {
					x1: e + n * .2,
					y1: t + n * .2,
					x2: e + n * .8,
					y2: t + n * .8
				}), /* @__PURE__ */ h("line", {
					x1: e + n * .8,
					y1: t + n * .2,
					x2: e + n * .2,
					y2: t + n * .8
				})]
			})
		]
	});
}
function qt({ pub: e, pickable: t, onPick: n, fitKey: r }) {
	let a = c(), o = i(() => {
		let t = [];
		for (let n = 0; n < 7; n += 1) {
			let r = e.rondel.dice.filter((e) => e.space === n);
			if (r.length === 0) continue;
			let i = Vt[n], a = r.length, o = a <= 1 ? 1 : 2, s = Math.ceil(a / o), c = Math.min(84, (i.w - 24) / o * .92, (i.h - 24) / s * .92), l = i.x + (i.w - o * c) / 2, u = i.y + (i.h - s * c) / 2;
			r.forEach((e, n) => {
				t.push({
					value: e.value,
					taken: e.taken,
					x: l + n % o * c,
					y: u + Math.floor(n / o) * c,
					size: c
				});
			});
		}
		return t;
	}, [e.rondel.dice]), s = i(() => t ? t.map((e) => {
		let t = o.filter((t) => t.value === e && !t.taken), n = Math.min(...t.map((e) => e.x)) - 10, r = Math.min(...t.map((e) => e.y)) - 10, i = Math.max(...t.map((e) => e.x + e.size)) + 10, a = Math.max(...t.map((e) => e.y + e.size)) + 10;
		return {
			key: `die:${e}`,
			rect: {
				x: n,
				y: r,
				w: i - n,
				h: a - r
			}
		};
	}) : [], [t, o]), l = Vt[e.rondel.pawn], u = e.round <= 8 ? Ht[e.round - 1] : null;
	return /* @__PURE__ */ g("div", {
		className: "relative h-full w-full",
		children: [/* @__PURE__ */ g(p, {
			clampToSheet: !0,
			sheetW: zt,
			sheetH: Bt,
			image: "games/threesisters/board.webp",
			eligible: s,
			onTapEligible: (e) => n(Number(e.split(":")[1])),
			readOnly: !t,
			fitKey: r,
			children: [
				u && /* @__PURE__ */ h("rect", {
					x: u.x - 6,
					y: u.y - 6,
					width: u.w + 12,
					height: u.h + 12,
					rx: 14,
					fill: "none",
					stroke: "#f59e0b",
					strokeWidth: 7,
					pointerEvents: "none"
				}),
				/* @__PURE__ */ g("g", {
					role: "img",
					"aria-label": a("games.threesisters.pawnAria"),
					pointerEvents: "none",
					children: [/* @__PURE__ */ h("circle", {
						cx: l.x + 26,
						cy: l.y + 26,
						r: 20,
						fill: "#f5c518",
						stroke: "var(--color-ink)",
						strokeWidth: 4
					}), /* @__PURE__ */ h("text", {
						x: l.x + 26,
						y: l.y + 30,
						textAnchor: "middle",
						dominantBaseline: "central",
						fontSize: 26,
						children: "👩‍🌾"
					})]
				}),
				o.map((e, t) => /* @__PURE__ */ h(Kt, {
					x: e.x,
					y: e.y,
					size: e.size,
					value: e.value,
					taken: e.taken,
					label: a("games.threesisters.dieAria", { n: e.value })
				}, t))
			]
		}), e.weatherOn && /* @__PURE__ */ g("div", {
			className: "absolute top-2 left-1/2 flex -translate-x-1/2 items-center gap-1 rounded-xl border-2 border-ink bg-surface/90 px-2 py-0.5 shadow-[2px_2px_0_var(--color-ink)]",
			children: [/* @__PURE__ */ h("span", {
				className: "text-[10px] font-bold opacity-70",
				children: a("games.threesisters.weatherChip")
			}), pe.map((t, n) => /* @__PURE__ */ h("span", {
				role: "img",
				"aria-label": a(Wt[t]),
				title: a(Wt[t]),
				className: n === e.weather ? "text-2xl" : "text-base opacity-40 grayscale",
				children: Ut[t]
			}, t))]
		})]
	});
}
//#endregion
//#region src/games/threesisters/sheet-views.tsx
function Q({ r: e, rose: t }) {
	let n = e.w * .18, r = e.h * .18;
	return /* @__PURE__ */ g("g", {
		strokeWidth: 7,
		strokeLinecap: "round",
		pointerEvents: "none",
		className: t ? "stroke-rose-600" : "stroke-ink",
		children: [/* @__PURE__ */ h("line", {
			x1: e.x + n,
			y1: e.y + r,
			x2: e.x + e.w - n,
			y2: e.y + e.h - r
		}), /* @__PURE__ */ h("line", {
			x1: e.x + e.w - n,
			y1: e.y + r,
			x2: e.x + n,
			y2: e.y + e.h - r
		})]
	});
}
function Jt({ cells: e }) {
	let t = Math.min(...e.map((e) => e.x)) - 4, n = Math.min(...e.map((e) => e.y)) - 4, r = Math.max(...e.map((e) => e.x + e.w)) + 4, i = Math.max(...e.map((e) => e.y + e.h)) + 4;
	return /* @__PURE__ */ g("g", {
		strokeWidth: 9,
		strokeLinecap: "round",
		pointerEvents: "none",
		className: "stroke-rose-600",
		strokeOpacity: .85,
		children: [/* @__PURE__ */ h("line", {
			x1: t,
			y1: n,
			x2: r,
			y2: i
		}), /* @__PURE__ */ h("line", {
			x1: r,
			y1: n,
			x2: t,
			y2: i
		})]
	});
}
function Yt(e, t, n) {
	return t === "corn" ? Array.from({ length: 4 }, (t, r) => ut(e, n, r)) : t === "bean" ? Array.from({ length: 2 }, (t, r) => dt(e, n, r)) : Array.from({ length: L[e].pumpkins[n].h }, (t, r) => ft(e, n, r));
}
function $(e, t, n) {
	let r = Yt(e, t, n), i = Math.min(...r.map((e) => e.x)) - 5, a = Math.min(...r.map((e) => e.y)) - 5;
	return {
		x: i,
		y: a,
		w: Math.max(...r.map((e) => e.x + e.w)) + 5 - i,
		h: Math.max(...r.map((e) => e.y + e.h)) + 5 - a
	};
}
function Xt({ r: e }) {
	return /* @__PURE__ */ h("rect", {
		x: e.x,
		y: e.y,
		width: e.w,
		height: e.h,
		rx: 12,
		fill: "#7dd3fc",
		fillOpacity: .45,
		stroke: "#0284c7",
		strokeWidth: 5,
		strokeDasharray: "12 8",
		pointerEvents: "none"
	});
}
function Zt({ sheet: e, eligible: t, onTapEligible: n, readOnly: r, fitKey: i, picked: a }) {
	return /* @__PURE__ */ g(p, {
		clampToSheet: !0,
		image: "games/threesisters/sheet-front.webp",
		sheetW: nt,
		sheetH: rt,
		eligible: t,
		onTapEligible: n,
		readOnly: r,
		fitKey: i,
		children: [
			L.map((t, n) => t.pumpkins.map((t, r) => {
				let i = e.pumpkin[n][r];
				return i === -1 ? /* @__PURE__ */ h(Jt, { cells: Yt(n, "pumpkin", r) }, `p${n}:${r}`) : Array.from({ length: i }, (e, t) => /* @__PURE__ */ h(Q, { r: ft(n, r, t) }, `p${n}:${r}:${t}`));
			})),
			L.map((t, n) => Array.from({ length: t.corn }, (t, r) => {
				let i = e.corn[n][r];
				return i === -1 ? /* @__PURE__ */ h(Jt, { cells: Yt(n, "corn", r) }, `c${n}:${r}`) : Array.from({ length: i }, (e, t) => /* @__PURE__ */ h(Q, { r: ut(n, r, t) }, `c${n}:${r}:${t}`));
			})),
			L.map((t, n) => Array.from({ length: t.corn }, (t, r) => {
				let i = e.bean[n][r];
				return i === -1 ? /* @__PURE__ */ h(Jt, { cells: Yt(n, "bean", r) }, `b${n}:${r}`) : Array.from({ length: i }, (e, t) => /* @__PURE__ */ h(Q, { r: dt(n, r, t) }, `b${n}:${r}:${t}`));
			})),
			e.ringClaimed.map((e, t) => {
				if (!e) return null;
				let n = mt[t];
				return /* @__PURE__ */ h(Q, { r: {
					x: n.cx - n.r + 4,
					y: n.cy - n.r + 4,
					w: n.r * 2 - 8,
					h: n.r * 2 - 8
				} }, `ring${t}`);
			}),
			M.map((t, n) => {
				let r = e.perennials[n], i = e.perennialBlocked[n];
				return [...Array.from({ length: r }, (e, t) => /* @__PURE__ */ h(Q, { r: yt(n, t) }, `per${n}:${t}`)), ...Array.from({ length: i }, (e, t) => /* @__PURE__ */ h(Q, {
					r: yt(n, r + t),
					rose: !0
				}, `perx${n}:${t}`))];
			}),
			a?.map((e) => /* @__PURE__ */ h(Xt, { r: $(e.zone, e.kind, e.idx) }, `pk${e.zone}:${e.kind}:${e.idx}`))
		]
	});
}
function Qt({ sheet: e, eligible: t, onTapEligible: n, readOnly: r, fitKey: i }) {
	let a = xe(e);
	return /* @__PURE__ */ g(p, {
		clampToSheet: !0,
		image: "games/threesisters/sheet-back.webp",
		sheetW: bt,
		sheetH: xt,
		eligible: t,
		onTapEligible: n,
		readOnly: r,
		fitKey: i,
		children: [
			Array.from({ length: e.apiaryMain }, (e, t) => /* @__PURE__ */ h(Q, { r: Ct("main", t) }, `am${t}`)),
			[
				"wax",
				"honey",
				"split"
			].map((t) => {
				let n = t === "wax" ? e.apiaryWax : t === "honey" ? e.apiaryHoney : e.apiarySplit, r = e.apiaryBlocked[t];
				return [...Array.from({ length: n }, (e, n) => /* @__PURE__ */ h(Q, { r: Ct(t, n) }, `a${t}${n}`)), ...Array.from({ length: r }, (e, n) => /* @__PURE__ */ h(Q, {
					r: Ct(t, 3 - n),
					rose: !0
				}, `ax${t}${n}`))];
			}),
			F.map((t, n) => [...Array.from({ length: e.fruit[n] }, (e, t) => /* @__PURE__ */ h(Q, { r: Tt(n, t) }, `fr${n}:${t}`)), ...Array.from({ length: e.fruitBlocked[n] }, (e, r) => /* @__PURE__ */ h(Q, {
				r: Tt(n, t - 1 - r),
				rose: !0
			}, `frx${n}:${r}`))]),
			le.map((t, n) => e.shedCrossed[n] ? /* @__PURE__ */ h(Jt, { cells: Array.from({ length: B[n] }, (e, t) => Dt(n, t)) }, `sx${t}`) : Array.from({ length: e.shed[n] }, (e, r) => /* @__PURE__ */ h(Q, { r: Dt(n, r) }, `s${t}:${r}`))),
			Array.from({ length: a }, (e, t) => t + 1).map((t) => e.deadStars.includes(t) ? /* @__PURE__ */ h(Q, {
				r: Nt(t - 1),
				rose: !0
			}, `gx${t}`) : /* @__PURE__ */ h(Q, { r: Nt(t - 1) }, `g${t}`)),
			Array.from({ length: e.compostGained }, (t, n) => {
				let r = n >= e.compost;
				return /* @__PURE__ */ h(Q, {
					r: Rt(n),
					rose: r
				}, `cp${n}`);
			})
		]
	});
}
function $t(e, t) {
	let n = e.perennials[t] + e.perennialBlocked[t];
	return n < 6 ? yt(t, n) : null;
}
function en(e, t) {
	return e.fruit[t] + e.fruitBlocked[t] < F[t] ? Tt(t, e.fruit[t]) : null;
}
function tn(e, t) {
	return !e.shedCrossed[t] && e.shed[t] < B[t] ? Dt(t, e.shed[t]) : null;
}
function nn(e, t) {
	return Ct(e, t);
}
//#endregion
//#region src/games/threesisters/view-player.tsx
var rn = {
	garden: "games.threesisters.tabGarden",
	yard: "games.threesisters.tabYard",
	board: "games.threesisters.tabBoard"
}, an = "btn-base min-h-11 flex-1 border-3 border-ink text-sm font-black text-white", on = "btn-quiet min-h-11 flex-1 text-sm font-bold", sn = {
	grow: "garden",
	waterAny: "garden",
	plantAny: "garden",
	growAny: "garden",
	perennial: "garden",
	edithCrop: "garden",
	shed: "yard",
	apiaryOrFruit: "yard",
	apiary: "yard",
	fruit: "yard",
	bonus: "garden",
	market: "yard"
};
function cn(e, t) {
	switch (t.kind) {
		case "grow": return t.rondel ? e("games.threesisters.pGrowRondel") : e("games.threesisters.pGrow", { n: t.zone + 1 });
		case "waterAny": return e("games.threesisters.pWaterAny");
		case "plantAny": return e("games.threesisters.pPlantAny");
		case "growAny": return e("games.threesisters.pGrowAny");
		case "shed": return e("games.threesisters.pShed");
		case "apiaryOrFruit": return e("games.threesisters.pApiaryOrFruit");
		case "apiary": return e("games.threesisters.pApiary");
		case "fruit": return e("games.threesisters.pFruit");
		case "perennial": return e("games.threesisters.pPerennial");
		case "bonus": return e("games.threesisters.pBonus");
		case "market": return e("games.threesisters.pMarket");
		case "edithCrop": return e("games.threesisters.edithCropPrompt");
	}
}
var ln = (e) => (e % 6 + 6) % 6, un = (e) => `${e.zone}:${e.kind}:${e.idx}`;
function dn(e) {
	let t = e.public;
	return /* @__PURE__ */ h(fn, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function fn({ pub: e, members: t, myRid: n, send: r }) {
	let a = c(), [s, d] = o("board"), [p, _] = o(n), [v, y] = o(null), [b, x] = o(0), [S, C] = o("plant"), [T, E] = o([]), D = e.sheets[n], O = e.sheets[p] ?? D, k = i(() => e.pendings[n] ?? [], [e.pendings, n]), A = (e) => t.find((t) => t.rid === e)?.name ?? e, ee = e.phase === "gardening" && e.window === null && e.edith !== null && k.some((e) => e.kind === "edithCrop"), j = e.phase === "gardening" && (e.window === n || ee) || (e.phase === "lowest" || e.phase === "event") && !e.done.includes(n), M = v !== null && v < k.length ? k[v] : void 0, N = e.weatherOn && e.weather === 1, F = e.weatherOn && e.weather === 2, I = e.weatherOn && e.weather === 5, R = e.phase === "gardening" && e.window === null && e.pickQueue[0] === n, [re, ie] = o(!1);
	R !== re && (ie(R), R && d("board"));
	let [ae, oe] = o(null);
	if (ae === null || ae.mine !== j || ae.pendings !== k) {
		oe({
			mine: j,
			pendings: k
		}), x(0), C("plant"), E([]);
		let e = null;
		if (j && k.length > 0) {
			let t = k.findIndex((e) => !e.banked);
			e = t >= 0 ? t : 0;
		}
		y(e), j && e !== null && (d(sn[k[e].kind]), _(n));
	}
	let se = e.phase === "planning" && e.players[e.firstIdx] === n, ce = i(() => {
		if (!R) return null;
		let t = e.rondel.dice.filter((e) => !e.taken).map((e) => e.value);
		return e.solo && e.pickQueue.length === 2 ? [Math.min(...t)] : [...new Set(t)];
	}, [
		R,
		e.rondel.dice,
		e.solo,
		e.pickQueue.length
	]), z = _e(D), B = M?.kind === "grow" ? ln(M.zone + b) : -1, V = M ? M.kind === "grow" ? M.mode === "choose" ? S : M.mode : M.kind === "plantAny" ? "plant" : M.kind === "waterAny" ? "water" : S : "plant", ue = U(D, "seedSpreader") ? 3 : 2, de = M?.kind === "grow" && I && T.length > 0 && !T.some((e) => ne[B].includes(e.zone)), { frontEligible: fe, backEligible: pe } = i(() => {
		let e = [], t = [];
		if (!j || !M) return {
			frontEligible: e,
			backEligible: t
		};
		let n = (t) => {
			for (let n of t) {
				for (let t = 0; t < L[n].corn; t += 1) Ce(D, n, "corn", t) && e.push({
					key: `crop:${n}:corn:${t}`,
					rect: $(n, "corn", t)
				}), Ce(D, n, "bean", t) && e.push({
					key: `crop:${n}:bean:${t}`,
					rect: $(n, "bean", t)
				});
				L[n].pumpkins.forEach((t, r) => {
					Ce(D, n, "pumpkin", r) && e.push({
						key: `crop:${n}:pumpkin:${r}`,
						rect: $(n, "pumpkin", r)
					});
				});
			}
		};
		switch (M.kind) {
			case "grow":
			case "plantAny":
			case "growAny":
				V === "plant" && n(M.kind === "grow" ? I ? [B, ...ne[B]] : [B] : [
					0,
					1,
					2,
					3,
					4,
					5
				]), V !== "plant" && !N && (M.kind === "grow" ? e.push({
					key: `zone:${B}`,
					rect: pt[B]
				}) : pt.forEach((t, n) => e.push({
					key: `zone:${n}`,
					rect: t
				})));
				break;
			case "waterAny":
				N || pt.forEach((t, n) => e.push({
					key: `zone:${n}`,
					rect: t
				}));
				break;
			case "perennial": {
				let t = M.flower === null ? [
					0,
					1,
					2,
					3,
					4,
					5
				] : [M.flower];
				for (let n of t) {
					if (!Ee(D, n)) continue;
					let t = $t(D, n);
					t && e.push({
						key: `per:${n}`,
						rect: t
					});
				}
				break;
			}
			case "edithCrop":
				for (let t of M.candidates) e.push({
					key: `edith:${M.cropKind}:${t}`,
					rect: $(M.zone, M.cropKind, t)
				});
				break;
			case "shed":
				le.forEach((e, n) => {
					let r = tn(D, n);
					r && Me(D, n) && t.push({
						key: `shed:${n}`,
						rect: r
					});
				});
				break;
			case "apiary":
			case "apiaryOrFruit":
				if (!F) for (let e of [
					"main",
					"wax",
					"honey",
					"split"
				]) {
					if (!ke(D, e)) continue;
					let n = e === "main" ? D.apiaryMain : e === "wax" ? D.apiaryWax : e === "honey" ? D.apiaryHoney : D.apiarySplit;
					t.push({
						key: `apiary:${e}`,
						rect: nn(e, n)
					});
				}
				if (M.kind === "apiary") break;
				te.forEach((e, n) => {
					let r = en(D, n);
					r && J(D, n) && t.push({
						key: `fruit:${n}`,
						rect: r
					});
				});
				break;
			case "fruit": {
				let e = M.row === null ? [
					0,
					1,
					2,
					3
				] : [P[M.row]];
				for (let n of e) {
					let e = en(D, n);
					e && J(D, n) && t.push({
						key: `fruit:${n}`,
						rect: e
					});
				}
				break;
			}
		}
		return {
			frontEligible: e,
			backEligible: t
		};
	}, [
		j,
		M,
		D,
		V,
		N,
		F,
		B,
		I
	]), H = j && p === n && !!M, me = (e) => {
		E((t) => {
			let n = un(e);
			return t.some((e) => un(e) === n) ? t.filter((e) => un(e) !== n) : t.length >= ue ? t : [...t, e];
		});
	}, he = (e) => {
		if (v === null || !M) return;
		let [t, n, i, a] = e.split(":");
		t === "crop" ? me({
			zone: Number(n),
			kind: i,
			idx: Number(a)
		}) : t === "zone" ? M.kind === "grow" ? r({
			type: "water",
			index: v,
			adjust: b
		}) : r({
			type: "water",
			index: v,
			zone: Number(n)
		}) : t === "per" ? r({
			type: "perennial",
			index: v,
			flower: Number(n)
		}) : t === "edith" && r({
			type: "edithCrop",
			index: v,
			kind: n,
			idx: Number(i)
		});
	}, ge = (e) => {
		if (v === null || !M) return;
		let [t, n] = e.split(":");
		t === "shed" ? r({
			type: "shed",
			index: v,
			item: Number(n)
		}) : t === "apiary" ? r({
			type: "apiary",
			index: v,
			section: n
		}) : t === "fruit" && r({
			type: "fruit",
			index: v,
			row: te[Number(n)]
		});
	}, ve = () => {
		v !== null && T.length !== 0 && r({
			type: "plant",
			index: v,
			crops: T,
			...M?.kind === "grow" ? { adjust: b } : {}
		});
	}, W = (() => {
		if (e.phase === "planning") return se ? {
			tone: "accent",
			text: a("games.threesisters.rollPrompt")
		} : {
			tone: "info",
			text: a("games.threesisters.rollWait", { name: A(e.players[e.firstIdx]) })
		};
		if (e.phase === "gardening") {
			if (k.some((e) => e.kind === "edithCrop") && (e.window === n || ee)) return {
				tone: "warn",
				text: a("games.threesisters.edithCropPrompt")
			};
			if (e.window === n) return {
				tone: "accent",
				text: a("games.threesisters.windowPrompt")
			};
			if (e.window) return {
				tone: "info",
				text: a("games.threesisters.windowWait", { name: A(e.window) })
			};
			if (R) return {
				tone: "accent",
				text: a("games.threesisters.pickPrompt")
			};
			let t = e.pickQueue[0];
			return t === "edith" ? {
				tone: "info",
				text: a("games.threesisters.edithAct", { n: e.edith?.die ?? 0 })
			} : {
				tone: "info",
				text: a("games.threesisters.pickWait", { name: A(t ?? "") })
			};
		}
		if (e.phase === "lowest") return e.done.includes(n) ? {
			tone: "info",
			text: a("games.threesisters.doneWait")
		} : {
			tone: "accent",
			text: a("games.threesisters.lowestPrompt", { n: e.lowestDie?.value ?? 0 })
		};
		if (e.phase === "event") {
			if (e.done.includes(n)) return {
				tone: "info",
				text: a("games.threesisters.doneWait")
			};
			let t = e.event === "shed" ? "games.threesisters.eventShed" : e.event === "rain" ? "games.threesisters.eventRain" : "games.threesisters.eventMarket";
			return {
				tone: "accent",
				text: a(t)
			};
		}
		return {
			tone: "done",
			text: a("games.threesisters.doneWait")
		};
	})(), ye = a("games.threesisters.roundChip", { n: e.round }) + (e.weatherOn ? ` ${[
		"🌫️",
		"⚡",
		"❄️",
		"☁️",
		"☀️",
		"💨"
	][e.weather]}` : ""), be = k.some((e) => !e.banked), xe = j && (e.phase !== "gardening" && e.phase !== "lowest" || !be), Se = j && U(D, "shovel") && D.compost >= 3, G = !!M && "rondel" in M && M.rondel && U(D, "mulch"), K = !!M && (M.kind === "grow" || M.kind === "plantAny" || M.kind === "growAny" || M.kind === "waterAny"), we = !!M && (M.kind === "grow" && M.mode === "choose" || M.kind === "growAny"), q = `${s}:${p}`;
	return /* @__PURE__ */ h(f, {
		adaptive: !0,
		scroll: !1,
		className: "threesisters-screen",
		children: /* @__PURE__ */ g("div", {
			className: "threesisters-layout",
			children: [
				/* @__PURE__ */ g("div", {
					className: "threesisters-top",
					children: [/* @__PURE__ */ h(l, {
						tone: W.tone,
						text: W.text,
						sub: W.sub,
						chip: ye,
						accent: w.accent
					}), /* @__PURE__ */ h(u, {
						adaptive: !0,
						members: t.filter((t) => e.players.includes(t.rid)),
						myRid: n,
						variant: "plate",
						status: (t) => {
							let n = e.sheets[t];
							return n ? /* @__PURE__ */ g("span", {
								className: "flex items-center gap-1.5 font-mono tabular-nums",
								children: [/* @__PURE__ */ h("span", {
									className: "text-base font-black",
									children: Pe(n).total
								}), /* @__PURE__ */ g("span", {
									className: "text-[10px] font-bold opacity-70",
									children: [
										"📦",
										n.goods,
										" 🍂",
										n.compost
									]
								})]
							}) : null;
						},
						action: (t) => e.phase === "gardening" ? e.window === t ? "pending" : null : e.phase === "lowest" || e.phase === "event" ? e.done.includes(t) ? "done" : "pending" : null,
						onPick: (e) => _(e),
						picked: (e) => e === p
					})]
				}),
				/* @__PURE__ */ h("div", {
					className: "threesisters-tabs flex shrink-0 gap-1.5",
					role: "tablist",
					children: [
						"garden",
						"yard",
						"board"
					].map((e) => /* @__PURE__ */ h("button", {
						type: "button",
						role: "tab",
						"aria-selected": s === e,
						onClick: () => d(e),
						className: s === e ? an : on,
						style: s === e ? { background: w.accent } : void 0,
						children: a(rn[e])
					}, e))
				}),
				/* @__PURE__ */ g("div", {
					className: "threesisters-board frame min-h-0 flex-1 overflow-hidden",
					children: [/* @__PURE__ */ g("div", {
						className: "threesisters-primary",
						children: [
							s === "garden" && /* @__PURE__ */ h(Zt, {
								sheet: O,
								eligible: H ? fe : void 0,
								onTapEligible: he,
								readOnly: !H,
								fitKey: q,
								picked: H && K && V === "plant" ? T : void 0
							}),
							s === "yard" && /* @__PURE__ */ h(Qt, {
								sheet: O,
								eligible: H ? pe : void 0,
								onTapEligible: ge,
								readOnly: !H,
								fitKey: q
							}),
							s === "board" && /* @__PURE__ */ h(qt, {
								pub: e,
								pickable: ce,
								onPick: (e) => r({
									type: "pick",
									value: e
								}),
								fitKey: q
							})
						]
					}), s !== "board" && /* @__PURE__ */ h("div", {
						className: "threesisters-peer",
						children: h(s === "garden" ? Qt : Zt, {
							sheet: O,
							readOnly: !0,
							fitKey: `peer:${q}`
						})
					})]
				}),
				/* @__PURE__ */ g("div", {
					className: "threesisters-actions safe-b flex shrink-0 flex-col gap-1.5",
					children: [
						j && k.length > 0 && /* @__PURE__ */ h("div", {
							className: "threesisters-journal flex gap-1.5 overflow-x-auto pb-0.5",
							"aria-label": a("games.threesisters.journal"),
							children: k.map((e, t) => /* @__PURE__ */ h("button", {
								type: "button",
								onClick: () => {
									y(t), x(0), C("plant"), E([]), d(sn[e.kind]), _(n);
								},
								className: `min-h-9 shrink-0 rounded-lg border-2 px-2.5 text-xs font-bold ${t === v ? "border-ink text-white" : e.kind === "edithCrop" ? "border-rose-500 bg-rose-100 text-rose-800" : e.banked ? "border-ink/30 bg-surface text-ink" : "border-amber-500 bg-amber-100 text-amber-900"}`,
								style: t === v ? { background: w.accent } : void 0,
								children: cn(a, e)
							}, t))
						}),
						/* @__PURE__ */ g("div", {
							className: "threesisters-decision flex min-h-12 items-center gap-2",
							children: [
								e.phase === "planning" && se && /* @__PURE__ */ h("button", {
									type: "button",
									onClick: () => r({ type: "roll" }),
									className: "btn-base min-h-12 w-full text-base font-black text-white",
									style: { background: w.accent },
									children: a("games.threesisters.roll")
								}),
								R && /* @__PURE__ */ h("p", {
									className: "w-full text-center text-sm font-bold opacity-80",
									children: a("games.threesisters.pickPrompt")
								}),
								j && M && /* @__PURE__ */ g(m, { children: [
									K && /* @__PURE__ */ g("div", {
										className: "flex min-w-0 flex-1 flex-wrap items-center gap-1.5",
										children: [
											M.kind === "grow" && /* @__PURE__ */ g("div", {
												className: "flex items-center gap-1",
												children: [
													/* @__PURE__ */ h("button", {
														type: "button",
														"aria-label": a("games.threesisters.adjustDown"),
														disabled: Math.max(0, Math.abs(b - 1) - z) > D.compost,
														onClick: () => x(b - 1),
														className: "btn-quiet grid size-9 place-items-center text-lg font-black disabled:opacity-30",
														children: "−"
													}),
													/* @__PURE__ */ h("span", {
														className: "min-w-14 text-center text-xs font-black",
														children: a("games.threesisters.zoneName", { n: B + 1 })
													}),
													/* @__PURE__ */ h("button", {
														type: "button",
														"aria-label": a("games.threesisters.adjustUp"),
														disabled: Math.max(0, Math.abs(b + 1) - z) > D.compost,
														onClick: () => x(b + 1),
														className: "btn-quiet grid size-9 place-items-center text-lg font-black disabled:opacity-30",
														children: "+"
													})
												]
											}),
											we && /* @__PURE__ */ g("div", {
												className: "flex gap-1",
												role: "group",
												children: [/* @__PURE__ */ h("button", {
													type: "button",
													onClick: () => C("plant"),
													className: V === "plant" ? "btn-base min-h-9 border-2 border-ink px-2.5 text-xs font-black text-white" : "btn-quiet min-h-9 px-2.5 text-xs font-bold",
													style: V === "plant" ? { background: w.accent } : void 0,
													children: a("games.threesisters.plantMode")
												}), /* @__PURE__ */ h("button", {
													type: "button",
													disabled: N,
													onClick: () => C("water"),
													className: V === "water" ? "btn-base min-h-9 border-2 border-ink px-2.5 text-xs font-black text-white" : "btn-quiet min-h-9 px-2.5 text-xs font-bold disabled:opacity-30",
													style: V === "water" ? { background: w.accent } : void 0,
													children: a("games.threesisters.waterMode")
												})]
											}),
											V === "plant" && M.kind !== "waterAny" ? /* @__PURE__ */ h("button", {
												type: "button",
												disabled: T.length === 0 || de,
												onClick: ve,
												className: "btn-base min-h-11 border-3 border-ink px-3 text-sm font-black text-white disabled:opacity-40",
												style: { background: w.accent },
												children: a("games.threesisters.plantConfirm", { n: T.length })
											}) : M.kind === "grow" ? /* @__PURE__ */ h("button", {
												type: "button",
												onClick: () => v !== null && r({
													type: "water",
													index: v,
													adjust: b
												}),
												className: "btn-base min-h-11 border-3 border-ink px-3 text-sm font-black text-white",
												style: { background: w.accent },
												children: a("games.threesisters.waterConfirm")
											}) : /* @__PURE__ */ h("span", {
												className: "text-xs font-bold opacity-70",
												children: a(N ? "games.threesisters.errBlocked" : "games.threesisters.pickZone")
											}),
											M.kind === "grow" && z > 0 && /* @__PURE__ */ h("span", {
												className: "text-[10px] font-bold opacity-60",
												children: a("games.threesisters.adjustFreeHint", { n: z })
											})
										]
									}),
									(M.kind === "shed" || M.kind === "apiary" || M.kind === "fruit" || M.kind === "perennial" || M.kind === "edithCrop") && /* @__PURE__ */ h("p", {
										className: "min-w-0 flex-1 text-xs font-bold opacity-80",
										children: M.kind === "edithCrop" ? a("games.threesisters.edithCropPrompt") : M.kind === "apiary" && F ? a("games.threesisters.errBlocked") : a("games.threesisters.pickOnSheet")
									}),
									M.kind === "apiaryOrFruit" && /* @__PURE__ */ h("p", {
										className: "min-w-0 flex-1 text-xs font-bold opacity-80",
										children: a(F ? "games.threesisters.errBlocked" : "games.threesisters.pickOnSheet")
									}),
									M.kind === "bonus" && /* @__PURE__ */ g("div", {
										className: "flex min-w-0 flex-1 flex-wrap gap-1.5",
										"aria-label": a("games.threesisters.bonusTitle"),
										children: [
											/* @__PURE__ */ h("button", {
												type: "button",
												onClick: () => v !== null && r({
													type: "bonus",
													index: v,
													target: "perennial"
												}),
												className: "btn-quiet min-h-9 px-2.5 text-xs font-bold",
												children: a("games.threesisters.bonusPerennial")
											}),
											/* @__PURE__ */ h("button", {
												type: "button",
												disabled: F,
												onClick: () => v !== null && r({
													type: "bonus",
													index: v,
													target: "apiary"
												}),
												className: "btn-quiet min-h-9 px-2.5 text-xs font-bold disabled:opacity-30",
												children: a("games.threesisters.bonusApiary")
											}),
											/* @__PURE__ */ h("button", {
												type: "button",
												onClick: () => v !== null && r({
													type: "bonus",
													index: v,
													target: "fruit"
												}),
												className: "btn-quiet min-h-9 px-2.5 text-xs font-bold",
												children: a("games.threesisters.bonusFruit")
											}),
											/* @__PURE__ */ h("button", {
												type: "button",
												onClick: () => v !== null && r({
													type: "bonus",
													index: v,
													target: "shed"
												}),
												className: "btn-quiet min-h-9 px-2.5 text-xs font-bold",
												children: a("games.threesisters.bonusShed")
											})
										]
									}),
									M.kind === "market" && /* @__PURE__ */ h("button", {
										type: "button",
										onClick: () => v !== null && r({
											type: "market",
											index: v
										}),
										className: "btn-base min-h-11 flex-1 border-3 border-ink px-3 text-sm font-black text-white",
										style: { background: w.accent },
										children: a("games.threesisters.marketApply", { n: D.goods })
									}),
									G && /* @__PURE__ */ h("button", {
										type: "button",
										title: a("games.threesisters.mulchSwap"),
										onClick: () => v !== null && r({
											type: "mulch",
											index: v
										}),
										className: "btn-quiet min-h-9 shrink-0 px-2 text-xs font-bold",
										children: "🍂→🌷"
									}),
									M.kind !== "edithCrop" && /* @__PURE__ */ h("button", {
										type: "button",
										"aria-label": a("games.threesisters.skipAria"),
										onClick: () => v !== null && r({
											type: "skip",
											index: v
										}),
										className: "btn-quiet grid size-9 shrink-0 place-items-center text-sm font-black text-rose-600",
										children: "✕"
									})
								] }),
								j && !M && e.phase !== "planning" && !R && /* @__PURE__ */ h("p", {
									className: "w-full text-center text-sm font-bold opacity-80",
									children: a("games.threesisters.windowPrompt")
								}),
								!j && !se && !R && /* @__PURE__ */ h("p", {
									className: "w-full text-center text-sm font-bold opacity-60",
									children: a("games.threesisters.doneWait")
								})
							]
						}),
						j && /* @__PURE__ */ g("div", {
							className: "flex gap-2",
							children: [Se && /* @__PURE__ */ h("button", {
								type: "button",
								title: a("games.threesisters.shovelSwap"),
								onClick: () => r({ type: "shovel" }),
								className: "btn-quiet min-h-11 shrink-0 px-3 text-xs font-bold",
								children: "🪏×3🍂"
							}), /* @__PURE__ */ h("button", {
								type: "button",
								disabled: !xe,
								onClick: () => r({ type: "done" }),
								className: "btn-base min-h-12 flex-1 border-3 border-ink text-base font-black text-white disabled:opacity-40",
								style: { background: w.accent },
								children: a("games.threesisters.done")
							})]
						})
					]
				})
			]
		})
	});
}
//#endregion
//#region src/games/threesisters/endgame-review.tsx
function pn({ board: e, renderResult: t, ...n }) {
	let s = c(), [l, u] = o(!0), [d, f] = o(null), p = a(null), m = a(null), v = a(null);
	r(() => {
		if (!d) return;
		v.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => f(null), 5e3);
		return () => clearTimeout(e);
	}, [d]);
	let x = (e) => {
		f(null), u(e), requestAnimationFrame(() => (e ? p : m).current?.focus({ preventScroll: !0 }));
	}, S = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => f({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => f({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => f({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), C = {
		...n,
		...S
	};
	return /* @__PURE__ */ g("div", {
		className: "threesisters-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ h("div", {
				className: "threesisters-endgame-board",
				inert: l,
				children: e
			}),
			/* @__PURE__ */ h("div", {
				className: "threesisters-endgame-overlay",
				hidden: !l,
				children: /* @__PURE__ */ g("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), x(!1));
					},
					className: "threesisters-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ g("header", {
							className: "threesisters-endgame-heading",
							children: [/* @__PURE__ */ g("div", {
								className: "threesisters-endgame-brand",
								children: [/* @__PURE__ */ h("span", {
									"aria-hidden": "true",
									children: w.icon
								}), s(w.nameKey)]
							}), /* @__PURE__ */ h("button", {
								type: "button",
								ref: p,
								className: "btn-quiet",
								"aria-label": s("games.threesisters.reviewHide"),
								title: s("games.threesisters.reviewHide"),
								onClick: () => x(!1),
								children: /* @__PURE__ */ h(y, { size: 19 })
							})]
						}),
						/* @__PURE__ */ h("div", {
							className: "threesisters-endgame-result",
							inert: d !== null,
							children: t(C)
						}),
						d && /* @__PURE__ */ g("div", {
							className: "threesisters-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || f(null);
							},
							children: [/* @__PURE__ */ h("button", {
								type: "button",
								ref: v,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = d.run;
									f(null), e();
								},
								children: s(d.label === "again" ? "games.threesisters.reviewConfirmAgain" : "games.threesisters.reviewConfirmLobby")
							}), /* @__PURE__ */ h("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									f(null), p.current?.focus({ preventScroll: !0 });
								},
								children: s("games.threesisters.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ h("div", {
				className: "threesisters-endgame-toolbar",
				hidden: l,
				children: /* @__PURE__ */ g("button", {
					type: "button",
					className: "btn-base",
					ref: m,
					onClick: () => x(!0),
					children: [
						/* @__PURE__ */ h(b, { size: 18 }),
						s("games.threesisters.reviewShow"),
						/* @__PURE__ */ h(_, { size: 18 })
					]
				})
			})
		]
	});
}
function mn({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: l, rows: u, renderRowExtra: f, summary: p, navigation: _, content: b, afterRanking: S, scoreUnit: C, rankOf: T }) {
	let E = c(), D = s((e) => e.locale), [O, k] = o({}), A = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? d(n, D) : e;
	}, ee = (t, n) => T?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), j = e.ranking.some((t) => e.scores?.[t] !== void 0), M = (t, n) => /* @__PURE__ */ g("div", {
		className: "threesisters-score-identity",
		children: [
			/* @__PURE__ */ g("span", {
				className: "threesisters-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ h("span", {
					"aria-label": E("games.threesisters.reviewWinner"),
					children: "♛ "
				}), j && ee(t, n)]
			}),
			/* @__PURE__ */ g("span", {
				className: "threesisters-score-name",
				children: [A(t), t === r && /* @__PURE__ */ h("small", { children: E("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ g("small", {
				className: "threesisters-score-autopilot",
				children: [
					/* @__PURE__ */ h(v, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), N = (t) => e.ranking.map((n) => /* @__PURE__ */ h("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ g("div", {
		className: "threesisters-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ h(x, {}),
			_,
			/* @__PURE__ */ g("div", {
				className: "threesisters-score-body",
				children: [
					p && /* @__PURE__ */ h("div", {
						className: "threesisters-score-summary",
						children: p
					}),
					i !== void 0 && /* @__PURE__ */ h("p", {
						className: "threesisters-score-hints",
						children: E("session.hint.usedCount", { n: i })
					}),
					b ?? (u?.length ? /* @__PURE__ */ h("div", {
						className: "threesisters-score-table-scroll",
						children: /* @__PURE__ */ g("table", {
							className: "threesisters-score-table",
							"aria-label": E(w.nameKey),
							children: [
								/* @__PURE__ */ h("thead", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", { scope: "col" }), /* @__PURE__ */ h(m, { children: e.ranking.map((t, n) => /* @__PURE__ */ h("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: M(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ h("tbody", { children: u.map((e, t) => /* @__PURE__ */ g(n, { children: [/* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ g("button", {
										type: "button",
										"aria-expanded": !!O[t],
										onClick: () => k((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ h(y, { size: 15 }), e.label]
									}) : e.label
								}), N(e)] }), O[t] && e.details?.map((e, t) => /* @__PURE__ */ g("tr", {
									className: "threesisters-score-sub",
									children: [/* @__PURE__ */ h("th", {
										scope: "row",
										children: e.label
									}), N(e)]
								}, t))] }, t)) }),
								j && /* @__PURE__ */ h("tfoot", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
									scope: "row",
									children: E("games.threesisters.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ h("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ h("ol", {
						className: "threesisters-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ g("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ g("div", {
								className: "threesisters-score-rankline",
								children: [M(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ g("strong", {
									className: "threesisters-score-points",
									children: [e.scores[t], C && /* @__PURE__ */ h("small", { children: C })]
								})]
							}), f?.(t)]
						}, t))
					})),
					S,
					!!u?.length && f && /* @__PURE__ */ h("div", {
						className: "threesisters-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ g("details", { children: [/* @__PURE__ */ h("summary", { children: A(e) }), f(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ g("footer", {
				className: "threesisters-score-actions",
				children: [
					l && /* @__PURE__ */ h("button", {
						type: "button",
						className: "btn-quiet",
						onClick: l,
						children: E("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ h("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: E("session.result.playAgain")
					}),
					!a && !l && /* @__PURE__ */ h("p", { children: E("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/threesisters/endgame-scores.tsx
function hn(e) {
	let t = c(), n = e.public, r = (e) => n.sheets[e] ? Pe(n.sheets[e]) : void 0, i = [
		["garden", "games.threesisters.scoreGarden"],
		["perennials", "games.threesisters.scorePerennials"],
		["apiary", "games.threesisters.scoreApiary"],
		["fruit", "games.threesisters.scoreFruit"],
		["shed", "games.threesisters.scoreShed"]
	].map(([e, n]) => ({
		label: t(n),
		value: (t) => r(t)?.[e] ?? "—"
	}));
	return /* @__PURE__ */ h(mn, {
		...e,
		renderRowExtra: void 0,
		rows: i,
		summary: n.solo && /* @__PURE__ */ h("p", { children: t("games.threesisters.soloRating", { n: Ie(r(e.myRid)?.total ?? 0) }) })
	});
}
//#endregion
//#region src/games/threesisters/game-over.tsx
function gn(e) {
	return /* @__PURE__ */ h(hn, { ...e });
}
function _n(e) {
	return /* @__PURE__ */ h(pn, {
		...e,
		board: /* @__PURE__ */ h(dn, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ h(gn, { ...e })
	});
}
//#endregion
//#region src/games/threesisters/game-over-row.tsx
var vn = [
	"games.threesisters.scoreGarden",
	"games.threesisters.scorePerennials",
	"games.threesisters.scoreApiary",
	"games.threesisters.scoreFruit",
	"games.threesisters.scoreShed"
];
function yn({ public: e, rid: t }) {
	let n = c(), r = e, i = r.sheets[t];
	if (!i) return null;
	let a = Pe(i), o = [
		a.garden,
		a.perennials,
		a.apiary,
		a.fruit,
		a.shed
	];
	return /* @__PURE__ */ g("div", {
		className: "threesisters-over-parts mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] font-bold opacity-80",
		children: [vn.map((e, t) => /* @__PURE__ */ g("span", {
			className: "font-mono tabular-nums",
			children: [
				n(e),
				" ",
				o[t]
			]
		}, e)), r.solo && /* @__PURE__ */ h("span", {
			className: "font-black text-amber-700",
			children: n("games.threesisters.soloRating", { n: Ie(a.total) })
		})]
	});
}
//#endregion
//#region src/games/threesisters/options.tsx
function bn({ value: e, onChange: t }) {
	let n = c(), r = A.safeParse(e), i = r.success ? r.data : A.parse(void 0);
	return /* @__PURE__ */ g(C, {
		title: n("games.threesisters.optWeather"),
		children: [/* @__PURE__ */ h(S, {
			name: "threesisters-weather",
			value: "false",
			checked: !i.weather,
			label: n("games.threesisters.weatherOff"),
			hint: n("games.threesisters.weatherOffHint"),
			accent: w.accent,
			onChange: () => t({
				...i,
				weather: !1
			})
		}), /* @__PURE__ */ h(S, {
			name: "threesisters-weather",
			value: "true",
			checked: i.weather,
			label: n("games.threesisters.weatherOn"),
			hint: n("games.threesisters.weatherOnHint"),
			accent: w.accent,
			onChange: () => t({
				...i,
				weather: !0
			})
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/threesisters/entry.tsx
var xn = {
	definition: tt,
	View: dn,
	OverView: _n,
	RowView: yn,
	Options: bn,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "农场三姐妹",
			desc: "骰写种田:轮盘选骰务花园,堆肥调点抢收获",
			rules: "目标：在8轮游戏中发展自己的计分纸，分别从花园、多年生植物、蜂箱、水果和工具棚获得分数，总分最高的玩家获胜。\n流程(每轮三阶段):\n· 规划:起始玩家掷出比人数多 2 颗的骰子,按点数分组。\n· 各组按点数升序、从 Edith 棋子格起顺时针放上轮盘,棋子移到最高组之后。\n· 园艺:从起始玩家开始，按顺序轮流选择,每人选 1 颗骰:先执行花园行动(在骰子点数对应的区域种植至多 2 株,或给该区浇水),再执行所在格的轮盘行动。\n· 所有玩家选完骰子后，共同使用剩余骰子中点数最小的一颗；每人都执行该骰子对应的花园行动和轮盘行动。\n· 事件：结算本轮指定的事件。工具棚事件执行工具棚效果；下雨事件使每个区域浇水一次；农贸市场事件按当前货物数量查阅奖励档位并领取奖励。\n调整：每消耗1份堆肥，可以将骰子点数增加或减少1点，点数可以在1与6之间循环。鸢尾花可以提供免费的点数调整。同一颗骰子对应的两项行动，必须使用同一个调整后的点数。\n轮盘行动:再种植或浇水一次、填工具棚、获得 1 份堆肥与 4 份货物、蜂箱或水果、农贸市场。\n要点：作物的圆圈（○）全部填满后，收获该作物。同时收获两个相邻南瓜时，触发两者之间的花朵。水果、蜂箱和工具棚分别提供相应的联动奖励。\n结束:8 轮后结算,平分则先比较花园分。\n单人：Farmer Edith与你交替选择骰子，双方各选择2颗。她会在你的计分纸上划掉格子，造成破坏。先行动的一方在第二次选择骰子时，必须选择剩余骰子中点数最小的一颗。\n天气(可选扩展):轮末按剩余最高骰移动天气。\n· 闪电：不能浇水。\n· 严寒：不能执行蜂箱行动。\n· 多云：获得多年生植物。\n· 炎热：收获水果时，可以额外获得 1 份货物。\n· 大风：种植时必须跨越到相邻区域。",
			weather: {
				foggy: "雾",
				lightning: "闪电",
				cold: "严寒",
				cloudy: "多云",
				hot: "炎热",
				windy: "大风"
			},
			optWeather: "天气扩展",
			weatherOff: "关闭",
			weatherOffHint: "标准规则",
			weatherOn: "开启",
			weatherOnHint: "轮末天气按剩余最高骰移动,影响行动",
			errOver: "本局已结束",
			errNotYourTurn: "现在轮不到你",
			errBadDie: "这颗骰子不能选",
			errBadPending: "这个行动现在不能结算",
			errBadCrop: "这株作物不能选",
			errBadTarget: "这个目标不可用",
			errNoCompost: "堆肥不够",
			errBadAdjust: "同一颗骰子的调整必须一致",
			errBlocked: "当前天气禁止这个行动",
			errUnresolved: "还有必须结算的行动",
			tabGarden: "花园",
			tabYard: "后院",
			tabBoard: "版图",
			roll: "掷骰",
			rollPrompt: "轮到你掷骰",
			rollWait: "等 {{name}} 掷骰",
			pickPrompt: "从版图选一颗骰子",
			pickWait: "等 {{name}} 选骰",
			windowPrompt: "结算你的行动",
			windowWait: "等 {{name}} 行动",
			lowestPrompt: "全民同用最小骰:{{n}} 点",
			eventShed: "事件·工具棚:各填 1 格",
			eventRain: "事件·下雨:全区已自动浇水",
			eventMarket: "事件·农贸市场:按货物查档",
			doneWait: "等其他玩家确认…",
			edithAct: "Edith 拿骰 {{n}} 行动中…",
			edithCropPrompt: "替 Edith 选要划掉的作物",
			roundChip: "第 {{n}} 轮",
			journal: "行动簿",
			pGrow: "花园 {{n}} 点",
			pGrowRondel: "轮盘·种/浇",
			pWaterAny: "任意区浇水",
			pPlantAny: "任意区种植",
			pGrowAny: "任意区种/浇",
			pShed: "工具棚 1 格",
			pApiaryOrFruit: "蜂箱或水果",
			pApiary: "蜂箱 1 格",
			pFruit: "水果 1 格",
			pPerennial: "多年生 1 格",
			pBonus: "奖励行动",
			pMarket: "农贸市场",
			done: "完成",
			skipAria: "放弃这条行动",
			plantMode: "种植",
			waterMode: "浇水",
			plantConfirm: "种下 {{n}} 株",
			waterConfirm: "浇水",
			adjustDown: "调低 1 点(消耗 1 堆肥)",
			adjustUp: "调高 1 点(消耗 1 堆肥)",
			adjustFreeHint: "鸢尾免费调 {{n}} 档",
			mulchSwap: "覆盖物:换成 1 次多年生",
			shovelSwap: "铲子:3 堆肥换奖励行动",
			bonusTitle: "奖励行动选一类",
			bonusPerennial: "多年生",
			bonusApiary: "蜂箱",
			bonusFruit: "水果",
			bonusShed: "工具棚",
			marketApply: "按 {{n}} 货物查档",
			pickOnSheet: "点计分纸上高亮的格子",
			pickZone: "点选一个区域浇水",
			flowerTulip: "郁金香",
			flowerHydrangea: "绣球",
			flowerIris: "鸢尾",
			flowerHyacinth: "风信子",
			flowerCrocus: "番红花",
			flowerDaffodil: "水仙",
			fruitApple: "苹果",
			fruitPeach: "桃",
			fruitBlackberry: "黑莓",
			fruitRaspberry: "覆盆子",
			apiaryMain: "主巢",
			apiaryWax: "蜂蜡",
			apiaryHoney: "蜂蜜",
			apiarySplit: "分巢",
			shedMasonJars: "玻璃罐",
			shedPieSafe: "馅饼柜",
			shedShovel: "铲子",
			shedFruitBowl: "水果碗",
			shedRainBarrel: "雨水桶",
			shedCasseroleDish: "砂锅",
			shedFancyLabels: "花哨标签",
			shedHiveTool: "起刮刀",
			shedPitchfork: "干草叉",
			shedStringTrimmer: "打草机",
			shedWheelbarrow: "独轮车",
			shedMulch: "覆盖物",
			shedTractor: "新拖拉机",
			shedCarvingKit: "雕刻刀",
			shedSeedSpreader: "播种机",
			zoneName: "{{n}} 号区",
			weatherChip: "天气",
			dieAria: "{{n}} 点骰",
			pawnAria: "Edith 棋子起始位",
			scoreGarden: "花园",
			scorePerennials: "多年生",
			scoreApiary: "蜂箱",
			scoreFruit: "水果",
			scoreShed: "工具棚",
			soloRating: "单人评级 {{n}} / 5"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Three Sisters",
			desc: "A roll-and-write farm: draft dice off the rondel, nudge values with compost",
			rules: "Goal: over 8 rounds, score your sheet across garden, perennials, apiary, fruit and toolshed — highest total wins.\nEach round has three phases:\n· Planning: the start player rolls 2 more dice than the player count and groups them by value.\n· Groups go on the rondel clockwise in ascending order from the Edith pawn; the pawn then moves past the highest group.\n· Gardening: in turn order, each player drafts 1 die: first take its garden action (plant up to 2 crops in the matching zone, or water that zone), then the rondel action of its space.\n· After all picks, everyone uses the lowest remaining die (both actions).\n· Event: Resolve the event for the current round. A Toolshed event activates its toolshed effect; Rain waters every zone once; a Farmer’s Market event grants the reward corresponding to your current goods total.\nAdjustments: each compost spent shifts a die up or down by 1 (wraps around); iris grants free shifts; both actions of one die share a single adjustment.\nRondel actions provide one of the following effects:\n· Plant or water once more.\n· Fill a toolshed item.\n· Gain 1 compost and 4 goods.\n· Perform an apiary or fruit action.\n· Visit the Farmer’s Market.\nKey points: a crop is harvested when its ○ is filled; harvesting two adjacent pumpkins triggers the flower between them; fruit, apiary and toolshed each chain further bonuses.\nEnd: after round 8, total the sheet; ties are broken on garden points first.\nSolo: Farmer Edith drafts dice alternately with you (2 each) and crosses things off your sheet; the first player's second pick must be the lowest remaining die.\nWeather (optional expansion): at round end the weather follows the highest remaining die.\n· Lightning prevents watering.\n· Cold prevents apiary actions.\n· Cloudy weather grants a free perennial.\n· Heat grants 1 extra good per fruit harvest.\n· Wind requires planting in a neighboring zone.",
			weather: {
				foggy: "Fog",
				lightning: "Lightning",
				cold: "Cold snap",
				cloudy: "Cloudy",
				hot: "Heat wave",
				windy: "Windy"
			},
			optWeather: "Weather expansion",
			weatherOff: "Off",
			weatherOffHint: "Standard rules",
			weatherOn: "On",
			weatherOnHint: "Weather follows the highest remaining die each round",
			errOver: "This game is over",
			errNotYourTurn: "Not your turn right now",
			errBadDie: "That die cannot be picked",
			errBadPending: "This action cannot be resolved now",
			errBadCrop: "That crop cannot be chosen",
			errBadTarget: "That target is unavailable",
			errNoCompost: "Not enough compost",
			errBadAdjust: "Both actions of a die must use the same adjustment",
			errBlocked: "The current weather forbids this action",
			errUnresolved: "You still have actions that must be resolved",
			tabGarden: "Garden",
			tabYard: "Yard",
			tabBoard: "Board",
			roll: "Roll",
			rollPrompt: "You roll the dice",
			rollWait: "Waiting for {{name}} to roll",
			pickPrompt: "Pick a die on the board",
			pickWait: "Waiting for {{name}} to pick a die",
			windowPrompt: "Resolve your actions",
			windowWait: "Waiting for {{name}}",
			lowestPrompt: "Everyone uses the lowest die: {{n}}",
			eventShed: "Event · Shed: fill 1 box each",
			eventRain: "Event · Rain: all zones watered",
			eventMarket: "Event · Farmer's Market: check your goods",
			doneWait: "Waiting for other players…",
			edithAct: "Edith took a {{n}} and is acting…",
			edithCropPrompt: "Pick the crop Edith crosses off",
			roundChip: "Round {{n}}",
			journal: "Journal",
			pGrow: "Garden {{n}}",
			pGrowRondel: "Rondel: plant/water",
			pWaterAny: "Water any zone",
			pPlantAny: "Plant in any zone",
			pGrowAny: "Plant/water any zone",
			pShed: "Shed: 1 box",
			pApiaryOrFruit: "Apiary or fruit",
			pApiary: "Apiary: 1 box",
			pFruit: "Fruit: 1 box",
			pPerennial: "Perennial: 1 box",
			pBonus: "Bonus action",
			pMarket: "Farmer's Market",
			done: "Done",
			skipAria: "Skip this action",
			plantMode: "Plant",
			waterMode: "Water",
			plantConfirm: "Plant {{n}}",
			waterConfirm: "Water",
			adjustDown: "Lower by 1 (spend 1 compost)",
			adjustUp: "Raise by 1 (spend 1 compost)",
			adjustFreeHint: "Iris covers {{n}} free shift(s)",
			mulchSwap: "Mulch: trade for 1 perennial",
			shovelSwap: "Shovel: 3 compost for a bonus action",
			bonusTitle: "Pick a bonus action",
			bonusPerennial: "Perennial",
			bonusApiary: "Apiary",
			bonusFruit: "Fruit",
			bonusShed: "Shed",
			marketApply: "Check tier at {{n}} goods",
			pickOnSheet: "Tap a highlighted cell on the sheet",
			pickZone: "Tap a zone to water",
			flowerTulip: "Tulip",
			flowerHydrangea: "Hydrangea",
			flowerIris: "Iris",
			flowerHyacinth: "Hyacinth",
			flowerCrocus: "Crocus",
			flowerDaffodil: "Daffodil",
			fruitApple: "Apples",
			fruitPeach: "Peaches",
			fruitBlackberry: "Blackberries",
			fruitRaspberry: "Raspberries",
			apiaryMain: "Main hive",
			apiaryWax: "Wax",
			apiaryHoney: "Honey",
			apiarySplit: "Split hive",
			shedMasonJars: "Mason Jars",
			shedPieSafe: "Pie Safe",
			shedShovel: "Shovel",
			shedFruitBowl: "Fruit Bowl",
			shedRainBarrel: "Rain Barrel",
			shedCasseroleDish: "Casserole Dish",
			shedFancyLabels: "Fancy Labels",
			shedHiveTool: "Hive Tool",
			shedPitchfork: "Pitchfork",
			shedStringTrimmer: "String Trimmer",
			shedWheelbarrow: "Wheelbarrow",
			shedMulch: "Mulch",
			shedTractor: "New Tractor",
			shedCarvingKit: "Carving Kit",
			shedSeedSpreader: "Seed Spreader",
			zoneName: "Zone {{n}}",
			weatherChip: "Weather",
			dieAria: "Die showing {{n}}",
			pawnAria: "Edith pawn start",
			scoreGarden: "Garden",
			scorePerennials: "Perennials",
			scoreApiary: "Apiary",
			scoreFruit: "Fruit",
			scoreShed: "Shed",
			soloRating: "Solo rating {{n}} / 5"
		}
	}
};
//#endregion
export { xn as default };
