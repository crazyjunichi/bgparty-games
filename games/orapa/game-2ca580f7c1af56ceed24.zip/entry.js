import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useId as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { useT as s } from "@bgparty/sdk/i18n";
import { Texture as c } from "@bgparty/sdk/texture";
import "@bgparty/sdk/icons";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { PhaseBanner as u } from "@bgparty/sdk/ui/phase-banner";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { Floater as h, PulseBox as g } from "@bgparty/sdk/fx/primitives";
import { AVATARS as _ } from "@bgparty/sdk/avatars";
import { Confetti as v } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as y, OptionSection as b } from "@bgparty/sdk/ui/game-options";
//#region src/games/orapa/pieces.ts
var x = [
	"bigWhite",
	"smallRed",
	"bigRed",
	"blue",
	"yellow",
	"saturn"
], S = {
	bigWhite: "W",
	smallRed: "R",
	bigRed: "R",
	blue: "B",
	yellow: "Y",
	saturn: "W",
	hole: "H"
};
function C(e, t) {
	switch (e) {
		case "bigWhite": return t % 2 == 0 ? {
			w: 4,
			h: 2
		} : {
			w: 2,
			h: 4
		};
		case "smallRed":
		case "hole": return {
			w: 1,
			h: 1
		};
		case "bigRed":
		case "blue": return {
			w: 2,
			h: 2
		};
		case "yellow": return {
			w: 3,
			h: 3
		};
		case "saturn": return t % 2 == 0 ? {
			w: 4,
			h: 2
		} : {
			w: 2,
			h: 4
		};
	}
}
function w(e) {
	return e.t === "bigWhite" ? {
		...e,
		r: (e.r % 4 + 4) % 4
	} : e.t === "saturn" ? {
		...e,
		r: e.r % 2
	} : {
		...e,
		r: 0
	};
}
function T(e, t) {
	switch (e) {
		case "bigWhite": return t === 0 ? [
			[0, 0],
			[8, 0],
			[8, 2],
			[6, 4],
			[2, 4],
			[0, 2]
		] : t === 1 ? [
			[4, 0],
			[4, 8],
			[2, 8],
			[0, 6],
			[0, 2],
			[2, 0]
		] : t === 2 ? [
			[2, 0],
			[6, 0],
			[8, 2],
			[8, 4],
			[0, 4],
			[0, 2]
		] : [
			[0, 0],
			[2, 0],
			[4, 2],
			[4, 6],
			[2, 8],
			[0, 8]
		];
		case "smallRed": return [
			[0, 0],
			[2, 0],
			[2, 2],
			[0, 2]
		];
		case "bigRed":
		case "blue": return [
			[2, 0],
			[4, 2],
			[2, 4],
			[0, 2]
		];
		case "yellow": return [
			[2, 0],
			[4, 0],
			[6, 2],
			[6, 4],
			[4, 6],
			[2, 6],
			[0, 4],
			[0, 2]
		];
		case "saturn": return t === 0 ? [
			[4, 0],
			[6, 2],
			[4, 4],
			[2, 2]
		] : [
			[2, 2],
			[4, 4],
			[2, 6],
			[0, 4]
		];
		case "hole": return [];
	}
}
function E(e) {
	let t = T(e.t, e.r), n = e.x * 2, r = e.y * 2, i = [];
	for (let e = 0; e < t.length; e += 1) {
		let a = t[e], o = t[(e + 1) % t.length];
		i.push([
			a[0] + n,
			a[1] + r,
			o[0] + n,
			o[1] + r
		]);
	}
	return i;
}
function D(e) {
	let t = e.x * 2, n = e.y * 2;
	return T(e.t, e.r).map(([e, r]) => [e + t, r + n]);
}
function O(e) {
	if (e.t !== "saturn") return [];
	let t = e.x * 2, n = e.y * 2;
	return e.r === 0 ? [[
		!0,
		n + 2,
		t + 0,
		t + 2
	], [
		!0,
		n + 2,
		t + 6,
		t + 8
	]] : [[
		!1,
		t + 2,
		n + 0,
		n + 2
	], [
		!1,
		t + 2,
		n + 6,
		n + 8
	]];
}
function k(e) {
	let { w: t, h: n } = C(e.t, e.r), r = [];
	for (let i = 0; i < n; i += 1) for (let n = 0; n < t; n += 1) r.push([e.x + n, e.y + i]);
	return r;
}
var A = [
	...Array.from({ length: 10 }, (e, t) => String(t + 1)),
	...Array.from({ length: 8 }, (e, t) => String(t + 11)),
	...Array.from({ length: 10 }, (e, t) => String.fromCharCode(73 + t)),
	...Array.from({ length: 8 }, (e, t) => String.fromCharCode(65 + t))
];
function j(e) {
	let t = e.charCodeAt(0);
	if (t >= 73) return {
		cx: t - 73,
		cy: 7,
		dx: 0,
		dy: -1
	};
	if (t >= 65) return {
		cx: 0,
		cy: t - 65,
		dx: 1,
		dy: 0
	};
	let n = Number(e);
	return n <= 10 ? {
		cx: n - 1,
		cy: 0,
		dx: 0,
		dy: 1
	} : {
		cx: 9,
		cy: n - 11,
		dx: -1,
		dy: 0
	};
}
function M(e, t, n, r) {
	return r === 1 ? String.fromCharCode(73 + e) : r === -1 ? String(e + 1) : n === 1 ? String(11 + t) : String.fromCharCode(65 + t);
}
function N(e, t) {
	return `${e + 1}${String.fromCharCode(65 + t)}`;
}
function ee(e, t, n) {
	for (let r of e) {
		let { w: e, h: i } = C(r.t, r.r);
		if (t >= r.x && t < r.x + e && n >= r.y && n < r.y + i) return S[r.t];
	}
	return null;
}
function P(e) {
	return [
		"R",
		"Y",
		"B",
		"W"
	].filter((t) => e.includes(t)).join("");
}
//#endregion
//#region src/games/orapa/laser.ts
function F(e, t, n, r, i) {
	let a = r === 0 ? 2 * t + 1 : r === 1 ? 2 * t : 2 * t + 2, o = i === 0 ? 2 * n + 1 : i === 1 ? 2 * n : 2 * n + 2, s = null, c = (e) => {
		e.t < 0 || e.t > 2 || (s === null || e.t < s.t) && (s = e);
	};
	for (let s of e) {
		let { w: e, h: l } = C(s.t, s.r);
		if (t < s.x || t >= s.x + e || n < s.y || n >= s.y + l) continue;
		let u = S[s.t];
		for (let [e, t, n, l] of E(s)) if (i !== 0 && n !== e) {
			let r = (a - e) / (n - e);
			if (r < 0 || r > 1) continue;
			c({
				t: (t + r * (l - t) - o) * i,
				edge: l === t ? "axis" : (n - e) * (l - t) > 0 ? "back" : "slash",
				color: u
			});
		} else if (r !== 0 && l !== t) {
			let i = (o - t) / (l - t);
			if (i < 0 || i > 1) continue;
			c({
				t: (e + i * (n - e) - a) * r,
				edge: n === e ? "axis" : (n - e) * (l - t) > 0 ? "back" : "slash",
				color: u
			});
		}
		for (let [e, t, n, l] of O(s)) if (e && i !== 0) {
			if (a < n || a > l) continue;
			c({
				t: (t - o) * i,
				edge: "axis",
				color: u
			});
		} else if (!e && r !== 0) {
			if (o < n || o > l) continue;
			c({
				t: (t - a) * r,
				edge: "axis",
				color: u
			});
		}
	}
	return s;
}
var I = 512;
function te(e, t) {
	let n = e.find((e) => e.t === "hole") ?? null, { cx: r, cy: i, dx: a, dy: o } = j(t), s = a === 0 ? 2 * r + 1 : a === 1 ? 2 * r : 2 * r + 2, c = o === 0 ? 2 * i + 1 : o === 1 ? 2 * i : 2 * i + 2, l = !1, u = /* @__PURE__ */ new Set(), d = /* @__PURE__ */ new Set(), f = [], p = (e, t) => {
		(e !== s || t !== c) && f.push({
			x1: s,
			y1: c,
			x2: e,
			y2: t,
			colors: [...u]
		}), s = e, c = t;
	};
	for (let t = 0; t < I; t += 1) {
		let t = `${r},${i},${a},${o},${+!!l}`;
		if (d.has(t)) return {
			answer: { kind: "trapped" },
			path: f
		};
		if (d.add(t), n && n.x === r && n.y === i) return {
			answer: { kind: "disappeared" },
			path: f
		};
		let m = F(e, r, i, a, o);
		if (m) {
			p(s + m.t * a, c + m.t * o), u.add(m.color), m.edge === "axis" ? (a = -a, o = -o) : m.edge === "slash" ? [a, o] = [-o, -a] : [a, o] = [o, a];
			let e = m.edge === "axis" ? m.t : 2 - m.t;
			p(s + e * a, c + e * o);
		} else if (n && !l) {
			let e = !1;
			for (let [t, s] of [[-o, a], [o, -a]]) if (n.x === r - a + t && n.y === i - o + s) {
				p(2 * r + 1, 2 * i + 1), a = t, o = s, l = !0, e = !0;
				break;
			}
			p(s + (e ? 1 : 2) * a, c + (e ? 1 : 2) * o);
		} else p(s + 2 * a, c + 2 * o);
		if (r += a, i += o, r < 0 || r >= 10 || i < 0 || i >= 8) return {
			answer: {
				kind: "exit",
				port: M(r - a, i - o, a, o),
				colors: [...u]
			},
			path: f
		};
	}
	return {
		answer: { kind: "trapped" },
		path: f
	};
}
function ne(e, t) {
	return te(e, t).answer;
}
function re(e, t) {
	return e.kind === t.kind ? e.kind !== "exit" || t.kind !== "exit" || e.port === t.port && P(e.colors) === P(t.colors) : !1;
}
function ie(e, t) {
	let n = e.find((e) => e.t === "hole") ?? null, { dx: r, dy: i } = j(t), { cx: a, cy: o } = j(t);
	for (let t = 0; t < 18; t += 1) {
		if (n && n.x === a && n.y === o) return n;
		let t = F(e, a, o, r, i);
		if (t) return e.find((e) => {
			let { w: n, h: r } = C(e.t, e.r);
			return a >= e.x && a < e.x + n && o >= e.y && o < e.y + r && S[e.t] === t.color;
		}) ?? null;
		if (a += r, o += i, a < 0 || a >= 10 || o < 0 || o >= 8) return null;
	}
	return null;
}
function ae(e, t) {
	let n = e.map(w), r = t ? [...x, "hole"] : x, i = n.map((e) => e.t).sort();
	if (n.length !== r.length || i.join() !== [...r].sort().join()) return "games.orapa.errPieces";
	for (let e of n) {
		let { w: t, h: n } = C(e.t, e.r);
		if (e.x < 0 || e.y < 0 || e.x + t > 10 || e.y + n > 8) return "games.orapa.errBounds";
		if (e.t === "bigWhite" && !(e.r === 0 && e.y === 0 || e.r === 2 && e.y + n === 8 || e.r === 3 && e.x === 0 || e.r === 1 && e.x + t === 10)) return "games.orapa.errFlush";
	}
	let a = /* @__PURE__ */ new Set();
	for (let e of n) for (let [t, n] of k(e)) {
		let e = `${t},${n}`;
		if (a.has(e)) return "games.orapa.errOverlap";
		a.add(e);
	}
	let o = /* @__PURE__ */ new Set();
	for (let e of A) {
		let t = ie(n, e);
		t && o.add(t);
	}
	return n.some((e) => !o.has(e)) ? "games.orapa.errHidden" : null;
}
function oe(e, t) {
	let n = (e) => e.map(w).map((e) => `${e.t}${e.x},${e.y},${e.r}`).sort().join("|");
	return n(e) === n(t);
}
function se(t, n, r) {
	let i = r ? [...x, "hole"] : x;
	for (let a = 0; a < 200; a += 1) {
		let a = [], o = !0;
		for (let r of i) {
			let i = !1;
			for (let o = 0; o < 40; o += 1) {
				let o = r === "bigWhite" ? e(t, n, 4) : r === "saturn" ? e(t, n, 2) : 0;
				n += 1;
				let { w: s, h: c } = C(r, o), l = e(t, n, 10 - s + 1);
				n += 1;
				let u = e(t, n, 8 - c + 1);
				n += 1;
				let d = {
					t: r,
					x: l,
					y: u,
					r: o
				};
				if (r === "bigWhite" && !(o === 0 && u === 0 || o === 2 && u + c === 8 || o === 3 && l === 0 || o === 1 && l + s === 10)) continue;
				let f = new Set(a.flatMap(k).map(([e, t]) => `${e},${t}`));
				if (!k(d).some(([e, t]) => f.has(`${e},${t}`))) {
					a.push(d), i = !0;
					break;
				}
			}
			if (!i) {
				o = !1;
				break;
			}
		}
		if (o && ae(a, r) === null) return {
			pieces: a,
			cursor: n
		};
	}
	let a = [
		{
			t: "bigWhite",
			x: 3,
			y: 0,
			r: 0
		},
		{
			t: "smallRed",
			x: 0,
			y: 7,
			r: 0
		},
		{
			t: "bigRed",
			x: 7,
			y: 2,
			r: 0
		},
		{
			t: "blue",
			x: 1,
			y: 3,
			r: 0
		},
		{
			t: "yellow",
			x: 3,
			y: 4,
			r: 0
		},
		{
			t: "saturn",
			x: 6,
			y: 6,
			r: 0
		}
	];
	return r && a.push({
		t: "hole",
		x: 4,
		y: 2,
		r: 0
	}), {
		pieces: a,
		cursor: n
	};
}
//#endregion
//#region src/games/orapa/meta.ts
var ce = {
	id: "orapa",
	tier: "released",
	mechanics: ["deduction"],
	interactionTags: [],
	nameKey: "games.orapa.name",
	descKey: "games.orapa.desc",
	rulesKey: "games.orapa.rules",
	icon: "🪐",
	iconImg: "games/orapa.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/orapa/en.pdf" },
	precacheAssets: [
		"bigWhite.webp",
		"smallRed.webp",
		"bigRed.webp",
		"blue.webp",
		"yellow.webp",
		"saturn.webp",
		"hole.webp"
	],
	minPlayers: 1,
	maxPlayers: 5,
	bestPlayers: [2],
	accent: "#94652e",
	releasedAt: "2026-09-12",
	search: {
		py: "ao la pa yu zhou",
		init: "alpyz"
	},
	hotseat: "off"
}, le = t.enum([
	"bigWhite",
	"smallRed",
	"bigRed",
	"blue",
	"yellow",
	"saturn",
	"hole"
]), L = t.object({
	t: le,
	x: t.int().min(0).max(9),
	y: t.int().min(0).max(7),
	r: t.int().min(0).max(3)
}), R = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("place"),
		pieces: t.array(L).min(6).max(7)
	}),
	t.object({
		type: t.literal("fire"),
		port: t.enum(A)
	}),
	t.object({
		type: t.literal("ask"),
		x: t.int().min(0).max(9),
		y: t.int().min(0).max(7)
	}),
	t.object({
		type: t.literal("submit"),
		pieces: t.array(L).min(6).max(7)
	})
]), z = t.object({
	mode: t.enum(["auto", "master"]).default("auto"),
	blackHole: t.boolean().default(!1)
}).default({
	mode: "auto",
	blackHole: !1
}), B = t.string(), V = t.enum([
	"R",
	"Y",
	"B",
	"W",
	"H"
]), ue = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("exit"),
		port: t.enum(A),
		colors: t.array(V)
	}),
	t.object({ kind: t.literal("disappeared") }),
	t.object({ kind: t.literal("trapped") })
]), de = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("fire"),
		by: B,
		port: t.enum(A),
		answer: ue
	}),
	t.object({
		kind: t.literal("ask"),
		by: B,
		x: t.int(),
		y: t.int(),
		color: V.nullable()
	}),
	t.object({
		kind: t.literal("submit"),
		by: B,
		ok: t.boolean()
	})
]), H = t.object({
	phase: t.enum([
		"place",
		"play",
		"done"
	]),
	nonce: t.int(),
	mode: t.enum(["auto", "master"]),
	blackHole: t.boolean(),
	setter: B.nullable(),
	explorers: t.array(B),
	activeRid: B.nullable(),
	targetOf: t.record(B, B),
	chancesLeft: t.record(B, t.int()),
	eliminated: t.array(B),
	placed: t.array(B),
	pendingLastChance: t.boolean(),
	pieceCount: t.int(),
	log: t.array(de),
	boards: t.record(B, t.array(L)).nullable()
}), U = t.object({
	pieces: t.array(L).nullable(),
	devAnswer: t.array(L).nullable().optional()
});
//#endregion
//#region src/games/orapa/rules.ts
function fe(e) {
	return e.mode === "master" && e.players.length === 2;
}
function W(t, n, r) {
	let i = t.blackHole, a = n.length < 2 ? "auto" : t.mode, o = 0, s = {
		players: n,
		nonce: 0,
		mode: a,
		blackHole: i,
		phase: "play",
		setter: null,
		boards: {},
		placed: [],
		explorers: n,
		targetOf: {},
		chancesLeft: {},
		eliminated: [],
		activeIdx: 0,
		startRid: "",
		pendingLastChance: !1,
		pendingWinner: null,
		winner: [],
		log: [],
		seed: r,
		rngCursor: o
	};
	if (a === "auto") {
		let e = se(r, o, i);
		o = e.cursor, s.boards = { auto: e.pieces };
		for (let e of n) s.targetOf[e] = "auto";
		s.chancesLeft = Object.fromEntries(n.map((e) => [e, 2]));
	} else if (n.length === 2) s.phase = "place", s.targetOf = {
		[n[0]]: n[1],
		[n[1]]: n[0]
	}, s.chancesLeft = Object.fromEntries(n.map((e) => [e, 1]));
	else {
		s.phase = "place", s.setter = n[0], s.explorers = n.slice(1);
		for (let e of s.explorers) s.targetOf[e] = n[0];
		s.chancesLeft = Object.fromEntries(s.explorers.map((e) => [e, 2]));
	}
	s.activeIdx = e(r, o, s.explorers.length), o += 1, s.startRid = s.explorers[s.activeIdx];
	let c = e(r, o, 4294967295);
	return o += 1, s.nonce = (c ^ c >>> 16) >>> 0, s.rngCursor = o, { state: s };
}
function G(e) {
	for (let t = 1; t <= e.explorers.length; t += 1) {
		let n = (e.activeIdx + t) % e.explorers.length;
		if (!e.eliminated.includes(e.explorers[n])) {
			e.activeIdx = n;
			return;
		}
	}
}
function K(e) {
	e.explorers.some((t) => !e.eliminated.includes(t)) || (e.winner = e.setter === null ? [] : [e.setter], e.phase = "done");
}
function pe(e, t, n) {
	if (t.type === "place") {
		if (e.phase !== "place" || !(e.setter === null ? e.players.includes(n.by) : n.by === e.setter) || e.placed.includes(n.by)) return { code: "games.orapa.errBadPhase" };
		let r = ae(t.pieces, e.blackHole);
		if (r) return { code: r };
		let i = structuredClone(e);
		i.boards[n.by] = t.pieces.map(w), i.placed.push(n.by);
		let a = [{
			kind: "placed",
			rid: n.by
		}];
		return (i.setter === null ? i.players.every((e) => i.placed.includes(e)) : i.placed.includes(i.setter)) && (i.phase = "play", a.push({ kind: "start" })), {
			state: i,
			fx: a
		};
	}
	if (e.phase !== "play") return { code: "games.orapa.errBadPhase" };
	let r = e.explorers[e.activeIdx];
	if (n.by !== r || e.eliminated.includes(n.by)) return { code: "games.orapa.errNotYourTurn" };
	let i = e.boards[e.targetOf[n.by]];
	if (t.type === "fire") {
		let r = structuredClone(e), a = ne(i, t.port);
		r.log.push({
			kind: "fire",
			by: n.by,
			port: t.port,
			answer: a
		});
		let o = [{
			kind: "laser",
			rid: n.by,
			data: {
				port: t.port,
				answer: a
			}
		}];
		return r.pendingLastChance ? (r.winner = [r.pendingWinner], r.phase = "done", {
			state: r,
			fx: o
		}) : (G(r), {
			state: r,
			fx: o
		});
	}
	if (t.type === "ask") {
		let r = structuredClone(e), a = ee(i, t.x, t.y);
		return r.log.push({
			kind: "ask",
			by: n.by,
			x: t.x,
			y: t.y,
			color: a
		}), r.pendingLastChance ? (r.winner = [r.pendingWinner], r.phase = "done", {
			state: r,
			fx: []
		}) : (G(r), {
			state: r,
			fx: []
		});
	}
	let a = oe(t.pieces, i), o = structuredClone(e);
	if (o.log.push({
		kind: "submit",
		by: n.by,
		ok: a
	}), fe(o)) {
		if (a) return o.pendingLastChance ? (o.winner = [o.pendingWinner, n.by], o.phase = "done", {
			state: o,
			fx: [{
				kind: "submit",
				rid: n.by,
				data: { ok: !0 }
			}]
		}) : n.by === o.startRid ? (o.pendingLastChance = !0, o.pendingWinner = n.by, G(o), {
			state: o,
			fx: [{
				kind: "submit",
				rid: n.by,
				data: { ok: !0 }
			}, { kind: "lastChance" }]
		}) : (o.winner = [n.by], o.phase = "done", {
			state: o,
			fx: [{
				kind: "submit",
				rid: n.by,
				data: { ok: !0 }
			}]
		});
		let e = o.players.find((e) => e !== n.by);
		return o.winner = [o.pendingLastChance ? o.pendingWinner : e], o.phase = "done", {
			state: o,
			fx: [{
				kind: "submit",
				rid: n.by,
				data: { ok: !1 }
			}]
		};
	}
	if (a) return o.winner = [n.by], o.phase = "done", {
		state: o,
		fx: [{
			kind: "submit",
			rid: n.by,
			data: { ok: !0 }
		}]
	};
	--o.chancesLeft[n.by];
	let s = [{
		kind: "submit",
		rid: n.by,
		data: { ok: !1 }
	}];
	return o.chancesLeft[n.by] <= 0 && (o.eliminated.push(n.by), s.push({
		kind: "out",
		rid: n.by
	})), K(o), o.phase !== "done" && G(o), {
		state: o,
		fx: s
	};
}
function q(e, t) {
	return {
		public: {
			phase: e.phase,
			nonce: e.nonce,
			mode: e.mode,
			blackHole: e.blackHole,
			setter: e.setter,
			explorers: e.explorers,
			activeRid: e.phase === "play" ? e.explorers[e.activeIdx] : null,
			targetOf: e.targetOf,
			chancesLeft: e.chancesLeft,
			eliminated: e.eliminated,
			placed: e.placed,
			pendingLastChance: e.pendingLastChance,
			pieceCount: e.blackHole ? 7 : 6,
			log: e.log,
			boards: e.phase === "done" ? e.boards : null
		},
		private: { pieces: e.boards[t] ?? null }
	};
}
function J(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.explorers].sort((t, n) => e.chancesLeft[n] - e.chancesLeft[t]), n;
	return e.winner.length > 0 && e.explorers.includes(e.winner[0]) ? (n = [e.winner[0], ...t.filter((t) => t !== e.winner[0])], e.setter !== null && n.push(e.setter)) : n = e.setter === null ? t : [e.setter, ...t], {
		phase: "done",
		winner: e.winner,
		ranking: n
	};
}
var me = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: ce,
	schemas: {
		action: R,
		publicView: H,
		privateView: U,
		config: z
	},
	setup: W,
	reduce: pe,
	viewFor: q,
	status: J
}, Y = {
	R: "#ef4444",
	Y: "#facc15",
	B: "#3b82f6",
	W: "#f8fafc",
	H: "#111827"
}, X = {
	"": "#f8fafc",
	R: "#ef4444",
	Y: "#facc15",
	B: "#3b82f6",
	W: "#f8fafc",
	RY: "#fb923c",
	RB: "#a855f7",
	YB: "#22c55e",
	RW: "#f9a8d4",
	YW: "#fef08a",
	BW: "#7dd3fc",
	RYW: "#fdba74",
	RBW: "#d8b4fe",
	YBW: "#86efac",
	RYB: "#1f2937",
	RYBW: "#9ca3af"
}, he = "#101a39", ge = {
	ok: "#34d399",
	bad: "#fb7185",
	unknown: "#fbbf24"
}, _e = {
	ok: "✓",
	bad: "✗",
	unknown: "?"
};
function Z(e) {
	let { cx: t, cy: n, dx: r, dy: i } = j(e);
	return [2 * t + 1 - r * 2.2, 2 * n + 1 - i * 2.2];
}
function ve({ pieces: e, ghost: t, fires: n, asks: r, selected: i, faded: a, preview: o, dropRect: s, paths: c, previewAnswer: l, svgRef: u, onPort: d, onCell: f, onShapeDown: h, armedPort: g, portLabel: _ }) {
	let v = A, y = Array.from({ length: 9 }, (e, t) => 2 * (t + 1)), b = Array.from({ length: 7 }, (e, t) => 2 * (t + 1));
	return /* @__PURE__ */ m("svg", {
		ref: u,
		viewBox: "-4.3 -4.3 28.6 24.6",
		className: "orapa-board-svg h-full w-full",
		role: "img",
		children: [
			/* @__PURE__ */ p("defs", { children: /* @__PURE__ */ m("pattern", {
				id: "orapa-stars",
				width: "5.3",
				height: "4.7",
				patternUnits: "userSpaceOnUse",
				children: [/* @__PURE__ */ p("circle", {
					cx: "1.1",
					cy: "0.8",
					r: "0.06",
					fill: "#dbe7fa",
					opacity: ".42"
				}), /* @__PURE__ */ p("circle", {
					cx: "4.2",
					cy: "3.4",
					r: "0.04",
					fill: "#dbe7fa",
					opacity: ".3"
				})]
			}) }),
			/* @__PURE__ */ p("rect", {
				x: -4.2,
				y: -4.2,
				width: 28.4,
				height: 24.4,
				rx: 1,
				fill: "#132147",
				stroke: "#6d7fa9",
				strokeWidth: .13
			}),
			/* @__PURE__ */ p("rect", {
				x: -.35,
				y: -.35,
				width: 20.7,
				height: 16.7,
				rx: .15,
				fill: he,
				stroke: "#9cafcf",
				strokeWidth: .18
			}),
			/* @__PURE__ */ p("rect", {
				x: -.35,
				y: -.35,
				width: 20.7,
				height: 16.7,
				rx: .15,
				fill: "url(#orapa-stars)"
			}),
			/* @__PURE__ */ p("ellipse", {
				cx: 10,
				cy: 8,
				rx: 8.6,
				ry: 5.7,
				transform: "rotate(-19 10 8)",
				fill: "none",
				stroke: "#8ea9d2",
				strokeWidth: .07,
				opacity: .28
			}),
			/* @__PURE__ */ p("ellipse", {
				cx: 10,
				cy: 8,
				rx: 5.9,
				ry: 7.8,
				transform: "rotate(23 10 8)",
				fill: "none",
				stroke: "#8ea9d2",
				strokeWidth: .06,
				opacity: .22
			}),
			/* @__PURE__ */ p("path", {
				d: "M1.8 6.8 3.2 5.2 4.6 6.3 5.5 4.5 M15.3 11.6 16.8 10.2 18 11.5 19 9.5",
				fill: "none",
				stroke: "#a2bbdc",
				strokeWidth: .06,
				opacity: .34
			}),
			y.map((e) => /* @__PURE__ */ p("line", {
				x1: e,
				y1: 0,
				x2: e,
				y2: 16,
				stroke: "#748ab8",
				strokeWidth: .07,
				opacity: .65
			}, `v${e}`)),
			b.map((e) => /* @__PURE__ */ p("line", {
				x1: 0,
				y1: e,
				x2: 20,
				y2: e,
				stroke: "#748ab8",
				strokeWidth: .07,
				opacity: .65
			}, `h${e}`)),
			f && Array.from({ length: 80 }, (e, t) => {
				let n = t % 10, r = Math.floor(t / 10);
				return /* @__PURE__ */ p("rect", {
					x: 2 * n,
					y: 2 * r,
					width: 2,
					height: 2,
					fill: "transparent",
					onClick: () => f(n, r),
					className: "cursor-pointer"
				}, `c${n},${r}`);
			}),
			(r ?? []).map((e, t) => /* @__PURE__ */ m("g", {
				pointerEvents: "none",
				children: [
					/* @__PURE__ */ p("rect", {
						x: 2 * e.x + .45,
						y: 2 * e.y + .45,
						width: 1.1,
						height: 1.1,
						rx: .12,
						fill: "#234968",
						fillOpacity: .55,
						stroke: "#9be6e2",
						strokeWidth: .1,
						strokeDasharray: "0.15 0.1"
					}),
					e.color ? /* @__PURE__ */ p("circle", {
						cx: 2 * e.x + 1,
						cy: 2 * e.y + 1,
						r: .3,
						fill: Y[e.color]
					}) : /* @__PURE__ */ p("path", {
						d: `M${2 * e.x + .75} ${2 * e.y + 1.25}l0.5 -0.5`,
						stroke: "#a8e9e6",
						strokeWidth: .12
					}),
					e.verified && /* @__PURE__ */ p(ye, {
						x: 2 * e.x + 1.7,
						y: 2 * e.y + .25,
						verdict: e.verified
					})
				]
			}, `a${t}`)),
			s && /* @__PURE__ */ p("rect", {
				x: 2 * s.x,
				y: 2 * s.y,
				width: 2 * s.w,
				height: 2 * s.h,
				fill: "#a5b4fc",
				opacity: .25,
				rx: .4
			}),
			(e ?? []).map((e, n) => /* @__PURE__ */ p("g", {
				opacity: a === n ? .3 : 1,
				children: /* @__PURE__ */ p(Q, {
					piece: e,
					selected: !t && i === n,
					onDown: !t && h ? (e) => h(n, e) : void 0
				})
			}, `p${n}`)),
			(t ?? []).map((e, t) => /* @__PURE__ */ p("g", {
				opacity: a === t ? .2 : 1,
				children: /* @__PURE__ */ p(Q, {
					piece: e,
					dashed: !0,
					selected: i === t,
					onDown: h ? (e) => h(t, e) : void 0
				})
			}, `g${t}`)),
			o && /* @__PURE__ */ p("g", {
				opacity: .7,
				children: /* @__PURE__ */ p(Q, {
					piece: o,
					dashed: !0
				})
			}),
			(c ?? []).map((e, t) => /* @__PURE__ */ p("line", {
				x1: e.x1,
				y1: e.y1,
				x2: e.x2,
				y2: e.y2,
				stroke: X[P(e.colors)],
				strokeWidth: .25,
				strokeLinecap: "round",
				strokeDasharray: "0.42 0.22",
				opacity: .95,
				pointerEvents: "none"
			}, `l${t}`)),
			l?.kind === "exit" && (() => {
				let [e, t] = Z(l.port);
				return /* @__PURE__ */ p("circle", {
					cx: e,
					cy: t,
					r: .97,
					fill: "none",
					stroke: "#f3cf78",
					strokeWidth: .18,
					strokeDasharray: "0.2 0.16",
					pointerEvents: "none"
				});
			})(),
			(n ?? []).map((e, t) => {
				let [n, r] = Z(e.port), i = (t) => {
					if (!e.verified) return null;
					let { dx: n, dy: r } = j(t), [i, a] = Z(t);
					return /* @__PURE__ */ p(ye, {
						x: i - n * 1.15,
						y: a - r * 1.15,
						verdict: e.verified
					});
				};
				if (e.answer.kind === "disappeared") return /* @__PURE__ */ m("g", { children: [/* @__PURE__ */ p("text", {
					x: n,
					y: r + .55,
					textAnchor: "middle",
					fontSize: 1.5,
					fill: "#f8fafc",
					children: "✕"
				}), i(e.port)] }, `f${t}`);
				if (e.answer.kind === "trapped") return /* @__PURE__ */ m("g", { children: [/* @__PURE__ */ p("text", {
					x: n,
					y: r + .55,
					textAnchor: "middle",
					fontSize: 1.4,
					fill: "#f8fafc",
					children: "↻"
				}), i(e.port)] }, `f${t}`);
				let a = X[P(e.answer.colors)], [o, s] = Z(e.answer.port);
				return /* @__PURE__ */ m("g", { children: [
					/* @__PURE__ */ p("circle", {
						cx: n,
						cy: r,
						r: .68,
						fill: "#22796e",
						stroke: "#aff5df",
						strokeWidth: .16
					}),
					/* @__PURE__ */ p("circle", {
						cx: o,
						cy: s,
						r: .72,
						fill: a,
						stroke: "#c2d6f4",
						strokeWidth: .18
					}),
					i(e.port),
					i(e.answer.port)
				] }, `f${t}`);
			}),
			v.map((e) => {
				let [t, n] = Z(e), r = e === g;
				return /* @__PURE__ */ m("g", { children: [
					r && /* @__PURE__ */ p("circle", {
						cx: t,
						cy: n,
						r: 1.08,
						fill: "#f2bd53",
						stroke: "#ffedb5",
						strokeWidth: .15
					}),
					/* @__PURE__ */ p("text", {
						x: t,
						y: n + .45,
						textAnchor: "middle",
						fontSize: 1.2,
						fontWeight: 800,
						fill: r ? "#17254b" : "#dce6f8",
						pointerEvents: "none",
						children: e
					}),
					d && /* @__PURE__ */ p("rect", {
						x: t - 1.7,
						y: n - 1.7,
						width: 3.4,
						height: 3.4,
						fill: "transparent",
						className: "cursor-pointer",
						role: "button",
						"aria-label": _ ? _(e) : e,
						onClick: () => d(e)
					})
				] }, e);
			})
		]
	});
}
function ye({ x: e, y: t, verdict: n }) {
	return /* @__PURE__ */ m("g", {
		pointerEvents: "none",
		children: [/* @__PURE__ */ p("circle", {
			cx: e,
			cy: t,
			r: .51,
			fill: ge[n],
			stroke: "#132147",
			strokeWidth: .12
		}), /* @__PURE__ */ p("text", {
			x: e,
			y: t + .24,
			textAnchor: "middle",
			fontSize: .78,
			fontWeight: 900,
			fill: "#17254b",
			children: _e[n]
		})]
	});
}
function Q({ piece: e, selected: t, dashed: n, onDown: i }) {
	let a = Y[S[e.t]], o = r().replace(/:/g, ""), { w: s, h: c } = C(e.t, e.r), l = 2 * e.x, u = 2 * e.y, d = `./games/orapa/${e.t}.webp`;
	if (e.t === "hole") return /* @__PURE__ */ m("g", {
		onPointerDown: i,
		className: i ? "cursor-grab touch-none" : void 0,
		children: [
			/* @__PURE__ */ p("defs", { children: /* @__PURE__ */ p("clipPath", {
				id: o,
				children: /* @__PURE__ */ p("circle", {
					cx: l + 1,
					cy: u + 1,
					r: .78
				})
			}) }),
			/* @__PURE__ */ p("circle", {
				cx: l + 1,
				cy: u + 1,
				r: 1.05,
				fill: "transparent"
			}),
			/* @__PURE__ */ p("circle", {
				cx: l + 1,
				cy: u + 1,
				r: .78,
				fill: a
			}),
			/* @__PURE__ */ p("image", {
				href: d,
				x: l + .22,
				y: u + .22,
				width: 1.56,
				height: 1.56,
				clipPath: `url(#${o})`,
				opacity: n ? .55 : 1
			}),
			/* @__PURE__ */ p("circle", {
				cx: l + 1,
				cy: u + 1,
				r: .78,
				fill: "none",
				stroke: n ? "#7ee4d8" : t ? "#f2bd53" : "#7b9bae",
				strokeWidth: t ? .3 : .18,
				strokeDasharray: n ? "0.3 0.2" : void 0
			})
		]
	});
	let f = D(e).map(([e, t]) => `${e},${t}`).join(" ");
	return /* @__PURE__ */ m("g", {
		onPointerDown: i,
		className: i ? "cursor-grab touch-none" : void 0,
		children: [
			/* @__PURE__ */ p("defs", { children: /* @__PURE__ */ p("clipPath", {
				id: o,
				children: /* @__PURE__ */ p("polygon", { points: f })
			}) }),
			/* @__PURE__ */ p("polygon", {
				points: f,
				fill: a
			}),
			/* @__PURE__ */ p("image", {
				href: d,
				x: l,
				y: u,
				width: 2 * s,
				height: 2 * c,
				preserveAspectRatio: "xMidYMid slice",
				clipPath: `url(#${o})`,
				opacity: n ? .55 : 1
			}),
			/* @__PURE__ */ p("polygon", {
				points: f,
				fill: "none",
				stroke: n ? "#7ee4d8" : t ? "#f2bd53" : "#17254b",
				strokeWidth: t ? .34 : .22,
				strokeLinejoin: "round",
				strokeDasharray: n ? "0.4 0.3" : void 0
			}),
			O(e).map(([e, t, n, r], i) => e ? /* @__PURE__ */ m("g", { children: [/* @__PURE__ */ p("line", {
				x1: n,
				y1: t,
				x2: r,
				y2: t,
				stroke: "#0f0c29",
				strokeWidth: .55
			}), /* @__PURE__ */ p("line", {
				x1: n,
				y1: t,
				x2: r,
				y2: t,
				stroke: a,
				strokeWidth: .28
			})] }, i) : /* @__PURE__ */ m("g", { children: [/* @__PURE__ */ p("line", {
				x1: t,
				y1: n,
				x2: t,
				y2: r,
				stroke: "#0f0c29",
				strokeWidth: .55
			}), /* @__PURE__ */ p("line", {
				x1: t,
				y1: n,
				x2: t,
				y2: r,
				stroke: a,
				strokeWidth: .28
			})] }, i))
		]
	});
}
function be({ t: e, className: t }) {
	let { w: n, h: r } = C(e, 0), i = {
		t: e,
		x: 0,
		y: 0,
		r: 0
	};
	return /* @__PURE__ */ p("svg", {
		viewBox: `-0.5 -0.5 ${2 * n + 1} ${2 * r + 1}`,
		className: t,
		"aria-hidden": !0,
		children: /* @__PURE__ */ p(Q, { piece: i })
	});
}
//#endregion
//#region src/games/orapa/guide.tsx
var xe = {
	"": "games.orapa.colorNone",
	R: "games.orapa.colorR",
	Y: "games.orapa.colorY",
	B: "games.orapa.colorB",
	W: "games.orapa.colorW",
	RY: "games.orapa.colorRY",
	RB: "games.orapa.colorRB",
	YB: "games.orapa.colorYB",
	RW: "games.orapa.colorRW",
	YW: "games.orapa.colorYW",
	BW: "games.orapa.colorBW",
	RYW: "games.orapa.colorRYW",
	RBW: "games.orapa.colorRBW",
	YBW: "games.orapa.colorYBW",
	RYB: "games.orapa.colorRYB",
	RYBW: "games.orapa.colorRYBW"
}, Se = {
	bigWhite: "games.orapa.pieceBigWhite",
	smallRed: "games.orapa.pieceSmallRed",
	bigRed: "games.orapa.pieceBigRed",
	blue: "games.orapa.pieceBlue",
	yellow: "games.orapa.pieceYellow",
	saturn: "games.orapa.pieceSaturn",
	hole: "games.orapa.pieceHole"
}, Ce = {
	bigWhite: "games.orapa.guideBigWhite",
	smallRed: "games.orapa.guideSmallRed",
	bigRed: "games.orapa.guideBigRed",
	blue: "games.orapa.guideBlue",
	yellow: "games.orapa.guideYellow",
	saturn: "games.orapa.guideSaturn",
	hole: "games.orapa.guideHole"
}, $ = [
	"bigWhite",
	"smallRed",
	"bigRed",
	"blue",
	"yellow",
	"saturn",
	"hole"
], we = [
	"RY",
	"RB",
	"YB",
	"RW",
	"YW",
	"BW",
	"RYW",
	"RBW",
	"YBW",
	"RYB",
	"RYBW"
], Te = {
	smallRed: {
		viewBox: "-2.5 -2 7 6",
		rays: ["-2,0.6 0,0.6", "0,1.5 -2,1.5"]
	},
	bigRed: {
		viewBox: "-2.5 -2.5 9 9",
		rays: ["-2,1 1,1 1,-2"]
	},
	blue: {
		viewBox: "-2.5 -2.5 9 9",
		rays: ["-2,1 1,1 1,-2"]
	},
	yellow: {
		viewBox: "-2.5 -2.5 11 11",
		rays: [
			"-2,2.6 0,2.6",
			"0,3.5 -2,3.5",
			"-2,1 1,1 1,-2"
		]
	},
	bigWhite: {
		viewBox: "-2.5 -2.5 13 9",
		rays: [
			"3.6,-2 3.6,0",
			"4.4,0 4.4,-2",
			"7,6 7,3 10,3"
		]
	},
	saturn: {
		viewBox: "-2.5 -2.5 13 9",
		rays: [
			"0.7,-2 0.7,2",
			"1.4,2 1.4,-2",
			"-2,1 2.5,1",
			"-2,3 3,3 3,6"
		]
	},
	hole: {
		viewBox: "-2.5 -2.5 8 9",
		rays: ["-2,1 0.7,1", "-2,3 3,3 3,-2"],
		gone: [1.3, 1]
	}
};
function Ee() {
	let e = s();
	return /* @__PURE__ */ m("div", {
		className: "flex w-full flex-col gap-3",
		children: [/* @__PURE__ */ p("ul", {
			className: "flex w-full flex-col gap-2",
			children: $.map((t) => /* @__PURE__ */ m("li", {
				className: "frame flex items-center gap-2 p-1.5",
				children: [/* @__PURE__ */ p(De, { t }), /* @__PURE__ */ m("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ p("p", {
						className: "text-xs font-extrabold",
						children: e(Se[t])
					}), /* @__PURE__ */ p("p", {
						className: "text-[11px] leading-4 font-bold opacity-70",
						children: e(Ce[t])
					})]
				})]
			}, t))
		}), /* @__PURE__ */ m("div", {
			className: "w-full",
			children: [/* @__PURE__ */ p("p", {
				className: "section-label",
				children: e("games.orapa.guideColors")
			}), /* @__PURE__ */ p("ul", {
				className: "grid grid-cols-2 gap-x-1 gap-y-1.5",
				children: we.map((t) => /* @__PURE__ */ m("li", {
					className: "flex items-center gap-1 text-[11px] leading-4 font-bold",
					children: [
						t.split("").map((e, t) => /* @__PURE__ */ m("span", {
							className: "flex items-center gap-1",
							children: [t > 0 && /* @__PURE__ */ p("span", {
								"aria-hidden": !0,
								className: "opacity-50",
								children: "+"
							}), /* @__PURE__ */ p("span", {
								"aria-hidden": !0,
								className: "size-3 flex-none rounded-full border border-ink",
								style: { background: X[e] }
							})]
						}, e)),
						/* @__PURE__ */ p("span", {
							"aria-hidden": !0,
							className: "opacity-50",
							children: "="
						}),
						/* @__PURE__ */ p("span", {
							"aria-hidden": !0,
							className: "size-3 flex-none rounded-full border border-ink",
							style: { background: X[t] }
						}),
						e(xe[t])
					]
				}, t))
			})]
		})]
	});
}
function De({ t: e }) {
	let t = r(), n = Te[e], i = D({
		t: e,
		x: 0,
		y: 0,
		r: 0
	}).map(([e, t]) => `${e},${t}`).join(" ");
	return /* @__PURE__ */ m("svg", {
		viewBox: n.viewBox,
		className: "h-16 w-20 flex-none",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ p("defs", { children: /* @__PURE__ */ p("marker", {
				id: t,
				viewBox: "0 0 10 10",
				refX: "8",
				refY: "5",
				markerWidth: "4.5",
				markerHeight: "4.5",
				orient: "auto-start-reverse",
				children: /* @__PURE__ */ p("path", {
					d: "M0,0L10,5L0,10z",
					fill: "#f8fafc"
				})
			}) }),
			/* @__PURE__ */ p("rect", {
				x: -2.5,
				y: -2.5,
				width: 100,
				height: 100,
				fill: "#1e1b4b"
			}),
			e === "hole" ? /* @__PURE__ */ p("circle", {
				cx: 1,
				cy: 1,
				r: .75,
				fill: "#111827",
				stroke: "#64748b",
				strokeWidth: .2
			}) : /* @__PURE__ */ p("polygon", {
				points: i,
				fill: Y[S[e]],
				stroke: "#0f0c29",
				strokeWidth: .22,
				strokeLinejoin: "round"
			}),
			O({
				t: e,
				x: 0,
				y: 0,
				r: 0
			}).map(([e, t, n, r], i) => e ? /* @__PURE__ */ p("line", {
				x1: n,
				y1: t,
				x2: r,
				y2: t,
				stroke: "#c7d2fe",
				strokeWidth: .3
			}, i) : /* @__PURE__ */ p("line", {
				x1: t,
				y1: n,
				x2: t,
				y2: r,
				stroke: "#c7d2fe",
				strokeWidth: .3
			}, i)),
			n.rays.map((e, n) => /* @__PURE__ */ p("polyline", {
				points: e,
				fill: "none",
				stroke: "#f8fafc",
				strokeWidth: .35,
				markerEnd: `url(#${t})`
			}, n)),
			n.gone && /* @__PURE__ */ p("text", {
				x: n.gone[0],
				y: n.gone[1] + .5,
				textAnchor: "middle",
				fontSize: 1.4,
				fill: "#f8fafc",
				children: "✕"
			})
		]
	});
}
//#endregion
//#region src/games/orapa/editor.tsx
var Oe = 48, ke = 6;
function Ae({ pieces: e, required: t, ghost: n, onChange: r, fires: o, asks: c, answer: l, paths: u, previewAnswer: d, onPort: f, onCell: h, armedPort: g, portLabel: _ }) {
	let v = s(), y = i(null), [b, x] = a(null), [S, w] = a(null), T = i(0), E = (e, t) => {
		let n = y.current?.getScreenCTM();
		if (!n) return null;
		let r = new DOMPoint(e, t).matrixTransform(n.inverse());
		return {
			x: r.x,
			y: r.y
		};
	}, D = (e, t, n) => {
		let r = E(t, n - (e.kind === "new" ? Oe : 0));
		if (!r) return null;
		let { w: i, h: a } = C(e.t, e.orig?.r ?? 0);
		return r.x < 0 || r.y < 0 || r.x > 20 || r.y > 16 ? null : {
			x: Math.min(Math.max(0, Math.round((r.x - e.grabDX) / 2)), 10 - i),
			y: Math.min(Math.max(0, Math.round((r.y - e.grabDY) / 2)), 8 - a)
		};
	}, O = (t, n, i, a) => {
		a.preventDefault(), a.currentTarget.setPointerCapture(a.pointerId);
		let o = t === "move" ? e[i] : null, s = E(a.clientX, a.clientY - (t === "new" ? Oe : 0)), { w: c, h: l } = C(n, o?.r ?? 0), u = t === "new" || !o || !s ? c : s.x - 2 * o.x, d = t === "new" || !o || !s ? l : s.y - 2 * o.y, f = {
			pointerId: a.pointerId,
			kind: t,
			t: n,
			index: i,
			orig: o,
			startX: a.clientX,
			startY: a.clientY,
			grabDX: u,
			grabDY: d,
			moved: !1,
			cell: null
		};
		f.cell = D(f, a.clientX, a.clientY), x({ ...f });
		let p = (e) => {
			e.pointerId === f.pointerId && (!f.moved && Math.hypot(e.clientX - f.startX, e.clientY - f.startY) <= ke || (f.moved = !0, f.cell = D(f, e.clientX, e.clientY), x({ ...f })));
		}, m = (t) => {
			if (t.pointerId !== f.pointerId) return;
			window.removeEventListener("pointermove", p), window.removeEventListener("pointerup", m), window.removeEventListener("pointercancel", g), x(null);
			let n = f.cell;
			if (!f.moved) {
				if (f.kind === "move") {
					if (h) {
						let e = E(t.clientX, t.clientY);
						if (e) {
							let t = Math.floor(e.x / 2), n = Math.floor(e.y / 2);
							t >= 0 && t < 10 && n >= 0 && n < 8 && h(t, n);
						}
						w(null);
					} else w((e) => e === f.index ? null : f.index);
				} else {
					let t = e.findIndex((e) => e.t === f.t);
					t >= 0 && w(t);
				}
			} else if (n) {
				if (T.current = performance.now() + 350, f.kind === "new") {
					let t = e.filter((e) => e.t !== f.t);
					t.push({
						t: f.t,
						x: n.x,
						y: n.y,
						r: 0
					}), r(t), w(t.length - 1);
				} else if (f.orig) {
					let t = f.orig;
					r(e.map((e, r) => r === f.index ? {
						...t,
						x: n.x,
						y: n.y
					} : e)), w(f.index);
				}
			}
		}, g = (e) => {
			e.pointerId === f.pointerId && (window.removeEventListener("pointermove", p), window.removeEventListener("pointerup", m), window.removeEventListener("pointercancel", g), x(null));
		};
		window.addEventListener("pointermove", p), window.addEventListener("pointerup", m), window.addEventListener("pointercancel", g);
	}, k = (e) => e ? (...t) => {
		performance.now() < T.current || (w(null), e(...t));
	} : void 0, A = S === null ? null : e[S], j = A && (A.t === "bigWhite" || A.t === "saturn"), M = () => {
		S !== null && A && r(e.map((e, t) => t === S ? {
			...e,
			r: e.t === "bigWhite" ? (e.r + 1) % 4 : (e.r + 1) % 2
		} : e));
	}, N = () => {
		S !== null && (r(e.filter((e, t) => t !== S)), w(null));
	}, ee = new Set(e.map((e) => e.t)), P = (e) => {
		let t = ee.has(e);
		return /* @__PURE__ */ p("li", { children: /* @__PURE__ */ m("button", {
			type: "button",
			"aria-label": v(Se[e]),
			onPointerDown: (t) => O("new", e, -1, t),
			className: `orapa-tray-piece relative grid min-h-11 min-w-11 touch-none place-items-center ${t ? "orapa-tray-piece-placed" : ""}`,
			children: [/* @__PURE__ */ p(be, {
				t: e,
				className: "h-8 w-auto"
			}), t && /* @__PURE__ */ p("span", {
				"aria-hidden": !0,
				className: "absolute -top-1 -right-1 grid size-4 place-items-center rounded-full border border-ink bg-emerald-400 text-[10px] leading-none font-black text-ink",
				children: "✓"
			})]
		}) }, e);
	}, F = b ? C(b.t, b.orig?.r ?? 0) : null;
	return /* @__PURE__ */ m("div", {
		className: "orapa-editor flex h-full min-h-0 w-full flex-col",
		children: [
			/* @__PURE__ */ p("div", {
				className: "orapa-board-window flex min-h-0 flex-1 touch-none items-center justify-center",
				children: /* @__PURE__ */ p(ve, {
					svgRef: y,
					pieces: n ? l : e,
					ghost: n ? e : void 0,
					selected: S,
					faded: b?.kind === "move" ? b.index : null,
					preview: b?.cell ? {
						t: b.t,
						x: b.cell.x,
						y: b.cell.y,
						r: b.orig?.r ?? 0
					} : null,
					dropRect: b?.cell && F ? {
						...b.cell,
						w: F.w,
						h: F.h
					} : null,
					fires: o,
					asks: c,
					paths: u,
					previewAnswer: d,
					onShapeDown: (t, n) => O("move", e[t].t, t, n),
					onPort: k(f),
					onCell: k(h),
					armedPort: g,
					portLabel: _
				})
			}),
			/* @__PURE__ */ m("div", {
				className: "orapa-tray-wrap relative flex-none",
				children: [
					/* @__PURE__ */ m("div", {
						className: "orapa-tray-heading",
						children: [/* @__PURE__ */ p("span", { children: v("games.orapa.notesTitle") }), /* @__PURE__ */ p("span", { children: v("games.orapa.notesCount", {
							placed: e.length,
							total: t.length
						}) })]
					}),
					/* @__PURE__ */ p("ul", {
						className: "orapa-tray-list",
						children: t.map(P)
					}),
					A && /* @__PURE__ */ m("div", {
						className: "orapa-piece-tools",
						children: [
							/* @__PURE__ */ p("span", {
								className: "orapa-piece-tools-name",
								children: v(Se[A.t])
							}),
							/* @__PURE__ */ p("button", {
								type: "button",
								onClick: M,
								disabled: !j,
								className: "orapa-tool-button disabled:opacity-40",
								children: v("games.orapa.rotate")
							}),
							/* @__PURE__ */ p("button", {
								type: "button",
								onClick: N,
								className: "orapa-tool-button",
								children: v("games.orapa.remove")
							})
						]
					})
				]
			}),
			b?.kind === "new" && b.moved && /* @__PURE__ */ p(je, { t: b.t })
		]
	});
}
function je({ t: e }) {
	let [t, r] = a(null);
	return n(() => {
		let e = (e) => r({
			x: e.clientX,
			y: e.clientY - Oe
		});
		return window.addEventListener("pointermove", e), () => window.removeEventListener("pointermove", e);
	}, []), t ? /* @__PURE__ */ p("div", {
		className: "pointer-events-none fixed z-50 -translate-x-1/2 -translate-y-1/2",
		style: {
			left: t.x,
			top: t.y
		},
		children: /* @__PURE__ */ p(be, {
			t: e,
			className: "h-10 w-auto opacity-80 drop-shadow-lg"
		})
	}) : null;
}
//#endregion
//#region src/games/orapa/view-player.tsx
function Me(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ p(Fe, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var Ne = /* @__PURE__ */ new Map();
function Pe(e) {
	let t = Ne.get(e);
	return t || (t = te([], e).answer, Ne.set(e, t)), t;
}
function Fe({ pub: e, priv: t, members: r, myRid: h, send: g }) {
	let _ = s(), { ref: v } = o("board"), y = (e) => r.find((t) => t.rid === e)?.name ?? e, b = e.phase === "play" && e.activeRid === h, S = e.explorers.includes(h), C = e.phase === "place" && (e.setter === null || e.setter === h), [w, T] = a("fire"), [E, D] = a([]), [O, k] = a(null), [A, j] = a(!1), M = i(null);
	n(() => () => {
		M.current && clearTimeout(M.current);
	}, []);
	let [N, F] = a(null), I = i(null);
	n(() => () => {
		I.current && clearTimeout(I.current);
	}, []);
	let ne = `${e.phase}:${b}:${w}`, [ie, oe] = a(ne);
	ie !== ne && (oe(ne), F(null));
	let [se, le] = a(!1), L = t?.devAnswer ?? null, R = `bgparty:orapa-notes:${r.map((e) => e.rid).sort().join(",")}:${h}:${e.targetOf[h] ?? ""}:${+!!e.blackHole}:${e.nonce}`, [z, B] = a(() => {
		try {
			let e = localStorage.getItem(R);
			return e ? JSON.parse(e) : [];
		} catch {
			return [];
		}
	});
	n(() => {
		try {
			localStorage.setItem(R, JSON.stringify(z));
		} catch {}
	}, [z, R]);
	let V = e.setter !== null && e.setter === h, ue = e.log.flatMap((e) => e.kind === "fire" && (V || e.by === h) ? [{
		port: e.port,
		answer: e.answer
	}] : []), de = e.log.flatMap((e) => e.kind === "ask" && (V || e.by === h) ? [{
		x: e.x,
		y: e.y,
		color: e.color
	}] : []), [H, U] = a(!1), fe = i(null);
	n(() => {
		if (!H) return;
		fe.current?.focus();
		let e = (e) => {
			e.key === "Escape" && U(!1);
		};
		return window.addEventListener("keydown", e), () => window.removeEventListener("keydown", e);
	}, [H]);
	let W = "info", G, K;
	if (e.phase === "place") {
		let t = e.placed.includes(h);
		W = C && !t ? "accent" : "info", G = C ? _(t ? "games.orapa.placedWait" : "games.orapa.placePrompt") : _("games.orapa.placeWaiting", { name: e.setter ? y(e.setter) : "" });
	} else e.pendingLastChance ? (W = b ? "warn" : "info", G = b ? _("games.orapa.lastChanceTurn") : _("games.orapa.waiting", { name: y(e.activeRid ?? "") }), K = _("games.orapa.lastChanceHint")) : b ? (W = "accent", G = _("games.orapa.yourTurn"), K = _("games.orapa.turnHint")) : (G = _("games.orapa.waiting", { name: y(e.activeRid ?? "") }), S && e.eliminated.includes(h) && (W = "warn", G = _("games.orapa.eliminatedYou")));
	N && b && (W = "warn", K = _("games.orapa.fireArmed", { port: N }));
	let pe = e.blackHole ? [...x, "hole"] : x, q = z.length === pe.length, J = e.phase === "play" && S && !V, me = (e) => {
		if (!J) return;
		let t = te(z, e.port).answer;
		return re(t, e.answer) ? "ok" : !q && re(t, Pe(e.port)) ? "unknown" : "bad";
	}, Y = ue.map((e) => ({
		...e,
		verified: me(e)
	})), he = de.map((e) => {
		if (!J) return e;
		let t = ee(z, e.x, e.y);
		return {
			...e,
			verified: t === null && !q ? "unknown" : t === e.color ? "ok" : "bad"
		};
	}), ge = J && N ? te(z, N) : null, _e = ge?.path ?? [], Z = e.phase === "place" && C && !e.placed.includes(h) || e.phase === "play" && S, ye = e.phase === "place" ? E : z, Q = e.phase === "place" ? D : B, be = (e) => {
		if (N !== e) {
			F(e), I.current && clearTimeout(I.current), I.current = setTimeout(() => F((t) => t === e ? null : t), 3e3);
			return;
		}
		I.current && clearTimeout(I.current), F(null), g({
			type: "fire",
			port: e
		});
	}, Se = () => {
		if (!A) {
			j(!0), M.current = setTimeout(() => j(!1), 3e3);
			return;
		}
		M.current && clearTimeout(M.current), j(!1), g({
			type: "submit",
			pieces: z
		});
	}, Ce = () => {
		let t = ae(E, e.blackHole);
		if (t) {
			k(t);
			return;
		}
		k(null), g({
			type: "place",
			pieces: E
		});
	}, $ = ge?.answer ?? null, we = $?.kind === "exit" ? P($.colors) : null, Te = $?.kind === "exit" ? `${N} → ${$.port}` : $?.kind === "disappeared" ? _("games.orapa.previewGone") : $?.kind === "trapped" ? _("games.orapa.previewTrapped") : "—", Ee = (e) => {
		if (J && e.by === h) {
			if (e.kind === "fire") return me({
				port: e.port,
				answer: e.answer
			});
			if (e.kind === "ask") {
				let t = ee(z, e.x, e.y);
				return t === null && !q ? "unknown" : t === e.color ? "ok" : "bad";
			}
		}
	};
	return /* @__PURE__ */ m("div", {
		className: "orapa-screen h-full min-h-0",
		children: [/* @__PURE__ */ p(d, {
			adaptive: !0,
			scroll: !1,
			actionsHeight: "orapa-actions-slot",
			banner: /* @__PURE__ */ m("div", {
				className: "orapa-top",
				children: [
					/* @__PURE__ */ m("div", {
						className: "orapa-brand",
						children: [/* @__PURE__ */ p("strong", { children: _("games.orapa.name") }), /* @__PURE__ */ p("span", { children: "ORAPA · CELESTIAL ATLAS" })]
					}),
					/* @__PURE__ */ p(u, {
						tone: W,
						text: G,
						sub: K,
						chip: _("games.orapa.pieceChip", { n: e.pieceCount }),
						accent: ce.accent
					}),
					/* @__PURE__ */ p("ul", {
						className: "orapa-players",
						children: e.explorers.map((t) => {
							let n = r.find((e) => e.rid === t), i = l[(n?.colorIndex ?? 0) % l.length], a = e.eliminated.includes(t);
							return /* @__PURE__ */ m("li", {
								title: _("games.orapa.chancesTitle"),
								"aria-label": `${n?.name ?? t} ${_("games.orapa.chancesTitle")} ${a ? "0" : e.chancesLeft[t] ?? 0}`,
								className: `orapa-player ${a ? "is-out" : ""} ${e.activeRid === t && e.phase === "play" ? "is-active" : ""}`,
								children: [
									/* @__PURE__ */ p("span", {
										className: "orapa-player-dot",
										style: { background: i.hex },
										children: /* @__PURE__ */ p(Ie, { rid: t })
									}),
									/* @__PURE__ */ p("span", {
										className: "orapa-player-name",
										children: n?.name ?? t
									}),
									/* @__PURE__ */ p("span", {
										className: "font-mono tabular-nums",
										children: a ? "✕" : `×${e.chancesLeft[t] ?? 0}`
									})
								]
							}, t);
						})
					})
				]
			}),
			actions: /* @__PURE__ */ p("div", {
				className: "orapa-actions",
				children: e.phase === "place" && C && !e.placed.includes(h) ? /* @__PURE__ */ p("button", {
					type: "button",
					onClick: Ce,
					disabled: E.length !== pe.length,
					className: "orapa-action is-primary disabled:opacity-40",
					children: _("games.orapa.confirmPlace")
				}) : e.phase === "play" && S && !e.eliminated.includes(h) ? /* @__PURE__ */ m(f, { children: [
					/* @__PURE__ */ p("button", {
						type: "button",
						disabled: !b,
						onClick: () => T("fire"),
						className: `orapa-action ${w === "fire" ? "is-primary" : ""}`,
						"aria-pressed": w === "fire",
						children: _("games.orapa.toolFire")
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						disabled: !b,
						onClick: () => T("ask"),
						className: `orapa-action ${w === "ask" ? "is-primary" : ""}`,
						"aria-pressed": w === "ask",
						children: _("games.orapa.toolAsk")
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						onClick: Se,
						disabled: !b || !q,
						className: `orapa-action ${A ? "is-armed" : ""}`,
						children: _(A ? "games.orapa.submitArmed" : "games.orapa.submitAnswer")
					})
				] }) : /* @__PURE__ */ p("span", {
					className: "orapa-action-wait",
					children: G
				})
			}),
			children: /* @__PURE__ */ m("div", {
				ref: v,
				className: "orapa-observatory",
				children: [
					/* @__PURE__ */ p(c, {
						kind: "sheen",
						base: "#1b2a53",
						className: "absolute inset-0 size-full"
					}),
					/* @__PURE__ */ m("div", {
						className: "orapa-observatory-header",
						children: [
							/* @__PURE__ */ p("span", { children: _("games.orapa.observatoryTitle") }),
							/* @__PURE__ */ p("small", { children: "CELESTIAL GRID · 10 × 08" }),
							!1
						]
					}),
					/* @__PURE__ */ p("div", {
						className: "orapa-play-area",
						children: Z ? /* @__PURE__ */ p(Ae, {
							pieces: ye,
							required: pe,
							ghost: e.phase === "play",
							onChange: Q,
							fires: e.phase === "play" ? Y : [],
							asks: e.phase === "play" ? he : [],
							answer: se && L ? L : void 0,
							paths: _e,
							previewAnswer: $,
							onPort: e.phase === "play" && b && w === "fire" ? be : void 0,
							onCell: e.phase === "play" && b && w === "ask" ? (e, t) => g({
								type: "ask",
								x: e,
								y: t
							}) : void 0,
							armedPort: N,
							portLabel: (e) => _("games.orapa.fireAria", { port: e })
						}, e.phase) : /* @__PURE__ */ m("div", {
							className: "orapa-static-area",
							children: [/* @__PURE__ */ p("div", {
								className: "orapa-board-window",
								children: /* @__PURE__ */ p(ve, {
									pieces: e.phase === "place" || V ? t?.pieces ?? void 0 : se && L ? L : void 0,
									fires: e.phase === "play" ? Y : [],
									asks: e.phase === "play" ? he : [],
									armedPort: N,
									portLabel: (e) => _("games.orapa.fireAria", { port: e })
								})
							}), /* @__PURE__ */ m("div", {
								className: "orapa-tray-wrap orapa-tray-empty",
								children: [/* @__PURE__ */ p("div", {
									className: "orapa-tray-heading",
									children: /* @__PURE__ */ p("span", { children: _("games.orapa.notesTitle") })
								}), /* @__PURE__ */ p("div", {
									className: "orapa-tray-placeholder",
									children: _("games.orapa.waitingBoard")
								})]
							})]
						})
					}),
					/* @__PURE__ */ m("div", {
						className: "orapa-readout",
						children: [/* @__PURE__ */ m("div", {
							className: "orapa-readout-copy",
							children: [
								/* @__PURE__ */ p("span", {
									className: "orapa-readout-kicker",
									children: N && ge ? _("games.orapa.previewTitle", { port: N }) : Z && e.phase === "place" ? _("games.orapa.placeReadout") : e.phase === "play" && S ? _("games.orapa.previewIdle") : _("games.orapa.waitingBoard")
								}),
								/* @__PURE__ */ m("div", {
									className: "orapa-readout-result",
									children: [/* @__PURE__ */ p("strong", {
										className: "font-mono tabular-nums",
										children: Te
									}), we !== null && /* @__PURE__ */ m("span", {
										className: "orapa-preview-color",
										children: [/* @__PURE__ */ p("i", { style: { background: X[we] } }), _(xe[we])]
									})]
								}),
								/* @__PURE__ */ p("span", {
									className: "orapa-readout-hint",
									children: e.phase === "play" && S ? _("games.orapa.previewLocal") : G
								})
							]
						}), /* @__PURE__ */ m("button", {
							type: "button",
							onClick: () => U(!0),
							className: "orapa-records-trigger",
							children: [/* @__PURE__ */ p("strong", { children: _("games.orapa.allRecords") }), /* @__PURE__ */ m("span", { children: [_("games.orapa.recordCount", { n: e.log.length }), " ›"] })]
						})]
					}),
					O && /* @__PURE__ */ p("div", {
						role: "alert",
						className: "orapa-error",
						children: _(O)
					})
				]
			})
		}), /* @__PURE__ */ m("div", {
			className: `orapa-records-layer ${H ? "is-open" : ""}`,
			"aria-hidden": !H,
			children: [/* @__PURE__ */ p("div", {
				className: "orapa-records-scrim",
				onClick: () => U(!1)
			}), /* @__PURE__ */ m("section", {
				className: "orapa-records-sheet",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": _("games.orapa.allRecords"),
				children: [
					/* @__PURE__ */ p("div", { className: "orapa-records-grip" }),
					/* @__PURE__ */ m("header", {
						className: "orapa-records-header",
						children: [
							/* @__PURE__ */ p("h2", { children: _("games.orapa.allRecords") }),
							/* @__PURE__ */ p("span", { children: _("games.orapa.recordCount", { n: e.log.length }) }),
							/* @__PURE__ */ p("button", {
								ref: fe,
								type: "button",
								onClick: () => U(!1),
								"aria-label": _("games.orapa.closeRecords"),
								children: "×"
							})
						]
					}),
					/* @__PURE__ */ p("p", {
						className: "orapa-records-sub",
						children: _("games.orapa.recordsReadonly")
					}),
					/* @__PURE__ */ m("ul", {
						className: "orapa-records-list",
						children: [e.log.length === 0 && /* @__PURE__ */ p("li", {
							className: "orapa-record-empty",
							children: _("games.orapa.logEmpty")
						}), e.log.slice().reverse().map((t, n) => {
							let r = Ee(t);
							return /* @__PURE__ */ m("li", {
								className: "orapa-record-row",
								children: [
									/* @__PURE__ */ p("span", {
										className: "orapa-record-index font-mono tabular-nums",
										children: String(e.log.length - n).padStart(2, "0")
									}),
									/* @__PURE__ */ p(Le, {
										entry: t,
										actor: t.by === h ? null : y(t.by)
									}),
									/* @__PURE__ */ p("span", {
										className: `orapa-record-verdict ${r ?? "none"}`,
										children: r === "ok" ? "✓" : r === "bad" ? "✕" : r === "unknown" ? "?" : ""
									})
								]
							}, e.log.length - n);
						})]
					})
				]
			})]
		})]
	});
}
function Ie({ rid: e }) {
	let { ref: t } = o(`seat:${e}`);
	return /* @__PURE__ */ p("span", {
		ref: t,
		className: "inline-block size-0",
		"aria-hidden": !0
	});
}
function Le({ entry: e, actor: t }) {
	let n = s(), r, i, a = null;
	if (e.kind === "fire") {
		if (r = `${n("games.orapa.toolFire")} ${e.port}${e.answer.kind === "exit" ? ` → ${e.answer.port}` : ""}`, e.answer.kind === "exit") {
			let t = P(e.answer.colors);
			i = n(xe[t]), a = X[t];
		} else i = n(e.answer.kind === "disappeared" ? "games.orapa.recordGone" : "games.orapa.recordTrapped");
	} else e.kind === "ask" ? (r = `${n("games.orapa.toolAsk")} ${N(e.x, e.y)}`, i = e.color === null ? n("games.orapa.askEmpty") : e.color === "H" ? n("games.orapa.colorHole") : n(xe[e.color]), a = e.color ? Y[e.color] : null) : (r = n("games.orapa.submitAnswer"), i = n(e.ok ? "games.orapa.recordCorrect" : "games.orapa.recordWrong"));
	return /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("span", {
		className: "orapa-record-line",
		children: [t && /* @__PURE__ */ m("small", { children: [t, " · "] }), r]
	}), /* @__PURE__ */ m("span", {
		className: "orapa-record-result",
		children: [a && /* @__PURE__ */ p("i", { style: { background: a } }), i]
	})] });
}
//#endregion
//#region src/games/orapa/fx.tsx
var Re = {
	laser(e, t) {
		let n = t.anchor("board");
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ p(g, {
				at: n,
				ms: 500
			})
		} : {
			ms: 500,
			node: null
		};
	},
	placed() {
		return {
			ms: 300,
			node: null
		};
	},
	start() {
		return {
			ms: 400,
			node: null
		};
	},
	submit() {
		return {
			ms: 600,
			node: null
		};
	},
	out(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 1100,
			node: /* @__PURE__ */ p(h, {
				at: n,
				ms: 1e3,
				children: /* @__PURE__ */ p("span", {
					"aria-hidden": !0,
					className: "text-danger",
					children: "✗"
				})
			})
		} : {
			ms: 800,
			node: null
		};
	},
	lastChance() {
		return {
			ms: 600,
			node: null
		};
	}
};
//#endregion
//#region src/games/orapa/game-over.tsx
function ze({ result: e, public: t, members: n, onPlayAgain: r, onBackToLobby: i }) {
	let a = s(), o = t, c = (e) => n.find((t) => t.rid === e)?.name ?? e, u = r ?? i, d = e.winner, h = d.length > 1 ? a("games.orapa.endDraw") : d.length === 1 ? o.setter === d[0] ? a("games.orapa.endSetterWins", { name: c(d[0]) }) : a("games.orapa.endWinner", { name: c(d[0]) }) : a("games.orapa.endNoWinner");
	return /* @__PURE__ */ m("div", {
		className: "orapa-final relative flex h-full min-h-0 flex-col items-center gap-2 overflow-hidden",
		children: [
			d.length > 0 && /* @__PURE__ */ p(v, {}),
			/* @__PURE__ */ m("h1", {
				className: "orapa-final-title flex flex-none items-center gap-2 text-center font-display text-xl font-extrabold",
				children: [/* @__PURE__ */ p("span", {
					"aria-hidden": !0,
					children: "🪐"
				}), h]
			}),
			/* @__PURE__ */ p("p", {
				className: "orapa-final-subtitle flex-none text-sm font-bold opacity-70",
				children: a("games.orapa.endReveal")
			}),
			/* @__PURE__ */ p("div", {
				className: "orapa-final-boards",
				"data-count": Object.keys(o.boards ?? {}).length,
				children: Object.entries(o.boards ?? {}).map(([e, t]) => {
					let r = e === "auto" ? null : n.find((t) => t.rid === e);
					return /* @__PURE__ */ m("div", {
						className: "orapa-final-board w-full p-2",
						children: [/* @__PURE__ */ p("p", {
							className: "orapa-final-owner mb-1 flex items-center gap-1.5 text-xs font-extrabold",
							children: r ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("img", {
								src: _[r.avatar % _.length],
								alt: "",
								draggable: !1,
								className: "size-5 rounded-full border border-ink object-contain",
								style: { backgroundColor: l[r.colorIndex % l.length].hex }
							}), a("games.orapa.boardOf", { name: r.name })] }) : a("games.orapa.boardAuto")
						}), /* @__PURE__ */ p(ve, { pieces: t })]
					}, e);
				})
			}),
			u ? /* @__PURE__ */ m("div", {
				className: "orapa-final-controls safe-b flex w-full flex-none flex-col gap-2 pb-1",
				children: [r && /* @__PURE__ */ p("button", {
					className: "btn-base orapa-final-action w-full cursor-pointer",
					onClick: r,
					children: a("session.result.playAgain")
				}), i && /* @__PURE__ */ p("button", {
					className: "btn-quiet w-full cursor-pointer",
					onClick: i,
					children: a("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ p("p", {
				className: "safe-b flex-none pb-1 text-sm font-bold opacity-70",
				children: a("session.result.waitHost")
			})
		]
	});
}
//#endregion
//#region src/games/orapa/options.tsx
function Be({ value: e, onChange: t }) {
	let n = s(), r = z.safeParse(e), i = r.success ? r.data : z.parse(void 0);
	return /* @__PURE__ */ m("div", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ p(b, {
			title: n("games.orapa.optMode"),
			children: ["auto", "master"].map((e) => /* @__PURE__ */ p(y, {
				name: "orapa-mode",
				value: e,
				checked: i.mode === e,
				label: n(e === "auto" ? "games.orapa.optAuto" : "games.orapa.optMaster"),
				accent: ce.accent,
				onChange: () => t({
					...i,
					mode: e
				})
			}, e))
		}), /* @__PURE__ */ p(b, {
			title: n("games.orapa.optBlackHole"),
			children: [!1, !0].map((e) => /* @__PURE__ */ p(y, {
				name: "orapa-black-hole",
				value: String(e),
				checked: i.blackHole === e,
				label: n(e ? "games.orapa.optOn" : "games.orapa.optOff"),
				accent: ce.accent,
				onChange: () => t({
					...i,
					blackHole: e
				})
			}, String(e)))
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/orapa/entry.tsx
var Ve = {
	definition: me,
	View: Me,
	fx: Re,
	OverView: ze,
	Options: Be,
	Guide: Ee,
	locales: {
		zh: {
			name: "奥拉帕宇宙",
			desc: "向星空发射激光,从混色光谱推理出隐藏行星的位置",
			rules: "目标:推理出隐藏天体的完整摆放,最先提交正确答案的人获胜。\n准备:\n· 版图宽 10 格、高 8 格,藏着 6 颗行星(开启黑洞扩展后为 7 个天体),位置只有出题者知道。\n· 出题方式二选一:系统出题(全员都是探索者),或出题者模式(一人摆放,其余人探索);2 人时互相出题。\n流程(轮到你,三选一):\n· 发射:从 36 个端口之一射入激光,系统报告出射口与混色结果;激光也可能被黑洞吞噬或困住。\n· 提问:询问一个坐标格里有什么。\n· 提交:摆出推理出的完整摆放,由系统判定对错。\n激光规则:\n· 行星边缘反射激光:斜边偏转 90°,直边原路弹回 180°。\n· 途经的天体颜色会混入激光,同色只计一次。\n胜负:\n· 3 人以上:每人 2 次提交机会,用完即淘汰;探索者全灭则出题者获胜(系统出题时无胜者)。\n· 2 人:互相出题,各 1 次机会;先手答对后对方还有最后一次行动,同样答对算平局。",
			optMode: "出题方式",
			optAuto: "系统出题",
			optMaster: "出题者模式",
			optBlackHole: "黑洞扩展",
			optOn: "开启",
			optOff: "关闭",
			pieceChip: "{{n}} 天体",
			observatoryTitle: "星图观测盘",
			notesTitle: "我的推理板",
			notesCount: "已摆 {{placed}} / {{total}} · 拖动上盘",
			waitingBoard: "观测盘待命",
			previewTitle: "{{port}} 号口 · 假设光线预演",
			previewIdle: "选中端口预演光路",
			placeReadout: "拖动天体完成星空布局",
			previewGone: "消失",
			previewTrapped: "受困",
			previewLocal: "仅依据推理板",
			allRecords: "全部记录",
			recordCount: "{{n}} 条",
			recordsReadonly: "只读流水 · 状态随本地推理板自动更新",
			closeRecords: "关闭全部记录",
			recordGone: "消失",
			recordTrapped: "受困",
			recordCorrect: "正确",
			recordWrong: "不对",
			placePrompt: "摆放你的星空:把天体拖进版图",
			placeWaiting: "等 {{name}} 摆放星空…",
			placedWait: "已确认,等其他人摆完…",
			confirmPlace: "确认摆放",
			guideColors: "混色表",
			guideBigWhite: "长直边必须贴版边:直边弹回 180°,斜角偏转 90°",
			guideSmallRed: "正方形:激光直射弹回 180°",
			guideBigRed: "菱形:斜边把激光偏转 90°",
			guideBlue: "菱形:斜边把激光偏转 90°",
			guideYellow: "八边形:直边弹回 180°,斜角偏转 90°",
			guideSaturn: "垂直撞环弹回 180°,沿环穿过不受影响;中央菱形偏转 90°",
			guideHole: "直射消失;从斜后方掠过会被吸弯 90°(每束激光只弯一次)",
			chancesTitle: "剩余提交机会",
			rotate: "旋转",
			remove: "移除",
			yourTurn: "轮到你:发射、提问,或提交答案",
			turnHint: "连点同一端口两次发射激光;切「提问」点格子;推理摆子直接拖",
			waiting: "等 {{name}} 探索…",
			eliminatedYou: "你的机会用完了,观战中",
			lastChanceTurn: "对方已解出!这是你最后一次机会",
			lastChanceHint: "提交正确即平局,探索或答错都算输",
			toolFire: "发射",
			toolAsk: "提问",
			submitAnswer: "提交答案",
			submitArmed: "再点一次确认提交",
			devPeek: "(dev) 偷看答案",
			fireAria: "从端口 {{port}} 发射",
			fireArmed: "再点一次 {{port}} 确认发射",
			askEmpty: "空",
			logExit: "{{name}} 从 {{port}} 发射 → 从 {{exit}} 出现 {{color}}",
			logEmpty: "还没有探索记录",
			logGone: "{{name}} 从 {{port}} 发射:消失了!",
			logTrapped: "{{name}} 从 {{port}} 发射:被困住了!",
			logAsk: "{{name}} 问 {{cell}}:{{answer}}",
			logSubmitOk: "{{name}} 提交答案:正确!",
			logSubmitBad: "{{name}} 提交答案:不对…",
			endWinner: "{{name}} 解开了星空!",
			endSetterWins: "全员淘汰,出题者 {{name}} 获胜!",
			endNoWinner: "全员淘汰,这片星空无人能解",
			endDraw: "先后解出,平局!",
			endReveal: "答案揭晓",
			boardOf: "{{name}} 的星空",
			boardAuto: "系统出的星空",
			pieceBigWhite: "大白行星",
			pieceSmallRed: "小红行星",
			pieceBigRed: "大红行星",
			pieceBlue: "蓝行星",
			pieceYellow: "黄行星",
			pieceSaturn: "白环行星",
			pieceHole: "黑洞",
			colorNone: "透明",
			colorR: "红色",
			colorY: "黄色",
			colorB: "蓝色",
			colorW: "白色",
			colorRY: "橙色",
			colorRB: "紫色",
			colorYB: "绿色",
			colorRW: "粉色",
			colorYW: "柠檬色",
			colorBW: "天蓝色",
			colorRYW: "浅橙色",
			colorRBW: "浅紫色",
			colorYBW: "浅绿色",
			colorRYB: "黑色",
			colorRYBW: "灰色",
			colorHole: "黑洞",
			errPieces: "天体数量或种类不对",
			errBounds: "有天体超出版图",
			errFlush: "大白行星的长直边必须贴住版图边缘",
			errOverlap: "天体不能共用格子",
			errHidden: "每个天体都要能被某个端口直射看见",
			errBadPhase: "现在不能这么做",
			errNotYourTurn: "现在轮不到你"
		},
		en: {
			name: "Orapa Space",
			desc: "Fire lasers into the stars and deduce the hidden planets from the blended colors",
			rules: "Goal: deduce the full layout of the hidden bodies; the first correct submission wins.\nSetup:\n· The board is 10×8 and hides 6 planets (7 bodies with the black hole expansion); only the setter knows the layout.\n· Two ways to set the puzzle: System (everyone explores) or Setter mode (one player builds the board, the rest explore); with 2 players you set boards for each other.\nOn your turn, choose one:\n· Fire: shoot a laser from one of the 36 ports — you are told the exit port and the blended color; the beam may also be swallowed by the black hole or trapped.\n· Ask: query what a coordinate holds.\n· Submit: lay out your full guess for the system to judge.\nLaser rules:\n· Planet edges reflect the beam: diagonal edges bend it 90°, straight edges bounce it back 180°.\n· Bodies the beam passes tint its color; the same color counts only once.\nResult:\n· With 3+ players: each explorer has 2 submissions and is eliminated after spending both; if every explorer is eliminated, the setter wins (no winner in System mode).\n· With 2 players: one submission each; after the first player answers correctly, the other gets one last action, and a correct answer there is a draw.",
			optMode: "Puzzle setter",
			optAuto: "System",
			optMaster: "Setter mode",
			optBlackHole: "Black hole",
			optOn: "On",
			optOff: "Off",
			pieceChip: "{{n}} bodies",
			observatoryTitle: "Celestial observatory",
			notesTitle: "My deduction board",
			notesCount: "{{placed}} / {{total}} placed · drag onto chart",
			waitingBoard: "Observatory standing by",
			previewTitle: "Port {{port}} · predicted light path",
			previewIdle: "Select a port to preview a beam",
			placeReadout: "Drag each body into your sky",
			previewGone: "Vanishes",
			previewTrapped: "Trapped",
			previewLocal: "Based on my board only",
			allRecords: "All records",
			recordCount: "{{n}} records",
			recordsReadonly: "Read only · status updates with your board",
			closeRecords: "Close all records",
			recordGone: "Vanishes",
			recordTrapped: "Trapped",
			recordCorrect: "Correct",
			recordWrong: "Wrong",
			placePrompt: "Build your sky: drag bodies onto the board",
			placeWaiting: "Waiting for {{name}} to set the sky…",
			placedWait: "Confirmed — waiting for the others…",
			confirmPlace: "Confirm setup",
			guideColors: "Color mixing",
			guideBigWhite: "Long straight edge must touch the border: straight edges bounce 180°, corners bend 90°",
			guideSmallRed: "Square: bounces the laser straight back 180°",
			guideBigRed: "Diamond: diagonal edges bend the laser 90°",
			guideBlue: "Diamond: diagonal edges bend the laser 90°",
			guideYellow: "Octagon: straight edges bounce 180°, corners bend 90°",
			guideSaturn: "Hitting the ring head-on bounces 180°; passing along it is unaffected; the inner diamond bends 90°",
			guideHole: "A direct hit vanishes; grazing past its rear diagonal bends the beam 90° (once per beam)",
			chancesTitle: "Submissions left",
			rotate: "Rotate",
			remove: "Remove",
			yourTurn: "Your turn: fire, ask, or submit",
			turnHint: "Tap a port twice to fire; switch to Ask to tap a cell; drag bodies to guess",
			waiting: "Waiting for {{name}} to explore…",
			eliminatedYou: "Out of chances — spectating",
			lastChanceTurn: "They solved it first! Last chance",
			lastChanceHint: "A correct submit ties; exploring or missing loses",
			toolFire: "Fire",
			toolAsk: "Ask",
			submitAnswer: "Submit answer",
			submitArmed: "Tap again to confirm",
			devPeek: "(dev) Peek at the answer",
			fireAria: "Fire from port {{port}}",
			fireArmed: "Tap {{port}} again to fire",
			askEmpty: "Empty",
			logExit: "{{name}} fired {{port}} → appeared from {{exit}} in {{color}}",
			logEmpty: "No exploration yet",
			logGone: "{{name}} fired {{port}}: it vanished!",
			logTrapped: "{{name}} fired {{port}}: trapped!",
			logAsk: "{{name}} asked {{cell}}: {{answer}}",
			logSubmitOk: "{{name}} submitted: correct!",
			logSubmitBad: "{{name}} submitted: wrong…",
			endWinner: "{{name}} solved the sky!",
			endSetterWins: "All eliminated — setter {{name}} wins!",
			endNoWinner: "All eliminated — this sky stays unsolved",
			endDraw: "Both solved it — draw!",
			endReveal: "The answer",
			boardOf: "{{name}}'s sky",
			boardAuto: "System sky",
			pieceBigWhite: "Big white planet",
			pieceSmallRed: "Small red planet",
			pieceBigRed: "Big red planet",
			pieceBlue: "Blue planet",
			pieceYellow: "Yellow planet",
			pieceSaturn: "Ringed planet",
			pieceHole: "Black hole",
			colorNone: "Clear",
			colorR: "Red",
			colorY: "Yellow",
			colorB: "Blue",
			colorW: "White",
			colorRY: "Orange",
			colorRB: "Purple",
			colorYB: "Green",
			colorRW: "Pink",
			colorYW: "Lemon",
			colorBW: "Sky blue",
			colorRYW: "Light orange",
			colorRBW: "Light purple",
			colorYBW: "Light green",
			colorRYB: "Black",
			colorRYBW: "Gray",
			colorHole: "Black hole",
			errPieces: "Wrong set of bodies",
			errBounds: "A body sticks out of the board",
			errFlush: "The big white planet must touch the edge",
			errOverlap: "Bodies cannot share cells",
			errHidden: "Every body must be visible from some port",
			errBadPhase: "Not allowed right now",
			errNotYourTurn: "Not your turn"
		}
	}
};
//#endregion
export { Ve as default };
