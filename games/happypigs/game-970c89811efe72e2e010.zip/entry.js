import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { avatarNameAt as a, useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { LogTicker as l } from "@bgparty/sdk/ui/log-sheet";
import { PhaseBanner as u } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as d } from "@bgparty/sdk/ui/player-strip";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { botAvatarOf as h } from "@bgparty/sdk/lobby";
import { AVATARS as g } from "@bgparty/sdk/avatars";
//#region src/games/happypigs/data.ts
var _ = [
	[2, 2],
	[2, 3],
	[3, 3],
	[3, 4]
], v = [
	3,
	6,
	10,
	15
], y = [
	50,
	48,
	48,
	50
];
function b(e) {
	return 5 * (e + 1);
}
function x(e) {
	let t = 0;
	for (let n = 1; n < e; n += 1) t += b(n);
	return t;
}
var ee = [
	{
		id: 0,
		season: 0,
		caps: [
			7,
			10,
			9,
			6
		],
		effect: "vaccination"
	},
	{
		id: 1,
		season: 0,
		caps: [
			7,
			9,
			8,
			6
		],
		effect: "seasonOfLove"
	},
	{
		id: 2,
		season: 0,
		caps: [
			8,
			10,
			9,
			7
		],
		effect: "none"
	},
	{
		id: 3,
		season: 0,
		caps: [
			8,
			10,
			9,
			7
		],
		effect: "fieldSale"
	},
	{
		id: 4,
		season: 0,
		caps: [
			7,
			10,
			9,
			6
		],
		effect: "vaccination"
	},
	{
		id: 5,
		season: 0,
		caps: [
			7,
			9,
			8,
			6
		],
		effect: "seasonOfLove"
	},
	{
		id: 6,
		season: 1,
		caps: [
			9,
			7,
			9,
			8
		],
		effect: "sanitary"
	},
	{
		id: 7,
		season: 1,
		caps: [
			8,
			6,
			9,
			7
		],
		effect: "seasonOfLove"
	},
	{
		id: 8,
		season: 1,
		caps: [
			9,
			7,
			9,
			8
		],
		effect: "sanitary"
	},
	{
		id: 9,
		season: 1,
		caps: [
			8,
			6,
			9,
			7
		],
		effect: "seasonOfLove"
	},
	{
		id: 10,
		season: 1,
		caps: [
			9,
			7,
			10,
			8
		],
		effect: "familyDay"
	},
	{
		id: 11,
		season: 1,
		caps: [
			9,
			6,
			9,
			7
		],
		effect: "vaccination"
	},
	{
		id: 12,
		season: 2,
		caps: [
			9,
			8,
			7,
			9
		],
		effect: "govAid"
	},
	{
		id: 13,
		season: 2,
		caps: [
			9,
			7,
			6,
			8
		],
		effect: "liquidation"
	},
	{
		id: 14,
		season: 2,
		caps: [
			10,
			8,
			7,
			9
		],
		effect: "pigFair"
	},
	{
		id: 15,
		season: 2,
		caps: [
			10,
			8,
			7,
			9
		],
		effect: "pigFair"
	},
	{
		id: 16,
		season: 2,
		caps: [
			9,
			7,
			6,
			9
		],
		effect: "sanitary"
	},
	{
		id: 17,
		season: 2,
		caps: [
			9,
			7,
			6,
			8
		],
		effect: "liquidation"
	},
	{
		id: 18,
		season: 3,
		caps: [
			6,
			9,
			7,
			10
		],
		effect: "pigFair"
	},
	{
		id: 19,
		season: 3,
		caps: [
			6,
			9,
			7,
			9
		],
		effect: "hamFest"
	},
	{
		id: 20,
		season: 3,
		caps: [
			6,
			8,
			7,
			9
		],
		effect: "baconFest"
	},
	{
		id: 21,
		season: 3,
		caps: [
			7,
			9,
			8,
			9
		],
		effect: "familyDay"
	},
	{
		id: 22,
		season: 3,
		caps: [
			6,
			8,
			7,
			9
		],
		effect: "baconFest"
	},
	{
		id: 23,
		season: 3,
		caps: [
			7,
			9,
			8,
			10
		],
		effect: "vaccination"
	}
], te = [
	"feed",
	"buy",
	"mate",
	"sell"
];
function S(e, t) {
	return t ? t.effect === "baconFest" ? [
		6,
		10,
		15,
		21
	][e] : t.effect === "hamFest" ? [
		5,
		9,
		14,
		20
	][e] : t.effect === "sanitary" ? v[e] + 3 : v[e] : v[e];
}
function ne(e, t) {
	let n = b(e);
	return t?.effect === "fieldSale" ? Math.max(0, n - 3) : n;
}
//#endregion
//#region src/games/happypigs/meta.ts
var re = {
	id: "happypigs",
	tier: "beta",
	mechanics: ["engine-building"],
	interactionTags: [],
	nameKey: "games.happypigs.name",
	descKey: "games.happypigs.desc",
	rulesKey: "games.happypigs.rules",
	icon: "🐷",
	iconImg: "games/happypigs.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/happypigs/en.pdf" },
	minPlayers: 3,
	maxPlayers: 6,
	bestPlayers: [4],
	accent: "#f472b6",
	releasedAt: "2026-10-10",
	search: {
		py: "yang zhu qu",
		init: "yzq"
	},
	hotseat: "cover"
}, C = t.union([
	t.literal(0),
	t.literal(1),
	t.literal(2),
	t.literal(3)
]), ie = t.enum([
	"feed",
	"buy",
	"mate",
	"sell"
]), w = t.int().nonnegative(), T = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("choose"),
		action: ie
	}),
	t.object({
		type: t.literal("feed"),
		pigId: w,
		supplement: t.boolean().optional()
	}),
	t.object({
		type: t.literal("mate"),
		pigId: w,
		amulet: t.boolean().optional()
	}),
	t.object({
		type: t.literal("buy"),
		buy: t.discriminatedUnion("kind", [
			t.object({
				kind: t.literal("pig"),
				size: C
			}),
			t.object({
				kind: t.literal("item"),
				item: t.enum([
					"vaccine",
					"supp",
					"amulet"
				])
			}),
			t.object({ kind: t.literal("field") })
		])
	}),
	t.object({
		type: t.literal("sell"),
		pigId: w
	}),
	t.object({ type: t.literal("stop") }),
	t.object({
		type: t.literal("placePig"),
		pigId: w,
		field: t.int().nonnegative(),
		x: t.int().nonnegative(),
		y: t.int().nonnegative(),
		rot: t.boolean()
	}),
	t.object({
		type: t.literal("discardPig"),
		pigId: w
	}),
	t.object({ type: t.literal("repack") }),
	t.object({ type: t.literal("donePlace") }),
	t.object({
		type: t.literal("vaccinate"),
		pigIds: t.array(w)
	})
]), E = t.string(), ae = t.object({
	id: w,
	size: C,
	vac: t.boolean(),
	field: t.int(),
	x: t.int().nonnegative(),
	y: t.int().nonnegative(),
	rot: t.boolean()
}), D = t.object({
	k: t.string(),
	p: t.record(t.string(), t.union([t.string(), t.number()])).optional()
}), O = t.object({
	phase: t.enum([
		"setup",
		"choose",
		"act",
		"place",
		"seasonChange",
		"done"
	]),
	round: t.int().nonnegative(),
	season: t.union([
		t.literal(0),
		t.literal(1),
		t.literal(2),
		t.literal(3)
	]),
	first: E,
	card: t.object({
		id: t.int().nonnegative(),
		season: t.union([
			t.literal(0),
			t.literal(1),
			t.literal(2),
			t.literal(3)
		]),
		caps: t.tuple([
			t.number(),
			t.number(),
			t.number(),
			t.number()
		]),
		effect: t.string()
	}).nullable(),
	players: t.array(t.object({
		rid: E,
		money: t.number(),
		fields: t.int().positive(),
		items: t.object({
			vaccine: t.int().nonnegative(),
			supp: t.int().nonnegative(),
			amulet: t.int().nonnegative()
		}),
		pigs: t.array(ae),
		fed: t.array(w),
		mated: t.array(w)
	})),
	chosenBy: t.array(E),
	chosen: t.record(t.string(), ie).nullable(),
	alloc: t.record(t.string(), t.int().nonnegative()).nullable(),
	actTurn: E.nullable(),
	remaining: t.int().nonnegative(),
	setupTurn: E.nullable(),
	setupLeft: t.int().nonnegative(),
	placeTurn: E.nullable(),
	scPending: t.array(E),
	supply: t.object({
		pigs: t.tuple([
			t.number(),
			t.number(),
			t.number(),
			t.number()
		]),
		vaccine: t.number(),
		supp: t.number(),
		amulet: t.number(),
		fields: t.number()
	}),
	log: t.array(D)
}), oe = t.object({ myChoice: ie.nullable() });
//#endregion
//#region src/games/happypigs/rules.ts
function se(e) {
	let [t, n] = _[e.size];
	return e.rot ? [n, t] : [t, n];
}
function k(e, t) {
	return e.x < t.x + t.w && t.x < e.x + e.w && e.y < t.y + t.h && t.y < e.y + e.h;
}
function A(e, t, n, r, i, a, o) {
	if (n < 0 || n >= t) return !1;
	let [s, c] = se({
		size: a,
		rot: o
	});
	if (r + s > 6 || i + c > 11) return !1;
	for (let t of e) {
		if (t.field !== n) continue;
		let [e, a] = se(t);
		if (k({
			x: r,
			y: i,
			w: s,
			h: c
		}, {
			x: t.x,
			y: t.y,
			w: e,
			h: a
		})) return !1;
	}
	return !0;
}
function j(e, t, n) {
	let [r, i] = _[n], a = r === i ? [[
		r,
		i,
		!1
	]] : [[
		r,
		i,
		!1
	], [
		i,
		r,
		!0
	]];
	for (let r = 0; r < t; r += 1) for (let [i, o, s] of a) for (let a = 0; a + o <= 11; a += 1) for (let o = 0; o + i <= 6; o += 1) if (A(e, t, r, o, a, n, s)) return {
		field: r,
		x: o,
		y: a,
		rot: s
	};
	return null;
}
var M = (e) => _[e][0] * _[e][1];
function N(e, t) {
	let n = [...e].sort((e, t) => M(t.size) - M(e.size) || e.id - t.id), r = [];
	for (let e of n) {
		let n = j(r, t, e.size);
		if (!n) return null;
		r.push({
			...e,
			...n
		});
	}
	return r;
}
var P = [
	"games.happypigs.pig0",
	"games.happypigs.pig1",
	"games.happypigs.pig2",
	"games.happypigs.pig3"
], F = {
	vaccine: "games.happypigs.itemVaccine",
	supp: "games.happypigs.itemSupp",
	amulet: "games.happypigs.itemAmulet"
}, I = [
	"games.happypigs.card0",
	"games.happypigs.card1",
	"games.happypigs.card2",
	"games.happypigs.card3",
	"games.happypigs.card4",
	"games.happypigs.card5",
	"games.happypigs.card6",
	"games.happypigs.card7",
	"games.happypigs.card8",
	"games.happypigs.card9",
	"games.happypigs.card10",
	"games.happypigs.card11",
	"games.happypigs.card12",
	"games.happypigs.card13",
	"games.happypigs.card14",
	"games.happypigs.card15",
	"games.happypigs.card16",
	"games.happypigs.card17",
	"games.happypigs.card18",
	"games.happypigs.card19",
	"games.happypigs.card20",
	"games.happypigs.card21",
	"games.happypigs.card22",
	"games.happypigs.card23"
];
function L(e) {
	return e.phase === "setup" || e.round >= 16 ? null : ee[e.deck[e.round]];
}
function R(e) {
	return e.players.map((t, n) => e.players[(e.first + n) % e.players.length]);
}
function z(e, t, n) {
	e.log.push({
		k: t,
		p: n
	}), e.log.length > 120 && (e.log = e.log.slice(-120));
}
function B(e, t) {
	return e.pigs[t].filter((e) => e.field >= 0);
}
function V(e, t) {
	e.supply.pigs[t.size] += 1;
}
function H(e, t) {
	let n = e.pigs[t];
	for (let r of [...n]) {
		if (r.field !== -1) continue;
		let n = j(B(e, t), e.fields[t], r.size);
		n ? Object.assign(r, n) : (e.pigs[t] = e.pigs[t].filter((e) => e.id !== r.id), V(e, r), z(e, "log.discardPig", {
			who: t,
			whatKey: P[r.size]
		}));
	}
}
function ce(e, t, n, r) {
	let i = B(e, t).filter((e) => e.id !== n.id);
	if (A(i, e.fields[t], n.field, n.x, n.y, r, n.rot)) return !0;
	let a = j(i, e.fields[t], r);
	return a ? (Object.assign(n, a), !0) : U(e, t, i, n, r);
}
function U(e, t, n, r, i) {
	let a = N([...n, {
		...r,
		size: i,
		field: 0,
		x: 0,
		y: 0,
		rot: !1
	}], e.fields[t]);
	if (!a) return !1;
	let o = new Map(a.map((e) => [e.id, e]));
	return e.pigs[t] = e.pigs[t].map((e) => o.get(e.id) ?? e), !0;
}
function W(e, t, n, r) {
	let i = e.filter((e) => e.id !== n.id);
	return A(i, t, n.field, n.x, n.y, r, n.rot) || j(i, t, r) ? !0 : N([...i, {
		...n,
		size: r,
		field: 0,
		x: 0,
		y: 0,
		rot: !1
	}], t) !== null;
}
function G(e, t, n) {
	let r = {
		id: e.nextPigId,
		size: n,
		vac: !1,
		field: -1,
		x: 0,
		y: 0,
		rot: !1
	};
	return e.nextPigId += 1, --e.supply.pigs[n], e.pigs[t].push(r), r;
}
function K(t, n, r) {
	let i = 0, a = [];
	for (let t = 0; t < 4; t += 1) {
		let n = ee.filter((e) => e.season === t).map((e) => e.id);
		for (let t = n.length - 1; t > 0; --t) {
			let a = e(r, i, t + 1);
			i += 1, [n[t], n[a]] = [n[a], n[t]];
		}
		a.push(...n.slice(0, 4));
	}
	let o = e(r, i, n.length);
	i += 1;
	let s = {}, c = {}, l = {}, u = {}, d = {};
	for (let e of n) s[e] = 45, c[e] = 1, l[e] = [], u[e] = {
		vaccine: 0,
		supp: 0,
		amulet: 0
	}, d[e] = {
		fed: [],
		mated: []
	};
	return {
		state: {
			players: n,
			nextPigId: 1,
			money: s,
			fields: c,
			pigs: l,
			items: u,
			supply: {
				pigs: [...y],
				vaccine: 25,
				supp: 25,
				amulet: 25,
				fields: 20 - n.length
			},
			deck: a,
			round: 0,
			first: o,
			phase: "setup",
			setupTurn: 0,
			setupLeft: 5,
			chosen: {},
			revealed: !1,
			alloc: {},
			actIdx: 0,
			remaining: 0,
			used: d,
			placeQueue: [],
			scSubmitted: [],
			rngCursor: i,
			log: []
		},
		fx: []
	};
}
function le(e) {
	e.round += 1, e.first = (e.first + 1) % e.players.length, e.phase = "choose", e.chosen = {}, e.revealed = !1, e.alloc = {}, e.actIdx = 0, e.remaining = 0;
	for (let t of e.players) e.used[t] = {
		fed: [],
		mated: []
	};
	let t = L(e);
	t && z(e, "log.round", {
		n: e.round + 1,
		cardKey: I[t.id]
	});
}
function q(e) {
	for (let t of e.players) {
		let n = e.pigs[t].filter((e) => !e.vac);
		if (n.length !== 0) {
			e.pigs[t] = e.pigs[t].filter((e) => e.vac);
			for (let t of n) V(e, t);
			z(e, "log.deaths", {
				who: t,
				n: n.length
			});
		}
	}
	if (e.round >= 15) {
		for (let t of e.players) {
			let n = e.pigs[t].reduce((e, t) => e + S(t.size, null), 0);
			e.money[t] += n, z(e, "log.finalSale", {
				who: t,
				n
			});
			for (let n of e.pigs[t]) V(e, n);
			e.pigs[t] = [];
		}
		e.phase = "done";
		return;
	}
	le(e);
}
function J(e) {
	e.phase = "seasonChange", e.scSubmitted = [];
	for (let t of e.players) (!e.pigs[t].some((e) => !e.vac) || e.items[t].vaccine === 0) && e.scSubmitted.push(t);
	e.scSubmitted.length === e.players.length && q(e);
}
function ue(e) {
	let t = L(e);
	if (t) {
		let n = R(e);
		if (t.effect === "familyDay") for (let t of n) new Set(B(e, t).map((e) => e.size)).size === 4 && (e.money[t] += 25, z(e, "log.effectMoney", {
			who: t,
			n: 25,
			effectKey: "games.happypigs.effectFamilyDay"
		}));
		else if (t.effect === "pigFair" || t.effect === "vaccination" || t.effect === "govAid") {
			let r = t.effect === "pigFair" ? 3 : +(t.effect === "vaccination"), i = new Map(n.map((t) => [t, B(e, t).filter((e) => e.size === r).length])), a = Math.max(...i.values());
			if (a >= 1) {
				for (let r of n) if (i.get(r) === a) {
					if (t.effect === "pigFair") e.money[r] += 25, z(e, "log.effectMoney", {
						who: r,
						n: 25,
						effectKey: "games.happypigs.effectPigFair"
					});
					else {
						let n = t.effect === "vaccination" ? "vaccine" : "supp", i = Math.min(3, e.supply[n]);
						e.supply[n] -= i, e.items[r][n] += i, z(e, "log.effectItems", {
							who: r,
							n: i,
							whatKey: F[n]
						});
					}
				}
			}
		} else if (t.effect === "seasonOfLove") for (let t of n) {
			let n = B(e, t).filter((e) => e.size >= 2).length, r = Math.min(Math.floor(n / 2), e.supply.pigs[0]);
			for (let n = 0; n < r; n += 1) G(e, t, 0);
			r > 0 && z(e, "log.effectPiglets", {
				who: t,
				n: r
			});
		}
	}
	if (e.placeQueue = R(e).filter((t) => e.pigs[t].some((e) => e.field === -1)), e.placeQueue.length > 0) {
		e.phase = "place";
		return;
	}
	(e.round + 1) % 4 == 0 ? J(e) : le(e);
}
function Y(e) {
	let t = R(e);
	for (; e.actIdx < t.length;) {
		let n = t[e.actIdx];
		if ((e.alloc[n] ?? 0) > 0) {
			e.remaining = e.alloc[n];
			return;
		}
		e.actIdx += 1;
	}
	ue(e);
}
function de(e) {
	if (H(e, R(e)[e.setupTurn]), e.setupTurn += 1, e.setupLeft = 5, e.setupTurn >= e.players.length) {
		e.phase = "choose";
		let t = L(e);
		t && z(e, "log.round", {
			n: 1,
			cardKey: I[t.id]
		});
	}
}
function X(e) {
	return e.phase === "setup" ? R(e)[e.setupTurn] ?? null : e.phase === "act" ? R(e)[e.actIdx] ?? null : e.phase === "place" ? e.placeQueue[0] ?? null : null;
}
function fe(e, t, n) {
	let r = e.players.includes(n.by) ? n.by : null;
	if (!r) return { code: "games.happypigs.errNotYourTurn" };
	if (t.type === "vaccinate") {
		let n = structuredClone(e), i = n.phase === "setup" && X(n) === r || n.phase === "act" && X(n) === r, a = n.phase === "seasonChange" && !n.scSubmitted.includes(r);
		if (!i && !a) return { code: "games.happypigs.errNotYourTurn" };
		let o = [...new Set(t.pigIds)];
		if (o.length > n.items[r].vaccine) return { code: "games.happypigs.errNoItem" };
		for (let e of o) {
			let t = n.pigs[r].find((t) => t.id === e && t.field >= 0);
			if (!t) return { code: "games.happypigs.errBadPig" };
			if (t.vac) return { code: "games.happypigs.errAlreadyVac" };
		}
		for (let e of o) {
			let t = n.pigs[r].find((t) => t.id === e);
			t.vac = !0;
		}
		return n.items[r].vaccine -= o.length, n.supply.vaccine += o.length, o.length > 0 && z(n, "log.vaccine", {
			who: r,
			n: o.length
		}), a && (n.scSubmitted.push(r), n.scSubmitted.length === n.players.length && q(n)), {
			state: n,
			fx: []
		};
	}
	if (t.type === "placePig" || t.type === "discardPig" || t.type === "repack" || t.type === "donePlace") {
		if (X(e) !== r || e.phase === "seasonChange" || e.phase === "choose" || e.phase === "done") return { code: "games.happypigs.errNotYourTurn" };
		let n = structuredClone(e);
		if (t.type === "repack") {
			let e = N(B(n, r), n.fields[r]);
			if (!e) return { code: "games.happypigs.errNoFit" };
			let t = new Map(e.map((e) => [e.id, e]));
			return n.pigs[r] = n.pigs[r].map((e) => t.get(e.id) ?? e), {
				state: n,
				fx: []
			};
		}
		if (t.type === "donePlace") return n.phase === "place" ? (H(n, r), n.placeQueue = n.placeQueue.filter((e) => e !== r), n.placeQueue.length === 0 && ((n.round + 1) % 4 == 0 ? J(n) : le(n)), {
			state: n,
			fx: []
		}) : { code: "games.happypigs.errNotYourTurn" };
		let i = n.pigs[r].find((e) => e.id === t.pigId && e.field === -1);
		return i ? t.type === "discardPig" ? (n.pigs[r] = n.pigs[r].filter((e) => e.id !== i.id), V(n, i), z(n, "log.discardPig", {
			who: r,
			whatKey: P[i.size]
		}), {
			state: n,
			fx: []
		}) : A(B(n, r), n.fields[r], t.field, t.x, t.y, i.size, t.rot) ? (Object.assign(i, {
			field: t.field,
			x: t.x,
			y: t.y,
			rot: t.rot
		}), {
			state: n,
			fx: []
		}) : { code: "games.happypigs.errNoFit" } : { code: "games.happypigs.errBadPig" };
	}
	if (t.type === "choose") {
		if (e.phase !== "choose" || r in e.chosen) return { code: "games.happypigs.errNotYourTurn" };
		let n = structuredClone(e);
		if (n.chosen[r] = t.action, Object.keys(n.chosen).length < n.players.length) return {
			state: n,
			fx: []
		};
		n.revealed = !0;
		let i = R(n), a = L(n), o = {};
		for (let e of i) o[e] = 0;
		return te.forEach((e, t) => {
			let r = i.filter((t) => n.chosen[t] === e), s = a.caps[t];
			for (let e = 0; e < s && r.length > 0; e += 1) o[r[e % r.length]] += 1;
		}), n.alloc = o, n.phase = "act", n.actIdx = 0, z(n, "log.reveal"), Y(n), {
			state: n,
			fx: []
		};
	}
	if (t.type === "stop") {
		if (X(e) !== r || e.phase !== "setup" && e.phase !== "act") return { code: "games.happypigs.errNotYourTurn" };
		let t = structuredClone(e);
		return t.phase === "setup" ? (de(t), {
			state: t,
			fx: []
		}) : (t.remaining > 0 && (t.money[r] += t.remaining, z(t, "log.stop", {
			who: r,
			n: t.remaining
		})), H(t, r), t.actIdx += 1, Y(t), {
			state: t,
			fx: []
		});
	}
	if (t.type === "buy") {
		let n = X(e), i = e.phase === "setup" && n === r, a = e.phase === "act" && n === r && e.chosen[r] === "buy" && e.remaining > 0;
		if (!i && !a || i && e.setupLeft <= 0) return { code: "games.happypigs.errNotYourTurn" };
		let o = structuredClone(e), s = L(o);
		if (t.buy.kind === "pig") {
			let e = t.buy.size, n = S(e, s);
			if (o.supply.pigs[e] <= 0) return { code: "games.happypigs.errSoldOut" };
			if (o.money[r] < n) return { code: "games.happypigs.errNoMoney" };
			if (!j(B(o, r), o.fields[r], e)) return { code: "games.happypigs.errNoFit" };
			o.money[r] -= n, G(o, r, e), z(o, "log.buy", {
				who: r,
				whatKey: P[e],
				n
			});
		} else if (t.buy.kind === "item") {
			let e = t.buy.item;
			if (o.supply[e] <= 0) return { code: "games.happypigs.errSoldOut" };
			if (o.money[r] < 1) return { code: "games.happypigs.errNoMoney" };
			--o.money[r], --o.supply[e], o.items[r][e] += 1, s?.effect === "liquidation" && o.supply[e] > 0 && (--o.supply[e], o.items[r][e] += 1), z(o, "log.buy", {
				who: r,
				whatKey: F[e],
				n: 1
			});
		} else {
			let e = ne(o.fields[r], s);
			if (o.supply.fields <= 0) return { code: "games.happypigs.errSoldOut" };
			if (o.money[r] < e) return { code: "games.happypigs.errNoMoney" };
			o.money[r] -= e, o.fields[r] += 1, --o.supply.fields, z(o, "log.buy", {
				who: r,
				whatKey: "games.happypigs.fieldName",
				n: e
			});
		}
		return o.phase === "setup" ? (--o.setupLeft, o.setupLeft <= 0 && de(o)) : (--o.remaining, o.remaining <= 0 && (H(o, r), o.actIdx += 1, Y(o))), {
			state: o,
			fx: []
		};
	}
	let i = X(e);
	if (e.phase !== "act" || i !== r || e.remaining <= 0) return { code: "games.happypigs.errNotYourTurn" };
	let a = structuredClone(e), o = L(a), s = a.used[r];
	if (t.type === "feed") {
		if (a.chosen[r] !== "feed") return { code: "games.happypigs.errNotYourTurn" };
		let e = a.pigs[r].find((e) => e.id === t.pigId && e.field >= 0);
		if (!e || e.size >= 3) return { code: "games.happypigs.errBadPig" };
		if (s.fed.includes(e.id)) return { code: "games.happypigs.errFedAlready" };
		let n = t.supplement === !0;
		if (n && (e.size >= 2 || a.items[r].supp <= 0)) return { code: "games.happypigs.errNoItem" };
		let i = n ? 2 : 1;
		for (let t = 1; t <= i; t += 1) if (a.supply.pigs[e.size + t] <= 0) return { code: "games.happypigs.errSoldOut" };
		let o = e.size + i;
		if (!ce(a, r, e, o)) return { code: "games.happypigs.errNoFit" };
		let c = a.pigs[r].find((t) => t.id === e.id);
		a.supply.pigs[e.size] += 1, c.size = o, --a.supply.pigs[o], n && (--a.items[r].supp, a.supply.supp += 1), s.fed.push(e.id), z(a, "log.feed", {
			who: r,
			whatKey: P[e.size]
		});
	} else if (t.type === "mate") {
		if (a.chosen[r] !== "mate") return { code: "games.happypigs.errNotYourTurn" };
		let e = a.pigs[r].find((e) => e.id === t.pigId && e.field >= 0);
		if (!e || e.size < 2) return { code: "games.happypigs.errBadPig" };
		if (s.mated.includes(e.id)) return { code: "games.happypigs.errMatedAlready" };
		let n = t.amulet === !0;
		if (n && a.items[r].amulet <= 0) return { code: "games.happypigs.errNoItem" };
		let i = +!!n;
		if (a.supply.pigs[i] <= 0) return { code: "games.happypigs.errSoldOut" };
		s.mated.push(e.id), n && (--a.items[r].amulet, a.supply.amulet += 1), G(a, r, i), z(a, "log.mate", {
			who: r,
			whatKey: P[i]
		});
	} else if (t.type === "sell") {
		if (a.chosen[r] !== "sell") return { code: "games.happypigs.errNotYourTurn" };
		let e = a.pigs[r].find((e) => e.id === t.pigId && e.field >= 0);
		if (!e) return { code: "games.happypigs.errBadPig" };
		let n = S(e.size, o);
		a.money[r] += n, a.pigs[r] = a.pigs[r].filter((t) => t.id !== e.id), V(a, e), z(a, "log.sell", {
			who: r,
			whatKey: P[e.size],
			n
		});
	} else return { code: "games.happypigs.errNotYourTurn" };
	return --a.remaining, a.remaining <= 0 && (H(a, r), a.actIdx += 1, Y(a)), {
		state: a,
		fx: []
	};
}
function pe(e, t) {
	let n = L(e);
	return {
		public: {
			phase: e.phase,
			round: e.round,
			season: Math.min(3, Math.floor(e.round / 4)),
			first: e.players[e.first],
			card: n ? {
				id: n.id,
				season: n.season,
				caps: [...n.caps],
				effect: n.effect
			} : null,
			players: e.players.map((t) => ({
				rid: t,
				money: e.money[t],
				fields: e.fields[t],
				items: { ...e.items[t] },
				pigs: e.pigs[t].map((e) => ({ ...e })),
				fed: [...e.used[t].fed],
				mated: [...e.used[t].mated]
			})),
			chosenBy: e.revealed ? [] : Object.keys(e.chosen),
			chosen: e.revealed ? { ...e.chosen } : null,
			alloc: e.revealed ? { ...e.alloc } : null,
			actTurn: e.phase === "act" ? X(e) : null,
			remaining: e.remaining,
			setupTurn: e.phase === "setup" ? X(e) : null,
			setupLeft: e.setupLeft,
			placeTurn: e.phase === "place" ? X(e) : null,
			scPending: e.phase === "seasonChange" ? e.players.filter((t) => !e.scSubmitted.includes(t)) : [],
			supply: {
				pigs: [...e.supply.pigs],
				vaccine: e.supply.vaccine,
				supp: e.supply.supp,
				amulet: e.supply.amulet,
				fields: e.supply.fields
			},
			log: e.log.slice(-60)
		},
		private: { myChoice: e.chosen[t] ?? null }
	};
}
function me(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = (t) => {
		let n = e.items[t];
		return n.vaccine + n.supp + n.amulet + x(e.fields[t]);
	}, n = (n) => e.money[n] * 1e5 + t(n), r = [...e.players].sort((e, t) => n(t) - n(e)), i = n(r[0]);
	return {
		phase: "done",
		winner: r.filter((e) => n(e) === i),
		ranking: r,
		scores: { ...e.money }
	};
}
var he = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: re,
	schemas: {
		action: T,
		publicView: O,
		privateView: oe
	},
	setup: K,
	reduce: fe,
	viewFor: pe,
	status: me
};
//#endregion
//#region src/games/happypigs/glyph.tsx
function Z({ kind: e, size: t = 24 }) {
	let n = {
		width: t,
		height: t,
		viewBox: "0 0 32 32",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: 2.7,
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": !0
	};
	return e === "feed" ? /* @__PURE__ */ m("svg", {
		...n,
		children: [
			/* @__PURE__ */ p("path", { d: "M5 16h22l-3 10H8L5 16Z" }),
			/* @__PURE__ */ p("path", { d: "M10 12c0-2 2-3 2-5M17 12c0-2 2-3 2-5M24 12c0-2 2-3 2-5" }),
			/* @__PURE__ */ p("path", { d: "M9 21h14" })
		]
	}) : e === "buy" ? /* @__PURE__ */ m("svg", {
		...n,
		children: [
			/* @__PURE__ */ p("path", { d: "M5 7h13l10 9-10 9H5V7Z" }),
			/* @__PURE__ */ p("circle", {
				cx: "11",
				cy: "16",
				r: "2"
			}),
			/* @__PURE__ */ p("path", { d: "M18 13h5M18 19h5" })
		]
	}) : e === "mate" ? /* @__PURE__ */ m("svg", {
		...n,
		children: [/* @__PURE__ */ p("path", { d: "M16 27 5 16C-1 9 8 1 16 9c8-8 17 0 11 7L16 27Z" }), /* @__PURE__ */ p("path", { d: "m11 16 3 3 7-7" })]
	}) : e === "sell" || e === "money" ? /* @__PURE__ */ m("svg", {
		...n,
		children: [/* @__PURE__ */ p("circle", {
			cx: "16",
			cy: "16",
			r: "12"
		}), /* @__PURE__ */ p("path", { d: "M20 10h-6a3 3 0 0 0 0 6h4a3 3 0 0 1 0 6h-7M16 7v18" })]
	}) : e === "vaccine" ? /* @__PURE__ */ m("svg", {
		...n,
		children: [/* @__PURE__ */ p("path", { d: "M13 4h6M16 4v5M11 9h10v17H11V9Z" }), /* @__PURE__ */ p("path", { d: "M16 13v9M12 17h8M13 26v3h6v-3" })]
	}) : e === "supp" ? /* @__PURE__ */ p("svg", {
		...n,
		children: /* @__PURE__ */ p("path", { d: "M16 27V8M16 19C8 20 5 15 6 8c6 0 10 4 10 11ZM16 16c0-7 4-11 10-11 1 7-2 12-10 11Z" })
	}) : e === "amulet" ? /* @__PURE__ */ m("svg", {
		...n,
		children: [/* @__PURE__ */ p("path", { d: "m16 3 11 12-11 14L5 15 16 3Z" }), /* @__PURE__ */ p("path", { d: "m16 10 4 5-4 6-4-6 4-5Z" })]
	}) : e === "field" ? /* @__PURE__ */ m("svg", {
		...n,
		children: [/* @__PURE__ */ p("path", { d: "M4 12 16 5l12 7v15H4V12Z" }), /* @__PURE__ */ p("path", { d: "M10 27V16h12v11M4 12h24M16 16v11" })]
	}) : /* @__PURE__ */ m("svg", {
		...n,
		children: [/* @__PURE__ */ p("path", { d: "M25 11a11 11 0 1 0 1 10" }), /* @__PURE__ */ p("path", { d: "M25 4v7h-7" })]
	});
}
//#endregion
//#region src/games/happypigs/view-player.tsx
function ge(e) {
	return /* @__PURE__ */ p(De, {
		pub: e.public,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var _e = [
	"games.happypigs.pig0",
	"games.happypigs.pig1",
	"games.happypigs.pig2",
	"games.happypigs.pig3"
], ve = {
	feed: "games.happypigs.actFeed",
	buy: "games.happypigs.actBuy",
	mate: "games.happypigs.actMate",
	sell: "games.happypigs.actSell"
}, ye = {
	vaccine: "games.happypigs.itemVaccine",
	supp: "games.happypigs.itemSupp",
	amulet: "games.happypigs.itemAmulet"
}, be = [
	"vaccine",
	"supp",
	"amulet"
], xe = [
	"games.happypigs.card0",
	"games.happypigs.card1",
	"games.happypigs.card2",
	"games.happypigs.card3",
	"games.happypigs.card4",
	"games.happypigs.card5",
	"games.happypigs.card6",
	"games.happypigs.card7",
	"games.happypigs.card8",
	"games.happypigs.card9",
	"games.happypigs.card10",
	"games.happypigs.card11",
	"games.happypigs.card12",
	"games.happypigs.card13",
	"games.happypigs.card14",
	"games.happypigs.card15",
	"games.happypigs.card16",
	"games.happypigs.card17",
	"games.happypigs.card18",
	"games.happypigs.card19",
	"games.happypigs.card20",
	"games.happypigs.card21",
	"games.happypigs.card22",
	"games.happypigs.card23"
], Se = {
	none: "games.happypigs.effectNone",
	fieldSale: "games.happypigs.effectFieldSale",
	seasonOfLove: "games.happypigs.effectSeasonOfLove",
	vaccination: "games.happypigs.effectVaccination",
	sanitary: "games.happypigs.effectSanitary",
	familyDay: "games.happypigs.effectFamilyDay",
	govAid: "games.happypigs.effectGovAid",
	liquidation: "games.happypigs.effectLiquidation",
	pigFair: "games.happypigs.effectPigFair",
	baconFest: "games.happypigs.effectBaconFest",
	hamFest: "games.happypigs.effectHamFest"
}, Ce = {
	"log.round": "games.happypigs.logRound",
	"log.buy": "games.happypigs.logBuy",
	"log.feed": "games.happypigs.logFeed",
	"log.mate": "games.happypigs.logMate",
	"log.sell": "games.happypigs.logSell",
	"log.stop": "games.happypigs.logStop",
	"log.vaccine": "games.happypigs.logVaccine",
	"log.discardPig": "games.happypigs.logDiscardPig",
	"log.deaths": "games.happypigs.logDeaths",
	"log.finalSale": "games.happypigs.logFinalSale",
	"log.reveal": "games.happypigs.logReveal",
	"log.effectMoney": "games.happypigs.logEffectMoney",
	"log.effectItems": "games.happypigs.logEffectItems",
	"log.effectPiglets": "games.happypigs.logEffectPiglets"
}, we = [
	"hp-pig-0",
	"hp-pig-1",
	"hp-pig-2",
	"hp-pig-3"
], Te = [
	"games/happypigs/piglet.webp",
	"games/happypigs/small-pig.webp",
	"games/happypigs/medium-pig.webp",
	"games/happypigs/large-pig.webp"
], Ee = [
	"games.happypigs.season0",
	"games.happypigs.season1",
	"games.happypigs.season2",
	"games.happypigs.season3"
];
function De({ pub: e, priv: t, members: a, myRid: o, send: h }) {
	let g = s(), y = e.players.find((e) => e.rid === o), b = y?.money, [x, ee] = i(o), C = e.players.find((e) => e.rid === x) ?? y, [ie, w] = i(0), T = `${e.phase}|${e.round}|${e.actTurn}|${e.setupTurn}|${e.placeTurn}`, [E, ae] = i({
		key: T,
		pig: null,
		rot: !1,
		supp: !1,
		amulet: !1,
		vac: [],
		spot: null,
		vacMode: !1
	}), D = E.key === T ? E : {
		key: T,
		pig: null,
		rot: !1,
		supp: !1,
		amulet: !1,
		vac: [],
		spot: null,
		vacMode: !1
	}, O = (e) => ae({
		...D,
		...e,
		key: T
	}), [oe, se] = i(!1), k = r(b);
	n(() => {
		if (b !== void 0 && k.current !== void 0 && b !== k.current) {
			se(!0);
			let e = window.setTimeout(() => se(!1), 420);
			return k.current = b, () => window.clearTimeout(e);
		}
		k.current = b;
	}, [b]);
	let j = (e) => a.find((t) => t.rid === e)?.name ?? e;
	if (!y || !C) return null;
	let M = e.card, N = M, P = y.pigs.filter((e) => e.field === -1), F = e.phase === "setup" && e.setupTurn === o, I = e.phase === "act" && e.actTurn === o && e.remaining > 0, L = e.phase === "place" && e.placeTurn === o, R = e.phase === "seasonChange" && e.scPending.includes(o), z = e.chosen?.[o] ?? null, B = R || D.vacMode && (F || I) ? "vaccinate" : I && z && z !== "buy" ? z : null, V = L || (F || I) && P.length > 0 ? P.find((e) => e.id === D.pig) ?? P[0] ?? null : null, H = Math.min(ie, C.fields - 1), ce = F || I || L || R || e.phase === "choose" && t?.myChoice == null, U = e.phase === "setup" ? F ? {
		tone: "accent",
		text: g("games.happypigs.phaseSetup"),
		sub: g("games.happypigs.setupPrompt", { n: e.setupLeft })
	} : {
		tone: "info",
		text: g("games.happypigs.phaseSetup"),
		sub: g("games.happypigs.setupWaiting", { name: j(e.setupTurn ?? "") })
	} : e.phase === "choose" ? t?.myChoice == null ? {
		tone: "accent",
		text: g("games.happypigs.phaseChoose"),
		sub: g("games.happypigs.choosePrompt")
	} : {
		tone: "info",
		text: g("games.happypigs.phaseChoose"),
		sub: g("games.happypigs.chooseWaiting")
	} : e.phase === "act" ? I && z ? {
		tone: "accent",
		text: g("games.happypigs.phaseAct"),
		sub: g({
			feed: "games.happypigs.actPromptFeed",
			buy: "games.happypigs.actPromptBuy",
			mate: "games.happypigs.actPromptMate",
			sell: "games.happypigs.actPromptSell"
		}[z], { n: e.remaining })
	} : {
		tone: "info",
		text: g("games.happypigs.phaseAct"),
		sub: g("games.happypigs.actWaiting", { name: j(e.actTurn ?? "") })
	} : e.phase === "place" ? L ? {
		tone: "accent",
		text: g("games.happypigs.phasePlace"),
		sub: g("games.happypigs.placePrompt")
	} : {
		tone: "info",
		text: g("games.happypigs.phasePlace"),
		sub: g("games.happypigs.placeWaiting", { name: j(e.placeTurn ?? "") })
	} : e.phase === "seasonChange" ? R ? {
		tone: "accent",
		text: g("games.happypigs.phaseSeasonChange"),
		sub: g("games.happypigs.scPrompt")
	} : {
		tone: "info",
		text: g("games.happypigs.phaseSeasonChange"),
		sub: g("games.happypigs.scWaiting", { name: j(e.scPending[0] ?? "") })
	} : {
		tone: "done",
		text: g("games.happypigs.overTitle")
	}, W = (e) => {
		if (!V || x !== o) return [];
		let t = y.pigs.filter((e) => e.field >= 0), n = [];
		for (let r = 0; r < 11; r += 1) for (let i = 0; i < 6; i += 1) A(t, y.fields, e, i, r, V.size, D.rot) && n.push({
			field: e,
			x: i,
			y: r
		});
		return n;
	}, G = W(H), K = D.spot && G.some((e) => e.x === D.spot?.x && e.y === D.spot?.y) ? D.spot : G[0] ?? null, le = (e, t) => {
		let n = W(e);
		if (!n.length || !V) return;
		let r = t.currentTarget.getBoundingClientRect(), i = t.clientX ? (t.clientX - r.left) / r.width * 6 : 0, a = t.clientY ? (t.clientY - r.top) / r.height * 11 : 0, [o, s] = _[V.size], c = D.rot ? s : o, l = D.rot ? o : s, u = n.reduce((e, t) => {
			let n = (t.x + c / 2 - i) ** 2 + (t.y + l / 2 - a) ** 2;
			return n < e.distance ? {
				spot: t,
				distance: n
			} : e;
		}, {
			spot: n[0],
			distance: Infinity
		}).spot;
		O({ spot: u });
	}, q = (F || I) && /* @__PURE__ */ p("button", {
		type: "button",
		className: "hp-plank-button",
		title: g("games.happypigs.stopHint"),
		onClick: () => h({ type: "stop" }),
		children: g("games.happypigs.stop")
	}), J = (F || I) && y.items.vaccine > 0 && /* @__PURE__ */ m("button", {
		type: "button",
		className: `hp-plank-button ${D.vacMode ? "hp-toggle-on" : ""}`,
		onClick: () => O({ vacMode: !D.vacMode }),
		children: [
			/* @__PURE__ */ p(Z, {
				kind: "vaccine",
				size: 17
			}),
			g("games.happypigs.itemVaccine"),
			" ×",
			y.items.vaccine
		]
	}), ue = (F || I && z === "buy") && /* @__PURE__ */ m("div", {
		className: "hp-buy-row scrollbar-none",
		"aria-label": g("games.happypigs.supplyPigs"),
		children: [
			v.map((t, n) => {
				let r = S(n, N), i = y.money < r || e.supply.pigs[n] <= 0;
				return /* @__PURE__ */ m("button", {
					type: "button",
					disabled: i,
					className: `hp-market-token ${we[n]}`,
					onClick: () => h({
						type: "buy",
						buy: {
							kind: "pig",
							size: n
						}
					}),
					children: [/* @__PURE__ */ p("img", {
						src: Te[n],
						alt: "",
						draggable: !1
					}), /* @__PURE__ */ m("span", {
						className: "hp-market-copy",
						children: [/* @__PURE__ */ p("strong", { children: g(_e[n]) }), /* @__PURE__ */ m("span", { children: [
							"$",
							r,
							" · ",
							e.supply.pigs[n]
						] })]
					})]
				}, n);
			}),
			be.map((t) => /* @__PURE__ */ m("button", {
				type: "button",
				disabled: y.money < 1 || e.supply[t] <= 0,
				className: `hp-market-token hp-item-${t}`,
				onClick: () => h({
					type: "buy",
					buy: {
						kind: "item",
						item: t
					}
				}),
				children: [/* @__PURE__ */ p(Z, {
					kind: t,
					size: 26
				}), /* @__PURE__ */ m("span", {
					className: "hp-market-copy",
					children: [/* @__PURE__ */ p("strong", { children: g(ye[t]) }), /* @__PURE__ */ m("span", { children: ["$1 · ", e.supply[t]] })]
				})]
			}, t)),
			/* @__PURE__ */ m("button", {
				type: "button",
				disabled: y.money < ne(y.fields, N) || e.supply.fields <= 0,
				className: "hp-market-token hp-item-field",
				onClick: () => h({
					type: "buy",
					buy: { kind: "field" }
				}),
				children: [/* @__PURE__ */ p(Z, {
					kind: "field",
					size: 26
				}), /* @__PURE__ */ m("span", {
					className: "hp-market-copy",
					children: [/* @__PURE__ */ p("strong", { children: g("games.happypigs.fieldName") }), /* @__PURE__ */ m("span", { children: [
						"$",
						ne(y.fields, N),
						" · ",
						e.supply.fields
					] })]
				})]
			})
		]
	}), Y = null;
	V ? Y = /* @__PURE__ */ m("div", {
		className: "hp-placement-tray",
		children: [
			/* @__PURE__ */ p("div", {
				className: "hp-tray-title",
				children: g("games.happypigs.pendingPig")
			}),
			/* @__PURE__ */ m("div", {
				className: "hp-placement-top",
				children: [
					/* @__PURE__ */ p("div", {
						className: "hp-pending scrollbar-none",
						children: P.map((e) => /* @__PURE__ */ p("button", {
							type: "button",
							"aria-label": g(_e[e.size]),
							"aria-pressed": V.id === e.id,
							className: `hp-pending-pig ${we[e.size]} ${V.id === e.id ? "hp-pig-picked" : ""}`,
							onClick: () => O({
								pig: e.id,
								spot: null
							}),
							children: /* @__PURE__ */ p("img", {
								src: Te[e.size],
								alt: "",
								draggable: !1
							})
						}, e.id))
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						className: "hp-plank-button hp-rotate",
						onClick: () => O({
							rot: !D.rot,
							spot: null
						}),
						children: [/* @__PURE__ */ p(Z, {
							kind: "rotate",
							size: 20
						}), g("games.happypigs.rotate")]
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						disabled: !K,
						className: "hp-plank-button hp-primary",
						onClick: () => {
							K && (h({
								type: "placePig",
								pigId: V.id,
								...K,
								rot: D.rot
							}), O({
								pig: null,
								spot: null
							}));
						},
						children: g("games.happypigs.placeHere")
					})
				]
			}),
			/* @__PURE__ */ m("div", {
				className: "hp-tray-tools scrollbar-none",
				children: [
					/* @__PURE__ */ p("button", {
						type: "button",
						className: "hp-plank-button",
						onClick: () => h({ type: "repack" }),
						children: g("games.happypigs.repack")
					}),
					/* @__PURE__ */ p("button", {
						type: "button",
						className: "hp-plank-button",
						onClick: () => h({
							type: "discardPig",
							pigId: V.id
						}),
						children: g("games.happypigs.discardPig")
					}),
					L && /* @__PURE__ */ p("button", {
						type: "button",
						className: "hp-plank-button",
						onClick: () => h({ type: "donePlace" }),
						children: g("games.happypigs.donePlace")
					}),
					!L && q
				]
			})
		]
	}) : e.phase === "choose" && t?.myChoice == null ? Y = /* @__PURE__ */ p("div", {
		className: "hp-choose-grid",
		children: te.map((e, t) => /* @__PURE__ */ m("button", {
			type: "button",
			className: `hp-action-token hp-kind-${e}`,
			onClick: () => h({
				type: "choose",
				action: e
			}),
			children: [
				/* @__PURE__ */ p(Z, {
					kind: e,
					size: 27
				}),
				/* @__PURE__ */ p("span", { children: g(ve[e]) }),
				M && /* @__PURE__ */ m("small", { children: ["×", M.caps[t]] })
			]
		}, e))
	}) : I && z === "feed" ? Y = /* @__PURE__ */ m("div", {
		className: "hp-act-row",
		children: [
			y.items.supp > 0 && /* @__PURE__ */ m("button", {
				type: "button",
				className: `hp-plank-button ${D.supp ? "hp-toggle-on" : ""}`,
				onClick: () => O({ supp: !D.supp }),
				children: [
					/* @__PURE__ */ p(Z, {
						kind: "supp",
						size: 17
					}),
					g("games.happypigs.itemSupp"),
					" ×",
					y.items.supp
				]
			}),
			J,
			q
		]
	}) : I && z === "mate" ? Y = /* @__PURE__ */ m("div", {
		className: "hp-act-row",
		children: [
			y.items.amulet > 0 && /* @__PURE__ */ m("button", {
				type: "button",
				className: `hp-plank-button ${D.amulet ? "hp-toggle-on" : ""}`,
				onClick: () => O({ amulet: !D.amulet }),
				children: [
					/* @__PURE__ */ p(Z, {
						kind: "amulet",
						size: 17
					}),
					g("games.happypigs.itemAmulet"),
					" ×",
					y.items.amulet
				]
			}),
			J,
			q
		]
	}) : I && z === "sell" ? Y = /* @__PURE__ */ m("div", {
		className: "hp-act-row",
		children: [J, q]
	}) : ue ? Y = /* @__PURE__ */ m("div", {
		className: "hp-act-col",
		children: [ue, /* @__PURE__ */ m("div", {
			className: "hp-act-row",
			children: [J, q]
		})]
	}) : L ? Y = /* @__PURE__ */ m("div", {
		className: "hp-act-row",
		children: [/* @__PURE__ */ p("button", {
			type: "button",
			className: "hp-plank-button",
			onClick: () => h({ type: "repack" }),
			children: g("games.happypigs.repack")
		}), /* @__PURE__ */ p("button", {
			type: "button",
			className: "hp-plank-button hp-primary",
			onClick: () => h({ type: "donePlace" }),
			children: g("games.happypigs.donePlace")
		})]
	}) : R ? Y = /* @__PURE__ */ p("div", {
		className: "hp-act-row",
		children: /* @__PURE__ */ m("button", {
			type: "button",
			className: "hp-plank-button hp-primary",
			onClick: () => h({
				type: "vaccinate",
				pigIds: D.vac
			}),
			children: [
				g("games.happypigs.scSubmit"),
				"(",
				D.vac.length,
				"/",
				y.items.vaccine,
				")"
			]
		})
	}) : e.phase === "choose" && t?.myChoice != null && (Y = /* @__PURE__ */ m("div", {
		className: "hp-wait-token",
		children: [/* @__PURE__ */ p(Z, {
			kind: t.myChoice,
			size: 30
		}), /* @__PURE__ */ p("span", { children: g(ve[t.myChoice]) })]
	})), Y ||= /* @__PURE__ */ m("div", {
		className: "hp-wait-token",
		children: [/* @__PURE__ */ p("span", {
			className: "hp-wait-seal",
			children: "···"
		}), /* @__PURE__ */ p("span", { children: U.sub ?? U.text })]
	});
	let de = (e) => x !== o || !B || V ? !1 : B === "vaccinate" ? !e.vac && (!R || D.vac.includes(e.id) || D.vac.length < y.items.vaccine) : B === "feed" ? e.size < 3 && !y.fed.includes(e.id) : B !== "mate" || e.size >= 2 && !y.mated.includes(e.id), X = (e) => {
		if (!(x !== o || V)) {
			if (B === "vaccinate") {
				if (!de(e)) return;
				R ? O({ vac: D.vac.includes(e.id) ? D.vac.filter((t) => t !== e.id) : [...D.vac, e.id] }) : (h({
					type: "vaccinate",
					pigIds: [e.id]
				}), O({ vacMode: !1 }));
				return;
			}
			if (B === "feed") {
				if (e.size >= 3 || y.fed.includes(e.id)) return;
				h({
					type: "feed",
					pigId: e.id,
					supplement: D.supp && e.size < 2
				});
				return;
			}
			if (B === "mate") {
				if (e.size < 2 || y.mated.includes(e.id)) return;
				h({
					type: "mate",
					pigId: e.id,
					amulet: D.amulet
				});
				return;
			}
			B === "sell" && h({
				type: "sell",
				pigId: e.id
			});
		}
	}, fe = /* @__PURE__ */ m("div", {
		className: `hp-field ${V ? "hp-field-placing" : ""}`,
		style: { backgroundImage: "url('games/happypigs/field-board.webp')" },
		children: [/* @__PURE__ */ m("div", {
			className: "hp-field-grid",
			children: [C.pigs.filter((e) => e.field === H).map((e) => {
				let [t, n] = _[e.size], r = e.rot ? n : t, i = e.rot ? t : n, a = de(e), s = B === "vaccinate" && D.vac.includes(e.id), c = x === o && y.fed.includes(e.id), l = x === o && y.mated.includes(e.id);
				return /* @__PURE__ */ m("button", {
					type: "button",
					disabled: !a,
					"aria-label": `${g(_e[e.size])}${e.vac ? `, ${g("games.happypigs.vaccinatedTag")}` : ""}`,
					className: `hp-pig ${we[e.size]} ${a ? "hp-pig-eligible" : ""} ${e.vac ? "hp-pig-vac" : ""} ${s ? "hp-pig-picked" : ""}`,
					style: {
						left: `${e.x / 6 * 100}%`,
						top: `${e.y / 11 * 100}%`,
						width: `${r / 6 * 100}%`,
						height: `${i / 11 * 100}%`
					},
					onClick: () => X(e),
					children: [
						/* @__PURE__ */ p("img", {
							src: Te[e.size],
							alt: "",
							draggable: !1
						}),
						e.vac && /* @__PURE__ */ p("span", {
							className: "hp-pig-badge hp-pig-badge-vac",
							children: /* @__PURE__ */ p(Z, {
								kind: "vaccine",
								size: 13
							})
						}),
						(c || l) && /* @__PURE__ */ p("span", {
							className: "hp-pig-badge hp-pig-badge-used",
							children: /* @__PURE__ */ p(Z, {
								kind: c ? "feed" : "mate",
								size: 13
							})
						})
					]
				}, e.id);
			}), V && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("button", {
				type: "button",
				className: "hp-place-surface",
				"aria-label": g("games.happypigs.placeHint"),
				disabled: !G.length,
				onClick: (e) => le(H, e)
			}), K && /* @__PURE__ */ p("span", {
				className: "hp-place-preview",
				style: {
					left: `${K.x / 6 * 100}%`,
					top: `${K.y / 11 * 100}%`,
					width: `${(D.rot ? _[V.size][1] : _[V.size][0]) / 6 * 100}%`,
					height: `${(D.rot ? _[V.size][0] : _[V.size][1]) / 11 * 100}%`
				},
				children: /* @__PURE__ */ p("img", {
					src: Te[V.size],
					alt: ""
				})
			})] })]
		}), /* @__PURE__ */ p("div", {
			className: "hp-field-plaque",
			children: g("games.happypigs.fieldTitle", { n: H + 1 })
		})]
	}), pe = (e) => {
		let t = Ce[e.k];
		if (!t) return e.k;
		let n = e.p ?? {}, r = {};
		return typeof n.who == "string" && (r.name = j(n.who)), typeof n.whatKey == "string" && (r.what = g(n.whatKey)), typeof n.cardKey == "string" && (r.card = g(n.cardKey)), typeof n.effectKey == "string" && (r.effect = g(n.effectKey)), typeof n.n == "number" && (r.n = n.n), g(t, r);
	}, me = /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ m("div", {
		className: `hp-season-card hp-season-${e.season}`,
		children: [/* @__PURE__ */ m("div", {
			className: "hp-season-copy",
			children: [
				/* @__PURE__ */ m("span", {
					className: "hp-season-eyebrow",
					children: [
						g(Ee[e.season]),
						" · ",
						g("games.happypigs.roundLabel", { n: e.round + 1 })
					]
				}),
				/* @__PURE__ */ p("strong", { children: g(M ? xe[M.id] : "games.happypigs.phaseSetup") }),
				/* @__PURE__ */ p("span", {
					className: "hp-season-effect",
					title: M ? g(Se[M.effect] ?? "games.happypigs.effectNone") : U.sub,
					children: M ? g(Se[M.effect] ?? "games.happypigs.effectNone") : U.sub
				})
			]
		}), /* @__PURE__ */ p("div", {
			className: "hp-season-caps",
			children: te.map((e, t) => /* @__PURE__ */ m("span", {
				className: `hp-season-cap hp-kind-${e}`,
				"aria-label": `${g(ve[e])} ${M?.caps[t] ?? "—"}`,
				children: [/* @__PURE__ */ p(Z, {
					kind: e,
					size: 16
				}), /* @__PURE__ */ p("b", { children: M?.caps[t] ?? "—" })]
			}, e))
		})]
	}, M?.id ?? "setup"), /* @__PURE__ */ m("div", {
		className: "hp-resources",
		children: [/* @__PURE__ */ m("div", {
			className: `hp-resource hp-resource-money ${oe && x === o ? "hp-money-pulse" : ""}`,
			children: [
				/* @__PURE__ */ p(Z, {
					kind: "money",
					size: 20
				}),
				/* @__PURE__ */ m("b", { children: ["$", C.money] }),
				/* @__PURE__ */ p("small", { children: g("games.happypigs.money") })
			]
		}), be.map((e) => /* @__PURE__ */ m("div", {
			className: `hp-resource hp-resource-${e}`,
			children: [
				/* @__PURE__ */ p(Z, {
					kind: e,
					size: 20
				}),
				/* @__PURE__ */ p("b", { children: C.items[e] }),
				/* @__PURE__ */ p("small", { children: g(ye[e]) })
			]
		}, e))]
	})] });
	return /* @__PURE__ */ p("div", {
		className: "hp-screen",
		style: { backgroundImage: "url('games/happypigs/farm-table.webp')" },
		children: /* @__PURE__ */ p(c, {
			adaptive: !0,
			className: "hp-layout",
			banner: /* @__PURE__ */ m("div", {
				className: "hp-banner",
				children: [/* @__PURE__ */ p(u, {
					tone: U.tone,
					accent: ce ? re.accent : void 0,
					text: U.text,
					sub: U.sub,
					chip: `${g(Ee[e.season])} ${g("games.happypigs.roundLabel", { n: e.round + 1 })}`
				}), /* @__PURE__ */ p("div", {
					className: "hp-player-shelf",
					children: /* @__PURE__ */ p(d, {
						members: a,
						myRid: o,
						variant: "mini",
						scroll: !0,
						adaptive: !0,
						onPick: (e) => {
							ee(e), w(0);
						},
						picked: (e) => e === x,
						action: (t) => e.phase === "choose" ? e.chosenBy.includes(t) || e.chosen ? "done" : "pending" : e.phase === "act" ? t === e.actTurn ? "pending" : null : e.phase === "seasonChange" ? e.scPending.includes(t) ? "pending" : "done" : null
					})
				})]
			}),
			actionsHeight: "hp-action-slot",
			actions: /* @__PURE__ */ m("div", {
				className: "hp-side-tray",
				children: [/* @__PURE__ */ p("div", {
					className: "hp-info-desktop",
					children: me
				}), /* @__PURE__ */ p("div", {
					className: "hp-actions",
					children: Y
				})]
			}),
			overlay: /* @__PURE__ */ p(l, {
				log: e.log,
				line: pe
			}),
			children: /* @__PURE__ */ m("div", {
				className: "hp-main",
				children: [
					/* @__PURE__ */ p("div", {
						className: "hp-info-mobile",
						children: me
					}),
					/* @__PURE__ */ p("div", {
						className: "hp-field-tabs scrollbar-none",
						"aria-label": g("games.happypigs.fieldName"),
						children: Array.from({ length: C.fields }, (e, t) => /* @__PURE__ */ p("button", {
							type: "button",
							"aria-label": g("games.happypigs.fieldTitle", { n: t + 1 }),
							"aria-pressed": t === H,
							className: t === H ? "hp-field-tab hp-field-tab-active" : "hp-field-tab",
							onClick: () => {
								w(t), O({ spot: null });
							},
							children: t + 1
						}, t))
					}),
					/* @__PURE__ */ p("div", {
						className: "hp-board-stage",
						children: fe
					})
				]
			})
		})
	});
}
//#endregion
//#region src/games/happypigs/bot.ts
function Q(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var Oe = (e) => e.filter((e) => e.field >= 0), $ = (e, t, n) => j(Oe(e), t, n) !== null, ke = [
	v[1] - v[0],
	v[2] - v[1],
	v[3] - v[2]
], Ae = (e, t) => {
	let n = e.public, r = n.players.find((e) => e.rid === t.rid);
	if (!r) return null;
	let i = t.difficulty === "weak", a = Oe(r.pigs), o = r.pigs.filter((e) => e.field === -1), s = n.round, c = s % 4 == 3, l = s >= 15;
	if (n.phase === "place") return n.placeTurn === t.rid ? { action: { type: "donePlace" } } : null;
	if (n.phase === "seasonChange") return n.scPending.includes(t.rid) ? { action: {
		type: "vaccinate",
		pigIds: a.filter((e) => !e.vac).sort((e, t) => v[t.size] - v[e.size]).slice(0, i ? Q([
			0,
			1,
			r.items.vaccine
		]) : r.items.vaccine).map((e) => e.id)
	} } : null;
	if (n.phase === "setup") {
		if (n.setupTurn !== t.rid) return null;
		if (o.length > 0) {
			let e = o[0], t = j(a, r.fields, e.size);
			return t ? { action: {
				type: "placePig",
				pigId: e.id,
				field: t.field,
				x: t.x,
				y: t.y,
				rot: t.rot
			} } : { action: {
				type: "discardPig",
				pigId: e.id
			} };
		}
		if (n.setupLeft <= 0) return { action: { type: "stop" } };
		if (i) {
			let e = [];
			for (let t = 0; t < 4; t += 1) r.money >= v[t] && n.supply.pigs[t] > 0 && $(r.pigs, r.fields, t) && e.push({
				type: "buy",
				buy: {
					kind: "pig",
					size: t
				}
			});
			return r.money >= 1 && n.supply.vaccine > 0 && e.push({
				type: "buy",
				buy: {
					kind: "item",
					item: "vaccine"
				}
			}), e.length === 0 || a.length >= 4 && Q([!0, !1]) ? { action: { type: "stop" } } : { action: Q(e) };
		}
		let e = (e) => a.filter((t) => t.size === e).length, s = e(2) === 0 ? [2, 1] : e(1) === 0 ? [1, 0] : [
			2,
			1,
			3,
			0
		];
		for (let e of s) if (r.money >= v[e] && n.supply.pigs[e] > 0 && $(r.pigs, r.fields, e)) return { action: {
			type: "buy",
			buy: {
				kind: "pig",
				size: e
			}
		} };
		let c = a.some((e) => !e.vac);
		return c && r.items.vaccine === 0 && r.money >= 1 && n.supply.vaccine > 0 ? { action: {
			type: "buy",
			buy: {
				kind: "item",
				item: "vaccine"
			}
		} } : !c && r.money >= v[0] && n.supply.pigs[0] > 0 && $(r.pigs, r.fields, 0) ? { action: {
			type: "buy",
			buy: {
				kind: "pig",
				size: 0
			}
		} } : { action: { type: "stop" } };
	}
	if (n.phase === "choose") {
		if (e.private?.myChoice != null) return null;
		if (i) return { action: {
			type: "choose",
			action: Q([
				"feed",
				"buy",
				"mate",
				"sell"
			])
		} };
		let t = n.card, o = a.filter((e) => e.size < 3), s = a.filter((e) => e.size >= 2), u = o.reduce((e, t) => e + ke[t.size], 0), d = s.length * 2 + (t?.effect === "seasonOfLove" ? s.length : 0), f = r.money >= v[3] ? 9 : r.money >= v[2] ? 7 : r.money >= v[1] ? 5 : r.money >= v[0] ? 3 : 0, p = 0;
		if (a.length > 0) {
			let e = Math.max(...a.map((e) => S(e.size, null))), n = t && (t.effect === "baconFest" || t.effect === "hamFest" || t.effect === "sanitary") ? 3 : 0;
			p = l || c && r.items.vaccine === 0 ? e + 2 : n > 0 ? Math.max(0, e - 12) + n : 0;
		}
		let m = [
			["feed", u],
			["buy", f],
			["mate", d],
			["sell", p]
		];
		return m.sort((e, t) => t[1] - e[1]), { action: {
			type: "choose",
			action: m[0][1] > 0 ? m[0][0] : "buy"
		} };
	}
	if (n.phase === "act") {
		if (n.actTurn !== t.rid || n.remaining <= 0) return null;
		let e = n.chosen?.[t.rid];
		if (!e) return { action: { type: "stop" } };
		let o = n.card;
		if (e === "feed") {
			let e = a.filter((e) => e.size < 3 && !r.fed.includes(e.id) && W(Oe(r.pigs), r.fields, e, e.size + 1));
			if (e.length === 0) return { action: { type: "stop" } };
			let t = i ? Q(e) : [...e].sort((e, t) => ke[t.size] - ke[e.size])[0], n = !i && r.items.supp > 0 && t.size === 1 && W(Oe(r.pigs), r.fields, t, 3);
			return { action: {
				type: "feed",
				pigId: t.id,
				supplement: n
			} };
		}
		if (e === "mate") {
			let e = a.filter((e) => e.size >= 2 && !r.mated.includes(e.id));
			return e.length === 0 ? { action: { type: "stop" } } : { action: {
				type: "mate",
				pigId: (i ? Q(e) : [...e].sort((e, t) => t.size - e.size)[0]).id,
				amulet: !i && r.items.amulet > 0
			} };
		}
		if (e === "sell") return a.length === 0 ? { action: { type: "stop" } } : { action: {
			type: "sell",
			pigId: (i ? Q(a) : [...a].sort((e, t) => S(t.size, null) - S(e.size, null))[0]).id
		} };
		let s = o;
		if (i) {
			let e = [];
			for (let t = 3; t >= 0; --t) if (r.money >= S(t, s) && n.supply.pigs[t] > 0 && $(r.pigs, r.fields, t)) {
				e.push({
					type: "buy",
					buy: {
						kind: "pig",
						size: t
					}
				});
				break;
			}
			return r.money >= 1 && n.supply.vaccine > 0 && e.push({
				type: "buy",
				buy: {
					kind: "item",
					item: "vaccine"
				}
			}), e.length === 0 ? { action: { type: "stop" } } : { action: Q(e) };
		}
		let l = a.filter((e) => !e.vac).length;
		if (c && l > r.items.vaccine && r.money >= 1 && n.supply.vaccine > 0) return { action: {
			type: "buy",
			buy: {
				kind: "item",
				item: "vaccine"
			}
		} };
		for (let e = 3; e >= 0; --e) {
			let t = S(e, s);
			if (r.money >= t && n.supply.pigs[e] > 0 && $(r.pigs, r.fields, e)) return { action: {
				type: "buy",
				buy: {
					kind: "pig",
					size: e
				}
			} };
		}
		let u = a.reduce((e, t) => e + (t.size === 0 ? 4 : t.size === 1 ? 6 : t.size === 2 ? 9 : 12), 0), d = r.fields * 66, f = ne(r.fields, null);
		return u * 2 > d && r.money >= f && n.supply.fields > 0 ? { action: {
			type: "buy",
			buy: { kind: "field" }
		} } : l > r.items.vaccine && r.money >= 1 && n.supply.vaccine > 0 ? { action: {
			type: "buy",
			buy: {
				kind: "item",
				item: "vaccine"
			}
		} } : { action: { type: "stop" } };
	}
	return null;
}, je = [
	"games/happypigs/piglet.webp",
	"games/happypigs/small-pig.webp",
	"games/happypigs/medium-pig.webp",
	"games/happypigs/large-pig.webp"
];
function Me({ result: e, members: t, myRid: n, onPlayAgain: r, onBackToLobby: i }) {
	let c = s(), l = o((e) => e.locale), u = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? h(e) === null ? n.name : a(l, n.avatar) : e;
	};
	return /* @__PURE__ */ p("div", {
		className: "hp-over",
		style: { backgroundImage: "url('games/happypigs/farm-table.webp')" },
		children: /* @__PURE__ */ m("div", {
			className: "hp-over-board",
			children: [
				/* @__PURE__ */ m("header", {
					className: "hp-over-heading",
					children: [
						/* @__PURE__ */ p("span", {
							className: "hp-over-eyebrow",
							children: "HAPPY PIGS · 4 SEASONS"
						}),
						/* @__PURE__ */ p("h1", { children: c("games.happypigs.overTitle") }),
						/* @__PURE__ */ p("p", { children: c("games.happypigs.overSubtitle") }),
						/* @__PURE__ */ p("div", {
							className: "hp-over-pigs",
							"aria-hidden": "true",
							children: je.map((e, t) => /* @__PURE__ */ p("span", {
								className: `hp-over-pig hp-over-pig-${t}`,
								children: /* @__PURE__ */ p("img", {
									src: e,
									alt: ""
								})
							}, e))
						})
					]
				}),
				/* @__PURE__ */ p("ol", {
					className: "hp-over-ranking",
					children: e.ranking.map((r, i) => {
						let a = t.find((e) => e.rid === r), o = e.winner.includes(r);
						return /* @__PURE__ */ m("li", {
							className: `hp-over-row ${o ? "hp-over-winner" : ""}`,
							children: [
								/* @__PURE__ */ p("span", {
									className: "hp-over-rank",
									"aria-hidden": "true",
									children: String(i + 1).padStart(2, "0")
								}),
								a && /* @__PURE__ */ p("img", {
									className: "hp-over-avatar",
									src: g[a.avatar % g.length],
									alt: ""
								}),
								/* @__PURE__ */ m("span", {
									className: "hp-over-name",
									children: [u(r), r === n && /* @__PURE__ */ p("small", { children: c("lobby.you") })]
								}),
								/* @__PURE__ */ m("span", {
									className: "hp-over-score",
									children: [/* @__PURE__ */ p(Z, {
										kind: "money",
										size: 19
									}), /* @__PURE__ */ m("b", { children: ["$", e.scores?.[r] ?? 0] })]
								}),
								o && /* @__PURE__ */ p("span", {
									className: "hp-over-crown",
									"aria-hidden": "true",
									children: "♛"
								})
							]
						}, r);
					})
				}),
				/* @__PURE__ */ m("footer", {
					className: "hp-over-actions",
					children: [
						r && /* @__PURE__ */ p("button", {
							type: "button",
							className: "hp-over-button hp-over-button-primary",
							onClick: r,
							children: c("session.result.playAgain")
						}),
						i && /* @__PURE__ */ p("button", {
							type: "button",
							className: "hp-over-button",
							onClick: i,
							children: c("session.result.backToLobby")
						}),
						!r && !i && /* @__PURE__ */ p("p", { children: c("session.result.waitHost") })
					]
				})
			]
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/happypigs/entry.tsx
var Ne = {
	definition: he,
	View: ge,
	bot: Ae,
	OverView: Me,
	locales: {
		zh: {
			name: "养猪趣",
			desc: "买猪、喂猪、配种,赶在换季瘟疫前把猪卖出好价钱",
			rules: "目标:一年(四季共 16 回合)结束时现金最多者获胜。\n准备:\n· 每人获得 1 块猪舍(6 列 11 行共 66 格)和 $45。\n· 从起始玩家开始,每人轮流进行开局采购,最多购买 5 件(猪、道具、猪舍任意组合),买到的猪立即放入猪舍。\n猪的购买价格与出售价格相同：\n· 每只猪仔的价格为 $3。\n· 每只小猪的价格为 $6。\n· 每只中猪的价格为 $10。\n· 每只大猪的价格为 $15。\n其他商品价格：\n· 每件道具的价格为 $1。\n· 第二块猪舍的价格为 $10，第三块为 $15，第四块为 $20；此后每多购买一块，价格增加 $5。\n回合流程:\n· 翻开本回合季节卡,卡上四个数字是本回合全体玩家共享的喂食、购买、交配、出售次数上限。\n· 每人秘密选择一种行动,同时揭示。\n· 选择同一行动的玩家平分该行动的次数:从起始玩家开始顺时针一次一次分发,分完为止。\n· 从起始玩家开始,每人依次执行自己的行动,次数用完为止;每有 1 次未执行,获得 $1 补偿。\n· 喂食:使 1 只猪长大一级,每只猪每回合只能喂食一次。\n· 交配:使 1 只中猪或大猪产下 1 只猪仔,每只猪每回合只能交配一次。\n· 购买：购买一件商品。\n· 出售：按当前市价出售 1 只猪。\n· 季节卡在回合末结算效果(改价类效果在回合内即时生效)。\n换季:\n· 每季第 4 回合结束后换季,所有未接种疫苗的猪死亡并退回市场;此时可以立即使用疫苗，使对应的猪免于死亡。\n· 冬季结束后再经历最后一次换季,存活的猪按基础市价全部卖出,结算现金。\n道具:\n· 疫苗 $1:随时可以使用,将 1 只猪的板块翻至已接种面;接种状态在猪长大后保留,直到卖出。\n· 营养剂 $1:执行喂食时使用,猪仔或小猪额外多长大一级。\n· 生产御守 $1:执行交配时使用,直接产下 1 只小猪。\n猪舍摆放:\n· 猪的占格:猪仔占 2 列 2 行、小猪占 2 列 3 行、中猪占 3 列 3 行、大猪占 3 列 4 行。\n· 猪可以旋转,猪之间不得重叠。\n· 新获得的猪若无法合法放入自己的任何猪舍，立即退回市场。\n平手:现金相同时,将剩余道具(每件 $1)和猪舍(按购入价)的价值计入现金后，再比较现金总额,再相同则共同获胜。",
			season0: "春",
			season1: "夏",
			season2: "秋",
			season3: "冬",
			pig0: "猪仔",
			pig1: "小猪",
			pig2: "中猪",
			pig3: "大猪",
			actFeed: "喂食",
			actBuy: "购买",
			actMate: "交配",
			actSell: "出售",
			itemVaccine: "疫苗",
			itemSupp: "营养剂",
			itemAmulet: "生产御守",
			fieldName: "猪舍",
			fieldTitle: "{{n}} 号猪舍",
			card0: "疫苗接种",
			card1: "发情期",
			card2: "风调雨顺",
			card3: "猪舍特卖",
			card4: "疫苗接种",
			card5: "发情期",
			card6: "卫生检查",
			card7: "发情期",
			card8: "卫生检查",
			card9: "发情期",
			card10: "家庭日",
			card11: "疫苗接种",
			card12: "政府援助",
			card13: "清仓拍卖",
			card14: "种猪展会",
			card15: "种猪展会",
			card16: "卫生检查",
			card17: "清仓拍卖",
			card18: "种猪展会",
			card19: "火腿节",
			card20: "培根节",
			card21: "家庭日",
			card22: "培根节",
			card23: "疫苗接种",
			effectNone: "无效果",
			effectFieldSale: "本回合猪舍价格减 $3",
			effectSeasonOfLove: "回合末每 2 只可生育猪产 1 只猪仔",
			effectVaccination: "小猪最多的玩家获得 3 个疫苗",
			effectSanitary: "本回合猪价 +$3(买与卖同价)",
			effectFamilyDay: "集齐四种体型的玩家各得 $25",
			effectGovAid: "猪仔最多的玩家获得 3 个营养剂",
			effectLiquidation: "本回合道具买一送一",
			effectPigFair: "大猪最多的玩家获得 $25",
			effectBaconFest: "本回合猪价 $6/$10/$15/$21",
			effectHamFest: "本回合猪价 $5/$9/$14/$20",
			phaseSetup: "开局采购",
			phaseChoose: "选择行动",
			phaseAct: "执行行动",
			phasePlace: "摆放新猪",
			phaseSeasonChange: "换季",
			roundLabel: "第 {{n}} 回合",
			setupPrompt: "还可以购买 {{n}} 件，买猪后点猪舍选落点",
			setupWaiting: "等 {{name}} 采购…",
			choosePrompt: "秘密选择本回合要执行的行动",
			chooseWaiting: "已选择,等其他玩家…",
			actPromptFeed: "点 1 只猪喂食(最多 {{n}} 次)",
			actPromptBuy: "购买商品(最多 {{n}} 次)",
			actPromptMate: "点 1 只中猪或大猪交配(最多 {{n}} 次)",
			actPromptSell: "点 1 只猪卖出(最多 {{n}} 次)",
			actWaiting: "等 {{name}} 行动…",
			stop: "提前结束",
			stopHint: "剩余次数每次补偿 $1",
			placePrompt: "点猪舍选择落点，再确认摆放；放不下将退回市场",
			placeHint: "在猪舍选择落点",
			placeHere: "确认摆放",
			placeWaiting: "等 {{name}} 摆放…",
			rotate: "旋转",
			repack: "一键整理",
			discardPig: "退回市场",
			donePlace: "完成摆放",
			scPrompt: "换季瘟疫:勾选要接种的猪,其余将死亡",
			scSubmit: "提交",
			scWaiting: "等 {{name}} 提交接种…",
			vaccinateAction: "接种疫苗",
			money: "现金",
			fieldsLabel: "猪舍 {{n}} 块",
			supplyPigs: "猪存量",
			supplyItems: "道具存量",
			buyPig: "买{{name}}(${{n}})",
			buyItem: "买{{name}}($1)",
			buyField: "买猪舍(${{n}})",
			capsFeed: "喂",
			capsBuy: "购",
			capsMate: "配",
			capsSell: "售",
			allocLabel: "分到 {{n}} 次",
			chosenLabel: "选了",
			pendingPig: "待摆放",
			vaccinatedTag: "已接种",
			overTitle: "年终结算",
			overSubtitle: "四季丰收，数数今年攒下的金币",
			logRound: "第 {{n}} 回合:{{card}}",
			logBuy: "{{name}} 购买{{what}}(${{n}})",
			logFeed: "{{name}} 喂食,养成{{what}}",
			logMate: "{{name}} 的猪产下{{what}}",
			logSell: "{{name}} 卖出{{what}},获得 ${{n}}",
			logStop: "{{name}} 提前结束,获得补偿 ${{n}}",
			logVaccine: "{{name}} 接种 {{n}} 只猪",
			logDiscardPig: "{{name}} 的{{what}}无处安放,退回市场",
			logDeaths: "{{name}} 有 {{n}} 只未接种的猪死亡",
			logFinalSale: "{{name}} 年终卖猪获得 ${{n}}",
			logReveal: "行动揭示",
			logEffectMoney: "{{name}} 获得 ${{n}}({{effect}})",
			logEffectItems: "{{name}} 获得 {{n}} 个{{what}}",
			logEffectPiglets: "{{name}} 获得 {{n}} 只猪仔",
			errNotYourTurn: "现在轮不到你",
			errNoItem: "对应道具数量不足",
			errBadPig: "这只猪不能作为目标",
			errAlreadyVac: "这只猪已经接种过了",
			errNoFit: "猪舍里放不下",
			errSoldOut: "市场已经售罄",
			errNoMoney: "现金不足",
			errFedAlready: "这只猪本回合已经喂过了",
			errMatedAlready: "这只猪本回合已经交配过了"
		},
		en: {
			name: "Happy Pigs",
			desc: "Buy, feed and breed pigs, and sell them before the seasonal plague hits",
			rules: "Goal: have the most cash at the end of the year (16 rounds over 4 seasons).\nSetup:\n· Each player gets 1 field board (6×11 grid) and $45.\n· Starting with the first player, each player takes a setup shopping turn, buying at most 5 items (pigs, items or fields in any combination). Pigs bought are placed in your field immediately.\nPurchase and sale prices are the same:\n· A Piglet costs $3.\n· A Small pig costs $6.\n· An Average pig costs $10.\n· A Big pig costs $15.\n· Items cost $1 each; fields cost $10 for the 2nd, $15 for the 3rd, $20 for the 4th, then +$5 each.\nRound flow:\n· Reveal the Season card. Its four numbers are the shared limits for Feed, Buy, Mate and Sell this round.\n· Everyone secretly picks one action, then all choices are revealed at once.\n· Players who picked the same action split its uses: dealt one at a time clockwise from the first player until exhausted.\n· Starting with the first player, each player performs their action up to their allotted count; each unused action pays $1 compensation.\n· Feed: grow one pig one size; each pig can be fed once per round.\n· Mate: one Average or Big pig births a Piglet; each pig can mate once per round.\n· Buy: purchase one item.\n· Sell: sell one pig at the current market price.\n· The Season card effect resolves at the end of the round (price-changing effects apply during the round).\nChange of season:\n· After the 4th round of each season, all unvaccinated pigs die and return to the market; Vaccines may be used immediately to save pigs.\n· After winter ends there is one last change of season, then surviving pigs are sold at base market price.\nItems:\n· Vaccine $1: usable at any time; flips one pig to its vaccinated side. Vaccination survives growth until the pig is sold.\n· Dietary Supplement $1: used while feeding; a Piglet or Small pig grows one extra size.\n· Amulet of Life $1: used while mating; the newborn is a Small pig instead of a Piglet.\nFields:\n· Pig sizes in grid cells: Piglet 2 by 2, Small 2 by 3, Average 3 by 3, Big 3 by 4.\n· Pigs may be rotated and must not overlap.\n· A pig that cannot fit at all returns to the market immediately.\nTies: sell leftover items ($1 each) and fields (at purchase price); players still tied share the victory.",
			season0: "Spring",
			season1: "Summer",
			season2: "Autumn",
			season3: "Winter",
			pig0: "Piglet",
			pig1: "Small Pig",
			pig2: "Average Pig",
			pig3: "Big Pig",
			actFeed: "Feed",
			actBuy: "Buy",
			actMate: "Mate",
			actSell: "Sell",
			itemVaccine: "Vaccine",
			itemSupp: "Supplement",
			itemAmulet: "Amulet",
			fieldName: "Field",
			fieldTitle: "Field {{n}}",
			card0: "Vaccination",
			card1: "Season of Love",
			card2: "No Effect",
			card3: "Field Sale",
			card4: "Vaccination",
			card5: "Season of Love",
			card6: "Sanitary Inspection",
			card7: "Season of Love",
			card8: "Sanitary Inspection",
			card9: "Season of Love",
			card10: "Family Day",
			card11: "Vaccination",
			card12: "Government Aid",
			card13: "Liquidation Sale",
			card14: "Pig Fair",
			card15: "Pig Fair",
			card16: "Sanitary Inspection",
			card17: "Liquidation Sale",
			card18: "Pig Fair",
			card19: "Ham Festival",
			card20: "Bacon Festival",
			card21: "Family Day",
			card22: "Bacon Festival",
			card23: "Vaccination",
			effectNone: "No effect",
			effectFieldSale: "Fields cost $3 less this round",
			effectSeasonOfLove: "At round end, each pair of breeding pigs births 1 Piglet",
			effectVaccination: "Player(s) with the most Small pigs gain 3 Vaccines",
			effectSanitary: "Pig prices +$3 this round (buy and sell)",
			effectFamilyDay: "Players owning all four pig sizes gain $25",
			effectGovAid: "Player(s) with the most Piglets gain 3 Supplements",
			effectLiquidation: "Items are buy-one-get-one-free this round",
			effectPigFair: "Player(s) with the most Big pigs gain $25",
			effectBaconFest: "Pig prices are $6/$10/$15/$21 this round",
			effectHamFest: "Pig prices are $5/$9/$14/$20 this round",
			phaseSetup: "Setup Shopping",
			phaseChoose: "Choose Action",
			phaseAct: "Take Actions",
			phasePlace: "Place New Pigs",
			phaseSeasonChange: "Change of Season",
			roundLabel: "Round {{n}}",
			setupPrompt: "Up to {{n}} purchase(s) left; tap the field to choose a spot",
			setupWaiting: "Waiting for {{name}} to shop…",
			choosePrompt: "Secretly choose your action for this round",
			chooseWaiting: "Chosen. Waiting for the others…",
			actPromptFeed: "Tap a pig to feed (up to {{n}})",
			actPromptBuy: "Buy goods (up to {{n}})",
			actPromptMate: "Tap an Average or Big pig to mate (up to {{n}})",
			actPromptSell: "Tap a pig to sell (up to {{n}})",
			actWaiting: "Waiting for {{name}}…",
			stop: "End Early",
			stopHint: "Unused actions pay $1 each",
			placePrompt: "Tap the field to pick a spot, then confirm; pigs that cannot fit return to the market",
			placeHint: "Choose a spot in the field",
			placeHere: "Place Pig",
			placeWaiting: "Waiting for {{name}} to place pigs…",
			rotate: "Rotate",
			repack: "Tidy Up",
			discardPig: "Return",
			donePlace: "Done",
			scPrompt: "Seasonal plague: select pigs to vaccinate; the rest will die",
			scSubmit: "Submit",
			scWaiting: "Waiting for {{name}} to vaccinate…",
			vaccinateAction: "Vaccinate",
			money: "Cash",
			fieldsLabel: "{{n}} fields",
			supplyPigs: "Pig stock",
			supplyItems: "Item stock",
			buyPig: "Buy {{name}} (${{n}})",
			buyItem: "Buy {{name}} ($1)",
			buyField: "Buy field (${{n}})",
			capsFeed: "Feed",
			capsBuy: "Buy",
			capsMate: "Mate",
			capsSell: "Sell",
			allocLabel: "{{n}} action(s)",
			chosenLabel: "chose",
			pendingPig: "Pending",
			vaccinatedTag: "Vaccinated",
			overTitle: "Year-End Settlement",
			overSubtitle: "Four seasons of farming, counted in coins",
			logRound: "Round {{n}}: {{card}}",
			logBuy: "{{name}} bought {{what}} (${{n}})",
			logFeed: "{{name}} fed a pig into {{what}}",
			logMate: "{{name}}'s pig birthed {{what}}",
			logSell: "{{name}} sold {{what}} for ${{n}}",
			logStop: "{{name}} ended early and gained ${{n}}",
			logVaccine: "{{name}} vaccinated {{n}} pig(s)",
			logDiscardPig: "{{name}}'s {{what}} did not fit and returned to the market",
			logDeaths: "{{name}} lost {{n}} unvaccinated pig(s)",
			logFinalSale: "{{name}} gained ${{n}} from the year-end sale",
			logReveal: "Actions revealed",
			logEffectMoney: "{{name}} gained ${{n}} ({{effect}})",
			logEffectItems: "{{name}} gained {{n}} {{what}}",
			logEffectPiglets: "{{name}} gained {{n}} Piglet(s)",
			errNotYourTurn: "Not your turn right now",
			errNoItem: "Not enough items",
			errBadPig: "This pig is not a valid target",
			errAlreadyVac: "This pig is already vaccinated",
			errNoFit: "No room in your fields",
			errSoldOut: "Sold out at the market",
			errNoMoney: "Not enough cash",
			errFedAlready: "This pig was already fed this round",
			errMatedAlready: "This pig already mated this round"
		}
	}
};
//#endregion
export { Ne as default };
