import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useMemo as n, useState as r } from "react";
import { useFxAnchor as i } from "@bgparty/sdk/fx/anchors";
import { useT as a } from "@bgparty/sdk/i18n";
import { GameScreen as o } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as s } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as c } from "@bgparty/sdk/ui/player-strip";
import { Fragment as l, jsx as u, jsxs as d } from "react/jsx-runtime";
import { Flash as f, Floater as p, FlySprite as m } from "@bgparty/sdk/fx/primitives";
import { GameOverScreen as h } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as g, OptionSection as _ } from "@bgparty/sdk/ui/game-options";
//#region src/games/cantstopexpress/meta.ts
var v = {
	id: "cantstopexpress",
	tier: "beta",
	mechanics: ["roll-and-write", "dice-rolling"],
	interactionTags: [],
	nameKey: "games.cantstopexpress.name",
	descKey: "games.cantstopexpress.desc",
	rulesKey: "games.cantstopexpress.rules",
	icon: "🚂",
	iconImg: "games/cantstopexpress.webp",
	minPlayers: 1,
	maxPlayers: 6,
	bestPlayers: [2, 3],
	accent: "#ea580c",
	releasedAt: "2026-09-21",
	search: {
		py: "yu ba bu neng ji su ban",
		init: "ybbnjsb"
	},
	hotseat: "cover"
}, y = t.int().min(1).max(6), b = t.string(), x = t.discriminatedUnion("type", [t.object({
	type: t.literal("assign"),
	p1: t.tuple([y, y]),
	p2: t.tuple([y, y]),
	fifth: y
})]), S = [
	200,
	150,
	100
], C = t.object({ penalty: t.union([
	t.literal(200),
	t.literal(150),
	t.literal(100)
]).default(200) }).default({ penalty: 200 }), w = t.object({
	value: y,
	count: t.int().min(1).max(8)
}), T = t.object({
	sums: t.tuple([
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative()
	]),
	fifth: t.array(w).max(3)
}), E = t.object({
	phase: t.enum(["play", "done"]),
	round: t.int().min(1),
	dice: t.tuple([
		y,
		y,
		y,
		y,
		y
	]),
	sheets: t.record(b, T),
	submitted: t.array(b),
	out: t.array(b),
	penalty: t.int()
}), D = t.object({}), O = [
	100,
	70,
	60,
	50,
	40,
	30,
	40,
	50,
	60,
	70,
	100
], k = {
	over: "games.cantstopexpress.errOver",
	notYourTurn: "games.cantstopexpress.errNotYourTurn",
	badAssign: "games.cantstopexpress.errBadAssign",
	alreadyDone: "games.cantstopexpress.errAlreadyDone"
};
function A() {
	return {
		sums: [
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0
		],
		fifth: []
	};
}
function j(t) {
	let n = Array.from({ length: 5 }, (n, r) => e(t.seed, t.rngCursor + r, 6) + 1);
	return t.rngCursor += 5, n;
}
function M(e, t, n) {
	return e === 0 || e === 5 ? 0 : e < 5 ? -n : (Math.min(e, 10) - 5) * O[t];
}
function N(e, t) {
	return e.sums.reduce((e, n, r) => e + M(n, r, t), 0);
}
function P(e, t, n) {
	let r = {};
	for (let e of t) r[e] = A();
	let i = {
		players: t,
		phase: "play",
		round: 1,
		dice: [],
		sheets: r,
		submitted: [],
		out: [],
		penalty: e.penalty,
		seed: n,
		rngCursor: 0
	};
	return i.dice = j(i), {
		state: i,
		fx: [{
			kind: "roll",
			data: { dice: i.dice }
		}]
	};
}
function F(e, t, n) {
	if (e.phase !== "play") return { code: k.over };
	if (!e.players.includes(n.by) || e.out.includes(n.by)) return { code: k.notYourTurn };
	if (e.submitted.includes(n.by)) return { code: k.alreadyDone };
	let r = [
		t.p1[0],
		t.p1[1],
		t.p2[0],
		t.p2[1],
		t.fifth
	].sort((e, t) => e - t), i = [...e.dice].sort((e, t) => e - t);
	if (r.some((e, t) => e !== i[t])) return { code: k.badAssign };
	let a = structuredClone(e), o = a.sheets[n.by], s = [t.p1[0] + t.p1[1], t.p2[0] + t.p2[1]].sort((e, t) => e - t);
	for (let e of s) o.sums[e - 2] += 1;
	let c = o.fifth.find((e) => e.value === t.fifth);
	c ? c.count += 1 : o.fifth.length < 3 && o.fifth.push({
		value: t.fifth,
		count: 1
	});
	let l = o.fifth.some((e) => e.count >= 8);
	l && a.out.push(n.by), a.submitted.push(n.by);
	let u = [];
	return l && u.push({
		kind: "bust",
		rid: n.by
	}), a.players.every((e) => a.out.includes(e) || a.submitted.includes(e)) && (a.out.length >= a.players.length ? a.phase = "done" : (a.round += 1, a.submitted = [], a.dice = j(a), u.push({
		kind: "roll",
		data: { dice: a.dice }
	}))), {
		state: a,
		fx: u
	};
}
function I(e) {
	return {
		public: {
			phase: e.phase,
			round: e.round,
			dice: e.dice,
			sheets: e.sheets,
			submitted: [...e.submitted],
			out: [...e.out],
			penalty: e.penalty
		},
		private: {}
	};
}
function L(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {};
	for (let n of e.players) t[n] = N(e.sheets[n], e.penalty);
	let n = [...e.players].sort((e, n) => t[n] - t[e]);
	return {
		phase: "done",
		winner: n.filter((e) => t[e] === t[n[0]]),
		ranking: n,
		scores: t
	};
}
var R = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: v,
	schemas: {
		action: x,
		publicView: E,
		privateView: D,
		config: C
	},
	setup: P,
	reduce: F,
	viewFor: I,
	status: L
}, z = {
	1: [[.5, .5]],
	2: [[.28, .28], [.72, .72]],
	3: [
		[.25, .25],
		[.5, .5],
		[.75, .75]
	],
	4: [
		[.28, .28],
		[.72, .28],
		[.28, .72],
		[.72, .72]
	],
	5: [
		[.25, .25],
		[.75, .25],
		[.5, .5],
		[.25, .75],
		[.75, .75]
	],
	6: [
		[.3, .25],
		[.7, .25],
		[.3, .5],
		[.7, .5],
		[.3, .75],
		[.7, .75]
	]
};
function B({ value: e, size: t = 44, label: n }) {
	return /* @__PURE__ */ d("svg", {
		viewBox: "0 0 48 48",
		role: "img",
		"aria-label": n,
		style: {
			width: t,
			height: t
		},
		className: "shrink-0",
		children: [/* @__PURE__ */ u("rect", {
			x: 2,
			y: 2,
			width: 44,
			height: 44,
			rx: 10,
			fill: "#ffffff",
			stroke: "var(--color-ink)",
			strokeWidth: 2.5
		}), z[e]?.map(([e, t], n) => /* @__PURE__ */ u("circle", {
			cx: e * 48,
			cy: t * 48,
			r: 4.6,
			fill: "var(--color-ink)"
		}, n))]
	});
}
function V(e) {
	let t = [
		[[e[0], e[1]], [e[2], e[3]]],
		[[e[0], e[2]], [e[1], e[3]]],
		[[e[0], e[3]], [e[1], e[2]]]
	], n = /* @__PURE__ */ new Set(), r = [];
	for (let [e, i] of t) {
		let t = [e[0] + e[1], i[0] + i[1]].sort((e, t) => e - t), a = `${t[0]}:${t[1]}`;
		n.has(a) || (n.add(a), r.push({
			p1: e,
			p2: i,
			sums: t
		}));
	}
	return r;
}
function H(e, t) {
	let n = e.fifth.findIndex((e) => e.value === t);
	return n >= 0 ? {
		kind: "mark",
		trackIdx: n
	} : e.fifth.length < 3 ? {
		kind: "new",
		trackIdx: e.fifth.length
	} : {
		kind: "free",
		trackIdx: -1
	};
}
function U(e) {
	let t = e.public;
	return /* @__PURE__ */ u(W, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: (t) => e.send(t)
	});
}
function W({ pub: e, members: t, myRid: i, send: f }) {
	let p = a(), m = t.filter((t) => e.sheets[t.rid]), h = e.sheets[i], g = e.out.includes(i), _ = e.submitted.includes(i), y = e.phase === "play" && !g && !_, [b, x] = r(null), [S, C] = r(null), [w, T] = r(e.round);
	w !== e.round && (T(e.round), x(null), C(null));
	let E = n(() => b === null ? [] : V(e.dice.filter((e, t) => t !== b)), [e.dice, b]), D = b !== null && S !== null ? E[S] : null, k = b === null ? null : e.dice[b], A = h && k !== null ? H(h, k) : null, j = D ? D.sums.map((e) => e - 2) : [], P = A && A.kind !== "free" ? A.trackIdx : null, F = Object.keys(e.sheets).filter((t) => !e.out.includes(t) && !e.submitted.includes(t)).length, I = g ? {
		tone: "info",
		text: p("games.cantstopexpress.youOut", { n: N(h, e.penalty) })
	} : _ ? {
		tone: "done",
		text: p("games.cantstopexpress.waiting", { n: F })
	} : {
		tone: "accent",
		text: p("games.cantstopexpress.pickPrompt")
	};
	return /* @__PURE__ */ u(o, {
		adaptive: !0,
		scroll: !1,
		className: "cse-view",
		banner: /* @__PURE__ */ d("div", {
			className: "cse-banner",
			children: [/* @__PURE__ */ u(s, {
				tone: I.tone,
				text: I.text,
				accent: v.accent,
				chip: p("games.cantstopexpress.round", { n: e.round })
			}), /* @__PURE__ */ u("div", {
				className: "cse-players",
				style: { "--cse-player-count": Math.max(1, m.length) },
				children: /* @__PURE__ */ u(c, {
					members: m,
					myRid: i,
					variant: "plate",
					status: (t) => {
						let n = e.sheets[t];
						return n ? /* @__PURE__ */ d("span", {
							className: "flex items-center gap-1.5 font-mono tabular-nums",
							children: [/* @__PURE__ */ u("span", {
								className: "cse-total text-base font-black",
								children: N(n, e.penalty)
							}), e.out.includes(t) && /* @__PURE__ */ u("span", {
								className: "rounded bg-danger-soft px-1 text-[10px] font-bold text-danger-ink",
								children: p("games.cantstopexpress.outBadge")
							})]
						}) : null;
					},
					action: (t) => e.phase !== "play" || e.out.includes(t) ? null : e.submitted.includes(t) ? "done" : "pending",
					anchorOf: (e) => `seat:${e}`
				})
			})]
		}),
		children: /* @__PURE__ */ d("div", {
			className: "cse-layout",
			children: [/* @__PURE__ */ u("div", {
				className: "frame cse-paper",
				tabIndex: 0,
				"aria-label": p("games.cantstopexpress.name"),
				children: /* @__PURE__ */ d("div", {
					className: "cse-sheet",
					children: [O.map((t, n) => /* @__PURE__ */ u(K, {
						sum: n + 2,
						aValue: t,
						marks: h.sums[n],
						score: M(h.sums[n], n, e.penalty),
						preview: j.includes(n)
					}, n)), /* @__PURE__ */ u(q, {
						sheet: h,
						previewIdx: P,
						previewKind: A?.kind ?? null,
						dieAria: (e) => p("games.cantstopexpress.dieAria", { n: e })
					})]
				})
			}), /* @__PURE__ */ d("div", {
				className: "cse-decisions",
				children: [/* @__PURE__ */ u(G, {
					pub: e,
					fifthIdx: y ? b : null,
					onPick: y ? (e) => {
						x(b === e ? null : e), C(null);
					} : void 0
				}), /* @__PURE__ */ d("div", {
					className: "cse-choice",
					children: [
						y && b === null && /* @__PURE__ */ u("p", {
							className: "cse-wait",
							children: p("games.cantstopexpress.pickFifth")
						}),
						y && b !== null && /* @__PURE__ */ d(l, { children: [
							/* @__PURE__ */ u("p", {
								className: "cse-fifth-preview",
								children: A?.kind === "free" ? p("games.cantstopexpress.fifthFree") : A?.kind === "new" ? p("games.cantstopexpress.fifthNew", { n: k ?? 0 }) : p("games.cantstopexpress.fifthMark", {
									n: k ?? 0,
									c: (h.fifth[A?.trackIdx ?? 0]?.count ?? 0) + 1
								})
							}),
							/* @__PURE__ */ u("div", {
								className: "cse-pairings",
								children: E.map((e, t) => /* @__PURE__ */ d("button", {
									type: "button",
									onClick: () => C(S === t ? null : t),
									className: "card cse-pair min-h-11 cursor-pointer text-center",
									style: S === t ? {
										borderColor: v.accent,
										boxShadow: `4px 4px 0 ${v.accent}`
									} : void 0,
									"aria-label": p("games.cantstopexpress.pairAria", {
										a: e.sums[0],
										b: e.sums[1]
									}),
									children: [/* @__PURE__ */ d("span", {
										className: "cse-pair-sums block font-mono font-black tabular-nums",
										children: [
											e.sums[0],
											" + ",
											e.sums[1]
										]
									}), /* @__PURE__ */ u("span", {
										className: "cse-pair-counts flex justify-center gap-1 font-mono font-bold tabular-nums text-ink/60",
										children: e.sums.map((e, t) => /* @__PURE__ */ u("span", {
											className: "rounded bg-paper px-1",
											children: p("games.cantstopexpress.rowCount", { n: h.sums[e - 2] })
										}, t))
									})]
								}, e.sums.join(":")))
							}),
							/* @__PURE__ */ u("button", {
								type: "button",
								onClick: () => {
									D && k !== null && f({
										type: "assign",
										p1: D.p1,
										p2: D.p2,
										fifth: k
									});
								},
								disabled: !D,
								className: "btn-base cse-confirm min-h-12 w-full shrink-0 font-black text-white disabled:opacity-40",
								style: { background: v.accent },
								children: D ? p("games.cantstopexpress.confirm", {
									a: D.sums[0],
									b: D.sums[1],
									f: k ?? 0
								}) : p("games.cantstopexpress.pickPair")
							})
						] }),
						_ && !g && /* @__PURE__ */ u("p", {
							className: "cse-wait",
							children: p("games.cantstopexpress.locked")
						}),
						g && /* @__PURE__ */ u("p", {
							className: "cse-wait",
							children: p("games.cantstopexpress.outWait")
						})
					]
				})]
			})]
		})
	});
}
function G({ pub: e, fifthIdx: t, onPick: n }) {
	let r = a(), { ref: o, hidden: s } = i("tray");
	return /* @__PURE__ */ u("div", {
		className: "cse-tray-space",
		children: /* @__PURE__ */ u("div", {
			ref: o,
			className: "cse-tray",
			style: s ? { visibility: "hidden" } : void 0,
			"aria-label": r("games.cantstopexpress.trayAria"),
			children: e.dice.map((e, i) => {
				let a = t === i, o = /* @__PURE__ */ u(B, {
					value: e,
					label: r("games.cantstopexpress.dieAria", { n: e })
				});
				return n ? /* @__PURE__ */ u("button", {
					type: "button",
					onClick: () => n(i),
					"aria-pressed": a,
					className: "cse-die-button min-h-11 min-w-11 cursor-pointer rounded-xl",
					style: a ? {
						outline: `3px solid ${v.accent}`,
						outlineOffset: "2px",
						transform: "translateY(-4px)"
					} : void 0,
					children: o
				}, i) : /* @__PURE__ */ u("span", { children: o }, i);
			})
		})
	});
}
function K({ sum: e, aValue: t, marks: n, score: r, preview: i }) {
	let a = Math.min(n, 10), o = n - 10;
	return /* @__PURE__ */ d("div", {
		className: `cse-row rounded-lg ${i ? "bg-info-soft" : ""}`,
		children: [
			/* @__PURE__ */ u("span", {
				className: "cse-sum font-mono font-black tabular-nums",
				children: e
			}),
			/* @__PURE__ */ u("div", {
				className: "cse-boxes",
				children: Array.from({ length: 10 }, (e, t) => {
					let n = t < a, r = i && t === a;
					return /* @__PURE__ */ u("span", {
						className: `cse-box flex items-center justify-center rounded-[4px] border-2 font-mono font-black leading-none ${n ? "border-ink bg-ink text-paper" : r ? "border-dashed border-info text-info" : "border-ink/25"}`,
						children: n || r ? "✕" : ""
					}, t);
				})
			}),
			/* @__PURE__ */ u("span", {
				className: "cse-overflow font-mono font-bold tabular-nums text-ink/60",
				children: o > 0 ? `+${o}` : ""
			}),
			/* @__PURE__ */ u("span", {
				className: "cse-value font-mono font-bold tabular-nums text-ink/50",
				children: t
			}),
			/* @__PURE__ */ u("span", {
				className: `cse-row-score font-mono font-black tabular-nums ${r > 0 ? "text-done-ink" : r < 0 ? "text-danger-ink" : "text-ink/40"}`,
				children: n === 0 ? "·" : r > 0 ? `+${r}` : r
			})
		]
	});
}
function q({ sheet: e, previewIdx: t, previewKind: n, dieAria: r }) {
	return /* @__PURE__ */ u("div", {
		className: "cse-fifth border-t-2 border-dashed border-ink/20",
		children: Array.from({ length: 3 }, (i, a) => {
			let o = e.fifth[a], s = t === a && n !== null && n !== "free";
			return /* @__PURE__ */ d("div", {
				className: `cse-track rounded-lg ${s ? "bg-info-soft" : ""}`,
				children: [o ? /* @__PURE__ */ u(B, {
					value: o.value,
					size: 26,
					label: r(o.value)
				}) : /* @__PURE__ */ u("span", {
					className: "cse-track-empty flex shrink-0 items-center justify-center rounded-lg border-2 border-dashed border-ink/30 font-black text-ink/30",
					children: "?"
				}), /* @__PURE__ */ u("div", {
					className: "cse-track-boxes",
					children: Array.from({ length: 8 }, (e, t) => {
						let n = o !== void 0 && t < o.count, r = s && (o !== void 0 && t === o.count || o === void 0 && t === 0);
						return /* @__PURE__ */ u("span", {
							className: `cse-track-box flex items-center justify-center rounded-[3px] border font-mono font-black leading-none ${n ? "border-danger-deep bg-danger text-white" : r ? "border-dashed border-info text-info" : "border-ink/25"}`,
							children: n || r ? "✕" : ""
						}, t);
					})
				})]
			}, o ? `t${o.value}` : `empty${a}`);
		})
	});
}
//#endregion
//#region src/games/cantstopexpress/bot.ts
function J(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function Y(e) {
	let t = /* @__PURE__ */ new Set(), n = [];
	for (let r = 0; r < e.length; r += 1) {
		let i = e.filter((e, t) => t !== r), a = [
			[[i[0], i[1]], [i[2], i[3]]],
			[[i[0], i[2]], [i[1], i[3]]],
			[[i[0], i[3]], [i[1], i[2]]]
		];
		for (let [i, o] of a) {
			let a = [...i].sort((e, t) => e - t), s = [...o].sort((e, t) => e - t), [c, l] = a[0] + a[1] <= s[0] + s[1] ? [a, s] : [s, a], u = `${c}:${l}:${e[r]}`;
			t.has(u) || (t.add(u), n.push({
				type: "assign",
				p1: c,
				p2: l,
				fifth: e[r]
			}));
		}
	}
	return n;
}
function X(e, t, n) {
	return e >= 10 ? 0 : e === 4 ? n : e >= 5 ? O[t] : 0;
}
function Z(e) {
	return e < 4 ? (e + 1) * 4 : 0;
}
var Q = (e, t) => {
	let n = e.public;
	if (n.phase !== "play" || n.out.includes(t.rid) || n.submitted.includes(t.rid)) return null;
	let r = n.sheets[t.rid];
	if (!r) return null;
	let i = Y(n.dice);
	if (i.length === 0) return null;
	if (t.difficulty === "weak") return { action: J(i) };
	let a = Math.max(0, ...r.fifth.map((e) => e.count)) / 8, o = r.sums.filter((e) => e >= 1 && e <= 4).length, s = (e) => [e.p1[0] + e.p1[1], e.p2[0] + e.p2[1]], c = (e) => s(e).reduce((e, t) => e + X(r.sums[t - 2], t - 2, n.penalty), 0), l = (e) => {
		let t = s(e), i = c(e);
		for (let e of t) i += Z(r.sums[e - 2]);
		let l = t.filter((e) => r.sums[e - 2] === 0).length;
		return i - l * n.penalty * .3 - o * n.penalty * .5 * a;
	}, u = Math.max(...i.map((e) => e.type === "assign" ? c(e) : 0)) <= 0, d = i[0], f = -Infinity;
	for (let e of i) {
		if (e.type !== "assign") continue;
		let t = r.fifth.find((t) => t.value === e.fifth), n = t !== void 0 && t.count + 1 >= 8, i = l(e);
		u ? (i += t ? t.count * 50 : -10, n && (i += 500)) : t ? (i -= (t.count + 1) * 15, n && (i -= 2e3)) : r.fifth.length < 3 ? i += 3 : i += 20, i > f && (f = i, d = e);
	}
	return { action: d };
}, ee = (e, t, n) => e.type === "assign" ? n("games.cantstopexpress.hintAssign", {
	a: e.p1[0] + e.p1[1],
	b: e.p2[0] + e.p2[1],
	f: e.fifth
}) : "", te = {
	needsAction: (e, t) => e.public.phase === "play" && !e.public.out.includes(t.rid) && !e.public.submitted.includes(t.rid),
	describeView(e, t) {
		let n = e.public, r = [`第 ${n.round} 回合。规则:每回合 5 颗公共骰,你把它们分成两对(p1/p2,各 2 颗,两对无顺序)+ 1 颗第 5 骰。两对的和值各行划 1 格;第 5 骰的点数轨道划 1 格。和值行:划 1-4 格每行罚 ${n.penalty} 分,恰好 5 格保本(0 分),第 6 格起每格 +A 值(A 值按和值 2-12: ${O.join(",")}),超 10 格不再得分。第 5 骰轨道最多记 3 个数字,任一数字满 8 格你立即出局;全员出局后总分最高者胜。`, `本回合骰子: [${n.dice.join(", ")}]`];
		for (let e of Object.keys(n.sheets)) {
			let i = n.sheets[e], a = i.sums.map((e, t) => e > 0 ? `和${t + 2}×${e}格(现值 ${M(e, t, n.penalty)} 分)` : null).filter(Boolean).join("; "), o = i.fifth.map((e) => `点${e.value}×${e.count}/8`).join("; ");
			r.push(`${e === t.rid ? "你" : e}${n.out.includes(e) ? "(已出局)" : ""}: 总分 ${N(i, n.penalty)};和值行: ${a || "(全空)"};第5骰轨道: ${o || "(空)"}`);
		}
		return r.push("输出 assign 行动:p1=[d1,d2], p2=[d3,d4], fifth=d5——5 颗骰每颗恰好用一次,按点数填(同点骰等价)。"), r.join("\n");
	},
	actionJsonSchema: {
		type: "object",
		properties: {
			type: { const: "assign" },
			p1: {
				type: "array",
				items: {
					type: "integer",
					minimum: 1,
					maximum: 6
				},
				minItems: 2,
				maxItems: 2
			},
			p2: {
				type: "array",
				items: {
					type: "integer",
					minimum: 1,
					maximum: 6
				},
				minItems: 2,
				maxItems: 2
			},
			fifth: {
				type: "integer",
				minimum: 1,
				maximum: 6
			}
		},
		required: [
			"type",
			"p1",
			"p2",
			"fifth"
		],
		additionalProperties: !1
	},
	parseAction(e, t, n) {
		let r = x.safeParse(e);
		if (!r.success) return null;
		let i = r.data, a = t.public;
		if (a.phase !== "play" || a.out.includes(n.rid) || a.submitted.includes(n.rid) || [...a.dice].sort().join(",") !== [
			...i.p1,
			...i.p2,
			i.fifth
		].sort().join(",")) return null;
		let o = a.sheets[n.rid];
		return o && !o.fifth.some((e) => e.value === i.fifth) && o.fifth.length >= 3 ? null : i;
	}
}, ne = {
	roll(e, t) {
		let n = e.data;
		if (!Array.isArray(n?.dice)) return null;
		let r = t.anchor("tray");
		if (!r) return null;
		let i = n.dice, a = t.queued > 0, o = r.h, s = i.length > 1 ? Math.max(0, (r.w - i.length * o) / (i.length - 1)) : 0, c = i.length * (o + s) - s;
		return {
			ms: a ? 350 : 700,
			hide: a ? void 0 : ["tray"],
			node: /* @__PURE__ */ u(l, { children: i.map((e, t) => /* @__PURE__ */ u(m, {
				from: {
					x: r.x + r.w / 2 - c / 2 + t * (o + s),
					y: r.y - 140,
					w: o,
					h: o
				},
				to: {
					x: r.x + r.w / 2 - c / 2 + t * (o + s),
					y: r.y + r.h / 2 - o / 2,
					w: o,
					h: o
				},
				ms: a ? 200 : 460,
				delay: a ? 0 : t * 50,
				children: /* @__PURE__ */ u(B, {
					value: e,
					size: o,
					label: ""
				})
			}, t)) })
		};
	},
	bust(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ d(l, { children: [/* @__PURE__ */ u(f, { ms: 700 }), /* @__PURE__ */ u(p, {
				at: n,
				ms: 900,
				children: /* @__PURE__ */ u("span", {
					className: "text-3xl",
					role: "img",
					"aria-hidden": !0,
					children: "🛑"
				})
			})] })
		} : null;
	}
};
//#endregion
//#region src/games/cantstopexpress/game-over-row.tsx
function $({ public: e, rid: t }) {
	let n = e, r = n.sheets[t];
	return r ? /* @__PURE__ */ d("div", {
		className: "cse-over-details mt-1.5 flex flex-wrap gap-1",
		"aria-hidden": !0,
		children: [r.sums.map((e, t) => {
			if (e === 0) return null;
			let r = M(e, t, n.penalty);
			return /* @__PURE__ */ d("span", {
				className: `rounded border border-ink/30 px-1.5 py-0.5 font-mono text-[10px] font-bold tabular-nums ${r > 0 ? "bg-done-soft text-done-ink" : r < 0 ? "bg-danger-soft text-danger-ink" : "bg-paper text-ink/60"}`,
				children: [
					t + 2,
					"×",
					Math.min(e, 10),
					e > 10 ? `+${e - 10}` : "",
					" → ",
					r > 0 ? `+${r}` : r
				]
			}, t);
		}), r.fifth.map((e) => /* @__PURE__ */ d("span", {
			className: "rounded border border-ink/30 bg-paper px-1.5 py-0.5 font-mono text-[10px] font-bold tabular-nums text-ink/60",
			children: [
				"🎲",
				e.value,
				"×",
				e.count
			]
		}, `f${e.value}`))]
	}) : null;
}
//#endregion
//#region src/games/cantstopexpress/game-over.tsx
function re(e) {
	return /* @__PURE__ */ u("div", {
		className: "cse-over",
		"data-count": e.result.ranking.length,
		children: /* @__PURE__ */ u(h, {
			hintCount: e.hintCount,
			result: e.result,
			members: e.members,
			myRid: e.myRid,
			accent: v.accent,
			onPlayAgain: e.onPlayAgain,
			onBackToLobby: e.onBackToLobby,
			renderRowExtra: (t) => /* @__PURE__ */ u($, {
				public: e.public,
				rid: t,
				myRid: e.myRid
			})
		})
	});
}
//#endregion
//#region src/games/cantstopexpress/options.tsx
function ie({ value: e, onChange: t }) {
	let n = a(), r = C.safeParse(e), i = r.success ? r.data : C.parse(void 0);
	return /* @__PURE__ */ u(_, {
		title: n("games.cantstopexpress.optPenalty"),
		columns: 3,
		children: S.map((e) => /* @__PURE__ */ u(g, {
			name: "cantstopexpress-penalty",
			value: String(e),
			checked: i.penalty === e,
			label: /* @__PURE__ */ d("span", {
				className: "font-mono tabular-nums",
				children: ["−", e]
			}),
			accent: v.accent,
			onChange: () => t({ penalty: e })
		}, e))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/cantstopexpress/entry.tsx
var ae = {
	definition: R,
	View: U,
	bot: Q,
	describe: ee,
	llm: te,
	fx: ne,
	OverView: re,
	RowView: $,
	Options: ie,
	locales: {
		zh: {
			name: "欲罢不能·极速版",
			desc: "五骰齐掷全员同划:凑对赚分,第 5 骰是你的出局倒计时",
			rules: "目标:在和值行上划记得分,终局总分最高者获胜。\n流程:\n· 每回合掷 5 颗公共骰,所有人用同一组点数同时行动。\n· 从 5 颗中选 4 颗凑成两对,两对的点数和各划 1 格;剩下 1 颗是第 5 骰。\n第 5 骰:\n· 第 5 骰记入专属轨道,最多开辟 3 条,每条对应一个点数、各 8 格。\n· 3 条轨道开辟后,第 5 骰命中其一必须划 1 格;都不命中则是免费回合,不划记。\n· 任一轨道划满 8 格,你立即出局。\n结束:\n· 玩家各自出局,全员出局后对局结束。\n结算:\n· 和值行划 1-4 格:每行扣 200 分(可在开局选项降为 150 或 100);划 0 或恰好 5 格:0 分。\n· 划到第 6 格起,每格赚得该行分值:2 和 12 值 100,向中间递减,7 值 30。\n· 一行划满 10 格后仍可继续划,但不再得分;总分最高者胜,平分共同获胜。",
			round: "第 {{n}} 回合",
			pickPrompt: "选一颗骰作第 5 骰,再挑配对方式",
			pickFifth: "点选一颗骰子作第 5 骰",
			pickPair: "选择配对方式",
			confirm: "划记 {{a}} + {{b}},第 5 骰留 {{f}}",
			waiting: "已提交,等 {{n}} 人…",
			locked: "已锁定,全员提交后开下一回合",
			youOut: "你已出局,最终得分 {{n}}",
			outWait: "第 5 骰轨道已集满,等其他人结束…",
			outBadge: "出局",
			fifthFree: "免费回合:第 5 骰不划记",
			fifthNew: "第 5 骰 {{n}}:开辟新轨道",
			fifthMark: "第 5 骰 {{n}}:划第 {{c}} 格(满 8 出局)",
			pairAria: "配对 {{a}} 和 {{b}}",
			rowCount: "{{n}} 格",
			dieAria: "{{n}} 点",
			trayAria: "本回合的 5 颗公共骰",
			optPenalty: "罚分档位(划 1-4 格的行)",
			hintAssign: "对子 {{a}} 与 {{b}},第 5 骰留 {{f}}",
			errOver: "本局已结束",
			errNotYourTurn: "你现在不能行动",
			errBadAssign: "分配与掷出的骰子不符",
			errAlreadyDone: "本回合你已提交"
		},
		en: {
			name: "Can't Stop Express",
			desc: "One roll for everyone: pair up for points, the 5th die is your countdown",
			rules: "Goal: Score by checking off sum rows; highest total wins.\nPlay:\n· Each turn 5 shared dice are rolled; everyone acts on the same roll at the same time.\n· Pick 4 of the 5 dice to form two pairs, and check one box for each pair's sum; the leftover die is your 5th die.\nThe 5th die:\n· The 5th die goes to its own tracks: at most 3 tracks, one per die value, 8 boxes each.\n· Once all 3 tracks are open, a 5th die matching one of them must be checked; if it matches none, the turn is free and nothing is marked.\n· As soon as any track reaches 8 checks, you are out.\nEnd:\n· Players go out individually; the game ends once everyone is out.\nScoring:\n· A row checked 1-4 times loses 200 points (reducible to 150 or 100 in the game options); 0 or exactly 5 checks score 0.\n· From the 6th check on, each box earns the row value: 100 for 2 and 12, decreasing toward 30 for 7.\n· You may keep checking a full row beyond 10 boxes but earn nothing more; highest total wins, ties share the win.",
			round: "Round {{n}}",
			pickPrompt: "Pick a 5th die, then choose a pairing",
			pickFifth: "Tap one die as the 5th die",
			pickPair: "Choose a pairing",
			confirm: "Mark {{a}} + {{b}}, keep {{f}} as 5th",
			waiting: "Submitted, waiting for {{n}}…",
			locked: "Locked in; next round once everyone submits",
			youOut: "You are out — final score {{n}}",
			outWait: "A 5th-die track is full; waiting for the others…",
			outBadge: "Out",
			fifthFree: "Free turn: the 5th die is not marked",
			fifthNew: "5th die {{n}}: opens a new track",
			fifthMark: "5th die {{n}}: check {{c}} of 8 (full = out)",
			pairAria: "Pair {{a}} and {{b}}",
			rowCount: "{{n}}",
			dieAria: "{{n}}",
			trayAria: "The 5 shared dice of this round",
			optPenalty: "Penalty per row checked 1-4 times",
			hintAssign: "Pairs {{a}} and {{b}}, keep {{f}} as the 5th die",
			errOver: "This game is over",
			errNotYourTurn: "You cannot act right now",
			errBadAssign: "That does not match the rolled dice",
			errAlreadyDone: "Already submitted this round"
		}
	}
};
//#endregion
export { ae as default };
