import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useCallback as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { botAvatarOf as o } from "@bgparty/sdk/lobby";
import { useFxAnchor as s, useFxAnchorsMaybe as c } from "@bgparty/sdk/fx/anchors";
import { usePrefersReducedMotion as l } from "@bgparty/sdk/fx/use-reduced-motion";
import { avatarNameAt as u, useI18nSettings as d, useT as f } from "@bgparty/sdk/i18n";
import { IconClose as p, IconDisconnected as m, IconEye as h, IconPile as ee } from "@bgparty/sdk/icons";
import { playTurn as g, useSoundEdge as _ } from "@bgparty/sdk/sfx";
import { Texture as te } from "@bgparty/sdk/texture";
import { GameScreen as v } from "@bgparty/sdk/ui/game-screen";
import { Fragment as y, jsx as b, jsxs as x } from "react/jsx-runtime";
import { FlySprite as S } from "@bgparty/sdk/fx/primitives";
//#region src/games/parade/meta.ts
var ne = {
	id: "parade",
	tier: "released",
	mechanics: ["hand-management", "set-collection"],
	interactionTags: [],
	nameKey: "games.parade.name",
	descKey: "games.parade.desc",
	rulesKey: "games.parade.rules",
	icon: "🎩",
	iconImg: "games/parade.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/parade/en.pdf" },
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [4],
	accent: "#8b5cf6",
	releasedAt: "2026-10-06",
	search: {
		py: "xian jing meng you",
		init: "xjmy"
	},
	hotseat: "cover"
}, C = t.int().min(0).max(65), w = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("tick"),
		now: t.number()
	}),
	t.object({
		type: t.literal("play"),
		card: C
	}),
	t.object({
		type: t.literal("discard"),
		cards: t.tuple([C, C])
	})
]), T = t.string(), E = t.object({
	parade: t.array(C.nullable()),
	deckCount: t.int().nonnegative(),
	turn: T,
	phase: t.enum([
		"play",
		"discard",
		"done"
	]),
	final: t.boolean(),
	players: t.array(t.object({
		rid: T,
		collected: t.array(C),
		handCount: t.int().nonnegative(),
		discarded: t.boolean()
	})),
	lastPlay: t.object({
		rid: T,
		card: C,
		taken: t.array(C)
	}).nullable(),
	settle: t.object({
		rid: T,
		card: C,
		taken: t.array(C)
	}).nullable()
}), D = t.object({
	hand: t.array(C),
	myDiscards: t.array(C).nullable()
}), O = 66, k = {
	place: 550,
	take: 750,
	advance: 420
}, A = (e) => Math.floor(e / 11), j = (e) => e % 11;
function M(e, t) {
	let n = e.filter((e) => e !== null), r = j(t), i = n.length;
	if (i <= r) return [];
	let a = i - r;
	return n.filter((e, n) => n < a && (A(e) === A(t) || j(e) <= r));
}
function N(e, t, n) {
	let r = 0;
	for (let i = 0; i < 6; i += 1) {
		let a = e.filter((e) => A(e) === i).length;
		if (a === 0) continue;
		let o;
		o = n ? a - (t[0]?.filter((e) => A(e) === i).length ?? 0) >= 2 : t.every((e) => e.filter((e) => A(e) === i).length <= a);
		for (let t of e) A(t) === i && (r += o ? 1 : j(t));
	}
	return r;
}
function P(t, n, r) {
	let i = Array.from({ length: O }, (e, t) => t), a = 0;
	for (let t = i.length - 1; t > 0; --t) {
		let n = e(r, a, t + 1);
		a += 1, [i[t], i[n]] = [i[n], i[t]];
	}
	let o = {}, s = {};
	for (let e of n) o[e] = i.splice(-5).sort((e, t) => e - t), s[e] = [];
	let c = i.splice(-6);
	return {
		state: {
			players: n,
			deck: i,
			parade: c,
			hands: o,
			collected: s,
			turn: 0,
			finalLeft: null,
			phase: "play",
			discards: {},
			lastPlay: null,
			settle: null,
			rngCursor: a
		},
		fx: [{
			kind: "dealParade",
			data: { cards: c }
		}, ...n.map((e) => ({
			kind: "deal",
			rid: e,
			data: { count: 5 },
			for: [e],
			secret: { cards: o[e] },
			with: !0
		}))]
	};
}
function F(e, t, n) {
	if (e.finalLeft === null) {
		if (e.deck.length > 0) {
			let r = e.deck.pop(), i = e.hands[t];
			i.push(r), i.sort((e, t) => e - t), n.push({
				kind: "draw",
				rid: t,
				data: { count: 1 },
				for: [t],
				secret: { card: r }
			});
		}
		(new Set(e.collected[t].map(A)).size === 6 || e.deck.length === 0) && (e.finalLeft = e.players.length), e.turn = (e.turn + 1) % e.players.length;
	} else --e.finalLeft, e.finalLeft <= 0 ? e.phase = "discard" : e.turn = (e.turn + 1) % e.players.length;
}
function I(e, t, n) {
	if (t.type === "tick") {
		let t = e.settle;
		if (e.phase !== "play" || !t) return {
			state: e,
			fx: []
		};
		let n = structuredClone(e), r = [];
		if (t.step === "take") {
			for (let e of t.slots) n.parade[e] = null;
			n.collected[t.rid].push(...t.taken), n.settle = {
				...t,
				step: "close"
			}, r.push({
				kind: "take",
				rid: t.rid,
				data: {
					taken: t.taken,
					slots: t.slots
				}
			});
		} else n.parade = n.parade.filter((e) => e !== null), n.settle = null, F(n, t.rid, r);
		return {
			state: n,
			fx: r
		};
	}
	if (t.type === "play") {
		if (e.phase !== "play" || e.settle || e.players[e.turn] !== n.by) return { code: "games.parade.errNotYourTurn" };
		if (!e.hands[n.by]?.includes(t.card)) return { code: "games.parade.errBadCard" };
		let r = structuredClone(e), i = r.hands[n.by];
		i.splice(i.indexOf(t.card), 1);
		let a = M(r.parade, t.card), o = a.map((e) => r.parade.indexOf(e));
		r.parade.push(t.card), r.lastPlay = {
			rid: n.by,
			card: t.card,
			taken: a
		};
		let s = [{
			kind: "play",
			rid: n.by,
			data: { card: t.card }
		}];
		return a.length > 0 ? (r.settle = {
			rid: n.by,
			card: t.card,
			taken: a,
			slots: o,
			step: "take"
		}, {
			state: r,
			fx: s
		}) : (F(r, n.by, s), {
			state: r,
			fx: s
		});
	}
	if (e.phase !== "discard" || n.by in e.discards) return { code: "games.parade.errNotYourTurn" };
	let r = e.hands[n.by] ?? [], [i, a] = t.cards;
	if (i === a || !r.includes(i) || !r.includes(a)) return { code: "games.parade.errBadDiscard" };
	let o = structuredClone(e);
	o.discards[n.by] = [...t.cards];
	let s = r.filter((e) => e !== i && e !== a);
	return o.collected[n.by].push(...s), o.collected[n.by].sort((e, t) => e - t), o.hands[n.by] = [], Object.keys(o.discards).length === o.players.length && (o.phase = "done"), {
		state: o,
		fx: [{
			kind: "discard",
			rid: n.by,
			data: { kept: s },
			for: [n.by],
			secret: { kept: s }
		}]
	};
}
function L(e, t) {
	return {
		public: {
			parade: e.parade,
			deckCount: e.deck.length,
			turn: e.players[e.turn],
			phase: e.phase,
			final: e.phase === "play" && e.finalLeft !== null,
			players: e.players.map((t) => ({
				rid: t,
				collected: e.collected[t],
				handCount: e.hands[t].length,
				discarded: t in e.discards
			})),
			lastPlay: e.lastPlay,
			settle: e.settle ? {
				rid: e.settle.rid,
				card: e.settle.card,
				taken: e.settle.taken
			} : null
		},
		private: {
			hand: e.hands[t] ?? [],
			myDiscards: e.discards[t] ?? null
		}
	};
}
function re(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = e.players.length === 2, n = {}, r = {};
	for (let i of e.players) {
		let a = e.players.filter((e) => e !== i).map((t) => e.collected[t]);
		n[i] = N(e.collected[i], a, t), r[i] = e.collected[i].length;
	}
	let i = [...e.players].sort((e, t) => n[e] - n[t] || r[e] - r[t]), a = i[0];
	return {
		phase: "done",
		winner: i.filter((e) => n[e] === n[a] && r[e] === r[a]),
		ranking: i,
		scores: n
	};
}
function R(e) {
	return e.phase !== "play" || !e.settle ? null : e.settle.step === "take" ? k.place : k.take;
}
var z = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: ne,
	schemas: {
		action: w,
		publicView: E,
		privateView: D
	},
	setup: P,
	reduce: I,
	viewFor: L,
	status: re,
	nextTickIn: R
}, B = [
	{
		accent: "#d66a70",
		soft: "#f5d8d5",
		ink: "#9d3e4b"
	},
	{
		accent: "#77aad1",
		soft: "#dbeaf5",
		ink: "#377cae"
	},
	{
		accent: "#a77bc6",
		soft: "#ecdcf4",
		ink: "#75469d"
	},
	{
		accent: "#76ab81",
		soft: "#dff0d8",
		ink: "#36794d"
	},
	{
		accent: "#9da7b9",
		soft: "#e8eaf0",
		ink: "#68758c"
	},
	{
		accent: "#dfa55b",
		soft: "#fae7c9",
		ink: "#a9692a"
	}
], V = [
	"games.parade.colorRed",
	"games.parade.colorBlue",
	"games.parade.colorPurple",
	"games.parade.colorGreen",
	"games.parade.colorGrey",
	"games.parade.colorOrange"
];
function H({ card: e, className: t = "" }) {
	let n = f(), r = A(e), i = j(e), a = B[r];
	return /* @__PURE__ */ x("svg", {
		className: `parade-card ${t}`,
		viewBox: "0 0 50 78",
		preserveAspectRatio: "xMidYMid meet",
		role: "img",
		"aria-label": n("games.parade.cardName", {
			color: n(V[r]),
			n: i
		}),
		children: [
			/* @__PURE__ */ b("rect", {
				x: "1",
				y: "1",
				width: "48",
				height: "76",
				rx: "5",
				fill: "#fff8e8",
				stroke: "#2e233a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ b("rect", {
				x: "4",
				y: "4",
				width: "42",
				height: "70",
				rx: "3",
				fill: "none",
				stroke: "#c6a56c",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ b("rect", {
				x: "5",
				y: "5",
				width: "40",
				height: "7",
				rx: "2",
				fill: a.accent
			}),
			/* @__PURE__ */ b("path", {
				d: "M7 35h36M7 68h36",
				stroke: "#c6a56c",
				strokeWidth: ".7"
			}),
			/* @__PURE__ */ b("circle", {
				cx: "25",
				cy: "52",
				r: "15",
				fill: a.soft
			}),
			/* @__PURE__ */ b(U, {
				color: r,
				ink: a.ink
			}),
			/* @__PURE__ */ b("text", {
				x: "25",
				y: "32",
				textAnchor: "middle",
				fill: a.ink,
				fontSize: i === 10 ? 23 : 28,
				fontWeight: "900",
				fontFamily: "ui-monospace, monospace",
				children: i
			}),
			/* @__PURE__ */ b("text", {
				x: "43",
				y: "73",
				textAnchor: "end",
				fill: a.ink,
				fontSize: "8",
				fontWeight: "800",
				fontFamily: "ui-monospace, monospace",
				children: i
			}),
			/* @__PURE__ */ b("path", {
				d: "m8 39 2 2-2 2-2-2zm34 0 2 2-2 2-2-2z",
				fill: "#bd9e69",
				opacity: ".8"
			})
		]
	});
}
function ie({ className: e = "" }) {
	return /* @__PURE__ */ x("svg", {
		className: `parade-card ${e}`,
		viewBox: "0 0 50 78",
		preserveAspectRatio: "xMidYMid meet",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ b("rect", {
				x: "1",
				y: "1",
				width: "48",
				height: "76",
				rx: "5",
				fill: "#44305f",
				stroke: "#2e233a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ b("rect", {
				x: "4",
				y: "4",
				width: "42",
				height: "70",
				rx: "3",
				fill: "none",
				stroke: "#c6a56c",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ b("path", {
				d: "M25 14 42 39 25 64 8 39Z",
				fill: "none",
				stroke: "#d9bc80",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ b("path", {
				d: "M25 24 34 39 25 54 16 39Z",
				fill: "#d9bc8033",
				stroke: "#d9bc80",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ b("circle", {
				cx: "25",
				cy: "39",
				r: "3.2",
				fill: "none",
				stroke: "#e6cf9b",
				strokeWidth: "1.2"
			}),
			/* @__PURE__ */ b("path", {
				d: "M25 42v6m-2.5 0h5",
				stroke: "#e6cf9b",
				strokeWidth: "1.2",
				strokeLinecap: "round"
			})
		]
	});
}
function U({ color: e, ink: t }) {
	let n = {
		fill: "none",
		stroke: t,
		strokeWidth: 2.3,
		strokeLinejoin: "round",
		strokeLinecap: "round"
	};
	switch (e) {
		case 0: return /* @__PURE__ */ x("g", {
			...n,
			children: [/* @__PURE__ */ b("path", { d: "M18 55 20 44h10l2 11M14 56h22l-2 5H16Z" }), /* @__PURE__ */ b("path", {
				d: "M19 52h12M26 45l2 7",
				strokeWidth: "1.5"
			})]
		});
		case 1: return /* @__PURE__ */ x("g", {
			...n,
			children: [
				/* @__PURE__ */ b("path", { d: "M25 42a6 6 0 0 1 3.3 11L28 62h-6l-.3-9A6 6 0 0 1 25 42Z" }),
				/* @__PURE__ */ b("circle", {
					cx: "25",
					cy: "48",
					r: "1.5",
					fill: t,
					stroke: "none"
				}),
				/* @__PURE__ */ b("path", {
					d: "M22 58h6",
					strokeWidth: "1.5"
				})
			]
		});
		case 2: return /* @__PURE__ */ x("g", {
			...n,
			children: [/* @__PURE__ */ b("path", { d: "M15 50c3 11 17 12 20 0-5 5-15 5-20 0Z" }), /* @__PURE__ */ b("path", {
				d: "M20 56v3m5-2v3m5-4v3M18 46l2-2m10 0 2 2",
				strokeWidth: "1.5"
			})]
		});
		case 3: return /* @__PURE__ */ x("g", {
			...n,
			children: [/* @__PURE__ */ b("path", { d: "M25 41c-5 0-9 10-9 16a9 9 0 0 0 18 0c0-6-4-16-9-16Z" }), /* @__PURE__ */ b("path", {
				d: "m17 55 5 2 3-3 3 3 5-2",
				strokeWidth: "1.7"
			})]
		});
		case 4: return /* @__PURE__ */ x("g", {
			...n,
			children: [/* @__PURE__ */ b("circle", {
				cx: "25",
				cy: "54",
				r: "9"
			}), /* @__PURE__ */ b("path", {
				d: "M22 42h6M25 45v2m0 7v-5m0 5 4 2",
				strokeWidth: "1.7"
			})]
		});
		default: return /* @__PURE__ */ x("g", {
			...n,
			children: [/* @__PURE__ */ b("path", { d: "M16 63c3-15 9-20 18-19 1 9-4 16-18 19Z" }), /* @__PURE__ */ b("path", {
				d: "M16 63 32 46m-10 11-1-7m6 2 6 1",
				strokeWidth: "1.5"
			})]
		});
	}
}
//#endregion
//#region src/games/parade/view-player.tsx
function W(e) {
	return /* @__PURE__ */ b(q, {
		pub: e.public,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function G(e) {
	return e <= 8 ? Math.max(7, e + 1) : e <= 35 ? 9 : 11;
}
function ae() {
	let e = c(), t = i(/* @__PURE__ */ new Map()), a = i(/* @__PURE__ */ new Map()), o = n((e, t) => {
		let n = t.getBoundingClientRect();
		n.width > 0 && n.height > 0 && a.current.set(e, {
			box: {
				x: n.left,
				y: n.top,
				w: n.width,
				h: n.height
			},
			viewport: `${window.innerWidth}:${window.innerHeight}`
		});
	}, []), s = n((e, n) => {
		let r = t.current.get(e);
		r?.isConnected && o(e, r), n ? t.current.set(e, n) : t.current.delete(e);
	}, [o]), l = n(() => {
		for (let [e, n] of t.current) o(e, n);
	}, [o]);
	return r(l), r(() => {
		if (!e) return;
		let t = Array.from({ length: 66 }, (t, n) => {
			let r = `hsource:${n}`;
			return e.registerProbe(r, () => {
				let e = a.current.get(n);
				return e?.viewport === `${window.innerWidth}:${window.innerHeight}` ? e.box : null;
			}), r;
		});
		return () => {
			for (let n of t) e.registerProbe(n, null);
		};
	}, [e]), {
		remember: s,
		capture: l
	};
}
function K(e) {
	let t = c(), n = i(null), [o, s] = a(() => G(e));
	return r(() => {
		let r = n.current;
		if (!r) return;
		t?.registerProbe("parade:large-queue", () => {
			if (Number(getComputedStyle(r).getPropertyValue("--parade-layout")) !== 2) return null;
			let e = r.getBoundingClientRect();
			return {
				x: e.left,
				y: e.top,
				w: e.width,
				h: e.height
			};
		});
		let i = new ResizeObserver(() => {
			let t = getComputedStyle(r), n = Number(t.getPropertyValue("--parade-layout")), i = n === 1 ? e <= 8 ? Math.max(7, e + 1) : e <= 35 ? 12 : 18 : G(e);
			if (n === 2) {
				let n = e + 1, a = parseFloat(t.columnGap), o = parseFloat(t.rowGap), s = 0, c = Infinity;
				for (let e = 1; e <= Math.min(18, n); e += 1) {
					let t = Math.ceil(n / e), l = (r.clientWidth - a * (e - 1)) / e, u = (r.clientHeight - o * (t - 1)) / t, d = Math.min(l, u * 50 / 78), f = e * t - n;
					(d > s || d === s && f < c) && (s = d, c = f, i = e);
				}
			}
			s((e) => e === i ? e : i);
		});
		return i.observe(r), () => {
			i.disconnect(), t?.registerProbe("parade:large-queue", null);
		};
	}, [t, e]), {
		gridRef: n,
		columns: o
	};
}
function q({ pub: e, priv: t, members: n, myRid: r, send: i }) {
	let c = f(), l = d((e) => e.locale), { ref: m } = s("deck"), { ref: y } = s("hand"), S = ae(), [ne, C] = a(!1), w = `${e.phase}|${e.turn}|${t?.hand.join(",") ?? ""}|${t?.myDiscards?.join(",") ?? ""}`, [T, E] = a({
		key: w,
		cards: []
	}), D = T.key === w ? T.cards : [], O = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? o(e) === null ? t.name : u(l, t.avatar) : e;
	}, k = (e) => c("games.parade.cardName", {
		color: c(V[A(e)]),
		n: j(e)
	}), N = e.phase === "play" && e.turn === r && !e.settle, P = e.phase === "discard" && t !== void 0 && t.myDiscards === null, F = N || P;
	_(F, g);
	let I = N && D.length === 1 && t?.hand.includes(D[0]) ? D[0] : null, L = I === null ? [] : M(e.parade, I), re = new Set(L), R = new Set(e.settle?.taken ?? []), z = I === null ? e.parade.length : Math.max(0, e.parade.length - j(I)), H = P && D.length === 2 && D.every((e) => t.hand.includes(e)), ie = e.parade.filter((e) => e !== null).length, U = e.phase === "discard" ? c(P ? "games.parade.discardPrompt" : "games.parade.discardWaiting") : e.settle ? c("games.parade.settling", { name: O(e.settle.rid) }) : N ? c("games.parade.playPrompt") : c("games.parade.waitingTurn", { name: O(e.turn) }), W = e.final ? c("games.parade.finalRound") : c("games.parade.deckLeft", { n: e.deckCount }), G = e.lastPlay ? e.lastPlay.taken.length > 0 ? c("games.parade.lastPlayTaken", {
		name: O(e.lastPlay.rid),
		card: k(e.lastPlay.card),
		n: e.lastPlay.taken.length
	}) : c("games.parade.lastPlayNone", {
		name: O(e.lastPlay.rid),
		card: k(e.lastPlay.card)
	}) : c("games.parade.lastPlayEmpty"), K = I === null ? H ? c("games.parade.discardReady") : e.phase === "discard" ? U : N ? c("games.parade.playPrompt") : G : L.length > 0 ? c("games.parade.previewTake", {
		card: k(I),
		n: L.length
	}) : c("games.parade.previewNone", { card: k(I) }), q = I === null ? e.phase === "discard" ? c("games.parade.discardHelp") : N ? G : "" : c("games.parade.previewSkip", { n: e.parade.length - z }), J = (e) => {
		if (!F) return;
		let t = D.includes(e) ? D.filter((t) => t !== e) : [...D, e].slice(P ? -2 : -1);
		E({
			key: w,
			cards: t
		});
	};
	return /* @__PURE__ */ b("div", {
		className: "parade-screen",
		children: /* @__PURE__ */ b(v, {
			adaptive: !0,
			className: "parade-adaptive",
			scroll: !1,
			banner: /* @__PURE__ */ x("div", {
				className: "parade-banner",
				role: "status",
				children: [/* @__PURE__ */ x("svg", {
					className: "parade-banner-watch",
					viewBox: "0 0 32 32",
					"aria-hidden": "true",
					children: [/* @__PURE__ */ b("circle", {
						cx: "16",
						cy: "17",
						r: "12",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "1.8"
					}), /* @__PURE__ */ b("path", {
						d: "M10 2h12M16 17V9m0 8 5 3",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "1.8",
						strokeLinecap: "round"
					})]
				}), /* @__PURE__ */ b("strong", {
					className: "parade-banner-text",
					children: U
				})]
			}),
			actionsHeight: "parade-actions-height",
			actions: /* @__PURE__ */ b("div", {
				className: "parade-hand-tray",
				"aria-label": c("games.parade.handTray", { n: t?.hand.length ?? 0 }),
				children: /* @__PURE__ */ b("div", {
					className: "parade-hand-cards",
					ref: y,
					children: t?.hand.map((e) => /* @__PURE__ */ b(oe, {
						card: e,
						picked: D.includes(e),
						disabled: !F,
						discardMode: P,
						label: k(e),
						onToggle: J,
						rememberSource: S.remember
					}, e))
				})
			}),
			children: /* @__PURE__ */ x("div", {
				className: "parade-board",
				children: [
					/* @__PURE__ */ b(te, {
						kind: "diamond",
						base: "#3b2a50",
						line: "#806596",
						className: "parade-board-texture"
					}),
					/* @__PURE__ */ x("svg", {
						className: "parade-board-dial",
						viewBox: "0 0 400 400",
						"aria-hidden": "true",
						children: [
							/* @__PURE__ */ b("circle", {
								cx: "200",
								cy: "200",
								r: "170",
								fill: "none",
								stroke: "#c9a4c4",
								strokeWidth: "2"
							}),
							/* @__PURE__ */ b("circle", {
								cx: "200",
								cy: "200",
								r: "132",
								fill: "none",
								stroke: "#c9a4c4",
								strokeWidth: "1.5"
							}),
							/* @__PURE__ */ b("path", {
								d: "M200 29v24m0 294v24M29 200h24m294 0h24M79 79l17 17m208 208 17 17M321 79l-17 17M96 304l-17 17",
								fill: "none",
								stroke: "#d9bc80",
								strokeWidth: "3",
								strokeLinecap: "round"
							})
						]
					}),
					/* @__PURE__ */ x("svg", {
						className: "parade-board-moon",
						viewBox: "0 0 48 48",
						"aria-hidden": "true",
						children: [/* @__PURE__ */ b("path", {
							d: "M25 4a20 20 0 1 0 18 30A23 23 0 0 1 25 4Z",
							fill: "#e6cf9b"
						}), /* @__PURE__ */ b("path", {
							d: "m9 12 2-4 2 4 4 2-4 2-2-4-4-2Z",
							fill: "#e6cf9b"
						})]
					}),
					/* @__PURE__ */ b("svg", {
						className: "parade-board-keyhole",
						viewBox: "0 0 46 50",
						"aria-hidden": "true",
						children: /* @__PURE__ */ b("path", {
							d: "M13 27a13 13 0 1 1 20 0l5 18H8l5-18Z",
							fill: "none",
							stroke: "#cfad78",
							strokeWidth: "1.6"
						})
					}),
					/* @__PURE__ */ x("div", {
						className: "parade-board-inner",
						style: { "--parade-players": e.players.length },
						children: [
							/* @__PURE__ */ x("div", {
								className: "parade-masthead",
								children: [/* @__PURE__ */ b("strong", { children: c("games.parade.name") }), /* @__PURE__ */ b("button", {
									type: "button",
									className: "parade-details-button",
									"aria-label": c("games.parade.detailsTitle"),
									title: c("games.parade.detailsTitle"),
									onClick: () => C(!0),
									children: /* @__PURE__ */ b(h, {
										size: 20,
										"aria-hidden": "true"
									})
								})]
							}),
							/* @__PURE__ */ x("section", {
								className: "parade-scoreboard",
								"aria-label": c("games.parade.collectedLabel"),
								children: [
									/* @__PURE__ */ b("div", {
										className: "parade-score-heading",
										children: /* @__PURE__ */ b("button", {
											type: "button",
											className: "parade-details-button",
											"aria-label": c("games.parade.detailsTitle"),
											title: c("games.parade.detailsTitle"),
											onClick: () => C(!0),
											children: /* @__PURE__ */ b(h, {
												size: 20,
												"aria-hidden": "true"
											})
										})
									}),
									/* @__PURE__ */ b("div", {
										className: "parade-score-rows",
										children: e.players.map((t) => /* @__PURE__ */ b(se, {
											player: t,
											member: n.find((e) => e.rid === t.rid),
											isMe: t.rid === r,
											isTurn: e.phase === "play" && e.turn === t.rid,
											phase: e.phase,
											name: O(t.rid),
											panel: e.players.length <= 3
										}, t.rid))
									}),
									/* @__PURE__ */ b("div", {
										className: "parade-chess-trim",
										"aria-hidden": "true"
									})
								]
							}),
							/* @__PURE__ */ x("section", {
								className: "parade-queue",
								"aria-label": c("games.parade.paradeLabel"),
								children: [/* @__PURE__ */ x("div", {
									className: "parade-queue-heading",
									children: [/* @__PURE__ */ x("strong", { children: [
										c("games.parade.paradeLabel"),
										" · ",
										c("games.parade.queueCount", { n: ie })
									] }), /* @__PURE__ */ x("span", {
										className: "parade-deck-status",
										ref: m,
										children: [/* @__PURE__ */ b(ee, {
											size: 14,
											"aria-hidden": "true"
										}), W]
									})]
								}), /* @__PURE__ */ b(ce, {
									cards: e.parade,
									selectedCard: I,
									takenIds: re,
									settleTakenIds: R,
									skippedStart: z
								})]
							}),
							/* @__PURE__ */ x("div", {
								className: "parade-preview-bar",
								role: "status",
								children: [/* @__PURE__ */ x("span", {
									className: "parade-preview-copy",
									children: [/* @__PURE__ */ b("strong", { children: K }), /* @__PURE__ */ b("small", { children: q })]
								}), I !== null || H ? /* @__PURE__ */ b("button", {
									type: "button",
									className: "parade-submit",
									onClick: () => {
										if (S.capture(), I !== null) i({
											type: "play",
											card: I
										});
										else if (H) i({
											type: "discard",
											cards: [D[0], D[1]]
										});
										else return;
										E({
											key: w,
											cards: []
										});
									},
									children: c(I === null ? "games.parade.confirmDiscard" : "games.parade.confirmPlay")
								}) : /* @__PURE__ */ b("span", { className: "parade-submit-space" })]
							})
						]
					}),
					ne && /* @__PURE__ */ b("div", {
						className: "parade-details-layer",
						children: /* @__PURE__ */ x("div", {
							className: "parade-details-panel",
							role: "region",
							"aria-label": c("games.parade.detailsTitle"),
							children: [/* @__PURE__ */ x("div", {
								className: "parade-details-head",
								children: [/* @__PURE__ */ b("strong", { children: c("games.parade.detailsTitle") }), /* @__PURE__ */ b("button", {
									type: "button",
									className: "parade-details-close",
									"aria-label": c("games.parade.closeDetails"),
									onClick: () => C(!1),
									children: /* @__PURE__ */ b(p, { size: 19 })
								})]
							}), /* @__PURE__ */ b("div", {
								className: "parade-details-list",
								children: e.players.map((e) => /* @__PURE__ */ x("div", {
									className: "parade-details-player",
									children: [/* @__PURE__ */ b("strong", { children: O(e.rid) }), /* @__PURE__ */ b("div", {
										className: "parade-details-colors",
										children: Array.from({ length: 6 }, (t, n) => {
											let r = e.collected.filter((e) => A(e) === n), i = B[n];
											return /* @__PURE__ */ x("div", {
												className: "parade-details-color",
												"aria-label": c("games.parade.detailColorAria", { color: c(V[n]) }),
												style: { borderColor: i.accent },
												children: [/* @__PURE__ */ b("span", {
													className: "parade-details-dot",
													style: { backgroundColor: i.accent }
												}), r.length ? r.map((e) => /* @__PURE__ */ b("span", {
													className: "parade-details-value",
													children: j(e)
												}, e)) : /* @__PURE__ */ b("span", {
													className: "parade-details-empty",
													children: "—"
												})]
											}, n);
										})
									})]
								}, e.rid))
							})]
						})
					})
				]
			})
		})
	});
}
function oe({ card: e, picked: t, disabled: r, discardMode: i, label: a, onToggle: o, rememberSource: c }) {
	let l = f(), { ref: u, hidden: d } = s(`hcard:${e}`), p = n((t) => {
		u(t), c(e, t);
	}, [
		u,
		c,
		e
	]);
	return /* @__PURE__ */ x("button", {
		type: "button",
		disabled: r,
		"aria-pressed": t,
		"aria-label": a,
		onClick: () => o(e),
		className: `parade-hand-button ${t ? "parade-hand-button--selected" : ""}`,
		children: [/* @__PURE__ */ b("span", {
			ref: p,
			className: "parade-hand-card-wrap",
			style: d ? { visibility: "hidden" } : void 0,
			children: /* @__PURE__ */ b(H, { card: e })
		}), i && /* @__PURE__ */ b("span", {
			className: `parade-hand-tag ${t ? "parade-hand-tag--discard" : ""}`,
			children: l(t ? "games.parade.discardTag" : "games.parade.keepTag")
		})]
	});
}
function se({ player: e, member: t, isMe: n, isTurn: r, phase: i, name: a, panel: o }) {
	let c = f(), { ref: l } = s(`collect:${e.rid}`);
	return /* @__PURE__ */ x("div", {
		ref: l,
		className: `parade-score-row ${n ? "parade-score-row--me" : ""} ${o ? "parade-score-row--panel" : ""}`,
		children: [/* @__PURE__ */ x("span", {
			className: "parade-player-name",
			children: [
				r && /* @__PURE__ */ b("span", {
					className: "parade-turn-mark",
					"aria-hidden": "true",
					children: "◆"
				}),
				i === "discard" && e.discarded && /* @__PURE__ */ b("span", {
					className: "parade-done-mark",
					"aria-label": c("lobby.done"),
					children: "✓"
				}),
				t && !t.online && /* @__PURE__ */ b(m, {
					size: 12,
					"aria-label": c("lobby.offline")
				}),
				/* @__PURE__ */ b("span", {
					className: "parade-player-name-text",
					title: a,
					children: a
				})
			]
		}), Array.from({ length: 6 }, (t, n) => /* @__PURE__ */ b(J, {
			rid: e.rid,
			color: n,
			cards: e.collected.filter((e) => A(e) === n)
		}, n))]
	});
}
function J({ rid: e, color: t, cards: n }) {
	let r = f(), { ref: i } = s(`collect-color:${e}:${t}`), a = n.reduce((e, t) => e + j(t), 0), o = B[t];
	return /* @__PURE__ */ x("span", {
		ref: i,
		className: "parade-score-cell",
		role: "img",
		"aria-label": r("games.parade.cellAria", {
			color: r(V[t]),
			count: n.length,
			sum: a
		}),
		style: {
			backgroundColor: o.soft,
			borderColor: o.accent,
			color: o.ink
		},
		children: [/* @__PURE__ */ x("span", {
			className: "parade-score-count",
			children: ["×", n.length]
		}), n.length > 0 ? /* @__PURE__ */ b("b", {
			className: "parade-point-seal",
			children: a
		}) : /* @__PURE__ */ b("span", {
			className: "parade-point-empty",
			children: "—"
		})]
	});
}
function ce({ cards: e, selectedCard: t, takenIds: n, settleTakenIds: r, skippedStart: i }) {
	let { gridRef: a, columns: o } = K(e.length), s = Math.ceil((e.length + 1) / o), c = (e) => {
		let t = Math.floor(e / o), n = e % o;
		return {
			row: t,
			col: t % 2 == 0 ? n : o - 1 - n
		};
	}, l = Array.from({ length: e.length + 1 }, (e, t) => {
		let { row: n, col: r } = c(t);
		return `${t === 0 ? "M" : "L"}${r + .5} ${n + .5}`;
	}).join(" "), u = {
		"--parade-columns": o,
		"--parade-rows": s
	}, d = c(e.length), f = -1;
	for (let t = e.length - 1; t >= 0; --t) if (e[t] !== null) {
		f = t;
		break;
	}
	return /* @__PURE__ */ x("div", {
		ref: a,
		className: "parade-queue-grid",
		style: u,
		children: [
			/* @__PURE__ */ x("svg", {
				className: "parade-route",
				viewBox: `0 0 ${o} ${s}`,
				preserveAspectRatio: "none",
				"aria-hidden": "true",
				children: [/* @__PURE__ */ b("path", {
					d: l,
					className: "parade-route-shadow"
				}), /* @__PURE__ */ b("path", {
					d: l,
					className: "parade-route-gold"
				})]
			}),
			e.map((e, a) => {
				let { row: o, col: s } = c(a);
				if (e === null) return /* @__PURE__ */ b(ue, {
					index: a,
					row: o,
					col: s
				}, `x${a}`);
				let l = r.has(e) ? "take" : t === null ? null : a >= i ? "skip" : n.has(e) ? "take" : null;
				return /* @__PURE__ */ b(de, {
					card: e,
					index: a,
					row: o,
					col: s,
					state: l,
					isFront: a === 0,
					isBack: a === f
				}, e);
			}),
			/* @__PURE__ */ b("span", {
				className: `parade-queue-slot parade-queue-slot--pending ${t === null ? "parade-queue-slot--empty" : ""}`,
				style: {
					gridColumn: d.col + 1,
					gridRow: d.row + 1
				},
				children: /* @__PURE__ */ b("span", {
					className: "parade-queue-card-wrap",
					children: t === null ? /* @__PURE__ */ b("span", {
						className: "parade-tail-empty",
						"aria-hidden": "true"
					}) : /* @__PURE__ */ b(le, { card: t })
				})
			})
		]
	});
}
function le({ card: e }) {
	let t = f();
	return /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b(H, { card: e }), /* @__PURE__ */ b("span", {
		className: "parade-pending-badge",
		children: t("games.parade.pendingTag")
	})] });
}
function ue({ index: e, row: t, col: n }) {
	let { ref: r } = s(`pslot:${e}`);
	return /* @__PURE__ */ b("span", {
		className: "parade-queue-slot",
		style: {
			gridColumn: n + 1,
			gridRow: t + 1
		},
		children: /* @__PURE__ */ b("span", {
			ref: r,
			className: "parade-queue-card-wrap",
			children: /* @__PURE__ */ b("span", {
				className: "parade-tail-empty",
				"aria-hidden": "true"
			})
		})
	});
}
function de({ card: e, index: t, row: n, col: a, state: o, isFront: c, isBack: u }) {
	let d = f(), p = l(), { ref: m } = s(`pslot:${t}`), { ref: h, hidden: ee } = s(`pcard:${e}`), g = i(null), _ = i(null);
	return r(() => {
		let e = g.current;
		if (!e) return;
		let t = e.getBoundingClientRect(), n = _.current;
		if (_.current = {
			x: t.left,
			y: t.top,
			w: t.width
		}, p || !n || n.w === 0 || t.width === 0 || Math.abs(n.w - t.width) > 1) return;
		let r = n.x - t.left, i = n.y - t.top;
		Math.abs(r) < 1 && Math.abs(i) < 1 || e.animate([{ transform: `translate(${r}px, ${i}px)` }, { transform: "none" }], {
			duration: k.advance,
			easing: "cubic-bezier(.3,.7,.25,1)"
		});
	}), /* @__PURE__ */ b("span", {
		ref: g,
		className: `parade-queue-slot ${o ? `parade-queue-slot--${o}` : ""}`,
		style: {
			gridColumn: a + 1,
			gridRow: n + 1
		},
		children: /* @__PURE__ */ x("span", {
			ref: (e) => {
				m(e), h(e);
			},
			className: "parade-queue-card-wrap",
			style: ee ? { visibility: "hidden" } : void 0,
			children: [
				/* @__PURE__ */ b(H, { card: e }),
				o && /* @__PURE__ */ b("span", {
					className: "parade-queue-badge",
					children: d(o === "take" ? "games.parade.takeTag" : "games.parade.skipTag")
				}),
				c && /* @__PURE__ */ b("span", {
					className: "parade-end-marker parade-end-marker--front",
					children: d("games.parade.frontLabel")
				}),
				u && /* @__PURE__ */ b("span", {
					className: "parade-end-marker parade-end-marker--back",
					children: d("games.parade.backLabel")
				})
			]
		})
	});
}
//#endregion
//#region src/games/parade/bot.ts
function Y(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function X(e, t, n) {
	return N(n, e.players.filter((e) => e.rid !== t).map((e) => e.collected), e.players.length === 2);
}
var fe = (e, t) => {
	let n = e.public, r = n.players.find((e) => e.rid === t.rid);
	if (!r) return null;
	if (n.phase === "discard") {
		if (r.discarded) return null;
		let i = e.private?.hand ?? [];
		if (i.length < 2) return null;
		let a = [];
		for (let e = 0; e < i.length; e += 1) for (let t = e + 1; t < i.length; t += 1) a.push([i[e], i[t]]);
		if (t.difficulty === "weak") return { action: {
			type: "discard",
			cards: Y(a)
		} };
		let o = a[0], s = Infinity;
		for (let e of a) {
			let a = i.filter((t) => t !== e[0] && t !== e[1]), c = X(n, t.rid, [...r.collected, ...a]);
			c < s && (s = c, o = e);
		}
		return { action: {
			type: "discard",
			cards: o
		} };
	}
	if (n.settle || n.phase !== "play" || n.turn !== t.rid) return null;
	let i = e.private?.hand ?? [];
	if (i.length === 0) return null;
	if (t.difficulty === "weak") return { action: {
		type: "play",
		card: Y(i)
	} };
	let a = X(n, t.rid, r.collected), o = i[0], s = Infinity;
	for (let e of i) {
		let i = M(n.parade, e), c = X(n, t.rid, [...r.collected, ...i]) - a;
		c < s && (s = c, o = e);
	}
	return { action: {
		type: "play",
		card: o
	} };
}, pe = [
	"games.parade.colorRed",
	"games.parade.colorBlue",
	"games.parade.colorPurple",
	"games.parade.colorGreen",
	"games.parade.colorGrey",
	"games.parade.colorOrange"
], me = (e, t, n) => {
	let r = (e) => n("games.parade.cardName", {
		color: n(pe[A(e)]),
		n: j(e)
	});
	return e.type === "discard" ? n("games.parade.hintDiscard", {
		cardA: r(e.cards[0]),
		cardB: r(e.cards[1])
	}) : e.type === "play" ? n("games.parade.hintPlay", { card: r(e.card) }) : "";
};
//#endregion
//#region src/games/parade/fx.tsx
function Z(e, t) {
	if (!e || e.w <= 0 || e.h <= 0) return null;
	let n = Math.min(e.w, e.h * 50 / 78, t?.w ?? Infinity, (t?.h ?? Infinity) * 50 / 78), r = n * 78 / 50;
	return {
		x: e.x + (e.w - n) / 2,
		y: e.y + (e.h - r) / 2,
		w: n,
		h: r
	};
}
function he({ card: e, from: t, motion: n }) {
	let a = i(null), { fromQueue: o, toQueue: s, ms: c, delay: l = 0 } = n;
	return r(() => {
		let t = a.current?.querySelector("text");
		if (!t) return;
		let n = j(e) === 10 ? 23 : 28, r = t.animate([{
			fontSize: `${o ? 30 : n}px`,
			transform: `translateY(${o ? 2 : 0}px)`
		}, {
			fontSize: `${s ? 30 : n}px`,
			transform: `translateY(${s ? 2 : 0}px)`
		}], {
			duration: c,
			delay: l,
			easing: "cubic-bezier(.3,.7,.25,1)",
			fill: "both"
		});
		return () => r.cancel();
	}, [
		e,
		o,
		s,
		c,
		l
	]), /* @__PURE__ */ b("div", {
		ref: a,
		style: {
			width: t.w,
			height: t.h
		},
		children: /* @__PURE__ */ b(H, { card: e })
	});
}
function Q(e, t, n) {
	return n ? /* @__PURE__ */ b(he, {
		card: e,
		from: t,
		motion: n
	}) : /* @__PURE__ */ b("div", {
		style: {
			width: t.w,
			height: t.h
		},
		children: /* @__PURE__ */ b(H, { card: e })
	});
}
function ge(e) {
	return /* @__PURE__ */ b("div", {
		style: {
			width: e.w,
			height: e.h
		},
		children: /* @__PURE__ */ b(ie, {})
	});
}
function _e(e, t, n, r) {
	let i = t !== void 0 && t === e.myRid;
	if (i) {
		let t = Z(e.anchor(`hcard:${n}`) ?? e.anchor(`hsource:${n}`));
		if (t) return t;
	}
	let a = Z(e.anchor("hand")) ?? r;
	return Z(i ? e.anchor("hand") : t ? e.anchor(`collect:${t}`) : null, a) ?? Z(e.anchor("deck"));
}
function $(e, t, n, r) {
	return t ? Z((n === void 0 ? null : e.anchor(`collect-color:${t}:${A(n)}`)) ?? e.anchor(`collect:${t}`), r ?? Z(e.anchor("hand"))) : null;
}
var ve = {
	dealParade(e, t) {
		let n = e.data;
		if (!Array.isArray(n?.cards)) return null;
		let r = Z(t.anchor("deck"));
		if (!r) return null;
		let i = n.cards, a = t.anchor("parade:large-queue") !== null, o = [], s = [];
		for (let [e, n] of i.entries()) {
			let i = Z(t.anchor(`pcard:${n}`) ?? t.anchor(`pslot:${e}`));
			i && (s.push(`pcard:${n}`), o.push(/* @__PURE__ */ b(S, {
				from: r,
				to: i,
				ms: 420,
				delay: e * 90,
				children: Q(n, r, a ? {
					fromQueue: !1,
					toQueue: !0,
					ms: 420,
					delay: e * 90
				} : void 0)
			}, n)));
		}
		return o.length ? {
			ms: 420 + o.length * 90,
			node: o,
			hide: t.queued > 0 ? void 0 : s
		} : null;
	},
	deal(e, t) {
		let n = Z(t.anchor("deck"));
		if (!n) return null;
		let r = e.secret;
		if (r && Array.isArray(r.cards)) {
			let e = [], i = [];
			for (let [a, o] of r.cards.entries()) {
				let r = Z(t.anchor(`hcard:${o}`) ?? t.anchor("hand"));
				r && (i.push(`hcard:${o}`), e.push(/* @__PURE__ */ b(S, {
					from: n,
					to: r,
					ms: 360,
					delay: a * 70,
					children: Q(o, n)
				}, o)));
			}
			return e.length ? {
				ms: 360 + e.length * 70,
				node: e,
				hide: t.queued > 0 ? void 0 : i
			} : null;
		}
		let i = $(t, e.rid);
		if (!i) return null;
		let a = e.data?.count, o = typeof a == "number" ? a : 5;
		return {
			ms: 360 + o * 70,
			node: Array.from({ length: o }, (e, t) => /* @__PURE__ */ b(S, {
				from: n,
				to: i,
				ms: 360,
				delay: t * 70,
				children: ge(n)
			}, t))
		};
	},
	play(e, t) {
		let n = e.data;
		if (typeof n?.card != "number") return null;
		let r = Z(t.anchor(`pcard:${n.card}`));
		if (!r) return null;
		let i = _e(t, e.rid, n.card, r);
		if (!i) return null;
		let a = t.queued > 0, o = a ? Math.round(k.place / 2) : k.place;
		return {
			ms: o,
			node: /* @__PURE__ */ b(S, {
				from: i,
				to: r,
				ms: o,
				children: Q(n.card, i, t.anchor("parade:large-queue") ? {
					fromQueue: !1,
					toQueue: !0,
					ms: o
				} : void 0)
			}),
			hide: a ? void 0 : [`pcard:${n.card}`]
		};
	},
	take(e, t) {
		let n = e.data;
		if (!Array.isArray(n?.taken) || !Array.isArray(n.slots)) return null;
		let r = n.taken, i = n.slots, a = r.length, o = t.queued > 0 ? Math.round(k.take / 2) : k.take, s = a > 1 ? Math.min(60, Math.max(0, o - 420) / (a - 1)) : 0, c = Math.max(200, o - s * (a - 1)), l = t.anchor("parade:large-queue") !== null, u = [];
		for (let n = 0; n < a; n += 1) {
			let a = Z(t.anchor(`pslot:${i[n]}`));
			if (!a) continue;
			let o = $(t, e.rid, r[n], a);
			o && u.push(/* @__PURE__ */ b(S, {
				from: a,
				to: o,
				ms: c,
				delay: n * s,
				children: Q(r[n], a, l ? {
					fromQueue: !0,
					toQueue: !1,
					ms: c,
					delay: n * s
				} : void 0)
			}, r[n]));
		}
		return u.length ? {
			ms: o,
			node: u
		} : null;
	},
	draw(e, t) {
		let n = Z(t.anchor("deck"));
		if (!n) return null;
		let r = e.secret;
		if (typeof r?.card == "number") {
			let e = Z(t.anchor(`hcard:${r.card}`) ?? t.anchor("hand"));
			return e ? {
				ms: 450,
				node: /* @__PURE__ */ b(S, {
					from: n,
					to: e,
					ms: 450,
					children: Q(r.card, n)
				}),
				hide: t.queued > 0 ? void 0 : [`hcard:${r.card}`]
			} : null;
		}
		let i = $(t, e.rid);
		return i ? {
			ms: 450,
			node: /* @__PURE__ */ b(S, {
				from: n,
				to: i,
				ms: 450,
				children: ge(n)
			})
		} : null;
	},
	discard(e, t) {
		let n = e.secret;
		if (!Array.isArray(n?.kept) || e.rid !== t.myRid) return null;
		let r = n.kept, i = r.flatMap((n, r) => {
			let i = Z(t.anchor(`hcard:${n}`) ?? t.anchor(`hsource:${n}`) ?? t.anchor("hand"));
			if (!i) return [];
			let a = $(t, e.rid, n, i);
			return a ? [/* @__PURE__ */ b(S, {
				from: i,
				to: a,
				ms: 420,
				delay: r * 90,
				children: Q(n, i)
			}, n)] : [];
		});
		return i.length ? {
			ms: 420 + r.length * 90,
			node: i
		} : null;
	}
};
//#endregion
//#region src/games/parade/game-over.tsx
function ye({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	let s = f(), c = d((e) => e.locale), l = t.players.map((e) => ({
		rid: e.rid,
		colors: Array.from({ length: 6 }, (t, n) => e.collected.filter((e) => A(e) === n))
	})), p = l.length === 2, m = Array.from({ length: 6 }, (e, t) => Math.max(0, ...l.map((e) => e.colors[t].length))), h = e.ranking.map((t, r) => {
		let i = n.find((e) => e.rid === t), a = i ? o(t) === null ? i.name : u(c, i.avatar) : t, s = l.find((e) => e.rid === t), d = l.filter((e) => e.rid !== t), f = Array.from({ length: 6 }, (e, t) => {
			let n = s?.colors[t] ?? [], r = n.length, i = d.map((e) => e.colors[t].length), a = r > 0 && r === m[t], o = a && (!p || r - (i[0] ?? 0) >= 2);
			return {
				count: r,
				sum: n.reduce((e, t) => e + j(t), 0),
				score: N(n, d.map((e) => e.colors[t]), p),
				most: a,
				majority: o
			};
		});
		return {
			rid: t,
			rank: r + 1,
			name: a,
			stats: f,
			score: e.scores?.[t] ?? f.reduce((e, t) => e + t.score, 0)
		};
	});
	return /* @__PURE__ */ b(v, {
		adaptive: !0,
		className: "parade-over-adaptive",
		scroll: !1,
		children: /* @__PURE__ */ x("div", {
			className: "parade-over",
			style: { "--parade-over-players": h.length },
			children: [/* @__PURE__ */ x("div", {
				className: "parade-over-panel",
				children: [/* @__PURE__ */ x("header", {
					className: "parade-over-heading",
					children: [/* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("span", {
						className: "parade-over-kicker",
						children: s("games.parade.name")
					}), /* @__PURE__ */ b("h1", { children: s("games.parade.overTitle") })] }), /* @__PURE__ */ b("span", {
						className: "parade-over-moon",
						"aria-hidden": "true"
					})]
				}), /* @__PURE__ */ b("div", {
					className: "parade-over-scroll",
					children: /* @__PURE__ */ x("table", {
						className: "parade-over-table",
						children: [
							/* @__PURE__ */ b("caption", {
								className: "sr-only",
								children: s("games.parade.collectedLabel")
							}),
							/* @__PURE__ */ b("thead", { children: /* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ b("th", {
								scope: "col",
								className: "parade-over-person-head",
								"aria-label": s("session.result.title"),
								children: "#"
							}), B.map((e, t) => /* @__PURE__ */ b("th", {
								scope: "col",
								className: "parade-over-color-head",
								"aria-label": s(V[t]),
								style: {
									backgroundColor: e.soft,
									borderColor: e.accent
								},
								children: /* @__PURE__ */ b("span", {
									className: "parade-over-color-dot",
									style: {
										backgroundColor: e.accent,
										borderColor: e.ink
									}
								})
							}, t))] }) }),
							/* @__PURE__ */ b("tbody", { children: h.map((t) => /* @__PURE__ */ x("tr", {
								className: e.winner.includes(t.rid) ? "parade-over-winner" : void 0,
								children: [/* @__PURE__ */ x("th", {
									scope: "row",
									className: "parade-over-person",
									children: [
										/* @__PURE__ */ x("span", {
											className: "parade-over-identity",
											children: [/* @__PURE__ */ b("span", {
												className: "parade-over-rank",
												children: t.rank
											}), /* @__PURE__ */ b("span", {
												className: "parade-over-name",
												title: t.name,
												children: t.name
											})]
										}),
										/* @__PURE__ */ b("span", {
											className: "parade-over-total",
											"aria-label": `${s("games.parade.pointsLegend")} ${t.score}`,
											children: t.score
										}),
										t.rid === r && /* @__PURE__ */ b("span", {
											className: "parade-over-me",
											children: s("lobby.you")
										})
									]
								}), t.stats.map((e, t) => {
									let n = B[t], r = s(V[t]), i = {
										"--parade-over-accent": n.accent,
										backgroundColor: n.soft,
										color: n.ink
									};
									return /* @__PURE__ */ x("td", {
										className: `parade-over-cell ${e.most ? "parade-over-cell--most" : ""}`,
										style: i,
										"aria-label": `${s("games.parade.cellAria", {
											color: r,
											count: e.count,
											sum: e.sum
										})}, ${s("games.parade.pointsLegend")} ${e.score}${e.most ? `, ${s("games.parade.overMostAria")}` : ""}${e.majority ? `, ${s("games.parade.overScoringAria")}` : ""}`,
										children: [
											/* @__PURE__ */ x("span", {
												className: "parade-over-count",
												children: ["×", e.count]
											}),
											e.most && /* @__PURE__ */ b("span", {
												className: "parade-over-star",
												"aria-hidden": "true",
												children: "★"
											}),
											/* @__PURE__ */ x("span", {
												className: "parade-over-sum",
												children: ["Σ", e.sum]
											}),
											/* @__PURE__ */ b("strong", {
												className: `parade-over-points ${e.majority ? "parade-over-points--majority" : ""} ${e.count === 0 ? "parade-over-points--empty" : ""}`,
												children: e.score
											})
										]
									}, t);
								})]
							}, t.rid)) })
						]
					})
				})]
			}), /* @__PURE__ */ x("div", {
				className: "parade-over-actions",
				children: [
					i && /* @__PURE__ */ b("button", {
						type: "button",
						className: "parade-over-play",
						onClick: i,
						children: s("session.result.playAgain")
					}),
					a && /* @__PURE__ */ b("button", {
						type: "button",
						className: "parade-over-back",
						onClick: a,
						children: s("session.result.backToLobby")
					}),
					!i && !a && /* @__PURE__ */ b("p", {
						className: "parade-over-wait",
						children: s("session.result.waitHost")
					})
				]
			})]
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/parade/entry.tsx
var be = {
	definition: z,
	View: W,
	bot: fe,
	describe: me,
	fx: ve,
	OverView: ye,
	locales: {
		zh: {
			name: "仙境梦游",
			desc: "把牌接进游行队伍,别被迫收走太多——分数最低者胜",
			rules: "目标:终局计分后总分最低者获胜。分数来自面前收走的牌,收牌越少越好。\n准备:\n· 牌共 66 张,分 6 种颜色,每色 11 张,面值从 0 到 10。\n· 每人获得 5 张手牌;桌面翻出 6 张排成一列作为游行队伍。\n· 队伍一端是队首,另一端是队尾。\n流程:\n· 轮到你时,从手牌中选 1 张放到队尾,再从摸牌堆摸 1 张补回手牌。\n· 队伍原有张数大于打出牌的面值时触发收牌:从队尾向队首跳过与面值等量的牌。\n· 更早入队的牌进入离队判定;张数不超过面值时无人离队。\n· 进入离队判定的牌中,与打出牌同色的牌全部被你收走,放到面前按颜色分列。\n· 面值小于或等于打出牌面值的牌也同样被你收走。\n· 打出面值 0 的牌时,全队都进入离队判定。\n结束:\n· 有玩家面前集齐 6 种颜色,或摸牌堆耗尽时,进入最后一轮。\n· 最后一轮包括触发者在内,每人再出 1 张牌,不再摸牌。\n· 最后一轮结束后,每人从手牌中选 2 张弃置,剩余 2 张加入面前。\n计分:\n· 逐色比较面前该色的张数:张数最多的玩家(可并列)该色每张只计 1 分。\n· 其余玩家该色的牌按面值计分;二人局须比对方多至少 2 张才算最多。\n· 总分最低者获胜;平分则面前总牌数更少者获胜。",
			colorRed: "红",
			colorBlue: "蓝",
			colorPurple: "紫",
			colorGreen: "绿",
			colorGrey: "灰",
			colorOrange: "橙",
			cardName: "{{color}} {{n}}",
			playPrompt: "选 1 张手牌放到队尾",
			waitingTurn: "等 {{name}} 出牌…",
			settling: "{{name}} 的收牌结算中…",
			finalRound: "最后一轮",
			deckLeft: "牌堆 {{n}}",
			paradeLabel: "游行队伍",
			queueCount: "全队 {{n}} 张",
			frontLabel: "队首",
			backLabel: "队尾",
			collectedLabel: "收牌概览",
			countLegend: "张数",
			pointsLegend: "点数",
			details: "明细",
			detailsTitle: "公开收牌明细",
			closeDetails: "关闭收牌明细",
			detailColorAria: "{{color}}色的收牌",
			lastPlayEmpty: "还没有人出牌",
			lastPlayNone: "{{name}} 打出 {{card}},无人离队",
			lastPlayTaken: "{{name}} 打出 {{card}},收走 {{n}} 张",
			previewNone: "打出 {{card}}:无人离队",
			previewTake: "打出 {{card}}:将收走 {{n}} 张牌",
			previewSkip: "队尾 {{n}} 张跳过；再点已选牌取消",
			confirmPlay: "打出",
			cancelPick: "重选",
			discardPrompt: "选 2 张手牌弃置,其余加入面前",
			discardWaiting: "已弃置,等其他人…",
			confirmDiscard: "弃置这 2 张",
			discardReady: "将弃置选中的 2 张牌",
			discardHelp: "其余手牌会加入面前收牌区",
			discardTag: "弃",
			keepTag: "留",
			handTray: "手牌 {{n}} 张 · 选牌接入队尾",
			skipTag: "跳",
			takeTag: "收",
			pendingTag: "待出",
			handCount: "手牌 {{n}}",
			cellAria: "{{color}}:{{count}} 张共 {{sum}} 点",
			collectedCount: "{{n}} 张",
			overTitle: "游行落幕",
			overMostAria: "本色张数最多",
			overScoringAria: "按张数计分",
			errNotYourTurn: "现在轮不到你",
			errBadCard: "这张牌不在你手里",
			errBadDiscard: "要恰好选 2 张手牌弃置",
			hintPlay: "打出 {{card}}",
			hintDiscard: "弃置 {{cardA}} 和 {{cardB}}"
		},
		en: {
			name: "Parade",
			desc: "Play cards into the parade and avoid collecting them — lowest score wins",
			rules: "Goal: After final scoring, the lowest total wins. Points come from the cards collected in front of you.\nSetup:\n· There are 66 cards in 6 colors, 11 cards per color, with values from 0 to 10.\n· Each player receives 5 hand cards; 6 cards are revealed in a row as the parade.\n· One end of the parade is the front and the other end is the back.\nPlay:\n· On your turn, play 1 card from your hand to the back of the parade, then draw 1 card.\n· If the parade had more cards than the played card’s value, cards are taken: skip that many cards from the back.\n· The earlier cards enter the leaving check; if the parade was short enough, nothing leaves.\n· Among the cards in the leaving check, you collect every card of the played card’s color.\n· You also collect every card with a value less than or equal to the played card.\n· When a card with value 0 is played, the whole parade enters the leaving check.\nEnd:\n· When a player has collected all 6 colors, or the draw pile runs out, the final round begins.\n· In the final round, everyone, including that player, plays 1 more card without drawing.\n· Afterwards, each player discards 2 cards from hand; the remaining 2 join the collected cards.\nScoring:\n· For each color, the player with the most cards of it (ties included) scores only 1 point per card.\n· All other players score the printed values; with 2 players you need at least 2 more cards to have the most.\n· The lowest total wins; on a tie, the player with fewer collected cards wins.",
			colorRed: "Red",
			colorBlue: "Blue",
			colorPurple: "Purple",
			colorGreen: "Green",
			colorGrey: "Grey",
			colorOrange: "Orange",
			cardName: "{{color}} {{n}}",
			playPrompt: "Play 1 card from your hand to the back",
			waitingTurn: "Waiting for {{name}} to play…",
			settling: "Resolving {{name}}'s collection…",
			finalRound: "Final round",
			deckLeft: "Deck {{n}}",
			paradeLabel: "Parade",
			queueCount: "{{n}} in parade",
			frontLabel: "Front",
			backLabel: "Back",
			collectedLabel: "Collected cards",
			countLegend: "count",
			pointsLegend: "points",
			details: "Details",
			detailsTitle: "Public collected cards",
			closeDetails: "Close collected cards",
			detailColorAria: "Collected {{color}} cards",
			lastPlayEmpty: "No one has played yet",
			lastPlayNone: "{{name}} played {{card}}; nothing left the parade",
			lastPlayTaken: "{{name}} played {{card}} and collected {{n}} cards",
			previewNone: "Play {{card}}: nothing leaves the parade",
			previewTake: "Play {{card}}: you will collect {{n}} cards",
			previewSkip: "Skip {{n}} from the back; tap the selected card to cancel",
			confirmPlay: "Play",
			cancelPick: "Reselect",
			discardPrompt: "Choose 2 hand cards to discard; the rest join your collected cards",
			discardWaiting: "Discarded. Waiting for others…",
			confirmDiscard: "Discard these 2",
			discardReady: "Discard the 2 selected cards",
			discardHelp: "The remaining cards join your collection",
			discardTag: "Out",
			keepTag: "Keep",
			handTray: "{{n}} in hand · choose one to play",
			skipTag: "Skip",
			takeTag: "Take",
			pendingTag: "Play",
			handCount: "Hand {{n}}",
			cellAria: "{{color}}: {{count}} cards, {{sum}} points",
			collectedCount: "{{n}} cards",
			overTitle: "The Parade Ends",
			overMostAria: "Most cards of this color",
			overScoringAria: "Scores by card count",
			errNotYourTurn: "Not your turn right now",
			errBadCard: "That card is not in your hand",
			errBadDiscard: "Choose exactly 2 hand cards to discard",
			hintPlay: "Play {{card}}",
			hintDiscard: "Discard {{cardA}} and {{cardB}}"
		}
	}
};
//#endregion
export { be as default };
