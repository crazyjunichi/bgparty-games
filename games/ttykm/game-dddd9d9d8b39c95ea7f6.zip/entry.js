import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { PhaseBanner as u } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as d, seatName as f } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { Floater as _, FlySprite as v, PulseBox as y } from "@bgparty/sdk/fx/primitives";
import { IconBack as b, IconBot as x, IconExpand as S, IconLog as C } from "@bgparty/sdk/icons";
import { Confetti as ee } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as w, OptionSection as T } from "@bgparty/sdk/ui/game-options";
//#region src/games/ttykm/meta.ts
var E = {
	id: "ttykm",
	tier: "alpha",
	mechanics: ["grid-movement", "action-points"],
	interactionTags: [],
	nameKey: "games.ttykm.name",
	descKey: "games.ttykm.desc",
	rulesKey: "games.ttykm.rules",
	icon: "⏳",
	iconImg: "games/ttykm.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/ttykm/en.pdf" },
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#0f766e",
	releasedAt: "2026-09-16",
	search: {
		py: "sha you qi shi",
		init: "syqs"
	},
	hotseat: "cover"
}, D = t.union([
	t.literal(0),
	t.literal(1),
	t.literal(2)
]), O = t.enum([
	"N",
	"S",
	"E",
	"W"
]), k = t.union([t.literal(0), t.literal(1)]), A = t.int().min(0).max(15), j = t.object({
	era: D,
	cell: A
}), M = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("select"),
		cell: A
	}),
	t.object({
		type: t.literal("move"),
		dir: O,
		pull: O.optional()
	}),
	t.object({
		type: t.literal("travel"),
		to: t.enum(["forward", "backward"])
	}),
	t.object({
		type: t.literal("plant"),
		cell: A
	}),
	t.object({
		type: t.literal("unplant"),
		cell: A
	}),
	t.object({
		type: t.literal("build"),
		cell: A
	}),
	t.object({
		type: t.literal("train"),
		cell: A
	}),
	t.object({
		type: t.literal("command"),
		dir: O
	}),
	t.object({
		type: t.literal("focus"),
		era: D
	})
]), N = t.object({
	chapter: t.union([
		t.literal(0),
		t.literal(1),
		t.literal(2),
		t.literal(3)
	]).catch(1),
	sideAssign: t.enum([
		"random",
		"hostWhite",
		"hostBlack"
	]).catch("random")
}).default({
	chapter: 1,
	sideAssign: "random"
}), P = t.object({
	seeds: t.array(t.array(A)),
	shrubs: t.array(t.array(A)),
	trees: t.array(t.array(A)),
	fallen: t.array(t.array(t.object({
		cell: A,
		from: A
	}))),
	supply: t.object({
		seed: t.int().nonnegative(),
		shrub: t.int().nonnegative(),
		tree: t.int().nonnegative()
	})
}), te = t.object({
	pieces: t.array(t.object({
		owner: k.nullable(),
		cells: t.array(A.nullable())
	})),
	builtUsed: t.tuple([t.boolean(), t.boolean()])
}), ne = t.object({
	pieces: t.array(t.object({
		kind: t.enum(["dark", "light"]),
		cells: t.array(t.object({
			cell: A,
			hat: k.nullable()
		}))
	})),
	hats: t.tuple([t.int().nonnegative(), t.int().nonnegative()])
}), F = t.object({
	chapter: t.union([
		t.literal(0),
		t.literal(1),
		t.literal(2),
		t.literal(3)
	]),
	seats: t.tuple([t.string(), t.string()]),
	turn: k,
	phase: t.enum([
		"select",
		"act",
		"focus",
		"done"
	]),
	focus: t.tuple([D, D]),
	active: j.nullable(),
	actionsLeft: t.int().min(0).max(2),
	copies: t.tuple([t.array(j), t.array(j)]),
	supply: t.tuple([t.int().nonnegative(), t.int().nonnegative()]),
	plants: P.nullable(),
	statues: te.nullable(),
	elephants: ne.nullable(),
	winner: k.nullable()
}), I = t.object({}), L = [
	"N",
	"S",
	"E",
	"W"
], re = {
	N: "S",
	S: "N",
	E: "W",
	W: "E"
};
function R(e, t) {
	let n = Math.floor(e / 4), r = e % 4;
	return t === "N" && n > 0 ? (n - 1) * 4 + r : t === "S" && n < 3 ? (n + 1) * 4 + r : t === "W" && r > 0 ? n * 4 + (r - 1) : t === "E" && r < 3 ? n * 4 + (r + 1) : null;
}
function z(e) {
	let t = [e];
	for (let n of L) {
		let r = R(e, n);
		r !== null && t.push(r);
	}
	return t;
}
function ie(e) {
	return {
		chapter: e.chapter,
		copies: e.copies.map((e) => e.map((e, t) => ({
			...e,
			id: t
		}))),
		supply: [...e.supply],
		plants: e.plants ? structuredClone(e.plants) : null,
		statues: e.statues ? structuredClone(e.statues) : null,
		elephants: e.elephants ? structuredClone(e.elephants) : null
	};
}
var B = (e, t, n) => {
	for (let r of [0, 1]) {
		let i = e.copies[r].find((e) => e.era === t && e.cell === n);
		if (i) return {
			side: r,
			piece: i
		};
	}
	return null;
}, V = (e, t, n) => e.plants?.seeds[t]?.includes(n) ?? !1, H = (e, t, n) => e.plants?.shrubs[t]?.includes(n) ?? !1, U = (e, t, n) => e.plants?.trees[t]?.includes(n) ?? !1, W = (e, t, n) => e.plants?.fallen[t]?.some((e) => e.cell === n) ?? !1, G = (e, t, n) => {
	if (!e.statues) return null;
	let r = e.statues.pieces.findIndex((e) => e.cells[t] === n);
	return r >= 0 ? r : null;
}, K = (e, t, n) => {
	if (!e.elephants) return null;
	let r = e.elephants.pieces.findIndex((e) => e.cells[t].cell === n);
	return r >= 0 ? r : null;
}, ae = (e, t, n) => !B(e, t, n) && !H(e, t, n) && !U(e, t, n) && !W(e, t, n) && G(e, t, n) === null && K(e, t, n) === null;
function q(e, t, n, r) {
	let i = e.bd.copies[t], a = i.indexOf(n);
	a >= 0 && i.splice(a, 1), e.fx.push({
		kind: "kill",
		data: {
			era: e.era,
			cell: n.cell,
			side: t,
			cause: r
		}
	});
}
function oe(e, t, n) {
	let r = e.bd.plants;
	if (!r) return;
	let i = r.seeds[t].indexOf(n);
	i < 0 || (r.seeds[t].splice(i, 1), r.supply.seed += 1, e.fx.push({
		kind: "ungrow",
		data: {
			era: t,
			cell: n,
			what: "seed"
		}
	}), t < 2 && r.shrubs[t + 1].includes(n) && se(e, t + 1, n));
}
function se(e, t, n) {
	let r = e.bd.plants;
	if (!r) return;
	let i = r.shrubs[t].indexOf(n);
	if (!(i < 0) && (r.shrubs[t].splice(i, 1), r.supply.shrub += 1, e.fx.push({
		kind: "ungrow",
		data: {
			era: t,
			cell: n,
			what: "shrub"
		}
	}), t < 2)) {
		let i = t + 1, a = r.trees[i].indexOf(n);
		a >= 0 && (r.trees[i].splice(a, 1), r.supply.tree += 1, e.fx.push({
			kind: "ungrow",
			data: {
				era: i,
				cell: n,
				what: "tree"
			}
		}));
		let o = r.fallen[i].findIndex((e) => e.from === n);
		o >= 0 && (r.fallen[i].splice(o, 1), r.supply.tree += 1, e.fx.push({
			kind: "ungrow",
			data: {
				era: i,
				cell: r.fallen[i][o]?.cell ?? n,
				what: "fallen"
			}
		}));
	}
}
function ce(e, t, n) {
	let r = e.bd.plants;
	if (!r) return !1;
	let i = e.era, a = R(t, n);
	if (a === null || H(e.bd, i, a) || W(e.bd, i, a) || G(e.bd, i, a) !== null || K(e.bd, i, a) !== null || U(e.bd, i, a) && !ce(e, a, n)) return !1;
	V(e.bd, i, a) && oe(e, i, a);
	let o = B(e.bd, i, a);
	o && q(e, o.side, o.piece, "topple");
	let s = r.trees[i].indexOf(t);
	return r.trees[i].splice(s, 1), r.fallen[i].push({
		cell: a,
		from: t
	}), e.fx.push({
		kind: "topple",
		data: {
			era: i,
			from: t,
			to: a,
			dir: n
		}
	}), !0;
}
function J(e, t, n) {
	let r = e.bd.statues;
	if (!r) return !1;
	let i = e.era, a = r.pieces[t], o = a.cells[i];
	if (o == null) return !1;
	let s = R(o, n);
	if (s === null || H(e.bd, i, s) || W(e.bd, i, s) || K(e.bd, i, s) !== null) return !1;
	let c = G(e.bd, i, s);
	if (c !== null && c !== t && !J(e, c, n) || U(e.bd, i, s) && !ce(e, s, n)) return !1;
	let l = B(e.bd, i, s);
	return l && le(e, l.side, l.piece, n), V(e.bd, i, s) && oe(e, i, s), a.cells[i] = s, e.fx.push({
		kind: "statue",
		data: {
			owner: a.owner,
			era: i,
			from: o,
			to: s
		}
	}), i < 2 && a.cells[i + 1] !== null && J({
		...e,
		era: i + 1
	}, t, n), !0;
}
function le(e, t, n, r) {
	let i = e.era, a = R(n.cell, r);
	if (a === null) {
		q(e, t, n, "squish");
		return;
	}
	let o = B(e.bd, i, a);
	if (o) {
		if (o.side === t) {
			q(e, t, o.piece, "paradox"), q(e, t, n, "paradox");
			return;
		}
		le(e, o.side, o.piece, r), n.cell = a;
		return;
	}
	if (H(e.bd, i, a) || W(e.bd, i, a)) {
		q(e, t, n, "squish");
		return;
	}
	if (U(e.bd, i, a)) {
		ce(e, a, r) ? n.cell = a : q(e, t, n, "squish");
		return;
	}
	let s = G(e.bd, i, a);
	if (s !== null) {
		J(e, s, r) ? n.cell = a : q(e, t, n, "squish");
		return;
	}
	if (K(e.bd, i, a) !== null) {
		q(e, t, n, "squish");
		return;
	}
	n.cell = a;
}
function ue(e, t, n, r) {
	let i = e.bd.plants;
	if (r === "seed" ? (i.seeds[t].push(n), --i.supply.seed) : r === "shrub" ? (i.shrubs[t].push(n), --i.supply.shrub) : (i.trees[t].push(n), --i.supply.tree), e.fx.push({
		kind: "grow",
		data: {
			era: t,
			cell: n,
			what: r
		}
	}), t >= 2) return;
	let a = t + 1, o = r === "seed" ? "shrub" : "tree";
	V(e.bd, a, n) || H(e.bd, a, n) || U(e.bd, a, n) || W(e.bd, a, n) || G(e.bd, a, n) !== null || K(e.bd, a, n) !== null || B(e.bd, a, n) !== null || o === "shrub" && i.supply.shrub <= 0 || o === "tree" && i.supply.tree <= 0 || ue({
		...e,
		era: a
	}, a, n, o);
}
function de(e, t, n, r) {
	let i = e.copies[t][n];
	if (!i) return null;
	let a = i.era, o = [], s = {
		bd: e,
		era: a,
		fx: o
	};
	if (r.type === "move") {
		let n = R(i.cell, r.dir);
		if (n === null) return null;
		let c = B(e, a, n);
		if (c && c.side === t || H(e, a, n) || W(e, a, n) || K(e, a, n) !== null) return null;
		let l = i.cell;
		if (i.cell = n, c) le(s, c.side, c.piece, r.dir);
		else if (U(e, a, n)) {
			if (!ce(s, n, r.dir)) return null;
		} else {
			let t = G(e, a, n);
			if (t !== null && !J(s, t, r.dir)) return null;
		}
		if (o.push({
			kind: "move",
			data: {
				side: t,
				era: a,
				from: l,
				to: n
			}
		}), r.pull) {
			let t = R(l, r.pull), n = t === null ? null : G(e, a, t);
			if (n === null) return null;
			let i = e.statues.pieces[n];
			i.cells[a] = l, o.push({
				kind: "statue",
				data: {
					owner: i.owner,
					era: a,
					from: t,
					to: l
				}
			}), a < 2 && i.cells[a + 1] !== null && J({
				...s,
				era: a + 1
			}, n, re[r.pull]);
		}
		return o;
	}
	if (r.type === "travel") {
		let n = a + (r.to === "forward" ? 1 : -1);
		if (n < 0 || n > 2 || !ae(e, n, i.cell) || r.to === "backward" && e.supply[t] <= 0) return null;
		let s = {
			era: a,
			cell: i.cell
		};
		if (r.to === "backward") {
			--e.supply[t];
			let n = Math.max(-1, ...e.copies[t].map((e) => e.id)) + 1;
			e.copies[t].push({
				id: n,
				era: a,
				cell: i.cell
			});
		}
		return i.era = n, o.push({
			kind: "travel",
			data: {
				side: t,
				from: s,
				to: {
					era: n,
					cell: i.cell
				},
				back: r.to === "backward"
			}
		}), o;
	}
	if (r.type === "plant") {
		let t = e.plants;
		if (!t || t.supply.seed <= 0) return null;
		let n = r.cell;
		return !z(i.cell).includes(n) || V(e, a, n) || H(e, a, n) || U(e, a, n) || W(e, a, n) || G(e, a, n) !== null || K(e, a, n) !== null ? null : (ue(s, a, n, "seed"), o);
	}
	if (r.type === "unplant") {
		if (!e.plants) return null;
		let t = r.cell;
		return !z(i.cell).includes(t) || !V(e, a, t) ? null : (oe(s, a, t), o);
	}
	if (r.type === "build") {
		let n = e.statues;
		if (!n || n.builtUsed[t]) return null;
		let s = r.cell;
		if (s === i.cell || !z(i.cell).includes(s) || B(e, a, s) || G(e, a, s) !== null || K(e, a, s) !== null || V(e, a, s) || H(e, a, s) || U(e, a, s) || W(e, a, s)) return null;
		let c = L.find((e) => R(i.cell, e) === s);
		if (!c) return null;
		n.builtUsed[t] = !0;
		let l = [
			null,
			null,
			null
		];
		l[a] = s, n.pieces.push({
			owner: t,
			cells: l
		}), o.push({
			kind: "build",
			data: {
				owner: t,
				era: a,
				cell: s
			}
		});
		let u = n.pieces.length - 1;
		for (let n = a + 1; n <= 2; n++) {
			let r = {
				bd: e,
				era: n,
				fx: o
			}, i = B(e, n, s), a = G(e, n, s);
			if (K(e, n, s) !== null || V(e, n, s) || H(e, n, s) || U(e, n, s) || W(e, n, s)) break;
			if (i) le(r, i.side, i.piece, c);
			else if (a !== null && !J(r, a, c)) break;
			e.statues.pieces[u].cells[n] = s, o.push({
				kind: "build",
				data: {
					owner: t,
					era: n,
					cell: s
				}
			});
		}
		return o;
	}
	if (r.type === "train") {
		let n = e.elephants;
		if (!n) return null;
		let s = r.cell, c = K(e, a, s);
		if (c === null || !z(i.cell).includes(s) || s === i.cell) return null;
		let l = n.pieces[c].kind;
		for (let n = a; n <= 2; n++) {
			let r = e.elephants.pieces.find((e) => e.kind === l).cells[n];
			if (r.hat === t) {
				if (n === a) return null;
				break;
			}
			r.hat !== null && (e.elephants.hats[r.hat] += 1);
			let i = e.elephants.pieces.find((e) => e.kind !== l && e.cells[n].hat === t);
			if (i) i.cells[n].hat = null;
			else {
				if (e.elephants.hats[t] <= 0) {
					if (n === a) return null;
					break;
				}
				--e.elephants.hats[t];
			}
			r.hat = t, o.push({
				kind: "train",
				data: {
					era: n,
					kind: l,
					side: t,
					cell: r.cell
				}
			});
		}
		return o;
	}
	if (r.type === "command") {
		let n = e.elephants;
		if (!n) return null;
		let i = n.pieces.findIndex((e) => e.cells[a].hat === t);
		if (i < 0) return null;
		let c = e.elephants.pieces[i].cells[a], l = R(c.cell, r.dir);
		if (l === null || K(e, a, l) !== null) return null;
		let u = c.cell;
		c.cell = l;
		let d = B(e, a, l);
		return d && q(s, d.side, d.piece, "trample"), o.push({
			kind: "command",
			data: {
				era: a,
				kind: n.pieces[i].kind,
				from: u,
				to: l
			}
		}), o;
	}
	return null;
}
function Y(e, t, n, r) {
	let i = structuredClone(e), a = de(i, t, n, r);
	return a ? {
		bd: i,
		fx: a
	} : null;
}
function X(e, t, n) {
	let r = e.copies[t][n];
	if (!r) return [];
	let i = [];
	for (let r of L) {
		let a = {
			type: "move",
			dir: r
		};
		Y(e, t, n, a) && i.push(a);
	}
	for (let r of ["forward", "backward"]) {
		let a = {
			type: "travel",
			to: r
		};
		Y(e, t, n, a) && i.push(a);
	}
	if (e.chapter === 1) for (let a of z(r.cell)) {
		let r = {
			type: "plant",
			cell: a
		};
		Y(e, t, n, r) && i.push(r);
		let o = {
			type: "unplant",
			cell: a
		};
		Y(e, t, n, o) && i.push(o);
	}
	if (e.chapter === 2) for (let a of z(r.cell)) {
		let r = {
			type: "build",
			cell: a
		};
		Y(e, t, n, r) && i.push(r);
	}
	if (e.chapter === 3) {
		for (let a of z(r.cell)) {
			let r = {
				type: "train",
				cell: a
			};
			Y(e, t, n, r) && i.push(r);
		}
		for (let r of L) {
			let a = {
				type: "command",
				dir: r
			};
			Y(e, t, n, a) && i.push(a);
		}
	}
	return i;
}
function fe(e, t, n, r) {
	let i = Y(e, t, n, {
		type: "move",
		dir: r
	});
	if (!i) return [];
	let a = e.copies[t][n], o = a.era, s = a.cell;
	return L.filter((e) => {
		let t = R(s, e);
		return t !== null && G(i.bd, o, t) !== null;
	});
}
function pe(e, t, n) {
	return e.copies[t].map((e, t) => ({
		p: e,
		idx: t
	})).filter(({ p: e }) => e.era === n).map(({ idx: n }) => {
		let r = X(e, t, n);
		if (r.length === 0) return {
			idx: n,
			max: 0
		};
		for (let i of r) {
			let r = Y(e, t, n, i);
			if (r) {
				let i = e.copies[t][n].id, a = r.bd.copies[t].findIndex((e) => e.id === i);
				if (a >= 0 && X(r.bd, t, a).length > 0) return {
					idx: n,
					max: 2
				};
			}
		}
		return {
			idx: n,
			max: 1
		};
	});
}
var me = (e, t) => new Set(e.copies[t].map((e) => e.era)).size, Z = (e) => ({ code: e }), he = {
	move: "games.ttykm.errMove",
	travel: "games.ttykm.errTravel",
	plant: "games.ttykm.errPlant",
	unplant: "games.ttykm.errUnplant",
	build: "games.ttykm.errBuild",
	train: "games.ttykm.errTrain",
	command: "games.ttykm.errCommand"
}, ge = (e) => ({
	chapter: e.chapter,
	copies: e.copies,
	supply: e.supply,
	plants: e.plants,
	statues: e.statues,
	elephants: e.elephants
});
function _e(t, n, r) {
	let i = t.sideAssign === "hostWhite" || t.sideAssign === "random" && e(r, 0, 2) === 0 ? [n[0], n[1]] : [n[1], n[0]], a = (e) => [
		{
			id: 0,
			era: 0,
			cell: e
		},
		{
			id: 1,
			era: 1,
			cell: e
		},
		{
			id: 2,
			era: 2,
			cell: e
		}
	], o = t.chapter;
	return {
		seed: r,
		chapter: o,
		players: i,
		turn: 0,
		phase: "select",
		focus: [0, 2],
		activeId: null,
		actionsLeft: 0,
		copies: [a(0), a(15)],
		supply: [4, 4],
		plants: o === 1 ? {
			seeds: [
				[],
				[],
				[]
			],
			shrubs: [
				[],
				[],
				[]
			],
			trees: [
				[],
				[],
				[]
			],
			fallen: [
				[],
				[],
				[]
			],
			supply: {
				seed: 5,
				shrub: 5,
				tree: 5
			}
		} : null,
		statues: o === 2 ? {
			pieces: [{
				owner: null,
				cells: [
					6,
					6,
					6
				]
			}],
			builtUsed: [!1, !1]
		} : null,
		elephants: o === 3 ? {
			pieces: [{
				kind: "dark",
				cells: [
					3,
					3,
					3
				].map((e) => ({
					cell: e,
					hat: null
				}))
			}, {
				kind: "light",
				cells: [
					12,
					12,
					12
				].map((e) => ({
					cell: e,
					hat: null
				}))
			}],
			hats: [3, 3]
		} : null,
		winner: null
	};
}
var ve = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: E,
	schemas: {
		action: M,
		publicView: F,
		privateView: I,
		config: N
	},
	setup(e, t, n) {
		return { state: _e(e, t, n) };
	},
	reduce(e, t, { by: n }) {
		if (e.phase === "done") return Z("games.ttykm.errPhase");
		let r = e.players.indexOf(n);
		if (r < 0 || r !== e.turn) return Z("games.ttykm.errTurn");
		let i = structuredClone(e);
		if (t.type === "select") {
			if (i.phase !== "select") return Z("games.ttykm.errPhase");
			let e = pe(ge(i), r, i.focus[r]), n = Math.max(0, ...e.map((e) => e.max));
			if (n === 0) return Z("games.ttykm.errSelect");
			let a = i.copies[r].findIndex((e) => e.era === i.focus[r] && e.cell === t.cell);
			if (a < 0) return Z("games.ttykm.errSelect");
			let o = e.find((e) => e.idx === a);
			return !o || o.max < n ? Z("games.ttykm.errSelect") : (i.activeId = i.copies[r][a].id, i.actionsLeft = 2, i.phase = "act", { state: i });
		}
		if (t.type === "focus") {
			if (i.phase !== "select" && i.phase !== "act" && i.phase !== "focus") return Z("games.ttykm.errPhase");
			if (t.era === i.focus[r]) return Z("games.ttykm.errFocus");
			let e = ge(i);
			if (i.phase === "select") {
				if (pe(e, r, i.focus[r]).some((e) => e.max > 0)) return Z("games.ttykm.errMustAct");
			} else if (i.phase === "act") {
				let t = i.copies[r].findIndex((e) => e.id === i.activeId);
				if (t >= 0 && X(e, r, t).length > 0) return Z("games.ttykm.errMustAct");
			}
			i.focus[r] = t.era;
			let n = [{
				kind: "focus",
				data: {
					side: r,
					era: t.era
				}
			}];
			return me(e, 1 - r) <= 1 ? (i.winner = r, i.phase = "done", {
				state: i,
				fx: n
			}) : (i.turn = 1 - r, i.phase = "select", i.activeId = null, i.actionsLeft = 0, {
				state: i,
				fx: n
			});
		}
		if (i.phase !== "act" || i.activeId === null) return Z("games.ttykm.errPhase");
		let a = i.copies[r].findIndex((e) => e.id === i.activeId);
		if (a < 0) return Z("games.ttykm.errPhase");
		let o = Y(ge(i), r, a, t);
		if (!o) return Z(he[t.type] ?? "games.ttykm.errPhase");
		i.copies = o.bd.copies, i.supply = o.bd.supply, i.plants = o.bd.plants, i.statues = o.bd.statues, i.elephants = o.bd.elephants, --i.actionsLeft;
		let s = i.copies[r].some((e) => e.id === i.activeId);
		return s || (i.activeId = null), (i.actionsLeft === 0 || !s) && (i.phase = "focus"), {
			state: i,
			fx: o.fx
		};
	},
	viewFor(e, t) {
		let n = e.activeId === null ? null : e.copies[e.turn].find((t) => t.id === e.activeId) ?? null;
		return {
			public: {
				chapter: e.chapter,
				seats: [e.players[0], e.players[1]],
				turn: e.turn,
				phase: e.phase,
				focus: [...e.focus],
				active: n ? {
					era: n.era,
					cell: n.cell
				} : null,
				actionsLeft: e.actionsLeft,
				copies: [e.copies[0].map(({ era: e, cell: t }) => ({
					era: e,
					cell: t
				})), e.copies[1].map(({ era: e, cell: t }) => ({
					era: e,
					cell: t
				}))],
				supply: [...e.supply],
				plants: e.plants ? structuredClone(e.plants) : null,
				statues: e.statues ? structuredClone(e.statues) : null,
				elephants: e.elephants ? structuredClone(e.elephants) : null,
				winner: e.winner
			},
			private: {}
		};
	},
	status(e) {
		if (e.phase !== "done" || e.winner === null) return { phase: e.phase };
		let t = e.players[e.winner];
		return {
			phase: "done",
			winner: [t],
			ranking: [t, e.players[1 - e.winner]]
		};
	}
};
//#endregion
//#region src/games/ttykm/view-player.tsx
function ye(e) {
	let t = e.public;
	return /* @__PURE__ */ h(we, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var be = [
	0,
	1,
	2
], xe = [
	"games.ttykm.era.past",
	"games.ttykm.era.present",
	"games.ttykm.era.future"
], Se = {
	N: "↑",
	S: "↓",
	W: "←",
	E: "→"
}, Ce = {
	E: "rotate-0",
	S: "rotate-90",
	W: "rotate-180",
	N: "-rotate-90"
};
function we({ pub: e, members: t, myRid: n, send: r }) {
	let i = l(), a = (e) => t.find((t) => t.rid === e)?.name ?? e, s = e.seats[0] === n ? 0 : e.seats[1] === n ? 1 : null, c = s !== null && e.turn === s && e.phase !== "done", f = e.focus[e.turn], m = e.phase === "act" && e.active ? e.active.era : f, _ = ie(e), v = s !== null && e.active ? _.copies[s].findIndex((t) => t.era === e.active.era && t.cell === e.active.cell) : -1, [y, b] = o("move"), [x, S] = o(null), C = `${e.phase}|${e.turn}|${e.actionsLeft}|${e.active?.era ?? "-"}:${e.active?.cell ?? "-"}`, [ee, w] = o(C);
	ee !== C && (w(C), b("move"), S(null));
	let T = c && e.phase === "select" && s !== null ? pe(_, s, f) : [], D = Math.max(0, ...T.map((e) => e.max)), O = new Set(T.filter((e) => e.max === D && e.max > 0).map((e) => _.copies[s][e.idx].cell)), k = e.phase === "select" && D === 0, A = c && e.phase === "act" && v >= 0 && s !== null ? X(_, s, v) : [], j = /* @__PURE__ */ new Map(), M = !1, N = !1, P = /* @__PURE__ */ new Set(), te = /* @__PURE__ */ new Set(), ne = /* @__PURE__ */ new Set(), F = /* @__PURE__ */ new Set(), I = /* @__PURE__ */ new Map();
	for (let t of A) if (t.type === "move" && e.active) {
		let n = R(e.active.cell, t.dir);
		n !== null && j.set(n, t.dir);
	} else if (t.type === "travel") t.to === "forward" ? M = !0 : N = !0;
	else if (t.type === "plant") P.add(t.cell);
	else if (t.type === "unplant") te.add(t.cell);
	else if (t.type === "build") ne.add(t.cell);
	else if (t.type === "train") F.add(t.cell);
	else if (t.type === "command" && e.elephants && e.active) {
		let n = e.elephants.pieces.find((t) => t.cells[e.active.era].hat === s);
		if (n) {
			let r = R(n.cells[e.active.era].cell, t.dir);
			r !== null && I.set(r, t.dir);
		}
	}
	let L = e.phase === "act" && A.length === 0, re = c && (e.phase === "focus" || k || L), z = (e) => {
		r(e), S(null);
	}, B = (t, n) => {
		if (c && s !== null) {
			if (e.phase === "select") {
				t === f && O.has(n) && z({
					type: "select",
					cell: n
				});
				return;
			}
			if (e.phase === "act" && e.active && t === e.active.era) {
				if (y === "move") {
					let e = j.get(n);
					if (!e) return;
					let t = fe(_, s, v, e);
					t.length > 0 ? S({
						dir: e,
						pulls: t
					}) : z({
						type: "move",
						dir: e
					});
				} else if (y === "plant" && P.has(n)) z({
					type: "plant",
					cell: n
				});
				else if (y === "unplant" && te.has(n)) z({
					type: "unplant",
					cell: n
				});
				else if (y === "build" && ne.has(n)) z({
					type: "build",
					cell: n
				});
				else if (y === "train" && F.has(n)) z({
					type: "train",
					cell: n
				});
				else if (y === "command") {
					let e = I.get(n);
					e && z({
						type: "command",
						dir: e
					});
				}
			}
		}
	}, V = (t, n) => c ? e.phase === "select" && t === f && O.has(n) ? "pick" : e.phase !== "act" || !e.active || t !== e.active.era ? null : y === "move" && j.has(n) || y === "plant" && P.has(n) || y === "unplant" && te.has(n) || y === "build" && ne.has(n) || y === "train" && F.has(n) || y === "command" && I.has(n) ? "target" : null : null, H, U;
	e.phase === "done" ? (H = "done", U = e.winner === null ? "" : i("games.ttykm.banner.win", { name: a(e.seats[e.winner]) })) : c ? e.phase === "select" ? (H = "accent", U = i(k ? "games.ttykm.banner.focusOnly" : "games.ttykm.banner.select")) : e.phase === "act" ? (H = "accent", U = i("games.ttykm.banner.act", { n: e.actionsLeft })) : (H = "accent", U = i("games.ttykm.banner.focus")) : (H = "info", U = i("games.ttykm.banner.wait", { name: a(e.seats[e.turn]) }));
	let W = [
		{
			id: "move",
			key: "games.ttykm.mode.move",
			avail: j.size > 0
		},
		{
			id: "plant",
			key: "games.ttykm.mode.plant",
			avail: P.size > 0
		},
		{
			id: "unplant",
			key: "games.ttykm.mode.unplant",
			avail: te.size > 0
		},
		{
			id: "build",
			key: "games.ttykm.mode.build",
			avail: ne.size > 0
		},
		{
			id: "train",
			key: "games.ttykm.mode.train",
			avail: F.size > 0
		},
		{
			id: "command",
			key: "games.ttykm.mode.command",
			avail: I.size > 0
		}
	].filter((t) => t.id === "plant" || t.id === "unplant" ? e.chapter === 1 : t.id === "build" ? e.chapter === 2 : t.id === "train" || t.id === "command" ? e.chapter === 3 : !0);
	return /* @__PURE__ */ h(p, {
		adaptive: !0,
		scroll: !1,
		className: "ttykm-screen",
		banner: /* @__PURE__ */ g("div", {
			className: "ttykm-top",
			children: [/* @__PURE__ */ h(u, {
				tone: H,
				text: U,
				accent: E.accent,
				chip: i("games.ttykm.chip", { n: e.chapter })
			}), /* @__PURE__ */ h(d, {
				adaptive: !0,
				members: t,
				myRid: n,
				variant: "plate",
				status: (t) => {
					let n = e.seats[0] === t ? 0 : e.seats[1] === t ? 1 : null;
					if (n === null) return null;
					let r = new Set(e.copies[n].map((e) => e.era)).size;
					return /* @__PURE__ */ g("span", {
						className: "flex items-center gap-1.5 font-mono text-xs font-bold tabular-nums",
						children: [/* @__PURE__ */ h("span", {
							className: `inline-block h-3 w-3 rounded-full border-2 border-ink ${n === 0 ? "bg-white" : "bg-ink"}`,
							"aria-hidden": !0
						}), i("games.ttykm.status", {
							eras: r,
							supply: e.supply[n]
						})]
					});
				},
				action: (t) => e.phase !== "done" && e.seats[e.turn] === t ? "pending" : null,
				anchorOf: (e) => `seat:${e}`
			})]
		}),
		actionsHeight: "ttykm-actions-slot",
		actions: /* @__PURE__ */ g("div", {
			className: "ttykm-actions",
			children: ["      ", c && e.phase !== "done" && /* @__PURE__ */ h("div", {
				className: "ttykm-action-content flex flex-none flex-col gap-2 pb-1",
				children: re ? /* @__PURE__ */ h("div", {
					className: "grid grid-cols-2 gap-2",
					children: be.filter((e) => e !== f).map((e) => /* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => z({
							type: "focus",
							era: e
						}),
						className: "tile-btn min-h-12 cursor-pointer text-sm font-extrabold",
						children: i("games.ttykm.focusTo", { era: i(xe[e]) })
					}, e))
				}) : x ? /* @__PURE__ */ g("div", {
					className: "flex gap-2",
					children: [x.pulls.map((e) => /* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => z({
							type: "move",
							dir: x.dir,
							pull: e
						}),
						className: "tile-btn min-h-12 flex-1 cursor-pointer text-sm font-extrabold",
						children: i("games.ttykm.pullYes", { dir: Se[e] })
					}, e)), /* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => z({
							type: "move",
							dir: x.dir
						}),
						className: "btn-quiet min-h-12 flex-1 cursor-pointer text-sm font-bold",
						children: i("games.ttykm.pullNo")
					})]
				}) : e.phase === "act" ? /* @__PURE__ */ g("div", {
					className: "flex flex-wrap gap-2",
					children: [
						W.map((e) => /* @__PURE__ */ h("button", {
							type: "button",
							disabled: !e.avail,
							onClick: () => b(e.id),
							className: `min-h-11 flex-1 cursor-pointer rounded-xl border-2 border-ink px-2 text-xs font-extrabold whitespace-nowrap shadow-[2px_2px_0_var(--color-ink)] disabled:cursor-not-allowed disabled:opacity-40 ${y === e.id ? "text-white" : "bg-surface text-ink"}`,
							style: y === e.id ? { background: E.accent } : void 0,
							children: i(e.key)
						}, e.id)),
						/* @__PURE__ */ h("button", {
							type: "button",
							disabled: !M,
							onClick: () => z({
								type: "travel",
								to: "forward"
							}),
							className: "btn-quiet min-h-11 flex-1 cursor-pointer text-xs font-extrabold whitespace-nowrap disabled:opacity-40",
							children: i("games.ttykm.travelFwd")
						}),
						/* @__PURE__ */ h("button", {
							type: "button",
							disabled: !N,
							onClick: () => z({
								type: "travel",
								to: "backward"
							}),
							className: "btn-quiet min-h-11 flex-1 cursor-pointer text-xs font-extrabold whitespace-nowrap disabled:opacity-40",
							children: i("games.ttykm.travelBack")
						})
					]
				}) : null
			})]
		}),
		children: /* @__PURE__ */ h("div", {
			className: "ttykm-boards frame flex min-h-0 flex-1 flex-col items-center justify-center gap-2 p-2",
			children: be.map((t) => /* @__PURE__ */ h(Te, {
				era: t,
				pub: e,
				mini: t !== m,
				myTurn: c,
				activePos: e.active,
				highlightFor: V,
				onTap: B,
				focusSides: [0, 1].filter((n) => e.focus[n] === t),
				turnHere: e.turn !== null && f === t && e.phase !== "done"
			}, t))
		})
	});
}
function Te({ era: e, pub: t, mini: n, myTurn: r, activePos: i, highlightFor: a, onTap: o, focusSides: s, turnHere: c }) {
	let u = l();
	return /* @__PURE__ */ g("div", {
		className: `ttykm-era flex flex-col items-center gap-0.5 ${n ? "opacity-80" : ""}`,
		children: [/* @__PURE__ */ g("div", {
			className: "ttykm-era-label flex items-center gap-1.5 text-[11px] font-extrabold text-ink/70",
			children: [
				/* @__PURE__ */ h("span", { children: u(xe[e]) }),
				s.map((e) => /* @__PURE__ */ h("span", {
					className: `inline-block h-2.5 w-2.5 rounded-full border-2 border-ink ${e === 0 ? "bg-white" : "bg-ink"}`,
					"aria-label": u("games.ttykm.focusMark")
				}, e)),
				c && /* @__PURE__ */ h("span", {
					style: { color: E.accent },
					children: "●"
				})
			]
		}), /* @__PURE__ */ h("div", {
			"data-mini": n || void 0,
			className: `ttykm-grid grid grid-cols-4 gap-1 rounded-xl border-2 p-1 ${c ? "border-ink" : "border-ink/30"}`,
			style: c ? { boxShadow: `3px 3px 0 ${E.accent}` } : void 0,
			children: Array.from({ length: 16 }, (s, c) => /* @__PURE__ */ h(Ee, {
				era: e,
				cell: c,
				pub: t,
				mini: n,
				interactive: r && !n,
				active: i?.era === e && i.cell === c,
				highlight: a(e, c),
				onTap: o
			}, c))
		})]
	});
}
function Ee({ era: e, cell: t, pub: n, mini: r, interactive: i, active: a, highlight: o, onTap: c }) {
	let { ref: l } = s(`cell:${e}:${t}`), u = n.copies[0].some((n) => n.era === e && n.cell === t) ? 0 : n.copies[1].some((n) => n.era === e && n.cell === t) ? 1 : null, d = n.plants?.seeds[e]?.includes(t) ?? !1, f = n.plants?.shrubs[e]?.includes(t) ?? !1, p = n.plants?.trees[e]?.includes(t) ?? !1, m = n.plants?.fallen[e]?.find((e) => e.cell === t) ?? null, _ = n.statues?.pieces.find((n) => n.cells[e] === t) ?? null, v = n.elephants?.pieces.find((n) => n.cells[e].cell === t) ?? null, y = "";
	if (m) {
		let e = m.from - t;
		y = Ce[e === 1 ? "W" : e === -1 ? "E" : e === 4 ? "N" : "S"];
	}
	let b = i && o !== null, x = r ? "h-5 w-5 text-[10px]" : "h-11 w-11 text-lg";
	return /* @__PURE__ */ g("button", {
		ref: l,
		type: "button",
		disabled: !b,
		onClick: () => c(e, t),
		"aria-label": `${e}-${t + 1}`,
		className: `ttykm-cell relative flex items-center justify-center rounded-md border font-bold ${x} ${o === "target" ? "border-ink bg-done-soft" : o === "pick" ? "border-ink bg-info-soft" : "border-ink/20 bg-surface"} ${b ? "cursor-pointer" : "cursor-default"}`,
		style: a ? { boxShadow: `0 0 0 2px ${E.accent}` } : o ? { boxShadow: `2px 2px 0 ${E.accent}` } : void 0,
		children: [
			d && /* @__PURE__ */ h("span", {
				className: u !== null || r ? "absolute top-0 left-0 text-[8px]" : "text-sm",
				children: "🌱"
			}),
			f && /* @__PURE__ */ h("span", { children: "🌿" }),
			p && /* @__PURE__ */ h("span", { children: "🌲" }),
			m && /* @__PURE__ */ h("span", {
				className: y,
				children: "🪵"
			}),
			_ && /* @__PURE__ */ h("span", {
				className: `${_.owner === null ? "" : "rounded-full"} `,
				style: _.owner === null ? void 0 : { filter: _.owner === 0 ? "drop-shadow(0 0 2px #fff)" : "drop-shadow(0 0 2px #000)" },
				children: "🗿"
			}),
			v && /* @__PURE__ */ g("span", {
				className: `relative flex items-center justify-center ${r ? "" : "h-full w-full"} rounded-md ${v.kind === "dark" ? "bg-ink/70" : "bg-ink/10"}`,
				children: ["🐘", v.cells[e].hat !== null && /* @__PURE__ */ h("span", { className: `absolute -top-0.5 -right-0.5 h-2 w-2 rounded-full border border-ink ${v.cells[e].hat === 0 ? "bg-white" : "bg-ink"}` })]
			}),
			u !== null && /* @__PURE__ */ h("span", {
				className: `${v || _ || p || f || m ? "absolute" : ""} ttykm-piece inline-block rounded-full border-2 border-ink ${r ? "h-2.5 w-2.5" : "h-5 w-5"} ${u === 0 ? "bg-white" : "bg-ink"}`,
				style: a ? { boxShadow: `0 0 0 2px ${E.accent}` } : void 0
			})
		]
	});
}
//#endregion
//#region src/games/ttykm/bot.ts
function De(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var Oe = (e) => 1 - e;
function ke(e, t) {
	let n = Oe(t), r = me(e, t), i = me(e, n);
	if (i <= 1) return 1e5;
	if (r <= 1) return -8e4;
	let a = 0;
	if (a += r * 120 - i * 150, a += e.copies[t].length * 12 - e.copies[n].length * 18, a += e.supply[t] * 4 - e.supply[n] * 3, e.elephants) for (let n of e.elephants.pieces) for (let e of n.cells) e.hat === t && (a += 6);
	return a;
}
function Ae(e, t, n) {
	let r = X(e, t, n);
	if (r.length === 0) return null;
	let i = e.copies[t][n].id, a = null;
	for (let o of r) {
		let r = Y(e, t, n, o);
		if (!r) continue;
		let s = r.bd.copies[t].findIndex((e) => e.id === i), c = ke(r.bd, t);
		if (s >= 0) {
			let e = X(r.bd, t, s);
			for (let n of e) {
				let e = Y(r.bd, t, s, n);
				e && (c = Math.max(c, ke(e.bd, t)));
			}
		}
		(!a || c > a.score) && (a = {
			action: o,
			score: c
		});
	}
	return a;
}
function je(e, t, n) {
	let r = 0;
	for (let i = 0; i < e.copies[t].length; i++) e.copies[t][i].era === n && (r += 4 + X(e, t, i).length);
	return e.copies[Oe(t)].some((e) => e.era === n) && e.copies[t].some((e) => e.era === n) && (r += 3), r;
}
var Me = (e, t) => {
	let n = e.public, r = n.seats[0] === t.rid ? 0 : n.seats[1] === t.rid ? 1 : null;
	if (r === null || n.turn !== r || n.phase === "done") return null;
	let i = ie(n), a = t.difficulty === "weak";
	if (n.phase === "select") {
		let e = pe(i, r, n.focus[r]), t = Math.max(0, ...e.map((e) => e.max));
		if (t === 0) return Q(i, r, n, a);
		let o = e.filter((e) => e.max === t);
		if (a) {
			let e = De(o);
			return { action: {
				type: "select",
				cell: i.copies[r][e.idx].cell
			} };
		}
		let s = null;
		for (let e of o) {
			let t = Ae(i, r, e.idx)?.score ?? -Infinity;
			(!s || t > s.score) && (s = {
				idx: e.idx,
				score: t
			});
		}
		let c = s?.idx ?? o[0].idx;
		return { action: {
			type: "select",
			cell: i.copies[r][c].cell
		} };
	}
	if (n.phase === "act") {
		if (!n.active) return Q(i, r, n, a);
		let e = i.copies[r].findIndex((e) => e.era === n.active.era && e.cell === n.active.cell);
		if (e < 0) return Q(i, r, n, a);
		let t = X(i, r, e);
		if (t.length === 0) return Q(i, r, n, a);
		if (a) return { action: De(t) };
		let o = i.copies[r][e].id, s = null;
		for (let a of t) {
			let t = Y(i, r, e, a);
			if (!t) continue;
			let c = t.bd.copies[r].findIndex((e) => e.id === o), l = ke(t.bd, r);
			if (n.actionsLeft === 2 && c >= 0) for (let e of X(t.bd, r, c)) {
				let n = Y(t.bd, r, c, e);
				n && (l = Math.max(l, ke(n.bd, r)));
			}
			(!s || l > s.score) && (s = {
				action: a,
				score: l
			});
		}
		return s ? { action: s.action } : null;
	}
	return Q(i, r, n, a);
};
function Q(e, t, n, r) {
	let i = [
		0,
		1,
		2
	].filter((e) => e !== n.focus[t]);
	if (r) return { action: {
		type: "focus",
		era: De(i)
	} };
	let a = i[0], o = -Infinity;
	for (let n of i) {
		let r = je(e, t, n);
		r > o && (o = r, a = n);
	}
	return { action: {
		type: "focus",
		era: a
	} };
}
var Ne = {
	0: "games.ttykm.era.past",
	1: "games.ttykm.era.present",
	2: "games.ttykm.era.future"
}, Pe = {
	N: "↑",
	S: "↓",
	W: "←",
	E: "→"
}, Fe = (e, t, n) => e.type === "select" ? n("games.ttykm.hintSelect", { n: e.cell + 1 }) : e.type === "move" ? e.pull ? n("games.ttykm.hintMovePull", { dir: Pe[e.dir] }) : n("games.ttykm.hintMove", { dir: Pe[e.dir] }) : e.type === "travel" ? n(e.to === "forward" ? "games.ttykm.travelFwd" : "games.ttykm.travelBack") : e.type === "plant" ? n("games.ttykm.hintPlant", { n: e.cell + 1 }) : e.type === "unplant" ? n("games.ttykm.hintUnplant", { n: e.cell + 1 }) : e.type === "build" ? n("games.ttykm.hintBuild", { n: e.cell + 1 }) : e.type === "train" ? n("games.ttykm.hintTrain", { n: e.cell + 1 }) : e.type === "command" ? n("games.ttykm.hintCommand", { dir: Pe[e.dir] }) : e.type === "focus" ? n("games.ttykm.focusTo", { era: n(Ne[e.era]) }) : "", $ = (e, t, n) => typeof t == "number" && typeof n == "number" ? e.anchor(`cell:${t}:${n}`) : null, Ie = {
	squish: "💥",
	paradox: "⚡",
	topple: "🌲",
	trample: "🐾"
}, Le = {
	seed: "🌱",
	shrub: "🌿",
	tree: "🌲"
}, Re = {
	kill(e, t) {
		let n = e.data, r = $(t, n?.era, n?.cell);
		if (!r) return null;
		let i = Ie[String(n?.cause)] ?? "💥";
		return {
			ms: 800,
			node: /* @__PURE__ */ h(_, {
				at: r,
				ms: 750,
				children: i
			})
		};
	},
	topple(e, t) {
		let n = e.data, r = $(t, n?.era, n?.to);
		return r ? {
			ms: 500,
			node: /* @__PURE__ */ h(y, {
				at: r,
				ms: 500
			})
		} : null;
	},
	grow(e, t) {
		let n = e.data, r = $(t, n?.era, n?.cell);
		if (!r) return null;
		let i = Le[String(n?.what)] ?? "🌱";
		return {
			ms: 600,
			node: /* @__PURE__ */ h(_, {
				at: r,
				ms: 550,
				children: i
			})
		};
	},
	ungrow(e, t) {
		let n = e.data, r = $(t, n?.era, n?.cell);
		return r ? {
			ms: 600,
			node: /* @__PURE__ */ h(_, {
				at: r,
				ms: 550,
				children: "💨"
			})
		} : null;
	},
	statue(e, t) {
		let n = e.data, r = $(t, n?.era, n?.to);
		return r ? {
			ms: 450,
			node: /* @__PURE__ */ h(y, {
				at: r,
				ms: 450
			})
		} : null;
	},
	build(e, t) {
		let n = e.data, r = $(t, n?.era, n?.cell);
		return r ? {
			ms: 700,
			node: /* @__PURE__ */ h(_, {
				at: r,
				ms: 650,
				children: "🗿"
			})
		} : null;
	},
	train(e, t) {
		let n = e.data, r = $(t, n?.era, n?.cell);
		return r ? {
			ms: 700,
			node: /* @__PURE__ */ h(_, {
				at: r,
				ms: 650,
				children: "🎩"
			})
		} : null;
	},
	command(e, t) {
		let n = e.data, r = $(t, n?.era, n?.to);
		return r ? {
			ms: 450,
			node: /* @__PURE__ */ h(y, {
				at: r,
				ms: 450
			})
		} : null;
	},
	travel(e, t) {
		let n = e.data, r = $(t, n?.from?.era, n?.from?.cell), i = $(t, n?.to?.era, n?.to?.cell);
		return !r || !i ? null : {
			ms: 550,
			node: /* @__PURE__ */ h(v, {
				from: r,
				to: i,
				ms: 500,
				children: /* @__PURE__ */ h("span", {
					style: { fontSize: Math.max(20, i.w * .6) },
					children: "⏳"
				})
			})
		};
	}
};
//#endregion
//#region src/games/ttykm/endgame-review.tsx
function ze({ board: e, renderResult: t, ...n }) {
	let s = l(), [c, u] = o(!0), [d, f] = o(null), p = a(null), m = a(null), _ = a(null);
	r(() => {
		if (!d) return;
		_.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => f(null), 5e3);
		return () => clearTimeout(e);
	}, [d]);
	let v = (e) => {
		f(null), u(e), requestAnimationFrame(() => (e ? p : m).current?.focus({ preventScroll: !0 }));
	}, y = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => f({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => f({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => f({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), x = {
		...n,
		...y
	};
	return /* @__PURE__ */ g("div", {
		className: "ttykm-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ h("div", {
				className: "ttykm-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ h("div", {
				className: "ttykm-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ g("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), v(!1));
					},
					className: "ttykm-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ g("header", {
							className: "ttykm-endgame-heading",
							children: [/* @__PURE__ */ g("div", {
								className: "ttykm-endgame-brand",
								children: [/* @__PURE__ */ h("span", {
									"aria-hidden": "true",
									children: E.icon
								}), s(E.nameKey)]
							}), /* @__PURE__ */ h("button", {
								type: "button",
								ref: p,
								className: "btn-quiet",
								"aria-label": s("games.ttykm.reviewHide"),
								title: s("games.ttykm.reviewHide"),
								onClick: () => v(!1),
								children: /* @__PURE__ */ h(S, { size: 19 })
							})]
						}),
						/* @__PURE__ */ h("div", {
							className: "ttykm-endgame-result",
							inert: d !== null,
							children: t(x)
						}),
						d && /* @__PURE__ */ g("div", {
							className: "ttykm-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || f(null);
							},
							children: [/* @__PURE__ */ h("button", {
								type: "button",
								ref: _,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = d.run;
									f(null), e();
								},
								children: s(d.label === "again" ? "games.ttykm.reviewConfirmAgain" : "games.ttykm.reviewConfirmLobby")
							}), /* @__PURE__ */ h("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									f(null), p.current?.focus({ preventScroll: !0 });
								},
								children: s("games.ttykm.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ h("div", {
				className: "ttykm-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ g("button", {
					type: "button",
					className: "btn-base",
					ref: m,
					onClick: () => v(!0),
					children: [
						/* @__PURE__ */ h(C, { size: 18 }),
						s("games.ttykm.reviewShow"),
						/* @__PURE__ */ h(b, { size: 18 })
					]
				})
			})
		]
	});
}
function Be({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: s, rows: u, renderRowExtra: d, summary: p, navigation: _, content: v, afterRanking: y, scoreUnit: b, rankOf: C }) {
	let w = l(), T = c((e) => e.locale), [D, O] = o({}), k = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? f(n, T) : e;
	}, A = (t, n) => C?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), j = e.ranking.some((t) => e.scores?.[t] !== void 0), M = (t, n) => /* @__PURE__ */ g("div", {
		className: "ttykm-score-identity",
		children: [
			/* @__PURE__ */ g("span", {
				className: "ttykm-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ h("span", {
					"aria-label": w("games.ttykm.reviewWinner"),
					children: "♛ "
				}), j && A(t, n)]
			}),
			/* @__PURE__ */ g("span", {
				className: "ttykm-score-name",
				children: [k(t), t === r && /* @__PURE__ */ h("small", { children: w("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ g("small", {
				className: "ttykm-score-autopilot",
				children: [
					/* @__PURE__ */ h(x, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), N = (t) => e.ranking.map((n) => /* @__PURE__ */ h("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ g("div", {
		className: "ttykm-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ h(ee, {}),
			_,
			/* @__PURE__ */ g("div", {
				className: "ttykm-score-body",
				children: [
					p && /* @__PURE__ */ h("div", {
						className: "ttykm-score-summary",
						children: p
					}),
					i !== void 0 && /* @__PURE__ */ h("p", {
						className: "ttykm-score-hints",
						children: w("session.hint.usedCount", { n: i })
					}),
					v ?? (u?.length ? /* @__PURE__ */ h("div", {
						className: "ttykm-score-table-scroll",
						children: /* @__PURE__ */ g("table", {
							className: "ttykm-score-table",
							"aria-label": w(E.nameKey),
							children: [
								/* @__PURE__ */ h("thead", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", { scope: "col" }), /* @__PURE__ */ h(m, { children: e.ranking.map((t, n) => /* @__PURE__ */ h("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: M(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ h("tbody", { children: u.map((e, t) => /* @__PURE__ */ g(n, { children: [/* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ g("button", {
										type: "button",
										"aria-expanded": !!D[t],
										onClick: () => O((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ h(S, { size: 15 }), e.label]
									}) : e.label
								}), N(e)] }), D[t] && e.details?.map((e, t) => /* @__PURE__ */ g("tr", {
									className: "ttykm-score-sub",
									children: [/* @__PURE__ */ h("th", {
										scope: "row",
										children: e.label
									}), N(e)]
								}, t))] }, t)) }),
								j && /* @__PURE__ */ h("tfoot", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
									scope: "row",
									children: w("games.ttykm.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ h("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ h("ol", {
						className: "ttykm-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ g("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ g("div", {
								className: "ttykm-score-rankline",
								children: [M(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ g("strong", {
									className: "ttykm-score-points",
									children: [e.scores[t], b && /* @__PURE__ */ h("small", { children: b })]
								})]
							}), d?.(t)]
						}, t))
					})),
					y,
					!!u?.length && d && /* @__PURE__ */ h("div", {
						className: "ttykm-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ g("details", { children: [/* @__PURE__ */ h("summary", { children: k(e) }), d(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ g("footer", {
				className: "ttykm-score-actions",
				children: [
					s && /* @__PURE__ */ h("button", {
						type: "button",
						className: "btn-quiet",
						onClick: s,
						children: w("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ h("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: w("session.result.playAgain")
					}),
					!a && !s && /* @__PURE__ */ h("p", { children: w("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/ttykm/game-over.tsx
function Ve(e) {
	return /* @__PURE__ */ h(Be, {
		...e,
		accent: E.accent
	});
}
function He(e) {
	return /* @__PURE__ */ h(ze, {
		...e,
		board: /* @__PURE__ */ h(ye, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ h(Ve, { ...e })
	});
}
//#endregion
//#region src/games/ttykm/options.tsx
var Ue = {
	0: "games.ttykm.chapter.ch0",
	1: "games.ttykm.chapter.ch1",
	2: "games.ttykm.chapter.ch2",
	3: "games.ttykm.chapter.ch3"
}, We = {
	random: "games.ttykm.side.random",
	hostWhite: "games.ttykm.side.hostWhite",
	hostBlack: "games.ttykm.side.hostBlack"
};
function Ge({ value: e, onChange: t }) {
	let n = l(), r = N.safeParse(e), i = r.success ? r.data : N.parse(void 0);
	return /* @__PURE__ */ g("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ h(T, {
			title: n("games.ttykm.optChapter"),
			children: [
				0,
				1,
				2,
				3
			].map((e) => /* @__PURE__ */ h(w, {
				name: "ttykm-chapter",
				value: String(e),
				checked: i.chapter === e,
				label: n(Ue[e]),
				accent: E.accent,
				onChange: () => t({
					...i,
					chapter: e
				})
			}, e))
		}), /* @__PURE__ */ h(T, {
			title: n("games.ttykm.optSide"),
			columns: 3,
			children: [
				"random",
				"hostWhite",
				"hostBlack"
			].map((e) => /* @__PURE__ */ h(w, {
				name: "ttykm-side",
				value: e,
				checked: i.sideAssign === e,
				label: n(We[e]),
				accent: E.accent,
				onChange: () => t({
					...i,
					sideAssign: e
				})
			}, e))
		})]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/ttykm/entry.tsx
var Ke = {
	definition: ve,
	View: ye,
	bot: Me,
	describe: Fe,
	fx: Re,
	OverView: He,
	Options: Ge,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "煞有其时",
			desc: "双人时空谋杀:在过去、现在、未来之间穿梭,把对手从两个时代彻底抹除",
			rules: "目标:你的回合结束时,若对手只在至多一个时代留有棋子,你获胜。\n准备:三块 4 乘 4 格的时代盘(过去/现在/未来)。\n双方各 7 枚棋子:白方在每时代 1 号格、黑方在 16 号格各放 1 枚,其余 4 枚备用。\n白方焦点在过去、黑方在未来,白方先行。\n流程:你的回合依次:\n· 在焦点所在时代选一枚棋子,用它做 2 个动作(能做完 2 个动作的棋子必须优先选;全都动不了则跳过行动)。\n可选择的动作：\n· 移动：沿正交方向移动一格，可以推挤对手的棋子，但不能移入已有己方棋子的格子。\n· 前往未来：移动到下一个时代的同一格，目标格必须为空。\n· 前往过去：移动到上一个时代的同一格，目标格必须为空，并须在出发格留下1枚备用棋子。没有备用棋子时，不能前往过去。\n结束行动后，将焦点移到另一个时代，然后检查胜负。\n推挤：被推挤的棋子沿同一方向继续传递推挤。棋子被挤出版图，或被挤到墙上时，死亡并永久移除。两枚同色棋子相撞时发生悖论，两枚棋子均死亡。\n章节(开局选择):\n· 第 0 章:纯基础规则。\n· 第 1 章 生长:可在自身或相邻格种下或除去种子;种子在下一时代长成灌木、再下一时代长成树,除去种子会沿时代级联枯萎。\n· 种子不占格子;灌木是墙;树可被推倒,倒下的树压死落点棋子、之后也是墙。\n· 种子、灌木、树为双方共享的供应,每种各 5 枚。\n· 第 2 章 雕像:黄雕像立于各时代 7 号格。雕像可被推挤,移动会向后续时代传播。\n· 主动移动离开雕像旁时,可把它拉到刚空出的格子。\n· 每方限一次:在相邻格建造自己的雕像,后续时代同格会一并建造(被占则挤开,挤不动则不建)。\n· 第 3 章 记忆:深象在 4 号格、浅象在 13 号格(每时代各一对)。\n· 可在相邻格给象戴帽，进行驯养：驯养沿时代传播,每个时代消耗1顶帽子，每方各有3顶；每方同时只能驯养一头象。\n· 可指挥被驯的象正交走一格,踩死落点的任何棋子。象不可被推动。",
			era: {
				past: "过去",
				present: "现在",
				future: "未来"
			},
			chip: "第{{n}}章",
			banner: {
				win: "{{name}} 抹除了对手,获胜!",
				wait: "等 {{name}} 行动…",
				select: "选一枚棋子行动",
				act: "再行动 {{n}} 次",
				focus: "把焦点移到另一个时代",
				focusOnly: "无子可动:移动焦点"
			},
			mode: {
				move: "移动",
				plant: "种种子",
				unplant: "除种子",
				build: "建雕像",
				train: "驯象",
				command: "指挥象"
			},
			travelFwd: "旅行到未来",
			travelBack: "旅行到过去",
			pullYes: "拉雕像 {{dir}}",
			pullNo: "不拉",
			focusTo: "焦点 → {{era}}",
			focusMark: "焦点所在时代",
			status: "{{eras}} 时代 · 备用 {{supply}}",
			optChapter: "章节",
			chapter: {
				ch0: "第 0 章 · 基础",
				ch1: "第 1 章 · 生长",
				ch2: "第 2 章 · 雕像",
				ch3: "第 3 章 · 记忆"
			},
			optSide: "选边",
			side: {
				random: "随机",
				hostWhite: "主机执白",
				hostBlack: "主机执黑"
			},
			errTurn: "还没轮到你",
			errPhase: "现在不能这样做",
			errSelect: "不能选这枚棋子",
			errMove: "不能移动到那里",
			errTravel: "不能朝那个方向旅行",
			errPlant: "不能在这里种种子",
			errUnplant: "这里没有可除的种子",
			errBuild: "不能在这里建造雕像",
			errTrain: "不能驯养那头象",
			errCommand: "不能指挥象走那一步",
			errFocus: "焦点必须移到另一个时代",
			errMustAct: "还有动作没做完",
			hintSelect: "选 {{n}} 号格的棋子行动",
			hintMove: "朝 {{dir}} 移动一格",
			hintMovePull: "朝 {{dir}} 移动一格,并拉出雕像",
			hintPlant: "在 {{n}} 号格种种子",
			hintUnplant: "除掉 {{n}} 号格的种子",
			hintBuild: "在 {{n}} 号格建雕像",
			hintTrain: "驯养 {{n}} 号格的象",
			hintCommand: "指挥象朝 {{dir}} 走一格"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "That Time You Killed Me",
			desc: "A duel of time and murder: hop between past, present and future to erase your rival from two eras",
			rules: "Goal: at the end of your turn, if your opponent has pieces in at most one era, you win.\nSetup: three 4-by-4 era boards (past / present / future).\nEach player has 7 pieces: white places one on space 1 of every era, black on space 16; the other 4 stay in reserve.\nWhite focuses on the past, black on the future; white goes first.\nPlay: on your turn, in order:\n· Choose one of your pieces in the era your focus is on and take 2 actions with it (a piece that can take both actions must be preferred; if nothing can act, skip to moving focus).\nAvailable actions:\n· Move: Move one space orthogonally. You may shove opposing pieces, but cannot enter a space occupied by your own piece.\n· Travel to the future: Move to the same space in the next era. The destination must be empty.\n· Travel to the past: Move to the same space in the previous era. The destination must be empty, and you must leave a reserve piece in your starting space. You cannot travel to the past when your reserve is empty.\nAfter completing your actions, move your focus to a different era, then check for victory.\nShoving: a shoved piece passes the shove along; pushed off the board or into a wall it dies for good; two pieces of the same color colliding causes a paradox and both die.\nChapters (chosen at start):\n· Chapter 0: the basic game only.\n· Chapter 1 Growth: plant or remove seeds on your own or an adjacent space; a seed grows into a shrub in the next era, then a tree in the era after, and removing a seed withers the whole line.\n· Seeds do not block; shrubs are walls; trees can be toppled, crushing whatever they fall on, and fallen trees are walls too.\n· Seeds, shrubs and trees come from a supply shared by both players: 5 of each.\n· Chapter 2 Influence: a yellow statue stands on space 7 of every era. Statues can be shoved, and the movement propagates to later eras.\n· When you move away from a statue, you may pull it into the space you left.\n· Once per game each player may build their own statue adjacent to their active piece — it is built on the same space of later eras too (occupants are shoved; if they cannot be shoved, it is not built).\n· Chapter 3 Memory: a dark elephant on space 4 and a light one on space 13 of every era.\n· Train an adjacent elephant with your hat: training echoes through the eras, costing 1 hat per era (3 hats each), and you may only train one elephant at a time.\n· Command a trained elephant to step orthogonally, trampling any piece it lands on. Elephants cannot be shoved.",
			era: {
				past: "Past",
				present: "Present",
				future: "Future"
			},
			chip: "Ch.{{n}}",
			banner: {
				win: "{{name}} erased their rival and wins!",
				wait: "Waiting for {{name}}…",
				select: "Choose a piece to act with",
				act: "{{n}} actions left",
				focus: "Move your focus to another era",
				focusOnly: "No piece can act: move your focus"
			},
			mode: {
				move: "Move",
				plant: "Plant",
				unplant: "Uproot",
				build: "Build",
				train: "Train",
				command: "Command"
			},
			travelFwd: "Travel forward",
			travelBack: "Travel back",
			pullYes: "Pull statue {{dir}}",
			pullNo: "No pull",
			focusTo: "Focus → {{era}}",
			focusMark: "Focus is here",
			status: "{{eras}} eras · reserve {{supply}}",
			optChapter: "Chapter",
			chapter: {
				ch0: "Ch 0 · Basic",
				ch1: "Ch 1 · Growth",
				ch2: "Ch 2 · Influence",
				ch3: "Ch 3 · Memory"
			},
			optSide: "Sides",
			side: {
				random: "Random",
				hostWhite: "Host white",
				hostBlack: "Host black"
			},
			errTurn: "Not your turn",
			errPhase: "Not allowed right now",
			errSelect: "Cannot choose that piece",
			errMove: "Cannot move there",
			errTravel: "Cannot travel that way",
			errPlant: "Cannot plant a seed there",
			errUnplant: "No seed to remove there",
			errBuild: "Cannot build a statue there",
			errTrain: "Cannot train that elephant",
			errCommand: "Cannot command the elephant there",
			errFocus: "Focus must move to a different era",
			errMustAct: "You still have actions to take",
			hintSelect: "Activate your piece on square {{n}}",
			hintMove: "Move one square {{dir}}",
			hintMovePull: "Move one square {{dir}} and pull the statue along",
			hintPlant: "Plant a seed on square {{n}}",
			hintUnplant: "Remove the seed on square {{n}}",
			hintBuild: "Build your statue on square {{n}}",
			hintTrain: "Tame the elephant on square {{n}}",
			hintCommand: "Command the elephant one square {{dir}}"
		}
	}
};
//#endregion
export { Ke as default };
