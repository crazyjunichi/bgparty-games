import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { createPortal as a } from "react-dom";
import { AVATARS as o } from "@bgparty/sdk/avatars";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { useWakeLock as l } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { seatName as d } from "@bgparty/sdk/ui/player-strip";
import { SheetView as f } from "@bgparty/sdk/sheet-view";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
//#region src/games/mazing/meta.ts
var g = {
	id: "mazing",
	tier: "alpha",
	mechanics: ["grid-movement", "route-building"],
	interactionTags: ["cooperative"],
	nameKey: "games.mazing.name",
	descKey: "games.mazing.desc",
	rulesKey: "games.mazing.rules",
	icon: "◉",
	iconImg: "games/mazing.webp",
	minPlayers: 1,
	maxPlayers: 2,
	bestPlayers: [1, 2],
	accent: "#d82629",
	releasedAt: "2026-11-07T01:14:05+08:00",
	search: {
		py: "",
		init: ""
	},
	hotseat: "open",
	botDelayMs: 700
}, _ = t.enum(["white", "black"]), v = t.enum([
	"messenger",
	"orth1",
	"orth2",
	"diag1",
	"diag2",
	"bridge",
	"meteor"
]), y = t.object({
	id: t.string(),
	color: _,
	kind: v,
	cell: t.int().min(0).max(59),
	locked: t.boolean()
}), b = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("move"),
		piece: t.string(),
		to: t.int().min(0).max(59)
	}),
	t.object({ type: t.literal("endTurn") }),
	t.object({ type: t.literal("concede") })
]), x = t.object({
	players: t.array(t.string()).min(1).max(2),
	pieces: t.array(y).length(36),
	color: _,
	actor: t.string(),
	used: t.int().min(0).max(2),
	moves: t.int().nonnegative(),
	turn: t.int().positive(),
	outcome: t.enum([
		"playing",
		"won",
		"trapped",
		"blocked",
		"conceded"
	]),
	last: t.object({
		piece: t.string(),
		from: t.int(),
		to: t.int(),
		locked: t.boolean()
	}).nullable()
}), S = t.object({}), C = Array.from({ length: 60 }, (e, t) => t).filter((e) => {
	let t = Math.floor(e / 10), n = e % 10, r = [
		2,
		1,
		0,
		0,
		1,
		2
	][t];
	return n >= r && n < 10 - r;
}), w = [
	14,
	15,
	23,
	26,
	33,
	36,
	44,
	45
], T = new Set(C), E = [
	[1, 0],
	[-1, 0],
	[0, 1],
	[0, -1]
], D = [
	[1, 1],
	[1, -1],
	[-1, 1],
	[-1, -1]
], O = [...E, ...D], k = (e) => e === "white" ? "black" : "white", A = (e, t) => e[t === "white" ? 0 : e.length - 1], j = (e) => {
	let t = e.color === "white" ? 0 : 9, n = (Math.floor(e.cell / 10) + e.cell % 10) % 2;
	return [20 + t, 30 + t].find((e) => (Math.floor(e / 10) + e % 10) % 2 === n);
}, M = (e) => e.kind === "messenger" && e.cell === j(e), N = (e) => e.filter(M).length;
function P(e, t) {
	if (e < 0 || e >= 6 || t < 0 || t >= 10) return null;
	let n = e * 10 + t;
	return T.has(n) ? n : null;
}
function F(e, t) {
	if (t.locked) return [];
	let n = new Set(e.map((e) => e.cell));
	if (t.kind === "meteor") return C.filter((e) => !n.has(e));
	let r = Math.floor(t.cell / 10), i = t.cell % 10, a = t.kind === "bridge" ? O : ["orth1", "orth2"].includes(t.kind) ? E : D, o = [];
	for (let [e, s] of a) {
		if (t.kind === "bridge") {
			let t = 1, a = P(r + e, i + s);
			if (a === null || !n.has(a)) continue;
			for (; a !== null && n.has(a);) t += 1, a = P(r + e * t, i + s * t);
			a !== null && o.push(a);
			continue;
		}
		let a = t.kind === "messenger" ? 10 : t.kind.endsWith("2") ? 2 : 1;
		for (let c = 1; c <= a; c += 1) {
			let l = P(r + e * c, i + s * c);
			if (l === null || n.has(l)) break;
			(t.kind === "messenger" || c === a) && o.push(l);
		}
	}
	return o;
}
function I(e, t) {
	return e.filter((e) => e.color === t).flatMap((t) => F(e, t).map((e) => ({
		type: "move",
		piece: t.id,
		to: e
	})));
}
function L(e, t, n) {
	return e.map((e) => e.id === t ? {
		...e,
		cell: n,
		locked: e.kind === "meteor" || w.includes(n)
	} : e);
}
var R = [
	"orth1",
	"orth1",
	"orth1",
	"orth2",
	"orth2",
	"diag1",
	"diag1",
	"diag1",
	"diag2",
	"diag2",
	"bridge",
	"bridge",
	"bridge",
	"meteor",
	"meteor",
	"meteor"
];
function z(t, n, r) {
	let i = [], a = 0;
	for (let t of ["white", "black"]) {
		let n = [...R];
		for (let t = n.length - 1; t > 0; --t) {
			let i = e(r, a++, t + 1);
			[n[t], n[i]] = [n[i], n[t]];
		}
		C.filter((e) => t === "white" ? e % 10 >= 6 && e % 10 <= 8 : e % 10 >= 1 && e % 10 <= 3).forEach((e, r) => i.push({
			id: `${t}-${r}`,
			color: t,
			kind: n[r],
			cell: e,
			locked: !1
		}));
		let o = t === "white" ? 9 : 0;
		for (let e of [2, 3]) i.push({
			id: `${t}-messenger-${e}`,
			color: t,
			kind: "messenger",
			cell: e * 10 + o,
			locked: !1
		});
	}
	return {
		state: {
			players: [...n],
			pieces: i,
			color: "white",
			used: 0,
			moves: 0,
			turn: 1,
			outcome: "playing",
			last: null
		},
		fx: []
	};
}
function B(e, t, n) {
	if (e.outcome !== "playing" || n.by !== A(e.players, e.color)) return { code: "games.mazing.errTurn" };
	if (t.type === "concede") return {
		state: {
			...e,
			outcome: "conceded"
		},
		fx: []
	};
	if (t.type === "endTurn") {
		if (e.used === 0) return { code: "games.mazing.errMoveFirst" };
		let t = k(e.color);
		return {
			state: {
				...e,
				color: t,
				used: 0,
				turn: e.turn + 1,
				outcome: I(e.pieces, t).length ? "playing" : "blocked"
			},
			fx: []
		};
	}
	let r = e.pieces.find((e) => e.id === t.piece);
	if (!r || r.color !== e.color || !F(e.pieces, r).includes(t.to)) return { code: "games.mazing.errMove" };
	let i = L(e.pieces, r.id, t.to), a = i.find((e) => e.id === r.id), o = e.used + 1, s = o === 3 || I(i, e.color).length === 0, c = s ? k(e.color) : e.color, l = N(i) === 4 ? "won" : a.kind === "messenger" && a.locked ? "trapped" : s && I(i, c).length === 0 ? "blocked" : "playing";
	return {
		state: {
			...e,
			pieces: i,
			color: c,
			used: s ? 0 : o,
			turn: e.turn + +!!s,
			moves: e.moves + 1,
			outcome: l,
			last: {
				piece: r.id,
				from: r.cell,
				to: t.to,
				locked: a.locked
			}
		},
		fx: []
	};
}
var V = {
	meta: g,
	saveCompatibility: { version: "1" },
	schemas: {
		action: b,
		publicView: x,
		privateView: S
	},
	setup: z,
	reduce: B,
	viewFor: (e) => ({
		public: {
			...e,
			actor: A(e.players, e.color)
		},
		private: {}
	}),
	status: (e) => e.outcome === "playing" ? { phase: "playing" } : {
		phase: "done",
		winner: e.outcome === "won" ? [...e.players] : [],
		ranking: [...e.players]
	}
}, H = new Set(C), U = new Set(w), W = /* @__PURE__ */ new Map();
for (let e of C) {
	let t = [];
	for (let [n, r] of [
		[1, 1],
		[1, -1],
		[-1, 1],
		[-1, -1]
	]) {
		let i = [];
		for (let a = 1; a < 10; a += 1) {
			let o = Math.floor(e / 10) + n * a, s = e % 10 + r * a, c = o * 10 + s;
			if (o < 0 || o >= 6 || s < 0 || s >= 10 || !H.has(c)) break;
			i.push(c), U.has(c) || t.push({
				to: c,
				through: [...i]
			});
		}
	}
	W.set(e, t);
}
function G(e, t) {
	if (M(t)) return 0;
	if (t.locked) return 200;
	let n = new Map(e.filter((e) => e.id !== t.id).map((e) => [e.cell, e])), r = j(t), i = /* @__PURE__ */ new Map([[t.cell, 0]]), a = (t.cell % 10 + Math.floor(t.cell / 10)) % 2, o = new Set(C.filter((e) => !U.has(e) && (e % 10 + Math.floor(e / 10)) % 2 === a));
	for (; o.size;) {
		let e = -1, t = Infinity;
		for (let n of o) (i.get(n) ?? Infinity) < t && (t = i.get(n), e = n);
		if (e < 0) break;
		if (e === r) return t;
		o.delete(e);
		for (let r of W.get(e)) {
			if (!o.has(r.to)) continue;
			let e = 1;
			for (let t of r.through) {
				let r = n.get(t);
				if (r?.locked) {
					e = Infinity;
					break;
				}
				r && (e += r.kind === "messenger" ? 2 : 2.5);
			}
			let a = t + e;
			a < (i.get(r.to) ?? Infinity) && i.set(r.to, a);
		}
	}
	return 200;
}
//#endregion
//#region src/games/mazing/bot.ts
var K = {
	route: 12,
	arrival: 150,
	distance: .2,
	repetition: 20,
	lock: .5
};
function q(e, t) {
	let n = N(e) * t.arrival;
	for (let r of e) r.kind === "messenger" ? (n -= G(e, r) * t.route, n -= Math.abs((r.color === "white" ? 0 : 9) - r.cell % 10) * t.distance) : r.locked && (n -= t.lock);
	return n;
}
var J = (e) => e.map((e) => `${e.cell}${e.locked ? "x" : ""}`).join(",");
function Y(e = K) {
	return (t, n) => {
		let r = t.public;
		if (r.outcome !== "playing" || r.actor !== n.rid) return null;
		let i = I(r.pieces, r.color);
		if (!i.length) return r.used ? { action: { type: "endTurn" } } : null;
		let a = n.memory?.recent ?? [];
		if (n.difficulty === "weak") {
			let e = i.filter((e) => !(r.pieces.find((t) => t.id === e.piece).kind === "messenger" && w.includes(e.to))), t = e.length ? e : i, n = Math.floor(4294967296 / t.length) * t.length, a = /* @__PURE__ */ new Uint32Array(1);
			do
				crypto.getRandomValues(a);
			while (a[0] >= n);
			return { action: t[a[0] % t.length] };
		}
		let o = i.map((t) => {
			let n = L(r.pieces, t.piece, t.to), i = J(n);
			return {
				action: t,
				key: i,
				value: q(n, e) - a.filter((e) => e === i).length * e.repetition
			};
		}).sort((e, t) => t.value - e.value);
		return r.used > 0 && o[0].value < q(r.pieces, e) - 1 ? {
			action: { type: "endTurn" },
			memory: n.memory
		} : {
			action: o[0].action,
			memory: { recent: [...a, J(r.pieces)].slice(-70) }
		};
	};
}
var ee = Y(), X = {
	messenger: "games.mazing.messenger",
	orth1: "games.mazing.orth1",
	orth2: "games.mazing.orth2",
	diag1: "games.mazing.diag1",
	diag2: "games.mazing.diag2",
	bridge: "games.mazing.bridge",
	meteor: "games.mazing.meteor"
};
//#endregion
//#region src/games/mazing/piece-icon.tsx
function Z({ kind: e }) {
	if (e === "messenger") return /* @__PURE__ */ h("g", {
		fill: "currentColor",
		children: [/* @__PURE__ */ m("circle", {
			r: "27",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "7"
		}), /* @__PURE__ */ m("circle", { r: "9" })]
	});
	if (e === "bridge") return /* @__PURE__ */ m("path", {
		d: "M-26 22V-2a26 26 0 0 1 52 0v24",
		stroke: "currentColor",
		strokeWidth: "8",
		fill: "none"
	});
	if (e === "meteor") return /* @__PURE__ */ m("g", {
		transform: "rotate(42)",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "7",
		children: /* @__PURE__ */ m("path", { d: "M-23-30V7a23 23 0 0 0 46 0v-37M-10-30V8M3-30V14M16-30V6" })
	});
	let t = e.startsWith("diag"), n = e.endsWith("2");
	return /* @__PURE__ */ h("g", {
		transform: t ? "rotate(45)" : void 0,
		stroke: "currentColor",
		strokeWidth: "3",
		fill: "currentColor",
		children: [/* @__PURE__ */ m("path", {
			d: "M-28 0H28M0-28V28",
			fill: "none"
		}), [-1, 1].flatMap((e) => [
			/* @__PURE__ */ m("circle", {
				cx: e * 28,
				r: "5.5"
			}, `h${e}`),
			/* @__PURE__ */ m("circle", {
				cy: e * 28,
				r: "5.5"
			}, `v${e}`),
			...n ? [/* @__PURE__ */ m("circle", {
				cx: e * 14,
				r: "5"
			}, `hi${e}`), /* @__PURE__ */ m("circle", {
				cy: e * 14,
				r: "5"
			}, `vi${e}`)] : []
		])]
	});
}
function te() {
	return /* @__PURE__ */ h("g", {
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "5",
		children: [
			/* @__PURE__ */ m("path", { d: "M-11-3v-9a11 11 0 0 1 22 0v9" }),
			/* @__PURE__ */ m("rect", {
				x: "-18",
				y: "-3",
				width: "36",
				height: "29",
				rx: "4"
			}),
			/* @__PURE__ */ m("circle", {
				cy: "10",
				r: "3",
				fill: "currentColor"
			})
		]
	});
}
//#endregion
//#region src/games/mazing/board.tsx
function Q({ pub: e, selected: t, targets: a = [], onCell: o, fit: s = 0, readOnly: l = !1 }) {
	let u = c(), d = r(null), [p, g] = i(!1);
	n(() => {
		let e = d.current, t = new ResizeObserver(() => g(e.clientHeight > e.clientWidth * .9));
		return t.observe(e), () => t.disconnect();
	}, []);
	let _ = (e) => {
		let t = Math.floor(e / 10), n = e % 10;
		return p ? {
			x: (5 - t) * 100 + 30,
			y: n * 100 + 30
		} : {
			x: n * 100 + 30,
			y: t * 100 + 30
		};
	}, v = (e) => u("games.mazing.cell", {
		r: Math.floor(e / 10) + 1,
		c: e % 10 + 1
	});
	return /* @__PURE__ */ m("div", {
		className: "mz-board",
		ref: d,
		"data-portrait": p,
		"aria-label": u(l ? "games.mazing.finalBoard" : "games.mazing.board"),
		children: /* @__PURE__ */ h(f, {
			sheetW: p ? 660 : 1060,
			sheetH: p ? 1060 : 660,
			fitKey: `mazing:${p}:${s}`,
			clampToSheet: !0,
			eligible: l ? [] : C.map((e) => ({
				key: String(e),
				rect: {
					x: _(e).x + 16,
					y: _(e).y + 16,
					w: 68,
					h: 68
				}
			})),
			highlight: "off",
			onTapEligible: (e) => o?.(Number(e)),
			readOnly: l,
			children: [C.map((t) => {
				let { x: n, y: r } = _(t), i = w.includes(t), s = [
					20,
					30,
					29,
					39
				].includes(t), c = a.includes(t), d = e.pieces.find((e) => e.cell === t);
				return /* @__PURE__ */ h("g", {
					className: "mz-square",
					"data-cell": t,
					role: l ? void 0 : "button",
					tabIndex: l ? void 0 : 0,
					"aria-label": d ? u("games.mazing.pieceAria", {
						color: u(d.color === "white" ? "games.mazing.white" : "games.mazing.black"),
						piece: u(X[d.kind]),
						cell: v(t)
					}) : `${c ? u("games.mazing.moveAria", { cell: v(t) }) : v(t)}${i ? ` · ${u("games.mazing.trap")}` : ""}`,
					onKeyDown: (e) => {
						(e.key === "Enter" || e.key === " ") && (e.preventDefault(), o?.(t));
					},
					children: [
						/* @__PURE__ */ m("rect", {
							x: n,
							y: r,
							width: "100",
							height: "100",
							fill: (Math.floor(t / 10) + t % 10) % 2 ? "#eeeae1" : "#101111",
							stroke: "#d82629",
							strokeWidth: "1.2"
						}),
						s && /* @__PURE__ */ h("g", {
							stroke: (Math.floor(t / 10) + t % 10) % 2 ? "#555856" : "#b5b8b3",
							fill: "none",
							opacity: "0.8",
							children: [/* @__PURE__ */ m("circle", {
								cx: n + 50,
								cy: r + 50,
								r: "34",
								strokeWidth: "2"
							}), /* @__PURE__ */ m("circle", {
								cx: n + 50,
								cy: r + 50,
								r: "25",
								strokeWidth: "1"
							})]
						}),
						i && /* @__PURE__ */ m("path", {
							d: `M${n + 3} ${r + 3}h94v94h-94z M${n + 14} ${r + 14}l9 11 9-11 9 11 9-11 9 11 9-11 9 11 9-11v18l-11 9 11 9-11 9 11 9v18h-18l-9-11-9 11-9-11-9 11-9-11-9 11h-9v-18l11-9-11-9 11-9-11-9z`,
							fill: "#d82629",
							fillRule: "evenodd"
						}),
						c && /* @__PURE__ */ h("g", {
							pointerEvents: "none",
							children: [
								/* @__PURE__ */ m("rect", {
									x: n + 7,
									y: r + 7,
									width: "86",
									height: "86",
									rx: "8",
									fill: "#4dcbd3",
									fillOpacity: ".22",
									stroke: "#fff",
									strokeWidth: "6"
								}),
								/* @__PURE__ */ m("rect", {
									x: n + 7,
									y: r + 7,
									width: "86",
									height: "86",
									rx: "8",
									fill: "none",
									stroke: "#117780",
									strokeWidth: "3",
									strokeDasharray: "9 6",
									children: /* @__PURE__ */ m("animate", {
										attributeName: "stroke-dashoffset",
										from: "0",
										to: "-30",
										dur: "1s",
										repeatCount: "indefinite"
									})
								}),
								/* @__PURE__ */ m("circle", {
									cx: n + 50,
									cy: r + 50,
									r: "8",
									fill: "#4dcbd3",
									stroke: "#10282a",
									strokeWidth: "2"
								})
							]
						})
					]
				}, t);
			}), e.pieces.map((n) => {
				let { x: r, y: i } = _(n.cell), a = e.last?.piece === n.id, o = M(n);
				return /* @__PURE__ */ h("g", {
					"data-piece": n.id,
					"data-kind": n.kind,
					className: "mz-piece",
					"data-selected": t === n.id,
					style: { transform: `translate(${r + 50}px,${i + 50}px)` },
					pointerEvents: "none",
					children: [/* @__PURE__ */ h("g", {
						className: a ? `mz-motion mz-${n.kind === "bridge" ? "jump" : n.kind === "meteor" ? "drop" : "slide"}` : "",
						children: [o && /* @__PURE__ */ m("circle", {
							className: a ? "mz-arrival" : "",
							r: "46",
							fill: "none",
							stroke: "#4dcbd3",
							strokeWidth: "5"
						}), /* @__PURE__ */ h("g", {
							className: a && n.locked ? "mz-flip" : "",
							style: { color: n.color === "white" ? "#191b1a" : "#f2eee4" },
							children: [
								n.kind === "messenger" ? /* @__PURE__ */ m("circle", {
									r: "39",
									fill: n.color === "white" ? "#f7f3e9" : "#191b1a",
									stroke: n.color === "white" ? "#77766d" : "#747975",
									strokeWidth: "3"
								}) : /* @__PURE__ */ m("rect", {
									x: "-39",
									y: "-39",
									width: "78",
									height: "78",
									rx: "15",
									fill: n.color === "white" ? "#f7f3e9" : "#191b1a",
									stroke: n.color === "white" ? "#77766d" : "#747975",
									strokeWidth: "3"
								}),
								/* @__PURE__ */ m("g", {
									transform: "scale(.86)",
									children: n.locked ? /* @__PURE__ */ m(te, {}) : /* @__PURE__ */ m(Z, { kind: n.kind })
								}),
								n.locked && /* @__PURE__ */ m("path", {
									d: "M-28 29l56-58",
									stroke: "currentColor",
									opacity: ".3",
									strokeWidth: "3"
								})
							]
						})]
					}, a ? `${n.id}:${e.moves}` : n.id), t === n.id && /* @__PURE__ */ m("rect", {
						x: "-45",
						y: "-45",
						width: "90",
						height: "90",
						rx: n.kind === "messenger" ? 45 : 20,
						fill: "none",
						stroke: "#4dcbd3",
						strokeWidth: "5"
					})]
				}, n.id);
			})]
		})
	});
}
//#endregion
//#region src/games/mazing/view-player.tsx
var $ = {
	messenger: "games.mazing.messengerHelp",
	orth1: "games.mazing.orth1Help",
	orth2: "games.mazing.orth2Help",
	diag1: "games.mazing.diag1Help",
	diag2: "games.mazing.diag2Help",
	bridge: "games.mazing.bridgeHelp",
	meteor: "games.mazing.meteorHelp"
};
function ne({ public: e, members: t, myRid: n, send: r }) {
	l();
	let f = e, g = c(), _ = s((e) => e.locale), v = `${n}:${f.color}`, [y, b] = i(null), [x, S] = i(null), [C, T] = i(null), [E, D] = i(0), O = f.actor === n && f.outcome === "playing", k = y?.scope === v ? f.pieces.find((e) => e.id === y.id) : void 0, A = O && k?.color === f.color && !k.locked, j = A ? F(f.pieces, k) : [], P = x?.move === f.moves && k?.id === x.id && j.includes(x.to) ? x : null, I = t.find((e) => e.rid === f.actor), L = g(f.color === "white" ? "games.mazing.white" : "games.mazing.black");
	return /* @__PURE__ */ h("div", {
		className: "mz-root",
		children: [/* @__PURE__ */ m(u, {
			adaptive: !0,
			scroll: !1,
			className: "mz-screen",
			banner: /* @__PURE__ */ h("header", {
				className: "mz-header",
				children: [/* @__PURE__ */ h("div", {
					className: "mz-title",
					children: [/* @__PURE__ */ h("b", { children: ["Mazing", /* @__PURE__ */ m("span", { children: "◉" })] }), /* @__PURE__ */ m("span", { children: g("games.mazing.progress", { n: N(f.pieces) }) })]
				}), /* @__PURE__ */ m("div", {
					className: "mz-seats",
					children: f.players.map((e, n) => {
						let r = t.find((t) => t.rid === e);
						return /* @__PURE__ */ h("div", {
							className: "mz-seat",
							"data-active": e === f.actor,
							children: [
								r && /* @__PURE__ */ m("img", {
									src: o[r.avatar % o.length],
									alt: ""
								}),
								/* @__PURE__ */ m("span", { className: `mz-dot mz-dot-${n === 0 ? "white" : "black"}` }),
								/* @__PURE__ */ m("span", { children: r ? d(r, _) : g(n === 0 ? "games.mazing.white" : "games.mazing.black") }),
								f.players.length === 1 ? /* @__PURE__ */ m("span", { className: "mz-dot mz-dot-black" }) : null
							]
						}, e);
					})
				})]
			}),
			actionsHeight: "mz-dock-height",
			actions: /* @__PURE__ */ h("footer", {
				className: "mz-dock",
				children: [/* @__PURE__ */ m("div", {
					className: "mz-context",
					"aria-live": "polite",
					children: k ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("svg", {
						viewBox: "-42 -42 84 84",
						children: /* @__PURE__ */ m(Z, { kind: k.kind })
					}), /* @__PURE__ */ h("div", { children: [/* @__PURE__ */ h("b", { children: [g(X[k.kind]), k.locked ? ` · ${g("games.mazing.locked")}` : M(k) ? ` · ${g("games.mazing.reached")}` : ""] }), /* @__PURE__ */ m("p", { children: !k.locked && (A && !j.length ? g("games.mazing.noMoves") : g($[k.kind])) })] })] }) : /* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("b", { children: O ? g("games.mazing.choose") : g("games.mazing.waiting", { name: I ? d(I, _) : L }) }), /* @__PURE__ */ m("p", { children: g("games.mazing.moves", { n: f.moves }) })] })
				}), /* @__PURE__ */ h("div", {
					className: "mz-tools",
					children: [
						/* @__PURE__ */ m("button", {
							type: "button",
							className: "mz-tool",
							onClick: () => T("guide"),
							children: g("games.mazing.legend")
						}),
						/* @__PURE__ */ m("button", {
							type: "button",
							className: "mz-tool",
							onClick: () => D((e) => e + 1),
							children: g("games.mazing.fit")
						}),
						/* @__PURE__ */ m("button", {
							type: "button",
							className: "mz-end",
							disabled: !O || f.used === 0,
							onClick: () => {
								S(null), r({ type: "endTurn" });
							},
							children: g("games.mazing.endTurn")
						})
					]
				})]
			}),
			children: /* @__PURE__ */ h("div", {
				className: "mz-stage",
				children: [/* @__PURE__ */ h("div", {
					className: "mz-turn",
					children: [
						/* @__PURE__ */ m("span", { className: `mz-dot mz-dot-${f.color}` }),
						/* @__PURE__ */ m("strong", { children: g("games.mazing.turn", { color: L }) }),
						/* @__PURE__ */ m("span", {
							className: "mz-pips",
							"aria-label": g("games.mazing.actions", { n: f.used }),
							children: [
								0,
								1,
								2
							].map((e) => /* @__PURE__ */ m("i", { "data-used": e < f.used }, e))
						})
					]
				}), /* @__PURE__ */ m(Q, {
					pub: f,
					selected: k?.id,
					targets: j,
					onCell: (e) => {
						if (k && j.includes(e)) {
							w.includes(e) || k.kind === "meteor" ? S({
								move: f.moves,
								id: k.id,
								to: e
							}) : r({
								type: "move",
								piece: k.id,
								to: e
							});
							return;
						}
						let t = f.pieces.find((t) => t.cell === e);
						S(null), b(t && t.id !== k?.id ? {
							scope: v,
							id: t.id
						} : null);
					},
					fit: E
				})]
			})
		}), (C || P) && a(/* @__PURE__ */ m("div", {
			className: "mz-modal-shade",
			onClick: () => {
				T(null), S(null);
			},
			children: /* @__PURE__ */ h("section", {
				className: "mz-modal",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": g(P ? "games.mazing.confirm" : C === "guide" ? "games.mazing.legend" : "games.mazing.concede"),
				onClick: (e) => e.stopPropagation(),
				children: [/* @__PURE__ */ m("button", {
					type: "button",
					className: "mz-close",
					onClick: () => {
						T(null), S(null);
					},
					"aria-label": g("games.mazing.close"),
					children: "×"
				}), C === "guide" ? /* @__PURE__ */ h(p, { children: [
					/* @__PURE__ */ m("h2", { children: g("games.mazing.legend") }),
					/* @__PURE__ */ m("div", {
						className: "mz-guide",
						children: Object.keys(X).map((e) => /* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("svg", {
							viewBox: "-42 -42 84 84",
							children: /* @__PURE__ */ m(Z, { kind: e })
						}), /* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("b", { children: g(X[e]) }), /* @__PURE__ */ m("p", { children: g($[e]) })] })] }, e))
					}),
					/* @__PURE__ */ m("button", {
						className: "mz-tool",
						type: "button",
						disabled: !O,
						onClick: () => T("concede"),
						children: g("games.mazing.concede")
					})
				] }) : /* @__PURE__ */ h(p, { children: [
					/* @__PURE__ */ m("h2", { children: g(P ? "games.mazing.confirm" : "games.mazing.concedeConfirm") }),
					P && /* @__PURE__ */ m("p", { children: g(k?.kind === "messenger" ? "games.mazing.messengerWarning" : k?.kind === "meteor" ? "games.mazing.meteorWarning" : "games.mazing.trapWarning") }),
					/* @__PURE__ */ h("div", {
						className: "mz-modal-actions",
						children: [/* @__PURE__ */ m("button", {
							type: "button",
							className: "mz-tool",
							onClick: () => {
								T(null), S(null);
							},
							children: g("games.mazing.cancel")
						}), /* @__PURE__ */ m("button", {
							type: "button",
							className: P ? "mz-end" : "mz-end danger-stripes",
							onClick: () => {
								r(P ? {
									type: "move",
									piece: P.id,
									to: P.to
								} : { type: "concede" }), S(null), T(null);
							},
							children: g(P ? "games.mazing.confirm" : "games.mazing.concede")
						})]
					})
				] })]
			})
		}), document.body)]
	});
}
//#endregion
//#region src/games/mazing/game-over.tsx
function re({ public: e, onPlayAgain: t, onBackToLobby: n }) {
	let r = e, a = c(), [o, s] = i(!1), l = r.outcome === "won" ? "games.mazing.wonReason" : r.outcome === "trapped" ? "games.mazing.trappedReason" : r.outcome === "blocked" ? "games.mazing.blockedReason" : "games.mazing.concededReason";
	return /* @__PURE__ */ h("div", {
		className: "mz-root mz-result",
		children: [
			/* @__PURE__ */ h("header", {
				className: "mz-result-header",
				children: [
					/* @__PURE__ */ m("span", {
						className: "mz-wordmark",
						children: "Mazing ◉"
					}),
					/* @__PURE__ */ m("h1", { children: a(r.outcome === "won" ? "games.mazing.won" : "games.mazing.lost") }),
					/* @__PURE__ */ m("p", { children: a(l) })
				]
			}),
			/* @__PURE__ */ h("div", {
				className: "mz-result-body",
				"data-review": o,
				children: [/* @__PURE__ */ h("div", {
					className: "mz-result-summary",
					children: [
						/* @__PURE__ */ h("strong", {
							className: "mz-result-count",
							children: [N(r.pieces), /* @__PURE__ */ m("small", { children: "/ 4" })]
						}),
						/* @__PURE__ */ m("p", { children: a("games.mazing.moves", { n: r.moves }) }),
						/* @__PURE__ */ m("div", {
							className: "mz-messengers",
							children: r.pieces.filter((e) => e.kind === "messenger").map((e) => /* @__PURE__ */ h("div", {
								className: `mz-medal mz-medal-${e.color}`,
								"data-arrived": M(e),
								"aria-label": `${a(e.color === "white" ? "games.mazing.white" : "games.mazing.black")} · ${a(M(e) ? "games.mazing.reached" : "games.mazing.messenger")}`,
								children: [/* @__PURE__ */ m("svg", {
									viewBox: "-42 -42 84 84",
									children: /* @__PURE__ */ m(Z, { kind: "messenger" })
								}), /* @__PURE__ */ m("span", { children: M(e) ? "✓" : "—" })]
							}, e.id))
						}),
						/* @__PURE__ */ m("button", {
							type: "button",
							className: "mz-tool",
							onClick: () => s((e) => !e),
							children: a(o ? "games.mazing.backResult" : "games.mazing.review")
						})
					]
				}), /* @__PURE__ */ m("div", {
					className: "mz-final-board",
					children: /* @__PURE__ */ m(Q, {
						pub: r,
						readOnly: !0
					})
				})]
			}),
			/* @__PURE__ */ m("footer", {
				className: "mz-result-controls",
				children: t || n ? /* @__PURE__ */ h(p, { children: [t && /* @__PURE__ */ m("button", {
					className: "mz-end",
					type: "button",
					onClick: t,
					children: a("session.result.playAgain")
				}), n && /* @__PURE__ */ m("button", {
					className: "mz-tool",
					type: "button",
					onClick: n,
					children: a("session.result.backToLobby")
				})] }) : /* @__PURE__ */ m("p", { children: a("session.result.waitHost") })
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/mazing/entry.tsx
var ie = {
	definition: V,
	View: ne,
	bot: ee,
	OverView: re,
	locales: {
		zh: {
			name: "Mazing",
			desc: "黑白携手，为四名信使打开穿越迷宫的道路。",
			rules: "目标:\n这是一个单人或双人合作游戏。让四名信使全部穿过迷宫，停在对面对应棋格颜色的起点，便共同获胜。\n准备:\n· 使用标准棋盘的八个陷阱面。每色有十八枚棋件：两名信使，正交一步墙、对角一步墙、桥和陨石各三枚，正交两步墙和对角两步墙各两枚。\n· 信使放在两端的起点，其余十六枚棋件随机放在本侧三列。开局已经位于陷阱上的棋件仍可移动。\n流程:\n· 白方先行动，之后黑白交替。每回合移动本色棋件一至三次，可以移动同一枚或不同棋件。移动一次后可以结束回合，第三次移动后自动换方。单人控制两色，双人各控制一色。\n· 信使沿对角线移动任意格。一步墙沿符号所示的正交或对角线移动一格；两步墙必须恰好移动两格。以上棋件均不能越过任何棋件。\n· 桥沿正交或对角线，跳过紧邻的连续一枚或多枚棋件，落在它们后面的第一个空格。桥不能单独移动到相邻空格。\n· 陨石可以移到任意空格，但移动后永久翻面锁定。\n· 所有落点必须是棋盘上的空格。棋件落入红色齿形陷阱时永久锁定，之后仍占据该格；经过陷阱而未停下不会触发。\n结束:\n· 四名信使同时停在各自目标时获胜。信使在获胜前可以离开已经到达的目标。\n· 任一信使被陷阱锁住，或轮到行动的颜色没有任何合法移动时，挑战失败。若判断已经无法完成，也可以确认结束挑战。没有步数上限。\n本次提供标准玩法；未包含背面棋盘及可选挑战变体。",
			white: "白方",
			black: "黑方",
			solo: "独自携手黑白",
			messenger: "信使",
			orth1: "正交一步墙",
			orth2: "正交两步墙",
			diag1: "对角一步墙",
			diag2: "对角两步墙",
			bridge: "桥",
			meteor: "陨石",
			messengerHelp: "沿对角线移动任意格，不能越过棋件。",
			orth1Help: "沿正交方向移动一格。",
			orth2Help: "沿正交方向恰好移动两格，不能越过棋件。",
			diag1Help: "沿对角线移动一格。",
			diag2Help: "沿对角线恰好移动两格，不能越过棋件。",
			bridgeHelp: "沿八个方向跳过紧邻的连续棋件，落在第一个空格。",
			meteorHelp: "移到任意空格，随后永久锁定。",
			turn: "{{color}}行动",
			waiting: "等待{{name}}行动",
			actions: "本回合已移动 {{n}} 次",
			progress: "已抵达 {{n}} / 4",
			choose: "选择一枚棋件",
			noMoves: "这枚棋件暂时无法移动。",
			locked: "已永久锁定",
			reached: "已抵达目标",
			endTurn: "结束回合",
			legend: "棋件图例",
			close: "关闭",
			fit: "回全景",
			cancel: "取消",
			confirm: "确认移动",
			trapWarning: "落入陷阱后，这枚棋件将永久锁定。",
			meteorWarning: "陨石移动后将永久锁定。",
			messengerWarning: "信使落入陷阱将使挑战失败。",
			concede: "结束挑战",
			concedeConfirm: "确认结束本次挑战？",
			moves: "总移动 {{n}} 次",
			won: "道路已通，信使齐聚",
			lost: "迷宫仍待解开",
			trappedReason: "一名信使落入了陷阱。",
			blockedReason: "轮到行动的一方已经没有合法移动。",
			concededReason: "本次挑战已经结束。",
			wonReason: "四名信使全部抵达对面起点。",
			review: "查看终盘",
			backResult: "返回结果",
			finalBoard: "最终棋盘",
			board: "迷宫棋盘",
			cell: "第 {{r}} 行，第 {{c}} 列",
			pieceAria: "{{color}}的{{piece}}，{{cell}}",
			moveAria: "移动到{{cell}}",
			trap: "陷阱",
			target: "信使起点与目标",
			hintMove: "将{{piece}}从{{from}}移动到{{to}}。",
			errTurn: "现在轮不到你行动。",
			errMove: "这次移动不符合棋件规则。",
			errMoveFirst: "至少移动一次后才能结束回合。"
		},
		en: {
			name: "Mazing",
			desc: "Join black and white to open a path through the maze for four Messengers.",
			rules: "Goal:\nA cooperative game for one or two people. Move all four Messengers across the maze to the opposite starting spaces of their matching square colours to win together.\nSetup:\n· Use the standard board with eight traps. Each colour has eighteen pieces: two Messengers; three each of orthogonal single Walls, diagonal single Walls, Bridges and Meteors; and two each of orthogonal double Walls and diagonal double Walls.\n· Place Messengers at the ends. Shuffle the other sixteen pieces into the three columns on their side. Pieces starting on traps can still move.\nTurns:\n· White starts, then the colours alternate. Move pieces of the active colour one to three times per turn, using the same or different pieces. After one move you may end the turn; the third move switches colours automatically. Solo play controls both colours; two people control one colour each.\n· Messengers move any distance diagonally. Single Walls move one square orthogonally or diagonally as shown; double Walls move exactly two squares in their indicated directions. None of these pieces may jump over pieces.\n· A Bridge jumps orthogonally or diagonally over an adjacent, unbroken line of one or more pieces, landing on the first empty square beyond them. It cannot simply move to an adjacent empty square.\n· A Meteor moves to any empty square once, then flips and becomes permanently locked.\n· Every destination must be an empty board square. Landing on a red toothed trap permanently locks the piece, which continues to occupy that square. Passing over a trap without stopping does not trigger it.\nEnding:\n· Win when all four Messengers occupy their respective targets at the same time. A Messenger may leave a reached target before the game is won.\n· Lose if a Messenger is trapped or the colour whose turn it is has no legal move. You may also confirm ending a challenge you judge impossible. There is no move limit.\nThis implementation provides standard play, without the reverse board or optional challenge variants.",
			white: "White",
			black: "Black",
			solo: "Both colours, one mind",
			messenger: "Messenger",
			orth1: "Orthogonal single Wall",
			orth2: "Orthogonal double Wall",
			diag1: "Diagonal single Wall",
			diag2: "Diagonal double Wall",
			bridge: "Bridge",
			meteor: "Meteor",
			messengerHelp: "Move any distance diagonally without jumping over pieces.",
			orth1Help: "Move one square orthogonally.",
			orth2Help: "Move exactly two squares orthogonally without jumping over pieces.",
			diag1Help: "Move one square diagonally.",
			diag2Help: "Move exactly two squares diagonally without jumping over pieces.",
			bridgeHelp: "Jump in any of eight directions over adjacent, consecutive pieces to the first empty square.",
			meteorHelp: "Move to any empty square, then become permanently locked.",
			turn: "{{color}} to move",
			waiting: "Waiting for {{name}}",
			actions: "Moves used this turn: {{n}}",
			progress: "{{n}} / 4 arrived",
			choose: "Choose a piece",
			noMoves: "This piece cannot move yet.",
			locked: "Permanently locked",
			reached: "Target reached",
			endTurn: "End turn",
			legend: "Piece guide",
			close: "Close",
			fit: "Fit board",
			cancel: "Cancel",
			confirm: "Confirm move",
			trapWarning: "This piece will become permanently locked in the trap.",
			meteorWarning: "The Meteor will become permanently locked after this move.",
			messengerWarning: "Trapping a Messenger will end the challenge in defeat.",
			concede: "End challenge",
			concedeConfirm: "End this challenge?",
			moves: "{{n}} total moves",
			won: "Paths opened, Messengers united",
			lost: "The maze awaits another attempt",
			trappedReason: "A Messenger fell into a trap.",
			blockedReason: "The active colour has no legal move.",
			concededReason: "This challenge has ended.",
			wonReason: "All four Messengers reached the opposite starting spaces.",
			review: "View final board",
			backResult: "Back to results",
			finalBoard: "Final board",
			board: "Maze board",
			cell: "row {{r}}, column {{c}}",
			pieceAria: "{{color}} {{piece}}, {{cell}}",
			moveAria: "Move to {{cell}}",
			trap: "Trap",
			target: "Messenger start and target",
			hintMove: "Move the {{piece}} from {{from}} to {{to}}.",
			errTurn: "It is not your turn.",
			errMove: "That move is not legal for this piece.",
			errMoveFirst: "Make at least one move before ending your turn."
		}
	}
};
//#endregion
export { ie as default };
