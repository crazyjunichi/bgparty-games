import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { useT as a } from "@bgparty/sdk/i18n";
import { GameScreen as o } from "@bgparty/sdk/ui/game-screen";
import { BottomSheet as s } from "@bgparty/sdk/bottom-sheet";
import { Fragment as c, jsx as l, jsxs as u } from "react/jsx-runtime";
//#region src/games/coffeeroaster/data.ts
var d = (e, t, n, r, i, a, o, s) => ({
	id: e,
	nameKey: `games.coffeeroaster.card${e}`,
	group: t,
	difficulty: n,
	specialty: r,
	bag: {
		bean0: i[0],
		hard: i[1],
		moisture: i[2],
		defective: i[3]
	},
	flavors: {
		body: a[0],
		acidity: a[1],
		aroma: a[2]
	},
	roastScale: Object.fromEntries(o),
	flavorReq: {
		body: s[0],
		acidity: s[1],
		aroma: s[2],
		sweet: s[3]
	}
}), f = [
	d(0, 1, "beginner", !1, [
		14,
		2,
		2,
		1
	], [
		2,
		3,
		2
	], [
		[11, 5],
		[12, 6],
		[13, 7],
		[14, 10],
		[15, 6],
		[16, 5],
		[17, 4],
		[18, 3]
	], [
		1,
		1,
		1,
		0
	]),
	d(1, 1, "expert", !0, [
		12,
		5,
		5,
		0
	], [
		5,
		3,
		4
	], [
		[11, 2],
		[12, 4],
		[13, 7],
		[14, 14],
		[15, 4],
		[16, 3],
		[17, 2],
		[18, 2]
	], [
		2,
		1,
		1,
		0
	]),
	d(2, 1, "expert", !0, [
		10,
		6,
		7,
		0
	], [
		4,
		3,
		5
	], [
		[11, 3],
		[12, 6],
		[13, 14],
		[14, 7],
		[15, 4],
		[16, 2],
		[17, 0],
		[18, 0]
	], [
		1,
		1,
		2,
		0
	]),
	d(3, 1, "beginner", !1, [
		15,
		2,
		2,
		2
	], [
		1,
		2,
		3
	], [
		[11, 5],
		[12, 6],
		[13, 10],
		[14, 7],
		[15, 5],
		[16, 5],
		[17, 5],
		[18, 4]
	], [
		1,
		1,
		1,
		0
	]),
	d(4, 1, "beginner", !1, [
		13,
		3,
		3,
		1
	], [
		2,
		2,
		3
	], [
		[11, 4],
		[12, 4],
		[13, 6],
		[14, 10],
		[15, 7],
		[16, 6],
		[17, 4],
		[18, 4]
	], [
		0,
		1,
		2,
		0
	]),
	d(5, 1, "beginner", !1, [
		13,
		4,
		4,
		1
	], [
		2,
		3,
		3
	], [
		[11, 5],
		[12, 5],
		[13, 7],
		[14, 10],
		[15, 6],
		[16, 6],
		[17, 4],
		[18, 4]
	], [
		0,
		2,
		1,
		0
	]),
	d(6, 2, "expert", !1, [
		9,
		9,
		5,
		6
	], [
		3,
		2,
		4
	], [
		[13, 4],
		[14, 4],
		[15, 5],
		[16, 5],
		[17, 9],
		[18, 13],
		[19, 8],
		[20, 4]
	], [
		0,
		1,
		2,
		0
	]),
	d(7, 2, "expert", !1, [
		8,
		10,
		8,
		4
	], [
		3,
		4,
		3
	], [
		[13, 4],
		[14, 4],
		[15, 5],
		[16, 7],
		[17, 13],
		[18, 9],
		[19, 6],
		[20, 4]
	], [
		1,
		0,
		2,
		0
	]),
	d(8, 2, "expert", !0, [
		4,
		14,
		7,
		0
	], [
		3,
		4,
		5
	], [
		[13, 3],
		[14, 3],
		[15, 4],
		[16, 5],
		[17, 15],
		[18, 8],
		[19, 5],
		[20, 4]
	], [
		0,
		2,
		2,
		0
	]),
	d(9, 2, "advanced", !1, [
		14,
		4,
		6,
		1
	], [
		4,
		2,
		3
	], [
		[13, 4],
		[14, 4],
		[15, 6],
		[16, 7],
		[17, 12],
		[18, 8],
		[19, 6],
		[20, 5]
	], [
		2,
		0,
		1,
		0
	]),
	d(10, 2, "advanced", !1, [
		13,
		5,
		4,
		4
	], [
		3,
		3,
		3
	], [
		[13, 4],
		[14, 4],
		[15, 6],
		[16, 6],
		[17, 8],
		[18, 12],
		[19, 7],
		[20, 5]
	], [
		1,
		1,
		1,
		0
	]),
	d(11, 2, "advanced", !1, [
		12,
		6,
		4,
		3
	], [
		3,
		4,
		4
	], [
		[13, 4],
		[14, 4],
		[15, 8],
		[16, 12],
		[17, 7],
		[18, 6],
		[19, 5],
		[20, 4]
	], [
		1,
		1,
		1,
		0
	]),
	d(12, 2, "beginner", !1, [
		11,
		6,
		5,
		3
	], [
		3,
		3,
		4
	], [
		[13, 5],
		[14, 5],
		[15, 7],
		[16, 10],
		[17, 6],
		[18, 5],
		[19, 4],
		[20, 3]
	], [
		0,
		1,
		2,
		0
	]),
	d(13, 2, "beginner", !1, [
		13,
		3,
		1,
		2
	], [
		2,
		2,
		3
	], [
		[13, 6],
		[14, 6],
		[15, 7],
		[16, 10],
		[17, 6],
		[18, 4],
		[19, 3],
		[20, 3]
	], [
		0,
		1,
		2,
		0
	]),
	d(14, 2, "beginner", !1, [
		12,
		6,
		6,
		2
	], [
		3,
		2,
		3
	], [
		[13, 5],
		[14, 6],
		[15, 10],
		[16, 7],
		[17, 5],
		[18, 5],
		[19, 4],
		[20, 3]
	], [
		1,
		0,
		2,
		0
	]),
	d(15, 2, "beginner", !1, [
		14,
		4,
		7,
		2
	], [
		4,
		4,
		2
	], [
		[13, 4],
		[14, 6],
		[15, 10],
		[16, 7],
		[17, 5],
		[18, 5],
		[19, 4],
		[20, 4]
	], [
		1,
		2,
		0,
		0
	]),
	d(16, 3, "expert", !0, [
		5,
		13,
		8,
		0
	], [
		5,
		4,
		4
	], [
		[15, 4],
		[16, 4],
		[17, 6],
		[18, 7],
		[19, 9],
		[20, 15],
		[21, 6],
		[22, 4]
	], [
		1,
		0,
		2,
		1
	]),
	d(17, 3, "expert", !0, [
		6,
		12,
		7,
		0
	], [
		3,
		4,
		5
	], [
		[15, 4],
		[16, 4],
		[17, 6],
		[18, 8],
		[19, 15],
		[20, 9],
		[21, 5],
		[22, 4]
	], [
		0,
		1,
		2,
		1
	]),
	d(18, 3, "advanced", !1, [
		12,
		4,
		7,
		6
	], [
		4,
		3,
		4
	], [
		[14, 4],
		[15, 5],
		[16, 6],
		[17, 8],
		[18, 12],
		[19, 7],
		[20, 6],
		[21, 4]
	], [
		1,
		1,
		1,
		1
	]),
	d(19, 3, "advanced", !1, [
		10,
		7,
		7,
		4
	], [
		4,
		2,
		4
	], [
		[15, 4],
		[16, 5],
		[17, 7],
		[18, 7],
		[19, 8],
		[20, 12],
		[21, 6],
		[22, 5]
	], [
		1,
		0,
		2,
		1
	]),
	d(20, 3, "beginner", !1, [
		13,
		5,
		8,
		2
	], [
		3,
		4,
		3
	], [
		[15, 4],
		[16, 5],
		[17, 6],
		[18, 7],
		[19, 7],
		[20, 10],
		[21, 5],
		[22, 5]
	], [
		2,
		0,
		1,
		1
	]),
	d(21, 3, "beginner", !1, [
		12,
		5,
		5,
		3
	], [
		3,
		3,
		3
	], [
		[15, 5],
		[16, 5],
		[17, 6],
		[18, 7],
		[19, 10],
		[20, 7],
		[21, 4],
		[22, 4]
	], [
		1,
		2,
		0,
		1
	])
], p = {
	bean0: 18,
	bean1: 18,
	bean2: 18,
	bean3: 15,
	bean4: 12,
	hard: 14,
	burnt: 8,
	moisture: 8,
	smoke: 5,
	defective: 6,
	body: 5,
	acidity: 5,
	aroma: 5,
	wild: 1
}, m = {
	10: 2,
	12: 3
};
function h(e) {
	return e >= 7 ? 6 : e >= 5 ? 7 : e >= 3 ? 8 : 9;
}
var g = [
	0,
	1,
	3,
	6,
	10
], _ = {
	3: 1,
	4: 2,
	5: 3,
	6: 4,
	7: 5
};
function v(e) {
	return e >= 15 ? [
		"beginner",
		"advanced",
		"expert"
	] : e >= 10 ? ["beginner", "advanced"] : ["beginner"];
}
var y = [
	60,
	53,
	47,
	40,
	35,
	28,
	20,
	0
], b = [
	"extraBean",
	"sweetness",
	"selection",
	"exchange",
	"tray"
], x = [
	["body", "aroma"],
	["any", "aroma"],
	["acidity", "aroma"],
	["body", "acidity"],
	["any", "acidity"]
], S = {
	id: "coffeeroaster",
	tier: "beta",
	mechanics: ["deck-bag-building", "push-your-luck"],
	interactionTags: [],
	nameKey: "games.coffeeroaster.name",
	descKey: "games.coffeeroaster.desc",
	rulesKey: "games.coffeeroaster.rules",
	icon: "☕",
	iconImg: "games/coffeeroaster.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/coffeeroaster/en.pdf" },
	minPlayers: 1,
	maxPlayers: 1,
	bestPlayers: [1],
	accent: "#8d5a3a",
	releasedAt: "2026-09-21",
	search: {
		py: "ka fei hong bei shi",
		init: "kfhbs"
	},
	hotseat: "cover"
}, C = t.enum([
	"bean0",
	"bean1",
	"bean2",
	"bean3",
	"bean4",
	"hard",
	"burnt",
	"moisture",
	"smoke",
	"defective",
	"body",
	"acidity",
	"aroma",
	"wild"
]), w = t.enum([
	"body",
	"acidity",
	"aroma",
	"wild"
]), T = t.object({ mode: t.enum(["single", "challenge"]).default("single") }).default({ mode: "single" }), E = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("select"),
		cardId: t.int().min(0).max(21)
	}),
	t.object({ type: t.literal("draw") }),
	t.object({
		type: t.literal("fxWild"),
		bean: t.enum(["bean0", "bean1"])
	}),
	t.object({
		type: t.literal("fxDraw2"),
		use: w
	}),
	t.object({
		type: t.literal("fxRedraw2"),
		use: w,
		back: t.tuple([C, C])
	}),
	t.object({
		type: t.literal("fxFive2"),
		use: w
	}),
	t.object({
		type: t.literal("fxFive2Pick"),
		remove: t.tuple([t.int().min(0).max(4), t.int().min(0).max(4)])
	}),
	t.object({
		type: t.literal("fxRemoval"),
		use: w
	}),
	t.object({
		type: t.literal("flavor"),
		effect: t.enum([
			"concentrate",
			"preserve",
			"disperse"
		]),
		use: w,
		beans: t.array(C).min(1).max(2),
		into: t.tuple([C, C]).optional(),
		target: t.int().min(0).max(4),
		slot: t.int().min(0).max(1)
	}),
	t.object({ type: t.literal("roast") }),
	t.object({ type: t.literal("toCup") }),
	t.object({ type: t.literal("cupDraw") }),
	t.object({
		type: t.literal("cupPlace"),
		dest: t.enum(["cup", "tray"]),
		pick: t.int().min(0).max(1).optional()
	}),
	t.object({
		type: t.literal("exchange"),
		out: t.tuple([t.int().min(0).max(9), t.int().min(0).max(9)])
	}),
	t.object({
		type: t.literal("exchangePick"),
		keep: t.tuple([t.int().min(0).max(2), t.int().min(0).max(2)])
	}),
	t.object({ type: t.literal("cupSkipExchange") }),
	t.object({ type: t.literal("next") })
]), D = t.partialRecord(C, t.int().nonnegative()), O = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("normal"),
		token: C
	}),
	t.object({
		kind: t.literal("selection"),
		tokens: t.array(C).min(1).max(2)
	}),
	t.object({
		kind: t.literal("exchange"),
		tokens: t.array(C).min(1).max(3),
		spaces: t.tuple([t.int(), t.int()])
	}),
	t.object({
		kind: t.literal("five2"),
		tokens: t.array(C).min(3).max(5)
	})
]), k = t.object({
	roastTotal: t.int(),
	roastPoints: t.int(),
	flavorMatches: t.int().min(0).max(4),
	flavorPoints: t.int(),
	skillGroups: t.array(t.object({
		level: t.int(),
		count: t.int(),
		points: t.int()
	})),
	skillPoints: t.int(),
	penalties: t.object({
		hard: t.int(),
		burnt: t.int(),
		smoke: t.int(),
		defective: t.int(),
		noFlavor: t.int(),
		empty: t.int()
	}),
	penaltyPoints: t.int(),
	total: t.int()
}), ee = t.object({
	mode: t.enum(["single", "challenge"]),
	phase: t.enum([
		"select",
		"roast",
		"cup",
		"score",
		"done"
	]),
	roastIndex: t.int().min(0).max(2),
	results: t.array(t.object({
		cardId: t.int(),
		score: k
	})),
	cardId: t.int().nullable(),
	bag: D,
	box: D,
	thermostat: t.int().min(6).max(14),
	smokeLeft: t.record(t.string(), t.int().nonnegative()),
	round: t.int().nonnegative(),
	drawn: t.array(C).nullable(),
	flavorLocked: t.boolean(),
	immediateUsed: t.array(t.enum([
		"wild",
		"draw2",
		"redraw2",
		"five2",
		"removal"
	])),
	spent: t.array(w),
	wildSlot: t.object({
		bean0: t.boolean(),
		bean1: t.boolean()
	}),
	cupFx: t.array(t.object({
		effect: t.enum([
			"extraBean",
			"sweetness",
			"selection",
			"exchange",
			"tray"
		]),
		filled: t.array(w.nullable()).length(2)
	})).length(5),
	cup: t.array(t.union([
		C,
		t.literal("extra"),
		t.literal("sweet")
	]).nullable()).length(10),
	tray: t.array(C),
	pending: O.nullable(),
	exchangeUsed: t.boolean(),
	score: k.nullable()
}), te = t.object({}), A = (e) => ({ code: e }), ne = [
	"bean0",
	"bean1",
	"bean2",
	"bean3",
	"bean4"
], j = (e) => ne.includes(e) ? Number(e[4]) : -1, M = {
	concentrate: "body",
	preserve: "acidity",
	disperse: "aroma"
}, N = (e) => Object.values(e.bag).reduce((e, t) => e + (t ?? 0), 0), P = (e, t) => e.cupFx.some((e) => e.effect === t && e.filled.every((e) => e !== null)), re = (e) => 3 + (P(e, "tray") ? 2 : 0);
function F(t) {
	let n = [];
	for (let e of Object.keys(t.bag)) {
		let r = t.bag[e] ?? 0;
		for (let t = 0; t < r; t++) n.push(e);
	}
	if (n.length === 0) return null;
	let r = e(t.seed, t.cursor, n.length);
	t.cursor += 1;
	let i = n[r];
	return t.bag[i] = (t.bag[i] ?? 0) - 1, i;
}
function I(e, t) {
	let n = [];
	for (let r = 0; r < t; r++) {
		let t = F(e);
		if (t === null) break;
		t === "moisture" ? e.box.moisture = (e.box.moisture ?? 0) + 1 : n.push(t);
	}
	return n;
}
function L(e) {
	for (;;) {
		let t = F(e);
		if (t === null) return null;
		if (t === "moisture") e.box.moisture = (e.box.moisture ?? 0) + 1;
		else return t;
	}
}
function R(e, t) {
	let n = e.drawn?.indexOf(t) ?? -1;
	return n < 0 || !e.drawn ? !1 : (e.drawn.splice(n, 1), !0);
}
function z(e, t, n) {
	return t !== "wild" && n !== "any" && t !== n ? !1 : R(e, t);
}
function B(e) {
	return e.cup.findIndex((e) => e === null);
}
function V(e) {
	let t = f[e.cardId ?? 0], n = 0, r = [
		0,
		0,
		0,
		0,
		0
	], i = {
		hard: 0,
		burnt: 0,
		smoke: 0,
		defective: 0
	}, a = [], o = 0, s = 0;
	for (let t of e.cup) if (t === null) s += 1;
	else if (t === "extra") n += 3, r[3] += 1;
	else if (t === "sweet") o += 1;
	else {
		let e = j(t);
		e >= 0 ? (n += e, r[e] += 1) : t === "hard" ? i.hard += 1 : t === "burnt" ? i.burnt += 1 : t === "smoke" ? i.smoke += 1 : t === "defective" ? i.defective += 1 : a.push(t);
	}
	let c = t.roastScale[n] ?? 0, l = [
		...Array(t.flavorReq.body).fill("body"),
		...Array(t.flavorReq.acidity).fill("acidity"),
		...Array(t.flavorReq.aroma).fill("aroma"),
		...Array(t.flavorReq.sweet).fill("sweet")
	], u = [...a, ...Array(o).fill("sweet")], d = (e, t) => e === t || e === "wild" || e === "sweet", p = (e, t) => {
		if (e >= l.length) return 0;
		let n = p(e + 1, t);
		for (let r = 0; r < u.length; r++) !t[r] && d(u[r], l[e]) && (t[r] = !0, n = Math.max(n, 1 + p(e + 1, t)), t[r] = !1);
		return n;
	}, m = p(0, u.map(() => !1)), h = g[m], v = [], y = 0;
	r.forEach((e, t) => {
		if (e >= 3) {
			let n = _[Math.min(e, 7)];
			v.push({
				level: t,
				count: e,
				points: n
			}), y += n;
		}
	});
	let b = {
		hard: -i.hard,
		burnt: -i.burnt,
		smoke: -i.smoke,
		defective: -2 * i.defective,
		noFlavor: a.length + o === 0 ? -3 : 0,
		empty: s > 0 ? -5 : 0
	}, x = Object.values(b).reduce((e, t) => e + t, 0);
	return {
		roastTotal: n,
		roastPoints: c,
		flavorMatches: m,
		flavorPoints: h,
		skillGroups: v,
		skillPoints: y,
		penalties: b,
		penaltyPoints: x,
		total: c + h + y + x
	};
}
function H(e) {
	e.score = V(e), e.phase = "score";
}
function ie(t, n) {
	let r = f[n];
	t.cardId = n;
	let i = {
		bean0: r.bag.bean0,
		hard: r.bag.hard,
		moisture: r.bag.moisture,
		defective: r.bag.defective,
		body: r.flavors.body,
		acidity: r.flavors.acidity,
		aroma: r.flavors.aroma
	}, a = {};
	for (let e of Object.keys(p)) a[e] = p[e] - (i[e] ?? 0);
	t.bag = i, t.box = a, t.thermostat = h(r.bag.moisture), t.smokeLeft = Object.fromEntries(Object.entries(m).map(([e, t]) => [e, t])), t.round = 0, t.drawn = null, t.flavorLocked = !1, t.immediateUsed = [], t.spent = [], t.wildSlot = {
		bean0: !1,
		bean1: !1
	};
	let o = [...b];
	for (let n = o.length - 1; n > 0; n--) {
		let r = e(t.seed, t.cursor, n + 1);
		t.cursor += 1, [o[n], o[r]] = [o[r], o[n]];
	}
	t.cupFx = o.map((e) => ({
		effect: e,
		filled: [null, null]
	})), t.cup = Array(10).fill(null), t.tray = [], t.pending = null, t.exchangeUsed = !1, t.score = null, t.phase = "roast";
}
function ae(e, t, n) {
	return { state: {
		host: t[0],
		seed: n,
		cursor: 0,
		mode: e.mode,
		phase: "select",
		roastIndex: 0,
		results: [],
		cardId: null,
		bag: {},
		box: {},
		thermostat: 6,
		smokeLeft: {},
		round: 0,
		drawn: null,
		flavorLocked: !1,
		immediateUsed: [],
		spent: [],
		wildSlot: {
			bean0: !1,
			bean1: !1
		},
		cupFx: b.map((e) => ({
			effect: e,
			filled: [null, null]
		})),
		cup: Array(10).fill(null),
		tray: [],
		pending: null,
		exchangeUsed: !1,
		score: null
	} };
}
function oe(e, t, n) {
	if (n.by !== e.host) return A("games.coffeeroaster.errNotPlayer");
	let r = structuredClone(e), i = [];
	switch (t.type) {
		case "select": {
			if (r.phase !== "select") return A("games.coffeeroaster.errPhase");
			let e = f[t.cardId];
			if (!e) return A("games.coffeeroaster.errPhase");
			if (r.mode === "challenge") {
				if (e.group !== r.roastIndex + 1) return A("games.coffeeroaster.errCardGroup");
				if (r.roastIndex > 0) {
					let t = r.results[r.roastIndex - 1].score.total;
					if (!v(t).includes(e.difficulty)) return A("games.coffeeroaster.errCardDifficulty");
				}
			}
			return ie(r, t.cardId), {
				state: r,
				fx: i
			};
		}
		case "draw":
			if (r.phase !== "roast" || r.pending) return A("games.coffeeroaster.errPhase");
			if (r.drawn !== null) return A("games.coffeeroaster.errDrawn");
			if (r.round += 1, r.round > 1) {
				if (r.thermostat >= 14) return A("games.coffeeroaster.errMustCup");
				r.thermostat += 1;
				let e = r.smokeLeft[String(r.thermostat)] ?? 0;
				e > 0 && (r.bag.smoke = (r.bag.smoke ?? 0) + e, r.smokeLeft[String(r.thermostat)] = 0);
			}
			return r.drawn = I(r, r.thermostat), r.flavorLocked = !1, {
				state: r,
				fx: i
			};
		case "fxWild":
			if (r.phase !== "roast" || !r.drawn || r.pending) return A("games.coffeeroaster.errPhase");
			if (r.flavorLocked) return A("games.coffeeroaster.errFlavorLocked");
			if (r.immediateUsed.includes("wild") || r.wildSlot[t.bean]) return A("games.coffeeroaster.errFxUsed");
			if (!R(r, t.bean)) return A("games.coffeeroaster.errNoToken");
			if (r.wildSlot[t.bean] = !0, r.wildSlot.bean0 && r.wildSlot.bean1) {
				if ((r.box.wild ?? 0) < 1) return A("games.coffeeroaster.errBox");
				r.box.bean0 = (r.box.bean0 ?? 0) + 1, r.box.bean1 = (r.box.bean1 ?? 0) + 1, r.box.wild = (r.box.wild ?? 0) - 1, r.drawn.push("wild"), r.immediateUsed.push("wild"), r.wildSlot = {
					bean0: !1,
					bean1: !1
				};
			}
			return {
				state: r,
				fx: i
			};
		case "fxDraw2": return r.phase !== "roast" || !r.drawn || r.pending ? A("games.coffeeroaster.errPhase") : r.flavorLocked ? A("games.coffeeroaster.errFlavorLocked") : r.immediateUsed.includes("draw2") ? A("games.coffeeroaster.errFxUsed") : N(r) < 2 ? A("games.coffeeroaster.errBagShort") : z(r, t.use, "body") ? (r.spent.push(t.use), r.drawn.push(...I(r, 2)), r.immediateUsed.push("draw2"), {
			state: r,
			fx: i
		}) : A("games.coffeeroaster.errNoToken");
		case "fxRedraw2":
			if (r.phase !== "roast" || !r.drawn || r.pending) return A("games.coffeeroaster.errPhase");
			if (r.flavorLocked) return A("games.coffeeroaster.errFlavorLocked");
			if (r.immediateUsed.includes("redraw2")) return A("games.coffeeroaster.errFxUsed");
			if (!z(r, t.use, "any")) return A("games.coffeeroaster.errNoToken");
			r.spent.push(t.use);
			for (let e of t.back) {
				if (!R(r, e)) return A("games.coffeeroaster.errNoToken");
				r.bag[e] = (r.bag[e] ?? 0) + 1;
			}
			return r.drawn.push(...I(r, 2)), r.immediateUsed.push("redraw2"), {
				state: r,
				fx: i
			};
		case "fxFive2": {
			if (r.phase !== "roast" || !r.drawn || r.pending) return A("games.coffeeroaster.errPhase");
			if (r.flavorLocked) return A("games.coffeeroaster.errFlavorLocked");
			if (r.immediateUsed.includes("five2")) return A("games.coffeeroaster.errFxUsed");
			if (N(r) < 5) return A("games.coffeeroaster.errBagShort");
			if (!z(r, t.use, "aroma")) return A("games.coffeeroaster.errNoToken");
			r.spent.push(t.use), r.immediateUsed.push("five2");
			let e = I(r, 5);
			if (e.length <= 2) for (let t of e) r.box[t] = (r.box[t] ?? 0) + 1;
			else r.pending = {
				kind: "five2",
				tokens: e
			};
			return {
				state: r,
				fx: i
			};
		}
		case "fxFive2Pick": {
			if (r.pending?.kind !== "five2") return A("games.coffeeroaster.errPending");
			let [e, n] = t.remove;
			if (e === n || e >= r.pending.tokens.length || n >= r.pending.tokens.length) return A("games.coffeeroaster.errPending");
			let a = r.pending.tokens.filter((t, r) => r !== e && r !== n);
			r.box[r.pending.tokens[e]] = (r.box[r.pending.tokens[e]] ?? 0) + 1, r.box[r.pending.tokens[n]] = (r.box[r.pending.tokens[n]] ?? 0) + 1;
			for (let e of a) r.bag[e] = (r.bag[e] ?? 0) + 1;
			return r.pending = null, {
				state: r,
				fx: i
			};
		}
		case "fxRemoval": return r.phase !== "roast" || !r.drawn || r.pending ? A("games.coffeeroaster.errPhase") : r.flavorLocked ? A("games.coffeeroaster.errFlavorLocked") : r.immediateUsed.includes("removal") ? A("games.coffeeroaster.errFxUsed") : z(r, t.use, "any") ? (r.spent.push(t.use), r.drawn = r.drawn.filter((e) => e === "burnt" || e === "smoke" || e === "defective" ? (r.box[e] = (r.box[e] ?? 0) + 1, !1) : !0), r.immediateUsed.push("removal"), {
			state: r,
			fx: i
		}) : A("games.coffeeroaster.errNoToken");
		case "flavor": {
			if (r.phase !== "roast" || !r.drawn || r.pending) return A("games.coffeeroaster.errPhase");
			let e = M[t.effect], n = r.cupFx[t.target], a = x[t.target][t.slot];
			if (!n || n.filled[t.slot] !== null || a !== "any" && a !== e) return A("games.coffeeroaster.errSlot");
			if (!z(r, t.use, e)) return A("games.coffeeroaster.errNoToken");
			let o = (e) => R(r, e);
			if (t.effect === "concentrate") {
				let [e, n] = t.beans, i = j(e), a = j(n ?? "");
				if (t.beans.length !== 2 || i < 1 || i > 3 || a < 1 || a > 3 || i + a > 4) return A("games.coffeeroaster.errBeans");
				let s = `bean${i + a}`;
				if ((r.box[s] ?? 0) < 1) return A("games.coffeeroaster.errBox");
				if (!o(e) || !o(n)) return A("games.coffeeroaster.errNoToken");
				r.box[e] = (r.box[e] ?? 0) + 1, r.box[n] = (r.box[n] ?? 0) + 1, r.box[s] = (r.box[s] ?? 0) - 1, r.bag[s] = (r.bag[s] ?? 0) + 1;
			} else if (t.effect === "preserve") {
				if (t.beans.length !== 2) return A("games.coffeeroaster.errBeans");
				let [e, n] = t.beans;
				if (j(e) < 0 || j(n) < 0) return A("games.coffeeroaster.errBeans");
				if (!o(e) || !o(n)) return A("games.coffeeroaster.errNoToken");
				r.bag[e] = (r.bag[e] ?? 0) + 1, r.bag[n] = (r.bag[n] ?? 0) + 1;
			} else {
				if (t.beans.length !== 1 || !t.into) return A("games.coffeeroaster.errBeans");
				let e = t.beans[0], n = j(e), [i, a] = t.into, s = j(i), c = j(a);
				if (n < 2 || n > 4 || s < 1 || c < 1 || s + c !== n) return A("games.coffeeroaster.errBeans");
				let l = {};
				l[i] = (l[i] ?? 0) + 1, l[a] = (l[a] ?? 0) + 1;
				for (let [e, t] of Object.entries(l)) if ((r.box[e] ?? 0) < t) return A("games.coffeeroaster.errBox");
				if (!o(e)) return A("games.coffeeroaster.errNoToken");
				r.box[e] = (r.box[e] ?? 0) + 1;
				for (let [e, t] of Object.entries(l)) r.box[e] = (r.box[e] ?? 0) - t, r.bag[e] = (r.bag[e] ?? 0) + t;
			}
			return n.filled[t.slot] = t.use, r.flavorLocked = !0, {
				state: r,
				fx: i
			};
		}
		case "roast": {
			if (r.phase !== "roast" || r.pending) return A("games.coffeeroaster.errPhase");
			if (r.drawn === null) return A("games.coffeeroaster.errDrawn");
			let e = m[r.thermostat] === void 0 ? 1 : 2, t = [...r.drawn].sort((e, t) => j(t) - j(e));
			for (let n of t) {
				let t = null;
				if (n === "hard") t = "bean0";
				else {
					let r = j(n);
					r >= 0 && (t = r + e > 4 ? "burnt" : `bean${r + e}`);
				}
				t && (r.box[t] ?? 0) > 0 ? (r.box[t] = (r.box[t] ?? 0) - 1, r.bag[t] = (r.bag[t] ?? 0) + 1, r.box[n] = (r.box[n] ?? 0) + 1) : r.bag[n] = (r.bag[n] ?? 0) + 1;
			}
			return r.drawn = null, {
				state: r,
				fx: i
			};
		}
		case "toCup": return r.phase !== "roast" || r.drawn !== null || r.pending ? A("games.coffeeroaster.errPhase") : (P(r, "extraBean") && (r.cup[0] = "extra"), P(r, "sweetness") && (r.cup[1] = "sweet"), r.phase = "cup", {
			state: r,
			fx: i
		});
		case "cupDraw": {
			if (r.phase !== "cup" || r.pending) return A("games.coffeeroaster.errPhase");
			let e = B(r);
			if (e === -1) return A("games.coffeeroaster.errCupFull");
			if (N(r) === 0) return H(r), {
				state: r,
				fx: i
			};
			if (P(r, "selection") && (e === 3 || e === 4)) {
				let e = [], t = L(r);
				t && e.push(t);
				let n = L(r);
				if (n && e.push(n), e.length === 0) return H(r), {
					state: r,
					fx: i
				};
				r.pending = {
					kind: "selection",
					tokens: e
				};
			} else {
				let e = L(r);
				if (e === null) return H(r), {
					state: r,
					fx: i
				};
				r.pending = {
					kind: "normal",
					token: e
				};
			}
			return {
				state: r,
				fx: i
			};
		}
		case "cupPlace": {
			if (r.phase !== "cup" || !r.pending) return A("games.coffeeroaster.errPhase");
			let e = r.pending;
			if (e.kind === "exchange" || e.kind === "five2") return A("games.coffeeroaster.errPending");
			if (e.kind === "selection" && t.dest !== "cup" || t.dest === "tray" && r.tray.length >= re(r)) return A("games.coffeeroaster.errTrayFull");
			if (e.kind === "normal") t.dest === "cup" ? r.cup[B(r)] = e.token : r.tray.push(e.token);
			else {
				let n = t.pick ?? 0;
				if (n >= e.tokens.length) return A("games.coffeeroaster.errPending");
				r.cup[B(r)] = e.tokens[n];
				for (let t = 0; t < e.tokens.length; t++) t !== n && (r.bag[e.tokens[t]] = (r.bag[e.tokens[t]] ?? 0) + 1);
			}
			return r.pending = null, B(r) === -1 ? (!P(r, "exchange") || r.exchangeUsed) && H(r) : N(r) === 0 && H(r), {
				state: r,
				fx: i
			};
		}
		case "exchange": {
			if (r.phase !== "cup" || r.pending) return A("games.coffeeroaster.errPhase");
			if (!P(r, "exchange") || r.exchangeUsed) return A("games.coffeeroaster.errExchange");
			if (B(r) !== -1) return A("games.coffeeroaster.errCupNotFull");
			let [e, n] = [...t.out].sort((e, t) => e - t);
			if (e === n) return A("games.coffeeroaster.errExchange");
			for (let t of [e, n]) {
				let e = r.cup[t];
				if (e === null || e === "extra" || e === "sweet") return A("games.coffeeroaster.errExchange");
			}
			r.exchangeUsed = !0;
			for (let t of [e, n]) {
				let e = r.cup[t];
				r.cup[t] = null, r.bag[e] = (r.bag[e] ?? 0) + 1;
			}
			let a = [];
			for (let e = 0; e < 3; e++) {
				let e = L(r);
				if (e === null) break;
				a.push(e);
			}
			if (a.length < 2) {
				for (let t = 0; t < a.length; t++) r.cup[[e, n][t]] = a[t];
				H(r);
			} else r.pending = {
				kind: "exchange",
				tokens: a,
				spaces: [e, n]
			};
			return {
				state: r,
				fx: i
			};
		}
		case "exchangePick": {
			if (r.pending?.kind !== "exchange") return A("games.coffeeroaster.errPending");
			let e = r.pending, [n, a] = t.keep;
			if (n === a || n >= e.tokens.length || a >= e.tokens.length) return A("games.coffeeroaster.errPending");
			r.cup[e.spaces[0]] = e.tokens[n], r.cup[e.spaces[1]] = e.tokens[a];
			for (let t = 0; t < e.tokens.length; t++) t !== n && t !== a && (r.bag[e.tokens[t]] = (r.bag[e.tokens[t]] ?? 0) + 1);
			return r.pending = null, H(r), {
				state: r,
				fx: i
			};
		}
		case "cupSkipExchange": return r.phase !== "cup" || r.pending ? A("games.coffeeroaster.errPhase") : !P(r, "exchange") || r.exchangeUsed ? A("games.coffeeroaster.errExchange") : B(r) === -1 ? (r.exchangeUsed = !0, H(r), {
			state: r,
			fx: i
		}) : A("games.coffeeroaster.errCupNotFull");
		case "next": return r.phase !== "score" || !r.score ? A("games.coffeeroaster.errPhase") : (r.results.push({
			cardId: r.cardId ?? 0,
			score: r.score
		}), r.mode === "single" || r.roastIndex === 2 ? r.phase = "done" : (r.roastIndex += 1, r.phase = "select", r.cardId = null), {
			state: r,
			fx: i
		});
	}
}
function se(e) {
	return {
		public: structuredClone({
			mode: e.mode,
			phase: e.phase,
			roastIndex: e.roastIndex,
			results: e.results,
			cardId: e.cardId,
			bag: e.bag,
			box: e.box,
			thermostat: e.thermostat,
			smokeLeft: e.smokeLeft,
			round: e.round,
			drawn: e.drawn,
			flavorLocked: e.flavorLocked,
			immediateUsed: e.immediateUsed,
			spent: e.spent,
			wildSlot: e.wildSlot,
			cupFx: e.cupFx,
			cup: e.cup,
			tray: e.tray,
			pending: e.pending,
			exchangeUsed: e.exchangeUsed,
			score: e.score
		}),
		private: {}
	};
}
function U(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = e.results.reduce((e, t) => e + t.score.total, 0);
	return {
		phase: "done",
		winner: [e.host],
		ranking: [e.host],
		scores: { [e.host]: t }
	};
}
var W = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: S,
	schemas: {
		action: E,
		publicView: ee,
		privateView: te,
		config: T
	},
	setup: ae,
	reduce: oe,
	viewFor: se,
	status: U
}, G = "./games/coffeeroaster/", K = {
	bean0: "games.coffeeroaster.tokenBean0",
	bean1: "games.coffeeroaster.tokenBean1",
	bean2: "games.coffeeroaster.tokenBean2",
	bean3: "games.coffeeroaster.tokenBean3",
	bean4: "games.coffeeroaster.tokenBean4",
	hard: "games.coffeeroaster.tokenHard",
	burnt: "games.coffeeroaster.tokenBurnt",
	moisture: "games.coffeeroaster.tokenMoisture",
	smoke: "games.coffeeroaster.tokenSmoke",
	defective: "games.coffeeroaster.tokenDefective",
	body: "games.coffeeroaster.tokenBody",
	acidity: "games.coffeeroaster.tokenAcidity",
	aroma: "games.coffeeroaster.tokenAroma",
	wild: "games.coffeeroaster.tokenWild"
}, ce = {
	bean0: "0",
	bean1: "1",
	bean2: "2",
	bean3: "3",
	bean4: "4",
	hard: "◆",
	burnt: "✦",
	moisture: "◌",
	smoke: "≈",
	defective: "×",
	body: "●",
	acidity: "✳",
	aroma: "✿",
	wild: "★",
	extra: "3+",
	sweet: "♥"
}, q = {
	beginner: "games.coffeeroaster.diffBeginner",
	advanced: "games.coffeeroaster.diffAdvanced",
	expert: "games.coffeeroaster.diffExpert"
}, le = {
	1: "games.coffeeroaster.group1",
	2: "games.coffeeroaster.group2",
	3: "games.coffeeroaster.group3"
}, ue = {
	extraBean: "games.coffeeroaster.cupFxExtraBean",
	sweetness: "games.coffeeroaster.cupFxSweetness",
	selection: "games.coffeeroaster.cupFxSelection",
	exchange: "games.coffeeroaster.cupFxExchange",
	tray: "games.coffeeroaster.cupFxTray"
}, J = (e) => Object.values(e).reduce((e, t) => e + (t ?? 0), 0), de = (e, t) => e.cupFx.some((e) => e.effect === t && e.filled.every((e) => e !== null)), fe = (e) => e.cup.findIndex((e) => e === null), pe = {
	bean0: 0,
	bean1: 1,
	bean2: 2,
	bean3: 3,
	bean4: 4
}, Y = (e) => pe[e] ?? -1;
function X(e, t) {
	if (t !== "any" && e.includes(t)) return t;
	if (t === "any") {
		for (let t of [
			"body",
			"acidity",
			"aroma"
		]) if (e.includes(t)) return t;
	}
	return e.includes("wild") ? "wild" : null;
}
function Z({ kind: e, size: t = "normal", selected: n = !1, onClick: r, label: i }) {
	let o = a()(e === "extra" ? "games.coffeeroaster.tokenExtra" : e === "sweet" ? "games.coffeeroaster.tokenSweet" : K[e]), s = /* @__PURE__ */ u("span", {
		className: "cr-token",
		"data-kind": e,
		"data-size": t,
		"data-selected": n || void 0,
		"aria-hidden": !0,
		children: [e.startsWith("bean") && /* @__PURE__ */ l("span", { className: "cr-token-seam" }), /* @__PURE__ */ l("span", {
			className: "cr-token-glyph",
			children: ce[e]
		})]
	});
	return r ? /* @__PURE__ */ l("button", {
		type: "button",
		className: "cr-token-hit cr-token-hit--button",
		"aria-label": i ?? o,
		"aria-pressed": n,
		onClick: r,
		children: s
	}) : /* @__PURE__ */ l("span", {
		className: "cr-token-hit",
		"aria-label": i ?? o,
		children: s
	});
}
function Q({ pub: e, title: t, hint: n, onRecipe: r }) {
	let i = a();
	return /* @__PURE__ */ u("header", {
		className: "cr-stage-header",
		children: [/* @__PURE__ */ u("div", {
			className: "cr-stage-meta",
			children: [
				/* @__PURE__ */ l("span", {
					className: "cr-stage-mark",
					"aria-hidden": !0,
					children: "✦"
				}),
				e.mode === "challenge" && /* @__PURE__ */ l("span", { children: i("games.coffeeroaster.roastOf", { n: e.roastIndex + 1 }) }),
				(e.phase === "roast" || e.phase === "cup") && /* @__PURE__ */ l("span", { children: i("games.coffeeroaster.bagLeft", { n: J(e.bag) }) }),
				r && /* @__PURE__ */ l("button", {
					type: "button",
					className: "cr-text-button",
					onClick: r,
					children: i("games.coffeeroaster.recipe")
				})
			]
		}), /* @__PURE__ */ u("div", {
			className: "cr-stage-heading",
			children: [/* @__PURE__ */ l("h1", { children: t }), /* @__PURE__ */ l("p", {
				role: "status",
				children: n
			})]
		})]
	});
}
function me({ cardId: e, open: t, onClose: n }) {
	let r = a();
	if (e === null) return null;
	let i = f[e], o = Math.max(...Object.values(i.roastScale)), c = [
		["body", i.flavorReq.body],
		["acidity", i.flavorReq.acidity],
		["aroma", i.flavorReq.aroma],
		["sweet", i.flavorReq.sweet]
	];
	return /* @__PURE__ */ u(s, {
		open: t,
		onClose: n,
		label: r("games.coffeeroaster.recipe"),
		children: [
			/* @__PURE__ */ u("div", {
				className: "cr-sheet-heading",
				children: [/* @__PURE__ */ l("span", {
					className: "cr-eyebrow",
					children: r(q[i.difficulty])
				}), /* @__PURE__ */ l("h2", { children: r(i.nameKey) })]
			}),
			/* @__PURE__ */ l("p", {
				className: "cr-sheet-label",
				children: r("games.coffeeroaster.targetFlavor")
			}),
			/* @__PURE__ */ l("div", {
				className: "cr-recipe-flavors",
				children: c.filter(([, e]) => e > 0).map(([e, t]) => /* @__PURE__ */ u("span", { children: [
					r(e === "sweet" ? "games.coffeeroaster.tokenSweet" : K[e]),
					" ×",
					t
				] }, e))
			}),
			/* @__PURE__ */ l("p", {
				className: "cr-sheet-label",
				children: r("games.coffeeroaster.roastScale")
			}),
			/* @__PURE__ */ l("div", {
				className: "cr-roast-scale",
				children: Object.entries(i.roastScale).map(([e, t]) => /* @__PURE__ */ u("span", {
					"data-peak": t === o || void 0,
					children: [/* @__PURE__ */ l("small", { children: e }), /* @__PURE__ */ l("strong", { children: t })]
				}, e))
			}),
			/* @__PURE__ */ l("p", {
				className: "cr-sheet-label",
				children: r("games.coffeeroaster.bagContents")
			}),
			/* @__PURE__ */ u("div", {
				className: "cr-recipe-flavors",
				children: [
					/* @__PURE__ */ u("span", { children: [
						r("games.coffeeroaster.tokenBean0"),
						" ×",
						i.bag.bean0
					] }),
					i.bag.hard > 0 && /* @__PURE__ */ u("span", { children: [
						r("games.coffeeroaster.tokenHard"),
						" ×",
						i.bag.hard
					] }),
					/* @__PURE__ */ u("span", { children: [
						r("games.coffeeroaster.tokenMoisture"),
						" ×",
						i.bag.moisture
					] }),
					i.bag.defective > 0 && /* @__PURE__ */ u("span", { children: [
						r("games.coffeeroaster.tokenDefective"),
						" ×",
						i.bag.defective
					] })
				]
			}),
			/* @__PURE__ */ l("button", {
				type: "button",
				className: "cr-button cr-button--secondary",
				onClick: n,
				children: r("games.coffeeroaster.close")
			})
		]
	});
}
//#endregion
//#region src/games/coffeeroaster/view-cup.tsx
var he = [
	[
		0,
		1,
		2
	],
	[3, 4],
	[
		5,
		6,
		7
	],
	[8, 9]
];
function ge({ pub: e, send: t }) {
	let n = a(), [r, s] = i(!1), [d, f] = i([]), [p, m] = i([]), [h, g] = i(!1), _ = e.pending, v = fe(e), y = v === -1 && de(e, "exchange") && !e.exchangeUsed, b = 3 + (de(e, "tray") ? 2 : 0), x = (t) => {
		if (!r) return;
		let n = e.cup[t];
		n !== null && n !== "extra" && n !== "sweet" && f(d.includes(t) ? d.filter((e) => e !== t) : [...d, t].slice(0, 2));
	}, S = (e) => {
		let t = _?.kind === "exchange" ? 2 : 1;
		m(p.includes(e) ? p.filter((t) => t !== e) : [...p, e].slice(0, t));
	}, C = _?.kind === "normal" ? n("games.coffeeroaster.cupPlaceStep") : _?.kind === "selection" ? n("games.coffeeroaster.cupPickOne") : _?.kind === "exchange" ? n("games.coffeeroaster.exchangePick") : r ? n("games.coffeeroaster.exchangePickStep", { n: d.length }) : y ? n("games.coffeeroaster.exchangeDecision") : n("games.coffeeroaster.cupDrawStep", { n: v + 1 }), w;
	return w = _?.kind === "normal" ? /* @__PURE__ */ u("div", {
		className: "cr-actions",
		children: [/* @__PURE__ */ l("button", {
			type: "button",
			className: "cr-button cr-button--secondary",
			disabled: e.tray.length >= b,
			onClick: () => t({
				type: "cupPlace",
				dest: "tray"
			}),
			children: n("games.coffeeroaster.cupToTray")
		}), /* @__PURE__ */ l("button", {
			type: "button",
			className: "cr-button cr-button--primary",
			onClick: () => t({
				type: "cupPlace",
				dest: "cup"
			}),
			children: n("games.coffeeroaster.cupToCup")
		})]
	}) : _?.kind === "selection" ? /* @__PURE__ */ u("div", {
		className: "cr-actions",
		children: [/* @__PURE__ */ u("span", {
			className: "cr-selection-count",
			children: [p.length, "/1"]
		}), /* @__PURE__ */ l("button", {
			type: "button",
			className: "cr-button cr-button--primary",
			disabled: p.length !== 1,
			onClick: () => {
				t({
					type: "cupPlace",
					dest: "cup",
					pick: p[0]
				}), m([]);
			},
			children: n("games.coffeeroaster.confirmCupPick")
		})]
	}) : _?.kind === "exchange" ? /* @__PURE__ */ u("div", {
		className: "cr-actions",
		children: [/* @__PURE__ */ u("span", {
			className: "cr-selection-count",
			children: [p.length, "/2"]
		}), /* @__PURE__ */ l("button", {
			type: "button",
			className: "cr-button cr-button--primary",
			disabled: p.length !== 2,
			onClick: () => {
				t({
					type: "exchangePick",
					keep: [p[0], p[1]]
				}), m([]);
			},
			children: n("games.coffeeroaster.confirmExchangePick")
		})]
	}) : r ? /* @__PURE__ */ u("div", {
		className: "cr-actions",
		children: [/* @__PURE__ */ l("button", {
			type: "button",
			className: "cr-button cr-button--secondary",
			onClick: () => {
				s(!1), f([]);
			},
			children: n("games.coffeeroaster.cancel")
		}), /* @__PURE__ */ l("button", {
			type: "button",
			className: "cr-button cr-button--primary",
			disabled: d.length !== 2,
			onClick: () => {
				t({
					type: "exchange",
					out: [d[0], d[1]]
				}), s(!1), f([]);
			},
			children: n("games.coffeeroaster.confirmExchange")
		})]
	}) : y ? /* @__PURE__ */ u("div", {
		className: "cr-actions",
		children: [/* @__PURE__ */ l("button", {
			type: "button",
			className: "cr-button cr-button--secondary",
			onClick: () => s(!0),
			children: n("games.coffeeroaster.exchange")
		}), /* @__PURE__ */ l("button", {
			type: "button",
			className: "cr-button cr-button--primary",
			onClick: () => t({ type: "cupSkipExchange" }),
			children: n("games.coffeeroaster.finishCup")
		})]
	}) : /* @__PURE__ */ l("div", {
		className: "cr-actions",
		children: /* @__PURE__ */ l("button", {
			type: "button",
			className: "cr-button cr-button--primary",
			onClick: () => t({ type: "cupDraw" }),
			children: n("games.coffeeroaster.cupDraw")
		})
	}), /* @__PURE__ */ u(o, {
		adaptive: !0,
		className: "cr-phase",
		banner: /* @__PURE__ */ l(Q, {
			pub: e,
			title: n("games.coffeeroaster.cupTitle"),
			hint: C,
			onRecipe: () => g(!0)
		}),
		actionsHeight: "cr-actions-height",
		actions: w,
		children: [/* @__PURE__ */ u("div", {
			className: "cr-cup-content",
			children: [
				/* @__PURE__ */ u("div", {
					className: "cr-cup-scene",
					children: [/* @__PURE__ */ l("img", {
						src: `${G}cup.webp`,
						alt: "",
						draggable: !1
					}), /* @__PURE__ */ l("div", {
						className: "cr-cup-grid",
						children: he.map((t, i) => /* @__PURE__ */ l("div", {
							className: "cr-cup-row",
							children: t.map((t) => {
								let i = e.cup[t], a = r && i !== null && i !== "extra" && i !== "sweet", o = n(i === null ? "games.coffeeroaster.empty" : i === "extra" ? "games.coffeeroaster.tokenExtra" : i === "sweet" ? "games.coffeeroaster.tokenSweet" : K[i]);
								return /* @__PURE__ */ l("button", {
									type: "button",
									className: "cr-cup-spot",
									"data-next": v === t || void 0,
									"data-selected": d.includes(t) || void 0,
									"data-filled": i !== null || void 0,
									disabled: !a,
									"aria-label": n("games.coffeeroaster.cupSpaceLabel", {
										n: t + 1,
										token: o
									}),
									"aria-pressed": a ? d.includes(t) : void 0,
									onClick: () => x(t),
									children: i === null ? /* @__PURE__ */ l("span", { children: t + 1 }) : /* @__PURE__ */ l(Z, {
										kind: i,
										size: "small"
									})
								}, t);
							})
						}, i))
					})]
				}),
				/* @__PURE__ */ u("div", {
					className: "cr-cup-tray",
					children: [/* @__PURE__ */ u("span", { children: [
						n("games.coffeeroaster.tray"),
						" ",
						/* @__PURE__ */ u("b", { children: [
							e.tray.length,
							"/",
							b
						] })
					] }), /* @__PURE__ */ l("div", { children: e.tray.map((e, t) => /* @__PURE__ */ l(Z, {
						kind: e,
						size: "small"
					}, t)) })]
				}),
				/* @__PURE__ */ l("div", {
					className: "cr-pending-tray",
					"data-empty": !_ || void 0,
					children: _ && /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("p", { children: _.kind === "normal" ? n("games.coffeeroaster.cupDrawnNow") : _.kind === "selection" ? n("games.coffeeroaster.cupPickOne") : n("games.coffeeroaster.exchangePick") }), /* @__PURE__ */ l("div", { children: _.kind === "normal" ? /* @__PURE__ */ l(Z, {
						kind: _.token,
						size: "large"
					}) : _.tokens.map((e, t) => /* @__PURE__ */ l(Z, {
						kind: e,
						size: "large",
						selected: p.includes(t),
						onClick: () => S(t)
					}, t)) })] })
				})
			]
		}), /* @__PURE__ */ l(me, {
			cardId: e.cardId,
			open: h,
			onClose: () => g(!1)
		})]
	});
}
//#endregion
//#region src/games/coffeeroaster/view-roast.tsx
var _e = {
	concentrate: "body",
	preserve: "acidity",
	disperse: "aroma"
}, ve = {
	concentrate: "games.coffeeroaster.flavorConcentrate",
	preserve: "games.coffeeroaster.flavorPreserve",
	disperse: "games.coffeeroaster.flavorDisperse"
};
function ye(e, t, n) {
	let r = t.map((e) => Y(n[e]));
	return e === "concentrate" ? r.every((e) => e >= 1 && e <= 3) && (r.length < 2 || r[0] + r[1] <= 4) : e === "disperse" ? r.every((e) => e >= 2 && e <= 4) : r.every((e) => e >= 0);
}
function be({ pub: e }) {
	let t = a();
	return /* @__PURE__ */ u("div", {
		className: "cr-thermostat",
		role: "img",
		"aria-label": `${t("games.coffeeroaster.thermostat")} ${e.thermostat}`,
		children: [/* @__PURE__ */ u("svg", {
			viewBox: "0 0 320 120",
			"aria-hidden": !0,
			children: [/* @__PURE__ */ l("path", {
				className: "cr-thermo-rail",
				d: "M30 104 A130 84 0 0 1 290 104"
			}), Array.from({ length: 9 }, (t, n) => {
				let r = 6 + n, i = Math.PI - n / 8 * Math.PI, a = 160 + 130 * Math.cos(i), o = 104 - 84 * Math.sin(i), s = m[r] !== void 0;
				return /* @__PURE__ */ u("g", {
					className: "cr-thermo-stop",
					"data-current": r === e.thermostat || void 0,
					"data-red": s || void 0,
					children: [
						/* @__PURE__ */ l("circle", {
							cx: a,
							cy: o,
							r: r === e.thermostat ? 18 : 14
						}),
						/* @__PURE__ */ l("text", {
							x: a,
							y: o + 4.5,
							textAnchor: "middle",
							children: r
						}),
						s && (e.smokeLeft[String(r)] ?? 0) > 0 && /* @__PURE__ */ l("circle", {
							className: "cr-thermo-smoke",
							cx: a + 14,
							cy: o - 13,
							r: "3"
						})
					]
				}, r);
			})]
		}), /* @__PURE__ */ u("div", {
			className: "cr-thermo-reading",
			children: [/* @__PURE__ */ l("strong", { children: e.thermostat }), /* @__PURE__ */ l("span", { children: t("games.coffeeroaster.thermostat") })]
		})]
	});
}
function xe({ pub: e, send: t }) {
	let n = a(), [r, d] = i(null), [f, p] = i([]), [h, g] = i(!1), [_, v] = i(!1), [y, b] = i(!1), [S, C] = i(!1), w = e.drawn ?? [], T = e.pending, E = e.drawn !== null && !T && !e.flavorLocked, D = e.drawn !== null && !T, O = (t) => e.immediateUsed.includes(t), k = w.some((e) => e === "burnt" || e === "smoke" || e === "defective"), ee = (t) => {
		let n = _e[t], r = [];
		return e.cupFx.forEach((e, t) => e.filled.forEach((e, i) => {
			let a = x[t][i];
			e === null && (a === "any" || a === n) && r.push([t, i]);
		})), r;
	}, te = (e) => {
		let t = w.map(Y).filter((e) => e >= 0);
		return e === "concentrate" ? t.some((e, n) => e >= 1 && e <= 3 && t.some((t, r) => r !== n && t >= 1 && t <= 3 && e + t <= 4)) : e === "preserve" ? t.length >= 2 : t.some((e) => e >= 2 && e <= 4);
	}, A = (e) => D && X(w, _e[e]) !== null && ee(e).length > 0 && te(e), ne = E && !O("wild") && w.some((t) => (t === "bean0" || t === "bean1") && !e.wildSlot[t]), j = E && !O("draw2") && X(w, "body") !== null && J(e.bag) >= 2, M = E && !O("redraw2") && X(w, "any") !== null && w.length >= 2, N = E && !O("five2") && X(w, "aroma") !== null && J(e.bag) >= 5, P = E && !O("removal") && X(w, "any") !== null && k, re = [
		"concentrate",
		"preserve",
		"disperse"
	].filter(A), F = [
		ne,
		j,
		M,
		N,
		P
	].filter(Boolean).length + re.length, I = (e) => {
		let t = Y(e);
		return t === 2 ? [["bean1", "bean1"]] : t === 3 ? [["bean1", "bean2"]] : t === 4 ? [["bean1", "bean3"], ["bean2", "bean2"]] : [];
	}, L = r?.kind === "flavor" ? r : null, R = L?.effect === "disperse" ? 1 : 2, z = !!L && L.beans.length === R, B = !!L && z && ye(L.effect, L.beans, w), V = L?.effect === "disperse" && L.beans.length === 1 ? I(w[L.beans[0]]) : [], H = V.length > 1 && !L?.into, ie = r?.kind === "redraw2" && r.back.length === 2 ? [
		"body",
		"acidity",
		"aroma",
		"wild"
	].find((e) => w.includes(e) && w.filter((t) => t === e).length > r.back.map((e) => w[e]).filter((t) => t === e).length) : null, ae = (n) => {
		let i = w[n];
		if (r?.kind === "wild") {
			(i === "bean0" || i === "bean1") && !e.wildSlot[i] && (t({
				type: "fxWild",
				bean: i
			}), e.wildSlot[i === "bean0" ? "bean1" : "bean0"] && d(null));
			return;
		}
		if (r?.kind === "redraw2") {
			let e = r.back.includes(n) ? r.back.filter((e) => e !== n) : [...r.back, n].slice(0, 2);
			d({
				kind: "redraw2",
				back: e
			});
			return;
		}
		if (r?.kind === "flavor" && Y(i) >= 0) {
			let e = r.beans.includes(n) ? r.beans.filter((e) => e !== n) : [...r.beans, n].slice(0, R);
			if (!ye(r.effect, e, w)) return;
			d({
				...r,
				beans: e,
				into: void 0,
				target: void 0
			}), e.length === R && v(!0);
		}
	}, oe = () => {
		if (r?.kind !== "redraw2" || r.back.length !== 2) return;
		let e = r.back.map((e) => w[e]), n = ie;
		n && (t({
			type: "fxRedraw2",
			use: n,
			back: [e[0], e[1]]
		}), d(null));
	}, se = () => {
		if (!L || !B || !L.target || H) return;
		let e = X(w, _e[L.effect]);
		if (!e) return;
		let n = L.beans.map((e) => w[e]), [r, i] = L.target;
		if (L.effect === "disperse") {
			let a = L.into ?? V[0];
			if (!a) return;
			t({
				type: "flavor",
				effect: "disperse",
				use: e,
				beans: n,
				into: a,
				target: r,
				slot: i
			});
		} else t({
			type: "flavor",
			effect: L.effect,
			use: e,
			beans: n,
			target: r,
			slot: i
		});
		d(null), v(!1);
	}, U = (e, n) => {
		let r = X(w, n);
		r && t({
			type: e,
			use: r
		}), g(!1);
	}, W = e.round === 0 ? e.thermostat : Math.min(e.thermostat + 1, 14), K = e.drawn === null && e.round > 0 && e.thermostat >= 14, ce = T?.kind === "five2" ? n("games.coffeeroaster.fxFive2Pick") : r?.kind === "wild" ? n("games.coffeeroaster.wildStep") : r?.kind === "redraw2" ? n("games.coffeeroaster.pickTwoStep", { n: r.back.length }) : L ? z ? n("games.coffeeroaster.flavorTargetStep") : n("games.coffeeroaster.pickBeansStep", {
		n: L.beans.length,
		total: R
	}) : e.drawn === null ? K ? n("games.coffeeroaster.mustCup") : n("games.coffeeroaster.drawStep", { n: W }) : n("games.coffeeroaster.roastStep"), q;
	return q = T?.kind === "five2" ? /* @__PURE__ */ u("div", {
		className: "cr-actions",
		children: [/* @__PURE__ */ u("span", {
			className: "cr-selection-count",
			children: [f.length, "/2"]
		}), /* @__PURE__ */ l("button", {
			type: "button",
			className: "cr-button cr-button--primary",
			disabled: f.length !== 2,
			onClick: () => {
				t({
					type: "fxFive2Pick",
					remove: [f[0], f[1]]
				}), p([]);
			},
			children: n("games.coffeeroaster.confirmRemove")
		})]
	}) : r?.kind === "wild" ? /* @__PURE__ */ u("div", {
		className: "cr-actions",
		children: [/* @__PURE__ */ l("button", {
			type: "button",
			className: "cr-button cr-button--secondary",
			onClick: () => d(null),
			children: n("games.coffeeroaster.cancel")
		}), /* @__PURE__ */ l("span", {
			className: "cr-action-note",
			children: n("games.coffeeroaster.wildStep")
		})]
	}) : r?.kind === "redraw2" ? /* @__PURE__ */ u("div", {
		className: "cr-actions",
		children: [/* @__PURE__ */ l("button", {
			type: "button",
			className: "cr-button cr-button--secondary",
			onClick: () => d(null),
			children: n("games.coffeeroaster.cancel")
		}), /* @__PURE__ */ l("button", {
			type: "button",
			className: "cr-button cr-button--primary",
			disabled: !ie,
			onClick: oe,
			children: n("games.coffeeroaster.confirmRedraw")
		})]
	}) : L ? /* @__PURE__ */ u("div", {
		className: "cr-actions",
		children: [/* @__PURE__ */ l("button", {
			type: "button",
			className: "cr-button cr-button--secondary",
			onClick: () => {
				d(null), v(!1);
			},
			children: n("games.coffeeroaster.cancel")
		}), /* @__PURE__ */ l("button", {
			type: "button",
			className: "cr-button cr-button--primary",
			disabled: !B,
			onClick: () => v(!0),
			children: n("games.coffeeroaster.chooseCupFx")
		})]
	}) : e.drawn === null ? /* @__PURE__ */ u("div", {
		className: "cr-actions",
		children: [e.round > 0 && !K && /* @__PURE__ */ l("button", {
			type: "button",
			className: "cr-button cr-button--secondary",
			onClick: () => t({ type: "toCup" }),
			children: n("games.coffeeroaster.toCup")
		}), /* @__PURE__ */ l("button", {
			type: "button",
			className: "cr-button cr-button--primary",
			onClick: () => t({ type: K ? "toCup" : "draw" }),
			children: K ? n("games.coffeeroaster.toCup") : n("games.coffeeroaster.drawCount", { n: W })
		})]
	}) : /* @__PURE__ */ u("div", {
		className: "cr-actions",
		children: [F > 0 && /* @__PURE__ */ l("button", {
			type: "button",
			className: "cr-button cr-button--secondary",
			onClick: () => g(!0),
			children: n("games.coffeeroaster.availableSkills", { n: F })
		}), /* @__PURE__ */ l("button", {
			type: "button",
			className: "cr-button cr-button--primary",
			onClick: () => t({ type: "roast" }),
			children: n("games.coffeeroaster.finishRoast")
		})]
	}), /* @__PURE__ */ u(o, {
		adaptive: !0,
		className: "cr-phase",
		banner: /* @__PURE__ */ l(Q, {
			pub: e,
			title: n("games.coffeeroaster.roast"),
			hint: ce,
			onRecipe: () => C(!0)
		}),
		actionsHeight: "cr-actions-height",
		actions: q,
		children: [
			/* @__PURE__ */ u("div", {
				className: "cr-roast-content",
				children: [/* @__PURE__ */ u("div", {
					className: "cr-roast-scene",
					children: [
						/* @__PURE__ */ l("img", {
							src: `${G}roast.webp`,
							alt: "",
							draggable: !1
						}),
						/* @__PURE__ */ l(be, { pub: e }),
						/* @__PURE__ */ u("span", {
							className: "cr-compact-temperature",
							children: [
								n("games.coffeeroaster.thermostat"),
								" ",
								e.thermostat
							]
						}),
						/* @__PURE__ */ u("div", {
							className: "cr-roast-tray",
							"aria-label": T?.kind === "five2" ? n("games.coffeeroaster.fxFive2Pick") : n("games.coffeeroaster.drawnTitle"),
							children: [T?.kind === "five2" ? T.tokens.map((e, t) => /* @__PURE__ */ l(Z, {
								kind: e,
								size: "large",
								selected: f.includes(t),
								onClick: () => p(f.includes(t) ? f.filter((e) => e !== t) : [...f, t].slice(0, 2))
							}, t)) : w.map((e, t) => /* @__PURE__ */ l(Z, {
								kind: e,
								size: "large",
								selected: r?.kind === "redraw2" && r.back.includes(t) || (L?.beans.includes(t) ?? !1),
								onClick: r ? () => ae(t) : void 0
							}, t)), w.length === 0 && T?.kind !== "five2" && /* @__PURE__ */ u("div", {
								className: "cr-empty-tray",
								children: [/* @__PURE__ */ l("span", {
									"aria-hidden": !0,
									children: "✦"
								}), /* @__PURE__ */ l("p", { children: n("games.coffeeroaster.emptyRoastTray") })]
							})]
						}),
						/* @__PURE__ */ u("div", {
							className: "cr-roast-scene-bottom",
							children: [
								/* @__PURE__ */ l("span", {
									className: "cr-bag-tag",
									children: n("games.coffeeroaster.bagLeft", { n: J(e.bag) })
								}),
								m[e.thermostat] !== void 0 && e.drawn !== null && /* @__PURE__ */ l("span", {
									className: "cr-red-tag",
									children: n("games.coffeeroaster.redZone")
								}),
								/* @__PURE__ */ u("button", {
									type: "button",
									className: "cr-progress-tag",
									onClick: () => b(!0),
									children: [n("games.coffeeroaster.cupFxProgress", { n: e.cupFx.filter((e) => e.filled.every((e) => e !== null)).length }), " ↗"]
								})
							]
						})
					]
				}), /* @__PURE__ */ u("div", {
					className: "cr-wild-progress",
					"aria-label": n("games.coffeeroaster.fxWild"),
					children: [
						/* @__PURE__ */ l("span", { children: n("games.coffeeroaster.fxWild") }),
						/* @__PURE__ */ l("span", {
							className: "cr-wild-slot",
							"data-filled": e.wildSlot.bean0 || void 0,
							children: "0"
						}),
						/* @__PURE__ */ l("span", {
							className: "cr-wild-slot",
							"data-filled": e.wildSlot.bean1 || void 0,
							children: "1"
						}),
						O("wild") && /* @__PURE__ */ l("span", {
							className: "cr-wild-earned",
							children: "★"
						})
					]
				})]
			}),
			/* @__PURE__ */ u(s, {
				open: h,
				onClose: () => g(!1),
				label: n("games.coffeeroaster.skills"),
				children: [/* @__PURE__ */ u("div", {
					className: "cr-sheet-heading",
					children: [/* @__PURE__ */ l("span", {
						className: "cr-eyebrow",
						children: n("games.coffeeroaster.availableSkills", { n: F })
					}), /* @__PURE__ */ l("h2", { children: n("games.coffeeroaster.skills") })]
				}), /* @__PURE__ */ u("div", {
					className: "cr-skill-list",
					children: [
						ne && /* @__PURE__ */ u("button", {
							type: "button",
							onClick: () => {
								d({ kind: "wild" }), g(!1);
							},
							children: [
								/* @__PURE__ */ l("strong", { children: n("games.coffeeroaster.fxWild") }),
								/* @__PURE__ */ l("small", { children: n("games.coffeeroaster.skillWildBrief") }),
								/* @__PURE__ */ l("span", {
									"aria-hidden": !0,
									children: "↗"
								})
							]
						}),
						j && /* @__PURE__ */ u("button", {
							type: "button",
							onClick: () => U("fxDraw2", "body"),
							children: [
								/* @__PURE__ */ l("strong", { children: n("games.coffeeroaster.fxDraw2") }),
								/* @__PURE__ */ l("small", { children: n("games.coffeeroaster.skillDrawBrief") }),
								/* @__PURE__ */ l("span", {
									"aria-hidden": !0,
									children: "↗"
								})
							]
						}),
						M && /* @__PURE__ */ u("button", {
							type: "button",
							onClick: () => {
								d({
									kind: "redraw2",
									back: []
								}), g(!1);
							},
							children: [
								/* @__PURE__ */ l("strong", { children: n("games.coffeeroaster.fxRedraw2") }),
								/* @__PURE__ */ l("small", { children: n("games.coffeeroaster.skillRedrawBrief") }),
								/* @__PURE__ */ l("span", {
									"aria-hidden": !0,
									children: "↗"
								})
							]
						}),
						N && /* @__PURE__ */ u("button", {
							type: "button",
							onClick: () => U("fxFive2", "aroma"),
							children: [
								/* @__PURE__ */ l("strong", { children: n("games.coffeeroaster.fxFive2") }),
								/* @__PURE__ */ l("small", { children: n("games.coffeeroaster.skillFiveBrief") }),
								/* @__PURE__ */ l("span", {
									"aria-hidden": !0,
									children: "↗"
								})
							]
						}),
						P && /* @__PURE__ */ u("button", {
							type: "button",
							onClick: () => U("fxRemoval", "any"),
							children: [
								/* @__PURE__ */ l("strong", { children: n("games.coffeeroaster.fxRemoval") }),
								/* @__PURE__ */ l("small", { children: n("games.coffeeroaster.skillRemovalBrief") }),
								/* @__PURE__ */ l("span", {
									"aria-hidden": !0,
									children: "↗"
								})
							]
						}),
						re.map((e) => /* @__PURE__ */ u("button", {
							type: "button",
							onClick: () => {
								d({
									kind: "flavor",
									effect: e,
									beans: []
								}), g(!1);
							},
							children: [
								/* @__PURE__ */ l("strong", { children: n(ve[e]) }),
								/* @__PURE__ */ l("small", { children: n("games.coffeeroaster.skillFlavorBrief") }),
								/* @__PURE__ */ l("span", {
									"aria-hidden": !0,
									children: "↗"
								})
							]
						}, e))
					]
				})]
			}),
			/* @__PURE__ */ l(s, {
				open: _ && !!L,
				onClose: () => v(!1),
				label: n("games.coffeeroaster.chooseCupFx"),
				children: L && /* @__PURE__ */ u(c, { children: [
					/* @__PURE__ */ u("div", {
						className: "cr-sheet-heading",
						children: [/* @__PURE__ */ l("span", {
							className: "cr-eyebrow",
							children: n(ve[L.effect])
						}), /* @__PURE__ */ l("h2", { children: n("games.coffeeroaster.chooseCupFx") })]
					}),
					V.length > 1 && /* @__PURE__ */ u(c, { children: [/* @__PURE__ */ l("p", {
						className: "cr-sheet-label",
						children: n("games.coffeeroaster.chooseSplit")
					}), /* @__PURE__ */ l("div", {
						className: "cr-split-options",
						children: V.map((e, t) => /* @__PURE__ */ u("button", {
							type: "button",
							"aria-pressed": L.into?.[0] === e[0] && L.into?.[1] === e[1],
							onClick: () => d({
								...L,
								into: e
							}),
							children: [
								/* @__PURE__ */ l(Z, {
									kind: e[0],
									size: "small"
								}),
								" + ",
								/* @__PURE__ */ l(Z, {
									kind: e[1],
									size: "small"
								})
							]
						}, t))
					})] }),
					/* @__PURE__ */ l("div", {
						className: "cr-fx-target-list",
						children: e.cupFx.map((e, t) => /* @__PURE__ */ u("div", { children: [/* @__PURE__ */ l("span", { children: n(ue[e.effect]) }), /* @__PURE__ */ l("div", { children: e.filled.map((r, i) => {
							let a = x[t][i], o = ee(L.effect).some(([e, n]) => e === t && n === i), s = L.target?.[0] === t && L.target?.[1] === i;
							return /* @__PURE__ */ l("button", {
								type: "button",
								disabled: !o || !B || H,
								"aria-label": `${n("games.coffeeroaster.flavorPickSlot")} ${n(ue[e.effect])} ${i + 1}`,
								"aria-pressed": s,
								"data-color": a,
								"data-filled": !!r || void 0,
								onClick: () => d({
									...L,
									target: [t, i]
								}),
								children: r || s ? "✓" : "◌"
							}, i);
						}) })] }, t))
					}),
					/* @__PURE__ */ l("button", {
						type: "button",
						className: "cr-button cr-button--primary",
						disabled: !L.target || H,
						onClick: se,
						children: n("games.coffeeroaster.confirmEffect")
					})
				] })
			}),
			/* @__PURE__ */ u(s, {
				open: y,
				onClose: () => b(!1),
				label: n("games.coffeeroaster.cupFxBoard"),
				children: [
					/* @__PURE__ */ u("div", {
						className: "cr-sheet-heading",
						children: [/* @__PURE__ */ l("span", {
							className: "cr-eyebrow",
							children: n("games.coffeeroaster.cupFxProgress", { n: e.cupFx.filter((e) => e.filled.every((e) => e !== null)).length })
						}), /* @__PURE__ */ l("h2", { children: n("games.coffeeroaster.cupFxBoard") })]
					}),
					/* @__PURE__ */ l("div", {
						className: "cr-fx-target-list",
						children: e.cupFx.map((e, t) => /* @__PURE__ */ u("div", { children: [/* @__PURE__ */ l("span", { children: n(ue[e.effect]) }), /* @__PURE__ */ l("div", { children: e.filled.map((e, n) => /* @__PURE__ */ l("span", {
							className: "cr-fx-readonly",
							"data-color": x[t][n],
							"data-filled": !!e || void 0,
							children: e ? "✓" : "◌"
						}, n)) })] }, t))
					}),
					/* @__PURE__ */ l("button", {
						type: "button",
						className: "cr-button cr-button--secondary",
						onClick: () => b(!1),
						children: n("games.coffeeroaster.close")
					})
				]
			}),
			/* @__PURE__ */ l(me, {
				cardId: e.cardId,
				open: S,
				onClose: () => C(!1)
			})
		]
	});
}
//#endregion
//#region src/games/coffeeroaster/view-score.tsx
function Se({ score: e }) {
	let t = a(), n = [
		{
			key: "games.coffeeroaster.penaltyHard",
			points: e.penalties.hard
		},
		{
			key: "games.coffeeroaster.penaltyBurnt",
			points: e.penalties.burnt
		},
		{
			key: "games.coffeeroaster.penaltySmoke",
			points: e.penalties.smoke
		},
		{
			key: "games.coffeeroaster.penaltyDefective",
			points: e.penalties.defective
		},
		{
			key: "games.coffeeroaster.penaltyNoFlavor",
			points: e.penalties.noFlavor
		},
		{
			key: "games.coffeeroaster.penaltyEmpty",
			points: e.penalties.empty
		}
	];
	return /* @__PURE__ */ u("div", {
		className: "cr-score-lines",
		children: [
			/* @__PURE__ */ u("div", { children: [/* @__PURE__ */ u("span", { children: [t("games.coffeeroaster.scoreRoast"), /* @__PURE__ */ l("small", { children: t("games.coffeeroaster.scoreRoastDetail", { n: e.roastTotal }) })] }), /* @__PURE__ */ u("strong", { children: ["+", e.roastPoints] })] }),
			/* @__PURE__ */ u("div", { children: [/* @__PURE__ */ u("span", { children: [t("games.coffeeroaster.scoreFlavor"), /* @__PURE__ */ l("small", { children: t("games.coffeeroaster.scoreFlavorDetail", { n: e.flavorMatches }) })] }), /* @__PURE__ */ u("strong", { children: ["+", e.flavorPoints] })] }),
			/* @__PURE__ */ u("div", { children: [/* @__PURE__ */ u("span", { children: [t("games.coffeeroaster.scoreSkill"), /* @__PURE__ */ l("small", { children: e.skillGroups.map((e) => t("games.coffeeroaster.scoreSkillDetail", {
				n: e.level,
				c: e.count
			})).join(" · ") })] }), /* @__PURE__ */ u("strong", { children: ["+", e.skillPoints] })] }),
			n.filter((e) => e.points !== 0).map((e) => /* @__PURE__ */ u("div", {
				className: "cr-penalty-line",
				children: [/* @__PURE__ */ l("span", { children: t(e.key) }), /* @__PURE__ */ l("strong", { children: e.points })]
			}, e.key))
		]
	});
}
function Ce({ pub: e, send: t }) {
	let n = a();
	if (!e.score || e.cardId === null) return null;
	let r = e.score, i = e.mode === "single" || e.roastIndex === 2, s = f[e.cardId], c = e.results.reduce((e, t) => e + t.score.total, 0) + r.total;
	return /* @__PURE__ */ l(o, {
		adaptive: !0,
		className: "cr-phase",
		banner: /* @__PURE__ */ l(Q, {
			pub: e,
			title: n("games.coffeeroaster.scoreTitle"),
			hint: n("games.coffeeroaster.scoreStep")
		}),
		actionsHeight: "cr-actions-height",
		actions: /* @__PURE__ */ l("div", {
			className: "cr-actions",
			children: /* @__PURE__ */ l("button", {
				type: "button",
				className: "cr-button cr-button--primary",
				onClick: () => t({ type: "next" }),
				children: n(i ? "games.coffeeroaster.finish" : "games.coffeeroaster.nextRoast")
			})
		}),
		children: /* @__PURE__ */ l("div", {
			className: "cr-score-content",
			children: /* @__PURE__ */ u("div", {
				className: "cr-score-receipt",
				children: [
					/* @__PURE__ */ l("span", {
						className: "cr-score-stamp",
						"aria-hidden": !0,
						children: "✦"
					}),
					/* @__PURE__ */ l("p", {
						className: "cr-eyebrow",
						children: n(s.nameKey)
					}),
					/* @__PURE__ */ u("div", {
						className: "cr-score-hero",
						children: [/* @__PURE__ */ l("span", { children: n("games.coffeeroaster.scoreTotal") }), /* @__PURE__ */ l("strong", { children: r.total })]
					}),
					/* @__PURE__ */ l(Se, { score: r }),
					e.mode === "challenge" && /* @__PURE__ */ u("div", {
						className: "cr-score-accumulated",
						children: [/* @__PURE__ */ l("span", { children: n("games.coffeeroaster.challengeTotal") }), /* @__PURE__ */ l("strong", { children: c })]
					})
				]
			})
		})
	});
}
//#endregion
//#region src/games/coffeeroaster/progress.ts
var we = "bgparty:coffeeroaster", $ = null;
function Te() {
	if ($) return $.best;
	try {
		let e = localStorage.getItem(we);
		if (e) return $ = { best: JSON.parse(e).best ?? 0 }, $.best;
	} catch {}
	return $ = { best: 0 }, 0;
}
function Ee(e) {
	let t = e > Te();
	if (t) {
		$ = { best: e };
		try {
			localStorage.setItem(we, JSON.stringify($));
		} catch {}
	}
	return t;
}
//#endregion
//#region src/games/coffeeroaster/view-select.tsx
function De({ pub: e, send: t }) {
	let n = a(), [r, c] = i(e.mode === "challenge" ? e.roastIndex + 1 : 1), [d, p] = i(0), [m, h] = i(!1), [g, _] = i(!1), y = f.filter((e) => e.group === r), b = y[Math.min(d, y.length - 1)], x = (t) => {
		if (e.mode === "single") return null;
		let n = f[t];
		return n.group === e.roastIndex + 1 ? e.roastIndex > 0 ? v(e.results[e.roastIndex - 1]?.score.total ?? 0).includes(n.difficulty) ? null : "games.coffeeroaster.lockedByScore" : n.difficulty === "expert" && Te() < 35 ? "games.coffeeroaster.lockedExpert" : null : "games.coffeeroaster.lockedGroup";
	}, S = x(b.id), C = Math.max(...Object.values(b.roastScale)), w = Object.entries(b.roastScale).find(([, e]) => e === C)?.[0] ?? "—", T = (e) => p((t) => (t + e + y.length) % y.length), E = (e) => {
		c(e), p(0);
	};
	return /* @__PURE__ */ u(o, {
		adaptive: !0,
		className: "cr-phase",
		banner: /* @__PURE__ */ l(Q, {
			pub: e,
			title: n("games.coffeeroaster.selectTitle"),
			hint: S ? n(S, { n: e.roastIndex + 1 }) : n("games.coffeeroaster.selectHint")
		}),
		actionsHeight: "cr-actions-height",
		actions: /* @__PURE__ */ u("div", {
			className: "cr-actions",
			children: [/* @__PURE__ */ l("button", {
				type: "button",
				className: "cr-button cr-button--secondary",
				onClick: () => _(!0),
				children: n("games.coffeeroaster.inspectCard")
			}), /* @__PURE__ */ l("button", {
				type: "button",
				className: "cr-button cr-button--primary",
				disabled: S !== null,
				onClick: () => t({
					type: "select",
					cardId: b.id
				}),
				children: n("games.coffeeroaster.startRoast")
			})]
		}),
		children: [
			/* @__PURE__ */ u("div", {
				className: "cr-select-content",
				children: [
					/* @__PURE__ */ l("div", {
						className: "cr-group-tabs",
						role: "group",
						"aria-label": n("games.coffeeroaster.selectGroup"),
						children: [
							1,
							2,
							3
						].map((t) => /* @__PURE__ */ l("button", {
							type: "button",
							disabled: e.mode === "challenge" && t !== e.roastIndex + 1,
							"aria-pressed": r === t,
							onClick: () => E(t),
							children: n(le[t])
						}, t))
					}),
					/* @__PURE__ */ u("div", {
						className: "cr-origin-card",
						children: [
							/* @__PURE__ */ l("img", {
								src: `${G}origin.webp`,
								alt: "",
								draggable: !1
							}),
							/* @__PURE__ */ u("span", {
								className: "cr-origin-number",
								children: [String(b.id + 1).padStart(2, "0"), " / 22"]
							}),
							/* @__PURE__ */ u("div", {
								className: "cr-origin-copy",
								children: [
									/* @__PURE__ */ u("span", {
										className: "cr-eyebrow",
										children: [
											n(le[b.group]),
											" · ",
											n(q[b.difficulty]),
											b.specialty ? ` · ${n("games.coffeeroaster.specialty")}` : ""
										]
									}),
									/* @__PURE__ */ l("h2", { children: n(b.nameKey) }),
									/* @__PURE__ */ u("div", {
										className: "cr-origin-facts",
										children: [/* @__PURE__ */ u("span", { children: [/* @__PURE__ */ l("small", { children: n("games.coffeeroaster.bestRoast") }), /* @__PURE__ */ l("strong", { children: w })] }), /* @__PURE__ */ u("span", { children: [/* @__PURE__ */ l("small", { children: n("games.coffeeroaster.targetFlavor") }), /* @__PURE__ */ l("strong", { children: b.flavorReq.body + b.flavorReq.acidity + b.flavorReq.aroma + b.flavorReq.sweet })] })]
									})
								]
							}),
							/* @__PURE__ */ l("button", {
								type: "button",
								className: "cr-card-arrow cr-card-arrow--prev",
								"aria-label": n("games.coffeeroaster.previousCard"),
								onClick: () => T(-1),
								children: "‹"
							}),
							/* @__PURE__ */ l("button", {
								type: "button",
								className: "cr-card-arrow cr-card-arrow--next",
								"aria-label": n("games.coffeeroaster.nextCard"),
								onClick: () => T(1),
								children: "›"
							})
						]
					}),
					/* @__PURE__ */ u("button", {
						type: "button",
						className: "cr-list-link",
						onClick: () => h(!0),
						children: [
							n("games.coffeeroaster.allCards"),
							" ",
							/* @__PURE__ */ l("span", {
								"aria-hidden": !0,
								children: "↗"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ u(s, {
				open: m,
				onClose: () => h(!1),
				label: n("games.coffeeroaster.allCards"),
				children: [/* @__PURE__ */ u("div", {
					className: "cr-sheet-heading",
					children: [/* @__PURE__ */ l("span", {
						className: "cr-eyebrow",
						children: n(le[r])
					}), /* @__PURE__ */ l("h2", { children: n("games.coffeeroaster.allCards") })]
				}), /* @__PURE__ */ l("div", {
					className: "cr-card-list",
					children: y.map((e, t) => {
						let r = x(e.id);
						return /* @__PURE__ */ u("button", {
							type: "button",
							onClick: () => {
								p(t), h(!1);
							},
							"aria-current": t === d ? "true" : void 0,
							children: [
								/* @__PURE__ */ l("span", {
									className: "cr-card-list-number",
									children: String(e.id + 1).padStart(2, "0")
								}),
								/* @__PURE__ */ u("span", {
									className: "cr-card-list-name",
									children: [n(e.nameKey), /* @__PURE__ */ l("small", { children: n(q[e.difficulty]) })]
								}),
								/* @__PURE__ */ l("span", {
									"aria-hidden": !0,
									children: r ? "◌" : "↗"
								})
							]
						}, e.id);
					})
				})]
			}),
			/* @__PURE__ */ l(me, {
				cardId: b.id,
				open: g,
				onClose: () => _(!1)
			})
		]
	});
}
//#endregion
//#region src/games/coffeeroaster/view-player.tsx
function Oe({ public: e, send: t }) {
	let n = e;
	return /* @__PURE__ */ u("div", {
		className: "cr-root",
		children: [
			n.phase === "select" && /* @__PURE__ */ l(De, {
				pub: n,
				send: t
			}),
			n.phase === "roast" && /* @__PURE__ */ l(xe, {
				pub: n,
				send: t
			}),
			n.phase === "cup" && /* @__PURE__ */ l(ge, {
				pub: n,
				send: t
			}),
			(n.phase === "score" || n.phase === "done") && /* @__PURE__ */ l(Ce, {
				pub: n,
				send: t
			})
		]
	}, n.roastIndex);
}
//#endregion
//#region src/games/coffeeroaster/game-over.tsx
var ke = [
	"games.coffeeroaster.title0",
	"games.coffeeroaster.title1",
	"games.coffeeroaster.title2",
	"games.coffeeroaster.title3",
	"games.coffeeroaster.title4",
	"games.coffeeroaster.title5",
	"games.coffeeroaster.title6",
	"games.coffeeroaster.title7"
];
function Ae({ public: e, onPlayAgain: t, onBackToLobby: i }) {
	let o = a(), s = e, c = s.results.reduce((e, t) => e + t.score.total, 0), d = y.findIndex((e) => c >= e), p = r(!1);
	return n(() => {
		p.current || s.mode !== "challenge" || (p.current = !0, Ee(c));
	}, [s.mode, c]), /* @__PURE__ */ u("div", {
		className: "cr-final",
		children: [
			/* @__PURE__ */ u("div", {
				className: "cr-final-hero",
				children: [/* @__PURE__ */ l("img", {
					src: `${G}origin.webp`,
					alt: ""
				}), /* @__PURE__ */ u("div", { children: [/* @__PURE__ */ l("span", {
					"aria-hidden": !0,
					children: S.icon
				}), /* @__PURE__ */ l("h1", { children: o("games.coffeeroaster.scoreTitle") })] })]
			}),
			/* @__PURE__ */ u("div", {
				className: "cr-final-paper",
				children: [
					s.mode === "challenge" && /* @__PURE__ */ u("p", {
						className: "cr-final-title",
						children: ["✦ ", o(ke[d < 0 ? ke.length - 1 : d])]
					}),
					/* @__PURE__ */ u("div", {
						className: "cr-final-total",
						children: [/* @__PURE__ */ l("span", { children: s.mode === "challenge" ? o("games.coffeeroaster.challengeTotal") : o("games.coffeeroaster.scoreTotal") }), /* @__PURE__ */ l("strong", { children: c })]
					}),
					/* @__PURE__ */ l("div", {
						className: "cr-final-results",
						children: s.results.map((e, t) => /* @__PURE__ */ u("div", { children: [
							/* @__PURE__ */ l("span", { children: o("games.coffeeroaster.roastOf", { n: t + 1 }) }),
							/* @__PURE__ */ l("strong", { children: o(f[e.cardId].nameKey) }),
							/* @__PURE__ */ l("b", { children: e.score.total })
						] }, t))
					})
				]
			}),
			/* @__PURE__ */ u("div", {
				className: "cr-final-actions",
				children: [t && /* @__PURE__ */ l("button", {
					type: "button",
					className: "cr-button cr-button--primary",
					onClick: t,
					children: o("session.result.playAgain")
				}), i && /* @__PURE__ */ l("button", {
					type: "button",
					className: "cr-button cr-button--secondary",
					onClick: i,
					children: o("session.result.backToLobby")
				})]
			})
		]
	});
}
//#endregion
//#region src/games/coffeeroaster/options.tsx
var je = {
	single: "games.coffeeroaster.modeSingle",
	challenge: "games.coffeeroaster.modeChallenge"
};
function Me({ value: e, onChange: t }) {
	let n = a(), r = T.safeParse(e), i = r.success ? r.data : T.parse(void 0);
	return /* @__PURE__ */ l("div", {
		className: "cr-mode-options",
		children: /* @__PURE__ */ l("div", {
			className: "cr-mode-grid",
			children: ["single", "challenge"].map((e) => {
				let r = i.mode === e;
				return /* @__PURE__ */ u("button", {
					type: "button",
					onClick: () => t({ mode: e }),
					className: "cr-mode-option relative",
					"aria-pressed": r,
					children: [
						/* @__PURE__ */ l("span", {
							"aria-hidden": !0,
							children: e === "single" ? "◌" : "✦"
						}),
						r && /* @__PURE__ */ l("i", {
							"aria-hidden": !0,
							className: "absolute right-2 top-2 grid size-5 place-items-center rounded-full border-2 border-ink bg-surface",
							children: /* @__PURE__ */ l("span", { className: "size-2 rounded-full bg-ink" })
						}),
						/* @__PURE__ */ l("strong", { children: n(je[e]) }),
						/* @__PURE__ */ l("small", { children: n(e === "single" ? "games.coffeeroaster.modeSingleDesc" : "games.coffeeroaster.modeChallengeDesc") })
					]
				}, e);
			})
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/coffeeroaster/entry.tsx
var Ne = {
	definition: W,
	View: Oe,
	OverView: Ae,
	Options: Me,
	locales: {
		zh: {
			name: "咖啡烘焙师",
			desc: "单人袋构筑:选豆、控温烘焙、杯测冲煮,冲出一杯完美咖啡",
			rules: "目标:将生豆烘至最佳烘焙度，在杯测中争取最高分。\n单杯模式自选一张咖啡卡;挑战模式依次完成三炉烘焙，组别顺序为I、II、III,按总分评定烘焙师头衔。\n准备:按卡片把咖啡豆、硬豆、水分、缺陷豆和风味片装进袋子;水分越多,温控器起始格越靠前。\n袋旁红区格(10、12)上放着烟片。\n烘焙流程:每轮温控器前进一格(首轮不动),格号就是本轮抽片数。\n温控器移入红区格时，将该格上的烟片放入袋中,且本轮多烘 2 级;抽出的水分片立即移出游戏。\n抽取圆片后，可以使用相应效果，再结算烘焙：所有咖啡豆的等级提高1级，红色区域改为提高2级,4级咖啡豆再次烘焙时变为焦豆,硬豆只能升到 0 级;供给耗尽则该豆保持原状放回袋中。\n即时效果(每炉各限一次,先即时后风味):\n· 野性风味:把抽出的 0 级豆和 1 级豆各一枚放上野性风味板的两格(可跨轮集齐),集齐立即换得百搭风味片。\n· 额外抽取2枚：支付醇度片，再抽取2枚圆片。\n· 重新抽取2枚：支付任意风味片，选择2枚已抽出的圆片放回袋中，再抽取2枚圆片。\n· 抽取5枚并移除2枚：支付香气片，抽取5枚圆片，将其中2枚移出游戏，其余圆片放回袋中。\n· 清除：支付任意风味片，将已抽出的焦豆、烟片和缺陷豆全部移出游戏。\n风味效果（支付的风味片放在杯效激活格中；2格均被占据时，获得对应杯效）:\n· 醇度——浓缩：将2枚咖啡豆合并为1枚，等级为原来两枚咖啡豆的等级之和;仅允许两枚 1 级、1 级加 2 级、1 级加 3 级或两枚 2 级。\n· 酸度——保鲜：选择恰好2枚咖啡豆，本轮不进行烘焙，直接放回袋中；不能选择硬豆、缺陷豆或焦豆。\n· 香气——分散：将1枚咖啡豆拆成2枚较低等级的豆。2级豆拆成两枚1级豆；3级豆拆成1级和2级豆各一枚；4级豆拆成1级和3级豆各一枚，或两枚2级豆。\n参与风味效果的咖啡豆立即放回袋中，本轮不进行烘焙。每炉杯效与激活格颜色的搭配随机。\n杯效:\n· 额外豆：在左上方杯位预先放置1枚3级咖啡豆。\n· 甜味：在顶部中央的杯位放置甜味标记。\n· 甄选:为第2排的两个杯位分别抽取2枚圆片，并各选择1枚放入杯位。\n· 交换:杯位填满后，选择2枚杯中圆片放回袋中，再抽取3枚圆片，选择其中2枚填回杯位。\n· 托盘：将托盘容量增加2格。\n杯测:温控器走完 14 格或主动停烘后,逐枚抽片决定入杯或入托盘(托盘满只能入杯);水分片直接弃掉。\n杯位按从上到下、从左到右依次填充,袋空或满杯即计分。\n计分:烘焙分按杯中豆总烘焙度查卡表,表外 0 分。\n风味分根据满足卡面需求的风味片数量计算：匹配1、2、3、4枚时，分别获得1、3、6、10分。\n百搭片可代任意需求;甜味在非指定卡也可代任意。\n技巧分：每个等级的咖啡豆各计算一组。该等级有3、4、5、6、7枚及以上时，分别获得1、2、3、4、5分。\n减分:硬豆、焦豆、烟片各扣 1 分;缺陷豆扣 2 分;杯中零风味扣 3 分;有空杯位扣 5 分。\n挑战模式：第二炉和第三炉可选择的难度，取决于上一炉的得分：\n· 上一炉不超过9分时，只能选择初级难度。\n· 上一炉为10至14分时，可以选择初级或中级难度。\n· 上一炉至少15分时，可以选择全部难度。\n挑战模式总分曾达到35分、获得“中级烘焙师”或更高称号后，才会解锁组别I的专家卡。\n总分头衔：\n· 总分达到60分时，获得“烘焙大师”称号。\n· 总分为53至59分时，获得“顶尖烘焙师”称号。\n· 总分为47至52分时，获得“全城最佳”称号。\n· 总分为40至46分时，获得“首席烘焙师”称号。\n· 总分为35至39分时，获得“中级烘焙师”称号。\n· 总分为28至34分时，获得“熟手烘焙师”称号。\n· 总分为20至27分时，获得“助理烘焙师”称号。\n· 总分不超过19分时，获得“学徒”称号。",
			modeSingle: "单杯自选",
			modeChallenge: "三段挑战",
			modeSingleDesc: "选一支豆，细细烘成一杯",
			modeChallengeDesc: "连续三炉，赢得烘焙师头衔",
			selectTitle: "选择咖啡豆",
			group1: "组别 I",
			group2: "组别 II",
			group3: "组别 III",
			diffBeginner: "初级",
			diffAdvanced: "中级",
			diffExpert: "专家",
			specialty: "大师特选",
			lockedExpert: "挑战总分曾达 35 分解锁",
			lockedByScore: "上炉分数不足",
			lockedGroup: "本炉限组别 {{n}}",
			roastOf: "第 {{n}} 炉",
			startRoast: "开始烘焙",
			selectHint: "翻阅豆卡，选一炉想烘的咖啡",
			selectGroup: "选择组别",
			previousCard: "上一张豆卡",
			nextCard: "下一张豆卡",
			allCards: "浏览本组豆卡",
			inspectCard: "查看配方",
			recipe: "咖啡配方",
			bestRoast: "最佳烘焙度",
			targetFlavor: "目标风味",
			roastScale: "烘焙得分",
			bagContents: "豆袋组成",
			close: "收起",
			draw: "抽片",
			roast: "烘焙",
			finishRoast: "完成本轮烘焙",
			toCup: "进入杯测",
			mustCup: "温控器已到顶,必须杯测",
			round: "第 {{n}} 轮",
			thermostat: "温控",
			drawCount: "抽 {{n}} 枚",
			redZone: "红区 +2 级",
			smokeIn: "烟片入袋",
			drawnTitle: "本轮抽出",
			bagLeft: "袋中 {{n}} 枚",
			drawStep: "下一步：从袋中抽 {{n}} 枚",
			roastStep: "可用技巧处理豆片，再完成本轮烘焙",
			emptyRoastTray: "豆片会铺在这里",
			skills: "烘焙技巧",
			availableSkills: "可用技巧 {{n}}",
			cancel: "取消选择",
			pickTwoStep: "点选两枚片（已选 {{n}}/2）",
			pickBeansStep: "点选豆片（已选 {{n}}/{{total}}）",
			wildStep: "点一枚 0 级豆或 1 级豆，填入野性风味槽",
			flavorTargetStep: "豆片已选好，选择杯效激活槽",
			confirmRedraw: "确认重抽",
			confirmRemove: "确认移除",
			confirmEffect: "确认使用技巧",
			chooseCupFx: "选择杯效槽",
			chooseSplit: "选择拆分方式",
			cupFxBoard: "杯效进度",
			cupFxProgress: "杯效 {{n}}/5",
			skillWildBrief: "用 0 级与 1 级豆换百搭片",
			skillDrawBrief: "消耗醇度片，再抽两枚",
			skillRedrawBrief: "消耗风味片，选两枚放回重抽",
			skillFiveBrief: "消耗香气片，抽五枚移除两枚",
			skillRemovalBrief: "消耗风味片，清走焦豆、烟与缺陷",
			skillFlavorBrief: "处理豆片，并推进杯效",
			fxWild: "野性风味",
			fxWildHint: "把 0 级豆与 1 级豆各一枚放上野性风味板,集齐换百搭片",
			fxDraw2: "额外抽 2",
			fxRedraw2: "重抽 2",
			fxFive2: "抽 5 去 2",
			fxFive2Pick: "选 2 枚移出游戏",
			fxRemoval: "清除杂质",
			flavorConcentrate: "浓缩(醇度)",
			flavorPreserve: "保鲜(酸度)",
			flavorDisperse: "分散(香气)",
			flavorPickSlot: "选择激活格",
			cupFxExtraBean: "额外豆",
			cupFxSweetness: "甜味",
			cupFxSelection: "甄选",
			cupFxExchange: "交换",
			cupFxTray: "托盘",
			cupTitle: "杯测",
			cupDraw: "抽下一枚",
			cupToCup: "入杯",
			cupToTray: "入托盘",
			cupPickOne: "选 1 枚入杯",
			tray: "托盘",
			exchange: "交换",
			exchangeHint: "选 2 枚杯中片回袋",
			exchangePick: "选 2 枚填回空位",
			skipExchange: "跳过交换",
			cupDrawStep: "下一步：抽片填入第 {{n}} 个杯位",
			cupPlaceStep: "决定这枚片入杯，还是暂放托盘",
			cupDrawnNow: "刚抽出的片",
			cupSpaceLabel: "第 {{n}} 个杯位：{{token}}",
			empty: "空",
			confirmCupPick: "确认入杯",
			confirmExchangePick: "确认填回",
			exchangePickStep: "点选两枚杯中片（已选 {{n}}/2）",
			exchangeDecision: "杯位已满：交换两枚，或完成杯测",
			confirmExchange: "确认交换",
			finishCup: "完成杯测",
			scoreTitle: "杯测计分",
			scoreStep: "这一炉的风味已经揭晓",
			scoreRoast: "烘焙分",
			scoreRoastDetail: "总烘焙度 {{n}}",
			scoreFlavor: "风味分",
			scoreFlavorDetail: "匹配 {{n}} 项",
			scoreSkill: "技巧分",
			scoreSkillDetail: "{{n}} 级豆 ×{{c}}",
			scorePenalty: "减分",
			penaltyHard: "硬豆",
			penaltyBurnt: "焦豆",
			penaltySmoke: "烟片",
			penaltyDefective: "缺陷豆",
			penaltyNoFlavor: "零风味",
			penaltyEmpty: "空杯位",
			scoreTotal: "本炉总分",
			challengeTotal: "挑战总分",
			nextRoast: "下一炉",
			finish: "完成",
			title0: "烘焙大师",
			title1: "顶尖烘焙师",
			title2: "全城最佳",
			title3: "首席烘焙师",
			title4: "中级烘焙师",
			title5: "熟手烘焙师",
			title6: "助理烘焙师",
			title7: "学徒",
			bestChallenge: "历史最佳 {{n}} 分",
			card0: "古巴 水晶山",
			card1: "巴拿马 铁皮卡水洗",
			card2: "巴拿马 瑰夏水洗",
			card3: "巴拿马 SHB",
			card4: "牙买加 蓝山一号",
			card5: "墨西哥",
			card6: "也门 摩卡玛塔莉 9 号",
			card7: "哥伦比亚 至尊",
			card8: "巴拿马 卡杜拉珍藏",
			card9: "布隆迪",
			card10: "巴西 日晒",
			card11: "坦桑尼亚 AA",
			card12: "危地马拉 SHB",
			card13: "赞比亚 AA",
			card14: "哥斯达黎加 SHB",
			card15: "夏威夷 科纳一号",
			card16: "埃塞俄比亚 S-G1 水洗",
			card17: "埃塞俄比亚 Y-G1 水洗",
			card18: "印度尼西亚 曼特宁 G1 特选",
			card19: "印度 APA",
			card20: "肯尼亚 AA",
			card21: "秘鲁 EX",
			tokenBean0: "0 级豆",
			tokenBean1: "1 级豆",
			tokenBean2: "2 级豆",
			tokenBean3: "3 级豆",
			tokenBean4: "4 级豆",
			tokenHard: "硬豆",
			tokenBurnt: "焦豆",
			tokenMoisture: "水分",
			tokenSmoke: "烟片",
			tokenDefective: "缺陷豆",
			tokenBody: "醇度片",
			tokenAcidity: "酸度片",
			tokenAroma: "香气片",
			tokenWild: "百搭片",
			tokenExtra: "额外豆",
			tokenSweet: "甜味",
			errNotPlayer: "你不在这一局里",
			errPhase: "当前阶段不能这么做",
			errCardGroup: "本炉只能选这个组别的卡",
			errCardDifficulty: "上炉分数不足以解锁该难度",
			errDrawn: "本轮已经抽过片了",
			errMustCup: "温控器已到顶,必须进入杯测",
			errFxUsed: "这个效果本炉已经用过了",
			errFlavorLocked: "本轮已用风味效果,即时效果须先用",
			errNoToken: "没有这枚片",
			errBagShort: "袋中片数不足",
			errSlot: "这个激活格不可用",
			errBeans: "豆的组合不合法",
			errBox: "供给不足",
			errPending: "先处理当前待选",
			errTrayFull: "托盘已满",
			errCupFull: "杯位已满",
			errCupNotFull: "杯位满后才能交换",
			errExchange: "交换不可用"
		},
		en: {
			name: "Coffee Roaster",
			desc: "Solo bag-building: pick a bean, roast it right, and cup the perfect brew",
			rules: "Goal: roast green beans to their sweet spot and score high at cupping.\nSingle mode: play any one coffee card. Challenge mode: roast three batches (groups I→II→III) and earn a roaster title from your total.\nSetup: fill the bag with the beans, hard beans, moisture, defective beans and flavor tokens shown on the card; more moisture means an earlier thermostat start.\nSmoke tokens sit on the red spaces (10, 12).\nRoasting: each round the thermostat advances one space (not on round 1); its number is how many tokens you draw.\nMoving onto a red space drops its smoke tokens into the bag and beans roast 2 extra levels that round; drawn moisture is removed from the game.\nAfter optional effects, all beans roast up 1 level (2 in a red zone); level-4 beans burn, hard beans only reach level 0, and if the supply runs dry a bean returns unroasted.\nImmediate effects (once per batch each; immediate before flavor):\n· Wild flavor: place a level-0 and a level-1 bean onto the two slots of the wild-flavor board (across rounds) to gain the wild token.\n· Draw 2 more: pay a body token and draw 2 more tokens.\n· Redraw 2: pay any flavor token, return 2 drawn tokens to the bag, and draw 2 new tokens.\n· Draw 5 and remove 2: pay an aroma token and draw 5 tokens. Remove 2 of them from the game and return the rest to the bag.\n· Removal: pay any flavor token and remove all drawn burnt, smoke and defective tokens from the game.\nFlavor effects (the paid token parks on a cup-effect activation slot; fill both slots to earn it):\n· Body = concentrate: merge 2 beans into 1, levels add; only two level-1, level-1 plus level-2, level-1 plus level-3, or two level-2.\n· Acidity = preserve: exactly 2 beans skip roasting and return to the bag (not hard/defective/burnt).\n· Aroma — disperse: split 1 bean into 2 lower-level beans. Split a level-2 bean into two level-1 beans; a level-3 bean into one level-1 and one level-2 bean; or a level-4 bean into one level-1 and one level-3 bean, or two level-2 beans.\nBeans involved return to the bag unroasted. Cup-effect slot colors are randomized each batch.\nCup effects:\n· Extra bean: the top-left cup space is pre-filled with a level-3 bean.\n· Sweetness: the top-middle space holds a sweetness marker.\n· Selection: for each of the two cup spaces in the second row, draw 2 tokens and choose 1 to place there.\n· Exchange: after filling the cup, return 2 cup tokens to the bag. Draw 3 tokens and choose 2 to refill those spaces.\n· Tray: add 2 spaces to your tray.\nCupping: after the thermostat passes 14 or you stop early, draw one token at a time and choose cup or tray (tray full means cup); moisture is discarded.\nSpaces fill top-to-bottom, left-to-right; scoring starts when the cup is full or the bag is empty.\nScoring: roast points come from the total roast level looked up on the card, 0 off-scale.\nFlavor points: matching one, two, three or four required flavor tokens scores 1, 3, 6 or 10 points respectively.\nWild counts as anything; sweetness counts as anything on cards not requiring it.\nSkill points: score each bean level as a separate group. A group of three, four, five, six, or seven or more beans scores 1, 2, 3, 4 or 5 points respectively.\nPenalties:\n· Each hard bean, burnt bean or smoke token loses 1 point.\n· Each defective bean loses 2 points.\n· Having no flavor token in the cup loses 3 points.\n· Having any empty cup space loses 5 points.\nChallenge mode: the available difficulty for batches 2 and 3 depends on the previous batch's score:\n· At 9 points or less, only Beginner is available.\n· At 10–14 points, Beginner and Moderate are available.\n· At 15 points or more, all difficulties are available.\nExpert cards of group I require a lifetime best challenge total of 35+.\nRoaster titles depend on the three-batch total:\n· A total of 60 or more earns Master Roaster.\n· A total of 53–59 earns Top Roaster.\n· A total of 47–52 earns Best in Town.\n· A total of 40–46 earns Chief Roaster.\n· A total of 35–39 earns Mid-level Roaster.\n· A total of 28–34 earns Journeyman.\n· A total of 20–27 earns Assistant.\n· A total of 19 or less earns Apprentice.",
			modeSingle: "Single coffee",
			modeChallenge: "Roast challenge",
			modeSingleDesc: "Roast one lot into your perfect cup",
			modeChallengeDesc: "Three batches toward a roaster title",
			selectTitle: "Choose your coffee",
			group1: "Group I",
			group2: "Group II",
			group3: "Group III",
			diffBeginner: "Beginner",
			diffAdvanced: "Moderate",
			diffExpert: "Expert",
			specialty: "Master roast",
			lockedExpert: "Unlock with a 35+ challenge total",
			lockedByScore: "Previous score too low",
			lockedGroup: "Group {{n}} only",
			roastOf: "Batch {{n}}",
			startRoast: "Start roasting",
			selectHint: "Browse the lots and choose your next roast",
			selectGroup: "Choose a group",
			previousCard: "Previous coffee card",
			nextCard: "Next coffee card",
			allCards: "Browse this group",
			inspectCard: "View recipe",
			recipe: "Coffee recipe",
			bestRoast: "Sweet spot",
			targetFlavor: "Target flavors",
			roastScale: "Roast points",
			bagContents: "Bag contents",
			close: "Close",
			draw: "Draw",
			roast: "Roast",
			finishRoast: "Finish this roast",
			toCup: "To cupping",
			mustCup: "Thermostat maxed — cup now",
			round: "Round {{n}}",
			thermostat: "Temp",
			drawCount: "Draw {{n}}",
			redZone: "Red zone: +2 levels",
			smokeIn: "Smoke in",
			drawnTitle: "Drawn",
			bagLeft: "{{n}} in bag",
			drawStep: "Next: draw {{n}} from the bag",
			roastStep: "Use a skill if you wish, then finish this roast",
			emptyRoastTray: "Drawn tokens will land here",
			skills: "Roasting skills",
			availableSkills: "{{n}} skills",
			cancel: "Cancel",
			pickTwoStep: "Choose two tokens ({{n}}/2)",
			pickBeansStep: "Choose beans ({{n}}/{{total}})",
			wildStep: "Choose a level-0 or level-1 bean for the wild slot",
			flavorTargetStep: "Beans chosen. Pick a cup-effect slot",
			confirmRedraw: "Confirm redraw",
			confirmRemove: "Remove selected",
			confirmEffect: "Use skill",
			chooseCupFx: "Pick cup-effect slot",
			chooseSplit: "Choose a split",
			cupFxBoard: "Cup-effect board",
			cupFxProgress: "Cup effects {{n}}/5",
			skillWildBrief: "Trade level 0 and 1 beans for a wild token",
			skillDrawBrief: "Spend body to draw two more",
			skillRedrawBrief: "Spend a flavor and redraw two tokens",
			skillFiveBrief: "Spend aroma, draw five and remove two",
			skillRemovalBrief: "Spend a flavor to clear burnt, smoke and defects",
			skillFlavorBrief: "Work beans and advance a cup effect",
			fxWild: "Wild flavor",
			fxWildHint: "Place a level-0 and a level-1 bean onto the wild-flavor board to gain the wild token",
			fxDraw2: "Draw 2 more",
			fxRedraw2: "Redraw 2",
			fxFive2: "5 pick 2",
			fxFive2Pick: "Remove 2 from the game",
			fxRemoval: "Purge",
			flavorConcentrate: "Concentrate (body)",
			flavorPreserve: "Preserve (acidity)",
			flavorDisperse: "Disperse (aroma)",
			flavorPickSlot: "Pick a slot",
			cupFxExtraBean: "Extra bean",
			cupFxSweetness: "Sweetness",
			cupFxSelection: "Selection",
			cupFxExchange: "Exchange",
			cupFxTray: "Tray",
			cupTitle: "Cupping",
			cupDraw: "Draw next",
			cupToCup: "To cup",
			cupToTray: "To tray",
			cupPickOne: "Keep 1 in cup",
			tray: "Tray",
			exchange: "Exchange",
			exchangeHint: "Return 2 cup tokens to the bag",
			exchangePick: "Pick 2 to refill",
			skipExchange: "Skip exchange",
			cupDrawStep: "Next: draw for cup space {{n}}",
			cupPlaceStep: "Place this token in the cup or tray",
			cupDrawnNow: "Just drawn",
			cupSpaceLabel: "Cup space {{n}}: {{token}}",
			empty: "Empty",
			confirmCupPick: "Place in cup",
			confirmExchangePick: "Confirm refill",
			exchangePickStep: "Choose two cup tokens ({{n}}/2)",
			exchangeDecision: "Cup full: exchange two or finish cupping",
			confirmExchange: "Confirm exchange",
			finishCup: "Finish cupping",
			scoreTitle: "Cupping score",
			scoreStep: "The flavors of this batch are revealed",
			scoreRoast: "Roast",
			scoreRoastDetail: "Roast level {{n}}",
			scoreFlavor: "Flavor",
			scoreFlavorDetail: "{{n}} matched",
			scoreSkill: "Skill",
			scoreSkillDetail: "Lv {{n}} ×{{c}}",
			scorePenalty: "Penalties",
			penaltyHard: "Hard beans",
			penaltyBurnt: "Burnt beans",
			penaltySmoke: "Smoke",
			penaltyDefective: "Defective",
			penaltyNoFlavor: "No flavor",
			penaltyEmpty: "Empty space",
			scoreTotal: "Batch total",
			challengeTotal: "Challenge total",
			nextRoast: "Next batch",
			finish: "Finish",
			title0: "Master roaster",
			title1: "Top roaster",
			title2: "Best in town",
			title3: "Chief roaster",
			title4: "Mid-level roaster",
			title5: "Journeyman roaster",
			title6: "Assistant roaster",
			title7: "Apprentice",
			bestChallenge: "Best {{n}}",
			card0: "Cuba Crystal Mountain",
			card1: "Panama Typica Washed",
			card2: "Panama Geisha Washed",
			card3: "Panama SHB",
			card4: "Jamaica Blue Mountain No.1",
			card5: "Mexico",
			card6: "Yemen Mokha Mattari No.9",
			card7: "Colombia Supremo",
			card8: "Panama Caturra Reserve",
			card9: "Burundi",
			card10: "Brazil Natural",
			card11: "Tanzania AA",
			card12: "Guatemala SHB",
			card13: "Zambia AA",
			card14: "Costa Rica SHB",
			card15: "Hawaii Kona No.1",
			card16: "Ethiopia S-G1 Washed",
			card17: "Ethiopia Y-G1 Washed",
			card18: "Indonesia Mandheling G1 Special",
			card19: "India APA",
			card20: "Kenya AA",
			card21: "Peru EX",
			tokenBean0: "Bean Lv0",
			tokenBean1: "Bean Lv1",
			tokenBean2: "Bean Lv2",
			tokenBean3: "Bean Lv3",
			tokenBean4: "Bean Lv4",
			tokenHard: "Hard bean",
			tokenBurnt: "Burnt bean",
			tokenMoisture: "Moisture",
			tokenSmoke: "Smoke",
			tokenDefective: "Defective",
			tokenBody: "Body",
			tokenAcidity: "Acidity",
			tokenAroma: "Aroma",
			tokenWild: "Wild",
			tokenExtra: "Extra bean",
			tokenSweet: "Sweetness",
			errNotPlayer: "You are not in this game",
			errPhase: "Not allowed right now",
			errCardGroup: "Only this group is allowed for this batch",
			errCardDifficulty: "Previous score does not unlock this difficulty",
			errDrawn: "Already drawn this round",
			errMustCup: "Thermostat maxed — go to cupping",
			errFxUsed: "Effect already used this batch",
			errFlavorLocked: "Immediate effects must come before flavor effects",
			errNoToken: "Token not available",
			errBagShort: "Not enough tokens in the bag",
			errSlot: "Slot not available",
			errBeans: "Illegal bean combination",
			errBox: "Supply exhausted",
			errPending: "Resolve the pending choice first",
			errTrayFull: "Tray is full",
			errCupFull: "Cup is full",
			errCupNotFull: "Exchange needs a full cup",
			errExchange: "Exchange not available"
		}
	}
};
//#endregion
export { Ne as default };
