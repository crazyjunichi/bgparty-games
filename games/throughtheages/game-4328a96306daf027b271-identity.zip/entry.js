import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, createContext as r, useContext as i, useEffect as a, useId as o, useMemo as s, useRef as c, useState as l, useSyncExternalStore as u } from "react";
import { useI18nSettings as d, useT as f } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as p } from "@bgparty/sdk/player-colors";
import { useWakeLock as m } from "@bgparty/sdk/use-wake-lock";
import { BottomSheet as ee } from "@bgparty/sdk/bottom-sheet";
import { IconBack as te, IconBot as ne, IconCheck as re, IconClose as h, IconExpand as ie, IconLog as ae } from "@bgparty/sdk/icons";
import { GameScreen as oe } from "@bgparty/sdk/ui/game-screen";
import { Fragment as g, jsx as _, jsxs as v } from "react/jsx-runtime";
import { seatName as se } from "@bgparty/sdk/ui/player-strip";
import { Confetti as ce } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as le, OptionSection as ue, OptionSwitch as y } from "@bgparty/sdk/ui/game-options";
//#region src/games/throughtheages/cards.ts
var de = {
	agriculture: {
		id: "agriculture",
		nameKey: "games.throughtheages.cards.agriculture.name",
		textKey: "games.throughtheages.cards.agriculture.text",
		kind: "technology",
		age: 0,
		category: "farm",
		science: 0,
		cost: 2,
		ratings: {},
		count: [
			0,
			0,
			0
		],
		value: 1,
		initial: !0
	},
	bronze: {
		id: "bronze",
		nameKey: "games.throughtheages.cards.bronze.name",
		textKey: "games.throughtheages.cards.bronze.text",
		kind: "technology",
		age: 0,
		category: "mine",
		science: 0,
		cost: 2,
		ratings: {},
		count: [
			0,
			0,
			0
		],
		value: 1,
		initial: !0
	},
	philosophy: {
		id: "philosophy",
		nameKey: "games.throughtheages.cards.philosophy.name",
		textKey: "games.throughtheages.cards.philosophy.text",
		kind: "technology",
		age: 0,
		category: "lab",
		science: 0,
		cost: 3,
		ratings: { science: 1 },
		count: [
			0,
			0,
			0
		],
		initial: !0
	},
	religion: {
		id: "religion",
		nameKey: "games.throughtheages.cards.religion.name",
		textKey: "games.throughtheages.cards.religion.text",
		kind: "technology",
		age: 0,
		category: "temple",
		science: 0,
		cost: 3,
		ratings: {
			culture: 1,
			happy: 1
		},
		count: [
			0,
			0,
			0
		],
		initial: !0
	},
	warriors: {
		id: "warriors",
		nameKey: "games.throughtheages.cards.warriors.name",
		textKey: "games.throughtheages.cards.warriors.text",
		kind: "technology",
		age: 0,
		category: "infantry",
		science: 0,
		cost: 2,
		ratings: { strength: 1 },
		count: [
			0,
			0,
			0
		],
		initial: !0
	},
	irrigation: {
		id: "irrigation",
		nameKey: "games.throughtheages.cards.irrigation.name",
		textKey: "games.throughtheages.cards.irrigation.text",
		kind: "technology",
		age: 1,
		category: "farm",
		science: 3,
		cost: 4,
		ratings: {},
		count: [
			2,
			2,
			2
		],
		value: 2
	},
	selectiveBreeding: {
		id: "selectiveBreeding",
		nameKey: "games.throughtheages.cards.selectiveBreeding.name",
		textKey: "games.throughtheages.cards.selectiveBreeding.text",
		kind: "technology",
		age: 2,
		category: "farm",
		science: 5,
		cost: 6,
		ratings: {},
		count: [
			1,
			2,
			3
		],
		value: 3
	},
	mechanizedAgriculture: {
		id: "mechanizedAgriculture",
		nameKey: "games.throughtheages.cards.mechanizedAgriculture.name",
		textKey: "games.throughtheages.cards.mechanizedAgriculture.text",
		kind: "technology",
		age: 3,
		category: "farm",
		science: 7,
		cost: 8,
		ratings: {},
		count: [
			1,
			2,
			2
		],
		value: 5
	},
	iron: {
		id: "iron",
		nameKey: "games.throughtheages.cards.iron.name",
		textKey: "games.throughtheages.cards.iron.text",
		kind: "technology",
		age: 1,
		category: "mine",
		science: 5,
		cost: 5,
		ratings: {},
		count: [
			2,
			2,
			3
		],
		value: 2
	},
	coal: {
		id: "coal",
		nameKey: "games.throughtheages.cards.coal.name",
		textKey: "games.throughtheages.cards.coal.text",
		kind: "technology",
		age: 2,
		category: "mine",
		science: 7,
		cost: 8,
		ratings: {},
		count: [
			1,
			2,
			2
		],
		value: 3
	},
	oil: {
		id: "oil",
		nameKey: "games.throughtheages.cards.oil.name",
		textKey: "games.throughtheages.cards.oil.text",
		kind: "technology",
		age: 3,
		category: "mine",
		science: 9,
		cost: 11,
		ratings: {},
		count: [
			1,
			2,
			2
		],
		value: 5
	},
	alchemy: {
		id: "alchemy",
		nameKey: "games.throughtheages.cards.alchemy.name",
		textKey: "games.throughtheages.cards.alchemy.text",
		kind: "technology",
		age: 1,
		category: "lab",
		science: 4,
		cost: 6,
		ratings: { science: 2 },
		count: [
			2,
			2,
			3
		]
	},
	scientificMethod: {
		id: "scientificMethod",
		nameKey: "games.throughtheages.cards.scientificMethod.name",
		textKey: "games.throughtheages.cards.scientificMethod.text",
		kind: "technology",
		age: 2,
		category: "lab",
		science: 6,
		cost: 8,
		ratings: { science: 3 },
		count: [
			2,
			2,
			2
		]
	},
	computers: {
		id: "computers",
		nameKey: "games.throughtheages.cards.computers.name",
		textKey: "games.throughtheages.cards.computers.text",
		kind: "technology",
		age: 3,
		category: "lab",
		science: 8,
		cost: 11,
		ratings: { science: 5 },
		count: [
			2,
			2,
			2
		]
	},
	theology: {
		id: "theology",
		nameKey: "games.throughtheages.cards.theology.name",
		textKey: "games.throughtheages.cards.theology.text",
		kind: "technology",
		age: 1,
		category: "temple",
		science: 2,
		cost: 5,
		ratings: {
			culture: 1,
			happy: 2
		},
		count: [
			1,
			2,
			2
		]
	},
	organizedReligion: {
		id: "organizedReligion",
		nameKey: "games.throughtheages.cards.organizedReligion.name",
		textKey: "games.throughtheages.cards.organizedReligion.text",
		kind: "technology",
		age: 2,
		category: "temple",
		science: 4,
		cost: 7,
		ratings: {
			culture: 1,
			happy: 3
		},
		count: [
			2,
			2,
			2
		]
	},
	printingPress: {
		id: "printingPress",
		nameKey: "games.throughtheages.cards.printingPress.name",
		textKey: "games.throughtheages.cards.printingPress.text",
		kind: "technology",
		age: 1,
		category: "library",
		science: 3,
		cost: 3,
		ratings: {
			science: 1,
			culture: 1
		},
		count: [
			2,
			2,
			2
		]
	},
	journalism: {
		id: "journalism",
		nameKey: "games.throughtheages.cards.journalism.name",
		textKey: "games.throughtheages.cards.journalism.text",
		kind: "technology",
		age: 2,
		category: "library",
		science: 6,
		cost: 8,
		ratings: {
			science: 2,
			culture: 2
		},
		count: [
			1,
			2,
			2
		]
	},
	multimedia: {
		id: "multimedia",
		nameKey: "games.throughtheages.cards.multimedia.name",
		textKey: "games.throughtheages.cards.multimedia.text",
		kind: "technology",
		age: 3,
		category: "library",
		science: 9,
		cost: 11,
		ratings: {
			science: 3,
			culture: 3
		},
		count: [
			2,
			2,
			2
		]
	},
	drama: {
		id: "drama",
		nameKey: "games.throughtheages.cards.drama.name",
		textKey: "games.throughtheages.cards.drama.text",
		kind: "technology",
		age: 1,
		category: "theater",
		science: 3,
		cost: 4,
		ratings: {
			culture: 2,
			happy: 1
		},
		count: [
			1,
			2,
			2
		]
	},
	opera: {
		id: "opera",
		nameKey: "games.throughtheages.cards.opera.name",
		textKey: "games.throughtheages.cards.opera.text",
		kind: "technology",
		age: 2,
		category: "theater",
		science: 7,
		cost: 8,
		ratings: {
			culture: 3,
			happy: 1
		},
		count: [
			2,
			2,
			2
		]
	},
	movies: {
		id: "movies",
		nameKey: "games.throughtheages.cards.movies.name",
		textKey: "games.throughtheages.cards.movies.text",
		kind: "technology",
		age: 3,
		category: "theater",
		science: 10,
		cost: 11,
		ratings: {
			culture: 4,
			happy: 1
		},
		count: [
			2,
			2,
			2
		]
	},
	breadCircuses: {
		id: "breadCircuses",
		nameKey: "games.throughtheages.cards.breadCircuses.name",
		textKey: "games.throughtheages.cards.breadCircuses.text",
		kind: "technology",
		age: 1,
		category: "arena",
		science: 3,
		cost: 3,
		ratings: {
			strength: 1,
			happy: 2
		},
		count: [
			1,
			2,
			2
		]
	},
	teamSports: {
		id: "teamSports",
		nameKey: "games.throughtheages.cards.teamSports.name",
		textKey: "games.throughtheages.cards.teamSports.text",
		kind: "technology",
		age: 2,
		category: "arena",
		science: 5,
		cost: 5,
		ratings: {
			strength: 2,
			happy: 3
		},
		count: [
			2,
			2,
			2
		]
	},
	professionalSports: {
		id: "professionalSports",
		nameKey: "games.throughtheages.cards.professionalSports.name",
		textKey: "games.throughtheages.cards.professionalSports.text",
		kind: "technology",
		age: 3,
		category: "arena",
		science: 7,
		cost: 8,
		ratings: {
			strength: 3,
			happy: 4
		},
		count: [
			1,
			1,
			2
		]
	},
	swordsmen: {
		id: "swordsmen",
		nameKey: "games.throughtheages.cards.swordsmen.name",
		textKey: "games.throughtheages.cards.swordsmen.text",
		kind: "technology",
		age: 1,
		category: "infantry",
		science: 4,
		cost: 3,
		ratings: { strength: 2 },
		count: [
			2,
			2,
			2
		]
	},
	riflemen: {
		id: "riflemen",
		nameKey: "games.throughtheages.cards.riflemen.name",
		textKey: "games.throughtheages.cards.riflemen.text",
		kind: "technology",
		age: 2,
		category: "infantry",
		science: 6,
		cost: 5,
		ratings: { strength: 3 },
		count: [
			1,
			2,
			2
		]
	},
	modernInfantry: {
		id: "modernInfantry",
		nameKey: "games.throughtheages.cards.modernInfantry.name",
		textKey: "games.throughtheages.cards.modernInfantry.text",
		kind: "technology",
		age: 3,
		category: "infantry",
		science: 10,
		cost: 7,
		ratings: { strength: 5 },
		count: [
			1,
			2,
			2
		]
	},
	knights: {
		id: "knights",
		nameKey: "games.throughtheages.cards.knights.name",
		textKey: "games.throughtheages.cards.knights.text",
		kind: "technology",
		age: 1,
		category: "cavalry",
		science: 5,
		cost: 3,
		ratings: { strength: 2 },
		count: [
			2,
			2,
			3
		]
	},
	cavalrymen: {
		id: "cavalrymen",
		nameKey: "games.throughtheages.cards.cavalrymen.name",
		textKey: "games.throughtheages.cards.cavalrymen.text",
		kind: "technology",
		age: 2,
		category: "cavalry",
		science: 6,
		cost: 5,
		ratings: { strength: 3 },
		count: [
			2,
			2,
			2
		]
	},
	tanks: {
		id: "tanks",
		nameKey: "games.throughtheages.cards.tanks.name",
		textKey: "games.throughtheages.cards.tanks.text",
		kind: "technology",
		age: 3,
		category: "cavalry",
		science: 9,
		cost: 7,
		ratings: { strength: 5 },
		count: [
			1,
			2,
			2
		]
	},
	cannon: {
		id: "cannon",
		nameKey: "games.throughtheages.cards.cannon.name",
		textKey: "games.throughtheages.cards.cannon.text",
		kind: "technology",
		age: 2,
		category: "artillery",
		science: 6,
		cost: 5,
		ratings: { strength: 3 },
		count: [
			2,
			2,
			3
		]
	},
	rockets: {
		id: "rockets",
		nameKey: "games.throughtheages.cards.rockets.name",
		textKey: "games.throughtheages.cards.rockets.text",
		kind: "technology",
		age: 3,
		category: "artillery",
		science: 8,
		cost: 7,
		ratings: { strength: 5 },
		count: [
			1,
			2,
			2
		]
	},
	airforces: {
		id: "airforces",
		nameKey: "games.throughtheages.cards.airforces.name",
		textKey: "games.throughtheages.cards.airforces.text",
		kind: "technology",
		age: 3,
		category: "airforce",
		science: 12,
		cost: 7,
		ratings: { strength: 5 },
		count: [
			2,
			2,
			3
		]
	},
	codeOfLaws: {
		id: "codeOfLaws",
		nameKey: "games.throughtheages.cards.codeOfLaws.name",
		textKey: "games.throughtheages.cards.codeOfLaws.text",
		kind: "technology",
		age: 1,
		category: "law",
		science: 6,
		cost: 0,
		ratings: { civil: 1 },
		count: [
			1,
			2,
			2
		]
	},
	justiceSystem: {
		id: "justiceSystem",
		nameKey: "games.throughtheages.cards.justiceSystem.name",
		textKey: "games.throughtheages.cards.justiceSystem.text",
		kind: "technology",
		age: 2,
		category: "law",
		science: 7,
		cost: 0,
		ratings: { civil: 2 },
		count: [
			1,
			1,
			1
		]
	},
	civilService: {
		id: "civilService",
		nameKey: "games.throughtheages.cards.civilService.name",
		textKey: "games.throughtheages.cards.civilService.text",
		kind: "technology",
		age: 3,
		category: "law",
		science: 10,
		cost: 0,
		ratings: { civil: 3 },
		count: [
			1,
			1,
			1
		]
	},
	warfare: {
		id: "warfare",
		nameKey: "games.throughtheages.cards.warfare.name",
		textKey: "games.throughtheages.cards.warfare.text",
		kind: "technology",
		age: 1,
		category: "warfare",
		science: 5,
		cost: 0,
		ratings: {
			military: 1,
			strength: 1
		},
		count: [
			1,
			2,
			2
		]
	},
	strategy: {
		id: "strategy",
		nameKey: "games.throughtheages.cards.strategy.name",
		textKey: "games.throughtheages.cards.strategy.text",
		kind: "technology",
		age: 2,
		category: "warfare",
		science: 8,
		cost: 0,
		ratings: {
			military: 2,
			strength: 3
		},
		count: [
			1,
			1,
			1
		]
	},
	militaryTheory: {
		id: "militaryTheory",
		nameKey: "games.throughtheages.cards.militaryTheory.name",
		textKey: "games.throughtheages.cards.militaryTheory.text",
		kind: "technology",
		age: 3,
		category: "warfare",
		science: 11,
		cost: 0,
		ratings: {
			military: 3,
			strength: 5
		},
		count: [
			1,
			1,
			2
		]
	},
	cartography: {
		id: "cartography",
		nameKey: "games.throughtheages.cards.cartography.name",
		textKey: "games.throughtheages.cards.cartography.text",
		kind: "technology",
		age: 1,
		category: "exploration",
		science: 4,
		cost: 0,
		ratings: {
			strength: 1,
			colonize: 2
		},
		count: [
			1,
			1,
			1
		]
	},
	navigation: {
		id: "navigation",
		nameKey: "games.throughtheages.cards.navigation.name",
		textKey: "games.throughtheages.cards.navigation.text",
		kind: "technology",
		age: 2,
		category: "exploration",
		science: 6,
		cost: 0,
		ratings: {
			strength: 2,
			colonize: 3
		},
		count: [
			1,
			1,
			1
		]
	},
	satellites: {
		id: "satellites",
		nameKey: "games.throughtheages.cards.satellites.name",
		textKey: "games.throughtheages.cards.satellites.text",
		kind: "technology",
		age: 3,
		category: "exploration",
		science: 8,
		cost: 0,
		ratings: {
			strength: 3,
			colonize: 4
		},
		count: [
			1,
			1,
			1
		]
	},
	masonry: {
		id: "masonry",
		nameKey: "games.throughtheages.cards.masonry.name",
		textKey: "games.throughtheages.cards.masonry.text",
		kind: "technology",
		age: 1,
		category: "construction",
		science: 3,
		cost: 0,
		ratings: {},
		count: [
			1,
			1,
			1
		]
	},
	architecture: {
		id: "architecture",
		nameKey: "games.throughtheages.cards.architecture.name",
		textKey: "games.throughtheages.cards.architecture.text",
		kind: "technology",
		age: 2,
		category: "construction",
		science: 6,
		cost: 0,
		ratings: {},
		count: [
			1,
			2,
			2
		]
	},
	engineering: {
		id: "engineering",
		nameKey: "games.throughtheages.cards.engineering.name",
		textKey: "games.throughtheages.cards.engineering.text",
		kind: "technology",
		age: 3,
		category: "construction",
		science: 9,
		cost: 0,
		ratings: {},
		count: [
			1,
			1,
			1
		]
	},
	despotism: {
		id: "despotism",
		nameKey: "games.throughtheages.cards.despotism.name",
		textKey: "games.throughtheages.cards.despotism.text",
		age: 0,
		kind: "government",
		science: 0,
		revolution: 0,
		ratings: {
			civil: 4,
			military: 2,
			urban: 2
		},
		count: [
			0,
			0,
			0
		],
		initial: !0
	},
	monarchy: {
		id: "monarchy",
		nameKey: "games.throughtheages.cards.monarchy.name",
		textKey: "games.throughtheages.cards.monarchy.text",
		age: 1,
		kind: "government",
		science: 8,
		revolution: 2,
		ratings: {
			civil: 5,
			military: 3,
			urban: 3
		},
		count: [
			1,
			2,
			2
		]
	},
	theocracy: {
		id: "theocracy",
		nameKey: "games.throughtheages.cards.theocracy.name",
		textKey: "games.throughtheages.cards.theocracy.text",
		age: 1,
		kind: "government",
		science: 6,
		revolution: 1,
		ratings: {
			civil: 4,
			military: 3,
			urban: 2,
			culture: 1,
			happy: 2
		},
		count: [
			1,
			1,
			1
		]
	},
	constitutionalMonarchy: {
		id: "constitutionalMonarchy",
		nameKey: "games.throughtheages.cards.constitutionalMonarchy.name",
		textKey: "games.throughtheages.cards.constitutionalMonarchy.text",
		age: 2,
		kind: "government",
		science: 12,
		revolution: 6,
		ratings: {
			civil: 6,
			military: 4,
			urban: 3
		},
		count: [
			1,
			2,
			2
		]
	},
	republic: {
		id: "republic",
		nameKey: "games.throughtheages.cards.republic.name",
		textKey: "games.throughtheages.cards.republic.text",
		age: 2,
		kind: "government",
		science: 13,
		revolution: 3,
		ratings: {
			civil: 7,
			military: 2,
			urban: 3
		},
		count: [
			1,
			1,
			2
		]
	},
	democracy: {
		id: "democracy",
		nameKey: "games.throughtheages.cards.democracy.name",
		textKey: "games.throughtheages.cards.democracy.text",
		age: 3,
		kind: "government",
		science: 17,
		revolution: 9,
		ratings: {
			civil: 7,
			military: 3,
			urban: 4,
			culture: 3
		},
		count: [
			1,
			2,
			2
		]
	},
	communism: {
		id: "communism",
		nameKey: "games.throughtheages.cards.communism.name",
		textKey: "games.throughtheages.cards.communism.text",
		age: 3,
		kind: "government",
		science: 19,
		revolution: 5,
		ratings: {
			civil: 7,
			military: 5,
			urban: 4,
			happy: -1
		},
		count: [
			1,
			1,
			1
		]
	},
	fundamentalism: {
		id: "fundamentalism",
		nameKey: "games.throughtheages.cards.fundamentalism.name",
		textKey: "games.throughtheages.cards.fundamentalism.text",
		age: 3,
		kind: "government",
		science: 18,
		revolution: 7,
		ratings: {
			civil: 6,
			military: 5,
			urban: 4,
			strength: 5,
			science: -2
		},
		count: [
			1,
			1,
			1
		]
	},
	homer: {
		id: "homer",
		nameKey: "games.throughtheages.cards.homer.name",
		textKey: "games.throughtheages.cards.homer.text",
		kind: "leader",
		age: 0,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "homer",
		ratings: { happy: 1 }
	},
	moses: {
		id: "moses",
		nameKey: "games.throughtheages.cards.moses.name",
		textKey: "games.throughtheages.cards.moses.text",
		kind: "leader",
		age: 0,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "moses"
	},
	alexander: {
		id: "alexander",
		nameKey: "games.throughtheages.cards.alexander.name",
		textKey: "games.throughtheages.cards.alexander.text",
		kind: "leader",
		age: 0,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "alexander"
	},
	hammurabi: {
		id: "hammurabi",
		nameKey: "games.throughtheages.cards.hammurabi.name",
		textKey: "games.throughtheages.cards.hammurabi.text",
		kind: "leader",
		age: 0,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "hammurabi"
	},
	caesar: {
		id: "caesar",
		nameKey: "games.throughtheages.cards.caesar.name",
		textKey: "games.throughtheages.cards.caesar.text",
		kind: "leader",
		age: 0,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "caesar",
		ratings: {
			strength: 1,
			military: 1
		}
	},
	aristotle: {
		id: "aristotle",
		nameKey: "games.throughtheages.cards.aristotle.name",
		textKey: "games.throughtheages.cards.aristotle.text",
		kind: "leader",
		age: 0,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "aristotle"
	},
	ashoka: {
		id: "ashoka",
		nameKey: "games.throughtheages.cards.ashoka.name",
		textKey: "games.throughtheages.cards.ashoka.text",
		kind: "leader",
		age: 0,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "ashoka"
	},
	cleopatra: {
		id: "cleopatra",
		nameKey: "games.throughtheages.cards.cleopatra.name",
		textKey: "games.throughtheages.cards.cleopatra.text",
		kind: "leader",
		age: 0,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "cleopatra"
	},
	sunTzu: {
		id: "sunTzu",
		nameKey: "games.throughtheages.cards.sunTzu.name",
		textKey: "games.throughtheages.cards.sunTzu.text",
		kind: "leader",
		age: 0,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "sunTzu",
		ratings: { strength: 1 }
	},
	confucius: {
		id: "confucius",
		nameKey: "games.throughtheages.cards.confucius.name",
		textKey: "games.throughtheages.cards.confucius.text",
		kind: "leader",
		age: 0,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "confucius"
	},
	boudica: {
		id: "boudica",
		nameKey: "games.throughtheages.cards.boudica.name",
		textKey: "games.throughtheages.cards.boudica.text",
		kind: "leader",
		age: 0,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "boudica"
	},
	hippocrates: {
		id: "hippocrates",
		nameKey: "games.throughtheages.cards.hippocrates.name",
		textKey: "games.throughtheages.cards.hippocrates.text",
		kind: "leader",
		age: 0,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "hippocrates"
	},
	joan: {
		id: "joan",
		nameKey: "games.throughtheages.cards.joan.name",
		textKey: "games.throughtheages.cards.joan.text",
		kind: "leader",
		age: 1,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "joan",
		ratings: {
			culture: 1,
			military: 1
		}
	},
	columbus: {
		id: "columbus",
		nameKey: "games.throughtheages.cards.columbus.name",
		textKey: "games.throughtheages.cards.columbus.text",
		kind: "leader",
		age: 1,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "columbus"
	},
	daVinci: {
		id: "daVinci",
		nameKey: "games.throughtheages.cards.daVinci.name",
		textKey: "games.throughtheages.cards.daVinci.text",
		kind: "leader",
		age: 1,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "daVinci"
	},
	michelangelo: {
		id: "michelangelo",
		nameKey: "games.throughtheages.cards.michelangelo.name",
		textKey: "games.throughtheages.cards.michelangelo.text",
		kind: "leader",
		age: 1,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "michelangelo"
	},
	barbarossa: {
		id: "barbarossa",
		nameKey: "games.throughtheages.cards.barbarossa.name",
		textKey: "games.throughtheages.cards.barbarossa.text",
		kind: "leader",
		age: 1,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "barbarossa"
	},
	genghis: {
		id: "genghis",
		nameKey: "games.throughtheages.cards.genghis.name",
		textKey: "games.throughtheages.cards.genghis.text",
		kind: "leader",
		age: 1,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "genghis"
	},
	isabella: {
		id: "isabella",
		nameKey: "games.throughtheages.cards.isabella.name",
		textKey: "games.throughtheages.cards.isabella.text",
		kind: "leader",
		age: 1,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "isabella",
		ratings: {
			ore: 1,
			military: 2
		}
	},
	nostradamus: {
		id: "nostradamus",
		nameKey: "games.throughtheages.cards.nostradamus.name",
		textKey: "games.throughtheages.cards.nostradamus.text",
		kind: "leader",
		age: 1,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "nostradamus"
	},
	zizka: {
		id: "zizka",
		nameKey: "games.throughtheages.cards.zizka.name",
		textKey: "games.throughtheages.cards.zizka.text",
		kind: "leader",
		age: 1,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "zizka",
		ratings: { military: 1 }
	},
	saladin: {
		id: "saladin",
		nameKey: "games.throughtheages.cards.saladin.name",
		textKey: "games.throughtheages.cards.saladin.text",
		kind: "leader",
		age: 1,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "saladin"
	},
	eleanor: {
		id: "eleanor",
		nameKey: "games.throughtheages.cards.eleanor.name",
		textKey: "games.throughtheages.cards.eleanor.text",
		kind: "leader",
		age: 1,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "eleanor"
	},
	gutenberg: {
		id: "gutenberg",
		nameKey: "games.throughtheages.cards.gutenberg.name",
		textKey: "games.throughtheages.cards.gutenberg.text",
		kind: "leader",
		age: 1,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "gutenberg"
	},
	cook: {
		id: "cook",
		nameKey: "games.throughtheages.cards.cook.name",
		textKey: "games.throughtheages.cards.cook.text",
		kind: "leader",
		age: 2,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "cook",
		ratings: { colonize: 1 }
	},
	robespierre: {
		id: "robespierre",
		nameKey: "games.throughtheages.cards.robespierre.name",
		textKey: "games.throughtheages.cards.robespierre.text",
		kind: "leader",
		age: 2,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "robespierre",
		ratings: { military: 1 }
	},
	bach: {
		id: "bach",
		nameKey: "games.throughtheages.cards.bach.name",
		textKey: "games.throughtheages.cards.bach.text",
		kind: "leader",
		age: 2,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "bach"
	},
	newton: {
		id: "newton",
		nameKey: "games.throughtheages.cards.newton.name",
		textKey: "games.throughtheages.cards.newton.text",
		kind: "leader",
		age: 2,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "newton"
	},
	shakespeare: {
		id: "shakespeare",
		nameKey: "games.throughtheages.cards.shakespeare.name",
		textKey: "games.throughtheages.cards.shakespeare.text",
		kind: "leader",
		age: 2,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "shakespeare",
		ratings: { happy: 1 }
	},
	napoleon: {
		id: "napoleon",
		nameKey: "games.throughtheages.cards.napoleon.name",
		textKey: "games.throughtheages.cards.napoleon.text",
		kind: "leader",
		age: 2,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "napoleon",
		ratings: { military: 3 }
	},
	gaudi: {
		id: "gaudi",
		nameKey: "games.throughtheages.cards.gaudi.name",
		textKey: "games.throughtheages.cards.gaudi.text",
		kind: "leader",
		age: 2,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "gaudi"
	},
	darwin: {
		id: "darwin",
		nameKey: "games.throughtheages.cards.darwin.name",
		textKey: "games.throughtheages.cards.darwin.text",
		kind: "leader",
		age: 2,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "darwin"
	},
	watt: {
		id: "watt",
		nameKey: "games.throughtheages.cards.watt.name",
		textKey: "games.throughtheages.cards.watt.text",
		kind: "leader",
		age: 2,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "watt"
	},
	nobel: {
		id: "nobel",
		nameKey: "games.throughtheages.cards.nobel.name",
		textKey: "games.throughtheages.cards.nobel.text",
		kind: "leader",
		age: 2,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "nobel",
		ratings: {
			strength: 2,
			science: 2
		}
	},
	catherine: {
		id: "catherine",
		nameKey: "games.throughtheages.cards.catherine.name",
		textKey: "games.throughtheages.cards.catherine.text",
		kind: "leader",
		age: 2,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "catherine",
		ratings: {
			culture: 2,
			military: 1
		}
	},
	mariaTheresa: {
		id: "mariaTheresa",
		nameKey: "games.throughtheages.cards.mariaTheresa.name",
		textKey: "games.throughtheages.cards.mariaTheresa.text",
		kind: "leader",
		age: 2,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "mariaTheresa"
	},
	chaplin: {
		id: "chaplin",
		nameKey: "games.throughtheages.cards.chaplin.name",
		textKey: "games.throughtheages.cards.chaplin.text",
		kind: "leader",
		age: 3,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "chaplin",
		ratings: { happy: 2 }
	},
	gandhi: {
		id: "gandhi",
		nameKey: "games.throughtheages.cards.gandhi.name",
		textKey: "games.throughtheages.cards.gandhi.text",
		kind: "leader",
		age: 3,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "gandhi",
		ratings: { culture: 2 }
	},
	einstein: {
		id: "einstein",
		nameKey: "games.throughtheages.cards.einstein.name",
		textKey: "games.throughtheages.cards.einstein.text",
		kind: "leader",
		age: 3,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "einstein"
	},
	churchill: {
		id: "churchill",
		nameKey: "games.throughtheages.cards.churchill.name",
		textKey: "games.throughtheages.cards.churchill.text",
		kind: "leader",
		age: 3,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "churchill"
	},
	billGates: {
		id: "billGates",
		nameKey: "games.throughtheages.cards.billGates.name",
		textKey: "games.throughtheages.cards.billGates.text",
		kind: "leader",
		age: 3,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "billGates"
	},
	sidMeier: {
		id: "sidMeier",
		nameKey: "games.throughtheages.cards.sidMeier.name",
		textKey: "games.throughtheages.cards.sidMeier.text",
		kind: "leader",
		age: 3,
		expansion: !1,
		count: [
			1,
			1,
			1
		],
		effect: "sidMeier"
	},
	curie: {
		id: "curie",
		nameKey: "games.throughtheages.cards.curie.name",
		textKey: "games.throughtheages.cards.curie.text",
		kind: "leader",
		age: 3,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "curie"
	},
	jobs: {
		id: "jobs",
		nameKey: "games.throughtheages.cards.jobs.name",
		textKey: "games.throughtheages.cards.jobs.text",
		kind: "leader",
		age: 3,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "jobs"
	},
	fleming: {
		id: "fleming",
		nameKey: "games.throughtheages.cards.fleming.name",
		textKey: "games.throughtheages.cards.fleming.text",
		kind: "leader",
		age: 3,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "fleming"
	},
	dietrich: {
		id: "dietrich",
		nameKey: "games.throughtheages.cards.dietrich.name",
		textKey: "games.throughtheages.cards.dietrich.text",
		kind: "leader",
		age: 3,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "dietrich"
	},
	mandela: {
		id: "mandela",
		nameKey: "games.throughtheages.cards.mandela.name",
		textKey: "games.throughtheages.cards.mandela.text",
		kind: "leader",
		age: 3,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "mandela",
		ratings: {
			culture: 2,
			civil: 1
		}
	},
	coubertin: {
		id: "coubertin",
		nameKey: "games.throughtheages.cards.coubertin.name",
		textKey: "games.throughtheages.cards.coubertin.text",
		kind: "leader",
		age: 3,
		expansion: !0,
		count: [
			1,
			1,
			1
		],
		effect: "coubertin"
	},
	alexandria: {
		id: "alexandria",
		nameKey: "games.throughtheages.cards.alexandria.name",
		textKey: "games.throughtheages.cards.alexandria.text",
		kind: "wonder",
		age: 0,
		expansion: !1,
		stages: [
			1,
			4,
			1
		],
		ratings: {
			culture: 1,
			science: 1
		},
		count: [
			1,
			1,
			1
		],
		effect: "alexandria"
	},
	colossus: {
		id: "colossus",
		nameKey: "games.throughtheages.cards.colossus.name",
		textKey: "games.throughtheages.cards.colossus.text",
		kind: "wonder",
		age: 0,
		expansion: !1,
		stages: [3, 3],
		ratings: {
			strength: 2,
			colonize: 1
		},
		count: [
			1,
			1,
			1
		],
		effect: "colossus"
	},
	pyramids: {
		id: "pyramids",
		nameKey: "games.throughtheages.cards.pyramids.name",
		textKey: "games.throughtheages.cards.pyramids.text",
		kind: "wonder",
		age: 0,
		expansion: !1,
		stages: [
			3,
			2,
			1
		],
		ratings: { civil: 1 },
		count: [
			1,
			1,
			1
		],
		effect: "pyramids"
	},
	hangingGardens: {
		id: "hangingGardens",
		nameKey: "games.throughtheages.cards.hangingGardens.name",
		textKey: "games.throughtheages.cards.hangingGardens.text",
		kind: "wonder",
		age: 0,
		expansion: !1,
		stages: [
			2,
			2,
			2
		],
		ratings: {
			culture: 1,
			happy: 2
		},
		count: [
			1,
			1,
			1
		],
		effect: "hangingGardens"
	},
	colosseum: {
		id: "colosseum",
		nameKey: "games.throughtheages.cards.colosseum.name",
		textKey: "games.throughtheages.cards.colosseum.text",
		kind: "wonder",
		age: 0,
		expansion: !0,
		stages: [
			2,
			1,
			3
		],
		ratings: {
			happy: 1,
			military: 1
		},
		count: [
			1,
			1,
			1
		],
		effect: "colosseum"
	},
	romanRoads: {
		id: "romanRoads",
		nameKey: "games.throughtheages.cards.romanRoads.name",
		textKey: "games.throughtheages.cards.romanRoads.text",
		kind: "wonder",
		age: 0,
		expansion: !0,
		stages: [
			2,
			1,
			1,
			1
		],
		ratings: {
			civil: 1,
			military: 1
		},
		count: [
			1,
			1,
			1
		],
		effect: "romanRoads"
	},
	stonehenge: {
		id: "stonehenge",
		nameKey: "games.throughtheages.cards.stonehenge.name",
		textKey: "games.throughtheages.cards.stonehenge.text",
		kind: "wonder",
		age: 0,
		expansion: !0,
		stages: [
			1,
			2,
			2,
			1
		],
		ratings: {
			culture: 1,
			happy: 1
		},
		count: [
			1,
			1,
			1
		],
		effect: "stonehenge"
	},
	acropolis: {
		id: "acropolis",
		nameKey: "games.throughtheages.cards.acropolis.name",
		textKey: "games.throughtheages.cards.acropolis.text",
		kind: "wonder",
		age: 0,
		expansion: !0,
		stages: [2, 3],
		ratings: {
			culture: 1,
			strength: 1
		},
		count: [
			1,
			1,
			1
		],
		effect: "acropolis"
	},
	basilica: {
		id: "basilica",
		nameKey: "games.throughtheages.cards.basilica.name",
		textKey: "games.throughtheages.cards.basilica.text",
		kind: "wonder",
		age: 1,
		expansion: !1,
		stages: [4, 4],
		ratings: {
			culture: 2,
			happy: 1
		},
		count: [
			1,
			1,
			1
		],
		effect: "basilica"
	},
	tajMahal: {
		id: "tajMahal",
		nameKey: "games.throughtheages.cards.tajMahal.name",
		textKey: "games.throughtheages.cards.tajMahal.text",
		kind: "wonder",
		age: 1,
		expansion: !1,
		stages: [
			2,
			4,
			2
		],
		ratings: {
			culture: 3,
			military: 1
		},
		count: [
			1,
			1,
			1
		],
		effect: "tajMahal"
	},
	carolina: {
		id: "carolina",
		nameKey: "games.throughtheages.cards.carolina.name",
		textKey: "games.throughtheages.cards.carolina.text",
		kind: "wonder",
		age: 1,
		expansion: !1,
		stages: [
			3,
			3,
			3
		],
		ratings: {
			science: 2,
			culture: 1
		},
		count: [
			1,
			1,
			1
		],
		effect: "carolina"
	},
	greatWall: {
		id: "greatWall",
		nameKey: "games.throughtheages.cards.greatWall.name",
		textKey: "games.throughtheages.cards.greatWall.text",
		kind: "wonder",
		age: 1,
		expansion: !1,
		stages: [
			2,
			2,
			3,
			2
		],
		ratings: {
			culture: 1,
			happy: 1
		},
		count: [
			1,
			1,
			1
		],
		effect: "greatWall"
	},
	machuPicchu: {
		id: "machuPicchu",
		nameKey: "games.throughtheages.cards.machuPicchu.name",
		textKey: "games.throughtheages.cards.machuPicchu.text",
		kind: "wonder",
		age: 1,
		expansion: !0,
		stages: [
			2,
			3,
			4
		],
		ratings: { military: 1 },
		count: [
			1,
			1,
			1
		],
		effect: "machuPicchu"
	},
	himeji: {
		id: "himeji",
		nameKey: "games.throughtheages.cards.himeji.name",
		textKey: "games.throughtheages.cards.himeji.text",
		kind: "wonder",
		age: 1,
		expansion: !0,
		stages: [4, 5],
		ratings: {
			culture: 2,
			strength: 2
		},
		count: [
			1,
			1,
			1
		],
		effect: "himeji"
	},
	forbiddenCity: {
		id: "forbiddenCity",
		nameKey: "games.throughtheages.cards.forbiddenCity.name",
		textKey: "games.throughtheages.cards.forbiddenCity.text",
		kind: "wonder",
		age: 1,
		expansion: !0,
		stages: [
			1,
			3,
			3,
			1
		],
		ratings: { civil: 1 },
		count: [
			1,
			1,
			1
		],
		effect: "forbiddenCity"
	},
	silkRoad: {
		id: "silkRoad",
		nameKey: "games.throughtheages.cards.silkRoad.name",
		textKey: "games.throughtheages.cards.silkRoad.text",
		kind: "wonder",
		age: 1,
		expansion: !0,
		stages: [
			2,
			1,
			1,
			2
		],
		ratings: {
			culture: 2,
			science: 1
		},
		count: [
			1,
			1,
			1
		],
		effect: "silkRoad"
	},
	oceanLiner: {
		id: "oceanLiner",
		nameKey: "games.throughtheages.cards.oceanLiner.name",
		textKey: "games.throughtheages.cards.oceanLiner.text",
		kind: "wonder",
		age: 2,
		expansion: !1,
		stages: [
			4,
			2,
			4
		],
		ratings: {},
		count: [
			1,
			1,
			1
		],
		effect: "oceanLiner"
	},
	kremlin: {
		id: "kremlin",
		nameKey: "games.throughtheages.cards.kremlin.name",
		textKey: "games.throughtheages.cards.kremlin.text",
		kind: "wonder",
		age: 2,
		expansion: !1,
		stages: [
			4,
			4,
			4
		],
		ratings: {
			culture: 2,
			happy: -1,
			civil: 1,
			military: 1
		},
		count: [
			1,
			1,
			1
		],
		effect: "kremlin"
	},
	eiffel: {
		id: "eiffel",
		nameKey: "games.throughtheages.cards.eiffel.name",
		textKey: "games.throughtheages.cards.eiffel.text",
		kind: "wonder",
		age: 2,
		expansion: !1,
		stages: [
			3,
			7,
			3
		],
		ratings: {
			culture: 4,
			happy: 1
		},
		count: [
			1,
			1,
			1
		],
		effect: "eiffel"
	},
	railroad: {
		id: "railroad",
		nameKey: "games.throughtheages.cards.railroad.name",
		textKey: "games.throughtheages.cards.railroad.text",
		kind: "wonder",
		age: 2,
		expansion: !1,
		stages: [
			3,
			3,
			3,
			3
		],
		ratings: { strength: 4 },
		count: [
			1,
			1,
			1
		],
		effect: "railroad"
	},
	harvard: {
		id: "harvard",
		nameKey: "games.throughtheages.cards.harvard.name",
		textKey: "games.throughtheages.cards.harvard.text",
		kind: "wonder",
		age: 2,
		expansion: !0,
		stages: [
			3,
			3,
			5
		],
		ratings: {
			culture: 1,
			science: 3
		},
		count: [
			1,
			1,
			1
		],
		effect: "harvard"
	},
	suez: {
		id: "suez",
		nameKey: "games.throughtheages.cards.suez.name",
		textKey: "games.throughtheages.cards.suez.text",
		kind: "wonder",
		age: 2,
		expansion: !0,
		stages: [
			4,
			3,
			2,
			2
		],
		ratings: {},
		count: [
			1,
			1,
			1
		],
		effect: "suez"
	},
	louvre: {
		id: "louvre",
		nameKey: "games.throughtheages.cards.louvre.name",
		textKey: "games.throughtheages.cards.louvre.text",
		kind: "wonder",
		age: 2,
		expansion: !0,
		stages: [
			4,
			5,
			4
		],
		ratings: { culture: 2 },
		count: [
			1,
			1,
			1
		],
		effect: "louvre"
	},
	liberty: {
		id: "liberty",
		nameKey: "games.throughtheages.cards.liberty.name",
		textKey: "games.throughtheages.cards.liberty.text",
		kind: "wonder",
		age: 2,
		expansion: !0,
		stages: [7, 5],
		ratings: { civil: 3 },
		count: [
			1,
			1,
			1
		],
		effect: "liberty"
	},
	hollywood: {
		id: "hollywood",
		nameKey: "games.throughtheages.cards.hollywood.name",
		textKey: "games.throughtheages.cards.hollywood.text",
		kind: "wonder",
		age: 3,
		expansion: !1,
		stages: [
			5,
			6,
			5
		],
		ratings: {},
		count: [
			1,
			1,
			1
		],
		effect: "hollywood"
	},
	internet: {
		id: "internet",
		nameKey: "games.throughtheages.cards.internet.name",
		textKey: "games.throughtheages.cards.internet.text",
		kind: "wonder",
		age: 3,
		expansion: !1,
		stages: [
			2,
			3,
			4,
			3,
			2
		],
		ratings: {},
		count: [
			1,
			1,
			1
		],
		effect: "internet"
	},
	spaceFlight: {
		id: "spaceFlight",
		nameKey: "games.throughtheages.cards.spaceFlight.name",
		textKey: "games.throughtheages.cards.spaceFlight.text",
		kind: "wonder",
		age: 3,
		expansion: !1,
		stages: [
			1,
			2,
			4,
			9
		],
		ratings: {},
		count: [
			1,
			1,
			1
		],
		effect: "spaceFlight"
	},
	fastFood: {
		id: "fastFood",
		nameKey: "games.throughtheages.cards.fastFood.name",
		textKey: "games.throughtheages.cards.fastFood.text",
		kind: "wonder",
		age: 3,
		expansion: !1,
		stages: [
			4,
			4,
			4,
			4
		],
		ratings: {},
		count: [
			1,
			1,
			1
		],
		effect: "fastFood"
	},
	empireState: {
		id: "empireState",
		nameKey: "games.throughtheages.cards.empireState.name",
		textKey: "games.throughtheages.cards.empireState.text",
		kind: "wonder",
		age: 3,
		expansion: !0,
		stages: [17],
		ratings: {},
		count: [
			1,
			1,
			1
		],
		effect: "empireState"
	},
	unitedNations: {
		id: "unitedNations",
		nameKey: "games.throughtheages.cards.unitedNations.name",
		textKey: "games.throughtheages.cards.unitedNations.text",
		kind: "wonder",
		age: 3,
		expansion: !0,
		stages: [8, 8],
		ratings: {},
		count: [
			1,
			1,
			1
		],
		effect: "unitedNations"
	},
	manhattan: {
		id: "manhattan",
		nameKey: "games.throughtheages.cards.manhattan.name",
		textKey: "games.throughtheages.cards.manhattan.text",
		kind: "wonder",
		age: 3,
		expansion: !0,
		stages: [
			4,
			6,
			4
		],
		ratings: { strength: 13 },
		count: [
			1,
			1,
			1
		],
		effect: "manhattan"
	},
	redCross: {
		id: "redCross",
		nameKey: "games.throughtheages.cards.redCross.name",
		textKey: "games.throughtheages.cards.redCross.text",
		kind: "wonder",
		age: 3,
		expansion: !0,
		stages: [
			3,
			3,
			3,
			3,
			3
		],
		ratings: {},
		count: [
			1,
			1,
			1
		],
		effect: "redCross"
	},
	urbanGrowth0: {
		id: "urbanGrowth0",
		nameKey: "games.throughtheages.cards.urbanGrowth0.name",
		textKey: "games.throughtheages.cards.urbanGrowth0.text",
		kind: "action",
		age: 0,
		effect: "urbanGrowth",
		amount: 1,
		count: [
			2,
			2,
			2
		]
	},
	richLand0: {
		id: "richLand0",
		nameKey: "games.throughtheages.cards.richLand0.name",
		textKey: "games.throughtheages.cards.richLand0.text",
		kind: "action",
		age: 0,
		effect: "richLand",
		amount: 1,
		count: [
			2,
			2,
			2
		]
	},
	frugality0: {
		id: "frugality0",
		nameKey: "games.throughtheages.cards.frugality0.name",
		textKey: "games.throughtheages.cards.frugality0.text",
		kind: "action",
		age: 0,
		effect: "frugality",
		amount: 1,
		count: [
			2,
			2,
			2
		]
	},
	engineeringGenius0: {
		id: "engineeringGenius0",
		nameKey: "games.throughtheages.cards.engineeringGenius0.name",
		textKey: "games.throughtheages.cards.engineeringGenius0.text",
		kind: "action",
		age: 0,
		effect: "engineeringGenius",
		amount: 2,
		count: [
			1,
			1,
			1
		]
	},
	stockpile0: {
		id: "stockpile0",
		nameKey: "games.throughtheages.cards.stockpile0.name",
		textKey: "games.throughtheages.cards.stockpile0.text",
		kind: "action",
		age: 0,
		effect: "stockpile",
		amount: 1,
		count: [
			1,
			1,
			1
		]
	},
	culturalHeritage0: {
		id: "culturalHeritage0",
		nameKey: "games.throughtheages.cards.culturalHeritage0.name",
		textKey: "games.throughtheages.cards.culturalHeritage0.text",
		kind: "action",
		age: 0,
		effect: "culturalHeritage",
		amount: 1,
		count: [
			1,
			1,
			1
		],
		gain: {
			science: 1,
			culture: 4
		}
	},
	patriotism0: {
		id: "patriotism0",
		nameKey: "games.throughtheages.cards.patriotism0.name",
		textKey: "games.throughtheages.cards.patriotism0.text",
		kind: "action",
		age: 0,
		effect: "patriotism",
		amount: 1,
		count: [
			1,
			1,
			1
		]
	},
	urbanGrowth1: {
		id: "urbanGrowth1",
		nameKey: "games.throughtheages.cards.urbanGrowth1.name",
		textKey: "games.throughtheages.cards.urbanGrowth1.text",
		kind: "action",
		age: 1,
		effect: "urbanGrowth",
		amount: 2,
		count: [
			2,
			2,
			2
		]
	},
	richLand1: {
		id: "richLand1",
		nameKey: "games.throughtheages.cards.richLand1.name",
		textKey: "games.throughtheages.cards.richLand1.text",
		kind: "action",
		age: 1,
		effect: "richLand",
		amount: 2,
		count: [
			2,
			2,
			2
		]
	},
	frugality1: {
		id: "frugality1",
		nameKey: "games.throughtheages.cards.frugality1.name",
		textKey: "games.throughtheages.cards.frugality1.text",
		kind: "action",
		age: 1,
		effect: "frugality",
		amount: 2,
		count: [
			2,
			2,
			2
		]
	},
	engineeringGenius1: {
		id: "engineeringGenius1",
		nameKey: "games.throughtheages.cards.engineeringGenius1.name",
		textKey: "games.throughtheages.cards.engineeringGenius1.text",
		kind: "action",
		age: 1,
		effect: "engineeringGenius",
		amount: 3,
		count: [
			1,
			1,
			1
		]
	},
	culturalHeritage1: {
		id: "culturalHeritage1",
		nameKey: "games.throughtheages.cards.culturalHeritage1.name",
		textKey: "games.throughtheages.cards.culturalHeritage1.text",
		kind: "action",
		age: 1,
		effect: "culturalHeritage",
		amount: 2,
		count: [
			1,
			1,
			1
		]
	},
	patriotism1: {
		id: "patriotism1",
		nameKey: "games.throughtheages.cards.patriotism1.name",
		textKey: "games.throughtheages.cards.patriotism1.text",
		kind: "action",
		age: 1,
		effect: "patriotism",
		amount: 2,
		count: [
			1,
			1,
			1
		]
	},
	breakthrough1: {
		id: "breakthrough1",
		nameKey: "games.throughtheages.cards.breakthrough1.name",
		textKey: "games.throughtheages.cards.breakthrough1.text",
		kind: "action",
		age: 1,
		effect: "breakthrough",
		amount: 2,
		count: [
			2,
			2,
			2
		]
	},
	reserves1: {
		id: "reserves1",
		nameKey: "games.throughtheages.cards.reserves1.name",
		textKey: "games.throughtheages.cards.reserves1.text",
		kind: "action",
		age: 1,
		effect: "reserves",
		amount: 2,
		count: [
			2,
			2,
			2
		]
	},
	richLand2: {
		id: "richLand2",
		nameKey: "games.throughtheages.cards.richLand2.name",
		textKey: "games.throughtheages.cards.richLand2.text",
		kind: "action",
		age: 2,
		effect: "richLand",
		amount: 3,
		count: [
			1,
			1,
			1
		]
	},
	frugality2: {
		id: "frugality2",
		nameKey: "games.throughtheages.cards.frugality2.name",
		textKey: "games.throughtheages.cards.frugality2.text",
		kind: "action",
		age: 2,
		effect: "frugality",
		amount: 3,
		count: [
			1,
			1,
			1
		]
	},
	engineeringGenius2: {
		id: "engineeringGenius2",
		nameKey: "games.throughtheages.cards.engineeringGenius2.name",
		textKey: "games.throughtheages.cards.engineeringGenius2.text",
		kind: "action",
		age: 2,
		effect: "engineeringGenius",
		amount: 4,
		count: [
			1,
			1,
			1
		]
	},
	patriotism2: {
		id: "patriotism2",
		nameKey: "games.throughtheages.cards.patriotism2.name",
		textKey: "games.throughtheages.cards.patriotism2.text",
		kind: "action",
		age: 2,
		effect: "patriotism",
		amount: 3,
		count: [
			1,
			1,
			1
		]
	},
	revolutionaryIdea2: {
		id: "revolutionaryIdea2",
		nameKey: "games.throughtheages.cards.revolutionaryIdea2.name",
		textKey: "games.throughtheages.cards.revolutionaryIdea2.text",
		kind: "action",
		age: 2,
		effect: "revolutionaryIdea",
		amount: 4,
		count: [
			1,
			1,
			1
		]
	},
	efficientUpgrade2: {
		id: "efficientUpgrade2",
		nameKey: "games.throughtheages.cards.efficientUpgrade2.name",
		textKey: "games.throughtheages.cards.efficientUpgrade2.text",
		kind: "action",
		age: 2,
		effect: "efficientUpgrade",
		amount: 3,
		count: [
			2,
			2,
			2
		]
	},
	breakthrough2: {
		id: "breakthrough2",
		nameKey: "games.throughtheages.cards.breakthrough2.name",
		textKey: "games.throughtheages.cards.breakthrough2.text",
		kind: "action",
		age: 2,
		effect: "breakthrough",
		amount: 3,
		count: [
			2,
			2,
			2
		]
	},
	reserves2: {
		id: "reserves2",
		nameKey: "games.throughtheages.cards.reserves2.name",
		textKey: "games.throughtheages.cards.reserves2.text",
		kind: "action",
		age: 2,
		effect: "reserves",
		amount: 3,
		count: [
			2,
			2,
			2
		]
	},
	nationalism2: {
		id: "nationalism2",
		nameKey: "games.throughtheages.cards.nationalism2.name",
		textKey: "games.throughtheages.cards.nationalism2.text",
		kind: "action",
		age: 2,
		effect: "nationalism",
		amount: 3,
		count: [
			1,
			1,
			1
		]
	},
	urbanGrowth3: {
		id: "urbanGrowth3",
		nameKey: "games.throughtheages.cards.urbanGrowth3.name",
		textKey: "games.throughtheages.cards.urbanGrowth3.text",
		kind: "action",
		age: 3,
		effect: "urbanGrowth",
		amount: 4,
		count: [
			2,
			2,
			2
		]
	},
	engineeringGenius3: {
		id: "engineeringGenius3",
		nameKey: "games.throughtheages.cards.engineeringGenius3.name",
		textKey: "games.throughtheages.cards.engineeringGenius3.text",
		kind: "action",
		age: 3,
		effect: "engineeringGenius",
		amount: 5,
		count: [
			1,
			1,
			1
		]
	},
	patriotism3: {
		id: "patriotism3",
		nameKey: "games.throughtheages.cards.patriotism3.name",
		textKey: "games.throughtheages.cards.patriotism3.text",
		kind: "action",
		age: 3,
		effect: "patriotism",
		amount: 4,
		count: [
			1,
			1,
			1
		]
	},
	revolutionaryIdea3: {
		id: "revolutionaryIdea3",
		nameKey: "games.throughtheages.cards.revolutionaryIdea3.name",
		textKey: "games.throughtheages.cards.revolutionaryIdea3.text",
		kind: "action",
		age: 3,
		effect: "revolutionaryIdea",
		amount: 6,
		count: [
			2,
			2,
			2
		]
	},
	efficientUpgrade3: {
		id: "efficientUpgrade3",
		nameKey: "games.throughtheages.cards.efficientUpgrade3.name",
		textKey: "games.throughtheages.cards.efficientUpgrade3.text",
		kind: "action",
		age: 3,
		effect: "efficientUpgrade",
		amount: 4,
		count: [
			2,
			2,
			2
		]
	},
	reserves3: {
		id: "reserves3",
		nameKey: "games.throughtheages.cards.reserves3.name",
		textKey: "games.throughtheages.cards.reserves3.text",
		kind: "action",
		age: 3,
		effect: "reserves",
		amount: 4,
		count: [
			3,
			3,
			3
		]
	},
	militaryBuildUp3: {
		id: "militaryBuildUp3",
		nameKey: "games.throughtheages.cards.militaryBuildUp3.name",
		textKey: "games.throughtheages.cards.militaryBuildUp3.text",
		kind: "action",
		age: 3,
		effect: "militaryBuildUp",
		amount: 4,
		count: [
			1,
			1,
			1
		]
	},
	endowment3: {
		id: "endowment3",
		nameKey: "games.throughtheages.cards.endowment3.name",
		textKey: "games.throughtheages.cards.endowment3.text",
		kind: "action",
		age: 3,
		effect: "endowment",
		amount: 4,
		count: [
			1,
			1,
			1
		]
	},
	richLand1Extra: {
		id: "richLand1Extra",
		nameKey: "games.throughtheages.cards.richLand1.name",
		textKey: "games.throughtheages.cards.richLand1.text",
		kind: "action",
		age: 1,
		effect: "richLand",
		amount: 2,
		count: [
			0,
			1,
			1
		],
		expansion: !0
	},
	urbanGrowth2Extra: {
		id: "urbanGrowth2Extra",
		nameKey: "games.throughtheages.cards.urbanGrowth2Extra.name",
		textKey: "games.throughtheages.cards.urbanGrowth2Extra.text",
		kind: "action",
		age: 2,
		effect: "urbanGrowth",
		amount: 3,
		expansion: !0,
		count: [
			0,
			1,
			1
		]
	},
	frugality2Extra: {
		id: "frugality2Extra",
		nameKey: "games.throughtheages.cards.frugality2.name",
		textKey: "games.throughtheages.cards.frugality2.text",
		kind: "action",
		age: 2,
		effect: "frugality",
		amount: 3,
		count: [
			0,
			1,
			1
		],
		expansion: !0
	},
	reserves3Extra: {
		id: "reserves3Extra",
		nameKey: "games.throughtheages.cards.reserves3.name",
		textKey: "games.throughtheages.cards.reserves3.text",
		kind: "action",
		age: 3,
		effect: "reserves",
		amount: 4,
		count: [
			0,
			1,
			1
		],
		expansion: !0
	},
	patriotism3Extra: {
		id: "patriotism3Extra",
		nameKey: "games.throughtheages.cards.patriotism3.name",
		textKey: "games.throughtheages.cards.patriotism3.text",
		kind: "action",
		age: 3,
		effect: "patriotism",
		amount: 4,
		count: [
			0,
			1,
			1
		],
		expansion: !0
	},
	revolutionaryIdea3Extra: {
		id: "revolutionaryIdea3Extra",
		nameKey: "games.throughtheages.cards.revolutionaryIdea3.name",
		textKey: "games.throughtheages.cards.revolutionaryIdea3.text",
		kind: "action",
		age: 3,
		effect: "revolutionaryIdea",
		amount: 6,
		count: [
			0,
			1,
			1
		],
		expansion: !0
	},
	legion: {
		id: "legion",
		nameKey: "games.throughtheages.cards.legion.name",
		textKey: "games.throughtheages.cards.legion.text",
		kind: "tactic",
		age: 1,
		units: [
			3,
			0,
			0
		],
		tactic: 2,
		obsolete: 2,
		count: [
			2,
			2,
			2
		],
		expansion: !1
	},
	fightingBand: {
		id: "fightingBand",
		nameKey: "games.throughtheages.cards.fightingBand.name",
		textKey: "games.throughtheages.cards.fightingBand.text",
		kind: "tactic",
		age: 1,
		units: [
			2,
			0,
			0
		],
		tactic: 1,
		obsolete: 1,
		count: [
			2,
			2,
			2
		],
		expansion: !1
	},
	phalanx: {
		id: "phalanx",
		nameKey: "games.throughtheages.cards.phalanx.name",
		textKey: "games.throughtheages.cards.phalanx.text",
		kind: "tactic",
		age: 1,
		units: [
			2,
			1,
			0
		],
		tactic: 3,
		obsolete: 3,
		count: [
			2,
			2,
			2
		],
		expansion: !1
	},
	heavyCavalry: {
		id: "heavyCavalry",
		nameKey: "games.throughtheages.cards.heavyCavalry.name",
		textKey: "games.throughtheages.cards.heavyCavalry.text",
		kind: "tactic",
		age: 1,
		units: [
			0,
			3,
			0
		],
		tactic: 4,
		obsolete: 4,
		count: [
			2,
			2,
			2
		],
		expansion: !1
	},
	medievalArmy: {
		id: "medievalArmy",
		nameKey: "games.throughtheages.cards.medievalArmy.name",
		textKey: "games.throughtheages.cards.medievalArmy.text",
		kind: "tactic",
		age: 1,
		units: [
			1,
			1,
			0
		],
		tactic: 2,
		obsolete: 2,
		count: [
			2,
			2,
			2
		],
		expansion: !1
	},
	napoleonicArmy: {
		id: "napoleonicArmy",
		nameKey: "games.throughtheages.cards.napoleonicArmy.name",
		textKey: "games.throughtheages.cards.napoleonicArmy.text",
		kind: "tactic",
		age: 2,
		units: [
			1,
			1,
			1
		],
		tactic: 7,
		obsolete: 4,
		count: [
			1,
			1,
			1
		],
		expansion: !1
	},
	mobileArtillery: {
		id: "mobileArtillery",
		nameKey: "games.throughtheages.cards.mobileArtillery.name",
		textKey: "games.throughtheages.cards.mobileArtillery.text",
		kind: "tactic",
		age: 2,
		units: [
			0,
			1,
			1
		],
		tactic: 5,
		obsolete: 3,
		count: [
			2,
			2,
			2
		],
		expansion: !1
	},
	fortifications: {
		id: "fortifications",
		nameKey: "games.throughtheages.cards.fortifications.name",
		textKey: "games.throughtheages.cards.fortifications.text",
		kind: "tactic",
		age: 2,
		units: [
			0,
			0,
			2
		],
		tactic: 5,
		obsolete: 3,
		count: [
			1,
			1,
			1
		],
		expansion: !1
	},
	conquistadors: {
		id: "conquistadors",
		nameKey: "games.throughtheages.cards.conquistadors.name",
		textKey: "games.throughtheages.cards.conquistadors.text",
		kind: "tactic",
		age: 2,
		units: [
			1,
			2,
			0
		],
		tactic: 5,
		obsolete: 3,
		count: [
			1,
			1,
			1
		],
		expansion: !1
	},
	defensiveArmy: {
		id: "defensiveArmy",
		nameKey: "games.throughtheages.cards.defensiveArmy.name",
		textKey: "games.throughtheages.cards.defensiveArmy.text",
		kind: "tactic",
		age: 2,
		units: [
			2,
			0,
			1
		],
		tactic: 6,
		obsolete: 3,
		count: [
			1,
			1,
			1
		],
		expansion: !1
	},
	entrenchments: {
		id: "entrenchments",
		nameKey: "games.throughtheages.cards.entrenchments.name",
		textKey: "games.throughtheages.cards.entrenchments.text",
		kind: "tactic",
		age: 3,
		units: [
			1,
			0,
			2
		],
		tactic: 9,
		obsolete: 5,
		count: [
			1,
			1,
			1
		],
		expansion: !1
	},
	shockTroops: {
		id: "shockTroops",
		nameKey: "games.throughtheages.cards.shockTroops.name",
		textKey: "games.throughtheages.cards.shockTroops.text",
		kind: "tactic",
		age: 3,
		units: [
			1,
			3,
			0
		],
		tactic: 11,
		obsolete: 6,
		count: [
			1,
			1,
			1
		],
		expansion: !1
	},
	mechanizedArmy: {
		id: "mechanizedArmy",
		nameKey: "games.throughtheages.cards.mechanizedArmy.name",
		textKey: "games.throughtheages.cards.mechanizedArmy.text",
		kind: "tactic",
		age: 3,
		units: [
			0,
			1,
			2
		],
		tactic: 10,
		obsolete: 5,
		count: [
			2,
			2,
			2
		],
		expansion: !1
	},
	modernArmy: {
		id: "modernArmy",
		nameKey: "games.throughtheages.cards.modernArmy.name",
		textKey: "games.throughtheages.cards.modernArmy.text",
		kind: "tactic",
		age: 3,
		units: [
			2,
			1,
			1
		],
		tactic: 13,
		obsolete: 7,
		count: [
			2,
			2,
			2
		],
		expansion: !1
	},
	hussars: {
		id: "hussars",
		nameKey: "games.throughtheages.cards.hussars.name",
		textKey: "games.throughtheages.cards.hussars.text",
		kind: "tactic",
		age: 2,
		units: [
			0,
			2,
			0
		],
		tactic: 2,
		obsolete: 2,
		count: [
			1,
			1,
			1
		],
		expansion: !0
	},
	positionalArmy: {
		id: "positionalArmy",
		nameKey: "games.throughtheages.cards.positionalArmy.name",
		textKey: "games.throughtheages.cards.positionalArmy.text",
		kind: "tactic",
		age: 3,
		units: [
			2,
			0,
			2
		],
		tactic: 12,
		obsolete: 6,
		count: [
			1,
			1,
			1
		],
		expansion: !0
	},
	bonus1: {
		id: "bonus1",
		nameKey: "games.throughtheages.cards.bonus1.name",
		textKey: "games.throughtheages.cards.bonus1.text",
		kind: "bonus",
		age: 1,
		defense: 2,
		colonize: 1,
		count: [
			6,
			6,
			6
		]
	},
	extraBonus1: {
		id: "extraBonus1",
		nameKey: "games.throughtheages.cards.extraBonus1.name",
		textKey: "games.throughtheages.cards.extraBonus1.text",
		kind: "bonus",
		age: 1,
		defense: 2,
		colonize: 1,
		expansion: !0,
		count: [
			1,
			1,
			1
		]
	},
	bonus2: {
		id: "bonus2",
		nameKey: "games.throughtheages.cards.bonus2.name",
		textKey: "games.throughtheages.cards.bonus2.text",
		kind: "bonus",
		age: 2,
		defense: 4,
		colonize: 2,
		count: [
			6,
			6,
			6
		]
	},
	extraBonus2: {
		id: "extraBonus2",
		nameKey: "games.throughtheages.cards.extraBonus2.name",
		textKey: "games.throughtheages.cards.extraBonus2.text",
		kind: "bonus",
		age: 2,
		defense: 4,
		colonize: 2,
		expansion: !0,
		count: [
			1,
			1,
			1
		]
	},
	bonus3: {
		id: "bonus3",
		nameKey: "games.throughtheages.cards.bonus3.name",
		textKey: "games.throughtheages.cards.bonus3.text",
		kind: "bonus",
		age: 3,
		defense: 6,
		colonize: 3,
		count: [
			6,
			6,
			6
		]
	},
	extraBonus3: {
		id: "extraBonus3",
		nameKey: "games.throughtheages.cards.extraBonus3.name",
		textKey: "games.throughtheages.cards.extraBonus3.text",
		kind: "bonus",
		age: 3,
		defense: 6,
		colonize: 3,
		expansion: !0,
		count: [
			1,
			1,
			1
		]
	},
	devWarfare: {
		id: "devWarfare",
		nameKey: "games.throughtheages.cards.devWarfare.name",
		textKey: "games.throughtheages.cards.devWarfare.text",
		kind: "event",
		age: 0,
		effect: "devWarfare",
		count: [
			1,
			1,
			1
		]
	},
	devReligion: {
		id: "devReligion",
		nameKey: "games.throughtheages.cards.devReligion.name",
		textKey: "games.throughtheages.cards.devReligion.text",
		kind: "event",
		age: 0,
		effect: "devReligion",
		count: [
			1,
			1,
			1
		]
	},
	devAgriculture: {
		id: "devAgriculture",
		nameKey: "games.throughtheages.cards.devAgriculture.name",
		textKey: "games.throughtheages.cards.devAgriculture.text",
		kind: "event",
		age: 0,
		effect: "devAgriculture",
		count: [
			1,
			1,
			1
		]
	},
	devScience: {
		id: "devScience",
		nameKey: "games.throughtheages.cards.devScience.name",
		textKey: "games.throughtheages.cards.devScience.text",
		kind: "event",
		age: 0,
		effect: "devScience",
		count: [
			1,
			1,
			1
		]
	},
	devCrafts: {
		id: "devCrafts",
		nameKey: "games.throughtheages.cards.devCrafts.name",
		textKey: "games.throughtheages.cards.devCrafts.text",
		kind: "event",
		age: 0,
		effect: "devCrafts",
		count: [
			1,
			1,
			1
		]
	},
	devSettlement: {
		id: "devSettlement",
		nameKey: "games.throughtheages.cards.devSettlement.name",
		textKey: "games.throughtheages.cards.devSettlement.text",
		kind: "event",
		age: 0,
		effect: "devSettlement",
		count: [
			1,
			1,
			1
		]
	},
	devPolitics: {
		id: "devPolitics",
		nameKey: "games.throughtheages.cards.devPolitics.name",
		textKey: "games.throughtheages.cards.devPolitics.text",
		kind: "event",
		age: 0,
		effect: "devPolitics",
		count: [
			1,
			1,
			1
		]
	},
	devTrade: {
		id: "devTrade",
		nameKey: "games.throughtheages.cards.devTrade.name",
		textKey: "games.throughtheages.cards.devTrade.text",
		kind: "event",
		age: 0,
		effect: "devTrade",
		count: [
			1,
			1,
			1
		]
	},
	devCivilization: {
		id: "devCivilization",
		nameKey: "games.throughtheages.cards.devCivilization.name",
		textKey: "games.throughtheages.cards.devCivilization.text",
		kind: "event",
		age: 0,
		effect: "devCivilization",
		count: [
			1,
			1,
			1
		]
	},
	devMarkets: {
		id: "devMarkets",
		nameKey: "games.throughtheages.cards.devMarkets.name",
		textKey: "games.throughtheages.cards.devMarkets.text",
		kind: "event",
		age: 0,
		effect: "devMarkets",
		count: [
			1,
			1,
			1
		]
	},
	culturalInfluence: {
		id: "culturalInfluence",
		nameKey: "games.throughtheages.cards.culturalInfluence.name",
		textKey: "games.throughtheages.cards.culturalInfluence.text",
		kind: "event",
		age: 1,
		effect: "culturalInfluence",
		count: [
			1,
			1,
			1
		]
	},
	barbarians: {
		id: "barbarians",
		nameKey: "games.throughtheages.cards.barbarians.name",
		textKey: "games.throughtheages.cards.barbarians.text",
		kind: "event",
		age: 1,
		effect: "barbarians",
		count: [
			1,
			1,
			1
		]
	},
	foray: {
		id: "foray",
		nameKey: "games.throughtheages.cards.foray.name",
		textKey: "games.throughtheages.cards.foray.text",
		kind: "event",
		age: 1,
		effect: "foray",
		count: [
			1,
			1,
			1
		]
	},
	raiders: {
		id: "raiders",
		nameKey: "games.throughtheages.cards.raiders.name",
		textKey: "games.throughtheages.cards.raiders.text",
		kind: "event",
		age: 1,
		effect: "raiders",
		count: [
			1,
			1,
			1
		]
	},
	epidemic: {
		id: "epidemic",
		nameKey: "games.throughtheages.cards.epidemic.name",
		textKey: "games.throughtheages.cards.epidemic.text",
		kind: "event",
		age: 1,
		effect: "epidemic",
		count: [
			1,
			1,
			1
		]
	},
	rats: {
		id: "rats",
		nameKey: "games.throughtheages.cards.rats.name",
		textKey: "games.throughtheages.cards.rats.text",
		kind: "event",
		age: 1,
		effect: "rats",
		count: [
			1,
			1,
			1
		]
	},
	scientificBreakthrough: {
		id: "scientificBreakthrough",
		nameKey: "games.throughtheages.cards.scientificBreakthrough.name",
		textKey: "games.throughtheages.cards.scientificBreakthrough.text",
		kind: "event",
		age: 1,
		effect: "scientificBreakthrough",
		count: [
			1,
			1,
			1
		]
	},
	newDeposits: {
		id: "newDeposits",
		nameKey: "games.throughtheages.cards.newDeposits.name",
		textKey: "games.throughtheages.cards.newDeposits.text",
		kind: "event",
		age: 1,
		effect: "newDeposits",
		count: [
			1,
			1,
			1
		]
	},
	goodHarvest: {
		id: "goodHarvest",
		nameKey: "games.throughtheages.cards.goodHarvest.name",
		textKey: "games.throughtheages.cards.goodHarvest.text",
		kind: "event",
		age: 1,
		effect: "goodHarvest",
		count: [
			1,
			1,
			1
		]
	},
	rebellion: {
		id: "rebellion",
		nameKey: "games.throughtheages.cards.rebellion.name",
		textKey: "games.throughtheages.cards.rebellion.text",
		kind: "event",
		age: 1,
		effect: "rebellion",
		count: [
			1,
			1,
			1
		]
	},
	territorialDispute: {
		id: "territorialDispute",
		nameKey: "games.throughtheages.cards.territorialDispute.name",
		textKey: "games.throughtheages.cards.territorialDispute.text",
		kind: "event",
		age: 1,
		effect: "territorialDispute",
		count: [
			1,
			1,
			1
		]
	},
	crusades: {
		id: "crusades",
		nameKey: "games.throughtheages.cards.crusades.name",
		textKey: "games.throughtheages.cards.crusades.text",
		kind: "event",
		age: 1,
		effect: "crusades",
		count: [
			1,
			1,
			1
		]
	},
	famine: {
		id: "famine",
		nameKey: "games.throughtheages.cards.famine.name",
		textKey: "games.throughtheages.cards.famine.text",
		kind: "event",
		age: 1,
		effect: "famine",
		count: [
			1,
			1,
			1
		]
	},
	enslavement: {
		id: "enslavement",
		nameKey: "games.throughtheages.cards.enslavement.name",
		textKey: "games.throughtheages.cards.enslavement.text",
		kind: "event",
		age: 1,
		effect: "enslavement",
		count: [
			1,
			1,
			1
		]
	},
	immigration: {
		id: "immigration",
		nameKey: "games.throughtheages.cards.immigration.name",
		textKey: "games.throughtheages.cards.immigration.text",
		kind: "event",
		age: 1,
		effect: "immigration",
		count: [
			1,
			1,
			1
		]
	},
	popularization: {
		id: "popularization",
		nameKey: "games.throughtheages.cards.popularization.name",
		textKey: "games.throughtheages.cards.popularization.text",
		kind: "event",
		age: 2,
		effect: "popularization",
		count: [
			1,
			1,
			1
		]
	},
	politicsStrength: {
		id: "politicsStrength",
		nameKey: "games.throughtheages.cards.politicsStrength.name",
		textKey: "games.throughtheages.cards.politicsStrength.text",
		kind: "event",
		age: 2,
		effect: "politicsStrength",
		count: [
			1,
			1,
			1
		]
	},
	independence: {
		id: "independence",
		nameKey: "games.throughtheages.cards.independence.name",
		textKey: "games.throughtheages.cards.independence.text",
		kind: "event",
		age: 2,
		effect: "independence",
		count: [
			1,
			1,
			1
		]
	},
	emigration: {
		id: "emigration",
		nameKey: "games.throughtheages.cards.emigration.name",
		textKey: "games.throughtheages.cards.emigration.text",
		kind: "event",
		age: 2,
		effect: "emigration",
		count: [
			1,
			1,
			1
		]
	},
	crimeWave: {
		id: "crimeWave",
		nameKey: "games.throughtheages.cards.crimeWave.name",
		textKey: "games.throughtheages.cards.crimeWave.text",
		kind: "event",
		age: 2,
		effect: "crimeWave",
		count: [
			1,
			1,
			1
		]
	},
	nationalPride: {
		id: "nationalPride",
		nameKey: "games.throughtheages.cards.nationalPride.name",
		textKey: "games.throughtheages.cards.nationalPride.text",
		kind: "event",
		age: 2,
		effect: "nationalPride",
		count: [
			1,
			1,
			1
		]
	},
	civilUnrest: {
		id: "civilUnrest",
		nameKey: "games.throughtheages.cards.civilUnrest.name",
		textKey: "games.throughtheages.cards.civilUnrest.text",
		kind: "event",
		age: 2,
		effect: "civilUnrest",
		count: [
			1,
			1,
			1
		]
	},
	terrorism: {
		id: "terrorism",
		nameKey: "games.throughtheages.cards.terrorism.name",
		textKey: "games.throughtheages.cards.terrorism.text",
		kind: "event",
		age: 2,
		effect: "terrorism",
		count: [
			1,
			1,
			1
		]
	},
	ravages: {
		id: "ravages",
		nameKey: "games.throughtheages.cards.ravages.name",
		textKey: "games.throughtheages.cards.ravages.text",
		kind: "event",
		age: 2,
		effect: "ravages",
		count: [
			1,
			1,
			1
		]
	},
	prosperity: {
		id: "prosperity",
		nameKey: "games.throughtheages.cards.prosperity.name",
		textKey: "games.throughtheages.cards.prosperity.text",
		kind: "event",
		age: 2,
		effect: "prosperity",
		count: [
			1,
			1,
			1
		]
	},
	iconoclasm: {
		id: "iconoclasm",
		nameKey: "games.throughtheages.cards.iconoclasm.name",
		textKey: "games.throughtheages.cards.iconoclasm.text",
		kind: "event",
		age: 2,
		effect: "iconoclasm",
		count: [
			1,
			1,
			1
		]
	},
	economicProgress: {
		id: "economicProgress",
		nameKey: "games.throughtheages.cards.economicProgress.name",
		textKey: "games.throughtheages.cards.economicProgress.text",
		kind: "event",
		age: 2,
		effect: "economicProgress",
		count: [
			1,
			1,
			1
		]
	},
	internationalAgreement: {
		id: "internationalAgreement",
		nameKey: "games.throughtheages.cards.internationalAgreement.name",
		textKey: "games.throughtheages.cards.internationalAgreement.text",
		kind: "event",
		age: 2,
		effect: "internationalAgreement",
		count: [
			1,
			1,
			1
		]
	},
	colonialism: {
		id: "colonialism",
		nameKey: "games.throughtheages.cards.colonialism.name",
		textKey: "games.throughtheages.cards.colonialism.text",
		kind: "event",
		age: 2,
		effect: "colonialism",
		count: [
			1,
			1,
			1
		]
	},
	happiness: {
		id: "happiness",
		nameKey: "games.throughtheages.cards.happiness.name",
		textKey: "games.throughtheages.cards.happiness.text",
		kind: "event",
		age: 2,
		effect: "happiness",
		count: [
			1,
			1,
			1
		]
	},
	impactPopulation: {
		id: "impactPopulation",
		nameKey: "games.throughtheages.cards.impactPopulation.name",
		textKey: "games.throughtheages.cards.impactPopulation.text",
		kind: "event",
		age: 3,
		effect: "impactPopulation",
		count: [
			1,
			1,
			1
		]
	},
	impactWonders: {
		id: "impactWonders",
		nameKey: "games.throughtheages.cards.impactWonders.name",
		textKey: "games.throughtheages.cards.impactWonders.text",
		kind: "event",
		age: 3,
		effect: "impactWonders",
		count: [
			1,
			1,
			1
		]
	},
	impactColonies: {
		id: "impactColonies",
		nameKey: "games.throughtheages.cards.impactColonies.name",
		textKey: "games.throughtheages.cards.impactColonies.text",
		kind: "event",
		age: 3,
		effect: "impactColonies",
		count: [
			1,
			1,
			1
		]
	},
	impactCompetition: {
		id: "impactCompetition",
		nameKey: "games.throughtheages.cards.impactCompetition.name",
		textKey: "games.throughtheages.cards.impactCompetition.text",
		kind: "event",
		age: 3,
		effect: "impactCompetition",
		count: [
			1,
			1,
			1
		]
	},
	impactAgriculture: {
		id: "impactAgriculture",
		nameKey: "games.throughtheages.cards.impactAgriculture.name",
		textKey: "games.throughtheages.cards.impactAgriculture.text",
		kind: "event",
		age: 3,
		effect: "impactAgriculture",
		count: [
			1,
			1,
			1
		]
	},
	impactProgress: {
		id: "impactProgress",
		nameKey: "games.throughtheages.cards.impactProgress.name",
		textKey: "games.throughtheages.cards.impactProgress.text",
		kind: "event",
		age: 3,
		effect: "impactProgress",
		count: [
			1,
			1,
			1
		]
	},
	impactIndustry: {
		id: "impactIndustry",
		nameKey: "games.throughtheages.cards.impactIndustry.name",
		textKey: "games.throughtheages.cards.impactIndustry.text",
		kind: "event",
		age: 3,
		effect: "impactIndustry",
		count: [
			1,
			1,
			1
		]
	},
	impactScience: {
		id: "impactScience",
		nameKey: "games.throughtheages.cards.impactScience.name",
		textKey: "games.throughtheages.cards.impactScience.text",
		kind: "event",
		age: 3,
		effect: "impactScience",
		count: [
			1,
			1,
			1
		]
	},
	impactTechnology: {
		id: "impactTechnology",
		nameKey: "games.throughtheages.cards.impactTechnology.name",
		textKey: "games.throughtheages.cards.impactTechnology.text",
		kind: "event",
		age: 3,
		effect: "impactTechnology",
		count: [
			1,
			1,
			1
		]
	},
	impactHappiness: {
		id: "impactHappiness",
		nameKey: "games.throughtheages.cards.impactHappiness.name",
		textKey: "games.throughtheages.cards.impactHappiness.text",
		kind: "event",
		age: 3,
		effect: "impactHappiness",
		count: [
			1,
			1,
			1
		]
	},
	impactArchitecture: {
		id: "impactArchitecture",
		nameKey: "games.throughtheages.cards.impactArchitecture.name",
		textKey: "games.throughtheages.cards.impactArchitecture.text",
		kind: "event",
		age: 3,
		effect: "impactArchitecture",
		count: [
			1,
			1,
			1
		]
	},
	impactStrength: {
		id: "impactStrength",
		nameKey: "games.throughtheages.cards.impactStrength.name",
		textKey: "games.throughtheages.cards.impactStrength.text",
		kind: "event",
		age: 3,
		effect: "impactStrength",
		count: [
			1,
			1,
			1
		]
	},
	impactGovernment: {
		id: "impactGovernment",
		nameKey: "games.throughtheages.cards.impactGovernment.name",
		textKey: "games.throughtheages.cards.impactGovernment.text",
		kind: "event",
		age: 3,
		effect: "impactGovernment",
		count: [
			1,
			1,
			1
		]
	},
	impactVariety: {
		id: "impactVariety",
		nameKey: "games.throughtheages.cards.impactVariety.name",
		textKey: "games.throughtheages.cards.impactVariety.text",
		kind: "event",
		age: 3,
		effect: "impactVariety",
		count: [
			1,
			1,
			1
		]
	},
	impactBalance: {
		id: "impactBalance",
		nameKey: "games.throughtheages.cards.impactBalance.name",
		textKey: "games.throughtheages.cards.impactBalance.text",
		kind: "event",
		age: 3,
		effect: "impactBalance",
		count: [
			1,
			1,
			1
		]
	},
	devPlanning: {
		id: "devPlanning",
		nameKey: "games.throughtheages.cards.devPlanning.name",
		textKey: "games.throughtheages.cards.devPlanning.text",
		kind: "event",
		age: 0,
		effect: "devPlanning",
		expansion: !0,
		count: [
			1,
			1,
			1
		]
	},
	darkAges: {
		id: "darkAges",
		nameKey: "games.throughtheages.cards.darkAges.name",
		textKey: "games.throughtheages.cards.darkAges.text",
		kind: "event",
		age: 1,
		effect: "darkAges",
		expansion: !0,
		count: [
			1,
			1,
			1
		]
	},
	knowledgeAncients: {
		id: "knowledgeAncients",
		nameKey: "games.throughtheages.cards.knowledgeAncients.name",
		textKey: "games.throughtheages.cards.knowledgeAncients.text",
		kind: "event",
		age: 1,
		effect: "knowledgeAncients",
		expansion: !0,
		count: [
			1,
			1,
			1
		]
	},
	callArms: {
		id: "callArms",
		nameKey: "games.throughtheages.cards.callArms.name",
		textKey: "games.throughtheages.cards.callArms.text",
		kind: "event",
		age: 1,
		effect: "callArms",
		expansion: !0,
		count: [
			1,
			1,
			1
		]
	},
	armsIndustry: {
		id: "armsIndustry",
		nameKey: "games.throughtheages.cards.armsIndustry.name",
		textKey: "games.throughtheages.cards.armsIndustry.text",
		kind: "event",
		age: 2,
		effect: "armsIndustry",
		expansion: !0,
		count: [
			1,
			1,
			1
		]
	},
	freedomMovement: {
		id: "freedomMovement",
		nameKey: "games.throughtheages.cards.freedomMovement.name",
		textKey: "games.throughtheages.cards.freedomMovement.text",
		kind: "event",
		age: 2,
		effect: "freedomMovement",
		expansion: !0,
		count: [
			1,
			1,
			1
		]
	},
	internationalNegotiations: {
		id: "internationalNegotiations",
		nameKey: "games.throughtheages.cards.internationalNegotiations.name",
		textKey: "games.throughtheages.cards.internationalNegotiations.text",
		kind: "event",
		age: 2,
		effect: "internationalNegotiations",
		expansion: !0,
		count: [
			1,
			1,
			1
		]
	},
	impactEconomy: {
		id: "impactEconomy",
		nameKey: "games.throughtheages.cards.impactEconomy.name",
		textKey: "games.throughtheages.cards.impactEconomy.text",
		kind: "event",
		age: 3,
		effect: "impactEconomy",
		expansion: !0,
		count: [
			1,
			1,
			1
		]
	},
	impactCulture: {
		id: "impactCulture",
		nameKey: "games.throughtheages.cards.impactCulture.name",
		textKey: "games.throughtheages.cards.impactCulture.text",
		kind: "event",
		age: 3,
		effect: "impactCulture",
		expansion: !0,
		count: [
			1,
			1,
			1
		]
	},
	developed1: {
		id: "developed1",
		nameKey: "games.throughtheages.cards.developed1.name",
		textKey: "games.throughtheages.cards.developed1.text",
		kind: "territory",
		age: 1,
		effect: "developed",
		gain: { science: 3 },
		ratings: {
			civil: 1,
			military: 1
		},
		yellow: 0,
		blue: 0,
		count: [
			1,
			1,
			1
		]
	},
	vast1: {
		id: "vast1",
		nameKey: "games.throughtheages.cards.vast1.name",
		textKey: "games.throughtheages.cards.vast1.text",
		kind: "territory",
		age: 1,
		effect: "vast",
		gain: { food: 3 },
		ratings: {},
		yellow: 3,
		blue: 0,
		count: [
			1,
			1,
			1
		]
	},
	wealthy1: {
		id: "wealthy1",
		nameKey: "games.throughtheages.cards.wealthy1.name",
		textKey: "games.throughtheages.cards.wealthy1.text",
		kind: "territory",
		age: 1,
		effect: "wealthy",
		gain: { ore: 5 },
		ratings: {},
		yellow: 0,
		blue: 2,
		count: [
			1,
			1,
			1
		]
	},
	inhabited1: {
		id: "inhabited1",
		nameKey: "games.throughtheages.cards.inhabited1.name",
		textKey: "games.throughtheages.cards.inhabited1.text",
		kind: "territory",
		age: 1,
		effect: "inhabited",
		gain: { population: 1 },
		ratings: {},
		yellow: 2,
		blue: 0,
		count: [
			1,
			1,
			1
		]
	},
	historic1: {
		id: "historic1",
		nameKey: "games.throughtheages.cards.historic1.name",
		textKey: "games.throughtheages.cards.historic1.text",
		kind: "territory",
		age: 1,
		effect: "historic",
		gain: { culture: 6 },
		ratings: { happy: 1 },
		yellow: 0,
		blue: 0,
		count: [
			1,
			1,
			1
		]
	},
	strategic1: {
		id: "strategic1",
		nameKey: "games.throughtheages.cards.strategic1.name",
		textKey: "games.throughtheages.cards.strategic1.text",
		kind: "territory",
		age: 1,
		effect: "strategic",
		gain: { cards: 3 },
		ratings: { strength: 2 },
		yellow: 0,
		blue: 0,
		count: [
			1,
			1,
			1
		]
	},
	developed2: {
		id: "developed2",
		nameKey: "games.throughtheages.cards.developed2.name",
		textKey: "games.throughtheages.cards.developed2.text",
		kind: "territory",
		age: 2,
		effect: "developed",
		gain: { science: 5 },
		ratings: {
			civil: 1,
			military: 1
		},
		yellow: 0,
		blue: 0,
		count: [
			1,
			1,
			1
		]
	},
	vast2: {
		id: "vast2",
		nameKey: "games.throughtheages.cards.vast2.name",
		textKey: "games.throughtheages.cards.vast2.text",
		kind: "territory",
		age: 2,
		effect: "vast",
		gain: { food: 4 },
		ratings: {},
		yellow: 4,
		blue: 0,
		count: [
			1,
			1,
			1
		]
	},
	wealthy2: {
		id: "wealthy2",
		nameKey: "games.throughtheages.cards.wealthy2.name",
		textKey: "games.throughtheages.cards.wealthy2.text",
		kind: "territory",
		age: 2,
		effect: "wealthy",
		gain: { ore: 9 },
		ratings: {},
		yellow: 0,
		blue: 3,
		count: [
			1,
			1,
			1
		]
	},
	inhabited2: {
		id: "inhabited2",
		nameKey: "games.throughtheages.cards.inhabited2.name",
		textKey: "games.throughtheages.cards.inhabited2.text",
		kind: "territory",
		age: 2,
		effect: "inhabited",
		gain: { population: 2 },
		ratings: {},
		yellow: 3,
		blue: 0,
		count: [
			1,
			1,
			1
		]
	},
	historic2: {
		id: "historic2",
		nameKey: "games.throughtheages.cards.historic2.name",
		textKey: "games.throughtheages.cards.historic2.text",
		kind: "territory",
		age: 2,
		effect: "historic",
		gain: { culture: 11 },
		ratings: { happy: 2 },
		yellow: 0,
		blue: 0,
		count: [
			1,
			1,
			1
		]
	},
	strategic2: {
		id: "strategic2",
		nameKey: "games.throughtheages.cards.strategic2.name",
		textKey: "games.throughtheages.cards.strategic2.text",
		kind: "territory",
		age: 2,
		effect: "strategic",
		gain: { cards: 5 },
		ratings: { strength: 4 },
		yellow: 0,
		blue: 0,
		count: [
			1,
			1,
			1
		]
	},
	autonomous2: {
		id: "autonomous2",
		nameKey: "games.throughtheages.cards.autonomous2.name",
		textKey: "games.throughtheages.cards.autonomous2.text",
		kind: "territory",
		age: 2,
		effect: "autonomous",
		yellow: 2,
		blue: 2,
		expansion: !0,
		count: [
			1,
			1,
			1
		]
	},
	plunder1: {
		id: "plunder1",
		nameKey: "games.throughtheages.cards.plunder1.name",
		textKey: "games.throughtheages.cards.plunder1.text",
		kind: "aggression",
		age: 1,
		effect: "plunder",
		amount: 3,
		militaryCost: 1,
		count: [
			2,
			2,
			2
		]
	},
	raid1: {
		id: "raid1",
		nameKey: "games.throughtheages.cards.raid1.name",
		textKey: "games.throughtheages.cards.raid1.text",
		kind: "aggression",
		age: 1,
		effect: "raid",
		amount: 1,
		militaryCost: 1,
		count: [
			2,
			2,
			2
		]
	},
	plunder2: {
		id: "plunder2",
		nameKey: "games.throughtheages.cards.plunder2.name",
		textKey: "games.throughtheages.cards.plunder2.text",
		kind: "aggression",
		age: 2,
		effect: "plunder",
		amount: 5,
		militaryCost: 2,
		count: [
			2,
			2,
			2
		]
	},
	raid2: {
		id: "raid2",
		nameKey: "games.throughtheages.cards.raid2.name",
		textKey: "games.throughtheages.cards.raid2.text",
		kind: "aggression",
		age: 2,
		effect: "raid",
		amount: 2,
		militaryCost: 2,
		count: [
			2,
			2,
			2
		]
	},
	plunder3: {
		id: "plunder3",
		nameKey: "games.throughtheages.cards.plunder3.name",
		textKey: "games.throughtheages.cards.plunder3.text",
		kind: "aggression",
		age: 3,
		effect: "plunder",
		amount: 7,
		militaryCost: 1,
		count: [
			2,
			2,
			2
		]
	},
	raid3: {
		id: "raid3",
		nameKey: "games.throughtheages.cards.raid3.name",
		textKey: "games.throughtheages.cards.raid3.text",
		kind: "aggression",
		age: 3,
		effect: "raid",
		amount: 2,
		militaryCost: 3,
		count: [
			2,
			2,
			2
		]
	},
	enslave1: {
		id: "enslave1",
		nameKey: "games.throughtheages.cards.enslave1.name",
		textKey: "games.throughtheages.cards.enslave1.text",
		kind: "aggression",
		age: 1,
		effect: "enslave",
		militaryCost: 1,
		count: [
			2,
			2,
			2
		]
	},
	spy2: {
		id: "spy2",
		nameKey: "games.throughtheages.cards.spy2.name",
		textKey: "games.throughtheages.cards.spy2.text",
		kind: "aggression",
		age: 2,
		effect: "spy",
		amount: 5,
		militaryCost: 1,
		count: [
			2,
			2,
			2
		]
	},
	infiltrate2: {
		id: "infiltrate2",
		nameKey: "games.throughtheages.cards.infiltrate2.name",
		textKey: "games.throughtheages.cards.infiltrate2.text",
		kind: "aggression",
		age: 2,
		effect: "infiltrate",
		amount: 0,
		militaryCost: 2,
		count: [
			2,
			2,
			2
		]
	},
	annex2: {
		id: "annex2",
		nameKey: "games.throughtheages.cards.annex2.name",
		textKey: "games.throughtheages.cards.annex2.text",
		kind: "aggression",
		age: 2,
		effect: "annex",
		amount: 0,
		militaryCost: 2,
		count: [
			1,
			1,
			1
		]
	},
	intervention3: {
		id: "intervention3",
		nameKey: "games.throughtheages.cards.intervention3.name",
		textKey: "games.throughtheages.cards.intervention3.text",
		kind: "aggression",
		age: 3,
		effect: "intervention",
		amount: 7,
		militaryCost: 2,
		count: [
			4,
			4,
			4
		]
	},
	kidnap1: {
		id: "kidnap1",
		nameKey: "games.throughtheages.cards.kidnap1.name",
		textKey: "games.throughtheages.cards.kidnap1.text",
		kind: "aggression",
		age: 1,
		effect: "kidnap",
		militaryCost: 1,
		expansion: !0,
		count: [
			1,
			1,
			1
		]
	},
	occupy3: {
		id: "occupy3",
		nameKey: "games.throughtheages.cards.occupy3.name",
		textKey: "games.throughtheages.cards.occupy3.text",
		kind: "aggression",
		age: 3,
		effect: "occupy",
		militaryCost: 2,
		expansion: !0,
		count: [
			1,
			1,
			1
		]
	},
	warTerritory2: {
		id: "warTerritory2",
		nameKey: "games.throughtheages.cards.warTerritory2.name",
		textKey: "games.throughtheages.cards.warTerritory2.text",
		kind: "war",
		age: 2,
		effect: "warTerritory",
		militaryCost: 2,
		count: [
			2,
			2,
			2
		]
	},
	warTechnology2: {
		id: "warTechnology2",
		nameKey: "games.throughtheages.cards.warTechnology2.name",
		textKey: "games.throughtheages.cards.warTechnology2.text",
		kind: "war",
		age: 2,
		effect: "warTechnology",
		militaryCost: 2,
		count: [
			2,
			2,
			2
		]
	},
	warCulture3: {
		id: "warCulture3",
		nameKey: "games.throughtheages.cards.warCulture3.name",
		textKey: "games.throughtheages.cards.warCulture3.text",
		kind: "war",
		age: 3,
		effect: "warCulture",
		militaryCost: 3,
		count: [
			6,
			6,
			6
		]
	},
	hybridWar3: {
		id: "hybridWar3",
		nameKey: "games.throughtheages.cards.hybridWar3.name",
		textKey: "games.throughtheages.cards.hybridWar3.text",
		kind: "war",
		age: 3,
		effect: "hybridWar",
		militaryCost: 2,
		expansion: !0,
		count: [
			1,
			1,
			1
		]
	},
	tradeRoutes1: {
		id: "tradeRoutes1",
		nameKey: "games.throughtheages.cards.tradeRoutes1.name",
		textKey: "games.throughtheages.cards.tradeRoutes1.text",
		kind: "pact",
		age: 1,
		effect: "tradeRoutes",
		count: [
			0,
			1,
			1
		],
		expansion: !1
	},
	openBorders1: {
		id: "openBorders1",
		nameKey: "games.throughtheages.cards.openBorders1.name",
		textKey: "games.throughtheages.cards.openBorders1.text",
		kind: "pact",
		age: 1,
		effect: "openBorders",
		count: [
			0,
			1,
			1
		],
		expansion: !1
	},
	protection2: {
		id: "protection2",
		nameKey: "games.throughtheages.cards.protection2.name",
		textKey: "games.throughtheages.cards.protection2.text",
		kind: "pact",
		age: 2,
		effect: "protection",
		count: [
			0,
			1,
			1
		],
		expansion: !1
	},
	internationalTrade2: {
		id: "internationalTrade2",
		nameKey: "games.throughtheages.cards.internationalTrade2.name",
		textKey: "games.throughtheages.cards.internationalTrade2.text",
		kind: "pact",
		age: 2,
		effect: "internationalTrade",
		count: [
			0,
			1,
			1
		],
		expansion: !1
	},
	scientificCooperation2: {
		id: "scientificCooperation2",
		nameKey: "games.throughtheages.cards.scientificCooperation2.name",
		textKey: "games.throughtheages.cards.scientificCooperation2.text",
		kind: "pact",
		age: 2,
		effect: "scientificCooperation",
		count: [
			0,
			1,
			1
		],
		expansion: !1
	},
	supremacy2: {
		id: "supremacy2",
		nameKey: "games.throughtheages.cards.supremacy2.name",
		textKey: "games.throughtheages.cards.supremacy2.text",
		kind: "pact",
		age: 2,
		effect: "supremacy",
		count: [
			0,
			1,
			1
		],
		expansion: !1
	},
	militaryAlliance3: {
		id: "militaryAlliance3",
		nameKey: "games.throughtheages.cards.militaryAlliance3.name",
		textKey: "games.throughtheages.cards.militaryAlliance3.text",
		kind: "pact",
		age: 3,
		effect: "militaryAlliance",
		count: [
			0,
			1,
			1
		],
		expansion: !1
	},
	tourism3: {
		id: "tourism3",
		nameKey: "games.throughtheages.cards.tourism3.name",
		textKey: "games.throughtheages.cards.tourism3.text",
		kind: "pact",
		age: 3,
		effect: "tourism",
		count: [
			0,
			1,
			1
		],
		expansion: !1
	},
	peaceTreaty3: {
		id: "peaceTreaty3",
		nameKey: "games.throughtheages.cards.peaceTreaty3.name",
		textKey: "games.throughtheages.cards.peaceTreaty3.text",
		kind: "pact",
		age: 3,
		effect: "peaceTreaty",
		count: [
			0,
			1,
			1
		],
		expansion: !1
	},
	sovereignty3: {
		id: "sovereignty3",
		nameKey: "games.throughtheages.cards.sovereignty3.name",
		textKey: "games.throughtheages.cards.sovereignty3.text",
		kind: "pact",
		age: 3,
		effect: "sovereignty",
		count: [
			0,
			1,
			1
		],
		expansion: !1
	},
	navalTrade1: {
		id: "navalTrade1",
		nameKey: "games.throughtheages.cards.navalTrade1.name",
		textKey: "games.throughtheages.cards.navalTrade1.text",
		kind: "pact",
		age: 1,
		effect: "navalTrade",
		count: [
			0,
			1,
			1
		],
		expansion: !0
	}
}, b = {
	professionalSports: {
		cost: 7,
		count: [
			1,
			2,
			2
		],
		textKey: "games.throughtheages.cards.professionalSports.revised"
	},
	militaryTheory: {
		count: [
			1,
			2,
			2
		],
		textKey: "games.throughtheages.cards.militaryTheory.revised"
	},
	republic: {
		science: 11,
		revolution: 2,
		count: [
			1,
			2,
			2
		],
		textKey: "games.throughtheages.cards.republic.revised"
	},
	communism: {
		science: 18,
		revolution: 1,
		ratings: {
			civil: 7,
			military: 5,
			urban: 4,
			happy: -1,
			ore: 1
		},
		textKey: "games.throughtheages.cards.communism.revised"
	},
	fundamentalism: {
		science: 16,
		revolution: 5,
		ratings: {
			civil: 6,
			military: 5,
			urban: 4,
			strength: 6,
			science: -2
		},
		textKey: "games.throughtheages.cards.fundamentalism.revised"
	},
	hammurabi: { textKey: "games.throughtheages.cards.hammurabi.revised" },
	caesar: { textKey: "games.throughtheages.cards.caesar.revised" },
	michelangelo: { textKey: "games.throughtheages.cards.michelangelo.revised" },
	shakespeare: { textKey: "games.throughtheages.cards.shakespeare.revised" },
	napoleon: {
		ratings: { military: 2 },
		textKey: "games.throughtheages.cards.napoleon.revised"
	},
	bach: {
		ratings: { culture: 2 },
		textKey: "games.throughtheages.cards.bach.revised"
	},
	gandhi: { textKey: "games.throughtheages.cards.gandhi.revised" },
	colossus: { textKey: "games.throughtheages.cards.colossus.revised" },
	hangingGardens: { textKey: "games.throughtheages.cards.hangingGardens.revised" },
	basilica: {
		stages: [
			1,
			6,
			1
		],
		ratings: {
			culture: 2,
			happy: 2
		},
		textKey: "games.throughtheages.cards.basilica.revised"
	},
	oceanLiner: {
		stages: [
			4,
			1,
			1,
			4
		],
		textKey: "games.throughtheages.cards.oceanLiner.revised"
	},
	railroad: {
		ratings: { strength: 5 },
		textKey: "games.throughtheages.cards.railroad.revised"
	},
	wealthy1: {
		gain: { ore: 6 },
		textKey: "games.throughtheages.cards.wealthy1.revised"
	}
};
function x(e, t) {
	let n = de[e];
	if (!n) throw Error("Unknown card: " + e);
	return t.rebalance && b[e] ? {
		...n,
		...b[e]
	} : n;
}
//#endregion
//#region src/games/throughtheages/economy.ts
function S(e, t, n) {
	return t.wonders.some((t) => (!n || t.id === n) && !t.ruined && t.stages === x(t.id, e.config).stages.length);
}
var C = (e) => e.blueTotal - e.technologies.reduce((e, t) => e + t.blue, 0) - e.wonders.reduce((e, t) => e + t.blue, 0);
function w(e, t, n, r) {
	let i = x(n.id, e.config);
	return r === "food" ? i.category === "farm" ? i.value : 0 : i.category === "mine" ? i.value : i.category === "lab" && (t.leader === "billGates" || t.flags.gatesStorage) ? i.age : 0;
}
function T(e, t, n) {
	return n === "science" || n === "culture" ? t[n] : t.technologies.reduce((r, i) => r + i.blue * w(e, t, i, n), 0);
}
function fe(e, t, n) {
	let r = Array(t + 1);
	r[0] = e.map(() => 0);
	for (let i = 1; i <= t; i++) for (let t = 0; t < e.length; t++) {
		let a = r[i - e[t]];
		if (!a) continue;
		let o = [...a];
		o[t]++;
		let s = o.reduce((e, t) => e + t, 0);
		s <= n && (!r[i] || s < r[i].reduce((e, t) => e + t, 0)) && (r[i] = o);
	}
	return r[t] ?? null;
}
function pe(e, t, n) {
	let r = /* @__PURE__ */ new Map();
	r.set(0, e.map(() => 0));
	for (let i = 0; i < n; i++) {
		let n = /* @__PURE__ */ new Map();
		for (let [i, a] of r) for (let r = 0; r < e.length; r++) if (i + e[r] <= t) {
			let t = [...a];
			t[r]++, n.set(i + e[r], t);
		}
		r.clear();
		for (let [e, t] of n) r.set(e, t);
	}
	let i = Math.max(-1, ...r.keys());
	return i >= 0 ? r.get(i) : null;
}
function E(e, t, n, r) {
	if (r = Math.max(0, Math.floor(r)), n === "science" || n === "culture") return t[n] += r, r;
	let i = t.technologies.filter((r) => w(e, t, r, n) > 0), a = i.map((r) => w(e, t, r, n));
	for (let e = r; e > 0; e--) {
		let n = fe(a, e, C(t));
		if (n) return i.forEach((e, t) => {
			e.blue += n[t];
		}), e;
	}
	return 0;
}
function D(e, t, n, r) {
	let i = t.technologies.filter((r) => w(e, t, r, n) > 0), a = i.map((r) => w(e, t, r, n)), o = i.reduce((e, t, n) => e + t.blue * a[n], 0);
	if (r > o) return null;
	let s = /* @__PURE__ */ new Map();
	s.set("0:0", a.map(() => 0));
	for (let e = 0; e < i.length; e++) for (let t = 0; t < i[e].blue; t++) for (let [t, n] of [...s]) {
		if (n[e] >= i[e].blue) continue;
		let [r, o] = t.split(":").map(Number), c = [...n];
		c[e]++;
		let l = `${r + a[e]}:${Math.max(o, a[e])}`, u = s.get(l);
		(!u || c.reduce((e, t) => e + t, 0) < u.reduce((e, t) => e + t, 0)) && s.set(l, c);
	}
	let c = [...s].map(([e, t]) => ({
		key: e.split(":").map(Number),
		xs: t
	})).filter((e) => e.key[0] >= r).sort((e, t) => e.key[0] - t.key[0] || t.xs.reduce((e, t) => e + t, 0) - e.xs.reduce((e, t) => e + t, 0));
	for (let { key: [e, n], xs: i } of c) {
		let s = C(t) + i.reduce((e, t) => e + t, 0), c = a.map((e) => e <= n ? e : o + 1), l = fe(c, e - r, s);
		if (l) return {
			remove: i,
			change: l
		};
		let u = pe(c, e - r - 1, s);
		if (u) return {
			remove: i,
			change: u
		};
	}
	return null;
}
function O(e, t, n, r) {
	return r <= 0 || (n === "science" || n === "culture" ? t[n] >= r : D(e, t, n, r) !== null);
}
function k(e, t, n, r) {
	if (r = Math.max(0, r), n === "science" || n === "culture") return t[n] < r ? !1 : (t[n] -= r, !0);
	let i = D(e, t, n, r);
	return i ? (t.technologies.filter((r) => w(e, t, r, n) > 0).forEach((e, t) => {
		e.blue += i.change[t] - i.remove[t];
	}), !0) : !1;
}
function A(e, t, n, r) {
	let i = T(e, t, n);
	return k(e, t, n, Math.min(i, Math.max(0, r))), i - T(e, t, n);
}
function me(e, t, n, r, i) {
	let a = A(e, t, r, i);
	return E(e, n, r, a), a;
}
function he(e, t) {
	if (e.turn !== t.rid) return null;
	let n = e.pacts.find((e) => e.id === "tradeRoutes1" && (e.a === t.rid || e.b === t.rid));
	return n ? n.a === t.rid ? "food" : "ore" : null;
}
function ge(e, t, n, r) {
	let i = he(e, t), a = [];
	for (let o = 0; o <= (i && i !== n ? r : 0); o++) !O(e, t, n, r - o) || o && !O(e, t, i, o) || a.push({
		food: n === "food" ? r - o : o,
		ore: n === "ore" ? r - o : o,
		...o ? {
			alternate: o,
			trade: i
		} : {}
	});
	return a;
}
function j(e) {
	return e.yellow > 16 ? 2 : e.yellow > 12 ? 3 : e.yellow > 8 ? 4 : e.yellow > 4 ? 5 : 7;
}
function _e(e) {
	return e.yellow > 16 ? 0 : e.yellow > 12 ? 1 : e.yellow > 8 ? 2 : e.yellow > 4 ? 3 : e.yellow > 0 ? 4 : 6;
}
function ve(e) {
	return [
		16,
		12,
		10,
		8,
		6,
		4,
		2,
		0
	].filter((t) => e.yellow <= t).length;
}
function ye(e) {
	let t = C(e);
	return t > 10 ? 0 : t > 5 ? 2 : t > 0 ? 4 : 6;
}
function be(e, t, n = 1) {
	let r = Math.min(n, t.yellow);
	return t.yellow -= r, t.pool += r, t.leader === "mariaTheresa" && (t.science += r, t.culture += r), r;
}
function M(e, t) {
	let n = t > 0 ? t : -Math.min(-t, e.yellow);
	e.yellow += n, e.yellowTotal += n;
}
function xe(e) {
	e.temporary = {};
}
//#endregion
//#region src/games/throughtheages/model.ts
var Se = [
	"infantry",
	"cavalry",
	"artillery",
	"airforce"
], Ce = [
	"lab",
	"temple",
	"library",
	"theater",
	"arena"
], we = [
	"farm",
	"mine",
	...Ce,
	...Se
];
//#endregion
//#region src/games/throughtheages/stats.ts
function N(e, t, n) {
	return t.technologies.filter((t) => !n || x(t.id, e.config).category === n).reduce((e, t) => e + t.workers, 0);
}
function Te(e, t, n) {
	return t.technologies.filter((t) => t.workers && n.includes(x(t.id, e.config).category)).sort((t, n) => x(n.id, e.config).age - x(t.id, e.config).age)[0];
}
var P = (e) => !!e && Se.includes(e), F = (e) => !!e && Ce.includes(e);
function Ee(e, t) {
	return Math.max(0, ...t.technologies.filter((t) => x(t.id, e.config).category === "construction").map((t) => x(t.id, e.config).age));
}
function De(e, t, n) {
	let r = x(n, e.config), i = r.category, a = r.age, o = r.cost ?? 0;
	return F(i) && (o -= Math.min(a, Ee(e, t))), t.leader === "watt" && (i === "farm" || i === "mine") && (o -= a), t.leader === "shakespeare" && (i === "library" && N(e, t, "theater") || i === "theater" && N(e, t, "library")) && (o -= e.config.rebalance ? 2 : 1), Math.max(0, o);
}
function Oe(e, t, n, r = !1) {
	let i = x(n, e.config), a = r ? i.revolution : i.science;
	t.leader === "watt" && (i.category === "farm" || i.category === "mine") && (a -= i.age), t.leader === "bach" && i.category === "theater" && (a -= 2), S(e, t, "colosseum") && (i.category === "infantry" || i.category === "cavalry") && (a -= i.age), t.leader === "shakespeare" && (i.category === "library" && N(e, t, "theater") || i.category === "theater" && N(e, t, "library")) && (a -= e.config.rebalance ? 3 : 1), t.leader === "gaudi" && F(i.category) && (a -= Ce.filter((n) => n !== i.category && N(e, t, n) > 0).length), S(e, t, "acropolis") && i.kind === "government" && !r && (a -= Ce.reduce((n, r) => n + N(e, t, r), 0));
	for (let n of e.pacts.filter((e) => e.a === t.rid || e.b === t.rid)) x(n.id, e.config).effect === "scientificCooperation" && (a -= 2);
	return Math.max(0, a);
}
function ke(e, t, n) {
	let r = e.tactics.find((e) => e.uid === t.tactic);
	if (!r) return {
		value: 0,
		armies: 0
	};
	let i = x(r.id, e.config), a = [], o = 0;
	for (let r of t.technologies) {
		let i = x(r.id, e.config), s = n ? n[r.id] ?? 0 : r.workers;
		if (!s) continue;
		let c = Se.indexOf(i.category);
		c === 3 ? o += s : c >= 0 ? a.push({
			type: c,
			level: i.age,
			n: s,
			farm: !1
		}) : !n && t.leader === "zizka" && i.category === "farm" && a.push({
			type: 0,
			level: 0,
			n: s,
			farm: !0
		});
	}
	let s = i.units.flatMap((e, t) => Array(e).fill(t)), c = (e) => {
		let n = /* @__PURE__ */ new Map();
		function r(e, o) {
			let c = `${e.join(",")}/${o}`, l = n.get(c);
			if (l) return l;
			let u = {
				value: 0,
				armies: 0
			}, d = /* @__PURE__ */ new Set();
			function f(e, n, c) {
				if (e === s.length) {
					let e = n.join(",");
					if (d.has(e)) return;
					d.add(e);
					let t = i.id === "hussars" ? 2 + c : c <= i.age - 2 ? i.obsolete : i.tactic;
					for (let e of o ? [0, 1] : [0]) {
						let i = r(n, o - e), a = t * (e ? 2 : 1) + i.value;
						(a > u.value || a === u.value && i.armies + 1 > u.armies) && (u = {
							value: a,
							armies: i.armies + 1
						});
					}
					return;
				}
				for (let r = 0; r < a.length; r++) {
					let i = a[r], o = s[e], l = i.type === o || t.leader === "genghis" && i.type === 0 && o === 1 && !i.farm || i.farm && (o === 0 || o === 2);
					if (!n[r] || !l) continue;
					let u = [...n];
					u[r]--, f(e + 1, u, Math.min(c, i.level));
				}
			}
			return f(0, e, 3), n.set(c, u), u;
		}
		return r(e, o);
	}, l = c(a.map((e) => e.n));
	if (t.leader === "dietrich") for (let e = 0; e < a.length; e++) {
		if (a[e].farm) continue;
		let t = a.map((e) => e.n);
		t[e]++;
		let n = c(t);
		(n.value > l.value || n.value === l.value && n.armies > l.armies) && (l = n);
	}
	return l;
}
function Ae(e, t, n) {
	return t.technologies.reduce((t, r) => t + (P(x(r.id, e.config).category) ? (n[r.id] ?? 0) * (x(r.id, e.config).ratings?.strength ?? 0) : 0), 0) + ke(e, t, n).value;
}
function je(e, t, n) {
	let r = x(n.id, e.config), i = { ...r.ratings }, a = r.category, o = r.age, s = Te(e, t, [a])?.id === n.id;
	return t.leader === "darwin" && (a === "temple" && (i.happy = (i.happy ?? 0) - 1), (a === "lab" || a === "library") && (i.culture = (i.culture ?? 0) + 1)), t.leader === "bach" && a === "theater" && (i.culture = (i.culture ?? 0) + 1), t.leader === "dietrich" && a === "theater" && s && (i.happy = (i.happy ?? 0) + 1, i.culture = (i.culture ?? 0) + 1), t.leader === "coubertin" && a === "arena" && (i.culture = (i.culture ?? 0) + 2), t.leader === "sidMeier" && a === "lab" && (i.science = (i.science ?? 0) - 1, i.culture = (i.culture ?? 0) + o), S(e, t, "basilica") && (r.ratings?.happy ?? 0) > 0 && (i.happy = (i.happy ?? 0) + 1), t.leader === "michelangelo" && (e.config.rebalance || a === "temple" || a === "theater") && (i.culture = (i.culture ?? 0) + Math.max(0, i.happy ?? 0)), t.leader === "joan" && a === "temple" && (i.strength = (i.strength ?? 0) + Math.max(0, i.happy ?? 0)), i;
}
function Me(e, t, n = Ce) {
	let r = {}, i = (e, t) => {
		r[e] = (r[e] ?? 0) + t;
	};
	for (let r of t.technologies.filter((t) => n.includes(x(t.id, e.config).category))) for (let [n, a] of Object.entries(je(e, t, r))) i(n, a * r.workers);
	t.leader === "shakespeare" && n.includes("theater") && n.includes("library") && i("culture", Math.min(N(e, t, "library"), N(e, t, "theater")) * 2), t.leader === "gaudi" && i("culture", n.filter((n) => N(e, t, n) > 0).length);
	let a = Te(e, t, ["lab", "library"]);
	a && n.includes(x(a.id, e.config).category) && [
		"daVinci",
		"newton",
		"einstein"
	].includes(t.leader ?? "") && i("science", x(a.id, e.config).age);
	let o = Te(e, t, ["theater"]), s = Te(e, t, ["lab"]);
	if (t.leader === "chaplin" && o && n.includes("theater") && i("culture", je(e, t, o).culture ?? 0), t.leader === "fleming") for (let r of ["theater", "library"]) {
		let a = Te(e, t, [r]);
		a && n.includes(r) && i("culture", x(a.id, e.config).age);
	}
	return t.leader === "curie" && s && n.includes("lab") && i("strength", x(s.id, e.config).age), r;
}
function I(e, t, n = !0) {
	let r = {
		science: 0,
		culture: 0,
		strength: 0,
		happy: 0,
		civil: 0,
		military: 0,
		urban: 0,
		colonize: 0,
		food: 0,
		ore: 0,
		armies: 0
	}, i = (e, t = 1) => {
		for (let n of Object.keys(e ?? {})) r[n] += e[n] * t;
	}, a = S(e, t, "basilica"), o = x(t.government, e.config);
	if (i(o.ratings), a && (o.ratings?.happy ?? 0) > 0 && r.happy++, t.leader) {
		let n = x(t.leader, e.config);
		i(n.ratings), a && (n.ratings?.happy ?? 0) > 0 && r.happy++;
	}
	for (let n of t.technologies) {
		let t = x(n.id, e.config), a = t.category;
		F(a) || (we.includes(a) ? i(t.ratings, n.workers) : i(t.ratings), a === "farm" && (r.food += n.workers * t.value), a === "mine" && (r.ore += n.workers * t.value));
	}
	i(Me(e, t)), t.leader === "billGates" && (r.ore += t.technologies.reduce((t, n) => t + (x(n.id, e.config).category === "lab" ? n.workers * x(n.id, e.config).age : 0), 0));
	for (let n of t.wonders) if (n.stages === x(n.id, e.config).stages.length) {
		if (n.ruined) r.culture += 2;
		else {
			let a = x(n.id, e.config);
			i(a.ratings), S(e, t, "basilica") && n.id !== "basilica" && ((a.ratings?.happy ?? 0) > 0 || n.homer) && r.happy++, t.leader === "michelangelo" && (r.culture += (a.ratings?.happy ?? 0) + +!!n.homer + (S(e, t, "basilica") && n.id !== "basilica" && ((a.ratings?.happy ?? 0) > 0 || n.homer) ? 1 : 0)), n.id === "louvre" && (r.culture += n.blue);
		}
		n.homer && (r.happy++, n.ruined && S(e, t, "basilica") && r.happy++), n.ruined && n.homer && t.leader === "michelangelo" && (r.culture += S(e, t, "basilica") ? 2 : 1);
	}
	for (let n of t.colonies) {
		let t = x(n, e.config);
		i(t.ratings), a && (t.ratings?.happy ?? 0) > 0 && r.happy++;
	}
	if (t.leader === "joan" && (r.strength += (o.ratings?.happy ?? 0) + (a && (o.ratings?.happy ?? 0) > 0 ? 1 : 0)), t.leader === "alexander" && (r.strength += Se.reduce((n, r) => n + N(e, t, r), 0)), S(e, t, "greatWall") && (r.strength += N(e, t, "infantry") + N(e, t, "artillery")), S(e, t, "acropolis") && r.urban++, S(e, t, "romanRoads") && (e.age === 1 ? r.ore++ : e.age === 2 ? r.science++ : e.age > 2 && (r.culture += 2)), S(e, t, "suez") && (r.ore += t.colonies.length), S(e, t, "liberty") && (r.culture += o.age), S(e, t, "railroad")) {
		let n = Te(e, t, ["mine"]);
		n && (r.ore += x(n.id, e.config).value);
	}
	if (S(e, t, "machuPicchu")) for (let n of ["farm", "mine"]) {
		let i = t.technologies.filter((t) => t.workers > 0 && x(t.id, e.config).category === n && x(t.id, e.config).age <= 1).sort((t, n) => x(n.id, e.config).age - x(t.id, e.config).age)[0];
		i && (r[n === "farm" ? "food" : "ore"] += x(i.id, e.config).value);
	}
	if (t.leader === "ashoka") {
		let n = new Set(t.hand.map((t) => {
			let n = x(t.id, e.config);
			return n.kind === "technology" ? P(n.category) ? "military" : F(n.category) ? "urban" : n.category === "farm" || n.category === "mine" ? "production" : "special" : n.kind;
		})).size;
		n >= 2 && r.ore++, n >= 3 && r.food++;
	}
	t.leader === "saladin" && (t.flags.saladin === "civil" ? r.civil++ : t.flags.saladin === "strength" && (r.strength += 2)), t.leader === "napoleon" && (r.strength += Se.filter((n) => N(e, t, n) > 0).length * 2), t.leader === "cook" && t.colonies.length && (r.culture += t.colonies.length + 1);
	let s = Te(e, t, ["lab"]), c = Te(e, t, ["mine"]);
	t.leader === "curie" && (r.science += c ? x(c.id, e.config).age : 0, r.culture += Math.max(s ? x(s.id, e.config).age : 0, c ? x(c.id, e.config).age : 0)), t.leader === "jobs" && s && (r.happy += x(s.id, e.config).age + (a && x(s.id, e.config).age > 0 ? 1 : 0));
	for (let n of e.pacts.filter((e) => e.a === t.rid || e.b === t.rid)) {
		let i = x(n.id, e.config).effect, o = n.a === t.rid, s = e.players[o ? n.b : n.a];
		i === "openBorders" && r.military++, i === "protection" && (o ? r.culture++ : (r.strength += 4, r.culture--)), i === "internationalTrade" && r[o ? "ore" : "food"]++, i === "supremacy" && (r.ore += o ? 1 : -1), i === "militaryAlliance" && (r.strength += 3), i === "tourism" && (r.culture += s.wonders.filter((t) => t.stages === x(t.id, e.config).stages.length).length), i === "peaceTreaty" && r.culture++, i === "sovereignty" && (r.culture += o ? 2 : -2), i === "navalTrade" && o && (r.happy += a ? 2 : 1);
	}
	for (let n of e.wars) n.id === "hybridWar3" && (n.a === t.rid || n.b === t.rid) && (r.happy -= 2);
	let l = ke(e, t);
	r.strength += l.value, r.armies = l.armies, e.tactics.some((e) => e.uid === t.tactic && e.sun) && r.strength++, t.leader === "zizka" && (r.culture += l.armies);
	for (let e of Object.keys(r)) (n || e !== "ore" && e !== "food") && (r[e] = Math.max(0, r[e]));
	return r.happy = Math.min(8, r.happy), r;
}
function Ne(e, t) {
	return Math.max(0, ve(t) - I(e, t).happy - (S(e, t, "forbiddenCity") ? 2 : 0));
}
function Pe(e, t) {
	let n = e.order.indexOf(e.turn), r = [...e.order.slice(n), ...e.order.slice(0, n)].filter((t) => !e.players[t].resigned), i = new Map(r.map((e, t) => [e, t]));
	return r.sort((n, r) => t(e.players[r]) - t(e.players[n]) || i.get(n) - i.get(r));
}
function Fe(e, t = e.order.filter((t) => !e.players[t].resigned).length === 2 ? 1 : 2) {
	return Pe(e, (t) => I(e, t).strength + (t.leader === "nostradamus" ? 3 : 0)).slice(-t);
}
//#endregion
//#region src/games/throughtheages/core.ts
var L = (e) => e.order.filter((t) => !e.players[t].resigned);
function Ie(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function Le(e, t) {
	return {
		id: t,
		uid: `c${e.serial++}`,
		taken: -1
	};
}
var R = (e, t) => {
	e.log.push(t);
}, Re = (e, ...t) => {
	e.queue.push(...t);
}, z = (e, ...t) => {
	e.queue.unshift(...t);
}, ze = (e, t, n = !1) => I(e, t)[n ? "military" : "civil"] + +!!S(e, t, "alexandria");
function B(e, t, n) {
	let r = I(e, t);
	t.civil = Math.min(r.civil + (t.temporary.extraCivil ?? 0), t.civil + Math.max(0, r.civil - n.civil)), t.military = Math.min(r.military + (t.temporary.extraMilitary ?? 0), t.military + Math.max(0, r.military - n.military));
}
function Be(e, t, n) {
	t.civil = Math.min(I(e, t).civil + (t.temporary.extraCivil ?? 0), t.civil + n);
}
function Ve(e, t, n) {
	let r = t === "civil" ? "extraCivil" : "extraMilitary";
	e.temporary[r] = Math.max(0, (e.temporary[r] ?? 0) - n), e[t] -= n;
}
function He(e, t, n, r = e.age) {
	if (!(r < 1 || r > 3)) for (let i = 0; i < n; i++) {
		e.militaryDecks[r].length || (e.militaryDecks[r] = Ie(e, e.militaryDiscard[r]), e.militaryDiscard[r] = []);
		let n = e.militaryDecks[r].shift();
		n && t.militaryHand.push(n);
	}
}
function Ue(e, t, n) {
	let r = t.militaryHand.findIndex((e) => e.uid === n);
	if (r < 0) return;
	let [i] = t.militaryHand.splice(r, 1);
	return e.militaryDiscard[x(i.id, e.config).age].push(i), i;
}
function We(e, t) {
	return e.hand.splice(e.hand.findIndex((e) => e.uid === t), 1)[0];
}
function Ge(e, t, n) {
	let r = x(n, e.config);
	return r.kind === "wonder" ? !t.wonders.some((t) => !t.ruined && t.stages < x(t.id, e.config).stages.length) : t.hand.length >= ze(e, t) || (r.kind === "technology" || r.kind === "government") && (t.hand.some((e) => e.id === n) || t.technologies.some((e) => e.id === n) || t.government === n) ? !1 : r.kind !== "leader" || !t.takenLeaders.includes(r.age);
}
function Ke(e, t, n, r = !0) {
	let i = x(n.id, e.config);
	i.kind === "wonder" ? (t.wonders.push({
		id: i.id,
		stages: 0,
		blue: 0,
		ruined: !1,
		homer: !1
	}), t.leader === "michelangelo" && e.config.rebalance && E(e, t, "ore", 1)) : (n.taken = e.phase === "action" ? e.revision : -1, t.hand.push(n), i.kind === "leader" && t.takenLeaders.push(i.age), r && (i.kind === "technology" || i.kind === "government") && t.leader === "aristotle" && t.science++);
}
function qe(e, t, n = !1) {
	let r = t.leader;
	if (r) {
		if (r === "confucius" && t.science++, r === "sunTzu") {
			let n = e.tactics.find((e) => e.uid === t.tactic);
			n && (n.sun = !0);
		}
		if (r === "billGates" && (t.culture += N(e, t, "lab") ? t.technologies.reduce((t, n) => t + (x(n.id, e.config).category === "lab" ? n.workers * x(n.id, e.config).age : 0), 0) : 0, t.flags.gatesStorage = !0), r === "watt") {
			let n = {
				...Ze(e, t, "food"),
				...Ze(e, t, "ore")
			};
			t.culture += Math.max(0, ...t.technologies.filter((t) => ["farm", "mine"].includes(x(t.id, e.config).category)).map((t) => (n[t.id] ?? 0) * x(t.id, e.config).value));
		}
		r === "nobel" && n && (e.nobel = !0), r === "saladin" && delete t.flags.saladin, r === "homer" && delete t.temporary.homerOre, r === "cleopatra" && delete t.temporary.cleopatraOre, t.leader = null;
	}
}
function Je(e, t, n, r = !0) {
	let i = I(e, t), a = x(n, e.config);
	if (t.colonies.push(n), M(t, a.yellow ?? 0), t.blueTotal += a.blue ?? 0, B(e, t, i), r) {
		for (let [n, r] of Object.entries(a.gain ?? {})) n === "population" ? z(e, {
			kind: "population",
			rid: t.rid,
			n: r
		}) : n === "cards" ? He(e, t, r) : E(e, t, n, r);
		n === "autonomous2" && z(e, {
			kind: "autonomous",
			rid: t.rid,
			card: n
		});
	}
}
function Ye(e, t, n) {
	let r = x(n, e.config), i = I(e, t);
	t.colonies.splice(t.colonies.indexOf(n), 1), M(t, -(r.yellow ?? 0)), Xe(e, t, r.blue ?? 0), B(e, t, i);
}
function Xe(e, t, n) {
	n = Math.min(n, t.blueTotal);
	let r = Math.max(0, n - C(t));
	t.blueTotal -= n, r && z(e, {
		kind: "removeBlue",
		rid: t.rid,
		n: r
	});
}
function Ze(e, t, n) {
	let r = {};
	for (let i of t.technologies) {
		let a = x(i.id, e.config);
		(n === "food" && a.category === "farm" || n === "ore" && (a.category === "mine" || t.leader === "billGates" && a.category === "lab" && a.age > 0)) && (r[i.id] = i.workers);
	}
	let i = (n, r = !1) => t.technologies.filter((t) => t.workers && x(t.id, e.config).category === n && (!r || x(t.id, e.config).age <= 1)).sort((t, n) => x(n.id, e.config).age - x(t.id, e.config).age)[0];
	if (S(e, t, "machuPicchu")) {
		let e = i(n === "food" ? "farm" : "mine", !0);
		e && r[e.id]++;
	}
	if (n === "ore" && S(e, t, "railroad")) {
		let e = i("mine");
		e && r[e.id]++;
	}
	return r;
}
function Qe(e, t, n) {
	let r = Ze(e, t, n), i = Object.entries(r).reduce((r, [i, a]) => r + a * w(e, t, t.technologies.find((e) => e.id === i), n), 0), a = I(e, t, !1)[n] - i, o = t.technologies.filter((e) => r[e.id]).sort((r, i) => w(e, t, i, n) - w(e, t, r, n));
	for (let e of o) e.blue += Math.min(r[e.id], C(t));
	z(e, {
		kind: "productionBonus",
		rid: t.rid,
		resource: n,
		n: a
	});
}
function $e(e) {
	return {
		rid: e,
		hand: [],
		militaryHand: [],
		technologies: [
			{
				id: "agriculture",
				workers: 2,
				blue: 0
			},
			{
				id: "bronze",
				workers: 2,
				blue: 0
			},
			{
				id: "philosophy",
				workers: 1,
				blue: 0
			},
			{
				id: "religion",
				workers: 0,
				blue: 0
			},
			{
				id: "warriors",
				workers: 1,
				blue: 0
			}
		],
		government: "despotism",
		leader: null,
		wonders: [],
		colonies: [],
		tactic: null,
		takenLeaders: [],
		yellow: 18,
		yellowTotal: 25,
		blueTotal: 16,
		pool: 1,
		science: 0,
		culture: 0,
		civil: 0,
		military: 0,
		resigned: !1,
		flags: {},
		temporary: {},
		final: {}
	};
}
function et(e, t, n) {
	let r = {
		config: e,
		seed: n,
		cursor: 0,
		serial: 0,
		revision: 0,
		age: 0,
		round: 1,
		turn: "",
		order: [],
		phase: "action",
		players: Object.fromEntries(t.map((e) => [e, $e(e)])),
		row: [],
		civilDecks: [
			[],
			[],
			[],
			[]
		],
		militaryDecks: [
			[],
			[],
			[],
			[]
		],
		militaryDiscard: [
			[],
			[],
			[],
			[]
		],
		events: [],
		future: [],
		past: [],
		unusedAncientEvents: [],
		exposed: "",
		pools: [
			[],
			[],
			[],
			[]
		],
		tactics: [],
		pacts: [],
		wars: [],
		decision: null,
		auction: null,
		queue: [],
		continuation: "action",
		lastRound: null,
		nobel: !1,
		olympics: null,
		knownEvents: {},
		log: []
	};
	r.order = Ie(r, t), r.turn = r.order[0];
	let i = Object.values(de);
	for (let n = 0; n < 4; n++) {
		let a = [];
		for (let o of ["leader", "wonder"]) {
			let s = i.filter((e) => e.age === n && e.kind === o), c = e.leaders === "public" || e.leaders === "secret", l = (o === "leader" ? 6 : 4) + (c && t.length > 2 ? 1 : 0), u = c ? Ie(r, s) : s.filter((t) => !!t.expansion == (e.leaders === "expansion"));
			a.push(...u.slice(0, l).map((e) => e.id));
		}
		r.pools[n] = a;
		for (let o of Ie(r, i.filter((e) => e.age === n && !e.initial))) {
			let i = x(o.id, e), s = [
				"technology",
				"government",
				"action",
				"leader",
				"wonder"
			].includes(i.kind);
			if (i.kind === "leader" || i.kind === "wonder") {
				a.includes(i.id) && r.civilDecks[n].push(Le(r, i.id));
				continue;
			}
			if (i.expansion && !e.militaryExpansion) continue;
			let c = i.count?.[t.length - 2] ?? 1;
			for (let e = 0; e < c; e++) (s ? r.civilDecks[n] : r.militaryDecks[n]).push(Le(r, i.id));
		}
		r.civilDecks[n] = Ie(r, r.civilDecks[n]), r.militaryDecks[n] = Ie(r, r.militaryDecks[n]);
	}
	return r.events = r.militaryDecks[0].splice(0, t.length + 2), r.unusedAncientEvents = r.militaryDecks[0].map((e) => e.id), r.militaryDecks[0] = [], r.row = r.civilDecks[0].splice(0, 13), r.order.forEach((e, t) => {
		r.players[e].civil = t + 1, r.players[e].flags.turnStart = 0;
	}), r;
}
function V(e, t, n, r) {
	let i = t.culture;
	t.culture = Math.max(0, t.culture + r), t.final[n] = (t.final[n] ?? 0) + t.culture - i;
}
function tt(e, t) {
	let n = Ze(e, t, "ore");
	return t.technologies.reduce((t, r) => t + (x(r.id, e.config).category === "mine" ? (n[r.id] ?? 0) * x(r.id, e.config).value : 0), 0);
}
function nt(e, t, n) {
	return t.technologies.reduce((t, r) => t + ((n === "urban" ? F(x(r.id, e.config).category) : n === "military" ? P(x(r.id, e.config).category) : ["farm", "mine"].includes(x(r.id, e.config).category)) ? r.workers : 0), 0);
}
//#endregion
//#region src/games/throughtheages/civil.ts
function rt(e, t, n, r = !1) {
	let i = n.card ? x(n.card, e.config) : void 0;
	if (r) return i && P(i.category) ? ["militaryScience"] : [];
	if (n.resource === "food") return [];
	let a = [];
	return i && P(i.category) && a.push("homerOre", "militaryOre"), (n.type === "wonder" || i && F(i.category)) && a.push("cleopatraOre"), a;
}
function it(e, t, n, r = !1) {
	return Math.max(0, (r ? n.science : n.cost) ?? 0) - Math.min(Math.max(0, (r ? n.science : n.cost) ?? 0), rt(e, t, n, r).reduce((e, n) => e + (t.temporary[n] ?? 0), 0));
}
function at(e, t) {
	return !!t.card && ["lab", "library"].includes(x(t.card, e.config).category) && [
		"take",
		"research",
		"build",
		"upgrade"
	].includes(t.type);
}
function ot(e, t, n) {
	if ((n.civil ?? 0) > t.civil || (n.military ?? 0) > t.military) return !1;
	let r = ct(e, t, n);
	if (r.food < 0 || r.ore < 0 || !O(e, t, "food", r.food) || !O(e, t, "ore", r.ore) || !O(e, t, "science", it(e, t, n, !0))) return !1;
	if (n.type === "research" || n.type === "revolution") {
		for (let n of e.pacts.filter((e) => e.id === "scientificCooperation2" && (e.a === t.rid || e.b === t.rid))) if (e.players[n.a === t.rid ? n.b : n.a].science < 1) return !1;
	}
	return !0;
}
function st(e, t, n, r) {
	let i = {
		...r,
		id: ""
	}, a = (r) => {
		let i = he(e, t), a = ct(e, t, {
			...r,
			alternate: 0
		});
		for (let o = 0; o <= (i ? a[i === "food" ? "ore" : "food"] : 0); o++) {
			let a = o ? {
				...r,
				alternate: o,
				trade: i
			} : r;
			ot(e, t, a) && n.push(a);
		}
	};
	a(i), t.leader === "gutenberg" && !t.temporary.gutenberg && at(e, i) && a({
		...i,
		civil: Math.max(0, (i.civil ?? 0) - 1),
		ability: "gutenberg",
		cost: Math.max(0, (i.cost ?? 0) - +(i.type === "build" || i.type === "upgrade")),
		science: Math.max(0, (i.science ?? 0) - +(i.type === "research"))
	});
}
function ct(e, t, n) {
	let r = (n.resource === "food" ? it(e, t, n) : 0) + (n.foodCost ?? 0), i = n.resource === "food" ? 0 : it(e, t, n);
	return n.trade === "food" && (i -= n.alternate ?? 0, r += n.alternate ?? 0), n.trade === "ore" && (r -= n.alternate ?? 0, i += n.alternate ?? 0), {
		food: r,
		ore: i
	};
}
function lt(e, t, n = "", r = 0) {
	let i = [], a = +!n, o = (n) => st(e, t, i, n);
	if ((!n || n === "frugality" || n === "devCivilization") && t.yellow > 0 && o({
		type: "population",
		civil: a,
		cost: Math.max(0, j(t) - +(t.leader === "moses") - (n === "devCivilization" ? r : 0)),
		resource: "food",
		score: 6
	}), !n || n === "breakthrough" || n === "devCivilization") for (let i of t.hand) {
		let s = x(i.id, e.config);
		if ((s.kind === "technology" || s.kind === "government") && (o({
			type: "research",
			card: i.id,
			source: i.uid,
			civil: a,
			science: Math.max(0, Oe(e, t, i.id) - (n === "devCivilization" ? r : 0)),
			score: s.kind === "government" ? 7 : 5 + s.age
		}), (!n || n === "devCivilization" || n === "breakthrough") && s.kind === "government")) {
			let a = t.leader === "robespierre", s = I(e, t);
			(a ? t.military - (t.temporary.extraMilitary ?? 0) === s.military : t.civil - (t.temporary.extraCivil ?? 0) === s.civil) && o({
				type: "revolution",
				card: i.id,
				source: i.uid,
				civil: a ? 0 : s.civil,
				military: a ? s.military : 0,
				science: Math.max(0, Oe(e, t, i.id, !0) - (n === "devCivilization" ? r : 0)),
				score: 8
			});
		}
	}
	for (let i of t.technologies) {
		let s = x(i.id, e.config);
		if (!we.includes(s.category)) continue;
		let c = P(s.category), l = F(s.category), u = I(e, t);
		if (!(!n || n === "devCivilization" && !c || n === "urbanGrowth" && l || n === "richLand" && ["farm", "mine"].includes(s.category) || n === "efficientUpgrade" && !c || n === "freedomMovement")) continue;
		let d = !l || N(e, t, s.category) < u.urban;
		t.pool > 0 && d && !["efficientUpgrade", "freedomMovement"].includes(n) && o({
			type: "build",
			card: i.id,
			civil: c ? 0 : a,
			military: c ? a : 0,
			cost: Math.max(0, De(e, t, i.id) - r),
			score: s.category === "farm" ? 8 : s.category === "mine" ? 10 : c ? 4 : 6
		});
		for (let u of t.technologies.filter((e) => e.workers > 0)) {
			let f = x(u.id, e.config), p = u.id !== i.id && f.category === s.category && f.age < s.age, m = t.leader === "bach" && !t.temporary.bach && l && s.category === "theater" && F(f.category) && f.category !== "theater" && f.age <= s.age && d, ee = n === "freedomMovement" && u.id !== i.id && we.includes(f.category) && (f.category === s.category || d);
			(p || m || ee) && ((n === "freedomMovement" ? !ee : !p && !m) || o({
				type: "upgrade",
				card: i.id,
				source: u.id,
				civil: c ? 0 : a,
				military: c ? a : 0,
				cost: Math.max(0, De(e, t, i.id) - De(e, t, u.id) - r),
				extra: m ? "bach" : void 0,
				score: s.category === "mine" ? 12 : s.category === "farm" ? 10 : 8
			}));
		}
	}
	if (!n || n === "engineeringGenius") for (let i of L(e)) for (let s of e.players[i].wonders.filter((t) => !t.ruined && t.stages < x(t.id, e.config).stages.length)) {
		let c = x(s.id, e.config), l = i !== t.rid;
		if (l && (c.id !== "redCross" || t.temporary.redCross || n)) continue;
		let u = l || n ? 1 : Ee(e, t) + 1;
		for (let e = 1; e <= Math.min(u, c.stages.length - s.stages); e++) o({
			type: "wonder",
			card: s.id,
			target: i,
			n: e,
			civil: a,
			resource: s.id === "redCross" ? "food" : "ore",
			cost: Math.max(0, c.stages.slice(s.stages, s.stages + e).reduce((e, t) => e + t, 0) - (s.id === "redCross" ? 0 : r)),
			score: 6 + e * 2
		});
	}
	return i;
}
function ut(e, t) {
	let n = [];
	if (e.row.forEach((r, i) => {
		if (!r || !Ge(e, t, r.id)) return;
		let a = x(r.id, e.config), o = i < 5 ? 1 : i < 9 ? 2 : 3;
		a.kind === "wonder" && t.leader !== "michelangelo" && (o += t.wonders.filter((t) => t.stages === x(t.id, e.config).stages.length).length), a.id === "tajMahal" && t.temporary.replacedLeader && (o = Math.max(0, o - 2)), a.id === "mandela" && Ne(e, t) === 0 && (o += 3), (a.kind === "technology" || a.kind === "government") && t.leader === "darwin" && (o = Math.max(1, o - 1)), a.kind === "leader" && t.leader === "hammurabi" && !e.config.rebalance && (o = Math.max(0, o - 1)), st(e, t, n, {
			type: "take",
			source: r.uid,
			card: r.id,
			civil: o,
			score: 3 - o + a.age
		});
	}), n.push({
		id: "",
		type: "end",
		score: -100
	}), e.round === 1) return n;
	n.push(...lt(e, t));
	for (let r of t.hand) {
		let i = x(r.id, e.config);
		if (i.kind === "leader" && st(e, t, n, {
			type: "leader",
			card: r.id,
			source: r.uid,
			civil: 1,
			score: 8
		}), i.kind !== "action" || r.taken >= Number(t.flags.turnStart) && r.taken >= 0 && (!S(e, t, "harvard") || t.temporary.harvard)) continue;
		let a = t.wonders.some((e) => e.id === "silkRoad" && e.stages > 0 && !e.ruined) && !t.temporary.actionCards ? 1 : 0, o = i.amount + a, s = i.effect;
		if ([
			"urbanGrowth",
			"richLand",
			"frugality",
			"engineeringGenius",
			"breakthrough",
			"efficientUpgrade"
		].includes(s)) for (let i of lt(e, t, s, ["frugality", "breakthrough"].includes(s) ? 0 : o)) {
			let a = {
				...i,
				action: r.uid,
				civil: (i.civil ?? 0) + (i.type === "revolution" ? 0 : 1),
				n: i.n,
				score: (i.score ?? 0) + 1
			};
			a.ability === "gutenberg" && (a.civil = Math.max(0, a.civil - 1)), ot(e, t, a) && n.push(a);
		}
		else if (s === "reserves") for (let i of ["food", "ore"]) st(e, t, n, {
			type: "action",
			card: r.id,
			source: r.uid,
			resource: i,
			civil: 1,
			n: o,
			score: T(e, t, i) < 5 ? 7 : 3
		});
		else st(e, t, n, {
			type: "action",
			card: r.id,
			source: r.uid,
			civil: 1,
			n: o,
			score: 6
		});
	}
	for (let r of t.technologies.filter((t) => t.workers > 0 && we.includes(x(t.id, e.config).category))) st(e, t, n, {
		type: "destroy",
		card: r.id,
		civil: +!P(x(r.id, e.config).category),
		military: +!!P(x(r.id, e.config).category),
		score: -10
	});
	if (t.leader === "hammurabi" && !t.temporary.hammurabi && t.military && n.push({
		id: "",
		type: "hammurabi",
		score: 4
	}), t.leader === "barbarossa" && t.yellow > 0) for (let r of t.technologies.filter((t) => P(x(t.id, e.config).category))) {
		let i = Math.max(0, j(t) - 1), a = Math.max(0, De(e, t, r.id) - 1);
		st(e, t, n, {
			type: "barbarossa",
			card: r.id,
			military: 1,
			cost: a,
			foodCost: i,
			score: 8
		});
	}
	if (S(e, t, "oceanLiner") && !t.temporary.liner && t.yellow > 0 && n.push({
		id: "",
		type: "liner",
		card: "oceanLiner",
		score: 14
	}), t.leader === "churchill" && !t.temporary.churchill) for (let e of ["culture", "military"]) n.push({
		id: "",
		type: "churchill",
		card: "churchill",
		extra: e,
		score: e === "culture" ? 6 : 4
	});
	if (!t.temporary.tactic) {
		for (let r of t.militaryHand.filter((t) => x(t.id, e.config).kind === "tactic")) t.military && n.push({
			id: "",
			type: "tactic",
			card: r.id,
			source: r.uid,
			military: 1,
			score: 5
		});
		for (let r of e.tactics.filter((e) => !e.owner && e.uid !== t.tactic)) t.military >= 2 && n.push({
			id: "",
			type: "copyTactic",
			card: r.id,
			source: r.uid,
			military: 2,
			score: 3
		});
	}
	return n;
}
function dt(e, t, n, r = !1) {
	let i = Math.max(0, (r ? n.science : n.cost) ?? 0);
	for (let a of rt(e, t, n, r)) {
		let e = Math.min(i, t.temporary[a] ?? 0);
		e && (t.temporary[a] -= e), i -= e;
	}
	if (r) k(e, t, "science", i);
	else {
		let r = (n.resource === "food" ? i : 0) + (n.foodCost ?? 0), a = n.resource === "food" ? 0 : i;
		n.trade === "food" && (a -= n.alternate ?? 0, r += n.alternate ?? 0), n.trade === "ore" && (r -= n.alternate ?? 0, a += n.alternate ?? 0), k(e, t, "food", r), k(e, t, "ore", a);
	}
}
function ft(e, t, n) {
	let r = x(n, e.config);
	t.temporary.technologies = (t.temporary.technologies ?? 0) + 1, t.leader === "daVinci" && E(e, t, "ore", 1), t.leader === "newton" && Be(e, t, 1), t.leader === "einstein" && (t.culture += 3), t.leader === "jobs" && z(e, {
		kind: "jobs",
		rid: t.rid,
		card: "jobs"
	}), S(e, t, "colosseum") && ["infantry", "cavalry"].includes(r.category) && (t.culture += 2);
	for (let n of e.pacts.filter((e) => e.id === "scientificCooperation2" && (e.a === t.rid || e.b === t.rid))) e.players[n.a === t.rid ? n.b : n.a].science--;
}
function pt(e, t, n) {
	let r = I(e, t);
	n.type === "revolution" ? (t.civil -= n.civil ?? 0, t.military -= n.military ?? 0) : (Ve(t, "civil", n.civil ?? 0), Ve(t, "military", n.military ?? 0)), dt(e, t, n), dt(e, t, n, !0), n.ability === "gutenberg" && (t.temporary.gutenberg = 1, t.culture += 2);
	let i = n.action ? t.hand.find((e) => e.uid === n.action) : n.type === "action" ? t.hand.find((e) => e.uid === n.source) : void 0, a = i ? x(i.id, e.config) : void 0, o = t.wonders.some((e) => e.id === "silkRoad" && e.stages > 0 && !e.ruined) && !t.temporary.actionCards ? 1 : 0;
	switch (i && (i.taken >= Number(t.flags.turnStart) && i.taken >= 0 && (t.temporary.harvard = 1), We(t, i.uid), t.temporary.actionCards = (t.temporary.actionCards ?? 0) + 1, t.flags.kidnap === i.uid && (t.culture += 3, delete t.flags.kidnap), R(e, {
		key: "action",
		rid: t.rid,
		card: i.id
	})), n.type) {
		case "take": {
			let r = e.row.findIndex((e) => e?.uid === n.source), i = e.row[r];
			e.row[r] = null, Ke(e, t, i), R(e, {
				key: "take",
				rid: t.rid,
				card: i.id
			});
			break;
		}
		case "population":
			be(e, t);
			break;
		case "research":
		case "revolution": {
			let i = We(t, n.source), a = x(i.id, e.config);
			t.flags.kidnap === i.uid && (t.culture += 3, delete t.flags.kidnap), a.kind === "government" ? t.government = a.id : (we.includes(a.category) || !t.technologies.some((t) => x(t.id, e.config).category === a.category && x(t.id, e.config).age >= a.age)) && (we.includes(a.category) || (t.technologies = t.technologies.filter((t) => x(t.id, e.config).category !== a.category)), t.technologies.push({
				id: a.id,
				workers: 0,
				blue: 0
			})), B(e, t, r), n.type === "revolution" && (t.leader === "robespierre" ? (t.military = t.temporary.extraMilitary ?? 0, t.culture += 3) : t.civil = t.temporary.extraCivil ?? 0), ft(e, t, a.id), R(e, {
				key: n.type,
				rid: t.rid,
				card: a.id
			});
			break;
		}
		case "leader": {
			let i = We(t, n.source), a = t.leader;
			qe(e, t, !0), t.leader = i.id, t.temporary.replacedLeader = +!!a, i.id === "billGates" && (t.flags.gatesStorage = !0), i.id === "homer" && (t.temporary.homerOre = 1), i.id === "cleopatra" && (t.temporary.cleopatraOre = 1), B(e, t, r), a && a !== "nobel" && (a === "homer" && t.wonders.some((t) => !t.ruined && t.stages === x(t.id, e.config).stages.length) ? z(e, {
				kind: "homer",
				rid: t.rid,
				card: "homer"
			}) : Be(e, t, a === "eleanor" ? 3 : 1)), R(e, {
				key: "leader",
				rid: t.rid,
				card: i.id
			});
			break;
		}
		case "build":
			t.pool--, t.technologies.find((e) => e.id === n.card).workers++;
			break;
		case "upgrade":
			t.technologies.find((e) => e.id === n.source).workers--, t.technologies.find((e) => e.id === n.card).workers++, n.extra === "bach" && (t.temporary.bach = 1);
			break;
		case "destroy":
			t.technologies.find((e) => e.id === n.card).workers--, t.pool++;
			break;
		case "wonder": {
			let r = e.players[n.target], i = r.wonders.find((e) => e.id === n.card), a = x(i.id, e.config), o = I(e, r), s = a.stages.slice(i.stages, i.stages + n.n);
			i.stages += n.n, i.blue += n.n, C(r) < 0 && z(e, {
				kind: "removeBlue",
				rid: r.rid,
				n: -C(r)
			}), r.rid !== t.rid && (t.temporary.redCross = 1), i.id === "redCross" && (t.culture += n.n * 6), i.id === "stonehenge" && (t.culture += s.reduce((e, t) => e + t, 0)), i.stages === a.stages.length && (i.id !== "louvre" && (i.blue = 0), B(e, r, o), Re(e, {
				kind: "wonderComplete",
				rid: r.rid,
				card: i.id
			}), R(e, {
				key: "complete",
				rid: r.rid,
				card: i.id
			}));
			break;
		}
		case "action": {
			let r = a, i = r.amount + o;
			switch (r.effect) {
				case "stockpile":
					E(e, t, "ore", 1 + o), E(e, t, "food", 1 + o);
					break;
				case "culturalHeritage":
					t.science += (r.gain?.science ?? r.amount) + o, t.culture += (r.gain?.culture ?? r.amount) + o;
					break;
				case "reserves":
					E(e, t, n.resource, i);
					break;
				case "revolutionaryIdea":
					t.science += i;
					break;
				case "patriotism":
					t.temporary.militaryOre = (t.temporary.militaryOre ?? 0) + i, t.military += 1 + o, t.temporary.extraMilitary = (t.temporary.extraMilitary ?? 0) + 1 + o;
					break;
				case "militaryBuildUp":
				case "nationalism":
					t.temporary.militaryOre = (t.temporary.militaryOre ?? 0) + L(e).filter((n) => I(e, e.players[n]).strength > I(e, t).strength).length * (r.effect === "militaryBuildUp" ? [
						8,
						5,
						3
					] : [
						5,
						3,
						2
					])[L(e).length - 2] + o;
					break;
				case "endowment": t.culture += L(e).filter((n) => e.players[n].culture > t.culture).length * [
					6,
					3,
					2
				][L(e).length - 2] + o;
			}
			break;
		}
		case "hammurabi":
			t.temporary.hammurabi = 1, Ve(t, "military", 1), t.civil++, t.temporary.extraCivil = (t.temporary.extraCivil ?? 0) + 1;
			break;
		case "barbarossa":
			be(e, t), t.pool--, t.technologies.find((e) => e.id === n.card).workers++;
			break;
		case "liner":
			be(e, t), t.temporary.liner = 1;
			break;
		case "louvre":
			t.wonders.find((e) => e.id === "louvre").blue--, E(e, t, "ore", 2);
			break;
		case "churchill":
			t.temporary.churchill = 1, n.extra === "culture" ? t.culture += 3 : (t.temporary.militaryOre = (t.temporary.militaryOre ?? 0) + 3, t.temporary.militaryScience = (t.temporary.militaryScience ?? 0) + 3);
			break;
		case "tactic": {
			let r = mt(t, n.source);
			e.tactics.push({
				uid: r.uid,
				id: r.id,
				owner: t.rid,
				sun: !1
			}), t.tactic = r.uid, t.temporary.tactic = 1;
			break;
		}
		case "copyTactic": t.tactic = n.source, t.temporary.tactic = 1;
	}
	a?.effect === "frugality" && E(e, t, "food", a.amount + o), a?.effect === "breakthrough" && E(e, t, "science", a.amount + o), [
		"population",
		"build",
		"upgrade",
		"destroy",
		"wonder"
	].includes(n.type) && R(e, {
		key: n.type,
		rid: t.rid,
		card: n.card,
		n: n.n
	});
}
function mt(e, t) {
	return e.militaryHand.splice(e.militaryHand.findIndex((e) => e.uid === t), 1)[0];
}
function ht(e) {
	let t = e.players[e.turn];
	t.flags.turnStart = e.revision, e.phase = "action", e.continuation = "action", t.leader === "homer" && (t.temporary.homerOre = 1), t.leader === "cleopatra" && (t.temporary.cleopatraOre = 1);
	let n = Pe(e, (t) => I(e, t).strength).slice(-(L(e).length === 2 ? 1 : 2)).includes(t.rid);
	t.leader === "mariaTheresa" && (t.temporary.militaryOre = (t.temporary.militaryOre ?? 0) + (n ? 3 : 1)), t.leader === "boudica" && (n ? t.temporary.militaryOre = (t.temporary.militaryOre ?? 0) + 2 : Re(e, {
		kind: "boudica",
		rid: t.rid,
		card: "boudica"
	}));
}
//#endregion
//#region src/games/throughtheages/politics.ts
var gt = (e, t) => t.leader === "caesar" && (e.config.rebalance || !t.flags.caesarUsed) ? 2 : 1;
function _t(e, t, n) {
	let r = x(n, e.config);
	return (r.ratings?.strength ?? 0) + +(t.leader === "alexander") + (S(e, t, "greatWall") && ["infantry", "artillery"].includes(r.category) ? 1 : 0);
}
function vt(e, t, n) {
	return {
		...e,
		pacts: e.pacts.filter((e) => !(["protection2", "militaryAlliance3"].includes(e.id) && (e.a === t && e.b === n || e.b === t && e.a === n)))
	};
}
function yt(e, t, n, r = !1, i = !0) {
	let a = I(e, t).strength;
	return r && i && t.leader === "nostradamus" && (a += 3), !r && e.pacts.some((e) => e.id === "openBorders1" && (e.a === t.rid && e.b === n.rid || e.b === t.rid && e.a === n.rid)) && (a += 2), a;
}
function bt(e, t, n, r) {
	return !(t.rid === n.rid || t.leader === "gandhi" || n.resigned || e.pacts.some((e) => [
		"supremacy2",
		"peaceTreaty3",
		"sovereignty3"
	].includes(e.id) && (e.a === t.rid && e.b === n.rid || e.b === t.rid && e.a === n.rid)) || r && (e.lastRound === e.round || e.pacts.some((e) => e.id === "sovereignty3" && e.b === n.rid) || e.wars.some((e) => e.a === t.rid && e.b === n.rid)));
}
function xt(e, t) {
	let n = [{
		id: "",
		type: "endPolitics",
		score: -10
	}];
	if ((!t.temporary.politics || t.temporary.skippedPolitics) && (t.leader === "coubertin" && !t.flags.olympicsUsed && n.push({
		id: "",
		type: "olympics",
		card: t.leader,
		score: 10
	}), t.leader === "fleming" && !t.temporary.fleming)) for (let r of L(e).filter((e) => e !== t.rid && e !== t.flags.flemingLast)) n.push({
		id: "",
		type: "fleming",
		card: t.leader,
		target: r,
		score: 5
	});
	if ((t.temporary.politics ?? 0) >= gt(e, t)) return n.filter((e) => [
		"olympics",
		"fleming",
		"endPolitics"
	].includes(e.type));
	for (let r of t.militaryHand) {
		let i = x(r.id, e.config);
		if ((i.kind === "event" || i.kind === "territory" || t.leader === "confucius") && n.push({
			id: "",
			type: "prepare",
			card: r.id,
			source: r.uid,
			score: 5 + i.age
		}), i.kind === "territory" && t.leader === "columbus" && n.push({
			id: "",
			type: "columbus",
			card: r.id,
			source: r.uid,
			score: 14
		}), i.kind === "pact") for (let i of L(e).filter((e) => e !== t.rid)) for (let e of ["a", "b"]) n.push({
			id: "",
			type: "offer",
			card: r.id,
			source: r.uid,
			target: i,
			extra: e,
			score: 0
		});
		if (i.kind === "aggression" || i.kind === "war") for (let a of L(e)) {
			let o = e.players[a], s = i.kind === "war";
			if (!bt(e, t, o, s)) continue;
			let c = i.militaryCost;
			if (o.leader === "gandhi" && (c = e.config.rebalance ? c + 3 : c * 2), t.military < c) continue;
			let l = vt(e, t.rid, o.rid), u = S(e, t, "himeji") ? Math.max(0, ...t.technologies.filter((t) => t.workers && P(x(t.id, e.config).category)).map((n) => _t(e, t, n.id))) : 0;
			!s && yt(l, t, o) + u <= yt(l, o, t, !0) || n.push({
				id: "",
				type: s ? "declareWar" : "aggression",
				card: r.id,
				source: r.uid,
				target: a,
				military: c,
				score: yt(e, t, o) - yt(e, o, t, !0) > 5 ? 5 : -2
			});
		}
	}
	for (let r of e.pacts.filter((e) => e.a === t.rid || e.b === t.rid)) n.push({
		id: "",
		type: "cancelPact",
		card: r.id,
		target: r.a === t.rid ? r.b : r.a,
		score: -7
	});
	return t.leader === "alexander" && n.push({
		id: "",
		type: "alexander",
		card: t.leader,
		score: 1
	}), t.leader === "catherine" && !t.flags.catherineUsed && n.push({
		id: "",
		type: "catherine",
		card: t.leader,
		score: 7
	}), n;
}
function St(e, t, n, r) {
	let i = Object.fromEntries([n, r].map((t) => [t, I(e, e.players[t])]));
	if (e.pacts = e.pacts.filter((e) => e.id !== t || e.a !== n || e.b !== r), t === "navalTrade1") {
		e.players[n].blueTotal++;
		let t = e.players[r];
		t.blueTotal -= 2, t.blueTotal < t.technologies.reduce((e, t) => e + t.blue, 0) + t.wonders.reduce((e, t) => e + t.blue, 0) && z(e, {
			kind: "normalizeBlue",
			rid: r
		});
	}
	for (let t of [n, r]) B(e, e.players[t], i[t]);
}
function Ct(e, t, n) {
	for (let r of [...e.pacts].filter((e) => ["protection2", "militaryAlliance3"].includes(e.id) && (e.a === t && e.b === n || e.b === t && e.a === n))) St(e, r.id, r.a, r.b);
}
function wt(e, t, n) {
	if (n.type === "olympics") {
		e.olympics = t.rid, t.flags.olympicsUsed = !0, t.culture += 8;
		return;
	}
	if (n.type === "fleming") {
		t.flags.flemingCurrent = n.target, t.flags.flemingCards = JSON.stringify(e.players[n.target].militaryHand), t.temporary.fleming = 1;
		return;
	}
	switch (t.temporary.politics = (t.temporary.politics ?? 0) + 1, t.leader === "caesar" && t.temporary.politics === 2 && !e.config.rebalance && (t.flags.caesarUsed = !0), n.type) {
		case "prepare": {
			let r = t.militaryHand.findIndex((e) => e.uid === n.source), [i] = t.militaryHand.splice(r, 1), a = x(i.id, e.config);
			e.future.push(i), t.culture += a.age, t.leader === "confucius" && t.science++, t.leader === "nostradamus" && (t.culture += 3), t.leader === "eleanor" && He(e, t, 2);
			for (let n of Object.values(e.players).filter((e) => e.leader === "nostradamus" && e.rid !== t.rid)) (e.knownEvents[n.rid] ??= []).push(i.uid);
			R(e, {
				key: "prepare",
				rid: t.rid,
				n: a.age
			}), Re(e, { kind: "revealEvent" });
			break;
		}
		case "columbus": {
			let r = t.militaryHand.find((e) => e.uid === n.source).id;
			t.militaryHand = t.militaryHand.filter((e) => e.uid !== n.source);
			let i = I(e, t);
			qe(e, t), Je(e, t, r), B(e, t, i);
			break;
		}
		case "alexander": {
			let n = I(e, t);
			qe(e, t), M(t, 1), B(e, t, n);
			break;
		}
		case "catherine": {
			let n = 0;
			for (let r of L(e).filter((n) => I(e, e.players[n]).strength < I(e, t).strength)) {
				let t = e.players[r];
				t.yellow && (M(t, -1), n++);
			}
			n >= (L(e).length === 4 ? 2 : 1) && M(t, 1), t.flags.catherineUsed = !0;
			break;
		}
		case "offer":
			Ue(e, t, n.source), e.decision = {
				kind: "pact",
				rid: n.target,
				card: n.card,
				target: t.rid,
				extra: n.extra
			};
			break;
		case "cancelPact": {
			let r = e.pacts.find((e) => e.id === n.card && (e.a === t.rid || e.b === t.rid));
			St(e, r.id, r.a, r.b);
			break;
		}
		case "aggression":
		case "declareWar": {
			Ue(e, t, n.source), Ve(t, "military", n.military), e.olympics && A(e, t, "culture", 8);
			let r = e.players[n.target];
			Ct(e, t.rid, r.rid);
			let i = yt(e, t, r);
			R(e, {
				key: n.type,
				rid: t.rid,
				target: r.rid,
				card: n.card
			}), n.type === "declareWar" ? e.wars.push({
				id: n.card,
				a: t.rid,
				b: r.rid
			}) : z(e, {
				kind: "attackHimeji",
				rid: t.rid,
				target: r.rid,
				card: n.card,
				n: i
			});
			break;
		}
	}
}
function Tt(e, t, n, r) {
	let i = e.players[t], a = e.players[n], o = x(r, e.config);
	switch (o.effect) {
		case "spy":
			me(e, a, i, "science", o.amount);
			break;
		case "intervention":
			me(e, a, i, "culture", o.amount);
			break;
		case "occupy":
			for (let t of [
				"food",
				"ore",
				"science",
				"culture"
			]) me(e, a, i, t, 3);
			break;
		case "plunder":
			z(e, {
				kind: "plunder",
				rid: i.rid,
				target: a.rid,
				card: r,
				n: Math.min(o.amount, T(e, a, "food") + T(e, a, "ore"))
			});
			break;
		case "enslave":
			E(e, i, "ore", 2), E(e, i, "food", 2), z(e, {
				kind: "losePopulation",
				rid: a.rid,
				n: 1
			});
			break;
		case "raid":
			z(e, {
				kind: "raid",
				rid: i.rid,
				target: a.rid,
				card: r,
				n: o.amount,
				extra: "0"
			});
			break;
		case "infiltrate":
			z(e, {
				kind: "infiltrate",
				rid: i.rid,
				target: a.rid,
				card: r
			});
			break;
		case "annex":
			z(e, {
				kind: "annex",
				rid: i.rid,
				target: a.rid,
				card: r
			});
			break;
		case "kidnap": z(e, {
			kind: "kidnap",
			rid: i.rid,
			target: a.rid,
			card: r
		});
	}
}
function Et(e, t) {
	e.auction = {
		card: t,
		bid: 0,
		leader: null,
		passed: [],
		rid: e.turn,
		units: {},
		cards: [],
		paid: 0,
		paidFood: 0,
		cook: [],
		offers: {}
	};
}
function Dt(e) {
	let t = e.auction, n = e.players[t.rid], r = Ae(e, n, t.units) + I(e, n).colonize;
	for (let i of t.cards) r += x(n.militaryHand.find((e) => e.uid === i).id, e.config).colonize ?? 1;
	return t.paid && (r += t.paid === 1 ? 1 : t.paid === 3 ? 2 : 3), r;
}
function Ot(e, t) {
	let n = e.auction, r = [{
		id: "",
		type: "auctionPass",
		card: n.card,
		score: -2
	}];
	for (let i of t.technologies.filter((t) => P(x(t.id, e.config).category))) {
		let e = n.units[i.id] ?? 0;
		e < i.workers && r.push({
			id: "",
			type: "auctionUnit",
			card: i.id,
			n: 1,
			score: 1
		}), e && r.push({
			id: "",
			type: "auctionUnit",
			card: i.id,
			n: -1,
			score: -3
		});
	}
	let i = n.cards.filter((n) => x(t.militaryHand.find((e) => e.uid === n).id, e.config).kind !== "bonus").length;
	for (let a of t.militaryHand) (x(a.id, e.config).kind === "bonus" || t.leader === "cook" && i < 2 || n.cards.includes(a.uid)) && r.push({
		id: "",
		type: "auctionCard",
		card: a.id,
		source: a.uid,
		n: n.cards.includes(a.uid) ? -1 : 1,
		score: n.cards.includes(a.uid) ? -3 : 0
	});
	if (t.leader === "isabella") for (let i of [
		0,
		1,
		3,
		6
	]) for (let a of ge(e, t, "ore", i)) (i !== n.paid || a.food !== n.paidFood) && r.push({
		id: "",
		type: "auctionPay",
		n: i,
		card: "isabella",
		alternate: a.alternate,
		trade: a.trade,
		score: -2
	});
	if (Object.values(n.units).some((e) => e > 0)) for (let t = n.bid + 1; t <= Dt(e); t++) r.push({
		id: "",
		type: "auctionBid",
		n: t,
		card: n.card,
		score: 5 - (t - n.bid)
	});
	return r;
}
function kt(e, t, n) {
	let r = e.auction;
	if (n.type === "auctionUnit") {
		r.units[n.card] = (r.units[n.card] ?? 0) + n.n;
		return;
	}
	if (n.type === "auctionCard") {
		n.n === -1 ? r.cards = r.cards.filter((e) => e !== n.source) : r.cards.push(n.source);
		return;
	}
	if (n.type === "auctionPay") {
		r.paid = n.n, r.paidFood = n.alternate ?? 0;
		return;
	}
	n.type === "auctionPass" ? r.passed.push(t.rid) : (r.bid = n.n, r.leader = t.rid, r.offers[t.rid] = {
		units: { ...r.units },
		cards: [...r.cards],
		paid: r.paid,
		paidFood: r.paidFood
	}, R(e, {
		key: "bid",
		rid: t.rid,
		card: r.card,
		n: r.bid
	}));
	let i = L(e).filter((e) => !r.passed.includes(e));
	if (!i.length || i.length === 1 && r.leader === i[0]) {
		if (r.leader) {
			let t = e.players[r.leader], n = r.offers[r.leader];
			for (let e of t.technologies) {
				let r = n.units[e.id] ?? 0;
				e.workers -= r, t.yellow += r;
			}
			n.cards.forEach((n) => Ue(e, t, n)), k(e, t, "food", n.paidFood), k(e, t, "ore", n.paid - n.paidFood), Je(e, t, r.card), R(e, {
				key: "colonize",
				rid: t.rid,
				card: r.card
			});
		}
		e.auction = null;
		return;
	}
	let a = e.order.indexOf(t.rid);
	do
		a = (a + 1) % e.order.length;
	while (!i.includes(e.order[a]) || e.order[a] === r.leader);
	r.rid = e.order[a], r.units = {}, r.cards = [], r.paid = 0, r.paidFood = 0;
}
function At(e) {
	e.events.length || (e.events = Ie(e, e.future).sort((t, n) => x(t.id, e.config).age - x(n.id, e.config).age), e.future = [], e.knownEvents = {});
}
function jt(e) {
	e.events.length || At(e);
	let t = e.events.shift();
	if (!t) return;
	e.events.length || z(e, { kind: "promoteEvents" }), e.exposed = t.id, e.past.push(t.id), R(e, {
		key: "event",
		card: t.id
	});
	let n = x(t.id, e.config);
	if (n.kind === "territory") Et(e, t.id);
	else if (n.kind === "event") z(e, {
		kind: "event",
		card: t.id
	});
	else for (let t of L(e)) E(e, e.players[t], "science", 1);
}
function Mt(e, t) {
	let n = e.decision, r = n.target ? e.players[n.target] : void 0, i = [], a = (e) => i.push({
		...e,
		id: ""
	});
	switch (n.kind) {
		case "pact":
			a({
				type: "decline",
				card: n.card,
				score: 0
			}), a({
				type: "accept",
				card: n.card,
				score: 1
			});
			break;
		case "attackHimeji":
		case "defendHimeji":
			(n.kind !== "attackHimeji" || n.extra === "war" || n.n > yt(e, r, t, !0)) && a({
				type: "skip",
				card: "himeji",
				score: 0
			});
			for (let i of t.technologies.filter((t) => t.workers && P(x(t.id, e.config).category))) (n.kind !== "attackHimeji" || n.extra === "war" || n.n + _t(e, t, i.id) > yt(e, r, t, !0)) && a({
				type: "sacrifice",
				card: i.id,
				score: -2
			});
			break;
		case "defend": {
			let i = n.selected ?? [], o = i.reduce((n, r) => n + (x(t.militaryHand.find((e) => e.uid === r).id, e.config).defense ?? 1), 0);
			a({
				type: "yield",
				card: n.card,
				score: -5
			}), yt(e, t, r, !0) + (n.amount ?? 0) + o >= n.n && a({
				type: "defend",
				card: n.card,
				n: o,
				score: 8
			});
			for (let n of t.militaryHand) {
				let r = i.includes(n.uid);
				(r || i.length < I(e, t).military) && a({
					type: "defenseCard",
					card: n.id,
					source: n.uid,
					n: r ? -1 : 1,
					score: r ? -9 : 1
				});
			}
			break;
		}
		case "plunder":
			for (let t = 0; t <= Math.min(n.n, T(e, r, "food")); t++) n.n - t <= T(e, r, "ore") && a({
				type: "plunder",
				card: n.card,
				n: t,
				score: 2
			});
			break;
		case "raid": {
			a({
				type: "skip",
				card: n.card,
				score: 0
			});
			let t = x(n.card, e.config).age - (n.amount ?? 0);
			for (let n of r.technologies.filter((n) => n.workers && F(x(n.id, e.config).category) && x(n.id, e.config).age <= t)) a({
				type: "raid",
				card: n.id,
				score: 4 + x(n.id, e.config).age
			});
			break;
		}
		case "infiltrate":
			a({
				type: "skip",
				score: 0
			}), r.leader && a({
				type: "infiltrateLeader",
				card: r.leader,
				score: 5 + x(r.leader, e.config).age
			});
			for (let t of r.wonders.filter((t) => !t.ruined && t.stages < x(t.id, e.config).stages.length)) a({
				type: "infiltrateWonder",
				card: t.id,
				score: 4 + x(t.id, e.config).age
			});
			break;
		case "annex":
			a({
				type: "skip",
				score: 0
			});
			for (let e of r.colonies) a({
				type: "annex",
				card: e,
				score: 5
			});
			break;
		case "kidnap":
			a({
				type: "skip",
				score: 0
			});
			for (let n of r.hand) Ge(e, t, n.id) && a({
				type: "kidnap",
				card: n.id,
				source: n.uid,
				score: 5
			});
			break;
		case "warTechnology":
			a({
				type: "warScience",
				n: Math.min(n.n, r.science),
				card: n.card,
				score: 3
			});
			for (let i of r.technologies.filter((t) => !t.workers && !["farm", "mine"].includes(x(t.id, e.config).category) && !P(x(t.id, e.config).category) && !F(x(t.id, e.config).category))) {
				let r = x(i.id, e.config);
				r.science <= n.n && !t.technologies.some((t) => x(t.id, e.config).category === r.category && x(t.id, e.config).age >= r.age) && a({
					type: "warSteal",
					card: r.id,
					n: r.science,
					score: 5
				});
			}
	}
	return i;
}
function Nt(e, t, n) {
	let r = e.decision, i = r.target ? e.players[r.target] : void 0;
	switch (r.kind) {
		case "pact":
			if (n.type === "accept") {
				let n = r.extra === "a" ? i.rid : t.rid, a = r.extra === "a" ? t.rid : i.rid;
				for (let t of [...e.pacts].filter((e) => e.owner === i.rid || e.a === n && e.b === a || e.a === a && e.b === n)) St(e, t.id, t.a, t.b);
				let o = I(e, e.players[n]), s = I(e, e.players[a]);
				e.pacts.push({
					id: r.card,
					a: n,
					b: a,
					owner: i.rid
				}), r.card === "navalTrade1" && (e.players[n].blueTotal--, e.players[a].blueTotal += 2, z(e, {
					kind: "normalizeBlue",
					rid: n
				})), B(e, e.players[n], o), B(e, e.players[a], s);
			}
			break;
		case "attackHimeji":
		case "defendHimeji": {
			let a = 0;
			if (n.type === "sacrifice" && (a = _t(e, t, n.card), z(e, {
				kind: "sacrifice",
				rid: t.rid,
				card: n.card
			}), r.kind === "attackHimeji" ? t.culture += 3 : a += 3), r.extra === "war" && r.kind === "attackHimeji") z(e, {
				kind: "defendHimeji",
				rid: i.rid,
				target: t.rid,
				card: r.card,
				n: r.n + a,
				amount: r.amount,
				extra: "war"
			});
			else if (r.extra === "war") z(e, {
				kind: "warFinish",
				rid: i.rid,
				target: t.rid,
				card: r.card,
				n: r.n,
				amount: r.amount + a
			});
			else if (r.kind === "attackHimeji") z(e, {
				kind: "defendHimeji",
				rid: i.rid,
				target: t.rid,
				card: r.card,
				n: r.n + a
			});
			else return e.decision = {
				kind: "defend",
				rid: t.rid,
				target: i.rid,
				card: r.card,
				n: r.n,
				amount: a,
				selected: []
			}, !0;
			break;
		}
		case "defend":
			if (n.type === "defenseCard") return r.selected ??= [], n.n === -1 ? r.selected = r.selected.filter((e) => e !== n.source) : r.selected.push(n.source), !0;
			n.type === "defend" ? r.selected.forEach((n) => Ue(e, t, n)) : Tt(e, i.rid, t.rid, r.card), R(e, {
				key: n.type === "defend" ? "defend" : "yield",
				rid: t.rid,
				target: i.rid,
				card: r.card
			});
			break;
		case "plunder": {
			let a = A(e, i, "food", n.n);
			E(e, t, "ore", A(e, i, "ore", r.n - n.n)), E(e, t, "food", a);
			break;
		}
		case "raid": {
			let a = Number(r.extra);
			if (n.type === "raid") {
				i.technologies.find((e) => e.id === n.card).workers--, i.pool++;
				let o = a + x(n.card, e.config).cost;
				r.n > 1 ? (z(e, {
					...r,
					kind: "raid",
					n: r.n - 1,
					extra: String(o),
					target: i.rid
				}), e.queue[0].n = r.n - 1, e.queue[0].amount = (r.amount ?? 0) + 1) : E(e, t, "ore", Math.ceil(o / 2));
			} else E(e, t, "ore", Math.ceil(a / 2));
			break;
		}
		case "infiltrate":
			if (n.type !== "skip") {
				t.science += x(n.card, e.config).age * 3;
				let r = I(e, i);
				n.type === "infiltrateLeader" ? qe(e, i) : i.wonders = i.wonders.filter((e) => e.id !== n.card), B(e, i, r);
			}
			break;
		case "annex":
			n.type !== "skip" && (Ye(e, i, n.card), Je(e, t, n.card, !1));
			break;
		case "kidnap":
			if (n.type !== "skip") {
				let r = i.hand.findIndex((e) => e.uid === n.source), [a] = i.hand.splice(r, 1);
				Ke(e, t, a, !1), t.flags.kidnap = a.uid;
			}
			break;
		case "warTechnology":
			if (n.type === "warScience") me(e, i, t, "science", r.n);
			else {
				let a = I(e, t), o = I(e, i), s = x(n.card, e.config);
				i.technologies = i.technologies.filter((e) => e.id !== n.card), t.technologies = t.technologies.filter((t) => x(t.id, e.config).category !== s.category), t.technologies.push({
					id: n.card,
					workers: 0,
					blue: 0
				}), B(e, t, a), B(e, i, o), r.n > n.n && z(e, {
					kind: "warTechnology",
					rid: t.rid,
					target: i.rid,
					card: r.card,
					n: r.n - n.n
				});
			}
			break;
		default: return !1;
	}
	return e.decision = null, !0;
}
//#endregion
//#region src/games/throughtheages/effects.ts
function H(e, t, n = t.kind) {
	e.decision = {
		...t,
		kind: n,
		rid: t.rid ?? e.turn,
		card: t.card ?? ""
	};
}
var Pt = (e) => {
	let t = e.order.indexOf(e.turn);
	return [...e.order.slice(t), ...e.order.slice(0, t)].filter((t) => !e.players[t].resigned);
};
function Ft(e, t, n, r) {
	z(e, ...Pt(e).map((e) => ({
		kind: t,
		rid: e,
		card: n,
		n: r
	})));
}
function It(e, t) {
	let n = t === "impactScience" ? "science" : t === "impactStrength" ? "strength" : "culture", r = Pe(e, (t) => I(e, t)[n]), i = L(e).length === 2 ? [10, 0] : L(e).length === 3 ? [
		14,
		7,
		0
	] : [
		15,
		10,
		5,
		0
	];
	for (let n of Pt(e)) {
		let a = e.players[n], o = I(e, a), s = (t) => a.technologies.reduce((n, r) => n + (t(x(r.id, e.config).category) ? x(r.id, e.config).age * r.workers : 0), 0), c = a.technologies.filter((t) => !["farm", "mine"].includes(x(t.id, e.config).category) && !P(x(t.id, e.config).category) && !F(x(t.id, e.config).category)), l;
		switch (t) {
			case "impactPopulation":
				l = Math.max(0, a.yellowTotal - a.yellow - Ne(e, a) - 10) * 2;
				break;
			case "impactWonders":
				l = a.wonders.filter((t) => t.stages === x(t.id, e.config).stages.length).reduce((t, n) => t + 5 - x(n.id, e.config).age, 0);
				break;
			case "impactColonies":
				l = a.colonies.length * 3;
				break;
			case "impactCompetition":
				l = s((e) => Se.includes(e) || e === "arena");
				break;
			case "impactAgriculture":
				l = o.food + (o.food > _e(a) ? 4 : 0);
				break;
			case "impactProgress":
				l = 2 * (x(a.government, e.config).age + c.reduce((t, n) => t + x(n.id, e.config).age, 0));
				break;
			case "impactIndustry":
				l = tt(e, a);
				break;
			case "impactScience":
			case "impactStrength":
			case "impactCulture":
				l = i[r.indexOf(n)];
				break;
			case "impactTechnology":
				l = 4 * (a.technologies.filter((t) => x(t.id, e.config).age === 3).length + +(x(a.government, e.config).age === 3));
				break;
			case "impactHappiness":
				l = 2 * (o.happy - Ne(e, a));
				break;
			case "impactArchitecture":
				l = s((e) => Ce.includes(e));
				break;
			case "impactGovernment":
				l = 2 * o.civil + o.military;
				break;
			case "impactVariety":
				l = 2 * (c.length + [...Se, ...Ce].filter((t) => N(e, a, t)).length);
				break;
			case "impactBalance":
				l = 2 * Math.min(o.food, o.ore, o.science, o.culture);
				break;
			case "impactEconomy":
				l = 4 * Math.min(nt(e, a, "production"), nt(e, a, "military"), nt(e, a, "urban"));
				break;
			default: throw Error(`Unhandled impact ${t}`);
		}
		V(e, a, t, l), R(e, {
			key: "score",
			rid: n,
			card: t,
			n: l
		});
	}
}
function Lt(e, t, n) {
	let r = x(t, e.config), i = n ? [n] : Pt(e);
	if (t.startsWith("impact")) {
		It(e, t);
		return;
	}
	if (r.age === 0) {
		if (t === "devPlanning") {
			let n = Ie(e, e.unusedAncientEvents).slice(0, 3);
			z(e, ...i.map((e) => ({
				kind: "planning",
				rid: e,
				card: t,
				extra: n.join("|")
			})));
			return;
		}
		z(e, ...i.map((e) => ({
			kind: "ancient",
			rid: e,
			card: t
		})));
		return;
	}
	let a = Pe(e, (t) => I(e, t).strength), o = Fe(e, 1)[0], s = a.slice(0, i.length === 2 ? 1 : 2), c = Fe(e), l = e.players[a[0]], u = e.players[o];
	switch (t) {
		case "barbarians": {
			let n = Pe(e, (e) => e.culture)[0];
			c.includes(n) && z(e, {
				kind: "losePopulation",
				rid: n,
				n: 1,
				card: t
			});
			break;
		}
		case "foray":
			z(e, ...s.map((e) => ({
				kind: "gainMixed",
				rid: e,
				card: t,
				n: 3
			})));
			break;
		case "raiders":
			z(e, ...c.map((e) => ({
				kind: "loseMixed",
				rid: e,
				card: t,
				n: 2
			})));
			break;
		case "epidemic":
			Ft(e, "losePopulation", t, 1);
			break;
		case "rats":
			i.forEach((t) => A(e, e.players[t], "food", T(e, e.players[t], "food")));
			break;
		case "scientificBreakthrough":
			i.forEach((t) => {
				e.players[t].science += I(e, e.players[t]).science;
			});
			break;
		case "culturalInfluence":
			i.forEach((t) => {
				e.players[t].culture += I(e, e.players[t]).culture;
			});
			break;
		case "newDeposits":
			Ft(e, "produceOre", t);
			break;
		case "goodHarvest":
			Ft(e, "produceFood", t);
			break;
		case "rebellion":
			i.forEach((t) => {
				let n = e.players[t];
				n.civil = Math.max(0, n.civil - Ne(e, n) * 2);
			});
			break;
		case "territorialDispute":
			E(e, l, "ore", 3), z(e, {
				kind: "demolish",
				rid: o,
				card: t
			});
			break;
		case "crusades":
			E(e, l, "culture", 4), A(e, u, "culture", 4);
			break;
		case "famine":
			z(e, {
				kind: "losePopulation",
				rid: o,
				n: 1,
				card: t
			});
			break;
		case "enslavement":
			u.yellow && (M(u, -1), M(l, 1));
			break;
		case "immigration": {
			let t = Math.max(...i.map((t) => I(e, e.players[t]).happy));
			i.filter((n) => I(e, e.players[n]).happy === t).forEach((t) => be(e, e.players[t]));
			break;
		}
		case "popularization":
			i.forEach((t) => {
				e.players[t].culture += I(e, e.players[t]).science;
			});
			break;
		case "politicsStrength":
			e.age === 4 ? (E(e, l, "culture", 5), A(e, u, "culture", 3)) : (He(e, l, 5), z(e, {
				kind: "discardCards",
				rid: o,
				card: t,
				n: Math.min(3, u.militaryHand.length)
			}));
			break;
		case "independence":
			z(e, {
				kind: "loseColony",
				rid: o,
				card: t
			});
			break;
		case "emigration":
			z(e, ...i.map((n) => ({
				kind: "losePopulation",
				rid: n,
				card: t,
				n: Math.ceil(Ne(e, e.players[n]) / 2)
			})));
			break;
		case "crimeWave":
			c.forEach((t) => {
				A(e, e.players[t], "culture", 3), Xe(e, e.players[t], 1);
			});
			break;
		case "nationalPride":
			E(e, e.players[Pe(e, (e) => e.culture)[0]], "culture", 5);
			break;
		case "civilUnrest": {
			let t = Math.max(...i.map((t) => Ne(e, e.players[t])));
			i.forEach((n) => {
				let r = e.players[n], i = Ne(e, r);
				A(e, r, "culture", i * 4), i > 0 && i === t && Xe(e, r, 1);
			});
			break;
		}
		case "terrorism": {
			let n = Pe(e, (e) => e.culture).at(-1);
			z(e, ...i.filter((e) => e !== n).map((e) => ({
				kind: "terrorism",
				rid: n,
				target: e,
				card: t
			})));
			break;
		}
		case "ravages":
			Ft(e, "ravages", t);
			break;
		case "prosperity":
			i.forEach((t) => E(e, e.players[t], "ore", I(e, e.players[t]).happy));
			break;
		case "iconoclasm":
			i.forEach((t) => {
				let n = e.players[t];
				if (n.leader && x(n.leader, e.config).age !== e.age) {
					let t = I(e, n);
					qe(e, n), B(e, n, t);
				}
			});
			break;
		case "economicProgress":
			z(e, ...i.flatMap((e) => [
				{
					kind: "corruption",
					rid: e
				},
				{
					kind: "produceFood",
					rid: e
				},
				{
					kind: "consume",
					rid: e
				},
				{
					kind: "produceOre",
					rid: e
				}
			]));
			break;
		case "internationalAgreement":
			z(e, {
				kind: "agreementOffer",
				rid: l.rid,
				card: t
			});
			break;
		case "colonialism":
			s.forEach((t) => E(e, e.players[t], "culture", 6));
			break;
		case "happiness":
			E(e, l, "culture", 3), be(e, l), A(e, u, "culture", 3), z(e, {
				kind: "losePopulation",
				rid: u.rid,
				n: 1,
				card: t
			});
			break;
		case "darkAges":
			i.forEach((t) => A(e, e.players[t], "science", Math.max(0, Math.ceil((e.players[t].science - 4) / 2))));
			break;
		case "knowledgeAncients":
			i.forEach((t) => {
				let n = e.players[t];
				for (let t of n.wonders) {
					let r = x(t.id, e.config), i = r.age === 0 ? 2 : 1;
					E(e, n, t.stages === r.stages.length ? "science" : "ore", i);
				}
			});
			break;
		case "callArms":
			Fe(e, i.length === 2 ? 1 : 2).reverse().forEach((t, n) => {
				let r = e.players[t], i = Math.min(r.civil, n === 0 ? 2 : 1);
				r.civil -= i, He(e, r, i);
			});
			break;
		case "armsIndustry": {
			let t = (t, n) => Math.max(0, ...t.technologies.filter((t) => x(t.id, e.config).category === n).map((t) => x(t.id, e.config).age)), n = Object.fromEntries(i.map((e) => [e, 0]));
			for (let r of [
				"infantry",
				"cavalry",
				"artillery"
			]) {
				let a = Math.max(...i.map((n) => t(e.players[n], r)));
				a && i.filter((n) => t(e.players[n], r) === a).forEach((e) => {
					n[e] += 2;
				});
			}
			i.forEach((t) => E(e, e.players[t], "ore", n[t]));
			break;
		}
		case "freedomMovement":
			Ft(e, "freedomMovement", t);
			break;
		case "internationalNegotiations":
			z(e, {
				kind: "negotiations",
				rid: e.turn,
				target: u.rid,
				extra: l.rid,
				card: t
			});
			break;
		default: throw Error(`Unhandled event ${t}`);
	}
}
function Rt(e, t, n) {
	let r = I(e, t);
	switch (n) {
		case "hangingGardens":
			e.config.rebalance && E(e, t, "food", 2);
			break;
		case "suez":
			z(e, {
				kind: "freeColony",
				rid: t.rid,
				card: n
			});
			break;
		case "hollywood":
			V(e, t, n, 2 * (Me(e, t, ["theater", "library"]).culture ?? 0));
			break;
		case "internet": {
			let r = Me(e, t);
			V(e, t, n, (r.science ?? 0) + (r.culture ?? 0) + (r.strength ?? 0));
			break;
		}
		case "spaceFlight":
			V(e, t, n, x(t.government, e.config).age + t.technologies.reduce((t, n) => t + x(n.id, e.config).age, 0));
			break;
		case "fastFood":
			V(e, t, n, nt(e, t, "production") * 2 + nt(e, t, "military") + nt(e, t, "urban"));
			break;
		case "empireState":
			V(e, t, n, (L(e).length + 5) * [
				"science",
				"culture",
				"strength",
				"food",
				"ore"
			].filter((n) => L(e).filter((e) => e !== t.rid).every((t) => I(e, e.players[t])[n] < r[n])).length);
			break;
		case "unitedNations": {
			let r = t.wonders.filter((t) => t.stages === x(t.id, e.config).stages.length).length, i = t.technologies.filter((t) => !["farm", "mine"].includes(x(t.id, e.config).category) && !P(x(t.id, e.config).category) && !F(x(t.id, e.config).category)).length;
			V(e, t, n, 4 * Math.max(r, i, Ce.filter((n) => N(e, t, n)).length)), z(e, {
				kind: "unitedNations",
				rid: t.rid,
				card: n
			});
			break;
		}
		case "manhattan":
			V(e, t, n, r.science);
			break;
		case "redCross": V(e, t, n, L(e).reduce((t, n) => t + e.players[n].colonies.length, 0));
	}
}
function zt(e, t) {
	let n = t.rid ? e.players[t.rid] : void 0, r = t.target ? e.players[t.target] : void 0;
	switch (t.kind) {
		case "revealEvent":
			jt(e);
			break;
		case "promoteEvents":
			At(e);
			break;
		case "event":
			Lt(e, t.card);
			break;
		case "wonderComplete":
			Rt(e, n, t.card);
			break;
		case "produceFood":
			Qe(e, n, "food");
			break;
		case "produceOre":
			Qe(e, n, "ore");
			break;
		case "productionBonus":
			t.n < 0 ? A(e, n, t.resource, -t.n) : E(e, n, t.resource, t.n);
			break;
		case "population":
			be(e, n, t.n);
			break;
		case "sacrifice":
			n.technologies.find((e) => e.id === t.card).workers--, n.yellow++;
			break;
		case "normalizeBlue":
			C(n) < 0 && H(e, {
				...t,
				n: -C(n)
			}, "removeBlue");
			break;
		case "removeBlue":
			t.n > 0 && H(e, t);
			break;
		case "losePopulation":
			t.n > 0 && n.yellowTotal - n.yellow > 0 && H(e, t);
			break;
		case "discardCards":
			t.n > 0 && n.militaryHand.length > 0 && H(e, t);
			break;
		case "ancient":
			switch (t.card) {
				case "devAgriculture":
					E(e, n, "food", 2);
					break;
				case "devScience":
					E(e, n, "science", 2);
					break;
				case "devCrafts":
					E(e, n, "ore", 2);
					break;
				case "devSettlement":
					be(e, n);
					break;
				case "devPolitics":
					He(e, n, 3);
					break;
				case "devTrade":
					E(e, n, "science", 1), E(e, n, "food", 1), E(e, n, "ore", 1);
					break;
				case "devWarfare":
				case "devReligion":
				case "devCivilization":
				case "devMarkets":
					H(e, t, t.card);
					break;
				default: throw Error(`Unhandled ancient event ${t.card}`);
			}
			break;
		case "planning":
			H(e, t), e.decision.options = t.extra.split("|");
			break;
		case "gainMixed":
		case "loseMixed":
		case "boudica":
		case "autonomous":
		case "saladin":
		case "homer":
		case "jobs":
		case "freeColony":
		case "unitedNations":
		case "agreementOffer":
		case "negotiations":
			H(e, t);
			break;
		case "demolish":
			n.technologies.some((t) => t.workers && !P(x(t.id, e.config).category)) && H(e, t);
			break;
		case "terrorism":
			r.technologies.some((t) => t.workers && F(x(t.id, e.config).category)) && H(e, t);
			break;
		case "loseColony":
			n.colonies.length && H(e, t);
			break;
		case "ravages":
			n.wonders.some((t) => !t.ruined && x(t.id, e.config).age <= 1 && t.stages === x(t.id, e.config).stages.length) && H(e, t);
			break;
		case "freedomMovement":
			lt(e, n, "freedomMovement").length && H(e, t);
			break;
		case "attackHimeji":
		case "defendHimeji":
			S(e, n, "himeji") && n.technologies.some((t) => t.workers && P(x(t.id, e.config).category)) ? H(e, t) : t.kind === "attackHimeji" ? z(e, {
				...t,
				kind: "defendHimeji",
				rid: r.rid,
				target: n.rid
			}) : t.extra === "war" ? z(e, {
				...t,
				kind: "warFinish",
				rid: r.rid,
				target: n.rid
			}) : H(e, {
				...t,
				kind: "defend"
			});
			break;
		case "warStart": {
			let i = yt(e, n, r, !1, !1), a = yt(e, r, n, !0, !1);
			z(e, {
				kind: "attackHimeji",
				rid: n.rid,
				target: r.rid,
				card: t.card,
				n: i,
				amount: a,
				extra: "war"
			});
			break;
		}
		case "warFinish": {
			e.wars = e.wars.filter((e) => e.id !== t.card || e.a !== n.rid || e.b !== r.rid);
			let i = t.n, a = t.amount, o = i > a ? n : r, s = i > a ? r : n, c = Math.abs(i - a);
			if (!c) break;
			if (R(e, {
				key: "warResult",
				rid: o.rid,
				target: s.rid,
				card: t.card,
				n: c
			}), t.card === "warTerritory2") {
				let e = Math.min(s.yellow, 1 + Math.floor(c / 5));
				M(s, -e), M(o, e);
			} else t.card === "warTechnology2" ? z(e, {
				kind: "warTechnology",
				rid: o.rid,
				target: s.rid,
				card: t.card,
				n: c
			}) : me(e, s, o, "culture", c + (t.card === "warCulture3" ? 5 : 0));
			break;
		}
		case "plunder":
		case "raid":
		case "infiltrate":
		case "annex":
		case "kidnap":
		case "warTechnology":
			H(e, t);
			break;
		default: return !1;
	}
	return !0;
}
function Bt(e, t) {
	let n = e.decision, r = Mt(e, t), i = (e) => r.push({
		...e,
		id: ""
	});
	switch (n.kind) {
		case "produce":
			for (let [r, a] of Object.entries(n.units)) a > 0 && C(t) > 0 && i({
				type: "produce",
				card: r,
				score: x(r, e.config).value ?? 1
			});
			break;
		case "removeBlue":
			for (let n of t.technologies.filter((e) => e.blue > 0)) i({
				type: "removeBlue",
				card: n.id,
				score: -(x(n.id, e.config).value ?? x(n.id, e.config).age)
			});
			break;
		case "losePopulation":
			if (t.pool) i({
				type: "losePopulation",
				score: 5
			});
			else for (let n of t.technologies.filter((e) => e.workers)) i({
				type: "losePopulation",
				card: n.id,
				score: -x(n.id, e.config).age
			});
			break;
		case "discardCards":
			for (let n of t.militaryHand) i({
				type: "discardCards",
				card: n.id,
				source: n.uid,
				score: x(n.id, e.config).kind === "bonus" ? -2 : 0
			});
			break;
		case "gainMixed":
		case "loseMixed": {
			let r = n.kind === "loseMixed" ? Math.min(n.n, T(e, t, "food") + T(e, t, "ore")) : n.n;
			for (let a = 0; a <= r; a++) (n.kind !== "loseMixed" || a <= T(e, t, "food") && r - a <= T(e, t, "ore")) && i({
				type: n.kind,
				n: a,
				cost: r - a,
				card: n.card,
				score: 2
			});
			break;
		}
		case "boudica":
		case "autonomous":
		case "devMarkets":
			for (let e of n.kind === "boudica" ? [
				"food",
				"ore",
				"science"
			] : n.kind === "devMarkets" ? ["food", "ore"] : [
				"science",
				"ore",
				"food",
				"culture"
			]) i({
				type: "gain",
				resource: e,
				n: n.kind === "boudica" ? 1 : n.kind === "devMarkets" ? 2 : e === "science" ? 4 : e === "ore" ? 5 : e === "food" ? 6 : 7,
				card: n.card,
				score: e === "ore" ? 5 : 4
			});
			break;
		case "saladin":
			for (let e of ["civil", "strength"]) i({
				type: "saladin",
				extra: e,
				card: "saladin",
				score: e === "civil" ? 4 : 2
			});
			break;
		case "homer":
			i({
				type: "recoverCivil",
				card: "homer",
				score: 0
			});
			for (let n of t.wonders.filter((t) => !t.ruined && t.stages === x(t.id, e.config).stages.length)) i({
				type: "homer",
				card: n.id,
				score: 3
			});
			break;
		case "jobs":
			i({
				type: "skip",
				card: "jobs",
				score: 0
			});
			for (let n of ge(e, t, "ore", 1)) i({
				type: "jobs",
				card: "jobs",
				cost: 1,
				alternate: n.alternate,
				trade: n.trade,
				score: 4
			});
			break;
		case "devWarfare":
		case "devReligion": {
			i({
				type: "skip",
				card: n.card,
				score: -1
			});
			let r = n.kind === "devWarfare" ? "warriors" : "religion";
			t.pool && (r === "warriors" || N(e, t, "temple") < I(e, t).urban) && i({
				type: "freeBuild",
				card: r,
				score: 4
			});
			break;
		}
		case "devCivilization":
		case "freedomMovement":
			i({
				type: "skip",
				card: n.card,
				score: -2
			}), r.push(...lt(e, t, n.kind, +(n.kind === "devCivilization")).map((e) => ({
				...e,
				ability: void 0
			})));
			break;
		case "planning":
			for (let e of n.options) i({
				type: "planning",
				card: e,
				score: 3
			});
			break;
		case "demolish":
		case "terrorism": {
			let r = n.kind === "terrorism" ? e.players[n.target] : t;
			for (let t of r.technologies.filter((t) => t.workers && (n.kind === "terrorism" ? F(x(t.id, e.config).category) : !P(x(t.id, e.config).category)))) i({
				type: "demolish",
				card: t.id,
				target: r.rid,
				score: -x(t.id, e.config).age
			});
			break;
		}
		case "ravages":
			for (let n of t.wonders.filter((t) => !t.ruined && x(t.id, e.config).age <= 1 && t.stages === x(t.id, e.config).stages.length)) i({
				type: "ravages",
				card: n.id,
				score: -I(e, t).culture
			});
			break;
		case "loseColony":
			for (let e of t.colonies) i({
				type: "loseColony",
				card: e,
				score: 0
			});
			break;
		case "freeColony":
		case "unitedNations":
			i({
				type: "skip",
				card: n.card,
				score: -1
			});
			for (let r of t.militaryHand.filter((t) => n.kind === "freeColony" ? x(t.id, e.config).kind === "territory" : x(t.id, e.config).kind === "event" && x(t.id, e.config).age === 3)) i({
				type: n.kind,
				card: r.id,
				source: r.uid,
				score: 5
			});
			break;
		case "agreementOffer":
			i({
				type: "skip",
				card: n.card,
				score: 0
			}), i({
				type: "agreementAccept",
				card: n.card,
				score: 6
			});
			break;
		case "agreement":
			i({
				type: "agreementEnd",
				card: n.card,
				score: 0
			}), r.push(...ut(e, {
				...t,
				civil: 100
			}).filter((e) => e.type === "take" && !e.ability && e.civil <= n.amount).map((e) => ({
				...e,
				type: "agreementTake"
			})));
			break;
		case "negotiations":
			for (let t of [
				"food",
				"ore",
				"science"
			]) T(e, e.players[n.target], t) >= 3 && i({
				type: "negotiate",
				card: n.card,
				resource: t,
				score: 3
			});
			r.length || i({
				type: "skip",
				card: n.card,
				score: 0
			});
	}
	return r;
}
function Vt(e, t, n) {
	let r = e.decision;
	if (!Nt(e, t, n)) switch (e.decision = null, r.kind) {
		case "produce":
			t.technologies.find((e) => e.id === n.card).blue++, r.units[n.card]--, C(t) > 0 && Object.values(r.units).some((e) => e > 0) && (e.decision = r);
			break;
		case "removeBlue":
			t.technologies.find((e) => e.id === n.card).blue--, r.n > 1 && (e.decision = {
				...r,
				n: r.n - 1
			});
			break;
		case "losePopulation":
			n.card ? t.technologies.find((e) => e.id === n.card).workers-- : t.pool--, t.yellow++, r.n > 1 && z(e, {
				...r,
				n: r.n - 1
			});
			break;
		case "discardCards": {
			let i = t.militaryHand.findIndex((e) => e.uid === n.source), [a] = t.militaryHand.splice(i, 1);
			e.militaryDiscard[x(a.id, e.config).age].push(a), r.n > 1 && z(e, {
				...r,
				n: r.n - 1
			});
			break;
		}
		case "gainMixed":
			E(e, t, "food", n.n), E(e, t, "ore", r.n - n.n);
			break;
		case "loseMixed":
			A(e, t, "food", n.n), A(e, t, "ore", n.cost);
			break;
		case "boudica":
		case "autonomous":
		case "devMarkets":
			E(e, t, n.resource, n.n);
			break;
		case "saladin": {
			let r = I(e, t);
			t.flags.saladin = n.extra, B(e, t, r);
			break;
		}
		case "homer":
			n.type === "recoverCivil" ? Be(e, t, 1) : t.wonders.find((e) => e.id === n.card).homer = !0;
			break;
		case "jobs":
			if (n.type === "jobs") {
				let r = ct(e, t, n);
				k(e, t, "food", r.food), k(e, t, "ore", r.ore), t.culture += 4;
			}
			break;
		case "devWarfare":
		case "devReligion":
			n.type !== "skip" && (t.pool--, t.technologies.find((e) => e.id === n.card).workers++);
			break;
		case "devCivilization":
		case "freedomMovement":
			n.type !== "skip" && pt(e, t, n);
			break;
		case "planning":
			Lt(e, n.card, t.rid);
			break;
		case "demolish":
		case "terrorism": {
			let t = e.players[n.target];
			t.technologies.find((e) => e.id === n.card).workers--, t.pool++;
			break;
		}
		case "ravages": {
			let r = I(e, t);
			t.wonders.find((e) => e.id === n.card).ruined = !0, B(e, t, r);
			break;
		}
		case "loseColony":
			Ye(e, t, n.card);
			break;
		case "freeColony":
			n.type !== "skip" && (t.militaryHand = t.militaryHand.filter((e) => e.uid !== n.source), Je(e, t, n.card));
			break;
		case "unitedNations":
			n.type !== "skip" && Lt(e, n.card);
			break;
		case "agreementOffer":
			n.type === "agreementAccept" && (t.flags.skipPolitics = !0, e.decision = {
				...r,
				kind: "agreement",
				amount: 5
			});
			break;
		case "agreement":
			if (n.type === "agreementTake") {
				let i = e.row.findIndex((e) => e?.uid === n.source), a = e.row[i];
				e.row[i] = null, Ke(e, t, a), e.decision = {
					...r,
					amount: r.amount - n.civil
				};
			} else z(e, { kind: "refillOnly" });
			break;
		case "negotiations":
			n.type === "negotiate" && me(e, e.players[r.target], e.players[r.extra], n.resource, 3);
			break;
		default: throw Error(`Unhandled decision ${r.kind}`);
	}
}
//#endregion
//#region src/games/throughtheages/engine.ts
function Ht(e) {
	return e.decision?.rid ?? e.auction?.rid ?? (e.phase === "resolve" || e.phase === "done" ? "" : e.turn);
}
function Ut(e) {
	return e.phase === "resolve" && !e.decision && !e.auction;
}
function Wt(e, t) {
	if (e.phase === "done" || !e.players[t] || e.players[t].resigned) return [];
	let n = e.players[t], r = S(e, n, "louvre") && n.wonders.find((e) => e.id === "louvre").blue ? [{
		id: "",
		type: "louvre",
		card: "louvre",
		score: T(e, n, "ore") < 4 ? 7 : -2
	}] : [];
	return t === Ht(e) ? [...e.decision ? Bt(e, n) : e.auction ? Ot(e, n) : e.phase === "action" ? ut(e, n) : e.phase === "politics" ? xt(e, n) : e.phase === "discard" ? n.militaryHand.map((t) => ({
		id: "",
		type: "discard",
		card: t.id,
		source: t.uid,
		score: x(t.id, e.config).kind === "bonus" ? -2 : 0
	})) : [], ...r].map((t, n) => ({
		...t,
		id: `${e.revision}:${n}`
	})) : r.map((t, n) => ({
		...t,
		id: `${e.revision}:${n}`
	}));
}
function Gt(e, t) {
	e.phase = "resolve", e.continuation = t;
}
function Kt(e, t, n) {
	let r = e.players[t];
	if (e.revision++, n.type === "louvre") {
		pt(e, r, n);
		return;
	}
	e.decision ? Vt(e, r, n) : e.auction ? kt(e, r, n) : e.phase === "discard" ? (Ue(e, r, n.source), r.leader === "eleanor" && r.culture++, r.militaryHand.length <= ze(e, r, !0) && (z(e, {
		kind: "endBonuses",
		rid: t
	}), Gt(e, "next"))) : e.phase === "politics" ? n.type === "endPolitics" ? (ht(e), e.queue.length && Gt(e, "action")) : (wt(e, r, n), e.queue.length || e.decision || e.auction ? Gt(e, "politics") : (r.temporary.politics ?? 0) >= gt(e, r) && (ht(e), e.queue.length && Gt(e, "action"))) : n.type === "end" ? (Gt(e, "next"), r.militaryHand.length > ze(e, r, !0) ? e.phase = "discard" : z(e, {
		kind: "endBonuses",
		rid: t
	})) : (pt(e, r, n), (e.queue.length || e.decision || e.auction) && Gt(e, "action"));
}
function qt(e) {
	let t = e.age;
	if (e.age++, R(e, {
		key: "age",
		n: e.age
	}), t > 0) {
		for (let n of Object.values(e.players)) {
			let r = I(e, n), i = (n) => x(n, e.config).age < t;
			n.hand = n.hand.filter((e) => !i(e.id)), n.militaryHand = n.militaryHand.filter((e) => !i(e.id)), n.leader && i(n.leader) && qe(e, n), n.wonders = n.wonders.filter((t) => t.stages === x(t.id, e.config).stages.length || !i(t.id)), M(n, -2), Number(n.flags.hippocrates ?? 0) > 0 && (M(n, 1), n.flags.hippocrates = Number(n.flags.hippocrates) - 1), B(e, n, r);
		}
		for (let n of [...e.pacts].filter((n) => x(n.id, e.config).age < t)) St(e, n.id, n.a, n.b);
	}
	if ((e.age === 2 || e.age === 3) && e.config.rebalance) for (let t of Object.values(e.players)) t.wonders.some((t) => t.id === "colossus" && !t.ruined && t.stages === x(t.id, e.config).stages.length) && He(e, t, 3);
	e.age === 4 && (e.lastRound = e.round + (e.turn === L(e)[0] ? 0 : 1));
}
function Jt(e, t) {
	for (t && e.row.splice(0, L(e).length === 2 ? 3 : L(e).length === 3 ? 2 : 1), e.row = e.row.filter((e) => e !== null); e.row.length < 13 && e.age < 4;) {
		if (!e.civilDecks[e.age].length) {
			qt(e);
			continue;
		}
		e.row.push(e.civilDecks[e.age].shift()), e.civilDecks[e.age].length || qt(e);
	}
	for (; e.row.length < 13;) e.row.push(null);
	t && e.age === 0 && (e.civilDecks[0] = [], qt(e));
}
function Yt(e) {
	e.turn = L(e)[0], z(e, ...[...e.events, ...e.future].filter((t) => x(t.id, e.config).age === 3 && x(t.id, e.config).kind === "event").map((e) => e.id).map((e) => ({
		kind: "finalEvent",
		card: e
	})), { kind: "finalLeaders" }, { kind: "done" }), e.continuation = "done";
}
function Xt(e) {
	let t = e.order.indexOf(e.turn);
	do
		t = (t + 1) % e.order.length;
	while (e.players[e.order[t]].resigned);
	if (t === e.order.indexOf(L(e)[0])) {
		if (e.lastRound !== null && e.round >= e.lastRound) {
			Yt(e);
			return;
		}
		e.round++;
	}
	e.turn = e.order[t];
	let n = e.players[e.turn];
	if (n.flags.turnStart = e.revision, n.flags.flemingLast = n.flags.flemingCurrent ?? "", delete n.flags.flemingCurrent, e.olympics === n.rid && (e.olympics = null), n.leader !== "sunTzu") {
		for (let t of e.tactics.filter((e) => e.owner === n.rid)) t.owner = null;
		for (let t of [...e.tactics].filter((e) => !e.owner && !e.sun)) {
			let n = e.tactics.find((e) => e.uid !== t.uid && e.id === t.id && !e.owner && !e.sun);
			n && (Object.values(e.players).filter((e) => e.tactic === t.uid).forEach((e) => {
				e.tactic = n.uid;
			}), e.tactics = e.tactics.filter((e) => e.uid !== t.uid));
		}
	}
	n.leader === "hippocrates" && (n.flags.hippocrates = Math.min(3, Number(n.flags.hippocrates ?? 0) + 1)), e.round > 1 ? (z(e, { kind: "refill" }, ...e.wars.filter((e) => e.a === n.rid).map((e) => ({
		kind: "warStart",
		rid: e.a,
		target: e.b,
		card: e.id
	}))), e.continuation = "politics") : (e.phase = "action", e.continuation = "action");
}
function Zt(e, t) {
	e.nobel && (t.temporary.technologies ?? 0) >= 2 && V(e, t, "nobel", 4), t.leader === "mandela" && V(e, t, "mandela", Math.max(0, I(e, t).happy - ve(t))), t.leader === "genghis" && Pe(e, (t) => I(e, t).strength).slice(0, L(e).length === 2 ? 1 : 2).includes(t.rid) && (t.culture += 3);
	let n = [{
		kind: "productionStart",
		rid: t.rid
	}];
	t.leader === "saladin" && n.unshift({
		kind: "saladin",
		rid: t.rid
	}), z(e, ...n);
}
function Qt(e) {
	e.revision++;
	let t = e.queue.shift();
	if (t) {
		let n = t.rid ? e.players[t.rid] : void 0;
		switch (t.kind) {
			case "refill":
				Jt(e, !0);
				break;
			case "refillOnly":
				Jt(e, !1);
				break;
			case "endBonuses":
				Zt(e, n);
				break;
			case "productionStart":
				Ne(e, n) > n.pool ? (R(e, {
					key: "uprising",
					rid: n.rid
				}), z(e, {
					kind: "endReset",
					rid: n.rid
				})) : z(e, {
					kind: "productionPoints",
					rid: n.rid
				}, {
					kind: "corruption",
					rid: n.rid
				}, {
					kind: "produceFood",
					rid: n.rid
				}, {
					kind: "consume",
					rid: n.rid
				}, {
					kind: "produceOre",
					rid: n.rid
				}, {
					kind: "endReset",
					rid: n.rid
				});
				break;
			case "productionPoints":
				n.science += I(e, n).science, n.culture += I(e, n).culture;
				break;
			case "corruption": {
				let t = ye(n);
				A(e, n, "food", t - A(e, n, "ore", t)), t && R(e, {
					key: "corruption",
					rid: n.rid,
					n: t
				});
				break;
			}
			case "consume": {
				let t = _e(n), r = A(e, n, "food", t);
				t > r && (A(e, n, "culture", (t - r) * 4), R(e, {
					key: "starvation",
					rid: n.rid,
					n: t - r
				}));
				break;
			}
			case "endReset":
				e.round > 1 && He(e, n, Math.min(3, n.military) + (n.leader === "sunTzu" ? 2 : 0)), xe(n), delete n.flags.kidnap, n.civil = I(e, n).civil, n.military = I(e, n).military, z(e, { kind: "advance" });
				break;
			case "advance":
				Xt(e);
				break;
			case "finalEvent":
				zt(e, {
					kind: "event",
					card: t.card
				});
				break;
			case "finalLeaders":
				for (let t of Object.values(e.players)) t.leader === "billGates" && V(e, t, "billGates", t.technologies.reduce((t, n) => t + (x(n.id, e.config).category === "lab" ? n.workers * x(n.id, e.config).age : 0), 0));
				break;
			case "done":
				e.phase = "done";
				break;
			default: if (!zt(e, t)) throw Error(`Unhandled effect ${t.kind}`);
		}
	}
	if (!(e.phase === "done" || e.decision || e.auction || e.queue.length || e.phase !== "resolve")) {
		if (e.continuation === "action") e.phase = "action";
		else if (e.continuation === "politics") {
			let t = e.players[e.turn];
			t.flags.skipPolitics && (t.temporary.politics ?? 0) < gt(e, t) && (delete t.flags.skipPolitics, t.temporary.politics = (t.temporary.politics ?? 0) + 1, t.temporary.skippedPolitics = 1);
			let n = xt(e, t).some((e) => e.type === "olympics" || e.type === "fleming");
			(t.temporary.politics ?? 0) >= gt(e, t) && !n ? (ht(e), e.queue.length && (e.phase = "resolve")) : e.phase = "politics";
		} else e.continuation === "next" ? Xt(e) : e.continuation === "done" && (e.phase = "done");
	}
}
//#endregion
//#region src/games/throughtheages/meta.ts
var $t = {
	id: "throughtheages",
	tier: "beta",
	mechanics: [
		"engine-building",
		"drafting",
		"action-points",
		"auction"
	],
	interactionTags: [],
	nameKey: "games.throughtheages.name",
	descKey: "games.throughtheages.desc",
	rulesKey: "games.throughtheages.rules",
	icon: "🏛️",
	iconImg: "games/throughtheages.webp",
	rulesUrl: {
		zh: "https://filemanager.czechgames.com/storage/files/through-the-ages-a-new-story-of-civilization/rules/through-the-ages-new-story-rules-zh-s.pdf",
		en: "https://filemanager.czechgames.com/storage/files/through-the-ages-a-new-story-of-civilization/rules/through-the-ages-new-story-rules-en.pdf"
	},
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3],
	accent: "#92633d",
	releasedAt: "2026-10-24T18:43:04+08:00",
	search: {
		py: "li shi ju lun ren lei wen ming xin pian zhang xin ling xiu yu qi ji",
		init: "lsjlrlwmxpzxlxyqj"
	},
	hotseat: "cover"
}, en = t.object({
	rebalance: t.boolean().default(!0),
	militaryExpansion: t.boolean().default(!0),
	leaders: t.enum([
		"base",
		"expansion",
		"secret",
		"public"
	]).default("public"),
	publicCivilHands: t.boolean().default(!0)
}).prefault({}), tn = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	id: t.string().min(1).max(40)
}).strict(), t.object({
	type: t.literal("tick"),
	now: t.number().finite()
}).strict()]), nn = t.object({
	uid: t.string(),
	id: t.string(),
	taken: t.number()
}), rn = t.enum([
	"food",
	"ore",
	"science",
	"culture"
]), an = t.object({
	id: t.string(),
	type: t.string(),
	card: t.string().optional(),
	target: t.string().optional(),
	source: t.string().optional(),
	action: t.string().optional(),
	ability: t.string().optional(),
	n: t.number().optional(),
	extra: t.string().optional(),
	resource: rn.optional(),
	cost: t.number().optional(),
	science: t.number().optional(),
	civil: t.number().optional(),
	military: t.number().optional(),
	foodCost: t.number().optional(),
	alternate: t.number().optional(),
	trade: t.enum(["food", "ore"]).optional(),
	payment: t.object({
		food: t.number(),
		ore: t.number(),
		science: t.number()
	})
}), on = t.object({
	science: t.number(),
	culture: t.number(),
	strength: t.number(),
	happy: t.number(),
	civil: t.number(),
	military: t.number(),
	urban: t.number(),
	colonize: t.number(),
	food: t.number(),
	ore: t.number(),
	armies: t.number()
}), sn = t.object({
	rid: t.string(),
	technologies: t.array(t.object({
		id: t.string(),
		workers: t.number(),
		blue: t.number()
	})),
	government: t.string(),
	leader: t.string().nullable(),
	wonders: t.array(t.object({
		id: t.string(),
		stages: t.number(),
		blue: t.number(),
		ruined: t.boolean(),
		homer: t.boolean()
	})),
	colonies: t.array(t.string()),
	tactic: t.string().nullable(),
	yellow: t.number(),
	yellowTotal: t.number(),
	blueTotal: t.number(),
	blueBank: t.number(),
	pool: t.number(),
	science: t.number(),
	culture: t.number(),
	civil: t.number(),
	military: t.number(),
	food: t.number(),
	ore: t.number(),
	discontent: t.number(),
	ratings: on,
	handCount: t.number(),
	militaryCount: t.number(),
	hand: t.array(nn),
	resigned: t.boolean(),
	final: t.record(t.string(), t.number())
}), cn = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: $t,
	schemas: {
		action: tn,
		publicView: t.object({
			config: en,
			revision: t.number(),
			age: t.number(),
			round: t.number(),
			turn: t.string(),
			acting: t.string(),
			phase: t.enum([
				"action",
				"politics",
				"resolve",
				"discard",
				"done"
			]),
			order: t.array(t.string()),
			players: t.array(sn),
			row: t.array(nn.nullable()),
			deckCounts: t.array(t.number()),
			militaryCounts: t.array(t.number()),
			eventCount: t.number(),
			futureCount: t.number(),
			exposed: t.string(),
			past: t.array(t.string()),
			pools: t.array(t.array(t.string())),
			tactics: t.array(t.object({
				uid: t.string(),
				id: t.string(),
				owner: t.string().nullable(),
				sun: t.boolean()
			})),
			pacts: t.array(t.object({
				id: t.string(),
				a: t.string(),
				b: t.string(),
				owner: t.string()
			})),
			wars: t.array(t.object({
				id: t.string(),
				a: t.string(),
				b: t.string()
			})),
			prompt: t.object({
				kind: t.string(),
				rid: t.string(),
				card: t.string(),
				target: t.string().optional()
			}).nullable(),
			auction: t.object({
				card: t.string(),
				bid: t.number(),
				leader: t.string().nullable(),
				passed: t.array(t.string()),
				rid: t.string()
			}).nullable(),
			lastRound: t.number().nullable(),
			nobel: t.boolean(),
			olympics: t.string().nullable(),
			log: t.array(t.object({
				key: t.string(),
				rid: t.string().optional(),
				target: t.string().optional(),
				card: t.string().optional(),
				n: t.number().optional(),
				resource: t.string().optional()
			}))
		}),
		privateView: t.object({
			hand: t.array(nn),
			militaryHand: t.array(nn),
			moves: t.array(an),
			peek: t.string().nullable(),
			knownEvents: t.array(t.string()),
			spy: t.object({
				rid: t.string(),
				cards: t.array(nn)
			}).nullable(),
			selected: t.array(t.string()),
			units: t.record(t.string(), t.number()),
			paid: t.number(),
			paidFood: t.number(),
			force: t.number(),
			temporary: t.record(t.string(), t.number())
		}),
		config: en
	},
	setup(e, t, n) {
		return { state: et(en.parse(e), t, n) };
	},
	reduce(e, t, { by: n }) {
		if (t.type === "tick") {
			if (n !== "$engine" || !Ut(e)) return { code: "games.throughtheages.invalidAction" };
			let t = structuredClone(e);
			return Qt(t), { state: t };
		}
		let r = Wt(e, n).find((e) => e.id === t.id);
		if (!r) return { code: "games.throughtheages.invalidAction" };
		let i = structuredClone(e);
		return Kt(i, n, r), { state: i };
	},
	viewFor(e, t) {
		let n = e.players[t], r = e.auction;
		return {
			public: {
				config: e.config,
				revision: e.revision,
				age: e.age,
				round: e.round,
				turn: e.turn,
				acting: Ht(e),
				phase: e.phase,
				order: e.order,
				players: e.order.map((t) => {
					let n = e.players[t];
					return {
						rid: t,
						technologies: n.technologies,
						government: n.government,
						leader: n.leader,
						wonders: n.wonders,
						colonies: n.colonies,
						tactic: n.tactic,
						yellow: n.yellow,
						yellowTotal: n.yellowTotal,
						blueTotal: n.blueTotal,
						blueBank: C(n),
						pool: n.pool,
						science: n.science,
						culture: n.culture,
						civil: n.civil,
						military: n.military,
						food: T(e, n, "food"),
						ore: T(e, n, "ore"),
						discontent: Ne(e, n),
						ratings: I(e, n),
						handCount: n.hand.length,
						militaryCount: n.militaryHand.length,
						hand: e.config.publicCivilHands || e.phase === "done" ? n.hand : [],
						resigned: n.resigned,
						final: n.final
					};
				}),
				row: e.row,
				deckCounts: e.civilDecks.map((e) => e.length),
				militaryCounts: e.militaryDecks.map((e) => e.length),
				eventCount: e.events.length,
				futureCount: e.future.length,
				exposed: e.exposed,
				past: e.past,
				pools: e.config.leaders === "public" ? e.pools : [],
				tactics: e.tactics,
				pacts: e.pacts,
				wars: e.wars,
				prompt: e.decision ? {
					kind: e.decision.kind,
					rid: e.decision.rid,
					card: e.decision.card,
					target: e.decision.target
				} : null,
				auction: r ? {
					card: r.card,
					bid: r.bid,
					leader: r.leader,
					passed: r.passed,
					rid: r.rid
				} : null,
				lastRound: e.lastRound,
				nobel: e.nobel,
				olympics: e.olympics,
				log: e.log
			},
			...n ? { private: {
				hand: n.hand,
				militaryHand: n.militaryHand,
				moves: Wt(e, t).map((t) => {
					let r = { ...t };
					delete r.score;
					let i = [
						"population",
						"research",
						"revolution",
						"build",
						"upgrade",
						"wonder",
						"barbarossa",
						"jobs"
					].includes(t.type) ? {
						...ct(e, n, t),
						science: it(e, n, t, !0)
					} : {
						food: 0,
						ore: 0,
						science: 0
					};
					return {
						...r,
						payment: i
					};
				}),
				peek: e.phase === "politics" && t === e.turn && n.leader === "joan" ? e.events[0]?.id ?? null : null,
				knownEvents: (e.knownEvents[t] ?? []).flatMap((t) => {
					let n = [...e.future, ...e.events].find((e) => e.uid === t);
					return n ? [n.id] : [];
				}),
				spy: n.flags.flemingCurrent ? {
					rid: String(n.flags.flemingCurrent),
					cards: JSON.parse(String(n.flags.flemingCards ?? "[]"))
				} : null,
				selected: r?.rid === t ? r.cards : e.decision?.rid === t ? e.decision.selected ?? [] : [],
				units: r?.rid === t ? r.units : e.decision?.rid === t ? e.decision.units ?? {} : {},
				paid: r?.rid === t ? r.paid : 0,
				paidFood: r?.rid === t ? r.paidFood : 0,
				force: r?.rid === t ? Dt(e) : 0,
				temporary: n.temporary
			} } : {}
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = Pe(e, (e) => e.culture), n = e.players[t[0]].culture;
		return {
			phase: "done",
			ranking: t,
			winner: t.filter((t) => e.players[t].culture === n),
			scores: Object.fromEntries(t.map((t) => [t, e.players[t].culture]))
		};
	},
	nextTickIn(e) {
		return Ut(e) ? 160 : null;
	}
}, ln = "<defs>\n<linearGradient id=\"tta-stoneFront\" x2=\"0\" y2=\"1\"><stop stop-color=\"#e4ddc7\"/><stop offset=\"1\" stop-color=\"#b9b89f\"/></linearGradient>\n<linearGradient id=\"tta-stoneSide\" x2=\".8\" y2=\"1\"><stop stop-color=\"#b3b6a2\"/><stop offset=\"1\" stop-color=\"#7e8b80\"/></linearGradient>\n<linearGradient id=\"tta-column\"><stop stop-color=\"#999e88\"/><stop offset=\".36\" stop-color=\"#eee6ce\"/><stop offset=\".67\" stop-color=\"#d3d1b7\"/><stop offset=\"1\" stop-color=\"#909b87\"/></linearGradient>\n<linearGradient id=\"tta-roof\" x2=\".3\" y2=\"1\"><stop stop-color=\"#9a7956\"/><stop offset=\"1\" stop-color=\"#63523c\"/></linearGradient>\n<linearGradient id=\"tta-dome\"><stop stop-color=\"#8fa59c\"/><stop offset=\".35\" stop-color=\"#64877e\"/><stop offset=\"1\" stop-color=\"#3d675f\"/></linearGradient>\n<linearGradient id=\"tta-pyramidFace\" x2=\".8\" y2=\"1\"><stop stop-color=\"#e3d1a2\"/><stop offset=\"1\" stop-color=\"#c1a66e\"/></linearGradient>\n<linearGradient id=\"tta-skin\"><stop stop-color=\"#e0ba94\"/><stop offset=\".5\" stop-color=\"#e6c7a3\"/><stop offset=\"1\" stop-color=\"#b28c6a\"/></linearGradient>\n<linearGradient id=\"tta-portraitGround\" x2=\"1\" y2=\"1\"><stop stop-color=\"#89a3af\"/><stop offset=\"1\" stop-color=\"#cbd8d5\"/></linearGradient>\n<linearGradient id=\"tta-sky2\" x2=\"0\" y2=\"1\"><stop stop-color=\"#83b3ce\"/><stop offset=\".65\" stop-color=\"#bbd8e2\"/><stop offset=\"1\" stop-color=\"#dfebeb\"/></linearGradient>\n<linearGradient id=\"tta-earth2\" x2=\".3\" y2=\"1\"><stop stop-color=\"#a2b969\"/><stop offset=\".6\" stop-color=\"#80a14e\"/><stop offset=\"1\" stop-color=\"#5f883e\"/></linearGradient>\n<linearGradient id=\"tta-river2\" x2=\".7\" y2=\"1\"><stop stop-color=\"#7eb2c7\"/><stop offset=\"1\" stop-color=\"#438caa\"/></linearGradient>\n<pattern id=\"tta-masonry\" width=\"30\" height=\"16\" patternUnits=\"userSpaceOnUse\"><path d=\"M0 0h30M0 8h30m-15-8v8M0 8v8m30-8v8\" stroke=\"#54482f\" stroke-width=\".6\" opacity=\".23\"/></pattern>\n<pattern id=\"tta-tiles\" width=\"17\" height=\"11\" patternTransform=\"rotate(12)\" patternUnits=\"userSpaceOnUse\"><path d=\"M0 10h17M5 0v10m8-10v10\" stroke=\"#dac194\" stroke-width=\".65\" opacity=\".42\"/></pattern>\n<pattern id=\"tta-hatch\" width=\"5\" height=\"5\" patternUnits=\"userSpaceOnUse\"><path d=\"M-1 5l6-6m-1 7 3-3\" stroke=\"#3d3b2d\" stroke-width=\".65\" opacity=\".22\"/></pattern>\n<pattern id=\"tta-engravingVeil\" width=\"4\" height=\"4\" patternUnits=\"userSpaceOnUse\"><path d=\"M0 4l4-4\" stroke=\"#3e3728\" stroke-width=\".4\" opacity=\".12\"/></pattern>\n\n<symbol id=\"tta-i-food\" viewBox=\"0 0 24 24\"><path d=\"M12 23V3m0 6Q4 9 5 3q7 1 7 6m0 6Q3 15 3 9q8 0 9 6m0 5q9-1 9-7-8 0-9 7m0-11q8-3 6-9-7 3-6 9\" fill=\"#b7984f\" stroke=\"#6e5b32\" stroke-width=\"1\" /></symbol>\n<symbol id=\"tta-i-ore\" viewBox=\"0 0 24 24\"><path d=\"M2 17L5 7l11-5 7 11-6 9L4 21Z\" fill=\"#91978a\" stroke=\"#4d584d\" stroke-width=\"1.2\" /><path d=\"M5 7l9 6 3 9m-3-9h9M14 13l2-11\" fill=\"none\" stroke=\"#d0ccb7\" stroke-width=\"1\" /></symbol>\n<symbol id=\"tta-i-science\" viewBox=\"0 0 24 24\"><path d=\"M8 2h8m-6 0v8L4 19q-1 3 3 3h10q4 0 3-3l-6-9V2\" fill=\"#c3c6b0\" stroke=\"#4d6a65\" stroke-width=\"1.5\" /><path d=\"M7 16h10l3 4H4Z\" fill=\"#5d8781\" stroke=\"none\" stroke-width=\"1\" /></symbol>\n<symbol id=\"tta-i-culture\" viewBox=\"0 0 24 24\"><path d=\"M4 3q4 4 4 10t4 8q4-2 4-8t4-10M4 3h5m6 0h5M8 7h8m-8 0v10m4-10v12m4-12v10M7 20q5 4 10 0\" fill=\"none\" stroke=\"#a88640\" stroke-width=\"2\" /></symbol>\n<symbol id=\"tta-i-strength\" viewBox=\"0 0 24 24\"><path d=\"M3 1l5 2 12 15-3 3L4 6Z\" fill=\"#b5b7a6\" stroke=\"#4d574a\" stroke-width=\"1.1\" /><path d=\"M1 16l7 7m-4-4L20 2l3-1-1 4L7 21\" fill=\"#a5ad9d\" stroke=\"#4d574a\" stroke-width=\"1.4\" /></symbol>\n<symbol id=\"tta-i-happy\" viewBox=\"0 0 24 24\"><path d=\"M4 3q8-3 16 0l-1 12q-2 6-7 8-6-3-7-8Z\" fill=\"#ba9c57\" stroke=\"#756138\" stroke-width=\"1.2\" /><path d=\"M7 9l3-1m4 0 3 1M8 14q4 4 8 0m-4-3-1 2h2\" fill=\"none\" stroke=\"#514832\" stroke-width=\"1.3\" /></symbol>\n<symbol id=\"tta-i-civil\" viewBox=\"0 0 24 24\"><path d=\"M3 4h14l4 4v14H7l-4-4Z\" fill=\"#e4dec6\" stroke=\"#9a8d6b\" stroke-width=\"1.2\" /><path d=\"M3 4l4 4h14M7 8v14\" fill=\"none\" stroke=\"#bcb18f\" stroke-width=\"1\" /></symbol>\n<symbol id=\"tta-i-military\" viewBox=\"0 0 24 24\"><path d=\"M3 4h14l4 4v14H7l-4-4Z\" fill=\"#945a48\" stroke=\"#5d4033\" stroke-width=\"1.2\" /><path d=\"M3 4l4 4h14M7 8v14\" fill=\"none\" stroke=\"#c49b78\" stroke-width=\"1\" /></symbol>\n<symbol id=\"tta-i-worker\" viewBox=\"0 0 24 24\"><ellipse cx=\"12\" cy=\"6\" rx=\"3.5\" ry=\"4\" fill=\"#c6a657\" /><path d=\"M7 23l1-11h8l1 11Z\" fill=\"#c6a657\" stroke=\"#8b713a\" stroke-width=\"1\" /></symbol>\n<symbol id=\"tta-a-farm\" viewBox=\"0 0 300 240\"><path d=\"M24 191l138-30 124 32-130 40Z\" fill=\"#3b3428\" stroke=\"none\" stroke-width=\"1\" opacity=\".23\"/><path d=\"M35 126L144 151L144 203L35 180Z\" fill=\"#ded3b8\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M35 126L144 151L144 203L35 180Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M144 151L227 121V176L144 203Z\" fill=\"url(#tta-stoneSide)\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M144 151L227 121V176L144 203Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M48 84L139 103V178L48 157Z\" fill=\"url(#tta-stoneFront)\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M48 84L139 103V178L48 157Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M139 103L215 79V154L139 178Z\" fill=\"url(#tta-stoneSide)\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M139 103L215 79V154L139 178Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M31 85L79 32L232 68L141 110Z\" fill=\"url(#tta-roof)\" stroke=\"#4d4033\" stroke-width=\"1.6\" /><path d=\"M31 85L79 32L232 68L141 110Z\" fill=\"url(#tta-tiles)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M79 32L133 21L232 68L141 110Z\" fill=\"url(#tta-roof)\" stroke=\"#4d4033\" stroke-width=\"1.6\" /><path d=\"M79 32L133 21L232 68L141 110Z\" fill=\"url(#tta-tiles)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M43 84L141 105\" fill=\"none\" stroke=\"#b29266\" stroke-width=\"0.6\" /><path d=\"M51 81L146.8 102.1\" fill=\"none\" stroke=\"#b29266\" stroke-width=\"0.6\" /><path d=\"M59 78L152.6 99.2\" fill=\"none\" stroke=\"#b29266\" stroke-width=\"0.6\" /><path d=\"M67 75L158.4 96.3\" fill=\"none\" stroke=\"#b29266\" stroke-width=\"0.6\" /><path d=\"M75 72L164.2 93.4\" fill=\"none\" stroke=\"#b29266\" stroke-width=\"0.6\" /><path d=\"M83 69L170 90.5\" fill=\"none\" stroke=\"#b29266\" stroke-width=\"0.6\" /><path d=\"M91 66L175.8 87.6\" fill=\"none\" stroke=\"#b29266\" stroke-width=\"0.6\" /><path d=\"M99 63L181.6 84.7\" fill=\"none\" stroke=\"#b29266\" stroke-width=\"0.6\" /><path d=\"M107 60L187.4 81.8\" fill=\"none\" stroke=\"#b29266\" stroke-width=\"0.6\" /><path d=\"M115 57L193.2 78.9\" fill=\"none\" stroke=\"#b29266\" stroke-width=\"0.6\" /><path d=\"M123 54L199 76\" fill=\"none\" stroke=\"#b29266\" stroke-width=\"0.6\" /><path d=\"M131 51L204.8 73.1\" fill=\"none\" stroke=\"#b29266\" stroke-width=\"0.6\" /><path d=\"M139 48L210.6 70.2\" fill=\"none\" stroke=\"#b29266\" stroke-width=\"0.6\" /><path d=\"M147 45L216.39999999999998 67.30000000000001\" fill=\"none\" stroke=\"#b29266\" stroke-width=\"0.6\" /><path d=\"M155 42L222.2 64.4\" fill=\"none\" stroke=\"#b29266\" stroke-width=\"0.6\" /><path d=\"M178 43V16L194 11L203 16V51L190 57Z\" fill=\"#9b8b6e\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M178 43V16L194 11L203 16V51L190 57Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M51 88l86 19v65M52 121l85 19M80 96v67m29-61v68m30-34 73-24m-51-10v66m29-75v66\" fill=\"none\" stroke=\"#5a4a34\" stroke-width=\"4\" /><path d=\"M67 160V128.9Q76 110 85 128.9V160Z\" fill=\"#403d30\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M65 160V128.9Q76 106 87 128.9V160\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /><path d=\"M157 143V128.9Q166 110 175 128.9V143Z\" fill=\"#54625a\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M155 143V128.9Q166 106 177 128.9V143\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /><path d=\"M111 155v15l18 5v-15Z\" fill=\"#534c37\" stroke=\"#a18961\" stroke-width=\"1\" /><path d=\"M119 157L119 171\" fill=\"none\" stroke=\"#b3a080\" stroke-width=\"1\" /><path d=\"M215 138l28-5 8 37-29 6Z\" fill=\"#746045\" stroke=\"#443d31\" stroke-width=\"1.4\" /><ellipse cx=\"231\" cy=\"173\" rx=\"32\" ry=\"34\" fill=\"#453e2d\" /><ellipse cx=\"231\" cy=\"173\" rx=\"27\" ry=\"29\" fill=\"#927a4d\" /><ellipse cx=\"231\" cy=\"173\" rx=\"21\" ry=\"23\" fill=\"#393d31\" /><path d=\"M231 173L261 173\" fill=\"none\" stroke=\"#b39962\" stroke-width=\"3\" /><path d=\"M256 173L260.66313233808125 177.63258210668158\" fill=\"none\" stroke=\"#3f382a\" stroke-width=\"2\" /><path d=\"M231 173L256.98076211353316 188.5\" fill=\"none\" stroke=\"#b39962\" stroke-width=\"3\" /><path d=\"M252.65063509461098 186L254.4474541734941 192.33788549751213\" fill=\"none\" stroke=\"#3f382a\" stroke-width=\"2\" /><path d=\"M231 173L246 199.8467875173176\" fill=\"none\" stroke=\"#b39962\" stroke-width=\"3\" /><path d=\"M243.5 195.5166604983954L241.94904959855342 201.86161808595878\" fill=\"none\" stroke=\"#3f382a\" stroke-width=\"2\" /><path d=\"M231 173L231 204\" fill=\"none\" stroke=\"#b39962\" stroke-width=\"3\" /><path d=\"M231 199L226.51685602579204 203.65190341601732\" fill=\"none\" stroke=\"#3f382a\" stroke-width=\"2\" /><path d=\"M231 173L216 199.8467875173176\" fill=\"none\" stroke=\"#b39962\" stroke-width=\"3\" /><path d=\"M218.5 195.5166604983954L212.28591726047213 197.22903597927723\" fill=\"none\" stroke=\"#3f382a\" stroke-width=\"2\" /><path d=\"M231 173L205.01923788646684 188.5\" fill=\"none\" stroke=\"#b39962\" stroke-width=\"3\" /><path d=\"M209.34936490538902 186L203.06940185229794 184.3140179185052\" fill=\"none\" stroke=\"#3f382a\" stroke-width=\"2\" /><path d=\"M231 173L201 173\" fill=\"none\" stroke=\"#b39962\" stroke-width=\"3\" /><path d=\"M206 173L201.33686766191875 168.36741789331842\" fill=\"none\" stroke=\"#3f382a\" stroke-width=\"2\" /><path d=\"M231 173L205.01923788646684 157.5\" fill=\"none\" stroke=\"#b39962\" stroke-width=\"3\" /><path d=\"M209.34936490538902 160L207.5525458265059 153.66211450248787\" fill=\"none\" stroke=\"#3f382a\" stroke-width=\"2\" /><path d=\"M231 173L216 146.15321248268242\" fill=\"none\" stroke=\"#b39962\" stroke-width=\"3\" /><path d=\"M218.5 150.4833395016046L220.05095040144658 144.13838191404122\" fill=\"none\" stroke=\"#3f382a\" stroke-width=\"2\" /><path d=\"M231 173L231 142\" fill=\"none\" stroke=\"#b39962\" stroke-width=\"3\" /><path d=\"M231 147L235.483143974208 142.34809658398268\" fill=\"none\" stroke=\"#3f382a\" stroke-width=\"2\" /><path d=\"M231 173L246 146.1532124826824\" fill=\"none\" stroke=\"#b39962\" stroke-width=\"3\" /><path d=\"M243.5 150.4833395016046L249.71408273952787 148.7709640207228\" fill=\"none\" stroke=\"#3f382a\" stroke-width=\"2\" /><path d=\"M231 173L256.98076211353316 157.5\" fill=\"none\" stroke=\"#b39962\" stroke-width=\"3\" /><path d=\"M252.65063509461095 160L258.9305981477021 161.6859820814948\" fill=\"none\" stroke=\"#3f382a\" stroke-width=\"2\" /><ellipse cx=\"231\" cy=\"173\" rx=\"5\" ry=\"6\" fill=\"#d0bb87\" /><path d=\"M242 203q17 9 48-3l9 13-47 9Z\" fill=\"#728b88\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M244 206q22 3 40-3m-26 10 28-4\" fill=\"none\" stroke=\"#b0b5a0\" stroke-width=\"1.5\" /><path d=\"M19 186l73 16-12 13-69-14Z\" fill=\"#a8956a\" stroke=\"#706247\" stroke-width=\"1\" /><path d=\"M20 188L13 199\" fill=\"none\" stroke=\"#d4c18d\" stroke-width=\"1\" /><path d=\"M30 190L23 201\" fill=\"none\" stroke=\"#d4c18d\" stroke-width=\"1\" /><path d=\"M40 192L33 203\" fill=\"none\" stroke=\"#d4c18d\" stroke-width=\"1\" /><path d=\"M50 194L43 205\" fill=\"none\" stroke=\"#d4c18d\" stroke-width=\"1\" /><path d=\"M60 196L53 207\" fill=\"none\" stroke=\"#d4c18d\" stroke-width=\"1\" /><path d=\"M70 198L63 209\" fill=\"none\" stroke=\"#d4c18d\" stroke-width=\"1\" /></symbol><symbol id=\"tta-a-mine\" viewBox=\"0 0 300 240\"><path d=\"M24 191l138-30 124 32-130 40Z\" fill=\"#3b3428\" stroke=\"none\" stroke-width=\"1\" opacity=\".23\"/><path d=\"M19 185L28 126L69 74L110 29L161 37L179 68L225 87L275 180L195 208L90 210Z\" fill=\"#6f7466\" stroke=\"#4d5349\" stroke-width=\"1.5\" /><path d=\"M28 126L92 108L110 29L161 37L151 99L225 87L179 136L275 180L195 208L141 161L90 210L19 185Z\" fill=\"#898a72\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M69 74L92 108L110 29L121 89L151 99L161 37M92 108L63 163L141 161L179 136L225 87M63 163L90 210M179 136L212 170L275 180\" fill=\"none\" stroke=\"#b4ae8e\" stroke-width=\"2\" /><path d=\"M31 142l41-30 14 10m51-73 6 28 33 1m-5 109 22-14 25 7m-8-77 18 15\" fill=\"none\" stroke=\"#4c564a\" stroke-width=\"1.8\" /><path d=\"M80 180V135q30-57 67-6v51Z\" fill=\"#252f2c\" stroke=\"#444737\" stroke-width=\"2\" /><path d=\"M76 183V115h80v67M70 112h92\" fill=\"none\" stroke=\"#5a4630\" stroke-width=\"12\" /><path d=\"M78 182V115m77 67V115M72 111h88\" fill=\"none\" stroke=\"#ac8c59\" stroke-width=\"4\" /><path d=\"M80 142l70-25m-70 1 70 26\" fill=\"none\" stroke=\"#68533a\" stroke-width=\"4\" /><path d=\"M93 179L48 224M132 178L104 231\" fill=\"none\" stroke=\"#3c3e34\" stroke-width=\"4\" /><path d=\"M81 190L124 191\" fill=\"none\" stroke=\"#9f8a65\" stroke-width=\"3\" /><path d=\"M76 195L120 196\" fill=\"none\" stroke=\"#9f8a65\" stroke-width=\"3\" /><path d=\"M71 200L116 201\" fill=\"none\" stroke=\"#9f8a65\" stroke-width=\"3\" /><path d=\"M66 205L112 206\" fill=\"none\" stroke=\"#9f8a65\" stroke-width=\"3\" /><path d=\"M61 210L108 211\" fill=\"none\" stroke=\"#9f8a65\" stroke-width=\"3\" /><path d=\"M56 215L104 216\" fill=\"none\" stroke=\"#9f8a65\" stroke-width=\"3\" /><path d=\"M51 220L100 221\" fill=\"none\" stroke=\"#9f8a65\" stroke-width=\"3\" /><path d=\"M137 158l49-9-4 32-37 10Z\" fill=\"#8d7956\" stroke=\"#413d31\" stroke-width=\"2\" /><path d=\"M139 158l5-17 12 6 10-18 16 7 7 13Z\" fill=\"#aab1a4\" stroke=\"#4d574f\" stroke-width=\"1\" /><path d=\"M149 162L154 186\" fill=\"none\" stroke=\"#bdab81\" stroke-width=\"1\" /><path d=\"M171 159L168 183\" fill=\"none\" stroke=\"#bdab81\" stroke-width=\"1\" /><ellipse cx=\"150\" cy=\"189\" rx=\"7\" ry=\"7\" fill=\"#333a32\" /><ellipse cx=\"176\" cy=\"182\" rx=\"7\" ry=\"7\" fill=\"#333a32\" /><path d=\"M222 186l13-16 20 4 13 18-29 11Z\" fill=\"#a4aa98\" stroke=\"#536050\" stroke-width=\"1.3\" /><path d=\"M229 185l11 5 15-15m-15 15v12\" fill=\"none\" stroke=\"#d0cbb0\" stroke-width=\"1\" /></symbol><symbol id=\"tta-a-lab\" viewBox=\"0 0 300 240\"><path d=\"M24 191l138-30 124 32-130 40Z\" fill=\"#3b3428\" stroke=\"none\" stroke-width=\"1\" opacity=\".23\"/><path d=\"M34 156L134 186L264 140V166L134 213L34 183Z\" fill=\"#aa9977\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M34 156L134 186L264 140V166L134 213L34 183Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M47 118L131 145V196L47 171Z\" fill=\"url(#tta-stoneFront)\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M47 118L131 145V196L47 171Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M131 145L247 105V155L131 196Z\" fill=\"url(#tta-stoneSide)\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M131 145L247 105V155L131 196Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M59 161V140.5Q64 130 69 140.5V161Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M57 161V140.5Q64 126 71 140.5V161\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /><path d=\"M76 166V145.5Q81 135 86 145.5V166Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M74 166V145.5Q81 131 88 145.5V166\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /><path d=\"M93 171V150.5Q98 140 103 150.5V171Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M91 171V150.5Q98 136 105 150.5V171\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /><path d=\"M110 176V155.5Q115 145 120 155.5V176Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M108 176V155.5Q115 141 122 155.5V176\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /><g transform=\"translate(145 147) scale(1)\"><path d=\"M0 29V6.050000000000001Q5.5 -5.5 11 6.050000000000001V29Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M-2 29V6.050000000000001Q5.5 -9.5 13 6.050000000000001V29\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /></g><g transform=\"translate(161 141.3) scale(1)\"><path d=\"M0 29V6.050000000000001Q5.5 -5.5 11 6.050000000000001V29Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M-2 29V6.050000000000001Q5.5 -9.5 13 6.050000000000001V29\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /></g><g transform=\"translate(177 135.6) scale(1)\"><path d=\"M0 29V6.050000000000001Q5.5 -5.5 11 6.050000000000001V29Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M-2 29V6.050000000000001Q5.5 -9.5 13 6.050000000000001V29\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /></g><g transform=\"translate(193 129.9) scale(1)\"><path d=\"M0 29V6.050000000000001Q5.5 -5.5 11 6.050000000000001V29Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M-2 29V6.050000000000001Q5.5 -9.5 13 6.050000000000001V29\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /></g><g transform=\"translate(209 124.2) scale(1)\"><path d=\"M0 29V6.050000000000001Q5.5 -5.5 11 6.050000000000001V29Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M-2 29V6.050000000000001Q5.5 -9.5 13 6.050000000000001V29\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /></g><g transform=\"translate(225 118.5) scale(1)\"><path d=\"M0 29V6.050000000000001Q5.5 -5.5 11 6.050000000000001V29Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M-2 29V6.050000000000001Q5.5 -9.5 13 6.050000000000001V29\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /></g><path d=\"M48 114L132 138L250 100V111L132 151L48 124Z\" fill=\"#c8c4a9\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M48 114L132 138L250 100V111L132 151L48 124Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M91 73L144 89L203 69V116L144 135L91 119Z\" fill=\"#d8d3bc\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M91 73L144 89L203 69V116L144 135L91 119Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M144 89L203 69V116L144 135Z\" fill=\"url(#tta-stoneSide)\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M144 89L203 69V116L144 135Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M85 75Q83 28 144 11Q205 31 209 71Q151 109 85 75Z\" fill=\"url(#tta-dome)\" stroke=\"#484c3e\" stroke-width=\"1.4\" /><path d=\"M144 12Q89 39 91 79\" fill=\"none\" stroke=\"#b8b69a\" stroke-width=\"1.3\" /><path d=\"M144 12Q111 39 112 89.89335530324871\" fill=\"none\" stroke=\"#b8b69a\" stroke-width=\"1.3\" /><path d=\"M144 12Q133 39 133 96.34404733750947\" fill=\"none\" stroke=\"#b8b69a\" stroke-width=\"1.3\" /><path d=\"M144 12Q155 39 154 95.72127487006965\" fill=\"none\" stroke=\"#4c5d52\" stroke-width=\"1.3\" /><path d=\"M144 12Q177 39 175 88.27902469278635\" fill=\"none\" stroke=\"#4c5d52\" stroke-width=\"1.3\" /><path d=\"M144 12Q199 39 196 77.05248757845806\" fill=\"none\" stroke=\"#4c5d52\" stroke-width=\"1.3\" /><path d=\"M87 69q57 33 120-4m-115 16q57 30 112-6\" fill=\"none\" stroke=\"#c5b99a\" stroke-width=\"1\" /><path d=\"M142 13V2m-6 4h12\" fill=\"none\" stroke=\"#b8a05c\" stroke-width=\"2\" /><path d=\"M96 87L96 117\" fill=\"none\" stroke=\"#8b7f62\" stroke-width=\"1.2\" /><path d=\"M117 90.36588393923158L117 120.36588393923158\" fill=\"none\" stroke=\"#8b7f62\" stroke-width=\"1.2\" /><path d=\"M138 90.63718970730272L138 120.63718970730272\" fill=\"none\" stroke=\"#8b7f62\" stroke-width=\"1.2\" /><path d=\"M159 87.56448003223947L159 117.56448003223947\" fill=\"none\" stroke=\"#8b7f62\" stroke-width=\"1.2\" /><path d=\"M180 83.9727900187683L180 113.9727900187683\" fill=\"none\" stroke=\"#8b7f62\" stroke-width=\"1.2\" /><path d=\"M204 162l25-10v21l-25 9Z\" fill=\"#b09c72\" stroke=\"#685d44\" stroke-width=\"1\" /><path d=\"M214 158l1-18 22-18 7 6-27 21\" fill=\"none\" stroke=\"#655a40\" stroke-width=\"4\" /></symbol>\n<symbol id=\"tta-a-temple\" viewBox=\"0 0 300 240\"><path d=\"M24 191l138-30 124 32-130 40Z\" fill=\"#3b3428\" stroke=\"none\" stroke-width=\"1\" opacity=\".23\"/><path d=\"M20 190L173 217L284 175V182L174 224L20 197Z\" fill=\"#d8d2bb\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M20 190L173 217L284 175V182L174 224L20 197Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M25 185L174.5 212L280 170V177L175.5 219L25 192Z\" fill=\"#b7baa3\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M25 185L174.5 212L280 170V177L175.5 219L25 192Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M30 180L176 207L276 165V172L177 214L30 187Z\" fill=\"#d8d2bb\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M30 180L176 207L276 165V172L177 214L30 187Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M35 175L177.5 202L272 160V167L178.5 209L35 182Z\" fill=\"#b7baa3\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M35 175L177.5 202L272 160V167L178.5 209L35 182Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M45 88L190 112V193L45 169Z\" fill=\"#514e42\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M45 88L190 112V193L45 169Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M190 112L266 79V160L190 193Z\" fill=\"url(#tta-stoneSide)\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M190 112L266 79V160L190 193Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M194 116l66-29v70l-66 29Z\" fill=\"url(#tta-hatch)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M45 91h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M50 99L50 159\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M53 99L53 159\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M56 99L56 159\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M46 96L60 96\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M46 162L60 162\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M63 94h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M68 102L68 162\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M71 102L71 162\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M74 102L74 162\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M64 99L78 99\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M64 165L78 165\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M81 97h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M86 105L86 165\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M89 105L89 165\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M92 105L92 165\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M82 102L96 102\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M82 168L96 168\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M99 100h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M104 108L104 168\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M107 108L107 168\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M110 108L110 168\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M100 105L114 105\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M100 171L114 171\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M117 103h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M122 111L122 171\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M125 111L125 171\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M128 111L128 171\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M118 108L132 108\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M118 174L132 174\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M135 106h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M140 114L140 174\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M143 114L143 174\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M146 114L146 174\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M136 111L150 111\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M136 177L150 177\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M153 109h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M158 117L158 177\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M161 117L161 177\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M164 117L164 177\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M154 114L168 114\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M154 180L168 180\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M171 112h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M176 120L176 180\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M179 120L179 180\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M182 120L182 180\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M172 117L186 117\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M172 183L186 183\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><g transform=\"translate(199 113) scale(0.91)\"><path d=\"M-3 0h17v5h-2l-1 60h3v7h-17v-7h3l-1-60h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M2 8L2 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M5.5 8L5.5 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M9 8L9 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M-2 5L13 5\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M-2 66L13 66\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /></g><g transform=\"translate(212 108) scale(0.91)\"><path d=\"M-3 0h17v5h-2l-1 60h3v7h-17v-7h3l-1-60h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M2 8L2 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M5.5 8L5.5 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M9 8L9 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M-2 5L13 5\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M-2 66L13 66\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /></g><g transform=\"translate(225 103) scale(0.91)\"><path d=\"M-3 0h17v5h-2l-1 60h3v7h-17v-7h3l-1-60h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M2 8L2 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M5.5 8L5.5 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M9 8L9 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M-2 5L13 5\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M-2 66L13 66\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /></g><g transform=\"translate(238 98) scale(0.91)\"><path d=\"M-3 0h17v5h-2l-1 60h3v7h-17v-7h3l-1-60h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M2 8L2 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M5.5 8L5.5 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M9 8L9 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M-2 5L13 5\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M-2 66L13 66\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /></g><g transform=\"translate(251 93) scale(0.91)\"><path d=\"M-3 0h17v5h-2l-1 60h3v7h-17v-7h3l-1-60h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M2 8L2 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M5.5 8L5.5 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M9 8L9 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M-2 5L13 5\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M-2 66L13 66\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /></g><path d=\"M32 78L117 24L204 106L267 74L182 4L117 24L204 106V118L32 90Z\" fill=\"url(#tta-stoneFront)\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M32 78L117 24L204 106L267 74L182 4L117 24L204 106V118L32 90Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M45 77L117 37L186 101Z\" fill=\"#9c8967\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M45 77L117 37L186 101Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M58 77L117 45L173 96Z\" fill=\"url(#tta-hatch)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M109 60l9-6 12 9 13 22-16-4-8-12-7 8-13-1Z\" fill=\"#d8d4be\" stroke=\"#6d614b\" stroke-width=\"0.8\" /><path d=\"M35 84L203 112\" fill=\"none\" stroke=\"#e7d8b8\" stroke-width=\"2.2\" /><path d=\"M202 112L268 80\" fill=\"none\" stroke=\"#baa881\" stroke-width=\"2\" /><path d=\"M40 91L40 97\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M50 92.65L50 98.65\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M60 94.3L60 100.3\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M70 95.95L70 101.95\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M80 97.6L80 103.6\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M90 99.25L90 105.25\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M100 100.9L100 106.9\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M110 102.55L110 108.55\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M120 104.2L120 110.2\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M130 105.85L130 111.85\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M140 107.5L140 113.5\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M150 109.15L150 115.15\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M160 110.8L160 116.8\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M170 112.45L170 118.45\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M180 114.1L180 120.1\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /></symbol><symbol id=\"tta-a-library\" viewBox=\"0 0 300 240\"><path d=\"M24 191l138-30 124 32-130 40Z\" fill=\"#3b3428\" stroke=\"none\" stroke-width=\"1\" opacity=\".23\"/><g transform=\"translate(3 40) scale(0.88)\"><path d=\"M24 191l138-30 124 32-130 40Z\" fill=\"#3b3428\" stroke=\"none\" stroke-width=\"1\" opacity=\".23\"/><path d=\"M20 190L173 217L284 175V182L174 224L20 197Z\" fill=\"#d8d2bb\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M20 190L173 217L284 175V182L174 224L20 197Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M25 185L174.5 212L280 170V177L175.5 219L25 192Z\" fill=\"#b7baa3\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M25 185L174.5 212L280 170V177L175.5 219L25 192Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M30 180L176 207L276 165V172L177 214L30 187Z\" fill=\"#d8d2bb\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M30 180L176 207L276 165V172L177 214L30 187Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M35 175L177.5 202L272 160V167L178.5 209L35 182Z\" fill=\"#b7baa3\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M35 175L177.5 202L272 160V167L178.5 209L35 182Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M45 88L190 112V193L45 169Z\" fill=\"#514e42\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M45 88L190 112V193L45 169Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M190 112L266 79V160L190 193Z\" fill=\"url(#tta-stoneSide)\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M190 112L266 79V160L190 193Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M194 116l66-29v70l-66 29Z\" fill=\"url(#tta-hatch)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M45 91h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M50 99L50 159\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M53 99L53 159\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M56 99L56 159\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M46 96L60 96\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M46 162L60 162\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M63 94h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M68 102L68 162\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M71 102L71 162\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M74 102L74 162\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M64 99L78 99\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M64 165L78 165\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M81 97h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M86 105L86 165\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M89 105L89 165\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M92 105L92 165\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M82 102L96 102\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M82 168L96 168\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M99 100h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M104 108L104 168\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M107 108L107 168\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M110 108L110 168\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M100 105L114 105\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M100 171L114 171\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M117 103h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M122 111L122 171\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M125 111L125 171\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M128 111L128 171\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M118 108L132 108\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M118 174L132 174\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M135 106h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M140 114L140 174\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M143 114L143 174\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M146 114L146 174\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M136 111L150 111\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M136 177L150 177\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M153 109h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M158 117L158 177\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M161 117L161 177\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M164 117L164 177\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M154 114L168 114\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M154 180L168 180\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M171 112h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M176 120L176 180\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M179 120L179 180\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M182 120L182 180\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M172 117L186 117\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M172 183L186 183\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><g transform=\"translate(199 113) scale(0.91)\"><path d=\"M-3 0h17v5h-2l-1 60h3v7h-17v-7h3l-1-60h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M2 8L2 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M5.5 8L5.5 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M9 8L9 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M-2 5L13 5\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M-2 66L13 66\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /></g><g transform=\"translate(212 108) scale(0.91)\"><path d=\"M-3 0h17v5h-2l-1 60h3v7h-17v-7h3l-1-60h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M2 8L2 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M5.5 8L5.5 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M9 8L9 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M-2 5L13 5\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M-2 66L13 66\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /></g><g transform=\"translate(225 103) scale(0.91)\"><path d=\"M-3 0h17v5h-2l-1 60h3v7h-17v-7h3l-1-60h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M2 8L2 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M5.5 8L5.5 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M9 8L9 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M-2 5L13 5\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M-2 66L13 66\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /></g><g transform=\"translate(238 98) scale(0.91)\"><path d=\"M-3 0h17v5h-2l-1 60h3v7h-17v-7h3l-1-60h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M2 8L2 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M5.5 8L5.5 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M9 8L9 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M-2 5L13 5\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M-2 66L13 66\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /></g><g transform=\"translate(251 93) scale(0.91)\"><path d=\"M-3 0h17v5h-2l-1 60h3v7h-17v-7h3l-1-60h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M2 8L2 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M5.5 8L5.5 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M9 8L9 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M-2 5L13 5\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M-2 66L13 66\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /></g><path d=\"M32 78L117 24L204 106L267 74L182 4L117 24L204 106V118L32 90Z\" fill=\"url(#tta-stoneFront)\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M32 78L117 24L204 106L267 74L182 4L117 24L204 106V118L32 90Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M45 77L117 37L186 101Z\" fill=\"#9c8967\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M45 77L117 37L186 101Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M58 77L117 45L173 96Z\" fill=\"url(#tta-hatch)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M109 60l9-6 12 9 13 22-16-4-8-12-7 8-13-1Z\" fill=\"#d8d4be\" stroke=\"#6d614b\" stroke-width=\"0.8\" /><path d=\"M35 84L203 112\" fill=\"none\" stroke=\"#e7d8b8\" stroke-width=\"2.2\" /><path d=\"M202 112L268 80\" fill=\"none\" stroke=\"#baa881\" stroke-width=\"2\" /><path d=\"M40 91L40 97\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M50 92.65L50 98.65\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M60 94.3L60 100.3\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M70 95.95L70 101.95\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M80 97.6L80 103.6\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M90 99.25L90 105.25\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M100 100.9L100 106.9\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M110 102.55L110 108.55\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M120 104.2L120 110.2\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M130 105.85L130 111.85\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M140 107.5L140 113.5\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M150 109.15L150 115.15\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M160 110.8L160 116.8\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M170 112.45L170 118.45\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M180 114.1L180 120.1\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /></g><g transform=\"translate(5 37) scale(0.98)\"><path d=\"M73 60L138 72L209 43V1L138 28L73 17Z\" fill=\"#c6c7af\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M73 60L138 72L209 43V1L138 28L73 17Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M73 17L138 28V72L73 60Z\" fill=\"#e0d6b9\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M73 17L138 28V72L73 60Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M80 53V33.95Q84.5 24.5 89 33.95V53Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M78 53V33.95Q84.5 20.5 91 33.95V53\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /><path d=\"M94 55.6V36.550000000000004Q98.5 27.1 103 36.550000000000004V55.6Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M92 55.6V36.550000000000004Q98.5 23.1 105 36.550000000000004V55.6\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /><path d=\"M108 58.2V39.150000000000006Q112.5 29.700000000000003 117 39.150000000000006V58.2Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M106 58.2V39.150000000000006Q112.5 25.700000000000003 119 39.150000000000006V58.2\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /><path d=\"M122 60.8V41.75Q126.5 32.3 131 41.75V60.8Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M120 60.8V41.75Q126.5 28.299999999999997 133 41.75V60.8\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /><g transform=\"translate(148 36) scale(1)\"><path d=\"M0 23V4.95Q4.5 -4.5 9 4.95V23Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M-2 23V4.95Q4.5 -8.5 11 4.95V23\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /></g><g transform=\"translate(161 31) scale(1)\"><path d=\"M0 23V4.95Q4.5 -4.5 9 4.95V23Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M-2 23V4.95Q4.5 -8.5 11 4.95V23\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /></g><g transform=\"translate(174 26) scale(1)\"><path d=\"M0 23V4.95Q4.5 -4.5 9 4.95V23Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M-2 23V4.95Q4.5 -8.5 11 4.95V23\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /></g><g transform=\"translate(187 21) scale(1)\"><path d=\"M0 23V4.95Q4.5 -4.5 9 4.95V23Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M-2 23V4.95Q4.5 -8.5 11 4.95V23\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /></g><path d=\"M64 16L132-23L220 0L141 34Z\" fill=\"url(#tta-roof)\" stroke=\"#4d4033\" stroke-width=\"1.6\" /><path d=\"M64 16L132-23L220 0L141 34Z\" fill=\"url(#tta-tiles)\" stroke=\"none\" stroke-width=\"1\" /></g></symbol><symbol id=\"tta-a-pyramid\" viewBox=\"0 0 300 240\"><path d=\"M9 196L143 16L281 184L159 229Z\" fill=\"#c5b17e\" stroke=\"#6e6147\" stroke-width=\"1.5\" /><path d=\"M143 16L159 229L9 196Z\" fill=\"url(#tta-pyramidFace)\" stroke=\"#8c7953\" stroke-width=\"1\" /><path d=\"M143 16L159 229L281 184Z\" fill=\"#978158\" stroke=\"#6e6147\" stroke-width=\"1\" /><path d=\"M137.64 23.2L143.64 24.52\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M143.64 24.52L148.52 22.72\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M132.28 30.4L144.28 33.04\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M144.28 33.04L154.04 29.439999999999998\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M126.92 37.6L144.92 41.56\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M144.92 41.56L159.56 36.160000000000004\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M121.56 44.8L145.56 50.08\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M145.56 50.08L165.08 42.879999999999995\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M116.2 52L146.2 58.6\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M146.2 58.6L170.6 49.6\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M110.84 59.2L146.84 67.12\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M146.84 67.12L176.12 56.32000000000001\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M105.47999999999999 66.40000000000002L147.48 75.64000000000001\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M147.48 75.64000000000001L181.64 63.04000000000001\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M100.12 73.6L148.12 84.16\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M148.12 84.16L187.16 69.75999999999999\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M94.76 80.8L148.76 92.67999999999999\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M148.76 92.67999999999999L192.68 76.47999999999999\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M89.4 88L149.4 101.2\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M149.4 101.2L198.2 83.2\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M84.03999999999999 95.2L150.04 109.72\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M150.04 109.72L203.72 89.92\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M78.68 102.39999999999999L150.68 118.24\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M150.68 118.24L209.24 96.64\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M73.32 109.60000000000001L151.32 126.76\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M151.32 126.76L214.76 103.36\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M67.96 116.80000000000003L151.96 135.28000000000003\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M151.96 135.28000000000003L220.28 110.08000000000003\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M62.60000000000001 124.00000000000001L152.6 143.8\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M152.6 143.8L225.8 116.80000000000001\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M57.239999999999995 131.2L153.24 152.32\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M153.24 152.32L231.32 123.52\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M51.879999999999995 138.4L153.88 160.84\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M153.88 160.84L236.84 130.24\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M46.52000000000001 145.6L154.52 169.35999999999999\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M154.52 169.35999999999999L242.36 136.95999999999998\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M41.16 152.79999999999998L155.16 177.88\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M155.16 177.88L247.88 143.68\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M35.8 160L155.8 186.4\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M155.8 186.4L253.4 150.4\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M30.439999999999998 167.2L156.44 194.92\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M156.44 194.92L258.92 157.12\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M25.08 174.4L157.08 203.44\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M157.08 203.44L264.44 163.84\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M19.72 181.6L157.72 211.96\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M157.72 211.96L269.96000000000004 170.56\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M14.360000000000014 188.79999999999998L158.36 220.48\" fill=\"none\" stroke=\"#8c784f\" stroke-width=\"0.9\" /><path d=\"M158.36 220.48L275.48 177.28\" fill=\"none\" stroke=\"#554d35\" stroke-width=\"0.8\" /><path d=\"M141 35L143 39\" fill=\"none\" stroke=\"#d9c79b\" stroke-width=\"0.9\" /><path d=\"M132 47L135 51\" fill=\"none\" stroke=\"#d9c79b\" stroke-width=\"0.9\" /><path d=\"M123 59L127 63\" fill=\"none\" stroke=\"#d9c79b\" stroke-width=\"0.9\" /><path d=\"M114 71L119 75\" fill=\"none\" stroke=\"#d9c79b\" stroke-width=\"0.9\" /><path d=\"M105 83L111 87\" fill=\"none\" stroke=\"#d9c79b\" stroke-width=\"0.9\" /><path d=\"M96 95L103 99\" fill=\"none\" stroke=\"#d9c79b\" stroke-width=\"0.9\" /><path d=\"M87 107L95 111\" fill=\"none\" stroke=\"#d9c79b\" stroke-width=\"0.9\" /><path d=\"M78 119L87 123\" fill=\"none\" stroke=\"#d9c79b\" stroke-width=\"0.9\" /><path d=\"M69 131L79 135\" fill=\"none\" stroke=\"#d9c79b\" stroke-width=\"0.9\" /><path d=\"M60 143L71 147\" fill=\"none\" stroke=\"#d9c79b\" stroke-width=\"0.9\" /><path d=\"M51 155L63 159\" fill=\"none\" stroke=\"#d9c79b\" stroke-width=\"0.9\" /><path d=\"M42 167L55 171\" fill=\"none\" stroke=\"#d9c79b\" stroke-width=\"0.9\" /><path d=\"M93 195l11-19 7 23Z\" fill=\"#514a36\" stroke=\"#6e6147\" stroke-width=\"1\" /><path d=\"M20 198l40 6 12-6 18 12-16 7-43-4Z\" fill=\"#9a875e\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M204 209l34-50 48 43-43 17Z\" fill=\"#bcaa7e\" stroke=\"#756349\" stroke-width=\"1\" /><path d=\"M238 159l5 60 43-17Z\" fill=\"#826d48\" stroke=\"#756349\" stroke-width=\"1\" /></symbol>\n<symbol id=\"tta-a-wall\" viewBox=\"0 0 300 240\"><path d=\"M7 198L49 134L75 149L132 81L174 93L197 131L246 76L289 178L234 211L178 168L137 185L75 216Z\" fill=\"#777960\" stroke=\"#555c49\" stroke-width=\"1\" /><path d=\"M10 187L49 157L77 174L134 111L163 118L195 161L248 113L277 165\" fill=\"none\" stroke=\"#3e493d\" stroke-width=\"24\" /><path d=\"M10 177L49 147L77 164L134 101L163 108L195 151L248 103L277 155\" fill=\"none\" stroke=\"#c6b38a\" stroke-width=\"19\" /><path d=\"M10 169L49 139L77 156L134 93L163 100L195 143L248 95L277 147\" fill=\"none\" stroke=\"#6d654e\" stroke-width=\"7\" /><path d=\"M18 165L18 174\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M29 156.43279646920968L29 165.43279646920968\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M40 149.2181660002105L40 158.2181660002105\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M51 144.49514010872102L51 153.49514010872102\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M62 143.00938073308689L62 152.00938073308689\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M73 144.995456609835L73 153.995456609835\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M84 150.1398100278747L84 159.1398100278747\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M95 157.6302606965701L95 166.6302606965701\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M106 166.28423115540676L106 175.28423115540676\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M117 174.73544975248674L117 183.73544975248674\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M128 181.64965489677442L128 190.64965489677442\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M139 185.93524562556937L139 194.93524562556937\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M150 186.9156213943885L150 195.9156213943885\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M161 184.43600242584336L161 193.43600242584336\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M172 178.88786603319107L172 187.88786603319107\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M183 171.14714096037636L183 180.14714096037636\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M194 162.43591749328914L194 171.43591749328914\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M205 154.12950627495061L205 163.12950627495061\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M216 147.53930699531864L216 156.53930699531864\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M227 143.7057672153073L227 152.7057672153073\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M238 143.2341185742856L238 152.2341185742856\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M249 146.19882402205783L249 155.19882402205783\" fill=\"none\" stroke=\"#988966\" stroke-width=\"3\" /><path d=\"M36 163V116l25-9 24 11v42l-25 13Z\" fill=\"#b8a17a\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M36 163V116l25-9 24 11v42l-25 13Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M61 173V125l24-7v42Z\" fill=\"#8a795c\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M61 173V125l24-7v42Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M30 115l28-20 32 22-27 10Z\" fill=\"#4f5748\" stroke=\"#4a4c3a\" stroke-width=\"1\" /><rect x=\"46\" y=\"130\" width=\"6\" height=\"12\" fill=\"#394238\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M40 149L56 155\" fill=\"none\" stroke=\"#e0cda0\" stroke-width=\"1\" /><path d=\"M123 112V65l25-9 24 11v42l-25 13Z\" fill=\"#b8a17a\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M123 112V65l25-9 24 11v42l-25 13Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M148 122V74l24-7v42Z\" fill=\"#8a795c\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M148 122V74l24-7v42Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M117 64l28-20 32 22-27 10Z\" fill=\"#4f5748\" stroke=\"#4a4c3a\" stroke-width=\"1\" /><rect x=\"133\" y=\"79\" width=\"6\" height=\"12\" fill=\"#394238\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M127 98L143 104\" fill=\"none\" stroke=\"#e0cda0\" stroke-width=\"1\" /><path d=\"M224 110V63l25-9 24 11v42l-25 13Z\" fill=\"#b8a17a\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M224 110V63l25-9 24 11v42l-25 13Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M249 120V72l24-7v42Z\" fill=\"#8a795c\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M249 120V72l24-7v42Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M218 62l28-20 32 22-27 10Z\" fill=\"#4f5748\" stroke=\"#4a4c3a\" stroke-width=\"1\" /><rect x=\"234\" y=\"77\" width=\"6\" height=\"12\" fill=\"#394238\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M228 96L244 102\" fill=\"none\" stroke=\"#e0cda0\" stroke-width=\"1\" /><path d=\"M256 103v104m20-90v77m-29-53h40m-40 28h40m-31-66 20 91m0-77-20 90\" fill=\"none\" stroke=\"#836643\" stroke-width=\"3\" /><path d=\"M256 103v104m-9-66h40\" fill=\"none\" stroke=\"#d2b079\" stroke-width=\"1\" /></symbol><symbol id=\"tta-a-army\" viewBox=\"0 0 300 240\"><path d=\"M13 199l139-35 139 29-136 35Z\" fill=\"#3f4737\" stroke=\"none\" stroke-width=\"1\" opacity=\".2\"/><g transform=\"translate(40 63) scale(0.94)\"><path d=\"M19 18q-7 3-8 11l-4 27 10 2 5-22 8 8 4-5-9-18Z\" fill=\"#766a4e\" stroke=\"#343b32\" stroke-width=\"0.8\" /><path d=\"M12 31l-2 23 17 2-2-26Z\" fill=\"#71756a\" stroke=\"#333d35\" stroke-width=\"1\" /><path d=\"M9 52l-2 15 22 1-3-15Z\" fill=\"#7d4b39\" stroke=\"#4a3b2c\" stroke-width=\"1\" /><path d=\"M12 67L8 88l-3 4h9l5-25m6 0 3 22 6 2-1 4H24l-6-27\" fill=\"#6c6752\" stroke=\"#353a31\" stroke-width=\"1\" /><ellipse cx=\"19\" cy=\"16\" rx=\"5.8\" ry=\"7.6\" fill=\"#a38d69\" /><path d=\"M12 16q-1-11 7-11 8 0 7 12l-4-1-1-7-3 2-1 7Z\" fill=\"#92978a\" stroke=\"#38463d\" stroke-width=\"0.9\" /><path d=\"M19 5l1-5 4 2-1 5Z\" fill=\"#754539\" stroke=\"#4a3c2e\" stroke-width=\"0.8\" /><path d=\"M8 33q-13 6-7 25 12 2 18-9l-6-14Z\" fill=\"#6b7563\" stroke=\"#3c473b\" stroke-width=\"1.2\" /><path d=\"M7 36l-1 18m-4-9 10 2\" fill=\"none\" stroke=\"#b7aa7c\" stroke-width=\"0.8\" /><path d=\"M34 21l-1 61m0-64 1-13 4 12Z\" fill=\"#b6b9a7\" stroke=\"#4d5546\" stroke-width=\"1\" /></g><g transform=\"translate(78 63) scale(0.94)\"><path d=\"M19 18q-7 3-8 11l-4 27 10 2 5-22 8 8 4-5-9-18Z\" fill=\"#766a4e\" stroke=\"#343b32\" stroke-width=\"0.8\" /><path d=\"M12 31l-2 23 17 2-2-26Z\" fill=\"#71756a\" stroke=\"#333d35\" stroke-width=\"1\" /><path d=\"M9 52l-2 15 22 1-3-15Z\" fill=\"#7d4b39\" stroke=\"#4a3b2c\" stroke-width=\"1\" /><path d=\"M12 67L8 88l-3 4h9l5-25m6 0 3 22 6 2-1 4H24l-6-27\" fill=\"#6c6752\" stroke=\"#353a31\" stroke-width=\"1\" /><ellipse cx=\"19\" cy=\"16\" rx=\"5.8\" ry=\"7.6\" fill=\"#a38d69\" /><path d=\"M12 16q-1-11 7-11 8 0 7 12l-4-1-1-7-3 2-1 7Z\" fill=\"#92978a\" stroke=\"#38463d\" stroke-width=\"0.9\" /><path d=\"M19 5l1-5 4 2-1 5Z\" fill=\"#754539\" stroke=\"#4a3c2e\" stroke-width=\"0.8\" /><path d=\"M8 33q-13 6-7 25 12 2 18-9l-6-14Z\" fill=\"#6b7563\" stroke=\"#3c473b\" stroke-width=\"1.2\" /><path d=\"M7 36l-1 18m-4-9 10 2\" fill=\"none\" stroke=\"#b7aa7c\" stroke-width=\"0.8\" /><path d=\"M34 21l-1 61m0-64 1-13 4 12Z\" fill=\"#b6b9a7\" stroke=\"#4d5546\" stroke-width=\"1\" /></g><g transform=\"translate(116 63) scale(0.94)\"><path d=\"M19 18q-7 3-8 11l-4 27 10 2 5-22 8 8 4-5-9-18Z\" fill=\"#766a4e\" stroke=\"#343b32\" stroke-width=\"0.8\" /><path d=\"M12 31l-2 23 17 2-2-26Z\" fill=\"#71756a\" stroke=\"#333d35\" stroke-width=\"1\" /><path d=\"M9 52l-2 15 22 1-3-15Z\" fill=\"#7d4b39\" stroke=\"#4a3b2c\" stroke-width=\"1\" /><path d=\"M12 67L8 88l-3 4h9l5-25m6 0 3 22 6 2-1 4H24l-6-27\" fill=\"#6c6752\" stroke=\"#353a31\" stroke-width=\"1\" /><ellipse cx=\"19\" cy=\"16\" rx=\"5.8\" ry=\"7.6\" fill=\"#a38d69\" /><path d=\"M12 16q-1-11 7-11 8 0 7 12l-4-1-1-7-3 2-1 7Z\" fill=\"#92978a\" stroke=\"#38463d\" stroke-width=\"0.9\" /><path d=\"M19 5l1-5 4 2-1 5Z\" fill=\"#754539\" stroke=\"#4a3c2e\" stroke-width=\"0.8\" /><path d=\"M8 33q-13 6-7 25 12 2 18-9l-6-14Z\" fill=\"#6b7563\" stroke=\"#3c473b\" stroke-width=\"1.2\" /><path d=\"M7 36l-1 18m-4-9 10 2\" fill=\"none\" stroke=\"#b7aa7c\" stroke-width=\"0.8\" /><path d=\"M34 21l-1 61m0-64 1-13 4 12Z\" fill=\"#b6b9a7\" stroke=\"#4d5546\" stroke-width=\"1\" /></g><g transform=\"translate(154 63) scale(0.94)\"><path d=\"M19 18q-7 3-8 11l-4 27 10 2 5-22 8 8 4-5-9-18Z\" fill=\"#766a4e\" stroke=\"#343b32\" stroke-width=\"0.8\" /><path d=\"M12 31l-2 23 17 2-2-26Z\" fill=\"#71756a\" stroke=\"#333d35\" stroke-width=\"1\" /><path d=\"M9 52l-2 15 22 1-3-15Z\" fill=\"#7d4b39\" stroke=\"#4a3b2c\" stroke-width=\"1\" /><path d=\"M12 67L8 88l-3 4h9l5-25m6 0 3 22 6 2-1 4H24l-6-27\" fill=\"#6c6752\" stroke=\"#353a31\" stroke-width=\"1\" /><ellipse cx=\"19\" cy=\"16\" rx=\"5.8\" ry=\"7.6\" fill=\"#a38d69\" /><path d=\"M12 16q-1-11 7-11 8 0 7 12l-4-1-1-7-3 2-1 7Z\" fill=\"#92978a\" stroke=\"#38463d\" stroke-width=\"0.9\" /><path d=\"M19 5l1-5 4 2-1 5Z\" fill=\"#754539\" stroke=\"#4a3c2e\" stroke-width=\"0.8\" /><path d=\"M8 33q-13 6-7 25 12 2 18-9l-6-14Z\" fill=\"#6b7563\" stroke=\"#3c473b\" stroke-width=\"1.2\" /><path d=\"M7 36l-1 18m-4-9 10 2\" fill=\"none\" stroke=\"#b7aa7c\" stroke-width=\"0.8\" /><path d=\"M34 21l-1 61m0-64 1-13 4 12Z\" fill=\"#b6b9a7\" stroke=\"#4d5546\" stroke-width=\"1\" /></g><g transform=\"translate(192 63) scale(0.94)\"><path d=\"M19 18q-7 3-8 11l-4 27 10 2 5-22 8 8 4-5-9-18Z\" fill=\"#766a4e\" stroke=\"#343b32\" stroke-width=\"0.8\" /><path d=\"M12 31l-2 23 17 2-2-26Z\" fill=\"#71756a\" stroke=\"#333d35\" stroke-width=\"1\" /><path d=\"M9 52l-2 15 22 1-3-15Z\" fill=\"#7d4b39\" stroke=\"#4a3b2c\" stroke-width=\"1\" /><path d=\"M12 67L8 88l-3 4h9l5-25m6 0 3 22 6 2-1 4H24l-6-27\" fill=\"#6c6752\" stroke=\"#353a31\" stroke-width=\"1\" /><ellipse cx=\"19\" cy=\"16\" rx=\"5.8\" ry=\"7.6\" fill=\"#a38d69\" /><path d=\"M12 16q-1-11 7-11 8 0 7 12l-4-1-1-7-3 2-1 7Z\" fill=\"#92978a\" stroke=\"#38463d\" stroke-width=\"0.9\" /><path d=\"M19 5l1-5 4 2-1 5Z\" fill=\"#754539\" stroke=\"#4a3c2e\" stroke-width=\"0.8\" /><path d=\"M8 33q-13 6-7 25 12 2 18-9l-6-14Z\" fill=\"#6b7563\" stroke=\"#3c473b\" stroke-width=\"1.2\" /><path d=\"M7 36l-1 18m-4-9 10 2\" fill=\"none\" stroke=\"#b7aa7c\" stroke-width=\"0.8\" /><path d=\"M34 21l-1 61m0-64 1-13 4 12Z\" fill=\"#b6b9a7\" stroke=\"#4d5546\" stroke-width=\"1\" /></g><g transform=\"translate(37 95) scale(1.12)\"><path d=\"M19 18q-7 3-8 11l-4 27 10 2 5-22 8 8 4-5-9-18Z\" fill=\"#766a4e\" stroke=\"#343b32\" stroke-width=\"0.8\" /><path d=\"M12 31l-2 23 17 2-2-26Z\" fill=\"#71756a\" stroke=\"#333d35\" stroke-width=\"1\" /><path d=\"M9 52l-2 15 22 1-3-15Z\" fill=\"#7d4b39\" stroke=\"#4a3b2c\" stroke-width=\"1\" /><path d=\"M12 67L8 88l-3 4h9l5-25m6 0 3 22 6 2-1 4H24l-6-27\" fill=\"#6c6752\" stroke=\"#353a31\" stroke-width=\"1\" /><ellipse cx=\"19\" cy=\"16\" rx=\"5.8\" ry=\"7.6\" fill=\"#a38d69\" /><path d=\"M12 16q-1-11 7-11 8 0 7 12l-4-1-1-7-3 2-1 7Z\" fill=\"#92978a\" stroke=\"#38463d\" stroke-width=\"0.9\" /><path d=\"M19 5l1-5 4 2-1 5Z\" fill=\"#754539\" stroke=\"#4a3c2e\" stroke-width=\"0.8\" /><path d=\"M8 33q-13 6-7 25 12 2 18-9l-6-14Z\" fill=\"#6b7563\" stroke=\"#3c473b\" stroke-width=\"1.2\" /><path d=\"M7 36l-1 18m-4-9 10 2\" fill=\"none\" stroke=\"#b7aa7c\" stroke-width=\"0.8\" /><path d=\"M34 21l-1 61m0-64 1-13 4 12Z\" fill=\"#b6b9a7\" stroke=\"#4d5546\" stroke-width=\"1\" /></g><g transform=\"translate(86 95) scale(1.12)\"><path d=\"M19 18q-7 3-8 11l-4 27 10 2 5-22 8 8 4-5-9-18Z\" fill=\"#766a4e\" stroke=\"#343b32\" stroke-width=\"0.8\" /><path d=\"M12 31l-2 23 17 2-2-26Z\" fill=\"#71756a\" stroke=\"#333d35\" stroke-width=\"1\" /><path d=\"M9 52l-2 15 22 1-3-15Z\" fill=\"#7d4b39\" stroke=\"#4a3b2c\" stroke-width=\"1\" /><path d=\"M12 67L8 88l-3 4h9l5-25m6 0 3 22 6 2-1 4H24l-6-27\" fill=\"#6c6752\" stroke=\"#353a31\" stroke-width=\"1\" /><ellipse cx=\"19\" cy=\"16\" rx=\"5.8\" ry=\"7.6\" fill=\"#a38d69\" /><path d=\"M12 16q-1-11 7-11 8 0 7 12l-4-1-1-7-3 2-1 7Z\" fill=\"#92978a\" stroke=\"#38463d\" stroke-width=\"0.9\" /><path d=\"M19 5l1-5 4 2-1 5Z\" fill=\"#754539\" stroke=\"#4a3c2e\" stroke-width=\"0.8\" /><path d=\"M8 33q-13 6-7 25 12 2 18-9l-6-14Z\" fill=\"#6b7563\" stroke=\"#3c473b\" stroke-width=\"1.2\" /><path d=\"M7 36l-1 18m-4-9 10 2\" fill=\"none\" stroke=\"#b7aa7c\" stroke-width=\"0.8\" /><path d=\"M34 21l-1 61m0-64 1-13 4 12Z\" fill=\"#b6b9a7\" stroke=\"#4d5546\" stroke-width=\"1\" /></g><g transform=\"translate(135 95) scale(1.12)\"><path d=\"M19 18q-7 3-8 11l-4 27 10 2 5-22 8 8 4-5-9-18Z\" fill=\"#766a4e\" stroke=\"#343b32\" stroke-width=\"0.8\" /><path d=\"M12 31l-2 23 17 2-2-26Z\" fill=\"#71756a\" stroke=\"#333d35\" stroke-width=\"1\" /><path d=\"M9 52l-2 15 22 1-3-15Z\" fill=\"#7d4b39\" stroke=\"#4a3b2c\" stroke-width=\"1\" /><path d=\"M12 67L8 88l-3 4h9l5-25m6 0 3 22 6 2-1 4H24l-6-27\" fill=\"#6c6752\" stroke=\"#353a31\" stroke-width=\"1\" /><ellipse cx=\"19\" cy=\"16\" rx=\"5.8\" ry=\"7.6\" fill=\"#a38d69\" /><path d=\"M12 16q-1-11 7-11 8 0 7 12l-4-1-1-7-3 2-1 7Z\" fill=\"#92978a\" stroke=\"#38463d\" stroke-width=\"0.9\" /><path d=\"M19 5l1-5 4 2-1 5Z\" fill=\"#754539\" stroke=\"#4a3c2e\" stroke-width=\"0.8\" /><path d=\"M8 33q-13 6-7 25 12 2 18-9l-6-14Z\" fill=\"#6b7563\" stroke=\"#3c473b\" stroke-width=\"1.2\" /><path d=\"M7 36l-1 18m-4-9 10 2\" fill=\"none\" stroke=\"#b7aa7c\" stroke-width=\"0.8\" /><path d=\"M34 21l-1 61m0-64 1-13 4 12Z\" fill=\"#b6b9a7\" stroke=\"#4d5546\" stroke-width=\"1\" /></g><g transform=\"translate(184 95) scale(1.12)\"><path d=\"M19 18q-7 3-8 11l-4 27 10 2 5-22 8 8 4-5-9-18Z\" fill=\"#766a4e\" stroke=\"#343b32\" stroke-width=\"0.8\" /><path d=\"M12 31l-2 23 17 2-2-26Z\" fill=\"#71756a\" stroke=\"#333d35\" stroke-width=\"1\" /><path d=\"M9 52l-2 15 22 1-3-15Z\" fill=\"#7d4b39\" stroke=\"#4a3b2c\" stroke-width=\"1\" /><path d=\"M12 67L8 88l-3 4h9l5-25m6 0 3 22 6 2-1 4H24l-6-27\" fill=\"#6c6752\" stroke=\"#353a31\" stroke-width=\"1\" /><ellipse cx=\"19\" cy=\"16\" rx=\"5.8\" ry=\"7.6\" fill=\"#a38d69\" /><path d=\"M12 16q-1-11 7-11 8 0 7 12l-4-1-1-7-3 2-1 7Z\" fill=\"#92978a\" stroke=\"#38463d\" stroke-width=\"0.9\" /><path d=\"M19 5l1-5 4 2-1 5Z\" fill=\"#754539\" stroke=\"#4a3c2e\" stroke-width=\"0.8\" /><path d=\"M8 33q-13 6-7 25 12 2 18-9l-6-14Z\" fill=\"#6b7563\" stroke=\"#3c473b\" stroke-width=\"1.2\" /><path d=\"M7 36l-1 18m-4-9 10 2\" fill=\"none\" stroke=\"#b7aa7c\" stroke-width=\"0.8\" /><path d=\"M34 21l-1 61m0-64 1-13 4 12Z\" fill=\"#b6b9a7\" stroke=\"#4d5546\" stroke-width=\"1\" /></g><path d=\"M229 53v142m0-140 37 5-8 23-29-5Z\" fill=\"#754a3a\" stroke=\"#4d4634\" stroke-width=\"1.5\" /><path d=\"M235 61l17 4m-10-7v17\" fill=\"none\" stroke=\"#bfa568\" stroke-width=\"1\" /></symbol><symbol id=\"tta-a-palace\" viewBox=\"0 0 300 240\"><g transform=\"translate(5 29) scale(0.9)\"><path d=\"M24 191l138-30 124 32-130 40Z\" fill=\"#3b3428\" stroke=\"none\" stroke-width=\"1\" opacity=\".23\"/><path d=\"M20 190L173 217L284 175V182L174 224L20 197Z\" fill=\"#d8d2bb\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M20 190L173 217L284 175V182L174 224L20 197Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M25 185L174.5 212L280 170V177L175.5 219L25 192Z\" fill=\"#b7baa3\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M25 185L174.5 212L280 170V177L175.5 219L25 192Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M30 180L176 207L276 165V172L177 214L30 187Z\" fill=\"#d8d2bb\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M30 180L176 207L276 165V172L177 214L30 187Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M35 175L177.5 202L272 160V167L178.5 209L35 182Z\" fill=\"#b7baa3\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M35 175L177.5 202L272 160V167L178.5 209L35 182Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M45 88L190 112V193L45 169Z\" fill=\"#514e42\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M45 88L190 112V193L45 169Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M190 112L266 79V160L190 193Z\" fill=\"url(#tta-stoneSide)\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M190 112L266 79V160L190 193Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M194 116l66-29v70l-66 29Z\" fill=\"url(#tta-hatch)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M45 91h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M50 99L50 159\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M53 99L53 159\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M56 99L56 159\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M46 96L60 96\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M46 162L60 162\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M63 94h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M68 102L68 162\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M71 102L71 162\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M74 102L74 162\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M64 99L78 99\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M64 165L78 165\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M81 97h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M86 105L86 165\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M89 105L89 165\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M92 105L92 165\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M82 102L96 102\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M82 168L96 168\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M99 100h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M104 108L104 168\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M107 108L107 168\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M110 108L110 168\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M100 105L114 105\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M100 171L114 171\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M117 103h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M122 111L122 171\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M125 111L125 171\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M128 111L128 171\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M118 108L132 108\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M118 174L132 174\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M135 106h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M140 114L140 174\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M143 114L143 174\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M146 114L146 174\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M136 111L150 111\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M136 177L150 177\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M153 109h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M158 117L158 177\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M161 117L161 177\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M164 117L164 177\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M154 114L168 114\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M154 180L168 180\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M171 112h16v5h-2l-1 65h3v7h-16v-7h3l-1-65h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M176 120L176 180\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M179 120L179 180\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M182 120L182 180\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M172 117L186 117\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M172 183L186 183\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><g transform=\"translate(199 113) scale(0.91)\"><path d=\"M-3 0h17v5h-2l-1 60h3v7h-17v-7h3l-1-60h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M2 8L2 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M5.5 8L5.5 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M9 8L9 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M-2 5L13 5\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M-2 66L13 66\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /></g><g transform=\"translate(212 108) scale(0.91)\"><path d=\"M-3 0h17v5h-2l-1 60h3v7h-17v-7h3l-1-60h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M2 8L2 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M5.5 8L5.5 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M9 8L9 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M-2 5L13 5\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M-2 66L13 66\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /></g><g transform=\"translate(225 103) scale(0.91)\"><path d=\"M-3 0h17v5h-2l-1 60h3v7h-17v-7h3l-1-60h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M2 8L2 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M5.5 8L5.5 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M9 8L9 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M-2 5L13 5\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M-2 66L13 66\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /></g><g transform=\"translate(238 98) scale(0.91)\"><path d=\"M-3 0h17v5h-2l-1 60h3v7h-17v-7h3l-1-60h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M2 8L2 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M5.5 8L5.5 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M9 8L9 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M-2 5L13 5\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M-2 66L13 66\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /></g><g transform=\"translate(251 93) scale(0.91)\"><path d=\"M-3 0h17v5h-2l-1 60h3v7h-17v-7h3l-1-60h-2Z\" fill=\"url(#tta-column)\" stroke=\"#7e6d51\" stroke-width=\"0.8\" /><path d=\"M2 8L2 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M5.5 8L5.5 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M9 8L9 63\" fill=\"none\" stroke=\"#ad9c7b\" stroke-width=\"0.65\" /><path d=\"M-2 5L13 5\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /><path d=\"M-2 66L13 66\" fill=\"none\" stroke=\"#eadbb8\" stroke-width=\"1\" /></g><path d=\"M32 78L117 24L204 106L267 74L182 4L117 24L204 106V118L32 90Z\" fill=\"url(#tta-stoneFront)\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M32 78L117 24L204 106L267 74L182 4L117 24L204 106V118L32 90Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M45 77L117 37L186 101Z\" fill=\"#9c8967\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M45 77L117 37L186 101Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M58 77L117 45L173 96Z\" fill=\"url(#tta-hatch)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M109 60l9-6 12 9 13 22-16-4-8-12-7 8-13-1Z\" fill=\"#d8d4be\" stroke=\"#6d614b\" stroke-width=\"0.8\" /><path d=\"M35 84L203 112\" fill=\"none\" stroke=\"#e7d8b8\" stroke-width=\"2.2\" /><path d=\"M202 112L268 80\" fill=\"none\" stroke=\"#baa881\" stroke-width=\"2\" /><path d=\"M40 91L40 97\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M50 92.65L50 98.65\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M60 94.3L60 100.3\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M70 95.95L70 101.95\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M80 97.6L80 103.6\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M90 99.25L90 105.25\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M100 100.9L100 106.9\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M110 102.55L110 108.55\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M120 104.2L120 110.2\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M130 105.85L130 111.85\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M140 107.5L140 113.5\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M150 109.15L150 115.15\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M160 110.8L160 116.8\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M170 112.45L170 118.45\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /><path d=\"M180 114.1L180 120.1\" fill=\"none\" stroke=\"#79694d\" stroke-width=\"2\" /></g><path d=\"M95 94V20l48-14 45 17v73l-46 17Z\" fill=\"#c7b28b\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M95 94V20l48-14 45 17v73l-46 17Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M142 39l46-16v73l-46 17Z\" fill=\"#9c8b68\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M142 39l46-16v73l-46 17Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M85 22L142-12L199 23L143 44Z\" fill=\"url(#tta-roof)\" stroke=\"#4d4033\" stroke-width=\"1.6\" /><path d=\"M85 22L142-12L199 23L143 44Z\" fill=\"url(#tta-tiles)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M111 79V54.9Q120 36 129 54.9V79Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M109 79V54.9Q120 32 131 54.9V79\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /><path d=\"M192 28V1m0 0 25 6v19l-25-7Z\" fill=\"#7a483b\" stroke=\"#594a34\" stroke-width=\"1\" /></symbol><symbol id=\"tta-a-taj\" viewBox=\"0 0 300 240\"><path d=\"M24 191l138-30 124 32-130 40Z\" fill=\"#3b3428\" stroke=\"none\" stroke-width=\"1\" opacity=\".23\"/><path d=\"M43 123L150 146L258 115V170L151 201L43 181Z\" fill=\"#d5c8aa\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M43 123L150 146L258 115V170L151 201L43 181Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M150 146L258 115V170L151 201Z\" fill=\"#a79c82\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M150 146L258 115V170L151 201Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M119 192V162.25Q136.5 125.5 154 162.25V192Z\" fill=\"#4e5b54\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M117 192V162.25Q136.5 121.5 156 162.25V192\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /><path d=\"M56 167V148.6Q62 136 68 148.6V167Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M54 167V148.6Q62 132 70 148.6V167\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /><path d=\"M76 170.7V152.29999999999998Q82 139.7 88 152.29999999999998V170.7Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M74 170.7V152.29999999999998Q82 135.7 90 152.29999999999998V170.7\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /><path d=\"M96 174.4V156Q102 143.4 108 156V174.4Z\" fill=\"#494b42\" stroke=\"#bba680\" stroke-width=\"1.5\" /><path d=\"M94 174.4V156Q102 139.4 110 156V174.4\" fill=\"none\" stroke=\"#8b795c\" stroke-width=\"1\" /><path d=\"M114 122V90l39-12 39 11v31l-39 14Z\" fill=\"#d5ccb3\" stroke=\"#7c775e\" stroke-width=\"1\" /><path d=\"M111 91q-7-25 17-43 16-10 24-26 9 16 26 26 24 17 18 40-42 24-85 3Z\" fill=\"url(#tta-column)\" stroke=\"#7c775e\" stroke-width=\"1.2\" /><path d=\"M152 22V7m-5 7h10M152 23q-22 35-22 73m22-73q22 34 25 73\" fill=\"none\" stroke=\"#9e8d68\" stroke-width=\"1\" /><path d=\"M18 189V89h13v99Z\" fill=\"#cec2a3\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M18 189V89h13v99Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M14 90q-5-15 10-27 16 13 10 27Z\" fill=\"url(#tta-column)\" stroke=\"#7c775e\" stroke-width=\"1\" /><path d=\"M15 107L34 107\" fill=\"none\" stroke=\"#8b8063\" stroke-width=\"2\" /><path d=\"M15 129L34 129\" fill=\"none\" stroke=\"#8b8063\" stroke-width=\"2\" /><path d=\"M15 151L34 151\" fill=\"none\" stroke=\"#8b8063\" stroke-width=\"2\" /><path d=\"M15 173L34 173\" fill=\"none\" stroke=\"#8b8063\" stroke-width=\"2\" /><path d=\"M266 171V71h13v99Z\" fill=\"#cec2a3\" stroke=\"#655b49\" stroke-width=\"1.2\" /><path d=\"M266 171V71h13v99Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M262 72q-5-15 10-27 16 13 10 27Z\" fill=\"url(#tta-column)\" stroke=\"#7c775e\" stroke-width=\"1\" /><path d=\"M263 89L282 89\" fill=\"none\" stroke=\"#8b8063\" stroke-width=\"2\" /><path d=\"M263 111L282 111\" fill=\"none\" stroke=\"#8b8063\" stroke-width=\"2\" /><path d=\"M263 133L282 133\" fill=\"none\" stroke=\"#8b8063\" stroke-width=\"2\" /><path d=\"M263 155L282 155\" fill=\"none\" stroke=\"#8b8063\" stroke-width=\"2\" /></symbol>\n<symbol id=\"tta-a-portrait\" viewBox=\"0 0 280 320\"><rect x=\"0\" y=\"0\" width=\"280\" height=\"320\" fill=\"#bac7c9\" stroke=\"none\" stroke-width=\"1\"/><rect x=\"8\" y=\"8\" width=\"264\" height=\"304\" fill=\"url(#tta-portraitGround)\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M8 320q8-56 61-80l39-17 66 4 37 14q49 18 61 79Z\" fill=\"#34464b\" stroke=\"#283c42\" stroke-width=\"1.5\" /><path d=\"M73 242l32-22 25 27 38-24 41 23-35 74h-74Z\" fill=\"#788e7f\" stroke=\"#344a4c\" stroke-width=\"1\" /><path d=\"M117 191l-6 43 20 25 38-34-3-41Z\" fill=\"#bd9472\" stroke=\"#775b46\" stroke-width=\"1.2\" /><path d=\"M89 88q-12 37-5 78l13 34 33 19 34-14 22-41 2-56-30-39-41 1Z\" fill=\"url(#tta-skin)\" stroke=\"#7f634b\" stroke-width=\"1.5\" /><path d=\"M156 89l24 22-3 20 8 15-15 5 6 25-18 21-30 5-23-20-8-34 11-38Z\" fill=\"#d3ad87\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M87 109q-10 14-13 40l8 21 13-5-2-31Z\" fill=\"#cca37e\" stroke=\"#8a684d\" stroke-width=\"1.2\" /><path d=\"M88 120q-9 15-3 31l6-8-5-7\" fill=\"none\" stroke=\"#7b5d46\" stroke-width=\"1.2\" /><path d=\"M89 106q-13 3-13-20 2-22 20-33l17-18 51 3 30 22 5 35-14 27-8-31-16-18-33-6-25 20-9 25Z\" fill=\"#7f8c86\" stroke=\"#394d50\" stroke-width=\"1.5\" /><path d=\"M83 71q-1-36 30-50 40-13 77 17l4 41q-56-22-111 5Z\" fill=\"#304047\" stroke=\"#22353c\" stroke-width=\"1.5\" /><path d=\"M82 76q52-24 112-2l-1 9q-54-20-110 5Z\" fill=\"#697c7a\" stroke=\"#354b50\" stroke-width=\"1.2\" /><path d=\"M90 51q37-20 84-2m-74-18q37-8 66 9m-76 15 20-8m-13 17 37-9\" fill=\"none\" stroke=\"#93a49a\" stroke-width=\"1\" /><path d=\"M103 112q13-11 27-3m24-1q10-5 23 2\" fill=\"none\" stroke=\"#4d5147\" stroke-width=\"3\" /><path d=\"M105 119q11-5 20 0-9 7-19 1m47-1q9-4 17 0-7 5-16 2Z\" fill=\"#ede0c9\" stroke=\"#806449\" stroke-width=\"1\" /><ellipse cx=\"116\" cy=\"119\" rx=\"2.2\" ry=\"2.8\" fill=\"#3b4a48\" /><ellipse cx=\"160\" cy=\"119\" rx=\"2\" ry=\"2.7\" fill=\"#3b4a48\" /><path d=\"M137 112l-7 27-6 8 7 6 15-4m-12-7 5 2m8 5 6 3m-46-24q11 4 20-2m26 2 15-3\" fill=\"none\" stroke=\"#82624c\" stroke-width=\"1.5\" /><path d=\"M94 145q8 4 10 19 8-2 20 1l12 9 14-9 14-1 12-12-3 30-14 33-21 16-24-9-18-28-9-31Z\" fill=\"#a4aba1\" stroke=\"#5a6a62\" stroke-width=\"1.2\" /><path d=\"M105 166q14-13 28 2l14-5 17 3m-43 12 17 1 11-4\" fill=\"none\" stroke=\"#6c6957\" stroke-width=\"1.8\" /><path d=\"M95 169q-2 23 12.599999999999994 23\" fill=\"none\" stroke=\"#dce0d3\" stroke-width=\"0.9\" /><path d=\"M99.3 175.4562048180957q5 23 10.600000000000009 25\" fill=\"none\" stroke=\"#73867b\" stroke-width=\"0.9\" /><path d=\"M103.6 177.99616242737355q-2 23 8.600000000000009 27\" fill=\"none\" stroke=\"#73867b\" stroke-width=\"0.9\" /><path d=\"M107.9 175.07916862496035q5 23 6.599999999999994 29\" fill=\"none\" stroke=\"#dce0d3\" stroke-width=\"0.9\" /><path d=\"M112.2 168.4746327091518q-2 23 4.599999999999994 31\" fill=\"none\" stroke=\"#73867b\" stroke-width=\"0.9\" /><path d=\"M116.5 162.18877754222865q5 23 2.5999999999999943 33\" fill=\"none\" stroke=\"#73867b\" stroke-width=\"0.9\" /><path d=\"M120.8 160.03451852047743q-2 23 0.6000000000000085 35\" fill=\"none\" stroke=\"#dce0d3\" stroke-width=\"0.9\" /><path d=\"M125.1 163.31860025914912q5 23 -1.3999999999999915 37\" fill=\"none\" stroke=\"#73867b\" stroke-width=\"0.9\" /><path d=\"M129.4 170.04894284365443q-2 23 -3.4000000000000057 39\" fill=\"none\" stroke=\"#73867b\" stroke-width=\"0.9\" /><path d=\"M133.7 176.1430107746424q5 23 -5.399999999999977 37\" fill=\"none\" stroke=\"#dce0d3\" stroke-width=\"0.9\" /><path d=\"M138 177.90422421961043q-2 23 -7.400000000000006 35\" fill=\"none\" stroke=\"#73867b\" stroke-width=\"0.9\" /><path d=\"M142.3 174.26425473602586q5 23 -9.400000000000006 33\" fill=\"none\" stroke=\"#73867b\" stroke-width=\"0.9\" /><path d=\"M146.6 167.43105896899317q-2 23 -11.400000000000006 31\" fill=\"none\" stroke=\"#dce0d3\" stroke-width=\"0.9\" /><path d=\"M150.9 161.5495617782291q5 23 -13.400000000000006 29\" fill=\"none\" stroke=\"#73867b\" stroke-width=\"0.9\" /><path d=\"M155.2 160.18740043763816q-2 23 -15.399999999999977 27\" fill=\"none\" stroke=\"#73867b\" stroke-width=\"0.9\" /><path d=\"M159.5 164.17084373799608q5 23 -17.400000000000006 25\" fill=\"none\" stroke=\"#dce0d3\" stroke-width=\"0.9\" /><path d=\"M163.8 171.08358842591386q-2 23 -19.400000000000006 23\" fill=\"none\" stroke=\"#73867b\" stroke-width=\"0.9\" /><path d=\"M99 98q8-4 14-2M154 91l17 5\" fill=\"none\" stroke=\"#ad8660\" stroke-width=\"0.65\" /><path d=\"M101 100q8-4 14-2M154.8 93l17 5\" fill=\"none\" stroke=\"#ad8660\" stroke-width=\"0.65\" /><path d=\"M103 102q8-4 14-2M155.6 95l17 5\" fill=\"none\" stroke=\"#ad8660\" stroke-width=\"0.65\" /><path d=\"M105 104q8-4 14-2M156.4 97l17 5\" fill=\"none\" stroke=\"#ad8660\" stroke-width=\"0.65\" /><path d=\"M107 106q8-4 14-2M157.2 99l17 5\" fill=\"none\" stroke=\"#ad8660\" stroke-width=\"0.65\" /><path d=\"M109 108q8-4 14-2M158 101l17 5\" fill=\"none\" stroke=\"#ad8660\" stroke-width=\"0.65\" /><path d=\"M111 110q8-4 14-2M158.8 103l17 5\" fill=\"none\" stroke=\"#ad8660\" stroke-width=\"0.65\" /><path d=\"M113 112q8-4 14-2M159.6 105l17 5\" fill=\"none\" stroke=\"#ad8660\" stroke-width=\"0.65\" /><path d=\"M115 114q8-4 14-2M160.4 107l17 5\" fill=\"none\" stroke=\"#ad8660\" stroke-width=\"0.65\" /><path d=\"M108 92q22-9 45-2m-47 7q26-7 45-1m-53 42-3 11 11 10m65-25-8 15m-50 7-6 8m-4-54-6 4\" fill=\"none\" stroke=\"#92704f\" stroke-width=\"1\" /><path d=\"M27 278L17 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M34 283L23 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M41 288L29 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M48 293L35 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M55 278L41 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M62 283L47 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M69 288L53 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M76 293L59 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M83 278L65 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M90 283L71 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M97 288L77 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M104 293L83 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M111 278L89 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M118 283L95 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M125 288L101 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M132 293L107 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M139 278L113 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M146 283L119 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M153 288L125 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M160 293L131 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M167 278L137 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M174 283L143 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M181 288L149 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M188 293L155 320\" fill=\"none\" stroke=\"#8ca194\" stroke-width=\"0.8\" /><path d=\"M89 249l26 31 16-24 16 20 28-33m-60 37-4 40m36-44 15 44M48 275l30-11m117-2 36 15\" fill=\"none\" stroke=\"#bdc8b2\" stroke-width=\"1.1\" /><rect x=\"8\" y=\"8\" width=\"264\" height=\"304\" fill=\"url(#tta-engravingVeil)\" stroke=\"none\" stroke-width=\"1\"/></symbol>\n<symbol id=\"tta-a-scroll\" viewBox=\"0 0 300 240\"><path d=\"M50 38h193l-17 146H31Z\" fill=\"#d3bd8d\" stroke=\"#8d7953\" stroke-width=\"1.6\" /><path d=\"M50 38q-26-1-20 27h194q-6-26 19-27m-17 146q27-2 20-27H51q7 27-20 27\" fill=\"#e1cba0\" stroke=\"#8d7953\" stroke-width=\"1.6\" /><path d=\"M70 84L198 84\" fill=\"none\" stroke=\"#9a865e\" stroke-width=\"1.5\" /><path d=\"M68 99L195 99\" fill=\"none\" stroke=\"#9a865e\" stroke-width=\"1.5\" /><path d=\"M66 114L192 114\" fill=\"none\" stroke=\"#9a865e\" stroke-width=\"1.5\" /><path d=\"M64 129L189 129\" fill=\"none\" stroke=\"#9a865e\" stroke-width=\"1.5\" /><path d=\"M62 144L186 144\" fill=\"none\" stroke=\"#9a865e\" stroke-width=\"1.5\" /><ellipse cx=\"185\" cy=\"160\" rx=\"17\" ry=\"17\" fill=\"#805342\" /><path d=\"M178 174v27l11-8 10 4-6-25Z\" fill=\"#8d7143\" stroke=\"#6b5432\" stroke-width=\"1\" /></symbol>\n</defs>", un = "<defs>\n <linearGradient id=\"v15-sky\" x2=\"0\" y2=\"1\"><stop stop-color=\"#d1e4eb\"/><stop offset=\".6\" stop-color=\"#f5f6f2\"/><stop offset=\"1\" stop-color=\"#d3dacc\"/></linearGradient>\n <linearGradient id=\"v15-title\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fcfcf7\"/><stop offset=\".75\" stop-color=\"#fcfcf7\" stop-opacity=\".85\"/><stop offset=\"1\" stop-color=\"#fcfcf7\" stop-opacity=\"0\"/></linearGradient>\n <linearGradient id=\"v15-foot\" x2=\"0\" y2=\"1\"><stop stop-color=\"#f6f5ee\" stop-opacity=\"0\"/><stop offset=\".36\" stop-color=\"#f4f4ed\" stop-opacity=\".94\"/><stop offset=\"1\" stop-color=\"#eceee6\"/></linearGradient>\n <linearGradient id=\"v15-cost\" x2=\".8\" y2=\"1\"><stop stop-color=\"#f2fcff\"/><stop offset=\".56\" stop-color=\"#d4edf8\"/><stop offset=\"1\" stop-color=\"#88bdd7\"/></linearGradient>\n <linearGradient id=\"v15-gold\" x2=\"0\" y2=\"1\"><stop stop-color=\"#fff2b1\"/><stop offset=\".4\" stop-color=\"#e2bc55\"/><stop offset=\"1\" stop-color=\"#a47b27\"/></linearGradient>\n <linearGradient id=\"v15-rule\" x2=\"0\" y2=\"1\"><stop stop-color=\"#738d93\"/><stop offset=\".5\" stop-color=\"#e6ece8\"/><stop offset=\"1\" stop-color=\"#536c75\"/></linearGradient>\n <symbol id=\"v15-book\" viewBox=\"0 0 20 20\"><path d=\"M2 3q4-2 8 1 4-3 8-1v12q-4-2-8 1-4-3-8-1Z\" fill=\"#e9ede4\" stroke=\"#445e66\" stroke-width=\"1.1\"/><path d=\"M10 4v12M4 6l4 1M4 9l4 1m4-3 4-1m-4 4 4-1\" fill=\"none\" stroke=\"#6f8585\" stroke-width=\".8\"/></symbol>\n <symbol id=\"v15-tools\" viewBox=\"0 0 120 100\"><path d=\"M12 84 58 69 111 81 68 98Z\" fill=\"#9c9d83\" opacity=\".3\"/><path d=\"M25 78V44l21-11 20 9v37l-21 8Z\" fill=\"#d9d4bd\" stroke=\"#777963\" stroke-width=\"1\"/><path d=\"M66 79V42l21-7 18 11v30L84 86Z\" fill=\"#b9c0aa\" stroke=\"#777963\" stroke-width=\"1\"/><path d=\"M44 80V52q15-16 23 1v27M24 43l20-17 23 15 19-16 20 19\" fill=\"none\" stroke=\"#9e9f88\" stroke-width=\"5\"/><path d=\"M21 43l22-18 23 16 20-17 23 20\" fill=\"none\" stroke=\"#ede8cf\" stroke-width=\"2\"/><path d=\"M52 13 31 71m21-58 23 58M45 34h16\" stroke=\"#60694f\" stroke-width=\"3\" fill=\"none\"/><circle cx=\"52\" cy=\"13\" r=\"4\" fill=\"#cfb866\" stroke=\"#716842\"/><path d=\"m80 16 6-2 12 39-6 2Z\" fill=\"#d5aa50\" stroke=\"#7e734e\"/><path d=\"m92 55 6-2-1 10Z\" fill=\"#5f6558\"/></symbol>\n</defs>", dn = {
	farm: {
		edge: "#9a7647",
		light: "#e1cb9d",
		shade: "#705838"
	},
	mine: {
		edge: "#927651",
		light: "#d6c6a5",
		shade: "#64553f"
	},
	urban: {
		edge: "#828b8e",
		light: "#d9dfdc",
		shade: "#59676d"
	},
	military: {
		edge: "#966055",
		light: "#d5aaa0",
		shade: "#6b403a"
	},
	government: {
		edge: "#ac7746",
		light: "#ecd2ab",
		shade: "#765238"
	},
	wonder: {
		edge: "#79658f",
		light: "#d5c6e3",
		shade: "#554463"
	},
	leader: {
		edge: "#68856a",
		light: "#c9d6b9",
		shade: "#425e49"
	},
	action: {
		edge: "#b48e2b",
		light: "#f7e4a0",
		shade: "#826725"
	},
	special: {
		edge: "#428ea4",
		light: "#b5dce7",
		shade: "#32687a"
	}
}, fn = (e) => String(e).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll("\"", "&quot;");
function pn(e, t, n, r) {
	let i = {
		id: e.id,
		name: t,
		art: n
	}, a = (e, t, n, r, i, a = "none", o = 0, s = 1) => `<rect x="${e}" y="${t}" width="${n}" height="${r}" rx="${o}" fill="${i}" stroke="${a}" stroke-width="${s}"/>`, o = (e, t = "none", n = 1, r = "none") => `<path d="${e}" fill="${r}" stroke="${t}" stroke-width="${n}" stroke-linecap="round" stroke-linejoin="round"/>`, s = (e, t, n, r = 14, i = "#2c3d43", a = 650, o = "start", s = !1) => `<text x="${e}" y="${t}" font-size="${r}" fill="${i}" font-weight="${a}" text-anchor="${o}"${s ? " style=\"font-family:ui-monospace,monospace\"" : ""}>${fn(n)}</text>`, c = (e, t, n, r, i = r * .8) => `<use href="#tta-a-${e}" x="${t}" y="${n}" width="${r}" height="${i}"/>`, l = (e, t, n, r, i = r * .8) => c(e.art, t, n, r, i), u = (e, t, n, r = 20) => `<use href="#tta-i-${{
		worker: "population",
		armies: "strength",
		colonize: "strength"
	}[e] ?? e}" x="${t}" y="${n}" width="${r}" height="${r}"/>`, d = (e = 95, t = 132) => `<use href="#v15-book" x="${e}" y="${t}" width="15" height="15"/>`, f = e.kind === "technology" ? ["farm", "mine"].includes(e.category) ? e.category : [
		"law",
		"warfare",
		"exploration",
		"construction"
	].includes(e.category) ? "special" : [
		"infantry",
		"cavalry",
		"artillery",
		"airforce"
	].includes(e.category) ? "military" : "urban" : e.kind, p = dn[f] ?? ([
		"tactic",
		"aggression",
		"war",
		"bonus"
	].includes(f) ? dn.military : dn.special), m = g(p) + oe(i, e);
	m += o("M5 23V6h110v17M5 143v15h110v-15", p.light, .65), m += o("M46 5h28l-3 14-11 5-11-5Z", p.shade, .75, p.edge) + o("M49 7h22l-2 10-9 4-9-4Z", p.light, .7), m += s(60, 17, [
		"A",
		"I",
		"II",
		"III"
	][e.age], 13, "#fbfaf1", 700, "middle"), e.science !== void 0 && (m += "<circle cx=\"15\" cy=\"16\" r=\"12.4\" fill=\"url(#v15-cost)\" stroke=\"#548fae\" stroke-width=\"1.1\"/><circle cx=\"15\" cy=\"15.5\" r=\"10.3\" fill=\"none\" stroke=\"#f6fcff\" stroke-width=\".7\"/>" + s(15, 21, e.science, 18, "#226c91", 650, "middle", !0), e.revolution !== void 0 && (m += "<circle cx=\"17\" cy=\"32\" r=\"8.8\" fill=\"#3e91b4\" stroke=\"#cce8ef\" stroke-width=\".8\"/>" + s(17, 36, e.revolution, 12, "#fff", 700, "middle", !0)));
	let ee = /[\u3400-\u9fff]/.test(t), te = ee ? 6 : 14, ne = ee ? Array.from(t) : t.split(" "), re = [], h = "";
	for (let e of ne) {
		let t = h + (h && !ee ? " " : "") + e;
		h && t.length > te ? (re.push(h), h = e) : h = t;
	}
	h && re.push(h);
	let ie = ee ? re.length > 1 ? 14.7 : 16 : re.length > 2 ? 11.5 : 13;
	re.forEach((e, t) => m += `<text x="61" y="${re.length > 1 ? 34 + t * 15 : 43}" font-size="${ie}" fill="#263b43" font-weight="750" text-anchor="middle"${e.length > (ee ? 7 : 16) ? " textLength=\"96\" lengthAdjust=\"spacingAndGlyphs\"" : ""}>${fn(e)}</text>`);
	let ae = e.ratings ?? {};
	if (e.kind === "government") {
		let e = Object.entries(ae).filter(([e, t]) => ![
			"civil",
			"military",
			"urban"
		].includes(e) && t), t = e.length ? 6 : 0;
		for (let e = 0; e < (ae.civil ?? 0); e++) m += u("civil", 10 + e * 12, 109 - t, 18);
		for (let e = 0; e < (ae.military ?? 0); e++) m += u("military", 10 + e * 12, 130 - t, 18);
		m += o("M99 132v-11l6-4 6 4v11M97 133h16", "#53646b", 1.2, "#d6ded5") + s(105, 148, ae.urban, 13, "#314a52", 750, "middle", !0), e.forEach(([e, t], n) => m += u(e, 10 + n * 40, 146, 13) + s(25 + n * 40, 158, t, 13, "#243b43", 750, "start", !0));
	} else {
		let t = Object.entries(ae).filter(([, e]) => e);
		e.category === "farm" && t.unshift(["food", e.value ?? 1]), e.category === "mine" && t.unshift(["ore", e.value ?? 1]);
		for (let [n, r] of Object.entries(e.gain ?? {})) t.push([n === "population" ? "worker" : n === "cards" ? "cards" : n, r]);
		e.defense && t.push(["strength", e.defense], ["colonize", e.colonize ?? 0]), e.tactic !== void 0 && t.push(["strength", e.tactic]), e.yellow && t.push(["worker", e.yellow]), e.blue && t.push(["blue", e.blue]);
		let n = [
			"leader",
			"action",
			"event",
			"territory",
			"aggression",
			"war",
			"pact",
			"bonus"
		].includes(e.kind) || [
			"law",
			"warfare",
			"exploration",
			"construction"
		].includes(e.category ?? ""), r = e.stages ? Math.max(3, t.length) : t.length > 3 ? Math.ceil(t.length / 2) : 3, i = Math.min(38, (n ? 86 : 104) / Math.min(r, Math.max(t.length, 1)));
		if (t.forEach(([n, a], o) => {
			let c = 8 + o % r * i, l = (t.length > 3 && !e.stages ? 128 : 145) + Math.floor(o / r) * 22, d = i < 29 ? 13 : 18;
			if (n === "happy" && a > 0 && a <= 2) for (let e = 0; e < a; e++) m += u("happy", c + e * 12, l - d + 2, d);
			else m += u(n === "colonize" ? "strength" : n, c, l - d + 2, d) + s(c + d + 1, l, a, d, "#243b43", 750, "start", !0);
		}), e.units && (e.units.forEach((e, t) => {
			e && (m += u([
				"infantry",
				"cavalry",
				"artillery"
			][t], 10 + t * 34, 111, 15) + s(26 + t * 34, 124, e, 12, "#354d52", 700, "start", !0));
		}), e.obsolete !== void 0 && (m += s(51, 145, "/ " + e.obsolete, 12, "#60716e", 650, "start", !0))), e.stages) {
			let n = Math.min(17, 100 / e.stages.length), r = 60 - e.stages.length * n / 2;
			e.stages.forEach((e, t) => m += a(r + t * n, 112, n - 1, 15, "#e7dfed", "#9b8caa", 1, .5) + s(r + t * n + (n - 1) / 2, 123, e, 11, "#594769", 700, "middle", !0)), t.length <= 2 && (m += d());
		} else e.cost !== void 0 && (m += u("ore", 88, 143, 12) + s(111, 153, e.cost, 13, "#46555a", 750, "end", !0));
		e.id === "michelangelo" && (m += u("happy", 17, 126, 21) + o("M43 137h13m-4-4 4 4-4 4", "#46606a", 1.5) + u("culture", 63, 126, 23)), e.kind === "action" && [
			"richLand",
			"engineeringGenius",
			"urbanGrowth",
			"efficientUpgrade"
		].includes(e.effect ?? "") && (m += u("ore", 17, 129, 20) + s(39, 146, "−" + e.amount, 22, "#243b43", 750, "start", !0)), n && (m += d());
	}
	return m.replaceAll("tta-", r).replaceAll("v15-", r + "card-");
	function oe(e, t) {
		let n = t.kind, r = a(5, 20, 110, 133, "url(#v15-sky)");
		if (r += o("M5 93 23 83 40 90 59 79 83 88 101 77 115 87V148H5Z", "none", 0, "#b8c9be"), r += o("M5 103Q37 94 60 104T115 100V148H5Z", "none", 0, "#a6b59a"), r += o("M5 126 47 108 80 120 115 112V148H5Z", "none", 0, "#c7c6ac"), r += o("M5 137 57 111 115 128", "#e0ddc8", 7), n === "leader") r += o("M11 103V62h17v42m68-1V62h13v42", "#cdd4c8", 3, "#d9ded3"), r += c(e.art, 24, 46, 77, 88);
		else if (n === "action") t.effect === "engineeringGenius" ? r += "<use href=\"#v15-tools\" x=\"13\" y=\"47\" width=\"96\" height=\"80\"/>" : r += c(t.effect === "richLand" ? "farm" : t.effect === "urbanGrowth" ? "library" : t.effect === "patriotism" ? "barracks" : "scroll", 12, 51, 104, 83), r += a(5, 22, 110, 126, "#f2cf5f").replace("fill=\"#f2cf5f\"", "fill=\"#f2cf5f\" opacity=\".16\"");
		else {
			let n = e.art === "wall" ? 125 : e.art === "mine" ? 113 : 110;
			r += l(e, (120 - n) / 2, 43, n, 88);
			for (let [e, t, n] of [[
				13,
				103,
				1
			], [
				104,
				99,
				.9
			]]) r += `<g transform="translate(${e} ${t}) scale(${n})">` + o("M0 0v11", "#7f8b6c", 1.2) + o("M-4-3q-3-7 3-10 5-2 7 4 4 7-6 8Z", "#819876", .4, "#95ab83") + "</g>";
			if (t.category === "farm") for (let e = 0; e < 5; e++) r += o(`M${8 + e * 7} ${118 + e * .5}l18-6`, "#b8b57e", .9);
		}
		return r + a(5, 21, 110, 48, "url(#v15-title)") + a(5, 110, 110, 47, "url(#v15-foot)");
	}
	function g(e) {
		let t = a(0, 2, 120, 164, "#879086", "none", 4) + a(.7, .7, 118.6, 162.6, e.edge, e.shade, 3, 1.1);
		t += a(4.3, 5.2, 111.4, 153.5, "url(#v15-sky)", e.light, 1.8, .8), t += o("M5 23V6h110v17M5 143v15h110v-15", e.shade, .7), t += o("M2.6 6v151M117.4 6v151", e.light, .65), t += o("M5 20q16-12 34-8l21 5 21-5q18-4 34 8V5H5Z", e.shade, .7, e.edge), t += o("M6 9h29q12 0 25 7 13-7 25-7h29M6 151h108", e.light, .8);
		for (let n of [!1, !0]) t += `<g${n ? " transform=\"translate(120 0) scale(-1 1)\"" : ""}>`, t += o("M8 17q9-8 18-4 5 2 1 5-6 3-8-1-1-3 3-2m8-3q7 0 11 4m-29-5 3 3m17-5 3 4", e.light, .75), t += o("M7 145q7 0 9 5l11-1 7 3m-26-4 4 5m-1-9 6 4", e.light, .7), t += "</g>";
		return t;
	}
}
//#endregion
//#region src/games/throughtheages/city-art.ts
var mn = "<g transform=\"scale(.6125 1)\"><rect x=\"0\" y=\"0\" width=\"1600\" height=\"360\" rx=\"0\" fill=\"url(#tta-sky2)\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M0 120 67 109 139 115 201 97 267 107 341 122 403 111 472 119 548 99 615 113 681 102 757 117 842 102 916 114 992 97 1070 114 1142 103 1209 119 1290 101 1360 111 1423 92 1487 104 1553 96 1600 116V207H0Z\" fill=\"#95b2b8\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M0 143Q90 126 194 143T402 141T612 138T824 145T1040 140T1250 134T1454 140 1600 131V240H0Z\" fill=\"#9bb496\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M0 165Q128 144 264 165T528 163T798 161T1070 160T1350 153T1600 166V360H0Z\" fill=\"url(#tta-earth2)\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M0 257 179 230 370 259 489 240 707 283 589 326 355 306 127 348 0 320Z\" fill=\"#8ca256\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M1070 283 1240 266 1392 292 1600 271V360H1030Z\" fill=\"#6c9148\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M1293 142 1350 119 1415 135 1462 113 1530 132 1600 126V234L1510 222 1400 232Z\" fill=\"#8b9f73\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M1340 146 1406 138 1450 153 1510 140 1578 155M1410 165l61 9 64-11M1450 153l-19 28\" fill=\"none\" stroke=\"#b7bd91\" stroke-width=\"1.1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M12 261l47.260000000000005-23.779999999999998 91.74000000000001 16.400000000000002-44.480000000000004 27.880000000000003Z\" fill=\"#c2af6d\" stroke=\"#9f955e\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M16.726 258.622l91.74000000000001 16.400000000000002\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M21.452 256.244l91.74000000000001 16.400000000000002\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M26.178 253.866l91.74000000000001 16.400000000000002\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M30.904000000000003 251.488l91.74000000000001 16.400000000000002\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M35.63 249.11l91.74000000000001 16.400000000000002\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M40.356 246.732l91.74000000000001 16.400000000000002\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M45.082 244.354l91.74000000000001 16.400000000000002\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M49.80800000000001 241.976l91.74000000000001 16.400000000000002\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M54.534000000000006 239.598l91.74000000000001 16.400000000000002\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M114 306l51.00000000000001-20.299999999999997 99 14-48 23.8Z\" fill=\"#c2af6d\" stroke=\"#9f955e\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M119.1 303.97l99 14\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M124.2 301.94l99 14\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M129.3 299.91l99 14\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M134.4 297.88l99 14\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M139.5 295.85l99 14\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M144.6 293.82l99 14\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M149.7 291.79l99 14\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M154.8 289.76l99 14\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M159.9 287.73l99 14\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M236 298l48.620000000000005-19.72 94.38000000000001 13.600000000000001-45.76 23.12Z\" fill=\"#6f934c\" stroke=\"#7c8e50\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M240.862 296.028l94.38000000000001 13.600000000000001\" fill=\"none\" stroke=\"#b6c184\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M245.724 294.056l94.38000000000001 13.600000000000001\" fill=\"none\" stroke=\"#b6c184\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M250.586 292.084l94.38000000000001 13.600000000000001\" fill=\"none\" stroke=\"#b6c184\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M255.448 290.112l94.38000000000001 13.600000000000001\" fill=\"none\" stroke=\"#b6c184\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M260.31 288.14l94.38000000000001 13.600000000000001\" fill=\"none\" stroke=\"#b6c184\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M265.172 286.168l94.38000000000001 13.600000000000001\" fill=\"none\" stroke=\"#b6c184\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M270.034 284.196l94.38000000000001 13.600000000000001\" fill=\"none\" stroke=\"#b6c184\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M274.896 282.224l94.38000000000001 13.600000000000001\" fill=\"none\" stroke=\"#b6c184\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M279.758 280.252l94.38000000000001 13.600000000000001\" fill=\"none\" stroke=\"#b6c184\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M183 169l38.080000000000005-16.24 73.92 11.200000000000001-35.84 19.040000000000003Z\" fill=\"#c2af6d\" stroke=\"#9f955e\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M186.808 167.376l73.92 11.200000000000001\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M190.616 165.752l73.92 11.200000000000001\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M194.424 164.12800000000001l73.92 11.200000000000001\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M198.232 162.504l73.92 11.200000000000001\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M202.04 160.88l73.92 11.200000000000001\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M205.848 159.256l73.92 11.200000000000001\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M209.656 157.632l73.92 11.200000000000001\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M213.464 156.008l73.92 11.200000000000001\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M217.272 154.38400000000001l73.92 11.200000000000001\" fill=\"none\" stroke=\"#e3d19a\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M12 182l23.8-13.919999999999998 46.2 9.600000000000001-22.400000000000002 16.32Z\" fill=\"#6f934c\" stroke=\"#7c8e50\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M14.38 180.608l46.2 9.600000000000001\" fill=\"none\" stroke=\"#b6c184\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M16.76 179.216l46.2 9.600000000000001\" fill=\"none\" stroke=\"#b6c184\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M19.14 177.824l46.2 9.600000000000001\" fill=\"none\" stroke=\"#b6c184\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M21.520000000000003 176.432l46.2 9.600000000000001\" fill=\"none\" stroke=\"#b6c184\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M23.9 175.04l46.2 9.600000000000001\" fill=\"none\" stroke=\"#b6c184\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M26.28 173.648l46.2 9.600000000000001\" fill=\"none\" stroke=\"#b6c184\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M28.66 172.256l46.2 9.600000000000001\" fill=\"none\" stroke=\"#b6c184\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M31.040000000000003 170.864l46.2 9.600000000000001\" fill=\"none\" stroke=\"#b6c184\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M33.42 169.472l46.2 9.600000000000001\" fill=\"none\" stroke=\"#b6c184\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M489 132C466 156 510 173 511 193S566 219 570 239 544 276 589 298 628 333 668 360H722C661 315 652 297 611 274S625 241 611 222 552 190 550 171 548 145 529 131Z\" fill=\"url(#tta-river2)\" stroke=\"#9fae8f\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M495 135C478 156 520 178 520 192S575 218 580 239 553 274 598 295 644 338 681 360\" fill=\"none\" stroke=\"#c4dde0\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-20 278C112 261 210 232 329 233S465 251 569 246 717 221 835 230 1056 242 1174 232 1434 259 1620 244\" fill=\"none\" stroke=\"#838c67\" stroke-width=\"14\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-20 278C112 261 210 232 329 233S465 251 569 246 717 221 835 230 1056 242 1174 232 1434 259 1620 244\" fill=\"none\" stroke=\"#c4bea0\" stroke-width=\"12\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-20 278C112 261 210 232 329 233S465 251 569 246 717 221 835 230 1056 242 1174 232 1434 259 1620 244\" fill=\"none\" stroke=\"#e3ddbc\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M171 258Q197 221 191 198M328 235Q346 202 350 177M748 232Q744 193 767 173M842 231Q883 274 1008 283M1185 232Q1231 194 1267 181M1409 249Q1449 216 1487 207\" fill=\"none\" stroke=\"#838c67\" stroke-width=\"7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M171 258Q197 221 191 198M328 235Q346 202 350 177M748 232Q744 193 767 173M842 231Q883 274 1008 283M1185 232Q1231 194 1267 181M1409 249Q1449 216 1487 207\" fill=\"none\" stroke=\"#c4bea0\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M171 258Q197 221 191 198M328 235Q346 202 350 177M748 232Q744 193 767 173M842 231Q883 274 1008 283M1185 232Q1231 194 1267 181M1409 249Q1449 216 1487 207\" fill=\"none\" stroke=\"#e3ddbc\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M666 227l81.9-20 100.10000000000001 10.4-76.44 26Z\" fill=\"#b5b79a\" stroke=\"#999c81\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M676.2375 224.5l100.10000000000001 10.4\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M686.475 222l100.10000000000001 10.4\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M696.7125 219.5l100.10000000000001 10.4\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M706.95 217l100.10000000000001 10.4\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M717.1875 214.5l100.10000000000001 10.4\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M727.425 212l100.10000000000001 10.4\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M737.6625 209.5l100.10000000000001 10.4\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M886 247l80.10000000000001-23 97.9 11.96-74.75999999999999 29.900000000000002Z\" fill=\"#b5b79a\" stroke=\"#999c81\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M896.0125 244.125l97.9 11.96\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M906.025 241.25l97.9 11.96\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M916.0375 238.375l97.9 11.96\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M926.05 235.5l97.9 11.96\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M936.0625 232.625l97.9 11.96\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M946.075 229.75l97.9 11.96\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M956.0875 226.875l97.9 11.96\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M1047 224l46.35-13.5 56.650000000000006 7.0200000000000005-43.26 17.55Z\" fill=\"#b5b79a\" stroke=\"#999c81\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M1052.79375 222.3125l56.650000000000006 7.0200000000000005\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M1058.5875 220.625l56.650000000000006 7.0200000000000005\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M1064.38125 218.9375l56.650000000000006 7.0200000000000005\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M1070.175 217.25l56.650000000000006 7.0200000000000005\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M1075.96875 215.5625l56.650000000000006 7.0200000000000005\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M1081.7625 213.875l56.650000000000006 7.0200000000000005\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M1087.55625 212.1875l56.650000000000006 7.0200000000000005\" fill=\"none\" stroke=\"#ced0b4\" stroke-width=\"0.55\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M549 241 583 228 626 243 591 256Z\" fill=\"#9e9270\" stroke=\"#6c654b\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M554 239l42 15\" fill=\"none\" stroke=\"#d0c3a1\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M558 237.55l42 15\" fill=\"none\" stroke=\"#d0c3a1\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M562 236.1l42 15\" fill=\"none\" stroke=\"#d0c3a1\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M566 234.65l42 15\" fill=\"none\" stroke=\"#d0c3a1\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M570 233.2l42 15\" fill=\"none\" stroke=\"#d0c3a1\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M574 231.75l42 15\" fill=\"none\" stroke=\"#d0c3a1\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M578 230.3l42 15\" fill=\"none\" stroke=\"#d0c3a1\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M582 228.85l42 15\" fill=\"none\" stroke=\"#d0c3a1\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M551 238 582 225 626 240M551 238v-7m15 2v-7m15 1v-8m15 13v-7m15 12v-7m15 12v-7\" fill=\"none\" stroke=\"#7f7353\" stroke-width=\"1.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><g transform=\"translate(563 183) scale(0.61)\"><path d=\"M-3 15 20 4 43 17 18 30Z\" fill=\"#52634933\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 1 22 6V24L2 18Z\" fill=\"#d8d0b7\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M22 6 38-1V17L22 24Z\" fill=\"#a9b2a0\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-2 2 12-9 42-1 22 9Z\" fill=\"#806b52\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M12-9 25-12 42-1 22 9Z\" fill=\"#a08d6e\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M7 8v7m6-5v7m14-7v7m5-9v6\" fill=\"none\" stroke=\"#62716b\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M16 22v-9l5 1v10\" fill=\"#5c6255\" stroke=\"#5b5745\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 2 22 7\" fill=\"none\" stroke=\"#d2bea0\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 4 22 10 38 3\" fill=\"none\" stroke=\"#5d5949\" stroke-width=\"0.75\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 15 20 20m5-3 10-4\" fill=\"none\" stroke=\"#b6b399\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M5-2 23 3m-12-10 18 5m-8-10 15 6\" fill=\"none\" stroke=\"#bba88a\" stroke-width=\"0.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(787 128) scale(0.62)\"><path d=\"M-3 15 20 4 43 17 18 30Z\" fill=\"#52634933\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 1 22 6V24L2 18Z\" fill=\"#d8d0b7\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M22 6 38-1V17L22 24Z\" fill=\"#a9b2a0\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-2 2 12-9 42-1 22 9Z\" fill=\"#806b52\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M12-9 25-12 42-1 22 9Z\" fill=\"#a08d6e\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M7 8v7m6-5v7m14-7v7m5-9v6\" fill=\"none\" stroke=\"#62716b\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M16 22v-9l5 1v10\" fill=\"#5c6255\" stroke=\"#5b5745\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 2 22 7\" fill=\"none\" stroke=\"#d2bea0\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 4 22 10 38 3\" fill=\"none\" stroke=\"#5d5949\" stroke-width=\"0.75\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 15 20 20m5-3 10-4\" fill=\"none\" stroke=\"#b6b399\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M5-2 23 3m-12-10 18 5m-8-10 15 6\" fill=\"none\" stroke=\"#bba88a\" stroke-width=\"0.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(817 126) scale(0.61)\"><path d=\"M-3 15 20 4 43 17 18 30Z\" fill=\"#52634933\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 1 22 6V24L2 18Z\" fill=\"#d8d0b7\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M22 6 38-1V17L22 24Z\" fill=\"#a9b2a0\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-2 2 12-9 42-1 22 9Z\" fill=\"#806b52\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M12-9 25-12 42-1 22 9Z\" fill=\"#a08d6e\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M7 8v7m6-5v7m14-7v7m5-9v6\" fill=\"none\" stroke=\"#62716b\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M16 22v-9l5 1v10\" fill=\"#5c6255\" stroke=\"#5b5745\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 2 22 7\" fill=\"none\" stroke=\"#d2bea0\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 4 22 10 38 3\" fill=\"none\" stroke=\"#5d5949\" stroke-width=\"0.75\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 15 20 20m5-3 10-4\" fill=\"none\" stroke=\"#b6b399\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M5-2 23 3m-12-10 18 5m-8-10 15 6\" fill=\"none\" stroke=\"#bba88a\" stroke-width=\"0.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(845 125) scale(0.61)\"><path d=\"M-3 15 20 4 43 17 18 30Z\" fill=\"#52634933\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 1 22 6V24L2 18Z\" fill=\"#d8d0b7\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M22 6 38-1V17L22 24Z\" fill=\"#a9b2a0\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-2 2 12-9 42-1 22 9Z\" fill=\"#806b52\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M12-9 25-12 42-1 22 9Z\" fill=\"#a08d6e\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M7 8v7m6-5v7m14-7v7m5-9v6\" fill=\"none\" stroke=\"#62716b\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M16 22v-9l5 1v10\" fill=\"#5c6255\" stroke=\"#5b5745\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 2 22 7\" fill=\"none\" stroke=\"#d2bea0\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 4 22 10 38 3\" fill=\"none\" stroke=\"#5d5949\" stroke-width=\"0.75\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 15 20 20m5-3 10-4\" fill=\"none\" stroke=\"#b6b399\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M5-2 23 3m-12-10 18 5m-8-10 15 6\" fill=\"none\" stroke=\"#bba88a\" stroke-width=\"0.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(875 129) scale(0.6)\"><path d=\"M-3 15 20 4 43 17 18 30Z\" fill=\"#52634933\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 1 22 6V24L2 18Z\" fill=\"#d8d0b7\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M22 6 38-1V17L22 24Z\" fill=\"#a9b2a0\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-2 2 12-9 42-1 22 9Z\" fill=\"#806b52\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M12-9 25-12 42-1 22 9Z\" fill=\"#a08d6e\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M7 8v7m6-5v7m14-7v7m5-9v6\" fill=\"none\" stroke=\"#62716b\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M16 22v-9l5 1v10\" fill=\"#5c6255\" stroke=\"#5b5745\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 2 22 7\" fill=\"none\" stroke=\"#d2bea0\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 4 22 10 38 3\" fill=\"none\" stroke=\"#5d5949\" stroke-width=\"0.75\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 15 20 20m5-3 10-4\" fill=\"none\" stroke=\"#b6b399\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M5-2 23 3m-12-10 18 5m-8-10 15 6\" fill=\"none\" stroke=\"#bba88a\" stroke-width=\"0.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(905 133) scale(0.61)\"><path d=\"M-3 15 20 4 43 17 18 30Z\" fill=\"#52634933\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 1 22 6V24L2 18Z\" fill=\"#d8d0b7\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M22 6 38-1V17L22 24Z\" fill=\"#a9b2a0\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-2 2 12-9 42-1 22 9Z\" fill=\"#806b52\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M12-9 25-12 42-1 22 9Z\" fill=\"#a08d6e\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M7 8v7m6-5v7m14-7v7m5-9v6\" fill=\"none\" stroke=\"#62716b\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M16 22v-9l5 1v10\" fill=\"#5c6255\" stroke=\"#5b5745\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 2 22 7\" fill=\"none\" stroke=\"#d2bea0\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 4 22 10 38 3\" fill=\"none\" stroke=\"#5d5949\" stroke-width=\"0.75\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 15 20 20m5-3 10-4\" fill=\"none\" stroke=\"#b6b399\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M5-2 23 3m-12-10 18 5m-8-10 15 6\" fill=\"none\" stroke=\"#bba88a\" stroke-width=\"0.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(1159 159) scale(0.6)\"><path d=\"M-3 15 20 4 43 17 18 30Z\" fill=\"#52634933\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 1 22 6V24L2 18Z\" fill=\"#d8d0b7\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M22 6 38-1V17L22 24Z\" fill=\"#a9b2a0\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-2 2 12-9 42-1 22 9Z\" fill=\"#806b52\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M12-9 25-12 42-1 22 9Z\" fill=\"#a08d6e\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M7 8v7m6-5v7m14-7v7m5-9v6\" fill=\"none\" stroke=\"#62716b\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M16 22v-9l5 1v10\" fill=\"#5c6255\" stroke=\"#5b5745\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 2 22 7\" fill=\"none\" stroke=\"#d2bea0\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 4 22 10 38 3\" fill=\"none\" stroke=\"#5d5949\" stroke-width=\"0.75\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 15 20 20m5-3 10-4\" fill=\"none\" stroke=\"#b6b399\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M5-2 23 3m-12-10 18 5m-8-10 15 6\" fill=\"none\" stroke=\"#bba88a\" stroke-width=\"0.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(1538 268) scale(0.65)\"><path d=\"M-3 15 20 4 43 17 18 30Z\" fill=\"#52634933\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 1 22 6V24L2 18Z\" fill=\"#d8d0b7\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M22 6 38-1V17L22 24Z\" fill=\"#a9b2a0\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-2 2 12-9 42-1 22 9Z\" fill=\"#806b52\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M12-9 25-12 42-1 22 9Z\" fill=\"#a08d6e\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M7 8v7m6-5v7m14-7v7m5-9v6\" fill=\"none\" stroke=\"#62716b\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M16 22v-9l5 1v10\" fill=\"#5c6255\" stroke=\"#5b5745\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 2 22 7\" fill=\"none\" stroke=\"#d2bea0\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 4 22 10 38 3\" fill=\"none\" stroke=\"#5d5949\" stroke-width=\"0.75\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 15 20 20m5-3 10-4\" fill=\"none\" stroke=\"#b6b399\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M5-2 23 3m-12-10 18 5m-8-10 15 6\" fill=\"none\" stroke=\"#bba88a\" stroke-width=\"0.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(736 252) scale(0.65)\"><path d=\"M-3 15 20 4 43 17 18 30Z\" fill=\"#52634933\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 1 22 6V24L2 18Z\" fill=\"#d8d0b7\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M22 6 38-1V17L22 24Z\" fill=\"#a9b2a0\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-2 2 12-9 42-1 22 9Z\" fill=\"#806b52\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M12-9 25-12 42-1 22 9Z\" fill=\"#a08d6e\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M7 8v7m6-5v7m14-7v7m5-9v6\" fill=\"none\" stroke=\"#62716b\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M16 22v-9l5 1v10\" fill=\"#5c6255\" stroke=\"#5b5745\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 2 22 7\" fill=\"none\" stroke=\"#d2bea0\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 4 22 10 38 3\" fill=\"none\" stroke=\"#5d5949\" stroke-width=\"0.75\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 15 20 20m5-3 10-4\" fill=\"none\" stroke=\"#b6b399\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M5-2 23 3m-12-10 18 5m-8-10 15 6\" fill=\"none\" stroke=\"#bba88a\" stroke-width=\"0.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(850 282) scale(0.64)\"><path d=\"M-3 15 20 4 43 17 18 30Z\" fill=\"#52634933\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 1 22 6V24L2 18Z\" fill=\"#d8d0b7\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M22 6 38-1V17L22 24Z\" fill=\"#a9b2a0\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-2 2 12-9 42-1 22 9Z\" fill=\"#806b52\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M12-9 25-12 42-1 22 9Z\" fill=\"#a08d6e\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M7 8v7m6-5v7m14-7v7m5-9v6\" fill=\"none\" stroke=\"#62716b\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M16 22v-9l5 1v10\" fill=\"#5c6255\" stroke=\"#5b5745\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 2 22 7\" fill=\"none\" stroke=\"#d2bea0\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 4 22 10 38 3\" fill=\"none\" stroke=\"#5d5949\" stroke-width=\"0.75\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 15 20 20m5-3 10-4\" fill=\"none\" stroke=\"#b6b399\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M5-2 23 3m-12-10 18 5m-8-10 15 6\" fill=\"none\" stroke=\"#bba88a\" stroke-width=\"0.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(879 289) scale(0.65)\"><path d=\"M-3 15 20 4 43 17 18 30Z\" fill=\"#52634933\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 1 22 6V24L2 18Z\" fill=\"#d8d0b7\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M22 6 38-1V17L22 24Z\" fill=\"#a9b2a0\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-2 2 12-9 42-1 22 9Z\" fill=\"#806b52\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M12-9 25-12 42-1 22 9Z\" fill=\"#a08d6e\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M7 8v7m6-5v7m14-7v7m5-9v6\" fill=\"none\" stroke=\"#62716b\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M16 22v-9l5 1v10\" fill=\"#5c6255\" stroke=\"#5b5745\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 2 22 7\" fill=\"none\" stroke=\"#d2bea0\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 4 22 10 38 3\" fill=\"none\" stroke=\"#5d5949\" stroke-width=\"0.75\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 15 20 20m5-3 10-4\" fill=\"none\" stroke=\"#b6b399\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M5-2 23 3m-12-10 18 5m-8-10 15 6\" fill=\"none\" stroke=\"#bba88a\" stroke-width=\"0.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(774 284) scale(0.67)\"><path d=\"M-3 15 20 4 43 17 18 30Z\" fill=\"#52634933\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 1 22 6V24L2 18Z\" fill=\"#d8d0b7\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M22 6 38-1V17L22 24Z\" fill=\"#a9b2a0\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-2 2 12-9 42-1 22 9Z\" fill=\"#806b52\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M12-9 25-12 42-1 22 9Z\" fill=\"#a08d6e\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M7 8v7m6-5v7m14-7v7m5-9v6\" fill=\"none\" stroke=\"#62716b\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M16 22v-9l5 1v10\" fill=\"#5c6255\" stroke=\"#5b5745\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 2 22 7\" fill=\"none\" stroke=\"#d2bea0\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 4 22 10 38 3\" fill=\"none\" stroke=\"#5d5949\" stroke-width=\"0.75\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 15 20 20m5-3 10-4\" fill=\"none\" stroke=\"#b6b399\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M5-2 23 3m-12-10 18 5m-8-10 15 6\" fill=\"none\" stroke=\"#bba88a\" stroke-width=\"0.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(808 295) scale(0.65)\"><path d=\"M-3 15 20 4 43 17 18 30Z\" fill=\"#52634933\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 1 22 6V24L2 18Z\" fill=\"#d8d0b7\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M22 6 38-1V17L22 24Z\" fill=\"#a9b2a0\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-2 2 12-9 42-1 22 9Z\" fill=\"#806b52\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M12-9 25-12 42-1 22 9Z\" fill=\"#a08d6e\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M7 8v7m6-5v7m14-7v7m5-9v6\" fill=\"none\" stroke=\"#62716b\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M16 22v-9l5 1v10\" fill=\"#5c6255\" stroke=\"#5b5745\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 2 22 7\" fill=\"none\" stroke=\"#d2bea0\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 4 22 10 38 3\" fill=\"none\" stroke=\"#5d5949\" stroke-width=\"0.75\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 15 20 20m5-3 10-4\" fill=\"none\" stroke=\"#b6b399\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M5-2 23 3m-12-10 18 5m-8-10 15 6\" fill=\"none\" stroke=\"#bba88a\" stroke-width=\"0.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(843 305) scale(0.62)\"><path d=\"M-3 15 20 4 43 17 18 30Z\" fill=\"#52634933\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 1 22 6V24L2 18Z\" fill=\"#d8d0b7\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M22 6 38-1V17L22 24Z\" fill=\"#a9b2a0\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-2 2 12-9 42-1 22 9Z\" fill=\"#806b52\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M12-9 25-12 42-1 22 9Z\" fill=\"#a08d6e\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M7 8v7m6-5v7m14-7v7m5-9v6\" fill=\"none\" stroke=\"#62716b\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M16 22v-9l5 1v10\" fill=\"#5c6255\" stroke=\"#5b5745\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 2 22 7\" fill=\"none\" stroke=\"#d2bea0\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 4 22 10 38 3\" fill=\"none\" stroke=\"#5d5949\" stroke-width=\"0.75\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 15 20 20m5-3 10-4\" fill=\"none\" stroke=\"#b6b399\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M5-2 23 3m-12-10 18 5m-8-10 15 6\" fill=\"none\" stroke=\"#bba88a\" stroke-width=\"0.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(12 161) scale(0.65)\"><path d=\"M0 0v13\" fill=\"none\" stroke=\"#69674b\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-11-6q-9-7-2-13 0-10 10-10 7-8 14 0 11-1 10 8 7 8-2 14-16 6-30 1Z\" fill=\"#68854c\" stroke=\"#587547\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-10-17q7-9 13-4m-2 11q8 4 13-3\" fill=\"none\" stroke=\"#92a46c\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(207 132) scale(0.58)\"><path d=\"M0 0v13\" fill=\"none\" stroke=\"#69674b\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-11-6q-9-7-2-13 0-10 10-10 7-8 14 0 11-1 10 8 7 8-2 14-16 6-30 1Z\" fill=\"#68854c\" stroke=\"#587547\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-10-17q7-9 13-4m-2 11q8 4 13-3\" fill=\"none\" stroke=\"#92a46c\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(232 139) scale(0.59)\"><path d=\"M0 0v13\" fill=\"none\" stroke=\"#69674b\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-11-6q-9-7-2-13 0-10 10-10 7-8 14 0 11-1 10 8 7 8-2 14-16 6-30 1Z\" fill=\"#68854c\" stroke=\"#587547\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-10-17q7-9 13-4m-2 11q8 4 13-3\" fill=\"none\" stroke=\"#92a46c\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(292 126) scale(0.55)\"><path d=\"M0 0v13\" fill=\"none\" stroke=\"#69674b\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-11-6q-9-7-2-13 0-10 10-10 7-8 14 0 11-1 10 8 7 8-2 14-16 6-30 1Z\" fill=\"#68854c\" stroke=\"#587547\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-10-17q7-9 13-4m-2 11q8 4 13-3\" fill=\"none\" stroke=\"#92a46c\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(364 130) scale(0.51)\"><path d=\"M0 0v13\" fill=\"none\" stroke=\"#69674b\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-11-6q-9-7-2-13 0-10 10-10 7-8 14 0 11-1 10 8 7 8-2 14-16 6-30 1Z\" fill=\"#68854c\" stroke=\"#587547\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-10-17q7-9 13-4m-2 11q8 4 13-3\" fill=\"none\" stroke=\"#92a46c\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(576 142) scale(0.45)\"><path d=\"M0 0v13\" fill=\"none\" stroke=\"#69674b\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-11-6q-9-7-2-13 0-10 10-10 7-8 14 0 11-1 10 8 7 8-2 14-16 6-30 1Z\" fill=\"#68854c\" stroke=\"#587547\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-10-17q7-9 13-4m-2 11q8 4 13-3\" fill=\"none\" stroke=\"#92a46c\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(609 127) scale(0.46)\"><path d=\"M0 0v13\" fill=\"none\" stroke=\"#69674b\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-11-6q-9-7-2-13 0-10 10-10 7-8 14 0 11-1 10 8 7 8-2 14-16 6-30 1Z\" fill=\"#68854c\" stroke=\"#587547\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-10-17q7-9 13-4m-2 11q8 4 13-3\" fill=\"none\" stroke=\"#92a46c\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(651 125) scale(0.52)\"><path d=\"M0 0v13\" fill=\"none\" stroke=\"#69674b\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-11-6q-9-7-2-13 0-10 10-10 7-8 14 0 11-1 10 8 7 8-2 14-16 6-30 1Z\" fill=\"#68854c\" stroke=\"#587547\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-10-17q7-9 13-4m-2 11q8 4 13-3\" fill=\"none\" stroke=\"#92a46c\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(895 125) scale(0.48)\"><path d=\"M0 0v13\" fill=\"none\" stroke=\"#69674b\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-11-6q-9-7-2-13 0-10 10-10 7-8 14 0 11-1 10 8 7 8-2 14-16 6-30 1Z\" fill=\"#68854c\" stroke=\"#587547\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-10-17q7-9 13-4m-2 11q8 4 13-3\" fill=\"none\" stroke=\"#92a46c\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(1116 119) scale(0.44)\"><path d=\"M0 0v13\" fill=\"none\" stroke=\"#69674b\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-11-6q-9-7-2-13 0-10 10-10 7-8 14 0 11-1 10 8 7 8-2 14-16 6-30 1Z\" fill=\"#68854c\" stroke=\"#587547\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-10-17q7-9 13-4m-2 11q8 4 13-3\" fill=\"none\" stroke=\"#92a46c\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(1179 123) scale(0.51)\"><path d=\"M0 0v13\" fill=\"none\" stroke=\"#69674b\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-11-6q-9-7-2-13 0-10 10-10 7-8 14 0 11-1 10 8 7 8-2 14-16 6-30 1Z\" fill=\"#68854c\" stroke=\"#587547\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-10-17q7-9 13-4m-2 11q8 4 13-3\" fill=\"none\" stroke=\"#92a46c\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(1554 301) scale(0.74)\"><path d=\"M0 0v13\" fill=\"none\" stroke=\"#69674b\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-11-6q-9-7-2-13 0-10 10-10 7-8 14 0 11-1 10 8 7 8-2 14-16 6-30 1Z\" fill=\"#68854c\" stroke=\"#587547\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-10-17q7-9 13-4m-2 11q8 4 13-3\" fill=\"none\" stroke=\"#92a46c\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(1516 311) scale(0.75)\"><path d=\"M0 0v13\" fill=\"none\" stroke=\"#69674b\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-11-6q-9-7-2-13 0-10 10-10 7-8 14 0 11-1 10 8 7 8-2 14-16 6-30 1Z\" fill=\"#68854c\" stroke=\"#587547\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-10-17q7-9 13-4m-2 11q8 4 13-3\" fill=\"none\" stroke=\"#92a46c\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(23 312) scale(0.78)\"><path d=\"M0 0v13\" fill=\"none\" stroke=\"#69674b\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-11-6q-9-7-2-13 0-10 10-10 7-8 14 0 11-1 10 8 7 8-2 14-16 6-30 1Z\" fill=\"#68854c\" stroke=\"#587547\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-10-17q7-9 13-4m-2 11q8 4 13-3\" fill=\"none\" stroke=\"#92a46c\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(184 317) scale(0.62)\"><path d=\"M0 0v13\" fill=\"none\" stroke=\"#69674b\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-11-6q-9-7-2-13 0-10 10-10 7-8 14 0 11-1 10 8 7 8-2 14-16 6-30 1Z\" fill=\"#68854c\" stroke=\"#587547\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-10-17q7-9 13-4m-2 11q8 4 13-3\" fill=\"none\" stroke=\"#92a46c\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(379 310) scale(0.63)\"><path d=\"M0 0v13\" fill=\"none\" stroke=\"#69674b\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-11-6q-9-7-2-13 0-10 10-10 7-8 14 0 11-1 10 8 7 8-2 14-16 6-30 1Z\" fill=\"#68854c\" stroke=\"#587547\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-10-17q7-9 13-4m-2 11q8 4 13-3\" fill=\"none\" stroke=\"#92a46c\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><g transform=\"translate(869 310) scale(0.65)\"><path d=\"M0 0v13\" fill=\"none\" stroke=\"#69674b\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-11-6q-9-7-2-13 0-10 10-10 7-8 14 0 11-1 10 8 7 8-2 14-16 6-30 1Z\" fill=\"#68854c\" stroke=\"#587547\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-10-17q7-9 13-4m-2 11q8 4 13-3\" fill=\"none\" stroke=\"#92a46c\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g><path d=\"M123 192l27-8m-25 14 27-8M125 181v21m13-25v21m13-26v21M358 275l41-12m-39 18 41-12m-39-4v18m19-24v18m20-24v18\" fill=\"none\" stroke=\"#a4a276\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M848 245l21-7 18 7-20 9Z\" fill=\"#c8b58b\" stroke=\"#7e7f60\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M849 241l21-7 18 7-20 9Z\" fill=\"#9b7560\" stroke=\"#7a7459\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M852 241v10m30-8v10\" fill=\"none\" stroke=\"#78684e\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M1407 278l22-7 16 9-22 7Z\" fill=\"#8e8364\" stroke=\"#6d6c54\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M1414 277v-8l14-5 10 8v6\" fill=\"#a2a28b\" stroke=\"#6d6c54\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><ellipse cx=\"1416\" cy=\"284\" rx=\"3\" ry=\"4\" fill=\"#555b47\" stroke=\"#c0b78c\" stroke-width=\".7\"/><ellipse cx=\"1437\" cy=\"278\" rx=\"3\" ry=\"4\" fill=\"#555b47\" stroke=\"#c0b78c\" stroke-width=\".7\"/></g>", hn = "<g transform=\"translate(0 0) scale(1)\"><path d=\"M-3 15 20 4 43 17 18 30Z\" fill=\"#52634933\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 1 22 6V24L2 18Z\" fill=\"#d8d0b7\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M22 6 38-1V17L22 24Z\" fill=\"#a9b2a0\" stroke=\"#695f4c\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M-2 2 12-9 42-1 22 9Z\" fill=\"#806b52\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M12-9 25-12 42-1 22 9Z\" fill=\"#a08d6e\" stroke=\"#504b3b\" stroke-width=\"0.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M7 8v7m6-5v7m14-7v7m5-9v6\" fill=\"none\" stroke=\"#62716b\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M16 22v-9l5 1v10\" fill=\"#5c6255\" stroke=\"#5b5745\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 2 22 7\" fill=\"none\" stroke=\"#d2bea0\" stroke-width=\"0.65\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M2 4 22 10 38 3\" fill=\"none\" stroke=\"#5d5949\" stroke-width=\"0.75\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M4 15 20 20m5-3 10-4\" fill=\"none\" stroke=\"#b6b399\" stroke-width=\"0.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M5-2 23 3m-12-10 18 5m-8-10 15 6\" fill=\"none\" stroke=\"#bba88a\" stroke-width=\"0.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g>", gn = "<defs><symbol id=\"tta-a-barracks\" viewBox=\"0 0 300 240\"><svg x=\"0\" y=\"0\" width=\"300\" height=\"240\" viewBox=\"0 0 300 240\"><path d=\"M9 187 149 141 286 187 154 235Z\" fill=\"#485c3c33\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M37 101 159 131V205L37 177Z\" fill=\"#c4baa0\" stroke=\"#5e5c49\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M159 131 255 96V167L159 205Z\" fill=\"#a0a88f\" stroke=\"#5e5c49\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M27 103 77 59 267 96 160 138Z\" fill=\"#7e7157\" stroke=\"#544b39\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M77 59 127 45 267 96 160 138Z\" fill=\"#9e8b67\" stroke=\"#544b39\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M43 101l39-35\" fill=\"none\" stroke=\"#bdac86\" stroke-width=\"0.9\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M56 104.1l39-35\" fill=\"none\" stroke=\"#bdac86\" stroke-width=\"0.9\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M69 107.2l39-35\" fill=\"none\" stroke=\"#bdac86\" stroke-width=\"0.9\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M82 110.3l39-35\" fill=\"none\" stroke=\"#bdac86\" stroke-width=\"0.9\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M95 113.4l39-35\" fill=\"none\" stroke=\"#bdac86\" stroke-width=\"0.9\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M108 116.5l39-35\" fill=\"none\" stroke=\"#bdac86\" stroke-width=\"0.9\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M121 119.6l39-35\" fill=\"none\" stroke=\"#bdac86\" stroke-width=\"0.9\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M134 122.7l39-35\" fill=\"none\" stroke=\"#bdac86\" stroke-width=\"0.9\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M37 101 159 131V205L37 177Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M159 131 255 96V167L159 205Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M27 103 77 59 267 96 160 138Z\" fill=\"url(#tta-tiles)\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M38 106 158 135 256 101\" fill=\"none\" stroke=\"#524b3d\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M50 115 150 140m-100 11 100 25m-79-54v59m40-50v60\" fill=\"none\" stroke=\"#817a60\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M52 123v27l17 5v-27m16 4v27l17 4v-26m15 4v27l17 4v-27\" fill=\"#667568\" stroke=\"#766d54\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M54 125l13 3m20 6 13 3m19 7 13 3\" fill=\"none\" stroke=\"#b9baa0\" stroke-width=\"1.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M43 166l110 28m15-4 78-27\" fill=\"none\" stroke=\"#e1d4b2\" stroke-width=\"1.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M178 190v-39q15-22 30-10v39Z\" fill=\"#525a48\" stroke=\"#5e5c49\" stroke-width=\"1.1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M48 92V19m0 3 42 10-42 9\" fill=\"#a56f51\" stroke=\"#645d43\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M25 182 60 194 91 180 56 169Z\" fill=\"#b2b08d\" stroke=\"#8e8a68\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M31 184v-46m-3 0 3-8 3 8Z\" fill=\"#adb5a6\" stroke=\"#6c6752\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M43 184.8v-46m-3 0 3-8 3 8Z\" fill=\"#adb5a6\" stroke=\"#6c6752\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M55 185.6v-46m-3 0 3-8 3 8Z\" fill=\"#adb5a6\" stroke=\"#6c6752\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M67 186.4v-46m-3 0 3-8 3 8Z\" fill=\"#adb5a6\" stroke=\"#6c6752\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M232 185v-22l12-4 11 5v20q-9 15-23 1Z\" fill=\"#9b7854\" stroke=\"#645541\" stroke-width=\"1.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M244 165v29m-10-18 19-4\" fill=\"none\" stroke=\"#cab38b\" stroke-width=\"1.1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></svg></symbol><symbol id=\"tta-a-stable\" viewBox=\"0 0 300 240\"><svg x=\"0\" y=\"0\" width=\"300\" height=\"240\" viewBox=\"0 0 300 240\"><path d=\"M6 190 142 144 291 190 158 236Z\" fill=\"#485c3c33\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M36 97 154 129V198L36 171Z\" fill=\"#cdbf9e\" stroke=\"#5d5a46\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M154 129 270 93V162L154 198Z\" fill=\"#a7ab8e\" stroke=\"#5d5a46\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M23 99 85 56 279 94 155 139Z\" fill=\"#8d7957\" stroke=\"#514b39\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M85 56 132 43 279 94 155 139Z\" fill=\"#ac976d\" stroke=\"#514b39\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M43 99l44-35\" fill=\"none\" stroke=\"#d1bc91\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M59 102.3l44-35\" fill=\"none\" stroke=\"#d1bc91\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M75 105.6l44-35\" fill=\"none\" stroke=\"#d1bc91\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M91 108.9l44-35\" fill=\"none\" stroke=\"#d1bc91\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M107 112.2l44-35\" fill=\"none\" stroke=\"#d1bc91\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M123 115.5l44-35\" fill=\"none\" stroke=\"#d1bc91\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M139 118.8l44-35\" fill=\"none\" stroke=\"#d1bc91\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M168 186v-40q10-15 20-7v40Z\" fill=\"#4e5947\" stroke=\"#655d47\" stroke-width=\"1.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M197 177v-40q10-15 20-7v40Z\" fill=\"#4e5947\" stroke=\"#655d47\" stroke-width=\"1.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M226 168v-40q10-15 20-7v40Z\" fill=\"#4e5947\" stroke=\"#655d47\" stroke-width=\"1.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M36 97 154 129V198L36 171Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M154 129 270 93V162L154 198Z\" fill=\"url(#tta-masonry)\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M23 99 85 56 279 94 155 139Z\" fill=\"url(#tta-tiles)\" stroke=\"none\" stroke-width=\"0\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M35 104 154 136 270 100\" fill=\"none\" stroke=\"#554d3c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M45 112v59m45-46v57m41-45v54M36 144l115 30\" fill=\"none\" stroke=\"#756749\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M54 118v19l23 6v-19m26 6v20l23 6v-20\" fill=\"#6a7561\" stroke=\"#726a50\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M43 161l107 25m14 3 95-29\" fill=\"none\" stroke=\"#dfd0aa\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M180 151v31m28-40v31m28-40v31\" fill=\"none\" stroke=\"#bda57a\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M23 192 94 212 130 197M24 174v38m34-28v37m36-28v34m35-46v28M23 184l70 20 36-15\" fill=\"none\" stroke=\"#968c64\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M49 189q-9-3-5-12l11-4 13 4 6-8 8-1 4 9-8 3-3 14-9 2-2-9-5 8-7-1Z\" fill=\"#9c8157\" stroke=\"#5f4f37\" stroke-width=\"1.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M52 190v9m17-7v9M45 180q-8-6-5 4\" fill=\"none\" stroke=\"#5f4f37\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M244 81V21m0 3 27 10-27 8\" fill=\"#a06e55\" stroke=\"#655b43\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></svg></symbol></defs>", _n = "<defs>\n<radialGradient id=\"tta-silver\" cx=\".34\" cy=\".26\" r=\".74\"><stop stop-color=\"#ffffff\"/><stop offset=\".40\" stop-color=\"#e3e9e8\"/><stop offset=\".77\" stop-color=\"#a9b7b9\"/><stop offset=\"1\" stop-color=\"#74898e\"/></radialGradient>\n<radialGradient id=\"tta-red\" cx=\".34\" cy=\".24\" r=\".76\"><stop stop-color=\"#ffd1b2\"/><stop offset=\".27\" stop-color=\"#ec6455\"/><stop offset=\".62\" stop-color=\"#c73833\"/><stop offset=\"1\" stop-color=\"#7c242a\"/></radialGradient>\n<symbol id=\"tta-i-civil\" viewBox=\"0 0 24 24\"><circle cx=\"12\" cy=\"12\" r=\"10.5\" fill=\"#71858a\" stroke=\"#c0cdca\" stroke-width=\".9\"/><circle cx=\"12\" cy=\"11.7\" r=\"8.7\" fill=\"url(#tta-silver)\" stroke=\"#e3ebe6\" stroke-width=\"1\"/><path d=\"M5.9 8.5a6.8 6.8 0 0 1 8.3-3.1\" fill=\"none\" stroke=\"#fff\" stroke-width=\"1.2\" opacity=\".7\"/></symbol>\n<symbol id=\"tta-i-military\" viewBox=\"0 0 24 24\"><circle cx=\"12\" cy=\"12\" r=\"10.5\" fill=\"#723d3e\" stroke=\"#b98176\" stroke-width=\".9\"/><circle cx=\"12\" cy=\"11.7\" r=\"8.7\" fill=\"url(#tta-red)\" stroke=\"#dca08e\" stroke-width=\".85\"/><path d=\"M6.2 8.4a6.3 6.3 0 0 1 7.9-3\" fill=\"none\" stroke=\"#ffbba5\" stroke-width=\"1.1\" opacity=\".6\"/></symbol>\n<linearGradient id=\"tta-blue-front\" x2=\"1\" y2=\"1\"><stop stop-color=\"#77b0cc\"/><stop offset=\"1\" stop-color=\"#417eaa\"/></linearGradient>\n<linearGradient id=\"tta-yellow\" x2=\"1\" y2=\"1\"><stop stop-color=\"#f2d16c\"/><stop offset=\"1\" stop-color=\"#b58a36\"/></linearGradient>\n<symbol id=\"tta-i-blue\" viewBox=\"0 0 26 28\"><path d=\"M2 8 5 2h16l3 6v18H2Z\" fill=\"#245575\" stroke=\"#173b50\" stroke-width=\"1.1\"/><path d=\"M5 3h16l2 5H3Z\" fill=\"#1c4560\"/><path d=\"M3 8h20v17H3Z\" fill=\"url(#tta-blue-front)\" stroke=\"#2d5c7c\" stroke-width=\"1\"/><path d=\"M5.3 10.3h15.4v12.4H5.3Z\" fill=\"none\" stroke=\"#225a7f\" stroke-width=\"1\"/><path d=\"m6 22 14-11\" fill=\"none\" stroke=\"#285b7b\" stroke-width=\"1.5\"/><path d=\"M5 10v12m0-12h15M3 8h20\" fill=\"none\" stroke=\"#9bcee0\" stroke-width=\".8\" opacity=\".8\"/></symbol>\n<symbol id=\"tta-i-population\" viewBox=\"0 0 20 32\"><path d=\"M10 1.5a3.5 3.5 0 1 1 0 7 3.5 3.5 0 0 1 0-7ZM6.5 10h7l4 8-3 1.5-2-4v14.7H9.7l-.6-9.3-.6 9.3H5.6V15.6l-2 3.9L1 18Z\" fill=\"url(#tta-yellow)\" stroke=\"#675427\" stroke-width=\"1\" stroke-linejoin=\"round\"/><path d=\"M8 3.1a2 2 0 0 1 3-.2M6.8 12h1\" fill=\"none\" stroke=\"#fbe8a1\" stroke-width=\".9\" stroke-linecap=\"round\"/></symbol>\n<symbol id=\"tta-i-discontent\" viewBox=\"0 0 24 24\"><path d=\"M5 2h14l3 3v14l-3 3H5l-3-3V5Z\" fill=\"#e6b749\" stroke=\"#7d622c\" stroke-width=\"1\"/><path d=\"M6 4h12\" stroke=\"#ffdd83\"/><path d=\"M8 8v3m8-3v3M7 17q5-6 10 0\" fill=\"none\" stroke=\"#5e4825\" stroke-width=\"1.5\" stroke-linecap=\"round\"/></symbol>\n<symbol id=\"tta-i-urban\" viewBox=\"0 0 24 24\"><path d=\"M3 20V9l9-6 9 6v11Zm7 0v-7h4v7M5 9h14M6 6l6-4 6 4\" fill=\"#d4dcd3\" stroke=\"#53646b\" stroke-width=\"1.4\"/></symbol>\n<symbol id=\"tta-i-cards\" viewBox=\"0 0 24 24\"><path d=\"M3 5h14v17H3Z\" fill=\"#8a6d64\" stroke=\"#514741\"/><path d=\"M7 2h14v17H7Z\" fill=\"#ede7d6\" stroke=\"#69674f\"/><path d=\"m10 7 4-2 4 2v7l-4 3-4-3Z\" fill=\"#9c6c5c\"/></symbol>\n<symbol id=\"tta-i-infantry\" viewBox=\"0 0 24 24\"><path d=\"m5 3 14 17m0-17L5 20M3 16l5 5m8-18 5 5M4 2l4 1-4 4Z\" fill=\"#b8c7c9\" stroke=\"#4e6363\" stroke-width=\"1.8\"/></symbol>\n<symbol id=\"tta-i-cavalry\" viewBox=\"0 0 24 24\"><path d=\"m5 21 1-6 6-5-4 2-4-2 4-6 4-1 2-2 2 4q7 5 4 16Z\" fill=\"#b9bb9f\" stroke=\"#5f624b\" stroke-width=\"1.3\"/><circle cx=\"10\" cy=\"6\" r=\"1\" fill=\"#4d5547\"/></symbol>\n<symbol id=\"tta-i-artillery\" viewBox=\"0 0 24 24\"><path d=\"m3 10 17-7 2 5-17 7Z\" fill=\"#728479\" stroke=\"#435b4f\"/><circle cx=\"9\" cy=\"17\" r=\"5\" fill=\"#b9b293\" stroke=\"#625b47\" stroke-width=\"1.4\"/><path d=\"M9 13v8m-4-4h8m-1-6 7 10\" fill=\"none\" stroke=\"#625b47\"/></symbol>\n</defs>", vn = {
	homer: {
		hair: "#d5d4c5",
		robe: "#979e86",
		beard: "long",
		style: "curly"
	},
	moses: {
		hair: "#d6d1bc",
		robe: "#c8c8ae",
		beard: "long",
		hat: "hood"
	},
	alexander: {
		hair: "#90714c",
		robe: "#8c6460",
		hat: "laurel",
		style: "curly"
	},
	hammurabi: {
		hair: "#3e4640",
		robe: "#a28f62",
		beard: "long",
		hat: "crown"
	},
	caesar: {
		hair: "#969b8c",
		robe: "#9e675d",
		hat: "laurel"
	},
	aristotle: {
		hair: "#7b7560",
		robe: "#a8ad95",
		beard: "short",
		style: "curly"
	},
	ashoka: {
		hair: "#394d46",
		robe: "#b49b61",
		skin: "#bc9573",
		hat: "crown"
	},
	cleopatra: {
		hair: "#263f3f",
		robe: "#557d7a",
		skin: "#c5a17b",
		hat: "egypt",
		female: !0
	},
	sunTzu: {
		hair: "#354842",
		robe: "#5d8275",
		skin: "#c6a582",
		beard: "goatee",
		hat: "bun"
	},
	confucius: {
		hair: "#bfc5b5",
		robe: "#9ca591",
		skin: "#caaa86",
		beard: "long",
		hat: "scholar"
	},
	boudica: {
		hair: "#956348",
		robe: "#698774",
		female: !0,
		style: "long"
	},
	hippocrates: {
		hair: "#d6d7c9",
		robe: "#b7bba5",
		beard: "short",
		style: "bald"
	},
	joan: {
		hair: "#544f43",
		robe: "#7b9190",
		female: !0,
		style: "bob"
	},
	columbus: {
		hair: "#7c6d55",
		robe: "#85675a",
		hat: "beret"
	},
	daVinci: {
		hair: "#b7c0b0",
		robe: "#8d7561",
		beard: "long",
		hat: "beret"
	},
	barbarossa: {
		hair: "#a07551",
		robe: "#8f7770",
		beard: "long",
		hat: "crown"
	},
	genghis: {
		hair: "#3b4e46",
		robe: "#998a67",
		skin: "#bd9876",
		beard: "moustache",
		hat: "helmet"
	},
	isabella: {
		hair: "#92775d",
		robe: "#a89779",
		female: !0,
		hat: "veil"
	},
	nostradamus: {
		hair: "#a9ac99",
		robe: "#66786c",
		beard: "long",
		hat: "beret"
	},
	zizka: {
		hair: "#806a50",
		robe: "#6e8580",
		beard: "short",
		hat: "helmet",
		style: "patch"
	},
	saladin: {
		hair: "#3e5148",
		robe: "#a7ad8e",
		skin: "#bf9b73",
		beard: "short",
		hat: "turban"
	},
	eleanor: {
		hair: "#a3835f",
		robe: "#8d6a64",
		female: !0,
		hat: "veil"
	},
	gutenberg: {
		hair: "#b7bfad",
		robe: "#755f55",
		beard: "long",
		hat: "scholar"
	},
	cook: {
		hair: "#9e9d85",
		robe: "#4c6e78",
		hat: "tricorn"
	},
	robespierre: {
		hair: "#d0d0c0",
		robe: "#6c8c7d",
		style: "wig"
	},
	bach: {
		hair: "#c7c7b6",
		robe: "#536c6d",
		style: "wig"
	},
	newton: {
		hair: "#a8aa99",
		robe: "#716c67",
		style: "wig"
	},
	shakespeare: {
		hair: "#685d47",
		robe: "#7c6860",
		beard: "goatee",
		style: "bald"
	},
	napoleon: {
		hair: "#576153",
		robe: "#506e76",
		hat: "bicorne"
	},
	gaudi: {
		hair: "#b0b8a9",
		robe: "#78877a",
		beard: "short",
		hat: "fedora"
	},
	darwin: {
		hair: "#d7d9c9",
		robe: "#64756c",
		beard: "long",
		style: "bald"
	},
	watt: {
		hair: "#a3a692",
		robe: "#5e766f",
		style: "wig"
	},
	nobel: {
		hair: "#8f927e",
		robe: "#586d6b",
		beard: "short"
	},
	catherine: {
		hair: "#c9cbba",
		robe: "#709287",
		female: !0,
		hat: "crown",
		style: "wig"
	},
	mariaTheresa: {
		hair: "#c4c5b1",
		robe: "#917d70",
		female: !0,
		hat: "crown",
		style: "wig"
	},
	chaplin: {
		hair: "#3b4d47",
		robe: "#405c60",
		beard: "toothbrush",
		hat: "bowler"
	},
	gandhi: {
		hair: "#c2c5b2",
		robe: "#d3d7c6",
		skin: "#aa8b69",
		style: "bald",
		glasses: !0
	},
	einstein: {
		hair: "#dce0d0",
		robe: "#7b8e82",
		beard: "moustache",
		style: "wild"
	},
	churchill: {
		hair: "#b9c1ae",
		robe: "#4b6469",
		style: "bald"
	},
	billGates: {
		hair: "#8e7e61",
		robe: "#738b89",
		glasses: !0
	},
	sidMeier: {
		hair: "#a5b19f",
		robe: "#5a7971",
		beard: "short",
		glasses: !0
	},
	curie: {
		hair: "#42564c",
		robe: "#596e6d",
		female: !0,
		hat: "bun"
	},
	jobs: {
		hair: "#a3ae9c",
		robe: "#344f55",
		beard: "short",
		style: "bald",
		glasses: !0
	},
	fleming: {
		hair: "#9ca68e",
		robe: "#607a77"
	},
	dietrich: {
		hair: "#c8ba86",
		robe: "#80978b",
		female: !0,
		style: "bob"
	},
	mandela: {
		hair: "#a8b09b",
		robe: "#688f82",
		skin: "#917659",
		style: "curly"
	},
	coubertin: {
		hair: "#84765d",
		robe: "#627c7d",
		beard: "moustache"
	}
}, U = (e, t, n = "#607265", r = 1.4) => `<path d="${e}" fill="${t}" stroke="${n}" stroke-width="${r}" stroke-linejoin="round"/>`, W = (e, t = "#869781", n = 1.2) => U(e, "none", t, n), G = (e, t, n, r, i) => `<ellipse cx="${e}" cy="${t}" rx="${n}" ry="${r}" fill="${i}"/>`, yn = (e, t = 0, n = 0, r = 300, i = 240) => `<use href="#tta-a-${e}" x="${t}" y="${n}" width="${r}" height="${i}"/>`, bn = (e, t) => `<symbol id="tta-a-${e}" viewBox="0 0 300 240">${t}</symbol>`, xn = {
	laurel: U("M106 60q40-47 89 0l-6 5q-39-36-76 0Z", "#a6a979") + W("M113 53l-7-9m18 0-4-12m18 7-1-12m16 11 2-12m12 14 6-11m7 19 9-8", "#d0c996", 3),
	crown: U("M109 52l-4-25 22 10 22-25 22 25 23-10-4 25Z", "#c3af6f") + W("M113 45h73", "#e2d29b", 3),
	egypt: U("M104 38q47-36 94 0l8 109-23-9-9-74-28-10-24 14-7 73-18 7Z", "#344d4c") + W("M104 46h90m-75 8 5 78m-15-72 3 78m78-78 5 78m-16-75 7 69", "#bdad72", 4),
	bun: G(149, 21, 17, 13, "#45584b") + W("M136 25h29", "#b3b49a", 3),
	scholar: U("M103 46l7-29 42-10 40 12 8 28-48-9Z", "#3e5451") + W("M108 32q42-20 86 2", "#829481"),
	beret: U("M98 48q-7-27 27-35l58 1q27 8 18 31l-52-6Z", "#3e5553") + W("M104 45q49-15 92-1", "#9cac98"),
	helmet: U("M101 56q1-45 47-49 47 3 53 46l-23-8-29 11-31-11Z", "#6a8177") + W("M148 9v45m-41-10q41-11 88 0", "#b5baa3", 3),
	turban: U("M100 50q-7-44 47-47 53 3 56 47l-53-11Z", "#c7cbb3") + W("M104 23l88 23m-75-34 78 24m-89 5 80-24", "#8c9f85", 3),
	veil: U("M102 37q45-37 94 0l15 109-23-8-12-80-29-14-25 17-9 77-25 11Z", "#c6c7ae") + U("M111 43l-2-20 21 7 20-17 19 18 23-8-4 20Z", "#bca66c"),
	hood: U("M104 44q43-47 91 0l21 104-26 13-12-92-29-22-28 21-15 90-24-13Z", "#b9bda1"),
	tricorn: U("M84 45l39-20 25-28 31 28 42 20-32 10-40-14-40 14Z", "#3c5558") + W("M91 44l32-12 25-25 28 26 37 13", "#b7b89b", 3),
	bicorne: U("M72 49l46-13q9-36 31-35 27 1 35 35l43 12-17 14-61-12-60 13Z", "#304c55") + G(156, 28, 5, 7, "#bba16a"),
	fedora: U("M91 46l27-6 6-28 43-4 19 31 24 7-10 10-103-2Z", "#718171") + W("M116 38l70 1", "#445a51", 5),
	bowler: U("M111 40q-2-39 38-40 39 0 39 40l20 6-6 8H98l-7-8Z", "#344e53")
};
function Sn(e) {
	let t = e.skin ?? "#d6b793", n = e.female, r = "<rect x=\"42\" y=\"4\" width=\"216\" height=\"230\" fill=\"#b4c7c8\"/>";
	(n || e.style === "wig" || e.style === "wild") && (r += U(n ? "M101 50q0-36 49-40 48 1 51 40l13 112-34 16-65-11-24-12Z" : "M95 45q14-35 54-32 51-5 65 38l-9 62-25 34-65-1-29-46Z", e.hair)), r += U("M60 231q8-58 58-74l10-23h43l12 23q50 14 60 74Z", e.robe), r += U("M129 125l-4 35 26 26 26-26-7-35Z", t), r += U(n ? "M109 58q1-33 41-35 40 4 42 35l-4 53-17 29-21 12-22-12-16-29Z" : "M106 62q1-40 45-41 43 3 45 41l-7 52-17 27-22 12-24-14-17-28Z", t, "#897b61"), e.style === "bald" ? r += U("M106 65l10-12-3 30-8 11m91-30-12-13 2 33 8 8Z", e.hair) : r += U(n ? "M106 67q-10-50 44-52 56 2 45 54l-18-21-30-10-27 21Z" : "M104 64q-4-48 47-50 51 2 47 50l-15-21-35-8-29 18Z", e.hair), e.style === "wild" && (r += U("M101 58l-19 5 9-19-8-4 19-7-1-16 25 6 18-15 16 11 23-8 5 20 22 3-4 14 11 15-22-3-11-26-35-6-31 16Z", e.hair)), r += W("M119 81q10-5 20-1m23 0q10-4 18 2", "#6d725b", 2.3), r += G(131, 87, 3, 2.4, "#45554b") + G(169, 87, 3, 2.4, "#45554b"), r += W("M150 87l-7 22 13 2m-20 12q14 6 29-1M117 101l8 6m51-6-8 7", "#9b896d", 1.6), e.beard === "long" && (r += U("M115 110l15 7 20-3 18 5 17-10-3 36-14 34-18 12-20-15-13-30Z", e.hair) + W("M125 126l12 33m4-37 9 48m7-47-1 43m14-39-9 31", "#d2d8c4", 1)), e.beard === "short" && (r += U("M115 114l17 12 18 3 17-3 18-13-6 25-29 21-25-16Z", e.hair) + W("M124 128l10 15m10-9 6 15m11-13-2 12", "#c4ceba")), e.beard === "goatee" && (r += U("M134 117l16-3 18 6-17 1m-9 13h17l-9 23Z", e.hair)), e.beard === "moustache" && (r += U("M127 118l20-7 6 1 21 8-13 5-12-6-11 6Z", e.hair)), e.beard === "toothbrush" && (r += U("M143 114h14v8h-14Z", e.hair)), e.glasses && (r += "<g fill=\"none\" stroke=\"#607469\" stroke-width=\"2\"><ellipse cx=\"130\" cy=\"87\" rx=\"14\" ry=\"11\"/><ellipse cx=\"170\" cy=\"87\" rx=\"14\" ry=\"11\"/><path d=\"M144 86h12m-41-2-8-3m78 3 10-3\"/></g>"), e.style === "patch" && (r += U("M157 77l24 2-5 21-20-4Z", "#455a50") + W("M111 65l70 18", "#455a50", 3)), e.hat && (r += xn[e.hat] ?? ""), r += W(n ? "M119 164l30 38 33-39m-32 39v29M88 190l22 37m102-40-24 42" : "M119 164l21 25 11-11 11 11 19-24m-41 24-9 42m32-41 11 40M82 201l28-16m109 16-25-16", "#bcc9b4", 1.5);
	for (let e = 0; e < 17; e++) r += W(`M${72 + e * 10} ${210 + e % 4 * 4}l-7 16`, "#9fb39f", .8);
	return r;
}
var K = U("M16 198l129-38 139 39-134 36Z", "#9ba991", "none"), q = (e) => U(e, "url(#tta-stoneFront)"), Cn = (e, t, n, r, i, a = "#5f7771") => Array.from({ length: n }, (n, o) => U(`M${e + o * r} ${t}h7v${i}h-7Z`, a, "none")).join(""), wn = (e, t) => U(`M${e} ${t + 25}v-25m-11 11q-6-14 10-20 20 4 12 20Z`, "#567c49"), Tn = {
	hangingGardens: K + q("M35 170l113 28 107-29v26l-107 32-113-29Z") + q("M62 129l86 23 82-23v40l-82 25-86-24Z") + q("M91 89l57 16 58-17v39l-58 23-57-21Z") + Cn(75, 144, 5, 18, 22) + wn(111, 83) + wn(148, 99) + wn(191, 83) + wn(47, 151) + wn(240, 146),
	colossus: K + q("M108 172l44-13 43 14v34l-43 15-44-15Z") + U("M131 165l4-55-17-20-10 39-13-3 12-55 23-15 8-20 26 1 9 22 19 12 11 51-11 5-18-35-3 21 8 53-16 4-18-50-3 50Z", "#829982") + G(150, 24, 14, 17, "#8da186"),
	colosseum: yn("arena"),
	romanRoads: K + U("M23 220L132 20h37l112 201-127 16Z", "#bdb99a") + W("M133 22l20 213m12-211-9 211m-57-98h114m-135 44h159m-181 45h211", "#8d977e", 2),
	stonehenge: K + [
		0,
		1,
		2,
		3,
		4
	].map((e) => q(`M${49 + e * 42} ${91 + e % 2 * 13}l18-5 8 103-23 5Z`) + q(`M${44 + e * 42} ${85 + e % 2 * 13}h36v16h-36Z`)).join(""),
	acropolis: K + U("M25 190l44-73 99-33 103 82-28 43-103 22Z", "#a6af94") + yn("temple", 39, 30, 230, 184),
	basilica: K + yn("lab", 25, 32, 250, 200) + W("M147 37V2m-10 12h20", "#b5ab79", 4),
	carolina: K + q("M45 85l105 27 106-28v112l-106 30-105-29Z") + q("M72 82V44l17-29 16 29v48m91-6V44l17-29 17 29v38") + Cn(57, 125, 5, 20, 53) + Cn(166, 124, 4, 21, 50),
	machuPicchu: K + U("M34 184L139 17l40 23 74 144-110 43Z", "#6f9274") + [
		0,
		1,
		2,
		3
	].map((e) => U(`M${63 + e * 16} ${173 - e * 21}l75-30 69 26-73 34Z`, "#b9c0a0")).join("") + wn(53, 178) + wn(239, 177),
	himeji: K + [
		0,
		1,
		2
	].map((e) => `<g transform="translate(${e * 32} ${e * -40}) scale(${1 - e * .2})">` + q("M70 115l78 18 81-22v74l-81 23-78-22Z") + U("M52 114l95-34 100 30-16 17-83 20-83-19Z", "#647a70") + "</g>").join(""),
	forbiddenCity: K + q("M31 135l117 23 118-24v58l-118 29-117-27Z") + U("M20 133l126-46 131 44-16 21-114 26-113-26Z", "#a38759") + U("M73 101l75 17 76-19-9-17-68-24-70 28Z", "#a99460") + Cn(45, 166, 11, 19, 29, "#8a6552"),
	silkRoad: K + U("M24 220L131 21l30 0 116 199-114 12Z", "#bfb38c") + wn(40, 167) + wn(248, 165) + yn("cavalry", 44, 35, 200, 160),
	oceanLiner: U("M5 176q145-63 290 2v44H5Z", "#71a6b7", "none") + U("M38 147l211-20-23 66-162 19Z", "#405d66") + q("M63 110l146-15 18 48-164 16Z") + U("M112 112V61h26v49m24-3V54h26v49", "#99694f") + Cn(79, 128, 9, 15, 10),
	kremlin: K + q("M37 120l110 29 111-28v76l-111 30-110-31Z") + U("M33 123V51l25-14 25 15v83m125 0V51l25-14 26 15v74M38 49l20-34 23 35m129 0 23-36 24 37", "#9a7061") + Cn(94, 166, 6, 19, 29),
	eiffel: K + U("M61 212L137 23h20l81 189-34 3-34-62h-49l-30 60Z", "#7c8b78") + W("M142 28l-19 123m30-123 19 125m-62 22h78M127 85h34m-52 57h72M96 190l83-47m-52-57 39 36m-39-18 40 36m-43 7 75 64", "#c8cbb3", 3),
	railroad: K + W("M18 231l112-70m30 2 121 68m-234-17h203m-194-14h160", "#60766b", 5) + U("M49 162l155-26 32 42-158 25Z", "#526f70") + U("M80 158V95h84v51m10-3V66h44v78", "#82998d") + Cn(89, 106, 3, 21, 29) + G(95, 188, 14, 14, "#3f585a") + G(147, 179, 14, 14, "#3f585a") + G(204, 171, 14, 14, "#3f585a"),
	harvard: K + yn("palace", 19, 12, 266, 213),
	suez: K + U("M49 226L137 26h32l97 194-109 14Z", "#6eabbc") + yn("wonder-oceanLiner", 50, 90, 190, 152),
	louvre: K + yn("palace", 0, 12, 155, 124) + yn("palace", 145, 12, 155, 124) + yn("pyramid", 91, 99, 126, 101),
	liberty: K + q("M117 172l37-12 36 13v41l-36 13-37-11Z") + U("M124 167l14-70-7-31-17-29 7-7 29 25 9 32 17 31 10 47-29 13Z", "#86a696") + G(150, 70, 12, 15, "#8aab98") + U("M137 59l-12-14 18 6 8-18 8 18 20-6-13 17m-55-29-4-23 15-7 6 23Z", "#b8bc8a"),
	hollywood: K + yn("theater", 0, 25, 210, 168) + G(224, 86, 39, 39, "#b1bba4") + [
		[-17, -13],
		[13, -16],
		[-12, 17],
		[18, 13]
	].map(([e, t]) => G(224 + e, 86 + t, 10, 10, "#607b71")).join("") + U("M183 140h78v49h-78Z", "#5d7975"),
	internet: K + G(150, 113, 81, 81, "#87b2b8") + W("M70 113h160m-151-35h142m-142 70h142M150 33q-78 80 0 161m0-161q78 80 0 161m0-161v161", "#dce4cf", 2) + [
		[-91, 39],
		[81, -45],
		[97, 38],
		[-57, -72],
		[4, 92]
	].map(([e, t]) => G(150 + e, 113 + t, 7, 7, "#4d796f")).join(""),
	spaceFlight: K + U("M127 164V75q7-43 24-64 18 21 24 64v89l24 34-32-13-16 40-16-40-31 13Z", "#c3ccbc") + G(151, 78, 15, 20, "#5c8d96") + U("M139 176l12 49 12-49Z", "#c0a16d"),
	fastFood: K + q("M44 111l104 25 109-26v83l-109 30-104-29Z") + U("M30 109l119-36 120 35-12 17-110 28-103-24Z", "#9c7a58") + U("M80 176v-31h50v44m36-1v-41h59v27", "#648d88") + G(149, 55, 38, 16, "#c4ad6c") + U("M113 57h75v12h-75Z", "#8b674c"),
	empireState: K + q("M80 199V106l24-5V64l26-7V28l22-7 21 7v29l26 7v38l24 6v91l-71 26Z") + W("M152 23V2m0 32v178m-56-91v79m23-127v129m65-127v129m24-81v79", "#758d83", 4),
	unitedNations: K + q("M70 46l86-28 68 23v155l-68 27-86-24Z") + W("M155 22v195m-72-158v126m18-131v137m18-144v151m17-157v163m41-163v163m17-157v150m17-141v134", "#7caaa6", 6) + W("M33 200V88m228 116V89", "#687c6e", 2) + U("M34 89l31 6-31 14m228-19-30 6 30 14", "#729b8b"),
	manhattan: K + yn("lab", 23, 17, 254, 203) + G(151, 55, 10, 10, "#a2b58c") + "<g fill=\"none\" stroke=\"#c2c89e\" stroke-width=\"2\"><ellipse cx=\"151\" cy=\"55\" rx=\"41\" ry=\"14\"/><ellipse cx=\"151\" cy=\"55\" rx=\"41\" ry=\"14\" transform=\"rotate(60 151 55)\"/><ellipse cx=\"151\" cy=\"55\" rx=\"41\" ry=\"14\" transform=\"rotate(120 151 55)\"/></g>",
	redCross: K + q("M52 87l99 25 98-26v111l-98 30-99-28Z") + Cn(67, 137, 8, 21, 48) + U("M133 52h35v20h22v32h-22v22h-35v-22h-23V72h23Z", "#a75f55")
}, En = new Set(Object.keys(vn)), Dn = new Set(Object.keys(Tn)), On = `<defs>${Object.entries(vn).map(([e, t]) => bn(`leader-${e}`, Sn(t))).join("")}${Object.entries(Tn).map(([e, t]) => bn(`wonder-${e}`, t)).join("")}</defs>`, kn = r("tta-");
function An({ children: e }) {
	let t = `tta${o().replace(/[^a-zA-Z0-9]/g, "")}-`, n = ln.replace(/<symbol id="tta-i-(?:civil|military|worker)"[\s\S]*?<\/symbol>/g, "") + Bn + On + _n + gn + un.replaceAll("v15-", "tta-card-");
	return /* @__PURE__ */ v(kn, {
		value: t,
		children: [/* @__PURE__ */ _("svg", {
			className: "tta-art-defs",
			"aria-hidden": "true",
			dangerouslySetInnerHTML: { __html: n.replaceAll("tta-", t) }
		}), e]
	});
}
function J({ name: e, className: t = "" }) {
	let n = i(kn);
	return /* @__PURE__ */ _("svg", {
		className: `tta-icon ${t}`,
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		children: /* @__PURE__ */ _("use", { href: `#${n}i-${{
			food: "food",
			ore: "ore",
			science: "science",
			culture: "culture",
			strength: "strength",
			happy: "happy",
			civil: "civil",
			military: "military",
			urban: "urban",
			colonize: "strength",
			armies: "strength",
			blue: "blue",
			population: "population",
			worker: "population",
			discontent: "discontent"
		}[e] ?? "culture"}` })
	});
}
function jn(e) {
	return e.id === "michelangelo" ? "portrait" : e.kind === "leader" ? En.has(e.id) ? `leader-${e.id}` : "bust" : e.kind === "wonder" ? Dn.has(e.id) ? `wonder-${e.id}` : {
		pyramids: "pyramid",
		greatWall: "wall",
		libraryAlexandria: "library",
		libraryOfAlexandria: "library",
		alexandria: "library",
		tajMahal: "taj",
		colossus: "monument"
	}[e.id] ?? "monument" : e.kind === "government" ? "palace" : e.category ? {
		farm: "farm",
		mine: "mine",
		lab: "lab",
		temple: "temple",
		library: "library",
		theater: "theater",
		arena: "arena",
		infantry: "barracks",
		cavalry: "stable",
		artillery: "cannon",
		airforce: "airplane",
		law: "scroll",
		warfare: "scroll",
		exploration: "scroll",
		construction: "scroll"
	}[e.category] ?? "scroll" : e.kind === "territory" ? "island" : [
		"tactic",
		"aggression",
		"war",
		"bonus"
	].includes(e.kind) ? "barracks" : "scroll";
}
function Mn(e) {
	return {
		law: "palace",
		warfare: "barracks",
		exploration: "island",
		construction: "library"
	}[e.category ?? ""] ?? jn(e);
}
function Nn({ definition: e, className: t = "", scene: n = !1 }) {
	let r = i(kn), a = n ? Mn(e) : jn(e);
	return /* @__PURE__ */ _("svg", {
		className: `tta-card-art ${t}`,
		viewBox: a === "portrait" ? "0 0 280 320" : "0 0 300 240",
		"aria-hidden": "true",
		children: /* @__PURE__ */ _("use", {
			href: `#${r}a-${a}`,
			width: a === "portrait" ? 280 : 300,
			height: a === "portrait" ? 320 : 240
		})
	});
}
function Pn({ definition: e, name: t }) {
	let n = i(kn);
	return /* @__PURE__ */ _("svg", {
		className: "tta-card-face",
		viewBox: "0 0 120 164",
		preserveAspectRatio: "xMidYMid meet",
		"aria-hidden": "true",
		dangerouslySetInnerHTML: { __html: pn(e, t, jn(e), n) }
	});
}
function Fn({ extension: e = !1 }) {
	let t = i(kn);
	return /* @__PURE__ */ _("svg", {
		className: "tta-city-ground",
		viewBox: "0 0 980 360",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		"data-extension": e,
		dangerouslySetInnerHTML: { __html: mn.replaceAll("tta-", t) }
	});
}
function In() {
	return /* @__PURE__ */ _("svg", {
		viewBox: "-4 -13 50 46",
		"aria-hidden": "true",
		dangerouslySetInnerHTML: { __html: hn }
	});
}
var Ln = {
	barracks: "M25 182V101L48 82V19L90 32L48 41V80L77 59L127 45L267 96V167L255 185L154 235Z",
	stable: "M23 99L85 56L132 43L244 80V21L271 34L244 42V86L279 94L270 162L158 236L23 212Z",
	farm: "M26 84L76 29L132 17L174 29V13L194 7L207 13V52L237 67L219 83V130L245 128Q275 142 268 181L298 199L302 216L252 226L222 211L142 208L88 219L8 203L16 183L31 177V126L44 123V91Z",
	mine: "M13 187L23 123L65 71L108 24L164 32L183 63L229 83L280 182L269 200L238 207L199 214L106 237L45 229L57 210Z",
	lab: "M29 157L43 150V112L82 102V79Q78 31 140 6V0H149V7Q209 28 214 70L208 77V109L253 98V137L269 138V170L134 218L29 187Z",
	temple: "M14 183L27 175V79L113 19L180 0L273 72V85L265 93V170L291 177V190L175 230L14 201Z",
	library: "M17 187L29 177V121L56 99V52L129 7L226 28L221 66L217 100L266 139V174L288 181V195L178 233L17 208Z",
	pyramid: "M4 198L141 10L287 181L293 204L246 224L204 214L159 234Z",
	wall: "M0 191L24 143V102L63 84L88 107L123 66V35L161 18L185 44V95L202 123L232 93V44L267 25L289 53V131L298 178L235 221L176 177L138 195L74 226Z",
	taj: "M10 208V114L37 97V65L56 49L72 65V110L102 96V57L122 41Q125 14 151 4Q177 14 180 41L202 57V97L228 110V65L246 49L264 65V98L290 113V211L151 237Z"
};
function Rn({ art: e, state: t }) {
	if (!t) return null;
	let n = Ln[e] ?? "M20 70L100 13L240 38L285 112V205L155 232L15 200Z";
	return /* @__PURE__ */ v("g", {
		className: `tta-outline tta-outline-${t}`,
		"aria-hidden": "true",
		children: [/* @__PURE__ */ _("path", {
			className: "tta-outline-back",
			d: n
		}), /* @__PURE__ */ _("path", {
			className: "tta-outline-line",
			d: n
		})]
	});
}
function zn({ state: e }) {
	return e ? /* @__PURE__ */ v("svg", {
		className: `tta-control-outline tta-outline tta-outline-${e}`,
		"aria-hidden": "true",
		children: [/* @__PURE__ */ _("rect", {
			className: "tta-outline-back",
			width: "100%",
			height: "100%",
			rx: "2"
		}), /* @__PURE__ */ _("rect", {
			className: "tta-outline-line",
			width: "100%",
			height: "100%",
			rx: "2"
		})]
	}) : null;
}
var Bn = "<defs>\n<symbol id=\"tta-a-bust\" viewBox=\"0 0 300 240\"><rect x=\"60\" y=\"6\" width=\"180\" height=\"222\" fill=\"#bdcecf\"/><path d=\"M78 219q2-50 48-62v-27q-24-21-17-66 2-40 44-42 42 2 43 42 6 43-18 66v27q46 12 48 62Z\" fill=\"#c6bea5\" stroke=\"#66766d\" stroke-width=\"2\"/><path d=\"M111 75q-5-56 45-54 46 5 39 53l-18-22-22 7-23-10Z\" fill=\"#465c5e\"/><path d=\"M124 87l15-3m24 0 15 3m-27 1-7 26 12 4m-22 12q17 9 34-1M125 163l27 31 26-31m-26 31v25m-52-41 27 41m72-43-25 43\" fill=\"none\" stroke=\"#7c8778\" stroke-width=\"2\"/><path d=\"M93 220h115v13H93Z\" fill=\"#7e938c\"/></symbol>\n<symbol id=\"tta-a-monument\" viewBox=\"0 0 300 240\"><path d=\"M23 196l126-36 128 37-126 35Z\" fill=\"#9ca793\"/><path d=\"M67 177l84-25 83 25v19l-83 25-84-25Z\" fill=\"#dbd7be\" stroke=\"#7f8975\"/><path d=\"M98 172V83l51-20 51 20v89l-51 18Z\" fill=\"#d5d4bf\" stroke=\"#7b897b\"/><path d=\"M149 63v126l51-17V83Z\" fill=\"#a7b3a2\"/><path d=\"M132 72V20l19-12 21 12v51\" fill=\"#c2c6b2\" stroke=\"#7e8977\"/><path d=\"M112 96l25-9v67l-25 8m49-73 22 7v64l-22-7M88 191l64 19 63-19\" fill=\"none\" stroke=\"#eef0dc\" stroke-width=\"3\"/></symbol>\n<symbol id=\"tta-a-theater\" viewBox=\"0 0 300 240\"><use href=\"#tta-a-temple\" width=\"300\" height=\"240\"/><path d=\"M72 105l78 17 67-23v77l-67 24-78-19Z\" fill=\"#774d48\"/><path d=\"M76 109q14 52 38 78m98-84q-5 43-38 83M148 126v68\" fill=\"none\" stroke=\"#ba9181\" stroke-width=\"5\"/></symbol>\n<symbol id=\"tta-a-arena\" viewBox=\"0 0 300 240\"><ellipse cx=\"150\" cy=\"160\" rx=\"130\" ry=\"61\" fill=\"#9ca58d\"/><path d=\"M25 124a125 60 0 0 1 250 0v45a125 60 0 0 1-250 0Z\" fill=\"#d0cfb7\" stroke=\"#7c8574\" stroke-width=\"2\"/><ellipse cx=\"150\" cy=\"124\" rx=\"122\" ry=\"54\" fill=\"#a7ad96\"/><ellipse cx=\"150\" cy=\"125\" rx=\"87\" ry=\"34\" fill=\"#bcc293\"/><path d=\"M40 148v31m25-20v33m27-26v36m29-32v38m29-35v39m29-41v38m29-44v36m27-44v32m24-44v29\" stroke=\"#697365\" stroke-width=\"10\"/></symbol>\n<symbol id=\"tta-a-cannon\" viewBox=\"0 0 300 240\"><path d=\"M24 208l135-40 117 41-123 24Z\" fill=\"#9ca58e\"/><path d=\"M107 139l-27 60m70-67 43 73\" stroke=\"#685b42\" stroke-width=\"14\"/><path d=\"M72 115l134-48 14 34-136 47Z\" fill=\"#62766b\" stroke=\"#3e514b\" stroke-width=\"3\"/><ellipse cx=\"216\" cy=\"83\" rx=\"12\" ry=\"20\" fill=\"#34453f\"/><circle cx=\"115\" cy=\"176\" r=\"37\" fill=\"#82714d\" stroke=\"#4a4c37\" stroke-width=\"5\"/><circle cx=\"115\" cy=\"176\" r=\"25\" fill=\"#bec0a3\"/><path d=\"M115 148v56m-28-28h56m-48-20 40 40m0-40-40 40\" stroke=\"#756647\" stroke-width=\"4\"/></symbol>\n<symbol id=\"tta-a-cavalry\" viewBox=\"0 0 300 240\"><path d=\"M44 205l105-28 104 30-105 24Z\" fill=\"#9ca58e\"/><path d=\"M76 115q29-23 86-8l18-45 18-13 31 31-3 18-27-6-7 49-26 14-4 52h-14l-9-54-37-5-14 58H74l11-76-19-4-16 38-10-5 14-50Z\" fill=\"#84765b\" stroke=\"#4e5847\" stroke-width=\"3\"/><path d=\"M113 103V70l23-13 22 20-5 40Z\" fill=\"#687e76\" stroke=\"#465b54\" stroke-width=\"2\"/><circle cx=\"136\" cy=\"47\" r=\"13\" fill=\"#c4b48f\"/><path d=\"M122 41q14-20 28 0m-7 42 40-5m-6 19V15\" stroke=\"#52675e\" stroke-width=\"7\"/><path d=\"M131 116l15 31-8 30\" fill=\"none\" stroke=\"#4d5e52\" stroke-width=\"11\"/></symbol>\n<symbol id=\"tta-a-airplane\" viewBox=\"0 0 300 240\"><path d=\"M23 200l140-40 115 43-121 29Z\" fill=\"#9aa98f\"/><path d=\"M141 37l17-7 15 86 99 54-10 15-92-25-2 33 27 19-4 11-39-11-39 10-5-11 29-21-2-33-91 26-8-14 103-54Z\" fill=\"#a8bab7\" stroke=\"#526b6b\" stroke-width=\"3\"/><path d=\"M150 50v151m-83-34 78-28m20 0 78 29\" stroke=\"#e1e5d2\" stroke-width=\"2\"/></symbol>\n<symbol id=\"tta-a-island\" viewBox=\"0 0 300 240\"><path d=\"M17 170q64-57 132-35 84-26 136 33l-23 33-116 28-112-29Z\" fill=\"#74abb5\"/><path d=\"M39 161l59-45 35-61 41 28 33 54 52 22-110 43Z\" fill=\"#7c9d63\" stroke=\"#587d58\" stroke-width=\"2\"/><path d=\"M98 116l35-61 41 28-23 55Z\" fill=\"#9daf7b\"/><path d=\"M77 173q77 32 156-5\" fill=\"none\" stroke=\"#d9d2ac\" stroke-width=\"6\"/></symbol>\n</defs>", Vn = {
	take: "games.throughtheages.moves.take",
	end: "games.throughtheages.moves.end",
	population: "games.throughtheages.moves.population",
	research: "games.throughtheages.moves.research",
	revolution: "games.throughtheages.moves.revolution",
	leader: "games.throughtheages.moves.leader",
	build: "games.throughtheages.moves.build",
	upgrade: "games.throughtheages.moves.upgrade",
	destroy: "games.throughtheages.moves.destroy",
	wonder: "games.throughtheages.moves.wonder",
	action: "games.throughtheages.moves.action",
	hammurabi: "games.throughtheages.moves.hammurabi",
	barbarossa: "games.throughtheages.moves.barbarossa",
	liner: "games.throughtheages.moves.liner",
	louvre: "games.throughtheages.moves.louvre",
	churchill: "games.throughtheages.moves.churchill",
	tactic: "games.throughtheages.moves.tactic",
	copyTactic: "games.throughtheages.moves.copyTactic",
	endPolitics: "games.throughtheages.moves.endPolitics",
	olympics: "games.throughtheages.moves.olympics",
	fleming: "games.throughtheages.moves.fleming",
	prepare: "games.throughtheages.moves.prepare",
	columbus: "games.throughtheages.moves.columbus",
	offer: "games.throughtheages.moves.offer",
	declareWar: "games.throughtheages.moves.declareWar",
	aggression: "games.throughtheages.moves.aggression",
	cancelPact: "games.throughtheages.moves.cancelPact",
	alexander: "games.throughtheages.moves.alexander",
	catherine: "games.throughtheages.moves.catherine",
	auctionPass: "games.throughtheages.moves.auctionPass",
	auctionUnit: "games.throughtheages.moves.auctionUnit",
	auctionCard: "games.throughtheages.moves.auctionCard",
	auctionPay: "games.throughtheages.moves.auctionPay",
	auctionBid: "games.throughtheages.moves.auctionBid",
	decline: "games.throughtheages.moves.decline",
	accept: "games.throughtheages.moves.accept",
	skip: "games.throughtheages.moves.skip",
	sacrifice: "games.throughtheages.moves.sacrifice",
	yield: "games.throughtheages.moves.yield",
	defend: "games.throughtheages.moves.defend",
	defenseCard: "games.throughtheages.moves.defenseCard",
	plunder: "games.throughtheages.moves.plunder",
	raid: "games.throughtheages.moves.raid",
	infiltrateLeader: "games.throughtheages.moves.infiltrateLeader",
	infiltrateWonder: "games.throughtheages.moves.infiltrateWonder",
	annex: "games.throughtheages.moves.annex",
	kidnap: "games.throughtheages.moves.kidnap",
	warScience: "games.throughtheages.moves.warScience",
	warSteal: "games.throughtheages.moves.warSteal",
	produce: "games.throughtheages.moves.produce",
	removeBlue: "games.throughtheages.moves.removeBlue",
	losePopulation: "games.throughtheages.moves.losePopulation",
	discardCards: "games.throughtheages.moves.discardCards",
	discard: "games.throughtheages.moves.discard",
	gainMixed: "games.throughtheages.moves.gainMixed",
	loseMixed: "games.throughtheages.moves.loseMixed",
	gain: "games.throughtheages.moves.gain",
	saladin: "games.throughtheages.moves.saladin",
	recoverCivil: "games.throughtheages.moves.recoverCivil",
	homer: "games.throughtheages.moves.homer",
	jobs: "games.throughtheages.moves.jobs",
	freeBuild: "games.throughtheages.moves.freeBuild",
	planning: "games.throughtheages.moves.planning",
	demolish: "games.throughtheages.moves.demolish",
	ravages: "games.throughtheages.moves.ravages",
	loseColony: "games.throughtheages.moves.loseColony",
	freeColony: "games.throughtheages.moves.freeColony",
	unitedNations: "games.throughtheages.moves.unitedNations",
	agreementAccept: "games.throughtheages.moves.agreementAccept",
	agreementTake: "games.throughtheages.moves.agreementTake",
	agreementEnd: "games.throughtheages.moves.agreementEnd",
	negotiate: "games.throughtheages.moves.negotiate"
}, Hn = {
	action: "games.throughtheages.prompts.action",
	politics: "games.throughtheages.prompts.politics",
	resolve: "games.throughtheages.prompts.resolve",
	discard: "games.throughtheages.prompts.discard",
	done: "games.throughtheages.prompts.done",
	pact: "games.throughtheages.prompts.pact",
	attackHimeji: "games.throughtheages.prompts.attackHimeji",
	defendHimeji: "games.throughtheages.prompts.defendHimeji",
	defend: "games.throughtheages.prompts.defend",
	plunder: "games.throughtheages.prompts.plunder",
	raid: "games.throughtheages.prompts.raid",
	infiltrate: "games.throughtheages.prompts.infiltrate",
	annex: "games.throughtheages.prompts.annex",
	kidnap: "games.throughtheages.prompts.kidnap",
	warTechnology: "games.throughtheages.prompts.warTechnology",
	produce: "games.throughtheages.prompts.produce",
	removeBlue: "games.throughtheages.prompts.removeBlue",
	losePopulation: "games.throughtheages.prompts.losePopulation",
	discardCards: "games.throughtheages.prompts.discardCards",
	gainMixed: "games.throughtheages.prompts.gainMixed",
	loseMixed: "games.throughtheages.prompts.loseMixed",
	boudica: "games.throughtheages.prompts.boudica",
	autonomous: "games.throughtheages.prompts.autonomous",
	devMarkets: "games.throughtheages.prompts.devMarkets",
	saladin: "games.throughtheages.prompts.saladin",
	homer: "games.throughtheages.prompts.homer",
	jobs: "games.throughtheages.prompts.jobs",
	devWarfare: "games.throughtheages.prompts.devWarfare",
	devReligion: "games.throughtheages.prompts.devReligion",
	devCivilization: "games.throughtheages.prompts.devCivilization",
	freedomMovement: "games.throughtheages.prompts.freedomMovement",
	planning: "games.throughtheages.prompts.planning",
	demolish: "games.throughtheages.prompts.demolish",
	terrorism: "games.throughtheages.prompts.terrorism",
	ravages: "games.throughtheages.prompts.ravages",
	loseColony: "games.throughtheages.prompts.loseColony",
	freeColony: "games.throughtheages.prompts.freeColony",
	unitedNations: "games.throughtheages.prompts.unitedNations",
	agreementOffer: "games.throughtheages.prompts.agreementOffer",
	agreement: "games.throughtheages.prompts.agreement",
	negotiations: "games.throughtheages.prompts.negotiations",
	auction: "games.throughtheages.prompts.auction"
}, Un = {
	action: "games.throughtheages.log.action",
	take: "games.throughtheages.log.take",
	research: "games.throughtheages.log.research",
	revolution: "games.throughtheages.log.revolution",
	leader: "games.throughtheages.log.leader",
	population: "games.throughtheages.log.population",
	build: "games.throughtheages.log.build",
	upgrade: "games.throughtheages.log.upgrade",
	destroy: "games.throughtheages.log.destroy",
	wonder: "games.throughtheages.log.wonder",
	complete: "games.throughtheages.log.complete",
	prepare: "games.throughtheages.log.prepare",
	aggression: "games.throughtheages.log.aggression",
	declareWar: "games.throughtheages.log.declareWar",
	bid: "games.throughtheages.log.bid",
	colonize: "games.throughtheages.log.colonize",
	event: "games.throughtheages.log.event",
	defend: "games.throughtheages.log.defend",
	yield: "games.throughtheages.log.yield",
	warResult: "games.throughtheages.log.warResult",
	score: "games.throughtheages.log.score",
	age: "games.throughtheages.log.age",
	uprising: "games.throughtheages.log.uprising",
	corruption: "games.throughtheages.log.corruption",
	starvation: "games.throughtheages.log.starvation"
}, Y = {
	science: "games.throughtheages.science",
	culture: "games.throughtheages.culture",
	strength: "games.throughtheages.strength",
	happy: "games.throughtheages.happy",
	civil: "games.throughtheages.civil",
	military: "games.throughtheages.military",
	urban: "games.throughtheages.urban",
	colonize: "games.throughtheages.colonize",
	food: "games.throughtheages.food",
	ore: "games.throughtheages.ore",
	armies: "games.throughtheages.armies",
	technology: "games.throughtheages.technology",
	government: "games.throughtheages.government",
	leader: "games.throughtheages.leader",
	wonder: "games.throughtheages.wonder",
	action: "games.throughtheages.action",
	event: "games.throughtheages.event",
	territory: "games.throughtheages.territory",
	tactic: "games.throughtheages.tactic",
	bonus: "games.throughtheages.bonus",
	aggression: "games.throughtheages.aggression",
	war: "games.throughtheages.war",
	pact: "games.throughtheages.pact",
	farm: "games.throughtheages.farm",
	mine: "games.throughtheages.mine",
	lab: "games.throughtheages.lab",
	temple: "games.throughtheages.temple",
	library: "games.throughtheages.library",
	theater: "games.throughtheages.theater",
	arena: "games.throughtheages.arena",
	infantry: "games.throughtheages.infantry",
	cavalry: "games.throughtheages.cavalry",
	artillery: "games.throughtheages.artillery",
	airforce: "games.throughtheages.airforce",
	law: "games.throughtheages.law",
	warfare: "games.throughtheages.warfare",
	exploration: "games.throughtheages.exploration",
	construction: "games.throughtheages.construction"
}, Wn = (e) => [
	"A",
	"I",
	"II",
	"III",
	"IV"
][e] ?? String(e);
function X(e, t, n) {
	return e(x(t, n).nameKey);
}
function Gn(e, t, n, r) {
	let i = t.extra ?? "";
	[
		"auctionUnit",
		"auctionCard",
		"defenseCard"
	].includes(t.type) && (i = e(t.n === -1 ? "games.throughtheages.remove" : "games.throughtheages.add")), t.type === "offer" && (i = e(t.extra === "a" ? "games.throughtheages.sideA" : "games.throughtheages.sideB")), t.type === "churchill" && (i = e(t.extra === "culture" ? "games.throughtheages.extraCulture" : "games.throughtheages.extraMilitary")), t.type === "saladin" && (i = e(t.extra === "civil" ? "games.throughtheages.extraCivil" : "games.throughtheages.extraStrength"));
	let a = t.resource ? e(Y[t.resource]) : "";
	return e(Vn[t.type] ?? "games.throughtheages.invalidAction", {
		card: t.card ? X(e, t.card, n) : e("games.throughtheages.pool"),
		source: t.source && ["upgrade"].includes(t.type) ? X(e, t.source, n) : "",
		name: t.target ? r(t.target) : "",
		n: t.n ?? 0,
		cost: t.cost ?? 0,
		extra: i,
		resource: t.type === "action" && a ? ` · ${a}` : a
	});
}
//#endregion
//#region src/games/throughtheages/reserve-panel.tsx
var Kn = (e, t) => e ? t > 10 ? 0 : t > 5 ? 2 : t > 0 ? 4 : 6 : t > 16 ? 0 : t > 12 ? 1 : t > 8 ? 2 : t > 4 ? 3 : t > 0 ? 4 : 6, qn = [
	0,
	2,
	4,
	6,
	8,
	10,
	12,
	16
];
function Jn({ blue: e, count: t, total: n }) {
	let r = f(), i = e ? [
		5,
		5,
		6
	] : [
		4,
		4,
		4,
		4,
		2
	], a = i.reduce((e, t) => e + t, 0);
	n > a && i.push(n - a);
	let o = 0;
	return /* @__PURE__ */ v("div", {
		className: `tta-reserve-rail ${e ? "tta-reserve-blue" : "tta-reserve-yellow"}`,
		"aria-label": r(e ? "games.throughtheages.storageRisk" : "games.throughtheages.populationRisk", {
			n: t,
			loss: Kn(e, t),
			happy: qn.filter((e) => t <= e).length
		}),
		children: [/* @__PURE__ */ _("b", { children: t }), /* @__PURE__ */ v("div", {
			className: "tta-reserve-segments",
			children: [i.map((n, r) => {
				let i = o, a = Math.min(n, Math.max(0, t - o));
				return o += n, /* @__PURE__ */ _("span", {
					className: "tta-reserve-segment",
					style: { flex: n },
					"data-active": a === 0 && Kn(e, i) === Kn(e, t),
					children: a ? /* @__PURE__ */ _("span", {
						className: "tta-reserve-pieces",
						children: Array.from({ length: a }, (t, n) => /* @__PURE__ */ _(J, { name: e ? "blue" : "population" }, n))
					}) : /* @__PURE__ */ v("span", {
						className: "tta-reserve-loss",
						children: [
							"−",
							Kn(e, i),
							/* @__PURE__ */ _(J, { name: e ? "ore" : "food" })
						]
					})
				}, r);
			}), !e && /* @__PURE__ */ _("div", {
				className: "tta-happiness-thresholds",
				children: qn.map((e) => /* @__PURE__ */ _("span", {
					style: { left: `${Math.min(96, e / Math.max(n, a) * 100)}%` },
					"data-active": t <= e,
					title: r("games.throughtheages.happinessThreshold", { n: e }),
					children: /* @__PURE__ */ _(J, { name: "happy" })
				}, e))
			})]
		})]
	});
}
function Yn({ player: e }) {
	let t = f(), n = o(), [r, i] = l(!1), a = c(null), s = () => {
		i(!1), a.current?.focus();
	};
	return /* @__PURE__ */ v("div", {
		className: "tta-reserve",
		onKeyDown: (e) => {
			e.key === "Escape" && (e.stopPropagation(), s());
		},
		children: [/* @__PURE__ */ v("button", {
			type: "button",
			className: "tta-reserve-trigger",
			ref: a,
			"aria-label": t("games.throughtheages.reserveSummary", {
				blue: e.blueBank,
				yellow: e.yellow,
				pool: e.pool,
				discontent: e.discontent
			}),
			"aria-expanded": r,
			"aria-controls": n,
			onClick: () => i(!r),
			children: [[
				"blue",
				"population",
				"worker",
				"discontent"
			].map((n, r) => /* @__PURE__ */ v("span", {
				title: t(r === 0 ? "games.throughtheages.blueBank" : r === 1 ? "games.throughtheages.yellowBank" : r === 2 ? "games.throughtheages.pool" : "games.throughtheages.discontent"),
				children: [/* @__PURE__ */ _(J, { name: n }), /* @__PURE__ */ _("b", { children: [
					e.blueBank,
					e.yellow,
					e.pool,
					e.discontent
				][r] })]
			}, n)), /* @__PURE__ */ _("span", {
				"aria-hidden": "true",
				className: "tta-reserve-chevron",
				children: r ? "⌃" : "⌄"
			})]
		}), r && /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ _("button", {
			type: "button",
			className: "tta-reserve-backdrop",
			"aria-label": t("games.throughtheages.close"),
			onClick: s
		}), /* @__PURE__ */ v("section", {
			id: n,
			className: "tta-reserve-popover",
			role: "dialog",
			"aria-label": t("games.throughtheages.reserves"),
			children: [
				/* @__PURE__ */ _("button", {
					type: "button",
					className: "tta-close",
					"aria-label": t("games.throughtheages.close"),
					onClick: s,
					autoFocus: !0,
					children: /* @__PURE__ */ _(h, { size: 16 })
				}),
				/* @__PURE__ */ _(Jn, {
					blue: !0,
					count: e.blueBank,
					total: e.blueTotal
				}),
				/* @__PURE__ */ _(Jn, {
					blue: !1,
					count: e.yellow,
					total: 18 + Math.max(0, e.yellowTotal - 25)
				}),
				/* @__PURE__ */ v("div", {
					className: "tta-reserve-foot",
					children: [/* @__PURE__ */ v("span", {
						title: t("games.throughtheages.happinessDemand"),
						children: [
							/* @__PURE__ */ _(J, { name: "happy" }),
							qn.filter((t) => e.yellow <= t).length,
							" / ",
							e.ratings.happy
						]
					}), ["pool", "discontent"].map((n) => /* @__PURE__ */ v("span", {
						title: t(Y[n] ?? (n === "pool" ? "games.throughtheages.pool" : "games.throughtheages.discontent")),
						children: [/* @__PURE__ */ _(J, { name: n === "pool" ? "worker" : "discontent" }), e[n]]
					}, n))]
				})
			]
		})] })]
	});
}
//#endregion
//#region src/games/throughtheages/worker-figure.tsx
var Xn = {
	citizen: "#bda365",
	farmer: "#b5ab80",
	miner: "#71817a",
	scholar: "#65808b",
	priest: "#d4d1b9",
	soldier: "#966754"
};
function Zn({ role: e = "citizen", outlined: t = !1 }) {
	let n = o(), r = e === "scholar" || e === "priest";
	return /* @__PURE__ */ v("svg", {
		className: "tta-worker-figure",
		"data-role": e,
		viewBox: "0 0 40 76",
		"aria-hidden": "true",
		children: [
			t && /* @__PURE__ */ _("defs", { children: /* @__PURE__ */ v("filter", {
				id: n,
				filterUnits: "userSpaceOnUse",
				x: "-8",
				y: "-8",
				width: "60",
				height: "100",
				colorInterpolationFilters: "sRGB",
				children: [
					/* @__PURE__ */ _("feMorphology", {
						in: "SourceAlpha",
						operator: "dilate",
						radius: "4.2",
						result: "outer"
					}),
					/* @__PURE__ */ _("feFlood", {
						floodColor: "#faf4da",
						result: "paper"
					}),
					/* @__PURE__ */ _("feComposite", {
						in: "paper",
						in2: "outer",
						operator: "in",
						result: "pale"
					}),
					/* @__PURE__ */ _("feMorphology", {
						in: "SourceAlpha",
						operator: "dilate",
						radius: "2.4",
						result: "inner"
					}),
					/* @__PURE__ */ _("feFlood", {
						floodColor: "#253b34",
						result: "ink"
					}),
					/* @__PURE__ */ _("feComposite", {
						in: "ink",
						in2: "inner",
						operator: "in",
						result: "dark"
					}),
					/* @__PURE__ */ v("feMerge", { children: [
						/* @__PURE__ */ _("feMergeNode", { in: "pale" }),
						/* @__PURE__ */ _("feMergeNode", { in: "dark" }),
						/* @__PURE__ */ _("feMergeNode", { in: "SourceGraphic" })
					] })
				]
			}) }),
			/* @__PURE__ */ _("ellipse", {
				cx: "20",
				cy: "72",
				rx: "12",
				ry: "2.3",
				fill: "#344737",
				opacity: ".2"
			}),
			/* @__PURE__ */ v("g", {
				filter: t ? `url(#${n})` : void 0,
				stroke: "#454e43",
				strokeWidth: ".9",
				strokeLinejoin: "round",
				strokeLinecap: "round",
				children: [
					/* @__PURE__ */ _("path", {
						d: "M13 45l-1 25h5l4-24 1 24h5l-1-26Z",
						fill: "#626957"
					}),
					/* @__PURE__ */ _("path", {
						d: "M12 69l-2 3h8v-3m4 0v3h8l-3-3",
						fill: "#524d3d"
					}),
					/* @__PURE__ */ _("path", {
						d: r ? "M14 23l-5 9 3 12-4 23q12 5 24 0l-5-24 3-12-5-8Z" : "M14 23l-6 9 4 13-1 7q10 3 18-1l-2-8 4-12-6-8Z",
						fill: Xn[e]
					}),
					/* @__PURE__ */ _("path", {
						d: "M17 19v5l4 3 3-3v-6",
						fill: "#b99874"
					}),
					/* @__PURE__ */ _("path", {
						d: "M15 11q0-6 6-6t6 6l-1 8-4 4-5-3Z",
						fill: "#c8ae8b"
					}),
					/* @__PURE__ */ _("path", {
						d: "M15 13V9q1-7 8-5l4 4v6l-3-5-5 1-3 5Z",
						fill: "#514b3e"
					}),
					/* @__PURE__ */ _("path", {
						d: "M23 14l1 3-2 1m-4-4h1m5 0h1",
						fill: "none",
						stroke: "#675b47",
						strokeWidth: ".7"
					}),
					/* @__PURE__ */ _("path", {
						d: "M14 29l-2 12 5 3m10-15 2 10-4 4",
						fill: "none",
						stroke: Xn[e],
						strokeWidth: "5"
					}),
					/* @__PURE__ */ _("path", {
						d: "M15 41l3 2-1 3-4-2m13-4-3 2 1 3 4-3",
						fill: "#c8ae8b"
					}),
					/* @__PURE__ */ _("path", {
						d: "M12 45h15v3H12Z",
						fill: "#695b43"
					}),
					/* @__PURE__ */ _("path", {
						d: "M20 29l-2 14m6 7 1 13",
						fill: "none",
						stroke: "#ecdfb9",
						strokeWidth: ".7",
						opacity: ".6"
					}),
					e === "farmer" && /* @__PURE__ */ v(g, { children: [
						/* @__PURE__ */ _("path", {
							d: "M9 10l5-2 2-7h9l3 7 5 2-1 3H10Z",
							fill: "#bfa46a"
						}),
						/* @__PURE__ */ _("path", {
							d: "M15 7h13",
							stroke: "#7d6c47"
						}),
						/* @__PURE__ */ _("path", {
							d: "M30 32l-2 37",
							stroke: "#776549",
							strokeWidth: "2"
						}),
						/* @__PURE__ */ _("path", {
							d: "M26 67l9 1-1 4-8-1Z",
							fill: "#788980"
						})
					] }),
					e === "miner" && /* @__PURE__ */ v(g, { children: [
						/* @__PURE__ */ _("path", {
							d: "M14 9q1-10 10-7l4 7Z",
							fill: "#8c8f7d"
						}),
						/* @__PURE__ */ _("path", {
							d: "M32 21l-7 45",
							stroke: "#7c6849",
							strokeWidth: "2.2"
						}),
						/* @__PURE__ */ _("path", {
							d: "M23 24q10-8 15 1l-8-2Z",
							fill: "#8b9d97"
						})
					] }),
					e === "scholar" && /* @__PURE__ */ v(g, { children: [
						/* @__PURE__ */ _("path", {
							d: "M16 8V4l9-1 3 5Z",
							fill: "#526b75"
						}),
						/* @__PURE__ */ _("path", {
							d: "M12 34l12 1-2 15-12-1Z",
							fill: "#e1d7b8"
						}),
						/* @__PURE__ */ _("path", {
							d: "M12 35v13m3-10 6 1m-6 3 5 1",
							fill: "none",
							stroke: "#958c6c"
						})
					] }),
					e === "priest" && /* @__PURE__ */ v(g, { children: [
						/* @__PURE__ */ _("path", {
							d: "M15 10l1-7 8-2 5 9-7-3Z",
							fill: "#d9d5bb"
						}),
						/* @__PURE__ */ _("path", {
							d: "M14 24l4 5-3 36 5 2 4-41-3 1Z",
							fill: "#6c8076"
						}),
						/* @__PURE__ */ _("path", {
							d: "M24 35l7 2-2 9-6-2Z",
							fill: "#8a6d4d"
						}),
						/* @__PURE__ */ _("path", {
							d: "M26 38l3 1",
							stroke: "#d2c497"
						})
					] }),
					e === "soldier" && /* @__PURE__ */ v(g, { children: [
						/* @__PURE__ */ _("path", {
							d: "M14 13V8q2-9 10-7l5 8v6l-4-2-1-6-6 1-1 6Z",
							fill: "#91a19c"
						}),
						/* @__PURE__ */ _("path", {
							d: "M14 25l6 3 6-3 2 16-8 3-8-3Z",
							fill: "#869995"
						}),
						/* @__PURE__ */ _("path", {
							d: "M16 30h8m-9 5h10m-10 4h10",
							stroke: "#b4c0ac"
						}),
						/* @__PURE__ */ _("path", {
							d: "M32 13v59",
							stroke: "#7f6e4a",
							strokeWidth: "1.7"
						}),
						/* @__PURE__ */ _("path", {
							d: "M30 14l2-11 3 11Z",
							fill: "#a5b6af"
						}),
						/* @__PURE__ */ _("path", {
							d: "M5 36l8-3 5 5-2 18-6 5-6-8Z",
							fill: "#8b6c50"
						}),
						/* @__PURE__ */ _("path", {
							d: "M10 36l2 21m-6-13 9-2",
							stroke: "#b1aa83"
						})
					] })
				]
			})
		]
	});
}
//#endregion
//#region src/games/throughtheages/view-components.tsx
function Qn({ target: e, config: t, badge: n, onClick: r, state: i, compact: a = !1 }) {
	let o = f(), s = x(e.id, t);
	return /* @__PURE__ */ v("button", {
		type: "button",
		className: `tta-card${a ? " tta-card-compact" : ""}`,
		"data-state": i,
		"data-target": e.key,
		"aria-pressed": i === "selected",
		"aria-label": `${X(o, s.id, t)} · ${Wn(s.age)} · ${o(Y[s.category ?? s.kind])}${i === "available" || i === "candidate" ? ` · ${o("games.throughtheages.availableTarget")}` : ""}`,
		onClick: r,
		children: [
			/* @__PURE__ */ _(Pn, {
				definition: s,
				name: X(o, s.id, t)
			}),
			n && /* @__PURE__ */ _("span", {
				className: "tta-card-badge",
				children: n
			}),
			i === "selected" && /* @__PURE__ */ _("span", {
				className: "tta-selected-check",
				children: /* @__PURE__ */ _(re, { size: 14 })
			}),
			i && /* @__PURE__ */ v("svg", {
				className: `tta-card-outline tta-outline tta-outline-${i}`,
				preserveAspectRatio: "none",
				viewBox: "0 0 100 100",
				"aria-hidden": "true",
				children: [/* @__PURE__ */ _("rect", {
					className: "tta-outline-back",
					x: "1.8",
					y: "1.5",
					width: "96.4",
					height: "97",
					rx: "1"
				}), /* @__PURE__ */ _("rect", {
					className: "tta-outline-line",
					x: "1.8",
					y: "1.5",
					width: "96.4",
					height: "97",
					rx: "1"
				})]
			})
		]
	});
}
function $n({ count: e, kind: t, limit: n = 12 }) {
	return /* @__PURE__ */ v("span", {
		className: `tta-tokens tta-tokens-${t}`,
		"aria-hidden": "true",
		children: [Array.from({ length: Math.min(n, Math.max(0, e)) }, (e, n) => /* @__PURE__ */ _(J, { name: t === "blue" ? "blue" : "population" }, n)), e > n && /* @__PURE__ */ v("b", { children: ["+", e - n] })]
	});
}
function er({ count: e, role: t = "citizen", limit: n = 5, outlined: r = !1 }) {
	return e <= 0 ? null : /* @__PURE__ */ v("span", {
		className: "tta-people",
		"aria-hidden": "true",
		children: [Array.from({ length: Math.min(n, Math.max(0, e)) }, (e, n) => /* @__PURE__ */ _(Zn, {
			role: t,
			outlined: r
		}, n)), e > n && /* @__PURE__ */ v("b", { children: ["+", e - n] })]
	});
}
function tr({ workers: e, blue: t }) {
	let n = f();
	return /* @__PURE__ */ v(g, { children: [/* @__PURE__ */ v("span", {
		title: n("games.throughtheages.workers", { n: e }),
		children: [/* @__PURE__ */ _($n, {
			count: e,
			kind: "worker",
			limit: 5
		}), /* @__PURE__ */ _("b", { children: e })]
	}), /* @__PURE__ */ v("span", {
		title: n("games.throughtheages.tokens", { n: t }),
		children: [/* @__PURE__ */ _($n, {
			count: t,
			kind: "blue",
			limit: 5
		}), /* @__PURE__ */ _("b", { children: t })]
	})] });
}
function nr({ move: e }) {
	let t = f(), n = [
		["civil", e.civil],
		["military", e.military],
		["food", e.payment.food],
		["ore", e.payment.ore],
		["science", e.payment.science]
	];
	return /* @__PURE__ */ v("span", {
		className: "tta-cost",
		children: [n.filter(([, e]) => e && e > 0).map(([e, n]) => /* @__PURE__ */ v("span", {
			title: t(Y[e]),
			children: [/* @__PURE__ */ _(J, { name: e }), n]
		}, e)), e.alternate ? /* @__PURE__ */ _("span", { children: t("games.throughtheages.tradePayment", {
			n: e.alternate,
			resource: t(Y[e.trade])
		}) }) : null]
	});
}
function rr({ id: e, config: t }) {
	let n = f(), r = x(e, t), i = { ...r.ratings };
	r.category === "farm" && (i.food = r.value), r.category === "mine" && (i.ore = r.value);
	let a = Object.entries(i).filter(([e, t]) => [
		"food",
		"ore",
		"science",
		"culture"
	].includes(e) && t).map(([e, t]) => `${t} ${n(Y[e])}`).join(" · "), o = Object.entries(i).filter(([e, t]) => ["strength", "happy"].includes(e) && t).map(([e, t]) => `${t} ${n(Y[e])}`).join(" · "), s = n(r.textKey);
	return /* @__PURE__ */ v("div", {
		className: "tta-card-detail",
		children: [
			/* @__PURE__ */ _("div", {
				className: "tta-detail-illustration",
				children: /* @__PURE__ */ _(Nn, { definition: r })
			}),
			/* @__PURE__ */ v("p", {
				className: "tta-detail-category",
				children: [
					Wn(r.age),
					" · ",
					n(Y[r.category ?? r.kind])
				]
			}),
			/* @__PURE__ */ v("div", {
				className: "tta-effect-description",
				children: [r.kind === "technology" && we.includes(r.category) && /* @__PURE__ */ v(g, { children: [a && /* @__PURE__ */ _("p", { children: n("games.throughtheages.workerProduction", { effects: a }) }), o && /* @__PURE__ */ _("p", { children: n("games.throughtheages.workerBenefits", { effects: o }) })] }), s && /* @__PURE__ */ _("p", { children: s })]
			}),
			/* @__PURE__ */ v("div", {
				className: "tta-detail-values",
				children: [
					r.value !== void 0 && /* @__PURE__ */ v("span", { children: [/* @__PURE__ */ _(J, { name: r.category === "farm" ? "food" : "ore" }), r.value] }),
					Object.entries(r.ratings ?? {}).map(([e, t]) => /* @__PURE__ */ v("span", { children: [
						n(Y[e]),
						" ",
						t
					] }, e)),
					r.science !== void 0 && /* @__PURE__ */ v("span", { children: [
						n("games.throughtheages.researchCost"),
						" ",
						r.science
					] }),
					r.cost !== void 0 && /* @__PURE__ */ v("span", { children: [
						n("games.throughtheages.construction"),
						" ",
						r.cost
					] }),
					r.revolution !== void 0 && /* @__PURE__ */ v("span", { children: [
						n("games.throughtheages.revolutionCost"),
						" ",
						r.revolution
					] }),
					r.stages && /* @__PURE__ */ v("span", { children: [
						n("games.throughtheages.stageCosts"),
						" ",
						r.stages.join(" / ")
					] }),
					r.units && /* @__PURE__ */ v("span", { children: [
						r.units.map((e, t) => e ? `${n(Y[[
							"infantry",
							"cavalry",
							"artillery"
						][t]])} × ${e}` : "").filter(Boolean).join(" + "),
						" · +",
						r.tactic,
						" / +",
						r.obsolete
					] }),
					r.defense && /* @__PURE__ */ v("span", { children: [
						n("games.throughtheages.strength"),
						" +",
						r.defense,
						" · ",
						n("games.throughtheages.colonize"),
						" +",
						r.colonize
					] }),
					!!r.yellow && /* @__PURE__ */ _("span", { children: n("games.throughtheages.yellowBonus", { n: r.yellow }) }),
					!!r.blue && /* @__PURE__ */ _("span", { children: n("games.throughtheages.blueBonus", { n: r.blue }) }),
					Object.entries(r.gain ?? {}).map(([e, t]) => /* @__PURE__ */ _("span", { children: n("games.throughtheages.moves.gain", {
						n: t,
						resource: n(e === "cards" ? "games.throughtheages.militaryHand" : e === "population" ? "games.throughtheages.population" : Y[e])
					}) }, e))
				]
			})
		]
	});
}
//#endregion
//#region src/games/throughtheages/civilization-scene.tsx
var ir = {
	"farm:0": [
		16,
		216,
		86
	],
	"farm:1": [
		126,
		161,
		108
	],
	"mine:0": [
		811,
		216,
		84
	],
	"mine:1": [
		864,
		137,
		103
	],
	"lab:0": [
		291,
		217,
		86
	],
	"lab:1": [
		369,
		131,
		100
	],
	"temple:0": [
		571,
		209,
		95
	],
	"library:1": [
		576,
		105,
		98
	],
	"infantry:0": [
		14,
		105,
		96
	],
	"cavalry:1": [
		234,
		106,
		98
	],
	"law:1": [
		481,
		181,
		76
	]
}, ar = [
	...Object.values(ir),
	[
		739,
		97,
		118
	],
	[
		698,
		218,
		98
	]
], or = {
	farm: "farmer",
	mine: "miner",
	lab: "scholar",
	library: "scholar",
	temple: "priest",
	infantry: "soldier",
	cavalry: "soldier",
	artillery: "soldier",
	airforce: "soldier"
};
function sr(e) {
	let [t, n, r] = ar[e % ar.length];
	return [
		(1 + Math.floor(e / ar.length)) * 980 + t,
		n,
		r
	];
}
function cr(e, t, n) {
	return {
		area: "technology",
		id: t,
		ids: n,
		owner: e.rid,
		key: `technology:${e.rid}:${t}`
	};
}
function lr({ player: e, pub: t, stateFor: n, onPick: r }) {
	let i = f(), a = 0, o = e.technologies.map((n) => {
		let r = x(n.id, t.config), i = `${r.category}:${r.age}`;
		return {
			target: cr(e, n.id),
			place: ir[i] ?? sr(a++),
			workers: n.workers,
			blue: n.blue,
			wonder: void 0
		};
	});
	o.push(...e.wonders.map((t, n) => ({
		target: {
			area: "wonder",
			id: t.id,
			owner: e.rid,
			key: `wonder:${e.rid}:${t.id}`
		},
		place: n === 0 ? [
			739,
			97,
			118
		] : n === 1 ? [
			698,
			218,
			98
		] : sr(a + n - 2),
		workers: 0,
		blue: t.blue,
		wonder: t
	})));
	let s = Math.max(980, ...o.map((e) => Math.ceil((e.place[0] + e.place[2]) / 980) * 980)), c = (e) => {
		let r = n(e.target), a = x(e.target.id, t.config);
		return `${X(i, a.id, t.config)} · ${Wn(a.age)}${e.target.area === "technology" ? ` · ${i("games.throughtheages.workers", { n: e.workers })} · ${i("games.throughtheages.tokens", { n: e.blue })}` : ` · ${e.wonder?.ruined ? i("games.throughtheages.ruined") : i("games.throughtheages.stages", { n: e.wonder.stages }) + " / " + a.stages.length}`}${r === "available" || r === "candidate" ? ` · ${i("games.throughtheages.availableTarget")}` : ""}`;
	};
	return /* @__PURE__ */ _("div", {
		className: "tta-city-scroll",
		tabIndex: 0,
		role: "region",
		"aria-label": i("games.throughtheages.civilization"),
		children: /* @__PURE__ */ v("div", {
			className: "tta-city-canvas",
			style: { "--tta-city-width": s },
			children: [
				Array.from({ length: s / 980 }, (e, t) => /* @__PURE__ */ _("div", {
					className: "tta-city-land",
					style: {
						left: `${t * 980 / s * 100}%`,
						width: `${980 / s * 100}%`
					},
					children: /* @__PURE__ */ _(Fn, { extension: t % 2 == 1 })
				}, t)),
				Object.entries(ir).filter(([n]) => !e.technologies.some((e) => {
					let r = x(e.id, t.config);
					return `${r.category}:${r.age}` === n;
				})).map(([e, [t, n, r]]) => /* @__PURE__ */ _("span", {
					className: "tta-city-vacancy",
					style: {
						left: `${(t + r / 2 - 20) / s * 100}%`,
						top: `${(n + r * .8 - 30) / 360 * 100}%`
					},
					children: /* @__PURE__ */ _(In, {})
				}, e)),
				o.slice().sort((e, t) => e.place[1] + e.place[2] * .8 - (t.place[1] + t.place[2] * .8)).map((e) => {
					let { target: i, place: [a, o, l], workers: u, blue: d, wonder: f } = e, p = x(i.id, t.config), m = n(i);
					return /* @__PURE__ */ v("button", {
						type: "button",
						className: "tta-city-site",
						"data-target": i.key,
						"data-state": m,
						"data-ruined": f?.ruined,
						"aria-label": c(e),
						"aria-pressed": m === "selected",
						style: {
							left: `${a / s * 100}%`,
							top: `${o / 360 * 100}%`,
							width: `${l / s * 100}%`,
							height: `${l * .8 / 360 * 100}%`
						},
						onClick: () => r(i),
						children: [
							/* @__PURE__ */ _(Nn, {
								definition: p,
								scene: !0
							}),
							/* @__PURE__ */ _("svg", {
								className: "tta-object-outline",
								viewBox: "0 0 300 240",
								"aria-hidden": "true",
								children: /* @__PURE__ */ _(Rn, {
									art: Mn(p),
									state: m
								})
							}),
							f && !f.ruined && f.stages < p.stages.length && /* @__PURE__ */ _("svg", {
								className: "tta-construction",
								viewBox: "0 0 300 240",
								"aria-hidden": "true",
								children: /* @__PURE__ */ _("path", { d: "M34 206V57m41 145V43m-47 24 68-20M27 112l69-18m-69 63 69-18M35 66l40 32-40 26 40 28-40 33M225 196V50m39 138V38m-49 22 59-17m-58 69 59-15m-57 66 56-15" })
							}),
							we.includes(p.category) && /* @__PURE__ */ v("span", {
								className: "tta-site-tokens",
								children: [u ? /* @__PURE__ */ _(er, {
									count: u,
									role: or[p.category],
									outlined: !0
								}) : /* @__PURE__ */ v("span", {
									className: "tta-zero-workers",
									children: [/* @__PURE__ */ _($n, {
										count: 1,
										kind: "worker"
									}), "0"]
								}), d > 0 && /* @__PURE__ */ _($n, {
									count: d,
									kind: "blue",
									limit: 5
								})]
							}),
							f && d > 0 && /* @__PURE__ */ _("span", {
								className: "tta-site-tokens",
								children: /* @__PURE__ */ _($n, {
									count: d,
									kind: "blue",
									limit: 5
								})
							})
						]
					}, i.key);
				}),
				o.map((e) => {
					let [a, o, l] = e.place, u = x(e.target.id, t.config), d = n(e.target);
					return /* @__PURE__ */ v("button", {
						type: "button",
						className: "tta-city-caption",
						"data-state": d,
						"aria-label": c(e),
						"aria-pressed": d === "selected",
						style: {
							left: `${(a + l / 2) / s * 100}%`,
							top: `${Math.min(290, o + l * .8 + 4) / 360 * 100}%`
						},
						onClick: () => r(e.target),
						children: [/* @__PURE__ */ v("span", {
							className: "tta-city-name",
							children: [
								/* @__PURE__ */ _("small", { children: Wn(u.age) }),
								X(i, u.id, t.config),
								d === "selected" && /* @__PURE__ */ _(re, { size: 12 })
							]
						}), e.wonder && /* @__PURE__ */ _("span", {
							className: "tta-wonder-stages",
							children: e.wonder.ruined ? i("games.throughtheages.ruined") : u.stages.map((t, n) => /* @__PURE__ */ _("i", { "data-built": n < e.wonder.stages }, n))
						})]
					}, e.target.key);
				})
			]
		})
	});
}
//#endregion
//#region src/games/throughtheages/interaction.ts
var ur = /* @__PURE__ */ new Set([
	"build",
	"upgrade",
	"destroy",
	"barbarossa",
	"auctionUnit",
	"sacrifice",
	"produce",
	"removeBlue",
	"losePopulation",
	"freeBuild"
]), dr = /* @__PURE__ */ new Set([
	"hammurabi",
	"churchill",
	"olympics",
	"fleming",
	"alexander",
	"catherine",
	"saladin",
	"jobs",
	"recoverCivil"
]), fr = /* @__PURE__ */ new Set([
	"offer",
	"aggression",
	"declareWar",
	"fleming"
]);
function pr(e, t, n, r) {
	let i = e.ids ?? [e.id], a = e.owner === r;
	return t.filter((t) => {
		switch (e.area) {
			case "row": return (t.type === "take" || t.type === "agreementTake") && t.source === e.uid;
			case "hand": return a && (t.action === e.uid || t.source === e.uid && !["take", "agreementTake"].includes(t.type)) || !a && n.prompt?.kind === "kidnap" && n.prompt.target === e.owner && t.type === "kidnap" && t.source === e.uid;
			case "military": return a && t.source === e.uid && !["take", "agreementTake"].includes(t.type);
			case "technology": return t.type === "demolish" ? t.target === e.owner && i.includes(t.card ?? "") : t.type === "raid" || t.type === "warSteal" ? n.prompt?.target === e.owner && i.includes(t.card ?? "") : a && ur.has(t.type) && (i.includes(t.card ?? "") || t.type === "upgrade" && i.includes(t.source ?? ""));
			case "government": return !1;
			case "leader": return a && (t.card === e.id && dr.has(t.type) || t.type === "hammurabi" && e.id === "hammurabi") || !a && n.prompt?.target === e.owner && t.type === "infiltrateLeader" && t.card === e.id;
			case "wonder": return t.type === "wonder" ? t.target === e.owner && t.card === e.id : t.type === "infiltrateWonder" ? n.prompt?.target === e.owner && t.card === e.id : a && [
				"louvre",
				"homer",
				"ravages",
				"liner"
			].includes(t.type) && t.card === e.id;
			case "colony": return t.card === e.id && (a && t.type === "loseColony" || n.prompt?.target === e.owner && t.type === "annex");
			case "tactic": return t.type === "copyTactic" && t.source === e.uid;
			case "pact": return t.type === "cancelPact" && t.card === e.id && (e.owner === r || e.uid === r);
			case "pool": return a && (["population", "liner"].includes(t.type) || t.type === "losePopulation" && !t.card);
			case "player": return fr.has(t.type) && t.target === e.owner;
			case "reference": return !1;
		}
	});
}
function mr(e, t) {
	return t ? e.filter((e) => e.action === t || e.source === t) : e;
}
//#endregion
//#region src/games/throughtheages/view-player.tsx
var hr = "(orientation: landscape) and (min-width: 1000px)", gr = () => window.matchMedia(hr).matches, _r = (e) => {
	let t = window.matchMedia(hr);
	return t.addEventListener("change", e), () => t.removeEventListener("change", e);
}, vr = () => !1, yr = [
	"culture",
	"science",
	"food",
	"ore",
	"strength",
	"happy"
];
function br(e) {
	return /* @__PURE__ */ _(An, { children: /* @__PURE__ */ _(xr, { ...e }, e.myRid) });
}
function xr(e) {
	m();
	let t = f(), n = e.public, r = e.private, i = u(_r, gr, vr), [a, o] = l(e.myRid), [s, c] = l(null), [d, te] = l(null), [ne, ie] = l(!1), [ae, g] = l(!1), [se, ce] = l(!1), [le, ue] = l("hand"), y = (t) => e.members.find((e) => e.rid === t)?.name ?? t, de = n.players.find((t) => t.rid === e.myRid), b = n.players.find((e) => e.rid === a) ?? de, S = n.phase === "done" ? [] : r?.moves ?? [], C = d && S.some((e) => e.source === d || e.action === d) ? d : null, w = mr(S, C), T = s ? pr(s, w, n, e.myRid) : w, fe = n.auction ? "auction" : n.prompt?.kind ?? n.phase, pe = n.acting === e.myRid || n.phase === "resolve" && !n.acting ? t(Hn[fe] ?? Hn.resolve) : t("games.throughtheages.waiting", { name: y(n.acting) }), E = !!C || !!n.prompt && n.acting === e.myRid || !!n.auction && n.acting === e.myRid, D = (e, t, n, r) => ({
		area: e,
		id: t,
		owner: n,
		uid: r,
		key: `${e}:${n ?? ""}:${r ?? t}`
	}), O = (t) => s?.key === t.key || t.area === "technology" && s?.area === "technology" && t.owner === s.owner && t.ids?.includes(s.id) ? "selected" : pr(t, w, n, e.myRid).length > 0 ? E ? "candidate" : "available" : void 0, k = (t) => {
		ce(!1), c(t), g(!0);
		let r = t.id ? x(t.id, n.config) : null;
		(t.area === "hand" && r?.kind === "action" || t.area === "military" && [
			"aggression",
			"war",
			"pact"
		].includes(r?.kind ?? "")) && pr(t, S, n, e.myRid).length && te(t.uid);
	}, A = () => {
		g(!1), c(null), te(null), ce(!1);
	}, me = (t) => {
		S.some((e) => e.id === t) && (e.send({
			type: "choose",
			id: t
		}), A());
	}, he = () => {
		ce(!0), g(!0);
	}, ge = (e) => {
		C && w.some((t) => t.target === e && [
			"offer",
			"aggression",
			"declareWar",
			"fleming"
		].includes(t.type)) ? (c(D("player", "", e)), g(!0), ce(!1)) : (o(e), c(null), g(!1), ce(!1));
	}, j = (e, t, r = !1) => /* @__PURE__ */ _(Qn, {
		target: e,
		config: n.config,
		badge: t,
		onClick: () => k(e),
		state: O(e),
		compact: r
	}, e.key), _e = S.find((e) => e.type === "end" || e.type === "endPolitics"), ve = D("pool", "", e.myRid), ye = pr(ve, w, n, e.myRid), be = b.rid === e.myRid ? r?.hand ?? [] : b.hand, M = b.rid === e.myRid ? r?.militaryHand ?? [] : [], xe = (e) => /* @__PURE__ */ _("div", {
		className: "tta-choices",
		children: e.map((e) => {
			let i = e.action ? r?.hand.find((t) => t.uid === e.action) : null;
			return /* @__PURE__ */ v("button", {
				type: "button",
				className: "tta-choice",
				"data-move-type": e.type,
				onClick: () => me(e.id),
				children: [
					/* @__PURE__ */ _("span", { children: i ? t("games.throughtheages.via", {
						card: X(t, i.id, n.config),
						action: Gn(t, e, n.config, y)
					}) : Gn(t, e, n.config, y) }),
					/* @__PURE__ */ _(nr, { move: e }),
					e.ability === "gutenberg" && /* @__PURE__ */ _("span", {
						className: "tta-choice-note",
						children: t("games.throughtheages.discounted")
					})
				]
			}, e.id);
		})
	}), Se = ne ? t("games.throughtheages.events") : se ? t("games.throughtheages.actions") : s?.area === "player" ? y(s.owner) : s?.area === "pool" ? t("games.throughtheages.pool") : s?.id ? X(t, s.id, n.config) : t("games.throughtheages.actions"), Ce = /* @__PURE__ */ v("div", {
		className: "tta-table-info",
		children: [
			/* @__PURE__ */ v("div", {
				className: "tta-leadership-mobile",
				children: [j(D("government", b.government, b.rid)), b.leader && j(D("leader", b.leader, b.rid))]
			}),
			/* @__PURE__ */ _("p", { children: t("games.throughtheages.eventCounts", {
				n: n.eventCount,
				future: n.futureCount
			}) }),
			/* @__PURE__ */ v("table", {
				className: "tta-decks",
				children: [/* @__PURE__ */ _("thead", { children: /* @__PURE__ */ v("tr", { children: [
					/* @__PURE__ */ _("th", {}),
					/* @__PURE__ */ _("th", { children: t("games.throughtheages.civilDeck") }),
					/* @__PURE__ */ _("th", { children: t("games.throughtheages.militaryDeck") })
				] }) }), /* @__PURE__ */ _("tbody", { children: n.deckCounts.map((e, t) => /* @__PURE__ */ v("tr", { children: [
					/* @__PURE__ */ _("th", { children: Wn(t) }),
					/* @__PURE__ */ _("td", { children: e }),
					/* @__PURE__ */ _("td", { children: n.militaryCounts[t] })
				] }, t)) })]
			}),
			/* @__PURE__ */ v("div", {
				className: "tta-hand-strip",
				children: [
					n.exposed && j(D("reference", n.exposed)),
					n.pacts.map((e) => j(D("pact", e.id, e.a, e.b), `${y(e.a)} / ${y(e.b)}`)),
					n.wars.map((e) => j(D("reference", e.id, e.a, `${e.a}:${e.b}`), `${y(e.a)} → ${y(e.b)}`))
				]
			}),
			/* @__PURE__ */ _("h3", { children: t("games.throughtheages.commonTactics") }),
			/* @__PURE__ */ _("div", {
				className: "tta-hand-strip",
				children: n.tactics.filter((e) => !e.owner).map((e) => j(D("tactic", e.id, void 0, e.uid), e.sun ? t("games.throughtheages.sunMark") : void 0))
			}),
			n.pools.length > 0 && /* @__PURE__ */ v("details", { children: [/* @__PURE__ */ _("summary", { children: t("games.throughtheages.selectedPool") }), n.pools.map((e, t) => /* @__PURE__ */ v("div", { children: [/* @__PURE__ */ _("h3", { children: Wn(t) }), /* @__PURE__ */ _("div", {
				className: "tta-hand-strip",
				children: e.map((e) => j(D("reference", e)))
			})] }, t))] }),
			r?.peek && /* @__PURE__ */ v("div", { children: [/* @__PURE__ */ _("h3", { children: t("games.throughtheages.peek") }), j(D("reference", r.peek))] }),
			!!r?.knownEvents.length && /* @__PURE__ */ v("div", { children: [/* @__PURE__ */ _("h3", { children: t("games.throughtheages.knownEvents") }), /* @__PURE__ */ _("div", {
				className: "tta-hand-strip",
				children: r.knownEvents.map((e, t) => j(D("reference", e, void 0, `${e}:${t}`)))
			})] }),
			r?.spy && /* @__PURE__ */ v("div", { children: [/* @__PURE__ */ _("h3", { children: t("games.throughtheages.spy", { name: y(r.spy.rid) }) }), /* @__PURE__ */ _("div", {
				className: "tta-hand-strip",
				children: r.spy.cards.map((e) => j(D("reference", e.id, r.spy.rid, e.uid)))
			})] })
		]
	}), we = /* @__PURE__ */ v("div", {
		className: "tta-details-content",
		children: [
			s?.id && !se && /* @__PURE__ */ _(rr, {
				id: s.id,
				config: n.config
			}),
			s?.area === "technology" && s.ids && s.ids.length > 1 && /* @__PURE__ */ _("div", {
				className: "tta-related",
				children: s.ids.map((e) => {
					let t = b.technologies.find((t) => t.id === e);
					return j(cr(b, e), /* @__PURE__ */ _(tr, {
						workers: t.workers,
						blue: t.blue
					}));
				})
			}),
			C && /* @__PURE__ */ _("button", {
				type: "button",
				className: "tta-button tta-pick-targets",
				onClick: () => g(!1),
				children: t("games.throughtheages.chooseTargets")
			}),
			n.auction && n.acting === e.myRid && /* @__PURE__ */ v("div", {
				className: "tta-response",
				children: [
					/* @__PURE__ */ _("strong", { children: t("games.throughtheages.auction", {
						card: X(t, n.auction.card, n.config),
						n: n.auction.bid
					}) }),
					/* @__PURE__ */ _("p", { children: t("games.throughtheages.selectedUnits", {
						n: Object.values(r?.units ?? {}).reduce((e, t) => e + t, 0),
						cards: r?.selected.length ?? 0
					}) }),
					/* @__PURE__ */ _("p", { children: t("games.throughtheages.colonizationOffer", {
						n: r?.force ?? 0,
						paid: r?.paid ?? 0
					}) }),
					!!r?.paidFood && /* @__PURE__ */ _("p", { children: t("games.throughtheages.tradePayment", {
						n: r.paidFood,
						resource: t("games.throughtheages.food")
					}) }),
					Object.entries(r?.units ?? {}).filter(([, e]) => e).map(([e, r]) => /* @__PURE__ */ v("p", { children: [
						X(t, e, n.config),
						" × ",
						r
					] }, e))
				]
			}),
			n.prompt?.target && n.prompt.target !== b.rid && /* @__PURE__ */ _("button", {
				type: "button",
				className: "tta-button",
				onClick: () => {
					o(n.prompt.target), g(!1);
				},
				children: t("games.throughtheages.viewCivilization", { name: y(n.prompt.target) })
			}),
			xe(se ? w : s ? T : S.filter((e) => !["end", "endPolitics"].includes(e.type))),
			!S.length && /* @__PURE__ */ _("p", {
				className: "tta-muted",
				children: pe
			})
		]
	}), N = {
		hand: "games.throughtheages.hand",
		military: "games.throughtheages.militaryHand",
		table: "games.throughtheages.events",
		history: "games.throughtheages.history"
	};
	return /* @__PURE__ */ v(oe, {
		adaptive: !0,
		scroll: !0,
		className: "tta-screen",
		actionsHeight: "tta-footer-height",
		banner: /* @__PURE__ */ v("div", {
			className: "tta-banner",
			children: [/* @__PURE__ */ v("div", {
				className: "tta-heading",
				children: [
					/* @__PURE__ */ _("span", {
						className: "tta-game-title",
						children: t("games.throughtheages.shortName")
					}),
					/* @__PURE__ */ _("span", {
						className: "tta-round",
						children: t("games.throughtheages.turn", {
							round: n.round,
							age: Wn(n.age)
						})
					}),
					/* @__PURE__ */ _("strong", {
						className: "tta-phase",
						title: pe,
						children: pe
					})
				]
			}), /* @__PURE__ */ _("div", {
				className: "tta-players",
				role: "group",
				"aria-label": t("games.throughtheages.civilizations"),
				children: n.players.map((r) => {
					let i = e.members.find((e) => e.rid === r.rid), a = D("player", "", r.rid), o = pr(a, w, n, e.myRid).length > 0;
					return /* @__PURE__ */ v("button", {
						type: "button",
						className: "tta-player",
						"data-picked": b.rid === r.rid,
						"data-acting": n.acting === r.rid,
						"data-state": O(a),
						style: { "--tta-player-color": p[(i?.colorIndex ?? 0) % p.length].hex },
						"aria-pressed": b.rid === r.rid,
						onClick: () => ge(r.rid),
						children: [
							/* @__PURE__ */ v("span", {
								className: "tta-player-name",
								children: [y(r.rid), r.rid === e.myRid && /* @__PURE__ */ _("small", { children: t("games.throughtheages.you") })]
							}),
							/* @__PURE__ */ v("span", {
								className: "tta-player-score",
								children: [/* @__PURE__ */ _(J, { name: "culture" }), r.culture]
							}),
							o && /* @__PURE__ */ _("span", {
								className: "tta-target-dot",
								"aria-label": t("games.throughtheages.availableTarget")
							}),
							/* @__PURE__ */ _(zn, { state: O(a) })
						]
					}, r.rid);
				})
			})]
		}),
		actions: /* @__PURE__ */ v("div", {
			className: "tta-actions",
			children: [
				/* @__PURE__ */ _("div", {
					className: "tta-action-supply",
					children: ["civil", "military"].map((e) => /* @__PURE__ */ v("span", {
						title: `${t(Y[e])} ${de[e]} / ${de.ratings[e]}`,
						children: [/* @__PURE__ */ _("span", {
							className: "tta-action-cubes",
							children: Array.from({ length: Math.min(de.ratings[e], 7) }, (t, n) => /* @__PURE__ */ _(J, {
								name: e,
								className: n >= de[e] ? "tta-spent" : ""
							}, n))
						}), /* @__PURE__ */ v("b", { children: [
							de[e],
							" / ",
							de.ratings[e]
						] })]
					}, e))
				}),
				/* @__PURE__ */ _("span", {
					className: "tta-footer-round",
					children: n.lastRound === n.round ? t("games.throughtheages.lastRound") : t("games.throughtheages.turn", {
						round: n.round,
						age: Wn(n.age)
					})
				}),
				C ? /* @__PURE__ */ _("button", {
					type: "button",
					className: "tta-button",
					onClick: A,
					children: t("games.throughtheages.cancelSelection")
				}) : /* @__PURE__ */ v("button", {
					type: "button",
					className: "tta-button tta-population-action",
					"data-state": O(ve),
					disabled: !ye.length,
					onClick: () => k(ve),
					children: [t("games.throughtheages.moves.population"), /* @__PURE__ */ _(zn, { state: O(ve) })]
				}),
				/* @__PURE__ */ _("button", {
					type: "button",
					className: "tta-button tta-all-actions",
					disabled: !S.length,
					onClick: he,
					children: t("games.throughtheages.actions")
				}),
				/* @__PURE__ */ _("button", {
					type: "button",
					className: "tta-button tta-primary tta-end-action",
					disabled: !_e,
					onClick: () => _e && me(_e.id),
					children: t(_e?.type === "endPolitics" ? "games.throughtheages.endPoliticsShort" : "games.throughtheages.endActionShort")
				})
			]
		}),
		children: [/* @__PURE__ */ v("div", {
			className: "tta-page",
			children: [/* @__PURE__ */ _("section", {
				className: "tta-market",
				"aria-label": t("games.throughtheages.row"),
				children: /* @__PURE__ */ _("div", {
					className: "tta-row",
					children: n.row.map((e, n) => /* @__PURE__ */ v("div", {
						className: "tta-row-slot",
						children: [/* @__PURE__ */ _("span", {
							className: "tta-row-price",
							"aria-hidden": "true",
							children: Array.from({ length: n < 5 ? 1 : n < 9 ? 2 : 3 }, (e, t) => /* @__PURE__ */ _(J, { name: "civil" }, t))
						}), e ? j(D("row", e.id, void 0, e.uid)) : /* @__PURE__ */ _("div", {
							className: "tta-empty-card",
							"aria-label": t("games.throughtheages.emptySlot"),
							children: /* @__PURE__ */ _("span", { children: "—" })
						})]
					}, n))
				})
			}), /* @__PURE__ */ v("div", {
				className: "tta-layout",
				children: [/* @__PURE__ */ v("main", {
					className: "tta-main",
					children: [
						/* @__PURE__ */ v("section", {
							className: "tta-world",
							children: [
								/* @__PURE__ */ _(lr, {
									player: b,
									pub: n,
									onPick: k,
									stateFor: O
								}),
								/* @__PURE__ */ v("div", {
									className: "tta-world-hud",
									children: [/* @__PURE__ */ _("section", {
										className: "tta-stats",
										"aria-label": y(b.rid),
										children: yr.map((e) => /* @__PURE__ */ v("div", {
											className: "tta-stat",
											title: `${t(Y[e])} ${e === "strength" || e === "happy" ? b.ratings[e] : b[e]}`,
											children: [
												/* @__PURE__ */ _(J, { name: e }),
												/* @__PURE__ */ _("strong", { children: e === "strength" || e === "happy" ? b.ratings[e] : b[e] }),
												/* @__PURE__ */ _("small", { children: [
													"culture",
													"science",
													"food",
													"ore"
												].includes(e) ? `+${b.ratings[e]}` : "" })
											]
										}, e))
									}), /* @__PURE__ */ _("div", {
										className: "tta-rulers",
										children: [["government", b.government], ["leader", b.leader]].map(([e, r]) => r && /* @__PURE__ */ v("button", {
											type: "button",
											className: "tta-ruler",
											"data-state": O(D(e, r, b.rid)),
											onClick: () => k(D(e, r, b.rid)),
											children: [
												/* @__PURE__ */ _(Nn, { definition: x(r, n.config) }),
												/* @__PURE__ */ _("span", { children: X(t, r, n.config) }),
												/* @__PURE__ */ _(zn, { state: O(D(e, r, b.rid)) })
											]
										}, e))
									})]
								}),
								/* @__PURE__ */ _(Yn, { player: b })
							]
						}, b.rid),
						(b.colonies.length > 0 || b.tactic) && /* @__PURE__ */ v("div", {
							className: "tta-civilization-assets",
							children: [b.colonies.map((e) => j(D("colony", e, b.rid))), n.tactics.filter((e) => e.uid === b.tactic).map((e) => j(D("reference", e.id, b.rid, e.uid), e.sun ? t("games.throughtheages.sunMark") : void 0))]
						}),
						/* @__PURE__ */ v("section", {
							className: "tta-tray",
							children: [
								/* @__PURE__ */ _("select", {
									className: "tta-tray-select",
									value: le,
									"aria-label": t("games.throughtheages.handArea"),
									onChange: (e) => ue(e.target.value),
									children: Object.keys(N).map((e) => /* @__PURE__ */ v("option", {
										value: e,
										children: [t(N[e]), e === "hand" ? ` ${b.handCount}` : e === "military" ? ` ${b.militaryCount}` : ""]
									}, e))
								}),
								/* @__PURE__ */ _("div", {
									className: "tta-tabs",
									role: "group",
									children: Object.keys(N).map((e) => /* @__PURE__ */ v("button", {
										type: "button",
										className: "tta-tab",
										"aria-pressed": le === e,
										onClick: () => ue(e),
										children: [t(N[e]), e === "hand" ? ` ${b.handCount}` : e === "military" ? ` ${b.militaryCount}` : ""]
									}, e))
								}),
								/* @__PURE__ */ v("div", {
									className: "tta-tray-body",
									children: [
										le === "hand" && /* @__PURE__ */ _("div", {
											className: "tta-hand-strip",
											children: be.map((e) => j(D("hand", e.id, b.rid, e.uid)))
										}),
										le === "military" && /* @__PURE__ */ _("div", {
											className: "tta-hand-strip",
											children: M.map((t) => j(D("military", t.id, e.myRid, t.uid), r?.selected.includes(t.uid) ? /* @__PURE__ */ _(re, { size: 15 }) : void 0))
										}),
										le === "table" && Ce,
										le === "history" && /* @__PURE__ */ _("ol", {
											className: "tta-history",
											children: n.log.slice(-80).reverse().map((e, r) => /* @__PURE__ */ _("li", { children: t(Un[e.key], {
												name: e.rid ? y(e.rid) : "",
												target: e.target ? y(e.target) : "",
												card: e.card ? X(t, e.card, n.config) : "",
												n: e.n ?? 0
											}) }, r))
										})
									]
								})
							]
						})
					]
				}), /* @__PURE__ */ _("aside", {
					className: "tta-sidebar",
					children: /* @__PURE__ */ v("section", {
						className: "tta-detail-panel",
						children: [/* @__PURE__ */ v("header", { children: [/* @__PURE__ */ _("h2", { children: Se }), s && /* @__PURE__ */ _("button", {
							type: "button",
							className: "tta-close",
							"aria-label": t("games.throughtheages.close"),
							onClick: A,
							children: /* @__PURE__ */ _(h, { size: 18 })
						})] }), we]
					})
				})]
			})]
		}), /* @__PURE__ */ _(ee, {
			open: ne || ae && !i,
			onClose: ne ? () => ie(!1) : A,
			label: Se,
			title: Se,
			tall: !0,
			children: /* @__PURE__ */ _("div", {
				className: "tta-sheet-content",
				children: ne ? /* @__PURE__ */ _("div", {
					className: "tta-full-table",
					children: Ce
				}) : we
			})
		})]
	});
}
//#endregion
//#region src/games/throughtheages/bot-position.ts
var Sr = {
	economy: 1,
	science: 1,
	culture: 1,
	military: 1,
	future: .4,
	planning: .7,
	actionCost: .8
};
function Cr(e, t, n) {
	let r = Object.fromEntries(e.players.map((r) => {
		let i = r.rid === n, a = {
			rid: r.rid,
			technologies: r.technologies.map((e) => ({ ...e })),
			government: r.government,
			leader: r.leader,
			wonders: r.wonders.map((e) => ({ ...e })),
			colonies: [...r.colonies],
			tactic: r.tactic,
			yellow: r.yellow,
			yellowTotal: r.yellowTotal,
			blueTotal: r.blueTotal,
			pool: r.pool,
			science: r.science,
			culture: r.culture,
			civil: r.civil,
			military: r.military,
			resigned: r.resigned,
			hand: (i ? t.hand : r.hand).map((e) => ({ ...e })),
			militaryHand: i ? t.militaryHand.map((e) => ({ ...e })) : [],
			takenLeaders: [],
			flags: {},
			temporary: i ? { ...t.temporary } : {},
			final: { ...r.final }
		}, o = r.technologies.reduce((t, n) => t + (x(n.id, e.config).category === "mine" ? n.blue * x(n.id, e.config).value : 0), 0);
		return (r.leader === "billGates" || r.ore > o) && (a.flags.gatesStorage = !0), [r.rid, a];
	})), i = {
		config: e.config,
		seed: 0,
		cursor: 0,
		serial: 0,
		revision: e.revision,
		age: e.age,
		round: e.round,
		turn: e.turn,
		order: [...e.order],
		phase: e.phase,
		players: r,
		row: e.row.map((e) => e && { ...e }),
		civilDecks: [
			[],
			[],
			[],
			[]
		],
		militaryDecks: [
			[],
			[],
			[],
			[]
		],
		militaryDiscard: [
			[],
			[],
			[],
			[]
		],
		events: [],
		future: [],
		past: [...e.past],
		unusedAncientEvents: [],
		exposed: e.exposed,
		pools: [],
		tactics: e.tactics.map((e) => ({ ...e })),
		pacts: e.pacts.map((e) => ({ ...e })),
		wars: e.wars.map((e) => ({ ...e })),
		decision: null,
		auction: null,
		queue: [],
		continuation: "action",
		lastRound: e.lastRound,
		nobel: e.nobel,
		olympics: e.olympics,
		knownEvents: {},
		log: []
	};
	for (let t of e.players.filter((e) => e.leader === "saladin")) {
		let e = i.players[t.rid];
		e.flags.saladin = "civil", I(i, e).civil !== t.ratings.civil && (e.flags.saladin = "strength");
	}
	return i;
}
function Z(e) {
	return structuredClone(e);
}
function wr(e, t) {
	if (e.lastRound !== null) return Math.max(0, e.lastRound - e.round + +(e.order.indexOf(t) >= e.order.indexOf(e.turn)));
	let n = e.players.filter((e) => !e.resigned).length, r = e.deckCounts.reduce((e, t) => e + t, 0) + e.row.filter(Boolean).length;
	return Math.max(1, Math.min(19, r / (4 + n * .8) + .5));
}
var Tr = (e, t, n = .15) => Math.min(e, t) + Math.max(0, e - t) * n;
function Q(e, t, n, r) {
	let i = I(e, t);
	return n === "food" ? r <= 1 ? _e(t) > i.food ? 3 : .08 : i.food <= _e(t) + 1 ? 1.4 : .65 : n === "science" ? r <= 1 ? .05 : i.science < 4 ? 1.2 : .65 : r <= 1 ? .2 : i.ore < 5 ? 1.35 : .8;
}
function $(e, t, n, r) {
	let i = I(e, t), a = Ne(e, t), o = C(t), s = _e(t), c = t.technologies.reduce((t, n) => t + (x(n.id, e.config).category === "farm" ? n.blue * x(n.id, e.config).value : 0), 0), l = t.technologies.reduce((n, r) => n + (x(r.id, e.config).category === "mine" ? r.blue * x(r.id, e.config).value : x(r.id, e.config).category === "lab" && (t.leader === "billGates" || t.flags.gatesStorage) ? r.blue * x(r.id, e.config).age : 0), 0), u = Math.min(8, Math.max(0, n - 1)), d = e.order.map((t) => e.players[t]).filter((e) => e.rid !== t.rid && !e.resigned).map((t) => I(e, t).strength), f = d.length ? Math.max(...d) + 2 : 0, p = t.culture + i.culture * n * r.culture;
	return p += (Tr(i.ore, 8) * 1.9 + Tr(i.food - s, 2, .08) * 2) * u * r.economy, p += Tr(i.science, 7) * 1.7 * u * r.science, p += Tr(l, 12, .08) * Q(e, t, "ore", n) + Tr(c, Math.max(3, s + 3), .08) * Q(e, t, "food", n), p += Tr(t.science, 14, .08) * Q(e, t, "science", n), p += Tr(Math.max(0, t.pool - a), 1, .18) * (n > 1 ? 4.5 : .15), p += Math.min(2, Math.max(0, i.happy - [
		16,
		12,
		10,
		8,
		6,
		4,
		2,
		0
	].filter((e) => t.yellow <= e).length)) * Math.min(3, u), p += Tr(i.civil, 7, .3) * Math.min(6, u) * 2.2, p += Tr(i.military, 4) * Math.min(4, u) * .7, p += Tr(Math.min(i.strength, f), Math.max(2, f - 4), .5) * Math.min(3, n) * .9 * r.military, p += i.colonize * Math.min(4, u) * .6, p -= a * Math.min(5, u) * 2.5, p -= Math.max(0, a - t.pool) * (35 + (i.science + i.culture + i.ore + i.food) * 3), p -= Math.max(0, s - c - i.food + Math.max(0, ye(t) - l)) * 13, p -= ye(t) * (n > 1 ? 1.4 : .4) + Math.max(0, -o) * 8, p;
}
function Er(e, t, n) {
	return Math.min(n, Math.max(1, (x(t, e.config).age + 2 - e.age) * 4));
}
//#endregion
//#region src/games/throughtheages/bot-strategy.ts
var Dr = /* @__PURE__ */ new Set([
	"end",
	"take",
	"leader",
	"research",
	"revolution",
	"population",
	"build",
	"upgrade",
	"destroy",
	"wonder",
	"action",
	"barbarossa",
	"liner",
	"louvre",
	"churchill",
	"hammurabi",
	"tactic",
	"copyTactic"
]);
function Or(e, t, n) {
	let r = I(e, t), i = (n) => t.technologies.reduce((t, r) => t + ((n === "production" ? ["farm", "mine"].includes(x(r.id, e.config).category) : n === "urban" ? F(x(r.id, e.config).category) : P(x(r.id, e.config).category)) ? r.workers : 0), 0);
	switch (n) {
		case "hollywood": return 2 * (Me(e, t, ["theater", "library"]).culture ?? 0);
		case "internet": {
			let n = Me(e, t);
			return (n.science ?? 0) + (n.culture ?? 0) + (n.strength ?? 0);
		}
		case "spaceFlight": return x(t.government, e.config).age + t.technologies.reduce((t, n) => t + x(n.id, e.config).age, 0);
		case "fastFood": return i("production") * 2 + i("urban") + i("military");
		case "manhattan": return r.science;
		case "redCross": return e.order.reduce((t, n) => t + e.players[n].colonies.length, 0);
		case "empireState": return (e.order.length + 5) * [
			"science",
			"culture",
			"strength",
			"food",
			"ore"
		].filter((n) => e.order.filter((e) => e !== t.rid).every((t) => I(e, e.players[t])[n] < r[n])).length;
		case "unitedNations": return 4 * Math.max(t.wonders.filter((t) => t.stages === x(t.id, e.config).stages.length).length, t.technologies.filter((t) => !F(x(t.id, e.config).category) && !P(x(t.id, e.config).category) && !["farm", "mine"].includes(x(t.id, e.config).category)).length, new Set(t.technologies.filter((t) => t.workers && F(x(t.id, e.config).category)).map((t) => x(t.id, e.config).category)).size);
		default: return 0;
	}
}
function kr(e, t, n, r) {
	let i = I(e, t), a = Er(e, n, r);
	switch (n) {
		case "aristotle":
		case "confucius": return a * 1.3;
		case "moses": return Math.min(4, a) * 1.5;
		case "homer":
		case "cleopatra": return a * 1.2;
		case "hammurabi":
		case "newton": return a * 2.2;
		case "gutenberg": return a * 2.5;
		case "daVinci":
		case "watt": return a * 1.5;
		case "barbarossa": return a * (i.strength < 10 ? 1.8 : .8);
		case "sunTzu": return a * 1.1;
		case "columbus": return a * 1.8;
		case "hippocrates": return Math.min(a, 3) * 2;
		case "ashoka": return a * 1.5;
		case "mariaTheresa": return Math.min(a, 4) * 2;
		case "einstein":
		case "jobs": return a * 2.5;
		case "churchill": return a * 3;
		case "mandela": return a * Math.max(0, i.happy - [
			16,
			12,
			10,
			8,
			6,
			4,
			2,
			0
		].filter((e) => t.yellow <= e).length);
		case "fleming": return Math.min(4, a) * 1.5;
		case "nobel": return a * (i.science >= 6 ? 2 : .5);
		default: return 0;
	}
}
function Ar(e, t) {
	let n = Z(e.s), r = n.players[e.rid], i = x(t, n.config), a = $(n, r, e.h, e.w), o = r.wonders.find((e) => e.id === t);
	o ? o.stages = i.stages.length : r.wonders.push({
		id: t,
		stages: i.stages.length,
		blue: t === "louvre" ? i.stages.length : 0,
		ruined: !1,
		homer: !1
	});
	let s = $(n, r, e.h, e.w) - a + Or(n, r, t);
	return t === "pyramids" && (s += 4), t === "alexandria" && (s += e.h * .9), t === "oceanLiner" && (s += Math.min(e.h, 5) * 3), t === "hangingGardens" && n.config.rebalance && (s += 2), t === "suez" && (s += 6), t === "harvard" && (s += Math.min(e.h, 5) * 2), t === "silkRoad" && (s += Math.min(e.h, 5) * 1.5), t === "stonehenge" && (s += i.stages.reduce((e, t) => e + t, 0)), Math.max(0, s);
}
function jr(e, t) {
	let n = Z(e.s), r = n.players[e.rid], i = x(t, n.config);
	if (r.technologies.some((e) => e.id === t) || r.government === t) return 0;
	let a = $(n, r, e.h, e.w);
	if (i.kind === "government") return r.government = t, Math.max(0, $(n, r, e.h, e.w) - a);
	if (!F(i.category) && !P(i.category) && !["farm", "mine"].includes(i.category)) {
		let o = r.technologies.find((e) => x(e.id, n.config).category === i.category);
		if (o && x(o.id, n.config).age >= i.age) return 0;
		r.technologies = r.technologies.filter((e) => x(e.id, n.config).category !== i.category), r.technologies.push({
			id: t,
			workers: 0,
			blue: 0
		});
		let s = i.category === "construction" ? Math.min(5, e.h) * i.age * .8 : 0;
		return Math.max(0, $(n, r, e.h, e.w) - a + s);
	}
	if (r.technologies.some((e) => x(e.id, n.config).category === i.category && x(e.id, n.config).age >= i.age)) return 0;
	r.technologies.push({
		id: t,
		workers: 0,
		blue: 0
	});
	let o = 0;
	for (let s of [void 0, ...r.technologies.filter((e) => e.workers && x(e.id, n.config).category === i.category)]) {
		let i = Z(n), c = i.players[e.rid];
		c.technologies.find((e) => e.id === t).workers++, s ? c.technologies.find((e) => e.id === s.id).workers-- : c.pool--;
		let l = Math.max(0, De(n, r, t) - (s ? De(n, r, s.id) : 0)), u = $(i, c, e.h, e.w) - a - l * Q(n, r, "ore", e.h) - 1.5;
		o = Math.max(o, u);
	}
	let s = r.technologies.filter((e) => x(e.id, n.config).category === i.category).reduce((e, t) => e + t.workers, 0);
	return o * (s >= 2 ? 1.5 : 1);
}
function Mr(e, t) {
	if (t.type === "end") return {
		m: t,
		score: 0
	};
	let n = Z(e.s), r = n.players[e.rid], i = e.s.players[e.rid], a = t.card ? x(t.card, n.config) : void 0, o = $(e.s, i, e.h, e.w);
	pt(n, r, t);
	let s = $(n, r, e.h, e.w) - o - (t.civil ?? 0) * e.w.actionCost - (t.military ?? 0) * .65;
	if (t.type === "take") {
		if (a.kind === "technology" || a.kind === "government") {
			let n = jr(e, t.card), r = i.science + I(e.s, i).science * Math.min(2, e.h - 1) >= (a.revolution ?? a.science ?? 0);
			s += e.w.future * Math.max(0, n - (a.science ?? 0) * Q(e.s, i, "science", e.h) * .6) * (r ? 1 : .25);
		} else if (a.kind === "leader") {
			let i = Z(n), a = i.players[e.rid], o = a.leader;
			a.leader = t.card;
			let c = Er(n, t.card, e.h);
			s += .55 * Math.max(0, $(i, a, c, e.w) - $(n, r, c, e.w) + kr(i, a, t.card, e.h) - (o ? kr(n, r, o, e.h) : 0));
		} else if (a.kind === "wonder") {
			let n = a.stages.reduce((e, t) => e + t, 0);
			s += e.w.future * Math.max(0, Ar(e, t.card) - n * Q(e.s, i, "ore", e.h) - a.stages.length * 1.7);
		} else if (a.kind === "action") {
			let t = [
				"stockpile",
				"reserves",
				"culturalHeritage",
				"revolutionaryIdea"
			], n = a.effect === "culturalHeritage" ? (a.gain?.science ?? a.amount ?? 0) + (a.gain?.culture ?? a.amount ?? 0) : a.effect === "stockpile" ? 2 : a.amount ?? 2;
			s += e.h > 1 ? (t.includes(a.effect) ? n : n * .8) * .65 : -5;
		}
		a.kind !== "wonder" && (s -= Math.max(0, i.hand.length - 1) * .5);
	}
	if ((t.type === "research" || t.type === "revolution") && (s += e.w.future * jr(e, t.card)), t.type === "leader") {
		let a = Er(n, t.card, e.h);
		s = $(n, r, a, e.w) - $(e.s, i, a, e.w) - (t.civil ?? 0) * e.w.actionCost, s += kr(n, r, t.card, e.h) - (i.leader ? kr(e.s, i, i.leader, e.h) : 0);
	}
	if (t.type === "wonder") {
		let i = t.target ?? e.rid, o = e.s.players[i].wonders.find((e) => e.id === t.card), c = a.stages.length;
		if (i === e.rid) {
			let i = (t.n ?? 1) / Math.max(1, c - o.stages);
			s += o.stages + (t.n ?? 1) === c ? Or(n, r, t.card) : Ar(e, t.card) * i * e.w.future;
		}
	}
	let c = (r.temporary.militaryOre ?? 0) - (i.temporary.militaryOre ?? 0), l = (r.temporary.militaryScience ?? 0) - (i.temporary.militaryScience ?? 0);
	return (c > 0 || l > 0) && lt(n, r).filter((e) => e.card && P(x(e.card, n.config).category)).length && (s += Math.min(c, 5) * .8 + Math.min(l, 4) * .6), t.type === "destroy" && (s -= 2), {
		m: t,
		score: s,
		next: n
	};
}
function Nr(e, t) {
	let n = x(t, e.s.config), r = e.s.players[e.rid], i = I(e.s, r), a = e.pub.players.filter((t) => t.rid !== e.rid && !t.resigned);
	if (n.kind === "territory") return i.colonize + (i.strength - Math.max(...a.map((e) => e.ratings.strength))) * .3;
	if (t.startsWith("impact")) {
		let n = Z(e.s);
		return Lt(n, t), n.players[e.rid].culture - r.culture - a.reduce((e, t) => e + n.players[t.rid].culture - t.culture, 0) / a.length;
	}
	let o = (e) => i[e] - a.reduce((t, n) => t + n.ratings[e], 0) / a.length;
	return [
		"foray",
		"raiders",
		"territorialDispute",
		"crusades",
		"famine",
		"enslavement",
		"politicsStrength",
		"independence",
		"crimeWave",
		"colonialism",
		"happiness",
		"barbarians",
		"callArms",
		"internationalAgreement",
		"internationalNegotiations"
	].includes(t) ? Math.max(-8, Math.min(8, o("strength"))) : [
		"rebellion",
		"emigration",
		"civilUnrest"
	].includes(t) ? a.reduce((e, t) => e + t.discontent, 0) / a.length * 3 - e.pub.players.find((t) => t.rid === e.rid).discontent * 3 : ["scientificBreakthrough", "popularization"].includes(t) ? o("science") : t === "culturalInfluence" ? o("culture") : ["immigration", "prosperity"].includes(t) ? o("happy") : t === "nationalPride" ? r.culture > Math.max(...a.map((e) => e.culture)) ? 5 : -3 : t === "rats" ? a.reduce((e, t) => e + t.food, 0) / a.length - T(e.s, r, "food") : 0;
}
function Pr(e) {
	let t = e.pub.auction, n = e.s.players[e.rid], r = x(t.card, e.s.config), i = $(e.s, n, e.h, e.w), a = n.technologies.filter((t) => t.workers && P(x(t.id, e.s.config).category)), o = e.priv.militaryHand.filter((t) => x(t.id, e.s.config).kind === "bonus" || n.leader === "cook"), s = [{
		units: {},
		cards: [],
		paid: 0,
		food: 0,
		force: I(e.s, n).colonize,
		loss: 0
	}], c = (t) => t.sort((t, n) => t.loss + Math.max(0, e.pub.auction.bid + 1 - t.force) * 3 - (n.loss + Math.max(0, e.pub.auction.bid + 1 - n.force) * 3)).slice(0, 80);
	for (let t of a) {
		let r = [];
		for (let a of s) for (let o = 0; o <= t.workers; o++) {
			let s = {
				...a.units,
				[t.id]: o
			}, c = Z(e.s), l = c.players[e.rid];
			for (let e of l.technologies) {
				let t = s[e.id] ?? 0;
				e.workers -= t, l.yellow += t;
			}
			let u = Ae(e.s, n, s) + I(e.s, n).colonize, d = Object.values(s).reduce((e, t) => e + t, 0) * (e.h > 1 ? 3 : .2);
			r.push({
				...a,
				units: s,
				force: u,
				loss: i - $(c, l, e.h, e.w) + d
			});
		}
		s = c(r);
	}
	for (let t of o) {
		let n = x(t.id, e.s.config);
		s = c([...s, ...s.filter((t) => n.kind === "bonus" || t.cards.filter((t) => x(o.find((e) => e.uid === t).id, e.s.config).kind !== "bonus").length < 2).map((e) => ({
			...e,
			cards: [...e.cards, t.uid],
			force: e.force + (n.colonize ?? 1),
			loss: e.loss + (n.kind === "bonus" ? .6 + (n.defense ?? 0) * .15 : 1.5)
		}))]);
	}
	if (n.leader === "isabella") {
		let t = [];
		for (let r of s) for (let i of [
			0,
			1,
			3,
			6
		]) if (T(e.s, n, "ore") >= i && t.push({
			...r,
			paid: i,
			force: r.force + (i === 6 ? 3 : i === 3 ? 2 : i),
			loss: r.loss + i * Q(e.s, n, "ore", e.h)
		}), e.s.pacts.some((e) => e.id === "tradeRoutes1" && e.a === n.rid)) for (let a = 1; a <= Math.min(i, T(e.s, n, "food")); a++) T(e.s, n, "ore") >= i - a && t.push({
			...r,
			paid: i,
			food: a,
			force: r.force + (i === 6 ? 3 : i === 3 ? 2 : i),
			loss: r.loss + (i - a) * Q(e.s, n, "ore", e.h) + a * Q(e.s, n, "food", e.h)
		});
		s = c(t);
	}
	let l = Z(e.s), u = l.players[e.rid];
	Je(l, u, t.card);
	let d = $(l, u, e.h, e.w) - i + (r.gain?.population ?? 0) * 4 + (r.gain?.cards ?? 0) * .5 + (r.yellow ?? 0) * .6 + (r.blue ?? 0) * 1.2 + (r.id === "autonomous2" ? 5 : 0), f = s.filter((e) => Object.values(e.units).some((e) => e > 0) && e.force > t.bid).sort((e, t) => e.loss - t.loss || e.force - t.force)[0];
	return f && d - f.loss > 1 ? {
		...f,
		score: d - f.loss
	} : null;
}
function Fr(e, t) {
	let n = e.s.players[e.rid], r = t.card ? x(t.card, e.s.config) : void 0, i = e.pub.players.find((n) => n.rid === (t.target ?? e.pub.prompt?.target));
	switch (t.type) {
		case "endPolitics": return 0;
		case "prepare": return r.age + 1 + Nr(e, t.card) * .6 + (e.priv.peek ? Nr(e, e.priv.peek) * .4 : 0);
		case "columbus":
		case "freeColony": {
			let i = Z(e.s), a = i.players[e.rid];
			return t.type === "columbus" && (a.leader = null), Je(i, a, t.card), $(i, a, e.h, e.w) - $(e.s, n, e.h, e.w) + (r.gain?.population ?? 0) * 4 + (r.gain?.cards ?? 0) * .5 + (r.blue ?? 0);
		}
		case "unitedNations": return Nr(e, t.card);
		case "aggression":
		case "declareWar": {
			if (!i) return -10;
			let a = I(e.s, n).strength, o = i.ratings.strength + (i.leader === "nostradamus" && t.type === "aggression" ? 3 : 0), s = e.s.pacts.find((e) => (e.a === n.rid && e.b === i.rid || e.b === n.rid && e.a === i.rid) && ["militaryAlliance3", "protection2"].includes(e.id));
			s?.id === "militaryAlliance3" && (a -= 3, o -= 3), s?.id === "protection2" && (s.b === n.rid ? a -= 4 : o -= 4), e.s.pacts.some((e) => e.id === "openBorders1" && (e.a === n.rid && e.b === i.rid || e.a === i.rid && e.b === n.rid)) && (a += 2);
			let c = a - o, l = e.pub.olympics ? 8 : 0;
			return t.type === "declareWar" ? c > 3 + i.ratings.military ? (r.effect === "warCulture" || r.effect === "hybridWar" ? Math.min(i.culture, c + 5) * 1.6 : c * .8) - (t.military ?? 0) - l : -8 : Math.max(0, Math.min(1, (c - Math.min(i.militaryCount, i.ratings.military) * 1.5) / 4)) * (r.effect === "spy" ? Math.min(i.science, r.amount ?? 0) * 1.5 : r.effect === "intervention" ? Math.min(i.culture, r.amount ?? 0) * 1.7 : r.effect === "plunder" ? Math.min(i.food + i.ore, r.amount ?? 0) * 1.8 : r.effect === "raid" ? 6 * (r.amount ?? 1) : r.effect === "occupy" ? 15 : 8) - (t.military ?? 0) * .8 - 1 - l;
		}
		case "defend": return 100;
		case "defenseCard": return t.n === 1 ? 8 + (r.defense ?? 1) * 2 - (r.kind === "bonus" ? 0 : 1) : -30;
		case "yield": return -10;
		case "discard":
		case "discardCards": return -Ir(e, r);
		case "offer": return -3;
		case "cancelPact": return -3;
		case "accept": return [
			"supremacy2",
			"sovereignty3",
			"protection2"
		].includes(t.card) ? -2 : 2;
		case "decline":
		case "skip": return 0;
		case "fleming": return i ? i.militaryCount : 0;
		case "olympics": return 5;
		case "catherine": return e.h > 2 ? 8 : 0;
		case "alexander": return e.pub.age >= 2 ? 4 : -3;
		default: return Lr(e, t);
	}
}
function Ir(e, t) {
	if (t.kind === "bonus") return 3 + (t.defense ?? 0) * .6;
	if (t.kind === "tactic") {
		let n = Z(e.s), r = n.players[e.rid], i = I(n, r).strength;
		return n.tactics.push({
			id: t.id,
			uid: "candidate",
			owner: r.rid,
			sun: !1
		}), r.tactic = "candidate", Math.max(.3, (I(n, r).strength - i) * 1.5);
	}
	return t.kind === "event" || t.kind === "territory" ? Math.max(.2, 1 + t.age + Nr(e, t.id) * .4) : .8 + t.age * .2;
}
function Lr(e, t) {
	let n = e.s.players[e.rid], r = t.card ? x(t.card, e.s.config) : void 0;
	switch (t.type) {
		case "gain": return (t.n ?? 1) * (t.resource === "culture" ? 1 : Q(e.s, n, t.resource, e.h));
		case "gainMixed": return (t.n ?? 0) * Q(e.s, n, "food", e.h) + (t.cost ?? 0) * Q(e.s, n, "ore", e.h);
		case "loseMixed": return -(t.n ?? 0) * Q(e.s, n, "food", e.h) - (t.cost ?? 0) * Q(e.s, n, "ore", e.h);
		case "produce": return (r.value ?? r.age) * Q(e.s, n, x(t.card, e.s.config).category === "farm" ? "food" : "ore", e.h);
		case "removeBlue": return -(r.value ?? r.age) * Q(e.s, n, r.category === "farm" ? "food" : "ore", e.h);
		case "losePopulation":
		case "sacrifice": {
			let r = Z(e.s), i = r.players[e.rid];
			return t.card ? i.technologies.find((e) => e.id === t.card).workers-- : i.pool--, i.yellow++, $(r, i, e.h, e.w) - $(e.s, n, e.h, e.w) - (t.type === "sacrifice" ? 2 : 0);
		}
		case "freeBuild": {
			let r = Z(e.s), i = r.players[e.rid];
			return i.pool--, i.technologies.find((e) => e.id === t.card).workers++, $(r, i, e.h, e.w) - $(e.s, n, e.h, e.w);
		}
		case "recoverCivil": return n.civil < I(e.s, n).civil ? 3 : 0;
		case "homer": return 4;
		case "jobs": return 4 - t.payment.food * Q(e.s, n, "food", e.h) - t.payment.ore * Q(e.s, n, "ore", e.h);
		case "saladin": return t.extra === "civil" ? 5 : 1;
		case "planning": return Nr(e, t.card);
		case "agreementAccept": return n.civil >= 3 ? 6 : 1;
		case "agreementTake": return 5 + (r.kind === "technology" ? jr(e, t.card) * .3 : r.age);
		case "plunder": {
			let i = e.pub.players.find((t) => t.rid === e.pub.prompt?.target), a = Math.min(r.amount, i.food + i.ore);
			return (t.n ?? 0) * Q(e.s, n, "food", e.h) + (a - (t.n ?? 0)) * Q(e.s, n, "ore", e.h);
		}
		case "raid": return (r.ratings?.culture ?? 0) * e.h + (r.ratings?.science ?? 0) * Math.min(e.h, 6) + r.cost * .5 + (r.ratings?.happy ?? 0) * 2;
		case "demolish": {
			let n = t.target, r = Z(e.s), i = r.players[n];
			i.technologies.find((e) => e.id === t.card).workers--, i.pool++;
			let a = $(r, i, e.h, e.w) - $(e.s, e.s.players[n], e.h, e.w);
			return n === e.rid ? a : -a;
		}
		case "infiltrateLeader": return 8 + r.age;
		case "infiltrateWonder": return 5;
		case "warScience": return (t.n ?? 0) * Q(e.s, n, "science", e.h);
		case "warSteal": return jr(e, t.card) + (t.n ?? 0) * .3;
		case "kidnap": return r.kind === "technology" ? jr(e, t.card) * .5 : r.kind === "leader" ? 5 : 2;
		case "annex": return 8 + (r.gain?.culture ?? 0) + (r.ratings?.civil ?? 0) * e.h;
		case "loseColony": return -(r.yellow ?? 0) * 2 - (r.blue ?? 0) - (r.ratings?.civil ?? 0) * e.h * 2 - (r.ratings?.happy ?? 0) * 4;
		case "ravages": return -(r.ratings?.culture ?? 0) * e.h - (r.ratings?.civil ?? 0) * e.h * 2;
		case "negotiate": return t.resource === "science" ? 2 : 1;
		default: return 0;
	}
}
function Rr(e = {}) {
	let t = {
		...Sr,
		...e
	};
	return (e, n) => {
		let r = e.public, i = e.private;
		if (!i?.moves.length || !r.players.some((e) => e.rid === n.rid)) return null;
		let a = {
			s: Cr(r, i, n.rid),
			rid: n.rid,
			pub: r,
			priv: i,
			h: wr(r, n.rid),
			w: t
		}, o;
		if (r.auction?.rid === n.rid) {
			let e = Pr(a);
			e && (o = i.moves.find((t) => t.type === "auctionUnit" && (e.units[t.card] ?? 0) !== (i.units[t.card] ?? 0) && t.n === ((e.units[t.card] ?? 0) > (i.units[t.card] ?? 0) ? 1 : -1)), o ??= i.moves.find((t) => t.type === "auctionCard" && e.cards.includes(t.source) !== i.selected.includes(t.source) && t.n === (e.cards.includes(t.source) ? 1 : -1)), o ??= i.moves.find((t) => t.type === "auctionPay" && t.n === e.paid && (t.alternate ?? 0) === e.food), o ??= i.moves.find((e) => e.type === "auctionBid" && e.n === r.auction.bid + 1)), o ??= i.moves.find((e) => e.type === "auctionPass");
		} else {
			let e = i.moves.map((e) => Dr.has(e.type) ? Mr(a, e) : {
				m: e,
				score: Fr(a, e)
			}).sort((e, t) => t.score - e.score);
			if (r.phase === "action" && r.round > 1 && !r.prompt && t.planning > 0) {
				let i = e.slice(0, 5);
				for (let t of [
					"population",
					"research",
					"take"
				]) {
					let n = e.find((e) => e.m.type === t);
					n && !i.includes(n) && i.push(n);
				}
				for (let e of i) if (e.next && !e.next.queue.length) {
					let i = e.next.players[n.rid], o = lt(e.next, i);
					e.m.type === "take" && x(e.m.card, r.config).kind === "leader" && i.civil > 0 && o.push({
						id: "",
						type: "leader",
						card: e.m.card,
						source: e.m.source,
						civil: 1
					});
					let s = {
						...a,
						s: e.next
					}, c = 0;
					for (let e of o) c = Math.max(c, Mr(s, e).score);
					e.score += c * t.planning;
				}
				e.sort((e, t) => t.score - e.score);
			}
			o = e[0].m;
		}
		return o ? { action: {
			type: "choose",
			id: o.id
		} } : null;
	};
}
//#endregion
//#region src/games/throughtheages/bot.ts
function zr(e, t, n) {
	let r = x(n, e.config);
	if (!r.units) return 0;
	let i = [
		"infantry",
		"cavalry",
		"artillery"
	].map((n) => t.technologies.filter((t) => x(t.id, e.config).category === n).reduce((e, t) => e + t.workers, 0));
	return t.leader === "genghis" && (i[1] += i[0]), t.leader === "zizka" && (i[2] += t.technologies.filter((t) => x(t.id, e.config).category === "farm").reduce((e, t) => e + t.workers, 0)), Math.min(...r.units.map((e, t) => e ? Math.floor(i[t] / e) : 99)) * r.tactic;
}
function Br(e, t, n, r) {
	let i = r.card ? x(r.card, e.config) : void 0, a = n.yellow > 16 ? 2 : n.yellow > 12 ? 3 : n.yellow > 8 ? 4 : n.yellow > 4 ? 5 : 7, o = (r.civil ?? 0) * 2 + (r.cost ?? 0) * .3 + (r.science ?? 0) * .2;
	switch (r.type) {
		case "end": return -20;
		case "endPolitics": return -5;
		case "take":
			if (!i) return -10;
			if (n.handCount >= n.ratings.civil - 1) return -25;
			if (i.kind === "technology") {
				if (Math.max(-1, ...n.technologies.filter((t) => x(t.id, e.config).category === i.category).map((t) => x(t.id, e.config).age)) >= i.age) return -30;
				let t = 10 + i.age * 2 - o;
				return i.category === "mine" && (t += n.ratings.ore < 6 ? 8 : 2), i.category === "farm" && (t += n.ratings.food < (n.yellow <= 8 ? 5 : 3) ? 9 : 0), i.category === "lab" && (t += n.ratings.science < 5 ? 8 : 0), (i.category === "temple" || i.category === "arena") && (t += n.discontent ? 10 : -4), t;
			}
			return i.kind === "government" ? x(n.government, e.config).age < i.age && n.science >= (i.revolution ?? 0) ? 15 - o : -25 : i.kind === "leader" ? !n.leader || x(n.leader, e.config).age < i.age ? 18 - o : -10 : i.kind === "wonder" ? n.ratings.ore >= 3 || e.round === 1 ? 7 - o : -15 : 5 - o;
		case "leader": return 30 - o;
		case "research":
		case "revolution": return 25 - o + (i?.kind === "government" ? 8 : i?.category === "mine" || i?.category === "lab" ? 5 : 0);
		case "build":
		case "upgrade":
		case "barbarossa": {
			let t = 10;
			return i?.category === "mine" && (t = n.ratings.ore < 10 ? 25 : 5), i?.category === "farm" && (t = n.ratings.food < Math.max(3, (n.yellow <= 4 ? 6 : n.yellow <= 8 ? 4 : 2) + 2) ? 28 : -8), i?.category === "lab" && (t = n.ratings.science < 10 ? 22 : 8), (i?.category === "temple" || i?.category === "arena") && (t = n.discontent >= n.pool ? 32 : 5), [
				"infantry",
				"cavalry",
				"artillery",
				"airforce"
			].includes(i?.category ?? "") && (t = n.ratings.strength <= Math.min(...e.players.map((e) => e.ratings.strength)) ? 23 : 5), ["library", "theater"].includes(i?.category ?? "") && (t = e.age >= 2 ? 24 : 10), r.type === "build" && n.pool <= n.discontent && (t -= 45), r.ability === "gutenberg" && (t += 6), t - o + (r.type === "upgrade" ? 3 : 0);
		}
		case "population": return n.pool <= Math.max(1, n.discontent) && n.food >= a ? 22 - o : -25;
		case "wonder": return 12 - o + (r.n ?? 1) * 3;
		case "action": return 13 - o + (r.resource === "food" && n.food < 4 || r.resource === "ore" && n.ore < 5 ? 8 : 0);
		case "liner": return n.pool <= n.discontent + 2 ? 40 : -25;
		case "louvre": return n.ore < 4 && e.age >= 3 ? 25 : -25;
		case "churchill": return r.extra === "culture" ? 30 : 15;
		case "hammurabi": return n.civil === 0 && e.round > 1 ? 5 : -30;
		case "destroy": return -100;
		case "tactic":
		case "copyTactic": {
			let t = e.tactics.find((e) => e.uid === n.tactic), i = t ? zr(e, n, t.id) : 0;
			return 4 * (zr(e, n, r.card) - i) - 1;
		}
		case "prepare": return 25 + i.age;
		case "columbus": return 50;
		case "fleming":
		case "olympics": return 50;
		case "catherine": return 20;
		case "alexander": return e.age >= 2 ? 15 : -10;
		case "aggression": return 7;
		case "declareWar": return n.ratings.strength > (e.players.find((e) => e.rid === r.target)?.ratings.strength ?? 0) + 5 ? 10 : -15;
		case "offer": return -15;
		case "cancelPact": return -15;
		case "auctionPass": return -5;
		case "auctionBid": return 35 - (r.n ?? 0) * .2;
		case "auctionUnit": return r.n === 1 ? 5 - (i?.age ?? 0) * 2 : -30;
		case "auctionCard":
		case "defenseCard": return r.n === 1 ? 8 + (i?.defense ?? i?.colonize ?? 0) : -30;
		case "auctionPay": return r.n && r.n > t.paid ? 3 - r.n : -30;
		case "defend": return 100;
		case "yield": return -10;
		case "sacrifice": return -2;
		case "skip": return 0;
		case "discard":
		case "discardCards": return -(i?.kind === "bonus" ? 10 : i?.kind === "event" || i?.kind === "territory" ? 5 : 1) - (i?.age ?? 0);
		case "decline": return 0;
		case "accept": return [
			"peaceTreaty3",
			"tourism3",
			"militaryAlliance3",
			"internationalTrade2",
			"openBorders1"
		].includes(r.card) ? 5 : -2;
		case "produce": return (i?.value ?? i?.age ?? 0) * 2;
		case "removeBlue": return -(i?.value ?? i?.age ?? 0);
		case "losePopulation": return r.card ? -(i?.age ?? 0) - (i?.category === "mine" ? 5 : 0) : 10;
		case "raid":
		case "infiltrateLeader":
		case "infiltrateWonder":
		case "annex":
		case "warSteal": return 5 + (i?.age ?? 0);
		case "homer": return 5;
		case "recoverCivil": return n.civil < n.ratings.civil ? 7 : -1;
		case "jobs": return n.ore > 2 ? 10 : -1;
		case "saladin": return r.extra === "civil" ? 5 : 1;
		case "agreementAccept":
		case "agreementTake":
		case "freeBuild":
		case "freeColony":
		case "unitedNations": return 20;
		case "gain": return r.resource === "ore" ? 10 : r.resource === "food" && n.food < 4 ? 15 : 5;
		default: return 3;
	}
}
var Vr = (e, t) => {
	let n = e.private, r = e.public, i = r.players.find((e) => e.rid === t.rid);
	return !n?.moves.length || !i ? null : { action: {
		type: "choose",
		id: n.moves.map((e, a) => ({
			m: e,
			score: Br(r, n, i, e) + (t.difficulty === "weak" ? (a * 17 + r.revision * 11) % 13 : 0)
		})).sort((e, t) => t.score - e.score)[0].m.id
	} };
};
function Hr(e = {}) {
	let t = Rr(e);
	return (e, n) => n.difficulty === "weak" ? Vr(e, n) : t(e, n);
}
var Ur = Hr(), Wr = (e, t, n) => {
	let r = e.type === "choose" ? t.private?.moves.find((t) => t.id === e.id) : void 0;
	return r ? Gn(n, r, t.public.config, (e) => e) : n("games.throughtheages.invalidAction");
};
//#endregion
//#region src/games/throughtheages/endgame-review.tsx
function Gr({ board: e, renderResult: t, ...n }) {
	let r = f(), [i, o] = l(!0), [u, d] = l(null), p = c(null), m = c(null), ee = c(null);
	a(() => {
		if (!u) return;
		ee.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => d(null), 5e3);
		return () => clearTimeout(e);
	}, [u]);
	let ne = (e) => {
		d(null), o(e), requestAnimationFrame(() => (e ? p : m).current?.focus({ preventScroll: !0 }));
	}, re = s(() => ({
		onPlayAgain: n.onPlayAgain && (() => d({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => d({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => d({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), h = {
		...n,
		...re
	};
	return /* @__PURE__ */ v("div", {
		className: "throughtheages-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ _("div", {
				className: "throughtheages-endgame-board",
				inert: i,
				children: e
			}),
			/* @__PURE__ */ _("div", {
				className: "throughtheages-endgame-overlay",
				hidden: !i,
				children: /* @__PURE__ */ v("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), ne(!1));
					},
					className: "throughtheages-endgame-panel",
					"aria-label": r("session.result.title"),
					children: [
						/* @__PURE__ */ v("header", {
							className: "throughtheages-endgame-heading",
							children: [/* @__PURE__ */ v("div", {
								className: "throughtheages-endgame-brand",
								children: [/* @__PURE__ */ _("span", {
									"aria-hidden": "true",
									children: $t.icon
								}), r($t.nameKey)]
							}), /* @__PURE__ */ _("button", {
								type: "button",
								ref: p,
								className: "btn-quiet",
								"aria-label": r("games.throughtheages.reviewHide"),
								title: r("games.throughtheages.reviewHide"),
								onClick: () => ne(!1),
								children: /* @__PURE__ */ _(ie, { size: 19 })
							})]
						}),
						/* @__PURE__ */ _("div", {
							className: "throughtheages-endgame-result",
							inert: u !== null,
							children: t(h)
						}),
						u && /* @__PURE__ */ v("div", {
							className: "throughtheages-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || d(null);
							},
							children: [/* @__PURE__ */ _("button", {
								type: "button",
								ref: ee,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = u.run;
									d(null), e();
								},
								children: r(u.label === "again" ? "games.throughtheages.reviewConfirmAgain" : "games.throughtheages.reviewConfirmLobby")
							}), /* @__PURE__ */ _("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									d(null), p.current?.focus({ preventScroll: !0 });
								},
								children: r("games.throughtheages.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ _("div", {
				className: "throughtheages-endgame-toolbar",
				hidden: i,
				children: /* @__PURE__ */ v("button", {
					type: "button",
					className: "btn-base",
					ref: m,
					onClick: () => ne(!0),
					children: [
						/* @__PURE__ */ _(ae, { size: 18 }),
						r("games.throughtheages.reviewShow"),
						/* @__PURE__ */ _(te, { size: 18 })
					]
				})
			})
		]
	});
}
function Kr({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: o, rows: s, renderRowExtra: c, summary: u, navigation: p, content: m, afterRanking: ee, scoreUnit: te, rankOf: re }) {
	let h = f(), ae = d((e) => e.locale), [oe, le] = l({}), ue = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? se(n, ae) : e;
	}, y = (t, n) => re?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), de = e.ranking.some((t) => e.scores?.[t] !== void 0), b = (t, n) => /* @__PURE__ */ v("div", {
		className: "throughtheages-score-identity",
		children: [
			/* @__PURE__ */ v("span", {
				className: "throughtheages-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ _("span", {
					"aria-label": h("games.throughtheages.reviewWinner"),
					children: "♛ "
				}), de && y(t, n)]
			}),
			/* @__PURE__ */ v("span", {
				className: "throughtheages-score-name",
				children: [ue(t), t === r && /* @__PURE__ */ _("small", { children: h("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ v("small", {
				className: "throughtheages-score-autopilot",
				children: [
					/* @__PURE__ */ _(ne, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), x = (t) => e.ranking.map((n) => /* @__PURE__ */ _("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ v("div", {
		className: "throughtheages-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ _(ce, {}),
			p,
			/* @__PURE__ */ v("div", {
				className: "throughtheages-score-body",
				children: [
					u && /* @__PURE__ */ _("div", {
						className: "throughtheages-score-summary",
						children: u
					}),
					i !== void 0 && /* @__PURE__ */ _("p", {
						className: "throughtheages-score-hints",
						children: h("session.hint.usedCount", { n: i })
					}),
					m ?? (s?.length ? /* @__PURE__ */ _("div", {
						className: "throughtheages-score-table-scroll",
						children: /* @__PURE__ */ v("table", {
							className: "throughtheages-score-table",
							"aria-label": h($t.nameKey),
							children: [
								/* @__PURE__ */ _("thead", { children: /* @__PURE__ */ v("tr", { children: [/* @__PURE__ */ _("th", { scope: "col" }), /* @__PURE__ */ _(g, { children: e.ranking.map((t, n) => /* @__PURE__ */ _("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: b(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ _("tbody", { children: s.map((e, t) => /* @__PURE__ */ v(n, { children: [/* @__PURE__ */ v("tr", { children: [/* @__PURE__ */ _("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ v("button", {
										type: "button",
										"aria-expanded": !!oe[t],
										onClick: () => le((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ _(ie, { size: 15 }), e.label]
									}) : e.label
								}), x(e)] }), oe[t] && e.details?.map((e, t) => /* @__PURE__ */ v("tr", {
									className: "throughtheages-score-sub",
									children: [/* @__PURE__ */ _("th", {
										scope: "row",
										children: e.label
									}), x(e)]
								}, t))] }, t)) }),
								de && /* @__PURE__ */ _("tfoot", { children: /* @__PURE__ */ v("tr", { children: [/* @__PURE__ */ _("th", {
									scope: "row",
									children: h("games.throughtheages.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ _("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ _("ol", {
						className: "throughtheages-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ v("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ v("div", {
								className: "throughtheages-score-rankline",
								children: [b(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ v("strong", {
									className: "throughtheages-score-points",
									children: [e.scores[t], te && /* @__PURE__ */ _("small", { children: te })]
								})]
							}), c?.(t)]
						}, t))
					})),
					ee,
					!!s?.length && c && /* @__PURE__ */ _("div", {
						className: "throughtheages-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ v("details", { children: [/* @__PURE__ */ _("summary", { children: ue(e) }), c(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ v("footer", {
				className: "throughtheages-score-actions",
				children: [
					o && /* @__PURE__ */ _("button", {
						type: "button",
						className: "btn-quiet",
						onClick: o,
						children: h("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ _("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: h("session.result.playAgain")
					}),
					!a && !o && /* @__PURE__ */ _("p", { children: h("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/throughtheages/endgame-scores.tsx
function qr(e) {
	let t = f(), n = e.public, r = [...new Set(n.players.flatMap((e) => Object.keys(e.final)))].map((e) => ({
		label: X(t, e, n.config),
		value: (t) => n.players.find((e) => e.rid === t)?.final[e] ?? 0
	}));
	return /* @__PURE__ */ _(Kr, {
		...e,
		renderRowExtra: void 0,
		rows: r
	});
}
//#endregion
//#region src/games/throughtheages/game-over.tsx
function Jr(e) {
	return /* @__PURE__ */ _(qr, { ...e });
}
function Yr(e) {
	return /* @__PURE__ */ _(Gr, {
		...e,
		board: /* @__PURE__ */ _(br, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ _(Jr, { ...e })
	});
}
//#endregion
//#region src/games/throughtheages/game-over-row.tsx
function Xr({ public: e, rid: t }) {
	let n = f(), r = e, i = r.players.find((e) => e.rid === t);
	return i ? /* @__PURE__ */ _("div", {
		className: "flex flex-wrap gap-x-4 gap-y-1 text-xs",
		children: Object.entries(i.final).map(([e, t]) => /* @__PURE__ */ _("span", { children: n("games.throughtheages.scoreFrom", {
			card: X(n, e, r.config),
			n: t
		}) }, e))
	}) : null;
}
//#endregion
//#region src/games/throughtheages/options.tsx
var Zr = {
	base: "games.throughtheages.base",
	expansion: "games.throughtheages.expansion",
	secret: "games.throughtheages.secret",
	public: "games.throughtheages.public"
};
function Qr({ value: e, onChange: t }) {
	let n = f(), r = en.safeParse(e), i = r.success ? r.data : en.parse(void 0);
	return /* @__PURE__ */ v("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ _(ue, {
				title: n("games.throughtheages.optLeaders"),
				children: Object.keys(Zr).map((e) => /* @__PURE__ */ _(le, {
					name: "tta-leaders",
					value: e,
					checked: i.leaders === e,
					label: n(Zr[e]),
					accent: $t.accent,
					onChange: () => t({
						...i,
						leaders: e
					})
				}, e))
			}),
			/* @__PURE__ */ _(y, {
				label: n("games.throughtheages.optRebalance"),
				checked: i.rebalance,
				accent: $t.accent,
				onChange: () => t({
					...i,
					rebalance: !i.rebalance
				})
			}),
			/* @__PURE__ */ _(y, {
				label: n("games.throughtheages.optMilitary"),
				checked: i.militaryExpansion,
				accent: $t.accent,
				onChange: () => t({
					...i,
					militaryExpansion: !i.militaryExpansion
				})
			}),
			/* @__PURE__ */ _(y, {
				label: n("games.throughtheages.optPublicHands"),
				checked: i.publicCivilHands,
				accent: $t.accent,
				onChange: () => t({
					...i,
					publicCivilHands: !i.publicCivilHands
				})
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/throughtheages/entry.tsx
var $r = {
	definition: cn,
	View: br,
	bot: Ur,
	describe: Wr,
	OverView: Yr,
	RowView: Xr,
	Options: Qr,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "历史巨轮：人类文明新篇章",
			desc: "发展文明，谱写历史；包含《新领袖与奇迹》扩展。",
			rules: "目标：\n2—4个文明从时代A发展至时代IV。文化点数最多的文明获胜，平手共享胜利。\n\n准备：\n· 选择领袖与奇迹组合、平衡调整和新军事牌；可分别启用。\n· 使用秘密混编或公开混编时，每个时代随机选择领袖与奇迹：2人游戏选择6位领袖和4座奇迹；3人或4人游戏选择7位领袖和5座奇迹。\n· 公开混编可查看入选名单；军事手牌和未揭示事件始终保密。\n\n回合流程：\n· 首轮依座次仅有1—4次内政行动，只能从牌列拿牌，随后进行生产。\n· 此后回合先补充牌列并结算自己发动的战争，再执行政治行动和行动阶段。\n· 政治行动可准备事件、发动侵略、宣战、提出或取消条约，或使用领袖能力。\n· 准备事件获得其等级的文化，并揭示当前事件；领土通过公开竞价分配。\n· 竞价赢家须牺牲实际军事单位，支付承诺的军事牌和资源。\n· 侵略须有更高军力；防守可弃军事牌，张数不超过军事行动总数。\n· 战争在发动者下回合开始结算，不使用军事奖励牌；最后一轮不能宣战。\n\n行动阶段：\n· 内政行动用于拿牌、增加人口、研发科技、任命领袖、建造和升级。\n· 军事行动用于建造、升级和拆除军事单位，以及打出或复制战术。\n· 牌列前5／中4／末4个位置拿牌分别需要1／2／3次内政行动。\n· 拿取奇迹牌时，每有1座已完成的奇迹，就须额外支付1次内政行动。同时只能建造1座奇迹。每个时代只能拿取1位领袖。\n· 手牌上限等于相应行动总数；行动阶段刚拿的行动牌不能立即使用。\n· 增加人口须付食物，工人先进入待业区；建造将待业工人放上科技。\n· 升级费用是两项科技分别折扣后的建造费用之差；城市建筑受政府上限限制。\n· 蓝色标记按科技面值存放食物和资源；临时专用资源自动优先花费。\n· 人口库越空，人口费用、消耗和幸福需求越高；蓝色库越空，腐败越高。\n· 战术按最大军力编组；有单位落后战术至少两个时代时，该军队过时。\n· 每架空军可令1支军队的战术军力翻倍。\n\n回合结束：\n· 首先弃置超过手牌上限的军事牌。不满工人的数量多于待业工人时，发生暴动，跳过本回合的生产。\n· 正常生产：获得科技与文化、支付腐败、生产食物、支付消耗、生产资源。\n· 支付消耗时，每缺少1单位食物，就损失4点文化。蓝色标记不足时，优先在面值较高的科技牌上生产食物或资源。\n· 按剩余军事行动抽至多3张军事牌，然后恢复行动。时代IV不再抽军事牌。\n\n时代与终局：\n· 时代I—III结束时，各文明从人口库移除2个黄色标记。\n· 比刚结束时代更早的手牌、领袖、未完成奇迹和条约过时。\n· 时代III牌库耗尽后完成最后一轮，保证各文明回合数相等。\n· 结算当前与未来事件中的全部时代III事件及领袖奖励，再比较文化。\n· 卡牌详情列出所选版本的效果与数值，具体效果优先于一般规则。",
			invalidAction: "此操作已不可用，请重新选择。",
			optRebalance: "平衡调整",
			optMilitary: "新军事牌与额外行动牌",
			optLeaders: "领袖与奇迹",
			optPublicHands: "公开内政手牌",
			base: "仅本体",
			expansion: "仅扩展",
			secret: "秘密混编",
			public: "公开混编",
			row: "牌列",
			civilization: "文明",
			hand: "内政手牌",
			militaryHand: "军事手牌",
			actions: "可用操作",
			details: "卡牌详情",
			reserves: "储备详情",
			reserveSummary: "查看储备：储存标记{{blue}}，人口储备{{yellow}}，待业工人{{pool}}，不满工人{{discontent}}。",
			storageRisk: "储存标记{{n}}，腐败损失{{loss}}资源。",
			populationRisk: "人口储备{{n}}，消耗{{loss}}食物，需要{{happy}}幸福。",
			happinessThreshold: "人口储备不高于{{n}}时，额外需要1幸福。",
			happinessDemand: "幸福需求 / 当前幸福",
			workerProduction: "每名工人每回合生产{{effects}}。",
			workerBenefits: "每名工人提供{{effects}}。",
			shortName: "历史巨轮",
			civilizations: "各玩家文明",
			you: "你",
			availableTarget: "可操作",
			chooseTargets: "在盘面选择目标",
			cancelSelection: "取消选择",
			viewCivilization: "查看{{name}}的文明",
			endActionShort: "结束行动",
			endPoliticsShort: "结束政治",
			emptySlot: "空牌位",
			handArea: "手边区域",
			civilDeck: "内政牌堆",
			militaryDeck: "军事牌堆",
			close: "关闭",
			all: "全部",
			noActions: "等待其他文明",
			waiting: "等待{{name}}",
			turn: "第{{round}}轮 · 时代{{age}}",
			lastRound: "最后一轮",
			population: "人口",
			yellowBank: "人口储备",
			blueBank: "储存标记",
			pool: "待业工人",
			culture: "文化",
			science: "科技",
			food: "食物",
			ore: "资源",
			strength: "军力",
			happy: "幸福",
			civil: "内政行动",
			military: "军事行动",
			colonize: "殖民力",
			urban: "城市建筑上限",
			armies: "军队",
			discontent: "不满工人",
			production: "产量",
			construction: "建造费用",
			researchCost: "科技费用",
			revolutionCost: "革命费用",
			stageCosts: "阶段费用",
			workers: "工人{{n}}",
			tokens: "蓝色标记{{n}}",
			stages: "已建造{{n}}阶段",
			ruined: "遗迹",
			homerMark: "荷马：幸福＋1",
			sunMark: "孙子：军力＋1",
			technology: "科技",
			government: "政府",
			leader: "领袖",
			wonder: "奇迹",
			action: "行动",
			event: "事件",
			territory: "领土",
			tactic: "战术",
			bonus: "军事奖励",
			aggression: "侵略",
			war: "战争",
			pact: "条约",
			farm: "农场",
			mine: "矿场",
			lab: "实验室",
			temple: "神庙",
			library: "图书馆",
			theater: "剧院",
			arena: "竞技场",
			infantry: "步兵",
			cavalry: "骑兵",
			artillery: "炮兵",
			airforce: "空军",
			law: "法律",
			warfare: "军事",
			exploration: "探索",
			commonTactics: "公共战术",
			exclusive: "{{name}}专有",
			events: "事件",
			eventCounts: "当前{{n}} · 未来{{future}}",
			selectedPool: "入选领袖与奇迹",
			history: "记录",
			knownEvents: "已知未来事件",
			peek: "当前事件顶牌",
			spy: "{{name}}的军事手牌",
			auction: "{{card}} · 最高出价{{n}}",
			selectedUnits: "已选单位{{n}} · 奖励牌{{cards}}",
			noBid: "尚无出价",
			costs: "{{civil}}内政 · {{military}}军事 · {{food}}食物 · {{ore}}资源 · {{science}}科技",
			discounted: "古腾堡专用行动",
			via: "使用{{card}}：{{action}}",
			summary: "{{name}} · 文化{{n}}",
			scoreFrom: "{{card}}：{{n}}文化",
			tradePayment: "贸易路线：以{{n}}{{resource}}替代支付",
			add: "加入",
			remove: "移回",
			sideA: "甲方",
			sideB: "乙方",
			extraCulture: "获得3文化",
			extraMilitary: "获得3临时军事科技和资源",
			extraCivil: "增加1次内政行动",
			extraStrength: "增加2军力",
			colonizationOffer: "当前殖民力{{n}} · 承诺支付{{paid}}资源",
			yellowBonus: "人口库标记＋{{n}}",
			blueBonus: "蓝色标记＋{{n}}",
			moves: {
				take: "拿取{{card}}",
				end: "结束行动阶段",
				population: "增加1人口",
				research: "研发{{card}}",
				revolution: "革命：改为{{card}}",
				leader: "任命{{card}}",
				build: "建造{{card}}",
				upgrade: "将{{source}}升级为{{card}}",
				destroy: "拆除{{card}}",
				wonder: "为{{name}}建造{{card}}的{{n}}个阶段",
				action: "使用{{card}}{{resource}}",
				hammurabi: "将1次军事行动改为内政行动",
				barbarossa: "增加人口并建造{{card}}",
				liner: "免费增加1人口",
				louvre: "移回卢浮宫标记，获得2资源",
				churchill: "丘吉尔：{{extra}}",
				tactic: "打出战术{{card}}",
				copyTactic: "复制战术{{card}}",
				endPolitics: "结束政治阶段",
				olympics: "举办奥运会，获得8文化",
				fleming: "查看{{name}}的军事手牌",
				prepare: "准备{{card}}",
				columbus: "直接殖民{{card}}",
				offer: "向{{name}}提出{{card}}（你为{{extra}}）",
				declareWar: "向{{name}}发动{{card}}",
				aggression: "对{{name}}发动{{card}}",
				cancelPact: "取消{{card}}",
				alexander: "移除亚历山大，增加1个人口库标记",
				catherine: "使用叶卡捷琳娜的政治能力",
				auctionPass: "退出竞价",
				auctionUnit: "{{extra}}1个{{card}}",
				auctionCard: "{{extra}}{{card}}",
				auctionPay: "支付{{n}}资源增加殖民力",
				auctionBid: "出价{{n}}殖民力",
				decline: "拒绝条约",
				accept: "接受条约",
				skip: "放弃此机会",
				sacrifice: "牺牲{{card}}",
				yield: "接受侵略结果",
				defend: "防御成功，弃置所选军事牌",
				defenseCard: "{{extra}}{{card}}",
				plunder: "拿取{{n}}食物，其余拿取资源",
				raid: "拆除对方的{{card}}",
				infiltrateLeader: "移除领袖{{card}}",
				infiltrateWonder: "移除未完成的{{card}}",
				annex: "拿取殖民地{{card}}",
				kidnap: "拿取对方手中的{{card}}",
				warScience: "拿取{{n}}科技",
				warSteal: "窃取特殊科技{{card}}",
				produce: "在{{card}}上生产1个蓝色标记",
				removeBlue: "从{{card}}移除1个蓝色标记",
				losePopulation: "失去{{card}}上的1人口",
				discardCards: "弃置{{card}}",
				discard: "弃置{{card}}",
				gainMixed: "获得{{n}}食物和{{cost}}资源",
				loseMixed: "失去{{n}}食物和{{cost}}资源",
				gain: "获得{{n}}{{resource}}",
				saladin: "萨拉丁：{{extra}}",
				recoverCivil: "收回1次内政行动",
				homer: "将荷马放到{{card}}下",
				jobs: "支付1资源，获得4文化",
				freeBuild: "免费建造{{card}}",
				planning: "选择{{card}}",
				demolish: "拆除{{name}}的{{card}}",
				ravages: "将{{card}}变为遗迹",
				loseColony: "失去殖民地{{card}}",
				freeColony: "直接殖民{{card}}",
				unitedNations: "结算{{card}}并保留该牌",
				agreementAccept: "放弃下次政治行动并拿牌",
				agreementTake: "拿取{{card}}",
				agreementEnd: "完成拿牌",
				negotiate: "转移3{{resource}}"
			},
			prompts: {
				action: "执行行动",
				politics: "执行政治行动",
				resolve: "结算中",
				discard: "弃置超限军事牌",
				done: "游戏结束",
				pact: "是否接受条约？",
				attackHimeji: "可牺牲单位增强进攻",
				defendHimeji: "可牺牲单位增强防御",
				defend: "选择军事牌防御，或接受侵略结果",
				plunder: "选择拿取的食物数量",
				raid: "选择要拆除的城市建筑",
				infiltrate: "选择移除领袖或未完成奇迹",
				annex: "选择殖民地",
				kidnap: "选择拿取的内政牌",
				warTechnology: "拿取科技点数或窃取特殊科技",
				produce: "蓝色标记不足，选择生产位置",
				removeBlue: "选择移除的蓝色标记",
				losePopulation: "选择失去的人口",
				discardCards: "选择弃置的军事牌",
				gainMixed: "选择获得的食物与资源",
				loseMixed: "选择失去的食物与资源",
				boudica: "选择布狄卡的收益",
				autonomous: "选择自治领土的收益",
				devMarkets: "选择食物或资源",
				saladin: "选择萨拉丁的能力",
				homer: "选择荷马的遗产",
				jobs: "是否支付资源获得文化？",
				devWarfare: "可免费建造1个战士",
				devReligion: "可免费建造1座神庙",
				devCivilization: "可执行1次费用减少1的文明行动",
				freedomMovement: "可将1位工人转移至另一项科技",
				planning: "选择1张时代A事件",
				demolish: "选择拆除的建筑或农矿",
				terrorism: "选择拆除对方的城市建筑",
				ravages: "选择变为遗迹的奇迹",
				loseColony: "选择失去的殖民地",
				freeColony: "可直接殖民手中的1张领土牌",
				unitedNations: "可结算手中1张时代III事件",
				agreementOffer: "是否放弃下次政治行动并拿牌？",
				agreement: "拿取总费用至多5次内政行动的牌",
				negotiations: "选择要转移的物资",
				auction: "选择单位和军事牌，然后出价或退出"
			},
			log: {
				action: "{{name}}使用了{{card}}",
				take: "{{name}}拿取了{{card}}",
				research: "{{name}}研发了{{card}}",
				revolution: "{{name}}革命改为{{card}}",
				leader: "{{name}}任命了{{card}}",
				population: "{{name}}增加了人口",
				build: "{{name}}建造了{{card}}",
				upgrade: "{{name}}升级为{{card}}",
				destroy: "{{name}}拆除了{{card}}",
				wonder: "{{name}}为{{card}}建造了{{n}}个阶段",
				complete: "{{name}}完成了{{card}}",
				prepare: "{{name}}准备了事件，获得{{n}}文化",
				aggression: "{{name}}对{{target}}发动{{card}}",
				declareWar: "{{name}}向{{target}}发动{{card}}",
				bid: "{{name}}为{{card}}出价{{n}}",
				colonize: "{{name}}殖民了{{card}}",
				event: "揭示事件：{{card}}",
				defend: "{{name}}成功防御了{{card}}",
				yield: "{{name}}承受了{{card}}的结果",
				warResult: "{{name}}在{{card}}中战胜{{target}}，军力差{{n}}",
				score: "{{name}}因{{card}}获得{{n}}文化",
				age: "时代{{n}}开始",
				uprising: "{{name}}发生暴动",
				corruption: "{{name}}支付{{n}}腐败",
				starvation: "{{name}}缺少{{n}}食物"
			},
			cards: {
				agriculture: {
					name: "农业",
					text: "",
					revised: ""
				},
				bronze: {
					name: "青铜",
					text: "",
					revised: ""
				},
				philosophy: {
					name: "哲学",
					text: "",
					revised: ""
				},
				religion: {
					name: "宗教",
					text: "",
					revised: ""
				},
				warriors: {
					name: "战士",
					text: "",
					revised: ""
				},
				irrigation: {
					name: "灌溉",
					text: "",
					revised: ""
				},
				selectiveBreeding: {
					name: "选择育种",
					text: "",
					revised: ""
				},
				mechanizedAgriculture: {
					name: "机械化农业",
					text: "",
					revised: ""
				},
				iron: {
					name: "铁矿",
					text: "",
					revised: ""
				},
				coal: {
					name: "煤矿",
					text: "",
					revised: ""
				},
				oil: {
					name: "石油",
					text: "",
					revised: ""
				},
				alchemy: {
					name: "炼金术",
					text: "",
					revised: ""
				},
				scientificMethod: {
					name: "科学方法",
					text: "",
					revised: ""
				},
				computers: {
					name: "计算机",
					text: "",
					revised: ""
				},
				theology: {
					name: "神学",
					text: "",
					revised: ""
				},
				organizedReligion: {
					name: "组织化宗教",
					text: "",
					revised: ""
				},
				printingPress: {
					name: "印刷术",
					text: "",
					revised: ""
				},
				journalism: {
					name: "新闻学",
					text: "",
					revised: ""
				},
				multimedia: {
					name: "多媒体",
					text: "",
					revised: ""
				},
				drama: {
					name: "戏剧",
					text: "",
					revised: ""
				},
				opera: {
					name: "歌剧",
					text: "",
					revised: ""
				},
				movies: {
					name: "电影",
					text: "",
					revised: ""
				},
				breadCircuses: {
					name: "面包与马戏",
					text: "",
					revised: ""
				},
				teamSports: {
					name: "团队运动",
					text: "",
					revised: ""
				},
				professionalSports: {
					name: "职业运动",
					text: "",
					revised: ""
				},
				swordsmen: {
					name: "剑士",
					text: "",
					revised: ""
				},
				riflemen: {
					name: "来复枪兵",
					text: "",
					revised: ""
				},
				modernInfantry: {
					name: "现代步兵",
					text: "",
					revised: ""
				},
				knights: {
					name: "骑士",
					text: "",
					revised: ""
				},
				cavalrymen: {
					name: "骑兵",
					text: "",
					revised: ""
				},
				tanks: {
					name: "坦克",
					text: "",
					revised: ""
				},
				cannon: {
					name: "火炮",
					text: "",
					revised: ""
				},
				rockets: {
					name: "火箭",
					text: "",
					revised: ""
				},
				airforces: {
					name: "空军",
					text: "",
					revised: ""
				},
				codeOfLaws: {
					name: "法典",
					text: "",
					revised: ""
				},
				justiceSystem: {
					name: "司法制度",
					text: "",
					revised: ""
				},
				civilService: {
					name: "公务制度",
					text: "",
					revised: ""
				},
				warfare: {
					name: "军事学",
					text: "",
					revised: ""
				},
				strategy: {
					name: "战略学",
					text: "",
					revised: ""
				},
				militaryTheory: {
					name: "军事理论",
					text: "",
					revised: ""
				},
				cartography: {
					name: "制图学",
					text: "",
					revised: ""
				},
				navigation: {
					name: "航海术",
					text: "",
					revised: ""
				},
				satellites: {
					name: "卫星",
					text: "",
					revised: ""
				},
				masonry: {
					name: "石工技术",
					text: "",
					revised: ""
				},
				architecture: {
					name: "建筑学",
					text: "",
					revised: ""
				},
				engineering: {
					name: "工程学",
					text: "",
					revised: ""
				},
				despotism: {
					name: "专制政体",
					text: "",
					revised: ""
				},
				monarchy: {
					name: "君主制",
					text: "",
					revised: ""
				},
				theocracy: {
					name: "神权制",
					text: "",
					revised: ""
				},
				constitutionalMonarchy: {
					name: "君主立宪制",
					text: "",
					revised: ""
				},
				republic: {
					name: "共和制",
					text: "",
					revised: ""
				},
				democracy: {
					name: "民主制",
					text: "",
					revised: ""
				},
				communism: {
					name: "共产主义",
					text: "",
					revised: ""
				},
				fundamentalism: {
					name: "原教旨主义",
					text: "",
					revised: ""
				},
				homer: {
					name: "荷马",
					text: "每回合可将额外1资源用于建造或升级军事单位。替换时可放到一座已完成奇迹下，使其永久获得1幸福，此时不收回内政行动。",
					revised: "每回合可将额外1资源用于建造或升级军事单位。替换时可放到一座已完成奇迹下，使其永久获得1幸福，此时不收回内政行动。"
				},
				moses: {
					name: "摩西",
					text: "增加人口的食物费用减少1。",
					revised: "增加人口的食物费用减少1。"
				},
				alexander: {
					name: "亚历山大大帝",
					text: "每个军事单位额外提供1军力。可用政治行动移除本领袖，向人口库加入1个黄色标记。",
					revised: "每个军事单位额外提供1军力。可用政治行动移除本领袖，向人口库加入1个黄色标记。"
				},
				hammurabi: {
					name: "汉谟拉比",
					text: "每回合可将1次军事行动作为内政行动使用。拿取领袖减少1次内政行动。",
					revised: "每回合可将1次军事行动作为内政行动使用。"
				},
				caesar: {
					name: "尤利乌斯·凯撒",
					text: "每局一次，在执行政治行动后可再执行1次政治行动。",
					revised: "每个政治阶段可执行至多2次政治行动。"
				},
				aristotle: {
					name: "亚里士多德",
					text: "每从牌列拿取1张科技牌，获得1科技点数。",
					revised: "每从牌列拿取1张科技牌，获得1科技点数。"
				},
				ashoka: {
					name: "阿育王",
					text: "手中内政牌至少有2种颜色时，额外生产1资源；至少3种颜色时，额外生产1资源和1食物。",
					revised: "手中内政牌至少有2种颜色时，额外生产1资源；至少3种颜色时，额外生产1资源和1食物。"
				},
				cleopatra: {
					name: "克娄巴特拉",
					text: "每回合有额外1资源用于奇迹或城市建筑。",
					revised: "每回合有额外1资源用于奇迹或城市建筑。"
				},
				sunTzu: {
					name: "孙子",
					text: "战术保持专有；回合结束时额外抽2张军事牌。离场时当前战术永久提供额外1军力。",
					revised: "战术保持专有；回合结束时额外抽2张军事牌。离场时当前战术永久提供额外1军力。"
				},
				confucius: {
					name: "孔子",
					text: "准备事件及离场时获得1科技点数。可将任何军事牌准备为事件；非事件牌揭示时，每个文明获得1科技点数。",
					revised: "准备事件及离场时获得1科技点数。可将任何军事牌准备为事件；非事件牌揭示时，每个文明获得1科技点数。"
				},
				boudica: {
					name: "布狄卡",
					text: "行动阶段开始时，若属于最弱的两个文明之一，获得2临时军事资源；否则获得1食物、1资源或1科技点数。",
					revised: "行动阶段开始时，若属于最弱的两个文明之一，获得2临时军事资源；否则获得1食物、1资源或1科技点数。"
				},
				hippocrates: {
					name: "希波克拉底",
					text: "回合开始时保存1个黄色标记，最多3个。时代I、II、III结束并失去人口库标记后，将其中1个加入人口库。",
					revised: "回合开始时保存1个黄色标记，最多3个。时代I、II、III结束并失去人口库标记后，将其中1个加入人口库。"
				},
				joan: {
					name: "圣女贞德",
					text: "神庙和政府的每个幸福提供1军力。政治阶段开始时可查看当前事件牌堆顶牌。",
					revised: "神庙和政府的每个幸福提供1军力。政治阶段开始时可查看当前事件牌堆顶牌。"
				},
				columbus: {
					name: "克里斯托弗·哥伦布",
					text: "可用政治行动移除本领袖，直接殖民手中的1张领土牌，无须牺牲单位。",
					revised: "可用政治行动移除本领袖，直接殖民手中的1张领土牌，无须牺牲单位。"
				},
				daVinci: {
					name: "列奥纳多·达·芬奇",
					text: "最高等级的实验室或图书馆额外生产等同其等级的科技。每研发1项科技获得1资源。",
					revised: "最高等级的实验室或图书馆额外生产等同其等级的科技。每研发1项科技获得1资源。"
				},
				michelangelo: {
					name: "米开朗琪罗",
					text: "神庙、剧院和奇迹每有1幸福，额外生产1文化。拿取奇迹时不因已完成奇迹增加行动费用。",
					revised: "城市建筑和奇迹每有1幸福，额外生产1文化。拿取奇迹不因已有奇迹增加行动费用，并获得1资源。"
				},
				barbarossa: {
					name: "腓特烈·巴巴罗萨",
					text: "可支付1次军事行动，增加人口并建造军事单位；食物和资源费用各减少1。",
					revised: "可支付1次军事行动，增加人口并建造军事单位；食物和资源费用各减少1。"
				},
				genghis: {
					name: "成吉思汗",
					text: "编组时步兵可视为骑兵。回合结束时，若属于军力最强的两个文明之一，获得3文化；两人局只比较最强，平手有利于自己。",
					revised: "编组时步兵可视为骑兵。回合结束时，若属于军力最强的两个文明之一，获得3文化；两人局只比较最强，平手有利于自己。"
				},
				isabella: {
					name: "卡斯蒂利亚的伊莎贝拉",
					text: "额外生产1资源，并增加2次军事行动。殖民时可支付1、3或6资源，获得1、2或3殖民力。",
					revised: "额外生产1资源，并增加2次军事行动。殖民时可支付1、3或6资源，获得1、2或3殖民力。"
				},
				nostradamus: {
					name: "诺查丹玛斯",
					text: "准备事件额外获得3文化。可查看之后由他人准备的事件。防御侵略及事件比较最弱文明时，额外提供3军力。",
					revised: "准备事件额外获得3文化。可查看之后由他人准备的事件。防御侵略及事件比较最弱文明时，额外提供3军力。"
				},
				zizka: {
					name: "扬·杰式卡",
					text: "编组时每座农场可视为时代A步兵或炮兵。每支军队生产1文化。",
					revised: "编组时每座农场可视为时代A步兵或炮兵。每支军队生产1文化。"
				},
				saladin: {
					name: "萨拉丁",
					text: "行动阶段后选择额外2军力或1次内政行动，持续至下次选择或本领袖离场。",
					revised: "行动阶段后选择额外2军力或1次内政行动，持续至下次选择或本领袖离场。"
				},
				eleanor: {
					name: "阿基坦的埃莉诺",
					text: "准备事件时抽2张军事牌。回合结束时每弃置1张超限军事牌获得1文化。被替换时收回3次内政行动。",
					revised: "准备事件时抽2张军事牌。回合结束时每弃置1张超限军事牌获得1文化。被替换时收回3次内政行动。"
				},
				gutenberg: {
					name: "约翰内斯·古腾堡",
					text: "每回合有1次专用内政行动，可拿取、研发、建造或升级实验室或图书馆，科技或资源费用减少1，并获得2文化。",
					revised: "每回合有1次专用内政行动，可拿取、研发、建造或升级实验室或图书馆，科技或资源费用减少1，并获得2文化。"
				},
				cook: {
					name: "詹姆斯·库克",
					text: "殖民时可弃置至多2张军事牌，每张提供1殖民力。第1块殖民地额外生产2文化，之后每块额外生产1文化。",
					revised: "殖民时可弃置至多2张军事牌，每张提供1殖民力。第1块殖民地额外生产2文化，之后每块额外生产1文化。"
				},
				robespierre: {
					name: "马克西米连·罗伯斯庇尔",
					text: "革命改为支付全部军事行动；革命时获得3文化。",
					revised: "革命改为支付全部军事行动；革命时获得3文化。"
				},
				bach: {
					name: "约翰·塞巴斯蒂安·巴赫",
					text: "每座剧院额外生产1文化；研发剧院科技减少2科技点数。每回合可将1座城市建筑升级为同级或更高等级的剧院。",
					revised: "每座剧院额外生产1文化；研发剧院科技减少2科技点数。每回合可将1座城市建筑升级为同级或更高等级的剧院。"
				},
				newton: {
					name: "艾萨克·牛顿",
					text: "最高等级的实验室或图书馆额外生产等同其等级的科技。每研发1项科技，收回1次内政行动。",
					revised: "最高等级的实验室或图书馆额外生产等同其等级的科技。每研发1项科技，收回1次内政行动。"
				},
				shakespeare: {
					name: "威廉·莎士比亚",
					text: "有图书馆时，剧院建造和科技研发费用各减少1；有剧院时图书馆同理。每对图书馆和剧院额外生产2文化。",
					revised: "有图书馆时，剧院建造减少2资源、研发减少3科技；有剧院时图书馆同理。每对图书馆和剧院额外生产2文化。"
				},
				napoleon: {
					name: "拿破仑·波拿巴",
					text: "每种不同类型的军事单位提供2军力。",
					revised: "每种不同类型的军事单位提供2军力。"
				},
				gaudi: {
					name: "安东尼·高迪",
					text: "研发城市建筑科技时，每拥有1种其他城市建筑类型，减少1科技点数。每种类型的最高等级城市建筑额外生产1文化。",
					revised: "研发城市建筑科技时，每拥有1种其他城市建筑类型，减少1科技点数。每种类型的最高等级城市建筑额外生产1文化。"
				},
				darwin: {
					name: "查尔斯·达尔文",
					text: "每座神庙少1幸福；每座实验室和图书馆额外生产1文化。拿取科技牌减少1次内政行动，最低仍为1次。",
					revised: "每座神庙少1幸福；每座实验室和图书馆额外生产1文化。拿取科技牌减少1次内政行动，最低仍为1次。"
				},
				watt: {
					name: "詹姆斯·瓦特",
					text: "农场和矿场的科技、建造费用按等级I／II／III减少1／2／3。离场时获得等同最佳农场或矿场产量的文化。",
					revised: "农场和矿场的科技、建造费用按等级I／II／III减少1／2／3。离场时获得等同最佳农场或矿场产量的文化。"
				},
				nobel: {
					name: "阿尔弗雷德·诺贝尔",
					text: "被替换时不收回内政行动，改为设立诺贝尔奖：此后任一文明在1回合内研发至少2项科技，获得4文化。",
					revised: "被替换时不收回内政行动，改为设立诺贝尔奖：此后任一文明在1回合内研发至少2项科技，获得4文化。"
				},
				catherine: {
					name: "叶卡捷琳娜大帝",
					text: "每局一次，可用政治行动使所有军力较低的文明失去1个人口库标记。若共失去至少1个，四人局至少2个，则你获得1个黄色标记。",
					revised: "每局一次，可用政治行动使所有军力较低的文明失去1个人口库标记。若共失去至少1个，四人局至少2个，则你获得1个黄色标记。"
				},
				mariaTheresa: {
					name: "玛丽亚·特蕾莎",
					text: "每增加或获得1人口，获得1科技和1文化。行动阶段开始时获得1临时军事资源；若属于最弱的两个文明之一，改为3。",
					revised: "每增加或获得1人口，获得1科技和1文化。行动阶段开始时获得1临时军事资源；若属于最弱的两个文明之一，改为3。"
				},
				chaplin: {
					name: "查理·卓别林",
					text: "你的一座最高等级剧院生产双倍文化。",
					revised: "你的一座最高等级剧院生产双倍文化。"
				},
				gandhi: {
					name: "圣雄甘地",
					text: "你不能发动侵略或战争。对手攻击你需要支付双倍军事行动。",
					revised: "你不能发动侵略或战争。对手攻击你需要额外支付3次军事行动。"
				},
				einstein: {
					name: "阿尔伯特·爱因斯坦",
					text: "最高等级的实验室或图书馆额外生产等同其等级的科技。每研发1项科技，获得3文化。",
					revised: "最高等级的实验室或图书馆额外生产等同其等级的科技。每研发1项科技，获得3文化。"
				},
				churchill: {
					name: "温斯顿·丘吉尔",
					text: "每回合选择：获得3文化；或获得3临时科技和3临时资源，用于军事单位科技及军事单位建造、升级。",
					revised: "每回合选择：获得3文化；或获得3临时科技和3临时资源，用于军事单位科技及军事单位建造、升级。"
				},
				billGates: {
					name: "比尔·盖茨",
					text: "等级I以上实验室按等级生产并储存资源。离场或游戏结束时，获得等同这部分额外产量的文化。",
					revised: "等级I以上实验室按等级生产并储存资源。离场或游戏结束时，获得等同这部分额外产量的文化。"
				},
				sidMeier: {
					name: "席德·梅尔",
					text: "每座实验室按等级生产文化，但少生产1科技。",
					revised: "每座实验室按等级生产文化，但少生产1科技。"
				},
				curie: {
					name: "玛丽·居里",
					text: "最高等级矿场按等级生产科技；最高等级实验室按等级提供军力；文化产量为上述两个等级中的较高者。",
					revised: "最高等级矿场按等级生产科技；最高等级实验室按等级提供军力；文化产量为上述两个等级中的较高者。"
				},
				jobs: {
					name: "史蒂夫·乔布斯",
					text: "最高等级实验室按等级提供幸福。每研发1项科技，可支付1资源获得4文化。",
					revised: "最高等级实验室按等级提供幸福。每研发1项科技，可支付1资源获得4文化。"
				},
				fleming: {
					name: "伊恩·弗莱明",
					text: "最佳图书馆和剧院各额外生产等同其等级的文化。政治行动前可查看1位对手的军事手牌，不能连续两回合选择同一对手。",
					revised: "最佳图书馆和剧院各额外生产等同其等级的文化。政治行动前可查看1位对手的军事手牌，不能连续两回合选择同一对手。"
				},
				dietrich: {
					name: "玛琳·黛德丽",
					text: "所有最高等级剧院额外提供1文化和1幸福。编组时，你的1个步兵、骑兵或炮兵单位可计算两次。",
					revised: "所有最高等级剧院额外提供1文化和1幸福。编组时，你的1个步兵、骑兵或炮兵单位可计算两次。"
				},
				mandela: {
					name: "纳尔逊·曼德拉",
					text: "若没有不满工人，拿取本牌多支付3次内政行动。回合结束时，每个多余幸福获得1文化。",
					revised: "若没有不满工人，拿取本牌多支付3次内政行动。回合结束时，每个多余幸福获得1文化。"
				},
				coubertin: {
					name: "皮埃尔·德·顾拜旦",
					text: "每座竞技场生产2文化。每局一次，可在政治行动前举办奥运会并获得8文化；直到下回合开始，发动侵略或战争的文明失去8文化。",
					revised: "每座竞技场生产2文化。每局一次，可在政治行动前举办奥运会并获得8文化；直到下回合开始，发动侵略或战争的文明失去8文化。"
				},
				alexandria: {
					name: "亚历山大图书馆",
					text: "内政手牌和军事手牌上限各增加1。",
					revised: "内政手牌和军事手牌上限各增加1。"
				},
				colossus: {
					name: "罗德岛巨像",
					text: "提供2军力和1殖民力。",
					revised: "提供2军力和1殖民力。时代II和III开始时，各抽3张该时代军事牌。"
				},
				pyramids: {
					name: "金字塔",
					text: "增加1次内政行动。",
					revised: "增加1次内政行动。"
				},
				hangingGardens: {
					name: "空中花园",
					text: "提供1文化产量和2幸福。",
					revised: "提供1文化产量和2幸福；完成时获得2食物。"
				},
				colosseum: {
					name: "罗马斗兽场",
					text: "研发步兵和骑兵科技时，科技费用减少等同其等级的数值，并获得2文化。",
					revised: "研发步兵和骑兵科技时，科技费用减少等同其等级的数值，并获得2文化。"
				},
				romanRoads: {
					name: "罗马道路",
					text: "时代I额外生产1资源；时代II提供1科技产量；之后提供2文化产量。",
					revised: "时代I额外生产1资源；时代II提供1科技产量；之后提供2文化产量。"
				},
				stonehenge: {
					name: "巨石阵",
					text: "建造每个阶段后，立即获得等同该阶段费用的文化。",
					revised: "建造每个阶段后，立即获得等同该阶段费用的文化。"
				},
				acropolis: {
					name: "雅典卫城",
					text: "城市建筑上限增加1；和平变更政府时，每座城市建筑减少1科技点数。",
					revised: "城市建筑上限增加1；和平变更政府时，每座城市建筑减少1科技点数。"
				},
				basilica: {
					name: "圣彼得大教堂",
					text: "每个原本提供幸福的其他卡牌或工人，额外提供1幸福。",
					revised: "每个原本提供幸福的其他卡牌或工人，额外提供1幸福。"
				},
				tajMahal: {
					name: "泰姬陵",
					text: "若本回合已替换领袖，拿取本奇迹少支付2次内政行动。",
					revised: "若本回合已替换领袖，拿取本奇迹少支付2次内政行动。"
				},
				carolina: {
					name: "查理大学",
					text: "生产2科技和1文化。",
					revised: "生产2科技和1文化。"
				},
				greatWall: {
					name: "长城",
					text: "每个步兵和炮兵单位额外提供1军力。",
					revised: "每个步兵和炮兵单位额外提供1军力。"
				},
				machuPicchu: {
					name: "马丘比丘",
					text: "最佳时代A或I农场和矿场各额外生产1个蓝色标记。",
					revised: "最佳时代A或I农场和矿场各额外生产1个蓝色标记。"
				},
				himeji: {
					name: "姬路城",
					text: "侵略或战争结算时可牺牲1个单位，临时增加等同该单位军力的数值；进攻额外获得3文化，防御额外增加3军力。",
					revised: "侵略或战争结算时可牺牲1个单位，临时增加等同该单位军力的数值；进攻额外获得3文化，防御额外增加3军力。"
				},
				forbiddenCity: {
					name: "紫禁城",
					text: "计算不满工人数时减少2，最低为0。",
					revised: "计算不满工人数时减少2，最低为0。"
				},
				silkRoad: {
					name: "丝绸之路",
					text: "每回合首张行动牌的各项收益增加1。首个阶段完成后即生效。",
					revised: "每回合首张行动牌的各项收益增加1。首个阶段完成后即生效。"
				},
				oceanLiner: {
					name: "远洋航线",
					text: "每个行动阶段可免费获得1人口。",
					revised: "每个行动阶段可免费获得1人口。"
				},
				kremlin: {
					name: "克里姆林宫",
					text: "增加1次内政行动和1次军事行动，生产2文化，但减少1幸福。",
					revised: "增加1次内政行动和1次军事行动，生产2文化，但减少1幸福。"
				},
				eiffel: {
					name: "埃菲尔铁塔",
					text: "生产4文化，提供1幸福。",
					revised: "生产4文化，提供1幸福。"
				},
				railroad: {
					name: "跨洲铁路",
					text: "最佳矿场额外生产1个蓝色标记。",
					revised: "最佳矿场额外生产1个蓝色标记。"
				},
				harvard: {
					name: "哈佛学院",
					text: "每回合可使用1张本回合刚拿取的行动牌。",
					revised: "每回合可使用1张本回合刚拿取的行动牌。"
				},
				suez: {
					name: "苏伊士运河",
					text: "完成时可直接殖民手中1张领土牌。每块殖民地额外生产1资源。",
					revised: "完成时可直接殖民手中1张领土牌。每块殖民地额外生产1资源。"
				},
				louvre: {
					name: "卢浮宫",
					text: "完成后保留3个蓝色标记，每个额外提供1文化产量。行动阶段可移回1个标记并获得2资源。",
					revised: "完成后保留3个蓝色标记，每个额外提供1文化产量。行动阶段可移回1个标记并获得2资源。"
				},
				liberty: {
					name: "自由女神像",
					text: "政府按等级生产文化。",
					revised: "政府按等级生产文化。"
				},
				hollywood: {
					name: "好莱坞",
					text: "立即获得等同剧院和图书馆文化总产量两倍的文化。",
					revised: "立即获得等同剧院和图书馆文化总产量两倍的文化。"
				},
				internet: {
					name: "互联网",
					text: "立即获得等同城市建筑文化、科技及军力产出总和的文化。",
					revised: "立即获得等同城市建筑文化、科技及军力产出总和的文化。"
				},
				spaceFlight: {
					name: "首次太空飞行",
					text: "立即按已研发科技的等级总和获得文化。",
					revised: "立即按已研发科技的等级总和获得文化。"
				},
				fastFood: {
					name: "快餐连锁店",
					text: "军事单位和城市建筑中每位工人获得1文化，农场和矿场中每位工人获得2文化。",
					revised: "军事单位和城市建筑中每位工人获得1文化，农场和矿场中每位工人获得2文化。"
				},
				empireState: {
					name: "帝国大厦",
					text: "分别比较科技、文化、军力、食物产量和资源产量。每项严格领先所有对手时，两／三／四人局分别获得7／8／9文化。",
					revised: "分别比较科技、文化、军力、食物产量和资源产量。每项严格领先所有对手时，两／三／四人局分别获得7／8／9文化。"
				},
				unitedNations: {
					name: "联合国",
					text: "按奇迹数量、特殊科技数量或城市建筑类型数量的最高值，每个获得4文化。可立即结算手中1张时代III事件，随后收回该牌。",
					revised: "按奇迹数量、特殊科技数量或城市建筑类型数量的最高值，每个获得4文化。可立即结算手中1张时代III事件，随后收回该牌。"
				},
				manhattan: {
					name: "曼哈顿计划",
					text: "立即获得等同科技产量的文化。",
					revised: "立即获得等同科技产量的文化。"
				},
				redCross: {
					name: "国际红十字会",
					text: "使用食物建造阶段，每阶段建造者获得6文化；其他玩家每回合可建造1阶段。完成后拥有者按全场殖民地数量获得文化。",
					revised: "使用食物建造阶段，每阶段建造者获得6文化；其他玩家每回合可建造1阶段。完成后拥有者按全场殖民地数量获得文化。"
				},
				urbanGrowth0: {
					name: "城市成长",
					text: "建造或升级1座城市建筑，减少1资源。",
					revised: "建造或升级1座城市建筑，减少1资源。"
				},
				richLand0: {
					name: "富饶土地",
					text: "建造或升级1座农场或矿场，减少1资源。",
					revised: "建造或升级1座农场或矿场，减少1资源。"
				},
				frugality0: {
					name: "节俭",
					text: "按通常费用增加1人口，之后获得1食物。",
					revised: "按通常费用增加1人口，之后获得1食物。"
				},
				engineeringGenius0: {
					name: "工程天才",
					text: "建造奇迹的1个阶段，减少2资源。",
					revised: "建造奇迹的1个阶段，减少2资源。"
				},
				stockpile0: {
					name: "储备物资",
					text: "获得1资源，再获得1食物。",
					revised: "获得1资源，再获得1食物。"
				},
				culturalHeritage0: {
					name: "文化遗产",
					text: "获得1科技和4文化。",
					revised: "获得1科技和4文化。"
				},
				patriotism0: {
					name: "爱国主义",
					text: "本回合获得1临时军事资源和1次临时军事行动。",
					revised: "本回合获得1临时军事资源和1次临时军事行动。"
				},
				urbanGrowth1: {
					name: "城市成长",
					text: "建造或升级1座城市建筑，减少2资源。",
					revised: "建造或升级1座城市建筑，减少2资源。"
				},
				richLand1: {
					name: "富饶土地",
					text: "建造或升级1座农场或矿场，减少2资源。",
					revised: "建造或升级1座农场或矿场，减少2资源。"
				},
				frugality1: {
					name: "节俭",
					text: "按通常费用增加1人口，之后获得2食物。",
					revised: "按通常费用增加1人口，之后获得2食物。"
				},
				engineeringGenius1: {
					name: "工程天才",
					text: "建造奇迹的1个阶段，减少3资源。",
					revised: "建造奇迹的1个阶段，减少3资源。"
				},
				culturalHeritage1: {
					name: "文化遗产",
					text: "获得2科技和2文化。",
					revised: "获得2科技和2文化。"
				},
				patriotism1: {
					name: "爱国主义",
					text: "本回合获得2临时军事资源和1次临时军事行动。",
					revised: "本回合获得2临时军事资源和1次临时军事行动。"
				},
				breakthrough1: {
					name: "科技突破",
					text: "研发1项科技，随后获得2科技点数。",
					revised: "研发1项科技，随后获得2科技点数。"
				},
				reserves1: {
					name: "储备",
					text: "获得2食物或2资源。",
					revised: "获得2食物或2资源。"
				},
				richLand2: {
					name: "富饶土地",
					text: "建造或升级1座农场或矿场，减少3资源。",
					revised: "建造或升级1座农场或矿场，减少3资源。"
				},
				frugality2: {
					name: "节俭",
					text: "按通常费用增加1人口，之后获得3食物。",
					revised: "按通常费用增加1人口，之后获得3食物。"
				},
				engineeringGenius2: {
					name: "工程天才",
					text: "建造奇迹的1个阶段，减少4资源。",
					revised: "建造奇迹的1个阶段，减少4资源。"
				},
				patriotism2: {
					name: "爱国主义",
					text: "本回合获得3临时军事资源和1次临时军事行动。",
					revised: "本回合获得3临时军事资源和1次临时军事行动。"
				},
				revolutionaryIdea2: {
					name: "革命思想",
					text: "获得4科技点数。",
					revised: "获得4科技点数。"
				},
				efficientUpgrade2: {
					name: "高效升级",
					text: "升级农场、矿场或城市建筑，减少3资源。",
					revised: "升级农场、矿场或城市建筑，减少3资源。"
				},
				breakthrough2: {
					name: "科技突破",
					text: "研发1项科技，随后获得3科技点数。",
					revised: "研发1项科技，随后获得3科技点数。"
				},
				reserves2: {
					name: "储备",
					text: "获得3食物或3资源。",
					revised: "获得3食物或3资源。"
				},
				nationalism2: {
					name: "民族主义浪潮",
					text: "每有1个军力更强的文明，两人／三人／四人局分别获得5／3／2临时军事资源。",
					revised: "每有1个军力更强的文明，两人／三人／四人局分别获得5／3／2临时军事资源。"
				},
				urbanGrowth3: {
					name: "城市成长",
					text: "建造或升级1座城市建筑，减少4资源。",
					revised: "建造或升级1座城市建筑，减少4资源。"
				},
				engineeringGenius3: {
					name: "工程天才",
					text: "建造奇迹的1个阶段，减少5资源。",
					revised: "建造奇迹的1个阶段，减少5资源。"
				},
				patriotism3: {
					name: "爱国主义",
					text: "本回合获得4临时军事资源和1次临时军事行动。",
					revised: "本回合获得4临时军事资源和1次临时军事行动。"
				},
				revolutionaryIdea3: {
					name: "革命思想",
					text: "获得6科技点数。",
					revised: "获得6科技点数。"
				},
				efficientUpgrade3: {
					name: "高效升级",
					text: "升级农场、矿场或城市建筑，减少4资源。",
					revised: "升级农场、矿场或城市建筑，减少4资源。"
				},
				reserves3: {
					name: "储备",
					text: "获得4食物或4资源。",
					revised: "获得4食物或4资源。"
				},
				militaryBuildUp3: {
					name: "军事扩张",
					text: "每有1个军力更强的文明，两人／三人／四人局分别获得8／5／3临时军事资源。",
					revised: "每有1个军力更强的文明，两人／三人／四人局分别获得8／5／3临时军事资源。"
				},
				endowment3: {
					name: "艺术赞助",
					text: "每有1个文化点数更多的文明，两人／三人／四人局分别获得6／3／2文化。",
					revised: "每有1个文化点数更多的文明，两人／三人／四人局分别获得6／3／2文化。"
				},
				richLand1Extra: {
					name: "富饶土地",
					text: "建造或升级1座农场或矿场，减少2资源。",
					revised: "建造或升级1座农场或矿场，减少2资源。"
				},
				urbanGrowth2Extra: {
					name: "城市成长",
					text: "建造或升级1座城市建筑，减少3资源。",
					revised: "建造或升级1座城市建筑，减少3资源。"
				},
				frugality2Extra: {
					name: "节俭",
					text: "按通常费用增加1人口，之后获得3食物。",
					revised: "按通常费用增加1人口，之后获得3食物。"
				},
				reserves3Extra: {
					name: "储备",
					text: "获得4食物或4资源。",
					revised: "获得4食物或4资源。"
				},
				patriotism3Extra: {
					name: "爱国主义",
					text: "本回合获得4临时军事资源和1次临时军事行动。",
					revised: "本回合获得4临时军事资源和1次临时军事行动。"
				},
				revolutionaryIdea3Extra: {
					name: "革命思想",
					text: "获得6科技点数。",
					revised: "获得6科技点数。"
				},
				legion: {
					name: "军团",
					text: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。",
					revised: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。"
				},
				fightingBand: {
					name: "战斗队",
					text: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。",
					revised: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。"
				},
				phalanx: {
					name: "方阵",
					text: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。",
					revised: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。"
				},
				heavyCavalry: {
					name: "重骑兵",
					text: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。",
					revised: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。"
				},
				medievalArmy: {
					name: "中世纪军队",
					text: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。",
					revised: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。"
				},
				napoleonicArmy: {
					name: "拿破仑军队",
					text: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。",
					revised: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。"
				},
				mobileArtillery: {
					name: "机动炮兵",
					text: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。",
					revised: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。"
				},
				fortifications: {
					name: "防御工事",
					text: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。",
					revised: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。"
				},
				conquistadors: {
					name: "征服者",
					text: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。",
					revised: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。"
				},
				defensiveArmy: {
					name: "防御军队",
					text: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。",
					revised: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。"
				},
				entrenchments: {
					name: "堑壕战",
					text: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。",
					revised: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。"
				},
				shockTroops: {
					name: "突击部队",
					text: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。",
					revised: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。"
				},
				mechanizedArmy: {
					name: "机械化军队",
					text: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。",
					revised: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。"
				},
				modernArmy: {
					name: "现代军队",
					text: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。",
					revised: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。"
				},
				hussars: {
					name: "骠骑兵",
					text: "每支军队的战术军力为2加上其中较低等级骑兵的等级。",
					revised: "每支军队的战术军力为2加上其中较低等级骑兵的等级。"
				},
				positionalArmy: {
					name: "阵地军队",
					text: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。",
					revised: "按所示单位组成军队；落后战术时代至少2个等级的单位会使该军队过时。"
				},
				bonus1: {
					name: "军事奖励",
					text: "防御侵略时提供2军力，或殖民时提供1殖民力。",
					revised: "防御侵略时提供2军力，或殖民时提供1殖民力。"
				},
				extraBonus1: {
					name: "军事奖励",
					text: "防御侵略时提供2军力，或殖民时提供1殖民力。",
					revised: "防御侵略时提供2军力，或殖民时提供1殖民力。"
				},
				bonus2: {
					name: "军事奖励",
					text: "防御侵略时提供4军力，或殖民时提供2殖民力。",
					revised: "防御侵略时提供4军力，或殖民时提供2殖民力。"
				},
				extraBonus2: {
					name: "军事奖励",
					text: "防御侵略时提供4军力，或殖民时提供2殖民力。",
					revised: "防御侵略时提供4军力，或殖民时提供2殖民力。"
				},
				bonus3: {
					name: "军事奖励",
					text: "防御侵略时提供6军力，或殖民时提供3殖民力。",
					revised: "防御侵略时提供6军力，或殖民时提供3殖民力。"
				},
				extraBonus3: {
					name: "军事奖励",
					text: "防御侵略时提供6军力，或殖民时提供3殖民力。",
					revised: "防御侵略时提供6军力，或殖民时提供3殖民力。"
				},
				devWarfare: {
					name: "军事发展",
					text: "可免费建造1个战士单位。",
					revised: "可免费建造1个战士单位。"
				},
				devReligion: {
					name: "宗教发展",
					text: "可免费建造1座时代A神庙。",
					revised: "可免费建造1座时代A神庙。"
				},
				devAgriculture: {
					name: "农业发展",
					text: "获得2食物。",
					revised: "获得2食物。"
				},
				devScience: {
					name: "科学发展",
					text: "获得2科技点数。",
					revised: "获得2科技点数。"
				},
				devCrafts: {
					name: "工艺发展",
					text: "获得2资源。",
					revised: "获得2资源。"
				},
				devSettlement: {
					name: "聚落发展",
					text: "获得1人口。",
					revised: "获得1人口。"
				},
				devPolitics: {
					name: "政治发展",
					text: "抽3张军事牌。",
					revised: "抽3张军事牌。"
				},
				devTrade: {
					name: "商路发展",
					text: "获得1科技、1食物和1资源。",
					revised: "获得1科技、1食物和1资源。"
				},
				devCivilization: {
					name: "文明发展",
					text: "增加人口、建造农场／矿场／城市建筑或研发科技，无须行动，费用减少1。",
					revised: "增加人口、建造农场／矿场／城市建筑或研发科技，无须行动，费用减少1。"
				},
				devMarkets: {
					name: "市场发展",
					text: "选择获得2食物或2资源。",
					revised: "选择获得2食物或2资源。"
				},
				culturalInfluence: {
					name: "文化影响",
					text: "每个文明按文化产量获得文化。",
					revised: "每个文明按文化产量获得文化。"
				},
				barbarians: {
					name: "蛮族",
					text: "文化最多的文明若属于最弱的两个文明之一，失去1人口。",
					revised: "文化最多的文明若属于最弱的两个文明之一，失去1人口。"
				},
				foray: {
					name: "突袭远征",
					text: "最强的两个文明各获得合计3食物或资源。",
					revised: "最强的两个文明各获得合计3食物或资源。"
				},
				raiders: {
					name: "掠夺者",
					text: "最弱的两个文明各失去合计2食物或资源。",
					revised: "最弱的两个文明各失去合计2食物或资源。"
				},
				epidemic: {
					name: "瘟疫",
					text: "每个文明失去1人口。",
					revised: "每个文明失去1人口。"
				},
				rats: {
					name: "鼠患",
					text: "每个文明失去全部储存的食物。",
					revised: "每个文明失去全部储存的食物。"
				},
				scientificBreakthrough: {
					name: "科学突破",
					text: "每个文明按科技产量获得科技点数。",
					revised: "每个文明按科技产量获得科技点数。"
				},
				newDeposits: {
					name: "新矿藏",
					text: "每个文明立即生产资源，不计算腐败。",
					revised: "每个文明立即生产资源，不计算腐败。"
				},
				goodHarvest: {
					name: "丰收",
					text: "每个文明立即生产食物，不计算消耗。",
					revised: "每个文明立即生产食物，不计算消耗。"
				},
				rebellion: {
					name: "叛乱",
					text: "每个文明每有1个不满工人，失去2次内政行动。",
					revised: "每个文明每有1个不满工人，失去2次内政行动。"
				},
				territorialDispute: {
					name: "领土争端",
					text: "最弱文明拆除1座农场、矿场或城市建筑；最强文明获得3资源。",
					revised: "最弱文明拆除1座农场、矿场或城市建筑；最强文明获得3资源。"
				},
				crusades: {
					name: "十字军东征",
					text: "最强文明获得4文化，最弱文明失去4文化。",
					revised: "最强文明获得4文化，最弱文明失去4文化。"
				},
				famine: {
					name: "饥荒",
					text: "最弱文明失去1人口。",
					revised: "最弱文明失去1人口。"
				},
				enslavement: {
					name: "奴役",
					text: "最强文明从最弱文明的人口库拿取1个黄色标记。",
					revised: "最强文明从最弱文明的人口库拿取1个黄色标记。"
				},
				immigration: {
					name: "移民涌入",
					text: "幸福最多的所有文明各获得1人口。",
					revised: "幸福最多的所有文明各获得1人口。"
				},
				popularization: {
					name: "科学普及",
					text: "每个文明按科技产量获得文化。",
					revised: "每个文明按科技产量获得文化。"
				},
				politicsStrength: {
					name: "强权政治",
					text: "最强文明抽5张军事牌；最弱文明弃3张军事牌。时代IV改为文化得失。",
					revised: "最强文明抽5张军事牌；最弱文明弃3张军事牌。时代IV改为文化得失。"
				},
				independence: {
					name: "独立宣言",
					text: "最弱文明失去其选择的1块殖民地。",
					revised: "最弱文明失去其选择的1块殖民地。"
				},
				emigration: {
					name: "人口外流",
					text: "每个文明失去等同不满工人数一半的人口，向上取整。",
					revised: "每个文明失去等同不满工人数一半的人口，向上取整。"
				},
				crimeWave: {
					name: "犯罪浪潮",
					text: "最弱的两个文明各失去3文化和1个蓝色标记。",
					revised: "最弱的两个文明各失去3文化和1个蓝色标记。"
				},
				nationalPride: {
					name: "民族自豪",
					text: "文化点数最多的文明获得5文化。",
					revised: "文化点数最多的文明获得5文化。"
				},
				civilUnrest: {
					name: "社会动荡",
					text: "每个文明每有1个不满工人，失去4文化；不满工人最多的所有文明再失去1个蓝色标记。",
					revised: "每个文明每有1个不满工人，失去4文化；不满工人最多的所有文明再失去1个蓝色标记。"
				},
				terrorism: {
					name: "恐怖主义",
					text: "文化最少的文明从每个其他文明拆除1座城市建筑。",
					revised: "文化最少的文明从每个其他文明拆除1座城市建筑。"
				},
				ravages: {
					name: "岁月摧残",
					text: "每个文明选择1座时代A或I的已完成奇迹，效果改为生产2文化。",
					revised: "每个文明选择1座时代A或I的已完成奇迹，效果改为生产2文化。"
				},
				prosperity: {
					name: "繁荣",
					text: "每个文明按幸福数量获得资源，最多8。",
					revised: "每个文明按幸福数量获得资源，最多8。"
				},
				iconoclasm: {
					name: "破除偶像",
					text: "所有非当前时代的领袖离场。",
					revised: "所有非当前时代的领袖离场。"
				},
				economicProgress: {
					name: "经济进步",
					text: "每个文明依次计算腐败、生产食物、消耗食物和生产资源。",
					revised: "每个文明依次计算腐败、生产食物、消耗食物和生产资源。"
				},
				internationalAgreement: {
					name: "国际协定",
					text: "最强文明可放弃下次政治行动，免费拿取总费用至多5次内政行动的内政牌，然后补充牌列。",
					revised: "最强文明可放弃下次政治行动，免费拿取总费用至多5次内政行动的内政牌，然后补充牌列。"
				},
				colonialism: {
					name: "殖民主义",
					text: "最强的两个文明各获得6文化。",
					revised: "最强的两个文明各获得6文化。"
				},
				happiness: {
					name: "幸福生活",
					text: "最强文明获得3文化和1人口；最弱文明失去3文化和1人口。",
					revised: "最强文明获得3文化和1人口；最弱文明失去3文化和1人口。"
				},
				impactPopulation: {
					name: "人口的影响",
					text: "每超过10名满意工人，获得2文化。",
					revised: "每超过10名满意工人，获得2文化。"
				},
				impactWonders: {
					name: "奇迹的影响",
					text: "时代A／I／II／III的每座已完成奇迹分别获得5／4／3／2文化。",
					revised: "时代A／I／II／III的每座已完成奇迹分别获得5／4／3／2文化。"
				},
				impactColonies: {
					name: "殖民地的影响",
					text: "每块殖民地获得3文化。",
					revised: "每块殖民地获得3文化。"
				},
				impactCompetition: {
					name: "竞争的影响",
					text: "每个军事单位和竞技场按等级获得文化。",
					revised: "每个军事单位和竞技场按等级获得文化。"
				},
				impactAgriculture: {
					name: "农业的影响",
					text: "获得等同食物产量的文化；若产量超过消耗，再获得4文化。",
					revised: "获得等同食物产量的文化；若产量超过消耗，再获得4文化。"
				},
				impactProgress: {
					name: "进步的影响",
					text: "政府和特殊科技的等级总和乘以2，获得相应文化。",
					revised: "政府和特殊科技的等级总和乘以2，获得相应文化。"
				},
				impactIndustry: {
					name: "工业的影响",
					text: "按矿场的资源产量获得文化，不计其他来源。",
					revised: "按矿场的资源产量获得文化，不计其他来源。"
				},
				impactScience: {
					name: "科学的影响",
					text: "按科技产量排名，四人15／10／5／0，三人14／7／0，两人10／0文化。",
					revised: "按科技产量排名，四人15／10／5／0，三人14／7／0，两人10／0文化。"
				},
				impactTechnology: {
					name: "科技的影响",
					text: "每项时代III科技获得4文化。",
					revised: "每项时代III科技获得4文化。"
				},
				impactHappiness: {
					name: "幸福的影响",
					text: "每个幸福获得2文化，最多16；每个不满工人扣除2文化。",
					revised: "每个幸福获得2文化，最多16；每个不满工人扣除2文化。"
				},
				impactArchitecture: {
					name: "建筑的影响",
					text: "按城市建筑的等级总和获得文化。",
					revised: "按城市建筑的等级总和获得文化。"
				},
				impactStrength: {
					name: "军力的影响",
					text: "按军力排名，四人15／10／5／0，三人14／7／0，两人10／0文化。",
					revised: "按军力排名，四人15／10／5／0，三人14／7／0，两人10／0文化。"
				},
				impactGovernment: {
					name: "政府的影响",
					text: "每次内政行动获得2文化，每次军事行动获得1文化，按行动总数计算。",
					revised: "每次内政行动获得2文化，每次军事行动获得1文化，按行动总数计算。"
				},
				impactVariety: {
					name: "多样性的影响",
					text: "每种军事单位类型、城市建筑类型及每项特殊科技获得2文化。",
					revised: "每种军事单位类型、城市建筑类型及每项特殊科技获得2文化。"
				},
				impactBalance: {
					name: "平衡的影响",
					text: "科技、文化、食物、资源四种产量的最低值乘以2，获得相应文化。",
					revised: "科技、文化、食物、资源四种产量的最低值乘以2，获得相应文化。"
				},
				devPlanning: {
					name: "规划发展",
					text: "从未使用的时代A事件中随机揭示3张，每个文明选择其中1张并对自己结算。",
					revised: "从未使用的时代A事件中随机揭示3张，每个文明选择其中1张并对自己结算。"
				},
				darkAges: {
					name: "黑暗时代",
					text: "科技点数超过4的部分失去一半，向上取整。",
					revised: "科技点数超过4的部分失去一半，向上取整。"
				},
				knowledgeAncients: {
					name: "先民的知识",
					text: "每座已完成奇迹获得1科技；有未完成奇迹则获得1资源。时代A奇迹收益翻倍。",
					revised: "每座已完成奇迹获得1科技；有未完成奇迹则获得1资源。时代A奇迹收益翻倍。"
				},
				callArms: {
					name: "征召入伍",
					text: "最弱文明失去2次内政行动，次弱失去1次，并按实际失去次数抽军事牌；两人局只影响最弱。",
					revised: "最弱文明失去2次内政行动，次弱失去1次，并按实际失去次数抽军事牌；两人局只影响最弱。"
				},
				armsIndustry: {
					name: "军工产业",
					text: "分别比较步兵、骑兵、炮兵科技等级；每项最高或并列最高者获得2资源。",
					revised: "分别比较步兵、骑兵、炮兵科技等级；每项最高或并列最高者获得2资源。"
				},
				freedomMovement: {
					name: "自由流动",
					text: "可将1位工人从一张科技牌移至另一张，若新费用较高则支付差额。",
					revised: "可将1位工人从一张科技牌移至另一张，若新费用较高则支付差额。"
				},
				internationalNegotiations: {
					name: "国际谈判",
					text: "揭示者选择科技、食物或资源；最强文明从最弱文明拿取3，目标必须拥有至少3。",
					revised: "揭示者选择科技、食物或资源；最强文明从最弱文明拿取3，目标必须拥有至少3。"
				},
				impactEconomy: {
					name: "经济的影响",
					text: "农场矿场数、城市建筑数、军事单位数三者取最低，每个获得4文化。",
					revised: "农场矿场数、城市建筑数、军事单位数三者取最低，每个获得4文化。"
				},
				impactCulture: {
					name: "文化的影响",
					text: "按文化产量排名，四人15／10／5／0，三人14／7／0，两人10／0文化。",
					revised: "按文化产量排名，四人15／10／5／0，三人14／7／0，两人10／0文化。"
				},
				developed1: {
					name: "发达领土",
					text: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。",
					revised: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。"
				},
				vast1: {
					name: "广阔领土",
					text: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。",
					revised: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。"
				},
				wealthy1: {
					name: "富裕领土",
					text: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。",
					revised: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。"
				},
				inhabited1: {
					name: "宜居领土",
					text: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。",
					revised: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。"
				},
				historic1: {
					name: "历史领土",
					text: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。",
					revised: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。"
				},
				strategic1: {
					name: "战略领土",
					text: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。",
					revised: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。"
				},
				developed2: {
					name: "发达领土",
					text: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。",
					revised: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。"
				},
				vast2: {
					name: "广阔领土",
					text: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。",
					revised: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。"
				},
				wealthy2: {
					name: "富裕领土",
					text: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。",
					revised: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。"
				},
				inhabited2: {
					name: "宜居领土",
					text: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。",
					revised: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。"
				},
				historic2: {
					name: "历史领土",
					text: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。",
					revised: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。"
				},
				strategic2: {
					name: "战略领土",
					text: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。",
					revised: "殖民后先获得永久奖励，再获得卡牌列出的即时奖励。"
				},
				autonomous2: {
					name: "自治领土",
					text: "殖民后获得2个人口库标记和2个蓝色标记，并选择获得4科技、5资源、6食物或7文化。",
					revised: "殖民后获得2个人口库标记和2个蓝色标记，并选择获得4科技、5资源、6食物或7文化。"
				},
				plunder1: {
					name: "侵略：劫掠",
					text: "从对手拿取合计至多3食物和资源。",
					revised: "从对手拿取合计至多3食物和资源。"
				},
				raid1: {
					name: "侵略：袭击",
					text: "拆除符合时代限制的对手城市建筑，获得其印刷费用总和的一半资源，向上取整。",
					revised: "拆除符合时代限制的对手城市建筑，获得其印刷费用总和的一半资源，向上取整。"
				},
				plunder2: {
					name: "侵略：劫掠",
					text: "从对手拿取合计至多5食物和资源。",
					revised: "从对手拿取合计至多5食物和资源。"
				},
				raid2: {
					name: "侵略：袭击",
					text: "拆除符合时代限制的对手城市建筑，获得其印刷费用总和的一半资源，向上取整。",
					revised: "拆除符合时代限制的对手城市建筑，获得其印刷费用总和的一半资源，向上取整。"
				},
				plunder3: {
					name: "侵略：劫掠",
					text: "从对手拿取合计至多7食物和资源。",
					revised: "从对手拿取合计至多7食物和资源。"
				},
				raid3: {
					name: "侵略：袭击",
					text: "拆除符合时代限制的对手城市建筑，获得其印刷费用总和的一半资源，向上取整。",
					revised: "拆除符合时代限制的对手城市建筑，获得其印刷费用总和的一半资源，向上取整。"
				},
				enslave1: {
					name: "侵略：奴役",
					text: "对手失去1人口，你获得2食物和2资源。",
					revised: "对手失去1人口，你获得2食物和2资源。"
				},
				spy2: {
					name: "侵略：间谍",
					text: "从对手拿取至多5科技点数。",
					revised: "从对手拿取至多5科技点数。"
				},
				infiltrate2: {
					name: "侵略：渗透",
					text: "移除对手领袖或未完成奇迹，按其等级的3倍获得科技。",
					revised: "移除对手领袖或未完成奇迹，按其等级的3倍获得科技。"
				},
				annex2: {
					name: "侵略：兼并",
					text: "拿取对手1块殖民地，只转移永久效果。",
					revised: "拿取对手1块殖民地，只转移永久效果。"
				},
				intervention3: {
					name: "侵略：武装干涉",
					text: "从对手拿取至多7文化。",
					revised: "从对手拿取至多7文化。"
				},
				kidnap1: {
					name: "侵略：绑架",
					text: "按拿牌限制拿取对手手中1张内政牌；若本回合使用，获得3文化。",
					revised: "按拿牌限制拿取对手手中1张内政牌；若本回合使用，获得3文化。"
				},
				occupy3: {
					name: "侵略：占领",
					text: "从对手各拿取至多3资源、3食物、3科技和3文化。",
					revised: "从对手各拿取至多3资源、3食物、3科技和3文化。"
				},
				warTerritory2: {
					name: "领土战争",
					text: "胜者拿取1个人口库标记，军力差每满5再拿取1个。",
					revised: "胜者拿取1个人口库标记，军力差每满5再拿取1个。"
				},
				warTechnology2: {
					name: "科技战争",
					text: "按军力差拿取科技点数，也可按印刷科技费用改为窃取特殊科技。",
					revised: "按军力差拿取科技点数，也可按印刷科技费用改为窃取特殊科技。"
				},
				warCulture3: {
					name: "文化战争",
					text: "胜者从败者拿取等同军力差加5的文化。",
					revised: "胜者从败者拿取等同军力差加5的文化。"
				},
				hybridWar3: {
					name: "混合战争",
					text: "战争结算前双方各减少2幸福；胜者按军力差拿取文化。",
					revised: "战争结算前双方各减少2幸福；胜者按军力差拿取文化。"
				},
				tradeRoutes1: {
					name: "商路协定",
					text: "甲方可将1食物作为1资源支付，乙方可将1资源作为1食物支付。",
					revised: "甲方可将1食物作为1资源支付，乙方可将1资源作为1食物支付。"
				},
				openBorders1: {
					name: "开放边境协定",
					text: "双方各增加1次军事行动；攻击另一方时额外获得2军力。",
					revised: "双方各增加1次军事行动；攻击另一方时额外获得2军力。"
				},
				protection2: {
					name: "保护承诺",
					text: "甲方多生产1文化；乙方获得4军力但少生产1文化。相互攻击时终止。",
					revised: "甲方多生产1文化；乙方获得4军力但少生产1文化。相互攻击时终止。"
				},
				internationalTrade2: {
					name: "国际贸易协定",
					text: "甲方多生产1资源；乙方多生产1食物。",
					revised: "甲方多生产1资源；乙方多生产1食物。"
				},
				scientificCooperation2: {
					name: "科研合作",
					text: "一方研发科技少支付2科技，另一方须支付1科技。",
					revised: "一方研发科技少支付2科技，另一方须支付1科技。"
				},
				supremacy2: {
					name: "承认霸权",
					text: "双方不能相互攻击；甲方多生产1资源，乙方少生产1资源。",
					revised: "双方不能相互攻击；甲方多生产1资源，乙方少生产1资源。"
				},
				militaryAlliance3: {
					name: "军事同盟",
					text: "双方各获得3军力；相互攻击时终止。",
					revised: "双方各获得3军力；相互攻击时终止。"
				},
				tourism3: {
					name: "国际旅游",
					text: "按另一方已完成奇迹数量，多生产相同数量文化。",
					revised: "按另一方已完成奇迹数量，多生产相同数量文化。"
				},
				peaceTreaty3: {
					name: "和平条约",
					text: "双方不能相互攻击；各多生产1文化。",
					revised: "双方不能相互攻击；各多生产1文化。"
				},
				sovereignty3: {
					name: "丧失主权",
					text: "双方不能相互攻击；甲方多生产2文化，乙方少生产2文化；无人能向乙方宣战。",
					revised: "双方不能相互攻击；甲方多生产2文化，乙方少生产2文化；无人能向乙方宣战。"
				},
				navalTrade1: {
					name: "海运贸易协定",
					text: "甲方增加1幸福并减少1蓝色标记；乙方增加2个蓝色标记。",
					revised: "甲方增加1幸福并减少1蓝色标记；乙方增加2个蓝色标记。"
				}
			}
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Through the Ages: A New Story of Civilization",
			desc: "Build a civilization through history, including New Leaders and Wonders.",
			rules: "Goal:\nDevelop 2–4 civilizations from Age A to Age IV. Most culture wins; ties share victory.\n\nSetup:\n· Choose leaders and wonders, rebalanced cards, and new military cards independently.\n· Mixed sets select 6 leaders and 4 wonders per age for two players; 7 and 5 for three or four.\n· Public mixes reveal the selected lists. Military hands and unrevealed events remain secret.\n\nTurn sequence:\n· Round one gives 1–4 civil actions by seating order, used only to take cards, then production.\n· Later turns replenish the row, resolve wars you declared, then have politics and actions.\n· Politics: prepare an event, attack, declare war, offer or cancel a pact, or use a leader.\n· Preparing an event scores its level in culture and reveals a current event.\n· Territories are auctioned. The winner sacrifices real units and pays committed cards and resources.\n· Aggressions need greater strength. Defense may discard cards up to your military action total.\n· Wars resolve next turn without bonus cards. No wars may be declared in the final round.\n\nAction Phase:\n· Civil actions take cards, increase population, develop technologies, appoint leaders, and build or upgrade.\n· Military actions manage units and play or copy tactics.\n· Taking cards from the first 5, next 4, or last 4 row spaces costs 1, 2, or 3 civil actions.\n· Wonders also cost an action per completed wonder. Build only one at a time and take one leader per age.\n· Hand limits equal action totals. Action cards taken during your Action Phase cannot be played immediately.\n· Pay food to move population to your worker pool. Building places a worker on a technology.\n· Upgrading pays the difference between separately discounted costs. Urban limits apply per type.\n· Blue tokens store food and resources at technology values. Spend applicable temporary resources first.\n· Emptying yellow banks increases population costs, consumption, and happiness needs; emptying blue banks increases corruption.\n· Tactics maximize strength. A unit two ages older than its tactic makes its army antiquated.\n· Each air force doubles one army’s tactical strength.\n\nEnd of turn:\n· Discard excess military cards. More discontent than unused workers causes an uprising, skipping production.\n· Otherwise score science and culture, pay corruption, produce food, consume, then produce resources.\n· Each missing food loses 4 culture. With too few blue tokens, produce on higher-value technologies first.\n· Draw up to 3 military cards for unspent military actions, then recover actions. Age IV stops military draws.\n\nAges and ending:\n· At the end of Ages I–III, remove 2 yellow bank tokens per civilization.\n· Hands, leaders, unfinished wonders, and pacts older than the age that just ended become obsolete.\n· Exhausting Age III starts the final round. All civilizations receive equal turns.\n· Evaluate all Age III current and future events and final leader bonuses, then compare culture.\n· Card details show the selected version’s effects and override general rules.",
			invalidAction: "This action is no longer available. Choose again.",
			optRebalance: "Rebalanced cards",
			optMilitary: "New military and additional action cards",
			optLeaders: "Leaders and wonders",
			optPublicHands: "Public civil hands",
			base: "Base game",
			expansion: "Expansion",
			secret: "Secret mix",
			public: "Public mix",
			row: "Card row",
			civilization: "Civilization",
			hand: "Civil hand",
			militaryHand: "Military hand",
			actions: "Available actions",
			details: "Card details",
			reserves: "Reserves",
			reserveSummary: "View reserves: {{blue}} storage tokens, {{yellow}} population, {{pool}} unused workers, {{discontent}} discontent workers.",
			storageRisk: "{{n}} storage tokens; corruption costs {{loss}} resources.",
			populationRisk: "{{n}} population; consumption costs {{loss}} food; {{happy}} happiness required.",
			happinessThreshold: "One more happiness is required at {{n}} or fewer population tokens.",
			happinessDemand: "Happiness required / available",
			workerProduction: "Each worker produces {{effects}} per turn.",
			workerBenefits: "Each worker provides {{effects}}.",
			shortName: "Through the Ages",
			civilizations: "Civilizations",
			you: "you",
			availableTarget: "Available",
			chooseTargets: "Choose a target on the board",
			cancelSelection: "Cancel selection",
			viewCivilization: "View {{name}}’s civilization",
			endActionShort: "End actions",
			endPoliticsShort: "End politics",
			emptySlot: "Empty card space",
			handArea: "Hand area",
			civilDeck: "Civil deck",
			militaryDeck: "Military deck",
			close: "Close",
			all: "All",
			noActions: "Waiting for another civilization",
			waiting: "Waiting for {{name}}",
			turn: "Round {{round}} · Age {{age}}",
			lastRound: "Final round",
			population: "Population",
			yellowBank: "Yellow bank",
			blueBank: "Blue bank",
			pool: "Unused workers",
			culture: "Culture",
			science: "Science",
			food: "Food",
			ore: "Resources",
			strength: "Strength",
			happy: "Happiness",
			civil: "Civil actions",
			military: "Military actions",
			colonize: "Colonization",
			urban: "Urban limit",
			armies: "Armies",
			discontent: "Discontent workers",
			production: "Production",
			construction: "Build cost",
			researchCost: "Science cost",
			revolutionCost: "Revolution cost",
			stageCosts: "Stage costs",
			workers: "Workers {{n}}",
			tokens: "Blue tokens {{n}}",
			stages: "{{n}} stages built",
			ruined: "Ruins",
			homerMark: "Homer: +1 happiness",
			sunMark: "Sun Tzu: +1 strength",
			technology: "Technology",
			government: "Government",
			leader: "Leader",
			wonder: "Wonder",
			action: "Action",
			event: "Event",
			territory: "Territory",
			tactic: "Tactic",
			bonus: "Military bonus",
			aggression: "Aggression",
			war: "War",
			pact: "Pact",
			farm: "Farm",
			mine: "Mine",
			lab: "Lab",
			temple: "Temple",
			library: "Library",
			theater: "Theater",
			arena: "Arena",
			infantry: "Infantry",
			cavalry: "Cavalry",
			artillery: "Artillery",
			airforce: "Air force",
			law: "Law",
			warfare: "Military",
			exploration: "Exploration",
			commonTactics: "Common tactics",
			exclusive: "Exclusive to {{name}}",
			events: "Events",
			eventCounts: "Current {{n}} · Future {{future}}",
			selectedPool: "Selected leaders and wonders",
			history: "History",
			knownEvents: "Known future events",
			peek: "Top current event",
			spy: "{{name}}’s military hand",
			auction: "{{card}} · Highest bid {{n}}",
			selectedUnits: "Units {{n}} · Cards {{cards}}",
			noBid: "No bid yet",
			costs: "{{civil}} civil · {{military}} military · {{food}} food · {{ore}} resources · {{science}} science",
			discounted: "Gutenberg’s action",
			via: "{{card}}: {{action}}",
			summary: "{{name}} · Culture {{n}}",
			scoreFrom: "{{card}}: {{n}} culture",
			tradePayment: "Trade Routes: substitute {{n}} {{resource}}",
			add: "Add",
			remove: "Remove",
			sideA: "A",
			sideB: "B",
			extraCulture: "Gain 3 culture",
			extraMilitary: "Gain 3 temporary military science and resources",
			extraCivil: "Gain a civil action",
			extraStrength: "Gain 2 strength",
			colonizationOffer: "Current force {{n}} · Committed resources {{paid}}",
			yellowBonus: "Yellow bank tokens +{{n}}",
			blueBonus: "Blue tokens +{{n}}",
			moves: {
				take: "Take {{card}}",
				end: "End Action Phase",
				population: "Increase population",
				research: "Develop {{card}}",
				revolution: "Revolution: {{card}}",
				leader: "Appoint {{card}}",
				build: "Build {{card}}",
				upgrade: "Upgrade {{source}} to {{card}}",
				destroy: "Destroy {{card}}",
				wonder: "Build {{n}} stages of {{name}}’s {{card}}",
				action: "Play {{card}}{{resource}}",
				hammurabi: "Use a military action as a civil action",
				barbarossa: "Increase population and build {{card}}",
				liner: "Gain a free population",
				louvre: "Return a Louvre token for 2 resources",
				churchill: "Churchill: {{extra}}",
				tactic: "Play tactic {{card}}",
				copyTactic: "Copy tactic {{card}}",
				endPolitics: "End Politics Phase",
				olympics: "Declare Olympics for 8 culture",
				fleming: "Inspect {{name}}’s military hand",
				prepare: "Prepare {{card}}",
				columbus: "Colonize {{card}}",
				offer: "Offer {{card}} to {{name}} (you are {{extra}})",
				declareWar: "Declare {{card}} on {{name}}",
				aggression: "Play {{card}} against {{name}}",
				cancelPact: "Cancel {{card}}",
				alexander: "Remove Alexander for 1 yellow bank token",
				catherine: "Use Catherine’s political ability",
				auctionPass: "Pass the auction",
				auctionUnit: "{{extra}} one {{card}}",
				auctionCard: "{{extra}} {{card}}",
				auctionPay: "Commit {{n}} resources for colonization",
				auctionBid: "Bid {{n}} colonization force",
				decline: "Decline pact",
				accept: "Accept pact",
				skip: "Pass",
				sacrifice: "Sacrifice {{card}}",
				yield: "Accept aggression",
				defend: "Defend and discard selected cards",
				defenseCard: "{{extra}} {{card}}",
				plunder: "Take {{n}} food and the rest as resources",
				raid: "Destroy opposing {{card}}",
				infiltrateLeader: "Remove leader {{card}}",
				infiltrateWonder: "Remove unfinished {{card}}",
				annex: "Take colony {{card}}",
				kidnap: "Take {{card}} from rival’s hand",
				warScience: "Take {{n}} science",
				warSteal: "Steal special technology {{card}}",
				produce: "Produce a blue token on {{card}}",
				removeBlue: "Remove a blue token from {{card}}",
				losePopulation: "Lose a population from {{card}}",
				discardCards: "Discard {{card}}",
				discard: "Discard {{card}}",
				gainMixed: "Gain {{n}} food and {{cost}} resources",
				loseMixed: "Lose {{n}} food and {{cost}} resources",
				gain: "Gain {{n}} {{resource}}",
				saladin: "Saladin: {{extra}}",
				recoverCivil: "Recover a civil action",
				homer: "Place Homer under {{card}}",
				jobs: "Pay 1 resource for 4 culture",
				freeBuild: "Build {{card}} for free",
				planning: "Choose {{card}}",
				demolish: "Destroy {{name}}’s {{card}}",
				ravages: "Turn {{card}} into ruins",
				loseColony: "Lose colony {{card}}",
				freeColony: "Colonize {{card}}",
				unitedNations: "Evaluate and keep {{card}}",
				agreementAccept: "Skip your next political action to take cards",
				agreementTake: "Take {{card}}",
				agreementEnd: "Finish taking cards",
				negotiate: "Transfer 3 {{resource}}"
			},
			prompts: {
				action: "Take actions",
				politics: "Take a political action",
				resolve: "Resolving",
				discard: "Discard excess military cards",
				done: "Game over",
				pact: "Accept this pact?",
				attackHimeji: "You may sacrifice a unit for this attack",
				defendHimeji: "You may sacrifice a unit for this defense",
				defend: "Choose defense cards or accept the aggression",
				plunder: "Choose food to take",
				raid: "Choose an urban building to destroy",
				infiltrate: "Choose a leader or unfinished wonder to remove",
				annex: "Choose a colony",
				kidnap: "Choose a civil card to take",
				warTechnology: "Take science or steal a special technology",
				produce: "Choose where to produce the remaining blue tokens",
				removeBlue: "Choose a blue token to remove",
				losePopulation: "Choose a population to lose",
				discardCards: "Choose a military card to discard",
				gainMixed: "Choose food and resources to gain",
				loseMixed: "Choose food and resources to lose",
				boudica: "Choose Boudica’s benefit",
				autonomous: "Choose the Autonomous Territory benefit",
				devMarkets: "Choose food or resources",
				saladin: "Choose Saladin’s benefit",
				homer: "Choose Homer’s legacy",
				jobs: "Pay a resource for culture?",
				devWarfare: "You may build a Warrior for free",
				devReligion: "You may build a temple for free",
				devCivilization: "You may take a civilization action with a discount of 1",
				freedomMovement: "You may move a worker to another technology",
				planning: "Choose an Age A event",
				demolish: "Choose a building, farm, or mine to destroy",
				terrorism: "Choose an opposing urban building to destroy",
				ravages: "Choose a wonder to turn into ruins",
				loseColony: "Choose a colony to lose",
				freeColony: "You may colonize a territory from hand",
				unitedNations: "You may evaluate an Age III event from hand",
				agreementOffer: "Skip your next political action to take cards?",
				agreement: "Take cards costing up to 5 civil actions",
				negotiations: "Choose what to transfer",
				auction: "Choose units and cards, then bid or pass"
			},
			log: {
				action: "{{name}} played {{card}}",
				take: "{{name}} took {{card}}",
				research: "{{name}} developed {{card}}",
				revolution: "{{name}} revolted to {{card}}",
				leader: "{{name}} appointed {{card}}",
				population: "{{name}} increased population",
				build: "{{name}} built {{card}}",
				upgrade: "{{name}} upgraded to {{card}}",
				destroy: "{{name}} destroyed {{card}}",
				wonder: "{{name}} built {{n}} stages of {{card}}",
				complete: "{{name}} completed {{card}}",
				prepare: "{{name}} prepared an event for {{n}} culture",
				aggression: "{{name}} played {{card}} against {{target}}",
				declareWar: "{{name}} declared {{card}} on {{target}}",
				bid: "{{name}} bid {{n}} for {{card}}",
				colonize: "{{name}} colonized {{card}}",
				event: "Event: {{card}}",
				defend: "{{name}} defended against {{card}}",
				yield: "{{name}} suffered {{card}}",
				warResult: "{{name}} defeated {{target}} in {{card}} by {{n}} strength",
				score: "{{name}} scored {{n}} culture from {{card}}",
				age: "Age {{n}} begins",
				uprising: "{{name}} suffered an uprising",
				corruption: "{{name}} paid {{n}} corruption",
				starvation: "{{name}} lacked {{n}} food"
			},
			cards: {
				agriculture: {
					name: "Agriculture",
					text: "",
					revised: ""
				},
				bronze: {
					name: "Bronze",
					text: "",
					revised: ""
				},
				philosophy: {
					name: "Philosophy",
					text: "",
					revised: ""
				},
				religion: {
					name: "Religion",
					text: "",
					revised: ""
				},
				warriors: {
					name: "Warriors",
					text: "",
					revised: ""
				},
				irrigation: {
					name: "Irrigation",
					text: "",
					revised: ""
				},
				selectiveBreeding: {
					name: "Selective Breeding",
					text: "",
					revised: ""
				},
				mechanizedAgriculture: {
					name: "Mechanized Agriculture",
					text: "",
					revised: ""
				},
				iron: {
					name: "Iron",
					text: "",
					revised: ""
				},
				coal: {
					name: "Coal",
					text: "",
					revised: ""
				},
				oil: {
					name: "Oil",
					text: "",
					revised: ""
				},
				alchemy: {
					name: "Alchemy",
					text: "",
					revised: ""
				},
				scientificMethod: {
					name: "Scientific Method",
					text: "",
					revised: ""
				},
				computers: {
					name: "Computers",
					text: "",
					revised: ""
				},
				theology: {
					name: "Theology",
					text: "",
					revised: ""
				},
				organizedReligion: {
					name: "Organized Religion",
					text: "",
					revised: ""
				},
				printingPress: {
					name: "Printing Press",
					text: "",
					revised: ""
				},
				journalism: {
					name: "Journalism",
					text: "",
					revised: ""
				},
				multimedia: {
					name: "Multimedia",
					text: "",
					revised: ""
				},
				drama: {
					name: "Drama",
					text: "",
					revised: ""
				},
				opera: {
					name: "Opera",
					text: "",
					revised: ""
				},
				movies: {
					name: "Movies",
					text: "",
					revised: ""
				},
				breadCircuses: {
					name: "Bread and Circuses",
					text: "",
					revised: ""
				},
				teamSports: {
					name: "Team Sports",
					text: "",
					revised: ""
				},
				professionalSports: {
					name: "Professional Sports",
					text: "",
					revised: ""
				},
				swordsmen: {
					name: "Swordsmen",
					text: "",
					revised: ""
				},
				riflemen: {
					name: "Riflemen",
					text: "",
					revised: ""
				},
				modernInfantry: {
					name: "Modern Infantry",
					text: "",
					revised: ""
				},
				knights: {
					name: "Knights",
					text: "",
					revised: ""
				},
				cavalrymen: {
					name: "Cavalrymen",
					text: "",
					revised: ""
				},
				tanks: {
					name: "Tanks",
					text: "",
					revised: ""
				},
				cannon: {
					name: "Cannon",
					text: "",
					revised: ""
				},
				rockets: {
					name: "Rockets",
					text: "",
					revised: ""
				},
				airforces: {
					name: "Air Forces",
					text: "",
					revised: ""
				},
				codeOfLaws: {
					name: "Code of Laws",
					text: "",
					revised: ""
				},
				justiceSystem: {
					name: "Justice System",
					text: "",
					revised: ""
				},
				civilService: {
					name: "Civil Service",
					text: "",
					revised: ""
				},
				warfare: {
					name: "Warfare",
					text: "",
					revised: ""
				},
				strategy: {
					name: "Strategy",
					text: "",
					revised: ""
				},
				militaryTheory: {
					name: "Military Theory",
					text: "",
					revised: ""
				},
				cartography: {
					name: "Cartography",
					text: "",
					revised: ""
				},
				navigation: {
					name: "Navigation",
					text: "",
					revised: ""
				},
				satellites: {
					name: "Satellites",
					text: "",
					revised: ""
				},
				masonry: {
					name: "Masonry",
					text: "",
					revised: ""
				},
				architecture: {
					name: "Architecture",
					text: "",
					revised: ""
				},
				engineering: {
					name: "Engineering",
					text: "",
					revised: ""
				},
				despotism: {
					name: "Despotism",
					text: "",
					revised: ""
				},
				monarchy: {
					name: "Monarchy",
					text: "",
					revised: ""
				},
				theocracy: {
					name: "Theocracy",
					text: "",
					revised: ""
				},
				constitutionalMonarchy: {
					name: "Constitutional Monarchy",
					text: "",
					revised: ""
				},
				republic: {
					name: "Republic",
					text: "",
					revised: ""
				},
				democracy: {
					name: "Democracy",
					text: "",
					revised: ""
				},
				communism: {
					name: "Communism",
					text: "",
					revised: ""
				},
				fundamentalism: {
					name: "Fundamentalism",
					text: "",
					revised: ""
				},
				homer: {
					name: "Homer",
					text: "Each turn, gain 1 temporary resource for military units. When replaced, you may give a completed wonder 1 permanent happy face instead of recovering an action.",
					revised: "Each turn, gain 1 temporary resource for military units. When replaced, you may give a completed wonder 1 permanent happy face instead of recovering an action."
				},
				moses: {
					name: "Moses",
					text: "Increasing population costs 1 less food.",
					revised: "Increasing population costs 1 less food."
				},
				alexander: {
					name: "Alexander the Great",
					text: "Each military unit gives 1 extra strength. As a political action, remove Alexander to add 1 yellow token to your bank.",
					revised: "Each military unit gives 1 extra strength. As a political action, remove Alexander to add 1 yellow token to your bank."
				},
				hammurabi: {
					name: "Hammurabi",
					text: "Each turn, you may use one military action as a civil action. Taking a leader costs 1 less civil action.",
					revised: "Each turn, you may use one military action as a civil action."
				},
				caesar: {
					name: "Julius Caesar",
					text: "Once per game, after a political action, you may perform a second political action.",
					revised: "You may perform up to 2 political actions each turn."
				},
				aristotle: {
					name: "Aristotle",
					text: "Score 1 science whenever you take a technology from the card row.",
					revised: "Score 1 science whenever you take a technology from the card row."
				},
				ashoka: {
					name: "Ashoka",
					text: "With at least 2 civil card colors in hand, produce 1 extra resource; with at least 3, also produce 1 extra food.",
					revised: "With at least 2 civil card colors in hand, produce 1 extra resource; with at least 3, also produce 1 extra food."
				},
				cleopatra: {
					name: "Cleopatra",
					text: "Each turn, gain 1 temporary resource for wonders or urban buildings.",
					revised: "Each turn, gain 1 temporary resource for wonders or urban buildings."
				},
				sunTzu: {
					name: "Sun Tzu",
					text: "Keep tactics exclusive and draw 2 additional military cards each turn. When Sun Tzu leaves, your current tactic permanently gains 1 strength.",
					revised: "Keep tactics exclusive and draw 2 additional military cards each turn. When Sun Tzu leaves, your current tactic permanently gains 1 strength."
				},
				confucius: {
					name: "Confucius",
					text: "Gain 1 science when preparing an event and when Confucius leaves play. Any military card may become an event; a revealed non-event gives everyone 1 science.",
					revised: "Gain 1 science when preparing an event and when Confucius leaves play. Any military card may become an event; a revealed non-event gives everyone 1 science."
				},
				boudica: {
					name: "Boudica",
					text: "At the start of the Action Phase, gain 2 temporary military resources if among the two weakest; otherwise gain 1 food, resource, or science.",
					revised: "At the start of the Action Phase, gain 2 temporary military resources if among the two weakest; otherwise gain 1 food, resource, or science."
				},
				hippocrates: {
					name: "Hippocrates",
					text: "At turn start, reserve a yellow token, up to 3. After losing bank tokens at the end of Ages I–III, add one reserved token to your yellow bank.",
					revised: "At turn start, reserve a yellow token, up to 3. After losing bank tokens at the end of Ages I–III, add one reserved token to your yellow bank."
				},
				joan: {
					name: "Joan of Arc",
					text: "Happy faces from temples and government also provide strength. You may inspect the top current event before your political action.",
					revised: "Happy faces from temples and government also provide strength. You may inspect the top current event before your political action."
				},
				columbus: {
					name: "Christopher Columbus",
					text: "As a political action, remove Columbus to colonize a territory in hand without sacrificing units.",
					revised: "As a political action, remove Columbus to colonize a territory in hand without sacrificing units."
				},
				daVinci: {
					name: "Leonardo da Vinci",
					text: "Your best lab or library produces extra science equal to its level. Gain 1 resource whenever you develop a technology.",
					revised: "Your best lab or library produces extra science equal to its level. Gain 1 resource whenever you develop a technology."
				},
				michelangelo: {
					name: "Michelangelo",
					text: "Temples, theaters, and wonders produce 1 extra culture per happy face. Completed wonders do not increase the action cost of taking a wonder.",
					revised: "Urban buildings and wonders produce extra culture per happy face. Ignore completed wonders when taking a wonder and gain 1 resource."
				},
				barbarossa: {
					name: "Frederick Barbarossa",
					text: "For 1 military action, increase population and build a military unit, paying 1 less food and 1 less resource.",
					revised: "For 1 military action, increase population and build a military unit, paying 1 less food and 1 less resource."
				},
				genghis: {
					name: "Genghis Khan",
					text: "Infantry may serve as cavalry in tactics. At turn end, score 3 culture if among the two strongest (the strongest with two players); you win ties.",
					revised: "Infantry may serve as cavalry in tactics. At turn end, score 3 culture if among the two strongest (the strongest with two players); you win ties."
				},
				isabella: {
					name: "Isabella of Castile",
					text: "Produce 1 extra resource and gain 2 military actions. During colonization, pay 1, 3, or 6 resources for 1, 2, or 3 extra colonization force.",
					revised: "Produce 1 extra resource and gain 2 military actions. During colonization, pay 1, 3, or 6 resources for 1, 2, or 3 extra colonization force."
				},
				nostradamus: {
					name: "Nostradamus",
					text: "Preparing an event gives 3 extra culture. See events others prepare. Gain 3 strength against aggressions and when events identify the weakest civilization.",
					revised: "Preparing an event gives 3 extra culture. See events others prepare. Gain 3 strength against aggressions and when events identify the weakest civilization."
				},
				zizka: {
					name: "Jan Žižka",
					text: "For tactics, farms may act as Age A infantry or artillery. Each army produces 1 culture.",
					revised: "For tactics, farms may act as Age A infantry or artillery. Each army produces 1 culture."
				},
				saladin: {
					name: "Saladin",
					text: "After your Action Phase, choose 2 extra strength or 1 extra civil action until your next choice or Saladin leaves play.",
					revised: "After your Action Phase, choose 2 extra strength or 1 extra civil action until your next choice or Saladin leaves play."
				},
				eleanor: {
					name: "Eleanor of Aquitaine",
					text: "Draw 2 military cards when preparing an event. Score 1 culture per excess military card discarded. Recover 3 civil actions when replaced.",
					revised: "Draw 2 military cards when preparing an event. Score 1 culture per excess military card discarded. Recover 3 civil actions when replaced."
				},
				gutenberg: {
					name: "Johannes Gutenberg",
					text: "Each turn, use 1 extra civil action to take, develop, build, or upgrade a lab or library with a discount of 1 science or resource, and score 2 culture.",
					revised: "Each turn, use 1 extra civil action to take, develop, build, or upgrade a lab or library with a discount of 1 science or resource, and score 2 culture."
				},
				cook: {
					name: "James Cook",
					text: "Discard up to 2 military cards for 1 colonization force each. Your first colony produces 2 extra culture and each further colony 1.",
					revised: "Discard up to 2 military cards for 1 colonization force each. Your first colony produces 2 extra culture and each further colony 1."
				},
				robespierre: {
					name: "Maximilien Robespierre",
					text: "Revolutions cost all military actions instead of civil actions. Score 3 culture when declaring a revolution.",
					revised: "Revolutions cost all military actions instead of civil actions. Score 3 culture when declaring a revolution."
				},
				bach: {
					name: "Johann Sebastian Bach",
					text: "Theaters produce 1 extra culture and their technologies cost 2 less science. Once per turn, upgrade any urban building to a theater of the same or higher level.",
					revised: "Theaters produce 1 extra culture and their technologies cost 2 less science. Once per turn, upgrade any urban building to a theater of the same or higher level."
				},
				newton: {
					name: "Isaac Newton",
					text: "Your best lab or library produces extra science equal to its level. Recover 1 civil action whenever you develop a technology.",
					revised: "Your best lab or library produces extra science equal to its level. Recover 1 civil action whenever you develop a technology."
				},
				shakespeare: {
					name: "William Shakespeare",
					text: "With a library, theaters and their technologies cost 1 less; with a theater, libraries receive the same discount. Each library–theater pair produces 2 extra culture.",
					revised: "With a library, theater buildings cost 2 fewer resources and technologies 3 less science; theaters give the same discounts to libraries. Each pair produces 2 extra culture."
				},
				napoleon: {
					name: "Napoleon Bonaparte",
					text: "Gain 2 strength for each different military unit type.",
					revised: "Gain 2 strength for each different military unit type."
				},
				gaudi: {
					name: "Antoni Gaudí",
					text: "Urban technologies cost 1 less science for each other urban building type. Your best building of each urban type produces 1 extra culture.",
					revised: "Urban technologies cost 1 less science for each other urban building type. Your best building of each urban type produces 1 extra culture."
				},
				darwin: {
					name: "Charles Darwin",
					text: "Temples give 1 fewer happy face. Labs and libraries produce 1 extra culture. Taking technology cards costs 1 less civil action, to a minimum of 1.",
					revised: "Temples give 1 fewer happy face. Labs and libraries produce 1 extra culture. Taking technology cards costs 1 less civil action, to a minimum of 1."
				},
				watt: {
					name: "James Watt",
					text: "Farm and mine technologies and buildings cost 1/2/3 less at levels I/II/III. When Watt leaves, score culture equal to your most productive farm or mine.",
					revised: "Farm and mine technologies and buildings cost 1/2/3 less at levels I/II/III. When Watt leaves, score culture equal to your most productive farm or mine."
				},
				nobel: {
					name: "Alfred Nobel",
					text: "When replaced, establish the Nobel Prize instead of recovering an action. Thereafter, any civilization developing at least 2 technologies in one turn scores 4 culture.",
					revised: "When replaced, establish the Nobel Prize instead of recovering an action. Thereafter, any civilization developing at least 2 technologies in one turn scores 4 culture."
				},
				catherine: {
					name: "Catherine the Great",
					text: "Once per game, use a political action to remove a yellow bank token from each weaker civilization. Gain a token if at least 1 was lost (2 with four players).",
					revised: "Once per game, use a political action to remove a yellow bank token from each weaker civilization. Gain a token if at least 1 was lost (2 with four players)."
				},
				mariaTheresa: {
					name: "Maria Theresa",
					text: "Gain 1 science and culture per population gained. Start the Action Phase with 1 temporary military resource, or 3 if among the two weakest.",
					revised: "Gain 1 science and culture per population gained. Start the Action Phase with 1 temporary military resource, or 3 if among the two weakest."
				},
				chaplin: {
					name: "Charlie Chaplin",
					text: "One of your best theaters produces twice as much culture.",
					revised: "One of your best theaters produces twice as much culture."
				},
				gandhi: {
					name: "Mahatma Gandhi",
					text: "You cannot play aggressions or wars. Rivals pay twice the military action cost to attack you.",
					revised: "You cannot play aggressions or wars. Rivals pay 3 extra military actions to attack you."
				},
				einstein: {
					name: "Albert Einstein",
					text: "Your best lab or library produces extra science equal to its level. Score 3 culture whenever you develop a technology.",
					revised: "Your best lab or library produces extra science equal to its level. Score 3 culture whenever you develop a technology."
				},
				churchill: {
					name: "Winston Churchill",
					text: "Each turn, choose 3 culture, or 3 temporary science and 3 resources for military technologies and units.",
					revised: "Each turn, choose 3 culture, or 3 temporary science and 3 resources for military technologies and units."
				},
				billGates: {
					name: "Bill Gates",
					text: "Labs of level I or higher produce and store resources equal to their levels. When Gates leaves, or at game end, score culture equal to this extra production.",
					revised: "Labs of level I or higher produce and store resources equal to their levels. When Gates leaves, or at game end, score culture equal to this extra production."
				},
				sidMeier: {
					name: "Sid Meier",
					text: "Labs produce culture equal to their level, but 1 less science each.",
					revised: "Labs produce culture equal to their level, but 1 less science each."
				},
				curie: {
					name: "Marie Curie Skłodowska",
					text: "Your best mine produces science equal to its level; your best lab gives strength equal to its level. Produce culture equal to the higher level.",
					revised: "Your best mine produces science equal to its level; your best lab gives strength equal to its level. Produce culture equal to the higher level."
				},
				jobs: {
					name: "Steve Jobs",
					text: "Your best lab gives happy faces equal to its level. Whenever you develop a technology, you may pay 1 resource to score 4 culture.",
					revised: "Your best lab gives happy faces equal to its level. Whenever you develop a technology, you may pay 1 resource to score 4 culture."
				},
				fleming: {
					name: "Ian Fleming",
					text: "Your best library and theater each produce extra culture equal to their levels. Inspect one rival’s military hand before politics; do not choose the same rival on consecutive turns.",
					revised: "Your best library and theater each produce extra culture equal to their levels. Inspect one rival’s military hand before politics; do not choose the same rival on consecutive turns."
				},
				dietrich: {
					name: "Marlene Dietrich",
					text: "All of your best theaters give 1 extra culture and happy face. One infantry, cavalry, or artillery unit may count twice for tactics.",
					revised: "All of your best theaters give 1 extra culture and happy face. One infantry, cavalry, or artillery unit may count twice for tactics."
				},
				mandela: {
					name: "Nelson Mandela",
					text: "Taking Mandela costs 3 extra civil actions if you have no discontent workers. At turn end, score 1 culture per surplus happy face.",
					revised: "Taking Mandela costs 3 extra civil actions if you have no discontent workers. At turn end, score 1 culture per surplus happy face."
				},
				coubertin: {
					name: "Pierre de Coubertin",
					text: "Arenas produce 2 culture. Once per game before politics, declare Olympics and score 8 culture; until your next turn, playing a war or aggression costs 8 culture.",
					revised: "Arenas produce 2 culture. Once per game before politics, declare Olympics and score 8 culture; until your next turn, playing a war or aggression costs 8 culture."
				},
				alexandria: {
					name: "Library of Alexandria",
					text: "Civil and military hand limits each increase by 1.",
					revised: "Civil and military hand limits each increase by 1."
				},
				colossus: {
					name: "Colossus",
					text: "Gain 2 strength and 1 colonization force.",
					revised: "Gain 2 strength and 1 colonization force. Draw 3 military cards at the start of Ages II and III."
				},
				pyramids: {
					name: "Pyramids",
					text: "Gain 1 civil action.",
					revised: "Gain 1 civil action."
				},
				hangingGardens: {
					name: "Hanging Gardens",
					text: "Produce 1 culture and gain 2 happy faces.",
					revised: "Produce 1 culture and gain 2 happy faces. Gain 2 food on completion."
				},
				colosseum: {
					name: "Colosseum",
					text: "Infantry and cavalry technologies cost less science equal to their level; score 2 culture when developing one.",
					revised: "Infantry and cavalry technologies cost less science equal to their level; score 2 culture when developing one."
				},
				romanRoads: {
					name: "Roman Roads",
					text: "Produce 1 resource in Age I, 1 science in Age II, and 2 culture in later ages.",
					revised: "Produce 1 resource in Age I, 1 science in Age II, and 2 culture in later ages."
				},
				stonehenge: {
					name: "Stonehenge",
					text: "Score culture equal to each stage’s printed cost when you build it.",
					revised: "Score culture equal to each stage’s printed cost when you build it."
				},
				acropolis: {
					name: "Acropolis",
					text: "Urban building limit increases by 1. Peaceful government changes cost 1 less science per urban building.",
					revised: "Urban building limit increases by 1. Peaceful government changes cost 1 less science per urban building."
				},
				basilica: {
					name: "St. Peter’s Basilica",
					text: "Each other card or worker that provides happy faces gives 1 more.",
					revised: "Each other card or worker that provides happy faces gives 1 more."
				},
				tajMahal: {
					name: "Taj Mahal",
					text: "If you replaced a leader this turn, taking this wonder costs 2 fewer civil actions.",
					revised: "If you replaced a leader this turn, taking this wonder costs 2 fewer civil actions."
				},
				carolina: {
					name: "Universitas Carolina",
					text: "Produce 2 science and 1 culture.",
					revised: "Produce 2 science and 1 culture."
				},
				greatWall: {
					name: "Great Wall",
					text: "Each infantry and artillery unit gives 1 extra strength.",
					revised: "Each infantry and artillery unit gives 1 extra strength."
				},
				machuPicchu: {
					name: "Machu Picchu",
					text: "Your best Age A or I farm and mine each produce 1 extra blue token.",
					revised: "Your best Age A or I farm and mine each produce 1 extra blue token."
				},
				himeji: {
					name: "Himeji Castle",
					text: "Sacrifice a unit in a war or aggression to add its strength for that attack or defense. When attacking, also score 3 culture; when defending, also add 3 strength.",
					revised: "Sacrifice a unit in a war or aggression to add its strength for that attack or defense. When attacking, also score 3 culture; when defending, also add 3 strength."
				},
				forbiddenCity: {
					name: "Forbidden City",
					text: "Ignore up to 2 discontent workers.",
					revised: "Ignore up to 2 discontent workers."
				},
				silkRoad: {
					name: "Silk Road",
					text: "Increase each benefit of the first action card played each turn by 1. This starts after the first stage is built.",
					revised: "Increase each benefit of the first action card played each turn by 1. This starts after the first stage is built."
				},
				oceanLiner: {
					name: "Ocean Liner Service",
					text: "Gain 1 population during each Action Phase, without an action or food cost.",
					revised: "Gain 1 population during each Action Phase, without an action or food cost."
				},
				kremlin: {
					name: "Kremlin",
					text: "Gain 1 civil and military action and produce 2 culture, but lose 1 happy face.",
					revised: "Gain 1 civil and military action and produce 2 culture, but lose 1 happy face."
				},
				eiffel: {
					name: "Eiffel Tower",
					text: "Produce 4 culture and gain 1 happy face.",
					revised: "Produce 4 culture and gain 1 happy face."
				},
				railroad: {
					name: "Transcontinental Railroad",
					text: "Your best mine produces 1 extra blue token.",
					revised: "Your best mine produces 1 extra blue token."
				},
				harvard: {
					name: "Harvard College",
					text: "Once per turn, play an action card taken during this Action Phase.",
					revised: "Once per turn, play an action card taken during this Action Phase."
				},
				suez: {
					name: "Suez Canal",
					text: "When completed, you may colonize a territory from hand. Each colony produces 1 extra resource.",
					revised: "When completed, you may colonize a territory from hand. Each colony produces 1 extra resource."
				},
				louvre: {
					name: "Louvre Museum",
					text: "Keep its 3 blue tokens when completed; each produces 1 culture. During your Action Phase, return a token to gain 2 resources.",
					revised: "Keep its 3 blue tokens when completed; each produces 1 culture. During your Action Phase, return a token to gain 2 resources."
				},
				liberty: {
					name: "Statue of Liberty",
					text: "Your government produces culture equal to its level.",
					revised: "Your government produces culture equal to its level."
				},
				hollywood: {
					name: "Hollywood",
					text: "Immediately score twice the culture produced by your theaters and libraries.",
					revised: "Immediately score twice the culture produced by your theaters and libraries."
				},
				internet: {
					name: "Internet",
					text: "Immediately score the total culture, science, and strength produced by your urban buildings.",
					revised: "Immediately score the total culture, science, and strength produced by your urban buildings."
				},
				spaceFlight: {
					name: "First Space Flight",
					text: "Immediately score culture equal to the total levels of your technologies.",
					revised: "Immediately score culture equal to the total levels of your technologies."
				},
				fastFood: {
					name: "Fast Food Chains",
					text: "Immediately score 1 culture per military or urban worker, and 2 per farm or mine worker.",
					revised: "Immediately score 1 culture per military or urban worker, and 2 per farm or mine worker."
				},
				empireState: {
					name: "Empire State Building",
					text: "Compare science, culture, strength, food production, and resource production. Score 7/8/9 per category you lead outright in a 2/3/4-player game.",
					revised: "Compare science, culture, strength, food production, and resource production. Score 7/8/9 per category you lead outright in a 2/3/4-player game."
				},
				unitedNations: {
					name: "United Nations",
					text: "Score 4 culture per wonder, special technology, or urban type, whichever count is greatest. You may evaluate an Age III event from hand and keep it.",
					revised: "Score 4 culture per wonder, special technology, or urban type, whichever count is greatest. You may evaluate an Age III event from hand and keep it."
				},
				manhattan: {
					name: "Manhattan Project",
					text: "Immediately score culture equal to your science rating.",
					revised: "Immediately score culture equal to your science rating."
				},
				redCross: {
					name: "International Red Cross",
					text: "Build with food; the builder scores 6 culture per stage. Other players may build one stage per turn. On completion, the owner scores culture per colony in play.",
					revised: "Build with food; the builder scores 6 culture per stage. Other players may build one stage per turn. On completion, the owner scores culture per colony in play."
				},
				urbanGrowth0: {
					name: "Urban Growth",
					text: "Build or upgrade an urban building with a discount of 1 resources.",
					revised: "Build or upgrade an urban building with a discount of 1 resources."
				},
				richLand0: {
					name: "Rich Land",
					text: "Build or upgrade a farm or mine with a discount of 1 resources.",
					revised: "Build or upgrade a farm or mine with a discount of 1 resources."
				},
				frugality0: {
					name: "Frugality",
					text: "Increase population at the usual cost, then gain 1 food.",
					revised: "Increase population at the usual cost, then gain 1 food."
				},
				engineeringGenius0: {
					name: "Engineering Genius",
					text: "Build one wonder stage with a discount of 2 resources.",
					revised: "Build one wonder stage with a discount of 2 resources."
				},
				stockpile0: {
					name: "Stockpile",
					text: "Gain 1 resource, then gain 1 food.",
					revised: "Gain 1 resource, then gain 1 food."
				},
				culturalHeritage0: {
					name: "Cultural Heritage",
					text: "Score 1 science and 4 culture.",
					revised: "Score 1 science and 4 culture."
				},
				patriotism0: {
					name: "Patriotism",
					text: "Gain 1 temporary military resources and 1 temporary military action.",
					revised: "Gain 1 temporary military resources and 1 temporary military action."
				},
				urbanGrowth1: {
					name: "Urban Growth",
					text: "Build or upgrade an urban building with a discount of 2 resources.",
					revised: "Build or upgrade an urban building with a discount of 2 resources."
				},
				richLand1: {
					name: "Rich Land",
					text: "Build or upgrade a farm or mine with a discount of 2 resources.",
					revised: "Build or upgrade a farm or mine with a discount of 2 resources."
				},
				frugality1: {
					name: "Frugality",
					text: "Increase population at the usual cost, then gain 2 food.",
					revised: "Increase population at the usual cost, then gain 2 food."
				},
				engineeringGenius1: {
					name: "Engineering Genius",
					text: "Build one wonder stage with a discount of 3 resources.",
					revised: "Build one wonder stage with a discount of 3 resources."
				},
				culturalHeritage1: {
					name: "Cultural Heritage",
					text: "Gain 2 science and 2 culture.",
					revised: "Gain 2 science and 2 culture."
				},
				patriotism1: {
					name: "Patriotism",
					text: "Gain 2 temporary military resources and 1 temporary military action.",
					revised: "Gain 2 temporary military resources and 1 temporary military action."
				},
				breakthrough1: {
					name: "Breakthrough",
					text: "Develop a technology, then gain 2 science.",
					revised: "Develop a technology, then gain 2 science."
				},
				reserves1: {
					name: "Reserves",
					text: "Gain 2 food or 2 resources.",
					revised: "Gain 2 food or 2 resources."
				},
				richLand2: {
					name: "Rich Land",
					text: "Build or upgrade a farm or mine with a discount of 3 resources.",
					revised: "Build or upgrade a farm or mine with a discount of 3 resources."
				},
				frugality2: {
					name: "Frugality",
					text: "Increase population at the usual cost, then gain 3 food.",
					revised: "Increase population at the usual cost, then gain 3 food."
				},
				engineeringGenius2: {
					name: "Engineering Genius",
					text: "Build one wonder stage with a discount of 4 resources.",
					revised: "Build one wonder stage with a discount of 4 resources."
				},
				patriotism2: {
					name: "Patriotism",
					text: "Gain 3 temporary military resources and 1 temporary military action.",
					revised: "Gain 3 temporary military resources and 1 temporary military action."
				},
				revolutionaryIdea2: {
					name: "Revolutionary Idea",
					text: "Gain 4 science.",
					revised: "Gain 4 science."
				},
				efficientUpgrade2: {
					name: "Efficient Upgrade",
					text: "Upgrade a farm, mine, or urban building with a discount of 3 resources.",
					revised: "Upgrade a farm, mine, or urban building with a discount of 3 resources."
				},
				breakthrough2: {
					name: "Breakthrough",
					text: "Develop a technology, then gain 3 science.",
					revised: "Develop a technology, then gain 3 science."
				},
				reserves2: {
					name: "Reserves",
					text: "Gain 3 food or 3 resources.",
					revised: "Gain 3 food or 3 resources."
				},
				nationalism2: {
					name: "Wave of Nationalism",
					text: "Gain 5/3/2 temporary military resources per stronger civilization in a 2/3/4-player game.",
					revised: "Gain 5/3/2 temporary military resources per stronger civilization in a 2/3/4-player game."
				},
				urbanGrowth3: {
					name: "Urban Growth",
					text: "Build or upgrade an urban building with a discount of 4 resources.",
					revised: "Build or upgrade an urban building with a discount of 4 resources."
				},
				engineeringGenius3: {
					name: "Engineering Genius",
					text: "Build one wonder stage with a discount of 5 resources.",
					revised: "Build one wonder stage with a discount of 5 resources."
				},
				patriotism3: {
					name: "Patriotism",
					text: "Gain 4 temporary military resources and 1 temporary military action.",
					revised: "Gain 4 temporary military resources and 1 temporary military action."
				},
				revolutionaryIdea3: {
					name: "Revolutionary Idea",
					text: "Gain 6 science.",
					revised: "Gain 6 science."
				},
				efficientUpgrade3: {
					name: "Efficient Upgrade",
					text: "Upgrade a farm, mine, or urban building with a discount of 4 resources.",
					revised: "Upgrade a farm, mine, or urban building with a discount of 4 resources."
				},
				reserves3: {
					name: "Reserves",
					text: "Gain 4 food or 4 resources.",
					revised: "Gain 4 food or 4 resources."
				},
				militaryBuildUp3: {
					name: "Military Build-Up",
					text: "Gain 8/5/3 temporary military resources per stronger civilization in a 2/3/4-player game.",
					revised: "Gain 8/5/3 temporary military resources per stronger civilization in a 2/3/4-player game."
				},
				endowment3: {
					name: "Endowment for the Arts",
					text: "Score 6/3/2 culture per civilization with more culture points in a 2/3/4-player game.",
					revised: "Score 6/3/2 culture per civilization with more culture points in a 2/3/4-player game."
				},
				richLand1Extra: {
					name: "Rich Land",
					text: "Build or upgrade a farm or mine with a discount of 2 resources.",
					revised: "Build or upgrade a farm or mine with a discount of 2 resources."
				},
				urbanGrowth2Extra: {
					name: "Urban Growth",
					text: "Build or upgrade an urban building with a discount of 3 resources.",
					revised: "Build or upgrade an urban building with a discount of 3 resources."
				},
				frugality2Extra: {
					name: "Frugality",
					text: "Increase population at the usual cost, then gain 3 food.",
					revised: "Increase population at the usual cost, then gain 3 food."
				},
				reserves3Extra: {
					name: "Reserves",
					text: "Gain 4 food or 4 resources.",
					revised: "Gain 4 food or 4 resources."
				},
				patriotism3Extra: {
					name: "Patriotism",
					text: "Gain 4 temporary military resources and 1 temporary military action.",
					revised: "Gain 4 temporary military resources and 1 temporary military action."
				},
				revolutionaryIdea3Extra: {
					name: "Revolutionary Idea",
					text: "Gain 6 science.",
					revised: "Gain 6 science."
				},
				legion: {
					name: "Legion",
					text: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic.",
					revised: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic."
				},
				fightingBand: {
					name: "Fighting Band",
					text: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic.",
					revised: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic."
				},
				phalanx: {
					name: "Phalanx",
					text: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic.",
					revised: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic."
				},
				heavyCavalry: {
					name: "Heavy Cavalry",
					text: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic.",
					revised: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic."
				},
				medievalArmy: {
					name: "Medieval Army",
					text: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic.",
					revised: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic."
				},
				napoleonicArmy: {
					name: "Napoleonic Army",
					text: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic.",
					revised: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic."
				},
				mobileArtillery: {
					name: "Mobile Artillery",
					text: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic.",
					revised: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic."
				},
				fortifications: {
					name: "Fortifications",
					text: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic.",
					revised: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic."
				},
				conquistadors: {
					name: "Conquistadors",
					text: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic.",
					revised: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic."
				},
				defensiveArmy: {
					name: "Defensive Army",
					text: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic.",
					revised: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic."
				},
				entrenchments: {
					name: "Entrenchments",
					text: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic.",
					revised: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic."
				},
				shockTroops: {
					name: "Shock Troops",
					text: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic.",
					revised: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic."
				},
				mechanizedArmy: {
					name: "Mechanized Army",
					text: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic.",
					revised: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic."
				},
				modernArmy: {
					name: "Modern Army",
					text: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic.",
					revised: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic."
				},
				hussars: {
					name: "Hussars",
					text: "Each army’s tactical strength is 2 plus the lower cavalry level.",
					revised: "Each army’s tactical strength is 2 plus the lower cavalry level."
				},
				positionalArmy: {
					name: "Positional Army",
					text: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic.",
					revised: "Form armies with the shown units. An army is outdated if any unit is at least 2 levels below the tactic."
				},
				bonus1: {
					name: "Military Bonus",
					text: "Gain 2 strength against an aggression, or 1 colonization force.",
					revised: "Gain 2 strength against an aggression, or 1 colonization force."
				},
				extraBonus1: {
					name: "Military Bonus",
					text: "Gain 2 strength against an aggression, or 1 colonization force.",
					revised: "Gain 2 strength against an aggression, or 1 colonization force."
				},
				bonus2: {
					name: "Military Bonus",
					text: "Gain 4 strength against an aggression, or 2 colonization force.",
					revised: "Gain 4 strength against an aggression, or 2 colonization force."
				},
				extraBonus2: {
					name: "Military Bonus",
					text: "Gain 4 strength against an aggression, or 2 colonization force.",
					revised: "Gain 4 strength against an aggression, or 2 colonization force."
				},
				bonus3: {
					name: "Military Bonus",
					text: "Gain 6 strength against an aggression, or 3 colonization force.",
					revised: "Gain 6 strength against an aggression, or 3 colonization force."
				},
				extraBonus3: {
					name: "Military Bonus",
					text: "Gain 6 strength against an aggression, or 3 colonization force.",
					revised: "Gain 6 strength against an aggression, or 3 colonization force."
				},
				devWarfare: {
					name: "Development of Warfare",
					text: "You may build a Warrior unit for free.",
					revised: "You may build a Warrior unit for free."
				},
				devReligion: {
					name: "Development of Religion",
					text: "You may build an Age A temple for free.",
					revised: "You may build an Age A temple for free."
				},
				devAgriculture: {
					name: "Development of Agriculture",
					text: "Gain 2 food.",
					revised: "Gain 2 food."
				},
				devScience: {
					name: "Development of Science",
					text: "Gain 2 science.",
					revised: "Gain 2 science."
				},
				devCrafts: {
					name: "Development of Crafts",
					text: "Gain 2 resources.",
					revised: "Gain 2 resources."
				},
				devSettlement: {
					name: "Development of Settlements",
					text: "Gain 1 population.",
					revised: "Gain 1 population."
				},
				devPolitics: {
					name: "Development of Politics",
					text: "Draw 3 military cards.",
					revised: "Draw 3 military cards."
				},
				devTrade: {
					name: "Development of Trade Routes",
					text: "Gain 1 science, food, and resource.",
					revised: "Gain 1 science, food, and resource."
				},
				devCivilization: {
					name: "Development of Civilization",
					text: "Increase population, build a farm/mine/urban building, or develop a technology without an action and with a discount of 1.",
					revised: "Increase population, build a farm/mine/urban building, or develop a technology without an action and with a discount of 1."
				},
				devMarkets: {
					name: "Development of Markets",
					text: "Choose 2 food or 2 resources.",
					revised: "Choose 2 food or 2 resources."
				},
				culturalInfluence: {
					name: "Cultural Influence",
					text: "Each civilization scores culture equal to its culture rating.",
					revised: "Each civilization scores culture equal to its culture rating."
				},
				barbarians: {
					name: "Barbarians",
					text: "If the culture leader is among the two weakest, it loses 1 population.",
					revised: "If the culture leader is among the two weakest, it loses 1 population."
				},
				foray: {
					name: "Foray",
					text: "The two strongest civilizations each gain 3 food and/or resources.",
					revised: "The two strongest civilizations each gain 3 food and/or resources."
				},
				raiders: {
					name: "Raiders",
					text: "The two weakest civilizations each lose 2 food and/or resources.",
					revised: "The two weakest civilizations each lose 2 food and/or resources."
				},
				epidemic: {
					name: "Epidemic",
					text: "Each civilization loses 1 population.",
					revised: "Each civilization loses 1 population."
				},
				rats: {
					name: "Rats",
					text: "Each civilization loses all stored food.",
					revised: "Each civilization loses all stored food."
				},
				scientificBreakthrough: {
					name: "Scientific Breakthrough",
					text: "Each civilization gains science equal to its science rating.",
					revised: "Each civilization gains science equal to its science rating."
				},
				newDeposits: {
					name: "New Deposits",
					text: "Each civilization produces resources, ignoring corruption.",
					revised: "Each civilization produces resources, ignoring corruption."
				},
				goodHarvest: {
					name: "Good Harvest",
					text: "Each civilization produces food, ignoring consumption.",
					revised: "Each civilization produces food, ignoring consumption."
				},
				rebellion: {
					name: "Rebellion",
					text: "Each civilization loses 2 civil actions per discontent worker.",
					revised: "Each civilization loses 2 civil actions per discontent worker."
				},
				territorialDispute: {
					name: "Territorial Dispute",
					text: "The weakest destroys a farm, mine, or urban building; the strongest gains 3 resources.",
					revised: "The weakest destroys a farm, mine, or urban building; the strongest gains 3 resources."
				},
				crusades: {
					name: "Crusades",
					text: "The strongest gains 4 culture; the weakest loses 4.",
					revised: "The strongest gains 4 culture; the weakest loses 4."
				},
				famine: {
					name: "Famine",
					text: "The weakest civilization loses 1 population.",
					revised: "The weakest civilization loses 1 population."
				},
				enslavement: {
					name: "Enslavement",
					text: "The strongest takes a yellow bank token from the weakest.",
					revised: "The strongest takes a yellow bank token from the weakest."
				},
				immigration: {
					name: "Immigration",
					text: "All civilizations with the most happy faces gain 1 population.",
					revised: "All civilizations with the most happy faces gain 1 population."
				},
				popularization: {
					name: "Popularization of Science",
					text: "Each civilization gains culture equal to its science rating.",
					revised: "Each civilization gains culture equal to its science rating."
				},
				politicsStrength: {
					name: "Politics of Strength",
					text: "The strongest draws 5 military cards; the weakest discards 3. In Age IV, gain and lose culture instead.",
					revised: "The strongest draws 5 military cards; the weakest discards 3. In Age IV, gain and lose culture instead."
				},
				independence: {
					name: "Declaration of Independence",
					text: "The weakest civilization loses a colony of its choice.",
					revised: "The weakest civilization loses a colony of its choice."
				},
				emigration: {
					name: "Emigration",
					text: "Each civilization loses half its discontent workers, rounded up.",
					revised: "Each civilization loses half its discontent workers, rounded up."
				},
				crimeWave: {
					name: "Crime Wave",
					text: "The two weakest civilizations each lose 3 culture and a blue token.",
					revised: "The two weakest civilizations each lose 3 culture and a blue token."
				},
				nationalPride: {
					name: "National Pride",
					text: "The civilization with the most culture scores 5 culture.",
					revised: "The civilization with the most culture scores 5 culture."
				},
				civilUnrest: {
					name: "Civil Unrest",
					text: "Lose 4 culture per discontent worker; all civilizations with the most discontent workers also lose a blue token.",
					revised: "Lose 4 culture per discontent worker; all civilizations with the most discontent workers also lose a blue token."
				},
				terrorism: {
					name: "Terrorism",
					text: "The civilization with the least culture destroys an urban building of each other civilization.",
					revised: "The civilization with the least culture destroys an urban building of each other civilization."
				},
				ravages: {
					name: "Ravages of Time",
					text: "Each civilization turns an Age A or I completed wonder into ruins producing 2 culture.",
					revised: "Each civilization turns an Age A or I completed wonder into ruins producing 2 culture."
				},
				prosperity: {
					name: "Prosperity",
					text: "Each civilization gains resources equal to happy faces, up to 8.",
					revised: "Each civilization gains resources equal to happy faces, up to 8."
				},
				iconoclasm: {
					name: "Iconoclasm",
					text: "Leaders not from the current age leave play.",
					revised: "Leaders not from the current age leave play."
				},
				economicProgress: {
					name: "Economic Progress",
					text: "Each civilization resolves corruption, food production, consumption, and resource production.",
					revised: "Each civilization resolves corruption, food production, consumption, and resource production."
				},
				internationalAgreement: {
					name: "International Agreement",
					text: "The strongest may skip its next political action to take civil cards worth up to 5 civil actions, then replenish the row.",
					revised: "The strongest may skip its next political action to take civil cards worth up to 5 civil actions, then replenish the row."
				},
				colonialism: {
					name: "Colonialism",
					text: "The two strongest civilizations each score 6 culture.",
					revised: "The two strongest civilizations each score 6 culture."
				},
				happiness: {
					name: "Happiness",
					text: "The strongest gains 3 culture and a population; the weakest loses 3 culture and a population.",
					revised: "The strongest gains 3 culture and a population; the weakest loses 3 culture and a population."
				},
				impactPopulation: {
					name: "Impact of Population",
					text: "Score 2 culture per content worker beyond 10.",
					revised: "Score 2 culture per content worker beyond 10."
				},
				impactWonders: {
					name: "Impact of Wonders",
					text: "Score 5/4/3/2 culture per completed wonder of Age A/I/II/III.",
					revised: "Score 5/4/3/2 culture per completed wonder of Age A/I/II/III."
				},
				impactColonies: {
					name: "Impact of Colonies",
					text: "Score 3 culture per colony.",
					revised: "Score 3 culture per colony."
				},
				impactCompetition: {
					name: "Impact of Competition",
					text: "Score culture equal to the total levels of military units and arenas.",
					revised: "Score culture equal to the total levels of military units and arenas."
				},
				impactAgriculture: {
					name: "Impact of Agriculture",
					text: "Score culture equal to food production, plus 4 if production exceeds consumption.",
					revised: "Score culture equal to food production, plus 4 if production exceeds consumption."
				},
				impactProgress: {
					name: "Impact of Progress",
					text: "Score twice the total levels of government and special technologies.",
					revised: "Score twice the total levels of government and special technologies."
				},
				impactIndustry: {
					name: "Impact of Industry",
					text: "Score culture equal to resource production from mines only.",
					revised: "Score culture equal to resource production from mines only."
				},
				impactScience: {
					name: "Impact of Science",
					text: "Rank science production: score 15/10/5/0 with four players, 14/7/0 with three, or 10/0 with two.",
					revised: "Rank science production: score 15/10/5/0 with four players, 14/7/0 with three, or 10/0 with two."
				},
				impactTechnology: {
					name: "Impact of Technology",
					text: "Score 4 culture per Age III technology.",
					revised: "Score 4 culture per Age III technology."
				},
				impactHappiness: {
					name: "Impact of Happiness",
					text: "Score 2 culture per happy face, up to 16, minus 2 per discontent worker.",
					revised: "Score 2 culture per happy face, up to 16, minus 2 per discontent worker."
				},
				impactArchitecture: {
					name: "Impact of Architecture",
					text: "Score culture equal to the total levels of urban buildings.",
					revised: "Score culture equal to the total levels of urban buildings."
				},
				impactStrength: {
					name: "Impact of Strength",
					text: "Rank strength: score 15/10/5/0 with four players, 14/7/0 with three, or 10/0 with two.",
					revised: "Rank strength: score 15/10/5/0 with four players, 14/7/0 with three, or 10/0 with two."
				},
				impactGovernment: {
					name: "Impact of Government",
					text: "Score 2 culture per civil action and 1 per military action, using action totals.",
					revised: "Score 2 culture per civil action and 1 per military action, using action totals."
				},
				impactVariety: {
					name: "Impact of Variety",
					text: "Score 2 culture per military unit type, urban building type, and special technology.",
					revised: "Score 2 culture per military unit type, urban building type, and special technology."
				},
				impactBalance: {
					name: "Impact of Balance",
					text: "Score twice the lowest of science, culture, food, and resource production.",
					revised: "Score twice the lowest of science, culture, food, and resource production."
				},
				devPlanning: {
					name: "Development of Planning",
					text: "Reveal 3 unused Age A events. Each civilization chooses one to apply to itself.",
					revised: "Reveal 3 unused Age A events. Each civilization chooses one to apply to itself."
				},
				darkAges: {
					name: "Dark Ages",
					text: "Lose half of science points beyond 4, rounded up.",
					revised: "Lose half of science points beyond 4, rounded up."
				},
				knowledgeAncients: {
					name: "Knowledge of the Ancients",
					text: "Gain 1 science per completed wonder, and 1 resource for an unfinished wonder; double for Age A wonders.",
					revised: "Gain 1 science per completed wonder, and 1 resource for an unfinished wonder; double for Age A wonders."
				},
				callArms: {
					name: "Call to Arms",
					text: "The weakest loses 2 civil actions and the second weakest 1; draw a military card per action lost. With two players, affect only the weakest.",
					revised: "The weakest loses 2 civil actions and the second weakest 1; draw a military card per action lost. With two players, affect only the weakest."
				},
				armsIndustry: {
					name: "Arms Industry",
					text: "Compare infantry, cavalry, and artillery technology levels. Gain 2 resources per type you lead or tie for.",
					revised: "Compare infantry, cavalry, and artillery technology levels. Gain 2 resources per type you lead or tie for."
				},
				freedomMovement: {
					name: "Freedom of Movement",
					text: "You may move a worker between technologies, paying any increase in resource cost.",
					revised: "You may move a worker between technologies, paying any increase in resource cost."
				},
				internationalNegotiations: {
					name: "International Negotiations",
					text: "The revealing player chooses science, food, or resources; the strongest takes 3 from the weakest, who must have at least 3.",
					revised: "The revealing player chooses science, food, or resources; the strongest takes 3 from the weakest, who must have at least 3."
				},
				impactEconomy: {
					name: "Impact of Economy",
					text: "Score 4 times the lowest count among farms/mines, urban buildings, and military units.",
					revised: "Score 4 times the lowest count among farms/mines, urban buildings, and military units."
				},
				impactCulture: {
					name: "Impact of Culture",
					text: "Rank culture production: score 15/10/5/0 with four players, 14/7/0 with three, or 10/0 with two.",
					revised: "Rank culture production: score 15/10/5/0 with four players, 14/7/0 with three, or 10/0 with two."
				},
				developed1: {
					name: "Developed Territory",
					text: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards.",
					revised: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards."
				},
				vast1: {
					name: "Vast Territory",
					text: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards.",
					revised: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards."
				},
				wealthy1: {
					name: "Wealthy Territory",
					text: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards.",
					revised: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards."
				},
				inhabited1: {
					name: "Inhabited Territory",
					text: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards.",
					revised: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards."
				},
				historic1: {
					name: "Historic Territory",
					text: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards.",
					revised: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards."
				},
				strategic1: {
					name: "Strategic Territory",
					text: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards.",
					revised: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards."
				},
				developed2: {
					name: "Developed Territory",
					text: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards.",
					revised: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards."
				},
				vast2: {
					name: "Vast Territory",
					text: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards.",
					revised: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards."
				},
				wealthy2: {
					name: "Wealthy Territory",
					text: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards.",
					revised: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards."
				},
				inhabited2: {
					name: "Inhabited Territory",
					text: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards.",
					revised: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards."
				},
				historic2: {
					name: "Historic Territory",
					text: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards.",
					revised: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards."
				},
				strategic2: {
					name: "Strategic Territory",
					text: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards.",
					revised: "After colonizing, gain permanent bonuses first, followed by the listed immediate rewards."
				},
				autonomous2: {
					name: "Autonomous Territory",
					text: "Gain 2 yellow bank and 2 blue tokens, then choose 4 science, 5 resources, 6 food, or 7 culture.",
					revised: "Gain 2 yellow bank and 2 blue tokens, then choose 4 science, 5 resources, 6 food, or 7 culture."
				},
				plunder1: {
					name: "Aggression: Plunder",
					text: "Take up to 3 food and resources in total from your rival.",
					revised: "Take up to 3 food and resources in total from your rival."
				},
				raid1: {
					name: "Aggression: Raid",
					text: "Destroy opposing urban buildings within the age limits and gain half their printed costs in resources, rounded up.",
					revised: "Destroy opposing urban buildings within the age limits and gain half their printed costs in resources, rounded up."
				},
				plunder2: {
					name: "Aggression: Plunder",
					text: "Take up to 5 food and resources in total from your rival.",
					revised: "Take up to 5 food and resources in total from your rival."
				},
				raid2: {
					name: "Aggression: Raid",
					text: "Destroy opposing urban buildings within the age limits and gain half their printed costs in resources, rounded up.",
					revised: "Destroy opposing urban buildings within the age limits and gain half their printed costs in resources, rounded up."
				},
				plunder3: {
					name: "Aggression: Plunder",
					text: "Take up to 7 food and resources in total from your rival.",
					revised: "Take up to 7 food and resources in total from your rival."
				},
				raid3: {
					name: "Aggression: Raid",
					text: "Destroy opposing urban buildings within the age limits and gain half their printed costs in resources, rounded up.",
					revised: "Destroy opposing urban buildings within the age limits and gain half their printed costs in resources, rounded up."
				},
				enslave1: {
					name: "Aggression: Enslave",
					text: "Your rival loses 1 population; gain 2 food and 2 resources.",
					revised: "Your rival loses 1 population; gain 2 food and 2 resources."
				},
				spy2: {
					name: "Aggression: Spy",
					text: "Take up to 5 science from your rival.",
					revised: "Take up to 5 science from your rival."
				},
				infiltrate2: {
					name: "Aggression: Infiltrate",
					text: "Remove an opposing leader or unfinished wonder and score science equal to 3 times its level.",
					revised: "Remove an opposing leader or unfinished wonder and score science equal to 3 times its level."
				},
				annex2: {
					name: "Aggression: Annex",
					text: "Take one opposing colony, transferring only its permanent effects.",
					revised: "Take one opposing colony, transferring only its permanent effects."
				},
				intervention3: {
					name: "Aggression: Armed Intervention",
					text: "Take up to 7 culture from your rival.",
					revised: "Take up to 7 culture from your rival."
				},
				kidnap1: {
					name: "Aggression: Kidnap",
					text: "Take one civil card from your rival’s hand under normal taking restrictions; score 3 culture if you play it this turn.",
					revised: "Take one civil card from your rival’s hand under normal taking restrictions; score 3 culture if you play it this turn."
				},
				occupy3: {
					name: "Aggression: Occupy",
					text: "Take up to 3 each of resources, food, science, and culture from your rival.",
					revised: "Take up to 3 each of resources, food, science, and culture from your rival."
				},
				warTerritory2: {
					name: "War over Territory",
					text: "The victor takes 1 yellow bank token, plus 1 per 5 points of strength advantage.",
					revised: "The victor takes 1 yellow bank token, plus 1 per 5 points of strength advantage."
				},
				warTechnology2: {
					name: "War over Technology",
					text: "Take science equal to the strength advantage; special technologies may be stolen instead at their printed science costs.",
					revised: "Take science equal to the strength advantage; special technologies may be stolen instead at their printed science costs."
				},
				warCulture3: {
					name: "War over Culture",
					text: "The victor takes culture equal to the strength advantage plus 5.",
					revised: "The victor takes culture equal to the strength advantage plus 5."
				},
				hybridWar3: {
					name: "Hybrid War",
					text: "Both civilizations lose 2 happy faces until resolution. The victor takes culture equal to the strength advantage.",
					revised: "Both civilizations lose 2 happy faces until resolution. The victor takes culture equal to the strength advantage."
				},
				tradeRoutes1: {
					name: "Trade Routes Agreement",
					text: "A may pay food as resources; B may pay resources as food.",
					revised: "A may pay food as resources; B may pay resources as food."
				},
				openBorders1: {
					name: "Open Borders Agreement",
					text: "Both gain 1 military action; attacking the other gives 2 extra strength.",
					revised: "Both gain 1 military action; attacking the other gives 2 extra strength."
				},
				protection2: {
					name: "Promise of Protection",
					text: "A produces 1 extra culture. B gains 4 strength and produces 1 less culture. Ends if either attacks.",
					revised: "A produces 1 extra culture. B gains 4 strength and produces 1 less culture. Ends if either attacks."
				},
				internationalTrade2: {
					name: "International Trade Agreement",
					text: "A produces 1 extra resource; B produces 1 extra food.",
					revised: "A produces 1 extra resource; B produces 1 extra food."
				},
				scientificCooperation2: {
					name: "Scientific Cooperation",
					text: "Developing a technology costs 2 less science, and the other party must pay 1 science.",
					revised: "Developing a technology costs 2 less science, and the other party must pay 1 science."
				},
				supremacy2: {
					name: "Acceptance of Supremacy",
					text: "Neither may attack the other. A produces 1 extra resource; B produces 1 less.",
					revised: "Neither may attack the other. A produces 1 extra resource; B produces 1 less."
				},
				militaryAlliance3: {
					name: "Military Alliance",
					text: "Both gain 3 strength. Ends if either attacks.",
					revised: "Both gain 3 strength. Ends if either attacks."
				},
				tourism3: {
					name: "International Tourism",
					text: "Each produces extra culture equal to the other’s completed wonders.",
					revised: "Each produces extra culture equal to the other’s completed wonders."
				},
				peaceTreaty3: {
					name: "Peace Treaty",
					text: "Neither may attack the other. Both produce 1 extra culture.",
					revised: "Neither may attack the other. Both produce 1 extra culture."
				},
				sovereignty3: {
					name: "Loss of Sovereignty",
					text: "Neither may attack the other. A produces 2 extra culture and B 2 less. No one may declare war on B.",
					revised: "Neither may attack the other. A produces 2 extra culture and B 2 less. No one may declare war on B."
				},
				navalTrade1: {
					name: "Naval Trade Agreement",
					text: "A gains 1 happy face and loses 1 blue token; B gains 2 blue tokens.",
					revised: "A gains 1 happy face and loses 1 blue token; B gains 2 blue tokens."
				}
			}
		}
	}
};
//#endregion
export { $r as default };
