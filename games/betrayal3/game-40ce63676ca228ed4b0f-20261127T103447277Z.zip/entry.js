import { z as e } from "zod";
import { randomIntAt as t } from "@bgparty/sdk/engine/prng";
import { AVATARS as n } from "@bgparty/sdk/avatars";
import { Fragment as r, jsx as i, jsxs as a } from "react/jsx-runtime";
import { useEffect as o, useRef as s, useState as c } from "react";
import { useT as l } from "@bgparty/sdk/i18n";
import { IconCheck as u, IconClose as d, IconHistory as f, IconInfo as p, IconRotate as ee, IconZoomIn as te, IconZoomOut as ne } from "@bgparty/sdk/icons";
import { useWakeLock as re } from "@bgparty/sdk/use-wake-lock";
import { SheetFxProbe as ie, SheetView as ae } from "@bgparty/sdk/sheet-view";
import { useFxAnchor as oe } from "@bgparty/sdk/fx/anchors";
import { playTurn as se, useSoundEdge as ce } from "@bgparty/sdk/sfx";
import { GameScreen as le } from "@bgparty/sdk/ui/game-screen";
import { Flash as ue, Floater as m, FlySprite as de, PulseBox as fe } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as pe, OptionSection as me } from "@bgparty/sdk/ui/game-options";
//#region src/game/meta.ts
var he = {
	id: "betrayal3",
	uuid: "33c7fe71-dee9-4ca3-9a92-22ccff33475e",
	mechanics: [
		"dice-rolling",
		"tile-placement",
		"grid-movement"
	],
	interactionTags: [
		"cooperative",
		"team-based",
		"hidden-roles"
	],
	tier: "alpha",
	nameKey: "games.betrayal3.name",
	descKey: "games.betrayal3.desc",
	rulesKey: "games.betrayal3.rules",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/1830158443003502620/3B6207DDA9C8E2D3DF60EBB732D15B4D0FD8BC96/" },
	icon: "🏚️",
	iconImg: "games/betrayal3.webp",
	minPlayers: 3,
	maxPlayers: 6,
	bestPlayers: [5, 6],
	accent: "#bca457",
	releasedAt: "2026-11-04T12:56:00+08:00",
	search: {
		py: "shan zhong xiao wu shan wu jing hun lin zhong xiao wu di san ban",
		init: "szxw swjh lzxw dsb"
	},
	hotseat: "cover"
}, ge = e.string(), _e = e.object({
	might: e.number(),
	speed: e.number(),
	sanity: e.number(),
	knowledge: e.number()
}), ve = e.object({
	scenario: e.enum([
		"paranormalInvestigators",
		"strangeDisappearance",
		"forSale",
		"mysteriousInvitation",
		"cursed",
		"howlAtTheMoon",
		"holidayHouse",
		"comeHomeToEvil"
	]).default("paranormalInvestigators"),
	stranger: e.enum(["elf", "jingleklaws"]).default("elf")
}).default({
	scenario: "paranormalInvestigators",
	stranger: "elf"
}), ye = e.discriminatedUnion("type", [
	e.object({
		type: e.literal("act"),
		id: e.string().max(300)
	}),
	e.object({ type: e.literal("ack") }),
	e.object({
		type: e.literal("tick"),
		now: e.number()
	})
]), be = e.object({
	key: e.string(),
	order: e.number(),
	actor: ge.optional(),
	target: ge.optional(),
	n: e.number().optional(),
	id: e.string().optional()
}), xe = e.object({
	phase: e.enum([
		"characters",
		"explore",
		"haunt",
		"done"
	]),
	scenario: e.string(),
	turn: ge,
	turnNumber: e.number(),
	movement: e.number(),
	explorers: e.array(e.object({
		rid: ge,
		character: e.string(),
		traits: _e,
		values: _e,
		room: e.string(),
		dead: e.boolean(),
		cards: e.array(e.string()),
		revealed: e.boolean(),
		team: e.string(),
		statuses: e.array(e.string())
	})),
	rooms: e.array(e.object({
		id: e.string(),
		tile: e.string(),
		floor: e.enum([
			"U",
			"G",
			"B"
		]),
		x: e.number(),
		y: e.number(),
		rotation: e.number(),
		condition: e.enum([
			"wrecked",
			"flooded",
			"burning",
			"consumed"
		]).optional()
	})),
	monsters: e.array(e.object({
		id: e.string(),
		kind: e.string(),
		room: e.string(),
		traits: _e,
		stunned: e.boolean(),
		dead: e.boolean(),
		identity: e.string().nullable(),
		number: e.number().nullable()
	})),
	tokens: e.array(e.object({
		id: e.string(),
		kind: e.string(),
		room: e.string().nullable(),
		holder: ge.nullable(),
		value: e.number().nullable(),
		trait: e.string().nullable(),
		hidden: e.boolean(),
		identity: e.string().nullable()
	})),
	haunt: e.object({
		id: e.string(),
		revealer: ge,
		traitor: ge.nullable(),
		hidden: e.boolean(),
		track: e.number(),
		counters: e.record(e.string(), e.number())
	}).nullable(),
	pending: e.object({
		actor: ge.nullable(),
		key: e.string(),
		params: e.record(e.string(), e.union([e.string(), e.number()])).optional()
	}).nullable(),
	roll: e.object({
		actor: ge,
		trait: e.string().nullable(),
		dice: e.array(e.number()),
		bonus: e.number(),
		context: e.string()
	}).nullable(),
	decks: e.object({
		tiles: e.number(),
		items: e.number(),
		omens: e.number(),
		events: e.number(),
		encounters: e.number(),
		omenDraws: e.number()
	}),
	journal: e.array(be),
	winners: e.array(ge).nullable(),
	ending: e.string().nullable(),
	discovery: e.object({
		tile: e.string(),
		floor: e.enum([
			"U",
			"G",
			"B"
		]),
		x: e.number(),
		y: e.number(),
		entrance: e.number(),
		from: e.string()
	}).nullable(),
	trade: e.object({
		actor: ge,
		target: ge,
		give: e.array(e.string()),
		take: e.array(e.string()),
		dog: e.boolean()
	}).nullable(),
	reveal: e.object({
		id: e.string(),
		kind: e.enum([
			"item",
			"omen",
			"event",
			"encounter"
		]),
		actor: ge,
		acks: e.array(ge),
		required: e.array(ge)
	}).nullable()
}), Se = e.object({
	actingPiece: e.string().nullable(),
	pending: e.object({
		key: e.string(),
		params: e.record(e.string(), e.union([e.string(), e.number()])).optional()
	}).nullable(),
	choices: e.array(e.object({
		id: e.string(),
		key: e.string(),
		params: e.record(e.string(), e.union([e.string(), e.number()])).optional(),
		kind: e.enum([
			"action",
			"room",
			"character",
			"card",
			"trait",
			"player",
			"token",
			"rotation"
		]),
		target: e.string().optional(),
		value: e.number().optional()
	})),
	secret: e.record(e.string(), e.union([
		e.string(),
		e.number(),
		e.boolean(),
		e.null(),
		e.array(e.union([
			e.string(),
			e.number(),
			e.boolean(),
			e.null()
		]))
	])),
	team: e.string(),
	objective: e.string().nullable(),
	journal: e.array(be),
	canAck: e.boolean()
}), Ce = [
	{
		id: "conservatory",
		floors: "G",
		doors: "NS",
		symbol: "item",
		expansion: "base"
	},
	{
		id: "armory",
		floors: "GB",
		doors: "NE",
		symbol: null,
		expansion: "base"
	},
	{
		id: "bloodyRoom",
		floors: "UG",
		doors: "NS",
		symbol: "item",
		expansion: "base"
	},
	{
		id: "catacombs",
		floors: "B",
		doors: "NESW",
		symbol: "omen",
		expansion: "base"
	},
	{
		id: "charredRoom",
		floors: "UG",
		doors: "NE",
		symbol: "omen",
		expansion: "base"
	},
	{
		id: "ritualRoom",
		floors: "B",
		doors: "NE",
		symbol: "omen",
		expansion: "base"
	},
	{
		id: "kitchen",
		floors: "G",
		doors: "NS",
		symbol: "event",
		expansion: "base"
	},
	{
		id: "ballroom",
		floors: "G",
		doors: "NESW",
		symbol: "omen",
		expansion: "base"
	},
	{
		id: "junkRoom",
		floors: "UG",
		doors: "NES",
		symbol: "item",
		expansion: "base"
	},
	{
		id: "panicRoom",
		floors: "B",
		doors: "N",
		symbol: "omen",
		expansion: "base"
	},
	{
		id: "laundryChute",
		floors: "G",
		doors: "N",
		symbol: null,
		expansion: "base"
	},
	{
		id: "laboratory",
		floors: "G",
		doors: "NE",
		symbol: "event",
		expansion: "base"
	},
	{
		id: "chapel",
		floors: "G",
		doors: "NS",
		symbol: null,
		expansion: "base"
	},
	{
		id: "soundproofedRoom",
		floors: "UB",
		doors: "NES",
		symbol: "omen",
		expansion: "base"
	},
	{
		id: "salon",
		floors: "UG",
		doors: "NE",
		symbol: "event",
		expansion: "base"
	},
	{
		id: "specimenRoom",
		floors: "UG",
		doors: "EW",
		symbol: "omen",
		expansion: "base"
	},
	{
		id: "secretStaircase",
		floors: "B",
		doors: "N",
		symbol: null,
		expansion: "base"
	},
	{
		id: "library",
		floors: "UG",
		doors: "NES",
		symbol: "omen",
		expansion: "base"
	},
	{
		id: "undergroundLake",
		floors: "B",
		doors: "NE",
		symbol: "event",
		expansion: "base"
	},
	{
		id: "statuaryCorridor",
		floors: "U",
		doors: "NS",
		symbol: "event",
		expansion: "base"
	},
	{
		id: "nursery",
		floors: "UB",
		doors: "NE",
		symbol: "omen",
		expansion: "base"
	},
	{
		id: "tower",
		floors: "U",
		doors: "NS",
		symbol: "event",
		expansion: "base"
	},
	{
		id: "crawlspace",
		floors: "UB",
		doors: "NEW",
		symbol: "event",
		expansion: "base"
	},
	{
		id: "operatingTheatre",
		floors: "UB",
		doors: "NE",
		symbol: "item",
		expansion: "base"
	},
	{
		id: "gameRoom",
		floors: "UB",
		doors: "NESW",
		symbol: "item",
		expansion: "base"
	},
	{
		id: "larder",
		floors: "G",
		doors: "NW",
		symbol: null,
		expansion: "base"
	},
	{
		id: "observatory",
		floors: "U",
		doors: "NS",
		symbol: "omen",
		expansion: "base"
	},
	{
		id: "diningRoom",
		floors: "G",
		doors: "NESW",
		symbol: "event",
		expansion: "base"
	},
	{
		id: "gymnasium",
		floors: "GB",
		doors: "NW",
		symbol: null,
		expansion: "base"
	},
	{
		id: "undergroundCavern",
		floors: "B",
		doors: "NESW",
		symbol: "event",
		expansion: "base"
	},
	{
		id: "organRoom",
		floors: "UB",
		doors: "ES",
		symbol: "event",
		expansion: "base"
	},
	{
		id: "vault",
		floors: "B",
		doors: "N",
		symbol: "item2",
		expansion: "base"
	},
	{
		id: "primaryBedroom",
		floors: "UG",
		doors: "NES",
		symbol: "omen",
		expansion: "base"
	},
	{
		id: "winterBedroom",
		floors: "UG",
		doors: "NE",
		symbol: "omen",
		expansion: "base"
	},
	{
		id: "mysticElevator",
		floors: "UGB",
		doors: "N",
		symbol: null,
		expansion: "base"
	},
	{
		id: "chasm",
		floors: "B",
		doors: "NS",
		symbol: "event",
		expansion: "base"
	},
	{
		id: "gallery",
		floors: "U",
		doors: "NS",
		symbol: "event",
		expansion: "base"
	},
	{
		id: "crampedPassageway",
		floors: "UGB",
		doors: "NESW",
		symbol: "event",
		expansion: "base"
	},
	{
		id: "graveyard",
		floors: "G",
		doors: "NE",
		symbol: "omen",
		expansion: "base"
	},
	{
		id: "furnaceRoom",
		floors: "B",
		doors: "ESW",
		symbol: "event",
		expansion: "base"
	},
	{
		id: "guestQuarters",
		floors: "UG",
		doors: "NE",
		symbol: "event",
		expansion: "base"
	},
	{
		id: "collapsedRoom",
		floors: "UG",
		doors: "NE",
		symbol: null,
		expansion: "base"
	},
	{
		id: "groundStaircase",
		floors: "G",
		doors: "E",
		symbol: null,
		expansion: "base"
	},
	{
		id: "hallway",
		floors: "G",
		doors: "NESW",
		symbol: null,
		expansion: "base"
	},
	{
		id: "entranceHall",
		floors: "G",
		doors: "NSW",
		symbol: null,
		expansion: "base"
	},
	{
		id: "upperLanding",
		floors: "U",
		doors: "NESW",
		symbol: null,
		expansion: "base"
	},
	{
		id: "basementLanding",
		floors: "B",
		doors: "NESW",
		symbol: null,
		expansion: "base"
	},
	{
		id: "oubliette",
		floors: "B",
		doors: "N",
		symbol: "event",
		expansion: "blood"
	},
	{
		id: "trophyRoom",
		floors: "G",
		doors: "NE",
		symbol: "item",
		expansion: "blood"
	},
	{
		id: "timeLostTree",
		floors: "U",
		doors: "NS",
		symbol: "event",
		expansion: "yuletide"
	},
	{
		id: "rootCellar",
		floors: "B",
		doors: "N",
		symbol: "omen",
		expansion: "yuletide"
	},
	{
		id: "ancientDen",
		floors: "B",
		doors: "NESW",
		symbol: "omen",
		expansion: "pennywise"
	},
	{
		id: "windingTunnels",
		floors: "B",
		doors: "NESW",
		symbol: null,
		expansion: "pennywise"
	},
	{
		id: "darkenedHallway",
		floors: "UGB",
		doors: "EW",
		symbol: "event2",
		expansion: "pennywise"
	},
	{
		id: "oldWell",
		floors: "B",
		doors: "NE",
		symbol: "item",
		expansion: "pennywise"
	}
], we = [
	{
		id: "isa",
		age: 11,
		birthday: "03-30",
		group: "yellow",
		tracks: {
			might: [
				2,
				3,
				3,
				3,
				4,
				5,
				6,
				7
			],
			speed: [
				4,
				4,
				5,
				5,
				6,
				7,
				8,
				8
			],
			knowledge: [
				2,
				3,
				4,
				4,
				5,
				6,
				6,
				6
			],
			sanity: [
				2,
				3,
				4,
				5,
				6,
				7,
				7,
				8
			]
		},
		start: {
			might: 3,
			speed: 3,
			knowledge: 2,
			sanity: 2
		}
	},
	{
		id: "anita",
		age: 12,
		birthday: "06-11",
		group: "yellow",
		tracks: {
			might: [
				2,
				2,
				3,
				4,
				4,
				5,
				6,
				7
			],
			speed: [
				2,
				3,
				4,
				4,
				5,
				6,
				7,
				8
			],
			knowledge: [
				4,
				4,
				5,
				5,
				6,
				7,
				8,
				8
			],
			sanity: [
				2,
				2,
				3,
				4,
				5,
				5,
				6,
				6
			]
		},
		start: {
			might: 3,
			speed: 2,
			knowledge: 3,
			sanity: 2
		}
	},
	{
		id: "jaden",
		age: 11,
		birthday: "10-04",
		group: "green",
		tracks: {
			might: [
				2,
				3,
				3,
				3,
				4,
				5,
				6,
				7
			],
			speed: [
				3,
				4,
				4,
				4,
				5,
				6,
				7,
				8
			],
			knowledge: [
				3,
				3,
				4,
				5,
				5,
				6,
				6,
				7
			],
			sanity: [
				3,
				3,
				4,
				5,
				5,
				6,
				7,
				8
			]
		},
		start: {
			might: 3,
			speed: 2,
			knowledge: 3,
			sanity: 2
		}
	},
	{
		id: "sammy",
		age: 9,
		birthday: "09-18",
		group: "green",
		tracks: {
			might: [
				3,
				3,
				4,
				4,
				5,
				5,
				6,
				8
			],
			speed: [
				2,
				3,
				4,
				4,
				5,
				6,
				7,
				8
			],
			knowledge: [
				2,
				3,
				3,
				4,
				5,
				6,
				7,
				8
			],
			sanity: [
				2,
				3,
				4,
				4,
				5,
				6,
				6,
				7
			]
		},
		start: {
			might: 2,
			speed: 4,
			knowledge: 2,
			sanity: 3
		}
	},
	{
		id: "oliver",
		age: 33,
		birthday: "07-03",
		group: "red",
		tracks: {
			might: [
				3,
				3,
				4,
				4,
				5,
				6,
				6,
				7
			],
			speed: [
				3,
				3,
				4,
				5,
				5,
				6,
				7,
				8
			],
			knowledge: [
				3,
				3,
				3,
				4,
				5,
				6,
				6,
				7
			],
			sanity: [
				2,
				3,
				3,
				4,
				5,
				5,
				6,
				7
			]
		},
		start: {
			might: 2,
			speed: 3,
			knowledge: 3,
			sanity: 2
		}
	},
	{
		id: "josef",
		age: 25,
		birthday: "02-25",
		group: "red",
		tracks: {
			might: [
				4,
				4,
				4,
				5,
				6,
				7,
				8,
				8
			],
			speed: [
				2,
				2,
				3,
				4,
				5,
				6,
				7,
				8
			],
			knowledge: [
				2,
				2,
				3,
				3,
				5,
				5,
				6,
				6
			],
			sanity: [
				2,
				3,
				4,
				4,
				5,
				5,
				6,
				6
			]
		},
		start: {
			might: 3,
			speed: 3,
			knowledge: 2,
			sanity: 2
		}
	},
	{
		id: "warren",
		age: 71,
		birthday: "11-17",
		group: "white",
		tracks: {
			might: [
				2,
				2,
				3,
				3,
				4,
				5,
				6,
				6
			],
			speed: [
				2,
				3,
				4,
				4,
				5,
				5,
				6,
				6
			],
			knowledge: [
				3,
				3,
				4,
				5,
				5,
				6,
				7,
				8
			],
			sanity: [
				3,
				3,
				3,
				4,
				5,
				6,
				7,
				8
			]
		},
		start: {
			might: 3,
			speed: 2,
			knowledge: 2,
			sanity: 4
		}
	},
	{
		id: "dan",
		age: 60,
		birthday: "05-06",
		group: "white",
		tracks: {
			might: [
				3,
				3,
				4,
				4,
				5,
				5,
				6,
				7
			],
			speed: [
				2,
				3,
				3,
				4,
				5,
				6,
				7,
				7
			],
			knowledge: [
				3,
				3,
				4,
				5,
				5,
				6,
				7,
				8
			],
			sanity: [
				2,
				3,
				4,
				4,
				5,
				6,
				7,
				8
			]
		},
		start: {
			might: 2,
			speed: 2,
			knowledge: 4,
			sanity: 3
		}
	},
	{
		id: "persephone",
		age: 49,
		birthday: "04-15",
		group: "blue",
		tracks: {
			might: [
				3,
				3,
				4,
				5,
				6,
				6,
				7,
				7
			],
			speed: [
				3,
				3,
				4,
				4,
				5,
				6,
				7,
				8
			],
			knowledge: [
				2,
				3,
				3,
				4,
				5,
				6,
				6,
				7
			],
			sanity: [
				3,
				3,
				4,
				5,
				6,
				7,
				8,
				8
			]
		},
		start: {
			might: 2,
			speed: 3,
			knowledge: 2,
			sanity: 3
		}
	},
	{
		id: "stephanie",
		age: 40,
		birthday: "01-12",
		group: "blue",
		tracks: {
			might: [
				2,
				3,
				3,
				4,
				5,
				5,
				6,
				6
			],
			speed: [
				2,
				3,
				3,
				5,
				5,
				6,
				6,
				7
			],
			knowledge: [
				2,
				3,
				4,
				4,
				4,
				5,
				6,
				6
			],
			sanity: [
				4,
				4,
				5,
				5,
				6,
				7,
				8,
				8
			]
		},
		start: {
			might: 3,
			speed: 2,
			knowledge: 2,
			sanity: 3
		}
	},
	{
		id: "brittani",
		age: 22,
		birthday: "12-01",
		group: "purple",
		tracks: {
			might: [
				3,
				3,
				4,
				5,
				6,
				7,
				7,
				8
			],
			speed: [
				2,
				3,
				3,
				4,
				4,
				5,
				6,
				6
			],
			knowledge: [
				3,
				3,
				4,
				5,
				5,
				6,
				6,
				7
			],
			sanity: [
				3,
				3,
				4,
				4,
				5,
				6,
				6,
				7
			]
		},
		start: {
			might: 3,
			speed: 2,
			knowledge: 2,
			sanity: 2
		}
	},
	{
		id: "michelle",
		age: 19,
		birthday: "08-19",
		group: "purple",
		tracks: {
			might: [
				2,
				3,
				4,
				4,
				5,
				6,
				7,
				8
			],
			speed: [
				3,
				3,
				4,
				5,
				6,
				6,
				7,
				8
			],
			knowledge: [
				2,
				3,
				3,
				4,
				5,
				6,
				7,
				8
			],
			sanity: [
				2,
				3,
				3,
				4,
				5,
				6,
				6,
				6
			]
		},
		start: {
			might: 4,
			speed: 2,
			knowledge: 3,
			sanity: 2
		}
	},
	{
		id: "sara",
		age: 19,
		birthday: "07-14",
		group: "silver",
		tracks: {
			might: [
				2,
				3,
				3,
				4,
				5,
				6,
				6,
				7
			],
			speed: [
				2,
				3,
				4,
				5,
				5,
				6,
				7,
				8
			],
			knowledge: [
				4,
				4,
				4,
				4,
				5,
				6,
				7,
				8
			],
			sanity: [
				2,
				3,
				3,
				4,
				5,
				6,
				7,
				8
			]
		},
		start: {
			might: 2,
			speed: 2,
			knowledge: 2,
			sanity: 3
		}
	},
	{
		id: "werewolf",
		age: 19,
		birthday: "07-14",
		group: "silver",
		tracks: {
			might: [
				4,
				4,
				4,
				4,
				5,
				6,
				7,
				8
			],
			speed: [
				3,
				4,
				5,
				6,
				7,
				7,
				8,
				8
			],
			knowledge: [
				2,
				3,
				3,
				3,
				4,
				5,
				6,
				7
			],
			sanity: [
				2,
				2,
				2,
				4,
				5,
				6,
				7,
				8
			]
		},
		start: {
			might: 2,
			speed: 2,
			knowledge: 2,
			sanity: 3
		}
	},
	{
		id: "elf",
		age: null,
		birthday: null,
		group: "green",
		tracks: {
			might: [
				3,
				4,
				4,
				5,
				6,
				6,
				7,
				7
			],
			speed: [
				3,
				4,
				5,
				6,
				7,
				7,
				8,
				8
			],
			knowledge: [
				3,
				4,
				4,
				4,
				5,
				6,
				7,
				8
			],
			sanity: [
				3,
				3,
				4,
				4,
				5,
				5,
				6,
				7
			]
		},
		start: {
			might: 2,
			speed: 2,
			knowledge: 2,
			sanity: 2
		}
	},
	{
		id: "jingleklaws",
		age: null,
		birthday: null,
		group: "green",
		tracks: {
			might: [
				2,
				3,
				3,
				4,
				5,
				6,
				7,
				8
			],
			speed: [
				3,
				4,
				4,
				5,
				6,
				6,
				7,
				7
			],
			knowledge: [
				3,
				4,
				4,
				4,
				5,
				6,
				7,
				8
			],
			sanity: [
				2,
				3,
				3,
				4,
				5,
				6,
				7,
				8
			]
		},
		start: {
			might: 3,
			speed: 2,
			knowledge: 2,
			sanity: 3
		}
	}
], Te = [
	"machete",
	"crossbow",
	"firstAidKit",
	"mirror",
	"angelsFeather",
	"strangeMedicine",
	"mysticalStopwatch",
	"skeletonKey",
	"strangeAmulet",
	"dynamite",
	"magicCamera",
	"headphones",
	"gun",
	"rabbitsFoot",
	"flashlight",
	"luckyCoin",
	"map",
	"necklaceOfTeeth",
	"brooch",
	"leatherJacket",
	"chainsaw",
	"creepyDoll"
], h = [
	"dog",
	"holySymbol",
	"idol",
	"dagger",
	"ring",
	"skull",
	"book",
	"armor",
	"mask"
], Ee = /* @__PURE__ */ "secretElevator.creakingDoor.cryForHelp.momentOfHope.darkStormyNight.spiders.meatMoss.eerieFeeling.hangedMen.poorYorick.impossibleArchitecture.alienGeometry.bite.funeral.jonahsTurn.flickeringLights.flowering.fullTable.deepestCloset.burningFigure.behindYou.clownRoom.radioBroadcast.tinyRobot.taxidermy.severedHand.phoneCall.batOutOfHell.sayCheese.mysteriousFluid.splashOfCrimson.forbiddenKnowledge.vialOfDust.cassettePlayer.eerieMirror.oldestHouse.jarOfOrgans.technicalDifficulties.wanderingGhost.starsAtNight.brainFood.secretPassage.houseIsHungry".split("."), De = [
	"floatingLights",
	"knifeInDark",
	"bloodTendrils",
	"goodBoy",
	"popOfRed",
	"hometownHorrors",
	"swirlingVisions",
	"stretchingHall",
	"timeToSink",
	"eaterOfWorlds"
], Oe = [
	{
		id: "paranormalInvestigators",
		haunts: [
			"28",
			"47",
			"18",
			"42",
			"16",
			"15",
			"31",
			"32",
			"5"
		],
		traitors: [
			"revealer",
			"revealer",
			"revealer",
			"revealer",
			"revealer",
			"revealer",
			"revealer",
			"revealer",
			"none"
		],
		expansion: "base"
	},
	{
		id: "strangeDisappearance",
		haunts: [
			"34",
			"25",
			"30",
			"43",
			"21",
			"11",
			"13",
			"35",
			"44"
		],
		traitors: [
			"highestKnowledge",
			"leftOfRevealer",
			"lowestSanityExceptRevealer",
			"mostOmens",
			"revealer",
			"freeForAll",
			"revealer",
			"revealer",
			"leftOfRevealer"
		],
		expansion: "base"
	},
	{
		id: "forSale",
		haunts: [
			"41",
			"10",
			"29",
			"4",
			"14",
			"49",
			"36",
			"22",
			"40"
		],
		traitors: [
			"revealer",
			"freeForAll",
			"revealer",
			"none",
			"leftOfRevealer",
			"revealer",
			"lowestSanity",
			"leftOfRevealer",
			"revealer"
		],
		expansion: "base"
	},
	{
		id: "mysteriousInvitation",
		haunts: [
			"9",
			"37",
			"38",
			"8",
			"45",
			"6",
			"26",
			"48",
			"24"
		],
		traitors: [
			"freeForAll",
			"revealer",
			"revealer",
			"none",
			"revealer",
			"hidden",
			"revealer",
			"highestMight",
			"highestSpeed"
		],
		expansion: "base"
	},
	{
		id: "cursed",
		haunts: [
			"23",
			"50",
			"2",
			"20",
			"39",
			"17",
			"19",
			"46",
			"27"
		],
		traitors: [
			"revealer",
			"revealer",
			"hidden",
			"oldestCharacter",
			"highestKnowledgeExceptRevealer",
			"revealer",
			"revealer",
			"revealer",
			"revealer"
		],
		expansion: "base"
	},
	{
		id: "howlAtTheMoon",
		haunts: [
			"blood3",
			"blood4",
			"blood1",
			"blood1",
			"blood5",
			"blood4",
			"blood2",
			"blood2",
			"blood5"
		],
		traitors: [
			"none",
			"hidden",
			"sara",
			"sara",
			"saraSeeObjective",
			"hidden",
			"revealerExceptSaraUseLeft",
			"revealerExceptSaraUseLeft",
			"saraSeeObjective"
		],
		expansion: "blood"
	},
	{
		id: "holidayHouse",
		haunts: [
			"yuletide3",
			"yuletide1",
			"yuletide3",
			"yuletide5",
			"yuletide4",
			"yuletide5",
			"yuletide2",
			"yuletide4",
			"yuletide2"
		],
		traitors: [
			"leftOfStranger",
			"none",
			"leftOfStranger",
			"leftOfStranger",
			"stranger",
			"leftOfStranger",
			"stranger",
			"stranger",
			"stranger"
		],
		expansion: "yuletide"
	},
	{
		id: "comeHomeToEvil",
		haunts: [],
		traitors: [],
		expansion: "pennywise"
	}
], ke = [
	"idol",
	"armor",
	"ring",
	"dog",
	"book",
	"dagger",
	"holySymbol",
	"skull",
	"mask"
], Ae = {
	popOfRed: "pennywise1",
	knifeInDark: "pennywise1",
	stretchingHall: "pennywise2",
	bloodTendrils: "pennywise2",
	goodBoy: "pennywise3",
	timeToSink: "pennywise3",
	swirlingVisions: "pennywise4",
	floatingLights: "pennywise4",
	eaterOfWorlds: "pennywise5",
	hometownHorrors: "pennywise5"
}, je = /* @__PURE__ */ new Set([
	"machete",
	"crossbow",
	"dynamite",
	"gun",
	"chainsaw",
	"dagger",
	"ring"
]), g = (e) => Ce.find((t) => t.id === e), Me = (e) => we.find((t) => t.id === e), _ = (e) => Oe.find((t) => t.id === e), Ne = [
	"N",
	"E",
	"S",
	"W"
], Pe = [
	[0, -1],
	[1, 0],
	[0, 1],
	[-1, 0]
];
function v(e) {
	return e.split(":")[0];
}
function y(e, t) {
	return e.rooms.find((e) => e.id === v(t));
}
function Fe(e) {
	return e.condition ? [
		0,
		1,
		2,
		3
	] : [...g(e.tile).doors].map((t) => (Ne.indexOf(t) + e.rotation) % 4);
}
function Ie(e, t) {
	if (e.tile !== "windingTunnels" || e.condition) return e.id;
	let n = (t - e.rotation + 4) % 4;
	return `${e.id}:${n < 2 ? "a" : "b"}`;
}
function b(e) {
	return e.tile === "windingTunnels" && !e.condition ? [`${e.id}:a`, `${e.id}:b`] : [e.id];
}
function Le(e, t, n, r) {
	return e.rooms.find((e) => e.floor === t && e.x === n && e.y === r);
}
function Re(e, t, n = !1) {
	let r = y(e, t);
	if (!r) return [];
	let i = [];
	for (let a = 0; a < 4; a++) {
		if (r.tile === "windingTunnels" && Ie(r, a) !== t) continue;
		let [o, s] = Pe[a], c = Le(e, r.floor, r.x + o, r.y + s);
		c && (n || Fe(r).includes(a) && Fe(c).includes((a + 2) % 4)) && i.push(Ie(c, (a + 2) % 4));
	}
	return i;
}
var ze = [
	["groundStaircase", "upperLanding"],
	["hallway", "secretStaircase"],
	["graveyard", "undergroundCavern"],
	["oubliette", "trophyRoom"],
	["timeLostTree", "rootCellar"]
];
function x(e, t, n = !1, r = !1) {
	let i = Re(e, t, r);
	for (let n of ze) {
		if (!n.includes(t)) continue;
		let r = n[0] === t ? n[1] : n[0], a = e.haunt?.id === "44" && n[0] === "groundStaircase";
		(!y(e, t)?.condition || a) && e.rooms.some((e) => e.id === r && (!e.condition || a)) && i.push(r);
	}
	t === "gallery" && !y(e, t)?.condition && e.rooms.some((e) => e.id === "ballroom") && i.push("ballroom"), t === "laundryChute" && !y(e, t)?.condition && i.push("basementLanding"), (n || e.haunt?.id === "44") && t === "groundStaircase" && i.push("basementLanding"), (n || e.haunt?.id === "44") && t === "basementLanding" && i.push("groundStaircase"), v(t) === "windingTunnels" && !y(e, t).condition && i.push(t.endsWith(":a") ? "windingTunnels:b" : "windingTunnels:a");
	let a = e.tokens.filter((e) => e.kind === "secretPassage" && e.room);
	if (a.some((e) => e.room === t)) for (let e of a) e.room !== t && i.push(e.room);
	return [...new Set(i)];
}
function S(e, t, n) {
	if (t === n) return !0;
	let r = y(e, t), i = y(e, n);
	if (!r || !i || r.floor !== i.floor || r.x !== i.x && r.y !== i.y || r.tile === "windingTunnels" && !r.condition || i.tile === "windingTunnels" && !i.condition) return !1;
	let a = r.x === i.x ? i.y > r.y ? 2 : 0 : i.x > r.x ? 1 : 3, [o, s] = Pe[a], c = r;
	for (let t = 0; t < e.rooms.length; t++) {
		if (!Fe(c).includes(a)) return !1;
		let t = Le(e, r.floor, c.x + o, c.y + s);
		if (!t || t.tile === "windingTunnels" && !t.condition || !Fe(t).includes((a + 2) % 4)) return !1;
		if (t.id === i.id) return !0;
		c = t;
	}
	return !1;
}
function Be(e, t, n, r = !1, i = !1) {
	let a = [[t]], o = /* @__PURE__ */ new Set([t]);
	for (; a.length;) {
		let t = a.shift(), s = t[t.length - 1];
		if (s === n) return t;
		for (let n of x(e, s, r, i)) o.has(n) || (o.add(n), a.push([...t, n]));
	}
	return null;
}
function C(e, t, n, r = !1) {
	let i = Be(e, t, n, r);
	return i ? i.length - 1 : Infinity;
}
function Ve(e, t, n) {
	return e.rooms.filter((e) => e.floor === t).flatMap((r) => Fe(r).flatMap((i) => {
		if (n && Ie(r, i) !== n) return [];
		let [a, o] = Pe[i];
		return Le(e, t, r.x + a, r.y + o) ? [] : [{
			room: Ie(r, i),
			direction: i,
			x: r.x + a,
			y: r.y + o
		}];
	}));
}
function He(e, t, n, r, i, a) {
	return [
		0,
		1,
		2,
		3
	].filter((o) => {
		let s = {
			id: t,
			tile: t,
			floor: n,
			x: r,
			y: i,
			rotation: o
		};
		return Fe(s).includes((a + 2) % 4) ? Ve({
			...e,
			rooms: [...e.rooms, s]
		}, n).length > 0 : !1;
	});
}
var Ue = [
	"groundStaircase",
	"hallway",
	"entranceHall"
];
function We(e, t, n, r, i) {
	let a = y(e, t), o = Ue.includes(t);
	return e.rooms.map((e) => o && Ue.includes(e.id) ? {
		...e,
		x: e.x + n - a.x,
		y: e.y + r - a.y
	} : e.id === t ? {
		...e,
		x: n,
		y: r,
		rotation: i
	} : { ...e });
}
function Ge(e, t) {
	let n = /* @__PURE__ */ new Set([t]), r = [t];
	for (; r.length;) for (let t of x(e, r.shift())) n.has(t) || (n.add(t), r.push(t));
	return n;
}
function Ke(e, t) {
	if (new Set(t.map((e) => `${e.floor}:${e.x}:${e.y}`)).size !== t.length) return !1;
	let n = {
		...e,
		rooms: t
	}, r = new Set(e.rooms.flatMap(b));
	for (; r.size;) {
		let t = r.values().next().value, i = Ge(e, t), a = Ge(n, t);
		for (let e of i) {
			if (!a.has(e)) return !1;
			r.delete(e);
		}
	}
	return !0;
}
function qe(e, t) {
	let n = y(e, t), r = e.rooms.filter((e) => e.floor === n.floor), i = [], a = Math.min(...r.map((e) => e.x)) - 1, o = Math.max(...r.map((e) => e.x)) + 1, s = Math.min(...r.map((e) => e.y)) - 1, c = Math.max(...r.map((e) => e.y)) + 1;
	for (let r = a; r <= o; r++) for (let a = s; a <= c; a++) if (r !== n.x || a !== n.y) for (let o of Ue.includes(t) ? [n.rotation] : [
		0,
		1,
		2,
		3
	]) Ke(e, We(e, t, r, a, o)) && i.push({
		x: r,
		y: a,
		rotation: o
	});
	return i;
}
//#endregion
//#region src/game/model.ts
var w = [
	"might",
	"speed",
	"sanity",
	"knowledge"
], Je = {
	move: 420,
	place: 550,
	draw: 700,
	roll: 1200,
	resolve: 1e3,
	haunt: 1500
};
function Ye(e, n) {
	return t(e.seed, e.cursor++, n);
}
function T(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; t--) {
		let r = Ye(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
function E(e, t) {
	return e.explorers.find((e) => e.rid === t);
}
function Xe(e, t) {
	return E(e, t) ?? E(e, R(e.monsters.find((e) => e.id === t)?.flags, "itemsOwner"));
}
function Ze(e) {
	return _(e.config.scenario).expansion;
}
function D(e) {
	return e.explorers.filter((e) => !e.dead);
}
function O(e) {
	return D(e).filter((e) => e.team === "hero");
}
function Qe(e, t) {
	return e.players[(e.players.indexOf(t) + 1) % e.players.length];
}
function $e(e, t) {
	return t[e.players.length - 3];
}
function et(e, t, n) {
	let r = E(e, t);
	if (r) return Me(r.character).tracks[n][Math.max(0, r.traits[n])];
	let i = e.monsters.find((e) => e.id === t), a = Xe(e, t);
	return a ? et(e, a.rid, n) : i.traits[n];
}
function k(e, t, n) {
	return t.cards.includes(n) ? !(e.haunt === null && t.character === "jingleklaws" && !h.includes(n)) : !1;
}
function tt(e, t, n) {
	return k(e, t, n) && t.startCards.includes(n) && !t.used.includes(n);
}
function nt(e, t, n) {
	let r = Xe(e, t);
	return r ? {
		might: ["idol"],
		speed: ["dog", "mask"],
		sanity: ["holySymbol", "ring"],
		knowledge: ["book", "skull"]
	}[n].filter((t) => k(e, r, t)).length : 0;
}
function A(e, t) {
	e.journal.push(t);
}
function j(e, t) {
	e.queue.unshift(...t);
}
function M(e, t, n, r, i) {
	r.length && (e.prompt = {
		actor: e.monsters.find((e) => e.id === t)?.controller ?? t,
		key: n,
		choices: r,
		params: i
	});
}
function N(e, t, n, r, i = "action", a) {
	return {
		id: e,
		key: t,
		tasks: n,
		target: r,
		kind: i,
		value: a
	};
}
function P(e, t, n, r, i) {
	let a = E(e, t);
	a && !a.dead && (a.traits[n] = Math.min(7, Math.max(e.haunt ? -1 : 0, a.traits[n] + r)), A(e, {
		key: r >= 0 ? "games.betrayal3.logGain" : "games.betrayal3.logLose",
		actor: t,
		id: n,
		n: Math.abs(r)
	}), e.beatMs = Je.resolve, a.traits[n] < 0 && !e.queue.some((e) => e.op === "death" && e.actor === t) && j(e, [{
		op: "death",
		actor: t,
		target: i
	}]));
}
function F(e, t, n = w) {
	let r = E(e, t), i = Me(r.character).start;
	for (let a of n) {
		let n = Math.max(0, i[a] - r.traits[a]);
		r.traits[a] += n, n && (A(e, {
			key: "games.betrayal3.logHeal",
			actor: t,
			id: a,
			n
		}), e.beatMs = Je.resolve);
	}
}
function rt(e, t) {
	E(e, t).traits = { ...Me(E(e, t).character).start };
}
function it(e, t) {
	E(e, t).traits = {
		might: 0,
		speed: 0,
		sanity: 0,
		knowledge: 0
	};
}
function I(e, t, n) {
	let r = E(e, t);
	r.cards = r.cards.filter((e) => e !== n), h.includes(n) ? e.omens.push(n) : e.items.push(n);
}
function at(e, t, n, r) {
	let i = E(e, t), a = E(e, n);
	i.cards = i.cards.filter((e) => e !== r), a.cards.push(r), a.startCards = a.startCards.filter((e) => e !== r), A(e, {
		key: "games.betrayal3.logTrade",
		actor: t,
		target: n,
		id: r
	}), e.beatMs = Je.draw;
}
function ot(e, t, n, r, i = !0, a, o = !1) {
	let s = E(e, t);
	if (!s || s.dead || n <= 0) return;
	if (i && r !== "general" && k(e, s, "brooch")) {
		M(e, t, "games.betrayal3.chooseDamageType", [N("normal", "games.betrayal3.keepDamageType", [{
			op: "damage",
			actor: t,
			target: a,
			n,
			damage: r,
			args: {
				converted: !0,
				criticalFloor: o
			}
		}]), N("brooch", "games.betrayal3.useBrooch", [{
			op: "damage",
			actor: t,
			target: a,
			n,
			damage: "general",
			args: {
				converted: !0,
				criticalFloor: o
			}
		}], "brooch", "card")]);
		return;
	}
	let c = r === "physical" && k(e, s, "armor") || r === "mental" && k(e, s, "headphones") ? 1 : 0, l = Math.max(0, n - c);
	o && (l = Math.min(l, (r === "physical" ? ["might", "speed"] : r === "mental" ? ["sanity", "knowledge"] : w).reduce((e, t) => e + Math.max(0, s.traits[t]), 0))), A(e, {
		key: "games.betrayal3.logDamage",
		actor: t,
		id: r,
		n: l
	}), e.beatMs = Je.resolve, r === "physical" && l > 0 && k(e, s, "strangeAmulet") && P(e, t, "sanity", 1), l && j(e, [{
		op: "allocateDamage",
		actor: t,
		target: a,
		n: l,
		damage: r,
		args: { criticalFloor: o }
	}]);
}
function st(e, t, n, r, i, a = !1) {
	let o = E(e, t);
	if (o.dead || n <= 0) return;
	let s = r === "physical" ? ["might", "speed"] : r === "mental" ? ["sanity", "knowledge"] : [...w];
	a && (s = s.filter((e) => o.traits[e] > 0), !s.length) || (!e.haunt && s.some((e) => o.traits[e] > 0) && (s = s.filter((e) => o.traits[e] > 0)), (e.haunt || !s.every((e) => o.traits[e] === 0)) && M(e, t, "games.betrayal3.allocateDamage", s.map((e) => N(e, "games.betrayal3.lowerTrait", [{
		op: "gain",
		actor: t,
		target: i,
		trait: e,
		n: -1
	}, ...n > 1 ? [{
		op: "allocateDamage",
		actor: t,
		target: i,
		n: n - 1,
		damage: r,
		args: { criticalFloor: a }
	}] : []], e, "trait", o.traits[e])), { n }));
}
function ct(e, t) {
	return Array.from({ length: Math.max(0, t) }, () => Ye(e, 3));
}
function lt(e) {
	return e.reduce((e, t) => e + t, 0);
}
function ut(e, t) {
	return y(e, E(e, t).room);
}
function dt(e) {
	return e === "G" ? "groundStaircase" : e === "U" ? "upperLanding" : "basementLanding";
}
function L(e, t, n, r = null, i = 1, a = null) {
	let o = 1;
	for (; e.tokens.some((e) => e.id === `${t}-${o}`);) o++;
	let s = `${t}-${o}`;
	return e.tokens.push({
		id: s,
		kind: t,
		room: n,
		holder: r,
		value: i,
		trait: a,
		hidden: !1,
		flags: {}
	}), s;
}
function ft(e, t, n) {
	return e.tokens.filter((e) => e.kind === t && e.room === n).length;
}
function pt(e, t, n) {
	e.winners = t, e.ending = n, e.phase = "done", e.queue = [], e.prompt = null, e.roll = null;
}
function mt(e, t) {
	return e?.[t] === !0;
}
function R(e, t, n = "") {
	return typeof e?.[t] == "string" ? e[t] : n;
}
function z(e, t, n = 0) {
	return typeof e?.[t] == "number" ? e[t] : n;
}
function B(e, t, n, r) {
	return {
		might: e,
		speed: t,
		sanity: n,
		knowledge: r
	};
}
//#endregion
//#region src/game/setup.ts
function ht(e) {
	let t = Ze(e), n = new Set(e.explorers.map((e) => Me(e.character).group)), r = we.filter((n) => n.id !== "werewolf" && (n.id !== "sara" || t === "blood") && (!["elf", "jingleklaws"].includes(n.id) || t === "yuletide" && n.id === e.config.stranger)).filter((e) => !n.has(e.group)).map((e) => e.id), i = t === "blood" ? "sara" : t === "yuletide" ? e.config.stranger : null;
	return i && e.explorers.length === e.players.length - 1 && !e.explorers.some((e) => e.character === i) && (r = r.filter((e) => e === i)), t === "yuletide" && (r = r.filter((e) => e !== "jaden" && e !== "sammy")), r;
}
function gt(e) {
	let t = e.players[e.explorers.length];
	e.turn = t, M(e, t, "games.betrayal3.chooseCharacter", ht(e).map((e) => N(e, "games.betrayal3.selectCharacter", [{
		op: "selectCharacter",
		actor: t,
		id: e
	}], e, "character")));
}
function _t(e, t, n) {
	if (t.length < 3 || t.length > 6 || new Set(t).size !== t.length) throw Error("Betrayal requires 3–6 distinct players");
	let r = ve.parse(e), i = _(r.scenario).expansion, a = {
		seed: n,
		cursor: 0,
		config: r,
		players: [...t],
		explorers: [],
		phase: "characters",
		turn: t[0],
		turnNumber: 0,
		movement: 0,
		attacked: !1,
		traded: !1,
		looted: [],
		extraTurn: !1,
		endRequested: !1,
		rooms: [
			{
				id: "groundStaircase",
				tile: "groundStaircase",
				floor: "G",
				x: 0,
				y: 0,
				rotation: 0
			},
			{
				id: "hallway",
				tile: "hallway",
				floor: "G",
				x: 1,
				y: 0,
				rotation: 0
			},
			{
				id: "entranceHall",
				tile: "entranceHall",
				floor: "G",
				x: 2,
				y: 0,
				rotation: 0
			},
			{
				id: "upperLanding",
				tile: "upperLanding",
				floor: "U",
				x: 0,
				y: 0,
				rotation: 0
			},
			{
				id: "basementLanding",
				tile: "basementLanding",
				floor: "B",
				x: 0,
				y: 0,
				rotation: 0
			}
		],
		tiles: [],
		items: [],
		omens: [],
		events: [],
		encounters: [],
		encountersOut: [],
		omenDraws: 0,
		monsters: [],
		tokens: [],
		haunt: null,
		prompt: null,
		roll: null,
		suspendedRolls: [],
		trade: null,
		discovery: null,
		reveal: null,
		queue: [],
		lastRoll: 0,
		lastDice: [],
		beatMs: 0,
		journal: [],
		winners: null,
		ending: null
	};
	return a.tiles = T(a, Ce.filter((e) => !a.rooms.some((t) => t.id === e.id) && (e.expansion === "base" || e.expansion === i)).map((e) => e.id)), a.items = T(a, [...Te, ...i === "blood" ? ["fangBracelet", "wolfsbane"] : i === "yuletide" ? ["unusualCake", "snowGlobe"] : []]), a.omens = T(a, h), a.events = T(a, [...Ee.filter((e) => i !== "pennywise" || e !== "sayCheese" && e !== "vialOfDust"), ...i === "blood" ? ["hunt", "bloodMoon"] : i === "yuletide" ? ["feast", "gift"] : []]), a.encounters = i === "pennywise" ? T(a, De) : [], gt(a), a;
}
function vt(e, t) {
	if (t.op === "selectCharacter") {
		let n = Me(t.id);
		return e.explorers.push({
			rid: t.actor,
			character: n.id,
			traits: { ...n.start },
			room: ["elf", "jingleklaws"].includes(n.id) ? "upperLanding" : "entranceHall",
			dead: !1,
			cards: [],
			startCards: [],
			used: [],
			tokens: [],
			secret: {},
			revealed: !1,
			team: "hero"
		}), e.explorers.length < e.players.length ? gt(e) : M(e, e.players[0], "games.betrayal3.chooseFirst", e.explorers.filter((e) => Me(e.character).birthday !== null).map((e) => N(e.rid, "games.betrayal3.firstPlayer", [{
			op: "firstPlayer",
			actor: e.rid
		}], e.rid, "player"))), !0;
	}
	return t.op === "firstPlayer" && (e.phase = "explore", e.turn = t.actor, j(e, [{
		op: "beginTurn",
		actor: t.actor
	}]), !0);
}
//#endregion
//#region src/game/rolls.ts
function yt(e, t, n = t.trait, r = 0) {
	return {
		op: e,
		actor: t.actor,
		...n ? { trait: n } : {},
		n: z(t.args, "count", -1),
		args: {
			...t.args,
			extra: r
		},
		then: t.done
	};
}
function bt(e, t) {
	let n = {
		actor: t.actor,
		trait: t.trait ?? null,
		dice: [],
		bonus: 0,
		context: R(t.args, "context"),
		done: t.then ?? [],
		args: {
			...t.args,
			count: t.n ?? -1,
			namedTrait: t.trait ?? null
		}
	};
	e.roll && e.suspendedRolls.push(e.roll), e.roll = n;
	let r = mt(n.args, "noItems") ? void 0 : Xe(e, t.actor), i = [n.trait];
	r && n.trait === "knowledge" && k(e, r, "magicCamera") && i.push("sanity"), r && n.trait && !mt(n.args, "attack") && r.secret.bookReady === !0 && !i.includes("knowledge") && i.push("knowledge");
	let a = i.flatMap((t) => {
		let i = N(`roll-${t ?? "dice"}`, "games.betrayal3.rollTrait", [yt("rollCast", n, t)], t ?? void 0, t ? "trait" : "action");
		return !r || !t || !mt(n.args, "event") || !k(e, r, "flashlight") ? [i] : [i, N(`flashlight-${t}`, "games.betrayal3.rollFlashlight", [yt("rollCast", n, t, 2)], t, "trait")];
	});
	if (r && n.trait && k(e, r, "angelsFeather")) for (let e of i) a.push(N(`feather-${e}`, "games.betrayal3.useFeather", [{
		op: "rollFeather",
		actor: r.rid,
		trait: e
	}], e, "trait"));
	a.length === 1 ? j(e, a[0].tasks) : M(e, Dt(e, t.actor), "games.betrayal3.chooseRoll", a);
}
function xt(e, t) {
	let n = e.roll;
	n.trait = t.trait ?? null;
	let r = mt(n.args, "noItems") ? void 0 : Xe(e, t.actor);
	if (n.dice = ct(e, (n.trait ? et(e, t.actor, n.trait) : t.n ?? 0) + (r && r.team === "hero" && n.trait && ft(e, "blessing", r.room) > 0 ? 1 : 0) + z(t.args, "extra") + z(t.args, "extraDice")), n.bonus = z(t.args, "bonus") + (n.trait ? nt(e, t.actor, n.trait) : 0), mt(n.args, "noItems") && n.trait && (n.bonus -= nt(e, t.actor, n.trait)), mt(n.args, "ignoreHighest")) {
		let e = Math.max(0, ...n.dice);
		n.args.highestPenalty = e, n.bonus -= e;
	}
	r && n.trait && !mt(n.args, "attack") && delete r.secret.bookReady, A(e, {
		key: "games.betrayal3.logRoll",
		actor: n.actor,
		id: n.trait ?? "dice",
		n: lt(n.dice) + n.bonus
	}), e.beatMs = Je.roll, j(e, [{
		op: "rollOptions",
		actor: n.actor
	}]);
}
function St(e) {
	let t = e.roll, n = mt(t.args, "noItems") ? void 0 : Xe(e, t.actor), r = [N("accept", "games.betrayal3.acceptRoll", [{
		op: "rollFinish",
		actor: t.actor
	}])];
	n && e.turn === n.rid && !("rawOverride" in t.args) && (k(e, n, "rabbitsFoot") && !n.used.includes("rabbitsFoot") && t.dice.forEach((e, n) => r.push(N(`foot-${n}`, "games.betrayal3.rerollDie", [{
		op: "rollReroll",
		actor: t.actor,
		id: "rabbitsFoot",
		n
	}], "rabbitsFoot", "card", e))), t.trait && t.dice.some((e) => e === 0) && k(e, n, "luckyCoin") && !n.used.includes("luckyCoin") && r.push(N("coin", "games.betrayal3.useLuckyCoin", [{
		op: "rollReroll",
		actor: t.actor,
		id: "luckyCoin"
	}], "luckyCoin", "card")), t.trait && k(e, n, "creepyDoll") && !n.used.includes("creepyDoll") && r.push(N("doll", "games.betrayal3.useCreepyDoll", [{
		op: "rollReroll",
		actor: t.actor,
		id: "creepyDoll"
	}], "creepyDoll", "card"))), M(e, Dt(e, t.actor), "games.betrayal3.reviewRoll", r, { n: z(t.args, "rawOverride", lt(t.dice)) + t.bonus });
}
function Ct(e, t) {
	let n = e.roll, r = Xe(e, t.actor), i = [];
	if (r.used.push(t.id), t.id === "rabbitsFoot" && (n.dice[t.n] = ct(e, 1)[0]), t.id === "creepyDoll" && (n.dice = ct(e, n.dice.length), i.push({
		op: "gain",
		actor: r.rid,
		trait: "sanity",
		n: -1
	})), t.id === "luckyCoin") {
		let t = 0;
		n.dice = n.dice.map((n) => {
			if (n !== 0) return n;
			let r = ct(e, 1)[0];
			return r === 0 && t++, r;
		}), t && i.push({
			op: "damage",
			actor: r.rid,
			n: t,
			damage: "mental"
		});
	}
	if (mt(n.args, "ignoreHighest")) {
		let e = Math.max(0, ...n.dice);
		n.bonus += z(n.args, "highestPenalty") - e, n.args.highestPenalty = e;
	}
	e.beatMs = Je.roll, j(e, [...i, {
		op: "rollOptions",
		actor: n.actor
	}]);
}
function wt(e, t) {
	let n = e.roll;
	n.trait = t.trait;
	let r = Array.from({ length: 9 }, (e, t) => N(`feather-${t}`, "games.betrayal3.featherResult", [{
		op: "rollFeatherResult",
		actor: n.actor,
		n: t
	}], void 0, "action", t));
	M(e, n.actor, "games.betrayal3.chooseFeatherResult", r);
}
function Tt(e, t) {
	let n = e.roll;
	I(e, Xe(e, n.actor).rid, "angelsFeather"), n.args.rawOverride = t.n, n.bonus = z(n.args, "bonus") + nt(e, n.actor, n.trait);
	let r = Xe(e, n.actor);
	mt(n.args, "attack") || delete r.secret.bookReady, j(e, [{
		op: "rollOptions",
		actor: n.actor
	}]);
}
function Et(e) {
	let t = e.roll, n = z(t.args, "rawOverride", lt(t.dice));
	e.lastRoll = n + t.bonus, e.lastDice = [...t.dice], e.roll = e.suspendedRolls.pop() ?? null, j(e, t.done.map((r) => ({
		...r,
		args: {
			...r.args,
			[R(t.args, "saveAs", "total")]: e.lastRoll,
			raw: n,
			rolledTrait: t.trait,
			namedTrait: t.args.namedTrait
		}
	})));
}
function Dt(e, t) {
	return E(e, t)?.rid ?? e.monsters.find((e) => e.id === t).controller;
}
function Ot(e, t) {
	switch (t.op) {
		case "roll":
			bt(e, t);
			break;
		case "rollCast":
			xt(e, t);
			break;
		case "rollOptions":
			St(e);
			break;
		case "rollReroll":
			Ct(e, t);
			break;
		case "rollFinish":
			Et(e);
			break;
		case "rollFeather":
			wt(e, t);
			break;
		case "rollFeatherResult":
			Tt(e, t);
			break;
		default: return !1;
	}
	return !0;
}
//#endregion
//#region src/game/events.ts
var V = (e, t, n = 1) => ({
	op: "gain",
	actor: e,
	trait: t,
	n
}), kt = (e, t, n) => ({
	op: "damage",
	actor: e,
	n: t,
	damage: n
}), At = (e) => ({
	op: "draw",
	actor: e,
	id: "item"
}), jt = (e, t) => ({
	op: "relocate",
	actor: e,
	id: t
}), Mt = (e, t = w) => ({
	op: "chooseGain",
	actor: e,
	n: 1,
	args: { traits: [...t] }
}), Nt = (e, t = "UGB") => ({
	op: "chooseRoom",
	actor: e,
	args: { floors: t }
}), Pt = (e, t, n) => ({
	op: "roll",
	actor: e,
	n: t,
	then: [{
		op: "rolledDamage",
		actor: e,
		damage: n
	}]
});
function Ft(e, t, n, r, i) {
	return {
		op: "roll",
		actor: e,
		...n ? { trait: n } : {},
		n: r,
		args: {
			context: t,
			event: !0
		},
		then: [{
			op: "eventResult",
			actor: e,
			id: t,
			args: i
		}]
	};
}
function It(e, t, n, r, i = []) {
	M(e, t, "games.betrayal3.eventDecision", [N("yes", "games.betrayal3.acceptEvent", r, n, "card"), N("no", "games.betrayal3.declineEvent", i, n, "card")]);
}
function Lt(e, t, n, r) {
	M(e, t, "games.betrayal3.chooseTraitRoll", r.map((e) => N(e, "games.betrayal3.rollTrait", [Ft(t, n, e)], e, "trait")));
}
function Rt(e, t, n, r, i, a) {
	if (e.haunt) {
		j(e, a);
		return;
	}
	It(e, t, n, [{
		op: "hauntRoll",
		actor: t,
		id: r,
		args: { event: n },
		then: i
	}], a);
}
function zt(e, t, n) {
	switch (A(e, {
		key: "games.betrayal3.logEvent",
		actor: t,
		id: n
	}), n) {
		case "secretElevator":
			It(e, t, n, [{
				op: "chooseRoom",
				actor: t,
				args: { differentFloor: ut(e, t).floor }
			}]);
			break;
		case "momentOfHope":
			L(e, "blessing", E(e, t).room);
			break;
		case "meatMoss":
			It(e, t, n, [Ft(t, n, null, 2)]);
			break;
		case "severedHand":
			It(e, t, n, [kt(t, 2, "physical"), At(t)]);
			break;
		case "mysteriousFluid":
			It(e, t, n, [Ft(t, n, null, 3)]);
			break;
		case "feast":
			It(e, t, n, [Ft(t, n, null, 2)]);
			break;
		case "gift":
			It(e, t, n, [Ft(t, n, null, 2)]);
			break;
		case "jonahsTurn":
			M(e, t, "games.betrayal3.chooseJonah", [...E(e, t).cards.filter((e) => !je.has(e) && ![
				"dog",
				"holySymbol",
				"idol",
				"ring",
				"skull",
				"book",
				"armor",
				"mask"
			].includes(e)).map((e) => N(e, "games.betrayal3.buryCard", [{
				op: "bury",
				actor: t,
				id: e
			}, V(t, "sanity")], e, "card")), N("damage", "games.betrayal3.takeMentalDie", [Pt(t, 1, "mental")])]);
			break;
		case "wanderingGhost":
			M(e, t, "games.betrayal3.chooseGhost", [...E(e, t).cards.filter((e) => ![
				"dog",
				"holySymbol",
				"idol",
				"dagger",
				"ring",
				"skull",
				"book",
				"armor",
				"mask"
			].includes(e)).map((e) => N(e, "games.betrayal3.buryCard", [{
				op: "bury",
				actor: t,
				id: e
			}, Mt(t)], e, "card")), N("roll", "games.betrayal3.rollTrait", [Ft(t, n, "sanity")], "sanity", "trait")]);
			break;
		case "flowering":
			j(e, [kt(t, 1, "general"), e.rooms.some((e) => e.id === "conservatory") ? jt(t, "conservatory") : Nt(t, "GB")]);
			break;
		case "technicalDifficulties": {
			let n = ut(e, t).floor;
			j(e, [jt(t, dt(n === "U" ? "G" : n === "G" ? "B" : "U")), ...n === "B" ? [kt(t, 1, "mental")] : []]);
			break;
		}
		case "sayCheese":
			Rt(e, t, n, "33", [At(t)], [At(t)]);
			break;
		case "splashOfCrimson":
			Rt(e, t, n, "1", [V(t, "speed")], [Pt(t, 1, "physical")]);
			break;
		case "vialOfDust":
			Rt(e, t, n, "3", [V(t, "sanity")], [V(t, "might", -1), V(t, "sanity")]);
			break;
		case "eerieMirror":
			Rt(e, t, n, "7", [V(t, "sanity")], [At(t)]);
			break;
		case "houseIsHungry":
			Rt(e, t, n, "12", [V(t, "might")], [Mt(t)]);
			break;
		case "flickeringLights":
		case "oldestHouse":
			Lt(e, t, n, ["speed", "might"]);
			break;
		case "fullTable":
			Lt(e, t, n, ["knowledge", "sanity"]);
			break;
		case "starsAtNight":
			Lt(e, t, n, w);
			break;
		case "eerieFeeling":
		case "radioBroadcast":
		case "phoneCall":
			j(e, [Ft(t, n, null, 2)]);
			break;
		case "hangedMen":
			j(e, [Ft(t, n, "might", void 0, {
				index: 0,
				failed: !1
			})]);
			break;
		case "creakingDoor":
		case "cryForHelp":
		case "darkStormyNight":
		case "alienGeometry":
		case "tinyRobot":
		case "secretPassage":
			j(e, [Ft(t, n, "knowledge")]);
			break;
		case "spiders":
		case "poorYorick":
		case "impossibleArchitecture":
		case "funeral":
		case "burningFigure":
		case "clownRoom":
		case "forbiddenKnowledge":
		case "cassettePlayer":
		case "jarOfOrgans":
		case "bloodMoon":
			j(e, [Ft(t, n, "sanity")]);
			break;
		case "bite":
		case "taxidermy":
		case "brainFood":
			j(e, [Ft(t, n, "might")]);
			break;
		case "deepestCloset":
		case "behindYou":
		case "batOutOfHell":
		case "hunt":
			j(e, [Ft(t, n, "speed")]);
			break;
		default: throw Error(`Unknown event: ${n}`);
	}
}
function Bt(e, t) {
	let n = t.actor, r = z(t.args, "total"), i = r >= 4, a = [];
	switch (t.id) {
		case "creakingDoor":
			a = r >= 6 ? [Nt(n, "UG")] : i ? [Nt(n, "G")] : [jt(n, "basementLanding")];
			break;
		case "cryForHelp":
			a = i ? [Nt(n, ut(e, n).floor)] : [kt(n, 1, "mental")];
			break;
		case "darkStormyNight":
			a = i ? [V(n, "sanity")] : [kt(n, 1, "mental")];
			break;
		case "spiders":
			a = i ? [Mt(n, ["sanity", "speed"]), {
				op: "chooseAdjacent",
				actor: n
			}] : r >= 2 ? [V(n, "speed"), V(n, "sanity", -1)] : [V(n, "speed", -1)];
			break;
		case "meatMoss":
			a = r >= 3 ? [Mt(n)] : [Pt(n, 1, "mental")];
			break;
		case "eerieFeeling":
			a = r === 4 ? [] : [V(n, [
				"might",
				"knowledge",
				"sanity",
				"speed"
			][r], -1)];
			break;
		case "hangedMen": {
			let e = z(t.args, "index"), i = t.args?.failed === !0 || r < 2;
			r < 2 && a.push(V(n, w[e], -1)), e < 3 ? a.push(Ft(n, "hangedMen", w[e + 1], void 0, {
				index: e + 1,
				failed: i
			})) : i || a.push(Mt(n));
			break;
		}
		case "poorYorick":
			a = i ? [V(n, "knowledge")] : [kt(n, 1, "mental")];
			break;
		case "impossibleArchitecture":
			a = i ? [At(n)] : [Pt(n, 1, "mental")];
			break;
		case "alienGeometry":
			a = i ? [V(n, "sanity")] : [V(n, "speed", -1)];
			break;
		case "bite":
			a = i ? [] : [kt(n, r >= 2 ? 1 : 3, "physical")];
			break;
		case "funeral": {
			a = i ? [V(n, "sanity")] : r >= 2 ? [V(n, "sanity", -1)] : [V(n, "sanity", -1), V(n, "might", -1)];
			let t = ["graveyard", "catacombs"].filter((t) => e.rooms.some((e) => e.id === t));
			t.length && a.push({
				op: "chooseRoom",
				actor: n,
				args: { rooms: t }
			});
			break;
		}
		case "flickeringLights":
			a = r >= 5 ? [V(n, "speed")] : [Pt(n, 1, "physical")];
			break;
		case "fullTable":
			a = r >= 5 ? [V(n, "speed")] : [kt(n, 1, "general")];
			break;
		case "deepestCloset":
			a = i ? [At(n)] : r > 0 ? [kt(n, 1, "mental")] : [Pt(n, 1, "physical"), jt(n, "basementLanding")];
			break;
		case "burningFigure":
			a = i ? [V(n, "sanity")] : r >= 2 ? [jt(n, "entranceHall")] : [Pt(n, 1, "physical"), Pt(n, 1, "mental")];
			break;
		case "behindYou":
			a = i ? [V(n, "sanity")] : [kt(n, 1, "physical")];
			break;
		case "clownRoom":
			a = i ? [] : [kt(n, 2, "mental")];
			break;
		case "radioBroadcast":
			a = r >= 3 ? [V(n, "knowledge")] : [Pt(n, 1, "mental")];
			break;
		case "tinyRobot":
			a = r >= 5 ? [At(n)] : [Pt(n, 1, "physical")];
			break;
		case "taxidermy":
			a = r >= 5 ? [V(n, "sanity")] : [kt(n, 1, "physical"), {
				op: "token",
				actor: n,
				id: "obstacle",
				args: { room: E(e, n).room }
			}];
			break;
		case "phoneCall":
		case "feast":
			a = r === 4 ? [V(n, t.id === "feast" ? "might" : "sanity")] : r === 3 ? [V(n, t.id === "feast" ? "sanity" : "knowledge")] : r > 0 ? [Pt(n, 1, "mental")] : [Pt(n, 2, "physical")];
			break;
		case "batOutOfHell":
			a = i ? [{
				op: "chooseAdjacent",
				actor: n
			}] : [kt(n, 1, "physical")];
			break;
		case "mysteriousFluid": {
			let e = {
				6: {
					might: 1,
					speed: 1,
					sanity: 1,
					knowledge: 1
				},
				5: {
					might: 1,
					speed: 1
				},
				4: {
					sanity: 1,
					knowledge: 1
				},
				3: {
					knowledge: 1,
					might: -1
				},
				2: {
					sanity: -1,
					knowledge: -1
				},
				1: {
					might: -1,
					speed: -1
				},
				0: {
					might: -1,
					speed: -1,
					sanity: -1,
					knowledge: -1
				}
			};
			a = w.filter((t) => e[r][t]).map((t) => V(n, t, e[r][t]));
			break;
		}
		case "forbiddenKnowledge":
			a = i ? [V(n, "knowledge")] : r >= 2 ? [V(n, "knowledge"), V(n, "sanity", -1)] : [kt(n, 2, "mental")];
			break;
		case "cassettePlayer":
			a = i ? [V(n, "knowledge")] : [kt(n, 1, "mental")];
			break;
		case "oldestHouse":
			a = r >= 5 ? [Nt(n)] : r >= 3 ? [Nt(n, "G"), kt(n, 1, "general")] : [Nt(n, "B"), kt(n, 1, "mental")];
			break;
		case "jarOfOrgans":
			a = i ? [At(n)] : [V(n, "might", -1)];
			break;
		case "wanderingGhost":
			a = i ? [At(n)] : [kt(n, 1, "general")];
			break;
		case "starsAtNight": {
			let e = R(t.args, "namedTrait");
			a = r >= 5 ? [V(n, e)] : r === 4 ? [V(n, e, -1)] : [{
				op: "heal",
				actor: n,
				args: { traits: [e] }
			}];
			break;
		}
		case "brainFood":
			a = r >= 5 ? [Mt(n, ["might", "speed"])] : r >= 1 ? [V(n, "speed"), V(n, "sanity", -1)] : [kt(n, 2, "general")];
			break;
		case "secretPassage":
			L(e, "secretPassage", E(e, n).room), a = [{
				op: "chooseRoom",
				actor: n,
				args: {
					floors: r >= 5 ? "UGB" : r >= 3 ? "G" : "B",
					except: E(e, n).room,
					token: "secretPassage"
				}
			}, ...r >= 5 ? [V(n, "knowledge")] : r < 3 ? [V(n, "sanity", -1)] : []];
			break;
		case "hunt":
			a = i ? [Nt(n, ut(e, n).floor), V(n, "sanity")] : [V(n, "sanity", -1)];
			break;
		case "bloodMoon":
			a = i ? [V(n, "might")] : r >= 2 ? [] : [
				Pt(n, 1, "physical"),
				Pt(n, 1, "mental"),
				jt(n, "entranceHall")
			];
			break;
		case "gift":
			a = r >= 3 ? [At(n)] : r === 2 ? [] : [Pt(n, 1, "physical"), Pt(n, 1, "mental")];
			break;
		default: throw Error(`Unknown event result: ${t.id}`);
	}
	j(e, a);
}
function Vt(e, t) {
	switch (t.op) {
		case "event":
			zt(e, t.actor, t.id);
			break;
		case "eventResult":
			Bt(e, t);
			break;
		case "rolledDamage":
			j(e, [kt(t.actor, z(t.args, "total"), t.damage)]);
			break;
		case "bury":
			I(e, t.actor, t.id);
			break;
		case "chooseGain": {
			let n = t.args?.traits ?? w;
			M(e, t.actor, "games.betrayal3.chooseGain", n.map((e) => N(e, "games.betrayal3.raiseTrait", [V(t.actor, e, t.n ?? 1)], e, "trait")));
			break;
		}
		case "chooseRoom": {
			let n = e.rooms.filter((e) => R(t.args, "floors", "UGB").includes(e.floor) && e.floor !== t.args?.differentFloor && e.id !== t.args?.except && (!Array.isArray(t.args?.rooms) || t.args.rooms.includes(e.id)));
			M(e, t.actor, t.args?.token ? "games.betrayal3.chooseTokenRoom" : "games.betrayal3.chooseRoom", n.flatMap((e) => (e.tile === "windingTunnels" ? [`${e.id}:a`, `${e.id}:b`] : [e.id]).map((e) => N(e, t.args?.token ? "games.betrayal3.placeToken" : "games.betrayal3.moveTo", [{
				op: t.args?.token ? "token" : "relocate",
				actor: t.actor,
				id: t.args?.token ? R(t.args, "token") : e,
				args: { room: e }
			}, ...t.then ?? []], e, "room"))));
			break;
		}
		case "token":
			L(e, t.id, R(t.args, "room", E(e, t.actor)?.room ?? "entranceHall"));
			break;
		default: return !1;
	}
	return !0;
}
//#endregion
//#region src/game/items.ts
function Ht(e, t) {
	let n = Xe(e, t), r = e.monsters.find((e) => e.id === t)?.room ?? n.room;
	return n.dead ? [] : n.cards.filter((t) => tt(e, n, t)).flatMap((i) => [
		"mirror",
		"strangeMedicine",
		"map",
		"wolfsbane",
		"unusualCake"
	].includes(i) ? [N(`item-${i}`, "games.betrayal3.useItem", [{
		op: "useItem",
		actor: t,
		id: i
	}], i, "card")] : i === "firstAidKit" ? D(e).filter((e) => (e.rid === n.rid || e.room === r && e.secret.hiddenAmongIllusions !== !0) && w.some((t) => e.traits[t] === 0)).map((e) => N(`aid-${e.rid}`, "games.betrayal3.healExplorer", [{
		op: "useItem",
		actor: t,
		id: i,
		target: e.rid
	}], e.rid, "player")) : i === "mysticalStopwatch" && e.haunt && !e.extraTurn ? [N("stopwatch", "games.betrayal3.useItem", [{
		op: "useItem",
		actor: t,
		id: i
	}], i, "card")] : i === "book" ? [N("book", "games.betrayal3.useBook", [{
		op: "useItem",
		actor: t,
		id: i
	}], i, "card")] : i === "mask" && x(e, r).length > 0 && (D(e).some((e) => e.rid !== n.rid && e.room === r) || e.monsters.some((e) => !e.dead && e.id !== t && e.room === r)) ? [N("mask", "games.betrayal3.useMask", [{
		op: "useItem",
		actor: t,
		id: i
	}], i, "card")] : []);
}
function Ut(e, t) {
	let n = Xe(e, t.actor), r = e.monsters.find((e) => e.id === t.actor)?.room ?? n.room;
	switch (n.used.push(t.id), A(e, {
		key: "games.betrayal3.logUse",
		actor: t.actor,
		id: t.id
	}), t.id) {
		case "firstAidKit": {
			let r = E(e, t.target);
			F(e, r.rid, w.filter((e) => r.traits[e] === 0)), I(e, n.rid, t.id);
			break;
		}
		case "mirror":
			F(e, n.rid, ["sanity", "knowledge"]), I(e, n.rid, t.id);
			break;
		case "strangeMedicine":
			F(e, n.rid, ["might", "speed"]), I(e, n.rid, t.id);
			break;
		case "wolfsbane":
			F(e, n.rid, ["sanity"]), I(e, n.rid, t.id);
			break;
		case "unusualCake":
			F(e, n.rid, ["speed", "sanity"]), I(e, n.rid, t.id);
			break;
		case "map":
			I(e, n.rid, t.id), j(e, [{
				op: "chooseRoom",
				actor: t.actor
			}]);
			break;
		case "mysticalStopwatch":
			e.extraTurn = !0, I(e, n.rid, t.id);
			break;
		case "book":
			n.secret.bookReady = !0, P(e, n.rid, "sanity", -1);
			break;
		case "mask":
			j(e, [...D(e).filter((e) => e.rid !== n.rid && e.room === r && e.secret.hiddenAmongIllusions !== !0).map((e) => e.rid), ...e.monsters.filter((e) => !e.dead && e.id !== t.actor && e.room === r).map((e) => e.id)].map((e) => ({
				op: "maskMove",
				actor: n.rid,
				target: e
			})));
			break;
		default: throw Error(`Unknown active item: ${t.id}`);
	}
}
function Wt(e, t) {
	let n = E(e, t);
	return e.traded || n.dead ? [] : D(e).filter((e) => e.rid !== t).flatMap((r) => {
		let i = r.room !== n.room;
		return i && (!tt(e, n, "dog") || C(e, n.room, r.room) > 4) || ![...n.cards, ...r.cards].length && !e.tokens.some((e) => (e.holder === t || e.holder === r.rid) && e.flags.tradable === !0) ? [] : [N(`trade-${r.rid}`, i ? "games.betrayal3.tradeWithDog" : "games.betrayal3.tradeWith", [{
			op: "tradeStart",
			actor: t,
			target: r.rid,
			args: { dog: i }
		}], r.rid, "player")];
	});
}
function Gt(e) {
	let t = e.trade, n = E(e, t.actor), r = E(e, t.target), i = (t) => [...E(e, t).cards.filter((t) => !(e.haunt?.id === "yuletide4" && n.team === "hero" && r.team === "hero" && e.haunt.flags.giftCards.includes(t))), ...e.tokens.filter((e) => e.holder === t && e.flags.tradable === !0 && (e.flags.heroesOnly !== !0 || n.team === "hero" && r.team === "hero")).map((e) => e.id)], a = [
		...i(n.rid).filter((e) => !n.used.includes(e)).map((r) => N(`give-${r}`, t.give.includes(r) ? "games.betrayal3.removeFromOffer" : "games.betrayal3.giveCard", [{
			op: "tradeToggle",
			actor: n.rid,
			id: r,
			args: { side: "give" }
		}], r, e.tokens.some((e) => e.id === r) ? "token" : "card")),
		...i(r.rid).filter((e) => !r.used.includes(e)).map((r) => N(`take-${r}`, t.take.includes(r) ? "games.betrayal3.removeFromOffer" : "games.betrayal3.requestCard", [{
			op: "tradeToggle",
			actor: n.rid,
			id: r,
			args: { side: "take" }
		}], r, e.tokens.some((e) => e.id === r) ? "token" : "card")),
		...t.give.length + t.take.length ? [N("propose", "games.betrayal3.proposeTrade", [{
			op: "tradePropose",
			actor: n.rid
		}])] : [],
		N("cancel", "games.betrayal3.cancel", [{
			op: "tradeCancel",
			actor: n.rid
		}])
	];
	M(e, n.rid, "games.betrayal3.prepareTrade", a);
}
function Kt(e, t) {
	let n = E(e, t), r = w.filter((e) => n.traits[e] === 0);
	!n.dead && k(e, n, "necklaceOfTeeth") && r.length && M(e, t, "games.betrayal3.useNecklace", [...r.map((e) => N(e, "games.betrayal3.raiseTrait", [{
		op: "gain",
		actor: t,
		trait: e,
		n: 1
	}], e, "trait")), N("decline", "games.betrayal3.decline", [])]);
}
function qt(e, t) {
	let n = E(e, t.actor);
	return k(e, n, "snowGlobe") ? (it(e, n.rid), I(e, n.rid, "snowGlobe"), j(e, [{
		op: "relocate",
		actor: n.rid,
		id: "entranceHall"
	}]), !0) : k(e, n, "skull") && t.args?.skullChecked !== !0 ? (j(e, [{
		op: "roll",
		actor: n.rid,
		n: 3,
		args: { context: "skull" },
		then: [{
			op: "skullDeath",
			actor: n.rid,
			target: t.target,
			args: { forced: mt(t.args, "forced") }
		}]
	}]), !0) : !1;
}
function Jt(e, t) {
	switch (t.op) {
		case "useItem":
			Ut(e, t);
			break;
		case "maskMove": {
			let n = E(e, t.target)?.room ?? e.monsters.find((e) => e.id === t.target).room;
			M(e, t.actor, "games.betrayal3.chooseMaskRoom", x(e, n).map((e) => N(e, "games.betrayal3.moveTo", [{
				op: "relocate",
				actor: t.target,
				id: e
			}], e, "room")));
			break;
		}
		case "keyRoll":
			j(e, [{
				op: "roll",
				actor: t.actor,
				n: 1,
				args: { context: "skeletonKey" },
				then: [{
					op: "keyResult",
					actor: t.actor
				}]
			}]);
			break;
		case "keyResult":
			z(t.args, "total") === 0 && I(e, Xe(e, t.actor).rid, "skeletonKey");
			break;
		case "skullDeath":
			z(t.args, "total") >= 4 ? it(e, t.actor) : j(e, [{
				op: "death",
				actor: t.actor,
				target: t.target,
				args: {
					skullChecked: !0,
					forced: mt(t.args, "forced")
				}
			}]);
			break;
		case "necklace":
			Kt(e, t.actor);
			break;
		case "tradeStart":
			e.trade = {
				actor: t.actor,
				target: t.target,
				give: [],
				take: [],
				dog: t.args?.dog === !0
			}, Gt(e);
			break;
		case "tradeToggle": {
			let n = e.trade, r = R(t.args, "side");
			n[r] = n[r].includes(t.id) ? n[r].filter((e) => e !== t.id) : [...n[r], t.id], Gt(e);
			break;
		}
		case "tradePropose": {
			let t = e.trade;
			M(e, t.target, "games.betrayal3.acceptTrade", [N("accept", "games.betrayal3.accept", [{
				op: "tradeAccept",
				actor: t.target
			}]), N("decline", "games.betrayal3.decline", [{
				op: "tradeCancel",
				actor: t.target
			}])]);
			break;
		}
		case "tradeAccept": {
			let t = e.trade;
			for (let n of t.give) Yt(e, t.actor, t.target, n);
			for (let n of t.take) Yt(e, t.target, t.actor, n);
			t.dog && E(e, t.actor).used.push("dog"), e.traded = !0, e.trade = null;
			break;
		}
		case "tradeCancel":
			e.trade = null;
			break;
		case "loot":
			t.args?.dog === !0 && E(e, t.actor).used.push("dog"), at(e, t.target, t.actor, t.id), e.looted.push(t.target);
			break;
		case "lootToken": {
			let n = e.tokens.find((e) => e.id === t.id);
			n.holder = t.actor, n.room = null, delete n.flags.corpse, e.looted.push(t.target);
			break;
		}
		default: return !1;
	}
	return !0;
}
function Yt(e, t, n, r) {
	let i = e.tokens.find((e) => e.id === r && e.holder === t);
	i ? i.holder = n : at(e, t, n, r);
}
function Xt(e, t) {
	let n = E(e, t);
	if (!k(e, n, "skeletonKey")) return [];
	let r = x(e, n.room);
	return Re(e, n.room, !0).filter((e) => !r.includes(e));
}
//#endregion
//#region src/game/combat.ts
function Zt(e, t) {
	return E(e, t)?.rid ?? e.monsters.find((e) => e.id === t).controller;
}
function Qt(e, t) {
	return E(e, t)?.room ?? e.monsters.find((e) => e.id === t).room;
}
function $t(e, t, n) {
	if (t === n || E(e, n)?.secret.hiddenFromWerewolf === !0 || E(e, t)?.secret.hiddenAmongIllusions === !0 || E(e, n)?.secret.hiddenAmongIllusions === !0) return !1;
	let r = e.monsters.find((e) => e.id === t), i = e.monsters.find((e) => e.id === n);
	if (r?.flags.owned === !0 && r.controller === n || i?.flags.owned === !0 && i.controller === t) return !1;
	let a = E(e, t), o = E(e, n);
	return e.haunt?.hidden && !e.explorers.some((e) => e.team === "traitor" && e.revealed) || a?.team === "individual" || o?.team === "individual" ? !0 : (a?.team ?? e.monsters.find((e) => e.id === t)?.flags.team ?? "traitor") !== (o?.team ?? e.monsters.find((e) => e.id === n)?.flags.team ?? "traitor");
}
function en(e, t) {
	let n = e.monsters.find((e) => e.id === t);
	if (!e.haunt || (n ? n.flags.attacked === !0 : e.attacked)) return [];
	let r = Xe(e, t), i = Qt(e, t), a = ["", ...r.cards.filter((t) => je.has(t) && k(e, r, t) && r.startCards.includes(t))], o = [...D(e).map((e) => e.rid), ...e.monsters.filter((e) => !e.dead && e.flags.untargetable !== !0).map((e) => e.id)];
	return a.flatMap((n) => n === "dynamite" ? [i, ...x(e, i)].map((e) => N(`dynamite-${e}`, "games.betrayal3.throwDynamite", [{
		op: "dynamite",
		actor: t,
		id: e
	}], e, "room")) : o.filter((n) => $t(e, t, n) || e.haunt?.id === "blood4" && n !== t && !!E(e, n)).filter((t) => {
		let r = Qt(e, t);
		return n === "gun" ? S(e, i, r) : n === "crossbow" ? i === r || x(e, i).includes(r) : i === r;
	}).map((e) => {
		let r = N(`attack-${n || "unarmed"}-${e}`, n ? "games.betrayal3.attackWith" : "games.betrayal3.attackUnarmed", [{
			op: "attack",
			actor: t,
			target: e,
			id: n
		}], e, "player");
		return r.params = { weapon: n }, r;
	}));
}
function tn(e, t, n, r) {
	let i = Xe(e, t), a = +(r === "machete"), o = r === "crossbow" || r === "chainsaw" ? 1 : r === "dagger" ? 2 : 0;
	return i && k(e, i, "fangBracelet") && (!E(e, n) || E(e, n).character === "werewolf") && a++, {
		extraDice: o,
		bonus: a
	};
}
function nn(e, t) {
	let n = t.id ?? "", r = Xe(e, t.actor), i = e.monsters.find((e) => e.id === t.actor), a = t.trait ?? (n === "ring" ? "sanity" : n === "gun" || n === "crossbow" ? "speed" : i?.attack ?? "might");
	r && (n && r.used.push(n), i ? i.flags.attacked = !0 : e.attacked = !0, n === "dagger" && P(e, r.rid, "speed", -1));
	let o = tn(e, t.actor, t.target, n);
	j(e, [{
		op: "roll",
		actor: t.actor,
		trait: a,
		args: {
			attack: !0,
			context: n || "attack",
			attackTarget: t.target,
			attackSource: t.actor,
			...o,
			extraDice: o.extraDice + z(t.args, "extraDice"),
			bonus: o.bonus + z(t.args, "bonus")
		},
		then: [{
			op: "attackResult",
			actor: t.actor,
			target: t.target,
			id: n,
			trait: a,
			damage: t.damage ?? (a === "sanity" || a === "knowledge" ? "mental" : "physical"),
			args: { ...t.args }
		}]
	}]);
}
function rn(e, t) {
	let n = Xe(e, t.target), r = Xe(e, t.actor), i = n && k(e, n, "leatherJacket") ? 1 : 0;
	n && (r?.character === "werewolf" || e.monsters.find((e) => e.id === t.actor)?.kind === "werewolf") && k(e, n, "wolfsbane") && i++, j(e, [{
		op: "roll",
		actor: t.target,
		trait: t.trait,
		args: {
			attack: !0,
			defense: !0,
			context: "defend",
			extraDice: i,
			attackTarget: t.target,
			attackSource: t.actor
		},
		then: [{
			...t,
			op: "combatResult",
			args: {
				...t.args,
				attackTotal: z(t.args, "total")
			}
		}]
	}]);
}
function an(e, t) {
	let n = z(t.args, "attackTotal") - z(t.args, "total");
	if (A(e, {
		key: "games.betrayal3.logAttack",
		actor: t.actor,
		target: t.target,
		n: Math.abs(n),
		id: t.id || "unarmed"
	}), n === 0) return;
	let r = n > 0 ? t.target : t.actor;
	n < 0 && (t.id === "crossbow" || t.id === "gun" || t.args?.noCounter === !0) || j(e, [{
		op: "characterDamage",
		actor: r,
		target: n > 0 ? t.actor : t.target,
		n: Math.abs(n),
		damage: t.damage,
		args: {
			attackTrait: t.trait ?? null,
			criticalFloor: e.haunt?.id === "45" && n > 0 && je.has(t.id ?? "")
		}
	}]);
}
function on(e, t) {
	let n = e.monsters.find((e) => e.id === t.actor);
	if (!n) {
		j(e, [{
			...t,
			op: "damage"
		}]);
		return;
	}
	(t.n ?? 0) <= 0 || n.dead || n.death === "immune" || (n.death === "kill" ? n.dead = !0 : n.stunned = !0, A(e, {
		key: n.dead ? "games.betrayal3.logMonsterKilled" : "games.betrayal3.logMonsterStunned",
		id: n.kind,
		actor: t.target
	}));
}
function sn(e, t) {
	let n = e.monsters.find((e) => e.id === t.actor);
	n ? n.flags.attacked = !0 : e.attacked = !0, I(e, Xe(e, t.actor).rid, "dynamite"), j(e, [...D(e).filter((e) => e.room === t.id).map((e) => e.rid), ...e.monsters.filter((e) => !e.dead && e.room === t.id).map((e) => e.id)].map((e) => ({
		op: "roll",
		actor: e,
		trait: "speed",
		args: { context: "dynamite" },
		then: [{
			op: "dynamiteResult",
			actor: e,
			target: t.actor
		}]
	})));
}
function cn(e, t) {
	switch (t.op) {
		case "attack":
			nn(e, t);
			break;
		case "attackResult":
			rn(e, t);
			break;
		case "combatResult":
			an(e, t);
			break;
		case "characterDamage":
			on(e, t);
			break;
		case "dynamite":
			sn(e, t);
			break;
		case "dynamiteResult":
			z(t.args, "total") < 4 && on(e, {
				...t,
				n: 4,
				damage: "physical",
				args: {
					...t.args,
					criticalFloor: e.haunt?.id === "45"
				}
			});
			break;
		case "encounterAttack": {
			let n = t.trait ?? "might";
			j(e, [{
				op: "roll",
				actor: t.actor,
				n: 4,
				args: { context: t.id ?? "encounter" },
				then: [{
					op: "encounterAttackResult",
					actor: t.actor,
					trait: n,
					id: t.id
				}]
			}]);
			break;
		}
		case "encounterAttackResult": {
			let n = +!!k(e, E(e, t.actor), "leatherJacket");
			j(e, [{
				op: "roll",
				actor: t.actor,
				trait: t.trait,
				args: {
					attack: !0,
					defense: !0,
					context: "defend",
					extraDice: n
				},
				then: [{
					op: "encounterDefenseResult",
					actor: t.actor,
					id: t.id,
					damage: "physical",
					args: { attackTotal: z(t.args, "total") }
				}]
			}]);
			break;
		}
		case "encounterDefenseResult": {
			let n = Math.max(0, z(t.args, "attackTotal") - z(t.args, "total"));
			j(e, [...n > 0 ? [{
				op: "damage",
				actor: t.actor,
				n,
				damage: "physical"
			}] : [], {
				op: "encounterDefenseReward",
				actor: t.actor,
				id: t.id,
				args: {
					journalAt: e.journal.length,
					reward: R(t.args, "reward")
				}
			}]);
			break;
		}
		case "encounterDefenseReward":
			!e.journal.slice(z(t.args, "journalAt")).some((e) => e.key === "games.betrayal3.logDamage" && e.actor === t.actor && (e.n ?? 0) > 0) && R(t.args, "reward") !== "none" && j(e, t.id === "knifeInDark" ? [{
				op: "draw",
				actor: t.actor,
				id: "omen",
				args: { noHaunt: !0 }
			}] : [{
				op: "chooseAdjacent",
				actor: t.actor
			}, {
				op: "gain",
				actor: t.actor,
				trait: "sanity",
				n: 1
			}]);
			break;
		default: return !1;
	}
	return !0;
}
//#endregion
//#region src/game/exploration.ts
function ln(e) {
	return e.haunt?.id === "34" || e.haunt?.id === "pennywise2";
}
function un(e, t) {
	let n = E(e, t);
	return e.haunt && (D(e).some((r) => r.room === n.room && $t(e, t, r.rid)) || e.monsters.some((r) => !r.dead && !r.stunned && r.room === n.room && $t(e, t, r.id))) || ft(e, "obstacle", n.room) > 0 || n.team === "hero" && ft(e, "alienWord", n.room) > 0 ? 2 : 1;
}
function dn(e, t) {
	let n = E(e, t), r = un(e, t);
	if (e.movement < r) return [];
	let i = x(e, n.room).map((e) => N(`move-${e}`, "games.betrayal3.moveTo", [{
		op: "move",
		actor: t,
		id: e,
		n: r
	}], e, "room"));
	i.push(...Xt(e, t).map((e) => N(`key-${e}`, "games.betrayal3.moveThroughWall", [{
		op: "move",
		actor: t,
		id: e,
		n: r,
		args: { key: !0 }
	}], e, "room")));
	for (let a of Ve(e, ut(e, t).floor, n.room)) {
		if (!e.tiles.some((n) => ln(e) || g(n).floors.includes(ut(e, t).floor))) continue;
		let n = N(`discover-${a.direction}`, "games.betrayal3.discoverDirection", [{
			op: "discover",
			actor: t,
			n: r,
			args: {
				floor: ut(e, t).floor,
				x: a.x,
				y: a.y,
				direction: a.direction,
				from: a.room
			}
		}], Ne[a.direction], "action");
		i.push(n);
	}
	return i;
}
function fn(e, t, n, r, i) {
	if (ln(e)) return e.tiles.length && He(e, e.tiles[0], t, n, r, i).length ? e.tiles.shift() : null;
	let a = e.tiles.length;
	for (let o = 0; o < a; o++) {
		let a = e.tiles.shift();
		if ((ln(e) || g(a).floors.includes(t)) && He(e, a, t, n, r, i).length) return a;
		e.tiles.push(a);
	}
	return null;
}
function pn(e, t) {
	let n = R(t.args, "floor"), r = z(t.args, "x"), i = z(t.args, "y"), a = z(t.args, "direction"), o = fn(e, n, r, i, a);
	if (!o) {
		if (!e.tiles.some((t) => ln(e) || g(t).floors.includes(n))) {
			A(e, {
				key: "games.betrayal3.logNoTile",
				actor: t.actor
			});
			return;
		}
		mn(e, t);
		return;
	}
	e.discovery = {
		tile: o,
		floor: n,
		x: r,
		y: i,
		entrance: a,
		from: R(t.args, "from")
	};
	let s = {
		op: "placeOptions",
		actor: t.actor,
		n: t.n
	};
	k(e, E(e, t.actor), "holySymbol") ? M(e, t.actor, "games.betrayal3.chooseDiscoveredTile", [N("keep", "games.betrayal3.keepTile", [s], o, "room"), N("bury", "games.betrayal3.buryTile", [{
		...t,
		op: "replaceTile",
		id: o
	}], o, "room")]) : j(e, [s]);
}
function mn(e, t) {
	let n = R(t.args, "floor"), r = z(t.args, "x"), i = z(t.args, "y"), a = z(t.args, "direction"), o = v(R(t.args, "from")), s = [
		"entranceHall",
		"hallway",
		"groundStaircase"
	], c = (t) => {
		let s = {
			...e,
			rooms: t
		}, c = y(s, o), l = ln(e) ? e.tiles.slice(0, 1) : e.tiles;
		return !Le(s, n, r, i) && Fe(c).includes(a) && l.some((t) => (ln(e) || g(t).floors.includes(n)) && He(s, t, n, r, i, a).length);
	}, l = [], u = e.rooms.filter((e) => e.floor === n);
	for (let t of u.filter((e) => !s.includes(e.id))) for (let n of [
		0,
		1,
		2,
		3
	]) {
		if (n === t.rotation) continue;
		let r = We(e, t.id, t.x, t.y, n);
		c(r) && Ke(e, r) && l.push({
			id: t.id,
			x: t.x,
			y: t.y,
			rotation: n
		});
	}
	if (!l.length) for (let t of u.filter((e) => e.id !== o && !(s.includes(e.id) && s.includes(o)))) for (let n of qe(e, t.id)) c(We(e, t.id, n.x, n.y, n.rotation)) && l.push({
		id: t.id,
		...n
	});
	if (!l.length) throw Error("No minimal connected room adjustment found for discovery");
	let d = Math.min(...l.map((e) => s.includes(e.id) ? 3 : 1));
	l = l.filter((e) => (s.includes(e.id) ? 3 : 1) === d), M(e, t.actor, "games.betrayal3.adjustHouseForDiscovery", l.map((e) => {
		let n = N(`${e.id}:${e.x},${e.y},${e.rotation}`, "games.betrayal3.relocateRoom", [{
			op: "adjustDiscoveryRoom",
			actor: t.actor,
			id: e.id,
			args: {
				x: e.x,
				y: e.y,
				rotation: e.rotation
			},
			then: [t]
		}], e.id, "room", e.rotation);
		return n.params = {
			x: e.x,
			y: e.y,
			rotation: e.rotation * 90
		}, n;
	}));
}
function hn(e, t) {
	let n = e.discovery;
	M(e, t.actor, "games.betrayal3.chooseRotation", He(e, n.tile, n.floor, n.x, n.y, n.entrance).map((e) => N(`rotate-${e}`, "games.betrayal3.rotateTile", [{
		op: "placeDiscovered",
		actor: t.actor,
		n: t.n,
		args: { rotation: e }
	}], n.tile, "rotation", e)));
}
function gn(e, t) {
	let n = e.discovery, r = {
		id: n.tile,
		tile: n.tile,
		floor: n.floor,
		x: n.x,
		y: n.y,
		rotation: z(t.args, "rotation")
	};
	e.rooms.push(r), E(e, t.actor).room = Ie(r, (n.entrance + 2) % 4), e.movement -= t.n ?? 0, e.discovery = null, e.endRequested = !0, e.beatMs = Je.place, A(e, {
		key: "games.betrayal3.logDiscover",
		actor: t.actor,
		id: r.tile
	}), j(e, [
		...e.haunt ? [{
			op: "hauntEnter",
			actor: t.actor,
			id: r.id
		}] : [],
		{
			op: "roomDiscover",
			actor: t.actor,
			id: r.tile
		},
		{
			op: "roomEnter",
			actor: t.actor,
			id: r.tile
		},
		{
			op: "roomCards",
			actor: t.actor,
			id: r.tile
		}
	]);
}
function _n(e, t) {
	if (e.rooms.some((e) => e.id === t.id)) return;
	let n = t.id, r = R(t.args, "floor", g(n).floors[0]), i = Ve(e, r);
	if (Array.isArray(t.args?.avoidAdjacent)) {
		let a = e.rooms.filter((e) => t.args.avoidAdjacent.includes(e.id) && e.floor === r), o = i.filter((t) => a.every((e) => Math.abs(t.x - e.x) + Math.abs(t.y - e.y) !== 1) && He(e, n, r, t.x, t.y, t.direction).length);
		o.length && (i = o);
	}
	if (t.args?.farthestFrom) {
		let n = R(t.args, "farthestFrom"), r = Math.max(...i.map((t) => C(e, n, t.room)));
		i = i.filter((t) => C(e, n, t.room) === r);
	}
	let a = R(t.args, "reserveFor"), o = i.flatMap((i) => He(e, n, r, i.x, i.y, i.direction).filter((t) => {
		if (!a) return !0;
		let o = {
			...e,
			rooms: [...e.rooms, {
				id: n,
				tile: n,
				floor: r,
				x: i.x,
				y: i.y,
				rotation: t
			}]
		};
		return Ve(o, r).some((e) => He(o, a, r, e.x, e.y, e.direction).length);
	}).map((e) => {
		let a = N(`${i.x},${i.y},${e}`, "games.betrayal3.placeRoomAt", [{
			op: "placeRequired",
			actor: t.actor,
			id: n,
			args: {
				floor: r,
				x: i.x,
				y: i.y,
				rotation: e
			}
		}, ...t.then ?? []], i.room, "room", e);
		return a.params = { rotation: e * 90 }, a;
	}));
	if (!o.length) {
		let i = (t) => {
			let i = {
				...e,
				rooms: t
			};
			return Ve(i, r).some((e) => He(i, n, r, e.x, e.y, e.direction).length);
		}, a = [
			"entranceHall",
			"hallway",
			"groundStaircase"
		], o = [];
		for (let t of e.rooms.filter((e) => e.floor === r && !a.includes(e.id))) for (let n of [
			0,
			1,
			2,
			3
		]) {
			if (n === t.rotation) continue;
			let r = We(e, t.id, t.x, t.y, n);
			i(r) && Ke(e, r) && o.push({
				id: t.id,
				x: t.x,
				y: t.y,
				rotation: n
			});
		}
		if (!o.length) for (let t of e.rooms.filter((e) => e.floor === r && !a.includes(e.id))) for (let n of qe(e, t.id)) i(We(e, t.id, n.x, n.y, n.rotation)) && o.push({
			id: t.id,
			...n
		});
		if (!o.length) {
			let i = e.tiles.find((t) => t !== n && g(t).floors.includes(r) && Ve(e, r).some((i) => He(e, t, r, i.x, i.y, i.direction).some((a) => {
				let o = {
					...e,
					rooms: [...e.rooms, {
						id: t,
						tile: t,
						floor: r,
						x: i.x,
						y: i.y,
						rotation: a
					}]
				};
				return Ve(o, r).some((e) => He(o, n, r, e.x, e.y, e.direction).length);
			})));
			if (i) {
				j(e, [{
					op: "placeRoom",
					actor: t.actor,
					id: i,
					args: {
						floor: r,
						reserveFor: n
					}
				}, t]);
				return;
			}
			throw Error(`No connected room adjustment found to place required room ${n}`);
		}
		M(e, t.actor, "games.betrayal3.adjustHouseForPlacement", o.map((e) => {
			let n = N(`${e.id}:${e.x},${e.y},${e.rotation}`, "games.betrayal3.relocateRoom", [{
				op: "adjustDiscoveryRoom",
				actor: t.actor,
				id: e.id,
				args: e,
				then: [t]
			}], e.id, "room");
			return n.params = {
				x: e.x,
				y: e.y,
				rotation: e.rotation * 90
			}, n;
		}));
		return;
	}
	M(e, t.actor, "games.betrayal3.placeRequiredRoom", o);
}
function vn(e, t) {
	if (y(e, t.id)?.condition) return;
	let n = {
		chapel: "sanity",
		library: "knowledge",
		larder: "might",
		gymnasium: "speed"
	};
	if (t.id in n && (E(e, t.actor).character !== "elf" || e.haunt) && j(e, [{
		op: "gain",
		actor: t.actor,
		trait: n[t.id],
		n: 1
	}]), t.id === "junkRoom" && j(e, [{
		op: "token",
		actor: t.actor,
		id: "obstacle",
		args: { room: t.id }
	}]), t.id === "armory") {
		let n = e.items.findIndex((e) => je.has(e));
		if (n >= 0) {
			let r = e.items.splice(0, n), i = e.items.shift();
			e.items.push(...r), E(e, t.actor).cards.push(i), A(e, {
				key: "games.betrayal3.logDraw",
				actor: t.actor,
				id: i
			});
		}
	}
	let r = {
		panicRoom: ["secretStaircase", "B"],
		timeLostTree: ["rootCellar", "B"],
		rootCellar: ["timeLostTree", "U"]
	};
	if (r[t.id]) {
		let [n, i] = r[t.id];
		e.rooms.some((e) => e.id === n) || j(e, [{
			op: "placeRoom",
			actor: t.actor,
			id: n,
			args: { floor: i }
		}, {
			op: "shuffleTiles",
			actor: t.actor
		}]);
	}
	t.id === "oldWell" && j(e, [{
		op: "roll",
		actor: t.actor,
		trait: "knowledge",
		args: { context: "oldWell" },
		then: [{
			op: "oldWellResult",
			actor: t.actor
		}]
	}]);
}
function yn(e, t) {
	if (y(e, t.id)?.condition) return;
	let n = g(t.id).symbol;
	if (!n) return;
	let r = n === "event" || n === "event2", i = r ? "event" : n === "item" || n === "item2" ? "item" : Ze(e) === "pennywise" && !e.haunt ? "encounter" : "omen", a = Array.from({ length: n.endsWith("2") ? 2 : 1 }, () => ({
		op: "draw",
		actor: t.actor,
		id: i,
		args: {
			chooseTwo: t.id === "ancientDen",
			exploring: !0
		}
	})), o = E(e, t.actor);
	r && (k(e, o, "idol") || o.team === "traitor" && o.revealed) ? M(e, t.actor, "games.betrayal3.chooseEventDraw", [N("draw", "games.betrayal3.drawEvent", a), N("skip", "games.betrayal3.skipEvent", [])]) : j(e, a);
}
function bn(e, t) {
	let n = t.id === "item" ? e.items : t.id === "omen" ? e.omens : t.id === "event" ? e.events : e.encounters;
	if (!n.length) {
		A(e, {
			key: "games.betrayal3.logEmptyDeck",
			actor: t.actor,
			id: t.id
		});
		return;
	}
	let r = n.shift();
	if (t.id === "item" && mt(t.args, "exploring") && E(e, t.actor).character === "elf" && !e.haunt) {
		let i = [r, ...n.splice(0, 2)];
		M(e, t.actor, "games.betrayal3.chooseCardToKeep", i.map((e) => N(e, "games.betrayal3.keepCard", [{
			...t,
			op: "takeDrawn",
			id: e,
			args: {
				...t.args,
				deck: t.id,
				others: i.filter((t) => t !== e)
			}
		}], e, "card")));
		return;
	}
	if (mt(t.args, "chooseTwo") && n.length) {
		let i = n.shift();
		M(e, t.actor, "games.betrayal3.chooseCardToKeep", [r, i].map((e) => N(e, "games.betrayal3.keepCard", [{
			...t,
			op: "takeDrawn",
			id: e,
			args: {
				...t.args,
				deck: t.id,
				other: e === r ? i : r
			}
		}], e, "card")));
	} else j(e, [{
		...t,
		op: "takeDrawn",
		id: r,
		args: {
			...t.args,
			deck: t.id
		}
	}]);
}
function xn(e, t) {
	let n = R(t.args, "deck"), r = R(t.args, "other"), i = n === "item" ? e.items : n === "omen" ? e.omens : n === "event" ? e.events : e.encounters;
	r && i.push(r), Array.isArray(t.args?.others) && i.push(...t.args.others), e.beatMs = Je.draw, A(e, {
		key: "games.betrayal3.logDraw",
		actor: t.actor,
		id: t.id
	});
	let a = [];
	n === "event" ? (i.push(t.id), a.push({
		op: "event",
		actor: t.actor,
		id: t.id
	})) : n === "encounter" ? (e.encountersOut.push(t.id), a.push({
		op: "encounter",
		actor: t.actor,
		id: t.id
	})) : (E(e, t.actor).cards.push(t.id), n === "item" && E(e, t.actor).character === "jingleklaws" && !e.haunt && a.push({
		op: "deliverPrompt",
		actor: t.actor,
		id: t.id
	}), n === "omen" && (e.omenDraws++, !e.haunt && !mt(t.args, "noHaunt") && a.push({
		op: "hauntRoll",
		actor: t.actor,
		id: t.id,
		args: { automatic: e.omens.length === 0 }
	}))), e.reveal = {
		id: t.id,
		kind: n,
		actor: t.actor,
		acks: [],
		tasks: a
	};
}
function Sn(e, t) {
	switch (t.op) {
		case "move": {
			e.movement -= t.n ?? 1;
			let n = E(e, t.actor).room;
			v(n) === "windingTunnels" && v(t.id) === "windingTunnels" ? j(e, [{
				op: "roll",
				actor: t.actor,
				trait: "knowledge",
				args: { context: "windingTunnels" },
				then: [{
					op: "tunnelResult",
					actor: t.actor,
					id: t.id
				}]
			}]) : j(e, [{
				op: "relocate",
				actor: t.actor,
				id: t.id
			}, ...mt(t.args, "key") ? [{
				op: "keyRoll",
				actor: t.actor
			}] : []]);
			break;
		}
		case "tunnelResult":
			z(t.args, "total") >= 4 && j(e, [{
				op: "relocate",
				actor: t.actor,
				id: t.id
			}]);
			break;
		case "relocate": {
			let n = E(e, t.actor), r = e.monsters.find((e) => e.id === t.actor), i = n?.room ?? r?.room ?? "";
			n ? n.room = t.id : r && (r.room = t.id), A(e, {
				key: "games.betrayal3.logMove",
				actor: t.actor,
				id: t.id,
				...r?.flags.hidden === !0 ? { secretFor: [r.controller] } : {}
			}), e.beatMs = Je.move, j(e, [...e.haunt ? [{
				op: "hauntEnter",
				actor: t.actor,
				id: t.id,
				args: { from: i }
			}] : [], {
				op: "roomEnter",
				actor: t.actor,
				id: v(t.id)
			}]);
			break;
		}
		case "chooseAdjacent": {
			let n = E(e, t.actor);
			M(e, t.actor, "games.betrayal3.chooseRoom", x(e, n.room).map((e) => N(e, "games.betrayal3.moveTo", [{
				op: "relocate",
				actor: t.actor,
				id: e
			}], e, "room")));
			break;
		}
		case "discover":
			pn(e, t);
			break;
		case "adjustDiscoveryRoom":
			e.rooms = We(e, t.id, z(t.args, "x"), z(t.args, "y"), z(t.args, "rotation")), j(e, t.then ?? []);
			break;
		case "replaceTile": {
			let n = e.discovery;
			e.tiles.push(t.id), e.discovery = null, j(e, [{
				...t,
				op: "discover",
				args: {
					floor: n.floor,
					x: n.x,
					y: n.y,
					direction: n.entrance,
					from: n.from
				}
			}]);
			break;
		}
		case "placeOptions":
			hn(e, t);
			break;
		case "placeDiscovered":
			gn(e, t);
			break;
		case "placeRoom":
			_n(e, t);
			break;
		case "placeRequired":
			e.tiles = e.tiles.filter((e) => e !== t.id), e.rooms.push({
				id: t.id,
				tile: t.id,
				floor: R(t.args, "floor"),
				x: z(t.args, "x"),
				y: z(t.args, "y"),
				rotation: z(t.args, "rotation")
			});
			break;
		case "shuffleTiles":
			e.tiles = T(e, e.tiles);
			break;
		case "roomDiscover":
			vn(e, t);
			break;
		case "roomEnter": {
			if (y(e, t.id)?.condition) break;
			let n = E(e, t.actor);
			t.id === "mysticElevator" && n && !n.used.includes("mysticElevator") && (n.used.push("mysticElevator"), M(e, t.actor, "games.betrayal3.useElevator", [N("ride", "games.betrayal3.rideElevator", [{
				op: "roll",
				actor: t.actor,
				n: 2,
				args: { context: "mysticElevator" },
				then: [{
					op: "elevatorResult",
					actor: t.actor
				}]
			}]), N("stay", "games.betrayal3.stayHere", [])]));
			break;
		}
		case "roomCards":
			yn(e, t);
			break;
		case "draw":
			bn(e, t);
			break;
		case "takeDrawn":
			xn(e, t);
			break;
		case "deliverPrompt":
			M(e, t.actor, "games.betrayal3.chooseDelivery", D(e).filter((e) => e.rid !== t.actor).map((e) => N(e.rid, "games.betrayal3.giveDelivery", [{
				op: "deliverItem",
				actor: t.actor,
				target: e.rid,
				id: t.id
			}], e.rid, "player")));
			break;
		case "deliverItem": {
			let n = E(e, t.actor), r = E(e, t.target);
			n.cards = n.cards.filter((e) => e !== t.id), r.cards.push(t.id), r.startCards = r.startCards.filter((e) => e !== t.id), j(e, [{
				op: "relocate",
				actor: n.rid,
				id: r.room
			}, {
				op: "chooseGain",
				actor: n.rid,
				n: 1
			}]);
			break;
		}
		case "oldWellResult":
			z(t.args, "total") >= 4 ? j(e, [{
				op: "draw",
				actor: t.actor,
				id: "item"
			}]) : j(e, [{
				op: "buryItemChoice",
				actor: t.actor
			}]);
			break;
		case "buryItemChoice": {
			let n = E(e, t.actor).cards.filter((e) => !h.includes(e));
			M(e, t.actor, "games.betrayal3.chooseItemToBury", n.map((e) => N(e, "games.betrayal3.buryCard", [{
				op: "bury",
				actor: t.actor,
				id: e
			}], e, "card")));
			break;
		}
		case "elevatorResult": {
			let n = z(t.args, "total"), r = n === 4 ? [
				"U",
				"G",
				"B"
			] : [n === 3 ? "U" : n === 2 ? "G" : "B"], i = {
				...e,
				rooms: e.rooms.filter((e) => e.id !== "mysticElevator")
			}, a = r.flatMap((e) => Ve(i, e).map((n) => {
				let r = N(`${e}-${n.x}-${n.y}`, "games.betrayal3.moveElevatorTo", [{
					op: "elevatorMove",
					actor: t.actor,
					args: {
						floor: e,
						x: n.x,
						y: n.y,
						rotation: (n.direction + 2) % 4
					}
				}], n.room, "room");
				return r.params = { direction: Ne[n.direction] }, r;
			}));
			M(e, t.actor, "games.betrayal3.chooseElevatorDoor", a);
			break;
		}
		case "elevatorMove": {
			let n = e.rooms.find((e) => e.id === "mysticElevator");
			n.floor = R(t.args, "floor"), n.x = z(t.args, "x"), n.y = z(t.args, "y"), n.rotation = z(t.args, "rotation");
			break;
		}
		case "roomEnd": {
			let n = E(e, t.actor), r = v(n.room);
			if (y(e, n.room).condition) break;
			r === "laundryChute" && j(e, [{
				op: "relocate",
				actor: n.rid,
				id: "basementLanding"
			}]), r === "furnaceRoom" && !(n.team === "traitor" && n.revealed) && j(e, [{
				op: "damage",
				actor: n.rid,
				n: 1,
				damage: "physical"
			}]), r === "collapsedRoom" && !(n.team === "traitor" && n.revealed) && j(e, [{
				op: "roll",
				actor: n.rid,
				trait: "speed",
				args: { context: r },
				then: [{
					op: "collapsedResult",
					actor: n.rid
				}]
			}]);
			break;
		}
		case "collapsedResult":
			z(t.args, "total") < 5 && j(e, [{
				op: "relocate",
				actor: t.actor,
				id: "basementLanding"
			}, {
				op: "roll",
				actor: t.actor,
				n: 1,
				then: [{
					op: "rolledDamage",
					actor: t.actor,
					damage: "physical"
				}]
			}]);
			break;
		default: return !1;
	}
	return !0;
}
//#endregion
//#region src/game/flow.ts
function Cn(e) {
	let t = E(e, e.turn);
	if (!t || t.dead || e.phase === "done" || e.phase === "characters") return [];
	let n = [
		...dn(e, t.rid),
		...Ht(e, t.rid),
		...Wt(e, t.rid),
		...en(e, t.rid)
	];
	for (let r of e.explorers.filter((n) => n.dead && (n.room === t.room || tt(e, t, "dog") && C(e, t.room, n.room) <= 4) && !e.looted.includes(n.rid))) {
		let i = r.room !== t.room;
		for (let e of r.cards) n.push(N(`loot-${r.rid}-${e}`, "games.betrayal3.lootCard", [{
			op: "loot",
			actor: t.rid,
			target: r.rid,
			id: e,
			args: { dog: i }
		}], e, "card"));
		if (!i) for (let i of e.tokens.filter((e) => e.room === t.room && e.flags.corpse === r.rid && (e.flags.tradable === !0 || e.flags.lootable === !0) && (e.flags.heroesOnly !== !0 || t.team === "hero"))) n.push(N(`loot-${r.rid}-${i.id}`, "games.betrayal3.lootToken", [{
			op: "lootToken",
			actor: t.rid,
			target: r.rid,
			id: i.id
		}], i.id, "token"));
	}
	return n.push(N("end", "games.betrayal3.endTurn", [{
		op: "endTurn",
		actor: t.rid
	}])), n;
}
function wn(e, t) {
	let n = E(e, t.actor);
	if (n && !n.dead && e.haunt && (mt(t.args, "forced") || w.some((e) => n.traits[e] < 0)) && (mt(t.args, "ignoreReplacement") || !qt(e, t))) {
		n.dead = !0;
		for (let t of e.tokens.filter((e) => e.holder === n.rid)) t.holder = null, t.room = n.room, t.flags.corpse = n.rid;
		A(e, {
			key: "games.betrayal3.logDeath",
			actor: n.rid
		}), e.roll?.actor === n.rid && (e.roll = null), e.suspendedRolls = e.suspendedRolls.filter((e) => e.actor !== n.rid), e.prompt?.actor === n.rid && (e.prompt = null), e.queue = e.queue.filter((e) => e.actor !== n.rid || e.op.startsWith("haunt") || e.op === "nextTurn" || e.op === "endTurn"), j(e, [{
			op: "hauntDeath",
			actor: n.rid,
			target: t.target
		}]), e.turn === n.rid && !e.queue.some((e) => e.op === "nextTurn") && (e.endRequested = !0);
	}
}
function Tn(e, t) {
	switch (t.op) {
		case "gain":
			P(e, t.actor, t.trait, t.n, t.target);
			break;
		case "heal":
			F(e, t.actor, t.args?.traits ?? w);
			break;
		case "damage":
			ot(e, t.actor, t.n, t.damage, !mt(t.args, "converted"), t.target, mt(t.args, "criticalFloor"));
			break;
		case "allocateDamage":
			st(e, t.actor, t.n, t.damage, t.target, mt(t.args, "criticalFloor"));
			break;
		case "death":
			wn(e, t);
			break;
		case "beginTurn": {
			if (e.turn = t.actor, e.turnNumber++, E(e, t.actor).dead) {
				e.endRequested = !1, j(e, [{
					op: "endTurn",
					actor: t.actor
				}]);
				break;
			}
			e.movement = et(e, t.actor, "speed"), e.attacked = !1, e.traded = !1, e.looted = [], e.endRequested = !1;
			for (let t of e.explorers) t.used = [], delete t.secret.bookReady;
			let n = E(e, t.actor);
			n.startCards = [...n.cards], e.haunt && (e.haunt.used = []), A(e, {
				key: "games.betrayal3.logTurn",
				actor: t.actor,
				n: e.turnNumber
			}), e.haunt && j(e, [{
				op: "hauntTurnStart",
				actor: t.actor
			}]);
			break;
		}
		case "endTurn":
			e.endRequested = !1, j(e, [
				...E(e, t.actor).dead ? [] : [{
					op: "roomEnd",
					actor: t.actor
				}, {
					op: "necklace",
					actor: t.actor
				}],
				...e.haunt ? [{
					op: "hauntTurnEnd",
					actor: t.actor
				}] : [],
				{
					op: "nextTurn",
					actor: t.actor
				}
			]);
			break;
		case "nextTurn": {
			if (e.extraTurn && !E(e, t.actor).dead) {
				e.extraTurn = !1, j(e, [{
					op: "beginTurn",
					actor: t.actor
				}]);
				break;
			}
			let n = e.players.indexOf(t.actor), r = Array.from({ length: e.players.length }, (t, r) => e.players[(n + r + 1) % e.players.length]).find((t) => !E(e, t).dead || e.haunt?.monsterAfter === t || Array.isArray(e.haunt?.flags.deadTurns) && e.haunt.flags.deadTurns.includes(t));
			r && j(e, [{
				op: "beginTurn",
				actor: r
			}]);
			break;
		}
		case "setSecret":
			E(e, t.actor).secret[R(t.args, "key")] = t.args?.value ?? !0;
			break;
		case "noop": break;
		default: return !1;
	}
	return !0;
}
//#endregion
//#region src/game/encounters.ts
var En = {
	floatingLights: "speed",
	bloodTendrils: "sanity",
	popOfRed: "might",
	hometownHorrors: "sanity",
	swirlingVisions: "knowledge",
	stretchingHall: "sanity",
	timeToSink: "speed",
	eaterOfWorlds: "sanity"
};
function Dn(e, t) {
	if (t.op === "encounter") return A(e, {
		key: "games.betrayal3.logEncounter",
		actor: t.actor,
		id: t.id
	}), e.haunt ? (j(e, [{
		...t,
		op: "hauntEncounter"
	}]), !0) : (j(e, [En[t.id] ? {
		op: "roll",
		actor: t.actor,
		trait: En[t.id],
		args: { context: t.id },
		then: [{
			op: "encounterResult",
			actor: t.actor,
			id: t.id
		}]
	} : {
		op: "encounterAttack",
		actor: t.actor,
		id: t.id,
		trait: t.id === "goodBoy" ? "speed" : "might"
	}, {
		op: "hauntRoll",
		actor: t.actor,
		id: t.id,
		args: {
			encounter: !0,
			automatic: e.encounters.length === 0
		}
	}]), !0);
	if (t.op !== "encounterResult") return !1;
	let n = t.actor, r = z(t.args, "total") >= 4, i = {
		op: "draw",
		actor: n,
		id: "omen",
		args: { noHaunt: !0 }
	}, a = (e, t) => ({
		op: "gain",
		actor: n,
		trait: e,
		n: t
	}), o = (e) => ({
		op: "damage",
		actor: n,
		n: 1,
		damage: e
	}), s;
	switch (t.id) {
		case "floatingLights":
			s = [a("sanity", r ? 2 : -1)];
			break;
		case "bloodTendrils":
			s = [r ? i : o("mental")];
			break;
		case "popOfRed":
			s = r ? [i] : ["physical", "mental"].map((e) => ({
				op: "roll",
				actor: n,
				n: 1,
				then: [{
					op: "rolledDamage",
					actor: n,
					damage: e
				}]
			}));
			break;
		case "hometownHorrors":
			s = r ? [a("sanity", 1), i] : [o("mental")];
			break;
		case "swirlingVisions":
			s = [r ? {
				op: "chooseGain",
				actor: n,
				n: 1
			} : o("mental")];
			break;
		case "stretchingHall":
			s = [r ? i : o("physical")];
			break;
		case "timeToSink":
			s = [r ? a("might", 1) : a("speed", -1)];
			break;
		case "eaterOfWorlds":
			s = r ? [{
				op: "chooseAdjacent",
				actor: n
			}, i] : [o("general")];
			break;
		default: throw Error(`Unknown Encounter: ${t.id}`);
	}
	return j(e, s), !0;
}
//#endregion
//#region src/game/haunts/support.ts
function H(e) {
	return e.haunt;
}
function On(e, t) {
	return !H(e).used.includes(t);
}
function U(e, t, n, r, i, a, o = "action") {
	return On(e, n) ? [N(`haunt-${n}-${a ?? ""}`, r, [{
		op: "hauntUse",
		actor: t,
		id: n
	}, ...i], a, o)] : [];
}
function W(e, t, n, r = 0, i = {}) {
	return {
		op: "roll",
		actor: e,
		trait: n,
		args: {
			context: t,
			bonus: r
		},
		then: [{
			op: t,
			actor: e,
			args: i
		}]
	};
}
function G(e, t, n) {
	return {
		op: "damage",
		actor: e,
		n: t,
		damage: n
	};
}
function K(e, t, n) {
	return {
		op: "roll",
		actor: e,
		n: t,
		args: { context: n },
		then: [{
			op: "rolledDamage",
			actor: e,
			damage: n
		}]
	};
}
function kn(e, t) {
	return e.rooms.filter((e) => e.floor === t).flatMap(b);
}
function q(e, t, n) {
	return n.includes(y(e, E(e, t).room).tile);
}
function An(e, t, n) {
	let r = y(e, E(e, t).room);
	return r && !r.condition ? n === "event" ? Pn.has(r.tile) : n === "item" ? Fn.has(r.tile) : In.has(r.tile) : !1;
}
function jn(e, t, n) {
	let r = y(e, t);
	r.condition = n;
	for (let t of e.explorers) v(t.room) === r.id && (t.room = r.id);
	for (let t of e.monsters) v(t.room) === r.id && (t.room = r.id);
	for (let t of e.tokens) t.room && v(t.room) === r.id && (t.room = r.id);
}
var Mn = [
	"entranceHall",
	"hallway",
	"groundStaircase",
	"upperLanding",
	"basementLanding"
];
function Nn(e) {
	return e.rooms.filter((e) => !Mn.includes(e.id));
}
var Pn = new Set(Ce.filter((e) => e.symbol?.startsWith("event")).map((e) => e.id)), Fn = new Set(Ce.filter((e) => e.symbol?.startsWith("item")).map((e) => e.id)), In = new Set(Ce.filter((e) => e.symbol === "omen").map((e) => e.id));
function J(e, t, n, r, i = {}) {
	let a = 1;
	for (; e.monsters.some((e) => e.id === `${t}-${a}`);) a++;
	let o = {
		id: `${t}-${a}`,
		kind: t,
		room: n,
		traits: r,
		controller: H(e).traitor ?? H(e).revealer,
		attack: "might",
		damage: "physical",
		death: "stun",
		stunned: !1,
		dead: !1,
		flags: { ai: H(e).traitor ? "manual" : "pursue" },
		...i
	};
	return e.monsters.push(o), o;
}
function Y(e, t) {
	return e.tokens.filter((e) => e.kind === t).length;
}
function Ln(e, t, n) {
	return e.tokens.some((e) => e.kind === n && e.holder === t);
}
function Rn(e, t, n, r = Infinity) {
	Y(e, n) < r && !Ln(e, t, n) && L(e, n, null, t);
}
function X(e, t = H(e).id) {
	pt(e, e.explorers.filter((e) => e.team === "hero").map((e) => e.rid), t);
}
function zn(e, t = H(e).id) {
	pt(e, e.explorers.filter((e) => e.team === "traitor").map((e) => e.rid), t);
}
function Bn(e) {
	return !D(e).some((e) => e.team === "hero");
}
function Z(e) {
	Bn(e) && zn(e);
}
function Vn(e, t, n = H(e).revealer) {
	j(e, t.filter((t) => !e.rooms.some((e) => e.id === t)).map((e) => ({
		op: "placeRoom",
		actor: n,
		id: e,
		args: { floor: g(e).floors[0] }
	})));
}
function Hn(e, t, n, r) {
	if (Y(e, n) >= r) return;
	let i = E(e, t);
	M(e, t, "games.betrayal3.chooseTokenRecipient", (Ln(e, t, n) ? D(e).filter((t) => t.team === "hero" && t.room === i.room && !Ln(e, t.rid, n)) : [i]).map((e) => N(e.rid, "games.betrayal3.giveTokenTo", [{
		op: "hauntGiveToken",
		actor: e.rid,
		id: n,
		n: r
	}], e.rid, "player")));
}
function Un(e, t) {
	let n = e.monsters.filter((e) => !e.dead && (!t || t.includes(e.id)));
	return [
		...[...new Set(n.map((e) => e.kind))].map((e) => {
			let t = n.find((t) => t.kind === e);
			return {
				op: "roll",
				actor: t.id,
				n: t.traits.speed,
				args: { context: "monsterMovement" },
				then: [{
					op: "monsterMovementResult",
					actor: t.id,
					id: e
				}]
			};
		}),
		...n.map((e) => ({
			op: "monsterBegin",
			actor: e.id
		})),
		{
			op: "hauntMonsterEnd",
			actor: H(e).revealer
		}
	];
}
function Wn(e, t) {
	let n = D(e).filter((n) => $t(e, t.id, n.rid)), r = n.map((n) => Gn(e, t, t.room, n.room)), i = Math.min(...r), a = n.filter((e, t) => r[t] === i);
	if (t.flags.tie === "oldest") {
		let e = Math.max(...a.map((e) => Me(e.character).age ?? -1));
		a = a.filter((t) => (Me(t.character).age ?? -1) === e);
	}
	return a.map((e) => e.rid);
}
function Q(e, t) {
	let n = Wn(e, t), r = D(e).filter((r) => r.room === t.room && $t(e, t.id, r.rid) && (t.flags.ai === "manual" || n.includes(r.rid))), i = t.flags.attacked !== !0 && t.flags.noAttack !== !0 ? r.map((e) => N(`attack-${e.rid}`, "games.betrayal3.attackUnarmed", [{
		op: "monsterAttack",
		actor: t.id,
		target: e.rid
	}], e.rid, "player")) : [];
	if (i.length && t.flags.ai !== "manual") return i;
	let a = r.length ? 2 : 1, o = z(t.flags, "movement") >= a ? x(e, t.room, !0, t.flags.walls === !0) : [];
	if (t.flags.ai !== "manual") {
		let n = Wn(e, t).map((t) => Qt(e, t)), r = Math.min(...n.map((n) => Gn(e, t, t.room, n)));
		o = o.filter((i) => n.some((n) => Gn(e, t, i, n) < r));
	}
	return [
		...i,
		...o.map((e) => N(`move-${e}`, "games.betrayal3.moveTo", [{
			op: "monsterMove",
			actor: t.id,
			id: e
		}], e, "room")),
		...t.flags.ai === "manual" || !o.length && !i.length ? [N("finish", "games.betrayal3.finishMonster", [{
			op: "monsterFinish",
			actor: t.id
		}])] : []
	];
}
function Gn(e, t, n, r) {
	return t.flags.walls === !0 ? (Be(e, n, r, !0, !0)?.length ?? Infinity) - 1 : C(e, n, r, !0);
}
function Kn(e, t) {
	let n = e.monsters.find((e) => e.id === t.actor);
	switch (t.op) {
		case "monsterMovementResult":
			H(e).counters[`movement.${t.id}`] = Math.max(1, z(t.args, "total"));
			break;
		case "monsterBegin":
			if (!n || n.dead) break;
			if (n.stunned) {
				n.stunned = !1;
				break;
			}
			n.flags.movement = H(e).counters[`movement.${n.kind}`] ?? Math.max(1, ct(e, n.traits.speed).reduce((e, t) => e + t, 0)), n.flags.attacked = !1, j(e, [{
				op: "monsterAct",
				actor: n.id
			}]);
			break;
		case "monsterAct":
			if (!n || n.dead || n.stunned) break;
			H(e).flags.monsterActive = n.id, M(e, Zt(e, n.id), "games.betrayal3.monsterAction", Q(e, n));
			break;
		case "monsterMove":
			n.flags.movement = z(n.flags, "movement") - (D(e).some((t) => t.room === n.room && $t(e, n.id, t.rid)) ? 2 : 1), j(e, n.room.startsWith("windingTunnels:") && t.id.startsWith("windingTunnels:") && n.room !== t.id && n.flags.walls !== !0 ? [{
				op: "roll",
				actor: n.id,
				trait: "knowledge",
				args: { context: "windingTunnels" },
				then: [{
					op: "tunnelResult",
					actor: n.id,
					id: t.id
				}]
			}, {
				op: "monsterAct",
				actor: n.id
			}] : [{
				op: "relocate",
				actor: n.id,
				id: t.id
			}, {
				op: "monsterAct",
				actor: n.id
			}]);
			break;
		case "monsterAttack":
			n.flags.attacked = !0, n.flags.ai !== "manual" && (n.flags.movement = 0), nn(e, {
				...t,
				op: "attack",
				trait: n.attack,
				damage: n.damage
			}), j(e, [e.queue.shift(), {
				op: "monsterAct",
				actor: n.id
			}]);
			break;
		case "monsterFinish":
			delete H(e).flags.monsterActive;
			break;
		default: return !1;
	}
	return !0;
}
function qn(e, t) {
	switch (t.op) {
		case "hauntUse":
			H(e).used.push(t.id);
			break;
		case "hauntGiveToken":
			Rn(e, t.actor, t.id, t.n);
			break;
		case "hauntPlaceToken":
			L(e, t.id, R(t.args, "room", E(e, t.actor).room));
			break;
		case "hauntRemoveToken":
			e.tokens = e.tokens.filter((e) => e.id !== t.id);
			break;
		case "hauntSetCounter":
			H(e).counters[t.id] = t.n;
			break;
		case "hauntAddCounter":
			H(e).counters[t.id] = (H(e).counters[t.id] ?? 0) + (t.n ?? 1);
			break;
		case "hauntFlag":
			H(e).flags[t.id] = t.args?.value ?? !0;
			break;
		case "hauntStartMonsters":
			j(e, Un(e));
			break;
		case "hauntEnsureRooms": {
			let n = R(t.args, "floor");
			if (e.rooms.filter((e) => (!n || e.floor === n) && (t.args?.nonLanding !== !0 || !Mn.includes(e.id))).length >= (t.n ?? 0)) break;
			let r = e.tiles.find((e) => !n || g(e).floors.includes(n));
			if (!r) throw Error("Insufficient room tiles for haunt setup");
			j(e, [{
				op: "placeRoom",
				actor: t.actor,
				id: r,
				args: { floor: n || g(r).floors[0] }
			}, t]);
			break;
		}
		case "hauntMoveSteps": {
			let n = Qt(e, t.target), r = E(e, t.target)?.dead ?? e.monsters.find((e) => e.id === t.target)?.dead;
			if ((t.n ?? 0) <= 0 || r) break;
			M(e, t.actor, "games.betrayal3.chooseRoom", [...x(e, n, !E(e, t.target)).map((e) => N(e, "games.betrayal3.moveTo", [{
				op: "relocate",
				actor: t.target,
				id: e
			}, {
				...t,
				n: t.n - 1
			}], e, "room")), N("stop", "games.betrayal3.stopMoving", [])]);
			break;
		}
		default: return !1;
	}
	return !0;
}
var $ = $e;
//#endregion
//#region src/game/haunts/early.ts
function Jn(e, t) {
	Y(e, "knowledgeOfJack") >= 2 || M(e, t, "games.betrayal3.chooseTokenRecipient", O(e).filter((t) => !Ln(e, t.rid, "knowledgeOfJack")).map((e) => N(e.rid, "games.betrayal3.giveTokenTo", [{
		op: "hauntGiveToken",
		actor: e.rid,
		id: "knowledgeOfJack",
		n: 2
	}], e.rid, "player")));
}
var Yn = {
	setup(e) {
		let t = H(e).traitor;
		F(e, t), P(e, t, "might", $(e, [
			1,
			1,
			2,
			2
		])), P(e, t, "speed", $(e, [
			1,
			1,
			2,
			2
		])), H(e).flags.deadTurns = [t], H(e).monsterAfter = "";
	},
	actions(e, t) {
		let n = E(e, t);
		if (n.team === "traitor") return e.attacked || O(e).some((t) => S(e, t.room, n.room)) ? [] : e.rooms.filter((t) => t.floor !== "B" && !O(e).some((n) => S(e, n.room, t.id))).flatMap((n) => U(e, t, "stalk", "games.betrayal3.stalkPrey", [{
			op: "relocate",
			actor: t,
			id: n.id
		}], n.id, "room"));
		let r = [];
		if (q(e, t, ["library"]) && Y(e, "knowledgeOfJack") < 2 && r.push(...U(e, t, "learnJack", "games.betrayal3.learnJack", [W(t, "jackKnowledgeResult", "knowledge")])), An(e, t, "event") && r.push(...U(e, t, "studyExorcism", "games.betrayal3.studyExorcism", [W(t, "jackCircleResult", "knowledge")])), e.monsters.some((e) => e.kind === "jackSpirit" && !e.dead && e.room === n.room)) {
			let i = e.tokens.filter((t) => t.kind === "exorcismCircle" && y(e, t.room).floor === y(e, n.room).floor).length;
			r.push(...U(e, t, "exorciseJack", "games.betrayal3.exorciseJack", [W(t, "jackExorciseResult", "sanity", i)]));
		}
		return r;
	},
	handle(e, t) {
		if (t.op === "roll" && t.args?.attack === !0 && Ln(e, t.actor, "knowledgeOfJack")) {
			let n = e.monsters.find((e) => e.id === t.args?.attackSource);
			(t.args.defense !== !0 && t.args.attackTarget === H(e).traitor || t.args.defense === !0 && n?.kind === "jackSpirit") && (t.args.bonus = z(t.args, "bonus") + 2);
		}
		if (t.op === "hauntDeath" && t.actor === H(e).traitor) {
			let n = E(e, t.actor), r = e.rooms.filter((e) => g(e.tile).symbol === "omen"), i = r.length ? r : e.rooms, a = Math.max(...i.map((t) => C(e, n.room, t.id)));
			return M(e, n.rid, "games.betrayal3.placeJackSpirit", i.filter((t) => C(e, n.room, t.id) === a).flatMap(b).map((e) => N(e, "games.betrayal3.placeToken", [{
				op: "jackSpawn",
				actor: n.rid,
				id: e
			}], e, "room"))), !0;
		}
		if (t.op === "beginTurn" && t.actor === H(e).traitor && E(e, t.actor).dead) {
			let n = e.monsters.find((e) => e.kind === "jackSpirit" && !e.dead);
			if (n.room === E(e, t.actor).room) {
				let r = E(e, t.actor);
				return r.dead = !1, F(e, r.rid), n.dead = !0, !1;
			}
			return e.turn = t.actor, e.turnNumber++, e.endRequested = !1, j(e, [...Un(e, [n.id]), {
				op: "nextTurn",
				actor: t.actor
			}]), !0;
		}
		switch (t.op) {
			case "jackSpawn": return J(e, "jackSpirit", t.id, B(5, 3, 4, 4), {
				controller: t.actor,
				death: "immune",
				flags: {
					ai: "manual",
					walls: !0
				}
			}), !0;
			case "jackKnowledgeResult": return z(t.args, "total") >= 5 && Jn(e, t.actor), !0;
			case "jackCircleResult": {
				if (z(t.args, "total") < 5) return j(e, [G(t.actor, 2, "mental")]), !0;
				let n = e.tokens.filter((e) => e.kind === "exorcismCircle");
				return n.length < 2 ? L(e, "exorcismCircle", E(e, t.actor).room) : M(e, t.actor, "games.betrayal3.chooseCircle", n.map((e) => N(e.id, "games.betrayal3.moveCircle", [{
					op: "jackMoveCircle",
					actor: t.actor,
					id: e.id
				}], e.room, "room"))), !0;
			}
			case "jackMoveCircle": return e.tokens.find((e) => e.id === t.id).room = E(e, t.actor).room, !0;
			case "jackExorciseResult": return z(t.args, "total") >= 7 ? X(e) : j(e, O(e).map((e) => G(e.rid, 1, "physical"))), !0;
			case "hauntMonsterEnd": return !0;
			default: return !1;
		}
	},
	check: Z
}, Xn = {
	setup(e) {
		J(e, "demonRealtor", "entranceHall", B(5, 3, 6, 4), {
			attack: "sanity",
			damage: "mental",
			death: "immune"
		}), H(e).monsterAfter = H(e).revealer, j(e, [{
			op: "realtorPlaceFires",
			actor: H(e).revealer,
			n: $(e, [
				3,
				2,
				1,
				0
			])
		}]);
	},
	actions(e, t) {
		let n = E(e, t), r = e.monsters.find((e) => e.kind === "demonRealtor"), i = Ln(e, t, "knowledgeOfCurse"), a = [];
		if (q(e, t, [
			"library",
			"chapel",
			"laboratory"
		]) && Y(e, "knowledgeOfCurse") < 2 && a.push(...U(e, t, "learnCurse", "games.betrayal3.learnCurse", [W(t, "realtorKnowledgeResult", "knowledge")])), An(e, t, "event") && Y(e, "cleansedFire") < 6 && !e.tokens.some((e) => e.kind === "cleansedFire" && e.room === n.room) && a.push(...U(e, t, "cleanseRoom", "games.betrayal3.cleanseRoom", [W(t, "realtorCleanseResult", "speed", i ? 2 : 0)])), q(e, t, [
			"nursery",
			"armory",
			"graveyard"
		]) && Y(e, "wardOfProtection") < 2 && !Ln(e, t, "wardOfProtection") && a.push(...U(e, t, "prepareWard", "games.betrayal3.prepareWard", [W(t, "realtorWardResult", "might", i ? 2 : 0)])), n.room === r.room) {
			let r = e.tokens.filter((t) => t.kind === "cleansedFire" && y(e, t.room).floor === y(e, n.room).floor).length;
			a.push(...U(e, t, "freeRealtor", "games.betrayal3.freeRealtor", [W(t, "realtorRitualResult", "sanity", r + (i ? 2 : 0) + +!!q(e, t, ["ritualRoom"]))]));
		}
		return a;
	},
	handle(e, t) {
		let n = e.monsters.find((e) => e.kind === "demonRealtor");
		if (t.op === "roll" && t.args?.attack === !0 && Ln(e, t.actor, "wardOfProtection") && (t.args.attackTarget === n.id || t.args.attackSource === n.id) && (t.args.extraDice = z(t.args, "extraDice") + 2), t.op === "characterDamage" && t.actor === n.id && (t.n ?? 0) > 0) return j(e, [{
			op: "realtorPush",
			actor: Zt(e, t.target),
			n: t.n
		}]), !0;
		switch (t.op) {
			case "realtorPlaceFires": {
				if ((t.n ?? 0) <= 0) return !0;
				let n = [...new Set(O(e).map((e) => e.room))].filter((t) => !e.tokens.some((e) => e.kind === "cleansedFire" && e.room === t));
				return M(e, t.actor, "games.betrayal3.chooseTokenRoom", n.map((e) => N(e, "games.betrayal3.placeToken", [{
					op: "hauntPlaceToken",
					actor: t.actor,
					id: "cleansedFire",
					args: { room: e }
				}, {
					...t,
					n: t.n - 1
				}], e, "room"))), !0;
			}
			case "realtorKnowledgeResult": return z(t.args, "total") >= 5 && Hn(e, t.actor, "knowledgeOfCurse", 2), !0;
			case "realtorCleanseResult": return z(t.args, "total") >= 6 && L(e, "cleansedFire", E(e, t.actor).room), !0;
			case "realtorWardResult": return z(t.args, "total") >= 6 && L(e, "wardOfProtection", null, t.actor), !0;
			case "realtorRitualResult": {
				let n = z(t.args, "total");
				if (n >= 13) X(e);
				else {
					if (n < 9) for (let t of O(e)) P(e, t.rid, "sanity", -1);
					e.endRequested = !0;
				}
				return !0;
			}
			case "realtorPush": return (t.n ?? 0) <= 0 || M(e, t.actor, "games.betrayal3.moveRealtor", [...x(e, n.room, !0).map((e) => N(e, "games.betrayal3.moveTo", [{
				op: "relocate",
				actor: n.id,
				id: e
			}, {
				...t,
				n: t.n - 1
			}], e, "room")), N("stop", "games.betrayal3.stopMoving", [])]), !0;
			case "hauntMonsterEnd": return j(e, O(e).filter((t) => y(e, t.room).floor === y(e, n.room).floor).map((e) => K(e.rid, 1, "mental"))), !0;
			default: return !1;
		}
	},
	check(e) {
		Bn(e) && pt(e, [], "realtorLoss");
	}
}, Zn = {
	setup(e) {
		for (let t of O(e)) Qn(e, t.room);
		H(e).monsterAfter = H(e).revealer, j(e, [{
			op: "cherubPlace",
			actor: H(e).revealer,
			n: $(e, [
				3,
				4,
				5,
				6
			])
		}]);
	},
	actions(e, t) {
		let n = E(e, t), r = e.monsters.filter((e) => e.kind === "stoneCherub" && !e.dead);
		return r.filter((e) => e.room === n.room).flatMap((i) => r.filter((t) => t.id !== i.id && S(e, i.room, t.room)).flatMap((r) => U(e, t, "peekaboo", "games.betrayal3.playPeekaboo", [W(t, "cherubPeekResult", "knowledge", k(e, n, "mirror") ? 2 : 0, {
			first: i.id,
			second: r.id
		})], `${i.id}:${r.id}`, "token")));
	},
	handle(e, t) {
		let n = e.monsters.filter((e) => e.kind === "stoneCherub" && !e.dead);
		if (t.op === "monsterAct") {
			let r = n.find((e) => e.id === t.actor);
			if (r && O(e).some((t) => S(e, t.room, r.room))) return delete H(e).flags.monsterActive, !0;
		}
		switch (t.op) {
			case "cherubPlace": {
				if ((t.n ?? 0) <= 0) return !0;
				let n = e.rooms.flatMap(b), r = n.filter((t) => !O(e).some((n) => S(e, n.room, t))), i = r.length ? r : n;
				return M(e, t.actor, "games.betrayal3.placeCherub", i.map((e) => N(e, "games.betrayal3.placeToken", [{
					op: "cherubSpawn",
					actor: t.actor,
					id: e
				}, {
					...t,
					n: t.n - 1
				}], e, "room"))), !0;
			}
			case "cherubSpawn": return Qn(e, t.id), !0;
			case "cherubPeekResult":
				if (z(t.args, "total") >= 4) for (let n of [R(t.args, "first"), R(t.args, "second")]) e.monsters.find((e) => e.id === n).dead = !0;
				else j(e, [K(t.actor, 2, "general")]);
				return !0;
			case "hauntTurnStart": {
				let r = E(e, t.actor);
				return r.secret.cherubsSeen = n.filter((t) => S(e, r.room, t.room)).map((e) => e.id), !0;
			}
			case "hauntEnter": {
				let r = E(e, t.actor);
				if (!r || r.dead || r.used.includes("stonyGaze")) return !0;
				let i = r.secret.cherubsSeen ?? [];
				return n.some((t) => !i.includes(t.id) && S(e, r.room, t.room)) && (r.used.push("stonyGaze"), j(e, [K(r.rid, 2, "general")])), !0;
			}
			case "hauntMonsterEnd": return j(e, O(e).map((t) => K(t.rid, n.filter((n) => S(e, t.room, n.room)).length, "general"))), !0;
			default: return !1;
		}
	},
	check(e) {
		e.monsters.filter((e) => e.kind === "stoneCherub").length > 0 && !e.monsters.some((e) => e.kind === "stoneCherub" && !e.dead) ? X(e) : Bn(e) && pt(e, [], "cherubLoss");
	}
};
function Qn(e, t) {
	J(e, "stoneCherub", t, B(8, 4, 8, 8), {
		death: "immune",
		flags: {
			ai: "pursue",
			noAttack: !0,
			untargetable: !0
		}
	});
}
//#endregion
//#region src/game/haunts/hidden.ts
var $n = [
	"panicRoom",
	"furnaceRoom",
	"ballroom",
	"operatingTheatre",
	"junkRoom"
], er = [
	"upperLanding",
	"groundStaircase",
	"basementLanding"
];
function tr(e) {
	return O(e).filter((t) => $n.includes(y(e, t.room).tile)).length;
}
function nr(e, t) {
	j(e, [G(t, 6, "general"), {
		op: "chooseRoom",
		actor: t,
		args: { rooms: er }
	}]);
}
var rr = {
	setup(e) {
		H(e).track = $(e, [
			6,
			5,
			4,
			3
		]), H(e).flags.deadTurns = [H(e).revealer];
	},
	actions(e, t) {
		return E(e, t).cards.includes("ring") ? ["speed", "knowledge"].flatMap((n) => U(e, t, "destroyRing", "games.betrayal3.destroyRing", [W(t, "ringDestroyResult", n, tr(e), { originalBonus: tr(e) })], n, "trait")) : [];
	},
	handle(e, t) {
		switch (t.op) {
			case "ringDestroyResult": {
				let n = z(t.args, "total");
				return n < 7 ? nr(e, t.actor) : !E(e, H(e).traitor).revealed && !E(e, H(e).traitor).dead ? (M(e, H(e).traitor, "games.betrayal3.ringCounterPrompt", [N("reveal", "games.betrayal3.revealAndDisplace", [
					{
						op: "ringReveal",
						actor: H(e).traitor
					},
					...O(e).map((t) => ({
						op: "ringDisplace",
						actor: H(e).traitor,
						target: t.rid
					})),
					{
						op: "ringCounterResult",
						actor: t.actor,
						n: n - z(t.args, "originalBonus")
					}
				]), N("allow", "games.betrayal3.allowRingDestroyed", [{
					op: "ringDestroyed",
					actor: t.actor
				}])]), e.prompt.secretFor = [H(e).traitor]) : j(e, [{
					op: "ringDestroyed",
					actor: t.actor
				}]), !0;
			}
			case "ringReveal": {
				let n = E(e, t.actor);
				return n.revealed = !0, F(e, n.rid), P(e, n.rid, "might", 1), !0;
			}
			case "ringDisplace": return M(e, t.actor, "games.betrayal3.chooseLandingForHero", er.map((e) => N(e, "games.betrayal3.moveTo", [{
				op: "relocate",
				actor: t.target,
				id: e
			}], e, "room"))), !0;
			case "ringCounterResult": return t.n + tr(e) >= 7 ? j(e, [{
				op: "ringDestroyed",
				actor: t.actor
			}]) : nr(e, t.actor), !0;
			case "ringDestroyed":
				for (let t of e.explorers) t.cards = t.cards.filter((e) => e !== "ring"), t.startCards = t.startCards.filter((e) => e !== "ring");
				return e.omens = e.omens.filter((e) => e !== "ring"), X(e), !0;
			case "hauntTurnEnd":
				if (t.actor === H(e).revealer) {
					if (H(e).track--, H(e).track <= 0) return zn(e), !0;
					j(e, D(e).filter((e) => !(e.team === "traitor" && e.revealed)).map((e) => ({
						op: "ringReturn",
						actor: e.rid
					})));
				}
				return !0;
			case "ringReturn": return M(e, t.actor, "games.betrayal3.timeLoopReturn", [...er.map((e) => N(e, "games.betrayal3.moveTo", [{
				op: "relocate",
				actor: t.actor,
				id: e
			}], e, "room")), N("stay", "games.betrayal3.stayAndTakeMental", [G(t.actor, 2, "mental")])]), !0;
			default: return !1;
		}
	},
	check(e) {
		E(e, H(e).traitor).dead ? X(e) : O(e).length || zn(e);
	}
};
function ir(e, t) {
	return E(e, t).secret.sickness;
}
function ar(e, t, n) {
	let r = ir(e, t), i = ir(e, n);
	if (!r.length || !i.length) return;
	let a = Ye(e, r.length), o = Ye(e, i.length);
	[r[a], i[o]] = [i[o], r[a]];
	for (let r of [t, n]) {
		let t = E(e, r);
		ir(e, r).includes(1) && (t.team = "traitor"), t.used.push("sicknessSwap");
	}
}
var or = {
	setup(e) {
		let t = e.players.length === 6 ? 2 : 1, n = T(e, Array.from({ length: 16 }, (e, t) => 2 + t % 8)), r = T(e, [...Array.from({ length: t }, () => 1), ...n.slice(0, e.players.length * 3 - t)]);
		e.explorers.forEach((t, n) => {
			t.secret.sickness = r.slice(n * 3, n * 3 + 3), t.team = ir(e, t.rid).includes(1) ? "traitor" : "hero";
		}), H(e).traitor = e.explorers.find((e) => e.team === "traitor").rid, H(e).monsterAfter = H(e).revealer;
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (An(e, t, "omen") && !e.tokens.some((e) => e.kind === "dustResearch" && e.room === n.room) && Y(e, "dustResearch") < 8) for (let n of ["knowledge", "sanity"]) r.push(...U(e, t, "dustSearch", "games.betrayal3.searchDustCure", [W(t, "dustResearchResult", n)], n, "trait"));
		if (q(e, t, [
			"laboratory",
			"operatingTheatre",
			"observatory",
			"kitchen"
		])) for (let n of w) r.push(...U(e, t, "cureDust", "games.betrayal3.cureDust", [W(t, "dustCureResult", n, Y(e, "dustResearch") * 2)], n, "trait"));
		for (let i of D(e).filter((e) => e.rid !== t && e.room === n.room)) r.push(...U(e, t, "controlImpulses", "games.betrayal3.controlImpulses", [{
			op: "dustSwapRequest",
			actor: t,
			target: i.rid
		}], i.rid, "player"));
		return r;
	},
	handle(e, t) {
		switch (t.op) {
			case "dustResearchResult": return z(t.args, "total") >= 5 ? L(e, "dustResearch", E(e, t.actor).room) : ar(e, t.actor, e.players[(e.players.indexOf(t.actor) + 1) % e.players.length]), !0;
			case "dustCureResult": return z(t.args, "total") >= 13 ? X(e) : ar(e, t.actor, e.players[(e.players.indexOf(t.actor) + 1) % e.players.length]), !0;
			case "dustSwapRequest": return M(e, t.target, "games.betrayal3.acceptSicknessSwap", [N("accept", "games.betrayal3.accept", [{
				op: "dustSwap",
				actor: t.actor,
				target: t.target
			}]), N("decline", "games.betrayal3.decline", [])]), !0;
			case "dustSwap": return ar(e, t.actor, t.target), !0;
			case "hauntTurnEnd": {
				let n = E(e, t.actor);
				return n.dead || j(e, [...D(e).filter((e) => e.rid !== n.rid && e.room === n.room).map((e) => ({
					op: "dustSwap",
					actor: n.rid,
					target: e.rid
				})), {
					op: "dustCheckSwap",
					actor: n.rid
				}]), !0;
			}
			case "dustCheckSwap": {
				let n = E(e, t.actor);
				return n.used.includes("sicknessSwap") || (n.secret.feverRisk = !0, j(e, [K(n.rid, 2, "general"), {
					op: "dustClearRisk",
					actor: n.rid
				}])), !0;
			}
			case "dustClearRisk": return delete E(e, t.actor).secret.feverRisk, !0;
			case "hauntDeath": {
				let n = E(e, t.actor);
				if (n.team === "traitor" && n.secret.feverRisk === !0) {
					for (let t of [...n.cards]) I(e, n.rid, t);
					J(e, "feverish", n.room, B(6, 5, 3, 3), {
						controller: n.rid,
						flags: { ai: "manual" }
					});
				}
				return !0;
			}
			case "hauntMonsterEnd": return !0;
			default: return !1;
		}
	},
	check: Z
};
function sr(e, t) {
	let n = E(e, t);
	n.revealed || (n.revealed = !0, n.team === "traitor" && (F(e, t), P(e, t, "might", 1)));
}
var cr = {
	setup(e) {
		j(e, [{
			op: "evidencePlace",
			actor: H(e).revealer,
			n: 0
		}]);
	},
	actions(e, t) {
		let n = E(e, t), r = [], i = e.tokens.filter((e) => e.kind === "evidence");
		for (let e of i.filter((e) => e.room === n.room && !e.flags.corpse)) r.push(N(`take-${e.id}`, "games.betrayal3.takeEvidence", [{
			op: "evidenceTake",
			actor: t,
			id: e.id
		}], e.id, "token"));
		let a = i.filter((e) => e.holder === t);
		for (let o of a) i.some((t) => t.id !== o.id && t.trait === o.trait && (t.room === n.room || t.holder && E(e, t.holder).room === n.room)) && r.push(...U(e, t, "uncoverTruth", "games.betrayal3.uncoverTruth", [W(t, "inheritanceTruthResult", o.trait)], o.trait, "trait"));
		return n.team === "traitor" && !n.revealed && r.push(N("reveal", "games.betrayal3.revealIdentity", [{
			op: "inheritanceReveal",
			actor: t
		}])), r;
	},
	handle(e, t) {
		if (t.op === "death") {
			let n = E(e, t.actor);
			if (n.team === "traitor" && !n.revealed && n.secret.inheritanceRisk === !0) return sr(e, n.rid), !0;
		}
		switch (t.op) {
			case "evidencePlace": {
				let n = t.n ?? 0;
				if (n >= 8) return !0;
				let r = w[Math.floor(n / 2)], i = e.tokens.find((e) => e.kind === "evidence" && e.trait === r), a = new Set(e.tokens.filter((e) => e.kind === "evidence").map((e) => e.room)), o = e.rooms.filter((t) => !a.has(t.id) && (!i || t.floor !== y(e, i.room).floor));
				if (o.length) M(e, t.actor, "games.betrayal3.placeEvidence", o.flatMap((e) => (e.tile === "windingTunnels" ? [`${e.id}:a`, `${e.id}:b`] : [e.id]).map((e) => N(e, "games.betrayal3.placeToken", [{
					op: "evidenceMake",
					actor: t.actor,
					id: e,
					trait: r
				}, {
					...t,
					n: n + 1
				}], e, "room"))));
				else {
					let n = e.tiles.filter((t) => !i || [...g(t).floors].some((t) => t !== y(e, i.room).floor))[0];
					if (!n) throw Error("No room remains to place all Evidence on separate tiles");
					let r = [...g(n).floors].find((t) => !i || t !== y(e, i.room).floor);
					j(e, [{
						op: "placeRoom",
						actor: t.actor,
						id: n,
						args: { floor: r }
					}, t]);
				}
				return !0;
			}
			case "evidenceMake": {
				let n = L(e, "evidence", t.id, null, 1, t.trait);
				return e.tokens.find((e) => e.id === n).flags.tradable = !0, !0;
			}
			case "evidenceTake": {
				let n = e.tokens.find((e) => e.id === t.id);
				return n.room = null, n.holder = t.actor, !0;
			}
			case "inheritanceTruthResult":
				if (z(t.args, "total") >= 5) {
					let t = [...e.explorers].filter((e) => !e.revealed).sort((e, t) => z(t.secret, "number") - z(e.secret, "number"))[0];
					t && sr(e, t.rid);
				}
				return !0;
			case "inheritanceReveal": return sr(e, t.actor), !0;
			case "hauntDeath": return E(e, t.actor).revealed = !0, !0;
			case "hauntTurnEnd": {
				let n = E(e, t.actor);
				return !n.dead && !e.attacked && !(n.team === "traitor" && n.revealed) && (n.secret.inheritanceRisk = !0, j(e, [K(n.rid, 2, "mental"), {
					op: "inheritanceClearRisk",
					actor: n.rid
				}])), !0;
			}
			case "inheritanceClearRisk": return delete E(e, t.actor).secret.inheritanceRisk, !0;
			default: return !1;
		}
	},
	check(e) {
		E(e, H(e).traitor).dead ? X(e) : Z(e);
	}
}, lr = {
	setup(e) {
		let t = E(e, H(e).revealer);
		t.dead = !0, t.secret.mirrorTrait = w[Ye(e, 4)], t.secret.mirrorOmen = h[Ye(e, h.length)], e.tiles = T(e, e.tiles), t.secret.mirrorRoom = e.tiles.at(-1) ?? e.rooms[Ye(e, e.rooms.length)].tile, e.tiles = T(e, e.tiles), H(e).flags.deadTurns = [t.rid], H(e).monsterAfter = t.rid;
		for (let n = 0; n < $(e, [
			2,
			3,
			4,
			5
		]); n++) J(e, "mirrorBeing", "entranceHall", B(4, 3, 6, 4), {
			attack: "sanity",
			damage: "mental",
			controller: t.rid
		});
	},
	actions(e, t) {
		let n = E(e, t);
		return w.flatMap((r) => n.cards.filter((e) => h.includes(e)).flatMap((i) => U(e, t, "breakMirrorSpell", "games.betrayal3.breakMirrorSpell", [W(t, "mirrorSpellResult", r, 0, {
			trait: r,
			omen: i,
			room: y(e, n.room).tile
		})], `${r}:${i}`, "card")));
	},
	handle(e, t) {
		switch (t.op) {
			case "roomCards": return g(t.id).symbol?.startsWith("event") ? (e.endRequested = !1, !0) : !1;
			case "beginTurn": return t.actor === H(e).revealer && (e.turn = t.actor, e.turnNumber++, e.endRequested = !1, j(e, [{
				op: "mirrorChooseClue",
				actor: t.actor
			}]), !0);
			case "mirrorChooseClue": {
				let n = e.events.map((e) => N(e, "games.betrayal3.chooseMirrorClue", [{
					op: "mirrorChooseRecipient",
					actor: t.actor,
					id: e
				}], e, "card"));
				return n.length ? (M(e, t.actor, "games.betrayal3.mirrorCluePrompt", n), e.prompt.secretFor = [t.actor]) : j(e, [{
					op: "endTurn",
					actor: t.actor
				}]), !0;
			}
			case "mirrorChooseRecipient": return M(e, t.actor, "games.betrayal3.chooseClueRecipient", O(e).map((e) => N(e.rid, "games.betrayal3.sendClue", [{
				op: "mirrorSendClue",
				actor: t.actor,
				target: e.rid,
				id: t.id
			}], e.rid, "player"))), e.prompt.secretFor = [t.actor], !0;
			case "mirrorSendClue": return e.events = e.events.filter((e) => e !== t.id), A(e, {
				key: "games.betrayal3.logMirrorClue",
				actor: t.actor,
				target: t.target,
				id: t.id,
				secretFor: [t.target]
			}), j(e, [{
				op: "endTurn",
				actor: t.actor
			}]), !0;
			case "mirrorSpellResult": {
				if (z(t.args, "total") < 5) return !0;
				let n = E(e, H(e).revealer).secret;
				return t.args?.trait === n.mirrorTrait && t.args?.omen === n.mirrorOmen && t.args?.room === n.mirrorRoom ? X(e) : A(e, {
					key: "games.betrayal3.logMirrorRejected",
					actor: t.actor
				}), !0;
			}
			case "hauntMonsterEnd": return !0;
			default: return !1;
		}
	},
	check(e) {
		Bn(e) && pt(e, [], "mirrorLoss");
	}
}, ur = [
	"bloodyRoom",
	"charredRoom",
	"collapsedRoom",
	"junkRoom",
	"catacombs"
], dr = {
	setup(e) {
		H(e).monsterAfter = H(e).revealer, j(e, [{
			op: "housekeepingRooms",
			actor: H(e).revealer
		}]);
	},
	actions(e, t) {
		return !q(e, t, ur) || e.tokens.some((n) => n.kind === "cleanedRoom" && n.room === E(e, t).room) ? [] : ["speed", "sanity"].flatMap((n) => U(e, t, "cleanHouse", "games.betrayal3.cleanHouse", [W(t, "housekeepingCleanResult", n)], n, "trait"));
	},
	handle(e, t) {
		switch (t.op) {
			case "housekeepingRooms": {
				if (e.rooms.filter((e) => g(e.tile).symbol?.startsWith("event")).length >= e.players.length || !e.tiles.length) return j(e, [{
					op: "housekeepingSpawn",
					actor: t.actor,
					n: e.players.length
				}]), !0;
				let n = (t, n) => Ve(e, n).some((r) => He(e, t, n, r.x, r.y, r.direction).length), r = e.tiles.findIndex((e) => [...g(e).floors].some((t) => n(e, t)));
				r > 0 && e.tiles.push(...e.tiles.splice(0, r));
				let i = e.tiles[0], a = [...g(i).floors].filter((e) => r < 0 || n(i, e));
				return M(e, t.actor, "games.betrayal3.chooseRoomFloor", a.map((e) => N(e, "games.betrayal3.placeRoomOnFloor", [{
					op: "placeRoom",
					actor: t.actor,
					id: i,
					args: { floor: e }
				}, { ...t }], e, "action"))), !0;
			}
			case "housekeepingSpawn": {
				if ((t.n ?? 0) <= 0) return !0;
				let n = e.rooms.filter((t) => g(t.tile).symbol?.startsWith("event") && !e.monsters.some((e) => e.kind === "housekeeper" && e.room === t.id));
				if (!n.length) return !0;
				let r = (t) => e.monsters.filter((n) => n.kind === "housekeeper" && y(e, n.room).floor === t).length, i = Math.min(...n.map((e) => r(e.floor)));
				return M(e, t.actor, "games.betrayal3.placeHousekeeper", n.filter((e) => r(e.floor) === i).flatMap(b).map((e) => N(e, "games.betrayal3.placeToken", [{
					op: "housekeepingMake",
					actor: t.actor,
					id: e
				}, {
					...t,
					n: t.n - 1
				}], e, "room"))), !0;
			}
			case "housekeepingMake": return J(e, "housekeeper", t.id, B(5, 4, 5, 5), { flags: {
				ai: "pursue",
				tie: "oldest"
			} }), !0;
			case "housekeepingCleanResult": return z(t.args, "total") >= 5 && L(e, "cleanedRoom", E(e, t.actor).room), !0;
			case "hauntMonsterEnd": return j(e, D(e).map((e) => G(e.rid, 1, "general"))), !0;
			default: return !1;
		}
	},
	check(e) {
		Y(e, "cleanedRoom") === 5 ? X(e) : Bn(e) && pt(e, [], "housekeepingLoss");
	}
};
//#endregion
//#region src/game/haunts/competitive.ts
function fr(e) {
	D(e).length <= 1 && pt(e, D(e).map((e) => e.rid), H(e).id);
}
function pr(e) {
	return z(e.args, "attackTotal") - z(e.args, "total");
}
function mr(e) {
	return {
		op: "characterDamage",
		actor: e.target,
		target: e.actor,
		n: pr(e),
		damage: e.damage
	};
}
var hr = {
	setup(e) {
		H(e).track = 1;
	},
	actions(e, t) {
		return An(e, t, "item") ? U(e, t, "searchShelves", "games.betrayal3.searchShelves", [W(t, "bygonesSearchResult", "knowledge")]) : [];
	},
	handle(e, t) {
		if (t.op === "roll" && t.trait === "might" && t.actor === e.turn && t.args?.attack === !0 && t.args.defense !== !0 && E(e, t.actor).cards.includes("idol") && (t.args.bonus = z(t.args, "bonus") + H(e).track), t.op === "attack" && !t.id && !t.args?.offeringPrepared && E(e, t.actor).cards.filter((e) => !h.includes(e)).length) return j(e, [{
			op: "bygonesBuryMenu",
			actor: t.actor,
			n: 0,
			then: [t]
		}]), !0;
		if (t.op === "combatResult" && t.trait === "might" && pr(t) > 0 && E(e, t.target)?.cards.includes("idol")) return M(e, t.actor, "games.betrayal3.chooseStealOrDamage", [N("steal", "games.betrayal3.stealIdol", [{
			op: "bygonesSteal",
			actor: t.actor,
			target: t.target
		}]), N("damage", "games.betrayal3.dealCombatDamage", [mr(t)])]), !0;
		switch (t.op) {
			case "bygonesBuryMenu": {
				let n = E(e, t.actor).cards.filter((e) => !h.includes(e)), r = {
					...t.then[0],
					args: {
						...t.then[0].args,
						offeringPrepared: !0,
						bonus: (t.n ?? 0) + z(t.then[0].args, "bonus")
					}
				};
				return M(e, t.actor, "games.betrayal3.buryForAttack", [...n.map((e) => N(e, "games.betrayal3.buryCard", [{
					op: "bury",
					actor: t.actor,
					id: e
				}, {
					...t,
					n: (t.n ?? 0) + 1
				}], e, "card")), N("attack", "games.betrayal3.makeAttack", [r])]), !0;
			}
			case "bygonesSearchResult": return z(t.args, "total") >= 5 && j(e, [{
				op: "draw",
				actor: t.actor,
				id: "item"
			}]), !0;
			case "bygonesSteal": return at(e, t.target, t.actor, "idol"), !0;
			case "hauntDeath": return t.target && E(e, t.target)?.cards.includes("idol") && H(e).track++, !0;
			default: return !1;
		}
	},
	check: fr
}, gr = {
	setup(e) {
		H(e).track = 4, H(e).flags.deadTurns = [H(e).revealer];
		let t = $(e, [
			2,
			3,
			4,
			5
		]);
		H(e).secret.treasureValues = T(e, Array.from({ length: t * 2 - 1 }, (e, n) => n < t ? n + 1 : n - t + 1)), j(e, [{
			op: "offerPrepareVault",
			actor: H(e).revealer,
			n: t
		}]);
	},
	actions(e, t) {
		let n = E(e, t);
		return e.tokens.some((e) => e.kind === "treasure" && e.room === n.room && !e.flags.corpse) ? U(e, t, "searchTreasure", "games.betrayal3.searchTreasure", [W(t, "offerSearchResult", "knowledge")]) : [];
	},
	handle(e, t) {
		if (t.op === "combatResult" && t.trait === "might" && pr(t) > 0 && e.tokens.some((e) => e.kind === "treasure" && e.holder === t.target)) return M(e, t.actor, "games.betrayal3.chooseStealOrDamage", [N("steal", "games.betrayal3.stealRandomTreasure", [{
			op: "offerSteal",
			actor: t.actor,
			target: t.target
		}]), N("damage", "games.betrayal3.dealCombatDamage", [mr(t)])]), !0;
		switch (t.op) {
			case "offerPrepareVault": return e.rooms.some((e) => e.id === "vault") ? j(e, [{
				...t,
				op: "offerPlaceVaultTreasure"
			}]) : j(e, [{
				op: "placeRoom",
				actor: t.actor,
				id: "vault",
				args: {
					floor: "G",
					farthestFrom: "entranceHall"
				}
			}, {
				...t,
				op: "offerPlaceVaultTreasure"
			}]), !0;
			case "offerPlaceVaultTreasure": return _r(e, "vault", t.n), j(e, [{
				op: "offerDistribute",
				actor: t.actor
			}]), !0;
			case "offerDistribute": {
				let n = H(e).secret.treasureValues;
				if (!n.length) return !0;
				let r = e.rooms.filter((e) => g(e.tile).symbol === "omen"), i = r.length ? r : [e.rooms.find((e) => e.id === "vault")], a = (t) => e.tokens.filter((n) => n.kind === "treasure" && n.room !== "vault" && n.room && y(e, n.room).floor === t).length, o = Math.min(...i.map((e) => a(e.floor))), s = i.filter((e) => a(e.floor) === o), c = s[Ye(e, s.length)];
				return _r(e, c.id, n.shift()), j(e, [t]), !0;
			}
			case "offerMakeTreasure": return _r(e, t.id, H(e).secret.treasureValues.shift()), !0;
			case "offerSearchResult": {
				let n = z(t.args, "total"), r = E(e, t.actor);
				if (n <= 0) return !0;
				let i = e.tokens.filter((e) => e.kind === "treasure" && e.room === r.room && !e.flags.corpse);
				return M(e, t.actor, n >= 4 ? "games.betrayal3.takeTreasurePrompt" : "games.betrayal3.peekTreasurePrompt", i.map((e) => N(e.id, n >= 4 ? "games.betrayal3.takeTreasure" : "games.betrayal3.peekTreasure", [{
					op: n >= 4 ? "offerTake" : "offerPeek",
					actor: t.actor,
					id: e.id
				}], e.id, "token"))), !0;
			}
			case "offerTake": {
				let n = e.tokens.find((e) => e.id === t.id);
				return n.room = null, n.holder = t.actor, !0;
			}
			case "offerPeek": {
				let n = e.tokens.find((e) => e.id === t.id);
				return A(e, {
					key: "games.betrayal3.logTreasureValue",
					actor: t.actor,
					id: n.id,
					n: n.value,
					secretFor: [t.actor]
				}), !0;
			}
			case "offerSteal": {
				let n = e.tokens.filter((e) => e.kind === "treasure" && e.holder === t.target);
				return n[Ye(e, n.length)].holder = t.actor, !0;
			}
			case "hauntTurnEnd": return t.actor === H(e).revealer && --H(e).track <= 0 && vr(e), !0;
			default: return !1;
		}
	},
	check(e) {
		D(e).length || pt(e, [], "offerLoss");
	}
};
function _r(e, t, n) {
	let r = L(e, "treasure", t, null, n), i = e.tokens.find((e) => e.id === r);
	i.hidden = !0, i.flags.lootable = !0;
}
function vr(e) {
	let t = D(e).map((t) => ({
		rid: t.rid,
		score: e.tokens.filter((e) => e.kind === "treasure" && e.holder === t.rid).reduce((e, t) => e + t.value, 0) + (t.room === "groundStaircase" ? 2 : 0)
	})), n = Math.max(...t.map((e) => e.score));
	for (let n of t) H(e).counters[`score.${n.rid}`] = n.score;
	pt(e, t.filter((e) => e.score === n).map((e) => e.rid), "10");
}
//#endregion
//#region src/game/haunts/witches.ts
var yr = (e) => z(e.args, "attackTotal") - z(e.args, "total"), br = (e) => ({
	op: "characterDamage",
	actor: e.target,
	target: e.actor,
	n: yr(e),
	damage: e.damage
}), xr = {
	setup(e) {
		H(e).counters.foodRemaining = $(e, [
			2,
			3,
			4,
			5
		]), H(e).flags.deadTurns = [H(e).revealer];
	},
	actions(e, t) {
		return H(e).counters.foodRemaining <= 0 ? [] : U(e, t, "rummageFood", "games.betrayal3.rummageFood", [W(t, "witchFoodResult", "knowledge", q(e, t, [
			"kitchen",
			"larder",
			"diningRoom",
			"panicRoom",
			"graveyard"
		]) ? 2 : 0)]);
	},
	handle(e, t) {
		if (t.op === "combatResult" && t.trait === "might" && yr(t) > 0 && Ln(e, t.target, "witchFood")) return M(e, t.actor, "games.betrayal3.chooseStealOrDamage", [N("steal", "games.betrayal3.stealFood", [{
			op: "witchStealFood",
			actor: t.actor,
			target: t.target
		}]), N("damage", "games.betrayal3.dealCombatDamage", [br(t)])]), !0;
		switch (t.op) {
			case "witchFoodResult":
				if (z(t.args, "total") >= 6 && H(e).counters.foodRemaining > 0) {
					let n = L(e, "witchFood", null, t.actor);
					e.tokens.find((e) => e.id === n).flags.tradable = !0, H(e).counters.foodRemaining--;
				}
				return !0;
			case "witchStealFood": return e.tokens.find((e) => e.kind === "witchFood" && e.holder === t.target).holder = t.actor, !0;
			case "hauntTurnEnd": return t.actor === H(e).revealer && H(e).counters.foodRemaining === 0 && j(e, [...D(e).filter((t) => !Ln(e, t.rid, "witchFood")).map((e) => ({
				op: "death",
				actor: e.rid,
				args: { forced: !0 }
			})), {
				op: "witchResetFood",
				actor: t.actor
			}]), !0;
			case "witchResetFood": return e.tokens = e.tokens.filter((e) => e.kind !== "witchFood"), H(e).counters.foodRemaining = Math.max(0, D(e).length - 1), !0;
			default: return !1;
		}
	},
	check(e) {
		D(e).length <= 1 && pt(e, D(e).map((e) => e.rid), "11");
	}
}, Sr = {
	setup(e) {
		e.explorers.some((e) => e.cards.includes("strangeAmulet")) || (e.items = e.items.filter((e) => e !== "strangeAmulet"), E(e, H(e).revealer).cards.push("strangeAmulet")), H(e).monsterAfter = H(e).revealer;
		for (let t of ["entranceHall", "basementLanding"]) J(e, "trollHand", t, B(5, 3, 4, 4), {
			death: "immune",
			flags: {
				ai: "manual",
				owned: !0
			}
		});
	},
	actions() {
		return [];
	},
	handle(e, t) {
		let n = D(e).find((e) => e.cards.includes("strangeAmulet"));
		if (t.op === "hauntStartMonsters") {
			if (!n) return !0;
			for (let t of e.monsters) t.controller = n.rid, t.flags.attacked = !1, delete t.flags.combined;
		}
		if (t.op === "combatResult" && t.trait === "might" && yr(t) > 0 && E(e, t.actor) && E(e, t.target)?.cards.length) return M(e, t.actor, "games.betrayal3.chooseStealOrDamage", [...E(e, t.target).cards.map((e) => N(`steal-${e}`, "games.betrayal3.stealCard", [{
			op: "handsSteal",
			actor: t.actor,
			target: t.target,
			id: e
		}], e, "card")), N("damage", "games.betrayal3.dealCombatDamage", [br(t)])]), !0;
		if (t.op === "monsterAct") {
			let r = e.monsters.find((e) => e.id === t.actor), i = e.monsters.find((e) => e.id !== r.id && !e.dead && e.room === r.room);
			if (!n || r.dead) return !0;
			let a = Q(e, r);
			return i && r.flags.attacked !== !0 && i.flags.attacked !== !0 && i.flags.combined !== !0 && a.push(...D(e).filter((t) => t.room === r.room && $t(e, r.id, t.rid)).map((e) => N(`combine-${e.rid}`, "games.betrayal3.combineHands", [{
				op: "handsCombinedAttack",
				actor: r.id,
				target: e.rid
			}], e.rid, "player"))), M(e, n.rid, "games.betrayal3.monsterAction", a), !0;
		}
		switch (t.op) {
			case "handsSteal": return at(e, t.target, t.actor, t.id), !0;
			case "handsCombinedAttack": {
				let n = e.monsters.find((e) => e.id === t.actor), r = e.monsters.find((e) => e.id !== n.id && !e.dead && e.room === n.room);
				return n.flags.attacked = !0, r.flags.attacked = !0, r.flags.combined = !0, j(e, [{
					op: "attack",
					actor: n.id,
					target: t.target,
					trait: "might",
					args: { extraDice: 3 }
				}, {
					op: "monsterAct",
					actor: n.id
				}]), !0;
			}
			case "monsterBegin": {
				let n = e.monsters.find((e) => e.id === t.actor);
				return n.flags.combined === !0 && (delete n.flags.combined, n.flags.movement = H(e).counters[`movement.${n.kind}`] ?? 1, n.flags.attacked = !0, j(e, [{
					op: "monsterAct",
					actor: n.id
				}]), !0);
			}
			case "hauntMonsterEnd":
				for (let t of e.monsters) delete t.flags.combined;
				return !0;
			default: return !1;
		}
	},
	check(e) {
		let t = D(e);
		t.length === 1 && t[0].cards.includes("strangeAmulet") ? pt(e, [t[0].rid], "12") : t.length || pt(e, [], "handsLoss");
	}
}, Cr = {
	setup(e) {
		let t = H(e).traitor;
		F(e, t), P(e, t, "might", 1), P(e, t, "speed", 1), H(e).track = 3, H(e).monsterAfter = t, j(e, [{
			op: "holyGroundSpawn",
			actor: t
		}]), Vn(e, ["ritualRoom", "chasm"], t);
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team === "traitor") {
			if (H(e).flags.carriedCorpse) q(e, t, ["chasm"]) && r.push(...U(e, t, "feedSleeper", "games.betrayal3.feedSleeper", [{
				op: "holyConsumeCorpse",
				actor: t
			}, W(t, "holyFeedResult", "sanity")]));
			else {
				let i = [...e.explorers.filter((e) => e.dead && e.room === n.room && e.secret.bodyRemoved !== !0).map((e) => e.rid), ...e.monsters.filter((e) => e.dead && e.kind === "cultist" && e.room === n.room && e.flags.bodyRemoved !== !0).map((e) => e.id)];
				for (let e of i) r.push(N(`carry-${e}`, "games.betrayal3.carryCorpse", [{
					op: "holyCarry",
					actor: t,
					id: e
				}], e, "player"));
			}
			return r;
		}
		if (q(e, t, [
			"library",
			"chapel",
			"ritualRoom"
		]) && Y(e, "ritualKnowledge") < 8 && r.push(...U(e, t, "studyRitual", "games.betrayal3.studyRitual", [W(t, "holyStudyResult", "knowledge")])), q(e, t, ["ritualRoom"])) {
			let n = e.tokens.filter((e) => e.kind === "ritualKnowledge" && e.holder === t).length, i = e.monsters.filter((e) => e.kind === "cultist" && !e.dead).length;
			r.push(...U(e, t, "disruptRitual", "games.betrayal3.disruptRitual", [W(t, "holyDisruptResult", "sanity", n - i)]));
		}
		return r;
	},
	handle(e, t) {
		switch (t.op) {
			case "holyGroundSpawn":
				for (let t = 0; t < e.players.length; t++) J(e, "cultist", "ritualRoom", B(5, 3, 3, 3), {
					death: "kill",
					flags: { ai: "manual" }
				});
				return !0;
			case "holyCarry": return H(e).flags.carriedCorpse = t.id, !0;
			case "holyConsumeCorpse": {
				let t = R(H(e).flags, "carriedCorpse"), n = E(e, t), r = e.monsters.find((e) => e.id === t);
				return n && (n.secret.bodyRemoved = !0), r && (r.flags.bodyRemoved = !0), delete H(e).flags.carriedCorpse, !0;
			}
			case "hauntEnter": {
				if (t.actor !== H(e).traitor || !H(e).flags.carriedCorpse) return !0;
				let n = R(H(e).flags, "carriedCorpse"), r = E(e, n), i = e.monsters.find((e) => e.id === n);
				if (r) {
					r.room = t.id;
					for (let n of e.tokens.filter((e) => e.flags.corpse === r.rid)) n.room = t.id;
				}
				return i && (i.room = t.id), !0;
			}
			case "holyFeedResult": return z(t.args, "total") >= 7 ? --H(e).track <= 0 && zn(e) : P(e, t.actor, "sanity", 2), !0;
			case "holyStudyResult": return z(t.args, "total") >= 5 && Y(e, "ritualKnowledge") < 8 && L(e, "ritualKnowledge", null, t.actor), !0;
			case "holyDisruptResult": {
				let n = z(t.args, "total");
				return n >= 6 ? X(e) : j(e, [G(t.actor, n >= 4 ? 1 : 2, "mental")]), !0;
			}
			case "hauntTurnEnd": return t.actor === H(e).traitor && j(e, O(e).map((e) => G(e.rid, 1, "general"))), !0;
			case "hauntMonsterEnd": return !0;
			default: return !1;
		}
	},
	check(e) {
		E(e, H(e).traitor).dead && !e.monsters.some((e) => e.kind === "cultist" && !e.dead) ? X(e) : Z(e);
	}
}, wr = {
	setup(e) {
		let t = H(e).traitor;
		F(e, t), H(e).track = $(e, [
			4,
			4,
			5,
			5
		]), H(e).monsterAfter = t;
		for (let t of O(e).filter((e) => !e.cards.includes("book"))) J(e, "animatedFurniture", t.room, B(6, 3, 4, 2), { flags: { ai: "manual" } });
	},
	actions(e, t) {
		let n = E(e, t);
		return n.cards.includes("book") ? n.team === "traitor" ? q(e, t, [
			"kitchen",
			"furnaceRoom",
			"laboratory"
		]) ? U(e, t, "burnBook", "games.betrayal3.burnBook", [{
			op: "permanenceBurnBook",
			actor: t
		}]) : [] : H(e).flags.spellHastened === !0 ? [] : U(e, t, "hastenSpell", "games.betrayal3.hastenSpell", [{
			op: "hauntFlag",
			actor: t,
			id: "spellHastened"
		}, W(t, "permanenceSpellResult", "sanity")]) : [];
	},
	handle(e, t) {
		if (t.op === "death" && t.actor === H(e).traitor && E(e, t.actor).dead === !1) {
			let n = e.monsters.filter((e) => e.kind === "animatedFurniture" && !e.dead);
			if (n.length) return M(e, t.actor, "games.betrayal3.rebornFurniture", n.map((e) => N(e.id, "games.betrayal3.rebornHere", [{
				op: "permanenceReborn",
				actor: t.actor,
				id: e.id
			}], e.room, "room"))), !0;
		}
		switch (t.op) {
			case "permanenceSpellResult": return z(t.args, "total") >= 5 && H(e).track--, P(e, t.actor, "sanity", -1), H(e).track <= 0 && X(e), !0;
			case "permanenceBurnBook": return E(e, t.actor).cards = E(e, t.actor).cards.filter((e) => e !== "book"), zn(e), !0;
			case "permanenceReborn": {
				let n = e.monsters.find((e) => e.id === t.id), r = E(e, t.actor);
				return n.dead = !0, r.dead = !1, F(e, r.rid), j(e, [{
					op: "relocate",
					actor: r.rid,
					id: n.room
				}, ...r.cards.includes("book") && O(e).length ? [{
					op: "permanenceGiveBook",
					actor: r.rid
				}] : []]), !0;
			}
			case "permanenceGiveBook": {
				let n = E(e, t.actor), r = O(e), i = Math.min(...r.map((t) => C(e, n.room, t.room)));
				return M(e, n.rid, "games.betrayal3.giveBookNearest", r.filter((t) => C(e, n.room, t.room) === i).map((e) => N(e.rid, "games.betrayal3.giveCard", [{
					op: "permanenceTransferBook",
					actor: n.rid,
					target: e.rid
				}], e.rid, "player"))), !0;
			}
			case "permanenceTransferBook": return at(e, t.actor, t.target, "book"), !0;
			case "hauntMonsterEnd": return H(e).flags.spellHastened = !1, D(e).some((e) => e.team === "hero" && e.cards.includes("book")) && H(e).track--, H(e).track <= 0 && X(e), !0;
			default: return !1;
		}
	},
	check: Z
}, Tr = {
	setup(e) {
		let t = E(e, H(e).traitor);
		t.dead = !0, H(e).flags.deadTurns = [t.rid];
		let n = T(e, [
			"ghost",
			"vampire",
			"werewolf"
		]).slice(0, $(e, [
			1,
			2,
			2,
			3
		]));
		for (let r of n) J(e, r, t.room, r === "ghost" ? B(4, 4, 5, 5) : r === "vampire" ? B(5, 4, 5, 5) : B(6, 4, 4, 4), {
			controller: t.rid,
			death: r === "ghost" ? "immune" : "stun",
			flags: {
				ai: "manual",
				walls: r === "ghost",
				blood: 0
			}
		});
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		(An(e, t, "item") || An(e, t, "omen")) && r.push(...U(e, t, "searchWeapons", "games.betrayal3.searchWeapons", [W(t, "mayhemSearchResult", "knowledge")]));
		let i = e.monsters.find((e) => e.kind === "ghost" && !e.dead && e.room === n.room);
		return i && tt(e, n, "holySymbol") && !e.attacked && r.push(N("holySymbolAttack", "games.betrayal3.attackGhostSymbol", [{
			op: "attack",
			actor: t,
			target: i.id,
			id: "holySymbol",
			trait: "sanity"
		}], i.id, "token")), r;
	},
	handle(e, t) {
		if (t.op === "beginTurn" && t.actor === H(e).traitor) return e.turn = t.actor, e.turnNumber++, e.endRequested = !1, H(e).flags.mayhemRemaining = e.monsters.filter((e) => !e.dead).map((e) => e.id), j(e, [{
			op: "mayhemChooseMonster",
			actor: t.actor
		}]), !0;
		if (t.op === "combatResult" && z(t.args, "attackTotal") > z(t.args, "total")) {
			let n = e.monsters.find((e) => e.id === t.target);
			if (n && (n.kind === "ghost" && t.id === "holySymbol" || n.kind === "vampire" && t.id === "crossbow" || n.kind === "werewolf" && t.id === "dagger")) return n.dead = !0, !0;
		}
		if (t.op === "monsterAct") {
			let n = e.monsters.find((e) => e.id === t.actor);
			if (n.dead || n.stunned) return !0;
			H(e).flags.monsterActive = n.id;
			let r = Q(e, n);
			if (n.flags.attacked !== !0) for (let t of O(e).filter((e) => e.room === n.room)) r.push(N(`special-${t.rid}`, n.kind === "ghost" ? "games.betrayal3.sayBoo" : n.kind === "vampire" ? "games.betrayal3.slurp" : "games.betrayal3.howl", [{
				op: "mayhemSpecialAttack",
				actor: n.id,
				target: t.rid
			}], t.rid, "player"));
			return M(e, n.controller, "games.betrayal3.monsterAction", r), !0;
		}
		switch (t.op) {
			case "mayhemChooseMonster": {
				let n = H(e).flags.mayhemRemaining.filter((t) => !e.monsters.find((e) => e.id === t).dead);
				return n.length ? M(e, t.actor, "games.betrayal3.chooseMonsterOrder", n.map((e) => N(e, "games.betrayal3.takeMonsterTurn", [{
					op: "mayhemRunMonster",
					actor: t.actor,
					id: e
				}], e, "token"))) : j(e, [{
					op: "nextTurn",
					actor: t.actor
				}]), !0;
			}
			case "mayhemRunMonster": return H(e).flags.mayhemRemaining = H(e).flags.mayhemRemaining.filter((e) => e !== t.id), j(e, [...Un(e, [t.id]), {
				op: "mayhemChooseMonster",
				actor: t.actor
			}]), !0;
			case "mayhemSearchResult": {
				if (z(t.args, "total") < 4) return !0;
				let n = g(e.rooms.find((n) => n.id === E(e, t.actor).room.split(":")[0]).tile).symbol, r = (n?.startsWith("item") ? e.items : e.omens).splice(0, 4);
				return r.length && M(e, t.actor, "games.betrayal3.chooseCardToKeep", r.map((e) => N(e, "games.betrayal3.keepCard", [{
					op: "takeDrawn",
					actor: t.actor,
					id: e,
					args: {
						deck: n?.startsWith("item") ? "item" : "omen",
						others: r.filter((t) => t !== e),
						noHaunt: !0
					}
				}], e, "card"))), !0;
			}
			case "mayhemSpecialAttack": {
				let n = e.monsters.find((e) => e.id === t.actor);
				n.flags.attacked = !0;
				let r = {
					op: "attack",
					actor: n.id,
					target: t.target,
					trait: n.kind === "ghost" ? "sanity" : "might",
					args: { bonus: n.kind === "vampire" ? z(n.flags, "blood") : 0 }
				};
				return n.kind === "ghost" ? j(e, [
					r,
					{
						op: "roll",
						actor: t.target,
						trait: "speed",
						args: { context: "sayBoo" },
						then: [{
							op: "mayhemBooMovement",
							actor: n.controller,
							target: t.target
						}]
					},
					{
						op: "monsterAct",
						actor: n.id
					}
				]) : n.kind === "vampire" ? j(e, [
					r,
					{
						op: "mayhemAddBlood",
						actor: n.id
					},
					{
						op: "monsterAct",
						actor: n.id
					}
				]) : j(e, [r, {
					op: "mayhemHowlAgain",
					actor: n.id,
					args: { attacked: [t.target] }
				}]), !0;
			}
			case "mayhemAddBlood": {
				let n = e.monsters.find((e) => e.id === t.actor);
				return n.flags.blood = z(n.flags, "blood") + 1, !0;
			}
			case "mayhemBooMovement": return j(e, [{
				op: "mayhemBooStep",
				actor: t.actor,
				target: t.target,
				n: z(t.args, "total")
			}]), !0;
			case "mayhemBooStep": {
				let n = E(e, t.target);
				return n.dead || (t.n ?? 0) <= 0 || M(e, t.actor, "games.betrayal3.moveFrightenedHero", [...x(e, n.room).map((e) => N(e, "games.betrayal3.moveTo", [{
					op: "relocate",
					actor: n.rid,
					id: e
				}, {
					...t,
					n: t.n - 1
				}], e, "room")), N("stop", "games.betrayal3.stopMoving", [])]), !0;
			}
			case "mayhemHowlAgain": {
				let n = e.monsters.find((e) => e.id === t.actor), r = t.args?.attacked;
				if (n.dead || n.stunned) return !0;
				let i = O(e).filter((e) => e.room === n.room && !r.includes(e.rid));
				return M(e, n.controller, "games.betrayal3.repeatHowl", [...i.map((e) => N(e.rid, "games.betrayal3.howl", [{
					op: "attack",
					actor: n.id,
					target: e.rid,
					trait: "might"
				}, {
					...t,
					args: { attacked: [...r, e.rid] }
				}], e.rid, "player")), N("stop", "games.betrayal3.stopAttacking", [{
					op: "monsterAct",
					actor: n.id
				}])]), !0;
			}
			case "hauntMonsterEnd": return !0;
			default: return !1;
		}
	},
	check(e) {
		e.monsters.length && e.monsters.every((e) => e.dead) ? X(e) : Z(e);
	}
}, Er = {
	setup(e) {
		let t = H(e).traitor;
		F(e, t), H(e).monsterAfter = t, H(e).counters.ghostReserve = $(e, [
			2,
			3,
			4,
			5
		]), H(e).secret.remainsOrder = T(e, Array.from({ length: $(e, [
			4,
			5,
			6,
			7
		]) }, (e, t) => t + 1)), j(e, [
			{
				op: "hauntEnsureRooms",
				actor: t,
				n: $(e, [
					4,
					5,
					6,
					7
				])
			},
			{
				op: "remainsPlace",
				actor: t,
				n: 0
			},
			{
				op: "remainsGhostSetup",
				actor: t,
				n: 2
			}
		]), Vn(e, ["graveyard"], t);
	},
	actions(e, t) {
		let n = E(e, t);
		if (n.team === "traitor") return Re(e, n.room, !0).filter((t) => O(e).some((e) => e.room === t)).flatMap((n) => U(e, t, "breakThrough", "games.betrayal3.breakThrough", [{
			op: "relocate",
			actor: t,
			id: n
		}], n, "room"));
		let r = e.tokens.filter((e) => e.kind === "remains" && e.room === n.room && !e.flags.corpse), i = [];
		for (let n of r) n.hidden && i.push(...U(e, t, "unearthRemains", "games.betrayal3.unearthRemains", [{
			op: "remainsTake",
			actor: t,
			id: n.id
		}], n.id, "token")), i.push(...U(e, t, "identifyRemains", "games.betrayal3.identifyRemains", [W(t, "remainsIdentifyResult", "knowledge", 0, { token: n.id })], n.id, "token"));
		return q(e, t, ["graveyard"]) && e.tokens.some((e) => e.kind === "remains" && e.value === 1 && e.holder === t) && i.push(...U(e, t, "consecrateRemains", "games.betrayal3.consecrateRemains", [W(t, "remainsConsecrateResult", "sanity")])), i;
	},
	handle(e, t) {
		if (t.op === "monsterAct") {
			let n = e.monsters.find((e) => e.id === t.actor);
			if (n.dead || n.stunned) return !0;
			let r = Q(e, n);
			if (n.flags.attacked !== !0) for (let t of O(e).filter((e) => e.room === n.room)) r.push(N(`sanity-${t.rid}`, "games.betrayal3.attackSanity", [{
				op: "remainsGhostAttack",
				actor: n.id,
				target: t.rid
			}], t.rid, "player"));
			return H(e).flags.monsterActive = n.id, M(e, n.controller, "games.betrayal3.monsterAction", r), !0;
		}
		if (t.op === "lootToken" && e.tokens.find((e) => e.id === t.id)?.kind === "remains") {
			for (let n of e.tokens.filter((e) => e.kind === "remains" && e.flags.corpse === t.target)) n.holder = t.actor, n.room = null, n.hidden = !1, delete n.flags.corpse;
			return e.looted.push(t.target), !0;
		}
		switch (t.op) {
			case "remainsPlace": {
				let n = H(e).secret.remainsOrder, r = t.n ?? 0;
				if (r >= n.length) return !0;
				let i = e.tokens.filter((e) => e.kind === "remains"), a = new Set(i.map((t) => y(e, t.room).floor)), o = [
					"U",
					"G",
					"B"
				].filter((e) => !a.has(e)), s = e.rooms.filter((t) => !i.some((n) => y(e, n.room).id === t.id) && (n.length - r > o.length || o.includes(t.floor)));
				return M(e, t.actor, "games.betrayal3.placeRemains", s.flatMap(b).map((e) => N(e, "games.betrayal3.placeToken", [{
					op: "remainsMake",
					actor: t.actor,
					id: e,
					n: n[r]
				}, {
					...t,
					n: r + 1
				}], e, "room")), { n: n[r] }), e.prompt.secretFor = [t.actor], !0;
			}
			case "remainsMake": {
				let n = L(e, "remains", t.id, null, t.n), r = e.tokens.find((e) => e.id === n);
				return r.hidden = !0, r.flags.tradable = !0, H(e).secret[`token.${n}`] = t.n, !0;
			}
			case "remainsGhostSetup": return (t.n ?? 0) > 0 && M(e, t.actor, "games.betrayal3.placeAngryGhost", e.rooms.filter((t) => !O(e).some((n) => y(e, n.room).id === t.id)).flatMap(b).map((e) => N(e, "games.betrayal3.placeToken", [{
				op: "remainsSpawnGhost",
				actor: t.actor,
				id: e
			}, {
				...t,
				n: t.n - 1
			}], e, "room"))), !0;
			case "remainsSpawnGhost": return J(e, "angryGhost", t.id, B(5, 4, 4, 4)), !0;
			case "remainsTake": {
				let n = e.tokens.find((e) => e.id === t.id);
				return n.holder = t.actor, n.room = null, n.hidden = !1, !0;
			}
			case "remainsIdentifyResult": {
				let n = e.tokens.find((e) => e.id === t.args?.token);
				return z(t.args, "total") >= 5 && (n.hidden = !1, n.value === 1 && (n.holder = t.actor, n.room = null)), !0;
			}
			case "remainsConsecrateResult": return z(t.args, "total") >= 5 ? X(e) : j(e, [G(t.actor, 2, "mental")]), !0;
			case "remainsGhostAttack": {
				let n = e.monsters.find((e) => e.id === t.actor);
				return n.flags.attacked = !0, j(e, [{
					op: "attack",
					actor: n.id,
					target: t.target,
					trait: "sanity"
				}, {
					op: "monsterAct",
					actor: n.id
				}]), !0;
			}
			case "hauntDeath": return H(e).counters.ghostReserve > 0 && (H(e).counters.ghostReserve--, J(e, "angryGhost", E(e, t.actor).room, B(5, 4, 4, 4))), !0;
			case "hauntTurnStart": return t.actor === H(e).traitor && j(e, O(e).map((t) => G(t.rid, e.tokens.filter((e) => e.kind === "remains" && e.holder === t.rid).length, "mental"))), !0;
			default: return !1;
		}
	},
	check: Z
}, Dr = {
	setup(e) {
		let t = H(e).traitor;
		F(e, t), H(e).monsterAfter = t;
		let n = $(e, [
			6,
			5,
			4,
			3
		]);
		H(e).secret.messages = T(e, Array.from({ length: n }, (e, t) => +(t === 0))), H(e).counters.messagesRemaining = n;
		for (let n = 0; n < 3; n++) J(e, "gremlin", E(e, t).room, B(5, 6, 6, 2), {
			death: "kill",
			flags: {
				ai: "manual",
				untargetable: !0
			}
		});
	},
	actions(e, t) {
		return E(e, t).team !== "hero" || !q(e, t, [
			"tower",
			"gallery",
			"observatory"
		]) || !e.monsters.some((e) => !e.dead && e.flags.untargetable === !0) ? [] : U(e, t, "researchGremlins", "games.betrayal3.researchGremlins", [W(t, "gremlinResearchResult", "knowledge")]);
	},
	handle(e, t) {
		switch (t.op) {
			case "gremlinResearchResult": return z(t.args, "total") >= 5 ? M(e, t.actor, "games.betrayal3.chooseGremlinRune", e.monsters.filter((e) => !e.dead && e.flags.untargetable === !0).map((e) => N(e.id, "games.betrayal3.markGremlin", [{
				op: "gremlinRune",
				actor: t.actor,
				id: e.id
			}], e.id, "token"))) : j(e, [G(t.actor, 1, "mental")]), !0;
			case "gremlinRune": {
				let n = e.monsters.find((e) => e.id === t.id);
				return n.flags.untargetable = !1, L(e, "gremlinRune", null, n.id), !0;
			}
			case "hauntTurnEnd": {
				if (E(e, t.actor).team !== "hero" || E(e, t.actor).dead) return !0;
				let n = H(e).secret.messages.shift();
				return A(e, {
					key: n === 1 ? "games.betrayal3.logMessageDie" : "games.betrayal3.logMessageX",
					actor: t.actor
				}), n === 1 && (H(e).secret.messages = T(e, Array.from({ length: $(e, [
					6,
					5,
					4,
					3
				]) }, (e, t) => +(t === 0))), j(e, [{
					op: "gremlinEmailAttack",
					actor: H(e).traitor,
					target: t.actor,
					n: 2,
					args: { used: [] }
				}])), H(e).counters.messagesRemaining = H(e).secret.messages.length, !0;
			}
			case "gremlinEmailAttack": {
				if ((t.n ?? 0) <= 0 || E(e, t.target).dead) return !0;
				let n = t.args?.used, r = e.monsters.filter((e) => !e.dead && !e.stunned && !n.includes(e.id)).map((r) => N(r.id, "games.betrayal3.teleportGremlinAttack", [
					{
						op: "relocate",
						actor: r.id,
						id: E(e, t.target).room
					},
					{
						op: "attack",
						actor: r.id,
						target: t.target
					},
					{
						...t,
						n: t.n - 1,
						args: { used: [...n, r.id] }
					}
				], r.id, "token"));
				return M(e, t.actor, "games.betrayal3.chooseGremlinAttack", [...r, N("finish", "games.betrayal3.stopAttacking", [])]), !0;
			}
			default: return !1;
		}
	},
	check(e) {
		E(e, H(e).traitor).dead && e.monsters.every((e) => e.dead) ? X(e) : Z(e);
	}
}, Or = {
	setup(e) {
		P(e, H(e).traitor, "sanity", 1), H(e).track = $(e, [
			6,
			4,
			3,
			2
		]), H(e).monsterAfter = H(e).traitor, H(e).flags.deadTurns = [H(e).traitor], j(e, [{
			op: "tapePlace",
			actor: H(e).traitor,
			n: 5
		}, {
			op: "tapeSpiritPlace",
			actor: H(e).traitor
		}]);
	},
	actions(e, t) {
		let n = E(e, t);
		if (n.team === "traitor") return e.attacked ? [] : O(e).filter((e) => e.room === n.room).map((e) => N(`sanity-${e.rid}`, "games.betrayal3.attackSanity", [{
			op: "attack",
			actor: t,
			target: e.rid,
			trait: "sanity"
		}], e.rid, "player"));
		let r = e.tokens.filter((e) => e.kind === "videotape" && e.room === n.room).flatMap((n) => U(e, t, "destroyTape", "games.betrayal3.destroyTape", [W(t, "tapeDestroyResult", "might", 0, { token: n.id })], n.id, "token"));
		return e.monsters.some((e) => e.kind === "vengefulSpirit" && e.room === n.room) && r.push(...U(e, t, "staveCurse", "games.betrayal3.staveCurse", [{
			op: "roll",
			actor: t,
			n: 1,
			args: { context: "staveCurse" },
			then: [{
				op: "tapeStaveResult",
				actor: t
			}]
		}])), r;
	},
	handle(e, t) {
		if (t.op === "monsterAct") {
			let n = e.monsters.find((e) => e.id === t.actor);
			if (n.dead || n.stunned) return !0;
			let r = Q(e, n), i = O(e).some((e) => e.room === n.room) ? 2 : 1;
			if (e.tokens.some((e) => e.kind === "videotape" && e.room === n.room) && z(n.flags, "movement") >= i) for (let t of e.tokens.filter((e) => e.kind === "videotape" && e.room !== n.room)) r.push(N(`tape-${t.id}`, "games.betrayal3.moveTo", [{
				op: "monsterMove",
				actor: n.id,
				id: t.room
			}], t.room, "room"));
			return H(e).flags.monsterActive = n.id, M(e, n.controller, "games.betrayal3.monsterAction", r), !0;
		}
		switch (t.op) {
			case "tapePlace": {
				if ((t.n ?? 0) <= 0) return !0;
				let n = e.rooms.filter((t) => !e.tokens.some((n) => n.kind === "videotape" && n.room && y(e, n.room).id === t.id)), r = Math.max(...n.map((t) => Math.min(...O(e).map((n) => C(e, n.room, t.id)))));
				return M(e, t.actor, "games.betrayal3.placeVideotape", n.filter((t) => Math.min(...O(e).map((n) => C(e, n.room, t.id))) === r).flatMap(b).map((e) => N(e, "games.betrayal3.placeToken", [{
					op: "hauntPlaceToken",
					actor: t.actor,
					id: "videotape",
					args: { room: e }
				}, {
					...t,
					n: t.n - 1
				}], e, "room"))), !0;
			}
			case "tapeSpiritPlace": return M(e, t.actor, "games.betrayal3.placeVengefulSpirit", e.tokens.filter((e) => e.kind === "videotape").map((e) => N(e.id, "games.betrayal3.placeToken", [{
				op: "tapeSpiritMake",
				actor: t.actor,
				id: e.room
			}], e.room, "room"))), !0;
			case "tapeSpiritMake": return J(e, "vengefulSpirit", t.id, B(7, 3, 4, 3)), !0;
			case "tapeDestroyResult": return z(t.args, "total") >= 4 && (e.tokens = e.tokens.filter((e) => e.id !== t.args?.token)), !0;
			case "tapeStaveResult": return z(t.args, "total") > 0 && H(e).track++, z(t.args, "total") < 2 && (e.endRequested = !0), !0;
			case "hauntTurnEnd": return t.actor === H(e).traitor ? --H(e).track <= 0 && zn(e) : !Y(e, "videotape") && O(e).some((e) => e.room === "entranceHall") && X(e), !0;
			default: return !1;
		}
	},
	check: Z
};
function kr(e, t, n) {
	let r = [{
		room: t,
		n: 0
	}], i = /* @__PURE__ */ new Set([t]);
	for (; r.length;) {
		let t = r.shift();
		if (y(e, t.room).id === n) return t.n;
		for (let n of Re(e, t.room)) i.has(n) || (i.add(n), r.push({
			room: n,
			n: t.n + 1
		}));
	}
	return -1;
}
var Ar = {
	setup(e) {
		let t = H(e).traitor;
		F(e, t), H(e).monsterAfter = t, H(e).secret.syllables = [], J(e, "facelessMan", E(e, t).room, B(5, 2, 5, 5), { death: "immune" }), j(e, [{
			op: "hauntEnsureRooms",
			actor: t,
			n: 5,
			args: { nonLanding: !0 }
		}, {
			op: "syllableChoose",
			actor: t
		}]);
	},
	actions(e, t) {
		return E(e, t).team !== "hero" || Y(e, "syllable") >= $(e, [
			2,
			3,
			4,
			5
		]) ? [] : U(e, t, "findSyllable", "games.betrayal3.findSyllable", [{
			op: "syllableGuess",
			actor: t
		}]);
	},
	handle(e, t) {
		if (t.op === "combatResult" && z(t.args, "attackTotal") > z(t.args, "total") && e.monsters.some((e) => e.id === t.target && e.kind === "facelessMan") && Y(e, "syllable") >= $(e, [
			2,
			3,
			4,
			5
		])) return e.monsters.find((e) => e.id === t.target).dead = !0, X(e), !0;
		switch (t.op) {
			case "syllableChoose": {
				let n = H(e).secret.syllables;
				return n.length >= $(e, [
					2,
					3,
					4,
					5
				]) || (M(e, t.actor, "games.betrayal3.chooseSyllableRoom", e.rooms.filter((e) => !n.includes(e.id)).map((e) => N(e.id, "games.betrayal3.chooseRoom", [{
					op: "syllableRemember",
					actor: t.actor,
					id: e.id
				}, t], e.id, "room")), { n: n.length + 1 }), e.prompt.secretFor = [t.actor], !0);
			}
			case "syllableRemember": return H(e).secret.syllables.push(t.id), !0;
			case "syllableGuess": {
				let n = E(e, t.actor), r = H(e).secret.syllables[Y(e, "syllable")];
				if (y(e, n.room).id === r) L(e, "syllable", n.room), A(e, {
					key: "games.betrayal3.logSyllableFound",
					actor: n.rid,
					n: Y(e, "syllable")
				});
				else {
					let t = y(e, n.room).floor === y(e, r).floor;
					A(e, {
						key: t ? "games.betrayal3.logSyllableDistance" : "games.betrayal3.logSyllableWrongFloor",
						actor: n.rid,
						n: t ? kr(e, n.room, r) : void 0
					});
					let i = e.monsters.find((e) => e.kind === "facelessMan");
					j(e, [{
						op: "relocate",
						actor: i.id,
						id: n.room
					}, {
						op: "attack",
						actor: i.id,
						target: n.rid
					}]);
				}
				return !0;
			}
			default: return !1;
		}
	},
	check: Z
};
//#endregion
//#region src/game/haunts/illusions.ts
function jr(e, t) {
	let n = e.tokens.find((e) => e.id === t), r = e.monsters.find((e) => e.flags.token === t), i = r.room;
	if (n.hidden = !1, n.room = null, r.dead = !0, A(e, {
		key: "games.betrayal3.logIllusionDispelled",
		id: t,
		n: n.value
	}), n.value !== 1) return;
	let a = E(e, H(e).traitor);
	a.secret.hiddenAmongIllusions = !1, a.room = i;
	for (let t of e.monsters.filter((e) => e.kind === "illusion")) t.dead = !0;
	for (let t of e.tokens.filter((e) => e.kind === "illusion")) t.room = null, t.hidden = !1;
	let o = Math.max(...e.tokens.filter((e) => e.kind === "illusion").map((e) => e.value));
	e.tokens = e.tokens.filter((e) => e.kind !== "illusion" || e.value !== o), H(e).flags.illusionActive = "";
}
function Mr(e, t) {
	let n = e.monsters.find((e) => e.id === t), r = E(e, n.controller);
	if (n.dead || r.secret.hiddenAmongIllusions !== !0) return [];
	let i = O(e).some((e) => e.room === n.room) || e.tokens.some((e) => e.kind === "obstacle" && e.room === n.room) ? 2 : 1, a = z(n.flags, "movement") >= i ? x(e, n.room).map((e) => N(`move-${e}`, "games.betrayal3.moveTo", [{
		op: "illusionMove",
		actor: n.id,
		id: e,
		n: i
	}], e, "room")) : [];
	if (z(n.flags, "movement") >= i && k(e, r, "skeletonKey")) for (let t of Re(e, n.room, !0).filter((t) => !x(e, n.room).includes(t))) a.push(N(`key-${t}`, "games.betrayal3.moveThroughWall", [{
		op: "illusionMove",
		actor: n.id,
		id: t,
		n: i,
		args: { key: !0 }
	}], t, "room"));
	return [
		...a,
		...en(e, n.id),
		...Ht(e, n.id)
	].map((e) => ({
		...e,
		tasks: [...e.tasks, {
			op: "illusionAct",
			actor: t
		}]
	}));
}
var Nr = {
	setup(e) {
		let t = H(e).traitor;
		F(e, t);
		for (let t = 1; t <= e.players.length; t++) L(e, "illusion", null, null, t);
		j(e, [{
			op: "illusionSummon",
			actor: t
		}]);
	},
	filterActions(e, t, n) {
		return E(e, t).secret.hiddenAmongIllusions === !0 ? [] : n;
	},
	actions(e, t) {
		let n = E(e, t);
		if (n.team === "traitor") return n.secret.hiddenAmongIllusions === !0 || !e.tokens.some((e) => e.kind === "illusion") ? [] : U(e, t, "summonIllusions", "games.betrayal3.summonIllusions", [{
			op: "illusionSummon",
			actor: t
		}, {
			op: "illusionSummonEnd",
			actor: t
		}]);
		let r = e.tokens.filter((e) => e.kind === "illusion" && e.room === n.room).flatMap((r) => U(e, t, "confrontIllusion", "games.betrayal3.confrontIllusion", [W(t, "illusionConfrontResult", "knowledge", k(e, n, "mirror") ? 2 : 0, { token: r.id })], r.id, "token"));
		return q(e, t, ["vault"]) && r.push(...U(e, t, "callRing", "games.betrayal3.callRing", [W(t, "illusionCallResult", "sanity", n.cards.filter((e) => h.includes(e)).length)])), r;
	},
	handle(e, t) {
		let n = E(e, H(e).traitor), r = e.monsters.find((e) => e.id === t.actor && e.kind === "illusion");
		if (t.op === "hauntTurnStart" && t.actor === n.rid && n.secret.hiddenAmongIllusions === !0) return H(e).flags.illusionRemaining = e.monsters.filter((e) => e.kind === "illusion" && !e.dead).map((e) => e.id), j(e, [{
			op: "illusionNext",
			actor: n.rid
		}]), !0;
		if (t.op === "characterDamage" && r && (t.n ?? 0) > 0) return jr(e, R(r.flags, "token")), !0;
		if (t.op === "relocate" && r) return e.tokens.find((e) => e.id === r.flags.token).room = t.id, !1;
		if (t.op === "useItem" && r && t.id === "mysticalStopwatch" && !tt(e, n, t.id)) return !0;
		switch (t.op) {
			case "illusionSummon": {
				let t = e.tokens.filter((e) => e.kind === "illusion"), r = T(e, t.map((e) => e.value));
				return e.monsters = e.monsters.filter((e) => e.kind !== "illusion"), t.forEach((t, n) => {
					t.value = r[n], t.hidden = !0, t.room = null, H(e).secret[`token.${t.id}`] = t.value;
				}), n.secret.hiddenAmongIllusions = !0, j(e, [{
					op: "illusionPlace",
					actor: n.rid,
					n: 0,
					args: { origin: n.room }
				}]), !0;
			}
			case "illusionPlace": {
				let r = e.tokens.filter((e) => e.kind === "illusion"), i = t.n ?? 0, a = R(t.args, "origin");
				if (i >= r.length) return !0;
				let o = e.rooms.filter((t) => b(t).some((t) => C(e, a, t) <= et(e, n.rid, "speed"))), s = o.filter((t) => !r.some((n) => n.room && y(e, n.room).id === t.id)), c = i === 0 ? [a] : (s.length ? s : o).flatMap(b).filter((t) => C(e, a, t) <= et(e, n.rid, "speed"));
				return M(e, t.actor, "games.betrayal3.placeIllusion", c.map((e) => N(e, "games.betrayal3.placeToken", [{
					op: "illusionMake",
					actor: t.actor,
					id: r[i].id,
					args: { room: e }
				}, {
					...t,
					n: i + 1
				}], e, "room")), { n: r[i].value }), e.prompt.secretFor = [t.actor], !0;
			}
			case "illusionMake": {
				let r = e.tokens.find((e) => e.id === t.id), i = R(t.args, "room");
				return r.room = i, J(e, "illusion", i, B(0, 0, 0, 0), {
					death: "immune",
					flags: {
						ai: "manual",
						itemsOwner: n.rid,
						owned: !0,
						token: r.id
					}
				}), !0;
			}
			case "illusionSummonEnd": return e.endRequested = !0, !0;
			case "illusionConfrontResult": return z(t.args, "total") >= 5 ? jr(e, R(t.args, "token")) : j(e, [K(t.actor, 1, "mental")]), !0;
			case "illusionCallResult": return e.endRequested = !0, z(t.args, "total") >= 8 && (n.secret.hiddenAmongIllusions === !0 ? M(e, t.actor, "games.betrayal3.chooseIllusionDispel", e.tokens.filter((e) => e.kind === "illusion" && e.room).map((e) => N(e.id, "games.betrayal3.dispelIllusion", [{
				op: "illusionDispel",
				actor: t.actor,
				id: e.id
			}], e.id, "token"))) : j(e, [K(n.rid, 1, "mental")])), !0;
			case "illusionDispel": return jr(e, t.id), !0;
			case "illusionNext": {
				let t = H(e).flags.illusionRemaining.filter((t) => e.monsters.some((e) => e.id === t && !e.dead));
				return n.secret.hiddenAmongIllusions !== !0 || !t.length ? (e.endRequested = !0, !0) : (M(e, n.rid, "games.betrayal3.chooseIllusionOrder", t.map((e) => N(e, "games.betrayal3.activateIllusion", [{
					op: "illusionBegin",
					actor: e
				}], e, "token"))), !0);
			}
			case "illusionBegin": return H(e).flags.illusionRemaining = H(e).flags.illusionRemaining.filter((e) => e !== t.actor), H(e).flags.illusionActive = t.actor, r.flags.movement = et(e, n.rid, "speed"), r.flags.attacked = !1, j(e, [{
				op: "illusionAct",
				actor: t.actor
			}]), !0;
			case "illusionAct": return !r || r.dead || n.secret.hiddenAmongIllusions !== !0 ? (j(e, [{
				op: "illusionNext",
				actor: n.rid
			}]), !0) : (M(e, n.rid, "games.betrayal3.illusionAction", [...Mr(e, t.actor), N("finish", "games.betrayal3.finishIllusion", [{
				op: "illusionNext",
				actor: n.rid
			}])]), !0);
			case "illusionMove": return r.flags.movement = z(r.flags, "movement") - (t.n ?? 1), j(e, r.room.startsWith("windingTunnels:") && t.id.startsWith("windingTunnels:") ? [{
				op: "roll",
				actor: t.actor,
				trait: "knowledge",
				args: { context: "windingTunnels" },
				then: [{
					op: "tunnelResult",
					actor: t.actor,
					id: t.id
				}]
			}] : [{
				op: "relocate",
				actor: t.actor,
				id: t.id
			}, ...t.args?.key === !0 ? [{
				op: "keyRoll",
				actor: t.actor
			}] : []]), !0;
			default: return !1;
		}
	},
	check(e) {
		E(e, H(e).traitor).dead ? X(e) : Z(e);
	}
};
//#endregion
//#region src/game/haunts/manuscript.ts
function Pr(e, t) {
	for (let t of e.explorers) t.cards = t.cards.filter((e) => e !== "book"), t.startCards = t.startCards.filter((e) => e !== "book");
	e.omens = e.omens.filter((e) => e !== "book"), H(e).flags.spookyBook = t === null, t && E(e, t).cards.push("book");
}
var Fr = {
	setup(e) {
		let t = H(e).traitor, n = y(e, E(e, t).room).floor;
		F(e, t), P(e, t, "might", $(e, [
			1,
			1,
			2,
			3
		])), P(e, t, "speed", $(e, [
			1,
			1,
			2,
			3
		])), H(e).monsterAfter = t, Pr(e, null), j(e, [{
			op: "spookySetup",
			actor: t
		}]), e.rooms.some((e) => e.id === "library") || j(e, [{
			op: "placeRoom",
			actor: t,
			id: "library",
			args: { floor: n === "G" ? "U" : "G" }
		}]);
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team === "traitor") return n.cards.includes("book") && q(e, t, ["library"]) ? [N("returnBook", "games.betrayal3.returnBookSpooky", [{
			op: "spookyBookReturn",
			actor: t
		}])] : [];
		if (n.cards.includes("book") && (q(e, t, [
			"furnaceRoom",
			"ritualRoom",
			"kitchen",
			"laboratory",
			"charredRoom"
		]) && r.push(...U(e, t, "burnManuscript", "games.betrayal3.burnManuscript", [W(t, "spookyBurnResult", "sanity")])), !e.attacked)) for (let i of e.monsters.filter((e) => e.kind === "horror" && !e.dead && e.room === n.room)) for (let e of w) r.push(N(`horror-${i.id}-${e}`, "games.betrayal3.attackHorrorTrait", [{
			op: "attack",
			actor: t,
			target: i.id,
			trait: e
		}], e, "trait"));
		return q(e, t, ["library"]) && r.push(...U(e, t, "buildCharacter", "games.betrayal3.buildCharacter", [W(t, "spookyBuildResult", "sanity")])), r;
	},
	handle(e, t) {
		let n = e.monsters.find((e) => e.kind === "spooky");
		if (t.op === "combatResult" && z(t.args, "attackTotal") > z(t.args, "total") && t.trait === "might") {
			if (t.target === n?.id && H(e).flags.spookyBook === !0) return Pr(e, t.actor), !0;
			if (t.actor === H(e).traitor && E(e, t.target)?.cards.includes("book")) return M(e, t.actor, "games.betrayal3.chooseCombatReward", [N("steal", "games.betrayal3.stealCard", [{
				op: "spookyStealBook",
				actor: t.actor,
				target: t.target
			}], "book", "card"), N("damage", "games.betrayal3.dealCombatDamage", [{
				op: "characterDamage",
				actor: t.target,
				target: t.actor,
				n: z(t.args, "attackTotal") - z(t.args, "total"),
				damage: t.damage
			}])]), !0;
		}
		if (t.op === "monsterAct" && t.actor === n?.id) {
			if (n.dead || n.stunned) return !0;
			let t = Q(e, n).filter((e) => !e.id.startsWith("move-"));
			if (H(e).flags.spookyBook === !0 && n.flags.ghostwritten !== !0) for (let r of e.rooms.flatMap(b)) t.push(N(`write-${r}`, "games.betrayal3.ghostwrite", [{
				op: "spookyGhostwrite",
				actor: n.id,
				id: r
			}], r, "room"));
			return H(e).flags.monsterActive = n.id, M(e, n.controller, "games.betrayal3.monsterAction", t), !0;
		}
		if (t.op === "monsterBegin" && t.actor === n?.id && (n.flags.ghostwritten = !1), t.op === "relocate" && t.actor === n?.id && t.id !== "library") return !0;
		switch (t.op) {
			case "spookySetup": return J(e, "spooky", "library", B(6, 6, 6, 8), { death: "immune" }), J(e, "horror", E(e, t.actor).room, B(5, 3, 4, 3)), !0;
			case "spookyBookReturn": return Pr(e, null), !0;
			case "spookyStealBook": return at(e, t.target, t.actor, "book"), !0;
			case "spookyBurnResult": return z(t.args, "total") >= 5 && (Pr(e, null), H(e).flags.spookyBook = !1, X(e)), !0;
			case "spookyBuildResult": return z(t.args, "total") >= 4 ? j(e, [{
				op: "chooseGain",
				actor: t.actor,
				args: { traits: ["might", "speed"] }
			}]) : J(e, "horror", E(e, t.actor).room, B(5, 3, 4, 3)), !0;
			case "hauntStartMonsters": return j(e, [...Un(e, [n.id]), {
				op: "spookyHorrorTurns",
				actor: t.actor
			}]), !0;
			case "spookyHorrorTurns": return j(e, Un(e, e.monsters.filter((e) => e.kind === "horror" && !e.dead).map((e) => e.id))), !0;
			case "spookyGhostwrite": return n.flags.ghostwritten = !0, j(e, [{
				op: "roll",
				actor: t.actor,
				n: 2,
				args: { context: "ghostwrite" },
				then: [{
					op: "spookyWriteResult",
					actor: t.actor,
					id: t.id
				}]
			}, {
				op: "monsterAct",
				actor: t.actor
			}]), !0;
			case "spookyWriteResult": {
				let n = z(t.args, "total"), r = e.explorers.filter((e) => !e.dead && e.room === t.id);
				if (n === 4) j(e, r.map((e) => G(e.rid, 3, "physical")));
				else {
					n >= 2 && j(e, r.map((e) => K(e.rid, 2, "mental")));
					for (let r = 0; r < (n >= 2 ? 1 : 2); r++) e.monsters.filter((e) => e.kind === "horror" && !e.dead).length < 20 && J(e, "horror", t.id, B(5, 3, 4, 3));
				}
				return !0;
			}
			default: return !1;
		}
	},
	check: Z
};
function Ir(e, t) {
	e.monsters.filter((e) => e.kind === "coldWarZombie" && !e.dead).length < 20 && J(e, "coldWarZombie", t, B(5, 2, 2, 2), { death: "kill" });
}
var Lr = {
	setup(e) {
		let t = e.rooms.filter((e) => e.floor === "B" && e.id !== "basementLanding"), n = new Set(t.map((e) => e.id));
		e.rooms = e.rooms.filter((e) => !n.has(e.id)), e.tiles = T(e, [...e.tiles, ...t.map((e) => e.tile)]), e.tokens = e.tokens.filter((e) => !e.room || !n.has(e.room.split(":")[0]));
		for (let t of O(e)) t.room = "basementLanding";
		H(e).monsterAfter = H(e).traitor, j(e, [{
			op: "relocate",
			actor: H(e).traitor,
			id: "laboratory"
		}]), Vn(e, ["laboratory"], H(e).traitor);
	},
	filterActions(e, t, n) {
		return t !== H(e).traitor || H(e).flags.missionComplete === !0 ? n : n.filter((e) => !e.id.startsWith("move-") && !e.id.startsWith("key-") && !e.id.startsWith("discover-") && e.id !== "item-map");
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team === "traitor") {
			if (!q(e, t, ["laboratory"])) return [];
			let n = e.tiles.find((e) => g(e).floors.includes("B"));
			return n ? U(e, t, "diversion", "games.betrayal3.createDiversion", [{
				op: "placeRoom",
				actor: t,
				id: n,
				args: { floor: "B" }
			}]) : [];
		}
		return q(e, t, ["entranceHall", "graveyard"]) && r.push(...U(e, t, "escapeHouse", "games.betrayal3.escapeHouse", [W(t, "undergroundEscapeResult", "speed", k(e, n, "dynamite") || k(e, n, "skeletonKey") ? 2 : 0)])), n.cards.includes("skull") && r.push(...U(e, t, "studyFloorPlan", "games.betrayal3.studyFloorPlan", [W(t, "undergroundPlanResult", "knowledge")])), r;
	},
	handle(e, t) {
		if (t.op === "relocate" && t.actor === H(e).traitor && H(e).flags.missionComplete !== !0 && t.id !== "laboratory") return !0;
		switch (t.op) {
			case "hauntEnter": return E(e, t.actor)?.team === "hero" && y(e, t.id).floor === "G" && (H(e).flags.missionComplete = !0), !0;
			case "undergroundEscapeResult": return z(t.args, "total") >= 6 && X(e), !0;
			case "undergroundPlanResult": {
				if (z(t.args, "total") < 5) return !0;
				let n = e.tiles.find((e) => g(e).floors.includes("B"));
				return n && (M(e, t.actor, "games.betrayal3.inspectBasementTile", [N("top", "games.betrayal3.returnTileTop", [{
					op: "undergroundRestack",
					actor: t.actor,
					id: n,
					n: 0
				}], n, "room"), N("bottom", "games.betrayal3.buryTile", [{
					op: "undergroundRestack",
					actor: t.actor,
					id: n,
					n: 1
				}], n, "room")]), e.prompt.secretFor = [t.actor]), !0;
			}
			case "undergroundRestack": return e.tiles = e.tiles.filter((e) => e !== t.id), t.n === 0 ? e.tiles.unshift(t.id) : e.tiles.push(t.id), !0;
			case "hauntTurnEnd":
				if (t.actor === H(e).traitor) {
					for (let t = 0; t < $(e, [
						0,
						0,
						1,
						1
					]); t++) Ir(e, "basementLanding");
					if (q(e, t.actor, ["laboratory"])) for (let t of [...new Set(Ve(e, "B").map((e) => e.room))]) Ir(e, t);
				}
				return !0;
			case "hauntDeath":
				if (e.monsters.some((e) => e.id === t.target && e.kind === "coldWarZombie")) {
					let n = E(e, t.actor);
					for (let t of [...n.cards]) I(e, n.rid, t);
					n.secret.bodyRemoved = !0;
					for (let t of e.tokens.filter((e) => e.flags.corpse === n.rid)) t.room = null, t.flags.removed = !0;
				}
				return !0;
			default: return !1;
		}
	},
	check: Z
}, Rr = {
	setup(e) {
		F(e, H(e).traitor), H(e).monsterAfter = H(e).traitor, H(e).track = $(e, [
			2,
			3,
			4,
			5
		]), j(e, [{
			op: "circuitPlace",
			actor: H(e).traitor,
			n: H(e).track
		}]);
	},
	actions(e, t) {
		let n = E(e, t);
		if (n.team === "traitor") return [...new Set(O(e).map((t) => y(e, t.room).id))].flatMap((n) => qe(e, n).length ? U(e, t, "shiftBlueprint", "games.betrayal3.shiftBlueprint", [{
			op: "circuitShiftOptions",
			actor: t,
			id: n
		}], n, "room") : []);
		let r = e.tokens.filter((e) => e.kind === "circuit" && e.value === 1 && e.room === n.room).flatMap((n) => U(e, t, "turnOffMachine", "games.betrayal3.turnOffMachine", [W(t, "circuitOffResult", "knowledge", 0, { token: n.id })], n.id, "token"));
		return An(e, t, "omen") && r.push(...U(e, t, "wreckHouse", "games.betrayal3.wreckHouse", [W(t, "circuitWreckResult", "might")])), r;
	},
	handle(e, t) {
		if (t.op === "monsterBegin" && (e.monsters.find((e) => e.id === t.actor).flags.lasersUsed = !1), t.op === "monsterAct") {
			let n = e.monsters.find((e) => e.id === t.actor);
			if (n.dead || n.stunned) return !0;
			let r = Q(e, n);
			if (n.flags.lasersUsed !== !0) for (let t of O(e).filter((t) => S(e, n.room, t.room))) r.push(N(`laser-${t.rid}`, "games.betrayal3.turnOnLasers", [{
				op: "circuitLaser",
				actor: n.id,
				target: t.rid
			}], t.rid, "player"));
			return H(e).flags.monsterActive = n.id, M(e, n.controller, "games.betrayal3.monsterAction", r), !0;
		}
		switch (t.op) {
			case "circuitPlace": {
				if ((t.n ?? 0) <= 0) return !0;
				let n = (t) => e.tokens.filter((n) => n.kind === "circuit" && y(e, n.room).floor === t).length, r = Math.min(...[
					"U",
					"G",
					"B"
				].map(n));
				return M(e, t.actor, "games.betrayal3.placeCircuit", e.rooms.filter((e) => n(e.floor) === r).flatMap(b).map((e) => N(e, "games.betrayal3.placeToken", [{
					op: "circuitMake",
					actor: t.actor,
					id: e
				}, {
					...t,
					n: t.n - 1
				}], e, "room"))), !0;
			}
			case "circuitMake": return L(e, "circuit", t.id), e.monsters.some((e) => e.kind === "robotAssistant" && e.room === t.id) || J(e, "robotAssistant", t.id, B(2, 6, 2, 2), { death: "immune" }), !0;
			case "circuitOffResult": {
				if (z(t.args, "total") < 5) return !0;
				let n = e.tokens.find((e) => e.id === t.args?.token);
				return n.value = 0, M(e, t.actor, "games.betrayal3.chooseRobotStun", e.monsters.filter((t) => !t.dead && y(e, t.room).floor === y(e, n.room).floor).map((e) => N(e.id, "games.betrayal3.stunRobot", [{
					op: "circuitStun",
					actor: t.actor,
					id: e.id
				}], e.id, "token"))), !0;
			}
			case "circuitStun": return e.monsters.find((e) => e.id === t.id).stunned = !0, !0;
			case "circuitWreckResult": return z(t.args, "total") >= 4 && (jn(e, E(e, t.actor).room, "wrecked"), H(e).track = Math.max(0, H(e).track - 1)), !0;
			case "circuitShiftOptions": return M(e, t.actor, "games.betrayal3.chooseRoomRelocation", qe(e, t.id).map((e) => {
				let n = N(`${e.x},${e.y},${e.rotation}`, "games.betrayal3.relocateRoom", [{
					op: "circuitShift",
					actor: t.actor,
					id: t.id,
					args: e
				}], t.id, "room", e.rotation);
				return n.params = {
					x: e.x,
					y: e.y,
					rotation: e.rotation * 90
				}, n;
			})), !0;
			case "circuitShift": return e.rooms = We(e, t.id, z(t.args, "x"), z(t.args, "y"), z(t.args, "rotation")), !0;
			case "circuitLaser": return e.monsters.find((e) => e.id === t.actor).flags.lasersUsed = !0, j(e, [{
				op: "roll",
				actor: t.target,
				trait: "speed",
				args: { context: "lasers" },
				then: [{
					op: "circuitLaserResult",
					actor: t.target
				}]
			}, {
				op: "monsterAct",
				actor: t.actor
			}]), !0;
			case "circuitLaserResult": return j(e, z(t.args, "total") >= 5 ? [{
				op: "chooseAdjacent",
				actor: t.actor
			}] : [K(t.actor, 2, "physical")]), !0;
			case "hauntTurnEnd": return E(e, t.actor).team === "hero" && H(e).track === 0 && e.tokens.filter((e) => e.kind === "circuit").every((e) => e.value === 0) && X(e), !0;
			default: return !1;
		}
	},
	check: Z
}, zr = [
	"tower",
	"statuaryCorridor",
	"conservatory",
	"graveyard",
	"undergroundCavern",
	"undergroundLake"
], Br = {
	setup(e) {
		let t = H(e).traitor;
		F(e, t), H(e).monsterAfter = t, H(e).counters.flamesRemaining = $(e, [
			2,
			3,
			4,
			5
		]);
		for (let t of zr) if (e.rooms.some((e) => e.id === t) && H(e).counters.flamesRemaining > 0) {
			let n = L(e, "seelieFlame", t);
			e.tokens.find((e) => e.id === n).flags.origin = t, H(e).counters.flamesRemaining--;
		}
		j(e, [{
			op: "masqueradeSetup",
			actor: t
		}]), Vn(e, ["ballroom", "chapel"], t);
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team === "traitor") return e.attacked ? [] : O(e).filter((e) => e.room === n.room).map((e) => N(`danceAttack-${e.rid}`, "games.betrayal3.attackSpeed", [{
			op: "attack",
			actor: t,
			target: e.rid,
			trait: "speed"
		}], e.rid, "player"));
		let i = e.tokens.find((e) => e.kind === "seelieFlame" && e.holder === t);
		if (i) r.push(N("dropFlame", "games.betrayal3.dropFlame", [{
			op: "masqueradeDrop",
			actor: t,
			id: i.id
		}], i.id, "token"));
		else for (let i of e.tokens.filter((e) => e.kind === "seelieFlame" && e.room === n.room && !e.flags.corpse)) for (let n of ["knowledge", "speed"]) r.push(...U(e, t, "pickFlame", "games.betrayal3.pickFlame", [{
			op: "masqueradeCarry",
			actor: t,
			id: i.id
		}, W(t, "masqueradePickResult", n)], `${i.id}:${n}`, "trait"));
		return r;
	},
	handle(e, t) {
		if (t.op === "tradePropose" || t.op === "tradeAccept") {
			let t = e.trade, n = (t, n, r) => e.tokens.filter((e) => e.kind === "seelieFlame" && (e.holder === t && !r.includes(e.id) || n.includes(e.id))).length;
			if (n(t.actor, t.take, t.give) > 1 || n(t.target, t.give, t.take) > 1) return e.trade = null, !0;
		}
		if (t.op === "combatResult" && t.actor === H(e).traitor && !t.id && z(t.args, "attackTotal") > z(t.args, "total")) {
			let n = z(t.args, "attackTotal") - z(t.args, "total");
			return M(e, t.actor, "games.betrayal3.chooseDanceDamage", [N("move", "games.betrayal3.moveDanceFigures", [{
				op: "hauntMoveSteps",
				actor: t.actor,
				target: t.actor,
				n
			}, {
				op: "hauntMoveSteps",
				actor: t.actor,
				target: t.target,
				n
			}]), N("damage", "games.betrayal3.dealCombatDamage", [{
				op: "characterDamage",
				actor: t.target,
				target: t.actor,
				n,
				damage: t.damage
			}])]), !0;
		}
		if (t.op === "monsterBegin" && (e.monsters.find((e) => e.id === t.actor).flags.danced = !1), t.op === "monsterAct") {
			let n = e.monsters.find((e) => e.id === t.actor);
			if (n.dead || n.stunned) return !0;
			let r = Q(e, n).filter((e) => n.kind !== "faeDancer" || !e.id.startsWith("attack-") || n.room === "ballroom");
			return n.kind === "darkQueen" && n.flags.danced !== !0 && r.push(N("dance", "games.betrayal3.stepDance", [{
				op: "masqueradeQueenDance",
				actor: n.id
			}])), H(e).flags.monsterActive = n.id, M(e, n.controller, "games.betrayal3.monsterAction", r), !0;
		}
		switch (t.op) {
			case "masqueradeSetup":
				E(e, t.actor).room = "ballroom";
				for (let t = 0; t < $(e, [
					1,
					2,
					3,
					4
				]); t++) J(e, "faeDancer", "ballroom", B(3, 6, 3, 2), { attack: "speed" });
				return !0;
			case "masqueradeCarry": {
				let n = e.tokens.find((e) => e.id === t.id);
				return n.room = null, n.holder = t.actor, n.flags.tradable = !0, !0;
			}
			case "masqueradeDrop": {
				let n = e.tokens.find((e) => e.id === t.id);
				return n.room = E(e, t.actor).room, n.holder = null, delete n.flags.corpse, !0;
			}
			case "masqueradePickResult": return z(t.args, "total") < 5 && j(e, [G(t.actor, 2, "general")]), !0;
			case "hauntEnter":
				if (zr.includes(t.id) && H(e).counters.flamesRemaining > 0 && !e.tokens.some((e) => e.kind === "seelieFlame" && e.flags.origin === t.id)) {
					let n = L(e, "seelieFlame", t.id), r = e.tokens.find((e) => e.id === n);
					r.flags.origin = t.id, H(e).counters.flamesRemaining--;
				}
				return !0;
			case "hauntDeath": return E(e, t.actor).room === "ballroom" && H(e).flags.queenArrived !== !0 && (H(e).flags.queenArrived = !0, J(e, "darkQueen", "ballroom", B(7, 6, 4, 5))), !0;
			case "hauntStartMonsters": return j(e, [...Un(e, e.monsters.filter((e) => e.kind === "faeDancer" && !e.dead).map((e) => e.id)), {
				op: "masqueradeQueenTurn",
				actor: t.actor
			}]), !0;
			case "masqueradeQueenTurn": return j(e, Un(e, e.monsters.filter((e) => e.kind === "darkQueen" && !e.dead).map((e) => e.id))), !0;
			case "masqueradeQueenDance": return e.monsters.find((e) => e.id === t.actor).flags.danced = !0, j(e, [{
				op: "roll",
				actor: t.actor,
				n: 2,
				args: { context: "danceEternal" },
				then: [{
					op: "masqueradeDanceResult",
					actor: t.actor
				}]
			}, {
				op: "monsterAct",
				actor: t.actor
			}]), !0;
			case "masqueradeDanceResult": {
				let n = e.monsters.find((e) => e.id === t.actor);
				return M(e, n.controller, "games.betrayal3.chooseDanceHero", O(e).filter((t) => y(e, t.room).floor === y(e, n.room).floor).map((e) => N(e.rid, "games.betrayal3.moveDanceHero", [{
					op: "hauntMoveSteps",
					actor: n.controller,
					target: e.rid,
					n: z(t.args, "total")
				}], e.rid, "player"))), !0;
			}
			case "hauntTurnEnd": return E(e, t.actor).team === "hero" && H(e).counters.flamesRemaining === 0 && Y(e, "seelieFlame") === $(e, [
				2,
				3,
				4,
				5
			]) && e.tokens.filter((e) => e.kind === "seelieFlame").every((e) => e.room === "chapel") && X(e), !0;
			default: return !1;
		}
	},
	check: Z
}, Vr = {
	sanity: [
		"operatingTheatre",
		"graveyard",
		"bloodyRoom"
	],
	might: [
		"larder",
		"specimenRoom",
		"diningRoom"
	],
	knowledge: [
		"furnaceRoom",
		"observatory",
		"library"
	],
	speed: [
		"undergroundLake",
		"conservatory",
		"kitchen"
	]
}, Hr = {
	setup(e) {
		F(e, H(e).traitor), H(e).flags.deadTurns = [H(e).traitor];
	},
	actions(e, t) {
		if (E(e, t).team !== "hero") return [];
		let n = [];
		for (let r of w) !e.tokens.some((e) => e.kind === "ingredient" && e.trait === r) && q(e, t, Vr[r]) && n.push(...U(e, t, "findIngredient", "games.betrayal3.findIngredient", [W(t, "armorIngredientResult", r, 0, { trait: r })], r, "trait"));
		return e.tokens.filter((e) => e.kind === "ingredient").length >= $(e, [
			1,
			2,
			3,
			4
		]) && q(e, t, ["armory", "ritualRoom"]) && n.push(...U(e, t, "breakArmorSpell", "games.betrayal3.breakArmorSpell", [W(t, "armorBreakResult", "sanity")])), n;
	},
	handle(e, t) {
		if (t.op === "beginTurn" && t.actor === H(e).traitor && E(e, t.actor).dead) {
			let n = E(e, t.actor), r = e.explorers.find((e) => e.cards.includes("armor"));
			n.dead = !1, n.room = r.room, F(e, n.rid);
		}
		if (t.op === "combatResult" && t.actor === H(e).traitor && t.trait === "might" && E(e, t.actor).cards.includes("armor") && O(e).some((e) => e.rid === t.target) && z(t.args, "attackTotal") > z(t.args, "total")) return at(e, t.actor, t.target, "armor"), !0;
		switch (t.op) {
			case "armorIngredientResult": {
				if (z(t.args, "total") < 4) return !0;
				let n = t.args?.trait;
				return e.tokens.push({
					id: `ingredient-${n}`,
					kind: "ingredient",
					room: E(e, t.actor).room,
					holder: null,
					value: 1,
					trait: n,
					hidden: !1,
					flags: {}
				}), !0;
			}
			case "armorBreakResult": return z(t.args, "total") >= 5 ? X(e) : P(e, t.actor, "sanity", -1), !0;
			case "hauntTurnEnd": {
				if (t.actor !== H(e).traitor) return !0;
				let n = O(e).find((e) => e.cards.includes("armor"));
				if (n) for (let r of w) P(e, n.rid, r, -1), P(e, t.actor, r, 1);
				return !0;
			}
			default: return !1;
		}
	},
	check: Z
}, Ur = [
	"guestQuarters",
	"primaryBedroom",
	"winterBedroom"
], Wr = {
	setup(e) {
		let t = H(e).traitor;
		F(e, t), H(e).monsterAfter = t, H(e).flags.deadTurns = [t];
		let n = O(e)[0].rid;
		j(e, [{
			op: "familyAltar",
			actor: n
		}, {
			op: "familyRelatives",
			actor: t,
			n: $(e, [
				2,
				3,
				4,
				5
			])
		}]), Vn(e, ["ritualRoom"], n);
	},
	actions(e, t) {
		let n = E(e, t);
		if (n.team === "traitor") return q(e, t, Ur) ? e.rooms.flatMap(b).flatMap((n) => U(e, t, "hiddenPassages", "games.betrayal3.useHiddenPassages", [{
			op: "relocate",
			actor: t,
			id: n
		}], n, "room")) : [];
		let r = [];
		return q(e, t, ["ritualRoom"]) && H(e).flags.tributeRuined !== !0 && r.push(...U(e, t, "ruinTribute", "games.betrayal3.ruinTribute", [W(t, "familyTributeResult", "sanity")])), q(e, t, ["gallery", "statuaryCorridor"]) && e.monsters.some((e) => e.kind === "relative" && !e.dead) && r.push(...U(e, t, "pruneFamily", "games.betrayal3.pruneFamily", [W(t, "familyPruneResult", "sanity")])), H(e).flags.tributeRuined === !0 && E(e, H(e).traitor).dead && e.tokens.some((e) => e.kind === "altar" && e.room === n.room) && r.push(...U(e, t, "destroyFamilyAltar", "games.betrayal3.destroyAltar", [W(t, "familyAltarResult", "might")])), r;
	},
	handle(e, t) {
		if (t.op === "monsterBegin" && (e.monsters.find((e) => e.id === t.actor).flags.passageUsed = !1), t.op === "monsterAct") {
			let n = e.monsters.find((e) => e.id === t.actor);
			if (n.dead || n.stunned) return !0;
			let r = Q(e, n);
			if (Ur.includes(y(e, n.room).tile) && n.flags.passageUsed !== !0) for (let t of e.rooms.flatMap(b)) r.push(N(`passage-${t}`, "games.betrayal3.useHiddenPassages", [{
				op: "familyMonsterPassage",
				actor: n.id,
				id: t
			}], t, "room"));
			return H(e).flags.monsterActive = n.id, M(e, n.controller, "games.betrayal3.monsterAction", r), !0;
		}
		switch (t.op) {
			case "familyAltar": return M(e, t.actor, "games.betrayal3.placeAltar", e.rooms.filter((e) => e.floor === "G").flatMap(b).map((e) => N(e, "games.betrayal3.placeToken", [{
				op: "hauntPlaceToken",
				actor: t.actor,
				id: "altar",
				args: { room: e }
			}], e, "room"))), !0;
			case "familyRelatives": {
				if ((t.n ?? 0) <= 0) return !0;
				let n = e.rooms.filter((t) => g(t.tile).symbol === "omen" && !e.monsters.some((n) => n.kind === "relative" && y(e, n.room).id === t.id));
				if (!n.length) {
					for (let n = 0; n < t.n; n++) J(e, "relative", "entranceHall", B(4, 4, 3, 4));
					return !0;
				}
				return M(e, t.actor, "games.betrayal3.placeRelative", n.flatMap(b).map((e) => N(e, "games.betrayal3.placeToken", [{
					op: "familyMakeRelative",
					actor: t.actor,
					id: e
				}, {
					...t,
					n: t.n - 1
				}], e, "room"))), !0;
			}
			case "familyMakeRelative": return J(e, "relative", t.id, B(4, 4, 3, 4)), !0;
			case "familyTributeResult": return z(t.args, "total") >= 4 ? H(e).flags.tributeRuined = !0 : j(e, [G(t.actor, 1, "physical")]), !0;
			case "familyPruneResult": return z(t.args, "total") >= 5 ? M(e, t.actor, "games.betrayal3.chooseRelativeRemove", e.monsters.filter((e) => e.kind === "relative" && !e.dead).map((e) => N(e.id, "games.betrayal3.removeRelative", [{
				op: "familyRemoveRelative",
				actor: t.actor,
				id: e.id
			}], e.id, "token"))) : j(e, [G(t.actor, 1, "physical")]), !0;
			case "familyRemoveRelative": return e.monsters.find((e) => e.id === t.id).dead = !0, !0;
			case "familyAltarResult": return z(t.args, "total") >= 4 ? X(e) : j(e, [G(t.actor, 1, "mental")]), !0;
			case "familyMonsterPassage": return e.monsters.find((e) => e.id === t.actor).flags.passageUsed = !0, j(e, [{
				op: "relocate",
				actor: t.actor,
				id: t.id
			}, {
				op: "monsterAct",
				actor: t.actor
			}]), !0;
			case "hauntTurnEnd": return t.actor === H(e).traitor && H(e).flags.elderArrived !== !0 && (H(e).counters.traitorTurns = (H(e).counters.traitorTurns ?? 0) + 1, H(e).counters.traitorTurns >= 2 && (H(e).flags.elderArrived = !0, J(e, "elder", e.tokens.find((e) => e.kind === "altar").room, B(7, 5, 6, 6)))), !0;
			case "hauntStartMonsters": {
				let t = e.monsters.filter((e) => e.kind === "relative" && !e.dead).map((e) => e.id), n = e.monsters.filter((e) => e.kind === "elder" && !e.dead).map((e) => e.id);
				return j(e, [...Un(e, t), ...Un(e, n)]), !0;
			}
			default: return !1;
		}
	},
	check: Z
};
//#endregion
//#region src/game/haunts/alien_words.ts
function Gr(e, t) {
	return e.tokens.some((e) => e.kind === "alienWord" && e.room === t);
}
var Kr = {
	setup(e) {
		let t = H(e).traitor;
		F(e, t), H(e).counters.traitorWords = $(e, [
			5,
			4,
			4,
			3
		]) - 1, H(e).counters.heroWords = $(e, [
			3,
			4,
			4,
			5
		]), L(e, "alienWord", E(e, t).room);
	},
	actions(e, t) {
		let n = E(e, t);
		return n.team === "traitor" ? !Gr(e, n.room) && !O(e).some((e) => e.room === n.room) && H(e).counters.traitorWords > 0 ? U(e, t, "spreadWord", "games.betrayal3.spreadWord", [W(t, "alienSpreadResult", "knowledge", x(e, n.room).filter((t) => Gr(e, t)).length)]) : [] : q(e, t, [
			"library",
			"observatory",
			"tower",
			"laboratory",
			"specimenRoom"
		]) ? U(e, t, "learnLanguage", "games.betrayal3.learnLanguage", [W(t, "alienLearnResult", "knowledge")]) : [];
	},
	handle(e, t) {
		let n = H(e).traitor, r = e.roll;
		if (t.op === "rollOptions" && r && r.args.attack === !0 && r.args.defense !== !0 && r.args.attackTarget === n && Ln(e, r.actor, "knowledgeOfAliens") && r.args.alienRerolled !== !0 && !("rawOverride" in r.args)) {
			St(e);
			for (let t = 0; t < r.dice.length; t++) for (let n = t; n < r.dice.length; n++) {
				let i = t === n ? [t] : [t, n], a = N(`aliens-${i.join("-")}`, "games.betrayal3.rerollAlienDice", [{
					op: "alienReroll",
					actor: r.actor,
					args: { indices: i }
				}]);
				a.params = { dice: i.map((e) => e + 1).join(", ") }, e.prompt.choices.push(a);
			}
			return !0;
		}
		if (t.op === "rollFinish" && r && r.args.attack === !0 && E(e, r.actor)?.team === "hero" && (r.args.attackSource === n || r.args.attackTarget === n) && Gr(e, E(e, n).room) && r.args.alienRemoved !== !0 && r.dice.length) return M(e, n, "games.betrayal3.chooseHeroDieRemove", r.dice.map((e, r) => N(`remove-${r}`, "games.betrayal3.removeHeroDie", [{
			op: "alienRemoveDie",
			actor: n,
			n: r
		}, t], void 0, "action", e))), !0;
		if (t.op === "combatResult" && t.target === n && E(e, t.actor)?.team === "hero" && E(e, n).cards.includes("mask") && z(t.args, "attackTotal") > z(t.args, "total")) return M(e, t.actor, "games.betrayal3.chooseCombatReward", [N("mask", "games.betrayal3.stealCard", [{
			op: "alienStealMask",
			actor: t.actor
		}], "mask", "card"), N("damage", "games.betrayal3.dealCombatDamage", [{
			op: "characterDamage",
			actor: n,
			target: t.actor,
			n: z(t.args, "attackTotal") - z(t.args, "total"),
			damage: t.damage
		}])]), !0;
		switch (t.op) {
			case "alienReroll":
				for (let n of t.args?.indices) e.roll.dice[n] = ct(e, 1)[0];
				return e.roll.args.alienRerolled = !0, j(e, [{
					op: "rollOptions",
					actor: t.actor
				}]), !0;
			case "alienRemoveDie": return e.roll.dice.splice(t.n, 1), e.roll.args.alienRemoved = !0, A(e, {
				key: "games.betrayal3.logHeroDieRemoved",
				actor: e.roll.actor
			}), !0;
			case "alienStealMask": return at(e, n, t.actor, "mask"), !0;
			case "alienSpreadResult": return z(t.args, "total") >= 7 ? (L(e, "alienWord", E(e, t.actor).room), H(e).counters.traitorWords--) : P(e, t.actor, "knowledge", 2), !0;
			case "alienLearnResult":
				if (z(t.args, "total") >= 4) Ln(e, t.actor, "knowledgeOfAliens") || L(e, "knowledgeOfAliens", null, t.actor);
				else if (H(e).counters.heroWords > 0) {
					let n = E(e, t.actor).room;
					Gr(e, n) ? M(e, t.actor, "games.betrayal3.chooseWordRoom", x(e, n).map((e) => N(e, "games.betrayal3.placeToken", [{
						op: "alienHeroWord",
						actor: t.actor,
						id: e
					}], e, "room"))) : (L(e, "alienWord", n), H(e).counters.heroWords--);
				}
				return !0;
			case "alienHeroWord": return L(e, "alienWord", t.id), H(e).counters.heroWords--, !0;
			case "hauntTurnEnd": return t.actor === n ? H(e).counters.traitorWords === 0 && zn(e) : !E(e, t.actor).dead && [E(e, t.actor).room, ...x(e, E(e, t.actor).room)].some((t) => Gr(e, t)) && j(e, [G(t.actor, 1, "mental")]), !0;
			default: return !1;
		}
	},
	check(e) {
		E(e, H(e).traitor).dead ? X(e) : Z(e);
	}
}, qr = {
	setup(e) {
		let t = E(e, H(e).traitor), n = t.room, r = y(e, n).floor;
		t.cards = t.cards.filter((e) => e !== "idol");
		for (let n of [...t.cards]) I(e, t.rid, n);
		e.omens = e.omens.filter((e) => e !== "idol"), t.dead = !0, t.secret.bodyRemoved = !0, H(e).flags.deadTurns = [t.rid], J(e, "ghostShark", n, B(8, 2, 4, 4), { death: "immune" }), Mn.includes(y(e, n).id) || jn(e, n, "flooded");
		let i = $(e, [
			0,
			1,
			2,
			3
		]);
		j(e, [{
			op: "hauntEnsureRooms",
			actor: t.rid,
			n: i + +!Mn.includes(y(e, n).id),
			args: {
				floor: r,
				nonLanding: !0
			}
		}, {
			op: "sharkInitialFlood",
			actor: t.rid,
			n: i,
			args: { floor: r }
		}]);
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		return n.team === "hero" ? (An(e, t, "item") && Y(e, "explosive") < 5 && r.push(...U(e, t, "searchExplosives", "games.betrayal3.searchExplosives", [W(t, "sharkSearchResult", "speed")])), e.monsters.some((e) => e.kind === "ghostShark" && e.room === n.room) && r.push(...U(e, t, "feedExplosives", "games.betrayal3.feedExplosives", [W(t, "sharkFeedRoll", "might", k(e, n, "dynamite") ? 2 : 0)])), r) : [];
	},
	handle(e, t) {
		if (t.op === "beginTurn" && t.actor === H(e).traitor) return e.turn = t.actor, e.turnNumber++, e.endRequested = !1, j(e, [...Un(e), {
			op: "nextTurn",
			actor: t.actor
		}]), !0;
		if (t.op === "monsterBegin" && (e.monsters.find((e) => e.id === t.actor).flags.musicUsed = !1), t.op === "monsterAct") {
			let n = e.monsters.find((e) => e.id === t.actor), r = Q(e, n);
			if (n.flags.musicUsed !== !0) for (let t of e.rooms.filter((e) => e.condition === "flooded")) r.push(N(`music-${t.id}`, "games.betrayal3.cueOminousMusic", [{
				op: "sharkMusic",
				actor: n.id,
				id: t.id
			}], t.id, "room"));
			return H(e).flags.monsterActive = n.id, M(e, n.controller, "games.betrayal3.monsterAction", r), !0;
		}
		switch (t.op) {
			case "sharkInitialFlood": {
				if ((t.n ?? 0) <= 0) return !0;
				let n = Nn(e).filter((e) => e.floor === t.args?.floor && e.condition !== "flooded");
				return M(e, t.actor, "games.betrayal3.chooseFloodRoom", n.map((e) => N(e.id, "games.betrayal3.floodRoom", [{
					op: "sharkFlood",
					actor: t.actor,
					id: e.id
				}, {
					...t,
					n: t.n - 1
				}], e.id, "room"))), !0;
			}
			case "sharkFlood": return jn(e, t.id, "flooded"), !0;
			case "hauntTurnStart": {
				if (E(e, t.actor).team !== "hero") return !0;
				let n = Nn(e).filter((e) => e.condition !== "flooded"), r = n.filter((t) => b(t).some((t) => Re(e, t).some((t) => y(e, t).condition === "flooded")));
				return r.length || (r = n.filter((t) => b(t).some((t) => Re(e, t).some((t) => Mn.includes(y(e, t).id))))), M(e, H(e).traitor, "games.betrayal3.chooseFloodRoom", r.map((t) => N(t.id, "games.betrayal3.floodRoom", [{
					op: "sharkFlood",
					actor: H(e).traitor,
					id: t.id
				}], t.id, "room"))), !0;
			}
			case "sharkMusic": return e.monsters.find((e) => e.id === t.actor).flags.musicUsed = !0, j(e, [{
				op: "relocate",
				actor: t.actor,
				id: t.id
			}, {
				op: "monsterAct",
				actor: t.actor
			}]), !0;
			case "sharkSearchResult":
				if (z(t.args, "total") >= 4) {
					let n = L(e, "explosive", null, t.actor);
					e.tokens.find((e) => e.id === n).flags.tradable = !0;
				}
				return !0;
			case "sharkFeedRoll": {
				let n = e.tokens.filter((e) => e.kind === "explosive" && e.holder === t.actor).length;
				return M(e, t.actor, "games.betrayal3.chooseExplosivesSpend", Array.from({ length: n + 1 }, (e, n) => {
					let r = N(`spend-${n}`, "games.betrayal3.spendExplosives", [{
						op: "sharkFeedResult",
						actor: t.actor,
						n,
						args: { total: z(t.args, "total") + 2 * n }
					}], void 0, "action", n);
					return r.params = {
						n,
						total: z(t.args, "total") + 2 * n
					}, r;
				})), !0;
			}
			case "sharkFeedResult": {
				let n = e.tokens.filter((e) => e.kind === "explosive" && e.holder === t.actor).slice(0, t.n);
				return e.tokens = e.tokens.filter((e) => !n.includes(e)), z(t.args, "total") >= 10 ? (e.monsters.find((e) => e.kind === "ghostShark").dead = !0, X(e)) : (j(e, [G(t.actor, 2, "physical")]), e.endRequested = !0), !0;
			}
			case "hauntMonsterEnd": return Nn(e).length > 0 && Nn(e).every((e) => e.condition === "flooded") && zn(e), !0;
			default: return !1;
		}
	},
	check: Z
}, Jr = {
	setup(e) {
		let t = H(e).traitor;
		H(e).monsterAfter = t;
		for (let n = 0; n < $(e, [
			1,
			2,
			3,
			3
		]); n++) J(e, "gardenFae", E(e, t).room, B(2, 6, 4, 4), {
			attack: "speed",
			death: "immune"
		});
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team === "traitor") return e.attacked ? [] : O(e).filter((e) => e.room === n.room).map((e) => N(`speed-${e.rid}`, "games.betrayal3.attackSpeed", [{
			op: "attack",
			actor: t,
			target: e.rid,
			trait: "speed"
		}], e.rid, "player"));
		if (An(e, t, "item") && Y(e, "coldIron") < 2 && r.push(...U(e, t, "rendIron", "games.betrayal3.rendIron", [W(t, "gardenIronResult", "might")])), q(e, t, ["library", "ritualRoom"]) && !Ln(e, t, "knowledgeOfFae") && r.push(...U(e, t, "learnFae", "games.betrayal3.learnFae", [W(t, "gardenLearnResult", "knowledge")])), e.monsters.some((e) => e.kind === "gardenFae" && !e.dead && e.room === n.room)) {
			let i = 2 * [
				Ln(e, t, "knowledgeOfFae"),
				Ln(e, t, "coldIron"),
				k(e, n, "ring")
			].filter(Boolean).length;
			r.push(...U(e, t, "bindFae", "games.betrayal3.bindFae", [W(t, "gardenBindResult", "knowledge", i)]));
		}
		return r;
	},
	handle(e, t) {
		if (t.op === "monsterAct") {
			let n = e.monsters.find((e) => e.id === t.actor);
			if (n.dead || n.stunned) return !0;
			let r = Q(e, n).filter((e) => !e.id.startsWith("attack-"));
			if (n.flags.attacked !== !0) for (let t of O(e).filter((t) => S(e, n.room, t.room))) r.push(N(`attack-${t.rid}`, "games.betrayal3.attackSpeed", [{
				op: "monsterAttack",
				actor: n.id,
				target: t.rid
			}], t.rid, "player"));
			return H(e).flags.monsterActive = n.id, M(e, n.controller, "games.betrayal3.monsterAction", r), !0;
		}
		switch (t.op) {
			case "gardenIronResult":
				if (z(t.args, "total") >= 5) {
					let n = L(e, "coldIron", null, t.actor);
					e.tokens.find((e) => e.id === n).flags.tradable = !0;
				}
				return !0;
			case "gardenLearnResult": return z(t.args, "total") >= 5 && L(e, "knowledgeOfFae", null, t.actor), !0;
			case "gardenBindResult": return z(t.args, "total") >= 9 && X(e), !0;
			default: return !1;
		}
	},
	check: Z
};
//#endregion
//#region src/game/haunts/wedding.ts
function Yr(e) {
	return h.includes(e);
}
function Xr(e, t, n, r = !1) {
	if (r) for (let t of e.explorers) t.secret.faceUpOmens.includes(n) || t.secret.faceUpOmens.push(n);
	A(e, {
		key: "games.betrayal3.logOmenRevealed",
		actor: t,
		id: n
	});
}
var Zr = {
	setup(e) {
		let t = H(e).traitor;
		F(e, t), E(e, t).room = "entranceHall", H(e).monsterAfter = t;
		for (let t of e.explorers) t.secret.faceUpOmens = [];
		for (let n of [...E(e, t).cards].filter(Yr)) at(e, t, H(e).revealer, n);
		j(e, [{
			op: "weddingPrepare",
			actor: H(e).revealer
		}, {
			op: "weddingPartyPlace",
			actor: t,
			n: $(e, [
				1,
				2,
				3,
				4
			])
		}]), Vn(e, ["secretStaircase"], H(e).revealer);
	},
	filterActions(e, t, n) {
		return t !== H(e).traitor || !e.tokens.some((n) => n.kind === "altar" && n.room === E(e, t).room) ? n : n.filter((e) => !e.id.startsWith("move-") && !e.id.startsWith("key-") && !e.id.startsWith("discover-") && e.id !== "item-map");
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		return n.team === "hero" ? (n.cards.includes("ring") && r.push(...U(e, t, "compelSpirit", "games.betrayal3.compelSpirit", [{
			op: "weddingReveal",
			actor: t,
			id: "ring"
		}, W(t, "weddingCompelResult", "knowledge")])), n.room === E(e, H(e).traitor).room && e.tokens.some((e) => e.kind === "altar" && e.room === n.room) && r.push(...U(e, t, "performCeremony", "games.betrayal3.performCeremony", [W(t, "weddingCeremonyResult", "sanity")])), r) : [];
	},
	handle(e, t) {
		let n = H(e).traitor;
		if (t.op === "gain" && t.actor === n && (t.n ?? 0) < 0) {
			let r = E(e, n), i = t.trait;
			return P(e, n, i, Math.max(t.n, Me(r.character).start[i] - r.traits[i])), !0;
		}
		if (t.op === "relocate" && t.actor === n && e.tokens.some((t) => t.kind === "altar" && t.room === E(e, n).room) && t.id !== E(e, n).room) return !0;
		if (t.op === "attack" && t.actor === n && E(e, t.target)?.team === "hero" && t.args?.weddingRevealed !== !0) {
			let r = E(e, t.target), i = r.cards.filter((e) => Yr(e) && !r.secret.faceUpOmens.includes(e)), a = {
				...t,
				args: {
					...t.args,
					weddingRevealed: !0
				}
			};
			return i.length ? (M(e, n, "games.betrayal3.chooseOmenReveal", [...i.map((e, n) => {
				let r = N(`omen-${n}`, "games.betrayal3.revealOmenBack", [{
					op: "weddingReveal",
					actor: t.target,
					id: e,
					args: { permanent: !0 }
				}, a], "hiddenOmen", "card", n + 1);
				return r.params = { n: n + 1 }, r;
			}), N("skip", "games.betrayal3.skipOmenReveal", [a])]), !0) : (j(e, [a]), !0);
		}
		switch (t.op) {
			case "weddingPrepare": {
				let n = $(e, [
					4,
					6,
					9,
					12
				]);
				e.tiles.length >= n && (e.tiles = e.tiles.slice(0, n)), e.tiles.length || L(e, "altar", E(e, H(e).revealer).room);
				let r = T(e, O(e).flatMap((e) => e.cards.filter(Yr)));
				for (let t of O(e)) t.cards = t.cards.filter((e) => !Yr(e));
				return E(e, t.actor).secret.weddingPool = r, j(e, [{
					op: "weddingDistribute",
					actor: t.actor
				}]), !0;
			}
			case "weddingDistribute": {
				let n = E(e, t.actor).secret.weddingPool;
				return n.length ? (M(e, t.actor, "games.betrayal3.distributeSecretOmen", O(e).map((e) => N(e.rid, "games.betrayal3.giveSecretOmen", [{
					op: "weddingGive",
					actor: t.actor,
					target: e.rid,
					id: n[0]
				}, t], e.rid, "player")), { card: n[0] }), e.prompt.secretFor = O(e).map((e) => e.rid), !0) : (delete E(e, t.actor).secret.weddingPool, !0);
			}
			case "weddingGive": return E(e, t.target).cards.push(t.id), E(e, t.actor).secret.weddingPool.shift(), !0;
			case "weddingPartyPlace": {
				if ((t.n ?? 0) <= 0) return !0;
				let n = e.rooms.filter((t) => g(t.tile).symbol === "omen" && !e.monsters.some((n) => n.kind === "weddingParty" && y(e, n.room).id === t.id));
				if (!n.length) {
					for (let n = 0; n < t.n; n++) J(e, "weddingParty", "groundStaircase", B(5, 4, 2, 3));
					return !0;
				}
				return M(e, t.actor, "games.betrayal3.placeWeddingParty", n.flatMap(b).map((e) => N(e, "games.betrayal3.placeToken", [{
					op: "weddingMakeParty",
					actor: t.actor,
					id: e
				}, {
					...t,
					n: t.n - 1
				}], e, "room"))), !0;
			}
			case "weddingMakeParty": return J(e, "weddingParty", t.id, B(5, 4, 2, 3)), !0;
			case "weddingReveal": return Xr(e, t.actor, t.id, t.args?.permanent === !0), !0;
			case "weddingCompelResult": return j(e, [{
				op: "hauntMoveSteps",
				actor: t.actor,
				target: n,
				n: z(t.args, "total")
			}]), !0;
			case "weddingCeremonyResult": return z(t.args, "total") >= 6 && X(e), !0;
			case "hauntDeath":
				for (let n of E(e, t.actor).cards.filter(Yr)) Xr(e, t.actor, n, !0);
				return !0;
			default: return !1;
		}
	},
	after(e, t) {
		if (t.op === "placeDiscovered" && !e.tiles.length && !e.tokens.some((e) => e.kind === "altar") && L(e, "altar", E(e, t.actor).room), t.op === "takeDrawn" && Yr(t.id)) {
			let n = [...e.journal].reverse().find((e) => e.key === "games.betrayal3.logDraw" && e.actor === t.actor && e.id === t.id);
			n && (n.secretFor = [t.actor]);
		}
		if (t.op === "tradeAccept" || t.op === "weddingPrepare") for (let t of e.journal.filter((t) => t.key === "games.betrayal3.logTrade" && t.id && Yr(t.id) && E(e, t.actor)?.team === "hero" && E(e, t.target)?.team === "hero")) t.secretFor = O(e).map((e) => e.rid);
		if ((t.op === "rollCast" || t.op === "rollFeatherResult") && e.roll && E(e, e.roll.actor)?.team === "hero" && e.roll.trait) for (let t of {
			might: ["idol"],
			speed: ["dog", "mask"],
			sanity: ["holySymbol", "ring"],
			knowledge: ["book", "skull"]
		}[e.roll.trait]) k(e, E(e, e.roll.actor), t) && Xr(e, e.roll.actor, t);
		t.op === "attack" && t.id && Yr(t.id) && E(e, t.actor)?.team === "hero" && Xr(e, t.actor, t.id), t.op === "tradeStart" && t.args?.dog === !0 && Xr(e, t.actor, "dog"), t.op === "replaceTile" && Xr(e, t.actor, "holySymbol"), t.op === "death" && e.queue.some((e) => e.op === "roll" && e.actor === t.actor && R(e.args, "context") === "skull") && Xr(e, t.actor, "skull");
	},
	check(e) {
		let t = E(e, H(e).traitor);
		t.cards.includes("ring") ? zn(e) : !O(e).length && e.tokens.some((e) => e.kind === "altar" && e.room === t.room) && !e.explorers.some((n) => n.cards.includes("ring") && (n.room === t.room || k(e, t, "dog") && C(e, t.room, n.room) <= 4)) && pt(e, [], "weddingStalemate");
	}
};
//#endregion
//#region src/game/haunts/cursed_items.ts
function Qr(e, t, n) {
	let r = e.monsters.find((e) => e.id === n);
	E(e, t).cards.push(R(r.flags, "card")), r.dead = !0;
}
function $r(e, t) {
	let n = Q(e, t).filter((e) => !e.id.startsWith("attack-"));
	if (t.flags.attacked === !0) return n;
	let r = R(t.flags, "card"), i = je.has(r) ? r : "";
	if (i === "dynamite") for (let r of [t.room, ...x(e, t.room)]) n.push(N(`dynamite-${r}`, "games.betrayal3.throwDynamite", [{
		op: "cursedDynamite",
		actor: t.id,
		id: r
	}, {
		op: "monsterAct",
		actor: t.id
	}], r, "room"));
	for (let r of O(e)) {
		let a = i === "gun" ? S(e, t.room, r.room) : i === "crossbow" ? t.room === r.room || x(e, t.room).includes(r.room) : t.room === r.room;
		i !== "dynamite" && a && n.push(N(`attack-${r.rid}`, i ? "games.betrayal3.attackWith" : "games.betrayal3.attackUnarmed", [{
			op: "cursedAttack",
			actor: t.id,
			target: r.rid,
			id: i
		}], r.rid, "player"));
	}
	return n;
}
var ei = {
	setup(e) {
		let t = H(e).traitor;
		F(e, t), H(e).monsterAfter = t;
		let n = e.explorers.flatMap((e) => e.cards);
		for (let t of e.explorers) t.cards = [], t.startCards = [];
		H(e).flags.cursedPool = n.filter((e) => e !== "holySymbol"), H(e).flags.cursedSelected = ["holySymbol"], j(e, [{
			op: "cursedSelect",
			actor: t
		}]);
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		for (let i of e.monsters.filter((e) => !e.dead && e.room === n.room && (n.team === "traitor" || e.stunned))) r.push(...U(e, t, n.team === "hero" ? "dispelCurse" : "channelSpirit", n.team === "hero" ? "games.betrayal3.dispelCurse" : "games.betrayal3.channelSpirit", [{
			op: "cursedTake",
			actor: t,
			id: i.id
		}], i.id, "token"));
		if (n.team === "hero") {
			if (!e.attacked) for (let i of e.monsters.filter((e) => !e.dead && e.room === n.room)) for (let e of ["sanity", "knowledge"]) r.push(N(`${e}-${i.id}`, "games.betrayal3.attackTrait", [{
				op: "attack",
				actor: t,
				target: i.id,
				trait: e,
				damage: "mental"
			}], i.id, "player"));
			q(e, t, [
				"gallery",
				"graveyard",
				"operatingTheatre",
				"soundproofedRoom"
			]) && r.push(...U(e, t, "speakSpirits", "games.betrayal3.speakSpirits", [K(t, 1, "general"), {
				op: "chooseGain",
				actor: t,
				n: 1
			}]));
		}
		return r;
	},
	handle(e, t) {
		if (t.op === "combatResult" && t.trait === "might" && z(t.args, "attackTotal") > z(t.args, "total") && E(e, t.actor) && E(e, t.target) && E(e, t.actor).team !== E(e, t.target).team && E(e, t.target).cards.length) return M(e, t.actor, "games.betrayal3.stealOrDamage", [N("damage", "games.betrayal3.dealDamage", [{
			op: "characterDamage",
			actor: t.target,
			target: t.actor,
			n: z(t.args, "attackTotal") - z(t.args, "total"),
			damage: t.damage
		}]), ...E(e, t.target).cards.map((e) => N(e, "games.betrayal3.stealCard", [{
			op: "cursedSteal",
			actor: t.actor,
			target: t.target,
			id: e
		}], e, "card"))]), !0;
		if (t.op === "monsterAct") {
			let n = e.monsters.find((e) => e.id === t.actor);
			return !n.dead && !n.stunned && (H(e).flags.monsterActive = n.id, M(e, n.controller, "games.betrayal3.monsterAction", $r(e, n))), !0;
		}
		switch (t.op) {
			case "cursedSelect": {
				let n = H(e).flags.cursedSelected, r = H(e).flags.cursedPool;
				if (n.length >= $(e, [
					4,
					5,
					7,
					9
				]) || !r.length) {
					for (let t of r) (h.includes(t) ? e.omens : e.items).push(t);
					return delete H(e).flags.cursedPool, j(e, n.map((e, n) => ({
						op: "cursedPlace",
						actor: t.actor,
						id: e,
						n: n + 1
					}))), !0;
				}
				return M(e, t.actor, "games.betrayal3.chooseCursedCard", r.map((e) => N(e, "games.betrayal3.selectCursedCard", [{
					op: "cursedSelectCard",
					actor: t.actor,
					id: e
				}], e, "card"))), !0;
			}
			case "cursedSelectCard": return H(e).flags.cursedSelected.push(t.id), H(e).flags.cursedPool = H(e).flags.cursedPool.filter((e) => e !== t.id), j(e, [{
				op: "cursedSelect",
				actor: t.actor
			}]), !0;
			case "cursedPlace": {
				let n = e.rooms.filter((t) => !t.condition && [
					"item",
					"item2",
					"omen"
				].includes(g(t.tile).symbol ?? "") && !e.monsters.some((n) => y(e, n.room).id === t.id)).flatMap(b);
				return M(e, t.actor, "games.betrayal3.chooseCursedRoom", (n.length ? n : ["entranceHall"]).map((e) => N(e, "games.betrayal3.placeToken", [{
					op: "cursedCreate",
					actor: t.actor,
					id: t.id,
					n: t.n,
					args: { room: e }
				}], e, "room"))), !0;
			}
			case "cursedCreate": return J(e, "cursedItem", R(t.args, "room"), B(5, 4, 5, 5), { flags: {
				ai: "manual",
				card: t.id,
				number: t.n
			} }), !0;
			case "cursedTake": return Qr(e, t.actor, t.id), E(e, t.actor).team === "traitor" && M(e, t.actor, "games.betrayal3.chooseDamageTarget", O(e).filter((n) => y(e, n.room).floor === y(e, E(e, t.actor).room).floor).map((e) => N(e.rid, "games.betrayal3.damageHero", [K(e.rid, 2, "general")], e.rid, "player"))), !0;
			case "cursedSteal": return at(e, t.target, t.actor, t.id), !0;
			case "cursedAttack": {
				let n = e.monsters.find((e) => e.id === t.actor);
				return n.flags.attacked = !0, j(e, [{
					...t,
					op: "attack",
					args: { bonus: +(t.id === "ring") }
				}, {
					op: "monsterAct",
					actor: t.actor
				}]), !0;
			}
			case "cursedDynamite": {
				let n = e.monsters.find((e) => e.id === t.actor);
				return n.flags.attacked = !0, n.dead = !0, e.items.push("dynamite"), j(e, [...D(e).filter((e) => e.room === t.id).map((e) => e.rid), ...e.monsters.filter((e) => !e.dead && e.room === t.id).map((e) => e.id)].map((e) => ({
					op: "roll",
					actor: e,
					trait: "speed",
					args: { context: "dynamite" },
					then: [{
						op: "dynamiteResult",
						actor: e,
						target: n.id
					}]
				}))), !0;
			}
			case "hauntTurnEnd": {
				let n = E(e, t.actor);
				return n.dead || n.team !== "hero" || !n.cards.includes("holySymbol") || (n.team === "hero" && n.room === "entranceHall" && n.cards.length >= $(e, [
					4,
					5,
					6,
					8
				]) ? X(e) : j(e, [K(t.actor, 1, "general")])), !0;
			}
			default: return !1;
		}
	},
	check: Z
}, ti = {
	setup(e) {
		let t = E(e, H(e).traitor), n = y(e, t.room).floor;
		for (let n of [...t.cards]) I(e, t.rid, n);
		t.dead = !0, t.secret.bodyRemoved = !0, H(e).flags.deadTurns = [t.rid], H(e).counters.fireSupply = $(e, [
			6,
			5,
			4,
			3
		]), J(e, "bakeneko", t.room, B(3, 6, 6, 2)), j(e, Array.from({ length: $(e, [
			3,
			4,
			5,
			7
		]) }, () => ({
			op: "catsPlace",
			actor: t.rid,
			args: { floor: n }
		})));
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team !== "hero") return r;
		for (let i of e.monsters.filter((e) => e.kind === "undeadCat" && !e.dead && e.room === n.room)) for (let a of n.cards) r.push(...U(e, t, "distractCat", "games.betrayal3.distractCat", [{
			op: "bury",
			actor: t,
			id: a
		}, {
			op: "catsDistract",
			actor: t,
			target: i.id
		}], `${i.id}:${a}`, "token"));
		return r;
	},
	handle(e, t) {
		if (t.op === "damage" && (t.args = {
			...t.args,
			journalAt: e.journal.length
		}), t.op === "beginTurn" && t.actor === H(e).traitor) return e.turn = t.actor, e.turnNumber++, e.endRequested = !1, H(e).used = [], j(e, [
			...Un(e, e.monsters.filter((e) => e.kind === "bakeneko").map((e) => e.id)),
			{
				op: "catsStart",
				actor: t.actor
			},
			{
				op: "nextTurn",
				actor: t.actor
			}
		]), !0;
		let n = e.monsters.find((e) => e.id === t.actor);
		if (t.op === "monsterAct" && n && !n.dead && !n.stunned) {
			let t = Q(e, n).filter((t) => !(n.kind === "undeadCat" && t.id.startsWith("attack-") && (H(e).flags.catsHurt ?? []).includes(t.target)));
			if (n.kind === "bakeneko") {
				if (On(e, "burnHouse")) for (let r of e.rooms.flatMap(b).filter((t) => S(e, n.room, t) && !ft(e, "fire", t))) t.push(N(`burn-${r}`, "games.betrayal3.burnRoom", [
					{
						op: "hauntUse",
						actor: n.id,
						id: "burnHouse"
					},
					{
						op: "catsBurn",
						actor: n.id,
						id: r
					},
					{
						op: "monsterAct",
						actor: n.id
					}
				], r, "room"));
				let r = y(e, n.room);
				On(e, "summonCat") && !r.condition && g(r.tile).symbol === "omen" && t.push(N("summonCat", "games.betrayal3.summonCat", [
					{
						op: "hauntUse",
						actor: n.id,
						id: "summonCat"
					},
					{
						op: "catsCreate",
						actor: n.id,
						id: n.room
					},
					{
						op: "monsterAct",
						actor: n.id
					}
				]));
			}
			return H(e).flags.monsterActive = n.id, M(e, n.controller, "games.betrayal3.monsterAction", t), !0;
		}
		if (t.op === "combatResult") {
			let r = e.monsters.find((e) => e.id === t.target), i = z(t.args, "attackTotal") - z(t.args, "total");
			if (r?.kind === "bakeneko" && t.trait === "might" && i > 0 && !e.monsters.some((t) => t.kind === "undeadCat" && !t.dead && y(e, t.room).floor === y(e, r.room).floor)) return X(e), !0;
			if (n?.kind === "undeadCat" && i > 0) return j(e, [G(t.target, Math.min(2, i), "physical")]), !0;
		}
		switch (t.op) {
			case "catsPlace": return M(e, t.actor, "games.betrayal3.chooseCatRoom", kn(e, t.args.floor).map((e) => N(e, "games.betrayal3.placeToken", [{
				op: "catsCreate",
				actor: t.actor,
				id: e
			}], e, "room"))), !0;
			case "catsCreate": return J(e, "undeadCat", t.id, B(3, 6, 2, 4), {
				attack: "speed",
				death: "kill"
			}), !0;
			case "catsStart": return H(e).flags.catsHurt = [], H(e).flags.catsTakingTurn = !0, j(e, [...Un(e, e.monsters.filter((e) => e.kind === "undeadCat").map((e) => e.id)), {
				op: "catsEnd",
				actor: t.actor
			}]), !0;
			case "catsEnd": return H(e).flags.catsTakingTurn = !1, !0;
			case "catsBurn": return L(e, "fire", t.id), H(e).counters.fireSupply--, H(e).counters.fireSupply === 0 && zn(e), !0;
			case "catsDistract": {
				let n = e.monsters.find((e) => e.id === t.target);
				return n.stunned = !0, j(e, [{
					op: "hauntMoveSteps",
					actor: t.actor,
					target: n.id,
					n: 4
				}]), !0;
			}
			case "hauntEnter": return E(e, t.actor)?.team === "hero" && ft(e, "fire", E(e, t.actor).room) && j(e, [W(t.actor, "catsFireResult", "speed")]), !0;
			case "catsFireResult": return z(t.args, "total") < 5 && j(e, [G(t.actor, 1, "physical")]), !0;
			default: return !1;
		}
	},
	after(e, t) {
		let n = e.monsters.find((e) => e.kind === "bakeneko");
		n && (n.traits.might = Math.min(8, 3 + e.monsters.filter((t) => t.kind === "undeadCat" && !t.dead && y(e, t.room).floor === y(e, n.room).floor).length)), t.op === "damage" && H(e).flags.catsTakingTurn === !0 && e.journal.slice(z(t.args, "journalAt")).some((e) => e.key === "games.betrayal3.logDamage" && e.actor === t.actor && (e.n ?? 0) > 0) && (H(e).flags.catsHurt = [.../* @__PURE__ */ new Set([...H(e).flags.catsHurt, t.actor])]);
	},
	check: Z
}, ni = {
	setup(e) {
		let t = H(e).traitor;
		H(e).monsterAfter = t, e.explorers.some((e) => e.cards.includes("magicCamera")) || (e.items = e.items.filter((e) => e !== "magicCamera"), E(e, t).cards.push("magicCamera"));
		for (let t of O(e)) {
			let n = L(e, "essence", null, t.rid);
			e.tokens.find((e) => e.id === n).flags.owner = t.rid;
		}
		j(e, [{
			op: "cameraPlace",
			actor: t,
			n: $(e, [
				2,
				3,
				4,
				5
			])
		}]);
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team === "hero" && n.room === E(e, H(e).traitor).room && E(e, H(e).traitor).cards.includes("magicCamera") && r.push(...U(e, t, "smashCamera", "games.betrayal3.smashCamera", [W(t, "cameraSmashResult", "sanity")])), n.team === "traitor") for (let i of O(e).filter((t) => e.tokens.some((e) => e.kind === "essence" && e.holder === t.rid && e.flags.owner === t.rid) && (n.room === t.room || n.cards.includes("magicCamera") && S(e, n.room, t.room)))) r.push(...U(e, t, "takePhoto", "games.betrayal3.takePhoto", [W(t, "cameraPhotoResult", "speed", 0, { target: i.rid })], i.rid, "player"));
		return r;
	},
	handle(e, t) {
		if (t.op === "attack" && t.actor === H(e).traitor && e.tokens.some((e) => e.kind === "essence" && e.holder === t.actor && e.flags.owner === t.target) && (t.args = {
			...t.args,
			extraDice: z(t.args, "extraDice") + 2
		}), t.op === "combatResult") {
			let n = z(t.args, "attackTotal") - z(t.args, "total"), r = n > 0 ? t.target : n < 0 && t.id !== "gun" && t.id !== "crossbow" && t.args?.noCounter !== !0 ? t.actor : null, i = e.monsters.find((e) => e.id === r);
			if (i?.kind === "photographer" && t.trait === "might") return i.dead = !0, !0;
		}
		if (t.op === "monsterAct") {
			let n = e.monsters.find((e) => e.id === t.actor);
			if (!n.dead && !n.stunned) {
				let t = Q(e, n).filter((e) => !e.id.startsWith("attack-"));
				if (n.flags.attacked !== !0) for (let r of O(e).filter((t) => S(e, n.room, t.room))) t.push(N(`attack-${r.rid}`, "games.betrayal3.attackSanity", [{
					op: "monsterAttack",
					actor: n.id,
					target: r.rid
				}], r.rid, "player"));
				H(e).flags.monsterActive = n.id, M(e, n.controller, "games.betrayal3.monsterAction", t);
			}
			return !0;
		}
		switch (t.op) {
			case "cameraPlace": {
				if ((t.n ?? 0) <= 0) return !0;
				let n = [
					"U",
					"G",
					"B"
				], r = n.map((t) => e.monsters.filter((n) => y(e, n.room).floor === t).length), i = Math.min(...r), a = n.filter((e, t) => r[t] === i), o = a.find((t) => !Nn(e).some((e) => e.floor === t));
				return o ? (j(e, [{
					op: "hauntEnsureRooms",
					actor: t.actor,
					n: 1,
					args: {
						floor: o,
						nonLanding: !0
					}
				}, t]), !0) : (M(e, t.actor, "games.betrayal3.choosePhotographerRoom", Nn(e).filter((e) => a.includes(e.floor)).flatMap(b).map((e) => N(e, "games.betrayal3.placeToken", [{
					op: "cameraCreate",
					actor: t.actor,
					id: e
				}, {
					...t,
					n: t.n - 1
				}], e, "room"))), !0);
			}
			case "cameraCreate": return J(e, "photographer", t.id, B(4, 1, 6, 2), {
				attack: "sanity",
				damage: "mental"
			}), !0;
			case "cameraSmashResult": return z(t.args, "total") >= 6 && (E(e, H(e).traitor).cards = E(e, H(e).traitor).cards.filter((e) => e !== "magicCamera"), H(e).flags.cameraDestroyed = !0), !0;
			case "cameraPhotoResult":
				if (z(t.args, "total") >= 6) {
					let n = e.tokens.find((e) => e.kind === "essence" && e.flags.owner === t.args.target);
					n.holder = t.actor, n.room = null, j(e, [{
						op: "chooseGain",
						actor: t.actor,
						n: 1
					}]);
				}
				return !0;
			case "hauntTurnEnd": {
				let n = E(e, t.actor);
				if (n.dead || n.team !== "hero") return !0;
				if (e.monsters.some((t) => !t.dead && t.kind === "photographer" && S(e, t.room, n.room))) {
					let t = e.tokens.find((e) => e.kind === "essence" && e.holder === n.rid && e.flags.owner === n.rid);
					t && (t.holder = H(e).traitor);
				}
				return H(e).flags.cameraDestroyed === !0 && e.monsters.every((e) => e.dead) && X(e), !0;
			}
			default: return !1;
		}
	},
	after(e) {
		let t = E(e, H(e).traitor);
		if (t.cards.includes("magicCamera")) for (let e of w) t.traits[e] = Math.max(0, t.traits[e]);
	},
	check: Z
};
//#endregion
//#region src/game/haunts/dimension.ts
function ri(e) {
	return [...new Set(Ve(e, "G").map((e) => e.room))];
}
var ii = {
	setup(e) {
		let t = H(e).traitor, n = e.rooms.filter((t) => Mn.includes(t.id) || e.explorers.some((e) => v(e.room) === t.id));
		F(e, t), H(e).flags.deadTurns = [t], H(e).track = $(e, [
			6,
			3,
			1,
			0
		]), e.events = [], e.tiles = T(e, [...e.tiles, ...e.rooms.filter((e) => !n.includes(e)).map((e) => e.tile)]), e.tokens = e.tokens.filter((e) => !e.room || n.some((t) => t.id === v(e.room))), e.rooms = n.filter((e) => [
			"entranceHall",
			"hallway",
			"groundStaircase"
		].includes(e.id)).map((e) => ({
			...e,
			floor: "G"
		})), j(e, n.filter((t) => !e.rooms.some((e) => e.id === t.id)).map((e) => ({
			op: "placeRoom",
			actor: t,
			id: e.tile,
			args: { floor: "G" }
		})));
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team === "hero") return !e.tokens.some((e) => e.kind === "christina") && An(e, t, "omen") && r.push(...U(e, t, "findChristina", "games.betrayal3.findChristina", [{
			op: "roll",
			actor: t,
			n: H(e).track,
			args: { context: "findChristina" },
			then: [{
				op: "dimensionFindResult",
				actor: t
			}]
		}])), n.room === "entranceHall" && e.tokens.some((e) => e.kind === "christina" && e.holder === t) && r.push(...U(e, t, "escapeDimension", "games.betrayal3.attemptEscape", [{
			op: "roll",
			actor: t,
			n: H(e).track,
			args: { context: "escapeDimension" },
			then: [{
				op: "dimensionEscapeResult",
				actor: t
			}]
		}])), r;
		ri(e).includes(n.room) && r.push(...U(e, t, "leapFaith", "games.betrayal3.leapFaith", [W(t, "dimensionLeapResult", "sanity")]));
		let i = $(e, [
			1,
			1,
			2,
			2
		]) + +!!e.tokens.some((t) => t.kind === "christina" && t.holder && E(e, t.holder).team === "hero");
		if ((H(e).counters.dimensionUses ?? 0) < i) {
			let n = {
				op: "hauntAddCounter",
				actor: t,
				id: "dimensionUses"
			};
			r.push(N("dimension-pain", "games.betrayal3.manipulatePain", [n, ...O(e).map((e) => ({
				op: "dimensionPain",
				actor: t,
				target: e.rid
			}))])), r.push(N("dimension-gain", "games.betrayal3.manipulateGain", [n, {
				op: "chooseGain",
				actor: t,
				n: 2
			}]));
			for (let i of e.rooms.filter((t) => !Mn.includes(t.id) && qe(e, t.id).length)) r.push(N(`dimension-room-${i.id}`, "games.betrayal3.manipulateRoom", [n, {
				op: "dimensionShiftOptions",
				actor: t,
				id: i.id
			}], i.id, "room"));
		}
		return r;
	},
	filterActions(e, t, n) {
		return E(e, t).team === "traitor" ? n.filter((e) => !e.id.startsWith("discover-")) : n;
	},
	handle(e, t) {
		if (t.op === "placeRoom" && (t.args = {
			...t.args,
			floor: "G"
		}), t.op === "beginTurn" && t.actor === H(e).traitor && E(e, t.actor).dead) return M(e, t.actor, "games.betrayal3.chooseRoom", ri(e).map((e) => N(e, "games.betrayal3.moveTo", [{
			op: "dimensionRevive",
			actor: t.actor,
			id: e
		}, t], e, "room"))), !0;
		if (t.op === "draw" && t.id === "event") return !0;
		if (t.op === "elevatorResult") {
			let n = z(t.args, "total");
			if (n !== 2 && n !== 4) return !0;
			let r = {
				...e,
				rooms: e.rooms.filter((e) => e.id !== "mysticElevator")
			};
			return M(e, t.actor, "games.betrayal3.chooseElevatorDoor", Ve(r, "G").map((e) => {
				let n = N(`${e.x},${e.y}`, "games.betrayal3.moveElevatorTo", [{
					op: "elevatorMove",
					actor: t.actor,
					args: {
						floor: "G",
						x: e.x,
						y: e.y,
						rotation: (e.direction + 2) % 4
					}
				}], e.room, "room");
				return n.params = { direction: Ne[e.direction] }, n;
			})), !0;
		}
		switch (t.op) {
			case "hauntTurnStart": return H(e).counters.dimensionUses = 0, !0;
			case "dimensionRevive": {
				let n = E(e, t.actor);
				return n.dead = !1, n.room = t.id, F(e, n.rid), !0;
			}
			case "dimensionFindResult":
				if (z(t.args, "total") >= 9) {
					let n = L(e, "christina", null, t.actor);
					e.tokens.find((e) => e.id === n).flags = {
						tradable: !0,
						heroesOnly: !0
					};
				} else j(e, [G(t.actor, 1, "general")]);
				return e.endRequested = !0, !0;
			case "dimensionEscapeResult": return z(t.args, "total") >= 9 ? X(e) : e.endRequested = !0, !0;
			case "dimensionLeapResult": return z(t.args, "total") >= 3 && M(e, t.actor, "games.betrayal3.chooseRoom", ri(e).map((e) => N(e, "games.betrayal3.moveTo", [{
				op: "relocate",
				actor: t.actor,
				id: e
			}], e, "room"))), !0;
			case "dimensionPain": return j(e, [K(t.target, 1, "general"), {
				op: "dimensionPainMove",
				actor: t.actor,
				target: t.target,
				args: { journalAt: e.journal.length }
			}]), !0;
			case "dimensionPainMove": {
				let n = e.journal.slice(z(t.args, "journalAt")).filter((e) => e.key === "games.betrayal3.logDamage" && e.actor === t.target).reduce((e, t) => e + (t.n ?? 0), 0);
				return j(e, [{
					op: "hauntMoveSteps",
					actor: t.actor,
					target: t.target,
					n
				}]), !0;
			}
			case "dimensionShiftOptions": return M(e, t.actor, "games.betrayal3.chooseRoomRelocation", qe(e, t.id).map((e) => {
				let n = N(`${e.x},${e.y},${e.rotation}`, "games.betrayal3.relocateRoom", [{
					op: "dimensionShift",
					actor: t.actor,
					id: t.id,
					args: e
				}], t.id, "room", e.rotation);
				return n.params = {
					x: e.x,
					y: e.y,
					rotation: e.rotation * 90
				}, n;
			})), !0;
			case "dimensionShift": return e.rooms = We(e, t.id, z(t.args, "x"), z(t.args, "y"), z(t.args, "rotation")), !0;
			default: return !1;
		}
	},
	after(e, t) {
		t.op === "placeDiscovered" && (e.endRequested = !1), t.op === "takeDrawn" && t.args?.deck === "omen" && (H(e).track = Math.min(8, H(e).track + 1)), t.op === "placeRequired" && (y(e, t.id).floor = "G");
	},
	check: Z
}, ai = {
	setup(e) {
		let t = H(e).traitor;
		H(e).monsterAfter = t;
		for (let n = 0; n < $(e, [
			2,
			3,
			4,
			5
		]); n++) J(e, "slug", E(e, t).room, B(3, 4, 3, 5), {
			attack: "sanity",
			damage: "mental",
			death: "kill"
		});
		j(e, ["B", "U"].map((e) => ({
			op: "slugNestPlace",
			actor: t,
			args: { floor: e }
		})));
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team === "traitor") return ft(e, "slugNest", n.room) ? U(e, t, "summonSlugs", "games.betrayal3.summonSlugs", [{
			op: "slugSummon",
			actor: t,
			id: n.room,
			n: 2
		}]) : [];
		if (q(e, t, [
			"kitchen",
			"diningRoom",
			"undergroundLake",
			"larder",
			"laboratory",
			"gymnasium"
		]) && Y(e, "salt") < 5) for (let n of ["knowledge", "speed"]) {
			let i = U(e, t, "findSalt", "games.betrayal3.findSalt", [W(t, "slugSaltResult", n)], n, "trait");
			r.push(...i);
		}
		ft(e, "slugNest", n.room) && r.push(...U(e, t, "destroyNest", "games.betrayal3.destroyNest", [W(t, "slugNestRoll", "speed")]));
		for (let i of e.tokens.filter((e) => e.kind === "salt" && e.room === n.room && !e.flags.corpse)) r.push(N(`salt-${i.id}`, "games.betrayal3.pickUpSalt", [{
			op: "slugTakeSalt",
			actor: t,
			id: i.id
		}], i.id, "token"));
		return r;
	},
	handle(e, t) {
		if (t.op === "hauntStartMonsters") return H(e).flags.slugStage = "move", j(e, [...Un(e).filter((e) => e.op !== "hauntMonsterEnd"), {
			op: "slugAttackStage",
			actor: t.actor
		}]), !0;
		let n = e.monsters.find((e) => e.id === t.actor);
		if (t.op === "monsterBegin" && n && (n.flags.skipTurn = n.stunned), t.op === "monsterAct" && n) {
			if (n.dead || n.stunned || n.flags.skipTurn === !0) return !0;
			let t = H(e).flags.slugStage === "move" ? Q(e, n).filter((e) => !e.id.startsWith("attack-")) : [...n.flags.attacked === !0 ? [] : O(e).filter((e) => e.room === n.room).map((e) => N(`attack-${e.rid}`, "games.betrayal3.attackSanity", [{
				op: "monsterAttack",
				actor: n.id,
				target: e.rid
			}], e.rid, "player")), N("finish", "games.betrayal3.finishMonster", [{
				op: "monsterFinish",
				actor: n.id
			}])];
			return H(e).flags.monsterActive = n.id, M(e, n.controller, "games.betrayal3.monsterAction", t), !0;
		}
		if (t.op === "roll" && n?.kind === "slug" && t.args?.attack === !0 && t.args.defense !== !0 && (t.args.bonus = z(t.args, "bonus") + e.monsters.filter((e) => e.kind === "slug" && e.id !== n.id && !e.dead && e.room === n.room).length), t.op === "combatResult" && n?.kind === "slug") {
			if (z(t.args, "attackTotal") > z(t.args, "total")) {
				let n = E(e, t.target);
				n.team = "traitor", n.revealed = !0, n.secret.mindControlled = !0;
			}
			for (let t of e.monsters.filter((e) => e.kind === "slug" && e.room === n.room)) t.dead = !0;
			return !0;
		}
		switch (t.op) {
			case "slugNestPlace": return M(e, t.actor, "games.betrayal3.chooseNestRoom", kn(e, t.args.floor).map((e) => N(e, "games.betrayal3.placeToken", [{
				op: "slugMakeNest",
				actor: t.actor,
				id: e
			}], e, "room"))), !0;
			case "slugMakeNest": return L(e, "slugNest", t.id), !0;
			case "slugSummon":
				for (let n = 0; n < (t.n ?? 1); n++) J(e, "slug", t.id, B(3, 4, 3, 5), {
					attack: "sanity",
					damage: "mental",
					death: "kill"
				});
				return !0;
			case "slugSaltResult": {
				let n = z(t.args, "total");
				if (n >= 5) {
					let n = L(e, "salt", null, t.actor);
					e.tokens.find((e) => e.id === n).flags = {
						tradable: !0,
						heroesOnly: !0
					};
				} else n <= 1 && j(e, [{
					op: "slugSummon",
					actor: t.actor,
					id: E(e, t.actor).room
				}]);
				return !0;
			}
			case "slugTakeSalt": {
				let n = e.tokens.find((e) => e.id === t.id);
				return n.room = null, n.holder = t.actor, !0;
			}
			case "slugNestRoll": {
				let n = e.tokens.filter((e) => e.kind === "salt" && e.holder === t.actor).length;
				return M(e, t.actor, "games.betrayal3.chooseSaltSpend", Array.from({ length: n + 1 }, (e, n) => {
					let r = z(t.args, "total") + 2 * n, i = N(`salt-${n}`, "games.betrayal3.spendSalt", [{
						op: "slugNestResult",
						actor: t.actor,
						n,
						args: { total: r }
					}], void 0, "action", n);
					return i.params = {
						n,
						total: r
					}, i;
				})), !0;
			}
			case "slugNestResult": {
				let n = e.tokens.filter((e) => e.kind === "salt" && e.holder === t.actor).slice(0, t.n);
				e.tokens = e.tokens.filter((e) => !n.includes(e));
				let r = z(t.args, "total"), i = E(e, t.actor).room;
				return r >= 9 ? (e.tokens = e.tokens.filter((e) => e.kind !== "slugNest" || e.room !== i), e.tokens.some((e) => e.kind === "slugNest") || X(e)) : r <= 4 && j(e, [{
					op: "slugSummon",
					actor: t.actor,
					id: i
				}]), !0;
			}
			case "slugAttackStage": return H(e).flags.slugStage = "attack", j(e, [...e.monsters.filter((e) => !e.dead && e.flags.skipTurn !== !0).map((e) => ({
				op: "monsterAct",
				actor: e.id
			})), {
				op: "hauntMonsterEnd",
				actor: t.actor
			}]), !0;
			default: return !1;
		}
	},
	filterActions(e, t, n) {
		return E(e, t).team === "traitor" ? n.filter((t) => !(t.id.startsWith("loot-") && e.tokens.find((e) => e.id === t.target)?.kind === "salt")) : n;
	},
	check: Z
};
//#endregion
//#region src/game/haunts/peace.ts
function oi(e, t) {
	return J(e, "peaceGhost", t, B(3, 3, 3, 4), { flags: {
		ai: "manual",
		noAttack: !0,
		untargetable: !0
	} });
}
var si = {
	setup(e) {
		H(e).monsterAfter = H(e).traitor;
		for (let t of e.rooms.filter((e) => !e.condition && g(e.tile).symbol?.startsWith("event"))) oi(e, b(t)[0]);
	},
	actions(e, t) {
		let n = E(e, t), r = e.monsters.filter((e) => !e.dead && e.room === n.room), i = [];
		return r.length && (n.team === "traitor" ? i.push(...U(e, t, "consumeGhost", "games.betrayal3.consumeGhost", [W(t, "peaceConsumeResult", "knowledge")])) : i.push(...U(e, t, "reconcileGhost", "games.betrayal3.reconcileGhost", [W(t, "peaceReconcileResult", "sanity")]))), i;
	},
	handle(e, t) {
		if (t.op === "roomCards" && g(t.id).symbol?.startsWith("event")) return oi(e, E(e, t.actor).room), !0;
		if (t.op === "characterDamage" && t.actor === H(e).traitor && (t.n ?? 0) > 0 && t.target) return j(e, [{
			op: "peaceFlee",
			actor: t.actor,
			n: t.n
		}, {
			op: "peaceGain",
			actor: t.actor
		}]), !0;
		if (t.op === "combatResult" && E(e, t.actor)?.team === "hero" && t.target === H(e).traitor && z(t.args, "attackTotal") > z(t.args, "total") && E(e, t.target).cards.length) return M(e, t.actor, "games.betrayal3.stealOrDamage", [N("damage", "games.betrayal3.dealDamage", [{
			op: "characterDamage",
			actor: t.target,
			target: t.actor,
			n: z(t.args, "attackTotal") - z(t.args, "total"),
			damage: t.damage
		}]), ...E(e, t.target).cards.map((e) => N(e, "games.betrayal3.stealCard", [{
			op: "peaceSteal",
			actor: t.actor,
			target: t.target,
			id: e
		}], e, "card"))]), !0;
		switch (t.op) {
			case "peaceReconcileResult": {
				if (z(t.args, "total") < 5) return !0;
				let n = e.monsters.find((n) => !n.dead && n.room === E(e, t.actor).room);
				return n && (n.dead = !0, H(e).counters[`reconciled.${t.actor}`] = (H(e).counters[`reconciled.${t.actor}`] ?? 0) + 1), Object.entries(H(e).counters).filter(([e]) => e.startsWith("reconciled.")).reduce((e, [, t]) => e + t, 0) >= $(e, [
					4,
					5,
					6,
					8
				]) && X(e), !0;
			}
			case "peaceConsumeResult": {
				let n = E(e, t.actor), r = e.monsters.filter((e) => !e.dead && e.room === n.room);
				return z(t.args, "total") >= 4 ? (r[0] && (r[0].dead = !0), P(e, n.rid, "sanity", 1)) : j(e, r.map((e) => ({
					op: "peaceMoveGhost",
					actor: t.actor,
					target: e.id
				}))), !0;
			}
			case "peaceMoveGhost": {
				let n = e.monsters.find((e) => e.id === t.target);
				return M(e, t.actor, "games.betrayal3.chooseRoom", Re(e, n.room, !0).map((e) => N(e, "games.betrayal3.moveTo", [{
					op: "relocate",
					actor: n.id,
					id: e
				}], e, "room"))), !0;
			}
			case "peaceFlee": return (t.n ?? 0) > 0 && M(e, t.actor, "games.betrayal3.chooseRoom", x(e, E(e, t.actor).room).map((e) => N(e, "games.betrayal3.moveTo", [{
				op: "relocate",
				actor: t.actor,
				id: e
			}, {
				...t,
				n: t.n - 1
			}], e, "room"))), !0;
			case "peaceGain": return M(e, t.actor, "games.betrayal3.chooseGain", ["might", "knowledge"].map((e) => N(e, "games.betrayal3.raiseTrait", [{
				op: "gain",
				actor: t.actor,
				trait: e,
				n: 1
			}], e, "trait"))), !0;
			case "peaceSteal": return at(e, t.target, t.actor, t.id), !0;
			case "hauntDeath": return E(e, t.actor).team === "hero" && oi(e, E(e, t.actor).room), !0;
			case "hauntTurnEnd": return t.actor === H(e).traitor && E(e, t.actor).traits.sanity === 7 && zn(e), !0;
			case "hauntMonsterEnd": return j(e, O(e).filter((t) => e.monsters.some((e) => !e.dead && e.room === t.room)).map((e) => G(e.rid, 2, "general"))), !0;
			default: return !1;
		}
	},
	check: Z
}, ci = {
	setup(e) {
		let t = H(e).traitor, n = E(e, t), r = e.explorers.find((e) => e.cards.includes("armor"));
		r && I(e, r.rid, "armor"), rt(e, t), n.room = "entranceHall", H(e).monsterAfter = t, H(e).track = $(e, [
			2,
			3,
			4,
			5
		]);
		for (let t = 0; t < $(e, [
			0,
			1,
			1,
			2
		]); t++) i("entranceHall");
		for (let t of O(e)) {
			i(t.room);
			let n = L(e, "dna", null, t.rid);
			e.tokens.find((e) => e.id === n).flags.body = t.character;
		}
		function i(t) {
			J(e, "securityRobot", t, B(6, 5, 5, 4), { death: "kill" });
		}
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team === "traitor") {
			for (let i of O(e).filter((t) => t.room === n.room && e.tokens.some((e) => e.kind === "dna" && e.flags.body === t.character))) r.push(...U(e, t, "metamorph", "games.betrayal3.metamorphSubject", [{
				op: "bodySwap",
				actor: t,
				target: i.rid
			}], i.rid, "player"));
			An(e, t, "omen") && e.tokens.some((e) => e.kind === "dna" && e.flags.body === n.character) && r.push(...U(e, t, "uploadDna", "games.betrayal3.uploadDna", [{
				op: "bodyUpload",
				actor: t
			}]));
		} else {
			if (!e.attacked && q(e, t, [
				"observatory",
				"gameRoom",
				"laboratory",
				"panicRoom"
			])) for (let i of e.monsters.filter((t) => !t.dead && y(e, t.room).floor === y(e, n.room).floor)) r.push(N(`circuits-${i.id}`, "games.betrayal3.messCircuits", [{
				op: "attack",
				actor: t,
				target: i.id,
				trait: "knowledge",
				damage: "mental"
			}], i.id, "token"));
			n.room === "entranceHall" && e.monsters.every((e) => e.dead) && r.push(...U(e, t, "escapeRobotHouse", "games.betrayal3.attemptEscape", [W(t, "bodyEscapeResult", "speed")]));
		}
		return r;
	},
	handle(e, t) {
		if (t.op === "death" && t.actor === H(e).traitor) {
			let n = E(e, t.actor);
			return (t.args?.forced === !0 || w.some((e) => n.traits[e] < 0)) && (rt(e, n.rid), M(e, n.rid, "games.betrayal3.chooseRoom", Mn.filter((t) => e.rooms.some((e) => e.id === t)).map((e) => N(e, "games.betrayal3.moveTo", [{
				op: "relocate",
				actor: n.rid,
				id: e
			}], e, "room")))), !0;
		}
		let n = e.monsters.find((e) => e.id === t.actor);
		if (t.op === "hauntStartMonsters") for (let t of e.monsters) delete t.flags.pursuing;
		if (t.op === "monsterBegin" && n && !n.dead && !n.stunned && t.args?.assigned !== !0) {
			let r = O(e).filter((t) => Number.isFinite(C(e, n.room, t.room, !0))), i = r.filter((t) => !e.monsters.some((e) => e.flags.pursuing === t.rid));
			if (M(e, n.controller, "games.betrayal3.chooseRobotTarget", (i.length ? i : r).map((e) => N(e.rid, "games.betrayal3.pursueHero", [{
				op: "bodyRobotTarget",
				actor: n.id,
				target: e.rid
			}, {
				...t,
				args: { assigned: !0 }
			}], e.rid, "player"))), e.prompt) return !0;
		}
		if (t.op === "monsterAct" && n && !n.dead && !n.stunned) {
			let t = E(e, String(n.flags.pursuing ?? "")), r = Q(e, n).filter((r) => !r.id.startsWith("move-") || !t || t.dead || C(e, r.target, t.room, !0) < C(e, n.room, t.room, !0));
			return H(e).flags.monsterActive = n.id, M(e, n.controller, "games.betrayal3.monsterAction", r), !0;
		}
		switch ((t.op === "attack" || t.op === "monsterAttack") && n && (t.args = {
			...t.args,
			noCounter: !0
		}), t.op) {
			case "bodySwap": {
				let n = E(e, t.actor), r = E(e, t.target);
				[n.character, r.character] = [r.character, n.character], [n.traits, r.traits] = [r.traits, n.traits], [n.room, r.room] = [r.room, n.room];
				for (let t of e.tokens.filter((e) => e.kind === "dna")) t.holder = e.explorers.find((e) => e.character === t.flags.body).rid;
				return F(e, n.rid), e.movement = 0, e.endRequested = !0, !0;
			}
			case "bodyUpload": return e.tokens = e.tokens.filter((n) => n.kind !== "dna" || n.flags.body !== E(e, t.actor).character), e.tokens.some((e) => e.kind === "dna") || (H(e).flags.allDnaUploaded = !0), !0;
			case "bodyEscapeResult": return z(t.args, "total") >= 4 && --H(e).track <= 0 && X(e), !0;
			case "bodyRobotTarget": return e.monsters.find((e) => e.id === t.actor).flags.pursuing = t.target, !0;
			default: return !1;
		}
	},
	after(e) {
		for (let t of O(e).filter((t) => e.tokens.some((e) => e.kind === "dna" && e.flags.body === t.character))) for (let e of w) t.traits[e] = Math.max(0, t.traits[e]);
	},
	check(e) {
		if (H(e).flags.allDnaUploaded === !0) {
			zn(e);
			return;
		}
		Z(e);
	}
}, li = {
	setup(e) {
		let t = H(e).traitor;
		F(e, t), H(e).monsterAfter = t, H(e).track = $(e, [
			2,
			3,
			4,
			4
		]), j(e, [{
			op: "placeRoom",
			actor: t,
			id: "kitchen",
			args: {
				floor: "G",
				farthestFrom: "entranceHall"
			}
		}, {
			op: "soireePlace",
			actor: t,
			n: e.players.length,
			args: {
				initial: !0,
				placed: []
			}
		}]);
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team !== "hero") return r;
		if (n.secret.ringFailed !== !0 && r.push(...en({
			...e,
			attacked: !1
		}, t).filter((e) => e.tasks.some((e) => e.op === "attack" && e.id === "ring"))), An(e, t, "event")) for (let n of ["knowledge", "sanity"]) r.push(...U(e, t, "callOffParty", "games.betrayal3.callOffParty", [W(t, "soireeCancelResult", n)], n, "trait"));
		return r;
	},
	filterActions(e, t, n) {
		return E(e, t).team === "hero" ? n.filter((e) => !e.tasks.some((e) => e.op === "attack" && e.id === "ring")) : n;
	},
	handle(e, t) {
		if (t.op === "death" && t.actor === H(e).traitor && (t.args?.forced === !0 || w.some((n) => E(e, t.actor).traits[n] < 0))) {
			let n = E(e, t.actor);
			F(e, n.rid);
			let r = e.explorers.find((e) => e.cards.includes("ring"));
			return r && r.rid !== t.target && E(e, t.target ?? "") && at(e, r.rid, t.target, "ring"), j(e, [{
				op: "relocate",
				actor: n.rid,
				id: "kitchen"
			}]), !0;
		}
		switch (t.op === "combatResult" && t.id === "ring" && E(e, t.actor)?.team === "hero" && z(t.args, "attackTotal") < z(t.args, "total") && (E(e, t.actor).secret.ringFailed = !0), t.op) {
			case "hauntTurnStart": return E(e, t.actor).secret.ringFailed = !1, !0;
			case "soireePlace": {
				if ((t.n ?? 0) <= 0) return !0;
				let n = t.args?.placed ?? [], r = e.rooms.filter((e) => !e.condition && g(e.tile).symbol?.startsWith("event") && !n.includes(e.id)).flatMap(b);
				return !r.length && t.args?.initial !== !0 || M(e, t.actor, "games.betrayal3.chooseNeighborRoom", (r.length ? r : ["entranceHall"]).map((e) => N(e, "games.betrayal3.placeToken", [{
					op: "soireeCreate",
					actor: t.actor,
					id: e
				}, {
					...t,
					n: t.n - 1,
					args: {
						...t.args,
						placed: [...n, v(e)]
					}
				}], e, "room"))), !0;
			}
			case "soireeCreate": return J(e, "neighbor", t.id, B(5, 2, 3, 5), { death: "kill" }), !0;
			case "soireeCancelResult": return z(t.args, "total") >= 6 && (H(e).track = Math.max(0, H(e).track - 1)), !0;
			case "hauntMonsterEnd": return j(e, [{
				op: "soireePlace",
				actor: H(e).traitor,
				n: H(e).track,
				args: { placed: [] }
			}]), !0;
			case "hauntTurnEnd": return E(e, t.actor).team === "hero" && e.monsters.every((e) => e.dead) && X(e), !0;
			default: return !1;
		}
	},
	check: Z
}, ui = {
	setup(e) {
		let t = E(e, H(e).traitor);
		for (let n of [...t.cards]) I(e, t.rid, n);
		t.dead = !0, t.secret.bodyRemoved = !0, H(e).flags.deadTurns = [t.rid], H(e).track = $(e, [
			5,
			4,
			4,
			3
		]), J(e, "giantWasp", t.room, B(6, 5, 5, 5));
		for (let n = 0; n < $(e, [
			0,
			2,
			3,
			5
		]); n++) J(e, "workerWasp", t.room, B(3, 5, 4, 1), { death: "kill" });
		j(e, [{
			op: "hivePlaceEggs",
			actor: t.rid,
			n: 5
		}]);
	},
	actions(e, t) {
		let n = E(e, t);
		if (n.team !== "hero") return [];
		let r = e.tokens.filter((e) => e.kind === "waspEgg" && e.room === n.room && !e.flags.corpse).map((e) => N(`egg-${e.id}`, "games.betrayal3.pickUpEgg", [{
			op: "hiveTakeEgg",
			actor: t,
			id: e.id
		}], e.id, "token"));
		return e.tokens.some((e) => e.kind === "waspEgg" && e.holder === t) && r.push(...U(e, t, "destroyEggs", "games.betrayal3.destroyEggs", [W(t, "hiveDestroyResult", "knowledge")])), r;
	},
	handle(e, t) {
		if (t.op === "beginTurn" && t.actor === H(e).traitor) {
			e.turn = t.actor, e.turnNumber++, e.endRequested = !1;
			for (let t of e.monsters) t.flags.specialUsed = !1;
			return j(e, [
				...Un(e, e.monsters.filter((e) => e.kind === "workerWasp").map((e) => e.id)).filter((e) => e.op !== "hauntMonsterEnd"),
				...Un(e, e.monsters.filter((e) => e.kind === "giantWasp").map((e) => e.id)).filter((e) => e.op !== "hauntMonsterEnd"),
				{
					op: "hiveTurnEnd",
					actor: t.actor
				},
				{
					op: "nextTurn",
					actor: t.actor
				}
			]), !0;
		}
		if (t.op === "roll" && t.args?.attack === !0 && t.args.defense !== !0 && e.monsters.find((e) => e.id === t.args.attackTarget)?.kind === "giantWasp" && (t.args.bonus = z(t.args, "bonus") - e.tokens.filter((e) => e.kind === "waspEgg").length), t.op === "combatResult" && e.monsters.find((e) => e.id === t.target)?.kind === "giantWasp" && z(t.args, "attackTotal") > z(t.args, "total")) return X(e), !0;
		if (t.op === "monsterAct") {
			let n = e.monsters.find((e) => e.id === t.actor);
			if (n.dead || n.stunned) return !0;
			let r = Q(e, n);
			if (n.flags.specialUsed !== !0) {
				if (n.kind === "workerWasp") for (let t of O(e).filter((e) => e.room === n.room)) r.push(N(`defend-${t.rid}`, "games.betrayal3.defendSwarm", [{
					op: "hiveDefend",
					actor: n.id,
					target: t.rid
				}], t.rid, "player"));
				else if ((H(e).counters.destroyedEggs ?? 0) > 0) for (let t of e.explorers.filter((e) => e.dead && e.secret.bodyRemoved !== !0 && e.room === n.room)) r.push(N(`lay-${t.rid}`, "games.betrayal3.layEgg", [{
					op: "hiveLay",
					actor: n.id,
					target: t.rid
				}, {
					op: "monsterAct",
					actor: n.id
				}], t.rid, "player"));
			}
			return H(e).flags.monsterActive = n.id, M(e, n.controller, "games.betrayal3.monsterAction", r), !0;
		}
		switch (t.op) {
			case "hivePlaceEggs": {
				if ((t.n ?? 0) <= 0) return !0;
				let n = e.rooms.filter((t) => t.floor !== "B" && !e.tokens.some((e) => e.room && v(e.room) === t.id && e.kind === "waspEgg"));
				if (!n.length) {
					let n = e.rooms.filter((e) => e.floor === "G").length <= e.rooms.filter((e) => e.floor === "U").length ? "G" : "U";
					return j(e, [{
						op: "hauntEnsureRooms",
						actor: t.actor,
						n: e.rooms.filter((e) => e.floor === n).length + 1,
						args: { floor: n }
					}, t]), !0;
				}
				return M(e, t.actor, "games.betrayal3.chooseEggRoom", n.flatMap(b).map((e) => N(e, "games.betrayal3.placeToken", [{
					op: "hiveMakeEgg",
					actor: t.actor,
					id: e
				}, {
					...t,
					n: t.n - 1
				}], e, "room"))), !0;
			}
			case "hiveMakeEgg": {
				let n = L(e, "waspEgg", t.id);
				return e.tokens.find((e) => e.id === n).flags = {
					tradable: !0,
					heroesOnly: !0
				}, !0;
			}
			case "hiveTakeEgg": {
				let n = e.tokens.find((e) => e.id === t.id);
				return n.holder = t.actor, n.room = null, !0;
			}
			case "hiveDestroyResult":
				if (z(t.args, "total") >= 5) {
					let n = e.tokens.filter((e) => e.kind === "waspEgg" && e.holder === t.actor);
					H(e).counters.destroyedEggs = (H(e).counters.destroyedEggs ?? 0) + n.length, e.tokens = e.tokens.filter((e) => !n.includes(e));
				} else J(e, "workerWasp", E(e, t.actor).room, B(3, 5, 4, 1), { death: "kill" });
				return !0;
			case "hiveDefend": return e.monsters.find((e) => e.id === t.actor).dead = !0, j(e, [K(t.target, 1, "physical")]), !0;
			case "hiveLay": {
				let n = E(e, t.target), r = e.monsters.find((e) => e.id === t.actor);
				r.flags.specialUsed = !0, H(e).counters.destroyedEggs--, n.secret.bodyRemoved = !0;
				for (let t of [...n.cards]) I(e, n.rid, t);
				return j(e, [{
					op: "hiveMakeEgg",
					actor: r.id,
					id: n.room
				}]), !0;
			}
			case "hiveTurnEnd":
				for (let t of e.tokens.filter((e) => e.kind === "waspEgg")) J(e, "workerWasp", t.room ?? E(e, t.holder).room, B(3, 5, 4, 1), { death: "kill" });
				return e.tokens.some((e) => e.kind === "waspEgg") && --H(e).track <= 0 && zn(e), !0;
			default: return !1;
		}
	},
	check: Z
}, di = {
	setup(e) {
		let t = H(e).traitor;
		F(e, t), H(e).monsterAfter = t;
		for (let n of O(e)) {
			let r = Me(n.character), i = Object.fromEntries(w.map((e) => [e, r.tracks[e][r.start[e]]]));
			J(e, "evilTwin", E(e, t).room, i, { flags: {
				ai: "manual",
				reflection: n.rid
			} });
		}
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team === "traitor") for (let i of e.monsters.filter((e) => !e.dead && e.stunned && e.room === n.room)) r.push(...U(e, t, "protectFamily", "games.betrayal3.protectFamily", [{
			op: "twinAwaken",
			actor: t,
			target: i.id
		}], i.id, "token"));
		return n.team === "hero" && q(e, t, ["tower", "ritualRoom"]) && r.push(...U(e, t, "scryTwin", "games.betrayal3.scryTwin", [W(t, "twinScryResult", "knowledge")])), r;
	},
	handle(e, t) {
		if (t.op === "hauntStartMonsters") return j(e, [...e.monsters.filter((e) => !e.dead).map((e) => ({
			op: "twinBegin",
			actor: e.id
		})), {
			op: "hauntMonsterEnd",
			actor: t.actor
		}]), !0;
		if (t.op === "monsterAct") {
			let n = e.monsters.find((e) => e.id === t.actor);
			if (n.dead || n.stunned) return !0;
			let r = Q(e, n).filter((e) => !e.id.startsWith("attack-"));
			if (n.flags.attacked !== !0) for (let t of O(e).filter((e) => e.room === n.room)) for (let e of w) {
				let i = N(`attack-${t.rid}-${e}`, "games.betrayal3.attackTraitNamed", [{
					op: "twinAttack",
					actor: n.id,
					target: t.rid,
					trait: e
				}], t.rid, "player");
				i.params = { trait: e }, r.push(i);
			}
			return H(e).flags.monsterActive = n.id, M(e, n.controller, "games.betrayal3.monsterAction", r), !0;
		}
		if (t.op === "characterDamage") {
			let n = e.monsters.find((e) => e.id === t.actor), r = E(e, t.target ?? "");
			if (n && r?.team === "hero" && (r.rid === n.flags.reflection || r.cards.includes("mask")) && (t.n ?? 0) > 0) return n.dead = !0, !0;
		}
		if (t.op === "combatResult" && t.trait === "might" && E(e, t.actor)?.team === "hero" && t.target === H(e).traitor && E(e, t.target).cards.includes("mask") && z(t.args, "attackTotal") > z(t.args, "total")) return M(e, t.actor, "games.betrayal3.stealOrDamage", [N("steal", "games.betrayal3.stealMask", [{
			op: "twinStealMask",
			actor: t.actor,
			target: t.target
		}]), N("damage", "games.betrayal3.dealDamage", [{
			op: "characterDamage",
			actor: t.target,
			target: t.actor,
			n: z(t.args, "attackTotal") - z(t.args, "total"),
			damage: t.damage
		}])]), !0;
		switch (t.op) {
			case "twinBegin": {
				let n = e.monsters.find((e) => e.id === t.actor);
				return n.dead ? !0 : n.stunned ? (n.stunned = !1, !0) : (n.flags.movement = n.traits.speed, n.flags.attacked = !1, j(e, [{
					op: "monsterAct",
					actor: n.id
				}]), !0);
			}
			case "twinAttack": {
				let n = e.monsters.find((e) => e.id === t.actor);
				return n.flags.attacked = !0, j(e, [{
					...t,
					op: "attack",
					damage: t.trait === "might" || t.trait === "speed" ? "physical" : "mental"
				}, {
					op: "monsterAct",
					actor: n.id
				}]), !0;
			}
			case "twinAwaken": return e.monsters.find((e) => e.id === t.target).stunned = !1, !0;
			case "twinScryResult": return z(t.args, "total") >= 5 && M(e, t.actor, "games.betrayal3.chooseTwin", e.monsters.filter((e) => !e.dead).map((e) => N(e.id, "games.betrayal3.stunTwin", [{
				op: "twinStun",
				actor: t.actor,
				target: e.id
			}], e.id, "token"))), !0;
			case "twinStun": return e.monsters.find((e) => e.id === t.target).stunned = !0, !0;
			case "twinStealMask": return at(e, t.target, t.actor, "mask"), !0;
			default: return !1;
		}
	},
	check(e) {
		e.monsters.length && e.monsters.every((e) => e.dead) ? X(e) : Z(e);
	}
}, fi = {
	setup(e) {
		let t = H(e).traitor, n = E(e, t).room;
		H(e).monsterAfter = t, L(e, "machineTrap", n), L(e, "generator", n), J(e, "theHouse", n, B(7, 0, 5, 5), {
			death: "immune",
			flags: {
				ai: "manual",
				untargetable: !0
			}
		}), j(e, [{
			op: "machinePlace",
			actor: t,
			n: $(e, [
				3,
				3,
				4,
				5
			]) - 1
		}]);
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team === "traitor") return e.tokens.some((e) => e.kind === "generator" && e.room === n.room && e.value === 0) && r.push(...U(e, t, "reactivateGenerator", "games.betrayal3.reactivateGenerator", [W(t, "machineReactivateResult", "knowledge")])), r;
		for (let i of e.tokens.filter((t) => t.kind === "machineTrap" && (t.room === n.room || x(e, n.room).includes(t.room)))) r.push(...U(e, t, "disableTrap", "games.betrayal3.disableTrap", [W(t, "machineDisableResult", "speed", i.room === n.room ? 2 : 0, { token: i.id })], i.id, "token"));
		if (q(e, t, [
			"panicRoom",
			"vault",
			"kitchen",
			"laboratory",
			"gameRoom"
		]) && !ft(e, "sabotaged", n.room)) for (let n of ["knowledge", "might"]) r.push(...U(e, t, "sabotageElectronics", "games.betrayal3.sabotageElectronics", [W(t, "machineSabotageResult", n)], n, "trait"));
		return e.tokens.some((e) => e.kind === "generator" && e.room === n.room && e.value === 1) && r.push(...U(e, t, "overloadGenerator", "games.betrayal3.overloadGenerator", [{
			op: "roll",
			actor: t,
			n: H(e).track,
			args: { context: "overloadGenerator" },
			then: [{
				op: "machineOverloadResult",
				actor: t
			}]
		}])), r;
	},
	handle(e, t) {
		if (t.op === "hauntStartMonsters") {
			let t = e.monsters[0];
			return t.flags.attacked = !1, t.flags.possessed = !1, t.flags.twisted = !1, j(e, [{
				op: "monsterAct",
				actor: t.id
			}]), !0;
		}
		if (t.op === "monsterAct") {
			let n = e.monsters.find((e) => e.id === t.actor), r = [N("finish", "games.betrayal3.finishMonster", [{
				op: "monsterFinish",
				actor: n.id
			}])], i = e.tokens.filter((e) => e.kind === "generator"), a = i.filter((e) => e.value === 1).map((e) => e.room);
			if (n.flags.attacked !== !0) for (let t of O(e).filter((t) => a.some((n) => t.room === n || x(e, n).includes(t.room)))) r.push(N(`attack-${t.rid}`, "games.betrayal3.attackUnarmed", [{
				op: "machineAttack",
				actor: n.id,
				target: t.rid
			}, {
				op: "monsterAct",
				actor: n.id
			}], t.rid, "player"));
			if (n.flags.possessed !== !0 && e.tokens.filter((e) => e.kind === "machineTrap").length < 5) for (let t of e.rooms.flatMap(b).filter((t) => !O(e).some((e) => e.room === t) && !ft(e, "machineTrap", t) && !i.some((n) => n.room === t || x(e, n.room).includes(t)))) r.push(N(`trap-${t}`, "games.betrayal3.possessElectronics", [{
				op: "machinePossess",
				actor: n.id,
				id: t
			}, {
				op: "monsterAct",
				actor: n.id
			}], t, "room"));
			return n.flags.twisted !== !0 && r.push(N("twist", "games.betrayal3.twistHallways", [{
				op: "roll",
				actor: n.id,
				n: 2,
				args: { context: "twistHallways" },
				then: [{
					op: "machineTwistResult",
					actor: n.id
				}]
			}, {
				op: "monsterAct",
				actor: n.id
			}])), H(e).flags.monsterActive = n.id, M(e, n.controller, "games.betrayal3.monsterAction", r), !0;
		}
		switch (t.op) {
			case "machinePlace": {
				if ((t.n ?? 0) <= 0) return !0;
				let n = e.rooms.filter((t) => !e.tokens.some((e) => e.kind === "generator" && e.room === t.id)), r = n.filter((e) => !e.condition && [
					"item",
					"item2",
					"omen"
				].includes(g(e.tile).symbol ?? "")), i = r.length ? r : n.filter((e) => Mn.includes(e.id));
				return M(e, t.actor, "games.betrayal3.chooseGeneratorRoom", i.flatMap(b).map((e) => N(e, "games.betrayal3.placeToken", [{
					op: "machineMakeGenerator",
					actor: t.actor,
					id: e
				}, {
					...t,
					n: t.n - 1
				}], e, "room"))), !0;
			}
			case "machineMakeGenerator": return L(e, "generator", t.id), !0;
			case "machineReactivateResult":
				if (z(t.args, "total") >= 4) for (let n of e.tokens.filter((n) => n.kind === "generator" && n.room === E(e, t.actor).room)) n.value = 1;
				return !0;
			case "machineDisableResult": return z(t.args, "total") >= 6 && (e.tokens = e.tokens.filter((e) => e.id !== t.args?.token), H(e).track++), !0;
			case "machineSabotageResult": return z(t.args, "total") >= 5 && (L(e, "sabotaged", E(e, t.actor).room), H(e).track++), !0;
			case "machineOverloadResult":
				if (z(t.args, "total") >= 5) {
					for (let n of e.tokens.filter((n) => n.kind === "generator" && n.room === E(e, t.actor).room)) n.value = 0;
					e.tokens.filter((e) => e.kind === "generator").every((e) => e.value === 0) && X(e);
				} else e.endRequested = !0;
				return !0;
			case "machineAttack": return e.monsters[0].flags.attacked = !0, j(e, [{
				...t,
				op: "attack",
				trait: "might",
				damage: "physical"
			}]), !0;
			case "machinePossess": return e.monsters[0].flags.possessed = !0, L(e, "machineTrap", t.id), !0;
			case "machineTwistResult": return e.monsters[0].flags.twisted = !0, M(e, e.monsters[0].controller, "games.betrayal3.chooseExplorer", D(e).map((e) => N(e.rid, "games.betrayal3.moveExplorer", [{
				op: "machineTwistStart",
				actor: t.actor,
				target: e.rid,
				n: z(t.args, "total")
			}], e.rid, "player"))), !0;
			case "machineTwistStart": return H(e).flags.hallwayActor = t.target, H(e).flags.hallwayStopped = !1, j(e, [{
				...t,
				op: "machineHallwayMove"
			}, {
				op: "machineTwistEnd",
				actor: t.actor
			}]), !0;
			case "machineHallwayMove": return (t.n ?? 0) > 0 && !E(e, t.target).dead && H(e).flags.hallwayStopped !== !0 && M(e, e.monsters[0].controller, "games.betrayal3.chooseRoom", [...x(e, E(e, t.target).room).map((e) => N(e, "games.betrayal3.moveTo", [{
				op: "relocate",
				actor: t.target,
				id: e
			}, {
				...t,
				n: t.n - 1
			}], e, "room")), N("stop", "games.betrayal3.stopMoving", [])]), !0;
			case "machineTwistEnd": return delete H(e).flags.hallwayActor, delete H(e).flags.hallwayStopped, !0;
			case "hauntEnter": return E(e, t.actor)?.team === "hero" && ft(e, "machineTrap", E(e, t.actor).room) && (H(e).flags.hallwayActor === t.actor && (H(e).flags.hallwayStopped = !0), j(e, [K(t.actor, 2, "general")])), !0;
			default: return !1;
		}
	},
	check: Z
}, pi = {
	library: "knowledge",
	larder: "might",
	gymnasium: "speed",
	chapel: "sanity"
};
function mi(e) {
	return e.tokens.filter((e) => e.kind === "dogFood").length + (H(e).counters.dogFood ?? 0);
}
var hi = {
	setup(e) {
		let t = H(e).traitor, n = E(e, t);
		F(e, t), H(e).monsterAfter = t;
		let r = e.explorers.find((e) => e.cards.includes("dog"));
		r && I(e, r.rid, "dog"), H(e).counters.dogFood = $(e, [
			0,
			1,
			1,
			2
		]), J(e, "demonicDog", n.room, B(4 + H(e).counters.dogFood, 4, 5, 4), { death: "immune" }), j(e, [{
			op: "placeRoom",
			actor: t,
			id: "larder",
			args: { floor: "B" }
		}]);
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team === "traitor") return q(e, t, Object.keys(pi)) ? U(e, t, "favoritePlaces", "games.betrayal3.favoritePlaces", [{
			op: "heal",
			actor: t
		}]) : [];
		let i = Object.keys(pi).find((n) => q(e, t, [n]));
		if (i && !ft(e, "exorcisedSpirit", n.room) && r.push(...U(e, t, "exorciseSpirit", "games.betrayal3.exorciseSpirit", [W(t, "dogExorciseResult", pi[i])])), q(e, t, ["larder"]) && mi(e) < 5 && r.push(...U(e, t, "stealFood", "games.betrayal3.stealFood", [W(t, "dogFoodResult", "speed")])), !e.attacked) for (let i of e.monsters.filter((e) => e.room === n.room)) r.push(N(`sanity-${i.id}`, "games.betrayal3.attackSanity", [{
			op: "attack",
			actor: t,
			target: i.id,
			trait: "sanity",
			damage: "mental"
		}], i.id, "player"));
		return r;
	},
	handle(e, t) {
		if (t.op === "monsterBegin" && (e.monsters[0].flags.ate = !1), t.op === "monsterAct") {
			let t = e.monsters[0], n = Q(e, t);
			return t.flags.ate !== !0 && t.room === "larder" && mi(e) < 5 && n.push(N("eat", "games.betrayal3.grabBite", [{
				op: "dogEat",
				actor: t.id
			}, {
				op: "monsterAct",
				actor: t.id
			}])), H(e).flags.monsterActive = t.id, M(e, t.controller, "games.betrayal3.monsterAction", n), !0;
		}
		if (t.op === "attackResult" && e.monsters.some((e) => e.id === t.actor) && t.args?.foodOffered !== !0) {
			let n = e.tokens.find((e) => e.kind === "dogFood" && e.holder === t.target);
			if (n) return M(e, t.target, "games.betrayal3.offerDogFood", [N("feed", "games.betrayal3.feedDog", [{
				op: "dogFeed",
				actor: t.target,
				id: n.id
			}, {
				...t,
				args: {
					...t.args,
					total: z(t.args, "total") - 4,
					foodOffered: !0
				}
			}]), N("decline", "games.betrayal3.decline", [{
				...t,
				args: {
					...t.args,
					foodOffered: !0
				}
			}])]), !0;
		}
		if (t.op === "combatResult" && e.monsters.some((e) => e.id === t.target) && z(t.args, "attackTotal") > z(t.args, "total") && e.tokens.filter((e) => e.kind === "exorcisedSpirit").length >= $(e, [
			2,
			3,
			4,
			4
		])) return X(e), !0;
		switch (t.op) {
			case "dogExorciseResult": return z(t.args, "total") >= 4 && L(e, "exorcisedSpirit", E(e, t.actor).room), !0;
			case "dogFoodResult": return z(t.args, "total") >= 4 && mi(e) < 5 && L(e, "dogFood", null, t.actor), !0;
			case "dogFeed": return e.tokens = e.tokens.filter((e) => e.id !== t.id), H(e).counters.dogFood++, !0;
			case "dogEat": return e.monsters[0].flags.ate = !0, H(e).counters.dogFood++, !0;
			default: return !1;
		}
	},
	after(e) {
		e.monsters[0].traits.might = 4 + H(e).counters.dogFood;
	},
	check: Z
}, gi = {
	setup(e) {
		let t = H(e).traitor;
		H(e).monsterAfter = t, H(e).track = $(e, [
			6,
			7,
			8,
			9
		]);
		let n = e.explorers.find((e) => e.cards.includes("dog"));
		n && I(e, n.rid, "dog"), J(e, "werewolf", E(e, H(e).revealer).room, B(7, 4, 2, 3));
	},
	actions(e, t) {
		let n = E(e, t), r = e.monsters[0], i = [];
		if (n.team === "hero") S(e, n.room, r.room) || i.push(...U(e, t, "hideWolf", "games.betrayal3.hideWolf", [W(t, "wolfHideResult", "speed", +!!q(e, t, [
			"armory",
			"soundproofedRoom",
			"catacombs",
			"winterBedroom",
			"graveyard",
			"statuaryCorridor"
		]))])), r.room === n.room && i.push(...U(e, t, "charmWolf", "games.betrayal3.charmWolf", [W(t, "wolfCharmResult", "sanity", O(e).filter((e) => e.room === n.room && e.secret.hiddenFromWerewolf !== !0).length)]));
		else {
			for (let r of O(e)) r.room === n.room && r.secret.hiddenFromWerewolf === !0 && i.push(...U(e, t, "revealHidden", "games.betrayal3.revealHidden", [W(t, "wolfRevealResult", "sanity", 0, { target: r.rid })], r.rid, "player")), r.secret.hiddenFromWerewolf !== !0 && r.cards.length && S(e, n.room, r.room) && i.push(...U(e, t, "curseEnemies", "games.betrayal3.curseEnemies", [W(t, "wolfCurseResult", "sanity", 0, { target: r.rid })], r.rid, "player"));
			r.room === n.room && !r.stunned && x(e, r.room, !0).length && i.push(...U(e, t, "communeWolves", "games.betrayal3.communeWolves", [{
				op: "wolfCommune",
				actor: t
			}]));
		}
		return i;
	},
	handle(e, t) {
		switch (t.op === "hauntStartMonsters" && (H(e).counters.wolfJournalAt = e.journal.length), t.op === "hauntEnter" && E(e, t.actor) && (E(e, t.actor).secret.hiddenFromWerewolf = !1), t.op) {
			case "wolfHideResult": return z(t.args, "total") >= 5 && (E(e, t.actor).secret.hiddenFromWerewolf = !0), !0;
			case "wolfCharmResult": return z(t.args, "total") >= 8 ? e.monsters[0].stunned = !0 : z(t.args, "total") <= 4 && j(e, [G(t.actor, 1, "physical")]), !0;
			case "wolfRevealResult": return z(t.args, "total") >= 5 && (E(e, String(t.args.target)).secret.hiddenFromWerewolf = !1), !0;
			case "wolfCurseResult": {
				let n = String(t.args.target);
				return z(t.args, "total") >= 5 && M(e, n, "games.betrayal3.chooseCardToBury", E(e, n).cards.map((e) => N(e, "games.betrayal3.buryCard", [{
					op: "bury",
					actor: n,
					id: e
				}], e, "card"))), !0;
			}
			case "wolfCommune": return M(e, t.actor, "games.betrayal3.chooseRoom", x(e, e.monsters[0].room, !0).map((n) => N(n, "games.betrayal3.moveTo", [{
				op: "relocate",
				actor: e.monsters[0].id,
				id: n
			}, {
				op: "wolfCommuneAttack",
				actor: t.actor
			}], n, "room"))), !0;
			case "wolfCommuneAttack": return M(e, t.actor, "games.betrayal3.chooseDamageTarget", O(e).filter((t) => t.room === e.monsters[0].room && t.secret.hiddenFromWerewolf !== !0).map((t) => N(t.rid, "games.betrayal3.attackUnarmed", [{
				op: "attack",
				actor: e.monsters[0].id,
				target: t.rid,
				trait: "might",
				damage: "physical"
			}], t.rid, "player"))), !0;
			case "hauntMonsterEnd": {
				let t = e.journal.slice(H(e).counters.wolfJournalAt ?? e.journal.length).some((t) => t.key === "games.betrayal3.logDamage" && (t.n ?? 0) > 0 && E(e, t.actor ?? "")?.team === "hero");
				if (H(e).track = Math.max(0, H(e).track - (t ? 1 : 2)), H(e).track === 0) X(e);
				else for (let t of O(e)) t.secret.hiddenFromWerewolf = !1;
				return !0;
			}
			default: return !1;
		}
	},
	check: Z
}, _i = [
	"entranceHall",
	"hallway",
	"groundStaircase"
];
function vi(e) {
	return _i.includes(v(e)) ? "groundStaircase" : v(e);
}
function yi(e, t) {
	let n = vi(t), r = n === "groundStaircase" ? _i : [n];
	for (let t of r) jn(e, t, "burning");
	Mn.includes(n) && !e.tokens.some((e) => e.kind === "seamFire" && e.room === n) && L(e, "seamFire", n);
}
function bi(e, t) {
	return [...new Set(e.rooms.filter((e) => t.includes(vi(e.id))).flatMap(b).flatMap((t) => Re(e, t, !0)).map(vi))];
}
function xi(e) {
	let t = new Set(e.rooms.filter((e) => e.condition === "burning").map((e) => vi(e.id))), n = [];
	for (; t.size;) {
		let r = [t.values().next().value], i = [];
		for (t.delete(r[0]); r.length;) {
			let n = r.shift();
			i.push(n);
			for (let i of bi(e, [n])) t.has(i) && (t.delete(i), r.push(i));
		}
		n.push(i);
	}
	return n;
}
var Si = {
	setup(e) {
		let t = H(e).traitor;
		if (F(e, t), H(e).monsterAfter = t, yi(e, E(e, H(e).revealer).room), e.players.length === 3) {
			let t = O(e).find((t) => t.rid !== H(e).revealer);
			Mn.includes(v(t.room)) || yi(e, t.room);
		}
		j(e, Array.from({ length: $(e, [
			1,
			2,
			3,
			4
		]) }, () => ({
			op: "seamPlace",
			actor: t
		})));
	},
	actions(e, t) {
		return E(e, t).team === "hero" && y(e, E(e, t).room).condition !== "burning" ? U(e, t, "setFire", "games.betrayal3.setFire", [W(t, "seamFireResult", "sanity")]) : [];
	},
	handle(e, t) {
		if (t.op === "characterDamage" && t.actor === H(e).traitor && (t.n = Math.max(0, (t.n ?? 0) - 1)), t.op === "hauntStartMonsters") {
			let n = e.monsters.filter((e) => !e.dead);
			return j(e, [
				{
					op: "roll",
					actor: n[0].id,
					n: 6,
					args: { context: "monsterMovement" },
					then: [{
						op: "seamMovementResult",
						actor: n[0].id,
						id: "normal"
					}]
				},
				{
					op: "roll",
					actor: n[0].id,
					n: 2,
					args: { context: "monsterMovement" },
					then: [{
						op: "seamMovementResult",
						actor: n[0].id,
						id: "visible"
					}]
				},
				...n.map((e) => ({
					op: "seamBegin",
					actor: e.id
				})),
				{
					op: "hauntMonsterEnd",
					actor: t.actor
				}
			]), !0;
		}
		switch (t.op) {
			case "seamPlace": return M(e, t.actor, "games.betrayal3.chooseMannequinRoom", Mn.filter((t) => e.rooms.some((e) => e.id === t)).map((e) => N(e, "games.betrayal3.placeToken", [{
				op: "seamCreate",
				actor: t.actor,
				id: e
			}], e, "room"))), !0;
			case "seamCreate": return J(e, "mannequin", t.id, B(7, 6, 4, 2)), !0;
			case "seamMovementResult": return H(e).counters[`seamMovement.${t.id}`] = Math.max(1, z(t.args, "total")), !0;
			case "seamBegin": {
				let n = e.monsters.find((e) => e.id === t.actor);
				return n.dead ? !0 : n.stunned ? (n.stunned = !1, !0) : (n.flags.movement = H(e).counters[O(e).some((t) => S(e, t.room, n.room)) ? "seamMovement.visible" : "seamMovement.normal"], n.flags.attacked = !1, j(e, [{
					op: "monsterAct",
					actor: n.id
				}]), !0);
			}
			case "seamFireResult": return z(t.args, "total") >= 4 && yi(e, E(e, t.actor).room), !0;
			case "hauntEnter": return E(e, t.actor)?.team === "hero" && y(e, E(e, t.actor).room).condition === "burning" && j(e, [G(t.actor, 1, "general")]), !0;
			case "hauntMonsterEnd": {
				let t = xi(e).map((t) => bi(e, t).filter((t) => y(e, t).condition !== "burning")).filter((e) => e.length);
				return H(e).flags.seamSpreadTargets = [], t.length ? j(e, [...t.map((t) => ({
					op: "seamSpreadChoose",
					actor: H(e).traitor,
					args: { targets: t }
				})), {
					op: "seamSpreadApply",
					actor: H(e).traitor
				}]) : M(e, H(e).traitor, "games.betrayal3.chooseBurnRoom", [
					"groundStaircase",
					"upperLanding",
					"basementLanding"
				].filter((t) => y(e, t).condition !== "burning").map((t) => N(t, "games.betrayal3.burnRoom", [{
					op: "seamBurn",
					actor: H(e).traitor,
					id: t
				}], t, "room"))), !0;
			}
			case "seamSpreadChoose": return M(e, t.actor, "games.betrayal3.chooseBurnRoom", t.args.targets.map((e) => N(e, "games.betrayal3.burnRoom", [{
				op: "seamSpreadSelect",
				actor: t.actor,
				id: e
			}], e, "room"))), !0;
			case "seamSpreadSelect": return H(e).flags.seamSpreadTargets.push(t.id), !0;
			case "seamSpreadApply":
				for (let t of H(e).flags.seamSpreadTargets) yi(e, t);
				return !0;
			case "seamBurn": return yi(e, t.id), !0;
			case "hauntTurnEnd": return E(e, t.actor).team === "hero" && e.rooms.every((e) => e.condition === "burning") && X(e), !0;
			default: return !1;
		}
	},
	check: Z
}, Ci = {
	setup(e) {
		let t = H(e).traitor;
		F(e, t), H(e).track = $(e, [
			2,
			3,
			4,
			5
		]);
		let n = [], r = [];
		for (; e.items.length && r.length < 2;) {
			let t = e.items.shift();
			(je.has(t) ? r : n).push(t);
		}
		e.items.push(...n), E(e, t).cards.push(...r), j(e, [{
			op: "placeRoom",
			actor: t,
			id: "armory",
			args: { floor: "G" }
		}]);
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		return n.team === "hero" ? (n.room === E(e, H(e).traitor).room && E(e, H(e).traitor).cards.includes("book") && r.push(...U(e, t, "stealScript", "games.betrayal3.stealScript", [W(t, "debutStealResult", "speed")])), n.cards.includes("book") && q(e, t, [
			"library",
			"ballroom",
			"gallery",
			"guestQuarters"
		]) && r.push(...U(e, t, "rewriteScript", "games.betrayal3.rewriteScript", [W(t, "debutRewriteResult", "knowledge")])), r) : r;
	},
	handle(e, t) {
		if (t.op === "roll" && t.actor === H(e).traitor && An(e, t.actor, "event") && O(e).some((n) => n.room === E(e, t.actor).room) && (t.args = {
			...t.args,
			extraDice: z(t.args, "extraDice") + 1
		}), t.op === "death" && t.actor === H(e).traitor && (t.args?.forced === !0 || w.some((n) => E(e, t.actor).traits[n] < 0))) {
			if (H(e).track === 0) return X(e), !0;
			H(e).track--;
			let n = E(e, t.actor);
			return n.dead = !1, n.room = "armory", F(e, n.rid), e.prompt = null, e.roll = null, e.suspendedRolls = [], e.trade = null, e.discovery = null, e.extraTurn = !1, e.endRequested = !1, e.queue = [{
				op: "beginTurn",
				actor: n.rid
			}], !0;
		}
		switch (t.op) {
			case "debutStealResult": return z(t.args, "total") >= 4 && at(e, H(e).traitor, t.actor, "book"), !0;
			case "debutRewriteResult": return z(t.args, "total") >= 6 && (H(e).track = Math.max(0, H(e).track - 1)), !0;
			default: return !1;
		}
	},
	check: Z
}, wi = {
	setup(e) {
		let t = E(e, H(e).traitor);
		for (let n of [...t.cards]) I(e, t.rid, n);
		t.dead = !0, t.secret.bodyRemoved = !0, H(e).flags.deadTurns = [t.rid], J(e, "giantHair", t.room, B(7, 1, 6, 4)), J(e, "smallHair", "entranceHall", B(5, 7, 2, 3)), H(e).flags.antidoteOrder = T(e, Array.from({ length: $(e, [
			4,
			6,
			8,
			10
		]) }, (e, t) => t + 1)), j(e, [{
			op: "hairPlaceAntidote",
			actor: t.rid
		}]);
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team !== "hero") return r;
		q(e, t, ["library"]) && e.tokens.some((e) => e.kind === "antidote" && e.hidden) && r.push(...U(e, t, "learnHairCurse", "games.betrayal3.learnHairCurse", [W(t, "hairLearnResult", "knowledge")]));
		for (let i of e.tokens.filter((e) => e.kind === "antidote" && e.room === n.room)) r.push(...U(e, t, "discoverAntidote", "games.betrayal3.discoverAntidote", [{
			op: "hairDiscover",
			actor: t,
			id: i.id
		}], i.id, "token"));
		return r;
	},
	handle(e, t) {
		if (t.op === "beginTurn" && t.actor === H(e).traitor) {
			e.turn = t.actor, e.turnNumber++, e.endRequested = !1;
			for (let t of e.monsters) t.flags.shifted = !1;
			return j(e, [
				...Un(e, e.monsters.filter((e) => e.kind === "smallHair").map((e) => e.id)).filter((e) => e.op !== "hauntMonsterEnd"),
				...Un(e, e.monsters.filter((e) => e.kind === "giantHair").map((e) => e.id)).filter((e) => e.op !== "hauntMonsterEnd"),
				{
					op: "nextTurn",
					actor: t.actor
				}
			]), !0;
		}
		let n = e.monsters.find((e) => e.id === t.actor);
		if (t.op === "monsterAct" && n?.kind === "giantHair") {
			if (n.dead || n.stunned) return !0;
			let t = Q(e, n), r = y(e, n.room), i = O(e).some((e) => e.room === n.room) ? 2 : 1;
			if (!r.condition && g(r.tile).symbol === "omen") {
				if (z(n.flags, "movement") >= i) for (let r of e.rooms.filter((e) => !e.condition && g(e.tile).symbol === "omen").flatMap(b).filter((t) => t !== n.room && !x(e, n.room, !0).includes(t))) t.push(N(`omen-${r}`, "games.betrayal3.moveTo", [{
					op: "hairOmenMove",
					actor: n.id,
					id: r,
					n: i
				}, {
					op: "monsterAct",
					actor: n.id
				}], r, "room"));
				if (n.flags.shifted !== !0) for (let r of e.monsters.filter((e) => e.kind === "smallHair" && !e.dead)) t.push(N(`shift-${r.id}`, "games.betrayal3.shiftHair", [{
					op: "hairShift",
					actor: n.id,
					target: r.id
				}, {
					op: "monsterAct",
					actor: n.id
				}], r.id, "token"));
			}
			return H(e).flags.monsterActive = n.id, M(e, n.controller, "games.betrayal3.monsterAction", t), !0;
		}
		if (t.op === "roll" && t.args?.attack === !0 && t.args.defense !== !0 && e.monsters.find((e) => e.id === t.args.attackTarget)?.kind === "giantHair" && Ln(e, t.actor, "antidote") && (t.args.bonus = z(t.args, "bonus") + 3), t.op === "combatResult" && e.monsters.find((e) => e.id === t.target)?.kind === "giantHair" && Ln(e, t.actor, "antidote") && z(t.args, "attackTotal") > z(t.args, "total")) return X(e), !0;
		if (t.op === "characterDamage" && n?.kind === "giantHair" && t.args?.attackTrait !== "might") return !0;
		switch (t.op) {
			case "hairPlaceAntidote": return H(e).flags.antidoteOrder.length && M(e, t.actor, "games.betrayal3.chooseAntidoteRoom", e.rooms.flatMap(b).map((e) => N(e, "games.betrayal3.placeToken", [{
				op: "hairMakeAntidote",
				actor: t.actor,
				id: e
			}, t], e, "room"))), !0;
			case "hairMakeAntidote": {
				let n = H(e).flags.antidoteOrder.shift(), r = L(e, "antidote", t.id, null, n);
				return e.tokens.find((e) => e.id === r).hidden = !0, !0;
			}
			case "hairLearnResult": return z(t.args, "total") >= 5 && M(e, t.actor, "games.betrayal3.chooseAntidote", e.tokens.filter((e) => e.kind === "antidote" && e.hidden).map((e) => N(e.id, "games.betrayal3.revealAntidote", [{
				op: "hairReveal",
				actor: t.actor,
				id: e.id
			}], e.id, "token"))), !0;
			case "hairReveal": return e.tokens.find((e) => e.id === t.id).hidden = !1, !0;
			case "hairDiscover": {
				let n = e.tokens.find((e) => e.id === t.id);
				return n.hidden = !1, n.value === 1 && (n.holder = t.actor, n.room = null, delete n.flags.corpse, n.flags = {
					tradable: !0,
					heroesOnly: !0
				}), !0;
			}
			case "hairOmenMove": return n.flags.movement = z(n.flags, "movement") - t.n, j(e, [{
				op: "relocate",
				actor: n.id,
				id: t.id
			}]), !0;
			case "hairShift": {
				let r = e.monsters.find((e) => e.id === t.target);
				n.flags.shifted = !0;
				let i = n.room;
				return j(e, [{
					op: "relocate",
					actor: n.id,
					id: r.room
				}, {
					op: "relocate",
					actor: r.id,
					id: i
				}]), !0;
			}
			case "hauntDeath": return E(e, t.actor).team === "hero" && (E(e, t.actor).secret.bodyRemoved = !0, J(e, "smallHair", E(e, t.actor).room, B(5, 7, 2, 3))), !0;
			default: return !1;
		}
	},
	check: Z
}, Ti = {
	setup(e) {
		let t = H(e).traitor;
		F(e, t);
		for (let t of O(e)) t.secret.trappedByKnight = !0, L(e, "trappedHero", null, t.rid);
		j(e, O(e).map((e) => ({
			op: "knightPortalPlace",
			actor: t,
			target: e.rid
		})));
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team === "traitor") {
			for (let i of O(e).filter((t) => t.room === n.room && !(H(e).flags.knightAttacked ?? []).includes(t.rid))) r.push(N(`knight-${i.rid}`, i.secret.trappedByKnight === !0 ? "games.betrayal3.knightSanityAttack" : "games.betrayal3.knightTrapAttack", [{
				op: "knightAttack",
				actor: t,
				target: i.rid
			}], i.rid, "player"));
			return r;
		}
		if (!ft(e, "knightPortal", n.room)) return r;
		if (n.secret.trappedByKnight === !0) r.push(...U(e, t, "escapePortal", "games.betrayal3.escapePortal", [W(t, "knightEscapeResult", "knowledge", O(e).some((e) => e.room === n.room && e.secret.trappedByKnight !== !0) ? 2 : 0)]));
		else for (let n of ["knowledge", "sanity"]) r.push(...U(e, t, "closePortal", "games.betrayal3.closePortal", [W(t, "knightCloseResult", n)], n, "trait"));
		return r;
	},
	filterActions(e, t, n) {
		let r = E(e, t);
		return n.filter((e) => r.team !== "traitor" || !e.tasks.some((e) => e.op === "attack" || e.op === "dynamite")).filter((t) => !t.id.startsWith("trade-") || E(e, t.target).team !== "hero" || r.team !== "hero" || r.secret.trappedByKnight === !0 == (E(e, t.target).secret.trappedByKnight === !0));
	},
	handle(e, t) {
		if (t.op === "combatResult" && t.actor === H(e).traitor && t.trait === "sanity" && z(t.args, "attackTotal") < z(t.args, "total") && (t.damage = "mental"), t.op === "death" && t.actor === H(e).traitor) return (t.args?.forced === !0 || w.some((n) => E(e, t.actor).traits[n] < 0)) && F(e, t.actor), !0;
		if (t.op === "hauntTurnStart") return H(e).flags.knightAttacked = [], E(e, t.actor).team === "hero" && j(e, [{
			op: "roll",
			actor: t.actor,
			trait: "speed",
			args: { context: "portalMovement" },
			then: [{
				op: "knightMovementResult",
				actor: t.actor
			}]
		}]), !0;
		if (t.op === "combatResult" && t.args?.knightTrap === !0 && z(t.args, "attackTotal") > z(t.args, "total")) return E(e, t.target).secret.trappedByKnight = !0, L(e, "trappedHero", null, t.target), !0;
		switch (t.op) {
			case "knightPortalPlace": {
				let n = E(e, t.target), r = e.rooms.filter((t) => t.floor === y(e, n.room).floor).flatMap(b), i = r.map((t) => C(e, n.room, t)), a = Math.max(...i);
				return M(e, t.actor, "games.betrayal3.choosePortalRoom", r.filter((e, t) => i[t] === a).map((e) => N(e, "games.betrayal3.placeToken", [{
					op: "knightMakePortal",
					actor: t.actor,
					id: e
				}], e, "room"))), !0;
			}
			case "knightMakePortal": return L(e, "knightPortal", t.id), !0;
			case "knightMovementResult": return e.movement = Math.max(1, z(t.args, "total")), !0;
			case "knightEscapeResult": return z(t.args, "total") >= 6 ? (E(e, t.actor).secret.trappedByKnight = !1, e.tokens = e.tokens.filter((e) => e.kind !== "trappedHero" || e.holder !== t.actor)) : P(e, t.actor, "knowledge", 1), !0;
			case "knightCloseResult":
				if (z(t.args, "total") >= 4) {
					let n = e.tokens.find((n) => n.kind === "knightPortal" && n.room === E(e, t.actor).room);
					e.tokens = e.tokens.filter((e) => e !== n), e.tokens.some((e) => e.kind === "knightPortal") || X(e);
				} else j(e, [K(t.actor, 1, "mental")]);
				return !0;
			case "knightAttack": {
				let n = E(e, t.target).secret.trappedByKnight === !0;
				return H(e).flags.knightAttacked.push(t.target), j(e, [{
					op: "attack",
					actor: t.actor,
					target: t.target,
					trait: n ? "sanity" : "might",
					damage: "physical",
					args: {
						bonus: n ? 2 : 0,
						knightTrap: !n,
						noCounter: !n
					}
				}]), !0;
			}
			default: return !1;
		}
	},
	check: Z
}, Ei = {
	setup(e) {
		let t = H(e).traitor;
		F(e, t), P(e, t, "might", 1), H(e).monsterAfter = t;
		for (let t of e.explorers) t.cards = t.cards.filter((e) => e !== "skull");
		e.omens = e.omens.filter((e) => e !== "skull"), j(e, [{
			op: "placeRoom",
			actor: t,
			id: "bloodyRoom",
			args: { floor: "G" }
		}, {
			op: "hostCreate",
			actor: t
		}]);
	},
	actions(e, t) {
		return E(e, t).team === "traitor" && E(e, t).cards.includes("skull") ? U(e, t, "reviveHost", "games.betrayal3.reviveHost", [{
			op: "hostRevive",
			actor: t
		}]) : [];
	},
	handle(e, t) {
		if (t.op === "death" && t.actor === H(e).traitor) {
			let n = E(e, t.actor);
			return (t.args?.forced === !0 || w.some((e) => n.traits[e] < 0)) && (F(e, n.rid), j(e, [{
				op: "relocate",
				actor: n.rid,
				id: "bloodyRoom"
			}])), !0;
		}
		if (t.op === "characterDamage" && e.monsters.some((e) => e.id === t.actor) && (t.n ?? 0) > 0 && E(e, t.target ?? "")) return e.monsters.find((e) => e.id === t.actor).dead = !0, E(e, t.target).cards.push("skull"), !0;
		switch (t.op) {
			case "hostCreate": return J(e, "headOfHouse", "bloodyRoom", B(6, 6, 6, 8), { death: "kill" }), !0;
			case "hostRevive": {
				let n = E(e, t.actor), r = e.monsters[0];
				return n.cards = n.cards.filter((e) => e !== "skull"), r.dead = !1, r.stunned = !1, r.room = n.room, !0;
			}
			case "hauntTurnEnd": return E(e, t.actor).team === "hero" && E(e, t.actor).cards.includes("skull") && j(e, [W(t.actor, "hostBiteResult", "speed")]), !0;
			case "hostBiteResult": return z(t.args, "total") < 5 && j(e, [G(t.actor, 2, "physical")]), !0;
			default: return !1;
		}
	},
	check(e) {
		O(e).some((e) => e.room === "panicRoom" && e.cards.includes("skull")) ? X(e) : Z(e);
	}
}, Di = {
	setup(e) {
		let t = H(e).traitor, n = E(e, t);
		F(e, t), H(e).monsterAfter = t, P(e, t, "might", $(e, [
			0,
			1,
			2,
			2
		])), P(e, t, "speed", $(e, [
			0,
			1,
			2,
			2
		]));
		for (let t of O(e)) {
			let n = L(e, "heroBlood", null, t.rid);
			e.tokens.find((e) => e.id === n).flags.owner = t.rid;
		}
		let r = L(e, "infernalContract", null, J(e, "contractDemon", n.room, B(6, 4, 4, 5), { death: "immune" }).id);
		e.tokens.find((e) => e.id === r).flags = {
			tradable: !0,
			heroesOnly: !0
		}, j(e, [{
			op: "contractDemonPlace",
			actor: t
		}]);
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team === "traitor") {
			for (let i of e.tokens.filter((e) => e.kind === "heroBlood" && e.room === n.room)) r.push(N(`blood-${i.id}`, "games.betrayal3.collectBlood", [{
				op: "contractTakeBlood",
				actor: t,
				id: i.id
			}], i.id, "token"));
			if (!e.attacked) for (let i of O(e).filter((e) => e.room === n.room)) r.push(N(`sanity-${i.rid}`, "games.betrayal3.attackSanity", [{
				op: "attack",
				actor: t,
				target: i.rid,
				trait: "sanity",
				damage: "mental"
			}], i.rid, "player"));
			return r;
		}
		return e.tokens.some((e) => e.kind === "infernalContract" && e.holder === t) && r.push(...U(e, t, "burnContract", "games.betrayal3.burnContract", [W(t, "contractBurnResult", "knowledge", q(e, t, [
			"furnaceRoom",
			"ritualRoom",
			"kitchen",
			"laboratory",
			"charredRoom"
		]) ? 4 : 0)])), e.tokens.some((e) => e.kind === "heroBlood" && e.holder === t) && r.push(...U(e, t, "bloodMagic", "games.betrayal3.bloodMagic", [K(t, 1, "mental"), {
			op: "gain",
			actor: t,
			trait: "might",
			n: 1
		}])), r;
	},
	handle(e, t) {
		if (t.op === "damage" && (t.args = {
			...t.args,
			journalAt: e.journal.length
		}), t.op === "combatResult" && t.trait === "might" && E(e, t.actor)?.team === "hero" && t.target === e.monsters[0].id && e.tokens.some((e) => e.kind === "infernalContract" && e.holder === t.target) && z(t.args, "attackTotal") > z(t.args, "total")) return M(e, t.actor, "games.betrayal3.stealOrDamage", [N("steal", "games.betrayal3.stealContract", [{
			op: "contractSteal",
			actor: t.actor
		}]), N("damage", "games.betrayal3.dealDamage", [{
			op: "characterDamage",
			actor: t.target,
			target: t.actor,
			n: z(t.args, "attackTotal") - z(t.args, "total"),
			damage: t.damage
		}])]), !0;
		switch (t.op) {
			case "contractDemonPlace": {
				let n = e.rooms.filter((e) => e.floor === "B").flatMap(b), r = n.map((t) => C(e, "basementLanding", t)), i = Math.max(...r);
				return M(e, t.actor, "games.betrayal3.chooseDemonRoom", n.filter((e, t) => r[t] === i).map((t) => N(t, "games.betrayal3.placeToken", [{
					op: "relocate",
					actor: e.monsters[0].id,
					id: t
				}], t, "room"))), !0;
			}
			case "contractTakeBlood": {
				let n = e.tokens.find((e) => e.id === t.id);
				return n.holder = t.actor, n.room = null, delete n.flags.corpse, !0;
			}
			case "contractSteal": return e.tokens.find((e) => e.kind === "infernalContract").holder = t.actor, !0;
			case "contractBurnResult": return z(t.args, "total") >= 7 ? X(e) : z(t.args, "total") <= 3 && j(e, [G(t.actor, 1, "physical")]), !0;
			case "hauntTurnEnd": return E(e, t.actor).team === "hero" && !e.tokens.some((e) => e.kind === "heroBlood" && e.holder === t.actor) && j(e, [K(t.actor, 1, "mental")]), !0;
			default: return !1;
		}
	},
	after(e, t) {
		if (t.op === "damage" && e.journal.slice(z(t.args, "journalAt")).some((e) => e.key === "games.betrayal3.logDamage" && e.id === "physical" && e.actor === t.actor && (e.n ?? 0) > 0)) for (let n of e.tokens.filter((e) => e.kind === "heroBlood" && e.holder === t.actor && e.flags.owner === t.actor)) n.holder = null, n.room = E(e, t.actor).room;
		e.monsters[0].death = e.tokens.some((t) => t.kind === "infernalContract" && t.holder === e.monsters[0].id) ? "immune" : "stun";
	},
	check(e) {
		let t = E(e, H(e).traitor);
		t.room === e.monsters[0].room && e.tokens.filter((e) => e.kind === "heroBlood" && e.holder === t.rid).length === e.players.length - 1 ? zn(e) : Z(e);
	}
}, Oi = {
	setup(e) {
		let t = E(e, H(e).traitor);
		for (let n of [...t.cards]) I(e, t.rid, n);
		t.dead = !0, t.secret.bodyRemoved = !0, H(e).flags.deadTurns = [t.rid], H(e).track = $(e, [
			2,
			3,
			3,
			4
		]), Mn.includes(y(e, t.room).id) || jn(e, t.room, "consumed"), J(e, "construct", t.room, B(8, H(e).track, 4, 4), { death: "immune" });
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team !== "hero") return r;
		for (let i of n.cards) for (let n of ["speed", "knowledge"]) r.push(...U(e, t, "setExplosive", "games.betrayal3.setExplosive", [{
			op: "bury",
			actor: t,
			id: i
		}, W(t, "constructExplosiveResult", n)], `${i}:${n}`, "card"));
		return r;
	},
	handle(e, t) {
		if (t.op === "beginTurn" && t.actor === H(e).traitor) return e.turn = t.actor, e.turnNumber++, e.endRequested = !1, e.monsters[0].flags.ateCorpse = !1, j(e, [...Un(e), {
			op: "nextTurn",
			actor: t.actor
		}]), !0;
		if (t.op === "monsterAct") {
			let t = e.monsters[0], n = Q(e, t), r = y(e, t.room);
			if (t.flags.ateCorpse !== !0) for (let r of e.explorers.filter((e) => e.dead && e.secret.bodyRemoved !== !0 && e.room === t.room)) n.push(N(`flesh-${r.rid}`, "games.betrayal3.consumeFlesh", [{
				op: "constructFlesh",
				actor: t.id,
				target: r.rid
			}, {
				op: "monsterAct",
				actor: t.id
			}], r.rid, "player"));
			return !Mn.includes(r.id) && r.condition !== "consumed" && n.push(N("consume", "games.betrayal3.consumeRoom", [{
				op: "constructConsume",
				actor: t.id
			}, {
				op: "monsterAct",
				actor: t.id
			}])), H(e).flags.monsterActive = t.id, M(e, t.controller, "games.betrayal3.monsterAction", n), !0;
		}
		switch (t.op) {
			case "constructExplosiveResult":
				if (z(t.args, "total") >= 6) {
					let n = e.tokens.filter((e) => e.kind === "makeshiftExplosive");
					n.length < $(e, [
						3,
						4,
						4,
						5
					]) ? L(e, "makeshiftExplosive", E(e, t.actor).room) : M(e, t.actor, "games.betrayal3.chooseExplosiveToMove", n.map((e) => N(e.id, "games.betrayal3.moveExplosiveHere", [{
						op: "constructMoveExplosive",
						actor: t.actor,
						id: e.id
					}], e.id, "token")));
				}
				return !0;
			case "constructMoveExplosive": return e.tokens.find((e) => e.id === t.id).room = E(e, t.actor).room, !0;
			case "constructFlesh": {
				let n = E(e, t.target);
				n.secret.bodyRemoved = !0, e.monsters[0].flags.ateCorpse = !0;
				for (let t of [...n.cards]) I(e, n.rid, t);
				return H(e).track++, !0;
			}
			case "constructConsume": {
				let t = e.monsters[0], n = y(e, t.room), r = !n.condition && g(n.tile).symbol === "omen";
				return jn(e, n.id, "consumed"), Nn(e).every((e) => e.condition === "consumed") ? (zn(e), !0) : (r && M(e, t.controller, "games.betrayal3.chooseConstructTeleport", [N("stay", "games.betrayal3.stayHere", []), ...[...new Set(O(e).map((e) => e.room))].map((e) => N(e, "games.betrayal3.moveTo", [{
					op: "constructTeleport",
					actor: t.id,
					id: e
				}], e, "room"))]), !0);
			}
			case "constructTeleport": return e.monsters[0].flags.movement = 0, j(e, [{
				op: "relocate",
				actor: e.monsters[0].id,
				id: t.id
			}]), !0;
			case "hauntTurnEnd": {
				let n = e.tokens.filter((e) => e.kind === "makeshiftExplosive");
				return E(e, t.actor).team === "hero" && n.length === $(e, [
					3,
					4,
					4,
					5
				]) && new Set(n.map((t) => y(e, t.room).floor)).size === 3 && X(e), !0;
			}
			default: return !1;
		}
	},
	after(e) {
		e.monsters[0].traits.speed = H(e).track;
	},
	check: Z
}, ki = {
	setup(e) {
		let t = H(e).traitor;
		for (let t of e.explorers) for (let n of [...t.cards]) h.includes(n) && I(e, t.rid, n);
		rt(e, t);
		for (let n of ["might", "speed"]) P(e, t, n, $(e, [
			1,
			2,
			3,
			4
		]));
		H(e).monsterAfter = t, H(e).flags.silvered = [];
		for (let t of O(e)) J(e, "packWolf", t.room, B(4, 4, 2, 2));
	},
	actions(e, t) {
		return E(e, t).team === "hero" && (An(e, t, "item") || An(e, t, "omen")) ? U(e, t, "silverSearch", "games.betrayal3.searchSilver", [W(t, "silverSearchResult", "knowledge")]) : [];
	},
	handle(e, t) {
		if (t.op === "attack" && t.target === H(e).traitor && H(e).flags.silvered.includes(t.id ?? "") && (t.args = {
			...t.args,
			extraDice: z(t.args, "extraDice") + 2
		}), t.op === "combatResult") {
			let n = z(t.args, "attackTotal"), r = z(t.args, "total");
			H(e).flags.silverDamageSource = t.target === H(e).traitor && n > r && H(e).flags.silvered.includes(t.id ?? "") ? t.actor : "";
		}
		switch (t.op) {
			case "hauntTurnStart":
				if (t.actor === H(e).traitor) {
					if (H(e).flags.silveredHit !== !0) for (let n of ["might", "speed"]) P(e, t.actor, n, 1);
					H(e).flags.silveredHit = !1;
				}
				return !0;
			case "silverSearchResult": {
				if (z(t.args, "total") < 3) return !0;
				let n = An(e, t.actor, "item"), r = (n ? e.items : e.omens).splice(0, 4);
				return M(e, t.actor, "games.betrayal3.chooseCardToKeep", r.map((e) => N(e, "games.betrayal3.keepCard", [{
					op: "silverKeep",
					actor: t.actor,
					id: e
				}, {
					op: "takeDrawn",
					actor: t.actor,
					id: e,
					args: {
						deck: n ? "item" : "omen",
						others: r.filter((t) => t !== e),
						noHaunt: !0
					}
				}], e, "card"))), !0;
			}
			case "silverKeep":
				if (je.has(t.id)) {
					H(e).flags.silvered.push(t.id);
					let n = L(e, "silverRune", null);
					e.tokens.find((e) => e.id === n).flags.card = t.id;
				}
				return !0;
			case "wolfHerd": {
				let n = E(e, t.target);
				return n.dead || M(e, t.actor, "games.betrayal3.herdHero", x(e, n.room).map((e) => N(e, "games.betrayal3.moveTo", [{
					op: "relocate",
					actor: n.rid,
					id: e
				}], e, "room"))), !0;
			}
			default: return !1;
		}
	},
	after(e, t) {
		if (t.op !== "damage" || e.queue[0]?.op !== "allocateDamage" || e.queue[0].actor !== t.actor) return;
		t.actor === H(e).traitor && t.target === H(e).flags.silverDamageSource && (H(e).flags.silveredHit = !0);
		let n = e.monsters.find((e) => e.id === t.target && e.kind === "packWolf");
		n && E(e, t.actor)?.team === "hero" && e.queue.splice(1, 0, {
			op: "wolfHerd",
			actor: n.controller,
			target: t.actor
		});
	},
	check(e) {
		E(e, H(e).traitor).dead ? X(e) : Z(e);
	}
};
function Ai(e) {
	return Y(e, "vampireBlood");
}
var ji = {
	setup(e) {
		let t = H(e).traitor;
		F(e, t), H(e).monsterAfter = t, H(e).counters.bloodSupply = $(e, [
			3,
			4,
			5,
			6
		]), H(e).counters.runesRequired = $(e, [
			2,
			3,
			4,
			5
		]), J(e, "vampireMaster", E(e, H(e).revealer).room, B(5, 5, 5, 5));
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team === "traitor") return n.room === e.monsters[0].room && Ai(e) ? U(e, t, "shareFeeding", "games.betrayal3.shareFeeding", [{
			op: "vampireHeal",
			actor: t
		}]) : [];
		let i = e.tokens.some((e) => e.kind === "sanctified" && e.room === n.room);
		return !i && An(e, t, "omen") && Y(e, "sanctified") < H(e).counters.runesRequired && r.push(...U(e, t, "sanctify", "games.betrayal3.sanctifyArea", [W(t, "sanctifyResult", "knowledge")])), i && Y(e, "sanctified") === H(e).counters.runesRequired && r.push(...U(e, t, "prepareAltar", "games.betrayal3.prepareAltar", [W(t, "vampireAltarResult", "sanity")])), r;
	},
	handle(e, t) {
		if (t.op === "attack" && E(e, t.actor)?.character === "werewolf" && t.target === e.monsters[0].id && (t.args = {
			...t.args,
			extraDice: z(t.args, "extraDice") + O(e).filter((e) => e.rid !== t.actor).length
		}), t.op === "combatResult") {
			let n = z(t.args, "attackTotal") - z(t.args, "total"), r = E(e, n > 0 ? t.target : t.actor);
			if (n !== 0 && r?.team === "hero" && r.room === e.monsters[0].room) {
				let t = Math.min(r.character === "werewolf" ? 2 : 1, H(e).counters.bloodSupply);
				for (let n = 0; n < t; n++) L(e, "vampireBlood", null, H(e).traitor);
				H(e).counters.bloodSupply -= t;
			}
		}
		if (t.op === "characterDamage" && t.actor === e.monsters[0].id && (t.n ?? 0) > 0) {
			let t = e.monsters[0];
			return e.tokens.some((e) => e.kind === "vampireAltar" && e.room === t.room) ? X(e) : (t.stunned = !0, M(e, O(e)[0].rid, "games.betrayal3.driveVampireBack", e.rooms.filter((t) => !O(e).some((e) => e.room.split(":")[0] === t.id)).map((e) => N(e.id, "games.betrayal3.moveTo", [{
				op: "relocate",
				actor: t.id,
				id: e.id
			}], e.id, "room")))), !0;
		}
		switch (t.op) {
			case "sanctifyResult": return z(t.args, "total") >= 3 && L(e, "sanctified", E(e, t.actor).room), !0;
			case "vampireAltarResult": return z(t.args, "total") >= 4 ? (e.tokens = e.tokens.filter((e) => e.kind !== "vampireAltar"), L(e, "vampireAltar", E(e, t.actor).room)) : j(e, [K(t.actor, 1, "mental")]), !0;
			case "vampireHeal": return e.tokens.splice(e.tokens.findIndex((e) => e.kind === "vampireBlood"), 1), F(e, t.actor), !0;
			default: return !1;
		}
	},
	after(e) {
		for (let t of w) e.monsters[0].traits[t] = 5 + Ai(e);
	},
	check: Z
}, Mi = {
	setup(e) {
		H(e).flags.firstPlayer = e.players[(e.players.indexOf(H(e).revealer) + 1) % e.players.length];
		for (let t of e.explorers) {
			let n = L(e, "hunterNumber", null, t.rid, z(t.secret, "number"));
			e.tokens.find((e) => e.id === n).hidden = !0;
		}
	},
	actions(e, t) {
		let n = E(e, t), r = D(e).filter((e) => e.rid !== t && e.room === n.room), i = [];
		return n.team === "traitor" && !n.revealed && i.push(N("hunterReveal", "games.betrayal3.revealHunter", [{
			op: "hunterReveal",
			actor: t
		}])), r.length === 1 && r[0].character !== "werewolf" && i.push(...U(e, t, "interrogate", "games.betrayal3.interrogate", [W(t, "interrogateAttack", "knowledge", 0, { target: r[0].rid })], r[0].rid, "player")), i;
	},
	handle(e, t) {
		switch (t.op) {
			case "hauntTurnStart": return !E(e, t.actor).dead && !(E(e, t.actor).team === "traitor" && E(e, t.actor).revealed) && j(e, [K(t.actor, 1, "mental")]), !0;
			case "hunterReveal": {
				let n = E(e, t.actor);
				n.revealed = !0, F(e, n.rid);
				for (let t of w) P(e, n.rid, t, 1);
				return e.tokens.find((e) => e.kind === "hunterNumber" && e.holder === n.rid).hidden = !1, !0;
			}
			case "interrogateAttack": return j(e, [{
				op: "roll",
				actor: String(t.args.target),
				trait: "sanity",
				args: { context: "interrogate" },
				then: [{
					op: "interrogateResult",
					actor: t.actor,
					target: String(t.args.target),
					n: z(t.args, "total")
				}]
			}]), !0;
			case "interrogateResult": return t.n > z(t.args, "total") ? (E(e, t.actor).secret[`interrogated.${t.target}`] = E(e, t.target).secret.number, A(e, {
				key: "games.betrayal3.logInterrogate",
				actor: t.actor,
				target: t.target,
				n: z(E(e, t.target).secret, "number"),
				secretFor: [t.actor]
			})) : j(e, [K(t.actor, 1, "mental")]), !0;
			case "hauntDeath": {
				let n = E(e, t.actor), r = E(e, t.target);
				return n.revealed = !0, e.tokens.find((e) => e.kind === "hunterNumber" && e.holder === n.rid || e.kind === "hunterNumber" && e.flags.corpse === n.rid).hidden = !1, E(e, H(e).traitor).character === "werewolf" && n.team === "hero" && r?.team === "hero" && zn(e), !0;
			}
			default: return !1;
		}
	},
	check(e) {
		let t = E(e, H(e).traitor);
		t.dead ? X(e) : t.character === "werewolf" ? Z(e) : e.explorers.find((e) => e.character === "werewolf").dead && zn(e);
	}
};
//#endregion
//#region src/game/haunts/blood_phase.ts
function Ni(e) {
	let t = E(e, H(e).traitor), n = { ...t.traits };
	t.character = t.character === "werewolf" ? "sara" : "werewolf", t.traits = {
		might: n.knowledge,
		speed: n.sanity,
		sanity: n.speed,
		knowledge: n.might
	};
}
function Pi(e) {
	let t = E(e, H(e).traitor);
	for (let n of [...t.cards]) h.includes(n) ? at(e, t.rid, Qe(e, t.rid), n) : I(e, t.rid, n);
}
var Fi = {
	setup(e) {
		let t = H(e).traitor;
		F(e, t);
		for (let n of ["might", "speed"]) P(e, t, n, $(e, [
			1,
			1,
			2,
			2
		]));
		H(e).track = $(e, [
			1,
			2,
			3,
			4
		]), H(e).flags.phaseTraits = T(e, w.flatMap((e) => [e, e])).slice(0, $(e, [
			3,
			4,
			5,
			6
		]));
		for (let t of H(e).flags.phaseTraits) L(e, "phaseSupply", null, null, 1, t);
		Pi(e);
	},
	actions(e, t) {
		let n = E(e, t), r = E(e, H(e).traitor), i = [];
		if (n.team === "traitor") return n.character === "sara" ? U(e, t, "forceChange", "games.betrayal3.forceChange", [K(t, 1, "mental"), {
			op: "phaseForceChange",
			actor: t
		}]) : [];
		if (An(e, t, "omen") && !e.tokens.some((e) => e.kind === "phaseTrait" && e.room === n.room)) for (let n of [...new Set(H(e).flags.phaseTraits)]) i.push(...U(e, t, "prepareWerewolf", "games.betrayal3.prepareWerewolf", [W(t, "phasePrepareResult", n, 0, { trait: n })], n, "trait"));
		return r.character === "sara" && n.room === r.room && n.cards.some((e) => e === "book" || e === "mask") && i.push(...U(e, t, "saveWerewolf", "games.betrayal3.saveWerewolf", [W(t, "phaseSaveResult", "knowledge", Y(e, "phaseTrait"))])), i;
	},
	filterActions(e, t, n) {
		return t === H(e).traitor ? n.filter((e) => !e.tasks.some((e) => [
			"tradeStart",
			"loot",
			"lootToken"
		].includes(e.op))) : n.filter((t) => !t.tasks.some((t) => t.op === "tradeStart" && t.target === H(e).traitor));
	},
	handle(e, t) {
		let n = E(e, H(e).traitor);
		if (t.op === "attack" && t.actor === n.rid && E(e, t.target)?.team === "hero" && (H(e).flags.phaseAttacked = !0), t.op === "attack" && t.target === n.rid && n.character === "werewolf" && (t.args = {
			...t.args,
			bonus: z(t.args, "bonus") + Y(e, "phaseTrait")
		}), t.op === "death" && t.actor === n.rid && (t.args?.forced === !0 || w.some((e) => n.traits[e] < 0))) {
			if (n.character === "werewolf") X(e);
			else {
				Ni(e);
				for (let e of ["might", "speed"]) n.traits[e] = Math.max(n.traits[e], Me("werewolf").start[e]);
				n.dead = !1, e.queue = e.queue.filter((e) => e.op !== "death" || e.actor !== n.rid);
			}
			return !0;
		}
		switch (t.op) {
			case "hauntTurnStart": return t.actor === n.rid && (H(e).flags.phaseAttacked = !1, H(e).track++, H(e).track >= 9 ? zn(e) : j(e, [W(n.rid, "phaseChangeResult", "sanity")])), !0;
			case "phaseChangeResult":
				if (z(t.args, "total") <= H(e).track && (Ni(e), n.character === "werewolf")) for (let t of ["might", "speed"]) P(e, n.rid, t, 1);
				return !0;
			case "phaseForceChange": return !n.dead && n.character === "sara" && Ni(e), !0;
			case "hauntTurnEnd": return t.actor === n.rid && n.character === "werewolf" && H(e).flags.phaseAttacked !== !0 && j(e, [K(n.rid, 1, "mental")]), !0;
			case "phasePrepareResult":
				if (z(t.args, "total") >= 4) {
					let n = String(t.args.trait), r = H(e).flags.phaseTraits;
					r.splice(r.indexOf(n), 1), e.tokens.splice(e.tokens.findIndex((e) => e.kind === "phaseSupply" && e.trait === n), 1), L(e, "phaseTrait", E(e, t.actor).room, null, 1, n);
				} else j(e, [K(t.actor, 1, "mental")]);
				return !0;
			case "phaseSaveResult": return z(t.args, "total") >= 5 ? j(e, [{
				op: "roll",
				actor: t.actor,
				n: 1,
				args: { context: "saveWerewolf" },
				then: [{
					op: "phaseCureDamage",
					actor: t.actor
				}]
			}]) : j(e, [K(t.actor, 2, "physical")]), !0;
			case "phaseCureDamage": {
				let r = z(t.args, "total");
				if (n.traits.sanity - r < 0 || n.traits.knowledge - r < 0) pt(e, D(e).map((e) => e.rid), "blood5.cured");
				else for (let i of ["sanity", "knowledge"]) P(e, n.rid, i, -r, t.actor);
				return !0;
			}
			case "hauntDeath": return E(e, t.actor).team === "hero" && t.target === n.rid && n.character === "werewolf" && H(e).track++, !0;
			default: return !1;
		}
	},
	after: Pi,
	check(e) {
		(H(e).track >= 9 || !D(e).some((e) => e.team === "hero")) && zn(e);
	}
};
//#endregion
//#region src/game/haunts/blood_sport.ts
function Ii(e) {
	return e.tokens.find((e) => e.kind === "spectralIdol");
}
function Li(e) {
	let t = Ii(e);
	return t.room ?? E(e, t.holder)?.room ?? e.monsters.find((e) => e.id === t.holder).room;
}
function Ri(e, t) {
	Ii(e).holder = t, Ii(e).room = null;
}
function zi(e, t) {
	let n = e.rooms.flatMap(b), r = n.map((n) => Math.min(...t.map((t) => C(e, n, t, !0)))), i = Math.max(...r);
	return n.filter((e, t) => r[t] === i);
}
function Bi(e, t, n, r) {
	let i = e.tiles[0];
	if (!i) {
		M(e, t, "games.betrayal3.chooseRoom", r.map((e) => N(e, "games.betrayal3.placeToken", [{
			...n,
			id: e
		}], e, "room")));
		return;
	}
	M(e, t, "games.betrayal3.chooseFloor", [...g(i).floors].map((e) => N(e, "games.betrayal3.chooseFloor", [{
		op: "placeRoom",
		actor: t,
		id: i,
		args: { floor: e },
		then: [{
			...n,
			id: i
		}]
	}], e, "room")));
}
function Vi(e, t) {
	let n = Ii(e), r = t.room, i = t.kind === "ghostAdversary", a = e.tokens.find((e) => e.kind === "sportNest").room;
	if (i && n.holder === t.id && t.room === a) {
		j(e, [{
			op: "sportScore",
			actor: t.id
		}]);
		return;
	}
	if (i && t.room === Li(e) && n.holder !== t.id && t.flags.attemptedCatch !== !0) {
		if (t.flags.attemptedCatch = !0, !n.holder) {
			Ri(e, t.id), j(e, [{
				op: "monsterAct",
				actor: t.id
			}]);
			return;
		}
		if (E(e, n.holder)) {
			j(e, [W(t.id, "sportStealAttack", "speed", 0, { target: n.holder })]);
			return;
		}
	}
	let o = !i && t.flags.sportMoved === !0 ? D(e).filter((e) => e.room === r) : [];
	if (o.length) {
		M(e, t.controller, "games.betrayal3.chooseExplorer", o.map((e) => N(e.rid, "games.betrayal3.blockHero", [W(t.id, "sportBlockAttack", "speed", 0, { target: e.rid })], e.rid, "player")));
		return;
	}
	if (!i && r === Li(e)) return;
	let s = i && n.holder === t.id ? a : Li(e), c = D(e).some((e) => e.room === r) ? 2 : 1, l = C(e, r, s, !0), u = z(t.flags, "movement") >= c ? x(e, r, !0).filter((t) => C(e, t, s, !0) < l) : [];
	u.length && M(e, t.controller, "games.betrayal3.monsterAction", u.map((e) => N(e, "games.betrayal3.moveTo", [{
		op: "sportMarkMove",
		actor: t.id
	}, {
		op: "monsterMove",
		actor: t.id,
		id: e
	}], e, "room")));
}
var Hi = {
	setup(e) {
		H(e).monsterAfter = H(e).revealer, H(e).flags.firstPlayer = Qe(e, H(e).revealer), H(e).counters.heroScore = 0, H(e).counters.spiritScore = 0, H(e).counters.scoreTarget = $(e, [
			2,
			3,
			4,
			5
		]);
		for (let t of e.explorers) t.cards = t.cards.filter((e) => e !== "idol");
		e.omens = e.omens.filter((e) => e !== "idol"), L(e, "sportNest", E(e, H(e).revealer).room), j(e, [{
			op: "sportSetupRoom",
			actor: H(e).revealer
		}]);
	},
	actions(e, t) {
		let n = E(e, t), r = Ii(e), i = [];
		return r ? (n.room === Li(e) && r.holder !== t && i.push(...U(e, t, "sportCatch", "games.betrayal3.catchIdol", [{
			op: "sportCatch",
			actor: t
		}])), r.holder === t && e.tokens.some((e) => e.kind === "sportAltar" && e.room === n.room) && i.push(...U(e, t, "sportScore", "games.betrayal3.scoreIdol", [{
			op: "sportScore",
			actor: t
		}])), i) : i;
	},
	handle(e, t) {
		let n = e.monsters.find((e) => e.id === t.actor);
		if (t.op === "monsterBegin" && n && !n.stunned && (n.flags.attemptedCatch = !1, n.flags.sportMoved = !1, n.flags.startBlocking = e.monsters.filter((e) => e.kind === "blockingSpirit" && !e.stunned && e.room === n.room).length), t.op === "monsterAct" && n) return !n.stunned && !n.dead && Vi(e, n), !0;
		switch (t.op) {
			case "sportSetupRoom": return Bi(e, t.actor, {
				op: "sportPlaceStart",
				actor: t.actor
			}, zi(e, ["groundStaircase"])), !0;
			case "sportPlaceStart":
				L(e, "spectralIdol", t.id), L(e, "sportAltar", t.id), J(e, "ghostAdversary", t.id, B(4, 5, 4, 4));
				for (let n = 0; n < e.players.length; n++) J(e, "blockingSpirit", t.id, B(3, 4, 2, 2));
				return !0;
			case "sportCatch": {
				let n = E(e, Ii(e).holder), r = e.monsters.find((t) => t.kind === "ghostAdversary" && t.room === Li(e) && !t.stunned);
				return n ? M(e, n.rid, "games.betrayal3.passIdol", [N("accept", "games.betrayal3.accept", [{
					op: "sportTake",
					actor: t.actor
				}]), N("decline", "games.betrayal3.decline", [])]) : r ? j(e, [W(t.actor, "sportCatchAttack", "might", 0, { target: r.id })]) : Ri(e, t.actor), !0;
			}
			case "sportTake": return Ri(e, t.actor), !0;
			case "sportCatchAttack": return j(e, [{
				op: "roll",
				actor: String(t.args.target),
				trait: "speed",
				args: { context: "sportCatch" },
				then: [{
					op: "sportCatchResult",
					actor: t.actor,
					n: z(t.args, "total")
				}]
			}]), !0;
			case "sportCatchResult": return t.n > z(t.args, "total") ? Ri(e, t.actor) : j(e, [K(t.actor, 1, "mental")]), !0;
			case "sportScore": {
				let r = !E(e, t.actor), i = r ? "spiritScore" : "heroScore";
				return H(e).counters[i]++, H(e).counters[i] >= H(e).counters.scoreTarget ? (r ? pt(e, [], "blood3.spirits") : X(e), !0) : (Bi(e, n?.controller ?? t.actor, {
					op: "sportResetBall",
					actor: t.actor
				}, zi(e, r ? [n.room] : D(e).map((e) => e.room))), !0);
			}
			case "sportResetBall": return Ii(e).room = t.id, Ii(e).holder = null, n && j(e, [{
				op: "monsterAct",
				actor: n.id
			}]), !0;
			case "sportMarkMove": return n.flags.sportMoved = !0, !0;
			case "sportStealAttack":
			case "sportBlockAttack": return j(e, [{
				op: "roll",
				actor: String(t.args.target),
				trait: "sanity",
				args: { context: t.op },
				then: [{
					op: t.op === "sportStealAttack" ? "sportStealResult" : "sportBlockResult",
					actor: t.actor,
					target: String(t.args.target),
					n: z(t.args, "total")
				}]
			}]), !0;
			case "sportStealResult": return t.n > z(t.args, "total") && (Ri(e, n.id), j(e, [{
				op: "monsterAct",
				actor: n.id
			}])), !0;
			case "sportBlockResult": return t.n > z(t.args, "total") ? e.tiles.length ? (Ii(e).holder === t.target && (Ii(e).holder = null, Ii(e).room = E(e, t.target).room), Bi(e, n.controller, {
				op: "sportTeleportHero",
				actor: t.target
			}, [])) : j(e, [K(t.target, 1, "mental")]) : t.n < z(t.args, "total") && (n.stunned = !0), !0;
			case "sportTeleportHero": return j(e, [{
				op: "relocate",
				actor: t.actor,
				id: t.id
			}]), !0;
			default: return !1;
		}
	},
	after(e, t) {
		let n = e.monsters.find((e) => e.id === t.actor);
		t.op === "monsterBegin" && n?.kind === "ghostAdversary" && e.queue[0]?.op === "monsterAct" && (n.flags.movement = z(n.flags, "movement") + z(n.flags, "startBlocking"));
	},
	check(e) {
		D(e).length || pt(e, [], "blood3.spirits");
	}
};
//#endregion
//#region src/game/haunts/yuletide_toys.ts
function Ui(e) {
	return e.explorers.find((e) => ["elf", "jingleklaws"].includes(e.character));
}
function Wi(e) {
	return e.monsters.filter((e) => e.kind === "mischievousToy" && !e.dead);
}
function Gi(e, t) {
	return e.tokens.find((e) => e.kind === "toyNumber" && e.flags.monster === t);
}
function Ki(e, t) {
	let n = Gi(e, t.id);
	return n.holder ? E(e, n.holder).room : n.room;
}
function qi(e, t) {
	let n = Ui(e), r = t.kind === "smallToy", i = D(e).filter((e) => e.room === t.room);
	if (t.flags.attacked === !0) return [];
	if (i.length && (r || t.flags.startedWithExplorer === !0)) return i.map((e) => N(e.rid, "games.betrayal3.attackUnarmed", [{
		op: "monsterAttack",
		actor: t.id,
		target: e.rid
	}], e.rid, "player"));
	if (t.flags.startedWithExplorer === !0) return [];
	let a = r ? [] : e.rooms.flatMap((t) => Ve(e, t.floor, t.id)).filter((t) => e.tiles.some((n) => g(n).floors.includes(y(e, t.room).floor))), o = r ? [n.room] : a.map((e) => e.room);
	if (!r && !e.tiles.length) return pt(e, [], "yuletide1.noRooms"), [];
	let s = i.length ? 2 : 1, c = Math.min(...o.map((n) => C(e, t.room, n, !0)));
	return !r && c === 0 && z(t.flags, "movement") >= 1 ? a.filter((e) => e.room === t.room).map((n) => N(`explore-${n.direction}`, "games.betrayal3.toyExplore", [{
		op: "toyExplore",
		actor: t.id,
		args: {
			x: n.x,
			y: n.y,
			direction: n.direction,
			from: n.room,
			floor: y(e, n.room).floor
		}
	}], String(n.direction), "action")) : z(t.flags, "movement") >= s ? x(e, t.room, !0).filter((t) => o.some((n) => C(e, t, n, !0) < c)).map((e) => N(e, "games.betrayal3.moveTo", [{
		op: "monsterMove",
		actor: t.id,
		id: e
	}], e, "room")) : [];
}
var Ji = {
	setup(e) {
		let t = e.explorers.flatMap((e) => e.cards);
		for (let t of e.explorers) t.cards = [], t.startCards = [];
		t.includes("armor") || (e.omens = e.omens.filter((e) => e !== "armor"), t.push("armor"));
		let n = $(e, [
			5,
			6,
			7,
			8
		]);
		for (; t.length < n && e.items.length;) t.push(e.items.shift());
		if (t.length < n) throw Error("Not enough items to set up Mischievous Toys");
		H(e).flags.toyPool = t.filter((e) => e !== "armor"), H(e).flags.chosenToys = ["armor"], H(e).counters.toyTarget = n, H(e).counters.banished = 0, H(e).monsterAfter = H(e).revealer, j(e, [{
			op: "toyChooseCards",
			actor: H(e).revealer,
			n: n - 1
		}]);
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		for (let i of Wi(e).filter((r) => r.stunned && r.room === n.room && !Gi(e, r.id).holder && (r.flags.stunnedBy !== t || r.flags.stunnedTurn !== e.turnNumber))) r.push(N(`carry-${i.id}`, "games.betrayal3.carryToy", [{
			op: "toyCarry",
			actor: t,
			id: i.id
		}], i.id, "token"));
		if (t === Ui(e).rid) for (let n of e.tokens.filter((e) => e.kind === "toyNumber" && e.holder === t)) r.push(...U(e, t, "banishMischief", "games.betrayal3.banishMischief", [W(t, "toyBanishResult", "knowledge", 0, { monster: String(n.flags.monster) })], String(n.flags.monster), "token"));
		return r;
	},
	handle(e, t) {
		let n = e.monsters.find((e) => e.id === t.actor);
		if (t.op === "hauntFirstTurn") return j(e, [{
			op: "hauntStartMonsters",
			actor: H(e).revealer
		}, {
			op: "beginTurn",
			actor: Qe(e, H(e).revealer)
		}]), !0;
		if (t.op === "monsterBegin" && n && !n.dead) {
			if (n.kind === "mischievousToy" && n.stunned) {
				n.stunned = !1;
				let t = Gi(e, n.id), r = Ki(e, n);
				return t.holder = null, t.room = r, delete t.flags.corpse, n.room = r, j(e, D(e).filter((e) => e.room === r).map((e) => K(e.rid, 2, "physical"))), !0;
			}
			n.flags.startedWithExplorer = D(e).some((e) => e.room === n.room);
		}
		if (t.op === "monsterAct" && n) return !n.dead && !n.stunned && M(e, n.controller, "games.betrayal3.monsterAction", qi(e, n)), !0;
		switch (t.op === "characterDamage" && n?.kind === "mischievousToy" && (t.n ?? 0) > 0 && (n.flags.stunnedBy = t.target ?? "", n.flags.stunnedTurn = e.turnNumber), t.op) {
			case "toyChooseCards":
				if (!t.n) {
					for (let t of H(e).flags.toyPool) (h.includes(t) ? e.omens : e.items).push(t);
					return j(e, [{
						op: "toyPlace",
						actor: t.actor,
						n: 0
					}]), !0;
				}
				return M(e, t.actor, "games.betrayal3.chooseToyCard", H(e).flags.toyPool.map((e) => N(e, "games.betrayal3.chooseThisCard", [{
					op: "toySelect",
					actor: t.actor,
					id: e
				}, {
					...t,
					n: t.n - 1
				}], e, "card"))), !0;
			case "toySelect": return H(e).flags.toyPool = H(e).flags.toyPool.filter((e) => e !== t.id), H(e).flags.chosenToys.push(t.id), !0;
			case "toyPlace": {
				let n = H(e).flags.chosenToys[t.n ?? 0];
				if (!n) return !0;
				let r = e.rooms.filter((t) => !t.condition && (g(t.tile).symbol?.startsWith("item") || g(t.tile).symbol === "omen") && !Wi(e).some((e) => e.room.split(":")[0] === t.id)).flatMap(b);
				return M(e, t.actor, "games.betrayal3.chooseToyRoom", (r.length ? r : ["entranceHall"]).map((e) => N(e, "games.betrayal3.placeToken", [{
					op: "toyCreate",
					actor: t.actor,
					id: e,
					n: (t.n ?? 0) + 1,
					args: { card: n }
				}, {
					...t,
					n: (t.n ?? 0) + 1
				}], e, "room"))), !0;
			}
			case "toyCreate": {
				let n = String(t.args.card), r = je.has(n), i = h.includes(n), a = J(e, "mischievousToy", t.id, r ? B(5, 2, 2, 2) : i ? B(2, 3, 4, 4) : B(3, 4, 2, 2), {
					attack: !r && i ? "sanity" : "might",
					damage: !r && i ? "mental" : "physical",
					flags: {
						ai: "pursue",
						card: n,
						number: t.n
					}
				}), o = L(e, "toyNumber", t.id, null, t.n), s = e.tokens.find((e) => e.id === o);
				return s.flags = {
					monster: a.id,
					card: n,
					tradable: !0
				}, !0;
			}
			case "toyCarry": {
				let n = Gi(e, t.id);
				return n.holder = t.actor, n.room = null, delete n.flags.corpse, !0;
			}
			case "toyBanishResult": {
				let n = e.monsters.find((e) => e.id === t.args.monster), r = Gi(e, n.id);
				if (z(t.args, "total") >= 3) n.dead = !0, e.tokens = e.tokens.filter((e) => e.id !== r.id), E(e, t.actor).cards.push(String(n.flags.card)), H(e).counters.banished++;
				else {
					let r = e.rooms.flatMap(b), i = Math.max(...r.map((n) => C(e, E(e, t.actor).room, n, !0)));
					j(e, [K(t.actor, 1, "physical"), {
						op: "toyRevivePrompt",
						actor: t.actor,
						id: n.id,
						args: { rooms: r.filter((n) => C(e, E(e, t.actor).room, n, !0) === i) }
					}]);
				}
				return !0;
			}
			case "toyRevivePrompt": return M(e, t.actor, "games.betrayal3.chooseFarthestToyRoom", t.args.rooms.map((e) => N(e, "games.betrayal3.moveTo", [{
				op: "toyRevive",
				actor: t.actor,
				id: t.id,
				args: { room: e }
			}], e, "room"))), !0;
			case "toyRevive": {
				let n = e.monsters.find((e) => e.id === t.id), r = Gi(e, n.id);
				return r.holder = null, r.room = String(t.args.room), delete r.flags.corpse, n.room = r.room, n.stunned = !1, !0;
			}
			case "toyExplore": {
				let r = y(e, n.room).floor, i = z(t.args, "x"), a = z(t.args, "y"), o = z(t.args, "direction"), s = e.tiles.findIndex((t) => g(t).floors.includes(r) && He(e, t, r, i, a, o).length);
				if (s < 0) throw Error("Toy exploration needs a legal room adjustment");
				let c = e.tiles[s];
				return M(e, n.controller, "games.betrayal3.chooseRotation", He(e, c, r, i, a, o).map((e) => N(String(e), "games.betrayal3.rotateTile", [{
					op: "placeRequired",
					actor: n.controller,
					id: c,
					args: {
						floor: r,
						x: i,
						y: a,
						rotation: e
					}
				}, {
					op: "toyExplored",
					actor: n.id,
					id: c,
					args: { direction: o }
				}], c, "rotation", e))), !0;
			}
			case "toyExplored": return n.room = Ie(y(e, t.id), (z(t.args, "direction") + 2) % 4), Gi(e, n.id).room = n.room, e.monsters.filter((e) => e.kind === "smallToy" && !e.dead).length < 20 && J(e, "smallToy", n.room, B(3, 3, 1, 1), { death: "kill" }), !0;
			default: return !1;
		}
	},
	after(e) {
		for (let t of Wi(e)) {
			let n = Gi(e, t.id);
			n.holder ? t.room = E(e, n.holder).room : n.room = t.room;
		}
		for (let t of e.monsters.filter((e) => e.kind === "smallToy" && !e.dead)) t.traits.might = 3 + e.monsters.filter((e) => e.id !== t.id && !e.dead && e.room === t.room).length;
	},
	check(e) {
		H(e).counters.banished === H(e).counters.toyTarget ? X(e) : Ui(e).dead && pt(e, [], "yuletide1.strangerDead");
	}
}, Yi = {
	chapel: "might",
	tower: "might",
	rootCellar: "speed",
	timeLostTree: "speed",
	observatory: "knowledge",
	organRoom: "knowledge"
}, Xi = {
	setup(e) {
		let t = H(e).traitor;
		rt(e, t);
		for (let n of w) P(e, t, n, $(e, [
			1,
			1,
			2,
			2
		]));
		H(e).track = $(e, [
			6,
			5,
			4,
			3
		]);
		let n = [...Object.keys(Yi), "soundproofedRoom"];
		j(e, [...n.filter((t) => !e.rooms.some((e) => e.id === t)).map((t) => ({
			op: "placeRoom",
			actor: H(e).revealer,
			id: t,
			args: {
				floor: g(t).floors[0],
				avoidAdjacent: n
			}
		})), {
			op: "bellSetup",
			actor: t
		}]);
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team === "traitor") return D(e).flatMap((n) => U(e, t, "twistDarkness", "games.betrayal3.twistDarkness", [{
			op: "roll",
			actor: t,
			n: 2,
			args: { context: "twistDarkness" },
			then: [{
				op: "bellTwistResult",
				actor: t,
				target: n.rid
			}]
		}], n.rid, "player"));
		for (let i of e.tokens.filter((e) => e.kind === "bell" && e.room === n.room && e.flags.delivered !== !0)) r.push(...U(e, t, "grabBell", "games.betrayal3.grabBell", [W(t, "bellGrabResult", i.trait, 0, { token: i.id })], i.id, "token"));
		if (n.room === "soundproofedRoom") for (let n of e.tokens.filter((e) => e.kind === "bell" && e.holder === t)) r.push(...U(e, t, "stopMusic", "games.betrayal3.stopBellMusic", [{
			op: "bellDeliver",
			actor: t,
			id: n.id
		}], n.id, "token"));
		return r;
	},
	handle(e, t) {
		if (t.op === "death" && t.actor === H(e).traitor && (t.args?.forced === !0 || w.some((n) => E(e, t.actor).traits[n] < 0))) return H(e).track++, F(e, t.actor), !0;
		switch (t.op) {
			case "bellSetup":
				for (let [t, n] of Object.entries(Yi)) {
					let r = L(e, "bell", t, null, 1, n);
					e.tokens.find((e) => e.id === r).flags.tradable = !0;
				}
				return L(e, "blessing", "soundproofedRoom"), e.tiles = T(e, e.tiles), !0;
			case "hauntTurnStart": return t.actor === H(e).traitor && H(e).track--, !0;
			case "hauntDeath": return H(e).track--, !0;
			case "hauntTurnEnd": return t.actor === H(e).traitor && e.tokens.some((n) => n.kind === "bell" && n.room === E(e, t.actor).room && n.flags.delivered !== !0) && j(e, [{
				op: "chooseGain",
				actor: t.actor,
				n: 1
			}]), !0;
			case "bellGrabResult":
				if (z(t.args, "total") >= 3) {
					let n = e.tokens.find((e) => e.id === t.args?.token);
					n.holder = t.actor, n.room = null;
				} else j(e, [K(t.actor, 1, "mental")]);
				return !0;
			case "bellDeliver": {
				let n = e.tokens.find((e) => e.id === t.id);
				return n.holder = null, n.room = "soundproofedRoom", n.flags.delivered = !0, n.flags.tradable = !1, !0;
			}
			case "bellTwistResult": return j(e, [{
				op: "hauntMoveSteps",
				actor: t.actor,
				target: t.target,
				n: z(t.args, "total")
			}, {
				op: "bellTwistDamage",
				actor: t.actor,
				target: t.target
			}]), !0;
			case "bellTwistDamage": return e.tokens.some((e) => e.kind === "bell" && e.holder === t.target) && j(e, [K(t.target, 1, "mental")]), !0;
			default: return !1;
		}
	},
	check(e) {
		e.tokens.filter((e) => e.kind === "bell" && e.flags.delivered === !0).length >= $(e, [
			3,
			4,
			5,
			6
		]) ? X(e) : H(e).track <= 0 ? zn(e) : Z(e);
	}
}, Zi = [
	"conservatory",
	"groundStaircase",
	"hallway",
	"tower",
	"gallery",
	"observatory",
	"graveyard"
];
function Qi(e, t = "mistletoeKudzu") {
	return e.monsters.filter((e) => e.kind === t && !e.dead);
}
function $i(e, t, n = "mistletoeKudzu") {
	Qi(e, n).length < (n === "mistletoeKudzu" ? 20 : 6) && J(e, n, t, B(3, 3, 1, 1), { death: "kill" });
}
function ea(e) {
	let t = new Set(Qi(e).map((e) => v(e.room))), n = $(e, [
		5,
		6,
		7,
		8
	]);
	function r(i, a) {
		return a.size >= n || b(y(e, i)).flatMap((t) => x(e, t, !0)).map(v).some((e) => t.has(e) && !a.has(e) && r(e, /* @__PURE__ */ new Set([...a, e])));
	}
	return t.size >= n && [...t].some((e) => r(e, /* @__PURE__ */ new Set([e])));
}
var ta = {
	setup(e) {
		let t = H(e).traitor;
		F(e, t), H(e).monsterAfter = t, H(e).counters.ornamentSupply = $(e, [
			4,
			5,
			6,
			7
		]), j(e, [{
			op: "treeSetupPlants",
			actor: t,
			n: $(e, [
				2,
				3,
				4,
				5
			]) * 2
		}]);
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team === "traitor") return Qi(e).length < 20 ? U(e, t, "rockAround", "games.betrayal3.rockAround", [{
			op: "treeGrow",
			actor: t,
			id: n.room
		}]) : [];
		if (Qi(e).some((e) => e.room === n.room) && r.push(...U(e, t, "rustleAround", "games.betrayal3.rustleAround", [W(t, "treeRustleResult", "speed")])), Y(e, "ornament") < H(e).counters.ornamentSupply) for (let i of n.cards.filter((e) => !je.has(e) && e !== "dog")) r.push(...U(e, t, "createOrnament", "games.betrayal3.createOrnament", [W(t, "treeOrnamentResult", "knowledge", 0, { card: i })], i, "card"));
		if (n.room === E(e, H(e).traitor).room) for (let n of e.tokens.filter((e) => e.kind === "ornament" && e.holder === t)) r.push(...U(e, t, "trimTree", "games.betrayal3.trimTree", [W(t, "treeTrimResult", "speed", 0, { token: n.id })], n.id, "token"));
		return r;
	},
	handle(e, t) {
		let n = e.monsters.find((e) => e.id === t.actor);
		if (t.op === "death" && t.actor === H(e).traitor && (t.args?.forced === !0 || w.some((n) => E(e, t.actor).traits[n] < 0))) return Qi(e).length ? M(e, t.actor, "games.betrayal3.reviveTree", Qi(e).map((e) => N(e.id, "games.betrayal3.reviveHere", [{
			op: "treeRevive",
			actor: t.actor,
			id: e.id
		}], e.id, "token"))) : X(e), !0;
		if (t.op === "monsterAct" && n?.kind === "mistletoeKudzu") {
			if (n.dead || n.stunned) return !0;
			let t = Q(e, n).filter((e) => !e.id.startsWith("move-"));
			if (n.flags.attacked !== !0) for (let r of e.explorers.filter((e) => !e.dead && e.team === "hero" && e.room === n.room)) t.push(N(`kiss-${r.rid}`, "games.betrayal3.kissDeath", [{
				op: "treeKiss",
				actor: n.id,
				target: r.rid
			}], r.rid, "player"));
			return M(e, n.controller, "games.betrayal3.monsterAction", t), !0;
		}
		if (t.op === "attackResult" && n?.kind === "burningYuleLog" && e.lastDice.every((e) => e !== 0) && $i(e, n.room, "burningYuleLog"), t.op === "combatResult" && t.args?.treeKiss === !0 && z(t.args, "attackTotal") > z(t.args, "total") && Qi(e).length < 20) return M(e, n.controller, "games.betrayal3.chooseKissEffect", [N("damage", "games.betrayal3.dealDamage", [{
			op: "characterDamage",
			actor: t.target,
			target: t.actor,
			n: z(t.args, "attackTotal") - z(t.args, "total"),
			damage: "physical"
		}]), ...[n.room, ...x(e, n.room, !0)].map((e) => N(e, "games.betrayal3.growKudzuHere", [{
			op: "treeGrow",
			actor: t.actor,
			id: e
		}], e, "room"))]), !0;
		switch (t.op) {
			case "treeSetupPlants": {
				if (!t.n) return !0;
				let n = e.rooms.filter((e) => Zi.includes(e.id)), r = n.filter((t) => !e.monsters.some((e) => !e.dead && e.room === t.id)), i = r.length ? r : n, a = $(e, [
					2,
					3,
					4,
					5
				]), o = t.n > a ? "mistletoeKudzu" : "burningYuleLog";
				return M(e, t.actor, "games.betrayal3.choosePlantRoom", i.map((e) => N(e.id, "games.betrayal3.placeToken", [{
					op: "treeGrow",
					actor: t.actor,
					id: e.id,
					args: { kind: o }
				}, {
					...t,
					n: t.n - 1
				}], e.id, "room"))), !0;
			}
			case "treeGrow": return $i(e, t.id, String(t.args?.kind ?? "mistletoeKudzu")), !0;
			case "treeRustleResult": return z(t.args, "total") >= 3 ? M(e, t.actor, "games.betrayal3.chooseDeck", ["item", "omen"].filter((t) => (t === "item" ? e.items : e.omens).length).map((e) => N(e, "games.betrayal3.drawFromDeck", [{
				op: "draw",
				actor: t.actor,
				id: e,
				args: { noHaunt: !0 }
			}], e, "card"))) : j(e, [G(t.actor, 1, "physical")]), !0;
			case "treeOrnamentResult":
				if (z(t.args, "total") >= 3) {
					let n = L(e, "ornament", null, t.actor);
					e.tokens.find((e) => e.id === n).flags.tradable = !0, j(e, [{
						op: "bury",
						actor: t.actor,
						id: String(t.args.card)
					}]);
				}
				return !0;
			case "treeTrimResult":
				if (z(t.args, "total") >= 3) {
					let n = e.tokens.find((e) => e.id === t.args.token);
					n.holder = H(e).traitor, n.flags.tradable = !1;
				} else j(e, [K(t.actor, 1, "physical")]);
				return !0;
			case "treeKiss": return n.flags.attacked = !0, j(e, [{
				...t,
				op: "attack",
				trait: "speed",
				damage: "physical",
				args: { treeKiss: !0 }
			}, {
				op: "monsterAct",
				actor: t.actor
			}]), !0;
			case "treeRevive": {
				let n = e.monsters.find((e) => e.id === t.id);
				return n.dead = !0, E(e, t.actor).room = n.room, F(e, t.actor), !0;
			}
			case "hauntDeath": return $i(e, E(e, t.actor).room), !0;
			default: return !1;
		}
	},
	check(e) {
		e.tokens.filter((t) => t.kind === "ornament" && t.holder === H(e).traitor).length >= $(e, [
			3,
			4,
			5,
			6
		]) ? X(e) : ea(e) ? zn(e) : Z(e);
	}
}, na = (e) => !h.includes(e);
function ra(e, t) {
	e.monsters.filter((e) => e.kind === "coalCreature" && !e.dead).length < 20 && J(e, "coalCreature", t, B(4, 2, 2, 2));
}
function ia(e) {
	return e.tokens.filter((t) => t.kind === "offeringFood" && t.room && (H(e).flags.luredFood ?? []).includes(t.id));
}
var aa = {
	setup(e) {
		let t = H(e).traitor, n = String(H(e).flags.triggerCard), r = e.explorers.find((e) => e.cards.includes(n));
		r && r.rid !== t ? at(e, r.rid, t, n) : r || (e.omens = e.omens.filter((e) => e !== n), E(e, t).cards.push(n)), rt(e, t);
		for (let n of w) P(e, t, n, $(e, [
			1,
			1,
			2,
			2
		]));
		for (; E(e, t).cards.filter(na).length < $(e, [
			2,
			3,
			4,
			5
		]) && e.items.length;) E(e, t).cards.push(e.items.shift());
		H(e).monsterAfter = t, H(e).flags.giftCards = [];
		for (let t of e.explorers) ra(e, t.room);
		j(e, [
			{
				op: "placeRoom",
				actor: H(e).revealer,
				id: "kitchen",
				args: { floor: "G" }
			},
			{
				op: "placeRoom",
				actor: H(e).revealer,
				id: "larder",
				args: { floor: "B" }
			},
			{
				op: "coalSetupFood",
				actor: H(e).revealer,
				n: 5
			}
		]);
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team === "traitor") {
			if (!e.attacked) for (let i of O(e).filter((t) => S(e, n.room, t.room))) r.push(...U(e, t, "gazeHorror", "games.betrayal3.gazeHorror", [{
				op: "attack",
				actor: t,
				target: i.rid,
				trait: "knowledge",
				damage: "mental"
			}, {
				op: "coalGazeOffer",
				actor: t,
				target: i.rid
			}], i.rid, "player"));
			return r;
		}
		for (let i of e.tokens.filter((t) => t.kind === "offeringFood" && t.room === n.room && t.flags.unpickableTurn !== e.turnNumber)) r.push(...U(e, t, "takeFood", "games.betrayal3.takeOfferingFood", [{
			op: "coalTakeFood",
			actor: t,
			id: i.id
		}], i.id, "token"));
		if (!e.tokens.some((e) => e.kind === "offeringFood" && e.room === n.room)) for (let n of e.tokens.filter((e) => e.kind === "offeringFood" && e.holder === t)) r.push(...U(e, t, "offerFood", "games.betrayal3.makeOffering", [{
			op: "coalOfferFood",
			actor: t,
			id: n.id
		}], n.id, "token"));
		for (let i of n.cards.filter((t) => na(t) && !H(e).flags.giftCards.includes(t))) for (let a of D(e).filter((e) => e.team === "hero" && e.rid !== t && e.room === n.room)) {
			let n = U(e, t, "niceGift", "games.betrayal3.niceGift", [{
				op: "coalGift",
				actor: t,
				target: a.rid,
				id: i
			}], `${i}:${a.rid}`, "card");
			for (let e of n) e.params = {
				card: i,
				player: a.rid
			};
			r.push(...n);
		}
		return q(e, t, ["kitchen", "larder"]) && Y(e, "offeringFood") < 5 && !e.tokens.some((e) => e.kind === "offeringFood" && e.room === n.room) && r.push(...U(e, t, "scroungeFood", "games.betrayal3.scroungeFood", [W(t, "coalScroungeResult", "knowledge")])), r;
	},
	filterActions(e, t, n) {
		let r = E(e, t), i = ia(e), a = n.some((t) => t.tasks.some((t) => t.op === "move" && i.some((n) => C(e, t.id, n.room) < C(e, r.room, n.room))));
		return n.filter((t) => !t.tasks.some((t) => r.team === "hero" && t.op === "loot" && H(e).flags.giftCards.includes(t.id) ? !0 : r.team !== "traitor" || !i.length ? !1 : t.op === "discover" || t.op === "useItem" && ["map", "mask"].includes(t.id) ? !0 : t.op === "move" ? !i.some((n) => C(e, t.id, n.room) < C(e, r.room, n.room)) : t.op === "endTurn" && a));
	},
	handle(e, t) {
		let n = e.monsters.find((e) => e.id === t.actor);
		switch (t.op === "attack" && t.target === H(e).traitor && H(e).counters.foodAttackBonus && (t.args = {
			...t.args,
			extraDice: z(t.args, "extraDice") + H(e).counters.foodAttackBonus
		}, H(e).counters.foodAttackBonus = 0), t.op === "combatResult" && n?.kind === "coalCreature" && e.queue.unshift({
			op: "coalSpoil",
			actor: n.id,
			target: t.target
		}), t.op) {
			case "coalSetupFood": return t.n ? M(e, t.actor, "games.betrayal3.divideFood", ["kitchen", "larder"].map((e) => N(e, "games.betrayal3.placeToken", [{
				op: "coalMakeFood",
				actor: t.actor,
				id: e
			}, {
				...t,
				n: t.n - 1
			}], e, "room"))) : e.tiles = T(e, e.tiles), !0;
			case "coalMakeFood": {
				let n = L(e, "offeringFood", t.id);
				return e.tokens.find((e) => e.id === n).flags.tradable = !0, !0;
			}
			case "coalTakeFood": {
				let n = e.tokens.find((e) => e.id === t.id);
				return n.holder = t.actor, n.room = null, !0;
			}
			case "coalOfferFood": {
				let n = e.tokens.find((e) => e.id === t.id);
				return n.holder = null, n.room = E(e, t.actor).room, !0;
			}
			case "coalGift": {
				at(e, t.actor, t.target, t.id), H(e).flags.giftCards.push(t.id);
				for (let n of e.monsters.filter((n) => n.kind === "coalCreature" && n.room === E(e, t.actor).room)) n.dead = !0;
				let n = L(e, "giftRune", null);
				return e.tokens.find((e) => e.id === n).flags.card = t.id, !0;
			}
			case "coalScroungeResult":
				if (z(t.args, "total") >= 3) {
					let n = L(e, "offeringFood", E(e, t.actor).room), r = e.tokens.find((e) => e.id === n);
					r.flags.tradable = !0, r.flags.unpickableTurn = e.turnNumber;
				}
				return !0;
			case "hauntTurnStart": return t.actor === H(e).traitor && (H(e).flags.luredFood = e.tokens.filter((n) => n.kind === "offeringFood" && n.room && S(e, E(e, t.actor).room, n.room)).map((e) => e.id)), !0;
			case "hauntEnter": return t.actor === H(e).traitor && e.tokens.some((n) => n.kind === "offeringFood" && n.room === E(e, t.actor).room) && j(e, [W(t.actor, "coalEatResult", "sanity")]), !0;
			case "coalEatResult": {
				let n = z(t.args, "total") >= 4;
				return H(e).counters.foodAttackBonus = n ? 1 : 2, e.tokens = e.tokens.filter((n) => n.kind !== "offeringFood" || n.room !== E(e, t.actor).room), j(e, [K(t.actor, n ? 1 : 2, "mental")]), !0;
			}
			case "coalGazeOffer": {
				let n = E(e, t.actor);
				return n.dead || M(e, t.actor, "games.betrayal3.gazeCoalOffer", [...n.cards.filter(na).map((n) => N(n, "games.betrayal3.buryCard", [{
					op: "bury",
					actor: t.actor,
					id: n
				}, {
					op: "coalSummon",
					actor: t.actor,
					id: E(e, t.target).room
				}], n, "card")), N("decline", "games.betrayal3.decline", [])]), !0;
			}
			case "coalSummon": return e.monsters.filter((e) => e.kind === "coalCreature" && !e.dead).length < 20 ? ra(e, t.id) : M(e, t.actor, "games.betrayal3.chooseCoal", e.monsters.filter((e) => e.kind === "coalCreature" && !e.dead).map((e) => N(e.id, "games.betrayal3.moveCoal", [{
				op: "relocate",
				actor: e.id,
				id: t.id
			}], e.id, "token"))), !0;
			case "coalSpoil": return E(e, t.target).dead || j(e, [{
				op: "roll",
				actor: t.actor,
				n: 1,
				args: { context: "coalSpoil" },
				then: [{
					op: "coalBuryItems",
					actor: t.target
				}]
			}]), !0;
			case "coalBuryItems": {
				let n = z(t.args, "total"), r = E(e, t.actor), i = r.cards.filter(na);
				return !n || r.dead || (i.length ? M(e, t.actor, "games.betrayal3.chooseItemToBury", i.map((e) => N(e, "games.betrayal3.buryCard", [{
					op: "bury",
					actor: t.actor,
					id: e
				}, {
					...t,
					args: { total: n - 1 }
				}], e, "card"))) : j(e, [G(t.actor, n, "general")])), !0;
			}
			default: return !1;
		}
	},
	check(e) {
		E(e, H(e).traitor).dead ? X(e) : Z(e);
	}
}, oa = (e) => !h.includes(e);
function sa(e) {
	return e.tokens.filter((e) => e.kind === "presentNumber");
}
function ca(e) {
	return e.tokens.filter((e) => e.kind === "presentWish");
}
function la(e, t) {
	let n = L(e, oa(t) ? "krampusItem" : "krampusOmen", null, e.monsters[0].id), r = e.tokens.find((e) => e.id === n);
	r.hidden = !0, r.flags.card = t;
}
function ua(e, t) {
	for (let n of ca(e).filter((e) => e.value === t.value)) n.hidden = !1, delete n.flags.matchedCard;
	let n = e.items.shift();
	if (!n) {
		t.flags.needsReplacement = !0, t.holder = null, t.hidden = !0;
		return;
	}
	t.flags.card = n, t.flags.available = !0, t.flags.protected = !1, t.holder = null, t.hidden = !0, delete t.flags.needsReplacement;
}
function da(e, t, n) {
	E(e, t).cards.push(String(n.flags.card)), n.holder = t, n.hidden = !1, n.flags.available = !1;
}
var fa = {
	setup(e) {
		let t = H(e).traitor, n = E(e, t);
		for (let t of e.explorers) for (let n of [...t.cards]) oa(n) || I(e, t.rid, n);
		for (let r of [...n.cards]) I(e, t, r);
		n.dead = !0, n.secret.bodyRemoved = !0, H(e).flags.deadTurns = [t], J(e, "krampus", n.room, B(5, 4, 4, 4));
		for (let t = 0; t < $(e, [
			1,
			2,
			3,
			4
		]) && e.omens.length; t++) la(e, e.omens.shift());
		let r = T(e, Array.from({ length: e.players.length + 1 }, (e, t) => t + 1));
		for (let t of e.explorers) L(e, "presentWish", null, t.rid, r.pop());
		H(e).flags.presentJournalAt = e.journal.length, j(e, [{
			op: "krampusSetupCards",
			actor: H(e).revealer
		}, {
			op: "krampusPassWish",
			actor: t
		}]);
	},
	actions(e, t) {
		let n = E(e, t);
		return n.team === "hero" && (An(e, t, "item") || q(e, t, ["armory"])) && !e.tokens.some((e) => e.kind === "presentSearched" && e.room === n.room) ? U(e, t, "findPresent", "games.betrayal3.findPresent", [W(t, "krampusFindResult", "knowledge")]) : [];
	},
	handle(e, t) {
		let n = e.monsters[0];
		if (t.op === "beginTurn" && t.actor === H(e).traitor) return e.turn = t.actor, e.turnNumber++, e.endRequested = !1, H(e).used = [], j(e, [...Un(e), {
			op: "nextTurn",
			actor: t.actor
		}]), !0;
		if (t.op === "roll" && t.actor === n.id && t.args?.krampusBoosted !== !0) return j(e, [{
			op: "krampusBoostOffer",
			actor: n.id,
			n: 0,
			then: [t]
		}]), !0;
		if (t.op === "monsterAct") {
			if (n.dead || n.stunned) return !0;
			let t = Q(e, n);
			return !H(e).used.includes("mineMine") && !pa(e, n.room) && e.omens.length && t.push(N("mineMine", "games.betrayal3.mineMine", [
				{
					op: "hauntUse",
					actor: n.id,
					id: "mineMine"
				},
				{
					op: "krampusDrawOmen",
					actor: n.id
				},
				{
					op: "monsterAct",
					actor: n.id
				}
			])), M(e, n.controller, "games.betrayal3.monsterAction", t), !0;
		}
		if (t.op === "combatResult") {
			let r = z(t.args, "attackTotal") - z(t.args, "total"), i = r > 0 && t.actor === n.id ? t.target : r < 0 && t.target === n.id ? t.actor : null;
			i && e.queue.unshift({
				op: "krampusStealOffer",
				actor: n.controller,
				target: i
			});
		}
		switch (t.op) {
			case "krampusSetupCards": {
				let n = $(e, [
					4,
					5,
					6,
					7
				]);
				if (e.items.length < n) {
					let n = O(e).flatMap((e) => e.cards.filter(oa).map((t) => ({
						owner: e.rid,
						id: t
					})));
					if (!n.length) throw Error("Insufficient Item cards for Krampusnacht");
					return M(e, H(e).revealer, "games.betrayal3.buryForPresents", n.map(({ owner: e, id: n }) => N(n, "games.betrayal3.buryCard", [{
						op: "bury",
						actor: e,
						id: n
					}, t], n, "card"))), !0;
				}
				let r = T(e, Array.from({ length: n }, (e, t) => t + 1));
				for (let t = 0; t < n; t++) {
					let n = L(e, "presentNumber", null, null, r[t]), i = e.tokens.find((e) => e.id === n);
					i.hidden = !0, i.flags.card = e.items.shift(), i.flags.available = !0;
				}
				return !0;
			}
			case "krampusPassWish":
				{
					let n = ca(e).find((e) => !e.hidden && (e.holder === t.actor || e.flags.corpse === t.actor));
					n && M(e, H(e).revealer, "games.betrayal3.passWish", O(e).map((e) => N(e.rid, "games.betrayal3.giveTokenTo", [{
						op: "krampusGiveWish",
						actor: e.rid,
						id: n.id
					}, t], e.rid, "player")));
				}
				return !0;
			case "krampusGiveWish": {
				let n = e.tokens.find((e) => e.id === t.id);
				return n.holder = t.actor, n.room = null, delete n.flags.corpse, !0;
			}
			case "krampusFindResult": return z(t.args, "total") >= 3 && (Y(e, "presentSearched") < 5 && L(e, "presentSearched", E(e, t.actor).room), M(e, t.actor, "games.betrayal3.choosePresent", [...sa(e).filter((e) => e.flags.available === !0 && e.flags.needsReplacement !== !0).map((e) => N(e.id, "games.betrayal3.takePresent", [{
				op: "krampusTakePresent",
				actor: t.actor,
				id: e.id
			}], String(e.flags.card), "card")), ...e.items.length ? [N("top", "games.betrayal3.drawItem", [{
				op: "draw",
				actor: t.actor,
				id: "item"
			}])] : []])), !0;
			case "krampusTakePresent": return da(e, t.actor, e.tokens.find((e) => e.id === t.id)), !0;
			case "krampusDrawOmen": return e.omens.length && la(e, e.omens.shift()), !0;
			case "krampusBoostOffer": {
				let r = t.then[0];
				return M(e, n.controller, "games.betrayal3.boostKrampusRoll", [...e.tokens.filter((e) => e.kind === "krampusItem" || e.kind === "krampusOmen").map((e) => N(e.id, "games.betrayal3.buryHiddenBoost", [{
					op: "krampusSpend",
					actor: n.id,
					id: e.id
				}, {
					...t,
					n: (t.n ?? 0) + 1
				}], e.id, "token")), N("roll", "games.betrayal3.rollWithBoost", [{
					...r,
					args: {
						...r.args,
						extraDice: z(r.args, "extraDice") + (t.n ?? 0),
						krampusBoosted: !0
					}
				}])], { n: t.n ?? 0 }), !0;
			}
			case "krampusSpend": {
				let n = e.tokens.find((e) => e.id === t.id);
				return (n.kind === "krampusItem" ? e.items : e.omens).push(String(n.flags.card)), e.tokens = e.tokens.filter((e) => e.id !== t.id), !0;
			}
			case "krampusStealOffer": {
				let n = E(e, t.target);
				if (n.dead) return !0;
				let r = n.cards.filter((t) => oa(t) && !sa(e).some((r) => r.flags.card === t && (r.flags.protected === !0 || ca(e).some((e) => e.holder === n.rid && e.value === r.value))));
				return M(e, t.actor, "games.betrayal3.stealPresent", [...r.map((e) => N(e, "games.betrayal3.stealItem", [{
					op: "krampusSteal",
					actor: t.actor,
					target: n.rid,
					id: e
				}], e, "card")), N("decline", "games.betrayal3.decline", [])]), !0;
			}
			case "krampusSteal": {
				let n = E(e, t.target), r = sa(e).find((e) => e.flags.card === t.id);
				if (n.cards = n.cards.filter((e) => e !== t.id), la(e, t.id), r) {
					ua(e, r);
					let t = T(e, sa(e).map((e) => e.value));
					sa(e).forEach((e, n) => {
						e.value = t[n], e.hidden = !0;
					});
				}
				return !0;
			}
			case "hauntDeath":
				for (let r of E(e, t.actor).cards.filter(oa)) j(e, [{
					op: "krampusSteal",
					actor: n.controller,
					target: t.actor,
					id: r
				}]);
				return j(e, [{
					op: "krampusPassWish",
					actor: t.actor
				}]), !0;
			default: return !1;
		}
	},
	after(e) {
		for (let t of e.journal.slice(z(H(e).flags, "presentJournalAt"))) {
			if (t.key !== "games.betrayal3.logTrade" || E(e, t.actor)?.team !== "hero" || E(e, t.target)?.team !== "hero") continue;
			let n = sa(e).find((e) => e.flags.card === t.id), r = ca(e).find((e) => e.holder === t.target && e.value === n?.value && !e.hidden);
			n && r && (r.hidden = !0, r.flags.matchedCard = t.id, n.hidden = !0, n.flags.protected = !0);
		}
		H(e).flags.presentJournalAt = e.journal.length;
		for (let t of sa(e)) {
			let n = e.explorers.find((e) => e.cards.includes(String(t.flags.card)));
			n ? (t.holder = n.rid, t.flags.available = !1, t.room = null) : t.flags.available !== !0 && ua(e, t), t.flags.needsReplacement === !0 && e.items.length && ua(e, t);
		}
		for (let t of ca(e)) t.hidden && t.flags.matchedCard && !E(e, t.holder)?.cards.includes(String(t.flags.matchedCard)) && (t.hidden = !1, delete t.flags.matchedCard);
	},
	check(e) {
		ca(e).length && ca(e).every((e) => e.hidden) ? X(e) : (!O(e).length || Y(e, "krampusItem") >= $(e, [
			4,
			5,
			6,
			7
		])) && zn(e);
	}
};
function pa(e, t) {
	let n = y(e, t);
	return !!n.condition || g(n.tile).symbol !== "omen";
}
//#endregion
//#region src/game/haunts/pennywise_henry.ts
function ma(e) {
	let t = O(e);
	H(e).secret.killTarget = t.length ? t[Ye(e, t.length)].rid : "";
}
var ha = {
	setup(e) {
		let t = H(e).traitor, n = E(e, t);
		for (F(e, t), n.secret.henryBowers = !0; et(e, t, "might") < $(e, [
			5,
			5,
			6,
			6
		]) && n.traits.might < 7;) n.traits.might++;
		J(e, "zombieHockstetter", n.room, B(5, 4, 4, 5), {
			death: "kill",
			flags: {
				ai: "manual",
				noAttack: !0
			}
		}), ma(e);
	},
	actions(e, t) {
		let n = E(e, t), r = [];
		if (n.team !== "hero") return r;
		if (An(e, t, "item") && Y(e, "henrySearched") < 5 && !e.tokens.some((e) => e.kind === "henrySearched" && e.room === n.room)) for (let n of ["speed", "knowledge"]) r.push(...U(e, t, "lookWeapon", "games.betrayal3.lookForWeapon", [W(t, "henrySearchResult", n)], n, "trait"));
		return !e.monsters[0].dead && e.monsters[0].room === n.room && r.push(...U(e, t, "banishHockstetter", "games.betrayal3.banishHockstetter", [W(t, "henryBanishResult", "sanity")])), r;
	},
	handle(e, t) {
		let n = e.monsters[0], r = E(e, H(e).traitor);
		if (t.op === "beginTurn" && t.actor === r.rid && t.args?.henryBefore !== !0) return j(e, [{
			op: "henryBefore",
			actor: r.rid
		}, {
			...t,
			args: {
				...t.args,
				henryBefore: !0
			}
		}]), !0;
		if (t.op === "attack" && t.target === r.rid && !n.dead && t.args?.henryGuarded !== !0) {
			let i = {
				...t,
				args: {
					...t.args,
					henryGuarded: !0
				}
			};
			return n.room === r.room ? M(e, r.rid, "games.betrayal3.hockGuard", [N("guard", "games.betrayal3.redirectHock", [{
				...i,
				target: n.id
			}]), N("decline", "games.betrayal3.decline", [i])]) : M(e, r.rid, "games.betrayal3.callHock", [N("call", "games.betrayal3.moveHockCloser", [{
				op: "henryCallHock",
				actor: r.rid,
				n: 3
			}, {
				...t,
				args: {
					...t.args,
					henryCalled: !0
				}
			}]), N("decline", "games.betrayal3.decline", [i])]), t.args?.henryCalled === !0 && n.room !== r.room && (e.prompt = null, j(e, [i])), !0;
		}
		if (t.op === "attack" && t.actor === r.rid && E(e, t.target)?.team === "hero" && (H(e).flags.henryAttacked = !0), t.op === "monsterBegin" && (n.flags.handUsed = !1), t.op === "monsterAct") {
			if (n.dead || n.stunned) return !0;
			let t = Q(e, n);
			return n.room === r.room && n.flags.handUsed !== !0 && (z(n.flags, "movement") > 0 && t.push(N("hand-move", "games.betrayal3.hockMoveHenry", [{
				op: "henryHelpingHand",
				actor: n.id,
				id: "move"
			}, {
				op: "monsterAct",
				actor: n.id
			}])), e.items.length && t.push(N("hand-item", "games.betrayal3.hockGiveItem", [{
				op: "henryHelpingHand",
				actor: n.id,
				id: "item"
			}, {
				op: "monsterAct",
				actor: n.id
			}]))), M(e, n.controller, "games.betrayal3.monsterAction", t), !0;
		}
		switch (t.op) {
			case "henryBefore": return n.dead ? M(e, O(e)[0].rid, "games.betrayal3.placeHock", [...new Set(e.rooms.flatMap((t) => Ve(e, t.floor, t.id)).map((e) => e.room))].map((e) => N(e, "games.betrayal3.placeToken", [{
				op: "henryReturnHock",
				actor: t.actor,
				id: e
			}, {
				op: "henryRunHock",
				actor: t.actor
			}], e, "room"))) : j(e, [{
				op: "henryRunHock",
				actor: t.actor
			}]), !0;
			case "henryReturnHock": return n.dead = !1, n.stunned = !1, n.room = t.id, !0;
			case "henryRunHock": return j(e, Un(e)), !0;
			case "henryHelpingHand":
				if (n.flags.handUsed = !0, t.id === "item") j(e, [{
					op: "draw",
					actor: r.rid,
					id: "item"
				}]);
				else {
					let t = z(n.flags, "movement");
					n.flags.movement = 0, j(e, [{
						op: "hauntMoveSteps",
						actor: r.rid,
						target: r.rid,
						n: t
					}]);
				}
				return !0;
			case "henryCallHock":
				if ((t.n ?? 0) > 0 && n.room !== r.room) {
					let i = C(e, n.room, r.room, !0);
					M(e, r.rid, "games.betrayal3.chooseRoom", [...x(e, n.room, !0).filter((t) => C(e, t, r.room, !0) < i).map((e) => N(e, "games.betrayal3.moveTo", [{
						op: "relocate",
						actor: n.id,
						id: e
					}, {
						...t,
						n: t.n - 1
					}], e, "room")), N("stop", "games.betrayal3.stopMoving", [])]);
				}
				return !0;
			case "henrySearchResult":
				if (L(e, "henrySearched", E(e, t.actor).room), z(t.args, "total") >= 3) {
					let n = e.items.splice(0, 3);
					M(e, t.actor, "games.betrayal3.chooseCardToKeep", n.map((e) => N(e, "games.betrayal3.keepCard", [{
						op: "takeDrawn",
						actor: t.actor,
						id: e,
						args: {
							deck: "item",
							others: n.filter((t) => t !== e)
						}
					}], e, "card")));
				}
				return !0;
			case "henryBanishResult": return z(t.args, "total") >= 5 ? n.dead = !0 : j(e, [G(t.actor, 1, "mental")]), !0;
			case "hauntTurnStart": return t.actor === r.rid && (H(e).flags.henryAttacked = !1), !0;
			case "hauntTurnEnd": return t.actor === r.rid && H(e).flags.henryAttacked !== !0 && j(e, [G(r.rid, 1, "mental")]), !0;
			case "hauntDeath":
				if (t.actor === H(e).secret.killTarget && t.target === r.rid) {
					let n = L(e, "henryVictim", null);
					e.tokens.find((e) => e.id === n).flags.owner = t.actor, M(e, r.rid, "games.betrayal3.healOneTrait", w.map((e) => N(e, "games.betrayal3.healTrait", [{
						op: "heal",
						actor: r.rid,
						args: { traits: [e] }
					}], e, "trait"))), ma(e);
				}
				return !0;
			default: return !1;
		}
	},
	check(e) {
		E(e, H(e).traitor).dead ? X(e) : Z(e);
	}
}, ga = {
	stansHead: {
		stats: B(3, 6, 4, 4),
		attack: "speed"
	},
	itDog: {
		stats: B(6, 3, 4, 4),
		attack: "might"
	},
	ghostShark: {
		stats: B(6, 4, 0, 2),
		attack: "might"
	},
	itWerewolf: {
		stats: B(4, 5, 4, 4),
		attack: "might"
	},
	georgieGhost: {
		stats: B(2, 4, 3, 5),
		attack: "sanity"
	},
	itZombie: {
		stats: B(5, 4, 3, 2),
		attack: "might"
	},
	itVampire: {
		stats: B(5, 5, 3, 5),
		attack: "might"
	},
	itDemon: {
		stats: B(7, 3, 3, 2),
		attack: "might"
	}
}, _a = [
	"ritualRoom",
	"library",
	"specimenRoom",
	"gallery",
	"laboratory"
], va = [
	"entranceHall",
	"hallway",
	"groundStaircase"
];
function ya(e) {
	return e.monsters.find((e) => !e.dead);
}
function ba(e, t) {
	return e.tokens.some((e) => e.kind === "formSearched" && e.room === t);
}
function xa(e, t) {
	let n = E(e, t).room;
	Y(e, "formSearched") < 5 ? L(e, "formSearched", n) : ba(e, n) || M(e, H(e).traitor, "games.betrayal3.moveSearched", e.tokens.filter((e) => e.kind === "formSearched").map((e) => N(e.id, "games.betrayal3.moveTokenHere", [{
		op: "formMoveSearched",
		actor: t,
		id: e.id
	}], e.id, "token")));
}
var Sa = {
	setup(e) {
		let t = E(e, H(e).traitor);
		for (let n of [...t.cards]) I(e, t.rid, n);
		t.dead = !0, t.secret.bodyRemoved = !0, H(e).flags.deadTurns = [t.rid], H(e).flags.remainingForms = Object.keys(ga), H(e).track = $(e, [
			2,
			3,
			4,
			5
		]);
	},
	actions(e, t) {
		let n = E(e, t), r = ya(e), i = [];
		if (r && q(e, t, _a) && !ba(e, n.room) && i.push(...U(e, t, "findWeakness", "games.betrayal3.findWeakness", [W(t, "formWeaknessResult", "knowledge")])), q(e, t, va) && !ba(e, n.room)) for (let n of ["knowledge", "sanity"]) i.push(...U(e, t, "searchKillIt", "games.betrayal3.searchKillIt", [W(t, "formSearchResult", n, -H(e).track)], n, "trait"));
		return r?.stunned && r.room === n.room && i.push(...U(e, t, "banishForm", "games.betrayal3.banishForm", [{
			op: "roll",
			actor: t,
			trait: "sanity",
			args: {
				attack: !0,
				attackTarget: r.id,
				attackSource: t,
				context: "banishForm"
			},
			then: [{
				op: "formBanishAttack",
				actor: t,
				target: r.id
			}]
		}])), i;
	},
	handle(e, t) {
		let n = ya(e), r = e.monsters.find((e) => e.id === t.actor);
		if (t.op === "beginTurn" && t.actor === H(e).traitor) return e.turn = t.actor, e.turnNumber++, e.endRequested = !1, H(e).used = [], H(e).flags.itAttacked = !1, n ? j(e, [
			{
				op: "formRun",
				actor: t.actor
			},
			{
				op: "formEnd",
				actor: t.actor
			},
			{
				op: "nextTurn",
				actor: t.actor
			}
		]) : j(e, [
			{
				op: "formSpawn",
				actor: t.actor
			},
			{
				op: "formRun",
				actor: t.actor
			},
			{
				op: "formEnd",
				actor: t.actor
			},
			{
				op: "nextTurn",
				actor: t.actor
			}
		]), !0;
		if (t.op === "monsterBegin" && r && (r.flags.formAttacks = 0, r.flags.attackOnly = !1, r.flags.noAttack = !1, r.stunned)) return r.stunned = !1, r.flags.attacked = !1, r.flags.movement = H(e).counters[`movement.${r.kind}`], M(e, r.controller, "games.betrayal3.recoverForm", [N("move", "games.betrayal3.recoverMoveOnly", [{
			op: "formRecoverChoice",
			actor: r.id,
			id: "move"
		}, {
			op: "monsterAct",
			actor: r.id
		}]), N("attack", "games.betrayal3.recoverAttackOnly", [{
			op: "formRecoverChoice",
			actor: r.id,
			id: "attack"
		}, {
			op: "monsterAct",
			actor: r.id
		}])]), !0;
		if (t.op === "monsterAct" && r) return !r.dead && !r.stunned && M(e, r.controller, "games.betrayal3.monsterAction", Q(e, r).filter((e) => !(r.flags.attackOnly === !0 && e.id.startsWith("move-")))), !0;
		if (t.op === "attack" && r && (H(e).flags.itAttacked = !0, r.kind === "georgieGhost" && (t.args = {
			...t.args,
			extraDice: z(t.args, "extraDice") + 3
		})), t.op === "monsterAttack" && r && (r.flags.formAttacks = z(r.flags, "formAttacks") + 1, H(e).flags.itAttacked = !0, r.kind === "georgieGhost" && (t.args = {
			...t.args,
			extraDice: z(t.args, "extraDice") + 3
		})), t.op === "rollFeatherResult" && n && e.roll?.actor === t.actor && E(e, t.actor)?.team === "hero" && e.roll.args.attackTarget === n.id && e.roll.args.defense !== !0) {
			for (let t of e.roll.done) t.args = {
				...t.args,
				usedFeather: !0
			};
			n.kind === "ghostShark" && (n.stunned = !0);
		}
		if (t.op === "dynamite" && n?.kind === "ghostShark" && t.id === n.room && (n.stunned = !0), t.op === "combatResult" && n && t.target === n.id && E(e, t.actor)?.team === "hero" && z(t.args, "attackTotal") > z(t.args, "total")) {
			let r = n.kind, i = je.has(t.id ?? ""), a = E(e, t.actor), o = z(t.args, "attackTotal") - z(t.args, "total");
			(r === "stansHead" && i || r === "itDog" && t.trait === "speed" || r === "itWerewolf" && o >= 3 || r === "georgieGhost" && t.trait === "sanity" || r === "itZombie" && !i || r === "itVampire" && (a.cards.some((e) => [
				"dagger",
				"crossbow",
				"holySymbol"
			].includes(e)) || t.args?.usedFeather === !0)) && (n.stunned = !0);
		}
		if (t.op === "characterDamage" && r) return !0;
		switch (t.op) {
			case "formSpawn": {
				let n = H(e).flags.remainingForms, r = n[Ye(e, n.length)];
				return M(e, t.actor, "games.betrayal3.chooseFormRoom", O(e).map((e) => N(e.rid, "games.betrayal3.placeFormWithHero", [{
					op: "formPlace",
					actor: t.actor,
					target: e.rid,
					id: r
				}], e.rid, "player"))), !0;
			}
			case "formPlace": {
				let n = ga[t.id];
				return J(e, t.id, E(e, t.target).room, { ...n.stats }, {
					death: "immune",
					attack: n.attack,
					damage: n.attack === "sanity" ? "mental" : "physical"
				}), H(e).secret.currentWeakness = t.id, !0;
			}
			case "formRun": return n && j(e, Un(e, [n.id])), !0;
			case "formRecoverChoice": return r.flags.attackOnly = t.id === "attack", r.flags.noAttack = t.id === "move", !0;
			case "formWeaknessResult":
				if (z(t.args, "total") >= 5 && n && (Y(e, "formSearched") < 5 && L(e, "formSearched", E(e, t.actor).room), !e.tokens.some((e) => e.kind === "knownWeakness" && e.flags.form === n.kind))) {
					let t = L(e, "knownWeakness", null);
					e.tokens.find((e) => e.id === t).flags.form = n.kind;
				}
				return !0;
			case "formSearchResult": return j(e, [{
				op: "formPlaceSearched",
				actor: t.actor
			}, ...z(t.args, "total") >= 4 ? [{
				op: "formChooseDeck",
				actor: t.actor
			}] : []]), !0;
			case "formPlaceSearched": return xa(e, t.actor), !0;
			case "formMoveSearched": return e.tokens.find((e) => e.id === t.id).room = E(e, t.actor).room, !0;
			case "formChooseDeck": return M(e, t.actor, "games.betrayal3.chooseDeck", ["item", "omen"].filter((t) => (t === "item" ? e.items : e.omens).length).map((e) => N(e, "games.betrayal3.drawFromDeck", [{
				op: "formSearchCards",
				actor: t.actor,
				id: e
			}], e, "card"))), !0;
			case "formSearchCards": {
				let n = (t.id === "item" ? e.items : e.omens).splice(0, 3);
				return M(e, t.actor, "games.betrayal3.chooseCardToKeep", n.map((e) => N(e, "games.betrayal3.keepCard", [{
					op: "takeDrawn",
					actor: t.actor,
					id: e,
					args: {
						deck: t.id,
						others: n.filter((t) => t !== e),
						noHaunt: !0
					}
				}], e, "card"))), !0;
			}
			case "formBanishAttack": return j(e, [{
				op: "roll",
				actor: t.target,
				trait: "sanity",
				args: {
					attack: !0,
					defense: !0,
					context: "banishForm"
				},
				then: [{
					op: "formBanishResult",
					actor: t.actor,
					target: t.target,
					n: z(t.args, "total")
				}]
			}]), !0;
			case "formBanishResult":
				if (t.n > z(t.args, "total")) {
					let n = e.monsters.find((e) => e.id === t.target);
					n.dead = !0, H(e).flags.remainingForms = H(e).flags.remainingForms.filter((e) => e !== n.kind), H(e).track--, H(e).track <= 0 && X(e);
				} else e.endRequested = !0;
				return !0;
			case "formEnd": return (n?.kind === "itDog" && H(e).flags.itAttacked !== !0 || n?.kind === "itDemon" && !O(e).some((t) => y(e, t.room).floor === y(e, n.room).floor)) && (n.stunned = !0), H(e).flags.itAttacked === !0 && j(e, [{
				op: "roll",
				actor: t.actor,
				n: 1,
				args: { context: "formFear" },
				then: [{
					op: "formShareFear",
					actor: t.actor
				}]
			}]), !0;
			case "formShareFear":
				if (z(t.args, "total") > 0) M(e, O(e)[0].rid, "games.betrayal3.shareFormFear", O(e).map((e) => N(e.rid, "games.betrayal3.takeMentalPoint", [{
					...t,
					args: {
						total: z(t.args, "total") - 1,
						allocations: [...t.args?.allocations ?? [], e.rid]
					}
				}], e.rid, "player")));
				else {
					let n = t.args?.allocations ?? [];
					j(e, [...new Set(n)].map((e) => G(e, n.filter((t) => t === e).length, "mental")));
				}
				return !0;
			case "hauntDeath":
				for (let n of [...E(e, t.actor).cards]) I(e, t.actor, n);
				return n && !O(e).some((t) => y(e, t.room).floor === y(e, n.room).floor) && M(e, H(e).traitor, "games.betrayal3.withdrawForm", [N("withdraw", "games.betrayal3.withdrawIt", [{
					op: "formWithdraw",
					actor: n.id
				}]), N("stay", "games.betrayal3.stayHere", [])]), !0;
			case "formWithdraw": return r.dead = !0, !0;
			default: return !1;
		}
	},
	after(e, t) {
		let n = ya(e);
		t.op === "monsterAttack" && n?.kind === "itWerewolf" && z(n.flags, "formAttacks") < 2 && (n.flags.attacked = !1);
	},
	check: Z
}, Ca = [
	"oldWell",
	"ancientDen",
	"ritualRoom",
	"nursery",
	"bloodyRoom"
];
function wa(e, t) {
	let n = e.tokens.find((e) => e.kind === "pennyTarget");
	n.holder = t, n.room = null, delete n.flags.corpse, H(e).flags.target = t, H(e).id === "pennywise4" && (H(e).monsterAfter = t);
}
function Ta(e, t) {
	let n = Qe(e, t);
	for (; E(e, n).dead && n !== t;) n = Qe(e, n);
	return n;
}
function Ea(e, t) {
	let n = e.monsters[0], r = E(e, String(H(e).flags.target));
	if (n.stunned || !r || r.dead || n.room === r.room || (t.n ?? 0) <= 0) return;
	let i = O(e).some((e) => e.room === n.room) ? 2 : 1, a = C(e, n.room, r.room, !0);
	t.n < i || M(e, t.actor, "games.betrayal3.monsterAction", x(e, n.room, !0).filter((t) => C(e, t, r.room, !0) < a).map((e) => N(e, "games.betrayal3.moveTo", [{
		op: "relocate",
		actor: n.id,
		id: e
	}, {
		...t,
		n: t.n - i
	}], e, "room")));
}
function Da(e) {
	return e.tokens.filter((e) => e.kind === "personalArtifact");
}
var Oa = {
	setup(e) {
		let t = H(e).revealer, n = Qe(e, t);
		J(e, "pennywiseClown", E(e, t).room, B(5, 4, 5, 4), { death: "immune" }), L(e, "pennyTarget", null, n), wa(e, n), H(e).flags.firstPlayer = n;
		for (let t of e.explorers) {
			let n = L(e, "personalArtifact", null, null, 0);
			e.tokens.find((e) => e.id === n).flags.owner = t.rid;
		}
		if (Ca.every((t) => e.rooms.some((e) => e.id === t))) {
			let n = Ca.map((t) => ({
				id: t,
				score: e.rooms.flatMap(b).filter((n) => n !== t && Number.isFinite(C(e, n, t))).length + e.explorers.filter((e) => e.room === t).length * 100
			})), r = Math.min(...n.map((e) => e.score));
			j(e, [{
				op: "chudRemoveRoomPrompt",
				actor: t,
				args: { rooms: n.filter((e) => e.score === r).map((e) => e.id) }
			}]);
		}
	},
	actions(e, t) {
		let n = E(e, t), r = [], i = e.tokens.find((e) => e.kind === "chudAltar");
		if (i?.room === n.room && e.monsters[0].room !== n.room) for (let n of Da(e).filter((n) => n.holder === t && (n.flags.owner === t || E(e, String(n.flags.owner)).dead))) r.push(...U(e, t, "depositArtifact", "games.betrayal3.depositArtifact", [W(t, "chudDepositResult", "sanity", 0, { artifact: n.id })], n.id, "token"));
		return i?.room === n.room && Da(e).every((e) => e.value === 2) && r.push(...U(e, t, "completeRitual", "games.betrayal3.completeRitual", [{
			op: "chudRitual",
			actor: t
		}])), r;
	},
	filterActions(e, t, n) {
		let r = E(e, t);
		return n.filter((t) => !t.tasks.some((t) => (t.op === "attack" && t.target === e.monsters[0].id || [
			"move",
			"dynamite",
			"relocate"
		].includes(t.op) && t.id === e.monsters[0].room) && r.secret.pennyFearFailed === e.turnNumber));
	},
	handle(e, t) {
		let n = e.monsters[0], r = E(e, t.actor);
		if (t.op === "roll" && t.args?.event === !0 && (t.args = {
			...t.args,
			ignoreHighest: !0
		}), r && !r.dead && (t.op === "attack" && t.target === n.id || t.op === "dynamite" && t.id === n.room || t.op === "relocate" && t.id === n.room) && r.secret.pennyFearPassed !== e.turnNumber) return r.secret.pennyFearFailed !== e.turnNumber && j(e, [{
			op: "roll",
			actor: r.rid,
			trait: "sanity",
			args: { context: "facePennywise" },
			then: [{
				op: "chudFearResult",
				actor: r.rid,
				then: [t]
			}]
		}]), !0;
		if (t.op === "characterDamage" && t.actor === n.id && (t.n ?? 0) > 0) return j(e, [{
			op: "hauntMoveSteps",
			actor: t.target ?? H(e).revealer,
			target: n.id,
			n: t.n
		}]), !0;
		if (t.op === "monsterAct") {
			if (n.stunned || n.dead) return !0;
			let t = E(e, String(H(e).flags.target));
			return n.room === t.room ? n.flags.attacked !== !0 && j(e, [{
				op: "monsterAttack",
				actor: n.id,
				target: t.rid
			}]) : z(n.flags, "movement") > 0 && j(e, [{
				op: "pennyChudMove",
				actor: n.controller,
				n: z(n.flags, "movement")
			}, {
				op: "chudAttackTarget",
				actor: n.id
			}]), !0;
		}
		if (t.op === "roomCards") {
			let n = y(e, r.room), i = !n.condition && g(n.tile).symbol;
			if (i && (i.startsWith("item") || i === "omen") && e.endRequested) {
				let n = Da(e).filter((t) => t.value === 0 && (t.flags.owner === r.rid || E(e, String(t.flags.owner)).dead));
				if (n.length && t.args?.artifactOffered !== !0) return M(e, r.rid, "games.betrayal3.findArtifactInstead", [...n.map((e) => N(e.id, "games.betrayal3.findArtifact", [{
					op: "chudFindArtifact",
					actor: r.rid,
					id: e.id
				}], e.id, "token")), N("draw", "games.betrayal3.drawRoomCard", [{
					...t,
					args: {
						...t.args,
						artifactOffered: !0
					}
				}])]), !0;
			}
		}
		switch (t.op) {
			case "chudFearResult": return z(t.args, "total") >= 5 ? (r.secret.pennyFearPassed = e.turnNumber, j(e, t.then)) : r.secret.pennyFearFailed = e.turnNumber, !0;
			case "pennyChudMove": return Ea(e, t), !0;
			case "chudAttackTarget": {
				let t = E(e, String(H(e).flags.target));
				return t.room === n.room && !t.dead && j(e, [{
					op: "monsterAttack",
					actor: n.id,
					target: t.rid
				}]), !0;
			}
			case "chudRemoveRoomPrompt": return M(e, t.actor, "games.betrayal3.returnRitualRoom", t.args.rooms.map((e) => N(e, "games.betrayal3.returnRoomToDeck", [{
				op: "chudRemoveRoom",
				actor: t.actor,
				id: e
			}], e, "room"))), !0;
			case "chudRemoveRoom": {
				let n = y(e, t.id), r = x(e, n.id)[0] ?? "groundStaircase";
				for (let t of e.explorers) t.room === n.id && (t.room = r);
				for (let t of e.monsters) t.room === n.id && (t.room = r);
				for (let t of e.tokens) t.room === n.id && (t.room = r);
				return e.rooms = e.rooms.filter((e) => e.id !== n.id), e.tiles = T(e, [...e.tiles, n.tile]), !0;
			}
			case "chudFindArtifact": {
				let n = e.tokens.find((e) => e.id === t.id);
				return n.holder = t.actor, n.value = 1, n.flags.tradable = E(e, String(n.flags.owner)).dead, !0;
			}
			case "chudDepositResult":
				if (z(t.args, "total") >= 4) {
					let n = e.tokens.find((e) => e.id === t.args.artifact);
					n.holder = null, n.room = e.tokens.find((e) => e.kind === "chudAltar").room, n.value = 2, n.flags.tradable = !1;
				} else wa(e, t.actor), e.endRequested = !0;
				return !0;
			case "chudRitual": return wa(e, t.actor), H(e).counters.ritualTotal = 0, j(e, [...O(e).map((e) => ({
				op: "roll",
				actor: e.rid,
				n: 1,
				args: { context: "ritualChud" },
				then: [{
					op: "chudRitualAdd",
					actor: e.rid
				}]
			})), {
				op: "chudRitualResult",
				actor: t.actor,
				n: O(e).length
			}]), !0;
			case "chudRitualAdd": return H(e).counters.ritualTotal += z(t.args, "total"), !0;
			case "chudRitualResult": return H(e).counters.ritualTotal >= t.n ? X(e) : j(e, [G(t.actor, t.n, "mental")]), !0;
			case "hauntDeath":
				for (let n of Da(e).filter((e) => e.flags.owner === t.actor && e.value === 1)) n.flags.tradable = !0;
				return H(e).flags.target === t.actor && O(e).length && wa(e, Ta(e, t.actor)), !0;
			default: return !1;
		}
	},
	after(e, t) {
		if (t.op === "placeDiscovered") {
			let n = E(e, t.actor), r = y(e, n.room);
			g(r.tile).symbol?.startsWith("event") && wa(e, n.rid), Ca.includes(r.tile) && (wa(e, n.rid), e.tokens.some((e) => e.kind === "chudAltar") || L(e, "chudAltar", n.room));
		}
	},
	check(e) {
		O(e).length || pt(e, [], "pennywise4.lost");
	}
}, ka = {
	setup(e) {
		H(e).track = $(e, [
			5,
			6,
			7,
			8
		]), e.encounters = T(e, De), e.encountersOut = [];
		let t = Qe(e, H(e).revealer);
		L(e, "pennyTarget", null, t), wa(e, t), H(e).flags.firstPlayer = t, J(e, "pennywiseSpider", E(e, H(e).revealer).room, B(6, 6, 6, 6));
	},
	actions(e, t) {
		let n = E(e, t), r = e.monsters[0], i = [];
		if (S(e, n.room, r.room)) for (let r of ["knowledge", "sanity"]) i.push(...U(e, t, "tauntPennywise", "games.betrayal3.tauntPennywise", [W(t, "clownTauntResult", r, +(n.room === E(e, String(H(e).flags.target)).room))], r, "trait"));
		return r.stunned && n.room === r.room && i.push(...U(e, t, "crushPennywise", "games.betrayal3.crushPennywise", [{
			op: "roll",
			actor: t,
			trait: "might",
			args: {
				noItems: !0,
				context: "crushPennywise",
				bonus: O(e).filter((e) => e.rid !== t && e.room === n.room).length - H(e).track
			},
			then: [{
				op: "clownCrushResult",
				actor: t
			}]
		}])), i;
	},
	handle(e, t) {
		let n = e.monsters[0];
		if (t.op === "beginTurn" && E(e, t.actor).secret.deadlightsStunned === !0) return E(e, t.actor).secret.deadlightsStunned = !1, e.turn = t.actor, e.turnNumber++, e.endRequested = !1, j(e, [{
			op: "hauntTurnEnd",
			actor: t.actor
		}, {
			op: "nextTurn",
			actor: t.actor
		}]), !0;
		switch (t.op === "attack" && t.actor === n.id && E(e, t.target)?.secret.deadlightsStunned === !0 && (t.args = {
			...t.args,
			extraDice: z(t.args, "extraDice") + 2
		}), t.op) {
			case "hauntTurnEnd": return E(e, t.actor).dead || j(e, [{
				op: "clownEncounter",
				actor: t.actor
			}]), !0;
			case "clownEncounter": {
				if (n.stunned) return n.stunned = !1, !0;
				e.encounters.length || (e.encounters = T(e, e.encountersOut), e.encountersOut = []);
				let r = e.encounters.shift();
				return e.encountersOut.push(r), j(e, [{
					op: "hauntEncounter",
					actor: t.actor,
					id: r
				}]), !0;
			}
			case "hauntEncounter":
				if (A(e, {
					key: "games.betrayal3.logEncounter",
					actor: t.actor,
					id: t.id
				}), [
					"floatingLights",
					"hometownHorrors",
					"swirlingVisions",
					"stretchingHall"
				].includes(t.id)) for (let t of O(e).filter((t) => S(e, t.room, n.room))) t.secret.deadlightsStunned = !0;
				else if (t.id === "knifeInDark" || t.id === "bloodTendrils") e.encounters = T(e, [...e.encounters, ...e.encountersOut]), e.encountersOut = [], M(e, t.actor, "games.betrayal3.chooseClownVictim", O(e).filter((e) => e.room === n.room).map((e) => N(e.rid, "games.betrayal3.attackUnarmed", [{
					op: "attack",
					actor: n.id,
					target: e.rid,
					trait: "might",
					damage: "physical"
				}], e.rid, "player")));
				else {
					let r = t.id === "goodBoy" || t.id === "timeToSink";
					r && wa(e, t.actor), j(e, [{
						op: "roll",
						actor: n.id,
						n: 3,
						args: { context: "pennywiseMovement" },
						then: [{
							op: "clownMoveResult",
							actor: t.actor
						}]
					}, ...r ? [] : [{
						op: "clownAttackTarget",
						actor: t.actor
					}, {
						op: "clownEncounter",
						actor: t.actor
					}]]);
				}
				return !0;
			case "clownMoveResult": return j(e, [{
				op: "pennyClownMove",
				actor: t.actor,
				n: z(t.args, "total")
			}]), !0;
			case "pennyClownMove": return Ea(e, t), !0;
			case "clownAttackTarget": {
				let t = E(e, String(H(e).flags.target));
				return !n.stunned && !t.dead && t.room === n.room && j(e, [{
					op: "attack",
					actor: n.id,
					target: t.rid,
					trait: "might",
					damage: "physical"
				}]), !0;
			}
			case "clownTauntResult": return z(t.args, "total") >= 4 ? (wa(e, t.actor), H(e).track = Math.max(1, H(e).track - 1)) : e.endRequested = !0, !0;
			case "clownCrushResult": return z(t.args, "total") >= 5 ? X(e) : (wa(e, t.actor), H(e).track = Math.min(9, H(e).track + 1)), !0;
			case "hauntDeath": return H(e).flags.target === t.actor && O(e).length && wa(e, Ta(e, t.actor)), !0;
			default: return !1;
		}
	},
	check(e) {
		D(e).length || pt(e, [], "pennywise5.lost");
	}
}, Aa = {
	armory: 4,
	nursery: 5,
	organRoom: 4,
	conservatory: 4,
	crawlspace: 3,
	diningRoom: 4,
	graveyard: 5,
	tower: 5,
	undergroundCavern: 6,
	larder: 4
}, ja = {
	ballroom: "nightmareGhost",
	primaryBedroom: "nightmareHair",
	ritualRoom: "nightmareDemon",
	specimenRoom: "nightmareWasp",
	statuaryCorridor: "nightmareFaceless",
	junkRoom: "nightmareConstruct",
	kitchen: "nightmareZombie",
	undergroundLake: "nightmareShark"
}, Ma = {
	bloodyRoom: {
		trait: "might",
		threshold: 5,
		n: 1,
		kind: "mental",
		dice: !0
	},
	furnaceRoom: {
		trait: "knowledge",
		threshold: 4,
		n: 0,
		kind: "physical",
		bury: !0
	},
	catacombs: {
		trait: "knowledge",
		threshold: 5,
		n: 2,
		kind: "physical"
	},
	laboratory: {
		trait: "speed",
		threshold: 5,
		n: 1,
		kind: "physical"
	},
	charredRoom: {
		trait: "speed",
		threshold: 5,
		n: 1,
		kind: "physical",
		dice: !0
	},
	laundryChute: {
		trait: "knowledge",
		threshold: 6,
		n: 0,
		kind: "physical"
	},
	chasm: {
		trait: "speed",
		threshold: 5,
		n: 1,
		kind: "mental"
	},
	observatory: {
		trait: "knowledge",
		threshold: 5,
		n: 2,
		kind: "mental"
	},
	collapsedRoom: {
		trait: "might",
		threshold: 5,
		n: 1,
		kind: "physical"
	},
	operatingTheatre: {
		trait: "might",
		threshold: 5,
		n: 1,
		kind: "physical",
		dice: !0
	},
	crampedPassageway: {
		trait: "speed",
		threshold: 5,
		n: 1,
		kind: "physical"
	},
	vault: {
		trait: "knowledge",
		threshold: 5,
		n: 1,
		kind: "mental"
	}
};
function Na(e, t) {
	return e.monsters.filter((e) => e.kind === "tinyTerror" && !e.dead && (!t || e.room === t));
}
function Pa(e, t) {
	let n = /* @__PURE__ */ new Set([v(t)]), r = [v(t)];
	for (; r.length;) for (let t of b(y(e, r.shift()))) for (let i of Re(e, t)) n.has(v(i)) || (n.add(v(i)), r.push(v(i)));
	return n;
}
function Fa(e, t) {
	let n = Pa(e, t), r = Pa(e, "entranceHall");
	if ([...n].some((e) => r.has(e))) return [];
	let i = {
		...e,
		rooms: e.rooms.filter((e) => !n.has(e.id))
	}, a = [];
	for (let t of Ve(i, "G").filter((e) => r.has(v(e.room)))) for (let r of e.rooms.filter((e) => n.has(e.id))) {
		if (!Fe(r).includes((t.direction + 2) % 4)) continue;
		let o = t.x - r.x, s = t.y - r.y;
		e.rooms.filter((e) => n.has(e.id)).some((e) => Le(i, "G", e.x + o, e.y + s)) || a.some((e) => e.dx === o && e.dy === s) || a.push({
			dx: o,
			dy: s
		});
	}
	return a;
}
function Ia(e, t, n, r) {
	let i = Math.min(n, 20 - Na(e).length);
	for (let n = 0; n < i; n++) J(e, "tinyTerror", t, B(1, 5, 3, 2), { death: "immune" });
	i < n && j(e, [{
		op: "nightmareMoveTiny",
		actor: r,
		id: t,
		n: n - i
	}]);
}
function La(e, t) {
	return !O(e).some((n) => S(e, n.room, t));
}
var Ra = {
	setup(e) {
		let t = H(e).traitor, n = E(e, t);
		Ia(e, n.room, 5, t), n.dead = !0, n.secret.bodyRemoved = !0, H(e).flags.deadTurns = [t], H(e).track = $(e, [
			6,
			7,
			8,
			9
		]), e.events = [];
		let r = e.rooms.filter((t) => Mn.includes(t.id) || O(e).some((e) => v(e.room) === t.id) || e.monsters.some((e) => !e.dead && v(e.room) === t.id));
		e.tiles = T(e, [...e.tiles, ...e.rooms.filter((e) => !r.includes(e)).map((e) => e.tile)]), e.tokens = e.tokens.filter((e) => !e.room || r.some((t) => t.id === v(e.room)));
		let i = 1;
		e.rooms = r.map((e) => [
			"entranceHall",
			"hallway",
			"groundStaircase"
		].includes(e.id) ? {
			...e,
			floor: "G",
			x: e.id === "entranceHall" ? 2 : +(e.id === "hallway"),
			y: 0
		} : {
			...e,
			floor: "G",
			x: i++ * 10,
			y: 0
		});
	},
	actions(e, t) {
		let n = [];
		if (Fa(e, E(e, t).room).length) for (let r of ["knowledge", "sanity"]) n.push(...U(e, t, "wayThrough", "games.betrayal3.findWayThrough", [W(t, "nightmareThroughResult", r, -H(e).track)], r, "trait"));
		if (q(e, t, [
			"entranceHall",
			"hallway",
			"groundStaircase"
		])) for (let r of ["knowledge", "sanity"]) n.push(...U(e, t, "helpHero", "games.betrayal3.helpAnotherHero", [W(t, "nightmareHelpResult", r, -H(e).track)], r, "trait"));
		return O(e).every((e) => e.room === "entranceHall") && n.push(...U(e, t, "wayOut", "games.betrayal3.findWayOut", [{
			op: "nightmareEscape",
			actor: t
		}])), n;
	},
	filterActions(e, t, n) {
		return n.filter((t) => !t.tasks.some((t) => t.op === "attack" && Na(e).some((n) => n.id === t.target && Na(e, n.room)[0].id !== n.id)));
	},
	handle(e, t) {
		let n = e.monsters.find((e) => e.id === t.actor);
		if (t.op === "placeRoom" && (t.args = {
			...t.args,
			floor: "G"
		}), t.op === "beginTurn" && t.actor === H(e).traitor) return e.turn = t.actor, e.turnNumber++, e.endRequested = !1, H(e).used = [], j(e, [
			...Un(e, Na(e).map((e) => e.id)),
			{
				op: "nightmareTinyAttackStart",
				actor: t.actor
			},
			{
				op: "nightmareHugeStart",
				actor: t.actor
			},
			{
				op: "nightmareHideStart",
				actor: t.actor
			},
			{
				op: "nextTurn",
				actor: t.actor
			}
		]), !0;
		if (t.op === "monsterAct" && n?.kind === "tinyTerror") return n.dead || M(e, n.controller, "games.betrayal3.monsterAction", Q(e, n).filter((e) => !e.id.startsWith("attack-"))), !0;
		if (t.op === "roll" && n && ["nightmareZombie", "nightmareConstruct"].includes(n.kind) && t.trait === "might" && (t.args = {
			...t.args,
			bonus: z(t.args, "bonus") + 1
		}), t.op === "monsterAttack" && n && (n.flags.attacking = !0), t.op === "monsterAct" && n && (n.flags.attacking = !1), t.op === "characterDamage" && n && (n.kind === "tinyTerror" || n.flags.attacking === !0 || ["nightmareGhost", "nightmareShark"].includes(n.kind))) return !0;
		if (t.op === "combatResult") {
			let r = n?.kind === "tinyTerror" ? n : e.monsters.find((e) => e.id === t.target && e.kind === "tinyTerror");
			r && e.queue.unshift({
				op: "nightmareRemoveTiny",
				actor: H(e).traitor,
				id: r.room
			});
		}
		if (t.op === "dynamite") for (let n of Na(e, t.id)) n.dead = !0;
		if (t.op === "draw" && t.id === "event") return !0;
		if (t.op === "roomCards") {
			let n = g(t.id).symbol;
			if (n?.startsWith("event")) return H(e).track = Math.max(0, H(e).track - (n === "event2" ? 2 : 1)), !0;
		}
		if (t.op === "roomEnd" && E(e, t.actor).secret.nightmareStayLaundry === e.turnNumber) return !0;
		if (t.op === "elevatorResult") {
			if (![2, 4].includes(z(t.args, "total"))) return !0;
			let n = {
				...e,
				rooms: e.rooms.filter((e) => e.id !== "mysticElevator")
			};
			return M(e, t.actor, "games.betrayal3.chooseElevatorDoor", Ve(n, "G").map((e) => {
				let n = N(`${e.x},${e.y}`, "games.betrayal3.moveElevatorTo", [{
					op: "elevatorMove",
					actor: t.actor,
					args: {
						floor: "G",
						x: e.x,
						y: e.y,
						rotation: (e.direction + 2) % 4
					}
				}], e.room, "room");
				return n.params = { direction: Ne[e.direction] }, n;
			})), !0;
		}
		switch (t.op) {
			case "nightmareMoveTiny": return t.n && M(e, t.actor, "games.betrayal3.chooseTinyToMove", Na(e).filter((e) => e.room !== t.id).map((e) => N(e.id, "games.betrayal3.moveTerrorHere", [{
				op: "relocate",
				actor: e.id,
				id: t.id
			}, {
				...t,
				n: t.n - 1
			}], e.id, "token"))), !0;
			case "nightmareEvaluate": {
				if (Aa[t.id] && Ia(e, E(e, t.actor).room, Aa[t.id], H(e).traitor), ja[t.id]) {
					let n = ja[t.id], r = ["nightmareHair", "nightmareWasp"].includes(n) ? "speed" : ["nightmareDemon", "nightmareFaceless"].includes(n) ? "sanity" : "might";
					J(e, n, E(e, t.actor).room, B(5, 4, 4, 4), {
						attack: r,
						damage: r === "sanity" ? "mental" : "physical",
						flags: {
							ai: "manual",
							walls: ["nightmareGhost", "nightmareShark"].includes(n)
						}
					});
				}
				let n = Ma[t.id];
				return n && j(e, [W(t.actor, "nightmareChallengeResult", n.trait, 0, { room: t.id })]), !0;
			}
			case "nightmareChallengeResult": {
				let n = String(t.args.room), r = Ma[n];
				return z(t.args, "total") >= r.threshold || (e.queue = e.queue.filter((e) => !(e.actor === t.actor && [
					"roomDiscover",
					"roomEnter",
					"roomCards"
				].includes(e.op) && e.id === n)), n === "laundryChute" && (E(e, t.actor).secret.nightmareStayLaundry = e.turnNumber), e.endRequested = !0, r.n && j(e, [r.dice ? K(t.actor, r.n, r.kind) : G(t.actor, r.n, r.kind)]), r.bury && M(e, t.actor, "games.betrayal3.chooseCardToBury", E(e, t.actor).cards.map((e) => N(e, "games.betrayal3.buryCard", [{
					op: "bury",
					actor: t.actor,
					id: e
				}], e, "card"))), !0);
			}
			case "nightmareThroughResult": return z(t.args, "total") >= 4 && M(e, H(e).traitor, "games.betrayal3.connectRoomGroup", Fa(e, E(e, t.actor).room).map((n) => {
				let r = N(`${n.dx}:${n.dy}`, "games.betrayal3.connectThisGroup", [{
					op: "nightmareConnect",
					actor: t.actor,
					args: n
				}], E(e, t.actor).room, "room");
				return r.params = n, r;
			})), !0;
			case "nightmareConnect": {
				let n = Pa(e, E(e, t.actor).room);
				for (let r of e.rooms.filter((e) => n.has(e.id))) r.x += z(t.args, "dx"), r.y += z(t.args, "dy");
				return !0;
			}
			case "nightmareHelpResult": return z(t.args, "total") >= 4 && M(e, t.actor, "games.betrayal3.chooseHeroToHelp", O(e).filter((e) => e.rid !== t.actor).map((e) => N(e.rid, "games.betrayal3.moveToHero", [{
				op: "relocate",
				actor: t.actor,
				id: e.room
			}, {
				op: "nightmareEndHero",
				actor: t.actor
			}], e.rid, "player"))), !0;
			case "nightmareEndHero": return e.endRequested = !0, !0;
			case "nightmareEscape": return H(e).flags.escapeRolls = [], j(e, [...O(e).map((e) => W(e.rid, "nightmareEscapeAdd", "sanity")), {
				op: "nightmareEscapeResult",
				actor: t.actor
			}]), !0;
			case "nightmareEscapeAdd": return H(e).flags.escapeRolls.push(z(t.args, "total")), !0;
			case "nightmareEscapeResult": {
				let t = H(e).flags.escapeRolls;
				return Math.min(...t) + Math.max(...t) >= 8 && X(e), !0;
			}
			case "nightmareTinyAttackStart": return H(e).flags.tinyAttackRooms = [...new Set(Na(e).map((e) => e.room))], j(e, [{
				op: "nightmareTinyAttackNext",
				actor: t.actor
			}]), !0;
			case "nightmareTinyAttackNext": {
				let n = H(e).flags.tinyAttackRooms.shift();
				if (!n) return !0;
				let r = Na(e, n)[0], i = O(e).filter((e) => e.room === n);
				return !r || !i.length ? j(e, [t]) : M(e, t.actor, "games.betrayal3.chooseTinyVictim", i.map((e) => N(e.rid, "games.betrayal3.attackUnarmed", [{
					op: "attack",
					actor: r.id,
					target: e.rid,
					trait: "might",
					damage: "physical"
				}, t], e.rid, "player"))), !0;
			}
			case "nightmareRemoveTiny": {
				let n = Na(e, t.id)[0];
				return n && (n.dead = !0), !0;
			}
			case "nightmareHugeStart": return j(e, e.monsters.filter((e) => !e.dead && e.kind !== "tinyTerror").flatMap((t) => Un(e, [t.id]))), !0;
			case "nightmareHideStart": return j(e, [...e.monsters.filter((e) => !e.dead && e.kind !== "tinyTerror"), ...[...new Set(Na(e).map((e) => e.room))].map((t) => Na(e, t)[0])].map((e) => ({
				op: "nightmareHide",
				actor: t.actor,
				id: e.id
			}))), !0;
			case "nightmareHide": {
				let n = e.monsters.find((e) => e.id === t.id);
				return !n.dead && La(e, n.room) && M(e, t.actor, "games.betrayal3.moveUnseenHorror", [...e.rooms.flatMap(b).filter((t) => La(e, t) && t !== n.room).map((e) => N(e, "games.betrayal3.moveTo", [{
					op: "nightmareHideMove",
					actor: n.id,
					id: e
				}], e, "room")), N("stay", "games.betrayal3.stayHere", [])]), !0;
			}
			case "nightmareHideMove":
				if (n.kind === "tinyTerror") for (let r of Na(e, n.room)) r.room = t.id;
				else n.room = t.id;
				return !0;
			default: return !1;
		}
	},
	after(e, t) {
		for (let t of Na(e)) t.traits.might = Math.min(6, Na(e, t.room).length);
		t.op === "placeDiscovered" && j(e, [{
			op: "nightmareEvaluate",
			actor: t.actor,
			id: y(e, E(e, t.actor).room).tile
		}]), t.op === "placeRequired" && (y(e, t.id).floor = "G");
	},
	check: Z
}, za = {
	1: Yn,
	2: rr,
	3: or,
	4: Xn,
	5: Zn,
	6: cr,
	7: lr,
	8: dr,
	9: hr,
	10: gr,
	11: xr,
	12: Sr,
	13: Cr,
	14: wr,
	15: Tr,
	16: Er,
	17: Dr,
	18: Nr,
	19: Or,
	20: Ar,
	21: Fr,
	22: Lr,
	23: Rr,
	24: Br,
	25: Hr,
	26: Wr,
	27: Kr,
	28: qr,
	29: Jr,
	30: Zr,
	31: ei,
	32: ti,
	33: ni,
	34: ii,
	35: ai,
	36: si,
	37: ci,
	38: li,
	39: ui,
	40: di,
	41: fi,
	42: hi,
	43: gi,
	44: Si,
	45: Ci,
	46: wi,
	47: Ti,
	48: Ei,
	49: Di,
	50: Oi
};
function Ba(e) {
	let t = za[e];
	if (!t) throw Error(`Haunt ${e} is not implemented; this development source is not ready for registration or publication`);
	return t;
}
Object.assign(za, {
	blood1: ki,
	blood2: ji,
	blood3: Hi,
	blood4: Mi,
	blood5: Fi
}), Object.assign(za, {
	yuletide1: Ji,
	yuletide2: Xi,
	yuletide3: ta,
	yuletide4: aa,
	yuletide5: fa
}), Object.assign(za, {
	pennywise1: ha,
	pennywise2: Ra,
	pennywise3: Sa,
	pennywise4: Oa,
	pennywise5: ka
});
//#endregion
//#region src/game/runtime.ts
var Va = [
	vt,
	Ot,
	Vt,
	Jt,
	cn,
	Sn,
	Tn,
	Dn
];
function Ha(e, t, n) {
	if (n === "none" || n === "freeForAll") return null;
	if (n === "revealer") return t;
	if (n === "hidden") return e.players[Ye(e, e.players.length)];
	if (n === "leftOfRevealer") return Qe(e, t);
	let r = e.explorers.find((e) => e.character === "sara" || e.character === "werewolf")?.rid, i = e.explorers.find((e) => ["elf", "jingleklaws"].includes(e.character))?.rid;
	if (n === "sara" || n === "saraSeeObjective") return r;
	if (n === "revealerExceptSaraUseLeft") return t === r ? Qe(e, t) : t;
	if (n === "stranger") return i;
	if (n === "leftOfStranger") return Qe(e, i);
	let a = Array.from({ length: e.players.length }, (n, r) => e.players[(e.players.indexOf(t) + r) % e.players.length]).filter((e) => !(n.endsWith("ExceptRevealer") && e === t)), o = /Knowledge/.test(n) ? "knowledge" : /Might/.test(n) ? "might" : /Speed/.test(n) ? "speed" : "sanity", s = (t) => n === "mostOmens" ? E(e, t).cards.filter((e) => h.includes(e)).length : n === "oldestCharacter" ? Me(E(e, t).character).age ?? -1 : et(e, t, o), c = n.startsWith("lowest") ? Math.min(...a.map(s)) : Math.max(...a.map(s));
	return a.find((e) => s(e) === c);
}
function Ua(e, t) {
	if (e.haunt) return;
	let n = t.args?.encounter === !0, r = R(t.args, "event"), i = _(e.config.scenario), a = ke.indexOf(t.id), o = n ? Ae[t.id] : r ? t.id : i.haunts[a], s = Ba(o), c = n ? o === "pennywise1" ? "lowestMight" : o === "pennywise4" || o === "pennywise5" ? "none" : "revealer" : r ? o === "3" ? "hidden" : o === "7" ? "none" : o === "12" ? "freeForAll" : "revealer" : i.traitors[a];
	r === "sayCheese" && (c = "revealer");
	let l = r === "sayCheese" ? e.explorers.find((e) => e.cards.includes("magicCamera"))?.rid ?? t.actor : Ha(e, t.actor, c);
	if (Ze(e) === "blood") {
		let t = e.explorers.find((e) => e.character === "sara"), n = { ...t.traits };
		t.character = "werewolf", t.traits = {
			might: n.knowledge,
			speed: n.sanity,
			sanity: n.speed,
			knowledge: n.might
		};
	}
	e.phase = "haunt", e.endRequested = !1, e.prompt = null, e.roll = null, e.suspendedRolls = [], e.trade = null, e.discovery = null, e.queue = [], e.haunt = {
		id: o,
		revealer: t.actor,
		traitor: l,
		hidden: c === "hidden",
		track: 0,
		counters: {},
		flags: { triggerCard: t.id ?? "" },
		secret: {},
		monsterAfter: "",
		used: []
	};
	for (let t of e.explorers) t.team = c === "freeForAll" ? "individual" : t.rid === l ? "traitor" : "hero", t.revealed = t.rid === l && c !== "hidden";
	if (c === "hidden" && o !== "3") {
		let t = e.players.filter((e) => e !== l), n = t.map((e, t) => t + 2);
		for (let t = n.length - 1; t > 0; t--) {
			let r = Ye(e, t + 1);
			[n[t], n[r]] = [n[r], n[t]];
		}
		for (let r of e.explorers) r.secret.number = r.rid === l ? 1 : n[t.indexOf(r.rid)];
	}
	A(e, {
		key: "games.betrayal3.logHaunt",
		actor: t.actor,
		id: o
	}), s.setup(e), e.queue.push(...e.players.map((e) => ({
		op: "hauntBrief",
		actor: e
	})), {
		op: "hauntFirstTurn",
		actor: t.actor
	}), e.beatMs = Je.haunt;
}
function Wa(e, t) {
	switch (t.op) {
		case "hauntRoll":
			if (e.haunt) return !0;
			if (t.args?.automatic === !0) j(e, [{
				...t,
				op: "startHaunt"
			}]);
			else {
				let n = t.args?.encounter === !0 ? e.encountersOut.length : e.explorers.reduce((e, t) => e + t.cards.filter((e) => h.includes(e)).length, 0);
				j(e, [{
					op: "roll",
					actor: t.actor,
					n,
					args: { context: "haunt" },
					then: [{
						...t,
						op: "hauntRollResult"
					}]
				}]);
			}
			return !0;
		case "hauntRollResult": return j(e, z(t.args, "total") >= 5 ? [{
			...t,
			op: "startHaunt"
		}] : t.then ?? []), !0;
		case "startHaunt": return Ua(e, t), !0;
		case "hauntBrief": return M(e, t.actor, "games.betrayal3.hauntBegins", [N("continue", "games.betrayal3.acknowledgeHaunt", [])]), !0;
		case "hauntFirstTurn": return j(e, [{
			op: "beginTurn",
			actor: R(H(e).flags, "firstPlayer", Qe(e, H(e).traitor ?? H(e).revealer))
		}]), !0;
		default: return !1;
	}
}
function Ga(e, t) {
	e.beatMs = 0;
	let n = e.queue.length, r = e.haunt ? Ba(e.haunt.id) : null, i = r?.handle(e, t) ?? !1;
	if (t.op === "hauntTurnEnd" && e.haunt?.monsterAfter === t.actor) {
		let r = e.queue.length - n;
		e.queue.splice(Math.max(0, r), 0, {
			op: "hauntStartMonsters",
			actor: t.actor
		});
	}
	if (i ||= Wa(e, t) || qn(e, t) || Kn(e, t) || Va.some((n) => n(e, t)), !i && ![
		"hauntTurnStart",
		"hauntTurnEnd",
		"hauntDeath",
		"hauntEnter",
		"hauntMonsterEnd"
	].includes(t.op)) throw Error(`Unknown task: ${t.op}`);
	r?.after?.(e, t), e.haunt && e.phase !== "done" && Ba(e.haunt.id).check(e);
}
function Ka(e) {
	if (e.phase === "done" || e.reveal) return null;
	if (e.prompt) return e.prompt;
	if (e.queue.length || e.roll || e.endRequested) return null;
	let t = e.haunt ? Ba(e.haunt.id) : null, n = Cn(e), r = [...t?.filterActions ? t.filterActions(e, e.turn, n) : n, ...t?.actions(e, e.turn) ?? []];
	return r.length ? {
		actor: e.turn,
		choices: r
	} : null;
}
function qa(e, t, n) {
	if (t.type === "ack") {
		if (!e.reveal || !e.players.includes(n) || e.reveal.acks.includes(n)) return { state: e };
		let t = e.explorers.filter((e) => !e.dead).map((e) => e.rid);
		if (!t.includes(n)) return { state: e };
		let r = structuredClone(e);
		if (r.reveal.acks.push(n), t.every((e) => r.reveal.acks.includes(e))) {
			let e = r.reveal.tasks;
			r.reveal = null, j(r, e);
		}
		return { state: r };
	}
	if (t.type === "tick") {
		if (e.reveal || e.prompt || e.phase === "done" || !e.queue.length && !e.endRequested) return { state: e };
		let t = structuredClone(e);
		return !t.queue.length && t.endRequested && t.queue.push({
			op: "endTurn",
			actor: t.turn
		}), Ga(t, t.queue.shift()), { state: t };
	}
	let r = Ka(e);
	if (!r || r.actor !== n) return { code: "games.betrayal3.errNotYourTurn" };
	let i = r.choices.find((e) => e.id === t.id);
	if (!i) return { code: "games.betrayal3.errBadChoice" };
	let a = structuredClone(e);
	return a.prompt = null, j(a, i.tasks), { state: a };
}
function Ja(e) {
	return !e.reveal && !e.prompt && e.phase !== "done" && (e.queue.length || e.endRequested) ? e.beatMs || Je.resolve : null;
}
//#endregion
//#region src/game/views.ts
function Ya(e, t) {
	let n = E(e, t), r = e.haunt, i = Ka(e), a = !!e.prompt?.secretFor?.length, o = e.journal.map((e, t) => ({
		...e,
		order: t
	})), s = o.filter((e) => !e.secretFor?.length).map(({ key: e, order: t, actor: n, target: r, n: i, id: a }) => ({
		key: e,
		order: t,
		actor: n,
		target: r,
		n: i,
		id: a
	})), c = o.filter((e) => e.secretFor?.includes(t)).map(({ key: e, order: t, actor: n, target: r, n: i, id: a }) => ({
		key: e,
		order: t,
		actor: n,
		target: r,
		n: i,
		id: a
	})), l = (t) => {
		let n = E(e, t);
		return e.phase !== "done" && r?.hidden && !n.revealed ? "unknown" : n.team;
	}, u = (t, n) => r?.id === "30" && e.phase !== "done" && E(e, t).team === "hero" && !E(e, t).dead && h.includes(n) && !E(e, t).secret.faceUpOmens?.includes(n) ? "hiddenOmen" : n, d = e.explorers.filter((e) => !e.dead).map((e) => e.rid), f = (t, n) => e.trade && [e.trade.actor, e.trade.target].every((t) => E(e, t).team === "hero") ? u(t, n) : n, p = n?.team === "traitor" && r ? Object.fromEntries(Object.entries(r.secret).filter(([e]) => [
		"killTarget",
		"currentWeakness",
		"syllables"
	].includes(e) || e.startsWith("token."))) : {};
	return {
		public: {
			phase: e.phase,
			scenario: e.config.scenario,
			turn: e.turn,
			turnNumber: e.turnNumber,
			movement: e.movement,
			explorers: e.explorers.map((t) => ({
				rid: t.rid,
				character: t.character,
				traits: { ...t.traits },
				values: Object.fromEntries(w.map((n) => [n, t.traits[n] < 0 ? 0 : et(e, t.rid, n)])),
				room: t.secret.hiddenAmongIllusions === !0 ? "" : t.room,
				dead: t.dead,
				cards: t.cards.map((e) => u(t.rid, e)),
				revealed: t.revealed,
				team: l(t.rid),
				statuses: [
					"hiddenFromWerewolf",
					"mindControlled",
					"trappedByKnight"
				].filter((e) => t.secret[e] === !0)
			})),
			rooms: e.rooms.map((e) => ({ ...e })),
			monsters: e.monsters.filter((e) => e.flags.hidden !== !0).map((t) => ({
				id: t.id,
				kind: t.kind,
				room: t.room,
				traits: Object.fromEntries(w.map((n) => [n, et(e, t.id, n)])),
				stunned: t.stunned,
				dead: t.dead,
				identity: t.kind === "cursedItem" || t.kind === "mischievousToy" ? String(t.flags.card) : t.kind === "evilTwin" ? String(t.flags.reflection) : null,
				number: typeof t.flags.number == "number" ? t.flags.number : e.monsters.filter((e) => e.kind === t.kind).indexOf(t) + 1
			})),
			tokens: e.tokens.map((t) => ({
				id: t.id,
				kind: t.kind,
				room: t.room,
				holder: t.holder,
				value: t.hidden && e.phase !== "done" ? null : t.value,
				trait: t.hidden && e.phase !== "done" ? null : t.trait,
				hidden: t.hidden,
				identity: t.kind === "dna" ? String(t.flags.body) : t.kind === "essence" || t.kind === "heroBlood" ? String(t.flags.owner) : [
					"silverRune",
					"giftRune",
					"toyNumber",
					"presentNumber"
				].includes(t.kind) ? String(t.flags.card) : null
			})),
			haunt: r ? {
				id: r.id,
				revealer: r.revealer,
				traitor: r.hidden && e.phase !== "done" && !e.explorers.some((e) => e.team === "traitor" && e.revealed) ? null : r.traitor,
				hidden: r.hidden,
				track: r.track,
				counters: { ...r.counters }
			} : null,
			pending: e.prompt ? {
				actor: a ? null : e.prompt.actor,
				key: a ? "games.betrayal3.privateDecision" : e.prompt.key,
				params: a ? void 0 : e.prompt.params
			} : null,
			roll: e.roll ? {
				actor: e.roll.actor,
				trait: e.roll.trait,
				dice: [...e.roll.dice],
				bonus: e.roll.bonus,
				context: e.roll.context
			} : null,
			decks: {
				tiles: e.tiles.length,
				items: e.items.length,
				omens: e.omens.length,
				events: e.events.length,
				encounters: e.encounters.length,
				omenDraws: e.omenDraws
			},
			journal: s,
			winners: e.winners ? [...e.winners] : null,
			ending: e.ending,
			discovery: e.discovery ? { ...e.discovery } : null,
			trade: e.trade ? {
				...e.trade,
				give: e.trade.give.map((t) => f(e.trade.actor, t)),
				take: e.trade.take.map((t) => f(e.trade.target, t))
			} : null,
			reveal: e.reveal ? {
				id: u(e.reveal.actor, e.reveal.id),
				kind: e.reveal.kind,
				actor: e.reveal.actor,
				acks: [...e.reveal.acks],
				required: d
			} : null
		},
		private: {
			pending: a && e.prompt.secretFor.includes(t) ? {
				key: e.prompt.key,
				params: e.prompt.params
			} : null,
			actingPiece: i?.actor === t ? i.choices.flatMap((e) => e.tasks).find((t) => e.monsters.some((e) => e.id === t.actor))?.actor ?? t : null,
			choices: i?.actor === t ? i.choices.map(({ id: e, key: t, params: n, kind: r, target: i, value: a }) => ({
				id: e,
				key: t,
				params: n,
				kind: r,
				target: i,
				value: a
			})) : [],
			secret: structuredClone({
				...n?.secret,
				cards: [...n?.cards ?? []],
				...p,
				...e.trade && [e.trade.actor, e.trade.target].includes(t) ? {
					tradeGive: e.trade.give,
					tradeTake: e.trade.take
				} : {},
				...Object.fromEntries(e.tokens.filter((e) => e.holder === t && e.hidden && e.kind !== "presentNumber").map((e) => [`token.${e.id}`, e.value]))
			}),
			team: n?.team ?? "hero",
			objective: r ? `${r.id}.${n?.team ?? "hero"}` : null,
			journal: c,
			canAck: !!e.reveal && d.includes(t) && !e.reveal.acks.includes(t)
		}
	};
}
//#endregion
//#region src/game/piece-layout.ts
function Xa(e, t = !1) {
	return t ? {
		x: 15 + e % 6 * 24,
		y: 45 + Math.floor(e / 6) % 3 * 22,
		size: 20
	} : {
		x: 15 + e % 3 * 47,
		y: 91 + Math.floor(e / 3) * 28,
		size: 30
	};
}
//#endregion
//#region src/game/rules.ts
var Za = {
	meta: he,
	saveCompatibility: { version: "2" },
	schemas: {
		config: ve,
		action: ye,
		publicView: xe,
		privateView: Se
	},
	setup: (e, t, n) => ({
		state: _t(e, t, n),
		fx: []
	}),
	reduce(e, t, n) {
		let r = qa(e, t, n.by);
		if ("code" in r) return r;
		let i = r.state.journal.slice(e.journal.length).filter((e) => !e.secretFor?.length), a = [
			"logMove",
			"logDraw",
			"logTrade",
			"logHaunt",
			"logDeath",
			"logDamage",
			"logGain",
			"logLose",
			"logHeal",
			"logUse"
		].map((e) => `games.betrayal3.${e}`), o = i.filter((e) => a.includes(e.key)).map((t) => {
			let n = e.explorers.find((e) => e.rid === t.actor), i = e.monsters.find((e) => e.id === t.actor), a = e.monsters.filter((e) => !e.dead && e.flags.hidden !== !0 && e.room === i?.room);
			if (i?.flags.hidden === !0) return null;
			let o = Xa(n ? e.explorers.filter((e) => e.room === n.room).indexOf(n) : Math.max(0, a.findIndex((e) => e.id === t.actor)), !!i), s = Te.includes(t.id ?? "") ? "item" : h.includes(t.id ?? "") ? "omen" : Ee.includes(t.id ?? "") ? "event" : "encounter";
			return {
				kind: "houseBeat",
				rid: t.actor,
				data: {
					key: t.key,
					n: t.n ?? null,
					id: t.key === "games.betrayal3.logDraw" ? null : t.id ?? null,
					from: v(n?.room ?? i?.room ?? ""),
					fromX: o.x,
					fromY: o.y,
					size: o.size,
					monster: !!i,
					number: typeof i?.flags.number == "number" ? i.flags.number : e.monsters.filter((e) => e.kind === i?.kind).findIndex((e) => e.id === i?.id) + 1,
					cardKind: s,
					target: t.target ?? null,
					to: v(t.id ?? ""),
					color: r.state.explorers.find((e) => e.rid === t.actor) ? Me(r.state.explorers.find((e) => e.rid === t.actor).character).group : "white"
				},
				...t.key === "games.betrayal3.logDraw" && t.actor ? {
					for: [t.actor],
					secret: { id: t.id ?? "" }
				} : {},
				with: !1
			};
		}).filter((e) => e !== null);
		return {
			...r,
			fx: o
		};
	},
	viewFor: Ya,
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = e.winners ?? [];
		return {
			phase: "done",
			winner: t,
			ranking: [...e.players.filter((e) => t.includes(e)), ...e.players.filter((e) => !t.includes(e))]
		};
	},
	nextTickIn: Ja
};
//#endregion
//#region src/game/rule-text.tsx
function Qa({ text: e }) {
	let t = [], n = [], a = () => {
		n.length && (t.push(/* @__PURE__ */ i("ul", {
			style: {
				listStyle: "disc",
				paddingLeft: 20,
				margin: "8px 0 16px"
			},
			children: n.map((e, t) => /* @__PURE__ */ i("li", { children: e }, t))
		}, t.length)), n = []);
	};
	for (let r of e.split("\n")) r.startsWith("· ") ? n.push(r.slice(2)) : (a(), r.trim() && t.push(/* @__PURE__ */ i("p", { children: r }, t.length)));
	return a(), /* @__PURE__ */ i(r, { children: t });
}
//#endregion
//#region src/game/labels.ts
var $a = {
	conservatory: "games.betrayal3.label_conservatory",
	armory: "games.betrayal3.label_armory",
	bloodyRoom: "games.betrayal3.label_bloodyRoom",
	catacombs: "games.betrayal3.label_catacombs",
	charredRoom: "games.betrayal3.label_charredRoom",
	ritualRoom: "games.betrayal3.label_ritualRoom",
	kitchen: "games.betrayal3.label_kitchen",
	ballroom: "games.betrayal3.label_ballroom",
	junkRoom: "games.betrayal3.label_junkRoom",
	panicRoom: "games.betrayal3.label_panicRoom",
	laundryChute: "games.betrayal3.label_laundryChute",
	laboratory: "games.betrayal3.label_laboratory",
	chapel: "games.betrayal3.label_chapel",
	soundproofedRoom: "games.betrayal3.label_soundproofedRoom",
	salon: "games.betrayal3.label_salon",
	specimenRoom: "games.betrayal3.label_specimenRoom",
	secretStaircase: "games.betrayal3.label_secretStaircase",
	library: "games.betrayal3.label_library",
	undergroundLake: "games.betrayal3.label_undergroundLake",
	statuaryCorridor: "games.betrayal3.label_statuaryCorridor",
	nursery: "games.betrayal3.label_nursery",
	tower: "games.betrayal3.label_tower",
	crawlspace: "games.betrayal3.label_crawlspace",
	operatingTheatre: "games.betrayal3.label_operatingTheatre",
	gameRoom: "games.betrayal3.label_gameRoom",
	larder: "games.betrayal3.label_larder",
	observatory: "games.betrayal3.label_observatory",
	diningRoom: "games.betrayal3.label_diningRoom",
	gymnasium: "games.betrayal3.label_gymnasium",
	undergroundCavern: "games.betrayal3.label_undergroundCavern",
	organRoom: "games.betrayal3.label_organRoom",
	vault: "games.betrayal3.label_vault",
	primaryBedroom: "games.betrayal3.label_primaryBedroom",
	winterBedroom: "games.betrayal3.label_winterBedroom",
	mysticElevator: "games.betrayal3.label_mysticElevator",
	chasm: "games.betrayal3.label_chasm",
	gallery: "games.betrayal3.label_gallery",
	crampedPassageway: "games.betrayal3.label_crampedPassageway",
	graveyard: "games.betrayal3.label_graveyard",
	furnaceRoom: "games.betrayal3.label_furnaceRoom",
	guestQuarters: "games.betrayal3.label_guestQuarters",
	collapsedRoom: "games.betrayal3.label_collapsedRoom",
	groundStaircase: "games.betrayal3.label_groundStaircase",
	hallway: "games.betrayal3.label_hallway",
	entranceHall: "games.betrayal3.label_entranceHall",
	upperLanding: "games.betrayal3.label_upperLanding",
	basementLanding: "games.betrayal3.label_basementLanding",
	oubliette: "games.betrayal3.label_oubliette",
	trophyRoom: "games.betrayal3.label_trophyRoom",
	timeLostTree: "games.betrayal3.label_timeLostTree",
	rootCellar: "games.betrayal3.label_rootCellar",
	ancientDen: "games.betrayal3.label_ancientDen",
	windingTunnels: "games.betrayal3.label_windingTunnels",
	darkenedHallway: "games.betrayal3.label_darkenedHallway",
	oldWell: "games.betrayal3.label_oldWell",
	isa: "games.betrayal3.label_isa",
	anita: "games.betrayal3.label_anita",
	jaden: "games.betrayal3.label_jaden",
	sammy: "games.betrayal3.label_sammy",
	oliver: "games.betrayal3.label_oliver",
	josef: "games.betrayal3.label_josef",
	warren: "games.betrayal3.label_warren",
	dan: "games.betrayal3.label_dan",
	persephone: "games.betrayal3.label_persephone",
	stephanie: "games.betrayal3.label_stephanie",
	brittani: "games.betrayal3.label_brittani",
	michelle: "games.betrayal3.label_michelle",
	sara: "games.betrayal3.label_sara",
	werewolf: "games.betrayal3.label_werewolf",
	elf: "games.betrayal3.label_elf",
	jingleklaws: "games.betrayal3.label_jingleklaws",
	machete: "games.betrayal3.label_machete",
	crossbow: "games.betrayal3.label_crossbow",
	firstAidKit: "games.betrayal3.label_firstAidKit",
	mirror: "games.betrayal3.label_mirror",
	angelsFeather: "games.betrayal3.label_angelsFeather",
	strangeMedicine: "games.betrayal3.label_strangeMedicine",
	mysticalStopwatch: "games.betrayal3.label_mysticalStopwatch",
	skeletonKey: "games.betrayal3.label_skeletonKey",
	strangeAmulet: "games.betrayal3.label_strangeAmulet",
	dynamite: "games.betrayal3.label_dynamite",
	magicCamera: "games.betrayal3.label_magicCamera",
	headphones: "games.betrayal3.label_headphones",
	gun: "games.betrayal3.label_gun",
	rabbitsFoot: "games.betrayal3.label_rabbitsFoot",
	flashlight: "games.betrayal3.label_flashlight",
	luckyCoin: "games.betrayal3.label_luckyCoin",
	map: "games.betrayal3.label_map",
	necklaceOfTeeth: "games.betrayal3.label_necklaceOfTeeth",
	brooch: "games.betrayal3.label_brooch",
	leatherJacket: "games.betrayal3.label_leatherJacket",
	chainsaw: "games.betrayal3.label_chainsaw",
	creepyDoll: "games.betrayal3.label_creepyDoll",
	dog: "games.betrayal3.label_dog",
	book: "games.betrayal3.label_book",
	dagger: "games.betrayal3.label_dagger",
	ring: "games.betrayal3.label_ring",
	armor: "games.betrayal3.label_armor",
	idol: "games.betrayal3.label_idol",
	holySymbol: "games.betrayal3.label_holySymbol",
	skull: "games.betrayal3.label_skull",
	mask: "games.betrayal3.label_mask",
	fangBracelet: "games.betrayal3.label_fangBracelet",
	wolfsbane: "games.betrayal3.label_wolfsbane",
	unusualCake: "games.betrayal3.label_unusualCake",
	snowGlobe: "games.betrayal3.label_snowGlobe",
	hiddenOmen: "games.betrayal3.label_hiddenOmen",
	might: "games.betrayal3.label_might",
	speed: "games.betrayal3.label_speed",
	sanity: "games.betrayal3.label_sanity",
	knowledge: "games.betrayal3.label_knowledge",
	dice: "games.betrayal3.label_dice",
	physical: "games.betrayal3.label_physical",
	mental: "games.betrayal3.label_mental",
	general: "games.betrayal3.label_general",
	item: "games.betrayal3.label_item",
	item2: "games.betrayal3.label_item2",
	omen: "games.betrayal3.label_omen",
	event: "games.betrayal3.label_event",
	event2: "games.betrayal3.label_event2",
	paranormalInvestigators: "games.betrayal3.label_paranormalInvestigators",
	strangeDisappearance: "games.betrayal3.label_strangeDisappearance",
	forSale: "games.betrayal3.label_forSale",
	mysteriousInvitation: "games.betrayal3.label_mysteriousInvitation",
	cursed: "games.betrayal3.label_cursed",
	howlAtTheMoon: "games.betrayal3.label_howlAtTheMoon",
	holidayHouse: "games.betrayal3.label_holidayHouse",
	comeHomeToEvil: "games.betrayal3.label_comeHomeToEvil",
	blessing: "games.betrayal3.label_blessing",
	secretPassage: "games.betrayal3.label_secretPassage",
	alienWord: "games.betrayal3.label_alienWord",
	knowledgeOfAliens: "games.betrayal3.label_knowledgeOfAliens",
	packWolf: "games.betrayal3.label_packWolf",
	silverRune: "games.betrayal3.label_silverRune",
	vampireMaster: "games.betrayal3.label_vampireMaster",
	vampireBlood: "games.betrayal3.label_vampireBlood",
	sanctified: "games.betrayal3.label_sanctified",
	vampireAltar: "games.betrayal3.label_vampireAltar",
	hunterNumber: "games.betrayal3.label_hunterNumber",
	phaseSupply: "games.betrayal3.label_phaseSupply",
	phaseTrait: "games.betrayal3.label_phaseTrait",
	sportNest: "games.betrayal3.label_sportNest",
	spectralIdol: "games.betrayal3.label_spectralIdol",
	sportAltar: "games.betrayal3.label_sportAltar",
	ghostAdversary: "games.betrayal3.label_ghostAdversary",
	blockingSpirit: "games.betrayal3.label_blockingSpirit",
	dna: "games.betrayal3.label_dna",
	securityRobot: "games.betrayal3.label_securityRobot",
	essence: "games.betrayal3.label_essence",
	photographer: "games.betrayal3.label_photographer",
	bakeneko: "games.betrayal3.label_bakeneko",
	undeadCat: "games.betrayal3.label_undeadCat",
	fire: "games.betrayal3.label_fire",
	treasure: "games.betrayal3.label_treasure",
	construct: "games.betrayal3.label_construct",
	makeshiftExplosive: "games.betrayal3.label_makeshiftExplosive",
	heroBlood: "games.betrayal3.label_heroBlood",
	contractDemon: "games.betrayal3.label_contractDemon",
	infernalContract: "games.betrayal3.label_infernalContract",
	mirrorBeing: "games.betrayal3.label_mirrorBeing",
	housekeeper: "games.betrayal3.label_housekeeper",
	cleanedRoom: "games.betrayal3.label_cleanedRoom",
	cursedItem: "games.betrayal3.label_cursedItem",
	demonicDog: "games.betrayal3.label_demonicDog",
	exorcisedSpirit: "games.betrayal3.label_exorcisedSpirit",
	dogFood: "games.betrayal3.label_dogFood",
	christina: "games.betrayal3.label_christina",
	jackSpirit: "games.betrayal3.label_jackSpirit",
	exorcismCircle: "games.betrayal3.label_exorcismCircle",
	demonRealtor: "games.betrayal3.label_demonRealtor",
	cleansedFire: "games.betrayal3.label_cleansedFire",
	wardOfProtection: "games.betrayal3.label_wardOfProtection",
	stoneCherub: "games.betrayal3.label_stoneCherub",
	relative: "games.betrayal3.label_relative",
	elder: "games.betrayal3.label_elder",
	evilTwin: "games.betrayal3.label_evilTwin",
	gardenFae: "games.betrayal3.label_gardenFae",
	coldIron: "games.betrayal3.label_coldIron",
	knowledgeOfFae: "games.betrayal3.label_knowledgeOfFae",
	giantHair: "games.betrayal3.label_giantHair",
	smallHair: "games.betrayal3.label_smallHair",
	antidote: "games.betrayal3.label_antidote",
	dustResearch: "games.betrayal3.label_dustResearch",
	feverish: "games.betrayal3.label_feverish",
	evidence: "games.betrayal3.label_evidence",
	giantWasp: "games.betrayal3.label_giantWasp",
	workerWasp: "games.betrayal3.label_workerWasp",
	waspEgg: "games.betrayal3.label_waspEgg",
	headOfHouse: "games.betrayal3.label_headOfHouse",
	illusion: "games.betrayal3.label_illusion",
	circuit: "games.betrayal3.label_circuit",
	robotAssistant: "games.betrayal3.label_robotAssistant",
	trappedHero: "games.betrayal3.label_trappedHero",
	knightPortal: "games.betrayal3.label_knightPortal",
	machineTrap: "games.betrayal3.label_machineTrap",
	generator: "games.betrayal3.label_generator",
	theHouse: "games.betrayal3.label_theHouse",
	sabotaged: "games.betrayal3.label_sabotaged",
	spooky: "games.betrayal3.label_spooky",
	horror: "games.betrayal3.label_horror",
	coldWarZombie: "games.betrayal3.label_coldWarZombie",
	seelieFlame: "games.betrayal3.label_seelieFlame",
	faeDancer: "games.betrayal3.label_faeDancer",
	darkQueen: "games.betrayal3.label_darkQueen",
	peaceGhost: "games.betrayal3.label_peaceGhost",
	formSearched: "games.betrayal3.label_formSearched",
	knownWeakness: "games.betrayal3.label_knownWeakness",
	zombieHockstetter: "games.betrayal3.label_zombieHockstetter",
	henrySearched: "games.betrayal3.label_henrySearched",
	henryVictim: "games.betrayal3.label_henryVictim",
	tinyTerror: "games.betrayal3.label_tinyTerror",
	pennywiseClown: "games.betrayal3.label_pennywiseClown",
	pennyTarget: "games.betrayal3.label_pennyTarget",
	personalArtifact: "games.betrayal3.label_personalArtifact",
	chudAltar: "games.betrayal3.label_chudAltar",
	pennywiseSpider: "games.betrayal3.label_pennywiseSpider",
	cultist: "games.betrayal3.label_cultist",
	ritualKnowledge: "games.betrayal3.label_ritualKnowledge",
	animatedFurniture: "games.betrayal3.label_animatedFurniture",
	seamFire: "games.betrayal3.label_seamFire",
	mannequin: "games.betrayal3.label_mannequin",
	ghostShark: "games.betrayal3.label_ghostShark",
	explosive: "games.betrayal3.label_explosive",
	slug: "games.betrayal3.label_slug",
	slugNest: "games.betrayal3.label_slugNest",
	salt: "games.betrayal3.label_salt",
	neighbor: "games.betrayal3.label_neighbor",
	remains: "games.betrayal3.label_remains",
	angryGhost: "games.betrayal3.label_angryGhost",
	gremlin: "games.betrayal3.label_gremlin",
	gremlinRune: "games.betrayal3.label_gremlinRune",
	vengefulSpirit: "games.betrayal3.label_vengefulSpirit",
	facelessMan: "games.betrayal3.label_facelessMan",
	syllable: "games.betrayal3.label_syllable",
	altar: "games.betrayal3.label_altar",
	weddingParty: "games.betrayal3.label_weddingParty",
	witchFood: "games.betrayal3.label_witchFood",
	trollHand: "games.betrayal3.label_trollHand",
	bell: "games.betrayal3.label_bell",
	coalCreature: "games.betrayal3.label_coalCreature",
	offeringFood: "games.betrayal3.label_offeringFood",
	giftRune: "games.betrayal3.label_giftRune",
	krampus: "games.betrayal3.label_krampus",
	presentWish: "games.betrayal3.label_presentWish",
	presentNumber: "games.betrayal3.label_presentNumber",
	presentSearched: "games.betrayal3.label_presentSearched",
	mischievousToy: "games.betrayal3.label_mischievousToy",
	toyNumber: "games.betrayal3.label_toyNumber",
	smallToy: "games.betrayal3.label_smallToy",
	ornament: "games.betrayal3.label_ornament",
	ghost: "games.betrayal3.label_ghost",
	vampire: "games.betrayal3.label_vampire",
	werewolfMonster: "games.betrayal3.label_werewolfMonster",
	zombie: "games.betrayal3.label_zombie",
	robot: "games.betrayal3.label_robot",
	pennywise: "games.betrayal3.label_pennywise",
	pennyClown: "games.betrayal3.label_pennyClown",
	pennySpider: "games.betrayal3.label_pennySpider",
	hockstetter: "games.betrayal3.label_hockstetter",
	fae: "games.betrayal3.label_fae",
	spirit: "games.betrayal3.label_spirit",
	cherub: "games.betrayal3.label_cherub",
	furniture: "games.betrayal3.label_furniture",
	food: "games.betrayal3.label_food",
	rune: "games.betrayal3.label_rune",
	searched: "games.betrayal3.label_searched",
	obstacle: "games.betrayal3.label_obstacle",
	redBalloon: "games.betrayal3.label_redBalloon",
	coal: "games.betrayal3.label_coal",
	artifact: "games.betrayal3.label_artifact",
	kudzu: "games.betrayal3.label_kudzu",
	yuleLog: "games.betrayal3.label_yuleLog",
	krampusItem: "games.betrayal3.label_krampusItem",
	videotape: "games.betrayal3.label_videotape",
	krampusOmen: "games.betrayal3.label_krampusOmen",
	ingredient: "games.betrayal3.label_ingredient",
	hiddenFromWerewolf: "games.betrayal3.label_hiddenFromWerewolf",
	mindControlled: "games.betrayal3.label_mindControlled",
	trappedByKnight: "games.betrayal3.label_trappedByKnight",
	secretElevator: "games.betrayal3.label_secretElevator",
	creakingDoor: "games.betrayal3.label_creakingDoor",
	cryForHelp: "games.betrayal3.label_cryForHelp",
	momentOfHope: "games.betrayal3.label_momentOfHope",
	darkStormyNight: "games.betrayal3.label_darkStormyNight",
	spiders: "games.betrayal3.label_spiders",
	meatMoss: "games.betrayal3.label_meatMoss",
	eerieFeeling: "games.betrayal3.label_eerieFeeling",
	hangedMen: "games.betrayal3.label_hangedMen",
	poorYorick: "games.betrayal3.label_poorYorick",
	impossibleArchitecture: "games.betrayal3.label_impossibleArchitecture",
	alienGeometry: "games.betrayal3.label_alienGeometry",
	bite: "games.betrayal3.label_bite",
	funeral: "games.betrayal3.label_funeral",
	jonahsTurn: "games.betrayal3.label_jonahsTurn",
	flickeringLights: "games.betrayal3.label_flickeringLights",
	flowering: "games.betrayal3.label_flowering",
	fullTable: "games.betrayal3.label_fullTable",
	deepestCloset: "games.betrayal3.label_deepestCloset",
	burningFigure: "games.betrayal3.label_burningFigure",
	behindYou: "games.betrayal3.label_behindYou",
	clownRoom: "games.betrayal3.label_clownRoom",
	radioBroadcast: "games.betrayal3.label_radioBroadcast",
	tinyRobot: "games.betrayal3.label_tinyRobot",
	taxidermy: "games.betrayal3.label_taxidermy",
	severedHand: "games.betrayal3.label_severedHand",
	phoneCall: "games.betrayal3.label_phoneCall",
	batOutOfHell: "games.betrayal3.label_batOutOfHell",
	sayCheese: "games.betrayal3.label_sayCheese",
	mysteriousFluid: "games.betrayal3.label_mysteriousFluid",
	splashOfCrimson: "games.betrayal3.label_splashOfCrimson",
	forbiddenKnowledge: "games.betrayal3.label_forbiddenKnowledge",
	vialOfDust: "games.betrayal3.label_vialOfDust",
	cassettePlayer: "games.betrayal3.label_cassettePlayer",
	eerieMirror: "games.betrayal3.label_eerieMirror",
	oldestHouse: "games.betrayal3.label_oldestHouse",
	jarOfOrgans: "games.betrayal3.label_jarOfOrgans",
	technicalDifficulties: "games.betrayal3.label_technicalDifficulties",
	wanderingGhost: "games.betrayal3.label_wanderingGhost",
	starsAtNight: "games.betrayal3.label_starsAtNight",
	brainFood: "games.betrayal3.label_brainFood",
	houseIsHungry: "games.betrayal3.label_houseIsHungry",
	hunt: "games.betrayal3.label_hunt",
	bloodMoon: "games.betrayal3.label_bloodMoon",
	feast: "games.betrayal3.label_feast",
	gift: "games.betrayal3.label_gift",
	floatingLights: "games.betrayal3.label_floatingLights",
	knifeInDark: "games.betrayal3.label_knifeInDark",
	bloodTendrils: "games.betrayal3.label_bloodTendrils",
	goodBoy: "games.betrayal3.label_goodBoy",
	popOfRed: "games.betrayal3.label_popOfRed",
	hometownHorrors: "games.betrayal3.label_hometownHorrors",
	swirlingVisions: "games.betrayal3.label_swirlingVisions",
	stretchingHall: "games.betrayal3.label_stretchingHall",
	timeToSink: "games.betrayal3.label_timeToSink",
	eaterOfWorlds: "games.betrayal3.label_eaterOfWorlds",
	haunt1: "games.betrayal3.label_haunt1",
	haunt2: "games.betrayal3.label_haunt2",
	haunt3: "games.betrayal3.label_haunt3",
	haunt4: "games.betrayal3.label_haunt4",
	haunt5: "games.betrayal3.label_haunt5",
	haunt6: "games.betrayal3.label_haunt6",
	haunt7: "games.betrayal3.label_haunt7",
	haunt8: "games.betrayal3.label_haunt8",
	haunt9: "games.betrayal3.label_haunt9",
	haunt10: "games.betrayal3.label_haunt10",
	haunt11: "games.betrayal3.label_haunt11",
	haunt12: "games.betrayal3.label_haunt12",
	haunt13: "games.betrayal3.label_haunt13",
	haunt14: "games.betrayal3.label_haunt14",
	haunt15: "games.betrayal3.label_haunt15",
	haunt16: "games.betrayal3.label_haunt16",
	haunt17: "games.betrayal3.label_haunt17",
	haunt18: "games.betrayal3.label_haunt18",
	haunt19: "games.betrayal3.label_haunt19",
	haunt20: "games.betrayal3.label_haunt20",
	haunt21: "games.betrayal3.label_haunt21",
	haunt22: "games.betrayal3.label_haunt22",
	haunt23: "games.betrayal3.label_haunt23",
	haunt24: "games.betrayal3.label_haunt24",
	haunt25: "games.betrayal3.label_haunt25",
	haunt26: "games.betrayal3.label_haunt26",
	haunt27: "games.betrayal3.label_haunt27",
	haunt28: "games.betrayal3.label_haunt28",
	haunt29: "games.betrayal3.label_haunt29",
	haunt30: "games.betrayal3.label_haunt30",
	haunt31: "games.betrayal3.label_haunt31",
	haunt32: "games.betrayal3.label_haunt32",
	haunt33: "games.betrayal3.label_haunt33",
	haunt34: "games.betrayal3.label_haunt34",
	haunt35: "games.betrayal3.label_haunt35",
	haunt36: "games.betrayal3.label_haunt36",
	haunt37: "games.betrayal3.label_haunt37",
	haunt38: "games.betrayal3.label_haunt38",
	haunt39: "games.betrayal3.label_haunt39",
	haunt40: "games.betrayal3.label_haunt40",
	haunt41: "games.betrayal3.label_haunt41",
	haunt42: "games.betrayal3.label_haunt42",
	haunt43: "games.betrayal3.label_haunt43",
	haunt44: "games.betrayal3.label_haunt44",
	haunt45: "games.betrayal3.label_haunt45",
	haunt46: "games.betrayal3.label_haunt46",
	haunt47: "games.betrayal3.label_haunt47",
	haunt48: "games.betrayal3.label_haunt48",
	haunt49: "games.betrayal3.label_haunt49",
	haunt50: "games.betrayal3.label_haunt50",
	hauntblood1: "games.betrayal3.label_hauntblood1",
	hauntblood2: "games.betrayal3.label_hauntblood2",
	hauntblood3: "games.betrayal3.label_hauntblood3",
	hauntblood4: "games.betrayal3.label_hauntblood4",
	hauntblood5: "games.betrayal3.label_hauntblood5",
	hauntyuletide1: "games.betrayal3.label_hauntyuletide1",
	hauntyuletide2: "games.betrayal3.label_hauntyuletide2",
	hauntyuletide3: "games.betrayal3.label_hauntyuletide3",
	hauntyuletide4: "games.betrayal3.label_hauntyuletide4",
	hauntyuletide5: "games.betrayal3.label_hauntyuletide5",
	hauntpennywise1: "games.betrayal3.label_hauntpennywise1",
	hauntpennywise2: "games.betrayal3.label_hauntpennywise2",
	hauntpennywise3: "games.betrayal3.label_hauntpennywise3",
	hauntpennywise4: "games.betrayal3.label_hauntpennywise4",
	hauntpennywise5: "games.betrayal3.label_hauntpennywise5"
}, eo = {
	1: "games.betrayal3.label_haunt1",
	2: "games.betrayal3.label_haunt2",
	3: "games.betrayal3.label_haunt3",
	4: "games.betrayal3.label_haunt4",
	5: "games.betrayal3.label_haunt5",
	6: "games.betrayal3.label_haunt6",
	7: "games.betrayal3.label_haunt7",
	8: "games.betrayal3.label_haunt8",
	9: "games.betrayal3.label_haunt9",
	10: "games.betrayal3.label_haunt10",
	11: "games.betrayal3.label_haunt11",
	12: "games.betrayal3.label_haunt12",
	13: "games.betrayal3.label_haunt13",
	14: "games.betrayal3.label_haunt14",
	15: "games.betrayal3.label_haunt15",
	16: "games.betrayal3.label_haunt16",
	17: "games.betrayal3.label_haunt17",
	18: "games.betrayal3.label_haunt18",
	19: "games.betrayal3.label_haunt19",
	20: "games.betrayal3.label_haunt20",
	21: "games.betrayal3.label_haunt21",
	22: "games.betrayal3.label_haunt22",
	23: "games.betrayal3.label_haunt23",
	24: "games.betrayal3.label_haunt24",
	25: "games.betrayal3.label_haunt25",
	26: "games.betrayal3.label_haunt26",
	27: "games.betrayal3.label_haunt27",
	28: "games.betrayal3.label_haunt28",
	29: "games.betrayal3.label_haunt29",
	30: "games.betrayal3.label_haunt30",
	31: "games.betrayal3.label_haunt31",
	32: "games.betrayal3.label_haunt32",
	33: "games.betrayal3.label_haunt33",
	34: "games.betrayal3.label_haunt34",
	35: "games.betrayal3.label_haunt35",
	36: "games.betrayal3.label_haunt36",
	37: "games.betrayal3.label_haunt37",
	38: "games.betrayal3.label_haunt38",
	39: "games.betrayal3.label_haunt39",
	40: "games.betrayal3.label_haunt40",
	41: "games.betrayal3.label_haunt41",
	42: "games.betrayal3.label_haunt42",
	43: "games.betrayal3.label_haunt43",
	44: "games.betrayal3.label_haunt44",
	45: "games.betrayal3.label_haunt45",
	46: "games.betrayal3.label_haunt46",
	47: "games.betrayal3.label_haunt47",
	48: "games.betrayal3.label_haunt48",
	49: "games.betrayal3.label_haunt49",
	50: "games.betrayal3.label_haunt50",
	blood1: "games.betrayal3.label_hauntblood1",
	blood2: "games.betrayal3.label_hauntblood2",
	blood3: "games.betrayal3.label_hauntblood3",
	blood4: "games.betrayal3.label_hauntblood4",
	blood5: "games.betrayal3.label_hauntblood5",
	yuletide1: "games.betrayal3.label_hauntyuletide1",
	yuletide2: "games.betrayal3.label_hauntyuletide2",
	yuletide3: "games.betrayal3.label_hauntyuletide3",
	yuletide4: "games.betrayal3.label_hauntyuletide4",
	yuletide5: "games.betrayal3.label_hauntyuletide5",
	pennywise1: "games.betrayal3.label_hauntpennywise1",
	pennywise2: "games.betrayal3.label_hauntpennywise2",
	pennywise3: "games.betrayal3.label_hauntpennywise3",
	pennywise4: "games.betrayal3.label_hauntpennywise4",
	pennywise5: "games.betrayal3.label_hauntpennywise5"
}, to = {
	yellow: "#e6bc3b",
	green: "#5c9c63",
	red: "#b34b45",
	white: "#ded8c7",
	blue: "#6699ba",
	purple: "#ad7fbc",
	silver: "#aeb8b4"
};
function no({ number: e, stunned: t = !1 }) {
	return /* @__PURE__ */ i("span", {
		className: `b3-monster-disc${t ? " b3-monster-stunned" : ""}`,
		children: e
	});
}
function ro({ kind: e }) {
	let t = e.startsWith("omen") ? "omen" : e.startsWith("event") ? "event" : "item";
	return /* @__PURE__ */ i("svg", {
		viewBox: "0 0 60 48",
		"aria-hidden": !0,
		className: "b3-glyph",
		children: /* @__PURE__ */ i("image", {
			href: `games/betrayal3/icons/${t}.svg`,
			width: "60",
			height: "48"
		})
	});
}
function io({ room: e, label: t, selected: n = !1 }) {
	let r = g(e.tile);
	return /* @__PURE__ */ a("g", {
		className: `b3-tile${n ? " b3-tile-selected" : ""}`,
		children: [
			/* @__PURE__ */ i("rect", {
				x: "2",
				y: "2",
				width: "172",
				height: "172",
				rx: "5",
				fill: "#151d19",
				stroke: "#a2936f",
				strokeWidth: "2"
			}),
			!e.condition && /* @__PURE__ */ i("image", {
				href: `games/betrayal3/rooms/${e.tile}.svg`,
				x: "10",
				y: "10",
				width: "156",
				height: "156",
				transform: `rotate(${e.rotation * 90} 88 88)`
			}),
			e.condition && /* @__PURE__ */ a("g", { children: [/* @__PURE__ */ i("path", {
				fill: e.condition === "flooded" ? "#305c65" : e.condition === "burning" ? "#79452f" : "#3e3c35",
				d: "M10 10H166V166H10Z"
			}), /* @__PURE__ */ i("path", {
				stroke: "#b2a68b",
				opacity: ".3",
				fill: "none",
				strokeWidth: "3",
				d: "M18 23 60 48 47 94 114 150M37 10 84 56 145 84 166 51M16 132 54 116 96 126 165 112"
			})] }),
			/* @__PURE__ */ i("g", {
				fill: "#141a17",
				stroke: "#d3bc8b",
				strokeWidth: "2",
				children: Fe(e).map((e) => /* @__PURE__ */ i("path", {
					transform: `rotate(${e * 90} 88 88)`,
					d: "M69 2V15H107V2"
				}, e))
			}),
			/* @__PURE__ */ i("path", {
				d: "M9 130H167V166H9Z",
				fill: "#101a16",
				opacity: ".94"
			}),
			r.symbol && !e.condition && /* @__PURE__ */ i("image", {
				href: `games/betrayal3/icons/${r.symbol.startsWith("omen") ? "omen" : r.symbol.startsWith("event") ? "event" : "item"}.svg`,
				x: "137",
				y: "108",
				width: "30",
				height: "24"
			}),
			/* @__PURE__ */ i("foreignObject", {
				x: "12",
				y: "133",
				width: "152",
				height: "30",
				children: /* @__PURE__ */ i("div", {
					className: "b3-room-name",
					children: t
				})
			}),
			n && /* @__PURE__ */ i("rect", {
				x: "3",
				y: "3",
				width: "170",
				height: "170",
				rx: "5",
				fill: "none",
				stroke: "#f1d27c",
				strokeWidth: "3",
				strokeDasharray: "11 7",
				children: /* @__PURE__ */ i("animate", {
					attributeName: "stroke-dashoffset",
					from: "0",
					to: "-36",
					dur: "1s",
					repeatCount: "indefinite"
				})
			})
		]
	});
}
function ao({ id: e, onClick: t, compact: n = !1 }) {
	let o = l(), s = Me(e), c = /* @__PURE__ */ a(r, { children: [
		/* @__PURE__ */ a("div", {
			className: "b3-portrait",
			children: [/* @__PURE__ */ i("img", {
				src: `games/betrayal3/characters/${e}.svg`,
				alt: ""
			}), /* @__PURE__ */ i("span", { children: o($a[e]) })]
		}),
		/* @__PURE__ */ i("div", {
			className: "b3-char-traits",
			children: w.map((e) => /* @__PURE__ */ a("span", { children: [o($a[e]), /* @__PURE__ */ i("b", { children: s.tracks[e][s.start[e]] })] }, e))
		}),
		!n && /* @__PURE__ */ i("small", { children: s.birthday && s.age !== null ? o("games.betrayal3.uiBirthday", {
			date: s.birthday,
			n: s.age
		}) : o("games.betrayal3.uiUnknownBirthday") })
	] }), u = { "--b3-character": to[s.group] };
	return t ? /* @__PURE__ */ i("button", {
		className: "b3-character b3-choice",
		style: u,
		onClick: t,
		children: c
	}) : /* @__PURE__ */ i("div", {
		className: "b3-character",
		style: u,
		children: c
	});
}
function oo({ dice: e }) {
	return /* @__PURE__ */ i("div", {
		className: "b3-dice",
		children: e.map((e, t) => /* @__PURE__ */ a("svg", {
			viewBox: "0 0 40 40",
			className: "b3-die",
			"aria-label": String(e),
			children: [
				/* @__PURE__ */ i("rect", {
					x: "2",
					y: "2",
					width: "36",
					height: "36",
					rx: "7",
					fill: "#e8dfc5",
					stroke: "#655d46",
					strokeWidth: "2"
				}),
				e === 1 && /* @__PURE__ */ i("circle", {
					cx: "20",
					cy: "20",
					r: "4",
					fill: "#1a211a"
				}),
				e === 2 && /* @__PURE__ */ a("g", {
					fill: "#1a211a",
					children: [/* @__PURE__ */ i("circle", {
						cx: "13",
						cy: "13",
						r: "4"
					}), /* @__PURE__ */ i("circle", {
						cx: "27",
						cy: "27",
						r: "4"
					})]
				})
			]
		}, t))
	});
}
we.map((e) => e.id);
//#endregion
//#region src/game/music.tsx
function so(e) {
	let t = 22050, n = e.createBuffer(1, t * 24, t), r = n.getChannelData(0), i = [
		146.83,
		164.81,
		174.61,
		138.59,
		146.83,
		220,
		207.65,
		164.81
	];
	for (let e = 0; e < r.length; e++) {
		let n = e / t, a = Math.floor(n / 3), o = n % 3, s = Math.sin(Math.PI * n / 24) ** 2, c = Math.sin(2 * Math.PI * 73.416 * n) + .4 * Math.sin(2 * Math.PI * 110 * n), l = Math.sin(2 * Math.PI * i[a] * n) + .22 * Math.sin(2 * Math.PI * i[a] * 2.003 * n);
		r[e] = .09 * s * c + .055 * Math.min(1, o * 8) * Math.exp(-o * 1.8) * l;
	}
	return n;
}
function co() {
	let e = l(), t = s(null), n = s(!1), [r, u] = c(!1), [d, f] = c(!1);
	o(() => () => {
		let e = t.current;
		t.current = null, e?.close().catch(() => void 0);
	}, []);
	let p = async () => {
		if (!n.current) {
			if (n.current = !0, t.current) {
				let e = t.current;
				t.current = null, u(!1), await e.close().catch(() => void 0), n.current = !1;
				return;
			}
			try {
				let e = new AudioContext();
				t.current = e;
				let n = e.createBufferSource();
				n.buffer = so(e), n.loop = !0;
				let r = e.createGain();
				if (r.gain.value = .5, n.connect(r), r.connect(e.destination), await e.resume(), t.current !== e) {
					await e.close();
					return;
				}
				n.start(), u(!0), f(!1);
			} catch {
				let e = t.current;
				t.current = null, await e?.close().catch(() => void 0), f(!0), u(!1);
			} finally {
				n.current = !1;
			}
		}
	};
	return /* @__PURE__ */ a("div", {
		className: "b3-music",
		children: [/* @__PURE__ */ i("button", {
			className: "b3-button",
			"aria-pressed": r,
			onClick: () => void p(),
			children: e(r ? "games.betrayal3.uiMusicOff" : "games.betrayal3.uiMusicOn")
		}), d && /* @__PURE__ */ i("span", {
			role: "status",
			children: e("games.betrayal3.uiMusicFailed")
		})]
	});
}
//#endregion
//#region src/game/objectives.ts
var lo = {
	1: {
		hero: "games.betrayal3.objective_1_hero",
		traitor: "games.betrayal3.objective_1_traitor"
	},
	2: {
		hero: "games.betrayal3.objective_2_hero",
		traitor: "games.betrayal3.objective_2_traitor"
	},
	3: {
		hero: "games.betrayal3.objective_3_hero",
		traitor: "games.betrayal3.objective_3_traitor"
	},
	4: {
		hero: "games.betrayal3.objective_4_hero",
		traitor: "games.betrayal3.objective_4_traitor"
	},
	5: {
		hero: "games.betrayal3.objective_5_hero",
		traitor: "games.betrayal3.objective_5_traitor"
	},
	6: {
		hero: "games.betrayal3.objective_6_hero",
		traitor: "games.betrayal3.objective_6_traitor"
	},
	7: {
		hero: "games.betrayal3.objective_7_hero",
		traitor: "games.betrayal3.objective_7_traitor"
	},
	8: {
		hero: "games.betrayal3.objective_8_hero",
		traitor: "games.betrayal3.objective_8_traitor"
	},
	9: {
		hero: "games.betrayal3.objective_9_hero",
		traitor: "games.betrayal3.objective_9_traitor"
	},
	10: {
		hero: "games.betrayal3.objective_10_hero",
		traitor: "games.betrayal3.objective_10_traitor"
	},
	11: {
		hero: "games.betrayal3.objective_11_hero",
		traitor: "games.betrayal3.objective_11_traitor"
	},
	12: {
		hero: "games.betrayal3.objective_12_hero",
		traitor: "games.betrayal3.objective_12_traitor"
	},
	13: {
		hero: "games.betrayal3.objective_13_hero",
		traitor: "games.betrayal3.objective_13_traitor"
	},
	14: {
		hero: "games.betrayal3.objective_14_hero",
		traitor: "games.betrayal3.objective_14_traitor"
	},
	15: {
		hero: "games.betrayal3.objective_15_hero",
		traitor: "games.betrayal3.objective_15_traitor"
	},
	16: {
		hero: "games.betrayal3.objective_16_hero",
		traitor: "games.betrayal3.objective_16_traitor"
	},
	17: {
		hero: "games.betrayal3.objective_17_hero",
		traitor: "games.betrayal3.objective_17_traitor"
	},
	18: {
		hero: "games.betrayal3.objective_18_hero",
		traitor: "games.betrayal3.objective_18_traitor"
	},
	19: {
		hero: "games.betrayal3.objective_19_hero",
		traitor: "games.betrayal3.objective_19_traitor"
	},
	20: {
		hero: "games.betrayal3.objective_20_hero",
		traitor: "games.betrayal3.objective_20_traitor"
	},
	21: {
		hero: "games.betrayal3.objective_21_hero",
		traitor: "games.betrayal3.objective_21_traitor"
	},
	22: {
		hero: "games.betrayal3.objective_22_hero",
		traitor: "games.betrayal3.objective_22_traitor"
	},
	23: {
		hero: "games.betrayal3.objective_23_hero",
		traitor: "games.betrayal3.objective_23_traitor"
	},
	24: {
		hero: "games.betrayal3.objective_24_hero",
		traitor: "games.betrayal3.objective_24_traitor"
	},
	25: {
		hero: "games.betrayal3.objective_25_hero",
		traitor: "games.betrayal3.objective_25_traitor"
	},
	26: {
		hero: "games.betrayal3.objective_26_hero",
		traitor: "games.betrayal3.objective_26_traitor"
	},
	27: {
		hero: "games.betrayal3.objective_27_hero",
		traitor: "games.betrayal3.objective_27_traitor"
	},
	28: {
		hero: "games.betrayal3.objective_28_hero",
		traitor: "games.betrayal3.objective_28_traitor"
	},
	29: {
		hero: "games.betrayal3.objective_29_hero",
		traitor: "games.betrayal3.objective_29_traitor"
	},
	30: {
		hero: "games.betrayal3.objective_30_hero",
		traitor: "games.betrayal3.objective_30_traitor"
	},
	31: {
		hero: "games.betrayal3.objective_31_hero",
		traitor: "games.betrayal3.objective_31_traitor"
	},
	32: {
		hero: "games.betrayal3.objective_32_hero",
		traitor: "games.betrayal3.objective_32_traitor"
	},
	33: {
		hero: "games.betrayal3.objective_33_hero",
		traitor: "games.betrayal3.objective_33_traitor"
	},
	34: {
		hero: "games.betrayal3.objective_34_hero",
		traitor: "games.betrayal3.objective_34_traitor"
	},
	35: {
		hero: "games.betrayal3.objective_35_hero",
		traitor: "games.betrayal3.objective_35_traitor"
	},
	36: {
		hero: "games.betrayal3.objective_36_hero",
		traitor: "games.betrayal3.objective_36_traitor"
	},
	37: {
		hero: "games.betrayal3.objective_37_hero",
		traitor: "games.betrayal3.objective_37_traitor"
	},
	38: {
		hero: "games.betrayal3.objective_38_hero",
		traitor: "games.betrayal3.objective_38_traitor"
	},
	39: {
		hero: "games.betrayal3.objective_39_hero",
		traitor: "games.betrayal3.objective_39_traitor"
	},
	40: {
		hero: "games.betrayal3.objective_40_hero",
		traitor: "games.betrayal3.objective_40_traitor"
	},
	41: {
		hero: "games.betrayal3.objective_41_hero",
		traitor: "games.betrayal3.objective_41_traitor"
	},
	42: {
		hero: "games.betrayal3.objective_42_hero",
		traitor: "games.betrayal3.objective_42_traitor"
	},
	43: {
		hero: "games.betrayal3.objective_43_hero",
		traitor: "games.betrayal3.objective_43_traitor"
	},
	44: {
		hero: "games.betrayal3.objective_44_hero",
		traitor: "games.betrayal3.objective_44_traitor"
	},
	45: {
		hero: "games.betrayal3.objective_45_hero",
		traitor: "games.betrayal3.objective_45_traitor"
	},
	46: {
		hero: "games.betrayal3.objective_46_hero",
		traitor: "games.betrayal3.objective_46_traitor"
	},
	47: {
		hero: "games.betrayal3.objective_47_hero",
		traitor: "games.betrayal3.objective_47_traitor"
	},
	48: {
		hero: "games.betrayal3.objective_48_hero",
		traitor: "games.betrayal3.objective_48_traitor"
	},
	49: {
		hero: "games.betrayal3.objective_49_hero",
		traitor: "games.betrayal3.objective_49_traitor"
	},
	50: {
		hero: "games.betrayal3.objective_50_hero",
		traitor: "games.betrayal3.objective_50_traitor"
	},
	blood1: {
		hero: "games.betrayal3.objective_blood1_hero",
		traitor: "games.betrayal3.objective_blood1_traitor"
	},
	blood2: {
		hero: "games.betrayal3.objective_blood2_hero",
		traitor: "games.betrayal3.objective_blood2_traitor"
	},
	blood3: {
		hero: "games.betrayal3.objective_blood3_hero",
		traitor: "games.betrayal3.objective_blood3_traitor"
	},
	blood4: {
		hero: "games.betrayal3.objective_blood4_hero",
		traitor: "games.betrayal3.objective_blood4_traitor"
	},
	blood5: {
		hero: "games.betrayal3.objective_blood5_hero",
		traitor: "games.betrayal3.objective_blood5_traitor"
	},
	yuletide1: {
		hero: "games.betrayal3.objective_yuletide1_hero",
		traitor: "games.betrayal3.objective_yuletide1_traitor"
	},
	yuletide2: {
		hero: "games.betrayal3.objective_yuletide2_hero",
		traitor: "games.betrayal3.objective_yuletide2_traitor"
	},
	yuletide3: {
		hero: "games.betrayal3.objective_yuletide3_hero",
		traitor: "games.betrayal3.objective_yuletide3_traitor"
	},
	yuletide4: {
		hero: "games.betrayal3.objective_yuletide4_hero",
		traitor: "games.betrayal3.objective_yuletide4_traitor"
	},
	yuletide5: {
		hero: "games.betrayal3.objective_yuletide5_hero",
		traitor: "games.betrayal3.objective_yuletide5_traitor"
	},
	pennywise1: {
		hero: "games.betrayal3.objective_pennywise1_hero",
		traitor: "games.betrayal3.objective_pennywise1_traitor"
	},
	pennywise2: {
		hero: "games.betrayal3.objective_pennywise2_hero",
		traitor: "games.betrayal3.objective_pennywise2_traitor"
	},
	pennywise3: {
		hero: "games.betrayal3.objective_pennywise3_hero",
		traitor: "games.betrayal3.objective_pennywise3_traitor"
	},
	pennywise4: {
		hero: "games.betrayal3.objective_pennywise4_hero",
		traitor: "games.betrayal3.objective_pennywise4_traitor"
	},
	pennywise5: {
		hero: "games.betrayal3.objective_pennywise5_hero",
		traitor: "games.betrayal3.objective_pennywise5_traitor"
	}
}, uo = {
	machete: "games.betrayal3.detail_machete",
	crossbow: "games.betrayal3.detail_crossbow",
	firstAidKit: "games.betrayal3.detail_firstAidKit",
	mirror: "games.betrayal3.detail_mirror",
	angelsFeather: "games.betrayal3.detail_angelsFeather",
	strangeMedicine: "games.betrayal3.detail_strangeMedicine",
	mysticalStopwatch: "games.betrayal3.detail_mysticalStopwatch",
	skeletonKey: "games.betrayal3.detail_skeletonKey",
	strangeAmulet: "games.betrayal3.detail_strangeAmulet",
	dynamite: "games.betrayal3.detail_dynamite",
	magicCamera: "games.betrayal3.detail_magicCamera",
	headphones: "games.betrayal3.detail_headphones",
	gun: "games.betrayal3.detail_gun",
	rabbitsFoot: "games.betrayal3.detail_rabbitsFoot",
	flashlight: "games.betrayal3.detail_flashlight",
	luckyCoin: "games.betrayal3.detail_luckyCoin",
	map: "games.betrayal3.detail_map",
	necklaceOfTeeth: "games.betrayal3.detail_necklaceOfTeeth",
	brooch: "games.betrayal3.detail_brooch",
	leatherJacket: "games.betrayal3.detail_leatherJacket",
	chainsaw: "games.betrayal3.detail_chainsaw",
	creepyDoll: "games.betrayal3.detail_creepyDoll",
	dog: "games.betrayal3.detail_dog",
	holySymbol: "games.betrayal3.detail_holySymbol",
	idol: "games.betrayal3.detail_idol",
	dagger: "games.betrayal3.detail_dagger",
	ring: "games.betrayal3.detail_ring",
	skull: "games.betrayal3.detail_skull",
	book: "games.betrayal3.detail_book",
	armor: "games.betrayal3.detail_armor",
	mask: "games.betrayal3.detail_mask",
	fangBracelet: "games.betrayal3.detail_fangBracelet",
	wolfsbane: "games.betrayal3.detail_wolfsbane",
	unusualCake: "games.betrayal3.detail_unusualCake",
	snowGlobe: "games.betrayal3.detail_snowGlobe",
	hiddenOmen: "games.betrayal3.detail_hiddenOmen",
	armory: "games.betrayal3.detail_armory",
	junkRoom: "games.betrayal3.detail_junkRoom",
	panicRoom: "games.betrayal3.detail_panicRoom",
	laundryChute: "games.betrayal3.detail_laundryChute",
	chapel: "games.betrayal3.detail_chapel",
	secretStaircase: "games.betrayal3.detail_secretStaircase",
	library: "games.betrayal3.detail_library",
	larder: "games.betrayal3.detail_larder",
	gymnasium: "games.betrayal3.detail_gymnasium",
	undergroundCavern: "games.betrayal3.detail_undergroundCavern",
	mysticElevator: "games.betrayal3.detail_mysticElevator",
	gallery: "games.betrayal3.detail_gallery",
	graveyard: "games.betrayal3.detail_graveyard",
	furnaceRoom: "games.betrayal3.detail_furnaceRoom",
	collapsedRoom: "games.betrayal3.detail_collapsedRoom",
	groundStaircase: "games.betrayal3.detail_groundStaircase",
	upperLanding: "games.betrayal3.detail_upperLanding",
	basementLanding: "games.betrayal3.detail_basementLanding",
	hallway: "games.betrayal3.detail_hallway",
	entranceHall: "games.betrayal3.detail_entranceHall",
	oubliette: "games.betrayal3.detail_oubliette",
	trophyRoom: "games.betrayal3.detail_trophyRoom",
	timeLostTree: "games.betrayal3.detail_timeLostTree",
	rootCellar: "games.betrayal3.detail_rootCellar",
	ancientDen: "games.betrayal3.detail_ancientDen",
	windingTunnels: "games.betrayal3.detail_windingTunnels",
	darkenedHallway: "games.betrayal3.detail_darkenedHallway",
	oldWell: "games.betrayal3.detail_oldWell"
}, fo = {
	...uo,
	secretElevator: "games.betrayal3.detail_secretElevator",
	creakingDoor: "games.betrayal3.detail_creakingDoor",
	cryForHelp: "games.betrayal3.detail_cryForHelp",
	momentOfHope: "games.betrayal3.detail_momentOfHope",
	darkStormyNight: "games.betrayal3.detail_darkStormyNight",
	spiders: "games.betrayal3.detail_spiders",
	meatMoss: "games.betrayal3.detail_meatMoss",
	eerieFeeling: "games.betrayal3.detail_eerieFeeling",
	hangedMen: "games.betrayal3.detail_hangedMen",
	poorYorick: "games.betrayal3.detail_poorYorick",
	impossibleArchitecture: "games.betrayal3.detail_impossibleArchitecture",
	alienGeometry: "games.betrayal3.detail_alienGeometry",
	bite: "games.betrayal3.detail_bite",
	funeral: "games.betrayal3.detail_funeral",
	jonahsTurn: "games.betrayal3.detail_jonahsTurn",
	flickeringLights: "games.betrayal3.detail_flickeringLights",
	flowering: "games.betrayal3.detail_flowering",
	fullTable: "games.betrayal3.detail_fullTable",
	deepestCloset: "games.betrayal3.detail_deepestCloset",
	burningFigure: "games.betrayal3.detail_burningFigure",
	behindYou: "games.betrayal3.detail_behindYou",
	clownRoom: "games.betrayal3.detail_clownRoom",
	radioBroadcast: "games.betrayal3.detail_radioBroadcast",
	tinyRobot: "games.betrayal3.detail_tinyRobot",
	taxidermy: "games.betrayal3.detail_taxidermy",
	severedHand: "games.betrayal3.detail_severedHand",
	phoneCall: "games.betrayal3.detail_phoneCall",
	batOutOfHell: "games.betrayal3.detail_batOutOfHell",
	sayCheese: "games.betrayal3.detail_sayCheese",
	mysteriousFluid: "games.betrayal3.detail_mysteriousFluid",
	splashOfCrimson: "games.betrayal3.detail_splashOfCrimson",
	forbiddenKnowledge: "games.betrayal3.detail_forbiddenKnowledge",
	vialOfDust: "games.betrayal3.detail_vialOfDust",
	cassettePlayer: "games.betrayal3.detail_cassettePlayer",
	eerieMirror: "games.betrayal3.detail_eerieMirror",
	oldestHouse: "games.betrayal3.detail_oldestHouse",
	jarOfOrgans: "games.betrayal3.detail_jarOfOrgans",
	technicalDifficulties: "games.betrayal3.detail_technicalDifficulties",
	wanderingGhost: "games.betrayal3.detail_wanderingGhost",
	starsAtNight: "games.betrayal3.detail_starsAtNight",
	brainFood: "games.betrayal3.detail_brainFood",
	secretPassage: "games.betrayal3.detail_secretPassage",
	houseIsHungry: "games.betrayal3.detail_houseIsHungry",
	hunt: "games.betrayal3.detail_hunt",
	bloodMoon: "games.betrayal3.detail_bloodMoon",
	feast: "games.betrayal3.detail_feast",
	gift: "games.betrayal3.detail_gift",
	floatingLights: "games.betrayal3.detail_floatingLights",
	knifeInDark: "games.betrayal3.detail_knifeInDark",
	bloodTendrils: "games.betrayal3.detail_bloodTendrils",
	goodBoy: "games.betrayal3.detail_goodBoy",
	popOfRed: "games.betrayal3.detail_popOfRed",
	hometownHorrors: "games.betrayal3.detail_hometownHorrors",
	swirlingVisions: "games.betrayal3.detail_swirlingVisions",
	stretchingHall: "games.betrayal3.detail_stretchingHall",
	timeToSink: "games.betrayal3.detail_timeToSink",
	eaterOfWorlds: "games.betrayal3.detail_eaterOfWorlds"
}, po = {
	U: "games.betrayal3.uiFloorU",
	G: "games.betrayal3.uiFloorG",
	B: "games.betrayal3.uiFloorB"
}, mo = {
	hero: "games.betrayal3.uiHero",
	traitor: "games.betrayal3.uiTraitor",
	individual: "games.betrayal3.uiIndividual",
	unknown: "games.betrayal3.uiUnknown"
}, ho = {
	N: "games.betrayal3.uiN",
	E: "games.betrayal3.uiE",
	S: "games.betrayal3.uiS",
	W: "games.betrayal3.uiW"
}, go = {
	might: "games.betrayal3.uiShortMight",
	speed: "games.betrayal3.uiShortSpeed",
	sanity: "games.betrayal3.uiShortSanity",
	knowledge: "games.betrayal3.uiShortKnowledge"
}, _o = {
	item: "games.betrayal3.uiCardItem",
	omen: "games.betrayal3.uiCardOmen",
	event: "games.betrayal3.uiCardEvent",
	encounter: "games.betrayal3.uiCardEncounter"
}, vo = /* @__PURE__ */ new Set([
	"logMessageDie",
	"logMessageX",
	"logSyllableFound",
	"logHeroDieRemoved",
	"logOmenRevealed",
	"logInterrogate"
]);
function yo(e, t) {
	return n[(e.find((e) => e.rid === t)?.avatar ?? 0) % n.length];
}
function bo({ choice: e, nameOf: t }) {
	let n = l(), i = n(e.key, Object.fromEntries(Object.entries(e.params ?? {}).map(([e, n]) => [e, typeof n == "string" && ($a[n] || ho[n]) ? t(n) : n]))) + (e.params?.weapon ? ` · ${t(String(e.params.weapon))}` : "");
	return e.id.startsWith("discover-") && e.target && ho[e.target] ? n("games.betrayal3.uiDoor", { direction: n(ho[e.target]) }) : e.kind === "rotation" ? n("games.betrayal3.uiRotation", { n: (e.value ?? 0) * 90 }) : e.target ? n("games.betrayal3.uiRoomChoice", {
		action: i,
		name: t(e.target)
	}) : /* @__PURE__ */ a(r, { children: [i, e.value !== void 0 && ` · ${e.value}`] });
}
function xo({ x: e = 2, y: t = 2, w: n = 172, h: r = 172 }) {
	return /* @__PURE__ */ i("rect", {
		x: e,
		y: t,
		width: n,
		height: r,
		rx: "5",
		fill: "#e7d58a",
		fillOpacity: ".12",
		stroke: "#f4d578",
		strokeWidth: "3",
		strokeDasharray: "10 7",
		pointerEvents: "none",
		children: /* @__PURE__ */ i("animate", {
			attributeName: "stroke-dashoffset",
			from: "0",
			to: "-34",
			dur: ".8s",
			repeatCount: "indefinite"
		})
	});
}
function So(e) {
	return /* @__PURE__ */ i(Co, {
		...e,
		pub: e.public,
		priv: e.private
	});
}
function Co({ pub: e, priv: t, members: n, myRid: u, send: ee, readOnly: ue = !1 }) {
	re();
	let m = l(), de = ue ? [] : t?.choices ?? [];
	ce(de.length > 0, se);
	let fe = e.explorers.find((e) => e.rid === u), pe = e.rooms.find((e) => e.id === v(fe?.room ?? "entranceHall")), me = `${u}:${pe?.floor ?? "G"}`, [he, ge] = c({
		key: me,
		floor: pe?.floor ?? "G"
	});
	he.key !== me && ge({
		key: me,
		floor: pe?.floor ?? "G"
	});
	let _e = he.key === me ? he.floor : pe?.floor ?? "G", [ve, ye] = c(0), [be, xe] = c(null), [Se, Ce] = c(null), [we, Te] = c(u), [h, Ee] = c({
		key: "",
		rotation: 0,
		open: !0
	}), De = e.explorers.find((e) => e.rid === we) ?? fe, { ref: Oe } = oe("house"), ke = s(null), Ae = s(null), je = s(null), g = s(null), _ = (t) => {
		let r = n.find((e) => e.rid === t);
		if (r) return r.name;
		if ($a[t]) return m($a[t]);
		if (t.includes(":") && ($a[t.split(":")[0]] || e.tokens.some((e) => e.id === t.split(":")[0]) || e.monsters.some((e) => e.id === t.split(":")[0]))) return _(t.split(":")[0]) + (t.endsWith(":a") ? " A" : t.endsWith(":b") ? " B" : ` · ${t.split(":").slice(1).map((e) => $a[e] ? m($a[e]) : e).join(" · ")}`);
		let i = e.monsters.find((e) => e.id === t);
		if (i) return _(i.kind) + (i.number === null ? "" : ` ${i.number}`);
		let a = e.tokens.find((e) => e.id === t);
		return a ? _(a.kind) + (a.value !== null && a.value !== 0 ? ` ${a.value}` : a.hidden ? ` · ${m("games.betrayal3.uiHidden")}` : "") : ho[t] ? m(ho[t]) : /^-?\d+$/.test(t) ? t : [
			"U",
			"G",
			"B"
		].includes(t) ? m(po[t]) : m("games.betrayal3.uiObject");
	}, Ne = (e) => {
		ue || ee({
			type: "act",
			id: e.id
		}), xe(null);
	}, y = (e) => {
		let t = je.current, n = t?.firstElementChild;
		if (!t || !n) return;
		let r = t.getBoundingClientRect();
		n.dispatchEvent(new WheelEvent("wheel", {
			bubbles: !0,
			cancelable: !0,
			deltaY: e > 0 ? -120 : 120,
			clientX: r.left + r.width / 2,
			clientY: r.top + r.height / 2
		}));
	}, Fe = (t) => {
		(e.explorers.find((e) => e.rid === t) ?? fe) && (Te(t), Ce("dossier"));
	}, Ie = e.rooms.filter((e) => e.floor === _e), b = e.discovery?.floor === _e ? e.discovery : null, Le = de.filter((e) => e.kind === "rotation"), Re = Le.map((e) => e.value ?? 0), ze = e.discovery ? `${e.discovery.tile}:${e.discovery.floor}:${e.discovery.x}:${e.discovery.y}` : "";
	h.key === ze ? Re.length > 0 && !Re.includes(h.rotation) && Ee({
		...h,
		rotation: Re[0]
	}) : Ee({
		key: ze,
		rotation: Re[0] ?? 0,
		open: !0
	});
	let x = [...Ie, ...b ? [b] : []], S = x.length ? Math.min(...x.map((e) => e.x)) : 0, Be = x.length ? Math.min(...x.map((e) => e.y)) : 0, C = x.length ? Math.max(...x.map((e) => e.x)) : 0, Ve = x.length ? Math.max(...x.map((e) => e.y)) : 0, He = (C - S + 1) * 190, Ue = (Ve - Be + 1) * 190, We = (e) => ({
		x: (e.x - S) * 190 + 8,
		y: (e.y - Be) * 190 + 8,
		w: 176,
		h: 176
	}), Ge = (t) => {
		if (!t) return;
		let n = e.explorers.find((e) => e.rid === t)?.room ?? e.monsters.find((e) => e.id === t)?.room ?? e.tokens.find((e) => e.id === t)?.room ?? t;
		return e.rooms.find((e) => e.id === v(n ?? ""));
	}, Ke = (e) => de.filter((t) => [
		"room",
		"player",
		"token"
	].includes(t.kind) && Ge(t.target)?.id === e.id), qe = de.filter((e) => [
		"room",
		"player",
		"token"
	].includes(e.kind) && Ge(e.target)), Je = de.filter((e) => e.id.startsWith("discover-")), Ye = e.rooms.find((t) => t.id === v(e.explorers.find((t) => t.rid === e.turn)?.room ?? "")), T = Ie.map((e) => ({
		key: e.id,
		rect: We(e)
	})), E = Ye?.floor === _e ? Je.map((e) => {
		let [t, n] = Pe[Number(e.id.slice(-1))], r = We(Ye);
		return {
			c: e,
			rect: {
				x: r.x + 66 + t * 102,
				y: r.y + 66 + n * 102,
				w: 44,
				h: 44
			}
		};
	}) : [];
	T.push(...E.map(({ c: e, rect: t }) => ({
		key: e.id,
		rect: t
	}))), b && T.push({
		key: "preview",
		rect: We(b)
	});
	let Xe = Ie.find((e) => e.id === be), Ze = Xe ? Ke(Xe) : [], D = de.filter((e) => e.kind === "action" && !e.id.startsWith("discover-") || [
		"room",
		"player",
		"token"
	].includes(e.kind) && !Ge(e.target)), O = de.filter((e) => e.kind === "card"), Qe = de.filter((e) => e.kind === "trait"), $e = de.some((e) => e.kind === "character"), et = t?.team ?? fe?.team ?? "unknown", k = e.haunt ? lo[e.haunt.id]?.[et === "traitor" ? "traitor" : "hero"] : void 0, tt = t?.pending ?? e.pending, nt = tt ? m(tt.key, Object.fromEntries(Object.entries(tt.params ?? {}).map(([e, t]) => [e, typeof t == "string" && $a[t] ? _(t) : t]))) : de.length ? m("games.betrayal3.takeTurn") : m("games.betrayal3.uiResolve"), A = e.reveal, j = new Set(qe.flatMap((e) => {
		let t = Ge(e.target);
		return t ? [t.id] : [];
	})), M = e.phase === "characters" ? [] : e.explorers.filter((t) => t.room && e.rooms.some((e) => e.id === v(t.room) && e.floor === _e)).map((t) => {
		let r = e.rooms.find((e) => e.id === v(t.room)), i = We(r), a = Xa(e.explorers.filter((e) => e.room === t.room).findIndex((e) => e.rid === t.rid), !1);
		return {
			explorer: t,
			x: i.x + a.x + a.size / 2,
			y: i.y + a.y + a.size / 2,
			name: _(t.rid),
			avatar: yo(n, t.rid),
			active: t.rid === e.turn,
			critical: w.some((e) => t.traits[e] <= 0)
		};
	}), N = /* @__PURE__ */ a("header", {
		className: "b3-header",
		children: [
			/* @__PURE__ */ a("div", { children: [/* @__PURE__ */ i("span", {
				className: "b3-kicker",
				children: e.haunt ? m("games.betrayal3.uiHaunt") : _(e.scenario)
			}), /* @__PURE__ */ i("h1", { children: e.haunt ? m(eo[e.haunt.id]) : m("games.betrayal3.uiHouse") })] }),
			/* @__PURE__ */ i("span", {
				className: "b3-turn",
				children: m("games.betrayal3.uiTurn", { n: e.turnNumber })
			}),
			/* @__PURE__ */ a("div", {
				className: "b3-header-tools",
				children: [
					/* @__PURE__ */ i(co, {}),
					/* @__PURE__ */ i("button", {
						className: "b3-icon",
						onClick: () => Ce("objective"),
						"aria-label": m("games.betrayal3.uiObjective"),
						children: /* @__PURE__ */ i(p, { size: 19 })
					}),
					/* @__PURE__ */ i("button", {
						className: "b3-icon",
						onClick: () => Ce("journal"),
						"aria-label": m("games.betrayal3.uiJournal"),
						children: /* @__PURE__ */ i(f, { size: 19 })
					})
				]
			})
		]
	}), P = /* @__PURE__ */ a("div", {
		className: "b3-dock",
		children: [/* @__PURE__ */ a("div", {
			className: `b3-prompt${de.length ? " b3-prompt-active" : ""}`,
			role: "status",
			children: [/* @__PURE__ */ i("b", { children: ue ? m("games.betrayal3.uiReview") : nt }), !ue && /* @__PURE__ */ a("span", { children: [de.length ? _(u) : m("games.betrayal3.uiWait", { name: _(e.pending?.actor ?? e.turn) }), e.phase !== "characters" && ` · ${m("games.betrayal3.uiMovement", { n: e.movement })}`] })]
		}), /* @__PURE__ */ a("div", {
			className: "b3-actions",
			children: [D.map((e) => /* @__PURE__ */ i("button", {
				className: "b3-button",
				onClick: () => Ne(e),
				children: /* @__PURE__ */ i(bo, {
					choice: e,
					nameOf: _
				})
			}, e.id)), (O.length > 0 || Qe.length > 0) && /* @__PURE__ */ i("button", {
				className: "b3-button",
				onClick: () => Fe(u),
				children: m("games.betrayal3.uiDossier")
			})]
		})]
	}), F = [...e.journal, ...t?.journal ?? []].sort((e, t) => e.order - t.order), rt = F.length;
	o(() => {
		if (Se !== "journal") return;
		let e = g.current;
		e && (e.scrollTop = e.scrollHeight);
	}, [Se, rt]);
	let it = /* @__PURE__ */ i("div", {
		className: "b3-journal",
		children: F.length ? F.map((e) => {
			if (e.key === "games.betrayal3.logTurn") return /* @__PURE__ */ a("h4", {
				className: "b3-journal-turn",
				children: [m("games.betrayal3.uiTurn", { n: e.n ?? 0 }), e.actor && ` · ${_(e.actor)}`]
			}, e.order);
			let t = e.key.slice(16), n = m(e.key, {
				n: e.n ?? 0,
				actor: e.actor ? _(e.actor) : "",
				id: e.id ? _(e.id) : "",
				target: e.target ? _(e.target) : ""
			});
			return /* @__PURE__ */ a("p", { children: [
				e.actor && !vo.has(t) && /* @__PURE__ */ a("b", { children: [_(e.actor), " · "] }),
				n,
				e.id && t !== "logOmenRevealed" && ` · ${eo[e.id] && e.key === "games.betrayal3.logHaunt" ? m(eo[e.id]) : _(e.id)}`,
				e.target && t !== "logInterrogate" && ` · ${_(e.target)}`
			] }, e.order);
		}) : /* @__PURE__ */ i("p", {
			className: "b3-journal-empty",
			children: m("games.betrayal3.uiJournalEmpty")
		})
	}), I = /* @__PURE__ */ a(r, { children: [
		/* @__PURE__ */ i("h3", { children: m(mo[et] ?? mo.unknown) }),
		e.haunt && /* @__PURE__ */ i("p", { children: m("games.betrayal3.uiTrackValue", { n: e.haunt.track }) }),
		k ? /* @__PURE__ */ i("p", {
			className: "b3-objective-text",
			children: m(k)
		}) : /* @__PURE__ */ i("div", {
			className: "b3-objective-text",
			children: /* @__PURE__ */ i(Qa, { text: m("games.betrayal3.rules") })
		}),
		/* @__PURE__ */ i(Mo, {
			pub: e,
			nameOf: _
		}),
		/* @__PURE__ */ i(No, {
			pub: e,
			priv: t,
			myRid: u,
			nameOf: _
		})
	] }), at = Se === "journal" ? m("games.betrayal3.uiJournal") : Se === "objective" ? m("games.betrayal3.uiObjective") : `${m("games.betrayal3.uiDossier")} · ${_(we)}`;
	return /* @__PURE__ */ i(le, {
		adaptive: !0,
		scroll: !1,
		className: "b3-game",
		banner: N,
		actionsHeight: "b3-actions-slot",
		actions: P,
		children: /* @__PURE__ */ a("div", {
			className: "b3-body",
			children: [
				/* @__PURE__ */ a("div", {
					className: `b3-main${e.phase === "characters" ? " b3-main-characters" : ""}`,
					children: [/* @__PURE__ */ a("section", {
						className: "b3-map-area",
						ref: Oe,
						children: [/* @__PURE__ */ a("div", {
							className: "b3-map-tools",
							children: [/* @__PURE__ */ i("span", {
								className: "b3-map-floor",
								children: e.phase === "characters" ? m("games.betrayal3.uiParty") : m(po[_e])
							}), e.phase !== "characters" && /* @__PURE__ */ a(r, { children: [
								/* @__PURE__ */ i("button", {
									className: "b3-icon b3-zoom",
									onClick: () => y(-1),
									"aria-label": m("games.betrayal3.uiZoomOut"),
									children: /* @__PURE__ */ i(ne, { size: 16 })
								}),
								/* @__PURE__ */ i("button", {
									className: "b3-icon b3-zoom",
									onClick: () => y(1),
									"aria-label": m("games.betrayal3.uiZoomIn"),
									children: /* @__PURE__ */ i(te, { size: 16 })
								}),
								/* @__PURE__ */ i("button", {
									className: "b3-button b3-fit",
									onClick: () => {
										ye((e) => e + 1), xe(null);
									},
									children: m("games.betrayal3.uiFit")
								})
							] })]
						}), e.phase === "characters" ? /* @__PURE__ */ i("div", {
							className: "b3-character-selection",
							children: $e ? de.filter((e) => e.kind === "character").map((e) => /* @__PURE__ */ i(ao, {
								id: e.target,
								onClick: () => Ne(e)
							}, e.id)) : de.some((e) => e.kind === "player") ? de.filter((e) => e.kind === "player").map((t) => /* @__PURE__ */ a("button", {
								className: "b3-first-player",
								onClick: () => Ne(t),
								children: [/* @__PURE__ */ i(ao, {
									id: e.explorers.find((e) => e.rid === t.target).character,
									compact: !0
								}), /* @__PURE__ */ i("b", { children: _(t.target) })]
							}, t.id)) : /* @__PURE__ */ i("div", {
								className: "b3-waiting",
								children: nt
							})
						}) : /* @__PURE__ */ a(r, { children: [
							/* @__PURE__ */ i("div", {
								className: "b3-sheet-wrap",
								ref: je,
								children: /* @__PURE__ */ a(ae, {
									sheetW: He,
									sheetH: Ue,
									fitKey: `${_e}:${ve}:${S}:${Be}:${C}:${Ve}`,
									clampToSheet: !0,
									eligible: T,
									highlight: "off",
									onTapEligible: (e) => {
										if (e === "preview") {
											Ee((e) => ({
												...e,
												open: !0
											}));
											return;
										}
										let t = Je.find((t) => t.id === e);
										if (t) return Ne(t);
										let n = Ie.find((t) => t.id === e), r = Ke(n);
										r.length === 1 ? Ne(r[0]) : xe(e);
									},
									children: [
										Ie.map((t) => {
											let n = We(t);
											return /* @__PURE__ */ a("g", {
												transform: `translate(${n.x} ${n.y})`,
												children: [
													/* @__PURE__ */ i(io, {
														room: t,
														label: _(t.tile),
														selected: be === t.id
													}),
													Ke(t).length > 0 && /* @__PURE__ */ i(xo, {}),
													/* @__PURE__ */ i(Fo, {
														pub: e,
														room: t.id
													}),
													/* @__PURE__ */ i(ie, {
														name: `room:${t.id}`,
														r: {
															x: 0,
															y: 0,
															w: 176,
															h: 176
														}
													})
												]
											}, t.id);
										}),
										e.monsters.filter((e) => !e.dead && Ie.some((t) => t.id === v(e.room))).map((t) => {
											let n = Ie.find((e) => e.id === v(t.room)), r = We(n), a = Xa(e.monsters.filter((e) => !e.dead && e.room === t.room).findIndex((e) => e.id === t.id), !0);
											return /* @__PURE__ */ i(Io, {
												monster: t,
												x: r.x + a.x,
												y: r.y + a.y,
												name: _(t.id)
											}, t.id);
										}),
										E.map(({ c: e, rect: t }) => /* @__PURE__ */ a("g", {
											transform: `translate(${t.x} ${t.y})`,
											children: [
												/* @__PURE__ */ i("rect", {
													width: "44",
													height: "44",
													rx: "4",
													fill: "#d6bf7f"
												}),
												/* @__PURE__ */ i("path", {
													d: "M10 22H34M22 10V34",
													stroke: "#17261d",
													strokeWidth: "4"
												}),
												/* @__PURE__ */ i(xo, {
													x: 1,
													y: 1,
													w: 42,
													h: 42
												})
											]
										}, e.id)),
										b && /* @__PURE__ */ a("g", {
											transform: `translate(${We(b).x} ${We(b).y})`,
											children: [
												/* @__PURE__ */ i(io, {
													room: {
														id: b.tile,
														tile: b.tile,
														floor: _e,
														x: b.x,
														y: b.y,
														rotation: h.rotation
													},
													label: _(b.tile)
												}),
												/* @__PURE__ */ i(xo, {}),
												/* @__PURE__ */ i("g", { ref: Ae })
											]
										}),
										/* @__PURE__ */ i("g", { ref: ke })
									]
								})
							}),
							/* @__PURE__ */ i(wo, {
								probeRef: ke,
								children: M.map((e) => /* @__PURE__ */ i(Eo, {
									explorer: e.explorer,
									x: e.x,
									y: e.y,
									name: e.name,
									avatar: e.avatar,
									active: e.active,
									critical: e.critical
								}, e.explorer.rid))
							}),
							b && Le.length > 0 && /* @__PURE__ */ i(To, {
								areaRef: je,
								probeRef: Ae,
								open: h.open,
								rotation: h.rotation,
								canRotate: Le.length > 1,
								onRotate: () => Ee((e) => ({
									...e,
									rotation: Re[(Re.indexOf(e.rotation) + 1) % Re.length]
								})),
								onConfirm: () => {
									let e = Le.find((e) => (e.value ?? 0) === h.rotation) ?? Le[0];
									e && Ne(e);
								},
								onCancel: () => Ee((e) => ({
									...e,
									open: !1
								}))
							}),
							!x.length && /* @__PURE__ */ i("div", {
								className: "b3-map-empty",
								children: m("games.betrayal3.uiUnexplored")
							}),
							/* @__PURE__ */ i(Po, { pub: e }),
							Xe && /* @__PURE__ */ a("section", {
								className: "b3-context",
								children: [/* @__PURE__ */ a("div", {
									className: "b3-panel-title",
									children: [/* @__PURE__ */ i("b", { children: _(Xe.tile) }), /* @__PURE__ */ i("button", {
										className: "b3-icon",
										onClick: () => xe(null),
										"aria-label": m("games.betrayal3.uiClose"),
										children: /* @__PURE__ */ i(d, { size: 17 })
									})]
								}), /* @__PURE__ */ a("div", {
									className: "b3-context-choices",
									children: [
										Ze.map((e) => /* @__PURE__ */ i("button", {
											className: "b3-button",
											onClick: () => Ne(e),
											children: /* @__PURE__ */ i(bo, {
												choice: e,
												nameOf: _
											})
										}, e.id)),
										uo[Xe.tile] && /* @__PURE__ */ i("p", {
											className: "b3-room-detail",
											children: m(uo[Xe.tile])
										}),
										e.tokens.filter((e) => e.room && v(e.room) === Xe.id).map((e) => /* @__PURE__ */ a("p", { children: [
											_(e.id),
											e.trait && ` · ${_(e.trait)}`,
											e.identity && ` · ${_(e.identity)}`
										] }, e.id)),
										e.monsters.filter((e) => !e.dead && v(e.room) === Xe.id).map((e) => /* @__PURE__ */ a("p", { children: [
											_(e.id),
											" · ",
											w.map((t) => `${_(t)} ${e.traits[t]}`).join(" · "),
											e.identity && ` · ${_(e.identity)}`,
											e.stunned && ` · ${m("games.betrayal3.uiStunned")}`
										] }, e.id))
									]
								})]
							}),
							e.roll && /* @__PURE__ */ a("div", {
								className: "b3-roll",
								children: [
									/* @__PURE__ */ a("span", { children: [_(e.roll.actor), e.roll.trait && ` · ${_(e.roll.trait)}`] }),
									/* @__PURE__ */ i(oo, { dice: e.roll.dice }),
									/* @__PURE__ */ i("b", { children: m("games.betrayal3.uiResult", { n: e.roll.dice.reduce((e, t) => e + t, 0) + e.roll.bonus }) })
								]
							}, e.journal.length)
						] })]
					}), e.phase !== "characters" && /* @__PURE__ */ a("aside", {
						className: "b3-side",
						children: [/* @__PURE__ */ i(Do, {
							pub: e,
							floor: _e,
							targetRooms: j,
							members: n,
							nameOf: _,
							onPick: (e) => {
								ge({
									key: me,
									floor: e
								}), xe(null);
							}
						}), /* @__PURE__ */ i(ko, {
							pub: e,
							members: n,
							nameOf: _,
							onPick: Fe
						})]
					})]
				}),
				Se && /* @__PURE__ */ i("div", {
					className: "b3-modal-shade",
					children: /* @__PURE__ */ a("section", {
						className: "b3-modal",
						role: "dialog",
						"aria-modal": "true",
						"aria-label": at,
						children: [/* @__PURE__ */ a("div", {
							className: "b3-panel-title",
							children: [/* @__PURE__ */ i("h2", { children: at }), /* @__PURE__ */ i("button", {
								className: "b3-icon",
								onClick: () => Ce(null),
								"aria-label": m("games.betrayal3.uiClose"),
								children: /* @__PURE__ */ i(d, { size: 20 })
							})]
						}), /* @__PURE__ */ i("div", {
							className: "b3-modal-content",
							ref: g,
							children: Se === "objective" ? I : Se === "journal" ? it : De && /* @__PURE__ */ i("div", {
								className: "b3-dossier",
								children: /* @__PURE__ */ i(jo, {
									pub: e,
									priv: t,
									inspected: De,
									myRid: u,
									team: et,
									nameOf: _,
									traitChoices: Qe,
									cardChoices: O,
									execute: Ne
								})
							})
						})]
					})
				}),
				A && /* @__PURE__ */ i("div", {
					className: "b3-reveal-shade",
					children: /* @__PURE__ */ a("section", {
						className: "b3-reveal",
						role: "dialog",
						"aria-modal": "true",
						"aria-label": m(_o[A.kind]),
						children: [
							/* @__PURE__ */ i("span", {
								className: "b3-reveal-kind",
								children: m(_o[A.kind])
							}),
							/* @__PURE__ */ i("h2", { children: _(A.id) }),
							/* @__PURE__ */ i("p", {
								className: "b3-reveal-actor",
								children: m("games.betrayal3.uiRevealDrawn", { name: _(A.actor) })
							}),
							fo[A.id] && /* @__PURE__ */ i("div", {
								className: "b3-reveal-text",
								children: /* @__PURE__ */ i(Qa, { text: m(fo[A.id]) })
							}),
							/* @__PURE__ */ i("ul", {
								className: "b3-reveal-acks",
								children: A.required.map((t) => {
									let r = A.acks.includes(t), o = e.explorers.find((e) => e.rid === t);
									return /* @__PURE__ */ a("li", {
										className: r ? "b3-ack-on" : "",
										children: [
											/* @__PURE__ */ i("span", {
												className: "b3-ack-avatar",
												style: { "--b3-character": o ? to[Me(o.character).group] : "#8a8a7a" },
												children: /* @__PURE__ */ i("img", {
													src: yo(n, t),
													alt: ""
												})
											}),
											/* @__PURE__ */ i("span", { children: _(t) }),
											/* @__PURE__ */ i("b", {
												className: "b3-ack-mark",
												"aria-hidden": !0,
												children: r ? "✓" : "…"
											})
										]
									}, t);
								})
							}),
							/* @__PURE__ */ i("p", {
								className: "b3-reveal-count",
								children: m("games.betrayal3.uiRevealConfirmed", {
									n: A.required.filter((e) => A.acks.includes(e)).length,
									m: A.required.length
								})
							}),
							t?.canAck ? /* @__PURE__ */ i("button", {
								className: "b3-button b3-reveal-ack",
								onClick: () => ee({ type: "ack" }),
								children: m("games.betrayal3.uiRevealAck")
							}) : /* @__PURE__ */ i("p", {
								className: "b3-reveal-wait",
								children: m("games.betrayal3.uiRevealWait")
							})
						]
					})
				})
			]
		})
	});
}
function wo({ probeRef: e, children: t }) {
	let n = s(null);
	return o(() => {
		let t = 0, r = () => {
			let i = n.current, a = e.current, o = i && a ? a.getScreenCTM() : null;
			if (i && o) {
				let e = i.getBoundingClientRect(), t = Math.min(1.5, Math.max(1, o.a)), n = [];
				for (let r of i.querySelectorAll("[data-pawn]")) {
					let i = r.offsetWidth * t, a = r.offsetHeight * t, s = o.a * Number(r.dataset.x) + o.e - e.left, c = o.d * Number(r.dataset.y) + o.f - e.top, l = s - i / 2, u = c - a / 2;
					for (let e = 0; e < 12; e++) {
						let e = n.find((e) => l < e.x + e.w + 4 && l + i + 4 > e.x && u < e.y + e.h + 4 && u + a + 4 > e.y);
						if (!e) break;
						u = e.y + e.h + 4;
					}
					l = Math.min(Math.max(4, l), Math.max(4, e.width - i - 4)), u = Math.min(Math.max(4, u), Math.max(4, e.height - a - 4));
					let d = s > -i && s < e.width + i && c > -a && c < e.height + a;
					n.push({
						x: l,
						y: u,
						w: i,
						h: a
					}), r.style.opacity = d ? "" : "0", r.style.transform = `translate3d(${l}px, ${u}px, 0) scale(${t})`;
				}
			}
			t = requestAnimationFrame(r);
		};
		return t = requestAnimationFrame(r), () => cancelAnimationFrame(t);
	}, [e]), /* @__PURE__ */ i("div", {
		ref: n,
		className: "b3-pawn-layer",
		"aria-hidden": !0,
		children: t
	});
}
function To({ areaRef: e, probeRef: t, open: n, rotation: r, canRotate: c, onRotate: f, onConfirm: p, onCancel: te }) {
	let ne = l(), re = s(null);
	return o(() => {
		let n = 0, r = () => {
			let i = re.current, a = t.current, o = e.current;
			if (i && a && o) {
				let e = a.getScreenCTM();
				if (e) {
					let t = o.getBoundingClientRect(), n = i.offsetWidth, r = i.offsetHeight, a = e.e - t.left, s = e.f - t.top, c = 176 * e.a, l = 176 * e.d, u = [
						{
							x: a + c / 2 - n / 2,
							y: s + l + 10
						},
						{
							x: a + c / 2 - n / 2,
							y: s - r - 10
						},
						{
							x: a + c + 10,
							y: s + l / 2 - r / 2
						},
						{
							x: a - n - 10,
							y: s + l / 2 - r / 2
						}
					], d = u.find((e) => e.x >= 4 && e.y >= 44 && e.x + n <= t.width - 4 && e.y + r <= t.height - 4) ?? u[0], f = Math.min(Math.max(d.x, 4), Math.max(4, t.width - n - 4)), p = Math.min(Math.max(d.y, 4), Math.max(4, t.height - r - 4));
					i.style.transform = `translate3d(${f}px, ${p}px, 0)`, i.style.visibility = "visible";
				}
			}
			n = requestAnimationFrame(r);
		};
		return n = requestAnimationFrame(r), () => cancelAnimationFrame(n);
	}, [e, t]), n ? /* @__PURE__ */ a("div", {
		ref: re,
		className: "b3-placement-tools",
		role: "group",
		"aria-label": ne("games.betrayal3.uiPlaceTools"),
		children: [
			c && /* @__PURE__ */ a("button", {
				className: "b3-button b3-placement-rotate",
				onClick: f,
				children: [/* @__PURE__ */ i(ee, { size: 16 }), ne("games.betrayal3.uiRotation", { n: r * 90 })]
			}),
			/* @__PURE__ */ a("button", {
				className: "b3-button b3-placement-confirm",
				onClick: p,
				children: [/* @__PURE__ */ i(u, { size: 16 }), ne("games.betrayal3.uiPlaceConfirm")]
			}),
			/* @__PURE__ */ i("button", {
				className: "b3-button b3-placement-cancel",
				onClick: te,
				"aria-label": ne("games.betrayal3.cancel"),
				children: /* @__PURE__ */ i(d, { size: 16 })
			})
		]
	}) : null;
}
function Eo({ explorer: e, x: t, y: n, name: r, avatar: o, active: s, critical: c }) {
	let { ref: l, hidden: u } = oe(`pawn:${e.rid}`), d = to[Me(e.character).group];
	return /* @__PURE__ */ a("div", {
		ref: l,
		"data-pawn": !0,
		"data-x": t,
		"data-y": n,
		className: `b3-pawn-chip${s ? " b3-pawn-chip-active" : ""}${e.dead ? " b3-pawn-chip-dead" : ""}${c ? " b3-pawn-chip-critical" : ""}`,
		style: {
			"--b3-character": d,
			visibility: u ? "hidden" : void 0
		},
		title: r,
		children: [/* @__PURE__ */ i("span", {
			className: "b3-pawn-chip-face",
			children: e.dead ? "☠" : /* @__PURE__ */ i("img", {
				src: o,
				alt: "",
				draggable: !1
			})
		}), /* @__PURE__ */ i("span", {
			className: "b3-pawn-chip-name",
			children: r
		})]
	});
}
function Do({ pub: e, floor: t, targetRooms: n, members: r, nameOf: a, onPick: o }) {
	return /* @__PURE__ */ i("div", {
		className: "b3-floors",
		children: [
			"U",
			"G",
			"B"
		].map((s) => /* @__PURE__ */ i(Oo, {
			pub: e,
			floor: s,
			active: s === t,
			targetRooms: n,
			members: r,
			nameOf: a,
			onPick: () => o(s)
		}, s))
	});
}
function Oo({ pub: e, floor: t, active: n, targetRooms: r, members: o, nameOf: s, onPick: c }) {
	let u = l(), d = e.rooms.filter((e) => e.floor === t), f = e.discovery?.floor === t ? e.discovery : null, p = e.explorers.filter((e) => e.room && d.some((t) => t.id === v(e.room))), ee = [...d, ...f ? [{
		x: f.x,
		y: f.y
	}] : []], te = null;
	if (ee.length) {
		let n = Math.min(...ee.map((e) => e.x)) - .25, c = Math.min(...ee.map((e) => e.y)) - .25, l = Math.max(...ee.map((e) => e.x)) + 1.25, u = Math.max(...ee.map((e) => e.y)) + 1.25;
		te = /* @__PURE__ */ a("svg", {
			viewBox: `${n} ${c} ${l - n} ${u - c}`,
			preserveAspectRatio: "xMidYMid meet",
			children: [
				d.map((e) => /* @__PURE__ */ i("rect", {
					x: e.x + .05,
					y: e.y + .05,
					width: ".9",
					height: ".9",
					rx: ".08",
					fill: e.condition === "flooded" ? "#2d525b" : e.condition === "burning" ? "#6e3d2a" : e.condition ? "#3b3933" : "#3a4a37",
					stroke: "#9c8f6a",
					strokeWidth: ".03"
				}, e.id)),
				f && /* @__PURE__ */ i("rect", {
					x: f.x + .05,
					y: f.y + .05,
					width: ".9",
					height: ".9",
					rx: ".08",
					fill: "#55664a44",
					stroke: "#d4c07d",
					strokeWidth: ".04",
					strokeDasharray: ".12 .08"
				}),
				d.filter((e) => r.has(e.id)).map((e) => /* @__PURE__ */ i("rect", {
					x: e.x + .68,
					y: e.y + .12,
					width: ".2",
					height: ".2",
					transform: `rotate(45 ${e.x + .78} ${e.y + .22})`,
					fill: "#f0cf74"
				}, `target-${e.id}`)),
				p.map((n, r) => {
					let c = d.find((e) => e.id === v(n.room)), l = p.filter((e) => v(e.room) === c.id).findIndex((e) => e.rid === n.rid), u = c.x + .5 + (l % 3 - 1) * .3, f = c.y + .5 + (Math.floor(l / 3) - .5) * .28;
					return /* @__PURE__ */ a("g", {
						opacity: n.dead ? .4 : 1,
						children: [
							/* @__PURE__ */ i("title", { children: s(n.rid) }),
							/* @__PURE__ */ i("clipPath", {
								id: `b3-mini-${t}-${r}`,
								children: /* @__PURE__ */ i("circle", {
									cx: u,
									cy: f,
									r: ".15"
								})
							}),
							/* @__PURE__ */ i("circle", {
								cx: u,
								cy: f,
								r: ".17",
								fill: to[Me(n.character).group],
								stroke: n.rid === e.turn ? "#f4d578" : "#0f1914",
								strokeWidth: n.rid === e.turn ? .06 : .035
							}),
							/* @__PURE__ */ i("image", {
								href: yo(o, n.rid),
								x: u - .15,
								y: f - .15,
								width: ".3",
								height: ".3",
								clipPath: `url(#b3-mini-${t}-${r})`
							})
						]
					}, n.rid);
				})
			]
		});
	}
	return /* @__PURE__ */ a("button", {
		type: "button",
		className: `b3-floor-mini${n ? " b3-floor-mini-active" : ""}`,
		onClick: c,
		"aria-current": n ? "true" : void 0,
		"aria-label": `${u(po[t])} · ${d.length}`,
		children: [/* @__PURE__ */ a("span", {
			className: "b3-floor-mini-head",
			children: [/* @__PURE__ */ i("b", { children: u(po[t]) }), /* @__PURE__ */ i("small", { children: d.length })]
		}), te ?? /* @__PURE__ */ i("span", {
			className: "b3-floor-mini-empty",
			children: u("games.betrayal3.uiUnexplored")
		})]
	});
}
function ko({ pub: e, members: t, nameOf: n, onPick: r }) {
	return /* @__PURE__ */ i("div", {
		className: "b3-roster",
		children: e.explorers.map((a) => /* @__PURE__ */ i(Ao, {
			pub: e,
			explorer: a,
			members: t,
			nameOf: n,
			onPick: () => r(a.rid)
		}, a.rid))
	});
}
function Ao({ pub: e, explorer: t, members: n, nameOf: r, onPick: o }) {
	let s = l(), { ref: c } = oe(`seat:${t.rid}`), u = t.room ? e.rooms.find((e) => e.id === v(t.room)) : void 0, d = e.haunt ? t.team : "unknown", f = t.statuses.length > 0 || d !== "unknown";
	return /* @__PURE__ */ a("button", {
		ref: c,
		className: `b3-roster-row${t.rid === e.turn ? " b3-roster-active" : ""}${t.dead ? " b3-roster-dead" : ""}`,
		style: { "--b3-character": to[Me(t.character).group] },
		onClick: o,
		children: [
			/* @__PURE__ */ a("span", {
				className: "b3-roster-face",
				children: [/* @__PURE__ */ i("img", {
					src: yo(n, t.rid),
					alt: ""
				}), /* @__PURE__ */ i("i", { "aria-hidden": !0 })]
			}),
			/* @__PURE__ */ a("span", {
				className: "b3-roster-main",
				children: [
					/* @__PURE__ */ i("b", { children: r(t.rid) }),
					/* @__PURE__ */ a("small", { children: [
						s($a[t.character]),
						" · ",
						t.dead ? s("games.betrayal3.uiDead") : u ? `${s(po[u.floor])} · ${r(u.tile)}` : s("games.betrayal3.uiNoRoom")
					] }),
					f && /* @__PURE__ */ a("span", {
						className: "b3-roster-tags",
						children: [t.statuses.map((e) => /* @__PURE__ */ i("i", { children: s($a[e] ?? $a.hiddenFromWerewolf) }, e)), d !== "unknown" && /* @__PURE__ */ i("i", {
							className: `b3-roster-team b3-roster-team-${d}`,
							children: s(mo[d] ?? mo.unknown)
						})]
					})
				]
			}),
			/* @__PURE__ */ i("span", {
				className: "b3-roster-traits",
				children: w.map((e) => /* @__PURE__ */ a("span", {
					className: t.traits[e] < 0 ? "b3-rt-dead" : t.traits[e] === 0 ? "b3-rt-critical" : void 0,
					title: r(e),
					children: [/* @__PURE__ */ i("small", { children: s(go[e]) }), /* @__PURE__ */ i("b", { children: t.traits[e] < 0 ? "☠" : t.values[e] })]
				}, e))
			})
		]
	});
}
function jo({ pub: e, priv: t, inspected: n, myRid: o, team: s, nameOf: c, traitChoices: u, cardChoices: d, execute: f }) {
	let p = l(), ee = n.rid === o, te = ee && Array.isArray(t?.secret.cards) ? t.secret.cards : n.cards, ne = e.haunt ? lo[e.haunt.id]?.[s === "traitor" ? "traitor" : "hero"] : void 0, re = [.../* @__PURE__ */ new Set([...te, ...ee ? d.map((e) => e.target ?? "").filter(Boolean) : []])];
	return /* @__PURE__ */ a(r, { children: [
		/* @__PURE__ */ i(ao, {
			id: n.character,
			compact: !0
		}),
		/* @__PURE__ */ a("h3", { children: [
			c(n.rid),
			" · ",
			p(mo[ee ? s : n.team] ?? mo.unknown)
		] }),
		/* @__PURE__ */ i("div", {
			className: "b3-tracks",
			children: w.map((e) => /* @__PURE__ */ a("div", {
				className: "b3-track",
				children: [
					/* @__PURE__ */ a("span", { children: [
						c(e),
						n.traits[e] === 0 && ` · ${p("games.betrayal3.uiCritical")}`,
						" ",
						/* @__PURE__ */ i("b", { children: n.traits[e] < 0 ? "☠" : n.values[e] })
					] }),
					/* @__PURE__ */ i("div", { children: Me(n.character).tracks[e].map((t, r) => /* @__PURE__ */ i("span", {
						className: `${r === n.traits[e] ? "b3-track-current" : ""}${r === Me(n.character).start[e] ? " b3-track-start" : ""}`,
						children: /* @__PURE__ */ i("small", { children: t })
					}, r)) }),
					ee && u.filter((t) => t.target?.split(":").at(-1) === e).map((e) => /* @__PURE__ */ i("button", {
						className: "b3-button",
						onClick: () => f(e),
						children: /* @__PURE__ */ i(bo, {
							choice: e,
							nameOf: c
						})
					}, e.id))
				]
			}, e))
		}),
		/* @__PURE__ */ i("h3", { children: p("games.betrayal3.uiInventory") }),
		/* @__PURE__ */ i("div", {
			className: "b3-inventory",
			children: re.map((e) => /* @__PURE__ */ a("article", {
				className: "b3-item",
				children: [
					/* @__PURE__ */ i(ro, { kind: h.includes(e) || e === "hiddenOmen" ? "omen" : "item" }),
					/* @__PURE__ */ i("b", { children: c(e) }),
					uo[e] && /* @__PURE__ */ i("p", {
						className: "b3-item-detail",
						children: p(uo[e])
					}),
					ee && d.filter((t) => t.target === e).map((e) => /* @__PURE__ */ i("button", {
						className: "b3-button",
						onClick: () => f(e),
						children: /* @__PURE__ */ i(bo, {
							choice: e,
							nameOf: c
						})
					}, e.id))
				]
			}, e))
		}),
		!te.length && /* @__PURE__ */ i("p", { children: p("games.betrayal3.uiNoCards") }),
		e.tokens.some((e) => e.holder === n.rid) && /* @__PURE__ */ a(r, { children: [/* @__PURE__ */ i("h3", { children: p("games.betrayal3.uiOwnedTokens") }), e.tokens.filter((e) => e.holder === n.rid).map((e) => /* @__PURE__ */ a("div", {
			className: "b3-token-line",
			children: [
				c(e.id),
				e.trait && ` · ${c(e.trait)}`,
				e.identity && ` · ${c(e.identity)}`,
				ee && t?.secret[`token.${e.id}`] !== void 0 && ` · ${t.secret[`token.${e.id}`]}`
			]
		}, e.id))] }),
		ee && /* @__PURE__ */ i(No, {
			pub: e,
			priv: t,
			myRid: o,
			nameOf: c,
			omitOwnedTokens: !0
		}),
		e.haunt && /* @__PURE__ */ i(Mo, {
			pub: e,
			nameOf: c
		}),
		ne && /* @__PURE__ */ a(r, { children: [/* @__PURE__ */ i("h3", { children: p("games.betrayal3.uiObjective") }), /* @__PURE__ */ i("p", {
			className: "b3-objective-text",
			children: p(ne)
		})] })
	] });
}
function Mo({ pub: e, nameOf: t }) {
	let n = l(), r = {
		traitorWords: "games.betrayal3.counterTraitorWords",
		heroWords: "games.betrayal3.counterHeroWords",
		bloodSupply: "games.betrayal3.counterBloodSupply",
		runesRequired: "games.betrayal3.counterRunesRequired",
		heroScore: "games.betrayal3.counterHeroScore",
		spiritScore: "games.betrayal3.counterSpiritScore",
		scoreTarget: "games.betrayal3.counterScoreTarget",
		fireSupply: "games.betrayal3.counterFireSupply",
		dogFood: "games.betrayal3.counterDogFood",
		flamesRemaining: "games.betrayal3.counterFlamesRemaining",
		ornamentSupply: "games.betrayal3.counterOrnamentSupply",
		toyTarget: "games.betrayal3.counterToyTarget",
		banished: "games.betrayal3.counterBanished",
		foodRemaining: "games.betrayal3.counterFoodRemaining",
		ghostReserve: "games.betrayal3.counterGhostReserve",
		messagesRemaining: "games.betrayal3.counterMessagesRemaining"
	};
	return /* @__PURE__ */ i("dl", {
		className: "b3-counters",
		children: Object.entries(e.haunt?.counters ?? {}).filter(([e]) => r[e] || e.startsWith("reconciled.")).map(([e, o]) => /* @__PURE__ */ a("div", { children: [/* @__PURE__ */ i("dt", { children: r[e] ? n(r[e]) : `${t(e.slice(11))} · ${n("games.betrayal3.counterReconciled")}` }), /* @__PURE__ */ i("dd", { children: o })] }, e))
	});
}
function No({ pub: e, priv: t, myRid: n, nameOf: o, omitOwnedTokens: s = !1 }) {
	let c = l(), u = {
		number: "games.betrayal3.uiHiddenNumber",
		sickness: "games.betrayal3.uiSecretSickness",
		mirrorTrait: "games.betrayal3.uiSecretTrait",
		mirrorOmen: "games.betrayal3.uiSecretOmen",
		mirrorRoom: "games.betrayal3.uiSecretRoom",
		killTarget: "games.betrayal3.uiSecretTarget",
		syllables: "games.betrayal3.uiSecretSyllables",
		currentWeakness: "games.betrayal3.uiSecretWeakness",
		messages: "games.betrayal3.uiSecretMessages",
		remainsOrder: "games.betrayal3.uiSecretRemains"
	}, d = e.tokens.some((e) => e.kind === "hunterNumber" && e.holder === n), f = e.tokens.filter((e) => (!s || e.holder !== n) && (t?.secret[`token.${e.id}`] !== void 0 || e.kind === "hunterNumber" && e.holder === n));
	return /* @__PURE__ */ a(r, { children: [
		Object.keys(u).filter((e) => t?.secret[e] !== void 0 && !(e === "number" && d)).map((e) => /* @__PURE__ */ a("p", {
			className: "b3-secret",
			children: [
				/* @__PURE__ */ i("b", { children: c(u[e]) }),
				" · ",
				(Array.isArray(t.secret[e]) ? t.secret[e] : [t.secret[e]]).map((e) => typeof e == "string" ? o(e) : String(e)).join(" · ")
			]
		}, e)),
		f.map((e) => /* @__PURE__ */ a("p", {
			className: "b3-secret",
			children: [
				/* @__PURE__ */ i("b", { children: o(e.kind) }),
				" · ",
				String(t?.secret[`token.${e.id}`] ?? e.value)
			]
		}, e.id)),
		Object.entries(t?.secret ?? {}).filter(([e]) => e.startsWith("interrogated.")).map(([e, t]) => /* @__PURE__ */ a("p", {
			className: "b3-secret",
			children: [
				/* @__PURE__ */ i("b", { children: o(e.slice(e.indexOf(".") + 1)) }),
				" · ",
				String(t)
			]
		}, e))
	] });
}
function Po({ pub: e }) {
	let t = l(), { ref: n } = oe("deck");
	return /* @__PURE__ */ i("div", {
		className: "b3-decks",
		ref: n,
		children: [
			["tiles", "games.betrayal3.uiTileDeck"],
			["items", "games.betrayal3.uiItemDeck"],
			["omens", "games.betrayal3.uiOmenDeck"],
			[e.scenario === "comeHomeToEvil" ? "encounters" : "events", e.scenario === "comeHomeToEvil" ? "games.betrayal3.uiEncounterDeck" : "games.betrayal3.uiEventDeck"]
		].map(([n, r]) => /* @__PURE__ */ a("span", { children: [
			t(r),
			" ",
			/* @__PURE__ */ i("b", { children: e.decks[n] })
		] }, n))
	});
}
function Fo({ pub: e, room: t }) {
	let n = l(), r = e.tokens.filter((e) => e.room && v(e.room) === t).length, o = e.monsters.filter((e) => !e.dead && v(e.room) === t).length;
	return !r && !o ? null : /* @__PURE__ */ a("g", { children: [/* @__PURE__ */ i("rect", {
		x: "12",
		y: "17",
		width: "151",
		height: "25",
		rx: "3",
		fill: "#19271de8",
		stroke: "#b7a574"
	}), /* @__PURE__ */ i("foreignObject", {
		x: "15",
		y: "21",
		width: "145",
		height: "20",
		children: /* @__PURE__ */ i("span", {
			className: "b3-room-count",
			children: n("games.betrayal3.uiContentsCount", {
				n: r,
				m: o
			})
		})
	})] });
}
function Io({ monster: e, x: t, y: n, name: r }) {
	let { ref: a, hidden: o } = oe(`pawn:${e.id}`);
	return /* @__PURE__ */ i("foreignObject", {
		x: t,
		y: n,
		width: "20",
		height: "20",
		children: /* @__PURE__ */ i("div", {
			ref: a,
			title: r,
			className: "b3-map-monster",
			style: { visibility: o ? "hidden" : void 0 },
			children: /* @__PURE__ */ i(no, {
				number: e.number ?? 1,
				stunned: e.stunned
			})
		})
	});
}
//#endregion
//#region src/game/bot.ts
var Lo = {
	objective: 80,
	combat: 25,
	explore: 28,
	repeat: 6,
	health: 12
}, Ro = {
	1: ["library", "ritualRoom"],
	2: [
		"panicRoom",
		"furnaceRoom",
		"ballroom",
		"operatingTheatre",
		"junkRoom"
	],
	3: [
		"laboratory",
		"operatingTheatre",
		"observatory",
		"kitchen"
	],
	4: ["entranceHall"],
	5: ["chapel"],
	6: [],
	7: [],
	8: [
		"bloodyRoom",
		"charredRoom",
		"collapsedRoom",
		"junkRoom",
		"catacombs"
	],
	9: ["@item"],
	10: ["@omen"],
	11: [
		"kitchen",
		"larder",
		"diningRoom"
	],
	12: [],
	13: [
		"library",
		"chapel",
		"ritualRoom"
	],
	14: [],
	15: ["@item", "@omen"],
	16: ["graveyard"],
	17: [
		"tower",
		"gallery",
		"observatory"
	],
	18: ["vault"],
	19: ["entranceHall"],
	20: [],
	21: [
		"library",
		"furnaceRoom",
		"ritualRoom",
		"kitchen",
		"laboratory",
		"charredRoom"
	],
	22: ["entranceHall", "graveyard"],
	23: ["@omen"],
	24: ["chapel"],
	25: ["armory", "ritualRoom"],
	26: [
		"ritualRoom",
		"gallery",
		"statuaryCorridor"
	],
	27: [
		"library",
		"observatory",
		"tower",
		"laboratory",
		"specimenRoom"
	],
	28: ["@item"],
	29: [
		"library",
		"ritualRoom",
		"@item"
	],
	30: [],
	31: ["entranceHall"],
	32: [],
	33: [],
	34: ["@omen"],
	35: [
		"kitchen",
		"diningRoom",
		"undergroundLake",
		"larder",
		"laboratory",
		"gymnasium"
	],
	36: [],
	37: [
		"entranceHall",
		"observatory",
		"gameRoom",
		"laboratory",
		"panicRoom"
	],
	38: ["@event"],
	39: [],
	40: ["tower", "ritualRoom"],
	41: [],
	42: [
		"library",
		"larder",
		"gymnasium",
		"chapel"
	],
	43: [],
	44: [],
	45: [
		"library",
		"ballroom",
		"gallery",
		"guestQuarters"
	],
	46: ["library"],
	47: [],
	48: ["panicRoom"],
	49: [
		"furnaceRoom",
		"ritualRoom",
		"kitchen",
		"laboratory",
		"charredRoom"
	],
	50: [],
	blood1: ["@item", "@omen"],
	blood2: ["@omen"],
	blood3: [],
	blood4: [],
	blood5: ["@omen"],
	yuletide1: [],
	yuletide2: ["soundproofedRoom"],
	yuletide3: [],
	yuletide4: ["kitchen", "larder"],
	yuletide5: ["@item", "armory"],
	pennywise1: ["@item"],
	pennywise2: ["entranceHall"],
	pennywise3: [
		"ritualRoom",
		"library",
		"specimenRoom",
		"gallery",
		"laboratory"
	],
	pennywise4: [],
	pennywise5: []
}, zo = {
	6: ["evidence"],
	10: ["treasure"],
	11: ["witchFood"],
	13: ["rune"],
	16: ["remains"],
	18: ["illusion"],
	19: ["tape"],
	20: ["syllable"],
	23: ["switch"],
	24: ["seelieFlame"],
	25: ["ingredient"],
	26: ["offering", "altar"],
	30: ["altar"],
	31: ["cursedItem"],
	32: ["cat"],
	34: ["christina"],
	35: ["nest"],
	36: ["ghost"],
	39: ["egg"],
	41: ["generator", "trap"],
	46: ["antidote"],
	47: ["portal"],
	48: ["head"],
	49: ["contract"],
	blood2: ["altar"],
	blood3: ["ball", "altar"],
	blood5: ["ritual"],
	yuletide2: ["bell"],
	yuletide3: ["tree"],
	yuletide4: ["coal"],
	yuletide5: ["presentNumber"],
	pennywise4: ["artifact", "altar"]
}, Bo = {
	sanity: [
		"operatingTheatre",
		"graveyard",
		"bloodyRoom"
	],
	might: [
		"larder",
		"specimenRoom",
		"diningRoom"
	],
	knowledge: [
		"furnaceRoom",
		"observatory",
		"library"
	],
	speed: [
		"undergroundLake",
		"conservatory",
		"kitchen"
	]
};
function Vo(e, t, n = !1) {
	let r = e.rooms.find((e) => e.id === v(t));
	if (!r) return [];
	let i = [];
	for (let n of Fe(r)) {
		if (r.tile === "windingTunnels" && !r.condition && Ie(r, n) !== t) continue;
		let [a, o] = Pe[n], s = e.rooms.find((e) => e.floor === r.floor && e.x === r.x + a && e.y === r.y + o);
		s && Fe(s).includes((n + 2) % 4) && i.push(Ie(s, (n + 2) % 4));
	}
	for (let [n, a] of [
		["groundStaircase", "upperLanding"],
		["hallway", "secretStaircase"],
		["graveyard", "undergroundCavern"],
		["oubliette", "trophyRoom"],
		["timeLostTree", "rootCellar"]
	]) if (!r.condition && (t === n || t === a)) {
		let r = e.rooms.find((e) => e.id === (t === n ? a : n));
		r && (!r.condition || e.haunt?.id === "44") && i.push(r.id);
	}
	t === "gallery" && !r.condition && i.push("ballroom"), t === "laundryChute" && !r.condition && i.push("basementLanding"), (n || e.haunt?.id === "44") && (t === "basementLanding" && i.push("groundStaircase"), t === "groundStaircase" && i.push("basementLanding")), r.tile === "windingTunnels" && !r.condition && i.push(t.endsWith(":a") ? `${r.id}:b` : `${r.id}:a`);
	let a = e.tokens.filter((e) => e.kind === "secretPassage" && e.room);
	return a.some((e) => e.room === t) && i.push(...a.map((e) => e.room)), i;
}
function Ho(e, t, n) {
	let r = /* @__PURE__ */ new Map([[t, 0]]), i = [t];
	for (; i.length;) {
		let t = i.shift();
		for (let a of Vo(e, t, n)) r.has(a) || (r.set(a, r.get(t) + 1), i.push(a));
	}
	return r;
}
function Uo(e, t) {
	return [
		"ring",
		"holySymbol",
		"book",
		"dog",
		"armor",
		"skull"
	].includes(e) ? 7 : [
		"gun",
		"crossbow",
		"chainsaw",
		"dagger",
		"machete"
	].includes(e) ? t.haunt ? 8 : 6 : [
		"firstAidKit",
		"angelsFeather",
		"snowGlobe",
		"map"
	].includes(e) ? 8 : 4;
}
function Wo(e = Lo) {
	return (t, n) => {
		let r = t.public, i = t.private, a = i?.choices ?? [];
		if (i?.canAck) return { action: { type: "ack" } };
		if (!a.length) return null;
		if (n.difficulty === "weak") return { action: {
			type: "act",
			id: a[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % a.length].id
		} };
		if (a.every((e) => e.kind === "character")) return { action: {
			type: "act",
			id: [...a].sort((e, t) => {
				let n = (e) => {
					let t = Me(e);
					return w.reduce((e, n) => e + t.tracks[n][t.start[n]], 0);
				};
				return n(t.target) - n(e.target);
			})[0].id
		} };
		let o = r.explorers.find((e) => e.rid === n.rid), s = i.team, c = n.memory, l = c?.lastRoom === o.room ? c.path ?? [] : [...c?.path ?? [], o.room].slice(-12), u = Object.fromEntries([...new Set(l)].map((e) => [e, l.filter((t) => t === e).length])), d = (c?.decisions ?? 0) + 1, f = r.pending?.key ?? "", p = !!i?.actingPiece && i.actingPiece !== n.rid, ee = r.monsters.find((e) => e.id === i?.actingPiece), te = ee?.room ?? o.room, ne = r.explorers.filter((e) => e.rid !== n.rid && !e.dead && e.room && (s === "individual" || s === "traitor" ? e.team !== "traitor" : e.team === "traitor")), re = s === "traitor" || p ? ne.map((e) => e.room) : [...ne.map((e) => e.room), ...r.monsters.filter((e) => !e.dead && !e.stunned).map((e) => e.room)], ie = r.haunt?.id ?? "", ae = s === "traitor" || p ? [] : Ro[ie] ?? [];
		if (ie === "25" && s === "hero") {
			let e = r.tokens.filter((e) => e.kind === "ingredient");
			ae = e.length >= r.explorers.length - 2 ? ["armory", "ritualRoom"] : w.filter((t) => !e.some((e) => e.trait === t)).flatMap((e) => Bo[e]);
		}
		ie === "37" && !p && (ae = s === "traitor" ? r.tokens.some((e) => e.kind === "dna" && e.identity === o.character) ? ["@omen"] : [] : r.monsters.some((e) => !e.dead) ? [
			"observatory",
			"gameRoom",
			"laboratory",
			"panicRoom"
		] : ["entranceHall"]);
		let oe = r.rooms.filter((e) => ae.includes(e.tile) || ae.includes("@" + g(e.tile).symbol?.replace(/2$/, ""))).flatMap(b);
		for (let e of r.tokens) !p && s === "hero" && ie !== "25" && e.room && zo[ie]?.includes(e.kind) && oe.push(e.room);
		ie === "37" && s === "traitor" && !p && !ae.length && oe.push(...ne.filter((e) => r.tokens.some((t) => t.kind === "dna" && t.identity === e.character)).map((e) => e.room)), ie === "7" && typeof i?.secret.mirrorRoom == "string" && oe.push(i.secret.mirrorRoom), ie === "20" && Array.isArray(i?.secret.syllables) && oe.push(...i.secret.syllables.filter((e) => typeof e == "string"));
		let se = r.tokens.filter((e) => e.holder === n.rid);
		if (ie === "16" && se.some((e) => e.kind === "remains") && oe.unshift("graveyard"), ie === "48" && o.cards.includes("skull") && oe.unshift("panicRoom"), ie === "24" && se.some((e) => e.kind === "seelieFlame") && oe.unshift("chapel"), ie === "31" && o.cards.includes("holySymbol") && oe.unshift("entranceHall"), !p && s === "hero" && ie === "8" && (oe = oe.filter((e) => !r.tokens.some((t) => t.kind === "cleanedRoom" && t.room === e))), !p && s === "hero" && ie === "35") {
			let e = r.tokens.filter((e) => e.kind === "salt");
			(e.length + (r.haunt?.counters.saltSpent ?? 0) >= 5 || e.some((e) => e.holder === n.rid)) && (oe = r.tokens.filter((e) => e.kind === "slugNest" && e.room).map((e) => e.room));
		}
		if (!p && s === "hero" && ie === "46") {
			let e = r.tokens.filter((e) => e.kind === "antidote");
			oe = e.some((e) => e.holder === n.rid) ? r.monsters.filter((e) => e.kind === "giantHair" && !e.dead).map((e) => e.room) : e.filter((e) => e.room && (e.hidden || e.value === 1)).map((e) => e.room);
		}
		!p && s === "hero" && ie === "24" && (oe = r.tokens.some((e) => e.kind === "seelieFlame" && e.holder === n.rid) ? ["chapel"] : r.tokens.filter((e) => e.kind === "seelieFlame" && e.room && e.room !== "chapel").map((e) => e.room)), !p && s === "individual" && ie === "9" && (oe = ne.map((e) => e.room)), !p && s === "traitor" && ie === "30" && (oe = r.explorers.filter((e) => e.rid !== n.rid && e.cards.includes("ring")).map((e) => e.room)), !p && !r.pending && !a.some((e) => e.id.startsWith("haunt-") || e.id === "dropFlame") && (oe = oe.filter((e) => e !== te));
		let ce = r.rooms.flatMap((e) => Fe(e).some((t) => {
			let [n, i] = Pe[t];
			return !r.rooms.some((t) => t.floor === e.floor && t.x === e.x + n && t.y === e.y + i);
		}) ? b(e) : []), le = Ho(r, te, p), ue = oe.length ? oe : re;
		(!ue.some((e) => le.has(e)) || !p && s === "hero" && ie === "24" && !oe.length && (r.haunt?.counters.flamesRemaining ?? 0) > 0) && (ue = ce.filter((e) => le.has(e)));
		let m = (e) => {
			let t = Ho(r, e, p);
			return Math.min(99, ...ue.map((e) => t.get(e) ?? 99));
		}, de = m(te), fe = (t) => {
			let n = t.key.split(".").at(-1), i = t.target ?? "", a = w.includes(i) ? i : null, c = 0;
			if (t.kind === "character") {
				let e = Me(i);
				return w.reduce((t, n) => t + e.tracks[n][e.start[n]], 0);
			}
			if (t.kind === "rotation" && r.discovery) {
				let e = r.discovery, n = {
					id: e.tile,
					tile: e.tile,
					floor: e.floor,
					x: e.x,
					y: e.y,
					rotation: t.value ?? 0
				};
				return Fe(n).filter((e) => {
					let [t, i] = Pe[e];
					return !r.rooms.some((e) => e.floor === n.floor && e.x === n.x + t && e.y === n.y + i);
				}).length * 4;
			}
			if (n === "lowerTrait" && a) return o.traits[a] * e.health + (o.values[a] - Me(o.character).tracks[a][Math.max(0, o.traits[a] - 1)]) * -2;
			if (n === "raiseTrait" && a) return (7 - o.traits[a]) * e.health;
			if (n === "rollTrait" || n === "rollFlashlight" || n === "rollKnowledge" || n === "rollSanity") return (a ? o.values[a] : 0) + (n === "rollFlashlight" ? 2 : 0);
			if (f.endsWith("reviewRoll")) return t.id.startsWith("foot-") ? t.value === 0 ? 30 : -20 : t.id === "coin" ? o.traits.sanity > 1 && (r.roll?.dice.filter((e) => e === 0).length ?? 0) > 0 ? 12 : -20 : t.id === "doll" ? o.traits.sanity > 2 && (r.roll?.dice.reduce((e, t) => e + t, 0) ?? 0) < (r.roll?.dice.length ?? 0) - 1 ? 8 : -20 : t.id === "accept" ? 1 : -10;
			if (/feather/i.test(f) && t.value !== void 0) return t.value * 10;
			if (t.id === "end" || t.id === "finish" || t.id === "stop") return 0;
			if (t.id === "cancel") return f.endsWith("prepareTrade") ? 40 : -5;
			if (t.id.startsWith("trade-")) return -100;
			if (f.endsWith("prepareTrade")) return t.id === "cancel" ? 200 : -200;
			if (n === "dropFlame") return o.room === "chapel" ? e.objective * 2 : -100;
			if (n === "pickFlame" && o.room === "chapel") return -100;
			if (n === "spendSalt") return Number(t.params?.total ?? 0) >= 9 ? 100 - (t.value ?? 0) : -(t.value ?? 0);
			if (n === "discoverAntidote") {
				let e = r.tokens.find((e) => e.id === i);
				if (e && !e.hidden && e.value !== 1) return -100;
			}
			if (n === "searchShelves" && ie === "9" && (!r.decks.items || o.cards.length >= 4)) return -30;
			if (ie === "30" && s === "traitor" && t.id.startsWith("loot-") && i === "ring") return e.objective * 3;
			if (t.id === "propose") return 30;
			if (t.id === "decline") return -2;
			if (t.id === "accept") return 3;
			if (t.id === "book") return -10;
			if (t.id === "item-map") return de >= 99 ? e.objective : -5;
			if (t.id.startsWith("item-")) return [
				"mirror",
				"strangeMedicine",
				"wolfsbane",
				"unusualCake"
			].includes(i) ? w.reduce((e, t) => e + Math.max(0, Me(o.character).start[t] - o.traits[t]), 0) * e.health - 8 : -5;
			if (t.id.startsWith("aid-")) return e.health * 2;
			if (t.id.startsWith("attack-")) {
				let n = r.explorers.find((e) => e.rid === i), a = r.monsters.find((e) => e.id === i);
				if (n?.team === "unknown" && s === "hero") return -40;
				let c = String(t.params?.weapon ?? ""), l = c === "ring" ? "sanity" : ["gun", "crossbow"].includes(c) ? "speed" : "might", u = (ee?.traits[l] ?? o.values[l]) + (["dagger"].includes(c) ? 2 : +!!["crossbow", "chainsaw"].includes(c)) + +(c === "machete");
				return c === "dagger" && o.traits.speed === 0 ? -50 : e.combat + (u - (n?.values[l] ?? a?.traits[l] ?? 4)) * 4 + (a?.stunned ? -15 : 0);
			}
			if (t.id.startsWith("discover-")) return r.haunt && ue.length && de < 2 ? 2 : e.explore;
			if (/^(move-|key-)/.test(t.id)) {
				let t = m(i), n = r.monsters.filter((e) => !e.dead && !e.stunned && e.room === i).length;
				return c = ue.length ? (de - t) * 16 + 8 : e.explore / 2, ue.includes(te) && !r.pending && (c -= 25), ie === "37" && s === "traitor" && ae.length && t < de && (c += e.objective), c - Math.min(2, u[i] ?? 0) * e.repeat - (s === "hero" && !p ? n * 4 : 0);
			}
			return t.id.startsWith("haunt-") && (c += e.objective), a && (c += o.values[a] * 2), t.kind === "card" && (c += Uo(i, r) * (n === "buryCard" ? -1 : 1)), t.kind === "room" && (c += 20 - m(i) - (u[i] ?? 0) * .1), t.kind === "token" && (c += 15 + (r.tokens.find((e) => e.id === i)?.value ?? 0)), /^(keep|take|banish|destroy|escape|burn|rescue|close|return|place|clean|search|reveal|steal|heal|finish)/i.test(n) && (c += 20), t.id === "continue" && (c += 10), c;
		}, pe = a[0], me = -Infinity;
		for (let e of a) {
			let t = (e.id.length * 17 + d * 13 + e.id.charCodeAt(e.id.length - 1)) % 19 / 100, n = fe(e) + t;
			n > me && (pe = e, me = n);
		}
		return {
			action: {
				type: "act",
				id: pe.id
			},
			memory: {
				path: l,
				lastRoom: o.room,
				decisions: d
			}
		};
	};
}
var Go = Wo(), Ko = (e, t, n) => {
	if (e.type !== "act") return "";
	let r = t.private?.choices.find((t) => t.id === e.id);
	if (!r) return "";
	let i = n(r.key, r.params), a = r.target;
	return a && $a[a] ? `${i} · ${n($a[a])}` : i;
};
//#endregion
//#region src/game/fx.tsx
function qo(e, t = 30) {
	let n = t * 4 / 3;
	return {
		x: e.x + (e.w - t) / 2,
		y: e.y + (e.h - n) / 2,
		w: t,
		h: n
	};
}
function Jo({ id: e, kind: t = "item" }) {
	let n = l();
	return /* @__PURE__ */ a("div", {
		className: "b3-fx-card",
		children: [t !== "encounter" && /* @__PURE__ */ i(ro, { kind: t }), /* @__PURE__ */ i("b", { children: e && $a[e] ? n($a[e]) : n(t === "omen" ? "games.betrayal3.uiOmenDeck" : t === "event" ? "games.betrayal3.uiEventDeck" : t === "encounter" ? "games.betrayal3.uiEncounterDeck" : "games.betrayal3.uiItemDeck") })]
	});
}
function Yo({ textKey: e, n: t, id: n }) {
	let r = l();
	return /* @__PURE__ */ a("span", {
		className: "b3-fx-label",
		children: [n && $a[n] && `${r($a[n])} · `, r(e, { n: t })]
	});
}
function Xo({ id: e }) {
	let t = l();
	return /* @__PURE__ */ a("div", {
		className: "b3-haunt-reveal",
		children: [/* @__PURE__ */ i("span", { children: t("games.betrayal3.uiHaunt") }), /* @__PURE__ */ i("h2", { children: eo[e] ? t(eo[e]) : "" })]
	});
}
var Zo = { houseBeat(e, t) {
	let o = e.data, s = e.rid ? t.anchor(`seat:${e.rid}`) : null;
	if (o.key === "games.betrayal3.logMove") {
		let r = o.from ? t.anchor(`room:${o.from}`) : null, a = e.rid ? t.anchor(`pawn:${e.rid}`) : null;
		if (!r || !a) return null;
		let s = {
			x: r.x + r.w * o.fromX / 176,
			y: r.y + r.h * o.fromY / 176,
			w: r.w * o.size / 176,
			h: r.h * o.size / 176
		}, c = t.queued ? Math.min(150, Je.move) : Je.move;
		return {
			ms: c,
			hide: t.queued ? [] : e.rid ? [`pawn:${e.rid}`] : [],
			node: /* @__PURE__ */ i(de, {
				from: s,
				to: a,
				ms: c,
				children: o.monster ? /* @__PURE__ */ i(no, { number: o.number }) : /* @__PURE__ */ i("div", {
					className: "b3-fx-pawn",
					style: {
						background: to[o.color ?? "white"],
						width: "100%",
						height: "100%"
					},
					children: /* @__PURE__ */ i("img", {
						src: n[(t.member(e.rid ?? "")?.avatar ?? 0) % n.length],
						alt: "",
						draggable: !1,
						style: {
							width: "1.75em",
							height: "1.75em",
							maxWidth: "100%",
							maxHeight: "100%",
							display: "block",
							objectFit: "contain",
							pointerEvents: "none",
							borderRadius: "inherit"
						}
					})
				})
			})
		};
	}
	if (o.key === "games.betrayal3.logDraw") {
		let n = t.anchor("deck");
		if (!n || !s) return null;
		let r = e.secret?.id ?? o.id ?? void 0;
		return {
			ms: Je.draw,
			node: /* @__PURE__ */ i(de, {
				from: {
					x: n.x + n.w / 2 - 30,
					y: n.y,
					w: 60,
					h: 80
				},
				to: qo(s),
				ms: Je.draw,
				children: /* @__PURE__ */ i(Jo, {
					id: r,
					kind: o.cardKind
				})
			})
		};
	}
	if (o.key === "games.betrayal3.logTrade") {
		let e = o.target ? t.anchor(`seat:${o.target}`) : null;
		return !s || !e ? null : {
			ms: Je.draw,
			node: /* @__PURE__ */ i(de, {
				from: qo(s, 60),
				to: qo(e),
				ms: Je.draw,
				children: /* @__PURE__ */ i(Jo, {
					id: o.id ?? void 0,
					kind: o.cardKind
				})
			})
		};
	}
	return o.key === "games.betrayal3.logHaunt" && o.id ? {
		ms: Je.haunt,
		node: /* @__PURE__ */ a(r, { children: [/* @__PURE__ */ i(ue, {
			ms: Je.haunt,
			className: "b3-haunt-flash"
		}), /* @__PURE__ */ i(Xo, { id: o.id })] })
	} : s ? o.key === "games.betrayal3.logDeath" ? {
		ms: Je.resolve,
		node: /* @__PURE__ */ i(fe, {
			at: s,
			ms: Je.resolve
		})
	} : [
		"games.betrayal3.logDamage",
		"games.betrayal3.logGain",
		"games.betrayal3.logLose",
		"games.betrayal3.logHeal",
		"games.betrayal3.logUse"
	].includes(o.key) ? {
		ms: Je.resolve,
		node: /* @__PURE__ */ i(m, {
			at: s,
			ms: Je.resolve,
			children: /* @__PURE__ */ i(Yo, {
				textKey: o.key,
				n: o.n ?? 0,
				id: o.id
			})
		})
	} : null : null;
} };
//#endregion
//#region src/game/game-over.tsx
function Qo(e) {
	let t = l(), n = e.public, r = e.private, [o, s] = c(!0), [u, d] = c(null), f = n.haunt && lo[n.haunt.id], p = e.result.winner;
	return /* @__PURE__ */ a("div", {
		className: "b3-result-root",
		children: [
			/* @__PURE__ */ i(Co, {
				...e,
				send: () => void 0,
				pub: n,
				priv: r,
				readOnly: !0
			}),
			!o && /* @__PURE__ */ i("button", {
				className: "b3-button b3-show-report",
				onClick: () => s(!0),
				children: t("games.betrayal3.uiShowReport")
			}),
			o && /* @__PURE__ */ i("div", {
				className: "b3-result-shade",
				children: /* @__PURE__ */ a("section", {
					className: "b3-result",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": t("games.betrayal3.uiReport"),
					children: [
						/* @__PURE__ */ a("header", { children: [
							/* @__PURE__ */ i("span", {
								className: "b3-kicker",
								children: t("games.betrayal3.uiReport")
							}),
							/* @__PURE__ */ i("h1", { children: n.haunt ? t(eo[n.haunt.id]) : t("games.betrayal3.name") }),
							/* @__PURE__ */ a("p", { children: [t("games.betrayal3.uiTurn", { n: n.turnNumber }), n.haunt && ` · ${t("games.betrayal3.uiTrackValue", { n: n.haunt.track })}`] })
						] }),
						/* @__PURE__ */ a("div", {
							className: "b3-result-scroll",
							children: [
								!p.length && /* @__PURE__ */ i("h2", { children: t("games.betrayal3.uiNoWinners") }),
								n.ending === "weddingStalemate" && /* @__PURE__ */ i("p", { children: t("games.betrayal3.uiWeddingStalemate") }),
								/* @__PURE__ */ i("ul", {
									className: "b3-result-people",
									children: n.explorers.map((r) => /* @__PURE__ */ a("li", {
										"data-winner": p.includes(r.rid),
										children: [/* @__PURE__ */ i(ao, {
											id: r.character,
											compact: !0
										}), /* @__PURE__ */ a("div", { children: [
											/* @__PURE__ */ i("h2", { children: e.members.find((e) => e.rid === r.rid)?.name ?? r.rid }),
											/* @__PURE__ */ i("b", { children: t(p.includes(r.rid) ? "games.betrayal3.uiWon" : "games.betrayal3.uiLost") }),
											/* @__PURE__ */ a("p", { children: [t(r.dead ? "games.betrayal3.uiDead" : "games.betrayal3.uiLiving"), r.room && ` · ${$a[r.room.split(":")[0]] ? t($a[r.room.split(":")[0]]) : ""}`] }),
											n.haunt?.id === "10" && !r.dead && /* @__PURE__ */ i("p", { children: t("games.betrayal3.uiTreasureScore", { n: n.haunt.counters[`score.${r.rid}`] ?? 0 }) })
										] })]
									}, r.rid))
								}),
								f && /* @__PURE__ */ a("div", {
									className: "b3-result-objectives",
									children: [/* @__PURE__ */ a("article", { children: [/* @__PURE__ */ i("h3", { children: t("games.betrayal3.uiHero") }), /* @__PURE__ */ i("p", { children: t(f.hero) })] }), n.explorers.some((e) => e.team === "traitor") && /* @__PURE__ */ a("article", { children: [/* @__PURE__ */ i("h3", { children: t("games.betrayal3.uiTraitor") }), /* @__PURE__ */ i("p", { children: t(f.traitor) })] })]
								})
							]
						}),
						/* @__PURE__ */ a("footer", { children: [
							/* @__PURE__ */ i("button", {
								className: "b3-button",
								onClick: () => s(!1),
								children: t("games.betrayal3.uiReviewHouse")
							}),
							e.onPlayAgain && /* @__PURE__ */ i("button", {
								className: "b3-button",
								onClick: () => d("again"),
								children: t("session.result.playAgain")
							}),
							e.onBackToLobby && /* @__PURE__ */ i("button", {
								className: "b3-button",
								onClick: () => d("lobby"),
								children: t("session.result.backToLobby")
							}),
							!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ i("p", { children: t("session.result.waitHost") })
						] }),
						u && /* @__PURE__ */ a("div", {
							className: "b3-confirm",
							children: [
								/* @__PURE__ */ i("p", { children: t(u === "again" ? "games.betrayal3.uiConfirmAgain" : "games.betrayal3.uiConfirmLobby") }),
								/* @__PURE__ */ i("button", {
									className: "b3-button",
									onClick: () => {
										u === "again" ? e.onPlayAgain?.() : e.onBackToLobby?.();
									},
									children: t("games.betrayal3.uiConfirm")
								}),
								/* @__PURE__ */ i("button", {
									className: "b3-button",
									onClick: () => d(null),
									children: t("games.betrayal3.cancel")
								})
							]
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/game/options.tsx
function $o({ value: e, onChange: t }) {
	let n = l(), r = ve.catch({
		scenario: "paranormalInvestigators",
		stranger: "elf"
	}).parse(e);
	return /* @__PURE__ */ a("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ i(me, {
			title: n("games.betrayal3.uiScenario"),
			children: Oe.map((e) => /* @__PURE__ */ i(pe, {
				name: "betrayal3-scenario",
				value: e.id,
				checked: r.scenario === e.id,
				label: n($a[e.id]),
				hint: e.expansion === "base" ? n("games.betrayal3.uiPackBase") : e.expansion === "blood" ? n("games.betrayal3.uiPackBlood") : e.expansion === "yuletide" ? n("games.betrayal3.uiPackYuletide") : n("games.betrayal3.uiPackPennywise"),
				onChange: () => t({
					...r,
					scenario: e.id
				})
			}, e.id))
		}), r.scenario === "holidayHouse" && /* @__PURE__ */ i(me, {
			title: n("games.betrayal3.uiStranger"),
			children: ["elf", "jingleklaws"].map((e) => /* @__PURE__ */ i(pe, {
				name: "betrayal3-stranger",
				value: e,
				checked: r.stranger === e,
				label: n($a[e]),
				onChange: () => t({
					...r,
					stranger: e
				})
			}, e))
		})]
	});
}
//#endregion
//#region src/game/guide.tsx
function es() {
	let e = l();
	return /* @__PURE__ */ a("article", {
		className: "b3-guide",
		children: [
			/* @__PURE__ */ i("h2", { children: e("games.betrayal3.guideSymbols") }),
			/* @__PURE__ */ i("div", {
				className: "b3-guide-symbols",
				children: [
					"item",
					"omen",
					"event"
				].map((t) => /* @__PURE__ */ a("div", { children: [/* @__PURE__ */ i(ro, { kind: t }), /* @__PURE__ */ i("p", { children: e(t === "item" ? "games.betrayal3.guideItem" : t === "omen" ? "games.betrayal3.guideOmen" : "games.betrayal3.guideEvent") })] }, t))
			}),
			/* @__PURE__ */ i("h2", { children: e("games.betrayal3.guideComponents") }),
			Object.entries(uo).map(([t, n]) => /* @__PURE__ */ a("details", { children: [/* @__PURE__ */ a("summary", { children: [e($a[t]), Ce.some((e) => e.id === t) ? ` · ${e("games.betrayal3.guideRoom")}` : ""] }), /* @__PURE__ */ i("p", { children: e(n) })] }, t))
		]
	});
}
//#endregion
//#region src/index.tsx
var ts = {
	definition: Za,
	View: So,
	bot: Go,
	describe: Ko,
	fx: Zo,
	OverView: Qo,
	Options: $o,
	Guide: es,
	locales: {
		zh: {
			uiWeddingStalemate: "英雄已全部死亡，叛徒被困在祭坛，无法取回远处的戒指。双方均无法完成目标，本局无人获胜。",
			name: "山中小屋：第三版",
			desc: "探索宅邸，直到作祟揭开每个人的命运",
			chooseDamageType: "选择这次伤害的种类",
			keepDamageType: "承受原种类伤害",
			useBrooch: "用胸针改为一般伤害",
			allocateDamage: "分配剩余 {{n}} 点伤害",
			lowerTrait: "降低此属性 1 格",
			raiseTrait: "提升此属性 1 格",
			chooseRoll: "选择检定方式",
			rollTrait: "进行检定",
			rollFlashlight: "使用手电筒多掷 2 颗骰子",
			useFeather: "埋掉天使之羽并指定结果",
			acceptRoll: "接受结果",
			rerollDie: "用兔脚重掷此骰",
			useLuckyCoin: "用幸运硬币重掷所有空白骰",
			useCreepyDoll: "用诡异人偶重掷全部骰子",
			reviewRoll: "检定结果：{{n}}",
			featherResult: "使用此结果",
			chooseFeatherResult: "选择 0 至 8 作为基础结果",
			cancel: "取消",
			accept: "同意",
			decline: "放弃",
			eventDecision: "选择是否执行此事件的可选效果",
			acceptEvent: "执行可选效果",
			declineEvent: "放弃可选效果",
			chooseTraitRoll: "选择检定属性",
			chooseJonah: "埋掉一件非武器物品，或承受伤害",
			buryCard: "埋掉此牌",
			takeMentalDie: "承受一骰精神伤害",
			chooseGhost: "选择交出物品或进行神志检定",
			chooseGain: "选择要提升的属性",
			chooseTokenRoom: "选择标记放置的房间",
			chooseRoom: "选择房间",
			placeToken: "放置标记",
			moveTo: "移动到此房间",
			useItem: "使用此物品",
			healExplorer: "为此探险者治疗",
			useBook: "失去 1 神志，下次非攻击检定可改用知识",
			useMask: "将同房其他角色移到相邻房间",
			tradeWithDog: "使用爱犬与此探险者交易",
			tradeWith: "与此探险者交易",
			removeFromOffer: "从交易中移除此牌",
			giveCard: "将此牌交给对方",
			requestCard: "向对方索取此牌",
			proposeTrade: "向对方提出交易",
			prepareTrade: "选择交出的牌和索取的牌",
			acceptTrade: "是否同意这项交易？",
			useNecklace: "可用牙齿项链提升一项危急属性",
			chooseMaskRoom: "选择被移动角色的目的房间",
			throwDynamite: "向此房间投掷炸药",
			attackWith: "使用武器攻击此角色",
			attackUnarmed: "徒手攻击此角色",
			moveThroughWall: "使用万能钥匙穿墙",
			discoverDirection: "从此门探索",
			chooseDiscoveredTile: "是否保留发现的房间？",
			keepTile: "保留此房间",
			buryTile: "埋掉此房间并重新发现",
			chooseRotation: "选择新房间的朝向",
			rotateTile: "以此朝向放置",
			placeRoomAt: "在此门外放置房间",
			placeRequiredRoom: "放置指定房间",
			chooseEventDraw: "选择是否抽取事件牌",
			drawEvent: "抽取事件牌",
			skipEvent: "跳过事件",
			chooseCardToKeep: "选择保留的一张牌",
			keepCard: "保留此牌",
			useElevator: "是否启动神秘电梯？",
			rideElevator: "掷骰启动电梯",
			stayHere: "留在原处",
			chooseItemToBury: "选择要埋掉的物品",
			adjustHouseForPlacement: "调整房间，为指定房间留出相连的门口",
			moveElevatorTo: "将电梯移到{{direction}}侧门外",
			chooseElevatorDoor: "选择电梯的出口",
			chooseCharacter: "选择探险者",
			selectCharacter: "选择此人物",
			chooseFirst: "选择下一个过生日的探险者先手",
			firstPlayer: "由此探险者先手",
			takeTurn: "选择行动",
			endTurn: "结束回合",
			lootCard: "从尸体取走此牌",
			errNotYourTurn: "现在不能由你执行此动作",
			errBadChoice: "此选项已经失效",
			logGain: "提升 {{n}} 格属性",
			logLose: "降低 {{n}} 格属性",
			logTrade: "转移一张牌",
			logRoll: "掷骰结果为 {{n}}",
			logEvent: "遭遇事件",
			logUse: "使用一张牌",
			logAttack: "战斗差值为 {{n}}",
			logMonsterKilled: "消灭怪物",
			logMonsterStunned: "击晕怪物",
			logHeal: "治疗 {{n}} 格属性",
			logMove: "移动到房间",
			logDiscover: "发现新房间",
			logNoTile: "没有找到可放置的房间",
			logEmptyDeck: "此牌堆已空",
			logDraw: "抽取一张牌",
			logDeath: "探险者死亡",
			logDamage: "承受 {{n}} 点伤害",
			logEncounter: "遭遇奈博尔特宅邸的幻象",
			logTurn: "开始第 {{n}} 回合",
			logHaunt: "作祟开始",
			chooseDelivery: "选择接收礼物的探险者",
			giveDelivery: "送出物品并移动到对方房间",
			chooseEncounterTrait: "进行遭遇检定",
			acknowledgeHaunt: "阅读目标后继续",
			hauntBegins: "作祟开始，请查看你的目标",
			chooseTokenRecipient: "选择标记的接收者",
			giveTokenTo: "将标记交给此探险者",
			finishMonster: "结束此怪物的行动",
			monsterAction: "选择怪物的行动",
			stalkPrey: "潜行到此房间",
			learnJack: "调查杰克的往事",
			studyExorcism: "研究驱魔仪式",
			exorciseJack: "驱逐杰克的亡魂",
			placeJackSpirit: "将杰克的亡魂放到最远的预兆房间",
			chooseCircle: "选择要移动的驱魔法阵",
			moveCircle: "将此法阵移到你的房间",
			learnCurse: "研究诅咒",
			cleanseRoom: "净化此房间",
			prepareWard: "制作防护符",
			freeRealtor: "举行解咒仪式",
			moveRealtor: "选择恶魔房产经纪人的移动",
			stopMoving: "停止移动",
			playPeekaboo: "让两尊石像相互对视",
			placeCherub: "放置一尊石像",
			destroyRing: "摧毁戒指",
			ringCounterPrompt: "可在戒指摧毁前揭示身份并移动英雄",
			revealAndDisplace: "揭示身份并将英雄送回楼梯",
			allowRingDestroyed: "让戒指被摧毁",
			chooseLandingForHero: "为这位英雄选择楼梯",
			timeLoopReturn: "返回楼梯，或留在原地承受 2 点精神伤害",
			stayAndTakeMental: "留在原地并承受 2 点精神伤害",
			searchDustCure: "寻找尘疫的疗法",
			cureDust: "治愈尘疫",
			controlImpulses: "请求随机交换一枚病症标记",
			acceptSicknessSwap: "是否同意随机交换一枚病症标记？",
			privateDecision: "正在处理秘密选择",
			lootToken: "从尸体取走此标记",
			breakMirrorSpell: "尝试用此属性和预兆解除魔咒",
			chooseMirrorClue: "选择此事件作为线索",
			mirrorCluePrompt: "你只能通过事件牌向朋友传递线索",
			chooseClueRecipient: "选择线索的接收者",
			sendClue: "将线索交给此英雄",
			logMirrorClue: "收到了镜中朋友的线索",
			logMirrorRejected: "此组合未能解除魔咒",
			cleanHouse: "清洁房间",
			chooseRoomFloor: "选择房间所在的楼层",
			placeRoomOnFloor: "在此楼层放置房间",
			placeHousekeeper: "放置一名管家",
			takeEvidence: "拾取证据",
			uncoverTruth: "揭露真相",
			revealIdentity: "揭示身份",
			placeEvidence: "将证据放在不同房间，配对证据放在不同楼层",
			searchShelves: "搜索书架",
			chooseStealOrDamage: "选择夺取物件或造成伤害",
			stealIdol: "夺取神像，代替伤害",
			dealCombatDamage: "造成战斗伤害",
			buryForAttack: "可埋掉任意数量的物品，每件令攻击结果增加 1",
			makeAttack: "进行攻击",
			searchTreasure: "寻找宝藏",
			stealRandomTreasure: "随机夺取一枚宝藏，代替伤害",
			takeTreasurePrompt: "选择要取走的宝藏",
			peekTreasurePrompt: "选择要偷看的宝藏",
			takeTreasure: "取走此宝藏",
			peekTreasure: "秘密查看此宝藏",
			logTreasureValue: "此宝藏的价值为 {{n}}",
			rummageFood: "翻找食物",
			stealFood: "从储藏室偷取食物",
			stealCard: "夺取此牌，代替伤害",
			combineHands: "合力进行力量为 8 的攻击",
			carryCorpse: "携带此尸体",
			feedSleeper: "将尸体献给沉睡者",
			studyRitual: "研究仪式",
			disruptRitual: "破坏仪式",
			burnBook: "在火中烧毁魔法书",
			hastenSpell: "加速施法",
			rebornFurniture: "选择供你重生的家具",
			rebornHere: "移除此家具并在此处重生",
			giveBookNearest: "将魔法书交给最近的英雄",
			searchWeapons: "寻找武器",
			attackGhostSymbol: "用圣符攻击幽灵",
			sayBoo: "大喊吓人",
			slurp: "吸血",
			howl: "嚎叫攻击",
			chooseMonsterOrder: "选择下一只行动的怪物",
			takeMonsterTurn: "让此怪物行动",
			moveFrightenedHero: "选择受惊英雄的移动",
			repeatHowl: "可继续攻击同房尚未被嚎叫攻击的英雄",
			stopAttacking: "停止攻击",
			breakThrough: "穿墙移动到相邻英雄所在的房间",
			unearthRemains: "挖出并携带这具遗骸",
			identifyRemains: "辨认这具遗骸",
			consecrateRemains: "安葬看守人的遗骸",
			placeRemains: "秘密放置 {{n}} 号遗骸",
			placeAngryGhost: "选择没有英雄的房间放置愤怒幽灵",
			attackSanity: "进行神志攻击",
			researchGremlins: "用手机研究小魔怪",
			chooseGremlinRune: "选择要标记符文的小魔怪",
			markGremlin: "给此小魔怪放置符文",
			logMessageDie: "{{actor}} 收到“死亡”消息",
			logMessageX: "{{actor}} 收到“X”消息",
			teleportGremlinAttack: "让此小魔怪传送并攻击",
			chooseGremlinAttack: "可选择至多两只未击晕的小魔怪攻击",
			destroyTape: "销毁这盘录像带",
			staveCurse: "延缓诅咒",
			placeVideotape: "将录像带尽量放在远离英雄的不同房间",
			placeVengefulSpirit: "选择一盘录像带所在的房间放置复仇怨灵",
			findSyllable: "寻找下一个音节",
			chooseSyllableRoom: "秘密选择第 {{n}} 个音节所在的房间",
			logSyllableFound: "{{actor}} 找到了第 {{n}} 个音节",
			logSyllableDistance: "下一个音节在本楼层，普通门路径距离为 {{n}} 步；−1 表示没有连通路径",
			logSyllableWrongFloor: "下一个音节在其他楼层",
			summonIllusions: "召唤幻象并结束回合",
			confrontIllusion: "质询此幻象",
			callRing: "呼唤戒指",
			placeIllusion: "秘密放置 {{n}} 号幻象",
			chooseIllusionDispel: "选择要驱散的幻象",
			dispelIllusion: "驱散此幻象",
			chooseIllusionOrder: "选择下一个行动的幻象",
			activateIllusion: "让此幻象行动",
			illusionAction: "选择此幻象的行动",
			finishIllusion: "结束此幻象的行动",
			logIllusionDispelled: "驱散了 {{n}} 号幻象",
			returnBookSpooky: "将魔法书交还斯普基",
			burnManuscript: "烧毁手稿",
			attackHorrorTrait: "用此属性攻击恐怖怪物",
			buildCharacter: "锻炼身心",
			ghostwrite: "为此房间写下恐怖情节",
			createDiversion: "在地下室放置一个房间",
			escapeHouse: "逃离宅邸",
			studyFloorPlan: "研究平面图",
			inspectBasementTile: "秘密查看下一块地下室房间",
			returnTileTop: "将房间放回牌堆顶部",
			shiftBlueprint: "移动此英雄所在的房间",
			turnOffMachine: "关闭这台机器",
			wreckHouse: "破坏此房间",
			turnOnLasers: "开启激光",
			placeCircuit: "将电路开关尽量均匀地分布在三个楼层",
			chooseRobotStun: "选择本楼层一台机器人并将其击晕",
			stunRobot: "击晕此机器人",
			chooseRoomRelocation: "选择房间的新位置与朝向",
			relocateRoom: "移到坐标（{{x}}，{{y}}），旋转 {{rotation}}°",
			attackSpeed: "进行速度攻击",
			dropFlame: "放下此精灵火焰",
			pickFlame: "拾起此精灵火焰",
			chooseDanceDamage: "可移动双方棋子，代替造成伤害",
			moveDanceFigures: "移动双方棋子",
			stepDance: "踏起永恒之舞",
			chooseDanceHero: "选择黑暗女王所在楼层的一名英雄",
			moveDanceHero: "移动此英雄",
			findIngredient: "寻找此种施法材料",
			breakArmorSpell: "解除盔甲的法术",
			chooseCombatReward: "选择这次攻击成功后的结果",
			adjustHouseForDiscovery: "选择对既有房间的最小调整，保留连通并为探索留下开放门",
			useHiddenPassages: "使用密道前往此房间",
			ruinTribute: "破坏贡品",
			pruneFamily: "剪除家族分支",
			destroyAltar: "摧毁祭坛",
			placeAltar: "选择地面层的房间放置祭坛",
			placeRelative: "选择不同的预兆房间放置亲族",
			chooseRelativeRemove: "选择要移除的亲族",
			removeRelative: "移除此亲族",
			spreadWord: "传播外星文字",
			learnLanguage: "研究外星语言",
			rerollAlienDice: "凭外星知识重掷第 {{dice}} 颗骰子",
			chooseHeroDieRemove: "选择一颗英雄的骰子并移除",
			removeHeroDie: "移除此骰子",
			logHeroDieRemoved: "外星文字移除了 {{actor}} 的一颗骰子",
			chooseWordRoom: "选择相邻房间放置外星文字",
			searchExplosives: "寻找爆炸物",
			feedExplosives: "将爆炸物塞进鲨鱼喉咙",
			chooseFloodRoom: "选择要淹没的房间",
			floodRoom: "淹没此房间",
			cueOminousMusic: "播放不祥的音乐并游到此房间",
			chooseExplosivesSpend: "选择要消耗的爆炸物数量",
			spendExplosives: "消耗 {{n}} 枚爆炸物，检定结果为 {{total}}",
			rendIron: "拆取冷铁",
			learnFae: "研究精灵",
			bindFae: "施法束缚精灵",
			logOmenRevealed: "{{actor}} 展示了 {{id}}",
			compelSpirit: "展示戒指并驱使幽魂",
			performCeremony: "举行婚礼仪式",
			chooseOmenReveal: "可翻开目标英雄的一张预兆，并令其保持正面朝上",
			revealOmenBack: "翻开第 {{n}} 张背面朝上的预兆",
			skipOmenReveal: "不翻开预兆并继续攻击",
			distributeSecretOmen: "为 {{card}} 秘密选择持有人",
			giveSecretOmen: "将此预兆交给该英雄",
			placeWeddingParty: "选择预兆房间放置婚礼宾客",
			dispelCurse: "解除此物品的诅咒并拿取",
			channelSpirit: "引导此物品中的诅咒幽魂",
			attackTrait: "用所选属性徒手攻击",
			speakSpirits: "承受一骰一般伤害并与幽魂交谈",
			stealOrDamage: "选择造成伤害或偷取一张牌",
			dealDamage: "造成这次攻击的伤害",
			chooseCursedCard: "选择被诅咒的物品或预兆",
			selectCursedCard: "诅咒此牌",
			chooseCursedRoom: "选择诅咒物品的房间",
			chooseDamageTarget: "选择承受伤害的英雄",
			damageHero: "令此英雄承受伤害",
			distractCat: "埋掉所选牌并引开此亡灵猫",
			burnRoom: "在此房间放置火焰",
			summonCat: "召唤一只亡灵猫",
			chooseCatRoom: "选择亡灵猫的房间",
			smashCamera: "砸碎魔法相机",
			takePhoto: "拍摄此英雄的精魄",
			choosePhotographerRoom: "选择幽灵摄影师的房间",
			summonSlugs: "召唤两只蛞蝓",
			findSalt: "寻找食盐",
			destroyNest: "摧毁巢穴",
			pickUpSalt: "拾取此食盐",
			chooseNestRoom: "选择巢穴的房间",
			chooseSaltSpend: "选择消耗的食盐数量",
			spendSalt: "消耗 {{n}} 枚食盐，检定结果为 {{total}}",
			consumeGhost: "吞噬幽灵",
			reconcileGhost: "帮助幽灵和解",
			metamorphSubject: "与此英雄交换身体并结束回合",
			uploadDna: "上传当前身体的 DNA 样本",
			messCircuits: "用知识攻击此保安机器人",
			attemptEscape: "尝试逃出宅邸",
			chooseRobotTarget: "选择此机器人追逐的英雄",
			pursueHero: "追逐此英雄",
			findChristina: "搜寻克里斯蒂娜",
			leapFaith: "从未连接的门跃入虚空",
			manipulatePain: "扭曲空间，令所有英雄受伤并移动",
			manipulateGain: "扭曲空间，提升任一属性 2 格",
			manipulateRoom: "扭曲空间，移动此房间",
			callOffParty: "取消聚会",
			chooseNeighborRoom: "选择邻居出现的房间",
			pickUpEgg: "拾取此黄蜂卵",
			destroyEggs: "尝试摧毁所有携带的黄蜂卵",
			defendSwarm: "牺牲此工蜂，令所选英雄受一骰身体伤害",
			layEgg: "用此尸体孵育一枚黄蜂卵",
			chooseEggRoom: "选择黄蜂卵的房间",
			protectFamily: "唤醒此被击晕的邪恶双生",
			scryTwin: "用水晶球占卜",
			attackTraitNamed: "用{{trait}}攻击此英雄",
			chooseTwin: "选择要击晕的邪恶双生",
			stunTwin: "击晕此邪恶双生",
			stealMask: "偷取面具",
			reactivateGenerator: "重新启动发电机",
			disableTrap: "拆除所选陷阱",
			sabotageElectronics: "破坏电子设备",
			overloadGenerator: "使发电机过载",
			possessElectronics: "操控电器，在此房间布置陷阱",
			twistHallways: "扭曲走廊并移动一名探险者",
			chooseGeneratorRoom: "选择发电机的房间",
			favoritePlaces: "重访同伴最爱的地方并全治疗",
			exorciseSpirit: "驱除房间中的幽魂",
			grabBite: "从储藏室取得一枚食物",
			offerDogFood: "可交出一枚食物，使恶犬本次攻击结果减少 4",
			feedDog: "交出一枚食物，攻击结果减少 4",
			hideWolf: "躲藏以避开狼人",
			charmWolf: "安抚野兽",
			revealHidden: "揭穿此英雄的躲藏",
			curseEnemies: "诅咒此英雄",
			communeWolves: "驱使狼人移动一格并攻击",
			setFire: "尝试点燃当前房间",
			chooseMannequinRoom: "选择人偶出现的楼梯区",
			chooseBurnRoom: "选择火势蔓延的房间",
			stealScript: "偷取剧本",
			rewriteScript: "改写剧本",
			chooseCardToBury: "选择要埋掉的物品或预兆",
			chooseExplorer: "选择探险者",
			moveExplorer: "移动此探险者",
			learnHairCurse: "研究毛发诅咒",
			discoverAntidote: "查看此解药，若为真药则拾取",
			shiftHair: "与此小型毛发怪物交换位置",
			chooseAntidoteRoom: "选择解药放置的房间",
			chooseAntidote: "选择一枚背面朝上的解药",
			revealAntidote: "翻开此解药",
			knightSanityAttack: "用神志攻击此受困英雄，结果增加 2",
			knightTrapAttack: "用力量攻击，尝试困住此英雄",
			escapePortal: "尝试逃出传送门",
			closePortal: "关闭传送门",
			choosePortalRoom: "选择最远房间放置传送门",
			reviveHost: "复活宅邸主人",
			collectBlood: "收集此英雄的血液",
			burnContract: "焚烧契约",
			bloodMagic: "承受一骰精神伤害并施展鲜血魔法",
			stealContract: "从恶魔手中夺取契约",
			chooseDemonRoom: "选择地下室最远的房间放置恶魔",
			setExplosive: "埋掉所选牌并设置临时炸药",
			consumeFlesh: "吞噬此尸体",
			consumeRoom: "吞噬当前房间",
			chooseExplosiveToMove: "选择移动到当前房间的炸药",
			moveExplosiveHere: "将此炸药移动到当前房间",
			chooseConstructTeleport: "可传送到有英雄的房间并失去剩余移动",
			searchSilver: "寻找镀银物件",
			herdHero: "选择将受伤英雄推往的相邻房间",
			shareFeeding: "消耗一枚鲜血并全治疗",
			sanctifyArea: "净化当前房间",
			prepareAltar: "在当前净化房间准备祭坛",
			driveVampireBack: "选择没有英雄的房间放置被击晕的吸血鬼",
			revealHunter: "揭示叛徒身份，全治疗并提升各属性一格",
			interrogate: "审问此探险者",
			logInterrogate: "{{actor}} 秘密获知 {{target}} 的号码为 {{n}}",
			forceChange: "承受一骰精神伤害并强制变为狼人",
			prepareWerewolf: "为对抗狼人准备此属性",
			saveWerewolf: "尝试救治人形莎拉",
			chooseFloor: "选择楼层",
			blockHero: "拦截此英雄",
			catchIdol: "尝试接住神像",
			scoreIdol: "将神像送至祭坛得分",
			passIdol: "是否同意交出神像？",
			twistDarkness: "扭曲黑暗并移动此探险者",
			grabBell: "尝试拾取此钟铃",
			stopBellMusic: "将此钟铃放入隔音室",
			rockAround: "在当前房间生长槲寄生藤蔓",
			rustleAround: "翻找藤蔓中的物件",
			createOrnament: "尝试将此物件制成装饰品",
			trimTree: "尝试将此装饰品挂到叛徒身上",
			reviveTree: "选择牺牲的藤蔓并在该处复活",
			reviveHere: "移除该怪物并在此复活",
			kissDeath: "用速度发动死亡之吻",
			chooseKissEffect: "选择造成伤害或生长一株藤蔓",
			growKudzuHere: "在此房间生长藤蔓",
			choosePlantRoom: "选择植物怪物的房间",
			chooseDeck: "选择要抽取的牌堆",
			drawFromDeck: "从此牌堆抽取一张牌",
			gazeHorror: "用知识发动恐怖凝视",
			takeOfferingFood: "拾取此食物",
			makeOffering: "将此食物留在房间作为供品",
			niceGift: "将{{card}}赠给{{player}}并清除房间内的煤炭怪物",
			scroungeFood: "搜寻更多食物",
			divideFood: "选择食物放在厨房还是储藏室",
			gazeCoalOffer: "可埋掉一张物品牌，在目标房间召唤煤炭怪物",
			chooseCoal: "选择要移动的煤炭怪物",
			moveCoal: "将此煤炭怪物移到目标房间",
			findPresent: "寻找礼物",
			mineMine: "秘密抽取一张预兆",
			buryForPresents: "选择埋掉的物品牌，以补足礼物设置",
			passWish: "选择接手此礼物号码的存活英雄",
			choosePresent: "选择一件摊开的礼物或抽取物品牌堆顶牌",
			takePresent: "取得此礼物并翻开其号码",
			drawItem: "抽取物品牌堆顶牌",
			boostKrampusRoll: "可埋掉背面朝上的物品或预兆，每张增加一骰",
			buryHiddenBoost: "埋掉此牌并增加一骰",
			rollWithBoost: "开始掷骰，额外增加 {{n}} 骰",
			stealPresent: "可夺取一件未与英雄号码匹配的物品",
			stealItem: "夺取此物品",
			toyExplore: "让玩具探索此门后的新房间",
			carryToy: "携带此被击晕的玩具",
			banishMischief: "尝试驱除所携玩具的魔力",
			chooseToyCard: "选择要被玩具附身的物品或预兆",
			chooseThisCard: "选择此牌",
			chooseToyRoom: "选择此玩具的房间",
			chooseFarthestToyRoom: "选择最远房间，让玩具恢复行动",
			lookForWeapon: "搜寻武器",
			banishHockstetter: "尝试驱逐霍克斯泰特僵尸",
			hockGuard: "可让同房的霍克斯泰特代受攻击",
			redirectHock: "将攻击目标改为霍克斯泰特",
			callHock: "可让霍克斯泰特向你移动至多三个房间",
			moveHockCloser: "召来霍克斯泰特",
			hockMoveHenry: "将剩余移动用于移动亨利",
			hockGiveItem: "抽取物品牌堆顶牌交给亨利",
			placeHock: "选择有未探索门的房间，让霍克斯泰特重返宅邸",
			healOneTrait: "选择治疗至初始值的属性",
			healTrait: "将此属性治疗至初始值",
			findWeakness: "调查当前怪物的弱点",
			searchKillIt: "寻找对抗它的物件",
			banishForm: "用神志尝试驱逐此被击晕的形态",
			moveSearched: "选择移到搜索房间的已搜索标记",
			moveTokenHere: "将此标记移到当前房间",
			recoverForm: "解除击晕后，本回合只能移动或攻击",
			recoverMoveOnly: "本回合只移动",
			recoverAttackOnly: "本回合只攻击",
			chooseFormRoom: "选择当前形态出现的英雄房间",
			placeFormWithHero: "将当前形态放在此英雄的房间",
			shareFormFear: "选择共同承担这一点精神伤害的英雄",
			takeMentalPoint: "承受一点精神伤害",
			withdrawForm: "本楼层已无英雄，可收回当前形态",
			withdrawIt: "将当前形态收回储备",
			depositArtifact: "尝试将此信物投入祭坛",
			completeRitual: "尝试完成丘德仪式",
			findArtifactInstead: "可寻找一件信物，代替抽取房间牌",
			findArtifact: "取得此信物",
			drawRoomCard: "按房间图标正常抽牌",
			returnRitualRoom: "选择对宅邸影响最小的仪式房间放回牌堆",
			returnRoomToDeck: "将此房间放回牌堆",
			tauntPennywise: "尝试嘲讽潘尼怀斯",
			crushPennywise: "尝试摧毁被击晕的潘尼怀斯",
			chooseClownVictim: "选择潘尼怀斯在同房攻击的英雄",
			findWayThrough: "尝试接通这组房间与主楼梯区",
			helpAnotherHero: "尝试前往另一名英雄的房间并结束回合",
			findWayOut: "所有存活英雄共同尝试逃离宅邸",
			chooseTinyToMove: "选择移至新房间的微型恐魔",
			moveTerrorHere: "将此微型恐魔移到新房间",
			connectRoomGroup: "选择整组房间与主宅邸的连接位置",
			connectThisGroup: "保持组内布局，连接这组房间",
			chooseHeroToHelp: "选择要前往援助的英雄",
			moveToHero: "前往此英雄的房间",
			chooseTinyVictim: "选择这组微型恐魔攻击的英雄",
			moveUnseenHorror: "可移动到另一处所有英雄均看不见的房间",
			rules: "准备与目标：\n选择一个场景。基础版五个场景使用基础组件；“月下嚎叫”“节日宅邸”“归家见恶”分别使用对应扩展，不混合三个扩展。每人选择不同颜色的一名人物。“月下嚎叫”必须有莎拉；“节日宅邸”必须有精灵或铃爪。按生日决定先手，然后依座位顺序轮流行动。\n游戏先共同探索宅邸，再按触发的作祟剧本分配阵营和胜负目标。通常是英雄合作对抗叛徒，也可能有隐藏叛徒、全员合作或各自争胜。作祟后的目标和特殊规则优先于基本规则。\n人物属性：\n力量、速度属于身体属性；神志、知识属于精神属性。轨道位置决定当前数值，提升或降低属性指移动轨道格数，不是直接加减显示数值。绿色起始位置是治疗基准；治疗将低于起始位置的属性恢复到起始位置，不降低较高属性。最左端的数值位置称为危急值，再降低一格就是骷髅。\n回合与移动：\n回合开始时，获得等于当时速度数值的移动力。本回合速度改变不会重算移动力。每经过一扇相连的门通常消耗1点；离开有对手或障碍的房间额外消耗1点，多个对手和障碍不累加。可以在移动前后使用允许的物品、交易或执行剧本动作，也可以提前结束回合。\n楼梯与其他特殊通路按房间说明连接。通常只能穿过相接的门，不能穿墙，不能从地下平台直接爬回地面楼梯；物品、房间或剧本的特例除外。特殊通路、房间能力和危急属性可在人物档案及房间详情中查看。\n发现房间：\n穿过尚未探索的门，抽取适用楼层的新房间，选择朝向，使来路门口连接。其他相邻房间的门不必相接。将人物移入新房间，结算发现、进入效果和房间图标，然后结束回合。物品、预兆、事件图标分别对应各自牌堆；有2个图标时，分别从对应牌堆各抽取1张牌。房间能力仅在写明的时机生效；普通进入旧房间不会再次抽牌。\n物品与预兆：\n物品和预兆通常由获得者公开持有，能力持续生效或按牌面使用；事件按牌面结算。每张牌的主动特殊动作每回合只能用一次，除非牌面另有说明。“埋掉”指将卡牌放到对应牌堆底部。刚获得的牌本回合不能执行主动特殊动作，也不能用作武器；持续能力仍适用。\n交易与尸体：\n在自己的回合中，可以与同一房间内的1名探险者交易1次，交换任意数量的物品、预兆及允许交易的标记，单方赠送也属于交易，须对方同意。可在同房尸体上拿取物品、预兆及允许搜取的标记，每回合只能从每具尸体拿取一件。剧本另有限制时按剧本执行。\n掷骰与伤害：\n属性检定按当前数值掷骰，每颗骰子有0、1、2点，将点数相加并应用修正。牌面允许的替代属性、额外骰子及重掷会在相应时机供选择。掷出的伤害骰表示点数总和的伤害，不是骰子颗数。\n受伤者逐点分配伤害：身体伤害降低力量或速度，精神伤害降低神志或知识，一般伤害可降低任意属性。作祟前不能降到骷髅，仍有可降低的非危急属性时，不得把伤害分配给危急属性。直接降低属性与承受伤害不同，不触发护甲等减伤能力。\n作祟检定：\n作祟前，每次抽到预兆后，掷等于所有探险者持有预兆总数的骰子，5点以上开始作祟；抽完最后一张预兆自动开始。触发者称为揭幕者，场景与刚抽到的预兆决定剧本。事件也可能直接触发指定剧本。“归家见恶”在作祟前以遭遇代替房间预兆抽牌，并按已翻开的遭遇张数掷作祟骰。\n作祟开始后：\n按剧本完成设置，分别阅读自己的阵营目标及秘密信息。通常从叛徒左侧的探险者开始新一轮。已公开的叛徒可以选择忽略不利的房间效果，也可以在发现事件房间时不抽事件。隐藏叛徒仍遵守相应剧本的身份规则。探索仍可继续，普通预兆不再进行作祟检定。\n战斗：\n作祟后，每个回合通常可以攻击一次。徒手攻击同房的对手，双方用力量检定；高点数者获胜，败方承受等于差值的身体伤害，平手无伤害。武器可能改用其他属性、增加骰子或允许远程攻击；精神属性攻击造成精神伤害。防御也会掷骰，正常近战中攻击者失败会受伤。\n枪以速度对抗速度，能攻击视线内目标；视线沿同一行或列穿过相连门口，不能穿墙或转弯。弩能攻击同房或相邻相连房间，使用速度属性进行检定，并额外投掷1颗骰子。枪与弩攻击失败时不承受反击伤害。武器的详细能力及消耗见牌面说明。\n怪物、死亡与胜负：\n怪物通常在叛徒回合后行动。同种怪物掷一次速度骰决定各自移动力，至少为1；每个怪物独立移动和攻击，不能探索。普通怪物受伤后被击晕，跳过下次回合；有些剧本允许杀死怪物或使其免疫。具体属性、行动及死亡例外以剧本为准。\n作祟后，任一属性降到骷髅时人物死亡，除非物品或剧本提供替代。死亡后不能再行动，持有物留在尸体处，仍可能按阵营目标共同获胜。满足剧本胜利条件时立即结束；调查报告显示实际胜者并允许回看宅邸。",
			uiHouse: "宅邸",
			uiDossier: "人物档案",
			uiInventory: "物品与预兆",
			uiObjective: "阵营目标",
			uiJournal: "动作历史",
			uiJournalEmpty: "尚无动作记录",
			uiClose: "关闭",
			uiWait: "等待 {{name}}",
			uiResolve: "正在结算",
			uiTurn: "第 {{n}} 回合",
			uiMovement: "移动 {{n}}",
			uiMusicOn: "开启配乐",
			uiMusicOff: "关闭配乐",
			uiMusicFailed: "无法播放配乐，请重试",
			uiFit: "查看全景",
			uiZoomIn: "放大地图",
			uiZoomOut: "缩小地图",
			uiPlaceConfirm: "确认放置",
			uiPlaceTools: "放置房间",
			uiFloorU: "上层",
			uiFloorG: "地面层",
			uiFloorB: "地下层",
			uiHero: "英雄",
			uiTraitor: "叛徒",
			uiIndividual: "各自为战",
			uiUnknown: "身份未公开",
			uiDead: "已死亡",
			uiStunned: "已击晕",
			uiHidden: "未揭示",
			uiCritical: "危急",
			uiSelected: "已选择",
			uiExplore: "探索宅邸",
			uiHaunt: "作祟",
			uiScenario: "场景",
			uiPackBase: "第三版基础游戏",
			uiPackBlood: "月下血影",
			uiPackYuletide: "圣诞奇谭",
			uiPackPennywise: "奈博尔特宅邸：潘尼怀斯之恶",
			uiStranger: "节日访客",
			uiReport: "宅邸调查报告",
			uiVictory: "你们活着走出了宅邸",
			uiDefeat: "宅邸留下了你们",
			uiWinners: "获胜者",
			uiNoWinners: "无人逃过宅邸的命运",
			uiReview: "回看宅邸",
			uiShowReport: "查看报告",
			uiAgain: "再来一局",
			uiLobby: "返回大厅",
			uiConfirmAgain: "确认重新开始？本局回看将关闭。",
			uiConfirmLobby: "确认返回大厅？本局回看将关闭。",
			uiHostWait: "等待主机开启下一局",
			uiObject: "物件",
			uiTrack: "倒数轨道",
			uiDice: "掷骰",
			uiResult: "结果 {{n}}",
			uiNoCards: "尚未持有物品或预兆",
			uiRules: "查看规则",
			uiDoor: "探索{{direction}}侧的门",
			uiN: "北",
			uiE: "东",
			uiS: "南",
			uiW: "西",
			uiRotation: "旋转 {{n}}°",
			uiRoomChoice: "{{action}}：{{name}}",
			uiBirthday: "生日 {{date}} · {{n}} 岁",
			uiUnknownBirthday: "生日不详",
			uiHiddenNumber: "秘密号码",
			uiOwnedTokens: "携带标记",
			uiConditionWrecked: "已损毁",
			uiConditionFlooded: "已淹没",
			uiConditionBurning: "燃烧中",
			uiConditionConsumed: "已吞噬",
			uiOutcome: "{{name}} · {{team}}",
			label_conservatory: "温室",
			label_armory: "武器库",
			label_bloodyRoom: "血腥房间",
			label_catacombs: "地下墓穴",
			label_charredRoom: "焦黑房间",
			label_ritualRoom: "仪式室",
			label_kitchen: "厨房",
			label_ballroom: "舞厅",
			label_junkRoom: "杂物间",
			label_panicRoom: "避难室",
			label_laundryChute: "洗衣滑槽",
			label_laboratory: "实验室",
			label_chapel: "礼拜堂",
			label_soundproofedRoom: "隔音室",
			label_salon: "沙龙",
			label_specimenRoom: "标本室",
			label_secretStaircase: "秘密楼梯",
			label_library: "图书馆",
			label_undergroundLake: "地下湖",
			label_statuaryCorridor: "雕像走廊",
			label_nursery: "育婴室",
			label_tower: "塔楼",
			label_crawlspace: "狭窄夹层",
			label_operatingTheatre: "手术室",
			label_gameRoom: "游戏室",
			label_larder: "食品储藏室",
			label_observatory: "天文台",
			label_diningRoom: "餐厅",
			label_gymnasium: "健身房",
			label_undergroundCavern: "地下洞窟",
			label_organRoom: "管风琴室",
			label_vault: "金库",
			label_primaryBedroom: "主卧室",
			label_winterBedroom: "冬季卧室",
			label_mysticElevator: "神秘电梯",
			label_chasm: "深渊",
			label_gallery: "画廊",
			label_crampedPassageway: "狭窄通道",
			label_graveyard: "墓园",
			label_furnaceRoom: "炉房",
			label_guestQuarters: "客房",
			label_collapsedRoom: "坍塌房间",
			label_groundStaircase: "地面层楼梯",
			label_hallway: "走廊",
			label_entranceHall: "入口大厅",
			label_upperLanding: "上层平台",
			label_basementLanding: "地下层平台",
			label_oubliette: "密牢",
			label_trophyRoom: "战利品室",
			label_timeLostTree: "遗失时光之树",
			label_rootCellar: "地窖",
			label_ancientDen: "古老巢穴",
			label_windingTunnels: "蜿蜒隧道",
			label_darkenedHallway: "幽暗走廊",
			label_oldWell: "古井",
			label_isa: "伊莎·瓦伦西亚",
			label_anita: "阿妮塔·埃尔南德斯",
			label_jaden: "杰登·琼斯",
			label_sammy: "萨米·安格勒",
			label_oliver: "奥利弗·斯威夫特",
			label_josef: "约瑟夫·胡珀",
			label_warren: "梁沃伦神父",
			label_dan: "阮丹医生",
			label_persephone: "珀耳塞福涅·普莱里",
			label_stephanie: "斯蒂芬妮·里希特",
			label_brittani: "布里塔妮·鲍恩",
			label_michelle: "米歇尔·门罗",
			label_sara: "阮莎拉",
			label_werewolf: "狼人",
			label_elf: "精灵",
			label_jingleklaws: "铃爪",
			label_machete: "砍刀",
			label_crossbow: "弩",
			label_firstAidKit: "急救箱",
			label_mirror: "镜子",
			label_angelsFeather: "天使之羽",
			label_strangeMedicine: "奇异药物",
			label_mysticalStopwatch: "神秘秒表",
			label_skeletonKey: "万能钥匙",
			label_strangeAmulet: "奇异护符",
			label_dynamite: "炸药",
			label_magicCamera: "魔法相机",
			label_headphones: "耳机",
			label_gun: "手枪",
			label_rabbitsFoot: "兔脚",
			label_flashlight: "手电筒",
			label_luckyCoin: "幸运硬币",
			label_map: "地图",
			label_necklaceOfTeeth: "牙齿项链",
			label_brooch: "胸针",
			label_leatherJacket: "皮夹克",
			label_chainsaw: "电锯",
			label_creepyDoll: "诡异人偶",
			label_dog: "爱犬",
			label_book: "书籍",
			label_dagger: "匕首",
			label_ring: "戒指",
			label_armor: "盔甲",
			label_idol: "偶像",
			label_holySymbol: "圣符",
			label_skull: "头骨",
			label_mask: "面具",
			label_fangBracelet: "獠牙手镯",
			label_wolfsbane: "乌头草",
			label_unusualCake: "奇怪的蛋糕",
			label_snowGlobe: "雪景球",
			label_hiddenOmen: "未揭示的预兆",
			label_might: "力量",
			label_speed: "速度",
			label_sanity: "神志",
			label_knowledge: "知识",
			label_dice: "骰子",
			label_physical: "身体",
			label_mental: "精神",
			label_general: "一般",
			label_item: "物品",
			label_item2: "物品",
			label_omen: "预兆",
			label_event: "事件",
			label_event2: "事件",
			label_paranormalInvestigators: "超自然调查员",
			label_strangeDisappearance: "离奇失踪",
			label_forSale: "出售中",
			label_mysteriousInvitation: "神秘邀请",
			label_cursed: "诅咒",
			label_howlAtTheMoon: "月下嚎叫",
			label_holidayHouse: "节日宅邸",
			label_comeHomeToEvil: "归家见恶",
			label_blessing: "祝福",
			label_secretPassage: "秘密通道",
			label_alienWord: "异星词语",
			label_knowledgeOfAliens: "异星知识",
			label_packWolf: "狼群成员",
			label_silverRune: "银色符文",
			label_vampireMaster: "吸血鬼主宰",
			label_vampireBlood: "吸血鬼之血",
			label_sanctified: "圣化之地",
			label_vampireAltar: "吸血鬼祭坛",
			label_hunterNumber: "猎人号码",
			label_phaseSupply: "月相储备",
			label_phaseTrait: "月相属性",
			label_sportNest: "狼巢",
			label_spectralIdol: "幽灵偶像",
			label_sportAltar: "赛场祭坛",
			label_ghostAdversary: "幽灵对手",
			label_blockingSpirit: "阻挡之灵",
			label_dna: "遗传样本",
			label_securityRobot: "安保机器人",
			label_essence: "灵魂精华",
			label_photographer: "摄影师",
			label_bakeneko: "化猫",
			label_undeadCat: "不死猫",
			label_fire: "火焰",
			label_treasure: "宝藏",
			label_construct: "血肉造物",
			label_makeshiftExplosive: "简易炸药",
			label_heroBlood: "英雄之血",
			label_contractDemon: "契约恶魔",
			label_infernalContract: "地狱契约",
			label_mirrorBeing: "镜中生物",
			label_housekeeper: "清洁者",
			label_cleanedRoom: "已清理房间",
			label_cursedItem: "诅咒物品",
			label_demonicDog: "恶魔犬",
			label_exorcisedSpirit: "已驱逐亡魂",
			label_dogFood: "犬粮",
			label_christina: "克里斯蒂娜",
			label_jackSpirit: "杰克的亡魂",
			label_exorcismCircle: "驱魔法阵",
			label_demonRealtor: "恶魔经纪人",
			label_cleansedFire: "净化火焰",
			label_wardOfProtection: "防护结界",
			label_stoneCherub: "石像小天使",
			label_relative: "亲属",
			label_elder: "长老",
			label_evilTwin: "邪恶分身",
			label_gardenFae: "花园妖精",
			label_coldIron: "冷铁",
			label_knowledgeOfFae: "妖精知识",
			label_giantHair: "巨发怪",
			label_smallHair: "小发怪",
			label_antidote: "解毒剂",
			label_dustResearch: "尘埃研究",
			label_feverish: "发热",
			label_evidence: "证据",
			label_giantWasp: "巨蜂",
			label_workerWasp: "工蜂",
			label_waspEgg: "蜂卵",
			label_headOfHouse: "宅邸主人",
			label_illusion: "幻象",
			label_circuit: "电路",
			label_robotAssistant: "机器人助手",
			label_trappedHero: "受困英雄",
			label_knightPortal: "骑士传送门",
			label_machineTrap: "机器陷阱",
			label_generator: "发电机",
			label_theHouse: "宅邸",
			label_sabotaged: "已破坏",
			label_spooky: "斯普基",
			label_horror: "恐怖幻象",
			label_coldWarZombie: "冷战僵尸",
			label_seelieFlame: "光明妖精之焰",
			label_faeDancer: "妖精舞者",
			label_darkQueen: "暗影女王",
			label_peaceGhost: "待安息幽灵",
			label_formSearched: "已调查形态",
			label_knownWeakness: "已知弱点",
			label_zombieHockstetter: "僵尸霍克斯泰特",
			label_henrySearched: "已搜查线索",
			label_henryVictim: "亨利的受害者",
			label_tinyTerror: "微型恐魔",
			label_pennywiseClown: "小丑潘尼怀斯",
			label_pennyTarget: "潘尼怀斯的目标",
			label_personalArtifact: "个人信物",
			label_chudAltar: "楚德祭坛",
			label_pennywiseSpider: "蜘蛛潘尼怀斯",
			label_cultist: "邪教徒",
			label_ritualKnowledge: "仪式知识",
			label_animatedFurniture: "活化家具",
			label_seamFire: "裂缝火焰",
			label_mannequin: "人体模型",
			label_ghostShark: "幽灵鲨",
			label_explosive: "爆炸物",
			label_slug: "蛞蝓",
			label_slugNest: "蛞蝓巢穴",
			label_salt: "盐",
			label_neighbor: "邻居",
			label_remains: "遗骸",
			label_angryGhost: "愤怒幽灵",
			label_gremlin: "小魔怪",
			label_gremlinRune: "小魔怪符文",
			label_vengefulSpirit: "复仇亡魂",
			label_facelessMan: "无面人",
			label_syllable: "音节",
			label_altar: "祭坛",
			label_weddingParty: "婚礼宾客",
			label_witchFood: "女巫的食物",
			label_trollHand: "巨魔手掌",
			label_bell: "铃铛",
			label_coalCreature: "煤块怪物",
			label_offeringFood: "食物供品",
			label_giftRune: "礼物符文",
			label_krampus: "坎卜斯",
			label_presentWish: "礼物愿望",
			label_presentNumber: "礼物号码",
			label_presentSearched: "已检查礼物",
			label_mischievousToy: "恶作剧玩具",
			label_toyNumber: "玩具号码",
			label_smallToy: "小玩具",
			label_ornament: "装饰物",
			label_ghost: "幽灵",
			label_vampire: "吸血鬼",
			label_werewolfMonster: "狼人",
			label_zombie: "僵尸",
			label_robot: "机器人",
			label_pennywise: "潘尼怀斯",
			label_pennyClown: "潘尼怀斯",
			label_pennySpider: "潘尼怀斯",
			label_hockstetter: "霍克斯泰特",
			label_fae: "妖精",
			label_spirit: "亡魂",
			label_cherub: "小天使",
			label_furniture: "家具",
			label_food: "食物",
			label_rune: "符文",
			label_searched: "已搜索",
			label_obstacle: "障碍",
			label_redBalloon: "红气球",
			label_coal: "煤块",
			label_artifact: "信物",
			label_kudzu: "葛藤",
			label_yuleLog: "圣诞木柴",
			label_krampusItem: "坎卜斯物品",
			label_videotape: "录像带",
			label_krampusOmen: "坎卜斯预兆",
			label_ingredient: "材料",
			label_hiddenFromWerewolf: "躲避狼人",
			label_mindControlled: "受到精神控制",
			label_trappedByKnight: "被骑士困住",
			label_secretElevator: "隐秘电梯",
			label_creakingDoor: "吱呀作响的门",
			label_cryForHelp: "呼救声",
			label_momentOfHope: "希望之光",
			label_darkStormyNight: "风雨交加之夜",
			label_spiders: "蛛群",
			label_meatMoss: "肉苔",
			label_eerieFeeling: "诡异之感",
			label_hangedMen: "被吊死的人",
			label_poorYorick: "可怜的约里克",
			label_impossibleArchitecture: "不可能的建筑",
			label_alienGeometry: "异星几何",
			label_bite: "撕咬",
			label_funeral: "葬礼",
			label_jonahsTurn: "轮到乔纳了",
			label_flickeringLights: "忽明忽暗的灯",
			label_flowering: "花开",
			label_fullTable: "满桌盛宴",
			label_deepestCloset: "最深的壁橱",
			label_burningFigure: "燃烧的身影",
			label_behindYou: "在你身后",
			label_clownRoom: "小丑房间",
			label_radioBroadcast: "无线电广播",
			label_tinyRobot: "微型机器人",
			label_taxidermy: "标本制作",
			label_severedHand: "断手",
			label_phoneCall: "电话铃响",
			label_batOutOfHell: "地狱之蝠",
			label_sayCheese: "说“茄子”",
			label_mysteriousFluid: "神秘液体",
			label_splashOfCrimson: "猩红飞溅",
			label_forbiddenKnowledge: "禁忌知识",
			label_vialOfDust: "灰尘小瓶",
			label_cassettePlayer: "磁带录音机",
			label_eerieMirror: "诡异的镜子",
			label_oldestHouse: "最古老的宅邸",
			label_jarOfOrgans: "器官罐",
			label_technicalDifficulties: "技术故障",
			label_wanderingGhost: "游荡的鬼魂",
			label_starsAtNight: "夜空繁星",
			label_brainFood: "脑髓佳肴",
			label_houseIsHungry: "宅邸饿了",
			label_hunt: "狩猎",
			label_bloodMoon: "血月",
			label_feast: "盛宴",
			label_gift: "礼物",
			label_floatingLights: "漂浮的光点",
			label_knifeInDark: "黑暗中的刀",
			label_bloodTendrils: "血色触须",
			label_goodBoy: "好孩子",
			label_popOfRed: "一团红色",
			label_hometownHorrors: "故乡的恐怖",
			label_swirlingVisions: "旋转幻象",
			label_stretchingHall: "延伸的走廊",
			label_timeToSink: "沉没时刻",
			label_eaterOfWorlds: "吞噬世界者",
			label_haunt1: "堆叠如柴2：猩红杰克归来",
			label_haunt2: "永远的朋友",
			label_haunt3: "尘埃",
			label_haunt4: "解救房产经纪人",
			label_haunt5: "石中之血",
			label_haunt6: "遗产",
			label_haunt7: "镜中倒影",
			label_haunt8: "清理宅邸",
			label_haunt9: "往事随风",
			label_haunt10: "一份诚意报价",
			label_haunt11: "别被煮熟",
			label_haunt12: "援手",
			label_haunt13: "圣地",
			label_haunt14: "物体恒存",
			label_haunt15: "怪物与混乱",
			label_haunt16: "来陪我们玩",
			label_haunt17: "不转发就死",
			label_haunt18: "戒指的回响",
			label_haunt19: "录像惊魂",
			label_haunt20: "别说出口",
			label_haunt21: "斯普基·麦克马斯特呈献……",
			label_haunt22: "地下行动",
			label_haunt23: "入侵警报",
			label_haunt24: "暗影假面舞会",
			label_haunt25: "借来的时间",
			label_haunt26: "家族的祝福",
			label_haunt27: "来自星辰的话语",
			label_haunt28: "我们需要更大的房子",
			label_haunt29: "美丽花园",
			label_haunt30: "至死不渝",
			label_haunt31: "幽灵一线生机",
			label_haunt32: "猫灾",
			label_haunt33: "对镜头微笑",
			label_haunt34: "沿走廊右转第二维度",
			label_haunt35: "太空蛞蝓",
			label_haunt36: "寻得安宁",
			label_haunt37: "灵魂出窍",
			label_haunt38: "邪恶晚宴",
			label_haunt39: "蜂群心智",
			label_haunt40: "剥皮行者归来",
			label_haunt41: "机器中的神",
			label_haunt42: "零食袭击",
			label_haunt43: "躲猫猫与吃人",
			label_haunt44: "消失的接缝",
			label_haunt45: "大胆的初登场",
			label_haunt46: "幽灵发丝",
			label_haunt47: "难忘的骑士之夜",
			label_haunt48: "别惹主人不高兴！",
			label_haunt49: "条款与条件",
			label_haunt50: "血肉与金属的滋味",
			label_hauntblood1: "狼群首领",
			label_hauntblood2: "黑暗之屋",
			label_hauntblood3: "狼人战队",
			label_hauntblood4: "猎人与猎物",
			label_hauntblood5: "不只是月相",
			label_hauntyuletide1: "恶作剧玩具之家",
			label_hauntyuletide2: "地狱铃声",
			label_hauntyuletide3: "树木的背叛",
			label_hauntyuletide4: "他知道你何时入睡",
			label_hauntyuletide5: "坎卜斯之夜",
			label_hauntpennywise1: "亨利的猎杀",
			label_hauntpennywise2: "各自的噩梦",
			label_hauntpennywise3: "众生皆须遵从",
			label_hauntpennywise4: "楚德仪式",
			label_hauntpennywise5: "杀死这个小丑",
			objective_1_hero: "在图书馆以知识5以上获得关于杰克的知识。在事件房以知识5以上布置驱魔法阵；与亡魂同房以神志检定，所在楼层每个法阵使结果加1，达到7即获胜。击倒杰克只会使其化为亡魂；亡魂回到尸体房间会复活。",
			objective_1_traitor: "消灭所有英雄。未攻击且不在英雄视线内时，可潜行至上层或地面层的隐蔽房间。死亡后控制亡魂回到尸体房间复活。",
			objective_2_hero: "戒指持有者以速度或知识尝试毁掉戒指，每个时间扰动房间内的英雄使结果加1，7以上获胜。失败承受6点一般伤害并回到平台。倒数归零前完成；秘密叛徒可在成功前干预。",
			objective_2_traitor: "阻止英雄毁掉戒指，等待倒数归零，或消灭所有英雄。可揭示身份，治疗全部属性并提升1格力量。",
			objective_3_hero: "在预兆房间以知识或神志5以上放置研究标记。到实验室、手术室、天文台或厨房，以任意属性尝试治愈粉尘；每枚研究使结果加2，13以上获胜。秘密病号在交换中可能改变阵营。",
			objective_3_traitor: "消灭所有英雄。任何曾持有1号病症者永久成为叛徒，即使之后交出该号码。死亡后可能成为狂热者继续行动。",
			objective_4_hero: "全体合作解救恶魔房产经纪人。图书馆、礼拜堂或实验室知识5以上获得诅咒知识；事件房速度6以上净化火焰。与经纪人同房，神志结果加同楼层火焰、知识和仪式室奖励，13以上获胜。",
			objective_4_traitor: "全体合作，解救房产经纪人。",
			objective_5_hero: "消除全部小天使。与一只同房且能看见另一只时，以知识4以上移除这两只；持镜子结果加2，失败承受2骰一般伤害。小天使不能被普通攻击；它们的视线会造成伤害。",
			objective_5_traitor: "全体合作，消除所有小天使。",
			objective_6_hero: "杀死秘密叛徒。取得证据后，与相同属性的另一枚证据会合，进行该属性5以上检定，揭示尚未亮明的最大号码身份。若回合中没有攻击，结束时承受2骰精神伤害。",
			objective_6_traitor: "杀死所有英雄。可以主动亮明身份并治疗全部属性、提升1格力量。未亮明时，若回合中没有攻击，结束时承受2骰精神伤害；因此死亡时改为亮明身份。",
			objective_7_hero: "全体合作寻找镜中咒语的房间、预兆和属性组合。揭示者每回合以事件牌给出线索；英雄持正确预兆、在正确房间，以正确属性掷出5以上即可获胜。",
			objective_7_traitor: "使用你掌握的房间、预兆和属性组合，通过事件牌向英雄传递线索。",
			objective_8_hero: "全体合作清理血腥房间、焦黑房间、坍塌房间、杂物间和地下墓穴。每个房间以速度或神志5以上完成清理；清理全部五个房间获胜。",
			objective_8_traitor: "全体合作清理宅邸。",
			objective_9_hero: "各自为战，成为最后一名存活的探险者。物品房知识5以上可找物品；攻击前可埋掉物品提升攻击结果。持偶像击杀他人会使偶像更强。",
			objective_9_traitor: "成为最后一名存活的探险者。",
			objective_10_hero: "在四轮倒数结束时拥有最高的宝藏总值，平分者共同获胜。预兆房知识4以上取得宝藏，1至3只能查看。结束时位于地面层楼梯额外获得2点。",
			objective_10_traitor: "收集最多宝藏，并在倒数结束时获胜。",
			objective_11_hero: "各自为战，成为最后一名存活者。知识6以上寻找食物，指定食物房间结果加2。食物被拿完后，没有食物的人死亡，然后开始食物更少的新一轮。",
			objective_11_traitor: "成为最后一名存活者。",
			objective_12_hero: "持有奇异护符，并成为唯一存活者。护符持有者控制巨魔之手；力量攻击获胜时可以偷取物品或预兆代替伤害。",
			objective_12_traitor: "持有奇异护符，并成为唯一存活者。",
			objective_13_hero: "在图书馆、礼拜堂或仪式室以知识5以上取得符文。在仪式室以神志检定，加持有符文数、减存活邪教徒数，6以上获胜；消灭叛徒和全部邪教徒也获胜。",
			objective_13_traitor: "将尸体运到深渊，以神志7以上献祭，倒数降到0即获胜。失败提升2格神志。也可消灭所有英雄。",
			objective_14_hero: "保住书籍直到倒数归零。全队每轮可由书籍持有者进行一次神志5以上的阅读，倒数减少1；阅读无论成败失去1神志。怪物行动后英雄仍持书也使倒数减少1。",
			objective_14_traitor: "夺走书籍，在厨房、炉房或实验室毁掉它，或消灭所有英雄。家具可用于死亡后复活，但每次消耗一件。",
			objective_15_hero: "消灭全部怪物。幽灵需要圣符的神志攻击，吸血鬼需要弩，狼人需要匕首。物品或预兆房知识4以上可从对应牌堆前四张中选择一张。",
			objective_15_traitor: "控制你的怪物，消灭所有英雄。各类怪物具有独立移动和攻击能力。",
			objective_16_hero: "找到1号看守人遗骸，并带到墓园以神志5以上安葬。知识5以上可辨认同房遗骸；携带的遗骸会在叛徒回合开始时造成精神伤害。",
			objective_16_traitor: "利用幽灵和遗骸诅咒消灭所有英雄。死亡会产生新的幽灵。",
			objective_17_hero: "在塔楼、画廊或天文台以知识5以上给小魔怪加符文，使其可以被消灭。消灭叛徒和所有小魔怪获胜。回合结束会抽取危险信息。",
			objective_17_traitor: "利用小魔怪和死亡信息消灭所有英雄。",
			objective_18_hero: "击破幻象并消灭叛徒。同房知识5以上可驱散幻象，持镜子结果加2；金库可用神志加持有预兆数量，8以上呼唤戒指。",
			objective_18_traitor: "用幻象隐藏本体并消灭所有英雄。本体揭示时移除最高号码的一个幻象，之后可重新召唤剩余幻象。",
			objective_19_hero: "以力量4以上毁掉同房录像带。毁掉全部录像带后，任意英雄在入口大厅结束回合即可获胜。与亡魂同房可冒险延长倒数。",
			objective_19_traitor: "倒数归零或消灭所有英雄。利用录像带之间的特殊通路追击。",
			objective_20_hero: "按顺序查出隐藏在房间中的全部音节，然后以成功攻击消灭无面人。猜错时会得到楼层和门路距离线索，但无面人会立即袭击。",
			objective_20_traitor: "保护隐藏音节的顺序，控制无面人消灭所有英雄。",
			objective_21_hero: "从斯普奇处取得书籍，在炉房、仪式室、厨房、实验室或焦黑房间以神志5以上烧毁它。持书可以任意属性攻击恐魔。",
			objective_21_traitor: "保护书籍，利用斯普奇和恐魔消灭所有英雄。可将夺回的书交还图书馆内的斯普奇。",
			objective_22_hero: "从地下逃出，到入口大厅或墓园以速度6以上离开宅邸。持炸药或万能钥匙使结果加2。",
			objective_22_traitor: "在实验室放置地下房间并召唤僵尸，消灭所有英雄。在英雄抵达地面前不得离开实验室。",
			objective_23_hero: "以知识5以上关闭全部开关，并在预兆房以力量4以上破坏指定数量的房间。两项目标完成后在英雄回合末获胜。",
			objective_23_traitor: "移动房间、利用机器人激光消灭所有英雄。",
			objective_24_hero: "收集全部火焰并放到礼拜堂。拾取时以速度或知识5以上免伤；失败仍取得火焰但承受2点一般伤害。",
			objective_24_traitor: "用舞者和黑暗女王阻止火焰归位，消灭所有英雄。",
			objective_25_hero: "收集规定种类的材料：在对应房间以对应属性4以上放置材料标记。然后在武器库或仪式室以神志5以上解除盔甲诅咒。",
			objective_25_traitor: "让英雄持有诅咒盔甲，逐步消耗他们的属性并强化自己，消灭所有英雄。死亡后在盔甲所在处复活。",
			objective_26_hero: "在仪式室以神志4以上破坏贡品，消灭叛徒，再到祭坛以力量4以上将其摧毁。画廊或雕像走廊神志5以上可驱除一名亲属。",
			objective_26_traitor: "利用亲属、长老和卧室的秘密通道消灭所有英雄。",
			objective_27_hero: "消灭叛徒。在图书馆、天文台、塔楼、实验室或标本室以知识4以上获得异星知识，可在攻击叛徒时重掷最多两骰。异星文字会阻碍移动并造成精神伤害。",
			objective_27_traitor: "在无英雄和文字的房间以知识7以上放置自己的文字，相邻每个文字房使结果加1。放完全部文字后结束回合，或消灭所有英雄，即获胜。",
			objective_28_hero: "物品房速度4以上取得爆炸物。与幽灵鲨同房以力量10以上炸死它，每消耗一枚爆炸物结果加2，持炸药再加2。",
			objective_28_traitor: "逐步淹没全部可淹房间，或消灭所有英雄。幽灵鲨可在淹没的房间之间移动。",
			objective_29_hero: "与妖精同房以知识9以上束缚它。持妖精知识、冷铁或戒指，每种使结果加2。物品房力量5以上取得冷铁；图书馆或仪式室知识5以上获得妖精知识。",
			objective_29_traitor: "利用妖精和速度攻击消灭所有英雄。",
			objective_30_hero: "探索最后一个房间以找到祭坛，利用戒指引导叛徒到祭坛，在同房以神志6以上完成婚礼。英雄的预兆身份保密，可在需要时展示。",
			objective_30_traitor: "取得戒指即获胜。调查英雄隐藏的预兆，避免被带到祭坛。",
			objective_31_hero: "击晕诅咒物品后驱散并取得它。某名英雄在入口大厅结束回合时持有圣符及足够数量的其他物件，即获胜。圣符会在回合末造成一般伤害。",
			objective_31_traitor: "吸收诅咒物品并消灭所有英雄。吸收时使同楼层的一名英雄承受2骰一般伤害。",
			objective_32_hero: "清除同楼层全部猫，再以力量攻击击败猫又。可以埋掉物品或预兆，移动一只同房的猫最多四格并击晕它。",
			objective_32_traitor: "放完全部火焰，或消灭所有英雄。猫会增强猫又的力量。",
			objective_33_hero: "与叛徒同房以神志6以上毁掉魔法相机，并消灭全部摄影师，随后在英雄回合末获胜。摄影师只能由力量伤害杀死。",
			objective_33_traitor: "利用相机、摄影师和夺取的精华消灭所有英雄。",
			objective_34_hero: "在预兆房掷轨道数量的骰子，9以上找到克里斯蒂娜；带她到入口大厅，再以同样方式掷出9以上逃离。发现预兆会增加轨道值。",
			objective_34_traitor: "操纵房间和英雄，阻止克里斯蒂娜逃走，消灭所有英雄。",
			objective_35_hero: "摧毁上层和地下的两个巢穴。巢穴房速度9以上成功，每消耗一份盐使结果加2。可在指定食物或研究房间以知识或速度5以上取得盐。",
			objective_35_traitor: "利用太空蛞蝓的神志攻击，将所有英雄转化或杀死。蛞蝓成组攻击后会死亡。",
			objective_36_hero: "与幽灵同房以神志5以上让它安息。全队安息的幽灵达到所需总数即获胜，已经安息的数量不会因人物死亡而消失。",
			objective_36_traitor: "以知识4以上吞噬同房幽灵、提升神志；在神志达到最高值时结束回合，或消灭所有英雄。",
			objective_37_hero: "消灭全部机器人，然后在入口大厅以速度4以上减少轨道值，直到归零。天文台、游戏室、实验室或避难室可用知识攻击同楼层机器人。",
			objective_37_traitor: "交换身体，取得英雄的遗传样本并在预兆房上传；全部上传或英雄全部死亡即获胜。",
			objective_38_hero: "在事件房以知识或神志6以上减弱召唤，减少每轮出现的邻居数。在英雄回合末没有存活邻居时获胜。戒指持有者可持续攻击直到第一次失败。",
			objective_38_traitor: "召唤邻居消灭所有英雄。死亡后回到厨房复活，并把戒指交给击杀者。",
			objective_39_hero: "收集并以知识5以上摧毁携带的虫卵，再成功攻击巨蜂。宅邸内每枚剩余虫卵使攻击结果减1。",
			objective_39_traitor: "保护虫卵，让倒数归零，或消灭所有英雄。虫卵房间会不断产生工蜂。",
			objective_40_hero: "消灭全部邪恶分身。只有分身对应的英雄或面具持有者造成伤害时才能将其杀死；其他伤害只会击晕。塔楼或仪式室知识5以上可击晕任意分身。",
			objective_40_traitor: "利用邪恶分身消灭所有英雄。可以解除同房一个分身的击晕。",
			objective_41_hero: "拆除陷阱或破坏设备以增加轨道值，再在发电机房间掷轨道数量的骰子，5以上关闭发电机。关闭全部发电机获胜。",
			objective_41_traitor: "重启被关闭的发电机，以宅邸和陷阱消灭所有英雄。重启需要同房知识4以上。",
			objective_42_hero: "在图书馆、食品储藏室、健身房和礼拜堂用对应属性4以上完成足够数量的驱魔，然后成功攻击恶魔犬。食物可使恶魔犬的攻击结果减少4。",
			objective_42_traitor: "喂养恶魔犬，消灭所有英雄。你可以在四个闹鬼房间治疗全部属性。",
			objective_43_hero: "坚持到轨道归零。在狼人视线之外以速度5以上躲藏；没有英雄在怪物回合受伤时倒数减少2，否则减少1。移动会解除躲藏。",
			objective_43_traitor: "找出躲藏者，用狼人消灭所有英雄。",
			objective_44_hero: "以神志4以上点燃房间，让火势蔓延至整座宅邸；在英雄回合末全部房间着火时获胜。英雄进入火焰会承受1点一般伤害。",
			objective_44_traitor: "利用不怕火的人体模型消灭所有英雄，阻止他们烧完宅邸。",
			objective_45_hero: "以速度4以上从叛徒处偷走书籍，在图书馆、舞厅、画廊或客房以知识6以上降低轨道。轨道为0后杀死叛徒获胜；此前击杀只会使其复活并降低轨道。",
			objective_45_traitor: "用武器和事件房奖励消灭所有英雄。轨道仍大于0时死亡会复活，并立即获得回合。",
			objective_46_hero: "寻找1号解毒剂。图书馆知识5以上可翻开任意解毒剂；亲自到房间也可翻开。携带真解毒剂攻击巨发怪结果加3，成功击败它获胜。",
			objective_46_traitor: "将所有英雄杀死并变为毛发怪。巨发怪只能被力量伤害击倒，并可使用预兆房之间的特殊通路。",
			objective_47_hero: "被困英雄在传送门以知识6以上逃脱，同房有自由英雄结果加2。自由英雄以知识或神志4以上关闭传送门，全部关闭获胜。",
			objective_47_traitor: "将英雄困住，并消灭所有英雄。每回合可以分别攻击每名英雄一次；将死时治疗全部属性。",
			objective_48_hero: "击败头颅取得头骨，把头骨带到避难室立即获胜。持有者在回合末以速度5以上免伤，失败承受2点身体伤害。",
			objective_48_traitor: "保住头骨并消灭所有英雄。持有头骨时可在同房复活头颅并把头骨交给它。",
			objective_49_hero: "以力量攻击恶魔获胜时可偷取契约。持契约以知识7以上烧毁它，炉房、仪式室、厨房、实验室或焦黑房间结果加4。",
			objective_49_traitor: "收集所有英雄落下的血液并带到恶魔所在房间，或消灭所有英雄。",
			objective_50_hero: "埋掉一件物品或预兆，以速度或知识6以上放置爆炸物。放完全部爆炸物且三层各至少一枚，在英雄回合末获胜。",
			objective_50_traitor: "吞噬所有非平台房间，或消灭所有英雄。吞噬尸体会增加你的移动速度；吞噬预兆房可传送到英雄房间。",
			objective_blood1_hero: "在物品或预兆房以知识3以上从前四张牌中选择一张，得到的武器带有银色符文。以符文武器击杀莎拉获胜；这类武器攻击她额外掷两骰，并抑制她下回合的成长。",
			objective_blood1_traitor: "控制狼群消灭所有英雄。若上轮未被符文武器伤害，回合开始时提升力量和速度。",
			objective_blood2_hero: "预兆房知识3以上完成全部圣化，再在圣化房以神志4以上放祭坛。必须在祭坛房击败吸血鬼才会获胜；其他房间只能将其移走并击晕。",
			objective_blood2_traitor: "让吸血鬼吸取血液变强，消灭所有英雄。可在同房消耗一份血液治疗全部属性。",
			objective_blood3_hero: "全体合作，把球带到祭坛取得分数，先达到目标分即获胜。未击晕的幽灵守球时，以力量对抗其速度抢球。",
			objective_blood3_traitor: "全体合作，抢球并送往祭坛得分。",
			objective_blood4_hero: "查明并消灭秘密叛徒。与非狼人探险者独处时，以知识对抗其神志查看号码。莎拉若是英雄，必须保护她；误杀英雄可能使叛徒立即获胜。",
			objective_blood4_traitor: "号码1为叛徒。若你是莎拉，英雄互杀或英雄全部死亡即获胜；否则莎拉死亡即获胜。可揭示身份，治疗并提升全部属性。",
			objective_blood5_hero: "在预兆房以标记对应属性4以上布置仪式。击杀狼形莎拉获胜；或持书籍或面具与人形莎拉同房，以知识加已布置标记数5以上尝试驱魔，成功救赎时莎拉也共同获胜。",
			objective_blood5_traitor: "轨道达到9，或狼形消灭所有英雄，独自获胜。人形被成功救赎时可与存活英雄共同获胜。",
			objective_yuletide1_hero: "全体合作击晕玩具，带给访客驱逐。只有访客持编号物品时可用知识3以上驱逐对应玩具，全部驱逐获胜。访客死亡或房间牌堆耗尽则失败。",
			objective_yuletide1_traitor: "全体合作驱逐全部玩具。",
			objective_yuletide2_hero: "在铃铛所在房以对应属性3以上取得铃铛，放到隔音室。所放铃铛达到玩家人数即获胜。",
			objective_yuletide2_traitor: "使轨道归零或消灭所有英雄。回合开始及探险者死亡时轨道减少；死亡改为提高轨道并治疗。",
			objective_yuletide3_hero: "从葛藤房取得物件，把非武器且非爱犬的物件以知识3以上换成符文饰品。与叛徒同房速度3以上交出饰品，交付数量达到玩家人数获胜。",
			objective_yuletide3_traitor: "让葛藤形成所需长度的连续房间链，或消灭所有英雄。死亡时可消耗一处葛藤复活；没有葛藤时英雄获胜。",
			objective_yuletide4_hero: "消灭叛徒。可用食物削弱它的下一次防御；赠送物品可移除同房煤块。厨房和食品储藏室知识3以上可补充食物。",
			objective_yuletide4_traitor: "利用煤块、凝视和物品优势消灭所有英雄。视线内有食物时必须靠近它。",
			objective_yuletide5_hero: "把匹配号码的物品赠送给对应英雄，让双方号码盖下；所有玩家号码都盖下即获胜。搜索物品房或武器库需知识3以上。",
			objective_yuletide5_traitor: "化为克朗普斯后，积累所需数量的物品或消灭所有英雄。偷取编号物品会打乱礼物号码。",
			objective_pennywise1_hero: "消灭亨利。物品房以速度或知识3以上搜寻前三张物品；同房神志5以上可驱除霍克斯泰特。",
			objective_pennywise1_traitor: "依秘密名单追杀英雄，消灭全部英雄获胜。霍克斯泰特可以保护、移动你或给你物品。",
			objective_pennywise2_hero: "以知识或神志减去轨道值，4以上把独立房间组接回主宅邸。所有存活英雄在入口大厅时共同掷神志，最高与最低结果之和达到8即可逃离。",
			objective_pennywise2_traitor: "控制微型与巨型恐魔，消灭所有英雄。微型恐魔全部移动后才按房间组攻击；不在英雄视线内时可重新潜伏。",
			objective_pennywise3_hero: "找出当前形态的弱点并将其击晕，再与它同房以神志成功攻击驱逐形态。轨道归零获胜。图书馆等调查房知识5以上可揭示弱点。",
			objective_pennywise3_traitor: "利用各形态的能力消灭所有英雄。被击晕后恢复的回合只能移动或攻击二选一；同楼层无英雄时可收回当前形态。",
			objective_pennywise4_hero: "全体合作寻找各自信物并送到祭坛。祭坛无潘尼怀斯时神志4以上可放入信物；全部信物放入后完成仪式，每名存活英雄各掷一骰，总和至少等于存活人数则获胜。",
			objective_pennywise4_traitor: "全体合作完成丘德仪式。",
			objective_pennywise5_hero: "全体合作。视线内以知识或神志4以上嘲讽潘尼怀斯，取得红气球并降低轨道。它被击晕时，与其同房以力量加同房其他英雄数、减轨道值，5以上摧毁它。此检定不能用物品或预兆修改。",
			objective_pennywise5_traitor: "全体合作，摧毁潘尼怀斯。",
			detail_machete: "武器。力量攻击的结果加1。",
			detail_crossbow: "武器。可攻击同房或相邻房间的目标，以速度对抗速度，多掷1骰。攻击失败时不承受反击伤害。",
			detail_firstAidKit: "自己的回合可以埋掉此牌，治疗同房一名探险者的全部危急属性，包括自己。",
			detail_mirror: "自己的回合可以埋掉此牌，治疗知识和神志。",
			detail_angelsFeather: "进行属性检定前，可以埋掉此牌，将原始结果指定为0至8，再应用对应修正。",
			detail_strangeMedicine: "自己的回合可以埋掉此牌，治疗力量和速度。",
			detail_mysticalStopwatch: "作祟开始后，自己的回合可以埋掉此牌，在当前回合后立即再行动一回合。",
			detail_skeletonKey: "可以穿墙移动到已发现的相邻房间，不能穿墙探索。每次使用后掷1骰，空白时埋掉此牌。",
			detail_strangeAmulet: "每次承受身体伤害后，提升1格神志。一般伤害和直接降低属性不触发此能力。",
			detail_dynamite: "代替攻击埋掉此牌，选择同房或相邻房间。其中每个探险者和怪物分别进行速度检定：4以上安全，0至3承受4点身体伤害。",
			detail_magicCamera: "可以用神志代替知识进行检定。",
			detail_headphones: "每次承受的精神伤害减少1。一般伤害和直接降低属性不受影响。",
			detail_gun: "武器。可攻击视线内的目标，以速度对抗速度。攻击失败时不承受反击伤害。",
			detail_rabbitsFoot: "自己的回合，每回合一次，可以重掷刚掷出的一颗骰子。",
			detail_flashlight: "处理事件的属性检定时，可以额外掷2骰。",
			detail_luckyCoin: "自己的回合，每回合一次，可以重掷刚完成属性检定的全部空白骰。重掷后每个空白造成1点精神伤害。",
			detail_map: "自己的回合可以埋掉此牌，移动到任意已发现的房间。",
			detail_necklaceOfTeeth: "自己回合结束时，可以提升一项危急属性1格。",
			detail_brooch: "可以将将要承受的身体或精神伤害改为一般伤害。",
			detail_leatherJacket: "防御攻击时多掷1骰。",
			detail_chainsaw: "武器。攻击时多掷1骰。",
			detail_creepyDoll: "自己的回合，每回合一次，可以重掷刚完成属性检定的全部骰子，然后降低1格神志。",
			detail_dog: "速度检定结果加1。自己的回合，每回合一次，可以与四步之内的一名探险者按交易规则交换物品和预兆。",
			detail_holySymbol: "神志检定结果加1。发现房间时，可以埋掉该房间并改为发现下一张，原房间不结算。",
			detail_idol: "力量检定结果加1。发现事件房间时，可以选择不抽事件。",
			detail_dagger: "武器。攻击前先降低1格速度，再多掷2骰。",
			detail_ring: "神志检定结果加1。可以用神志对抗神志进行攻击，败方承受精神伤害。",
			detail_skull: "知识检定结果加1。将要死亡时先掷3骰：4以上将全部属性置于危急值；0至3死亡。",
			detail_book: "知识检定结果加1。自己的回合，每回合一次，可以降低1格神志；本回合下一次非攻击属性检定可以改用知识及其修正。",
			detail_armor: "每次承受的身体伤害减少1。一般伤害和直接降低属性不受影响。",
			detail_mask: "速度检定结果加1。自己的回合，每回合一次，可以将同房其他探险者与怪物分别移到相邻房间，不能探索。",
			detail_fangBracelet: "对怪物及狼人角色的攻击结果加1。",
			detail_wolfsbane: "防御狼人时多掷1骰。自己的回合可以埋掉此牌，治疗神志。",
			detail_unusualCake: "自己的回合可以埋掉此牌，治疗速度和神志。",
			detail_snowGlobe: "将要死亡时，改为移到入口大厅，将全部属性置于危急值，然后埋掉此牌。",
			detail_hiddenOmen: "此预兆的身份尚未公开。",
			detail_armory: "发现时，从物品牌堆依次翻牌直到出现武器。取得该武器，将其余翻开的牌埋回。",
			detail_junkRoom: "发现时放置障碍标记。离开有障碍的房间额外消耗1点移动力。",
			detail_panicRoom: "发现时，若秘密楼梯尚未出现，从房间牌堆找出并放到地下，再洗混牌堆。",
			detail_laundryChute: "可以单向前往地下平台。结束回合时，也会被移到地下平台。",
			detail_chapel: "发现时提升1格神志。",
			detail_secretStaircase: "与走廊双向相通。",
			detail_library: "发现时提升1格知识。",
			detail_larder: "发现时提升1格力量。",
			detail_gymnasium: "发现时提升1格速度。",
			detail_undergroundCavern: "与墓园双向相通。",
			detail_mysticElevator: "进入时，每回合一次，可以掷2骰移动整块电梯到开放门口：4任意楼层，3上层，2地面层，0至1地下。",
			detail_gallery: "可以单向前往舞厅。",
			detail_graveyard: "与地下洞穴双向相通。",
			detail_furnaceRoom: "在此结束回合，承受1点身体伤害。",
			detail_collapsedRoom: "在此结束回合，进行速度检定：5以上安全；0至4移到地下平台并承受1骰身体伤害。",
			detail_groundStaircase: "与上层平台双向相通。怪物还可以在此与地下平台之间通行。",
			detail_upperLanding: "与地面层楼梯双向相通。",
			detail_basementLanding: "怪物可以在此与地面层楼梯之间通行。",
			detail_hallway: "与秘密楼梯双向相通。",
			detail_entranceHall: "作祟开始前，不能离开宅邸。",
			detail_oubliette: "与战利品室双向相通。",
			detail_trophyRoom: "与地牢双向相通。",
			detail_timeLostTree: "发现时，若根窖尚未出现，将其放到地下并洗混房间牌堆。与根窖双向相通。",
			detail_rootCellar: "发现时，若迷时之树尚未出现，将其放到上层并洗混房间牌堆。与迷时之树双向相通。",
			detail_ancientDen: "发现时额外抽一张预兆，选择一张保留并埋掉另一张。",
			detail_windingTunnels: "东北与西南为不相连的两半。以知识4以上可以穿过两半之间的通道。",
			detail_darkenedHallway: "发现时抽取两张事件，按抽取顺序分别处理。",
			detail_oldWell: "发现时进行知识检定：4以上额外抽取一张物品；0至3埋掉一张物品。",
			detail_secretElevator: "你可以立即移动到另一楼层的一个已发现的房间。",
			detail_creakingDoor: "进行一次知识检定。结果为6点或以上时，你可以移动到上层或地面层的任意已发现房间；4至5点时，你可以移动到地面层的任意已发现房间；3点或以下时，你移动到地下层平台。",
			detail_cryForHelp: "进行一次知识检定。结果为4点或以上时，你可以移动到同一楼层的任意已发现房间；否则你受到1点精神伤害。",
			detail_momentOfHope: "在你所在的房间放置祝福标记。位于该房间的英雄进行任何属性检定时多掷1颗骰子。",
			detail_darkStormyNight: "进行一次知识检定。结果为4点或以上时，你提升1点神志；否则你受到1点精神伤害。",
			detail_spiders: "进行一次神志检定。结果为4点或以上时，你提升1点神志或速度，然后可以移动到相邻房间；2至3点时，你提升1点速度并降低1点神志；1点或以下时，你降低1点速度。",
			detail_meatMoss: "你可以选择掷2颗骰子。结果为3点或以上时，你提升任意1点属性；否则你掷1颗骰子并受到点数总和的精神伤害。",
			detail_eerieFeeling: "掷2颗骰子。结果为4点时无事发生；3点时你降低1点速度；2点时降低1点神志；1点时降低1点知识；0点时降低1点力量。",
			detail_hangedMen: "依次对力量、速度、神志和知识各进行一次检定。任意一次结果为1点或以下时，你降低该属性1点；若四次结果均为2点或以上，你提升任意1点属性。",
			detail_poorYorick: "进行一次神志检定。结果为4点或以上时，你提升1点知识；否则受到1点精神伤害。",
			detail_impossibleArchitecture: "进行一次神志检定。结果为4点或以上时，你抽取1张物品牌；否则掷1颗骰子并受到点数总和的精神伤害。",
			detail_alienGeometry: "进行一次知识检定。结果为4点或以上时，你提升1点神志；否则降低1点速度。",
			detail_bite: "进行一次力量检定。结果为4点或以上时你安然无恙；2至3点时受到1点身体伤害；1点或以下时受到3点身体伤害。",
			detail_funeral: "进行一次神志检定。结果为4点或以上时提升1点神志；2至3点时降低1点神志；1点或以下时降低1点神志和1点力量。随后若墓园或地下墓穴已经出现，你必须移动到其中之一。",
			detail_jonahsTurn: "你可以埋掉一件非武器物品，并提升1点神志；若你不这么做，掷1颗骰子并受到点数总和的精神伤害。",
			detail_flickeringLights: "选择速度或力量进行一次检定。结果为5点或以上时提升1点速度；否则掷1颗骰子并受到点数总和的身体伤害。",
			detail_flowering: "你受到1点一般伤害，然后移动到地面层或地下层的任意已发现房间。若温室已经出现，你必须移动到温室。",
			detail_fullTable: "选择知识或神志进行一次检定。结果为5点或以上时提升1点速度；否则受到1点一般伤害。",
			detail_deepestCloset: "进行一次速度检定。结果为4点或以上时抽取1张物品牌；1至3点时受到1点精神伤害；0点时掷1颗骰子并受到点数总和的身体伤害，然后移动到地下层平台。",
			detail_burningFigure: "进行一次神志检定。结果为4点或以上时提升1点神志；2至3点时你移动到入口大厅；1点或以下时掷1颗骰子受到点数总和的身体伤害，并掷1颗骰子受到点数总和的精神伤害。",
			detail_behindYou: "进行一次速度检定。结果为4点或以上时提升1点神志；否则受到1点身体伤害。",
			detail_clownRoom: "进行一次神志检定。结果为4点或以上时安然无恙；否则受到2点精神伤害。",
			detail_radioBroadcast: "掷2颗骰子。结果为3点或以上时提升1点知识；否则掷1颗骰子并受到点数总和的精神伤害。",
			detail_tinyRobot: "进行一次知识检定。结果为5点或以上时抽取1张物品牌；否则掷1颗骰子并受到点数总和的身体伤害。",
			detail_taxidermy: "进行一次力量检定。结果为5点或以上时提升1点神志；否则受到1点身体伤害，并在你所在的房间放置障碍标记。",
			detail_severedHand: "你可以承受2点身体伤害，然后抽取1张物品牌。",
			detail_phoneCall: "掷2颗骰子。结果为4点时提升1点神志；3点时提升1点知识；1至2点时掷1颗骰子并受到点数总和的精神伤害；0点时掷2颗骰子并受到点数总和的身体伤害。",
			detail_batOutOfHell: "进行一次速度检定。结果为4点或以上时，你可以移动到相邻房间；否则受到1点身体伤害。",
			detail_sayCheese: "作祟开始前，你可以进行一次作祟检定。结果为5点或以上时触发剧本《说“茄子”》，否则你抽取1张物品牌。作祟已经开始或你拒绝检定时，你抽取1张物品牌。",
			detail_mysteriousFluid: "你可以选择掷3颗骰子。结果为6点时四项属性各提升1点；5点时力量和速度各提升1点；4点时神志和知识各提升1点；3点时知识提升1点、力量降低1点；2点时神志和知识各降低1点；1点时力量和速度各降低1点；0点时四项属性各降低1点。",
			detail_splashOfCrimson: "作祟开始前，你可以进行一次作祟检定。结果为5点或以上时触发剧本《猩红飞溅》，否则你提升1点速度。作祟已经开始或你拒绝检定时，掷1颗骰子并受到点数总和的身体伤害。",
			detail_forbiddenKnowledge: "进行一次神志检定。结果为4点或以上时提升1点知识；2至3点时提升1点知识并降低1点神志；1点或以下时受到2点精神伤害。",
			detail_vialOfDust: "作祟开始前，你可以进行一次作祟检定。结果为5点或以上时触发剧本《灰尘小瓶》，否则你提升1点神志。作祟已经开始或你拒绝检定时，你降低1点力量并提升1点神志。",
			detail_cassettePlayer: "进行一次神志检定。结果为4点或以上时提升1点知识；否则受到1点精神伤害。",
			detail_eerieMirror: "作祟开始前，你可以进行一次作祟检定。结果为5点或以上时触发剧本《诡异的镜子》，否则你提升1点神志。作祟已经开始或你拒绝检定时，你抽取1张物品牌。",
			detail_oldestHouse: "选择速度或力量进行一次检定。结果为5点或以上时，你可以移动到任意已发现房间；3至4点时，你移动到地面层的任意已发现房间并受到1点一般伤害；2点或以下时，你移动到地下层的任意已发现房间并受到1点精神伤害。",
			detail_jarOfOrgans: "进行一次神志检定。结果为4点或以上时抽取1张物品牌；否则降低1点力量。",
			detail_technicalDifficulties: "你移动到下一层的平台。若你原本位于地下层，你改移到上层平台并受到1点精神伤害。",
			detail_wanderingGhost: "你可以埋掉一件物品，并提升任意1点属性；若你不这么做，进行一次神志检定，结果为4点或以上时抽取1张物品牌，否则受到1点一般伤害。",
			detail_starsAtNight: "选择任意一项属性并进行检定。结果为5点或以上时该属性提升1点；4点时该属性降低1点；3点或以下时治疗该属性。",
			detail_brainFood: "进行一次力量检定。结果为5点或以上时，你提升1点力量或速度；1至4点时提升1点速度并降低1点神志；0点时受到2点一般伤害。",
			detail_secretPassage: "在你所在的房间放置秘密通道标记，并进行一次知识检定。结果为5点或以上时，你可以把另一枚通道标记放到任意其他已发现房间并提升1点知识；3至4点时把另一枚通道标记放到地面层；2点或以下时把另一枚通道标记放到地下层并降低1点神志。两枚标记之间可以通行。",
			detail_houseIsHungry: "作祟开始前，你可以进行一次作祟检定。结果为5点或以上时触发剧本《宅邸饿了》，否则你提升1点力量。作祟已经开始或你拒绝检定时，你提升任意1点属性。",
			detail_hunt: "进行一次速度检定。结果为4点或以上时，你可以移动到同一楼层的任意已发现房间并提升1点神志；否则降低1点神志。",
			detail_bloodMoon: "进行一次神志检定。结果为4点或以上时提升1点力量；2至3点时无事发生；1点或以下时掷1颗骰子受到点数总和的身体伤害，并掷1颗骰子受到点数总和的精神伤害，然后移动到入口大厅。",
			detail_feast: "你可以选择掷2颗骰子。结果为4点时提升1点力量；3点时提升1点神志；1至2点时掷1颗骰子并受到点数总和的精神伤害；0点时掷2颗骰子并受到点数总和的身体伤害。",
			detail_gift: "你可以选择掷2颗骰子。结果为3点或以上时抽取1张物品牌；2点时无事发生；1点或以下时掷1颗骰子受到点数总和的身体伤害，并掷1颗骰子受到点数总和的精神伤害。",
			detail_floatingLights: "进行一次速度检定。结果为4点或以上时提升2点神志；否则降低1点神志。",
			detail_knifeInDark: "一名敌人以4颗骰子攻击你，你用力量防御。若你未受伤，抽取1张预兆牌。",
			detail_bloodTendrils: "进行一次神志检定。结果为4点或以上时抽取1张预兆牌；否则受到1点精神伤害。",
			detail_goodBoy: "一只巨犬以4颗骰子攻击你，你用速度防御。若你未受伤，可以移动到相邻房间并提升1点神志。",
			detail_popOfRed: "进行一次力量检定。结果为4点或以上时抽取1张预兆牌；否则掷1颗骰子受到点数总和的身体伤害，并掷1颗骰子受到点数总和的精神伤害。",
			detail_hometownHorrors: "进行一次神志检定。结果为4点或以上时提升1点神志并抽取1张预兆牌；否则受到1点精神伤害。",
			detail_swirlingVisions: "进行一次知识检定。结果为4点或以上时提升任意1点属性；否则受到1点精神伤害。",
			detail_stretchingHall: "进行一次神志检定。结果为4点或以上时抽取1张预兆牌；否则受到1点身体伤害。",
			detail_timeToSink: "进行一次速度检定。结果为4点或以上时提升1点力量；否则降低1点速度。",
			detail_eaterOfWorlds: "进行一次神志检定。结果为4点或以上时，你可以移动到相邻房间并抽取1张预兆牌；否则受到1点一般伤害。",
			uiSecretSickness: "病症号码",
			uiSecretTrait: "镜中属性",
			uiSecretOmen: "镜中预兆",
			uiSecretRoom: "镜中房间",
			uiSecretTarget: "追杀目标",
			uiSecretSyllables: "隐藏音节顺序",
			uiSecretWeakness: "当前形态弱点",
			uiSecretMessages: "死亡信息",
			uiSecretRemains: "遗骸号码顺序",
			uiRoomContents: "房间内的物件",
			uiTileDeck: "房间",
			uiItemDeck: "物品",
			uiOmenDeck: "预兆",
			uiEventDeck: "事件",
			uiEncounterDeck: "遭遇",
			uiSurvivors: "最终记录",
			uiWon: "获胜",
			uiLost: "未获胜",
			uiReviewHouse: "回看宅邸",
			uiConfirm: "确认",
			uiTrackValue: "作祟轨道：{{n}}",
			uiLiving: "存活",
			uiParty: "调查队",
			uiNoRoom: "位置不明",
			uiUnexplored: "尚未探索",
			uiCardItem: "物品卡",
			uiCardOmen: "预兆卡",
			uiCardEvent: "事件卡",
			uiCardEncounter: "遭遇卡",
			uiRevealDrawn: "{{name}} 抽到了",
			uiRevealAck: "我已确认",
			uiRevealConfirmed: "已确认 {{n}}/{{m}}",
			uiRevealWait: "等待其他玩家确认后继续",
			uiShortMight: "力量",
			uiShortSpeed: "速度",
			uiShortSanity: "神志",
			uiShortKnowledge: "知识",
			uiContentsCount: "标记 {{n}} · 怪物 {{m}}",
			guideSymbols: "房间图标",
			guideItem: "牛骨：抽取物品。通常公开持有并按牌面使用。",
			guideOmen: "渡鸦：抽取预兆。作祟前还须进行作祟检定；“归家见恶”改为抽遭遇。",
			guideEvent: "螺旋：抽取并结算事件。",
			guideComponents: "物品、预兆与特殊房间",
			guideRoom: "房间",
			uiTreasureScore: "宝藏总分：{{n}}",
			counterTraitorWords: "叛徒剩余词语",
			counterHeroWords: "英雄剩余词语",
			counterBloodSupply: "剩余血液",
			counterRunesRequired: "所需符文",
			counterHeroScore: "英雄得分",
			counterSpiritScore: "幽灵得分",
			counterScoreTarget: "获胜分数",
			counterFireSupply: "剩余火焰",
			counterDogFood: "恶魔犬已吃食物",
			counterFlamesRemaining: "尚待出现的妖精之焰",
			counterOrnamentSupply: "装饰物总数",
			counterToyTarget: "需要驱逐的玩具",
			counterBanished: "已驱逐玩具",
			counterFoodRemaining: "剩余女巫食物",
			counterGhostReserve: "可召唤幽灵",
			counterMessagesRemaining: "剩余邮件",
			counterReconciled: "已和解幽灵"
		},
		en: {
			uiWeddingStalemate: "All heroes are dead, and the traitor is bound to the altar, unable to retrieve the distant Ring. Neither side can complete its objective; no one wins.",
			name: "Betrayal at House on the Hill: Third Edition",
			desc: "Explore the house until a haunt reveals your fate",
			chooseDamageType: "Choose the type of this damage",
			keepDamageType: "Take the original damage type",
			useBrooch: "Use the Brooch to take General damage",
			allocateDamage: "Allocate {{n}} remaining damage",
			lowerTrait: "Lower this trait by 1",
			raiseTrait: "Gain 1 in this trait",
			chooseRoll: "Choose how to make this roll",
			rollTrait: "Make this roll",
			rollFlashlight: "Roll 2 extra dice with the Flashlight",
			useFeather: "Bury the Angel’s Feather to choose a result",
			acceptRoll: "Accept the result",
			rerollDie: "Reroll this die with the Rabbit’s Foot",
			useLuckyCoin: "Reroll all blanks with the Lucky Coin",
			useCreepyDoll: "Reroll all dice with the Creepy Doll",
			reviewRoll: "Roll result: {{n}}",
			featherResult: "Use this result",
			chooseFeatherResult: "Choose a raw result from 0 to 8",
			cancel: "Cancel",
			accept: "Accept",
			decline: "Decline",
			eventDecision: "Choose whether to use the optional event effect",
			acceptEvent: "Use the optional effect",
			declineEvent: "Decline the optional effect",
			chooseTraitRoll: "Choose a trait for the roll",
			chooseJonah: "Bury a non-weapon Item or take damage",
			buryCard: "Bury this card",
			takeMentalDie: "Take 1 die of Mental damage",
			chooseGhost: "Choose to bury an Item or make a Sanity roll",
			chooseGain: "Choose a trait to gain",
			chooseTokenRoom: "Choose a room for the token",
			chooseRoom: "Choose a room",
			placeToken: "Place the token",
			moveTo: "Move to this room",
			useItem: "Use this card",
			healExplorer: "Heal this explorer",
			useBook: "Lose 1 Sanity to use Knowledge on the next non-attack trait roll",
			useMask: "Move the other characters here to adjacent rooms",
			tradeWithDog: "Trade with this explorer using the Dog",
			tradeWith: "Trade with this explorer",
			removeFromOffer: "Remove this card from the offer",
			giveCard: "Offer this card",
			requestCard: "Request this card",
			proposeTrade: "Propose this trade",
			prepareTrade: "Choose the cards to give and request",
			acceptTrade: "Accept this trade?",
			useNecklace: "You may gain 1 in a critical trait with the Necklace of Teeth",
			chooseMaskRoom: "Choose a destination for this character",
			throwDynamite: "Throw Dynamite into this room",
			attackWith: "Attack this character with the selected weapon",
			attackUnarmed: "Attack this character unarmed",
			moveThroughWall: "Move through this wall with the Skeleton Key",
			discoverDirection: "Discover through this doorway",
			chooseDiscoveredTile: "Keep the discovered room?",
			keepTile: "Keep this room",
			buryTile: "Bury this room and discover another",
			chooseRotation: "Choose the new room’s orientation",
			rotateTile: "Place in this orientation",
			placeRoomAt: "Place the room outside this doorway",
			placeRequiredRoom: "Place the required room",
			chooseEventDraw: "Choose whether to draw an Event",
			drawEvent: "Draw the Event",
			skipEvent: "Skip the Event",
			chooseCardToKeep: "Choose one card to keep",
			keepCard: "Keep this card",
			useElevator: "Use the Mystic Elevator?",
			rideElevator: "Roll to use the elevator",
			stayHere: "Stay here",
			chooseItemToBury: "Choose an Item to bury",
			adjustHouseForPlacement: "Adjust a room to make a connected doorway for the required tile",
			moveElevatorTo: "Move the elevator outside the {{direction}} doorway",
			chooseElevatorDoor: "Choose an elevator doorway",
			chooseCharacter: "Choose an explorer",
			selectCharacter: "Choose this character",
			chooseFirst: "Choose the explorer whose birthday comes next",
			firstPlayer: "This explorer takes the first turn",
			takeTurn: "Choose an action",
			endTurn: "End turn",
			lootCard: "Take this card from the corpse",
			errNotYourTurn: "You cannot take this action now",
			errBadChoice: "This choice is no longer available",
			logGain: "Gained {{n}} in a trait",
			logLose: "Lost {{n}} in a trait",
			logTrade: "Transferred a card",
			logRoll: "Rolled {{n}}",
			logEvent: "Resolved an Event",
			logUse: "Used a card",
			logAttack: "Combat margin: {{n}}",
			logMonsterKilled: "Killed a monster",
			logMonsterStunned: "Stunned a monster",
			logHeal: "Healed {{n}} trait steps",
			logMove: "Moved to a room",
			logDiscover: "Discovered a room",
			logNoTile: "No room could be placed",
			logEmptyDeck: "This deck is empty",
			logDraw: "Drew a card",
			logDeath: "An explorer died",
			logDamage: "Took {{n}} damage",
			logEncounter: "Resolved a Pennywise Encounter",
			logTurn: "Turn {{n}} begins",
			logHaunt: "The haunt begins",
			chooseDelivery: "Choose an explorer to receive the gift",
			giveDelivery: "Give the Item and move to their room",
			chooseEncounterTrait: "Make the Encounter roll",
			acknowledgeHaunt: "Continue after reading your objective",
			hauntBegins: "The haunt begins. Read your objective",
			chooseTokenRecipient: "Choose who receives the token",
			giveTokenTo: "Give the token to this explorer",
			finishMonster: "Finish this monster’s turn",
			monsterAction: "Choose a monster action",
			stalkPrey: "Stalk the prey from this room",
			learnJack: "Learn about Jack",
			studyExorcism: "Study the exorcism",
			exorciseJack: "Exorcise Jack’s Spirit",
			placeJackSpirit: "Place Jack’s Spirit in a farthest Omen room",
			chooseCircle: "Choose an Exorcism Circle to move",
			moveCircle: "Move this Circle to your room",
			learnCurse: "Gain Knowledge of the Curse",
			cleanseRoom: "Cleanse this room",
			prepareWard: "Prepare a Ward of Protection",
			freeRealtor: "Perform the ritual to free the realtor",
			moveRealtor: "Choose how to move the Demon Realtor",
			stopMoving: "Stop moving",
			playPeekaboo: "Play Peekaboo with these Cherubs",
			placeCherub: "Place a Stone Cherub",
			destroyRing: "Destroy the Ring",
			ringCounterPrompt: "You may reveal yourself and move the heroes before the Ring is destroyed",
			revealAndDisplace: "Reveal yourself and send the heroes to Landing tiles",
			allowRingDestroyed: "Allow the Ring to be destroyed",
			chooseLandingForHero: "Choose a Landing tile for this hero",
			timeLoopReturn: "Return to a Landing or stay and take 2 Mental damage",
			stayAndTakeMental: "Stay here and take 2 Mental damage",
			searchDustCure: "Search for a cure",
			cureDust: "Cure the Dust",
			controlImpulses: "Request a random Sickness token swap",
			acceptSicknessSwap: "Agree to swap one random Sickness token?",
			privateDecision: "A private decision is being resolved",
			lootToken: "Take this token from the corpse",
			breakMirrorSpell: "Try to break the spell with this trait and Omen",
			chooseMirrorClue: "Choose this Event as a clue",
			mirrorCluePrompt: "You may communicate only by giving Event cards as clues",
			chooseClueRecipient: "Choose who receives the clue",
			sendClue: "Give the clue to this hero",
			logMirrorClue: "Received a clue from the Mirror Realm",
			logMirrorRejected: "This combination did not break the spell",
			cleanHouse: "Clean the House",
			chooseRoomFloor: "Choose a floor for the room",
			placeRoomOnFloor: "Place the room on this floor",
			placeHousekeeper: "Place a Housekeeper",
			takeEvidence: "Pick up the Evidence",
			uncoverTruth: "Uncover the Truth",
			revealIdentity: "Reveal your identity",
			placeEvidence: "Place Evidence on separate tiles, with each pair in different regions",
			searchShelves: "Search the Shelves",
			chooseStealOrDamage: "Choose to steal or deal damage",
			stealIdol: "Steal the Idol instead of dealing damage",
			dealCombatDamage: "Deal the combat damage",
			buryForAttack: "You may bury any number of Items to add 1 per Item to this attack",
			makeAttack: "Make the attack",
			searchTreasure: "Search for Treasure",
			stealRandomTreasure: "Steal a random Treasure instead of dealing damage",
			takeTreasurePrompt: "Choose a Treasure to take",
			peekTreasurePrompt: "Choose a Treasure to inspect",
			takeTreasure: "Take this Treasure",
			peekTreasure: "Secretly inspect this Treasure",
			logTreasureValue: "This Treasure is worth {{n}}",
			rummageFood: "Rummage for Food",
			stealFood: "Steal Food from the Larder",
			stealCard: "Steal this card instead of dealing damage",
			combineHands: "Combine both Hands for a Might 8 attack",
			carryCorpse: "Carry this corpse",
			feedSleeper: "Feed Her",
			studyRitual: "Study the Ritual",
			disruptRitual: "Disrupt the Ritual",
			burnBook: "Destroy the Spellbook in the fire",
			hastenSpell: "Hasten the Spell",
			rebornFurniture: "Choose Furniture to emerge from",
			rebornHere: "Remove this Furniture and emerge here",
			giveBookNearest: "Give the Book to a nearest hero",
			searchWeapons: "Search for Weapons",
			attackGhostSymbol: "Attack the Ghost with the Holy Symbol",
			sayBoo: "Say “Boo!”",
			slurp: "Slurp!",
			howl: "Howl!",
			chooseMonsterOrder: "Choose the next monster to act",
			takeMonsterTurn: "Take a turn with this monster",
			moveFrightenedHero: "Choose how to move the frightened hero",
			repeatHowl: "You may repeat the attack against another hero here",
			stopAttacking: "Stop attacking",
			breakThrough: "Break through to a touching room with a hero",
			unearthRemains: "Unearth and carry these Remains",
			identifyRemains: "Identify these Remains",
			consecrateRemains: "Consecrate the Caretaker’s Remains",
			placeRemains: "Secretly place Remains number {{n}}",
			placeAngryGhost: "Place an Angry Ghost in a room without a hero",
			attackSanity: "Make a Sanity attack",
			researchGremlins: "Do research on your phone",
			chooseGremlinRune: "Choose a Gremlin to mark with a Rune",
			markGremlin: "Place a Rune on this Gremlin",
			logMessageDie: "{{actor}} receives a “DIE” message",
			logMessageX: "{{actor}} receives an “X” message",
			teleportGremlinAttack: "Teleport and attack with this Gremlin",
			chooseGremlinAttack: "Choose up to two unstunned Gremlins to attack",
			destroyTape: "Destroy this Videotape",
			staveCurse: "Stave off the Curse",
			placeVideotape: "Place a Videotape as far from heroes as possible",
			placeVengefulSpirit: "Place the Vengeful Spirit in a room with a Videotape",
			findSyllable: "Find the next Syllable",
			chooseSyllableRoom: "Secretly choose the room for Syllable {{n}}",
			logSyllableFound: "{{actor}} finds Syllable {{n}}",
			logSyllableDistance: "The next Syllable is on this floor, {{n}} normal doorway moves away; −1 means no connected route",
			logSyllableWrongFloor: "The next Syllable is on another floor",
			summonIllusions: "Summon Illusions and end your turn",
			confrontIllusion: "Confront this Illusion",
			callRing: "Call to the Ring",
			placeIllusion: "Secretly place Illusion number {{n}}",
			chooseIllusionDispel: "Choose an Illusion to dispel",
			dispelIllusion: "Dispel this Illusion",
			chooseIllusionOrder: "Choose the next Illusion to act",
			activateIllusion: "Take a turn with this Illusion",
			illusionAction: "Choose an action for this Illusion",
			finishIllusion: "Finish this Illusion’s turn",
			logIllusionDispelled: "Illusion {{n}} is dispelled",
			returnBookSpooky: "Return the Book to Spooky",
			burnManuscript: "Burn the Book",
			attackHorrorTrait: "Attack the Horror with this trait",
			buildCharacter: "Build Character",
			ghostwrite: "Ghostwrite for this room",
			createDiversion: "Create a diversion in the Basement",
			escapeHouse: "Escape the House",
			studyFloorPlan: "Study the Floor Plan",
			inspectBasementTile: "Secretly inspect the next Basement tile",
			returnTileTop: "Return the tile to the top",
			shiftBlueprint: "Shift the Blueprint for this hero’s room",
			turnOffMachine: "Turn the Machine Off",
			wreckHouse: "Wreck the House",
			turnOnLasers: "Turn on the Lasers",
			placeCircuit: "Distribute the circuits as evenly as possible across floors",
			chooseRobotStun: "Choose a Robot on this floor to stun",
			stunRobot: "Stun this Robot",
			chooseRoomRelocation: "Choose a new position and rotation for the room",
			relocateRoom: "Move to ({{x}}, {{y}}), rotated {{rotation}}°",
			attackSpeed: "Make a Speed attack",
			dropFlame: "Drop this Seelie Flame",
			pickFlame: "Pick up this Seelie Flame",
			chooseDanceDamage: "You may move both figures instead of dealing damage",
			moveDanceFigures: "Move both figures",
			stepDance: "Step the Dance Eternal",
			chooseDanceHero: "Choose a hero on the Dark Queen’s floor",
			moveDanceHero: "Move this hero",
			findIngredient: "Find this Spell Ingredient",
			breakArmorSpell: "Break the Armor’s Spell",
			chooseCombatReward: "Choose the result of the successful attack",
			adjustHouseForDiscovery: "Choose a minimal connected adjustment that leaves an open doorway for discovery",
			useHiddenPassages: "Use Hidden Passages to reach this room",
			ruinTribute: "Ruin the Tribute",
			pruneFamily: "Prune the Family Tree",
			destroyAltar: "Destroy the Altar",
			placeAltar: "Choose a Ground Floor room for the Altar",
			placeRelative: "Choose a separate Omen room for a Relative",
			chooseRelativeRemove: "Choose a Relative to remove",
			removeRelative: "Remove this Relative",
			spreadWord: "Spread the Word",
			learnLanguage: "Learn the Language",
			rerollAlienDice: "Use Knowledge of Aliens to reroll dice {{dice}}",
			chooseHeroDieRemove: "Choose a hero’s die to remove",
			removeHeroDie: "Remove this die",
			logHeroDieRemoved: "The Alien Words remove one of {{actor}}’s dice",
			chooseWordRoom: "Choose an adjacent room for an Alien Word",
			searchExplosives: "Search for Explosives",
			feedExplosives: "Force Explosives down the Shark’s Throat",
			chooseFloodRoom: "Choose a room to Flood",
			floodRoom: "Flood this room",
			cueOminousMusic: "Cue Ominous Music and move here",
			chooseExplosivesSpend: "Choose how many Explosives to discard",
			spendExplosives: "Discard {{n}} Explosives for a result of {{total}}",
			rendIron: "Rend Iron",
			learnFae: "Learn about the Fae",
			bindFae: "Bind the Fae",
			logOmenRevealed: "{{actor}} reveals {{id}}",
			compelSpirit: "Reveal the Ring and compel the Spirit",
			performCeremony: "Perform the Ceremony",
			chooseOmenReveal: "You may permanently reveal one of the target hero’s Omens",
			revealOmenBack: "Reveal facedown Omen {{n}}",
			skipOmenReveal: "Continue the attack without revealing an Omen",
			distributeSecretOmen: "Secretly choose who holds {{card}}",
			giveSecretOmen: "Give this Omen to this hero",
			placeWeddingParty: "Choose an Omen room for the Wedding Party",
			dispelCurse: "Dispel the Curse and take this card",
			channelSpirit: "Channel this Cursed Spirit",
			attackTrait: "Attack unarmed with the selected trait",
			speakSpirits: "Take 1 die of General damage to Speak with the Spirits",
			stealOrDamage: "Choose to deal damage or steal a card",
			dealDamage: "Deal this attack’s damage",
			chooseCursedCard: "Choose an Item or Omen to curse",
			selectCursedCard: "Curse this card",
			chooseCursedRoom: "Choose a room for this Cursed Item",
			chooseDamageTarget: "Choose a hero to take damage",
			damageHero: "Deal damage to this hero",
			distractCat: "Bury the selected card to distract this Undead Cat",
			burnRoom: "Set this room on fire",
			summonCat: "Summon an Undead Cat",
			chooseCatRoom: "Choose a room for this Undead Cat",
			smashCamera: "Smash the Magic Camera",
			takePhoto: "Take a Photo of this hero’s Essence",
			choosePhotographerRoom: "Choose a room for this Phantom Photographer",
			summonSlugs: "Summon two Slugs",
			findSalt: "Find Salt",
			destroyNest: "Destroy a Nest",
			pickUpSalt: "Pick up this Salt",
			chooseNestRoom: "Choose a room for the Nest",
			chooseSaltSpend: "Choose how much Salt to discard",
			spendSalt: "Discard {{n}} Salt for a result of {{total}}",
			consumeGhost: "Consume a Ghost",
			reconcileGhost: "Find Reconciliation",
			metamorphSubject: "Metamorph this Subject and end your turn",
			uploadDna: "Upload this body’s DNA Sample",
			messCircuits: "Mess with Circuits to attack this Security Robot with Knowledge",
			attemptEscape: "Attempt an Escape",
			chooseRobotTarget: "Choose a hero for this Robot to pursue",
			pursueHero: "Pursue this hero",
			findChristina: "Search for Christina",
			leapFaith: "Make a Leap of Faith",
			manipulatePain: "Manipulate the Dimension to damage and move each hero",
			manipulateGain: "Manipulate the Dimension to gain 2 in a trait",
			manipulateRoom: "Manipulate the Dimension to move this room",
			callOffParty: "Call off the Party",
			chooseNeighborRoom: "Choose a room for the Neighbor",
			pickUpEgg: "Pick up this Wasp Egg",
			destroyEggs: "Attempt to destroy all Wasp Eggs you carry",
			defendSwarm: "Sacrifice this Worker Wasp to deal 1 die of Physical damage to this hero",
			layEgg: "Lay an Egg in this corpse",
			chooseEggRoom: "Choose a room for this Wasp Egg",
			protectFamily: "Protect Your Family by awakening this stunned Evil Twin",
			scryTwin: "Consult the Crystal Ball",
			attackTraitNamed: "Attack this hero with {{trait}}",
			chooseTwin: "Choose an Evil Twin to stun",
			stunTwin: "Stun this Evil Twin",
			stealMask: "Steal the Mask",
			reactivateGenerator: "Reactivate the Generator",
			disableTrap: "Disable the selected Trap",
			sabotageElectronics: "Sabotage Electronics",
			overloadGenerator: "Overload the Generator",
			possessElectronics: "Possess Electronics to place a Trap here",
			twistHallways: "Twist Hallways to move an explorer",
			chooseGeneratorRoom: "Choose a room for the Generator",
			favoritePlaces: "Visit the Gang’s Favorite Places and heal all traits",
			exorciseSpirit: "Exorcise the Spirit",
			grabBite: "Grab a Bite to Eat from the Larder",
			offerDogFood: "You may give the Dog a Food token to subtract 4 from this attack’s result",
			feedDog: "Give the Dog Food to subtract 4 from its attack result",
			hideWolf: "Hide from the Werewolf",
			charmWolf: "Charm the Beast",
			revealHidden: "Reveal this Hidden hero",
			curseEnemies: "Curse this Enemy",
			communeWolves: "Commune with Wolves to move the Werewolf one tile and attack",
			setFire: "Attempt to set this room on Fire",
			chooseMannequinRoom: "Choose a Landing for the Mannequin",
			chooseBurnRoom: "Choose a room for the fire to spread to",
			stealScript: "Steal the Script",
			rewriteScript: "Rewrite the Script",
			chooseCardToBury: "Choose an Item or Omen to bury",
			chooseExplorer: "Choose an explorer",
			moveExplorer: "Move this explorer",
			learnHairCurse: "Learn about the Curse",
			discoverAntidote: "Make a Discovery and take the real Antidote if found",
			shiftHair: "Shift Hair to swap with this Small Hair Monster",
			chooseAntidoteRoom: "Choose a room for this facedown Antidote",
			chooseAntidote: "Choose a facedown Antidote",
			revealAntidote: "Reveal this Antidote",
			knightSanityAttack: "Attack this Trapped hero with Sanity and add 2 to the result",
			knightTrapAttack: "Attack with Might to Trap this hero",
			escapePortal: "Escape the Portal",
			closePortal: "Close the Portal",
			choosePortalRoom: "Choose a farthest room for the Portal",
			reviveHost: "Revive the Host",
			collectBlood: "Collect this hero’s Blood",
			burnContract: "Burn the Contract",
			bloodMagic: "Take 1 die of Mental damage to Perform Blood Magic",
			stealContract: "Steal the Contract from the Demon",
			chooseDemonRoom: "Choose a farthest Basement room for the Demon",
			setExplosive: "Bury the selected card to Set a Makeshift Explosive",
			consumeFlesh: "Consume this corpse’s Flesh",
			consumeRoom: "Consume this room",
			chooseExplosiveToMove: "Choose an Explosive to move here",
			moveExplosiveHere: "Move this Explosive here",
			chooseConstructTeleport: "You may teleport to a hero’s room and lose your remaining movement",
			searchSilver: "Search for a Silvered Item",
			herdHero: "Choose an adjacent room to herd this damaged hero into",
			shareFeeding: "Share in the Feeding: discard a Blood token and heal all traits",
			sanctifyArea: "Sanctify the Area",
			prepareAltar: "Prepare the Altar in this sanctified room",
			driveVampireBack: "Choose a tile without heroes for the stunned Vampire",
			revealHunter: "Reveal yourself as the traitor, heal all traits, and gain 1 in each trait",
			interrogate: "Interrogate this explorer",
			logInterrogate: "{{actor}} secretly learned that {{target}} has number {{n}}",
			forceChange: "Take 1 die of Mental damage to Force the Change into a werewolf",
			prepareWerewolf: "Prepare for the Werewolf using this trait",
			saveWerewolf: "Attempt to Save the Werewolf in human form",
			chooseFloor: "Choose a floor",
			blockHero: "Block this hero",
			catchIdol: "Catch the Idol",
			scoreIdol: "Bring the Idol to the Altar to Score",
			passIdol: "Do you agree to pass the Idol?",
			twistDarkness: "Twist the Darkness to move this explorer",
			grabBell: "Grab a Bell That Tolls for Me",
			stopBellMusic: "Stop the Music by leaving this Bell in the Soundproofed Room",
			rockAround: "Rock Around to grow Mistletoe Kudzu in this room",
			rustleAround: "Rustle Around in the Mistletoe Kudzu",
			createOrnament: "Attempt to Create an Ornament from this card",
			trimTree: "Attempt to Trim the Tree with this Ornament",
			reviveTree: "Choose a Mistletoe Kudzu to remove and revive there",
			reviveHere: "Remove this monster and revive here",
			kissDeath: "Make a Speed attack with the Kiss of Death",
			chooseKissEffect: "Choose to deal damage or grow one Mistletoe Kudzu",
			growKudzuHere: "Grow Mistletoe Kudzu in this room",
			choosePlantRoom: "Choose a room for this plant monster",
			chooseDeck: "Choose a deck to draw from",
			drawFromDeck: "Draw a card from this deck",
			gazeHorror: "Make a Knowledge attack with the Gaze of Ho-Ho-Horror",
			takeOfferingFood: "Pick up this Food offering",
			makeOffering: "Leave this Food in the room as an Offering",
			niceGift: "Give {{card}} to {{player}} and remove all Coal Creatures in the room",
			scroungeFood: "Scrounge Up More Food",
			divideFood: "Choose whether to place this Food in the Kitchen or Larder",
			gazeCoalOffer: "You may bury one Item to place a Coal Creature in the target’s room",
			chooseCoal: "Choose a Coal Creature to move",
			moveCoal: "Move this Coal Creature to the target room",
			findPresent: "Find a Present",
			mineMine: "Mine! Mine! MINE! Draw an Omen facedown",
			buryForPresents: "Choose an Item to bury so there are enough cards to set up the presents",
			passWish: "Choose a surviving hero to receive this gift number",
			choosePresent: "Choose a set-aside present or draw the top Item",
			takePresent: "Take this present and reveal its number",
			drawItem: "Draw the top Item card",
			boostKrampusRoll: "You may bury facedown Items or Omens to add one die each",
			buryHiddenBoost: "Bury this facedown card to add one die",
			rollWithBoost: "Roll with {{n}} additional dice",
			stealPresent: "You may take an Item that does not match the hero’s number",
			stealItem: "Take this Item",
			toyExplore: "Let this Toy explore beyond this doorway",
			carryToy: "Pick up this stunned Toy",
			banishMischief: "Banish Mischief from this carried Toy",
			chooseToyCard: "Choose an Item or Omen to become a Mischievous Toy",
			chooseThisCard: "Choose this card",
			chooseToyRoom: "Choose a room for this Mischievous Toy",
			chooseFarthestToyRoom: "Choose a farthest room for the Toy to become unstunned",
			lookForWeapon: "Look for a Weapon",
			banishHockstetter: "Banish Zombie Hockstetter",
			hockGuard: "You may redirect this attack to Hockstetter in your room",
			redirectHock: "Redirect the attack to Hockstetter",
			callHock: "You may move Hockstetter up to three rooms toward you",
			moveHockCloser: "Move Hockstetter toward you",
			hockMoveHenry: "Use Hockstetter’s remaining movement to move Henry",
			hockGiveItem: "Give Henry the top Item card",
			placeHock: "Choose a room with an unexplored doorway for Hockstetter to return",
			healOneTrait: "Choose a trait to heal to its starting value",
			healTrait: "Heal this trait to its starting value",
			findWeakness: "Discover the Monster’s Weakness",
			searchKillIt: "Search for Something to Kill It",
			banishForm: "Make a Sanity attack to Banish this stunned Form",
			moveSearched: "Choose a Searched token to move to the searched room",
			moveTokenHere: "Move this token to the current room",
			recoverForm: "Recover from being stunned and choose movement or attacks this turn",
			recoverMoveOnly: "Only move this turn",
			recoverAttackOnly: "Only attack this turn",
			chooseFormRoom: "Choose a hero’s room for It’s current form",
			placeFormWithHero: "Place It’s current form in this hero’s room",
			shareFormFear: "Choose a hero to take this point of shared Mental damage",
			takeMentalPoint: "Take 1 Mental damage",
			withdrawForm: "No heroes remain on this floor; you may withdraw It’s current form",
			withdrawIt: "Withdraw It’s current form to the supply",
			depositArtifact: "Deposit this Artifact at the Altar",
			completeRitual: "Complete the Ritual of Chüd",
			findArtifactInstead: "You may find an Artifact instead of drawing this room’s card",
			findArtifact: "Find this Artifact",
			drawRoomCard: "Draw this room’s card normally",
			returnRitualRoom: "Choose a ritual room with the least disruption to return to the tile stack",
			returnRoomToDeck: "Return this room to the tile stack",
			tauntPennywise: "Taunt Pennywise",
			crushPennywise: "Crush the stunned Pennywise",
			chooseClownVictim: "Choose a hero in Pennywise’s room for him to attack",
			findWayThrough: "Find a Way Through to connect this group to the main house",
			helpAnotherHero: "Help Another Hero by moving to their room and ending your turn",
			findWayOut: "Find a Way Out together with all surviving heroes",
			chooseTinyToMove: "Choose a Tiny Terror to move to the new room",
			moveTerrorHere: "Move this Tiny Terror to the new room",
			connectRoomGroup: "Choose where to connect this room group to the main house",
			connectThisGroup: "Connect this room group while keeping its internal layout",
			chooseHeroToHelp: "Choose a hero to move to and help",
			moveToHero: "Move to this hero’s room",
			chooseTinyVictim: "Choose a hero for this group of Tiny Terrors to attack",
			moveUnseenHorror: "You may move to another room outside every hero’s line of sight",
			rules: "Setup and objective:\nChoose one Scenario. The five base Scenarios use the base components. Howl at the Moon, The Holiday House, and Come Home to Evil each use their matching expansion; the three expansions are not mixed. Each player chooses a different character color. Howl at the Moon requires Sara; The Holiday House requires the Elf or Jingleklaws. Choose the explorer whose birthday comes next as first player, then follow seat order.\nFirst explore together. The haunt then assigns teams and objectives: usually heroes against a traitor, but some haunts have a hidden traitor, cooperation, or individual winners. Haunt rules and objectives take precedence over the basic rules.\nCharacter traits:\nMight and Speed are Physical traits; Sanity and Knowledge are Mental traits. A marker position determines the trait value. Gaining or losing a trait moves the marker by spaces, rather than adding to or subtracting from its printed value. Healing raises a trait below its green starting position to that position, leaving higher traits unchanged. The leftmost numbered space is critical; one space below it is the skull.\nTurns and movement:\nStart your turn with movement equal to your current Speed value. Later Speed changes do not recalculate it. Moving through a connected doorway normally costs 1. Leaving a room containing an opponent or Obstacle costs 1 extra; multiple opponents and Obstacles do not stack. You may move before or after legal Item, trade, or haunt actions, or end your turn early.\nStairs and special routes connect as their room rules describe. Normally you must use matching doors, cannot pass through walls, and cannot climb directly from the Basement Landing to the Ground Staircase. Items, rooms, and haunts may provide exceptions. Inspect rooms and character dossiers for abilities, routes, and critical traits.\nDiscovering rooms:\nMove through an unexplored door and draw a tile for that floor. Choose an orientation connecting the entrance door; its other doors need not match adjacent rooms. Enter it, resolve discovery and entry effects and its symbols, then end your turn. Item, Omen, and Event symbols draw their respective cards; a double symbol draws two. Abilities apply only at their stated times. Reentering an existing room does not normally draw another card.\nItems and Omens:\nItems and Omens are normally held faceup; resolve Events as instructed. Cards provide ongoing abilities or actions. Each card’s special action is normally usable once per turn. Bury means place at the bottom of the matching deck. A card received during this turn cannot be used for its special action or as a weapon until a later turn; ongoing abilities still apply.\nTrading and corpses:\nOnce on your turn, trade with one explorer in your room. Exchange any number of Items, Omens, and tradable tokens, including a one-sided gift, with the other player’s agreement. You may take cards or lootable tokens from corpses in your room, but only one piece from each corpse per turn. Follow any haunt-specific restrictions.\nDice and damage:\nRoll dice equal to the named trait value. Each die shows 0, 1, or 2; sum them and apply modifiers. Legal substitutions, extra dice, and rerolls are offered at the appropriate time. Dice of damage deal their total pips, not their number of dice.\nThe damaged player allocates damage one point at a time: Physical damage lowers Might or Speed, Mental damage lowers Sanity or Knowledge, and General damage can lower any trait. Before the haunt, traits cannot drop to the skull, and while an eligible noncritical trait remains, do not allocate damage to a critical trait. Losing a trait directly is different from damage and does not trigger Armor or other damage reduction.\nHaunt rolls:\nBefore the haunt, after drawing an Omen, roll dice equal to all Omens held by explorers. A total of 5 or more starts the haunt; drawing the last Omen starts it automatically. The drawer is the haunt revealer; the Scenario and triggering Omen determine the haunt. Some Events directly start a named haunt. Before the haunt in Come Home to Evil, Omen room symbols draw Encounters instead, and haunt dice equal the faceup Encounter count.\nAfter the haunt starts:\nComplete the haunt setup and read your own team objective and secret information. Play normally resumes with the explorer to the traitor’s left. A revealed traitor may ignore harmful room effects and decline an Event when discovering an Event room. Hidden traitors follow their haunt’s identity rules. Exploration continues, but ordinary Omen draws no longer cause haunt rolls.\nCombat:\nAfter the haunt, you can normally attack once per turn. An unarmed attack targets an opponent in your room; both roll Might. The higher total wins, and the loser takes Physical damage equal to the difference. Ties cause no damage. Weapons may change the trait, add dice, or allow ranged attacks. Mental trait attacks deal Mental damage. The defender also rolls, and a failed normal melee attack can hurt the attacker.\nThe Gun uses Speed against Speed and attacks within line of sight: a straight row or column through connected doors, without crossing walls or turning. The Crossbow uses Speed with 1 extra die and targets the same or an adjacent connected room. Failed Gun and Crossbow attacks cause no counterattack damage. See each card for costs and detailed abilities.\nMonsters, death, and victory:\nMonsters normally act after the traitor. Roll movement once per monster type; each monster receives that many moves, with a minimum of 1. Each moves and attacks independently and cannot discover rooms. Ordinary monsters are stunned when damaged and skip their next turn; some haunts instead allow them to die or make them immune. Follow the haunt’s traits, actions, and death exceptions.\nAfter the haunt, reaching the skull in any trait kills an explorer unless an Item or haunt replaces death. Dead explorers cannot act; their belongings remain with their corpse, and they may still share their team’s victory. The game ends immediately when a haunt victory condition is met. The investigation report shows the actual winners and allows you to review the house.",
			uiHouse: "The House",
			uiDossier: "Dossier",
			uiInventory: "Items & Omens",
			uiObjective: "Your Objective",
			uiJournal: "Action history",
			uiJournalEmpty: "No actions yet",
			uiClose: "Close",
			uiWait: "Waiting for {{name}}",
			uiResolve: "Resolving",
			uiTurn: "Turn {{n}}",
			uiMovement: "Movement {{n}}",
			uiMusicOn: "Enable music",
			uiMusicOff: "Disable music",
			uiMusicFailed: "Music could not start. Try again.",
			uiFit: "Fit the house",
			uiZoomIn: "Zoom in",
			uiZoomOut: "Zoom out",
			uiPlaceConfirm: "Place room",
			uiPlaceTools: "Room placement",
			uiFloorU: "Upper Floor",
			uiFloorG: "Ground Floor",
			uiFloorB: "Basement",
			uiHero: "Hero",
			uiTraitor: "Traitor",
			uiIndividual: "Every explorer for themselves",
			uiUnknown: "Unrevealed",
			uiDead: "Dead",
			uiStunned: "Stunned",
			uiHidden: "Unrevealed",
			uiCritical: "Critical",
			uiSelected: "Selected",
			uiExplore: "Explore the house",
			uiHaunt: "The Haunt",
			uiScenario: "Scenario",
			uiPackBase: "Third Edition Base Game",
			uiPackBlood: "Blood on the Moon",
			uiPackYuletide: "Yuletide Tale",
			uiPackPennywise: "The Evil of Pennywise",
			uiStranger: "Holiday Stranger",
			uiReport: "House investigation report",
			uiVictory: "You survived the house",
			uiDefeat: "The house claimed you",
			uiWinners: "Winners",
			uiNoWinners: "The house claimed everyone",
			uiReview: "Inspect the house",
			uiShowReport: "Show report",
			uiAgain: "Play again",
			uiLobby: "Back to lobby",
			uiConfirmAgain: "Start another game? This review will close.",
			uiConfirmLobby: "Return to the lobby? This review will close.",
			uiHostWait: "Waiting for the host",
			uiObject: "Object",
			uiTrack: "Number Track",
			uiDice: "Dice roll",
			uiResult: "Result {{n}}",
			uiNoCards: "No Items or Omens yet",
			uiRules: "Read rules",
			uiDoor: "Explore the {{direction}} doorway",
			uiN: "north",
			uiE: "east",
			uiS: "south",
			uiW: "west",
			uiRotation: "Rotate {{n}}°",
			uiRoomChoice: "{{action}}: {{name}}",
			uiBirthday: "Birthday {{date}} · Age {{n}}",
			uiUnknownBirthday: "Birthday unknown",
			uiHiddenNumber: "Secret number",
			uiOwnedTokens: "Carried tokens",
			uiConditionWrecked: "Wrecked",
			uiConditionFlooded: "Flooded",
			uiConditionBurning: "Burning",
			uiConditionConsumed: "Consumed",
			uiOutcome: "{{name}} · {{team}}",
			label_conservatory: "Conservatory",
			label_armory: "Armory",
			label_bloodyRoom: "Bloody Room",
			label_catacombs: "Catacombs",
			label_charredRoom: "Charred Room",
			label_ritualRoom: "Ritual Room",
			label_kitchen: "Kitchen",
			label_ballroom: "Ballroom",
			label_junkRoom: "Junk Room",
			label_panicRoom: "Panic Room",
			label_laundryChute: "Laundry Chute",
			label_laboratory: "Laboratory",
			label_chapel: "Chapel",
			label_soundproofedRoom: "Soundproofed Room",
			label_salon: "Salon",
			label_specimenRoom: "Specimen Room",
			label_secretStaircase: "Secret Staircase",
			label_library: "Library",
			label_undergroundLake: "Underground Lake",
			label_statuaryCorridor: "Statuary Corridor",
			label_nursery: "Nursery",
			label_tower: "Tower",
			label_crawlspace: "Crawlspace",
			label_operatingTheatre: "Operating Theatre",
			label_gameRoom: "Game Room",
			label_larder: "Larder",
			label_observatory: "Observatory",
			label_diningRoom: "Dining Room",
			label_gymnasium: "Gymnasium",
			label_undergroundCavern: "Underground Cavern",
			label_organRoom: "Organ Room",
			label_vault: "Vault",
			label_primaryBedroom: "Primary Bedroom",
			label_winterBedroom: "Winter Bedroom",
			label_mysticElevator: "Mystic Elevator",
			label_chasm: "Chasm",
			label_gallery: "Gallery",
			label_crampedPassageway: "Cramped Passageway",
			label_graveyard: "Graveyard",
			label_furnaceRoom: "Furnace Room",
			label_guestQuarters: "Guest Quarters",
			label_collapsedRoom: "Collapsed Room",
			label_groundStaircase: "Ground Staircase",
			label_hallway: "Hallway",
			label_entranceHall: "Entrance Hall",
			label_upperLanding: "Upper Landing",
			label_basementLanding: "Basement Landing",
			label_oubliette: "Oubliette",
			label_trophyRoom: "Trophy Room",
			label_timeLostTree: "Time Lost Tree",
			label_rootCellar: "Root Cellar",
			label_ancientDen: "Ancient Den",
			label_windingTunnels: "Winding Tunnels",
			label_darkenedHallway: "Darkened Hallway",
			label_oldWell: "Old Well",
			label_isa: "Isa Valencia",
			label_anita: "Anita Hernandez",
			label_jaden: "Jaden Jones",
			label_sammy: "Sammy Angler",
			label_oliver: "Oliver Swift",
			label_josef: "Josef “Brosef” Hooper",
			label_warren: "Father Warren Leung",
			label_dan: "Dan Nguyen, M.D.",
			label_persephone: "Persephone Puleri",
			label_stephanie: "Stephanie Richter",
			label_brittani: "Brittani “Beat Box” Bowen",
			label_michelle: "Michelle Monroe",
			label_sara: "Sara Nguyen",
			label_werewolf: "Werewolf",
			label_elf: "The Elf",
			label_jingleklaws: "Jingleklaws",
			label_machete: "Machete",
			label_crossbow: "Crossbow",
			label_firstAidKit: "First Aid Kit",
			label_mirror: "Mirror",
			label_angelsFeather: "Angels Feather",
			label_strangeMedicine: "Strange Medicine",
			label_mysticalStopwatch: "Mystical Stopwatch",
			label_skeletonKey: "Skeleton Key",
			label_strangeAmulet: "Strange Amulet",
			label_dynamite: "Dynamite",
			label_magicCamera: "Magic Camera",
			label_headphones: "Headphones",
			label_gun: "Gun",
			label_rabbitsFoot: "Rabbits Foot",
			label_flashlight: "Flashlight",
			label_luckyCoin: "Lucky Coin",
			label_map: "Map",
			label_necklaceOfTeeth: "Necklace Of Teeth",
			label_brooch: "Brooch",
			label_leatherJacket: "Leather Jacket",
			label_chainsaw: "Chainsaw",
			label_creepyDoll: "Creepy Doll",
			label_dog: "Dog",
			label_book: "Book",
			label_dagger: "Dagger",
			label_ring: "Ring",
			label_armor: "Armor",
			label_idol: "Idol",
			label_holySymbol: "Holy Symbol",
			label_skull: "Skull",
			label_mask: "Mask",
			label_fangBracelet: "Fang Bracelet",
			label_wolfsbane: "Wolfsbane",
			label_unusualCake: "Unusual Cake",
			label_snowGlobe: "Snow Globe",
			label_hiddenOmen: "Hidden Omen",
			label_might: "Might",
			label_speed: "Speed",
			label_sanity: "Sanity",
			label_knowledge: "Knowledge",
			label_dice: "Dice",
			label_physical: "Physical",
			label_mental: "Mental",
			label_general: "General",
			label_item: "Item",
			label_item2: "Item2",
			label_omen: "Omen",
			label_event: "Event",
			label_event2: "Event2",
			label_paranormalInvestigators: "Paranormal Investigators",
			label_strangeDisappearance: "Strange Disappearance",
			label_forSale: "For Sale",
			label_mysteriousInvitation: "Mysterious Invitation",
			label_cursed: "Cursed",
			label_howlAtTheMoon: "Howl At The Moon",
			label_holidayHouse: "Holiday House",
			label_comeHomeToEvil: "Come Home To Evil",
			label_blessing: "Blessing",
			label_secretPassage: "Secret Passage",
			label_alienWord: "Alien Word",
			label_knowledgeOfAliens: "Knowledge Of Aliens",
			label_packWolf: "Pack Wolf",
			label_silverRune: "Silver Rune",
			label_vampireMaster: "Vampire Master",
			label_vampireBlood: "Vampire Blood",
			label_sanctified: "Sanctified",
			label_vampireAltar: "Vampire Altar",
			label_hunterNumber: "Hunter Number",
			label_phaseSupply: "Phase Supply",
			label_phaseTrait: "Phase Trait",
			label_sportNest: "Sport Nest",
			label_spectralIdol: "Spectral Idol",
			label_sportAltar: "Sport Altar",
			label_ghostAdversary: "Ghost Adversary",
			label_blockingSpirit: "Blocking Spirit",
			label_dna: "Dna",
			label_securityRobot: "Security Robot",
			label_essence: "Essence",
			label_photographer: "Photographer",
			label_bakeneko: "Bakeneko",
			label_undeadCat: "Undead Cat",
			label_fire: "Fire",
			label_treasure: "Treasure",
			label_construct: "Construct",
			label_makeshiftExplosive: "Makeshift Explosive",
			label_heroBlood: "Hero Blood",
			label_contractDemon: "Contract Demon",
			label_infernalContract: "Infernal Contract",
			label_mirrorBeing: "Mirror Being",
			label_housekeeper: "Housekeeper",
			label_cleanedRoom: "Cleaned Room",
			label_cursedItem: "Cursed Item",
			label_demonicDog: "Demonic Dog",
			label_exorcisedSpirit: "Exorcised Spirit",
			label_dogFood: "Dog Food",
			label_christina: "Christina",
			label_jackSpirit: "Jack Spirit",
			label_exorcismCircle: "Exorcism Circle",
			label_demonRealtor: "Demon Realtor",
			label_cleansedFire: "Cleansed Fire",
			label_wardOfProtection: "Ward Of Protection",
			label_stoneCherub: "Stone Cherub",
			label_relative: "Relative",
			label_elder: "Elder",
			label_evilTwin: "Evil Twin",
			label_gardenFae: "Garden Fae",
			label_coldIron: "Cold Iron",
			label_knowledgeOfFae: "Knowledge Of Fae",
			label_giantHair: "Giant Hair",
			label_smallHair: "Small Hair",
			label_antidote: "Antidote",
			label_dustResearch: "Dust Research",
			label_feverish: "Feverish",
			label_evidence: "Evidence",
			label_giantWasp: "Giant Wasp",
			label_workerWasp: "Worker Wasp",
			label_waspEgg: "Wasp Egg",
			label_headOfHouse: "Head Of House",
			label_illusion: "Illusion",
			label_circuit: "Circuit",
			label_robotAssistant: "Robot Assistant",
			label_trappedHero: "Trapped Hero",
			label_knightPortal: "Knight Portal",
			label_machineTrap: "Machine Trap",
			label_generator: "Generator",
			label_theHouse: "The House",
			label_sabotaged: "Sabotaged",
			label_spooky: "Spooky",
			label_horror: "Horror",
			label_coldWarZombie: "Cold War Zombie",
			label_seelieFlame: "Seelie Flame",
			label_faeDancer: "Fae Dancer",
			label_darkQueen: "Dark Queen",
			label_peaceGhost: "Peace Ghost",
			label_formSearched: "Form Searched",
			label_knownWeakness: "Known Weakness",
			label_zombieHockstetter: "Zombie Hockstetter",
			label_henrySearched: "Henry Searched",
			label_henryVictim: "Henry Victim",
			label_tinyTerror: "Tiny Terror",
			label_pennywiseClown: "Pennywise Clown",
			label_pennyTarget: "Penny Target",
			label_personalArtifact: "Personal Artifact",
			label_chudAltar: "Chud Altar",
			label_pennywiseSpider: "Pennywise Spider",
			label_cultist: "Cultist",
			label_ritualKnowledge: "Ritual Knowledge",
			label_animatedFurniture: "Animated Furniture",
			label_seamFire: "Seam Fire",
			label_mannequin: "Mannequin",
			label_ghostShark: "Ghost Shark",
			label_explosive: "Explosive",
			label_slug: "Slug",
			label_slugNest: "Slug Nest",
			label_salt: "Salt",
			label_neighbor: "Neighbor",
			label_remains: "Remains",
			label_angryGhost: "Angry Ghost",
			label_gremlin: "Gremlin",
			label_gremlinRune: "Gremlin Rune",
			label_vengefulSpirit: "Vengeful Spirit",
			label_facelessMan: "Faceless Man",
			label_syllable: "Syllable",
			label_altar: "Altar",
			label_weddingParty: "Wedding Party",
			label_witchFood: "Witch Food",
			label_trollHand: "Troll Hand",
			label_bell: "Bell",
			label_coalCreature: "Coal Creature",
			label_offeringFood: "Offering Food",
			label_giftRune: "Gift Rune",
			label_krampus: "Krampus",
			label_presentWish: "Present Wish",
			label_presentNumber: "Present Number",
			label_presentSearched: "Present Searched",
			label_mischievousToy: "Mischievous Toy",
			label_toyNumber: "Toy Number",
			label_smallToy: "Small Toy",
			label_ornament: "Ornament",
			label_ghost: "Ghost",
			label_vampire: "Vampire",
			label_werewolfMonster: "Werewolf Monster",
			label_zombie: "Zombie",
			label_robot: "Robot",
			label_pennywise: "Pennywise",
			label_pennyClown: "Penny Clown",
			label_pennySpider: "Penny Spider",
			label_hockstetter: "Hockstetter",
			label_fae: "Fae",
			label_spirit: "Spirit",
			label_cherub: "Cherub",
			label_furniture: "Furniture",
			label_food: "Food",
			label_rune: "Rune",
			label_searched: "Searched",
			label_obstacle: "Obstacle",
			label_redBalloon: "Red Balloon",
			label_coal: "Coal",
			label_artifact: "Artifact",
			label_kudzu: "Kudzu",
			label_yuleLog: "Yule Log",
			label_krampusItem: "Krampus Item",
			label_videotape: "Videotape",
			label_krampusOmen: "Krampus Omen",
			label_ingredient: "Ingredient",
			label_hiddenFromWerewolf: "Hidden From Werewolf",
			label_mindControlled: "Mind Controlled",
			label_trappedByKnight: "Trapped By Knight",
			label_secretElevator: "Secret Elevator",
			label_creakingDoor: "Creaking Door",
			label_cryForHelp: "Cry for Help",
			label_momentOfHope: "Moment of Hope",
			label_darkStormyNight: "Dark and Stormy Night",
			label_spiders: "Spiders",
			label_meatMoss: "Meat Moss",
			label_eerieFeeling: "Eerie Feeling",
			label_hangedMen: "The Hanged Men",
			label_poorYorick: "Poor Yorick",
			label_impossibleArchitecture: "Impossible Architecture",
			label_alienGeometry: "Alien Geometry",
			label_bite: "A Bite",
			label_funeral: "A Funeral",
			label_jonahsTurn: "Jonah's Turn",
			label_flickeringLights: "Flickering Lights",
			label_flowering: "Flowering",
			label_fullTable: "A Full Table",
			label_deepestCloset: "The Deepest Closet",
			label_burningFigure: "Burning Figure",
			label_behindYou: "Behind You",
			label_clownRoom: "The Clown Room",
			label_radioBroadcast: "Radio Broadcast",
			label_tinyRobot: "Tiny Robot",
			label_taxidermy: "Taxidermy",
			label_severedHand: "Severed Hand",
			label_phoneCall: "A Phone Call",
			label_batOutOfHell: "Bat Out of Hell",
			label_sayCheese: "Say Cheese",
			label_mysteriousFluid: "Mysterious Fluid",
			label_splashOfCrimson: "A Splash of Crimson",
			label_forbiddenKnowledge: "Forbidden Knowledge",
			label_vialOfDust: "A Vial of Dust",
			label_cassettePlayer: "Cassette Player",
			label_eerieMirror: "Eerie Mirror",
			label_oldestHouse: "The Oldest House",
			label_jarOfOrgans: "A Jar of Organs",
			label_technicalDifficulties: "Technical Difficulties",
			label_wanderingGhost: "Wandering Ghost",
			label_starsAtNight: "Stars at Night",
			label_brainFood: "Brain Food",
			label_houseIsHungry: "The House Is Hungry",
			label_hunt: "The Hunt",
			label_bloodMoon: "Blood Moon",
			label_feast: "The Feast",
			label_gift: "The Gift",
			label_floatingLights: "Floating Lights",
			label_knifeInDark: "Knife in the Dark",
			label_bloodTendrils: "Blood Tendrils",
			label_goodBoy: "That's a Good Boy",
			label_popOfRed: "A Pop of Red",
			label_hometownHorrors: "Hometown Horrors",
			label_swirlingVisions: "Swirling Visions",
			label_stretchingHall: "A Stretching Hall",
			label_timeToSink: "Time to Sink!",
			label_eaterOfWorlds: "The Eater of Worlds",
			label_haunt1: "Stacked Like Cordwood 2: Crimson Jack Returns",
			label_haunt2: "Friends Forever",
			label_haunt3: "The Dust",
			label_haunt4: "Free the Realtor",
			label_haunt5: "Blood from a Stone",
			label_haunt6: "Inheritance",
			label_haunt7: "Upon Reflection",
			label_haunt8: "Housekeeping",
			label_haunt9: "Let Bygones be Bygones",
			label_haunt10: "A Serious Offer",
			label_haunt11: "Don't Get Cooked",
			label_haunt12: "Helping Hands",
			label_haunt13: "Holy Ground",
			label_haunt14: "Object Permanence",
			label_haunt15: "Of Monsters and Mayhem",
			label_haunt16: "Come Play With Us",
			label_haunt17: "Forward This or Die",
			label_haunt18: "A Nice Ring to It",
			label_haunt19: "Caught on Tape",
			label_haunt20: "Don't Say It",
			label_haunt21: "Spooky McMasters Presents...",
			label_haunt22: "Operation: Underground",
			label_haunt23: "Intruder Alert",
			label_haunt24: "The Shadow Masquerade",
			label_haunt25: "Borrowed Time",
			label_haunt26: "The Family's Blessing",
			label_haunt27: "Words from the Stars",
			label_haunt28: "We're Going to Need a Bigger House",
			label_haunt29: "A Beautiful Garden",
			label_haunt30: "'Til Death Do Us Part",
			label_haunt31: "A Ghost of a Chance",
			label_haunt32: "The Catastrophe",
			label_haunt33: "Smile for the Camera",
			label_haunt34: "Down the Hall, Second Dimension on the Right",
			label_haunt35: "Space Slugs",
			label_haunt36: "Finding Peace",
			label_haunt37: "Out of Body",
			label_haunt38: "The Sinister Soiree",
			label_haunt39: "Hive Mind",
			label_haunt40: "Return of the Fleshwalkers",
			label_haunt41: "A God in the Machine",
			label_haunt42: "Snack Attack",
			label_haunt43: "Hide and Eat",
			label_haunt44: "A Missing Seam",
			label_haunt45: "An Audacious Debut",
			label_haunt46: "Ghost Hair",
			label_haunt47: "A Knight to Remember",
			label_haunt48: "Don't Upset the Host!",
			label_haunt49: "Terms and Conditions",
			label_haunt50: "The Taste of Flesh and Metal",
			label_hauntblood1: "Leader of the Pack",
			label_hauntblood2: "House of Darkness",
			label_hauntblood3: "Team Werewolf",
			label_hauntblood4: "The Hunter and the Hunted",
			label_hauntblood5: "Not Just a Phase",
			label_hauntyuletide1: "The House of Mischievous Toys",
			label_hauntyuletide2: "Hell’s Bells",
			label_hauntyuletide3: "‘Tis the Treeson",
			label_hauntyuletide4: "He Knows When You Are Sleeping",
			label_hauntyuletide5: "Krampusnacht",
			label_hauntpennywise1: "Henry on the Hunt",
			label_hauntpennywise2: "Separate Nightmares",
			label_hauntpennywise3: "All Living Things Must Abide",
			label_hauntpennywise4: "The Ritual of Chüd",
			label_hauntpennywise5: "Let’s Kill This Clown",
			objective_1_hero: "At the Library, Knowledge 5+ grants Knowledge of Jack. In Event rooms, Knowledge 5+ prepares Exorcism Circles. With the Spirit, make a Sanity roll, adding 1 per Circle on your floor; 7+ wins. Killing Jack releases his Spirit, which revives him on reaching his corpse.",
			objective_1_traitor: "Kill all heroes. Before attacking, while unseen, Stalk to an unseen Upper or Ground room. After death, return your Spirit to your corpse to revive.",
			objective_2_hero: "The Ring holder attempts Speed or Knowledge, adding 1 per hero in a time-disturbance room. A 7+ destroys the Ring and wins; failure deals 6 General damage and returns you to a Landing. Finish before the countdown ends. A hidden traitor may intervene.",
			objective_2_traitor: "Prevent the Ring’s destruction until the countdown ends, or kill all heroes. Reveal to heal all traits and gain 1 Might.",
			objective_3_hero: "In Omen rooms, Knowledge or Sanity 5+ places Research. At the Laboratory, Operating Theatre, Observatory, or Kitchen, roll any trait to cure the Dust. Add 2 per Research; 13+ wins. Secret Sickness exchanges can change allegiances.",
			objective_3_traitor: "Kill all heroes. Anyone who has ever held Sickness number 1 remains a traitor after passing it away. Death may turn you into a Feverish monster.",
			objective_4_hero: "Work together to free the Demon Realtor. Knowledge 5+ at the Library, Chapel, or Laboratory grants curse knowledge; Speed 6+ in Event rooms cleanses fires. With her, roll Sanity, adding floor fires, curse knowledge, and the Ritual Room bonus. A 13+ wins.",
			objective_4_traitor: "Work together to free the Realtor.",
			objective_5_hero: "Remove all Cherubs. With one in your room and another in line of sight, Knowledge 4+ removes both; a Mirror adds 2. Failure deals 2 dice of General damage. Cherubs cannot be attacked normally, and their gaze is dangerous.",
			objective_5_traitor: "Work together to remove all Cherubs.",
			objective_6_hero: "Kill the hidden traitor. Take Evidence and bring it to another matching trait’s Evidence. Roll that trait 5+ to reveal the highest unrevealed Number. If you made no attack this turn, take 2 dice of Mental damage at turn end.",
			objective_6_traitor: "Kill all heroes. You may reveal to heal all traits and gain 1 Might. While unrevealed, take 2 dice of Mental damage at turn end if you did not attack; death from this damage reveals you instead.",
			objective_7_hero: "Find the room, Omen, and trait that break the mirror spell. Each turn the revealer sends an Event-card clue. A hero with the correct Omen, in the correct room, must roll 5+ using the correct trait.",
			objective_7_traitor: "Use Event-card clues to communicate the secret room, Omen, and trait to the heroes.",
			objective_8_hero: "Clean the Bloody Room, Charred Room, Collapsed Room, Junk Room, and Catacombs. Speed or Sanity 5+ cleans each room. Cleaning all five wins.",
			objective_8_traitor: "Work together to clean the house.",
			objective_9_hero: "Be the last surviving explorer. Knowledge 5+ in Item rooms finds Items. Bury Items before an attack to improve its result. Killing while holding the Idol strengthens it.",
			objective_9_traitor: "Be the last surviving explorer.",
			objective_10_hero: "Have the highest Treasure total after the four-round countdown; ties share victory. In Omen rooms, Knowledge 4+ takes Treasure and 1–3 only peeks. Being at the Ground Floor Staircase at the end adds 2.",
			objective_10_traitor: "Collect the most Treasure before the countdown ends.",
			objective_11_hero: "Be the last survivor. Knowledge 6+ finds Food, with +2 in designated food rooms. Once all Food is taken, explorers without Food die and a new round begins with less Food.",
			objective_11_traitor: "Be the last survivor.",
			objective_12_hero: "Hold the Strange Amulet and be the only survivor. Its holder controls the Troll Hands. A winning Might attack may steal an Item or Omen instead of dealing damage.",
			objective_12_traitor: "Hold the Strange Amulet and be the only survivor.",
			objective_13_hero: "Knowledge 5+ at the Library, Chapel, or Ritual Room grants a Rune. In the Ritual Room, roll Sanity plus carried Runes minus living Cultists; 6+ wins. Killing the traitor and all Cultists also wins.",
			objective_13_traitor: "Carry corpses to the Chasm and sacrifice them with Sanity 7+. Reducing the track to 0 wins; failure gains 2 Sanity. Killing all heroes also wins.",
			objective_14_hero: "Keep the Book until the track reaches 0. Once per round for the whole team, its holder can roll Sanity 5+ to reduce the track by 1; lose 1 Sanity either way. A hero still holding the Book after the monsters also reduces it by 1.",
			objective_14_traitor: "Take the Book and destroy it in the Kitchen, Furnace Room, or Laboratory, or kill all heroes. Furniture lets you revive after death but is consumed.",
			objective_15_hero: "Defeat every monster: use the Holy Symbol in a Sanity attack for Ghosts, the Crossbow for Vampires, and the Dagger for Werewolves. Knowledge 4+ in Item or Omen rooms lets you choose one of the top four cards.",
			objective_15_traitor: "Control your monsters and kill all heroes. Each type has its own movement and attacks.",
			objective_16_hero: "Find Remains number 1 and bury them at the Graveyard with Sanity 5+. Knowledge 5+ identifies Remains in your room. Carried Remains inflict Mental damage at the start of the traitor’s turn.",
			objective_16_traitor: "Use Ghosts and the Remains curse to kill all heroes. Deaths create new Ghosts.",
			objective_17_hero: "Knowledge 5+ at the Tower, Gallery, or Observatory marks a Gremlin with a Rune, making it vulnerable. Kill the traitor and all Gremlins to win. Each turn ends with a dangerous message draw.",
			objective_17_traitor: "Use Gremlins and death messages to kill all heroes.",
			objective_18_hero: "Dispel Illusions and kill the traitor. Knowledge 5+ confronts an Illusion in your room; a Mirror adds 2. At the Vault, Sanity plus your Omen count of 8+ calls to the Ring.",
			objective_18_traitor: "Hide among your Illusions and kill all heroes. Revealing your true form permanently removes the highest-numbered Illusion; you can later summon the rest.",
			objective_19_hero: "Might 4+ destroys a Videotape in your room. After all tapes are destroyed, end a hero turn with any hero at the Entrance Hall to win. A hero with the Spirit may risk a roll to extend the countdown.",
			objective_19_traitor: "Run the countdown to 0 or kill all heroes. Use the special connections between Videotape rooms.",
			objective_20_hero: "Find all hidden room syllables in order, then defeat the Faceless Man with a successful attack. A wrong guess provides floor and doorway-distance clues, but triggers an immediate attack.",
			objective_20_traitor: "Protect the secret syllable order and use the Faceless Man to kill all heroes.",
			objective_21_hero: "Take the Book from Spooky and burn it with Sanity 5+ in the Furnace Room, Ritual Room, Kitchen, Laboratory, or Charred Room. Its holder can attack Horrors using any trait.",
			objective_21_traitor: "Protect the Book and kill all heroes using Spooky and the Horrors. Return a recovered Book to Spooky at the Library.",
			objective_22_hero: "Escape the basement and leave from the Entrance Hall or Graveyard with Speed 6+. Dynamite or the Skeleton Key adds 2.",
			objective_22_traitor: "Place basement rooms and summon Zombies from the Laboratory to kill all heroes. You cannot leave the Laboratory before a hero reaches the Ground Floor.",
			objective_23_hero: "Turn every switch OFF with Knowledge 5+ and Wreck the required number of Omen rooms with Might 4+. Win at the end of a hero turn once both goals are met.",
			objective_23_traitor: "Rearrange rooms and use Robot lasers to kill all heroes.",
			objective_24_hero: "Collect all Flames and deliver them to the Chapel. Speed or Knowledge 5+ takes a Flame safely; failure still takes it but deals 2 General damage.",
			objective_24_traitor: "Use the Dancers and Dark Queen to prevent the Flames reaching the Chapel and kill all heroes.",
			objective_25_hero: "Gather the required different Ingredients by rolling their trait 4+ in matching rooms. Then break the Armor’s curse with Sanity 5+ at the Armory or Ritual Room.",
			objective_25_traitor: "Keep the cursed Armor with heroes to drain their traits and strengthen yourself. Kill all heroes; revive where the Armor is after death.",
			objective_26_hero: "Ruin the Tribute with Sanity 4+ in the Ritual Room, kill the traitor, then destroy the Altar with Might 4+. Sanity 5+ at the Gallery or Statuary Corridor removes a Relative.",
			objective_26_traitor: "Use your Relatives, the Elder, and bedroom passages to kill all heroes.",
			objective_27_hero: "Kill the traitor. Knowledge 4+ at the Library, Observatory, Tower, Laboratory, or Specimen Room grants alien knowledge, allowing up to two rerolls when attacking the traitor. Alien Words hinder movement and cause Mental damage.",
			objective_27_traitor: "Place your Words with Knowledge 7+ in rooms without heroes or Words, adding 1 per adjacent Word room. Win at turn end after placing them all, or kill all heroes.",
			objective_28_hero: "Speed 4+ in Item rooms finds Explosives. With the Ghost Shark, Might 10+ destroys it; add 2 per Explosive spent and another 2 for Dynamite.",
			objective_28_traitor: "Flood every floodable room or kill all heroes. The Ghost Shark can move between Flooded rooms.",
			objective_29_hero: "Bind a Fae with Knowledge 9+ in its room. Each of fae knowledge, Cold Iron, and the Ring adds 2. Might 5+ in Item rooms finds Cold Iron; Knowledge 5+ at the Library or Ritual Room grants fae knowledge.",
			objective_29_traitor: "Use the Fae and Speed attacks to kill all heroes.",
			objective_30_hero: "Discover the last room to reveal the Altar. Use the Ring to lure the traitor there, then complete the ceremony with Sanity 6+ in that room. Heroes keep their Omens hidden until needed.",
			objective_30_traitor: "Acquire the Ring to win. Uncover the heroes’ hidden Omens and avoid being lured to the Altar.",
			objective_31_hero: "Stun Cursed Items, then Dispel them to claim their cards. End a hero turn at the Entrance Hall holding the Holy Symbol and the required number of other cards to win. The Holy Symbol causes General damage at turn end.",
			objective_31_traitor: "Channel Cursed Items and kill all heroes. Channeling inflicts 2 dice of General damage on a hero on your floor.",
			objective_32_hero: "Remove all Cats from the Bakeneko’s floor, then defeat it with a Might attack. Bury an Item or Omen to move a Cat in your room up to four rooms and stun it.",
			objective_32_traitor: "Place all your Fires or kill all heroes. Cats increase the Bakeneko’s Might.",
			objective_33_hero: "Destroy the traitor’s Magic Camera with Sanity 6+ in their room and kill all Photographers, then finish a hero turn. Only Might damage kills Photographers.",
			objective_33_traitor: "Use the Camera, Photographers, and stolen Essence to kill all heroes.",
			objective_34_hero: "In an Omen room, roll dice equal to the track; 9+ finds Christina. Bring her to the Entrance Hall and roll 9+ the same way to escape. Drawing Omens increases the track.",
			objective_34_traitor: "Manipulate rooms and heroes to prevent Christina’s escape and kill all heroes.",
			objective_35_hero: "Destroy both Nests on the Upper Floor and Basement. Speed 9+ destroys a Nest, with +2 per Salt spent. Knowledge or Speed 5+ in the designated food or research rooms finds Salt.",
			objective_35_traitor: "Use the Slugs’ Sanity attacks to convert or kill all heroes. Slugs die after their group attacks.",
			objective_36_hero: "Sanity 5+ in a Ghost’s room brings it peace. Reach the required shared total to win. Completed acts of peace remain counted after a hero dies.",
			objective_36_traitor: "Consume Ghosts in your room with Knowledge 4+ to gain Sanity. End a turn with maximum Sanity, or kill all heroes, to win.",
			objective_37_hero: "Destroy every Robot, then reduce the track to 0 with Speed 4+ at the Entrance Hall. At the Observatory, Game Room, Laboratory, or Panic Room, Knowledge attacks can target any Robot on your floor.",
			objective_37_traitor: "Swap bodies and upload the heroes’ DNA in Omen rooms. Upload all DNA or kill all heroes to win.",
			objective_38_hero: "Knowledge or Sanity 6+ in Event rooms reduces future Neighbor spawns. Win at the end of a hero turn with no Neighbors alive. The Ring holder may keep attacking until the first failed Ring attack.",
			objective_38_traitor: "Summon Neighbors to kill all heroes. On death, revive in the Kitchen and give the Ring to your killer.",
			objective_39_hero: "Collect Eggs and destroy all you carry with Knowledge 5+, then successfully attack the Giant Wasp. Each Egg still in the house subtracts 1 from the attack result.",
			objective_39_traitor: "Protect the Eggs until the track reaches 0 or kill all heroes. Egg rooms continually create Workers.",
			objective_40_hero: "Kill every Evil Twin. Only its Reflection or a hero holding the Mask can kill it; other damage merely stuns. Knowledge 5+ at the Tower or Ritual Room stuns any Twin.",
			objective_40_traitor: "Use the Evil Twins to kill all heroes. You may recover one stunned Twin in your room.",
			objective_41_hero: "Dismantle Traps or Sabotage equipment to increase the track, then roll that many dice at a Generator; 5+ turns it OFF. Turn all Generators OFF to win.",
			objective_41_traitor: "Restart OFF Generators with Knowledge 4+ in their room and kill all heroes using the House and Traps.",
			objective_42_hero: "Exorcise the required number of the Library, Larder, Gymnasium, and Chapel with the room’s trait at 4+, then successfully attack the Demonic Dog. Feeding it reduces its attack result by 4.",
			objective_42_traitor: "Feed the Demonic Dog and kill all heroes. Heal all traits in any of the four haunted rooms.",
			objective_43_hero: "Survive until the track reaches 0. Speed 5+ while out of the Werewolf’s sight hides you. The track drops by 2 after a monster turn with no hero hurt, otherwise by 1. Moving reveals you.",
			objective_43_traitor: "Find hidden explorers and use the Werewolf to kill all heroes.",
			objective_44_hero: "Start fires with Sanity 4+ and spread them throughout the house. Win at the end of a hero turn when every room burns. Entering a burning room deals heroes 1 General damage.",
			objective_44_traitor: "Use fireproof Mannequins to kill all heroes before they burn the entire house.",
			objective_45_hero: "Steal the Book from the traitor with Speed 4+. Knowledge 6+ at the Library, Ballroom, Gallery, or Guest Quarters reduces the track. Kill the traitor at track 0 to win; earlier kills revive them and reduce the track.",
			objective_45_traitor: "Use weapons and Event-room bonuses to kill all heroes. Dying while the track is above 0 revives you and grants an immediate turn.",
			objective_46_hero: "Find Antidote number 1. Knowledge 5+ at the Library reveals any Antidote, or visit its room to reveal it. Carrying the true Antidote adds 3 when attacking the Giant Hair Monster; defeating it wins.",
			objective_46_traitor: "Kill every hero and turn them into Hair Monsters. Only Might damage can defeat the Giant Hair Monster; it can travel between Omen rooms.",
			objective_47_hero: "Trapped heroes escape at a Portal with Knowledge 6+, adding 2 for a free hero in the room. Free heroes close Portals with Knowledge or Sanity 4+. Close them all to win.",
			objective_47_traitor: "Trap and kill all heroes. You may attack each hero once per turn; heal all traits instead of dying.",
			objective_48_hero: "Defeat the Head, take the Skull, and bring it to the Panic Room to win immediately. At turn end its holder rolls Speed 5+ or takes 2 Physical damage.",
			objective_48_traitor: "Protect the Skull and kill all heroes. While holding it, revive the Head in your room and return the Skull to it.",
			objective_49_hero: "A winning Might attack against the Demon may steal the Contract. Burn it with Knowledge 7+; add 4 in the Furnace Room, Ritual Room, Kitchen, Laboratory, or Charred Room.",
			objective_49_traitor: "Collect all heroes’ dropped Blood and bring it to the Demon, or kill all heroes.",
			objective_50_hero: "Bury an Item or Omen and roll Speed or Knowledge 6+ to place an Explosive. At the end of a hero turn, win if all Explosives are placed with at least one on each floor.",
			objective_50_traitor: "Consume every non-Landing room or kill all heroes. Consuming corpses increases your Speed; consuming Omen rooms lets you teleport to a hero.",
			objective_blood1_hero: "Knowledge 3+ in Item or Omen rooms searches the top four cards; found weapons gain silver Runes. Kill Sara to win. Rune weapons add two dice against her and suppress her growth next turn.",
			objective_blood1_traitor: "Lead your Wolves to kill all heroes. Gain Might and Speed at turn start unless a Rune weapon hurt you since your last turn.",
			objective_blood2_hero: "Sanctify Omen rooms with Knowledge 3+, then place an Altar there with Sanity 4+ after all Runes are used. Defeat the Vampire in the Altar room to win; elsewhere it is relocated and stunned.",
			objective_blood2_traitor: "Strengthen the Vampire with Blood and kill all heroes. Spend Blood in its room to heal all your traits.",
			objective_blood3_hero: "Work together to carry the ball to the Altar and reach the target score first. If an unstunned Ghost guards the ball, beat its Speed with Might to take it.",
			objective_blood3_traitor: "Work together to take the ball to the Altar and score.",
			objective_blood4_hero: "Identify and kill the hidden traitor. Alone with a non-Werewolf explorer, oppose their Sanity with Knowledge to inspect their number. Protect Sara if she is a hero; killing the wrong explorer can give the traitor instant victory.",
			objective_blood4_traitor: "Number 1 is the traitor. As Sara, win if a hero kills another hero or all heroes die; otherwise win when Sara dies. Reveal to heal and improve every trait.",
			objective_blood5_hero: "Place ritual tokens in Omen rooms with the matching trait at 4+. Kill Sara’s Werewolf form to win, or attempt to save her human form while holding the Book or Mask, with Knowledge plus placed tokens at 5+. Successful salvation also lets Sara win.",
			objective_blood5_traitor: "Win alone by reaching track 9 or killing all heroes as the Werewolf. If your human form is saved, share victory with the surviving heroes.",
			objective_yuletide1_hero: "Work together to stun the Toys and bring them to the Stranger. Only the Stranger carrying a numbered card can Banish its Toy with Knowledge 3+. Banish them all before the Stranger dies or the room stack runs out.",
			objective_yuletide1_traitor: "Work together to Banish every Toy.",
			objective_yuletide2_hero: "Take Bells with their trait at 3+ and deliver them to the Soundproofed Room. Deliver a number equal to the player count to win.",
			objective_yuletide2_traitor: "Run the track to 0 or kill all heroes. It drops at your turn start and on explorer deaths. Instead of dying, increase the track and heal.",
			objective_yuletide3_hero: "Find cards in Kudzu rooms and exchange nonweapon cards other than the Dog for Rune ornaments with Knowledge 3+. In the traitor’s room, Speed 3+ delivers one. Deliver a number equal to the player count to win.",
			objective_yuletide3_traitor: "Connect the required number of Kudzu rooms or kill all heroes. On death, consume a Kudzu to revive; if none remain, the heroes win.",
			objective_yuletide4_hero: "Kill the traitor. Food weakens its next defense, and gifting an Item clears Coal from your room. Knowledge 3+ at the Kitchen or Larder replenishes Food.",
			objective_yuletide4_traitor: "Use Coal, your Gaze, and Items to kill all heroes. If Food is in sight, you must approach it.",
			objective_yuletide5_hero: "Gift numbered Items to heroes with matching numbers, turning both players’ numbers facedown. Win when all player numbers are facedown. Search Item rooms or the Armory with Knowledge 3+.",
			objective_yuletide5_traitor: "After becoming Krampus, collect the required number of Items or kill all heroes. Stealing a numbered Item reshuffles the gift numbers.",
			objective_pennywise1_hero: "Kill Henry. Search the top three Items with Speed or Knowledge 3+ in Item rooms. Sanity 5+ in Hockstetter’s room removes him.",
			objective_pennywise1_traitor: "Hunt heroes using your secret kill list and kill them all. Hockstetter can protect you, move you, or supply Items.",
			objective_pennywise2_hero: "Roll Knowledge or Sanity minus the track; 4+ reconnects a separated room group to the main house. Once all living heroes reach the Entrance Hall, roll Sanity together; highest plus lowest of 8+ escapes.",
			objective_pennywise2_traitor: "Use Tiny and Huge Terrors to kill all heroes. Move all Tiny Terrors before grouped room attacks. Unseen Terrors can relocate to another unseen room.",
			objective_pennywise3_hero: "Find the current Form’s weakness and stun it, then Banish it with a successful Sanity attack in its room. Reach track 0 to win. Knowledge 5+ in investigation rooms reveals the weakness.",
			objective_pennywise3_traitor: "Use each Form’s powers to kill all heroes. On recovery from stun, choose movement or attacks for that turn. Withdraw a Form when no heroes remain on its floor.",
			objective_pennywise4_hero: "Find your Artifacts and bring them to the Altar. While Pennywise is absent, Sanity 4+ deposits one. After all Artifacts are deposited, perform the Ritual: each living hero rolls one die; a total at least equal to their count wins.",
			objective_pennywise4_traitor: "Work together to complete the Ritual of Chüd.",
			objective_pennywise5_hero: "Work together. Taunt Pennywise in sight with Knowledge or Sanity 4+ to take the red balloon and reduce the track. While he is stunned, roll Might plus other heroes in the room minus the track; 5+ Crushes him. Items and Omens cannot modify this roll.",
			objective_pennywise5_traitor: "Work together to Crush Pennywise.",
			detail_machete: "Weapon. Add 1 to the result of your Might attack.",
			detail_crossbow: "Weapon. Attack a target on your tile or an adjacent tile using Speed against Speed, and roll one additional die. You take no damage if your attack fails.",
			detail_firstAidKit: "On your turn, you may bury this card to heal all critical traits of one explorer on your tile, including yourself.",
			detail_mirror: "On your turn, you may bury this card to heal Knowledge and Sanity.",
			detail_angelsFeather: "Before making a trait roll, you may bury this card to choose a raw result from 0 to 8, then apply the relevant modifiers.",
			detail_strangeMedicine: "On your turn, you may bury this card to heal Might and Speed.",
			detail_mysticalStopwatch: "After the haunt begins, you may bury this card on your turn to take another turn immediately after this one.",
			detail_skeletonKey: "You may move through walls between discovered tiles. After each use, roll one die; bury this card on a blank. You cannot discover a room through a wall.",
			detail_strangeAmulet: "After each instance of physical damage, gain 1 Sanity. General damage and direct trait loss do not trigger this effect.",
			detail_dynamite: "Instead of attacking, bury this card and choose your tile or an adjacent tile. Each explorer and monster there makes a Speed roll: 4 or more avoids damage; 0–3 causes 4 physical damage.",
			detail_magicCamera: "You may use Sanity instead of Knowledge when making a Knowledge roll.",
			detail_headphones: "Reduce each instance of mental damage by 1. This does not reduce general damage or direct trait loss.",
			detail_gun: "Weapon. Attack a target in line of sight using Speed against Speed. You take no damage if your attack fails.",
			detail_rabbitsFoot: "Once on your turn, you may reroll one die you just rolled.",
			detail_flashlight: "When making a trait roll for an Event, you may roll two additional dice.",
			detail_luckyCoin: "Once on your turn, you may reroll all blanks in a trait roll you just made. Each blank in the reroll causes 1 mental damage.",
			detail_map: "On your turn, you may bury this card to move to any discovered tile.",
			detail_necklaceOfTeeth: "At the end of your turn, you may increase one critical trait by one step.",
			detail_brooch: "You may convert incoming physical or mental damage into general damage.",
			detail_leatherJacket: "Roll one additional die when defending against an attack.",
			detail_chainsaw: "Weapon. Roll one additional die when attacking with it.",
			detail_creepyDoll: "Once on your turn, you may reroll all dice in a trait roll you just made, then lose 1 Sanity.",
			detail_dog: "Add 1 to your Speed roll results. Once on your turn, you may trade Items and Omens with one explorer within four tiles, following normal trading rules.",
			detail_holySymbol: "Add 1 to your Sanity roll results. When discovering a tile, you may bury it and discover the next tile instead, without resolving the first tile.",
			detail_idol: "Add 1 to your Might roll results. When discovering an Event room, you may choose not to draw its Event.",
			detail_dagger: "Weapon. Before attacking with it, lose 1 Speed, then roll two additional dice.",
			detail_ring: "Add 1 to your Sanity roll results. You may attack using Sanity against Sanity; the loser takes mental damage.",
			detail_skull: "Add 1 to your Knowledge roll results. Before dying, roll three dice: on 4 or more, set all traits to critical instead; on 0–3, you die.",
			detail_book: "Add 1 to your Knowledge roll results. Once on your turn, you may lose 1 Sanity to use Knowledge and its modifiers for your next nonattack trait roll that turn.",
			detail_armor: "Reduce each instance of physical damage by 1. This does not reduce general damage or direct trait loss.",
			detail_mask: "Add 1 to your Speed roll results. Once on your turn, you may move each other explorer and monster on your tile to an adjacent discovered tile.",
			detail_fangBracelet: "Add 1 to attack results against monsters and werewolf characters.",
			detail_wolfsbane: "Roll one additional die when defending against a werewolf. On your turn, you may bury this card to heal Sanity.",
			detail_unusualCake: "On your turn, you may bury this card to heal Speed and Sanity.",
			detail_snowGlobe: "When you would die, move to the Entrance Hall and set all traits to critical instead, then bury this card.",
			detail_hiddenOmen: "This omen has not been revealed.",
			detail_armory: "When discovered, reveal Items until you find a weapon. Take that weapon and bury the other revealed cards.",
			detail_junkRoom: "When discovered, place an Obstacle here. Leaving a room with an Obstacle costs one extra move.",
			detail_panicRoom: "When discovered, find and place the Secret Staircase in the Basement if it is absent, then shuffle the tile stack.",
			detail_laundryChute: "One-way connection to the Basement Landing. If you end your turn here, move to the Basement Landing.",
			detail_chapel: "When discovered, gain 1 Sanity.",
			detail_secretStaircase: "Connects in both directions to the Hallway.",
			detail_library: "When discovered, gain 1 Knowledge.",
			detail_larder: "When discovered, gain 1 Might.",
			detail_gymnasium: "When discovered, gain 1 Speed.",
			detail_undergroundCavern: "Connects in both directions to the Graveyard.",
			detail_mysticElevator: "Once per turn when entering, you may roll two dice: 4 allows any floor, 3 the Upper Floor, 2 the Ground Floor, and 0–1 the Basement. Move the entire tile to an unexplored doorway on that floor.",
			detail_gallery: "One-way connection to the Ballroom.",
			detail_graveyard: "Connects in both directions to the Underground Cavern.",
			detail_furnaceRoom: "If you end your turn here, take 1 physical damage.",
			detail_collapsedRoom: "At the end of your turn, make a Speed roll. On 5 or more, nothing happens. On 0–4, move to the Basement Landing and take one die of physical damage.",
			detail_groundStaircase: "Connects to the Upper Landing. Monsters also connect to the Basement Landing.",
			detail_upperLanding: "Connects to the Ground Staircase.",
			detail_basementLanding: "Monsters can travel between here and the Ground Staircase.",
			detail_hallway: "Connects to the Secret Staircase.",
			detail_entranceHall: "You cannot leave the house before the haunt begins.",
			detail_oubliette: "Connects in both directions to the Trophy Room.",
			detail_trophyRoom: "Connects in both directions to the Oubliette.",
			detail_timeLostTree: "When discovered, place the Root Cellar in the Basement if absent, then shuffle the tile stack. Connects in both directions to the Root Cellar.",
			detail_rootCellar: "When discovered, place the Time-Lost Tree on the Upper Floor if absent, then shuffle the tile stack. Connects in both directions to the Time-Lost Tree.",
			detail_ancientDen: "When discovered, draw an extra card, choose one to keep, and bury the other.",
			detail_windingTunnels: "The northeast and southwest halves are separate areas. A Knowledge roll of 4 or more lets you cross between them.",
			detail_darkenedHallway: "Draw both Events and resolve them in the order drawn.",
			detail_oldWell: "When discovered, make a Knowledge roll. On 4 or more, draw an extra Item. On 0–3, bury an Item.",
			detail_secretElevator: "You may immediately move to any explored room on a different floor.",
			detail_creakingDoor: "Make a Knowledge roll. On 6 or more, you may move to any explored room on the Upper or Ground floor. On 4–5, you may move to any explored room on the Ground floor. On 0–3, you move to the Basement Landing.",
			detail_cryForHelp: "Make a Knowledge roll. On 4 or more, you may move to any explored room on your floor. Otherwise, take 1 mental damage.",
			detail_momentOfHope: "Place a Blessing token in your room. A hero in that room rolls 1 extra die on every trait roll.",
			detail_darkStormyNight: "Make a Knowledge roll. On 4 or more, gain 1 Sanity. Otherwise, take 1 mental damage.",
			detail_spiders: "Make a Sanity roll. On 4 or more, gain 1 Sanity or Speed, then you may move to an adjacent room. On 2–3, gain 1 Speed and lose 1 Sanity. On 0–1, lose 1 Speed.",
			detail_meatMoss: "You may roll 2 dice. On 3 or more, gain 1 in any trait. Otherwise, roll 1 die and take mental damage equal to the total.",
			detail_eerieFeeling: "Roll 2 dice. On 4, nothing happens. On 3, lose 1 Speed. On 2, lose 1 Sanity. On 1, lose 1 Knowledge. On 0, lose 1 Might.",
			detail_hangedMen: "Roll Might, Speed, Sanity, and Knowledge in that order. On 0–1 for a trait, lose 1 in that trait. If all four rolls are 2 or more, gain 1 in any trait.",
			detail_poorYorick: "Make a Sanity roll. On 4 or more, gain 1 Knowledge. Otherwise, take 1 mental damage.",
			detail_impossibleArchitecture: "Make a Sanity roll. On 4 or more, draw an Item. Otherwise, roll 1 die and take mental damage equal to the total.",
			detail_alienGeometry: "Make a Knowledge roll. On 4 or more, gain 1 Sanity. Otherwise, lose 1 Speed.",
			detail_bite: "Make a Might roll. On 4 or more, nothing happens. On 2–3, take 1 physical damage. On 0–1, take 3 physical damage.",
			detail_funeral: "Make a Sanity roll. On 4 or more, gain 1 Sanity. On 2–3, lose 1 Sanity. On 0–1, lose 1 Sanity and 1 Might. Then, if the Graveyard or Catacombs is in the house, you must move to one of them.",
			detail_jonahsTurn: "You may bury a non-weapon Item to gain 1 Sanity. If you do not, roll 1 die and take mental damage equal to the total.",
			detail_flickeringLights: "Choose Speed or Might and make a roll. On 5 or more, gain 1 Speed. Otherwise, roll 1 die and take physical damage equal to the total.",
			detail_flowering: "Take 1 general damage, then move to any explored room on the Ground or Basement floor. If the Conservatory is in the house, you must move there.",
			detail_fullTable: "Choose Knowledge or Sanity and make a roll. On 5 or more, gain 1 Speed. Otherwise, take 1 general damage.",
			detail_deepestCloset: "Make a Speed roll. On 4 or more, draw an Item. On 1–3, take 1 mental damage. On 0, roll 1 die and take physical damage equal to the total, then move to the Basement Landing.",
			detail_burningFigure: "Make a Sanity roll. On 4 or more, gain 1 Sanity. On 2–3, move to the Entrance Hall. On 0–1, roll 1 die for physical damage equal to the total and 1 die for mental damage equal to the total.",
			detail_behindYou: "Make a Speed roll. On 4 or more, gain 1 Sanity. Otherwise, take 1 physical damage.",
			detail_clownRoom: "Make a Sanity roll. On 4 or more, nothing happens. Otherwise, take 2 mental damage.",
			detail_radioBroadcast: "Roll 2 dice. On 3 or more, gain 1 Knowledge. Otherwise, roll 1 die and take mental damage equal to the total.",
			detail_tinyRobot: "Make a Knowledge roll. On 5 or more, draw an Item. Otherwise, roll 1 die and take physical damage equal to the total.",
			detail_taxidermy: "Make a Might roll. On 5 or more, gain 1 Sanity. Otherwise, take 1 physical damage and place an Obstacle token in your room.",
			detail_severedHand: "You may take 2 physical damage to draw an Item.",
			detail_phoneCall: "Roll 2 dice. On 4, gain 1 Sanity. On 3, gain 1 Knowledge. On 1–2, roll 1 die and take mental damage equal to the total. On 0, roll 2 dice and take physical damage equal to the total.",
			detail_batOutOfHell: "Make a Speed roll. On 4 or more, you may move to an adjacent room. Otherwise, take 1 physical damage.",
			detail_sayCheese: "Before the haunt, you may make a haunt roll. On 5 or more, start Haunt 33. Otherwise, draw an Item. If the haunt has started or you decline, draw an Item.",
			detail_mysteriousFluid: "You may roll 3 dice. On 6, gain 1 in every trait. On 5, gain 1 Might and Speed. On 4, gain 1 Sanity and Knowledge. On 3, gain 1 Knowledge and lose 1 Might. On 2, lose 1 Sanity and Knowledge. On 1, lose 1 Might and Speed. On 0, lose 1 in every trait.",
			detail_splashOfCrimson: "Before the haunt, you may make a haunt roll. On 5 or more, start Haunt 1. Otherwise, gain 1 Speed. If the haunt has started or you decline, roll 1 die and take physical damage equal to the total.",
			detail_forbiddenKnowledge: "Make a Sanity roll. On 4 or more, gain 1 Knowledge. On 2–3, gain 1 Knowledge and lose 1 Sanity. On 0–1, take 2 mental damage.",
			detail_vialOfDust: "Before the haunt, you may make a haunt roll. On 5 or more, start Haunt 3. Otherwise, gain 1 Sanity. If the haunt has started or you decline, lose 1 Might and gain 1 Sanity.",
			detail_cassettePlayer: "Make a Sanity roll. On 4 or more, gain 1 Knowledge. Otherwise, take 1 mental damage.",
			detail_eerieMirror: "Before the haunt, you may make a haunt roll. On 5 or more, start Haunt 7. Otherwise, gain 1 Sanity. If the haunt has started or you decline, draw an Item.",
			detail_oldestHouse: "Choose Speed or Might and make a roll. On 5 or more, you may move to any explored room. On 3–4, move to any explored room on the Ground floor and take 1 general damage. On 0–2, move to any explored room on the Basement floor and take 1 mental damage.",
			detail_jarOfOrgans: "Make a Sanity roll. On 4 or more, draw an Item. Otherwise, lose 1 Might.",
			detail_technicalDifficulties: "Move to the landing of the next floor. If you were on the Basement floor, move to the Upper Landing and take 1 mental damage.",
			detail_wanderingGhost: "You may bury an Item to gain 1 in any trait. If you do not, make a Sanity roll: on 4 or more, draw an Item; otherwise, take 1 general damage.",
			detail_starsAtNight: "Choose any trait and make a roll. On 5 or more, gain 1 in that trait. On 4, lose 1 in that trait. On 0–3, heal that trait.",
			detail_brainFood: "Make a Might roll. On 5 or more, gain 1 Might or Speed. On 1–4, gain 1 Speed and lose 1 Sanity. On 0, take 2 general damage.",
			detail_secretPassage: "Place a Secret Passage token in your room and make a Knowledge roll. On 5 or more, place the other token in any other explored room and gain 1 Knowledge. On 3–4, place it on the Ground floor. On 0–2, place it on the Basement floor and lose 1 Sanity. The two tokens connect.",
			detail_houseIsHungry: "Before the haunt, you may make a haunt roll. On 5 or more, start Haunt 12. Otherwise, gain 1 Might. If the haunt has started or you decline, gain 1 in any trait.",
			detail_hunt: "Make a Speed roll. On 4 or more, you may move to any explored room on your floor and gain 1 Sanity. Otherwise, lose 1 Sanity.",
			detail_bloodMoon: "Make a Sanity roll. On 4 or more, gain 1 Might. On 2–3, nothing happens. On 0–1, roll 1 die for physical damage and 1 die for mental damage equal to their totals, then move to the Entrance Hall.",
			detail_feast: "You may roll 2 dice. On 4, gain 1 Might. On 3, gain 1 Sanity. On 1–2, roll 1 die and take mental damage equal to the total. On 0, roll 2 dice and take physical damage equal to the total.",
			detail_gift: "You may roll 2 dice. On 3 or more, draw an Item. On 2, nothing happens. On 0–1, roll 1 die for physical damage and 1 die for mental damage equal to their totals.",
			detail_floatingLights: "Make a Speed roll. On 4 or more, gain 2 Sanity. Otherwise, lose 1 Sanity.",
			detail_knifeInDark: "An enemy attacks you with 4 dice and you defend with Might. If you take no damage, draw an Omen.",
			detail_bloodTendrils: "Make a Sanity roll. On 4 or more, draw an Omen. Otherwise, take 1 mental damage.",
			detail_goodBoy: "A huge dog attacks you with 4 dice and you defend with Speed. If you take no damage, you may move to an adjacent room and gain 1 Sanity.",
			detail_popOfRed: "Make a Might roll. On 4 or more, draw an Omen. Otherwise, roll 1 die for physical damage and 1 die for mental damage equal to their totals.",
			detail_hometownHorrors: "Make a Sanity roll. On 4 or more, gain 1 Sanity and draw an Omen. Otherwise, take 1 mental damage.",
			detail_swirlingVisions: "Make a Knowledge roll. On 4 or more, gain 1 in any trait. Otherwise, take 1 mental damage.",
			detail_stretchingHall: "Make a Sanity roll. On 4 or more, draw an Omen. Otherwise, take 1 physical damage.",
			detail_timeToSink: "Make a Speed roll. On 4 or more, gain 1 Might. Otherwise, lose 1 Speed.",
			detail_eaterOfWorlds: "Make a Sanity roll. On 4 or more, you may move to an adjacent room and draw an Omen. Otherwise, take 1 general damage.",
			uiSecretSickness: "Sickness numbers",
			uiSecretTrait: "Mirror trait",
			uiSecretOmen: "Mirror omen",
			uiSecretRoom: "Mirror room",
			uiSecretTarget: "Next victim",
			uiSecretSyllables: "Hidden syllable order",
			uiSecretWeakness: "Current form weakness",
			uiSecretMessages: "Death messages",
			uiSecretRemains: "Remains number order",
			uiRoomContents: "Room contents",
			uiTileDeck: "Rooms",
			uiItemDeck: "Items",
			uiOmenDeck: "Omens",
			uiEventDeck: "Events",
			uiEncounterDeck: "Encounters",
			uiSurvivors: "Final record",
			uiWon: "Winner",
			uiLost: "Did not win",
			uiReviewHouse: "Review the house",
			uiConfirm: "Confirm",
			uiTrackValue: "Haunt track: {{n}}",
			uiLiving: "Alive",
			uiParty: "Investigators",
			uiNoRoom: "Location unknown",
			uiUnexplored: "Unexplored",
			uiCardItem: "Item card",
			uiCardOmen: "Omen card",
			uiCardEvent: "Event card",
			uiCardEncounter: "Encounter card",
			uiRevealDrawn: "{{name}} drew",
			uiRevealAck: "I've seen it",
			uiRevealConfirmed: "Confirmed {{n}}/{{m}}",
			uiRevealWait: "Waiting for the other players to confirm",
			uiShortMight: "Mgt",
			uiShortSpeed: "Spd",
			uiShortSanity: "San",
			uiShortKnowledge: "Kno",
			uiContentsCount: "Tokens {{n}} · Monsters {{m}}",
			guideSymbols: "Room symbols",
			guideItem: "Bull skull: draw an Item, normally held faceup and used as instructed.",
			guideOmen: "Raven: draw an Omen and, before the haunt, make a haunt roll. Come Home to Evil draws an Encounter instead.",
			guideEvent: "Spiral: draw and resolve an Event.",
			guideComponents: "Items, Omens, and special rooms",
			guideRoom: "Room",
			uiTreasureScore: "Treasure score: {{n}}",
			counterTraitorWords: "Traitor words remaining",
			counterHeroWords: "Hero words remaining",
			counterBloodSupply: "Blood supply",
			counterRunesRequired: "Runes required",
			counterHeroScore: "Hero score",
			counterSpiritScore: "Spirit score",
			counterScoreTarget: "Winning score",
			counterFireSupply: "Fires remaining",
			counterDogFood: "Food eaten by the Dog",
			counterFlamesRemaining: "Flames not yet placed",
			counterOrnamentSupply: "Ornament supply",
			counterToyTarget: "Toys to banish",
			counterBanished: "Toys banished",
			counterFoodRemaining: "Witch food remaining",
			counterGhostReserve: "Ghosts in reserve",
			counterMessagesRemaining: "Messages remaining",
			counterReconciled: "Ghosts reconciled"
		}
	}
};
//#endregion
export { ts as default };
