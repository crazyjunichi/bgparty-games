import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { GameScreen as n } from "@bgparty/sdk/ui/game-screen";
import { useEffect as r, useRef as i, useState as a } from "react";
import { AVATARS as o } from "@bgparty/sdk/avatars";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as u } from "@bgparty/sdk/player-colors";
import { seatName as d } from "@bgparty/sdk/ui/player-strip";
import { gameAssetUrl as f } from "@bgparty/sdk/assets";
import { usePrefersReducedMotion as p } from "@bgparty/sdk/fx/use-reduced-motion";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { FlySprite as _ } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as v, OptionSection as ee, OptionSwitch as y } from "@bgparty/sdk/ui/game-options";
//#region src/game/components.ts
var te = [
	"die",
	"wildlife",
	"forest",
	"sun",
	"photoCanteen",
	"gear",
	"water",
	"mountain"
], b = [
	"sun2",
	"tradeWildlife",
	"tradeWildlife",
	"forest",
	"tradeWildlife",
	"mountain",
	"forest",
	"forest",
	"forest",
	"tradePhoto",
	"forest",
	"parks",
	"tradePhoto",
	"sun2",
	"mountain",
	"tradePhoto",
	"mountain",
	"sun2",
	"parks",
	"mountain",
	"sun2",
	"mountain",
	"parks",
	"sun2"
], x = [
	[
		"Hiking Boots",
		2,
		"siteForest",
		"forest"
	],
	[
		"Mystery Cache",
		3,
		"die",
		"die"
	],
	[
		"Sleeping Bag",
		3,
		"siteMountain",
		"relightSun2"
	],
	[
		"Sleeping Bag",
		3,
		"siteForest",
		"relightSun2"
	],
	[
		"Field Guide",
		3,
		"siteWater",
		"wildlife"
	],
	[
		"Field Guide",
		3,
		"siteSun",
		"wildlife"
	],
	[
		"Field Guide",
		3,
		"siteForest",
		"wildlife"
	],
	[
		"Field Guide",
		3,
		"siteMountain",
		"wildlife"
	],
	[
		"Mystery Cache",
		2,
		"photo",
		"die"
	],
	[
		"Sunscreen",
		2,
		"tradeWildlife",
		"sun2"
	],
	[
		"Sunscreen",
		2,
		"photo",
		"sun2"
	],
	[
		"Rain Gear",
		2,
		"tradeWildlife",
		"water2"
	],
	[
		"Rain Gear",
		2,
		"photo",
		"water2"
	],
	[
		"Binoculars",
		2,
		"reserve",
		"mountain"
	],
	[
		"Binoculars",
		2,
		"siteSun",
		"mountain"
	],
	[
		"Binoculars",
		2,
		"siteMountain",
		"mountain"
	],
	[
		"Hiking Boots",
		2,
		"reserve",
		"forest"
	],
	[
		"Hiking Boots",
		2,
		"siteWater",
		"forest"
	],
	[
		"Camp Mug",
		1,
		"reserve",
		"canteen"
	],
	[
		"Telephoto Lens",
		1,
		"tradeWildlife",
		"tradePhoto"
	],
	[
		"Telephoto Lens",
		1,
		"reserve",
		"tradePhoto"
	],
	[
		"Telephoto Lens",
		1,
		"die",
		"tradePhoto"
	],
	[
		"Compass",
		1,
		"tradeWildlife",
		"reserve"
	],
	[
		"Compass",
		1,
		"die",
		"reserve"
	],
	[
		"Journal",
		1,
		"siteWater",
		"reserve"
	],
	[
		"Journal",
		1,
		"siteSun",
		"reserve"
	],
	[
		"Journal",
		1,
		"siteForest",
		"reserve"
	],
	[
		"Journal",
		1,
		"siteMountain",
		"reserve"
	],
	[
		"Flint & Tinder",
		1,
		"siteWater",
		"relight"
	],
	[
		"Flint & Tinder",
		1,
		"siteSun",
		"relight"
	],
	[
		"Flint & Tinder",
		1,
		"siteForest",
		"relight"
	],
	[
		"Flint & Tinder",
		1,
		"siteMountain",
		"relight"
	],
	[
		"Wide Angle Lens",
		1,
		"siteWater",
		"tradePhoto"
	],
	[
		"Wide Angle Lens",
		1,
		"siteSun",
		"tradePhoto"
	],
	[
		"Wide Angle Lens",
		1,
		"siteForest",
		"tradePhoto"
	],
	[
		"Wide Angle Lens",
		1,
		"siteMountain",
		"tradePhoto"
	],
	[
		"Camp Mug",
		1,
		"tradeWildlife",
		"canteen"
	]
].map(([e, t, n, r], i) => ({
	id: i,
	name: e,
	cost: t,
	trigger: n,
	effect: r
})), S = [
	"wildlife",
	"botany",
	"mountaineering",
	"birdwatching",
	"kayaking",
	"forestry",
	"collecting",
	"swimming",
	"rockClimbing",
	"adventure"
], ne = [
	[
		"photoToResources",
		"canteenAndGear",
		"mountainToSun5",
		"parksAndPhoto"
	],
	[
		"photoToWildlife2",
		"wildlifeToForest3",
		"mountainAndPhoto",
		"twoToWildlife2"
	],
	[
		"photoToWildlife2",
		"chooseResources",
		"forestToWater5",
		"badgeAndPhoto"
	],
	[
		"wildlife",
		"photoToResources",
		"forestAndPhoto",
		"gearAndSun2"
	],
	[
		"wildlifeToMountain3",
		"forestAndPhoto",
		"sunToDice2",
		"twoToWildlife2"
	],
	[
		"chooseResources",
		"mountainToWater5",
		"sunToAny2",
		"parksAndPhoto"
	],
	[
		"wildlifeToForest3",
		"mountainAndPhoto",
		"waterToAny2",
		"gearAndSun2"
	],
	[
		"forestToSun5",
		"waterToDice2",
		"wildlifeToMountain3",
		"badgeAndPhoto"
	]
], C = [
	[
		"next",
		"parks",
		"back"
	],
	[
		2,
		"gear",
		"back"
	],
	[
		"next",
		"parks",
		"front"
	],
	[
		2,
		"parks",
		"front"
	],
	[
		3,
		"parks",
		"back"
	],
	[
		2,
		"gear",
		"back"
	],
	[
		2,
		"photo",
		"back"
	],
	[
		2,
		"gear",
		"front"
	],
	[
		"next",
		"gear",
		"back"
	],
	[
		2,
		"photo",
		"back"
	],
	[
		"next",
		"gear",
		"front"
	],
	[
		"next",
		"parks",
		"back"
	],
	[
		3,
		"photo",
		"front"
	],
	[
		3,
		"gear",
		"front"
	],
	[
		2,
		"parks",
		"back"
	],
	[
		2,
		"parks",
		"back"
	],
	[
		"next",
		"photo",
		"front"
	],
	[
		"next",
		"gear",
		"back"
	],
	[
		2,
		"photo",
		"front"
	],
	[
		"next",
		"photo",
		"back"
	],
	[
		"next",
		"photo",
		"back"
	]
].map(([e, t, n]) => ({
	movement: e,
	end: t,
	back: n
})), w = [
	[
		"North Cascades",
		7,
		1,
		2,
		0,
		4,
		0,
		null
	],
	[
		"Great Basin",
		4,
		2,
		1,
		1,
		0,
		0,
		"water2"
	],
	[
		"Crater Lake",
		3,
		1,
		1,
		0,
		1,
		0,
		"shutterbug"
	],
	[
		"Kings Canyon",
		4,
		1,
		2,
		0,
		1,
		0,
		"sun2"
	],
	[
		"Pinnacles",
		4,
		3,
		0,
		1,
		0,
		0,
		"die"
	],
	[
		"Denali",
		6,
		1,
		1,
		2,
		2,
		0,
		null
	],
	[
		"Gates of the Arctic",
		3,
		0,
		0,
		3,
		1,
		0,
		null
	],
	[
		"Glacier Bay",
		6,
		1,
		0,
		0,
		3,
		1,
		null
	],
	[
		"Katmai",
		3,
		0,
		0,
		0,
		1,
		1,
		null
	],
	[
		"Kenai Fjords",
		5,
		3,
		1,
		0,
		1,
		0,
		"sun2"
	],
	[
		"Yosemite",
		6,
		1,
		1,
		1,
		1,
		1,
		null
	],
	[
		"Everglades",
		3,
		0,
		0,
		0,
		4,
		0,
		null
	],
	[
		"Hawaiʻi Volcanoes",
		4,
		3,
		0,
		0,
		1,
		0,
		"die"
	],
	[
		"Capitol Reef",
		5,
		1,
		1,
		1,
		1,
		0,
		null
	],
	[
		"Zion",
		4,
		3,
		0,
		0,
		0,
		0,
		null
	],
	[
		"Arches",
		3,
		1,
		0,
		2,
		0,
		0,
		null
	],
	[
		"Canyonlands",
		3,
		2,
		0,
		1,
		0,
		0,
		"wildlife"
	],
	[
		"Bryce Canyon",
		7,
		4,
		0,
		2,
		0,
		0,
		null
	],
	[
		"Guadalupe Mountains",
		4,
		1,
		0,
		1,
		0,
		1,
		null
	],
	[
		"Big Bend",
		5,
		1,
		0,
		3,
		2,
		0,
		"wildlife"
	],
	[
		"Great Smoky Mountains",
		7,
		2,
		2,
		1,
		1,
		0,
		null
	],
	[
		"Gateway Arch",
		2,
		0,
		0,
		3,
		0,
		0,
		"water2"
	],
	[
		"Haleakalā",
		5,
		4,
		0,
		0,
		0,
		0,
		null
	],
	[
		"Mammoth Cave",
		3,
		2,
		0,
		0,
		0,
		0,
		null
	],
	[
		"Wind Cave",
		4,
		0,
		3,
		0,
		1,
		0,
		"shutterbug"
	],
	[
		"White Sands",
		3,
		0,
		0,
		1,
		0,
		1,
		null
	],
	[
		"Indiana Dunes",
		3,
		1,
		0,
		1,
		2,
		0,
		"wildlife"
	],
	[
		"Great Sand Dunes",
		6,
		3,
		0,
		3,
		0,
		0,
		"water1"
	],
	[
		"National Park of American Samoa",
		6,
		0,
		1,
		3,
		0,
		1,
		null
	],
	[
		"Dry Tortugas",
		2,
		0,
		0,
		0,
		3,
		0,
		"sun2"
	],
	[
		"Biscayne",
		3,
		0,
		2,
		0,
		1,
		0,
		"canteen"
	],
	[
		"Channel Islands",
		3,
		1,
		0,
		0,
		3,
		0,
		"sun2"
	],
	[
		"Virgin Islands",
		4,
		0,
		0,
		2,
		1,
		1,
		null
	],
	[
		"Badlands",
		7,
		2,
		1,
		4,
		0,
		0,
		null
	],
	[
		"Theodore Roosevelt",
		5,
		1,
		3,
		1,
		0,
		0,
		"water2"
	],
	[
		"Lassen Volcanic",
		4,
		0,
		3,
		0,
		0,
		0,
		null
	],
	[
		"Petrified Forest",
		4,
		0,
		2,
		2,
		0,
		0,
		null
	],
	[
		"Carlsbad Caverns",
		2,
		1,
		0,
		1,
		0,
		0,
		"wildlife"
	],
	[
		"Kobuk Valley",
		3,
		0,
		1,
		2,
		1,
		0,
		"canteen"
	],
	[
		"Lake Clark",
		3,
		1,
		0,
		0,
		2,
		0,
		null
	],
	[
		"Wrangell–St. Elias",
		7,
		0,
		4,
		0,
		2,
		0,
		null
	],
	[
		"Voyageurs",
		6,
		0,
		3,
		0,
		3,
		0,
		"sun1"
	],
	[
		"Glacier",
		4,
		2,
		0,
		1,
		1,
		0,
		"shutterbug"
	],
	[
		"Olympic",
		4,
		0,
		3,
		1,
		0,
		0,
		"die"
	],
	[
		"Acadia",
		4,
		0,
		1,
		0,
		1,
		1,
		null
	],
	[
		"Isle Royale",
		2,
		0,
		1,
		0,
		1,
		0,
		"canteen"
	],
	[
		"Redwood",
		7,
		1,
		4,
		0,
		0,
		0,
		null
	],
	[
		"Sequoia",
		5,
		0,
		4,
		0,
		0,
		0,
		null
	],
	[
		"Congaree",
		3,
		0,
		2,
		0,
		0,
		0,
		null
	],
	[
		"Cuyahoga Valley",
		3,
		0,
		1,
		0,
		2,
		0,
		null
	],
	[
		"Hot Springs",
		3,
		0,
		0,
		1,
		3,
		0,
		null
	],
	[
		"New River Gorge",
		5,
		0,
		1,
		2,
		3,
		0,
		"canteen"
	],
	[
		"Shenandoah",
		4,
		0,
		2,
		1,
		1,
		0,
		"shutterbug"
	],
	[
		"Mesa Verde",
		6,
		3,
		1,
		1,
		0,
		0,
		null
	],
	[
		"Black Canyon of the Gunnison",
		4,
		2,
		0,
		0,
		2,
		0,
		null
	],
	[
		"Grand Teton",
		3,
		1,
		1,
		1,
		0,
		0,
		"die"
	],
	[
		"Yellowstone",
		6,
		0,
		0,
		2,
		3,
		1,
		null
	],
	[
		"Mount Rainier",
		5,
		1,
		3,
		0,
		1,
		0,
		"wildlife"
	],
	[
		"Death Valley",
		3,
		0,
		0,
		4,
		0,
		0,
		null
	],
	[
		"Joshua Tree",
		3,
		0,
		1,
		3,
		0,
		0,
		"water2"
	],
	[
		"Saguaro",
		3,
		0,
		1,
		2,
		0,
		0,
		null
	],
	[
		"Grand Canyon",
		7,
		4,
		1,
		0,
		0,
		0,
		null
	],
	[
		"Rocky Mountain",
		6,
		1,
		1,
		2,
		2,
		0,
		null
	]
].map(([e, t, n, r, i, a, o, s], c) => ({
	id: c,
	name: e,
	points: t,
	cost: {
		mountain: n,
		forest: r,
		sun: i,
		water: a,
		wildlife: o
	},
	bonus: s
})), T = [
	"mountain",
	"forest",
	"sun",
	"water",
	"wildlife"
], E = () => ({
	mountain: 0,
	forest: 0,
	sun: 0,
	water: 0,
	wildlife: 0
}), D = (e) => T.reduce((t, n) => t + e[n], 0);
function O(e, t, n) {
	if (T.some((e) => !Number.isInteger(t[e]) || t[e] < 0 || t[e] > n[e]) || t.wildlife < e.wildlife) return !1;
	let r = 0;
	for (let n of [
		"mountain",
		"forest",
		"sun",
		"water"
	]) {
		if (t[n] > e[n]) return !1;
		r += e[n] - t[n];
	}
	return t.wildlife === e.wildlife + r;
}
function k(e, t) {
	let n = [];
	for (let r = 0; r <= Math.min(e.mountain, t.mountain); r++) for (let i = 0; i <= Math.min(e.forest, t.forest); i++) for (let a = 0; a <= Math.min(e.sun, t.sun); a++) for (let o = 0; o <= Math.min(e.water, t.water); o++) {
		let s = e.wildlife + e.mountain - r + e.forest - i + e.sun - a + e.water - o, c = {
			mountain: r,
			forest: i,
			sun: a,
			water: o,
			wildlife: s
		};
		O(e, c, t) && n.push(c);
	}
	return n;
}
function A(e) {
	return e.visited.map((e) => w[e]).filter((e) => !!e);
}
function j(e) {
	let t = A(e), n = (e) => t.reduce((t, n) => t + n.cost[e], 0), r = (e) => t.filter((t) => t.cost[e] > 0).length;
	switch (e.passion) {
		case "wildlife": return e.photographedWithWildlife;
		case "botany": return n("forest") >= 3;
		case "mountaineering": return r("mountain") >= 3;
		case "birdwatching": return r("sun") >= 2;
		case "kayaking": return r("water") >= 2;
		case "forestry": return r("forest") >= 3;
		case "collecting": return e.gear.length >= 2;
		case "swimming": return n("water") >= 3;
		case "rockClimbing": return n("mountain") >= 3;
		case "adventure": return t.filter((e) => e.bonus !== null).length >= 2;
	}
}
function M(e) {
	let t = A(e), n = (e) => t.reduce((t, n) => t + n.cost[e], 0), r = (e) => t.filter((t) => t.cost[e] > 0).length;
	switch (e.passion) {
		case "wildlife": return Math.floor(e.photos / 3);
		case "botany": return Math.floor(n("forest") / 2);
		case "mountaineering": return r("mountain");
		case "birdwatching": return r("sun");
		case "kayaking": return r("water");
		case "forestry": return r("forest");
		case "collecting": return e.gear.length;
		case "swimming": return Math.floor(n("water") / 2);
		case "rockClimbing": return Math.floor(n("mountain") / 2);
		case "adventure": return t.filter((e) => e.bonus !== null).length;
	}
}
function N(e, t) {
	let n = { ...e.cost }, r = t ? {
		mountaineering: "mountain",
		forestry: "forest",
		birdwatching: "sun",
		kayaking: "water"
	}[t] : void 0;
	return r && (n[r] = Math.max(0, n[r] - 1)), n;
}
//#endregion
//#region src/game/movement.ts
function P(e) {
	let t = new Set([...e.own, ...e.others.flat()].filter((e) => e >= 0 && e < 9)), n = e.others.every((e) => e.every((e) => e === 9)), r = [];
	for (let i of [0, 1]) {
		let a = e.own[i];
		if (a !== 9) for (let o = a + 1; o <= 9; o++) {
			if (o < 9 && (n || !e.siteUsable(o))) continue;
			let a = o < 9 && t.has(o);
			(!a || e.campfire) && r.push({
				hiker: i,
				destination: o,
				usesCampfire: a
			});
		}
	}
	return r;
}
function re(e, t, n, r) {
	if (e[0] === 9 && e[1] === 9) return null;
	let i = e[0] === e[1] ? 0 : r === "front" ? e[0] > e[1] ? 0 : 1 : e[0] < e[1] ? 0 : 1;
	e[i] === 9 && (i = +(i === 0));
	let a = e[i];
	if (n !== "next") return {
		hiker: i,
		destination: Math.min(9, a + n)
	};
	let o = new Set([...e, ...t.flat()].filter((e) => e >= 0 && e < 9)), s = a + 1;
	for (; s < 9 && o.has(s);) s++;
	return {
		hiker: i,
		destination: s
	};
}
//#endregion
//#region src/game/decisions.ts
function ie(e) {
	return T.filter((t) => e.backpack[t] > 0).map((e) => ({
		...E(),
		[e]: 1
	}));
}
function ae(e) {
	let t = [];
	for (let n = 0; n < T.length; n++) for (let r = n; r < T.length; r++) {
		let i = E();
		i[T[n]]++, i[T[r]]++, T.every((t) => i[t] <= e.backpack[t]) && t.push(i);
	}
	return t;
}
function F(e, t) {
	return t.canteens.some((e) => e.tokens.length < 2) && e.canteenDeckCount + e.canteenDisplay.length > 0;
}
function I(e, t) {
	return D(t.backpack) > 0 && e.photosLeft > 0 && (!e.projects.includes(7) || e.shutterbugOwner === t.rid);
}
function oe(e) {
	return e.passion !== null && S[e.passion] === "collecting" && e.passionChoice === "gear";
}
function se(e, t) {
	return k({
		...E(),
		sun: oe(e) ? 0 : t
	}, e.backpack);
}
function L(e, t) {
	return e.gearDeckCount > 0 && se(t, 2).length > 0 || e.gearMarket.some((e) => e >= 0 && se(t, x[e].cost).length > 0);
}
function ce(e, t) {
	return e.parkDeckCount > 0 || e.parkDisplay.some((e) => e >= 0) || t.reserved.some((e) => {
		let n = t.passionChoice === "gear" && t.passion !== null ? S[t.passion] : null;
		return k(N(w[e], n), t.backpack).length > 0;
	});
}
function le(e, t, n) {
	let r = D(t.backpack), i = e.supplies, a = t.backpack, o = i.wildlife > 0 && (!e.projects.includes(4) || a.wildlife < 1);
	switch (n) {
		case "photoToResources": return t.photos > 0 && i.mountain + i.forest + i.sun + i.water > 0;
		case "photoToWildlife2": return t.photos > 0 && o;
		case "wildlifeToForest3": return a.wildlife > 0 && i.forest > 0;
		case "wildlifeToMountain3": return a.wildlife > 0 && i.mountain > 0;
		case "mountainToSun5": return a.mountain > 0 && i.sun > 0;
		case "mountainToWater5": return a.mountain > 0 && i.water > 0;
		case "forestToSun5": return a.forest > 0 && i.sun > 0;
		case "forestToWater5": return a.forest > 0 && i.water > 0;
		case "sunToAny2": return a.sun > 0 && T.some((e) => e === "wildlife" ? o : i[e] > 0 || e === "sun");
		case "waterToAny2": return a.water > 0 && T.some((e) => e === "wildlife" ? o : i[e] > 0 || e === "water");
		case "sunToDice2": return a.sun > 0;
		case "waterToDice2": return a.water > 0;
		case "twoToWildlife2": return r >= 2 && (i.wildlife > 0 || a.wildlife > 0);
		case "canteenAndGear": return F(e, t) || L(e, t);
		case "parksAndPhoto": return ce(e, t) || I(e, t);
		case "badgeAndPhoto": return !0;
		case "gearAndSun2": return i.sun > 0 || L(e, t);
		case "mountainAndPhoto": return i.mountain > 0 || I(e, t);
		case "forestAndPhoto": return i.forest > 0 || I(e, t);
		case "wildlife": return o;
		case "chooseResources": return i.mountain + i.forest + i.sun + i.water > 0;
	}
}
function ue(e, t, n) {
	let r = e.trail[n], i = e.weather[n], a = i ? {
		...t,
		backpack: {
			...t.backpack,
			[i]: t.backpack[i] + 1
		}
	} : t, o = e.shutterbugSite === n ? {
		...e,
		shutterbugOwner: t.rid
	} : e;
	return r === "mountain" || r === "forest" || r === "sun" || r === "water" ? e.supplies[r] > 0 : r === "die" ? !0 : r === "wildlife" ? D(a.backpack) > 0 && (e.supplies.wildlife > 0 || a.backpack.wildlife > 0) : r === "photoCanteen" ? I(o, a) || F(e, a) : r === "gear" ? L(e, a) : ce(e, a);
}
function de(e, t, n) {
	return e.config.camping && e.tents.includes(n) && e.campsite !== null && ne[e.campsite].some((n, r) => !e.occupiedCampsites.includes(r) && le(e, t, n));
}
function fe(e, t) {
	let n = [...e.players.filter((e) => e.rid !== t.rid).map((e) => e.hikers), ...e.rangerHikers];
	return P({
		own: t.hikers,
		others: n,
		campfire: t.campfire,
		siteUsable: (n) => ue(e, t, n) || de(e, t, n)
	}).flatMap(({ hiker: n, destination: r }) => {
		let i = [];
		return (r === 9 || ue(e, t, r)) && i.push({
			type: "move",
			hiker: n,
			destination: r,
			camp: !1
		}), r < 9 && de(e, t, r) && i.push({
			type: "move",
			hiker: n,
			destination: r,
			camp: !0
		}), i;
	});
}
function R(e, t, n) {
	return n.mandatory ? n.source === "site" || n.source === "weather" || n.source === "camp" && n.kind !== "selectResource" ? !1 : n.kind === "photo" ? !I(e, t) : n.kind === "canteen" ? !F(e, t) : n.kind === "gear" ? !L(e, t) : n.kind === "parks" ? !ce(e, t) : n.kind === "selectResource" && T.every((n) => e.supplies[n] === 0 || n === "wildlife" && e.projects.includes(4) && t.backpack.wildlife >= 1) : !0;
}
function z(e, t, n, r) {
	let i = e.tasks.filter((e) => e.id !== r && e.source === "site" && e.mandatory);
	if (!i.length) return !0;
	let a = { ...t.backpack };
	for (let e of T) a[e] -= n[e];
	e.tasks.find((e) => e.id === r)?.kind === "tradeWildlife" && e.supplies.wildlife + n.wildlife > 0 && (!e.projects.includes(4) || a.wildlife < 1) && a.wildlife++;
	for (let i of e.tasks) {
		if (i.id === r) continue;
		let o = {
			gainMountain: "mountain",
			gainForest: "forest",
			gainSun: "sun",
			gainWater: "water",
			gainWildlife: "wildlife"
		}[i.kind];
		if (!o) continue;
		let s = i.source === "weather" ? 1 : e.supplies[o] + n[o], c = o === "wildlife" && e.projects.includes(4) ? Math.max(0, 1 - a.wildlife) : Infinity;
		if (a[o] += Math.min(i.amount, s, c), o === "water") {
			let r = t.canteens.filter((e) => !e.filled).map((e) => e.tokens.filter((e) => b[e] === "sun2").length * 2);
			a.sun += Math.min(e.supplies.sun + n.sun, Math.max(0, ...r));
		}
	}
	let o = {
		...t,
		backpack: a
	}, s = e.tasks.some((e) => e.kind === "badge" && e.source === "site") ? {
		...e,
		shutterbugOwner: t.rid
	} : e;
	return i.every((t) => t.kind === "gear" || t.kind === "site" && t.detail === "gear" ? L(e, o) : t.kind === "photo" ? I(s, o) : t.kind === "tradeWildlife" || t.kind === "site" && t.detail === "wildlife" ? D(a) > 0 && (e.supplies.wildlife + n.wildlife > 0 || a.wildlife > 0) : t.kind === "site" && t.detail === "photoCanteen" ? I(s, o) || F(e, o) : !0);
}
function pe(e, t, n) {
	if (e.tasks.some((e) => e.kind === "choosePassion")) return [];
	let r = [], i = (e, t = {}, i) => {
		r.push({
			kind: e,
			id: i,
			row: t.row,
			payment: t.payment,
			action: {
				type: "resolve",
				taskId: n.id,
				...t
			}
		});
	}, a = ie(t);
	if (n.kind === "site") {
		if (n.detail === "end") for (let [n, r] of [
			"parks",
			"photo",
			"gear"
		].entries()) {
			let a = n === 1 ? "wildlife" : "sun", o = n > 0 && !e.endClaims[n] && e.supplies[a] > 0 && (a !== "wildlife" || !e.projects.includes(4) || t.backpack.wildlife < 1) ? {
				...t,
				backpack: {
					...t.backpack,
					[a]: t.backpack[a] + 1
				}
			} : t;
			(r === "parks" && ce(e, t) || r === "photo" && I(e, o) || r === "gear" && L(e, o)) && i("end", { choice: r }, n);
		}
		else n.detail === "photoCanteen" ? (I(e, t) && i("photo", { choice: "photo" }), F(e, t) && i("canteen", { choice: "canteen" })) : (n.detail !== "parks" || ce(e, t)) && (n.detail !== "gear" || L(e, t)) && i("resolve");
	} else if (n.kind === "camp" && e.campsite !== null) ne[e.campsite].forEach((n, r) => {
		if (!e.occupiedCampsites.includes(r) && le(e, t, n)) {
			if (n === "chooseResources") for (let [t, n] of Object.entries({
				mountainSun: ["mountain", "sun"],
				mountainWater: ["mountain", "water"],
				forestSun: ["forest", "sun"],
				forestWater: ["forest", "water"]
			})) (e.supplies[n[0]] > 0 || e.supplies[n[1]] > 0) && i("camp", {
				index: r,
				choice: t
			}, r);
			else if (n === "twoToWildlife2") for (let n of ae(t)) e.supplies.wildlife + n.wildlife > 0 && (!e.projects.includes(4) || t.backpack.wildlife - n.wildlife < 1) && i("camp", {
				index: r,
				payment: n
			}, r);
			else i("camp", { index: r }, r);
		}
	});
	else if (n.kind === "parks") {
		if (n.detail === "1" ? i("resolve", { choice: "done" }) : (e.parkDeckCount && i("reserve", {
			choice: "reserve",
			index: -1
		}, -1), e.parkDisplay.forEach((e, t) => {
			e >= 0 && i("reserve", {
				choice: "reserve",
				index: t
			}, e);
		})), n.source !== "gearReserve" && n.source !== "seasonReserve") {
			let n = t.passionChoice === "gear" && t.passion !== null ? S[t.passion] : null, r = (r, a, o) => {
				for (let s of e.projects.includes(5) ? [0, 1] : [-1]) {
					let e = N(w[r], n);
					s >= 0 && e[s === 0 ? "mountain" : "forest"]++;
					for (let n of k(e, t.backpack)) i("visit", {
						choice: o,
						index: a,
						payment: n,
						...s >= 0 ? { row: s } : {}
					}, r);
				}
			};
			e.projects.includes(0) || e.parkDisplay.forEach((e, t) => {
				e >= 0 && r(e, t, "visitDisplay");
			}), t.reserved.forEach((e, t) => r(e, t, "visitReserved"));
		}
	} else if (n.kind === "gear") {
		if (e.gearDeckCount) for (let e of se(t, 2)) i("gear", {
			index: -1,
			payment: e
		}, -1);
		e.gearMarket.forEach((e, n) => {
			if (e >= 0) for (let r of se(t, x[e].cost)) i("gear", {
				index: n,
				payment: r
			}, e);
		});
	} else if (n.kind === "canteen") t.canteens.forEach((t, n) => {
		t.tokens.length >= 2 || (e.canteenDeckCount && i("canteen", {
			index: -1,
			row: n
		}, -1), e.canteenDisplay.forEach((e, t) => i("canteen", {
			index: t,
			row: n
		}, e)));
	});
	else if (n.kind === "photo" && I(e, t)) for (let e of a) i("photo", { payment: e });
	else if (n.kind === "tradeWildlife") for (let n of a) e.supplies.wildlife + n.wildlife > 0 && (!e.projects.includes(4) || t.backpack.wildlife - n.wildlife < 1) && i("wildlife", { payment: n });
	else if (n.kind === "selectResource") {
		if (!e.tasks.some((e) => e.id !== n.id && e.source === n.source && e.kind.startsWith("gain"))) for (let [n, r] of T.entries()) e.supplies[r] > 0 && (r !== "wildlife" || !e.projects.includes(4) || t.backpack.wildlife < 1) && i("resource", { choice: r }, n);
	} else if (n.kind.startsWith("gain")) {
		if (i("resolve"), n.kind === "gainWater" && t.canteens.forEach((r, a) => {
			if (r.filled || !r.tokens.length) return;
			let o = e.tasks.some((n) => n.source === "site" && (n.kind === "tradeWildlife" || n.kind === "photo" || n.kind === "site" && (n.detail === "wildlife" || n.detail === "photoCanteen" && !F(e, t)))), s = r.tokens.some((t) => {
				let n = b[t];
				return n === "sun2" && e.supplies.sun > 0 || n === "forest" && e.supplies.forest > 0 || n === "mountain" && e.supplies.mountain > 0;
			});
			(n.source !== "weather" || !o || D(t.backpack) > 0 || s) && i("waterRow", { row: a }, a);
		}), t.passion !== null && t.passionChoice === "gear" && (n.kind === "gainForest" && S[t.passion] === "botany" || n.kind === "gainMountain" && S[t.passion] === "rockClimbing")) {
			let r = n.kind === "gainForest" ? "forest" : "mountain";
			e.supplies[r] > 0 && e.supplies.wildlife > 0 && (!e.projects.includes(4) || t.backpack.wildlife < 1) && i("wildlife", { choice: "wildlife" });
		}
	} else n.kind === "useGear" ? n.gearId !== null && !e.usedGear.includes(n.gearId) && !e.tasks.some((e) => e.mandatory && e.source === "site") && i("gear", {}, n.gearId) : (n.kind === "badge" || n.kind === "die" || n.kind === "relight") && i("resolve");
	return R(e, t, n) && r.push({
		kind: "skip",
		action: {
			type: "skip",
			taskId: n.id
		}
	}), r.filter((r) => !r.payment || z(e, t, r.payment, n.id));
}
//#endregion
//#region src/game/meta.ts
var B = {
	id: "parks2",
	tier: "alpha",
	mechanics: [
		"worker-placement",
		"set-collection",
		"engine-building"
	],
	interactionTags: [],
	nameKey: "games.parks2.name",
	descKey: "games.parks2.desc",
	rulesKey: "games.parks2.rules",
	icon: "🏞️",
	iconImg: "games/parks2.webp",
	minPlayers: 1,
	maxPlayers: 5,
	bestPlayers: [
		2,
		3,
		4
	],
	accent: "#2b786c",
	releasedAt: "2026-11-13T12:16:08+08:00",
	search: {
		py: "guo jia gong yuan di er ban",
		init: "gjgydeb"
	},
	hotseat: "cover",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/16089773028220332793/562B05697071C4E3C0D0BEDD12C13FC35E449DF7/" }
};
//#endregion
//#region src/game/scoring.ts
function me(e, t, n) {
	if (t === 0) return e.backpack[[
		"forest",
		"sun",
		"mountain",
		"water"
	][n]];
	if (t === 1) switch (n) {
		case 0: return e.canteens.reduce((e, t) => e + t.tokens.length, 0);
		case 1: return e.gear.reduce((e, t) => e + (x[t]?.cost ?? 0), 0);
		case 2: return e.backpack.wildlife;
		case 3: return e.visited.filter((e) => w[e]?.bonus !== null).length;
		default: return 0;
	}
	let r = [
		"forest",
		"mountain",
		"sun",
		"water"
	];
	return e.visited.reduce((e, t) => e + (w[t]?.cost[r[n]] ?? 0), 0);
}
function V(e, t, n) {
	if (e.length === 1) return me(e[0], t, n) >= t + 3 ? [e[0].rid] : [];
	let r = e.map((e) => me(e, t, n)), i = Math.max(0, ...r);
	return i === 0 ? [] : e.filter((e, t) => r[t] === i).map((e) => e.rid);
}
function he(e, t) {
	return e.passionChoice === "score" && t ? M(t) : 0;
}
//#endregion
//#region src/game/schema.ts
var H = t.object({
	camping: t.boolean().default(!1),
	ranger: t.boolean().default(!1),
	projects: t.int().min(0).max(4).default(0),
	choosePassion: t.boolean().default(!1)
}).default({
	camping: !1,
	ranger: !1,
	projects: 0,
	choosePassion: !1
}), U = t.int().nonnegative(), W = t.object({
	mountain: U,
	forest: U,
	sun: U,
	water: U,
	wildlife: U
}), ge = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("move"),
		hiker: t.int().min(0).max(1),
		destination: t.int().min(0).max(9),
		camp: t.boolean().default(!1)
	}),
	t.object({
		type: t.literal("resolve"),
		taskId: U,
		choice: t.string().optional(),
		index: t.int().min(-1).max(100).optional(),
		row: t.int().min(-1).max(2).optional(),
		payment: W.optional()
	}),
	t.object({
		type: t.literal("skip"),
		taskId: U
	}),
	t.object({
		type: t.literal("selectPassion"),
		passion: t.int().min(0).max(9)
	}),
	t.object({
		type: t.literal("chooseRanger"),
		ranger: t.int().min(0).max(1)
	}),
	t.object({
		type: t.literal("passion"),
		choice: t.enum(["gear", "score"])
	}),
	t.object({
		type: t.literal("discard"),
		payment: W
	}),
	t.object({ type: t.literal("finish") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), _e = t.enum([
	"site",
	"weather",
	"badge",
	"camp",
	"gainMountain",
	"gainForest",
	"gainSun",
	"gainWater",
	"gainWildlife",
	"parks",
	"gear",
	"canteen",
	"photo",
	"tradeWildlife",
	"die",
	"relight",
	"selectResource",
	"trade",
	"choosePassion",
	"useGear"
]), ve = t.object({
	id: U,
	kind: _e,
	mandatory: t.boolean(),
	amount: U.default(1),
	source: t.string().default(""),
	gearId: t.int().min(0).max(36).nullable().default(null),
	detail: t.string().default("")
}), ye = t.object({
	tokens: t.array(t.int().min(0).max(23)).max(2),
	filled: t.boolean()
}), be = t.object({
	rid: t.string(),
	hikers: t.tuple([t.int().min(-1).max(9), t.int().min(-1).max(9)]),
	backpack: W,
	canteens: t.tuple([
		ye,
		ye,
		ye
	]),
	campfire: t.boolean(),
	reserved: t.array(t.int().min(0).max(62)),
	visited: t.array(t.int().min(0).max(62)),
	gear: t.array(t.int().min(0).max(36)),
	passion: t.int().min(0).max(9).nullable(),
	passionChoice: t.enum(["gear", "score"]).nullable(),
	photographedWithWildlife: t.boolean(),
	photos: U,
	photoAlbums: t.int().min(0).max(8).default(0),
	seasonPoints: U
}), xe = t.enum([
	"die",
	"wildlife",
	"forest",
	"sun",
	"photoCanteen",
	"gear",
	"water",
	"mountain",
	"parks"
]), Se = t.enum(["sun", "water"]).nullable(), Ce = t.object({
	config: H,
	players: t.array(be).min(1).max(5),
	active: t.string(),
	phase: t.enum([
		"choosePassion",
		"move",
		"resolve",
		"ranger",
		"discard",
		"season",
		"done"
	]),
	season: t.int().min(0).max(2),
	trail: t.array(xe).length(9),
	weather: t.array(Se).length(9),
	shutterbugSite: t.int().min(0).max(8),
	shutterbugOwner: t.string().nullable(),
	firstHiker: t.string(),
	parkDisplay: t.array(t.int().min(-1).max(62)),
	gearMarket: t.array(t.int().min(-1).max(36)),
	canteenDisplay: t.array(t.int().min(0).max(23)),
	parkDeckCount: U,
	gearDeckCount: U,
	canteenDeckCount: U,
	supplies: W,
	photosLeft: U,
	photoAlbumsLeft: t.int().min(0).max(8),
	seasonTiles: t.tuple([
		t.int().min(0).max(3),
		t.int().min(0).max(3),
		t.int().min(0).max(3)
	]),
	tents: t.array(t.int().min(0).max(8)),
	campsite: t.int().min(0).max(7).nullable(),
	occupiedCampsites: t.array(t.int().min(0).max(3)),
	projects: t.array(t.int().min(0).max(8)),
	rangerHikers: t.array(t.tuple([t.int().min(-1).max(9), t.int().min(-1).max(9)])),
	rangerQueue: t.array(t.int().min(0).max(1)),
	tasks: t.array(ve),
	usedGear: t.array(t.int().min(0).max(36)),
	endClaims: t.tuple([
		t.string().nullable(),
		t.string().nullable(),
		t.string().nullable()
	]),
	log: t.array(t.object({
		rid: t.string(),
		kind: t.string(),
		detail: t.string()
	})),
	scores: t.record(t.string(), t.number()),
	scoreBreakdown: t.record(t.string(), t.object({
		parks: U,
		photos: U,
		photoBonus: U,
		season: U,
		passion: U,
		firstHiker: U
	}))
}), we = t.object({ passionOptions: t.array(t.int().min(0).max(9)) }), G = "$ranger", K = (e) => Array.from({ length: e }, (e, t) => t);
function q(t, n) {
	let r = e(t.seed, t.cursor, n);
	return t.cursor += 1, r;
}
function J(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; t--) {
		let r = q(e, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
function Te(e) {
	let t = J(e, te);
	e.trail = [
		...t.slice(0, 4),
		"parks",
		...t.slice(4)
	], e.weather = Array.from({ length: 9 }, (t, n) => {
		if (n === 0) return null;
		let r = n % 2 ? "sun" : "water";
		return r === "sun" && e.projects.includes(6) || e.supplies[r] <= 0 ? null : (e.supplies[r]--, r);
	});
	let n = [
		"sun",
		"wildlife",
		"water",
		"mountain",
		"forest",
		"photoCanteen"
	], r = n[q(e, n.length)];
	e.shutterbugSite = e.trail.indexOf(r), e.tents = e.config.camping ? [
		4,
		6,
		8
	] : [], e.occupiedCampsites = [], e.endClaims = [
		null,
		null,
		null
	];
}
function Ee(e, t, n) {
	return {
		rid: e,
		hikers: [-1, -1],
		backpack: E(),
		canteens: [
			{
				tokens: [],
				filled: !1
			},
			{
				tokens: [],
				filled: !1
			},
			{
				tokens: [],
				filled: !1
			}
		],
		campfire: t,
		reserved: [],
		visited: [],
		gear: [],
		passion: n,
		passionChoice: null,
		photographedWithWildlife: !1,
		photos: 0,
		photoAlbums: 0,
		seasonPoints: 0
	};
}
function De(e, t, n) {
	let r = H.parse(e ?? void 0), i = {
		config: r,
		players: [],
		active: t[0],
		phase: "move",
		season: 0,
		trail: [],
		weather: [],
		shutterbugSite: 0,
		shutterbugOwner: null,
		firstHiker: t[0],
		parkDisplay: [],
		gearMarket: [],
		canteenDisplay: [],
		parkDeck: [],
		gearDeck: [],
		canteenDeck: [],
		supplies: {
			mountain: 16,
			forest: 16,
			sun: 30,
			water: 30,
			wildlife: 14
		},
		photosLeft: 20,
		photoAlbumsLeft: 8,
		seasonTiles: [
			0,
			0,
			0
		],
		tents: [],
		campsiteStack: [],
		occupiedCampsites: [],
		projects: [],
		rangerHikers: [],
		rangerQueue: [],
		rangerDeck: [],
		rangerDiscard: [],
		tasks: [],
		taskCounter: 0,
		usedGear: [],
		endClaims: [
			null,
			null,
			null
		],
		log: [],
		scores: {},
		scoreBreakdown: {},
		passionOptions: {},
		seed: n,
		cursor: 0,
		currentSite: null,
		photographedWithBadge: !1,
		waterPenaltyApplied: !1,
		seasonQueue: [],
		discardReturn: "resolve"
	};
	i.projects = J(i, K(9)).slice(0, r.projects), i.parkDeck = J(i, K(w.length).filter((e) => !i.projects.includes(3) || ![1, 3].includes(w[e].points))), i.gearDeck = J(i, K(x.length)), i.canteenDeck = J(i, K(b.length)), i.parkDisplay = i.parkDeck.splice(0, 3), i.gearMarket = i.gearDeck.splice(0, 3), i.canteenDisplay = i.canteenDeck.splice(0, 3);
	let a = J(i, K(S.length));
	i.players = t.map((e) => {
		let n = a.splice(0, r.choosePassion ? 2 : 1), o = Ee(e, t.length >= 4 && !i.projects.includes(8), r.choosePassion ? null : n[0]), s = i.canteenDeck.shift();
		return s !== void 0 && o.canteens[0].tokens.push(s), r.choosePassion && (i.passionOptions[e] = n), o;
	}), i.seasonTiles = [
		q(i, 4),
		q(i, 4),
		q(i, 4)
	], i.campsiteStack = J(i, K(4)).slice(0, 3).map((e) => e * 2 + q(i, 2));
	let o = t.length === 1 ? 2 : t.length === 2 && r.ranger ? 1 : 0;
	return i.rangerHikers = Array.from({ length: o }, () => [-1, -1]), i.rangerDeck = J(i, K(21)), i.firstHiker = o ? G : t[q(i, t.length)], i.active = i.firstHiker === G ? t[0] : i.firstHiker, i.phase = r.choosePassion ? "choosePassion" : "move", r.choosePassion && (i.active = t[0]), Te(i), !r.choosePassion && i.firstHiker === G && Ze(i), { state: i };
}
function Oe(e, t) {
	return {
		public: {
			config: e.config,
			players: e.players,
			active: e.active,
			phase: e.phase,
			season: e.season,
			trail: e.trail,
			weather: e.weather,
			shutterbugSite: e.shutterbugSite,
			shutterbugOwner: e.shutterbugOwner,
			firstHiker: e.firstHiker,
			parkDisplay: e.parkDisplay,
			gearMarket: e.gearMarket,
			canteenDisplay: e.canteenDisplay,
			parkDeckCount: e.parkDeck.length,
			gearDeckCount: e.gearDeck.length,
			canteenDeckCount: e.canteenDeck.length,
			supplies: e.supplies,
			photosLeft: e.photosLeft,
			photoAlbumsLeft: e.photoAlbumsLeft,
			seasonTiles: e.seasonTiles,
			tents: e.tents,
			campsite: e.config.camping ? e.campsiteStack[0] ?? null : null,
			occupiedCampsites: e.occupiedCampsites,
			projects: e.projects,
			rangerHikers: e.rangerHikers,
			rangerQueue: e.rangerQueue,
			tasks: e.tasks,
			usedGear: e.usedGear,
			endClaims: e.endClaims,
			log: e.log,
			scores: e.scores,
			scoreBreakdown: e.scoreBreakdown
		},
		private: { passionOptions: e.passionOptions[t] ?? [] }
	};
}
function Y(e, t, n, r = !0, i = 1, a = "", o = null) {
	e.tasks.push({
		id: e.taskCounter++,
		kind: t,
		source: n,
		mandatory: r,
		amount: i,
		detail: a,
		gearId: o
	});
}
function ke(e, t, n, r) {
	for (let i of t.gear) x[i]?.trigger !== n || e.usedGear.includes(i) || e.tasks.some((e) => e.kind === "useGear" && e.gearId === i) || Y(e, "useGear", r, !1, 1, "", i);
}
function X(e, t) {
	e.tasks = e.tasks.filter((e) => e.id !== t);
}
function Ae(e, t, n) {
	return !!(t && D(t) === n && T.every((n) => Number.isInteger(t[n]) && t[n] >= 0 && t[n] <= e.backpack[n]));
}
function je(e, t, n) {
	for (let r of T) t.backpack[r] -= n[r], e.supplies[r] += n[r];
}
function Me(e, t) {
	for (; e.photoAlbumsLeft > 0 && t.photos - 5 * t.photoAlbums >= 5;) t.photoAlbums++, e.photoAlbumsLeft--, e.photosLeft += 5;
}
function Ne(e, t, n) {
	for (let r = 0; r < n && e.photosLeft > 0; r++) t.photos++, e.photosLeft--, Me(e, t);
}
function Pe(e, t) {
	if (t.photos - 5 * t.photoAlbums > 0) {
		t.photos--, e.photosLeft++;
		return;
	}
	if (t.photoAlbums--, t.photos--, e.photoAlbumsLeft++, e.photosLeft < 4) for (let t of e.players) Me(e, t);
	e.photosLeft -= 4;
}
function Fe(e, t) {
	return t.canteens.some((e) => e.tokens.length < 2) && e.canteenDeck.length + e.canteenDisplay.length > 0;
}
function Ie(e, t) {
	return D(t.backpack) > 0 && e.photosLeft > 0 && (!e.projects.includes(7) || e.shutterbugOwner === t.rid);
}
function Le(e, t, n) {
	switch (n) {
		case "mountain":
		case "forest":
		case "sun":
		case "water": return e.supplies[n] > 0;
		case "die": return !0;
		case "wildlife": return D(t.backpack) > 0 && (e.supplies.wildlife > 0 || t.backpack.wildlife > 0);
		case "photoCanteen": return Ie(e, t) || Fe(e, t);
		case "gear": {
			let n = t.passion !== null && S[t.passion] === "collecting" && t.passionChoice === "gear", r = t.backpack.sun + t.backpack.wildlife;
			return e.gearDeck.length > 0 && (n || r >= 2) || e.gearMarket.some((e) => e >= 0 && (n || r >= x[e].cost));
		}
		case "parks": return e.parkDeck.length > 0 || e.parkDisplay.some((e) => e >= 0) || t.reserved.some((e) => k(N(w[e], t.passionChoice === "gear" && t.passion !== null ? S[t.passion] : null), t.backpack).length > 0);
	}
}
function Re(e, t, n) {
	let r = e.weather[n], i = r ? {
		...t,
		backpack: {
			...t.backpack,
			[r]: t.backpack[r] + 1
		}
	} : t;
	return Le(e.shutterbugSite === n ? {
		...e,
		shutterbugOwner: t.rid
	} : e, i, e.trail[n]);
}
function ze(e, t, n) {
	let r = t.photos > 0, i = D(t.backpack), a = e.supplies.wildlife > 0 && (!e.projects.includes(4) || t.backpack.wildlife < 1);
	switch (n) {
		case "photoToResources": return r && [
			"mountain",
			"forest",
			"sun",
			"water"
		].some((t) => e.supplies[t] > 0);
		case "photoToWildlife2": return r && a;
		case "wildlifeToForest3": return t.backpack.wildlife > 0 && e.supplies.forest > 0;
		case "wildlifeToMountain3": return t.backpack.wildlife > 0 && e.supplies.mountain > 0;
		case "mountainToSun5": return t.backpack.mountain > 0 && e.supplies.sun > 0;
		case "mountainToWater5": return t.backpack.mountain > 0 && e.supplies.water > 0;
		case "forestToSun5": return t.backpack.forest > 0 && e.supplies.sun > 0;
		case "forestToWater5": return t.backpack.forest > 0 && e.supplies.water > 0;
		case "sunToAny2": return t.backpack.sun > 0 && T.some((t) => t === "wildlife" ? a : e.supplies[t] > 0 || t === "sun");
		case "waterToAny2": return t.backpack.water > 0 && T.some((t) => t === "wildlife" ? a : e.supplies[t] > 0 || t === "water");
		case "sunToDice2": return t.backpack.sun > 0;
		case "waterToDice2": return t.backpack.water > 0;
		case "twoToWildlife2": return i >= 2 && (e.supplies.wildlife > 0 || t.backpack.wildlife > 0);
		case "canteenAndGear": return Fe(e, t) || Le(e, t, "gear");
		case "parksAndPhoto": return Le(e, t, "parks") || Ie(e, t);
		case "badgeAndPhoto": return !0;
		case "gearAndSun2": return e.supplies.sun > 0 || Le(e, t, "gear");
		case "mountainAndPhoto": return e.supplies.mountain > 0 || Ie(e, t);
		case "forestAndPhoto": return e.supplies.forest > 0 || Ie(e, t);
		case "wildlife": return a;
		case "chooseResources": return [
			"mountain",
			"forest",
			"sun",
			"water"
		].some((t) => e.supplies[t] > 0);
	}
}
function Be(e, t, n) {
	let r = e.campsiteStack[0];
	return e.config.camping && e.tents.includes(n) && r !== void 0 && ne[r].some((n, r) => !e.occupiedCampsites.includes(r) && ze(e, t, n));
}
function Z(e, t, n, r, i = !0) {
	Y(e, {
		mountain: "gainMountain",
		forest: "gainForest",
		sun: "gainSun",
		water: "gainWater",
		wildlife: "gainWildlife"
	}[t], r, i, n);
}
function Ve(e, t) {
	let n = b[t];
	n === "sun2" ? Z(e, "sun", 2, "canteen") : n === "forest" || n === "mountain" ? Z(e, n, 1, "canteen") : n === "tradeWildlife" ? Y(e, "tradeWildlife", "canteen", !1) : n === "tradePhoto" ? Y(e, "photo", "canteen", !1) : n === "parks" && Y(e, "parks", "canteen", !1, 1, "0");
}
function He(e, t) {
	let n = x[t].effect;
	n === "forest" || n === "mountain" || n === "wildlife" ? Z(e, n, 1, "gear") : n === "water2" ? Z(e, "water", 2, "gear") : n === "sun2" ? Z(e, "sun", 2, "gear") : n === "relightSun2" ? (Z(e, "sun", 2, "gear"), Y(e, "relight", "gear")) : n === "relight" ? Y(e, "relight", "gear") : n === "die" ? Y(e, "die", "gear") : n === "canteen" ? Y(e, "canteen", "gear") : n === "tradePhoto" ? Y(e, "photo", "gear") : n === "reserve" && Y(e, "parks", "gearReserve", !0, 1, "0");
}
function Ue(e, t) {
	t.passion === null || t.passionChoice !== null || e.tasks.some((e) => e.kind === "choosePassion") || j({
		...t,
		passion: S[t.passion]
	}) && Y(e, "choosePassion", "passion");
}
function We(e) {
	for (e.parkDisplay = e.parkDisplay.filter((e) => e >= 0), e.gearMarket = e.gearMarket.filter((e) => e >= 0); e.parkDisplay.length < 3 && e.parkDeck.length;) e.parkDisplay.unshift(e.parkDeck.shift());
	for (; e.gearMarket.length < 3 && e.gearDeck.length;) e.gearMarket.unshift(e.gearDeck.shift());
}
function Ge(e) {
	return e.players.every((e) => e.hikers.every((e) => e === 9)) && e.rangerHikers.every((e) => e.every((e) => e === 9));
}
function Ke(e) {
	let t = e.players.map((e) => e.photos), n = Math.max(0, ...t), r = t.filter((e) => e === n).length, i = Math.max(0, ...t.filter((e) => e < n));
	for (let t of e.players) {
		let a = 0;
		e.players.length > 1 && n > 0 && (t.photos === n ? a = e.players.length === 2 ? 3 : 4 : e.players.length > 2 && r === 1 && t.photos === i && i > 0 && (a = 2));
		let o = t.passion === null ? null : {
			...t,
			passion: S[t.passion]
		}, s = {
			parks: t.visited.reduce((e, t) => e + w[t].points, 0),
			photos: t.photos,
			photoBonus: a,
			season: t.seasonPoints,
			passion: he(t, o),
			firstHiker: +(e.firstHiker === t.rid)
		};
		e.scoreBreakdown[t.rid] = s, e.scores[t.rid] = Object.values(s).reduce((e, t) => e + t, 0);
	}
	e.phase = "done", e.tasks = [], e.rangerQueue = [];
}
function qe(e) {
	for (let t of e.weather) t && e.supplies[t]++;
	for (let t of e.players) {
		for (let n of t.canteens) n.filled && (n.filled = !1, e.supplies.water++);
		t.campfire = !e.projects.includes(8), t.hikers = [-1, -1];
	}
	e.rangerHikers = e.rangerHikers.map(() => [-1, -1]), e.rangerDeck = J(e, K(21)), e.rangerDiscard = [], e.config.camping && e.campsiteStack.shift(), e.gearMarket.length && e.gearMarket.pop(), We(e), e.season++, e.currentSite = null, e.usedGear = [], e.photographedWithBadge = !1, e.waterPenaltyApplied = !1, Te(e), e.firstHiker === G ? Ze(e) : (e.active = e.firstHiker, e.phase = "move");
}
function Je(e) {
	for (; e.seasonQueue.length;) {
		let t = e.seasonQueue.shift(), n = e.players.find((e) => e.rid === t);
		e.active = t, e.phase = "season", e.tasks = [], e.usedGear = [], e.photographedWithBadge = !1, e.waterPenaltyApplied = !1;
		let r = e.seasonTiles[e.season];
		if (e.season === 0) {
			if (r === 0 && e.parkDisplay.length + e.parkDeck.length) Y(e, "parks", "seasonReserve", !0, 1, "0");
			else if (r === 1) {
				let t = e.gearDeck.shift();
				t !== void 0 && n.gear.push(t);
			} else r === 2 && e.photosLeft > 0 && (!e.projects.includes(7) || e.shutterbugOwner === n.rid) ? (Ne(e, n, 1), ke(e, n, "photo", "seasonGear"), e.shutterbugOwner === n.rid && (e.photographedWithBadge = !0, Y(e, "photo", "badgeExtra", !1))) : r === 3 && n.canteens.some((e) => e.tokens.length < 2) && e.canteenDeck.length + e.canteenDisplay.length > 0 && Y(e, "canteen", "season");
		} else e.season === 1 && (Y(e, "die", "season"), Y(e, "die", "season"));
		if (Ue(e, n), e.tasks.length) return;
	}
	qe(e);
}
function Ye(e) {
	e.tasks = [], e.rangerQueue = [];
	let t = e.season, n = V(e.players, t, e.seasonTiles[t]);
	if (t === 2) {
		for (let t of n) e.players.find((e) => e.rid === t).seasonPoints += 3;
		Ke(e);
	} else e.seasonQueue = n, Je(e);
}
function Xe(e, t) {
	let n = e.rangerHikers[t];
	if (!n || n.every((e) => e === 9)) return;
	e.rangerDeck.length <= 1 && (e.rangerDeck = J(e, [...e.rangerDeck, ...e.rangerDiscard]), e.rangerDiscard = []);
	let r = e.rangerDeck.shift(), i = C[r], a = C[e.rangerDeck[0]].back, o = [...e.players.map((e) => e.hikers), ...e.rangerHikers.filter((e, n) => n !== t)], s = re(n, o, i.movement, a);
	if (e.rangerDiscard.push(r), !s) return;
	let c = o.every((e) => e.every((e) => e === 9)) ? 9 : s.destination;
	if (n[s.hiker] = c, c === 9) {
		let t = i.end === "parks" ? 0 : i.end === "photo" ? 1 : 2;
		e.endClaims[t] || (e.endClaims[t] = G, t === 0 && (e.firstHiker = G));
		return;
	}
	if (e.players.length === 1 && e.config.camping && e.tents.includes(c) && e.occupiedCampsites.length < 4) {
		e.tents = e.tents.filter((e) => e !== c);
		let t = [
			3,
			2,
			1,
			0
		].find((t) => !e.occupiedCampsites.includes(t));
		e.occupiedCampsites.push(t);
		return;
	}
	let l = e.weather[c];
	l && (e.supplies[l]++, e.weather[c] = null), e.players.length === 1 && (e.shutterbugSite === c && (e.shutterbugOwner = G), e.trail[c] === "parks" && e.parkDisplay.length && e.parkDisplay.pop(), e.trail[c] === "gear" && e.gearMarket.length && e.gearMarket.pop(), We(e));
}
function Ze(e) {
	if (e.rangerQueue = e.rangerHikers.map((e, t) => t).filter((t) => e.rangerHikers[t].some((e) => e !== 9)), !e.rangerQueue.length) {
		Qe(e, G);
		return;
	}
	if (e.players.length === 1) {
		e.phase = "ranger", e.active = e.players[0].rid;
		return;
	}
	Xe(e, e.rangerQueue[0]), e.rangerQueue = [], Qe(e, G);
}
function Qe(e, t) {
	if (Ge(e)) {
		Ye(e);
		return;
	}
	let n = [...e.players.map((e) => e.rid), ...e.rangerHikers.length ? [G] : []], r = n.indexOf(t);
	for (let t = 0; t < n.length; t++) {
		r = (r + 1) % n.length;
		let t = n[r];
		if (t === G) {
			if (e.rangerHikers.some((e) => e.some((e) => e !== 9))) {
				Ze(e);
				return;
			}
		} else if (e.players.find((e) => e.rid === t).hikers.some((e) => e !== 9)) {
			e.active = t, e.phase = "move";
			return;
		}
	}
	Ge(e) && Ye(e);
}
function $e(e, t, n) {
	let r = () => ({ code: "games.parks2.errAction" });
	if (t.type === "tick") return { state: e };
	if (n.by !== e.active) return { code: "games.parks2.errTurn" };
	let i = structuredClone(e), a = i.players.find((e) => e.rid === n.by);
	if (!a) return r();
	let o = [];
	if (t.type === "selectPassion") {
		if (i.phase !== "choosePassion" || !i.passionOptions[a.rid]?.includes(t.passion)) return r();
		a.passion = t.passion, delete i.passionOptions[a.rid];
		let e = i.players.find((e) => e.passion === null);
		return e ? i.active = e.rid : i.firstHiker === G ? Ze(i) : (i.phase = "move", i.active = i.firstHiker), { state: i };
	}
	if (t.type === "chooseRanger") return i.phase !== "ranger" || !i.rangerQueue.includes(t.ranger) ? r() : (Xe(i, t.ranger), i.rangerQueue = i.rangerQueue.filter((e) => e !== t.ranger), i.rangerQueue.length || Qe(i, G), { state: i });
	if (i.tasks.some((e) => e.kind === "choosePassion") && t.type !== "passion") return r();
	if (t.type === "move") {
		if (i.phase !== "move") return r();
		let e = [...i.players.filter((e) => e.rid !== a.rid).map((e) => e.hikers), ...i.rangerHikers], n = P({
			own: a.hikers,
			others: e,
			campfire: a.campfire,
			siteUsable: (e) => Re(i, a, e) || Be(i, a, e)
		}).find((e) => e.hiker === t.hiker && e.destination === t.destination);
		if (!n || t.camp && !Be(i, a, t.destination) || t.destination < 9 && !t.camp && !Re(i, a, t.destination)) return r();
		n.usesCampfire && (a.campfire = !1);
		let o = a.hikers[t.hiker], s = [...i.players.flatMap((e) => e.hikers.map((t, n) => ({
			key: `${e.rid}-${n}`,
			site: t
		}))), ...i.rangerHikers.flatMap((e, t) => e.map((e, n) => ({
			key: `ranger-${t}-${n}`,
			site: e
		})))].filter((e) => e.site === o).findIndex((e) => e.key === `${a.rid}-${t.hiker}`);
		if (a.hikers[t.hiker] = t.destination, i.phase = "resolve", i.currentSite = t.destination, i.tasks = [], i.usedGear = [], i.photographedWithBadge = !1, i.waterPenaltyApplied = !1, t.destination === 9) Y(i, "site", "site", !0, 1, "end");
		else if (t.camp) Y(i, "camp", "camp", !0, 1, String(t.destination));
		else {
			let e = i.weather[t.destination];
			e && (i.weather[t.destination] = null, Z(i, e, 1, "weather")), i.shutterbugSite === t.destination && Y(i, "badge", "site"), Y(i, "site", "site", !0, 1, i.trail[t.destination]);
		}
		return i.log.push({
			rid: a.rid,
			kind: "move",
			detail: String(t.destination)
		}), i.log = i.log.slice(-20), {
			state: i,
			fx: [{
				kind: "hiker",
				rid: a.rid,
				data: {
					hiker: t.hiker,
					from: o,
					fromSlot: s
				}
			}]
		};
	}
	if (t.type === "passion") {
		let e = i.tasks.find((e) => e.kind === "choosePassion");
		return !e || a.passion === null || a.passionChoice !== null ? r() : (a.passionChoice = t.choice, X(i, e.id), { state: i });
	}
	if (t.type === "discard") {
		let e = Math.max(0, 12 - (i.projects.includes(1) ? a.gear.length : 0)), n = Math.max(0, D(a.backpack) - e);
		return i.phase !== "discard" || n === 0 || !Ae(a, t.payment, n) ? r() : (je(i, a, t.payment), i.phase = i.discardReturn, { state: i });
	}
	if (t.type === "finish") {
		if (i.phase !== "resolve" && i.phase !== "season" || i.tasks.some((e) => e.mandatory)) return r();
		let e = Math.max(0, 12 - (i.projects.includes(1) ? a.gear.length : 0));
		return D(a.backpack) > e ? (i.discardReturn = i.phase, i.phase = "discard", { state: i }) : (i.tasks = [], We(i), i.phase === "season" ? Je(i) : Qe(i, a.rid), { state: i });
	}
	if (t.type === "skip") {
		let e = i.tasks.find((e) => e.id === t.taskId);
		return !e || i.phase !== "resolve" && i.phase !== "season" || e.mandatory && (e.source === "site" || e.source === "weather" || e.source === "camp" && e.kind !== "selectResource" || !(e.kind === "photo" && !Ie(i, a) || e.kind === "canteen" && !Fe(i, a) || e.kind === "gear" && !Le(i, a, "gear") || e.kind === "parks" && !Le(i, a, "parks") || e.kind === "selectResource" && T.every((e) => i.supplies[e] === 0 || e === "wildlife" && i.projects.includes(4) && a.backpack.wildlife >= 1))) ? r() : (X(i, e.id), { state: i });
	}
	if (t.type === "resolve") {
		if (i.phase !== "resolve" && i.phase !== "season") return r();
		let e = i.tasks.find((e) => e.id === t.taskId);
		if (!e || t.payment && !z(Oe(i, a.rid).public, a, t.payment, e.id)) return r();
		if (e.kind === "camp") {
			let n = i.campsiteStack[0], o = t.index;
			if (n === void 0 || o === void 0 || o < 0 || o > 3 || i.occupiedCampsites.includes(o)) return r();
			let s = ne[n][o];
			if (!ze(i, a, s)) return r();
			let c = (e) => {
				let t = {
					...E(),
					[e]: 1
				};
				je(i, a, t);
			};
			if (s === "photoToResources" || s === "photoToWildlife2") Pe(i, a), s === "photoToResources" ? (Z(i, "mountain", 1, "camp"), Z(i, "forest", 1, "camp"), Z(i, "sun", 1, "camp"), Z(i, "water", 1, "camp")) : Z(i, "wildlife", 2, "camp");
			else if (s === "canteenAndGear") Y(i, "canteen", "camp", !1), Y(i, "gear", "camp", !1);
			else if (s === "parksAndPhoto") Y(i, "parks", "camp", !1, 1, "0"), Y(i, "photo", "camp", !1);
			else if (s === "badgeAndPhoto") Y(i, "badge", "camp"), Y(i, "photo", "camp", !1);
			else if (s === "mountainAndPhoto" || s === "forestAndPhoto") Z(i, s === "mountainAndPhoto" ? "mountain" : "forest", 1, "camp"), Y(i, "photo", "camp", !1);
			else if (s === "gearAndSun2") Z(i, "sun", 2, "camp"), Y(i, "gear", "camp", !1);
			else if (s === "wildlife") Z(i, "wildlife", 1, "camp");
			else if (s === "chooseResources") {
				let e = {
					mountainSun: ["mountain", "sun"],
					mountainWater: ["mountain", "water"],
					forestSun: ["forest", "sun"],
					forestWater: ["forest", "water"]
				}[t.choice];
				if (!e || i.supplies[e[0]] === 0 && i.supplies[e[1]] === 0) return r();
				Z(i, e[0], 1, "camp"), Z(i, e[1], 1, "camp");
			} else if (s === "twoToWildlife2") {
				if (!Ae(a, t.payment, 2) || i.projects.includes(4) && a.backpack.wildlife - t.payment.wildlife >= 1 || i.supplies.wildlife + t.payment.wildlife === 0) return r();
				je(i, a, t.payment), Z(i, "wildlife", 2, "camp");
			} else {
				let e = {
					wildlifeToForest3: "wildlife",
					wildlifeToMountain3: "wildlife",
					mountainToSun5: "mountain",
					mountainToWater5: "mountain",
					forestToSun5: "forest",
					forestToWater5: "forest",
					sunToAny2: "sun",
					sunToDice2: "sun",
					waterToAny2: "water",
					waterToDice2: "water"
				}[s];
				if (!e || a.backpack[e] < 1) return r();
				c(e), s === "wildlifeToForest3" ? Z(i, "forest", 3, "camp") : s === "wildlifeToMountain3" ? Z(i, "mountain", 3, "camp") : s === "mountainToSun5" || s === "forestToSun5" ? Z(i, "sun", 5, "camp") : s === "mountainToWater5" || s === "forestToWater5" ? Z(i, "water", 5, "camp") : s === "sunToAny2" || s === "waterToAny2" ? Y(i, "selectResource", "camp", !0, 2) : (s === "sunToDice2" || s === "waterToDice2") && (Y(i, "die", "camp"), Y(i, "die", "camp"));
			}
			i.tents = i.tents.filter((t) => t !== Number(e.detail)), i.occupiedCampsites.push(o), X(i, e.id);
		} else if (e.kind === "selectResource") {
			if (i.tasks.some((t) => t.id !== e.id && t.source === e.source && t.kind.startsWith("gain"))) return r();
			let n = t.choice;
			if (!T.includes(n) || i.supplies[n] <= 0 || n === "wildlife" && i.projects.includes(4) && a.backpack.wildlife >= 1) return r();
			Z(i, n, 1, e.source), e.amount--, e.amount === 0 && X(i, e.id);
		} else if (e.kind === "badge") i.shutterbugOwner = a.rid, X(i, e.id);
		else if (e.kind === "site") {
			let n = e.detail, o = n, s = a;
			if (n === "end") {
				if (![
					"parks",
					"photo",
					"gear"
				].includes(t.choice ?? "")) return r();
				o = t.choice;
				let e = o === "parks" ? 0 : o === "photo" ? 1 : 2;
				if (!i.endClaims[e]) {
					if (i.endClaims[e] = a.rid, e === 0) i.firstHiker = a.rid;
					else {
						let t = e === 1 ? "wildlife" : "sun";
						i.supplies[t] > 0 && (t !== "wildlife" || !i.projects.includes(4) || a.backpack.wildlife < 1) && (s = {
							...a,
							backpack: {
								...a.backpack,
								[t]: a.backpack[t] + 1
							}
						}), Z(i, t, 1, "end");
					}
				}
			} else if (n === "photoCanteen") {
				if (t.choice !== "photo" && t.choice !== "canteen") return r();
				o = t.choice;
			}
			if (o === "photo" && (D(s.backpack) === 0 || i.photosLeft === 0) || o === "photo" && i.projects.includes(7) && i.shutterbugOwner !== a.rid || o === "canteen" && (!a.canteens.some((e) => e.tokens.length < 2) || i.canteenDeck.length + i.canteenDisplay.length === 0) || o === "gear" && !Le(i, s, "gear") || o === "parks" && !Le(i, a, "parks")) return r();
			X(i, e.id), o === "mountain" || o === "forest" ? Z(i, o, 1, "site") : o === "sun" || o === "water" ? Z(i, o, 2, "site") : o === "die" ? Y(i, "die", "site") : o === "wildlife" ? Y(i, "tradeWildlife", "site") : o === "parks" ? Y(i, "parks", "site", !0, 1, "0") : o === "gear" ? Y(i, "gear", "site") : o === "photo" ? Y(i, "photo", "site") : o === "canteen" && Y(i, "canteen", "site");
			let c = {
				mountain: "siteMountain",
				forest: "siteForest",
				sun: "siteSun",
				water: "siteWater"
			};
			n in c && ke(i, a, c[n], "siteGear");
		} else if (e.kind === "useGear") {
			if (e.gearId === null || !a.gear.includes(e.gearId) || i.usedGear.includes(e.gearId) || i.tasks.some((e) => e.mandatory && e.source === "site")) return r();
			i.usedGear.push(e.gearId), He(i, e.gearId), X(i, e.id);
		} else if (e.kind === "relight") a.campfire = !0, X(i, e.id);
		else if (e.kind === "die") {
			let t = q(i, 6);
			t === 0 ? Z(i, "sun", 2, "die") : t === 1 ? Z(i, "wildlife", 1, "die") : t === 2 ? Z(i, "water", 2, "die") : t === 3 ? Z(i, "mountain", 1, "die") : t === 4 ? Z(i, "forest", 1, "die") : Y(i, "canteen", "die"), ke(i, a, "die", "eventGear"), X(i, e.id);
		} else if (e.kind === "tradeWildlife") {
			if (!Ae(a, t.payment, 1) || i.supplies.wildlife + t.payment.wildlife === 0 || i.projects.includes(4) && a.backpack.wildlife - t.payment.wildlife >= 1) return r();
			je(i, a, t.payment), Z(i, "wildlife", 1, "trade"), ke(i, a, "tradeWildlife", "eventGear"), X(i, e.id);
		} else if (e.kind === "photo") {
			if (!Ae(a, t.payment, 1) || i.photosLeft === 0 || i.projects.includes(7) && i.shutterbugOwner !== a.rid) return r();
			let n = t.payment.wildlife > 0;
			je(i, a, t.payment), Ne(i, a, n && a.passion !== null && S[a.passion] === "wildlife" && a.passionChoice === "gear" ? 2 : 1), n && (a.photographedWithWildlife = !0), ke(i, a, "photo", "eventGear"), i.shutterbugOwner === a.rid && !i.photographedWithBadge && e.source !== "badgeExtra" && (i.photographedWithBadge = !0, Y(i, "photo", "badgeExtra", !1)), X(i, e.id);
		} else if (e.kind === "canteen") {
			let n = t.row === void 0 || t.row < 0 ? void 0 : a.canteens[t.row];
			if (!n || n.tokens.length >= 2 || t.index === void 0) return r();
			let s = t.index === -1 ? i.canteenDeck.shift() : i.canteenDisplay[t.index];
			if (s === void 0) return r();
			if (t.index >= 0) {
				i.canteenDisplay.splice(t.index, 1);
				let e = i.canteenDeck.shift();
				e !== void 0 && i.canteenDisplay.push(e);
			}
			n.tokens.push(s), X(i, e.id), o.push({
				kind: "canteen",
				rid: a.rid,
				data: {
					token: s,
					from: t.index
				}
			});
		} else if (e.kind === "gear") {
			if (t.index === void 0 || !t.payment) return r();
			let n = t.index === -1, s = n ? i.gearDeck[0] : i.gearMarket[t.index];
			if (s === void 0 || s < 0) return r();
			let c = a.passion !== null && S[a.passion] === "collecting" && a.passionChoice === "gear";
			if (!O({
				...E(),
				sun: c ? 0 : n ? 2 : x[s].cost
			}, t.payment, a.backpack)) return r();
			je(i, a, t.payment), n ? i.gearDeck.shift() : i.gearMarket[t.index] = -1, a.gear.push(s), X(i, e.id), o.push({
				kind: "gearCard",
				rid: a.rid,
				data: {
					id: s,
					from: t.index
				}
			});
		} else if (e.kind === "parks") {
			if (t.choice === "done") {
				if (e.detail !== "1") return r();
				X(i, e.id);
			} else if (t.choice === "reserve") {
				if (e.detail === "1" || t.index === void 0) return r();
				let n = t.index === -1 ? i.parkDeck.shift() : i.parkDisplay[t.index];
				if (n === void 0 || n < 0) return r();
				t.index >= 0 && (i.parkDisplay[t.index] = -1), a.reserved.push(n), ke(i, a, "reserve", "eventGear"), X(i, e.id), o.push({
					kind: "parkCard",
					rid: a.rid,
					data: {
						id: n,
						from: t.index,
						reserved: !0
					}
				});
			} else if (t.choice === "visitDisplay" || t.choice === "visitReserved") {
				if (e.source === "gearReserve" || e.source === "seasonReserve" || t.index === void 0 || t.index < 0 || !t.payment) return r();
				let n = t.choice === "visitDisplay";
				if (n && i.projects.includes(0)) return r();
				let s = n ? i.parkDisplay : a.reserved, c = s[t.index];
				if (c === void 0 || c < 0) return r();
				let l = a.passionChoice === "gear" && a.passion !== null ? S[a.passion] : null, u = N(w[c], l);
				if (i.projects.includes(5)) {
					if (t.row !== 0 && t.row !== 1) return r();
					u[t.row === 0 ? "mountain" : "forest"]++;
				}
				if (!O(u, t.payment, a.backpack)) return r();
				je(i, a, t.payment), n ? s[t.index] = -1 : s.splice(t.index, 1), a.visited.push(c), e.detail = "1", n && o.push({
					kind: "parkCard",
					rid: a.rid,
					data: {
						id: c,
						from: t.index,
						reserved: !1
					}
				});
				let d = w[c].bonus;
				d === "water1" || d === "water2" ? Z(i, "water", d === "water1" ? 1 : 2, "park") : d === "sun1" || d === "sun2" ? Z(i, "sun", d === "sun1" ? 1 : 2, "park") : d === "wildlife" ? Z(i, "wildlife", 1, "park") : d === "canteen" ? Y(i, "canteen", "park") : d === "die" ? Y(i, "die", "park") : d === "shutterbug" && Y(i, "badge", "park"), d && l === "adventure" && Y(i, "die", "passion");
			} else return r();
		} else if (e.kind === "gainMountain" || e.kind === "gainForest" || e.kind === "gainSun" || e.kind === "gainWater" || e.kind === "gainWildlife") {
			let n = {
				gainMountain: "mountain",
				gainForest: "forest",
				gainSun: "sun",
				gainWater: "water",
				gainWildlife: "wildlife"
			}[e.kind], o = a.passion === null || a.passionChoice !== "gear" ? null : S[a.passion], s = t.choice === "wildlife" && (n === "forest" && o === "botany" || n === "mountain" && o === "rockClimbing");
			if (t.choice === "wildlife" && !s || s && i.supplies[n] <= 0) return r();
			let c = s ? "wildlife" : n, l = c === "wildlife" && i.projects.includes(4) ? Math.max(0, 1 - a.backpack.wildlife) : Infinity, u = Math.min(l, e.source === "weather" ? 1 : i.supplies[c]);
			if (s && u <= 0) return r();
			if (u <= 0) return X(i, e.id), { state: i };
			let d = c === "water" || s ? 1 : Math.min(e.amount, u);
			if (c === "water" && t.row !== void 0 && t.row >= 0) {
				let n = a.canteens[t.row];
				if (!n || n.filled || n.tokens.length === 0) return r();
				let o = i.tasks.some((e) => e.source === "site" && (e.kind === "tradeWildlife" || e.kind === "photo" || e.kind === "site" && (e.detail === "wildlife" || e.detail === "photoCanteen" && !Fe(i, a)))), s = n.tokens.some((e) => {
					let t = b[e];
					return t === "sun2" && i.supplies.sun > 0 || t === "forest" && i.supplies.forest > 0 || t === "mountain" && i.supplies.mountain > 0;
				});
				if (e.source === "weather" && o && D(a.backpack) === 0 && !s) return r();
				n.filled = !0;
				for (let e of n.tokens) Ve(i, e);
				a.passion !== null && S[a.passion] === "swimming" && a.passionChoice === "gear" && Y(i, "die", "passion");
			} else a.backpack[c] += d;
			e.source !== "weather" && (i.supplies[c] -= d), c === "sun" && i.projects.includes(2) && !i.waterPenaltyApplied && a.backpack.water > 0 && (a.backpack.water--, i.supplies.water++, i.waterPenaltyApplied = !0), e.amount -= d, (e.amount <= 0 || !s && e.source !== "weather" && i.supplies[c] === 0) && X(i, e.id);
		} else return r();
		return Ue(i, a), {
			state: i,
			fx: o
		};
	}
	return r();
}
function et(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => (e.scores[n.rid] ?? 0) - (e.scores[t.rid] ?? 0) || n.visited.length - t.visited.length);
	return {
		phase: "done",
		winner: t.filter((n) => e.scores[n.rid] === e.scores[t[0].rid] && n.visited.length === t[0].visited.length).map((e) => e.rid),
		ranking: t.map((e) => e.rid),
		scores: e.scores
	};
}
var tt = {
	meta: B,
	saveCompatibility: { version: "2" },
	schemas: {
		action: ge,
		config: H,
		publicView: Ce,
		privateView: we
	},
	setup: De,
	reduce: $e,
	viewFor: Oe,
	status: et
}, nt = [
	[66, 38],
	[282, 38],
	[282, 130],
	[66, 130],
	[66, 222],
	[282, 222],
	[282, 314],
	[66, 314],
	[66, 406],
	[282, 406],
	[282, 498]
];
function rt(e, t) {
	let [n, r] = nt[e + 1] ?? nt[0];
	if (e === -1) return {
		x: n / 348 * 100,
		y: r / 546 * 100,
		dx: 22 + t % 5 * 31 - n,
		dy: 22 + Math.floor(t / 5) * 31 - r
	};
	let i = -Math.PI * .4 + t % 5 * Math.PI * .4, a = t < 5 ? 38 : 53, o = Math.max(18, Math.min(330, n + Math.cos(i) * a)) - n, s = Math.max(18, Math.min(528, r + Math.sin(i) * a)) - r;
	return {
		x: n / 348 * 100,
		y: r / 546 * 100,
		dx: o,
		dy: s
	};
}
function it(e, t) {
	return rt(e, t);
}
//#endregion
//#region src/game/locales/en.ts
var at = {
	name: "Parks (Second Edition)",
	desc: "Hike through three seasons, gather resources, visit national parks, and capture the journey in photos.",
	rules: "Goal:\nVisit parks, take photos, and complete your personal passion objective over three seasons. The player with the most points after the third season wins.\n\nSetup:\n· Each player receives two hikers, a player board, a passion card, and a random canteen token. Campfires start lit with four or five players and extinguished with one to three players.\n· Shuffle the eight trail sites and place the Parks site in the middle. Starting at the second site, alternate sun and water as weather. Roll the trail die and place the Shutterbug marker at the corresponding site.\n· Reveal three park cards, three gear cards, and three canteen tokens in their displays. Randomly choose a season tile for each season.\n· Optional rules add camping, a two-player ranger, volunteer projects, and a choice between two passion cards.\n\nHiking:\nThe player with the First Hiker token begins; play proceeds clockwise. On your turn, move either hiker any distance forward to a trail site and perform its action. Hikers cannot move backwards. You must be able to perform the site's action to stop there.\nHikers may share a site, but you must extinguish your campfire when entering an occupied site. You cannot share another site until your campfire is relit. When you are the only player with hikers left on the trail, move each remaining hiker directly to Trail's End.\nThe first hiker to reach a site with weather collects that token. You may take the weather and the site action in either order. When you reach the Shutterbug site, take the Shutterbug Badge; the marker stays on the trail.\n\nResources and sites:\n· Mountains, forests, sun, water, and wildlife are finite. If a resource is unavailable in the supply, you cannot gain it. At the end of your turn, discard resources above your backpack limit of 12.\n· Wildlife can replace other resources when visiting parks, buying gear, or taking photos. A wildlife symbol printed in a park's cost must be paid with wildlife.\n· Mountain and forest sites each give one matching resource; sun and water sites each give two.\n· At the die site, roll the trail die and gain its benefit.\n· At the wildlife site, trade one resource from your backpack for one wildlife.\n· At the photo/canteen site, choose to gain a canteen token or pay one backpack resource to take a photo.\n· At the gear site, buy one gear card.\n· At the Parks site, reserve one park or visit one or more parks.\n\nParks and gear:\nTo reserve a park, take a card from the display or the top of the deck into your reserve. Only you may visit a park in your reserve. To visit, choose a park in the display or your reserve, pay its printed resource cost, and place it in your visited parks. You may visit several parks during one Parks action. Resolve a park's instant benefit when you visit it; it may help you visit another park. Refill the park display after your entire turn ends.\nTo buy gear, pay its printed sun cost for a card in the market, or pay two sun to draw the top card of the gear deck. Gear is ready immediately. After completing your trail site action, you may use gear whose trigger was met. Each gear card may be used at most once per turn. Refill the market after your turn ends.\n\nCanteens and photos:\nWhen gaining a canteen, choose a displayed token or draw the top token and place it in an empty space on your player board. Immediately replace a token taken from the display. Each row holds up to two tokens.\nWhenever you gain water, put it in your backpack or in a canteen row that has at least one token and no water, then gain all benefits on that row. A row can be filled once per season; water already in your backpack cannot fill it. A token added to a filled row does not activate that season.\nTo take a photo, pay one resource and gain one photo token worth 1 point at the end. Exchange five photos for a 5-point album token, returning the single photo tokens to the supply. While holding the Shutterbug Badge, once per turn after taking a photo you may pay another resource to take a second photo.\n\nPassions, Trail's End, and seasons:\nEach passion card has an objective. As soon as you complete it on your turn, choose either its ongoing ability or its end-game bonus. This choice cannot be changed.\nAt Trail's End, choose the Parks, photo, or gear action. The first hiker to choose each action also gains its bonus: the First Hiker token at Parks, one wildlife at photo, or one sun at gear. The bonus may be used for that same action. Hikers remain at Trail's End until the season ends.\nAfter all hikers reach Trail's End, compare the season objective. The player with the most matching items, provided they have at least one, gains its reward; all tied players receive it. Spring rewards are printed on the tile, summer rewards are two trail die rolls, and the fall reward is 3 points. Then empty canteens, relight campfires, reset hikers and rearrange the trail. Discard the rightmost market gear and refill the market.\n· In spring, compare the pictured resource in each backpack. The reward is a park reservation, a free gear card from the deck, a free photo, or a canteen token, depending on the tile.\n· In summer, compare the number of canteen tokens, total sun cost on gear cards, wildlife in backpacks, or visited parks with instant benefits, as shown on the tile.\n· In fall, compare the number of the pictured resource icons in the costs of visited parks.\n\nCamping and Ranger Teddy:\nWith camping enabled, a site with a tent lets you place that tent on an open space of the current campsite tile and take its action. When camping, you do not take the trail site's action, its weather, the Shutterbug Badge, or gear effects triggered by that site. Replace the campsite tile each season.\nThe ranger begins the game with the First Hiker token and moves before the players, then takes turns in order with them.\n· A two-player game may add one ranger set. On each ranger turn, reveal one ranger card and move one hiker.\n· Solo play uses two ranger sets. On each ranger turn, reveal a separate card and move one hiker from each set that has not finished; choose which set moves first.\n· The revealed card directs the hiker to the next unoccupied site or exactly 2 or 3 spaces forward. A numbered move may share a site. The newly revealed back on top of the deck determines whether the front or back hiker in that set moves; if both occupy the same site, either hiker may move.\n· When a ranger lands on weather, return that token to the supply. At Trail's End, the ranger claims the action space shown on the revealed card and may take the First Hiker token.\n· In solo play, the ranger also takes the Shutterbug Badge and removes the rightmost displayed park or gear card when reaching its corresponding site, then refills that display. With camping enabled, a ranger reaching a tent moves it to the rightmost unoccupied campsite; the ranger does not take the site's weather, badge, or action.\nSolo season rewards require at least 3, 4, and 5 matching items in spring, summer, and fall respectively.\nVolunteer projects add challenges at any player count. Each revealed project changes a rule and must be followed when possible.\n\nFinal scoring:\nAfter the third season, add points for visited parks, 1 point per photo, the photo bonus, the fall reward, a chosen passion end-game bonus, and 1 point for the First Hiker token.\n· In a two-player game the most photos earn 3 points; with three to five players the most earn 4 points and the second-most earn 2.\n· Players with no photos do not receive a photo bonus.\n· Players tied for the most each receive the first-place bonus, with no second-place bonus awarded; players tied for second each receive the second-place bonus.\nThe highest total wins. Break a tie by the number of parks visited; if still tied, share the victory.\nSolo play does not use the photo bonus tile.",
	errAction: "That action is not available now.",
	errTurn: "It is not your turn.",
	optCamping: "Camping mode",
	optCampingHint: "Add tents and campsite actions to the trail.",
	optRanger: "Two-player ranger",
	optRangerHint: "Add a ranger in a two-player game; solo play always uses rangers.",
	optPassion: "Choose a passion",
	optPassionHint: "Each player chooses one of two passion cards.",
	optProjects: "Volunteer projects",
	optProjectsHint: "Add this many random project cards for extra rules.",
	yourTurn: "Your turn",
	waiting: "Waiting for {{name}}",
	chooseHiker: "Select a hiker, then choose a site ahead.",
	chooseAction: "Choose an action",
	finish: "End turn",
	skip: "Skip",
	choosePassion: "Choose your passion",
	chooseRanger: "Choose a ranger to move",
	ranger: "Ranger",
	backpack: "Backpack",
	photos: "Photos",
	campfireLit: "Campfire lit",
	campfireOut: "Campfire extinguished",
	reserved: "Reserved parks",
	visited: "Visited parks",
	take: "Take",
	visit: "Visit",
	reserve: "Reserve",
	buy: "Buy",
	use: "Use",
	takePhoto: "Take a photo",
	fillCanteen: "Fill a canteen",
	collectResource: "Gain resource",
	wildlifeTrade: "Trade for wildlife",
	campsite: "Camp",
	resolve: "Perform",
	endAction: "Trail's End action",
	parksAction: "Parks action",
	drawTop: "Draw from deck",
	pay: "Pay",
	free: "Free",
	resourceToBackpack: "Put in backpack",
	chooseDiscard: "Choose resources to return",
	discardConfirm: "Return resources",
	inspect: "View details",
	close: "Close",
	hiker: "Hiker",
	hikerFront: "Front hiker",
	hikerBack: "Back hiker",
	hikerLeft: "Left hiker",
	hikerRight: "Right hiker",
	parksDeck: "Park deck",
	gearDeck: "Gear deck",
	canteenDeck: "Canteen stack",
	seasonGoal: "Season objective",
	supplies: "View public supplies",
	suppliesShort: "Supplies",
	suppliesTitle: "Public supplies",
	photoSupply: "Photo tokens",
	albumSupply: "Photo albums",
	firstHikerHolder: "First Hiker: {{name}}",
	badgeHolder: "Shutterbug Badge: {{name}}",
	badgeNone: "Unclaimed",
	shutterbugSite: "Shutterbug site",
	tentAvailable: "Tent available",
	campOccupied: "Campsite occupied",
	parkDisplay: "Park display",
	gearDisplay: "Gear market",
	canteenDisplay: "Canteen display",
	trailhead: "Trailhead",
	trailEnd: "Trail's End",
	rewardClaimed: "Bonus claimed by {{name}}",
	rewardAvailable: "Bonus unclaimed",
	rewardTaken: "Bonus claimed",
	selectedAbility: "Ongoing ability selected",
	selectedScore: "End-game bonus selected",
	instantBonus: "Instant benefit",
	seasonSolo: "In solo play, you need at least {{n}} matching items.",
	seasonDetails: [
		[
			"Compare forest in backpacks. Reward: reserve a park.",
			"Compare sun in backpacks. Reward: draw a free gear card.",
			"Compare mountains in backpacks. Reward: take a free photo.",
			"Compare water in backpacks. Reward: gain a canteen token."
		],
		[
			"Compare canteen tokens. Reward: roll the trail die twice.",
			"Compare the total sun cost on gear cards. Reward: roll the trail die twice.",
			"Compare wildlife in backpacks. Reward: roll the trail die twice.",
			"Compare visited parks with instant benefits. Reward: roll the trail die twice."
		],
		[
			"Compare forest icons in visited park costs. Reward: 3 points.",
			"Compare mountain icons in visited park costs. Reward: 3 points.",
			"Compare sun icons in visited park costs. Reward: 3 points.",
			"Compare water icons in visited park costs. Reward: 3 points."
		]
	],
	parkBonus: {
		water1: "Gain 1 water",
		water2: "Gain 2 water",
		sun1: "Gain 1 sun",
		sun2: "Gain 2 sun",
		wildlife: "Gain 1 wildlife",
		canteen: "Gain a canteen token",
		die: "Roll the trail die",
		shutterbug: "Take the Shutterbug Badge"
	},
	passionPower: "Choose ongoing ability",
	passionScore: "Choose end-game scoring",
	doneParks: "Finish visiting",
	finishSeason: "Finish season reward",
	canteenRow: "Canteen row {{n}}",
	campSpace: "Campsite {{n}}",
	gameFinished: "Journey complete",
	results: "Journey review",
	winners: "Winner",
	sharedVictory: "Shared victory",
	total: "Total",
	soloScore: "Hiking score",
	soloRanks: [
		"Dayhiker",
		"Trekker",
		"Explorer",
		"Adventurer",
		"Trailblazer"
	],
	scoreParks: "Parks",
	scorePhotos: "Photos",
	scorePhotoBonus: "Photo bonus",
	scoreSeason: "Season",
	scorePassion: "Passion",
	scoreFirstHiker: "First Hiker",
	reviewTable: "Review the trail",
	showResults: "Show results",
	playAgain: "Play again",
	backLobby: "Back to lobby",
	confirmAgain: "Confirm new game",
	confirmLobby: "Confirm return to lobby",
	cancel: "Cancel",
	waitingHost: "Waiting for the host.",
	seasons: [
		"Spring",
		"Summer",
		"Fall"
	],
	resources: [
		"Mountain",
		"Forest",
		"Sun",
		"Water",
		"Wildlife"
	],
	sites: [
		"Trail die",
		"Wildlife",
		"Forest",
		"Sun",
		"Photo or canteen",
		"Gear",
		"Water",
		"Mountain",
		"Parks"
	],
	passions: [
		"Wildlife",
		"Botany",
		"Mountaineering",
		"Birdwatching",
		"Kayaking",
		"Forestry",
		"Collecting",
		"Swimming",
		"Rock Climbing",
		"Adventure"
	],
	projects: [
		"Sustainable Transportation",
		"Responsible Consumption",
		"Water Conservation",
		"Reduce Emissions",
		"Wildlife Conservation",
		"Carbon Offsetting",
		"Climate Action",
		"Environmental Studies",
		"Leave No Trace"
	],
	projectText: [
		"You may visit only parks in your reserve.",
		"Your backpack holds one fewer resource per gear card purchased.",
		"If you gain sun on your turn, lose one water if able.",
		"Remove 1- and 3-point parks from the deck before play.",
		"Your backpack can never hold more than one wildlife.",
		"Before visiting each park, spend one additional mountain or forest.",
		"Do not place sun in the weather pattern; place water as usual.",
		"You must have the Shutterbug Badge to take a photo.",
		"Start each season with your campfire extinguished."
	],
	passionObjectives: [
		"Take a photo with wildlife.",
		"Visit parks with at least three forest icons in their costs.",
		"Visit three parks with a mountain icon in their cost.",
		"Visit two parks with a sun icon in their cost.",
		"Visit two parks with a water icon in their cost.",
		"Visit three parks with a forest icon in their cost.",
		"Purchase two gear cards.",
		"Visit parks with at least three water icons in their costs.",
		"Visit parks with at least three mountain icons in their costs.",
		"Visit two parks with instant benefits."
	],
	passionPowers: [
		"When taking a photo with wildlife, gain two photos.",
		"When gaining forest, you may gain wildlife instead.",
		"Parks cost one less mountain to visit.",
		"Parks cost one less sun to visit.",
		"Parks cost one less water to visit.",
		"Parks cost one less forest to visit.",
		"Gear purchases are free.",
		"Roll the trail die when filling a canteen row.",
		"When gaining a mountain, you may gain wildlife instead.",
		"Roll the trail die when visiting a park with an instant benefit."
	],
	passionScores: [
		"Score 1 point per three photos.",
		"Score 1 point per two forest icons on visited parks.",
		"Score 1 point per visited park with a mountain icon.",
		"Score 1 point per visited park with a sun icon.",
		"Score 1 point per visited park with a water icon.",
		"Score 1 point per visited park with a forest icon.",
		"Score 1 point per gear card.",
		"Score 1 point per two water icons on visited parks.",
		"Score 1 point per two mountain icons on visited parks.",
		"Score 1 point per visited park with an instant benefit."
	],
	canteenText: {
		sun2: "Gain 2 sun",
		tradeWildlife: "Pay 1 resource to gain 1 wildlife",
		forest: "Gain 1 forest",
		mountain: "Gain 1 mountain",
		tradePhoto: "Pay 1 resource to take a photo",
		parks: "Take a Parks action"
	},
	gearTrigger: {
		siteForest: "After visiting the forest site",
		siteMountain: "After visiting the mountain site",
		siteWater: "After visiting the water site",
		siteSun: "After visiting the sun site",
		reserve: "After reserving a park",
		photo: "After taking a photo",
		die: "After rolling the trail die",
		tradeWildlife: "After trading for wildlife"
	},
	gearEffect: {
		forest: "gain 1 forest",
		mountain: "gain 1 mountain",
		water2: "gain 2 water",
		sun2: "gain 2 sun",
		wildlife: "gain 1 wildlife",
		relight: "relight your campfire",
		relightSun2: "relight your campfire and gain 2 sun",
		die: "roll the trail die",
		canteen: "gain a canteen token",
		tradePhoto: "pay 1 resource to take a photo",
		reserve: "reserve a park"
	},
	campText: {
		photoToResources: "Return 1 photo to gain 1 mountain, forest, sun, and water",
		canteenAndGear: "Gain a canteen and purchase gear",
		mountainToSun5: "Pay 1 mountain to gain 5 sun",
		parksAndPhoto: "Take a Parks action and a photo",
		photoToWildlife2: "Return 1 photo to gain 2 wildlife",
		wildlifeToForest3: "Pay 1 wildlife to gain 3 forest",
		mountainAndPhoto: "Gain 1 mountain and take a photo",
		twoToWildlife2: "Pay 2 resources to gain 2 wildlife",
		chooseResources: "Gain either a mountain or a forest, and either a sun or a water",
		forestToWater5: "Pay 1 forest to gain 5 water",
		badgeAndPhoto: "Take the Shutterbug Badge and a photo",
		wildlife: "Gain 1 wildlife",
		forestAndPhoto: "Gain 1 forest and take a photo",
		gearAndSun2: "Buy gear and gain 2 sun",
		wildlifeToMountain3: "Pay 1 wildlife to gain 3 mountains",
		sunToDice2: "Pay 1 sun to roll the trail die twice",
		mountainToWater5: "Pay 1 mountain to gain 5 water",
		sunToAny2: "Pay 1 sun to gain 2 resources of your choice",
		waterToAny2: "Pay 1 water to gain 2 resources of your choice",
		forestToSun5: "Pay 1 forest to gain 5 sun",
		waterToDice2: "Pay 1 water to roll the trail die twice"
	}
}, ot = {
	name: "国家公园第二版",
	desc: "走过三个季节，收集资源、访问国家公园，并用照片记录旅程。",
	rules: "目标：\n在三个季节中访问公园、拍摄照片并完成个人热情目标。第三季结束时，得分最高的玩家获胜。\n\n准备：\n· 每位玩家获得两名徒步者、一个玩家板、一张热情牌和一个随机水壶标记。四至五人开局时点燃篝火；一至三人开局时篝火熄灭。\n· 随机排列八个步道地点，并在中间放置公园地点。从第二个地点开始，交替放置阳光和水作为天气。掷步道骰，将摄影爱好者标记放在对应地点。\n· 翻开三张公园牌、三张装备牌和三个水壶标记，组成各自的展示区。每个季节随机选取一个季节目标。\n· 进阶选项可以使用露营、双人护林员、志愿项目，以及从两张热情牌中选择一张。\n\n徒步：\n拥有先行者标记的玩家开始，之后按顺时针轮流行动。每回合选择自己的一名徒步者，向前移动任意距离，在尚未到达终点的一个地点停下并执行该地点行动；徒步者不能后退。你必须能够执行地点行动，才能停在那里。\n一个地点可以由多名徒步者共享，但进入已有徒步者的地点时，你必须熄灭自己的篝火。篝火熄灭后，你不能再以此方式共享地点，直到重新点燃。若你是唯一仍有徒步者留在步道上的玩家，必须将剩余徒步者直接移到终点。\n首次抵达有天气的地点时，取得该天气标记。天气和地点行动可以按任意顺序处理。抵达摄影爱好者所在地点时，取得摄影爱好者徽章；标记仍留在步道上。\n\n资源与地点：\n· 山、森林、阳光、水和野生动物是有限资源。供应中没有某种资源时，你无法获得该资源。回合结束时背包最多保留 12 个资源，超出的资源须归还供应。\n· 野生动物可以代替其他资源用于访问公园、购买装备或拍照；公园费用中印有野生动物时，必须支付野生动物。\n· 山与森林地点分别提供一个对应资源；阳光与水地点分别提供两个对应资源。\n· 骰子地点让你掷步道骰并获得对应奖励。\n· 野生动物地点让你将一个背包资源换成一个野生动物。\n· 水壶／照片地点让你选择获得一个水壶标记，或支付一个背包资源拍摄一张照片。\n· 装备地点让你购买一张装备牌。\n· 公园地点让你预订一张公园牌，或访问一张或多张公园牌。\n\n公园与装备：\n预订时，从公园展示区选择一张牌，或抽取牌堆顶牌，放入自己的预订区。只有你能访问自己的预订牌。访问时，从展示区或自己的预订区选择公园，支付牌面所示资源，并将牌放入已访问区；你可以在一次公园行动中连续访问多张公园。公园牌上的即时奖励在访问时获得，可能帮助你继续访问其他公园。公园展示区在你的整个回合结束后补牌。\n购买装备时，支付牌面所示的阳光购买展示区的一张装备，或支付两个阳光抽取装备牌堆顶牌。装备立即生效；满足触发条件后，在完成地点行动之后可以使用装备效果。每张装备每回合最多使用一次。展示区在回合结束后补牌。\n\n水壶与照片：\n取得水壶时，从展示区选择一个标记或抽取牌堆顶标记，将它放入自己玩家板上的空位。展示区被取走的标记立即补充。每行最多容纳两个水壶标记。\n每当获得水时，可以将水放入背包，或放入尚未装水且至少有一个标记的水壶行，获得该行所有标记的效果。每行每季只能装水一次；已在背包里的水不能再用于装水。该行装水后新加入的标记本季不再触发。\n拍照时支付一个资源，获得一张照片；每张照片在终局值 1 分。每 5 张照片可兑换为一个值 5 分的相册标记，换回的单张照片标记返回供应。持有摄影爱好者徽章时，每回合拍照后可额外支付一个资源，再拍一张照片。\n\n热情、终点和季节：\n每张热情牌列有个人目标。你在自己回合中完成目标后，立即选择该牌提供的持续能力或终局计分奖励，之后不能更改选择。\n到达终点时，选择公园、照片或装备行动。每个终点行动的首位到达者还获得该位置的奖励：公园位置取得先行者标记，照片位置取得一个野生动物，装备位置取得一个阳光。该奖励可用于同一次终点行动。到达终点的徒步者留在那里直到本季结束。\n所有徒步者到达终点后，比较本季目标，拥有最多目标项目且至少有一个项目的玩家获得季节奖励；并列玩家都获得奖励。春季奖励印在目标板块上，夏季奖励是掷两次步道骰，秋季奖励是 3 分。随后清空水壶中的水、点燃篝火、重置徒步者并重新布置步道；弃掉装备展示区最右侧的牌并补牌。\n· 春季比较背包中板块所示的资源。奖励可能是预订一座公园、免费抽取一张装备、免费拍一张照片或取得一个水壶。\n· 夏季按板块比较水壶标记数量、装备牌上的阳光费用总数、背包中的野生动物数量，或有即时奖励的已访问公园数量。\n· 秋季比较已访问公园费用中板块所示资源图标的总数。\n\n露营和护林员：\n启用露营后，带帐篷的地点允许你选择把帐篷放到当前营地板块的空位，执行该营位的行动。选择露营时，不执行原地点行动，也不取得该地点的天气、摄影爱好者徽章或地点触发的装备效果。每季更换营地板块。\n护林员在游戏开始时持有先行者标记，先于玩家行动，之后与玩家按顺序轮流行动。\n· 双人游戏可选择加入一组护林员。每次护林员行动时，翻开一张护林员牌并移动一名徒步者。\n· 单人游戏使用两组护林员。每次护林员行动时，为尚未结束的每组各翻一张牌并移动一名徒步者，玩家可以选择先移动哪一组。\n· 翻开的牌正面指定移动到下一个没有徒步者的地点，或前进 2 格或 3 格。前进指定格数时，护林员可以与其他徒步者共享地点。牌堆顶新露出的牌背决定移动该组前方还是后方的徒步者；如果两名徒步者在同一地点，可以移动任意一名。\n· 护林员到达有天气的地点时，将天气标记归还供应。到达终点时，护林员按翻开的牌占据指定的终点行动位置，并可能取得先行者标记。\n· 单人游戏中，护林员还会取得摄影爱好者徽章，并在到达公园或装备地点时移除展示区最右侧的对应牌，再补充展示区。启用露营时，护林员到达有帐篷的地点会把帐篷放到最右侧空营位；此时不取得天气或徽章，也不执行地点行动。\n单人季节目标要求春、夏、秋分别达到至少 3、4、5 个目标项目。\n志愿项目可以为任意人数增加挑战；每张公开项目牌改变一项规则，必须在能够执行时遵守。\n\n终局：\n第三季结束后，计入已访问公园的分数、每张照片的 1 分、照片奖励、秋季奖励、已选择的热情终局奖励，以及先行者的 1 分。\n· 双人局照片最多者获得 3 分；三至五人局照片最多者获得 4 分，第二多者获得 2 分。\n· 没有照片的玩家不获得照片奖励。\n· 若多人并列最多，他们各得第一名奖励，且不再颁发第二名奖励；若第二名并列，并列者各得第二名奖励。\n总分最高者获胜；若总分相同，访问公园较多者获胜，仍相同则共同获胜。\n单人游戏不使用照片奖励板块。",
	errAction: "当前不能执行该行动。",
	errTurn: "现在不是你的回合。",
	optCamping: "露营模式",
	optCampingHint: "在步道上加入帐篷和营地行动。",
	optRanger: "双人护林员",
	optRangerHint: "双人游戏中加入护林员；单人游戏始终使用护林员。",
	optPassion: "选择热情",
	optPassionHint: "每位玩家从两张热情牌中选择一张。",
	optProjects: "志愿项目数量",
	optProjectsHint: "随机加入所选数量的项目牌，增加额外规则。",
	yourTurn: "你的回合",
	waiting: "等待 {{name}} 行动",
	chooseHiker: "选择徒步者，然后选择前方地点。",
	chooseAction: "选择行动",
	finish: "结束回合",
	skip: "跳过",
	choosePassion: "选择你的热情",
	chooseRanger: "选择要移动的护林员",
	ranger: "护林员",
	backpack: "背包",
	photos: "照片",
	campfireLit: "篝火已点燃",
	campfireOut: "篝火已熄灭",
	reserved: "预订公园",
	visited: "已访问公园",
	take: "取得",
	visit: "访问",
	reserve: "预订",
	buy: "购买",
	use: "使用",
	takePhoto: "拍照",
	fillCanteen: "装满水壶",
	collectResource: "取得资源",
	wildlifeTrade: "换取野生动物",
	campsite: "露营",
	resolve: "执行",
	endAction: "终点行动",
	parksAction: "公园行动",
	drawTop: "从牌堆抽取",
	pay: "支付",
	free: "免费",
	resourceToBackpack: "放入背包",
	chooseDiscard: "选择要归还的资源",
	discardConfirm: "归还资源",
	inspect: "查看详情",
	close: "关闭",
	hiker: "徒步者",
	hikerFront: "前方徒步者",
	hikerBack: "后方徒步者",
	hikerLeft: "左侧徒步者",
	hikerRight: "右侧徒步者",
	parksDeck: "公园牌堆",
	gearDeck: "装备牌堆",
	canteenDeck: "水壶堆",
	seasonGoal: "季节目标",
	supplies: "查看公共供应",
	suppliesShort: "供应",
	suppliesTitle: "公共供应",
	photoSupply: "照片标记",
	albumSupply: "相册标记",
	firstHikerHolder: "先行者：{{name}}",
	badgeHolder: "摄影徽章：{{name}}",
	badgeNone: "无人持有",
	shutterbugSite: "摄影地点",
	tentAvailable: "有帐篷",
	campOccupied: "营位已占用",
	parkDisplay: "公园展示区",
	gearDisplay: "装备展示区",
	canteenDisplay: "水壶展示区",
	trailhead: "步道起点",
	trailEnd: "步道终点",
	rewardClaimed: "奖励已由 {{name}} 取得",
	rewardAvailable: "奖励尚未领取",
	rewardTaken: "奖励已领取",
	selectedAbility: "已选持续能力",
	selectedScore: "已选终局计分",
	instantBonus: "即时奖励",
	seasonSolo: "单人游戏需要至少 {{n}} 个目标项目。",
	seasonDetails: [
		[
			"比较背包中的森林。奖励：预订一座公园。",
			"比较背包中的阳光。奖励：免费抽取一张装备牌。",
			"比较背包中的山。奖励：免费拍摄一张照片。",
			"比较背包中的水。奖励：取得一个水壶标记。"
		],
		[
			"比较水壶标记数量。奖励：掷两次步道骰。",
			"比较装备牌上的阳光费用总数。奖励：掷两次步道骰。",
			"比较背包中的野生动物数量。奖励：掷两次步道骰。",
			"比较有即时奖励的已访问公园数量。奖励：掷两次步道骰。"
		],
		[
			"比较已访问公园费用中的森林图标总数。奖励：3 分。",
			"比较已访问公园费用中的山图标总数。奖励：3 分。",
			"比较已访问公园费用中的阳光图标总数。奖励：3 分。",
			"比较已访问公园费用中的水图标总数。奖励：3 分。"
		]
	],
	parkBonus: {
		water1: "获得 1 个水",
		water2: "获得 2 个水",
		sun1: "获得 1 个阳光",
		sun2: "获得 2 个阳光",
		wildlife: "获得 1 个野生动物",
		canteen: "取得一个水壶标记",
		die: "掷一次步道骰",
		shutterbug: "取得摄影爱好者徽章"
	},
	passionPower: "选择持续能力",
	passionScore: "选择终局计分",
	doneParks: "完成访问",
	finishSeason: "完成季节奖励",
	canteenRow: "水壶行 {{n}}",
	campSpace: "营位 {{n}}",
	gameFinished: "旅程结束",
	results: "旅程回顾",
	winners: "获胜",
	sharedVictory: "共同获胜",
	total: "总分",
	soloScore: "徒步得分",
	soloRanks: [
		"日间徒步者",
		"远足者",
		"探索者",
		"冒险家",
		"开拓者"
	],
	scoreParks: "公园",
	scorePhotos: "照片",
	scorePhotoBonus: "照片奖励",
	scoreSeason: "季节",
	scorePassion: "热情",
	scoreFirstHiker: "先行者",
	reviewTable: "回看旅程",
	showResults: "查看结算",
	playAgain: "再来一局",
	backLobby: "返回大厅",
	confirmAgain: "确认再来一局",
	confirmLobby: "确认返回大厅",
	cancel: "取消",
	waitingHost: "等待房主选择下一步。",
	seasons: [
		"春季",
		"夏季",
		"秋季"
	],
	resources: [
		"山",
		"森林",
		"阳光",
		"水",
		"野生动物"
	],
	sites: [
		"步道骰",
		"野生动物",
		"森林",
		"阳光",
		"照片或水壶",
		"装备",
		"水",
		"山",
		"公园"
	],
	passions: [
		"野生动物",
		"植物学",
		"登山",
		"观鸟",
		"皮划艇",
		"林业",
		"收藏",
		"游泳",
		"攀岩",
		"探险"
	],
	projects: [
		"可持续交通",
		"负责任消费",
		"节约用水",
		"减少排放",
		"保护野生动物",
		"碳补偿",
		"气候行动",
		"环境研究",
		"不留痕迹"
	],
	projectText: [
		"只能访问自己预订的公园。",
		"每购买一张装备，背包容量减少 1。",
		"你的回合获得阳光时，若有水则失去 1 个水。",
		"开局前从牌堆移除 1 分和 3 分的公园。",
		"背包中的野生动物不能超过 1 个。",
		"访问每座公园前，额外支付 1 个山或森林。",
		"布置天气时不放阳光，仍照常放水。",
		"拍照时必须持有摄影爱好者徽章。",
		"每季开始时篝火保持熄灭。"
	],
	passionObjectives: [
		"用野生动物拍摄一张照片。",
		"已访问公园的费用中共有至少 3 个森林图标。",
		"访问 3 座费用中有山图标的公园。",
		"访问 2 座费用中有阳光图标的公园。",
		"访问 2 座费用中有水图标的公园。",
		"访问 3 座费用中有森林图标的公园。",
		"购买 2 张装备牌。",
		"已访问公园的费用中共有至少 3 个水图标。",
		"已访问公园的费用中共有至少 3 个山图标。",
		"访问 2 座有即时奖励的公园。"
	],
	passionPowers: [
		"用野生动物拍照时获得两张照片。",
		"获得森林时，可以改为获得野生动物。",
		"访问公园时少支付 1 个山。",
		"访问公园时少支付 1 个阳光。",
		"访问公园时少支付 1 个水。",
		"访问公园时少支付 1 个森林。",
		"购买装备免费。",
		"装满一行水壶时掷一次步道骰。",
		"获得山时，可以改为获得野生动物。",
		"访问有即时奖励的公园时掷一次步道骰。"
	],
	passionScores: [
		"每 3 张照片得 1 分。",
		"已访问公园费用中每 2 个森林图标得 1 分。",
		"每座费用中有山图标的已访问公园得 1 分。",
		"每座费用中有阳光图标的已访问公园得 1 分。",
		"每座费用中有水图标的已访问公园得 1 分。",
		"每座费用中有森林图标的已访问公园得 1 分。",
		"每张装备牌得 1 分。",
		"已访问公园费用中每 2 个水图标得 1 分。",
		"已访问公园费用中每 2 个山图标得 1 分。",
		"每座有即时奖励的已访问公园得 1 分。"
	],
	canteenText: {
		sun2: "获得 2 个阳光",
		tradeWildlife: "支付 1 个资源，获得 1 个野生动物",
		forest: "获得 1 个森林",
		mountain: "获得 1 个山",
		tradePhoto: "支付 1 个资源，拍摄 1 张照片",
		parks: "执行一次公园行动"
	},
	gearTrigger: {
		siteForest: "访问森林地点后",
		siteMountain: "访问山地点后",
		siteWater: "访问水地点后",
		siteSun: "访问阳光地点后",
		reserve: "预订公园后",
		photo: "拍照后",
		die: "掷步道骰后",
		tradeWildlife: "换取野生动物后"
	},
	gearEffect: {
		forest: "获得 1 个森林",
		mountain: "获得 1 个山",
		water2: "获得 2 个水",
		sun2: "获得 2 个阳光",
		wildlife: "获得 1 个野生动物",
		relight: "点燃篝火",
		relightSun2: "点燃篝火并获得 2 个阳光",
		die: "掷一次步道骰",
		canteen: "获得 1 个水壶标记",
		tradePhoto: "支付 1 个资源拍照",
		reserve: "预订一座公园"
	},
	campText: {
		photoToResources: "归还 1 张照片，获得山、森林、阳光和水各 1 个",
		canteenAndGear: "获得 1 个水壶标记并购买装备",
		mountainToSun5: "支付 1 个山，获得 5 个阳光",
		parksAndPhoto: "执行公园行动并拍照",
		photoToWildlife2: "归还 1 张照片，获得 2 个野生动物",
		wildlifeToForest3: "支付 1 个野生动物，获得 3 个森林",
		mountainAndPhoto: "获得 1 个山并拍照",
		twoToWildlife2: "支付 2 个资源，获得 2 个野生动物",
		chooseResources: "选择山或森林，并选择阳光或水，各获得 1 个",
		forestToWater5: "支付 1 个森林，获得 5 个水",
		badgeAndPhoto: "取得摄影爱好者徽章并拍照",
		wildlife: "获得 1 个野生动物",
		forestAndPhoto: "获得 1 个森林并拍照",
		gearAndSun2: "购买装备并获得 2 个阳光",
		wildlifeToMountain3: "支付 1 个野生动物，获得 3 个山",
		sunToDice2: "支付 1 个阳光，掷两次步道骰",
		mountainToWater5: "支付 1 个山，获得 5 个水",
		sunToAny2: "支付 1 个阳光，获得 2 个自选资源",
		waterToAny2: "支付 1 个水，获得 2 个自选资源",
		forestToSun5: "支付 1 个森林，获得 5 个阳光",
		waterToDice2: "支付 1 个水，掷两次步道骰"
	}
}, st = [
	[
		"北喀斯喀特",
		"华盛顿州",
		"Washington",
		1968,
		"高耸的山脊和尖峰酷似欧洲阿尔卑斯山脉，这里因此有时被称为“美国阿尔卑斯”。",
		"Its high ridges and sharp peaks resemble the European mountain range, earning it the nickname “American Alps”."
	],
	[
		"大盆地",
		"内华达州",
		"Nevada",
		1986,
		"罕见的大盆地狐尾松是地球上最古老的树木之一，能在严酷环境中存活四千年以上。",
		"The rare Great Basin bristlecone pine is among the oldest trees on Earth, surviving 4,000 years or more in extremely harsh conditions."
	],
	[
		"火山口湖",
		"俄勒冈州",
		"Oregon",
		1902,
		"“湖中老人”是一截古老的铁杉树桩，它在火山口湖中直立漂浮。",
		"The Old Man of the Lake is an ancient hemlock stump that floats freely and upright around Crater Lake."
	],
	[
		"国王峡谷",
		"加利福尼亚州",
		"California",
		1940,
		"大树桩环线可以看到马克·吐温树的遗迹；这棵树于 1891 年被砍倒，以证明巨杉的存在。",
		"Hike the Big Stump loop to see the remains of the Mark Twain Tree, cut down in 1891 to prove the giant sequoia’s existence."
	],
	[
		"尖峰",
		"加利福尼亚州",
		"California",
		2013,
		"除了短尾猫和蝙蝠，公园还保护着北美单一区域中种类最丰富的蜜蜂。",
		"Besides bobcats and bats, the park protects the largest diversity of bees in a single area in North America."
	],
	[
		"迪纳利",
		"阿拉斯加州",
		"Alaska",
		1917,
		"深入荒野，寻找阿拉斯加的五种大型哺乳动物：驼鹿、白大角羊、狼、灰熊和北美驯鹿。",
		"Head into the backcountry to look for Alaska’s “big five”: moose, Dall sheep, wolves, grizzly bears and caribou."
	],
	[
		"北极之门",
		"阿拉斯加州",
		"Alaska",
		1980,
		"公园没有公路，步道也很少。乘飞机可以俯瞰六条风景优美的河流和广阔荒野。",
		"There are no roads and few trails. A flight reveals six scenic rivers and the vast wilderness within."
	],
	[
		"冰川湾",
		"阿拉斯加州",
		"Alaska",
		1980,
		"紧密压实、几乎没有气泡的冰川冰吸收除蓝光以外的各种颜色，因此呈现梦幻般的蓝色。",
		"Glacial ice is compressed with few air bubbles and absorbs every color of light but blue, giving it an ethereal blue color."
	],
	[
		"卡特迈",
		"阿拉斯加州",
		"Alaska",
		1918,
		"这里是观察棕熊的绝佳地点，许多棕熊会在布鲁克斯河捕捉红鲑。",
		"One of the best places to see brown bears, many of which catch sockeye salmon in the Brooks River."
	],
	[
		"基奈峡湾",
		"阿拉斯加州",
		"Alaska",
		1980,
		"古代冰川雕刻出这些峡湾，至今仍在塑造地貌，并为海洋野生动物提供栖息地。",
		"Ancient ice carved these fjords and still shapes the landscape, creating habitat for marine wildlife."
	],
	[
		"优胜美地",
		"加利福尼亚州",
		"California",
		1890,
		"世界各地的攀岩者来到半圆顶，挑战北美最陡峭的岩壁，其垂直坡度达 93%。",
		"Climbers from around the world come to take on Half Dome, the sheerest cliff in North America, with a 93% vertical grade."
	],
	[
		"大沼泽地",
		"佛罗里达州",
		"Florida",
		1947,
		"大沼泽地被称为“草之河”，是地球上唯一一个鳄鱼与短吻鳄在野外共同生活的地方。",
		"Known as the “river of grass”, the Everglades is the only place where crocodiles and alligators live together in the wild."
	],
	[
		"夏威夷火山",
		"夏威夷州",
		"Hawaii",
		1916,
		"这里有世界上最大的火山冒纳罗亚火山，以及基拉韦厄火山；火焰女神佩蕾居住在哈雷茂茂火山口。",
		"Here are Mauna Loa, the world’s biggest volcano, and Kīlauea, home of the fire goddess Pele in Halemaʻumaʻu Crater."
	],
	[
		"圆顶礁",
		"犹他州",
		"Utah",
		1971,
		"公园有 19 座果园，可采摘传统品种的樱桃、杏、桃、梨、李子和圆顶礁红苹果。",
		"In 19 orchards, pick heirloom cherries, apricots, peaches, pears, plums and the namesake Capitol Reef Red apple."
	],
	[
		"锡安",
		"犹他州",
		"Utah",
		1919,
		"在狭谷中徒步时，游客会涉过深及腰部的维尔京河，体验著名的狭缝峡谷。",
		"In the Narrows, wade waist-deep in the Virgin River on one of the world’s great slot-canyon hikes."
	],
	[
		"拱门",
		"犹他州",
		"Utah",
		1929,
		"这里是国际暗夜公园，拥有美国最暗的一些夜空；在犹他沙漠可以看到银河。",
		"An International Dark Sky Park, Arches has some of the darkest skies in the United States, where the Milky Way is visible."
	],
	[
		"峡谷地",
		"犹他州",
		"Utah",
		1964,
		"天空之岛是一座高出周围地貌约 1,000 英尺的巨大台地，四周视野开阔。",
		"Island in the Sky is a huge mesa rising 1,000 feet above the landscape, with panoramic views in every direction."
	],
	[
		"布莱斯峡谷",
		"犹他州",
		"Utah",
		1928,
		"公园有十二座天然圆形剧场，其中的石林高约 5 至 150 英尺。",
		"The park has twelve amphitheaters filled with hoodoos, rock pillars ranging from five to 150 feet high."
	],
	[
		"瓜达卢佩山脉",
		"得克萨斯州",
		"Texas",
		1972,
		"这里生活着西貒，一种类似猪的哺乳动物，它们从仙人掌肉质茎中获取所需水分。",
		"Javelinas are piglike mammals that obtain the water they need by eating the pads of prickly pear cactus."
	],
	[
		"大弯",
		"得克萨斯州",
		"Texas",
		1944,
		"公园以格兰德河的大弯曲河段命名，这条河也是美国与墨西哥的国际边界。",
		"The park is named for the big bend in the Rio Grande, which also forms the border between the United States and Mexico."
	],
	[
		"大烟山",
		"北卡罗来纳州 / 田纳西州",
		"North Carolina / Tennessee",
		1934,
		"从佐治亚州延伸至缅因州的阿巴拉契亚步道有 72 英里穿过这里，其最高点也位于公园内。",
		"The highest point of the Appalachian Trail is here, along with 72 miles of the Georgia-to-Maine trail."
	],
	[
		"门户拱门",
		"密苏里州",
		"Missouri",
		2018,
		"这里适合城市观鸟，可看到金翅雀、东蓝鸲、红雀、林鸳鸯、加拿大雁和蓝松鸦。",
		"For urban birdwatching, look for goldfinches, Eastern bluebirds, cardinals, wood ducks, Canada geese and blue jays."
	],
	[
		"哈雷阿卡拉",
		"夏威夷州",
		"Hawaii",
		1961,
		"哈雷阿卡拉在夏威夷语中意为“太阳之家”，火山顶是观赏日出的好地方。",
		"Haleakalā means “house of the sun” in Hawaiian, and the volcano’s summit is a fine place to watch the sunrise."
	],
	[
		"猛犸洞",
		"肯塔基州",
		"Kentucky",
		1941,
		"这座石灰岩迷宫拥有壮观的岩层，其中“冰冻尼亚加拉”是公园最密集的钟乳石群。",
		"This limestone labyrinth contains formations such as Frozen Niagara, the park’s densest collection of stalactites."
	],
	[
		"风洞",
		"南达科他州",
		"South Dakota",
		1903,
		"地表是连绵丘陵与草原，地下则有长达 143 英里的洞穴，是世界最大的洞穴系统之一。",
		"Rolling hills and prairie cover 143 miles of cave beneath the surface, among the largest cave systems in the world."
	],
	[
		"白沙",
		"新墨西哥州",
		"New Mexico",
		1933,
		"这里的沙丘由石膏沙组成，不像硅砂那样吸热，即使炎热天气也保持凉爽。",
		"The gypsum sand forming these dunes does not absorb heat like silica sand, so it stays cool even on hot days."
	],
	[
		"印第安纳沙丘",
		"印第安纳州",
		"Indiana",
		2019,
		"这段长 15 英里的密歇根湖岸线生物多样性丰富，保护着多种水鸟。",
		"These 15 miles of Lake Michigan shoreline are highly biodiverse and protect many waterfowl species."
	],
	[
		"大沙丘",
		"科罗拉多州",
		"Colorado",
		2004,
		"尤特语中大沙丘的传统名称意为“移动的沙”，较小的沙丘会在草原上生长并迁移。",
		"The traditional Ute name means “sand that moves”; smaller dunes grow and migrate across the grasslands."
	],
	[
		"美属萨摩亚",
		"美属萨摩亚",
		"American Samoa",
		1988,
		"带上浮潜装备，探索奥努乌岛附近的珊瑚礁与海底洞穴，或法加特勒湾海洋保护区。",
		"Bring snorkeling gear to explore reefs and underwater caves near Aunuʻu Island or the Fagatele Bay marine sanctuary."
	],
	[
		"干龟群岛",
		"佛罗里达州",
		"Florida",
		1935,
		"干龟群岛周围浅而多岩的海域散布着 250 多艘沉船，有些可追溯至 16 世纪。",
		"The shallow rocky waters surrounding Dry Tortugas hold more than 250 shipwrecks, some dating to the 16th century."
	],
	[
		"比斯坎",
		"佛罗里达州",
		"Florida",
		1980,
		"公园超过 95% 的区域位于水下，其中包括美国本土唯一的活珊瑚礁。",
		"Over 95% of the park is underwater, including the only living coral reef in the continental United States."
	],
	[
		"海峡群岛",
		"加利福尼亚州",
		"California",
		1980,
		"岛屿周围的巨藻森林如同水下丛林，高耸的藻冠间栖息着丰富的海洋生物。",
		"Kelp forests around the islands are underwater jungles whose towering canopies teem with sea life."
	],
	[
		"维尔京群岛",
		"美属维尔京群岛",
		"Virgin Islands",
		1956,
		"特朗克湾是世界上最美丽的海滩之一，设有适合初学者探索的水下浮潜步道。",
		"Trunk Bay, one of the world’s most beautiful beaches, has an underwater snorkeling trail suited to beginners."
	],
	[
		"恶地",
		"南达科他州",
		"South Dakota",
		1939,
		"叉角羚是世界上速度第二快的陆地哺乳动物，在这片崎岖地形中十分常见。",
		"Pronghorns, the world’s second-fastest land mammal, abound in this difficult terrain."
	],
	[
		"西奥多·罗斯福",
		"北达科他州",
		"North Dakota",
		1978,
		"数以千计的黑尾草原犬鼠居住在草原犬鼠村落中，洞穴之间由隧道相连。",
		"Thousands of black-tailed prairie dogs inhabit towns made of burrows connected by tunnels."
	],
	[
		"拉森火山",
		"加利福尼亚州",
		"California",
		1916,
		"这里有盾状火山普罗斯佩克特峰、熔岩穹丘拉森峰、火山渣锥以及复合火山布罗克奥夫山。",
		"Find every type of volcano here: shield (Prospect Peak), plug dome (Lassen Peak), cinder cone (Cinder Cone) and composite (Brokeoff)."
	],
	[
		"石化林",
		"亚利桑那州",
		"Arizona",
		1962,
		"石化木由石英构成，铁、碳和锰等杂质赋予这些巨大晶体彩虹般的颜色。",
		"Petrified wood is solid quartz, whose rainbow colors come from iron, carbon and manganese impurities."
	],
	[
		"卡尔斯巴德洞窟",
		"新墨西哥州",
		"New Mexico",
		1930,
		"这里被称为“有屋顶的大峡谷”；大洞厅步道是欣赏奇特岩层的好地点。",
		"Called “the Grand Canyon with a roof over it”, the Big Room Trail is a premier place to see remarkable rock formations."
	],
	[
		"科伯克谷",
		"阿拉斯加州",
		"Alaska",
		1980,
		"大科伯克沙丘从苔原和林地上方拔地而起，高约 100 英尺。",
		"The Great Kobuk Sand Dunes rise unexpectedly 100 feet above the tundra and trees below."
	],
	[
		"克拉克湖",
		"阿拉斯加州",
		"Alaska",
		1980,
		"每年数千条红鲑沿纽黑伦河洄游，回到它们出生的克拉克湖水域。",
		"Each year thousands of sockeye salmon swim up the Newhalen River to the waters of Lake Clark where they were born."
	],
	[
		"兰格尔—圣伊莱亚斯",
		"阿拉斯加州",
		"Alaska",
		1980,
		"公园的冰川面积达 5,000 平方英里，鲁特冰川是其中最易抵达的一处，其陡直冰壁适合攀冰。",
		"Root Glacier is the most accessible of the park’s 5,000 square miles of glacier, with walls ideal for ice climbing."
	],
	[
		"航海者",
		"明尼苏达州",
		"Minnesota",
		1975,
		"在晴朗的黑夜，这里是观赏北极光的绝佳地点。",
		"On clear dark nights, Voyageurs is a superb place to watch the aurora borealis, or Northern Lights."
	],
	[
		"冰川",
		"蒙大拿州",
		"Montana",
		1910,
		"山羊是公园的非官方吉祥物，经常可以看到它们攀爬湖泊和森林上方的陡崖。",
		"Mountain goats are the park’s unofficial mascot and are often seen scaling cliffs above the lakes and forests."
	],
	[
		"奥林匹克",
		"华盛顿州",
		"Washington",
		1938,
		"第二海滩步道沿岸有高耸的海蚀柱，夕阳有时从它们之间透出。",
		"Second Beach Trail has towering sea stacks and breathtaking sunsets that sometimes peek through them."
	],
	[
		"阿卡迪亚",
		"缅因州",
		"Maine",
		1916,
		"这里的悬崖是大西洋沿岸最高的一些悬崖，也最早迎来美洲的晨光。",
		"Its cliffs are among the tallest on the Atlantic Coast and among the first places in the Americas to see morning sunlight."
	],
	[
		"皇家岛",
		"密歇根州",
		"Michigan",
		1940,
		"这座密歇根上半岛的岛屿是最偏远的国家公园之一，只能乘船或水上飞机抵达。",
		"This island in Michigan’s Upper Peninsula is one of the most secluded national parks, accessible only by boat or seaplane."
	],
	[
		"红杉",
		"加利福尼亚州",
		"California",
		1968,
		"巨型海岸红杉的顶端叶片从空气中吸收水分并凝成水滴，形成自己的“雨”。",
		"Giant redwoods create their own rain by drawing moisture from the air with their upper needles and condensing droplets."
	],
	[
		"美洲杉",
		"加利福尼亚州",
		"California",
		1890,
		"百巨人步道穿过长草甸林地，那里有高耸的巨杉，有些树龄达 1,500 年。",
		"The Trail of 100 Giants crosses Long Meadow Grove, a dense stand of giant sequoias, some 1,500 years old."
	],
	[
		"康加里",
		"南卡罗来纳州",
		"South Carolina",
		2003,
		"这是一片洪泛平原森林，而非沼泽，保护着美国面积最大的原始低地硬木林。",
		"This floodplain forest, not a swamp, preserves the largest area of old-growth bottomland hardwood in the United States."
	],
	[
		"凯霍加谷",
		"俄亥俄州",
		"Ohio",
		2e3,
		"125 英里步道纵横交错，经过溪流和木桥，可欣赏岩层、峡谷和瀑布。",
		"Some 125 miles of trails cross streams and log bridges among rock formations, ravines and waterfalls."
	],
	[
		"温泉",
		"阿肯色州",
		"Arkansas",
		1921,
		"天然温泉由地下深处加热，富含矿物质的泉水可以安全饮用。",
		"Natural hot springs are heated deep below the surface, producing mineral-rich water that is safe to drink."
	],
	[
		"新河峡谷",
		"西弗吉尼亚州",
		"West Virginia",
		2020,
		"新河峡谷大桥横跨河流上方；定点跳伞者每年只在大桥日获准跳伞一次。",
		"The New River Gorge Bridge spans high above the river; BASE jumpers may leap once a year on Bridge Day."
	],
	[
		"仙纳度",
		"弗吉尼亚州",
		"Virginia",
		1935,
		"天际线公路经过杜鹃花地、山景和红橡树林，是著名的风景道路。",
		"Skyline Drive passes rhododendron fields, mountain landscapes and red oak forests."
	],
	[
		"梅萨维德",
		"科罗拉多州",
		"Colorado",
		1906,
		"悬崖宫是公园最大的崖居，由祖先普韦布洛人在 1190 年代建造，可能曾绘有鲜艳色彩。",
		"Cliff Palace, the park’s largest cliff dwelling, was built by Ancestral Pueblo people in the 1190s and may have been brightly painted."
	],
	[
		"甘尼森黑峡谷",
		"科罗拉多州",
		"Colorado",
		1999,
		"峡谷壁很少受到阳光照射，经常笼罩在阴影中，因而看起来呈黑色。",
		"The canyon walls receive little sunlight and are often in shadow, making them appear black."
	],
	[
		"大提顿",
		"怀俄明州",
		"Wyoming",
		1929,
		"公园有一百多个清澈的冰川湖，包括适合游泳的菲尔普斯湖。",
		"The park has more than 100 clear glacial lakes, including Phelps Lake, a favored place to swim."
	],
	[
		"黄石",
		"爱达荷州 / 蒙大拿州 / 怀俄明州",
		"Idaho / Montana / Wyoming",
		1872,
		"公园地下的黄石火山口是一座休眠的超级火山，为间歇泉、泥浆池和温泉提供能量。",
		"The Yellowstone Caldera, a dormant supervolcano beneath the park, fuels its geysers, mudpots and hot springs."
	],
	[
		"雷尼尔山",
		"华盛顿州",
		"Washington",
		1899,
		"夏日野花竞相盛开，包括粉色吊钟花、紫色羽扇豆、黄色委陵菜、红色画笔草和白色缬草。",
		"Summer brings pink penstemon, purple lupine, yellow cinquefoils, red paintbrush and white valerian."
	],
	[
		"死亡谷",
		"加利福尼亚州",
		"California",
		1994,
		"扎布里斯基角超凡的景色使它常被电影和电视作品用作外星星球的取景地。",
		"The otherworldly view from Zabriskie Point has stood in for alien planets in many films and television shows."
	],
	[
		"约书亚树",
		"加利福尼亚州",
		"California",
		1994,
		"约书亚树每年只长约一两英寸，又没有年轮，因此很难判断树龄。",
		"Joshua trees grow only an inch or two a year and lack growth rings, making their age hard to determine."
	],
	[
		"萨瓜罗",
		"亚利桑那州",
		"Arizona",
		1994,
		"萨瓜罗仙人掌侧面的著名“手臂”通常要等到植株超过 75 岁才会长出。",
		"The famous arms of a saguaro cactus usually do not appear until the plant is more than 75 years old."
	],
	[
		"大峡谷",
		"亚利桑那州",
		"Arizona",
		1919,
		"峡谷深到足以形成自己的天气，最低处与最高处的温度可相差 25 度。",
		"The canyon is deep enough to create its own weather; temperatures between its lowest and highest points can vary by 25 degrees."
	],
	[
		"落基山",
		"科罗拉多州",
		"Colorado",
		1915,
		"海伦湖位于平顶山、雷鸟峰和诺奇托普山下的盆地中，四周景色壮丽。",
		"Lake Helene sits beneath Flattop Mountain, Ptarmigan Point and Notchtop Mountain, with spectacular views all around."
	]
].map(([e, t, n, r, i, a]) => ({
	zhName: e,
	zhRegion: t,
	enRegion: n,
	year: r,
	zhText: i,
	enText: a
})), ct = (e) => f(`games/parks2/art/park-${String(e).padStart(2, "0")}.webp`), lt = (e) => f(`games/parks2/art/gear-${String(e).padStart(2, "0")}.webp`), ut = {
	"Hiking Boots": "徒步靴",
	"Mystery Cache": "神秘包",
	"Sleeping Bag": "睡袋",
	"Field Guide": "野外图鉴",
	Sunscreen: "防晒霜",
	"Rain Gear": "雨具",
	Binoculars: "望远镜",
	"Camp Mug": "露营杯",
	"Telephoto Lens": "长焦镜头",
	Compass: "指南针",
	Journal: "徒步日志",
	"Flint & Tinder": "打火工具",
	"Wide Angle Lens": "广角镜头"
}, dt = (e, t) => t === "zh" ? st[e].zhName : w[e].name, ft = (e, t) => t === "zh" ? ut[x[e].name] ?? x[e].name : x[e].name;
function Q({ kind: e, className: t = "" }) {
	let n = {
		mountain: /* @__PURE__ */ h("path", {
			fill: "#ed5534",
			d: "M2 29 8 9q.5-1 2-1h2l2 5q1 2 2 0L20 2q.3-1 2-1h2l6 28z"
		}),
		forest: /* @__PURE__ */ h("path", {
			fill: "#70b853",
			d: "M14 2q2-1 4 0l1 4q2 3 9 4v5q-5 0-9-3v3q3 4 10 5v6q-6 1-10-3v6h-6v-6q-4 4-10 3v-6q7-1 10-5v-3q-4 3-9 3v-5q7-1 9-4z"
		}),
		sun: /* @__PURE__ */ h("path", {
			fill: "#f9ad00",
			d: "M12 1h8l-1 9 7-5 4 6-8 5 8 4-4 6-7-4 1 9h-8l1-9-7 4-4-6 8-4-8-5 4-6 7 5z"
		}),
		water: /* @__PURE__ */ h("path", {
			fill: "#43b8c1",
			d: "M13 1h6q0 6 4 10 5 5 5 10a12 12 0 0 1-24 0q0-5 5-10 4-4 4-10z"
		}),
		wildlife: /* @__PURE__ */ h("path", {
			fill: "#b75f44",
			transform: "translate(1 1) scale(.9)",
			d: "M2 11q0-2 3-2h2L6 7l2 1 1 2 2-5q1-3 4-3h6l3 3-1 1q6 1 8 5 1 3 1 7l1 3v8h-3l-1-6-2-1-2 7h-3v-7l-6 1-1 6h-3l1-7-4-1-2 4-2-1-1-2-2-1 1-3z"
		}),
		die: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
			fill: "#efab13",
			d: "M16 2 29 8v16l-13 7L3 24V8z"
		}), /* @__PURE__ */ h("path", {
			fill: "none",
			stroke: "#b66c1c",
			strokeWidth: "2",
			d: "m3 8 13 7 13-7M16 15v16"
		})] }),
		photoCanteen: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				fill: "#3eb4c0",
				d: "M4 7h9v21H4zM6 3h5v4H6z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#b75f44",
				d: "M18 10h11v12H18zM20 8h5v2h-5z"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "23.5",
				cy: "16",
				r: "3",
				fill: "#f7efd8"
			})
		] }),
		gear: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				fill: "#e1a345",
				stroke: "#75482f",
				strokeWidth: "1",
				d: "M4 4 12 2l4 3 1 8q1 4 7 7l5 2 1 4H3l-1-4 1-8z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#71442f",
				d: "m3 5 9-3 2 5-11 4z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#b75536",
				d: "M3 18q8 2 15-1l5 4q-9 3-20 1z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#343b34",
				d: "M2 25h28v4H2z"
			}),
			/* @__PURE__ */ h("path", {
				stroke: "#f8e6c3",
				strokeWidth: "1",
				d: "M3 26h26"
			}),
			/* @__PURE__ */ g("g", {
				fill: "#4a3a2c",
				children: [
					/* @__PURE__ */ h("circle", {
						cx: "13",
						cy: "7",
						r: "1"
					}),
					/* @__PURE__ */ h("circle", {
						cx: "15",
						cy: "10",
						r: "1"
					}),
					/* @__PURE__ */ h("circle", {
						cx: "17",
						cy: "13",
						r: "1"
					}),
					/* @__PURE__ */ h("circle", {
						cx: "19",
						cy: "16",
						r: "1"
					})
				]
			})
		] }),
		parks: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
			fill: "#4f825b",
			d: "M2 27 11 8l5 9 6-14 8 24z"
		}), /* @__PURE__ */ h("circle", {
			cx: "7",
			cy: "6",
			r: "3",
			fill: "#e6ae37"
		})] }),
		end: /* @__PURE__ */ h("path", {
			fill: "#c9683e",
			d: "M6 2h3v28H6zM9 3l20 5-20 8z"
		}),
		camp: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
			fill: "#eaa72d",
			d: "M1 28 16 2l15 26z"
		}), /* @__PURE__ */ h("path", {
			fill: "#8a4b2c",
			d: "m11 28 5-10 5 10z"
		})] }),
		badge: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("circle", {
				cx: "16",
				cy: "16",
				r: "15",
				fill: "#cf5834"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "16",
				cy: "16",
				r: "10",
				fill: "#394137"
			}),
			/* @__PURE__ */ h("ellipse", {
				cx: "16",
				cy: "18",
				rx: "6",
				ry: "7",
				fill: "#ef8a4b"
			}),
			/* @__PURE__ */ h("path", {
				d: "M16 11v13",
				stroke: "#394137",
				strokeWidth: "2"
			})
		] }),
		photo: /* @__PURE__ */ g(m, { children: [
			/* @__PURE__ */ h("path", {
				fill: "#bb6040",
				d: "M3 9h26v19H3zM8 5h8l2 4H8z"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "16",
				cy: "18",
				r: "6",
				fill: "#f7efd8"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "16",
				cy: "18",
				r: "3",
				fill: "#518778"
			})
		] }),
		canteen: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
			fill: "#43b8c1",
			d: "M7 7h18v23H7zM11 2h10v5H11z"
		}), /* @__PURE__ */ h("path", {
			fill: "#267f8a",
			d: "M16 12c-2 3-4 5-4 7a4 4 0 0 0 8 0c0-2-2-4-4-7z"
		})] }),
		fire: /* @__PURE__ */ h("path", {
			fill: "#d7683e",
			d: "M16 1c2 7 8 8 8 16 0 7-4 12-9 12S6 24 6 18c0-5 4-9 7-12 0 4 1 6 3 7 1-5 0-8 0-12z"
		})
	};
	return /* @__PURE__ */ h("svg", {
		className: `pk2-icon ${t}`,
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		children: n[e]
	});
}
function $({ round: e = !1 }) {
	let t = p();
	return /* @__PURE__ */ g("svg", {
		className: "pk2-target-outline",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ h("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "96",
			rx: e ? 48 : 8,
			className: "pk2-target-base"
		}), /* @__PURE__ */ h("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "96",
			rx: e ? 48 : 8,
			className: "pk2-target-dashes",
			children: !t && /* @__PURE__ */ h("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-24",
				dur: "1s",
				repeatCount: "indefinite"
			})
		})]
	});
}
function pt({ cost: e, showZero: t = !1 }) {
	let n = c((e) => e.locale) === "zh" ? ot : at;
	return /* @__PURE__ */ h("span", {
		className: "pk2-cost",
		children: T.map((r, i) => e[r] || t ? /* @__PURE__ */ g("span", {
			role: "img",
			"aria-label": `${n.resources[i]} ${e[r] ?? 0}`,
			title: `${n.resources[i]} ${e[r] ?? 0}`,
			children: [/* @__PURE__ */ h(Q, { kind: r }), /* @__PURE__ */ h("b", { children: e[r] ?? 0 })]
		}, r) : null)
	});
}
function mt({ id: e }) {
	let t = c((e) => e.locale), n = e >= 4 && e <= 7, r = e === 9 || e === 10, i = e >= 24 && e <= 27, a = t === "zh" ? [
		"北美鱼类",
		"北美鸟类",
		"北美爬行动物",
		"北美哺乳动物"
	] : [
		"North American Fish",
		"North American Birds",
		"North American Reptiles",
		"North American Mammals"
	];
	return /* @__PURE__ */ g("span", {
		className: `pk2-art pk2-gear-art pk2-gear-art-${e}`,
		children: [
			/* @__PURE__ */ h("img", {
				src: lt(e),
				alt: ""
			}),
			n && /* @__PURE__ */ h("span", {
				className: "pk2-package-label pk2-book-label",
				children: a[e - 4]
			}),
			r && /* @__PURE__ */ h("span", {
				className: "pk2-package-label pk2-sunscreen-label",
				children: t === "zh" ? "防晒" : "Sun care"
			}),
			r && /* @__PURE__ */ h("span", {
				className: "pk2-package-label pk2-sunscreen-spf",
				children: e === 9 ? "30+" : "50+"
			}),
			i && /* @__PURE__ */ h("span", {
				className: "pk2-package-label pk2-journal-label",
				children: t === "zh" ? "徒步日志" : "Trail journal"
			}),
			[
				19,
				20,
				21,
				32,
				33,
				34,
				35
			].includes(e) && /* @__PURE__ */ h("span", { className: "pk2-package-label pk2-camera-label" }),
			[
				19,
				20,
				21
			].includes(e) && /* @__PURE__ */ h("span", { className: "pk2-package-label pk2-lens-corner" }),
			[22, 23].includes(e) && /* @__PURE__ */ h("span", { className: "pk2-package-label pk2-compass-label" }),
			[
				0,
				16,
				17
			].includes(e) && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("span", { className: "pk2-package-label pk2-boot-label pk2-boot-left" }), /* @__PURE__ */ h("span", { className: "pk2-package-label pk2-boot-label pk2-boot-right" })] })
		]
	});
}
function ht({ id: e, compact: t = !1 }) {
	let n = c((e) => e.locale), r = n === "zh" ? ot : at, i = w[e];
	return /* @__PURE__ */ g("span", {
		className: `pk2-new-card${t ? " pk2-new-card-compact" : ""}`,
		children: [/* @__PURE__ */ h("span", {
			className: "pk2-art",
			children: /* @__PURE__ */ h("img", {
				src: ct(e),
				alt: ""
			})
		}), /* @__PURE__ */ g("span", {
			className: "pk2-new-card-body",
			children: [
				/* @__PURE__ */ h("strong", { children: dt(e, n) }),
				/* @__PURE__ */ h("span", {
					className: "pk2-points",
					children: i.points
				}),
				/* @__PURE__ */ h(pt, { cost: i.cost }),
				i.bonus && /* @__PURE__ */ h("small", { children: r.parkBonus[i.bonus] }),
				/* @__PURE__ */ g("span", {
					className: "pk2-card-hint",
					children: [n === "zh" ? "选择 / 查看" : "Select / details", " ›"]
				})
			]
		})]
	});
}
function gt({ id: e, compact: t = !1 }) {
	let n = c((e) => e.locale), r = n === "zh" ? ot : at, i = x[e];
	return /* @__PURE__ */ g("span", {
		className: `pk2-new-card${t ? " pk2-new-card-compact" : ""}`,
		children: [/* @__PURE__ */ h(mt, { id: e }), /* @__PURE__ */ g("span", {
			className: "pk2-new-card-body",
			children: [
				/* @__PURE__ */ h("strong", { children: ft(e, n) }),
				/* @__PURE__ */ h(pt, { cost: { sun: i.cost } }),
				/* @__PURE__ */ g("small", { children: [
					r.gearTrigger[i.trigger],
					"：",
					r.gearEffect[i.effect]
				] }),
				/* @__PURE__ */ g("span", {
					className: "pk2-card-hint",
					children: [n === "zh" ? "选择 / 查看" : "Select / details", " ›"]
				})
			]
		})]
	});
}
//#endregion
//#region src/game/redesigned-view.tsx
function _t({ anchor: e, style: t, ...n }) {
	let { ref: r, hidden: i } = s(e);
	return /* @__PURE__ */ h("button", {
		...n,
		ref: r,
		style: {
			...t,
			visibility: i ? "hidden" : void 0
		}
	});
}
function vt({ name: e }) {
	let { ref: t } = s(e);
	return /* @__PURE__ */ h("span", {
		ref: t,
		className: "pk2-anchor"
	});
}
function yt({ children: e }) {
	let { ref: t } = s("pk2:board");
	return /* @__PURE__ */ h("div", {
		className: "pk2-trail-map",
		ref: t,
		children: e
	});
}
var bt = (e) => ({
	left: `${e[0] / 348 * 100}%`,
	top: `${e[1] / 546 * 100}%`
}), xt = (e, t) => t.sites[e === "parks" ? 8 : te.indexOf(e)], St = (e, t) => ({
	die: ["掷一次步道骰。", "Roll the trail die."],
	wildlife: ["支付 1 个资源，换取 1 个野生动物。", "Pay 1 resource to gain 1 wildlife."],
	forest: ["获得 1 个森林。", "Gain 1 forest."],
	sun: ["获得 2 个阳光。", "Gain 2 sun."],
	photoCanteen: ["支付 1 个资源拍照，或取得水壶标记。", "Pay 1 resource for a photo, or gain a canteen token."],
	gear: ["购买一张装备。", "Purchase a gear card."],
	water: ["获得 2 个水。", "Gain 2 water."],
	mountain: ["获得 1 个山。", "Gain 1 mountain."],
	parks: ["访问或预订公园。", "Visit or reserve parks."]
})[e][t === "zh" ? 0 : 1];
function Ct() {
	return /* @__PURE__ */ g("svg", {
		className: "pk2-terrain",
		viewBox: "0 0 348 546",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ h("path", {
				fill: "#3b7959",
				d: "M0 0h348v155l-77 10-68-14-87 17L0 151z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#9ab4bc",
				d: "M0 151l116 17 87-17 68 14 77-10v155l-75-10-64 14-87-17L0 311z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#c66c45",
				d: "M0 311l122-14 87 17 64-14 75 10v236H0z"
			}),
			/* @__PURE__ */ h("g", {
				fill: "#64a45e",
				opacity: ".85",
				children: Array.from({ length: 34 }, (e, t) => /* @__PURE__ */ h("circle", {
					cx: (t * 71 + 11) % 348,
					cy: (t * 37 + 8) % 153,
					r: 3 + t % 6
				}, t))
			}),
			/* @__PURE__ */ h("path", {
				fill: "#5d819a",
				d: "m0 287 70-117 69 117 54-101 90 114 38-92 27 63v39H0z"
			}),
			/* @__PURE__ */ h("path", {
				fill: "#e5e7dc",
				d: "m44 214 26-44 25 43-24-13-13 18zm126 15 23-43 28 36-22-12-12 17zM306 245l15-37 20 45-20-19z"
			}),
			/* @__PURE__ */ h("g", {
				stroke: "#e5a276",
				strokeWidth: "3",
				fill: "none",
				opacity: ".8",
				children: [
					344,
					376,
					408,
					440,
					472,
					504,
					536
				].map((e) => /* @__PURE__ */ h("path", { d: `M0 ${e}l60 -18 57 8 67 -20 68 9 49 -18 47 8` }, e))
			}),
			/* @__PURE__ */ h("polyline", {
				points: nt.map(([e, t]) => `${e},${t}`).join(" "),
				fill: "none",
				stroke: "#375f4d",
				strokeWidth: "17",
				strokeLinejoin: "round",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ h("polyline", {
				points: nt.map(([e, t]) => `${e},${t}`).join(" "),
				fill: "none",
				stroke: "#f0d49c",
				strokeWidth: "11",
				strokeLinejoin: "round",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ h("polyline", {
				points: nt.map(([e, t]) => `${e},${t}`).join(" "),
				fill: "none",
				stroke: "#b89161",
				strokeWidth: "2",
				strokeDasharray: "2 12",
				strokeLinecap: "round"
			})
		]
	});
}
function wt(e, t, n, r, i, a) {
	let o = e.action, s = e.kind === "skip" ? a("games.parks2.skip") : e.kind === "visit" ? a("games.parks2.visit") : e.kind === "reserve" ? a("games.parks2.reserve") : e.kind === "gear" ? a(t.kind === "useGear" ? "games.parks2.use" : "games.parks2.buy") : e.kind === "photo" ? a("games.parks2.takePhoto") : e.kind === "canteen" ? i === "zh" ? "取得水壶标记" : "Gain a canteen token" : e.kind === "waterRow" ? a("games.parks2.fillCanteen") : e.kind === "wildlife" ? a("games.parks2.wildlifeTrade") : e.kind === "camp" ? a("games.parks2.campSpace", { n: (e.id ?? 0) + 1 }) : e.kind === "resource" ? a("games.parks2.collectResource") : a("games.parks2.resolve");
	return o.type === "resolve" && o.choice === "done" && (s = a("games.parks2.doneParks")), e.kind === "resolve" && t.kind.startsWith("gain") && (s = a("games.parks2.resourceToBackpack")), e.kind === "end" && e.id !== void 0 && (s = `${[
		a("games.parks2.parksAction"),
		a("games.parks2.takePhoto"),
		a("games.parks2.buy")
	][e.id]} · ${a(n.endClaims[e.id] ? "games.parks2.rewardTaken" : "games.parks2.rewardAvailable")}`), (e.kind === "visit" || e.kind === "reserve") && e.id !== void 0 && (s += ` · ${e.id < 0 ? a("games.parks2.drawTop") : dt(e.id, i)}`), e.kind === "gear" && e.id !== void 0 && (s += ` · ${e.id < 0 ? a("games.parks2.drawTop") : ft(e.id, i)}`), e.kind === "canteen" && e.id !== void 0 && (s += ` · ${e.id < 0 ? a("games.parks2.drawTop") : r.canteenText[b[e.id]]}`), e.kind === "camp" && e.id !== void 0 && n.campsite !== null && (s += ` · ${r.campText[ne[n.campsite][e.id]]}`), e.kind === "resource" && e.id !== void 0 && (s += ` · ${r.resources[e.id]}`), e.row !== void 0 && (e.kind === "waterRow" || e.kind === "canteen") && (s += ` · ${a("games.parks2.canteenRow", { n: e.row + 1 })}`), o.type === "resolve" && o.choice && [
		"mountainSun",
		"mountainWater",
		"forestSun",
		"forestWater"
	].includes(o.choice) && (s += ` · ${r.resources[+!o.choice.startsWith("mountain")]} + ${r.resources[o.choice.endsWith("Sun") ? 2 : 3]}`), e.payment && (s += ` · ${a("games.parks2.pay")} ${T.map((t, n) => e.payment[t] ? `${r.resources[n]} ${e.payment[t]}` : "").filter(Boolean).join(" / ") || a("games.parks2.free")}`), s;
}
function Tt(e) {
	let t = e.Screen, n = e.public, s = e.private, f = c((e) => e.locale), p = f === "zh" ? ot : at, _ = l(), v = (e, t) => f === "zh" ? e : t, [ee, y] = a("trail"), [x, S] = a("park"), [C, O] = a(null), [k, A] = a(null), [j, M] = a(null), [N, P] = a(null), [re, ie] = a(e.myRid), [ae, F] = a(!1), [I, oe] = a(E()), [se, L] = a(0), ce = i(null), le = i(n.log.length > 0), ue = i(null), de = i(null), R = n.players.find((t) => t.rid === e.myRid), z = n.players.find((e) => e.rid === re) ?? R ?? n.players[0], B = n.phase !== "done" && n.active === e.myRid && !!R, me = (t) => e.members.find((e) => e.rid === t), V = (e) => {
		if (e === "$ranger") return _("games.parks2.ranger");
		let t = me(e);
		if (!t) return _(u[0].nameKey);
		let n = d(t, f);
		return !n || t.rid.startsWith("preview-") && /^Player \d+$/.test(n) ? _(u[t.colorIndex % u.length].nameKey) : n;
	}, he = B && n.phase === "move" && R ? fe(n, R) : [], H = C === null ? [] : he.filter((e) => e.hiker === C), U = B && R ? n.tasks.flatMap((e) => pe(n, R, e).map((t) => ({
		task: e,
		choice: t
	}))) : [], W = (e) => U.filter(({ choice: t }) => t.id === e.id && (e.kind === "park" ? t.kind === "visit" || t.kind === "reserve" : t.kind === e.kind)), ge = j ? W(j) : [], _e = (t) => {
		e.send(t), A(null), M(null), P(null), t.type === "move" && O(null), t.type === "discard" && oe(E());
	}, ve = i(e.myRid);
	r(() => {
		ve.current !== e.myRid && (ve.current = e.myRid, ie(e.myRid), O(null), M(null), P(null), A(null));
	}, [e.myRid]), r(() => {
		le.current && n.log.length === 0 && n.season === 0 && n.players.every((e) => e.hikers.every((e) => e === -1)) && (ce.current?.scrollTo({ top: 0 }), y("trail"), O(null), A(null), M(null), P(null)), le.current = n.log.length > 0;
	}, [
		n.log,
		n.players,
		n.season
	]), r(() => {
		C !== null && !he.some((e) => e.hiker === C) ? (O(null), A(null)) : k !== null && !H.some((e) => e.destination === k) && A(null), j && ge.length === 0 && M(null);
	}, [
		C,
		he,
		k,
		H,
		j,
		ge.length
	]), r(() => {
		k !== null && ue.current?.scrollIntoView({
			block: "center",
			behavior: "smooth"
		});
	}, [k]), r(() => {
		se > 0 && de.current?.scrollIntoView({
			block: "start",
			behavior: "smooth"
		});
	}, [se]);
	let ye = B ? `${n.phase}:${n.tasks.map((e) => `${e.id}-${e.kind}`).join(",")}` : "", be = i("");
	r(() => {
		if (!ye) {
			be.current = "";
			return;
		}
		if (be.current === ye) return;
		be.current = ye;
		let t = n.tasks.find((e) => [
			"parks",
			"gear",
			"canteen"
		].includes(e.kind));
		t ? (y("market"), S(t.kind === "parks" ? "park" : t.kind)) : n.tasks.some((e) => e.kind === "useGear") ? (ie(e.myRid), y("journey")) : (n.phase === "move" || n.tasks.some((e) => e.kind === "camp")) && y("trail");
	}, [
		ye,
		n.phase,
		n.tasks,
		e.myRid
	]);
	let xe = [...n.players.flatMap((e) => e.hikers.map((t, n) => ({
		key: `${e.rid}-${n}`,
		site: t,
		rid: e.rid,
		index: n,
		ranger: !1,
		rangerIndex: -1
	}))), ...n.rangerHikers.flatMap((e, t) => e.map((e, n) => ({
		key: `ranger-${t}-${n}`,
		site: e,
		rid: "$ranger",
		index: n,
		ranger: !0,
		rangerIndex: t
	})))], Se = (e) => e < 0 ? _("games.parks2.trailhead") : e === 9 ? _("games.parks2.trailEnd") : xt(n.trail[e], p), Ce = (e, t) => t.map((t, r) => /* @__PURE__ */ g("button", {
		type: "button",
		className: "pk2-action-choice",
		onClick: () => _e(t.action),
		children: [wt(t, e, n, p, f, _), /* @__PURE__ */ h($, {})]
	}, `${e.id}-${r}`)), we = (e) => {
		let t = [
			"gainMountain",
			"gainForest",
			"gainSun",
			"gainWater",
			"gainWildlife"
		].indexOf(e.kind);
		return t >= 0 ? `${_("games.parks2.collectResource")} · ${p.resources[t]} ${e.amount}` : e.kind === "site" ? e.detail === "end" ? _("games.parks2.trailEnd") : e.detail && (te.includes(e.detail) || e.detail === "parks") ? St(e.detail, f) : _("games.parks2.chooseAction") : e.kind === "badge" ? _("games.parks2.shutterbugSite") : _("games.parks2.chooseAction");
	}, G = U.filter(({ choice: e }) => e.id === void 0 || ![
		"visit",
		"reserve",
		"gear",
		"canteen",
		"camp"
	].includes(e.kind)), K = D(I), q = R ? Math.max(0, D(R.backpack) - Math.max(0, 12 - (n.projects.includes(1) ? R.gear.length : 0))) : 0, J = B && (n.phase === "choosePassion" || n.phase === "ranger" || n.phase === "discard" || n.phase === "resolve" || n.phase === "season" || n.phase === "move" && k !== null);
	return /* @__PURE__ */ g("div", {
		className: "pk2-screen pk2-redesign",
		children: [
			/* @__PURE__ */ h(t, {
				adaptive: !0,
				scroll: !1,
				className: "pk2-layout",
				banner: /* @__PURE__ */ g("header", {
					className: "pk2-new-header",
					children: [
						/* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("strong", { children: _("games.parks2.name") }), /* @__PURE__ */ g("span", { children: [
							p.seasons[n.season],
							" · ",
							n.phase === "done" ? v("旅程结束", "Journey complete") : B ? _("games.parks2.yourTurn") : _("games.parks2.waiting", { name: V(n.active) })
						] })] }),
						/* @__PURE__ */ g("div", {
							className: "pk2-header-seats",
							children: [e.reviewControl, n.players.map((e) => {
								let t = me(e.rid);
								return /* @__PURE__ */ h(_t, {
									anchor: `pk2:seat:${e.rid}`,
									type: "button",
									"aria-label": V(e.rid),
									title: V(e.rid),
									onClick: () => {
										ie(e.rid), y("journey");
									},
									style: { background: u[(t?.colorIndex ?? 0) % u.length].hex },
									children: /* @__PURE__ */ h("img", {
										src: o[(t?.avatar ?? 0) % o.length],
										alt: ""
									})
								}, e.rid);
							})]
						}),
						/* @__PURE__ */ h("div", {
							className: "pk2-header-resources",
							children: R && /* @__PURE__ */ h(pt, {
								cost: R.backpack,
								showZero: !0
							})
						})
					]
				}),
				children: /* @__PURE__ */ g("div", {
					className: "pk2-new-layout",
					children: [
						/* @__PURE__ */ g("div", {
							ref: ce,
							className: `pk2-new-content pk2-tab-${ee}${J ? " pk2-has-actions" : ""}`,
							children: [
								/* @__PURE__ */ g("section", {
									className: `pk2-trail-panel${ee === "trail" ? "" : " pk2-panel-hidden"}`,
									"aria-label": v("步道", "Trail"),
									children: [
										/* @__PURE__ */ g("div", {
											className: "pk2-trail-heading",
											children: [/* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("strong", { children: B && n.phase === "move" ? C === null ? _("games.parks2.chooseHiker") : v("选择目的地", "Choose a destination") : B && n.phase === "ranger" ? _("games.parks2.chooseRanger") : v("步道", "Trail") }), R && /* @__PURE__ */ g("small", { children: [
												V(R.rid),
												" · ",
												_(R.campfire ? "games.parks2.campfireLit" : "games.parks2.campfireOut")
											] })] }), /* @__PURE__ */ g("button", {
												type: "button",
												onClick: () => F(!0),
												children: [v("图例", "Legend"), " ›"]
											})]
										}),
										/* @__PURE__ */ g(yt, { children: [
											/* @__PURE__ */ h(Ct, {}),
											nt.map((e, t) => {
												let r = t - 1, i = r >= 0 && r < 9 ? n.trail[r] : null, a = H.some((e) => e.destination === r), o = r >= 0 && r < 9 && xe.some((e) => e.site === r), s = r === -1 ? _("games.parks2.trailhead") : r === 9 ? _("games.parks2.trailEnd") : xt(i, p), c = [
													s,
													r >= 0 && r < 9 && n.weather[r] ? `${v("天气", "Weather")}: ${p.resources[n.weather[r] === "sun" ? 2 : 3]}` : "",
													r === n.shutterbugSite ? _("games.parks2.shutterbugSite") : "",
													n.tents.includes(r) ? _("games.parks2.tentAvailable") : "",
													o ? v("已占位", "Occupied") : ""
												].filter(Boolean).join(" · ");
												return /* @__PURE__ */ g("div", {
													className: "pk2-map-node",
													style: bt(e),
													children: [
														/* @__PURE__ */ h(vt, { name: `pk2:site:${r}` }),
														/* @__PURE__ */ g("button", {
															type: "button",
															ref: k === r ? ue : void 0,
															className: `pk2-map-site${k === r ? " pk2-map-selected" : ""}`,
															"aria-label": c,
															disabled: !a,
															onClick: () => A(r),
															children: [/* @__PURE__ */ h(Q, { kind: r === -1 ? "forest" : r === 9 ? "end" : i }), a && /* @__PURE__ */ h($, { round: !0 })]
														}),
														r >= 0 && r < 9 && n.weather[r] && /* @__PURE__ */ h("span", {
															className: "pk2-map-weather",
															title: p.resources[n.weather[r] === "sun" ? 2 : 3],
															children: /* @__PURE__ */ h(Q, { kind: n.weather[r] })
														}),
														r >= 0 && r < 9 && n.tents.includes(r) && /* @__PURE__ */ h("span", {
															className: "pk2-map-tent",
															title: _("games.parks2.tentAvailable"),
															children: /* @__PURE__ */ h(Q, { kind: "camp" })
														}),
														r === n.shutterbugSite && /* @__PURE__ */ h("span", {
															className: "pk2-map-badge",
															title: _("games.parks2.shutterbugSite"),
															children: /* @__PURE__ */ h(Q, { kind: "badge" })
														}),
														o && a && R?.campfire && /* @__PURE__ */ h("span", {
															className: "pk2-map-fire",
															title: v("进入此地点需熄灭篝火", "Entering requires extinguishing your campfire"),
															children: /* @__PURE__ */ h(Q, { kind: "fire" })
														}),
														(r === -1 || r === 9) && /* @__PURE__ */ h("span", {
															className: "pk2-map-caption",
															children: s
														})
													]
												}, r);
											}),
											xe.map((t) => {
												let r = xe.filter((e) => e.site === t.site).findIndex((e) => e.key === t.key), i = rt(t.site, r), a = me(t.rid), s = !t.ranger && t.rid === e.myRid && he.some((e) => e.hiker === t.index), c = (a?.colorIndex ?? (t.ranger ? n.players.length + t.rangerIndex : 0)) % u.length, l = u[c].hex, d = {
													left: `calc(${i.x}% + ${i.dx}px)`,
													top: `calc(${i.y}% + ${i.dy}px)`,
													"--pk2-player": l
												}, f = t.ranger ? `${_("games.parks2.ranger")} · ${_(u[c].nameKey)}` : V(t.rid), p = n.players.find((e) => e.rid === t.rid)?.hikers[+(t.index === 0)], m = p === void 0 ? "" : p === t.site ? _(t.index === 0 ? "games.parks2.hikerLeft" : "games.parks2.hikerRight") : _(t.site > p ? "games.parks2.hikerFront" : "games.parks2.hikerBack"), v = `${f}${m ? ` · ${m}` : ""} · ${Se(t.site)}`;
												return /* @__PURE__ */ g(_t, {
													type: "button",
													anchor: t.ranger ? `pk2:${t.key}` : `pk2:hiker:${t.rid}:${t.index}`,
													className: "pk2-map-hiker",
													style: d,
													"aria-label": v,
													title: v,
													"aria-pressed": s && C === t.index,
													disabled: !s,
													onClick: () => {
														O(t.index), A(null);
													},
													children: [/* @__PURE__ */ h("img", {
														src: o[(a?.avatar ?? 0) % o.length],
														alt: ""
													}), s && /* @__PURE__ */ h($, { round: !0 })]
												}, t.key);
											})
										] }),
										n.campsite !== null && n.tasks.some((e) => e.kind === "camp") && /* @__PURE__ */ g("div", {
											className: "pk2-camp-options",
											ref: de,
											children: [/* @__PURE__ */ h("h3", { children: _("games.parks2.campsite") }), ne[n.campsite].map((e, t) => {
												let r = {
													kind: "camp",
													id: t
												}, i = W(r).length > 0;
												return /* @__PURE__ */ g("button", {
													type: "button",
													disabled: !i,
													onClick: () => M(r),
													children: [
														p.campText[e],
														n.occupiedCampsites.includes(t) && ` · ${_("games.parks2.campOccupied")}`,
														i && /* @__PURE__ */ h($, {})
													]
												}, t);
											})]
										})
									]
								}),
								/* @__PURE__ */ g("section", {
									className: `pk2-market-panel${ee === "market" ? "" : " pk2-panel-hidden"}`,
									children: [/* @__PURE__ */ g("div", {
										className: "pk2-panel-heading",
										children: [/* @__PURE__ */ h("h2", { children: v("公园与装备", "Parks and gear") }), /* @__PURE__ */ h("div", {
											className: "pk2-switch",
											children: [
												"park",
												"gear",
												"canteen"
											].map((e) => /* @__PURE__ */ h("button", {
												type: "button",
												"aria-pressed": x === e,
												onClick: () => {
													S(e), M(null);
												},
												children: e === "park" ? v("公园", "Parks") : e === "gear" ? v("装备", "Gear") : v("水壶", "Canteens")
											}, e))
										})]
									}), /* @__PURE__ */ g("div", {
										className: "pk2-market-list",
										children: [
											x === "park" && n.parkDisplay.map((e, t) => /* @__PURE__ */ h(_t, {
												anchor: `pk2:park-slot:${t}`,
												type: "button",
												className: e < 0 ? "pk2-market-empty" : "pk2-market-item",
												disabled: e < 0,
												onClick: () => {
													let t = {
														kind: "park",
														id: e
													};
													W(t).length ? M(t) : P(t);
												},
												children: e < 0 ? v("空牌位", "Empty space") : /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(ht, {
													id: e,
													compact: !0
												}), W({
													kind: "park",
													id: e
												}).length > 0 && /* @__PURE__ */ h($, {})] })
											}, t)),
											x === "park" && R?.reserved.map((e) => W({
												kind: "park",
												id: e
											}).length > 0 && /* @__PURE__ */ g("button", {
												type: "button",
												className: "pk2-market-item",
												onClick: () => M({
													kind: "park",
													id: e
												}),
												children: [
													/* @__PURE__ */ h(ht, {
														id: e,
														compact: !0
													}),
													/* @__PURE__ */ h("span", {
														className: "pk2-reserved-label",
														children: _("games.parks2.reserved")
													}),
													/* @__PURE__ */ h($, {})
												]
											}, `reserved-${e}`)),
											x === "gear" && n.gearMarket.map((e, t) => /* @__PURE__ */ h(_t, {
												anchor: `pk2:gear-slot:${t}`,
												type: "button",
												className: e < 0 ? "pk2-market-empty" : "pk2-market-item",
												disabled: e < 0,
												onClick: () => {
													let t = {
														kind: "gear",
														id: e
													};
													W(t).length ? M(t) : P(t);
												},
												children: e < 0 ? v("空牌位", "Empty space") : /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(gt, {
													id: e,
													compact: !0
												}), W({
													kind: "gear",
													id: e
												}).length > 0 && /* @__PURE__ */ h($, {})] })
											}, t)),
											x === "canteen" && n.canteenDisplay.map((e, t) => /* @__PURE__ */ g(_t, {
												anchor: `pk2:canteen-slot:${t}`,
												type: "button",
												className: "pk2-market-item pk2-canteen-item",
												onClick: () => {
													let t = {
														kind: "canteen",
														id: e
													};
													W(t).length ? M(t) : P(t);
												},
												children: [
													/* @__PURE__ */ h(Q, { kind: "canteen" }),
													/* @__PURE__ */ h("span", { children: p.canteenText[b[e]] }),
													W({
														kind: "canteen",
														id: e
													}).length > 0 && /* @__PURE__ */ h($, {})
												]
											}, `${e}-${t}`)),
											/* @__PURE__ */ g(_t, {
												anchor: `pk2:${x === "park" ? "park" : x === "gear" ? "gear" : "canteen"}-deck`,
												type: "button",
												className: "pk2-deck",
												disabled: !W({
													kind: x,
													id: -1
												}).length,
												onClick: () => M({
													kind: x,
													id: -1
												}),
												children: [
													_("games.parks2.drawTop"),
													" · ",
													x === "park" ? n.parkDeckCount : x === "gear" ? n.gearDeckCount : n.canteenDeckCount,
													W({
														kind: x,
														id: -1
													}).length > 0 && /* @__PURE__ */ h($, {})
												]
											})
										]
									})]
								}),
								/* @__PURE__ */ g("section", {
									className: "pk2-journey-panel",
									hidden: ee !== "journey",
									children: [/* @__PURE__ */ g("div", {
										className: "pk2-panel-heading",
										children: [/* @__PURE__ */ h("h2", { children: v("旅程", "Journey") }), /* @__PURE__ */ h("div", {
											className: "pk2-players",
											children: n.players.map((e) => {
												let t = me(e.rid);
												return /* @__PURE__ */ g("button", {
													type: "button",
													"aria-pressed": z.rid === e.rid,
													onClick: () => ie(e.rid),
													children: [/* @__PURE__ */ h("span", {
														style: { background: u[(t?.colorIndex ?? 0) % u.length].hex },
														children: /* @__PURE__ */ h("img", {
															src: o[(t?.avatar ?? 0) % o.length],
															alt: ""
														})
													}), V(e.rid)]
												}, e.rid);
											})
										})]
									}), /* @__PURE__ */ g("div", {
										className: "pk2-journey-content",
										children: [
											/* @__PURE__ */ g("div", {
												className: "pk2-journey-summary",
												children: [
													/* @__PURE__ */ h("strong", { children: V(z.rid) }),
													/* @__PURE__ */ h(pt, {
														cost: z.backpack,
														showZero: !0
													}),
													/* @__PURE__ */ g("span", { children: [
														_("games.parks2.photos"),
														" ",
														z.photos,
														" · ",
														_(z.campfire ? "games.parks2.campfireLit" : "games.parks2.campfireOut")
													] })
												]
											}),
											z.passion !== null && /* @__PURE__ */ g("article", {
												className: "pk2-info-card",
												children: [
													/* @__PURE__ */ h("h3", { children: p.passions[z.passion] }),
													/* @__PURE__ */ h("p", { children: p.passionObjectives[z.passion] }),
													/* @__PURE__ */ h("p", { children: p.passionPowers[z.passion] }),
													/* @__PURE__ */ h("p", { children: p.passionScores[z.passion] }),
													z.passionChoice && /* @__PURE__ */ h("strong", { children: _(z.passionChoice === "gear" ? "games.parks2.selectedAbility" : "games.parks2.selectedScore") })
												]
											}),
											/* @__PURE__ */ h("h3", { children: v("水壶", "Canteens") }),
											z.canteens.map((e, t) => /* @__PURE__ */ g("div", {
												className: "pk2-water-row",
												children: [
													/* @__PURE__ */ h("strong", { children: _("games.parks2.canteenRow", { n: t + 1 }) }),
													/* @__PURE__ */ h("span", { children: e.tokens.map((e) => p.canteenText[b[e]]).join(" · ") || v("空位", "Empty") }),
													/* @__PURE__ */ h("small", { children: e.filled ? v("已装满", "Filled") : v("未装满", "Unfilled") })
												]
											}, t)),
											/* @__PURE__ */ g("h3", { children: [
												v("装备", "Gear"),
												" · ",
												z.gear.length
											] }),
											/* @__PURE__ */ h("div", {
												className: "pk2-collection",
												children: z.gear.map((e) => /* @__PURE__ */ g(_t, {
													anchor: `pk2:gear:${z.rid}:${e}`,
													type: "button",
													className: "pk2-market-item",
													onClick: () => {
														let t = {
															kind: "gear",
															id: e
														};
														W(t).length ? M(t) : P(t);
													},
													children: [/* @__PURE__ */ h(gt, {
														id: e,
														compact: !0
													}), W({
														kind: "gear",
														id: e
													}).length > 0 && /* @__PURE__ */ h($, {})]
												}, e))
											}),
											[["reserved", z.reserved], ["visited", z.visited]].map(([e, t]) => /* @__PURE__ */ g("div", { children: [/* @__PURE__ */ g("h3", { children: [
												_(e === "reserved" ? "games.parks2.reserved" : "games.parks2.visited"),
												" · ",
												t.length
											] }), /* @__PURE__ */ h("div", {
												className: "pk2-collection",
												children: t.map((e) => /* @__PURE__ */ g(_t, {
													anchor: `pk2:park:${z.rid}:${e}`,
													type: "button",
													className: "pk2-market-item",
													onClick: () => {
														let t = {
															kind: "park",
															id: e
														};
														W(t).length ? M(t) : P(t);
													},
													children: [/* @__PURE__ */ h(ht, {
														id: e,
														compact: !0
													}), W({
														kind: "park",
														id: e
													}).length > 0 && /* @__PURE__ */ h($, {})]
												}, e))
											})] }, e))
										]
									})]
								}),
								/* @__PURE__ */ g("section", {
									className: "pk2-status-panel",
									hidden: ee !== "status",
									children: [
										/* @__PURE__ */ h("div", {
											className: "pk2-panel-heading",
											children: /* @__PURE__ */ h("h2", { children: v("局况", "Game status") })
										}),
										/* @__PURE__ */ g("div", {
											className: "pk2-info-card",
											children: [/* @__PURE__ */ g("h3", { children: [
												p.seasons[n.season],
												" · ",
												_("games.parks2.seasonGoal")
											] }), /* @__PURE__ */ h("p", { children: p.seasonDetails[n.season][n.seasonTiles[n.season]] })]
										}),
										/* @__PURE__ */ g("div", {
											className: "pk2-info-card",
											children: [
												/* @__PURE__ */ h("h3", { children: v("玩家与标记", "Players and markers") }),
												n.players.map((e) => /* @__PURE__ */ g("p", { children: [
													V(e.rid),
													" · ",
													/* @__PURE__ */ h(pt, {
														cost: e.backpack,
														showZero: !0
													}),
													" · ",
													_("games.parks2.photos"),
													" ",
													e.photos
												] }, e.rid)),
												/* @__PURE__ */ h("p", { children: _("games.parks2.firstHikerHolder", { name: V(n.firstHiker) }) }),
												/* @__PURE__ */ h("p", { children: _("games.parks2.badgeHolder", { name: n.shutterbugOwner ? V(n.shutterbugOwner) : _("games.parks2.badgeNone") }) })
											]
										}),
										/* @__PURE__ */ g("div", {
											className: "pk2-info-card",
											children: [
												/* @__PURE__ */ h("h3", { children: _("games.parks2.suppliesTitle") }),
												/* @__PURE__ */ h(pt, {
													cost: n.supplies,
													showZero: !0
												}),
												/* @__PURE__ */ g("p", { children: [
													_("games.parks2.photoSupply"),
													" ",
													n.photosLeft,
													" · ",
													_("games.parks2.albumSupply"),
													" ",
													n.photoAlbumsLeft
												] }),
												/* @__PURE__ */ g("p", { children: [
													_("games.parks2.parksDeck"),
													" ",
													n.parkDeckCount,
													" · ",
													_("games.parks2.gearDeck"),
													" ",
													n.gearDeckCount,
													" · ",
													_("games.parks2.canteenDeck"),
													" ",
													n.canteenDeckCount
												] })
											]
										}),
										/* @__PURE__ */ g("div", {
											className: "pk2-info-card",
											children: [/* @__PURE__ */ h("h3", { children: _("games.parks2.trailEnd") }), n.endClaims.map((e, t) => /* @__PURE__ */ g("p", { children: [
												[
													_("games.parks2.parksAction"),
													_("games.parks2.takePhoto"),
													_("games.parks2.buy")
												][t],
												" · ",
												e ? _("games.parks2.rewardClaimed", { name: V(e) }) : _("games.parks2.rewardAvailable")
											] }, t))]
										}),
										n.campsite !== null && /* @__PURE__ */ g("div", {
											className: "pk2-info-card",
											children: [/* @__PURE__ */ h("h3", { children: _("games.parks2.campsite") }), ne[n.campsite].map((e, t) => /* @__PURE__ */ g("p", { children: [
												p.campText[e],
												" · ",
												n.occupiedCampsites.includes(t) ? _("games.parks2.campOccupied") : v("空营位", "Unoccupied")
											] }, t))]
										}),
										n.projects.length > 0 && /* @__PURE__ */ g("div", {
											className: "pk2-info-card",
											children: [/* @__PURE__ */ h("h3", { children: v("志愿项目", "Projects") }), n.projects.map((e) => /* @__PURE__ */ g("p", { children: [
												/* @__PURE__ */ h("strong", { children: p.projects[e] }),
												" · ",
												p.projectText[e]
											] }, e))]
										})
									]
								})
							]
						}),
						J && /* @__PURE__ */ g("aside", {
							className: "pk2-action-dock",
							"aria-live": "polite",
							children: [
								n.phase === "move" && k !== null && H.some((e) => e.destination === k) && /* @__PURE__ */ g(m, { children: [
									/* @__PURE__ */ h("strong", { children: k === 9 ? _("games.parks2.trailEnd") : xt(n.trail[k], p) }),
									H.some((e) => e.destination === k && !e.camp) && /* @__PURE__ */ g(m, { children: [
										/* @__PURE__ */ h("span", { children: k === 9 ? v("选择公园、拍照或装备行动。", "Choose a parks, photo or gear action.") : St(n.trail[k], f) }),
										k < 9 && n.weather[k] && /* @__PURE__ */ g("span", { children: [v("地点行动的天气：获得 1 个", "Site action weather: gain 1 "), p.resources[n.weather[k] === "sun" ? 2 : 3]] }),
										k === n.shutterbugSite && /* @__PURE__ */ h("span", { children: v("地点行动可取得摄影徽章。", "The site action grants the Shutterbug Badge.") })
									] }),
									H.some((e) => e.destination === k && e.camp) && /* @__PURE__ */ h("span", { children: v("露营改为执行营位效果，不取得地点或天气奖励。", "Camping uses a campsite effect instead of the site and weather rewards.") }),
									k < 9 && xe.some((e) => e.site === k) && /* @__PURE__ */ h("span", { children: v("进入已占地点需熄灭篝火。", "Entering an occupied site extinguishes your campfire.") }),
									/* @__PURE__ */ h("div", {
										className: "pk2-action-options",
										children: H.filter((e) => e.destination === k).map((e) => /* @__PURE__ */ g("button", {
											className: "pk2-action-choice",
											type: "button",
											onClick: () => _e(e),
											children: [e.camp ? v("前往露营", "Camp") : v("前往", "Move"), /* @__PURE__ */ h($, {})]
										}, String(e.camp)))
									})
								] }),
								n.phase === "choosePassion" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("strong", { children: _("games.parks2.choosePassion") }), /* @__PURE__ */ h("div", {
									className: "pk2-action-options",
									children: s?.passionOptions.map((e) => /* @__PURE__ */ g("button", {
										type: "button",
										className: "pk2-action-choice",
										onClick: () => _e({
											type: "selectPassion",
											passion: e
										}),
										children: [
											/* @__PURE__ */ h("strong", { children: p.passions[e] }),
											" · ",
											p.passionObjectives[e],
											" · ",
											p.passionPowers[e],
											" · ",
											p.passionScores[e],
											/* @__PURE__ */ h($, {})
										]
									}, e))
								})] }),
								n.phase === "ranger" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("strong", { children: _("games.parks2.chooseRanger") }), /* @__PURE__ */ h("div", {
									className: "pk2-action-options",
									children: n.rangerQueue.map((e) => /* @__PURE__ */ g("button", {
										type: "button",
										className: "pk2-action-choice",
										onClick: () => _e({
											type: "chooseRanger",
											ranger: e
										}),
										children: [
											_("games.parks2.ranger"),
											" · ",
											_(u[(n.players.length + e) % u.length].nameKey),
											" · ",
											n.rangerHikers[e].map(Se).join(" / "),
											/* @__PURE__ */ h($, {})
										]
									}, e))
								})] }),
								n.phase === "discard" && R && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("strong", { children: [
									_("games.parks2.chooseDiscard"),
									" · ",
									K,
									"/",
									q
								] }), /* @__PURE__ */ g("div", {
									className: "pk2-action-options",
									children: [T.map((e, t) => /* @__PURE__ */ g("span", {
										className: "pk2-discard-control",
										children: [
											/* @__PURE__ */ h(Q, { kind: e }),
											I[e],
											/* @__PURE__ */ g("button", {
												type: "button",
												"aria-label": `${v("减少", "Remove")} ${p.resources[t]}`,
												disabled: !I[e],
												onClick: () => oe({
													...I,
													[e]: I[e] - 1
												}),
												children: ["−", I[e] > 0 && /* @__PURE__ */ h($, {})]
											}),
											/* @__PURE__ */ g("button", {
												type: "button",
												"aria-label": `${v("增加", "Add")} ${p.resources[t]}`,
												disabled: I[e] >= R.backpack[e] || K >= q,
												onClick: () => oe({
													...I,
													[e]: I[e] + 1
												}),
												children: ["+", I[e] < R.backpack[e] && K < q && /* @__PURE__ */ h($, {})]
											}),
											/* @__PURE__ */ h("span", {
												className: "pk2-sr-only",
												children: p.resources[t]
											})
										]
									}, e)), /* @__PURE__ */ g("button", {
										type: "button",
										className: "pk2-action-choice",
										disabled: K !== q,
										onClick: () => _e({
											type: "discard",
											payment: I
										}),
										children: [_("games.parks2.discardConfirm"), K === q && /* @__PURE__ */ h($, {})]
									})]
								})] }),
								(n.phase === "resolve" || n.phase === "season") && R && /* @__PURE__ */ g(m, { children: [
									n.tasks.some((e) => e.kind === "choosePassion") && R.passion !== null && /* @__PURE__ */ h("div", {
										className: "pk2-action-options",
										children: ["gear", "score"].map((e) => /* @__PURE__ */ g("button", {
											type: "button",
											className: "pk2-action-choice",
											onClick: () => _e({
												type: "passion",
												choice: e
											}),
											children: [e === "gear" ? p.passionPowers[R.passion] : p.passionScores[R.passion], /* @__PURE__ */ h($, {})]
										}, e))
									}),
									j && ge.length > 0 ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("strong", { children: j.kind === "park" && j.id >= 0 ? dt(j.id, f) : j.kind === "gear" && j.id >= 0 ? ft(j.id, f) : _("games.parks2.chooseAction") }), /* @__PURE__ */ g("div", {
										className: "pk2-action-options",
										children: [
											n.tasks.map((e) => Ce(e, ge.filter((t) => t.task.id === e.id).map((e) => e.choice))),
											j.id >= 0 && j.kind !== "camp" && /* @__PURE__ */ h("button", {
												type: "button",
												onClick: () => P(j),
												children: v("查看详情", "Details")
											}),
											/* @__PURE__ */ h("button", {
												type: "button",
												onClick: () => M(null),
												children: _("games.parks2.close")
											})
										]
									})] }) : /* @__PURE__ */ g(m, { children: [
										n.tasks.map((e) => {
											let t = G.filter((t) => t.task.id === e.id).map((e) => e.choice);
											return t.length > 0 && /* @__PURE__ */ g("div", {
												className: "pk2-task-group",
												children: [/* @__PURE__ */ h("strong", { children: we(e) }), /* @__PURE__ */ h("div", {
													className: "pk2-action-options",
													children: Ce(e, t)
												})]
											}, e.id);
										}),
										U.some(({ choice: e }) => e.id !== void 0 && [
											"visit",
											"reserve",
											"gear",
											"canteen"
										].includes(e.kind)) && /* @__PURE__ */ g("button", {
											type: "button",
											className: "pk2-action-choice",
											onClick: () => y(n.tasks.some((e) => e.kind === "useGear") ? "journey" : "market"),
											children: [v("选择牌件", "Choose a card"), /* @__PURE__ */ h($, {})]
										}),
										U.some(({ choice: e }) => e.kind === "camp") && /* @__PURE__ */ g("button", {
											type: "button",
											className: "pk2-action-choice",
											onClick: () => {
												y("trail"), L((e) => e + 1);
											},
											children: [v("选择营位", "Choose a campsite"), /* @__PURE__ */ h($, {})]
										})
									] }),
									!n.tasks.some((e) => e.mandatory) && /* @__PURE__ */ g("button", {
										type: "button",
										className: "pk2-action-choice pk2-finish",
										onClick: () => _e({ type: "finish" }),
										children: [_(n.phase === "season" ? "games.parks2.finishSeason" : "games.parks2.finish"), /* @__PURE__ */ h($, {})]
									})
								] })
							]
						}),
						/* @__PURE__ */ h("nav", {
							className: "pk2-bottom-nav",
							"aria-label": v("游戏区域", "Game areas"),
							children: [
								"trail",
								"market",
								"journey",
								"status"
							].map((e) => /* @__PURE__ */ g("button", {
								type: "button",
								"aria-current": ee === e ? "page" : void 0,
								onClick: () => y(e),
								children: [/* @__PURE__ */ h(Q, { kind: e === "trail" ? "mountain" : e === "market" ? "parks" : e === "journey" ? "canteen" : "sun" }), /* @__PURE__ */ h("span", { children: e === "trail" ? v("步道", "Trail") : e === "market" ? v("公园", "Parks") : e === "journey" ? v("旅程", "Journey") : v("局况", "Status") })]
							}, e))
						})
					]
				})
			}),
			N && N.id >= 0 && /* @__PURE__ */ h("div", {
				className: "pk2-dialog",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": v("详情", "Details"),
				children: /* @__PURE__ */ g("div", {
					className: "pk2-dialog-card",
					children: [
						/* @__PURE__ */ h("button", {
							className: "pk2-dialog-close",
							type: "button",
							onClick: () => P(null),
							children: _("games.parks2.close")
						}),
						N.kind === "park" && /* @__PURE__ */ g(m, { children: [
							/* @__PURE__ */ h("img", {
								className: "pk2-detail-art",
								src: ct(N.id),
								alt: ""
							}),
							/* @__PURE__ */ h("h2", { children: dt(N.id, f) }),
							/* @__PURE__ */ g("p", { children: [
								f === "zh" ? st[N.id].zhRegion : st[N.id].enRegion,
								" · ",
								st[N.id].year
							] }),
							/* @__PURE__ */ g("strong", { children: [
								w[N.id].points,
								" ",
								v("分", "points")
							] }),
							/* @__PURE__ */ h(pt, { cost: w[N.id].cost }),
							w[N.id].bonus && /* @__PURE__ */ h("p", { children: p.parkBonus[w[N.id].bonus] }),
							/* @__PURE__ */ h("p", { children: f === "zh" ? st[N.id].zhText : st[N.id].enText })
						] }),
						N.kind === "gear" && /* @__PURE__ */ h(gt, {
							id: N.id,
							compact: !0
						}),
						N.kind === "canteen" && /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(Q, { kind: "canteen" }), /* @__PURE__ */ h("p", { children: p.canteenText[b[N.id]] })] })
					]
				})
			}),
			ae && /* @__PURE__ */ h("div", {
				className: "pk2-dialog",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": v("地图图例", "Map legend"),
				children: /* @__PURE__ */ g("div", {
					className: "pk2-dialog-card",
					children: [
						/* @__PURE__ */ h("button", {
							className: "pk2-dialog-close",
							type: "button",
							onClick: () => F(!1),
							children: _("games.parks2.close")
						}),
						/* @__PURE__ */ h("h2", { children: v("地图图例", "Map legend") }),
						/* @__PURE__ */ g("div", {
							className: "pk2-legend-list",
							children: [
								[...te, "parks"].map((e) => /* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h(Q, { kind: e }), /* @__PURE__ */ h("span", { children: xt(e, p) })] }, e)),
								/* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h(Q, { kind: "camp" }), /* @__PURE__ */ h("span", { children: _("games.parks2.tentAvailable") })] }),
								/* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h(Q, { kind: "badge" }), /* @__PURE__ */ h("span", { children: _("games.parks2.shutterbugSite") })] }),
								/* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h(Q, { kind: "fire" }), /* @__PURE__ */ h("span", { children: v("占位时需熄灭篝火", "Occupied: extinguish campfire") })] })
							]
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/game/view-player.tsx
function Et(e) {
	return /* @__PURE__ */ h(Tt, {
		...e,
		Screen: n
	});
}
//#endregion
//#region src/game/bot.ts
var Dt = {
	parkPoints: 4,
	gearValue: 9,
	canteenValue: 7,
	wildlifeCost: 1.5,
	movementCost: .45
};
function Ot(e, t) {
	let n = t.passionChoice === "gear" && t.passion !== null ? S[t.passion] : null;
	return [...e.projects.includes(0) ? [] : e.parkDisplay.filter((e) => e >= 0), ...t.reserved].filter((r) => {
		let i = N(w[r], n);
		return e.projects.includes(5) ? ["mountain", "forest"].some((e) => k({
			...i,
			[e]: i[e] + 1
		}, t.backpack).length > 0) : k(i, t.backpack).length > 0;
	}).length;
}
function kt(e, t, n, r) {
	let i = n.destination - t.hikers[n.hiker];
	if (n.destination === 9) return Ot(e, t) > 0 ? 4 : -6;
	let a = e.trail[n.destination], o = {
		die: 5,
		wildlife: 3,
		forest: 4,
		mountain: 4,
		sun: 5,
		water: 5,
		photoCanteen: 5,
		gear: 4,
		parks: 3
	}[a];
	return a === "parks" && (o += Ot(e, t) * 5), a === "gear" && t.gear.length < 2 && (o += 3), a === "photoCanteen" && t.canteens.some((e) => e.tokens.length < 2) && (o += 3), e.weather[n.destination] && (o += 2), e.shutterbugSite === n.destination && e.shutterbugOwner !== t.rid && (o += 2), n.camp && (o += 1), [
		...t.hikers,
		...e.players.filter((e) => e.rid !== t.rid).flatMap((e) => e.hikers),
		...e.rangerHikers.flat()
	].includes(n.destination) && (o -= 2), o - r.movementCost * i;
}
function At(e, t, n, r) {
	let i = n.action, a;
	return n.kind === "skip" ? -100 : (a = n.kind === "visit" && n.id !== void 0 ? 20 + w[n.id].points * r.parkPoints : n.kind === "reserve" ? 8 + (n.id === void 0 || n.id < 0 ? 2 : w[n.id].points) : n.kind === "gear" ? r.gearValue + (n.id !== void 0 && n.id >= 0 ? x[n.id].cost / 2 : 0) : n.kind === "canteen" ? r.canteenValue + (n.row === void 0 ? 0 : t.canteens[n.row].tokens.length) : n.kind === "waterRow" ? 10 + (n.row === void 0 ? 0 : t.canteens[n.row].tokens.length) : n.kind === "photo" ? 6 : n.kind === "wildlife" ? 5 : n.kind === "camp" ? 7 : n.kind === "resource" ? n.id === 4 ? 7 : 5 : n.kind === "end" ? n.id === 0 && Ot(e, t) ? 15 : n.id === 1 ? 6 : 5 : 5, n.payment && (a -= n.payment.wildlife * r.wildlifeCost + D(n.payment) * .2), i.type === "resolve" && i.choice === "done" && (a = -2), a);
}
function jt(e = Dt) {
	return (t, n) => {
		let r = t.public, i = r.players.find((e) => e.rid === n.rid);
		if (!i || r.active !== n.rid) return null;
		if (r.phase === "choosePassion") {
			let e = t.private?.passionOptions[0];
			return e === void 0 ? null : { action: {
				type: "selectPassion",
				passion: e
			} };
		}
		if (r.phase === "ranger") return r.rangerQueue.length ? { action: {
			type: "chooseRanger",
			ranger: r.rangerQueue[0]
		} } : null;
		if (r.phase === "move") {
			let t = fe(r, i);
			return t.sort((t, n) => kt(r, i, n, e) - kt(r, i, t, e)), t.length ? { action: t[0] } : null;
		}
		if (r.phase === "discard") {
			let e = D(i.backpack) - Math.max(0, 12 - (r.projects.includes(1) ? i.gear.length : 0)), t = E();
			for (let n of [...T].sort((e, t) => i.backpack[t] - i.backpack[e] || (e === "wildlife" ? 1 : t === "wildlife" ? -1 : 0))) {
				let r = Math.min(i.backpack[n], e);
				t[n] = r, e -= r;
			}
			return { action: {
				type: "discard",
				payment: t
			} };
		}
		if (r.tasks.some((e) => e.kind === "choosePassion")) return { action: {
			type: "passion",
			choice: r.season < 2 ? "gear" : "score"
		} };
		if (r.phase !== "resolve" && r.phase !== "season") return null;
		let a = r.tasks.flatMap((e) => pe(r, i, e));
		return a.sort((t, n) => At(r, i, n, e) - At(r, i, t, e)), a.length && (a[0].kind !== "skip" || r.tasks.some((e) => e.mandatory)) ? { action: a[0].action } : { action: { type: "finish" } };
	};
}
var Mt = jt(), Nt = 460, Pt = 480, Ft = {
	hiker(e, t) {
		if (!e.rid) return null;
		let n = e.data, r = t.anchor("pk2:board"), i = `pk2:hiker:${e.rid}:${n.hiker}`, a = t.anchor(i);
		if (!r || !a || n.fromSlot < 0) return null;
		let s = r.h > r.w * 2 ? it(n.from, n.fromSlot) : rt(n.from, n.fromSlot), c = {
			x: r.x + r.w * s.x / 100 + s.dx - a.w / 2,
			y: r.y + r.h * s.y / 100 + s.dy - a.h / 2,
			w: a.w,
			h: a.h
		}, l = t.member(e.rid), d = u[(l?.colorIndex ?? 0) % u.length].hex, f = t.queued ? 180 : Pt;
		return {
			ms: f,
			hide: t.queued ? [] : [i],
			node: /* @__PURE__ */ h(_, {
				from: c,
				to: a,
				ms: f,
				children: /* @__PURE__ */ h("span", {
					className: "pk2-flying-hiker",
					style: {
						width: a.w,
						height: a.h,
						background: d
					},
					children: /* @__PURE__ */ h("img", {
						src: o[(l?.avatar ?? 0) % o.length],
						alt: ""
					})
				})
			})
		};
	},
	parkCard(e, t) {
		if (!e.rid) return null;
		let n = e.data, r = t.anchor(n.from < 0 ? "pk2:park-deck" : `pk2:park-slot:${n.from}`), i = `pk2:park:${e.rid}:${n.id}`, a = t.anchor(i), o = a && a.w > 0 && a.h > 0 ? a : null, s = o ?? t.anchor(`pk2:seat:${e.rid}`);
		if (!r || !s) return null;
		let c = t.queued ? 180 : Nt;
		return {
			ms: c,
			hide: !t.queued && o ? [i] : [],
			node: /* @__PURE__ */ h(_, {
				from: r,
				to: s,
				ms: c,
				children: /* @__PURE__ */ h("span", {
					className: "pk2-flying-card",
					style: {
						width: r.w,
						height: r.h
					},
					children: /* @__PURE__ */ h(ht, {
						id: n.id,
						compact: !0
					})
				})
			})
		};
	},
	gearCard(e, t) {
		if (!e.rid) return null;
		let n = e.data, r = t.anchor(n.from < 0 ? "pk2:gear-deck" : `pk2:gear-slot:${n.from}`), i = `pk2:gear:${e.rid}:${n.id}`, a = t.anchor(i), o = a && a.w > 0 && a.h > 0 ? a : null, s = o ?? t.anchor(`pk2:seat:${e.rid}`);
		if (!r || !s) return null;
		let c = t.queued ? 180 : Nt;
		return {
			ms: c,
			hide: !t.queued && o ? [i] : [],
			node: /* @__PURE__ */ h(_, {
				from: r,
				to: s,
				ms: c,
				children: /* @__PURE__ */ h("span", {
					className: "pk2-flying-card",
					style: {
						width: r.w,
						height: r.h
					},
					children: /* @__PURE__ */ h(gt, {
						id: n.id,
						compact: !0
					})
				})
			})
		};
	},
	canteen(e, t) {
		if (!e.rid) return null;
		let n = e.data, r = t.anchor(n.from < 0 ? "pk2:canteen-deck" : `pk2:canteen-slot:${n.from}`), i = `pk2:canteen:${e.rid}:${n.token}`, a = t.anchor(i), o = a ?? t.anchor(`pk2:seat:${e.rid}`);
		if (!r || !o) return null;
		let s = t.queued ? 180 : Nt;
		return {
			ms: s,
			hide: !t.queued && a ? [i] : [],
			node: /* @__PURE__ */ h(_, {
				from: r,
				to: o,
				ms: s,
				children: /* @__PURE__ */ h("span", {
					className: "pk2-flying-canteen",
					children: /* @__PURE__ */ h(Q, { kind: "canteen" })
				})
			})
		};
	}
}, It = () => {};
function Lt(e) {
	let t = l(), n = c((e) => e.locale), r = e.public, [i, s] = a(!1), [f, p] = a(null), _ = (r) => {
		let i = e.members.find((e) => e.rid === r);
		if (!i) return t(u[0].nameKey);
		let a = d(i, n);
		return !a || i.rid.startsWith("preview-") && /^Player \d+$/.test(a) ? t(u[i.colorIndex % u.length].nameKey) : a;
	}, v = [
		["parks", t("games.parks2.scoreParks")],
		["photos", t("games.parks2.scorePhotos")],
		["photoBonus", t("games.parks2.scorePhotoBonus")],
		["season", t("games.parks2.scoreSeason")],
		["passion", t("games.parks2.scorePassion")],
		["firstHiker", t("games.parks2.scoreFirstHiker")]
	], ee = e.result.winner.map((e) => `${_(e)} ${r.scores[e] ?? ""}`).join(" · "), y = r.players.length === 1, te = y ? r.scores[r.players[0].rid] ?? 0 : 0, b = Math.min(4, Math.floor((te - 30) / 5)), x = y ? `${t("games.parks2.soloScore")} · ${te}${b >= 0 ? ` · ${(n === "zh" ? ot : at).soloRanks[b]}` : ""}` : `${t(e.result.winner.length > 1 ? "games.parks2.sharedVictory" : "games.parks2.winners")} · ${ee}`;
	return /* @__PURE__ */ g("div", {
		className: "pk2-over-root",
		children: [/* @__PURE__ */ h("div", {
			className: "pk2-over-table",
			inert: !i,
			children: /* @__PURE__ */ h(Et, {
				public: e.public,
				private: e.private,
				members: e.members,
				myRid: e.myRid,
				send: It,
				reviewControl: i ? /* @__PURE__ */ h("button", {
					type: "button",
					className: "pk2-show-results",
					onClick: () => s(!1),
					children: t("games.parks2.showResults")
				}) : void 0
			})
		}), /* @__PURE__ */ h("section", {
			className: "pk2-results",
			hidden: i,
			"aria-label": t("games.parks2.results"),
			children: /* @__PURE__ */ g("div", {
				className: "pk2-result-sheet",
				children: [
					/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ g("div", { children: [
						/* @__PURE__ */ h("span", { children: t("games.parks2.gameFinished") }),
						/* @__PURE__ */ h("h1", { children: t("games.parks2.results") }),
						/* @__PURE__ */ h("p", { children: x })
					] }), /* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => s(!0),
						children: t("games.parks2.reviewTable")
					})] }),
					/* @__PURE__ */ g("div", {
						className: "pk2-result-content",
						children: [/* @__PURE__ */ h("div", {
							className: "pk2-result-players",
							children: [...r.players].sort((e, t) => (r.scores[t.rid] ?? 0) - (r.scores[e.rid] ?? 0)).map((i, a) => {
								let s = e.members.find((e) => e.rid === i.rid), c = e.result.autopilot?.[i.rid] ?? 0;
								return /* @__PURE__ */ g("details", {
									className: "pk2-result-player",
									open: a === 0,
									children: [
										/* @__PURE__ */ g("summary", { children: [
											/* @__PURE__ */ h("span", {
												className: "pk2-score-avatar",
												style: { background: u[(s?.colorIndex ?? 0) % u.length].hex },
												children: /* @__PURE__ */ h("img", {
													src: o[(s?.avatar ?? 0) % o.length],
													alt: ""
												})
											}),
											/* @__PURE__ */ g("span", { children: [/* @__PURE__ */ h("strong", { children: _(i.rid) }), c > 0 && /* @__PURE__ */ h("small", {
												className: "pk2-score-note",
												children: t("session.autopilot.share", { n: Math.round(c * 100) })
											})] }),
											/* @__PURE__ */ h("b", { children: r.scores[i.rid] ?? "—" })
										] }),
										/* @__PURE__ */ h("div", {
											className: "pk2-result-breakdown",
											children: v.map(([e, t]) => /* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("span", { children: t }), /* @__PURE__ */ h("strong", { children: r.scoreBreakdown[i.rid]?.[e] ?? "—" })] }, e))
										}),
										/* @__PURE__ */ h("div", {
											className: "pk2-result-gallery",
											children: i.visited.map((e) => /* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("img", {
												src: ct(e),
												alt: ""
											}), /* @__PURE__ */ h("span", { children: dt(e, n) })] }, e))
										})
									]
								}, i.rid);
							})
						}), e.hintCount !== void 0 && /* @__PURE__ */ h("p", {
							className: "pk2-score-note",
							children: t("session.hint.usedCount", { n: e.hintCount })
						})]
					}),
					/* @__PURE__ */ h("footer", { children: f ? /* @__PURE__ */ g(m, { children: [
						/* @__PURE__ */ h("span", { children: t(f === "again" ? "games.parks2.confirmAgain" : "games.parks2.confirmLobby") }),
						/* @__PURE__ */ h("button", {
							type: "button",
							onClick: () => {
								f === "again" ? e.onPlayAgain?.() : e.onBackToLobby?.();
							},
							children: t(f === "again" ? "games.parks2.playAgain" : "games.parks2.backLobby")
						}),
						/* @__PURE__ */ h("button", {
							type: "button",
							onClick: () => p(null),
							children: t("games.parks2.cancel")
						})
					] }) : e.onPlayAgain || e.onBackToLobby ? /* @__PURE__ */ g(m, { children: [e.onPlayAgain && /* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => p("again"),
						children: t("games.parks2.playAgain")
					}), e.onBackToLobby && /* @__PURE__ */ h("button", {
						type: "button",
						onClick: () => p("lobby"),
						children: t("games.parks2.backLobby")
					})] }) : /* @__PURE__ */ h("span", { children: t("games.parks2.waitingHost") }) })
				]
			})
		})]
	});
}
//#endregion
//#region src/game/options.tsx
function Rt({ value: e, onChange: t }) {
	let n = l(), r = H.safeParse(e), i = r.success ? r.data : H.parse(void 0);
	return /* @__PURE__ */ g("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ h(y, {
				checked: i.camping,
				label: n("games.parks2.optCamping"),
				hint: n("games.parks2.optCampingHint"),
				accent: B.accent,
				onChange: () => t({
					...i,
					camping: !i.camping
				})
			}),
			/* @__PURE__ */ h(y, {
				checked: i.ranger,
				label: n("games.parks2.optRanger"),
				hint: n("games.parks2.optRangerHint"),
				accent: B.accent,
				onChange: () => t({
					...i,
					ranger: !i.ranger
				})
			}),
			/* @__PURE__ */ h(y, {
				checked: i.choosePassion,
				label: n("games.parks2.optPassion"),
				hint: n("games.parks2.optPassionHint"),
				accent: B.accent,
				onChange: () => t({
					...i,
					choosePassion: !i.choosePassion
				})
			}),
			/* @__PURE__ */ h(ee, {
				title: n("games.parks2.optProjects"),
				columns: 3,
				children: [
					0,
					1,
					2,
					3,
					4
				].map((e) => /* @__PURE__ */ h(v, {
					name: "parks2-projects",
					value: String(e),
					checked: i.projects === e,
					label: e,
					accent: B.accent,
					onChange: () => t({
						...i,
						projects: e
					})
				}, e))
			}),
			/* @__PURE__ */ h("p", {
				className: "text-sm opacity-70",
				children: n("games.parks2.optProjectsHint")
			})
		]
	});
}
//#endregion
//#region src/index.tsx
var zt = {
	definition: tt,
	View: Et,
	bot: Mt,
	fx: Ft,
	OverView: Lt,
	Options: Rt,
	locales: {
		zh: ot,
		en: at
	}
};
//#endregion
export { zt as default };
