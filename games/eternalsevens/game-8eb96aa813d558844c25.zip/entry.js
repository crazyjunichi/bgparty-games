import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { BottomSheet as a } from "@bgparty/sdk/bottom-sheet";
import { ConfirmButton as o } from "@bgparty/sdk/confirm-button";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { playTurn as u, useSoundEdge as d } from "@bgparty/sdk/sfx";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { SeatBadgedAvatar as p, seatName as m } from "@bgparty/sdk/ui/player-strip";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { FlySprite as v } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as y, OptionSection as b, OptionSwitch as ee } from "@bgparty/sdk/ui/game-options";
//#region src/games/eternalsevens/data.ts
var x = [
	"red",
	"blue",
	"green",
	"yellow",
	"purple",
	"rare"
], S = [
	"phoenix",
	"skeleton",
	"barong",
	"mummy",
	"kyubi",
	"minotaur",
	"ghost",
	"dragon",
	"king",
	"kappa",
	"yeti",
	"kraken",
	"cyclops",
	"djinn",
	"pegasus",
	"mermaid",
	"fairy",
	"witch",
	"medusa",
	"golem",
	"vampire"
], C = [
	"phoenix",
	"fairy",
	"witch",
	"vampire",
	"minotaur",
	"medusa",
	"pegasus",
	"barong",
	"yeti",
	"cyclops",
	"king",
	"mermaid",
	"ghost",
	"kraken",
	"skeleton",
	"mummy",
	"kyubi",
	"djinn",
	"kappa",
	"golem"
], w = (e) => e < 40 ? x[Math.floor(e / 10)] : e < 48 ? "purple" : "rare", T = (e) => e < 40 ? e % 10 + 1 : 0, E = (e, t = 0, n = 1) => ({
	kind: e,
	bonus: t,
	count: n
}), D = [
	E("rare"),
	E("discard"),
	E("eternal")
], te = {
	red: [
		E("rare", 1),
		E("eternal", 1),
		E("eternal", 1)
	],
	blue: [
		E("must", 0, 2),
		E("must", 1),
		E("move", 2)
	],
	green: [
		E("must", 1),
		E("move", 2),
		E("eternal", 1)
	],
	yellow: [
		E("discard"),
		E("discard"),
		E("eternal", 1)
	],
	phoenix: [E("rare", 1), E("eternal", 1)],
	fairy: [E("rare", 1), E("eternal", 1)],
	witch: [E("rare", 1), E("eternal", 1)],
	vampire: [E("eternal", 1), E("eternal", 1)],
	minotaur: [
		E("must", 0, 2),
		E("must", 1),
		E("move", 2)
	],
	medusa: [
		E("must", 0, 2),
		E("must", 1),
		E("rare", 1)
	],
	pegasus: [E("must"), E("rare")],
	barong: [E("eternal"), E("exchange")],
	yeti: [
		E("rare", 1),
		E("discard"),
		E("discard")
	],
	cyclops: [
		E("discard"),
		E("must", 1),
		E("eternal", 1)
	],
	king: [E("must", 1), E("move", 2)],
	mermaid: [E("must", 1), E("move", 2)],
	ghost: [E("retrieve", 2), E("retrieve", 2)],
	kraken: [E("retrieve", 2), E("tens")],
	skeleton: [E("prepared", 1), E("eternal", 1)],
	mummy: [E("prepared", 1), E("eternal", 1)],
	kyubi: [E("rare", 1), E("eternal", 1)],
	djinn: [E("eternal", 1), E("eternal", 1)],
	kappa: [
		E("discard"),
		E("must", 1),
		E("drain", 2)
	],
	golem: [E("must", 1), E("eternal", 1)]
}, ne = [
	"phoenix",
	"skeleton",
	"barong",
	"mummy",
	"kyubi",
	"minotaur",
	"ghost",
	"dragon"
], re = [
	"kraken",
	"cyclops",
	"djinn",
	"pegasus"
], ie = [
	...re,
	"mermaid",
	"fairy",
	"witch",
	"medusa",
	"vampire"
], O = [
	"fairy",
	"mermaid",
	"vampire",
	"ghost",
	"discard",
	"dragon",
	"kraken",
	"hard"
], k = [
	"must",
	"must",
	"cyclops",
	"mummy"
], A = {
	id: "eternalsevens",
	tier: "alpha",
	nameKey: "games.eternalsevens.name",
	descKey: "games.eternalsevens.desc",
	rulesKey: "games.eternalsevens.rules",
	icon: "♾️",
	iconImg: "games/eternalsevens.webp",
	rulesUrl: { en: "https://drive.google.com/file/d/1q4aHNsUtuKU0IQV5CjJ8W-5fno6iYWM0/view" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [4],
	accent: "#8053bd",
	releasedAt: "2026-11-04T16:00:00+08:00",
	search: {
		py: "yong heng qi",
		init: "yhq"
	},
	hotseat: "cover",
	mechanics: ["hand-management", "race"],
	interactionTags: []
}, j = t.object({
	level: t.enum([
		"beginner",
		"standard",
		"expert",
		"pro"
	]).default("beginner"),
	expanded: t.boolean().default(!1),
	dragon: t.boolean().default(!0),
	rolePool: t.enum(["intro", "all"]).default("intro")
}).default({
	level: "beginner",
	expanded: !1,
	dragon: !0,
	rolePool: "intro"
}), M = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		card: t.int().min(0).max(51),
		row: t.int().min(0).max(3),
		col: t.int().min(0).max(11)
	}),
	t.object({
		type: t.literal("pass"),
		slot: t.int().min(0).max(7)
	}),
	t.object({
		type: t.literal("choose"),
		value: t.int().min(0).max(200)
	}),
	t.object({
		type: t.literal("acquire"),
		index: t.int().min(0).max(1)
	}),
	t.object({ type: t.literal("end") }),
	t.object({ type: t.literal("hard") }),
	t.object({ type: t.literal("eliminate") }),
	t.object({ type: t.literal("next") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), N = t.enum([
	...C,
	"red",
	"blue",
	"green",
	"yellow"
]), ae = t.object({
	value: t.int(),
	kind: t.enum([
		"card",
		"player",
		"color",
		"position",
		"row",
		"role",
		"dragon"
	]),
	detail: t.string().optional()
}), P = t.object({
	config: j,
	round: t.int(),
	phase: t.enum([
		"play",
		"resolve",
		"roundOver",
		"done"
	]),
	turn: t.string(),
	field: t.array(t.array(t.int().nullable())),
	blocks: t.array(t.int()),
	must: t.array(t.int()),
	players: t.array(t.object({
		rid: t.string(),
		color: t.int(),
		role: N,
		handCount: t.int(),
		rareCount: t.int(),
		passes: t.array(t.int()),
		extra: t.int(),
		hearts: t.int(),
		stars: t.int(),
		status: t.enum([
			"active",
			"out",
			"hard",
			"eliminated"
		]),
		remaining: t.int().nullable(),
		ready: t.boolean(),
		revealed: t.array(t.int()).nullable()
	})),
	continuous: t.enum(S).nullable(),
	instant: t.enum(S).nullable(),
	rareSupply: t.int(),
	drawCount: t.int(),
	market: t.array(t.int()),
	discarded: t.array(t.int().nullable()),
	dragon: t.object({
		forbidden: t.int(),
		playable: t.int(),
		side: t.int(),
		cubes: t.array(t.int())
	}),
	prompt: t.object({
		kind: t.string(),
		by: t.string()
	}).nullable(),
	log: t.array(t.object({
		kind: t.string(),
		by: t.string(),
		n: t.int().optional(),
		detail: t.string().optional()
	})),
	history: t.array(t.object({
		round: t.int(),
		players: t.array(t.object({
			rid: t.string(),
			role: N,
			hearts: t.int(),
			stars: t.int(),
			status: t.string()
		}))
	})),
	ranking: t.array(t.string()),
	played: t.int()
}), oe = t.object({
	hand: t.array(t.int()),
	moves: t.array(M),
	choices: t.array(ae),
	discards: t.array(t.int().nullable()),
	roleChoices: t.array(N)
}), F = {
	play: 480,
	event: 780,
	award: 950
}, I = (e) => e.config.level === "expert" || e.config.level === "pro", L = (e, t) => e.players.find((e) => e.rid === t), R = (e) => e.players.filter((e) => e.status === "active"), z = (e, t) => {
	let n = e.players.findIndex((e) => e.rid === t);
	return [...e.players.slice(n), ...e.players.slice(0, n)];
};
function B(t, n) {
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function V(e, t, n, r, i) {
	e.log.push({
		kind: t,
		by: n,
		...r === void 0 ? {} : { n: r },
		...i === void 0 ? {} : { detail: i }
	});
}
function H(e, ...t) {
	e.queue.unshift(...t), e.phase = "resolve";
}
function U(e, t) {
	e.pending = t, e.phase = "resolve";
}
var W = (e) => ({
	kind: "task",
	by: e.by,
	task: e
});
function G(e, t, n) {
	e.config.level !== "beginner" && t.role !== "pegasus" && t.role !== "barong" && (t.extra = Math.min(t.role === "kyubi" ? 3 : 2, t.extra + n));
}
function K(e, t, n) {
	if (!n) return;
	let r = Math.min(e.players.length === 4 ? 20 : 21, t.hearts + n);
	r !== t.hearts && (t.hearts = r, t.stamp = ++e.clock);
}
function q(e, t, n) {
	t.stars = Math.min(I(e) ? e.players.length === 4 ? 4 : 5 : 4, t.stars + n);
}
function J(e) {
	return I(e) ? O[e.dragon.forbidden] ?? null : e.continuous;
}
function se(e) {
	return [
		"witch",
		"vampire",
		"barong",
		"mummy",
		"kyubi"
	].includes(e.role);
}
function ce(e, t) {
	let n = J(e);
	return n === "fairy" && (t === 3 || t === 8) || n === "mermaid" && (t === 1 || t === 10) || n === "vampire" && (t === 0 || t === 11);
}
function le(e, t) {
	let n = e.field[t];
	return n.every((e) => e === null) ? [
		4,
		5,
		6,
		7
	] : n.flatMap((e, t) => e === null && (n[t - 1] != null || n[t + 1] != null || t === 0 && n[11] !== null || t === 11 && n[0] !== null) ? [t] : []);
}
function ue(e, t) {
	let n = [];
	for (let r of t.hand) {
		let i = w(r);
		for (let a = 0; a < 4; a++) {
			if (r < 40 && Math.floor(r / 10) !== a) continue;
			let o = e.field[a].filter((e) => e === null).length, s = le(e, a);
			for (let c = 0; c < 12; c++) {
				if (r < 40 && c !== T(r) || i === "purple" && c !== 0 && c !== 11) continue;
				let l = e.field[a][c];
				(l === null || l >= 48 && r < 48) && (l !== null || s.includes(c) && (e.blocks[a] !== c || o === 1)) && ((r >= 48 ? !I(e) && e.continuous === "witch" : ce(e, c) && !se(t)) || n.push({
					type: "play",
					card: r,
					row: a,
					col: c
				}));
			}
		}
	}
	let r = n.filter((t) => t.card < 48 && e.must.includes(t.row * 12 + t.col)), i = (I(e) ? e.dragon.playable >= 0 && e.dragon.playable % 4 == 2 : e.continuous === "cyclops") ? n.filter((e) => e.card >= 48) : [];
	return r.length || i.length ? [...r, ...i] : n;
}
function de(e, t) {
	return e.played === 0 || e.players.length === 2 && I(e) && t.remaining !== null || e.played === 1 && (t.role === "pegasus" || !I(e) && e.continuous === "pegasus") || e.played === 1 && t.role === "barong" ? !0 : t.extra > 0 && t.role !== "pegasus" && t.role !== "barong" && J(e) !== "dragon" && !(e.continuous === "pegasus" && !I(e));
}
function fe(e, t) {
	if (e.ending || !de(e, t)) return [];
	let n = ue(e, t);
	return e.played === 1 && t.role === "barong" ? n.filter((t) => w(t.card) === e.lastColor) : n;
}
function pe(e, t) {
	let n = t.role === "djinn" ? 3 : t.role === "pegasus" || t.role === "cyclops" ? 1 : 2;
	return I(e) && J(e) !== "hard" && t.hand.length > 0 && t.hand.length <= n;
}
function me(e, t) {
	return e.config.level === "beginner" ? D : [...D, ...te[t.role]];
}
function he(e, t) {
	let n = e.config.level === "beginner" ? 3 : 4;
	if (t.passes.length >= n) return [];
	let r = me(e, t).flatMap((n, r) => t.passes.includes(r) || n.kind === "prepared" || n.kind === "move" && !e.blocks.some((e) => e >= 0) || n.kind === "retrieve" && !e.discards.length ? [] : [{
		type: "pass",
		slot: r
	}]);
	if (e.players.length === 2) for (let t = 6; t < 8; t++) e.players.some((e) => e.passes.includes(t)) || r.push({
		type: "pass",
		slot: t
	});
	return r;
}
function ge(e, t) {
	let n = e.players.find((e) => e.rid === t);
	if (!n) return [];
	if (e.pending) return e.pending.by === t ? _e(e).map((e) => ({
		type: "choose",
		value: e.value
	})) : [];
	if (e.phase === "roundOver") return n.ready ? [] : [{ type: "next" }];
	if (e.phase !== "play" || e.turn !== t || n.status !== "active") return [];
	if (e.ending) return [{ type: "end" }, ...pe(e, n) ? [{ type: "hard" }] : []];
	let r = fe(e, n);
	return pe(e, n) && r.push({ type: "hard" }), e.played > 0 ? (r.push({ type: "end" }), r) : (r.push(...he(e, n)), e.market.length === 2 && r.push({
		type: "acquire",
		index: 0
	}, {
		type: "acquire",
		index: 1
	}), r.length || r.push({ type: "eliminate" }), r);
}
function _e(e) {
	let t = e.pending;
	if (!t) return [];
	let n = L(e, t.by), r = (e) => e.map((e) => ({
		value: e,
		kind: "card"
	}));
	switch (t.kind) {
		case "role": return e.pool.map((e) => ({
			kind: "role",
			value: C.indexOf(e),
			detail: e
		}));
		case "color": return [
			0,
			1,
			2,
			3,
			4
		].map((e) => ({
			value: e,
			kind: "color"
		}));
		case "target": return R(e).filter((e) => e.rid !== n.rid).map((t) => ({
			kind: "player",
			value: e.players.indexOf(t),
			detail: t.rid
		}));
		case "must": return e.must.length >= 7 ? [] : e.field.flatMap((t, n) => t.flatMap((t, r) => t === null && !e.must.includes(n * 12 + r) ? [{
			kind: "position",
			value: n * 12 + r
		}] : []));
		case "move": return e.blocks.flatMap((e, t) => e >= 0 ? [{
			kind: "row",
			value: t
		}] : []);
		case "retrieve": return r(e.discards.map((e) => e.card));
		case "collect": return r(n.hand.filter((e) => t.special === "tens" ? T(e) === 10 : w(e) === [
			"red",
			"blue",
			"green",
			"yellow",
			"purple"
		][t.color]));
		case "dragon": {
			let t = [];
			if (e.dragon.forbidden < 7 && t.push({
				kind: "dragon",
				value: 0,
				detail: O[e.dragon.forbidden + 1]
			}), e.dragon.playable < 7 && t.push({
				kind: "dragon",
				value: 1,
				detail: k[(e.dragon.playable + 1) % 4]
			}), e.dragon.cubes.forEach((n, r) => {
				if (n < 0) for (let n = 0; n < 4; n++) (e.dragon.side !== 0 || n !== 2 || e.blocks.some((e) => e >= 0)) && t.push({
					kind: "dragon",
					value: 10 + r * 4 + n,
					detail: (e.dragon.side === 0 ? [
						"extra",
						"heart",
						"moveAll",
						"mummy"
					] : [
						"extra",
						"heart",
						"hardBonus",
						"outBonus"
					])[n]
				});
			}), n.role === "witch" || n.role === "vampire") for (let n of e.dragon.forbidden < 4 ? [
				0,
				1,
				2
			] : [
				5,
				6,
				7
			]) e.dragon.forbidden >= 0 && n !== e.dragon.forbidden && t.push({
				kind: "dragon",
				value: 100 + n,
				detail: O[n]
			});
			return t;
		}
		default: return r(n.hand);
	}
}
function ve(t) {
	t.field = Array.from({ length: 4 }, () => Array(12).fill(null)), t.under = {}, t.blocks = [
		-1,
		-1,
		-1,
		-1
	], t.must = [], t.rare = [
		48,
		49,
		50,
		51
	], t.discards = [], t.draw = [], t.market = [], t.pending = null, t.queue = [], t.transfers = [], t.dragon = {
		forbidden: -1,
		playable: -1,
		side: 0,
		cubes: [
			-1,
			-1,
			-1,
			-1
		]
	}, t.played = 0, t.ending = !1, t.lastColor = null, t.again = !1, t.skip = 0, t.first = !1, t.instant = null, t.continuous = null;
	let n = B(t, Array.from({ length: 48 }, (e, t) => t)), r = t.players.length === 4 ? 12 : 16;
	t.players.forEach((e, t) => {
		e.hand = n.slice(t * r, (t + 1) * r), e.extra = 0, e.passes = [], e.status = "active", e.remaining = null, e.ready = !1, e.revealed = null;
	}), t.players.length === 2 && (t.draw = n.slice(32), t.discards = t.draw.splice(0, 2).map((e) => ({
		card: e,
		open: !1
	})), t.market = t.draw.splice(0, 2));
	let i = t.config.expanded && t.config.level !== "beginner" ? [
		...ne,
		"king",
		"kappa",
		"yeti"
	] : [...ne];
	t.players.length === 2 && (i = i.map((e) => e === "ghost" ? "king" : e)), t.config.dragon || (i = i.map((e) => e === "dragon" ? i.includes("king") ? "yeti" : "king" : e)), t.instantDeck = B(t, [...new Set(i)]), t.continuousDeck = B(t, t.config.level === "beginner" ? [...re] : t.config.expanded ? [
		...ie,
		"golem",
		"dragon"
	] : [...ie]), t.turn = t.start, t.phase = "play", t.config.level === "pro" ? (t.round === 1 ? (t.pairPool = t.config.rolePool === "intro" ? [
		0,
		1,
		2,
		3,
		4
	] : B(t, Array.from({ length: 10 }, (e, t) => t)).slice(0, t.players.length + 1).map((n) => n * 2 + e(t.seed, t.cursor++, 2)), t.config.rolePool === "intro" && (t.pairPool = [
		0,
		2,
		4,
		6,
		8
	]), t.draftOrder = z(t, t.start).map((e) => e.rid).reverse()) : t.draftOrder = [...t.players].sort((e, t) => e.hearts - t.hearts || t.stamp - e.stamp).map((e) => e.rid), t.pool = t.pairPool.map((e) => C[t.round === 1 ? e : e ^ 1]), U(t, {
		kind: "role",
		by: t.draftOrder.shift()
	})) : ye(t);
}
function ye(e) {
	let t = [];
	for (let n of z(e, e.start)) {
		(n.role === "witch" || n.role === "vampire") && (e.dragon.forbidden = 0), (n.role === "minotaur" || n.role === "medusa") && G(e, n, 1), n.role === "king" && xe(e, n), (n.role === "skeleton" || n.role === "mummy") && (n.passes = [3], G(e, n, 1));
		let r = n.role === "ghost" ? 2 : +(n.role === "kraken");
		r && t.push(W({
			kind: "discard",
			by: n.rid,
			n: r,
			special: "prepare"
		}));
	}
	t.length ? H(e, ...t, {
		kind: "begin",
		by: e.start
	}) : (e.phase = "play", e.turn = e.start);
}
function be(t, n, r) {
	let i = j.parse(t ?? {}), a = {
		config: i,
		seed: r,
		cursor: 0,
		players: n.map((e, t) => ({
			rid: e,
			color: t,
			role: [
				"red",
				"blue",
				"green",
				"yellow"
			][t],
			hand: [],
			passes: [],
			extra: 0,
			hearts: (i.level === "expert" || i.level === "pro") && n.length === 4 ? 3 : 0,
			stars: 0,
			status: "active",
			remaining: null,
			ready: !1,
			revealed: null,
			stamp: t
		})),
		round: 1,
		start: "",
		turn: "",
		phase: "play",
		field: [],
		under: {},
		blocks: [],
		must: [],
		rare: [],
		draw: [],
		market: [],
		discards: [],
		instantDeck: [],
		continuousDeck: [],
		instant: null,
		continuous: null,
		dragon: {
			forbidden: -1,
			playable: -1,
			side: 0,
			cubes: []
		},
		pool: [],
		pairPool: [],
		draftOrder: [],
		pending: null,
		queue: [],
		transfers: [],
		played: 0,
		ending: !1,
		lastColor: null,
		again: !1,
		skip: 0,
		first: !1,
		beat: F.event,
		clock: n.length,
		finishers: [],
		eliminated: [],
		ranking: [],
		log: [],
		history: []
	};
	return a.start = n[e(r, a.cursor++, n.length)], z(a, a.start).forEach((e, t) => {
		e.stamp = t;
	}), ve(a), {
		state: a,
		fx: []
	};
}
function xe(e, t) {
	let n = e.rare.shift();
	n === void 0 ? G(e, t, 1) : t.hand.push(n);
}
function Se(e, t) {
	if (e.blocks[t] < 0) return;
	let n = le(e, t).filter((n) => n !== e.blocks[t]);
	n.length && (e.blocks[t] = n[0]);
}
function Ce(e, t, n, r = !1) {
	let i = L(e, n);
	if (V(e, r ? "continuous" : "instant", n, void 0, t), r) {
		e.continuous = t, t === "medusa" && U(e, {
			kind: "must",
			by: n,
			n: 1
		}), t === "golem" && e.instant && H(e, {
			kind: "effect",
			by: n,
			effect: e.instant
		});
		return;
	}
	switch (t) {
		case "phoenix":
			e.again = !0;
			break;
		case "skeleton":
			U(e, {
				kind: "target",
				by: n,
				special: "gift"
			});
			break;
		case "barong":
			U(e, {
				kind: "color",
				by: n
			});
			break;
		case "mummy":
			we(e, n);
			break;
		case "kyubi":
			e.skip++;
			break;
		case "minotaur":
			e.blocks.forEach((t, n) => Se(e, n));
			break;
		case "ghost":
			e.discards.forEach((e) => {
				e.open = !0;
			});
			break;
		case "dragon":
			U(e, {
				kind: "target",
				by: n,
				special: "swap"
			});
			break;
		case "king":
			xe(e, i);
			break;
		case "kappa":
			R(e).forEach((t) => G(e, t, 1));
			break;
		case "yeti": J(e) !== "kraken" && H(e, ...z(e, n).filter((e) => e.status === "active").map((e) => W({
			kind: "discard",
			by: e.rid,
			n: 1
		})));
	}
}
function we(e, t) {
	let n = z(e, t).filter((e) => e.status === "active" && e.hand.length);
	n.length < 2 || (e.transfers = [], H(e, ...n.map((e, t) => W({
		kind: "transfer",
		by: e.rid,
		to: n[(t + 1) % n.length].rid,
		n: 1
	})), {
		kind: "commit",
		by: t
	}));
}
function Te(e, t, n) {
	let r = (e.config.level === "beginner" ? 3 : 4) - t.passes.length, i = (e) => t.hand.filter((t) => w(t) === e).length, a = 0, o = 0;
	switch (t.role) {
		case "red":
			a = n ? 3 + i("red") : 2 * r, o = n ? 0 : 2;
			break;
		case "blue":
			a = n ? 2 * i("blue") : 5, o = n ? 0 : Math.floor(r / 2);
			break;
		case "green":
			a = n ? i("green") : 3, o = n ? 0 : 1 + Math.floor(r / 2);
			break;
		case "yellow":
			a = n ? (r === 0 ? 4 : 0) + i("yellow") : 4, o = n ? 0 : 1 + Number(r === 0);
			break;
		case "phoenix":
			a = n ? 3 + i("red") : 2 * t.extra, o = n ? 0 : 2;
			break;
		case "fairy":
			a = n ? i("green") : 4, o = +!n + Math.floor(r / 2);
			break;
		case "witch":
		case "vampire":
			a = n ? 0 : 3, o = n ? Number(t.role === "witch" ? i("purple") === 1 && i("rare") === 1 : i("purple") === 2) : 1;
			break;
		case "minotaur":
		case "medusa":
			a = n ? 3 : 4, o = +!n;
			break;
		case "pegasus":
			a = n ? 3 : 6 + r;
			break;
		case "barong":
			a = n ? (r === 0 ? 3 : 0) + i("purple") : 6, o = n ? 0 : Number(r === 0);
			break;
		case "yeti":
			a = n ? 2 + 2 * i("rare") : 4 + (r === 0 ? 2 : 0), o = n ? Number(r === 0) : 1;
			break;
		case "cyclops":
			a = 4 + (r === 0 ? 2 : 0), o = 1 + Number(r === 0);
			break;
		case "king":
			a = n ? 2 * i("yellow") : r, o = n ? 0 : 2;
			break;
		case "mermaid":
			a = n ? r + i("blue") : 4, o = n ? 0 : Number(t.extra >= 2);
			break;
		case "ghost":
			a = n ? 2 + i("purple") : 3, o = +!n;
			break;
		case "kraken":
			a = r, o = n ? Number(t.hand.filter((e) => T(e) === 10).length === 2) : 1;
			break;
		case "skeleton":
			a = n ? 3 : 4, o = n ? Number(r === 0) : 1 + Number(r === 0);
			break;
		case "mummy":
			a = 2, o = n ? Number(r === 0) : 1;
			break;
		case "kyubi":
			a = n ? 2 * i("rare") + t.extra : 6, o = n ? 0 : Number(t.extra >= 2);
			break;
		case "djinn":
			a = n ? 2 * i("rare") + i("purple") : 4, o = n ? Number(i("rare") === 2) : 1;
			break;
		case "kappa":
			a = n ? 2 * i("rare") : 2 + t.extra, o = n ? Number(r === 0) : 1;
			break;
		case "golem": a = n ? 3 : 2 + t.extra + r, o = +!n;
	}
	e.dragon.side === 1 && e.dragon.cubes[t.color] >= 0 && e.dragon.cubes.includes(n ? 2 : 3) && (a += r), K(e, t, a), q(e, t, o);
}
function Y(e, t, n, r = !1) {
	if (t.status === "active") {
		if (!I(e)) {
			if (t.status = n, n === "eliminated" ? e.eliminated.push(t.rid) : e.finishers.push(t.rid), n !== "eliminated") {
				let n = t.hand.filter((e) => e >= 48);
				e.rare.push(...n), t.hand = t.hand.filter((e) => e < 48);
			}
			Ee(e, t), V(e, n, t.rid);
			return;
		}
		if (n === "eliminated") t.status = n, t.hearts = 0, t.stamp = ++e.clock, e.round === 1 && q(e, t, 1), r ? (e.discards.push(...t.hand.map((e) => ({
			card: e,
			open: !0
		}))), t.hand = []) : Ee(e, t);
		else {
			e.first || (e.first = !0, K(e, t, 1), e.round === 2 && q(e, t, 1), V(e, "first", t.rid, e.round)), Te(e, t, n === "hard"), t.status = n, n === "hard" && (t.revealed = [...t.hand], e.discards.push(...t.hand.map((e) => ({
				card: e,
				open: !0
			}))), t.hand = [], e.players.filter((e) => e.role === "witch" || e.role === "vampire").forEach((t) => K(e, t, 2)));
			let r = n === "out" ? 1 : 2;
			R(e).forEach((e) => {
				e.remaining = Math.min(e.remaining ?? r, r);
			});
		}
		V(e, n, t.rid);
	}
}
function Ee(e, t) {
	let n = R(e), r = B(e, t.hand);
	if (t.hand = [], !n.length) {
		e.discards.push(...r.map((e) => ({
			card: e,
			open: !0
		})));
		return;
	}
	let i = Math.floor(r.length / n.length);
	n.forEach((e, t) => e.hand.push(...r.slice(t * i, (t + 1) * i))), e.discards.push(...r.slice(i * n.length).map((e) => ({
		card: e,
		open: !0
	})));
}
function De(e) {
	for (let t of z(e, e.turn)) t.status === "active" && (t.hand.length === 0 || !I(e) && t.stars >= 2) && Y(e, t, "out");
	let t = R(e);
	!I(e) && t.length <= 1 ? (e.ranking = [
		...e.finishers,
		...t.map((e) => e.rid),
		...[...e.eliminated].reverse()
	], t.forEach((e) => {
		e.revealed = [...e.hand];
	}), e.phase = "done", e.queue = [], e.pending = null) : I(e) && t.length === 1 && !e.first && Y(e, t[0], "out"), I(e) && R(e).length === 0 && Ae(e);
}
var Oe = (e) => e.phase === "done" || e.phase === "roundOver";
function ke(e) {
	let t = e.players.length === 4 ? 20 : 21, n = e.players.length === 4 ? 4 : 5, r = (e) => e.status === "eliminated" ? 0 : e.hearts >= t ? 3 : e.stars >= n && e.hearts > 4 ? 2 : 1;
	return [...e.players].sort((e, t) => r(t) - r(e) || (r(e) === 3 ? t.stars - e.stars || e.stamp - t.stamp : t.hearts - e.hearts || t.stars - e.stars || e.stamp - t.stamp)).map((e) => e.rid);
}
function Ae(e) {
	e.history.push({
		round: e.round,
		players: e.players.map((e) => ({
			rid: e.rid,
			role: e.role,
			hearts: e.hearts,
			stars: e.stars,
			status: e.status
		}))
	}), e.queue = [], e.pending = null, e.round === 2 ? (e.ranking = ke(e), e.phase = "done") : (e.phase = "roundOver", e.players.forEach((e) => {
		e.ready = !1;
	}));
}
function je(e) {
	if (De(e), Oe(e)) return;
	let t = L(e, e.turn);
	if (t.status === "active" && t.remaining !== null && (t.remaining--, t.remaining <= 0 && Y(e, t, "eliminated", !0)), De(e), Oe(e)) return;
	let n = z(e, e.turn).slice(1).concat([t]).filter((e) => e.status === "active");
	for (e.turn = e.again && t.status === "active" ? t.rid : n[0].rid, e.again = !1, e.played = 0, e.ending = !1, e.lastColor = null, e.phase = "play"; e.skip > 0;) e.skip--, e.turn = z(e, e.turn).slice(1).find((e) => e.status === "active")?.rid ?? e.turn;
}
function Me(e, t, n) {
	let r = L(e, t);
	if (n === 0 || n >= 100) {
		e.dragon.forbidden = n === 0 ? e.dragon.forbidden + 1 : n - 100;
		let i = O[e.dragon.forbidden];
		i === "ghost" && e.discards.forEach((e) => {
			e.open = !0;
		}), i === "discard" && r.hand.length && U(e, {
			kind: "discard",
			by: t,
			n: 1
		}), V(e, "dragon", t, void 0, i);
	} else if (n === 1) {
		e.dragon.playable++;
		let n = k[e.dragon.playable % 4];
		n === "must" && U(e, {
			kind: "must",
			by: t,
			n: 1
		}), n === "mummy" && we(e, t), V(e, "dragon", t, void 0, n);
	} else {
		let i = Math.floor((n - 10) / 4), a = (n - 10) % 4;
		e.dragon.cubes[i] = a, a === 0 && G(e, r, 1), a === 1 && K(e, r, 1), e.dragon.side === 0 && a === 2 && e.blocks.forEach((t, n) => Se(e, n)), e.dragon.side === 0 && a === 3 && we(e, t), V(e, "dragon", t, void 0, (e.dragon.side === 0 ? [
			"extra",
			"heart",
			"moveAll",
			"mummy"
		] : [
			"extra",
			"heart",
			"hardBonus",
			"outBonus"
		])[a]), e.dragon.side === 0 && e.dragon.cubes.every((e) => e >= 0) && (e.dragon.side = 1, e.dragon.cubes.fill(-1));
	}
}
function Ne(e, t) {
	let n = e.pending, r = L(e, n.by);
	switch (e.pending = null, n.kind) {
		case "role":
			r.role = C[t], e.pool = e.pool.filter((e) => e !== r.role), e.draftOrder.length ? U(e, {
				kind: "role",
				by: e.draftOrder.shift()
			}) : ye(e);
			break;
		case "dragon":
			Me(e, n.by, t);
			break;
		case "must":
			e.must.push(t), (n.n ?? 1) > 1 && H(e, W({
				...n,
				n: n.n - 1
			}));
			break;
		case "move":
			Se(e, t);
			break;
		case "retrieve": {
			let n = e.discards.findIndex((e) => e.card === t);
			e.discards.splice(n, 1), r.hand.push(t);
			break;
		}
		case "discard":
			r.hand.splice(r.hand.indexOf(t), 1), e.discards.push({
				card: t,
				open: !1
			}), (n.n ?? 1) > 1 && H(e, W({
				...n,
				n: n.n - 1
			}));
			break;
		case "target": {
			let i = e.players[t];
			if (n.special === "gift") U(e, {
				kind: "gift",
				by: r.rid,
				to: i.rid
			});
			else if (e.players.length === 4) {
				let e = r.hand;
				r.hand = i.hand, i.hand = e;
			} else e.transfers = [], H(e, W({
				kind: "transfer",
				by: r.rid,
				to: i.rid,
				n: Math.min(3, r.hand.length)
			}), W({
				kind: "transfer",
				by: i.rid,
				to: r.rid,
				n: Math.min(3, i.hand.length)
			}), {
				kind: "commit",
				by: r.rid
			});
			break;
		}
		case "gift":
		case "return":
			r.hand.splice(r.hand.indexOf(t), 1), L(e, n.to).hand.push(t), (n.n ?? 1) > 1 && H(e, W({
				...n,
				n: n.n - 1
			}));
			break;
		case "transfer":
		case "collect":
			r.hand.splice(r.hand.indexOf(t), 1), e.transfers.push({
				from: r.rid,
				to: n.to,
				card: t
			}), (n.n ?? 1) > 1 && H(e, W({
				...n,
				n: n.n - 1
			}));
			break;
		case "color": Pe(e, r.rid, t);
	}
	V(e, "choice", n.by, void 0, n.kind);
}
function Pe(e, t, n, r) {
	e.transfers = [];
	let i = [], a = [];
	for (let o of R(e).filter((e) => e.rid !== t)) {
		let s = o.hand.filter((e) => r === "tens" ? T(e) === 10 : w(e) === [
			"red",
			"blue",
			"green",
			"yellow",
			"purple"
		][n]).length, c = r === "tens" ? s : Math.min(s, e.players.length === 2 ? 2 : 1);
		c && (i.push(W({
			kind: "collect",
			by: o.rid,
			to: t,
			color: n,
			special: r,
			n: c
		})), a.push(W({
			kind: "return",
			by: t,
			to: o.rid,
			n: c
		})));
	}
	H(e, ...i, {
		kind: "commit",
		by: t
	}, ...a);
}
function Fe(e, t, n) {
	t.passes.push(n);
	let r = n >= 6 ? {
		kind: "eternal",
		bonus: 0,
		count: 1
	} : me(e, t)[n];
	G(e, t, r.bonus), V(e, "pass", t.rid, n), e.queue = [{
		kind: "sweep",
		by: t.rid
	}, {
		kind: "endChoice",
		by: t.rid
	}], e.phase = "resolve", r.kind === "rare" && xe(e, t), r.kind === "discard" && J(e) !== "kraken" && U(e, {
		kind: "discard",
		by: t.rid,
		n: 1
	}), r.kind === "eternal" && H(e, {
		kind: "eternal",
		by: t.rid,
		n: 0
	}), r.kind === "must" && U(e, {
		kind: "must",
		by: t.rid,
		n: r.count
	}), r.kind === "move" && U(e, {
		kind: "move",
		by: t.rid
	}), r.kind === "retrieve" && U(e, {
		kind: "retrieve",
		by: t.rid
	}), r.kind === "exchange" && U(e, {
		kind: "color",
		by: t.rid
	}), r.kind === "tens" && Pe(e, t.rid, 0, "tens"), r.kind === "drain" && R(e).forEach((e) => {
		e.extra = Math.max(0, e.extra - 2);
	});
}
function Ie(e, t, n) {
	let r = e.field[n.row][n.col];
	if (e.played === 0 || e.players.length === 2 && I(e) && t.remaining !== null || e.played === 1 && (t.role === "pegasus" || t.role === "barong" || !I(e) && e.continuous === "pegasus") || t.extra--, t.hand.splice(t.hand.indexOf(n.card), 1), e.played++, e.lastColor = w(n.card), r !== null) {
		let i = e.players.find((e) => e.role === "djinn");
		I(e) && i ? i.hand.push(r) : !I(e) && e.continuous === "djinn" ? t.hand.push(r) : e.under[n.row * 12 + n.col] = r;
	}
	if (e.field[n.row][n.col] = n.card, e.must = e.must.filter((e) => e !== n.row * 12 + n.col), r === null && (n.col === 0 || n.col === 11) && e.blocks[n.row] === -1) {
		let t = le(e, n.row).filter((e) => e !== (n.col === 0 ? 11 : 0));
		e.blocks[n.row] = t[0] ?? (n.col === 0 ? 11 : 0);
	}
	return e.queue = [{
		kind: "played",
		by: t.rid,
		row: n.row,
		col: n.col,
		card: n.card,
		n: +(r === null)
	}], e.phase = "resolve", e.beat = F.play, V(e, "play", t.rid, n.card, `${n.row}:${n.col}`), {
		kind: "play",
		rid: t.rid,
		data: {
			card: n.card,
			row: n.row,
			col: n.col
		}
	};
}
function Le(e) {
	for (let t = 0; t < 100 && e.queue.length && !e.pending; t++) {
		let t = e.queue.shift(), n = L(e, t.by);
		switch (t.kind) {
			case "begin": return e.turn = e.start, e.played = 0, e.phase = "play", [];
			case "task":
				if (t.task.kind === "must" && e.must.length >= 7) break;
				e.pending = t.task, _e(e).length || (e.pending = null);
				break;
			case "commit":
				e.transfers.forEach((t) => L(e, t.to).hand.push(t.card)), e.transfers = [];
				break;
			case "sweep":
				De(e);
				break;
			case "endChoice": return n.status === "active" && pe(e, n) ? (e.ending = !0, e.phase = "play", []) : (je(e), []);
			case "finish": return je(e), [];
			case "effect": return Ce(e, t.effect, t.by), e.beat = F.event, [{
				kind: "eternal",
				rid: t.by,
				data: { eternal: t.effect }
			}];
			case "eternal":
				if (n.status !== "active") break;
				if (I(e)) n.role === "golem" ? H(e, W({
					kind: "dragon",
					by: n.rid
				}), W({
					kind: "dragon",
					by: n.rid
				})) : U(e, {
					kind: "dragon",
					by: n.rid
				});
				else {
					let r = t.n === 1 ? e.instantDeck : e.continuousDeck;
					if (!r.length) break;
					let i = r.shift();
					return t.n === 1 && (e.instant = i), Ce(e, i, t.by, t.n !== 1), e.beat = F.event, [{
						kind: "eternal",
						rid: n.rid,
						data: {
							eternal: i,
							continuous: t.n !== 1
						}
					}];
				}
				break;
			case "played": {
				let r = t.card, i = t.col, a = r < 40 && (T(r) === 2 || T(r) === 9), o = [{
					kind: "sweep",
					by: n.rid
				}];
				if (n.role === "skeleton" && w(r) === "purple" && n.hand.length && o.unshift(W({
					kind: "target",
					by: n.rid,
					special: "gift"
				})), a ? o.push({
					kind: "eternal",
					by: n.rid,
					n: 1
				}, {
					kind: "sweep",
					by: n.rid
				}, {
					kind: "endChoice",
					by: n.rid
				}) : o.push({
					kind: "continue",
					by: n.rid
				}), H(e, ...o), n.role === "phoenix" && (T(r) === 6 || T(r) === 8) && G(e, n, 1), n.role === "fairy" && (T(r) === 1 || T(r) === 4) && G(e, n, 1), n.role === "mermaid" && (T(r) === 5 || T(r) === 7) && G(e, n, 1), n.role === "king" && r >= 48 && G(e, n, 1), n.role === "kraken" && T(r) === 10 && K(e, n, 1), n.role === "mummy" && ce(e, i) && K(e, n, 1), t.n === 1 && (n.role === "kyubi" || n.role === "djinn") && e.field.every((e) => e[i] !== null) && G(e, n, 1), t.n === 1 && e.field[t.row].every((e) => e !== null)) return e.blocks[t.row] = -2, q(e, n, 1), ["blue", "mermaid"].includes(n.role) && q(e, n, 1), [
					"green",
					"yellow",
					"cyclops"
				].includes(n.role) && K(e, n, 4), [
					"minotaur",
					"medusa",
					"king",
					"ghost",
					"kraken",
					"mummy",
					"kappa"
				].includes(n.role) && K(e, n, 2), V(e, "star", n.rid, t.row), e.beat = F.award, [{
					kind: "star",
					rid: n.rid,
					data: {
						row: t.row,
						col: i
					}
				}];
				break;
			}
			case "continue": return De(e), e.phase === "done" || e.phase === "roundOver" ? [] : n.status === "active" && fe(e, n).length || n.status === "active" && pe(e, n) ? (e.phase = "play", []) : (je(e), []);
		}
		if (e.phase === "done" || e.phase === "roundOver") return [];
	}
	return !e.pending && !e.queue.length && e.phase === "resolve" && (e.phase = "play"), [];
}
function Re(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "resolve" || e.pending) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		return {
			state: t,
			fx: Le(t)
		};
	}
	if (!ge(e, n.by).some((e) => JSON.stringify(e) === JSON.stringify(t))) return { code: "games.eternalsevens.errAction" };
	let r = structuredClone(e), i = L(r, n.by), a = [];
	switch (t.type) {
		case "play":
			a = [Ie(r, i, t)];
			break;
		case "pass":
			Fe(r, i, t.slot), r.beat = F.event, a = [{
				kind: "pass",
				rid: i.rid,
				data: { slot: t.slot }
			}];
			break;
		case "choose":
			Ne(r, t.value), r.beat = F.event, a = [{
				kind: "choice",
				rid: i.rid,
				data: { kind: e.pending.kind }
			}];
			break;
		case "acquire":
			i.hand.push(r.market[t.index]), r.players.find((e) => e.rid !== i.rid).hand.push(r.market[1 - t.index]), r.market = r.draw.splice(0, 2), V(r, "acquire", i.rid), H(r, {
				kind: "endChoice",
				by: i.rid
			});
			break;
		case "end":
			H(r, {
				kind: "finish",
				by: i.rid
			});
			break;
		case "hard":
			Y(r, i, "hard"), H(r, {
				kind: "finish",
				by: i.rid
			}), a = [{
				kind: "award",
				rid: i.rid,
				data: { how: "hard" }
			}];
			break;
		case "eliminate":
			Y(r, i, "eliminated", i.remaining !== null), H(r, {
				kind: "finish",
				by: i.rid
			}), a = [{
				kind: "award",
				rid: i.rid,
				data: { how: "eliminated" }
			}];
			break;
		case "next": i.ready = !0, r.players.every((e) => e.ready) && (r.round = 2, r.start = [...r.players].sort((e, t) => e.hearts - t.hearts || t.stamp - e.stamp)[0].rid, ve(r));
	}
	return r.pending && !_e(r).length && (r.pending = null), {
		state: r,
		fx: a
	};
}
function ze(e, t) {
	let n = e.players.find((e) => e.rid === t), r = n?.role === "ghost" || n?.role === "kraken";
	return {
		public: {
			config: e.config,
			phase: e.phase,
			round: e.round,
			turn: e.turn,
			field: e.field,
			blocks: e.blocks,
			must: e.must,
			players: e.players.map((e) => ({
				rid: e.rid,
				color: e.color,
				role: e.role,
				handCount: e.hand.length,
				rareCount: e.hand.filter((e) => e >= 48).length,
				passes: e.passes,
				extra: e.extra,
				hearts: e.hearts,
				stars: e.stars,
				status: e.status,
				remaining: e.remaining,
				ready: e.ready,
				revealed: e.revealed
			})),
			continuous: e.continuous,
			instant: e.instant,
			rareSupply: e.rare.length,
			drawCount: e.draw.length,
			market: e.market,
			discarded: e.discards.map((e) => e.open ? e.card : null),
			dragon: e.dragon,
			prompt: e.pending ? {
				kind: e.pending.kind,
				by: e.pending.by
			} : null,
			log: e.log,
			history: e.history,
			ranking: e.ranking,
			played: e.played
		},
		private: {
			hand: n?.hand ?? [],
			moves: ge(e, t),
			choices: e.pending?.by === t ? _e(e) : [],
			discards: e.discards.map((e) => e.open || r ? e.card : null),
			roleChoices: e.pending?.kind === "role" ? e.pool : []
		}
	};
}
var Be = {
	meta: A,
	saveCompatibility: { version: "1" },
	schemas: {
		action: M,
		config: j,
		publicView: P,
		privateView: oe
	},
	setup: be,
	reduce: Re,
	viewFor: ze,
	status: (e) => e.phase === "done" ? {
		phase: "done",
		winner: e.ranking.slice(0, 1),
		ranking: e.ranking,
		scores: Object.fromEntries(e.players.map((t) => [t.rid, I(e) ? t.hearts : e.players.length - e.ranking.indexOf(t.rid)]))
	} : { phase: e.phase },
	nextTickIn: (e) => e.phase === "resolve" && !e.pending ? e.beat : null
}, Ve = {
	roleAbilities: "games.eternalsevens.roleAbilities",
	eternalEffects: "games.eternalsevens.eternalEffects",
	name: "games.eternalsevens.name",
	desc: "games.eternalsevens.desc",
	errAction: "games.eternalsevens.errAction",
	level: "games.eternalsevens.level",
	beginner: "games.eternalsevens.beginner",
	standard: "games.eternalsevens.standard",
	expert: "games.eternalsevens.expert",
	pro: "games.eternalsevens.pro",
	expanded: "games.eternalsevens.expanded",
	dragonOption: "games.eternalsevens.dragonOption",
	rolePool: "games.eternalsevens.rolePool",
	intro: "games.eternalsevens.intro",
	all: "games.eternalsevens.all",
	red: "games.eternalsevens.red",
	blue: "games.eternalsevens.blue",
	green: "games.eternalsevens.green",
	yellow: "games.eternalsevens.yellow",
	purple: "games.eternalsevens.purple",
	rare: "games.eternalsevens.rare",
	phoenix: "games.eternalsevens.phoenix",
	fairy: "games.eternalsevens.fairy",
	witch: "games.eternalsevens.witch",
	vampire: "games.eternalsevens.vampire",
	minotaur: "games.eternalsevens.minotaur",
	medusa: "games.eternalsevens.medusa",
	pegasus: "games.eternalsevens.pegasus",
	barong: "games.eternalsevens.barong",
	yeti: "games.eternalsevens.yeti",
	cyclops: "games.eternalsevens.cyclops",
	king: "games.eternalsevens.king",
	mermaid: "games.eternalsevens.mermaid",
	ghost: "games.eternalsevens.ghost",
	kraken: "games.eternalsevens.kraken",
	skeleton: "games.eternalsevens.skeleton",
	mummy: "games.eternalsevens.mummy",
	kyubi: "games.eternalsevens.kyubi",
	djinn: "games.eternalsevens.djinn",
	kappa: "games.eternalsevens.kappa",
	golem: "games.eternalsevens.golem",
	dragon: "games.eternalsevens.dragon",
	colorRed: "games.eternalsevens.colorRed",
	colorBlue: "games.eternalsevens.colorBlue",
	colorGreen: "games.eternalsevens.colorGreen",
	colorYellow: "games.eternalsevens.colorYellow",
	round: "games.eternalsevens.round",
	yourTurn: "games.eternalsevens.yourTurn",
	waiting: "games.eternalsevens.waiting",
	resolving: "games.eternalsevens.resolving",
	hand: "games.eternalsevens.hand",
	cards: "games.eternalsevens.cards",
	extra: "games.eternalsevens.extra",
	heart: "games.eternalsevens.heart",
	star: "games.eternalsevens.star",
	passDiscs: "games.eternalsevens.passDiscs",
	rareSupply: "games.eternalsevens.rareSupply",
	passRare: "games.eternalsevens.passRare",
	passDiscard: "games.eternalsevens.passDiscard",
	passEternal: "games.eternalsevens.passEternal",
	passDragon: "games.eternalsevens.passDragon",
	passMust: "games.eternalsevens.passMust",
	passMove: "games.eternalsevens.passMove",
	passRetrieve: "games.eternalsevens.passRetrieve",
	passExchange: "games.eternalsevens.passExchange",
	passTens: "games.eternalsevens.passTens",
	passDrain: "games.eternalsevens.passDrain",
	passPrepared: "games.eternalsevens.passPrepared",
	gainExtra: "games.eternalsevens.gainExtra",
	sharedPass: "games.eternalsevens.sharedPass",
	endTurn: "games.eternalsevens.endTurn",
	hardPass: "games.eternalsevens.hardPass",
	eliminate: "games.eternalsevens.eliminate",
	nextRound: "games.eternalsevens.nextRound",
	nextWaiting: "games.eternalsevens.nextWaiting",
	choose_role: "games.eternalsevens.choose_role",
	choose_color: "games.eternalsevens.choose_color",
	choose_target: "games.eternalsevens.choose_target",
	choose_gift: "games.eternalsevens.choose_gift",
	choose_return: "games.eternalsevens.choose_return",
	choose_transfer: "games.eternalsevens.choose_transfer",
	choose_collect: "games.eternalsevens.choose_collect",
	choose_discard: "games.eternalsevens.choose_discard",
	choose_must: "games.eternalsevens.choose_must",
	choose_move: "games.eternalsevens.choose_move",
	choose_retrieve: "games.eternalsevens.choose_retrieve",
	choose_dragon: "games.eternalsevens.choose_dragon",
	selectCard: "games.eternalsevens.selectCard",
	selectedCard: "games.eternalsevens.selectedCard",
	chooseAcquisition: "games.eternalsevens.chooseAcquisition",
	draw: "games.eternalsevens.draw",
	instant: "games.eternalsevens.instant",
	continuous: "games.eternalsevens.continuous",
	dragonForbidden: "games.eternalsevens.dragonForbidden",
	dragonPlayable: "games.eternalsevens.dragonPlayable",
	dragonChoice: "games.eternalsevens.dragonChoice",
	dragon_fairy: "games.eternalsevens.dragon_fairy",
	dragon_mermaid: "games.eternalsevens.dragon_mermaid",
	dragon_vampire: "games.eternalsevens.dragon_vampire",
	dragon_ghost: "games.eternalsevens.dragon_ghost",
	dragon_discard: "games.eternalsevens.dragon_discard",
	dragon_dragon: "games.eternalsevens.dragon_dragon",
	dragon_kraken: "games.eternalsevens.dragon_kraken",
	dragon_hard: "games.eternalsevens.dragon_hard",
	dragon_must: "games.eternalsevens.dragon_must",
	dragon_cyclops: "games.eternalsevens.dragon_cyclops",
	dragon_mummy: "games.eternalsevens.dragon_mummy",
	dragon_extra: "games.eternalsevens.dragon_extra",
	dragon_heart: "games.eternalsevens.dragon_heart",
	dragon_moveAll: "games.eternalsevens.dragon_moveAll",
	dragon_hardBonus: "games.eternalsevens.dragon_hardBonus",
	dragon_outBonus: "games.eternalsevens.dragon_outBonus",
	dragonAvailable: "games.eternalsevens.dragonAvailable",
	cube: "games.eternalsevens.cube",
	out: "games.eternalsevens.out",
	hard: "games.eternalsevens.hard",
	eliminated: "games.eternalsevens.eliminated",
	active: "games.eternalsevens.active",
	remaining: "games.eternalsevens.remaining",
	overview: "games.eternalsevens.overview",
	close: "games.eternalsevens.close",
	log: "games.eternalsevens.log",
	discards: "games.eternalsevens.discards",
	hidden: "games.eternalsevens.hidden",
	field: "games.eternalsevens.field",
	blocked: "games.eternalsevens.blocked",
	must: "games.eternalsevens.must",
	roundOver: "games.eternalsevens.roundOver",
	resultTitle: "games.eternalsevens.resultTitle",
	winner: "games.eternalsevens.winner",
	rank: "games.eternalsevens.rank",
	roundResult: "games.eternalsevens.roundResult",
	viewField: "games.eternalsevens.viewField",
	log_play: "games.eternalsevens.log_play",
	log_pass: "games.eternalsevens.log_pass",
	log_instant: "games.eternalsevens.log_instant",
	log_continuous: "games.eternalsevens.log_continuous",
	log_dragon: "games.eternalsevens.log_dragon",
	log_choice: "games.eternalsevens.log_choice",
	log_star: "games.eternalsevens.log_star",
	log_out: "games.eternalsevens.log_out",
	log_hard: "games.eternalsevens.log_hard",
	log_eliminated: "games.eternalsevens.log_eliminated",
	log_first: "games.eternalsevens.log_first",
	log_acquire: "games.eternalsevens.log_acquire",
	power_red: "games.eternalsevens.power_red",
	power_blue: "games.eternalsevens.power_blue",
	power_green: "games.eternalsevens.power_green",
	power_yellow: "games.eternalsevens.power_yellow",
	power_phoenix: "games.eternalsevens.power_phoenix",
	power_fairy: "games.eternalsevens.power_fairy",
	power_witch: "games.eternalsevens.power_witch",
	power_vampire: "games.eternalsevens.power_vampire",
	power_minotaur: "games.eternalsevens.power_minotaur",
	power_medusa: "games.eternalsevens.power_medusa",
	power_pegasus: "games.eternalsevens.power_pegasus",
	power_barong: "games.eternalsevens.power_barong",
	power_yeti: "games.eternalsevens.power_yeti",
	power_cyclops: "games.eternalsevens.power_cyclops",
	power_king: "games.eternalsevens.power_king",
	power_mermaid: "games.eternalsevens.power_mermaid",
	power_ghost: "games.eternalsevens.power_ghost",
	power_kraken: "games.eternalsevens.power_kraken",
	power_skeleton: "games.eternalsevens.power_skeleton",
	power_mummy: "games.eternalsevens.power_mummy",
	power_kyubi: "games.eternalsevens.power_kyubi",
	power_djinn: "games.eternalsevens.power_djinn",
	power_kappa: "games.eternalsevens.power_kappa",
	power_golem: "games.eternalsevens.power_golem",
	effect_phoenix: "games.eternalsevens.effect_phoenix",
	effect_skeleton: "games.eternalsevens.effect_skeleton",
	effect_barong: "games.eternalsevens.effect_barong",
	effect_mummy: "games.eternalsevens.effect_mummy",
	effect_kyubi: "games.eternalsevens.effect_kyubi",
	effect_minotaur: "games.eternalsevens.effect_minotaur",
	effect_ghost: "games.eternalsevens.effect_ghost",
	effect_dragon: "games.eternalsevens.effect_dragon",
	effect_king: "games.eternalsevens.effect_king",
	effect_kappa: "games.eternalsevens.effect_kappa",
	effect_yeti: "games.eternalsevens.effect_yeti",
	effect_kraken: "games.eternalsevens.effect_kraken",
	effect_cyclops: "games.eternalsevens.effect_cyclops",
	effect_djinn: "games.eternalsevens.effect_djinn",
	effect_pegasus: "games.eternalsevens.effect_pegasus",
	effect_mermaid: "games.eternalsevens.effect_mermaid",
	effect_fairy: "games.eternalsevens.effect_fairy",
	effect_witch: "games.eternalsevens.effect_witch",
	effect_medusa: "games.eternalsevens.effect_medusa",
	effect_golem: "games.eternalsevens.effect_golem",
	effect_vampire: "games.eternalsevens.effect_vampire",
	rules: "games.eternalsevens.rules"
};
function X() {
	let e = l(), t = (t, n) => e(Ve[t], n);
	return {
		label: t,
		cardLabel: (e) => e >= 48 ? t("rare") : e >= 40 ? `${t("purple")} ∞` : `${t([
			"colorRed",
			"colorBlue",
			"colorGreen",
			"colorYellow"
		][Math.floor(e / 10)])} ${T(e)}`,
		passLabel: (e, n) => t(e.kind === "eternal" ? n ? "passDragon" : "passEternal" : `pass${e.kind[0].toUpperCase()}${e.kind.slice(1)}`, { n: e.count ?? 1 }),
		colorOf: w
	};
}
//#endregion
//#region src/games/eternalsevens/card.tsx
var Z = (e) => `games/eternalsevens/${e}.svg`, He = (e) => Z(`card-${e >= 48 ? 48 : e >= 40 ? 40 : e}`);
function Q({ id: e, anchor: t, className: n = "" }) {
	let { cardLabel: r } = X(), { ref: i, hidden: a } = s(t ?? null);
	return /* @__PURE__ */ g("span", {
		ref: i,
		className: `e7-card ${n}`,
		style: { visibility: a ? "hidden" : void 0 },
		children: /* @__PURE__ */ g("img", {
			src: He(e),
			alt: r(e),
			draggable: !1
		})
	});
}
function Ue({ kind: e, n: t, label: n }) {
	return /* @__PURE__ */ _("span", {
		className: "e7-token",
		title: n,
		"aria-label": `${n}${t === void 0 ? "" : ` ${t}`}`,
		children: [/* @__PURE__ */ g("img", {
			src: Z(e),
			alt: "",
			draggable: !1
		}), t !== void 0 && /* @__PURE__ */ g("b", { children: t })]
	});
}
function We() {
	return /* @__PURE__ */ g("svg", {
		className: "e7-marching",
		"aria-hidden": !0,
		children: /* @__PURE__ */ g("rect", {
			x: "2",
			y: "2",
			width: "calc(100% - 4px)",
			height: "calc(100% - 4px)",
			rx: "4",
			fill: "none",
			stroke: "#fff0c4",
			strokeWidth: "2",
			strokeDasharray: "6 4",
			children: /* @__PURE__ */ g("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-20",
				dur: "1.1s",
				repeatCount: "indefinite"
			})
		})
	});
}
//#endregion
//#region src/games/eternalsevens/board.tsx
var $ = [
	"#9b2b50",
	"#24769b",
	"#599778",
	"#bf9434"
];
function Ge({ pub: e, row: t, col: n, legal: r, choose: i, move: a, onPick: o }) {
	let { label: c } = X(), { ref: l, hidden: u } = s(`cell:${t}:${n}`), d = e.field[t][n], f = e.blocks[t] === n, p = e.must.includes(t * 12 + n), m = e.config.level === "expert" || e.config.level === "pro" ? O[e.dragon.forbidden] : e.continuous, h = m === "fairy" && (n === 3 || n === 8) || m === "mermaid" && (n === 1 || n === 10) || m === "vampire" && (n === 0 || n === 11), v = n === 0 || n === 11 ? "∞" : n;
	return /* @__PURE__ */ _("button", {
		ref: l,
		type: "button",
		className: `e7-cell${d === null ? "" : " occupied"}${r || i || a ? " eligible" : ""}`,
		onClick: o,
		disabled: !r && !i && !a,
		"aria-label": `${c([
			"colorRed",
			"colorBlue",
			"colorGreen",
			"colorYellow"
		][t])} ${v}${f ? ` · ${c("blocked")}` : ""}${p ? ` · ${c("must")}` : ""}`,
		style: { visibility: u ? "hidden" : void 0 },
		children: [
			d !== null && /* @__PURE__ */ g(Q, { id: d }),
			/* @__PURE__ */ g("b", {
				className: "e7-cell-value",
				children: v
			}),
			d !== null && d >= 48 && /* @__PURE__ */ g("span", {
				className: "e7-rare-mark",
				children: "R"
			}),
			f && /* @__PURE__ */ g("img", {
				className: "e7-block",
				src: Z("star"),
				alt: c("blocked")
			}),
			p && /* @__PURE__ */ g("img", {
				className: "e7-must",
				src: Z("must"),
				alt: c("must")
			}),
			h && (d === null || d >= 48) && /* @__PURE__ */ g("img", {
				className: "e7-x",
				src: Z("x"),
				alt: c(`dragon_${m}`)
			}),
			(r || i || a) && /* @__PURE__ */ g(We, {})
		]
	});
}
function Ke({ pub: e, plays: t = [], selected: n, choices: r = [], prompt: i, send: a }) {
	let { label: o } = X();
	return /* @__PURE__ */ g("div", {
		className: "e7-field-scroll",
		"aria-label": o("field"),
		children: /* @__PURE__ */ g("div", {
			className: "e7-field",
			children: e.field.map((o, s) => /* @__PURE__ */ g("div", {
				className: "e7-row",
				style: { "--row-color": $[s] },
				children: o.map((o, c) => {
					let l = t.find((e) => e.card === n && e.row === s && e.col === c), u = r.some((e) => e.value === (i === "move" ? s : s * 12 + c));
					return /* @__PURE__ */ g(Ge, {
						pub: e,
						row: s,
						col: c,
						legal: !!l,
						choose: i === "must" && u,
						move: i === "move" && u && e.blocks[s] === c,
						onPick: () => {
							l ? a?.(l) : u && a?.({
								type: "choose",
								value: i === "move" ? s : s * 12 + c
							});
						}
					}, c);
				})
			}, s))
		})
	});
}
function qe({ p: e, gamer: t, discs: n }) {
	let { label: r } = X();
	return /* @__PURE__ */ _("span", {
		className: "e7-resources",
		children: [
			/* @__PURE__ */ g(Ue, {
				kind: "star",
				n: e.stars,
				label: r("star")
			}),
			t && /* @__PURE__ */ g(Ue, {
				kind: `heart-${[
					"red",
					"blue",
					"green",
					"yellow"
				][e.color]}`,
				n: e.hearts,
				label: r("heart")
			}),
			/* @__PURE__ */ g(Ue, {
				kind: "extra",
				n: e.extra,
				label: r("extra")
			}),
			/* @__PURE__ */ g("span", {
				title: r("passDiscs"),
				className: "e7-discs",
				children: Array.from({ length: n }, (t, n) => /* @__PURE__ */ g("i", { className: n < e.passes.length ? "spent" : "" }, n))
			})
		]
	});
}
//#endregion
//#region src/games/eternalsevens/power-text.tsx
function Je({ text: e }) {
	let t = e.split("\n").map((e) => e.replace(/^·\s*/, "").trim()).filter(Boolean);
	return /* @__PURE__ */ g("ul", {
		className: "e7-power",
		children: t.map((e, t) => /* @__PURE__ */ g("li", { children: e }, t))
	});
}
//#endregion
//#region src/games/eternalsevens/view-player.tsx
function Ye({ p: e, name: t, gamer: n, discs: r, member: i, myRid: a, target: o, onClick: c, active: l }) {
	let { label: u } = X(), { ref: d } = s(`seat:${e.rid}`);
	return /* @__PURE__ */ _("button", {
		ref: d,
		type: "button",
		className: `e7-seat${l ? " current" : ""}${e.status === "active" ? "" : " finished"}`,
		style: { "--seat-color": $[e.color] },
		onClick: c,
		children: [
			/* @__PURE__ */ _("span", {
				className: "e7-seat-identity",
				children: [i && /* @__PURE__ */ g(p, {
					m: i,
					myRid: a,
					action: null,
					anchorName: null,
					box: "size-8",
					img: "size-6"
				}), /* @__PURE__ */ g("span", {
					className: "e7-seat-name",
					children: t
				})]
			}),
			/* @__PURE__ */ g("small", { children: u(e.role) }),
			/* @__PURE__ */ _("span", {
				className: "e7-seat-cards",
				children: [u("cards", { n: e.handCount }), e.rareCount > 0 && /* @__PURE__ */ _("span", {
					className: "e7-public-rare",
					children: ["R ", e.rareCount]
				})]
			}),
			/* @__PURE__ */ g(qe, {
				p: e,
				gamer: n,
				discs: r
			}),
			e.status === "active" ? e.remaining !== null && /* @__PURE__ */ g("em", { children: u("remaining", { n: e.remaining }) }) : /* @__PURE__ */ g("em", { children: u(e.status) }),
			o && /* @__PURE__ */ g(We, {})
		]
	});
}
function Xe({ pub: e, priv: t, myRid: n, send: r, mobile: i = !1 }) {
	let { label: a, passLabel: o } = X(), s = e.players.find((e) => e.rid === n);
	if (!s) return null;
	let c = e.config.level === "expert" || e.config.level === "pro", l = (e.config.level === "beginner" ? D : [...D, ...te[s.role]]).map((e, t) => ({
		pass: e,
		slot: t
	}));
	return e.players.length === 2 && l.push(...[6, 7].map((e) => ({
		pass: {
			kind: "eternal",
			bonus: 0,
			count: 1
		},
		slot: e
	}))), /* @__PURE__ */ g("div", {
		className: `e7-passes${i ? " mobile" : ""}`,
		children: l.map(({ pass: n, slot: i }) => {
			let l = t?.moves.some((e) => e.type === "pass" && e.slot === i), u = i >= 6 ? e.players.some((e) => e.passes.includes(i)) : s.passes.includes(i), d = n.kind === "rare" ? "card-48" : n.kind === "must" || n.kind === "exchange" ? "must" : n.kind === "move" ? "star" : n.kind === "eternal" ? "eternal-action" : n.kind === "drain" ? "extra" : "discard-action";
			return /* @__PURE__ */ _("button", {
				type: "button",
				className: `e7-pass${u ? " spent" : ""}`,
				disabled: !l,
				onClick: () => r({
					type: "pass",
					slot: i
				}),
				title: n.bonus ? a("gainExtra", { n: n.bonus }) : void 0,
				children: [/* @__PURE__ */ g("img", {
					src: Z(d),
					alt: ""
				}), /* @__PURE__ */ _("span", { children: [
					o(n, c),
					i >= 6 && /* @__PURE__ */ g("small", { children: a("sharedPass") }),
					n.bonus > 0 && /* @__PURE__ */ g("small", { children: /* @__PURE__ */ g(Ue, {
						kind: "extra",
						n: n.bonus,
						label: a("extra")
					}) })
				] })]
			}, i);
		})
	});
}
function Ze({ pub: e, onInfo: t }) {
	let { label: n } = X(), r = e.config.level === "expert" || e.config.level === "pro", { ref: i } = s("eternal");
	return /* @__PURE__ */ g("div", {
		ref: i,
		className: "e7-eternals",
		children: r ? /* @__PURE__ */ _(h, { children: [
			/* @__PURE__ */ _("div", {
				className: "e7-dragon-summary",
				children: [/* @__PURE__ */ g("h3", { children: n("dragonForbidden") }), /* @__PURE__ */ g("span", { children: e.dragon.forbidden >= 0 ? n(`dragon_${O[e.dragon.forbidden]}`) : n("dragonAvailable") })]
			}),
			/* @__PURE__ */ _("div", {
				className: "e7-dragon-summary",
				children: [/* @__PURE__ */ g("h3", { children: n("dragonPlayable") }), /* @__PURE__ */ g("span", { children: e.dragon.playable >= 0 ? n(`dragon_${k[e.dragon.playable % 4]}`) : n("dragonAvailable") })]
			}),
			/* @__PURE__ */ _("div", {
				className: "e7-dragon-summary",
				children: [/* @__PURE__ */ g("h3", { children: n("dragonChoice") }), /* @__PURE__ */ g("div", {
					className: "e7-cubes",
					children: e.dragon.cubes.map((t, r) => /* @__PURE__ */ g("span", {
						style: { "--seat-color": $[r] },
						className: t >= 0 ? "used" : "",
						children: t >= 0 ? n(`dragon_${(e.dragon.side === 0 ? [
							"extra",
							"heart",
							"moveAll",
							"mummy"
						] : [
							"extra",
							"heart",
							"hardBonus",
							"outBonus"
						])[t]}`) : "◇"
					}, r))
				})]
			})
		] }) : /* @__PURE__ */ g(h, { children: [["instant", e.instant], ["continuous", e.continuous]].map(([e, r]) => /* @__PURE__ */ _("button", {
			type: "button",
			className: "e7-eternal-card",
			onClick: () => r && t(`effect:${r === "dragon" && e === "continuous" ? "dragon-continuous" : r}`),
			disabled: !r,
			children: [/* @__PURE__ */ g("small", { children: n(e) }), r ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("img", {
				src: Z(r === "dragon" && e === "continuous" ? "dragon-continuous" : r),
				alt: n(r)
			}), /* @__PURE__ */ g("strong", { children: n(r) })] }) : /* @__PURE__ */ g("div", {
				className: "e7-card-back",
				children: "∞"
			})]
		}, e)) })
	});
}
function Qe({ public: e, private: t, members: r, myRid: s, send: l }) {
	let p = e, v = t, { label: y, cardLabel: b } = X(), ee = c((e) => e.locale), x = (e) => {
		let t = r.find((t) => t.rid === e);
		return t ? m(t, ee) : e;
	}, [S, C] = i(null), [w, T] = i(null), E = w?.split(":")[1], D = w?.split(":")[0], [te, ne] = i(""), re = `${p.turn}:${p.phase}:${p.prompt?.kind}:${v?.hand.join(",")}`;
	te !== re && (ne(re), C(null));
	let ie = p.config.level === "expert" || p.config.level === "pro", O = p.players.find((e) => e.rid === s), k = p.prompt?.by === s ? p.prompt.kind : void 0, A = v?.choices ?? [], j = v?.moves ?? [], M = [...v?.hand ?? []].sort((e, t) => e - t), [N, ae] = i(M), [P, oe] = i([]);
	N.join(",") !== M.join(",") && (oe(N.filter((e) => !M.includes(e))), ae(M)), n(() => {
		if (!P.length) return;
		let e = window.setTimeout(() => oe([]), F.play);
		return () => window.clearTimeout(e);
	}, [P]);
	let I = [...M, ...P].sort((e, t) => e - t), L = j.filter((e) => e.type === "play"), R = !!k && [
		"discard",
		"transfer",
		"collect",
		"gift",
		"return"
	].includes(k), z = !!k && [
		"role",
		"dragon",
		"retrieve",
		"color"
	].includes(k);
	d(j.length > 0, u);
	let B = k ? y(`choose_${k}`) : p.phase === "roundOver" ? y("roundOver") : p.phase === "resolve" ? y("resolving") : p.turn === s ? y("yourTurn") : y("waiting", { name: x(p.turn) }), V = (e) => {
		C(null), l(e);
	}, H = /* @__PURE__ */ _("div", {
		className: "e7-controls",
		children: [
			/* @__PURE__ */ g("span", {
				role: "status",
				children: S === null ? B : y("selectedCard")
			}),
			/* @__PURE__ */ _("button", {
				type: "button",
				onClick: () => T("discards"),
				children: [
					y("discards"),
					" ",
					p.discarded.length
				]
			}),
			/* @__PURE__ */ g("button", {
				type: "button",
				onClick: () => T("log"),
				children: y("log")
			}),
			j.some((e) => e.type === "end") && /* @__PURE__ */ g("button", {
				type: "button",
				className: "e7-primary",
				onClick: () => V({ type: "end" }),
				children: y("endTurn")
			}),
			j.some((e) => e.type === "hard") && /* @__PURE__ */ g(o, {
				compact: !0,
				label: y("hardPass"),
				confirmLabel: y("hardPass"),
				onConfirm: () => V({ type: "hard" }),
				className: "e7-hard"
			}),
			j.some((e) => e.type === "eliminate") && /* @__PURE__ */ g("button", {
				type: "button",
				onClick: () => V({ type: "eliminate" }),
				children: y("eliminate")
			}),
			p.phase === "roundOver" && /* @__PURE__ */ g("button", {
				type: "button",
				disabled: O?.ready,
				onClick: () => V({ type: "next" }),
				children: y(O?.ready ? "nextWaiting" : "nextRound")
			})
		]
	});
	return /* @__PURE__ */ _("div", {
		className: "e7-screen",
		children: [
			/* @__PURE__ */ g(f, {
				adaptive: !0,
				scroll: !1,
				banner: /* @__PURE__ */ _("header", {
					className: "e7-header",
					children: [/* @__PURE__ */ _("div", {
						className: "e7-title",
						children: [/* @__PURE__ */ _("h1", { children: [
							y("name"),
							" ",
							/* @__PURE__ */ g("span", { children: "ETERNAL SEVENS" })
						] }), /* @__PURE__ */ g("span", { children: ie && y("round", { n: p.round }) })]
					}), /* @__PURE__ */ g("div", {
						className: "e7-seats",
						children: p.players.map((e, t) => /* @__PURE__ */ g(Ye, {
							p: e,
							name: x(e.rid),
							gamer: ie,
							discs: p.config.level === "beginner" ? 3 : 4,
							member: r.find((t) => t.rid === e.rid),
							myRid: s,
							active: (p.prompt?.by ?? p.turn) === e.rid && p.phase !== "roundOver",
							target: k === "target" && A.some((e) => e.value === t),
							onClick: () => k === "target" && A.some((e) => e.value === t) ? V({
								type: "choose",
								value: t
							}) : T(`role:${e.role}`)
						}, e.rid))
					})]
				}),
				actionsHeight: "e7-actions-height",
				actions: /* @__PURE__ */ _("div", {
					className: "e7-actions",
					children: [
						/* @__PURE__ */ _("div", {
							className: "e7-hand-heading",
							children: [/* @__PURE__ */ g("span", { children: y("hand") }), /* @__PURE__ */ g("span", { children: R ? B : p.turn === s && L.length > 0 ? y("selectCard") : "" })]
						}),
						/* @__PURE__ */ g("div", {
							className: "e7-hand",
							children: I.map((e) => {
								let t = P.includes(e) && !M.includes(e), n = !t && R && A.some((t) => t.value === e), r = !t && L.some((t) => t.card === e);
								return /* @__PURE__ */ _("button", {
									type: "button",
									"aria-hidden": t || void 0,
									style: { visibility: t ? "hidden" : void 0 },
									className: `e7-hand-card${S === e ? " selected" : ""}`,
									disabled: !n && !r,
									"aria-label": b(e),
									"aria-pressed": S === e,
									onClick: () => n ? V({
										type: "choose",
										value: e
									}) : C(S === e ? null : e),
									children: [/* @__PURE__ */ g(Q, {
										id: e,
										anchor: `hand:${e}`
									}), n && /* @__PURE__ */ g(We, {})]
								}, e);
							})
						}),
						/* @__PURE__ */ g(Xe, {
							mobile: !0,
							pub: p,
							priv: v,
							myRid: s,
							send: l
						}),
						H
					]
				}),
				children: /* @__PURE__ */ _("main", {
					className: "e7-arena",
					children: [/* @__PURE__ */ _("div", {
						className: "e7-field-zone",
						children: [/* @__PURE__ */ g(Ke, {
							pub: p,
							plays: L,
							selected: S,
							prompt: k,
							choices: A,
							send: V
						}), p.market.length > 0 && /* @__PURE__ */ _("div", {
							className: "e7-market",
							children: [/* @__PURE__ */ _("span", { children: [
								y("draw"),
								" ",
								p.drawCount,
								/* @__PURE__ */ g("small", { children: y("chooseAcquisition") })
							] }), p.market.map((e, t) => /* @__PURE__ */ g("button", {
								type: "button",
								disabled: !j.some((e) => e.type === "acquire" && e.index === t),
								onClick: () => V({
									type: "acquire",
									index: t
								}),
								children: /* @__PURE__ */ g(Q, { id: e })
							}, e))]
						})]
					}), /* @__PURE__ */ _("aside", {
						className: "e7-side",
						children: [/* @__PURE__ */ g(Ze, {
							pub: p,
							onInfo: T
						}), /* @__PURE__ */ g(Xe, {
							pub: p,
							priv: v,
							myRid: s,
							send: l
						})]
					})]
				})
			}),
			/* @__PURE__ */ g(a, {
				side: "left",
				open: z,
				label: B,
				title: B,
				children: /* @__PURE__ */ g("div", {
					className: "e7-choice-sheet",
					children: A.map((e) => /* @__PURE__ */ g("button", {
						type: "button",
						className: `e7-choice e7-choice-${e.kind}`,
						onClick: () => V({
							type: "choose",
							value: e.value
						}),
						children: e.kind === "card" ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(Q, { id: e.value }), /* @__PURE__ */ g("span", { children: b(e.value) })] }) : e.kind === "role" ? /* @__PURE__ */ _(h, { children: [
							/* @__PURE__ */ g("img", {
								src: Z(e.detail),
								alt: ""
							}),
							/* @__PURE__ */ g("strong", { children: y(e.detail) }),
							/* @__PURE__ */ g(Je, { text: y(`power_${e.detail}`) })
						] }) : e.kind === "dragon" ? /* @__PURE__ */ _(h, { children: [
							/* @__PURE__ */ g("span", {
								className: "e7-dragon-cube",
								children: "◇"
							}),
							/* @__PURE__ */ g("strong", { children: y(`dragon_${e.detail}`) }),
							e.value >= 10 && e.value < 100 && /* @__PURE__ */ g("small", { children: y("cube", { n: Math.floor((e.value - 10) / 4) + 1 }) })
						] }) : /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("i", { style: { background: [...$, "#624291"][e.value] } }), /* @__PURE__ */ g("span", { children: y([
							"colorRed",
							"colorBlue",
							"colorGreen",
							"colorYellow",
							"purple"
						][e.value]) })] })
					}, e.value))
				})
			}),
			/* @__PURE__ */ g(a, {
				side: "left",
				open: w !== null,
				onClose: () => T(null),
				label: y(w === "log" || w === "discards" ? w : "overview"),
				title: y(w === "log" || w === "discards" ? w : "overview"),
				children: /* @__PURE__ */ g("div", {
					className: "e7-info",
					children: w === "log" ? /* @__PURE__ */ g("ol", { children: p.log.map((e, t) => /* @__PURE__ */ g("li", { children: y(`log_${e.kind}`, {
						name: x(e.by),
						card: e.n === void 0 ? "" : b(e.n),
						detail: e.kind === "dragon" ? y(`dragon_${e.detail}`) : e.detail ? y(e.detail) : ""
					}) }, t)) }) : w === "discards" ? /* @__PURE__ */ g("div", {
						className: "e7-discard-grid",
						children: (v?.discards ?? p.discarded).map((e, t) => e === null ? /* @__PURE__ */ g("div", {
							className: "e7-card-back",
							"aria-label": y("hidden"),
							children: "∞"
						}, t) : /* @__PURE__ */ g(Q, { id: e }, t))
					}) : E && /* @__PURE__ */ _(h, { children: [
						/* @__PURE__ */ g("img", {
							className: "e7-info-art",
							src: Z(E),
							alt: y(E === "dragon-continuous" ? "dragon" : E)
						}),
						/* @__PURE__ */ g("h2", { children: y(E === "dragon-continuous" ? "dragon" : E) }),
						D === "role" ? /* @__PURE__ */ g(Je, { text: y(`power_${E}`) }) : /* @__PURE__ */ g("p", { children: y(E === "dragon-continuous" ? "dragon_dragon" : `effect_${E}`) })
					] })
				})
			})
		]
	});
}
//#endregion
//#region src/games/eternalsevens/bot.ts
var $e = {
	chain: 2,
	rare: 3,
	star: 20,
	event: 1,
	pass: 1,
	hard: 1
}, et = (e) => e.config.level === "expert" || e.config.level === "pro";
function tt(e, t, n, r, i) {
	let a = t.players.find((e) => e.rid === r), o = n.hand, s = (e) => {
		if (e >= 48) return -i.rare;
		if (e >= 40) return 1;
		let n = T(e), r = Math.floor(e / 10);
		return Math.min(...t.field[r].flatMap((e, t) => e === null ? [] : [Math.abs(t - n)]), Math.abs(n - 5.5)) + (n === 1 || n === 10 ? 2 : 0);
	};
	switch (e.type) {
		case "play": {
			let n = t.field[e.row], r = T(e.card), c = o.filter((t) => t !== e.card && t < 40 && Math.floor(t / 10) === e.row && Math.abs(T(t) - e.col) === 1).length, l = n.filter((e) => e === null).length === 1 && n[e.col] === null, u = (e.col === 0 || e.col === 11) && t.blocks[e.row] === -1;
			return 12 + s(e.card) + c * i.chain + (l ? i.star : 0) - (e.card >= 48 ? i.rare : 0) + (r === 2 || r === 9 ? i.event : 0) + (u ? 2 : 0) + (o.length === 1 ? 100 : 0) + (a.remaining === null ? 0 : 10);
		}
		case "pass": {
			let r = e.slot >= 6 ? {
				kind: "eternal",
				bonus: 0
			} : [...D, ...t.config.level === "beginner" ? [] : te[a.role]][e.slot], s = n.moves.some((e) => e.type === "play");
			return -i.pass * (s ? 8 : 0) + r.bonus * 2 + (r.kind === "discard" ? 10 : r.kind === "rare" ? -2 : r.kind === "retrieve" ? -7 : 0) + (r.kind === "discard" && o.length === 1 ? 100 : 0);
		}
		case "hard": return (a.remaining === null ? o.length === 1 && n.moves.some((e) => e.type === "play") ? -20 : 3 : 85) * i.hard;
		case "acquire": return -12 + s(t.market[1 - e.index]) - s(t.market[e.index]);
		case "choose": {
			let r = n.choices.find((t) => t.value === e.value), i = t.prompt?.kind;
			return r.kind === "card" ? i === "retrieve" || i === "collect" ? -s(e.value) : s(e.value) : r.kind === "role" ? [
				"phoenix",
				"pegasus",
				"king",
				"kyubi",
				"cyclops",
				"mermaid"
			].includes(r.detail ?? "") ? 5 : 2 : r.kind === "color" ? -o.filter((t) => w(t) === [
				"red",
				"blue",
				"green",
				"yellow",
				"purple"
			][e.value]).length : r.kind === "player" ? t.players[e.value].handCount : r.kind === "position" ? o.some((t) => t < 40 && Math.floor(t / 10) * 12 + T(t) === e.value) ? -4 : 1 : r.kind === "row" ? t.field[e.value].filter((e) => e === null).length : r.kind === "dragon" ? r.detail === "heart" ? 5 : r.detail === "extra" ? a.extra < 2 ? 6 : -2 : r.detail === "discard" ? 8 : r.detail === "hard" ? -15 : r.detail === "hardBonus" || r.detail === "outBonus" ? 4 : 0 : 0;
		}
		case "end": return 0;
		case "eliminate": return -1e3;
		case "next": return et(t) ? 100 : 0;
		default: return -1e3;
	}
}
var nt = ((e = {}) => {
	let t = {
		...$e,
		...e
	};
	return (e, n) => {
		let r = e.private;
		return r?.moves.length ? { action: r.moves.reduce((i, a) => tt(a, e.public, r, n.rid, t) > tt(i, e.public, r, n.rid, t) ? a : i) } : null;
	};
})();
//#endregion
//#region src/games/eternalsevens/fx.tsx
function rt({ at: e, ms: t, color: i }) {
	let a = r(null);
	return n(() => {
		let e = a.current?.animate([
			{ opacity: 0 },
			{
				opacity: .9,
				offset: .25
			},
			{
				opacity: .4,
				offset: .6
			},
			{ opacity: 0 }
		], {
			duration: t,
			easing: "ease-in-out"
		});
		return () => e?.cancel();
	}, [t]), /* @__PURE__ */ g("div", {
		ref: a,
		style: {
			position: "absolute",
			left: e.x - 2,
			top: e.y - 2,
			width: e.w + 4,
			height: e.h + 4,
			border: `2px solid ${i}`,
			borderRadius: 7
		}
	});
}
var it = {
	play(e, t) {
		let n = e.data, r = t.anchor(`cell:${n.row}:${n.col}`), i = t.anchor(`hand:${n.card}`), a = t.anchor(`seat:${e.rid}`), o = i ?? (r && a ? {
			x: a.x + a.w / 2 - r.w / 2,
			y: a.y + a.h / 2 - r.h / 2,
			w: r.w,
			h: r.h
		} : null);
		if (!r || !o) return null;
		let s = t.queued ? Math.min(F.play, 180) : F.play;
		return {
			ms: s,
			hide: t.queued ? [] : [`cell:${n.row}:${n.col}`],
			node: /* @__PURE__ */ g(v, {
				from: o,
				to: r,
				ms: s,
				children: /* @__PURE__ */ g("div", {
					style: {
						width: o.w,
						height: o.h
					},
					children: /* @__PURE__ */ g(Q, { id: n.card })
				})
			})
		};
	},
	eternal(e, t) {
		let n = t.anchor("eternal");
		return n ? {
			ms: F.event,
			node: /* @__PURE__ */ g(rt, {
				at: n,
				ms: F.event,
				color: "#c6afe1"
			})
		} : null;
	},
	star(e, t) {
		let n = e.data, r = t.anchor(`seat:${e.rid}`), i = t.anchor(`cell:${n.row}:${n.col}`);
		return r && i ? {
			ms: F.award,
			node: /* @__PURE__ */ g(v, {
				from: i,
				to: {
					x: r.x + r.w / 2 - 18,
					y: r.y + r.h / 2 - 18,
					w: 36,
					h: 36
				},
				ms: F.award,
				children: /* @__PURE__ */ g("img", {
					src: Z("star"),
					alt: "",
					style: {
						width: 36,
						height: 36
					}
				})
			})
		} : null;
	},
	pass(e, t) {
		let n = t.anchor(`seat:${e.rid}`);
		return n ? {
			ms: F.event,
			node: /* @__PURE__ */ g(rt, {
				at: n,
				ms: F.event,
				color: "#bca2da"
			})
		} : null;
	},
	choice(e, t) {
		let n = t.anchor(`seat:${e.rid}`);
		return n ? {
			ms: F.event,
			node: /* @__PURE__ */ g(rt, {
				at: n,
				ms: F.event,
				color: "#bca2da"
			})
		} : null;
	},
	award(e, t) {
		let n = t.anchor(`seat:${e.rid}`);
		return n ? {
			ms: F.award,
			node: /* @__PURE__ */ g(rt, {
				at: n,
				ms: F.award,
				color: "#f2d694"
			})
		} : null;
	}
};
//#endregion
//#region src/games/eternalsevens/game-over.tsx
function at({ result: e, public: t, members: n, onPlayAgain: r, onBackToLobby: a }) {
	let o = t, { label: s } = X(), u = l(), d = c((e) => e.locale), [f, p] = i(!1), h = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? m(t, d) : e;
	}, v = o.config.level === "expert" || o.config.level === "pro", y = o.players.find((t) => t.rid === e.winner[0]);
	return /* @__PURE__ */ _("div", {
		className: "e7-screen e7-over",
		children: [
			/* @__PURE__ */ _("header", {
				className: "e7-over-header",
				children: [y && /* @__PURE__ */ g("img", {
					src: Z(y.role),
					alt: s(y.role)
				}), /* @__PURE__ */ _("div", { children: [
					/* @__PURE__ */ g("h1", { children: s("resultTitle") }),
					/* @__PURE__ */ g("strong", { children: e.winner.map(h).join(" · ") }),
					/* @__PURE__ */ g("p", { children: s("winner") })
				] })]
			}),
			/* @__PURE__ */ g("div", {
				className: "e7-results",
				children: e.ranking.map((t, n) => {
					let r = o.players.find((e) => e.rid === t);
					return /* @__PURE__ */ _("section", {
						className: `e7-result${e.winner.includes(t) ? " winner" : ""}`,
						style: { "--seat-color": $[r.color] },
						children: [
							/* @__PURE__ */ g("img", {
								src: Z(r.role),
								alt: ""
							}),
							/* @__PURE__ */ g("span", { children: s("rank", { n: n + 1 }) }),
							/* @__PURE__ */ g("h2", { children: h(t) }),
							/* @__PURE__ */ g("h3", { children: s(r.role) }),
							/* @__PURE__ */ g(qe, {
								p: r,
								gamer: v,
								discs: o.config.level === "beginner" ? 3 : 4
							}),
							/* @__PURE__ */ g("p", { children: s(r.status) }),
							v && /* @__PURE__ */ g("div", {
								className: "e7-history",
								children: o.history.map((e) => {
									let n = e.players.find((e) => e.rid === t);
									return /* @__PURE__ */ _("div", { children: [
										/* @__PURE__ */ _("b", { children: [
											s("roundResult", { n: e.round }),
											" · ",
											s(n.role)
										] }),
										/* @__PURE__ */ g("br", {}),
										s("heart"),
										" ",
										n.hearts,
										" · ",
										s("star"),
										" ",
										n.stars,
										" · ",
										s(n.status)
									] }, e.round);
								})
							})
						]
					}, t);
				})
			}),
			/* @__PURE__ */ _("div", {
				className: "e7-over-actions",
				children: [
					/* @__PURE__ */ g("button", {
						type: "button",
						onClick: () => p(!f),
						children: s("viewField")
					}),
					r && /* @__PURE__ */ g("button", {
						type: "button",
						onClick: r,
						children: u("session.result.playAgain")
					}),
					a && /* @__PURE__ */ g("button", {
						type: "button",
						onClick: a,
						children: u("session.result.backToLobby")
					}),
					!r && !a && /* @__PURE__ */ g("p", { children: u("session.result.waitHost") })
				]
			}),
			f && /* @__PURE__ */ g("div", {
				className: "e7-over-field",
				children: /* @__PURE__ */ g(Ke, { pub: o })
			})
		]
	});
}
//#endregion
//#region src/games/eternalsevens/options.tsx
function ot({ value: e, onChange: t }) {
	let n = j.parse(e ?? {}), { label: r } = X(), i = (e) => t({
		...n,
		...e
	});
	return /* @__PURE__ */ _("div", { children: [
		/* @__PURE__ */ g(b, {
			title: r("level"),
			children: [
				"beginner",
				"standard",
				"expert",
				"pro"
			].map((e) => /* @__PURE__ */ g(y, {
				name: "e7-level",
				value: e,
				checked: n.level === e,
				onChange: () => i({ level: e }),
				label: r(e)
			}, e))
		}),
		n.level === "standard" && /* @__PURE__ */ g(ee, {
			label: r("expanded"),
			checked: n.expanded,
			onChange: () => i({ expanded: !n.expanded })
		}),
		(n.level === "beginner" || n.level === "standard") && /* @__PURE__ */ g(ee, {
			label: r("dragonOption"),
			checked: n.dragon,
			onChange: () => i({ dragon: !n.dragon })
		}),
		n.level === "pro" && /* @__PURE__ */ g(b, {
			title: r("rolePool"),
			children: ["intro", "all"].map((e) => /* @__PURE__ */ g(y, {
				name: "e7-pool",
				value: e,
				label: r(e),
				checked: n.rolePool === e,
				onChange: () => i({ rolePool: e })
			}, e))
		})
	] });
}
//#endregion
//#region src/games/eternalsevens/guide.tsx
function st() {
	let { label: e } = X();
	return /* @__PURE__ */ _("article", {
		className: "e7-guide",
		children: [
			/* @__PURE__ */ g("h2", { children: e("roleAbilities") }),
			[
				"red",
				"blue",
				"green",
				"yellow",
				...C
			].map((t) => /* @__PURE__ */ _("details", { children: [/* @__PURE__ */ g("summary", { children: e(t) }), /* @__PURE__ */ _("div", {
				className: "e7-guide-entry",
				children: [/* @__PURE__ */ g("img", {
					src: Z(t),
					alt: ""
				}), /* @__PURE__ */ g(Je, { text: e(`power_${t}`) })]
			})] }, t)),
			/* @__PURE__ */ g("h2", { children: e("eternalEffects") }),
			S.map((t) => /* @__PURE__ */ _("details", { children: [/* @__PURE__ */ g("summary", { children: e(t) }), /* @__PURE__ */ _("div", {
				className: "e7-guide-entry",
				children: [/* @__PURE__ */ g("img", {
					src: Z(t),
					alt: ""
				}), /* @__PURE__ */ g("p", { children: e(`effect_${t}`) })]
			})] }, t))
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/eternalsevens/entry.tsx
var ct = {
	definition: Be,
	View: Qe,
	bot: nt,
	fx: it,
	OverView: at,
	Options: ot,
	Guide: st,
	locales: {
		zh: {
			roleAbilities: "角色能力",
			eternalEffects: "永恒牌效果",
			name: "永恒七",
			desc: "让四色生命依序连结，借永恒者之力争取星辰与爱心。",
			errAction: "当前无法执行此操作，请重新选择。",
			level: "游戏等级",
			beginner: "休闲 · 初级",
			standard: "休闲 · 标准",
			expert: "玩家 · 专家",
			pro: "玩家 · 职业",
			expanded: "使用全部永恒牌",
			dragonOption: "使用交换手牌的龙",
			rolePool: "职业角色",
			intro: "入门五组角色",
			all: "随机全部角色",
			red: "热情观察者",
			blue: "冷静观察者",
			green: "和谐观察者",
			yellow: "挑战观察者",
			purple: "紫色",
			rare: "稀有牌",
			phoenix: "凤凰",
			fairy: "妖精",
			witch: "魔女",
			vampire: "吸血鬼",
			minotaur: "米诺陶洛斯",
			medusa: "美杜莎",
			pegasus: "天马",
			barong: "巴龙",
			yeti: "雪人",
			cyclops: "独眼巨人",
			king: "狮王",
			mermaid: "人鱼",
			ghost: "幽灵",
			kraken: "克拉肯",
			skeleton: "骷髅",
			mummy: "木乃伊",
			kyubi: "九尾狐",
			djinn: "灯神",
			kappa: "河童",
			golem: "魔像",
			dragon: "龙",
			colorRed: "红色",
			colorBlue: "蓝色",
			colorGreen: "绿色",
			colorYellow: "黄色",
			round: "第 {{n}} 轮",
			yourTurn: "你的回合",
			waiting: "等待{{name}}",
			resolving: "永恒之力正在流转",
			hand: "你的手牌",
			cards: "{{n}} 张手牌",
			extra: "追加出牌标记",
			heart: "爱心",
			star: "星辰",
			passDiscs: "剩余跳过圆片",
			rareSupply: "稀有牌供给",
			passRare: "获得 1 张稀有牌",
			passDiscard: "弃置 1 张手牌",
			passEternal: "发动永恒行动",
			passDragon: "选择龙行动",
			passMust: "放置 {{n}} 个必出标记",
			passMove: "移动 1 个星块",
			passRetrieve: "拿取 1 张弃牌",
			passExchange: "指定颜色交换手牌",
			passTens: "收取所有 10 并归还等量手牌",
			passDrain: "所有玩家移除 2 个追加标记",
			passPrepared: "准备时已使用",
			gainExtra: "先获得 {{n}} 个追加标记",
			sharedPass: "公共位置",
			endTurn: "结束回合",
			hardPass: "退出本轮",
			eliminate: "确认淘汰",
			nextRound: "进入第二轮",
			nextWaiting: "等待其他玩家确认",
			choose_role: "选择本轮永恒者",
			choose_color: "指定交换颜色",
			choose_target: "选择一位玩家",
			choose_gift: "选择赠送的手牌",
			choose_return: "选择归还的手牌",
			choose_transfer: "选择传出的手牌",
			choose_collect: "选择交出的手牌",
			choose_discard: "选择弃置的手牌",
			choose_must: "选择必出标记位置",
			choose_move: "选择要移动的星块",
			choose_retrieve: "选择拿取的弃牌",
			choose_dragon: "选择一项龙行动",
			selectCard: "选择手牌，再选择场上的落点",
			selectedCard: "请选择高亮落点",
			chooseAcquisition: "选取一张，另一张交给对手",
			draw: "公共牌堆",
			instant: "即时永恒",
			continuous: "持续永恒",
			dragonForbidden: "禁制之龙",
			dragonPlayable: "顺行之龙",
			dragonChoice: "抉择之龙",
			dragon_fairy: "禁止打出 3 和 8",
			dragon_mermaid: "禁止打出 1 和 10",
			dragon_vampire: "禁止打出紫牌",
			dragon_ghost: "翻开全部弃牌",
			dragon_discard: "弃置 1 张手牌",
			dragon_dragon: "禁止使用追加标记",
			dragon_kraken: "禁止弃置手牌",
			dragon_hard: "禁止退出本轮",
			dragon_must: "放置 1 个必出标记",
			dragon_cyclops: "优先打出稀有牌",
			dragon_mummy: "向左传递 1 张手牌",
			dragon_extra: "获得 1 个追加标记",
			dragon_heart: "获得 1 颗爱心",
			dragon_moveAll: "移动全部星块",
			dragon_hardBonus: "退出时每个剩余圆片获得 1 颗爱心",
			dragon_outBonus: "出完时每个剩余圆片获得 1 颗爱心",
			dragonAvailable: "尚未发动",
			cube: "龙方块 {{n}}",
			out: "已出完",
			hard: "已退出",
			eliminated: "已淘汰",
			active: "对局中",
			remaining: "剩余 {{n}} 回合",
			overview: "永恒者能力",
			close: "关闭",
			log: "行动记录",
			discards: "弃牌漩涡",
			hidden: "牌背",
			field: "生命之场",
			blocked: "星块：该行最后填入",
			must: "必出标记",
			roundOver: "第一轮结束",
			resultTitle: "永恒世界已成形",
			winner: "本局获胜",
			rank: "第 {{n}} 名",
			roundResult: "第 {{n}} 轮记录",
			viewField: "回看场地",
			log_play: "{{name}}打出{{card}}",
			log_pass: "{{name}}使用跳过行动",
			log_instant: "{{name}}发动{{detail}}",
			log_continuous: "{{name}}唤来{{detail}}",
			log_dragon: "{{name}}选择{{detail}}",
			log_choice: "{{name}}完成选择",
			log_star: "{{name}}完成一行，获得星块",
			log_out: "{{name}}出完手牌",
			log_hard: "{{name}}退出本轮",
			log_eliminated: "{{name}}被淘汰",
			log_first: "{{name}}获得首位奖励",
			log_acquire: "{{name}}分配公共牌",
			power_red: "· 标准等级：使用角色板上标有追加出牌奖励的稀有牌行动或永恒行动时，获得对应的追加出牌标记。\n· 专家等级：出完手牌时，获得2颗星辰，并按每个剩余未使用的跳过圆片获得2点爱心。\n· 专家等级：退出本轮时，获得3点爱心，并按手中每张红牌额外获得1点爱心。",
			power_blue: "· 出完手牌时，获得5点爱心，并按每两个剩余未使用的跳过圆片获得1颗星辰。\n· 退出本轮时，按手中每张蓝牌获得2点爱心。\n· 获得星块时，额外获得1颗星辰。",
			power_green: "· 出完手牌时，获得1颗星辰和3点爱心，并按每两个剩余未使用的跳过圆片额外获得1颗星辰。\n· 退出本轮时，按手中每张绿牌获得1点爱心。\n· 获得星块时，获得4点爱心。",
			power_yellow: "· 出完手牌时，获得1颗星辰和4点爱心；如果没有剩余未使用的跳过圆片，再获得1颗星辰。\n· 退出本轮时，按手中每张黄牌获得1点爱心；如果没有剩余未使用的跳过圆片，再获得4点爱心。\n· 获得星块时，获得4点爱心。",
			power_phoenix: "· 打出印有6或8的普通主牌时，获得1个追加出牌标记。\n· 出完手牌时，获得2颗星辰，并按每个剩余的追加出牌标记获得2点爱心。\n· 退出本轮时，获得3点爱心，并按手中每张红牌额外获得1点爱心。",
			power_fairy: "· 打出印有1或4的普通主牌时，获得1个追加出牌标记。\n· 出完手牌时，获得1颗星辰和4点爱心。\n· 出完手牌或退出本轮时，按每两个剩余未使用的跳过圆片额外获得1颗星辰。\n· 退出本轮时，按手中每张绿牌获得1点爱心。",
			power_witch: "· 出牌时可以忽略落点上的禁制标记。执行龙行动时，可以在禁制之龙当前同一面的禁制位置之间移动。\n· 准备阶段，将禁制之龙设为禁止打出3和8的位置；这不会移除手牌中的3或8。\n· 出完手牌时，获得1颗星辰和3点爱心。\n· 以1张紫牌和1张稀有牌退出本轮时，获得1颗星辰。\n· 任何玩家退出本轮时，你获得2点爱心。",
			power_vampire: "· 出牌时可以忽略落点上的禁制标记。执行龙行动时，可以在禁制之龙当前同一面的禁制位置之间移动。\n· 准备阶段，将禁制之龙设为禁止打出3和8的位置；这不会移除手牌中的3或8。\n· 出完手牌时，获得1颗星辰和3点爱心。\n· 以2张紫牌退出本轮时，获得1颗星辰。\n· 任何玩家退出本轮时，你获得2点爱心。",
			power_minotaur: "· 准备阶段，获得1个追加出牌标记。\n· 出完手牌时，获得1颗星辰和4点爱心。\n· 退出本轮时，获得3点爱心。\n· 获得星块时，获得2点爱心。",
			power_medusa: "· 准备阶段，获得1个追加出牌标记。\n· 出完手牌时，获得1颗星辰和4点爱心。\n· 退出本轮时，获得3点爱心。\n· 获得星块时，获得2点爱心。",
			power_pegasus: "· 每回合最多连续打出2张牌，不能使用追加出牌标记。\n· 仅剩1张手牌时，才可以退出本轮。\n· 出完手牌时，获得6点爱心，并按每个剩余未使用的跳过圆片额外获得1点爱心。\n· 退出本轮时，获得3点爱心。",
			power_barong: "· 每回合可以连续打出2张同色牌，出牌时可以忽略落点上的禁制标记，不能使用追加出牌标记。\n· 出完手牌时，获得6点爱心；如果没有剩余未使用的跳过圆片，再获得1颗星辰。\n· 退出本轮时，按手中每张紫牌获得1点爱心；如果没有剩余未使用的跳过圆片，再获得3点爱心。",
			power_yeti: "· 出完手牌时，获得1颗星辰和4点爱心；如果没有剩余未使用的跳过圆片，再获得2点爱心。\n· 退出本轮时，获得2点爱心，并按手中每张稀有牌额外获得2点爱心；如果没有剩余未使用的跳过圆片，再获得1颗星辰。",
			power_cyclops: "· 仅剩1张手牌时，才可以退出本轮。\n· 出完手牌或退出本轮时，获得1颗星辰和4点爱心；如果没有剩余未使用的跳过圆片，再获得1颗星辰和2点爱心。\n· 获得星块时，获得4点爱心。",
			power_king: "· 准备阶段，获得1张稀有牌。打出稀有牌时，获得1个追加出牌标记。\n· 出完手牌时，获得2颗星辰，并按每个剩余未使用的跳过圆片获得1点爱心。\n· 退出本轮时，按手中每张黄牌获得2点爱心。\n· 获得星块时，获得2点爱心。",
			power_mermaid: "· 打出印有5或7的普通主牌时，获得1个追加出牌标记。\n· 出完手牌时，获得4点爱心；如果持有至少2个追加出牌标记，再获得1颗星辰。\n· 退出本轮时，按每个剩余未使用的跳过圆片和手中每张蓝牌各获得1点爱心。\n· 获得星块时，额外获得1颗星辰。",
			power_ghost: "· 准备阶段，弃置2张手牌。你可以随时查看暗置的弃牌。\n· 出完手牌时，获得1颗星辰和3点爱心。\n· 退出本轮时，获得2点爱心，并按手中每张紫牌额外获得1点爱心。\n· 获得星块时，获得2点爱心。",
			power_kraken: "· 准备阶段，弃置1张手牌。你可以随时查看暗置的弃牌。\n· 打出印有10的普通主牌时，获得1点爱心。\n· 出完手牌时，获得1颗星辰；以2张印有10的普通主牌退出本轮时，也获得1颗星辰。\n· 出完手牌或退出本轮时，按每个剩余未使用的跳过圆片获得1点爱心。\n· 获得星块时，获得2点爱心。",
			power_skeleton: "· 准备阶段，使用1个跳过圆片，并获得1个追加出牌标记。\n· 打出紫牌后，如果仍有手牌，须将1张手牌赠送给另一位玩家。\n· 出完手牌时，获得1颗星辰和4点爱心。\n· 退出本轮时，获得3点爱心。\n· 出完手牌或退出本轮时，如果没有剩余未使用的跳过圆片，再获得1颗星辰。",
			power_mummy: "· 准备阶段，使用1个跳过圆片，并获得1个追加出牌标记。\n· 出牌时可以忽略落点上的禁制标记；在禁制位置出牌时，获得1点爱心。\n· 出完手牌时，获得1颗星辰和2点爱心。\n· 退出本轮时，获得2点爱心；如果没有剩余未使用的跳过圆片，再获得1颗星辰。\n· 获得星块时，获得2点爱心。",
			power_kyubi: "· 最多可以持有3个追加出牌标记。出牌时可以忽略落点上的禁制标记。\n· 完成一列时，获得1个追加出牌标记。\n· 出完手牌时，获得6点爱心；如果持有至少2个追加出牌标记，再获得1颗星辰。\n· 退出本轮时，按手中每张稀有牌获得2点爱心，并按每个剩余的追加出牌标记获得1点爱心。",
			power_djinn: "· 手牌为1至3张时，可以退出本轮。\n· 任何玩家覆盖稀有牌时，你将被覆盖的稀有牌收回手中。\n· 完成一列时，获得1个追加出牌标记。\n· 出完手牌时，获得1颗星辰和4点爱心。\n· 退出本轮时，按手中每张稀有牌获得2点爱心，并按每张紫牌获得1点爱心；如果恰好持有2张稀有牌，再获得1颗星辰。",
			power_kappa: "· 出完手牌时，获得1颗星辰和2点爱心，并按每个剩余的追加出牌标记额外获得1点爱心。\n· 退出本轮时，按手中每张稀有牌获得2点爱心；如果没有剩余未使用的跳过圆片，再获得1颗星辰。\n· 获得星块时，获得2点爱心。",
			power_golem: "· 每次发动龙行动时，必须连续执行两次龙行动。\n· 出完手牌时，获得1颗星辰和2点爱心，并按每个剩余的追加出牌标记和每个剩余未使用的跳过圆片各额外获得1点爱心。\n· 退出本轮时，获得3点爱心。",
			effect_phoenix: "当前玩家再进行一个回合。",
			effect_skeleton: "当前玩家赠送其他玩家 1 张手牌。",
			effect_barong: "指定一种颜色，与持有该颜色的其他玩家交换 1 张牌；双人时最多交换 2 张。",
			effect_mummy: "所有仍在对局中的玩家先各选 1 张手牌，再同时传给左侧玩家。",
			effect_kyubi: "跳过下一位玩家的回合。",
			effect_minotaur: "移动场上全部星块至另一端。",
			effect_ghost: "翻开现有的全部弃牌。",
			effect_dragon: "与其他玩家交换全部手牌；两人或三人时双方各传出最多 3 张。",
			effect_king: "获得 1 张稀有牌。",
			effect_kappa: "所有玩家获得 1 个追加标记。",
			effect_yeti: "所有玩家各弃置 1 张手牌。",
			effect_kraken: "禁止弃置手牌；仍可消耗跳过圆片。",
			effect_cyclops: "打出牌时必须优先选择可出的稀有牌。",
			effect_djinn: "覆盖稀有牌的玩家必须将该稀有牌收回手中。",
			effect_pegasus: "每回合最多连续打出 2 张牌，不能使用追加标记。",
			effect_mermaid: "禁止打出 1 和 10，稀有牌不受影响。",
			effect_fairy: "禁止打出 3 和 8，稀有牌不受影响。",
			effect_witch: "禁止打出稀有牌。",
			effect_medusa: "当前玩家放置 1 个必出标记。",
			effect_golem: "再次执行最近一次即时永恒行动。",
			effect_vampire: "禁止打出紫牌，稀有牌不受影响。",
			rules: "目标：\n· 休闲模式进行一轮，以出完手牌或获得两个星块的先后决定名次。\n· 玩家模式进行两轮；四人时目标为 20点爱心或4颗星辰，两三人时为 21点爱心或5颗星辰。\n第二轮被淘汰者排在其他玩家之后。\n准备：\n共 48 张主牌：红、蓝、绿、黄各 1 至 10，以及 8 张紫牌。四人每人 12 张，三人每人 16 张。双人每人 16 张，其余组成公共牌堆，先暗弃 2 张，再展示 2 张。另有 4 张稀有牌。初级使用 3 个跳过圆片，其余等级使用 4 个。使用职业等级时，在查看手牌后选择角色，第二轮改用同组背面角色。\n流程：\n回合中选择出牌或使用一个尚未使用的跳过位置。双人还可从公共展示牌中选择一张加入手牌，另一张交给对手，然后补充两张展示牌并结束回合。不能出牌、跳过或拿取公共牌时淘汰，手牌洗混后平均分给仍在对局中的玩家，将无法平均分配的剩余卡牌正面朝上弃置。\n每行首张牌必须为 4、5、6 或 7；之后按颜色和数字紧邻接龙。紫牌只能位于 1 的左侧或 10 的右侧，两端互相连通。首次放入一端紫牌时，在另一方向的前沿放置星块；该位置必须留到本行最后填入。完成一行获得星块。稀有牌可代替任何合法位置，之后可以被对应主牌覆盖；稀有牌不能覆盖其他牌。\n印有2或9的普通主牌打出后发动即时永恒行动，随后结束回合；以该牌出完时不发动。稀有牌代替 2 或 9 不发动。跳过可获得稀有牌、暗弃一张、发动持续永恒或执行玩家板行动；每位置限用一次。持续效果保留到下一张持续永恒出现。\n标准及玩家等级可使用追加标记继续出牌；每人上限为 2，九尾狐上限为 3。跳过回合或打出印有2或9的普通主牌后，不能追加出牌。必出标记要求优先打出对应的合法主牌；稀有牌本身不会因必出标记被强制打出。若同时存在稀有牌优先效果，两类牌均可选择。\n玩家模式：\n全部永恒行动改为龙行动。\n· 禁制之龙与顺行之龙按顺序推进。\n· 抉择之龙可选择尚未移动的任一方块，并执行对应行动。\n抉择之龙背面的退出、出完奖励对当时颜色已露出者生效。\n出完或退出时按角色获得奖励。\n可以在回合开始或结束时退出，手牌数量须满足以下条件：\n· 通常情况下，退出时手牌不能超过2张。\n· 天马和独眼巨人的退出手牌上限为1张。\n· 灯神的退出手牌上限为3张。\n首位出完手牌或退出的玩家，在第一轮获得1点爱心，在第二轮获得1颗星辰和1点爱心。出完后其他玩家剩一回合，退出后剩两回合；再次出完可缩为一回合。限时结束仍未出完或退出者淘汰，将所有手牌正面朝上弃置，爱心归零；若在第一轮被淘汰，则额外获得1颗星辰。双人最后回合可无限连续出牌，但 2 或 9 与跳过仍结束回合。\n结算：\n第二轮保留第一轮的爱心与星辰，以最低爱心者先手，平手时心形标记较晚到达该格者先手。最终先比较达到爱心目标者，再比较达到星辰目标且爱心超过4点的玩家，再比较爱心。适用的平手依次比较星辰与心形先后；较早到达者优先。详细角色能力与永恒牌效果可在对局内查看。"
		},
		en: {
			roleAbilities: "Character abilities",
			eternalEffects: "Eternal card effects",
			name: "Eternal Sevens",
			desc: "Connect four colors of life and call on the Eternals to earn stars and hearts.",
			errAction: "This action is unavailable. Please choose again.",
			level: "Game level",
			beginner: "Casual · Beginner",
			standard: "Casual · Standard",
			expert: "Gamer · Expert",
			pro: "Gamer · Pro",
			expanded: "Use all Eternal cards",
			dragonOption: "Include the hand-swapping Dragon",
			rolePool: "Pro characters",
			intro: "Introductory five pairs",
			all: "Random characters from all pairs",
			red: "Passion Observer",
			blue: "Calm Observer",
			green: "Harmony Observer",
			yellow: "Challenge Observer",
			purple: "Purple",
			rare: "Rare card",
			phoenix: "Phoenix",
			fairy: "Fairy",
			witch: "Witch",
			vampire: "Vampire",
			minotaur: "Minotaur",
			medusa: "Medusa",
			pegasus: "Pegasus",
			barong: "Barong",
			yeti: "Yeti",
			cyclops: "Cyclops",
			king: "King",
			mermaid: "Mermaid",
			ghost: "Ghost",
			kraken: "Kraken",
			skeleton: "Skeleton",
			mummy: "Mummy",
			kyubi: "Kyubi",
			djinn: "Djinn",
			kappa: "Kappa",
			golem: "Golem",
			dragon: "Dragon",
			colorRed: "Red",
			colorBlue: "Blue",
			colorGreen: "Green",
			colorYellow: "Yellow",
			round: "Round {{n}}",
			yourTurn: "Your turn",
			waiting: "Waiting for {{name}}",
			resolving: "Eternal powers are resolving",
			hand: "Your hand",
			cards: "{{n}} cards",
			extra: "Additional Play Tokens",
			heart: "Hearts",
			star: "Stars",
			passDiscs: "Unused pass discs",
			rareSupply: "Rare card supply",
			passRare: "Gain 1 Rare card",
			passDiscard: "Discard 1 card",
			passEternal: "Activate an Eternal action",
			passDragon: "Choose a Dragon action",
			passMust: "Place {{n}} Must Play Tokens",
			passMove: "Move 1 Star Block",
			passRetrieve: "Take 1 discarded card",
			passExchange: "Declare a color and exchange cards",
			passTens: "Collect all 10s and return the same number of cards",
			passDrain: "All players lose 2 Additional Play Tokens",
			passPrepared: "Used during preparation",
			gainExtra: "First gain {{n}} Additional Play Tokens",
			sharedPass: "Shared space",
			endTurn: "End turn",
			hardPass: "Hard Pass",
			eliminate: "Confirm elimination",
			nextRound: "Begin round 2",
			nextWaiting: "Waiting for the other players",
			choose_role: "Choose your Eternal for this round",
			choose_color: "Declare a color to exchange",
			choose_target: "Choose another player",
			choose_gift: "Choose a card to give",
			choose_return: "Choose a card to return",
			choose_transfer: "Choose a card to pass",
			choose_collect: "Choose a card to hand over",
			choose_discard: "Choose a card to discard",
			choose_must: "Choose a Must Play space",
			choose_move: "Choose a Star Block to move",
			choose_retrieve: "Choose a discarded card to take",
			choose_dragon: "Choose a Dragon action",
			selectCard: "Choose a card, then its space on the Field",
			selectedCard: "Choose a highlighted space",
			chooseAcquisition: "Take one card; the other goes to your opponent",
			draw: "Common deck",
			instant: "Instant Eternal",
			continuous: "Continuous Eternal",
			dragonForbidden: "Forbidden Dragon",
			dragonPlayable: "Playable Dragon",
			dragonChoice: "Choice Based Dragon",
			dragon_fairy: "No 3s or 8s",
			dragon_mermaid: "No 1s or 10s",
			dragon_vampire: "No Purple cards",
			dragon_ghost: "Reveal all discarded cards",
			dragon_discard: "Discard 1 card",
			dragon_dragon: "No Additional Play Tokens",
			dragon_kraken: "No discarding from hand",
			dragon_hard: "No Hard Pass",
			dragon_must: "Place 1 Must Play Token",
			dragon_cyclops: "Play Rare cards first",
			dragon_mummy: "Pass 1 card to the left",
			dragon_extra: "Gain 1 Additional Play Token",
			dragon_heart: "Gain 1 heart",
			dragon_moveAll: "Move all Star Blocks",
			dragon_hardBonus: "Hard Pass: 1 heart per unused pass disc",
			dragon_outBonus: "Go Out: 1 heart per unused pass disc",
			dragonAvailable: "Not activated",
			cube: "Dragon cube {{n}}",
			out: "Gone Out",
			hard: "Hard Passed",
			eliminated: "Eliminated",
			active: "Playing",
			remaining: "{{n}} turns left",
			overview: "Eternal abilities",
			close: "Close",
			log: "Action log",
			discards: "Discard Vortex",
			hidden: "Face down",
			field: "Field of life",
			blocked: "Star Block: fill this space last",
			must: "Must Play Token",
			roundOver: "Round 1 complete",
			resultTitle: "The Eternal World takes shape",
			winner: "Winner",
			rank: "Place {{n}}",
			roundResult: "Round {{n}} record",
			viewField: "Review the Field",
			log_play: "{{name}} played {{card}}",
			log_pass: "{{name}} used a pass action",
			log_instant: "{{name}} activated {{detail}}",
			log_continuous: "{{name}} revealed {{detail}}",
			log_dragon: "{{name}} chose {{detail}}",
			log_choice: "{{name}} completed a choice",
			log_star: "{{name}} completed a row and gained a Star Block",
			log_out: "{{name}} went out",
			log_hard: "{{name}} Hard Passed",
			log_eliminated: "{{name}} was eliminated",
			log_first: "{{name}} gained the First Bonus",
			log_acquire: "{{name}} distributed the common cards",
			power_red: "· At Standard level, a Rare or Eternal action marked with an Additional Play reward grants the indicated Additional Play Tokens.\n· At Expert level, when you Go Out, gain 2 stars and 2 hearts for each unused pass disc.\n· At Expert level, when you Hard Pass, gain 3 hearts plus 1 heart for each red card in your hand.",
			power_blue: "· When you Go Out, gain 5 hearts and 1 star for every 2 unused pass discs.\n· When you Hard Pass, gain 2 hearts for each blue card in your hand.\n· When you gain a Star Block, gain 1 additional star.",
			power_green: "· When you Go Out, gain 1 star and 3 hearts, plus 1 additional star for every 2 unused pass discs.\n· When you Hard Pass, gain 1 heart for each green card in your hand.\n· When you gain a Star Block, gain 4 hearts.",
			power_yellow: "· When you Go Out, gain 1 star and 4 hearts. If you have no unused pass discs, gain 1 additional star.\n· When you Hard Pass, gain 1 heart for each yellow card in your hand. If you have no unused pass discs, gain 4 additional hearts.\n· When you gain a Star Block, gain 4 hearts.",
			power_phoenix: "· When you play an ordinary card printed with a 6 or 8, gain 1 Additional Play Token.\n· When you Go Out, gain 2 stars and 2 hearts for each Additional Play Token you still hold.\n· When you Hard Pass, gain 3 hearts plus 1 heart for each red card in your hand.",
			power_fairy: "· When you play an ordinary card printed with a 1 or 4, gain 1 Additional Play Token.\n· When you Go Out, gain 1 star and 4 hearts.\n· When you Go Out or Hard Pass, gain 1 additional star for every 2 unused pass discs.\n· When you Hard Pass, gain 1 heart for each green card in your hand.",
			power_witch: "· You may ignore placement X Tokens. When taking a Dragon action, you may move between X spaces on the current side of the Forbidden Dragon.\n· During preparation, set the Forbidden Dragon to the space that forbids 3s and 8s. This does not remove any 3s or 8s from your hand.\n· When you Go Out, gain 1 star and 3 hearts.\n· When you Hard Pass with 1 Purple card and 1 Rare card, gain 1 star.\n· Whenever any player Hard Passes, you gain 2 hearts.",
			power_vampire: "· You may ignore placement X Tokens. When taking a Dragon action, you may move between X spaces on the current side of the Forbidden Dragon.\n· During preparation, set the Forbidden Dragon to the space that forbids 3s and 8s. This does not remove any 3s or 8s from your hand.\n· When you Go Out, gain 1 star and 3 hearts.\n· When you Hard Pass with 2 Purple cards, gain 1 star.\n· Whenever any player Hard Passes, you gain 2 hearts.",
			power_minotaur: "· During preparation, gain 1 Additional Play Token.\n· When you Go Out, gain 1 star and 4 hearts.\n· When you Hard Pass, gain 3 hearts.\n· When you gain a Star Block, gain 2 hearts.",
			power_medusa: "· During preparation, gain 1 Additional Play Token.\n· When you Go Out, gain 1 star and 4 hearts.\n· When you Hard Pass, gain 3 hearts.\n· When you gain a Star Block, gain 2 hearts.",
			power_pegasus: "· You may play up to 2 consecutive cards per turn and cannot use Additional Play Tokens.\n· You may Hard Pass only when you have exactly 1 card in your hand.\n· When you Go Out, gain 6 hearts plus 1 heart for each unused pass disc.\n· When you Hard Pass, gain 3 hearts.",
			power_barong: "· You may play up to 2 consecutive cards of the same color per turn and may ignore placement X Tokens. You cannot use Additional Play Tokens.\n· When you Go Out, gain 6 hearts. If you have no unused pass discs, gain 1 additional star.\n· When you Hard Pass, gain 1 heart for each Purple card in your hand. If you have no unused pass discs, gain 3 additional hearts.",
			power_yeti: "· When you Go Out, gain 1 star and 4 hearts. If you have no unused pass discs, gain 2 additional hearts.\n· When you Hard Pass, gain 2 hearts plus 2 hearts for each Rare card in your hand. If you have no unused pass discs, gain 1 star.",
			power_cyclops: "· You may Hard Pass only when you have exactly 1 card in your hand.\n· When you Go Out or Hard Pass, gain 1 star and 4 hearts. If you have no unused pass discs, gain 1 additional star and 2 additional hearts.\n· When you gain a Star Block, gain 4 hearts.",
			power_king: "· During preparation, gain 1 Rare card. When you play a Rare card, gain 1 Additional Play Token.\n· When you Go Out, gain 2 stars and 1 heart for each unused pass disc.\n· When you Hard Pass, gain 2 hearts for each yellow card in your hand.\n· When you gain a Star Block, gain 2 hearts.",
			power_mermaid: "· When you play an ordinary card printed with a 5 or 7, gain 1 Additional Play Token.\n· When you Go Out, gain 4 hearts. If you hold at least 2 Additional Play Tokens, gain 1 star.\n· When you Hard Pass, gain 1 heart for each unused pass disc and 1 heart for each blue card in your hand.\n· When you gain a Star Block, gain 1 additional star.",
			power_ghost: "· During preparation, discard 2 cards from your hand. You may inspect face-down discards at any time.\n· When you Go Out, gain 1 star and 3 hearts.\n· When you Hard Pass, gain 2 hearts plus 1 heart for each Purple card in your hand.\n· When you gain a Star Block, gain 2 hearts.",
			power_kraken: "· During preparation, discard 1 card from your hand. You may inspect face-down discards at any time.\n· When you play an ordinary card printed with a 10, gain 1 heart.\n· When you Go Out, gain 1 star. When you Hard Pass with 2 ordinary cards printed with a 10, also gain 1 star.\n· When you Go Out or Hard Pass, gain 1 heart for each unused pass disc.\n· When you gain a Star Block, gain 2 hearts.",
			power_skeleton: "· During preparation, use 1 pass disc and gain 1 Additional Play Token.\n· After you play a Purple card, if you still have cards in your hand, give 1 of them to another player.\n· When you Go Out, gain 1 star and 4 hearts.\n· When you Hard Pass, gain 3 hearts.\n· When you Go Out or Hard Pass with no unused pass discs, gain 1 additional star.",
			power_mummy: "· During preparation, use 1 pass disc and gain 1 Additional Play Token.\n· You may ignore placement X Tokens. When you play a card on an X space, gain 1 heart.\n· When you Go Out, gain 1 star and 2 hearts.\n· When you Hard Pass, gain 2 hearts. If you have no unused pass discs, gain 1 star.\n· When you gain a Star Block, gain 2 hearts.",
			power_kyubi: "· You may hold up to 3 Additional Play Tokens and may ignore placement X Tokens.\n· When you complete a column, gain 1 Additional Play Token.\n· When you Go Out, gain 6 hearts. If you hold at least 2 Additional Play Tokens, gain 1 star.\n· When you Hard Pass, gain 2 hearts for each Rare card in your hand plus 1 heart for each Additional Play Token you still hold.",
			power_djinn: "· You may Hard Pass with 1 to 3 cards in your hand.\n· Whenever any player covers a Rare card, take the covered Rare card into your hand.\n· When you complete a column, gain 1 Additional Play Token.\n· When you Go Out, gain 1 star and 4 hearts.\n· When you Hard Pass, gain 2 hearts for each Rare card and 1 heart for each Purple card in your hand. If you hold exactly 2 Rare cards, gain 1 star.",
			power_kappa: "· When you Go Out, gain 1 star and 2 hearts, plus 1 heart for each Additional Play Token you still hold.\n· When you Hard Pass, gain 2 hearts for each Rare card in your hand. If you have no unused pass discs, gain 1 star.\n· When you gain a Star Block, gain 2 hearts.",
			power_golem: "· Whenever you activate a Dragon action, you must perform 2 consecutive Dragon actions.\n· When you Go Out, gain 1 star and 2 hearts, plus 1 heart for each Additional Play Token you still hold and 1 heart for each unused pass disc.\n· When you Hard Pass, gain 3 hearts.",
			effect_phoenix: "The current player takes another turn.",
			effect_skeleton: "Give another player 1 card from your hand.",
			effect_barong: "Declare a color and exchange 1 card with each other player holding it; up to 2 cards in a two-player game.",
			effect_mummy: "All active players choose 1 card before passing them simultaneously to the left.",
			effect_kyubi: "Skip the next player’s turn.",
			effect_minotaur: "Move every Star Block to the opposite end.",
			effect_ghost: "Reveal all existing discards.",
			effect_dragon: "Swap hands with another player; with two or three players, each passes up to 3 cards instead.",
			effect_king: "Gain 1 Rare card.",
			effect_kappa: "All players gain 1 Additional Play Token.",
			effect_yeti: "Each player discards 1 card.",
			effect_kraken: "Players cannot discard cards from their hands, but may still use pass discs.",
			effect_cyclops: "Prioritize any playable Rare card.",
			effect_djinn: "A player covering a Rare card must take it into their hand.",
			effect_pegasus: "Play up to 2 cards per turn. Additional Play Tokens cannot be used.",
			effect_mermaid: "Players cannot play ordinary cards printed with a 1 or 10. Rare cards are unaffected.",
			effect_fairy: "Players cannot play ordinary cards printed with a 3 or 8. Rare cards are unaffected.",
			effect_witch: "Players cannot play Rare cards.",
			effect_medusa: "Place 1 Must Play Token.",
			effect_golem: "Repeat the most recent Instant Eternal action.",
			effect_vampire: "Players cannot play Purple cards. Rare cards are unaffected.",
			rules: "Objective:\n· Casual mode lasts one round. Rank players by Going Out, either emptying their hand or gaining two Star Blocks.\n· Gamer mode lasts two rounds: aim for 20 hearts or 4 stars with four players, or 21 hearts or 5 stars with two or three.\nPlayers eliminated in round 2 rank behind the others.\nSetup:\nThe 48-card deck has red, blue, green and yellow 1–10, plus 8 Purple cards. Deal 12 each with four players, or 16 with three. With two players, deal 16 each, discard 2 face down from the remainder and reveal 2 common cards. There are also 4 Rare cards. Beginner uses 3 pass discs; other levels use 4. In Pro, choose characters after seeing your hand and use the opposite side of each pair in round 2.\nTurns:\nPlay a card or use an unused pass space. With two players, you may instead take one common card and give the other to your opponent, reveal two replacements and end your turn. If none of these actions is possible, you are eliminated: shuffle and divide your hand equally among active players, discarding the remainder face up.\nStart each row with a 4, 5, 6 or 7, then extend adjacently in matching color and number. Purple cards go before 1 or after 10; the ends link together. The first Purple places a Star Block at the opposite frontier. Fill that space last to complete the row and gain the Star Block. Rare cards substitute for any legal space and may later be covered by the matching ordinary card; Rare cards cannot cover cards.\nA printed 2 or 9 activates an Instant Eternal and ends your turn, unless it makes you Go Out. A Rare on a 2 or 9 does not activate it. Passing may gain a Rare card, discard one card face down, activate a Continuous Eternal or use a board action. Each space is used once. A Continuous effect remains until replaced.\nStandard and Gamer levels allow Additional Play Tokens for extra cards. Hold up to 2, or 3 as Kyubi. Passing and printed 2s or 9s end the turn. Must Play Tokens prioritize the matching playable ordinary card, never force a Rare card. If Rare-first is also active, either priority may be chosen.\nGamer mode:\nAll Eternal actions become Dragon actions.\n· Forbidden and Playable Dragon tracks advance in order.\n· Choice Based actions use any unmoved cube.\nOn its reverse, Hard Pass and Go Out bonuses apply to players whose color is revealed when they finish.\nGoing Out or Hard Passing immediately earns your character rewards. Normally Hard Pass is allowed at the start or end of your turn with at most 2 cards; Pegasus and Cyclops require 1, Djinn permits 3. The first finisher gains 1 heart in round 1, or 1 star and 1 heart in round 2. Going Out leaves the others one final turn; Hard Pass leaves two. A later Go Out reduces two to one. At expiry, unfinished players discard their entire hand face up and lose all hearts; in round 1 they also gain 1 star. In two-player final turns, any number of cards may be played, but a 2 or 9 and passing still end the turn.\nScoring:\nKeep hearts and stars between rounds. The fewest hearts starts round 2; a tie goes to the most recent arrival at that heart space. Final priority is reaching the heart target, then reaching the star target with more than 4 hearts, then most hearts. Applicable ties compare stars, then earliest arrival at the heart space. Character abilities and Eternal effects can be inspected during play."
		}
	}
};
//#endregion
export { ct as default };
