import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { botAvatarOf as r } from "@bgparty/sdk/lobby";
import { avatarNameAt as i, useI18nSettings as a, useT as o } from "@bgparty/sdk/i18n";
import { GameScreen as s } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as c } from "@bgparty/sdk/ui/phase-banner";
import { SeatBadgedAvatar as l } from "@bgparty/sdk/ui/player-strip";
import { AVATARS as u } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as d } from "@bgparty/sdk/player-colors";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { GameOverScreen as h } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/manila/meta.ts
var g = {
	id: "manila",
	tier: "beta",
	mechanics: [
		"worker-placement",
		"betting",
		"auction",
		"dice-rolling"
	],
	interactionTags: [],
	nameKey: "games.manila.name",
	descKey: "games.manila.desc",
	rulesKey: "games.manila.rules",
	icon: "⛵",
	iconImg: "games/manila.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/manila/en.pdf" },
	minPlayers: 3,
	maxPlayers: 5,
	bestPlayers: [4],
	accent: "#0e7490",
	releasedAt: "2026-10-01",
	search: {
		py: "ma ni la",
		init: "mnl"
	},
	hotseat: "open"
}, _ = [
	"ginseng",
	"nutmeg",
	"silk",
	"jade"
], v = t.enum(_), y = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("ship"),
		good: v
	}),
	t.object({
		kind: t.literal("port"),
		slot: t.int().min(0).max(2)
	}),
	t.object({
		kind: t.literal("yard"),
		slot: t.int().min(0).max(2)
	}),
	t.object({ kind: t.literal("pirate") }),
	t.object({ kind: t.literal("pilotSmall") }),
	t.object({ kind: t.literal("pilotBig") }),
	t.object({ kind: t.literal("insurance") })
]), b = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("bid"),
		amount: t.int().min(1)
	}),
	t.object({ type: t.literal("passBid") }),
	t.object({
		type: t.literal("buyShare"),
		good: v
	}),
	t.object({ type: t.literal("skipShare") }),
	t.object({
		type: t.literal("deploy"),
		goods: t.tuple([
			v,
			v,
			v
		]),
		starts: t.tuple([
			t.int().min(0).max(5),
			t.int().min(0).max(5),
			t.int().min(0).max(5)
		])
	}),
	t.object({
		type: t.literal("place"),
		spot: y
	}),
	t.object({ type: t.literal("passPlace") }),
	t.object({
		type: t.literal("mortgage"),
		good: v
	}),
	t.object({
		type: t.literal("redeem"),
		good: v
	}),
	t.object({ type: t.literal("roll") }),
	t.object({
		type: t.literal("portOrder"),
		order: t.array(t.int().min(0).max(2))
	}),
	t.object({
		type: t.literal("board"),
		ship: t.int().min(0).max(2).nullable()
	}),
	t.object({
		type: t.literal("pilotMove"),
		moves: t.array(t.object({
			ship: t.int().min(0).max(2),
			delta: t.int().min(-2).max(2)
		})).max(2)
	}),
	t.object({
		type: t.literal("raidChoose"),
		dests: t.array(t.enum(["port", "yard"])).max(3)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), x = t.string(), S = x.nullable(), C = t.object({
	good: v,
	mortgaged: t.boolean()
}), w = t.object({
	good: v,
	pos: t.int(),
	where: t.enum([
		"sea",
		"port",
		"yard"
	]),
	slot: t.int().nullable(),
	crew: t.array(t.object({
		rid: x,
		pirate: t.boolean()
	})),
	robbed: t.boolean()
}), T = t.object({
	good: v,
	outcome: t.enum([
		"port",
		"robbedPort",
		"robbedYard",
		"yard"
	]),
	slot: t.int().nullable()
}), E = t.object({
	rid: x,
	amount: t.int()
}), ee = t.object({
	voyage: t.int().min(1),
	phase: t.enum([
		"auction",
		"office",
		"place",
		"move",
		"portOrder",
		"pirateBoard",
		"pilot",
		"pirateRaid",
		"settle",
		"done"
	]),
	harbor: x.nullable(),
	market: t.record(v, t.int().min(0).max(4)),
	supply: t.record(v, t.int().min(0)),
	laidGood: v.nullable(),
	ships: t.array(w),
	ports: t.tuple([
		S,
		S,
		S
	]),
	yards: t.tuple([
		S,
		S,
		S
	]),
	pirateBoat: t.tuple([S, S]),
	pilotSmall: S,
	pilotBig: S,
	insurance: S,
	players: t.array(t.object({
		rid: x,
		cash: t.int(),
		shares: t.array(C),
		passed: t.boolean()
	})),
	active: x.nullable(),
	auction: t.object({
		high: t.int(),
		highBy: x.nullable(),
		out: t.array(x)
	}).nullable(),
	officeStep: t.enum(["share", "deploy"]).nullable(),
	placeRound: t.int().min(0),
	placeRoundsTotal: t.int(),
	leg: t.int().min(0).max(3),
	lastRoll: t.array(t.object({
		good: v,
		die: t.int().min(1).max(6),
		from: t.int(),
		to: t.int()
	})).nullable(),
	pendingArrivals: t.array(t.int()),
	boardQueue: t.array(x),
	raidQueue: t.array(t.int()),
	pilotTurn: t.enum(["small", "big"]).nullable(),
	settlement: t.object({
		ships: t.array(T),
		crewPay: t.array(E.extend({ good: v })),
		loot: t.array(E),
		portPay: t.array(E.nullable()),
		yardPay: t.array(E.nullable()),
		insurancePaid: t.int(),
		insuranceCovered: t.int(),
		risen: t.array(v),
		deltas: t.record(x, t.int()),
		gameEnd: t.boolean()
	}).nullable()
}), D = t.object({}), O = [
	0,
	5,
	10,
	20,
	30
], k = {
	ginseng: {
		profit: 18,
		seats: [
			1,
			2,
			3
		]
	},
	nutmeg: {
		profit: 24,
		seats: [
			2,
			3,
			4
		]
	},
	silk: {
		profit: 30,
		seats: [
			3,
			4,
			5
		]
	},
	jade: {
		profit: 36,
		seats: [
			3,
			4,
			5,
			5
		]
	}
}, A = [
	4,
	3,
	2
], j = [
	6,
	8,
	15
], M = [
	4,
	3,
	2
], N = [
	6,
	8,
	15
], te = 6e3, P = (e) => ({ code: e });
function ne(t, n, r) {
	let i = 0, a = e(r, i, n.length);
	i += 1;
	let o = _.flatMap((e) => [
		e,
		e,
		e
	]);
	for (let t = o.length - 1; t > 0; --t) {
		let n = e(r, i, t + 1);
		i += 1, [o[t], o[n]] = [o[n], o[t]];
	}
	let s = {}, c = {
		ginseng: 0,
		nutmeg: 0,
		silk: 0,
		jade: 0
	};
	n.forEach((e, t) => {
		let n = [o[t * 2], o[t * 2 + 1]];
		s[e] = n.map((e) => ({
			good: e,
			mortgaged: !1
		}));
		for (let e of n) c[e] += 1;
	});
	let l = {};
	for (let e of n) l[e] = 30;
	let u = {
		players: n,
		seed: r,
		rngCursor: i,
		voyage: 1,
		phase: "auction",
		harbor: null,
		auctionStarter: a,
		auction: null,
		officeStep: null,
		market: {
			ginseng: 0,
			nutmeg: 0,
			silk: 0,
			jade: 0
		},
		supply: {
			ginseng: 5 - c.ginseng,
			nutmeg: 5 - c.nutmeg,
			silk: 5 - c.silk,
			jade: 5 - c.jade
		},
		shares: s,
		cash: l,
		ships: [],
		laidGood: null,
		ports: [
			null,
			null,
			null
		],
		yards: [
			null,
			null,
			null
		],
		pirateBoat: [null, null],
		pilotSmall: null,
		pilotBig: null,
		insurance: null,
		passed: [],
		placeOrder: [],
		placeQueue: [],
		placeRound: 0,
		leg: 0,
		lastRoll: null,
		pendingArrivals: [],
		boardQueue: [],
		raidQueue: [],
		pilotTurn: null,
		settlement: null
	};
	return ie(u), { state: u };
}
function re(e, t) {
	return [...e.slice(t), ...e.slice(0, t)];
}
function ie(e) {
	e.phase = "auction";
	let t = e.harbor ? e.players.indexOf(e.harbor) : e.auctionStarter;
	e.auction = {
		order: re(e.players, t),
		idx: 0,
		high: 0,
		highBy: null,
		out: []
	};
}
var ae = (e, t) => e.shares[t].filter((e) => !e.mortgaged), F = (e, t) => ae(e, t).length * 12;
function I(e, t) {
	let n = ae(e, t).sort((t, n) => O[e.market[t.good]] - O[e.market[n.good]]), r = 0;
	for (; e.cash[t] < 0 && r < n.length;) n[r].mortgaged = !0, e.cash[t] += 12, r += 1;
}
function L(e, t, n) {
	e.cash[t] -= n, I(e, t), e.harbor = t, e.auction = null, e.phase = "office", e.officeStep = "share";
}
function R(e) {
	let t = e.auction, n = t.order.filter((e) => !t.out.includes(e));
	if (t.highBy && n.length === 1 && n[0] === t.highBy) {
		L(e, t.highBy, t.high);
		return;
	}
	if (n.length === 0) {
		L(e, e.harbor ?? t.order[0], 0);
		return;
	}
	do
		t.idx = (t.idx + 1) % t.order.length;
	while (t.out.includes(t.order[t.idx]));
}
function z(e) {
	let t = e.ships.filter((e) => e.where === "port").length;
	return t < 3 ? t : null;
}
function oe(e) {
	let t = e.ships.filter((e) => e.where === "yard").length;
	return t < 3 ? t : null;
}
function B(e, t) {
	let n = e.ships[t];
	n.where = "port", n.slot = z(e);
}
function V(e, t) {
	e.phase = "place", e.placeRound = t, e.placeQueue = e.placeOrder.filter((t) => !e.passed.includes(t)), e.placeQueue.length === 0 && H(e);
}
function se(e) {
	e.pilotSmall ? (e.phase = "pilot", e.pilotTurn = "small") : e.pilotBig ? (e.phase = "pilot", e.pilotTurn = "big") : e.phase = "move";
}
function H(e) {
	if (e.players.length === 3 && e.leg === 0 && e.placeRound === 1) {
		V(e, 2);
		return;
	}
	let t = e.leg + 1;
	if (t < 3) {
		e.leg = t, e.phase = "move";
		return;
	}
	e.leg = 3, se(e);
}
function ce(e) {
	if (e.ships.every((e) => e.where !== "sea")) {
		U(e);
		return;
	}
	if (e.leg === 2) {
		let t = e.ships.some((e) => e.where === "sea" && e.pos === 13 && e.crew.length < k[e.good].seats.length), n = e.pirateBoat.filter((e) => e !== null);
		if (t && n.length > 0) {
			e.phase = "pirateBoard", e.boardQueue = n;
			return;
		}
	}
	if (e.leg >= 3) {
		U(e);
		return;
	}
	V(e, e.placeRound + 1);
}
function U(e) {
	let t = e.ships.map((e, t) => ({
		sh: e,
		i: t
	})).filter(({ sh: e }) => e.where === "sea" && e.pos === 13), n = e.pirateBoat.filter((e) => e !== null);
	if (t.length > 0 && n.length > 0) {
		for (let { sh: e } of t) e.robbed = !0, e.crew = [];
		e.raidQueue = t.map(({ i: e }) => e), e.phase = "pirateRaid";
		return;
	}
	for (let { i: n } of t) B(e, n);
	le(e);
}
function le(e) {
	e.ships.forEach((t) => {
		t.where === "sea" && (t.where = "yard", t.slot = oe(e));
	}), ue(e);
}
function ue(e) {
	let t = Object.fromEntries(e.players.map((e) => [e, 0])), n = [], r = [], i = [
		null,
		null,
		null
	], a = [
		null,
		null,
		null
	], o = [], s = [];
	for (let r of e.ships) if (r.where === "port") {
		if (!r.robbed && r.crew.length > 0) {
			let e = k[r.good].profit / r.crew.length;
			for (let i of r.crew) t[i.rid] += e, n.push({
				rid: i.rid,
				good: r.good,
				amount: e
			});
		}
		o.push(r.good), s.push({
			good: r.good,
			outcome: r.robbed ? "robbedPort" : "port",
			slot: r.slot
		});
	} else s.push({
		good: r.good,
		outcome: r.robbed ? "robbedYard" : "yard",
		slot: r.slot
	});
	let c = e.pirateBoat.filter((e) => e !== null);
	if (c.length > 0) for (let n of e.ships) {
		if (!n.robbed) continue;
		let e = k[n.good].profit / c.length;
		for (let n of c) t[n] += e, r.push({
			rid: n,
			amount: e
		});
	}
	for (let n = 0; n < 3; n += 1) {
		let r = e.ships.some((e) => e.where === "port" && e.slot === n), a = e.ports[n];
		r && a && (t[a] += j[n], i[n] = {
			rid: a,
			amount: j[n]
		});
	}
	let l = 0;
	for (let n = 0; n < 3; n += 1) {
		if (!e.ships.some((e) => e.where === "yard" && e.slot === n)) continue;
		let r = e.yards[n], i = N[n];
		r && (r !== e.insurance && (t[r] += i), a[n] = {
			rid: r,
			amount: i
		}), e.insurance && r !== e.insurance && (l += i);
	}
	for (let n of e.players) e.cash[n] += t[n];
	let u = 0, d = 0;
	e.insurance && l > 0 && (e.cash[e.insurance] -= l, I(e, e.insurance), d = Math.max(0, -e.cash[e.insurance]), d > 0 && (e.cash[e.insurance] = 0), u = l - d, t[e.insurance] -= u);
	for (let t of o) e.market[t] = Math.min(O.length - 1, e.market[t] + 1);
	let f = _.some((t) => e.market[t] === O.length - 1);
	e.settlement = {
		ships: s,
		crewPay: n,
		loot: r,
		portPay: i,
		yardPay: a,
		insurancePaid: u,
		insuranceCovered: d,
		risen: o,
		deltas: t,
		gameEnd: f
	}, e.phase = "settle";
}
function de(e) {
	e.voyage += 1, e.ships = [], e.laidGood = null, e.ports = [
		null,
		null,
		null
	], e.yards = [
		null,
		null,
		null
	], e.pirateBoat = [null, null], e.pilotSmall = null, e.pilotBig = null, e.insurance = null, e.passed = [], e.placeOrder = [], e.placeQueue = [], e.placeRound = 0, e.leg = 0, e.lastRoll = null, e.pendingArrivals = [], e.boardQueue = [], e.raidQueue = [], e.pilotTurn = null, e.settlement = null, e.officeStep = null, ie(e);
}
function fe(e, t) {
	switch (t.kind) {
		case "ship": {
			let n = e.ships.find((e) => e.good === t.good);
			if (!n || n.where !== "sea") return null;
			let r = k[n.good].seats;
			return n.crew.length >= r.length ? null : r[n.crew.length];
		}
		case "port": return e.ports[t.slot] === null ? A[t.slot] : null;
		case "yard": return e.yards[t.slot] === null ? M[t.slot] : null;
		case "pirate": return e.pirateBoat[1] === null ? 5 : null;
		case "pilotSmall": return e.pilotSmall === null ? 2 : null;
		case "pilotBig": return e.pilotBig === null ? 5 : null;
		case "insurance": return e.insurance === null ? 0 : null;
	}
}
function pe(e) {
	let t = [];
	for (let n of e.ships) t.push({
		kind: "ship",
		good: n.good
	});
	for (let e = 0; e < 3; e += 1) t.push({
		kind: "port",
		slot: e
	}), t.push({
		kind: "yard",
		slot: e
	});
	return t.push({ kind: "pirate" }, { kind: "pilotSmall" }, { kind: "pilotBig" }, { kind: "insurance" }), t;
}
function me(t, n, r) {
	let i = structuredClone(t);
	if (n.type === "tick") return i.phase === "settle" ? i.settlement?.gameEnd ? (i.phase = "done", { state: i }) : (de(i), { state: i }) : { state: i };
	if (n.type === "mortgage" || n.type === "redeem") {
		if (!(i.phase === "auction" && i.auction?.order[i.auction.idx] === r.by || i.phase === "office" && i.harbor === r.by || i.phase === "place" && i.placeQueue[0] === r.by)) return P("games.manila.errNotTurn");
		if (n.type === "mortgage") {
			let e = i.shares[r.by].find((e) => e.good === n.good && !e.mortgaged);
			if (!e) return P("games.manila.errNoUnmortgaged");
			e.mortgaged = !0, i.cash[r.by] += 12;
		} else {
			let e = i.shares[r.by].find((e) => e.good === n.good && e.mortgaged);
			if (!e) return P("games.manila.errNoMortgaged");
			if (i.cash[r.by] < 15) return P("games.manila.errCash");
			i.cash[r.by] -= 15, e.mortgaged = !1;
		}
		return { state: i };
	}
	switch (n.type) {
		case "bid": {
			if (i.phase !== "auction" || !i.auction) return P("games.manila.errPhase");
			let e = i.auction;
			return e.order[e.idx] === r.by ? e.out.includes(r.by) ? P("games.manila.errPhase") : n.amount <= e.high ? P("games.manila.errBidLow") : n.amount > i.cash[r.by] + F(i, r.by) ? P("games.manila.errBidHigh") : (e.high = n.amount, e.highBy = r.by, R(i), { state: i }) : P("games.manila.errNotTurn");
		}
		case "passBid": {
			if (i.phase !== "auction" || !i.auction) return P("games.manila.errPhase");
			let e = i.auction;
			return e.order[e.idx] === r.by ? (e.out.push(r.by), R(i), { state: i }) : P("games.manila.errNotTurn");
		}
		case "buyShare": {
			if (i.phase !== "office" || i.harbor !== r.by || i.officeStep !== "share") return P("games.manila.errPhase");
			if (i.supply[n.good] <= 0) return P("games.manila.errNoShare");
			let e = Math.max(5, O[i.market[n.good]]);
			return i.cash[r.by] < e ? P("games.manila.errCash") : (i.cash[r.by] -= e, --i.supply[n.good], i.shares[r.by].push({
				good: n.good,
				mortgaged: !1
			}), i.officeStep = "deploy", { state: i });
		}
		case "skipShare": return i.phase !== "office" || i.harbor !== r.by || i.officeStep !== "share" ? P("games.manila.errPhase") : (i.officeStep = "deploy", { state: i });
		case "deploy": {
			if (i.phase !== "office" || i.harbor !== r.by || i.officeStep !== "deploy") return P("games.manila.errPhase");
			let e = n.goods;
			return new Set(e).size !== 3 || n.starts.reduce((e, t) => e + t, 0) !== 9 ? P("games.manila.errBadDeploy") : (i.laidGood = _.find((t) => !e.includes(t)) ?? null, i.ships = e.map((e, t) => ({
				good: e,
				pos: n.starts[t],
				where: "sea",
				slot: null,
				crew: [],
				robbed: !1
			})), i.officeStep = null, i.placeOrder = re(i.players, i.players.indexOf(r.by)), V(i, 1), { state: i });
		}
		case "place": {
			if (i.phase !== "place") return P("games.manila.errPhase");
			if (i.placeQueue[0] !== r.by) return P("games.manila.errNotTurn");
			let e = fe(i, n.spot);
			if (e === null) return P("games.manila.errSpotTaken");
			if (i.cash[r.by] >= e) i.cash[r.by] -= e;
			else {
				let e = pe(i).map((e) => e.kind === "insurance" ? null : fe(i, e)).filter((e) => e !== null), t = e.length > 0 ? Math.min(...e) : 0;
				if (!(n.spot.kind !== "insurance" && i.cash[r.by] + F(i, r.by) < t)) return P("games.manila.errCash");
				i.cash[r.by] = 0;
			}
			switch (n.spot.kind) {
				case "ship":
					i.ships.find((e) => e.good === n.spot.good).crew.push({
						rid: r.by,
						pirate: !1
					});
					break;
				case "port":
					i.ports[n.spot.slot] = r.by;
					break;
				case "yard":
					i.yards[n.spot.slot] = r.by;
					break;
				case "pirate":
					i.pirateBoat[i.pirateBoat[0] === null ? 0 : 1] = r.by;
					break;
				case "pilotSmall":
					i.pilotSmall = r.by;
					break;
				case "pilotBig":
					i.pilotBig = r.by;
					break;
				case "insurance": i.insurance = r.by, i.cash[r.by] += 10;
			}
			return i.placeQueue.shift(), i.placeQueue.length === 0 && H(i), { state: i };
		}
		case "passPlace": return i.phase === "place" ? i.placeQueue[0] === r.by ? (i.passed.push(r.by), i.placeQueue.shift(), i.placeQueue.length === 0 && H(i), { state: i }) : P("games.manila.errNotTurn") : P("games.manila.errPhase");
		case "roll": {
			if (i.phase !== "move") return P("games.manila.errPhase");
			if (i.harbor !== r.by) return P("games.manila.errNotTurn");
			let t = i.ships.map((e, t) => ({
				sh: e,
				i: t
			})).filter(({ sh: e }) => e.where === "sea"), n = t.map(() => {
				let t = 1 + e(i.seed, i.rngCursor, 6);
				return i.rngCursor += 1, t;
			});
			i.lastRoll = t.map(({ sh: e }, t) => ({
				good: e.good,
				die: n[t],
				from: e.pos,
				to: e.pos + n[t]
			}));
			let a = [];
			return t.forEach(({ sh: e, i: t }, r) => {
				e.pos += n[r], e.pos > 13 && a.push(t);
			}), a.length > 1 ? (i.pendingArrivals = a, i.phase = "portOrder", { state: i }) : (a.length === 1 && B(i, a[0]), ce(i), { state: i });
		}
		case "portOrder": {
			if (i.phase !== "portOrder") return P("games.manila.errPhase");
			if (i.harbor !== r.by) return P("games.manila.errNotTurn");
			let e = [...n.order].sort((e, t) => e - t);
			if (e.length !== i.pendingArrivals.length || !e.every((e, t) => e === [...i.pendingArrivals].sort((e, t) => e - t)[t])) return P("games.manila.errBadOrder");
			for (let e of n.order) B(i, e);
			return i.pendingArrivals = [], ce(i), { state: i };
		}
		case "board":
			if (i.phase !== "pirateBoard") return P("games.manila.errPhase");
			if (i.boardQueue[0] !== r.by) return P("games.manila.errNotTurn");
			if (n.ship !== null) {
				let e = i.ships[n.ship];
				if (!e || e.where !== "sea" || e.pos !== 13 || e.crew.length >= k[e.good].seats.length) return P("games.manila.errBadBoard");
				let t = i.pirateBoat.indexOf(r.by);
				i.pirateBoat[t] = null, t === 0 && i.pirateBoat[1] !== null && (i.pirateBoat[0] = i.pirateBoat[1], i.pirateBoat[1] = null), e.crew.push({
					rid: r.by,
					pirate: !0
				});
			}
			return i.boardQueue.shift(), i.boardQueue.length === 0 && V(i, i.placeRound + 1), { state: i };
		case "pilotMove": {
			if (i.phase !== "pilot" || !i.pilotTurn) return P("games.manila.errPhase");
			if ((i.pilotTurn === "small" ? i.pilotSmall : i.pilotBig) !== r.by) return P("games.manila.errNotTurn");
			let e = n.moves, t = i.pilotTurn === "big", a = t ? e.length <= 2 : e.length <= 1, o = t ? e.length === 2 ? e.every((e) => Math.abs(e.delta) === 1) && e[0].ship !== e[1].ship : e.every((e) => Math.abs(e.delta) >= 1 && Math.abs(e.delta) <= 2) : e.every((e) => Math.abs(e.delta) === 1);
			if (!a || !o) return P("games.manila.errBadPilot");
			for (let t of e) {
				let e = i.ships[t.ship];
				if (!e || e.where !== "sea" || e.pos + t.delta < 0) return P("games.manila.errBadPilot");
			}
			for (let t of e) {
				let e = i.ships[t.ship];
				e.pos += t.delta, e.pos > 13 && B(i, t.ship);
			}
			return i.pilotTurn === "small" && i.pilotBig ? i.pilotTurn = "big" : (i.pilotTurn = null, i.phase = "move"), { state: i };
		}
		case "raidChoose": return i.phase === "pirateRaid" ? i.pirateBoat[0] === r.by ? n.dests.length !== i.raidQueue.length || n.dests.filter((e) => e === "port").length > 3 - i.ships.filter((e) => e.where === "port").length ? P("games.manila.errBadRaid") : (i.raidQueue.forEach((e, t) => {
			let r = i.ships[e];
			n.dests[t] === "port" ? (r.where = "port", r.slot = z(i)) : (r.where = "yard", r.slot = oe(i));
		}), i.raidQueue = [], le(i), { state: i }) : P("games.manila.errNotTurn") : P("games.manila.errPhase");
		default: return P("games.manila.errPhase");
	}
}
function he(e) {
	switch (e.phase) {
		case "auction": return e.auction ? e.auction.order[e.auction.idx] : null;
		case "office":
		case "move":
		case "portOrder": return e.harbor;
		case "place": return e.placeQueue[0] ?? null;
		case "pirateBoard": return e.boardQueue[0] ?? null;
		case "pilot": return e.pilotTurn === "small" ? e.pilotSmall : e.pilotBig;
		case "pirateRaid": return e.pirateBoat[0];
		default: return null;
	}
}
function ge(e) {
	return {
		public: {
			voyage: e.voyage,
			phase: e.phase,
			harbor: e.harbor,
			market: { ...e.market },
			supply: { ...e.supply },
			laidGood: e.laidGood,
			ships: e.ships.map((e) => ({
				good: e.good,
				pos: e.pos,
				where: e.where,
				slot: e.slot,
				crew: e.crew.map((e) => ({ ...e })),
				robbed: e.robbed
			})),
			ports: [...e.ports],
			yards: [...e.yards],
			pirateBoat: [...e.pirateBoat],
			pilotSmall: e.pilotSmall,
			pilotBig: e.pilotBig,
			insurance: e.insurance,
			players: e.players.map((t) => ({
				rid: t,
				cash: e.cash[t],
				shares: e.shares[t].map((e) => ({ ...e })),
				passed: e.passed.includes(t)
			})),
			active: he(e),
			auction: e.auction ? {
				high: e.auction.high,
				highBy: e.auction.highBy,
				out: [...e.auction.out]
			} : null,
			officeStep: e.officeStep,
			placeRound: e.placeRound,
			placeRoundsTotal: e.players.length === 3 ? 4 : 3,
			leg: e.leg,
			lastRoll: e.lastRoll ? e.lastRoll.map((e) => ({ ...e })) : null,
			pendingArrivals: [...e.pendingArrivals],
			boardQueue: [...e.boardQueue],
			raidQueue: [...e.raidQueue],
			pilotTurn: e.pilotTurn,
			settlement: e.settlement
		},
		private: {}
	};
}
function _e(e, t) {
	let n = e.shares[t].reduce((t, n) => t + O[e.market[n.good]], 0), r = e.shares[t].filter((e) => e.mortgaged).length * 15;
	return e.cash[t] + n - r;
}
function ve(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = Object.fromEntries(e.players.map((t) => [t, _e(e, t)])), n = [...e.players].sort((e, n) => t[n] - t[e]), r = t[n[0]];
	return {
		phase: "done",
		winner: n.filter((e) => t[e] === r),
		ranking: n,
		scores: t
	};
}
function ye(e) {
	return e.phase === "settle" ? te : null;
}
var be = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: g,
	schemas: {
		action: b,
		publicView: ee,
		privateView: D
	},
	setup: ne,
	reduce: me,
	viewFor: ge,
	status: ve,
	nextTickIn: ye
}, xe = {
	ginseng: "参",
	nutmeg: "蔻",
	silk: "丝",
	jade: "玉"
};
function Se() {
	return /* @__PURE__ */ m("svg", {
		className: "manila-water-art",
		viewBox: "0 0 240 420",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ p("rect", {
				width: "240",
				height: "420",
				fill: "var(--ma-sea)"
			}),
			/* @__PURE__ */ p("path", {
				d: "M0 35 Q33 8 69 39 T142 33 T240 19 V101 Q195 78 158 103 T80 90 T0 111Z",
				fill: "var(--ma-sea-light)",
				opacity: ".15"
			}),
			/* @__PURE__ */ p("path", {
				d: "M0 244 Q45 217 75 252 T151 242 T240 228 V297 Q191 273 151 307 T76 289 T0 314Z",
				fill: "var(--ma-sea-light)",
				opacity: ".16"
			}),
			[
				0,
				1,
				2
			].map((e) => /* @__PURE__ */ m("g", {
				transform: `translate(${e * 80},0)`,
				children: [/* @__PURE__ */ p("rect", {
					x: "6",
					y: "7",
					width: "68",
					height: "406",
					rx: "13",
					fill: "var(--ma-sea-light)",
					opacity: ".12"
				}), /* @__PURE__ */ p("path", {
					d: "M79 10 V410",
					fill: "none",
					stroke: "var(--ma-foam)",
					strokeDasharray: "4 10",
					opacity: ".36"
				})]
			}, e)),
			Array.from({ length: 14 }, (e, t) => /* @__PURE__ */ p("g", {
				transform: `translate(0,${18 + t * 29})`,
				stroke: "var(--ma-foam)",
				fill: "none",
				strokeWidth: "2.8",
				strokeLinecap: "round",
				opacity: t % 4 == 0 ? ".62" : ".36",
				children: /* @__PURE__ */ p("path", { d: "M8 0 q10 -8 20 0 t20 0 t20 0 M88 0 q10 -8 20 0 t20 0 t20 0 M168 0 q10 -8 20 0 t20 0 t20 0" })
			}, t)),
			/* @__PURE__ */ p("path", {
				d: "M1 0 Q10 19 1 39 T1 83 M239 0 Q230 20 239 43 T239 88",
				fill: "none",
				stroke: "var(--ma-foam)",
				strokeWidth: "3",
				opacity: ".7"
			})
		]
	});
}
function Ce() {
	return /* @__PURE__ */ m("svg", {
		className: "manila-shore-art",
		viewBox: "0 0 375 420",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: [
			[
				20,
				96,
				173,
				251,
				330
			].map((e) => /* @__PURE__ */ m("g", {
				fill: "var(--ma-land-dark)",
				opacity: ".25",
				children: [/* @__PURE__ */ p("path", { d: `M0 ${e} Q22 ${e - 16} 45 ${e - 4} T76 ${e - 4} V${e + 20} Q41 ${e + 4} 0 ${e + 22}Z` }), /* @__PURE__ */ p("path", { d: `M299 ${e + 4} Q331 ${e - 12} 375 ${e - 2} V${e + 22} Q333 ${e + 4} 299 ${e + 25}Z` })]
			}, e)),
			/* @__PURE__ */ m("g", {
				fill: "var(--ma-foliage)",
				children: [
					/* @__PURE__ */ p("path", { d: "M17 31 Q28 6 38 29 Q38 9 56 11 Q42 20 40 39 Q53 24 68 28 Q52 35 42 48 Q31 38 17 31Z" }),
					/* @__PURE__ */ p("path", { d: "M310 34 Q326 9 342 27 Q340 8 364 12 Q349 24 347 42 Q363 27 374 31 Q358 41 349 53 Q332 37 310 34Z" }),
					/* @__PURE__ */ p("path", { d: "M9 360 Q25 333 40 351 Q41 331 60 336 Q47 350 44 369 Q59 352 73 360 Q53 365 45 385 Q30 369 9 360Z" })
				]
			}),
			/* @__PURE__ */ p("g", {
				stroke: "var(--ma-wood-deep)",
				strokeWidth: "3",
				fill: "none",
				strokeLinecap: "round",
				children: /* @__PURE__ */ p("path", { d: "M36 66 Q43 46 39 29 M342 71 Q349 48 344 29 M42 402 Q49 381 43 359" })
			})
		]
	});
}
function we() {
	return /* @__PURE__ */ m("svg", {
		className: "manila-punt-art",
		viewBox: "0 0 80 66",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ p("path", {
				d: "M5 43 Q40 54 75 43 L65 60 Q40 68 15 60Z",
				fill: "var(--ma-wood-deep)",
				stroke: "var(--color-ink)",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ p("path", {
				d: "M8 42 Q40 51 72 42 L64 56 Q40 63 16 56Z",
				fill: "var(--ma-good)",
				stroke: "var(--color-ink)",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ p("path", {
				d: "M40 5 V43",
				stroke: "var(--color-ink)",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ p("path", {
				d: "M37 7 L10 39 H37Z",
				fill: "var(--color-surface)",
				stroke: "var(--color-ink)",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ p("path", {
				d: "M43 9 L67 39 H43Z",
				fill: "color-mix(in srgb,var(--ma-good) 28%,var(--color-surface))",
				stroke: "var(--color-ink)",
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ p("path", {
				d: "M10 53 Q40 63 70 53",
				fill: "none",
				stroke: "var(--ma-foam)",
				strokeWidth: "2",
				opacity: ".8"
			})
		]
	});
}
function Te({ kind: e }) {
	let t = e === "pirate" ? "☠" : e === "pilot" ? "✦" : e === "insurance" ? "+" : e === "route" ? "↥" : "⚒";
	return /* @__PURE__ */ m("svg", {
		className: `manila-site-art manila-site-art--${e}`,
		viewBox: "0 0 70 88",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: [e === "pirate" ? /* @__PURE__ */ p("path", {
			d: "M4 8 Q35 -6 66 8 L63 73 Q35 97 7 73Z",
			fill: "var(--ma-wood-deep)",
			stroke: "var(--color-ink)",
			strokeWidth: "3"
		}) : e === "yard" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", {
			d: "M4 3 L66 6 L62 84 L5 82Z",
			fill: "var(--ma-wood)",
			stroke: "var(--color-ink)",
			strokeWidth: "3"
		}), /* @__PURE__ */ p("path", {
			d: "M7 25 L63 27 M6 48 L63 50 M6 68 L63 70",
			fill: "none",
			stroke: "var(--ma-wood-deep)",
			opacity: ".4"
		})] }) : e === "insurance" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", {
			d: "M5 19 L35 2 L65 19 L62 83 H8Z",
			fill: "var(--ma-sand)",
			stroke: "var(--color-ink)",
			strokeWidth: "3"
		}), /* @__PURE__ */ p("path", {
			d: "M5 19 L35 2 L65 19Z",
			fill: "var(--ma-wood-deep)",
			stroke: "var(--color-ink)",
			strokeWidth: "2"
		})] }) : e === "route" ? /* @__PURE__ */ p("path", {
			d: "M5 12 L35 3 L65 12 V78 L35 86 L5 78Z",
			fill: "var(--ma-wood-deep)",
			stroke: "var(--color-ink)",
			strokeWidth: "3"
		}) : /* @__PURE__ */ p("path", {
			d: "M3 16 Q35 -5 67 15 L69 72 Q35 98 2 72Z",
			fill: "var(--ma-sand)",
			stroke: "var(--color-ink)",
			strokeWidth: "3"
		}), /* @__PURE__ */ p("text", {
			x: "35",
			y: e === "route" ? 18 : 53,
			textAnchor: "middle",
			fontSize: "13",
			fontWeight: "900",
			opacity: e === "route" ? 1 : .25,
			fill: e === "pirate" || e === "route" || e === "insurance" ? "var(--color-surface)" : "var(--ma-land-dark)",
			children: t
		})]
	});
}
function Ee({ good: e, style: t }) {
	return /* @__PURE__ */ p("span", {
		className: `manila-cargo-mark manila-good-${e}`,
		style: t,
		"aria-hidden": !0,
		children: xe[e]
	});
}
//#endregion
//#region src/games/manila/board-view.tsx
function De({ pub: e, members: t, myTurn: n, canPlaceAt: r, onPlace: i, portOrder: a, onPickOrder: s, pilotMoves: c, raidDests: l }) {
	let u = o(), d = e.phase === "settle" || e.phase === "done" ? e.settlement : null;
	return /* @__PURE__ */ p("div", {
		className: "manila-board-viewport",
		children: /* @__PURE__ */ m("div", {
			className: "manila-board",
			children: [
				/* @__PURE__ */ p("div", {
					className: "manila-board-top",
					children: [
						0,
						1,
						2
					].map((n) => {
						let a = e.ships.find((e) => e.where === "port" && e.slot === n);
						return /* @__PURE__ */ p(Ae, {
							label: `${u("games.manila.port")} ${"ABC"[n]}`,
							fee: A[n],
							pay: j[n],
							occupant: e.ports[n],
							members: t,
							canPlace: e.ports[n] === null && r(A[n]),
							onPlace: () => i({
								kind: "port",
								slot: n
							}),
							docked: a ?? null,
							settlement: d,
							income: d?.portPay[n]?.amount ?? null
						}, n);
					})
				}),
				/* @__PURE__ */ m("div", {
					className: "manila-board-middle",
					children: [
						/* @__PURE__ */ p(Ce, {}),
						/* @__PURE__ */ m("div", {
							className: "manila-shore",
							children: [
								/* @__PURE__ */ m(q, {
									kind: "pirate",
									label: u("games.manila.pirateShort"),
									fee: 5,
									fullLabel: u("games.manila.pirateBoat"),
									children: [/* @__PURE__ */ p("span", {
										className: "manila-pirate-crew",
										children: e.pirateBoat.filter((e) => e !== null).map((e, n) => /* @__PURE__ */ p(W, {
											rid: e,
											members: t,
											size: "size-5",
											amount: d ? d.loot.filter((t) => t.rid === e).reduce((e, t) => e + t.amount, 0) : null,
											title: n === 0 ? u("games.manila.captain") : void 0
										}, e))
									}), e.pirateBoat[1] === null && (r(5) ? /* @__PURE__ */ p(G, {
										fee: 5,
										label: u("games.manila.pirateBoat"),
										onPlace: () => i({ kind: "pirate" })
									}) : /* @__PURE__ */ p(K, { fee: 5 }))]
								}),
								/* @__PURE__ */ p(q, {
									kind: "pilot",
									label: u("games.manila.pilotSmallShort"),
									fee: 2,
									fullLabel: u("games.manila.pilotSmall"),
									children: e.pilotSmall ? /* @__PURE__ */ p(Oe, {
										rid: e.pilotSmall,
										members: t
									}) : r(2) ? /* @__PURE__ */ p(G, {
										fee: 2,
										label: u("games.manila.pilotSmall"),
										onPlace: () => i({ kind: "pilotSmall" })
									}) : /* @__PURE__ */ p(K, { fee: 2 })
								}),
								/* @__PURE__ */ p(q, {
									kind: "pilot",
									label: u("games.manila.pilotBigShort"),
									fee: 5,
									fullLabel: u("games.manila.pilotBig"),
									children: e.pilotBig ? /* @__PURE__ */ p(Oe, {
										rid: e.pilotBig,
										members: t
									}) : r(5) ? /* @__PURE__ */ p(G, {
										fee: 5,
										label: u("games.manila.pilotBig"),
										onPlace: () => i({ kind: "pilotBig" })
									}) : /* @__PURE__ */ p(K, { fee: 5 })
								}),
								/* @__PURE__ */ m("div", {
									className: "manila-site manila-site--route",
									children: [/* @__PURE__ */ p(Te, { kind: "route" }), /* @__PURE__ */ m("span", {
										className: "manila-site-title",
										children: ["0→", 13]
									})]
								})
							]
						}),
						/* @__PURE__ */ m("div", {
							className: "manila-water",
							children: [/* @__PURE__ */ p(Se, {}), [
								0,
								1,
								2
							].map((o) => {
								let u = e.ships[o];
								return /* @__PURE__ */ m("div", {
									className: "manila-lane",
									children: [[
										0,
										5,
										10,
										13
									].map((e) => /* @__PURE__ */ p("span", {
										className: "manila-space-label",
										style: { bottom: `${e / 13 * 91}%` },
										children: e
									}, e)), u?.where === "sea" && /* @__PURE__ */ p(je, {
										ship: u,
										members: t,
										canPlace: r(k[u.good].seats[u.crew.length] ?? 0) && u.crew.length < k[u.good].seats.length,
										onPlace: () => i({
											kind: "ship",
											good: u.good
										}),
										orderBadge: e.phase === "portOrder" && e.pendingArrivals.includes(o) ? a.includes(o) ? a.indexOf(o) + 1 : 0 : null,
										onPickOrder: e.phase === "portOrder" && n && e.pendingArrivals.includes(o) ? () => s(o) : void 0,
										pendingArrival: e.pendingArrivals.includes(o),
										pilotDelta: e.phase === "pilot" ? c.find((e) => e.ship === o)?.delta : void 0,
										raidDestination: e.phase === "pirateRaid" ? l[e.raidQueue.indexOf(o)] : void 0
									})]
								}, o);
							})]
						}),
						/* @__PURE__ */ m("div", {
							className: "manila-shore",
							children: [[
								0,
								1,
								2
							].map((n) => {
								let a = e.ships.find((e) => e.where === "yard" && e.slot === n);
								return /* @__PURE__ */ p(q, {
									kind: "yard",
									label: `${u("games.manila.yardShort")} ${"ABC"[n]}`,
									fee: M[n],
									pay: N[n],
									fullLabel: `${u("games.manila.yard")} ${"ABC"[n]}`,
									docked: a ?? null,
									children: e.yards[n] ? /* @__PURE__ */ p(W, {
										rid: e.yards[n],
										members: t,
										amount: e.yards[n] === e.insurance ? null : d?.yardPay[n]?.amount ?? null
									}) : r(M[n]) ? /* @__PURE__ */ p(G, {
										fee: M[n],
										label: `${u("games.manila.yard")} ${"ABC"[n]}`,
										onPlace: () => i({
											kind: "yard",
											slot: n
										})
									}) : /* @__PURE__ */ p(K, { fee: M[n] })
								}, n);
							}), /* @__PURE__ */ p(q, {
								kind: "insurance",
								label: u("games.manila.insurance"),
								fee: 0,
								fullLabel: u("games.manila.insurance"),
								children: e.insurance ? /* @__PURE__ */ p(W, {
									rid: e.insurance,
									members: t,
									amount: d && d.insurancePaid > 0 ? -d.insurancePaid : null
								}) : r(0, !0) ? /* @__PURE__ */ p(G, {
									fee: 0,
									label: u("games.manila.insurance"),
									onPlace: () => i({ kind: "insurance" })
								}) : /* @__PURE__ */ p(K, { fee: 0 })
							})]
						})
					]
				}),
				/* @__PURE__ */ p("div", {
					className: "manila-market",
					"aria-label": u("games.manila.marketPrice"),
					children: _.map((t) => /* @__PURE__ */ m("div", {
						className: `manila-market-ware manila-good-${t}`,
						"data-risen": e.settlement?.risen.includes(t) ?? !1,
						title: u("games.manila.supply", { n: e.supply[t] }),
						children: [
							/* @__PURE__ */ p("span", {
								className: "manila-market-name",
								children: u(`games.manila.${t}`)
							}),
							/* @__PURE__ */ p("span", {
								className: "manila-market-price",
								children: O[e.market[t]]
							}),
							/* @__PURE__ */ p("span", {
								className: "manila-market-track",
								"aria-hidden": !0,
								children: O.map((n, r) => /* @__PURE__ */ p("span", {
									className: "manila-market-step",
									"data-current": r === e.market[t]
								}, r))
							}),
							/* @__PURE__ */ p("span", {
								className: "manila-market-supply",
								children: u("games.manila.supply", { n: e.supply[t] })
							})
						]
					}, t))
				})
			]
		})
	});
}
function Oe({ rid: e, members: t, size: n = "size-8", title: i }) {
	let a = t.find((t) => t.rid === e), o = d[(a?.colorIndex ?? 0) % d.length].hex, s = u[(r(e) ?? a?.avatar ?? 0) % u.length];
	return /* @__PURE__ */ p("img", {
		src: s,
		alt: "",
		"aria-hidden": !0,
		title: i,
		style: { borderColor: o },
		className: `${n} rounded-full border-2 bg-surface object-contain`
	});
}
function W({ rid: e, members: t, amount: n, size: r = "size-8", title: i }) {
	let a = t.find((t) => t.rid === e), o = n ? `${n > 0 ? "+" : "−"}${Math.abs(n)}` : "";
	return /* @__PURE__ */ m("span", {
		className: "manila-payout-avatar",
		"data-small": r === "size-5",
		role: "img",
		"aria-label": `${a?.name ?? e}${o ? ` · ${o}` : ""}`,
		children: [/* @__PURE__ */ p(Oe, {
			rid: e,
			members: t,
			size: r,
			title: i
		}), o && /* @__PURE__ */ m("span", {
			className: "manila-coin-badge",
			"aria-hidden": !0,
			children: ["🪙", o]
		})]
	});
}
function G({ fee: e, label: t, onPlace: n }) {
	let r = o();
	return /* @__PURE__ */ p("button", {
		type: "button",
		className: "manila-place-button",
		onClick: n,
		"aria-label": `${t} · ${r("games.manila.fee", { n: e })}`,
		children: e
	});
}
function K({ fee: e }) {
	return /* @__PURE__ */ p("span", {
		className: "manila-empty-seat",
		"aria-hidden": !0,
		children: e
	});
}
function ke({ ship: e, members: t, settlement: n }) {
	let r = o();
	return /* @__PURE__ */ m("span", {
		className: `manila-docked manila-good-${e.good}`,
		title: r(`games.manila.${e.good}`),
		children: [
			/* @__PURE__ */ p(we, {}),
			/* @__PURE__ */ p(Ee, { good: e.good }),
			e.robbed && /* @__PURE__ */ p("span", {
				"aria-label": r("games.manila.outcomeRobbedYard"),
				children: "☠"
			}),
			n && t && e.where === "port" && e.crew.length > 0 && /* @__PURE__ */ p("span", {
				className: "manila-docked-crew",
				children: e.crew.map((r, i) => /* @__PURE__ */ p(W, {
					rid: r.rid,
					members: t,
					size: "size-5",
					amount: n.crewPay.find((t) => t.good === e.good && t.rid === r.rid)?.amount ?? null
				}, `${r.rid}-${i}`))
			})
		]
	});
}
function Ae({ label: e, fee: t, pay: n, occupant: r, members: i, canPlace: a, onPlace: s, docked: c, settlement: l, income: u }) {
	let d = o();
	return /* @__PURE__ */ m("div", {
		className: "manila-pier",
		children: [
			/* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p("span", {
				className: "manila-pier-title",
				children: e
			}), /* @__PURE__ */ p("span", {
				className: "manila-pier-fee",
				children: d("games.manila.fee", { n: t })
			})] }),
			/* @__PURE__ */ p("span", {
				className: "manila-pier-pay",
				title: d("games.manila.pay", { n }),
				children: n
			}),
			c && /* @__PURE__ */ p("span", {
				className: "manila-pier-docked",
				children: /* @__PURE__ */ p(ke, {
					ship: c,
					members: i,
					settlement: l
				})
			}),
			/* @__PURE__ */ p("span", {
				className: "manila-pier-occupant",
				children: r ? /* @__PURE__ */ p(W, {
					rid: r,
					members: i,
					amount: u
				}) : a ? /* @__PURE__ */ p(G, {
					fee: t,
					label: e,
					onPlace: s
				}) : /* @__PURE__ */ p(K, { fee: t })
			})
		]
	});
}
function q({ kind: e, label: t, fee: n, pay: r, fullLabel: i, docked: a, children: s }) {
	let c = o();
	return /* @__PURE__ */ m("div", {
		className: `manila-site manila-site--${e}`,
		title: `${i} · ${c("games.manila.fee", { n })}${r === void 0 ? "" : ` · ${c("games.manila.pay", { n: r })}`}`,
		children: [
			/* @__PURE__ */ p(Te, { kind: e }),
			/* @__PURE__ */ p("span", {
				className: "manila-site-title",
				children: t
			}),
			/* @__PURE__ */ p("span", {
				className: "manila-site-fee",
				children: r === void 0 ? c("games.manila.fee", { n }) : `−${n} / +${r}`
			}),
			/* @__PURE__ */ p("span", {
				className: "manila-site-seat",
				children: s
			}),
			a && /* @__PURE__ */ p("span", {
				className: "manila-site-docked",
				children: /* @__PURE__ */ p(ke, { ship: a })
			})
		]
	});
}
function je({ ship: e, members: t, canPlace: n, onPlace: r, orderBadge: i, onPickOrder: a, pendingArrival: s, pilotDelta: c, raidDestination: l }) {
	let u = o(), d = k[e.good].seats, f = Math.min(e.pos, 13) / 13, h = { bottom: `calc(${f * 100}% + ${10 - f * 10}px - var(--ma-ship-height) * ${f})` }, g = /* @__PURE__ */ m("span", {
		className: "manila-ship-body",
		children: [
			/* @__PURE__ */ p(we, {}),
			/* @__PURE__ */ p("span", {
				className: "manila-ship-position",
				children: e.pos
			}),
			/* @__PURE__ */ m("span", {
				className: "manila-ship-label",
				children: [
					u(`games.manila.${e.good}`),
					" · ",
					k[e.good].profit
				]
			}),
			/* @__PURE__ */ p("span", {
				className: "manila-ship-crew",
				children: d.map((r, i) => /* @__PURE__ */ p("span", {
					className: "manila-ship-seat",
					"data-next": n && i === e.crew.length,
					children: e.crew[i] ? /* @__PURE__ */ p(Oe, {
						rid: e.crew[i].rid,
						members: t,
						size: "size-full",
						title: e.crew[i].pirate ? u("games.manila.pirateBoat") : void 0
					}) : r
				}, i))
			}),
			i !== null && /* @__PURE__ */ p("span", {
				className: "manila-ship-order",
				children: i || "+"
			}),
			c !== void 0 && /* @__PURE__ */ p("span", {
				className: "manila-ship-choice",
				children: c > 0 ? `+${c}` : c
			}),
			l && /* @__PURE__ */ p("span", {
				className: "manila-ship-choice",
				children: u(l === "port" ? "games.manila.port" : "games.manila.yard")
			})
		]
	}), _ = `manila-ship manila-good-${e.good}`;
	return a ? /* @__PURE__ */ p("button", {
		type: "button",
		className: _,
		style: h,
		"data-pickable": "true",
		"data-pending": s,
		"aria-pressed": i !== null && i > 0,
		"aria-label": `${u(`games.manila.${e.good}`)} · ${u("games.manila.portOrderPrompt")}`,
		onClick: a,
		children: g
	}) : n ? /* @__PURE__ */ p("button", {
		type: "button",
		className: _,
		style: h,
		"data-pickable": "true",
		"data-pending": s,
		"aria-label": `${u(`games.manila.${e.good}`)} · ${u("games.manila.fee", { n: d[e.crew.length] })}`,
		onClick: r,
		children: g
	}) : /* @__PURE__ */ p("div", {
		className: _,
		style: h,
		"data-pending": s,
		children: g
	});
}
//#endregion
//#region src/games/manila/view-player.tsx
var J = {
	ginseng: "border-amber-700 bg-amber-100 text-amber-900",
	nutmeg: "border-amber-950 bg-amber-700 text-amber-50",
	silk: "border-sky-800 bg-sky-200 text-sky-900",
	jade: "border-emerald-900 bg-emerald-600 text-emerald-50"
};
function Me(e) {
	let t = e.public;
	return /* @__PURE__ */ p(Pe, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Ne(e, t) {
	return r(e.rid) === null ? e.name : i(t, e.avatar);
}
function Pe({ pub: e, members: t, myRid: r, send: i }) {
	let u = o(), d = a((e) => e.locale), f = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? Ne(n, d) : e;
	}, h = t.filter((t) => e.players.some((e) => e.rid === t.rid)), _ = e.players.find((e) => e.rid === r), v = e.active === r, y = e.phase === "place" && v && !_?.passed, b = [
		...e.ships.filter((e) => e.where === "sea" && e.crew.length < k[e.good].seats.length).map((e) => k[e.good].seats[e.crew.length]),
		...e.ports.flatMap((e, t) => e === null ? [A[t]] : []),
		...e.yards.flatMap((e, t) => e === null ? [M[t]] : []),
		...e.pirateBoat[1] === null ? [5] : [],
		...e.pilotSmall === null ? [2] : [],
		...e.pilotBig === null ? [5] : []
	], x = b.length ? Math.min(...b) : 0, S = _?.shares.filter((e) => !e.mortgaged).length ?? 0, C = _ !== void 0 && _.cash + S * 12 < x, w = (e, t = !1) => y && _ !== void 0 && (_.cash >= e || !t && C), T = e.phase === "auction" && v || e.phase === "office" && v || e.phase === "place" && v, E = `${e.phase}|${e.voyage}|${e.leg}|${e.officeStep}|${e.pilotTurn}`, [ee, D] = n(E), [O, j] = n(1), [N, te] = n([]), [P, ne] = n({
		ginseng: 0,
		nutmeg: 0,
		silk: 0,
		jade: 0
	}), [re, ie] = n([]), [ae, F] = n([]), [I, L] = n([]), [R, z] = n("phase");
	ee !== E && (D(E), j((e.auction?.high ?? 0) + 1), te([]), ne({
		ginseng: 0,
		nutmeg: 0,
		silk: 0,
		jade: 0
	}), ie([]), F([]), L(e.raidQueue.map(() => "yard")), z("phase"));
	let oe = {
		auction: u("games.manila.phaseAuction"),
		office: u("games.manila.phaseOffice"),
		place: u("games.manila.phasePlace"),
		move: u("games.manila.phaseMove"),
		portOrder: u("games.manila.phasePortOrder"),
		pirateBoard: u("games.manila.phasePirateBoard"),
		pilot: u("games.manila.phasePilot"),
		pirateRaid: u("games.manila.phasePirateRaid"),
		settle: u("games.manila.phaseSettle"),
		done: u("games.manila.phaseDone")
	}, B = "info";
	e.phase === "done" ? B = "done" : v ? B = "accent" : (e.phase === "pirateBoard" || e.phase === "pirateRaid") && (B = "warn");
	let V;
	e.active && (V = e.active === r ? u("games.manila.myTurn") : u("games.manila.waitingFor", { name: f(e.active) })), e.phase === "place" && (V = `${u("games.manila.placeRoundInfo", {
		n: e.placeRound,
		total: e.placeRoundsTotal
	})}${V ? ` · ${V}` : ""}`), (e.phase === "move" || e.phase === "portOrder" || e.phase === "pilot") && (V = `${u("games.manila.legInfo", { n: e.leg })}${V ? ` · ${V}` : ""}`);
	let se = (e) => i({
		type: "place",
		spot: e
	}), H = v && (e.phase === "auction" || e.phase === "office" || e.phase === "pirateBoard" || e.phase === "pilot" || e.phase === "pirateRaid"), ce = T && !!_?.shares.length, U = {
		pub: e,
		me: _,
		myRid: r,
		myTurn: v,
		loanWindow: !1,
		nameOf: f,
		send: i,
		bid: O,
		setBid: j,
		deployGoods: N,
		setDeployGoods: te,
		deployStarts: P,
		setDeployStarts: ne,
		portOrder: re,
		pilotMoves: ae,
		setPilotMoves: F,
		raidDests: I,
		setRaidDests: L
	};
	return /* @__PURE__ */ p("div", {
		className: "manila-root h-full",
		style: { "--ma-accent": g.accent },
		children: /* @__PURE__ */ p(s, {
			adaptive: !0,
			className: "manila-screen",
			banner: /* @__PURE__ */ m("div", {
				className: "flex flex-col gap-1",
				children: [/* @__PURE__ */ p(c, {
					tone: B,
					text: oe[e.phase],
					sub: V,
					chip: u("games.manila.voyage", { n: e.voyage }),
					accent: g.accent
				}), /* @__PURE__ */ p("div", {
					className: "manila-roster",
					children: h.map((t) => {
						let n = e.players.find((e) => e.rid === t.rid);
						if (!n) return null;
						let i = n.shares.filter((e) => e.mortgaged).length;
						return /* @__PURE__ */ m("div", {
							className: "manila-roster-card",
							"data-active": e.active === t.rid,
							"data-passed": e.phase === "place" && n.passed,
							children: [/* @__PURE__ */ p(l, {
								m: t,
								myRid: r,
								action: t.rid === e.active ? "pending" : null,
								anchorName: null,
								box: "size-9",
								img: "size-7"
							}), /* @__PURE__ */ m("span", {
								className: "manila-roster-copy",
								children: [
									/* @__PURE__ */ p("span", {
										className: "manila-roster-name",
										children: Ne(t, d)
									}),
									/* @__PURE__ */ m("span", {
										className: "manila-roster-numbers",
										"aria-label": `${u("games.manila.cash")} ${n.cash}, ${u("games.manila.shares")} ${n.shares.length}`,
										children: [
											"💰",
											n.cash,
											" · 🎫",
											n.shares.length,
											i > 0 ? ` (${i})` : ""
										]
									}),
									e.harbor === t.rid && /* @__PURE__ */ p("span", {
										className: "manila-roster-tag",
										children: u("games.manila.harborTag")
									})
								]
							})]
						}, t.rid);
					})
				})]
			}),
			actionsHeight: "h-16 wide:h-0",
			actions: /* @__PURE__ */ m("div", {
				className: "manila-mobile-actions wide:hidden",
				children: [H ? /* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-base manila-panel-toggle",
					onClick: () => z(R === "phase" ? null : "phase"),
					children: u(R === "phase" ? "games.manila.hideControls" : "games.manila.showControls")
				}) : /* @__PURE__ */ p("div", {
					className: "manila-mobile-primary",
					children: /* @__PURE__ */ p(Le, { ...U })
				}), ce && /* @__PURE__ */ p("button", {
					type: "button",
					className: "btn-quiet manila-finance-toggle",
					onClick: () => z(R === "finance" ? null : "finance"),
					children: u("games.manila.financeShort")
				})]
			}),
			overlay: /* @__PURE__ */ m("div", {
				className: "flex flex-col items-center gap-1 px-2 pb-2",
				children: [
					R === "phase" && H && /* @__PURE__ */ p("div", {
						className: "manila-control-overlay wide:hidden",
						children: /* @__PURE__ */ p(Le, { ...U })
					}),
					R === "finance" && ce && _ && /* @__PURE__ */ m("div", {
						className: "manila-control-overlay wide:hidden",
						children: [/* @__PURE__ */ p("p", {
							className: "manila-control-heading",
							children: u("games.manila.finance")
						}), /* @__PURE__ */ p(Re, {
							me: _,
							send: i
						})]
					}),
					e.lastRoll && (e.phase === "move" || e.phase === "portOrder" || e.phase === "pilot" || e.phase === "pirateBoard") && /* @__PURE__ */ m("div", {
						className: "plate flex items-center gap-2 px-2 py-1 text-xs font-bold",
						children: [/* @__PURE__ */ p("span", {
							className: "opacity-70",
							children: u("games.manila.lastRollTitle")
						}), e.lastRoll.map((e) => /* @__PURE__ */ m("span", {
							className: `flex items-center gap-1 rounded border px-1 font-mono tabular-nums ${J[e.good]}`,
							children: [
								u(`games.manila.${e.good}`),
								" ",
								/* @__PURE__ */ p(Fe, { n: e.die })
							]
						}, e.good))]
					})
				]
			}),
			scroll: !1,
			children: /* @__PURE__ */ m("div", {
				className: "manila-stage",
				children: [/* @__PURE__ */ m("div", {
					className: "manila-board-slot",
					children: [/* @__PURE__ */ p(De, {
						pub: e,
						members: t,
						myTurn: v,
						canPlaceAt: w,
						onPlace: se,
						portOrder: re,
						onPickOrder: (e) => ie((t) => t.includes(e) ? t.slice(0, t.indexOf(e)) : [...t, e]),
						pilotMoves: ae,
						raidDests: I
					}), e.settlement && (e.phase === "settle" || e.phase === "done") && /* @__PURE__ */ p("div", {
						className: "manila-settle-layer",
						children: /* @__PURE__ */ p(Ie, {
							pub: e,
							nameOf: f
						})
					})]
				}), /* @__PURE__ */ p("aside", {
					className: "manila-side-dock hidden wide:block",
					children: /* @__PURE__ */ p(Le, {
						...U,
						loanWindow: T
					})
				})]
			})
		})
	});
}
function Fe({ n: e }) {
	return /* @__PURE__ */ p("svg", {
		viewBox: "0 0 100 100",
		className: "inline-block size-4 rounded-sm border border-ink/40 bg-white align-[-2px]",
		"aria-hidden": !0,
		children: {
			1: [[50, 50]],
			2: [[28, 28], [72, 72]],
			3: [
				[25, 25],
				[50, 50],
				[75, 75]
			],
			4: [
				[28, 28],
				[72, 28],
				[28, 72],
				[72, 72]
			],
			5: [
				[25, 25],
				[75, 25],
				[50, 50],
				[25, 75],
				[75, 75]
			],
			6: [
				[28, 22],
				[72, 22],
				[28, 50],
				[72, 50],
				[28, 78],
				[72, 78]
			]
		}[e].map(([e, t], n) => /* @__PURE__ */ p("circle", {
			cx: e,
			cy: t,
			r: 11,
			className: "fill-ink"
		}, n))
	});
}
function Ie({ pub: e, nameOf: t }) {
	let n = o(), r = e.settlement;
	if (!r) return null;
	let i = {
		port: n("games.manila.outcomePort"),
		robbedPort: n("games.manila.outcomeRobbedPort"),
		robbedYard: n("games.manila.outcomeRobbedYard"),
		yard: n("games.manila.outcomeYard")
	};
	return /* @__PURE__ */ m("section", {
		className: "manila-settle-panel",
		"aria-label": n("games.manila.settleTitle"),
		"aria-live": "polite",
		children: [
			/* @__PURE__ */ m("header", {
				className: "manila-settle-header",
				children: [/* @__PURE__ */ p("strong", { children: n("games.manila.settleTitle") }), /* @__PURE__ */ p("span", { children: r.gameEnd ? n("games.manila.gameEndNote") : n("games.manila.settleNext") })]
			}),
			/* @__PURE__ */ p("p", {
				className: "manila-settle-heading",
				children: n("games.manila.settleShips")
			}),
			/* @__PURE__ */ p("div", {
				className: "manila-settle-ships",
				children: r.ships.map((e, t) => /* @__PURE__ */ m("span", {
					className: `manila-settle-ship manila-good-${e.good}`,
					children: [/* @__PURE__ */ p("span", {
						className: "manila-settle-cargo",
						children: n(`games.manila.${e.good}`)
					}), /* @__PURE__ */ p("span", { children: i[e.outcome] })]
				}, t))
			}),
			/* @__PURE__ */ p("p", {
				className: "manila-settle-heading",
				children: n("games.manila.settlePlayers")
			}),
			/* @__PURE__ */ p("div", {
				className: "manila-settle-players",
				children: e.players.map((e) => {
					let n = r.deltas[e.rid] ?? 0;
					return /* @__PURE__ */ m("span", {
						className: "manila-settle-player",
						children: [/* @__PURE__ */ p("span", { children: t(e.rid) }), /* @__PURE__ */ m("b", {
							"data-negative": n < 0,
							children: [
								"🪙",
								n > 0 ? "+" : n < 0 ? "−" : "",
								Math.abs(n)
							]
						})]
					}, e.rid);
				})
			}),
			(r.risen.length > 0 || r.insurancePaid > 0 || r.insuranceCovered > 0) && /* @__PURE__ */ p("p", {
				className: "manila-settle-heading",
				children: n("games.manila.settleMarket")
			}),
			/* @__PURE__ */ m("div", {
				className: "manila-settle-notes",
				children: [
					r.risen.map((e) => /* @__PURE__ */ p("span", {
						className: `manila-settle-rise manila-good-${e}`,
						children: n("games.manila.risenLine", { good: n(`games.manila.${e}`) })
					}, e)),
					r.insurancePaid > 0 && /* @__PURE__ */ p("span", { children: n("games.manila.insurancePaidLine", { n: r.insurancePaid }) }),
					r.insuranceCovered > 0 && /* @__PURE__ */ p("span", { children: n("games.manila.insuranceCoveredLine", { n: r.insuranceCovered }) })
				]
			}),
			e.phase === "done" && /* @__PURE__ */ p("div", {
				className: "manila-settle-fortunes",
				children: e.players.map((r) => {
					let i = r.shares.reduce((t, n) => t + O[e.market[n.good]], 0), a = r.shares.filter((e) => e.mortgaged).length * 15;
					return /* @__PURE__ */ p("span", { children: n("games.manila.fortuneLine", {
						name: t(r.rid),
						cash: r.cash,
						shares: i,
						debt: a,
						total: r.cash + i - a
					}) }, r.rid);
				})
			})
		]
	});
}
function Le({ pub: e, me: t, myRid: n, myTurn: r, loanWindow: i, nameOf: a, send: s, bid: c, setBid: l, deployGoods: u, setDeployGoods: d, deployStarts: f, setDeployStarts: h, portOrder: v, pilotMoves: y, setPilotMoves: b, raidDests: x, setRaidDests: S }) {
	let C = o(), w = i && t && t.shares.length > 0 ? /* @__PURE__ */ m("details", {
		className: "manila-finance-details",
		children: [/* @__PURE__ */ p("summary", { children: C("games.manila.finance") }), /* @__PURE__ */ p(Re, {
			me: t,
			send: s
		})]
	}) : null;
	if (e.phase === "auction" && e.auction) {
		let i = e.auction;
		if (!r || i.out.includes(n)) return /* @__PURE__ */ m(Y, {
			hint: C("games.manila.auctionIdle"),
			children: [i.highBy && /* @__PURE__ */ m("span", {
				className: "font-mono text-xs font-extrabold tabular-nums",
				children: [
					C("games.manila.bid"),
					" ",
					i.high,
					" · ",
					a(i.highBy)
				]
			}), w]
		});
		let o = t ? t.cash + t.shares.filter((e) => !e.mortgaged).length * 12 : 0, u = i.high + 1;
		return /* @__PURE__ */ m(Y, {
			hint: C("games.manila.bidHint", {
				n: i.high,
				m: o
			}),
			children: [/* @__PURE__ */ m("div", {
				className: "manila-bid-layout",
				children: [/* @__PURE__ */ m("div", {
					className: "manila-bid-stepper",
					children: [
						/* @__PURE__ */ p("button", {
							type: "button",
							"aria-label": "-",
							disabled: c <= u,
							onClick: () => l(Math.max(u, c - 1)),
							className: "btn-quiet min-h-12 font-mono text-lg",
							children: "−"
						}),
						/* @__PURE__ */ p("span", {
							className: "plate grid min-h-12 place-items-center font-mono text-xl font-extrabold tabular-nums",
							children: Math.max(c, u)
						}),
						/* @__PURE__ */ p("button", {
							type: "button",
							"aria-label": "+",
							disabled: c >= o,
							onClick: () => l(Math.min(o, Math.max(c, u) + 1)),
							className: "btn-quiet min-h-12 font-mono text-lg",
							children: "+"
						})
					]
				}), /* @__PURE__ */ m("div", {
					className: "manila-bid-decisions",
					children: [/* @__PURE__ */ p("button", {
						type: "button",
						disabled: c > o,
						onClick: () => s({
							type: "bid",
							amount: Math.max(c, u)
						}),
						className: "btn-base min-h-12 text-base",
						style: { background: g.accent },
						children: C("games.manila.bidConfirm")
					}), /* @__PURE__ */ p("button", {
						type: "button",
						onClick: () => s({ type: "passBid" }),
						className: "btn-quiet min-h-12 text-sm",
						children: C("games.manila.passBid")
					})]
				})]
			}), w]
		});
	}
	if (e.phase === "office") {
		if (!r) return /* @__PURE__ */ p(Y, {
			hint: e.active ? C("games.manila.waitingFor", { name: a(e.active) }) : "",
			children: null
		});
		if (e.officeStep === "share") return /* @__PURE__ */ m(Y, {
			hint: C("games.manila.officeBuyShare"),
			children: [/* @__PURE__ */ m("div", {
				className: "manila-share-grid",
				children: [_.map((n) => {
					let r = Math.max(5, O[e.market[n]]), i = e.supply[n] <= 0 || t !== void 0 && t.cash < r;
					return /* @__PURE__ */ m("button", {
						type: "button",
						disabled: i,
						onClick: () => s({
							type: "buyShare",
							good: n
						}),
						className: `btn-base min-h-12 flex-col px-2 text-xs leading-4 disabled:opacity-40 ${J[n]}`,
						children: [/* @__PURE__ */ p("span", { children: C(`games.manila.${n}`) }), /* @__PURE__ */ m("span", {
							className: "font-mono tabular-nums",
							children: [
								r,
								" · ",
								C("games.manila.supply", { n: e.supply[n] })
							]
						})]
					}, n);
				}), /* @__PURE__ */ p("button", {
					type: "button",
					onClick: () => s({ type: "skipShare" }),
					className: "btn-quiet manila-share-skip min-h-12 px-3 text-sm",
					children: C("games.manila.skipShare")
				})]
			}), w]
		});
		let n = u.reduce((e, t) => e + f[t], 0), i = u.length === 3 && n === 9;
		return /* @__PURE__ */ m(Y, {
			hint: `${C("games.manila.deployTitle")} · ${C("games.manila.deploySum", { n })}`,
			children: [
				/* @__PURE__ */ p("div", {
					className: "manila-goods-pick",
					children: _.map((e) => {
						let t = u.includes(e);
						return /* @__PURE__ */ p("button", {
							type: "button",
							"aria-pressed": t,
							disabled: !t && u.length >= 3,
							onClick: () => d(t ? u.filter((t) => t !== e) : [...u, e]),
							className: `min-h-11 rounded-lg border-2 px-1 text-xs font-extrabold disabled:opacity-40 ${t ? J[e] : "border-ink/30 opacity-60"}`,
							children: C(`games.manila.${e}`)
						}, e);
					})
				}),
				/* @__PURE__ */ p("div", {
					className: "manila-deploy-starts",
					children: u.map((e) => /* @__PURE__ */ m("span", {
						className: "manila-deploy-row",
						children: [
							/* @__PURE__ */ p("span", {
								className: `rounded border px-1 text-xs font-bold ${J[e]}`,
								children: C(`games.manila.${e}`)
							}),
							/* @__PURE__ */ p("button", {
								type: "button",
								"aria-label": `${C(`games.manila.${e}`)} −`,
								disabled: f[e] <= 0,
								onClick: () => h({
									...f,
									[e]: f[e] - 1
								}),
								className: "btn-quiet grid size-11 place-items-center font-mono",
								children: "−"
							}),
							/* @__PURE__ */ p("span", {
								className: "w-5 text-center font-mono text-base font-extrabold tabular-nums",
								children: f[e]
							}),
							/* @__PURE__ */ p("button", {
								type: "button",
								"aria-label": `${C(`games.manila.${e}`)} +`,
								disabled: f[e] >= 5,
								onClick: () => h({
									...f,
									[e]: f[e] + 1
								}),
								className: "btn-quiet grid size-11 place-items-center font-mono",
								children: "+"
							})
						]
					}, e))
				}),
				/* @__PURE__ */ p("div", {
					className: "manila-confirm-row",
					children: /* @__PURE__ */ p("button", {
						type: "button",
						disabled: !i,
						onClick: () => s({
							type: "deploy",
							goods: u,
							starts: u.map((e) => f[e])
						}),
						className: "btn-base min-h-12 w-full text-base disabled:opacity-40",
						style: { background: g.accent },
						children: C("games.manila.deployConfirm")
					})
				}),
				w
			]
		});
	}
	if (e.phase === "place") return r ? /* @__PURE__ */ m(Y, {
		hint: C("games.manila.placePrompt"),
		children: [/* @__PURE__ */ p("button", {
			type: "button",
			onClick: () => s({ type: "passPlace" }),
			className: "btn-quiet min-h-12 w-full text-sm",
			children: C("games.manila.passPlace")
		}), w]
	}) : /* @__PURE__ */ p(Y, {
		hint: e.active ? C("games.manila.waitingFor", { name: a(e.active) }) : "",
		children: t?.passed ? /* @__PURE__ */ p("span", {
			className: "text-xs font-bold opacity-60",
			children: C("games.manila.placePassed")
		}) : null
	});
	if (e.phase === "move") return r ? /* @__PURE__ */ p(Y, {
		hint: C("games.manila.legInfo", { n: e.leg }),
		children: /* @__PURE__ */ p("button", {
			type: "button",
			onClick: () => s({ type: "roll" }),
			className: "btn-base min-h-12 w-full text-base",
			style: { background: g.accent },
			children: C("games.manila.roll")
		})
	}) : /* @__PURE__ */ p(Y, {
		hint: C("games.manila.waitingRoll"),
		children: null
	});
	if (e.phase === "portOrder") return r ? /* @__PURE__ */ p(Y, {
		hint: C("games.manila.portOrderPrompt"),
		children: /* @__PURE__ */ m("button", {
			type: "button",
			disabled: v.length !== e.pendingArrivals.length,
			onClick: () => s({
				type: "portOrder",
				order: v
			}),
			className: "btn-base min-h-12 w-full text-base disabled:opacity-40",
			style: { background: g.accent },
			children: [
				C("games.manila.confirm"),
				" ",
				v.length,
				"/",
				e.pendingArrivals.length
			]
		})
	}) : /* @__PURE__ */ p(Y, {
		hint: e.active ? C("games.manila.waitingFor", { name: a(e.active) }) : "",
		children: null
	});
	if (e.phase === "pirateBoard") {
		if (!r) return /* @__PURE__ */ p(Y, {
			hint: e.active ? C("games.manila.waitingFor", { name: a(e.active) }) : "",
			children: null
		});
		let t = e.ships.map((e, t) => ({
			sh: e,
			i: t
		})).filter(({ sh: e }) => e.where === "sea" && e.pos === 13 && e.crew.length < k[e.good].seats.length);
		return /* @__PURE__ */ p(Y, {
			hint: C("games.manila.boardPrompt"),
			children: /* @__PURE__ */ m("div", {
				className: "manila-board-choices",
				children: [t.map(({ sh: e, i: t }) => /* @__PURE__ */ m("button", {
					type: "button",
					onClick: () => s({
						type: "board",
						ship: t
					}),
					className: `btn-base min-h-12 flex-1 text-sm ${J[e.good]}`,
					children: [
						C("games.manila.boardShip"),
						" · ",
						C(`games.manila.${e.good}`)
					]
				}, t)), /* @__PURE__ */ p("button", {
					type: "button",
					onClick: () => s({
						type: "board",
						ship: null
					}),
					className: "btn-quiet min-h-12 flex-none px-3 text-sm",
					children: C("games.manila.decline")
				})]
			})
		});
	}
	if (e.phase === "pilot" && e.pilotTurn) {
		let t = e.pilotTurn === "big";
		if (!r) return /* @__PURE__ */ p(Y, {
			hint: e.active ? C("games.manila.waitingFor", { name: a(e.active) }) : "",
			children: null
		});
		let n = e.ships.map((e, t) => ({
			sh: e,
			i: t
		})).filter(({ sh: e }) => e.where === "sea"), i = (e, t) => {
			b((() => {
				let n = y.filter((t) => t.ship !== e);
				if (y.find((t) => t.ship === e)?.delta === t) return n;
				if (Math.abs(t) === 2) return [{
					ship: e,
					delta: t
				}];
				let r = y.some((e) => Math.abs(e.delta) === 2) ? [] : n;
				return r.length >= 2 ? [...r.slice(1), {
					ship: e,
					delta: t
				}] : [...r, {
					ship: e,
					delta: t
				}];
			})());
		}, o = y.length > 0 && (t ? y.length <= 2 && (y.length === 2 ? y.every((e) => Math.abs(e.delta) === 1) : Math.abs(y[0].delta) <= 2) : y.length === 1 && Math.abs(y[0].delta) === 1);
		return /* @__PURE__ */ p(Y, {
			hint: C(t ? "games.manila.pilotBigPrompt" : "games.manila.pilotSmallPrompt"),
			children: /* @__PURE__ */ m("div", {
				className: "flex flex-col gap-1",
				children: [n.map(({ sh: e, i: n }) => {
					let r = y.find((e) => e.ship === n);
					return /* @__PURE__ */ m("div", {
						className: "manila-pilot-row",
						"data-big": t,
						children: [
							/* @__PURE__ */ p("span", {
								className: `rounded border px-1 text-[10px] font-bold ${J[e.good]}`,
								children: C(`games.manila.${e.good}`)
							}),
							/* @__PURE__ */ p("span", {
								className: "font-mono text-[10px] tabular-nums opacity-70",
								children: e.pos
							}),
							(t ? [
								-2,
								-1,
								1,
								2
							] : [-1, 1]).map((t) => /* @__PURE__ */ p("button", {
								type: "button",
								"aria-pressed": r?.delta === t,
								disabled: e.pos + t < 0,
								onClick: () => i(n, t),
								className: `min-h-11 min-w-11 rounded-lg border-2 font-mono text-sm font-extrabold disabled:opacity-35 ${r?.delta === t ? "border-ink bg-ink text-white" : "border-ink/30"}`,
								children: t > 0 ? `+${t}` : t
							}, t))
						]
					}, n);
				}), /* @__PURE__ */ m("div", {
					className: "manila-confirm-row",
					children: [/* @__PURE__ */ p("button", {
						type: "button",
						disabled: !o,
						onClick: () => s({
							type: "pilotMove",
							moves: y
						}),
						className: "btn-base min-h-12 flex-1 text-base disabled:opacity-40",
						style: { background: g.accent },
						children: C("games.manila.confirm")
					}), /* @__PURE__ */ p("button", {
						type: "button",
						onClick: () => s({
							type: "pilotMove",
							moves: []
						}),
						className: "btn-quiet min-h-12 flex-none px-3 text-sm",
						children: C("games.manila.pilotDone")
					})]
				})]
			})
		});
	}
	if (e.phase === "pirateRaid") {
		if (!r) return /* @__PURE__ */ p(Y, {
			hint: e.active ? C("games.manila.waitingFor", { name: a(e.active) }) : "",
			children: null
		});
		let t = 3 - e.ships.filter((e) => e.where === "port").length, n = x.filter((e) => e === "port").length;
		return /* @__PURE__ */ p(Y, {
			hint: C("games.manila.raidPrompt"),
			children: /* @__PURE__ */ m("div", {
				className: "flex flex-col gap-1",
				children: [e.raidQueue.map((r, i) => {
					let a = e.ships[r];
					return /* @__PURE__ */ m("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ p("span", {
							className: `rounded border px-1 text-[10px] font-bold ${J[a.good]}`,
							children: C(`games.manila.${a.good}`)
						}), ["port", "yard"].map((e) => /* @__PURE__ */ p("button", {
							type: "button",
							"aria-pressed": x[i] === e,
							disabled: e === "port" && x[i] !== "port" && n >= t,
							onClick: () => S(x.map((t, n) => n === i ? e : t)),
							className: `min-h-11 flex-1 rounded-lg border-2 px-2 text-xs font-extrabold disabled:opacity-35 ${x[i] === e ? "border-ink bg-ink text-white" : "border-ink/30"}`,
							children: C(e === "port" ? "games.manila.toPort" : "games.manila.toYard")
						}, e))]
					}, r);
				}), /* @__PURE__ */ p("div", {
					className: "manila-confirm-row",
					children: /* @__PURE__ */ p("button", {
						type: "button",
						disabled: x.length !== e.raidQueue.length,
						onClick: () => s({
							type: "raidChoose",
							dests: x
						}),
						className: "btn-base min-h-12 w-full text-base disabled:opacity-40",
						style: { background: g.accent },
						children: C("games.manila.confirm")
					})
				})]
			})
		});
	}
	return /* @__PURE__ */ p(Y, {
		hint: "",
		children: null
	});
}
function Y({ hint: e, children: t }) {
	return /* @__PURE__ */ m("div", {
		className: "manila-bar-shell flex min-h-full flex-col justify-start gap-1.5",
		children: [/* @__PURE__ */ p("p", {
			className: "flex-none truncate text-center text-xs font-bold opacity-70",
			children: e
		}), t]
	});
}
function Re({ me: e, send: t }) {
	let n = o();
	return e.shares.length === 0 ? null : /* @__PURE__ */ p("div", {
		className: "flex flex-wrap items-center gap-1",
		children: e.shares.map((r, i) => /* @__PURE__ */ m("button", {
			type: "button",
			disabled: r.mortgaged ? e.cash < 15 : !1,
			onClick: () => t(r.mortgaged ? {
				type: "redeem",
				good: r.good
			} : {
				type: "mortgage",
				good: r.good
			}),
			className: `min-h-11 rounded-lg border-2 px-2 text-[10px] leading-3.5 font-extrabold disabled:opacity-40 ${J[r.good]} ${r.mortgaged ? "opacity-55" : ""}`,
			children: [n(`games.manila.${r.good}`), /* @__PURE__ */ p("span", {
				className: "ml-1 font-mono tabular-nums",
				children: r.mortgaged ? n("games.manila.redeem") : n("games.manila.mortgage")
			})]
		}, i))
	});
}
//#endregion
//#region src/games/manila/bot.ts
var ze = {
	dilution: 0,
	passBias: 0,
	scarcityW: 2,
	denyW: 1,
	crewW: .5,
	futureVoyages: 2,
	sailProb: .3,
	shareMargin: 2,
	firstW: 0,
	loanInterest: 4.5,
	pilotW: .8,
	boardW: 1.5
}, Be = [
	1,
	2,
	3,
	4,
	5,
	6
];
function Ve(e) {
	let t = Array(e.length + 6).fill(0);
	return e.forEach((e, n) => {
		for (let r of Be) t[n + r] += e;
	}), t;
}
var X = [[1]], He = [1];
for (let e = 1; e <= 3; e += 1) X.push(Ve(X[e - 1])), He.push(He[e - 1] * 6);
function Z(e, t) {
	let n = 14 - e;
	if (n <= 0) return 1;
	if (t <= 0) return 0;
	let r = X[t];
	if (n >= r.length) return 0;
	let i = 0;
	for (let e = n; e < r.length; e += 1) i += r[e];
	return i / He[t];
}
function Q(e, t) {
	let n = 13 - e;
	return t <= 0 ? +(n === 0) : n < t || n >= X[t].length ? 0 : X[t][n] / He[t];
}
function $(e, t) {
	if (t <= 0) return 1;
	if (t > e.length) return 0;
	let n = [1];
	for (let t of e) {
		let e = Array(n.length + 1).fill(0);
		n.forEach((n, r) => {
			e[r] += n * (1 - t), e[r + 1] += n * t;
		}), n = e;
	}
	return n.slice(t).reduce((e, t) => e + t, 0);
}
function Ue(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var We = [
	[
		0,
		4,
		5
	],
	[
		1,
		3,
		5
	],
	[
		1,
		4,
		4
	],
	[
		2,
		2,
		5
	],
	[
		2,
		3,
		4
	],
	[
		3,
		3,
		3
	]
], Ge = [
	[
		0,
		1,
		2
	],
	[
		0,
		2,
		1
	],
	[
		1,
		0,
		2
	],
	[
		1,
		2,
		0
	],
	[
		2,
		0,
		1
	],
	[
		2,
		1,
		0
	]
];
function Ke(e, t) {
	let n = Math.min(O.length - 1 - e, Math.max(0, t)), r = Math.floor(n), i = n - r, a = O[e + r];
	return a + i * (O[Math.min(O.length - 1, e + r + 1)] - a);
}
function qe(e = {}) {
	let t = {
		...ze,
		...e
	};
	return (e, n) => {
		let r = e.public, i = n.rid;
		if (r.phase === "settle" || r.phase === "done" || r.active !== i) return null;
		let a = r.players.find((e) => e.rid === i);
		if (!a) return null;
		let o = n.difficulty === "weak", s = a.shares.filter((e) => !e.mortgaged), c = s.length * 12, l = (e) => a.shares.filter((t) => t.good === e).length, u = (e) => Math.max(0, ...r.players.filter((e) => e.rid !== i).map((t) => t.shares.filter((t) => t.good === e).length)), d = (e) => r.market[e] < O.length - 1 ? O[r.market[e] + 1] - O[r.market[e]] : 0, f = 3 - r.leg, p = r.ships.map((e, t) => ({
			sh: e,
			i: t
		})).filter(({ sh: e }) => e.where === "sea"), m = p.map(({ sh: e }) => Z(e.pos, f)), h = p.map(({ sh: e }) => Q(e.pos, f)), g = p.map((e, t) => Math.max(0, 1 - m[t] - h[t])), v = r.pirateBoat.filter((e) => e !== null), y = r.ships.filter((e) => e.where === "port").length, b = r.ships.filter((e) => e.where === "yard").length, x = () => {
			let e = [...s].sort((e, t) => O[r.market[e.good]] - O[r.market[t.good]])[0];
			return e ? {
				type: "mortgage",
				good: e.good
			} : null;
		};
		switch (r.phase) {
			case "auction": {
				let e = r.auction?.high ?? 0;
				if (o) return { action: e === 0 && a.cash > 0 ? {
					type: "bid",
					amount: 1
				} : { type: "passBid" } };
				let n = 0;
				for (let e of _) {
					if (r.supply[e] <= 0) continue;
					let i = Math.max(5, O[r.market[e]]);
					if (i > a.cash + c) continue;
					let o = Z(4, 3) + t.futureVoyages * t.sailProb;
					n = Math.max(n, Ke(r.market[e], o) - i);
				}
				let i = 0;
				for (let e of _) {
					let n = _.filter((t) => t !== e);
					for (let e of We) {
						let r = [...e].sort((e, t) => t - e);
						for (let e of Ge) {
							let a = 0;
							for (let i = 0; i < 3; i += 1) {
								let o = n[e[i]];
								a += Z(r[i], 3) * ((l(o) - t.denyW * u(o)) * d(o) + t.crewW * (k[o].profit / 2));
							}
							a > i && (i = a);
						}
					}
				}
				let s = Math.max(0, n) + i + t.firstW, f = e + 1;
				return f > a.cash && (s -= t.loanInterest), f <= s && f <= a.cash + c ? { action: {
					type: "bid",
					amount: f
				} } : { action: { type: "passBid" } };
			}
			case "office": {
				if (r.officeStep === "share") {
					if (o) return { action: { type: "skipShare" } };
					let e = null, n = -Infinity;
					for (let i of _) {
						if (r.supply[i] <= 0) continue;
						let o = Math.max(5, O[r.market[i]]);
						if (o > a.cash + c) continue;
						let s = Z(4, 3) + t.futureVoyages * t.sailProb, l = Ke(r.market[i], s) - o;
						l > n && (n = l, e = i);
					}
					if (!e || n <= t.shareMargin) return { action: { type: "skipShare" } };
					if (Math.max(5, O[r.market[e]]) > a.cash) {
						if (n <= t.shareMargin + t.loanInterest) return { action: { type: "skipShare" } };
						let e = x();
						return e ? { action: e } : { action: { type: "skipShare" } };
					}
					return { action: {
						type: "buyShare",
						good: e
					} };
				}
				if (o) return { action: {
					type: "deploy",
					goods: [..._].sort((e, t) => l(t) * 100 + k[t].profit - (l(e) * 100 + k[e].profit)).slice(0, 3),
					starts: Ue(We).slice().sort((e, t) => t - e)
				} };
				let e = null, n = null, i = -Infinity;
				for (let r of _) {
					let a = _.filter((e) => e !== r);
					for (let r of We) {
						let o = [...r].sort((e, t) => t - e);
						for (let r of Ge) {
							let s = [
								a[r[0]],
								a[r[1]],
								a[r[2]]
							], c = 0;
							for (let e = 0; e < 3; e += 1) c += Z(o[e], 3) * ((l(s[e]) - t.denyW * u(s[e])) * d(s[e]) + t.crewW * (k[s[e]].profit / 2));
							c > i && (i = c, e = s, n = o);
						}
					}
				}
				return { action: {
					type: "deploy",
					goods: e ?? [
						_[0],
						_[1],
						_[2]
					],
					starts: n ?? [
						5,
						4,
						0
					]
				} };
			}
			case "place": {
				let e = [];
				p.forEach(({ sh: n }, r) => {
					let i = k[n.good].seats;
					if (n.crew.length >= i.length) return;
					let a = i[n.crew.length], o = m[r] + (v.length === 0 ? h[r] : 0), s = n.crew.length + 1 + (f > 1 ? t.dilution : 0);
					e.push({
						spot: {
							kind: "ship",
							good: n.good
						},
						ev: o * k[n.good].profit / s - a,
						fee: a
					});
				});
				for (let t = 0; t < 3; t += 1) r.ports[t] === null && e.push({
					spot: {
						kind: "port",
						slot: t
					},
					ev: j[t] * $(m, t + 1 - y) - A[t],
					fee: A[t]
				}), r.yards[t] === null && e.push({
					spot: {
						kind: "yard",
						slot: t
					},
					ev: N[t] * $(g, t + 1 - b) - M[t],
					fee: M[t]
				});
				if (r.pirateBoat[1] === null && p.length > 0) {
					let n = v.length + 1, r = p.reduce((e, { sh: t }, r) => e + h[r] * k[t.good].profit / n, 0), i = 0;
					if (f >= 2) for (let { sh: e } of p) {
						let t = k[e.good].seats;
						if (e.crew.length >= t.length) continue;
						let n = Q(e.pos, f - 1);
						i = Math.max(i, n * k[e.good].profit / (e.crew.length + 1));
					}
					e.push({
						spot: { kind: "pirate" },
						ev: Math.max(r, t.boardW * i) - 5,
						fee: 5
					});
				}
				let n = (e, n) => {
					let r = 0;
					for (let { sh: t } of p) {
						let n = t.crew.filter((e) => e.rid === i).length * k[t.good].profit / Math.max(1, t.crew.length) + l(t.good) * d(t.good), a = v.includes(i) ? k[t.good].profit / v.length : 0;
						for (let i of e === 2 ? [2, 1] : [1]) {
							let e = t.pos + i, o = (Z(e, f) - Z(t.pos, f)) * n, s = (Q(e, f) - Q(t.pos, f)) * a;
							r = Math.max(r, o + s);
						}
					}
					return t.pilotW * r - n;
				};
				if (r.pilotSmall === null && e.push({
					spot: { kind: "pilotSmall" },
					ev: n(1, 2),
					fee: 2
				}), r.pilotBig === null && e.push({
					spot: { kind: "pilotBig" },
					ev: n(2, 5),
					fee: 5
				}), r.insurance === null) {
					let t = 0;
					for (let e = 0; e < 3; e += 1) r.yards[e] !== i && (t += N[e] * $(g, e + 1 - b));
					e.push({
						spot: { kind: "insurance" },
						ev: 10 - t,
						fee: 0
					});
				}
				if (o) {
					let t = e.filter((e) => e.fee <= a.cash), n = t.length > 0 ? t : e;
					return n.length === 0 || Ue([!0, !1]) ? { action: { type: "passPlace" } } : { action: {
						type: "place",
						spot: Ue(n).spot
					} };
				}
				let s = e.filter((e) => e.spot.kind !== "insurance"), u = s.length > 0 ? Math.min(...s.map((e) => e.fee)) : 0, _ = a.cash + c < u, S = (_ ? s : e).map((e) => _ ? {
					...e,
					ev: e.ev + e.fee - a.cash
				} : e);
				if (S.length === 0) return { action: { type: "passPlace" } };
				let C = S.reduce((e, t) => t.ev > e.ev ? t : e), w = r.players.length === 3 ? 4 : 3, T = r.ships.filter((e) => e.crew.some((e) => e.rid === i)).length + r.ports.filter((e) => e === i).length + r.yards.filter((e) => e === i).length + v.filter((e) => e === i).length + +(r.pilotSmall === i) + +(r.pilotBig === i) + +(r.insurance === i), E = r.placeRound < r.placeRoundsTotal, ee = t.passBias;
				w - T <= 1 && E && (ee += t.scarcityW);
				let D = !_ && C.fee > a.cash;
				if (C.ev <= ee + (D ? t.loanInterest : 0) || !_ && C.fee > a.cash + c) return { action: { type: "passPlace" } };
				if (D) {
					let e = x();
					return e ? { action: e } : { action: { type: "passPlace" } };
				}
				return { action: {
					type: "place",
					spot: C.spot
				} };
			}
			case "move": return { action: { type: "roll" } };
			case "portOrder": return { action: {
				type: "portOrder",
				order: [...r.pendingArrivals].sort((e, t) => l(r.ships[t].good) - l(r.ships[e].good))
			} };
			case "pirateBoard": {
				if (o) return { action: {
					type: "board",
					ship: null
				} };
				let e = r.ships.map((e, t) => ({
					sh: e,
					i: t
				})).filter(({ sh: e }) => e.where === "sea" && e.pos === 13 && e.crew.length < k[e.good].seats.length);
				if (e.length === 0) return { action: {
					type: "board",
					ship: null
				} };
				let t = v.length, n = p.reduce((e, { sh: n }) => e + Q(n.pos, 1) * k[n.good].profit / t, 0), i = e.reduce((e, t) => k[t.sh.good].profit / (t.sh.crew.length + 1) > k[e.sh.good].profit / (e.sh.crew.length + 1) ? t : e);
				return k[i.sh.good].profit / (i.sh.crew.length + 1) > n ? { action: {
					type: "board",
					ship: i.i
				} } : { action: {
					type: "board",
					ship: null
				} };
			}
			case "pilot": {
				if (o) return { action: {
					type: "pilotMove",
					moves: []
				} };
				let e = r.pilotTurn === "big", t = (e) => {
					let t = p.map(({ i: t }) => {
						let n = e(t), r = Z(n, 1), i = Q(n, 1);
						return {
							a: r,
							s: i,
							f: Math.max(0, 1 - r - i)
						};
					}), n = 0;
					p.forEach(({ sh: e }, r) => {
						let a = e.crew.filter((e) => e.rid === i).length * k[e.good].profit / Math.max(1, e.crew.length) + l(e.good) * d(e.good), o = v.length === 0 ? a : v.includes(i) ? k[e.good].profit / v.length : 0;
						n += t[r].a * a + t[r].s * o;
					});
					let a = t.map((e) => e.a), o = t.map((e) => e.f);
					for (let e = 0; e < 3; e += 1) r.ports[e] === i && (n += j[e] * $(a, e + 1 - y)), r.yards[e] === i ? n += N[e] * $(o, e + 1 - b) : r.insurance === i && (n -= N[e] * $(o, e + 1 - b));
					return n;
				}, n = [[]];
				for (let { i: t } of p) {
					let i = e ? [
						-2,
						-1,
						1,
						2
					] : [-1, 1];
					for (let e of i) r.ships[t].pos + e >= 0 && n.push([{
						ship: t,
						delta: e
					}]);
				}
				if (e) for (let e = 0; e < p.length; e += 1) for (let t = e + 1; t < p.length; t += 1) for (let i of [-1, 1]) for (let a of [-1, 1]) r.ships[p[e].i].pos + i < 0 || r.ships[p[t].i].pos + a < 0 || n.push([{
					ship: p[e].i,
					delta: i
				}, {
					ship: p[t].i,
					delta: a
				}]);
				let a = [], s = t((e) => r.ships[e].pos);
				for (let e of n) {
					if (e.length === 0) continue;
					let n = new Map(e.map((e) => [e.ship, r.ships[e.ship].pos + e.delta])), i = t((e) => n.get(e) ?? r.ships[e].pos);
					i > s + 1e-9 && (s = i, a = e);
				}
				return { action: {
					type: "pilotMove",
					moves: a
				} };
			}
			case "pirateRaid": {
				let e = 3 - r.ships.filter((e) => e.where === "port").length, t = r.raidQueue.map((e) => {
					let t = r.ships[e].good, n = l(t) * d(t) + (r.ports.some((e) => e === i) ? j[0] : 0), a = (r.yards.some((e) => e === i) ? N[0] : 0) - (r.insurance === i ? N[0] : 0);
					return {
						i: e,
						diff: o ? 1 : n - a
					};
				});
				t.sort((e, t) => t.diff - e.diff);
				let n = /* @__PURE__ */ new Map();
				return t.forEach(({ i: t, diff: r }, i) => {
					n.set(t, i < e && r > 0 ? "port" : "yard");
				}), { action: {
					type: "raidChoose",
					dests: r.raidQueue.map((e) => n.get(e) ?? "yard")
				} };
			}
			default: return null;
		}
	};
}
var Je = qe();
//#endregion
//#region src/games/manila/game-over.tsx
function Ye(e) {
	return /* @__PURE__ */ p("div", {
		className: "manila-over",
		children: /* @__PURE__ */ p(h, {
			...e,
			accent: g.accent
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/manila/entry.tsx
var Xe = {
	definition: be,
	View: Me,
	bot: Je,
	OverView: Ye,
	locales: {
		zh: {
			name: "马尼拉",
			desc: "竞拍港务长、装船出航,在走私船能否抵达马尼拉的赌局中分利",
			rules: "目标:\n· 任一货物的黑市价升到三十时游戏结束,现金加持股价值最高者获胜;并列则共同获胜。\n航次:\n· 每航次先拍卖港务长:轮流出价或弃权,弃权后不得再出价;出价不得超过现金加可贷款之和。\n· 港务长可购买一股股票(价格为该货黑市现价,至少五比索),随后选定三种货物装船,并指定三艘船的起点(各零至五格,之和恰为九)。\n· 之后放置与移动交替:放置轮每人依次放置一个同伙或弃权,弃权后本航次不得再放置;移动轮由港务长掷三颗货色骰,三艘船各自前进。\n· 船超过十三格即入港,按到港顺序停靠港口;正好停在十三格会触发海盗。\n· 第三轮移动前,小领航员可将一艘船移动一格,大领航员可将一艘船移动两格或两艘船各一格;被推过十三格的船直接入港。\n· 三人局每人有四个同伙,首次移动前连续放置两轮。\n工位收益:\n· 船上同伙:船入港后平分利润,人参十八、豆蔻二十四、丝绸三十、玉石三十六;放置时必须坐最便宜的空位。\n· 港口三位(费用四、三、二):第一、二、三艘入港船分别使租户获得六、八、十五,由金库支付。\n· 船厂三位(费用四、三、二):未能入港的船依次进厂,租户获得六、八、十五,由保险员支付;无保险员时由金库支付。\n· 海盗船两位(各五):第二轮移动后停在十三格的船可被登船,登船者成为船上同伙。\n· 第三轮移动后停在十三格的船被抢劫:船员空手而归,海盗平分利润,船长决定被劫船送港口还是船厂。\n· 保险(免费):立即获得十比索,但须为每艘进厂船支付修理费;现金不足必须抵押贷款,仍不足由金库垫付且不用偿还。\n· 黑市:送入港口的货物升值一档;终局时每张持股按现价计值,未赎回的抵押股每张扣十五。\n其他:\n· 贷款:轮到自己行动时可抵押一张未抵押股票换取十二比索,赎回需支付十五比索。\n· 盲乘客:现金加可贷款仍付不起最便宜空位时,可付清全部现金免费放置到除保险外的任意空位。",
			phaseAuction: "拍卖港务长",
			phaseOffice: "港务长履职",
			phasePlace: "放置同伙",
			phaseMove: "移动船只",
			phasePortOrder: "入港排序",
			phasePirateBoard: "海盗登船",
			phasePilot: "领航员行动",
			phasePirateRaid: "海盗分赃",
			phaseSettle: "航次结算",
			phaseDone: "游戏结束",
			voyage: "第 {{n}} 航次",
			placeRoundInfo: "放置轮 {{n}} / {{total}}",
			legInfo: "移动轮 {{n}} / 3",
			ginseng: "人参",
			nutmeg: "豆蔻",
			silk: "丝绸",
			jade: "玉石",
			harborTag: "港务长",
			cash: "现金",
			shares: "股票",
			mortgaged: "已抵押",
			marketPrice: "黑市价",
			supply: "可购 {{n}} 股",
			profit: "利润 {{n}}",
			fee: "费用 {{n}}",
			pay: "赔付 {{n}}",
			port: "港口",
			yard: "船厂",
			pirateBoat: "海盗船",
			pirateShort: "海盗",
			captain: "船长",
			pilotSmall: "小领航员",
			pilotSmallShort: "小领航",
			pilotBig: "大领航员",
			pilotBigShort: "大领航",
			yardShort: "船厂",
			insurance: "保险",
			insuranceInfo: "免费放置,立即获得十比索;须赔付进厂船修理费",
			bid: "出价",
			bidConfirm: "确认出价",
			bidHint: "须高于 {{n}},不超过 {{m}}",
			passBid: "放弃出价",
			auctionIdle: "等待其他玩家出价",
			officeBuyShare: "可购买一股股票",
			skipShare: "放弃购股",
			deployTitle: "装船出航",
			deployPick: "选择三种装船货物",
			deployStarts: "指定三艘船的起点",
			deploySum: "起点之和 {{n}} / 9",
			deployConfirm: "确认出航",
			placePrompt: "放置一个同伙",
			passPlace: "弃权(本航次不再放置)",
			placePassed: "你已弃权",
			roll: "掷骰移动",
			waitingRoll: "等待港务长掷骰",
			lastRollTitle: "本轮骰点",
			portOrderPrompt: "同轮到港:点击船只排定入港顺序",
			confirm: "确认",
			boardPrompt: "可登上一艘停在十三格的船,或放弃",
			boardShip: "登船",
			decline: "放弃",
			pilotSmallPrompt: "小领航员:将一艘船移动一格",
			pilotBigPrompt: "大领航员:将一艘船移动两格,或两艘船各一格",
			pilotDone: "完成推移",
			raidPrompt: "决定每艘被劫船的去向",
			toPort: "送港口",
			toYard: "送船厂",
			mortgage: "抵押 +12",
			redeem: "赎回 −15",
			finance: "股票与贷款",
			financeShort: "借贷",
			showControls: "展开操作",
			hideControls: "收起操作",
			myTurn: "轮到你",
			waitingFor: "等待 {{name}}",
			settleTitle: "航次结算",
			settleShips: "船只去向",
			settlePlayers: "结算收支",
			settleMarket: "黑市与保险",
			outcomePort: "入港",
			outcomeRobbedPort: "被劫送港",
			outcomeRobbedYard: "被劫进厂",
			outcomeYard: "进厂修理",
			crewPayLine: "{{name}} 分得 {{n}}",
			lootLine: "海盗 {{name}} 分得 {{n}}",
			portPayLine: "港口租户 {{name}} 获得 {{n}}",
			yardPayLine: "船厂租户 {{name}} 获得 {{n}}",
			insurancePaidLine: "保险员支付修理费 {{n}}",
			insuranceCoveredLine: "金库垫付 {{n}}",
			risenLine: "{{good}} 升值",
			settleNext: "下一航次即将开始",
			gameEndNote: "有货物黑市价达到三十,游戏结束",
			fortuneLine: "{{name}}:现金 {{cash}} + 股票 {{shares}} − 抵押罚扣 {{debt}} = {{total}}",
			errPhase: "当前阶段无法执行此操作",
			errNotTurn: "还没轮到你行动",
			errBidLow: "出价必须高于当前最高出价",
			errBidHigh: "出价超出现金与可贷款之和",
			errSpotTaken: "该位置已被占用或不可用",
			errCash: "现金不足,可先抵押股票贷款",
			errNoShare: "该货物的股票已售罄",
			errNoUnmortgaged: "没有该货物的未抵押股票",
			errNoMortgaged: "没有该货物的已抵押股票",
			errBadDeploy: "须选择三种货物,且三个起点之和恰为九",
			errBadOrder: "入港顺序与待到港船不符",
			errBadBoard: "只能登上停在十三格且有空位的船",
			errBadPilot: "领航员推移不符合规则",
			errBadRaid: "去向数量不符或港口泊位不足"
		},
		en: {
			name: "Manila",
			desc: "Bid for the harbor master, load the punts, and profit from smuggling runs to Manila",
			rules: "Goal:\n· The game ends when any ware reaches 30 on the black market; the highest fortune of cash plus share values wins. Ties share the win.\nVoyage:\n· Each voyage opens with an auction for harbor master: bid or pass in turn; passing is final for the auction. You may not bid more than your cash plus possible loans.\n· The harbor master may buy one share (its black market price, at least 5), chooses three wares to load, and sets the punts' starting spaces (0 to 5 each, summing to exactly 9).\n· Placing and movement rounds alternate: in a placing round each player places one accomplice or passes (passing ends your placing for the voyage); in a movement round the harbor master rolls the three ware dice and each punt advances.\n· A punt beyond space 13 reaches port, docking in arrival order; a punt ending exactly on space 13 attracts pirates.\n· Before the third movement round, the small pilot may move one punt by one space, and the large pilot one punt by two spaces or two punts by one each; a punt pushed past 13 arrives at once.\n· With three players, everyone has four accomplices and there are two placing rounds before the first movement.\nSpots:\n· Punt crews share the profit when their punt arrives: ginseng 18, nutmeg 24, silk 30, jade 36; you must take the cheapest vacant seat.\n· Ports (fee 4/3/2): the 1st, 2nd and 3rd arriving punts pay their tenants 6/8/15 from the harbor cash box.\n· Shipyards (fee 4/3/2): punts that fail to arrive land here in order and pay tenants 6/8/15, paid by the insurance agent, or by the cash box if there is none.\n· Pirate boat (5 each): punts on space 13 after the second movement may be boarded, and boarders join the crew.\n· Punts on space 13 after the third movement are plundered: the crew leaves empty-handed, the pirates split the profit, and the captain sends each plundered punt to port or shipyard.\n· Insurance (free): take 10 at once, but pay the repair cost for every punt landing in the shipyard; if short of cash you must mortgage shares, and any remainder is covered by the cash box for free.\n· Black market: wares delivered to port rise one step; at game end each share scores its current value, and each mortgaged share costs you 15.\nOther rules:\n· Loans: on your turn you may mortgage an unencumbered share for 12; redeeming it later costs 15.\n· Blind passenger: if your cash plus possible loans cannot cover the cheapest vacant spot, you may place for free (paying all your cash) on any vacant spot except insurance.",
			phaseAuction: "Auctioning the harbor master",
			phaseOffice: "Harbor master duties",
			phasePlace: "Place accomplices",
			phaseMove: "Move punts",
			phasePortOrder: "Arrival order",
			phasePirateBoard: "Pirates boarding",
			phasePilot: "Pilots act",
			phasePirateRaid: "Pirate plunder",
			phaseSettle: "Voyage settlement",
			phaseDone: "Game over",
			voyage: "Voyage {{n}}",
			placeRoundInfo: "Placing round {{n}} / {{total}}",
			legInfo: "Movement round {{n}} / 3",
			ginseng: "Ginseng",
			nutmeg: "Nutmeg",
			silk: "Silk",
			jade: "Jade",
			harborTag: "Harbor master",
			cash: "Cash",
			shares: "Shares",
			mortgaged: "Mortgaged",
			marketPrice: "Market price",
			supply: "{{n}} for sale",
			profit: "Profit {{n}}",
			fee: "Fee {{n}}",
			pay: "Pays {{n}}",
			port: "Port",
			yard: "Shipyard",
			pirateBoat: "Pirate boat",
			pirateShort: "Pirates",
			captain: "Captain",
			pilotSmall: "Small pilot",
			pilotSmallShort: "Pilot S",
			pilotBig: "Large pilot",
			pilotBigShort: "Pilot L",
			yardShort: "Yard",
			insurance: "Insurance",
			insuranceInfo: "Free to place, gain 10 at once; pays repairs for shipyard punts",
			bid: "Bid",
			bidConfirm: "Confirm bid",
			bidHint: "Must beat {{n}}, at most {{m}}",
			passBid: "Pass",
			auctionIdle: "Waiting for other bids",
			officeBuyShare: "You may buy one share",
			skipShare: "Skip purchase",
			deployTitle: "Load and launch",
			deployPick: "Choose three wares to load",
			deployStarts: "Set each punt's starting space",
			deploySum: "Sum of starts {{n}} / 9",
			deployConfirm: "Launch",
			placePrompt: "Place one accomplice",
			passPlace: "Pass (no more placing this voyage)",
			placePassed: "You have passed",
			roll: "Roll and move",
			waitingRoll: "Waiting for the harbor master to roll",
			lastRollTitle: "Dice rolled",
			portOrderPrompt: "Simultaneous arrival: tap punts to set docking order",
			confirm: "Confirm",
			boardPrompt: "Board a punt on space 13, or decline",
			boardShip: "Board",
			decline: "Decline",
			pilotSmallPrompt: "Small pilot: move one punt by one space",
			pilotBigPrompt: "Large pilot: move one punt by two spaces, or two punts by one each",
			pilotDone: "Done moving",
			raidPrompt: "Choose where each plundered punt goes",
			toPort: "To port",
			toYard: "To shipyard",
			mortgage: "Mortgage +12",
			redeem: "Redeem −15",
			finance: "Shares & loans",
			financeShort: "Loans",
			showControls: "Show controls",
			hideControls: "Hide controls",
			myTurn: "Your turn",
			waitingFor: "Waiting for {{name}}",
			settleTitle: "Voyage settlement",
			settleShips: "Punt outcomes",
			settlePlayers: "Settlement changes",
			settleMarket: "Market & insurance",
			outcomePort: "Arrived",
			outcomeRobbedPort: "Plundered, sent to port",
			outcomeRobbedYard: "Plundered, sent to shipyard",
			outcomeYard: "In for repairs",
			crewPayLine: "{{name}} earns {{n}}",
			lootLine: "Pirate {{name}} earns {{n}}",
			portPayLine: "Port tenant {{name}} earns {{n}}",
			yardPayLine: "Shipyard tenant {{name}} earns {{n}}",
			insurancePaidLine: "Insurance pays repairs of {{n}}",
			insuranceCoveredLine: "The cash box covers {{n}}",
			risenLine: "{{good}} rises in value",
			settleNext: "The next voyage begins soon",
			gameEndNote: "A ware reached 30 on the black market — game over",
			fortuneLine: "{{name}}: cash {{cash}} + shares {{shares}} − mortgage penalty {{debt}} = {{total}}",
			errPhase: "This action is not available now",
			errNotTurn: "Not your turn yet",
			errBidLow: "Your bid must beat the current highest bid",
			errBidHigh: "Your bid exceeds your cash plus possible loans",
			errSpotTaken: "That spot is occupied or unavailable",
			errCash: "Not enough cash; mortgage a share for a loan first",
			errNoShare: "Shares of that ware are sold out",
			errNoUnmortgaged: "No unencumbered share of that ware",
			errNoMortgaged: "No mortgaged share of that ware",
			errBadDeploy: "Choose three wares, with starting spaces summing to exactly 9",
			errBadOrder: "The order does not match the arriving punts",
			errBadBoard: "You may only board a punt on space 13 with a vacant seat",
			errBadPilot: "That pilot move is not allowed",
			errBadRaid: "Destinations mismatch, or no vacant port space"
		}
	}
};
//#endregion
export { Xe as default };
