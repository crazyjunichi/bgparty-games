import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useId as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as s } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as f, seatName as p } from "@bgparty/sdk/ui/player-strip";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { Floater as _, FlySprite as v, PulseBox as y } from "@bgparty/sdk/fx/primitives";
import { AVATARS as b } from "@bgparty/sdk/avatars";
import { ConfirmButton as x } from "@bgparty/sdk/confirm-button";
import { IconClose as ee } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as S } from "@bgparty/sdk/player-colors";
import { Confetti as te } from "@bgparty/sdk/ui/confetti";
import { GameOverScreen as C } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/castlecombo/cards.ts
var w = [
	"nobility",
	"faith",
	"scholarship",
	"military",
	"craftsmanship",
	"peasantry"
];
function T(e) {
	return e.scoring.cond.type === "perPurseGold" ? e.scoring.cond.limit : 0;
}
function E(e) {
	return `games.castlecombo.card.${e.toLowerCase()}`;
}
var D = [
	{
		id: "Steward",
		place: "castle",
		cost: 0,
		shields: ["nobility"],
		effects: [{
			type: "putGold",
			cardsLimit: 2
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perPurseGold",
				limit: 3
			}
		}
	},
	{
		id: "Scribe",
		place: "castle",
		cost: 4,
		shields: ["faith"],
		messenger: !0,
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "faith"
			}
		}],
		scoring: {
			score: 3,
			cond: {
				type: "perShield",
				shield: "scholarship",
				line: !0,
				column: !0
			}
		}
	},
	{
		id: "MotherSuperior",
		place: "castle",
		cost: 5,
		shields: ["faith", "faith"],
		effects: [{
			type: "gainKeys",
			gain: 4
		}],
		scoring: {
			score: 5,
			cond: {
				type: "ifPosition",
				pos: [
					[
						!0,
						!0,
						!0
					],
					[
						!1,
						!1,
						!1
					],
					[
						!1,
						!1,
						!1
					]
				]
			}
		}
	},
	{
		id: "HisHoliness",
		place: "castle",
		cost: 7,
		shields: ["faith"],
		effects: [{
			type: "gainKeys",
			gain: 3,
			opponentsGain: 1
		}],
		scoring: {
			score: 6,
			cond: { type: "perMissingShield" }
		}
	},
	{
		id: "Chaplain",
		place: "castle",
		cost: 5,
		shields: ["faith"],
		messenger: !0,
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: {
				type: "perCardShieldCount",
				count: 1
			}
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perBanner",
				place: "village"
			}
		}
	},
	{
		id: "Cardinal",
		place: "castle",
		cost: 4,
		shields: ["faith"],
		effects: [{
			type: "gainKeys",
			gain: 1,
			cond: {
				type: "perBanner",
				place: "castle"
			}
		}],
		scoring: {
			score: 3,
			cond: {
				type: "perShield",
				shield: "faith",
				line: !0
			}
		}
	},
	{
		id: "Templar",
		place: "castle",
		cost: 5,
		shields: ["faith", "military"],
		messenger: !0,
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: {
				type: "bestNeighbor",
				cond: {
					type: "perShield",
					shield: "faith"
				}
			}
		}, {
			type: "gainKeys",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "military"
			}
		}],
		scoring: {
			score: 1,
			cond: { type: "perKey" }
		}
	},
	{
		id: "Gravedigger",
		place: "castle",
		cost: 4,
		shields: ["faith", "scholarship"],
		effects: [{
			type: "discardRiver",
			river: "village",
			token: "gold"
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perPurseGold",
				limit: 8
			}
		}
	},
	{
		id: "Alchemist",
		place: "castle",
		cost: 6,
		shields: ["scholarship"],
		effects: [{
			type: "discount",
			castle: 1,
			village: 1
		}],
		scoring: {
			score: 4,
			cond: { type: "perCardDiscount" }
		}
	},
	{
		id: "Astronomer",
		place: "castle",
		cost: 5,
		shields: ["scholarship", "scholarship"],
		effects: [{
			type: "discount",
			castle: 1
		}],
		scoring: {
			score: 8,
			cond: {
				type: "ifPosition",
				pos: [
					[
						!0,
						!1,
						!1
					],
					[
						!0,
						!1,
						!1
					],
					[
						!0,
						!1,
						!1
					]
				]
			}
		}
	},
	{
		id: "Pilgrim",
		place: "castle",
		cost: 6,
		shields: ["faith"],
		messenger: !0,
		effects: [{
			type: "discount",
			village: 1
		}],
		scoring: {
			score: 4,
			cond: {
				type: "perDifferentShield",
				line: !0
			}
		}
	},
	{
		id: "Devout",
		place: "castle",
		cost: 4,
		shields: ["faith"],
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: { type: "perEmpty" }
		}],
		scoring: {
			score: 10,
			cond: {
				type: "ifShieldMissing",
				shield: "craftsmanship"
			}
		}
	},
	{
		id: "Nun",
		place: "castle",
		cost: 3,
		shields: ["faith"],
		messenger: !0,
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: {
				type: "perBanner",
				place: "castle"
			}
		}],
		scoring: {
			score: 3,
			cond: {
				type: "perShield",
				shield: "faith",
				column: !0
			}
		}
	},
	{
		id: "Architect",
		place: "castle",
		cost: 4,
		shields: ["scholarship"],
		messenger: !0,
		effects: [{
			type: "discount",
			village: 1
		}],
		scoring: {
			score: 2,
			cond: { type: "perDifferentShield" }
		}
	},
	{
		id: "Goldsmith",
		place: "castle",
		cost: 4,
		shields: ["scholarship", "craftsmanship"],
		messenger: !0,
		effects: [{
			type: "gainKeys",
			gain: 1,
			cond: {
				type: "perCardShieldCount",
				count: 2
			}
		}],
		scoring: {
			score: 6,
			cond: {
				type: "ifPosition",
				pos: [
					[
						!0,
						!1,
						!1
					],
					[
						!0,
						!1,
						!1
					],
					[
						!0,
						!1,
						!1
					]
				]
			}
		}
	},
	{
		id: "Apothecary",
		place: "castle",
		cost: 3,
		shields: ["scholarship"],
		messenger: !0,
		effects: [{
			type: "discount",
			castle: 1
		}],
		scoring: {
			score: 3,
			cond: {
				type: "perShield",
				shield: "scholarship",
				column: !0
			}
		}
	},
	{
		id: "Professor",
		place: "castle",
		cost: 4,
		shields: ["scholarship"],
		messenger: !0,
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: { type: "perDifferentShield" }
		}],
		scoring: {
			score: 3,
			cond: {
				type: "perShield",
				shield: "scholarship",
				line: !0
			}
		}
	},
	{
		id: "Officer",
		place: "castle",
		cost: 5,
		shields: ["military"],
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "nobility"
			}
		}, {
			type: "gainGold",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "military"
			}
		}],
		scoring: {
			score: 4,
			cond: {
				type: "perShieldSet",
				shields: ["nobility", "military"]
			}
		}
	},
	{
		id: "Captain",
		place: "castle",
		cost: 5,
		shields: ["military", "military"],
		messenger: !0,
		effects: [{
			type: "discount",
			village: 1
		}],
		scoring: {
			score: 8,
			cond: {
				type: "ifPosition",
				pos: [
					[
						!1,
						!1,
						!0
					],
					[
						!1,
						!1,
						!0
					],
					[
						!1,
						!1,
						!0
					]
				]
			}
		}
	},
	{
		id: "Judge",
		place: "castle",
		cost: 4,
		shields: ["scholarship"],
		messenger: !0,
		effects: [{
			type: "gainKeys",
			gain: 2
		}],
		scoring: {
			score: 3,
			cond: {
				type: "perBannerSet",
				places: ["castle", "village"]
			}
		}
	},
	{
		id: "Patron",
		place: "castle",
		cost: 7,
		shields: ["scholarship"],
		effects: [{
			type: "gainGold",
			gain: 0,
			opponentsGain: 2
		}],
		scoring: {
			score: 5,
			cond: {
				type: "perCardCost",
				cost: 5,
				orGreater: !0
			}
		}
	},
	{
		id: "Guildmaster",
		place: "castle",
		cost: 5,
		shields: ["craftsmanship", "craftsmanship"],
		messenger: !0,
		effects: [{
			type: "discardRiver",
			river: "village",
			token: "key"
		}],
		scoring: {
			score: 5,
			cond: {
				type: "ifPosition",
				pos: [
					[
						!1,
						!1,
						!1
					],
					[
						!1,
						!1,
						!1
					],
					[
						!0,
						!0,
						!0
					]
				]
			}
		}
	},
	{
		id: "General",
		place: "castle",
		cost: 7,
		shields: ["military"],
		effects: [{
			type: "gainKeys",
			gain: 1,
			cond: { type: "perDifferentShield" }
		}],
		scoring: {
			score: 6,
			cond: {
				type: "perIdenticalSet",
				count: 3
			}
		}
	},
	{
		id: "Knight",
		place: "castle",
		cost: 5,
		shields: ["military"],
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: {
				type: "perBanner",
				place: "castle"
			}
		}],
		scoring: {
			score: 3,
			cond: {
				type: "perShield",
				shield: "nobility",
				line: !0,
				column: !0
			}
		}
	},
	{
		id: "Lookout",
		place: "castle",
		cost: 6,
		shields: ["military"],
		effects: [{
			type: "gainKeys",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "military"
			}
		}],
		scoring: {
			score: 4,
			cond: {
				type: "perDifferentShield",
				column: !0
			}
		}
	},
	{
		id: "RoyalGuard",
		place: "castle",
		cost: 4,
		shields: ["nobility", "military"],
		messenger: !0,
		effects: [{
			type: "gainKeys",
			gain: 1,
			opponentsGain: 1
		}],
		scoring: {
			score: 3,
			cond: {
				type: "perShield",
				shield: "nobility",
				column: !0
			}
		}
	},
	{
		id: "Banker",
		place: "castle",
		cost: 7,
		shields: ["craftsmanship"],
		messenger: !0,
		effects: [{
			type: "choose",
			a: {
				type: "putGold",
				gold: 2
			},
			b: {
				type: "gainKeys",
				gain: 3
			}
		}],
		scoring: {
			score: 1,
			cond: { type: "perAllPurseGold" }
		}
	},
	{
		id: "Pawnbroker",
		place: "castle",
		cost: 4,
		shields: ["craftsmanship"],
		messenger: !0,
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: {
				type: "perCardCost",
				cost: 4
			}
		}],
		scoring: {
			score: 3,
			cond: {
				type: "perCardCost",
				cost: 4
			}
		}
	},
	{
		id: "Chatelaine",
		place: "castle",
		cost: 2,
		shields: ["nobility", "craftsmanship"],
		effects: [{
			type: "discount",
			castle: 1
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perDifferentShield",
				line: !0
			}
		}
	},
	{
		id: "Glassblower",
		place: "castle",
		cost: 5,
		shields: ["craftsmanship"],
		messenger: !0,
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "faith"
			}
		}, {
			type: "gainGold",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "craftsmanship"
			}
		}],
		scoring: {
			score: 4,
			cond: {
				type: "perShieldSet",
				shields: ["faith", "craftsmanship"]
			}
		}
	},
	{
		id: "Princess",
		place: "castle",
		cost: 3,
		shields: ["nobility"],
		messenger: !0,
		effects: [{
			type: "discount",
			castle: 1
		}],
		scoring: {
			score: 3,
			cond: {
				type: "perShield",
				shield: "nobility",
				line: !0
			}
		}
	},
	{
		id: "Prince",
		place: "castle",
		cost: 6,
		shields: ["nobility"],
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "nobility"
			}
		}],
		scoring: {
			score: 4,
			cond: {
				type: "perShield",
				shield: "nobility",
				line: !0
			}
		}
	},
	{
		id: "HisMajesty",
		place: "castle",
		cost: 6,
		shields: ["nobility", "faith"],
		messenger: !0,
		effects: [{
			type: "gainGold",
			gain: 0,
			opponentsGain: 1
		}],
		scoring: {
			score: 4,
			cond: {
				type: "perShield",
				shield: "nobility",
				column: !0
			}
		}
	},
	{
		id: "QueenMother",
		place: "castle",
		cost: 3,
		shields: ["nobility", "nobility"],
		effects: [{
			type: "putGold",
			gold: 2
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perPurseGold",
				limit: 5
			}
		}
	},
	{
		id: "Jester",
		place: "castle",
		cost: 3,
		shields: ["nobility"],
		messenger: !0,
		effects: [{
			type: "gainGold",
			gain: 2,
			cond: {
				type: "perShield",
				shield: "nobility"
			}
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perShield",
				shield: "nobility",
				line: !0,
				column: !0
			}
		}
	},
	{
		id: "Chancellor",
		place: "castle",
		cost: 6,
		shields: ["nobility", "scholarship"],
		effects: [{
			type: "gainKeys",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "scholarship"
			}
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perBanner",
				place: "castle"
			}
		}
	},
	{
		id: "Baron",
		place: "castle",
		cost: 3,
		shields: ["nobility"],
		effects: [{
			type: "discount",
			castle: 1,
			village: 1
		}],
		scoring: {
			score: 10,
			cond: {
				type: "ifShieldMissing",
				shield: "peasantry"
			}
		}
	},
	{
		id: "HerMajestyTheQueen",
		place: "castle",
		cost: 7,
		shields: ["nobility"],
		effects: [{
			type: "gainKeys",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "nobility"
			}
		}],
		scoring: {
			score: 10,
			cond: {
				type: "perShieldSet",
				shields: [
					"nobility",
					"scholarship",
					"craftsmanship"
				]
			}
		}
	},
	{
		id: "Duchess",
		place: "castle",
		cost: 5,
		shields: ["nobility", "nobility"],
		effects: [{
			type: "gainKeys",
			gain: 2
		}],
		scoring: {
			score: 8,
			cond: {
				type: "ifPosition",
				pos: [
					[
						!0,
						!0,
						!0
					],
					[
						!1,
						!1,
						!1
					],
					[
						!1,
						!1,
						!1
					]
				]
			}
		}
	},
	{
		id: "Inventor",
		place: "village",
		cost: 2,
		shields: ["scholarship", "scholarship"],
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "scholarship"
			}
		}],
		scoring: {
			score: 1,
			cond: {
				type: "perBanner",
				place: "village"
			}
		}
	},
	{
		id: "Spy",
		place: "village",
		cost: 4,
		shields: ["scholarship", "military"],
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "scholarship"
			}
		}, {
			type: "gainKeys",
			gain: 1,
			cond: {
				type: "bestNeighbor",
				cond: {
					type: "perShield",
					shield: "military"
				}
			}
		}],
		scoring: {
			score: 6,
			cond: {
				type: "ifPosition",
				pos: [
					[
						!1,
						!0,
						!1
					],
					[
						!1,
						!0,
						!1
					],
					[
						!1,
						!0,
						!1
					]
				]
			}
		}
	},
	{
		id: "Vicar",
		place: "village",
		cost: 0,
		shields: ["faith"],
		messenger: !0,
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: {
				type: "perBanner",
				place: "village"
			}
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perPurseGold",
				limit: 5
			}
		}
	},
	{
		id: "MiraculouslyCured",
		place: "village",
		cost: 2,
		shields: ["faith", "faith"],
		messenger: !0,
		effects: [{
			type: "gainKeys",
			gain: 1,
			cond: { type: "perCardPurse" }
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perPurseGold",
				limit: 4
			}
		}
	},
	{
		id: "Squire",
		place: "village",
		cost: 0,
		shields: ["military"],
		effects: [{
			type: "discount",
			castle: 1,
			village: 1
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perShield",
				shield: "craftsmanship",
				line: !0,
				column: !0
			}
		}
	},
	{
		id: "Philosopher",
		place: "village",
		cost: 2,
		shields: ["scholarship"],
		effects: [{
			type: "discount",
			castle: 1
		}],
		scoring: {
			score: 10,
			cond: {
				type: "ifShieldMissing",
				shield: "military"
			}
		}
	},
	{
		id: "Doctor",
		place: "village",
		cost: 5,
		shields: ["scholarship"],
		messenger: !0,
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "scholarship"
			}
		}, {
			type: "gainGold",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "peasantry"
			}
		}],
		scoring: {
			score: 4,
			cond: {
				type: "perShieldSet",
				shields: ["scholarship", "peasantry"]
			}
		}
	},
	{
		id: "Executioner",
		place: "village",
		cost: 0,
		shields: ["military"],
		messenger: !0,
		effects: [{
			type: "discardRiver",
			river: "castle",
			token: "gold"
		}],
		scoring: {
			score: 1,
			cond: {
				type: "perBanner",
				place: "castle"
			}
		}
	},
	{
		id: "Barbarian",
		place: "village",
		cost: 2,
		shields: ["military"],
		messenger: !0,
		effects: [{
			type: "choose",
			a: {
				type: "gainGold",
				gain: 1,
				cond: {
					type: "bestNeighbor",
					cond: {
						type: "perShield",
						shield: "scholarship"
					}
				}
			},
			b: {
				type: "gainKeys",
				gain: 2
			}
		}],
		scoring: {
			score: 10,
			cond: {
				type: "ifShieldMissing",
				shield: "scholarship"
			}
		}
	},
	{
		id: "Militiaman",
		place: "village",
		cost: 2,
		shields: ["military"],
		messenger: !0,
		effects: [{
			type: "choose",
			a: {
				type: "gainGold",
				gain: 1,
				cond: {
					type: "bestNeighbor",
					cond: {
						type: "perShield",
						shield: "peasantry"
					}
				}
			},
			b: {
				type: "gainKeys",
				gain: 2
			}
		}],
		scoring: {
			score: 3,
			cond: {
				type: "perShield",
				shield: "military",
				line: !0
			}
		}
	},
	{
		id: "Bombardier",
		place: "village",
		cost: 2,
		shields: ["military"],
		effects: [{
			type: "choose",
			a: {
				type: "gainGold",
				gain: 1,
				cond: {
					type: "bestNeighbor",
					cond: {
						type: "perShield",
						shield: "craftsmanship"
					}
				}
			},
			b: {
				type: "gainKeys",
				gain: 2
			}
		}],
		scoring: {
			score: 3,
			cond: {
				type: "perShield",
				shield: "military",
				column: !0
			}
		}
	},
	{
		id: "Stonemason",
		place: "village",
		cost: 3,
		shields: ["craftsmanship"],
		messenger: !0,
		effects: [{
			type: "discount",
			village: 1
		}],
		scoring: {
			score: 3,
			cond: {
				type: "perShield",
				shield: "craftsmanship",
				column: !0
			}
		}
	},
	{
		id: "Blacksmith",
		place: "village",
		cost: 5,
		shields: ["military", "craftsmanship"],
		effects: [{
			type: "choose",
			a: {
				type: "gainGold",
				gain: 1,
				cond: {
					type: "bestNeighbor",
					cond: {
						type: "perShield",
						shield: "nobility"
					}
				}
			},
			b: {
				type: "gainKeys",
				gain: 2
			}
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perCardShieldCount",
				count: 2
			}
		}
	},
	{
		id: "MasterAtArms",
		place: "village",
		cost: 2,
		shields: ["military", "military"],
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "military"
			}
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perPurseGold",
				limit: 4
			}
		}
	},
	{
		id: "Mercenary",
		place: "village",
		cost: 6,
		shields: ["military", "peasantry"],
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: { type: "perDifferentShield" }
		}],
		scoring: {
			score: 7,
			cond: {
				type: "perShieldSet",
				shields: [
					"faith",
					"military",
					"peasantry"
				]
			}
		}
	},
	{
		id: "Innkeeper",
		place: "village",
		cost: 0,
		shields: ["craftsmanship"],
		effects: [{
			type: "putGold",
			gold: 2
		}, {
			type: "gainGold",
			gain: 0,
			opponentsGain: 2
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perPurseGold",
				limit: 6
			}
		}
	},
	{
		id: "Sculptor",
		place: "village",
		cost: 3,
		shields: ["faith", "craftsmanship"],
		messenger: !0,
		effects: [{
			type: "gainKeys",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "faith"
			}
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perPurseGold",
				limit: 7
			}
		}
	},
	{
		id: "Clockmaker",
		place: "village",
		cost: 3,
		shields: ["craftsmanship"],
		messenger: !0,
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "craftsmanship"
			}
		}],
		scoring: {
			score: 3,
			cond: {
				type: "perShield",
				shield: "craftsmanship",
				line: !0
			}
		}
	},
	{
		id: "SpiceMerchant",
		place: "village",
		cost: 0,
		shields: ["craftsmanship"],
		effects: [{
			type: "gainGold",
			gain: 2,
			cond: {
				type: "perShield",
				shield: "craftsmanship"
			}
		}],
		scoring: {
			score: 5,
			cond: {
				type: "ifPosition",
				pos: [
					[
						!1,
						!1,
						!1
					],
					[
						!0,
						!0,
						!0
					],
					[
						!1,
						!1,
						!1
					]
				]
			}
		}
	},
	{
		id: "Armorer",
		place: "village",
		cost: 3,
		shields: ["craftsmanship"],
		effects: [{
			type: "discount",
			castle: 1,
			village: 1
		}],
		scoring: {
			score: 3,
			cond: {
				type: "perShield",
				shield: "military",
				line: !0,
				column: !0
			}
		}
	},
	{
		id: "Potter",
		place: "village",
		cost: 2,
		shields: ["craftsmanship", "craftsmanship"],
		messenger: !0,
		effects: [{
			type: "putGold",
			gold: 2
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perPurseGold",
				limit: 4
			}
		}
	},
	{
		id: "Farmer",
		place: "village",
		cost: 5,
		shields: ["peasantry", "peasantry"],
		messenger: !0,
		effects: [{
			type: "gainKeys",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "peasantry"
			}
		}],
		scoring: {
			score: 7,
			cond: {
				type: "ifPosition",
				pos: [
					[
						!1,
						!1,
						!1
					],
					[
						!1,
						!1,
						!1
					],
					[
						!0,
						!0,
						!0
					]
				]
			}
		}
	},
	{
		id: "Locksmith",
		place: "village",
		cost: 4,
		shields: ["craftsmanship", "peasantry"],
		messenger: !0,
		effects: [{
			type: "gainKeys",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "craftsmanship"
			}
		}],
		scoring: {
			score: 1,
			cond: { type: "perKey" }
		}
	},
	{
		id: "Carpenter",
		place: "village",
		cost: 0,
		shields: ["craftsmanship"],
		messenger: !0,
		effects: [{
			type: "gainKeys",
			gain: 1,
			cond: { type: "perMissingShield" }
		}],
		scoring: {
			score: 8,
			cond: { type: "ifFaceDown" }
		}
	},
	{
		id: "Witch",
		place: "village",
		cost: 4,
		shields: ["peasantry"],
		messenger: !0,
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "peasantry"
			}
		}, {
			type: "gainKeys",
			gain: 1,
			cond: {
				type: "bestNeighbor",
				cond: {
					type: "perShield",
					shield: "faith"
				}
			}
		}],
		scoring: {
			score: 9,
			cond: {
				type: "ifShieldMissing",
				shield: "faith"
			}
		}
	},
	{
		id: "Brigand",
		place: "village",
		cost: 7,
		shields: ["peasantry"],
		effects: [{
			type: "gainKeys",
			gain: 1,
			cond: {
				type: "bestNeighbor",
				cond: {
					type: "perBanner",
					place: "castle"
				}
			}
		}],
		scoring: {
			score: 7,
			cond: {
				type: "perBannerSet",
				places: [
					"village",
					"village",
					"village"
				]
			}
		}
	},
	{
		id: "Woodcutter",
		place: "village",
		cost: 0,
		shields: ["peasantry"],
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: { type: "perCard" }
		}],
		scoring: {
			score: 5,
			cond: {
				type: "ifPosition",
				pos: [
					[
						!1,
						!1,
						!0
					],
					[
						!1,
						!1,
						!0
					],
					[
						!1,
						!1,
						!0
					]
				]
			}
		}
	},
	{
		id: "Monk",
		place: "village",
		cost: 4,
		shields: ["faith", "peasantry"],
		messenger: !0,
		effects: [{
			type: "gainKeys",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "faith"
			}
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perShield",
				shield: "peasantry",
				line: !0,
				column: !0
			}
		}
	},
	{
		id: "Beggar",
		place: "village",
		cost: 0,
		shields: ["peasantry"],
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: { type: "perCard" }
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perShield",
				shield: "faith",
				line: !0,
				column: !0
			}
		}
	},
	{
		id: "StableBoy",
		place: "village",
		cost: 4,
		shields: ["peasantry", "nobility"],
		effects: [{
			type: "gainKeys",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "nobility"
			}
		}],
		scoring: {
			score: 3,
			cond: {
				type: "perShield",
				shield: "peasantry",
				column: !0
			}
		}
	},
	{
		id: "Winemaker",
		place: "village",
		cost: 2,
		shields: ["scholarship", "peasantry"],
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: {
				type: "perBanner",
				place: "village"
			}
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perDifferentShield",
				column: !0
			}
		}
	},
	{
		id: "Shepherd",
		place: "village",
		cost: 5,
		shields: ["peasantry"],
		messenger: !0,
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: { type: "perEmpty" }
		}],
		scoring: {
			score: 3,
			cond: {
				type: "perShield",
				shield: "peasantry",
				line: !0
			}
		}
	},
	{
		id: "Usurper",
		place: "village",
		cost: 5,
		shields: ["peasantry"],
		messenger: !0,
		effects: [{
			type: "gainKeys",
			gain: 1,
			cond: {
				type: "perCardShieldCount",
				count: 1
			}
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perBanner",
				place: "castle"
			}
		}
	},
	{
		id: "Traveler",
		place: "village",
		cost: 0,
		shields: ["peasantry"],
		effects: [{
			type: "gainGold",
			gain: 3,
			cond: {
				type: "perCardCost",
				cost: 0
			}
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perCardCost",
				cost: 0
			}
		}
	},
	{
		id: "Farmhand",
		place: "village",
		cost: 0,
		shields: ["peasantry"],
		messenger: !0,
		effects: [{
			type: "discount",
			village: 1
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perPurseGold",
				limit: 5
			}
		}
	},
	{
		id: "Revolutionary",
		place: "village",
		cost: 4,
		shields: ["peasantry"],
		messenger: !0,
		effects: [{
			type: "gainKeys",
			gain: 1,
			cond: {
				type: "perBanner",
				place: "village"
			}
		}],
		scoring: {
			score: 9,
			cond: {
				type: "ifShieldMissing",
				shield: "nobility"
			}
		}
	},
	{
		id: "Fisherman",
		place: "village",
		cost: 2,
		shields: ["peasantry", "peasantry"],
		effects: [{
			type: "discount",
			castle: 1
		}],
		scoring: {
			score: 4,
			cond: {
				type: "ifPosition",
				pos: [
					[
						!0,
						!1,
						!0
					],
					[
						!1,
						!1,
						!1
					],
					[
						!0,
						!1,
						!0
					]
				]
			}
		}
	},
	{
		id: "Baker",
		place: "village",
		cost: 0,
		shields: ["peasantry"],
		effects: [{
			type: "gainGold",
			gain: 1,
			cond: {
				type: "perShield",
				shield: "peasantry"
			}
		}, {
			type: "gainKeys",
			gain: 1,
			cond: {
				type: "perBanner",
				place: "village"
			}
		}],
		scoring: {
			score: 3,
			cond: {
				type: "ifPosition",
				pos: [
					[
						!1,
						!0,
						!1
					],
					[
						!0,
						!1,
						!0
					],
					[
						!1,
						!0,
						!1
					]
				]
			}
		}
	},
	{
		id: "Beekeeper",
		place: "village",
		cost: 2,
		shields: ["peasantry"],
		effects: [{
			type: "putGold",
			gold: 2
		}],
		scoring: {
			score: 2,
			cond: {
				type: "perPurseGold",
				limit: 9
			}
		}
	}
], ne = new Map(D.map((e) => [e.id, e]));
function O(e) {
	let t = ne.get(e);
	if (!t) throw Error(`unknown card ${e}`);
	return t;
}
//#endregion
//#region src/games/castlecombo/meta.ts
var k = {
	id: "castlecombo",
	tier: "alpha",
	mechanics: [
		"drafting",
		"tile-placement",
		"set-collection"
	],
	interactionTags: [],
	nameKey: "games.castlecombo.name",
	descKey: "games.castlecombo.desc",
	rulesKey: "games.castlecombo.rules",
	icon: "🏰",
	iconImg: "games/castlecombo.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/castlecombo/en.pdf" },
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [2],
	accent: "#b45309",
	releasedAt: "2026-09-15",
	search: {
		py: "cheng bao jia nian hua",
		init: "cbjnh"
	},
	hotseat: "cover"
}, A = t.union([
	t.object({ type: t.literal("keyMove") }),
	t.object({ type: t.literal("keyRefresh") }),
	t.object({
		type: t.literal("buy"),
		cardId: t.string(),
		x: t.int(),
		y: t.int(),
		faceDown: t.boolean().optional()
	}),
	t.object({
		type: t.literal("choose"),
		pick: t.union([t.literal(1), t.literal(2)])
	}),
	t.object({
		type: t.literal("discardPick"),
		cardId: t.string()
	})
]), re = t.enum(["castle", "village"]), ie = t.object({
	card: t.string(),
	x: t.int(),
	y: t.int(),
	faceDown: t.boolean().optional(),
	purseGold: t.int().nonnegative().optional()
}), j = t.object({
	phase: t.enum([
		"main",
		"choose",
		"discard",
		"done"
	]),
	turn: t.string(),
	keySpent: t.boolean(),
	messenger: re,
	gone: re.nullable(),
	rivers: t.object({
		castle: t.array(t.string()),
		village: t.array(t.string())
	}),
	deckCounts: t.object({
		castle: t.int().nonnegative(),
		village: t.int().nonnegative()
	}),
	discards: t.object({
		castle: t.array(t.string()),
		village: t.array(t.string())
	}),
	current: t.string().nullable(),
	players: t.array(t.object({
		rid: t.string(),
		gold: t.int().nonnegative(),
		keys: t.int().nonnegative(),
		tableau: t.array(ie),
		score: t.int()
	}))
}), ae = t.object({}), M = ["castle", "village"], oe = (e) => e === "castle" ? "village" : "castle", N = 3, P = 9;
function F(e) {
	if (e.length === 0) return [{
		x: 0,
		y: 0
	}];
	let t = new Set(e.map((e) => `${e.x},${e.y}`)), n = [], r = /* @__PURE__ */ new Set();
	for (let i of e) for (let [a, o] of [
		[1, 0],
		[-1, 0],
		[0, 1],
		[0, -1]
	]) {
		let s = i.x + a, c = i.y + o, l = `${s},${c}`;
		if (t.has(l) || r.has(l)) continue;
		let u = e.map((e) => e.x).concat(s), d = e.map((e) => e.y).concat(c);
		Math.max(...u) - Math.min(...u) >= 3 || Math.max(...d) - Math.min(...d) >= 3 || (r.add(l), n.push({
			x: s,
			y: c
		}));
	}
	return n;
}
function I(e) {
	let t = Math.min(...e.map((e) => e.x)), n = Math.min(...e.map((e) => e.y)), r = [
		[
			null,
			null,
			null
		],
		[
			null,
			null,
			null
		],
		[
			null,
			null,
			null
		]
	];
	for (let i of e) {
		let e = i.x - t, a = i.y - n;
		e < 3 && a < 3 && (r[a][e] = i.faceDown ? null : O(i.card));
	}
	return r;
}
function L(e, t) {
	let n = 0;
	for (let r of e) if (!r.faceDown) for (let e of O(r.card).effects) e.type === "discount" && (n += (t === "castle" ? e.castle : e.village) ?? 0);
	return n;
}
function R(e, t) {
	let n = O(e);
	return Math.max(0, n.cost - L(t, n.place));
}
function z(e, t, n, r) {
	return t.line && t.column ? e.grid.flatMap((e, t) => e.filter((e, i) => i === n || t === r)) : t.line ? e.grid[r ?? 0] : t.column ? e.grid.map((e) => e[n ?? 0]) : e.grid.flat();
}
function se(e, t) {
	let n = 0, r = [...t];
	search: for (; r.length >= e.length;) {
		for (let t of e) {
			let e = r.indexOf(t);
			if (e < 0) break search;
			r.splice(e, 1);
		}
		n += 1;
	}
	return n;
}
function B(e, t, n, r) {
	let i = z(t, {}, void 0, void 0).filter((e) => e !== null);
	switch (e.type) {
		case "perShield": return z(t, e, n, r).reduce((t, n) => t + (n ? n.shields.filter((t) => t === e.shield).length : 0), 0);
		case "perDifferentShield": return new Set(z(t, e, n, r).filter((e) => e !== null).flatMap((e) => e.shields)).size;
		case "perMissingShield": return w.filter((e) => !i.some((t) => t.shields.includes(e))).length;
		case "ifShieldMissing": return +!i.some((t) => t.shields.includes(e.shield));
		case "perShieldSet": return se(e.shields, i.flatMap((e) => e.shields));
		case "perIdenticalSet": return w.reduce((t, n) => t + Math.floor(i.reduce((e, t) => e + t.shields.filter((e) => e === n).length, 0) / e.count), 0);
		case "perKey": return t.keys;
		case "perBanner": return i.filter((t) => t.place === e.place).length;
		case "perBannerSet": return se(e.places, i.map((e) => e.place));
		case "perCardShieldCount": return i.filter((t) => t.shields.length === e.count).length;
		case "perCardCost": return i.filter((t) => e.orGreater ? t.cost >= e.cost : t.cost === e.cost).length;
		case "perCardDiscount": return i.filter((e) => e.effects.some((e) => e.type === "discount")).length;
		case "ifFaceDown": return +!!t.tableau.some((e) => e.faceDown);
		case "perCardPurse": return i.filter((e) => T(e) > 0).length;
		case "perPurseGold": return 0;
		case "perAllPurseGold": return t.tableau.reduce((e, t) => e + (t.purseGold ?? 0), 0);
		case "perCard": return t.tableau.length;
		case "perEmpty": return P - t.tableau.length;
		case "ifPosition": return n === void 0 || r === void 0 ? 0 : +!!e.pos[r]?.[n];
		case "bestNeighbor": return Math.max(0, ...t.neighbors.map((t) => B(e.cond, V(t, 0, []))));
	}
}
function V(e, t, n) {
	return {
		grid: e.length ? I(e) : [
			[
				null,
				null,
				null
			],
			[
				null,
				null,
				null
			],
			[
				null,
				null,
				null
			]
		],
		tableau: e,
		keys: t,
		neighbors: n
	};
}
function ce(e, t) {
	let n = e.players.indexOf(t), r = e.players.length;
	return [e.tableau[e.players[(n + 1) % r]], e.tableau[e.players[(n - 1 + r) % r]]];
}
function H(e, t, n, r) {
	let i = e[r];
	if (i.faceDown) return 0;
	let a = O(i.card);
	if (a.scoring.cond.type === "perPurseGold") return a.scoring.score * (i.purseGold ?? 0);
	let o = V(e, t, n), s = Math.min(...e.map((e) => e.x)), c = Math.min(...e.map((e) => e.y));
	return a.scoring.score * B(a.scoring.cond, o, i.x - s, i.y - c);
}
function U(e, t) {
	let n = e.tableau[t], r = ce(e, t);
	return n.reduce((i, a, o) => i + H(n, e.keys[t], r, o), 0) + e.keys[t];
}
function le(t, n, r) {
	for (let i = t.length - 1; i > 0; --i) {
		let a = e(n, r(), i + 1);
		[t[i], t[a]] = [t[a], t[i]];
	}
	return t;
}
function ue(t, n, r) {
	let i = 0, a = () => i++, o = {
		castle: le(D.filter((e) => e.place === "castle").map((e) => e.id), r, a),
		village: le(D.filter((e) => e.place === "village").map((e) => e.id), r, a)
	}, s = {
		castle: [],
		village: []
	};
	for (let e of M) for (let t = 0; t < N; t += 1) s[e].push(o[e].pop());
	let c = {
		players: n,
		turnIdx: e(r, a(), n.length),
		phase: "main",
		seed: r,
		cursor: i,
		decks: o,
		rivers: s,
		discards: {
			castle: [],
			village: []
		},
		messenger: "village",
		gone: null,
		gold: {},
		keys: {},
		tableau: {},
		keySpent: !1,
		current: null
	};
	for (let e of n) c.gold[e] = 15, c.keys[e] = 2, c.tableau[e] = [];
	return {
		state: c,
		fx: []
	};
}
function de(e, t) {
	e.decks[t] = le(e.discards[t], e.seed, () => e.cursor++), e.discards[t] = [];
}
function fe(e) {
	for (let t of M) for (; e.rivers[t].length < N;) {
		if (e.decks[t].length === 0) {
			if (e.discards[t].length === 0) {
				e.rivers[t] = [], e.gone = t, e.messenger === t && (e.messenger = oe(t));
				break;
			}
			de(e, t);
		}
		e.rivers[t].push(e.decks[t].pop());
	}
}
function pe(e) {
	if (e.current = null, fe(e), e.players.every((t) => e.tableau[t].length === P)) {
		for (let t of e.players) {
			let n = e.tableau[t].filter((e) => !e.faceDown && T(O(e.card)) > (e.purseGold ?? 0)).sort((e, t) => e.y - t.y || e.x - t.x);
			for (let r of n) {
				if (e.gold[t] <= 0) break;
				let n = T(O(r.card)) - (r.purseGold ?? 0), i = Math.min(n, e.gold[t]);
				r.purseGold = (r.purseGold ?? 0) + i, e.gold[t] -= i;
			}
		}
		return e.phase = "done", [];
	}
	return e.turnIdx = (e.turnIdx + 1) % e.players.length, e.phase = "main", e.keySpent = !1, [];
}
function me(e, t, n) {
	for (let r of n) if (r.type !== "discount") {
		if (r.type === "choose") {
			e.phase = "choose";
			continue;
		}
		if (r.type === "discardRiver") {
			e.phase = "discard";
			continue;
		}
		he(e, t, r);
	}
}
function he(e, t, n) {
	let r = V(e.tableau[t], e.keys[t], ce(e, t));
	if (n.type === "gainGold" || n.type === "gainKeys") {
		let i = n.cond ? B(n.cond, r) : 1, a = (n.gain ?? 0) * i, o = (n.opponentsGain ?? 0) * i;
		if (n.type === "gainGold") {
			e.gold[t] += a;
			for (let n of e.players) n !== t && (e.gold[n] += o);
		} else {
			e.keys[t] += a;
			for (let n of e.players) n !== t && (e.keys[n] += o);
		}
		return;
	}
	if (n.type === "putGold") {
		let r = e.tableau[t].filter((e) => !e.faceDown && T(O(e.card)) > (e.purseGold ?? 0));
		n.cardsLimit && (r = r.sort((e, t) => T(O(t.card)) - (t.purseGold ?? 0) - (T(O(e.card)) - (e.purseGold ?? 0))).slice(0, n.cardsLimit));
		for (let e of r) {
			let t = T(O(e.card)) - (e.purseGold ?? 0);
			e.purseGold = (e.purseGold ?? 0) + Math.min(n.gold ?? t, t);
		}
	}
}
function ge(e, t, n) {
	if (n || !O(t).messenger) return [];
	let r = oe(e.messenger);
	return e.gone === r || e.rivers[r].length === 0 ? [] : (e.messenger = r, [{
		kind: "messenger",
		data: { to: r }
	}]);
}
function _e(e, t, n) {
	if (e.phase === "done") return { code: "games.castlecombo.errNotYourTurn" };
	let r = n.by;
	if (e.players[e.turnIdx] !== r) return { code: "games.castlecombo.errNotYourTurn" };
	if (t.type === "choose") {
		if (e.phase !== "choose" || !e.current) return { code: "games.castlecombo.errBadPhase" };
		let n = O(e.current).effects.find((e) => e.type === "choose");
		if (!n || n.type !== "choose") return { code: "games.castlecombo.errBadPhase" };
		let i = structuredClone(e), a = i.current;
		return i.current = null, he(i, r, t.pick === 1 ? n.a : n.b), {
			state: i,
			fx: [...ge(i, a, !1), ...pe(i)]
		};
	}
	if (t.type === "discardPick") {
		if (e.phase !== "discard" || !e.current) return { code: "games.castlecombo.errBadPhase" };
		let n = O(e.current).effects.find((e) => e.type === "discardRiver");
		if (!n || n.type !== "discardRiver") return { code: "games.castlecombo.errBadPhase" };
		let i = e.rivers[n.river].indexOf(t.cardId);
		if (i < 0) return { code: "games.castlecombo.errBadCard" };
		let a = structuredClone(e), o = a.current;
		a.current = null, a.rivers[n.river].splice(i, 1), a.discards[n.river].push(t.cardId);
		let s = O(t.cardId).cost;
		n.token === "gold" ? a.gold[r] += s : a.keys[r] += s;
		let c = [{
			kind: "discardPick",
			rid: r,
			data: {
				river: n.river,
				cardId: t.cardId,
				token: n.token,
				amount: s
			}
		}];
		return c.push(...ge(a, o, !1)), {
			state: a,
			fx: [...c, ...pe(a)]
		};
	}
	if (e.phase !== "main") return { code: "games.castlecombo.errBadPhase" };
	if (t.type === "keyMove" || t.type === "keyRefresh") {
		if (e.keySpent || e.keys[r] <= 0) return { code: "games.castlecombo.errNoKey" };
		let n = structuredClone(e);
		if (--n.keys[r], n.keySpent = !0, t.type === "keyMove") {
			let e = oe(n.messenger);
			return n.gone === e || n.rivers[e].length === 0 ? { code: "games.castlecombo.errBadPhase" } : (n.messenger = e, {
				state: n,
				fx: [{
					kind: "messenger",
					rid: r,
					data: { to: e }
				}]
			});
		}
		let i = n.messenger, a = n.rivers[i].length;
		return n.discards[i].push(...n.rivers[i]), n.rivers[i] = [], fe(n), {
			state: n,
			fx: [{
				kind: "refresh",
				rid: r,
				data: {
					river: i,
					count: a
				}
			}]
		};
	}
	let i = e.rivers[e.messenger].indexOf(t.cardId);
	if (i < 0) return { code: "games.castlecombo.errBadCard" };
	let a = t.faceDown === !0, o = e.tableau[r];
	if (!F(o).some((e) => e.x === t.x && e.y === t.y)) return { code: "games.castlecombo.errBadPos" };
	let s = R(t.cardId, o);
	if (!a && s > e.gold[r]) return { code: "games.castlecombo.errCantAfford" };
	let c = structuredClone(e);
	c.rivers[c.messenger].splice(i, 1), c.tableau[r].push({
		card: t.cardId,
		x: t.x,
		y: t.y,
		faceDown: a || void 0
	});
	let l = [{
		kind: "buy",
		rid: r,
		data: {
			cardId: t.cardId,
			river: c.messenger,
			slot: i,
			faceDown: a,
			x: t.x,
			y: t.y
		}
	}];
	return a ? (c.gold[r] += 6, c.keys[r] += 2, {
		state: c,
		fx: [...l, ...pe(c)]
	}) : (c.gold[r] -= s, c.current = t.cardId, me(c, r, O(t.cardId).effects), c.phase === "main" ? (l.push(...ge(c, t.cardId, !1)), {
		state: c,
		fx: [...l, ...pe(c)]
	}) : {
		state: c,
		fx: l
	});
}
function ve(e, t) {
	return {
		public: {
			phase: e.phase,
			turn: e.players[e.turnIdx],
			keySpent: e.keySpent,
			messenger: e.messenger,
			gone: e.gone,
			rivers: {
				castle: [...e.rivers.castle],
				village: [...e.rivers.village]
			},
			deckCounts: {
				castle: e.decks.castle.length,
				village: e.decks.village.length
			},
			discards: {
				castle: [...e.discards.castle],
				village: [...e.discards.village]
			},
			current: e.current,
			players: e.players.map((t) => ({
				rid: t,
				gold: e.gold[t],
				keys: e.keys[t],
				tableau: e.tableau[t].map((e) => ({ ...e })),
				score: U(e, t)
			}))
		},
		private: {}
	};
}
function ye(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = (t) => U(e, t), n = [...e.players].sort((n, r) => t(r) - t(n) || e.gold[r] - e.gold[n]), r = n[0], i = n.filter((n) => t(n) === t(r) && e.gold[n] === e.gold[r]), a = {};
	for (let n of e.players) a[n] = t(n);
	return {
		phase: "done",
		winner: i,
		ranking: n,
		scores: a
	};
}
var be = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: k,
	schemas: {
		action: A,
		publicView: j,
		privateView: ae
	},
	setup: ue,
	reduce: _e,
	viewFor: ve,
	status: ye
}, W = {
	ink: "#273b38",
	deep: "#244b45",
	teal: "#326c69",
	paper: "#faf4e4",
	gold: "#d4a446",
	rust: "#ae603e",
	blue: "#3c85a0"
}, G = (e, t, n = W.ink, r = 2) => `<path d="${e}" fill="${t}" stroke="${n}" stroke-width="${r}" stroke-linejoin="round" stroke-linecap="round"/>`, K = (e, t, n, r, i = W.ink, a = 2) => G(`M${e} ${t}L${n} ${r}`, "none", i, a), q = (e, t, n, r, i, a = "none", o = 1) => `<ellipse cx="${e}" cy="${t}" rx="${n}" ry="${r}" fill="${i}" stroke="${a}" stroke-width="${o}"/>`, J = (e, t, n, r, i, a = 0, o = "none", s = 1) => `<rect x="${e}" y="${t}" width="${n}" height="${r}" rx="${a}" fill="${i}" stroke="${o}" stroke-width="${s}"/>`, xe = {
	Duchess: "<path d=\"M24 0H216V221L196 209L174 223L152 212L129 224L104 212L80 224L55 212L24 224Z\" fill=\"#7d9f9d\" stroke=\"none\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><rect x=\"30\" y=\"0\" width=\"180\" height=\"215\" rx=\"0\" fill=\"url(#cc-tapestry)\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M36 0L36 209\" fill=\"none\" stroke=\"#ffffff58\" stroke-width=\"1\" stroke-linecap=\"round\"/><path d=\"M204 0L204 209\" fill=\"none\" stroke=\"#ffffff58\" stroke-width=\"1\" stroke-linecap=\"round\"/><path d=\"M49 240Q52 197 82 182L96 176L142 176L158 184Q190 197 200 240Z\" fill=\"#265b65\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M77 189L97 177L117 206L141 177L162 190L146 238H91Z\" fill=\"#467f87\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M95 168L93 186Q110 202 128 187L137 164Z\" fill=\"#d99b72\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M68 83Q44 57 67 37Q75 15 99 28Q119 13 143 28Q179 20 187 52Q207 79 180 105L170 132L76 130Z\" fill=\"#a96339\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M78 53Q102 40 124 48Q144 43 157 59L163 108L180 112Q189 120 170 129Q168 158 143 168Q113 183 91 157Q76 143 77 118L69 107Q61 94 75 92Z\" fill=\"#eab68a\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M79 54Q96 77 125 65Q142 53 161 70Q171 47 152 36Q121 20 95 34Z\" fill=\"#b87342\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M61 56Q72 31 97 34M66 76Q74 61 84 69M160 34Q181 45 178 63M59 88Q66 77 74 82\" fill=\"none\" stroke=\"#d69d5e\" stroke-width=\"4\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M87 94Q101 87 110 94M131 90Q144 84 151 91\" fill=\"none\" stroke=\"#734b34\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><ellipse cx=\"101\" cy=\"102\" rx=\"6.5\" ry=\"5.5\" fill=\"#faf4e4\" stroke=\"#273b38\" stroke-width=\"1.2\"/><ellipse cx=\"102\" cy=\"102\" rx=\"2.6\" ry=\"4\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"101.2\" cy=\"100.6\" rx=\"0.7\" ry=\"1\" fill=\"white\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"143\" cy=\"99\" rx=\"6.5\" ry=\"5.5\" fill=\"#faf4e4\" stroke=\"#273b38\" stroke-width=\"1.2\"/><ellipse cx=\"143\" cy=\"99\" rx=\"2.6\" ry=\"4\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"142.2\" cy=\"97.6\" rx=\"0.7\" ry=\"1\" fill=\"white\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M120 101Q126 109 120 121L135 123Q133 130 122 130\" fill=\"#d89469\" stroke=\"#273b38\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><ellipse cx=\"91\" cy=\"128\" rx=\"8\" ry=\"4\" fill=\"#d98572\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M108 143Q126 151 143 138Q132 163 116 154Z\" fill=\"#9b4540\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M113 145L137 142L133 148L118 150Z\" fill=\"#faf4e4\" stroke=\"none\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M69 43L70 25Q108 9 151 22L159 43Q109 31 69 43Z\" fill=\"#274b52\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M92 29L113 28L115 39L94 40Z\" fill=\"#d7ad53\" stroke=\"none\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M157 28Q190 1 207 11Q190 37 161 34Z\" fill=\"#e8d7a1\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M163 31L194 15\" fill=\"none\" stroke=\"#85734d\" stroke-width=\"1\" stroke-linecap=\"round\"/><path d=\"M78 184L64 194L89 232L101 219Z\" fill=\"#f5e6c2\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M146 180L163 187L141 215L127 205Z\" fill=\"#f5e6c2\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><ellipse cx=\"100\" cy=\"207\" rx=\"3\" ry=\"3\" fill=\"#e1be64\" stroke=\"#273b38\" stroke-width=\"0.7\"/><ellipse cx=\"116\" cy=\"205\" rx=\"3\" ry=\"3\" fill=\"#e1be64\" stroke=\"#273b38\" stroke-width=\"0.7\"/><ellipse cx=\"132\" cy=\"203\" rx=\"3\" ry=\"3\" fill=\"#e1be64\" stroke=\"#273b38\" stroke-width=\"0.7\"/><path d=\"M166 223Q150 204 151 192L160 172L167 176L164 191L173 182L179 185L176 196L186 207L179 222Z\" fill=\"#eab68a\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M177 192L187 142L195 144L187 199Z\" fill=\"#d0a250\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><ellipse cx=\"192\" cy=\"141\" rx=\"5\" ry=\"6\" fill=\"#e6cc83\" stroke=\"#273b38\" stroke-width=\"1\"/><path d=\"M65 212L74 234M108 223L106 240M136 223L143 240\" fill=\"none\" stroke=\"#153e48\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/>",
	Templar: "<path d=\"M24 0H216V221L196 209L174 223L152 212L129 224L104 212L80 224L55 212L24 224Z\" fill=\"#a58f9c\" stroke=\"none\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><rect x=\"30\" y=\"0\" width=\"180\" height=\"215\" rx=\"0\" fill=\"url(#cc-tapestry)\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M36 0L36 209\" fill=\"none\" stroke=\"#ffffff58\" stroke-width=\"1\" stroke-linecap=\"round\"/><path d=\"M204 0L204 209\" fill=\"none\" stroke=\"#ffffff58\" stroke-width=\"1\" stroke-linecap=\"round\"/><path d=\"M51 240L63 190L91 169L154 168L185 190L198 240Z\" fill=\"#8f493f\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M75 181L95 170L114 184L145 171L165 183L157 240H84Z\" fill=\"#c2664f\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M91 176L105 166L153 168L165 181L153 199L100 199Z\" fill=\"#86928b\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M100 182l5 5l-5 5l-5-5Z\" fill=\"#516865\" stroke=\"#c2cac0\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M111 182l5 5l-5 5l-5-5Z\" fill=\"#516865\" stroke=\"#c2cac0\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M122 182l5 5l-5 5l-5-5Z\" fill=\"#516865\" stroke=\"#c2cac0\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M133 182l5 5l-5 5l-5-5Z\" fill=\"#516865\" stroke=\"#c2cac0\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M144 182l5 5l-5 5l-5-5Z\" fill=\"#516865\" stroke=\"#c2cac0\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M78 54L141 35L167 56L176 143Q140 167 91 151L70 118Z\" fill=\"#7c9290\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M78 54L101 50L109 147L91 151L70 118Z\" fill=\"#526e70\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M101 50L141 35L167 56L176 143L109 147Z\" fill=\"#b4c6bd\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M84 54Q118 28 148 37L167 51L160 58L95 65Z\" fill=\"#d5ded0\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M104 80L163 72L167 87L108 95Z\" fill=\"#243e3f\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M128 43L138 41L145 139L134 145Z\" fill=\"#78918f\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><ellipse cx=\"117\" cy=\"111\" rx=\"2\" ry=\"2\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"127\" cy=\"111.8\" rx=\"2\" ry=\"2\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"137\" cy=\"112.6\" rx=\"2\" ry=\"2\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"147\" cy=\"113.4\" rx=\"2\" ry=\"2\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"157\" cy=\"114.2\" rx=\"2\" ry=\"2\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"119\" cy=\"122\" rx=\"2\" ry=\"2\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"129\" cy=\"122.8\" rx=\"2\" ry=\"2\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"139\" cy=\"123.6\" rx=\"2\" ry=\"2\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"149\" cy=\"124.4\" rx=\"2\" ry=\"2\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"119\" cy=\"133\" rx=\"1.3\" ry=\"1.3\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"130\" cy=\"133.8\" rx=\"1.3\" ry=\"1.3\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"141\" cy=\"134.6\" rx=\"1.3\" ry=\"1.3\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"152\" cy=\"135.4\" rx=\"1.3\" ry=\"1.3\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M83 72L88 119M153 57L162 138\" fill=\"none\" stroke=\"#eef0d4\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M81 188L66 182L50 194L50 213L70 215L83 203Z\" fill=\"#8f9b92\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M63 191L81 192L78 207L63 213Z\" fill=\"#bac7b9\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><g transform=\"translate(34 163) scale(1.6)\" ><g transform=\"translate(0 0) scale(1.28125)\" ><path d=\"M3 3L28 3L27 19Q24 27 15.5 31Q7 27 4 19Z\" fill=\"#8b5981\" stroke=\"#273b38\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M6 6L25 6L24 18Q22 24 15.5 27Q10 24 7 18Z\" fill=\"none\" stroke=\"#ffffff9a\" stroke-width=\"0.9\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M13 8H18V13H23V18H18V25H13V18H8V13H13Z\" fill=\"#faf4e4\" stroke=\"none\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/></g></g><path d=\"M161 199L183 187L197 197L189 216L170 218Z\" fill=\"#a9b7ab\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M183 212L202 157L207 158L192 216Z\" fill=\"#d8ded0\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M191 151L215 160L212 166L189 158Z\" fill=\"#b38f4d\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M200 154L206 132L212 133L207 157Z\" fill=\"#4b6661\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M101 210H150V224H101Z\" fill=\"#b89a55\" stroke=\"#273b38\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M120 210V240M113 231H130\" fill=\"none\" stroke=\"#f4e7c3\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M82 226Q94 223 104 224M155 224L170 221\" fill=\"none\" stroke=\"#4b352d\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/>",
	Glassblower: "<path d=\"M24 0H216V221L196 209L174 223L152 212L129 224L104 212L80 224L55 212L24 224Z\" fill=\"#b29b77\" stroke=\"none\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><rect x=\"30\" y=\"0\" width=\"180\" height=\"215\" rx=\"0\" fill=\"url(#cc-tapestry)\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M36 0L36 209\" fill=\"none\" stroke=\"#ffffff58\" stroke-width=\"1\" stroke-linecap=\"round\"/><path d=\"M204 0L204 209\" fill=\"none\" stroke=\"#ffffff58\" stroke-width=\"1\" stroke-linecap=\"round\"/><path d=\"M59 240L67 191L93 177L148 179L179 198L184 240Z\" fill=\"#f1dbb0\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M92 184L92 208L85 240H160L151 207L149 182L138 180L136 208H106L105 181Z\" fill=\"#7b573e\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M95 208H148V240H95Z\" fill=\"#aa7650\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M100 213L100 236M142 211L142 235\" fill=\"none\" stroke=\"#d0a170\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M99 154L96 184Q112 195 137 181L135 153Z\" fill=\"#d59971\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M83 70Q63 52 79 37Q73 21 94 22Q106 5 121 20Q139 6 152 27Q172 24 175 44Q196 57 175 76L161 102L91 103Z\" fill=\"#8c4e34\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M89 53Q114 43 148 57L155 87Q170 80 173 94L168 110Q184 117 172 128L154 131Q150 159 131 168Q109 174 94 151L82 108Z\" fill=\"#e8ab7d\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><ellipse cx=\"148\" cy=\"122\" rx=\"18\" ry=\"13\" fill=\"#efba86\" stroke=\"#273b38\" stroke-width=\"1.8\"/><path d=\"M152 109Q181 103 181 114Q179 122 166 121\" fill=\"#dfa175\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M82 51Q98 71 114 57Q130 72 151 60\" fill=\"none\" stroke=\"#59382c\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M86 40Q95 24 103 35M116 28Q124 18 135 31M151 37Q164 33 164 48\" fill=\"none\" stroke=\"#bc7849\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><ellipse cx=\"111\" cy=\"87\" rx=\"6.5\" ry=\"5.5\" fill=\"#faf4e4\" stroke=\"#273b38\" stroke-width=\"1.2\"/><ellipse cx=\"113\" cy=\"87\" rx=\"2.6\" ry=\"4\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"112.2\" cy=\"85.6\" rx=\"0.7\" ry=\"1\" fill=\"white\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"143\" cy=\"88\" rx=\"6.5\" ry=\"5.5\" fill=\"#faf4e4\" stroke=\"#273b38\" stroke-width=\"1.2\"/><ellipse cx=\"145\" cy=\"88\" rx=\"2.6\" ry=\"4\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"144.2\" cy=\"86.6\" rx=\"0.7\" ry=\"1\" fill=\"white\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M101 74L114 72M135 74L148 76\" fill=\"none\" stroke=\"#643e2c\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M109 143Q117 139 125 144Q115 149 108 147Z\" fill=\"#995848\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M153 133L229 98\" fill=\"none\" stroke=\"#344d49\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M158 130L228 96\" fill=\"none\" stroke=\"#d6b976\" stroke-width=\"1.1\" stroke-linecap=\"round\"/><ellipse cx=\"218\" cy=\"89\" rx=\"17\" ry=\"23\" fill=\"#c3d1a0c0\" stroke=\"#273b38\" stroke-width=\"1.6\"/><path d=\"M209 73Q202 84 208 94M222 101L228 97\" fill=\"none\" stroke=\"#f5f2c5\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M63 214Q68 198 85 194L104 204L102 217L81 211L74 232Z\" fill=\"#e8ab7d\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M158 202L174 194L191 207L174 217L159 213Z\" fill=\"#e8ab7d\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M168 202L181 197L185 201M169 208L181 204\" fill=\"none\" stroke=\"#a56d4c\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M59 232L81 238M174 229L184 233\" fill=\"none\" stroke=\"#b9a27b\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/>",
	Spy: "<path d=\"M24 0H216V221L196 209L174 223L152 212L129 224L104 212L80 224L55 212L24 224Z\" fill=\"#879691\" stroke=\"none\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><rect x=\"30\" y=\"0\" width=\"180\" height=\"215\" rx=\"0\" fill=\"url(#cc-tapestry)\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M36 0L36 209\" fill=\"none\" stroke=\"#ffffff58\" stroke-width=\"1\" stroke-linecap=\"round\"/><path d=\"M204 0L204 209\" fill=\"none\" stroke=\"#ffffff58\" stroke-width=\"1\" stroke-linecap=\"round\"/><path d=\"M39 240Q42 202 70 178L91 161L146 161L169 178Q203 208 208 240Z\" fill=\"#43545e\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M65 193L93 166L110 218L93 240H39Z\" fill=\"#283f4b\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M151 168L181 192L199 240H127L114 216Z\" fill=\"#60757a\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M75 156Q50 119 63 76Q72 40 106 24Q132 37 161 62L183 123L166 164L135 180Z\" fill=\"#344954\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M89 73Q107 52 122 54Q146 65 155 94L146 141L126 161L99 146L84 114Z\" fill=\"#c28c69\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M86 91L101 77L112 79L102 113L87 115Z\" fill=\"#1f3541\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M109 94Q121 79 143 89\" fill=\"none\" stroke=\"#5b493e\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><ellipse cx=\"130\" cy=\"99\" rx=\"6.5\" ry=\"5.5\" fill=\"#faf4e4\" stroke=\"#273b38\" stroke-width=\"1.2\"/><ellipse cx=\"128\" cy=\"99\" rx=\"2.6\" ry=\"4\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"127.2\" cy=\"97.6\" rx=\"0.7\" ry=\"1\" fill=\"white\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M143 94L155 108L171 115Q170 125 153 123L148 133\" fill=\"#c99771\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M112 140L145 134L138 148L120 152Z\" fill=\"#715a50\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M112 137L134 136\" fill=\"none\" stroke=\"#e9cba5\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M68 93Q77 52 107 34Q142 49 160 78L141 69L113 51Q90 70 83 115L82 147\" fill=\"none\" stroke=\"#7e9692\" stroke-width=\"4\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M77 170L117 190L154 167L145 192L113 216L90 199Z\" fill=\"#c8bfa0\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M70 199L127 230M147 202L167 240\" fill=\"none\" stroke=\"#152f3a\" stroke-width=\"4\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><ellipse cx=\"117\" cy=\"194\" rx=\"8\" ry=\"8\" fill=\"#c7a35b\" stroke=\"#273b38\" stroke-width=\"1\"/><path d=\"M112 194L117 189L122 194L117 199Z\" fill=\"#566d67\" stroke=\"none\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M160 223Q145 215 143 205L149 193L156 195L154 205L172 210L180 219Z\" fill=\"#c99771\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M152 212L182 192L188 198L166 223Z\" fill=\"#e3d5b0\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M160 211L179 198\" fill=\"none\" stroke=\"#ab976f\" stroke-width=\"1\" stroke-linecap=\"round\"/><path d=\"M58 225L82 216L102 236L87 240H61Z\" fill=\"#566b72\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/>",
	Innkeeper: "<path d=\"M24 0H216V221L196 209L174 223L152 212L129 224L104 212L80 224L55 212L24 224Z\" fill=\"#a1846e\" stroke=\"none\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><rect x=\"30\" y=\"0\" width=\"180\" height=\"215\" rx=\"0\" fill=\"url(#cc-tapestry)\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M36 0L36 209\" fill=\"none\" stroke=\"#ffffff58\" stroke-width=\"1\" stroke-linecap=\"round\"/><path d=\"M204 0L204 209\" fill=\"none\" stroke=\"#ffffff58\" stroke-width=\"1\" stroke-linecap=\"round\"/><path d=\"M40 240L47 197Q63 177 88 176H151Q177 184 193 207L201 240Z\" fill=\"#6c7454\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M80 181L88 198L80 240H157L146 198L150 179L137 175L131 195H106L99 177Z\" fill=\"#f1dfbd\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M90 197Q110 205 139 196L150 240H82Z\" fill=\"#d6c29a\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M94 151L89 181Q117 197 143 179L139 148Z\" fill=\"#cc9676\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><ellipse cx=\"142\" cy=\"38\" rx=\"21\" ry=\"23\" fill=\"#b4b2a3\" stroke=\"#273b38\" stroke-width=\"2\"/><path d=\"M83 64Q65 34 94 24Q118 10 143 32Q165 37 165 72L151 113L88 106Z\" fill=\"#8b9284\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M83 67Q108 54 146 66L153 87Q166 83 170 96L165 112L153 117Q150 153 128 164Q104 169 88 149Q75 133 77 107L68 96Q66 83 80 84Z\" fill=\"#dfad88\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M83 63Q101 77 115 65Q133 79 153 67\" fill=\"none\" stroke=\"#6d796f\" stroke-width=\"7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M78 55Q91 33 117 38M128 37Q146 43 150 55M146 22Q158 33 149 45\" fill=\"none\" stroke=\"#d5d0b5\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><ellipse cx=\"100\" cy=\"96\" rx=\"6.5\" ry=\"5.5\" fill=\"#faf4e4\" stroke=\"#273b38\" stroke-width=\"1.2\"/><ellipse cx=\"101\" cy=\"96\" rx=\"2.6\" ry=\"4\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"100.2\" cy=\"94.6\" rx=\"0.7\" ry=\"1\" fill=\"white\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"137\" cy=\"95\" rx=\"6.5\" ry=\"5.5\" fill=\"#faf4e4\" stroke=\"#273b38\" stroke-width=\"1.2\"/><ellipse cx=\"136\" cy=\"95\" rx=\"2.6\" ry=\"4\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"135.2\" cy=\"93.6\" rx=\"0.7\" ry=\"1\" fill=\"white\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M93 84L104 82M131 81L142 83\" fill=\"none\" stroke=\"#5b6456\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M116 98L110 120L126 123Q131 117 123 113\" fill=\"#cf9573\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><ellipse cx=\"88\" cy=\"121\" rx=\"9\" ry=\"6\" fill=\"#c98170\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"146\" cy=\"121\" rx=\"8\" ry=\"6\" fill=\"#c98170\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M98 137Q116 149 139 134Q128 158 111 151Z\" fill=\"#874e43\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M105 140L133 138L127 144L113 146Z\" fill=\"#faf4e4\" stroke=\"none\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M51 197L40 211L54 227L75 216L73 200Z\" fill=\"#f3e1bd\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M49 221L70 211L90 213L94 225L73 232L55 231Z\" fill=\"#dfad88\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M147 213Q156 193 172 194L187 211L174 225L158 229Z\" fill=\"#dfad88\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M169 188L189 188L197 209L190 226H165L159 208Z\" fill=\"#b87844\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M190 195Q211 190 211 207Q208 223 193 218\" fill=\"none\" stroke=\"#273b38\" stroke-width=\"6\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M191 196Q206 194 207 207Q205 217 195 215\" fill=\"none\" stroke=\"#d2a271\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M167 189L189 189M166 223H188\" fill=\"none\" stroke=\"#e1b980\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><ellipse cx=\"179\" cy=\"188\" rx=\"11\" ry=\"4\" fill=\"#ecd9a4\" stroke=\"#273b38\" stroke-width=\"1\"/><path d=\"M107 214L132 214L133 235H105Z\" fill=\"#bda883\" stroke=\"none\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M109 217L128 217\" fill=\"none\" stroke=\"#f2e2c3\" stroke-width=\"1\" stroke-linecap=\"round\"/>",
	Farmer: "<path d=\"M24 0H216V221L196 209L174 223L152 212L129 224L104 212L80 224L55 212L24 224Z\" fill=\"#95a16f\" stroke=\"none\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><rect x=\"30\" y=\"0\" width=\"180\" height=\"215\" rx=\"0\" fill=\"url(#cc-tapestry)\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M36 0L36 209\" fill=\"none\" stroke=\"#ffffff58\" stroke-width=\"1\" stroke-linecap=\"round\"/><path d=\"M204 0L204 209\" fill=\"none\" stroke=\"#ffffff58\" stroke-width=\"1\" stroke-linecap=\"round\"/><path d=\"M49 240L57 192L86 178H146L176 194L189 240Z\" fill=\"#c0ab69\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M88 179L90 204L79 240H157L143 204L142 177L130 176L130 212H102L101 179Z\" fill=\"#536d56\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M99 211L137 211L147 240H86Z\" fill=\"#75906a\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M95 154L93 182L116 193L140 180L136 151Z\" fill=\"#cb9270\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M78 74Q69 43 99 36Q125 24 151 50L158 91L83 108Z\" fill=\"#825c3c\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M83 64L143 57L155 89Q170 87 172 100L161 115Q154 152 134 163Q112 175 96 151L84 119Q70 120 68 107Q66 93 81 96Z\" fill=\"#e5ae7b\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M57 71Q90 44 170 60L193 78Q147 97 64 86Q45 81 57 71Z\" fill=\"#d2b563\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M81 64L90 28Q120 15 145 34L161 66Q121 76 81 64Z\" fill=\"#dfc581\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M85 52Q119 59 154 54L158 65Q120 75 82 63Z\" fill=\"#7f7046\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M93 31L88 49\" fill=\"none\" stroke=\"#b99b55\" stroke-width=\"1\" stroke-linecap=\"round\"/><path d=\"M105 33L100 49\" fill=\"none\" stroke=\"#b99b55\" stroke-width=\"1\" stroke-linecap=\"round\"/><path d=\"M117 31L112 49\" fill=\"none\" stroke=\"#b99b55\" stroke-width=\"1\" stroke-linecap=\"round\"/><path d=\"M129 33L124 49\" fill=\"none\" stroke=\"#b99b55\" stroke-width=\"1\" stroke-linecap=\"round\"/><path d=\"M141 31L136 49\" fill=\"none\" stroke=\"#b99b55\" stroke-width=\"1\" stroke-linecap=\"round\"/><path d=\"M91 94L104 92M130 92L142 95\" fill=\"none\" stroke=\"#74543c\" stroke-width=\"2.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><ellipse cx=\"101\" cy=\"105\" rx=\"6.5\" ry=\"5.5\" fill=\"#faf4e4\" stroke=\"#273b38\" stroke-width=\"1.2\"/><ellipse cx=\"102\" cy=\"105\" rx=\"2.6\" ry=\"4\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"101.2\" cy=\"103.6\" rx=\"0.7\" ry=\"1\" fill=\"white\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"137\" cy=\"106\" rx=\"6.5\" ry=\"5.5\" fill=\"#faf4e4\" stroke=\"#273b38\" stroke-width=\"1.2\"/><ellipse cx=\"136\" cy=\"106\" rx=\"2.6\" ry=\"4\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"135.2\" cy=\"104.6\" rx=\"0.7\" ry=\"1\" fill=\"white\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M118 104L111 123L129 125Q134 121 124 117\" fill=\"#d69968\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><ellipse cx=\"92\" cy=\"127\" rx=\"7\" ry=\"4\" fill=\"#ce8a63\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M103 141Q119 149 141 134Q136 151 120 153L109 150Z\" fill=\"#835044\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M126 151L132 154L147 142\" fill=\"none\" stroke=\"#eed6a4\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M173 240L187 104\" fill=\"none\" stroke=\"#5e5031\" stroke-width=\"7\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M174 239L188 108\" fill=\"none\" stroke=\"#c2a56b\" stroke-width=\"2\" stroke-linecap=\"round\"/><path d=\"M188 110Q171 108 172 84L174 63M188 110L188 61M188 110Q206 106 205 83L204 64\" fill=\"none\" stroke=\"#79877a\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M157 201L178 191L190 199L187 213L173 216L161 211Z\" fill=\"#e5ae7b\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M57 203L76 207L84 224L71 231L55 224Z\" fill=\"#e5ae7b\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M67 207L50 165M68 201L61 165M73 212L72 172\" fill=\"none\" stroke=\"#b08c39\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M51 172q-12-3-10-12q8 1 10 12q7-9 11-6q-1 8-11 6\" fill=\"#e0bd60\" stroke=\"#a78237\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M54 180q-12-3-10-12q8 1 10 12q7-9 11-6q-1 8-11 6\" fill=\"#e0bd60\" stroke=\"#a78237\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M57 188q-12-3-10-12q8 1 10 12q7-9 11-6q-1 8-11 6\" fill=\"#e0bd60\" stroke=\"#a78237\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M60 196q-12-3-10-12q8 1 10 12q7-9 11-6q-1 8-11 6\" fill=\"#e0bd60\" stroke=\"#a78237\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><ellipse cx=\"99\" cy=\"204\" rx=\"3\" ry=\"3\" fill=\"#c9a454\" stroke=\"#273b38\" stroke-width=\"1\"/><ellipse cx=\"133\" cy=\"204\" rx=\"3\" ry=\"3\" fill=\"#c9a454\" stroke=\"#273b38\" stroke-width=\"1\"/>"
}, Se = "<path d=\"M39 169Q23 149 38 125L54 116L61 92L79 95L89 116Q123 105 156 121L176 135L169 169L159 192L151 233H136L137 185L111 181L97 230H83L92 178L74 160L61 175L43 176Z\" fill=\"#c5d0ba\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M40 141L57 135L67 117L76 117L79 142L67 162L47 163Z\" fill=\"#55756d\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><ellipse cx=\"58\" cy=\"133\" rx=\"6.5\" ry=\"5.5\" fill=\"#faf4e4\" stroke=\"#273b38\" stroke-width=\"1.2\"/><ellipse cx=\"58\" cy=\"133\" rx=\"2.6\" ry=\"4\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"57.2\" cy=\"131.6\" rx=\"0.7\" ry=\"1\" fill=\"white\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M45 126L40 112L53 121M69 117L72 99L80 117\" fill=\"#55756d\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M159 126Q190 131 187 161L198 180Q175 176 174 154L167 147Z\" fill=\"#42665e\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M97 119L151 117L153 156L129 166L93 153Z\" fill=\"#bd7c50\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M104 121L141 122L139 148L107 145Z\" fill=\"#e7c27c\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M111 114L98 78L105 59L141 60L155 86L151 117L133 129Z\" fill=\"#655b7c\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M103 85L89 108L66 113L65 120L93 120L115 99Z\" fill=\"#655b7c\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M67 111L58 116L65 123L73 120Z\" fill=\"#ddb184\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M129 122L149 153L141 176L129 177L130 167L128 153L111 137Z\" fill=\"#514b69\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M129 172L147 172L153 179L129 183Z\" fill=\"#334d50\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M108 55Q103 28 119 18L145 23L158 40L149 67L133 78L116 69Z\" fill=\"#dfb382\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M144 40L167 45Q167 53 149 52L144 64Q131 73 122 58\" fill=\"#d9a678\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><ellipse cx=\"142\" cy=\"37\" rx=\"6.5\" ry=\"5.5\" fill=\"#faf4e4\" stroke=\"#273b38\" stroke-width=\"1.2\"/><ellipse cx=\"141\" cy=\"37\" rx=\"2.6\" ry=\"4\" fill=\"#273b38\" stroke=\"none\" stroke-width=\"1\"/><ellipse cx=\"140.2\" cy=\"35.6\" rx=\"0.7\" ry=\"1\" fill=\"white\" stroke=\"none\" stroke-width=\"1\"/><path d=\"M128 23L138 21\" fill=\"none\" stroke=\"#5a4938\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M115 55L103 48Q97 64 110 78L121 67Z\" fill=\"#e4ddc2\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M121 71L130 74L139 66L133 82L125 85Z\" fill=\"#675d4a\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M104 24L113 5L138 8L154 27Q129 34 104 24Z\" fill=\"#4d5871\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M105 22L151 23L162 32Q120 42 96 31Z\" fill=\"#7d88a1\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M141 10Q157-6 174 3Q160 23 145 18Z\" fill=\"#b7c4a0\" stroke=\"#273b38\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M146 15L167 4\" fill=\"none\" stroke=\"#5e6f5d\" stroke-width=\"1\" stroke-linecap=\"round\"/><path d=\"M69 118Q91 138 128 136\" fill=\"none\" stroke=\"#65543c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><path d=\"M97 93L145 108\" fill=\"none\" stroke=\"#c5ad6b\" stroke-width=\"3\" stroke-linecap=\"round\"/>";
function Ce(e) {
	let t = "";
	if (e === "castle") {
		t += G("M35 202L49 101L78 101L78 172L107 172L107 77L137 77L137 172L167 172L167 112L195 112L204 202Z", "#e7e6c9", W.ink, 2), t += G("M43 101L64 64L86 101Z", W.blue) + G("M98 77L122 26L147 77Z", W.teal) + G("M159 112L181 76L203 112Z", W.rust), t += G("M102 202V167Q122 141 142 167V202Z", "#426d69");
		for (let e of [
			59,
			117,
			177
		]) t += G(`M${e} 122v-12q6-10 12 0v12Z`, "#496a62", W.ink, 1);
		t += K(122, 26, 122, 10, W.ink, 2) + G("M124 10Q141 15 154 8L154 26Q141 32 124 25Z", "#e7c36c", W.ink, 1);
	} else t += G("M30 202V139L67 107L105 137V202Z", "#e5cca4") + G("M23 140L65 98L111 138L105 145L65 114L29 147Z", W.rust), t += G("M104 202V110L150 76L195 111V202Z", "#e8dfbc") + G("M96 112L151 65L205 110L197 118L150 82L103 120Z", "#6e8371"), t += G("M124 202V161Q144 145 161 162V202Z", "#846448") + J(45, 151, 17, 23, "#547d75", 1, W.ink, 1) + J(167, 127, 15, 22, "#547d75", 1, W.ink, 1), t += K(108, 129, 194, 129, "#9e7c54", 3) + K(150, 91, 150, 151, "#9e7c54", 3) + K(108, 128, 130, 150, "#9e7c54", 3);
	if (e === "castle") {
		t += G("M35 202H204L214 209H25Z", "#c7c8a8", W.ink, 1), t += G("M42 137H78M103 111H141M167 146H198", "none", "#bdc7ae", 2), t += G("M108 194V170Q122 151 136 170V194Z", "#233f42", W.ink, 1) + K(116, 163, 116, 194, "#a7b594", 1) + K(126, 159, 126, 194, "#a7b594", 1) + K(108, 179, 136, 179, "#a7b594", 1), t += G("M97 202H147L154 209H91Z", "#e7dfb8", "#798970", 1) + K(97, 205, 146, 205, "#9da88a", 1);
		for (let e = 80; e < 98; e += 7) t += K(53 - (e - 80) * .35, e, 76 + (e - 80) * .35, e, "#89b6b1", .8);
		for (let e = 48; e < 75; e += 7) t += K(112 - (e - 48) * .38, e, 132 + (e - 48) * .38, e, "#82a5a0", .8);
		t += G("M47 101V94H54V101H61V94H68V101H76V95", "none", "#e7e6c9", 4), t += G("M165 112V106H173V112H181V106H188V112H197V106", "none", "#e7e6c9", 4), t += G("M180 78V52M182 53Q194 60 208 53V66Q196 73 182 66", "#e9c77d", W.ink, 1), t += G("M42 202Q24 186 30 168Q41 174 40 182Q31 150 43 151Q58 166 49 187L53 202", "#6c8c75", W.ink, 1), t += G("M197 202Q214 184 205 172Q197 181 200 188Q214 153 221 165Q226 182 207 201", "#8d9e71", W.ink, 1);
	} else t += G("M32 202H195L208 210H23Z", "#d4c3a1", W.ink, 1), t += G("M67 116V202M32 177H103M106 156H194", "none", "#a88a60", 2), t += J(78, 153, 15, 22, "#8b9c7c", 1, W.ink, 1) + K(85, 153, 85, 175, "#dbdab2", 1) + K(45, 162, 62, 162, "#dbdab2", 1), t += K(174, 128, 174, 148, "#dbdab2", 1) + K(167, 136, 182, 136, "#dbdab2", 1), t += G("M41 145H93L100 158H33Z", "#bc925c", W.ink, 1) + G("M42 145L39 157M54 145L53 157M66 145V157M78 145L80 157M90 145L93 157", "none", "#e5ce9d", 2), t += G("M125 201H163M128 197H160", "none", "#c0ad86", 2), t += G("M175 74V53H190V89", "#bb9b71", W.ink, 1) + G("M172 53H193V58H172Z", "#e4d0a5", W.ink, 1), t += G("M175 46Q165 35 175 26M187 44Q198 33 190 22", "none", "#e8eadb", 5), t += G("M23 202Q16 187 23 180Q33 186 32 200M198 201Q196 180 207 176Q218 187 204 202", "#78936c", W.ink, 1);
	return t + q(120, 212, 103, 4, "#273b3818");
}
var we = {
	Steward: [
		"cap",
		"coins",
		"coat",
		0,
		0,
		0
	],
	Scribe: [
		"cap",
		"quill",
		"robe",
		1,
		1,
		-7
	],
	MotherSuperior: [
		"veil",
		"book",
		"robe",
		2,
		2,
		6
	],
	HisHoliness: [
		"mitre",
		"staff",
		"robe",
		3,
		3,
		-4
	],
	Chaplain: [
		"bonnet",
		"cross",
		"robe",
		4,
		4,
		4
	],
	Cardinal: [
		"beret",
		"book",
		"robe",
		5,
		0,
		-6
	],
	Gravedigger: [
		"hood",
		"spade",
		"cloak",
		6,
		1,
		8
	],
	Alchemist: [
		"point",
		"flask",
		"apron",
		7,
		2,
		-9
	],
	Astronomer: [
		"point",
		"stars",
		"robe",
		8,
		3,
		5
	],
	Pilgrim: [
		"straw",
		"staff",
		"cloak",
		9,
		4,
		-5
	],
	Devout: [
		"veil",
		"cross",
		"dress",
		10,
		0,
		8
	],
	Nun: [
		"veil",
		"scroll",
		"robe",
		11,
		1,
		-4
	],
	Architect: [
		"beret",
		"scroll",
		"coat",
		12,
		2,
		7
	],
	Goldsmith: [
		"cap",
		"hammer",
		"apron",
		13,
		3,
		-6
	],
	Apothecary: [
		"bonnet",
		"bottle",
		"robe",
		14,
		4,
		5
	],
	Professor: [
		"beret",
		"book",
		"robe",
		15,
		0,
		-8
	],
	Officer: [
		"helmet",
		"sword",
		"coat",
		16,
		1,
		8
	],
	Captain: [
		"helmet",
		"spear",
		"armor",
		17,
		2,
		-6
	],
	Judge: [
		"bonnet",
		"scales",
		"robe",
		18,
		3,
		3
	],
	Patron: [
		"beret",
		"goblet",
		"coat",
		19,
		4,
		-8
	],
	Guildmaster: [
		"cap",
		"key",
		"coat",
		20,
		0,
		7
	],
	General: [
		"helmet",
		"flag",
		"armor",
		21,
		1,
		-4
	],
	Knight: [
		"helmet",
		"shield",
		"armor",
		22,
		2,
		6
	],
	Lookout: [
		"hood",
		"stars",
		"cloak",
		23,
		3,
		-9
	],
	RoyalGuard: [
		"helmet",
		"sword",
		"armor",
		24,
		4,
		4
	],
	Banker: [
		"bonnet",
		"coins",
		"coat",
		25,
		0,
		-6
	],
	Pawnbroker: [
		"cap",
		"scales",
		"apron",
		26,
		1,
		9
	],
	Chatelaine: [
		"bonnet",
		"key",
		"dress",
		27,
		2,
		-6
	],
	Princess: [
		"crown",
		"rose",
		"dress",
		28,
		3,
		7
	],
	Prince: [
		"beret",
		"lute",
		"coat",
		29,
		4,
		-5
	],
	HisMajesty: [
		"crown",
		"staff",
		"coat",
		30,
		0,
		6
	],
	QueenMother: [
		"crown",
		"goblet",
		"dress",
		31,
		1,
		-7
	],
	Jester: [
		"jester",
		"lute",
		"coat",
		32,
		2,
		10
	],
	Chancellor: [
		"bonnet",
		"scroll",
		"robe",
		33,
		3,
		-4
	],
	Baron: [
		"beret",
		"sword",
		"coat",
		34,
		4,
		7
	],
	HerMajestyTheQueen: [
		"crown",
		"rose",
		"robe",
		35,
		0,
		-8
	],
	Inventor: [
		"cap",
		"gear",
		"apron",
		36,
		1,
		9
	],
	Vicar: [
		"hair",
		"cross",
		"robe",
		37,
		2,
		-5
	],
	MiraculouslyCured: [
		"bonnet",
		"crutch",
		"cloak",
		38,
		3,
		8
	],
	Squire: [
		"cap",
		"shield",
		"coat",
		39,
		4,
		-6
	],
	Philosopher: [
		"hair",
		"scroll",
		"robe",
		40,
		0,
		7
	],
	Doctor: [
		"bonnet",
		"bottle",
		"coat",
		41,
		1,
		-8
	],
	Executioner: [
		"hood",
		"axe",
		"apron",
		42,
		2,
		6
	],
	Barbarian: [
		"hair",
		"axe",
		"cloak",
		43,
		3,
		-7
	],
	Militiaman: [
		"helmet",
		"spear",
		"coat",
		44,
		4,
		8
	],
	Bombardier: [
		"cap",
		"bomb",
		"coat",
		45,
		0,
		-5
	],
	Stonemason: [
		"cap",
		"chisel",
		"apron",
		46,
		1,
		9
	],
	Blacksmith: [
		"hair",
		"hammer",
		"apron",
		47,
		2,
		-6
	],
	MasterAtArms: [
		"helmet",
		"shield",
		"coat",
		48,
		3,
		5
	],
	Mercenary: [
		"hood",
		"sword",
		"armor",
		49,
		4,
		-9
	],
	Sculptor: [
		"beret",
		"chisel",
		"coat",
		50,
		0,
		7
	],
	Clockmaker: [
		"bonnet",
		"clock",
		"apron",
		51,
		1,
		-4
	],
	SpiceMerchant: [
		"bonnet",
		"spices",
		"robe",
		52,
		2,
		9
	],
	Armorer: [
		"cap",
		"shield",
		"apron",
		53,
		3,
		-7
	],
	Potter: [
		"bonnet",
		"pot",
		"apron",
		54,
		4,
		6
	],
	Locksmith: [
		"cap",
		"key",
		"apron",
		55,
		0,
		-9
	],
	Carpenter: [
		"beret",
		"saw",
		"apron",
		56,
		1,
		8
	],
	Witch: [
		"point",
		"broom",
		"cloak",
		57,
		2,
		-6
	],
	Brigand: [
		"hood",
		"dagger",
		"cloak",
		58,
		3,
		7
	],
	Woodcutter: [
		"cap",
		"axe",
		"coat",
		59,
		4,
		-5
	],
	Monk: [
		"hair",
		"book",
		"robe",
		60,
		0,
		8
	],
	Beggar: [
		"hood",
		"bowl",
		"cloak",
		61,
		1,
		-7
	],
	StableBoy: [
		"cap",
		"brush",
		"coat",
		62,
		2,
		6
	],
	Winemaker: [
		"beret",
		"grapes",
		"apron",
		63,
		3,
		-8
	],
	Shepherd: [
		"straw",
		"sheep",
		"cloak",
		64,
		4,
		7
	],
	Usurper: [
		"crown",
		"dagger",
		"cloak",
		65,
		0,
		-5
	],
	Traveler: [
		"straw",
		"bundle",
		"coat",
		66,
		1,
		9
	],
	Farmhand: [
		"bonnet",
		"fork",
		"apron",
		67,
		2,
		-7
	],
	Revolutionary: [
		"cap",
		"flag",
		"coat",
		68,
		3,
		6
	],
	Fisherman: [
		"straw",
		"fish",
		"coat",
		69,
		4,
		-9
	],
	Baker: [
		"bonnet",
		"bread",
		"apron",
		70,
		0,
		7
	],
	Beekeeper: [
		"veil",
		"hive",
		"robe",
		71,
		1,
		-6
	]
};
function Te(e) {
	let t = "#987448", n = "#b5c6b7", r = "#f1e0b3";
	switch (e) {
		case "book": return G("M155 178Q178 170 192 183Q207 176 228 186L222 232Q205 222 189 235Q173 223 151 222Z", r) + G("M190 184L189 232M158 187L180 190M157 194L180 198M199 191L218 193M198 200L216 202", "none", "#9a7851", 1.5);
		case "quill": return Te("book") + G("M176 207L209 113Q227 130 206 162L186 190Z", "#eee5c5") + G("M177 211L209 125M194 162L207 159", "none", t, 1.5);
		case "staff": return G("M191 240L199 91Q176 80 188 63Q203 46 217 67Q225 83 210 91", "none", "#c3a054", 7) + q(204, 67, 7, 8, "#72a7a1", W.ink, 1);
		case "cross": return G("M193 236V117M170 142H216", "none", "#caa358", 9) + G("M193 230V122M175 142H211", "none", r, 2);
		case "spade": return G("M191 239L202 85M195 88Q179 62 202 61Q226 62 211 86Z", "none", t, 7) + G("M183 198L207 201L211 226L195 240L179 224Z", n);
		case "flask": return G("M192 140H213V164L232 211Q235 231 204 232Q176 229 181 210L198 163V140Z", "#a3c6b1") + G("M188 198Q207 189 226 201L230 217Q218 230 190 222Z", "#b2a84d", "none") + G("M194 144H215M199 174L190 195", "none", r, 3);
		case "stars": return G("M180 214L209 110L218 114L195 218Z", t) + q(214, 111, 18, 10, "#b7c8ab", W.ink, 2) + q(214, 111, 12, 6, "#3f7272") + G("M167 103L171 113L182 116L172 120L169 131L165 121L155 117L165 113Z", "#e0be64");
		case "scroll": return G("M154 180Q150 166 163 164H219Q231 173 221 184L215 221H161L169 179Z", r) + G("M166 164Q180 170 169 179M175 188H207M173 196H209M172 205H196", "none", t, 1.5);
		case "hammer": return G("M189 238L211 128L218 130L199 239Z", t) + G("M188 128L196 108L234 121L230 140Z", n) + G("M195 113L229 123", "none", "#e0e5cb", 3);
		case "bottle": return G("M196 144V127H213V145L224 157V219Q209 232 190 220V160Z", "#8ba377") + J(195, 125, 19, 10, t, 2, W.ink) + G("M194 177H219V204H194Z", r) + G("M203 184V198M198 191H210", "none", "#9b5848", 3);
		case "sword": return G("M194 225L207 100L216 87L222 104L205 227Z", n) + G("M183 211L216 215M195 218L192 239", "none", "#bf9a4d", 7) + K(210, 113, 201, 204, "#f4efd0", 2);
		case "scales": return G("M195 235V134M165 151L222 145M174 152L160 187M174 152L188 187M213 148L199 183M213 148L229 183", "none", "#c6a052", 3) + G("M153 187H191Q177 209 153 187M196 183H231Q214 205 196 183", "#dcb968") + q(195, 133, 5, 6, "#d5b562", W.ink, 1);
		case "coins": return G("M158 204L162 185H213L224 219Q201 239 162 224Z", t) + [
			0,
			1,
			2,
			3
		].map((e) => q(173 + e * 11, 200 + e % 2 * 9, 9, 6, "#dfba5b", W.ink, 1)).join("") + K(168, 189, 209, 189, r, 2);
		case "goblet": return G("M179 145H225Q231 185 204 188Q174 187 179 145Z", "#d1aa53") + G("M203 188V218M187 221H220", "none", "#d1aa53", 6) + G("M185 151H218M185 157Q183 174 194 178", "none", r, 2);
		case "rose": return G("M193 237Q201 190 206 148M196 214Q177 210 183 193Q199 194 196 214M201 192Q224 188 223 174Q201 174 201 192", "#78956a") + G("M202 151Q181 147 191 133Q185 117 202 119Q213 106 220 123Q238 127 225 142Q218 156 202 151Z", "#b65e55") + G("M204 143Q193 132 205 128Q220 126 215 138Z", "#d78c70");
		case "lute": return G("M186 175L215 110L224 114L199 184Q223 208 205 230Q182 250 163 228Q149 208 174 190Z", "#c29b58") + q(185, 209, 7, 10, W.ink) + G("M181 227L219 118M185 228L222 118", "none", r, 1) + G("M211 107L228 111L227 125L208 120Z", t);
		case "gear": return G("M195 161L202 153L211 158L222 157L225 168L233 175L229 185L232 196L220 201L214 212L203 207L192 211L185 201L174 197L177 186L172 176L185 170L188 159Z", "#b39958") + q(204, 183, 13, 14, "#e0c98b", W.ink, 2) + q(204, 183, 5, 6, W.ink);
		case "crutch": return G("M195 239L207 136M183 139Q203 149 226 139M197 183H216", "none", t, 7);
		case "axe": return G("M185 240L215 103", "none", t, 9) + G("M212 106Q230 109 237 99L235 148Q219 132 204 133Z", n) + K(228, 116, 229, 135, r, 2);
		case "spear": return G("M199 239L207 99", "none", t, 6) + G("M201 103L198 83L210 52L219 85L213 104Z", n) + K(210, 61, 207, 98, r, 2);
		case "bomb": return q(201, 205, 27, 28, "#4c6260", W.ink, 2) + G("M193 179L197 166L211 168L213 180Z", t) + G("M206 167Q218 146 226 162", "none", "#bb9d62", 3) + G("M225 159L219 148M228 157L235 149", "none", "#c77848", 3) + G("M184 201Q180 188 193 185", "none", "#9dad9e", 3);
		case "chisel": return G("M182 240V205L200 178L223 193L223 240Z", "#c2c1a4") + G("M188 223L220 145L225 148L195 226Z", n) + G("M215 145L226 122L234 125L226 150Z", t) + K(194, 232, 213, 216, "#818e7d", 2);
		case "shield": return G("M158 165L220 158L226 209Q216 237 193 240Q167 225 162 206Z", "#7e9b94") + G("M168 173L211 168L216 208Q208 226 193 229Q178 217 173 202Z", "none", "#e5dbb8", 3) + G("M190 178V215M177 192H207", "none", "#dbb15e", 6);
		case "clock": return q(203, 196, 30, 33, "#a77949", W.ink, 2) + q(203, 195, 24, 26, r, W.ink, 1.5) + G("M203 176V195L216 202", "none", W.ink, 3) + [
			0,
			1,
			2,
			3
		].map((e) => {
			let t = e * Math.PI / 2;
			return q(203 + 19 * Math.sin(t), 195 + 21 * Math.cos(t), 2, 2, W.ink);
		}).join("");
		case "spices": return G("M159 233L163 201H184L189 233M188 233L194 193H218L228 233Z", "#b38957") + G("M163 201Q175 171 184 201Z", "#c7a044") + G("M194 193Q205 163 218 193Z", "#b86845") + K(168, 215, 182, 215, r, 2);
		case "pot": return G("M192 163H216L211 180Q232 191 226 217Q222 237 199 236Q175 227 183 203L197 179Z", "#b87f55") + G("M192 163H216M186 205H225M185 214H226", "none", "#e6c190", 3);
		case "key": return G("M196 236L207 168", "none", "#bb8a51", 9) + q(210, 150, 18, 20, "#c29a5b", W.ink, 2) + q(210, 150, 8, 9, r, W.ink, 1) + G("M198 216L211 218M201 204L214 206", "none", "#c29a5b", 8);
		case "saw": return G("M146 222L211 169L228 186L170 234L168 227L161 232L160 223L153 227Z", n) + G("M207 169L222 149L238 165L225 186Z", t) + G("M219 168L225 160L231 166L225 176Z", W.paper);
		case "broom": return G("M188 221L218 93", "none", t, 6) + G("M182 193L203 197L213 240H159Z", "#c8aa62") + G("M180 212L170 240M187 213L182 240M196 213L200 240", "none", t, 1.5) + K(178, 208, 205, 214, "#7b5d3e", 4);
		case "dagger": return G("M176 232L212 160L222 156L221 169L187 237Z", n) + G("M178 217L200 228M185 228L179 240", "none", "#c2a05c", 5);
		case "bowl": return G("M160 203Q191 194 224 204Q220 232 192 233Q164 229 160 203Z", t) + q(192, 204, 30, 8, "#d6c08e", W.ink, 1) + q(187, 202, 8, 4, "#e1bd68", W.ink, 1);
		case "brush": return G("M194 230L211 156L223 159L207 234Z", t) + G("M205 155L212 131L231 137L224 162Z", "#bba274") + G("M214 132L210 155M220 134L216 156M226 135L222 157", "none", "#eadab0", 2);
		case "grapes": return G("M203 174L215 140M208 162Q189 144 185 161Q188 176 208 162", "#7c945e") + [
			0,
			1,
			2,
			3,
			4,
			5
		].map((e) => q(192 + e % 3 * 12 + (e > 2 ? 6 : 0), 180 + Math.floor(e / 3) * 14, 9, 10, "#82738a", W.ink, 1.3)).join("") + q(208, 211, 9, 10, "#82738a", W.ink, 1.3);
		case "sheep": return G("M155 218Q147 205 160 198Q154 181 171 180Q177 166 189 179Q204 167 212 183Q228 184 224 202Q234 217 217 227L171 233Z", "#ede5cb") + G("M211 192Q229 186 233 205L227 220L215 220L207 207Z", "#65766b") + q(223, 202, 2, 3, W.ink) + G("M173 228V239M205 228V239", "none", W.ink, 5);
		case "bundle": return G("M194 237L207 104", "none", t, 6) + G("M207 112Q172 104 166 131Q160 158 187 167Q213 173 219 150Z", "#b7825b") + G("M188 114L206 148M176 121L192 153", "none", "#deb887", 2);
		case "fork": return G("M198 240L207 124M187 90L189 125L207 140L227 123L228 88M207 83V140", "none", t, 5);
		case "flag": return G("M197 239L207 69", "none", t, 5) + G("M209 73Q223 67 239 77V134Q223 122 205 131Z", "#a85e4b") + G("M212 83L234 87M211 91L230 94", "none", "#e7bb78", 2);
		case "fish": return G("M193 240L212 86Q239 93 228 146L212 178", "none", t, 3) + G("M190 171Q216 181 218 205L230 220L216 223Q201 237 187 220Q174 201 190 171Z", "#93b3a8") + G("M187 189L204 203L183 207Z", "#d4dfc1") + q(192, 181, 3, 4, W.ink) + G("M201 210L209 216M198 217L204 224", "none", "#668d83", 1.5);
		case "bread": return G("M153 224Q156 181 187 180Q216 176 230 205Q239 227 216 233H171Z", "#c9a05e") + G("M170 199L179 212M185 191L195 205M201 192L212 208", "none", "#f2d495", 5);
		case "hive": return G("M158 232Q158 205 166 199Q163 187 177 181Q177 168 192 168Q211 167 215 181Q229 185 225 198Q238 210 231 232Z", "#caac66") + G("M170 198H224M163 213H231M177 183H216", "none", "#8d743f", 2) + G("M187 232V220Q196 208 204 220V232Z", "#40564c") + [0, 1].map((e) => q(160 + e * 68, 173 + e * 29, 5, 3, "#b89c58", W.ink, 1) + q(157 + e * 68, 168 + e * 29, 4, 3, "#f4edcd")).join("");
	}
}
function Ee([e, t, n, r, i, a], o) {
	let s = [
		"#e7b68b",
		"#cd9672",
		"#b68160",
		"#edd0a0",
		"#d5a481"
	], c = [
		"#526f76",
		"#9b6451",
		"#777f59",
		"#88758a",
		"#ab8456",
		"#4d7871"
	], l = s[i], u = c[r % c.length], d = [
		"#a5683f",
		"#604a38",
		"#b5b19a",
		"#473f35",
		"#c39050"
	][r % 5], f = 27 + r % 5 * 3, p = 160 + r % 4 * 4, m = G("M24 0H216V221L190 211L164 223L138 212L110 224L82 213L55 223L24 213Z", [
		"#97aaa1",
		"#b5a78c",
		"#9b9d8d",
		"#a8979e"
	][r % 4], "none") + J(30, 0, 180, 215, "url(#cc-tapestry)");
	m += G(`M${51 + r % 3 * 4} 240Q52 198 91 178L146 175Q183 185 200 240Z`, u), n === "apron" && (m += G("M87 180L98 179L103 205H142L145 178L155 183L156 240H81L94 207Z", "#d8c39b") + G("M98 214H144V238H98Z", "#bba47c", W.ink, 1) + K(103, 218, 103, 234, "#eddfb4", 1)), n === "robe" && (m += G("M93 178L119 207L145 177L157 240H76Z", "#d1c2a0") + G("M97 188L112 222L106 240M143 189L126 222L133 240", "none", u, 8)), n === "armor" && (m += G("M79 185L98 177L118 190L143 175L166 184L159 231L120 240L84 228Z", "#9db0a5") + G("M88 195L119 204L153 193M120 204V234M87 219L110 225M134 226L153 218", "none", "#d9dfc7", 3) + q(120, 201, 3, 3, "#bd9d5e", W.ink, 1)), n === "dress" && (m += G("M91 179L118 206L147 178L162 240H77Z", "#c7b188") + G("M99 209L108 240M137 208L131 240", "none", u, 6) + [
		0,
		1,
		2,
		3
	].map((e) => q(120, 211 + e * 8, 2.5, 2.5, "#e2bd64", W.ink, .7)).join("")), n === "cloak" && (m += G("M81 176L113 199L151 173L184 196L162 204L191 240H132L115 213L97 240H48L69 206L57 197Z", "#455e60") + q(115, 201, 7, 7, "#bd9f60", W.ink, 1)), n === "coat" && (m += G("M82 185L97 178L118 203L141 176L158 185L142 209L125 201L130 240H107L110 208L95 215Z", "#e5d5ae") + G("M116 215V240", "none", W.ink, 1.3)), m += `<g transform="rotate(${a} 119 146)">` + G("M101 152L97 182Q116 198 140 180L137 149Z", l), m += G(`M${119 - f - 9} 65Q69 39 92 27Q119 9 150 33Q176 40 ${119 + f + 9} 79L162 123H81Z`, d), m += G(`M${119 - f} 61Q116 44 ${119 + f} 64L${123 + f} 104L${137 + f} 115Q${143 + f} 124 ${123 + f} 128Q147 ${p} 124 ${p + 6}Q95 ${p + 4} 87 138L${116 - f} 118L${108 - f} 105Q67 88 ${119 - f} 94Z`, l), m += G(`M${119 - f} 62Q101 77 120 65Q139 82 ${119 + f} 65`, "none", d, 8);
	let h = 99 + r % 3 * 3;
	return m += G(`M91 ${h - 10}Q99 ${h - 16} 109 ${h - 10}M130 ${h - 11}Q141 ${h - 17} 151 ${h - 9}`, "none", d, 3), m += [101, 141].map((e) => q(e, h, 6.5, 5.5, "#faf4e4", W.ink, 1.2) + q(e + a / 6, h, 2.5, 4, W.ink) + q(e + a / 6 - .8, h - 1.4, .7, 1, "white")).join(""), m += G(`M121 ${h}L116 123L131 126L134 121`, "none", "#815d45", 1.5) + q(94, 130, 7, 4, "#c8826b"), o ? m += G("M108 145Q124 151 141 139Q131 160 118 155Z", "#a55b52") + G("M113 146L135 143", "none", "#f4e5bd", 2) + q(86, 118, 3, 5, "#ddbb68", W.ink, 1) : r % 4 == 0 ? m += G("M97 139Q111 153 130 141L146 133Q150 161 126 175Q102 173 97 139Z", d) + G("M112 145L134 142", "none", "#e8d6af", 2) : r % 4 == 1 ? m += G("M107 143Q124 150 142 137Q132 159 119 155Z", "#8f5143") + G("M112 145L136 141L132 147L117 149Z", "#f4e5bd", "none") : r % 4 == 2 ? m += G("M107 141Q118 132 126 141Q138 129 147 139Q140 151 127 145Q115 153 107 141Z", d) + G("M117 157Q126 163 136 154", "none", "#8b624b", 1.5) : m += G("M109 147Q126 153 141 144", "none", "#855142", 2.5), e === "cap" && (m += G("M77 64Q69 32 104 29L148 30Q165 39 164 61L125 54Z", u) + G("M75 60Q116 45 169 59L178 67L92 71Z", u) + K(98, 35, 98, 53, "#e0c995", 2)), e === "beret" && (m += G("M73 57Q56 30 96 19Q135 6 167 32L176 49L155 61L119 52L88 65Z", u) + G("M105 21L115 48M147 26L140 48", "none", "#d5bb83", 2) + G("M149 28Q177 3 198 13Q181 41 154 39Z", "#ded7ac")), e === "bonnet" && (m += G("M76 65Q61 43 81 29Q87 12 106 25Q122 13 138 25Q165 23 170 47L157 67L119 57Z", "#c6c6a7") + G("M79 60Q115 48 164 61", "none", u, 7) + G("M86 36L101 48M118 29L121 47M151 34L142 48", "none", "#ece3bc", 2)), e === "veil" && (m += G("M78 64Q71 29 106 23Q140 14 164 47L177 164L153 174L146 65Q115 48 89 68L89 168L66 159Z", r === 71 ? "#c6bd93" : u) + G("M80 67Q117 47 152 64M83 69L80 154M158 69L165 153", "none", "#eee5c6", 5) + (r === 71 ? G("M86 70H151V157H88Z", "none", "#b9b79d", 2) + Array.from({ length: 6 }, (e, t) => K(87 + t * 12, 73, 90 + t * 11, 153, "#d9d8b9", 1)).join("") : "")), e === "mitre" && (m += G("M77 61L82 28L119 0L159 29L165 62L118 53Z", "#d7c78b") + G("M118 8V51M98 33H139", "none", "#b98455", 7) + G("M81 63L74 136M160 62L174 130", "none", "#e0cf93", 10)), e === "hood" && (m += G("M72 155Q43 111 65 63Q80 32 111 16Q157 35 174 81L181 143L154 172L148 146L158 101L144 65L112 47L83 79L82 122L94 158Z", u) + G("M75 130Q65 83 86 58L110 31L148 55L164 93", "none", "#b4b6a0", 4)), e === "helmet" && (m += G("M76 80Q64 32 112 23Q162 15 169 72L164 93L148 78L143 47L119 36L90 54L93 84Z", "#aabdb2") + G("M77 67L164 60M120 29L124 58", "none", "#d6dfc9", 4) + G("M83 79L89 126L77 138L72 91M156 78L168 122L157 137L151 92Z", "#839e95") + (r % 2 ? G("M111 25Q119 2 143 7L145 25Z", "#aa5d4a") : "")), e === "crown" && (m += G("M76 58L71 24L94 36L117 11L140 35L164 21L160 58Z", "#d0ab57") + G("M79 49H158", "none", "#f0dc9c", 3) + [
		89,
		118,
		146
	].map((e, t) => q(e, 43, 4, 5, t === 1 ? "#9e5c5a" : "#64948a", W.ink, 1)).join("")), e === "jester" && (m += G("M73 63Q55 10 87 14L114 39Q135 -1 156 14L168 64L147 57L135 37L117 62L100 38L92 63Z", u) + q(66, 20, 6, 6, "#d6b45f", W.ink, 1) + q(155, 15, 6, 6, "#d6b45f", W.ink, 1) + G("M77 165L105 181L121 164L139 181L158 163L159 186L139 195L120 184L101 196L81 186Z", "#c8ac68")), e === "straw" && (m += G("M76 53L88 22L135 19L159 52Q198 58 190 68L153 77L78 74L52 66Q43 58 76 53Z", "#ceb56c") + G("M79 52Q123 64 159 51", "none", u, 7) + [
		91,
		103,
		116,
		130,
		143
	].map((e) => K(e, 29, e - 5, 47, "#957b43", 1)).join("")), e === "point" && (m += G("M66 64L94 42L121 0L146 19L151 50L175 63L168 75L110 67L77 76Z", u) + G("M94 48L148 54", "none", "#c4ac6e", 7) + G("M124 17L128 34M119 27L137 25", "none", "#e2c76f", 2)), e === "hair" && (m += G("M73 62Q61 38 84 33Q76 12 99 20Q115 5 129 21Q149 8 158 31Q181 32 168 62L150 46Q137 55 120 42Q102 58 84 46Z", d) + G("M84 37Q92 26 102 32M129 29Q141 22 151 36", "none", "#d5bf8e", 3)), m += "</g>", m += Te(t), m += G(r % 2 ? "M62 221Q64 204 81 199L107 210L103 223L84 217L78 240H58Z" : "M64 232L69 210L89 202L110 215L106 228L86 222L81 240Z", l) + G("M173 217L184 202L203 205L207 216L190 225Z", l) + G("M183 210L199 212M182 215L198 217", "none", "#926a4e", 1), m;
}
var De = /* @__PURE__ */ new Set([
	"MotherSuperior",
	"Devout",
	"Nun",
	"Chatelaine",
	"Princess",
	"QueenMother",
	"HerMajestyTheQueen",
	"Witch"
]), Oe = Object.fromEntries(Object.entries(we).map(([e, t]) => [e, Ee(t, De.has(e))])), ke = {
	castle: Ce("castle"),
	village: Ce("village")
};
function Ae({ id: e, className: t }) {
	let n = `cc-tapestry-${r().replaceAll(":", "")}`, i = (xe[e] ?? Oe[e]).replaceAll("cc-tapestry", n);
	return /* @__PURE__ */ g("svg", {
		className: t,
		viewBox: "0 0 240 240",
		"aria-hidden": "true",
		focusable: "false",
		children: [/* @__PURE__ */ h("defs", { children: /* @__PURE__ */ h("pattern", {
			id: n,
			width: "32",
			height: "32",
			patternUnits: "userSpaceOnUse",
			children: /* @__PURE__ */ h("path", {
				d: "M16 5Q11 12 16 17Q21 12 16 5M6 21Q11 16 16 21Q11 26 6 21M26 21Q21 16 16 21Q21 26 26 21",
				fill: "none",
				stroke: "#fff",
				strokeWidth: ".9"
			})
		}) }), /* @__PURE__ */ h("g", { dangerouslySetInnerHTML: { __html: i } })]
	});
}
function je({ place: e, className: t }) {
	return /* @__PURE__ */ h("svg", {
		className: t,
		viewBox: "15 0 215 225",
		"aria-hidden": "true",
		focusable: "false",
		children: /* @__PURE__ */ h("g", { dangerouslySetInnerHTML: { __html: ke[e] } })
	});
}
function Me({ className: e }) {
	return /* @__PURE__ */ h("svg", {
		className: e,
		width: "100%",
		height: "100%",
		viewBox: "20 0 190 240",
		"aria-hidden": "true",
		focusable: "false",
		children: /* @__PURE__ */ h("g", { dangerouslySetInnerHTML: { __html: Se } })
	});
}
//#endregion
//#region src/games/castlecombo/describe.ts
var Ne = {
	nobility: "👑",
	faith: "⛪",
	scholarship: "📚",
	military: "⚔️",
	craftsmanship: "⚒️",
	peasantry: "🌾"
}, Pe = {
	nobility: "games.castlecombo.shield.nobility",
	faith: "games.castlecombo.shield.faith",
	scholarship: "games.castlecombo.shield.scholarship",
	military: "games.castlecombo.shield.military",
	craftsmanship: "games.castlecombo.shield.craftsmanship",
	peasantry: "games.castlecombo.shield.peasantry"
}, Fe = {
	castle: "games.castlecombo.place.castle",
	village: "games.castlecombo.place.village"
}, Ie = (e, t) => `${Ne[t]}${e(Pe[t])}`, Le = (e, t) => e(Fe[t]);
function Re(e) {
	let t = (t) => e[t].every(Boolean), n = (t) => e.every((e) => e[t]);
	return t(0) ? "games.castlecombo.pos.topRow" : t(1) ? "games.castlecombo.pos.midRow" : t(2) ? "games.castlecombo.pos.bottomRow" : n(0) ? "games.castlecombo.pos.leftCol" : n(1) ? "games.castlecombo.pos.midCol" : n(2) ? "games.castlecombo.pos.rightCol" : e[0][0] && e[0][2] && e[2][0] && e[2][2] ? "games.castlecombo.pos.corners" : "games.castlecombo.pos.edges";
}
function ze(e, t, n = !1) {
	let r = (t, r) => {
		let i = e(t, r);
		return n ? i : e("games.castlecombo.cond.per", { what: i });
	};
	switch (t.type) {
		case "perShield": return t.line && t.column ? r("games.castlecombo.cond.shieldCross", { shield: Ie(e, t.shield) }) : t.line ? r("games.castlecombo.cond.shieldLine", { shield: Ie(e, t.shield) }) : t.column ? r("games.castlecombo.cond.shieldColumn", { shield: Ie(e, t.shield) }) : r("games.castlecombo.cond.shield", { shield: Ie(e, t.shield) });
		case "perDifferentShield": return t.line ? r("games.castlecombo.cond.differentLine") : t.column ? r("games.castlecombo.cond.differentColumn") : r("games.castlecombo.cond.different");
		case "perMissingShield": return r("games.castlecombo.cond.missing");
		case "ifShieldMissing": return e("games.castlecombo.cond.ifMissing", { shield: Ie(e, t.shield) });
		case "perShieldSet": return r("games.castlecombo.cond.shieldSet", { shields: t.shields.map((e) => Ne[e]).join("+") });
		case "perIdenticalSet": return r("games.castlecombo.cond.identicalSet", { count: t.count });
		case "perKey": return r("games.castlecombo.cond.key");
		case "perBanner": return r("games.castlecombo.cond.banner", { place: Le(e, t.place) });
		case "perBannerSet": return r("games.castlecombo.cond.bannerSet", { places: t.places.map((t) => Le(e, t)).join("+") });
		case "perCardShieldCount": return r("games.castlecombo.cond.shieldCount", { count: t.count });
		case "perCardCost": return t.orGreater ? r("games.castlecombo.cond.costOrMore", { cost: t.cost }) : r("games.castlecombo.cond.cost", { cost: t.cost });
		case "perCardDiscount": return r("games.castlecombo.cond.discount");
		case "ifFaceDown": return e("games.castlecombo.cond.ifFaceDown");
		case "perCardPurse": return r("games.castlecombo.cond.purseCard");
		case "perPurseGold": return r("games.castlecombo.cond.purseGold");
		case "perAllPurseGold": return r("games.castlecombo.cond.allPurseGold");
		case "perCard": return r("games.castlecombo.cond.card");
		case "perEmpty": return r("games.castlecombo.cond.empty");
		case "ifPosition": return e("games.castlecombo.cond.ifPosition", { pos: e(Re(t.pos)) });
		case "bestNeighbor": return e("games.castlecombo.cond.bestNeighbor", { what: ze(e, t.cond, !0) });
	}
}
function Be(e, t) {
	return t.effects.map((t) => Ve(e, t));
}
function Ve(e, t) {
	switch (t.type) {
		case "discount": {
			let n = (t.castle ?? 0) + (t.village ?? 0);
			return t.castle && t.village ? e("games.castlecombo.eff.discountBoth", { n }) : t.castle ? e("games.castlecombo.eff.discountCastle", { n }) : e("games.castlecombo.eff.discountVillage", { n });
		}
		case "gainGold":
		case "gainKeys": {
			let n = t.cond ? e(t.type === "gainGold" ? "games.castlecombo.eff.gainGoldPer" : "games.castlecombo.eff.gainKeysPer", {
				what: ze(e, t.cond),
				n: t.gain
			}) : e(t.type === "gainGold" ? "games.castlecombo.eff.gainGold" : "games.castlecombo.eff.gainKeys", { n: t.gain });
			return t.opponentsGain ? e("games.castlecombo.eff.withOpponents", {
				main: n,
				opp: e(t.type === "gainGold" ? "games.castlecombo.eff.opponentsGold" : "games.castlecombo.eff.opponentsKeys", { n: t.opponentsGain })
			}) : n;
		}
		case "putGold": return t.cardsLimit ? e("games.castlecombo.eff.putGoldFill", { n: t.cardsLimit }) : e("games.castlecombo.eff.putGoldEach", { n: t.gold ?? 0 });
		case "discardRiver": return e(t.token === "gold" ? "games.castlecombo.eff.discardRiverGold" : "games.castlecombo.eff.discardRiverKey", { place: Le(e, t.river) });
		case "choose": return e("games.castlecombo.eff.choose", {
			a: Ve(e, t.a),
			b: Ve(e, t.b)
		});
	}
}
function He(e, t) {
	let { score: n, cond: r } = t.scoring;
	return r.type === "perPurseGold" ? e("games.castlecombo.score.purse", {
		n,
		limit: r.limit
	}) : e("games.castlecombo.score.per", {
		what: ze(e, r),
		n
	});
}
//#endregion
//#region src/games/castlecombo/icons.tsx
function Y({ n: e }) {
	return /* @__PURE__ */ g("svg", {
		className: "cc-object",
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ h("ellipse", {
				cx: "16",
				cy: "18",
				rx: "14",
				ry: "13",
				fill: "#98712f",
				stroke: "#273b38"
			}),
			/* @__PURE__ */ h("ellipse", {
				cx: "16",
				cy: "15",
				rx: "14",
				ry: "13",
				fill: "#e6bd61",
				stroke: "#273b38"
			}),
			/* @__PURE__ */ h("ellipse", {
				cx: "16",
				cy: "15",
				rx: "10.5",
				ry: "9.5",
				fill: "#f5d88c",
				stroke: "#b88a39"
			}),
			e === void 0 ? /* @__PURE__ */ h("path", {
				d: "M12 20V10L16 7L21 11L19 16L15 18Z",
				fill: "#b3873d"
			}) : /* @__PURE__ */ h("text", {
				x: "16",
				y: "21",
				textAnchor: "middle",
				fontSize: "18",
				fontWeight: "800",
				fill: "#273b38",
				children: e
			})
		]
	});
}
function X() {
	return /* @__PURE__ */ g("svg", {
		className: "cc-object",
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ h("path", {
				d: "M9 3C2 3 1 14 8 17V28L12 30L16 28V24H12V21H16V17C24 13 22 3 15 3L12 6Z",
				fill: "#ba6850",
				stroke: "#273b38",
				strokeWidth: "1.3"
			}),
			/* @__PURE__ */ h("ellipse", {
				cx: "12",
				cy: "10",
				rx: "3.2",
				ry: "3.5",
				fill: "#faf4e4",
				stroke: "#273b38"
			}),
			/* @__PURE__ */ h("path", {
				d: "M10 18V27",
				stroke: "#e7a482"
			})
		]
	});
}
function Ue() {
	return /* @__PURE__ */ g("svg", {
		className: "cc-object",
		viewBox: "0 0 36 36",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ h("path", {
				d: "M7 23L5 35L13 30L18 34L21 22",
				fill: "#b9823c"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "18",
				cy: "16",
				r: "15",
				fill: "#b27635",
				stroke: "#273b38"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "18",
				cy: "15",
				r: "12",
				fill: "#efd081",
				stroke: "#f9e3aa"
			}),
			/* @__PURE__ */ h("path", {
				d: "M18 6L21 12L27 15L21 18L18 25L15 18L9 15L15 12Z",
				fill: "#52675b"
			})
		]
	});
}
var We = {
	nobility: "#3c85a0",
	faith: "#8b5981",
	scholarship: "#c3a243",
	military: "#a84e42",
	craftsmanship: "#b7804a",
	peasantry: "#6d8350"
}, Ge = {
	nobility: /* @__PURE__ */ h("path", { d: "M8 12L11 15L15 9L19 15L23 12L21 22H10Z" }),
	faith: /* @__PURE__ */ h("path", { d: "M13 8H18V13H23V18H18V25H13V18H8V13H13Z" }),
	scholarship: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", { d: "M6 11Q11 8 15 12Q20 8 25 11V24Q20 21 15 25Q11 21 6 24Z" }), /* @__PURE__ */ h("path", {
		d: "M15 13V23",
		fill: "none",
		stroke: "#c3a243"
	})] }),
	military: /* @__PURE__ */ h("path", {
		d: "M8 8L22 22M22 8L8 22M5 18L11 24M19 24L25 18",
		fill: "none",
		stroke: "#faf4e4",
		strokeWidth: "2.3"
	}),
	craftsmanship: /* @__PURE__ */ h("path", {
		d: "M9 9L20 20M6 20L20 6M15 7L22 14",
		fill: "none",
		stroke: "#faf4e4",
		strokeWidth: "2.8"
	}),
	peasantry: /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("path", {
		d: "M16 8V26",
		fill: "none",
		stroke: "#faf4e4",
		strokeWidth: "1.8"
	}), [
		10,
		15,
		20
	].map((e) => /* @__PURE__ */ h("path", { d: `M16 ${e + 3}Q7 ${e + 1} 9 ${e - 3}Q15 ${e - 2} 16 ${e + 3}Q24 ${e} 23 ${e - 3}Q18 ${e - 2} 16 ${e + 3}` }, e))] })
};
function Ke({ shield: e }) {
	return /* @__PURE__ */ g("svg", {
		className: "cc-object cc-shield",
		viewBox: "0 0 32 33",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ h("path", {
				d: "M3 3H28L27 19Q24 27 15.5 31Q7 27 4 19Z",
				fill: We[e],
				stroke: "#273b38",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ h("path", {
				d: "M6 6H25L24 18Q22 24 15.5 27Q10 24 7 18Z",
				fill: "none",
				stroke: "#ffffff9a",
				strokeWidth: ".9"
			}),
			/* @__PURE__ */ h("g", {
				fill: "#faf4e4",
				children: Ge[e]
			})
		]
	});
}
function qe() {
	return /* @__PURE__ */ g("svg", {
		className: "cc-object",
		viewBox: "0 0 36 38",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ h("path", {
			d: "M6 10L10 3H24L28 10L34 31Q19 40 1 31Z",
			fill: "#b17c48",
			stroke: "#273b38",
			strokeWidth: "1.4"
		}), /* @__PURE__ */ h("path", {
			d: "M7 11H28M10 6H24",
			stroke: "#f0d8a7",
			strokeWidth: "2"
		})]
	});
}
function Je() {
	return /* @__PURE__ */ g("svg", {
		className: "cc-object",
		viewBox: "0 0 28 34",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ h("path", {
			d: "M2 6L14 3L23 0V23L14 18L2 16Z",
			fill: "#bd9250",
			stroke: "#273b38",
			strokeWidth: "1.5"
		}), /* @__PURE__ */ h("path", {
			d: "M8 16V26Q8 32 16 32",
			fill: "none",
			stroke: "#273b38",
			strokeWidth: "2"
		})]
	});
}
function Ye({ place: e }) {
	return /* @__PURE__ */ g("svg", {
		className: "cc-object",
		viewBox: "0 0 28 34",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ h("path", {
			d: "M3 2H25V25L14 32L3 25Z",
			fill: e === "castle" ? "#728c86" : "#a48260",
			stroke: "#273b38"
		}), /* @__PURE__ */ h("path", {
			d: e === "castle" ? "M7 12V8H10V12H13V8H16V12H20V24H7Z" : "M5 16L14 7L23 16H20V25H9V16Z",
			fill: "#f1dfb3"
		})]
	});
}
function Xe({ pos: e }) {
	return /* @__PURE__ */ h("svg", {
		className: "cc-object cc-position",
		viewBox: "0 0 30 30",
		"aria-hidden": "true",
		children: e.flatMap((e, t) => e.map((e, n) => /* @__PURE__ */ h("rect", {
			x: n * 10 + 1,
			y: t * 10 + 1,
			width: "8",
			height: "8",
			rx: "1",
			fill: e ? "#244b45" : "#f5edda",
			stroke: "#8b947e",
			strokeWidth: ".7"
		}, `${n}:${t}`)))
	});
}
function Z({ children: e }) {
	return /* @__PURE__ */ h("span", {
		className: "cc-small-card",
		children: e ?? "•"
	});
}
function Ze({ cond: e }) {
	switch (e.type) {
		case "ifPosition": return /* @__PURE__ */ h(Xe, { pos: e.pos });
		case "perKey": return /* @__PURE__ */ h(X, {});
		case "perShield": return /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(Ke, { shield: e.shield }), (e.line || e.column) && /* @__PURE__ */ h("span", { children: e.line && e.column ? "✛" : e.line ? "↔" : "↕" })] });
		case "perDifferentShield": return /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("span", { children: "◇◇" }), (e.line || e.column) && /* @__PURE__ */ h("span", { children: e.line ? "↔" : "↕" })] });
		case "perMissingShield": return /* @__PURE__ */ h("span", {
			className: "cc-crossed",
			children: "◇"
		});
		case "ifShieldMissing": return /* @__PURE__ */ h("span", {
			className: "cc-crossed",
			children: /* @__PURE__ */ h(Ke, { shield: e.shield })
		});
		case "perShieldSet": return /* @__PURE__ */ h("span", {
			className: "cc-mark-set",
			children: e.shields.map((e, t) => /* @__PURE__ */ h(Ke, { shield: e }, t))
		});
		case "perIdenticalSet": return /* @__PURE__ */ g("span", { children: [e.count, "×◇"] });
		case "perBanner": return /* @__PURE__ */ h(Ye, { place: e.place });
		case "perBannerSet": return /* @__PURE__ */ h("span", {
			className: "cc-mark-set",
			children: e.places.map((e, t) => /* @__PURE__ */ h(Ye, { place: e }, t))
		});
		case "perCardShieldCount": return /* @__PURE__ */ g(Z, { children: [e.count, "◇"] });
		case "perCardCost": return /* @__PURE__ */ g(Z, { children: [
			e.orGreater ? "≥" : "",
			e.cost,
			/* @__PURE__ */ h(Y, {})
		] });
		case "perCardDiscount": return /* @__PURE__ */ g(Z, { children: ["−", /* @__PURE__ */ h(Y, {})] });
		case "ifFaceDown": return /* @__PURE__ */ h(Z, { children: /* @__PURE__ */ h(Ye, { place: "village" }) });
		case "perCardPurse": return /* @__PURE__ */ h(Z, { children: /* @__PURE__ */ h(qe, {}) });
		case "perPurseGold": return /* @__PURE__ */ h(qe, {});
		case "perAllPurseGold": return /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(qe, {}), /* @__PURE__ */ h(Y, {})] });
		case "perCard": return /* @__PURE__ */ h(Z, {});
		case "perEmpty": return /* @__PURE__ */ h("span", { className: "cc-small-card cc-empty-mark" });
		case "bestNeighbor": return /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("span", { children: "↔" }), /* @__PURE__ */ h(Ze, { cond: e.cond })] });
	}
}
var Qe = {
	castle: {
		bg: "#dbe5dd",
		band: "#557b77"
	},
	village: {
		bg: "#e5d2b1",
		band: "#a56f48"
	}
};
function $e(e, t, n) {
	let r = t === void 0 ? e === "mini" ? "var(--cc-tableau-w, 64px)" : e === "deck" ? "var(--cc-deck-w, 44px)" : "var(--cc-market-w, 84px)" : `${t}px`;
	return {
		"--cc-card-w": r,
		width: r,
		height: n === void 0 ? e === "mini" ? "var(--cc-tableau-h, 88px)" : "var(--cc-market-h, 116px)" : `${n}px`
	};
}
function et({ place: e, w: t, h: n, size: r = "md" }) {
	return /* @__PURE__ */ g("span", {
		className: "cc-card-back",
		"data-place": e,
		"data-size": r,
		style: $e(r, t, n),
		"aria-hidden": "true",
		children: [/* @__PURE__ */ h(je, { place: e }), r !== "deck" && /* @__PURE__ */ g("span", {
			className: "cc-back-resources",
			children: [
				/* @__PURE__ */ h(Y, { n: 6 }),
				/* @__PURE__ */ h(X, {}),
				/* @__PURE__ */ h("b", { children: "2" })
			]
		})]
	});
}
function tt({ id: e, size: t = "md", purseGold: n, w: r, h: i }) {
	let a = l(), o = O(e), s = T(o);
	return /* @__PURE__ */ g("span", {
		className: "cc-card",
		"data-card-size": t,
		"data-place": o.place,
		style: $e(t, r, i),
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ g("span", {
				className: "cc-card-band",
				children: [
					/* @__PURE__ */ h("span", {
						className: "cc-card-cost",
						children: /* @__PURE__ */ h(Y, { n: o.cost })
					}),
					o.messenger && /* @__PURE__ */ h(Je, {}),
					/* @__PURE__ */ h("span", {
						className: "cc-card-shields",
						children: o.shields.map((e, t) => /* @__PURE__ */ h(Ke, { shield: e }, t))
					})
				]
			}),
			/* @__PURE__ */ h(Ae, {
				id: e,
				className: "cc-card-portrait"
			}),
			/* @__PURE__ */ h("span", {
				className: "cc-card-title",
				children: a(E(e))
			}),
			t === "md" && /* @__PURE__ */ h("span", {
				className: "cc-card-effects",
				children: Be(a, o).map((e, t) => /* @__PURE__ */ h("span", { children: e }, t))
			}),
			/* @__PURE__ */ h("span", {
				className: "cc-card-scoring",
				title: He(a, o),
				children: s > 0 && t === "mini" ? /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h(qe, {}), /* @__PURE__ */ g("b", { children: [
					n ?? 0,
					"/",
					s
				] })] }) : /* @__PURE__ */ g(m, { children: [
					/* @__PURE__ */ h(Ze, { cond: o.scoring.cond }),
					/* @__PURE__ */ g("b", { children: [o.scoring.cond.type === "ifPosition" || o.scoring.cond.type === "ifFaceDown" || o.scoring.cond.type === "ifShieldMissing" ? "" : "×", o.scoring.score] }),
					s > 0 && /* @__PURE__ */ g("small", { children: ["/", s] })
				] })
			})
		]
	});
}
function nt({ cell: e }) {
	return e.faceDown ? /* @__PURE__ */ h(et, {
		place: O(e.card).place,
		size: "mini"
	}) : /* @__PURE__ */ h(tt, {
		id: e.card,
		size: "mini",
		purseGold: e.purseGold
	});
}
//#endregion
//#region src/games/castlecombo/view-player.tsx
function rt(e) {
	let t = e.public;
	return /* @__PURE__ */ h(it, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var Q = "#244b45";
function it({ pub: e, members: t, myRid: r, send: o }) {
	let _ = l(), v = c((e) => e.locale), y = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? p(n, v) : e;
	}, b = e.players.find((e) => e.rid === r), x = e.turn === r && e.phase !== "done", [ee, S] = a(null), te = i(null), [C, w] = a(null), [T, D] = a(null), [ne, k] = a(null), A = `${e.phase}|${e.turn}|${e.messenger}|${e.rivers.castle.join(".")}|${e.rivers.village.join(".")}`, [re, ie] = a(A);
	re !== A && (ie(A), w(null), D(null)), n(() => {
		T && te.current?.scrollIntoView({
			block: "nearest",
			behavior: "instant"
		});
	}, [T]);
	let j = T ? r : ne ?? r, ae = e.players.find((e) => e.rid === j), M = ae?.tableau.find((e) => e.card === ee?.card) ?? null, oe = b ? F(b.tableau) : [], N = e.current ? O(e.current) : null, P = e.phase === "choose" && N ? N.effects.find((e) => e.type === "choose") : null, I = e.phase === "discard" && N ? N.effects.find((e) => e.type === "discardRiver") : null, L, z;
	e.phase === "choose" ? (L = x ? "accent" : "info", z = x ? _("games.castlecombo.choosePrompt") : _("games.castlecombo.turnWait", { name: y(e.turn) })) : e.phase === "discard" && I && I.type === "discardRiver" ? (L = x ? "accent" : "info", z = x ? _("games.castlecombo.discardPrompt", { place: _(Fe[I.river]) }) : _("games.castlecombo.turnWait", { name: y(e.turn) })) : x ? (L = "accent", z = _(T ? "games.castlecombo.placePrompt" : "games.castlecombo.turnYou")) : (L = "info", z = _("games.castlecombo.turnWait", { name: y(e.turn) }));
	let se = C ? O(C) : null, B = C && b ? R(C, b.tableau) : 0, V = b !== void 0 && B <= b.gold, ce = x && e.phase === "main" && !!C && e.rivers[e.messenger].includes(C), H = T ? T.cardId : C ?? (M && !M.faceDown ? M.card : null), U = H ? O(H) : !M?.faceDown && x && (e.phase === "choose" || e.phase === "discard") ? N : null;
	return /* @__PURE__ */ h(u, {
		adaptive: !0,
		className: "cc-screen",
		scroll: !1,
		banner: /* @__PURE__ */ g("div", {
			className: "cc-banner",
			style: { "--cc-player-count": Math.max(1, t.length) },
			children: [
				/* @__PURE__ */ h("h1", {
					className: "cc-title",
					children: _("games.castlecombo.name")
				}),
				/* @__PURE__ */ h(d, {
					tone: L,
					text: z,
					accent: Q
				}),
				/* @__PURE__ */ h(f, {
					variant: "plate",
					members: t,
					myRid: r,
					anchorOf: (e) => `seat:${e}`,
					action: (t) => e.phase !== "done" && t === e.turn ? "pending" : null,
					status: (t) => {
						let n = e.players.find((e) => e.rid === t);
						return n ? /* @__PURE__ */ g("span", {
							className: "cc-resources flex items-center gap-1.5 text-xs leading-4.5 font-bold",
							children: [
								/* @__PURE__ */ g("span", {
									className: "flex items-center gap-0.5 font-mono text-sm tabular-nums",
									children: [
										/* @__PURE__ */ h(Y, {}),
										/* @__PURE__ */ h("span", {
											className: "sr-only",
											children: _("games.castlecombo.resultGold")
										}),
										/* @__PURE__ */ h(s, { value: n.gold })
									]
								}),
								/* @__PURE__ */ g("span", {
									className: "flex items-center gap-0.5 font-mono text-sm tabular-nums",
									children: [
										/* @__PURE__ */ h(X, {}),
										/* @__PURE__ */ h("span", {
											className: "sr-only",
											children: _("games.castlecombo.resultKeys")
										}),
										/* @__PURE__ */ h(s, { value: n.keys })
									]
								}),
								/* @__PURE__ */ g("span", {
									className: "flex items-center gap-0.5 font-mono text-sm tabular-nums",
									style: { color: Q },
									children: [
										/* @__PURE__ */ h(Ue, {}),
										/* @__PURE__ */ h("span", {
											className: "sr-only",
											children: _("games.castlecombo.resultTotal")
										}),
										/* @__PURE__ */ h(s, { value: n.score })
									]
								})
							]
						}) : null;
					}
				})
			]
		}),
		actionsHeight: "cc-actions-slot",
		actions: /* @__PURE__ */ g("div", {
			className: "cc-actions",
			children: [/* @__PURE__ */ g("div", {
				className: "cc-details",
				"aria-live": "polite",
				children: [H && !T?.faceDown && /* @__PURE__ */ h(Ae, {
					id: H,
					className: "cc-detail-art"
				}), /* @__PURE__ */ h("div", {
					className: "cc-detail-copy",
					children: T ? /* @__PURE__ */ h("strong", { children: T.faceDown ? _("games.castlecombo.flipDesc") : _("games.castlecombo.placeDesc", { name: _(E(T.cardId)) }) }) : U ? /* @__PURE__ */ g(m, { children: [
						/* @__PURE__ */ g("strong", { children: [_(E(U.id)), C && /* @__PURE__ */ g("span", {
							className: "cc-detail-price",
							children: [B < U.cost ? _("games.castlecombo.costOff", {
								cost: U.cost,
								n: B
							}) : _("games.castlecombo.cost", { n: B }), !V && /* @__PURE__ */ h("em", { children: _("games.castlecombo.cantAfford") })]
						})] }),
						Be(_, U).map((e, t) => /* @__PURE__ */ h("p", { children: e }, t)),
						/* @__PURE__ */ h("p", {
							className: "cc-detail-score",
							children: He(_, U)
						}),
						M && !C && !M.faceDown && U.scoring.cond.type === "perPurseGold" && /* @__PURE__ */ h("p", { children: _("games.castlecombo.resultPurse", {
							n: M.purseGold ?? 0,
							limit: U.scoring.cond.type === "perPurseGold" ? U.scoring.cond.limit : 0
						}) })
					] }) : M?.faceDown ? /* @__PURE__ */ h("strong", { children: _("games.castlecombo.resultFaceDown") }) : /* @__PURE__ */ h("span", { children: x ? _("games.castlecombo.hintPick") : z })
				})]
			}), /* @__PURE__ */ h("div", {
				className: "cc-buttons flex items-stretch gap-2",
				children: T ? /* @__PURE__ */ h("button", {
					type: "button",
					className: "btn-quiet min-w-24 px-3 text-sm",
					onClick: () => D(null),
					children: _("games.castlecombo.cancel")
				}) : ce && C && se ? /* @__PURE__ */ g(m, { children: [
					/* @__PURE__ */ h("button", {
						type: "button",
						className: "btn-quiet px-3 text-sm",
						onClick: () => w(null),
						children: _("games.castlecombo.cancel")
					}),
					/* @__PURE__ */ h("button", {
						type: "button",
						className: "btn-quiet flex-1 px-3 text-sm",
						onClick: () => D({
							cardId: C,
							faceDown: !0
						}),
						children: _("games.castlecombo.flip")
					}),
					/* @__PURE__ */ h("button", {
						type: "button",
						disabled: !V,
						className: "btn-base flex-1 px-4 text-sm text-white disabled:opacity-40",
						style: { background: Q },
						onClick: () => D({
							cardId: C,
							faceDown: !1
						}),
						children: _("games.castlecombo.buy")
					})
				] }) : x && e.phase === "choose" && P && P.type === "choose" ? [P.a, P.b].map((e, t) => /* @__PURE__ */ h("button", {
					type: "button",
					className: "btn-base flex-1 px-3 text-xs text-white",
					style: { background: Q },
					onClick: () => o({
						type: "choose",
						pick: t === 0 ? 1 : 2
					}),
					children: Be(_, {
						...N,
						effects: [e]
					})[0]
				}, t)) : /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ g("button", {
					type: "button",
					disabled: !x || e.phase !== "main" || !b || b.keys <= 0 || e.keySpent || e.gone === (e.messenger === "castle" ? "village" : "castle"),
					className: "btn-quiet flex-1 px-3 text-sm disabled:opacity-40",
					onClick: () => o({ type: "keyMove" }),
					children: [
						/* @__PURE__ */ h(X, {}),
						" 1 · ",
						_("games.castlecombo.keyMove")
					]
				}), /* @__PURE__ */ g("button", {
					type: "button",
					disabled: !x || e.phase !== "main" || !b || b.keys <= 0 || e.keySpent,
					className: "btn-quiet flex-1 px-3 text-sm disabled:opacity-40",
					onClick: () => o({ type: "keyRefresh" }),
					children: [
						/* @__PURE__ */ h(X, {}),
						" 1 · ",
						_("games.castlecombo.keyRefresh")
					]
				})] })
			})]
		}),
		children: /* @__PURE__ */ g("div", {
			className: "cc-table",
			children: [/* @__PURE__ */ h("div", {
				className: "cc-market",
				children: ["castle", "village"].map((t) => /* @__PURE__ */ h(at, {
					pub: e,
					place: t,
					active: e.messenger === t,
					gone: e.gone === t,
					discardTarget: I?.type === "discardRiver" && I.river === t && x,
					canPick: x && e.phase === "main" && e.messenger === t,
					selected: C,
					affordable: (e) => b !== void 0 && R(e, b.tableau) <= b.gold,
					onPick: (e) => {
						if (I?.type === "discardRiver" && I.river === t && x) {
							o({
								type: "discardPick",
								cardId: e
							});
							return;
						}
						S(null), D(null), w(C === e ? null : e);
					}
				}, t))
			}), /* @__PURE__ */ g("div", {
				className: "cc-tableau",
				ref: te,
				children: [/* @__PURE__ */ g("div", {
					className: "cc-tableau-heading",
					children: [/* @__PURE__ */ h("span", {
						className: "text-xs font-bold opacity-60",
						children: j === r ? _("games.castlecombo.myTableau") : _("games.castlecombo.theirTableau", { name: y(j) })
					}), e.players.length > 1 && e.players.map((e) => /* @__PURE__ */ h("button", {
						type: "button",
						"aria-pressed": e.rid === j,
						disabled: !!T,
						onClick: () => {
							k(e.rid === r ? null : e.rid), S(null), w(null);
						},
						className: `min-h-8 rounded-full border-2 px-2 text-xs font-bold ${e.rid === j ? "border-ink bg-surface" : "border-ink/25 opacity-60"}`,
						children: y(e.rid)
					}, e.rid))]
				}), /* @__PURE__ */ h(lt, {
					rid: j,
					onInspect: (e) => {
						S(e), w(null);
					},
					tableau: ae?.tableau ?? [],
					ghosts: T && b ? oe : [],
					onGhost: (e, t) => {
						T && (o({
							type: "buy",
							cardId: T.cardId,
							x: e,
							y: t,
							faceDown: T.faceDown || void 0
						}), k(null), D(null), w(null));
					}
				})]
			})]
		})
	});
}
function at({ pub: e, place: t, active: n, gone: r, discardTarget: i, canPick: a, selected: s, affordable: c, onPick: u }) {
	let d = l(), { ref: f } = o(`river:${t}`), { ref: p, hidden: m } = o(`messenger:${t}`), _ = e.rivers[t];
	return /* @__PURE__ */ g("div", {
		className: "cc-river",
		"data-place": t,
		"data-active": n,
		children: [
			/* @__PURE__ */ g("span", {
				className: `cc-river-label flex flex-none flex-col items-center leading-tight font-extrabold ${n ? "" : "opacity-45"}`,
				style: { color: Qe[t].band },
				children: [
					/* @__PURE__ */ h("span", {
						"aria-hidden": !0,
						className: "text-base",
						children: /* @__PURE__ */ h(je, { place: t })
					}),
					d(Fe[t]),
					/* @__PURE__ */ h("span", {
						ref: p,
						className: "cc-messenger",
						style: { visibility: n && !m ? "visible" : "hidden" },
						children: /* @__PURE__ */ h(Me, {})
					})
				]
			}),
			/* @__PURE__ */ h(ct, {
				place: t,
				count: e.deckCounts[t],
				gone: r
			}),
			/* @__PURE__ */ g("div", {
				ref: f,
				className: `cc-river-slots ${!n && !i ? "cc-inactive-river" : ""}`,
				children: [[
					0,
					1,
					2
				].map((e) => {
					let n = _[e];
					return /* @__PURE__ */ h(ot, {
						place: t,
						slot: e,
						children: n && /* @__PURE__ */ h(st, {
							id: n,
							active: s === n,
							highlight: a && c(n) || i,
							onPick: () => u(n)
						})
					}, e);
				}), r && /* @__PURE__ */ h("span", {
					className: "cc-gone text-xs font-bold opacity-50",
					children: d("games.castlecombo.goneLabel")
				})]
			})
		]
	});
}
function ot({ place: e, slot: t, children: n }) {
	let { ref: r } = o(`river-slot:${e}:${t}`);
	return /* @__PURE__ */ h("div", {
		ref: r,
		className: "cc-market-slot",
		children: n
	});
}
function st({ id: e, active: t, highlight: n, onPick: r }) {
	let i = l(), { ref: a } = o(`mcard:${e}`);
	return /* @__PURE__ */ h("button", {
		ref: a,
		type: "button",
		"aria-label": `${i(E(e))}. ${Be(i, O(e)).join(". ")}. ${He(i, O(e))}`,
		"aria-pressed": t,
		onClick: r,
		className: `cc-market-button flex flex-none rounded-xl outline-2 outline-offset-2 transition-transform active:translate-y-0.5 ${t ? "-translate-y-1 shadow-[3px_3px_0_var(--color-ink)] outline-solid" : n ? "outline-dashed" : "outline-transparent"}`,
		style: { outlineColor: t || n ? Q : void 0 },
		children: /* @__PURE__ */ h(tt, { id: e })
	});
}
function ct({ place: e, count: t, gone: n }) {
	let r = l(), { ref: i } = o(`deck:${e}`);
	return /* @__PURE__ */ h("div", {
		ref: i,
		className: "relative flex-none",
		children: t === 0 ? /* @__PURE__ */ h("span", {
			className: "inline-flex items-center justify-center rounded-xl border-2 border-dashed border-ink/25 text-xs font-bold opacity-50",
			style: {
				width: "var(--cc-deck-w, 44px)",
				height: "var(--cc-market-h, 116px)"
			},
			children: n ? "✕" : 0
		}) : /* @__PURE__ */ g("span", {
			className: "relative inline-flex",
			"aria-label": r("games.castlecombo.deckAria", {
				place: r(Fe[e]),
				n: t
			}),
			role: "img",
			children: [/* @__PURE__ */ h(et, {
				place: e,
				size: "deck"
			}), /* @__PURE__ */ h("span", {
				className: "cc-deck-count absolute -top-1.5 -right-1.5 grid size-5 place-items-center rounded-full border-2 border-ink bg-surface font-mono text-[10px] font-extrabold tabular-nums",
				children: t
			})]
		})
	});
}
function lt({ rid: e, tableau: t, ghosts: n, onGhost: r, onInspect: i }) {
	let a = l(), o = [...t.map((e) => ({
		x: e.x,
		y: e.y
	})), ...n], s = o.length ? Math.min(...o.map((e) => e.x)) : 0, c = o.length ? Math.min(...o.map((e) => e.y)) : 0, u = new Map(t.map((e) => [`${e.x},${e.y}`, e])), d = new Set(n.map((e) => `${e.x},${e.y}`));
	return /* @__PURE__ */ h("div", {
		className: "cc-tableau-grid flex flex-col gap-1",
		children: [
			0,
			1,
			2
		].map((t) => /* @__PURE__ */ h("div", {
			className: "flex gap-1",
			children: [
				0,
				1,
				2
			].map((n) => {
				let o = s + n, l = c + t, f = `${o},${l}`, p = u.get(f);
				return p ? /* @__PURE__ */ h(ut, {
					rid: e,
					cell: p,
					onInspect: () => i(p)
				}, p.card) : d.has(f) ? /* @__PURE__ */ h("button", {
					type: "button",
					"aria-label": a("games.castlecombo.placePrompt"),
					onClick: () => r(o, l),
					className: "cc-ghost",
					style: {
						width: "var(--cc-tableau-w, 64px)",
						height: "var(--cc-tableau-h, 88px)",
						borderColor: Q
					},
					children: "+"
				}, f) : /* @__PURE__ */ h("span", {
					className: "cc-tableau-empty",
					style: {
						width: "var(--cc-tableau-w, 64px)",
						height: "var(--cc-tableau-h, 88px)"
					},
					"aria-hidden": !0
				}, f);
			})
		}, t))
	});
}
function ut({ rid: e, cell: t, onInspect: n }) {
	let r = l(), { ref: i, hidden: a } = o(`tableau:${e}:${t.card}`);
	return /* @__PURE__ */ h("button", {
		type: "button",
		ref: i,
		className: "cc-placed-button",
		style: { visibility: a ? "hidden" : void 0 },
		onClick: n,
		"aria-label": t.faceDown ? r("games.castlecombo.resultFaceDown") : r(E(t.card)),
		children: /* @__PURE__ */ h(nt, { cell: t })
	});
}
//#endregion
//#region src/games/castlecombo/bot.ts
function dt(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function ft(e) {
	let t = 0;
	for (let n of e) n.faceDown || (t += Math.max(0, T(O(n.card)) - (n.purseGold ?? 0)));
	return t;
}
function pt(e) {
	let t = e.tableau, n = ft(t), r = +!!t.some((e) => !e.faceDown && e.card === "Banker"), i = n > e.gold + 4 ? 2 + r : 0, a = e.gold >= 25 ? .15 : e.gold >= 15 ? .35 : e.gold >= 8 ? .8 : 1.2;
	return Math.max(i, a);
}
function mt(e) {
	let t = 1;
	for (let n of e.tableau) {
		if (n.faceDown) continue;
		let e = O(n.card);
		e.scoring.cond.type === "perKey" && (t += e.scoring.score);
	}
	return t;
}
function ht(e, t) {
	let n = e.players.findIndex((e) => e.rid === t), r = e.players.length;
	return [e.players[(n + 1) % r].tableau, e.players[(n - 1 + r) % r].tableau];
}
function gt(e, t, n) {
	return e.reduce((r, i, a) => r + H(e, t, n, a), 0);
}
function $(e, t, n, r, i, a, o) {
	let s = V(t, n.keys, i);
	switch (e.type) {
		case "discount": {
			let n = 9 - t.length;
			return ((e.castle ?? 0) + (e.village ?? 0)) * Math.min(n, 4) * .4 * a;
		}
		case "gainGold": {
			let t = e.cond ? B(e.cond, s) : 1;
			return (e.gain ?? 0) * t * a - (e.opponentsGain ?? 0) * t * .4 * (r.players.length - 1);
		}
		case "gainKeys": {
			let t = e.cond ? B(e.cond, s) : 1;
			return (e.gain ?? 0) * t * o - (e.opponentsGain ?? 0) * t * .4 * (r.players.length - 1);
		}
		case "putGold": {
			let n = t.filter((e) => !e.faceDown && T(O(e.card)) > (e.purseGold ?? 0)), r = +!!t.some((e) => !e.faceDown && e.card === "Banker"), i = 0;
			if (e.cardsLimit) {
				let t = [...n].sort((e, t) => T(O(t.card)) - (t.purseGold ?? 0) - (T(O(e.card)) - (e.purseGold ?? 0)));
				for (let n of t.slice(0, e.cardsLimit)) i += T(O(n.card)) - (n.purseGold ?? 0);
			} else for (let t of n) i += Math.min(e.gold ?? 0, T(O(t.card)) - (t.purseGold ?? 0));
			return i * (2 + r);
		}
		case "discardRiver": return r.rivers[e.river].reduce((e, t) => Math.max(e, O(t).cost), 0) * (e.token === "key" ? o : a);
		case "choose": return Math.max($(e.a, t, n, r, i, a, o), $(e.b, t, n, r, i, a, o));
	}
}
function _t(e, t, n, r, i, a, o, s) {
	let c = t.tableau, l = gt(c, t.keys, r), u = [...c, {
		card: e.id,
		x: i,
		y: a
	}], d = gt(u, t.keys, r) - l, f = e.effects.reduce((e, i) => e + $(i, u, t, n, r, o, s), 0), p = R(e.id, c), m = d + f - p * o, h = T(e);
	if (h > 0) {
		let e = +!!c.some((e) => !e.faceDown && e.card === "Banker"), n = Math.min(h, Math.max(0, t.gold - p));
		m += n * Math.max(0, 2 + e - o);
	}
	return m;
}
function vt(e, t, n, r, i, a, o) {
	let s = t.tableau, c = gt(s, t.keys, n), l = [...s, {
		card: e,
		x: r,
		y: i,
		faceDown: !0
	}];
	return 6 * a + 2 * o + (gt(l, t.keys, n) - c);
}
function yt(e, t, n, r, i, a) {
	let o = null, s = t.tableau, c = F(s);
	for (let l of e) {
		if (R(l, s) > t.gold) continue;
		let e = O(l);
		for (let s of c) {
			let c = _t(e, t, n, r, s.x, s.y, i, a);
			(!o || c > o.value) && (o = {
				cardId: l,
				x: s.x,
				y: s.y,
				value: c
			});
		}
	}
	return o;
}
function bt(e, t, n, r, i) {
	let a = null, o = F(t.tableau)[0];
	if (!o) return null;
	for (let s of e) {
		let e = O(s), c = e.scoring.score * 2 + e.cost * .5, l = vt(s, t, n, o.x, o.y, r, i) + c * .02;
		(!a || l > a.value) && (a = {
			cardId: s,
			x: o.x,
			y: o.y,
			value: l
		});
	}
	return a;
}
var xt = (e, t) => {
	let n = e.public;
	if (n.phase === "done" || n.turn !== t.rid) return null;
	let r = n.players.find((e) => e.rid === t.rid);
	if (!r) return null;
	let i = ht(n, t.rid), a = pt(r), o = mt(r), s = n.current ? O(n.current) : null;
	if (n.phase === "choose") {
		let e = s?.effects.find((e) => e.type === "choose");
		if (!e || e.type !== "choose") return null;
		if (t.difficulty === "weak") return { action: {
			type: "choose",
			pick: dt([1, 2])
		} };
		let c = r.tableau;
		return { action: {
			type: "choose",
			pick: $(e.a, c, r, n, i, a, o) >= $(e.b, c, r, n, i, a, o) ? 1 : 2
		} };
	}
	if (n.phase === "discard") {
		let e = s?.effects.find((e) => e.type === "discardRiver");
		if (!e || e.type !== "discardRiver") return null;
		let r = n.rivers[e.river];
		return r.length ? { action: {
			type: "discardPick",
			cardId: t.difficulty === "weak" ? dt(r) : [...r].sort((e, t) => O(t).cost - O(e).cost)[0]
		} } : null;
	}
	let c = F(r.tableau);
	if (!c.length) return null;
	let l = n.rivers[n.messenger], u = n.rivers[n.messenger === "castle" ? "village" : "castle"];
	if (t.difficulty === "weak") {
		let e = [];
		for (let t of l) for (let n of c) R(t, r.tableau) <= r.gold && e.push({
			type: "buy",
			cardId: t,
			x: n.x,
			y: n.y
		}), e.push({
			type: "buy",
			cardId: t,
			x: n.x,
			y: n.y,
			faceDown: !0
		});
		return r.keys > 0 && !n.keySpent && n.gone === null && e.push({ type: "keyMove" }, { type: "keyRefresh" }), e.length ? { action: dt(e) } : null;
	}
	let d = yt(l, r, n, i, a, o), f = bt(l, r, i, a, o);
	if (r.keys > 0 && !n.keySpent && n.gone === null) {
		let e = yt(u, r, n, i, a, o), t = Math.max(d?.value ?? -Infinity, f?.value ?? -Infinity);
		if (e && e.value - t > o + .5) return { action: { type: "keyMove" } };
		if (t < Math.min(6 * a + 2 * o, 3) && r.keys >= 2 && n.deckCounts[n.messenger] + n.discards[n.messenger].length > 0) return { action: { type: "keyRefresh" } };
	}
	return d && (!f || d.value >= f.value) ? { action: {
		type: "buy",
		cardId: d.cardId,
		x: d.x,
		y: d.y
	} } : f ? { action: {
		type: "buy",
		cardId: f.cardId,
		x: f.x,
		y: f.y,
		faceDown: !0
	} } : null;
}, St = (e, t, n) => {
	switch (e.type) {
		case "keyMove": return n("games.castlecombo.keyMove");
		case "keyRefresh": return n("games.castlecombo.keyRefresh");
		case "buy": return e.faceDown ? n("games.castlecombo.hintFlip", { name: n(E(e.cardId)) }) : n("games.castlecombo.hintBuy", { name: n(E(e.cardId)) });
		case "choose": return n("games.castlecombo.hintChoose", { n: e.pick });
		case "discardPick": return n("games.castlecombo.hintDiscard", { name: n(E(e.cardId)) });
	}
};
//#endregion
//#region src/games/castlecombo/fx.tsx
function Ct(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function wt(e, t, n) {
	return e.anchor(`river-slot:${t}:${n}`);
}
var Tt = {
	buy(e, t) {
		let n = e.data;
		if (typeof n?.cardId != "string" || typeof n.river != "string" || typeof n.slot != "number") return null;
		let r = `tableau:${e.rid}:${n.cardId}`, i = t.anchor(r), a = Ct(t, e.rid), o = i ?? a;
		if (!o) return null;
		if (t.queued > 0) return {
			ms: 180,
			node: /* @__PURE__ */ h(y, {
				at: o,
				ms: 180
			})
		};
		let s = wt(t, n.river, n.slot) ?? t.anchor(`mcard:${n.cardId}`);
		return s ? {
			ms: 480,
			hide: i ? [r] : void 0,
			node: /* @__PURE__ */ h(v, {
				from: s,
				to: o,
				ms: 420,
				children: n.faceDown === !0 ? /* @__PURE__ */ h(et, {
					place: O(n.cardId).place,
					w: s.w,
					h: s.h
				}) : /* @__PURE__ */ h(tt, {
					id: n.cardId,
					w: s.w,
					h: s.h
				})
			})
		} : null;
	},
	messenger(e, t) {
		let n = e.data;
		if (typeof n?.to != "string" || n.to !== "castle" && n.to !== "village") return null;
		let r = `messenger:${n.to}`, i = t.anchor(r), a = t.anchor(`messenger:${n.to === "castle" ? "village" : "castle"}`);
		return i ? !a || t.queued > 0 ? {
			ms: 240,
			node: /* @__PURE__ */ h(y, {
				at: i,
				ms: 240
			})
		} : {
			ms: 700,
			hide: [r],
			node: [/* @__PURE__ */ h(y, {
				at: i,
				ms: 500
			}, "pulse"), /* @__PURE__ */ h(v, {
				from: a,
				to: i,
				ms: 580,
				children: /* @__PURE__ */ h(Me, {})
			}, "pawn")]
		} : null;
	},
	refresh(e, t) {
		let n = e.data;
		if (typeof n?.river != "string") return null;
		let r = t.anchor(`river:${n.river}`);
		return r ? {
			ms: 600,
			node: [/* @__PURE__ */ h(y, {
				at: r,
				ms: 450
			}, "pulse"), /* @__PURE__ */ h(_, {
				at: r,
				ms: 600,
				children: /* @__PURE__ */ h(X, {})
			}, "txt")]
		} : null;
	},
	discardPick(e, t) {
		let n = e.data;
		if (typeof n?.cardId != "string" || typeof n.river != "string" || typeof n.amount != "number") return null;
		let r = Ct(t, e.rid), i = t.anchor(`river:${n.river}`);
		return !r || !i ? null : {
			ms: 800,
			node: /* @__PURE__ */ g(_, {
				at: r,
				ms: 800,
				children: [
					"+",
					n.amount,
					n.token === "key" ? /* @__PURE__ */ h(X, {}) : /* @__PURE__ */ h(Y, {})
				]
			}, "gain")
		};
	}
}, Et = new Set(D.map((e) => e.id));
function Dt(e) {
	return e.length > 9 || e.some((e) => !Et.has(e.card)) || new Set(e.map((e) => `${e.x},${e.y}`)).size !== e.length ? !1 : !e.length || Math.max(...e.map((e) => e.x)) - Math.min(...e.map((e) => e.x)) < 3 && Math.max(...e.map((e) => e.y)) - Math.min(...e.map((e) => e.y)) < 3;
}
function Ot(e, t) {
	let n = e.players.findIndex((e) => e.rid === t), r = e.players.length;
	return [e.players[(n + 1) % r].tableau, e.players[(n - 1 + r) % r].tableau];
}
function kt(e, t, n) {
	return e.scores?.[n] ?? t.players.find((e) => e.rid === n).score;
}
function At(e, t) {
	let n = e.players.find((e) => e.rid === t);
	return n.tableau.reduce((r, i, a) => r + H(n.tableau, n.keys, Ot(e, t), a), 0);
}
function jt({ pub: e, rid: t, name: n, result: r }) {
	let i = l(), [o, s] = a(null), c = e.players.find((e) => e.rid === t), u = c.tableau, d = Ot(e, t), f = u.length ? Math.min(...u.map((e) => e.x)) : 0, p = u.length ? Math.min(...u.map((e) => e.y)) : 0, m = new Map(u.map((e, t) => [`${e.x},${e.y}`, {
		cell: e,
		score: H(u, c.keys, d, t)
	}])), _ = Array.from({ length: 9 }, (e, t) => m.get(`${f + t % 3},${p + Math.floor(t / 3)}`)), v = (e) => e.faceDown ? i("games.castlecombo.resultFaceDown") : i(E(e.card)), y = u.find((e) => e.card === o), b = y && !y.faceDown ? O(y.card) : null;
	return /* @__PURE__ */ g("section", {
		className: "cc-over-realm",
		"aria-label": i("games.castlecombo.theirTableau", { name: n }),
		children: [/* @__PURE__ */ g("header", {
			className: "cc-over-realm-header",
			children: [/* @__PURE__ */ h("h2", { children: i("games.castlecombo.theirTableau", { name: n }) }), /* @__PURE__ */ g("strong", { children: [/* @__PURE__ */ h(Ue, {}), kt(r, e, t)] })]
		}), /* @__PURE__ */ g("div", {
			className: "cc-over-realm-body",
			children: [/* @__PURE__ */ h("ol", {
				className: "cc-over-board",
				children: _.map((e, t) => e ? /* @__PURE__ */ h("li", {
					className: "cc-over-cell",
					children: /* @__PURE__ */ g("button", {
						type: "button",
						"aria-label": i("games.castlecombo.resultCardScore", {
							name: v(e.cell),
							n: e.score
						}),
						"aria-pressed": o === e.cell.card,
						onClick: () => s(e.cell.card),
						children: [/* @__PURE__ */ h(nt, { cell: e.cell }), /* @__PURE__ */ h("strong", {
							className: "cc-over-card-score",
							children: e.score
						})]
					})
				}, `${e.cell.x},${e.cell.y}`) : /* @__PURE__ */ h("li", {
					className: "cc-over-empty",
					"aria-hidden": "true"
				}, `empty:${t}`))
			}), /* @__PURE__ */ g("section", {
				className: "cc-over-ledger",
				children: [
					/* @__PURE__ */ h("h3", { children: i("games.castlecombo.resultBreakdown") }),
					y && /* @__PURE__ */ g("div", {
						className: "cc-over-inspected",
						children: [/* @__PURE__ */ h("strong", { children: v(y) }), b && Be(i, b).map((e, t) => /* @__PURE__ */ h("p", { children: e }, t))]
					}),
					/* @__PURE__ */ h("ol", { children: _.map((e, t) => {
						if (!e) return /* @__PURE__ */ h("li", { hidden: !0 }, `empty:${t}`);
						let n = e.cell.faceDown ? null : O(e.cell.card), r = n ? T(n) : 0;
						return /* @__PURE__ */ g("li", {
							"data-selected": e.cell.card === o,
							children: [
								/* @__PURE__ */ g("div", { children: [/* @__PURE__ */ g("strong", { children: [
									t + 1,
									". ",
									v(e.cell)
								] }), /* @__PURE__ */ h("b", { children: e.score })] }),
								n && /* @__PURE__ */ h("p", { children: He(i, n) }),
								r > 0 && /* @__PURE__ */ g("p", { children: [/* @__PURE__ */ h("span", {
									"aria-hidden": "true",
									children: /* @__PURE__ */ h(Y, {})
								}), i("games.castlecombo.resultPurse", {
									n: e.cell.purseGold ?? 0,
									limit: r
								})] })
							]
						}, e.cell.card);
					}) }),
					/* @__PURE__ */ g("p", {
						className: "cc-over-tie",
						children: [
							i("games.castlecombo.resultRemainingGold"),
							": ",
							c.gold
						]
					})
				]
			})]
		})]
	});
}
function Mt(e) {
	let t = j.safeParse(e.public), n = /* @__PURE__ */ h(C, {
		...e,
		accent: k.accent
	});
	if (!t.success) return n;
	let r = t.data, i = new Set(r.players.map((e) => e.rid));
	return r.phase !== "done" || r.players.length < 2 || r.players.length > 5 || i.size !== r.players.length || e.result.ranking.length !== r.players.length || new Set(e.result.ranking).size !== e.result.ranking.length || e.result.ranking.some((e) => !i.has(e)) || e.result.winner.some((e) => !i.has(e)) || r.players.some((e) => !Dt(e.tableau)) ? n : /* @__PURE__ */ h(Nt, {
		...e,
		pub: r
	});
}
function Nt({ result: e, pub: t, members: o, myRid: s, hintCount: u, onPlayAgain: d, onBackToLobby: f }) {
	let _ = l(), v = c((e) => e.locale), [y, C] = a(e.winner[0] ?? e.ranking[0]), [w, T] = a(!0), E = i(null), D = i(null), ne = r(), O = t.players.some((e) => e.rid === y) ? y : e.ranking[0], k = d ?? f, A = (e) => {
		let t = o.find((t) => t.rid === e);
		return t ? p(t, v) : e;
	};
	n(() => {
		w ? E.current?.focus() : D.current?.focus();
	}, [w]);
	let re = (e) => {
		if (e.key === "Escape") {
			e.stopPropagation(), T(!1);
			return;
		}
		if (e.key !== "Tab") return;
		let t = [...e.currentTarget.querySelectorAll("button:not([disabled]), summary, [tabindex=\"0\"]")].filter((e) => e.getClientRects().length > 0), n = t[0], r = t.at(-1);
		e.shiftKey && document.activeElement === n ? (e.preventDefault(), r?.focus()) : !e.shiftKey && document.activeElement === r && (e.preventDefault(), n?.focus());
	}, ie = (t, n) => {
		let r = o.find((e) => e.rid === t), i = e.winner.includes(t), a = e.autopilot?.[t] ?? 0;
		return /* @__PURE__ */ g("button", {
			type: "button",
			className: "cc-over-player",
			"data-won": i,
			"aria-pressed": O === t,
			onClick: () => C(t),
			title: A(t),
			children: [
				/* @__PURE__ */ g("span", {
					className: "cc-over-avatar",
					style: { backgroundColor: S[(r?.colorIndex ?? 0) % S.length].hex },
					children: [r && /* @__PURE__ */ h("img", {
						src: b[r.avatar % b.length],
						alt: "",
						draggable: !1
					}), /* @__PURE__ */ h("span", {
						className: "cc-over-place",
						children: i ? "🏆" : n
					})]
				}),
				/* @__PURE__ */ g("strong", { children: [A(t), t === s && /* @__PURE__ */ h("small", { children: _("lobby.you") })] }),
				a > 0 && /* @__PURE__ */ h("small", { children: _("session.autopilot.share", { n: Math.round(a * 100) }) })
			]
		});
	}, j = /* @__PURE__ */ h(m, { children: t.players.map((n) => /* @__PURE__ */ h("div", {
		className: "cc-over-realm-pane",
		hidden: O !== n.rid,
		children: /* @__PURE__ */ h(jt, {
			pub: t,
			rid: n.rid,
			name: A(n.rid),
			result: e
		})
	}, n.rid)) });
	return /* @__PURE__ */ g("div", {
		className: "cc-over",
		style: { "--cc-result-players": t.players.length },
		children: [
			e.winner.length > 0 && /* @__PURE__ */ h(te, {}),
			/* @__PURE__ */ g("div", {
				className: "cc-over-review",
				inert: w,
				"aria-hidden": w || void 0,
				children: [
					/* @__PURE__ */ h("header", { children: /* @__PURE__ */ h("h1", { children: _("games.castlecombo.resultReview") }) }),
					/* @__PURE__ */ h("nav", {
						className: "cc-over-review-players",
						"aria-label": _("games.castlecombo.resultRealms"),
						children: e.ranking.map((e, t) => /* @__PURE__ */ h("div", { children: ie(e, t + 1) }, e))
					}),
					/* @__PURE__ */ h("div", {
						className: "cc-over-review-scene",
						children: j
					}),
					/* @__PURE__ */ g("button", {
						ref: D,
						type: "button",
						className: "cc-over-restore",
						onClick: () => T(!0),
						children: [/* @__PURE__ */ h(Ue, {}), _("games.castlecombo.resultOpen")]
					})
				]
			}),
			/* @__PURE__ */ g("div", {
				className: "cc-celebration",
				hidden: !w,
				role: "dialog",
				"aria-modal": "true",
				"aria-labelledby": ne,
				onKeyDown: re,
				children: [
					/* @__PURE__ */ g("header", {
						className: "cc-over-heading",
						children: [
							/* @__PURE__ */ h(Ue, {}),
							/* @__PURE__ */ h("h1", {
								id: ne,
								children: _("games.castlecombo.resultCelebration")
							}),
							/* @__PURE__ */ h("button", {
								type: "button",
								ref: E,
								className: "cc-over-close",
								onClick: () => T(!1),
								"aria-label": _("games.castlecombo.resultReview"),
								children: /* @__PURE__ */ h(ee, { size: 24 })
							})
						]
					}),
					/* @__PURE__ */ g("div", {
						className: "cc-over-content",
						children: [
							/* @__PURE__ */ h("div", {
								className: "cc-over-table-scroll",
								tabIndex: 0,
								role: "region",
								"aria-label": _("games.castlecombo.resultComparison"),
								children: /* @__PURE__ */ g("table", {
									className: "cc-over-comparison",
									children: [/* @__PURE__ */ h("thead", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
										scope: "col",
										children: /* @__PURE__ */ h("span", { children: _("games.castlecombo.resultComparison") })
									}), e.ranking.map((e, t) => /* @__PURE__ */ h("th", {
										scope: "col",
										children: ie(e, t + 1)
									}, e))] }) }), /* @__PURE__ */ g("tbody", { children: [
										/* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
											scope: "row",
											children: _("games.castlecombo.resultCards")
										}), e.ranking.map((e) => /* @__PURE__ */ h("td", { children: At(t, e) }, e))] }),
										/* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ g("th", {
											scope: "row",
											children: [/* @__PURE__ */ h(X, {}), _("games.castlecombo.resultKeys")]
										}), e.ranking.map((e) => /* @__PURE__ */ h("td", { children: t.players.find((t) => t.rid === e).keys }, e))] }),
										/* @__PURE__ */ g("tr", {
											className: "cc-over-total",
											children: [/* @__PURE__ */ h("th", {
												scope: "row",
												children: _("games.castlecombo.resultTotal")
											}), e.ranking.map((n) => /* @__PURE__ */ h("td", {
												"data-won": e.winner.includes(n),
												children: kt(e, t, n)
											}, n))]
										})
									] })]
								})
							}),
							u !== void 0 && /* @__PURE__ */ h("p", {
								className: "cc-over-hints",
								children: _("session.hint.usedCount", { n: u })
							}),
							/* @__PURE__ */ h("div", {
								className: "cc-over-detail",
								children: j
							})
						]
					}),
					/* @__PURE__ */ h("footer", {
						className: "cc-over-controls",
						children: k ? /* @__PURE__ */ g(m, { children: [d && /* @__PURE__ */ h(x, {
							className: "cc-over-play",
							label: _("session.result.playAgain"),
							confirmLabel: _("games.castlecombo.resultReplayConfirm"),
							onConfirm: d
						}), f && /* @__PURE__ */ h(x, {
							label: _("session.result.backToLobby"),
							confirmLabel: _("games.castlecombo.resultLobbyConfirm"),
							onConfirm: f
						})] }) : /* @__PURE__ */ h("p", { children: _("session.result.waitHost") })
					})
				]
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/castlecombo/entry.tsx
var Pt = {
	definition: be,
	View: rt,
	bot: xt,
	describe: St,
	fx: Tt,
	OverView: Mt,
	locales: {
		zh: {
			name: "城堡嘉年华",
			desc: "跟使者逛市集买卡,拼出 3×3 王国:钱包存金、盾牌成套,九卡落定比分",
			rules: "目标:从使者所在的市集购买卡牌,拼出自己 3 行 3 列的王国,9张卡牌全部放置后总分最高者获胜。\n流程(你的回合):\n· 可先花 1 把钥匙(每回合至多一次):把使者移到另一市集,或弃置当前市集的全部正面朝上的卡牌，并补充新牌。\n· 然后从使者所在市集购买1张卡牌：支付金币，将该牌正面朝上放入版图,或免费将它背面朝上放置。\n· 将卡牌正面朝上放入版图时，须与已有卡牌正交相邻，整个王国不得超过3行3列；背面朝上放置时，立即获得6枚金币和2把钥匙。\n· 带 📯 的卡被正面朝上购买后，将使者移到另一市集。\n· 卡面能力立即结算:获得金币或钥匙、将金币存入钱包卡、弃置市集中的卡牌以换取资源等。\n计分:\n· 终局逐卡结算底部分数(盾牌、位置、旗帜、钥匙等条件)。\n· 将剩余金币自动存入钱包卡，直至钱包填满或金币用尽；钱包中的每枚金币获得2分，每把剩余钥匙获得1分。\n· 某市集牌堆与弃牌都耗尽时,该市集移出游戏。\n· 总分相同时，剩余金币较多的玩家获胜；若仍然相同，则共享胜利。",
			turnYou: "轮到你:买 1 张卡",
			hintPick: "选择使者所在市集中的一张角色牌",
			turnWait: "等 {{name}} 行动…",
			choosePrompt: "选择要发动的效果",
			discardPrompt: "从{{place}}市集选弃 1 张",
			placePrompt: "点虚线格放置",
			myTableau: "我的王国",
			theirTableau: "{{name}} 的王国",
			keyMove: "移动使者",
			keyRefresh: "刷新市集",
			goneLabel: "已售空",
			deckAria: "{{place}}牌堆,剩 {{n}} 张",
			cost: "🪙{{n}}",
			costOff: "🪙{{n}}(原 {{cost}})",
			cantAfford: "金币不够",
			cancel: "取消",
			buy: "购买",
			flip: "扣放",
			flipDesc: "扣放并获得 6🪙 与 2🗝️:点虚线格",
			placeDesc: "放置「{{name}}」:点虚线格",
			tieBreak: "同分决胜:余金 {{n}}",
			resultCards: "卡牌得分",
			resultKeys: "钥匙得分",
			resultGold: "金币",
			resultTotal: "总分",
			resultBreakdown: "逐卡计分",
			resultFaceDown: "扣放卡",
			resultPurse: "钱包：{{n}}／{{limit}}",
			resultCardScore: "{{name}}：{{n}} 分",
			resultCelebration: "王国庆典",
			resultReview: "回看王国",
			resultOpen: "查看结算",
			resultComparison: "得分对照",
			resultRealms: "选择王国",
			resultRemainingGold: "余金（同分决胜）",
			resultReplayConfirm: "确认再来一局",
			resultLobbyConfirm: "确认返回大厅",
			shield: {
				nobility: "贵族",
				faith: "信仰",
				scholarship: "学识",
				military: "军事",
				craftsmanship: "工艺",
				peasantry: "平民"
			},
			place: {
				castle: "城堡",
				village: "村庄"
			},
			cond: {
				per: "每{{what}}",
				shield: "{{shield}}盾牌",
				shieldLine: "本行{{shield}}盾牌",
				shieldColumn: "本列{{shield}}盾牌",
				shieldCross: "十字线上{{shield}}盾牌",
				different: "种不同盾牌",
				differentLine: "种本行不同盾牌",
				differentColumn: "种本列不同盾牌",
				missing: "种缺少的盾牌",
				ifMissing: "若没有{{shield}}",
				shieldSet: "套{{shields}}",
				identicalSet: "组{{count}}枚相同盾牌",
				key: "把钥匙",
				banner: "面{{place}}旗帜",
				bannerSet: "套{{places}}旗帜",
				shieldCount: "张{{count}}盾卡",
				cost: "张费用{{cost}}的卡",
				costOrMore: "张费用≥{{cost}}的卡",
				discount: "张折扣卡",
				ifFaceDown: "若有扣放卡",
				purseCard: "张钱包卡",
				purseGold: "枚本卡存金",
				allPurseGold: "枚钱包总存金",
				card: "张版图卡",
				empty: "个空格",
				ifPosition: "若在{{pos}}",
				bestNeighbor: "{{what}}(按邻座较优版图)"
			},
			pos: {
				topRow: "顶行",
				midRow: "中行",
				bottomRow: "底行",
				leftCol: "左列",
				midCol: "中列",
				rightCol: "右列",
				corners: "四角",
				edges: "边中"
			},
			eff: {
				discountCastle: "城堡卡费用 −{{n}}🪙",
				discountVillage: "村庄卡费用 −{{n}}🪙",
				discountBoth: "买卡费用 −{{n}}🪙",
				gainGold: "获得 {{n}}🪙",
				gainKeys: "获得 {{n}}🗝️",
				gainGoldPer: "{{what}}:获得 {{n}}🪙",
				gainKeysPer: "{{what}}:获得 {{n}}🗝️",
				withOpponents: "{{main}};其他玩家{{opp}}",
				opponentsGold: "获得 {{n}}🪙",
				opponentsKeys: "获得 {{n}}🗝️",
				putGoldEach: "每张钱包卡存 {{n}}🪙",
				putGoldFill: "装满至多 {{n}} 张钱包卡",
				discardRiverGold: "从{{place}}市集弃 1 张卡,获得等同于其费用的🪙",
				discardRiverKey: "从{{place}}市集弃 1 张卡,获得等同于其费用的🗝️",
				choose: "二选一:{{a}};或 {{b}}"
			},
			score: {
				per: "{{what}}:+{{n}} 分",
				purse: "每枚本卡存金 +{{n}} 分(容量 {{limit}})"
			},
			errNotYourTurn: "现在轮不到你",
			errBadPhase: "现在不能这么做",
			errBadCard: "这张卡不在市集里",
			errBadPos: "这里放不下",
			errCantAfford: "金币不够",
			errNoKey: "没有可用的钥匙",
			card: {
				steward: "管家",
				scribe: "抄写员",
				mothersuperior: "修道院院长",
				hisholiness: "教皇",
				chaplain: "随行牧师",
				cardinal: "红衣主教",
				templar: "圣殿骑士",
				gravedigger: "掘墓人",
				alchemist: "炼金术士",
				astronomer: "天文学家",
				pilgrim: "朝圣者",
				devout: "虔信者",
				nun: "修女",
				architect: "建筑师",
				goldsmith: "金匠",
				apothecary: "药剂师",
				professor: "教授",
				officer: "军官",
				captain: "卫队长",
				judge: "法官",
				patron: "赞助人",
				guildmaster: "行会会长",
				general: "将军",
				knight: "骑士",
				lookout: "瞭望手",
				royalguard: "皇家卫兵",
				banker: "银行家",
				pawnbroker: "典当商",
				chatelaine: "女城主",
				glassblower: "玻璃匠",
				princess: "公主",
				prince: "王子",
				hismajesty: "国王陛下",
				queenmother: "王太后",
				jester: "宫廷弄臣",
				chancellor: "宰相",
				baron: "男爵",
				hermajestythequeen: "王后陛下",
				duchess: "公爵夫人",
				inventor: "发明家",
				spy: "间谍",
				vicar: "代牧",
				miraculouslycured: "奇迹痊愈者",
				squire: "侍从",
				philosopher: "哲学家",
				doctor: "医生",
				executioner: "刽子手",
				barbarian: "蛮族战士",
				militiaman: "民兵",
				bombardier: "投弹兵",
				stonemason: "石匠",
				blacksmith: "铁匠",
				masteratarms: "武器教头",
				mercenary: "雇佣兵",
				innkeeper: "旅店老板",
				sculptor: "雕塑家",
				clockmaker: "钟表匠",
				spicemerchant: "香料商",
				armorer: "盔甲匠",
				potter: "陶工",
				farmer: "农夫",
				locksmith: "锁匠",
				carpenter: "木匠",
				witch: "女巫",
				brigand: "强盗",
				woodcutter: "樵夫",
				monk: "僧侣",
				beggar: "乞丐",
				stableboy: "马厩小厮",
				winemaker: "酿酒师",
				shepherd: "牧羊人",
				usurper: "篡位者",
				traveler: "旅人",
				farmhand: "农场短工",
				revolutionary: "革命者",
				fisherman: "渔夫",
				baker: "面包师",
				beekeeper: "养蜂人"
			},
			hintBuy: "买下 {{name}}",
			hintFlip: "扣放 {{name}},获得 6🪙 与 2🗝️",
			hintChoose: "选第 {{n}} 项效果",
			hintDiscard: "弃掉 {{name}}"
		},
		en: {
			name: "Castle Combo",
			desc: "Shop the messenger's market and build a 3×3 realm: purses, shield sets, clever placements",
			rules: "Goal: buy cards from the market the messenger stands at, build your 3×3 realm, and have the most points once everyone has 9 cards.\nOn your turn:\n· You may spend 1 key first (once per turn): move the messenger to the other market, or discard its 3 face-up cards and refill.\n· Then buy 1 card from the messenger's market: pay gold to place it face-up, or place it face-down for free.\n· A face-up card must be orthogonally adjacent within 3 rows by 3 columns; a face-down card gains you 6 gold and 2 keys.\n· Cards with 📯 move the messenger to the other market when bought face-up.\n· Abilities resolve immediately: gain gold/keys, store gold on purse cards, discard from a river for its cost, etc.\nScoring:\n· At the end, each card scores its bottom-line condition (shields, positions, banners, keys…).\n· Automatically put leftover gold into purse cards until the purses are full or no gold remains. Each stored gold scores 2 points, and each unused key scores 1 point.\n· A market whose deck and discards are both exhausted leaves the game.\n· Ties break on leftover gold, then the win is shared.",
			turnYou: "Your turn: buy 1 card",
			hintPick: "Choose a character from the messenger's market",
			turnWait: "Waiting for {{name}}…",
			choosePrompt: "Choose an effect",
			discardPrompt: "Discard 1 from the {{place}} market",
			placePrompt: "Tap a dashed space to place",
			myTableau: "My realm",
			theirTableau: "{{name}}'s realm",
			keyMove: "Move messenger",
			keyRefresh: "Refresh market",
			goneLabel: "Sold out",
			deckAria: "{{place}} deck, {{n}} left",
			cost: "🪙{{n}}",
			costOff: "🪙{{n}} (was {{cost}})",
			cantAfford: "Need more gold",
			cancel: "Cancel",
			buy: "Buy",
			flip: "Flip",
			flipDesc: "Face-down: gain 6🪙 and 2🗝️, tap a dashed space",
			placeDesc: "Place \"{{name}}\": tap a dashed space",
			tieBreak: "Tie-break: {{n}} gold left",
			resultCards: "Card points",
			resultKeys: "Key points",
			resultGold: "Gold",
			resultTotal: "Total",
			resultBreakdown: "Card scoring",
			resultFaceDown: "Face-down card",
			resultPurse: "Purse: {{n}}/{{limit}}",
			resultCardScore: "{{name}}: {{n}} points",
			resultCelebration: "Kingdom celebration",
			resultReview: "Review realms",
			resultOpen: "View results",
			resultComparison: "Score comparison",
			resultRealms: "Choose a realm",
			resultRemainingGold: "Gold left (tie-break)",
			resultReplayConfirm: "Confirm new game",
			resultLobbyConfirm: "Confirm return to lobby",
			shield: {
				nobility: "Nobility",
				faith: "Faith",
				scholarship: "Scholarship",
				military: "Military",
				craftsmanship: "Crafts",
				peasantry: "Peasantry"
			},
			place: {
				castle: "Castle",
				village: "Village"
			},
			cond: {
				per: "per {{what}}",
				shield: "{{shield}} shield",
				shieldLine: "{{shield}} shield in row",
				shieldColumn: "{{shield}} shield in column",
				shieldCross: "{{shield}} in row+column",
				different: "distinct shield",
				differentLine: "distinct shield in row",
				differentColumn: "distinct shield in column",
				missing: "missing shield",
				ifMissing: "if no {{shield}}",
				shieldSet: "{{shields}} set",
				identicalSet: "set of {{count}} identical",
				key: "key",
				banner: "{{place}} banner",
				bannerSet: "{{places}} banner set",
				shieldCount: "card with {{count}} shields",
				cost: "card costing {{cost}}",
				costOrMore: "card costing {{cost}}+",
				discount: "discount card",
				ifFaceDown: "if a face-down card",
				purseCard: "purse card",
				purseGold: "gold in this purse",
				allPurseGold: "gold in all purses",
				card: "tableau card",
				empty: "empty space",
				ifPosition: "if on {{pos}}",
				bestNeighbor: "{{what}} (better neighbor)"
			},
			pos: {
				topRow: "the top row",
				midRow: "the middle row",
				bottomRow: "the bottom row",
				leftCol: "the left column",
				midCol: "the middle column",
				rightCol: "the right column",
				corners: "a corner",
				edges: "an edge midpoint"
			},
			eff: {
				discountCastle: "Castle cards cost −{{n}}🪙",
				discountVillage: "Village cards cost −{{n}}🪙",
				discountBoth: "Cards cost −{{n}}🪙",
				gainGold: "gain {{n}}🪙",
				gainKeys: "gain {{n}}🗝️",
				gainGoldPer: "{{what}}: gain {{n}}🪙",
				gainKeysPer: "{{what}}: gain {{n}}🗝️",
				withOpponents: "{{main}}; others {{opp}}",
				opponentsGold: "gain {{n}}🪙",
				opponentsKeys: "gain {{n}}🗝️",
				putGoldEach: "store {{n}}🪙 on each purse",
				putGoldFill: "fill up to {{n}} purses",
				discardRiverGold: "discard 1 from {{place}}, gain 🪙 equal to its cost",
				discardRiverKey: "discard 1 from {{place}}, gain 🗝️ equal to its cost",
				choose: "choose: {{a}} or {{b}}"
			},
			score: {
				per: "+{{n}} {{what}}",
				purse: "+{{n}} per gold in purse (cap {{limit}})"
			},
			errNotYourTurn: "Not your turn",
			errBadPhase: "Not allowed right now",
			errBadCard: "That card is not in the market",
			errBadPos: "Can't place it there",
			errCantAfford: "Not enough gold",
			errNoKey: "No key to spend",
			card: {
				steward: "Steward",
				scribe: "Scribe",
				mothersuperior: "Mother Superior",
				hisholiness: "His Holiness",
				chaplain: "Chaplain",
				cardinal: "Cardinal",
				templar: "Templar",
				gravedigger: "Gravedigger",
				alchemist: "Alchemist",
				astronomer: "Astronomer",
				pilgrim: "Pilgrim",
				devout: "Devout",
				nun: "Nun",
				architect: "Architect",
				goldsmith: "Goldsmith",
				apothecary: "Apothecary",
				professor: "Professor",
				officer: "Officer",
				captain: "Captain",
				judge: "Judge",
				patron: "Patron",
				guildmaster: "Guildmaster",
				general: "General",
				knight: "Knight",
				lookout: "Lookout",
				royalguard: "Royal Guard",
				banker: "Banker",
				pawnbroker: "Pawnbroker",
				chatelaine: "Chatelaine",
				glassblower: "Glassblower",
				princess: "Princess",
				prince: "Prince",
				hismajesty: "His Majesty",
				queenmother: "Queen Mother",
				jester: "Jester",
				chancellor: "Chancellor",
				baron: "Baron",
				hermajestythequeen: "Her Majesty the Queen",
				duchess: "Duchess",
				inventor: "Inventor",
				spy: "Spy",
				vicar: "Vicar",
				miraculouslycured: "Miraculously Cured",
				squire: "Squire",
				philosopher: "Philosopher",
				doctor: "Doctor",
				executioner: "Executioner",
				barbarian: "Barbarian",
				militiaman: "Militiaman",
				bombardier: "Bombardier",
				stonemason: "Stonemason",
				blacksmith: "Blacksmith",
				masteratarms: "Master-at-Arms",
				mercenary: "Mercenary",
				innkeeper: "Innkeeper",
				sculptor: "Sculptor",
				clockmaker: "Clockmaker",
				spicemerchant: "Spice Merchant",
				armorer: "Armorer",
				potter: "Potter",
				farmer: "Farmer",
				locksmith: "Locksmith",
				carpenter: "Carpenter",
				witch: "Witch",
				brigand: "Brigand",
				woodcutter: "Woodcutter",
				monk: "Monk",
				beggar: "Beggar",
				stableboy: "Stable Boy",
				winemaker: "Winemaker",
				shepherd: "Shepherd",
				usurper: "Usurper",
				traveler: "Traveler",
				farmhand: "Farmhand",
				revolutionary: "Revolutionary",
				fisherman: "Fisherman",
				baker: "Baker",
				beekeeper: "Beekeeper"
			},
			hintBuy: "Buy {{name}}",
			hintFlip: "Place {{name}} face down, gaining 6 gold and 2 keys",
			hintChoose: "Pick effect {{n}}",
			hintDiscard: "Discard {{name}}"
		}
	}
};
//#endregion
export { Pt as default };
