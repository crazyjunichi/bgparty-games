import { randomIntAt as e } from "@bgparty/sdk/core";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { GameScreen as a } from "@bgparty/sdk/ui/game-screen";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { useWakeLock as c } from "@bgparty/sdk/use-wake-lock";
import { SheetFxProbe as l, SheetView as u } from "@bgparty/sdk/sheet-view";
import { usePrefersReducedMotion as d } from "@bgparty/sdk/fx/use-reduced-motion";
import { gameAssetUrl as f } from "@bgparty/sdk/assets";
import { useI18nSettings as p, useT as m } from "@bgparty/sdk/i18n";
import { Fragment as ee, jsx as h, jsxs as g } from "react/jsx-runtime";
import { Floater as _, FlySprite as v, PulseBox as y } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as b, OptionSection as te, OptionSwitch as ne } from "@bgparty/sdk/ui/game-options";
//#region src/games/risingsun/data.ts
var re = [
	"koi",
	"sun",
	"lotus",
	"turtle",
	"dragonfly",
	"fox",
	"bonsai",
	"moon"
], x = [
	5,
	1,
	2,
	4,
	7,
	3,
	0,
	6
], ie = [
	5,
	7,
	7,
	6,
	6,
	5,
	4,
	4
], S = [
	"#a5272f",
	"#a97532",
	"#8e558c",
	"#3d8060",
	"#4598a8",
	"#c66d2a",
	"#d6a72d",
	"#454d72"
], ae = [
	[2, 3],
	[3, 4],
	[4, 5],
	[4, 6],
	[5, 6]
], C = [
	[0, 1],
	[1, 3],
	[0, 3],
	[0, 7],
	[3, 7],
	[6, 7]
], oe = [
	[
		1,
		1,
		1
	],
	[
		3,
		0,
		0
	],
	[
		1,
		1,
		1
	],
	[
		0,
		0,
		3
	],
	[
		0,
		0,
		4
	],
	[
		2,
		0,
		2
	],
	[
		3,
		0,
		0
	],
	[
		0,
		2,
		0
	]
], w = (e, t, n, r, i, a, o = 1) => ({
	id: e,
	season: t,
	cost: n,
	copies: r,
	set: i,
	kind: a,
	force: o,
	oni: e.startsWith("oni"),
	lucky: i === "lucky"
}), T = [
	w("komainu", 0, 2, 1, "core", "monster"),
	w("oniSkulls", 0, 2, 1, "core", "monster"),
	w("lion", 0, 0, 1, "core", "enhancement"),
	w("righteousness", 0, 2, 2, "core", "virtue"),
	w("shogun", 0, 2, 2, "core", "war"),
	w("serpent", 1, 0, 1, "core", "enhancement"),
	w("respect", 1, 0, 2, "core", "virtue"),
	w("bushido", 1, 3, 1, "core", "war"),
	w("ronin", 1, 1, 2, "core", "war"),
	w("yurei", 1, 3, 1, "core", "monster", 2),
	w("kitsuneForm", 2, 4, 2, "core", "winter"),
	w("phoenixForm", 2, 3, 2, "core", "winter"),
	w("dragon", 2, 3, 1, "core", "enhancement"),
	w("riverDragon", 2, 3, 1, "core", "monster", 5),
	w("moneylender", 2, 0, 1, "core", "war"),
	w("benevolence", 0, 1, 2, "archway", "virtue"),
	w("kenin", 0, 2, 2, "archway", "enhancement"),
	w("light", 0, 0, 1, "archway", "enhancement"),
	w("justice", 1, 1, 2, "archway", "virtue"),
	w("oniBlood", 1, 3, 1, "archway", "monster", 2),
	w("oniSouls", 1, 2, 1, "archway", "monster"),
	w("samurai", 1, 2, 1, "archway", "enhancement"),
	w("beastForm", 2, 4, 2, "archway", "winter"),
	w("oniHate", 2, 3, 1, "archway", "monster"),
	w("oniSpite", 2, 3, 1, "archway", "monster"),
	w("katana", 2, 3, 1, "archway", "war"),
	w("honesty", 0, 0, 2, "kettle", "virtue"),
	w("patron", 0, 0, 1, "kettle", "enhancement"),
	w("warlord", 0, 1, 2, "kettle", "enhancement"),
	w("loyalty", 1, 1, 2, "kettle", "virtue"),
	w("merchant", 1, 2, 2, "kettle", "war"),
	w("kindredForm", 2, 3, 2, "kettle", "winter"),
	w("unrighteous", 2, 0, 2, "kettle", "enhancement"),
	w("courage", 0, 3, 2, "horseman", "virtue"),
	w("ninja", 0, 2, 1, "horseman", "enhancement"),
	w("righteous", 0, 2, 2, "horseman", "war"),
	w("mercy", 1, 1, 2, "horseman", "virtue"),
	w("monkey", 1, 0, 2, "horseman", "enhancement"),
	w("demonForm", 2, 3, 2, "horseman", "winter"),
	w("spirit", 2, 0, 1, "horseman", "enhancement"),
	w("dignity", 0, 1, 2, "boat", "virtue"),
	w("pacifist", 0, 0, 1, "boat", "enhancement"),
	w("salamander", 0, 0, 2, "boat", "enhancement"),
	w("patience", 1, 1, 2, "boat", "virtue"),
	w("ashigaru", 1, 2, 1, "boat", "war"),
	w("dragonForm", 2, 1, 2, "boat", "winter"),
	w("snake", 2, 3, 1, "boat", "war"),
	w("builder", 0, 0, 1, "mountain", "enhancement"),
	w("kannushi", 0, 2, 2, "mountain", "enhancement"),
	w("piety", 0, 1, 2, "mountain", "virtue"),
	w("sengoku", 1, 1, 1, "mountain", "enhancement"),
	w("favored", 1, 1, 1, "mountain", "enhancement"),
	w("sincerity", 1, 1, 2, "mountain", "virtue"),
	w("tanukiForm", 2, 2, 2, "mountain", "winter"),
	w("keiri", 2, 0, 1, "mountain", "war"),
	w("jinmenju", 0, 2, 1, "monster", "monster"),
	w("jorogumo", 0, 3, 1, "monster", "monster"),
	w("fireDragon", 1, 3, 1, "monster", "monster", 3),
	w("oniPlagues", 2, 1, 1, "monster", "monster"),
	w("earthDragon", 0, 3, 1, "daimyo", "monster", 3),
	w("kotahi", 0, 1, 1, "daimyo", "monster"),
	w("phoenix", 0, 1, 1, "daimyo", "monster"),
	w("jikininki", 1, 0, 1, "daimyo", "monster"),
	w("koneko", 1, 2, 1, "daimyo", "monster"),
	w("nureOnna", 1, 2, 1, "daimyo", "monster", 2),
	w("sunakake", 1, 1, 1, "daimyo", "monster"),
	w("daikaiju", 2, 5, 1, "daimyo", "monster", 5),
	w("kitsune", 2, 0, 1, "daimyo", "monster"),
	w("sacredWarrior", 2, 0, 1, "daimyo", "monster"),
	w("daikokuten", 0, 1, 1, "lucky", "monster"),
	w("fukurokuju", 0, 3, 1, "lucky", "monster"),
	w("jurojin", 0, 1, 1, "lucky", "monster"),
	w("bishamon", 1, 2, 1, "lucky", "monster"),
	w("hotei", 1, 2, 1, "lucky", "monster"),
	w("benten", 2, 2, 1, "lucky", "monster"),
	w("ebisu", 2, 0, 1, "lucky", "monster")
], E = Object.fromEntries(T.map((e) => [e.id, e]));
function se(e, t, n, r, i) {
	let a = e === "kettle" ? ["oniSouls", "oniHate"] : e === "horseman" ? [
		"oniBlood",
		"oniHate",
		"oniSpite"
	] : e === "boat" || e === "mountain" ? [
		"oniBlood",
		"oniSouls",
		"oniHate",
		"oniSpite"
	] : [];
	return T.filter((o) => o.season === t && (o.set === "core" || o.set === e || a.includes(o.id) || n && o.set === "daimyo" || r && o.set === "monster" || i && o.set === "lucky")).flatMap((e) => Array.from({ length: e.copies }, () => e.id));
}
//#endregion
//#region src/games/risingsun/meta.ts
var ce = {
	id: "risingsun",
	tier: "alpha",
	mechanics: [
		"area-control",
		"auction",
		"action-programming"
	],
	interactionTags: [],
	nameKey: "games.risingsun.name",
	descKey: "games.risingsun.desc",
	rulesKey: "games.risingsun.rules",
	icon: "⛩️",
	iconImg: "games/risingsun.webp",
	minPlayers: 3,
	maxPlayers: 6,
	bestPlayers: [4, 5],
	playerRange: (e) => ({
		min: 3,
		max: e && typeof e == "object" && "dynasty" in e && e.dynasty === !0 ? 6 : 5
	}),
	accent: "#a5372f",
	releasedAt: "2026-11-05T00:27:00+08:00",
	search: {
		py: "xu ri zhan hun lu",
		init: "xrzhl"
	},
	hotseat: "cover",
	botDelayMs: 650,
	rulesUrl: { en: "https://cmon-files.s3.amazonaws.com/pdf/assets_item/resource/79/Rulebook_RisingSun.pdf" }
}, D = t.int().nonnegative(), O = t.object({
	set: t.enum([
		"archway",
		"kettle",
		"horseman",
		"boat",
		"mountain"
	]).default("archway"),
	daimyo: t.boolean().default(!1),
	monster: t.boolean().default(!1),
	dynasty: t.boolean().default(!1),
	unbound: t.boolean().default(!1),
	shrines: t.enum(["beginner", "random"]).default("beginner")
}).prefault({}), le = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("choose"),
		index: D
	}),
	t.object({
		type: t.literal("mandate"),
		index: D.max(3),
		declare: D.max(4)
	}),
	t.object({
		type: t.literal("bid"),
		coins: t.tuple([
			D,
			D,
			D,
			D
		])
	}),
	t.object({
		type: t.literal("gift"),
		seat: D.max(5),
		coins: D,
		ronin: D
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), k = t.object({
	kind: t.string(),
	target: t.int(),
	at: t.int().default(-1),
	value: t.int().default(0),
	ability: t.string().optional()
}), ue = t.object({
	id: D,
	owner: D,
	kind: t.string(),
	at: t.int(),
	captive: t.int(),
	controller: t.int()
}), de = t.object({
	rid: t.string(),
	clan: t.int(),
	coins: D,
	ronin: D,
	vp: D,
	ally: t.int(),
	cards: t.array(t.string()),
	tokens: t.array(t.object({
		province: D,
		season: D
	})),
	alliedSeasons: D,
	committed: t.boolean(),
	final: t.array(t.int())
}), fe = t.object({
	config: O,
	players: t.array(de),
	pieces: t.array(ue),
	honor: t.array(D),
	turnOrder: t.array(D),
	season: D,
	phase: t.enum([
		"draft",
		"tea",
		"politics",
		"kami",
		"war",
		"cleanup",
		"winter",
		"done"
	]),
	active: t.int(),
	selector: t.int(),
	mandates: t.array(D),
	mandate: t.int(),
	mandateCount: D,
	market: t.array(t.string()),
	shrines: t.array(D),
	kami: t.array(t.object({
		god: D,
		at: t.int(),
		owner: t.int()
	})),
	wars: t.array(D),
	warIndex: D,
	battle: t.object({
		province: t.int(),
		participants: t.array(D),
		bids: t.array(t.array(D)),
		step: t.int(),
		dead: D,
		winner: t.int(),
		force: t.array(t.number())
	}).nullable(),
	prompt: t.object({
		kind: t.string(),
		seat: t.int(),
		n: t.int(),
		at: t.int(),
		card: t.string(),
		choices: t.array(k),
		pending: t.array(t.object({
			seat: t.int(),
			ability: t.string(),
			at: t.int()
		})).optional()
	}).nullable(),
	resolving: t.boolean(),
	revision: D,
	log: t.array(t.object({
		event: t.string(),
		seat: t.int(),
		target: t.int(),
		at: t.int(),
		n: t.int(),
		card: t.string()
	}))
}), pe = t.object({
	mandates: t.array(D),
	bid: t.array(D),
	legal: t.array(le)
}), A = (e, t = -1, n = 0, r = -1, i = [], a = "", o = -1) => ({
	kind: e,
	seat: t,
	n,
	at: r,
	ids: i,
	card: a,
	aux: o
}), j = (e, t = -1, n = -1, r = 0) => ({
	kind: e,
	target: t,
	at: n,
	value: r
}), me = () => j("pass"), M = (e, t, n) => e.players[t]?.cards.filter((e) => e === n).length ?? 0, N = (e, t, n) => re[e.players[t]?.clan] === n, P = (e) => e.controller < 0 ? e.owner : e.controller, F = (e) => [
	"daimyo",
	"yurei",
	"fukurokuju"
].includes(e.kind), he = (e) => [
	"shinto",
	"komainu",
	"hotei"
].includes(e.kind), ge = (e) => ["fort", "fukurokuju"].includes(e.kind), I = (e) => E[e.kind]?.kind === "monster", L = (e) => e.kind !== "fort", R = (e, t) => e.honor.indexOf(t), _e = (e, t) => new Set(e.players[t].cards.filter((e) => E[e].kind === "virtue" || e === "jurojin")).size, ve = (e, t) => new Set(e.players[t].cards.flatMap((e) => e === "jurojin" ? ["monster", "virtue"] : [E[e].kind])).size;
function ye(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function z(e, t, n = -1, r = 0, i = -1, a = -1, o = "") {
	e.log.push({
		event: t,
		seat: n,
		n: r,
		at: i,
		target: a,
		card: o
	});
}
function B(e, t, n, r = {}) {
	e.fx.push({
		kind: t,
		rid: e.players[n]?.rid,
		data: r && typeof r == "object" && !Array.isArray(r) ? {
			...r,
			clan: e.players[n]?.clan ?? -1
		} : r,
		with: e.fx.length > 0
	});
}
function V(e, t, n) {
	let r = [...e.pieces.filter((e) => e.at === n).map((e) => e.id), ...e.kami.filter((e) => e.at === n).map((e) => 1e3 + e.god)];
	return {
		fromCount: r.length,
		fromIndex: r.indexOf(t)
	};
}
function H(e, t, n, r = !0) {
	if (t < 0 || n === 0) return;
	let i = n > 0 && r && e.players[t].ally >= 0 ? n + M(e, t, "loyalty") : n;
	e.players[t].vp = Math.max(0, e.players[t].vp + i), B(e, "score", t, { n: i });
}
function U(e, t, n, r = !0, i = []) {
	if (t < 0 || !n) return;
	let a = e.players[t].coins;
	e.players[t].coins = Math.max(0, a + n), B(e, "resource", t, {
		resource: "coins",
		n: e.players[t].coins - a
	});
	let o = [];
	if (n > 0 && r) for (let n = 0; n < e.players.length; n++) {
		let r = `${t}:${n}`;
		if (n !== t && a > e.players[n].coins && M(e, n, "merchant") && !i.includes(r)) for (let t = 0; t < M(e, n, "merchant"); t++) o.push({
			...A("merchant", n, 1, -1, [], "merchant"),
			trail: [...i, r]
		});
	}
	q(e, o);
}
function W(e, t, n) {
	let r = R(e, t), i = Math.max(0, Math.min(e.honor.length - 1, r - n));
	e.honor.splice(r, 1), e.honor.splice(i, 0, t), r !== i && B(e, "resource", t, {
		resource: "honor",
		n: r - i
	}), Ce(e);
}
function be(e, t, n, r = !0) {
	let i = Math.max(...t.map((e) => n[e])), a = t.filter((e) => n[e] === i).sort((t, n) => R(e, t) - R(e, n)), o = a[0];
	if (r && a.length > 1 && N(e, o, "sun")) {
		U(e, o, 1), H(e, o, 1);
		for (let t of a.slice(1)) U(e, t, -1, !1), H(e, t, -1, !1);
		z(e, "sun", o, 1);
	}
	return o ?? -1;
}
function xe(e, t, n = "normal", r = !0) {
	let i = e.players.map((r, i) => G(e, i, t, n)), a = i.map((e, t) => e > 0 ? t : -1).filter((e) => e >= 0);
	return a.length ? be(e, a, i, r) : -1;
}
function Se(e, t) {
	return xe(e, 8 + t, "shrine", !1);
}
function Ce(e) {
	for (let t of e.kami) {
		let n = Se(e, e.shrines.indexOf(t.god));
		if (n !== t.owner && n >= 0 && t.at >= 0) {
			let r = e.players.map((n, r) => G(e, r, 8 + e.shrines.indexOf(t.god), "shrine")), i = r.map((e, t) => e > 0 ? t : -1).filter((e) => e >= 0);
			N(e, n, "sun") && be(e, i, r);
		}
		t.owner = n;
	}
}
function we(e, t, n) {
	return e.config.unbound && e.kami.some((e) => e.god === t && e.at === n);
}
function Te(e, t, n = "normal") {
	let r = P(t), i = t.at;
	if (t.captive >= 0 || i < 0 || t.kind === "fort" && !N(e, r, "turtle")) return 0;
	if (i >= 8) return he(t) ? N(e, r, "moon") ? 2 : 1 : 0;
	if (we(e, 4, i) && t.kind !== "bushi" && t.kind !== "fort") return 0;
	let a = Math.max(N(e, r, "moon") && L(t) ? 2 : 1, E[t.kind]?.force ?? 1), o = e.players.map((e, t) => t).filter((t) => e.pieces.some((e) => P(e) === t && e.at === i && L(e))), s = o.every((t) => R(e, r) >= R(e, t)), c = o.every((t) => R(e, r) <= R(e, t));
	return t.kind === "oniSkulls" && s && (a = Math.max(a, 3)), t.kind === "oniBlood" && s && (a = Math.max(a, 4)), t.kind === "sacredWarrior" && (a += e.players[r].cards.filter((e) => E[e].kind === "virtue" || e === "jurojin").length), t.kind === "daikokuten" && n === "harvest" && (a = Math.max(a, 8)), t.kind === "bishamon" && e.pieces.some((e) => e.at === i && P(e) !== r && I(e)) && (a = Math.max(a, 4)), t.kind === "bushi" && e.phase === "war" && M(e, r, "katana") && (a = Math.max(a, 2)), he(t) && c && M(e, r, "favored") && (a = Math.max(a, 3)), F(t) && (a += M(e, r, "lion") + 3 * M(e, r, "dragon")), a;
}
function G(e, t, n, r = "normal") {
	let i = e.pieces.filter((e) => P(e) === t && e.at === n).reduce((t, n) => t + Te(e, n, r), 0);
	if (n < 8 && r !== "shrine") for (let r of e.kami.filter((e) => e.owner === t && e.at === n)) i += Math.max(N(e, t, "moon") ? 2 : 0, r.god === 5 ? ve(e, t) : 1);
	return i;
}
function Ee(e, t, n, r = -1) {
	return !N(e, t, "moon") || e.pieces.filter((e) => e.id !== r && P(e) === t && (n >= 8 ? e.at >= 8 : e.at === n) && L(e)).length < 2;
}
function De(e, t, n) {
	return e.pieces.some((e) => P(e) === t && e.at === n && ge(e));
}
function Oe(e, t, n, r = !0) {
	let i = P(t);
	return n < 0 || n >= 8 || t.at < 0 || t.at >= 8 || t.at === n || t.kind === "fort" && !N(e, i, "turtle") || we(e, 6, t.at) || !Ee(e, i, n, t.id) || e.pieces.some((t) => t.at === n && t.kind === "oniPlagues" && R(e, i) < R(e, P(t))) ? !1 : !r || N(e, i, "dragonfly") || [...ae, ...C].some(([e, r]) => e === t.at && r === n || r === t.at && e === n);
}
function K(e, ...t) {
	e.tasks.unshift(...t);
}
function q(e, t) {
	t.length === 1 ? K(e, t[0]) : t.length > 1 && K(e, {
		...A("timing"),
		jobs: t
	});
}
function ke(e) {
	return e.card || (e.kind === "koi" || e.kind === "fox" ? `clan:${e.kind}` : e.kind);
}
function J(e, t, n, r = !1) {
	let i = r ? [...n, me()] : n;
	!i.length || i.length === 1 && i[0].kind === "pass" || (e.prompt = {
		kind: t.kind,
		seat: t.seat,
		n: t.n,
		at: t.at,
		card: t.card,
		choices: i,
		task: t,
		...t.kind === "timing" ? { pending: t.jobs.map((e) => ({
			seat: e.seat,
			ability: ke(e),
			at: e.at
		})) } : {}
	});
}
function Ae(e, t, n) {
	U(e, t, -n, !1);
	let r = Math.min(n, M(e, t, "benevolence"));
	r > 0 && K(e, A("benevolence", t, r));
}
function je(e, t, n) {
	return Math.max(0, N(e, t, "bonsai") ? Math.min(n, 1) : n);
}
function Me(e, t, n, r, i) {
	let a = Math.min(r, e.players[t][i]);
	i === "coins" ? (U(e, t, -a, !1), U(e, n, a, !1)) : (H(e, t, -a, !1), H(e, n, a));
}
function Y(e, t, n, r = !1, i = !0, a = []) {
	let o = t.at, s = P(t), c = V(e, t.id, o);
	t.at = n;
	let l = [...a];
	if (B(e, "move", s, {
		piece: t.id,
		from: o,
		to: n,
		kind: t.kind,
		...c
	}), z(e, r ? "summon" : "move", s, 1, n, -1, t.kind), n >= 8 ? (t.kind === "hotei" && l.push(A("hotei", s, 0, n, [], t.kind, t.id)), Ce(e)) : (t.kind === "oniHate" && l.push(A("hateStart", s, 1, n, [], t.kind)), t.kind === "oniSpite" && l.push(A("spite", s, 1, n, [], t.kind)), t.kind === "benten" && l.push(A("benten", s, 1, n, [], t.kind))), r) {
		for (let r of [
			"dignity",
			"warlord",
			"patron",
			"spirit",
			"monkey",
			"ninja",
			"kenin"
		]) if (!(r === "dignity" && !I(t) || r === "kenin" && !i)) for (let t = 0; t < M(e, s, r); t++) l.push(A([
			"monkey",
			"ninja",
			"kenin"
		].includes(r) ? r : "summonAbility", s, 1, n, [], r));
	}
	q(e, l);
}
function Ne(e, t, n, r = !1, i = !1, a = 0) {
	let o = t.map((t) => e.pieces[t]).filter((t) => t && t.at >= 0 && t.at < 8 && L(t) && (!we(e, 0, t.at) || r || R(e, P(t)) !== Math.min(...e.players.map((n, r) => G(e, r, t.at) > 0 ? R(e, r) : 99))));
	if (o.length) {
		if (!r && n >= 0 && M(e, n, "mercy")) {
			K(e, A("mercy", n, 0, -1, o.map((e) => e.id), "", a));
			return;
		}
		Pe(e, o.map((e) => e.id), n, r, i), a && H(e, n, a * o.length);
	}
}
function Pe(e, t, n, r = !1, i = !1) {
	let a = /* @__PURE__ */ new Set(), o = [], s = e.pieces.filter((e) => e.kind === "jikininki" && e.at >= 0 && e.at < 8).map((e) => ({
		id: e.id,
		seat: P(e),
		at: e.at
	})), c = e.players.map((t, n) => Array.from({ length: 8 }, (t, r) => G(e, n, r) > 0)), l = Object.fromEntries(t.map((t) => [t, V(e, t, e.pieces[t].at)]));
	for (let u of t) {
		let t = e.pieces[u], d = P(t), f = t.at;
		if (!(f < 0)) {
			n >= 0 && !r && R(e, n) < R(e, d) && a.add(d);
			for (let t = 0; t < M(e, d, "righteousness"); t++) o.push(A("deathAbility", d, 1, f, [], "righteousness"));
			for (let e of s.filter((e) => e.at === f && e.id !== u)) o.push(A("deathAbility", e.seat, 1, f, [], "jikininki"));
			e.battle?.province === f && e.battle.dead++, i && (H(e, d, 1), W(e, d, 1)), t.at = -1, t.controller = -1, [
				"phoenix",
				"ebisu",
				"koneko"
			].includes(t.kind) && o.push(A("deathAbility", d, 1, f, t.kind === "koneko" ? e.turnOrder.filter((e) => e !== d && c[e][f]) : [u], t.kind)), z(e, "killed", d, 1, f, n, t.kind), B(e, "kill", d, {
				piece: u,
				at: f,
				kind: t.kind,
				...l[u]
			});
		}
	}
	if (n >= 0) for (let t = 0; t < a.size * M(e, n, "justice"); t++) o.push(A("deathAbility", n, 3, -1, [], "justice"));
	q(e, o);
}
function Fe(e, t, n) {
	let r = e.pieces[n], i = P(r), a = r.at, o = V(e, n, a);
	r.at = -1, r.captive = t, r.controller = -1, Me(e, i, t, 1, "vp");
	let s = M(e, t, "sincerity");
	s && (H(e, t, s), W(e, t, s)), z(e, "hostage", t, 1, a, i, r.kind), B(e, "hostage", t, {
		piece: n,
		at: a,
		kind: r.kind,
		figureClan: e.players[i].clan,
		...o
	});
}
function Ie(e, t, n, r = !1) {
	let [i, a, o] = oe[n], s = r && we(e, 1, n) ? 2 : 1;
	U(e, t, i * s), e.players[t].ronin += a * s, H(e, t, o * s), e.harvested[t].push(n), z(e, "harvest", t, s, n);
}
function Le(e, t, n, r, i = !0) {
	let a = e.pieces.filter((e) => e.owner === t && e.at === -1 && e.captive < 0 && L(e) && (!r || r.includes(e.kind)));
	return a.filter((e, t) => a.findIndex((t) => t.kind === e.kind) === t).flatMap((r) => Array.from({ length: i && he(r) ? 12 : 8 }, (e, t) => t).filter((i) => (n ? n.includes(i) : i >= 8 || N(e, t, "dragonfly") || De(e, t, i)) && Ee(e, t, i, r.id)).map((e) => j("summon", r.id, e)));
}
function Re(e, t, n = !1, r = []) {
	let i = e.pieces.filter((n) => P(n) === t && (!r.length || r.includes(n.id)) && !e.movements.includes(n.id)).flatMap((t) => Array.from({ length: 8 }, (e, t) => t).filter((r) => Oe(e, t, r, !n)).map((e) => j("move", t.id, e))), a = e.kami.filter((n) => n.owner === t && n.at >= 0 && !e.movements.includes(1e3 + n.god) && !r.length).flatMap((r) => Array.from({ length: 8 }, (e, t) => t).filter((i) => i !== r.at && (n || N(e, t, "dragonfly") || [...ae, ...C].some(([e, t]) => e === r.at && t === i || t === r.at && e === i))).map((e) => j("kamiMove", 1e3 + r.god, e)));
	return [...i, ...a];
}
function ze(e, t, n, r = 0) {
	let i = Math.max(0, je(e, t, E[n].cost) - r);
	if (Ae(e, t, i), e.market.splice(e.market.indexOf(n), 1), e.players[t].cards.push(n), z(e, "buy", t, i, -1, -1, n), B(e, "card", t, { card: n }), E[n].kind === "virtue" && U(e, t, 3 * M(e, t, "jurojin")), E[n].kind === "monster") {
		let r = {
			id: e.pieces.length,
			owner: t,
			kind: n,
			at: -1,
			captive: -1,
			controller: -1
		};
		if (e.pieces.push(r), n === "daikaiju") {
			r.at = -2;
			return;
		}
		K(e, A("monsterSummon", t, 1, -1, [r.id], n));
	}
}
function Be(e, t, n = 0) {
	let r = N(e, t, "sun") || N(e, t, "moon");
	return [...new Set(e.market)].filter((i) => (E[i].kind !== "monster" || E[i].lucky === r) && Math.max(0, je(e, t, E[i].cost) - n) <= e.players[t].coins).map((t) => j("card", e.market.indexOf(t)));
}
function Ve(e) {
	e.phase = "tea", e.tea = 0, e.teaDone = [], e.wars = ye(e, [
		0,
		1,
		2,
		3,
		4,
		5,
		6,
		7
	]).slice(0, e.players.length + 2), e.warIndex = 0, e.battle = null, e.mandate = -1, e.mandateCount = 0, e.mandates = ye(e, [
		0,
		0,
		1,
		1,
		2,
		2,
		3,
		3,
		4,
		4
	]), e.market = se(e.config.set, e.season, e.config.daimyo, e.config.monster, e.players.some((e) => e.clan === 1 || e.clan === 7));
	for (let t = 0; t < e.players.length; t++) e.players[t].ally = -1, e.players[t].coins = 0, e.players[t].ronin = 0, U(e, t, ie[e.players[t].clan]), e.players[t].committed = !1;
	for (let t of e.pieces.filter((e) => e.captive >= 0)) U(e, t.captive, 1), t.captive = -1;
	z(e, "season", -1, e.season), K(e, A("teaNext")), e.season > 0 && q(e, e.turnOrder.flatMap((t) => ["salamander", "pacifist"].flatMap((n) => Array.from({ length: M(e, t, n) }, () => A("seasonAbility", t, 1, -1, [], n)))));
}
function He(e) {
	let t = e.turnOrder.find((t) => !e.teaDone.includes(t) && e.players[t].ally < 0);
	if (t === void 0) {
		e.phase = "politics", Ue(e);
		return;
	}
	J(e, A("tea", t), e.turnOrder.filter((n) => n !== t && e.players[n].ally < 0).map((e) => j("seat", e)), !0), e.prompt || (e.teaDone.push(t), K(e, A("teaNext")));
}
function Ue(e) {
	e.phase = "politics", e.selector = e.turnOrder[e.selectorCursor % e.players.length], e.selectorCursor++, e.prompt = null, e.mandates.length || (e.mandates = ye(e, [
		0,
		0,
		1,
		1,
		2,
		2,
		3,
		3,
		4,
		4
	]));
}
function We(e) {
	let t = e.turnOrder.indexOf(e.selector);
	return e.mandate === 2 ? [
		e.selector,
		...e.turnOrder.slice(t + 1),
		...e.turnOrder.slice(0, t)
	] : [...e.turnOrder.slice(t + 1), ...e.turnOrder.slice(0, t + 1)];
}
function Ge(e, t) {
	e.mandate = t, e.mandateCount++, z(e, "mandate", e.selector, t), B(e, "mandate", e.selector, { mandate: t }), t !== 4 && e.players[e.selector].ally >= 0 && H(e, e.selector, 2 * M(e, e.selector, "honesty"));
	let n = We(e), r = [];
	if (e.harvested = e.players.map(() => []), t === 4) r.push(A("betrayStart", e.selector));
	else for (let i of n) {
		let n = i === e.selector || e.players[e.selector].ally === i;
		t === 0 && r.push(A("recruitStart", i, +!!n)), t === 1 && r.push(A("marshalStart", i, +!!n)), t === 2 && r.push(A("train", i, +!!n)), t === 3 && r.push(A("harvest", i, +!!n));
	}
	if (t === 3) {
		let t = e.turnOrder.filter((t) => M(e, t, "sengoku")).map((e) => A("sengoku", e, 1, -1, [], "sengoku"));
		t.length && r.push({
			...A("timing"),
			jobs: t
		});
	}
	r.push(A("mandateEnd")), K(e, ...r);
}
function Ke(e) {
	e.phase = "kami", K(e, ...e.shrines.map((e, t) => A("kamiShrine", -1, e, 8 + t)), A("kamiEnd"));
}
function qe(e) {
	e.phase = "war", e.warIndex = 0;
	let t = [];
	for (let n of e.turnOrder) {
		for (let r of [
			"shogun",
			"moneylender",
			"bushido",
			"ronin",
			"righteous"
		]) for (let i = 0; i < M(e, n, r); i++) t.push(A("warAbility", n, 1, -1, [], r));
		for (let r = 0; r < M(e, n, "ashigaru"); r++) t.push(A("ashigaru", n, 1, -1, [], "ashigaru"));
		for (let r = 0; r < M(e, n, "keiri"); r++) t.push(A("keiri", n, 2, -1, [], "keiri"));
		N(e, n, "koi") && t.push(A("koi", n)), N(e, n, "fox") && t.push(A("fox", n));
		for (let r of e.pieces.filter((e) => P(e) === n && e.at >= 0 && e.kind === "sunakake")) t.push(A("sand", n, 1, r.at, [], r.kind));
		for (let r of e.pieces.filter((e) => P(e) === n && e.at === -2 && e.kind === "daikaiju")) t.push(A("daikaiju", n, 1, -1, [r.id], r.kind));
	}
	K(e, A("warNext")), q(e, t);
}
function Je(e) {
	if (e.warIndex >= e.wars.length) {
		e.phase = "cleanup", K(e, A("cleanup"));
		return;
	}
	let t = e.wars[e.warIndex];
	e.battle = null, z(e, "warProvince", -1, 0, t);
	let n = [];
	if (we(e, 3, t)) for (let r of e.turnOrder) G(e, r, t) > 0 && n.push(A("moonIncome", r, 4, t, [], "god:3"));
	for (let r of e.pieces.filter((e) => e.kind === "nureOnna" && e.at >= 0 && e.at < 8 && e.at !== t)) C.some(([e, n]) => e === t && n === r.at || n === t && e === r.at) && n.push(A("nureOnna", P(r), 1, t, [r.id], r.kind));
	K(e, A("battleStart", -1, 0, t)), q(e, n);
}
function Ye(e, t) {
	let n = e.turnOrder.filter((n) => G(e, n, t) > 0), r = n.length === 2 && e.players[n[0]].ally === n[1];
	if (n.length < 2 || r) {
		n.length && K(e, A("winProvince", xe(e, t), 0, t)), Xe(e);
		return;
	}
	e.battle = {
		province: t,
		participants: n,
		bids: [],
		step: -1,
		dead: 0,
		winner: -1,
		force: e.players.map((n, r) => G(e, r, t)),
		sealed: e.players.map(() => null),
		ronin: -1,
		removed: [],
		losers: [],
		paid: !1
	};
	for (let t of e.players) t.committed = !1;
	let i = [];
	for (let n of e.turnOrder) for (let r of e.pieces.filter((e) => P(e) === n && e.at === t)) r.kind === "earthDragon" && i.push(A("earthDragon", n, 1, t, [], r.kind)), r.kind === "jorogumo" && i.push(A("jorogumo", n, 1, t, [], r.kind)), r.kind === "fireDragon" && i.push(A("fireDragonStart", n, 1, t, [r.id], r.kind));
	K(e, A("bidStart")), q(e, i);
}
function Xe(e) {
	e.tasks.push(A("warAdvance"));
}
function Ze(e, t) {
	let n = e.battle;
	n.step = t;
	let r = n.participants.filter((e) => (n.sealed[e]?.[t] ?? 0) > 0), i = e.players.map((e, r) => n.sealed[r]?.[t] ?? 0), a = r.length ? be(e, r, i) : -1;
	if (a < 0) return;
	let o = n.province;
	t === 0 && J(e, A("seppuku", a, 1, o), [j("yes")], !0), t === 1 && K(e, A("hostage", a, 1 + M(e, a, "respect"), o)), t === 2 && J(e, A("ronin", a, 1, o), [j("yes")], !0), t === 3 && J(e, A("poets", a, n.dead, o), [j("yes")], !0);
}
function Qe(e, t, n) {
	if (t < 0) return;
	e.players[t].tokens.push({
		province: n,
		season: e.season
	});
	let r = [];
	for (let i = 0; i < M(e, t, "courage"); i++) r.push(A("winAbility", t, 2, n, [], "courage"));
	if (e.pieces.some((e) => P(e) === t && e.at === n && he(e))) for (let i = 0; i < M(e, t, "piety"); i++) r.push(A("winAbility", t, 3, n, [], "piety"));
	for (let i of e.pieces.filter((e) => e.at === n && (e.kind === "oniSouls" && P(e) === t || e.kind === "kitsune"))) r.push(A("winAbility", t, i.kind === "kitsune" ? 6 : 2 * e.pieces.filter((e) => P(e) === t && E[e.kind]?.oni).length, n, [], i.kind));
	we(e, 1, n) && r.push(A("winAbility", t, 1, n, [], "god:1")), q(e, r), z(e, "win", t, e.season + 1, n), B(e, "win", t, { at: n });
}
function $e(e, t) {
	let n = t.seat, r = t.at;
	switch (t.kind) {
		case "timing": {
			let n = t.jobs ?? [];
			if (n.length < 2 || n.every((e) => JSON.stringify(e) === JSON.stringify(n[0]))) {
				K(e, ...n);
				break;
			}
			let r = e.honor.find((e) => n.some((t) => t.seat === e));
			J(e, {
				...t,
				seat: r
			}, n.flatMap((e, t) => e.seat === r ? [{
				...j("timing", t, e.at, 1),
				ability: ke(e)
			}, {
				...j("timing", t, e.at, -1),
				ability: ke(e)
			}] : []));
			break;
		}
		case "merchant":
			U(e, n, t.n, !0, t.trail);
			break;
		case "seasonAbility":
			t.card === "salamander" && (U(e, n, 3), W(e, n, -1)), t.card === "pacifist" && e.players[n].tokens.length < Math.max(...e.players.map((e) => e.tokens.length)) && H(e, n, 4);
			break;
		case "summonAbility":
			t.card === "dignity" && H(e, n, 2), t.card === "warlord" && U(e, n, 1), t.card === "patron" && e.players.filter((t, r) => R(e, r) > R(e, n)).length >= 2 && U(e, n, 2), t.card === "spirit" && R(e, n) === 0 && (U(e, n, 2), H(e, n, 2));
			break;
		case "deathAbility":
			if ((t.card === "righteousness" || t.card === "justice") && H(e, n, t.n), t.card === "jikininki" && (H(e, n, 1), W(e, n, -1)), t.card === "phoenix" && (H(e, n, 1), K(e, A("phoenixReturn", n, 1, r, t.ids))), t.card === "ebisu" && U(e, n, 8), t.card === "koneko") {
				U(e, n, 2), e.players[n].ronin += 2;
				for (let n of t.ids) U(e, n, -2, !1), e.players[n].ronin = Math.max(0, e.players[n].ronin - 2);
			}
			break;
		case "winAbility":
			t.card === "god:1" ? Ie(e, n, r) : (H(e, n, t.n), t.card === "piety" && W(e, n, 1));
			break;
		case "season":
			Ve(e);
			break;
		case "teaNext":
			He(e);
			break;
		case "mandateEnd":
			[
				3,
				5,
				7
			].includes(e.mandateCount) ? Ke(e) : Ue(e);
			break;
		case "recruitStart": {
			let r = e.pieces.filter((e) => P(e) === n && e.at >= 0 && e.at < 8 && ge(e)).map((e) => e.at);
			t.n && r.push(-1), e.summonLeft = r.length, K(e, A("recruit", n, 0, -1, r), A("recruitExtra", n));
			break;
		}
		case "recruit":
			t.ids.length && J(e, t, Le(e, n).filter((r) => r.at >= 8 || N(e, n, "dragonfly") || t.ids.includes(r.at) || t.ids.includes(-1)), !0);
			break;
		case "recruitExtra": {
			let t = [];
			for (let r = 0; r < M(e, n, "light"); r++) t.push(A("light", n, 1));
			for (let r = 0; r < M(e, n, "samurai"); r++) t.push(A("samurai", n, 1));
			for (let r of e.pieces.filter((e) => P(e) === n && e.kind === "jinmenju" && e.at >= 0 && e.at < 8)) t.push(A("jinmenju", n, 1, r.at));
			q(e, t.map((e) => ({
				...e,
				card: e.kind
			})));
			break;
		}
		case "light":
			J(e, t, Le(e, n, [
				8,
				9,
				10,
				11
			], ["shinto"]), !0);
			break;
		case "samurai":
			J(e, t, Le(e, n, [
				0,
				1,
				2,
				3,
				4,
				5,
				6,
				7
			], ["bushi"], !1), !0);
			break;
		case "jinmenju":
			J(e, t, Le(e, n, [r], void 0, !1), !0);
			break;
		case "kenin":
			J(e, t, Le(e, n, void 0, ["bushi"], !1), !0);
			break;
		case "monsterSummon": {
			let r = e.pieces[t.ids[0]];
			J(e, t, Le(e, n, void 0, [r.kind]), !1);
			break;
		}
		case "marshalStart":
			e.movements = [], e.taxes = [], e.buildLeft = t.n + M(e, n, "builder"), K(e, A("marshal", n), A("build", n, e.buildLeft), A("kannushi", n, M(e, n, "kannushi")));
			break;
		case "marshal":
			J(e, t, Re(e, n), !0);
			break;
		case "build": {
			let r = e.pieces.find((e) => e.owner === n && e.kind === "fort" && e.at < 0), i = je(e, n, 3);
			t.n > 0 && r && e.players[n].coins >= i && J(e, t, Array.from({ length: 8 }, (e, t) => j("province", t)), !0);
			break;
		}
		case "kannushi":
			t.n > 0 && J(e, t, e.pieces.filter((e) => P(e) === n && he(e) && e.at >= 8).flatMap((t) => e.shrines.map((e, t) => t + 8).filter((e) => e !== t.at).map((e) => j("move", t.id, e))), !0);
			break;
		case "train":
		case "ryujin":
			J(e, t, Be(e, n, t.kind === "train" ? t.n : 0), !0);
			break;
		case "harvest":
			U(e, n, 1);
			for (let r = 0; r < 8; r++) {
				let i = xe(e, r, "harvest", !1) === n, a = e.pieces.some((e) => P(e) === n && e.kind === "kotahi" && e.at === r);
				i && (t.n || a) && (xe(e, r, "harvest"), Ie(e, n, r, !0));
			}
			break;
		case "sengoku":
			for (let t of e.pieces.filter((e) => P(e) === n && e.at >= 0 && e.at < 8 && F(e))) e.harvested[n].includes(t.at) || Ie(e, n, t.at, !0);
			break;
		case "betrayStart":
			if (e.players[n].ally >= 0) {
				let t = e.players[n].ally;
				e.players[n].ally = -1, e.players[t].ally = -1, W(e, n, -1), z(e, "betray", n, 0, -1, t);
			}
			K(e, A("betray", n, 2, -1, []), A("unrighteous", n, M(e, n, "unrighteous")));
			break;
		case "betray":
		case "unrighteous":
			if (t.n <= 0) break;
			J(e, t, e.pieces.filter((r) => P(r) !== n && ["bushi", "shinto"].includes(r.kind) && r.captive < 0 && r.at >= 0 && (t.kind === "unrighteous" || r.at < 8 && !t.ids.includes(P(r))) && e.pieces.some((e) => e.owner === n && e.kind === r.kind && e.at === -1 && e.captive < 0) && Ee(e, n, r.at)).map((e) => j("piece", e.id, e.at)), !0);
			break;
		case "kamiShrine": {
			let n = xe(e, r, "shrine");
			if (n < 0) break;
			z(e, "kami", n, t.n, r);
			let i = [];
			t.n === 0 && (W(e, n, e.players.length), z(e, "honor", n, e.players.length)), t.n === 1 && i.push(A("fujin", n, 2)), t.n === 2 && (e.players[n].ronin += 2), t.n === 3 && U(e, n, 2), t.n === 4 && i.push(A("raijin", n, 1)), t.n === 5 && i.push(A("ryujin", n)), t.n === 6 && H(e, n, e.pieces.filter((e) => P(e) === n && e.at >= 0 && e.at < 8 && ge(e)).length), e.config.unbound && i.push(A("manifest", n, t.n)), K(e, ...i);
			break;
		}
		case "fujin":
			e.movements = [], t.n > 0 && J(e, t, Re(e, n), !0);
			break;
		case "raijin":
			J(e, t, Le(e, n, [
				0,
				1,
				2,
				3,
				4,
				5,
				6,
				7
			], ["bushi"], !1), !0);
			break;
		case "manifest":
			J(e, t, Array.from({ length: 8 }, (e, t) => j("province", t)));
			break;
		case "kamiEnd": {
			let t = e.turnOrder.flatMap((t) => ["patience", "snake"].flatMap((n) => Array.from({ length: M(e, t, n) }, () => A(n, t, 1, -1, [], n))));
			K(e, A("afterKami")), q(e, t);
			break;
		}
		case "patience":
			e.players[n].vp < Math.max(...e.players.map((e) => e.vp)) && H(e, n, 1);
			break;
		case "snake":
			J(e, t, [j("yes")], !0);
			break;
		case "afterKami":
			e.mandateCount === 7 ? qe(e) : Ue(e);
			break;
		case "benevolence":
			J(e, t, e.turnOrder.filter((e) => e !== n).map((e) => j("seat", e)), !0);
			break;
		case "monkey":
		case "ninja":
			J(e, t, t.kind === "monkey" ? [j("yes")] : e.pieces.filter((e) => e.kind === "bushi" && e.at >= 0 && e.at < 8).map((e) => j("piece", e.id, e.at)), !0);
			break;
		case "hotei":
			J(e, t, e.pieces.filter((e) => e.at === r && he(e) && e.id !== t.aux).map((e) => j("piece", e.id, r)), !0);
			break;
		case "hate":
			J(e, t, t.ids.filter((t) => e.pieces[t].at === r).map((e) => j("piece", e, r)), !0);
			break;
		case "hateStart":
			K(e, ...e.turnOrder.filter((t) => R(e, t) < R(e, n)).map((t) => A("hate", n, 1, r, e.pieces.filter((e) => P(e) === t && e.at === r && ["bushi", "shinto"].includes(e.kind)).map((e) => e.id), "oniHate")));
			break;
		case "spite":
			for (let t of e.turnOrder.filter((t) => t !== n && R(e, t) < R(e, n) && G(e, t, r) > 0)) Me(e, t, n, 2, "vp");
			break;
		case "benten":
			J(e, t, e.pieces.filter((e) => e.at === r && P(e) !== n && I(e) && !F(e)).map((e) => j("piece", e.id, r)), !0);
			break;
		case "pushDestination": {
			let n = e.pieces[t.ids[0]];
			J(e, t, Array.from({ length: 8 }, (e, t) => t).filter((t) => Oe(e, n, t, !1)).map((e) => j("province", e)), !0);
			break;
		}
		case "mercy":
			J(e, t, [j("yes"), j("no")]);
			break;
		case "warAbility":
			if (t.card === "shogun" && U(e, n, 3), t.card === "moneylender" && U(e, n, 5), t.card === "bushido") {
				let t = 2 * _e(e, n);
				U(e, n, t), H(e, n, t);
			}
			if (t.card === "ronin" && (e.players[n].ronin += 2), t.card === "righteous") for (let t of e.turnOrder.filter((t) => R(e, t) > R(e, n))) Me(e, t, n, 1, "coins");
			break;
		case "koi": {
			let t = e.players[n].ronin;
			e.players[n].ronin = 0, U(e, n, t);
			break;
		}
		case "moonIncome":
			U(e, n, 4);
			break;
		case "ashigaru":
			t.n > 0 && J(e, t, Array.from({ length: 8 }, (e, t) => t).filter((t) => e.pieces.filter((e) => P(e) === n && e.at === t && L(e)).length === 1).map((e) => j("province", e)), !0);
			break;
		case "keiri": {
			let r = e.pieces.filter((e) => P(e) === n && F(e) && e.at >= 0 && e.at < 8).map((e) => e.at);
			J(e, t, e.pieces.filter((e) => P(e) !== n && r.includes(e.at) && ["bushi", "shinto"].includes(e.kind)).map((e) => j("piece", e.id, e.at)), !0);
			break;
		}
		case "fox":
			e.pieces.find((e) => e.owner === n && e.kind === "bushi" && e.at === -1 && e.captive < 0) && J(e, t, Array.from({ length: 8 }, (e, t) => t).filter((r) => G(e, n, r) === 0 && !t.ids.includes(r)).map((e) => j("province", e)), !0);
			break;
		case "sand":
		case "hostage":
			t.n > 0 && J(e, t, e.pieces.filter((e) => e.at === r && P(e) !== n && L(e) && !F(e) && (t.kind !== "sand" || ["bushi", "shinto"].includes(e.kind))).map((e) => j("piece", e.id, r)), !0);
			break;
		case "daikaiju":
			J(e, t, Array.from({ length: 8 }, (e, t) => j("province", t)));
			break;
		case "warNext":
			Je(e);
			break;
		case "nureOnna":
			Oe(e, e.pieces[t.ids[0]], r, !1) && J(e, t, [j("yes")], !0);
			break;
		case "battleStart":
			Ye(e, r);
			break;
		case "earthDragon":
			J(e, t, e.pieces.filter((e) => e.at === r && P(e) !== n && L(e) && !F(e) && !t.ids.includes(P(e))).map((e) => e.id).map((e) => j("piece", e, r)), !0);
			break;
		case "jorogumo":
			J(e, t, e.pieces.filter((e) => e.at === r && P(e) !== n && ["bushi", "shinto"].includes(e.kind)).map((e) => j("piece", e.id, r)), !0);
			break;
		case "fireDragonStart":
			K(e, ...e.turnOrder.map((e) => A("fireDragon", n, 1, r, t.ids, t.card, e)));
			break;
		case "fireDragon":
			J(e, t, e.pieces.filter((e) => e.at === r && P(e) === t.aux && e.id !== t.ids[0] && L(e) && !F(e)).map((e) => j("piece", e.id, r)));
			break;
		case "bidStart": {
			let t = e.battle;
			t.participants = e.turnOrder.filter((n) => G(e, n, t.province) > 0), t.force = e.players.map((n, r) => G(e, r, t.province)), t.step = 0;
			for (let n of e.turnOrder) e.players[n].committed = !t.participants.includes(n);
			if (t.participants.length < 2 || t.participants.length === 2 && e.players[t.participants[0]].ally === t.participants[1]) {
				K(e, A("winProvince", xe(e, t.province), 0, t.province), A("battleFinish"));
				break;
			}
			break;
		}
		case "reveal": {
			let t = e.battle;
			t.bids = t.sealed.map((e) => e ?? [
				0,
				0,
				0,
				0
			]), z(e, "reveal", -1, 0, t.province), B(e, "reveal", -1, {
				bids: t.bids,
				players: e.players.map((e) => e.rid)
			});
			let n = [];
			for (let r of t.participants) {
				let i = t.bids[r].reduce((e, t) => e + t, 0);
				U(e, r, -i, !1), i && M(e, r, "benevolence") && n.push(A("benevolence", r, Math.min(i, M(e, r, "benevolence"))));
			}
			K(e, A("advantage", -1, 0), A("advantage", -1, 1), A("advantage", -1, 2), A("battleResolve"), A("advantage", -1, 3), A("reparation"), A("battleFinish")), q(e, n.map((e) => ({
				...e,
				card: "benevolence"
			})));
			break;
		}
		case "advantage":
			Ze(e, t.n);
			break;
		case "battleResolve": {
			let t = e.battle;
			t.step = 4;
			let n = e.players.map((n, r) => G(e, r, t.province) + (t.ronin === r ? (N(e, r, "koi") ? e.players[r].coins : e.players[r].ronin) * (we(e, 2, t.province) ? 2 : 1) : 0));
			t.force = n;
			let r = be(e, t.participants, n);
			t.winner = r, t.losers = t.participants.filter((e) => e !== r), K(e, A("battleCasualties", r, 0, t.province)), Qe(e, r, t.province), z(e, "battle", r, n[r], t.province);
			break;
		}
		case "battleCasualties":
			Ne(e, e.pieces.filter((t) => t.at === r && P(t) !== n && P(t) !== e.players[n].ally && L(t)).map((e) => e.id), n);
			break;
		case "reparation": {
			let t = e.battle;
			if (t.step = 5, t.paid) break;
			t.paid = !0;
			let n = t.bids[t.winner]?.reduce((e, t) => e + t, 0) ?? 0;
			if (t.losers.length) {
				let r = Math.floor(n / t.losers.length);
				for (let n of t.losers) U(e, n, r, !1);
				let i = n % t.losers.length;
				i && K(e, A("remainder", t.winner, i, -1, []));
			}
			break;
		}
		case "remainder":
			t.n > 0 && J(e, t, e.battle.losers.filter((e) => !t.ids.includes(e)).map((e) => j("seat", e)));
			break;
		case "winProvince":
			Qe(e, n, r);
			break;
		case "battleFinish":
			for (let t of e.pieces) t.controller = -1;
			e.battle = null, e.tasks.push(A("warAdvance"));
			break;
		case "warAdvance":
			e.warIndex++, K(e, A("warNext"));
			break;
		case "cleanup": {
			let t = e.pieces.filter((e) => e.at >= 8).map((t) => ({
				piece: t.id,
				at: t.at,
				kind: t.kind,
				...V(e, t.id, t.at)
			}));
			for (let n of t) B(e, "return", e.pieces[n.piece].owner, n), e.pieces[n.piece].at = -1;
			for (let t of e.kami) t.at >= 0 && B(e, "return", t.owner, {
				piece: 1e3 + t.god,
				at: t.at,
				to: 8 + e.shrines.indexOf(t.god),
				kind: `kami:${t.god}`,
				...V(e, 1e3 + t.god, t.at)
			}), t.at = -1, t.owner = -1;
			for (let t of e.players) t.coins = 0, t.ronin = 0, t.committed = !1;
			if (e.season === 2) {
				for (let t of e.pieces.filter((e) => e.captive >= 0)) U(e, t.captive, 1), t.captive = -1;
				e.phase = "winter", K(e, ...e.turnOrder.map((e) => A("winter", e)), A("end"));
			} else e.season++, K(e, A("season"));
			break;
		}
		case "winter": {
			let t = e.players[n], r = new Set(t.tokens.map((e) => e.province)).size, i = t.tokens.reduce((e, t) => e + t.season + 1, 0), a = r >= 7 ? 30 : r >= 5 ? 20 : r >= 3 ? 10 : 0, o = e.pieces.filter((e) => P(e) === n && ge(e) && e.at >= 0 && e.at < 8).length, s = e.pieces.filter((e) => e.owner === n && I(e)).length, c = e.pieces.filter((e) => e.owner === n && E[e.kind]?.oni).length, l = 3 * o * M(e, n, "kitsuneForm") + 3 * _e(e, n) * M(e, n, "phoenixForm") + 3 * s * M(e, n, "beastForm") + 3 * t.alliedSeasons * M(e, n, "kindredForm") + 3 * c * M(e, n, "demonForm") + t.tokens.length * M(e, n, "dragonForm") + 2 * ve(e, n) * M(e, n, "tanukiForm");
			t.final = [
				t.vp,
				i,
				a,
				l
			], H(e, n, i + a + l, !1), z(e, "winter", n, i + a + l);
			break;
		}
		case "phoenixReturn":
			Ee(e, n, r) && Y(e, e.pieces[t.ids[0]], r);
			break;
		case "end": {
			let t = Math.max(...e.players.map((e) => e.vp)), n = e.turnOrder.filter((n) => e.players[n].vp === t), r = [...n].sort((t, n) => R(e, t) - R(e, n))[0];
			n.length > 1 && !n.includes(e.players[r].ally) && be(e, n, e.players.map((e) => e.vp));
			for (let t of e.players) t.final.push(t.vp - t.final.reduce((e, t) => e + t, 0));
			e.phase = "done";
			break;
		}
	}
}
function et(e, t, n) {
	let r = t.seat, i = t.at, a = n.kind !== "pass", o = e.pieces[n.target];
	switch (t.kind) {
		case "timing": {
			let i = [...t.jobs], a = i.splice(n.target, 1)[0], o = {
				...A("timing"),
				jobs: i
			};
			z(e, "timing", r, n.value, a.at, -1, ke(a)), n.value === 1 ? K(e, a, o) : K(e, o, a);
			break;
		}
		case "draft":
			if (e.players[r].clan = n.target, e.draft++, e.draft < e.players.length) tt(e);
			else {
				e.honor = e.players.map((e, t) => t).sort((t, n) => e.players[t].clan - e.players[n].clan), e.turnOrder = [...e.honor];
				for (let t = 0; t < e.players.length; t++) {
					let n = x[e.players[t].clan];
					for (let [r, i] of [
						["daimyo", 1],
						["shinto", 3],
						["bushi", 6],
						["fort", 4]
					]) for (let a = 0; a < i; a++) e.pieces.push({
						id: e.pieces.length,
						owner: t,
						kind: r,
						at: r === "daimyo" || r === "bushi" && a === 0 || r === "fort" && a === 0 ? n : -1,
						captive: -1,
						controller: -1
					});
				}
				K(e, A("season"));
			}
			break;
		case "tea":
			e.teaDone.push(r), a ? J(e, A("alliance", n.target, 0, -1, [], "", r), [j("yes"), j("no")]) : K(e, A("teaNext"));
			break;
		case "alliance":
			if (n.kind === "yes") {
				let n = t.aux;
				e.players[r].ally = n, e.players[n].ally = r, e.players[r].alliedSeasons++, e.players[n].alliedSeasons++, z(e, "alliance", r, 0, -1, n);
			}
			K(e, A("teaNext"));
			break;
		case "recruit":
			if (a) {
				let i = [...t.ids], a = n.at >= 8 || N(e, r, "dragonfly") ? 0 : i.includes(n.at) ? i.indexOf(n.at) : i.indexOf(-1);
				i.splice(a, 1), e.summonLeft = i.length, K(e, A("recruit", r, 0, -1, i)), Y(e, o, n.at, !0);
			}
			break;
		case "light":
		case "samurai":
		case "raijin":
		case "jinmenju":
		case "monsterSummon":
		case "kenin":
			a && (t.kind === "kenin" ? (t.n > 1 && K(e, A("kenin", r, t.n - 1)), Y(e, o, n.at, !1, !1)) : Y(e, o, n.at, !0), t.kind === "jinmenju" && W(e, r, -1));
			break;
		case "marshal":
		case "fujin":
			if (a) {
				let i = [];
				if (t.kind === "marshal" && e.movements.push(n.target), (t.kind === "marshal" || t.n > 1) && K(e, A(t.kind, r, t.n - 1)), n.kind === "kamiMove") {
					let t = e.kami.find((e) => 1e3 + e.god === n.target), i = t.at, a = V(e, n.target, i);
					t.at = n.at, B(e, "move", r, {
						piece: n.target,
						from: i,
						to: n.at,
						kind: `kami:${t.god}`,
						...a
					});
				} else {
					let a = o.at;
					if (t.kind === "marshal" && C.some(([e, t]) => e === a && t === n.at || t === a && e === n.at)) for (let t of e.turnOrder.filter((t) => t !== r && M(e, t, "serpent"))) {
						let o = `${t}:${Math.min(a, n.at)}:${Math.max(a, n.at)}`;
						e.taxes.includes(o) || (e.taxes.push(o), i.push(A("serpent", t, 1, -1, [], "serpent", r)));
					}
					Y(e, o, n.at, !1, !0, i);
				}
			}
			break;
		case "build":
			if (a) {
				let i = e.pieces.find((e) => e.owner === r && e.kind === "fort" && e.at < 0);
				Ae(e, r, je(e, r, 3)), i.at = n.target, z(e, "build", r, 1, n.target), B(e, "build", r, { at: n.target }), t.n > 1 && K(e, A("build", r, t.n - 1));
			}
			break;
		case "kannushi":
			a && (t.n > 1 && K(e, A("kannushi", r, t.n - 1)), Y(e, o, n.at));
			break;
		case "train":
		case "ryujin":
			a && ze(e, r, e.market[n.target], t.kind === "train" ? t.n : 0);
			break;
		case "betray":
		case "unrighteous":
			if (a) {
				let n = P(o), i = e.pieces.find((e) => e.owner === r && e.at === -1 && e.captive < 0 && e.kind === o.kind), a = o.at;
				B(e, "return", n, {
					piece: o.id,
					at: a,
					kind: o.kind,
					...V(e, o.id, a)
				}), o.at = -1, o.controller = -1, t.n > 1 && K(e, A(t.kind, r, t.n - 1, -1, [...t.ids, n])), Y(e, i, a, !1), z(e, "replace", r, 1, a, n);
			}
			break;
		case "manifest": {
			let i = e.kami.find((e) => e.god === t.n), a = i.at, o = V(e, 1e3 + i.god, a);
			i.at = n.target, i.owner = Se(e, e.shrines.indexOf(t.n)), B(e, "move", r, {
				piece: 1e3 + i.god,
				from: a,
				sourceAt: 8 + e.shrines.indexOf(i.god),
				to: n.target,
				kind: `kami:${i.god}`,
				...o
			}), B(e, "manifest", r, {
				god: t.n,
				at: n.target
			}), z(e, "manifest", r, t.n, n.target);
			break;
		}
		case "snake":
			a && K(e, A("betrayStart", r));
			break;
		case "benevolence":
			a && (U(e, n.target, 1, !1), W(e, r, 1), H(e, r, 2), t.n > 1 && K(e, A("benevolence", r, t.n - 1)));
			break;
		case "serpent":
			a && Me(e, t.aux, r, 1, "coins");
			break;
		case "monkey":
			if (a) {
				let n = Math.max(...e.players.filter((e, t) => t !== r).map((e) => e.coins));
				for (let t of e.turnOrder.filter((t) => t !== r && e.players[t].coins === n)) Me(e, t, r, 1, "coins");
				W(e, r, -1), t.n > 1 && K(e, A("monkey", r, t.n - 1));
			}
			break;
		case "ninja":
			a && (Ne(e, [n.target], r, P(o) === r), W(e, r, -1), t.n > 1 && K(e, A("ninja", r, t.n - 1)));
			break;
		case "hotei":
			a && (B(e, "return", P(o), {
				piece: o.id,
				at: o.at,
				kind: o.kind,
				...V(e, o.id, o.at)
			}), o.at = -1, o.controller = -1, Ce(e));
			break;
		case "hate":
			a && Ne(e, [n.target], r);
			break;
		case "benten":
			a && K(e, A("pushDestination", r, 1, i, [n.target], "benten"));
			break;
		case "pushDestination":
			a && (t.card === "earthDragon" && K(e, A("earthDragon", r, 1, i, t.ids.slice(1))), Y(e, e.pieces[t.ids[0]], n.target));
			break;
		case "mercy":
			n.kind === "yes" ? H(e, r, 2 * M(e, r, "mercy")) : (Pe(e, t.ids, r), t.aux > 0 && H(e, r, t.aux * t.ids.length));
			break;
		case "ashigaru":
			a && (t.n > 1 && K(e, A("ashigaru", r, t.n - 1)), K(e, A("ashigaruSummon", r, 2, n.target)));
			break;
		case "ashigaruSummon":
			a && (t.n > 1 && K(e, A("ashigaruSummon", r, t.n - 1, i)), Y(e, o, n.at, !0));
			break;
		case "keiri":
			a && (t.n > 1 && K(e, A("keiri", r, t.n - 1)), Ne(e, [n.target], r, !1, !1, 3));
			break;
		case "fox":
			if (a) {
				let i = e.pieces.find((e) => e.owner === r && e.kind === "bushi" && e.at === -1 && e.captive < 0);
				K(e, A("fox", r, 0, -1, [...t.ids, n.target])), Y(e, i, n.target);
			}
			break;
		case "sand":
		case "hostage":
			a && (Fe(e, r, n.target), t.n > 1 && K(e, A(t.kind, r, t.n - 1, i)));
			break;
		case "daikaiju":
			if (a) {
				let i = e.pieces[t.ids[0]];
				Y(e, i, n.target);
				for (let t of e.pieces.filter((e) => ge(e) && P(e) !== r && e.at === n.target)) t.kind === "fort" && (B(e, "return", P(t), {
					piece: t.id,
					at: t.at,
					kind: t.kind,
					...V(e, t.id, t.at)
				}), t.at = -1);
				z(e, "destroyForts", r, 1, n.target);
			}
			break;
		case "nureOnna":
			a && Y(e, e.pieces[t.ids[0]], i);
			break;
		case "earthDragon":
			a && K(e, A("pushDestination", r, 1, i, [
				n.target,
				...t.ids,
				P(o)
			], "earthDragon"));
			break;
		case "jorogumo":
			a && (o.controller = r, z(e, "control", r, 1, i, o.owner), B(e, "control", r, { piece: o.id }));
			break;
		case "fireDragon":
			Ne(e, [n.target], r, P(o) === r);
			break;
		case "seppuku":
			a && Ne(e, e.pieces.filter((e) => P(e) === r && e.at === i && L(e)).map((e) => e.id), r, !0, !0);
			break;
		case "ronin":
			a && (e.battle.ronin = r);
			break;
		case "poets":
			a && (H(e, r, t.n), z(e, "poets", r, t.n, i));
			break;
		case "remainder": U(e, n.target, 1, !1), t.n > 1 && K(e, A("remainder", r, t.n - 1, -1, [...t.ids, n.target]));
	}
}
function tt(e) {
	let t = re.map((e, t) => t).filter((t) => !e.players.some((e) => e.clan === t) && (e.config.daimyo || t !== 5) && (e.config.dynasty || t !== 1 && t !== 7));
	J(e, A("draft", e.draft), t.map((e) => j("clan", e)));
}
function nt(e, t, n) {
	let r = O.parse(e), i = {
		config: r,
		players: t.map((e) => ({
			rid: e,
			clan: -1,
			coins: 0,
			ronin: 0,
			vp: 0,
			ally: -1,
			cards: [],
			tokens: [],
			alliedSeasons: 0,
			committed: !1,
			final: []
		})),
		pieces: [],
		honor: t.map((e, t) => t),
		turnOrder: t.map((e, t) => t),
		season: 0,
		phase: "draft",
		selector: -1,
		selectorCursor: 0,
		mandates: [],
		mandate: -1,
		mandateCount: 0,
		market: [],
		shrines: [],
		kami: [],
		wars: [],
		warIndex: 0,
		battle: null,
		prompt: null,
		tasks: [],
		seed: n,
		cursor: 0,
		revision: 0,
		log: [],
		fx: [],
		draft: 0,
		tea: 0,
		teaDone: [],
		movements: [],
		taxes: [],
		summonLeft: 0,
		buildLeft: 0,
		harvested: t.map(() => [])
	};
	return i.shrines = r.shrines === "beginner" ? [
		0,
		1,
		2,
		3
	] : ye(i, [
		0,
		1,
		2,
		3,
		4,
		5,
		6
	]).slice(0, 4), i.kami = i.shrines.map((e) => ({
		god: e,
		at: -1,
		owner: -1
	})), tt(i), {
		state: i,
		fx: []
	};
}
function rt(e, t) {
	return t < 0 || e.phase === "done" ? [] : e.prompt ? e.prompt.seat === t ? e.prompt.choices.map((e, t) => ({
		type: "choose",
		index: t
	})) : [] : e.tasks.length ? [] : e.phase === "politics" && e.selector === t ? e.mandates.slice(0, 4).flatMap((n, r) => N(e, t, "lotus") ? [
		0,
		1,
		2,
		3,
		4
	].map((e) => ({
		type: "mandate",
		index: r,
		declare: e
	})) : [{
		type: "mandate",
		index: r,
		declare: n
	}]) : e.phase === "war" && e.battle?.step === 0 && e.battle.participants.includes(t) && !e.players[t].committed ? [{
		type: "bid",
		coins: [
			0,
			0,
			0,
			0
		]
	}] : [];
}
function it(e, t, n) {
	let r = e.players.findIndex((e) => e.rid === n.by), i = { code: "games.risingsun.errAction" };
	if (e.phase === "done") return i;
	if (t.type === "tick") {
		if (n.by !== "$engine" || e.prompt || !e.tasks.length) return i;
	} else if (t.type === "gift") {
		if (!["tea", "politics"].includes(e.phase) || r < 0 || t.seat === r || !e.players[t.seat] || t.coins + t.ronin === 0 || t.coins > e.players[r].coins || t.ronin > e.players[r].ronin) return i;
	} else if (t.type === "bid") {
		if (r < 0 || e.tasks.length || e.prompt || e.phase !== "war" || e.battle?.step !== 0 || !e.battle.participants.includes(r) || e.players[r].committed || t.coins.reduce((e, t) => e + t, 0) > e.players[r].coins) return i;
	} else if (!rt(e, r).some((e) => JSON.stringify(e) === JSON.stringify(t))) return i;
	let a = structuredClone(e);
	if (a.fx = [], a.revision++, t.type === "tick") {
		let e = a.tasks.shift();
		e.kind === "ashigaruSummon" ? J(a, e, Le(a, e.seat, [e.at], ["bushi"], !1), !0) : e.kind === "serpent" ? J(a, e, [j("yes")], !0) : $e(a, e);
	} else if (t.type === "gift") U(a, r, -t.coins, !1), U(a, t.seat, t.coins, !1), a.players[r].ronin -= t.ronin, a.players[t.seat].ronin += t.ronin, z(a, "gift", r, t.coins, -1, t.seat, String(t.ronin));
	else if (t.type === "choose") {
		let e = a.prompt;
		a.prompt = null, et(a, e.task, e.choices[t.index]);
	} else t.type === "mandate" ? (a.mandates.splice(t.index, 1), Ge(a, t.declare)) : (a.battle.sealed[r] = [...t.coins], a.players[r].committed = !0, a.battle.participants.every((e) => a.players[e].committed) && K(a, A("reveal")));
	return {
		state: a,
		fx: a.fx
	};
}
function at(e, t) {
	let n = e.players.findIndex((e) => e.rid === t), r = e.prompt ? {
		kind: e.prompt.kind,
		seat: e.prompt.seat,
		n: e.prompt.n,
		at: e.prompt.at,
		card: e.prompt.card,
		choices: e.prompt.choices,
		...e.prompt.pending ? { pending: e.prompt.pending } : {}
	} : null, i = e.battle ? {
		province: e.battle.province,
		participants: [...e.battle.participants],
		bids: e.battle.bids.map((e) => [...e]),
		step: e.battle.step,
		dead: e.battle.dead,
		winner: e.battle.winner,
		force: e.battle.step >= 4 ? [...e.battle.force] : e.players.map((t, n) => G(e, n, e.battle.province))
	} : null;
	return {
		public: {
			config: e.config,
			players: e.players,
			pieces: e.pieces,
			honor: e.honor,
			turnOrder: e.turnOrder,
			season: e.season,
			phase: e.phase,
			active: e.prompt?.seat ?? (e.tasks.length ? -1 : e.selector),
			selector: e.selector,
			mandates: [],
			mandate: e.mandate,
			mandateCount: e.mandateCount,
			market: e.market,
			shrines: e.shrines,
			kami: e.config.unbound ? e.kami : [],
			wars: e.wars,
			warIndex: e.warIndex,
			battle: i,
			prompt: r,
			resolving: !!e.tasks.length && !e.prompt,
			revision: e.revision,
			log: e.log
		},
		private: {
			mandates: n === e.selector && e.phase === "politics" && !e.tasks.length && !e.prompt ? e.mandates.slice(0, 4) : [],
			bid: n >= 0 ? e.battle?.sealed[n] ?? [] : [],
			legal: rt(e, n)
		}
	};
}
function ot(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.turnOrder].sort((t, n) => e.players[n].vp - e.players[t].vp || R(e, t) - R(e, n)), n = t[0], r = e.players[n].ally, i = [n];
	return r >= 0 && e.players[r].vp === e.players[n].vp && i.push(r), {
		phase: "done",
		winner: i.map((t) => e.players[t].rid),
		ranking: t.map((t) => e.players[t].rid),
		scores: Object.fromEntries(e.players.map((e) => [e.rid, e.vp]))
	};
}
var st = {
	meta: ce,
	saveCompatibility: { version: "1" },
	schemas: {
		action: le,
		publicView: fe,
		privateView: pe,
		config: O
	},
	setup: nt,
	reduce: it,
	viewFor: at,
	status: ot,
	nextTickIn: (e) => e.tasks.length && !e.prompt ? 850 : null
}, ct = {
	komainu: [
		"狛犬",
		"Komainu",
		"视为神官。",
		"Counts as a Shinto."
	],
	oniSkulls: [
		"骷髅鬼",
		"Oni of Skulls",
		"本省荣誉最低时为3战力。",
		"Has 3 Force while you have the lowest Honor here."
	],
	lion: [
		"狮之道",
		"Path of the Lion",
		"大名的战力增加1。",
		"Your Daimyo gains 1 Force."
	],
	righteousness: [
		"正义",
		"Righteousness",
		"每个己方棋子被杀时获得1胜利点，包括切腹。",
		"Gain 1 VP whenever one of your figures is killed, including Seppuku."
	],
	shogun: [
		"将军之道",
		"Way of the Shogun",
		"每季战争开始时获得3枚钱币。",
		"Gain 3 Coins at the start of each War Phase."
	],
	serpent: [
		"蛇之道",
		"Path of the Serpent",
		"可以向使用每条不同航线的其他玩家收取1枚钱币，同批棋子不重复收费。",
		"You may charge another player 1 Coin per different Shipping Route used, not per figure."
	],
	respect: [
		"尊重",
		"Respect",
		"获得人质优势时可额外夺取1名人质。",
		"You may take one extra hostage when winning Take Hostage."
	],
	bushido: [
		"武士道",
		"Way of the Bushido",
		"战争开始时，每种不同的己方美德获得2枚钱币和2胜利点。",
		"At War start, gain 2 Coins and 2 VP per different Virtue you own."
	],
	ronin: [
		"浪人之道",
		"Way of the Ronin",
		"战争开始时获得2枚浪人。",
		"Gain 2 Ronin at War start."
	],
	yurei: [
		"幽灵",
		"Yurei",
		"视为大名，战力为2。",
		"Counts as a Daimyo with 2 Force."
	],
	kitsuneForm: [
		"狐之形",
		"Form of the Kitsune",
		"终局时，每座己方城获得3胜利点。",
		"At game end, gain 3 VP per friendly Stronghold."
	],
	phoenixForm: [
		"凤之形",
		"Form of the Phoenix",
		"终局时，每种不同的己方美德获得3胜利点。",
		"At game end, gain 3 VP per different Virtue you own."
	],
	dragon: [
		"龙之道",
		"Path of the Dragon",
		"大名的战力增加3。",
		"Your Daimyo gains 3 Force."
	],
	riverDragon: [
		"河龙",
		"River Dragon",
		"战力为5。",
		"Has 5 Force."
	],
	moneylender: [
		"放债人之道",
		"Way of the Moneylender",
		"战争开始时获得5枚钱币。",
		"Gain 5 Coins at War start."
	],
	benevolence: [
		"仁慈",
		"Benevolence",
		"花钱时可将其中1枚已花钱币送给其他玩家，获得1格荣誉和2胜利点。",
		"When spending Coins, you may give one spent Coin to another player to gain 1 Honor and 2 VP."
	],
	kenin: [
		"家臣之道",
		"Path of the Kenin",
		"召唤后，可在己方城额外放置1名武士。放置不触发召唤效果。",
		"After summoning, you may place an extra Bushi at a Stronghold. Placement does not trigger Summon effects."
	],
	light: [
		"光明之道",
		"Path of the Light",
		"征募政令末，可向神社额外派出1名神官。",
		"At the end of Recruit, you may send an extra Shinto to a Shrine."
	],
	justice: [
		"公正",
		"Justice",
		"每次杀死荣誉更低玩家的至少1个棋子时，获得3胜利点。",
		"Gain 3 VP for each lower-Honor player whose figure you kill in one killing effect."
	],
	oniBlood: [
		"血鬼",
		"Oni of Blood",
		"通常2战力，本省荣誉最低时4战力。",
		"Has 2 Force, or 4 while you have the lowest Honor here."
	],
	oniSouls: [
		"魂鬼",
		"Oni of Souls",
		"携带此怪赢得本省战省时，每只己方鬼获得2胜利点。",
		"When you win this War Province with this Monster here, gain 2 VP per Oni you own."
	],
	samurai: [
		"武士之道",
		"Path of the Samurai",
		"征募政令末，可在任意省额外召唤1名武士。",
		"At the end of Recruit, you may summon an extra Bushi to any Province."
	],
	beastForm: [
		"兽之形",
		"Form of the Beast",
		"终局时，每只己方怪物获得3胜利点。",
		"At game end, gain 3 VP per Monster you own."
	],
	oniHate: [
		"憎恨鬼",
		"Oni of Hate",
		"因任何原因进入省时，从每名荣誉更高玩家处杀死当地1名武士或神官。",
		"Whenever it enters a Province, kill one local Bushi or Shinto belonging to each higher-Honor player."
	],
	oniSpite: [
		"怨恨鬼",
		"Oni of Spite",
		"因任何原因进入省时，从每名当地有战力且荣誉更高的玩家处窃取2胜利点。",
		"Whenever it enters a Province, steal 2 VP from each higher-Honor player with Force here."
	],
	katana: [
		"刀之道",
		"Way of the Katana",
		"战争阶段中，己方所有武士为2战力。",
		"Your Bushi have 2 Force during War."
	],
	honesty: [
		"诚实",
		"Honesty",
		"有盟友且自己选择非背叛政令时，获得2胜利点。",
		"Gain 2 VP when you select a non-Betray Mandate while allied."
	],
	patron: [
		"赞助人之道",
		"Path of the Patron",
		"召唤后，若荣誉高于至少两名玩家，获得2枚钱币。",
		"After summoning, gain 2 Coins if your Honor is higher than at least two players."
	],
	warlord: [
		"军阀之道",
		"Path of the Warlord",
		"召唤后获得1枚钱币。",
		"Gain 1 Coin after summoning."
	],
	loyalty: [
		"忠诚",
		"Loyalty",
		"有盟友时，每次获得至少1胜利点额外获得1胜利点。",
		"While allied, gain 1 additional VP whenever you gain one or more VP."
	],
	merchant: [
		"商人之道",
		"Way of the Merchant",
		"更富有的玩家从公共区获得钱币时，自己获得1枚钱币。",
		"Gain 1 Coin when a richer player gains Coins from the common supply."
	],
	kindredForm: [
		"亲族之形",
		"Form of the Kindred",
		"终局时，每个曾有盟友的季节获得3胜利点。",
		"At game end, gain 3 VP per Season in which you had an ally."
	],
	unrighteous: [
		"不义之道",
		"Path of the Unrighteous",
		"背叛时可额外替换1名任意敌方武士或神官，包括敬神中的神官。大名免疫。",
		"Betray may replace one extra opposing Bushi or Shinto, including a worshipper. Daimyo remain immune."
	],
	courage: [
		"勇气",
		"Courage",
		"每次赢得战省时获得2胜利点。",
		"Gain 2 VP whenever you win a War Province."
	],
	ninja: [
		"忍者之道",
		"Path of the Ninja",
		"召唤后，可杀死地图上任意1名武士并降低1格荣誉。",
		"After summoning, you may kill a Bushi anywhere on the map and lose 1 Honor."
	],
	righteous: [
		"义人之道",
		"Way of the Righteous",
		"战争开始时，从每名荣誉更低的玩家处获得1枚钱币。",
		"At War start, take 1 Coin from each lower-Honor player."
	],
	mercy: [
		"怜悯",
		"Mercy",
		"将杀死至少1个敌方棋子时，可以让本次全部敌方棋子存活并获得2胜利点。",
		"Instead of killing enemy figures in one effect, you may spare them all and gain 2 VP."
	],
	monkey: [
		"猴之道",
		"Path of the Monkey",
		"召唤后，可从最富有的对手处获得1枚钱币并降低1格荣誉；并列者各付1枚。",
		"After summoning, you may take 1 Coin from every richest opponent and lose 1 Honor."
	],
	demonForm: [
		"鬼之形",
		"Form of the Demon",
		"终局时，每只己方鬼获得3胜利点。",
		"At game end, gain 3 VP per Oni you own."
	],
	spirit: [
		"灵之道",
		"Path of the Spirit",
		"召唤后，若荣誉最高，获得2枚钱币和2胜利点。",
		"After summoning, gain 2 Coins and 2 VP if you have the highest Honor."
	],
	dignity: [
		"尊严",
		"Dignity",
		"每次召唤怪物时获得2胜利点。",
		"Gain 2 VP whenever you summon a Monster."
	],
	pacifist: [
		"和平者之道",
		"Path of the Pacifist",
		"夏季和秋季开始时，若战省数量不是最多，获得4胜利点。",
		"At Summer and Autumn start, gain 4 VP if you do not have the most War Province tokens."
	],
	salamander: [
		"蝾螈之道",
		"Path of the Salamander",
		"夏季和秋季开始时，获得3枚钱币并降低1格荣誉。",
		"At Summer and Autumn start, gain 3 Coins and lose 1 Honor."
	],
	patience: [
		"耐心",
		"Patience",
		"每次神回合结束时，若胜利点不是最多，获得1胜利点。",
		"After each Kami Turn, gain 1 VP if you do not have the most VP."
	],
	ashigaru: [
		"足轻之道",
		"Way of the Ashigaru",
		"战争开始时，可选择恰有己方1个棋子的省召唤2名武士。",
		"At War start, you may summon two Bushi to a Province with exactly one friendly figure."
	],
	dragonForm: [
		"龙之形",
		"Form of the Dragon",
		"终局时，每枚己方战省获得1胜利点。",
		"At game end, gain 1 VP per War Province token."
	],
	snake: [
		"蛇道",
		"Way of the Snake",
		"每次神回合结束后，可执行背叛政令。",
		"After each Kami Turn, you may perform a Betray Mandate."
	],
	builder: [
		"筑城者之道",
		"Path of the Builder",
		"任何玩家选择行军政令时，自己可支付费用建1座城。",
		"When any player selects Marshal, you may pay to build one Stronghold."
	],
	kannushi: [
		"神主之道",
		"Path of the Kannushi",
		"行军政令中，可将1名神官移到不同神社。",
		"During Marshal, you may move a Shinto to a different Shrine."
	],
	piety: [
		"虔诚",
		"Piety",
		"有己方神官的省赢得战省时，获得1格荣誉和3胜利点。",
		"When you win a War Province containing your Shinto, gain 1 Honor and 3 VP."
	],
	sengoku: [
		"战国之道",
		"Path of the Sengoku",
		"任何丰收政令末，若大名本省奖励尚未获得，则获得该奖励。",
		"At the end of any Harvest, receive your Daimyo’s Province reward if you have not received it yet."
	],
	favored: [
		"宠眷之道",
		"Path of the Favored",
		"本省荣誉最高时，己方神官为3战力。",
		"Your Shinto have 3 Force while you have the highest Honor here."
	],
	sincerity: [
		"真诚",
		"Sincerity",
		"每次夺取人质时，额外获得1格荣誉和1胜利点。",
		"Whenever you take a hostage, gain 1 Honor and 1 additional VP."
	],
	tanukiForm: [
		"狸之形",
		"Form of the Tanuki",
		"终局时，每种己方季节卡类型获得2胜利点。",
		"At game end, gain 2 VP per different Season card type you own."
	],
	keiri: [
		"刑吏之道",
		"Way of the Keiri",
		"战争开始时，可杀死大名本省最多2名敌方武士或神官，每名获得3胜利点。",
		"At War start, you may kill up to two enemy Bushi or Shinto in your Daimyo’s Province, gaining 3 VP each."
	],
	jinmenju: [
		"人面树",
		"Jinmenju",
		"征募中可额外在本省召唤1个棋子并降低1格荣誉。",
		"During Recruit, you may summon one extra figure here and lose 1 Honor."
	],
	jorogumo: [
		"络新妇",
		"Jorogumo",
		"本省战斗开始时，可临时控制1名敌方武士或神官。",
		"At battle start here, you may temporarily control one enemy Bushi or Shinto."
	],
	fireDragon: [
		"火龙",
		"Fire Dragon",
		"3战力。本省战斗开始时，各方含自己必须杀死另1个当地棋子。",
		"3 Force. At battle start here, every player, including you, kills one other local figure."
	],
	oniPlagues: [
		"瘟疫鬼",
		"Oni of Plagues",
		"荣誉更高的玩家不能将棋子移入本省。",
		"Higher-Honor players cannot move figures into this Province."
	],
	earthDragon: [
		"地龙",
		"Earth Dragon",
		"3战力。本省战斗开始时，可将每名对手的1个棋子移出本省。",
		"3 Force. At battle start here, you may move one figure per opponent out of this Province."
	],
	kotahi: [
		"小太刀",
		"Kotahi",
		"丰收时，若本省己方战力最高，总能获得奖励。",
		"During Harvest, receive this Province’s reward if you have the most Force, regardless of the selector."
	],
	phoenix: [
		"凤凰",
		"Phoenix",
		"死亡时获得1胜利点，并立即回到原省。",
		"When killed, gain 1 VP and immediately return it to the same Province."
	],
	jikininki: [
		"食人鬼",
		"Jikininki",
		"本省每死另1个棋子时，获得1胜利点并降低1格荣誉。",
		"Whenever another figure dies here, gain 1 VP and lose 1 Honor."
	],
	koneko: [
		"小猫",
		"Koneko",
		"死亡时获得2枚钱币和2枚浪人，本省其他玩家各失去2枚钱币和2枚浪人。",
		"When killed, gain 2 Coins and 2 Ronin; other players here each lose 2 Coins and 2 Ronin."
	],
	nureOnna: [
		"濡女",
		"Nure-Onna",
		"2战力。战省结算前，可沿一条航线移动来参战。",
		"2 Force. Before a War Province resolves, you may move here along one Shipping Route."
	],
	sunakake: [
		"撒砂婆",
		"Sunakake-baba",
		"战争开始时，可从本省夺取1名武士或神官为人质。",
		"At War start, you may take a Bushi or Shinto here as a hostage."
	],
	daikaiju: [
		"大怪兽",
		"Daikaiju",
		"5战力。召唤到海中；战争开始时在任意省登陆，并摧毁该省所有敌城。",
		"5 Force. Summoned into the sea; at War start, land anywhere and destroy all opposing Strongholds there."
	],
	kitsune: [
		"狐",
		"Kitsune",
		"赢得本省战省的玩家获得6胜利点。",
		"Whoever wins this War Province gains 6 VP."
	],
	sacredWarrior: [
		"神圣武士",
		"Sacred Warrior",
		"每张己方美德为其增加1战力。",
		"Gains 1 Force per Virtue card you own."
	],
	daikokuten: [
		"大黑天",
		"Daikokuten",
		"丰收时为8战力。仅日、月氏族可购买。",
		"Has 8 Force during Harvest. Only Sun and Moon may buy it."
	],
	fukurokuju: [
		"福禄寿",
		"Fukurokuju",
		"同时视为大名和城。仅日、月氏族可购买。",
		"Counts as both a Daimyo and a Stronghold. Only Sun and Moon may buy it."
	],
	jurojin: [
		"寿老人",
		"Jurojin",
		"同时视为美德，购买其他美德后获得3枚钱币。仅日、月氏族可购买。",
		"Also counts as a Virtue. Gain 3 Coins after buying another Virtue. Only Sun and Moon may buy it."
	],
	bishamon: [
		"毗沙门天",
		"Bishamon",
		"本省有敌方怪物时为4战力。仅日、月氏族可购买。",
		"Has 4 Force when an opposing Monster is here. Only Sun and Moon may buy it."
	],
	hotei: [
		"布袋",
		"Hotei",
		"视为神官，送去敬神时可替换任意神官。仅日、月氏族可购买。",
		"Counts as a Shinto. When sent to worship, may replace another Shinto. Only Sun and Moon may buy it."
	],
	benten: [
		"辩才天",
		"Benten",
		"因任何原因进入省时，可迫使1只敌方怪物移出。仅日、月氏族可购买。",
		"Whenever it enters a Province, you may force one opposing Monster to leave. Only Sun and Moon may buy it."
	],
	ebisu: [
		"惠比寿",
		"Ebisu",
		"死亡时获得8枚钱币。仅日、月氏族可购买。",
		"Gain 8 Coins when killed. Only Sun and Moon may buy it."
	]
}, lt = Object.fromEntries(Object.entries(ct).map(([e, [t, , n]]) => [e, {
	name: t,
	effect: n
}])), ut = Object.fromEntries(Object.entries(ct).map(([e, [, t, , n]]) => [e, {
	name: t,
	effect: n
}])), dt = {
	name: "旭日战魂录",
	desc: "结盟、敬神、征战日本诸省，以荣誉与谋略争夺霸权。",
	rules: "目标：\n春、夏、秋三季后总胜利点最高者获胜；同分以荣誉决定，末季盟友同分第一时共同获胜。\n能力时序：\n多项能力在同一时点发生冲突时，相关玩家中荣誉最高者选择自己的哪项能力先执行或后执行，再依当前荣誉处理其余能力。已经触发的能力即使来源棋子随后离场，仍在原触发位置结算；可选目标以执行时局面为准。\n氏族：\n选择不同氏族，按初始荣誉决定固定座次。每季获得氏族收入并归还人质；每名人质为俘虏者带来1枚钱币。茶会可两两结盟，政令期间可赠送钱币和浪人。承诺不具约束力，战争期间禁止赠送。\n政令：\n当前选令者查看政令牌堆顶部的4张政令，选择其中1张执行，再将其余政令按原顺序放回。每季依次执行以下步骤：\n· 执行3张政令，然后进行一次敬神。\n· 再执行2张政令，然后进行一次敬神。\n· 再执行2张政令，然后进行最后一次敬神。\n· 进入战争阶段。\n· 征募：每座城可以召唤1个己方棋子，选令者及其盟友各可以额外召唤1个棋子；召唤神官时，可以将其派往神社。\n· 行军：每个棋子沿陆界或航线移动1步，选令者及盟友可支付3枚钱币在任意省份建造1座城堡。\n· 训练：每人购买1张当前季节卡，选令者及盟友支付的费用减少1枚钱币。\n· 丰收：所有人获得1枚钱币，选令者及盟友获得己方战力最高的各省奖励。\n· 背叛：仅选令者行动，解散联盟并降低1格荣誉，从两名不同对手各替换1个武士或神官。\n训练由选令者先行动，其他政令由选令者左侧开始，选令者最后。\n敬神：\n按神社顺序，战力最高者获得神的恩赐；平手以荣誉决定。神显形扩展中，获胜者再将对应神放入任意合法省，控制权始终取决于该神社当前最高战力。神不占用月氏族的普通棋子名额。\n战争：\n按本季战省顺序结算。无人占据则跳过，只有一方或两名盟友则最高战力直接获得战省。发生战斗时，各方秘密分配钱币争夺切腹、人质、浪人和诗人优势，全部提交后同时揭示。按切腹→人质→浪人→战斗胜负→诗人→赔款结算。每项出价全为0则无人获得，赢家可放弃。\n· 切腹：杀死本省所有己方棋子，每移除1枚棋子，获得1点胜利点并提升1格荣誉。\n· 人质：将本省的1个敌方棋子俘虏为人质，并从其所属玩家处夺取最多1点胜利点。不能俘虏大名。\n· 浪人：每枚增加1点战力，结算后不消耗。\n败者棋子被杀，胜者的盟友存活。\n· 诗人：获得本场死亡棋子数量的胜利点。\n胜者花费的钱币均分给败者，余数由胜者分配；败者所花钱币弃置。城不能被杀死、俘虏或背叛；神不能被杀死或受特殊效果影响。\n终局：\n春、夏、秋的战省分别提供1、2、3点胜利点。额外奖励按持有的不同战省种类数计算：\n· 3至4种：额外获得10分。\n· 5至6种：额外获得20分。\n· 7至8种：额外获得30分。\n然后结算冬季升级卡。每季结束时，弃置钱币与浪人，将敬神棋子收回预备区；地图上的其他棋子保留。\n氏族能力：\n· 锦鲤：在战争开始把浪人换为钱币，未花钱币可代替浪人。\n· 莲花：可将所选政令宣布为任意政令。\n· 龟：己方城具有1点战力，并且可以执行行军。\n· 蜻蜓：可以在任意省召唤棋子，也可以将棋子移动到任意省。\n· 盆栽：支付费用时，先将所需钱币数量降至最多1枚，再应用其他折扣。\n· 狐：在战争开始向每个己方没有战力的省放1个预备武士。\n· 日：赢得实际荣誉平手时获得1枚钱币和1点胜利点，并使并列对手各失去最多1枚钱币和1胜利点。\n· 月：棋子至少2点战力，但每省最多2个，所有神社合计最多2个。\n扩展：\n可选大名宝盒、怪物包、王朝入侵和神显形。王朝入侵允许6人并加入日、月氏族与七福神；日、月只能购买七福神，其他氏族不能购买七福神。每局仅使用一套季节牌。点击卡牌和神社可查看完整效果。",
	errAction: "此时不能执行该行动，请重新选择。",
	hintBid: "根据本省兵力和后续战省分配钱币。",
	hintMandate: "选择对本氏族最有利的政令。",
	hintChoice: "选择当前标出的合法目标。",
	clans: [
		"锦鲤",
		"日",
		"莲花",
		"龟",
		"蜻蜓",
		"狐",
		"盆栽",
		"月"
	],
	clanAbilities: [
		"战争开始把浪人换为钱币，未花钱币代替浪人。",
		"赢得荣誉平手时获得1枚钱币和1胜利点，并削减对手资源。",
		"可以将选出的政令宣布为任意政令。",
		"城有1战力，并可像棋子一样行军。",
		"可以在任意省召唤及移动。",
		"战争开始向每个己方无战力的省放1个武士。",
		"每次费用最多1枚钱币，再应用折扣。",
		"棋子至少2战力；每省及所有神社合计分别最多2个。"
	],
	provinces: [
		"九州",
		"四国",
		"长门",
		"关西",
		"京都",
		"江户",
		"奥州",
		"北海道"
	],
	mandates: [
		"征募",
		"行军",
		"训练",
		"丰收",
		"背叛"
	],
	seasons: [
		"春",
		"夏",
		"秋",
		"冬"
	],
	gods: [
		"天照",
		"风神",
		"八幡",
		"月读",
		"雷神",
		"龙神",
		"须佐之男"
	],
	godShrines: [
		"荣誉升至第一。",
		"最多移动2步，可移动同一棋子两次。",
		"获得2枚浪人。",
		"获得2枚钱币。",
		"在任意省召唤1个预备武士。",
		"以全价购买1张当前季节卡。",
		"每座己方城获得1胜利点。"
	],
	godPowers: [
		"本省荣誉最高氏族的棋子不能被其他玩家杀死。",
		"丰收奖励翻倍，战省赢家另获得本省原值丰收奖励。",
		"本省浪人每枚2战力。",
		"战争结算本省前，每名有战力的玩家获得4枚钱币。",
		"本省除武士和神外的棋子不计算战力。",
		"战力等于控制者拥有的不同季节卡类型数量。",
		"除神以外的所有棋子不能移出本省。"
	],
	phase: {
		draft: "选择氏族",
		tea: "茶会",
		politics: "政治",
		kami: "敬神",
		war: "战争",
		cleanup: "季末",
		winter: "冬季计分",
		done: "天下已定"
	},
	resolveFirst: "先执行",
	resolveLast: "后执行",
	pendingAbilities: "同时触发的能力",
	prompts: {
		timing: "选择一项能力先执行或后执行",
		draft: "选择你的氏族",
		tea: "向一名玩家提议结盟",
		alliance: "是否接受联盟提议？",
		recruit: "从预备区选择棋子并选择召唤位置",
		light: "可向神社额外派出1名神官",
		samurai: "可在任意省额外召唤1名武士",
		raijin: "可在任意省召唤1名武士",
		jinmenju: "可额外召唤1个棋子并降低1格荣誉",
		kenin: "可在己方城额外放置1名武士",
		monsterSummon: "将怪物召唤到己方城",
		marshal: "选择棋子，再选择行军目标",
		build: "可建造1座城",
		kannushi: "可将1名神官移往另一神社",
		train: "选择一张季节卡购买",
		ryujin: "可以全价购买一张季节卡",
		betray: "选择一名对手的武士或神官进行替换",
		unrighteous: "可额外替换敌方武士或神官，包括敬神中的神官",
		manifest: "选择神的显形位置",
		fujin: "可移动1步",
		snake: "是否执行背叛政令？",
		benevolence: "可将已支付的1枚钱币送给对手，提升1格荣誉并获得2胜利点",
		serpent: "是否向跨越航线的玩家收取1枚钱币？",
		monkey: "是否从最富有的对手处各取1枚钱币并降低1格荣誉？",
		ninja: "可杀死1名地图上的武士并降低1格荣誉",
		hotei: "可将1名正在敬神的神官送回预备区",
		hate: "选择本省荣誉较高对手的武士或神官杀死",
		benten: "可迫使本省一个敌方怪物离开",
		pushDestination: "选择移出后的省",
		mercy: "是否让本次所有敌方棋子存活，获得胜利点？",
		ashigaru: "可选择恰有己方1个棋子的省召唤2名武士",
		fox: "可向己方没有战力的省部署1名武士",
		ashigaruSummon: "召唤武士",
		keiri: "可杀死大名本省的敌方武士或神官，每个获得3胜利点",
		sand: "可从本省夺取1名人质",
		hostage: "可夺取1名人质",
		daikaiju: "选择大怪兽的登陆省",
		nureOnna: "是否沿航线前来参战？",
		earthDragon: "可将每名对手的1个棋子移出本省",
		jorogumo: "可临时控制本省1名敌方武士或神官",
		fireDragon: "为当前氏族选择本省1个棋子杀死（大名免疫）",
		seppuku: "是否让本省所有己方棋子切腹？",
		ronin: "是否使用浪人增加本场战力？",
		poets: "是否获得本场死亡棋子数量的胜利点？",
		remainder: "选择一名败者获得余下的钱币"
	},
	pieces: {
		daimyo: "大名",
		shinto: "神官",
		bushi: "武士",
		fort: "城"
	},
	resource: {
		coins: "钱币",
		ronin: "浪人",
		vp: "胜利点",
		honor: "荣誉",
		force: "战力"
	},
	turn: "当前行动",
	waiting: "等待其他玩家行动",
	resolving: "正在结算",
	chooseMandate: "选择政令",
	lotusDeclare: "宣布政令",
	yourBid: "秘密出价",
	bidLabels: [
		"切腹",
		"人质",
		"浪人",
		"诗人"
	],
	bid: "提交出价",
	committed: "已提交",
	available: "可用钱币",
	unspent: "保留",
	confirm: "确认选择",
	pass: "跳过",
	yes: "执行",
	no: "放弃",
	close: "关闭",
	cancel: "取消",
	back: "返回",
	reserve: "预备区",
	shrine: "神社",
	market: "季节卡",
	ownedCards: "氏族卡牌",
	wars: "本季战省",
	log: "行动记录",
	details: "详情",
	gift: "赠送资源",
	give: "确认赠送",
	target: "目标玩家",
	review: "回看版图",
	result: "冬之书",
	showResult: "查看结算",
	totals: "总分",
	scoreRows: [
		"战前得分",
		"战省",
		"战省种类",
		"冬季卡牌",
		"荣誉决胜"
	],
	again: "再来一局",
	lobby: "返回大厅",
	waitHost: "等待主机开始下一局",
	ally: "盟友",
	noAlly: "尚未结盟",
	cost: "费用",
	choosePiece: "选择棋子",
	selectProvince: "选择省",
	selected: "已选中",
	treasury: "氏族资源",
	cardTypes: {
		enhancement: "强化",
		virtue: "美德",
		monster: "怪物",
		war: "战争升级",
		winter: "冬季升级"
	},
	options: {
		set: "季节牌组",
		sets: [
			"鸟居",
			"茶壶",
			"骑士",
			"舟",
			"山"
		],
		expansions: "官方扩展",
		daimyo: "大名宝盒",
		monster: "怪物包",
		dynasty: "王朝入侵",
		unbound: "神显形",
		shrines: "神社",
		beginner: "新手组合",
		random: "随机组合",
		six: "王朝入侵允许6人游戏，加入日、月氏族与七福神。"
	},
	events: {
		timing: "决定能力顺序",
		season: "季节开始",
		mandate: "选择政令",
		alliance: "结成联盟",
		betray: "解散联盟",
		summon: "召唤棋子",
		move: "移动棋子",
		buy: "购入卡牌",
		build: "建造城",
		harvest: "获得丰收奖励",
		kami: "获得神的恩赐",
		manifest: "神显形",
		honor: "提升荣誉",
		sun: "以荣誉赢得平手",
		killed: "棋子阵亡",
		hostage: "夺取人质",
		replace: "替换棋子",
		gift: "赠送资源",
		warProvince: "结算战省",
		reveal: "揭示出价",
		win: "获得战省",
		battle: "赢得战斗",
		poets: "吟咏亡者",
		winter: "获得冬季分数",
		control: "临时控制棋子",
		destroyForts: "摧毁敌城"
	},
	cards: lt
}, ft = {
	name: "Rising Sun",
	desc: "Forge alliances, worship the Kami, and wage war for dominion over Japan.",
	rules: "OBJECTIVE: Play Spring, Summer and Autumn, then score Winter. Highest VP wins, with Honor breaking ties. Allied players tied for first may share victory.\nABILITY TIMING: If simultaneous abilities conflict, the involved player with the highest Honor chooses one of their abilities to resolve first or last. Repeat for the remaining abilities using current Honor. A triggered ability remains pending at its original location even if its source figure later leaves; targets are checked when it resolves.\nSEASONS: Receive Clan income and return hostages; captors gain 1 Coin per returned hostage. Negotiate pairs of alliances at the Tea Ceremony. Coins and Ronin can be gifted during Tea and Politics, but never during War. Promises are not binding.\nMANDATES: The selector takes one of the top four tiles and returns the rest in order. Each Season follows this sequence:\n· Resolve 3 Mandates, then a Kami phase.\n· Resolve 2 more Mandates, then another Kami phase.\n· Resolve the final 2 Mandates, then the final Kami phase.\n· Proceed to War.\n· Recruit summons one figure per Stronghold plus one for the selector and ally; Shinto may instead be sent to Shrines when summoned.\n· Marshal moves each figure one adjacent Province by land or Shipping Route; the selector and ally may build one Stronghold anywhere for 3 Coins.\n· Train lets each player buy one current Season card, with a 1 Coin discount for the selector and ally.\n· Harvest gives everyone 1 Coin; the selector and ally also receive rewards for Provinces where they have the most Force.\n· Betray lets only the selector replace one Bushi or Shinto from each of two different opponents, ending their alliance and losing one Honor if allied.\nTrain starts with the selector; other Mandates end with the selector.\nKAMI: Resolve Shrines in order. Highest Force gains the Shrine ability; Honor breaks ties. With Kami Unbound, that player then places the Kami in a legal Province. Its controller always follows the current top worshipper. Kami do not use Moon’s ordinary-figure capacity.\nWAR: Resolve numbered War Provinces in order. No Force means no winner. One player, or only two allies, awards the token to the highest Force. Otherwise all participants secretly allocate Coins to Seppuku, Take Hostage, Hire Ronin and Imperial Poets. Reveal together, then resolve Seppuku → Hostages → Ronin → Battle → Poets → Reparations. All-zero bids award no advantage; winners may decline. Seppuku kills all your local figures for 1 VP and 1 Honor each. The Take Hostage winner may capture one opposing figure in the Province and steal up to 1 VP from its owner. A Daimyo cannot be taken hostage. Ronin add 1 Force each without being spent. Defeated figures die, except the winner’s ally. Poets score 1 VP per figure killed in the Battle. The winner’s spent Coins are divided among all losers; the winner assigns remainder Coins to distinct losers. Losers discard their bids. Strongholds cannot be killed, taken hostage or betrayed. Kami cannot die or suffer special effects.\nWINTER: Spring, Summer and Autumn tokens score 1, 2 and 3 VP. Holding 3–4 / 5–6 / 7–8 distinct Provinces adds 10 / 20 / 30 VP. Resolve Winter Upgrades. Seasonal cleanup discards Coins and Ronin, returns worshippers to reserve and leaves map figures in place.\nCLANS:\n· Koi converts Ronin into Coins at War start and uses unspent Coins as Ronin.\n· Lotus may declare any Mandate.\n· Turtle Strongholds have 1 Force and can move.\n· Dragonfly summons and moves to any Province.\n· Bonsai caps costs at 1 Coin before discounts.\n· Fox places a reserve Bushi in each Province with no friendly Force at War start.\n· Sun gains 1 Coin and 1 VP when winning a real Honor tie, while tied rivals each lose up to 1 Coin and 1 VP.\n· Moon figures have at least 2 Force, but at most two may occupy a Province or all Shrines combined.\nEXPANSIONS: Daimyo Box, Monster Pack, Dynasty Invasion and Kami Unbound are optional. Dynasty Invasion enables six players and Sun/Moon with Lucky Gods. Sun/Moon can only buy Lucky Gods as Monsters; other Clans cannot buy Lucky Gods. Choose one Season-card set per game. Inspect cards and Shrines for complete effects.",
	errAction: "That action is not available now. Please choose again.",
	hintBid: "Allocate Coins according to this battle and later War Provinces.",
	hintMandate: "Choose the Mandate that best serves your Clan.",
	hintChoice: "Choose one of the marked legal targets.",
	clans: [
		"Koi",
		"Sun",
		"Lotus",
		"Turtle",
		"Dragonfly",
		"Fox",
		"Bonsai",
		"Moon"
	],
	clanAbilities: [
		"Convert Ronin into Coins at War start; unspent Coins act as Ronin.",
		"Win an Honor tie to gain 1 Coin and 1 VP and drain tied rivals.",
		"Declare any Mandate when selecting a tile.",
		"Strongholds have 1 Force and can move.",
		"Summon and move to any Province.",
		"At War start, place a Bushi in each Province with no friendly Force.",
		"Cap each cost at 1 Coin before discounts.",
		"Figures have at least 2 Force; max two per Province and all Shrines combined."
	],
	provinces: [
		"Kyushu",
		"Shikoku",
		"Nagato",
		"Kansai",
		"Kyoto",
		"Edo",
		"Oshu",
		"Hokkaido"
	],
	mandates: [
		"Recruit",
		"Marshal",
		"Train",
		"Harvest",
		"Betray"
	],
	seasons: [
		"Spring",
		"Summer",
		"Autumn",
		"Winter"
	],
	gods: [
		"Amaterasu",
		"Fujin",
		"Hachiman",
		"Tsukuyomi",
		"Raijin",
		"Ryujin",
		"Susanoo"
	],
	godShrines: [
		"Move to the top of Honor.",
		"Move up to two steps, possibly the same figure twice.",
		"Gain 2 Ronin.",
		"Gain 2 Coins.",
		"Summon a reserve Bushi to any Province.",
		"Buy a current Season card at full price.",
		"Gain 1 VP per friendly Stronghold."
	],
	godPowers: [
		"The highest-Honor Clan here cannot be killed by other players.",
		"Double Harvest rewards; the War winner also receives the printed reward.",
		"Each hired Ronin adds 2 Force here.",
		"Before War resolves here, each player with Force gains 4 Coins.",
		"Only Bushi and Kami count their Force here.",
		"Force equals the controller’s number of different Season card types.",
		"No figure other than a Kami can move out of this Province."
	],
	phase: {
		draft: "Choose Clans",
		tea: "Tea Ceremony",
		politics: "Politics",
		kami: "Kami Turn",
		war: "War",
		cleanup: "Seasonal Cleanup",
		winter: "Winter Scoring",
		done: "Dominion Decided"
	},
	resolveFirst: "Resolve first",
	resolveLast: "Resolve last",
	pendingAbilities: "Simultaneous abilities",
	prompts: {
		timing: "Choose an ability to resolve first or last",
		draft: "Choose your Clan",
		tea: "Propose an alliance",
		alliance: "Accept this alliance?",
		recruit: "Choose a reserve figure and summoning location",
		light: "You may send an extra Shinto to a Shrine",
		samurai: "You may summon a Bushi anywhere",
		raijin: "You may summon a reserve Bushi anywhere",
		jinmenju: "You may summon an extra figure here and lose 1 Honor",
		kenin: "You may place an extra Bushi at a Stronghold",
		monsterSummon: "Summon your Monster at a Stronghold",
		marshal: "Choose a figure, then its destination",
		build: "You may build a Stronghold",
		kannushi: "You may move a Shinto to another Shrine",
		train: "Choose a Season card to buy",
		ryujin: "You may buy a Season card at full price",
		betray: "Replace an opposing Bushi or Shinto",
		unrighteous: "You may replace an extra opposing Bushi or Shinto, including worshippers",
		manifest: "Choose where this Kami manifests",
		fujin: "You may move one step",
		snake: "Perform a Betray Mandate?",
		benevolence: "Give an opponent 1 spent Coin to gain 1 Honor and 2 VP",
		serpent: "Charge 1 Coin for using this Shipping Route?",
		monkey: "Take 1 Coin from each richest opponent and lose 1 Honor?",
		ninja: "You may kill a Bushi on the map and lose 1 Honor",
		hotei: "You may return another worshipping Shinto to reserve",
		hate: "Choose a higher-Honor opponent’s Bushi or Shinto here to kill",
		benten: "You may force an opposing Monster to leave",
		pushDestination: "Choose the destination Province",
		mercy: "Spare all enemy figures from this killing and gain VP?",
		ashigaru: "Choose a Province with exactly one friendly figure to summon two Bushi",
		fox: "You may place a Bushi in a Province with no friendly Force",
		ashigaruSummon: "Summon a Bushi",
		keiri: "You may kill opposing Bushi or Shinto in your Daimyo’s Province for 3 VP each",
		sand: "You may take a hostage here",
		hostage: "You may take a hostage",
		daikaiju: "Choose Daikaiju’s landing Province",
		nureOnna: "Move along the Shipping Route to join this battle?",
		earthDragon: "You may move one figure per opponent out of this Province",
		jorogumo: "You may temporarily control an opposing Bushi or Shinto here",
		fireDragon: "Choose one figure of this Clan here to kill (Daimyo are immune)",
		seppuku: "Commit all your local figures to Seppuku?",
		ronin: "Add your Ronin to this battle?",
		poets: "Claim VP for all figures killed in this battle?",
		remainder: "Choose a defeated Clan to receive a remainder Coin"
	},
	pieces: {
		daimyo: "Daimyo",
		shinto: "Shinto",
		bushi: "Bushi",
		fort: "Stronghold"
	},
	resource: {
		coins: "Coins",
		ronin: "Ronin",
		vp: "VP",
		honor: "Honor",
		force: "Force"
	},
	turn: "Acting",
	waiting: "Waiting for another player",
	resolving: "Resolving",
	chooseMandate: "Choose a Mandate",
	lotusDeclare: "Declare Mandate",
	yourBid: "Secret Bid",
	bidLabels: [
		"Seppuku",
		"Hostage",
		"Ronin",
		"Poets"
	],
	bid: "Seal bid",
	committed: "Submitted",
	available: "Available Coins",
	unspent: "Retained",
	confirm: "Confirm",
	pass: "Pass",
	yes: "Proceed",
	no: "Decline",
	close: "Close",
	cancel: "Cancel",
	back: "Back",
	reserve: "Reserve",
	shrine: "Shrine",
	market: "Season Cards",
	ownedCards: "Clan Cards",
	wars: "War Provinces",
	log: "Chronicle",
	details: "Details",
	gift: "Give Resources",
	give: "Confirm gift",
	target: "Recipient",
	review: "View final map",
	result: "Book of Winter",
	showResult: "Show results",
	totals: "Total",
	scoreRows: [
		"Before Winter",
		"War Tokens",
		"Province Sets",
		"Winter Cards",
		"Honor Resolution"
	],
	again: "Play again",
	lobby: "Back to lobby",
	waitHost: "Waiting for the host",
	ally: "Ally",
	noAlly: "Unallied",
	cost: "Cost",
	choosePiece: "Choose a figure",
	selectProvince: "Choose a Province",
	selected: "Selected",
	treasury: "Clan Resources",
	cardTypes: {
		enhancement: "Enhancement",
		virtue: "Virtue",
		monster: "Monster",
		war: "War Upgrade",
		winter: "Winter Upgrade"
	},
	options: {
		set: "Season-card Set",
		sets: [
			"Archway",
			"Kettle",
			"Horseman",
			"Boat",
			"Mountain"
		],
		expansions: "Official Expansions",
		daimyo: "Daimyo Box",
		monster: "Monster Pack",
		dynasty: "Dynasty Invasion",
		unbound: "Kami Unbound",
		shrines: "Shrines",
		beginner: "Beginner set",
		random: "Random set",
		six: "Dynasty Invasion enables six players, Sun/Moon and Lucky Gods."
	},
	events: {
		timing: "Chose ability order",
		season: "Season begins",
		mandate: "Selected a Mandate",
		alliance: "Formed an alliance",
		betray: "Ended an alliance",
		summon: "Summoned a figure",
		move: "Moved a figure",
		buy: "Acquired a card",
		build: "Built a Stronghold",
		harvest: "Received Harvest rewards",
		kami: "Received a Shrine blessing",
		manifest: "Manifested a Kami",
		honor: "Gained Honor",
		sun: "Won an Honor tie",
		killed: "Figure killed",
		hostage: "Took a hostage",
		replace: "Replaced a figure",
		gift: "Gave resources",
		warProvince: "Resolving War Province",
		reveal: "Revealed bids",
		win: "Claimed a War Province",
		battle: "Won the battle",
		poets: "Honored the fallen",
		winter: "Scored Winter VP",
		control: "Temporarily controlled a figure",
		destroyForts: "Destroyed opposing Strongholds"
	},
	cards: ut
}, pt = (e) => f(`games/risingsun/${e}.svg`);
function X() {
	return p((e) => e.locale) === "zh" ? dt : ft;
}
function mt({ kind: e, n: t }) {
	let n = X();
	return /* @__PURE__ */ g("span", {
		className: "rs-resource",
		"aria-label": `${n.resource[e]} ${t}`,
		children: [/* @__PURE__ */ h("img", {
			src: pt(e === "ronin" ? "resource-ronin" : e),
			alt: ""
		}), /* @__PURE__ */ h("b", { children: t })]
	});
}
function ht({ clan: e, size: t = 40 }) {
	return e < 0 ? /* @__PURE__ */ h("span", {
		className: "rs-seal-empty",
		style: {
			width: t,
			height: t
		}
	}) : /* @__PURE__ */ h("img", {
		className: "rs-seal",
		width: t,
		height: t,
		src: pt(`clan-${e}`),
		alt: ""
	});
}
function gt({ god: e }) {
	let t = X();
	return /* @__PURE__ */ g("span", {
		className: "rs-kami-figure",
		children: [/* @__PURE__ */ h("img", {
			src: pt(`kami-${e}`),
			alt: ""
		}), /* @__PURE__ */ h("small", { children: t.gods[e] })]
	});
}
function _t() {
	let e = d();
	return /* @__PURE__ */ h("svg", {
		className: "rs-eligible-frame",
		"aria-hidden": !0,
		children: /* @__PURE__ */ h("rect", {
			x: "2",
			y: "2",
			width: "calc(100% - 4px)",
			height: "calc(100% - 4px)",
			rx: "4",
			fill: "none",
			stroke: "#a5372f",
			strokeWidth: "2",
			strokeDasharray: "8 5",
			children: !e && /* @__PURE__ */ h("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-26",
				dur: ".8s",
				repeatCount: "indefinite"
			})
		})
	});
}
function vt({ kind: e, clan: t, small: n = !1 }) {
	let r = X(), i = E[e]?.kind === "monster";
	return /* @__PURE__ */ g("span", {
		className: `rs-figure${n ? " is-small" : ""}${i ? " is-monster" : ""}`,
		style: { "--rs-clan": S[t] ?? "#76674e" },
		children: [
			/* @__PURE__ */ h("img", {
				src: pt(e),
				alt: ""
			}),
			/* @__PURE__ */ h("img", {
				className: "rs-figure-badge",
				src: pt(`clan-${t}`),
				alt: ""
			}),
			/* @__PURE__ */ h("span", {
				className: "rs-sr",
				children: r.pieces[e] ?? r.cards[e]?.name ?? e
			})
		]
	});
}
function yt({ id: e, eligible: t = !1, selected: n = !1, onClick: r, compact: i = !1, anchor: a = !0 }) {
	let o = X(), c = E[e], { ref: l, hidden: u } = s(a ? `card:${e}` : null);
	return /* @__PURE__ */ g("button", {
		ref: a ? l : void 0,
		style: a && u ? { visibility: "hidden" } : void 0,
		type: "button",
		className: `rs-card${i ? " is-compact" : ""}${t ? " is-eligible" : ""}${n ? " is-selected" : ""}`,
		"data-season": c.season,
		onClick: r,
		children: [
			/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ h("strong", { children: o.cards[e]?.name ?? e }), /* @__PURE__ */ h(mt, {
				kind: "coins",
				n: c.cost
			})] }),
			/* @__PURE__ */ h("img", {
				className: "rs-card-art",
				src: pt(e),
				alt: ""
			}),
			/* @__PURE__ */ h("span", {
				className: "rs-card-type",
				children: o.cardTypes[c.kind]
			}),
			/* @__PURE__ */ h("p", { children: o.cards[e]?.effect }),
			t && /* @__PURE__ */ h(_t, {})
		]
	});
}
//#endregion
//#region src/games/risingsun/layout.ts
var bt = [
	{
		x: 160,
		y: 1140,
		w: 360,
		h: 430
	},
	{
		x: 520,
		y: 1430,
		w: 460,
		h: 250
	},
	{
		x: 700,
		y: 1010,
		w: 430,
		h: 220
	},
	{
		x: 1190,
		y: 1160,
		w: 300,
		h: 370
	},
	{
		x: 1580,
		y: 1010,
		w: 290,
		h: 390
	},
	{
		x: 1950,
		y: 1230,
		w: 280,
		h: 360
	},
	{
		x: 2110,
		y: 720,
		w: 320,
		h: 370
	},
	{
		x: 2440,
		y: 130,
		w: 330,
		h: 340
	}
], xt = [
	0,
	1,
	2,
	3
].map((e) => ({
	x: 270 + e * 330,
	y: 55,
	w: 275,
	h: 215
}));
function St(e) {
	if (e >= 8) {
		let t = xt[e - 8];
		return {
			x: t.x + 10,
			y: t.y + 130,
			w: t.w - 20,
			h: t.h - 138
		};
	}
	let t = bt[e];
	return {
		...t,
		y: t.y + 10,
		h: t.h - 20
	};
}
function Ct(e, t, n) {
	let r = St(e), i = Math.max(1, Math.ceil(Math.sqrt(t * r.w / r.h))), a = Math.ceil(t / i), o = r.w / i, s = r.h / Math.max(1, a), c = Math.min(105, o * .88, s * .88);
	return {
		x: r.x + (n % i + .5) * o - c / 2,
		y: r.y + (Math.floor(n / i) + .5) * s - c / 2,
		w: c,
		h: c
	};
}
//#endregion
//#region src/games/risingsun/board.tsx
function wt({ pub: e, id: t, at: n, count: r, index: i }) {
	let { ref: a, hidden: o } = s(`piece:${t}`), c = Ct(n, r, i), l = e.pieces[t], u = t >= 1e3 ? e.kami.find((e) => e.god === t - 1e3) : void 0, d = u?.owner ?? (l.controller >= 0 ? l.controller : l.owner);
	return /* @__PURE__ */ h("g", { children: /* @__PURE__ */ h("foreignObject", {
		x: c.x,
		y: c.y,
		width: c.w,
		height: c.h,
		pointerEvents: "none",
		style: { visibility: o ? "hidden" : void 0 },
		children: /* @__PURE__ */ h("div", {
			ref: a,
			className: "rs-board-figure",
			children: u ? /* @__PURE__ */ h(gt, { god: u.god }) : /* @__PURE__ */ h(vt, {
				kind: l.kind,
				clan: e.players[d].clan
			})
		})
	}) });
}
function Tt({ pub: e, at: t }) {
	let n = [...e.pieces.filter((e) => e.at === t).map((e) => e.id), ...e.kami.filter((e) => e.at === t).map((e) => 1e3 + e.god)];
	return /* @__PURE__ */ h(ee, { children: n.map((r, i) => /* @__PURE__ */ h(wt, {
		pub: e,
		id: r,
		at: t,
		count: n.length,
		index: i
	}, r)) });
}
function Et({ r: e }) {
	let t = d();
	return /* @__PURE__ */ h("rect", {
		x: e.x,
		y: e.y,
		width: e.w,
		height: e.h,
		rx: 18,
		fill: "#fff4ce",
		fillOpacity: ".14",
		stroke: "#a6342e",
		strokeWidth: 12,
		strokeDasharray: "28 16",
		pointerEvents: "none",
		children: !t && /* @__PURE__ */ h("animate", {
			attributeName: "stroke-dashoffset",
			from: "0",
			to: "-44",
			dur: "0.85s",
			repeatCount: "indefinite"
		})
	});
}
function Dt({ pub: e, targets: t, onProvince: n, onShrine: r, fitKey: i }) {
	let { ref: a } = s("board"), o = X(), c = [...xt.map((e, t) => ({
		key: `s${t}`,
		rect: e
	})), ...bt.map((e, t) => ({
		key: `p${t}`,
		rect: {
			x: e.x,
			y: e.y - 60,
			w: e.w,
			h: e.h + 60
		}
	}))];
	return /* @__PURE__ */ h("div", {
		ref: a,
		className: "rs-board",
		children: /* @__PURE__ */ g(u, {
			image: pt("map"),
			sheetW: 3e3,
			sheetH: 2e3,
			eligible: c,
			onTapEligible: (e) => e.startsWith("s") ? r(Number(e.slice(1))) : n(Number(e.slice(1))),
			fitKey: i,
			highlight: "off",
			clampToSheet: !0,
			children: [e.shrines.map((n, r) => {
				let i = xt[r];
				return /* @__PURE__ */ g("g", { children: [
					/* @__PURE__ */ h("rect", {
						x: i.x,
						y: i.y,
						width: i.w,
						height: i.h,
						fill: "#f4ecd8",
						stroke: "#564f3c",
						strokeWidth: 6
					}),
					/* @__PURE__ */ h("text", {
						x: i.x + i.w / 2,
						y: i.y + 75,
						textAnchor: "middle",
						fontSize: 45,
						fontWeight: 700,
						fill: "#312e25",
						children: o.gods[n]
					}),
					/* @__PURE__ */ h("text", {
						x: i.x + i.w / 2,
						y: i.y + 122,
						textAnchor: "middle",
						fontSize: 26,
						fill: "#655a45",
						children: o.shrine
					}),
					/* @__PURE__ */ h(Tt, {
						pub: e,
						at: r + 8
					}),
					t.includes(r + 8) && /* @__PURE__ */ h(Et, { r: i }),
					/* @__PURE__ */ h(l, {
						name: `place:${r + 8}`,
						r: St(r + 8)
					})
				] }, n);
			}), bt.map((n, r) => {
				let i = e.wars.indexOf(r), a = e.phase === "war" && e.wars[e.warIndex] === r;
				return /* @__PURE__ */ g("g", { children: [
					/* @__PURE__ */ h("rect", {
						x: n.x - 8,
						y: n.y - 60,
						width: n.w + 16,
						height: 64,
						rx: 5,
						fill: a ? "#a73630" : "#eee5c8",
						stroke: "#625942",
						strokeWidth: 4
					}),
					/* @__PURE__ */ h("text", {
						x: n.x + n.w / 2,
						y: n.y - 15,
						textAnchor: "middle",
						fontSize: 40,
						fontWeight: 700,
						fill: a ? "#fff0d7" : "#302c24",
						children: o.provinces[r]
					}),
					i >= 0 && /* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("circle", {
						cx: n.x + n.w,
						cy: n.y - 58,
						r: 25,
						fill: i < e.warIndex && e.phase === "war" ? "#6e7669" : "#a73630"
					}), /* @__PURE__ */ h("text", {
						x: n.x + n.w,
						y: n.y - 49,
						textAnchor: "middle",
						fontSize: 28,
						fill: "white",
						children: i + 1
					})] }),
					/* @__PURE__ */ h(Tt, {
						pub: e,
						at: r
					}),
					t.includes(r) && /* @__PURE__ */ h(Et, { r: n }),
					/* @__PURE__ */ h(l, {
						name: `place:${r}`,
						r: St(r)
					})
				] }, r);
			})]
		})
	});
}
//#endregion
//#region src/games/risingsun/view-player.tsx
function Ot({ seat: e, pub: t, name: n, onClick: r }) {
	let i = X(), a = t.players[e], { ref: o } = s(`seat:${a.rid}`);
	return /* @__PURE__ */ g("button", {
		ref: o,
		className: `rs-player${t.active === e ? " is-active" : ""}`,
		style: { "--rs-clan": S[a.clan] },
		onClick: r,
		children: [
			/* @__PURE__ */ h(ht, { clan: a.clan }),
			/* @__PURE__ */ g("span", {
				className: "rs-player-name",
				children: [/* @__PURE__ */ h("strong", { children: n }), /* @__PURE__ */ g("small", { children: [
					a.clan < 0 ? "—" : i.clans[a.clan],
					" ",
					/* @__PURE__ */ h("b", { children: t.honor.indexOf(e) + 1 })
				] })]
			}),
			/* @__PURE__ */ g("span", {
				className: "rs-player-resources",
				children: [
					/* @__PURE__ */ h(mt, {
						kind: "vp",
						n: a.vp
					}),
					/* @__PURE__ */ h(mt, {
						kind: "coins",
						n: a.coins
					}),
					/* @__PURE__ */ h(mt, {
						kind: "ronin",
						n: a.ronin
					})
				]
			}),
			a.committed && t.battle?.step === 0 && !t.battle.bids.length && /* @__PURE__ */ h("span", {
				className: "rs-committed",
				children: i.committed
			})
		]
	});
}
function kt({ rid: e, kind: t, clan: n, count: r, selected: i, legal: a, onClick: o }) {
	let c = X(), { ref: l } = s(`reserve:${e}:${t}`);
	return /* @__PURE__ */ g("button", {
		ref: l,
		className: `rs-reserve-piece${i ? " is-selected" : ""}${a ? " is-eligible" : ""}`,
		onClick: o,
		disabled: !a,
		children: [
			a && /* @__PURE__ */ h(_t, {}),
			/* @__PURE__ */ h(vt, {
				kind: t,
				clan: n
			}),
			/* @__PURE__ */ g("span", { children: [c.pieces[t] ?? c.cards[t]?.name, /* @__PURE__ */ h("b", { children: r })] })
		]
	});
}
function At(e) {
	return /* @__PURE__ */ h(jt, {
		...e,
		pub: e.public,
		priv: e.private
	});
}
function jt({ pub: e, priv: t, members: n, myRid: r, send: s, readOnly: l = !1 }) {
	c();
	let u = X(), d = e.players.findIndex((e) => e.rid === r), f = e.players[d], p = l ? [] : t?.legal ?? [], m = e.prompt, _ = m?.seat === d && p[0]?.type === "choose", [v, y] = i(-1), [b, te] = i(-1), [ne, re] = i(""), [x, ie] = i(-1), [S, ae] = i(-1), [C, oe] = i(-1), [w, T] = i(""), [E, se] = i(0), [ce, D] = i(0), [O, le] = i([
		0,
		0,
		0,
		0
	]), [k, ue] = i({
		seat: 0,
		coins: 0,
		ronin: 0
	}), de = `${e.revision}:${r}`, [fe, pe] = i(de);
	de !== fe && (pe(de), te(-1), y(-1), le([
		0,
		0,
		0,
		0
	]));
	let A = (t) => n.find((n) => n.rid === e.players[t]?.rid)?.name ?? e.players[t]?.rid ?? "—", j = (e) => u.pieces[e] ?? u.cards[e]?.name ?? e, me = (e) => e.startsWith("clan:") ? u.clans[e === "clan:koi" ? 0 : 5] : e.startsWith("god:") ? u.gods[Number(e.slice(4))] : j(e), M = (t) => {
		if (t.kind === "timing") return `${me(t.ability)} · ${t.value === 1 ? u.resolveFirst : u.resolveLast}${t.at >= 0 && t.at < 8 ? ` · ${u.provinces[t.at]}` : ""}`;
		if (t.kind === "pass") return u.pass;
		if (t.kind === "yes") return u.yes;
		if (t.kind === "no") return u.no;
		if (t.kind === "clan") return u.clans[t.target];
		if (t.kind === "seat") return A(t.target);
		if (t.kind === "province") return u.provinces[t.target];
		if (t.kind === "card") return u.cards[e.market[t.target]]?.name;
		let n = e.pieces[t.target];
		return `${n ? j(n.kind) : u.gods[t.target - 1e3]}${t.at >= 0 ? ` · ${t.at >= 8 ? u.gods[e.shrines[t.at - 8]] : u.provinces[t.at]}` : ""}`;
	}, N = _ ? m.choices[b] : void 0, P = _ ? [...new Set(m.choices.flatMap((t) => t.kind === "province" ? [t.target] : [
		"summon",
		"move",
		"kamiMove"
	].includes(t.kind) && t.target === v ? [t.at] : v < 0 && ["piece", "move"].includes(t.kind) ? [e.pieces[t.target].at] : v < 0 && t.kind === "kamiMove" ? [e.kami.find((e) => 1e3 + e.god === t.target).at] : []))] : [], F = f ? e.pieces.filter((e) => e.owner === d && e.at === -1 && e.captive < 0 && e.kind !== "fort") : [], he = [...new Set(F.map((e) => e.kind))], ge = (e) => F.find((t) => t.kind === e), I = (e) => {
		te(e), re(""), ie(-1), ae(-1);
	}, L = (e) => {
		let t = _ ? m.choices.map((e, t) => ({
			c: e,
			i: t
		})).filter(({ c: t }) => t.kind === "province" && t.target === e || [
			"summon",
			"move",
			"kamiMove"
		].includes(t.kind) && t.at === e && t.target === v) : [];
		t.length === 1 ? I(t[0].i) : ie(e);
	}, R = (e) => {
		let t = _ ? m.choices.map((e, t) => ({
			c: e,
			j: t
		})).filter(({ c: t }) => t.at === e + 8 && t.target === v && ["summon", "move"].includes(t.kind)) : [];
		t.length === 1 ? I(t[0].j) : ae(e);
	}, _e = (e) => {
		if (!_) return;
		let t = m.choices.findIndex((t) => t.kind === "piece" && t.target === e);
		t >= 0 ? I(t) : m.choices.some((t) => [
			"move",
			"kamiMove",
			"summon"
		].includes(t.kind) && t.target === e) && (y(e), te(-1), ie(-1), ae(-1));
	}, ve = () => {
		b >= 0 && _ && (s({
			type: "choose",
			index: b
		}), te(-1));
	}, ye = p[0]?.type === "bid", z = p[0]?.type === "mandate", B = O.reduce((e, t) => e + t, 0), V = _ ? m.choices.findIndex((e) => e.kind === "pass") : -1, H = _ && m.choices.every((e) => [
		"yes",
		"no",
		"pass",
		"seat",
		"timing"
	].includes(e.kind)), U = !!ne || x >= 0 || S >= 0 || C >= 0 || !!w, W = l ? u.phase.done : _ ? u.prompts[m.kind] ?? u.turn : z ? u.chooseMandate : ye ? u.yourBid : e.resolving ? u.resolving : u.waiting;
	return /* @__PURE__ */ g("div", {
		className: "rs-shell",
		children: [
			/* @__PURE__ */ h("div", {
				className: "rs-main",
				inert: U,
				children: /* @__PURE__ */ h(a, {
					adaptive: !0,
					className: "rs-screen",
					scroll: !1,
					actionsHeight: l ? "rs-review-height" : "rs-actions-height",
					banner: /* @__PURE__ */ g("header", {
						className: "rs-header",
						children: [/* @__PURE__ */ g("div", {
							className: "rs-heading",
							children: [/* @__PURE__ */ g("span", {
								className: "rs-season",
								children: [u.seasons[l ? 3 : e.season], !l && /* @__PURE__ */ g("small", { children: [e.mandateCount, " / 7"] })]
							}), /* @__PURE__ */ h("div", { children: /* @__PURE__ */ g("h1", { children: [u.phase[e.phase], e.mandate >= 0 && e.phase === "politics" && /* @__PURE__ */ h("em", { children: u.mandates[e.mandate] })] }) })]
						}), /* @__PURE__ */ h("div", {
							className: "rs-players",
							children: e.honor.map((t) => /* @__PURE__ */ h(Ot, {
								seat: t,
								pub: e,
								name: A(t),
								onClick: () => oe(t)
							}, t))
						})]
					}),
					actions: /* @__PURE__ */ g("footer", {
						className: "rs-actions",
						children: [!l && /* @__PURE__ */ h("div", {
							className: "rs-selection",
							"aria-live": "polite",
							children: N ? M(N) : v >= 1e3 ? u.gods[v - 1e3] : v >= 0 ? j(e.pieces[v].kind) : W
						}), /* @__PURE__ */ g("div", {
							className: "rs-action-row",
							children: [/* @__PURE__ */ g("div", {
								className: "rs-tools",
								children: [
									/* @__PURE__ */ h("button", {
										onClick: () => T("market"),
										children: u.market
									}),
									/* @__PURE__ */ h("button", {
										onClick: () => T("log"),
										children: u.log
									}),
									!l && f && ["tea", "politics"].includes(e.phase) && /* @__PURE__ */ h("button", {
										onClick: () => {
											ue({
												seat: +(d === 0),
												coins: 0,
												ronin: 0
											}), T("gift");
										},
										children: u.gift
									}),
									/* @__PURE__ */ h("button", {
										onClick: () => {
											se(E + 1), te(-1), y(-1);
										},
										children: u.cancel
									})
								]
							}), !l && /* @__PURE__ */ g("div", {
								className: "rs-submit",
								children: [/* @__PURE__ */ h("button", {
									disabled: V < 0,
									onClick: () => s({
										type: "choose",
										index: V
									}),
									children: u.pass
								}), /* @__PURE__ */ h("button", {
									className: "rs-primary",
									disabled: !N,
									onClick: ve,
									children: u.confirm
								})]
							})]
						})]
					}),
					children: /* @__PURE__ */ g("div", {
						className: "rs-table",
						children: [/* @__PURE__ */ g("section", {
							className: "rs-map-column",
							children: [/* @__PURE__ */ h(Dt, {
								pub: e,
								targets: P,
								onProvince: L,
								onShrine: R,
								fitKey: `${r}:${E}`
							}), /* @__PURE__ */ h("div", {
								className: "rs-war-track",
								"aria-label": u.wars,
								children: e.wars.map((t, n) => /* @__PURE__ */ g("button", {
									className: e.phase === "war" && n === e.warIndex ? "is-current" : "",
									onClick: () => ie(t),
									children: [/* @__PURE__ */ h("b", { children: n + 1 }), u.provinces[t]]
								}, t))
							})]
						}), /* @__PURE__ */ g("aside", {
							className: "rs-side",
							children: [/* @__PURE__ */ g("div", {
								className: "rs-workspace",
								children: [e.phase === "draft" && _ ? /* @__PURE__ */ h("div", {
									className: "rs-clan-draft",
									children: m.choices.map((e, t) => /* @__PURE__ */ g("button", {
										className: b === t ? "is-selected" : "",
										onClick: () => I(t),
										children: [
											/* @__PURE__ */ h(ht, {
												clan: e.target,
												size: 64
											}),
											/* @__PURE__ */ h("strong", { children: u.clans[e.target] }),
											/* @__PURE__ */ h("p", { children: u.clanAbilities[e.target] })
										]
									}, e.target))
								}) : z ? /* @__PURE__ */ g("div", {
									className: "rs-mandates",
									children: [
										/* @__PURE__ */ h("h2", { children: u.chooseMandate }),
										/* @__PURE__ */ h("div", { children: t.mandates.map((e, t) => /* @__PURE__ */ g("button", {
											className: "rs-mandate-card",
											onClick: () => s({
												type: "mandate",
												index: t,
												declare: f.clan === 2 ? ce : e
											}),
											children: [/* @__PURE__ */ h("span", { children: t + 1 }), /* @__PURE__ */ h("strong", { children: u.mandates[e] })]
										}, t)) }),
										f.clan === 2 && /* @__PURE__ */ g("label", { children: [u.lotusDeclare, /* @__PURE__ */ h("select", {
											value: ce,
											onChange: (e) => D(Number(e.target.value)),
											children: u.mandates.map((e, t) => /* @__PURE__ */ h("option", {
												value: t,
												children: e
											}, e))
										})] })
									]
								}) : ye ? /* @__PURE__ */ g("section", {
									className: "rs-bidding",
									children: [
										/* @__PURE__ */ g("h2", { children: [u.yourBid, /* @__PURE__ */ h(mt, {
											kind: "coins",
											n: f.coins
										})] }),
										/* @__PURE__ */ h("div", { children: O.map((e, t) => /* @__PURE__ */ g("label", { children: [u.bidLabels[t], /* @__PURE__ */ h("input", {
											"aria-label": u.bidLabels[t],
											type: "number",
											min: 0,
											max: f.coins - B + e,
											value: e,
											onChange: (n) => {
												let r = [...O];
												r[t] = Math.max(0, Math.min(f.coins - B + e, Number(n.target.value) || 0)), le(r);
											}
										})] }, t)) }),
										/* @__PURE__ */ g("span", { children: [
											u.unspent,
											": ",
											f.coins - B
										] }),
										/* @__PURE__ */ h("button", {
											className: "rs-primary",
											onClick: () => s({
												type: "bid",
												coins: O
											}),
											children: u.bid
										})
									]
								}) : H ? /* @__PURE__ */ g("div", {
									className: "rs-negotiation",
									children: [
										/* @__PURE__ */ h("h2", { children: W }),
										m.kind === "alliance" && /* @__PURE__ */ h("p", { children: A(e.log.at(-1)?.seat ?? e.selector) }),
										m.pending && /* @__PURE__ */ h("ul", {
											className: "rs-pending",
											"aria-label": u.pendingAbilities,
											children: m.pending.map((e, t) => /* @__PURE__ */ g("li", { children: [
												/* @__PURE__ */ h("strong", { children: A(e.seat) }),
												" · ",
												me(e.ability),
												e.at >= 0 && e.at < 8 ? ` · ${u.provinces[e.at]}` : ""
											] }, t))
										}),
										/* @__PURE__ */ h("div", { children: m.choices.map((t, n) => /* @__PURE__ */ g("button", {
											className: b === n ? "is-selected" : "",
											onClick: () => I(n),
											children: [
												t.kind === "seat" && /* @__PURE__ */ h(ht, { clan: e.players[t.target].clan }),
												" ",
												M(t)
											]
										}, n)) })
									]
								}) : /* @__PURE__ */ g("section", {
									className: "rs-reserve",
									children: [/* @__PURE__ */ g("h2", { children: [u.reserve, f && /* @__PURE__ */ h("span", { children: u.clans[f.clan] })] }), /* @__PURE__ */ h("div", { children: he.map((e) => {
										let t = ge(e), n = !!_ && m.choices.some((e) => e.kind === "summon" && e.target === t.id);
										return /* @__PURE__ */ h(kt, {
											rid: f.rid,
											kind: e,
											clan: f.clan,
											count: F.filter((t) => t.kind === e).length,
											selected: v === t.id,
											legal: n,
											onClick: () => {
												y(t.id), te(-1);
											}
										}, e);
									}) })]
								}), e.battle && /* @__PURE__ */ g("div", {
									className: "rs-battle-summary",
									children: [/* @__PURE__ */ g("h2", { children: [
										u.provinces[e.battle.province],
										" · ",
										u.phase.war
									] }), /* @__PURE__ */ h("div", { children: e.battle.participants.map((t) => /* @__PURE__ */ g("span", { children: [
										/* @__PURE__ */ h(ht, {
											clan: e.players[t].clan,
											size: 28
										}),
										A(t),
										" ",
										/* @__PURE__ */ h("b", { children: e.battle.force[t] }),
										e.battle.bids[t] && /* @__PURE__ */ h("small", { children: e.battle.bids[t].join(" / ") })
									] }, t)) })]
								})]
							}), /* @__PURE__ */ g("div", {
								className: "rs-market",
								children: [/* @__PURE__ */ g("h2", { children: [u.market, /* @__PURE__ */ h("span", { children: u.seasons[e.season] })] }), /* @__PURE__ */ h("div", {
									className: "rs-market-cards",
									children: [...new Set(e.market)].map((t) => {
										let n = _ ? m.choices.findIndex((n) => n.kind === "card" && e.market[n.target] === t) : -1;
										return /* @__PURE__ */ h(yt, {
											id: t,
											eligible: n >= 0,
											selected: n >= 0 && b === n,
											compact: !0,
											onClick: () => re(t)
										}, t);
									})
								})]
							})]
						})]
					})
				})
			}),
			/* @__PURE__ */ h(o, {
				open: !!ne,
				label: u.details,
				onClose: () => re(""),
				footer: _ && ne && m.choices.some((t) => t.kind === "card" && e.market[t.target] === ne) ? /* @__PURE__ */ h("button", {
					className: "rs-primary rs-full",
					onClick: () => I(m.choices.findIndex((t) => t.kind === "card" && e.market[t.target] === ne)),
					children: u.confirm
				}) : void 0,
				children: /* @__PURE__ */ h("div", {
					className: "rs-detail-card",
					children: ne && /* @__PURE__ */ h(yt, {
						id: ne,
						anchor: !1
					})
				})
			}),
			/* @__PURE__ */ h(o, {
				open: x >= 0,
				label: x >= 0 ? u.provinces[x] : u.details,
				title: x >= 0 ? u.provinces[x] : "",
				onClose: () => ie(-1),
				children: /* @__PURE__ */ g("div", {
					className: "rs-province-detail",
					children: [e.pieces.filter((e) => e.at === x && x >= 0).map((t) => /* @__PURE__ */ g("button", {
						disabled: !_ || !m.choices.some((e) => e.target === t.id && ["move", "piece"].includes(e.kind)),
						onClick: () => _e(t.id),
						children: [/* @__PURE__ */ h(vt, {
							kind: t.kind,
							clan: e.players[t.controller >= 0 ? t.controller : t.owner].clan
						}), /* @__PURE__ */ g("span", { children: [j(t.kind), /* @__PURE__ */ h("small", { children: A(t.controller >= 0 ? t.controller : t.owner) })] })]
					}, t.id)), e.kami.filter((e) => e.at === x && x >= 0).map((e) => /* @__PURE__ */ g("button", {
						disabled: !_ || !m.choices.some((t) => t.kind === "kamiMove" && t.target === 1e3 + e.god),
						onClick: () => _e(1e3 + e.god),
						children: [
							u.gods[e.god],
							" · ",
							A(e.owner)
						]
					}, e.god))]
				})
			}),
			/* @__PURE__ */ h(o, {
				open: S >= 0,
				label: u.shrine,
				title: S >= 0 ? u.gods[e.shrines[S]] : "",
				onClose: () => ae(-1),
				children: /* @__PURE__ */ h("div", {
					className: "rs-shrine-detail",
					children: S >= 0 && /* @__PURE__ */ g(ee, { children: [
						/* @__PURE__ */ h("p", { children: u.godShrines[e.shrines[S]] }),
						e.config.unbound && /* @__PURE__ */ h("p", { children: u.godPowers[e.shrines[S]] }),
						/* @__PURE__ */ h("div", {
							className: "rs-province-detail",
							children: e.pieces.filter((e) => e.at === 8 + S && S >= 0).map((t) => /* @__PURE__ */ g("button", {
								disabled: !_ || !m.choices.some((e) => e.target === t.id && ["move", "piece"].includes(e.kind)),
								onClick: () => _e(t.id),
								children: [/* @__PURE__ */ h(vt, {
									kind: t.kind,
									clan: e.players[t.owner].clan
								}), A(t.owner)]
							}, t.id))
						})
					] })
				})
			}),
			/* @__PURE__ */ h(o, {
				open: C >= 0,
				label: u.treasury,
				title: C >= 0 ? A(C) : "",
				onClose: () => oe(-1),
				children: /* @__PURE__ */ h("div", {
					className: "rs-seat-detail",
					children: C >= 0 && /* @__PURE__ */ g(ee, { children: [
						/* @__PURE__ */ h(ht, {
							clan: e.players[C].clan,
							size: 84
						}),
						/* @__PURE__ */ h("h2", { children: u.clans[e.players[C].clan] }),
						/* @__PURE__ */ h("p", { children: u.clanAbilities[e.players[C].clan] }),
						/* @__PURE__ */ g("p", { children: [
							u.ally,
							": ",
							e.players[C].ally >= 0 ? A(e.players[C].ally) : u.noAlly
						] }),
						/* @__PURE__ */ h("div", {
							className: "rs-token-collection",
							children: e.players[C].tokens.map((e, t) => /* @__PURE__ */ g("span", { children: [u.provinces[e.province], /* @__PURE__ */ h("small", { children: u.seasons[e.season] })] }, t))
						}),
						/* @__PURE__ */ h("h3", { children: u.ownedCards }),
						/* @__PURE__ */ h("div", {
							className: "rs-owned-cards",
							children: e.players[C].cards.map((e, t) => /* @__PURE__ */ h(yt, {
								id: e,
								compact: !0,
								anchor: !1,
								onClick: () => {
									oe(-1), re(e);
								}
							}, t))
						})
					] })
				})
			}),
			/* @__PURE__ */ h(o, {
				open: !!w,
				label: w === "log" ? u.log : w === "gift" ? u.gift : u.market,
				onClose: () => T(""),
				children: /* @__PURE__ */ g("div", {
					className: "rs-panel",
					children: [
						w === "market" && /* @__PURE__ */ h("div", {
							className: "rs-owned-cards",
							children: [...new Set(e.market)].map((t) => /* @__PURE__ */ h(yt, {
								id: t,
								compact: !0,
								anchor: !1,
								eligible: !!_ && m.choices.some((n) => n.kind === "card" && e.market[n.target] === t),
								onClick: () => {
									T(""), re(t);
								}
							}, t))
						}),
						w === "log" && /* @__PURE__ */ h("ol", {
							className: "rs-log",
							children: e.log.map((e, t) => /* @__PURE__ */ g("li", { children: [
								/* @__PURE__ */ h("strong", { children: e.seat >= 0 ? A(e.seat) : "" }),
								" ",
								u.events[e.event] ?? e.event,
								e.event === "timing" ? ` · ${me(e.card)} · ${e.n === 1 ? u.resolveFirst : u.resolveLast}` : "",
								e.event === "mandate" ? ` · ${u.mandates[e.n]}` : "",
								e.event === "kami" || e.event === "manifest" ? ` · ${u.gods[e.n]}` : "",
								e.at >= 0 && e.at < 8 ? ` · ${u.provinces[e.at]}` : "",
								e.target >= 0 ? ` · ${A(e.target)}` : "",
								e.event !== "timing" && u.cards[e.card] ? ` · ${u.cards[e.card].name}` : ""
							] }, t))
						}),
						w === "gift" && f && /* @__PURE__ */ g("div", {
							className: "rs-gift",
							children: [
								/* @__PURE__ */ h("h2", { children: u.gift }),
								/* @__PURE__ */ g("label", { children: [u.target, /* @__PURE__ */ h("select", {
									value: k.seat,
									onChange: (e) => ue({
										...k,
										seat: Number(e.target.value)
									}),
									children: e.players.map((e, t) => t !== d && /* @__PURE__ */ h("option", {
										value: t,
										children: A(t)
									}, t))
								})] }),
								["coins", "ronin"].map((e) => /* @__PURE__ */ g("label", { children: [u.resource[e], /* @__PURE__ */ h("input", {
									type: "number",
									min: 0,
									max: f[e],
									value: k[e],
									onChange: (t) => ue({
										...k,
										[e]: Math.max(0, Math.min(f[e], Number(t.target.value) || 0))
									})
								})] }, e)),
								/* @__PURE__ */ h("button", {
									className: "rs-primary",
									disabled: k.coins + k.ronin === 0,
									onClick: () => {
										s({
											type: "gift",
											...k
										}), T("");
									},
									children: u.give
								})
							]
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/risingsun/bot.ts
var Mt = {
	diversity: 3,
	shrine: 2.3,
	develop: 1,
	conserve: .38
}, Nt = (e) => e.controller >= 0 ? e.controller : e.owner;
function Z(e, t, n) {
	let r = 0;
	for (let i of e.pieces.filter((e) => Nt(e) === t && e.at === n)) {
		if (i.kind === "fort") {
			e.players[t].clan === 3 && r++;
			continue;
		}
		let n = Math.max(e.players[t].clan === 7 ? 2 : 1, E[i.kind]?.force ?? 1);
		[
			"daimyo",
			"yurei",
			"fukurokuju"
		].includes(i.kind) && (n += e.players[t].cards.filter((e) => e === "lion").length + 3 * e.players[t].cards.filter((e) => e === "dragon").length), r += n;
	}
	return r += e.kami.filter((e) => e.owner === t && e.at === n).length, r;
}
function Pt(e, t, n, r) {
	let i = e.players.map((t, r) => Z(e, r, n)), a = i[t], o = Math.max(0, ...i.filter((n, r) => r !== t && r !== e.players[t].ally)), s = e.wars.slice(e.warIndex).includes(n), c = !e.players[t].tokens.some((e) => e.province === n), l = oe[n][0] * .3 + oe[n][1] * .25 + oe[n][2] * .6;
	return (s ? 2 + (c ? r.diversity : 0) + e.season : 0) + l + (o >= a ? -Math.max(0, o - a) * .6 : 1) - a * .6;
}
function Ft(e, t, n, r) {
	let i = 3 - e.season, a = E[n], o = e.players[t].cards, s = e.pieces.filter((e) => e.owner === t && e.kind !== "fort").length, c = 2;
	a.kind === "monster" && (c = 3 + a.force * 1.2), a.kind === "virtue" && (c = i * 3), n === "righteousness" && (c = i * 4), n === "kenin" && (c = i * 3.5), (n === "shogun" || n === "moneylender") && (c = i * (n === "shogun" ? 3 : 5) * .65), (n === "lion" || n === "dragon") && (c = n === "lion" ? 2 : 4), n === "bushido" && (c = i * new Set(o.filter((e) => E[e].kind === "virtue")).size * 3), n === "ronin" && (c = i * 2.2), n === "kitsuneForm" && (c = e.pieces.filter((e) => e.owner === t && e.kind === "fort" && e.at >= 0).length * 3), n === "phoenixForm" && (c = new Set(o.filter((e) => E[e].kind === "virtue")).size * 3), n === "beastForm" && (c = o.filter((e) => E[e].kind === "monster").length * 3), n === "kindredForm" && (c = e.players[t].alliedSeasons * 3), n === "demonForm" && (c = o.filter((e) => E[e].oni).length * 3), n === "dragonForm" && (c = e.players[t].tokens.length + 2), n === "tanukiForm" && (c = new Set(o.map((e) => E[e].kind)).size * 2), n === "katana" && (c = s * .6), n === "unrighteous" && (c = i * 2);
	let l = Math.max(0, (e.players[t].clan === 6 ? Math.min(1, a.cost) : a.cost) - +(e.mandate === 2 && (t === e.selector || e.players[t].ally === e.selector)));
	return c * r.develop - l * .9;
}
function It(e, t, n, r) {
	let i = e.prompt, a = e.pieces[n.target], o = e.pieces.filter((n) => Nt(n) === t && n.at === e.battle?.province && n.kind !== "fort").length;
	if (n.kind === "timing") {
		let r = n.ability, i = n.value === 1, a = e.players[t];
		return r === "clan:koi" ? i ? -3 : 4 : r === "ronin" && a.clan === 0 ? i ? 5 : -3 : r === "spirit" || r === "patron" ? i ? 4 : -1 : r === "monkey" || r === "ninja" ? i ? -1 : 2 : r === "jorogumo" || r === "earthDragon" ? i ? 5 : 0 : r === "merchant" ? i ? 3 : 0 : +!!i;
	}
	if (n.kind === "pass") return i.kind === "marshal" ? 0 : -3;
	if (n.kind === "clan") return [
		7,
		5,
		8,
		7,
		9,
		6,
		8,
		7
	][n.target];
	if (n.kind === "card") return Ft(e, t, e.market[n.target], r);
	if (n.kind === "summon") return n.at >= 8 ? r.shrine + +(Z(e, t, n.at) === 0) - Z(e, t, n.at) * .8 : Pt(e, t, n.at, r) + Math.max(1, E[a.kind]?.force ?? 1);
	if (n.kind === "move" || n.kind === "kamiMove") {
		let i = n.kind === "kamiMove" ? e.kami.find((e) => 1e3 + e.god === n.target).at : a.at;
		return n.at >= 8 ? r.shrine - Z(e, t, n.at) + Z(e, t, i) * .1 : Pt(e, t, n.at, r) - Pt(e, t, i, r) * .65 + +(Z(e, t, i) > 2);
	}
	if (n.kind === "province") return Pt(e, t, n.target, r) + (i.kind === "ashigaru" ? 2 : 0);
	if (n.kind === "piece") {
		let n = Nt(a) === e.players[t].ally, r = Nt(a) !== t;
		return i.kind === "fireDragon" ? -(E[a.kind]?.force ?? 1) : (r ? 4 : -10) + (E[a.kind]?.force ?? 1) + (n ? -4 : 0);
	}
	if (n.kind === "seat") return (n.target === e.players[t].ally ? 2 : 0) - e.players[n.target].vp * .02 - e.players[n.target].coins * .05;
	if (n.kind === "no") return i.kind === "mercy" ? 3 : 0;
	if (i.kind === "seppuku") {
		let n = Math.max(...e.players.map((n, r) => r === t ? 0 : Z(e, r, i.at))), r = Z(e, t, i.at);
		return o * (1 + e.players[t].cards.filter((e) => e === "righteousness").length) + (r >= n ? -10 : 1);
	}
	return i.kind === "alliance" ? 4 : i.kind === "mercy" ? -2 : i.kind === "nureOnna" ? Pt(e, t, i.at, r) : i.kind === "monkey" || i.kind === "ninja" ? 2 : 4;
}
function Lt(e, t, n) {
	let r = e.battle, i = e.players[t], a = e.wars.slice(e.warIndex).filter((n) => Z(e, t, n) > 0).length, o = Math.max(0, Math.min(i.coins, Math.ceil(i.coins * (a <= 1 ? 1 : 1 - n.conserve)))), s = Z(e, t, r.province), c = Math.max(...r.participants.filter((e) => e !== t).map((t) => Z(e, t, r.province))), l = e.pieces.filter((e) => Nt(e) === t && e.at === r.province && e.kind !== "fort").length, u = [
		0,
		0,
		0,
		0
	], d = i.ronin + (re[i.clan] === "koi" ? Math.max(0, i.coins - o) : 0), f = s + d >= c ? d > 0 ? 2 : 1 : l >= 2 ? 0 : 1;
	return u[f] = Math.min(o, Math.max(1, Math.ceil(o * .65))), u[3] = Math.max(0, o - u[f]), {
		type: "bid",
		coins: u
	};
}
function Rt(e, t, n, r = !1, i = Mt) {
	let a = t.legal;
	if (!a.length) return null;
	if (r) return a[(e.revision * 17 + n * 13) % a.length];
	if (a[0].type === "bid") return Lt(e, n, i);
	let o = a[0], s = -Infinity;
	for (let t of a) {
		let r = 0;
		if (t.type === "choose" && (r = It(e, n, e.prompt.choices[t.index], i)), t.type === "mandate") {
			let a = e.pieces.filter((e) => e.owner === n && e.at < 0 && e.captive < 0 && e.kind !== "fort").length, o = Array.from({ length: 8 }, (e, t) => t).filter((t) => Z(e, n, t) > 0);
			r = [
				a ? 4 + Math.min(4, a) : 0,
				o.length < 3 ? 5 : 2,
				e.market.length ? Math.max(...[...new Set(e.market)].map((t) => Ft(e, n, t, i))) : 0,
				o.reduce((t, r) => t + Pt(e, n, r, i), 0) * .8,
				e.players[n].ally >= 0 ? -4 : 3
			][t.declare];
		}
		r += ((t.type === "choose" || t.type === "mandate" ? t.index : 0) * 7 + e.revision) % 11 * .001, r > s && (s = r, o = t);
	}
	return o;
}
function zt(e = Mt) {
	return (t, n) => {
		let r = t.public.players.findIndex((e) => e.rid === n.rid);
		if (!t.private || r < 0) return null;
		let i = Rt(t.public, t.private, r, n.difficulty === "weak", e);
		return i ? { action: i } : null;
	};
}
var Bt = zt(), Q = (e) => e.data, $ = 700, Vt = (e, t) => e.rid ? t.anchor(`seat:${e.rid}`) : null;
function Ht(e, t, n) {
	let r = e.anchor(`place:${n}`);
	if (!r) return null;
	if (!t.fromCount || t.fromIndex === void 0 || t.fromIndex < 0) return r;
	let i = St(n), a = Ct(n, t.fromCount, t.fromIndex);
	return {
		x: r.x + (a.x - i.x) / i.w * r.w,
		y: r.y + (a.y - i.y) / i.h * r.h,
		w: a.w / i.w * r.w,
		h: a.h / i.h * r.h
	};
}
function Ut({ kind: e, clan: t }) {
	return /* @__PURE__ */ h("div", {
		className: "rs-fx-piece",
		children: e.startsWith("kami:") ? /* @__PURE__ */ h(gt, { god: Number(e.slice(5)) }) : /* @__PURE__ */ h(vt, {
			kind: e,
			clan: t
		})
	});
}
function Wt({ kind: e, n: t }) {
	let n = X();
	return /* @__PURE__ */ h("div", {
		className: "rs-fx-stamp",
		children: e === "win" ? n.provinces[t] : e === "mandate" ? n.mandates[t] : n.gods[t]
	});
}
function Gt({ data: e }) {
	let t = X();
	return /* @__PURE__ */ g("span", {
		className: "rs-fx-score",
		children: [
			(e.n ?? 0) > 0 ? "+" : "",
			e.n,
			" ",
			e.resource === "coins" ? t.resource.coins : t.resource.honor
		]
	});
}
function Kt({ bids: e, players: t, ctx: i }) {
	let a = X(), o = r(null);
	return n(() => {
		let e = o.current?.animate([{
			transform: "perspective(700px) rotateX(85deg)",
			opacity: 0
		}, {
			transform: "perspective(700px) rotateX(0)",
			opacity: 1
		}], {
			duration: $ * .7,
			fill: "both",
			easing: "ease-out"
		});
		return () => e?.cancel();
	}, []), /* @__PURE__ */ g("div", {
		ref: o,
		className: "rs-fx-reveal",
		children: [
			/* @__PURE__ */ h("strong", { children: a.events.reveal }),
			/* @__PURE__ */ h("div", { children: a.bidLabels.map((e) => /* @__PURE__ */ h("small", { children: e }, e)) }),
			e.map((e, n) => /* @__PURE__ */ g("section", { children: [/* @__PURE__ */ h("span", { children: i.member(t[n])?.name ?? t[n] }), /* @__PURE__ */ h("div", { children: e.map((e, t) => /* @__PURE__ */ h("b", { children: e }, t)) })] }, n))
		]
	});
}
var qt = (e, t) => {
	let n = Q(e), r = n.piece === void 0 ? null : t.anchor(`piece:${n.piece}`), i = n.from !== void 0 && n.from >= 0 ? Ht(t, n, n.from) : n.sourceAt === void 0 ? t.anchor(`reserve:${e.rid}:${n.kind}`) ?? Vt(e, t) : t.anchor(`place:${n.sourceAt}`);
	return !i || !r || !n.kind ? null : {
		ms: $,
		node: /* @__PURE__ */ h(v, {
			from: i,
			to: r,
			ms: $,
			children: /* @__PURE__ */ h(Ut, {
				kind: n.kind,
				clan: n.clan ?? -1
			})
		}),
		hide: t.queued ? [] : [`piece:${n.piece}`]
	};
}, Jt = (e, t) => {
	let n = Q(e), r = n.at === void 0 ? null : Ht(t, n, n.at), i = n.to === void 0 ? Vt(e, t) : t.anchor(`place:${n.to}`);
	return !r || !i || !n.kind ? null : {
		ms: $,
		node: /* @__PURE__ */ h(v, {
			from: r,
			to: {
				...i,
				w: 32,
				h: 32
			},
			ms: $,
			children: /* @__PURE__ */ h(Ut, {
				kind: n.kind,
				clan: n.figureClan ?? n.clan ?? -1
			})
		})
	};
}, Yt = {
	move: qt,
	kill: Jt,
	hostage: Jt,
	return: Jt,
	resource(e, t) {
		let n = Vt(e, t), r = Q(e);
		return n && r.n ? {
			ms: $,
			node: /* @__PURE__ */ h(_, {
				at: n,
				ms: $,
				children: /* @__PURE__ */ h(Gt, { data: r })
			})
		} : null;
	},
	score(e, t) {
		let n = Q(e), r = Vt(e, t);
		return r ? {
			ms: $,
			node: /* @__PURE__ */ h(_, {
				at: r,
				ms: $,
				children: /* @__PURE__ */ g("span", {
					className: "rs-fx-score",
					children: [(n.n ?? 0) > 0 ? "+" : "", /* @__PURE__ */ h(mt, {
						kind: "vp",
						n: n.n ?? 0
					})]
				})
			})
		} : null;
	},
	card(e, t) {
		let n = Q(e), r = t.anchor(`card:${n.card}`) ?? t.anchor("market") ?? t.anchor("board"), i = Vt(e, t);
		return r && i && n.card ? {
			ms: $,
			node: /* @__PURE__ */ h(v, {
				from: r,
				to: {
					...i,
					w: 55,
					h: 75
				},
				ms: $,
				children: /* @__PURE__ */ h("div", {
					className: "rs-fx-card",
					children: /* @__PURE__ */ h(yt, {
						id: n.card,
						anchor: !1,
						compact: !0
					})
				})
			})
		} : null;
	},
	build(e, t) {
		let n = Q(e), r = t.anchor(`place:${n.at}`);
		return r ? {
			ms: $,
			node: /* @__PURE__ */ g(ee, { children: [/* @__PURE__ */ h(y, {
				at: r,
				ms: $
			}), /* @__PURE__ */ h(_, {
				at: r,
				ms: $,
				children: /* @__PURE__ */ h(Ut, {
					kind: "fort",
					clan: n.clan ?? -1
				})
			})] })
		} : null;
	},
	mandate(e, t) {
		let n = t.anchor("board");
		return n ? {
			ms: $,
			node: /* @__PURE__ */ h(_, {
				at: {
					...n,
					y: n.y + n.h * .25
				},
				ms: $,
				children: /* @__PURE__ */ h(Wt, {
					kind: "mandate",
					n: Q(e).mandate ?? 0
				})
			})
		} : null;
	},
	win(e, t) {
		let n = Q(e), r = t.anchor(`place:${n.at}`);
		return r ? {
			ms: $,
			node: /* @__PURE__ */ g(ee, { children: [/* @__PURE__ */ h(y, {
				at: r,
				ms: $
			}), /* @__PURE__ */ h(_, {
				at: {
					...r,
					y: r.y + r.h * .5
				},
				ms: $,
				children: /* @__PURE__ */ g("div", {
					className: "rs-fx-victory",
					children: [/* @__PURE__ */ h(ht, { clan: n.clan ?? -1 }), /* @__PURE__ */ h(Wt, {
						kind: "win",
						n: n.at ?? 0
					})]
				})
			})] })
		} : null;
	},
	manifest(e, t) {
		let n = Q(e), r = t.anchor(`place:${n.at}`);
		return r ? {
			ms: $,
			node: /* @__PURE__ */ g(ee, { children: [/* @__PURE__ */ h(y, {
				at: r,
				ms: $
			}), /* @__PURE__ */ h(_, {
				at: r,
				ms: $,
				children: /* @__PURE__ */ h(Wt, {
					kind: "manifest",
					n: n.god ?? 0
				})
			})] })
		} : null;
	},
	control(e, t) {
		let n = t.anchor(`piece:${Q(e).piece}`);
		return n ? {
			ms: $,
			node: /* @__PURE__ */ h(y, {
				at: n,
				ms: $
			})
		} : null;
	},
	reveal(e, t) {
		let n = Q(e), r = t.anchor("board");
		return r && n.bids && n.players ? {
			ms: $,
			node: /* @__PURE__ */ h("div", {
				style: {
					position: "absolute",
					left: r.x + r.w * .12,
					top: r.y + r.h * .15,
					width: r.w * .76
				},
				children: /* @__PURE__ */ h(Kt, {
					bids: n.bids,
					players: n.players,
					ctx: t
				})
			})
		} : null;
	}
};
//#endregion
//#region src/games/risingsun/game-over.tsx
function Xt({ public: e, result: t, members: n, myRid: r, hintCount: a, onPlayAgain: o, onBackToLobby: s }) {
	let c = e, l = X(), u = m(), [d, f] = i(!0), p = (e) => n.find((t) => t.rid === e)?.name ?? e, _ = t.ranking.map((e) => c.players.findIndex((t) => t.rid === e));
	return /* @__PURE__ */ g("div", {
		className: "rs-over rs-shell",
		children: [
			/* @__PURE__ */ h("div", {
				className: "rs-over-board",
				inert: d,
				children: /* @__PURE__ */ h(jt, {
					pub: c,
					public: c,
					members: n,
					myRid: r,
					send: () => {},
					readOnly: !0
				})
			}),
			/* @__PURE__ */ g("section", {
				className: "rs-ending",
				hidden: !d,
				role: "dialog",
				"aria-label": l.result,
				children: [
					/* @__PURE__ */ g("header", {
						className: "rs-ending-header",
						children: [/* @__PURE__ */ g("div", { children: [
							/* @__PURE__ */ h("small", { children: l.seasons[3] }),
							/* @__PURE__ */ h("h1", { children: l.result }),
							/* @__PURE__ */ h("p", { children: t.winner.map(p).join(" · ") })
						] }), /* @__PURE__ */ h("button", {
							onClick: () => f(!1),
							children: l.review
						})]
					}),
					/* @__PURE__ */ g("div", {
						className: "rs-ending-body",
						children: [/* @__PURE__ */ g("table", {
							className: "rs-ledger",
							style: { minWidth: _.length <= 4 ? "100%" : 95 + _.length * 90 },
							children: [
								/* @__PURE__ */ h("thead", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
									scope: "col",
									children: l.resource.vp
								}), _.map((e, n) => {
									let r = c.players[e];
									return /* @__PURE__ */ g("th", {
										scope: "col",
										"data-winner": t.winner.includes(r.rid),
										children: [
											/* @__PURE__ */ h(ht, {
												clan: r.clan,
												size: 58
											}),
											/* @__PURE__ */ h("strong", { children: p(r.rid) }),
											/* @__PURE__ */ g("small", { children: [
												l.clans[r.clan],
												" · ",
												n + 1
											] })
										]
									}, r.rid);
								})] }) }),
								/* @__PURE__ */ h("tbody", { children: l.scoreRows.map((e, t) => /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
									scope: "row",
									children: e
								}), _.map((e) => /* @__PURE__ */ h("td", { children: c.players[e].final[t] ?? 0 }, e))] }, e)) }),
								/* @__PURE__ */ h("tfoot", { children: /* @__PURE__ */ g("tr", {
									className: "rs-ledger-total",
									children: [/* @__PURE__ */ h("th", {
										scope: "row",
										children: l.totals
									}), _.map((e) => /* @__PURE__ */ h("td", { children: c.players[e].vp }, e))]
								}) })
							]
						}), /* @__PURE__ */ g("div", {
							className: "rs-ending-notes",
							children: [_.map((e) => {
								let n = c.players[e], r = t.autopilot?.[n.rid];
								return /* @__PURE__ */ g("p", { children: [
									/* @__PURE__ */ h("strong", { children: p(n.rid) }),
									n.ally >= 0 && /* @__PURE__ */ g("span", { children: [
										l.ally,
										": ",
										p(c.players[n.ally].rid)
									] }),
									r !== void 0 && r > 0 && /* @__PURE__ */ h("span", { children: u("session.autopilot.share", { n: Math.round(r * 100) }) })
								] }, n.rid);
							}), a !== void 0 && !!o && /* @__PURE__ */ h("p", { children: u("session.hint.usedCount", { n: a }) })]
						})]
					}),
					/* @__PURE__ */ h("footer", {
						className: "rs-ending-footer",
						children: o || s ? /* @__PURE__ */ g(ee, { children: [o && /* @__PURE__ */ h("button", {
							className: "rs-primary",
							onClick: o,
							children: l.again
						}), s && /* @__PURE__ */ h("button", {
							onClick: s,
							children: l.lobby
						})] }) : /* @__PURE__ */ h("p", { children: l.waitHost })
					})
				]
			}),
			!d && /* @__PURE__ */ h("div", {
				className: "rs-review-tools",
				children: /* @__PURE__ */ h("button", {
					className: "rs-primary",
					onClick: () => f(!0),
					children: l.showResult
				})
			})
		]
	});
}
//#endregion
//#region src/games/risingsun/options.tsx
function Zt({ value: e, onChange: t }) {
	let n = X(), r = O.safeParse(e), i = r.success ? r.data : O.parse(void 0);
	return /* @__PURE__ */ g("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ h(te, {
				title: n.options.set,
				children: [
					"archway",
					"kettle",
					"horseman",
					"boat",
					"mountain"
				].map((e, r) => /* @__PURE__ */ h(b, {
					name: "risingsun-set",
					value: e,
					label: n.options.sets[r],
					checked: e === i.set,
					onChange: () => t({
						...i,
						set: e
					})
				}, e))
			}),
			/* @__PURE__ */ h(te, {
				title: n.options.shrines,
				children: ["beginner", "random"].map((e) => /* @__PURE__ */ h(b, {
					name: "risingsun-shrines",
					value: e,
					label: n.options[e],
					checked: i.shrines === e,
					onChange: () => t({
						...i,
						shrines: e
					})
				}, e))
			}),
			/* @__PURE__ */ h("div", { children: [
				"daimyo",
				"monster",
				"dynasty",
				"unbound"
			].map((e) => /* @__PURE__ */ h(ne, {
				label: n.options[e],
				hint: e === "dynasty" ? n.options.six : void 0,
				checked: i[e],
				onChange: () => t({
					...i,
					[e]: !i[e]
				})
			}, e)) })
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/risingsun/entry.tsx
var Qt = {
	definition: st,
	View: At,
	bot: Bt,
	fx: Yt,
	OverView: Xt,
	Options: Zt,
	locales: {
		zh: dt,
		en: ft
	}
};
//#endregion
export { Qt as default };
