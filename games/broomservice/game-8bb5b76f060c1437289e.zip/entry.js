import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useT as r } from "@bgparty/sdk/i18n";
import { BottomSheet as i } from "@bgparty/sdk/bottom-sheet";
import { useFxAnchor as a } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as o } from "@bgparty/sdk/fx/delta-number";
import { PLAYER_COLORS as s } from "@bgparty/sdk/player-colors";
import { SheetFxProbe as c, SheetView as l } from "@bgparty/sdk/sheet-view";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { Floater as h, FlySprite as g, PulseBox as _ } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as v, OptionSection as y, OptionSwitch as b } from "@bgparty/sdk/ui/game-options";
//#region src/games/broomservice/data.ts
var x = [
	"games.broomservice.roles.forest",
	"games.broomservice.roles.prairie",
	"games.broomservice.roles.hill",
	"games.broomservice.roles.mountain",
	"games.broomservice.roles.herb",
	"games.broomservice.roles.fruit",
	"games.broomservice.roles.root",
	"games.broomservice.roles.peak",
	"games.broomservice.roles.valley",
	"games.broomservice.roles.weather"
], ee = [
	"games.broomservice.events.empty",
	"games.broomservice.events.protected",
	"games.broomservice.events.market",
	"games.broomservice.events.more",
	"games.broomservice.events.works",
	"games.broomservice.events.distillery",
	"games.broomservice.events.flock",
	"games.broomservice.events.upper",
	"games.broomservice.events.perilous",
	"games.broomservice.events.brave"
], te = [
	"games.broomservice.eventText.empty",
	"games.broomservice.eventText.protected",
	"games.broomservice.eventText.market",
	"games.broomservice.eventText.more",
	"games.broomservice.eventText.works",
	"games.broomservice.eventText.distillery",
	"games.broomservice.eventText.flock",
	"games.broomservice.eventText.upper",
	"games.broomservice.eventText.perilous",
	"games.broomservice.eventText.brave"
], S = [
	"games.broomservice.green",
	"games.broomservice.purple",
	"games.broomservice.orange",
	"games.broomservice.wand"
], ne = {
	forest: "games.broomservice.forest",
	prairie: "games.broomservice.prairie",
	hill: "games.broomservice.hill",
	mountain: "games.broomservice.mountain",
	water: "games.broomservice.water"
}, C = [
	[
		"forest",
		395,
		53,
		[
			8,
			15,
			23,
			37
		]
	],
	[
		"forest",
		934,
		127,
		[
			12,
			16,
			32
		]
	],
	[
		"forest",
		99,
		235,
		[
			9,
			10,
			25,
			33
		]
	],
	[
		"forest",
		657,
		266,
		[
			12,
			19,
			20,
			26,
			27,
			31
		]
	],
	[
		"forest",
		420,
		387,
		[
			10,
			11,
			13,
			17,
			18,
			20,
			28,
			31,
			34
		]
	],
	[
		"forest",
		758,
		438,
		[
			13,
			14,
			20,
			21,
			27,
			35
		]
	],
	[
		"forest",
		60,
		492,
		[
			11,
			18,
			29,
			34
		]
	],
	[
		"forest",
		666,
		593,
		[
			13,
			22,
			28,
			30,
			35
		]
	],
	[
		"prairie",
		570,
		47,
		[
			0,
			15,
			17,
			19,
			24,
			26,
			33,
			37
		]
	],
	[
		"prairie",
		93,
		141,
		[
			2,
			15,
			23,
			33
		]
	],
	[
		"prairie",
		264,
		290,
		[
			2,
			4,
			17,
			18,
			25,
			33
		]
	],
	[
		"prairie",
		392,
		505,
		[
			4,
			6,
			22,
			28,
			29,
			34
		]
	],
	[
		"prairie",
		805,
		212,
		[
			1,
			3,
			19,
			21,
			24,
			27,
			32
		]
	],
	[
		"prairie",
		618,
		466,
		[
			4,
			5,
			7,
			20,
			28,
			35
		]
	],
	[
		"prairie",
		926,
		513,
		[
			5,
			21,
			30,
			35
		]
	],
	[
		"hill",
		251,
		107,
		[
			0,
			8,
			9,
			23,
			33
		]
	],
	[
		"hill",
		853,
		36,
		[
			1,
			24,
			32
		]
	],
	[
		"hill",
		397,
		257,
		[
			4,
			8,
			10,
			26,
			31,
			33
		]
	],
	[
		"hill",
		148,
		401,
		[
			4,
			6,
			10,
			25,
			34
		]
	],
	[
		"hill",
		597,
		159,
		[
			3,
			8,
			12,
			24,
			26,
			32
		]
	],
	[
		"hill",
		624,
		364,
		[
			3,
			4,
			5,
			13,
			27
		]
	],
	[
		"hill",
		931,
		348,
		[
			5,
			12,
			14,
			27,
			36
		]
	],
	[
		"hill",
		388,
		607,
		[
			7,
			11,
			28,
			29
		]
	],
	[
		"mountain",
		115,
		48,
		[
			0,
			9,
			15
		]
	],
	[
		"mountain",
		698,
		92,
		[
			8,
			12,
			16,
			19,
			32
		]
	],
	[
		"mountain",
		74,
		308,
		[
			2,
			10,
			18
		]
	],
	[
		"mountain",
		510,
		231,
		[
			3,
			8,
			17,
			19,
			31
		]
	],
	[
		"mountain",
		810,
		341,
		[
			3,
			5,
			12,
			20,
			21
		]
	],
	[
		"mountain",
		526,
		542,
		[
			4,
			7,
			11,
			13,
			22
		]
	],
	[
		"mountain",
		116,
		598,
		[
			6,
			11,
			22,
			34
		]
	],
	[
		"mountain",
		896,
		607,
		[
			7,
			14,
			35
		]
	],
	[
		"water",
		509,
		318,
		[
			3,
			4,
			17,
			26
		]
	],
	[
		"water",
		797,
		116,
		[
			1,
			12,
			16,
			19,
			24
		]
	],
	[
		"water",
		251,
		198,
		[
			2,
			8,
			9,
			10,
			15,
			17
		]
	],
	[
		"water",
		231,
		493,
		[
			4,
			6,
			11,
			18,
			29
		]
	],
	[
		"water",
		776,
		528,
		[
			5,
			7,
			13,
			14,
			30
		]
	],
	[
		"water",
		980,
		340,
		[21]
	],
	[
		"water",
		502,
		93,
		[0, 8]
	]
];
function re(e) {
	let t = e.map(([e, t, n, r], i) => ({
		id: i,
		terrain: e,
		x: t,
		y: n,
		neighbors: [...r]
	}));
	for (let e of t) for (let n of e.neighbors) t[n].neighbors.includes(e.id) || t[n].neighbors.push(e.id);
	return t;
}
var ie = [
	[
		38,
		42,
		0,
		8,
		0,
		!1,
		[23]
	],
	[
		188,
		38,
		0,
		6,
		0,
		!1,
		[23]
	],
	[
		261,
		33,
		0,
		4,
		0,
		!0,
		[
			0,
			15,
			23
		]
	],
	[
		380,
		35,
		1,
		2,
		1,
		!1,
		[0]
	],
	[
		435,
		35,
		2,
		6,
		0,
		!1,
		[0]
	],
	[
		257,
		105,
		1,
		3,
		2,
		!1,
		[15]
	],
	[
		350,
		100,
		0,
		6,
		0,
		!1,
		[
			0,
			8,
			15
		]
	],
	[
		27,
		140,
		2,
		4,
		0,
		!1,
		[9]
	],
	[
		135,
		145,
		1,
		3,
		1,
		!1,
		[9]
	],
	[
		80,
		183,
		0,
		3,
		0,
		!0,
		[2, 9]
	],
	[
		56,
		245,
		0,
		4,
		0,
		!1,
		[2, 25]
	],
	[
		121,
		286,
		1,
		2,
		1,
		!1,
		[2, 25]
	],
	[
		215,
		319,
		1,
		3,
		0,
		!0,
		[
			10,
			18,
			25
		]
	],
	[
		302,
		356,
		1,
		1,
		1,
		!1,
		[4, 10]
	],
	[
		337,
		274,
		0,
		4,
		0,
		!1,
		[10, 17]
	],
	[
		458,
		273,
		2,
		5,
		0,
		!1,
		[17]
	],
	[
		442,
		186,
		1,
		4,
		0,
		!0,
		[
			8,
			17,
			26
		]
	],
	[
		575,
		45,
		1,
		7,
		0,
		!1,
		[8]
	],
	[
		640,
		65,
		2,
		5,
		0,
		!0,
		[8, 24]
	],
	[
		690,
		130,
		2,
		7,
		0,
		!1,
		[19, 24]
	],
	[
		543,
		200,
		1,
		3,
		2,
		!1,
		[19, 26]
	],
	[
		650,
		185,
		2,
		9,
		0,
		!1,
		[19]
	],
	[
		716,
		195,
		1,
		6,
		0,
		!1,
		[12, 19]
	],
	[
		856,
		43,
		0,
		9,
		0,
		!1,
		[16]
	],
	[
		897,
		75,
		0,
		7,
		0,
		!0,
		[1, 16]
	],
	[
		957,
		50,
		1,
		10,
		0,
		!1,
		[1, 16]
	],
	[
		979,
		135,
		2,
		9,
		0,
		!1,
		[1]
	],
	[
		800,
		235,
		0,
		5,
		0,
		!1,
		[12]
	],
	[
		860,
		270,
		1,
		5,
		0,
		!0,
		[
			12,
			21,
			27
		]
	],
	[
		946,
		230,
		0,
		7,
		0,
		!1,
		[12, 21]
	],
	[
		986,
		285,
		0,
		8,
		0,
		!1,
		[21]
	],
	[
		659,
		270,
		1,
		4,
		1,
		!1,
		[3]
	],
	[
		715,
		315,
		0,
		4,
		0,
		!0,
		[3, 27]
	],
	[
		778,
		355,
		0,
		5,
		0,
		!1,
		[27]
	],
	[
		674,
		350,
		1,
		5,
		0,
		!1,
		[20]
	],
	[
		677,
		409,
		0,
		4,
		0,
		!1,
		[13, 20]
	],
	[
		789,
		428,
		0,
		5,
		0,
		!1,
		[5]
	],
	[
		881,
		450,
		1,
		4,
		0,
		!0,
		[
			5,
			14,
			21
		]
	],
	[
		941,
		355,
		2,
		7,
		0,
		!1,
		[21]
	],
	[
		990,
		405,
		2,
		5,
		0,
		!1,
		[21]
	],
	[
		970,
		477,
		1,
		6,
		0,
		!1,
		[14, 21]
	],
	[
		934,
		511,
		1,
		3,
		1,
		!1,
		[14]
	],
	[
		904,
		600,
		0,
		4,
		0,
		!1,
		[30]
	],
	[
		981,
		619,
		0,
		6,
		0,
		!1,
		[30]
	],
	[
		836,
		588,
		0,
		5,
		0,
		!1,
		[30]
	],
	[
		792,
		614,
		1,
		3,
		0,
		!0,
		[7, 30]
	],
	[
		667,
		593,
		1,
		3,
		1,
		!1,
		[7]
	],
	[
		595,
		560,
		2,
		4,
		0,
		!1,
		[7, 28]
	],
	[
		540,
		457,
		0,
		3,
		0,
		!0,
		[
			4,
			13,
			28
		]
	],
	[
		403,
		542,
		2,
		4,
		0,
		!1,
		[11]
	],
	[
		340,
		555,
		0,
		3,
		0,
		!0,
		[11, 22]
	],
	[
		236,
		597,
		1,
		4,
		0,
		!1,
		[22, 29]
	],
	[
		398,
		611,
		1,
		3,
		1,
		!1,
		[22]
	],
	[
		151,
		552,
		1,
		5,
		0,
		!1,
		[
			6,
			11,
			29
		]
	],
	[
		87,
		538,
		0,
		4,
		0,
		!1,
		[6, 11]
	],
	[
		34,
		557,
		2,
		3,
		0,
		!0,
		[6]
	],
	[
		38,
		617,
		1,
		7,
		0,
		!1,
		[29]
	],
	[
		523,
		248,
		2,
		6,
		0,
		!1,
		[26]
	]
];
function ae(e) {
	return e.map(([e, t, n, r, i, a, o], s) => ({
		id: s,
		x: e,
		y: t,
		color: n,
		points: r,
		wands: i,
		square: a,
		areas: o
	}));
}
var w = {
	front: {
		areas: re(C),
		towers: ae(ie),
		slots: [
			{
				x: 112,
				y: 60,
				area: 23,
				adjacent: [
					0,
					9,
					15
				]
			},
			{
				x: 116,
				y: 598,
				area: 29,
				adjacent: [
					6,
					11,
					22
				]
			},
			{
				x: 855,
				y: 337,
				area: 27,
				adjacent: [
					3,
					5,
					12,
					20,
					21
				]
			},
			{
				x: 208,
				y: 190,
				area: 33,
				adjacent: [
					2,
					8,
					9,
					10,
					15,
					17
				]
			},
			{
				x: 288,
				y: 202,
				area: 33,
				adjacent: [
					2,
					8,
					9,
					10,
					15,
					17
				]
			},
			{
				x: 390,
				y: 245,
				area: 17,
				adjacent: [
					4,
					8,
					10,
					26
				]
			},
			{
				x: 585,
				y: 155,
				area: 19,
				adjacent: [
					3,
					8,
					12,
					24,
					26
				]
			},
			{
				x: 600,
				y: 363,
				area: 20,
				adjacent: [
					3,
					4,
					5,
					13,
					27
				]
			},
			{
				x: 929,
				y: 267,
				area: 21,
				adjacent: [
					5,
					12,
					14,
					27
				]
			},
			{
				x: 929,
				y: 416,
				area: 21,
				adjacent: [
					5,
					12,
					14,
					27
				]
			},
			{
				x: 780,
				y: 87,
				area: 32,
				adjacent: [
					1,
					12,
					16,
					19,
					24
				]
			},
			{
				x: 822,
				y: 146,
				area: 32,
				adjacent: [
					1,
					12,
					16,
					19,
					24
				]
			},
			{
				x: 509,
				y: 318,
				area: 31,
				adjacent: [
					3,
					4,
					17,
					26
				]
			},
			{
				x: 235,
				y: 456,
				area: 34,
				adjacent: [
					4,
					6,
					11,
					18,
					29
				]
			},
			{
				x: 182,
				y: 505,
				area: 34,
				adjacent: [
					4,
					6,
					11,
					18,
					29
				]
			},
			{
				x: 265,
				y: 511,
				area: 34,
				adjacent: [
					4,
					6,
					11,
					18,
					29
				]
			},
			{
				x: 738,
				y: 529,
				area: 35,
				adjacent: [
					5,
					7,
					13,
					14,
					30
				]
			},
			{
				x: 815,
				y: 535,
				area: 35,
				adjacent: [
					5,
					7,
					13,
					14,
					30
				]
			}
		],
		castles: [18, 11],
		mountains: [
			25,
			26,
			28
		],
		forestPositions: {},
		mountainPositions: {
			25: [74, 325],
			26: [523, 248],
			28: [526, 542]
		},
		coveredTowers: [57],
		forests: [],
		hills: [],
		circles: []
	},
	back: {
		areas: re([
			[
				"forest",
				115,
				60,
				[
					9,
					17,
					26
				]
			],
			[
				"forest",
				60,
				240,
				[
					9,
					27,
					28,
					34,
					37
				]
			],
			[
				"forest",
				350,
				370,
				[
					12,
					20,
					22,
					27,
					37,
					38
				]
			],
			[
				"forest",
				670,
				250,
				[
					13,
					19,
					21,
					29,
					30,
					36,
					39
				]
			],
			[
				"forest",
				770,
				430,
				[
					13,
					21,
					24,
					31,
					36,
					39
				]
			],
			[
				"forest",
				940,
				170,
				[
					11,
					35,
					36
				]
			],
			[
				"forest",
				86,
				500,
				[
					14,
					22,
					28,
					32
				]
			],
			[
				"forest",
				530,
				570,
				[
					15,
					24,
					31,
					38
				]
			],
			[
				"forest",
				870,
				600,
				[
					16,
					33,
					36
				]
			],
			[
				"prairie",
				52,
				130,
				[
					0,
					1,
					17,
					34
				]
			],
			[
				"prairie",
				610,
				25,
				[
					18,
					19,
					29,
					36
				]
			],
			[
				"prairie",
				905,
				75,
				[
					5,
					35,
					36
				]
			],
			[
				"prairie",
				470,
				310,
				[
					2,
					20,
					21,
					30,
					31,
					38
				]
			],
			[
				"prairie",
				860,
				320,
				[
					3,
					4,
					19,
					36,
					39
				]
			],
			[
				"prairie",
				80,
				560,
				[
					6,
					23,
					32
				]
			],
			[
				"prairie",
				420,
				520,
				[
					7,
					31,
					38
				]
			],
			[
				"prairie",
				900,
				500,
				[
					8,
					25,
					33,
					36
				]
			],
			[
				"hill",
				260,
				130,
				[
					0,
					9,
					26,
					34
				]
			],
			[
				"hill",
				450,
				70,
				[
					10,
					29,
					30,
					34
				]
			],
			[
				"hill",
				800,
				210,
				[
					3,
					10,
					13,
					29,
					36
				]
			],
			[
				"hill",
				380,
				245,
				[
					2,
					12,
					27,
					30,
					34
				]
			],
			[
				"hill",
				610,
				380,
				[
					3,
					4,
					12,
					30,
					31,
					39
				]
			],
			[
				"hill",
				180,
				415,
				[
					2,
					6,
					28,
					32,
					37,
					38
				]
			],
			[
				"hill",
				50,
				595,
				[14]
			],
			[
				"hill",
				630,
				550,
				[
					4,
					7,
					31,
					36
				]
			],
			[
				"hill",
				970,
				420,
				[
					16,
					33,
					36
				]
			],
			[
				"mountain",
				290,
				60,
				[
					0,
					17,
					34
				]
			],
			[
				"mountain",
				240,
				270,
				[
					1,
					2,
					20,
					34,
					37
				]
			],
			[
				"mountain",
				60,
				360,
				[
					1,
					6,
					22,
					37
				]
			],
			[
				"mountain",
				670,
				160,
				[
					3,
					10,
					18,
					19
				]
			],
			[
				"mountain",
				530,
				270,
				[
					3,
					12,
					18,
					20,
					21,
					39
				]
			],
			[
				"mountain",
				550,
				470,
				[
					4,
					7,
					12,
					15,
					21,
					24,
					38
				]
			],
			[
				"mountain",
				270,
				550,
				[
					6,
					14,
					22,
					38
				]
			],
			[
				"mountain",
				950,
				560,
				[
					8,
					16,
					25,
					36
				]
			],
			[
				"water",
				300,
				440,
				[
					1,
					9,
					17,
					18,
					20,
					26,
					27
				]
			],
			[
				"water",
				978,
				35,
				[5, 11]
			],
			[
				"water",
				820,
				510,
				[
					3,
					4,
					5,
					8,
					10,
					11,
					13,
					16,
					19,
					24,
					25,
					33
				]
			],
			[
				"water",
				225,
				340,
				[
					1,
					2,
					22,
					27,
					28
				]
			],
			[
				"water",
				350,
				490,
				[
					2,
					7,
					12,
					15,
					22,
					31,
					32
				]
			],
			[
				"water",
				730,
				330,
				[
					3,
					4,
					13,
					21,
					30
				]
			]
		]),
		towers: ae([
			[
				28,
				34,
				2,
				4,
				0,
				!1,
				[0, 9]
			],
			[
				111,
				35,
				1,
				3,
				1,
				!1,
				[0]
			],
			[
				184,
				35,
				0,
				4,
				0,
				!0,
				[
					0,
					17,
					26
				]
			],
			[
				251,
				34,
				0,
				5,
				0,
				!1,
				[26]
			],
			[
				29,
				120,
				1,
				2,
				1,
				!1,
				[9]
			],
			[
				85,
				150,
				1,
				3,
				0,
				!0,
				[1, 9]
			],
			[
				481,
				35,
				1,
				8,
				0,
				!1,
				[18]
			],
			[
				627,
				25,
				2,
				9,
				0,
				!1,
				[10]
			],
			[
				726,
				49,
				0,
				7,
				0,
				!0,
				[10, 29]
			],
			[
				847,
				35,
				0,
				6,
				0,
				!0,
				[11]
			],
			[
				930,
				105,
				1,
				6,
				0,
				!0,
				[5, 11]
			],
			[
				975,
				144,
				2,
				8,
				0,
				!0,
				[5]
			],
			[
				787,
				97,
				1,
				7,
				0,
				!1,
				[19]
			],
			[
				736,
				160,
				2,
				8,
				0,
				!1,
				[19]
			],
			[
				581,
				85,
				1,
				10,
				0,
				!1,
				[29]
			],
			[
				620,
				170,
				0,
				7,
				0,
				!1,
				[3, 29]
			],
			[
				476,
				123,
				2,
				6,
				0,
				!0,
				[18]
			],
			[
				444,
				188,
				2,
				8,
				0,
				!1,
				[30]
			],
			[
				234,
				248,
				1,
				4,
				0,
				!1,
				[27]
			],
			[
				350,
				250,
				0,
				3,
				0,
				!0,
				[
					2,
					20,
					27
				]
			],
			[
				471,
				295,
				1,
				1,
				2,
				!1,
				[12]
			],
			[
				649,
				257,
				0,
				8,
				0,
				!1,
				[3, 30]
			],
			[
				810,
				235,
				0,
				5,
				0,
				!0,
				[
					3,
					13,
					19
				]
			],
			[
				932,
				266,
				1,
				4,
				1,
				!1,
				[13]
			],
			[
				848,
				338,
				0,
				6,
				0,
				!1,
				[4, 13]
			],
			[
				325,
				372,
				1,
				3,
				2,
				!1,
				[2]
			],
			[
				395,
				397,
				0,
				4,
				0,
				!1,
				[2]
			],
			[
				484,
				394,
				0,
				4,
				0,
				!0,
				[12, 31]
			],
			[
				165,
				397,
				2,
				3,
				0,
				!0,
				[22, 28]
			],
			[
				248,
				450,
				1,
				2,
				2,
				!1,
				[22]
			],
			[
				55,
				440,
				0,
				3,
				0,
				!1,
				[6, 28]
			],
			[
				55,
				541,
				0,
				6,
				0,
				!1,
				[6, 14]
			],
			[
				170,
				550,
				2,
				4,
				0,
				!0,
				[6, 14]
			],
			[
				208,
				612,
				2,
				5,
				0,
				!1,
				[14, 32]
			],
			[
				653,
				420,
				1,
				4,
				1,
				!1,
				[4, 31]
			],
			[
				684,
				493,
				1,
				5,
				0,
				!0,
				[4, 24]
			],
			[
				538,
				616,
				1,
				5,
				2,
				!1,
				[7]
			],
			[
				467,
				570,
				0,
				5,
				0,
				!0,
				[7, 15]
			],
			[
				409,
				615,
				0,
				6,
				0,
				!1,
				[15]
			],
			[
				620,
				616,
				1,
				8,
				0,
				!1,
				[24]
			],
			[
				693,
				610,
				2,
				9,
				0,
				!1,
				[24]
			],
			[
				875,
				489,
				0,
				7,
				0,
				!1,
				[16]
			],
			[
				929,
				488,
				1,
				7,
				1,
				!1,
				[16, 33]
			],
			[
				905,
				552,
				0,
				5,
				0,
				!0,
				[
					8,
					16,
					33
				]
			],
			[
				960,
				617,
				2,
				8,
				0,
				!1,
				[33]
			]
		]),
		slots: [
			{
				x: 206,
				y: 106,
				area: 17,
				adjacent: [
					0,
					9,
					26
				]
			},
			{
				x: 390,
				y: 216,
				area: 20,
				adjacent: [
					2,
					12,
					27,
					30
				]
			},
			{
				x: 575,
				y: 262,
				area: 30,
				adjacent: [
					3,
					12,
					18,
					20,
					21
				]
			},
			{
				x: 787,
				y: 147,
				area: 19,
				adjacent: [
					3,
					10,
					13,
					29
				]
			},
			{
				x: 652,
				y: 551,
				area: 24,
				adjacent: [
					4,
					7,
					31
				]
			},
			{
				x: 128,
				y: 623,
				area: 23,
				adjacent: [14]
			},
			{
				x: 656,
				y: 113,
				area: 29,
				adjacent: [
					3,
					10,
					18,
					19
				]
			},
			{
				x: 518,
				y: 201,
				area: 30,
				adjacent: [
					3,
					12,
					18,
					20,
					21
				]
			},
			{
				x: 276,
				y: 539,
				area: 32,
				adjacent: [
					6,
					14,
					22
				]
			},
			{
				x: 962,
				y: 546,
				area: 33,
				adjacent: [
					8,
					16,
					25
				]
			},
			{
				x: 942,
				y: 25,
				area: 35,
				adjacent: [5, 11]
			},
			{
				x: 378,
				y: 128,
				area: 34,
				adjacent: [
					1,
					9,
					17,
					18,
					20,
					26,
					27
				]
			},
			{
				x: 287,
				y: 175,
				area: 34,
				adjacent: [
					1,
					9,
					17,
					18,
					20,
					26,
					27
				]
			},
			{
				x: 203,
				y: 324,
				area: 37,
				adjacent: [
					1,
					2,
					22,
					27,
					28
				]
			},
			{
				x: 237,
				y: 363,
				area: 37,
				adjacent: [
					1,
					2,
					22,
					27,
					28
				]
			},
			{
				x: 359,
				y: 487,
				area: 38,
				adjacent: [
					2,
					7,
					12,
					15,
					22,
					31,
					32
				]
			},
			{
				x: 746,
				y: 300,
				area: 39,
				adjacent: [
					3,
					4,
					13,
					21,
					30
				]
			},
			{
				x: 697,
				y: 343,
				area: 39,
				adjacent: [
					3,
					4,
					13,
					21,
					30
				]
			},
			{
				x: 812,
				y: 520,
				area: 36,
				adjacent: [
					3,
					4,
					5,
					8,
					10,
					11,
					13,
					16,
					19,
					24,
					25,
					33
				]
			}
		],
		castles: [1, 28],
		mountains: [
			26,
			31,
			32
		],
		forestPositions: {
			0: [140, 80],
			2: [385, 320],
			3: [690, 220],
			7: [530, 570]
		},
		mountainPositions: {
			26: [310, 30],
			31: [570, 437],
			32: [250, 594]
		},
		coveredTowers: [],
		forests: [
			0,
			2,
			3,
			7
		],
		hills: [
			17,
			21,
			23,
			25
		],
		circles: [
			15,
			8,
			13,
			11
		]
	}
}, T = [
	...Array.from({ length: 7 }, () => ({
		cost: 1,
		lightning: 1,
		effect: "none"
	})),
	...Array.from({ length: 7 }, () => ({
		cost: 2,
		lightning: 1,
		effect: "none"
	})),
	...Array.from({ length: 7 }, () => ({
		cost: 3,
		lightning: 1,
		effect: "none"
	})),
	...Array.from({ length: 2 }, () => ({
		cost: 3,
		lightning: 2,
		effect: "none"
	})),
	{
		cost: 6,
		lightning: 3,
		effect: "none"
	}
], E = [
	{
		cost: 1,
		lightning: 1,
		effect: "bonus"
	},
	{
		cost: 1,
		lightning: 1,
		effect: "bonus"
	},
	{
		cost: 2,
		lightning: 1,
		effect: "move"
	},
	{
		cost: 2,
		lightning: 1,
		effect: "move"
	},
	{
		cost: 2,
		lightning: 1,
		effect: "deliver"
	},
	{
		cost: 3,
		lightning: 1,
		effect: "orange"
	},
	{
		cost: 3,
		lightning: 1,
		effect: "green"
	},
	{
		cost: 4,
		lightning: 1,
		effect: "purple"
	}
], D = [
	0,
	3,
	6,
	10,
	14,
	19,
	24,
	30
];
function O(e) {
	let t = [...e].sort((e, t) => e - t), n = t[0];
	for (let e = 0; e < 4; e++) t[e] -= n;
	let r = t.slice(1), i = 0;
	for (; r.filter((e) => e > 0).length >= 3;) {
		for (let e = 0; e < 3; e++) r[e]--;
		i++;
	}
	return n * 4 + i * 2;
}
//#endregion
//#region src/games/broomservice/meta.ts
var oe = {
	id: "broomservice",
	tier: "alpha",
	mechanics: [
		"hand-management",
		"action-programming",
		"push-your-luck",
		"set-collection"
	],
	interactionTags: [],
	nameKey: "games.broomservice.name",
	descKey: "games.broomservice.desc",
	rulesKey: "games.broomservice.rules",
	icon: "🧹",
	iconImg: "games/broomservice.webp",
	rulesUrl: { en: "https://cdn.1j1ju.com/medias/c8/1e/8b-broom-service-rulebook.pdf" },
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [4, 5],
	accent: "#86649c",
	releasedAt: "2026-11-02T01:15:00+08:00",
	search: {
		py: "mo nv kuai di",
		init: "mnkd"
	},
	hotseat: "cover"
}, k = t.int().min(0).max(9), A = t.tuple([
	t.int().nonnegative(),
	t.int().nonnegative(),
	t.int().nonnegative(),
	t.int().nonnegative()
]), j = t.object({
	board: t.enum(["front", "back"]).default("front"),
	storms: t.boolean().default(!1),
	mountains: t.boolean().default(!1)
}).default({
	board: "front",
	storms: !1,
	mountains: !1
}), M = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("select"),
		roles: t.array(k).min(1).max(6),
		extra: t.boolean().default(!1)
	}),
	t.object({
		type: t.literal("play"),
		role: k,
		brave: t.boolean(),
		tile: t.enum([
			"none",
			"brave",
			"points"
		]).default("none")
	}),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("choose"),
		id: t.string().max(120)
	}),
	t.object({
		type: t.literal("bid"),
		stock: A
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	}),
	t.object({
		type: t.literal("extraCard"),
		role: k.nullable()
	})
]), se = t.object({
	id: t.string(),
	kind: t.enum([
		"skip",
		"move",
		"teleport",
		"deliver",
		"cloud",
		"gain",
		"works",
		"mountain"
	]),
	option: t.int().optional(),
	pawn: t.int().optional(),
	to: t.int().optional(),
	tower: t.int().optional(),
	cloud: t.int().optional(),
	stock: A.optional(),
	points: t.int().optional()
}), N = t.object({
	rid: t.string(),
	points: t.int(),
	stock: A,
	pawns: t.tuple([t.int(), t.int()]),
	lightning: t.int().nonnegative(),
	amulets: t.array(t.int()),
	tiles: t.array(t.enum([
		"brave",
		"extra",
		"points"
	])),
	picked: t.boolean(),
	handCount: t.int().nullable(),
	played: t.array(k),
	final: t.object({
		base: t.int(),
		lightning: t.int(),
		resources: t.int(),
		amulets: t.int()
	}).nullable()
}), P = t.object({
	config: j,
	round: t.int(),
	phase: t.enum([
		"select",
		"reveal",
		"extra",
		"play",
		"effect",
		"beat",
		"auction",
		"event",
		"done"
	]),
	actor: t.string().nullable(),
	leader: t.string(),
	role: k.nullable(),
	brave: t.string().nullable(),
	event: k,
	bewitched: t.array(k),
	players: t.array(N),
	extraWaiting: t.array(t.string()),
	clouds: t.array(t.object({
		id: t.int(),
		slot: t.int(),
		cost: t.int(),
		lightning: t.int(),
		effect: t.string()
	})),
	occupied: t.record(t.string(), t.string()),
	mountainTiles: t.record(t.string(), t.enum([
		"potions",
		"wands",
		"deliver",
		"moves",
		"cloud"
	])),
	forestTiles: t.record(t.string(), t.enum([
		"brave",
		"extra",
		"points"
	])),
	hillTiles: t.record(t.string(), t.array(t.int())),
	job: t.string().nullable(),
	log: t.array(t.object({
		kind: t.enum([
			"play",
			"pass",
			"move",
			"deliver",
			"cloud",
			"gain",
			"score",
			"round",
			"bid",
			"tile"
		]),
		rid: t.string().optional(),
		role: k.optional(),
		n: t.int().optional(),
		from: t.int().optional(),
		to: t.int().optional(),
		brave: t.boolean().optional()
	})),
	auctionReady: t.array(t.string())
}), ce = t.object({
	hand: t.array(k),
	selected: t.array(k).nullable(),
	extra: t.boolean(),
	choices: t.array(se),
	bid: A.nullable()
}), le = () => [
	0,
	0,
	0,
	0
], F = (e) => e.reduce((e, t) => e + t, 0), I = (e) => w[e.config.board], L = () => ({ code: "games.broomservice.invalid" });
function R(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function z(e, t) {
	e.log.push(t);
}
function B(e, t, n) {
	e.people[t].points += n, n && z(e, {
		kind: "score",
		rid: t,
		n
	});
}
function ue(e, t) {
	return e.players[(e.players.indexOf(t) + 1) % e.players.length];
}
function de(e) {
	let t = 5 - e.players.length;
	e.bewitched = [];
	for (let n = 0; n < t; n++) e.curseAt >= e.curseDeck.length && (e.curseDeck = R(e, Array.from({ length: 10 }, (e, t) => t)), e.curseAt = 0), e.bewitched.push(e.curseDeck[e.curseAt++]);
	e.bewitched = [...new Set(e.bewitched)];
}
function fe(e) {
	e.phase = "select", e.actor = null, e.role = null, e.brave = null, e.selected = {}, e.extra = {}, e.bids = {}, e.jobs = [], e.event = e.events[e.round - 1];
	for (let t of e.players) e.hands[t] = [], e.people[t].played = [], e.people[t].picked = !1, e.people[t].handCount = null;
	de(e), e.event === 9 && e.people[e.leader].stock[3]++, z(e, {
		kind: "round",
		n: e.round
	});
}
function pe(e, t, n) {
	let r = {
		config: j.parse(e),
		seed: n,
		cursor: 0,
		players: [...t],
		people: {},
		hands: {},
		selected: {},
		extra: {},
		round: 1,
		phase: "select",
		actor: null,
		leader: t[0],
		role: null,
		brave: null,
		responders: [],
		lastPlayed: t[0],
		events: [],
		event: 0,
		curseDeck: [],
		curseAt: 0,
		bewitched: [],
		clouds: [],
		occupied: {},
		mountainTiles: {},
		forestTiles: {},
		hillTiles: {},
		jobs: [],
		resume: "respond",
		eventQueue: [],
		bids: {},
		squareUsed: {},
		log: [],
		extraWaiting: []
	}, i = I(r);
	for (let [e, n] of t.entries()) r.people[n] = {
		rid: n,
		points: 10,
		stock: [
			1,
			1,
			1,
			e === 0 || e === t.length - 1 ? 1 : 2
		],
		pawns: [...i.castles],
		lightning: 0,
		amulets: [],
		tiles: [],
		picked: !1,
		handCount: null,
		played: [],
		final: null
	};
	if (r.events = R(r, Array.from({ length: 10 }, (e, t) => t)).slice(0, 7), r.curseDeck = R(r, Array.from({ length: 10 }, (e, t) => t)), r.clouds = R(r, [...T, ...r.config.storms ? E : []]).slice(0, i.slots.length).map((e, t) => ({
		...e,
		id: t,
		slot: t
	})), r.config.mountains || r.config.board === "back") {
		let e = R(r, [
			"potions",
			"wands",
			"deliver",
			"moves",
			"cloud"
		]);
		i.mountains.forEach((t, n) => {
			r.mountainTiles[t] = e[n];
		});
	}
	if (r.config.board === "back") {
		let e = R(r, [
			"brave",
			"brave",
			"extra",
			"extra",
			"points",
			"points"
		]);
		i.forests.forEach((t, n) => {
			r.forestTiles[t] = e[n];
		});
		let t = R(r, [
			[1, 2],
			[2, 3],
			[1, 3],
			[],
			[0, 3],
			[0, 1]
		]);
		i.hills.forEach((e, n) => {
			r.hillTiles[e] = t[n];
		});
	}
	return fe(r), { state: r };
}
function me(e, t) {
	return I(e).areas[t].terrain !== "water" && !e.clouds.some((n) => I(e).slots[n.slot].area === t);
}
function he(e, t) {
	return Object.keys(e.mountainTiles).length > 0 && I(e).coveredTowers.includes(t);
}
function ge(e) {
	if (e.phase !== "effect" || !e.actor || e.jobs.length === 0) return [];
	let t = e.jobs[0], n = I(e), r = e.people[e.actor], i = [];
	if (t.kind === "mountain") for (let e of t.options ?? []) i.push({
		id: `mountain:${e}`,
		kind: "mountain",
		option: e
	});
	if (t.kind === "gain") {
		t.stock && i.push({
			id: "gain",
			kind: "gain",
			stock: t.stock
		});
		for (let e of t.options ?? []) {
			let t = le();
			e >= 0 && (t[e] = 1), i.push({
				id: `gain:${e}`,
				kind: "gain",
				stock: t,
				...e === -3 ? { points: 3 } : {}
			});
		}
	}
	if (t.kind === "works" && r.stock.every((e) => e > 0) && i.push({
		id: "works",
		kind: "works",
		points: 9
	}), t.kind === "move") for (let a of t.pawn === void 0 ? [0, 1] : [t.pawn]) for (let o of n.areas[r.pawns[a]].neighbors) me(e, o) && (!t.terrain || n.areas[o].terrain === t.terrain) && i.push({
		id: `move:${a}:${o}`,
		kind: "move",
		pawn: a,
		to: o
	});
	if (t.kind === "teleport") for (let e of t.options ?? []) {
		let r = n.circles[e];
		i.push({
			id: `teleport:${t.pawn}:${r}`,
			kind: "teleport",
			pawn: t.pawn,
			to: r
		});
	}
	if (t.kind === "deliver") for (let a of t.pawn === void 0 ? [0, 1] : [t.pawn]) {
		let o = r.pawns[a], s = n.areas[o].terrain;
		if ((t.source === void 0 || o === t.source) && (t.terrain !== "hill" || s === "hill" || s === "mountain") && (t.terrain !== "forest" || s === "forest" || s === "prairie")) {
			for (let s of n.towers) s.areas.includes(o) && r.stock[s.color] > 0 && !(s.id in e.occupied) && !he(e, s.id) && (!s.square || !e.squareUsed[e.actor]) && i.push({
				id: `deliver:${a}:${s.id}`,
				kind: "deliver",
				pawn: a,
				tower: s.id,
				points: s.points + (t.brave ? 3 : 0)
			});
			String(o) in e.hillTiles && e.hillTiles[o].length === 0 && r.stock[2] > 0 && !e.squareUsed[e.actor] && i.push({
				id: `virtual:${a}`,
				kind: "deliver",
				pawn: a,
				tower: -1,
				points: 7 + (t.brave ? 3 : 0)
			});
		}
	}
	if (t.kind === "cloud") for (let a of e.clouds) {
		let e = n.slots[a.slot];
		r.stock[3] >= a.cost && r.pawns.some((t) => e.adjacent.includes(t)) && i.push({
			id: `cloud:${a.id}`,
			kind: "cloud",
			cloud: a.id,
			points: t.brave ? 3 : 0
		});
	}
	return (t.optional !== !1 || i.length === 0) && i.push({
		id: "skip",
		kind: "skip"
	}), i;
}
function _e(e, t, n, r) {
	e.actor = t, e.phase = "effect", e.squareUsed[t] = !1;
	let i = [];
	n < 4 && i.push({
		kind: "move",
		terrain: [
			"forest",
			"prairie",
			"hill",
			"mountain"
		][n],
		brave: r
	}), n === 4 && i.push({
		kind: "gain",
		stock: r ? [
			2,
			0,
			0,
			1
		] : [
			1,
			0,
			0,
			0
		]
	}), n === 5 && (i.push({
		kind: "gain",
		stock: r ? [
			0,
			2,
			0,
			0
		] : [
			0,
			1,
			0,
			0
		]
	}), r && i.push({
		kind: "gain",
		options: [
			0,
			1,
			2
		]
	})), n === 6 && (r ? i.push({
		kind: "gain",
		stock: [
			0,
			0,
			1,
			2
		]
	}) : i.push({
		kind: "gain",
		options: [2, 3]
	})), (n === 7 || n === 8) && i.push({
		kind: "deliver",
		terrain: n === 7 ? "hill" : "forest",
		brave: r
	}), n === 9 && i.push({
		kind: "cloud",
		brave: r
	}), e.jobs = i;
}
function V(e) {
	e.phase = "beat", e.jobs = [];
}
function ve(e, t) {
	for (let n = 0; n < e.players.length; n++) {
		if (e.hands[t].length) return t;
		t = ue(e, t);
	}
	return t;
}
function H(e) {
	e.leader = ve(e, e.leader), e.actor = e.leader, e.role = null, e.brave = null, e.responders = [], e.phase = "play";
}
function ye(e) {
	if (e.responders.length) {
		e.actor = e.responders.shift(), e.phase = "play";
		return;
	}
	if (e.brave) {
		let t = e.brave;
		e.resume = "trick", _e(e, t, e.role, !0);
		return;
	}
	be(e);
}
function be(e) {
	if (e.brave && (e.leader = e.brave), e.players.every((t) => e.hands[t].length === 0)) {
		e.eventQueue = [...e.players], e.phase = "event", e.actor = null, e.jobs = [];
		return;
	}
	H(e);
}
function xe(e) {
	for (let t of e.players) {
		let n = e.people[t];
		n.final = {
			base: n.points,
			lightning: D[Math.min(7, n.lightning)],
			resources: O(n.stock),
			amulets: [
				0,
				4,
				9,
				15
			][n.amulets.length] ?? 15
		}, n.points = Object.values(n.final).reduce((e, t) => e + t, 0);
	}
	e.phase = "done", e.actor = null, e.role = null, e.jobs = [];
}
function Se(e) {
	e.round === 7 ? xe(e) : (e.round++, fe(e));
}
function Ce(e) {
	if (e.event === 7) {
		e.phase = "auction", e.actor = null;
		return;
	}
	if (!e.eventQueue.length) {
		Se(e);
		return;
	}
	let t = e.eventQueue.shift(), n = e.people[t], r = I(e);
	if (e.event === 4) {
		e.actor = t, e.phase = "effect", e.jobs = [{ kind: "works" }], e.resume = "event";
		return;
	}
	let i = 0;
	e.event === 0 && F(n.stock) <= 5 && (i = 3), e.event === 1 && (i = n.pawns.reduce((e, t) => e + {
		hill: 1,
		forest: 0,
		mountain: -1,
		prairie: 2,
		water: 0
	}[r.areas[t].terrain], 0)), e.event === 6 && r.areas[n.pawns[0]].terrain === r.areas[n.pawns[1]].terrain && (i = 4), e.event === 8 && (i = n.pawns.reduce((e, t) => e + {
		hill: -2,
		forest: -1,
		mountain: 0,
		prairie: -3,
		water: 0
	}[r.areas[t].terrain], 0)), B(e, t, i);
}
function we(e, t) {
	switch (e.mountainTiles[t]) {
		case "potions": return [{
			kind: "gain",
			stock: [
				1,
				1,
				1,
				0
			]
		}];
		case "wands": return [{
			kind: "gain",
			stock: [
				0,
				0,
				0,
				2
			]
		}];
		case "deliver": return [{ kind: "deliver" }];
		case "moves": return [{ kind: "move" }, { kind: "move" }];
		case "cloud": return [{ kind: "cloud" }];
	}
	return [];
}
function Te(e, t, n, r = !1) {
	let i = e.people[e.actor], a = [];
	return String(n) in e.forestTiles && (i.tiles.push(e.forestTiles[n]), delete e.forestTiles[n], z(e, {
		kind: "tile",
		rid: e.actor,
		to: n
	})), String(n) in e.hillTiles && e.hillTiles[n].length && a.push({
		kind: "teleport",
		pawn: t,
		options: e.hillTiles[n],
		optional: !1
	}), String(n) in e.mountainTiles && !i.amulets.includes(n) ? (i.amulets.push(n), z(e, {
		kind: "tile",
		rid: e.actor,
		to: n
	}), a.push({
		kind: "mountain",
		source: n,
		pawn: t,
		options: r ? [0, 1] : [0]
	})) : r && a.push({
		kind: "deliver",
		pawn: t,
		source: e.hillTiles[n]?.length ? void 0 : n
	}), a;
}
function Ee(e, t) {
	let n = e.actor, r = e.people[n], i = I(e), a = e.jobs.shift(), o = [];
	if (t.kind === "move" || t.kind === "teleport") {
		let i = r.pawns[t.pawn], s = e.players.flatMap((t) => e.people[t].pawns.map((e, n) => ({
			rid: t,
			pawn: n,
			area: e
		}))).filter((e) => e.area === i).findIndex((e) => e.rid === n && e.pawn === t.pawn);
		r.pawns[t.pawn] = t.to, z(e, {
			kind: "move",
			rid: n,
			from: i,
			to: t.to
		}), o.push({
			kind: "move",
			rid: n,
			data: {
				pawn: t.pawn,
				from: i,
				to: t.to,
				fromPlace: s
			}
		});
		let c = Te(e, t.pawn, t.to, t.kind === "move" && a.brave);
		e.jobs.unshift(...c);
	}
	if (t.kind === "mountain") {
		let n = (a.options ?? []).filter((e) => e !== t.option), r = n.length ? [{
			...a,
			options: n
		}] : [];
		e.jobs.unshift(...t.option === 0 ? we(e, a.source) : [{
			kind: "deliver",
			pawn: a.pawn,
			source: a.source
		}], ...r);
	}
	if (t.kind === "deliver") {
		let s = t.tower === -1 ? {
			color: 2,
			points: 7,
			wands: 0,
			square: !0
		} : i.towers[t.tower];
		r.stock[s.color]--, r.stock[3] += s.wands, s.square ? e.squareUsed[n] = !0 : e.occupied[t.tower] = n;
		let c = e.clouds.filter((e) => e.effect === "bonus" && i.slots[e.slot].adjacent.includes(r.pawns[t.pawn])).length * 2, l = s.points + (a.brave ? 3 : 0) + c;
		B(e, n, l), z(e, {
			kind: "deliver",
			rid: n,
			n: l,
			to: t.tower
		}), o.push({
			kind: "deliver",
			rid: n,
			data: {
				tower: t.tower,
				area: r.pawns[t.pawn],
				color: s.color,
				points: l
			}
		});
	}
	if (t.kind === "cloud") {
		let i = e.clouds.find((e) => e.id === t.cloud);
		r.stock[3] -= i.cost, r.lightning += i.lightning, e.clouds = e.clouds.filter((e) => e.id !== i.id);
		let s = a.brave ? 3 : 0, c = i.effect;
		c === "orange" && r.stock[2] >= 3 && (s += 7), c === "green" && r.stock[0] >= 4 && (s += 8), c === "purple" && r.stock[1] >= 4 && (s += 9), B(e, n, s), z(e, {
			kind: "cloud",
			rid: n,
			n: i.lightning,
			to: i.slot
		}), c === "move" && e.jobs.unshift({ kind: "move" }), c === "deliver" && e.jobs.unshift({ kind: "deliver" }), o.push({
			kind: "cloud",
			rid: n,
			data: {
				slot: i.slot,
				lightning: i.lightning,
				cost: i.cost,
				effect: i.effect,
				points: s
			}
		});
	}
	if (t.kind === "gain") {
		let i = t.stock;
		r.stock = r.stock.map((e, t) => e + i[t]), z(e, {
			kind: "gain",
			rid: n,
			n: F(i)
		}), t.points && B(e, n, t.points), a.replacement && (e.jobs = []), o.push({
			kind: "gain",
			rid: n,
			data: { stock: i }
		});
	}
	if (t.kind === "works") {
		for (let e = 0; e < 4; e++) r.stock[e]--;
		B(e, n, 9), o.push({
			kind: "score",
			rid: n,
			data: { points: 9 }
		});
	}
	return t.kind === "skip" && a.kind === "move" && a.brave, e.jobs.length || V(e), o;
}
function De(e, t, n) {
	if (t.type === "tick") {
		if (![
			"beat",
			"reveal",
			"event"
		].includes(e.phase)) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		return t.phase === "reveal" ? (t.extraWaiting = t.players.filter((e) => !t.extra[e] && t.people[e].tiles.includes("extra")), t.extraWaiting.length ? t.phase = "extra" : H(t)) : t.phase === "event" ? Ce(t) : t.resume === "respond" ? ye(t) : t.resume === "trick" ? be(t) : (t.phase = "event", t.actor = null), {
			state: t,
			fx: []
		};
	}
	if (!e.players.includes(n.by)) return L();
	let r = n.by, i = e.people[r];
	if (t.type === "extraCard") {
		if (e.phase !== "extra" || !e.extraWaiting.includes(r) || t.role !== null && e.hands[r].includes(t.role)) return L();
		let n = structuredClone(e);
		if (n.extraWaiting = n.extraWaiting.filter((e) => e !== r), t.role !== null && (n.hands[r].push(t.role), n.extra[r] = !0, n.people[r].tiles.splice(n.people[r].tiles.indexOf("extra"), 1)), !n.extraWaiting.length) {
			for (let e of n.players) n.people[e].handCount = n.hands[e].length;
			H(n);
		}
		return {
			state: n,
			fx: []
		};
	}
	if (t.type === "select") {
		if (e.phase !== "select" || r in e.selected || new Set(t.roles).size !== t.roles.length) return L();
		let n = t.extra && i.tiles.includes("extra"), a = t.roles.length - +!!n;
		if (t.extra && !n || (e.event === 3 ? a < 1 || a > 5 : a !== 4)) return L();
		let o = structuredClone(e);
		if (o.selected[r] = [...t.roles].sort((e, t) => e - t), o.extra[r] = n, o.people[r].picked = !0, n && o.people[r].tiles.splice(o.people[r].tiles.indexOf("extra"), 1), o.players.every((e) => e in o.selected)) {
			for (let e of o.players) o.hands[e] = [...o.selected[e]], o.people[e].handCount = o.hands[e].length, o.event === 3 && B(o, e, [
				10,
				6,
				3,
				0,
				-3
			][o.hands[e].length - +!!o.extra[e] - 1]);
			return o.phase = "reveal", {
				state: o,
				fx: [{ kind: "reveal" }]
			};
		}
		return {
			state: o,
			fx: []
		};
	}
	if (t.type === "bid") {
		if (e.phase !== "auction" || r in e.bids || t.stock.some((e, t) => e > i.stock[t])) return L();
		let n = structuredClone(e);
		if (n.bids[r] = [...t.stock], n.players.every((e) => e in n.bids)) {
			let e = Math.max(...n.players.map((e) => F(n.bids[e]))), t = [];
			for (let r of n.players) {
				let i = F(n.bids[r]);
				z(n, {
					kind: "bid",
					rid: r,
					n: i
				}), i === e && (n.people[r].stock = n.people[r].stock.map((e, t) => e - n.bids[r][t]), B(n, r, 8), t.push({
					kind: "score",
					rid: r,
					data: { points: 8 },
					with: !0
				}));
			}
			return Se(n), {
				state: n,
				fx: t
			};
		}
		return {
			state: n,
			fx: []
		};
	}
	if (t.type === "choose") {
		if (e.phase !== "effect" || e.actor !== r) return L();
		let n = ge(e).find((e) => e.id === t.id);
		if (!n) return L();
		let i = structuredClone(e);
		return {
			state: i,
			fx: Ee(i, n)
		};
	}
	if (e.phase !== "play" || e.actor !== r) return L();
	if (t.type === "pass") {
		if (e.role === null || e.hands[r].includes(e.role)) return L();
		let t = structuredClone(e);
		return z(t, {
			kind: "pass",
			rid: r
		}), t.resume = "respond", V(t), {
			state: t,
			fx: []
		};
	}
	if (t.type !== "play" || !e.hands[r].includes(t.role) || e.role !== null && e.role !== t.role || t.tile !== "none" && (t.brave || !i.tiles.includes(t.tile)) || e.event === 9 && e.role === null && !t.brave) return L();
	let a = structuredClone(e), o = a.people[r];
	if (a.lastPlayed = r, a.hands[r] = a.hands[r].filter((e) => e !== t.role), o.played.push(t.role), o.handCount = a.hands[r].length, a.role === null) {
		a.role = t.role;
		let e = ue(a, r);
		for (; e !== r;) a.responders.push(e), e = ue(a, e);
	}
	a.bewitched.includes(t.role) && B(a, r, -3), z(a, {
		kind: "play",
		rid: r,
		role: t.role,
		brave: t.brave
	});
	let s = [{
		kind: "play",
		rid: r,
		data: {
			role: t.role,
			brave: t.brave
		}
	}];
	return a.resume = "respond", t.brave ? (a.brave && s.push({
		kind: "usurp",
		rid: a.brave,
		with: !0
	}), a.brave = r, V(a)) : (t.tile !== "none" && o.tiles.splice(o.tiles.indexOf(t.tile), 1), _e(a, r, t.role, t.tile === "brave"), t.tile === "points" ? (a.jobs = [{
		kind: "gain",
		stock: le()
	}], B(a, r, 5), V(a), s.push({
		kind: "score",
		rid: r,
		data: { points: 5 },
		with: !0
	})) : t.tile === "none" && a.event === 2 ? a.jobs.unshift({
		kind: "gain",
		options: [-3],
		replacement: !0
	}) : t.tile === "none" && a.event === 5 && a.jobs.unshift({
		kind: "gain",
		options: [
			0,
			1,
			2,
			3
		],
		replacement: !0
	})), {
		state: a,
		fx: s
	};
}
function Oe(e, t) {
	return {
		public: {
			config: e.config,
			round: e.round,
			phase: e.phase,
			actor: e.actor,
			leader: e.leader,
			role: e.role,
			brave: e.brave,
			event: e.event,
			bewitched: e.bewitched,
			players: e.players.map((t) => ({
				...e.people[t],
				tiles: [...e.people[t].tiles],
				handCount: e.phase === "select" ? null : e.people[t].handCount
			})),
			clouds: e.clouds,
			occupied: e.occupied,
			mountainTiles: e.mountainTiles,
			forestTiles: e.forestTiles,
			hillTiles: e.hillTiles,
			job: e.jobs[0]?.kind ?? null,
			log: e.log.slice(-120),
			auctionReady: Object.keys(e.bids),
			extraWaiting: e.extraWaiting
		},
		private: {
			hand: e.hands[t] ?? [],
			selected: e.selected[t] ?? null,
			extra: e.extra[t] ?? !1,
			choices: e.actor === t ? ge(e) : [],
			bid: e.bids[t] ?? null
		}
	};
}
function ke(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.people[n].points - e.people[t].points || F(e.people[n].stock) - F(e.people[t].stock)), n = e.people[t[0]];
	return {
		phase: "done",
		ranking: t,
		winner: t.filter((t) => e.people[t].points === n.points && F(e.people[t].stock) === F(n.stock)),
		scores: Object.fromEntries(e.players.map((t) => [t, e.people[t].points]))
	};
}
var Ae = {
	meta: oe,
	saveCompatibility: { version: "1" },
	schemas: {
		action: M,
		publicView: P,
		privateView: ce,
		config: j
	},
	setup: pe,
	reduce: De,
	viewFor: Oe,
	status: ke,
	nextTickIn: (e) => [
		"beat",
		"reveal",
		"event"
	].includes(e.phase) ? 620 : null
}, U = [
	"#79a94b",
	"#9e3f83",
	"#e88532",
	"#9de0ed"
];
function W({ color: e, size: t = 24 }) {
	return /* @__PURE__ */ p("svg", {
		width: t,
		height: t,
		viewBox: "0 0 32 32",
		"aria-hidden": !0,
		children: e === 3 ? /* @__PURE__ */ m(f, { children: [
			/* @__PURE__ */ p("path", {
				d: "M4 27 25 6",
				stroke: "#61472e",
				strokeWidth: "5",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ p("path", {
				d: "m20 5 7-3-1 8-4 1Z",
				fill: "#b5f3fa",
				stroke: "#487c9b"
			}),
			/* @__PURE__ */ p("path", {
				d: "m25 0 1 5 6 1-6 2-1 5-2-5-5-2 6-1Z",
				fill: "#ddfaff"
			})
		] }) : /* @__PURE__ */ m(f, { children: [
			/* @__PURE__ */ p("path", {
				d: "M11 3h10v6l5 7c7 15-27 15-20 0l5-7Z",
				fill: "#e1ded0",
				stroke: "#4d3d4d",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ p("path", {
				d: "M7 18c2-3 6 0 9-1s6-2 9 1c5 11-23 11-18 0",
				fill: U[e]
			}),
			/* @__PURE__ */ p("rect", {
				x: "11",
				y: "1",
				width: "10",
				height: "5",
				rx: "1",
				fill: "#ad7b48",
				stroke: "#59402b"
			}),
			/* @__PURE__ */ p("path", {
				d: "M10 17v5",
				stroke: "#fff",
				strokeWidth: "3",
				strokeLinecap: "round",
				opacity: ".75"
			})
		] })
	});
}
function je({ color: e = "#86649c", size: t = 42 }) {
	return /* @__PURE__ */ m("svg", {
		width: t,
		height: t,
		viewBox: "0 0 50 50",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ p("path", {
				d: "m3 39 41-7",
				stroke: "#623c25",
				strokeWidth: "4"
			}),
			/* @__PURE__ */ p("path", {
				d: "m39 29 9-1-2 12-9-6Z",
				fill: "#e4b556",
				stroke: "#714728"
			}),
			/* @__PURE__ */ p("path", {
				d: "m12 41 4-18 14-3 9 15-13-2-4 10Z",
				fill: e,
				stroke: "#31243a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ p("path", {
				d: "m11 21 8-7L23 1l6 12 10 6Z",
				fill: e,
				stroke: "#31243a",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ p("circle", {
				cx: "25",
				cy: "22",
				r: "5",
				fill: "#eec99c"
			}),
			/* @__PURE__ */ p("path", {
				d: "m17 24-8 6 8 3",
				fill: e,
				stroke: "#31243a",
				strokeWidth: "2"
			})
		]
	});
}
function Me({ color: e, square: t, points: n, wands: r, occupied: i }) {
	return /* @__PURE__ */ m("g", { children: [
		/* @__PURE__ */ p("ellipse", {
			cy: "13",
			rx: "15",
			ry: "4",
			fill: "#382d37",
			opacity: ".22"
		}),
		t ? /* @__PURE__ */ m(f, { children: [
			/* @__PURE__ */ p("path", {
				d: "M-13-13h26v25h-26Z",
				fill: "#a8aa8b",
				stroke: "#53464b",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ p("path", {
				d: "m-16-13 16-20 16 20Z",
				fill: U[e],
				stroke: "#49414b",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ p("path", {
				d: "M0-33v-8l10 3-10 3",
				fill: U[e],
				stroke: "#51404a",
				strokeWidth: "1"
			})
		] }) : /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", {
			d: "M-10-15h20l2 27c-7 5-17 5-24 0Z",
			fill: "#fff4cd",
			stroke: "#6a5a55",
			strokeWidth: "1.5"
		}), /* @__PURE__ */ p("path", {
			d: "m-14-15 14-22 14 22Z",
			fill: U[e],
			stroke: "#51434a",
			strokeWidth: "1.5"
		})] }),
		/* @__PURE__ */ p("path", {
			d: "M-3-10h6v7h-6Z",
			fill: "#544256"
		}),
		n !== void 0 && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", {
			d: "M0 1 13 0l-2 13L1 17-6 9Z",
			fill: "#dfab4a",
			stroke: "#77522d",
			strokeWidth: "1.2"
		}), /* @__PURE__ */ p("text", {
			x: "4",
			y: "11",
			textAnchor: "middle",
			fontSize: "12",
			fill: "#382b36",
			fontWeight: "900",
			children: n
		})] }),
		r > 0 && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("rect", {
			x: "-13",
			y: "16",
			width: "26",
			height: "10",
			rx: "5",
			fill: "#bce8ec",
			stroke: "#426d86"
		}), /* @__PURE__ */ p("text", {
			y: "24",
			textAnchor: "middle",
			fontSize: "9",
			fontWeight: "bold",
			fill: "#284554",
			children: r
		})] }),
		i && /* @__PURE__ */ p("circle", {
			cx: "-13",
			cy: "-24",
			r: "8",
			fill: U[e],
			stroke: "#fff",
			strokeWidth: "2"
		})
	] });
}
function G({ cost: e, lightning: t, effect: n }) {
	return /* @__PURE__ */ m("g", { children: [
		/* @__PURE__ */ p("path", {
			d: "M-34 8c-18-9-11-24 1-26 1-13 16-17 26-9 8-10 23-9 28 1 17-5 29 7 24 19 10 15-8 26-20 23-10 11-24 8-30 3-14 7-31 1-29-11Z",
			fill: n && n !== "none" ? "#64b8ca" : "#348aa9",
			stroke: "#1b576e",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ p("path", {
			d: "m-20-17 4 5 7-2-2 7 5 5-8 2-3 7-4-6-7-1 4-6-2-6Z",
			fill: "#d6eef0"
		}),
		/* @__PURE__ */ p("text", {
			x: "-18",
			y: "1",
			textAnchor: "middle",
			fill: "#214e67",
			fontSize: "16",
			fontWeight: "900",
			children: e ?? "?"
		}),
		/* @__PURE__ */ p("path", {
			d: "m9-17-4 15h6L8 13 25-6H15l6-11Z",
			fill: "#f6d560",
			stroke: "#a2762e"
		}),
		/* @__PURE__ */ p("text", {
			x: "28",
			y: "16",
			textAnchor: "middle",
			fill: "#e7faff",
			fontSize: "11",
			fontWeight: "bold",
			children: t ?? ""
		}),
		n && n !== "none" && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("rect", {
			x: "-35",
			y: "20",
			width: "72",
			height: "17",
			rx: "7",
			fill: "#f7edbf",
			stroke: "#5d6880"
		}), /* @__PURE__ */ p("text", {
			x: "0",
			y: "33",
			textAnchor: "middle",
			fontSize: "12",
			fontWeight: "bold",
			fill: n === "orange" ? U[2] : n === "green" ? U[0] : n === "purple" ? U[1] : "#3b4b66",
			children: n === "bonus" ? "+2" : n === "move" ? "↝" : n === "deliver" ? "↗" : n === "orange" ? "3 → 7" : n === "green" ? "4 → 8" : "4 → 9"
		})] })
	] });
}
function K({ x: e, y: t, w: n, h: r, ellipse: i = !1 }) {
	let a = {
		fill: "none",
		stroke: "#fff",
		strokeWidth: 3,
		strokeDasharray: "8 5",
		pointerEvents: "none"
	};
	return i ? /* @__PURE__ */ p("ellipse", {
		cx: e + n / 2,
		cy: t + r / 2,
		rx: n / 2,
		ry: r / 2,
		...a,
		children: /* @__PURE__ */ p("animate", {
			attributeName: "stroke-dashoffset",
			from: "0",
			to: "-26",
			dur: ".8s",
			repeatCount: "indefinite"
		})
	}) : /* @__PURE__ */ p("rect", {
		x: e,
		y: t,
		width: n,
		height: r,
		rx: "8",
		...a,
		children: /* @__PURE__ */ p("animate", {
			attributeName: "stroke-dashoffset",
			from: "0",
			to: "-26",
			dur: ".8s",
			repeatCount: "indefinite"
		})
	});
}
function Ne() {
	return /* @__PURE__ */ p("span", {
		className: "bs-any-potion",
		children: [
			0,
			1,
			2
		].map((e) => /* @__PURE__ */ p(W, {
			color: e,
			size: 18
		}, e))
	});
}
function Pe({ terrain: e }) {
	return /* @__PURE__ */ p("svg", {
		width: "28",
		height: "22",
		viewBox: "0 0 32 24",
		"aria-hidden": !0,
		children: e === 0 ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", {
			d: "m2 20 7-15 7 15Zm12 0 8-18 8 18Z",
			fill: "#43764d",
			stroke: "#254b3b"
		}), /* @__PURE__ */ p("path", {
			d: "M9 19v5m13-5v5",
			stroke: "#71512e",
			strokeWidth: "3"
		})] }) : e === 1 ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", {
			d: "M1 22h30V12L1 17Z",
			fill: "#e7c452"
		}), /* @__PURE__ */ p("path", {
			d: "m6 21 3-12 3 12m6 0 3-17 4 17",
			stroke: "#819244",
			fill: "none"
		})] }) : e === 2 ? /* @__PURE__ */ p("path", {
			d: "M1 21C4 1 12 3 18 14 24-1 30 10 31 21Z",
			fill: "#ba714a",
			stroke: "#874c3b"
		}) : /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("path", {
			d: "m1 22 10-18 6 10L24 2l7 20Z",
			fill: "#7c8695",
			stroke: "#4b5569"
		}), /* @__PURE__ */ p("path", {
			d: "m7 12 4-8 5 9-5-3Zm13-2 4-8 5 12-5-5Z",
			fill: "#eeeade"
		})] })
	});
}
function Fe() {
	return /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ p(Ne, {}),
		/* @__PURE__ */ p("span", { children: "→" }),
		/* @__PURE__ */ p("svg", {
			width: "22",
			height: "30",
			viewBox: "-20 -40 40 70",
			children: /* @__PURE__ */ p(Me, {
				color: 1,
				square: !1,
				wands: 0
			})
		})
	] });
}
function Ie({ effect: e }) {
	return /* @__PURE__ */ p("foreignObject", {
		x: "-27",
		y: "-20",
		width: "54",
		height: "42",
		children: /* @__PURE__ */ p("div", {
			className: "bs-tile-symbol",
			children: e === "potions" ? /* @__PURE__ */ p(Ne, {}) : e === "wands" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(W, { color: 3 }), /* @__PURE__ */ p(W, { color: 3 })] }) : e === "moves" ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(je, { size: 25 }), /* @__PURE__ */ p("b", { children: "↝ 2" })] }) : e === "cloud" ? /* @__PURE__ */ p("svg", {
				width: "50",
				height: "35",
				viewBox: "-50 -35 100 70",
				children: /* @__PURE__ */ p(G, {})
			}) : e === "deliver" ? /* @__PURE__ */ p(Fe, {}) : /* @__PURE__ */ p("b", { children: e === "extra" ? "+1" : e === "points" ? "+5" : "↑" })
		})
	});
}
function Le({ role: e, brave: t }) {
	let n;
	return n = e < 4 ? /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ p(Pe, { terrain: e }),
		/* @__PURE__ */ p("span", { children: "↝" }),
		t && /* @__PURE__ */ p(Fe, {})
	] }) : e === 4 ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(W, { color: 0 }), t && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(W, { color: 0 }), /* @__PURE__ */ p(W, { color: 3 })] })] }) : e === 5 ? /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(W, { color: 1 }), t && /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ p(W, { color: 1 }),
		/* @__PURE__ */ p("span", { children: "＋" }),
		/* @__PURE__ */ p(Ne, {})
	] })] }) : e === 6 ? t ? /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ p(W, { color: 2 }),
		/* @__PURE__ */ p(W, { color: 3 }),
		/* @__PURE__ */ p(W, { color: 3 })
	] }) : /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ p(W, { color: 2 }),
		/* @__PURE__ */ p("span", { children: "/" }),
		/* @__PURE__ */ p(W, { color: 3 })
	] }) : e === 7 || e === 8 ? /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ p(Pe, { terrain: e === 7 ? 2 : 0 }),
		/* @__PURE__ */ p(Pe, { terrain: e === 7 ? 3 : 1 }),
		/* @__PURE__ */ p(Fe, {}),
		t && /* @__PURE__ */ p("b", { children: "＋3" })
	] }) : /* @__PURE__ */ m(f, { children: [
		/* @__PURE__ */ p(W, { color: 3 }),
		/* @__PURE__ */ p("span", { children: "→" }),
		/* @__PURE__ */ p("svg", {
			width: "32",
			height: "25",
			viewBox: "-50 -35 100 70",
			children: /* @__PURE__ */ p(G, {})
		}),
		t && /* @__PURE__ */ p("b", { children: "＋3" })
	] }), /* @__PURE__ */ p("span", {
		className: "bs-effect-symbols",
		children: n
	});
}
var Re = [
	"#4d7850",
	"#d3ab4b",
	"#bc713f",
	"#7b8892",
	"#7eaa45",
	"#a45088",
	"#d47b3d",
	"#897fa0",
	"#82975e",
	"#5998b6"
];
function ze({ role: e, selected: t, disabled: n, curse: i, onClick: a }) {
	let o = r();
	return /* @__PURE__ */ m("button", {
		type: "button",
		className: "bs-role",
		style: { "--bs-role": Re[e] },
		"data-selected": t || void 0,
		disabled: n,
		onClick: a,
		"aria-pressed": t,
		children: [
			/* @__PURE__ */ p("strong", { children: o(x[e]) }),
			/* @__PURE__ */ p("img", {
				src: `games/broomservice/role-${e}.svg`,
				alt: "",
				draggable: !1
			}),
			i && /* @__PURE__ */ p("span", {
				className: "bs-curse",
				children: "−3"
			}),
			/* @__PURE__ */ m("span", {
				className: "bs-role-effect",
				children: [
					/* @__PURE__ */ p("span", { children: o("games.broomservice.brave") }),
					/* @__PURE__ */ p(Le, {
						role: e,
						brave: !0
					}),
					/* @__PURE__ */ p("small", { children: o(e < 4 ? "games.broomservice.moveDeliver" : e === 7 || e === 8 ? "games.broomservice.deliverBonus" : e === 9 ? "games.broomservice.cloudBonus" : "games.broomservice.takeShown") })
				]
			}),
			/* @__PURE__ */ m("span", {
				className: "bs-role-effect",
				children: [
					/* @__PURE__ */ p("span", { children: o("games.broomservice.coward") }),
					/* @__PURE__ */ p(Le, {
						role: e,
						brave: !1
					}),
					/* @__PURE__ */ p("small", { children: o(e < 4 ? "games.broomservice.moveOnly" : e === 7 || e === 8 ? "games.broomservice.deliverOnly" : e === 9 ? "games.broomservice.cloudOnly" : "games.broomservice.takeShown") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/broomservice/view-player.tsx
function Be(e) {
	return /* @__PURE__ */ p(We, {
		...e,
		pub: e.public,
		priv: e.private
	}, `${e.myRid}:${e.public.round}`);
}
var q = (e, t) => {
	(e.key === "Enter" || e.key === " ") && (e.preventDefault(), t());
};
function Ve({ pub: e, members: t, myRid: i, choices: a = [], send: o, readOnly: u = !1 }) {
	let d = r(), f = w[e.config.board], h = (e) => t.find((t) => t.rid === e)?.name ?? e, [g, _] = n(0), v = a.filter((e) => e.kind === "move" || e.kind === "teleport"), y = [...new Set(v.map((e) => e.pawn))], b = y.includes(g) ? g : y[0], x = (e) => {
		e && !u && o?.({
			type: "choose",
			id: e.id
		});
	};
	return /* @__PURE__ */ p("div", {
		className: "bs-map",
		children: /* @__PURE__ */ m(l, {
			sheetW: 1e3,
			sheetH: 646,
			image: `games/broomservice/${e.config.board}.svg`,
			fitKey: e.config.board,
			clampToSheet: !0,
			children: [
				f.towers.map((t) => {
					let n = a.find((e) => e.kind === "deliver" && e.tower === t.id);
					if (Object.keys(e.mountainTiles).length > 0 && f.coveredTowers.includes(t.id)) return null;
					let r = d("games.broomservice.towerLabel", {
						color: d(S[t.color]),
						n: t.points,
						wands: t.wands
					});
					return /* @__PURE__ */ m("g", {
						transform: `translate(${t.x} ${t.y})`,
						role: n ? "button" : void 0,
						tabIndex: n ? 0 : void 0,
						"aria-label": r,
						onPointerDown: n ? (e) => e.stopPropagation() : void 0,
						onClick: () => x(n),
						onKeyDown: (e) => q(e, () => x(n)),
						className: n ? "bs-target" : "",
						children: [
							/* @__PURE__ */ p("title", { children: r }),
							/* @__PURE__ */ p(Me, {
								...t,
								occupied: t.id in e.occupied
							}),
							n && /* @__PURE__ */ p(K, {
								x: -19,
								y: -43,
								w: 38,
								h: 72
							}),
							/* @__PURE__ */ p(c, {
								name: `tower:${t.id}`,
								r: {
									x: -17,
									y: -40,
									w: 34,
									h: 60
								}
							})
						]
					}, t.id);
				}),
				Object.entries(e.mountainTiles).map(([n, r]) => {
					let [i, a] = f.mountainPositions[Number(n)];
					return /* @__PURE__ */ m("g", {
						transform: `translate(${i} ${a})`,
						children: [
							/* @__PURE__ */ p("path", {
								d: "m-25-13 12-13h26l12 13v26l-12 13h-26l-12-13Z",
								fill: "#b6a6c3",
								stroke: "#5b4d68",
								strokeWidth: "2"
							}),
							/* @__PURE__ */ p(Ie, { effect: r }),
							e.players.map((r, i) => {
								let a = r.amulets.includes(Number(n)), o = s[(t.find((e) => e.rid === r.rid)?.colorIndex ?? i) % s.length].hex;
								return /* @__PURE__ */ p("path", {
									d: "M0-5 5 0 0 5-5 0Z",
									transform: `translate(${(i - (e.players.length - 1) / 2) * 13} 34)`,
									fill: a ? "#d7d0d8" : o,
									stroke: a ? "#9b919e" : "#fff9e9",
									strokeWidth: "1.5",
									children: /* @__PURE__ */ p("title", { children: d(a ? "games.broomservice.amuletClaimed" : "games.broomservice.amuletAvailable", { name: h(r.rid) }) })
								}, r.rid);
							})
						]
					}, n);
				}),
				Object.entries(e.forestTiles).map(([e, t]) => {
					let [n, r] = f.forestPositions[Number(e)];
					return /* @__PURE__ */ m("g", {
						transform: `translate(${n} ${r})`,
						children: [/* @__PURE__ */ p("rect", {
							x: "-20",
							y: "-18",
							width: "40",
							height: "36",
							rx: "10",
							fill: "#e6eed0",
							stroke: "#417044",
							strokeWidth: "3"
						}), /* @__PURE__ */ p(Ie, { effect: t })]
					}, e);
				}),
				Object.entries(e.hillTiles).map(([t, n]) => {
					let r = f.areas[Number(t)], o = a.find((t) => t.tower === -1 && e.players.find((e) => e.rid === i)?.pawns[t.pawn] === r.id);
					return /* @__PURE__ */ m("g", {
						transform: `translate(${r.x} ${r.y})`,
						role: o ? "button" : void 0,
						tabIndex: o ? 0 : void 0,
						onPointerDown: o ? (e) => e.stopPropagation() : void 0,
						onClick: () => x(o),
						onKeyDown: (e) => q(e, () => x(o)),
						"aria-label": d("games.broomservice.hillTile"),
						children: [
							/* @__PURE__ */ p("path", {
								d: "m-24-14 12-12h24l12 12v28l-12 12h-24l-12-12Z",
								fill: "#d9a75d",
								stroke: "#7e4a34",
								strokeWidth: "2"
							}),
							/* @__PURE__ */ p("text", {
								textAnchor: "middle",
								y: "5",
								fontSize: "16",
								children: n.length ? n.map((e) => "ABCD"[e]).join(" / ") : "7"
							}),
							o && /* @__PURE__ */ p(K, {
								x: -28,
								y: -30,
								w: 56,
								h: 60
							})
						]
					}, t);
				}),
				e.clouds.map((e) => {
					let t = f.slots[e.slot], n = a.find((t) => t.cloud === e.id);
					return /* @__PURE__ */ m("g", {
						transform: `translate(${t.x} ${t.y})`,
						role: n ? "button" : void 0,
						tabIndex: n ? 0 : void 0,
						onPointerDown: n ? (e) => e.stopPropagation() : void 0,
						onClick: () => x(n),
						onKeyDown: (e) => q(e, () => x(n)),
						"aria-label": d("games.broomservice.cloudLabel", {
							cost: e.cost,
							n: e.lightning
						}),
						className: n ? "bs-target" : "",
						children: [/* @__PURE__ */ p(G, { ...e }), n && /* @__PURE__ */ p(K, {
							x: -49,
							y: -35,
							w: 98,
							h: 63,
							ellipse: !0
						})]
					}, e.id);
				}),
				f.slots.map((e, t) => /* @__PURE__ */ p(c, {
					name: `cloud:${t}`,
					r: {
						x: e.x - 40,
						y: e.y - 25,
						w: 80,
						h: 50
					}
				}, t)),
				v.filter((e) => e.pawn === b).map((e) => {
					let t = f.areas[e.to];
					return /* @__PURE__ */ m("g", {
						transform: `translate(${t.x} ${t.y})`,
						role: "button",
						tabIndex: 0,
						"aria-label": d("games.broomservice.moveTo", {
							terrain: d(ne[t.terrain]),
							n: t.id + 1
						}),
						onPointerDown: (e) => e.stopPropagation(),
						onClick: () => x(e),
						onKeyDown: (t) => q(t, () => x(e)),
						className: "bs-target",
						children: [
							/* @__PURE__ */ p("ellipse", {
								rx: "34",
								ry: "22",
								fill: "#f8f3d8",
								fillOpacity: ".75",
								stroke: "#6c4d85",
								strokeWidth: "3"
							}),
							/* @__PURE__ */ p("text", {
								y: "6",
								textAnchor: "middle",
								fontSize: "23",
								fill: "#60426e",
								children: "↝"
							}),
							/* @__PURE__ */ p(K, {
								x: -34,
								y: -22,
								w: 68,
								h: 44,
								ellipse: !0
							})
						]
					}, e.id);
				}),
				e.players.flatMap((n, r) => n.pawns.map((a, o) => {
					let c = f.areas[a], l = e.players.flatMap((e) => e.pawns.map((t, n) => ({
						rid: e.rid,
						pawn: n,
						area: t
					}))).filter((e) => e.area === a).findIndex((e) => e.rid === n.rid && e.pawn === o), u = c.x + (l % 3 - 1) * 32, g = c.y + 15 + Math.floor(l / 3) * 34, v = n.rid === i && y.includes(o), x = s[(t.find((e) => e.rid === n.rid)?.colorIndex ?? r) % s.length].hex;
					return /* @__PURE__ */ m("g", {
						transform: `translate(${u} ${g})`,
						pointerEvents: v ? "auto" : "none",
						role: v ? "button" : void 0,
						tabIndex: v ? 0 : void 0,
						"aria-label": d("games.broomservice.pawnLabel", {
							name: h(n.rid),
							n: o + 1
						}),
						onPointerDown: v ? (e) => e.stopPropagation() : void 0,
						onClick: () => v && _(o),
						onKeyDown: (e) => q(e, () => v && _(o)),
						children: [
							/* @__PURE__ */ p("title", { children: d("games.broomservice.pawnLabel", {
								name: h(n.rid),
								n: o + 1
							}) }),
							v && /* @__PURE__ */ p("ellipse", {
								cx: "14",
								cy: "13",
								rx: "21",
								ry: "20",
								fill: b === o ? "#fff7bc" : "#dcd1ef",
								stroke: "#5e426b",
								strokeWidth: "2"
							}),
							/* @__PURE__ */ p(He, {
								name: `pawn:${n.rid}:${o}`,
								color: x
							})
						]
					}, `${n.rid}:${o}`);
				})),
				f.areas.map((e) => /* @__PURE__ */ p(c, {
					name: `area:${e.id}`,
					r: {
						x: e.x - 20,
						y: e.y - 15,
						w: 40,
						h: 40
					}
				}, e.id))
			]
		})
	});
}
function He({ name: e, color: t }) {
	let { ref: n, hidden: r } = a(e);
	return /* @__PURE__ */ p("foreignObject", {
		x: "-5",
		y: "-10",
		width: "38",
		height: "38",
		children: /* @__PURE__ */ p("div", {
			ref: n,
			style: {
				width: 38,
				height: 38,
				visibility: r ? "hidden" : void 0
			},
			children: /* @__PURE__ */ p(je, {
				color: t,
				size: 38
			})
		})
	});
}
function Ue({ p: e, name: t, active: s, color: c }) {
	let { ref: l } = a(`seat:${e.rid}`), u = r(), [d, f] = n(!1);
	return /* @__PURE__ */ m("div", {
		ref: l,
		className: "bs-seat",
		"data-active": s || void 0,
		style: { borderLeft: `5px solid ${c}` },
		children: [
			/* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("button", {
				className: "bs-player-name",
				onClick: () => f(!0),
				title: u("games.broomservice.playerDetails", { name: t }),
				children: t
			}), /* @__PURE__ */ p("b", { children: /* @__PURE__ */ p(o, { value: e.points }) })] }),
			/* @__PURE__ */ m("div", {
				className: "bs-stock",
				children: [
					e.stock.map((e, t) => /* @__PURE__ */ m("span", {
						title: u(S[t]),
						children: [/* @__PURE__ */ p(W, {
							color: t,
							size: 18
						}), e]
					}, t)),
					/* @__PURE__ */ m("span", {
						title: u("games.broomservice.lightning"),
						children: ["ϟ ", e.lightning]
					}),
					/* @__PURE__ */ m("span", {
						title: u("games.broomservice.amulet"),
						children: ["◇ ", e.amulets.length]
					}),
					e.tiles.length > 0 && /* @__PURE__ */ m("span", {
						title: u("games.broomservice.forestTile"),
						children: ["▱ ", e.tiles.length]
					}),
					/* @__PURE__ */ p("span", {
						title: u("games.broomservice.hand"),
						children: e.handCount === null ? e.picked ? "✓" : "?" : e.handCount
					})
				]
			}),
			/* @__PURE__ */ p(i, {
				side: "left",
				open: d,
				onClose: () => f(!1),
				label: t,
				title: t,
				children: /* @__PURE__ */ m("div", {
					className: "bs-player-detail",
					children: [
						/* @__PURE__ */ p("div", {
							className: "bs-stock",
							children: e.stock.map((e, t) => /* @__PURE__ */ m("span", { children: [
								/* @__PURE__ */ p(W, { color: t }),
								u(S[t]),
								" ",
								e
							] }, t))
						}),
						/* @__PURE__ */ p("p", { children: u("games.broomservice.playedRoles") }),
						/* @__PURE__ */ p("div", {
							className: "bs-bewitched",
							children: e.played.map((e) => /* @__PURE__ */ p("span", { children: u(x[e]) }, e))
						}),
						/* @__PURE__ */ m("p", { children: [
							u("games.broomservice.lightning"),
							" ",
							e.lightning,
							" · ",
							u("games.broomservice.hand"),
							" ",
							e.handCount === null ? e.picked ? "✓" : "?" : e.handCount,
							" · ",
							u("games.broomservice.amulet"),
							" ",
							e.amulets.length,
							" · ",
							u("games.broomservice.forestTile"),
							" ",
							e.tiles.length
						] }),
						e.tiles.map((e, t) => /* @__PURE__ */ p("p", { children: u(e === "extra" ? "games.broomservice.chooseExtra" : e === "brave" ? "games.broomservice.useBraveTile" : "games.broomservice.usePointsTile") }, t))
					]
				})
			})
		]
	});
}
function We({ pub: e, priv: t, members: o, myRid: c, send: l }) {
	let h = r(), [g, _] = n([]), [v, y] = n(null), [b, ne] = n(!1), [C, re] = n([
		0,
		0,
		0,
		0
	]), { ref: ie } = a("hand"), { ref: ae } = a("role"), w = (e) => o.find((t) => t.rid === e)?.name ?? e ?? "", T = e.players.find((e) => e.rid === c), E = e.phase === "select" && !t?.selected, D = e.phase === "extra" && e.extraWaiting.includes(c), O = e.phase === "play" && e.actor === c, oe = E ? Array.from({ length: 10 }, (e, t) => t) : D ? Array.from({ length: 10 }, (e, t) => t).filter((e) => !t?.hand.includes(e)) : t?.hand ?? [], k = v !== null && oe.includes(v) ? v : null, A = t?.choices ?? [], j = A.filter((e) => [
		"skip",
		"gain",
		"works",
		"mountain"
	].includes(e.kind)), M = h("games.broomservice.waiting", { name: w(e.actor) });
	E ? M = h(e.event === 3 ? "games.broomservice.selectMore" : "games.broomservice.selectFour") : e.phase === "select" ? M = h("games.broomservice.waitSelections") : D ? M = h("games.broomservice.chooseExtra") : O ? M = h(e.role === null ? "games.broomservice.lead" : "games.broomservice.follow") : e.phase === "effect" && e.actor === c ? M = h(e.job === "move" ? "games.broomservice.chooseMove" : e.job === "teleport" ? "games.broomservice.chooseTeleport" : e.job === "deliver" ? "games.broomservice.chooseTower" : e.job === "cloud" ? "games.broomservice.chooseCloud" : "games.broomservice.chooseEffect") : e.phase === "auction" ? M = h("games.broomservice.bidPrompt") : [
		"beat",
		"reveal",
		"event"
	].includes(e.phase) && (M = h("games.broomservice.resolving"));
	let se = E && (e.event === 3 ? g.length >= 1 && g.length <= 5 : g.length === 4), N = e.event === 9 && e.role === null, P = (e, t = "none") => {
		k !== null && (l({
			type: "play",
			role: k,
			brave: e,
			tile: t
		}), y(null));
	};
	return /* @__PURE__ */ m("div", {
		className: "bs-screen",
		children: [/* @__PURE__ */ p(u, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ m("div", {
				className: "bs-top",
				children: [
					/* @__PURE__ */ m("div", {
						className: "bs-title",
						children: [
							/* @__PURE__ */ p("h1", { children: h("games.broomservice.name") }),
							/* @__PURE__ */ p("span", { children: h("games.broomservice.round", { n: e.round }) }),
							/* @__PURE__ */ p("button", {
								className: "bs-event",
								onClick: () => ne(!0),
								children: h(ee[e.event])
							})
						]
					}),
					/* @__PURE__ */ p("div", {
						className: "bs-seats",
						children: e.players.map((t) => /* @__PURE__ */ p(Ue, {
							p: t,
							name: w(t.rid),
							active: e.actor === t.rid,
							color: s[(o.find((e) => e.rid === t.rid)?.colorIndex ?? 0) % s.length].hex
						}, t.rid))
					}),
					/* @__PURE__ */ p(d, {
						tone: E || D || e.actor === c || e.phase === "auction" && !t?.bid ? "accent" : "info",
						text: M,
						accent: "#87649a"
					})
				]
			}),
			children: /* @__PURE__ */ m("div", {
				className: "bs-table",
				children: [/* @__PURE__ */ p(Ve, {
					pub: e,
					members: o,
					myRid: c,
					choices: A,
					send: l
				}), /* @__PURE__ */ m("aside", {
					className: "bs-hand-panel",
					ref: ie,
					children: [
						/* @__PURE__ */ m("div", {
							className: "bs-controls",
							children: [
								E && /* @__PURE__ */ p("button", {
									className: "bs-button",
									disabled: !se,
									onClick: () => {
										l({
											type: "select",
											roles: g,
											extra: !1
										}), _([]);
									},
									children: h("games.broomservice.confirmCards", { n: g.length })
								}),
								O && e.role !== null && !t?.hand.includes(e.role) && /* @__PURE__ */ p("button", {
									className: "bs-button",
									onClick: () => l({ type: "pass" }),
									children: h("games.broomservice.pass")
								}),
								O && k !== null && /* @__PURE__ */ m("div", {
									className: "bs-courage",
									children: [
										/* @__PURE__ */ p("button", {
											className: "bs-button",
											onClick: () => P(!0),
											children: h("games.broomservice.brave")
										}),
										/* @__PURE__ */ p("button", {
											className: "bs-button bs-button-pale",
											disabled: N,
											onClick: () => P(!1),
											children: h("games.broomservice.coward")
										}),
										!N && T?.tiles.filter((e) => e !== "extra").filter((e, t, n) => n.indexOf(e) === t).map((e) => /* @__PURE__ */ p("button", {
											className: "bs-button bs-button-pale",
											onClick: () => P(!1, e),
											children: h(e === "brave" ? "games.broomservice.useBraveTile" : "games.broomservice.usePointsTile")
										}, e))
									]
								}),
								D && /* @__PURE__ */ p("button", {
									className: "bs-button bs-button-pale",
									onClick: () => l({
										type: "extraCard",
										role: null
									}),
									children: h("games.broomservice.keepTile")
								}),
								j.map((e) => /* @__PURE__ */ p("button", {
									className: `bs-button${e.kind === "skip" ? " bs-button-pale" : ""}`,
									onClick: () => l({
										type: "choose",
										id: e.id
									}),
									children: e.kind === "skip" ? h("games.broomservice.skip") : e.kind === "works" ? h("games.broomservice.paySet") : e.kind === "mountain" ? h(e.option === 0 ? "games.broomservice.useMountain" : "games.broomservice.deliverHere") : e.points ? h("games.broomservice.takePoints", { n: e.points }) : /* @__PURE__ */ p("span", {
										className: "bs-stock",
										children: e.stock?.map((e, t) => e > 0 && /* @__PURE__ */ m("span", { children: [/* @__PURE__ */ p(W, { color: t }), e] }, t))
									})
								}, e.id)),
								e.phase === "auction" && !t?.bid && T && /* @__PURE__ */ m("div", {
									className: "bs-bid",
									children: [C.map((e, t) => /* @__PURE__ */ m("label", { children: [/* @__PURE__ */ p(W, { color: t }), /* @__PURE__ */ p("input", {
										type: "number",
										min: "0",
										max: T.stock[t],
										value: e,
										"aria-label": h(S[t]),
										onChange: (e) => re(C.map((n, r) => r === t ? Math.max(0, Math.min(T.stock[t], Number(e.target.value) || 0)) : n))
									})] }, t)), /* @__PURE__ */ p("button", {
										className: "bs-button",
										onClick: () => l({
											type: "bid",
											stock: C
										}),
										children: h("games.broomservice.sealBid")
									})]
								})
							]
						}),
						/* @__PURE__ */ p("div", {
							className: "bs-role-grid",
							children: oe.map((t) => /* @__PURE__ */ p(ze, {
								role: t,
								selected: E ? g.includes(t) : k === t,
								disabled: !E && !D && (!O || e.role !== null && e.role !== t),
								curse: e.bewitched.includes(t),
								onClick: () => {
									E ? _(g.includes(t) ? g.filter((e) => e !== t) : [...g, t]) : D ? l({
										type: "extraCard",
										role: t
									}) : y(k === t ? null : t);
								}
							}, t))
						}),
						/* @__PURE__ */ p("div", {
							ref: ae,
							className: "bs-current",
							children: e.role !== null && /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p("span", { children: h(x[e.role]) }), /* @__PURE__ */ p("strong", { children: e.brave ? h("games.broomservice.braveOwner", { name: w(e.brave) }) : h("games.broomservice.noBrave") })] })
						})
					]
				})]
			})
		}), /* @__PURE__ */ m(i, {
			side: "left",
			open: b,
			onClose: () => ne(!1),
			label: h(ee[e.event]),
			title: h(ee[e.event]),
			children: [
				/* @__PURE__ */ p("p", {
					className: "bs-event-copy",
					children: h(te[e.event])
				}),
				e.bewitched.length > 0 && /* @__PURE__ */ m("div", {
					className: "bs-bewitched",
					children: [/* @__PURE__ */ p("strong", { children: h("games.broomservice.bewitched") }), e.bewitched.map((e) => /* @__PURE__ */ m("span", { children: [h(x[e]), " −3"] }, e))]
				}),
				/* @__PURE__ */ p("div", {
					className: "bs-guide-copy",
					children: h("games.broomservice.referenceHint")
				})
			]
		})]
	});
}
//#endregion
//#region src/games/broomservice/bot.ts
var Ge = {
	resource: 1.3,
	movement: 1.8,
	delivery: 1,
	lightning: 1,
	risk: 1,
	curse: 3,
	horizon: .55
};
function J(e) {
	let t = 4294967296, n = t - t % e.length, r;
	do
		r = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
	while (r >= n);
	return e[r % e.length];
}
var Y = (e) => e.reduce((e, t) => e + t, 0);
function X(e, t, n, r) {
	let i = e.players.find((e) => e.rid === t);
	return r.resource * (1.5 / (1 + i.stock[n] * .35)) * (e.round === 7 ? .55 : 1);
}
function Z(e, t, n) {
	let r = w[e.config.board], i = e.players.find((e) => e.rid === t);
	return Math.max(0, ...r.towers.filter((t) => t.areas.includes(n) && i.stock[t.color] > 0 && !(t.id in e.occupied) && !(Object.keys(e.mountainTiles).length > 0 && r.coveredTowers.includes(t.id))).map((e) => e.points + e.wands));
}
function Q(e, t, n, r, i) {
	let a = w[e.config.board], o = e.players.find((e) => e.rid === t), s = new Set(e.clouds.map((e) => a.slots[e.slot].area));
	if (n < 4) {
		let c = [
			"forest",
			"prairie",
			"hill",
			"mountain"
		][n], l = 0;
		for (let n of o.pawns) for (let u of a.areas[n].neighbors) if (a.areas[u].terrain === c && !s.has(u)) {
			let n = String(u) in e.mountainTiles && !o.amulets.includes(u) ? 4 : 0, c = Math.max(0, ...a.areas[u].neighbors.filter((e) => !s.has(e)).map((n) => Z(e, t, n))) * i.horizon;
			l = Math.max(l, i.movement + n + c + (r ? Z(e, t, u) * i.delivery : 0));
		}
		return l;
	}
	if (n === 4) return X(e, t, 0, i) * (r ? 2 : 1) + (r ? X(e, t, 3, i) : 0);
	if (n === 5) return X(e, t, 1, i) * (r ? 2 : 1) + (r ? Math.max(...[
		0,
		1,
		2
	].map((n) => X(e, t, n, i))) : 0);
	if (n === 6) return r ? X(e, t, 2, i) + 2 * X(e, t, 3, i) : Math.max(X(e, t, 2, i), X(e, t, 3, i));
	if (n === 7 || n === 8) {
		let s = o.pawns.filter((e) => n === 7 ? ["hill", "mountain"].includes(a.areas[e].terrain) : ["forest", "prairie"].includes(a.areas[e].terrain)).map((n) => Z(e, t, n)), c = Math.max(0, ...s);
		return c > 0 ? c * i.delivery + (r ? 3 : 0) : 0;
	}
	return Math.max(0, ...e.clouds.filter((e) => o.stock[3] >= e.cost && o.pawns.some((t) => a.slots[e.slot].adjacent.includes(t))).map((n) => (D[Math.min(7, o.lightning + n.lightning)] - D[Math.min(7, o.lightning)]) * i.lightning - n.cost * X(e, t, 3, i) + (r ? 3 : 0)));
}
function Ke(e, t, n, r) {
	let i = e.players.find((e) => e.rid === t), a = w[e.config.board];
	if (n.kind === "mountain") return n.option === 0 ? 4 : 5;
	if (n.kind === "skip") return 0;
	if (n.kind === "gain") return (n.points ?? 0) + (n.stock ?? [
		0,
		0,
		0,
		0
	]).reduce((n, i, a) => n + i * X(e, t, a, r), 0);
	if (n.kind === "works") return 9 - [
		0,
		1,
		2,
		3
	].reduce((n, i) => n + X(e, t, i, r), 0);
	if (n.kind === "deliver") return (n.points ?? 0) * r.delivery + (n.tower === -1 ? 0 : a.towers[n.tower].wands * X(e, t, 3, r)) - .5;
	if (n.kind === "cloud") {
		let a = e.clouds.find((e) => e.id === n.cloud);
		return (D[Math.min(7, i.lightning + a.lightning)] - D[Math.min(7, i.lightning)]) * r.lightning - a.cost * X(e, t, 3, r) + (n.points ?? 0) + 1;
	}
	if (n.to !== void 0) {
		let o = r.movement + Z(e, t, n.to) * r.delivery;
		return o += Math.max(0, ...a.areas[n.to].neighbors.map((n) => Z(e, t, n))) * r.horizon, String(n.to) in e.mountainTiles && !i.amulets.includes(n.to) && (o += 5), String(n.to) in e.forestTiles && (o += 4), e.event === 8 && (o += {
			prairie: -3,
			forest: -1,
			hill: -2,
			mountain: 0,
			water: 0
		}[a.areas[n.to].terrain]), e.event === 1 && (o += {
			prairie: 2,
			forest: 0,
			hill: 1,
			mountain: -1,
			water: 0
		}[a.areas[n.to].terrain]), o;
	}
	return 0;
}
function qe(e = Ge) {
	return (t, n) => {
		let r = t.public, i = t.private, a = n.rid, o = r.players.find((e) => e.rid === a);
		if (!o || !i) return null;
		let s = n.difficulty === "weak";
		if (r.phase === "select" && !i.selected) {
			let t = Array.from({ length: 10 }, (e, t) => t);
			if (s) {
				let e = [];
				for (; e.length < 4;) {
					let n = J(t.filter((t) => !e.includes(t)));
					e.push(n);
				}
				return { action: {
					type: "select",
					roles: e,
					extra: !1
				} };
			}
			let n = t.map((t) => ({
				role: t,
				value: Q(r, a, t, !0, e) * .6 + Q(r, a, t, !1, e) * .4 - (r.bewitched.includes(t) ? e.curse : 0)
			})).sort((e, t) => t.value - e.value || e.role - t.role), i = 4;
			if (r.event === 3) {
				let e = -Infinity;
				for (let t = 1; t <= 5; t++) {
					let r = n.slice(0, t).reduce((e, t) => e + t.value, 0) + [
						10,
						6,
						3,
						0,
						-3
					][t - 1];
					r > e && (e = r, i = t);
				}
			}
			return { action: {
				type: "select",
				roles: n.slice(0, i).map((e) => e.role),
				extra: !1
			} };
		}
		if (r.phase === "extra" && r.extraWaiting.includes(a)) return { action: {
			type: "extraCard",
			role: Array.from({ length: 10 }, (e, t) => t).filter((e) => !i.hand.includes(e)).sort((t, n) => Q(r, a, n, !0, e) - Q(r, a, t, !0, e))[0] ?? null
		} };
		if (r.phase === "auction" && !i.bid) {
			let e = [
				0,
				0,
				0,
				0
			], t = Math.max(...r.players.filter((e) => e.rid !== a).map((e) => Y(e.stock))), n = s ? Math.min(2, Y(o.stock)) : Math.min(Y(o.stock), Math.min(5, Math.ceil(t * .45)));
			for (let t = 0; t < n; t++) {
				let t = [
					0,
					1,
					2,
					3
				].filter((t) => e[t] < o.stock[t]).sort((t, n) => o.stock[n] - e[n] - (o.stock[t] - e[t]));
				t.length && e[t[0]]++;
			}
			return { action: {
				type: "bid",
				stock: e
			} };
		}
		if (r.actor !== a) return null;
		if (r.phase === "effect" && i.choices.length) return { action: {
			type: "choose",
			id: (s ? J(i.choices) : [...i.choices].sort((t, n) => Ke(r, a, n, e) - Ke(r, a, t, e))[0]).id
		} };
		if (r.phase !== "play") return null;
		if (r.role !== null && !i.hand.includes(r.role)) return { action: { type: "pass" } };
		let c = r.role === null ? i.hand : [r.role];
		if (s) return { action: {
			type: "play",
			role: J(c),
			brave: r.event === 9 && r.role === null || J([!0, !1]),
			tile: "none"
		} };
		let l = r.players.findIndex((e) => e.rid === a), u = r.players.findIndex((e) => e.rid === r.leader), d = null;
		for (let t of c) {
			let n = 1;
			for (let e = 1; e < r.players.length; e++) {
				let i = (l + e) % r.players.length;
				if (i === u) break;
				let a = r.players[i];
				a.played.includes(t) || (n *= 1 - Math.min(.8, (a.handCount ?? 4) / Math.max(1, 10 - a.played.length)) * .65);
			}
			let i = Q(r, a, t, !1, e), s = Q(r, a, t, !0, e) * n ** e.risk, c = r.event === 9 && r.role === null, f = [{
				role: t,
				brave: !0,
				tile: "none",
				value: s + .15
			}, ...c ? [] : [
				{
					role: t,
					brave: !1,
					tile: "none",
					value: Math.max(i, r.event === 2 ? 3 : r.event === 5 ? e.resource : 0)
				},
				...o.tiles.includes("brave") ? [{
					role: t,
					brave: !1,
					tile: "brave",
					value: Q(r, a, t, !0, e) - 2
				}] : [],
				...o.tiles.includes("points") ? [{
					role: t,
					brave: !1,
					tile: "points",
					value: 4
				}] : []
			]];
			for (let e of f) (!d || e.value > d.value) && (d = e);
		}
		return d ? { action: {
			type: "play",
			role: d.role,
			brave: d.brave,
			tile: d.tile
		} } : null;
	};
}
var Je = qe(), Ye = (e, t, n) => e.type === "play" ? n(e.brave ? "games.broomservice.playBrave" : "games.broomservice.playCoward", { role: n(x[e.role]) }) : n("games.broomservice.hint"), $ = (e, t, n = t) => ({
	x: e.x + (e.w - t) / 2,
	y: e.y + (e.h - n) / 2,
	w: t,
	h: n
}), Xe = {
	usurp: (e, t) => {
		let n = t.anchor(`seat:${e.rid}`);
		return n ? {
			ms: 620,
			node: /* @__PURE__ */ p(h, {
				at: n,
				ms: 620,
				children: /* @__PURE__ */ p(Ze, {})
			})
		} : null;
	},
	play: (e, t) => {
		let n = t.anchor(e.rid === t.myRid ? "hand" : `seat:${e.rid}`), r = t.anchor("role");
		if (!n || !r) return null;
		let i = e.data;
		return {
			ms: 620,
			node: /* @__PURE__ */ p(g, {
				from: $(n, 80, 70),
				to: $(r, 80, 70),
				ms: 620,
				children: /* @__PURE__ */ p("img", {
					src: `games/broomservice/role-${i.role}.svg`,
					style: {
						width: 80,
						height: 70,
						border: "3px solid #8a6a9b",
						borderRadius: 5
					}
				})
			})
		};
	},
	reveal: (e, t) => {
		let n = t.anchor("hand");
		return n ? {
			ms: 620,
			node: /* @__PURE__ */ p(_, {
				at: n,
				ms: 620
			})
		} : null;
	},
	move: (e, t) => {
		let n = e.data, r = t.anchor(`pawn:${e.rid}:${n.pawn}`), i = t.anchor(`area:${n.from}`);
		if (!i || !r) return null;
		let a = i.w / 40, o = {
			x: i.x + (15 + (n.fromPlace % 3 - 1) * 32) * a,
			y: i.y + (20 + Math.floor(n.fromPlace / 3) * 34) * a,
			w: 38 * a,
			h: 38 * a
		}, c = t.member(e.rid), l = s[(c?.colorIndex ?? 0) % s.length].hex;
		return {
			ms: 620,
			hide: t.queued ? [] : [`pawn:${e.rid}:${n.pawn}`],
			node: /* @__PURE__ */ p(g, {
				from: o,
				to: r,
				ms: 620,
				children: /* @__PURE__ */ p("div", {
					style: {
						width: o.w,
						height: o.h
					},
					children: /* @__PURE__ */ p(je, {
						color: l,
						size: o.w
					})
				})
			})
		};
	},
	deliver: (e, t) => {
		let n = e.data, r = t.anchor(`seat:${e.rid}`), i = t.anchor(`tower:${n.tower}`) ?? t.anchor(`area:${n.area}`);
		return !r || !i ? null : {
			ms: 620,
			node: /* @__PURE__ */ m(f, { children: [/* @__PURE__ */ p(g, {
				from: $(r, 32),
				to: $(i, 32),
				ms: 620,
				children: /* @__PURE__ */ p("div", {
					style: {
						width: 32,
						height: 32
					},
					children: /* @__PURE__ */ p(W, {
						color: n.color,
						size: 32
					})
				})
			}), /* @__PURE__ */ m(h, {
				at: i,
				ms: 620,
				children: ["+", n.points]
			})] })
		};
	},
	cloud: (e, t) => {
		let n = e.data, r = t.anchor(`cloud:${n.slot}`), i = t.anchor(`seat:${e.rid}`);
		return !r || !i ? null : {
			ms: 620,
			node: /* @__PURE__ */ p(g, {
				from: r,
				to: $(i, 36, 25),
				ms: 620,
				children: /* @__PURE__ */ p("div", {
					style: {
						width: r.w,
						height: r.h
					},
					children: /* @__PURE__ */ p("svg", {
						width: r.w,
						height: r.h,
						viewBox: "-50 -35 100 70",
						children: /* @__PURE__ */ p(G, {
							cost: n.cost,
							lightning: n.lightning,
							effect: n.effect
						})
					})
				})
			})
		};
	},
	gain: (e, t) => {
		let n = t.anchor(`seat:${e.rid}`), r = e.data;
		return n ? {
			ms: 620,
			node: /* @__PURE__ */ p(h, {
				at: n,
				ms: 620,
				children: /* @__PURE__ */ p("span", {
					className: "bs-stock",
					children: r.stock.map((e, t) => e > 0 && /* @__PURE__ */ m("span", { children: [
						/* @__PURE__ */ p(W, { color: t }),
						"+",
						e
					] }, t))
				})
			})
		} : null;
	},
	score: (e, t) => {
		let n = t.anchor(`seat:${e.rid}`);
		return n ? {
			ms: 620,
			node: /* @__PURE__ */ m(h, {
				at: n,
				ms: 620,
				children: ["+", e.data.points]
			})
		} : null;
	}
};
function Ze() {
	let e = r();
	return /* @__PURE__ */ p("span", { children: e("games.broomservice.usurped") });
}
//#endregion
//#region src/games/broomservice/game-over.tsx
function Qe({ public: e, members: t, myRid: i, result: a, onPlayAgain: o, onBackToLobby: s, hintCount: c }) {
	let l = e, u = r(), [d, f] = n(!0), h = (e) => t.find((t) => t.rid === e)?.name ?? e;
	return /* @__PURE__ */ m("div", {
		className: "bs-ending",
		children: [
			/* @__PURE__ */ p(Ve, {
				pub: l,
				members: t,
				myRid: i,
				readOnly: !0
			}),
			!d && /* @__PURE__ */ p("button", {
				className: "bs-button bs-result-restore",
				onClick: () => f(!0),
				children: u("games.broomservice.showResult")
			}),
			/* @__PURE__ */ m("div", {
				className: "bs-final-overlay",
				hidden: !d,
				style: d ? void 0 : { display: "none" },
				children: [
					/* @__PURE__ */ m("div", {
						className: "bs-final-heading",
						children: [/* @__PURE__ */ p("h1", { children: u("games.broomservice.ending") }), /* @__PURE__ */ p("button", {
							className: "bs-button bs-button-pale",
							onClick: () => f(!1),
							children: u("games.broomservice.reviewBoard")
						})]
					}),
					/* @__PURE__ */ p("p", {
						className: "bs-final-note",
						children: u("games.broomservice.winner", { names: a.winner.map(h).join(" · ") })
					}),
					/* @__PURE__ */ m("div", {
						className: "bs-result-scroll",
						children: [
							/* @__PURE__ */ m("table", {
								className: "bs-result-table",
								children: [/* @__PURE__ */ p("thead", { children: /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", { children: u("games.broomservice.total") }), a.ranking.map((e) => /* @__PURE__ */ p("th", {
									className: a.winner.includes(e) ? "bs-winner" : void 0,
									children: h(e)
								}, e))] }) }), /* @__PURE__ */ m("tbody", { children: [
									[
										"base",
										"lightning",
										"resources",
										"amulets"
									].map((e, t) => /* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", { children: u([
										"games.broomservice.baseScore",
										"games.broomservice.cloudScore",
										"games.broomservice.resourceScore",
										"games.broomservice.amuletScore"
									][t]) }), a.ranking.map((t) => /* @__PURE__ */ p("td", { children: l.players.find((e) => e.rid === t)?.final?.[e] ?? 0 }, t))] }, e)),
									/* @__PURE__ */ m("tr", {
										className: "bs-total",
										children: [/* @__PURE__ */ p("th", { children: u("games.broomservice.total") }), a.ranking.map((e) => /* @__PURE__ */ p("td", {
											className: a.winner.includes(e) ? "bs-winner" : void 0,
											children: a.scores?.[e]
										}, e))]
									}),
									/* @__PURE__ */ m("tr", { children: [/* @__PURE__ */ p("th", { children: u("games.broomservice.resourceScore") }), a.ranking.map((e) => /* @__PURE__ */ p("td", { children: u("games.broomservice.resourceCount", { n: l.players.find((t) => t.rid === e)?.stock.reduce((e, t) => e + t, 0) ?? 0 }) }, e))] })
								] })]
							}),
							/* @__PURE__ */ p("p", {
								className: "bs-final-note",
								children: u("games.broomservice.tieResource")
							}),
							c !== void 0 && /* @__PURE__ */ p("p", {
								className: "bs-final-note",
								children: u("session.hint.usedCount", { n: c })
							}),
							a.autopilot && Object.entries(a.autopilot).map(([e, t]) => /* @__PURE__ */ m("p", {
								className: "bs-final-note",
								children: [
									h(e),
									" · ",
									u("session.autopilot.share", { n: Math.round(t * 100) })
								]
							}, e))
						]
					}),
					/* @__PURE__ */ m("div", {
						className: "bs-final-actions",
						children: [
							o && /* @__PURE__ */ p("button", {
								className: "bs-button",
								onClick: o,
								children: u("session.result.playAgain")
							}),
							s && /* @__PURE__ */ p("button", {
								className: "bs-button bs-button-pale",
								onClick: s,
								children: u("session.result.backToLobby")
							}),
							!o && !s && /* @__PURE__ */ p("span", { children: u("session.result.waitHost") })
						]
					})
				]
			})
		]
	});
}
//#endregion
//#region src/games/broomservice/options.tsx
function $e({ value: e, onChange: t }) {
	let n = r(), i = j.safeParse(e), a = i.success ? i.data : j.parse(void 0);
	return /* @__PURE__ */ m("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ m(y, {
				title: n("games.broomservice.options.board"),
				children: [/* @__PURE__ */ p(v, {
					name: "broomservice-board",
					value: "front",
					checked: a.board === "front",
					label: n("games.broomservice.options.front"),
					onChange: () => t({
						...a,
						board: "front"
					})
				}), /* @__PURE__ */ p(v, {
					name: "broomservice-board",
					value: "back",
					checked: a.board === "back",
					label: n("games.broomservice.options.back"),
					hint: n("games.broomservice.options.backHint"),
					onChange: () => t({
						...a,
						board: "back"
					})
				})]
			}),
			/* @__PURE__ */ p(b, {
				checked: a.storms,
				label: n("games.broomservice.options.storms"),
				onChange: () => t({
					...a,
					storms: !a.storms
				})
			}),
			/* @__PURE__ */ p(b, {
				checked: a.mountains || a.board === "back",
				disabled: a.board === "back",
				label: n("games.broomservice.options.mountains"),
				onChange: () => t({
					...a,
					mountains: !a.mountains
				})
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/broomservice/entry.tsx
var et = {
	definition: Ae,
	View: Be,
	bot: Je,
	describe: Ye,
	fx: Xe,
	OverView: Qe,
	Options: $e,
	locales: {
		zh: {
			name: "魔女快递",
			desc: "秘密选择角色，争夺勇敢行动，骑着扫帚运送魔药。",
			rules: "目标:\n七轮后胜利点最多者获胜。同分时，剩余资源总数较多者获胜，再同则并列。\n准备:\n每人获得10张角色牌、两枚棋子、10胜利点和绿、紫、橙药水各1瓶。两枚棋子分别从两座城堡出发。起始玩家及其右侧玩家各获得1根魔杖，其余玩家各获得2根。两人局双方各获得1根。药水与魔杖统称资源，供给不限。\n正面地图随机放置18片云，背面放置19片。重云共24片：消耗1、2、3根魔杖且带1道闪电的各7片，消耗3根且带2道闪电的2片，消耗6根且带3道闪电的1片。随机使用10张事件中的7张，每轮翻开一张。2至4人局每轮分别公开3、2、1张被诅咒角色；打出这些角色立即失去3点，无论勇敢、胆怯或最终能否执行。\n流程:\n每轮所有人秘密选择4张不同的角色牌，全部确认后开始。轮次中从起始玩家开始领出一个角色，并选择勇敢或胆怯。依顺时针轮到各玩家；持有同一角色时必须跟牌，没有该角色时跳过。轮到自己前不得透露是否持有。已公开的角色和剩余手牌张数始终可见。\n胆怯行动立即执行；勇敢者等待其他人宣告。后来的勇敢者夺走先前勇敢者的行动，最后一位勇敢者执行并成为下次领出者。全员胆怯时，原领出者继续；领出者没有手牌时，顺时针交给仍有牌者。所有人用完手牌后处理轮末事件。下一轮由最后一位勇敢者开始；最后一个角色全员胆怯时，仍由该角色的领出者开始。\n可以全部或部分放弃行动。即使不执行，最后勇敢者仍取得下次领出权。\n角色:\n· 森林、草原、丘陵、高山女巫：胆怯时将任一棋子移至相邻的对应地形，勇敢时移动后还可在到达地形送1瓶药水。不能进入或跨越水域、有云的区域。可以只移动不送货，不能不移动就送货。\n· 草药采集者：胆怯获得1瓶绿色药水；勇敢获得2瓶绿色药水和1根魔杖。\n· 水果采集者：胆怯获得1瓶紫色药水；勇敢获得2瓶紫色药水，再选择任意颜色药水1瓶。\n· 根茎采集者：胆怯获得1瓶橙色药水或1根魔杖；勇敢获得1瓶橙色药水和2根魔杖。\n· 山峰德鲁伊：在本人棋子所在的丘陵或高山送1瓶药水。\n· 山谷德鲁伊：在本人棋子所在的森林或草原送1瓶药水。\n勇敢德鲁伊成功送货时额外获得3点。\n· 天气仙子：选择本人任一棋子相邻的一片云，支付星形数字所示魔杖，收下该云。勇敢成功时额外获得3点。云上的闪电在终局计分。\n送货:\n塔基接触的区域都可送货，药水颜色必须与塔顶相符。圆塔只能接收一次，药水留在塔上；带旗的方塔可重复接收，药水交回供给。每次送货获得塔上胜利点及标明的魔杖。每位玩家每个角色向方塔至多送货1瓶，额外送货效果也计入。所有人共用塔的占用状态。\n事件:\n· 两手空空：轮末资源总数不超过5时获得3点。\n· 安全之地：轮末每枚棋子在草原获得2点、丘陵获得1点、高山失去1点。\n· 危险之地：轮末每枚棋子在草原失去3点、丘陵失去2点、森林失去1点。\n· 黑市：每次胆怯可用获得3点替代角色行动。\n· 秘密蒸馏：每次胆怯可用获得任意1份资源替代角色行动。\n· 多一点，少一点：改为秘密选择1至5张角色，全部确认后同时公开张数，分别获得10、6、3、0、−3点。森林板块增加的额外牌不影响这项计分。\n· 全套齐备：轮末可支付每种资源各1份，获得9点，至多一次。\n· 结伴同行：轮末两枚棋子地形相同则获得4点，不必在同一区域。\n· 占得上风：轮末同时秘密出价，资源种类任意；最高出价的所有玩家支付所出资源，各获得8点，其他人不支付。\n· 勇敢之心：每个角色的领出者必须勇敢；整轮起始玩家获得1根魔杖。\n盒内变体:\n默认使用正面基础地图且关闭风暴云与山地板块。风暴云混入重云后随机放置：2片常驻云让相邻棋子每次送货额外获得2点；2片移除后允许一次相邻移动；1片移除后允许送货；另外3片移除时，持有至少3瓶橙药、4瓶绿药、4瓶紫药分别获得7、8、9点，药水不消耗。\n山地板块随机选3种放在指定山地；仅被板块遮住的塔失去功能。每位玩家首次到达该山地时领取自己的护符，可当场完整执行板块效果：三色药水各1瓶、2根魔杖、任一棋子送货、最多两次移动、移除1片云。后续到访不能再次执行。可任意安排板块效果与勇敢高山女巫在此处的送货顺序；若先移走该棋子，便不能用这次女巫行动在别处送货。\n背面地图必须同时使用山地、森林、丘陵板块。森林首次到达者领取板块，在后续行动使用：胆怯执行勇敢效果但不争夺勇敢权、轮初增加1张角色、胆怯替代行动获得5点，各2张，每个角色至多使用1张。额外牌可在初选张数公开后决定；不能避开勇敢之心的领出限制。丘陵板块中5张要求立即传送至标示两个石环之一，另1张提供可重复接收橙药的7点方塔。勇敢丘陵女巫在最终位置送货。石环D所在岛屿无法离开。\n结束:\n七轮后，按持有的闪电数量获得终局胜利点：\n· 没有闪电时，获得0点。\n· 有1道闪电时，获得3点。\n· 有2道闪电时，获得6点。\n· 有3道闪电时，获得10点。\n· 有4道闪电时，获得14点。\n· 有5道闪电时，获得19点。\n· 有6道闪电时，获得24点。\n· 有至少7道闪电时，获得30点。\n剩余资源每套四种获得4点，每套三种获得2点，每份只能使用一次，取最大组合。1、2、3枚护符分别获得4、9、15点。加上对局胜利点确定胜者。",
			roles: {
				forest: "森林女巫",
				prairie: "草原女巫",
				hill: "丘陵女巫",
				mountain: "高山女巫",
				herb: "草药采集者",
				fruit: "水果采集者",
				root: "根茎采集者",
				peak: "山峰德鲁伊",
				valley: "山谷德鲁伊",
				weather: "天气仙子"
			},
			events: {
				empty: "两手空空",
				protected: "安全之地",
				market: "黑市",
				more: "多一点，少一点",
				works: "全套齐备",
				distillery: "秘密蒸馏",
				flock: "结伴同行",
				upper: "占得上风",
				perilous: "危险之地",
				brave: "勇敢之心"
			},
			eventText: {
				empty: "轮末资源总数不超过5时获得3点。",
				protected: "轮末每枚棋子在草原获得2点、丘陵获得1点、高山失去1点。森林不计分。",
				market: "每次打出胆怯角色时，可以获得3点替代该角色行动。",
				more: "本轮秘密选择1至5张角色。全部确认后公开张数，分别获得10、6、3、0、−3点。森林板块的额外牌不计入。",
				works: "轮末可以支付三色药水和魔杖各1份，获得9点，至多一套。",
				distillery: "每次打出胆怯角色时，可以获得任意1份资源替代该角色行动。",
				flock: "轮末两枚棋子地形相同则获得4点，不必在同一区域。",
				upper: "轮末同时秘密出价。最高出价的所有玩家支付所出资源，各获得8点；其他人不支付。",
				perilous: "轮末每枚棋子在草原失去3点、丘陵失去2点、森林失去1点。高山不扣分。",
				brave: "每个角色的领出者必须勇敢。整轮起始玩家获得1根魔杖。"
			},
			green: "绿色药水",
			purple: "紫色药水",
			orange: "橙色药水",
			wand: "魔杖",
			forest: "森林",
			prairie: "草原",
			hill: "丘陵",
			mountain: "高山",
			water: "水域",
			brave: "勇敢",
			coward: "胆怯",
			round: "第 {{n}} / 7 轮",
			waiting: "等待 {{name}} 行动",
			selectFour: "秘密选择4张角色牌",
			selectMore: "秘密选择1至5张角色牌",
			waitSelections: "等待其他人选牌",
			chooseExtra: "可以使用森林板块增加1张角色",
			lead: "选择要领出的角色",
			follow: "持有当前角色时必须跟牌",
			chooseMove: "选择棋子及相邻目的地",
			chooseTeleport: "选择要前往的石环",
			chooseTower: "选择匹配颜色的塔送货",
			chooseCloud: "选择相邻云层并支付魔杖",
			chooseEffect: "选择要执行的行动",
			bidPrompt: "秘密选择本轮出价的资源",
			resolving: "角色与事件结算中",
			confirmCards: "确认 {{n}} 张",
			pass: "没有该角色，跳过",
			skip: "放弃此次行动",
			keepTile: "保留森林板块",
			takePoints: "获得 {{n}} 点",
			paySet: "支付一套资源，获得9点",
			sealBid: "密封出价",
			useBraveTile: "使用勇敢板块",
			usePointsTile: "使用5点板块",
			braveOwner: "{{name}} 暂获勇敢权",
			noBrave: "尚无勇敢者",
			playBrave: "勇敢打出{{role}}",
			playCoward: "胆怯打出{{role}}",
			hint: "按当前局面选择行动",
			towerLabel: "{{color}}塔：{{n}}点，{{wands}}根魔杖",
			cloudLabel: "支付{{cost}}根魔杖，收集{{n}}道闪电",
			moveTo: "移动至{{terrain}}区域{{n}}",
			pawnLabel: "{{name}}的第{{n}}枚棋子",
			amulet: "护符",
			hillTile: "丘陵板块",
			lightning: "闪电",
			hand: "剩余手牌",
			bewitched: "被诅咒角色",
			referenceHint: "详细角色、事件与变体效果请查看游戏规则。",
			invalid: "当前不能执行该行动，请按最新局面重新选择。",
			options: {
				board: "版图",
				front: "正面",
				back: "背面及地形板块",
				storms: "风暴云",
				mountains: "山地板块与护符",
				backHint: "背面必须同时使用山地、森林与丘陵板块。"
			},
			moveDeliver: "移动后送货1次",
			moveOnly: "相邻地形移动",
			deliverBonus: "送货1次，额外3点",
			deliverOnly: "送货1次",
			cloudBonus: "除云1片，额外3点",
			cloudOnly: "支付魔杖除云1片",
			takeShown: "获得所示资源",
			forestTile: "森林板块",
			playerDetails: "查看{{name}}的公开信息",
			playedRoles: "本轮已用角色",
			usurped: "勇敢行动被夺走",
			useMountain: "执行山地板块效果",
			deliverHere: "先在此处送货",
			amuletAvailable: "{{name}}：尚未领取护符",
			amuletClaimed: "{{name}}：已领取护符",
			ending: "七轮快递完成",
			baseScore: "对局得分",
			cloudScore: "闪电",
			resourceScore: "剩余资源",
			amuletScore: "护符",
			total: "总分",
			reviewBoard: "回看版图",
			showResult: "查看结算",
			winner: "{{names}} 获胜",
			tieResource: "同分时比较剩余资源总数。",
			resourceCount: "资源 {{n}}"
		},
		en: {
			name: "Broom Service",
			desc: "Choose roles in secret, risk brave actions, and deliver magical potions.",
			rules: "Goal:\nAfter seven rounds, the most victory points wins. Break ties by total remaining resources, then share the win.\nSetup:\nEach player receives 10 role cards, two pawns, 10 VP, and one green, purple and orange potion. Place one pawn at each castle. The first player and the player to their right receive one wand; everyone else receives two. In a two-player game, both receive one. Potions and wands are resources; supplies are unlimited.\nRandomly place 18 clouds on the front or 19 on the back. The 24 heavy clouds comprise seven each costing 1, 2 or 3 wands with one lightning bolt, two costing 3 with two bolts, and one costing 6 with three bolts. Shuffle ten events and use seven, revealing one each round. With 2/3/4 players, reveal 3/2/1 bewitched roles each round. Playing one immediately costs 3 VP, regardless of courage or whether the action happens.\nPlay:\nEveryone secretly chooses four different roles. Once everyone commits, the leader plays a role bravely or cowardly. Proceed clockwise: anyone holding that role must follow; anyone without it passes. Do not reveal whether you hold a role before your turn. Played roles and remaining hand sizes are public.\nCowardly actions happen immediately. Brave players wait: a later brave player steals the action from the previous one. The last brave player acts and leads next. If all are cowardly, the original leader leads again. If the leader has no cards, pass clockwise to someone who does. When all hands are empty, resolve the round-end event. The last brave player leads the next round; if the final trick had no brave player, that trick’s original leader leads.\nAny action may be partly or wholly declined. The last brave player still leads even after declining the action.\nRoles:\n· Forest, prairie, hill and mountain witches: cowardly, move one pawn to an adjacent area of the matching terrain. Brave, move and optionally deliver one potion there. Water and areas containing clouds cannot be entered or crossed. You may move without delivering, but cannot deliver without moving.\n· Herb gatherer: acting cowardly gains one green potion; acting bravely gains two green potions and one wand.\n· Fruit gatherer: acting cowardly gains one purple potion; acting bravely gains two purple potions and one potion of any color.\n· Root gatherer: acting cowardly gains one orange potion or one wand; acting bravely gains one orange potion and two wands.\n· Peak druid: deliver one potion from a pawn on a hill or mountain.\n· Valley druid: deliver from a pawn in a forest or prairie.\nA successful brave druid delivery scores 3 extra VP.\n· Weather fairy: pay a cloud's star cost in wands to charm it away from an area adjacent to either pawn. Keep its lightning. Brave scores 3 extra VP only if a cloud is removed.\nDelivery:\nA tower is accessible from every area touching its base. Match the potion to its roof color. Round towers accept one delivery in the entire game; leave the potion there. Flagged square towers accept repeat deliveries; return the potion to supply. Gain the printed VP and wands. Each player may deliver only one potion to square towers per role, including extra delivery effects. Occupancy is shared by everyone.\nEvents:\n· Empty Handed: at round end, gain 3 VP with at most five resources.\n· Protected Places: each pawn scores prairie +2, hill +1, mountain −1, forest 0.\n· Perilous Places: each pawn scores prairie −3, hill −2, forest −1, mountain 0.\n· Black Market: replace any cowardly role action with 3 VP.\n· Black Distillery: replace any cowardly action with any one resource.\n· More or Less: secretly choose between one and five roles, then reveal the counts together. Choosing one, two, three, four or five roles scores 10, 6, 3, 0 or −3 VP respectively. A forest tile's extra card does not affect this score.\n· The Works: at round end, optionally pay one of each resource for 9 VP, once.\n· Flock Together: gain 4 VP if both pawns end the round in the same terrain type, even in different areas.\n· The Upper Hand: bid resources of any types simultaneously and secretly. Every highest bidder pays their bid and gains 8 VP; other players pay nothing.\n· Brave Heart: the first player of every role must be brave. The first player of the round gains one wand.\nBox Variations:\nThe default is the front board with storm clouds and mountain tiles disabled. Storm clouds are shuffled with heavy clouds: two grant +2 VP on each delivery from an adjacent pawn while they remain; two grant an adjacent movement when removed; one grants a delivery; three grant 7/8/9 VP when removed if you hold at least 3 orange/4 green/4 purple potions, without spending them.\nPlace three random mountain tiles on their designated areas, only towers actually covered lose their function. On a player's first arrival at each, claim their amulet and optionally use the complete tile effect immediately: one potion of each color, two wands, a delivery with either pawn, up to two movements, or one cloud removal. Later visits do not repeat the effect. Choose the order of the tile effect and a brave mountain witch’s delivery here. If that pawn moves away first, the witch cannot deliver at a different destination.\nThe back board requires mountain, forest and hill tiles. First arrivals claim forest tiles for later use: act cowardly but use the brave effect without stealing brave priority; add one role at round start; or replace a cowardly action with 5 VP. There are two of each. Use at most one tile per role; decide an extra card after initial counts are revealed if desired. Tiles cannot avoid Brave Heart's obligation. Five hill tiles immediately teleport to one of their two marked stone circles; one supplies a repeatable orange tower worth 7 VP. A brave hill witch may deliver at the final destination. The island with circle D cannot be left.\nEnd:\nScore your lightning bolts as follows:\n· No lightning bolts score 0 VP.\n· One lightning bolt scores 3 VP.\n· Two lightning bolts score 6 VP.\n· Three lightning bolts score 10 VP.\n· Four lightning bolts score 14 VP.\n· Five lightning bolts score 19 VP.\n· Six lightning bolts score 24 VP.\n· Seven or more lightning bolts score 30 VP. Each set of four different remaining resources scores 4 VP; each set of three scores 2 VP. Use each resource only once and maximize the combination. 1/2/3 amulets score 4/9/15 VP. Add these to the points earned during play.",
			roles: {
				forest: "Forest Witch",
				prairie: "Prairie Witch",
				hill: "Hill Witch",
				mountain: "Mountain Witch",
				herb: "Herb Gatherer",
				fruit: "Fruit Gatherer",
				root: "Root Gatherer",
				peak: "Peak Druid",
				valley: "Valley Druid",
				weather: "Weather Fairy"
			},
			events: {
				empty: "Empty Handed",
				protected: "Protected Places",
				market: "Black Market",
				more: "More or Less",
				works: "The Works",
				distillery: "Black Distillery",
				flock: "Flock Together",
				upper: "The Upper Hand",
				perilous: "Perilous Places",
				brave: "Brave Heart"
			},
			eventText: {
				empty: "At round end, gain 3 VP if you have at most five resources.",
				protected: "At round end, each pawn scores +2 in a prairie, +1 on a hill, −1 on a mountain and 0 in a forest.",
				market: "Whenever you play cowardly, you may take 3 VP instead of the role action.",
				more: "Secretly choose 1–5 roles. Reveal counts together and score 10/6/3/0/−3 VP. A forest tile extra card is excluded.",
				works: "At round end, pay one potion of each color and one wand for 9 VP, at most once.",
				distillery: "Whenever you play cowardly, you may take any one resource instead of the role action.",
				flock: "At round end, gain 4 VP if both pawns occupy the same terrain type, even in different areas.",
				upper: "Bid resources secretly. Every highest bidder pays their bid and gains 8 VP. Everyone else pays nothing.",
				perilous: "At round end, each pawn scores −3 in a prairie, −2 on a hill, −1 in a forest and 0 on a mountain.",
				brave: "The leader of each role must be brave. The first player of the round gains one wand."
			},
			green: "Green potion",
			purple: "Purple potion",
			orange: "Orange potion",
			wand: "Wand",
			forest: "Forest",
			prairie: "Prairie",
			hill: "Hill",
			mountain: "Mountain",
			water: "Water",
			brave: "Brave",
			coward: "Cowardly",
			round: "Round {{n}} / 7",
			waiting: "Waiting for {{name}}",
			selectFour: "Choose four roles in secret",
			selectMore: "Choose 1–5 roles in secret",
			waitSelections: "Waiting for role choices",
			chooseExtra: "You may add a role with a forest tile",
			lead: "Choose a role to lead",
			follow: "You must follow this role if you have it",
			chooseMove: "Choose your pawn and an adjacent destination",
			chooseTeleport: "Choose a stone circle",
			chooseTower: "Deliver to a matching tower",
			chooseCloud: "Choose an adjacent cloud and pay wands",
			chooseEffect: "Choose your action",
			bidPrompt: "Secretly choose resources to bid",
			resolving: "Resolving roles and events",
			confirmCards: "Confirm {{n}} cards",
			pass: "No matching role: pass",
			skip: "Decline this action",
			keepTile: "Keep forest tile",
			takePoints: "Gain {{n}} VP",
			paySet: "Pay one of each for 9 VP",
			sealBid: "Seal bid",
			useBraveTile: "Use brave tile",
			usePointsTile: "Use 5 VP tile",
			braveOwner: "{{name}} claims brave",
			noBrave: "No brave claim yet",
			playBrave: "Play {{role}} bravely",
			playCoward: "Play {{role}} cowardly",
			hint: "Choose an action for this position",
			towerLabel: "{{color}} tower: {{n}} VP, {{wands}} wands",
			cloudLabel: "Pay {{cost}} wands for {{n}} lightning",
			moveTo: "Move to {{terrain}} area {{n}}",
			pawnLabel: "{{name}}, pawn {{n}}",
			amulet: "Amulet",
			hillTile: "Hill tile",
			lightning: "Lightning",
			hand: "Cards remaining",
			bewitched: "Bewitched roles",
			referenceHint: "Full role, event and variation details are in the game rules.",
			invalid: "This action is unavailable. Choose again from the current position.",
			options: {
				board: "Board",
				front: "Front",
				back: "Back with terrain tiles",
				storms: "Storm clouds",
				mountains: "Mountain tiles and amulets",
				backHint: "The back requires mountain, forest and hill tiles."
			},
			moveDeliver: "Move, then deliver once",
			moveOnly: "Move to adjacent terrain",
			deliverBonus: "Deliver once, +3 VP",
			deliverOnly: "Deliver once",
			cloudBonus: "Charm one cloud, +3 VP",
			cloudOnly: "Pay wands to charm one cloud",
			takeShown: "Take shown resources",
			forestTile: "Forest tiles",
			playerDetails: "View public information for {{name}}",
			playedRoles: "Roles played this round",
			usurped: "Brave action stolen",
			useMountain: "Use mountain tile",
			deliverHere: "Deliver here first",
			amuletAvailable: "{{name}}: amulet still available",
			amuletClaimed: "{{name}}: amulet collected",
			ending: "Seven Rounds Delivered",
			baseScore: "During play",
			cloudScore: "Lightning",
			resourceScore: "Resources",
			amuletScore: "Amulets",
			total: "Total",
			reviewBoard: "Review board",
			showResult: "Show scores",
			winner: "{{names}} wins",
			tieResource: "Break ties by total remaining resources.",
			resourceCount: "Resources: {{n}}"
		}
	}
};
//#endregion
export { et as default };
