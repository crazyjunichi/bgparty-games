import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useFxAnchor as r } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as i, useT as a } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as o } from "@bgparty/sdk/player-colors";
import { GameScreen as s } from "@bgparty/sdk/ui/game-screen";
import { SeatBadgedAvatar as c, seatName as l } from "@bgparty/sdk/ui/player-strip";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { Floater as p, FlySprite as m } from "@bgparty/sdk/fx/primitives";
import { OptionRadio as h, OptionSection as g } from "@bgparty/sdk/ui/game-options";
//#region src/games/apocalypse/data.ts
var _ = [
	1,
	2,
	3,
	4,
	6,
	7,
	8,
	9,
	10
], v = [
	"games.apocalypse.red",
	"games.apocalypse.green",
	"games.apocalypse.purple",
	"games.apocalypse.blue",
	"games.apocalypse.gold"
], y = [
	"#d94e36",
	"#c6d57d",
	"#704099",
	"#5cacc6",
	"#f3b344"
], b = (e) => e < 45 ? Math.floor(e / 9) : null, x = (e) => e >= 45 && e < 51, S = (e) => e >= 51, C = (e) => e < 45 ? _[e % 9] : x(e) ? 5 : 0, w = (e) => e === 2 ? 3 : e <= 4 ? 4 : 5, T = (e) => e.find((e) => e.card !== null && e.card < 45)?.card;
function E(e) {
	let t = T(e);
	return t == null ? null : b(t);
}
function D(e, t) {
	let n = E(t), r = n !== null && e.some((e) => b(e) === n);
	return e.filter((e) => x(e) ? !t.some((e) => e.card !== null && x(e.card)) : S(e) ? !t.some((e) => e.card !== null && S(e.card)) : !r || b(e) === n);
}
function O(e, t) {
	let n = E(e), r = e.filter((e) => e.card !== null && !S(e.card) && (x(e.card) || b(e.card) === n)).reduce((e, n) => !e || (t ? C(n.card) < C(e.card) : C(n.card) > C(e.card)) ? n : e, null), i = e.flatMap((e) => e.card === null ? [] : [e.card]), a = r ? t ? i : [r.card] : [];
	return {
		winner: r?.rid ?? null,
		taken: a,
		discarded: i.filter((e) => !a.includes(e))
	};
}
function k(e, t) {
	let n = [...e].sort((e, n) => t[e] - t[n]);
	return {
		ranking: n,
		winner: n.filter((e) => t[e] === t[n[0]]),
		scores: { ...t }
	};
}
//#endregion
//#region src/games/apocalypse/meta.ts
var A = {
	id: "apocalypse",
	tier: "alpha",
	mechanics: ["trick-taking", "hand-management"],
	interactionTags: [],
	nameKey: "games.apocalypse.name",
	descKey: "games.apocalypse.desc",
	rulesKey: "games.apocalypse.rules",
	icon: "🌘",
	iconImg: "games/apocalypse.webp",
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [4, 5],
	accent: "#704099",
	search: {
		py: "",
		init: ""
	},
	hotseat: "cover",
	releasedAt: "2026-11-07T01:12:46+08:00",
	rulesUrl: {
		en: "https://steamusercontent-a.akamaihd.net/ugc/17143304790820924725/7ACA48484C8D2EC3BF2406337ABC32005C4BD4A1/",
		fr: "https://steamusercontent-a.akamaihd.net/ugc/10321611616958345985/5DD307E223436080D6F42A14FFDC755B767C2976/"
	}
}, j = t.int().min(0).max(56), M = t.int().nonnegative(), N = t.record(t.string(), M), P = t.object({ firstPlayer: t.enum(["random", "host"]).default("random") }).prefault({}), F = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		card: j,
		token: t.int().min(0).max(4).optional()
	}),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("lead"),
		rid: t.string()
	}),
	t.object({ type: t.literal("ready") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), I = t.object({
	rid: t.string(),
	card: j.nullable(),
	token: t.int().nullable()
}), L = t.object({
	phase: t.enum([
		"deal",
		"play",
		"reveal",
		"collect",
		"choose",
		"score",
		"roundOver",
		"roundLead",
		"done"
	]),
	round: t.int().min(1).max(3),
	trickNumber: t.int().positive(),
	turn: t.string(),
	leader: t.string(),
	chooser: t.string(),
	tokens: t.array(t.boolean()),
	apocalypse: t.boolean(),
	lastApocalypse: t.boolean(),
	trick: t.array(I),
	lastTrick: t.array(I),
	lastWinner: t.string().nullable(),
	lastTaken: t.array(j),
	players: t.array(t.object({
		rid: t.string(),
		score: M,
		handCount: M,
		captured: M,
		pilePoints: M,
		ready: t.boolean()
	})),
	rounds: t.array(t.object({
		round: t.int(),
		captured: N,
		penalties: N,
		raw: N,
		points: N,
		totals: N,
		swapped: t.boolean()
	})),
	history: t.array(t.object({
		round: t.int(),
		number: t.int(),
		plays: t.array(I),
		winner: t.string().nullable(),
		apocalypse: t.boolean(),
		taken: t.array(j)
	})),
	seen: t.array(j),
	voids: t.record(t.string(), t.array(t.int()))
}), R = t.object({
	hand: t.array(j),
	legal: t.array(j),
	needsAction: t.boolean()
}), z = {
	deal: 750,
	play: 360,
	reveal: 1e3,
	collect: 800,
	score: 1300
}, B = (e) => Object.fromEntries(e.map((e) => [e, []]));
function V(t, n) {
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function H(e) {
	let t = e.players.length, n = Array.from({ length: w(t) * 9 }, (e, t) => t);
	t === 2 && n.push(45, 46, 47, 51, 52, 53), V(e, n);
	let r = t === 2 ? 13 : t === 3 ? 10 : t === 6 ? 7 : 8;
	return e.hands = Object.fromEntries(e.players.map((e, i) => [e, [...n.slice(i * r, (i + 1) * r), ...t === 2 ? [] : [45 + i, 51 + i]].sort((e, t) => e - t)])), e.unused = n.slice(t * r), e.piles = B(e.players), e.discarded = [], e.seen = [], e.voids = B(e.players), e.trick = [], e.lastTrick = [], e.lastWinner = null, e.lastTaken = [], e.ready = [], e.apocalypse = !1, e.lastApocalypse = !1, e.trickNumber = 1, e.turn = e.leader, e.roundLeader = e.leader, e.phase = "deal", e.players.map((t) => ({
		kind: "deal",
		rid: t,
		data: { count: e.hands[t].length },
		for: [t],
		secret: { cards: e.hands[t] },
		with: !0
	}));
}
function U(e) {
	let t = Object.fromEntries(e.players.map((t) => [t, e.piles[t].reduce((e, t) => e + C(t), 0)])), n = Object.fromEntries(e.players.map((t) => [t, e.hands[t].filter((e) => e >= 45).length * 20])), r = Object.fromEntries(e.players.map((e) => [e, t[e] + n[e]])), i = { ...r }, [a, o] = e.players, s = e.players.length === 2 && (r[a] > r[o] * 2 || r[o] > r[a] * 2);
	s && ([i[a], i[o]] = [r[o], r[a]]);
	for (let t of e.players) e.scores[t] += i[t];
	e.rounds.push({
		round: e.round,
		captured: t,
		penalties: n,
		raw: r,
		points: i,
		totals: { ...e.scores },
		swapped: s
	});
	let c = Math.max(...Object.values(e.scores)), l = e.players.filter((t) => e.scores[t] === c);
	return e.chooser = l.length === 1 ? l[0] : e.lastActualWinner ?? e.roundLeader, e.phase = "score", [{
		kind: "score",
		data: { points: i }
	}];
}
function W(e) {
	if (e.phase === "deal") e.phase = e.round === 1 ? "play" : "roundLead";
	else if (e.phase === "reveal") {
		let t = O(e.trick, e.apocalypse);
		return e.lastWinner = t.winner, e.lastTrick = e.trick, e.lastTaken = t.taken, e.lastApocalypse = e.apocalypse, t.winner && (e.piles[t.winner].push(...t.taken), e.lastActualWinner = t.winner), e.discarded.push(...t.discarded), e.history.push({
			round: e.round,
			number: e.trickNumber,
			plays: e.trick,
			winner: t.winner,
			apocalypse: e.apocalypse,
			taken: t.taken
		}), e.chooser = t.winner ?? e.leader, e.trick = [], e.phase = "collect", [{
			kind: "collect",
			rid: t.winner ?? void 0,
			data: {
				plays: e.lastTrick,
				taken: t.taken,
				apocalypse: e.apocalypse
			}
		}];
	} else if (e.phase === "collect") {
		if (e.apocalypse && (e.tokens = e.tokens.map(() => !1)), e.apocalypse = !1, e.players.some((t) => e.hands[t].length === 0)) return U(e);
		e.phase = "choose";
	} else e.phase === "score" && (e.phase = e.round === 3 ? "done" : "roundOver");
	return [];
}
var G = {
	meta: A,
	schemas: {
		action: F,
		publicView: L,
		privateView: R,
		config: P
	},
	saveCompatibility: { version: "1" },
	setup(t, n, r) {
		let i = t.firstPlayer === "host" ? n[0] : n[e(r, 0, n.length)], a = {
			players: [...n],
			seed: r,
			cursor: 1,
			phase: "deal",
			round: 1,
			trickNumber: 1,
			turn: i,
			leader: i,
			chooser: i,
			roundLeader: i,
			lastActualWinner: null,
			hands: {},
			piles: {},
			scores: Object.fromEntries(n.map((e) => [e, 0])),
			tokens: Array.from({ length: w(n.length) }, () => !1),
			apocalypse: !1,
			lastApocalypse: !1,
			trick: [],
			lastTrick: [],
			lastWinner: null,
			lastTaken: [],
			discarded: [],
			unused: [],
			ready: [],
			rounds: [],
			history: [],
			seen: [],
			voids: {}
		};
		return {
			state: a,
			fx: H(a)
		};
	},
	reduce(e, t, n) {
		let r = structuredClone(e);
		if (t.type === "tick") return n.by === "$engine" ? {
			state: r,
			fx: W(r)
		} : { code: "games.apocalypse.errTurn" };
		if (!r.players.includes(n.by) || r.phase === "done") return { code: "games.apocalypse.errTurn" };
		if (t.type === "ready") return r.phase !== "roundOver" || r.ready.includes(n.by) ? { code: "games.apocalypse.errTurn" } : (r.ready.push(n.by), r.ready.length === r.players.length ? (r.round++, {
			state: r,
			fx: H(r)
		}) : { state: r });
		if (t.type === "lead") return !["choose", "roundLead"].includes(r.phase) || n.by !== r.chooser || !r.players.includes(t.rid) ? { code: "games.apocalypse.errTurn" } : (r.leader = t.rid, r.turn = t.rid, r.phase === "roundLead" ? (r.roundLeader = t.rid, r.phase = "play", { state: r }) : (r.trickNumber++, r.trick = [], r.phase = "play", { state: r }));
		if (r.phase !== "play" || r.turn !== n.by) return { code: "games.apocalypse.errTurn" };
		let i = D(r.hands[n.by], r.trick), a = [];
		if (t.type === "pass") {
			if (i.length) return { code: "games.apocalypse.errPass" };
			r.trick.push({
				rid: n.by,
				card: null,
				token: null
			});
		} else {
			if (!r.hands[n.by].includes(t.card)) return { code: "games.apocalypse.errCard" };
			if (!i.includes(t.card)) return { code: "games.apocalypse.errLegal" };
			let e = t.card, o = b(e), s = E(r.trick), c = o;
			if (x(e)) {
				if (r.tokens.every(Boolean)) c = null;
				else {
					if (t.token === void 0 || t.token >= r.tokens.length || r.tokens[t.token]) return { code: "games.apocalypse.errToken" };
					c = t.token;
				}
			}
			s !== null && o !== null && o !== s && !r.voids[n.by].includes(s) && r.voids[n.by].push(s), r.hands[n.by] = r.hands[n.by].filter((t) => t !== e), r.seen.push(e), r.trick.push({
				rid: n.by,
				card: e,
				token: c
			}), c !== null && (r.tokens[c] = !0);
			let l = !r.apocalypse && r.tokens.every(Boolean);
			r.apocalypse = r.tokens.every(Boolean), a.push({
				kind: "play",
				rid: n.by,
				data: {
					card: e,
					token: c,
					triggered: l
				}
			});
		}
		return r.trick.length === r.players.length ? (r.phase = "reveal", r.lastWinner = O(r.trick, r.apocalypse).winner) : r.turn = r.players[(r.players.indexOf(n.by) + 1) % r.players.length], {
			state: r,
			fx: a
		};
	},
	nextTickIn(e) {
		return e.phase === "deal" ? z.deal : e.phase === "reveal" ? z.reveal : e.phase === "collect" ? z.collect : e.phase === "score" ? z.score : null;
	},
	viewFor(e, t) {
		let n = e.phase === "play" && e.turn === t;
		return {
			public: {
				phase: e.phase,
				round: e.round,
				trickNumber: e.trickNumber,
				turn: e.turn,
				leader: e.leader,
				chooser: e.chooser,
				tokens: [...e.tokens],
				apocalypse: e.apocalypse,
				lastApocalypse: e.lastApocalypse,
				trick: structuredClone(e.trick),
				lastTrick: structuredClone(e.lastTrick),
				lastWinner: e.lastWinner,
				lastTaken: [...e.lastTaken],
				players: e.players.map((t) => ({
					rid: t,
					score: e.scores[t],
					handCount: e.hands[t].length,
					captured: e.piles[t].length,
					pilePoints: e.piles[t].reduce((e, t) => e + C(t), 0),
					ready: e.ready.includes(t)
				})),
				rounds: structuredClone(e.rounds),
				history: structuredClone(e.history),
				seen: [...e.seen],
				voids: structuredClone(e.voids)
			},
			...e.players.includes(t) ? { private: {
				hand: [...e.hands[t]],
				legal: n ? D(e.hands[t], e.trick) : [],
				needsAction: n || ["choose", "roundLead"].includes(e.phase) && e.chooser === t || e.phase === "roundOver" && !e.ready.includes(t)
			} } : {}
		};
	},
	status(e) {
		return e.phase === "done" ? {
			phase: e.phase,
			...k(e.players, e.scores)
		} : { phase: e.phase };
	}
};
//#endregion
//#region src/games/apocalypse/card.tsx
function K() {
	return /* @__PURE__ */ d("svg", {
		className: "ap-march",
		viewBox: "0 0 100 140",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: /* @__PURE__ */ d("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "136",
			rx: "7",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeDasharray: "6 4",
			children: /* @__PURE__ */ d("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-20",
				dur: "1s",
				repeatCount: "indefinite"
			})
		})
	});
}
function q({ id: e }) {
	let t = a(), n = b(e), r = n === null, i = x(e), o = t(r ? i ? "games.apocalypse.chaos" : "games.apocalypse.peace" : v[n]);
	return /* @__PURE__ */ f("div", {
		className: `ap-card-face${r ? " ap-card-special" : ""}`,
		style: {
			"--ap-card-color": r ? i ? "#4a2759" : "#a9bcb9" : y[n],
			"--ap-number-color": n === 2 ? "#fff3da" : "#212132",
			"--ap-number-shadow": n === 2 ? "#29243d" : "#fff9"
		},
		children: [
			/* @__PURE__ */ d("span", {
				className: "ap-card-value",
				children: r ? i ? "5" : "☮" : C(e)
			}),
			/* @__PURE__ */ d("img", {
				className: "ap-card-art",
				src: `games/apocalypse/${r ? i ? "chaos" : "peace" : `rider-${n}`}.webp`,
				alt: "",
				draggable: !1
			}),
			!r && /* @__PURE__ */ d("img", {
				className: "ap-card-symbol",
				src: `games/apocalypse/token-${n}.svg`,
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ d("span", {
				className: "ap-card-label",
				children: o
			}),
			/* @__PURE__ */ d("span", {
				className: "ap-card-value ap-card-value-bottom",
				"aria-hidden": !0,
				children: r ? i ? "5" : "☮" : C(e)
			})
		]
	});
}
function J({ id: e, anchor: t, legal: n = !1, selected: i = !1, onClick: o }) {
	let s = a(), c = b(e), { ref: l, hidden: u } = r(t ?? null), p = c === null ? s(x(e) ? "games.apocalypse.chaos" : "games.apocalypse.peace") : s("games.apocalypse.card", {
		suit: s(v[c]),
		n: C(e)
	});
	return /* @__PURE__ */ f("button", {
		ref: l,
		type: "button",
		className: `ap-card${n ? " ap-card-legal" : ""}${i ? " ap-card-selected" : ""}`,
		style: { visibility: u ? "hidden" : void 0 },
		disabled: !o,
		onClick: o,
		"aria-label": p,
		"aria-pressed": o ? i : void 0,
		children: [/* @__PURE__ */ d(q, { id: e }), n && /* @__PURE__ */ d(K, {})]
	});
}
//#endregion
//#region src/games/apocalypse/score-table.tsx
function Y({ pub: e, nameOf: t }) {
	let n = a();
	return /* @__PURE__ */ d("div", {
		className: "ap-score-scroll",
		children: /* @__PURE__ */ f("table", {
			className: "ap-score-table",
			children: [
				/* @__PURE__ */ d("thead", { children: /* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", {}), e.players.map((e) => /* @__PURE__ */ d("th", { children: t(e.rid) }, e.rid))] }) }),
				/* @__PURE__ */ d("tbody", { children: e.rounds.map((t) => /* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ f("th", { children: [n("games.apocalypse.roundShort", { n: t.round }), t.swapped && /* @__PURE__ */ d("small", { children: n("games.apocalypse.swap") })] }), e.players.map((e) => /* @__PURE__ */ f("td", { children: [/* @__PURE__ */ d("strong", { children: t.points[e.rid] }), /* @__PURE__ */ f("small", { children: [
					n("games.apocalypse.captureRow"),
					" ",
					t.captured[e.rid],
					/* @__PURE__ */ d("br", {}),
					n("games.apocalypse.penaltyRow"),
					" ",
					t.penalties[e.rid]
				] })] }, e.rid))] }, t.round)) }),
				/* @__PURE__ */ d("tfoot", { children: /* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", { children: n("games.apocalypse.finalTotal") }), e.players.map((e) => /* @__PURE__ */ d("td", { children: e.score }, e.rid))] }) })
			]
		})
	});
}
//#endregion
//#region src/games/apocalypse/view-player.tsx
function X({ public: e, private: t, members: o, myRid: c, send: u }) {
	let p = e, m = t, h = a(), g = i((e) => e.locale), _ = (e) => {
		let t = o.find((t) => t.rid === e);
		return t ? l(t, g) : h("games.apocalypse.unknownPlayer");
	}, [y, b] = n(null), [S, C] = n(null), w = `${c}:${p.round}:${p.trickNumber}:${p.phase}:${p.turn}`, T = y?.scope === w && m?.legal.includes(y.card) ? y : null, D = p.phase === "play" && p.turn === c, O = ["choose", "roundLead"].includes(p.phase) && p.chooser === c, k = T !== null && x(T.card) && !p.tokens.every(Boolean), A = p.phase === "deal" ? h("games.apocalypse.deal") : p.phase === "reveal" ? p.lastWinner ? h("games.apocalypse.reveal", { name: _(p.lastWinner) }) : h("games.apocalypse.noWinner") : p.phase === "collect" ? h("games.apocalypse.collect") : p.phase === "score" ? h("games.apocalypse.scoring") : p.phase === "roundOver" ? h("games.apocalypse.roundOver") : ["choose", "roundLead"].includes(p.phase) ? O ? h("games.apocalypse.chooseYou") : h("games.apocalypse.chooseWait", { name: _(p.chooser) }) : D ? h(k ? "games.apocalypse.chooseToken" : "games.apocalypse.turnYou") : h("games.apocalypse.turnWait", { name: _(p.turn) }), j = p.phase === "collect" ? p.lastTrick : p.trick, M = E(j), { ref: N } = r("table"), { ref: P } = r("discard"), { ref: F } = r("hand"), I = p.players.find((e) => e.rid === c);
	return /* @__PURE__ */ d("div", {
		className: "ap-root",
		children: /* @__PURE__ */ f(s, {
			adaptive: !0,
			className: "ap-screen",
			scroll: !1,
			banner: /* @__PURE__ */ f("header", {
				className: "ap-header",
				children: [
					/* @__PURE__ */ f("div", {
						className: "ap-heading",
						children: [/* @__PURE__ */ d("b", { children: "APOCALYPSE" }), /* @__PURE__ */ f("span", { children: [
							h("games.apocalypse.round", { n: p.round }),
							" · ",
							h("games.apocalypse.trick", { n: p.trickNumber })
						] })]
					}),
					/* @__PURE__ */ d("div", {
						className: "ap-status",
						role: "status",
						children: A
					}),
					/* @__PURE__ */ f("div", {
						className: "ap-tools",
						children: [/* @__PURE__ */ d("button", {
							type: "button",
							onClick: () => C("scores"),
							"aria-label": h("games.apocalypse.scoreTitle"),
							children: "Σ"
						}), /* @__PURE__ */ d("button", {
							type: "button",
							onClick: () => C("history"),
							"aria-label": h("games.apocalypse.history"),
							children: "≡"
						})]
					})
				]
			}),
			actionsHeight: "ap-actions-height",
			actions: /* @__PURE__ */ f("div", {
				className: "ap-hand-area",
				children: [
					/* @__PURE__ */ f("div", {
						className: "ap-hand-title",
						children: [h("games.apocalypse.hand"), /* @__PURE__ */ d("span", { children: h("games.apocalypse.handCount", { n: m?.hand.length ?? 0 }) })]
					}),
					/* @__PURE__ */ d("div", {
						className: "ap-hand",
						ref: F,
						children: m?.hand.map((e) => /* @__PURE__ */ d(J, {
							id: e,
							anchor: `hand:${e}`,
							legal: D && m.legal.includes(e),
							selected: T?.card === e,
							onClick: D && m.legal.includes(e) ? () => b(T?.card === e ? null : {
								scope: w,
								card: e
							}) : void 0
						}, e))
					}),
					/* @__PURE__ */ d("div", {
						className: "ap-decision",
						children: p.phase === "roundOver" ? /* @__PURE__ */ d("button", {
							type: "button",
							className: "ap-primary",
							disabled: !m?.needsAction,
							onClick: () => u({ type: "ready" }),
							children: h(I?.ready ? "games.apocalypse.waiting" : "games.apocalypse.next")
						}) : D && !m?.legal.length ? /* @__PURE__ */ d("button", {
							type: "button",
							className: "ap-primary",
							onClick: () => u({ type: "pass" }),
							children: h("games.apocalypse.pass")
						}) : /* @__PURE__ */ d("button", {
							type: "button",
							className: "ap-primary",
							disabled: !D || T === null || k && T.token === void 0,
							onClick: () => {
								T && (u({
									type: "play",
									card: T.card,
									...T.token === void 0 ? {} : { token: T.token }
								}), b(null));
							},
							children: h("games.apocalypse.play")
						})
					})
				]
			}),
			children: [/* @__PURE__ */ f("main", {
				className: `ap-main${p.apocalypse ? " ap-main-apocalypse" : ""}`,
				ref: N,
				children: [
					/* @__PURE__ */ d("div", {
						className: "ap-seals",
						children: p.tokens.map((e, t) => /* @__PURE__ */ d(ee, {
							suit: t,
							black: e,
							legal: k && !e,
							selected: T?.token === t,
							onClick: k && !e ? () => b({
								...T,
								token: t
							}) : void 0
						}, t))
					}),
					/* @__PURE__ */ f("div", {
						className: "ap-trick-caption",
						children: [/* @__PURE__ */ d("span", { children: h(p.apocalypse ? "games.apocalypse.apocalypse" : "games.apocalypse.regular") }), /* @__PURE__ */ d("span", { children: h(M === null ? "games.apocalypse.noLead" : "games.apocalypse.lead", { suit: M === null ? "" : h(v[M]) }) })]
					}),
					/* @__PURE__ */ d("div", {
						className: "ap-table",
						style: { "--ap-players": p.players.length },
						children: p.players.map((e) => /* @__PURE__ */ d(te, {
							player: e,
							member: o.find((t) => t.rid === e.rid),
							myRid: c,
							name: _(e.rid),
							turn: p.phase === "play" && p.turn === e.rid,
							choosing: O,
							onChoose: () => u({
								type: "lead",
								rid: e.rid
							}),
							play: j.find((t) => t.rid === e.rid),
							collecting: p.phase === "collect",
							winner: p.phase === "reveal" && p.lastWinner === e.rid
						}, e.rid))
					}),
					/* @__PURE__ */ d("div", {
						className: "ap-discard",
						ref: P,
						"aria-hidden": !0,
						children: "◇"
					}),
					["score", "roundOver"].includes(p.phase) && /* @__PURE__ */ f("div", {
						className: "ap-round-sheet",
						children: [/* @__PURE__ */ d("h2", { children: h("games.apocalypse.scoreTitle") }), /* @__PURE__ */ d(Y, {
							pub: p,
							nameOf: _
						})]
					})
				]
			}), S && /* @__PURE__ */ d(Z, {
				title: h(S === "history" ? "games.apocalypse.history" : "games.apocalypse.scoreTitle"),
				onClose: () => C(null),
				children: d(S === "scores" ? Y : Q, {
					pub: p,
					nameOf: _
				})
			})]
		})
	});
}
function ee({ suit: e, black: t, legal: n, selected: i, onClick: o }) {
	let s = a(), { ref: c } = r(`token:${e}`);
	return /* @__PURE__ */ f("button", {
		type: "button",
		ref: c,
		className: `ap-seal${n ? " ap-seal-legal" : ""}${i ? " ap-seal-selected" : ""}`,
		disabled: !o,
		onClick: o,
		"aria-label": s("games.apocalypse.token", {
			suit: s(v[e]),
			state: s(t ? "games.apocalypse.tokenBlack" : "games.apocalypse.tokenOpen")
		}),
		children: [/* @__PURE__ */ d("img", {
			className: "ap-seal-image",
			src: `games/apocalypse/${t ? "fallen" : "token"}-${e}.svg`,
			alt: ""
		}, String(t)), n && /* @__PURE__ */ d(K, {})]
	});
}
function te({ player: e, member: t, myRid: n, name: i, turn: s, choosing: l, onChoose: u, play: p, collecting: m, winner: h }) {
	let g = a(), { ref: _ } = r(`seat:${e.rid}`), { ref: v } = r(`pile:${e.rid}`), { ref: y } = r(`score:${e.rid}`);
	return /* @__PURE__ */ f("section", {
		ref: _,
		className: `ap-seat${s ? " ap-seat-turn" : ""}${h ? " ap-seat-winner" : ""}`,
		style: { "--ap-player-color": t ? o[t.colorIndex % o.length].hex : "#704099" },
		children: [
			/* @__PURE__ */ f("button", {
				type: "button",
				className: "ap-nameplate",
				disabled: !l,
				onClick: u,
				"aria-label": l ? `${g("games.apocalypse.chooseYou")} · ${i}` : i,
				children: [
					t && /* @__PURE__ */ d(c, {
						m: t,
						myRid: n,
						action: null,
						anchorName: null,
						box: "size-7",
						img: "size-6"
					}),
					/* @__PURE__ */ f("span", {
						className: "ap-name",
						children: [i, e.ready && " ✓"]
					}),
					/* @__PURE__ */ d("strong", {
						ref: y,
						title: g("games.apocalypse.total"),
						children: e.score
					}),
					l && /* @__PURE__ */ d(K, {})
				]
			}),
			/* @__PURE__ */ d("div", {
				className: "ap-slot",
				children: p?.card !== null && p?.card !== void 0 ? /* @__PURE__ */ d("div", {
					style: { visibility: m ? "hidden" : void 0 },
					children: /* @__PURE__ */ d(J, {
						id: p.card,
						anchor: `trick:${e.rid}`
					})
				}) : /* @__PURE__ */ d("span", {
					className: "ap-card-space",
					children: p ? g("games.apocalypse.skipped") : "✧"
				})
			}),
			/* @__PURE__ */ f("div", {
				className: "ap-seat-foot",
				children: [/* @__PURE__ */ d("span", {
					ref: v,
					children: g("games.apocalypse.captured", { n: e.pilePoints })
				}), /* @__PURE__ */ d("span", { children: g("games.apocalypse.handCount", { n: e.handCount }) })]
			})
		]
	});
}
function Z({ title: e, onClose: t, children: n }) {
	let r = a();
	return /* @__PURE__ */ d("div", {
		className: "ap-modal",
		onClick: t,
		children: /* @__PURE__ */ f("section", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": e,
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ f("header", { children: [/* @__PURE__ */ d("h2", { children: e }), /* @__PURE__ */ d("button", {
				type: "button",
				"aria-label": r("games.apocalypse.close"),
				onClick: t,
				children: "×"
			})] }), /* @__PURE__ */ d("div", {
				className: "ap-modal-content",
				children: n
			})]
		})
	});
}
function Q({ pub: e, nameOf: t }) {
	let n = a();
	return /* @__PURE__ */ d("div", {
		className: "ap-history",
		children: [...e.history].reverse().map((e) => /* @__PURE__ */ f("article", { children: [
			/* @__PURE__ */ f("h3", { children: [
				n("games.apocalypse.logTrick", {
					r: e.round,
					n: e.number
				}),
				" · ",
				n(e.apocalypse ? "games.apocalypse.apocalypse" : "games.apocalypse.regular")
			] }),
			/* @__PURE__ */ d("div", {
				className: "ap-history-plays",
				children: e.plays.map((e) => /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("span", { children: t(e.rid) }), e.card === null ? /* @__PURE__ */ d("small", { children: n("games.apocalypse.skipped") }) : /* @__PURE__ */ d(J, { id: e.card })] }, e.rid))
			}),
			/* @__PURE__ */ d("p", { children: e.winner ? n("games.apocalypse.won", {
				name: t(e.winner),
				n: e.taken.reduce((e, t) => e + C(t), 0)
			}) : n("games.apocalypse.discard") })
		] }, `${e.round}:${e.number}`))
	});
}
//#endregion
//#region src/games/apocalypse/bot.ts
var ne = (e, t) => {
	let n = e.public, r = e.private;
	if (!r?.needsAction) return null;
	if (n.phase === "roundOver") return { action: { type: "ready" } };
	if (n.phase === "choose" || n.phase === "roundLead") return n.players.length === 2 && t.difficulty !== "weak" ? { action: {
		type: "lead",
		rid: t.rid
	} } : { action: {
		type: "lead",
		rid: n.players.filter((e) => e.rid !== t.rid).sort((e, t) => t.score - e.score)[0]?.rid ?? t.rid
	} };
	if (n.phase !== "play" || n.turn !== t.rid) return null;
	if (!r.legal.length) return { action: { type: "pass" } };
	let i = E(n.trick), a = r.legal.flatMap((e) => x(e) && !n.tokens.every(Boolean) ? n.tokens.flatMap((t, n) => t ? [] : [{
		card: e,
		token: n
	}]) : [{ card: e }]), o = (e) => {
		let { card: a, token: o } = e, s = [...n.tokens], c = b(a);
		c !== null && (s[c] = !0), o !== void 0 && (s[o] = !0);
		let l = s.every(Boolean), u = [...n.trick, {
			rid: t.rid,
			card: a,
			token: o ?? null
		}], d = O(u, l).winner === t.rid, f = C(a), p = n.trick.length === n.players.length - 1, m = n.players.length === 2;
		if (S(a)) return m ? r.hand.length < 5 ? -30 : 6 : r.hand.length < 5 || l && d ? -15 : -3;
		let h = d ? l ? u.reduce((e, t) => e + (t.card === null ? 0 : C(t.card)), 0) + (p ? 0 : 7) : f : 0;
		return m ? -h + (x(a) ? -8 : 0) - (i === null && c !== null ? f * .4 : 0) : h + (x(a) ? -6 : -f * .25) + (i === null && c !== null ? f * .4 : 0);
	};
	return { action: {
		type: "play",
		...t.difficulty === "weak" ? a[0] : a.reduce((e, t) => o(t) < o(e) ? t : e)
	} };
}, re = (e, t, n) => {
	if (e.type === "pass") return n("games.apocalypse.pass");
	if (e.type === "ready") return n("games.apocalypse.next");
	if (e.type === "lead") return n("games.apocalypse.chooseYou");
	if (e.type !== "play") return "";
	if (x(e.card) && e.token !== void 0) return n("games.apocalypse.hintToken", { suit: n(v[e.token]) });
	let r = b(e.card);
	return n("games.apocalypse.hintPlay", { card: r === null ? n(x(e.card) ? "games.apocalypse.chaos" : "games.apocalypse.peace") : n("games.apocalypse.card", {
		suit: n(v[r]),
		n: C(e.card)
	}) });
};
//#endregion
//#region src/games/apocalypse/fx.tsx
function $({ card: e, box: t }) {
	return /* @__PURE__ */ d("div", {
		className: "ap-root",
		style: {
			width: t.w,
			height: t.h,
			background: "transparent",
			borderRadius: 5,
			boxShadow: "2px 4px 6px #29243d55"
		},
		children: /* @__PURE__ */ d(q, { id: e })
	});
}
var ie = {
	deal(e, t) {
		let n = e.secret?.cards, r = t.anchor("table");
		if (!n || !r) return null;
		let i = [], a = n.map((e, n) => {
			let a = t.anchor(`hand:${e}`);
			if (!a) return null;
			let o = {
				x: r.x + r.w / 2 - a.w / 2,
				y: r.y + r.h / 2 - a.h / 2,
				w: a.w,
				h: a.h
			};
			return i.push(`hand:${e}`), /* @__PURE__ */ d(m, {
				from: o,
				to: a,
				ms: 400,
				delay: n * 20,
				children: /* @__PURE__ */ d($, {
					card: e,
					box: o
				})
			}, e);
		});
		return {
			ms: z.deal - 30,
			hide: i,
			node: a
		};
	},
	play(e, t) {
		let n = e.data, r = t.anchor(`trick:${e.rid}`), i = t.anchor(`hand:${n.card}`) ?? (e.rid === t.myRid ? t.anchor("hand") : t.anchor(`seat:${e.rid}`)), a = n.token === null ? null : t.anchor(`token:${n.token}`);
		if (!r || !i) return null;
		let o = {
			x: i.x + i.w / 2 - r.w / 2,
			y: i.y + i.h / 2 - r.h / 2,
			w: r.w,
			h: r.h
		};
		return {
			ms: z.play,
			hide: [`trick:${e.rid}`],
			node: /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d(m, {
				from: o,
				to: r,
				ms: z.play - 20,
				children: /* @__PURE__ */ d($, {
					card: n.card,
					box: o
				})
			}), a && n.triggered && /* @__PURE__ */ d(p, {
				at: a,
				ms: z.play,
				children: /* @__PURE__ */ d("span", {
					style: {
						color: "#704099",
						fontSize: 35
					},
					children: "✦"
				})
			})] })
		};
	},
	collect(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`pile:${e.rid}`) : null, i = t.anchor("discard");
		return i ? {
			ms: z.collect - 20,
			node: n.plays.map((e, a) => {
				let o = t.anchor(`trick:${e.rid}`);
				if (e.card === null || !o) return null;
				let s = n.taken.includes(e.card) && r ? r : i, c = {
					x: s.x + s.w / 2 - 9,
					y: s.y + s.h / 2 - 12,
					w: 18,
					h: 25
				};
				return /* @__PURE__ */ d(m, {
					from: o,
					to: c,
					ms: z.collect - 180,
					delay: a * 22,
					children: /* @__PURE__ */ d($, {
						card: e.card,
						box: o
					})
				}, e.rid);
			})
		} : null;
	},
	score(e, t) {
		let n = e.data.points;
		return {
			ms: z.score - 50,
			node: Object.entries(n).map(([e, n]) => {
				let r = t.anchor(`score:${e}`);
				return r ? /* @__PURE__ */ d(p, {
					at: r,
					ms: z.score - 100,
					children: /* @__PURE__ */ f("span", {
						style: {
							color: "#704099",
							fontSize: 26,
							background: "#f1ead8",
							padding: "2px 6px"
						},
						children: ["+", n]
					})
				}, e) : null;
			})
		};
	}
};
//#endregion
//#region src/games/apocalypse/game-over.tsx
function ae({ public: e, result: t, members: r, myRid: s, hintCount: p, onPlayAgain: m, onBackToLobby: h }) {
	let g = e, _ = a(), v = i((e) => e.locale), [y, b] = n(!1), x = (e) => {
		let t = r.find((t) => t.rid === e);
		return t ? l(t, v) : _("games.apocalypse.unknownPlayer");
	};
	return /* @__PURE__ */ f("div", {
		className: "ap-root ap-over",
		children: [
			/* @__PURE__ */ f("header", {
				className: "ap-over-heading",
				children: [
					/* @__PURE__ */ d("span", { children: "APOCALYPSE" }),
					/* @__PURE__ */ d("h1", { children: _("games.apocalypse.finalTitle") }),
					/* @__PURE__ */ f("p", { children: [_("games.apocalypse.winner"), p !== void 0 && ` · ${_("session.hint.usedCount", { n: p })}`] })
				]
			}),
			/* @__PURE__ */ f("main", {
				className: "ap-over-main",
				children: [
					/* @__PURE__ */ d("div", {
						className: "ap-results",
						children: t.ranking.map((e) => {
							let n = g.players.find((t) => t.rid === e), i = t.winner.includes(e), a = r.find((t) => t.rid === e);
							return /* @__PURE__ */ f("section", {
								className: `ap-result${i ? " ap-result-winner" : ""}`,
								style: { "--ap-player-color": a ? o[a.colorIndex % o.length].hex : "#704099" },
								children: [a && /* @__PURE__ */ d(c, {
									m: a,
									myRid: s,
									action: null,
									anchorName: null,
									box: "size-12",
									img: "size-10"
								}), /* @__PURE__ */ f("div", { children: [
									/* @__PURE__ */ f("h2", { children: [x(e), s === e && /* @__PURE__ */ f("small", { children: [" · ", _("lobby.you")] })] }),
									/* @__PURE__ */ d("strong", { children: n.score }),
									i && /* @__PURE__ */ d("p", { children: _(t.winner.length > 1 ? "games.apocalypse.tied" : "games.apocalypse.winner") }),
									t.autopilot?.[e] !== void 0 && /* @__PURE__ */ d("small", { children: _("session.autopilot.share", { n: Math.round(t.autopilot[e] * 100) }) })
								] })]
							}, e);
						})
					}),
					/* @__PURE__ */ f("section", {
						className: "ap-over-scores",
						children: [/* @__PURE__ */ d("h2", { children: _("games.apocalypse.scoreTitle") }), /* @__PURE__ */ d(Y, {
							pub: g,
							nameOf: x
						})]
					}),
					/* @__PURE__ */ d("button", {
						type: "button",
						className: "ap-secondary",
						onClick: () => b(!0),
						children: _("games.apocalypse.history")
					})
				]
			}),
			/* @__PURE__ */ d("footer", {
				className: "ap-over-actions",
				children: m || h ? /* @__PURE__ */ f(u, { children: [m && /* @__PURE__ */ d("button", {
					type: "button",
					className: "ap-primary",
					onClick: m,
					children: _("session.result.playAgain")
				}), h && /* @__PURE__ */ d("button", {
					type: "button",
					className: "ap-secondary",
					onClick: h,
					children: _("session.result.backToLobby")
				})] }) : /* @__PURE__ */ d("p", { children: _("games.apocalypse.finalWait") })
			}),
			y && /* @__PURE__ */ d(Z, {
				title: _("games.apocalypse.history"),
				onClose: () => b(!1),
				children: /* @__PURE__ */ d(Q, {
					pub: g,
					nameOf: x
				})
			})
		]
	});
}
//#endregion
//#region src/games/apocalypse/options.tsx
function oe({ value: e, onChange: t }) {
	let n = a(), r = P.safeParse(e), i = r.success ? r.data : P.parse(void 0);
	return /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d(g, {
		title: n("games.apocalypse.firstPlayer"),
		columns: 2,
		children: ["random", "host"].map((e) => /* @__PURE__ */ d(h, {
			name: "apocalypse-first",
			value: e,
			checked: i.firstPlayer === e,
			label: n(e === "random" ? "games.apocalypse.random" : "games.apocalypse.host"),
			accent: A.accent,
			onChange: () => t({ firstPlayer: e })
		}, e))
	}), /* @__PURE__ */ d("p", {
		className: "mt-3 text-sm",
		children: n("games.apocalypse.duelNote")
	})] });
}
//#endregion
//#region .bgparty/cache/pack-entry/apocalypse/entry.tsx
var se = {
	definition: G,
	View: X,
	bot: ne,
	describe: re,
	fx: ie,
	OverView: ae,
	Options: oe,
	locales: {
		zh: {
			name: "Apocalypse",
			desc: "翻转灾厄封印，避开罚分；三轮吃墩，最低分获胜",
			rules: "目标：\n进行三轮，累计分最低者获胜；最低分并列者共享胜利。\n准备：\n· 骑士牌分五种花色，每色各有1、2、3、4、6、7、8、9、10。三或四人使用四色，五或六人使用五色，对应的灾厄标记均从彩色面开始。\n· 3人游戏每人发10张骑士牌，4人或5人游戏每人发8张，6人游戏每人发7张；每人另获得1张混沌牌和1张宁静牌；余牌本轮不用。首轮默认随机领出，可在设置中改为主机领出。\n出牌：\n· 从领出者开始顺时针出牌。第一张骑士牌决定本墩花色；有该花色时必须跟色，也可以出特殊牌；没有该花色时可出任意牌。\n· 同一墩最多出现一张混沌和一张宁静。没有合法牌时必须跳过，不能自愿跳过。\n· 骑士牌将本花色灾厄标记翻至黑面，已经翻黑的不变。混沌必须选择一个仍为彩色面的标记翻黑；全部已黑时不再翻标记。宁静不翻标记。\n· 混沌始终视为本墩花色、数值为5；宁静无花色、无数值，不能赢墩。\n结算：\n· 普通墩：本墩花色中数值最大的牌获胜，赢家只收取自己打出的牌，其余弃置。\n· 当所有灾厄标记都翻黑时，当前墩立即变为灾厄墩。本墩花色中数值最小的牌获胜，并收取所有已出的牌。该墩结算后，所有标记翻回彩色面。\n· 每墩赢家指定下一墩领出者，可以指定自己。极端情况下，整墩仅有宁静和跳过，没有赢家；所有牌弃置，由本墩领出者指定下一位。\n轮末：\n· 当前墩结算后，若有人没有手牌，本轮立即结束。收取的骑士牌按面值计分，混沌计5分，宁静计0分；每张未打出的特殊牌另罚20分。\n· 每轮之间重新洗混并发放手牌，但不重置灾厄标记。累计分最高者指定下一轮领出者；最高分并列时由最后实际赢墩者指定。若本轮尚无实际赢墩者，则由本轮最初的领出者指定。\n双人变体：\n· 使用三色共27张骑士牌，加混沌、宁静各3张，全部混洗，各发13张，余牌不用。相同特殊牌仍须遵守每墩各类型最多一张。\n· 每轮分别计算得分和未打特殊牌罚分后，若一人的本轮分严格超过对手的两倍，两人互换本轮分再加入累计分；恰好两倍不交换。其他规则相同。",
			red: "红色",
			green: "绿色",
			purple: "紫色",
			blue: "蓝色",
			gold: "金色",
			chaos: "混沌",
			peace: "宁静",
			card: "{{suit}} {{n}}",
			round: "第 {{n}} 轮 / 共三轮",
			trick: "第 {{n}} 墩",
			turnYou: "轮到你出牌",
			turnWait: "等待 {{name}} 出牌",
			deal: "正在发牌",
			reveal: "{{name}} 赢墩",
			noWinner: "本墩无人获胜",
			collect: "正在收牌",
			scoring: "本轮计分",
			roundOver: "本轮结束",
			chooseYou: "请选择下一位领出者",
			chooseWait: "等待 {{name}} 指定领出者",
			lead: "本墩花色：{{suit}}",
			noLead: "首张骑士牌决定花色",
			regular: "普通墩 · 最高有效牌获胜",
			apocalypse: "灾厄墩 · 最低有效牌获胜",
			hand: "你的手牌",
			play: "出牌",
			pass: "无合法牌，跳过",
			next: "确认轮分",
			waiting: "等待其他玩家",
			ready: "已确认",
			chooseToken: "请选择一个彩色灾厄标记",
			token: "{{suit}}：{{state}}",
			tokenOpen: "彩色面",
			tokenBlack: "黑面",
			total: "累计分",
			captured: "收牌 {{n}} 分",
			handCount: "余牌 {{n}} 张",
			skipped: "跳过",
			empty: "等待出牌",
			scoreTitle: "三轮计分册",
			roundShort: "第 {{n}} 轮",
			captureRow: "收牌分",
			penaltyRow: "特殊牌罚分",
			swap: "本轮分互换",
			roundPoints: "本轮分",
			finalTotal: "总分",
			history: "出牌记录",
			logTrick: "第 {{r}} 轮 · 第 {{n}} 墩",
			won: "{{name}} 收取 {{n}} 分",
			discard: "全部弃置",
			close: "关闭",
			finalTitle: "第三道封印之后",
			winner: "最低分获胜",
			tied: "并列获胜",
			finalWait: "等待主机开始下一局",
			firstPlayer: "首轮领出",
			random: "随机选择",
			host: "主机领出",
			duelNote: "双人时自动使用规则书中的双人变体",
			errTurn: "当前不能执行此操作",
			errCard: "这张牌不在你的手牌中",
			errLegal: "请跟随本墩花色，或使用尚未出现的特殊牌",
			errPass: "你还有合法牌，不能跳过",
			errToken: "请选择一个仍为彩色面的灾厄标记",
			hintPlay: "打出{{card}}",
			hintToken: "打出混沌，并翻转{{suit}}标记",
			hintLead: "指定{{name}}领出",
			unknownPlayer: "同行者"
		},
		en: {
			name: "Apocalypse",
			desc: "Turn the seals, avoid the points. Three rounds of perilous trick-taking.",
			rules: "Objective:\nPlay three rounds. The lowest total wins; tied players share victory.\nSetup:\n· Five Horseman suits each contain 1, 2, 3, 4, 6, 7, 8, 9 and 10. Use four suits with three or four players, and five suits with five or six. Matching Apocalypse tokens start coloured side up.\n· Deal 10 Horseman cards per player with three players, 8 per player with four or five players, or 7 per player with six players. Each player also receives one Chaos and one Tranquility. Set unused cards aside. The first leader is random by default; host lead is available in settings.\nPlaying:\n· Starting with the leader, play clockwise. The first Horseman card determines the leading suit. Follow that suit if possible, or play a Special card. If void in the suit, play any card.\n· At most one Chaos and one Tranquility may appear in a trick. Pass only if you have no legal card.\n· A Horseman turns its matching token black. A token already black stays black. Chaos must turn one remaining coloured token black; if all are black, it turns none. Tranquility turns no token.\n· Chaos always belongs to the leading suit and has value 5. Tranquility has no suit or value and cannot win.\nResolution:\n· Regular trick: the highest card of the leading suit wins. The winner keeps only their own played card; discard all others.\n· When all tokens are black, the current trick immediately becomes an Apocalypse: the lowest card of the leading suit wins and takes every played card. Reset all tokens to coloured after resolving it.\n· The winner chooses who leads next and may choose themselves. In the rare case where only Tranquility and passes appear, nobody wins; discard the cards and let the previous leader choose the next leader.\nScoring:\n· End the round after resolving a trick if any hand is empty. Captured Horsemen score face value, Chaos scores 5, Tranquility scores 0. Each unplayed Special card adds 20 points.\n· Redeal between rounds but do not reset tokens. The highest cumulative scorer chooses the next round leader; if tied, the last actual trick winner chooses. If none exists, use the previous round leader.\nDuel variant:\n· Shuffle three suits (27 Horsemen), three Chaos and three Tranquility. Deal 13 cards each and set the rest aside. The one-per-type limit still applies.\n· After adding captured points and unplayed-Special penalties, if one player scored strictly more than twice the other, swap their round scores before adding them to totals. Exactly twice does not swap. All other rules apply.",
			red: "Red",
			green: "Green",
			purple: "Purple",
			blue: "Blue",
			gold: "Gold",
			chaos: "Chaos",
			peace: "Tranquility",
			card: "{{suit}} {{n}}",
			round: "Round {{n}} / 3",
			trick: "Trick {{n}}",
			turnYou: "Your turn",
			turnWait: "Waiting for {{name}}",
			deal: "Dealing cards",
			reveal: "{{name}} wins the trick",
			noWinner: "No trick winner",
			collect: "Collecting cards",
			scoring: "Scoring the round",
			roundOver: "Round complete",
			chooseYou: "Choose the next leader",
			chooseWait: "{{name}} chooses the leader",
			lead: "Leading suit: {{suit}}",
			noLead: "First Horseman sets the suit",
			regular: "Regular · Highest eligible card wins",
			apocalypse: "Apocalypse · Lowest eligible card wins",
			hand: "Your hand",
			play: "Play card",
			pass: "No legal card — pass",
			next: "Confirm score",
			waiting: "Waiting for others",
			ready: "Confirmed",
			chooseToken: "Choose a coloured Apocalypse token",
			token: "{{suit}}: {{state}}",
			tokenOpen: "coloured",
			tokenBlack: "black",
			total: "Total",
			captured: "Captured {{n}} points",
			handCount: "{{n}} cards left",
			skipped: "Passed",
			empty: "Awaiting card",
			scoreTitle: "Book of three rounds",
			roundShort: "Round {{n}}",
			captureRow: "Captured",
			penaltyRow: "Unplayed Specials",
			swap: "Round scores swapped",
			roundPoints: "Round points",
			finalTotal: "Total",
			history: "Trick history",
			logTrick: "Round {{r}} · Trick {{n}}",
			won: "{{name}} takes {{n}} points",
			discard: "All discarded",
			close: "Close",
			finalTitle: "Beyond the third seal",
			winner: "Lowest score wins",
			tied: "Shared victory",
			finalWait: "Waiting for the host",
			firstPlayer: "First round leader",
			random: "Random player",
			host: "Host leads",
			duelNote: "Two players automatically use the official Duel variant.",
			errTurn: "You cannot do that now",
			errCard: "That card is not in your hand",
			errLegal: "Follow suit or play an available Special card",
			errPass: "You have a legal card and cannot pass",
			errToken: "Choose a token that is still coloured",
			hintPlay: "Play {{card}}",
			hintToken: "Play Chaos and turn the {{suit}} token",
			hintLead: "Choose {{name}} to lead",
			unknownPlayer: "Companion"
		}
	}
};
//#endregion
export { se as default };
