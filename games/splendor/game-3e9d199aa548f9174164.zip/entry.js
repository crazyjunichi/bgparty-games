import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useFxAnchor as r } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as i } from "@bgparty/sdk/fx/delta-number";
import { useT as a } from "@bgparty/sdk/i18n";
import { PhaseBanner as o } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as s } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { Texture as l } from "@bgparty/sdk/texture";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { Floater as p, FlySprite as m } from "@bgparty/sdk/fx/primitives";
//#region src/games/splendor/cards.ts
var h = [
	"white",
	"blue",
	"green",
	"red",
	"black"
], g = [
	{
		id: "t1-01",
		tier: 1,
		bonus: "black",
		points: 0,
		cost: {
			blue: 1,
			green: 1,
			red: 1,
			white: 1
		}
	},
	{
		id: "t1-02",
		tier: 1,
		bonus: "black",
		points: 0,
		cost: {
			blue: 2,
			green: 1,
			red: 1,
			white: 1
		}
	},
	{
		id: "t1-03",
		tier: 1,
		bonus: "black",
		points: 0,
		cost: {
			blue: 2,
			red: 1,
			white: 2
		}
	},
	{
		id: "t1-04",
		tier: 1,
		bonus: "black",
		points: 0,
		cost: {
			black: 1,
			green: 1,
			red: 3
		}
	},
	{
		id: "t1-05",
		tier: 1,
		bonus: "black",
		points: 0,
		cost: {
			green: 2,
			red: 1
		}
	},
	{
		id: "t1-06",
		tier: 1,
		bonus: "black",
		points: 0,
		cost: {
			green: 2,
			white: 2
		}
	},
	{
		id: "t1-07",
		tier: 1,
		bonus: "black",
		points: 0,
		cost: { green: 3 }
	},
	{
		id: "t1-08",
		tier: 1,
		bonus: "black",
		points: 1,
		cost: { blue: 4 }
	},
	{
		id: "t1-09",
		tier: 1,
		bonus: "blue",
		points: 0,
		cost: {
			black: 1,
			green: 1,
			red: 1,
			white: 1
		}
	},
	{
		id: "t1-10",
		tier: 1,
		bonus: "blue",
		points: 0,
		cost: {
			black: 1,
			green: 1,
			red: 2,
			white: 1
		}
	},
	{
		id: "t1-11",
		tier: 1,
		bonus: "blue",
		points: 0,
		cost: {
			green: 2,
			red: 2,
			white: 1
		}
	},
	{
		id: "t1-12",
		tier: 1,
		bonus: "blue",
		points: 0,
		cost: {
			blue: 1,
			green: 3,
			red: 1
		}
	},
	{
		id: "t1-13",
		tier: 1,
		bonus: "blue",
		points: 0,
		cost: {
			black: 2,
			white: 1
		}
	},
	{
		id: "t1-14",
		tier: 1,
		bonus: "blue",
		points: 0,
		cost: {
			black: 2,
			green: 2
		}
	},
	{
		id: "t1-15",
		tier: 1,
		bonus: "blue",
		points: 0,
		cost: { black: 3 }
	},
	{
		id: "t1-16",
		tier: 1,
		bonus: "blue",
		points: 1,
		cost: { red: 4 }
	},
	{
		id: "t1-17",
		tier: 1,
		bonus: "white",
		points: 0,
		cost: {
			black: 1,
			blue: 1,
			green: 1,
			red: 1
		}
	},
	{
		id: "t1-18",
		tier: 1,
		bonus: "white",
		points: 0,
		cost: {
			black: 1,
			blue: 1,
			green: 2,
			red: 1
		}
	},
	{
		id: "t1-19",
		tier: 1,
		bonus: "white",
		points: 0,
		cost: {
			black: 1,
			blue: 2,
			green: 2
		}
	},
	{
		id: "t1-20",
		tier: 1,
		bonus: "white",
		points: 0,
		cost: {
			black: 1,
			blue: 1,
			white: 3
		}
	},
	{
		id: "t1-21",
		tier: 1,
		bonus: "white",
		points: 0,
		cost: {
			black: 1,
			red: 2
		}
	},
	{
		id: "t1-22",
		tier: 1,
		bonus: "white",
		points: 0,
		cost: {
			black: 2,
			blue: 2
		}
	},
	{
		id: "t1-23",
		tier: 1,
		bonus: "white",
		points: 0,
		cost: { blue: 3 }
	},
	{
		id: "t1-24",
		tier: 1,
		bonus: "white",
		points: 1,
		cost: { green: 4 }
	},
	{
		id: "t1-25",
		tier: 1,
		bonus: "green",
		points: 0,
		cost: {
			black: 1,
			blue: 1,
			red: 1,
			white: 1
		}
	},
	{
		id: "t1-26",
		tier: 1,
		bonus: "green",
		points: 0,
		cost: {
			black: 2,
			blue: 1,
			red: 1,
			white: 1
		}
	},
	{
		id: "t1-27",
		tier: 1,
		bonus: "green",
		points: 0,
		cost: {
			black: 2,
			blue: 1,
			red: 2
		}
	},
	{
		id: "t1-28",
		tier: 1,
		bonus: "green",
		points: 0,
		cost: {
			blue: 3,
			green: 1,
			white: 1
		}
	},
	{
		id: "t1-29",
		tier: 1,
		bonus: "green",
		points: 0,
		cost: {
			blue: 1,
			white: 2
		}
	},
	{
		id: "t1-30",
		tier: 1,
		bonus: "green",
		points: 0,
		cost: {
			blue: 2,
			red: 2
		}
	},
	{
		id: "t1-31",
		tier: 1,
		bonus: "green",
		points: 0,
		cost: { red: 3 }
	},
	{
		id: "t1-32",
		tier: 1,
		bonus: "green",
		points: 1,
		cost: { black: 4 }
	},
	{
		id: "t1-33",
		tier: 1,
		bonus: "red",
		points: 0,
		cost: {
			black: 1,
			blue: 1,
			green: 1,
			white: 1
		}
	},
	{
		id: "t1-34",
		tier: 1,
		bonus: "red",
		points: 0,
		cost: {
			black: 1,
			blue: 1,
			green: 1,
			white: 2
		}
	},
	{
		id: "t1-35",
		tier: 1,
		bonus: "red",
		points: 0,
		cost: {
			black: 2,
			green: 1,
			white: 2
		}
	},
	{
		id: "t1-36",
		tier: 1,
		bonus: "red",
		points: 0,
		cost: {
			black: 3,
			red: 1,
			white: 1
		}
	},
	{
		id: "t1-37",
		tier: 1,
		bonus: "red",
		points: 0,
		cost: {
			blue: 2,
			green: 1
		}
	},
	{
		id: "t1-38",
		tier: 1,
		bonus: "red",
		points: 0,
		cost: {
			red: 2,
			white: 2
		}
	},
	{
		id: "t1-39",
		tier: 1,
		bonus: "red",
		points: 0,
		cost: { white: 3 }
	},
	{
		id: "t1-40",
		tier: 1,
		bonus: "red",
		points: 1,
		cost: { white: 4 }
	},
	{
		id: "t2-01",
		tier: 2,
		bonus: "black",
		points: 1,
		cost: {
			blue: 2,
			green: 2,
			white: 3
		}
	},
	{
		id: "t2-02",
		tier: 2,
		bonus: "black",
		points: 1,
		cost: {
			black: 2,
			green: 3,
			white: 3
		}
	},
	{
		id: "t2-03",
		tier: 2,
		bonus: "black",
		points: 2,
		cost: {
			blue: 1,
			green: 4,
			red: 2
		}
	},
	{
		id: "t2-04",
		tier: 2,
		bonus: "black",
		points: 2,
		cost: {
			green: 5,
			red: 3
		}
	},
	{
		id: "t2-05",
		tier: 2,
		bonus: "black",
		points: 2,
		cost: { white: 5 }
	},
	{
		id: "t2-06",
		tier: 2,
		bonus: "black",
		points: 3,
		cost: { black: 6 }
	},
	{
		id: "t2-07",
		tier: 2,
		bonus: "blue",
		points: 1,
		cost: {
			blue: 2,
			green: 2,
			red: 3
		}
	},
	{
		id: "t2-08",
		tier: 2,
		bonus: "blue",
		points: 1,
		cost: {
			black: 3,
			blue: 2,
			green: 3
		}
	},
	{
		id: "t2-09",
		tier: 2,
		bonus: "blue",
		points: 2,
		cost: {
			blue: 3,
			white: 5
		}
	},
	{
		id: "t2-10",
		tier: 2,
		bonus: "blue",
		points: 2,
		cost: {
			black: 4,
			red: 1,
			white: 2
		}
	},
	{
		id: "t2-11",
		tier: 2,
		bonus: "blue",
		points: 2,
		cost: { blue: 5 }
	},
	{
		id: "t2-12",
		tier: 2,
		bonus: "blue",
		points: 3,
		cost: { blue: 6 }
	},
	{
		id: "t2-13",
		tier: 2,
		bonus: "white",
		points: 1,
		cost: {
			black: 2,
			green: 3,
			red: 2
		}
	},
	{
		id: "t2-14",
		tier: 2,
		bonus: "white",
		points: 1,
		cost: {
			blue: 3,
			red: 3,
			white: 2
		}
	},
	{
		id: "t2-15",
		tier: 2,
		bonus: "white",
		points: 2,
		cost: {
			black: 2,
			green: 1,
			red: 4
		}
	},
	{
		id: "t2-16",
		tier: 2,
		bonus: "white",
		points: 2,
		cost: {
			black: 3,
			red: 5
		}
	},
	{
		id: "t2-17",
		tier: 2,
		bonus: "white",
		points: 2,
		cost: { red: 5 }
	},
	{
		id: "t2-18",
		tier: 2,
		bonus: "white",
		points: 3,
		cost: { white: 6 }
	},
	{
		id: "t2-19",
		tier: 2,
		bonus: "green",
		points: 1,
		cost: {
			green: 2,
			red: 3,
			white: 3
		}
	},
	{
		id: "t2-20",
		tier: 2,
		bonus: "green",
		points: 1,
		cost: {
			black: 2,
			blue: 3,
			white: 2
		}
	},
	{
		id: "t2-21",
		tier: 2,
		bonus: "green",
		points: 2,
		cost: {
			black: 1,
			blue: 2,
			white: 4
		}
	},
	{
		id: "t2-22",
		tier: 2,
		bonus: "green",
		points: 2,
		cost: {
			blue: 5,
			green: 3
		}
	},
	{
		id: "t2-23",
		tier: 2,
		bonus: "green",
		points: 2,
		cost: { green: 5 }
	},
	{
		id: "t2-24",
		tier: 2,
		bonus: "green",
		points: 3,
		cost: { green: 6 }
	},
	{
		id: "t2-25",
		tier: 2,
		bonus: "red",
		points: 1,
		cost: {
			black: 3,
			red: 2,
			white: 2
		}
	},
	{
		id: "t2-26",
		tier: 2,
		bonus: "red",
		points: 1,
		cost: {
			black: 3,
			blue: 3,
			red: 2
		}
	},
	{
		id: "t2-27",
		tier: 2,
		bonus: "red",
		points: 2,
		cost: {
			blue: 4,
			green: 2,
			white: 1
		}
	},
	{
		id: "t2-28",
		tier: 2,
		bonus: "red",
		points: 2,
		cost: {
			black: 5,
			white: 3
		}
	},
	{
		id: "t2-29",
		tier: 2,
		bonus: "red",
		points: 2,
		cost: { black: 5 }
	},
	{
		id: "t2-30",
		tier: 2,
		bonus: "red",
		points: 3,
		cost: { red: 6 }
	},
	{
		id: "t3-01",
		tier: 3,
		bonus: "black",
		points: 3,
		cost: {
			blue: 3,
			green: 5,
			red: 3,
			white: 3
		}
	},
	{
		id: "t3-02",
		tier: 3,
		bonus: "black",
		points: 4,
		cost: { red: 7 }
	},
	{
		id: "t3-03",
		tier: 3,
		bonus: "black",
		points: 4,
		cost: {
			black: 3,
			green: 3,
			red: 6
		}
	},
	{
		id: "t3-04",
		tier: 3,
		bonus: "black",
		points: 5,
		cost: {
			black: 3,
			red: 7
		}
	},
	{
		id: "t3-05",
		tier: 3,
		bonus: "blue",
		points: 3,
		cost: {
			black: 5,
			green: 3,
			red: 3,
			white: 3
		}
	},
	{
		id: "t3-06",
		tier: 3,
		bonus: "blue",
		points: 4,
		cost: { white: 7 }
	},
	{
		id: "t3-07",
		tier: 3,
		bonus: "blue",
		points: 4,
		cost: {
			black: 3,
			blue: 3,
			white: 6
		}
	},
	{
		id: "t3-08",
		tier: 3,
		bonus: "blue",
		points: 5,
		cost: {
			blue: 3,
			white: 7
		}
	},
	{
		id: "t3-09",
		tier: 3,
		bonus: "white",
		points: 3,
		cost: {
			black: 3,
			blue: 3,
			green: 3,
			red: 5
		}
	},
	{
		id: "t3-10",
		tier: 3,
		bonus: "white",
		points: 4,
		cost: { black: 7 }
	},
	{
		id: "t3-11",
		tier: 3,
		bonus: "white",
		points: 4,
		cost: {
			black: 6,
			red: 3,
			white: 3
		}
	},
	{
		id: "t3-12",
		tier: 3,
		bonus: "white",
		points: 5,
		cost: {
			black: 7,
			white: 3
		}
	},
	{
		id: "t3-13",
		tier: 3,
		bonus: "green",
		points: 3,
		cost: {
			black: 3,
			blue: 3,
			red: 3,
			white: 5
		}
	},
	{
		id: "t3-14",
		tier: 3,
		bonus: "green",
		points: 4,
		cost: { blue: 7 }
	},
	{
		id: "t3-15",
		tier: 3,
		bonus: "green",
		points: 4,
		cost: {
			blue: 6,
			green: 3,
			white: 3
		}
	},
	{
		id: "t3-16",
		tier: 3,
		bonus: "green",
		points: 5,
		cost: {
			blue: 7,
			green: 3
		}
	},
	{
		id: "t3-17",
		tier: 3,
		bonus: "red",
		points: 3,
		cost: {
			black: 3,
			blue: 5,
			green: 3,
			white: 3
		}
	},
	{
		id: "t3-18",
		tier: 3,
		bonus: "red",
		points: 4,
		cost: { green: 7 }
	},
	{
		id: "t3-19",
		tier: 3,
		bonus: "red",
		points: 4,
		cost: {
			blue: 3,
			green: 6,
			red: 3
		}
	},
	{
		id: "t3-20",
		tier: 3,
		bonus: "red",
		points: 5,
		cost: {
			green: 7,
			red: 3
		}
	}
], _ = [
	{
		id: "n1",
		points: 3,
		requires: {
			green: 4,
			red: 4
		}
	},
	{
		id: "n2",
		points: 3,
		requires: {
			blue: 4,
			green: 4
		}
	},
	{
		id: "n3",
		points: 3,
		requires: {
			white: 4,
			blue: 4
		}
	},
	{
		id: "n4",
		points: 3,
		requires: {
			white: 4,
			black: 4
		}
	},
	{
		id: "n5",
		points: 3,
		requires: {
			red: 4,
			black: 4
		}
	},
	{
		id: "n6",
		points: 3,
		requires: {
			blue: 3,
			green: 3,
			red: 3
		}
	},
	{
		id: "n7",
		points: 3,
		requires: {
			white: 3,
			red: 3,
			black: 3
		}
	},
	{
		id: "n8",
		points: 3,
		requires: {
			white: 3,
			blue: 3,
			black: 3
		}
	},
	{
		id: "n9",
		points: 3,
		requires: {
			green: 3,
			red: 3,
			black: 3
		}
	},
	{
		id: "n10",
		points: 3,
		requires: {
			white: 3,
			blue: 3,
			green: 3
		}
	}
], v = new Map(g.map((e) => [e.id, e])), y = new Map(_.map((e) => [e.id, e])), b = (e) => v.get(e), x = (e) => y.get(e), S = {
	id: "splendor",
	tier: "released",
	mechanics: ["engine-building", "set-collection"],
	interactionTags: [],
	nameKey: "games.splendor.name",
	descKey: "games.splendor.desc",
	rulesKey: "games.splendor.rules",
	icon: "💎",
	iconImg: "games/splendor.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/splendor/en.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3],
	accent: "#0284c7",
	releasedAt: "2026-09-12",
	search: {
		py: "cui can bao shi",
		init: "ccbs"
	},
	hotseat: "cover"
}, C = t.enum([
	"white",
	"blue",
	"green",
	"red",
	"black"
]), w = t.union([
	t.object({
		type: t.literal("take"),
		gems: t.array(C).min(1).max(3)
	}),
	t.object({
		type: t.literal("buy"),
		cardId: t.string(),
		from: t.enum(["market", "reserved"])
	}),
	t.object({
		type: t.literal("reserve"),
		cardId: t.string()
	}),
	t.object({
		type: t.literal("reserve"),
		tier: t.union([
			t.literal(1),
			t.literal(2),
			t.literal(3)
		])
	}),
	t.object({
		type: t.literal("return"),
		gems: t.array(C).min(1)
	}),
	t.object({
		type: t.literal("chooseNoble"),
		nobleId: t.string()
	}),
	t.object({ type: t.literal("pass") })
]), T = t.string(), E = t.object({
	white: t.int().nonnegative(),
	blue: t.int().nonnegative(),
	green: t.int().nonnegative(),
	red: t.int().nonnegative(),
	black: t.int().nonnegative(),
	gold: t.int().nonnegative()
}), D = t.object({
	phase: t.enum([
		"play",
		"return",
		"chooseNoble",
		"done"
	]),
	turn: T,
	market: t.array(t.object({
		tier: t.union([
			t.literal(1),
			t.literal(2),
			t.literal(3)
		]),
		cards: t.array(t.string()),
		deckCount: t.int().nonnegative()
	})),
	nobles: t.array(t.string()),
	bank: E,
	nobleChoices: t.array(t.string()).nullable(),
	lastRound: t.boolean(),
	players: t.array(t.object({
		rid: T,
		tokens: E,
		bonuses: t.object({
			white: t.int().nonnegative(),
			blue: t.int().nonnegative(),
			green: t.int().nonnegative(),
			red: t.int().nonnegative(),
			black: t.int().nonnegative()
		}),
		points: t.int().nonnegative(),
		cardCount: t.int().nonnegative(),
		reservedCount: t.int().nonnegative(),
		nobleCount: t.int().nonnegative()
	}))
}), O = t.object({ reserved: t.array(t.string()) }), k = [...h, "gold"], A = 4, j = 3, M = () => ({
	white: 0,
	blue: 0,
	green: 0,
	red: 0,
	black: 0,
	gold: 0
}), N = (e) => k.reduce((t, n) => t + e[n], 0);
function P(e, t) {
	return e.purchased[t].reduce((e, t) => e + b(t).points, 0) + e.noblesWon[t].length * 3;
}
function F(e, t, n) {
	let r = {}, i = 0;
	for (let a of h) {
		let o = Math.max(0, (e[a] ?? 0) - t[a]), s = Math.min(n[a], o);
		s > 0 && (r[a] = s), i += o - s;
	}
	return i > n.gold ? null : {
		pay: r,
		gold: i
	};
}
function I(t, n, r) {
	let i = 0, a = (t) => {
		for (let n = t.length - 1; n > 0; --n) {
			let a = e(r, i, n + 1);
			i += 1, [t[n], t[a]] = [t[a], t[n]];
		}
		return t;
	}, o = {}, s = {};
	for (let e of [
		1,
		2,
		3
	]) {
		o[e] = a(g.filter((t) => t.tier === e).map((e) => e.id)), s[e] = [];
		for (let t = 0; t < A; t += 1) s[e].push(o[e].pop());
	}
	let c = {
		2: 4,
		3: 5,
		4: 7
	}[n.length], l = {
		white: c,
		blue: c,
		green: c,
		red: c,
		black: c,
		gold: 5
	}, u = {
		players: n,
		turnIdx: 0,
		phase: "play",
		decks: o,
		market: s,
		nobles: a(_.map((e) => e.id)).slice(0, n.length + 1),
		bank: l,
		tokens: {},
		bonuses: {},
		purchased: {},
		reserved: {},
		noblesWon: {},
		mustReturn: 0,
		nobleChoices: null,
		lastRound: !1,
		progressMark: "",
		stallCount: 0
	};
	for (let e of n) u.tokens[e] = M(), u.bonuses[e] = {
		white: 0,
		blue: 0,
		green: 0,
		red: 0,
		black: 0
	}, u.purchased[e] = [], u.reserved[e] = [], u.noblesWon[e] = [];
	return {
		state: u,
		fx: []
	};
}
function L(e) {
	let t = N(e.tokens[e.players[e.turnIdx]]) - 10;
	return t > 0 ? (e.phase = "return", e.mustReturn = t, []) : ee(e);
}
function ee(e) {
	let t = e.players[e.turnIdx], n = e.nobles.filter((n) => h.every((r) => e.bonuses[t][r] >= (x(n).requires[r] ?? 0)));
	if (n.length > 1) return e.phase = "chooseNoble", e.nobleChoices = n, [];
	let r = [];
	if (n.length === 1) {
		let i = e.nobles.indexOf(n[0]), a = e.nobles.length;
		e.nobles = e.nobles.filter((e) => e !== n[0]), e.noblesWon[t].push(n[0]), r.push({
			kind: "noble",
			rid: t,
			data: {
				nobleId: n[0],
				slot: i,
				rowLen: a
			}
		});
	}
	return R(e), r;
}
function R(e) {
	let t = e.players.reduce((t, n) => t + e.purchased[n].length + e.reserved[n].length + e.noblesWon[n].length, 0) + "|" + k.map((t) => e.bank[t]).join(",");
	if (t === e.progressMark ? e.stallCount += 1 : (e.progressMark = t, e.stallCount = 0), e.stallCount >= e.players.length) {
		e.phase = "done";
		return;
	}
	!e.lastRound && P(e, e.players[e.turnIdx]) >= 15 && (e.lastRound = !0);
	let n = (e.turnIdx + 1) % e.players.length;
	if (e.lastRound && n === 0) {
		e.phase = "done";
		return;
	}
	e.turnIdx = n, e.phase = "play";
}
function z(e, t, n) {
	if (e.phase === "done") return { code: "games.splendor.errNotYourTurn" };
	let r = n.by;
	if (e.players[e.turnIdx] !== r) return { code: "games.splendor.errNotYourTurn" };
	if (t.type === "return") {
		if (e.phase !== "return" || t.gems.length !== e.mustReturn) return { code: "games.splendor.errBadReturn" };
		let n = {};
		for (let e of t.gems) n[e] = (n[e] ?? 0) + 1;
		if (h.some((t) => (n[t] ?? 0) > e.tokens[r][t])) return { code: "games.splendor.errBadReturn" };
		let i = structuredClone(e);
		for (let e of h) {
			let t = n[e] ?? 0;
			i.tokens[r][e] -= t, i.bank[e] += t;
		}
		return i.mustReturn = 0, {
			state: i,
			fx: [{
				kind: "return",
				rid: r,
				data: { gems: t.gems }
			}, ...ee(i)]
		};
	}
	if (t.type === "chooseNoble") {
		if (e.phase !== "chooseNoble" || !e.nobleChoices?.includes(t.nobleId)) return { code: "games.splendor.errBadNoble" };
		let n = structuredClone(e), i = n.nobles.indexOf(t.nobleId), a = n.nobles.length;
		return n.nobles = n.nobles.filter((e) => e !== t.nobleId), n.noblesWon[r].push(t.nobleId), n.nobleChoices = null, R(n), {
			state: n,
			fx: [{
				kind: "noble",
				rid: r,
				data: {
					nobleId: t.nobleId,
					slot: i,
					rowLen: a
				}
			}]
		};
	}
	if (e.phase !== "play") return { code: "games.splendor.errNotYourTurn" };
	if (t.type === "pass") {
		if (h.some((t) => e.bank[t] > 0) || e.reserved[r].length < j && [
			1,
			2,
			3
		].some((t) => e.market[t].length > 0 || e.decks[t].length > 0) || [
			...e.market[1],
			...e.market[2],
			...e.market[3],
			...e.reserved[r]
		].some((t) => F(b(t).cost, e.bonuses[r], e.tokens[r]) !== null)) return { code: "games.splendor.errBadPass" };
		let t = structuredClone(e);
		return R(t), {
			state: t,
			fx: []
		};
	}
	if (t.type === "take") {
		let n = {};
		for (let e of t.gems) n[e] = (n[e] ?? 0) + 1;
		let i = h.filter((e) => (n[e] ?? 0) > 0);
		if (i.length === 1 && n[i[0]] === 2) {
			if (e.bank[i[0]] < 4) return { code: "games.splendor.errBadTake" };
		} else {
			if (i.some((t) => n[t] !== 1 || e.bank[t] < 1)) return { code: "games.splendor.errBadTake" };
			let t = h.filter((t) => e.bank[t] > 0).length;
			if (i.length !== Math.min(3, t)) return { code: "games.splendor.errBadTake" };
		}
		let a = structuredClone(e);
		for (let e of t.gems) a.tokens[r][e] += 1, --a.bank[e];
		return {
			state: a,
			fx: [{
				kind: "take",
				rid: r,
				data: { gems: t.gems }
			}, ...L(a)]
		};
	}
	if (t.type === "reserve") {
		if (e.reserved[r].length >= j) return { code: "games.splendor.errReserveFull" };
		let n;
		if ("cardId" in t) {
			let i = [
				1,
				2,
				3
			].find((n) => e.market[n].includes(t.cardId));
			if (!i) return { code: "games.splendor.errBadCard" };
			n = t.cardId;
			let a = structuredClone(e), o = a.market[i].indexOf(n), s = a.market[i].length;
			a.market[i] = a.market[i].filter((e) => e !== n);
			let c = a.decks[i].pop();
			return c && a.market[i].push(c), a.reserved[r].push(n), a.bank.gold > 0 && (--a.bank.gold, a.tokens[r].gold += 1), {
				state: a,
				fx: [{
					kind: "reserve",
					rid: r,
					data: {
						cardId: n,
						tier: i,
						slot: o,
						rowLen: s
					}
				}, ...L(a)]
			};
		}
		if (e.decks[t.tier].length === 0) return { code: "games.splendor.errBadCard" };
		let i = structuredClone(e);
		return n = i.decks[t.tier].pop(), i.reserved[r].push(n), i.bank.gold > 0 && (--i.bank.gold, i.tokens[r].gold += 1), {
			state: i,
			fx: [{
				kind: "reserve",
				rid: r,
				data: {
					tier: t.tier,
					blind: !0
				},
				for: [r],
				secret: { cardId: n }
			}, ...L(i)]
		};
	}
	let i = g.find((e) => e.id === t.cardId);
	if (!i) return { code: "games.splendor.errBadCard" };
	let a = null;
	if (t.from === "market") {
		if (a = [
			1,
			2,
			3
		].find((n) => e.market[n].includes(t.cardId)) ?? null, a === null) return { code: "games.splendor.errBadCard" };
	} else if (!e.reserved[r].includes(t.cardId)) return { code: "games.splendor.errBadCard" };
	let o = F(i.cost, e.bonuses[r], e.tokens[r]);
	if (!o) return { code: "games.splendor.errCantAfford" };
	let s = structuredClone(e);
	for (let e of h) {
		let t = o.pay[e] ?? 0;
		s.tokens[r][e] -= t, s.bank[e] += t;
	}
	s.tokens[r].gold -= o.gold, s.bank.gold += o.gold;
	let c;
	if (a !== null) {
		let e = s.market[a].indexOf(i.id), n = s.market[a].length;
		s.market[a] = s.market[a].filter((e) => e !== i.id);
		let r = s.decks[a].pop();
		r && s.market[a].push(r), c = {
			cardId: i.id,
			from: t.from,
			tier: a,
			slot: e,
			rowLen: n
		};
	} else c = {
		cardId: i.id,
		from: t.from,
		slot: s.reserved[r].indexOf(i.id)
	}, s.reserved[r] = s.reserved[r].filter((e) => e !== i.id);
	return s.purchased[r].push(i.id), s.bonuses[r][i.bonus] += 1, {
		state: s,
		fx: [{
			kind: "buy",
			rid: r,
			data: c
		}, ...ee(s)]
	};
}
function B(e, t) {
	return {
		public: {
			phase: e.phase,
			turn: e.players[e.turnIdx],
			market: [
				1,
				2,
				3
			].map((t) => ({
				tier: t,
				cards: e.market[t],
				deckCount: e.decks[t].length
			})),
			nobles: e.nobles,
			bank: { ...e.bank },
			nobleChoices: e.nobleChoices,
			lastRound: e.lastRound,
			players: e.players.map((t) => ({
				rid: t,
				tokens: { ...e.tokens[t] },
				bonuses: { ...e.bonuses[t] },
				points: P(e, t),
				cardCount: e.purchased[t].length,
				reservedCount: e.reserved[t].length,
				nobleCount: e.noblesWon[t].length
			}))
		},
		private: { reserved: [...e.reserved[t] ?? []] }
	};
}
function te(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => {
		let r = P(e, n) - P(e, t);
		return r === 0 ? e.purchased[t].length - e.purchased[n].length : r;
	}), n = t[0], r = t.filter((t) => P(e, t) === P(e, n) && e.purchased[t].length === e.purchased[n].length), i = {};
	for (let t of e.players) i[t] = P(e, t);
	return {
		phase: "done",
		winner: r,
		ranking: t,
		scores: i
	};
}
var ne = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: S,
	schemas: {
		action: w,
		publicView: D,
		privateView: O
	},
	setup: I,
	reduce: z,
	viewFor: B,
	status: te
}, V = {
	white: {
		bg: "var(--color-sp-white)",
		fg: "var(--color-sp-white-ink)",
		deep: "var(--color-sp-white-deep)"
	},
	blue: {
		bg: "var(--color-sp-blue)",
		fg: "var(--color-surface)",
		deep: "var(--color-sp-blue-deep)"
	},
	green: {
		bg: "var(--color-sp-green)",
		fg: "var(--color-surface)",
		deep: "var(--color-sp-green-deep)"
	},
	red: {
		bg: "var(--color-sp-red)",
		fg: "var(--color-surface)",
		deep: "var(--color-sp-red-deep)"
	},
	black: {
		bg: "var(--color-sp-black)",
		fg: "var(--color-surface)",
		deep: "var(--color-sp-black-deep)"
	},
	gold: {
		bg: "var(--color-sp-gold)",
		fg: "var(--color-sp-gold-ink)",
		deep: "var(--color-sp-gold-deep)"
	}
}, re = {
	1: "Ⅰ",
	2: "Ⅱ",
	3: "Ⅲ"
}, ie = {
	1: "var(--color-sp-deck-1)",
	2: "var(--color-sp-deck-2)",
	3: "var(--color-sp-deck-3)"
}, ae = {
	1: "var(--color-sp-art-1)",
	2: "var(--color-sp-art-2)",
	3: "var(--color-sp-art-3)"
};
function H({ fill: e, line: t, size: n, x: r = 0, y: i = 0 }) {
	return /* @__PURE__ */ f("svg", {
		x: r,
		y: i,
		width: n,
		height: n,
		viewBox: "0 0 24 24",
		"aria-hidden": !0,
		className: "flex-none",
		children: [/* @__PURE__ */ d("path", {
			d: "M12 2.5 L20 9 L16.5 21.5 L7.5 21.5 L4 9 Z",
			fill: e
		}), /* @__PURE__ */ d("path", {
			d: "M4 9 L20 9 M8.2 9 L10.2 21.3 M15.8 9 L13.8 21.3",
			fill: "none",
			stroke: t,
			strokeWidth: 1,
			opacity: .55
		})]
	});
}
function oe({ fg: e, bg: t, size: n = 11 }) {
	return /* @__PURE__ */ f("svg", {
		width: n,
		height: n,
		viewBox: "0 0 16 16",
		"aria-hidden": !0,
		className: "flex-none",
		children: [
			/* @__PURE__ */ d("circle", {
				cx: 8,
				cy: 8,
				r: 7.4,
				fill: e
			}),
			[
				0,
				60,
				120,
				180,
				240,
				300
			].map((e) => /* @__PURE__ */ d("rect", {
				x: 7.1,
				y: .9,
				width: 1.8,
				height: 3,
				rx: .9,
				fill: t,
				transform: `rotate(${e} 8 8)`
			}, e)),
			/* @__PURE__ */ d("circle", {
				cx: 8,
				cy: 8,
				r: 3.4,
				fill: t
			})
		]
	});
}
function se({ fg: e, bg: t, size: n = 11 }) {
	return /* @__PURE__ */ f("svg", {
		width: n,
		height: n,
		viewBox: "0 0 16 16",
		"aria-hidden": !0,
		className: "flex-none",
		children: [/* @__PURE__ */ d("rect", {
			x: 3,
			y: 1.8,
			width: 10,
			height: 12.4,
			rx: 2,
			fill: e
		}), /* @__PURE__ */ d("path", {
			d: "M8 4.6 L11.2 7.2 L10.1 11.6 L5.9 11.6 L4.8 7.2 Z",
			fill: t
		})]
	});
}
function U({ id: e, w: t = 68, h: n = 92 }) {
	let r = b(e), i = V[r.bonus], a = h.filter((e) => (r.cost[e] ?? 0) > 0), o = 88 - a.length * 16;
	return /* @__PURE__ */ f("svg", {
		width: t,
		height: n,
		viewBox: "0 0 68 92",
		"aria-hidden": !0,
		className: "block flex-none overflow-visible",
		children: [
			/* @__PURE__ */ d("rect", {
				x: 1,
				y: 1,
				width: 66,
				height: 90,
				rx: 5,
				fill: "var(--color-sp-parchment)",
				stroke: "var(--color-ink)",
				strokeWidth: 2
			}),
			/* @__PURE__ */ d("rect", {
				x: 18,
				y: 20,
				width: 48,
				height: 70,
				fill: ae[r.tier]
			}),
			/* @__PURE__ */ d("path", {
				d: "M18 82 66 42v48H18Z",
				fill: "var(--color-surface)",
				opacity: .16
			}),
			/* @__PURE__ */ d("path", {
				d: "M21 90V43Q21 25 42 25T63 43v47",
				fill: "none",
				stroke: "var(--color-sp-brass)",
				strokeWidth: 1.25
			}),
			/* @__PURE__ */ d("path", {
				d: "M26 90V45Q26 32 42 32T58 45v45",
				fill: "none",
				stroke: "var(--color-sp-brass)",
				strokeWidth: .85
			}),
			/* @__PURE__ */ d("path", {
				d: "M19 31h46M22 82h40M21 86h42M23 32v50M61 32v50",
				fill: "none",
				stroke: "var(--color-sp-brass)",
				strokeWidth: 1,
				opacity: .82
			}),
			r.tier === 3 && /* @__PURE__ */ d("path", {
				d: "M28 27 33 22 42 24 51 22 56 27",
				fill: "none",
				stroke: "var(--color-sp-brass)",
				strokeWidth: 1.1
			}),
			/* @__PURE__ */ d("path", {
				d: "M42 39 54 55 42 73 30 55Z",
				fill: "var(--color-sp-velvet-deep)",
				stroke: "var(--color-sp-brass)",
				strokeWidth: 1.4
			}),
			/* @__PURE__ */ d(H, {
				fill: i.bg,
				line: i.fg,
				x: 31,
				y: 43,
				size: 22
			}),
			/* @__PURE__ */ d("path", {
				d: "M31 77h22",
				stroke: "var(--color-sp-brass)",
				strokeWidth: 1.3
			}),
			/* @__PURE__ */ d("circle", {
				cx: 42,
				cy: 28,
				r: 2,
				fill: "var(--color-sp-brass)"
			}),
			/* @__PURE__ */ d("rect", {
				x: 2,
				y: 20,
				width: 16,
				height: 70,
				fill: "var(--color-sp-parchment)",
				opacity: .92
			}),
			/* @__PURE__ */ d("path", {
				d: "M18 20v70",
				stroke: "var(--color-sp-brass-deep)",
				strokeWidth: .9
			}),
			/* @__PURE__ */ d("rect", {
				x: 2,
				y: 2,
				width: 64,
				height: 17,
				rx: 3,
				fill: "var(--color-sp-parchment)"
			}),
			/* @__PURE__ */ d("path", {
				d: "M3 19h62",
				stroke: "var(--color-sp-brass-deep)",
				strokeWidth: 1
			}),
			r.points > 0 ? /* @__PURE__ */ d("text", {
				x: 6,
				y: 16,
				fill: "var(--color-ink)",
				fontFamily: "var(--font-display)",
				fontWeight: 800,
				fontSize: 18,
				children: r.points
			}) : /* @__PURE__ */ d("path", {
				d: "M8 12h14",
				stroke: "var(--color-sp-brass-deep)",
				strokeWidth: 1.1,
				opacity: .65
			}),
			/* @__PURE__ */ d("circle", {
				cx: 55,
				cy: 10.5,
				r: 8,
				fill: "var(--color-surface)",
				stroke: "var(--color-ink)",
				strokeWidth: 1.2
			}),
			/* @__PURE__ */ d(H, {
				fill: i.bg,
				line: i.fg,
				x: 48.8,
				y: 4.3,
				size: 12.4
			}),
			a.map((e, t) => /* @__PURE__ */ d(G, {
				x: 2.5,
				y: o + t * 16,
				color: e,
				n: r.cost[e] ?? 0,
				size: 15
			}, e)),
			/* @__PURE__ */ d("rect", {
				x: 2.8,
				y: 2.8,
				width: 62.4,
				height: 86.4,
				rx: 3,
				fill: "none",
				stroke: "var(--color-surface)",
				strokeWidth: .55,
				opacity: .6
			})
		]
	});
}
function W({ tier: e, w: t = 44, h: n = 92 }) {
	return /* @__PURE__ */ f("svg", {
		width: t,
		height: n,
		viewBox: "0 0 44 92",
		"aria-hidden": !0,
		className: "block flex-none overflow-visible",
		children: [
			/* @__PURE__ */ d("rect", {
				x: 1,
				y: 1,
				width: 42,
				height: 90,
				rx: 5,
				fill: ie[e],
				stroke: "var(--color-ink)",
				strokeWidth: 2
			}),
			/* @__PURE__ */ d("rect", {
				x: 4,
				y: 4,
				width: 36,
				height: 84,
				rx: 3,
				fill: "none",
				stroke: "var(--color-sp-brass)",
				strokeWidth: 1
			}),
			/* @__PURE__ */ d("path", {
				d: "M22 14 37 46 22 78 7 46ZM22 22l10 24-10 24-10-24Z",
				fill: "none",
				stroke: "var(--color-sp-brass)",
				strokeWidth: 1,
				opacity: .8
			}),
			/* @__PURE__ */ d(H, {
				fill: "var(--color-sp-brass)",
				line: "var(--color-sp-velvet-deep)",
				x: 10.5,
				y: 33,
				size: 23
			}),
			/* @__PURE__ */ d("text", {
				x: 22,
				y: 67,
				textAnchor: "middle",
				fill: "var(--color-surface)",
				fontFamily: "var(--font-display)",
				fontWeight: 800,
				fontSize: 16,
				children: re[e]
			})
		]
	});
}
function G({ x: e, y: t, color: n, n: r, size: i }) {
	let a = V[n];
	return /* @__PURE__ */ f("g", {
		transform: `translate(${e} ${t})`,
		children: [
			/* @__PURE__ */ d("circle", {
				cx: i / 2,
				cy: i / 2,
				r: i / 2 - .6,
				fill: a.deep,
				stroke: "var(--color-surface)",
				strokeWidth: 1.2
			}),
			/* @__PURE__ */ d("circle", {
				cx: i / 2,
				cy: i / 2,
				r: i / 2 - 2,
				fill: a.bg
			}),
			/* @__PURE__ */ d("path", {
				d: `M3.2 5.4 Q${i / 2} 1.7 ${i - 3.2} 5.4`,
				fill: "none",
				stroke: a.fg,
				strokeWidth: 1,
				strokeLinecap: "round",
				opacity: .6
			}),
			/* @__PURE__ */ d("text", {
				x: i / 2,
				y: i / 2 + 3.3,
				textAnchor: "middle",
				fill: a.fg,
				fontFamily: "monospace",
				fontWeight: 900,
				fontSize: 10,
				children: r
			})
		]
	});
}
function K({ id: e, w: t = 64, h: n = 42 }) {
	let r = x(e), i = h.filter((e) => (r.requires[e] ?? 0) > 0), a = V[i[0]];
	return /* @__PURE__ */ f("svg", {
		width: t,
		height: n,
		viewBox: "0 0 64 42",
		"aria-hidden": !0,
		className: "block flex-none overflow-visible",
		children: [
			/* @__PURE__ */ d("rect", {
				x: 1,
				y: 1,
				width: 62,
				height: 40,
				rx: 4,
				fill: "var(--color-sp-parchment)",
				stroke: "var(--color-ink)",
				strokeWidth: 1.8
			}),
			/* @__PURE__ */ d("rect", {
				x: 3.5,
				y: 3.5,
				width: 57,
				height: 35,
				rx: 2,
				fill: "none",
				stroke: "var(--color-sp-brass-deep)",
				strokeWidth: .8
			}),
			/* @__PURE__ */ d("path", {
				d: "M7 10 11 14 16 9 21 14 25 10l-2 9H9Z",
				fill: "var(--color-sp-brass)",
				stroke: "var(--color-sp-brass-deep)",
				strokeWidth: .8
			}),
			/* @__PURE__ */ d("text", {
				x: 16,
				y: 35,
				textAnchor: "middle",
				fill: "var(--color-ink)",
				fontFamily: "var(--font-display)",
				fontWeight: 800,
				fontSize: 15,
				children: r.points
			}),
			/* @__PURE__ */ d("path", {
				d: "M28 4v34",
				stroke: "var(--color-sp-brass-deep)",
				strokeWidth: .8
			}),
			/* @__PURE__ */ d("path", {
				d: "M35 7 46 5 57 8 55 25 46 33 37 25Z",
				fill: "var(--color-surface)",
				stroke: "var(--color-sp-brass-deep)",
				strokeWidth: 1
			}),
			/* @__PURE__ */ d(H, {
				fill: a.bg,
				line: a.fg,
				x: 39,
				y: 9,
				size: 14
			}),
			i.map((e, t) => /* @__PURE__ */ d(G, {
				x: 29 + t * 11.5,
				y: 28,
				color: e,
				n: r.requires[e] ?? 0,
				size: 11.5
			}, e))
		]
	});
}
function q({ color: e, count: t, size: n = 40 }) {
	let r = V[e];
	return /* @__PURE__ */ f("svg", {
		width: n,
		height: n,
		viewBox: "0 0 48 48",
		"aria-hidden": !0,
		className: "flex-none",
		children: [
			/* @__PURE__ */ d("circle", {
				cx: 24,
				cy: 24,
				r: 21.5,
				fill: r.deep,
				stroke: "var(--color-ink)",
				strokeWidth: 2.4
			}),
			[
				0,
				45,
				90,
				135,
				180,
				225,
				270,
				315
			].map((e) => /* @__PURE__ */ d("rect", {
				x: 22.2,
				y: 3.4,
				width: 3.6,
				height: 6,
				rx: 1.8,
				fill: r.fg,
				opacity: .55,
				transform: `rotate(${e} 24 24)`
			}, e)),
			/* @__PURE__ */ d("circle", {
				cx: 24,
				cy: 24,
				r: 13.5,
				fill: r.bg,
				stroke: r.deep,
				strokeWidth: 1.2
			}),
			/* @__PURE__ */ d("path", {
				d: "M13 16.5 Q24 9 35 16.5",
				fill: "none",
				stroke: r.fg,
				strokeWidth: 2,
				strokeLinecap: "round",
				opacity: .35
			}),
			t !== void 0 && /* @__PURE__ */ d("text", {
				x: 24,
				y: 24.8,
				textAnchor: "middle",
				dominantBaseline: "central",
				fill: r.fg,
				className: "font-mono font-extrabold tabular-nums",
				style: { fontSize: 17 },
				children: t
			})
		]
	});
}
//#endregion
//#region src/games/splendor/view-player.tsx
function ce(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ d(fe, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var le = {
	white: "games.splendor.gem.white",
	blue: "games.splendor.gem.blue",
	green: "games.splendor.gem.green",
	red: "games.splendor.gem.red",
	black: "games.splendor.gem.black",
	gold: "games.splendor.gem.gold"
};
function ue(e, t) {
	if (e.length === 0) return !1;
	let n = /* @__PURE__ */ new Map();
	for (let t of e) n.set(t, (n.get(t) ?? 0) + 1);
	if (n.size === 1) {
		let [e, r] = [...n.entries()][0];
		return r === 2 ? t[e] >= 4 : r === 1 && t[e] >= 1 && h.filter((e) => t[e] > 0).length === 1;
	}
	if ([...n.values()].some((e) => e !== 1) || [...n.keys()].some((e) => t[e] < 1)) return !1;
	let r = h.filter((e) => t[e] > 0).length;
	return e.length === Math.min(3, r);
}
function de(e, t, n) {
	return n[e] === 0 ? !1 : t.includes(e) ? !0 : !(t.length >= 3 || t.length === 2 && t[0] === t[1]);
}
function fe({ pub: e, priv: t, members: r, myRid: p, send: m }) {
	let g = a(), _ = (e) => r.find((t) => t.rid === e)?.name ?? e, v = e.players.find((e) => e.rid === p), y = e.phase === "play" && e.turn === p, x = e.phase === "return" && e.turn === p, C = e.phase === "chooseNoble" && e.turn === p, w = e.players.find((t) => t.rid === e.turn), T = e.phase === "return" && w ? k.reduce((e, t) => e + w.tokens[t], 0) - 10 : 0, [E, D] = n([]), [O, A] = n(null), [j, M] = n(null), [N, P] = n([]), I = `${e.phase}|${e.turn}|${e.lastRound}|${k.map((t) => e.bank[t]).join(",")}|${e.market.map((e) => e.cards.join(".")).join("|")}|${e.nobles.join(".")}`, [L, ee] = n(I);
	L !== I && (ee(I), D([]), A(null), M(null), P([]));
	let [R, z] = n(p), B = y || x, [te, ne] = n(B);
	te !== B && (ne(B), B && z(p));
	let V = (t) => {
		y && (z(p), A(null), M(null), D((n) => {
			let r = n.filter((e) => e === t).length;
			if (r === 0) return n.length >= 3 || n.length === 2 && n[0] === n[1] ? n : [...n, t];
			if (r === 1 && new Set(n).size === 1 && e.bank[t] >= 4) return [...n, t];
			let i = n.indexOf(t);
			return n.filter((e, t) => t !== i);
		}));
	}, re = (e, t) => {
		y && (z(p), D([]), M(null), A(O?.cardId === e ? null : {
			cardId: e,
			from: t
		}));
	}, ie = (e) => {
		y && (z(p), D([]), A(null), M(j === e ? null : e));
	}, ae = (e) => {
		x && v && P((t) => {
			let n = t.indexOf(e);
			return n >= 0 ? t.filter((e, t) => t !== n) : t.filter((t) => t === e).length >= v.tokens[e] || t.length >= T ? t : [...t, e];
		});
	}, H = O ? b(O.cardId) : null, W = H && v ? F(H.cost, v.bonuses, v.tokens) : null, G = t?.reserved ?? [], K = G.length < 3, ce = !h.some((t) => e.bank[t] > 0), le = K && e.market.some((e) => e.cards.length > 0 || e.deckCount > 0), de = v !== void 0 && (e.market.some((e) => e.cards.some((e) => F(b(e).cost, v.bonuses, v.tokens) !== null)) || G.some((e) => F(b(e).cost, v.bonuses, v.tokens) !== null)), fe = y && ce && !le && !de, J, Y;
	x ? (J = "warn", Y = g("games.splendor.returnPrompt", { n: T })) : e.phase === "return" ? (J = "info", Y = g("games.splendor.returnWait", { name: _(e.turn) })) : C ? (J = "accent", Y = g("games.splendor.noblePrompt")) : e.phase === "chooseNoble" ? (J = "info", Y = g("games.splendor.nobleWait", { name: _(e.turn) })) : y ? (J = "accent", Y = g("games.splendor.turnYou")) : (J = "info", Y = g("games.splendor.turnWait", { name: _(e.turn) }));
	let X = R === p ? v : e.players.find((e) => e.rid === R), Z = R !== p;
	return /* @__PURE__ */ d(c, {
		adaptive: !0,
		scroll: !1,
		className: "sp-view",
		banner: /* @__PURE__ */ f("div", {
			className: "sp-top",
			children: [/* @__PURE__ */ d(o, {
				tone: J,
				text: Y,
				chip: e.lastRound ? g("games.splendor.lastRound") : void 0,
				accent: S.accent
			}), /* @__PURE__ */ d(s, {
				variant: "plate",
				members: r,
				myRid: p,
				anchorOf: (e) => `seat:${e}`,
				onPick: (e) => z(e === R ? p : e),
				picked: (e) => e === R && R !== p,
				action: (t) => e.phase !== "done" && t === e.turn ? "pending" : null,
				status: (t) => {
					let n = e.players.find((e) => e.rid === t);
					if (!n) return null;
					let r = k.reduce((e, t) => e + n.tokens[t], 0), a = (e, t, n, r) => /* @__PURE__ */ f("span", {
						className: "flex items-center gap-0.5",
						style: r ? { color: S.accent } : void 0,
						children: [e, t]
					}, n);
					return /* @__PURE__ */ f("span", {
						className: "sp-player-status flex w-full flex-nowrap items-center justify-between gap-0.5 font-mono text-sm leading-4.5 font-extrabold tabular-nums whitespace-nowrap",
						children: [
							/* @__PURE__ */ f("span", {
								className: "flex items-center gap-px",
								children: [/* @__PURE__ */ d("span", {
									"aria-hidden": !0,
									className: "text-[10px]",
									children: "🏆"
								}), /* @__PURE__ */ d(i, { value: n.points })]
							}),
							a(/* @__PURE__ */ d(oe, {
								fg: "var(--color-ink)",
								bg: "var(--color-surface)"
							}), r, "t"),
							a(/* @__PURE__ */ d(se, {
								fg: "var(--color-ink)",
								bg: "var(--color-surface)"
							}), n.cardCount, "c"),
							n.reservedCount > 0 && a("📥", n.reservedCount, "r"),
							n.nobleCount > 0 && a("👑", n.nobleCount, "n", !0)
						]
					});
				}
			})]
		}),
		children: /* @__PURE__ */ f("div", {
			className: "sp-table",
			children: [
				/* @__PURE__ */ f("div", {
					className: "sp-board relative min-h-0 flex-1 overflow-hidden",
					children: [
						/* @__PURE__ */ d(l, {
							kind: "sheen",
							base: "var(--color-sp-velvet)",
							className: "absolute inset-0 size-full"
						}),
						/* @__PURE__ */ d("div", {
							className: "sp-board-scroll",
							children: /* @__PURE__ */ f("div", {
								className: "sp-board-content",
								children: [
									/* @__PURE__ */ d("div", {
										className: "sp-board-heading",
										children: g("games.splendor.noblesLabel")
									}),
									/* @__PURE__ */ d(pe, {
										pub: e,
										choosingNoble: C,
										send: m
									}),
									[
										3,
										2,
										1
									].map((t) => {
										let n = e.market.find((e) => e.tier === t);
										return n ? /* @__PURE__ */ d(me, {
											tier: t,
											cards: n.cards,
											deckCount: n.deckCount,
											myTurn: y,
											canReserve: K,
											deckSelected: j === t,
											selectedCard: O?.from === "market" ? O.cardId : null,
											affordable: (e) => v !== void 0 && F(b(e).cost, v.bonuses, v.tokens) !== null,
											onPickCard: (e) => re(e, "market"),
											onPickDeck: () => ie(t)
										}, t) : null;
									}),
									/* @__PURE__ */ f("div", {
										className: "sp-board-heading",
										children: [/* @__PURE__ */ d("span", { children: g("games.splendor.bankLabel") }), /* @__PURE__ */ d("span", {
											className: "text-[10px] font-medium opacity-75",
											children: g("games.splendor.bankGuide")
										})]
									}),
									/* @__PURE__ */ d(he, {
										pub: e,
										takeSel: E,
										myTurn: y,
										onPick: V
									})
								]
							})
						}),
						x && v && /* @__PURE__ */ f("div", {
							className: "sp-return-confirm card absolute inset-x-2 bottom-2 z-10 flex min-h-12 items-center gap-2 px-3 py-1.5",
							children: [
								/* @__PURE__ */ f("span", {
									className: "flex min-w-0 flex-1 items-center gap-1 text-sm font-extrabold",
									children: [N.map((e, t) => /* @__PURE__ */ d(q, {
										color: e,
										size: 22
									}, `${e}${t}`)), /* @__PURE__ */ f("span", {
										className: "ml-1 font-mono tabular-nums",
										children: [
											N.length,
											"/",
											T
										]
									})]
								}),
								/* @__PURE__ */ d("button", {
									type: "button",
									className: "btn-quiet min-h-11 px-3 text-sm",
									onClick: () => P([]),
									children: g("games.splendor.cancel")
								}),
								/* @__PURE__ */ d("button", {
									type: "button",
									disabled: N.length !== T,
									className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
									style: { background: S.accent },
									onClick: () => {
										m({
											type: "return",
											gems: N
										}), P([]);
									},
									children: g("games.splendor.returnConfirm")
								})
							]
						})
					]
				}),
				E.length > 0 && y && /* @__PURE__ */ f("div", {
					className: "sp-confirm card safe-b absolute inset-x-0 bottom-0 z-10 mb-1 flex min-h-12 items-center gap-2 px-3 py-1.5",
					children: [
						/* @__PURE__ */ f("span", {
							className: "flex min-w-0 flex-1 items-center gap-1",
							children: [E.map((e, t) => /* @__PURE__ */ d(q, {
								color: e,
								size: 22
							}, `${e}${t}`)), !ue(E, e.bank) && /* @__PURE__ */ d("span", {
								className: "ml-1 truncate text-xs font-bold text-warn-ink",
								children: g("games.splendor.takeIllegal")
							})]
						}),
						/* @__PURE__ */ d("button", {
							type: "button",
							className: "btn-quiet min-h-11 px-3 text-sm",
							onClick: () => D([]),
							children: g("games.splendor.cancel")
						}),
						/* @__PURE__ */ d("button", {
							type: "button",
							disabled: !ue(E, e.bank),
							className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
							style: { background: S.accent },
							onClick: () => {
								m({
									type: "take",
									gems: E
								}), D([]);
							},
							children: g("games.splendor.takeConfirm", { n: E.length })
						})
					]
				}),
				O && H && v && /* @__PURE__ */ f("div", {
					className: "sp-confirm card safe-b sp-card-confirm absolute inset-x-0 bottom-0 z-10 mb-1 flex min-h-12 items-center gap-2 px-3 py-1.5",
					children: [
						/* @__PURE__ */ d(U, {
							id: H.id,
							w: 34,
							h: 46
						}),
						/* @__PURE__ */ d("span", {
							className: "flex min-w-0 flex-1 flex-wrap items-center gap-0.5",
							children: W ? /* @__PURE__ */ f(u, { children: [
								h.filter((e) => (W.pay[e] ?? 0) > 0).map((e) => /* @__PURE__ */ d(q, {
									color: e,
									count: W.pay[e],
									size: 20
								}, e)),
								W.gold > 0 && /* @__PURE__ */ d(q, {
									color: "gold",
									count: W.gold,
									size: 20
								}),
								Object.keys(W.pay).length === 0 && W.gold === 0 && /* @__PURE__ */ d("span", {
									className: "text-sm font-extrabold text-emerald-600",
									children: g("games.splendor.free")
								})
							] }) : /* @__PURE__ */ d("span", {
								className: "truncate text-xs font-bold text-warn-ink",
								children: g("games.splendor.cantAfford")
							})
						}),
						/* @__PURE__ */ d("button", {
							type: "button",
							className: "btn-quiet min-h-11 px-3 text-sm",
							onClick: () => A(null),
							children: g("games.splendor.cancel")
						}),
						O.from === "market" && /* @__PURE__ */ d("button", {
							type: "button",
							disabled: !K,
							className: "btn-quiet min-h-11 px-3 text-sm disabled:opacity-40",
							onClick: () => {
								m({
									type: "reserve",
									cardId: O.cardId
								}), A(null);
							},
							children: g("games.splendor.reserve")
						}),
						/* @__PURE__ */ d("button", {
							type: "button",
							disabled: !W,
							className: "btn-base min-h-11 px-4 text-sm text-white disabled:opacity-40",
							style: { background: S.accent },
							onClick: () => {
								m({
									type: "buy",
									cardId: O.cardId,
									from: O.from
								}), A(null);
							},
							children: g("games.splendor.buy")
						})
					]
				}),
				j !== null && /* @__PURE__ */ f("div", {
					className: "sp-confirm card safe-b absolute inset-x-0 bottom-0 z-10 mb-1 flex min-h-12 items-center gap-2 px-3 py-1.5",
					children: [
						/* @__PURE__ */ d("span", {
							className: "min-w-0 flex-1 truncate text-sm font-extrabold",
							children: g("games.splendor.blindReserveDesc", { tier: j })
						}),
						/* @__PURE__ */ d("button", {
							type: "button",
							className: "btn-quiet min-h-11 px-3 text-sm",
							onClick: () => M(null),
							children: g("games.splendor.cancel")
						}),
						/* @__PURE__ */ d("button", {
							type: "button",
							className: "btn-base min-h-11 px-4 text-sm text-white",
							style: { background: S.accent },
							onClick: () => {
								m({
									type: "reserve",
									tier: j
								}), M(null);
							},
							children: g("games.splendor.reserve")
						})
					]
				}),
				fe && /* @__PURE__ */ f("div", {
					className: "sp-confirm card safe-b absolute inset-x-0 bottom-0 z-10 mb-1 flex min-h-12 items-center gap-2 px-3 py-1.5",
					children: [/* @__PURE__ */ d("span", {
						className: "min-w-0 flex-1 truncate text-sm font-extrabold",
						children: g("games.splendor.passPrompt")
					}), /* @__PURE__ */ d("button", {
						type: "button",
						className: "btn-base min-h-11 px-4 text-sm text-white",
						style: { background: S.accent },
						onClick: () => m({ type: "pass" }),
						children: g("games.splendor.pass")
					})]
				}),
				X && /* @__PURE__ */ f("div", {
					className: "sp-personal-tray safe-b pb-1",
					children: [/* @__PURE__ */ f("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ d("p", {
							className: "sp-personal-heading mb-1 text-[11px] font-bold text-ink/75",
							children: Z ? g("games.splendor.playerGems", { name: _(R) }) : g("games.splendor.myGems")
						}), /* @__PURE__ */ f("div", {
							className: "sp-gems-grid grid grid-cols-3 place-items-center gap-1",
							children: [h.map((e) => /* @__PURE__ */ d(ge, {
								color: e,
								bonus: X.bonuses[e],
								tokens: X.tokens[e],
								picked: !Z && x && N.includes(e),
								onPick: !Z && x && X.tokens[e] > 0 ? () => ae(e) : void 0
							}, e)), /* @__PURE__ */ d(ge, {
								color: "gold",
								tokens: X.tokens.gold
							})]
						})]
					}), /* @__PURE__ */ f("div", {
						className: "flex-none",
						children: [/* @__PURE__ */ d("p", {
							className: "sp-personal-heading mb-1 text-[11px] font-bold text-ink/75",
							children: g("games.splendor.reservedLabel")
						}), /* @__PURE__ */ d("div", {
							className: "sp-reserves flex items-center gap-1",
							children: Z ? [
								0,
								1,
								2
							].map((e) => e < X.reservedCount ? /* @__PURE__ */ d("span", {
								className: "sp-reserve-back",
								"aria-hidden": !0,
								children: "?"
							}, e) : /* @__PURE__ */ d("span", {
								className: "sp-reserve-slot",
								"aria-hidden": !0
							}, e)) : [
								0,
								1,
								2
							].map((e) => {
								let t = G[e];
								return t ? /* @__PURE__ */ d(ve, {
									id: t,
									index: e,
									active: O?.cardId === t,
									affordable: y && F(b(t).cost, X.bonuses, X.tokens) !== null,
									disabled: !y,
									onPick: () => re(t, "reserved")
								}, t) : /* @__PURE__ */ d(_e, { index: e }, e);
							})
						})]
					})]
				})
			]
		})
	});
}
function pe({ pub: e, choosingNoble: t, send: n }) {
	let i = a(), { ref: o } = r("nobles");
	return /* @__PURE__ */ d("div", {
		className: "sp-nobles",
		children: /* @__PURE__ */ f("div", {
			ref: o,
			className: "sp-noble-cards",
			children: [e.nobles.length === 0 && /* @__PURE__ */ d("span", {
				className: "text-xs font-bold text-sp-parchment",
				children: i("games.splendor.noblesGone")
			}), e.nobles.map((r) => t && (e.nobleChoices?.includes(r) ?? !1) ? /* @__PURE__ */ d("button", {
				type: "button",
				"aria-label": i("games.splendor.noblePickAria"),
				onClick: () => n({
					type: "chooseNoble",
					nobleId: r
				}),
				className: "sp-noble-button",
				"data-eligible": "true",
				children: /* @__PURE__ */ d(J, { id: r })
			}, r) : /* @__PURE__ */ d("span", {
				className: "flex-none",
				"aria-label": i("games.splendor.nobleAria"),
				role: "img",
				children: /* @__PURE__ */ d(J, { id: r })
			}, r))]
		})
	});
}
function J({ id: e }) {
	let { ref: t } = r(`noble:${e}`);
	return /* @__PURE__ */ d("span", {
		ref: t,
		className: "sp-noble inline-flex",
		children: /* @__PURE__ */ d(K, { id: e })
	});
}
function me({ tier: e, cards: t, deckCount: n, myTurn: i, canReserve: o, deckSelected: s, selectedCard: c, affordable: l, onPickCard: u, onPickDeck: p }) {
	let m = a(), { ref: h } = r(`mrow:${e}`);
	return /* @__PURE__ */ f("div", {
		className: "sp-market-row",
		children: [/* @__PURE__ */ d(X, {
			tier: e,
			count: n,
			selected: s,
			disabled: !i || !o,
			onPick: p
		}), /* @__PURE__ */ f("div", {
			ref: h,
			className: "sp-market-cards",
			children: [t.map((e) => /* @__PURE__ */ d(Y, {
				id: e,
				active: c === e,
				affordable: i && l(e),
				disabled: !i,
				onPick: () => u(e)
			}, e)), Array.from({ length: Math.max(0, 4 - t.length) }, (e, t) => /* @__PURE__ */ d("span", {
				className: "sp-empty-card",
				children: m("games.splendor.soldOut")
			}, `empty-${t}`))]
		})]
	});
}
function Y({ id: e, active: t, affordable: n, disabled: i, onPick: o }) {
	let s = a(), { ref: c } = r(`mcard:${e}`), l = b(e);
	return /* @__PURE__ */ d("button", {
		ref: c,
		type: "button",
		"aria-label": s("games.splendor.cardStatusAria", {
			card: s("games.splendor.cardAria", { tier: l.tier }),
			status: s(n ? "games.splendor.cardAffordable" : "games.splendor.cardInspect")
		}),
		"aria-pressed": t,
		disabled: i,
		onClick: o,
		className: "sp-market-card",
		"data-selected": t,
		"data-affordable": n && !t,
		children: /* @__PURE__ */ d(U, { id: e })
	});
}
function X({ tier: e, count: t, selected: n, disabled: i, onPick: o }) {
	let s = a(), { ref: c } = r(`deck:${e}`);
	return /* @__PURE__ */ d("div", {
		ref: c,
		className: "relative flex-none",
		children: t === 0 ? /* @__PURE__ */ d("span", {
			className: "sp-empty-deck",
			children: s("games.splendor.soldOut")
		}) : /* @__PURE__ */ f("button", {
			type: "button",
			"aria-label": s("games.splendor.deckAria", {
				tier: e,
				n: t
			}),
			disabled: i,
			onClick: o,
			className: "sp-deck-button",
			"data-selected": n,
			"aria-pressed": n,
			children: [/* @__PURE__ */ d(W, { tier: e }), /* @__PURE__ */ d("span", {
				className: "sp-deck-count",
				children: t
			})]
		})
	});
}
function he({ pub: e, takeSel: t, myTurn: n, onPick: r }) {
	let i = a();
	return /* @__PURE__ */ d("div", {
		className: "sp-bank-tray",
		children: k.map((a) => {
			let o = a === "gold", s = !o && de(a, t, e.bank), c = !o && t.includes(a);
			return /* @__PURE__ */ d(Z, {
				color: a,
				count: e.bank[a],
				label: i(o ? "games.splendor.goldReserveOnly" : "games.splendor.bankTokenAria", {
					gem: i(le[a]),
					n: e.bank[a]
				}),
				picked: c,
				unavailable: !o && n && !s,
				doubleReady: !o && e.bank[a] >= 4 && t.length === 1 && c,
				disabled: !n || !s,
				gold: o,
				onPick: () => !o && r(a)
			}, a);
		})
	});
}
function Z({ color: e, count: t, label: n, picked: i, unavailable: a, doubleReady: o, gold: s, disabled: c, onPick: l }) {
	let { ref: u } = r(`bank:${e}`);
	return /* @__PURE__ */ f("button", {
		ref: u,
		type: "button",
		"aria-label": n,
		"aria-pressed": s ? void 0 : i,
		disabled: c,
		onClick: l,
		className: "sp-bank-token",
		"data-picked": i,
		"data-unavailable": a || t === 0,
		children: [
			/* @__PURE__ */ d(q, {
				color: e,
				count: t
			}),
			o && /* @__PURE__ */ d("span", {
				className: "sp-bank-double",
				"aria-hidden": !0,
				children: "×2"
			}),
			s && /* @__PURE__ */ d("span", {
				className: "sp-bank-gold",
				"aria-hidden": !0,
				children: "🔒"
			})
		]
	});
}
function ge({ color: e, bonus: t, tokens: n, picked: r, onPick: i }) {
	let o = a(), s = V[e], c = /* @__PURE__ */ f("span", {
		className: `sp-gem-cell flex w-12 flex-none flex-col items-center rounded-lg border-2 py-0.5 font-mono leading-4 font-extrabold tabular-nums ${r ? "-translate-y-1 shadow-[2px_2px_0_var(--color-ink)]" : ""}`,
		style: {
			background: `linear-gradient(150deg, rgb(255 255 255 / 0.22), rgb(255 255 255 / 0) 45%), ${s.bg}`,
			color: s.fg,
			borderColor: r ? S.accent : "var(--color-ink)"
		},
		children: [/* @__PURE__ */ f("span", {
			className: "flex items-center gap-0.5 text-xs",
			children: [/* @__PURE__ */ d(oe, {
				fg: s.fg,
				bg: s.bg
			}), n]
		}), /* @__PURE__ */ f("span", {
			className: "flex items-center gap-0.5 text-xs",
			children: [/* @__PURE__ */ d(se, {
				fg: s.fg,
				bg: s.bg
			}), t ?? 0]
		})]
	});
	return i ? /* @__PURE__ */ d("span", {
		className: "sp-gem-return",
		children: /* @__PURE__ */ d("button", {
			type: "button",
			onClick: i,
			"aria-label": o("games.splendor.returnGemAria", {
				gem: o(le[e]),
				n
			}),
			"aria-pressed": r,
			className: "flex min-h-11 min-w-12 flex-none items-center justify-center transition-transform active:translate-y-0.5",
			children: c
		})
	}) : c;
}
function _e({ index: e }) {
	let { ref: t } = r(`rsv:${e}`);
	return /* @__PURE__ */ d("span", {
		ref: t,
		className: "sp-reserve-slot",
		"aria-hidden": !0
	});
}
function ve({ id: e, index: t, active: n, affordable: i, disabled: o, onPick: s }) {
	let c = a(), { ref: l } = r(`rsv:${t}`), u = b(e);
	return /* @__PURE__ */ d("button", {
		ref: l,
		type: "button",
		"aria-label": c("games.splendor.reservedCardAria", { tier: u.tier }),
		"aria-pressed": n,
		disabled: o,
		onClick: s,
		className: "sp-reserved-card",
		"data-selected": n,
		"data-affordable": i && !n,
		children: /* @__PURE__ */ d(U, {
			id: e,
			w: 54,
			h: 74
		})
	});
}
//#endregion
//#region src/games/splendor/bot.ts
function ye() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
function be(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var Q = (e) => k.reduce((t, n) => t + e[n], 0);
function xe(e, t) {
	let n = 0;
	for (let r of e) {
		let e = x(r).requires, i = h.reduce((t, n) => t + (e[n] ?? 0), 0);
		if (i === 0) continue;
		let a = h.reduce((n, r) => n + Math.min(t[r], e[r] ?? 0), 0);
		n = Math.max(n, a / i);
	}
	return n;
}
function Se(e) {
	let t = h.filter((t) => e[t] > 0), n = [], r = Math.min(3, t.length);
	if (r > 0) {
		let e = (i, a) => {
			if (a.length === r) {
				n.push(a);
				return;
			}
			for (let n = i; n < t.length; n += 1) e(n + 1, [...a, t[n]]);
		};
		e(0, []);
	}
	for (let t of h) e[t] >= 4 && n.push([t, t]);
	return n;
}
var Ce = {
	noblePlanW: 1,
	developmentW: .5,
	planning2pW: .5,
	pointsW: 5,
	raceW: .5,
	nobleW: 0,
	goldW: 0,
	hoardW: 0,
	returnW: 2,
	denyW: 0,
	denyEndW: 0,
	oppRespW: 0,
	oppDistW: 1,
	reserveBaseW: 0,
	blindW: 0,
	engineW: .25,
	gatherRate: 3.4,
	colorRate: .8,
	searchK: 6,
	rolloutS: 0,
	rolloutK: 3,
	rolloutW: 1,
	noiseW: 0
};
function we(e = Ce) {
	let t = (t, n, r) => {
		let i = {}, a = 0;
		for (let e of h) i[e] = Math.max(0, (t[e] ?? 0) - n[e] - r[e]), a += i[e];
		let o = r.gold;
		for (let e of [...h].sort((e, t) => i[t] - i[e])) {
			let t = Math.min(o, i[e]);
			i[e] -= t, o -= t, a -= t;
		}
		let s = 0;
		for (let t of h) s = Math.max(s, i[t] / e.colorRate);
		return Math.max(s, a / e.gatherRate);
	}, n = (n, r, i, a, o) => {
		let s = { ...i }, c = { ...a }, l = o, u = [...n], d = [...r], f = 0;
		for (let n = 0; n < 24 && l < 15; n += 1) {
			let n = null, r = 0, i = 0;
			for (let a of u) {
				let o = b(a), l = t(o.cost, c, s), u = d.some((e) => {
					let t = x(e).requires;
					return h.every((e) => c[e] + +(o.bonus === e) >= (t[e] ?? 0));
				}), f = (o.points + (u ? 3 : 0) + e.engineW) / (l + 1);
				f > i && (i = f, n = a, r = l);
			}
			if (!n) break;
			f += r + 1;
			let a = b(n);
			for (let e of h) {
				let t = Math.max(0, (a.cost[e] ?? 0) - c[e]), n = Math.min(s[e], t);
				s[e] -= n;
				let r = t - n, i = Math.min(s.gold, r);
				s.gold -= i;
			}
			c[a.bonus] += 1, l += a.points;
			let o = d.find((e) => h.every((t) => c[t] >= (x(e).requires[t] ?? 0)));
			o && (l += 3, d = d.filter((e) => e !== o)), u.splice(u.indexOf(n), 1);
		}
		return l >= 15 ? f : 99 + (15 - l);
	}, r = (t, n, r) => {
		let i = t.players[n], a = () => {
			let e = t.nobles.find((e) => h.every((t) => i.bonuses[t] >= (x(e).requires[t] ?? 0)));
			e && (t.nobles = t.nobles.filter((t) => t !== e), i.points += 3);
		}, o = () => {
			let r = Q(i.tokens) - 10;
			if (r > 0) {
				let a = [...t.market, ...n === t.myRid ? t.myReserved : []];
				for (let n of d(a, t.nobles, i, r, Object.keys(t.players).length === 2 ? e.planning2pW : 1)) --i.tokens[n], t.bank[n] += 1;
			}
		};
		if (r.type === "take") {
			for (let e of r.gems) i.tokens[e] += 1, --t.bank[e];
			o(), a();
			return;
		}
		if (r.type === "reserve") {
			"cardId" in r && (t.market = t.market.filter((e) => e !== r.cardId), n === t.myRid && t.myReserved.push(r.cardId)), t.bank.gold > 0 && (--t.bank.gold, i.tokens.gold += 1, o()), a();
			return;
		}
		if (r.type === "buy") {
			let e = b(r.cardId), n = F(e.cost, i.bonuses, i.tokens);
			if (!n) return;
			for (let e of h) {
				let r = n.pay[e] ?? 0;
				i.tokens[e] -= r, t.bank[e] += r;
			}
			i.tokens.gold -= n.gold, t.bank.gold += n.gold, r.from === "market" ? t.market = t.market.filter((e) => e !== r.cardId) : t.myReserved = t.myReserved.filter((e) => e !== r.cardId), i.bonuses[e.bonus] += 1, i.points += e.points, a();
		}
	}, i = (e, t, n, r, i, a) => {
		let o = [];
		for (let t of e) F(b(t).cost, r, n) && o.push({
			type: "buy",
			cardId: t,
			from: "market"
		});
		for (let e of i) F(b(e).cost, r, n) && o.push({
			type: "buy",
			cardId: e,
			from: "reserved"
		});
		for (let e of Se(t)) o.push({
			type: "take",
			gems: e
		});
		if (!a) for (let t of e) o.push({
			type: "reserve",
			cardId: t
		});
		return o;
	}, a = (e, t, n) => {
		let r = e.players[t];
		if (n.type === "take") {
			for (let t of n.gems) r.tokens[t] += 1, --e.bank[t];
			for (; Q(r.tokens) > 10;) {
				let t = null, n = Infinity;
				for (let i of h) {
					if (r.tokens[i] <= 0) continue;
					let a = 0;
					for (let t of [
						1,
						2,
						3
					]) for (let n of e.market[t]) a += Math.max(0, (b(n).cost[i] ?? 0) - r.bonuses[i]);
					a < n && (n = a, t = i);
				}
				if (!t) break;
				--r.tokens[t], e.bank[t] += 1;
			}
			return;
		}
		if (n.type === "reserve") {
			if ("cardId" in n) {
				let r = [
					1,
					2,
					3
				].find((t) => e.market[t].includes(n.cardId));
				if (!r) return;
				e.market[r] = e.market[r].filter((e) => e !== n.cardId);
				let i = e.decks[r].pop();
				i && e.market[r].push(i), t === e.myRid && e.myReserved.push(n.cardId);
			} else {
				let t = e.decks[n.tier].pop();
				t && e.myReserved.push(t);
			}
			e.bank.gold > 0 && (--e.bank.gold, r.tokens.gold += 1);
			return;
		}
		if (n.type === "buy") {
			let t = b(n.cardId), i = F(t.cost, r.bonuses, r.tokens);
			if (!i) return;
			for (let t of h) {
				let n = i.pay[t] ?? 0;
				r.tokens[t] -= n, e.bank[t] += n;
			}
			if (r.tokens.gold -= i.gold, e.bank.gold += i.gold, n.from === "market") {
				let t = [
					1,
					2,
					3
				].find((t) => e.market[t].includes(n.cardId));
				if (!t) return;
				e.market[t] = e.market[t].filter((e) => e !== n.cardId);
				let r = e.decks[t].pop();
				r && e.market[t].push(r);
			} else e.myReserved = e.myReserved.filter((e) => e !== n.cardId);
			r.bonuses[t.bonus] += 1, r.points += t.points;
			let a = e.nobles.find((e) => h.every((t) => r.bonuses[t] >= (x(e).requires[t] ?? 0)));
			a && (e.nobles = e.nobles.filter((e) => e !== a), r.points += 3);
		}
	}, o = (n, r) => {
		let i = n.players[r], a = [
			...n.market[1],
			...n.market[2],
			...n.market[3]
		], o = r === n.myRid ? [...a, ...n.myReserved] : a, s = null;
		for (let e of o) {
			let t = b(e);
			if (!F(t.cost, i.bonuses, i.tokens)) continue;
			let r = n.nobles.some((e) => h.every((n) => i.bonuses[n] + +(t.bonus === n) >= (x(e).requires[n] ?? 0))), o = t.points * 3 + (r ? 3 : 0) + t.tier * .2;
			(!s || o > s.v) && (s = {
				id: e,
				from: n.myReserved.includes(e) && !a.includes(e) ? "reserved" : "market",
				v: o
			});
		}
		if (s) return {
			type: "buy",
			cardId: s.id,
			from: s.from
		};
		let c = null, l = 0;
		for (let n of o) {
			let r = b(n), a = (r.points + e.engineW) / (t(r.cost, i.bonuses, i.tokens) + 1);
			a > l && (l = a, c = n);
		}
		if (c) {
			let e = b(c), t = h.filter((t) => (e.cost[t] ?? 0) > i.bonuses[t] + i.tokens[t] && n.bank[t] > 0);
			if (t.length === 1 && n.bank[t[0]] >= 4) return {
				type: "take",
				gems: [t[0], t[0]]
			};
			let r = t.slice(0, 3);
			if (r.length > 0) {
				for (let e of h) {
					if (r.length >= 3) break;
					!r.includes(e) && n.bank[e] > 0 && r.push(e);
				}
				let e = h.filter((e) => n.bank[e] > 0).length;
				return {
					type: "take",
					gems: r.slice(0, Math.min(3, e))
				};
			}
		}
		return { type: "pass" };
	}, s = (e) => {
		let t = 0;
		for (; !(t++ > 400);) {
			let t = e.order[e.turnIdx];
			a(e, t, o(e, t)), !e.lastRound && e.players[t].points >= 15 && (e.lastRound = !0);
			let n = (e.turnIdx + 1) % e.order.length;
			if (e.lastRound && n === 0) break;
			e.turnIdx = n;
		}
		let n = -Infinity;
		for (let t of e.order) t !== e.myRid && (n = Math.max(n, e.players[t].points));
		return e.players[e.myRid].points - n;
	}, c = (t, n, r) => {
		let i = b(t), a = r.some((e) => h.every((t) => n[t] + +(i.bonus === t) >= (x(e).requires[t] ?? 0)));
		return i.points + (a ? 3 : 0) + e.engineW;
	}, l = (e, n, r, i) => e.map((e) => ({
		id: e,
		eff: c(e, i, n) / (t(b(e).cost, i, r) + 1)
	})).sort((e, t) => t.eff - e.eff).slice(0, 3).map((e) => e.id), u = (t, n, r, i, a) => {
		let o = e.pointsW * t.points + e.goldW * t.tokens.gold - e.hoardW * Math.max(0, Q(t.tokens) - 10) + e.nobleW * 3 * xe(i, t.bonuses);
		if (e.noblePlanW > 0) {
			let n = i.map((e) => 3 * .65 ** h.reduce((n, r) => n + Math.max(0, (x(e).requires[r] ?? 0) - t.bonuses[r]), 0)).sort((e, t) => t - e);
			o += a * e.noblePlanW * e.pointsW * ((n[0] ?? 0) + (n[1] ?? 0) * .5);
		}
		if (e.developmentW > 0) {
			let n = 0;
			for (let e of g) {
				let r = h.reduce((n, r) => n + Math.max(0, (e.cost[r] ?? 0) - t.bonuses[r]), 0);
				n += (e.points + .4) / (r + 2);
			}
			o += a * e.developmentW * n;
		}
		for (let n of h) {
			if (t.bonuses[n] <= 0) continue;
			let i = 0;
			for (let e of r) (b(e).cost[n] ?? 0) > t.bonuses[n] && (i += 1);
			o += e.engineW * t.bonuses[n] * Math.min(i, 4);
		}
		let s = n.map((e) => {
			let n = b(e), r = 0, i = 0, a = {};
			for (let e of h) {
				let o = n.cost[e] ?? 0;
				r += o;
				let s = Math.min(t.bonuses[e], o);
				i += s, a[e] = Math.min(t.tokens[e], o - s);
			}
			return {
				id: e,
				total: r,
				bonusCov: i,
				tokenCov: a
			};
		}), l = {};
		for (let e of h) {
			let n = s.reduce((t, n) => t + n.tokenCov[e], 0);
			l[e] = n > t.tokens[e] && n > 0 ? t.tokens[e] / n : 1;
		}
		let u = s.map((e) => {
			let t = e.bonusCov;
			for (let n of h) t += e.tokenCov[n] * l[n];
			return {
				...e,
				deficit: e.total - e.bonusCov - h.reduce((t, n) => t + e.tokenCov[n], 0),
				cov: t
			};
		}), d = u.reduce((e, n) => e + Math.min(t.tokens.gold, n.deficit), 0), f = d > t.tokens.gold && d > 0 ? t.tokens.gold / d : 1;
		for (let e of u) e.total > 0 && (o += c(e.id, t.bonuses, i) * ((e.cov + Math.min(t.tokens.gold, e.deficit) * f) / e.total));
		return o;
	}, d = (e, t, n, r, i) => {
		let a = l(e, t, n.tokens, n.bonuses), o = -Infinity, s = [], c = (r, l, d, f) => {
			if (l === 0) {
				let r = u({
					...n,
					tokens: d
				}, a, e, t, i);
				r > o && (o = r, s = [...f]);
				return;
			}
			if (r === h.length) return;
			let p = h[r];
			for (let e = 0; e <= Math.min(l, n.tokens[p]); e += 1) d[p] = n.tokens[p] - e, c(r + 1, l - e, d, [...f, ...Array.from({ length: e }, () => p)]);
			d[p] = n.tokens[p];
		};
		return c(0, r, { ...n.tokens }, []), s;
	};
	return (t, o) => {
		let c = t.public, f = c.players.find((e) => e.rid === o.rid);
		if (!f) return null;
		let p = c.players.length === 2 ? e.planning2pW : 1;
		if (c.phase === "return") {
			if (c.turn !== o.rid) return null;
			let e = Q(f.tokens) - 10;
			if (e <= 0) return null;
			if (o.difficulty === "weak") {
				let t = h.flatMap((e) => Array.from({ length: f.tokens[e] }, () => e)), n = [];
				for (let r = 0; r < e && t.length > 0; r += 1) n.push(t.splice(crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % t.length, 1)[0]);
				return { action: {
					type: "return",
					gems: n
				} };
			}
			let n = [...c.market.flatMap((e) => e.cards), ...t.private?.reserved ?? []];
			return { action: {
				type: "return",
				gems: d(n, c.nobles, f, e, p)
			} };
		}
		if (c.phase === "chooseNoble") return c.turn !== o.rid || !c.nobleChoices?.length ? null : { action: {
			type: "chooseNoble",
			nobleId: be(c.nobleChoices)
		} };
		if (c.phase !== "play" || c.turn !== o.rid) return null;
		let m = c.market.flatMap((e) => e.cards), _ = t.private?.reserved ?? [], v = c.players.filter((e) => e.rid !== o.rid);
		if (o.difficulty === "weak") {
			let e = i(m, c.bank, f.tokens, f.bonuses, _, _.length >= 3);
			if (_.length < 3) {
				let t = c.market.filter((e) => e.deckCount > 0).map((e) => e.tier);
				for (let n of t) e.push({
					type: "reserve",
					tier: n
				});
			}
			return e.length > 0 ? { action: be(e) } : { action: { type: "pass" } };
		}
		let y = c.lastRound ? 1 : Infinity, x = (t, n, i, a) => {
			let o = t.players[n], s = o.points;
			if (y <= 1) return r(t, n, a), e.pointsW * (o.points - s);
			let c = () => [...t.market, ...n === t.myRid ? t.myReserved : []], l = u(o, i, c(), t.nobles, p), d = Q(o.tokens), f = a.type === "take" && d + a.gems.length > 10 || a.type === "reserve" && t.bank.gold > 0 && d + 1 > 10;
			r(t, n, a);
			let m = a.type === "buy" ? i.filter((e) => e !== a.cardId) : i, h = u(o, m, c(), t.nobles, p) - l;
			if (f && (h -= e.returnW), a.type === "reserve" && (h += e.reserveBaseW, "tier" in a && (h += e.blindW * a.tier)), a.type === "buy" && a.from === "market" || a.type === "reserve" && "cardId" in a) {
				let r = a.cardId;
				for (let i of Object.keys(t.players)) {
					if (i === n) continue;
					let a = t.players[i];
					if (F(b(r).cost, a.bonuses, a.tokens)) {
						h += e.denyW * (.5 + b(r).points), a.points + b(r).points >= 15 && (h += e.denyEndW * (.5 + b(r).points));
						break;
					}
				}
			}
			return h;
		}, S = () => ({
			market: [...m],
			bank: { ...c.bank },
			nobles: [...c.nobles],
			players: Object.fromEntries(c.players.map((e) => [e.rid, {
				tokens: { ...e.tokens },
				bonuses: { ...e.bonuses },
				points: e.points
			}])),
			myReserved: [..._],
			myRid: o.rid
		}), C = i(m, c.bank, f.tokens, f.bonuses, _, _.length >= 3);
		if (_.length < 3) for (let e of c.market) e.deckCount > 0 && C.push({
			type: "reserve",
			tier: e.tier
		});
		let w = [...m, ..._], T = y <= 1 ? [] : l(w, c.nobles, f.tokens, f.bonuses), E = 0;
		if (y > 1 && e.raceW > 0) {
			let e = n(w, c.nobles, f.tokens, f.bonuses, f.points), t = Infinity;
			for (let e of v) t = Math.min(t, n(m, c.nobles, e.tokens, e.bonuses, e.points));
			E = Math.max(-1, Math.min(1, (e - t) / 10));
		}
		let D = [];
		for (let t of C) {
			let n = x(S(), o.rid, T, t);
			E !== 0 && t.type === "buy" && (n += e.raceW * E * e.pointsW * b(t.cardId).points), n += e.noiseW > 0 ? (ye() - .5) * e.noiseW : 0, D.push({
				action: t,
				score: n
			});
		}
		if (D.length === 0) return { action: { type: "pass" } };
		if (D.sort((e, t) => t.score - e.score), e.searchK > 0 && e.oppRespW > 0) {
			let t = c.players.findIndex((e) => e.rid === o.rid), n = c.players.length;
			for (let a of D.slice(0, e.searchK)) {
				let s = S();
				r(s, o.rid, a.action);
				let u = 0, d = 0;
				for (let r of v) {
					let a = s.players[r.rid], o = y <= 1 ? [] : l(s.market, s.nobles, a.tokens, a.bonuses), f = i(s.market, s.bank, a.tokens, a.bonuses, [], r.reservedCount >= 3), p = 0;
					for (let e of f) {
						let t = x({
							market: [...s.market],
							bank: { ...s.bank },
							nobles: [...s.nobles],
							players: structuredClone(s.players),
							myReserved: [],
							myRid: r.rid
						}, r.rid, o, e);
						t > p && (p = t);
					}
					let m = (c.players.findIndex((e) => e.rid === r.rid) - t + n) % n, h = e.oppDistW ** (m - 1);
					u += h * p, d += h;
				}
				a.score -= e.oppRespW * (d > 0 ? u / d : 0);
			}
			D.sort((e, t) => t.score - e.score);
		}
		if (e.rolloutS > 0) {
			let t = o.memory?.bought ?? [], n = c.players.map((e) => e.rid);
			for (let r of D.slice(0, Math.min(e.rolloutK, D.length))) {
				let i = 0;
				for (let l = 0; l < e.rolloutS; l += 1) {
					let e = {};
					for (let n of [
						1,
						2,
						3
					]) {
						let r = new Set(c.market.find((e) => e.tier === n)?.cards ?? []), i = g.filter((e) => e.tier === n && !r.has(e.id) && !_.includes(e.id) && !t.includes(e.id)).map((e) => e.id);
						for (let e = i.length - 1; e > 0; --e) {
							let t = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % (e + 1);
							[i[e], i[t]] = [i[t], i[e]];
						}
						let a = c.market.find((e) => e.tier === n)?.deckCount ?? 0;
						e[n] = i.slice(0, Math.min(a, i.length));
					}
					let l = {
						market: Object.fromEntries(c.market.map((e) => [e.tier, [...e.cards]])),
						decks: e,
						bank: { ...c.bank },
						order: n,
						myRid: o.rid,
						players: Object.fromEntries(c.players.map((e) => [e.rid, {
							tokens: { ...e.tokens },
							bonuses: { ...e.bonuses },
							points: e.points
						}])),
						myReserved: [..._],
						nobles: [...c.nobles],
						turnIdx: (n.indexOf(o.rid) + 1) % n.length,
						lastRound: c.lastRound
					};
					a(l, o.rid, r.action), !l.lastRound && l.players[o.rid].points >= 15 && (l.lastRound = !0), l.lastRound && l.turnIdx === 0 ? i += l.players[o.rid].points - Math.max(...v.map((e) => l.players[e.rid].points)) : i += s(l);
				}
				r.score += e.rolloutW * (i / e.rolloutS);
			}
			D.sort((e, t) => t.score - e.score);
		}
		let O = D[0].action;
		return e.rolloutS > 0 && O.type === "buy" ? {
			action: O,
			memory: { bought: [...o.memory?.bought ?? [], O.cardId] }
		} : { action: O };
	};
}
var Te = we(), Ee = {
	white: "games.splendor.gem.white",
	blue: "games.splendor.gem.blue",
	green: "games.splendor.gem.green",
	red: "games.splendor.gem.red",
	black: "games.splendor.gem.black"
};
function De(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of e) n.set(t, (n.get(t) ?? 0) + 1);
	return [...n].map(([e, n]) => n > 1 ? t("games.splendor.hintGemCount", {
		gem: t(Ee[e]),
		n
	}) : t(Ee[e])).join(" ");
}
var Oe = (e, t, n) => {
	switch (e.type) {
		case "take": return n("games.splendor.hintTake", { gems: De(e.gems, n) });
		case "buy": {
			let t = b(e.cardId);
			return n("games.splendor.hintBuy", {
				tier: t.tier,
				gem: n(Ee[t.bonus]),
				points: t.points
			});
		}
		case "reserve": return "tier" in e ? n("games.splendor.blindReserveDesc", { tier: e.tier }) : n("games.splendor.hintReserve", { tier: b(e.cardId).tier });
		case "return": return n("games.splendor.hintReturn", { gems: De(e.gems, n) });
		case "chooseNoble": return n("games.splendor.hintNoble");
		case "pass": return n("games.splendor.pass");
	}
}, ke = {
	white: "白",
	blue: "蓝",
	green: "绿",
	red: "红",
	black: "黑",
	gold: "金"
}, Ae = (e) => k.filter((t) => e[t] > 0).map((t) => `${t}(${ke[t]})×${e[t]}`).join(" ") || "(无)", je = (e) => h.filter((t) => (e[t] ?? 0) > 0).map((t) => `${t}(${ke[t]})×${e[t]}`).join(" ") || "免费", Me = (e) => {
	let t = b(e);
	return `${e}[${t.tier}级 ${t.points}分 产${ke[t.bonus]} 费用 ${je(t.cost)}]`;
}, Ne = {
	needsAction: (e, t) => e.public.phase !== "done" && e.public.turn === t.rid,
	describeView(e, t) {
		let n = e.public, r = n.players.find((e) => e.rid === t.rid), i = [`目标:先到 15 分${n.lastRound ? "(已有人达标,这是最后一轮)" : ""}。颜色一律用英文枚举值输出。`];
		i.push("市场明卡:");
		for (let e of n.market) i.push(`  ${e.tier} 级(牌堆剩 ${e.deckCount}): ${e.cards.map(Me).join(" ")}`);
		i.push(`银行宝石: ${Ae(n.bank)}`), i.push(`场上贵族(达成条件得 3 分): ${n.nobles.map((e) => `${e}[需要折扣 ${je(x(e).requires)}]`).join(" ")}`), i.push("各玩家:");
		for (let e of n.players) {
			let n = e.rid === t.rid ? "你" : e.rid;
			i.push(`  ${n}: ${e.points} 分,折扣 ${je(e.bonuses)},token ${Ae(e.tokens)},已购 ${e.cardCount} 张,保留 ${e.reservedCount} 张`);
		}
		if (n.phase === "return") {
			let e = r ? k.reduce((e, t) => e + r.tokens[t], 0) : 0;
			i.push(`你的 token 超过 10 枚上限,必须退还 ${e - 10} 枚。输出 return 行动。`);
		} else if (n.phase === "chooseNoble") i.push(`你同时满足多个贵族,选一个: ${(n.nobleChoices ?? []).join(", ")}。输出 chooseNoble 行动。`);
		else {
			let t = e.private?.reserved ?? [];
			t.length && i.push(`你的保留卡(可 buy,from 用 "reserved"): ${t.map(Me).join(" ")}`), i.push("轮到你行动:take(拿宝石:1-3 个异色,或同色 2 个——银行该色需 ≥4)/buy(买市场或保留卡,黄金自动补差)/reserve(留一张市场卡或盲留某级牌堆顶,得 1 金)/pass(仅当无事可做)。");
		}
		return i.join("\n");
	},
	actionJsonSchema: { oneOf: [
		{
			type: "object",
			properties: {
				type: { const: "take" },
				gems: {
					type: "array",
					items: { enum: [
						"white",
						"blue",
						"green",
						"red",
						"black"
					] },
					minItems: 1,
					maxItems: 3
				}
			},
			required: ["type", "gems"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "buy" },
				cardId: { type: "string" },
				from: { enum: ["market", "reserved"] }
			},
			required: [
				"type",
				"cardId",
				"from"
			],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "reserve" },
				cardId: {
					type: "string",
					description: "市场明卡 id"
				}
			},
			required: ["type", "cardId"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "reserve" },
				tier: {
					type: "integer",
					enum: [
						1,
						2,
						3
					],
					description: "盲留牌堆顶"
				}
			},
			required: ["type", "tier"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "return" },
				gems: {
					type: "array",
					items: { enum: [
						"white",
						"blue",
						"green",
						"red",
						"black"
					] },
					minItems: 1
				}
			},
			required: ["type", "gems"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "chooseNoble" },
				nobleId: { type: "string" }
			},
			required: ["type", "nobleId"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: { type: { const: "pass" } },
			required: ["type"],
			additionalProperties: !1
		}
	] },
	parseAction(e, t, n) {
		let r = w.safeParse(e);
		if (!r.success) return null;
		let i = r.data, a = t.public;
		if (a.turn !== n.rid || a.phase === "done") return null;
		let o = a.players.find((e) => e.rid === n.rid);
		if (!o) return null;
		switch (i.type) {
			case "take": {
				if (a.phase !== "play") return null;
				let e = new Set(i.gems);
				if (e.size === 1) {
					if (i.gems.length !== 2 || a.bank[i.gems[0]] < 4) return null;
				} else if (e.size !== i.gems.length) return null;
				return i.gems.every((e) => a.bank[e] > 0) ? i : null;
			}
			case "buy": return a.phase !== "play" || !(i.from === "market" ? a.market.flatMap((e) => e.cards) : t.private?.reserved ?? []).includes(i.cardId) ? null : F(b(i.cardId).cost, o.bonuses, o.tokens) ? i : null;
			case "reserve": {
				if (a.phase !== "play" || o.reservedCount >= 3) return null;
				if ("cardId" in i) return a.market.some((e) => e.cards.includes(i.cardId)) ? i : null;
				let e = a.market.find((e) => e.tier === i.tier);
				return e && e.deckCount > 0 ? i : null;
			}
			case "return": {
				if (a.phase !== "return") return null;
				let e = k.reduce((e, t) => e + o.tokens[t], 0);
				if (i.gems.length !== e - 10) return null;
				let t = /* @__PURE__ */ new Map();
				for (let e of i.gems) t.set(e, (t.get(e) ?? 0) + 1);
				return [...t].every(([e, t]) => o.tokens[e] >= t) ? i : null;
			}
			case "chooseNoble": return a.phase !== "chooseNoble" || !a.nobleChoices?.includes(i.nobleId) ? null : _.some((e) => e.id === i.nobleId) ? i : null;
			case "pass": return a.phase === "play" ? i : null;
		}
	}
};
//#endregion
//#region src/games/splendor/fx.tsx
function $(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function Pe(e, t, n) {
	let r = e.anchor(`mrow:${t}`);
	if (!r) return null;
	let i = r.h * 68 / 92, a = (r.w - 4 * i) / 3;
	return {
		x: r.x + n * (i + a),
		y: r.y,
		w: i,
		h: r.h
	};
}
function Fe(e, t, n) {
	let r = e.anchor("nobles");
	if (!r) return null;
	let i = r.h / 42, a = 64 * i, o = 4 * i, s = a + o, c = n * a + (n - 1) * o, l = r.w;
	return {
		x: r.x + (l - c) / 2 + t * s,
		y: r.y,
		w: a,
		h: r.h
	};
}
function Ie(e) {
	return Array.isArray(e) ? e.filter((e) => typeof e == "string") : [];
}
//#endregion
//#region .bgparty/cache/pack-entry/splendor/entry.tsx
var Le = {
	definition: ne,
	View: ce,
	bot: Te,
	describe: Oe,
	llm: Ne,
	fx: {
		take(e, t) {
			let n = Ie(e.data?.gems), r = $(t, e.rid);
			if (!n.length || !r) return null;
			let i = n.map((e, n) => {
				let i = t.anchor(`bank:${e}`);
				return i ? /* @__PURE__ */ d(m, {
					from: i,
					to: r,
					ms: 340,
					delay: n * 70,
					children: /* @__PURE__ */ d("span", {
						className: "inline-flex",
						children: /* @__PURE__ */ d(q, {
							color: e,
							size: i.w
						})
					})
				}, `${e}${n}`) : null;
			}).filter(Boolean);
			return i.length ? {
				ms: 340 + n.length * 70,
				node: i
			} : null;
		},
		return(e, t) {
			let n = Ie(e.data?.gems), r = $(t, e.rid);
			if (!n.length || !r) return null;
			let i = n.map((e, n) => {
				let i = t.anchor(`bank:${e}`);
				return i ? /* @__PURE__ */ d(m, {
					from: r,
					to: i,
					ms: 320,
					delay: n * 60,
					children: /* @__PURE__ */ d("span", {
						className: "inline-flex",
						children: /* @__PURE__ */ d(q, {
							color: e,
							size: i.w
						})
					})
				}, `${e}${n}`) : null;
			}).filter(Boolean);
			return i.length ? {
				ms: 320 + n.length * 60,
				node: i
			} : null;
		},
		buy(e, t) {
			let n = e.data;
			if (typeof n?.cardId != "string") return null;
			let r = $(t, e.rid);
			if (!r) return null;
			let i = null;
			n.from === "market" && typeof n.tier == "number" && typeof n.slot == "number" ? i = Pe(t, n.tier, n.slot) : n.from === "reserved" && typeof n.slot == "number" && (i = t.anchor(`rsv:${n.slot}`) ?? null);
			let a = i?.w ?? 68, o = i?.h ?? 92;
			return i ??= r, {
				ms: 900,
				node: [/* @__PURE__ */ d(m, {
					from: i,
					to: r,
					ms: 420,
					children: /* @__PURE__ */ d("span", {
						className: "inline-flex",
						children: /* @__PURE__ */ d(U, {
							id: n.cardId,
							w: a,
							h: o
						})
					})
				}, "card")]
			};
		},
		reserve(e, t) {
			let n = e.data, r = $(t, e.rid);
			if (!n || !r) return null;
			let i = e.secret, a = null, o = null;
			return n.blind === !0 && typeof n.tier == "number" ? (a = t.anchor(`deck:${n.tier}`), o = typeof i?.cardId == "string" ? /* @__PURE__ */ d("span", {
				className: "inline-flex",
				children: /* @__PURE__ */ d(U, {
					id: i.cardId,
					w: a?.h ? a.h * 68 / 92 : 68,
					h: a?.h ?? 92
				})
			}) : /* @__PURE__ */ d("span", {
				className: "inline-flex",
				children: /* @__PURE__ */ d(W, {
					tier: n.tier ?? 1,
					w: a?.w,
					h: a?.h
				})
			})) : typeof n.cardId == "string" && typeof n.tier == "number" && typeof n.slot == "number" && (a = Pe(t, n.tier, n.slot), o = /* @__PURE__ */ d("span", {
				className: "inline-flex",
				children: /* @__PURE__ */ d(U, {
					id: n.cardId,
					w: a?.w,
					h: a?.h
				})
			})), !a || !o ? null : {
				ms: 500,
				node: /* @__PURE__ */ d(m, {
					from: a,
					to: r,
					ms: 380,
					children: o
				})
			};
		},
		noble(e, t) {
			let n = e.data, r = $(t, e.rid);
			if (typeof n?.nobleId != "string" || !r) return null;
			let i = typeof n.slot == "number" && typeof n.rowLen == "number" ? Fe(t, n.slot, n.rowLen) : t.anchor("nobles");
			return i ? {
				ms: 1e3,
				node: [/* @__PURE__ */ d(m, {
					from: i,
					to: r,
					ms: 480,
					children: /* @__PURE__ */ d("span", {
						className: "inline-flex",
						children: /* @__PURE__ */ d(K, {
							id: n.nobleId,
							w: i.w,
							h: i.h
						})
					})
				}, "noble"), /* @__PURE__ */ d(p, {
					at: r,
					ms: 900,
					delay: 420,
					children: "+3"
				}, "pts")]
			} : null;
		}
	},
	locales: {
		zh: {
			name: "璀璨宝石",
			desc: "拿宝石、买发展卡、吸引贵族,先冲 15 分",
			rules: "目标：有玩家达到15分时，触发最后一轮。所有玩家完成相同数量的回合后，总分最高的玩家获胜。\n流程(每回合四选一):\n· 拿取3枚不同颜色的宝石。银行中不足3种颜色时，每种剩余颜色各拿取1枚。\n· 拿取两枚同色宝石：只有银行中该颜色的宝石至少剩余四枚时，才能选择此行动。\n· 保留 1 张发展卡，并拿取 1 枚黄金：可以保留市场中公开的卡牌，也可以不查看牌面，直接保留牌堆顶的卡牌。最多同时保留 3 张发展卡。\n· 购买 1 张发展卡(市场上的或自己保留的),黄金可抵任意颜色。\n规则:\n· 已购卡上的宝石是永久折扣。\n· 手里宝石总数(含黄金)不能超过 10 枚,超出的部分须在本回合退还。\n· 回合结束时若满足贵族的折扣要求,贵族自动来访,值 3 分;同时满足多位则自己挑一位。\n· 总分相同时，拥有发展卡较少的玩家获胜；仍然相同时，共同获胜。",
			turnYou: "轮到你:拿宝石 / 买卡 / 保留",
			turnWait: "等 {{name}} 行动…",
			returnPrompt: "宝石超过 10 枚,点选退还 {{n}} 枚",
			returnWait: "等 {{name}} 退还超出的宝石…",
			noblePrompt: "多位贵族来访,挑一位",
			nobleWait: "等 {{name}} 挑选贵族…",
			noblesLabel: "贵族廊",
			noblesGone: "贵族已全部到访",
			bankLabel: "宝石银行",
			bankGuide: "异色 3 枚 / 同色 2 枚需 ≥4；黄金靠保留",
			myGems: "我的宝石",
			playerGems: "{{name}}的宝石",
			cardAffordable: "可购买",
			cardInspect: "查看费用或保留",
			cardStatusAria: "{{card}}，{{status}}",
			goldReserveOnly: "黄金，余 {{n}}；只能通过保留卡取得",
			bankTokenAria: "{{gem}}，余 {{n}}",
			returnGemAria: "退还 {{gem}}，持有 {{n}} 枚",
			soldOut: "售罄",
			lastRound: "最后一轮",
			takeIllegal: "拿满 3 异色(银行不足有几种拿几种),或 2 同色(银行 ≥4)",
			takeConfirm: "拿 {{n}} 枚",
			cancel: "取消",
			free: "免费",
			cantAfford: "宝石不够",
			reserve: "保留",
			buy: "购买",
			blindReserveDesc: "盲留 {{tier}} 级牌堆顶一张",
			returnConfirm: "退还",
			pass: "跳过",
			passPrompt: "无处可拿也买不起,跳过本回合",
			reservedLabel: "保留",
			stripTokens: "💎{{n}}",
			stripCards: "🃏{{n}}",
			stripReserved: "📥{{n}}",
			stripNobles: "👑{{n}}",
			noblePickAria: "选择这位贵族",
			nobleAria: "贵族",
			cardAria: "{{tier}} 级发展卡",
			reservedCardAria: "保留的 {{tier}} 级发展卡",
			deckAria: "{{tier}} 级牌堆,剩 {{n}} 张",
			gem: {
				white: "钻石",
				blue: "蓝宝石",
				green: "绿宝石",
				red: "红宝石",
				black: "玛瑙",
				gold: "黄金"
			},
			errNotYourTurn: "还没轮到你",
			errBadTake: "拿法不对:异色拿满银行可给的色数,或 2 同色且银行 ≥4",
			errCantAfford: "宝石不够,买不起",
			errReserveFull: "最多保留 3 张",
			errBadCard: "这张卡不在那里了",
			errBadReturn: "退还的数量或种类不对",
			errBadNoble: "不能选这位贵族",
			errBadPass: "还有能做的动作,不能跳过",
			hintTake: "拿 {{gems}}",
			hintGemCount: "{{gem}}×{{n}}",
			hintBuy: "买下 {{tier}} 级发展卡({{gem}},{{points}} 分)",
			hintReserve: "保留 {{tier}} 级发展卡",
			hintReturn: "退还 {{gems}}",
			hintNoble: "迎请这位贵族(+3 分)"
		},
		en: {
			name: "Splendor",
			desc: "Collect gems, buy cards, charm nobles — race to 15",
			rules: "Goal: reaching 15 points triggers the final round; after everyone has taken an equal number of turns, the highest score wins.\nEach turn, choose one of four:\n· Take 3 gems of different colors; if the bank has fewer than 3 colors, take what is left.\n· Take 2 gems of the same color; only if that stack holds 4 or more.\n· Reserve 1 development card and take 1 gold. Choose a face-up market card or reserve the top card of a deck without looking at it. You may have at most 3 reserved cards.\n· Buy 1 development card (from the market or your reserve); gold counts as any color.\nRules:\n· Gems on bought cards are permanent discounts.\n· You may hold at most 10 gems in total (gold included); excess must be returned the same turn.\n· At the end of your turn, any noble whose gem requirements you meet visits you for 3 points; if several qualify, pick one.\n· Ties go to fewer cards bought; a further tie shares the victory.",
			turnYou: "Your turn: take gems / buy / reserve",
			turnWait: "Waiting for {{name}}…",
			returnPrompt: "Over 10 gems — tap {{n}} to return",
			returnWait: "Waiting for {{name}} to return gems…",
			noblePrompt: "Several nobles visit — pick one",
			nobleWait: "Waiting for {{name}} to pick a noble…",
			noblesLabel: "Noble gallery",
			noblesGone: "All nobles have visited",
			bankLabel: "Gem bank",
			bankGuide: "3 colors / 2 same if ≥4 · Gold via reserve",
			myGems: "My gems",
			playerGems: "{{name}}'s gems",
			cardAffordable: "Ready to buy",
			cardInspect: "Inspect cost or reserve",
			cardStatusAria: "{{card}}, {{status}}",
			goldReserveOnly: "Gold, {{n}} left; only gained by reserving",
			bankTokenAria: "{{gem}}, {{n}} left",
			returnGemAria: "Return {{gem}}, holding {{n}}",
			soldOut: "Sold out",
			lastRound: "Final round",
			takeIllegal: "Take 3 distinct (fewer if the bank runs low), or 2 of one color (bank ≥4)",
			takeConfirm: "Take {{n}}",
			cancel: "Cancel",
			free: "Free",
			cantAfford: "Not enough gems",
			reserve: "Reserve",
			buy: "Buy",
			blindReserveDesc: "Blind-reserve the top of tier {{tier}}",
			returnConfirm: "Return",
			pass: "Pass",
			passPrompt: "Nothing to take or buy — pass your turn",
			reservedLabel: "Reserved",
			stripTokens: "💎{{n}}",
			stripCards: "🃏{{n}}",
			stripReserved: "📥{{n}}",
			stripNobles: "👑{{n}}",
			noblePickAria: "Choose this noble",
			nobleAria: "Noble",
			cardAria: "Tier {{tier}} development card",
			reservedCardAria: "Reserved tier {{tier}} card",
			deckAria: "Tier {{tier}} deck, {{n}} left",
			gem: {
				white: "Diamond",
				blue: "Sapphire",
				green: "Emerald",
				red: "Ruby",
				black: "Onyx",
				gold: "Gold"
			},
			errNotYourTurn: "Not your turn yet",
			errBadTake: "Invalid take: distinct colors as many as the bank offers, or 2 of one color with bank ≥4",
			errCantAfford: "Not enough gems to buy that",
			errReserveFull: "You can reserve at most 3 cards",
			errBadCard: "That card is no longer there",
			errBadReturn: "Wrong gems or count to return",
			errBadNoble: "You cannot pick that noble",
			errBadPass: "You still have legal moves",
			hintTake: "Take {{gems}}",
			hintGemCount: "{{gem}}×{{n}}",
			hintBuy: "Buy the tier {{tier}} card ({{gem}}, {{points}} pts)",
			hintReserve: "Reserve the tier {{tier}} card",
			hintReturn: "Return {{gems}}",
			hintNoble: "Welcome this noble (+3 pts)"
		}
	}
};
//#endregion
export { Le as default };
