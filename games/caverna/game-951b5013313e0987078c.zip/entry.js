import { z as e } from "zod";
import { randomIntAt as t } from "@bgparty/sdk/engine/prng";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as l } from "@bgparty/sdk/player-colors";
import { Texture as u } from "@bgparty/sdk/texture";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as f } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as p, seatName as m } from "@bgparty/sdk/ui/player-strip";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
import { IconBack as ee, IconBot as v, IconExpand as te, IconLog as y } from "@bgparty/sdk/icons";
import { Confetti as b } from "@bgparty/sdk/ui/confetti";
//#region src/games/caverna/data.ts
var x = [
	"wood",
	"stone",
	"ore",
	"ruby",
	"gold",
	"food",
	"grain",
	"veg"
], S = [
	"sheep",
	"donkey",
	"boar",
	"cattle"
], C = ["dog", ...S], ne = {
	sheep: 1,
	boar: 2,
	cattle: 3,
	grain: 1,
	veg: 2,
	ruby: 2
}, re = (e) => Math.floor(e / 2) * 3 + e % 2, ie = (e) => e + 1, w = {
	driftMining: {
		acc: { add: { stone: 1 } },
		nameKey: "games.caverna.spaces.driftMining",
		descKey: "games.caverna.spaceDesc.driftMining"
	},
	excavation: {
		acc: { add: { stone: 1 } },
		nameKey: "games.caverna.spaces.excavation",
		descKey: "games.caverna.spaceDesc.excavation"
	},
	startingPlayer: {
		acc: { add: { food: 1 } },
		nameKey: "games.caverna.spaces.startingPlayer",
		descKey: "games.caverna.spaceDesc.startingPlayer"
	},
	logging: {
		acc: {
			ifEmpty: { wood: 3 },
			else: { wood: 1 }
		},
		nameKey: "games.caverna.spaces.logging",
		descKey: "games.caverna.spaceDesc.logging"
	},
	supplies: {
		nameKey: "games.caverna.spaces.supplies",
		descKey: "games.caverna.spaceDesc.supplies"
	},
	oreMining: {
		acc: {
			ifEmpty: { ore: 2 },
			else: { ore: 1 }
		},
		nameKey: "games.caverna.spaces.oreMining",
		descKey: "games.caverna.spaceDesc.oreMining"
	},
	woodGathering: {
		acc: { add: { wood: 1 } },
		nameKey: "games.caverna.spaces.woodGathering",
		descKey: "games.caverna.spaceDesc.woodGathering"
	},
	clearing: {
		acc: { add: { wood: 1 } },
		nameKey: "games.caverna.spaces.clearing",
		descKey: "games.caverna.spaceDesc.clearing"
	},
	sustenance: {
		acc: { add: { food: 1 } },
		nameKey: "games.caverna.spaces.sustenance",
		descKey: "games.caverna.spaceDesc.sustenance"
	},
	growth: {
		nameKey: "games.caverna.spaces.growth",
		descKey: "games.caverna.spaceDesc.growth"
	},
	forestExploration: {
		acc: {
			ifEmpty: { wood: 2 },
			else: { wood: 1 }
		},
		nameKey: "games.caverna.spaces.forestExploration",
		descKey: "games.caverna.spaceDesc.forestExploration"
	},
	imitation: {
		imitationCost: 2,
		nameKey: "games.caverna.spaces.imitation",
		descKey: "games.caverna.spaceDesc.imitation"
	},
	rubyMining: {
		acc: { add: { ruby: 1 } },
		nameKey: "games.caverna.spaces.rubyMining",
		descKey: "games.caverna.spaceDesc.rubyMining"
	},
	housework: {
		nameKey: "games.caverna.spaces.housework",
		descKey: "games.caverna.spaceDesc.housework"
	},
	slashAndBurn: {
		nameKey: "games.caverna.spaces.slashAndBurn",
		descKey: "games.caverna.spaceDesc.slashAndBurn"
	},
	stripMining: {
		acc: {
			ifEmpty: { ore: 1 },
			else: { stone: 1 }
		},
		nameKey: "games.caverna.spaces.stripMining",
		descKey: "games.caverna.spaceDesc.stripMining"
	},
	imitation3: {
		imitationCost: 4,
		nameKey: "games.caverna.spaces.imitation3",
		descKey: "games.caverna.spaceDesc.imitation3"
	},
	forestExploration3: {
		acc: { add: { wood: 1 } },
		nameKey: "games.caverna.spaces.forestExploration3",
		descKey: "games.caverna.spaceDesc.forestExploration3"
	},
	depot: {
		acc: { add: {
			wood: 1,
			ore: 1
		} },
		nameKey: "games.caverna.spaces.depot",
		descKey: "games.caverna.spaceDesc.depot"
	},
	weeklyMarket: {
		nameKey: "games.caverna.spaces.weeklyMarket",
		descKey: "games.caverna.spaceDesc.weeklyMarket"
	},
	hardwareRental: {
		nameKey: "games.caverna.spaces.hardwareRental",
		descKey: "games.caverna.spaceDesc.hardwareRental"
	},
	imitation5a: {
		imitationCost: 2,
		nameKey: "games.caverna.spaces.imitation5a",
		descKey: "games.caverna.spaceDesc.imitation5a"
	},
	imitation5b: {
		imitationCost: 4,
		nameKey: "games.caverna.spaces.imitation5b",
		descKey: "games.caverna.spaceDesc.imitation5b"
	},
	smallDriftMining: {
		nameKey: "games.caverna.spaces.smallDriftMining",
		descKey: "games.caverna.spaceDesc.smallDriftMining"
	},
	driftMining2: {
		acc: { add: { stone: 1 } },
		nameKey: "games.caverna.spaces.driftMining2",
		descKey: "games.caverna.spaceDesc.driftMining2"
	},
	fenceBuilding: {
		acc: { add: { wood: 1 } },
		nameKey: "games.caverna.spaces.fenceBuilding",
		descKey: "games.caverna.spaceDesc.fenceBuilding"
	},
	imitation6a: {
		imitationCost: 1,
		nameKey: "games.caverna.spaces.imitation6a",
		descKey: "games.caverna.spaceDesc.imitation6a"
	},
	imitation6b: {
		imitationCost: 2,
		nameKey: "games.caverna.spaces.imitation6b",
		descKey: "games.caverna.spaceDesc.imitation6b"
	},
	largeDepot: {
		acc: { add: {
			wood: 1,
			stone: 1,
			ore: 1
		} },
		nameKey: "games.caverna.spaces.largeDepot",
		descKey: "games.caverna.spaceDesc.largeDepot"
	},
	extension: {
		nameKey: "games.caverna.spaces.extension",
		descKey: "games.caverna.spaceDesc.extension"
	},
	imitation7a: {
		imitationCost: 0,
		nameKey: "games.caverna.spaces.imitation7a",
		descKey: "games.caverna.spaceDesc.imitation7a"
	},
	imitation7b: {
		imitationCost: 1,
		nameKey: "games.caverna.spaces.imitation7b",
		descKey: "games.caverna.spaceDesc.imitation7b"
	},
	imitation7c: {
		imitationCost: 2,
		nameKey: "games.caverna.spaces.imitation7c",
		descKey: "games.caverna.spaceDesc.imitation7c"
	},
	blacksmithing: {
		nameKey: "games.caverna.spaces.blacksmithing",
		descKey: "games.caverna.spaceDesc.blacksmithing"
	},
	sheepFarming: {
		acc: { add: { sheep: 1 } },
		nameKey: "games.caverna.spaces.sheepFarming",
		descKey: "games.caverna.spaceDesc.sheepFarming"
	},
	oreMineConstruction: {
		nameKey: "games.caverna.spaces.oreMineConstruction",
		descKey: "games.caverna.spaceDesc.oreMineConstruction"
	},
	wishForChildren: {
		nameKey: "games.caverna.spaces.wishForChildren",
		descKey: "games.caverna.spaceDesc.wishForChildren"
	},
	donkeyFarming: {
		acc: { add: { donkey: 1 } },
		nameKey: "games.caverna.spaces.donkeyFarming",
		descKey: "games.caverna.spaceDesc.donkeyFarming"
	},
	rubyMineConstruction: {
		nameKey: "games.caverna.spaces.rubyMineConstruction",
		descKey: "games.caverna.spaceDesc.rubyMineConstruction"
	},
	familyLife: {
		nameKey: "games.caverna.spaces.familyLife",
		descKey: "games.caverna.spaceDesc.familyLife"
	},
	exploration: {
		nameKey: "games.caverna.spaces.exploration",
		descKey: "games.caverna.spaceDesc.exploration"
	},
	oreDelivery: {
		acc: { add: {
			ore: 1,
			stone: 1
		} },
		nameKey: "games.caverna.spaces.oreDelivery",
		descKey: "games.caverna.spaceDesc.oreDelivery"
	},
	adventure: {
		nameKey: "games.caverna.spaces.adventure",
		descKey: "games.caverna.spaceDesc.adventure"
	},
	oreTrading: {
		nameKey: "games.caverna.spaces.oreTrading",
		descKey: "games.caverna.spaceDesc.oreTrading"
	},
	rubyDelivery: {
		acc: {
			ifEmpty: { ruby: 2 },
			else: { ruby: 1 }
		},
		nameKey: "games.caverna.spaces.rubyDelivery",
		descKey: "games.caverna.spaceDesc.rubyDelivery"
	}
};
function T(e) {
	let t = e <= 3 ? [
		"driftMining",
		"excavation",
		"startingPlayer",
		"logging",
		"supplies",
		"oreMining",
		"woodGathering",
		"clearing",
		"sustenance"
	] : [
		"driftMining",
		"excavation",
		"startingPlayer",
		"logging",
		"growth",
		"oreMining",
		"woodGathering",
		"clearing",
		"sustenance",
		"forestExploration",
		"imitation"
	], n = [
		"rubyMining",
		"housework",
		"slashAndBurn"
	], r = [];
	e === 3 && r.push("stripMining", "imitation3", "forestExploration3"), e === 5 && r.push("depot", "weeklyMarket", "hardwareRental", "imitation5a", "imitation5b", "smallDriftMining", "fenceBuilding"), e >= 6 && r.push("depot", "weeklyMarket", "hardwareRental", "imitation6a", "imitation6b", "driftMining2", "fenceBuilding"), e === 7 && r.push("largeDepot", "extension", "imitation7a", "imitation7b", "imitation7c");
	let i = [
		...t,
		...n,
		...r
	];
	return e === 1 ? i.filter((e) => e !== "supplies" && e !== "clearing") : i;
}
function ae(e, t) {
	if (t >= 4) {
		if (e === "excavation") return {
			ifEmpty: { stone: 2 },
			else: { stone: 1 }
		};
		if (e === "logging") return { add: { wood: 3 } };
		if (e === "oreMining") return {
			ifEmpty: { ore: 3 },
			else: { ore: 2 }
		};
		if (e === "clearing") return { add: { wood: 2 } };
		if (e === "sustenance") return {
			ifEmpty: { grain: 1 },
			else: { veg: 1 }
		};
		if (e === "driftMining" || e === "driftMining2") return { add: { stone: 2 } };
	}
	return t >= 6 && e === "fenceBuilding" ? {
		ifEmpty: { wood: 2 },
		else: { wood: 1 }
	} : w[e].acc;
}
var oe = [
	"blacksmithing",
	"sheepFarming",
	"oreMineConstruction"
], E = ["donkeyFarming", "rubyMineConstruction"], se = [
	"familyLife",
	"exploration",
	"oreDelivery"
], ce = [
	"adventure",
	"oreTrading",
	"rubyDelivery"
];
function le(e) {
	let t = [
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9,
		10,
		11,
		12
	];
	return e <= 2 ? t.filter((e) => e !== 9) : t;
}
var ue = [
	"blacksmithing",
	"sheepFarming",
	"oreMineConstruction",
	"wishForChildren",
	"donkeyFarming",
	"rubyMineConstruction",
	"oreDelivery",
	"familyLife",
	"oreTrading",
	"adventure",
	"rubyDelivery"
], de = [
	{
		id: "weaponsUp",
		min: 1
	},
	{
		id: "dog",
		min: 1
	},
	{
		id: "wood",
		min: 1
	},
	{
		id: "sheep",
		min: 2
	},
	{
		id: "grain",
		min: 2
	},
	{
		id: "donkey",
		min: 3
	},
	{
		id: "stone",
		min: 3
	},
	{
		id: "veg",
		min: 4
	},
	{
		id: "ore2",
		min: 4
	},
	{
		id: "boar",
		min: 5
	},
	{
		id: "gold2",
		min: 6
	},
	{
		id: "furnish",
		min: 7
	},
	{
		id: "stable",
		min: 8
	},
	{
		id: "tunnel",
		min: 9
	},
	{
		id: "smallPasture1w",
		min: 9
	},
	{
		id: "cattle",
		min: 10
	},
	{
		id: "largePasture2w",
		min: 10
	},
	{
		id: "meadow",
		min: 11
	},
	{
		id: "dwelling2w2s",
		min: 11
	},
	{
		id: "field",
		min: 12
	},
	{
		id: "sow",
		min: 12
	},
	{
		id: "cavern",
		min: 14
	},
	{
		id: "breed2",
		min: 14
	}
], fe = {
	weaponsUp: "games.caverna.loot.weaponsUp",
	dog: "games.caverna.loot.dog",
	wood: "games.caverna.loot.wood",
	sheep: "games.caverna.loot.sheep",
	grain: "games.caverna.loot.grain",
	donkey: "games.caverna.loot.donkey",
	stone: "games.caverna.loot.stone",
	veg: "games.caverna.loot.veg",
	ore2: "games.caverna.loot.ore2",
	boar: "games.caverna.loot.boar",
	gold2: "games.caverna.loot.gold2",
	furnish: "games.caverna.loot.furnish",
	stable: "games.caverna.loot.stable",
	tunnel: "games.caverna.loot.tunnel",
	smallPasture1w: "games.caverna.loot.smallPasture1w",
	cattle: "games.caverna.loot.cattle",
	largePasture2w: "games.caverna.loot.largePasture2w",
	meadow: "games.caverna.loot.meadow",
	dwelling2w2s: "games.caverna.loot.dwelling2w2s",
	field: "games.caverna.loot.field",
	sow: "games.caverna.loot.sow",
	cavern: "games.caverna.loot.cavern",
	breed2: "games.caverna.loot.breed2"
}, D = (e, t) => t * 3 + e, O = D(0, 3), pe = D(0, 2), k = {
	[D(1, 3)]: { food: 1 },
	[D(2, 0)]: { food: 2 }
}, me = {
	[D(2, 0)]: { boar: 1 },
	[D(0, 2)]: { boar: 1 },
	[D(1, 3)]: { food: 1 }
}, he = D(2, 3);
function ge(e, t) {
	return t === 1 ? 2 : e === 0 || e === 1 ? 1 : e === 2 ? 2 : 3;
}
var A = {
	unusedCell: -1,
	missingAnimal: -2,
	begging: -3,
	smallPasture: 2,
	largePasture: 4,
	oreMine: 3,
	rubyMine: 4
}, _e = {
	wood: 1,
	stone: 1,
	ore: 1,
	sheep: 1,
	donkey: 1,
	grain: 1,
	boar: 2,
	dog: 2,
	veg: 2,
	cattle: 3
}, j = {
	dwelling: {
		nameKey: "games.caverna.furnishings.dwelling",
		descKey: "games.caverna.furnishingDesc.dwelling",
		cost: {
			wood: 4,
			stone: 3
		},
		vp: 3,
		cat: "dwelling",
		room: 1,
		unlimited: !0
	},
	simpleDwelling1: {
		nameKey: "games.caverna.furnishings.simpleDwelling1",
		descKey: "games.caverna.furnishingDesc.simpleDwelling1",
		cost: {
			wood: 4,
			stone: 2
		},
		vp: 0,
		cat: "dwelling",
		room: 1
	},
	simpleDwelling2: {
		nameKey: "games.caverna.furnishings.simpleDwelling2",
		descKey: "games.caverna.furnishingDesc.simpleDwelling2",
		cost: {
			wood: 3,
			stone: 3
		},
		vp: 0,
		cat: "dwelling",
		room: 1
	},
	mixedDwelling: {
		nameKey: "games.caverna.furnishings.mixedDwelling",
		descKey: "games.caverna.furnishingDesc.mixedDwelling",
		cost: {
			wood: 5,
			stone: 4
		},
		vp: 4,
		cat: "dwelling",
		room: 1
	},
	coupleDwelling: {
		nameKey: "games.caverna.furnishings.coupleDwelling",
		descKey: "games.caverna.furnishingDesc.coupleDwelling",
		cost: {
			wood: 8,
			stone: 6
		},
		vp: 5,
		cat: "dwelling",
		room: 2
	},
	additionalDwelling: {
		nameKey: "games.caverna.furnishings.additionalDwelling",
		descKey: "games.caverna.furnishingDesc.additionalDwelling",
		cost: {
			wood: 4,
			stone: 3
		},
		vp: 5,
		cat: "dwelling",
		room: 1
	},
	cuddleRoom: {
		nameKey: "games.caverna.furnishings.cuddleRoom",
		descKey: "games.caverna.furnishingDesc.cuddleRoom",
		cost: { wood: 1 },
		vp: 2,
		cat: "special"
	},
	breakfastRoom: {
		nameKey: "games.caverna.furnishings.breakfastRoom",
		descKey: "games.caverna.furnishingDesc.breakfastRoom",
		cost: { wood: 1 },
		vp: 0,
		cat: "special"
	},
	stubbleRoom: {
		nameKey: "games.caverna.furnishings.stubbleRoom",
		descKey: "games.caverna.furnishingDesc.stubbleRoom",
		cost: {
			wood: 1,
			ore: 1
		},
		vp: 1,
		cat: "special"
	},
	workRoom: {
		nameKey: "games.caverna.furnishings.workRoom",
		descKey: "games.caverna.furnishingDesc.workRoom",
		cost: { stone: 1 },
		vp: 2,
		cat: "special"
	},
	guestRoom: {
		nameKey: "games.caverna.furnishings.guestRoom",
		descKey: "games.caverna.furnishingDesc.guestRoom",
		cost: {
			wood: 1,
			stone: 1
		},
		vp: 0,
		cat: "special"
	},
	officeRoom: {
		nameKey: "games.caverna.furnishings.officeRoom",
		descKey: "games.caverna.furnishingDesc.officeRoom",
		cost: { stone: 1 },
		vp: 0,
		cat: "special"
	},
	carpenter: {
		nameKey: "games.caverna.furnishings.carpenter",
		descKey: "games.caverna.furnishingDesc.carpenter",
		cost: { stone: 1 },
		vp: 0,
		cat: "craft"
	},
	stoneCarver: {
		nameKey: "games.caverna.furnishings.stoneCarver",
		descKey: "games.caverna.furnishingDesc.stoneCarver",
		cost: { wood: 1 },
		vp: 1,
		cat: "craft"
	},
	blacksmith: {
		nameKey: "games.caverna.furnishings.blacksmith",
		descKey: "games.caverna.furnishingDesc.blacksmith",
		cost: {
			wood: 1,
			stone: 2
		},
		vp: 3,
		cat: "craft"
	},
	miner: {
		nameKey: "games.caverna.furnishings.miner",
		descKey: "games.caverna.furnishingDesc.miner",
		cost: {
			wood: 1,
			stone: 1
		},
		vp: 3,
		cat: "craft"
	},
	builder: {
		nameKey: "games.caverna.furnishings.builder",
		descKey: "games.caverna.furnishingDesc.builder",
		cost: { stone: 1 },
		vp: 2,
		cat: "craft"
	},
	trader: {
		nameKey: "games.caverna.furnishings.trader",
		descKey: "games.caverna.furnishingDesc.trader",
		cost: { wood: 1 },
		vp: 2,
		cat: "craft"
	},
	woodSupplier: {
		nameKey: "games.caverna.furnishings.woodSupplier",
		descKey: "games.caverna.furnishingDesc.woodSupplier",
		cost: { stone: 1 },
		vp: 2,
		cat: "craft"
	},
	stoneSupplier: {
		nameKey: "games.caverna.furnishings.stoneSupplier",
		descKey: "games.caverna.furnishingDesc.stoneSupplier",
		cost: { wood: 1 },
		vp: 1,
		cat: "craft"
	},
	rubySupplier: {
		nameKey: "games.caverna.furnishings.rubySupplier",
		descKey: "games.caverna.furnishingDesc.rubySupplier",
		cost: {
			wood: 2,
			stone: 2
		},
		vp: 2,
		cat: "craft"
	},
	dogSchool: {
		nameKey: "games.caverna.furnishings.dogSchool",
		descKey: "games.caverna.furnishingDesc.dogSchool",
		cost: {},
		vp: 0,
		cat: "craft"
	},
	quarry: {
		nameKey: "games.caverna.furnishings.quarry",
		descKey: "games.caverna.furnishingDesc.quarry",
		cost: { wood: 1 },
		vp: 2,
		cat: "craft"
	},
	seam: {
		nameKey: "games.caverna.furnishings.seam",
		descKey: "games.caverna.furnishingDesc.seam",
		cost: { wood: 2 },
		vp: 1,
		cat: "craft"
	},
	slaughteringCave: {
		nameKey: "games.caverna.furnishings.slaughteringCave",
		descKey: "games.caverna.furnishingDesc.slaughteringCave",
		cost: {
			wood: 2,
			stone: 2
		},
		vp: 2,
		cat: "food"
	},
	cookingCave: {
		nameKey: "games.caverna.furnishings.cookingCave",
		descKey: "games.caverna.furnishingDesc.cookingCave",
		cost: { stone: 2 },
		vp: 2,
		cat: "food"
	},
	workingCave: {
		nameKey: "games.caverna.furnishings.workingCave",
		descKey: "games.caverna.furnishingDesc.workingCave",
		cost: {
			wood: 1,
			stone: 1
		},
		vp: 2,
		cat: "food"
	},
	miningCave: {
		nameKey: "games.caverna.furnishings.miningCave",
		descKey: "games.caverna.furnishingDesc.miningCave",
		cost: {
			wood: 3,
			stone: 2
		},
		vp: 2,
		cat: "food"
	},
	breedingCave: {
		nameKey: "games.caverna.furnishings.breedingCave",
		descKey: "games.caverna.furnishingDesc.breedingCave",
		cost: {
			grain: 1,
			stone: 1
		},
		vp: 2,
		cat: "food"
	},
	peacefulCave: {
		nameKey: "games.caverna.furnishings.peacefulCave",
		descKey: "games.caverna.furnishingDesc.peacefulCave",
		cost: {
			wood: 2,
			stone: 2
		},
		vp: 2,
		cat: "food"
	},
	weavingParlor: {
		nameKey: "games.caverna.furnishings.weavingParlor",
		descKey: "games.caverna.furnishingDesc.weavingParlor",
		cost: {
			wood: 2,
			stone: 1
		},
		vp: 0,
		cat: "parlor"
	},
	milkingParlor: {
		nameKey: "games.caverna.furnishings.milkingParlor",
		descKey: "games.caverna.furnishingDesc.milkingParlor",
		cost: {
			wood: 2,
			stone: 2
		},
		vp: 0,
		cat: "parlor"
	},
	stateParlor: {
		nameKey: "games.caverna.furnishings.stateParlor",
		descKey: "games.caverna.furnishingDesc.stateParlor",
		cost: {
			gold: 5,
			stone: 3
		},
		vp: 0,
		cat: "parlor"
	},
	huntingParlor: {
		nameKey: "games.caverna.furnishings.huntingParlor",
		descKey: "games.caverna.furnishingDesc.huntingParlor",
		cost: { wood: 2 },
		vp: 1,
		cat: "parlor"
	},
	beerParlor: {
		nameKey: "games.caverna.furnishings.beerParlor",
		descKey: "games.caverna.furnishingDesc.beerParlor",
		cost: { wood: 2 },
		vp: 3,
		cat: "parlor"
	},
	blacksmithingParlor: {
		nameKey: "games.caverna.furnishings.blacksmithingParlor",
		descKey: "games.caverna.furnishingDesc.blacksmithingParlor",
		cost: { ore: 3 },
		vp: 2,
		cat: "parlor"
	},
	stoneStorage: {
		nameKey: "games.caverna.furnishings.stoneStorage",
		descKey: "games.caverna.furnishingDesc.stoneStorage",
		cost: {
			wood: 3,
			ore: 1
		},
		vp: 0,
		cat: "storage"
	},
	oreStorage: {
		nameKey: "games.caverna.furnishings.oreStorage",
		descKey: "games.caverna.furnishingDesc.oreStorage",
		cost: {
			wood: 1,
			stone: 2
		},
		vp: 0,
		cat: "storage"
	},
	sparePartStorage: {
		nameKey: "games.caverna.furnishings.sparePartStorage",
		descKey: "games.caverna.furnishingDesc.sparePartStorage",
		cost: { wood: 2 },
		vp: 0,
		cat: "storage"
	},
	mainStorage: {
		nameKey: "games.caverna.furnishings.mainStorage",
		descKey: "games.caverna.furnishingDesc.mainStorage",
		cost: {
			wood: 2,
			stone: 1
		},
		vp: 0,
		cat: "storage"
	},
	weaponStorage: {
		nameKey: "games.caverna.furnishings.weaponStorage",
		descKey: "games.caverna.furnishingDesc.weaponStorage",
		cost: {
			wood: 3,
			stone: 2
		},
		vp: 0,
		cat: "storage"
	},
	suppliesStorage: {
		nameKey: "games.caverna.furnishings.suppliesStorage",
		descKey: "games.caverna.furnishingDesc.suppliesStorage",
		cost: {
			food: 3,
			wood: 1
		},
		vp: 0,
		cat: "storage"
	},
	broomChamber: {
		nameKey: "games.caverna.furnishings.broomChamber",
		descKey: "games.caverna.furnishingDesc.broomChamber",
		cost: { wood: 1 },
		vp: 0,
		cat: "storage"
	},
	treasureChamber: {
		nameKey: "games.caverna.furnishings.treasureChamber",
		descKey: "games.caverna.furnishingDesc.treasureChamber",
		cost: {
			wood: 1,
			stone: 1
		},
		vp: 0,
		cat: "storage"
	},
	foodChamber: {
		nameKey: "games.caverna.furnishings.foodChamber",
		descKey: "games.caverna.furnishingDesc.foodChamber",
		cost: {
			wood: 2,
			veg: 2
		},
		vp: 0,
		cat: "storage"
	},
	prayerChamber: {
		nameKey: "games.caverna.furnishings.prayerChamber",
		descKey: "games.caverna.furnishingDesc.prayerChamber",
		cost: { wood: 2 },
		vp: 0,
		cat: "storage"
	},
	writingChamber: {
		nameKey: "games.caverna.furnishings.writingChamber",
		descKey: "games.caverna.furnishingDesc.writingChamber",
		cost: { stone: 2 },
		vp: 0,
		cat: "storage"
	},
	fodderChamber: {
		nameKey: "games.caverna.furnishings.fodderChamber",
		descKey: "games.caverna.furnishingDesc.fodderChamber",
		cost: {
			grain: 2,
			stone: 1
		},
		vp: 0,
		cat: "storage"
	}
}, ve = Object.keys(j), ye = ["parlor", "storage"], M = {
	woodSupplier: {
		rounds: 7,
		good: "wood"
	},
	stoneSupplier: {
		rounds: 5,
		good: "stone"
	},
	rubySupplier: {
		rounds: 4,
		good: "ruby"
	}
}, N = (e, t) => {
	let n = Array.from({ length: 12 }, () => ({ t: "rock" }));
	return n[e] = { t: "cavern" }, n[t] = {
		t: "cavern",
		furnishing: "entryDwelling"
	}, {
		forest: Array.from({ length: 12 }, () => ({ t: "forest" })),
		mountain: n,
		stables: 0,
		nextPastureId: 1,
		hasLandscape: !1
	};
};
function P(e) {
	let t = Math.floor(e / 3), n = e % 3, r = [];
	return t > 0 && r.push(e - 3), t < 3 && r.push(e + 3), n > 0 && r.push(e - 1), n < 2 && r.push(e + 1), r;
}
var be = (e, t) => P(e).includes(t), xe = (e) => e.t !== "rock";
function Se(e, t) {
	return t < 0 || t >= 12 || e.mountain[t].t !== "rock" ? !1 : P(t).some((t) => xe(e.mountain[t]));
}
function Ce(e, t, n, r) {
	return r ? Se(e, t) : be(t, n) && Se(e, t) && Se(e, n);
}
function we(e, t, n) {
	let r = e.forest[t];
	return !(!r || r.t !== "forest" || n === "field" && r.stable);
}
function Te(e, t) {
	return e.hasLandscape ? t.some((t) => P(t).some((t) => [
		"meadow",
		"field",
		"pasture"
	].includes(e.forest[t].t))) : t.includes(he);
}
function F(e, t, n, r) {
	if (r) {
		let r = t >= 0 ? t : n;
		return we(e, r, t >= 0 ? "meadow" : "field") && Te(e, [r]);
	}
	return be(t, n) && we(e, t, "meadow") && we(e, n, "field") && Te(e, [t, n]);
}
function Ee(e) {
	let t = /* @__PURE__ */ new Map();
	return e.forest.forEach((e, n) => {
		if (e.t !== "pasture" || e.pastureId === void 0) return;
		let r = t.get(e.pastureId) ?? {
			cells: [],
			stables: 0
		};
		r.cells.push(n), e.stable && r.stables++, t.set(e.pastureId, r);
	}), t;
}
function De(e, t, n, r) {
	if (t === "f") {
		let t = e.forest[n], i = t.dogs ?? 0;
		if (t.t === "pasture") {
			if (i > 0) return {
				kinds: ["sheep"],
				cap: i + 1
			};
			let n = Ee(e).get(t.pastureId);
			return {
				kinds: [...S],
				cap: 2 * 2 ** (n?.stables ?? 0)
			};
		}
		return t.t === "meadow" ? i > 0 ? {
			kinds: ["sheep"],
			cap: i + 1
		} : t.stable ? {
			kinds: [...S],
			cap: 1
		} : {
			kinds: [],
			cap: 0
		} : t.t === "forest" ? t.stable ? {
			kinds: ["boar"],
			cap: 1
		} : {
			kinds: [],
			cap: 0
		} : t.t === "field" && !t.crop && r.hasStubbleRoom ? {
			kinds: [...S],
			cap: 1
		} : {
			kinds: [],
			cap: 0
		};
	}
	let i = e.mountain[n];
	return i.t === "oreMine" || i.t === "rubyMine" ? {
		kinds: ["donkey"],
		cap: 1
	} : i.furnishing === "entryDwelling" || i.furnishing === "mixedDwelling" ? {
		kinds: [...S],
		cap: 2
	} : i.furnishing === "cuddleRoom" ? {
		kinds: ["sheep"],
		cap: r.dwarfCount
	} : i.furnishing === "breakfastRoom" ? {
		kinds: ["cattle"],
		cap: 3
	} : {
		kinds: [],
		cap: 0
	};
}
function Oe(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let r of ["f", "m"]) {
		let i = r === "f" ? e.forest : e.mountain;
		for (let a = 0; a < i.length; a++) {
			let o = i[a].animals;
			if ((r === "f" ? e.forest[a].dogs ?? 0 : 0) > 0 && r === "f" && !["meadow", "pasture"].includes(e.forest[a].t)) return !0;
			if (!o) continue;
			let { kinds: s, cap: c } = De(e, r, a, t);
			if (!s.includes(o.kind) || o.n > c) return !0;
			if (r === "f" && e.forest[a].t === "pasture") {
				let t = e.forest[a].pastureId, r = n.get(t);
				if (r && r !== o.kind) return !0;
				n.set(t, o.kind);
			}
		}
	}
	return !1;
}
function ke(e, t, n) {
	if (t === "dog") return !0;
	let r = /* @__PURE__ */ new Map();
	for (let t = 0; t < 12; t++) {
		let n = e.forest[t];
		n.t === "pasture" && n.animals && r.set(n.pastureId, n.animals.kind);
	}
	for (let i of ["f", "m"]) {
		let a = i === "f" ? e.forest : e.mountain;
		for (let o = 0; o < 12; o++) {
			let { kinds: s, cap: c } = De(e, i, o, n);
			if (!s.includes(t)) continue;
			if (i === "f" && e.forest[o].t === "pasture") {
				let n = r.get(e.forest[o].pastureId);
				if (n && n !== t) continue;
			}
			let l = a[o].animals;
			if (!(l && l.kind !== t) && (l?.n ?? 0) < c) return !0;
		}
	}
	return !1;
}
function Ae(e, t, n) {
	if (t === "dog") return !0;
	let r = /* @__PURE__ */ new Map();
	for (let t = 0; t < 12; t++) {
		let n = e.forest[t];
		n.t === "pasture" && n.animals && r.set(n.pastureId, n.animals.kind);
	}
	let i = (i, a) => {
		let { kinds: o, cap: s } = De(e, i, a, n);
		if (!o.includes(t)) return !1;
		if (i === "f" && e.forest[a].t === "pasture") {
			let n = r.get(e.forest[a].pastureId);
			if (n && n !== t) return !1;
		}
		let c = i === "f" ? e.forest : e.mountain, l = c[a].animals;
		return l && l.kind !== t || (l?.n ?? 0) >= s ? !1 : (c[a].animals = {
			kind: t,
			n: (l?.n ?? 0) + 1
		}, !0);
	};
	for (let n of ["f", "m"]) {
		let r = n === "f" ? e.forest : e.mountain;
		for (let e = 0; e < 12; e++) if (r[e].animals?.kind === t && i(n, e)) return !0;
	}
	for (let t of ["f", "m"]) {
		let n = t === "f" ? e.forest : e.mountain;
		for (let e = 0; e < 12; e++) if (!n[e].animals && i(t, e)) return !0;
	}
	return !1;
}
function je(e, t, n, r, i) {
	if (I(e, t, n) < r) return !1;
	let a = r;
	if (n === "dog") {
		e.forest.reduce((e, t) => e + (t.dogs ?? 0), 0);
		let n = Math.min(t.dogsHome, a);
		t.dogsHome -= n, a -= n;
		for (let t = 11; t >= 0 && a > 0; t--) {
			let n = e.forest[t], r = Math.min(n.dogs ?? 0, a);
			r > 0 && (n.dogs = (n.dogs ?? 0) - r, n.dogs === 0 && delete n.dogs, a -= r);
		}
		return !0;
	}
	for (let t of [e.mountain, e.forest]) for (let e = 11; e >= 0 && a > 0; e--) {
		let r = t[e].animals;
		if (!r || r.kind !== n) continue;
		let i = Math.min(r.n, a);
		r.n -= i, a -= i, r.n === 0 && delete t[e].animals;
	}
	return !0;
}
function I(e, t, n) {
	let r = n === "dog" ? t.dogsHome : 0;
	for (let t = 0; t < 12; t++) {
		let i = e.forest[t];
		if (n === "dog") r += i.dogs ?? 0;
		else {
			i.animals?.kind === n && (r += i.animals.n);
			let a = e.mountain[t].animals;
			a?.kind === n && (r += a.n);
		}
	}
	return r;
}
function L(e) {
	let t = 0;
	for (let n of e.forest) n.t === "forest" && !n.stable && t++;
	for (let n of e.mountain) n.t === "rock" && t++;
	return t;
}
//#endregion
//#region src/games/caverna/meta.ts
var R = {
	id: "caverna",
	tier: "alpha",
	mechanics: ["worker-placement", "engine-building"],
	interactionTags: [],
	nameKey: "games.caverna.name",
	descKey: "games.caverna.desc",
	rulesKey: "games.caverna.rules",
	icon: "⛏️",
	iconImg: "games/caverna.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/caverna/en.pdf" },
	minPlayers: 1,
	maxPlayers: 7,
	bestPlayers: [4],
	accent: "#b45309",
	releasedAt: "2026-09-25",
	search: {
		py: "dong xue nong fu",
		init: "dxnf"
	},
	hotseat: "open"
}, Me = e.enum(Object.keys(w)), z = e.enum(C), Ne = e.enum([...x, ...C]), B = e.int().min(0).max(11), Pe = e.enum(ve), Fe = e.enum(["grain", "veg"]), Ie = e.array(e.object({
	cell: B,
	crop: Fe
})).max(12), V = e.object({
	dwarf: e.int().min(0).max(5).optional(),
	useRuby: e.boolean().optional(),
	mtnTwin: e.object({
		a: B,
		b: B.optional(),
		aFace: e.enum(["cavern", "tunnel"]),
		bFace: e.enum(["cavern", "tunnel"]).optional()
	}).optional(),
	forTwin: e.object({
		meadow: B.optional(),
		field: B.optional()
	}).optional(),
	furnish: e.object({
		fid: Pe,
		cell: B
	}).optional(),
	sow: Ie.optional(),
	pastureSmall: B.optional(),
	pastureLarge: e.tuple([B, B]).optional(),
	stable: B.optional(),
	forge: e.int().min(0).max(8).optional(),
	loot: e.array(e.string()).max(4).optional(),
	loot2: e.array(e.string()).max(4).optional(),
	lootFurnish: e.object({
		fid: Pe,
		cell: B
	}).optional(),
	lootStable: B.optional(),
	lootTunnel: B.optional(),
	lootPasture: B.optional(),
	lootLargePasture: e.tuple([B, B]).optional(),
	lootMeadow: B.optional(),
	lootField: B.optional(),
	lootCavern: B.optional(),
	lootSow: Ie.optional(),
	lootBreed: e.array(z).max(2).optional(),
	oreMine: e.object({
		cells: e.tuple([B, B]),
		mineAt: B
	}).optional(),
	rubyMine: B.optional(),
	buyTunnel: B.optional(),
	oreTrades: e.int().min(1).max(3).optional(),
	market: e.array(Ne).optional(),
	imitate: Me.optional(),
	growthChoice: e.enum(["goods", "grow"]).optional(),
	wishChoice: e.enum([
		"grow",
		"dwelling",
		"gold"
	]).optional(),
	rubyTile: e.object({
		t: e.enum([
			"meadow",
			"field",
			"tunnel",
			"cavern"
		]),
		cell: B
	}).optional()
}).strict(), Le = e.discriminatedUnion("type", [
	e.object({
		type: e.literal("place"),
		space: Me,
		payload: V.optional()
	}),
	e.object({
		type: e.literal("convert"),
		kind: e.enum([
			"food",
			"buyFood",
			"ruby",
			"rubyTile",
			"peaceful",
			"cookingCave"
		]),
		food: e.partialRecord(e.enum([
			"sheep",
			"boar",
			"cattle",
			"donkey",
			"grain",
			"veg",
			"ruby"
		]), e.int().min(1)).optional(),
		n: e.int().min(1).optional(),
		to: Ne.optional(),
		tile: e.object({
			t: e.enum([
				"meadow",
				"field",
				"tunnel",
				"cavern"
			]),
			cell: B
		}).optional(),
		dwarf: e.int().min(0).max(5).optional()
	}),
	e.object({
		type: e.literal("moveAnimals"),
		forest: e.array(e.object({
			kind: z,
			n: e.int().min(1)
		}).nullable()).length(12),
		mountain: e.array(e.object({
			kind: z,
			n: e.int().min(1)
		}).nullable()).length(12),
		dogs: e.array(e.int().min(0)).length(12),
		dogsHome: e.int().min(0)
	}),
	e.object({
		type: e.literal("resolve"),
		choice: e.enum(["field", "breed"]).optional(),
		keep: e.array(Me).optional()
	}),
	e.object({
		type: e.literal("confirmFeeding"),
		grain: e.int().min(0).optional(),
		veg: e.int().min(0).optional(),
		ruby: e.int().min(0).optional(),
		sheep: e.int().min(0).optional(),
		boar: e.int().min(0).optional(),
		cattle: e.int().min(0).optional(),
		donkey: e.int().min(0).optional(),
		buyFood: e.int().min(0).optional(),
		workingCave: e.enum([
			"wood",
			"stone",
			"ore"
		]).optional()
	}),
	e.object({
		type: e.literal("preScore"),
		op: e.enum([
			"hunting",
			"beerGold",
			"beerFood",
			"trader",
			"spareParts",
			"smithParlor"
		]).optional(),
		n: e.int().min(1).optional()
	})
]), Re = e.partialRecord(Ne, e.int().min(0)), ze = e.partialRecord(e.enum(x), e.int().min(0)), Be = e.object({
	t: e.enum([
		"forest",
		"meadow",
		"field",
		"pasture"
	]),
	stable: e.boolean().optional(),
	crop: Fe.nullable().optional(),
	cropN: e.int().min(0).optional(),
	animals: e.object({
		kind: z,
		n: e.int().min(1)
	}).optional(),
	dogs: e.int().min(1).optional(),
	pastureId: e.int().optional()
}), Ve = e.object({
	t: e.enum([
		"rock",
		"cavern",
		"tunnel",
		"deepTunnel",
		"oreMine",
		"rubyMine"
	]),
	furnishing: e.string().optional(),
	animals: e.object({
		kind: z,
		n: e.int().min(1)
	}).optional()
}), He = e.object({
	rid: e.string(),
	dwarfs: e.array(e.object({ weapon: e.int().min(0).max(14) })),
	newborn: e.int().min(0),
	placed: e.array(e.int()),
	goods: ze,
	forest: e.array(Be),
	mountain: e.array(Ve),
	dogsHome: e.int().min(0),
	stables: e.int().min(0).max(3),
	hasLandscape: e.boolean(),
	furnishings: e.array(Pe),
	begging: e.int().min(0)
}), Ue = e.object({
	round: e.int().min(1).max(12),
	rounds: e.array(e.int()),
	phase: e.enum([
		"work",
		"resolve",
		"feeding",
		"preScore",
		"done"
	]),
	roundOrder: e.array(Me),
	harvestMarks: e.record(e.string(), e.enum([
		"leaf",
		"q1",
		"q2",
		"q3"
	]).nullable()),
	spaces: e.array(e.object({
		id: Me,
		goods: Re,
		by: e.array(e.string())
	})),
	startPlayer: e.string(),
	active: e.string().nullable(),
	players: e.array(He),
	pending: e.array(e.object({
		rid: e.string(),
		kind: e.enum(["harvestChoice", "rubyKeep"])
	})),
	feedingWaiting: e.array(e.string()),
	feedMode: e.enum(["normal", "half"]).nullable(),
	preScoreWaiting: e.array(e.string()),
	furnishingsTaken: e.record(e.string(), e.string()),
	lastEvent: Me.nullable()
}), We = e.object({}), H = (e, t) => e.players.findIndex((e) => e.rid === t);
function Ge(e, n) {
	let r = [...e];
	for (let e = r.length - 1; e > 0; e--) {
		let i = t(n.seed, n.rngCursor, e + 1);
		n.rngCursor++, [r[e], r[i]] = [r[i], r[e]];
	}
	return r;
}
function Ke(e, t, n) {
	return {
		rid: e,
		dwarfs: [{ weapon: 0 }, { weapon: 0 }],
		placed: [],
		goods: {
			wood: 0,
			stone: 0,
			ore: 0,
			ruby: 0,
			gold: 0,
			food: ge(t, n),
			grain: 0,
			veg: 0
		},
		board: N(pe, O),
		dogsHome: 0,
		furnishings: [],
		begging: 0
	};
}
var U = (e, t) => e.furnishings.includes(t);
function qe(e, t) {
	return Object.entries(t).every(([t, n]) => (e.goods[t] ?? 0) >= (n ?? 0));
}
function W(e, t) {
	for (let [n, r] of Object.entries(t)) e.goods[n] -= r ?? 0;
}
function Je(e, t) {
	for (let [n, r] of Object.entries(t)) e.goods[n] = (e.goods[n] ?? 0) + (r ?? 0);
}
var G = (e) => ({
	hasStubbleRoom: U(e, "stubbleRoom"),
	dwarfCount: e.dwarfs.length
});
function K(e, t, n) {
	for (let [e, r] of Object.entries(n)) {
		let n = r ?? 0;
		if (!(n <= 0)) {
			if ([
				"dog",
				"sheep",
				"donkey",
				"boar",
				"cattle"
			].includes(e)) {
				let r = e;
				for (let e = 0; e < n; e++) r === "dog" ? (t.dogsHome++, U(t, "dogSchool") && t.goods.wood++) : Ae(t.board, r, G(t)) || (t.goods.food += r === "donkey" ? 1 : r === "boar" ? 2 : r === "cattle" ? 3 : 1);
				continue;
			}
			t.goods[e] += n, e === "stone" && U(t, "seam") && (t.goods.ore += 1);
		}
	}
}
function q(e, t, n, r) {
	let i = e.roundGoods[t.rid] ??= {}, a = i[String(n)] ??= {};
	for (let [e, t] of Object.entries(r)) a[e] = (a[e] ?? 0) + (t ?? 0);
}
//#endregion
//#region src/games/caverna/rules.ts
var J = (e) => ({ code: e });
function Ye(e, n, r) {
	let i = n.length, a = {
		seed: r,
		rngCursor: 0,
		players: n.map((e, t) => Ke(e, t, i)),
		roundIdx: 0,
		phase: "work",
		roundOrder: [],
		harvestMarks: {},
		board: T(i).map((e) => ({
			id: e,
			goods: {},
			by: []
		})),
		startPlayer: 0,
		active: 0,
		pending: [],
		feedingWaiting: [],
		harvestChoice: {},
		feedMode: "normal",
		preScoreWaiting: [],
		furnishingsTaken: {},
		roundGoods: {},
		lastEvent: null,
		scores: null
	};
	if (i === 1) a.roundOrder = [...ue];
	else {
		let e = se.filter((e) => e !== "exploration" || i > 2);
		a.roundOrder = [
			...Ge([...oe], a),
			"wishForChildren",
			...Ge([...E], a),
			...Ge(e, a),
			...Ge([...ce], a)
		];
	}
	if (i > 1) {
		let e = le(i).filter((e) => e >= 6), t = Ge([
			...Array(i === 2 ? 3 : 4).fill("leaf"),
			"q1",
			"q2",
			"q3"
		], a);
		e.forEach((e, n) => a.harvestMarks[e] = t[n]);
	}
	return a.startPlayer = t(a.seed, a.rngCursor, i), a.rngCursor++, a.active = a.startPlayer, Ze(a), { state: a };
}
var Xe = (e) => le(e.players.length)[e.roundIdx];
function Y(e) {
	let t = e.players.length, n = Xe(e);
	t === 1 && e.board.filter((e) => Object.values(e.goods).reduce((e, t) => e + (t ?? 0), 0) > 6).length > 0 && e.pending.push({
		rid: e.players[0].rid,
		kind: "rubyKeep"
	});
	let r = e.roundOrder[e.roundIdx];
	e.board.push({
		id: r,
		goods: {},
		by: []
	}), e.lastEvent = r;
	for (let r of e.board) {
		if (r.id === "rubyMining" && t === 2 && n <= 2) continue;
		let e = ae(r.id, t);
		if (!e) continue;
		let i = Object.keys(r.goods).length === 0, a = "add" in e ? e.add : i ? e.ifEmpty : e.else;
		for (let [e, t] of Object.entries(a)) r.goods[e] = (r.goods[e] ?? 0) + (t ?? 0);
	}
}
function Ze(e) {
	for (let t of e.players) {
		for (let e of t.dwarfs) delete e.baby;
		t.placed = [];
	}
	for (let t of e.board) t.by = [];
	Y(e);
	let t = Xe(e);
	for (let n of e.players) {
		let r = e.roundGoods[n.rid]?.[String(t)];
		if (r && (K(e, n, r), delete e.roundGoods[n.rid][String(t)]), U(n, "miner")) {
			let t = n.board.mountain.filter((e) => e.t === "oreMine" && e.animals?.kind === "donkey").length;
			t > 0 && K(e, n, { ore: t });
		}
	}
	e.active = e.startPlayer;
}
function Qe(e) {
	let t = e.players.length;
	for (let n = 1; n <= t; n++) {
		let r = (e.active + n) % t;
		if (e.players[r].placed.length < e.players[r].dwarfs.length) {
			e.active = r;
			return;
		}
	}
	et(e);
}
function $e(e, t) {
	return e.players.length === 1 ? t >= 5 ? "leaf" : "none" : t === 3 || t === 5 ? "leaf" : t === 4 ? "half" : t >= 6 ? e.harvestMarks[t] ?? "none" : "none";
}
function et(e) {
	let t = $e(e, Xe(e));
	if (t === "none" || t === "q1") return ot(e);
	if (t === "half" || t === "q2") return nt(e, "half");
	if (t === "q3") {
		e.harvestChoice = {};
		for (let t of e.players) e.pending.push({
			rid: t.rid,
			kind: "harvestChoice"
		});
		return;
	}
	tt(e, e.players), nt(e, "normal");
}
function tt(e, t) {
	for (let n of t) for (let t of n.board.forest) t.t === "field" && t.crop && t.cropN && (t.cropN--, K(e, n, { [t.crop]: 1 }), t.cropN === 0 && (delete t.crop, delete t.cropN));
}
function nt(e, t) {
	e.phase = "feeding", e.feedMode = t, e.feedingWaiting = e.players.map((e) => e.rid);
}
function rt(e, t) {
	let n = t === "half" ? e.dwarfs.length : e.dwarfs.reduce((e, t) => e + (t.baby ? 1 : 2), 0);
	return U(e, "miningCave") && (n -= e.board.mountain.filter((e) => e.t === "oreMine" && e.animals?.kind === "donkey").length), Math.max(0, n);
}
function it(e) {
	if (e.feedMode === "normal") {
		let t = Object.keys(e.harvestChoice).length > 0 ? e.players.filter((t) => e.harvestChoice[t.rid] === "breed") : e.players;
		for (let n of t) at(e, n);
		e.harvestChoice = {};
	}
	ot(e);
}
function at(e, t, n) {
	let r = G(t), i = [];
	for (let a of S) (!n || n.includes(a)) && (I(t.board, t, a) < 2 || ke(t.board, a, r) && Ae(t.board, a, r) && (i.push(a), U(t, "breedingCave") && t.goods.food++, a === "donkey" && U(t, "quarry") && K(e, t, { stone: 1 })));
	U(t, "breedingCave") && i.length === 4 && t.goods.food++;
}
function ot(e) {
	if (e.roundIdx++, e.roundIdx >= le(e.players.length).length) {
		e.phase = "preScore", e.preScoreWaiting = e.players.map((e) => e.rid);
		return;
	}
	e.phase = "work", Ze(e);
}
var st = (e) => U(e, "additionalDwelling") ? 6 : 5;
function ct(e) {
	let t = 2;
	for (let n of e.furnishings) t += j[n].room ?? 0;
	return t;
}
var lt = (e) => e.dwarfs.length < st(e) && e.dwarfs.length < ct(e);
function ut(e) {
	return lt(e) ? (e.dwarfs.push({
		weapon: 0,
		baby: !0
	}), null) : J("games.caverna.errNoRoom");
}
function dt(e, t) {
	let n = { ...t };
	if (U(e, "carpenter") && n.wood && (n.wood = Math.max(0, n.wood - 1)), U(e, "stoneCarver") && n.stone && (n.stone = Math.max(0, n.stone - 1)), qe(e, n)) return n;
	if (U(e, "builder")) for (let t of [0, 1]) for (let r of [0, 1]) {
		if (!t && !r) continue;
		let i = { ...n };
		if (t && i.wood && (i.wood--, i.ore = (i.ore ?? 0) + 1), r && i.stone && (i.stone--, i.ore = (i.ore ?? 0) + 1), qe(e, i)) return i;
	}
	return null;
}
function ft(e, t) {
	e.furnishings = e.furnishings.filter((e) => e !== t);
	for (let n of e.board.mountain) n.furnishing === t && delete n.furnishing;
}
function pt(e, t, n, r, i) {
	let a = j[n];
	if (!a) return J("games.caverna.errBadPayload");
	if (!a.unlimited && e.furnishingsTaken[n]) return J("games.caverna.errTaken");
	let o = t.board.mountain[r];
	if (!o) return J("games.caverna.errBadCell");
	let s = o.t === "tunnel" || o.t === "deepTunnel";
	if (!(o.t === "cavern" || s && U(t, "workRoom") && n !== "workRoom") || o.furnishing) return J("games.caverna.errBadCell");
	let c = dt(t, i ?? a.cost);
	if (!c) return J("games.caverna.errCantAfford");
	n === "trader" && U(t, "sparePartStorage") && ft(t, "sparePartStorage"), n === "sparePartStorage" && U(t, "trader") && ft(t, "trader"), W(t, c), o.furnishing = n, t.furnishings.push(n), a.unlimited || (e.furnishingsTaken[n] = t.rid), n === "stoneCarver" && K(e, t, { stone: 2 }), n === "blacksmith" && K(e, t, { ore: 2 }), n === "weavingParlor" && K(e, t, { food: I(t.board, t, "sheep") }), n === "milkingParlor" && K(e, t, { food: I(t.board, t, "cattle") }), n === "stateParlor" && K(e, t, { food: 2 * mt(t, r) });
	let l = M[n];
	if (l) {
		let n = Xe(e);
		for (let r = 1; r <= l.rounds; r++) q(e, t, n + r, { [l.good]: 1 });
	}
	return null;
}
function mt(e, t) {
	let n = 0;
	for (let r of P(t)) {
		let t = e.board.mountain[r]?.furnishing;
		(t === "entryDwelling" || t && j[t]?.cat === "dwelling") && n++;
	}
	return n;
}
function ht(e, t, n, r) {
	let i = n.b === void 0;
	if (i && !U(t, "officeRoom")) return J("games.caverna.errBadCell");
	let a = n.aFace, o = i ? void 0 : n.bFace ?? (a === "cavern" ? "tunnel" : "cavern"), s = i ? [a] : [a, o], c = s.filter((e) => e === "cavern").length, l = s.filter((e) => e === "tunnel").length;
	if ((c !== 1 || l !== s.length - 1) && !(r && c === s.length)) return J("games.caverna.errBadPayload");
	if (!Ce(t.board, n.a, n.b ?? -1, i)) return J("games.caverna.errBadCell");
	t.board.mountain[n.a] = { t: a }, i || (t.board.mountain[n.b] = { t: o });
	for (let r of i ? [n.a] : [n.a, n.b]) {
		let n = k[r];
		n && K(e, t, n);
	}
	return i && K(e, t, { gold: 2 }), null;
}
function gt(e, t, n) {
	let r = n.meadow ?? -1, i = n.field ?? -1;
	if (r < 0 && i < 0) return J("games.caverna.errBadPayload");
	let a = r < 0 || i < 0;
	if (a && !U(t, "officeRoom") || !F(t.board, r, i, a)) return J("games.caverna.errBadCell");
	r >= 0 && (t.board.forest[r] = {
		...t.board.forest[r],
		t: "meadow"
	}), i >= 0 && (t.board.forest[i] = {
		...t.board.forest[i],
		t: "field"
	}), t.board.hasLandscape = !0;
	for (let n of [r, i]) {
		if (n < 0) continue;
		let r = me[n];
		r && K(e, t, r);
	}
	return a && K(e, t, { gold: 2 }), null;
}
function _t(e, t, n, r) {
	let i = n === "cavern" ? 2 : 1;
	if (t.goods.ruby < i) return J("games.caverna.errCantAfford");
	if (n === "meadow" || n === "field") {
		if (!we(t.board, r, n) || !Te(t.board, [r])) return J("games.caverna.errBadCell");
		t.goods.ruby -= i, t.board.forest[r] = {
			...t.board.forest[r],
			t: n
		}, t.board.hasLandscape = !0;
		let a = me[r];
		a && K(e, t, a);
	} else {
		if (!Se(t.board, r)) return J("games.caverna.errBadCell");
		t.goods.ruby -= i, t.board.mountain[r] = { t: n };
		let a = k[r];
		a && K(e, t, a);
	}
	return null;
}
function vt(e, t) {
	if (t.length === 0) return J("games.caverna.errBadPayload");
	let n = t.filter((e) => e.crop === "grain").length, r = t.length - n;
	if (n > 2 || r > 2) return J("games.caverna.errBadPayload");
	let i = /* @__PURE__ */ new Set();
	for (let { cell: n } of t) {
		let t = e.board.forest[n];
		if (!t || t.t !== "field" || t.crop || i.has(n)) return J("games.caverna.errBadCell");
		i.add(n);
	}
	if (e.goods.grain < n || e.goods.veg < r) return J("games.caverna.errCantAfford");
	e.goods.grain -= n, e.goods.veg -= r;
	for (let { cell: n, crop: r } of t) e.board.forest[n].crop = r, e.board.forest[n].cropN = r === "grain" ? 3 : 2;
	return null;
}
function yt(e, t, n, r) {
	if (t.board.stables >= 3) return J("games.caverna.errBadCell");
	let i = t.board.forest[n];
	if (!i || i.stable || ![
		"forest",
		"meadow",
		"pasture"
	].includes(i.t)) return J("games.caverna.errBadCell");
	if (!r) {
		let e = +!U(t, "stoneCarver");
		if (t.goods.stone < e) return J("games.caverna.errCantAfford");
		t.goods.stone -= e;
	}
	return i.stable = !0, t.board.stables++, null;
}
function bt(e, t) {
	return U(e, "carpenter") ? Math.max(0, t - 1) : t;
}
function xt(e, t, n) {
	let r = e.board.forest[t];
	if (!r || r.t !== "meadow") return J("games.caverna.errBadCell");
	let i = bt(e, n);
	return e.goods.wood < i ? J("games.caverna.errCantAfford") : (e.goods.wood -= i, r.t = "pasture", r.pastureId = e.board.nextPastureId++, null);
}
function St(e, t, n) {
	let [r, i] = t, a = e.board.forest[r], o = e.board.forest[i];
	if (!a || !o || a.t !== "meadow" || o.t !== "meadow" || !be(r, i)) return J("games.caverna.errBadCell");
	let s = bt(e, n);
	if (e.goods.wood < s) return J("games.caverna.errCantAfford");
	e.goods.wood -= s;
	let c = e.board.nextPastureId++;
	return a.t = "pasture", a.pastureId = c, o.t = "pasture", o.pastureId = c, null;
}
function Ct(e, t, n) {
	let r = e.dwarfs[t];
	if (!r || r.weapon > 0) return J("games.caverna.errBadDwarf");
	if (n < 1 || n > 8) return J("games.caverna.errBadPayload");
	let i = Math.max(0, n - (U(e, "blacksmith") ? 2 : 0));
	return e.goods.ore < i ? J("games.caverna.errCantAfford") : (e.goods.ore -= i, r.weapon = n, null);
}
function wt(e, t, n, r, i, a) {
	let o = t.dwarfs[n];
	if (!o || o.weapon <= 0) return J("games.caverna.errNeedWeapon");
	if (i.length > r || new Set(i).size !== i.length) return J("games.caverna.errBadLoot");
	let s = o.weapon;
	for (let e of i) {
		let t = de.find((t) => t.id === e);
		if (!t || t.min > s) return J("games.caverna.errBadLoot");
	}
	let c = [...i].sort((e, t) => (e === "weaponsUp" ? 0 : 1) - (t === "weaponsUp" ? 0 : 1));
	for (let n of c) {
		let r = Tt(e, t, n, a);
		if (r) return r;
	}
	return o.weapon = Math.min(14, o.weapon + 1), null;
}
function Tt(e, t, n, r) {
	switch (n) {
		case "weaponsUp":
			for (let e of t.dwarfs) e.weapon > 0 && (e.weapon = Math.min(14, e.weapon + 1));
			return null;
		case "dog":
		case "sheep":
		case "donkey":
		case "boar":
		case "cattle": return K(e, t, { [n]: 1 }), null;
		case "wood":
		case "stone":
		case "grain":
		case "veg": return K(e, t, { [n]: 1 }), null;
		case "ore2": return K(e, t, { ore: 2 }), null;
		case "gold2": return K(e, t, { gold: 2 }), null;
		case "furnish": return !r.lootFurnish || r.lootFurnish.fid === "dwelling" ? J("games.caverna.errBadPayload") : pt(e, t, r.lootFurnish.fid, r.lootFurnish.cell);
		case "dwelling2w2s": return !r.lootFurnish || r.lootFurnish.fid !== "dwelling" ? J("games.caverna.errBadPayload") : pt(e, t, "dwelling", r.lootFurnish.cell, {
			wood: 2,
			stone: 2
		});
		case "stable": return r.lootStable === void 0 ? J("games.caverna.errBadPayload") : yt(e, t, r.lootStable, !0);
		case "tunnel": return r.lootTunnel === void 0 || !Se(t.board, r.lootTunnel) ? J("games.caverna.errBadCell") : (t.board.mountain[r.lootTunnel] = { t: "tunnel" }, k[r.lootTunnel] && K(e, t, k[r.lootTunnel]), null);
		case "cavern": return r.lootCavern === void 0 || !Se(t.board, r.lootCavern) ? J("games.caverna.errBadCell") : (t.board.mountain[r.lootCavern] = { t: "cavern" }, k[r.lootCavern] && K(e, t, k[r.lootCavern]), null);
		case "smallPasture1w": return r.lootPasture === void 0 ? J("games.caverna.errBadPayload") : xt(t, r.lootPasture, 1);
		case "largePasture2w": return r.lootLargePasture ? St(t, r.lootLargePasture, 2) : J("games.caverna.errBadPayload");
		case "meadow":
		case "field": {
			let i = n === "meadow" ? r.lootMeadow : r.lootField;
			return i === void 0 || !we(t.board, i, n) || !Te(t.board, [i]) ? J("games.caverna.errBadCell") : (t.board.forest[i] = {
				...t.board.forest[i],
				t: n
			}, t.board.hasLandscape = !0, me[i] && K(e, t, me[i]), null);
		}
		case "sow": return r.lootSow ? vt(t, r.lootSow) : J("games.caverna.errBadPayload");
		case "breed2": {
			let n = r.lootBreed ?? [];
			if (n.length === 0 || n.length > 2 || new Set(n).size !== n.length || n.includes("dog")) return J("games.caverna.errBadPayload");
			let i = G(t);
			for (let e of n) if (I(t.board, t, e) < 2 || !ke(t.board, e, i)) return J("games.caverna.errBadPayload");
			return at(e, t, n), null;
		}
	}
	return J("games.caverna.errBadPayload");
}
var Et = {
	wood: 1,
	stone: 1,
	ore: 1,
	food: 1,
	gold: 2
};
function Dt(e, t, n, r = {}) {
	if (e.phase !== "work") return J("games.caverna.errBadPhase");
	if (e.pending.length > 0) return J("games.caverna.errPending");
	let i = H(e, t);
	if (i !== e.active) return J("games.caverna.errNotYourTurn");
	let a = e.board.find((e) => e.id === n);
	if (!a) return J("games.caverna.errBadSpace");
	if (a.by.length > 0) return J("games.caverna.errOccupied");
	let o = e.players[i], s = o.dwarfs.map((e, t) => t).filter((e) => !o.placed.includes(e)).sort((e, t) => o.dwarfs[e].weapon - o.dwarfs[t].weapon);
	if (s.length === 0) return J("games.caverna.errBadDwarf");
	let c;
	if (r.useRuby) {
		if (o.goods.ruby < 1) return J("games.caverna.errCantAfford");
		let e = r.dwarf ?? 0;
		if (e >= s.length) return J("games.caverna.errBadDwarf");
		c = s[e], o.goods.ruby--;
	} else {
		if (r.dwarf !== void 0 && r.dwarf !== 0) return J("games.caverna.errPlayOrder");
		c = s[0];
	}
	return Ot(e, o, a, r, c) || (o.placed.push(c), a.by.push(t), Qe(e), { state: e });
}
function Ot(e, t, n, r, i, a = !1) {
	let o = e.players.length, s = !1, c = () => {
		Object.keys(n.goods).length > 0 && (K(e, t, n.goods), n.goods = {}, s = !0);
	}, l = (e) => t.board.mountain.filter((t) => t.t === e).length;
	switch (n.id) {
		case "driftMining":
		case "driftMining2":
			if (c(), r.mtnTwin) {
				let n = ht(e, t, r.mtnTwin, !1);
				if (n) return n;
				s = !0;
			}
			break;
		case "excavation":
			if (c(), r.mtnTwin) {
				let n = ht(e, t, r.mtnTwin, !0);
				if (n) return n;
				s = !0;
			}
			break;
		case "startingPlayer":
			c(), K(e, t, o <= 3 ? { ore: 2 } : { ruby: 1 }), e.startPlayer = H(e, t.rid), s = !0;
			break;
		case "logging":
			if (c(), r.loot !== void 0 && t.dwarfs[i].weapon > 0) {
				let n = wt(e, t, i, 1, r.loot, r);
				if (n) return n;
				s = !0;
			}
			break;
		case "supplies":
			K(e, t, Et), s = !0;
			break;
		case "growth": {
			let n = U(t, "guestRoom");
			if ((r.growthChoice === "goods" || n && r.growthChoice === "grow") && (K(e, t, Et), s = !0), r.growthChoice === "grow" || n && r.growthChoice === "goods") {
				let e = ut(t);
				if (e) return e;
				s = !0;
			}
			if (!s) return J("games.caverna.errBadPayload");
			break;
		}
		case "oreMining": {
			c();
			let n = l("oreMine");
			n > 0 && (K(e, t, { ore: 2 * n }), s = !0);
			break;
		}
		case "woodGathering":
			c();
			break;
		case "clearing":
			if (c(), r.forTwin) {
				let n = gt(e, t, r.forTwin);
				if (n) return n;
				s = !0;
			}
			break;
		case "sustenance":
			if (c(), o <= 3 && K(e, t, { grain: 1 }), s = !0, r.forTwin) {
				let n = gt(e, t, r.forTwin);
				if (n) return n;
				s = !0;
			}
			break;
		case "forestExploration":
			c(), K(e, t, { food: 2 }), s = !0;
			break;
		case "imitation":
		case "imitation3":
		case "imitation5a":
		case "imitation5b":
		case "imitation6a":
		case "imitation6b":
		case "imitation7a":
		case "imitation7b":
		case "imitation7c": {
			if (a) return J("games.caverna.errBadSpace");
			let o = r.imitate;
			if (!o || o === "startingPlayer" || o.startsWith("imitation")) return J("games.caverna.errBadSpace");
			let c = e.board.find((e) => e.id === o);
			if (!c || c.by.length === 0 || c.by.includes(t.rid)) return J("games.caverna.errBadSpace");
			let l = w[n.id].imitationCost ?? 0;
			if (t.goods.food < l) return J("games.caverna.errCantAfford");
			t.goods.food -= l;
			let u = Ot(e, t, {
				id: o,
				goods: {}
			}, r, i, !0);
			if (u) return u;
			s = !0;
			break;
		}
		case "rubyMining":
			c(), l("rubyMine") > 0 && (K(e, t, { ruby: 1 }), s = !0);
			break;
		case "housework":
			if (K(e, t, { dog: 1 }), s = !0, r.furnish) {
				let n = pt(e, t, r.furnish.fid, r.furnish.cell);
				if (n) return n;
				s = !0;
			}
			break;
		case "slashAndBurn":
			if (r.rubyTile) {
				let n = _t(e, t, r.rubyTile.t, r.rubyTile.cell);
				if (n) return n;
				s = !0;
			}
			if (r.forTwin) {
				let n = gt(e, t, r.forTwin);
				if (n) return n;
				s = !0;
			}
			if (r.sow) {
				let e = vt(t, r.sow);
				if (e) return e;
				s = !0;
			}
			break;
		case "stripMining":
			c(), K(e, t, { wood: 2 }), s = !0;
			break;
		case "forestExploration3":
			c(), K(e, t, { veg: 1 }), s = !0;
			break;
		case "depot":
		case "largeDepot":
			c();
			break;
		case "weeklyMarket":
			if (K(e, t, { gold: 4 }), s = !0, r.market && r.market.length > 0) {
				let n = r.market;
				if (new Set(n).size !== n.length) return J("games.caverna.errBadPayload");
				let i = 0;
				for (let e of n) {
					let t = _e[e];
					if (t === void 0) return J("games.caverna.errBadPayload");
					i += t;
				}
				if (t.goods.gold < i) return J("games.caverna.errCantAfford");
				t.goods.gold -= i;
				for (let r of n) K(e, t, { [r]: 1 });
			}
			break;
		case "hardwareRental":
			if (o >= 6 && (K(e, t, { wood: 2 }), s = !0), r.rubyTile) {
				let n = _t(e, t, r.rubyTile.t, r.rubyTile.cell);
				if (n) return n;
				s = !0;
			}
			if (r.loot !== void 0 && t.dwarfs[i].weapon > 0) {
				let n = wt(e, t, i, 2, r.loot, r);
				if (n) return n;
				s = !0;
			}
			if (r.sow) {
				let e = vt(t, r.sow);
				if (e) return e;
				s = !0;
			}
			break;
		case "smallDriftMining":
			if (r.mtnTwin) {
				let n = ht(e, t, r.mtnTwin, !1);
				if (n) return n;
				s = !0;
			}
			s && K(e, t, { stone: 1 });
			break;
		case "fenceBuilding":
			if (c(), r.pastureSmall !== void 0) {
				let e = xt(t, r.pastureSmall, 2);
				if (e) return e;
				s = !0;
			}
			if (r.pastureLarge) {
				let e = St(t, r.pastureLarge, 4);
				if (e) return e;
				s = !0;
			}
			break;
		case "extension": {
			let n = U(t, "guestRoom"), i = !!r.forTwin, a = !!r.mtnTwin;
			if (!i && !a || !n && i && a) return J("games.caverna.errBadPayload");
			if (i) {
				let n = gt(e, t, r.forTwin);
				if (n) return n;
				K(e, t, { wood: 1 }), s = !0;
			}
			if (a) {
				let n = ht(e, t, r.mtnTwin, !1);
				if (n) return n;
				K(e, t, { stone: 1 }), s = !0;
			}
			break;
		}
		case "blacksmithing": {
			if (t.dwarfs[i].weapon === 0) {
				if (r.forge === void 0) return J("games.caverna.errBadPayload");
				let e = Ct(t, i, r.forge);
				if (e) return e;
			}
			let n = wt(e, t, i, 3, r.loot ?? [], r);
			if (n) return n;
			s = !0;
			break;
		}
		case "sheepFarming":
		case "donkeyFarming":
			if (r.pastureSmall !== void 0) {
				let e = xt(t, r.pastureSmall, 2);
				if (e) return e;
				s = !0;
			}
			if (r.pastureLarge) {
				let e = St(t, r.pastureLarge, 4);
				if (e) return e;
				s = !0;
			}
			if (r.stable !== void 0) {
				let n = yt(e, t, r.stable, !1);
				if (n) return n;
				s = !0;
			}
			c();
			break;
		case "oreMineConstruction":
			if (r.oreMine) {
				let [n, i] = r.oreMine.cells, a = t.board.mountain[n], o = t.board.mountain[i];
				if (!a || !o || a.t !== "tunnel" || o.t !== "tunnel" || !be(n, i) || !r.oreMine.cells.includes(r.oreMine.mineAt)) return J("games.caverna.errBadCell");
				let c = r.oreMine.mineAt === n ? i : n;
				t.board.mountain[r.oreMine.mineAt] = { t: "oreMine" }, t.board.mountain[c] = { t: "deepTunnel" }, K(e, t, { ore: 3 }), s = !0;
			}
			if (r.loot !== void 0 && t.dwarfs[i].weapon > 0) {
				let n = wt(e, t, i, 2, r.loot, r);
				if (n) return n;
				s = !0;
			}
			break;
		case "wishForChildren": {
			let n = e.board.some((e) => e.id === "familyLife"), i = U(t, "guestRoom"), a = () => !r.furnish || r.furnish.fid !== "dwelling" ? J("games.caverna.errBadPayload") : pt(e, t, "dwelling", r.furnish.cell);
			if (n) {
				let n = r.wishChoice === "gold", o = r.wishChoice === "dwelling";
				if (!n && !o) return J("games.caverna.errBadPayload");
				if (o) {
					let e = a();
					if (e) return e;
					if (s = !0, lt(t)) {
						let e = ut(t);
						if (e) return e;
					}
				}
				(n || i && o) && (K(e, t, { gold: 3 }), s = !0);
			} else {
				let e = r.wishChoice === "grow", n = r.wishChoice === "dwelling";
				if (!e && !n) return J("games.caverna.errBadPayload");
				if (n) {
					let e = a();
					if (e) return e;
					s = !0;
				}
				if (e) {
					let e = ut(t);
					if (e) return e;
					s = !0;
				} else if (i && n && lt(t)) {
					let e = ut(t);
					if (e) return e;
				}
			}
			break;
		}
		case "rubyMineConstruction":
			if (r.buyTunnel !== void 0) {
				if (t.goods.ruby < 1 || !Se(t.board, r.buyTunnel)) return J("games.caverna.errBadCell");
				t.goods.ruby--, t.board.mountain[r.buyTunnel] = { t: "tunnel" }, k[r.buyTunnel] && K(e, t, k[r.buyTunnel]), s = !0;
			}
			if (r.rubyMine !== void 0) {
				let n = t.board.mountain[r.rubyMine];
				if (!n || n.t !== "tunnel" && n.t !== "deepTunnel" || n.furnishing) return J("games.caverna.errBadCell");
				let i = n.t === "deepTunnel";
				t.board.mountain[r.rubyMine] = { t: "rubyMine" }, i && K(e, t, { ruby: 1 }), s = !0;
			}
			break;
		case "familyLife":
			if (r.wishChoice === "grow" || r.growthChoice === "grow") {
				let e = ut(t);
				if (e) return e;
				s = !0;
			}
			if (r.rubyTile) {
				let n = _t(e, t, r.rubyTile.t, r.rubyTile.cell);
				if (n) return n;
				s = !0;
			}
			if (r.sow) {
				let e = vt(t, r.sow);
				if (e) return e;
				s = !0;
			}
			break;
		case "exploration": {
			if (t.dwarfs[i].weapon <= 0) return J("games.caverna.errNeedWeapon");
			let n = wt(e, t, i, 4, r.loot ?? [], r);
			if (n) return n;
			s = !0;
			break;
		}
		case "oreDelivery": {
			c();
			let n = l("oreMine");
			n > 0 && (K(e, t, { ore: 2 * n }), s = !0);
			break;
		}
		case "adventure": {
			if (t.dwarfs[i].weapon === 0) {
				if (r.forge === void 0) return J("games.caverna.errBadPayload");
				let e = Ct(t, i, r.forge);
				if (e) return e;
			}
			let n = wt(e, t, i, 1, r.loot ?? [], r);
			if (n) return n;
			let a = wt(e, t, i, 1, r.loot2 ?? [], r);
			if (a) return a;
			s = !0;
			break;
		}
		case "oreTrading": {
			let n = r.oreTrades ?? 0;
			if (n < 1) return J("games.caverna.errBadPayload");
			if (t.goods.ore < 2 * n) return J("games.caverna.errCantAfford");
			t.goods.ore -= 2 * n, K(e, t, {
				gold: 2 * n,
				food: n
			}), s = !0;
			break;
		}
		case "rubyDelivery": c(), l("rubyMine") >= 2 && (K(e, t, { ruby: 1 }), s = !0);
	}
	return s ? null : J("games.caverna.errNoAction");
}
function kt(e, t, n) {
	if (e.phase === "done" || e.phase === "preScore") return J("games.caverna.errBadPhase");
	let r = e.players[H(e, t)], i = +!!U(r, "slaughteringCave");
	switch (n.kind) {
		case "food": {
			let t = n.food ?? {};
			if (Object.keys(t).length === 0) return J("games.caverna.errBadPayload");
			let a = 0;
			for (let [e, n] of Object.entries(t)) {
				let t = n ?? 0;
				if (!(t <= 0)) {
					if (e === "grain" || e === "veg" || e === "ruby") {
						if (r.goods[e] < t) return J("games.caverna.errCantAfford");
						r.goods[e] -= t, a += (ne[e] ?? 0) * t;
					} else {
						let n = e;
						if (!je(r.board, r, n, t, G(r))) return J("games.caverna.errCantAfford");
						a += (n === "donkey" ? re(t) : (ne[n] ?? 0) * t) + i * t;
					}
				}
			}
			return r.goods.food += a, { state: e };
		}
		case "buyFood": {
			let t = n.n ?? 0;
			return t < 1 || r.goods.gold < ie(t) ? J("games.caverna.errCantAfford") : (r.goods.gold -= ie(t), r.goods.food += t, { state: e });
		}
		case "ruby": {
			let t = n.to;
			if (!t || t === "food" || t === "ruby") return J("games.caverna.errBadPayload");
			let i = +(t === "cattle");
			return r.goods.ruby < 1 || r.goods.food < i ? J("games.caverna.errCantAfford") : (r.goods.ruby--, r.goods.food -= i, K(e, r, { [t]: 1 }), { state: e });
		}
		case "rubyTile": return n.tile ? _t(e, r, n.tile.t, n.tile.cell) || { state: e } : J("games.caverna.errBadPayload");
		case "peaceful": {
			if (!U(r, "peacefulCave")) return J("games.caverna.errBadPayload");
			let t = r.dwarfs[n.dwarf ?? -1];
			return !t || t.weapon <= 0 ? J("games.caverna.errBadDwarf") : (r.goods.food += t.weapon, t.weapon = 0, { state: e });
		}
		case "cookingCave": {
			if (!U(r, "cookingCave")) return J("games.caverna.errBadPayload");
			let t = n.n ?? 1;
			return r.goods.grain < t || r.goods.veg < t ? J("games.caverna.errCantAfford") : (r.goods.grain -= t, r.goods.veg -= t, r.goods.food += 5 * t, { state: e });
		}
	}
	return J("games.caverna.errBadPayload");
}
function At(e, t, n) {
	if (e.phase !== "work") return J("games.caverna.errBadPhase");
	let r = e.players[H(e, t)], i = {
		dog: 0,
		sheep: 0,
		donkey: 0,
		boar: 0,
		cattle: 0
	};
	for (let e of Object.keys(i)) i[e] = I(r.board, r, e);
	let a = structuredClone(r.board), o = r.dogsHome, s = {
		dog: 0,
		sheep: 0,
		donkey: 0,
		boar: 0,
		cattle: 0
	};
	for (let e = 0; e < 12; e++) {
		let t = n.forest[e], i = n.mountain[e];
		r.board.forest[e].animals = t ? {
			kind: t.kind,
			n: t.n
		} : void 0, t || delete r.board.forest[e].animals, r.board.mountain[e].animals = i ? {
			kind: i.kind,
			n: i.n
		} : void 0, i || delete r.board.mountain[e].animals;
		let a = n.dogs[e];
		a > 0 ? r.board.forest[e].dogs = a : delete r.board.forest[e].dogs;
	}
	r.dogsHome = n.dogsHome;
	let c = !0;
	for (let e of Object.keys(s)) s[e] = I(r.board, r, e), s[e] !== i[e] && (c = !1);
	return c && Oe(r.board, G(r)) && (c = !1), c ? { state: e } : (r.board = a, r.dogsHome = o, J("games.caverna.errBadLayout"));
}
function jt(e, t, n) {
	let r = e.pending.findIndex((e) => e.rid === t);
	if (r < 0) return J("games.caverna.errNotWaiting");
	let i = e.pending[r], a = e.players[H(e, t)];
	switch (i.kind) {
		case "harvestChoice": return n.choice !== "field" && n.choice !== "breed" ? J("games.caverna.errBadPayload") : (e.harvestChoice[t] = n.choice, e.pending.splice(r, 1), e.pending.some((e) => e.kind === "harvestChoice") || (tt(e, e.players.filter((t) => e.harvestChoice[t.rid] === "field")), nt(e, "normal")), { state: e });
		case "rubyKeep": {
			let t = n.keep ?? [];
			if (a.goods.ruby < t.length) return J("games.caverna.errCantAfford");
			for (let n of e.board) Object.values(n.goods).reduce((e, t) => e + (t ?? 0), 0) <= 6 || (t.includes(n.id) ? a.goods.ruby-- : n.goods = {});
			return e.pending.splice(r, 1), { state: e };
		}
	}
	return J("games.caverna.errBadPayload");
}
function Mt(e, t, n) {
	if (e.phase !== "feeding" || !e.feedingWaiting.includes(t)) return J("games.caverna.errNotWaiting");
	let r = e.players[H(e, t)], i = +!!U(r, "slaughteringCave"), a = rt(r, e.feedMode), o = Math.min(r.goods.food, a);
	r.goods.food -= o;
	let s = (e, t) => {
		let n = Math.min(t ?? 0, r.goods[e]);
		r.goods[e] -= n, o += (ne[e] ?? 0) * n;
	};
	s("grain", n.grain), s("veg", n.veg), s("ruby", n.ruby);
	let c = (e, t) => {
		let n = Math.min(t ?? 0, I(r.board, r, e));
		n <= 0 || (je(r.board, r, e, n, G(r)), o += (e === "donkey" ? re(n) : (ne[e] ?? 0) * n) + i * n);
	};
	if (c("sheep", n.sheep), c("boar", n.boar), c("cattle", n.cattle), c("donkey", n.donkey), n.buyFood && n.buyFood > 0) {
		let e = ie(n.buyFood);
		r.goods.gold >= e && (r.goods.gold -= e, o += n.buyFood);
	}
	if (n.workingCave && U(r, "workingCave")) {
		let e = n.workingCave === "ore" ? { ore: 2 } : { [n.workingCave]: 1 };
		qe(r, e) && (W(r, e), o += 2);
	}
	let l = a - o;
	return l > 0 && (r.begging += l), e.feedingWaiting = e.feedingWaiting.filter((e) => e !== t), e.feedingWaiting.length === 0 && it(e), { state: e };
}
function Nt(e, t, n) {
	if (e.phase !== "preScore" || !e.preScoreWaiting.includes(t)) return J("games.caverna.errNotWaiting");
	let r = e.players[H(e, t)], i = n.n ?? 1;
	switch (n.op) {
		case "hunting": return U(r, "huntingParlor") ? I(r.board, r, "boar") < 2 * i ? J("games.caverna.errCantAfford") : (je(r.board, r, "boar", 2 * i, G(r)), K(e, r, {
			gold: 2 * i,
			food: 2 * i
		}), { state: e }) : J("games.caverna.errBadPayload");
		case "beerGold": return !U(r, "beerParlor") || r.goods.grain < 2 * i ? J("games.caverna.errCantAfford") : (r.goods.grain -= 2 * i, r.goods.gold += 3 * i, { state: e });
		case "beerFood": return !U(r, "beerParlor") || r.goods.grain < 2 * i ? J("games.caverna.errCantAfford") : (r.goods.grain -= 2 * i, r.goods.food += 4 * i, { state: e });
		case "trader": return !U(r, "trader") || r.goods.gold < 2 * i ? J("games.caverna.errCantAfford") : (r.goods.gold -= 2 * i, Je(r, {
			wood: i,
			stone: i,
			ore: i
		}), { state: e });
		case "spareParts": {
			if (!U(r, "sparePartStorage")) return J("games.caverna.errBadPayload");
			let t = {
				wood: i,
				stone: i,
				ore: i
			};
			return qe(r, t) ? (W(r, t), r.goods.gold += 2 * i, { state: e }) : J("games.caverna.errCantAfford");
		}
		case "smithParlor": return !U(r, "blacksmithingParlor") || r.goods.ruby < i || r.goods.ore < i ? J("games.caverna.errCantAfford") : (r.goods.ruby -= i, r.goods.ore -= i, K(e, r, {
			gold: 2 * i,
			food: i
		}), { state: e });
		case void 0: return e.preScoreWaiting = e.preScoreWaiting.filter((e) => e !== t), e.preScoreWaiting.length === 0 && Ft(e), { state: e };
	}
	return J("games.caverna.errBadPayload");
}
function Pt(e, t) {
	let n = 0, r = 0, i = {
		dog: 0,
		sheep: 0,
		donkey: 0,
		boar: 0,
		cattle: 0
	};
	for (let e of Object.keys(i)) i[e] = I(t.board, t, e);
	for (let e of S) r += i[e];
	n += i.dog + r;
	let a = L(t.board) * -A.unusedCell;
	for (let e of S) i[e] === 0 && (a += -A.missingAnimal);
	a += t.begging * -A.begging, U(t, "writingChamber") && (a = Math.max(0, a - 7));
	let o = t.goods.grain, s = t.goods.veg;
	for (let e of t.board.forest) e.t === "field" && e.crop && e.cropN && (e.crop === "grain" ? o += e.cropN : s += e.cropN);
	n += Math.ceil(o / 2) + s + t.goods.ruby + t.dwarfs.length + t.goods.gold;
	let c = /* @__PURE__ */ new Map();
	for (let e of t.board.forest) e.t === "pasture" && e.pastureId !== void 0 && c.set(e.pastureId, (c.get(e.pastureId) ?? 0) + 1);
	for (let e of c.values()) n += e === 1 ? A.smallPasture : A.largePasture;
	for (let e of t.board.mountain) e.t === "oreMine" && (n += A.oreMine), e.t === "rubyMine" && (n += A.rubyMine);
	for (let e of t.furnishings) n += j[e].vp;
	if (U(t, "weavingParlor") && (n += Math.floor(i.sheep / 2)), U(t, "milkingParlor") && (n += i.cattle), U(t, "stateParlor")) {
		let e = t.board.mountain.findIndex((e) => e.furnishing === "stateParlor");
		n += Math.min(16, 4 * mt(t, e));
	}
	return U(t, "stoneStorage") && (n += t.goods.stone), U(t, "oreStorage") && (n += Math.floor(t.goods.ore / 2)), U(t, "mainStorage") && (n += 2 * t.furnishings.filter((e) => ye.includes(j[e].cat)).length), U(t, "weaponStorage") && (n += 3 * t.dwarfs.filter((e) => e.weapon > 0).length), U(t, "suppliesStorage") && t.dwarfs.every((e) => e.weapon > 0) && (n += 8), U(t, "broomChamber") && (n += t.dwarfs.length >= 6 ? 10 : t.dwarfs.length >= 5 ? 5 : 0), U(t, "treasureChamber") && (n += t.goods.ruby), U(t, "foodChamber") && (n += 2 * Math.min(t.goods.grain, t.goods.veg)), U(t, "prayerChamber") && t.dwarfs.every((e) => e.weapon === 0) && (n += 8), U(t, "fodderChamber") && (n += Math.floor(r / 3)), n -= a, n;
}
function Ft(e) {
	e.phase = "done";
	let t = {};
	for (let n of e.players) t[n.rid] = Pt(e, n);
	e.scores = t, e.lastEvent = null;
}
function It(e, t, n) {
	if (!e.players.some((e) => e.rid === n.by)) return J("games.caverna.errNotYourTurn");
	let r = structuredClone(e);
	switch (t.type) {
		case "place": return Dt(r, n.by, t.space, t.payload);
		case "convert": return kt(r, n.by, t);
		case "moveAnimals": return At(r, n.by, t);
		case "resolve": return jt(r, n.by, t);
		case "confirmFeeding": return Mt(r, n.by, t);
		case "preScore": return Nt(r, n.by, t);
	}
	return J("games.caverna.errBadPayload");
}
function Lt(e) {
	let t = le(e.players.length), n = t[Math.min(e.roundIdx, t.length - 1)], r = {};
	for (let i of t.filter((e) => e >= 6)) r[String(i)] = i <= n ? e.harvestMarks[i] ?? null : null;
	return {
		public: {
			round: n,
			rounds: t,
			phase: e.phase === "work" && e.pending.length > 0 ? "resolve" : e.phase,
			roundOrder: [...e.roundOrder],
			harvestMarks: r,
			spaces: e.board.map((e) => ({
				id: e.id,
				goods: { ...e.goods },
				by: [...e.by]
			})),
			startPlayer: e.players[e.startPlayer].rid,
			active: e.phase === "work" && e.pending.length === 0 ? e.players[e.active].rid : null,
			players: e.players.map((e) => ({
				rid: e.rid,
				dwarfs: e.dwarfs.map((e) => ({ weapon: e.weapon })),
				newborn: e.dwarfs.filter((e) => e.baby).length,
				placed: [...e.placed],
				goods: { ...e.goods },
				forest: e.board.forest.map((e) => ({
					t: e.t,
					stable: e.stable || void 0,
					crop: e.crop ?? null,
					cropN: e.cropN,
					animals: e.animals ? { ...e.animals } : void 0,
					dogs: e.dogs || void 0,
					pastureId: e.pastureId
				})),
				mountain: e.board.mountain.map((e) => ({
					t: e.t,
					furnishing: e.furnishing,
					animals: e.animals ? { ...e.animals } : void 0
				})),
				dogsHome: e.dogsHome,
				stables: e.board.stables,
				hasLandscape: e.board.hasLandscape,
				furnishings: [...e.furnishings],
				begging: e.begging
			})),
			pending: e.pending.map((e) => ({
				rid: e.rid,
				kind: e.kind
			})),
			feedingWaiting: [...e.feedingWaiting],
			feedMode: e.phase === "feeding" ? e.feedMode : null,
			preScoreWaiting: [...e.preScoreWaiting],
			furnishingsTaken: { ...e.furnishingsTaken },
			lastEvent: e.lastEvent
		},
		private: {}
	};
}
function Rt(e) {
	if (e.phase !== "done" || !e.scores) return { phase: e.phase };
	let t = e.scores, n = [...e.players].sort((e, n) => t[n.rid] - t[e.rid]).map((e) => e.rid), r = t[n[0]];
	return {
		phase: "done",
		winner: n.filter((e) => t[e] === r),
		ranking: n,
		scores: t
	};
}
var zt = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: R,
	schemas: {
		action: Le,
		publicView: Ue,
		privateView: We
	},
	setup: Ye,
	reduce: It,
	viewFor: Lt,
	status: Rt
}, X = "#b45309", Bt = {
	wood: "🪵",
	stone: "🪨",
	ore: "⬛",
	ruby: "♦️",
	gold: "🪙",
	food: "🍖",
	grain: "🌾",
	veg: "🥕"
}, Vt = {
	dog: "🐕",
	sheep: "🐑",
	donkey: "🫏",
	boar: "🐗",
	cattle: "🐄"
}, Ht = (e) => e in Bt ? Bt[e] : Vt[e], Ut = {
	wood: "games.caverna.goods.wood",
	stone: "games.caverna.goods.stone",
	ore: "games.caverna.goods.ore",
	ruby: "games.caverna.goods.ruby",
	gold: "games.caverna.goods.gold",
	food: "games.caverna.goods.food",
	grain: "games.caverna.goods.grain",
	veg: "games.caverna.goods.veg"
}, Wt = {
	dog: "games.caverna.animals.dog",
	sheep: "games.caverna.animals.sheep",
	donkey: "games.caverna.animals.donkey",
	boar: "games.caverna.animals.boar",
	cattle: "games.caverna.animals.cattle"
}, Gt = {
	leaf: "games.caverna.harvestLeaf",
	q1: "games.caverna.harvestNone",
	q2: "games.caverna.harvestHalf",
	q3: "games.caverna.harvestQ3"
}, Kt = {
	leaf: "🌾",
	q1: "🚫",
	q2: "½🍖",
	q3: "❓"
}, qt = {
	dwelling: "games.caverna.catDwelling",
	special: "games.caverna.catSpecial",
	craft: "games.caverna.catCraft",
	food: "games.caverna.catFood",
	parlor: "games.caverna.catParlor",
	storage: "games.caverna.catStorage"
}, Jt = [
	"dwelling",
	"special",
	"craft",
	"food",
	"parlor",
	"storage"
], Z = "cv-chip inline-flex items-center gap-0.5 rounded-lg border-2 border-ink bg-surface px-1.5 py-0.5 text-xs font-bold", Q = "cv-chip inline-flex items-center gap-0.5 rounded-lg border-2 border-ink bg-ink px-1.5 py-0.5 text-xs font-bold text-white", $ = "btn-base min-h-11 flex-1 border-ink text-white", Yt = "btn-quiet min-h-11", Xt = (e) => ({
	space: e,
	dwarf: 0,
	mtnAFace: "cavern",
	mtnBOver: !1,
	mtnBCavern: !1,
	forMeadowOver: !1,
	forFieldOver: !1,
	sow: [],
	pastureLarge: [],
	loot: [],
	loot2: [],
	lootLargePasture: [],
	lootSow: [],
	lootBreed: [],
	oreMineCells: [],
	market: []
}), Zt = [
	"imitation",
	"imitation3",
	"imitation5a",
	"imitation5b",
	"imitation6a",
	"imitation6b",
	"imitation7a",
	"imitation7b",
	"imitation7c"
], Qt = {
	logging: 1,
	hardwareRental: 2,
	blacksmithing: 3,
	oreMineConstruction: 2,
	exploration: 4
}, $t = {
	stable: "lootStable",
	tunnel: "lootTunnel",
	cavern: "lootCavern",
	smallPasture1w: "lootPasture",
	largePasture2w: "lootLargePasture",
	meadow: "lootMeadow",
	field: "lootField"
};
function en(e) {
	return /* @__PURE__ */ g(tn, {
		pub: e.public,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function tn({ pub: e, members: t, myRid: n, send: i }) {
	let s = c(), m = a(null), ee = a(null), [v, te] = o("board"), [y, b] = o(null), [x, S] = o(null), [C, T] = o(null), [ae, oe] = o({}), [E, se] = o(1), [ce, le] = o("meadow"), [ue, D] = o(null), [O, pe] = o({}), [k, me] = o(null), [he, ge] = o([]), [A, ye] = o(1), [M, N] = o(null), P = `${e.phase}|${e.round}|${e.active}|${e.pending.length}|${e.feedingWaiting.join(",")}|${e.preScoreWaiting.join(",")}`, [xe, Ce] = o(P);
	xe !== P && (Ce(P), b(null), S(null), T(null), oe({}), se(1), D(null), pe({}), me(null), ge([]), ye(1), N(null)), r(() => {
		let e = ee.current;
		e && getComputedStyle(e).position === "static" && e.parentElement?.scrollTo({ top: e.offsetTop });
	}, [
		y?.space,
		C,
		P
	]);
	let Te = () => {
		ee.current && getComputedStyle(ee.current).position === "static" && m.current?.parentElement?.scrollTo({ top: 0 });
	}, F = e.players.find((e) => e.rid === n);
	if (!F) return null;
	let Ee = (e) => t.find((t) => t.rid === e)?.name ?? e, De = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? l[n.colorIndex % l.length].hex : "#57534e";
	}, ke = e.phase === "work" && e.active === n, Ae = e.pending.find((e) => e.rid === n) ?? null, je = e.phase === "feeding" && e.feedingWaiting.includes(n), I = e.phase === "preScore" && e.preScoreWaiting.includes(n), L = (e) => F.furnishings.includes(e), R = (e) => {
		i(e), b(null), S(null), T(null);
	}, Me = () => ({
		forest: F.forest,
		mountain: F.mountain,
		stables: F.stables,
		nextPastureId: 1,
		hasLandscape: F.hasLandscape
	}), z = F.dwarfs.map((e, t) => t).filter((e) => !F.placed.includes(e)).sort((e, t) => F.dwarfs[e].weapon - F.dwarfs[t].weapon), Ne = z[Math.min(y?.dwarf ?? 0, Math.max(0, z.length - 1))], B = y && Ne !== void 0 ? F.dwarfs[Ne].weapon : 0, Pe = !!y && y.dwarf > 0, Fe = B > 0 ? B : y?.forge ?? 0, Ie = e.spaces.some((e) => e.id === "familyLife"), V = (e) => (e === "dog" ? F.dogsHome : 0) + F.forest.reduce((t, n) => t + (n.animals?.kind === e ? n.animals.n : 0) + (e === "dog" ? n.dogs ?? 0 : 0), 0) + (e === "dog" ? 0 : F.mountain.reduce((t, n) => t + (n.animals?.kind === e ? n.animals.n : 0), 0)), Le = (e) => {
		let t = C === "rubyTile" ? "convTileCell" : x;
		if (!t) return null;
		let n = Me(), r = new Set(Array.from({ length: 12 }, (e, t) => t).filter((e) => Se(n, e))), i = new Set(F.mountain.map((e, t) => ({
			c: e,
			i: t
		})).filter(({ c: e }) => !e.furnishing && (e.t === "cavern" || L("workRoom") && (e.t === "tunnel" || e.t === "deepTunnel"))).map(({ i: e }) => e)), a = (e) => new Set(F.forest.map((e, t) => ({
			c: e,
			i: t
		})).filter(({ c: t, i: n }) => e(t.t, n)).map(({ i: e }) => e)), o = a((e, t) => we(n, t, "meadow") && e === "forest"), s = a((e, t) => we(n, t, "field") && e === "forest"), c = a((e) => e === "meadow"), l = a((e, t) => (e === "forest" || e === "meadow" || e === "pasture") && !F.forest[t].stable), u = a((e, t) => e === "field" && !F.forest[t].crop), d = new Set(F.mountain.map((e, t) => ({
			c: e,
			i: t
		})).filter(({ c: e }) => e.t === "tunnel").map(({ i: e }) => e)), f = new Set(F.mountain.map((e, t) => ({
			c: e,
			i: t
		})).filter(({ c: e }) => (e.t === "tunnel" || e.t === "deepTunnel") && !e.furnishing).map(({ i: e }) => e));
		switch (t) {
			case "mtnA": return e === "m" ? r : null;
			case "mtnB": return e === "m" && y?.mtnA !== void 0 ? new Set([...r].filter((e) => be(e, y.mtnA))) : null;
			case "lootTunnel":
			case "lootCavern":
			case "buyTunnel": return e === "m" ? r : null;
			case "furnishCell":
			case "lootFurnishCell": return e === "m" ? i : null;
			case "oreMine": return e === "m" ? y && y.oreMineCells.length === 1 ? new Set([...d].filter((e) => be(e, y.oreMineCells[0]))) : d : null;
			case "rubyMine": return e === "m" ? f : null;
			case "forMeadow":
			case "lootMeadow": return e === "f" ? o : null;
			case "forField":
			case "lootField": return e === "f" ? s : null;
			case "pastureSmall":
			case "lootPasture": return e === "f" ? c : null;
			case "pastureLarge":
			case "lootLargePasture": {
				if (e !== "f") return null;
				let n = t === "pastureLarge" ? y?.pastureLarge : y?.lootLargePasture;
				return n && n.length === 1 ? new Set([...c].filter((e) => be(e, n[0]))) : c;
			}
			case "stable":
			case "lootStable": return e === "f" ? l : null;
			case "sow":
			case "lootSow": return e === "f" ? u : null;
			case "convTileCell": return ce === "tunnel" || ce === "cavern" ? e === "m" ? r : null : e === "f" ? ce === "meadow" ? o : s : null;
			case "rubyTileCell": {
				let t = y?.rubyTileT;
				return t ? t === "tunnel" || t === "cavern" ? e === "m" ? r : null : e === "f" ? t === "meadow" ? o : s : null : null;
			}
		}
		return null;
	}, Re = (e, t, n) => {
		let r = e.find((e) => e.cell === t);
		if (r) r.crop === "grain" && e.filter((e) => e.crop === "veg").length < 2 ? n(e.map((e) => e.cell === t ? {
			...e,
			crop: "veg"
		} : e)) : n(e.filter((e) => e.cell !== t));
		else {
			let r = e.filter((e) => e.crop === "grain").length, i = e.length - r, a = r < 2 && (F.goods.grain ?? 0) > r ? "grain" : i < 2 && (F.goods.veg ?? 0) > i ? "veg" : r < 2 ? "grain" : "veg";
			n([...e, {
				cell: t,
				crop: a
			}]);
		}
	}, ze = (e, t) => {
		if (M) return He(e, t);
		if (C === "rubyTile") {
			Le(e)?.has(t) && D(t);
			return;
		}
		if (!x || !y || !Le(e)?.has(t)) return;
		let n = (e) => b({
			...y,
			...e
		});
		switch (x) {
			case "mtnA":
				n({
					mtnA: t,
					mtnB: y.mtnB !== void 0 && be(t, y.mtnB) ? y.mtnB : void 0
				});
				break;
			case "mtnB":
				n({ mtnB: t });
				break;
			case "lootTunnel":
				n({ lootTunnel: t });
				break;
			case "lootCavern":
				n({ lootCavern: t });
				break;
			case "buyTunnel":
				n({ buyTunnel: t });
				break;
			case "furnishCell":
				n({ furnishCell: t });
				break;
			case "lootFurnishCell":
				n({ lootFurnishCell: t });
				break;
			case "oreMine": {
				let e = y.oreMineCells.includes(t) ? y.oreMineCells.filter((e) => e !== t) : [...y.oreMineCells, t].slice(-2);
				n({
					oreMineCells: e,
					oreMineAt: y.oreMineAt !== void 0 && e.includes(y.oreMineAt) ? y.oreMineAt : void 0
				});
				break;
			}
			case "rubyMine":
				n({ rubyMine: t });
				break;
			case "forMeadow":
				n({ forMeadow: t });
				break;
			case "forField":
				n({ forField: t });
				break;
			case "lootMeadow":
				n({ lootMeadow: t });
				break;
			case "lootField":
				n({ lootField: t });
				break;
			case "pastureSmall":
				n({ pastureSmall: y.pastureSmall === t ? void 0 : t });
				break;
			case "lootPasture":
				n({ lootPasture: y.lootPasture === t ? void 0 : t });
				break;
			case "pastureLarge":
				n({ pastureLarge: y.pastureLarge.includes(t) ? y.pastureLarge.filter((e) => e !== t) : [...y.pastureLarge, t].slice(-2) });
				break;
			case "lootLargePasture":
				n({ lootLargePasture: y.lootLargePasture.includes(t) ? y.lootLargePasture.filter((e) => e !== t) : [...y.lootLargePasture, t].slice(-2) });
				break;
			case "stable":
				n({ stable: y.stable === t ? void 0 : t });
				break;
			case "lootStable":
				n({ lootStable: y.lootStable === t ? void 0 : t });
				break;
			case "sow":
				Re(y.sow, t, (e) => n({ sow: e }));
				break;
			case "lootSow":
				Re(y.lootSow, t, (e) => n({ lootSow: e }));
				break;
			case "rubyTileCell": n({ rubyTileCell: t });
		}
		[
			"oreMine",
			"pastureLarge",
			"lootLargePasture",
			"sow",
			"lootSow"
		].includes(x) || S(null);
	}, Be = () => N({
		forest: F.forest.map((e) => e.animals ? {
			kind: e.animals.kind,
			n: e.animals.n
		} : null),
		mountain: F.mountain.map((e) => e.animals ? {
			kind: e.animals.kind,
			n: e.animals.n
		} : null),
		dogs: F.forest.map((e) => e.dogs ?? 0),
		dogsHome: F.dogsHome,
		sel: null
	}), Ve = M ? Oe(M ? {
		forest: F.forest.map((e, t) => ({
			...e,
			animals: M.forest[t] ?? void 0,
			dogs: M.dogs[t] || void 0
		})),
		mountain: F.mountain.map((e, t) => ({
			...e,
			animals: M.mountain[t] ?? void 0
		})),
		stables: F.stables,
		nextPastureId: 1,
		hasLandscape: F.hasLandscape
	} : null, {
		hasStubbleRoom: L("stubbleRoom"),
		dwarfCount: F.dwarfs.length
	}) : !1, He = (e, t) => {
		if (!M) return;
		let n = e === "f" ? M.forest : M.mountain;
		if (!M.sel) {
			(n[t] || e === "f" && M.dogs[t] > 0) && N({
				...M,
				sel: {
					side: e,
					i: t
				}
			});
			return;
		}
		let r = M.sel;
		if (r.side === e && r.i === t) {
			N({
				...M,
				sel: null
			});
			return;
		}
		let i = (r.side === "f" ? M.forest : M.mountain)[r.i], a = n[t], o = [...M.forest], s = [...M.mountain], c = (e, t, n) => e === "f" ? o[t] = n : s[t] = n;
		i && a && i.kind === a.kind ? (c(r.side, r.i, null), c(e, t, {
			kind: a.kind,
			n: i.n + a.n
		})) : (c(r.side, r.i, a ? { ...a } : null), c(e, t, i ? { ...i } : null)), N({
			...M,
			forest: o,
			mountain: s,
			sel: null
		});
	}, Ue = (e, t) => {
		if (!M) return;
		let n = [...M.dogs];
		t === 1 && M.dogsHome > 0 ? (n[e]++, N({
			...M,
			dogs: n,
			dogsHome: M.dogsHome - 1
		})) : t === -1 && n[e] > 0 && (n[e]--, N({
			...M,
			dogs: n,
			dogsHome: M.dogsHome + 1
		}));
	}, We = (e) => {
		let t = {};
		e.dwarf > 0 && (t.dwarf = e.dwarf, t.useRuby = !0), e.mtnA !== void 0 && (e.mtnBOver || e.mtnB !== void 0) && (t.mtnTwin = e.mtnBOver ? {
			a: e.mtnA,
			aFace: e.mtnAFace
		} : {
			a: e.mtnA,
			b: e.mtnB,
			aFace: e.mtnAFace,
			bFace: e.mtnBCavern ? "cavern" : e.mtnAFace === "cavern" ? "tunnel" : "cavern"
		});
		let n = e.forMeadowOver ? void 0 : e.forMeadow, r = e.forFieldOver ? void 0 : e.forField;
		return (n !== void 0 || r !== void 0) && (t.forTwin = {
			meadow: n,
			field: r
		}), e.furnishFid && e.furnishCell !== void 0 && (t.furnish = {
			fid: e.furnishFid,
			cell: e.furnishCell
		}), e.sow.length > 0 && (t.sow = e.sow), e.pastureSmall !== void 0 && (t.pastureSmall = e.pastureSmall), e.pastureLarge.length === 2 && (t.pastureLarge = [e.pastureLarge[0], e.pastureLarge[1]]), e.stable !== void 0 && (t.stable = e.stable), e.forge !== void 0 && (t.forge = e.forge), e.loot.length > 0 && (t.loot = e.loot), e.loot2.length > 0 && (t.loot2 = e.loot2), e.lootFurnishFid && e.lootFurnishCell !== void 0 && (t.lootFurnish = {
			fid: e.lootFurnishFid,
			cell: e.lootFurnishCell
		}), e.lootStable !== void 0 && (t.lootStable = e.lootStable), e.lootTunnel !== void 0 && (t.lootTunnel = e.lootTunnel), e.lootPasture !== void 0 && (t.lootPasture = e.lootPasture), e.lootLargePasture.length === 2 && (t.lootLargePasture = [e.lootLargePasture[0], e.lootLargePasture[1]]), e.lootMeadow !== void 0 && (t.lootMeadow = e.lootMeadow), e.lootField !== void 0 && (t.lootField = e.lootField), e.lootCavern !== void 0 && (t.lootCavern = e.lootCavern), e.lootSow.length > 0 && (t.lootSow = e.lootSow), e.lootBreed.length > 0 && (t.lootBreed = e.lootBreed), e.oreMineCells.length === 2 && e.oreMineAt !== void 0 && (t.oreMine = {
			cells: [e.oreMineCells[0], e.oreMineCells[1]],
			mineAt: e.oreMineAt
		}), e.rubyMine !== void 0 && (t.rubyMine = e.rubyMine), e.buyTunnel !== void 0 && (t.buyTunnel = e.buyTunnel), e.oreTrades !== void 0 && (t.oreTrades = e.oreTrades), e.market.length > 0 && (t.market = e.market), e.imitate && (t.imitate = e.imitate), e.growthChoice && (t.growthChoice = e.growthChoice), e.wishChoice && (t.wishChoice = e.wishChoice), e.rubyTileT && e.rubyTileCell !== void 0 && (t.rubyTile = {
			t: e.rubyTileT,
			cell: e.rubyTileCell
		}), t;
	}, H = (e, t) => {
		for (let n of t) if (n === "furnish" && !(e.lootFurnishFid && e.lootFurnishCell !== void 0) || n === "dwelling2w2s" && e.lootFurnishCell === void 0 || n === "stable" && e.lootStable === void 0 || n === "tunnel" && e.lootTunnel === void 0 || n === "cavern" && e.lootCavern === void 0 || n === "smallPasture1w" && e.lootPasture === void 0 || n === "largePasture2w" && e.lootLargePasture.length < 2 || n === "meadow" && e.lootMeadow === void 0 || n === "field" && e.lootField === void 0 || n === "sow" && e.lootSow.length === 0 || n === "breed2" && e.lootBreed.length === 0) return !1;
		return !0;
	}, Ge = (e) => {
		if (z.length === 0 || e.dwarf > 0 && (F.goods.ruby ?? 0) < 1 || !H(e, e.loot) || !H(e, e.loot2)) return !1;
		let t = e.mtnA !== void 0 && !e.mtnBOver && e.mtnB === void 0, n = !e.forMeadowOver && !e.forFieldOver && e.forMeadow === void 0 != (e.forField === void 0);
		if (t || n) return !1;
		let r = e.space;
		if ((r === "blacksmithing" || r === "adventure") && B === 0 && e.forge === void 0) return !1;
		switch (r) {
			case "growth": return !!e.growthChoice;
			case "wishForChildren": return e.wishChoice ? e.wishChoice !== "dwelling" || e.furnishCell !== void 0 : !1;
			case "familyLife": return e.wishChoice === "grow" || e.sow.length > 0 || !!Ke(e);
			case "smallDriftMining": return !!We(e).mtnTwin;
			case "exploration": return B > 0;
			case "oreMineConstruction": return !!We(e).oreMine || B > 0 && e.loot.length > 0;
			case "rubyMineConstruction": return e.rubyMine !== void 0 || e.buyTunnel !== void 0;
			case "oreTrading": return !!e.oreTrades && (F.goods.ore ?? 0) >= 2 * e.oreTrades;
			case "weeklyMarket": return e.market.reduce((e, t) => e + (_e[t] ?? 0), 0) <= (F.goods.gold ?? 0) + 4;
			case "adventure": return !0;
			default: return !Zt.includes(r) || !!e.imitate && (F.goods.food ?? 0) >= (w[r].imitationCost ?? 0);
		}
	}, Ke = (e) => e.rubyTileT !== void 0 && e.rubyTileCell !== void 0, U = (e) => {
		if (y?.space === e) {
			b(null), S(null);
			return;
		}
		ke && (b(Xt(e)), S(null), T(null), [
			"driftMining",
			"driftMining2",
			"excavation",
			"smallDriftMining",
			"clearing",
			"sustenance",
			"slashAndBurn",
			"extension",
			"housework",
			"wishForChildren",
			"fenceBuilding",
			"sheepFarming",
			"donkeyFarming",
			"oreMineConstruction",
			"rubyMineConstruction",
			"familyLife",
			"hardwareRental"
		].includes(e) && te("home"));
	}, qe = (e) => Object.entries(e).map(([e, t]) => /* @__PURE__ */ _("span", {
		className: "inline-flex items-center gap-0.5 font-mono text-xs tabular-nums",
		children: [
			Ht(e),
			"×",
			t
		]
	}, e)), W = (e, t, n, r) => /* @__PURE__ */ _("button", {
		type: "button",
		className: (C === "rubyTile" ? "convTileCell" : x) === e ? Q : Z,
		onClick: () => {
			C !== "rubyTile" && (S(x === e ? null : e), te("home"), Te());
		},
		children: [t, n === void 0 ? "" : ` #${n + 1}`]
	}), Je = (e) => /* @__PURE__ */ g("button", {
		type: "button",
		className: Z,
		onClick: e,
		children: "✕"
	}), G = (t, n, r, i, a) => {
		if (!y) return null;
		let o = r;
		return /* @__PURE__ */ _("div", {
			className: "flex flex-col gap-1",
			children: [
				/* @__PURE__ */ _("span", {
					className: "text-xs font-bold",
					children: [
						s(a ? "games.caverna.secondExpedition" : "games.caverna.expeditionTitle"),
						" · 🗡️",
						n,
						" · ",
						s("games.caverna.lootPicked", {
							n: o.length,
							max: t
						})
					]
				}),
				/* @__PURE__ */ g("div", {
					className: "flex flex-wrap gap-1",
					children: de.filter((e) => e.min <= n).map((e) => {
						let n = o.includes(e.id);
						return /* @__PURE__ */ g("button", {
							type: "button",
							className: n ? Q : Z,
							onClick: () => i(n ? o.filter((t) => t !== e.id) : o.length < t ? [...o, e.id] : o),
							children: s(fe[e.id])
						}, e.id);
					})
				}),
				!a && o.some((e) => $t[e] || e === "furnish" || e === "dwelling2w2s" || e === "sow" || e === "breed2") && /* @__PURE__ */ _("div", {
					className: "flex flex-wrap items-center gap-1",
					children: [
						o.includes("furnish") && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ _("select", {
							className: Z,
							value: y.lootFurnishFid ?? "",
							onChange: (e) => b({
								...y,
								lootFurnishFid: e.target.value || void 0
							}),
							children: [/* @__PURE__ */ g("option", {
								value: "",
								children: s("games.caverna.buildFurnish")
							}), ve.filter((t) => t !== "dwelling" && !e.furnishingsTaken[t]).map((e) => /* @__PURE__ */ g("option", {
								value: e,
								children: s(j[e].nameKey)
							}, e))]
						}), W("lootFurnishCell", s("games.caverna.furnPickCell"), y.lootFurnishCell, "m")] }),
						o.includes("dwelling2w2s") && W("lootFurnishCell", s("games.caverna.furnishings.dwelling"), y.lootFurnishCell, "m"),
						o.includes("stable") && W("lootStable", s("games.caverna.stableLabel"), y.lootStable, "f"),
						o.includes("tunnel") && W("lootTunnel", s("games.caverna.faceTunnel"), y.lootTunnel, "m"),
						o.includes("cavern") && W("lootCavern", s("games.caverna.faceCavern"), y.lootCavern, "m"),
						o.includes("smallPasture1w") && W("lootPasture", s("games.caverna.pastureSmallLabel"), y.lootPasture, "f"),
						o.includes("largePasture2w") && W("lootLargePasture", s("games.caverna.pastureLargeLabel"), void 0, "f"),
						o.includes("largePasture2w") && y.lootLargePasture.length > 0 && /* @__PURE__ */ g("span", {
							className: Z,
							children: y.lootLargePasture.map((e) => `#${e + 1}`).join(" ")
						}),
						o.includes("meadow") && W("lootMeadow", s("games.caverna.faceMeadow"), y.lootMeadow, "f"),
						o.includes("field") && W("lootField", s("games.caverna.faceField"), y.lootField, "f"),
						o.includes("sow") && /* @__PURE__ */ _(h, { children: [W("lootSow", s("games.caverna.sowTitle"), void 0, "f"), y.lootSow.length > 0 && /* @__PURE__ */ g("span", {
							className: Z,
							children: y.lootSow.map((e) => `${e.crop === "grain" ? "🌾" : "🥕"}#${e.cell + 1}`).join(" ")
						})] }),
						o.includes("breed2") && /* @__PURE__ */ g("span", {
							className: "flex items-center gap-1",
							children: [
								"sheep",
								"donkey",
								"boar",
								"cattle"
							].map((e) => /* @__PURE__ */ g("button", {
								type: "button",
								className: y.lootBreed.includes(e) ? Q : Z,
								onClick: () => b({
									...y,
									lootBreed: y.lootBreed.includes(e) ? y.lootBreed.filter((t) => t !== e) : y.lootBreed.length < 2 ? [...y.lootBreed, e] : y.lootBreed
								}),
								children: Vt[e]
							}, e))
						})
					]
				})
			]
		});
	}, K = (t) => {
		if (!y) return null;
		let r = y, i = (e) => b({
			...r,
			...e
		}), a = Qt[t] !== void 0 && (B > 0 || ((e) => (e === "blacksmithing" || e === "adventure") && B === 0)(t)), o = /* @__PURE__ */ _("div", {
			className: "flex flex-wrap items-center gap-1",
			children: [
				/* @__PURE__ */ g("span", {
					className: "section-label",
					children: s("games.caverna.twinMtn")
				}),
				W("mtnA", s("games.caverna.slotA"), r.mtnA, "m"),
				/* @__PURE__ */ g("button", {
					type: "button",
					className: Z,
					onClick: () => i({ mtnAFace: r.mtnAFace === "cavern" ? "tunnel" : "cavern" }),
					children: r.mtnAFace === "cavern" ? s("games.caverna.faceCavern") : s("games.caverna.faceTunnel")
				}),
				r.mtnBOver ? /* @__PURE__ */ g("span", {
					className: Z,
					children: s("games.caverna.overhangB")
				}) : /* @__PURE__ */ _(h, { children: [W("mtnB", s("games.caverna.slotB"), r.mtnB, "m"), t === "excavation" ? /* @__PURE__ */ g("button", {
					type: "button",
					className: Z,
					onClick: () => i({ mtnBCavern: !r.mtnBCavern }),
					children: r.mtnBCavern ? s("games.caverna.faceCavern") : r.mtnAFace === "cavern" ? s("games.caverna.faceTunnel") : s("games.caverna.faceCavern")
				}) : /* @__PURE__ */ g("span", {
					className: Z,
					children: r.mtnAFace === "cavern" ? s("games.caverna.faceTunnel") : s("games.caverna.faceCavern")
				})] }),
				L("officeRoom") && /* @__PURE__ */ g("button", {
					type: "button",
					className: r.mtnBOver ? Q : Z,
					onClick: () => i({
						mtnBOver: !r.mtnBOver,
						mtnB: void 0
					}),
					children: s("games.caverna.overhangB")
				}),
				(r.mtnA !== void 0 || r.mtnB !== void 0) && Je(() => i({
					mtnA: void 0,
					mtnB: void 0
				}))
			]
		}), c = /* @__PURE__ */ _("div", {
			className: "flex flex-wrap items-center gap-1",
			children: [
				/* @__PURE__ */ g("span", {
					className: "section-label",
					children: s("games.caverna.twinFor")
				}),
				r.forMeadowOver ? /* @__PURE__ */ g("span", {
					className: Z,
					children: s("games.caverna.overhangMeadow")
				}) : W("forMeadow", s("games.caverna.slotMeadow"), r.forMeadow, "f"),
				r.forFieldOver ? /* @__PURE__ */ g("span", {
					className: Z,
					children: s("games.caverna.overhangField")
				}) : W("forField", s("games.caverna.slotField"), r.forField, "f"),
				L("officeRoom") && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("button", {
					type: "button",
					className: r.forMeadowOver ? Q : Z,
					onClick: () => i({
						forMeadowOver: !r.forMeadowOver,
						forMeadow: void 0
					}),
					children: s("games.caverna.overhangMeadow")
				}), /* @__PURE__ */ g("button", {
					type: "button",
					className: r.forFieldOver ? Q : Z,
					onClick: () => i({
						forFieldOver: !r.forFieldOver,
						forField: void 0
					}),
					children: s("games.caverna.overhangField")
				})] }),
				(r.forMeadow !== void 0 || r.forField !== void 0) && Je(() => i({
					forMeadow: void 0,
					forField: void 0
				}))
			]
		}), l = /* @__PURE__ */ _("div", {
			className: "flex flex-wrap items-center gap-1",
			children: [
				/* @__PURE__ */ g("span", {
					className: "section-label",
					children: s("games.caverna.sowTitle")
				}),
				W("sow", `${s("games.caverna.sowTitle")}`, void 0, "f"),
				r.sow.length > 0 && /* @__PURE__ */ g("span", {
					className: Z,
					children: r.sow.map((e) => `${e.crop === "grain" ? "🌾" : "🥕"}#${e.cell + 1}`).join(" ")
				}),
				r.sow.length > 0 && Je(() => i({ sow: [] }))
			]
		}), u = /* @__PURE__ */ _("div", {
			className: "flex flex-wrap items-center gap-1",
			children: [
				W("pastureSmall", s("games.caverna.pastureSmallLabel"), r.pastureSmall, "f"),
				W("pastureLarge", s("games.caverna.pastureLargeLabel"), void 0, "f"),
				r.pastureLarge.length > 0 && /* @__PURE__ */ g("span", {
					className: Z,
					children: r.pastureLarge.map((e) => `#${e + 1}`).join(" ")
				})
			]
		}), d = /* @__PURE__ */ g("div", {
			className: "flex flex-wrap items-center gap-1",
			children: W("stable", s("games.caverna.stableLabel"), r.stable, "f")
		}), f = /* @__PURE__ */ _("div", {
			className: "flex flex-wrap items-center gap-1",
			children: [
				/* @__PURE__ */ g("span", {
					className: "section-label",
					children: s("games.caverna.rubyTile")
				}),
				[
					"field",
					"meadow",
					"tunnel",
					"cavern"
				].map((e) => /* @__PURE__ */ _("button", {
					type: "button",
					className: r.rubyTileT === e ? Q : Z,
					onClick: () => i({
						rubyTileT: e,
						rubyTileCell: void 0
					}),
					children: [s(e === "field" ? "games.caverna.faceField" : e === "meadow" ? "games.caverna.faceMeadow" : e === "tunnel" ? "games.caverna.faceTunnel" : "games.caverna.faceCavern"), e === "cavern" ? " ♦️2" : " ♦️1"]
				}, e)),
				r.rubyTileT && W("rubyTileCell", "#", r.rubyTileCell, r.rubyTileT === "tunnel" || r.rubyTileT === "cavern" ? "m" : "f")
			]
		}), p = (t) => /* @__PURE__ */ _("div", {
			className: "flex flex-col gap-1",
			children: [!t && /* @__PURE__ */ _("select", {
				className: Z,
				value: r.furnishFid ?? "",
				onChange: (e) => i({ furnishFid: e.target.value || void 0 }),
				children: [/* @__PURE__ */ g("option", {
					value: "",
					children: s("games.caverna.buildFurnish")
				}), ve.filter((t) => j[t].unlimited || !e.furnishingsTaken[t]).map((e) => /* @__PURE__ */ _("option", {
					value: e,
					children: [
						s(j[e].nameKey),
						" · ",
						Object.entries(j[e].cost).map(([e, t]) => `${Ht(e)}${t}`).join("")
					]
				}, e))]
			}), /* @__PURE__ */ g("div", {
				className: "flex flex-wrap items-center gap-1",
				children: W("furnishCell", s(t ? "games.caverna.furnishings.dwelling" : "games.caverna.furnPickCell"), r.furnishCell, "m")
			})]
		}), m = /* @__PURE__ */ _("div", {
			className: "flex flex-wrap items-center gap-1",
			children: [
				/* @__PURE__ */ g("span", {
					className: "section-label",
					children: s("games.caverna.forgeTitle")
				}),
				Array.from({ length: 8 }, (e, t) => t + 1).map((e) => {
					let t = Math.max(0, e - (L("blacksmith") ? 2 : 0)), n = (F.goods.ore ?? 0) >= t;
					return /* @__PURE__ */ g("button", {
						type: "button",
						disabled: !n,
						className: `${r.forge === e ? Q : Z} disabled:opacity-40`,
						onClick: () => i({ forge: e }),
						children: e
					}, e);
				}),
				r.forge !== void 0 && /* @__PURE__ */ g("span", {
					className: Z,
					children: s("games.caverna.forgeCost", {
						n: r.forge,
						cost: Math.max(0, r.forge - (L("blacksmith") ? 2 : 0))
					})
				})
			]
		});
		switch (t) {
			case "driftMining":
			case "driftMining2":
			case "excavation":
			case "smallDriftMining": return o;
			case "clearing":
			case "sustenance": return c;
			case "slashAndBurn": return /* @__PURE__ */ _(h, { children: [
				c,
				l,
				f
			] });
			case "extension": return /* @__PURE__ */ _(h, { children: [c, o] });
			case "housework": return p(!1);
			case "wishForChildren": return /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("div", {
				className: "flex flex-wrap gap-1",
				children: (Ie ? [["dwelling", "games.caverna.wishDwelling"], ["gold", "games.caverna.wishGold"]] : [["grow", "games.caverna.wishGrow"], ["dwelling", "games.caverna.wishDwelling"]]).map(([e, t]) => /* @__PURE__ */ g("button", {
					type: "button",
					className: r.wishChoice === e ? Q : Z,
					onClick: () => i({
						wishChoice: e,
						furnishFid: e === "dwelling" ? "dwelling" : void 0
					}),
					children: s(t)
				}, e))
			}), r.wishChoice === "dwelling" && p(!0)] });
			case "familyLife": return /* @__PURE__ */ _(h, { children: [
				/* @__PURE__ */ g("div", {
					className: "flex flex-wrap gap-1",
					children: /* @__PURE__ */ g("button", {
						type: "button",
						className: r.wishChoice === "grow" ? Q : Z,
						onClick: () => i({ wishChoice: r.wishChoice === "grow" ? void 0 : "grow" }),
						children: s("games.caverna.wishGrow")
					})
				}),
				l,
				f
			] });
			case "growth": return /* @__PURE__ */ g("div", {
				className: "flex flex-wrap gap-1",
				children: ["goods", "grow"].map((e) => /* @__PURE__ */ g("button", {
					type: "button",
					className: r.growthChoice === e ? Q : Z,
					onClick: () => i({ growthChoice: e }),
					children: s(e === "goods" ? "games.caverna.growthGoods" : "games.caverna.growthGrow")
				}, e))
			});
			case "fenceBuilding":
			case "sheepFarming":
			case "donkeyFarming": return /* @__PURE__ */ _(h, { children: [u, t !== "fenceBuilding" && d] });
			case "hardwareRental": return /* @__PURE__ */ _(h, { children: [
				a && G(2, Fe, r.loot, (e) => i({ loot: e }), !1),
				l,
				f
			] });
			case "logging":
			case "exploration": return a ? G(Qt[t], Fe, r.loot, (e) => i({ loot: e }), !1) : null;
			case "blacksmithing": return /* @__PURE__ */ _(h, { children: [B === 0 && m, G(3, Fe, r.loot, (e) => i({ loot: e }), !1)] });
			case "adventure": return /* @__PURE__ */ _(h, { children: [
				B === 0 && m,
				G(1, Fe, r.loot, (e) => i({ loot: e }), !1),
				G(1, Fe + 1, r.loot2, (e) => i({ loot2: e }), !0)
			] });
			case "oreMineConstruction": return /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ _("div", {
				className: "flex flex-wrap items-center gap-1",
				children: [
					/* @__PURE__ */ g("span", {
						className: "section-label",
						children: s("games.caverna.oreMineTitle")
					}),
					W("oreMine", "⛏️", void 0, "m"),
					r.oreMineCells.length > 0 && /* @__PURE__ */ g("span", {
						className: "flex items-center gap-1",
						children: r.oreMineCells.map((e) => /* @__PURE__ */ _("button", {
							type: "button",
							className: r.oreMineAt === e ? Q : Z,
							onClick: () => i({ oreMineAt: e }),
							children: [
								"#",
								e + 1,
								" ",
								s("games.caverna.mineAtLabel")
							]
						}, e))
					})
				]
			}), a && G(2, Fe, r.loot, (e) => i({ loot: e }), !1)] });
			case "rubyMineConstruction": return /* @__PURE__ */ _("div", {
				className: "flex flex-wrap items-center gap-1",
				children: [W("rubyMine", s("games.caverna.rubyMineLabel"), r.rubyMine, "m"), (F.goods.ruby ?? 0) >= 1 && W("buyTunnel", s("games.caverna.buyTunnelLabel"), r.buyTunnel, "m")]
			});
			case "oreTrading": return /* @__PURE__ */ _("div", {
				className: "flex flex-wrap items-center gap-1",
				children: [/* @__PURE__ */ g("span", {
					className: "section-label",
					children: s("games.caverna.oreTradesLabel")
				}), [
					1,
					2,
					3
				].map((e) => /* @__PURE__ */ _("button", {
					type: "button",
					disabled: (F.goods.ore ?? 0) < 2 * e,
					className: `${r.oreTrades === e ? Q : Z} disabled:opacity-40`,
					onClick: () => i({ oreTrades: e }),
					children: [e, "×(⬛2→🪙2🍖1)"]
				}, e))]
			});
			case "weeklyMarket": {
				let e = r.market.reduce((e, t) => e + (_e[t] ?? 0), 0);
				return /* @__PURE__ */ _("div", {
					className: "flex flex-col gap-1",
					children: [/* @__PURE__ */ _("span", {
						className: "section-label",
						children: [
							s("games.caverna.marketTitle"),
							" · ",
							s("games.caverna.marketCost", { n: e })
						]
					}), /* @__PURE__ */ g("div", {
						className: "flex flex-wrap gap-1",
						children: Object.keys(_e).map((e) => /* @__PURE__ */ _("button", {
							type: "button",
							className: r.market.includes(e) ? Q : Z,
							onClick: () => i({ market: r.market.includes(e) ? r.market.filter((t) => t !== e) : [...r.market, e] }),
							children: [
								Ht(e),
								" 🪙",
								_e[e]
							]
						}, e))
					})]
				});
			}
			default:
				if (Zt.includes(t)) {
					let i = w[t].imitationCost ?? 0, a = e.spaces.filter((e) => e.by.length > 0 && !e.by.includes(n) && !Zt.includes(e.id) && e.id !== "startingPlayer");
					return /* @__PURE__ */ _("div", {
						className: "flex flex-col gap-1",
						children: [
							/* @__PURE__ */ _("span", {
								className: "section-label",
								children: [
									s("games.caverna.imitateLabel"),
									" · 🍖",
									i
								]
							}),
							/* @__PURE__ */ g("div", {
								className: "flex flex-wrap gap-1",
								children: a.map((e) => /* @__PURE__ */ g("button", {
									type: "button",
									className: r.imitate === e.id ? Q : Z,
									onClick: () => b({
										...Xt(t),
										dwarf: r.dwarf,
										imitate: e.id
									}),
									children: s(w[e.id].nameKey)
								}, e.id))
							}),
							r.imitate && K(r.imitate)
						]
					});
				}
				return null;
		}
	}, q = +!!L("slaughteringCave"), J = (() => {
		let t = e.feedMode === "half" ? F.dwarfs.length : 2 * (F.dwarfs.length - F.newborn) + F.newborn;
		return L("miningCave") && (t -= F.mountain.filter((e) => e.t === "oreMine" && e.animals?.kind === "donkey").length), Math.max(0, t);
	})(), Ye = (() => {
		let e = Math.min(F.goods.food ?? 0, J);
		return e += (O.grain ?? 0) * 1 + (O.veg ?? 0) * 2 + (O.ruby ?? 0) * 2, e += (O.sheep ?? 0) * (1 + q) + (O.boar ?? 0) * (2 + q) + (O.cattle ?? 0) * (3 + q) + re(O.donkey ?? 0) + q * (O.donkey ?? 0), e += O.buyFood ?? 0, k && L("workingCave") && (e += 2), e;
	})(), Xe = Math.max(0, J - Ye), Y = (e, t, n, r) => /* @__PURE__ */ _("span", {
		className: "flex items-center gap-1",
		children: [
			/* @__PURE__ */ g("button", {
				type: "button",
				className: Z,
				onClick: () => pe((t) => ({
					...t,
					[e]: Math.max(0, (t[e] ?? 0) - 1)
				})),
				children: "−"
			}),
			/* @__PURE__ */ _("span", {
				className: "inline-flex items-center gap-0.5 font-mono text-sm tabular-nums",
				children: [
					t,
					"×",
					O[e] ?? 0,
					"/",
					n
				]
			}),
			/* @__PURE__ */ g("button", {
				type: "button",
				className: Z,
				onClick: () => pe((t) => ({
					...t,
					[e]: Math.min(n, (t[e] ?? 0) + 1)
				})),
				children: "+"
			}),
			/* @__PURE__ */ g("span", {
				className: "text-xs font-bold",
				children: r
			})
		]
	}, e), Ze = /* @__PURE__ */ _("div", {
		className: "frame flex flex-col gap-1.5 p-2",
		children: [
			/* @__PURE__ */ _("span", {
				className: "text-sm font-extrabold",
				children: [
					s("games.caverna.feedingTitle"),
					" · ",
					s("games.caverna.feedingNeed", { n: J }),
					e.feedMode === "half" ? ` · ${s("games.caverna.harvestHalf")}` : ""
				]
			}),
			/* @__PURE__ */ g("span", {
				className: "text-xs font-bold",
				children: s("games.caverna.feedingAuto")
			}),
			/* @__PURE__ */ _("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					Y("grain", "🌾", F.goods.grain ?? 0, "→🍖1"),
					Y("veg", "🥕", F.goods.veg ?? 0, "→🍖2"),
					Y("ruby", "♦️", F.goods.ruby ?? 0, "→🍖2"),
					V("sheep") > 0 && Y("sheep", "🐑", V("sheep"), `→🍖${1 + q}`),
					V("boar") > 0 && Y("boar", "🐗", V("boar"), `→🍖${2 + q}`),
					V("cattle") > 0 && Y("cattle", "🐄", V("cattle"), `→🍖${3 + q}`),
					V("donkey") > 0 && Y("donkey", "🫏", V("donkey"), ""),
					(F.goods.gold ?? 0) >= 2 && Y("buyFood", "🪙", Math.max(0, (F.goods.gold ?? 0) - 1), `${ie(O.buyFood ?? 0)}🪙`),
					L("workingCave") && /* @__PURE__ */ g("span", {
						className: "flex items-center gap-1",
						children: [
							"wood",
							"stone",
							"ore"
						].map((e) => /* @__PURE__ */ _("button", {
							type: "button",
							className: k === e ? Q : Z,
							onClick: () => me(k === e ? null : e),
							children: [
								Bt[e],
								e === "ore" ? "×2" : "",
								"→🍖2"
							]
						}, e))
					})
				]
			}),
			Xe > 0 && /* @__PURE__ */ _("span", {
				className: "text-xs font-bold text-rose-600",
				children: [
					s("games.caverna.feedShort", { n: Xe }),
					" · ",
					s("games.caverna.feedingBegging")
				]
			}),
			/* @__PURE__ */ _("button", {
				type: "button",
				className: $,
				style: { background: X },
				onClick: () => R({
					type: "confirmFeeding",
					grain: O.grain,
					veg: O.veg,
					ruby: O.ruby,
					sheep: O.sheep,
					boar: O.boar,
					cattle: O.cattle,
					donkey: O.donkey,
					buyFood: O.buyFood,
					workingCave: k ?? void 0
				}),
				children: [s("games.caverna.feedingConfirm"), Xe > 0 ? ` (🥺×${Xe})` : ""]
			})
		]
	}), Qe = Ae?.kind === "harvestChoice" ? /* @__PURE__ */ _("div", {
		className: "frame flex flex-col gap-1.5 p-2",
		children: [/* @__PURE__ */ g("span", {
			className: "text-sm font-extrabold",
			children: s("games.caverna.harvestChoiceTitle")
		}), /* @__PURE__ */ _("div", {
			className: "flex gap-1",
			children: [/* @__PURE__ */ _("button", {
				type: "button",
				className: $,
				style: { background: X },
				onClick: () => R({
					type: "resolve",
					choice: "field"
				}),
				children: ["🌾 ", s("games.caverna.chooseField")]
			}), /* @__PURE__ */ _("button", {
				type: "button",
				className: $,
				style: { background: X },
				onClick: () => R({
					type: "resolve",
					choice: "breed"
				}),
				children: ["🐑 ", s("games.caverna.chooseBreed")]
			})]
		})]
	}) : Ae?.kind === "rubyKeep" ? /* @__PURE__ */ _("div", {
		className: "frame flex flex-col gap-1.5 p-2",
		children: [
			/* @__PURE__ */ g("span", {
				className: "text-sm font-extrabold",
				children: s("games.caverna.rubyKeepTitle")
			}),
			/* @__PURE__ */ g("div", {
				className: "flex flex-wrap gap-1",
				children: e.spaces.filter((e) => Object.values(e.goods ?? {}).reduce((e, t) => e + (t ?? 0), 0) > 6).map((e) => /* @__PURE__ */ _("button", {
					type: "button",
					className: he.includes(e.id) ? Q : Z,
					onClick: () => ge(he.includes(e.id) ? he.filter((t) => t !== e.id) : [...he, e.id]),
					children: [s(w[e.id].nameKey), " ♦️1"]
				}, e.id))
			}),
			/* @__PURE__ */ g("button", {
				type: "button",
				className: $,
				style: { background: X },
				disabled: he.length > (F.goods.ruby ?? 0),
				onClick: () => R({
					type: "resolve",
					keep: he
				}),
				children: s("games.caverna.submit")
			})
		]
	}) : null, $e = [
		{
			op: "hunting",
			fid: "huntingParlor",
			key: "games.caverna.preScoreHunting",
			max: Math.floor(V("boar") / 2)
		},
		{
			op: "beerGold",
			fid: "beerParlor",
			key: "games.caverna.preScoreBeerGold",
			max: Math.floor((F.goods.grain ?? 0) / 2)
		},
		{
			op: "beerFood",
			fid: "beerParlor",
			key: "games.caverna.preScoreBeerFood",
			max: Math.floor((F.goods.grain ?? 0) / 2)
		},
		{
			op: "trader",
			fid: "trader",
			key: "games.caverna.preScoreTrader",
			max: Math.floor((F.goods.gold ?? 0) / 2)
		},
		{
			op: "spareParts",
			fid: "sparePartStorage",
			key: "games.caverna.preScoreSpareParts",
			max: Math.min(F.goods.wood ?? 0, F.goods.stone ?? 0, F.goods.ore ?? 0)
		},
		{
			op: "smithParlor",
			fid: "blacksmithingParlor",
			key: "games.caverna.preScoreSmithParlor",
			max: Math.min(F.goods.ruby ?? 0, F.goods.ore ?? 0)
		}
	], et = /* @__PURE__ */ _("div", {
		className: "frame flex flex-col gap-1.5 p-2",
		children: [
			/* @__PURE__ */ g("span", {
				className: "text-sm font-extrabold",
				children: s("games.caverna.preScoreTitle")
			}),
			$e.filter((e) => L(e.fid) && e.max > 0).map((e) => /* @__PURE__ */ _("div", {
				className: "flex items-center gap-1",
				children: [
					/* @__PURE__ */ g("span", {
						className: "flex-1 text-xs font-bold",
						children: s(e.key)
					}),
					/* @__PURE__ */ g("button", {
						type: "button",
						className: Z,
						onClick: () => ye(Math.max(1, A - 1)),
						children: "−"
					}),
					/* @__PURE__ */ _("span", {
						className: "font-mono text-sm tabular-nums",
						children: ["×", Math.min(A, e.max)]
					}),
					/* @__PURE__ */ g("button", {
						type: "button",
						className: Z,
						onClick: () => ye(Math.min(e.max, A + 1)),
						children: "+"
					}),
					/* @__PURE__ */ g("button", {
						type: "button",
						className: Z,
						onClick: () => i({
							type: "preScore",
							op: e.op,
							n: Math.min(A, e.max)
						}),
						children: s("games.caverna.convertNow")
					})
				]
			}, e.op)),
			/* @__PURE__ */ g("button", {
				type: "button",
				className: $,
				style: { background: X },
				onClick: () => R({ type: "preScore" }),
				children: s("games.caverna.preScoreDone")
			})
		]
	}), tt = (e, t, n) => {
		if (t === "m") {
			let t = e.mountain[n], r = [];
			return t.furnishing === "entryDwelling" ? r.push(/* @__PURE__ */ g("span", {
				className: "text-[10px] leading-none",
				children: "🏠"
			}, "f")) : t.furnishing && r.push(/* @__PURE__ */ g("span", {
				className: "max-w-full truncate text-[8px] font-bold leading-none",
				children: s(j[t.furnishing].nameKey)
			}, "f")), t.animals && r.push(/* @__PURE__ */ _("span", {
				className: "font-mono text-[9px] leading-none tabular-nums",
				children: [Vt[t.animals.kind], t.animals.n > 1 ? `×${t.animals.n}` : ""]
			}, "a")), r;
		}
		let r = e.forest[n], i = [];
		return r.crop && i.push(/* @__PURE__ */ _("span", {
			className: "font-mono text-[9px] leading-none tabular-nums",
			children: [r.crop === "grain" ? "🌾" : "🥕", r.cropN ?? ""]
		}, "c")), r.animals && i.push(/* @__PURE__ */ _("span", {
			className: "font-mono text-[9px] leading-none tabular-nums",
			children: [Vt[r.animals.kind], r.animals.n > 1 ? `×${r.animals.n}` : ""]
		}, "a")), r.dogs && i.push(/* @__PURE__ */ _("span", {
			className: "font-mono text-[9px] leading-none tabular-nums",
			children: ["🐕", r.dogs > 1 ? `×${r.dogs}` : ""]
		}, "d")), r.stable && i.push(/* @__PURE__ */ g("span", {
			className: "text-[9px] leading-none",
			children: "🛖"
		}, "s")), i;
	}, nt = {
		rock: "bg-stone-700",
		cavern: "bg-amber-900",
		tunnel: "bg-amber-700",
		deepTunnel: "bg-amber-950",
		oreMine: "bg-stone-500",
		rubyMine: "bg-rose-700"
	}, rt = {
		forest: "bg-emerald-800",
		meadow: "bg-lime-300",
		field: "bg-amber-300",
		pasture: "bg-lime-500"
	}, it = (e, t, n) => {
		let r = n ? Le(t) : null;
		return /* @__PURE__ */ g("div", {
			className: "cv-home-grid grid flex-1 grid-cols-3 gap-0.5",
			children: Array.from({ length: 12 }, (i, a) => {
				let o = M?.sel?.side === t && M.sel.i === a, s = !!y && (t === "m" && [
					y.mtnA,
					y.mtnB,
					y.furnishCell,
					y.lootFurnishCell,
					y.lootTunnel,
					y.lootCavern,
					y.buyTunnel,
					y.rubyMine,
					...y.oreMineCells
				].includes(a) || t === "f" && [
					y.forMeadow,
					y.forField,
					y.pastureSmall,
					y.stable,
					y.lootPasture,
					y.lootMeadow,
					y.lootField,
					y.lootStable,
					...y.pastureLarge,
					...y.lootLargePasture
				].includes(a)), c = C === "rubyTile" && ue === a && (ce === "tunnel" || ce === "cavern") == (t === "m"), l = y && t === "f" ? [...y.sow, ...y.lootSow].find((e) => e.cell === a) : void 0, u = t === "m" ? nt[e.mountain[a].t] : rt[e.forest[a].t], d = t === "f" && e.forest[a].t !== "forest";
				return /* @__PURE__ */ _("button", {
					type: "button",
					disabled: !n,
					onClick: () => ze(t, a),
					className: `cv-home-cell relative flex aspect-square flex-col items-center justify-center gap-0 overflow-hidden rounded-md border-2 ${u} ${o || s || c ? "border-sky-400 outline-2 outline-sky-300" : r?.has(a) ? "border-sky-300" : "border-ink/40"} ${d ? "text-ink" : "text-white"} ${e.forest[a]?.pastureId !== void 0 && t === "f" ? "border-dashed" : ""}`,
					children: [
						t === "m" && e.mountain[a].t === "rock" && /* @__PURE__ */ g("span", {
							className: "text-[10px] opacity-40",
							children: "⛰"
						}),
						t === "m" && (e.mountain[a].t === "oreMine" || e.mountain[a].t === "rubyMine") && /* @__PURE__ */ g("span", {
							className: "text-[10px] leading-none",
							children: e.mountain[a].t === "oreMine" ? "⬛" : "♦️"
						}),
						t === "m" && (e.mountain[a].t === "tunnel" || e.mountain[a].t === "deepTunnel") && /* @__PURE__ */ g("span", {
							className: "text-[10px] leading-none",
							children: e.mountain[a].t === "tunnel" ? "🕳" : "🕳️"
						}),
						tt(e, t, a),
						l && /* @__PURE__ */ _("span", {
							className: "absolute top-0 right-0 text-[8px]",
							children: [l.crop === "grain" ? "🌾" : "🥕", "+"]
						})
					]
				}, a);
			})
		});
	}, at = (e) => /* @__PURE__ */ _("div", {
		className: "flex flex-wrap gap-1",
		children: [Object.keys(Bt).map((t) => /* @__PURE__ */ _("span", {
			className: Z,
			title: s(Ut[t]),
			children: [Bt[t], /* @__PURE__ */ g("span", {
				className: "font-mono tabular-nums",
				children: e.goods[t] ?? 0
			})]
		}, t)), e.begging > 0 && /* @__PURE__ */ _("span", {
			className: Z,
			children: ["🥺", /* @__PURE__ */ g("span", {
				className: "font-mono tabular-nums",
				children: e.begging
			})]
		})]
	}), ot = (e) => /* @__PURE__ */ _("span", {
		className: "inline-flex items-center gap-0.5",
		children: [e.dwarfs.map((e, t) => /* @__PURE__ */ _("span", {
			className: "font-mono text-xs tabular-nums",
			children: ["👷", e.weapon > 0 ? `🗡️${e.weapon}` : ""]
		}, t)), e.newborn > 0 && /* @__PURE__ */ _("span", {
			className: "text-[10px] font-bold",
			children: ["🍼", s("games.caverna.babyMark")]
		})]
	}), st = C === "food" ? /* @__PURE__ */ _("div", {
		className: "frame flex flex-col gap-1.5 p-2",
		children: [
			/* @__PURE__ */ g("span", {
				className: "text-sm font-extrabold",
				children: s("games.caverna.convertFood")
			}),
			/* @__PURE__ */ g("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					"grain",
					"veg",
					"ruby",
					"sheep",
					"boar",
					"cattle",
					"donkey"
				].map((e) => {
					let t = e === "grain" || e === "veg" || e === "ruby" ? F.goods[e] ?? 0 : V(e);
					if (t <= 0) return null;
					let n = e === "grain" || e === "veg" || e === "ruby" ? Bt[e] : Vt[e], r = e === "donkey" ? "" : `→🍖${(ne[e] ?? 0) + (e === "grain" || e === "veg" || e === "ruby" ? 0 : q)}`;
					return /* @__PURE__ */ _("span", {
						className: "flex items-center gap-1",
						children: [
							/* @__PURE__ */ g("button", {
								type: "button",
								className: Z,
								onClick: () => oe((t) => ({
									...t,
									[e]: Math.max(0, (t[e] ?? 0) - 1)
								})),
								children: "−"
							}),
							/* @__PURE__ */ _("span", {
								className: "inline-flex items-center gap-0.5 font-mono text-sm tabular-nums",
								children: [
									n,
									"×",
									ae[e] ?? 0,
									"/",
									t
								]
							}),
							/* @__PURE__ */ g("button", {
								type: "button",
								className: Z,
								onClick: () => oe((n) => ({
									...n,
									[e]: Math.min(t, (n[e] ?? 0) + 1)
								})),
								children: "+"
							}),
							/* @__PURE__ */ g("span", {
								className: "text-xs font-bold",
								children: r
							})
						]
					}, e);
				})
			}),
			/* @__PURE__ */ _("button", {
				type: "button",
				className: $,
				style: { background: X },
				disabled: Object.values(ae).every((e) => !e),
				onClick: () => {
					let e = Object.fromEntries(Object.entries(ae).filter(([, e]) => e > 0));
					R({
						type: "convert",
						kind: "food",
						food: e
					});
				},
				children: [
					s("games.caverna.convertNow"),
					" → 🍖",
					Object.entries(ae).reduce((e, [t, n]) => e + (t === "donkey" ? re(n) : n * (ne[t] ?? 0)) + ([
						"sheep",
						"boar",
						"cattle",
						"donkey"
					].includes(t) ? q * n : 0), 0)
				]
			})
		]
	}) : C === "buyFood" ? /* @__PURE__ */ _("div", {
		className: "frame flex flex-col gap-1.5 p-2",
		children: [/* @__PURE__ */ g("span", {
			className: "text-sm font-extrabold",
			children: s("games.caverna.buyFood")
		}), /* @__PURE__ */ _("div", {
			className: "flex items-center gap-1",
			children: [
				/* @__PURE__ */ g("button", {
					type: "button",
					className: Z,
					onClick: () => se(Math.max(1, E - 1)),
					children: "−"
				}),
				/* @__PURE__ */ g("span", {
					className: "font-mono text-sm tabular-nums",
					children: E
				}),
				/* @__PURE__ */ g("button", {
					type: "button",
					className: Z,
					onClick: () => se(Math.min(Math.max(1, (F.goods.gold ?? 0) - 1), E + 1)),
					children: "+"
				}),
				/* @__PURE__ */ g("button", {
					type: "button",
					className: $,
					style: { background: X },
					disabled: (F.goods.gold ?? 0) < ie(E),
					onClick: () => R({
						type: "convert",
						kind: "buyFood",
						n: E
					}),
					children: s("games.caverna.buyFoodN", {
						n: E,
						cost: ie(E)
					})
				})
			]
		})]
	}) : C === "ruby" ? /* @__PURE__ */ _("div", {
		className: "frame flex flex-col gap-1.5 p-2",
		children: [/* @__PURE__ */ g("span", {
			className: "text-sm font-extrabold",
			children: s("games.caverna.rubyPickTarget")
		}), /* @__PURE__ */ g("div", {
			className: "flex flex-wrap gap-1",
			children: [
				"wood",
				"stone",
				"ore",
				"gold",
				"grain",
				"veg",
				"sheep",
				"donkey",
				"boar",
				"cattle",
				"dog"
			].map((e) => /* @__PURE__ */ _("button", {
				type: "button",
				disabled: e === "cattle" && (F.goods.food ?? 0) < 1,
				className: `${Z} disabled:opacity-40`,
				onClick: () => R({
					type: "convert",
					kind: "ruby",
					to: e
				}),
				children: [
					Ht(e),
					" ",
					s(e in Bt ? Ut[e] : Wt[e]),
					e === "cattle" ? " +🍖1" : ""
				]
			}, e))
		})]
	}) : C === "rubyTile" ? /* @__PURE__ */ _("div", {
		className: "frame flex flex-col gap-1.5 p-2",
		children: [/* @__PURE__ */ g("span", {
			className: "text-sm font-extrabold",
			children: s("games.caverna.rubyTile")
		}), /* @__PURE__ */ _("div", {
			className: "flex flex-wrap items-center gap-1",
			children: [
				[
					"meadow",
					"field",
					"tunnel",
					"cavern"
				].map((e) => /* @__PURE__ */ _("button", {
					type: "button",
					disabled: (F.goods.ruby ?? 0) < (e === "cavern" ? 2 : 1),
					className: `${ce === e ? Q : Z} disabled:opacity-40`,
					onClick: () => {
						le(e), D(null), te("home"), Te();
					},
					children: [s(e === "meadow" ? "games.caverna.faceMeadow" : e === "field" ? "games.caverna.faceField" : e === "tunnel" ? "games.caverna.faceTunnel" : "games.caverna.faceCavern"), e === "cavern" ? " ♦️2" : " ♦️1"]
				}, e)),
				ue !== null && /* @__PURE__ */ _("span", {
					className: Z,
					children: ["#", ue + 1]
				}),
				/* @__PURE__ */ g("button", {
					type: "button",
					className: $,
					style: { background: X },
					disabled: ue === null,
					onClick: () => R({
						type: "convert",
						kind: "rubyTile",
						tile: {
							t: ce,
							cell: ue
						}
					}),
					children: s("games.caverna.submit")
				})
			]
		})]
	}) : C === "peaceful" ? /* @__PURE__ */ _("div", {
		className: "frame flex flex-col gap-1.5 p-2",
		children: [/* @__PURE__ */ g("span", {
			className: "text-sm font-extrabold",
			children: s("games.caverna.peacefulPick")
		}), /* @__PURE__ */ g("div", {
			className: "flex flex-wrap gap-1",
			children: F.dwarfs.map((e, t) => e.weapon > 0 ? /* @__PURE__ */ _("button", {
				type: "button",
				className: Z,
				onClick: () => R({
					type: "convert",
					kind: "peaceful",
					dwarf: t
				}),
				children: [
					"👷🗡️",
					e.weapon,
					" → 🍖",
					e.weapon
				]
			}, t) : null)
		})]
	}) : C === "cookingCave" ? /* @__PURE__ */ _("div", {
		className: "frame flex flex-col gap-1.5 p-2",
		children: [/* @__PURE__ */ g("span", {
			className: "text-sm font-extrabold",
			children: s("games.caverna.cookingCave")
		}), /* @__PURE__ */ _("div", {
			className: "flex items-center gap-1",
			children: [
				/* @__PURE__ */ g("button", {
					type: "button",
					className: Z,
					onClick: () => se(Math.max(1, E - 1)),
					children: "−"
				}),
				/* @__PURE__ */ g("span", {
					className: "font-mono text-sm tabular-nums",
					children: E
				}),
				/* @__PURE__ */ g("button", {
					type: "button",
					className: Z,
					onClick: () => se(Math.min(Math.min(F.goods.grain ?? 0, F.goods.veg ?? 0), E + 1)),
					children: "+"
				}),
				/* @__PURE__ */ _("button", {
					type: "button",
					className: $,
					style: { background: X },
					disabled: (F.goods.grain ?? 0) < E || (F.goods.veg ?? 0) < E,
					onClick: () => R({
						type: "convert",
						kind: "cookingCave",
						n: E
					}),
					children: [
						s("games.caverna.convertNow"),
						" → 🍖",
						E * 5
					]
				})
			]
		})]
	}) : null, ct = (t) => e.players.length === 1 ? t >= 5 ? "leaf" : null : t === 3 || t === 5 ? "leaf" : t === 4 ? "q2" : t < 6 ? null : e.harvestMarks[String(t)] ?? "unknown", lt = e.phase === "done" ? "done" : je || I || Ae ? "warn" : ke ? "accent" : "info", ut = e.phase === "work" ? s("games.caverna.phaseWork") : e.phase === "resolve" ? s("games.caverna.phaseResolve") : e.phase === "feeding" ? s("games.caverna.phaseFeeding") : s("games.caverna.phasePreScore"), dt = ke ? `${ut} · ${s("games.caverna.myTurn")}` : e.phase === "work" ? `${ut} · ${s("games.caverna.waiting", { name: Ee(e.active ?? "") })}` : ut, ft = ct(e.round), pt = (e, t) => /* @__PURE__ */ g("button", {
		type: "button",
		onClick: () => te(e),
		"data-tab": e,
		className: `btn-quiet min-h-11 flex-1 text-sm ${v === e ? "bg-ink text-white" : ""}`,
		children: t
	}, e), mt = Ae ? Qe : je ? Ze : I ? et : C ? st : y ? /* @__PURE__ */ _("div", {
		className: "frame flex flex-col gap-1.5 p-2",
		children: [
			/* @__PURE__ */ _("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ g("span", {
					className: "flex-1 text-sm font-extrabold",
					children: s(w[y.space].nameKey)
				}), /* @__PURE__ */ g("button", {
					type: "button",
					className: Z,
					onClick: () => {
						b(null), S(null);
					},
					children: s("games.caverna.cancel")
				})]
			}),
			/* @__PURE__ */ g("span", {
				className: "text-xs text-ink/70",
				children: s(w[y.space].descKey)
			}),
			z.length > 1 && /* @__PURE__ */ g("div", {
				className: "flex flex-wrap items-center gap-1",
				children: z.map((e, t) => {
					let n = F.dwarfs[e], r = t > 0, i = r && (F.goods.ruby ?? 0) < 1, a = y.space === "exploration";
					return /* @__PURE__ */ _("button", {
						type: "button",
						disabled: i || a && n.weapon === 0,
						className: `${y.dwarf === t ? Q : Z} disabled:opacity-40`,
						onClick: () => b({
							...y,
							dwarf: t
						}),
						children: [
							"👷",
							n.weapon > 0 ? `🗡️${n.weapon}` : s("games.caverna.weaponShort") + 0,
							r ? " ♦️1" : ""
						]
					}, e);
				})
			}),
			K(y.space),
			/* @__PURE__ */ _("button", {
				type: "button",
				className: `${$} disabled:opacity-40`,
				style: { background: X },
				disabled: !Ge(y),
				onClick: () => R({
					type: "place",
					space: y.space,
					payload: We(y)
				}),
				children: [s("games.caverna.submit"), Pe ? " · ♦️-1" : ""]
			})
		]
	}) : null, ht = /* @__PURE__ */ _("div", {
		className: "cv-board-panel flex flex-col gap-2 pb-2",
		children: [/* @__PURE__ */ g("div", {
			className: "flex flex-wrap gap-1",
			children: e.rounds.map((t) => {
				let n = ct(t);
				return /* @__PURE__ */ _("span", {
					className: `${t === e.round ? Q : Z} font-mono tabular-nums`,
					title: n ? s(n === "unknown" ? "games.caverna.harvestUnknown" : Gt[n]) : void 0,
					children: [t, n === "unknown" ? "❓" : n ? Kt[n] : ""]
				}, t);
			})
		}), /* @__PURE__ */ g("div", {
			className: "cv-spaces grid grid-cols-2 gap-2",
			children: e.spaces.map((e) => {
				let t = e.by.length > 0;
				return /* @__PURE__ */ _("button", {
					type: "button",
					onClick: () => t && !(ke && Zt.includes(e.id)) ? void 0 : U(e.id),
					className: `cv-space card flex min-h-16 flex-col items-start gap-0.5 p-2 text-left ${y?.space === e.id ? "outline-3 outline-sky-500" : ""} ${t ? "opacity-60" : ""}`,
					children: [/* @__PURE__ */ g("span", {
						className: "text-sm font-extrabold",
						children: s(w[e.id].nameKey)
					}), /* @__PURE__ */ _("span", {
						className: "flex flex-wrap gap-1",
						children: [qe(e.goods), e.by.map((e) => /* @__PURE__ */ g("span", {
							className: "rounded-full border-2 border-ink px-1 text-[10px] font-bold text-white",
							style: { background: De(e) },
							children: Ee(e)
						}, e))]
					})]
				}, e.id);
			})
		})]
	}), gt = /* @__PURE__ */ _("div", {
		ref: m,
		className: "cv-home-panel flex flex-col gap-2 pb-2",
		children: [
			at(F),
			/* @__PURE__ */ _("div", {
				className: "flex flex-wrap items-center gap-1",
				children: [ot(F), /* @__PURE__ */ _("span", {
					className: Z,
					children: [
						s("games.caverna.dogsHome"),
						" 🐕",
						F.dogsHome,
						" · ",
						s("games.caverna.stablesLeft"),
						" ",
						F.stables,
						"/",
						3
					]
				})]
			}),
			/* @__PURE__ */ _("div", {
				className: "cv-homestead flex gap-1.5",
				children: [/* @__PURE__ */ _("div", {
					className: "flex flex-1 flex-col gap-0.5",
					children: [/* @__PURE__ */ g("span", {
						className: "section-label",
						children: s("games.caverna.mtnSide")
					}), it(F, "m", !0)]
				}), /* @__PURE__ */ _("div", {
					className: "flex flex-1 flex-col gap-0.5",
					children: [/* @__PURE__ */ g("span", {
						className: "section-label",
						children: s("games.caverna.forSide")
					}), it(F, "f", !0)]
				})]
			}),
			/* @__PURE__ */ g("span", {
				className: "text-xs text-ink/70",
				children: s("games.caverna.animalsNeedHome")
			}),
			M ? /* @__PURE__ */ _("div", {
				className: "frame flex flex-col gap-1 p-2",
				children: [
					/* @__PURE__ */ g("span", {
						className: "text-xs font-bold",
						children: s("games.caverna.moveAnimalsHint")
					}),
					M.sel && M.sel.side === "f" && ["meadow", "pasture"].includes(F.forest[M.sel.i].t) && /* @__PURE__ */ _("span", {
						className: "flex items-center gap-1",
						children: [
							/* @__PURE__ */ g("button", {
								type: "button",
								className: Z,
								onClick: () => Ue(M.sel.i, -1),
								children: "−🐕"
							}),
							/* @__PURE__ */ _("span", {
								className: "font-mono text-xs tabular-nums",
								children: [
									"🐕×",
									M.dogs[M.sel.i],
									" · ",
									s("games.caverna.dogHomeShort"),
									" ",
									M.dogsHome
								]
							}),
							/* @__PURE__ */ g("button", {
								type: "button",
								className: Z,
								onClick: () => Ue(M.sel.i, 1),
								children: "+🐕"
							})
						]
					}),
					Ve && /* @__PURE__ */ g("span", {
						className: "text-xs font-bold text-rose-600",
						children: s("games.caverna.errBadLayout")
					}),
					/* @__PURE__ */ _("div", {
						className: "flex gap-1",
						children: [/* @__PURE__ */ g("button", {
							type: "button",
							className: `${$} disabled:opacity-40`,
							style: { background: X },
							disabled: Ve,
							onClick: () => {
								R({
									type: "moveAnimals",
									forest: M.forest,
									mountain: M.mountain,
									dogs: M.dogs,
									dogsHome: M.dogsHome
								}), N(null);
							},
							children: s("games.caverna.moveSubmit")
						}), /* @__PURE__ */ g("button", {
							type: "button",
							className: Yt,
							onClick: () => N(null),
							children: s("games.caverna.cancel")
						})]
					})
				]
			}) : /* @__PURE__ */ g("button", {
				type: "button",
				className: Yt,
				onClick: Be,
				children: s("games.caverna.moveAnimals")
			}),
			F.furnishings.length > 0 && /* @__PURE__ */ _("div", {
				className: "flex flex-col gap-1",
				children: [/* @__PURE__ */ g("span", {
					className: "section-label",
					children: s("games.caverna.furnishingsMine")
				}), /* @__PURE__ */ g("div", {
					className: "flex flex-wrap gap-1",
					children: F.furnishings.map((e) => /* @__PURE__ */ g("span", {
						className: Z,
						title: s(j[e].descKey),
						children: s(j[e].nameKey)
					}, e))
				})]
			})
		]
	}), _t = /* @__PURE__ */ g("div", {
		className: "cv-furn-panel flex flex-col gap-2 pb-2",
		children: Jt.map((t) => /* @__PURE__ */ _("div", {
			className: "flex flex-col gap-1",
			children: [/* @__PURE__ */ g("span", {
				className: "section-label",
				children: s(qt[t])
			}), ve.filter((e) => j[e].cat === t).map((t) => {
				let n = j[t], r = e.furnishingsTaken[t], i = F.furnishings.includes(t);
				return /* @__PURE__ */ _("div", {
					className: `cv-furnishing plate flex items-center gap-2 p-1.5 ${r && !i ? "opacity-50" : ""}`,
					children: [
						/* @__PURE__ */ _("span", {
							className: "flex-1 text-xs font-extrabold",
							children: [
								s(n.nameKey),
								n.vp > 0 ? ` · ${s("games.caverna.scorePts", { n: n.vp })}` : "",
								i ? " ✓" : r ? ` · ${s("games.caverna.takenBy", { name: Ee(r) })}` : ""
							]
						}),
						/* @__PURE__ */ g("span", {
							className: "flex gap-0.5 font-mono text-xs tabular-nums",
							children: Object.entries(n.cost).map(([e, t]) => /* @__PURE__ */ _("span", { children: [
								Ht(e),
								"×",
								t
							] }, e))
						}),
						/* @__PURE__ */ g("span", {
							className: "w-2/5 text-[10px] text-ink/70",
							children: s(n.descKey)
						})
					]
				}, t);
			})]
		}, t))
	});
	return /* @__PURE__ */ g("div", {
		className: "cv-screen safe-x safe-b",
		children: /* @__PURE__ */ g(d, {
			adaptive: !0,
			scroll: !1,
			className: "cv-adaptive",
			banner: /* @__PURE__ */ _("div", {
				className: "cv-banner",
				children: [/* @__PURE__ */ g(f, {
					tone: lt,
					accent: X,
					chip: `${s("games.caverna.round", { n: e.round })}/${e.rounds.length}${ft ? ` ${Kt[ft === "unknown" ? "q3" : ft]}` : ""}`,
					text: dt,
					sub: e.lastEvent ? `${s("games.caverna.revealedEvent")}: ${s(w[e.lastEvent].nameKey)}` : void 0
				}), /* @__PURE__ */ g("div", {
					className: "cv-seats",
					children: /* @__PURE__ */ g(p, {
						members: t,
						myRid: n,
						variant: "plate",
						status: (t) => {
							let n = e.players.find((e) => e.rid === t);
							return n ? /* @__PURE__ */ _("span", {
								className: "inline-flex items-center gap-0.5 font-mono text-xs tabular-nums",
								children: [
									"🍖",
									n.goods.food ?? 0,
									" · 👷",
									n.dwarfs.length - n.placed.length,
									"/",
									n.dwarfs.length,
									t === e.startPlayer ? " · 👑" : ""
								]
							}) : null;
						},
						action: (t) => e.phase === "work" ? e.active === t ? "pending" : null : e.phase === "feeding" ? e.feedingWaiting.includes(t) ? "pending" : "done" : e.phase === "preScore" ? e.preScoreWaiting.includes(t) ? "pending" : "done" : null
					})
				})]
			}),
			actionsHeight: "cv-actions-height",
			actions: /* @__PURE__ */ _("div", {
				className: "cv-actions flex h-full min-w-0 items-center gap-2",
				children: [/* @__PURE__ */ g("span", {
					className: "flex-1 text-sm font-bold",
					children: e.phase === "work" ? ke ? s(y ? w[y.space].nameKey : "games.caverna.pickSpace") : s("games.caverna.waiting", { name: Ee(e.active ?? "") }) : e.phase === "resolve" ? s(Ae ? "games.caverna.phaseResolve" : "games.caverna.waitingFeed") : e.phase === "feeding" ? s(je ? "games.caverna.feedingTitle" : "games.caverna.waitingFeed") : e.phase === "preScore" ? s(I ? "games.caverna.preScoreTitle" : "games.caverna.waitingPreScore") : ""
				}), e.phase !== "done" && e.phase !== "preScore" && /* @__PURE__ */ _("div", {
					className: "flex gap-1",
					children: [
						/* @__PURE__ */ g("button", {
							type: "button",
							className: C === "food" ? Q : Z,
							onClick: () => T(C === "food" ? null : "food"),
							children: "🍖"
						}),
						(F.goods.gold ?? 0) >= 2 && /* @__PURE__ */ g("button", {
							type: "button",
							className: C === "buyFood" ? Q : Z,
							onClick: () => T(C === "buyFood" ? null : "buyFood"),
							children: "🪙→🍖"
						}),
						(F.goods.ruby ?? 0) >= 1 && /* @__PURE__ */ g("button", {
							type: "button",
							className: C === "ruby" ? Q : Z,
							onClick: () => T(C === "ruby" ? null : "ruby"),
							children: "♦️→"
						}),
						(F.goods.ruby ?? 0) >= 1 && /* @__PURE__ */ g("button", {
							type: "button",
							className: C === "rubyTile" ? Q : Z,
							onClick: () => T(C === "rubyTile" ? null : "rubyTile"),
							children: "♦️→⬜"
						}),
						L("peacefulCave") && F.dwarfs.some((e) => e.weapon > 0) && /* @__PURE__ */ g("button", {
							type: "button",
							className: C === "peaceful" ? Q : Z,
							onClick: () => T(C === "peaceful" ? null : "peaceful"),
							children: "🕊"
						}),
						L("cookingCave") && (F.goods.grain ?? 0) >= 1 && (F.goods.veg ?? 0) >= 1 && /* @__PURE__ */ g("button", {
							type: "button",
							className: C === "cookingCave" ? Q : Z,
							onClick: () => T(C === "cookingCave" ? null : "cookingCave"),
							children: "🍲"
						})
					]
				})]
			}),
			children: /* @__PURE__ */ _("div", {
				className: "cv-table frame",
				"data-tab": v,
				children: [
					/* @__PURE__ */ g(u, {
						kind: "sheen",
						base: "#efe8d8",
						className: "absolute inset-0 size-full"
					}),
					/* @__PURE__ */ _("div", {
						className: "cv-tabs",
						children: [
							pt("board", s("games.caverna.tabBoard")),
							pt("home", s("games.caverna.tabHome")),
							pt("furn", s("games.caverna.tabFurnish"))
						]
					}),
					/* @__PURE__ */ _("div", {
						className: "cv-workspace",
						children: [/* @__PURE__ */ _("div", {
							className: "cv-main-column",
							children: [ht, _t]
						}), /* @__PURE__ */ _("div", {
							className: "cv-home-column",
							children: [gt, mt && /* @__PURE__ */ g("div", {
								ref: ee,
								className: "cv-sheet",
								children: mt
							})]
						})]
					})
				]
			})
		})
	});
}
//#endregion
//#region src/games/caverna/bot.ts
var nn = 3, rn = (e) => {
	let t = Math.floor(e / nn), n = e % nn;
	return [
		t > 0 ? e - nn : -1,
		t < 3 ? e + nn : -1,
		n > 0 ? e - 1 : -1,
		n < 2 ? e + 1 : -1
	].filter((e) => e >= 0);
}, an = 11, on = (e) => e.furnishings.includes("additionalDwelling") ? 6 : 5, sn = (e) => 2 + e.furnishings.reduce((e, t) => e + (j[t]?.room ?? 0), 0), cn = (e) => e.dwarfs.length < on(e) && e.dwarfs.length < sn(e), ln = (e) => e.dwarfs.length, un = (e, t) => t === "half" ? ln(e) : 2 * (ln(e) - e.newborn) + e.newborn, dn = (e, t) => (t === "dog" ? e.dogsHome : 0) + e.forest.reduce((e, n) => e + (n.animals?.kind === t ? n.animals.n : 0) + (t === "dog" ? n.dogs ?? 0 : 0), 0) + (t === "dog" ? 0 : e.mountain.reduce((e, n) => e + (n.animals?.kind === t ? n.animals.n : 0), 0));
function fn(e) {
	let t = (t) => e.forest[t]?.t === "forest";
	if (!e.hasLandscape) return t(an) && t(8) ? {
		meadow: an,
		field: 8
	} : null;
	let n = (t) => rn(t).some((t) => [
		"meadow",
		"field",
		"pasture"
	].includes(e.forest[t]?.t ?? ""));
	for (let e = 0; e < 12; e++) if (t(e) && n(e)) {
		for (let n of rn(e)) if (t(n)) return {
			meadow: e,
			field: n
		};
	}
	return null;
}
function pn(e) {
	let t = (t) => e.mountain[t]?.t === "rock" && rn(t).some((t) => e.mountain[t]?.t !== "rock");
	for (let e = 0; e < 12; e++) if (t(e)) {
		for (let n of rn(e)) if (t(n)) return {
			a: e,
			b: n
		};
	}
	return null;
}
var mn = (e) => e.mountain.findIndex((e) => e.t === "cavern" && !e.furnishing);
function hn(e) {
	let t = [], n = Math.min(e.goods.grain ?? 0, 2), r = Math.min(e.goods.veg ?? 0, 2);
	for (let i = 0; i < 12; i++) {
		let a = e.forest[i];
		a?.t !== "field" || a.crop || (n > 0 ? (t.push({
			cell: i,
			crop: "grain"
		}), n--) : r > 0 && (t.push({
			cell: i,
			crop: "veg"
		}), r--));
	}
	return t;
}
var gn = [
	"imitation",
	"imitation3",
	"imitation5a",
	"imitation5b",
	"imitation6a",
	"imitation6b",
	"imitation7a",
	"imitation7b",
	"imitation7c",
	"blacksmithing",
	"adventure",
	"exploration",
	"oreTrading",
	"rubyMineConstruction",
	"oreMineConstruction",
	"smallDriftMining",
	"hardwareRental"
];
function _n(e, t) {
	let n = e.public, r = n.players.find((e) => e.rid === t.rid);
	if (!r || n.phase === "done") return null;
	let i = (e, t) => ({ action: {
		type: "place",
		space: e,
		...t ? { payload: t } : {}
	} }), a = n.pending.find((e) => e.rid === t.rid);
	if (a) {
		if (a.kind === "harvestChoice") {
			let e = r.forest.some((e) => e.t === "field" && e.crop), t = S.some((e) => dn(r, e) >= 2);
			return { action: {
				type: "resolve",
				choice: e || !t ? "field" : "breed"
			} };
		}
		return { action: {
			type: "resolve",
			keep: []
		} };
	}
	if (n.phase === "resolve") return null;
	if (n.phase === "preScore") return n.preScoreWaiting.includes(t.rid) ? { action: { type: "preScore" } } : null;
	if (n.phase === "feeding") {
		if (!n.feedingWaiting.includes(t.rid)) return null;
		let e = un(r, n.feedMode ?? "normal"), i = Math.max(0, e - (r.goods.food ?? 0)), a = Math.min(r.goods.grain ?? 0, i);
		i -= a;
		let o = Math.min(r.goods.veg ?? 0, Math.ceil(i / 2));
		i -= o * 2;
		let s = Math.min(r.goods.ruby ?? 0, Math.ceil(i / 2));
		i -= s * 2;
		let c = 0, l = 0, u = 0;
		return i > 0 && (c = Math.min(dn(r, "sheep"), i), i -= c, l = Math.min(dn(r, "boar"), Math.ceil(i / 2)), i -= l * 2, u = Math.min(dn(r, "cattle"), Math.ceil(i / 3))), { action: {
			type: "confirmFeeding",
			...a ? { grain: a } : {},
			...o ? { veg: o } : {},
			...s ? { ruby: s } : {},
			...c ? { sheep: c } : {},
			...l ? { boar: l } : {},
			...u ? { cattle: u } : {}
		} };
	}
	if (n.phase !== "work" || n.active !== t.rid) return null;
	let o = (e) => n.spaces.find((t) => t.id === e && t.by.length === 0), s = (e) => n.spaces.find((t) => t.id === e)?.goods ?? {}, c = (e) => Object.values(s(e)).reduce((e, t) => e + (t ?? 0), 0), l = (r.goods.food ?? 0) + (r.goods.grain ?? 0) + 2 * (r.goods.veg ?? 0), u = l < un(r, "normal");
	if (u) {
		for (let e of [
			"sustenance",
			"forestExploration",
			"supplies",
			"startingPlayer",
			"forestExploration3",
			"weeklyMarket"
		]) if (o(e)) return i(e, e === "weeklyMarket" ? { market: ["sheep", "grain"] } : void 0);
		if (o("sheepFarming") && c("sheepFarming") > 0) return i("sheepFarming");
		if (o("donkeyFarming") && c("donkeyFarming") > 0) return i("donkeyFarming");
		if (o("growth")) return i("growth", { growthChoice: "goods" });
	}
	let d = l >= un(r, "normal") + 4, f = n.spaces.some((e) => e.id === "familyLife");
	if (cn(r) && d) {
		if (!f && o("wishForChildren")) return i("wishForChildren", { wishChoice: "grow" });
		if (o("familyLife")) return i("familyLife", { wishChoice: "grow" });
		if (o("growth")) return i("growth", { growthChoice: "grow" });
	}
	let p = mn(r);
	if (p >= 0 && sn(r) <= ln(r) + 1 && (r.goods.wood ?? 0) >= 4 && (r.goods.stone ?? 0) >= 3) {
		if (o("housework")) return i("housework", { furnish: {
			fid: "dwelling",
			cell: p
		} });
		if (o("wishForChildren")) return i("wishForChildren", {
			wishChoice: "dwelling",
			furnish: {
				fid: "dwelling",
				cell: p
			}
		});
	}
	let m = fn(r), h = hn(r);
	if (m && (o("clearing") || o("slashAndBurn"))) return o("slashAndBurn") ? i("slashAndBurn", {
		forTwin: m,
		...h.length > 0 ? { sow: h } : {}
	}) : i("clearing", { forTwin: m });
	if (h.length > 0 && o("slashAndBurn")) return i("slashAndBurn", { sow: h });
	if (h.length > 0 && o("familyLife")) return i("familyLife", { sow: h });
	let g = pn(r);
	if (g && !u) {
		if (o("driftMining")) return i("driftMining", { mtnTwin: {
			...g,
			aFace: "cavern"
		} });
		if (o("excavation")) return i("excavation", { mtnTwin: {
			...g,
			aFace: "cavern"
		} });
	}
	let _ = n.spaces.filter((e) => e.by.length === 0 && !gn.includes(e.id) && e.id !== "wishForChildren" && e.id !== "familyLife" && c(e.id) > 0).sort((e, t) => c(t.id) - c(e.id));
	if (_.length > 0) {
		let e = _[0].id;
		return e === "growth" ? i(e, { growthChoice: "goods" }) : i(e);
	}
	for (let e of [
		"startingPlayer",
		"housework",
		"supplies",
		"weeklyMarket"
	]) if (o(e)) return i(e);
	if (o("growth")) return i("growth", { growthChoice: "goods" });
	if (o("slashAndBurn") && m) return i("slashAndBurn", { forTwin: m });
	let ee = r.dwarfs.map((e, t) => t).filter((e) => !r.placed.includes(e)).sort((e, t) => r.dwarfs[e].weapon - r.dwarfs[t].weapon), v = ee.length > 0 ? r.dwarfs[ee[0]]?.weapon ?? 0 : 0, te = de.filter((e) => [
		"weaponsUp",
		"dog",
		"wood",
		"sheep",
		"grain",
		"donkey",
		"stone",
		"veg",
		"ore2",
		"boar",
		"gold2"
	].includes(e.id)).map((e) => e.id), y = (e, t) => te.filter((t) => (de.find((e) => e.id === t)?.min ?? 99) <= e).slice(0, t);
	if (g && o("smallDriftMining")) return i("smallDriftMining", { mtnTwin: {
		...g,
		aFace: "cavern"
	} });
	if ((r.goods.ore ?? 0) >= 2 && o("oreTrading")) return i("oreTrading", { oreTrades: 1 });
	if (v > 0) {
		if (o("exploration")) return i("exploration", { loot: y(v, 4) });
		if (o("adventure")) return i("adventure", {
			loot: y(v, 1),
			loot2: y(v + 1, 1)
		});
		if (o("blacksmithing")) return i("blacksmithing", { loot: y(v, 3) });
	}
	if (v === 0 && (r.goods.ore ?? 0) >= 1) {
		if (o("blacksmithing")) return i("blacksmithing", {
			forge: 1,
			loot: y(1, 3)
		});
		if (o("adventure")) return i("adventure", {
			forge: 1,
			loot: y(1, 1),
			loot2: y(2, 1)
		});
	}
	let b = r.mountain.map((e, t) => ({
		c: e,
		i: t
	})).filter(({ c: e }) => e.t === "tunnel" || e.t === "deepTunnel");
	if (o("rubyMineConstruction")) {
		let e = b.find(({ c: e }) => !e.furnishing);
		if (e) return i("rubyMineConstruction", { rubyMine: e.i });
	}
	if (o("oreMineConstruction")) {
		let e = b.map(({ i: e }) => e);
		for (let t of e) for (let n of rn(t)) if (e.includes(n)) return i("oreMineConstruction", { oreMine: {
			cells: [t, n],
			mineAt: t
		} });
	}
	let x = n.spaces.find((e) => e.by.length === 0 && !gn.includes(e.id) && e.id !== "wishForChildren" && e.id !== "familyLife");
	return x ? i(x.id) : null;
}
var vn = (e, t) => _n(e, t);
//#endregion
//#region src/games/caverna/endgame-review.tsx
function yn({ board: e, renderResult: t, ...n }) {
	let s = c(), [l, u] = o(!0), [d, f] = o(null), p = a(null), m = a(null), h = a(null);
	r(() => {
		if (!d) return;
		h.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => f(null), 5e3);
		return () => clearTimeout(e);
	}, [d]);
	let v = (e) => {
		f(null), u(e), requestAnimationFrame(() => (e ? p : m).current?.focus({ preventScroll: !0 }));
	}, b = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => f({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => f({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => f({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), x = {
		...n,
		...b
	};
	return /* @__PURE__ */ _("div", {
		className: "caverna-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ g("div", {
				className: "caverna-endgame-board",
				inert: l,
				children: e
			}),
			/* @__PURE__ */ g("div", {
				className: "caverna-endgame-overlay",
				hidden: !l,
				children: /* @__PURE__ */ _("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), v(!1));
					},
					className: "caverna-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ _("header", {
							className: "caverna-endgame-heading",
							children: [/* @__PURE__ */ _("div", {
								className: "caverna-endgame-brand",
								children: [/* @__PURE__ */ g("span", {
									"aria-hidden": "true",
									children: R.icon
								}), s(R.nameKey)]
							}), /* @__PURE__ */ g("button", {
								type: "button",
								ref: p,
								className: "btn-quiet",
								"aria-label": s("games.caverna.reviewHide"),
								title: s("games.caverna.reviewHide"),
								onClick: () => v(!1),
								children: /* @__PURE__ */ g(te, { size: 19 })
							})]
						}),
						/* @__PURE__ */ g("div", {
							className: "caverna-endgame-result",
							inert: d !== null,
							children: t(x)
						}),
						d && /* @__PURE__ */ _("div", {
							className: "caverna-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || f(null);
							},
							children: [/* @__PURE__ */ g("button", {
								type: "button",
								ref: h,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = d.run;
									f(null), e();
								},
								children: s(d.label === "again" ? "games.caverna.reviewConfirmAgain" : "games.caverna.reviewConfirmLobby")
							}), /* @__PURE__ */ g("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									f(null), p.current?.focus({ preventScroll: !0 });
								},
								children: s("games.caverna.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ g("div", {
				className: "caverna-endgame-toolbar",
				hidden: l,
				children: /* @__PURE__ */ _("button", {
					type: "button",
					className: "btn-base",
					ref: m,
					onClick: () => v(!0),
					children: [
						/* @__PURE__ */ g(y, { size: 18 }),
						s("games.caverna.reviewShow"),
						/* @__PURE__ */ g(ee, { size: 18 })
					]
				})
			})
		]
	});
}
function bn({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: l, rows: u, renderRowExtra: d, summary: f, navigation: p, content: ee, afterRanking: y, scoreUnit: x, rankOf: S }) {
	let C = c(), ne = s((e) => e.locale), [re, ie] = o({}), w = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? m(n, ne) : e;
	}, T = (t, n) => S?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), ae = e.ranking.some((t) => e.scores?.[t] !== void 0), oe = (t, n) => /* @__PURE__ */ _("div", {
		className: "caverna-score-identity",
		children: [
			/* @__PURE__ */ _("span", {
				className: "caverna-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ g("span", {
					"aria-label": C("games.caverna.reviewWinner"),
					children: "♛ "
				}), ae && T(t, n)]
			}),
			/* @__PURE__ */ _("span", {
				className: "caverna-score-name",
				children: [w(t), t === r && /* @__PURE__ */ g("small", { children: C("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ _("small", {
				className: "caverna-score-autopilot",
				children: [
					/* @__PURE__ */ g(v, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), E = (t) => e.ranking.map((n) => /* @__PURE__ */ g("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ _("div", {
		className: "caverna-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ g(b, {}),
			p,
			/* @__PURE__ */ _("div", {
				className: "caverna-score-body",
				children: [
					f && /* @__PURE__ */ g("div", {
						className: "caverna-score-summary",
						children: f
					}),
					i !== void 0 && /* @__PURE__ */ g("p", {
						className: "caverna-score-hints",
						children: C("session.hint.usedCount", { n: i })
					}),
					ee ?? (u?.length ? /* @__PURE__ */ g("div", {
						className: "caverna-score-table-scroll",
						children: /* @__PURE__ */ _("table", {
							className: "caverna-score-table",
							"aria-label": C(R.nameKey),
							children: [
								/* @__PURE__ */ g("thead", { children: /* @__PURE__ */ _("tr", { children: [/* @__PURE__ */ g("th", { scope: "col" }), /* @__PURE__ */ g(h, { children: e.ranking.map((t, n) => /* @__PURE__ */ g("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: oe(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ g("tbody", { children: u.map((e, t) => /* @__PURE__ */ _(n, { children: [/* @__PURE__ */ _("tr", { children: [/* @__PURE__ */ g("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ _("button", {
										type: "button",
										"aria-expanded": !!re[t],
										onClick: () => ie((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ g(te, { size: 15 }), e.label]
									}) : e.label
								}), E(e)] }), re[t] && e.details?.map((e, t) => /* @__PURE__ */ _("tr", {
									className: "caverna-score-sub",
									children: [/* @__PURE__ */ g("th", {
										scope: "row",
										children: e.label
									}), E(e)]
								}, t))] }, t)) }),
								ae && /* @__PURE__ */ g("tfoot", { children: /* @__PURE__ */ _("tr", { children: [/* @__PURE__ */ g("th", {
									scope: "row",
									children: C("games.caverna.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ g("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ g("ol", {
						className: "caverna-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ _("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ _("div", {
								className: "caverna-score-rankline",
								children: [oe(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ _("strong", {
									className: "caverna-score-points",
									children: [e.scores[t], x && /* @__PURE__ */ g("small", { children: x })]
								})]
							}), d?.(t)]
						}, t))
					})),
					y,
					!!u?.length && d && /* @__PURE__ */ g("div", {
						className: "caverna-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ _("details", { children: [/* @__PURE__ */ g("summary", { children: w(e) }), d(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ _("footer", {
				className: "caverna-score-actions",
				children: [
					l && /* @__PURE__ */ g("button", {
						type: "button",
						className: "btn-quiet",
						onClick: l,
						children: C("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ g("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: C("session.result.playAgain")
					}),
					!a && !l && /* @__PURE__ */ g("p", { children: C("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/caverna/game-over.tsx
function xn({ result: e, members: t, myRid: n, hintCount: r, onPlayAgain: i, onBackToLobby: a }) {
	return /* @__PURE__ */ g(bn, {
		result: e,
		members: t,
		myRid: n,
		accent: R.accent,
		hintCount: r,
		onPlayAgain: i,
		onBackToLobby: a
	});
}
function Sn(e) {
	return /* @__PURE__ */ g(yn, {
		...e,
		board: /* @__PURE__ */ g(en, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ g(xn, { ...e })
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/caverna/entry.tsx
var Cn = {
	definition: zt,
	View: en,
	bot: vn,
	OverView: Sn,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "洞穴农夫",
			desc: "12 回合经营矮人家园:坑道挖矿、森林放牧、锻造武器去远征,别忘了喂饱全家",
			rules: "目标:12 回合后,家园经营得分最高者获胜。\n准备:\n· 每人一块家园版图(山体 3 行 4 列、森林 3 行 4 列)、2 名矮人与入门居所;起始食物按座位 1/1/2/3 份。\n· 阶段卡分四阶段洗混,每回合开始翻开一张新行动格。\n流程:\n· 每回合轮流向空行动格放置 1 名矮人并执行该格;必须先放徒手矮人,再按武器强度升序放武装矮人(可付 1 红宝石插队)。\n· 累积格上的物资每回合累加,拿走即清空。\n· 挖隧道开洞穴、建家具(每只矮人都需要居所空位)、铺草原垦田播种、围牧场养动物、锻造武器后远征获得战利品。\n· 红宝石是万能资源:1:1 兑换物资(兑换牛需另付 1 食物)、兑换单块板块、让矮人插队。\n收获(按回合与标记):\n· 田地各收 1 份作物。\n· 每名矮人吃 2 食物(当轮新生吃 1),喂不饱领乞讨牌(每张扣 3 分)。\n· 每类农场动物不少于 2 只时繁殖 1 只。\n计分:动物、谷物(每 2 份计 1 分,向上取整)、蔬菜、红宝石、矮人、金币各计分;牧场/矿场/家具按面值。\n· 缺一类农场动物扣 2 分,未开发格扣 1 分,乞讨牌扣 3 分;黄底家具另有奖励分。平局共享胜利。\n单人:固定阶段卡序,第 5 回合起每轮收获;累积格超过 6 份物资会清空(可付红宝石保留)。",
			goods: {
				wood: "木头",
				stone: "石头",
				ore: "矿石",
				ruby: "红宝石",
				gold: "金币",
				food: "食物",
				grain: "谷物",
				veg: "蔬菜"
			},
			animals: {
				dog: "狗",
				sheep: "绵羊",
				donkey: "驴",
				boar: "野猪",
				cattle: "牛"
			},
			spaces: {
				driftMining: "坑道开采",
				excavation: "挖掘",
				startingPlayer: "起始玩家",
				logging: "伐木",
				supplies: "补给",
				oreMining: "矿石开采",
				woodGathering: "集材",
				clearing: "清理",
				sustenance: "生计",
				growth: "成长",
				forestExploration: "森林探索",
				imitation: "模仿",
				rubyMining: "红宝石开采",
				housework: "家务",
				slashAndBurn: "刀耕火种",
				stripMining: "露天开采",
				imitation3: "模仿(4 食物)",
				forestExploration3: "森林探索(小)",
				depot: "仓库",
				weeklyMarket: "周市",
				hardwareRental: "五金租赁",
				imitation5a: "模仿(2 食物)",
				imitation5b: "模仿(4 食物)",
				smallDriftMining: "小型坑道开采",
				driftMining2: "坑道开采 II",
				fenceBuilding: "围建牧场",
				imitation6a: "模仿(1 食物)",
				imitation6b: "模仿(2 食物)",
				largeDepot: "大仓库",
				extension: "扩建",
				imitation7a: "模仿(免费)",
				imitation7b: "模仿(1 食物)",
				imitation7c: "模仿(2 食物)",
				blacksmithing: "锻造",
				sheepFarming: "牧羊",
				oreMineConstruction: "矿场建设",
				wishForChildren: "求子",
				donkeyFarming: "养驴",
				rubyMineConstruction: "红宝石矿建设",
				familyLife: "家庭生活",
				exploration: "探险",
				oreDelivery: "矿石运输",
				adventure: "冒险",
				oreTrading: "矿石交易",
				rubyDelivery: "红宝石运输"
			},
			spaceDesc: {
				driftMining: "拿走累积的石头,可放置 1 块洞穴/隧道双拼",
				excavation: "拿走累积的石头,可放置 1 块双拼(可选双洞穴面)",
				startingPlayer: "拿走累积的食物,另获得物资,成为下一轮起始玩家",
				logging: "拿走累积的木头,可进行 1 级远征",
				supplies: "获得 1 木头、1 石头、1 矿石、1 食物与 2 金币",
				oreMining: "拿走累积的矿石,每座矿场另得 2 矿石",
				woodGathering: "拿走累积的木头",
				clearing: "拿走累积的木头,可放置 1 块草原/田地双拼",
				sustenance: "拿走累积物资,可放置 1 块草原/田地双拼",
				growth: "获得 1 木头、1 石头、1 矿石、1 食物与 2 金币,或增加 1 名矮人(需居所空位)",
				forestExploration: "拿走累积的木头,另获得 2 食物",
				imitation: "付 2 食物,执行一个被对手占据的行动格(拿不到累积物资)",
				rubyMining: "拿走累积的红宝石;有红宝石矿则另获得 1 颗",
				housework: "获得 1 只狗,和/或装修洞穴(建 1 件家具,照付费用)",
				slashAndBurn: "放置 1 块草原/田地双拼,然后可播种",
				stripMining: "拿走累积物资,另获得 2 木头",
				imitation3: "付 4 食物,执行一个被对手占据的行动格(拿不到累积物资)",
				forestExploration3: "拿走累积的木头,另获得 1 蔬菜",
				depot: "拿走累积的木头与矿石",
				weeklyMarket: "获得 4 金币,可按市价购物(每类限购 1)",
				hardwareRental: "进行 2 级远征,和/或播种",
				imitation5a: "付 2 食物,执行一个被对手占据的行动格(拿不到累积物资)",
				imitation5b: "付 4 食物,执行一个被对手占据的行动格(拿不到累积物资)",
				smallDriftMining: "放置 1 块洞穴/隧道双拼,然后获得 1 石头",
				driftMining2: "拿走累积的石头,可放置 1 块洞穴/隧道双拼",
				fenceBuilding: "拿走累积的木头,可围 1 个小牧场(2 木头)和/或 1 个大牧场(4 木头)",
				imitation6a: "付 1 食物,执行一个被对手占据的行动格(拿不到累积物资)",
				imitation6b: "付 2 食物,执行一个被对手占据的行动格(拿不到累积物资)",
				largeDepot: "拿走累积的木头、石头与矿石",
				extension: "放置草原/田地双拼并获得 1 木头,或放置洞穴/隧道双拼并获得 1 石头",
				imitation7a: "免费执行一个被对手占据的行动格(拿不到累积物资)",
				imitation7b: "付 1 食物,执行一个被对手占据的行动格(拿不到累积物资)",
				imitation7c: "付 2 食物,执行一个被对手占据的行动格(拿不到累积物资)",
				blacksmithing: "徒手矮人付等量矿石锻造 1-8 强度的武器,然后进行 3 级远征;已武装则仅 3 级远征",
				sheepFarming: "拿取绵羊前可先围 1 个小牧场和 1 个大牧场并建 1 个畜棚;拿走累积的绵羊",
				oreMineConstruction: "把 2 条相邻隧道盖成矿场加深隧道,获得 3 矿石;和/或进行 2 级远征",
				wishForChildren: "增加 1 名矮人(需居所空位),或建 1 间居所;家庭生活翻开后变为:建居所后增加 1 名矮人,或获得 3 金币",
				donkeyFarming: "拿取驴前可先围 1 个小牧场和 1 个大牧场并建 1 个畜棚;拿走累积的驴",
				rubyMineConstruction: "把 1 条隧道盖成红宝石矿(是深隧道则另获得 1 红宝石);可先付 1 红宝石买 1 条隧道",
				familyLife: "增加 1 名矮人(需居所空位),和/或播种",
				exploration: "仅武装矮人:4 级远征",
				oreDelivery: "拿走累积的矿石与石头,每座矿场另得 2 矿石",
				adventure: "徒手矮人先锻造,然后连续 2 次 1 级远征",
				oreTrading: "每次用 2 矿石兑换 2 金币与 1 食物,至多 3 次",
				rubyDelivery: "拿走累积的红宝石;有至少 2 座红宝石矿则另获得 1 颗"
			},
			furnishings: {
				dwelling: "居所",
				simpleDwelling1: "简陋居所(木)",
				simpleDwelling2: "简陋居所(石)",
				mixedDwelling: "混合居所",
				coupleDwelling: "夫妻居所",
				additionalDwelling: "额外居所",
				cuddleRoom: "温存室",
				breakfastRoom: "早餐室",
				stubbleRoom: "残茬室",
				workRoom: "工作间",
				guestRoom: "客房",
				officeRoom: "办公室",
				carpenter: "木匠",
				stoneCarver: "石匠",
				blacksmith: "铁匠",
				miner: "矿工",
				builder: "建造者",
				trader: "商人",
				woodSupplier: "木材供应商",
				stoneSupplier: "石材供应商",
				rubySupplier: "红宝石供应商",
				dogSchool: "训犬学校",
				quarry: "采石场",
				seam: "矿缝",
				slaughteringCave: "屠宰洞",
				cookingCave: "烹饪洞",
				workingCave: "劳作洞",
				miningCave: "采矿洞",
				breedingCave: "繁殖洞",
				peacefulCave: "和平洞",
				weavingParlor: "纺织厅",
				milkingParlor: "挤奶厅",
				stateParlor: "国务厅",
				huntingParlor: "狩猎厅",
				beerParlor: "啤酒厅",
				blacksmithingParlor: "锻造厅",
				stoneStorage: "石料储藏室",
				oreStorage: "矿石储藏室",
				sparePartStorage: "备件储藏室",
				mainStorage: "主储藏室",
				weaponStorage: "武器储藏室",
				suppliesStorage: "补给储藏室",
				broomChamber: "扫帚室",
				treasureChamber: "宝藏室",
				foodChamber: "食物室",
				prayerChamber: "祈祷室",
				writingChamber: "书房",
				fodderChamber: "饲料室"
			},
			furnishingDesc: {
				dwelling: "增加 1 个居所空位(不限量)",
				simpleDwelling1: "增加 1 个居所空位",
				simpleDwelling2: "增加 1 个居所空位",
				mixedDwelling: "增加 1 个居所空位,可容纳 1 对同类动物",
				coupleDwelling: "增加 2 个居所空位",
				additionalDwelling: "增加 1 个居所空位,矮人上限升为 6",
				cuddleRoom: "可容纳绵羊,数量至多等于矮人数",
				breakfastRoom: "可容纳至多 3 头牛",
				stubbleRoom: "每块空田可放 1 只动物",
				workRoom: "家具可建在隧道上(工作间自身除外)",
				guestRoom: "行动格的「二选一」对你变成「两者皆可」",
				officeRoom: "双拼板块可半块悬出界外,每次外悬得 2 金币",
				carpenter: "建家具与围牧场少付 1 木头",
				stoneCarver: "建成时获得 2 石头;建家具与畜棚少付 1 石头",
				blacksmith: "建成时获得 2 矿石;锻造少付 2 矿石",
				miner: "每轮开始,每座有驴的矿场得 1 矿石",
				builder: "建家具可用 1 矿石代替 1 木头和/或 1 石头",
				trader: "计分前:每 2 金币可兑换 1 木头、1 石头与 1 矿石;与备件储藏室互相覆盖",
				woodSupplier: "之后 7 轮每轮获得 1 木头",
				stoneSupplier: "之后 5 轮每轮获得 1 石头",
				rubySupplier: "之后 4 轮每轮获得 1 红宝石",
				dogSchool: "之后每获得 1 只狗,同时获得 1 木头",
				quarry: "繁殖新生的每只驴另获得 1 石头",
				seam: "每次获得石头时,额外获得 1 个矿石",
				slaughteringCave: "动物兑换食物时每只多得 1 食物(狗除外;不与狩猎厅并用)",
				cookingCave: "可将 1 谷物与 1 蔬菜兑换成 5 食物",
				workingCave: "喂食时恰好 1 名矮人可用 1 木/1 石/2 矿喂养",
				miningCave: "喂食时每座有驴的矿场少喂 1 食物",
				breedingCave: "每只繁殖新生的动物获得 1 食物,四类全部繁殖再获得 1 食物",
				peacefulCave: "任意时刻把武器按强度换成食物",
				weavingParlor: "建成时每只绵羊获得 1 食物;终局每 2 只绵羊计 1 分",
				milkingParlor: "建成时每头牛获得 1 食物;终局每头牛计 1 分",
				stateParlor: "建成时每个相邻居所获得 2 食物;终局每个相邻居所计 4 分(上限 16)",
				huntingParlor: "计分前:每 2 只野猪可兑换 2 金币与 2 食物",
				beerParlor: "计分前:每 2 谷物可兑换 3 金币或 4 食物",
				blacksmithingParlor: "计分前:可用 1 红宝石与 1 矿石兑换 2 金币与 1 食物",
				stoneStorage: "终局每块石头 1 分",
				oreStorage: "终局每 2 块矿石 1 分",
				sparePartStorage: "计分前:每套 1 木头、1 石头与 1 矿石可兑换 2 金币;与商人互相覆盖",
				mainStorage: "终局每件黄底家具 2 分(含自身)",
				weaponStorage: "终局每名武装矮人 3 分",
				suppliesStorage: "终局若全员武装 +8 分",
				broomChamber: "终局 5 名矮人 +5 分,6 名 +10 分",
				treasureChamber: "终局每颗红宝石 1 分",
				foodChamber: "终局每对谷物+蔬菜 2 分",
				prayerChamber: "终局若无人持武 +8 分",
				writingChamber: "终局最多免除 7 分罚分",
				fodderChamber: "终局每 3 只农场动物 1 分"
			},
			loot: {
				weaponsUp: "全部武器强度 +1",
				dog: "1 只狗",
				wood: "1 木头",
				sheep: "1 只绵羊",
				grain: "1 谷物",
				donkey: "1 头驴",
				stone: "1 石头",
				veg: "1 蔬菜",
				ore2: "2 矿石",
				boar: "1 只野猪",
				gold2: "2 金币",
				furnish: "装修洞穴(照付费用)",
				stable: "免费畜棚",
				tunnel: "免费隧道",
				smallPasture1w: "1 木围小牧场",
				cattle: "1 头牛",
				largePasture2w: "2 木围大牧场",
				meadow: "免费草原",
				dwelling2w2s: "2 木 2 石建居所",
				field: "免费田地",
				sow: "播种",
				cavern: "免费洞穴",
				breed2: "至多 2 类动物繁殖"
			},
			round: "第 {{n}} 回合",
			phaseWork: "放置矮人",
			phaseResolve: "等待选择",
			phaseFeeding: "收获喂食",
			phasePreScore: "计分前兑换",
			harvestLeaf: "正常收获",
			harvestHalf: "减半喂食",
			harvestNone: "无收获",
			harvestQ3: "田地/繁殖二选一",
			tabBoard: "行动板",
			tabHome: "家园",
			tabFurnish: "家具",
			myTurn: "轮到你了",
			waiting: "等待 {{name}}…",
			startPlayerMark: "起始",
			babyMark: "新生",
			weaponShort: "武",
			placeHere: "放置矮人",
			useRubyJump: "付 1 红宝石任选矮人",
			pickDwarf: "选择要放的矮人",
			atLeastOne: "至少执行一个行动",
			twinMtn: "山体双拼",
			twinFor: "草原/田地双拼",
			faceCavern: "洞穴",
			faceTunnel: "隧道",
			faceMeadow: "草原",
			faceField: "田地",
			overhangOk: "可半块悬出(办公室)",
			sowTitle: "播种(点至多 2 块谷物田与 2 块蔬菜田)",
			pastureSmallLabel: "小牧场(2 木头)",
			pastureLargeLabel: "大牧场(4 木头)",
			stableLabel: "畜棚(1 石头)",
			forgeTitle: "锻造武器强度",
			expeditionTitle: "远征战利品",
			expeditionPick: "选择至多 {{n}} 项(各不相同)",
			oreMineTitle: "矿场双拼:点 2 条相邻隧道,再点哪格做矿场",
			rubyMineLabel: "盖红宝石矿",
			buyTunnelLabel: "先付 1 红宝石买隧道",
			imitateLabel: "复制对手占据的格子",
			growthGoods: "获得物资",
			growthGrow: "增加矮人",
			wishGrow: "增加矮人",
			wishDwelling: "建居所",
			wishGold: "获得 3 金币",
			marketTitle: "周市购物(每类限 1)",
			oreTradesLabel: "矿石交易次数",
			submit: "执行",
			cancel: "取消",
			dogsHome: "家中狗",
			stablesLeft: "畜棚",
			furnishingsMine: "我的家具",
			moveAnimals: "重排动物",
			moveAnimalsHint: "点两格交换/移动动物,完成后提交",
			animalsNeedHome: "动物会自动安置;放不下将按换食率折成食物",
			convertTitle: "兑换",
			convertFood: "兑换食物",
			buyFood: "金币买食物(买 N 份付 N+1 金币)",
			rubyExchange: "红宝石兑换物资(1:1,兑换牛另付 1 食物)",
			rubyTile: "红宝石兑换板块(田地/草原/隧道各 1 颗,洞穴 2 颗)",
			peaceful: "武器兑换食物(和平洞)",
			cookingCave: "1 谷物 + 1 蔬菜 = 5 食物(烹饪洞)",
			feedingTitle: "喂食",
			feedingNeed: "还需 {{n}} 食物",
			feedingAuto: "已自动用掉库存食物",
			feedingBegging: "缺口将领取乞讨牌(每张 -3 分)",
			feedingConfirm: "确认喂食",
			workingCaveFeed: "劳作洞:1 木/1 石/2 矿喂 1 人",
			waitingFeed: "等待其他人确认喂食…",
			harvestChoiceTitle: "收获事件:本回合你选择",
			chooseField: "田地收成",
			chooseBreed: "动物繁殖",
			rubyKeepTitle: "累积格将超过 6 份物资:选择付 1 红宝石保留的格子",
			preScoreTitle: "计分前兑换",
			preScoreDone: "完成,进入计分",
			preScoreHunting: "2 野猪 → 2 金币 2 食物",
			preScoreBeerGold: "2 谷物 → 3 金币",
			preScoreBeerFood: "2 谷物 → 4 食物",
			preScoreTrader: "2 金币 → 1 木头 1 石头 1 矿石",
			preScoreSpareParts: "1 木头 1 石头 1 矿石 → 2 金币",
			preScoreSmithParlor: "1 红宝石 + 1 矿石 → 2 金币 1 食物",
			waitingPreScore: "等待其他人完成兑换…",
			revealedEvent: "翻开了新行动格",
			pickSpace: "点选一个行动格放置矮人",
			mtnSide: "山体",
			forSide: "森林",
			catDwelling: "居所",
			catSpecial: "特殊房间",
			catCraft: "建材",
			catFood: "食物洞",
			catParlor: "客厅",
			catStorage: "储藏室",
			scorePts: "{{n}} 分",
			takenBy: "{{name}} 已建",
			furnPickCell: "再点一个空洞穴格放置",
			forgeCost: "强度 {{n}} · 付 {{cost}} 矿石",
			harvestUnknown: "收获未知",
			moveSubmit: "提交重排",
			overhangB: "B 半边悬出(+2 金币)",
			overhangMeadow: "草原半边悬出(+2 金币)",
			overhangField: "田地半边悬出(+2 金币)",
			mineAtLabel: "矿场放这格",
			feedShort: "缺口 {{n}} · 乞讨牌",
			lootPicked: "已选 {{n}}/{{max}} 项",
			marketCost: "合计 {{n}} 金币",
			convertNow: "兑换",
			rubyPickTarget: "付 1 红宝石换:",
			buyFoodN: "买 {{n}} 食物(付 {{cost}} 金币)",
			peacefulPick: "选 1 名武装矮人,武器换成等量食物",
			dogHomeShort: "家中",
			movePickFirst: "先点一个动物格",
			slotMeadow: "草原格",
			slotField: "田地格",
			slotA: "A 格",
			slotB: "B 格",
			buildFurnish: "选择家具",
			pickTarget: "选择要复制的格子",
			secondExpedition: "第二次远征",
			beggingLabel: "乞讨牌",
			errNotYourTurn: "还没轮到你",
			errBadPhase: "当前阶段不能这么做",
			errPending: "有选择待处理",
			errBadSpace: "这个行动格不可用",
			errOccupied: "这个行动格已被占用",
			errPlayOrder: "必须按武器强度升序放矮人(或付 1 红宝石插队)",
			errBadDwarf: "这只矮人不能这么用",
			errNoAction: "至少执行一个行动",
			errCantAfford: "资源不够",
			errBadCell: "这格不能这么用",
			errBadPayload: "这个行动还缺选择",
			errTaken: "这件家具已被别人建走",
			errNotWaiting: "现在不需要你确认",
			errBadLoot: "战利品选择不合法(须各不相同且不超过武器强度)",
			errNeedWeapon: "需要武装矮人",
			errNoRoom: "居所住不下了",
			errBadLayout: "动物摆法不合法(容量/种类冲突)"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Caverna",
			desc: "Develop your dwarf homestead over 12 rounds: mine tunnels, farm the forest, forge weapons for expeditions — and keep everyone fed",
			rules: "Goal: after 12 rounds, the most valuable homestead wins.\nSetup:\n· Each player gets a home board (3 rows by 4 columns of mountain, plus 3 rows by 4 columns of forest), 2 dwarfs and an entry-level dwelling; starting food is 1/1/2/3 by seat order.\n· Stage cards are shuffled within four stages; one new action space is revealed each round.\nFlow:\n· Take turns placing 1 dwarf on an empty action space and resolving it. Unarmed dwarfs must be placed first, then armed ones in ascending weapon strength (pay 1 ruby to skip the order).\n· Goods accumulate on accumulation spaces each round; taking them empties the space.\n· Dig tunnels and caverns, furnish rooms (every dwarf needs dwelling space), lay meadows and fields, fence pastures, forge weapons and go on expeditions for loot.\n· Rubies are wild: exchange 1:1 for goods (cattle costs 1 extra food), exchange for single tiles, or skip the dwarf play order.\nHarvest (by round and token):\n· Collect 1 crop per field.\n· Feed 2 food per dwarf (1 per newborn); unfed dwarfs take begging markers (each costs 3 points).\n· Every farm animal type with at least 2 breeds 1.\nScoring: animals, grain (every 2 score 1 point, rounded up), vegetables, rubies, dwarfs and gold all score; pastures, mines and furnishings score their printed value.\n· Each missing farm animal type costs 2 points, each undeveloped space costs 1, each begging marker costs 3; yellow furnishing tiles grant bonus points. Ties are shared wins.\nSolo: fixed stage order, harvest every round from round 5; accumulation spaces holding more than 6 goods are cleared (pay 1 ruby per space to keep).",
			goods: {
				wood: "Wood",
				stone: "Stone",
				ore: "Ore",
				ruby: "Ruby",
				gold: "Gold",
				food: "Food",
				grain: "Grain",
				veg: "Vegetable"
			},
			animals: {
				dog: "Dog",
				sheep: "Sheep",
				donkey: "Donkey",
				boar: "Wild boar",
				cattle: "Cattle"
			},
			spaces: {
				driftMining: "Drift Mining",
				excavation: "Excavation",
				startingPlayer: "Starting Player",
				logging: "Logging",
				supplies: "Supplies",
				oreMining: "Ore Mining",
				woodGathering: "Wood Gathering",
				clearing: "Clearing",
				sustenance: "Sustenance",
				growth: "Growth",
				forestExploration: "Forest Exploration",
				imitation: "Imitation",
				rubyMining: "Ruby Mining",
				housework: "Housework",
				slashAndBurn: "Slash-and-burn",
				stripMining: "Strip Mining",
				imitation3: "Imitation (4 food)",
				forestExploration3: "Forest Exploration (S)",
				depot: "Depot",
				weeklyMarket: "Weekly Market",
				hardwareRental: "Hardware Rental",
				imitation5a: "Imitation (2 food)",
				imitation5b: "Imitation (4 food)",
				smallDriftMining: "Small Drift Mining",
				driftMining2: "Drift Mining II",
				fenceBuilding: "Fence Building",
				imitation6a: "Imitation (1 food)",
				imitation6b: "Imitation (2 food)",
				largeDepot: "Large Depot",
				extension: "Extension",
				imitation7a: "Imitation (free)",
				imitation7b: "Imitation (1 food)",
				imitation7c: "Imitation (2 food)",
				blacksmithing: "Blacksmithing",
				sheepFarming: "Sheep Farming",
				oreMineConstruction: "Ore Mine Construction",
				wishForChildren: "Wish for Children",
				donkeyFarming: "Donkey Farming",
				rubyMineConstruction: "Ruby Mine Construction",
				familyLife: "Family Life",
				exploration: "Exploration",
				oreDelivery: "Ore Delivery",
				adventure: "Adventure",
				oreTrading: "Ore Trading",
				rubyDelivery: "Ruby Delivery"
			},
			spaceDesc: {
				driftMining: "Take the accumulated stone; you may place a Cavern/Tunnel twin tile",
				excavation: "Take the accumulated stone; you may place a twin tile (double Cavern allowed)",
				startingPlayer: "Take the accumulated food plus goods, and become the next starting player",
				logging: "Take the accumulated wood; you may undertake a level 1 expedition",
				supplies: "Get 1 wood, 1 stone, 1 ore, 1 food and 2 gold",
				oreMining: "Take the accumulated ore, plus 2 ore per Ore mine you own",
				woodGathering: "Take the accumulated wood",
				clearing: "Take the accumulated wood; you may place a Meadow/Field twin tile",
				sustenance: "Take the accumulated goods; you may place a Meadow/Field twin tile",
				growth: "Get 1 wood, 1 stone, 1 ore, 1 food and 2 gold, or grow your family (needs dwelling space)",
				forestExploration: "Take the accumulated wood, plus 2 food",
				imitation: "Pay 2 food to use an action space occupied by an opponent (without its accumulated goods)",
				rubyMining: "Take the accumulated rubies; gain 1 more if you own a Ruby mine",
				housework: "Get 1 dog, and/or furnish a cavern (pay the furnishing cost)",
				slashAndBurn: "Place a Meadow/Field twin tile, then you may sow",
				stripMining: "Take the accumulated goods, plus 2 wood",
				imitation3: "Pay 4 food to use an action space occupied by an opponent (without its accumulated goods)",
				forestExploration3: "Take the accumulated wood, plus 1 vegetable",
				depot: "Take the accumulated wood and ore",
				weeklyMarket: "Get 4 gold and buy goods at market prices (max 1 per type)",
				hardwareRental: "Undertake a level 2 expedition, and/or sow",
				imitation5a: "Pay 2 food to use an action space occupied by an opponent (without its accumulated goods)",
				imitation5b: "Pay 4 food to use an action space occupied by an opponent (without its accumulated goods)",
				smallDriftMining: "Place a Cavern/Tunnel twin tile, then gain 1 stone",
				driftMining2: "Take the accumulated stone; you may place a Cavern/Tunnel twin tile",
				fenceBuilding: "Take the accumulated wood; fence 1 small (2 wood) and/or 1 large (4 wood) pasture",
				imitation6a: "Pay 1 food to use an action space occupied by an opponent (without its accumulated goods)",
				imitation6b: "Pay 2 food to use an action space occupied by an opponent (without its accumulated goods)",
				largeDepot: "Take the accumulated wood, stone and ore",
				extension: "Place a Meadow/Field twin tile and gain 1 wood, or a Cavern/Tunnel twin tile and gain 1 stone",
				imitation7a: "For free, use an action space occupied by an opponent (without its accumulated goods)",
				imitation7b: "Pay 1 food to use an action space occupied by an opponent (without its accumulated goods)",
				imitation7c: "Pay 2 food to use an action space occupied by an opponent (without its accumulated goods)",
				blacksmithing: "An unarmed dwarf forges a weapon of strength 1-8 (pay ore equal to its strength), then undertakes a level 3 expedition; an armed dwarf only expeditions",
				sheepFarming: "Before taking the sheep you may fence 1 small pasture and 1 large pasture and build 1 stable; take the accumulated sheep",
				oreMineConstruction: "Cover 2 adjacent tunnels with an Ore mine plus a Deep tunnel and gain 3 ore; and/or undertake a level 2 expedition",
				wishForChildren: "Grow your family (needs dwelling space) or build a Dwelling; once Family Life is revealed: build a Dwelling, then grow your family, or gain 3 gold",
				donkeyFarming: "Before taking the donkeys you may fence 1 small pasture and 1 large pasture and build 1 stable; take the accumulated donkeys",
				rubyMineConstruction: "Turn a tunnel into a Ruby mine (gain 1 extra ruby if it is a deep tunnel); you may first pay 1 ruby for a new tunnel",
				familyLife: "Grow your family (needs dwelling space), and/or sow",
				exploration: "Armed dwarfs only: level 4 expedition",
				oreDelivery: "Take the accumulated ore and stone, plus 2 ore per Ore mine you own",
				adventure: "An unarmed dwarf forges first, then two level 1 expeditions in a row",
				oreTrading: "Trade 2 ore for 2 gold and 1 food per trade, up to 3 times",
				rubyDelivery: "Take the accumulated rubies; gain 1 more if you own at least 2 Ruby mines"
			},
			furnishings: {
				dwelling: "Dwelling",
				simpleDwelling1: "Simple Dwelling (wood)",
				simpleDwelling2: "Simple Dwelling (stone)",
				mixedDwelling: "Mixed Dwelling",
				coupleDwelling: "Couple Dwelling",
				additionalDwelling: "Additional Dwelling",
				cuddleRoom: "Cuddle Room",
				breakfastRoom: "Breakfast Room",
				stubbleRoom: "Stubble Room",
				workRoom: "Work Room",
				guestRoom: "Guest Room",
				officeRoom: "Office Room",
				carpenter: "Carpenter",
				stoneCarver: "Stone Carver",
				blacksmith: "Blacksmith",
				miner: "Miner",
				builder: "Builder",
				trader: "Trader",
				woodSupplier: "Wood Supplier",
				stoneSupplier: "Stone Supplier",
				rubySupplier: "Ruby Supplier",
				dogSchool: "Dog School",
				quarry: "Quarry",
				seam: "Seam",
				slaughteringCave: "Slaughtering Cave",
				cookingCave: "Cooking Cave",
				workingCave: "Working Cave",
				miningCave: "Mining Cave",
				breedingCave: "Breeding Cave",
				peacefulCave: "Peaceful Cave",
				weavingParlor: "Weaving Parlor",
				milkingParlor: "Milking Parlor",
				stateParlor: "State Parlor",
				huntingParlor: "Hunting Parlor",
				beerParlor: "Beer Parlor",
				blacksmithingParlor: "Blacksmithing Parlor",
				stoneStorage: "Stone Storage",
				oreStorage: "Ore Storage",
				sparePartStorage: "Spare Part Storage",
				mainStorage: "Main Storage",
				weaponStorage: "Weapon Storage",
				suppliesStorage: "Supplies Storage",
				broomChamber: "Broom Chamber",
				treasureChamber: "Treasure Chamber",
				foodChamber: "Food Chamber",
				prayerChamber: "Prayer Chamber",
				writingChamber: "Writing Chamber",
				fodderChamber: "Fodder Chamber"
			},
			furnishingDesc: {
				dwelling: "Adds 1 dwarf space (unlimited)",
				simpleDwelling1: "Adds 1 dwarf space",
				simpleDwelling2: "Adds 1 dwarf space",
				mixedDwelling: "Adds 1 dwarf space, holds a pair of animals of one type",
				coupleDwelling: "Adds 2 dwarf spaces",
				additionalDwelling: "Adds 1 dwarf space, raises the dwarf limit to 6",
				cuddleRoom: "Holds sheep, up to your dwarf count",
				breakfastRoom: "Holds up to 3 cattle",
				stubbleRoom: "Each empty field can hold 1 animal",
				workRoom: "Furnishings may be built on tunnels (except the Work Room itself)",
				guestRoom: "\"either/or\" action spaces become \"and/or\" for you",
				officeRoom: "Twin tiles may overhang the board edge; +2 gold each time",
				carpenter: "Pay 1 less wood when furnishing or fencing",
				stoneCarver: "Gain 2 stone when built; pay 1 less stone when furnishing or building stables",
				blacksmith: "Gain 2 ore when built; forging costs 2 less ore",
				miner: "At the start of each round, +1 ore per Ore mine holding a donkey",
				builder: "When furnishing, 1 ore may replace 1 wood and/or 1 stone",
				trader: "Before scoring: every 2 gold buys 1 wood, 1 stone and 1 ore; covers the Spare Part Storage",
				woodSupplier: "Gain 1 wood in each of the next 7 rounds",
				stoneSupplier: "Gain 1 stone in each of the next 5 rounds",
				rubySupplier: "Gain 1 ruby in each of the next 4 rounds",
				dogSchool: "Gain 1 wood each time you get a dog",
				quarry: "Gain 1 stone per newborn donkey from breeding",
				seam: "Whenever you gain stone, gain 1 additional ore",
				slaughteringCave: "Gain 1 extra food per animal converted to food (except dogs; not with Hunting Parlor)",
				cookingCave: "1 grain + 1 vegetable = 5 food",
				workingCave: "When feeding, exactly 1 dwarf may be fed with 1 wood / 1 stone / 2 ore",
				miningCave: "When feeding, -1 food per Ore mine holding a donkey",
				breedingCave: "Gain 1 food per newborn animal from breeding, and 1 more if all four types bred",
				peacefulCave: "At any time, convert a weapon into food equal to its strength",
				weavingParlor: "Gain 1 food per sheep when built; at scoring, 1 point per 2 sheep",
				milkingParlor: "Gain 1 food per cattle when built; at scoring, 1 point per cattle",
				stateParlor: "Gain 2 food per adjacent dwelling when built; at scoring, 4 points each (max 16)",
				huntingParlor: "Before scoring: every 2 wild boars convert to 2 gold and 2 food",
				beerParlor: "Before scoring: every 2 grain convert to 3 gold or 4 food",
				blacksmithingParlor: "Before scoring: 1 ruby plus 1 ore convert to 2 gold and 1 food",
				stoneStorage: "At scoring, 1 point per stone",
				oreStorage: "At scoring, 1 point per 2 ore",
				sparePartStorage: "Before scoring: each set of 1 wood, 1 stone and 1 ore converts to 2 gold; covers the Trader",
				mainStorage: "At scoring, 2 points per yellow furnishing (including itself)",
				weaponStorage: "At scoring, 3 points per armed dwarf",
				suppliesStorage: "At scoring, +8 if all your dwarfs are armed",
				broomChamber: "At scoring, +5 with 5 dwarfs, +10 with 6",
				treasureChamber: "At scoring, 1 point per ruby",
				foodChamber: "At scoring, 2 points per grain+vegetable pair",
				prayerChamber: "At scoring, +8 if no dwarf bears a weapon",
				writingChamber: "At scoring, prevent up to 7 minus points",
				fodderChamber: "At scoring, 1 point per 3 farm animals"
			},
			loot: {
				weaponsUp: "All weapons +1 strength",
				dog: "1 dog",
				wood: "1 wood",
				sheep: "1 sheep",
				grain: "1 grain",
				donkey: "1 donkey",
				stone: "1 stone",
				veg: "1 vegetable",
				ore2: "2 ore",
				boar: "1 wild boar",
				gold2: "2 gold",
				furnish: "Furnish a cavern (pay its cost)",
				stable: "Free stable",
				tunnel: "Free tunnel",
				smallPasture1w: "Small pasture for 1 wood",
				cattle: "1 cattle",
				largePasture2w: "Large pasture for 2 wood",
				meadow: "Free meadow",
				dwelling2w2s: "Dwelling for 2 wood 2 stone",
				field: "Free field",
				sow: "Sow",
				cavern: "Free cavern",
				breed2: "Breed up to 2 animal types"
			},
			round: "Round {{n}}",
			phaseWork: "Place dwarfs",
			phaseResolve: "Waiting for choices",
			phaseFeeding: "Harvest feeding",
			phasePreScore: "Pre-scoring trades",
			harvestLeaf: "Normal harvest",
			harvestHalf: "Half feeding",
			harvestNone: "No harvest",
			harvestQ3: "Field or breed",
			tabBoard: "Board",
			tabHome: "Home",
			tabFurnish: "Furnishings",
			myTurn: "Your turn",
			waiting: "Waiting for {{name}}…",
			startPlayerMark: "Start",
			babyMark: "New",
			weaponShort: "W",
			placeHere: "Place dwarf",
			useRubyJump: "Pay 1 ruby to pick any dwarf",
			pickDwarf: "Pick the dwarf to place",
			atLeastOne: "Perform at least one action",
			twinMtn: "Mountain twin",
			twinFor: "Meadow/Field twin",
			faceCavern: "Cavern",
			faceTunnel: "Tunnel",
			faceMeadow: "Meadow",
			faceField: "Field",
			overhangOk: "May overhang (Office Room)",
			sowTitle: "Sow (tap up to 2 grain fields and 2 vegetable fields)",
			pastureSmallLabel: "Small pasture (2 wood)",
			pastureLargeLabel: "Large pasture (4 wood)",
			stableLabel: "Stable (1 stone)",
			forgeTitle: "Forge weapon strength",
			expeditionTitle: "Expedition loot",
			expeditionPick: "Pick up to {{n}} (all different)",
			oreMineTitle: "Ore mine twin: tap 2 adjacent tunnels, then which becomes the mine",
			rubyMineLabel: "Build Ruby mine",
			buyTunnelLabel: "First pay 1 ruby for a tunnel",
			imitateLabel: "Copy a space occupied by an opponent",
			growthGoods: "Take goods",
			growthGrow: "Grow family",
			wishGrow: "Grow family",
			wishDwelling: "Build Dwelling",
			wishGold: "Take 3 gold",
			marketTitle: "Weekly market (max 1 per type)",
			oreTradesLabel: "Ore trades",
			submit: "Confirm",
			cancel: "Cancel",
			dogsHome: "Dogs at home",
			stablesLeft: "Stables",
			furnishingsMine: "My furnishings",
			moveAnimals: "Rearrange animals",
			moveAnimalsHint: "Tap two spaces to swap/move animals, then submit",
			animalsNeedHome: "Animals are placed automatically; those without room become food",
			convertTitle: "Exchange",
			convertFood: "Convert to food",
			buyFood: "Buy food (N food costs N+1 gold)",
			rubyExchange: "Ruby exchange (1:1; cattle costs 1 extra food)",
			rubyTile: "Ruby for tiles (field/meadow/tunnel 1 each, cavern 2)",
			peaceful: "Weapon into food (Peaceful Cave)",
			cookingCave: "1 grain + 1 vegetable = 5 food (Cooking Cave)",
			feedingTitle: "Feeding",
			feedingNeed: "{{n}} more food needed",
			feedingAuto: "Stocked food was used automatically",
			feedingBegging: "The shortfall becomes begging markers (-3 each)",
			feedingConfirm: "Confirm feeding",
			workingCaveFeed: "Working Cave: 1 wood / 1 stone / 2 ore feeds 1 dwarf",
			waitingFeed: "Waiting for others to feed…",
			harvestChoiceTitle: "Harvest event: this round you choose",
			chooseField: "Field phase",
			chooseBreed: "Breeding",
			rubyKeepTitle: "Spaces over 6 goods: pick which to keep for 1 ruby each",
			preScoreTitle: "Pre-scoring trades",
			preScoreDone: "Done, proceed to scoring",
			preScoreHunting: "2 boars → 2 gold 2 food",
			preScoreBeerGold: "2 grain → 3 gold",
			preScoreBeerFood: "2 grain → 4 food",
			preScoreTrader: "2 gold → 1 wood 1 stone 1 ore",
			preScoreSpareParts: "1 wood 1 stone 1 ore → 2 gold",
			preScoreSmithParlor: "1 ruby + 1 ore → 2 gold 1 food",
			waitingPreScore: "Waiting for others to finish trading…",
			revealedEvent: "A new action space was revealed",
			pickSpace: "Tap an action space to place a dwarf",
			mtnSide: "Mountain",
			forSide: "Forest",
			catDwelling: "Dwellings",
			catSpecial: "Special rooms",
			catCraft: "Craft",
			catFood: "Food caves",
			catParlor: "Parlors",
			catStorage: "Storage",
			scorePts: "{{n}} VP",
			takenBy: "Built by {{name}}",
			furnPickCell: "Then tap an empty cavern to place it",
			forgeCost: "Strength {{n}} · pay {{cost}} ore",
			harvestUnknown: "Unknown harvest",
			moveSubmit: "Submit layout",
			overhangB: "Overhang side B (+2 gold)",
			overhangMeadow: "Overhang meadow half (+2 gold)",
			overhangField: "Overhang field half (+2 gold)",
			mineAtLabel: "Mine goes here",
			feedShort: "Short {{n}} · begging",
			lootPicked: "Picked {{n}}/{{max}}",
			marketCost: "Total {{n}} gold",
			convertNow: "Convert",
			rubyPickTarget: "Pay 1 ruby for:",
			buyFoodN: "Buy {{n}} food (pay {{cost}} gold)",
			peacefulPick: "Pick 1 armed dwarf to turn weapon into food",
			dogHomeShort: "Home",
			movePickFirst: "Tap an animal tile first",
			slotMeadow: "Meadow tile",
			slotField: "Field tile",
			slotA: "Tile A",
			slotB: "Tile B",
			buildFurnish: "Pick a furnishing",
			pickTarget: "Pick a space to copy",
			secondExpedition: "Second expedition",
			beggingLabel: "Begging cards",
			errNotYourTurn: "Not your turn yet",
			errBadPhase: "Not allowed in this phase",
			errPending: "A choice is still pending",
			errBadSpace: "This action space is unavailable",
			errOccupied: "This action space is occupied",
			errPlayOrder: "Place dwarfs in ascending weapon order (or pay 1 ruby to skip)",
			errBadDwarf: "This dwarf cannot do that",
			errNoAction: "Perform at least one action",
			errCantAfford: "Not enough resources",
			errBadCell: "This space cannot be used that way",
			errBadPayload: "This action is missing choices",
			errTaken: "Another player already built that furnishing",
			errNotWaiting: "Nothing is waiting for you",
			errBadLoot: "Invalid loot (all different, within weapon strength)",
			errNeedWeapon: "An armed dwarf is required",
			errNoRoom: "No room in your dwellings",
			errBadLayout: "Illegal animal layout (capacity/type conflict)"
		}
	}
};
//#endregion
export { Cn as default };
