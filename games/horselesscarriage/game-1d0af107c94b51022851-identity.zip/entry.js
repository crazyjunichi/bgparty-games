import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useId as r, useLayoutEffect as i, useRef as a, useState as o } from "react";
import { useT as s } from "@bgparty/sdk/i18n";
import { DeltaNumber as c } from "@bgparty/sdk/fx/delta-number";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { SheetView as u } from "@bgparty/sdk/sheet-view";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { useFxAnchor as m, useFxAnchorsMaybe as h } from "@bgparty/sdk/fx/anchors";
import { Floater as g, FlySprite as _, PulseBox as v } from "@bgparty/sdk/fx/primitives";
import { IconExpand as y } from "@bgparty/sdk/icons";
import { ConfirmButton as b } from "@bgparty/sdk/confirm-button";
import { OptionRadio as x, OptionSection as S } from "@bgparty/sdk/ui/game-options";
//#region src/games/horselesscarriage/cards.ts
var C = [
	[
		{
			brand: 0,
			id: 0,
			year: 1,
			clocks: 0,
			points: [{
				x: 1,
				y: 3,
				kind: "sports",
				count: 1
			}]
		},
		{
			brand: 0,
			id: 1,
			year: 1,
			clocks: 0,
			points: [{
				x: 2,
				y: 1,
				kind: "truck",
				count: 1
			}]
		},
		{
			brand: 0,
			id: 2,
			year: 1,
			clocks: 0,
			points: [{
				x: 2,
				y: 1,
				kind: "car",
				count: 1
			}]
		},
		{
			brand: 0,
			id: 3,
			year: 1,
			clocks: 1,
			points: [{
				x: 1,
				y: 1,
				kind: "car",
				count: 1
			}]
		},
		{
			brand: 0,
			id: 4,
			year: 2,
			clocks: 2,
			points: [{
				x: 3,
				y: 1,
				kind: "sports",
				count: 1
			}]
		},
		{
			brand: 0,
			id: 5,
			year: 2,
			clocks: 1,
			points: [{
				x: 0,
				y: 1,
				kind: "truck",
				count: 1
			}]
		},
		{
			brand: 0,
			id: 6,
			year: 2,
			clocks: 2,
			points: [{
				x: 0,
				y: 2,
				kind: "truck",
				count: 1
			}, {
				x: 0,
				y: 0,
				kind: "truck",
				count: 1
			}]
		},
		{
			brand: 0,
			id: 7,
			year: 2,
			clocks: 0,
			points: [{
				x: 0,
				y: 0,
				kind: "car",
				count: 1
			}, {
				x: 1,
				y: 0,
				kind: "car",
				count: 1
			}]
		},
		{
			brand: 0,
			id: 8,
			year: 2,
			clocks: 2,
			points: [{
				x: 2,
				y: 3,
				kind: "car",
				count: 1
			}, {
				x: 1,
				y: 2,
				kind: "car",
				count: 1
			}]
		},
		{
			brand: 0,
			id: 9,
			year: 2,
			clocks: 4,
			points: []
		},
		{
			brand: 0,
			id: 10,
			year: 3,
			clocks: 1,
			points: [
				{
					x: 3,
					y: 3,
					kind: "sports",
					count: 1
				},
				{
					x: 2,
					y: 2,
					kind: "sports",
					count: 1
				},
				{
					x: 1,
					y: 0,
					kind: "car",
					count: 1
				}
			]
		},
		{
			brand: 0,
			id: 11,
			year: 3,
			clocks: 3,
			points: [
				{
					x: 2,
					y: 3,
					kind: "sports",
					count: 1
				},
				{
					x: 3,
					y: 2,
					kind: "sports",
					count: 1
				},
				{
					x: 0,
					y: 0,
					kind: "car",
					count: 1
				}
			]
		},
		{
			brand: 0,
			id: 12,
			year: 3,
			clocks: 1,
			points: [
				{
					x: 0,
					y: 3,
					kind: "truck",
					count: 1
				},
				{
					x: 1,
					y: 2,
					kind: "truck",
					count: 1
				},
				{
					x: 1,
					y: 1,
					kind: "truck",
					count: 1
				}
			]
		},
		{
			brand: 0,
			id: 13,
			year: 3,
			clocks: 3,
			points: [
				{
					x: 1,
					y: 0,
					kind: "truck",
					count: 1
				},
				{
					x: 2,
					y: 0,
					kind: "truck",
					count: 1
				},
				{
					x: 3,
					y: 0,
					kind: "truck",
					count: 1
				}
			]
		},
		{
			brand: 0,
			id: 14,
			year: 3,
			clocks: 0,
			points: [
				{
					x: 3,
					y: 3,
					kind: "car",
					count: 1
				},
				{
					x: 3,
					y: 2,
					kind: "car",
					count: 1
				},
				{
					x: 0,
					y: 1,
					kind: "car",
					count: 1
				}
			]
		},
		{
			brand: 0,
			id: 15,
			year: 3,
			clocks: 3,
			points: [
				{
					x: 0,
					y: 3,
					kind: "car",
					count: 1
				},
				{
					x: 1,
					y: 1,
					kind: "car",
					count: 1
				},
				{
					x: 2,
					y: 1,
					kind: "car",
					count: 1
				}
			]
		},
		{
			brand: 0,
			id: 16,
			year: 4,
			clocks: 1,
			points: [
				{
					x: 1,
					y: 3,
					kind: "car",
					count: 1
				},
				{
					x: 2,
					y: 3,
					kind: "car",
					count: 1
				},
				{
					x: 2,
					y: 2,
					kind: "car",
					count: 2
				}
			]
		}
	],
	[
		{
			brand: 1,
			id: 0,
			year: 1,
			clocks: 0,
			points: [{
				x: 3,
				y: 1,
				kind: "sports",
				count: 1
			}]
		},
		{
			brand: 1,
			id: 1,
			year: 1,
			clocks: 0,
			points: [{
				x: 0,
				y: 2,
				kind: "truck",
				count: 1
			}]
		},
		{
			brand: 1,
			id: 2,
			year: 1,
			clocks: 0,
			points: [{
				x: 0,
				y: 2,
				kind: "car",
				count: 1
			}]
		},
		{
			brand: 1,
			id: 3,
			year: 1,
			clocks: 1,
			points: [{
				x: 0,
				y: 1,
				kind: "car",
				count: 1
			}]
		},
		{
			brand: 1,
			id: 4,
			year: 2,
			clocks: 2,
			points: [{
				x: 1,
				y: 3,
				kind: "sports",
				count: 1
			}]
		},
		{
			brand: 1,
			id: 5,
			year: 2,
			clocks: 1,
			points: [{
				x: 1,
				y: 1,
				kind: "truck",
				count: 1
			}]
		},
		{
			brand: 1,
			id: 6,
			year: 2,
			clocks: 2,
			points: [{
				x: 1,
				y: 0,
				kind: "truck",
				count: 1
			}, {
				x: 3,
				y: 0,
				kind: "truck",
				count: 1
			}]
		},
		{
			brand: 1,
			id: 7,
			year: 2,
			clocks: 0,
			points: [{
				x: 1,
				y: 1,
				kind: "car",
				count: 1
			}, {
				x: 1,
				y: 0,
				kind: "car",
				count: 1
			}]
		},
		{
			brand: 1,
			id: 8,
			year: 2,
			clocks: 2,
			points: [{
				x: 3,
				y: 1,
				kind: "car",
				count: 1
			}, {
				x: 2,
				y: 0,
				kind: "car",
				count: 1
			}]
		},
		{
			brand: 1,
			id: 9,
			year: 2,
			clocks: 4,
			points: []
		},
		{
			brand: 1,
			id: 10,
			year: 3,
			clocks: 1,
			points: [
				{
					x: 3,
					y: 3,
					kind: "sports",
					count: 1
				},
				{
					x: 2,
					y: 2,
					kind: "sports",
					count: 1
				},
				{
					x: 1,
					y: 1,
					kind: "car",
					count: 1
				}
			]
		},
		{
			brand: 1,
			id: 11,
			year: 3,
			clocks: 3,
			points: [
				{
					x: 2,
					y: 3,
					kind: "sports",
					count: 1
				},
				{
					x: 3,
					y: 2,
					kind: "sports",
					count: 1
				},
				{
					x: 1,
					y: 0,
					kind: "car",
					count: 1
				}
			]
		},
		{
			brand: 1,
			id: 12,
			year: 3,
			clocks: 1,
			points: [
				{
					x: 0,
					y: 3,
					kind: "truck",
					count: 1
				},
				{
					x: 1,
					y: 2,
					kind: "truck",
					count: 1
				},
				{
					x: 0,
					y: 1,
					kind: "truck",
					count: 1
				}
			]
		},
		{
			brand: 1,
			id: 13,
			year: 3,
			clocks: 3,
			points: [
				{
					x: 2,
					y: 1,
					kind: "truck",
					count: 1
				},
				{
					x: 0,
					y: 0,
					kind: "truck",
					count: 1
				},
				{
					x: 2,
					y: 0,
					kind: "truck",
					count: 1
				}
			]
		},
		{
			brand: 1,
			id: 14,
			year: 3,
			clocks: 0,
			points: [
				{
					x: 3,
					y: 3,
					kind: "car",
					count: 1
				},
				{
					x: 3,
					y: 2,
					kind: "car",
					count: 1
				},
				{
					x: 0,
					y: 0,
					kind: "car",
					count: 1
				}
			]
		},
		{
			brand: 1,
			id: 15,
			year: 3,
			clocks: 3,
			points: [
				{
					x: 0,
					y: 2,
					kind: "car",
					count: 1
				},
				{
					x: 0,
					y: 1,
					kind: "car",
					count: 1
				},
				{
					x: 2,
					y: 0,
					kind: "car",
					count: 1
				}
			]
		},
		{
			brand: 1,
			id: 16,
			year: 4,
			clocks: 1,
			points: [
				{
					x: 1,
					y: 3,
					kind: "car",
					count: 1
				},
				{
					x: 2,
					y: 3,
					kind: "car",
					count: 2
				},
				{
					x: 2,
					y: 2,
					kind: "car",
					count: 1
				}
			]
		}
	],
	[
		{
			brand: 2,
			id: 0,
			year: 1,
			clocks: 0,
			points: [{
				x: 3,
				y: 1,
				kind: "sports",
				count: 1
			}]
		},
		{
			brand: 2,
			id: 1,
			year: 1,
			clocks: 0,
			points: [{
				x: 2,
				y: 0,
				kind: "truck",
				count: 1
			}]
		},
		{
			brand: 2,
			id: 2,
			year: 1,
			clocks: 0,
			points: [{
				x: 1,
				y: 2,
				kind: "car",
				count: 1
			}]
		},
		{
			brand: 2,
			id: 3,
			year: 1,
			clocks: 1,
			points: [{
				x: 1,
				y: 1,
				kind: "car",
				count: 1
			}]
		},
		{
			brand: 2,
			id: 4,
			year: 2,
			clocks: 2,
			points: [{
				x: 1,
				y: 3,
				kind: "sports",
				count: 1
			}]
		},
		{
			brand: 2,
			id: 5,
			year: 2,
			clocks: 2,
			points: [{
				x: 1,
				y: 2,
				kind: "truck",
				count: 1
			}, {
				x: 0,
				y: 0,
				kind: "truck",
				count: 1
			}]
		},
		{
			brand: 2,
			id: 6,
			year: 2,
			clocks: 1,
			points: [{
				x: 1,
				y: 0,
				kind: "truck",
				count: 1
			}]
		},
		{
			brand: 2,
			id: 7,
			year: 2,
			clocks: 0,
			points: [{
				x: 0,
				y: 1,
				kind: "car",
				count: 1
			}, {
				x: 0,
				y: 0,
				kind: "car",
				count: 1
			}]
		},
		{
			brand: 2,
			id: 8,
			year: 2,
			clocks: 2,
			points: [{
				x: 3,
				y: 2,
				kind: "car",
				count: 1
			}, {
				x: 2,
				y: 1,
				kind: "car",
				count: 1
			}]
		},
		{
			brand: 2,
			id: 9,
			year: 2,
			clocks: 4,
			points: []
		},
		{
			brand: 2,
			id: 10,
			year: 3,
			clocks: 1,
			points: [
				{
					x: 3,
					y: 3,
					kind: "sports",
					count: 1
				},
				{
					x: 2,
					y: 2,
					kind: "sports",
					count: 1
				},
				{
					x: 0,
					y: 0,
					kind: "car",
					count: 1
				}
			]
		},
		{
			brand: 2,
			id: 11,
			year: 3,
			clocks: 3,
			points: [
				{
					x: 2,
					y: 3,
					kind: "sports",
					count: 1
				},
				{
					x: 3,
					y: 2,
					kind: "sports",
					count: 1
				},
				{
					x: 0,
					y: 1,
					kind: "car",
					count: 1
				}
			]
		},
		{
			brand: 2,
			id: 12,
			year: 3,
			clocks: 1,
			points: [
				{
					x: 1,
					y: 1,
					kind: "truck",
					count: 1
				},
				{
					x: 2,
					y: 1,
					kind: "truck",
					count: 1
				},
				{
					x: 3,
					y: 0,
					kind: "truck",
					count: 1
				}
			]
		},
		{
			brand: 2,
			id: 13,
			year: 3,
			clocks: 3,
			points: [
				{
					x: 0,
					y: 3,
					kind: "truck",
					count: 1
				},
				{
					x: 0,
					y: 2,
					kind: "truck",
					count: 1
				},
				{
					x: 0,
					y: 1,
					kind: "truck",
					count: 1
				}
			]
		},
		{
			brand: 2,
			id: 14,
			year: 3,
			clocks: 0,
			points: [
				{
					x: 1,
					y: 3,
					kind: "car",
					count: 1
				},
				{
					x: 2,
					y: 3,
					kind: "car",
					count: 1
				},
				{
					x: 1,
					y: 0,
					kind: "car",
					count: 1
				}
			]
		},
		{
			brand: 2,
			id: 15,
			year: 3,
			clocks: 3,
			points: [
				{
					x: 1,
					y: 2,
					kind: "car",
					count: 1
				},
				{
					x: 1,
					y: 1,
					kind: "car",
					count: 1
				},
				{
					x: 3,
					y: 0,
					kind: "car",
					count: 1
				}
			]
		},
		{
			brand: 2,
			id: 16,
			year: 4,
			clocks: 1,
			points: [
				{
					x: 3,
					y: 3,
					kind: "car",
					count: 1
				},
				{
					x: 2,
					y: 2,
					kind: "car",
					count: 1
				},
				{
					x: 3,
					y: 2,
					kind: "car",
					count: 2
				}
			]
		}
	],
	[
		{
			brand: 3,
			id: 0,
			year: 1,
			clocks: 0,
			points: [{
				x: 1,
				y: 3,
				kind: "sports",
				count: 1
			}]
		},
		{
			brand: 3,
			id: 1,
			year: 1,
			clocks: 0,
			points: [{
				x: 1,
				y: 2,
				kind: "truck",
				count: 1
			}]
		},
		{
			brand: 3,
			id: 2,
			year: 1,
			clocks: 0,
			points: [{
				x: 2,
				y: 0,
				kind: "car",
				count: 1
			}]
		},
		{
			brand: 3,
			id: 3,
			year: 1,
			clocks: 1,
			points: [{
				x: 1,
				y: 0,
				kind: "car",
				count: 1
			}]
		},
		{
			brand: 3,
			id: 4,
			year: 2,
			clocks: 2,
			points: [{
				x: 3,
				y: 1,
				kind: "sports",
				count: 1
			}]
		},
		{
			brand: 3,
			id: 5,
			year: 2,
			clocks: 1,
			points: [{
				x: 0,
				y: 1,
				kind: "truck",
				count: 1
			}]
		},
		{
			brand: 3,
			id: 6,
			year: 2,
			clocks: 2,
			points: [{
				x: 0,
				y: 0,
				kind: "truck",
				count: 1
			}, {
				x: 2,
				y: 0,
				kind: "truck",
				count: 1
			}]
		},
		{
			brand: 3,
			id: 7,
			year: 2,
			clocks: 0,
			points: [{
				x: 0,
				y: 1,
				kind: "car",
				count: 1
			}, {
				x: 1,
				y: 1,
				kind: "car",
				count: 1
			}]
		},
		{
			brand: 3,
			id: 8,
			year: 2,
			clocks: 2,
			points: [{
				x: 1,
				y: 3,
				kind: "car",
				count: 1
			}, {
				x: 0,
				y: 2,
				kind: "car",
				count: 1
			}]
		},
		{
			brand: 3,
			id: 9,
			year: 2,
			clocks: 4,
			points: []
		},
		{
			brand: 3,
			id: 10,
			year: 3,
			clocks: 1,
			points: [
				{
					x: 3,
					y: 3,
					kind: "sports",
					count: 1
				},
				{
					x: 2,
					y: 2,
					kind: "sports",
					count: 1
				},
				{
					x: 1,
					y: 1,
					kind: "car",
					count: 1
				}
			]
		},
		{
			brand: 3,
			id: 11,
			year: 3,
			clocks: 3,
			points: [
				{
					x: 2,
					y: 3,
					kind: "sports",
					count: 1
				},
				{
					x: 3,
					y: 2,
					kind: "sports",
					count: 1
				},
				{
					x: 0,
					y: 1,
					kind: "car",
					count: 1
				}
			]
		},
		{
			brand: 3,
			id: 12,
			year: 3,
			clocks: 1,
			points: [
				{
					x: 0,
					y: 3,
					kind: "truck",
					count: 1
				},
				{
					x: 0,
					y: 2,
					kind: "truck",
					count: 1
				},
				{
					x: 1,
					y: 1,
					kind: "truck",
					count: 1
				}
			]
		},
		{
			brand: 3,
			id: 13,
			year: 3,
			clocks: 3,
			points: [
				{
					x: 2,
					y: 1,
					kind: "truck",
					count: 1
				},
				{
					x: 1,
					y: 0,
					kind: "truck",
					count: 1
				},
				{
					x: 3,
					y: 0,
					kind: "truck",
					count: 1
				}
			]
		},
		{
			brand: 3,
			id: 14,
			year: 3,
			clocks: 0,
			points: [
				{
					x: 2,
					y: 3,
					kind: "car",
					count: 1
				},
				{
					x: 3,
					y: 3,
					kind: "car",
					count: 1
				},
				{
					x: 0,
					y: 0,
					kind: "car",
					count: 1
				}
			]
		},
		{
			brand: 3,
			id: 15,
			year: 3,
			clocks: 3,
			points: [
				{
					x: 0,
					y: 2,
					kind: "car",
					count: 1
				},
				{
					x: 1,
					y: 0,
					kind: "car",
					count: 1
				},
				{
					x: 2,
					y: 0,
					kind: "car",
					count: 1
				}
			]
		},
		{
			brand: 3,
			id: 16,
			year: 4,
			clocks: 1,
			points: [
				{
					x: 2,
					y: 2,
					kind: "car",
					count: 2
				},
				{
					x: 3,
					y: 2,
					kind: "car",
					count: 1
				},
				{
					x: 3,
					y: 1,
					kind: "car",
					count: 1
				}
			]
		}
	],
	[
		{
			brand: 4,
			id: 0,
			year: 1,
			clocks: 0,
			points: [{
				x: 3,
				y: 1,
				kind: "sports",
				count: 1
			}]
		},
		{
			brand: 4,
			id: 1,
			year: 1,
			clocks: 0,
			points: [{
				x: 2,
				y: 0,
				kind: "truck",
				count: 1
			}]
		},
		{
			brand: 4,
			id: 2,
			year: 1,
			clocks: 0,
			points: [{
				x: 2,
				y: 0,
				kind: "car",
				count: 1
			}]
		},
		{
			brand: 4,
			id: 3,
			year: 1,
			clocks: 1,
			points: [{
				x: 1,
				y: 0,
				kind: "car",
				count: 1
			}]
		},
		{
			brand: 4,
			id: 4,
			year: 2,
			clocks: 2,
			points: [{
				x: 1,
				y: 3,
				kind: "sports",
				count: 1
			}]
		},
		{
			brand: 4,
			id: 5,
			year: 2,
			clocks: 1,
			points: [{
				x: 1,
				y: 1,
				kind: "truck",
				count: 1
			}]
		},
		{
			brand: 4,
			id: 6,
			year: 2,
			clocks: 2,
			points: [{
				x: 0,
				y: 3,
				kind: "truck",
				count: 1
			}, {
				x: 0,
				y: 1,
				kind: "truck",
				count: 1
			}]
		},
		{
			brand: 4,
			id: 7,
			year: 2,
			clocks: 0,
			points: [{
				x: 0,
				y: 1,
				kind: "car",
				count: 1
			}, {
				x: 1,
				y: 1,
				kind: "car",
				count: 1
			}]
		},
		{
			brand: 4,
			id: 8,
			year: 2,
			clocks: 2,
			points: [{
				x: 2,
				y: 2,
				kind: "car",
				count: 1
			}, {
				x: 1,
				y: 1,
				kind: "car",
				count: 1
			}]
		},
		{
			brand: 4,
			id: 9,
			year: 2,
			clocks: 4,
			points: []
		},
		{
			brand: 4,
			id: 10,
			year: 3,
			clocks: 1,
			points: [
				{
					x: 3,
					y: 3,
					kind: "sports",
					count: 1
				},
				{
					x: 2,
					y: 2,
					kind: "sports",
					count: 1
				},
				{
					x: 0,
					y: 1,
					kind: "car",
					count: 1
				}
			]
		},
		{
			brand: 4,
			id: 11,
			year: 3,
			clocks: 3,
			points: [
				{
					x: 2,
					y: 3,
					kind: "sports",
					count: 1
				},
				{
					x: 3,
					y: 2,
					kind: "sports",
					count: 1
				},
				{
					x: 1,
					y: 1,
					kind: "car",
					count: 1
				}
			]
		},
		{
			brand: 4,
			id: 12,
			year: 3,
			clocks: 1,
			points: [
				{
					x: 2,
					y: 1,
					kind: "truck",
					count: 1
				},
				{
					x: 1,
					y: 0,
					kind: "truck",
					count: 1
				},
				{
					x: 3,
					y: 0,
					kind: "truck",
					count: 1
				}
			]
		},
		{
			brand: 4,
			id: 13,
			year: 3,
			clocks: 3,
			points: [
				{
					x: 0,
					y: 2,
					kind: "truck",
					count: 1
				},
				{
					x: 1,
					y: 2,
					kind: "truck",
					count: 1
				},
				{
					x: 0,
					y: 0,
					kind: "truck",
					count: 1
				}
			]
		},
		{
			brand: 4,
			id: 14,
			year: 3,
			clocks: 0,
			points: [
				{
					x: 3,
					y: 2,
					kind: "car",
					count: 1
				},
				{
					x: 3,
					y: 1,
					kind: "car",
					count: 1
				},
				{
					x: 0,
					y: 0,
					kind: "car",
					count: 1
				}
			]
		},
		{
			brand: 4,
			id: 15,
			year: 3,
			clocks: 3,
			points: [
				{
					x: 1,
					y: 2,
					kind: "car",
					count: 1
				},
				{
					x: 1,
					y: 0,
					kind: "car",
					count: 1
				},
				{
					x: 2,
					y: 0,
					kind: "car",
					count: 1
				}
			]
		},
		{
			brand: 4,
			id: 16,
			year: 4,
			clocks: 1,
			points: [
				{
					x: 2,
					y: 3,
					kind: "car",
					count: 1
				},
				{
					x: 3,
					y: 3,
					kind: "car",
					count: 2
				},
				{
					x: 2,
					y: 2,
					kind: "car",
					count: 1
				}
			]
		}
	]
], w = [
	"speed",
	"reliability",
	"design",
	"range",
	"safety"
], ee = [
	"A",
	"B",
	"C",
	"D"
], T = [
	"car",
	"truck",
	"sports"
], te = [
	"chassis",
	"bumpers",
	"body",
	"radiator",
	"door",
	"engine",
	"fuelTank",
	"gears",
	"brakes",
	"steering",
	"dashboard",
	"battery",
	"paint",
	"claxon",
	"windshield",
	"tires",
	"headlights"
], E = {
	speed: [
		"engine",
		"claxon",
		"gears",
		"tires",
		"fuelTank",
		"dashboard"
	],
	reliability: [
		"battery",
		"chassis",
		"body",
		"bumpers",
		"engine",
		"chassis"
	],
	design: [
		"paint",
		"door",
		"headlights",
		"dashboard",
		"body",
		"steering"
	],
	range: [
		"engine",
		"radiator",
		"tires",
		"fuelTank",
		"radiator",
		"gears"
	],
	safety: [
		"brakes",
		"windshield",
		"steering",
		"bumpers",
		"headlights",
		"tires"
	]
}, D = {
	chassis: {
		step: "A",
		w: 3,
		h: 4,
		stock: 6
	},
	bumpers: {
		step: "A",
		w: 4,
		h: 1,
		stock: 10
	},
	body: {
		step: "A",
		w: 3,
		h: 3,
		stock: 6
	},
	radiator: {
		step: "A",
		w: 2,
		h: 3,
		stock: 10
	},
	door: {
		step: "A",
		w: 2,
		h: 2,
		stock: 10
	},
	engine: {
		step: "B",
		w: 4,
		h: 4,
		stock: 6
	},
	fuelTank: {
		step: "B",
		w: 4,
		h: 2,
		stock: 6
	},
	gears: {
		step: "B",
		w: 3,
		h: 4,
		stock: 6
	},
	brakes: {
		step: "B",
		w: 2,
		h: 2,
		stock: 10
	},
	steering: {
		step: "B",
		w: 3,
		h: 3,
		stock: 6
	},
	dashboard: {
		step: "C",
		w: 4,
		h: 2,
		stock: 6
	},
	battery: {
		step: "C",
		w: 2,
		h: 2,
		stock: 10
	},
	paint: {
		step: "C",
		w: 2,
		h: 3,
		stock: 10
	},
	claxon: {
		step: "D",
		w: 2,
		h: 2,
		stock: 10
	},
	windshield: {
		step: "D",
		w: 4,
		h: 2,
		stock: 10
	},
	tires: {
		step: "D",
		w: 3,
		h: 3,
		stock: 6
	},
	headlights: {
		step: "D",
		w: 2,
		h: 3,
		stock: 6
	}
}, O = {
	A: {
		design: 16,
		reliability: 28,
		safety: 10,
		range: 20
	},
	B: {
		design: 6,
		reliability: 6,
		range: 18,
		speed: 18,
		safety: 16
	},
	C: {
		design: 16,
		reliability: 10,
		speed: 6
	},
	D: {
		speed: 16,
		safety: 22,
		range: 6,
		design: 6
	}
}, ne = [
	...te,
	"car",
	"truck",
	"sports",
	"dealer0",
	"dealer1",
	"dealer2",
	"research",
	"planning",
	"marketing",
	"spec"
], k = {
	...te.reduce((e, t) => ({
		...e,
		[t]: [D[t].w, D[t].h]
	}), {}),
	car: [4, 3],
	truck: [6, 3],
	sports: [5, 3],
	dealer0: [4, 3],
	dealer1: [4, 4],
	dealer2: [5, 4],
	research: [3, 3],
	planning: [2, 3],
	marketing: [4, 3],
	spec: [1, 1]
}, re = [
	"Alexander Wilson",
	"Giovanni Agnelli",
	"Armand Peugeot",
	"Bertha Benz",
	"Henry Ford"
], ie = [
	[
		"Luton",
		"Dunstable",
		"Ellesmere Port"
	],
	[
		"Pomigliano d’Arco",
		"Grugliasco",
		"Torino"
	],
	[
		"Sochaux",
		"Fives-Lille",
		"Audincourt"
	],
	[
		"Mannheim",
		"Ladenburg",
		"Stuttgart"
	],
	[
		"Detroit",
		"Dearborn",
		"Kansas City"
	]
], A = {
	speed: "#b84636",
	reliability: "#3d7da1",
	design: "#785686",
	range: "#5e7750",
	safety: "#bf8622"
}, j = {
	car: "#663c59",
	truck: "#bd6b23",
	sports: "#39899a"
}, ae = {
	speed: "games.horselesscarriage.speed",
	reliability: "games.horselesscarriage.reliability",
	design: "games.horselesscarriage.design",
	range: "games.horselesscarriage.range",
	safety: "games.horselesscarriage.safety"
}, oe = {
	chassis: "games.horselesscarriage.chassis",
	bumpers: "games.horselesscarriage.bumpers",
	body: "games.horselesscarriage.body",
	radiator: "games.horselesscarriage.radiator",
	door: "games.horselesscarriage.door",
	engine: "games.horselesscarriage.engine",
	fuelTank: "games.horselesscarriage.fuelTank",
	gears: "games.horselesscarriage.gears",
	brakes: "games.horselesscarriage.brakes",
	steering: "games.horselesscarriage.steering",
	dashboard: "games.horselesscarriage.dashboard",
	battery: "games.horselesscarriage.battery",
	paint: "games.horselesscarriage.paint",
	claxon: "games.horselesscarriage.claxon",
	windshield: "games.horselesscarriage.windshield",
	tires: "games.horselesscarriage.tires",
	headlights: "games.horselesscarriage.headlights",
	car: "games.horselesscarriage.car",
	truck: "games.horselesscarriage.truck",
	sports: "games.horselesscarriage.sports",
	dealer0: "games.horselesscarriage.dealer",
	dealer1: "games.horselesscarriage.dealer",
	dealer2: "games.horselesscarriage.dealer",
	research: "games.horselesscarriage.research",
	planning: "games.horselesscarriage.planning",
	marketing: "games.horselesscarriage.marketing",
	spec: "games.horselesscarriage.spec"
}, M = [
	[{
		x: 0,
		y: 0,
		kind: "car",
		count: 1
	}],
	[{
		x: 1,
		y: 0,
		kind: "car",
		count: 1
	}],
	[{
		x: 2,
		y: 0,
		kind: "car",
		count: 1
	}],
	[{
		x: 0,
		y: 1,
		kind: "car",
		count: 1
	}],
	[{
		x: 1,
		y: 1,
		kind: "car",
		count: 1
	}],
	[{
		x: 0,
		y: 2,
		kind: "car",
		count: 1
	}],
	[{
		x: 0,
		y: 0,
		kind: "truck",
		count: 1
	}]
], N = (e) => te.includes(e), P = (e) => T.includes(e), F = (e) => e.startsWith("dealer"), I = () => ({
	speed: 0,
	reliability: 0,
	design: 0,
	range: 0,
	safety: 0
}), L = (e, t) => `${e},${t}`, R = (e, t) => [
	[e + 1, t],
	[e, t + 1],
	[e - 1, t],
	[e, t - 1]
];
function z(e) {
	let [t, n] = k[e.item];
	return {
		x: e.x,
		y: e.y,
		w: e.r % 2 ? n : t,
		h: e.r % 2 ? t : n
	};
}
function se(e) {
	return Array.from({ length: e.w * e.h }, (t, n) => [e.x + n % e.w, e.y + Math.floor(n / e.w)]);
}
function B(e, t) {
	return (e.x + e.w === t.x || t.x + t.w === e.x) && Math.max(e.y, t.y) < Math.min(e.y + e.h, t.y + t.h) || (e.y + e.h === t.y || t.y + t.h === e.y) && Math.max(e.x, t.x) < Math.min(e.x + e.w, t.x + t.w);
}
function ce(e, t, n, r, i) {
	return i === 1 ? [r - 1 - t, e] : i === 2 ? [n - 1 - e, r - 1 - t] : i === 3 ? [t, n - 1 - e] : [e, t];
}
function V(e, t = !1) {
	let n = t ? 12 : 8, r = t ? 12 : 6, i = t ? 5 : 2, a = [], o = [], s = [], c = (t, i) => {
		let [a, o] = ce(t, i, n, r, e.r);
		return [e.x + a, e.y + o];
	};
	for (let e = 0; e < r; e++) for (let r = 0; r < n; r++) a.push(c(r, e)), e < i && (t ? r < i : r >= n - i) && o.push(c(r, e));
	for (let e = 0; e < i; e++) s.push(c(t ? e : n - i + e, -1)), s.push(c(t ? -1 : n, e));
	return {
		all: a,
		bays: o,
		clear: s,
		bounds: {
			x: e.x,
			y: e.y,
			w: e.r % 2 ? r : n,
			h: e.r % 2 ? n : r
		}
	};
}
function le(e) {
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Set();
	return e.forEach((e, i) => {
		let a = V(e, i === 0);
		a.all.forEach(([e, n]) => t.add(L(e, n))), a.bays.forEach(([e, t]) => n.add(L(e, t))), a.clear.forEach(([e, t]) => r.add(L(e, t)));
	}), {
		all: t,
		bays: n,
		clear: r
	};
}
function ue(e, t) {
	if (e.length >= 7) return !1;
	let n = le(e), r = V(t), i = new Set(r.all.map(([e, t]) => L(e, t)));
	return r.all.some(([e, t]) => n.all.has(L(e, t)) || n.clear.has(L(e, t))) || r.clear.some(([e, t]) => n.all.has(L(e, t))) ? !1 : r.all.some(([e, t]) => R(e, t).some(([e, t]) => n.all.has(L(e, t)) && !i.has(L(e, t))));
}
function de(e, t, n, r) {
	let i = e.players.find((e) => e.rid === t);
	return i ? i.research[n] >= r || e.players.filter((e) => e.rid !== t && e.research[n] >= r).length >= e.order.indexOf(t) + 1 : !1;
}
function fe(e, t, n) {
	return w.flatMap((r) => E[r].flatMap((i, a) => i === n && de(e, t, r, a + 1) ? [{
		dim: r,
		level: a + 1
	}] : []));
}
function pe(e, t) {
	if (N(e.item)) return D[e.item].step;
	if (e.item === "spec") {
		let n = t.find((t) => t.id === e.target);
		if (n && N(n.item)) return D[n.item].step;
	}
	return null;
}
function me(e, t) {
	let n = z(e), r = z(t);
	return B(n, r) ? [
		"D",
		"B",
		"A",
		"C"
	][((r.y + r.h === n.y ? 0 : r.x === n.x + n.w ? 1 : r.y === n.y + n.h ? 2 : 3) - e.r + 4) % 4] : null;
}
function he(e) {
	let t = [];
	for (let n of ee) {
		let r = e.filter((t) => P(t.item) || pe(t, e) === n), i = new Set(r.map((e) => e.id)), a = (e, t) => B(z(e), z(t)) && (!P(e.item) || me(e, t) === n) && (!P(t.item) || me(t, e) === n);
		for (; i.size;) {
			let e = [r.find((e) => e.id === i.values().next().value)];
			i.delete(e[0].id);
			for (let t = 0; t < e.length; t++) for (let n of r) i.has(n.id) && a(e[t], n) && (e.push(n), i.delete(n.id));
			t.push({
				step: n,
				tiles: e.filter((e) => !P(e.item)),
				lines: e.filter((e) => P(e.item))
			});
		}
	}
	return t;
}
var ge = {
	overlap: "games.horselesscarriage.errOverlap",
	outside: "games.horselesscarriage.errOutside",
	disconnected: "games.horselesscarriage.errDisconnected",
	dealerConnection: "games.horselesscarriage.errDealer",
	marketingConnection: "games.horselesscarriage.errMarketing",
	technologyAccess: "games.horselesscarriage.errTechnology",
	specRequired: "games.horselesscarriage.errSpec",
	specTarget: "games.horselesscarriage.errArrow",
	duplicateTech: "games.horselesscarriage.errDuplicate",
	manufacturing: "games.horselesscarriage.errManufacturing",
	stock: "games.horselesscarriage.errStock",
	expansion: "games.horselesscarriage.errExpansion",
	startTiles: "games.horselesscarriage.errStart"
};
function _e(e, t, n, r = !1) {
	let i = [...t.tiles, ...n];
	if (new Set(i.map((e) => e.id)).size !== i.length) return "overlap";
	if (r && (n.length !== 2 || n.filter((e) => e.item === "research").length !== 1 || n.filter((e) => e.item === "planning").length !== 1)) return "startTiles";
	let a = le(t.floors), o = /* @__PURE__ */ new Map();
	for (let e of i) for (let [t, n] of se(z(e))) {
		let r = L(t, n);
		if (!a.all.has(r) || a.bays.has(r)) return "outside";
		if (o.has(r)) return "overlap";
		o.set(r, e.id);
	}
	let s = /* @__PURE__ */ new Set(), c = i.filter((e) => se(z(e)).some(([e, t]) => R(e, t).some(([e, t]) => a.bays.has(L(e, t)))));
	c.forEach((e) => s.add(e.id));
	for (let e = 0; e < c.length; e++) for (let t of i) !s.has(t.id) && B(z(t), z(c[e])) && (c.push(t), s.add(t.id));
	if (s.size !== i.length) return "disconnected";
	for (let r of i) {
		let a = i.filter((e) => e.id !== r.id && B(z(r), z(e)));
		if (P(r.item) && !a.some((e) => F(e.item)) || F(r.item) && !a.some((e) => P(e.item))) return "dealerConnection";
		if (r.item === "marketing" && !a.some((e) => F(e.item))) return "marketingConnection";
		if (N(r.item) && !i.some((e) => e.item === "spec" && e.target === r.id)) return "specRequired";
		if (r.item === "spec") {
			let a = i.find((e) => e.id === r.target);
			if (!a || !N(a.item) || !r.dim || !r.level || E[r.dim][r.level - 1] !== a.item) return "specTarget";
			let [o, s] = [
				[1, 0],
				[0, 1],
				[-1, 0],
				[0, -1]
			][r.r], c = z(a);
			if (r.x + o < c.x || r.x + o >= c.x + c.w || r.y + s < c.y || r.y + s >= c.y + c.h || i.some((e) => e.id !== r.id && e.item === "spec" && e.target === r.target && e.dim === r.dim && e.level === r.level)) return "specTarget";
			if (n.includes(r) && !de(e, t.rid, r.dim, r.level)) return "technologyAccess";
		}
		if (n.includes(r) && N(r.item) && fe(e, t.rid, r.item).length === 0) return "technologyAccess";
	}
	for (let e of he(i)) {
		if (e.tiles.length && !e.lines.length) return "manufacturing";
		let t = e.tiles.filter((e) => N(e.item)).map((e) => e.item);
		if (new Set(t).size !== t.length) return "duplicateTech";
	}
	let l = e.players.flatMap((e) => e.rid === t.rid ? i : e.tiles), u = e.players.length;
	for (let r of n) {
		let n, a;
		if (r.item === "spec") {
			let o = pe(r, i);
			n = O[o][r.dim] ?? 0, a = e.players.flatMap((e) => {
				let n = e.rid === t.rid ? i : e.tiles;
				return n.filter((e) => e.item === "spec" && e.dim === r.dim && pe(e, n) === o);
			});
		} else n = N(r.item) ? D[r.item].stock - (5 - u) * (D[r.item].stock === 6 ? 1 : 2) : P(r.item) ? u * 2 : r.item === "research" ? u * 5 : r.item === "planning" ? u * 6 : r.item === "marketing" ? 4 : 1, a = (F(r.item) || r.item === "marketing" ? i : l).filter((e) => e.item === r.item);
		if (a.length > n) return "stock";
	}
	return null;
}
function ve(e, t = !1) {
	let n = he(e.tiles), r = /* @__PURE__ */ new Map();
	for (let t of e.tiles.filter((e) => P(e.item))) {
		let e = I();
		for (let r of n.filter((e) => e.lines.some((e) => e.id === t.id))) for (let t of r.tiles.filter((e) => e.item === "spec" && e.dim)) e[t.dim]++;
		r.set(t.id, e);
	}
	return e.tiles.filter((e) => F(e.item)).map((n) => {
		let i = e.tiles.filter((e) => P(e.item) && B(z(e), z(n))), a = I();
		for (let e of w) a[e] = i.length ? Math.min(...i.map((t) => r.get(t.id)[e])) : 0;
		let o = {
			car: 0,
			truck: 0,
			sports: 0
		};
		for (let n of i) o[t ? "car" : n.item] += Math.max(0, e.capacity - (e.used[n.id] ?? 0));
		return {
			tile: n,
			lines: i,
			specs: a,
			capacity: o,
			stretch: Math.min(2, e.tiles.filter((e) => e.item === "marketing" && B(z(e), z(n))).length)
		};
	});
}
function ye(e, t, n) {
	let r = e.players.flatMap((e) => e.tiles), i = e.players.length;
	return (N(t) ? D[t].stock - (5 - i) * (D[t].stock === 6 ? 1 : 2) : P(t) ? i * 2 : t === "research" ? i * 5 : t === "planning" ? i * 6 : t === "marketing" ? 4 : 1) - (F(t) || t === "marketing" ? n.tiles : r).filter((e) => e.item === t).length;
}
//#endregion
//#region src/games/horselesscarriage/market.ts
var be = (e, t) => t * 8 + e, xe = (e, t) => Math.floor((e + t) / 4), Se = (e, t) => e.stretch === 2 ? [3, 3] : e.stretch === 1 ? [2, 2] : t.vertical ? [1, 2] : [2, 1];
function Ce(e, t) {
	return w.every((n) => t.specs[n] >= e.minimum[n]);
}
function we(e, t, n, r) {
	return t.specs[e.axes[0]] >= e.minimum[e.axes[0]] + Math.floor(n / 2) && t.specs[e.axes[1]] >= e.minimum[e.axes[1]] + Math.floor(r / 2);
}
function Te(e, t, n) {
	if (!Ce(e, t)) return !1;
	let [r, i] = Se(t, n), a = 0;
	for (let o = n.y; o < n.y + i; o++) for (let i = n.x; i < n.x + r; i++) if (!(i < 0 || o < 0 || i > 7 || o > 7) && (a++, !we(e, t, i, o))) return !1;
	return a > 0;
}
function H(e, t, n, r) {
	let [i, a] = Se(e, t);
	return n >= t.x && r >= t.y && n < t.x + i && r < t.y + a;
}
function Ee(e, t, n, r) {
	let i = [];
	for (let a of t.stretch === 0 ? [!1, !0] : [!1]) {
		let [o, s] = Se(t, {
			x: 0,
			y: 0,
			vertical: a
		});
		for (let c = 1 - s; c < 8; c++) for (let s = 1 - o; s < 8; s++) {
			let o = {
				x: s,
				y: c,
				vertical: a
			};
			(n === void 0 || r === void 0 || H(t, o, n, r)) && Te(e, t, o) && i.push(o);
		}
	}
	return i;
}
function De(e, t, n, r) {
	let i = e.buyers[be(n, r)], a = {
		car: 0,
		truck: 0,
		sports: 0
	}, o = 0;
	for (let s of T) a[s] = Math.min(i[s], t.capacity[s]), o += a[s] * (e.prices[xe(n, r)] + (s === "truck" ? 1 : s === "sports" ? 2 : 0));
	return {
		counts: a,
		income: o
	};
}
function Oe(e, t, n = !1) {
	let r = [];
	for (let i of ve(t, e.introductory)) {
		if (!Ce(e, i) || !T.some((e) => i.capacity[e] > 0)) continue;
		let a = t.windows[i.tile.id];
		for (let t = 0; t < 8; t++) for (let o = 0; o < 8; o++) {
			if (!we(e, i, o, t)) continue;
			let s = De(e, i, o, t);
			if (!T.some((e) => s.counts[e] > 0)) continue;
			let c = a ? H(i, a, o, t) ? [a] : [] : Ee(e, i, o, t);
			for (let e of n ? c : c.slice(0, 1)) r.push({
				dealer: i.tile.id,
				x: o,
				y: t,
				window: a ? null : e,
				...s
			});
		}
	}
	return r;
}
function ke(e, t, n) {
	let r = { ...e.minimum };
	return r[e.axes[0]] += Math.floor(t / 2), r[e.axes[1]] += Math.floor(n / 2), r;
}
//#endregion
//#region src/games/horselesscarriage/meta.ts
var Ae = {
	id: "horselesscarriage",
	tier: "alpha",
	nameKey: "games.horselesscarriage.name",
	descKey: "games.horselesscarriage.desc",
	rulesKey: "games.horselesscarriage.rules",
	icon: "🚘",
	iconImg: "games/horselesscarriage.webp",
	rulesUrl: { en: "https://www.rulespal.com/horseless-carriage/rulebook" },
	minPlayers: 3,
	maxPlayers: 5,
	bestPlayers: [3, 4],
	mechanics: [
		"tile-placement",
		"engine-building",
		"hand-management"
	],
	interactionTags: [],
	accent: "#596b52",
	releasedAt: "2026-11-04T10:30:02+08:00",
	search: {
		py: "wumazhiche",
		init: "wmzc"
	},
	hotseat: "cover"
}, je = t.object({ introductory: t.boolean().default(!1) }).default({ introductory: !1 }), Me = t.int().min(-80).max(80), Ne = t.object({
	x: Me,
	y: Me,
	r: t.int().min(0).max(3)
}), Pe = t.object({
	id: t.string().min(1).max(40),
	item: t.enum(ne),
	x: Me,
	y: Me,
	r: t.int().min(0).max(3),
	target: t.string().max(40).optional(),
	dim: t.enum(w).optional(),
	level: t.int().min(1).max(6).optional()
}), Fe = t.object({
	speed: t.int().nonnegative(),
	reliability: t.int().nonnegative(),
	design: t.int().nonnegative(),
	range: t.int().nonnegative(),
	safety: t.int().nonnegative()
}), Ie = t.object({
	rid: t.string(),
	dim: t.enum([...w, "capacity"])
}), U = t.object({
	x: t.int().min(-2).max(7),
	y: t.int().min(-2).max(7),
	vertical: t.boolean()
}), Le = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("chooseBrand"),
		brand: t.int().min(0).max(4)
	}),
	t.object({
		type: t.literal("startFactory"),
		tiles: t.array(Pe).length(2)
	}),
	t.object({
		type: t.literal("research"),
		moves: t.array(Ie).max(26)
	}),
	t.object({
		type: t.literal("focus"),
		slot: t.int().min(-1).max(4)
	}),
	t.object({
		type: t.literal("build"),
		tiles: t.array(Pe).max(250),
		expansion: Ne.nullable()
	}),
	t.object({
		type: t.literal("sell"),
		dealer: t.string(),
		x: t.int().min(0).max(7),
		y: t.int().min(0).max(7),
		window: U.nullable(),
		allocation: t.record(t.string(), t.int().nonnegative()).optional()
	}),
	t.object({
		type: t.literal("demand"),
		card: t.int().min(0).max(16),
		quadrant: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), Re = [
	"industrialist",
	"setup",
	"research",
	"focus",
	"build",
	"brochures",
	"sell",
	"finish",
	"expectations",
	"demand",
	"reveal",
	"grow",
	"neutral",
	"prices",
	"done"
], ze = t.object({
	rid: t.string(),
	brand: t.int().min(0).max(4),
	brandChosen: t.boolean(),
	research: Fe,
	capacity: t.int().min(1).max(5),
	gantt: t.int().min(0).max(20),
	wealth: t.int().nonnegative(),
	tiles: t.array(Pe),
	floors: t.array(Ne),
	used: t.record(t.string(), t.int().nonnegative()),
	windows: t.record(t.string(), U),
	handCount: t.int().nonnegative()
}), W = t.object({
	car: t.int().nonnegative(),
	truck: t.int().nonnegative(),
	sports: t.int().nonnegative()
}), Be = t.object({
	year: t.int(),
	kind: t.enum([
		"setup",
		"research",
		"focus",
		"build",
		"brochures",
		"sale",
		"finish",
		"expectations",
		"demand",
		"grow",
		"neutral",
		"prices"
	]),
	rid: t.string().optional(),
	n: t.int().optional(),
	dim: t.enum(w).optional(),
	x: t.int().optional(),
	y: t.int().optional(),
	card: t.int().optional(),
	quadrant: t.int().optional()
}), Ve = t.object({
	phase: t.enum(Re),
	year: t.int().min(1).max(7),
	actor: t.string().nullable(),
	introductory: t.boolean(),
	clock: t.int().nonnegative(),
	players: t.array(ze).min(3).max(5),
	order: t.array(t.string()),
	focusSlots: t.array(t.string().nullable()),
	axes: t.tuple([t.enum(w), t.enum(w)]),
	offboard: t.array(t.enum(w)),
	minimum: Fe,
	obsolete: t.int().min(0).max(1),
	buyers: t.array(W).length(64),
	sparks: t.array(W).length(64),
	prices: t.array(t.int().nonnegative()).length(4),
	demandSubmitted: t.array(t.string()),
	revealed: t.array(t.object({
		rid: t.string(),
		card: t.int(),
		quadrant: t.int()
	})),
	log: t.array(Be)
}), He = t.object({
	hand: t.array(t.int().min(0).max(16)),
	demand: t.object({
		card: t.int(),
		quadrant: t.int()
	}).nullable()
}), G = {
	admin: 850,
	reveal: 1100,
	growth: 1200,
	sale: 900
}, K = (e) => ({ code: e }), Ue = () => ({
	car: 0,
	truck: 0,
	sports: 0
});
function q(e, t) {
	e.log.push({
		year: e.year,
		...t
	});
}
function We(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.rngCursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function Ge(e) {
	return We(e, M.map((e, t) => t).filter((t) => !e.introductory || t !== 6));
}
function J(e, t, n, r) {
	let i = n % 2 * 4, a = Math.floor(n / 2) * 4;
	for (let n of t) (r ? e.sparks : e.buyers)[be(n.x + i, n.y + a)][n.kind] += n.count;
}
function Ke(e, t, n) {
	let r = {
		seed: n,
		rngCursor: 0
	}, i = We(r, w), a = We(r, t), o = We(r, [
		0,
		1,
		2,
		3,
		4
	]), s = t.map((n, r) => ({
		rid: n,
		brand: o[r],
		brandChosen: !1,
		research: {
			...I(),
			[i[0]]: 1,
			[i[1]]: 1
		},
		capacity: 1,
		gantt: t.length - a.indexOf(n),
		wealth: 0,
		tiles: [],
		floors: [{
			x: 0,
			y: 0,
			r: 0
		}],
		used: {},
		windows: {},
		handCount: e.introductory ? 8 : 17
	})), c = {
		...r,
		players: s,
		order: a,
		axes: [i[0], i[1]],
		offboard: i.slice(2),
		minimum: I(),
		obsolete: 0,
		year: 1,
		phase: "industrialist",
		actor: a[0],
		turn: 0,
		introductory: e.introductory,
		clock: t.length * 8,
		buyers: Array.from({ length: 64 }, Ue),
		sparks: Array.from({ length: 64 }, Ue),
		prices: [
			6,
			0,
			0,
			0
		],
		focusSlots: t.map(() => null),
		focusQueue: [],
		demandSubmitted: [],
		revealed: [],
		demands: {},
		hands: Object.fromEntries(s.map((t) => [t.rid, C[t.brand].filter((t) => !e.introductory || t.points.every((e) => e.kind === "car")).map((e) => e.id)])),
		revealQueue: [],
		neutralQueue: [],
		log: [],
		beatMs: G.admin
	};
	for (let e of Ge(c).slice(0, t.length + 1)) J(c, M[e], 0, !1);
	return q(c, { kind: "setup" }), {
		state: c,
		fx: []
	};
}
function qe(e, t, n = e.order) {
	e.phase = t, e.turn = 0, e.actor = n[0] ?? null;
}
function Je(e, t) {
	return e.players.flatMap((e) => w.filter((t) => e.research[t] < 6).map((t) => ({
		rid: e.rid,
		dim: t
	}))).concat(e.players.find((e) => e.rid === t).capacity < 5 ? [{
		rid: t,
		dim: "capacity"
	}] : []);
}
function Ye(e) {
	for (; e.turn < e.order.length;) {
		let t = e.players.find((t) => t.rid === e.order[e.turn]);
		if (Je(e, t.rid).length && t.tiles.some((e) => e.item === "research")) {
			e.actor = t.rid;
			return;
		}
		e.turn++;
	}
	e.focusSlots = e.players.map(() => null), e.focusQueue = [...e.order].sort((t, n) => e.players.find((e) => e.rid === n).gantt - e.players.find((e) => e.rid === t).gantt), qe(e, "focus", e.focusQueue);
}
function Xe(e) {
	let t = e.order.filter((t) => !e.focusSlots.includes(t));
	e.order = e.focusSlots.map((e) => e ?? t.shift()), qe(e, "build");
}
function Ze(e, t) {
	let n = [...e.order].reverse(), r = t ? (n.indexOf(t) + 1) % n.length : 0;
	for (let t = 0; t < n.length; t++) {
		let i = n[(r + t) % n.length];
		if (Oe(e, e.players.find((e) => e.rid === i)).length) {
			e.actor = i;
			return;
		}
	}
	e.actor = null, e.phase = "finish";
	for (let t of e.players) t.windows = {};
}
function Qe(e) {
	let t = e.axes[e.obsolete];
	e.minimum[t]++;
	let n = (t) => e.players.reduce((n, r) => n + Math.max(0, r.research[t] - e.minimum[t]), 0), r = (t) => Math.max(...e.players.map((n) => Math.max(0, n.research[t] - e.minimum[t]))), i = [...e.offboard].sort((e, t) => n(t) - n(e) || r(t) - r(e))[0];
	e.offboard = [...e.offboard.filter((e) => e !== i), t], e.axes[e.obsolete] = i, e.obsolete = 1 - e.obsolete, q(e, {
		kind: "expectations",
		dim: i
	});
}
function $e(e) {
	if (e.beatMs = G.admin, e.phase === "brochures") {
		let t = e.players.find((t) => t.rid === e.order[e.turn]), n = t.tiles.filter((e) => e.item === "planning").length, r = t.gantt;
		return t.gantt = Math.min(20, t.gantt + n), r < 10 && t.gantt >= 10 && (e.clock = Math.max(0, e.clock - 1)), t.used = {}, t.windows = {}, q(e, {
			kind: "brochures",
			rid: t.rid,
			n
		}), e.turn++, e.turn === e.order.length && (e.phase = "sell", Ze(e)), [{
			kind: "brochure",
			rid: t.rid,
			data: { n }
		}];
	}
	if (e.phase === "finish") return e.clock === 0 || e.year === 7 ? (e.phase = "done", q(e, { kind: "finish" }), [{
		kind: "finish",
		data: {}
	}]) : (e.phase = "expectations", []);
	if (e.phase === "expectations") return Qe(e), e.demands = {}, e.demandSubmitted = [], e.revealed = [], qe(e, "demand"), [{
		kind: "expectations",
		data: { axes: e.axes }
	}];
	if (e.phase === "reveal") {
		let t = e.revealQueue.shift();
		e.revealed.push(t);
		let n = e.players.find((e) => e.rid === t.rid), r = C[n.brand][t.card];
		return J(e, r.points, t.quadrant, !0), e.clock = Math.max(0, e.clock - r.clocks), q(e, {
			kind: "demand",
			rid: t.rid,
			card: t.card,
			quadrant: t.quadrant
		}), e.beatMs = G.reveal, e.revealQueue.length || (e.phase = "grow"), [{
			kind: "demand",
			rid: t.rid,
			data: {
				card: t.card,
				quadrant: t.quadrant,
				brand: n.brand
			}
		}];
	}
	if (e.phase === "grow") {
		let t = 0, n = [];
		for (let r = 0; r < 64; r++) for (let i of T) {
			let a = Math.max(0, Math.min(e.sparks[r][i], e.sparks[r][i] * 2 - e.buyers[r][i]));
			e.buyers[r][i] += a, t += a, a && n.push({
				x: r % 8,
				y: Math.floor(r / 8),
				kind: i,
				n: a
			});
		}
		let r = Ge(e);
		return e.neutralQueue = [
			1,
			2,
			...Array.from({ length: e.players.length - 2 }, () => 0)
		].map((e, t) => ({
			quadrant: e,
			card: r[t]
		})), e.phase = "neutral", e.beatMs = G.growth, q(e, {
			kind: "grow",
			n: t
		}), [{
			kind: "growth",
			data: {
				n: t,
				added: n
			}
		}];
	}
	if (e.phase === "neutral") {
		let t = e.neutralQueue.shift();
		return J(e, M[t.card], t.quadrant, !1), q(e, {
			kind: "neutral",
			card: t.card,
			quadrant: t.quadrant
		}), e.neutralQueue.length || (e.phase = "prices"), [{
			kind: "neutral",
			data: t
		}];
	}
	if (e.phase === "prices") {
		e.prices = [
			0,
			0,
			0,
			0
		];
		let t = [
			6,
			4,
			3,
			2
		], n = 0;
		for (let r = 3; r >= 0; r--) e.buyers.some((e, t) => xe(t % 8, Math.floor(t / 8)) === r && T.some((t) => e[t])) && (e.prices[r] = t[n++]);
		return q(e, { kind: "prices" }), e.year++, qe(e, "research"), Ye(e), [{
			kind: "prices",
			data: { prices: e.prices }
		}];
	}
	return [];
}
function et(e, t, n) {
	if (t.type === "tick") {
		if (n.by !== "$engine" || e.actor || e.phase === "done") return K("games.horselesscarriage.errTurn");
		let t = structuredClone(e);
		return {
			state: t,
			fx: $e(t)
		};
	}
	if (e.actor !== n.by) return K("games.horselesscarriage.errTurn");
	let r = structuredClone(e), i = r.players.find((e) => e.rid === n.by);
	if (t.type === "chooseBrand" && r.phase === "industrialist") return r.players.some((e) => e.brandChosen && e.brand === t.brand) ? K("games.horselesscarriage.errBrand") : (i.brand = t.brand, i.brandChosen = !0, r.hands[i.rid] = C[i.brand].filter((e) => !r.introductory || e.points.every((e) => e.kind === "car")).map((e) => e.id), r.phase = "setup", {
		state: r,
		fx: []
	});
	if (t.type === "startFactory" && r.phase === "setup") {
		let e = _e(r, i, t.tiles, !0);
		return e ? K(ge[e]) : (i.tiles = t.tiles, r.turn++, r.turn === r.order.length ? (qe(r, "research"), Ye(r)) : (r.actor = r.order[r.turn], r.phase = "industrialist"), {
			state: r,
			fx: [{
				kind: "build",
				rid: i.rid,
				data: {
					tiles: t.tiles,
					brand: i.brand
				}
			}]
		});
	}
	if (t.type === "research" && r.phase === "research") {
		let e = Je(r, i.rid), n = Math.min(i.tiles.filter((e) => e.item === "research").length, e.length);
		if (t.moves.length !== n || new Set(t.moves.map((e) => `${e.rid}:${e.dim}`)).size !== n || t.moves.some((t) => !e.some((e) => e.rid === t.rid && e.dim === t.dim))) return K("games.horselesscarriage.errResearch");
		let a = t.moves.map((e) => ({
			rid: e.rid,
			dim: e.dim,
			brand: r.players.find((t) => t.rid === e.rid).brand,
			level: e.dim === "capacity" ? r.players.find((t) => t.rid === e.rid).capacity : r.players.find((t) => t.rid === e.rid).research[e.dim]
		}));
		for (let e of t.moves) {
			let t = r.players.find((t) => t.rid === e.rid);
			e.dim === "capacity" ? (t.capacity++, t.capacity === 5 && (r.clock = Math.max(0, r.clock - 1))) : (t.research[e.dim]++, [4, 6].includes(t.research[e.dim]) && (r.clock = Math.max(0, r.clock - 1)));
		}
		return q(r, {
			kind: "research",
			rid: i.rid,
			n: t.moves.length
		}), r.turn++, Ye(r), {
			state: r,
			fx: [{
				kind: "research",
				rid: i.rid,
				data: { moves: a }
			}]
		};
	}
	if (t.type === "focus" && r.phase === "focus") return t.slot >= r.players.length || t.slot >= 0 && r.focusSlots[t.slot] ? K("games.horselesscarriage.errFocus") : (t.slot >= 0 && (r.focusSlots[t.slot] = i.rid, i.gantt = 0), q(r, {
		kind: "focus",
		rid: i.rid,
		n: t.slot
	}), r.turn++, r.turn === r.focusQueue.length ? Xe(r) : r.actor = r.focusQueue[r.turn], {
		state: r,
		fx: [{
			kind: "focus",
			rid: i.rid,
			data: { slot: t.slot }
		}]
	});
	if (t.type === "build" && r.phase === "build") {
		let e = _e(r, i, t.tiles);
		return e ? K(ge[e]) : i.floors.length < 7 && !t.expansion || t.expansion && !ue(i.floors, t.expansion) || i.floors.length === 7 && t.expansion ? K("games.horselesscarriage.errExpansion") : (i.tiles.push(...t.tiles), t.expansion && i.floors.push(t.expansion), q(r, {
			kind: "build",
			rid: i.rid,
			n: t.tiles.length
		}), r.turn++, r.turn === r.order.length ? (qe(r, "brochures", []), r.actor = null) : r.actor = r.order[r.turn], {
			state: r,
			fx: [{
				kind: "build",
				rid: i.rid,
				data: {
					tiles: t.tiles,
					brand: i.brand,
					floorIndex: i.floors.length - 1,
					expansion: t.expansion
				}
			}]
		});
	}
	if (t.type === "sell" && r.phase === "sell") {
		let e = ve(i, r.introductory).find((e) => e.tile.id === t.dealer), n = i.windows[t.dealer], a = n ?? t.window;
		if (!e || !a || n && t.window || !Te(r, e, a) || !H(e, a, t.x, t.y)) return K("games.horselesscarriage.errSale");
		let o = De(r, e, t.x, t.y);
		if (!T.some((e) => o.counts[e])) return K("games.horselesscarriage.errSale");
		if (t.allocation) {
			let n = t.allocation;
			if (Object.entries(n).some(([t, n]) => !e.lines.some((e) => e.id === t) || n > i.capacity - (i.used[t] ?? 0))) return K("games.horselesscarriage.errAllocation");
			for (let t of T) if (e.lines.filter((e) => (r.introductory ? "car" : e.item) === t).reduce((e, t) => e + (n[t.id] ?? 0), 0) !== o.counts[t]) return K("games.horselesscarriage.errAllocation");
		}
		i.windows[t.dealer] = a;
		let s = [];
		for (let n of T) {
			let a = o.counts[n];
			for (let o of e.lines.filter((e) => (r.introductory ? "car" : e.item) === n)) {
				let e = t.allocation ? t.allocation[o.id] ?? 0 : Math.min(a, i.capacity - (i.used[o.id] ?? 0));
				e && s.push({
					id: o.id,
					kind: n,
					n: e
				}), i.used[o.id] = (i.used[o.id] ?? 0) + e, a -= e;
			}
			r.buyers[be(t.x, t.y)][n] -= o.counts[n];
		}
		return i.wealth += o.income, q(r, {
			kind: "sale",
			rid: i.rid,
			n: o.income,
			x: t.x,
			y: t.y
		}), r.beatMs = G.sale, Ze(r, i.rid), {
			state: r,
			fx: [{
				kind: "sale",
				rid: i.rid,
				data: {
					x: t.x,
					y: t.y,
					income: o.income,
					counts: o.counts,
					produced: s,
					dealer: t.dealer,
					window: n ? null : a
				}
			}]
		};
	}
	if (t.type === "demand" && r.phase === "demand") {
		let e = C[i.brand][t.card];
		return !r.hands[i.rid].includes(t.card) || e.year > i.floors.length - 1 ? K("games.horselesscarriage.errDemand") : (r.hands[i.rid] = r.hands[i.rid].filter((e) => e !== t.card), i.handCount--, r.demands[i.rid] = {
			card: t.card,
			quadrant: t.quadrant
		}, r.demandSubmitted.push(i.rid), r.turn++, r.turn === r.order.length ? (r.revealQueue = r.order.map((e) => ({
			rid: e,
			...r.demands[e]
		})).sort((e, t) => e.quadrant - t.quadrant), r.actor = null, r.phase = "reveal") : r.actor = r.order[r.turn], {
			state: r,
			fx: [{
				kind: "demandCommit",
				rid: i.rid,
				for: [i.rid],
				secret: {
					card: t.card,
					brand: i.brand
				}
			}]
		});
	}
	return K("games.horselesscarriage.errPhase");
}
function tt(e, t) {
	return {
		public: {
			phase: e.phase,
			year: e.year,
			actor: e.actor,
			introductory: e.introductory,
			clock: e.clock,
			players: e.players,
			order: e.order,
			focusSlots: e.focusSlots,
			axes: e.axes,
			offboard: e.offboard,
			minimum: e.minimum,
			obsolete: e.obsolete,
			buyers: e.buyers,
			sparks: e.sparks,
			prices: e.prices,
			demandSubmitted: e.demandSubmitted,
			revealed: e.revealed,
			log: e.log
		},
		private: {
			hand: e.players.find((e) => e.rid === t)?.brandChosen ? e.hands[t] : [],
			demand: e.demands[t] ?? null
		}
	};
}
function Y(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.order].sort((t, n) => e.players.find((e) => e.rid === n).wealth - e.players.find((e) => e.rid === t).wealth || e.order.indexOf(n) - e.order.indexOf(t));
	return {
		phase: "done",
		winner: [t[0]],
		ranking: t,
		scores: Object.fromEntries(e.players.map((e) => [e.rid, e.wealth]))
	};
}
var nt = {
	meta: Ae,
	saveCompatibility: { version: "1" },
	schemas: {
		action: Le,
		publicView: Ve,
		privateView: He,
		config: je
	},
	setup: Ke,
	reduce: et,
	viewFor: tt,
	status: Y,
	nextTickIn: (e) => !e.actor && e.phase !== "done" ? e.beatMs : null
}, rt = {
	chassis: {
		w: 212,
		h: 226,
		paper: "M118,11L111,11L110,12L109,12L107,14L107,15L106,16L106,19L105,20L105,24L104,25L85,25L83,23L82,23L81,22L69,22L68,23L65,23L64,24L62,24L60,26L59,26L54,31L52,31L51,32L46,32L45,33L39,33L38,34L38,41L36,43L30,43L29,42L29,40L28,39L28,37L27,36L27,34L26,33L26,31L23,26L13,26L12,27L11,27L11,28L10,29L10,36L9,37L9,47L10,48L10,54L11,55L11,59L12,60L12,63L13,64L13,66L14,67L14,68L15,69L17,74L19,76L20,76L21,77L24,77L25,78L25,85L26,86L33,86L34,85L41,85L42,84L44,84L52,76L56,76L57,77L60,78L65,82L66,82L67,83L70,83L71,84L71,85L75,92L75,94L76,95L76,96L80,103L80,105L81,106L81,110L80,111L77,111L76,112L73,113L71,115L68,116L66,118L65,118L60,122L54,122L53,123L49,123L48,124L44,124L43,125L43,128L44,129L50,129L51,128L55,128L56,127L59,127L60,126L63,125L65,123L66,123L71,119L74,118L76,116L77,116L80,114L84,114L85,115L85,116L86,117L86,118L87,119L87,120L88,121L88,122L89,123L89,124L90,125L90,126L91,127L91,128L95,135L95,137L96,138L96,139L97,140L97,141L101,148L101,155L100,156L100,157L98,159L97,162L95,164L94,164L93,165L90,165L89,166L85,166L84,165L84,164L83,163L83,161L82,160L82,158L81,157L79,152L77,150L77,149L74,146L66,146L65,147L64,147L61,150L61,152L60,153L60,158L59,159L59,167L60,168L60,176L61,177L61,181L62,182L62,185L63,186L63,189L64,190L64,193L65,194L65,196L66,197L66,198L67,199L67,200L68,201L70,206L73,209L74,209L75,210L81,210L82,209L83,209L85,207L85,206L87,203L87,200L88,199L88,181L89,180L91,180L92,179L95,179L96,178L100,178L101,177L106,177L107,176L110,176L111,175L116,175L117,174L122,174L123,173L127,173L128,172L132,172L133,171L136,171L137,170L141,170L142,169L146,169L147,168L152,168L153,167L157,167L158,166L161,166L162,165L171,165L173,167L173,169L175,172L175,174L177,177L177,179L179,181L179,182L182,185L183,185L184,186L198,186L201,183L201,181L202,180L202,174L203,173L203,166L202,165L202,158L201,157L201,152L200,151L200,148L199,147L199,145L198,144L198,142L197,141L197,140L196,139L196,137L195,136L195,135L193,133L193,132L188,127L187,127L186,126L176,126L175,127L174,127L172,129L172,130L171,131L171,133L170,134L170,138L169,139L169,146L167,148L164,148L163,149L156,149L155,148L155,147L154,146L152,141L150,139L150,138L149,137L149,136L148,135L148,134L147,133L147,132L146,131L144,126L142,124L142,123L141,122L141,121L137,114L137,109L138,108L142,108L143,109L158,109L159,108L163,108L164,107L165,107L165,103L158,103L157,104L155,104L154,105L151,105L150,106L146,106L145,105L143,105L140,103L132,103L130,101L130,100L129,99L127,94L125,92L125,91L124,90L124,89L123,88L123,87L122,86L122,85L121,84L121,83L120,82L118,77L116,75L116,74L115,73L115,68L116,67L122,67L123,68L127,68L128,69L132,69L133,68L138,68L139,67L141,67L142,66L142,64L141,63L134,63L133,64L128,64L127,63L127,59L129,56L129,33L128,32L128,28L127,27L127,25L126,24L126,22L125,21L125,20L124,19L122,14L120,12L119,12ZM53,49L56,52L56,53L57,54L57,56L61,63L61,68L60,69L57,69L56,70L53,70L52,71L51,71L45,77L44,77L42,79L37,79L36,80L31,80L30,79L30,75L32,72L32,52L33,51L38,51L39,50L45,50L46,49Z",
		ink: "M67,147L66,148L65,148L62,151L62,153L61,154L61,159L60,160L60,166L61,167L61,175L62,176L62,180L63,181L63,184L64,185L64,188L65,189L65,192L66,193L66,195L67,196L67,197L68,198L68,199L69,200L71,205L74,208L75,208L76,209L80,209L81,208L82,208L84,206L84,205L86,202L86,199L87,198L87,182L86,181L86,176L85,175L85,172L84,171L84,168L83,167L83,165L82,164L82,162L81,161L81,159L80,158L78,153L76,151L76,150L73,147ZM72,194L73,193L74,194L73,195ZM68,189L69,188L70,188L71,189L70,190L69,190ZM68,181L69,182L69,183L68,184L67,184L66,183ZM64,170L65,169L66,169L67,170L67,171L66,172L65,172L64,171ZM64,161L65,161L66,162L66,165L65,166L63,164L63,162ZM134,104L135,104L136,105L138,105L139,106L140,106L141,107L143,107L144,108L157,108L158,107L162,107L163,106L164,106L164,104L159,104L158,105L156,105L155,106L152,106L151,107L145,107L144,106L142,106L139,104ZM14,27L13,28L12,28L12,29L11,30L11,37L10,38L10,46L11,47L11,53L12,54L12,58L13,59L13,62L14,63L14,65L15,66L15,67L16,68L18,73L20,75L21,75L22,76L27,76L28,75L29,75L29,74L31,71L31,57L30,56L30,48L29,47L29,44L28,43L28,41L27,40L27,38L26,37L26,35L25,34L25,32L24,31L23,28L22,27ZM20,62L22,64L22,65L20,67L19,66L19,63ZM13,57L15,54L17,54L18,55L18,57L16,59L15,59ZM12,52L12,49L13,48L15,48L17,50L14,53L13,53ZM11,42L12,41L13,41L15,43L15,45L14,46L13,46L12,45ZM39,35L39,36L41,38L43,38L45,40L43,42L41,42L40,43L38,43L37,44L35,44L34,45L33,45L33,49L34,50L37,50L38,49L44,49L45,48L54,48L57,51L57,52L58,53L58,55L59,56L59,57L63,64L63,66L64,67L64,68L62,70L58,70L57,71L54,71L53,72L52,72L46,78L45,78L43,80L38,80L37,81L32,81L31,82L27,82L26,83L26,84L27,85L32,85L33,84L40,84L41,83L43,83L52,74L56,74L58,76L61,77L66,81L67,81L68,82L69,81L70,81L72,83L72,84L76,91L76,93L77,94L77,95L81,102L81,104L82,105L84,110L82,112L78,112L77,113L74,114L72,116L69,117L67,119L66,119L61,123L55,123L54,124L50,124L49,125L45,125L44,126L44,127L45,128L49,128L50,127L54,127L55,126L58,126L59,125L62,124L64,122L65,122L70,118L73,117L75,115L76,115L79,113L85,113L86,114L86,115L87,116L87,117L88,118L88,119L89,120L89,121L90,122L90,123L91,124L91,125L92,126L92,127L96,134L96,136L97,137L97,138L98,139L98,140L102,147L102,149L104,152L103,153L101,158L99,160L98,163L96,165L95,165L94,166L91,166L90,167L88,167L88,168L89,167L93,167L94,168L94,170L92,172L92,173L91,174L89,174L89,177L90,178L90,179L91,178L94,178L95,177L99,177L100,176L105,176L106,175L109,175L110,174L115,174L116,173L121,173L122,172L126,172L127,171L131,171L132,170L135,170L136,169L140,169L141,168L145,168L146,167L151,167L152,166L156,166L157,165L160,165L161,164L166,164L167,163L172,163L174,166L174,168L176,171L176,173L178,176L178,178L180,180L180,181L183,184L184,184L185,185L197,185L200,182L200,180L201,179L201,173L202,172L202,167L201,166L201,159L200,158L200,153L199,152L199,149L198,148L198,146L197,145L197,143L196,142L196,141L195,140L195,138L194,137L194,136L192,134L192,133L187,128L186,128L185,127L177,127L176,128L175,128L173,130L173,131L172,132L172,134L171,135L171,139L170,140L170,147L168,149L165,149L164,150L160,150L159,151L156,151L154,149L154,148L153,147L151,142L149,140L149,139L148,138L148,137L147,136L147,135L146,134L146,133L145,132L143,127L141,125L141,124L140,123L140,122L139,121L139,120L138,119L138,118L137,117L137,116L136,115L136,114L135,113L135,112L134,111L134,110L133,109L131,104L129,102L129,101L128,100L126,95L124,93L124,92L123,91L123,90L122,89L122,88L121,87L121,86L120,85L120,84L119,83L117,78L115,76L115,75L114,74L114,73L110,66L110,65L112,63L114,63L115,64L116,64L117,65L119,65L120,66L123,66L124,67L128,67L129,68L131,68L132,67L137,67L138,66L140,66L141,65L140,64L135,64L134,65L130,65L129,66L125,66L124,65L122,65L121,64L121,63L122,62L123,62L126,59L126,58L128,55L128,34L127,33L127,29L126,28L126,26L125,25L125,23L124,22L124,21L123,20L121,15L119,13L118,13L117,12L112,12L111,13L110,13L108,15L108,16L107,17L107,20L106,21L106,30L103,33L100,31L100,29L101,28L101,27L100,26L92,26L91,27L86,27L80,23L70,23L69,24L66,24L65,25L63,25L61,27L60,27L55,32L53,32L52,33L47,33L46,34L40,34ZM188,171L189,170L190,170L191,171L191,172L190,173L189,173L188,172ZM178,164L179,163L180,163L181,164L181,165L180,166L179,166L178,165ZM108,164L108,165L106,167L105,167L104,168L102,168L99,170L97,170L96,169L96,168L99,165L101,165L102,164L105,164L106,163L107,163ZM187,163L188,162L190,162L192,165L190,167L188,165L188,164ZM135,164L137,162L139,164L138,165L136,165ZM141,161L143,163L140,165L138,163L140,161ZM145,161L146,160L148,160L149,161L149,162L148,163L146,163L145,162ZM113,161L114,160L115,160L116,161L115,162L114,162ZM117,160L118,159L119,160L118,161ZM104,155L106,157L106,158L108,161L106,163L103,163L102,164L101,164L100,163L100,161ZM186,155L187,154L188,154L189,155L189,157L188,158L187,158L186,157ZM134,155L135,154L136,155L136,156L135,157L134,156ZM142,153L143,152L144,152L145,153L144,154L143,154ZM147,152L148,151L149,151L150,152L149,153L148,153ZM171,157L170,158L166,158L165,157L162,157L161,156L158,156L156,154L158,152L160,152L161,151L165,151L166,150L169,150L171,152ZM175,144L176,143L177,143L178,144L178,145L177,146L176,146L175,145ZM106,148L108,146L109,146L110,145L110,144L111,143L113,138L114,137L116,137L117,138L118,138L119,139L120,139L121,140L122,140L123,141L124,141L125,142L126,142L127,143L128,143L129,144L130,144L131,145L132,145L133,146L134,146L135,147L140,149L142,151L140,153L139,153L138,154L135,154L134,155L131,155L132,156L132,157L131,158L130,158L129,157L129,156L127,156L127,158L126,159L125,158L125,157L123,157L123,159L122,160L121,159L121,158L119,158L118,159L112,159L111,158L111,157L110,156L110,155ZM90,113L91,112L94,111L96,109L97,109L100,106L101,106L102,107L101,108L101,110L105,110L107,108L107,107L102,107L101,106L103,104L104,104L105,103L110,103L115,106L126,106L128,108L128,109L129,110L126,113L124,113L124,114L123,115L124,116L124,117L125,118L127,118L129,116L131,116L134,119L134,120L135,121L137,126L139,128L139,129L140,130L140,131L141,132L141,133L142,134L142,135L143,136L143,137L144,138L144,139L145,140L147,145L149,147L149,150L148,151L145,151L144,150L143,150L142,149L141,149L140,148L139,148L138,147L137,147L136,146L135,146L134,145L133,145L132,144L131,144L130,143L129,143L128,142L127,142L126,141L125,141L124,140L123,140L122,139L117,137L113,133L112,130L112,134L113,135L113,136L112,137L112,139L111,140L111,141L109,143L108,146L107,147L106,147L105,146L105,145L102,140L102,138L101,137L101,136L100,135L100,134L96,127L96,125L98,123L98,121L96,119L94,119L91,116ZM100,102L100,101L101,100L102,100L103,101L101,103ZM80,92L81,91L83,91L85,93L88,94L90,96L95,98L96,99L96,102L98,104L98,105L93,110L91,110L90,111L89,111L86,106L86,104L85,103L85,102L81,95L81,93ZM109,75L110,75L112,77L112,78L113,79L113,80L114,81L114,82L115,83L115,84L116,85L118,90L120,92L120,93L121,94L121,95L125,102L125,103L122,105L121,105L117,101L116,98L114,96L114,95L113,94L111,89L109,87L109,86L107,83L107,78ZM57,73L59,71L65,71L67,73L67,74L68,75L70,80L69,81L68,81L63,77L60,76ZM71,69L72,69L73,68L75,68L78,66L79,66L81,68L81,69L82,70L82,71L83,72L83,73L84,74L84,75L85,76L85,77L86,78L88,83L90,85L90,86L93,91L93,93L94,94L93,95L91,95L90,94L89,94L87,92L84,91L82,89L81,89L76,84L76,83L75,82L75,81L74,80L74,79L70,72L70,70ZM100,64L104,64L106,66L106,67L108,70L108,74L107,75L107,77L106,78L105,78L103,76L103,75L101,73L101,72L98,67L98,66ZM85,63L90,63L91,64L94,64L98,68L98,69L99,70L101,75L103,77L103,78L105,81L105,85L104,86L104,88L103,89L103,92L102,93L102,94L103,94L103,92L104,91L104,89L105,88L105,87L106,86L107,86L109,88L110,91L112,93L113,96L115,98L115,99L117,102L117,103L116,104L114,104L111,102L107,102L104,100L104,99L105,98L104,97L100,97L99,96L99,95L97,93L97,92L96,91L96,90L95,89L95,88L94,87L94,86L90,79L90,77L89,76L88,73L86,71L86,70L84,67L84,64ZM60,45L61,46L64,47L71,54L71,55L72,56L73,56L77,60L77,61L79,63L75,67L74,67L73,68L71,68L70,69L68,67L68,66L67,65L67,64L63,57L63,55L60,50L60,48L59,47L59,46ZM79,44L80,45L81,45L82,46L82,47L84,49L84,50L85,51L85,52L89,59L89,61L88,62L87,62L86,61L85,62L81,62L80,61L81,60L81,59L80,58L80,57L76,50L76,49L77,48L77,46ZM85,45L89,45L89,44L91,42L92,42L95,45L95,46L96,47L96,48L97,49L97,50L98,51L98,52L99,53L99,54L103,61L101,63L97,63L96,62L96,60L95,60L94,61L92,61L88,57L88,56L85,51L85,49L84,48L84,46ZM99,41L105,41L107,43L107,45L108,46L108,48L111,53L111,55L112,56L112,59L113,60L111,62L109,62L107,60L106,57L104,55L104,54L103,53L103,52L102,51L102,50L98,43L98,42ZM116,41L117,40L118,40L119,41L119,43L118,44L117,44L116,43ZM47,43L47,42L50,40L52,42L50,44L48,44ZM105,35L105,36L103,38L99,38L98,39L96,39L95,38L95,36L96,35L100,35L101,34L104,34ZM108,33L109,32L110,32L112,34L114,34L115,35L114,36L109,36L108,35ZM115,31L116,30L117,30L118,31L118,32L117,33L116,33L115,32ZM56,41L56,38L57,37L58,37L60,35L61,35L65,31L66,31L67,30L69,30L70,29L75,29L76,30L78,30L80,32L81,32L82,33L84,33L85,34L87,34L89,36L89,37L87,39L82,39L81,40L75,40L74,41L67,41L66,42L61,42L60,43L58,43ZM73,37L72,36L69,35L68,36L67,36L65,38L73,38ZM109,27L110,26L111,27L111,28L110,29L109,28ZM63,28L63,27L66,25L68,25L69,26L69,27L68,28L65,28L64,29ZM71,25L72,24L79,24L81,26L80,27L72,27L71,26ZM111,22L112,21L113,22L113,23L112,24L111,23Z"
	},
	bumpers: {
		w: 159,
		h: 39,
		paper: "M3,3L3,15L4,15L5,16L5,20L4,21L4,25L5,26L5,28L6,29L6,30L7,31L8,31L9,32L11,32L12,33L51,33L53,35L53,38L104,38L104,34L107,32L149,32L151,30L152,30L152,29L154,26L154,21L152,19L152,15L153,14L153,7L152,6L152,4L151,3L145,3L144,2L144,0L142,0L142,2L141,3L133,3L132,2L132,0L4,0L4,2Z",
		ink: "M4,4L4,14L5,14L8,16L8,19L5,22L5,24L6,25L6,27L7,28L7,29L8,30L9,30L10,31L12,31L13,32L52,32L54,34L54,35L57,37L92,37L93,36L102,36L103,35L103,33L106,31L148,31L150,29L151,29L151,28L153,25L153,22L150,19L149,19L148,18L151,15L151,14L152,13L152,8L151,7L151,5L150,4L144,4L143,3L142,4L132,4L131,3L5,3ZM124,23L125,23L126,24L126,27L125,28L124,28L122,26L122,25ZM56,23L59,21L99,21L101,23L101,30L99,32L96,32L95,33L70,33L69,32L63,32L62,33L60,33L59,32L58,32L56,30ZM87,24L84,24L86,24L87,25L87,28L86,29L83,29L84,29L85,30L86,29L87,29L87,28L88,27L88,25ZM77,24L79,24L80,25L80,27L78,29L77,29L76,28L76,29L79,29L80,28L80,24ZM70,24L71,24L72,25L72,28L71,29L69,29L72,29L72,28L73,27L73,24ZM13,22L16,20L32,20L33,21L34,21L37,24L38,23L40,25L40,27L39,28L38,28L37,27L34,28L33,27L33,25L33,26L31,28L30,28L29,27L29,25L27,28L26,28L25,27L25,26L23,28L22,28L21,27L21,25L21,26L19,28L18,28L17,27L17,25L17,27L16,28L14,28L13,27ZM11,20L13,22L13,26L12,27L11,27L9,25L9,22ZM126,26L126,21L127,20L131,20L132,19L146,19L147,20L148,20L150,22L150,23L147,26L146,25L146,26L145,27L143,27L142,26L142,25L142,26L141,27L139,27L138,26L138,24L138,26L137,27L134,27L133,28L132,28L130,26L130,27L129,28L128,28ZM64,18L65,17L101,17L102,18L104,18L106,20L118,20L119,21L119,23L120,22L122,24L122,26L120,28L118,26L118,27L117,28L116,28L114,26L114,27L113,28L112,28L111,27L111,25L111,26L109,28L108,28L107,27L107,26L106,26L106,27L105,28L104,28L103,27L103,24L102,23L102,21L101,20L65,20L64,19ZM61,18L61,19L60,20L58,20L57,21L56,21L56,23L55,24L55,27L54,28L52,26L52,24L52,26L50,28L49,28L48,27L47,28L46,28L44,26L44,27L43,28L42,28L40,26L40,23L42,21L43,21L44,20L53,20L58,17L60,17ZM121,12L123,12L126,15L126,20L123,22L121,22L119,20L119,19L118,18L118,16L119,15L119,14ZM123,18L121,18L121,19L122,20L123,19ZM36,12L39,12L41,14L41,20L38,23L37,23L36,22L36,21L38,19L38,18L37,18L34,16L34,15ZM150,8L150,12L148,14L147,14L146,13L144,15L142,13L142,12L142,13L141,14L139,14L138,13L138,12L138,13L137,14L135,14L134,13L134,11L134,13L133,14L131,14L130,13L130,12L130,13L129,14L127,14L124,12L121,12L118,15L117,15L114,12L114,11L114,13L113,14L112,14L111,13L111,12L111,13L110,14L108,14L107,13L107,12L105,14L104,14L103,13L103,11L103,12L101,14L100,14L99,13L99,11L99,13L98,14L97,14L95,12L95,10L95,13L94,14L92,14L91,13L91,11L91,12L89,14L88,14L87,13L87,12L87,13L86,14L84,14L83,13L83,10L83,13L82,14L81,14L79,12L79,11L79,13L78,14L77,14L75,12L75,13L74,14L69,14L68,13L68,11L68,12L66,14L65,14L64,13L61,14L60,13L60,10L60,12L58,14L57,14L56,13L56,10L56,13L55,14L53,14L52,13L52,11L52,13L51,14L50,14L48,12L48,13L47,14L45,14L44,13L44,11L44,13L43,14L42,14L40,11L36,11L34,14L33,14L32,13L31,14L30,14L29,13L29,11L27,14L26,14L25,13L25,12L23,14L22,14L21,13L21,11L21,12L19,14L18,14L17,13L17,11L17,12L15,14L14,14L13,13L13,11L13,12L11,14L10,14L9,13L9,11L8,12L7,12L6,11L6,9L9,6L92,6L93,5L145,5L146,6L148,6Z"
	},
	body: {
		w: 184,
		h: 110,
		paper: "M5,25L5,36L4,37L4,55L5,56L5,57L6,58L25,58L26,59L28,59L29,60L30,60L33,63L34,63L36,65L36,66L39,69L39,70L41,73L41,75L42,76L42,80L43,81L43,82L46,84L147,84L148,83L154,83L154,78L155,77L155,75L156,74L157,71L161,67L162,67L167,64L175,64L178,61L178,52L177,51L177,50L175,48L172,47L170,45L170,42L169,41L169,37L168,36L168,34L164,30L163,30L162,29L159,29L158,28L123,28L122,27L120,27L119,26L118,26L109,17L109,16L104,11L103,11L98,8L27,8L26,9L21,9L20,10L18,10L17,11L16,11L14,13L13,13L7,20L7,21L6,22L6,24Z",
		ink: "M6,26L6,37L5,38L5,54L6,55L6,56L7,57L16,57L17,56L21,56L22,57L26,57L27,58L29,58L30,59L31,59L34,62L35,62L37,64L37,65L40,68L40,69L42,72L42,74L43,75L43,79L44,80L44,81L47,83L65,83L66,82L68,82L69,83L146,83L147,82L153,82L153,77L154,76L154,74L155,73L156,70L160,66L161,66L166,63L169,63L170,62L171,63L174,63L177,60L177,53L176,52L176,51L174,49L171,48L169,46L169,43L168,42L168,38L167,37L167,35L163,31L162,31L161,30L158,30L157,29L122,29L121,28L119,28L118,27L117,27L108,18L108,17L103,12L102,12L97,9L50,9L49,10L45,10L44,9L28,9L27,10L22,10L21,11L19,11L18,12L17,12L15,14L14,14L8,21L8,22L7,23L7,25ZM10,45L11,44L37,44L38,45L40,45L42,47L43,47L51,55L51,56L54,61L54,63L55,64L55,66L53,68L54,69L54,70L53,71L53,73L54,73L54,70L55,69L56,69L58,71L138,71L139,70L139,68L140,67L141,64L145,60L145,59L148,56L149,56L154,53L157,53L158,52L162,52L163,51L166,51L167,52L170,52L172,54L172,57L171,58L167,58L166,59L163,59L162,60L161,60L160,59L159,60L159,61L158,62L157,62L153,66L153,67L151,69L151,70L149,73L149,76L147,78L49,78L47,75L47,72L46,71L46,69L45,68L45,67L43,65L43,64L40,61L40,60L39,60L35,56L34,56L31,54L29,54L28,53L21,53L20,52L16,52L15,53L12,53L10,51ZM144,68L143,69L143,71L144,72ZM155,58L155,60L156,60L156,58ZM37,28L40,25L53,25L54,26L59,26L60,25L90,25L91,26L93,26L98,31L98,32L103,37L103,38L107,42L107,43L109,45L109,64L106,67L61,67L59,65L59,63L58,62L58,60L57,59L57,57L56,56L55,53L53,51L53,50L48,45L47,45L44,42L39,40L37,38L37,35L38,34L38,33L37,32ZM9,36L10,35L10,28L11,27L11,25L12,24L12,23L19,16L20,16L21,15L23,15L24,14L29,14L30,13L41,13L42,14L47,14L48,13L95,13L96,14L99,15L106,22L106,23L114,31L115,31L116,32L118,32L119,33L143,33L144,34L158,34L159,35L160,35L163,38L163,39L164,40L164,49L162,51L155,51L154,52L152,52L151,53L146,55L141,60L141,61L139,63L139,65L138,66L138,67L135,69L115,69L113,67L113,43L112,42L112,39L111,40L109,38L109,37L108,36L108,32L108,33L107,34L105,32L105,27L104,27L104,28L103,29L102,29L101,28L101,27L96,22L95,22L94,21L90,21L89,20L89,19L87,21L86,20L85,20L84,21L79,21L77,19L77,18L77,20L76,21L75,21L73,19L73,18L73,19L71,21L69,19L69,18L69,20L68,21L67,21L66,20L66,18L65,18L65,20L64,21L63,21L61,18L61,19L60,20L59,20L58,19L58,18L57,18L58,19L56,21L55,21L54,20L54,18L53,18L53,20L52,21L51,21L50,20L50,18L48,21L47,21L46,20L45,20L44,21L39,21L38,20L38,19L37,20L34,20L33,21L33,39L31,42L29,42L28,43L16,43L15,42L12,42L10,40L10,38L9,37ZM116,63L116,50L118,48L119,48L120,49L120,63L120,48L122,46L123,46L124,47L124,64L124,48L126,46L127,46L128,47L128,64L128,48L130,46L132,48L132,64L132,48L134,46L136,49L136,60L136,48L138,46L139,46L140,47L140,53L140,47L141,46L142,46L143,47L143,51L144,51L144,47L145,46L146,46L147,47L147,48L148,48L148,47L149,46L150,46L151,47L152,46L150,46L149,45L121,45L120,46L117,46L117,47L116,48ZM156,43L155,46L156,46Z"
	},
	radiator: {
		w: 129,
		h: 148,
		paper: "M78,8L74,8L73,7L65,7L63,10L59,10L58,9L58,8L55,8L54,9L54,20L53,21L51,21L50,22L36,22L35,23L33,23L32,24L30,24L28,26L25,27L24,28L24,29L17,36L16,36L14,38L14,39L8,45L8,46L6,49L6,51L5,52L5,60L4,61L4,123L5,124L5,128L6,129L8,134L11,137L12,137L13,138L114,138L115,137L118,137L120,135L121,135L123,133L124,130L126,128L128,128L128,56L126,56L125,55L125,51L124,50L124,48L123,47L123,46L121,44L121,43L105,27L104,27L102,25L101,25L98,23L92,23L91,22L78,22L77,21L77,17L79,15L79,9Z",
		ink: "M77,9L73,9L72,8L66,8L65,9L65,11L64,12L64,13L61,15L58,12L57,9L56,9L55,10L55,15L56,16L57,16L60,19L57,22L52,22L51,23L37,23L36,24L34,24L33,25L31,25L29,27L26,28L25,29L25,30L18,37L17,37L15,39L15,40L9,46L9,47L7,50L7,52L6,53L6,61L5,62L5,122L6,123L6,127L7,128L9,133L12,136L13,136L14,137L113,137L114,136L117,136L119,134L120,134L122,132L123,129L125,127L125,124L126,123L126,101L125,100L125,57L124,56L124,52L123,51L123,49L122,48L122,47L120,45L120,44L104,28L103,28L101,26L100,26L97,24L91,24L90,23L76,23L74,21L74,18L78,14L78,10ZM29,31L30,31L32,29L33,29L34,28L37,28L38,27L57,27L58,26L75,26L76,27L93,27L94,28L96,28L97,29L100,30L104,34L105,34L113,42L113,43L118,48L118,49L120,51L120,53L121,54L121,73L122,74L122,122L121,123L121,125L120,126L120,127L115,132L114,132L113,133L17,133L16,132L15,132L11,128L11,127L10,126L10,123L9,122L9,73L10,72L10,53L11,52L11,50L16,45L16,44ZM17,55L17,119L19,121L112,121L113,120L113,119L114,118L114,116L113,115L113,96L112,95L112,93L111,93L109,91L109,85L111,83L112,83L112,54L111,53L110,53L109,52L106,52L105,51L27,51L26,52L21,52L20,53L19,53ZM104,99L106,101L106,102L107,103L107,107L106,108L106,116L107,117L107,108L109,105L110,105L111,106L111,109L110,110L110,116L112,118L112,119L110,121L105,121L103,119L103,100ZM72,100L73,99L74,99L75,100L75,101L74,102L73,102L72,101ZM103,97L104,96L105,97L104,98ZM108,95L111,95L112,96L112,97L111,98L112,99L112,102L111,103L109,103L107,101L107,96ZM91,91L92,90L93,90L94,91L94,93L93,94L92,94L91,93ZM34,89L36,92L36,93L34,95L32,93L32,91ZM60,88L61,87L62,87L63,88L62,89L61,89ZM19,86L20,87L20,90L19,91L18,90L18,87ZM91,85L92,84L94,86L93,87L92,87L91,86ZM60,82L61,81L63,81L65,84L63,86L60,83ZM104,80L105,80L107,82L107,95L105,97L103,94L103,81ZM107,80L108,79L109,79L110,80L109,81L108,81ZM34,77L35,77L36,78L36,81L35,82L34,82L33,81L33,78ZM71,77L72,76L73,76L75,78L75,79L74,80L72,80L71,79ZM91,76L92,75L93,76L93,77L92,78L91,77ZM53,74L55,74L56,75L56,86L54,88L53,88L51,85L51,77ZM23,73L24,74L24,82L23,83L23,84L22,85L21,85L20,84L20,76L21,75L21,74L22,73ZM107,73L108,72L109,72L110,73L110,74L109,75L108,75L107,74ZM88,73L89,72L90,73L90,74L89,75L88,74ZM28,72L29,71L30,72L29,73ZM78,69L80,71L80,77L79,78L79,83L77,85L75,83L75,76L76,75L76,71ZM21,70L22,69L24,71L23,72L22,72L21,71ZM104,68L105,68L107,71L107,77L105,79L104,79L103,78L103,69ZM47,69L48,68L49,69L49,70L48,71L47,70ZM28,69L29,68L30,68L31,69L31,70L30,71L29,71L28,70ZM87,68L88,67L89,67L90,68L90,70L89,71L88,71L87,70ZM60,68L61,67L62,68L62,69L61,70L60,69ZM33,68L34,67L35,67L36,68L36,69L35,70L34,70L33,69ZM91,67L92,66L93,66L95,68L95,69L94,70L93,70L91,68ZM101,70L101,76L100,77L99,77L100,78L100,79L99,80L98,80L99,80L101,82L101,83L102,84L102,94L101,95L100,95L101,95L102,96L102,100L101,101L101,103L100,104L100,106L101,105L102,106L102,118L103,119L103,120L102,121L86,121L83,118L83,116L83,119L81,121L55,121L54,120L53,121L32,121L31,120L25,120L24,119L24,114L24,115L23,116L22,116L21,115L21,117L22,117L23,118L23,119L22,120L21,120L18,118L18,117L17,116L17,114L19,112L20,113L19,110L20,109L20,107L21,106L21,105L20,104L20,87L22,85L23,85L24,86L24,101L26,99L27,100L27,105L28,106L27,107L27,112L28,112L28,96L25,94L25,92L24,91L24,85L26,83L28,85L27,86L27,89L28,88L28,82L27,81L28,80L27,79L27,78L28,77L28,76L30,74L31,75L31,87L32,88L32,94L31,95L31,116L32,117L32,101L33,100L32,99L32,96L33,95L34,95L35,96L35,101L36,102L35,103L35,105L36,106L36,117L36,99L35,98L35,96L36,95L36,92L37,91L40,92L40,90L37,87L37,83L42,78L44,78L45,79L45,84L44,85L43,85L41,82L41,86L43,86L45,88L45,89L45,82L46,81L46,75L48,72L49,72L50,73L50,87L48,89L50,91L50,92L51,93L51,117L52,116L51,115L51,107L52,106L52,90L54,88L55,88L56,89L56,91L55,92L55,116L56,115L56,104L55,103L55,95L56,94L56,74L57,73L57,71L56,70L56,69L57,68L58,68L60,71L60,76L59,77L59,79L60,80L60,88L59,89L59,91L60,92L60,95L60,91L61,90L64,90L64,88L66,86L66,71L67,70L67,67L68,66L70,68L70,81L71,82L70,83L70,87L71,88L71,90L70,91L70,92L71,93L71,90L72,89L70,86L70,84L72,82L73,82L75,84L75,91L74,92L75,93L75,96L73,99L72,99L71,98L71,100L70,101L70,105L71,106L71,108L70,109L70,114L71,115L71,116L71,104L72,103L73,103L75,105L75,113L74,114L75,115L75,116L75,95L76,94L76,92L75,91L75,89L76,88L76,87L77,86L78,86L80,88L79,89L79,90L81,90L81,88L82,87L82,83L81,82L81,75L83,73L85,75L85,83L86,84L86,95L87,95L87,87L86,86L86,82L87,81L86,80L86,79L87,78L88,78L90,80L90,82L88,84L90,86L90,91L91,92L91,97L90,98L90,114L89,115L87,113L87,107L86,106L86,103L87,102L86,101L86,100L86,103L85,104L86,105L86,116L89,116L90,117L91,117L91,98L92,97L93,97L94,98L94,107L94,89L96,87L97,87L98,88L97,87L95,87L94,86L94,71L96,69L97,70L99,68ZM99,112L98,113L98,115L97,116L94,116L94,117L99,117ZM79,110L79,117L79,114L80,113ZM66,102L66,108L67,109L67,117L68,116L67,115L67,106L66,105ZM62,101L62,102L63,103L63,105L62,106L62,107L63,108L63,115L62,116L63,117L63,103L64,102L63,101ZM47,99L47,117L48,117L48,114L47,113L47,107L48,106L48,103L47,102ZM44,99L43,99L43,114L41,116L40,116L39,117L40,117L41,116L44,117L44,113L43,112L43,105L44,104L44,103L43,102L43,100ZM20,67L21,66L22,67L21,68ZM28,66L29,65L30,65L31,66L30,67L29,67ZM84,63L85,64L85,69L83,71L81,69L81,67L82,66L82,64L83,63ZM87,62L88,61L89,61L90,62L90,63L89,64L88,64L87,63ZM56,62L57,61L58,61L60,63L60,64L58,66L57,66L56,65ZM27,62L28,61L29,61L30,62L30,63L29,64L28,64L27,63ZM66,61L67,60L68,60L70,62L70,63L68,65L67,65L66,64ZM64,61L65,60L66,61L65,62ZM38,61L39,60L40,60L41,61L41,62L40,63L39,63L38,62ZM97,60L98,59L99,59L100,60L99,61L98,61ZM60,60L61,59L62,59L63,60L63,61L62,62ZM49,59L50,60L50,61L49,62L49,66L48,67L47,67L46,66L46,63L47,62L47,60L48,59ZM49,59L50,58L51,58L52,59L52,60L51,61ZM44,57L46,59L46,70L45,71L45,76L44,77L43,77L42,76L39,77L38,76L38,66L39,65L40,65L41,66L41,72L42,72L42,62L41,61L41,59L43,57ZM91,41L90,41L90,42L87,45L72,45L81,45L82,46L83,46L84,45L86,45L87,46L89,46L91,43ZM40,40L40,45L41,46L43,46L44,45L45,45L46,46L48,46L49,45L59,45L44,45L41,43ZM56,31L57,31L58,32L60,32L59,32L58,31ZM62,16L63,16L65,18L65,19L63,21L62,21L60,19L60,18Z"
	},
	door: {
		w: 88,
		h: 113,
		paper: "M8,0L8,6L5,9L5,10L4,11L4,20L7,23L7,24L8,25L8,42L5,45L5,46L4,47L4,57L7,60L7,62L8,63L8,65L22,65L23,66L23,72L24,72L28,76L29,76L31,78L31,79L33,81L33,82L36,87L36,89L37,90L37,94L38,95L38,105L83,105L85,102L87,102L87,0ZM28,61L29,60L77,60L79,63L79,92L78,93L78,97L77,98L67,98L66,99L47,99L45,97L45,96L44,95L44,89L43,88L43,85L42,84L42,82L41,81L41,79L39,77L39,76L37,74L37,73L31,67L30,67L28,65Z",
		ink: "M9,2L9,7L6,10L6,11L5,12L5,19L8,22L8,23L9,24L9,43L6,46L6,47L5,48L5,56L8,59L8,61L9,62L9,65L22,65L23,66L23,70L24,71L25,71L29,75L30,75L32,77L32,78L34,80L34,81L37,86L37,88L38,89L38,93L39,94L39,104L73,104L74,103L79,103L80,104L82,104L84,101L84,3L82,1L72,1L71,2L49,2L48,1L11,1L10,2ZM13,61L15,59L78,59L80,62L80,93L79,94L79,98L78,99L68,99L67,100L46,100L44,98L44,97L43,96L43,90L42,89L42,86L41,85L41,83L40,82L40,80L38,78L38,77L36,75L36,74L30,68L29,68L26,65L26,64L25,65L23,65L22,64L19,64L18,63L15,63ZM13,7L16,5L25,5L26,6L27,5L38,5L39,6L57,6L58,5L76,5L77,6L78,6L80,9L80,54L79,55L79,57L78,58L15,58L13,55L13,53L14,52L14,28L13,27ZM20,11L20,12L19,13L19,52L21,54L72,54L73,53L73,52L74,51L74,13L72,11L32,11L31,10L23,10L22,11ZM20,13L23,11L35,11L36,12L54,12L55,13L55,14L57,14L57,13L58,12L61,12L62,13L62,15L61,16L59,21L60,18L62,16L62,15L65,12L71,12L73,14L73,50L70,53L42,53L41,52L41,50L40,50L38,52L37,52L36,53L22,53L20,51ZM51,21L51,22L48,25L47,28L47,27L50,24Z"
	},
	engine: {
		w: 295,
		h: 208,
		paper: "M294,204L294,192L292,192L290,190L288,190L287,189L285,189L284,188L271,188L270,189L265,189L263,187L263,186L262,185L256,185L255,184L255,175L256,174L256,165L257,164L257,134L256,133L256,132L254,130L253,130L252,129L249,129L248,128L246,128L245,127L245,126L240,121L239,121L238,120L222,120L221,119L219,119L217,117L217,115L214,112L212,112L211,111L206,111L204,109L204,102L203,101L203,99L201,96L201,87L200,86L200,85L195,81L193,81L192,80L191,80L189,78L189,74L192,72L192,71L194,68L194,63L195,62L195,61L197,59L207,59L208,60L208,64L202,70L202,71L201,72L201,76L202,77L206,77L214,69L215,69L218,66L222,66L223,67L223,91L228,91L229,90L229,89L230,88L230,81L231,80L231,73L232,72L232,66L233,65L233,62L234,61L234,57L235,56L236,56L238,53L238,45L237,44L237,43L229,43L228,42L228,38L230,36L230,35L237,28L238,28L238,26L237,25L232,25L231,24L231,7L227,7L226,6L223,6L222,7L221,7L221,9L220,10L220,15L221,16L221,33L219,35L219,39L218,40L209,40L207,38L206,38L205,37L205,33L206,32L206,30L207,29L207,28L208,27L208,25L209,24L209,18L206,15L205,15L204,14L202,14L201,13L192,13L191,14L191,15L190,16L188,21L186,23L184,28L179,31L158,31L157,30L157,27L156,26L150,26L150,30L149,31L148,31L147,32L139,32L138,31L138,27L136,25L136,23L134,23L133,24L133,25L131,28L131,30L129,32L122,32L120,30L120,29L119,28L119,25L118,24L118,23L116,23L113,26L113,28L111,31L104,31L103,30L103,26L102,25L97,25L96,26L96,28L93,30L89,30L88,29L86,29L85,30L81,30L80,31L74,31L73,30L73,25L72,24L72,22L69,19L62,19L61,20L58,21L53,26L52,26L49,29L49,38L50,39L51,39L53,41L56,42L58,44L58,45L59,46L59,48L60,49L60,56L55,61L52,62L50,64L49,64L48,65L47,65L46,66L45,66L44,67L43,67L42,68L41,68L40,69L39,69L38,70L37,70L36,71L35,71L34,72L33,72L32,73L31,73L30,74L29,74L28,75L27,75L26,76L25,76L24,77L23,77L22,78L17,80L15,82L14,82L14,84L11,87L10,87L7,90L7,91L6,92L6,94L5,95L5,98L4,99L4,108L5,109L5,112L6,113L6,114L10,118L11,118L16,121L18,121L19,122L20,122L21,123L22,123L23,124L24,124L25,125L26,125L27,126L32,128L34,131L34,134L35,135L35,138L36,139L36,141L37,142L37,143L42,148L43,148L46,151L47,151L49,153L52,154L54,156L56,156L63,160L65,160L68,162L71,162L72,163L75,163L76,162L78,162L79,161L80,161L81,160L82,160L83,159L88,157L90,155L93,154L95,152L98,151L100,146L102,144L102,143L105,140L117,140L118,141L125,141L126,142L134,142L135,143L142,143L143,144L152,144L153,145L163,145L164,146L179,146L180,145L183,145L184,144L186,144L187,143L193,143L194,144L199,144L200,145L207,145L208,146L214,146L215,145L218,145L219,144L221,144L222,143L224,143L231,139L238,139L239,138L240,138L242,136L249,136L250,137L250,170L249,171L249,183L248,184L248,187L249,188L249,191L253,195L257,195L258,196L258,198L259,199L267,199L268,200L271,201L273,203L275,203L276,204L278,204L279,205L279,207L289,207L289,205L290,204Z",
		ink: "M216,41L216,42L215,43L215,45L214,46L214,59L203,71L203,72L202,73L202,75L203,76L205,76L213,68L214,68L219,63L222,62L224,64L224,90L227,90L229,87L229,80L230,79L230,72L231,71L231,65L232,64L232,61L233,60L233,58L232,57L234,55L235,55L237,52L237,46L236,45L236,44L229,44L229,47L230,46L231,47L231,55L229,57L226,54L226,53L224,50L224,47L223,46L223,44L222,43L222,42L220,44L219,44L218,43L218,42L217,41ZM228,73L229,74L229,86L227,89L225,87L225,79L226,78L226,75ZM228,66L229,65L230,66L229,67ZM211,66L211,64L212,63L213,63L214,64L214,65L212,67ZM214,61L215,60L216,60L217,61L216,62L215,62ZM217,47L218,46L219,46L220,47L220,48L219,49L218,49L217,48ZM7,93L7,95L6,96L6,99L5,100L5,107L6,108L6,111L7,112L7,113L11,117L12,117L17,120L19,120L20,121L21,121L22,122L23,122L24,123L25,123L26,124L27,124L28,125L33,127L35,130L35,133L36,134L36,137L37,138L37,140L38,141L38,142L43,147L44,147L47,150L48,150L50,152L53,153L55,155L57,155L64,159L66,159L69,161L72,161L73,162L74,162L75,161L77,161L78,160L79,160L80,159L81,159L82,158L87,156L89,154L92,153L94,151L97,150L99,145L101,143L101,142L105,138L108,138L109,139L118,139L119,140L126,140L127,141L135,141L136,142L143,142L144,143L153,143L154,144L164,144L165,145L178,145L179,144L182,144L183,143L185,143L186,142L194,142L195,143L200,143L201,144L208,144L209,145L213,145L214,144L217,144L218,143L220,143L221,142L223,142L230,138L237,138L243,134L244,135L245,135L246,134L248,134L251,136L251,138L252,139L252,142L251,143L251,171L250,172L250,184L249,185L249,186L250,187L250,190L254,194L256,194L256,193L257,192L258,192L259,193L259,197L260,198L261,198L262,197L266,197L267,198L272,200L274,202L276,202L277,203L279,203L280,204L288,204L289,203L291,203L293,200L293,195L292,194L292,193L291,193L289,191L287,191L286,190L284,190L283,189L272,189L271,190L267,190L266,191L265,190L264,190L262,188L262,187L261,186L258,189L255,189L254,188L254,174L255,173L255,164L256,163L256,135L255,134L255,133L253,131L252,131L251,130L248,130L247,129L245,129L244,128L244,127L239,122L238,122L237,121L221,121L220,120L218,120L216,118L216,116L213,113L211,113L210,112L205,112L203,110L203,103L202,102L202,100L200,97L200,88L199,87L199,86L194,82L192,82L187,79L187,75L188,74L188,73L191,71L191,70L193,67L193,62L194,61L194,60L196,58L202,58L205,56L207,56L208,55L210,55L210,50L203,50L202,49L202,48L203,47L203,45L204,44L208,44L209,43L210,44L211,43L212,43L212,41L208,41L206,39L205,39L203,41L203,42L202,43L202,48L201,49L202,52L201,53L200,53L199,52L199,50L198,49L198,45L199,44L199,42L201,40L201,39L204,36L204,32L205,31L205,29L206,28L206,27L207,26L207,24L208,23L208,19L205,16L204,16L203,15L201,15L200,14L193,14L192,15L192,16L191,17L189,22L187,24L185,29L180,32L157,32L155,30L155,29L156,28L155,27L151,27L151,31L148,33L138,33L137,32L137,28L135,26L135,24L132,29L132,31L130,33L121,33L119,31L119,30L118,29L118,26L117,25L117,24L114,27L114,29L112,32L102,32L101,31L101,29L102,28L102,27L101,26L98,26L97,27L97,29L94,31L88,31L87,30L86,31L82,31L81,32L78,33L76,35L75,35L73,33L73,32L72,31L72,26L71,25L71,23L68,20L63,20L62,21L59,22L54,27L53,27L50,30L50,37L51,38L52,38L54,40L57,41L59,43L59,44L60,45L60,47L61,48L61,51L62,52L62,56L56,62L53,63L51,65L50,65L49,66L48,66L47,67L46,67L45,68L44,68L43,69L42,69L41,70L40,70L39,71L38,71L37,72L36,72L35,73L34,73L33,74L32,74L31,75L30,75L29,76L28,76L27,77L26,77L25,78L24,78L23,79L18,81L16,83L15,83L15,85L12,88L11,88L8,91L8,92ZM271,191L273,189L282,189L283,190L285,190L286,191L289,192L291,194L291,196L290,197L288,197L283,194L280,194L279,193L273,193ZM250,132L251,131L252,132L251,133ZM238,128L242,133L240,135L238,135L237,134L237,129ZM188,129L189,128L190,128L191,129L191,131L190,132L189,132L188,131ZM236,126L237,127L237,130L236,131L236,132L235,133L234,133L233,132L233,129L234,128L234,127L235,126ZM232,125L233,126L233,129L231,131L230,130L230,127ZM221,127L223,125L228,125L229,126L229,127L227,129L224,129ZM163,126L164,125L166,125L167,126L167,128L166,129L165,129L163,127ZM139,123L140,122L142,122L143,123L143,125L142,126L140,126L139,125ZM73,120L74,121L74,122L71,125L70,125L69,124L69,122L71,120ZM114,122L114,121L116,119L118,119L120,121L118,123L115,123ZM48,121L48,119L49,118L51,118L52,119L52,120L50,122L49,122ZM88,118L90,116L91,116L93,118L93,119L92,120L90,120ZM30,111L32,113L30,115L28,113ZM19,106L20,105L31,105L32,106L38,106L39,107L43,107L44,108L45,108L47,110L49,110L50,111L52,111L53,112L58,112L59,113L69,113L70,114L76,114L77,113L79,113L80,112L82,112L85,110L97,110L98,111L106,111L107,112L114,112L115,113L123,113L126,115L128,115L129,114L131,114L132,115L139,115L140,116L144,116L145,117L157,117L158,118L164,118L165,119L167,119L168,120L169,120L170,119L171,120L179,120L180,121L184,121L185,122L192,122L193,123L198,123L199,124L202,124L203,125L206,125L207,126L211,126L211,124L214,121L217,121L218,122L221,122L222,123L222,124L219,129L215,129L215,134L214,135L212,133L212,132L211,131L211,129L208,129L207,128L202,128L201,127L196,127L195,126L190,126L189,125L180,125L179,124L172,124L171,123L164,123L163,122L154,122L153,121L144,121L143,120L136,120L135,119L127,119L126,118L118,118L117,117L111,117L110,116L104,116L103,115L93,115L92,114L89,114L88,113L87,114L85,114L84,115L82,115L81,116L79,116L78,117L57,117L56,116L51,116L50,115L48,115L45,112L44,112L41,110L36,110L35,109L26,109L25,108L20,108L19,107ZM179,105L181,103L182,103L183,104L183,105L186,104L188,106L189,109L191,109L193,111L191,113L190,113L189,112L182,112L179,110ZM196,102L199,105L199,107L197,110L195,110L193,108L193,105ZM166,104L168,102L170,102L171,103L172,103L174,105L174,106L173,107L170,108L169,107L167,107L166,106ZM157,103L158,102L159,102L160,103L159,104L158,104ZM191,101L192,100L193,101L193,102L192,103L191,102ZM160,97L158,99L158,101L156,104L158,106L160,106L161,107L160,108L160,113L159,114L152,114L151,113L145,113L144,112L141,112L139,110L139,108L141,106L142,106L142,103L144,101L146,101L147,102L147,103L148,103L152,99L154,99L157,96L159,96ZM123,96L124,95L126,97L125,98L124,98L123,97ZM9,102L10,101L10,97L11,96L11,95L12,94L13,94L14,95L14,96L13,97L13,104L14,105L18,105L19,106L19,107L18,108L12,108L15,111L16,111L23,115L25,115L27,117L28,117L29,118L30,118L31,119L32,119L33,120L38,122L41,125L41,127L43,130L43,133L44,134L44,136L46,139L47,139L49,141L50,141L52,143L53,143L55,145L56,145L58,147L59,147L64,151L67,151L68,152L70,152L71,153L73,153L73,145L74,144L74,139L75,138L76,138L77,139L77,152L77,127L78,126L79,126L81,129L81,150L81,126L83,124L84,125L84,127L85,128L85,134L85,127L84,126L84,125L86,123L87,123L89,126L89,137L90,136L92,138L92,141L93,142L93,144L94,143L95,140L97,138L97,137L101,132L113,132L114,133L123,133L124,134L131,134L132,135L139,135L140,136L150,136L151,137L158,137L159,138L177,138L180,136L182,136L184,134L190,134L191,135L199,135L200,136L208,136L209,137L218,137L219,136L223,136L224,135L226,135L227,134L228,135L228,137L227,138L224,138L223,139L219,139L218,140L208,140L207,139L200,139L199,138L192,138L191,137L185,137L184,138L183,138L182,139L180,139L175,142L173,142L172,141L155,141L154,140L146,140L145,139L137,139L136,138L130,138L129,137L120,137L119,136L107,136L106,135L103,135L99,139L98,142L94,147L93,147L91,149L90,149L89,150L88,150L87,151L86,151L85,152L84,152L83,153L82,153L75,157L71,157L70,156L68,156L67,155L66,155L65,154L64,154L63,153L62,153L61,152L60,152L59,151L54,149L52,147L49,146L42,139L42,138L41,137L41,135L40,134L40,132L38,129L38,127L37,126L36,126L34,124L31,123L29,121L28,121L23,118L21,118L19,116L18,116L17,115L16,115L14,113L13,113L10,110L10,107L9,106ZM148,93L150,95L150,96L148,98L147,98L146,97L146,95ZM196,92L196,96L192,100L190,100L189,99L184,99L183,98L180,98L178,96L178,94L179,93L187,93L188,94L192,94L193,93L193,91L194,90ZM142,90L143,89L155,89L156,90L168,90L169,91L170,91L173,94L173,95L170,97L169,97L168,96L162,96L161,95L155,95L154,94L149,94L148,93L146,93L145,92L144,92ZM188,89L189,88L190,88L192,90L192,91L190,93L188,91ZM108,89L109,88L110,88L112,91L110,93L109,93L108,92ZM40,88L41,89L40,90L40,93L39,94L39,100L36,102L31,102L29,100L29,96L30,95L30,94L35,90ZM19,87L20,88L20,89L19,90L19,91L16,93L15,92L15,91ZM186,86L188,88L188,91L187,92L185,92L184,91L184,88ZM182,86L184,88L184,91L183,92L182,92L180,90L180,88ZM178,86L180,88L180,91L179,92L178,92L176,90L176,88ZM72,85L73,86L73,87L71,89L71,90L69,93L69,95L68,96L68,101L67,102L67,103L66,104L65,104L64,103L64,99L65,98L65,95L67,93L67,89L69,87L69,86L70,85ZM37,85L38,84L39,84L40,85L39,86L38,86ZM22,84L23,85L20,88L19,87L19,86L21,84ZM158,82L160,82L161,83L161,87L160,88L158,88L157,87L157,83ZM138,83L139,82L140,82L141,83L141,85L140,86L139,86L138,85ZM135,83L136,82L137,82L138,83L137,84L136,84ZM127,83L128,82L129,82L130,83L130,84L129,85L128,85L127,84ZM162,81L164,81L165,82L165,87L163,89L162,89L161,88L161,82ZM26,81L27,82L27,83L26,84L23,85L22,84L24,82L25,82ZM167,79L169,81L169,88L167,90L166,90L165,89L165,81ZM170,78L171,78L172,79L172,89L171,90L170,90L169,89L169,79ZM62,75L65,77L65,79L64,80L62,80L60,78L60,77ZM80,74L81,75L81,87L80,88L80,89L79,90L78,90L77,89L77,83L78,82L78,75L79,74ZM106,72L107,73L108,76L108,75L109,74L110,74L111,75L111,81L109,83L107,81L107,79L107,81L106,82L105,82L104,81L104,74ZM102,72L104,75L104,78L103,79L103,80L102,81L101,81L100,80L100,74ZM181,70L181,69L182,68L184,68L185,69L183,71L182,71ZM52,69L53,68L54,68L55,69L54,70L53,70ZM179,65L181,65L182,66L182,68L181,69L181,72L180,73L179,73L178,72L178,66ZM58,66L59,65L60,65L61,66L60,67L59,67ZM64,62L65,63L65,64L64,65L61,66L60,65L63,62ZM188,56L189,57L189,65L187,67L186,67L185,66L185,64L186,63L186,58ZM188,56L189,55L190,56L189,57ZM194,52L195,51L196,51L197,52L196,53L195,53ZM189,49L190,50L190,51L189,52L188,52L187,51ZM73,42L74,41L76,41L77,42L77,43L76,44L74,44L73,43ZM42,101L42,93L44,90L44,88L45,87L45,85L46,84L46,83L48,81L49,78L52,75L56,75L58,77L58,78L56,80L58,80L59,81L60,81L62,83L62,84L61,85L61,87L60,88L60,90L58,93L58,96L57,97L57,106L58,107L69,107L69,105L70,104L70,102L71,101L71,99L72,98L72,97L77,92L80,92L81,93L82,93L83,92L89,92L90,91L92,91L92,73L92,80L91,81L90,81L88,79L88,77L88,78L87,79L86,79L85,78L85,73L85,77L83,79L82,78L82,76L81,75L81,73L80,73L79,72L79,68L82,66L90,66L96,72L96,88L96,73L97,72L99,72L100,73L100,80L99,81L100,82L100,85L100,83L101,82L102,82L104,84L104,88L105,87L106,87L108,89L108,93L114,93L114,91L115,90L115,81L114,80L114,78L113,77L113,76L109,72L106,72L103,69L101,69L98,67L97,67L96,68L93,67L91,65L89,59L83,59L82,58L82,57L83,56L93,56L94,57L100,57L101,58L101,60L100,61L101,62L101,63L106,63L107,64L117,64L118,65L137,65L138,64L138,63L135,63L134,64L125,64L122,61L122,57L121,56L116,56L115,57L115,59L114,60L113,59L112,59L111,60L112,60L114,62L112,64L111,64L110,63L107,63L104,60L104,58L105,57L105,54L104,53L100,53L99,52L83,52L82,53L82,56L79,59L75,59L72,57L72,56L71,55L71,53L72,52L72,51L73,50L75,45L77,43L77,42L80,39L82,39L83,38L92,38L93,39L100,39L101,40L106,40L107,41L117,41L118,42L122,42L123,43L126,43L127,44L131,44L132,45L136,45L137,46L142,46L143,47L147,47L148,48L152,48L153,49L156,49L157,50L160,50L161,51L164,52L168,56L168,57L169,58L169,64L167,66L166,66L165,67L163,67L162,66L161,66L158,63L158,60L157,59L157,58L155,56L148,56L147,55L137,55L136,56L135,56L134,57L134,59L137,59L138,58L145,58L146,59L149,60L151,63L151,69L149,72L148,72L147,73L145,73L144,74L142,74L139,71L133,71L132,72L132,74L131,75L129,75L128,74L128,73L127,74L126,74L125,75L125,76L122,81L122,83L121,84L121,88L121,87L122,86L123,86L124,87L124,91L123,92L123,93L122,94L121,94L121,96L118,99L118,100L115,102L105,102L104,101L101,101L100,102L94,102L91,99L90,99L88,97L88,96L89,95L94,95L95,96L104,96L105,97L111,97L108,97L107,96L95,96L94,95L87,95L87,96L86,97L85,97L84,96L84,95L83,95L82,96L80,96L77,99L77,101L78,101L79,102L87,102L88,103L97,103L98,104L105,104L106,105L114,105L115,106L123,106L123,104L124,103L124,102L125,101L125,100L126,99L128,94L129,93L132,92L132,91L133,90L136,90L137,89L138,89L142,93L142,95L138,102L138,104L137,105L136,108L133,111L128,111L125,109L123,109L122,110L121,110L120,109L112,109L111,108L103,108L102,107L93,107L92,106L91,107L81,107L80,108L78,108L77,109L74,109L73,110L59,110L58,109L56,109L55,108L54,108L53,107L48,105L46,103L44,103ZM100,87L100,89L99,90L97,90L97,92L98,93L101,93L102,92L102,91L100,89ZM56,84L55,85L54,85L53,84L51,84L49,86L49,88L47,91L49,89L52,89L53,90L55,88L55,87L56,86ZM159,56L161,58L161,60L163,62L165,62L163,60L163,59L160,56ZM126,55L126,54L125,53L123,53L122,52L122,51L123,50L121,50L118,52L115,52L114,53L113,53L113,54L116,52L121,52L122,53L124,53ZM103,48L103,49L106,49ZM101,37L102,36L109,36L110,37L110,38L108,40L106,40L105,39L102,39L101,38ZM137,36L138,35L144,35L145,36L145,39L144,40L143,40L142,39L143,38L141,38L140,39L139,38L138,38L137,37ZM118,36L119,35L129,35L131,37L129,39L128,39L127,40L124,40L123,39L122,40L121,39L120,39L118,37ZM96,34L97,33L98,34L97,35ZM162,33L163,32L164,33L164,34L163,35L162,34ZM64,25L66,25L68,27L68,33L69,34L69,37L70,38L70,40L72,42L72,43L73,44L73,45L72,46L71,46L70,45L70,44L67,41L67,40L64,37L65,38L65,39L67,41L67,42L68,43L68,45L69,46L69,51L70,52L70,53L68,55L67,55L65,52L65,50L63,47L63,45L62,44L62,42L61,41L60,38L59,37L58,37L55,34L55,32L56,31L57,31L59,33L60,33L60,30L61,29L62,29L63,30L63,31L63,26ZM205,19L205,20L203,22L203,23L202,24L201,24L199,22L198,22L197,23L197,24L194,29L194,31L193,32L193,34L194,35L196,33L198,33L199,34L198,35L198,36L201,39L198,44L198,46L196,48L195,47L195,45L194,44L194,43L193,44L190,44L189,43L189,42L190,41L193,41L193,39L192,38L188,38L185,41L185,42L184,43L185,46L184,47L184,51L183,52L183,57L182,58L182,62L180,64L179,63L179,59L178,58L178,48L177,47L177,45L176,44L176,43L175,43L172,41L157,41L156,40L149,40L147,38L148,37L149,37L149,36L152,34L153,35L153,36L152,37L155,37L155,36L157,34L158,35L168,35L169,36L179,36L180,35L182,35L183,34L185,34L188,31L188,30L189,29L189,28L190,27L192,22L195,19L195,17L197,15L198,15L199,16L201,16L202,17L203,17ZM230,8L226,8L225,7L224,7L223,8L222,8L222,10L221,11L221,14L222,15L222,30L223,31L223,33L220,36L220,39L221,39L222,38L225,38L226,37L227,37L229,35L229,34L236,27L237,27L236,26L232,30L230,30L229,29L229,24L230,23ZM226,28L226,26L227,25L229,27L227,29ZM229,9L230,10L230,21L228,23L227,23L226,22L226,13L227,12L227,10L228,9Z"
	},
	fuelTank: {
		w: 136,
		h: 140,
		paper: "M9,5L7,7L7,10L9,13L24,13L25,14L28,15L32,19L32,28L34,30L37,30L38,31L38,35L33,40L33,41L31,43L31,77L30,78L30,116L31,117L31,120L32,121L32,122L38,128L44,128L45,129L58,129L59,128L113,128L114,127L116,127L117,126L118,126L121,123L121,122L123,119L123,114L124,113L124,109L123,108L123,98L124,97L124,27L125,26L125,22L124,21L124,16L123,15L123,13L120,10L120,9L115,6L112,6L111,5L71,5L70,6L66,6L65,7L62,8L56,14L52,14L51,13L51,12L49,10L44,10L43,11L38,11L34,7L33,7L30,5Z",
		ink: "M10,6L8,8L8,9L10,12L25,12L26,13L29,14L34,19L34,20L35,21L35,22L33,25L33,27L35,29L37,29L38,28L39,29L40,29L42,32L39,35L39,36L34,41L34,42L32,44L32,78L31,79L31,115L32,116L32,119L33,120L33,121L39,127L45,127L46,128L57,128L58,127L112,127L113,126L115,126L116,125L117,125L120,122L120,121L122,118L122,113L123,112L123,110L122,109L122,97L123,96L123,26L124,25L124,23L123,22L123,17L122,16L122,14L119,11L119,10L114,7L111,7L110,6L72,6L71,7L67,7L66,8L63,9L53,19L52,19L51,18L50,18L48,16L50,13L48,11L45,11L43,14L42,14L40,16L39,16L38,15L38,12L37,12L33,8L32,8L29,6ZM47,18L48,19L48,20L45,23L44,23L43,22L43,21L46,18ZM114,12L118,16L118,17L119,18L119,69L118,70L118,79L119,80L119,107L118,108L118,116L117,117L117,118L114,121L113,121L112,122L109,122L108,123L53,123L52,124L49,124L48,123L42,123L41,122L40,122L36,117L36,115L35,114L35,112L36,111L36,103L35,102L35,97L36,96L36,65L37,64L37,46L38,45L38,44L40,42L40,41L53,27L53,26L66,13L67,13L68,12L70,12L71,11L82,11L83,10L105,10L106,11L112,11L113,12ZM102,117L102,118L103,118L103,117ZM59,115L59,116L60,117L60,116ZM115,113L114,113L114,115L115,114ZM63,85L63,95L63,91L64,90L64,88L63,87ZM47,76L48,77L48,80L47,81L47,83L48,84L48,92L47,93L48,92L48,77ZM114,74L114,95L115,94L115,89L114,88L114,84L115,83L115,75ZM40,68L40,83L39,84L39,86L40,87L40,94ZM64,67L63,68L63,73L64,72L63,71L63,69L64,68ZM48,67L47,67L47,70L48,69ZM103,66L102,67L102,70L103,71L103,75L102,76L102,94L103,94ZM99,66L99,81L98,82L98,83L99,84L98,85L98,87L99,88L99,89ZM52,45L52,47L51,48L51,49L52,49ZM102,43L102,44L103,45L103,48L103,44ZM63,42L63,49L64,48L64,47L63,46ZM70,24L70,33L73,36L74,36L75,37L106,37L109,35L109,34L111,31L111,25L110,24L110,23L108,21L107,21L106,20L74,20L73,21L72,21L72,22ZM75,31L75,26L77,24L80,24L81,25L87,25L88,24L89,25L105,25L107,28L106,29L106,31L105,32L76,32ZM114,19L114,48L115,48L115,39L114,38L114,26L115,25L115,22L114,21ZM12,8L13,7L30,7L35,12L35,13L34,14L33,14L32,13L31,13L28,10L24,10L23,11L22,11L21,10L13,10L12,9Z"
	},
	gears: {
		w: 182,
		h: 211,
		paper: "M74,7L71,9L66,9L65,10L61,10L61,12L60,13L59,13L59,17L58,18L56,18L55,19L52,19L52,22L51,23L48,23L48,27L47,28L44,28L44,31L43,32L42,32L42,34L41,35L40,35L40,38L39,39L38,39L36,42L35,42L35,45L34,46L30,46L29,47L29,49L30,50L30,57L28,59L28,60L27,61L21,61L21,64L24,66L24,71L22,73L22,83L19,86L19,89L18,90L18,93L16,95L16,105L15,106L15,109L16,110L16,114L17,115L17,120L18,121L18,126L16,128L10,128L10,130L11,131L11,135L12,136L12,140L13,140L14,141L14,146L15,146L16,147L16,151L17,152L17,156L19,156L20,157L20,161L21,162L21,165L23,165L24,166L24,170L27,172L27,174L29,174L30,175L30,178L33,180L33,182L35,182L36,183L36,185L39,188L39,189L40,189L41,190L41,192L43,192L44,193L44,194L45,194L47,196L49,196L50,197L50,198L52,198L53,199L55,199L58,201L60,201L61,202L63,202L64,203L76,203L77,204L99,204L100,203L103,203L104,202L105,202L107,200L110,200L112,197L114,197L115,196L117,196L119,193L121,193L121,191L122,190L125,190L125,187L126,186L128,186L131,183L131,181L132,180L134,180L134,177L137,175L137,173L138,172L140,172L140,170L142,167L142,164L144,162L144,158L146,156L147,156L147,153L146,152L146,146L148,144L152,144L153,143L153,142L155,140L155,139L157,137L157,136L158,135L158,133L161,128L161,126L162,125L162,123L163,122L163,119L164,118L164,115L166,113L175,113L175,111L173,109L173,104L171,104L170,105L166,105L165,104L165,93L164,92L164,89L163,88L163,85L162,84L162,83L161,82L161,81L160,80L158,75L156,73L153,73L151,71L151,70L150,69L150,66L147,63L147,58L148,57L148,55L147,54L147,49L146,48L146,47L144,45L144,43L143,43L142,42L142,40L138,36L137,33L136,33L135,32L135,30L133,30L132,29L132,27L131,27L130,26L130,25L128,25L127,24L127,23L123,19L122,19L120,17L119,17L118,16L118,15L116,15L115,14L114,14L112,12L109,12L106,10L101,10L100,9L96,9L95,8L85,8L84,7ZM117,142L118,141L122,141L123,142L123,146L122,147L118,147L117,146ZM145,103L146,102L150,102L151,103L155,103L156,104L156,108L155,109L152,109L150,111L146,111L145,110ZM134,92L134,97L133,98L121,98L120,99L120,101L119,102L113,102L111,100L111,95L113,93L113,92L118,87L119,87L121,85L127,85L130,88L131,88L132,89L132,90ZM117,65L118,66L118,70L117,71L114,71L110,81L109,82L105,82L105,83L104,84L104,87L103,88L103,93L102,94L102,98L101,99L94,99L94,105L92,107L88,107L87,106L87,96L88,95L88,91L89,90L89,87L90,86L90,82L88,82L88,84L87,85L87,88L86,89L86,91L85,92L85,94L84,95L84,105L83,106L83,109L80,112L78,112L78,113L77,114L76,114L76,115L75,116L70,116L69,115L69,97L70,96L70,89L71,88L71,86L72,85L72,83L74,80L74,76L76,74L76,73L77,72L81,72L82,71L83,68L85,66L86,66L87,65L95,65L96,66L98,66L99,67L99,71L102,71L102,70L103,69L103,67L105,65Z",
		ink: "M89,83L89,85L88,86L88,89L87,90L87,92L86,93L86,95L85,96L85,106L84,107L84,109L86,112L85,113L84,113L83,112L83,111L81,113L79,113L79,114L78,115L77,115L78,116L78,117L77,118L77,120L78,121L77,124L78,125L78,126L77,127L76,127L75,126L75,124L74,123L74,121L73,120L72,117L72,121L73,122L73,125L74,126L74,129L75,130L75,133L76,134L76,136L79,141L79,143L81,145L82,148L88,154L89,154L91,156L92,156L95,158L117,158L118,159L136,159L137,158L139,158L140,157L142,157L143,156L146,155L146,154L144,156L142,156L141,157L135,157L134,156L128,156L127,155L125,155L123,153L122,153L114,145L113,145L110,142L110,141L108,139L108,138L105,133L105,131L103,128L103,126L102,125L102,122L101,121L101,117L100,116L100,109L98,109L97,108L97,107L98,106L99,106L98,106L97,105L97,104L98,103L96,100L95,100L96,101L96,103L95,104L96,105L96,106L93,108L91,108L91,109L90,110L91,110L92,109L95,109L96,110L96,111L95,112L93,112L92,113L90,113L91,114L90,115L90,116L91,117L91,121L92,121L92,120L93,119L96,119L97,120L93,124L92,124L94,124L95,125L95,126L94,127L93,127L93,128L94,129L94,132L95,133L95,137L94,138L93,138L92,137L92,135L91,134L91,131L90,130L90,128L88,125L88,124L89,123L88,122L88,118L87,117L87,114L86,113L86,106L85,105L85,100L86,99L86,95L87,94L87,90L88,89L88,86L89,85ZM112,151L113,152L113,153L111,155L108,156L107,155L107,154ZM100,149L101,148L104,151L103,152L102,152L100,150ZM97,149L97,148L98,147L99,147L100,148L98,150ZM94,139L96,141L96,142L97,143L97,145L96,146L94,144L94,143L93,142L93,140ZM93,128L95,126L97,128L96,129L94,129ZM91,118L91,117L94,115L95,116L96,116L97,115L99,115L100,116L100,117L99,118L95,118L94,119L92,119ZM127,59L122,62L122,63L121,64L121,65L122,66L122,68L118,72L115,72L115,73L113,76L113,78L111,81L111,84L110,85L110,88L109,89L109,92L108,93L108,96L107,97L105,97L104,96L104,93L105,92L105,85L106,84L106,83L106,84L105,85L105,88L104,89L104,94L103,95L103,102L104,103L106,103L107,100L110,97L110,94L112,92L112,91L117,86L118,86L120,84L122,84L123,83L125,83L126,84L128,84L131,87L132,87L133,88L133,89L135,91L135,92L136,93L136,95L137,96L137,98L136,99L122,99L121,100L121,101L122,102L127,102L128,103L128,104L126,106L121,106L118,103L112,103L111,102L109,102L109,104L107,106L107,121L108,122L108,124L109,125L109,127L110,128L110,129L111,130L111,131L112,132L112,133L113,134L115,139L116,140L117,140L118,139L120,139L121,138L122,139L123,139L125,141L124,142L124,147L125,148L128,148L129,149L133,149L134,150L140,150L141,149L143,149L145,147L145,145L148,142L150,142L151,143L152,142L152,141L154,139L154,138L156,136L156,135L157,134L157,132L160,127L160,125L161,124L161,122L162,121L162,118L163,117L163,114L165,112L174,112L172,110L172,105L170,107L170,108L169,109L166,109L165,110L153,110L149,114L141,114L140,113L140,112L141,111L144,111L144,108L143,107L141,107L140,106L138,106L137,107L136,106L129,106L128,105L129,104L129,101L130,100L134,100L135,99L138,101L146,101L147,100L148,100L147,100L146,99L141,99L139,97L139,96L140,95L141,95L142,96L147,96L148,97L151,98L153,100L152,101L151,101L152,102L156,102L157,103L160,103L161,102L162,102L163,103L164,103L164,94L163,93L163,90L162,89L162,86L161,85L161,84L160,83L160,82L159,81L157,76L155,74L152,74L150,72L150,71L149,70L149,67L143,61L142,61L139,59ZM143,141L144,140L145,140L146,141L146,142L145,143L144,143L143,142ZM153,126L154,127L154,129L153,130L153,132L152,133L152,134L148,139L146,139L144,137L146,135L148,135L148,134L150,132L150,130L151,129L151,128ZM151,116L153,116L154,117L154,122L152,125L150,125L148,123L149,122L149,119ZM148,115L149,116L149,118L148,119L148,121L147,122L147,125L145,128L145,130L144,131L142,136L140,138L140,139L137,142L136,142L135,141L136,140L136,139L138,137L138,135L139,134L139,133L141,131L140,130L140,129L141,128L141,126L142,125L142,123L143,122L143,120L144,119L145,119L146,118L146,117ZM110,112L111,111L113,113L113,115L114,116L114,117L117,120L118,120L119,121L120,121L117,118L117,115L118,114L118,113L120,111L125,111L126,112L127,112L129,115L129,121L130,122L130,123L128,125L127,125L126,126L118,126L113,121L113,120L110,115ZM130,111L131,110L132,110L133,111L135,111L137,113L135,115L135,116L134,117L132,117L131,116L131,113L130,112ZM106,97L107,98L107,99L106,100L105,100L104,99ZM154,89L156,91L156,93L157,94L157,96L158,97L158,100L157,101L156,101L155,100L155,97L154,96L154,93L153,92L153,90ZM79,70L80,71L81,70L82,67L84,65L85,65L86,64L86,63L87,62L87,61L86,60L88,58L89,59L91,57L91,56L92,55L94,55L95,56L95,58L94,59L94,60L92,62L92,64L95,62L96,62L97,63L97,65L98,64L99,65L100,64L102,66L100,68L100,70L101,70L101,69L102,68L102,66L104,64L108,64L109,63L112,63L113,64L114,64L116,62L116,61L122,55L123,55L128,52L137,52L138,53L140,53L143,56L145,56L146,57L147,56L146,56L144,54L142,54L140,52L137,52L136,51L116,51L115,52L114,52L113,51L111,51L110,52L109,51L108,51L107,52L100,52L99,53L95,53L94,54L92,54L85,61L85,62L82,65L82,66L80,68L80,69ZM104,60L105,61L105,63L104,64L101,65L100,64L100,63L103,60ZM75,8L72,10L67,10L66,11L64,11L63,12L62,11L62,13L61,14L60,14L62,17L59,19L57,19L56,20L53,20L53,21L54,21L55,22L55,23L54,24L49,24L51,24L52,25L51,26L51,27L52,28L51,29L45,29L48,31L46,33L43,33L44,34L44,35L43,36L41,36L41,39L38,41L39,41L40,42L40,43L39,44L36,43L37,44L37,45L35,47L31,47L30,48L31,47L32,47L33,48L33,49L32,50L31,50L34,52L34,53L31,55L31,58L29,60L30,61L28,63L23,63L22,62L22,63L23,64L27,64L28,65L28,66L27,67L25,67L25,68L27,70L27,71L25,73L24,73L23,74L23,75L24,76L24,79L23,80L24,81L24,83L20,87L20,88L21,88L22,89L19,91L19,92L20,92L22,94L21,95L18,95L17,96L17,99L18,98L20,98L21,99L21,101L20,102L19,101L19,102L18,103L20,103L21,104L21,105L19,107L18,107L17,106L16,107L16,108L19,108L20,109L20,111L19,112L17,112L17,113L18,114L20,114L21,115L21,116L20,117L19,117L18,118L18,119L20,119L21,120L21,121L19,124L20,123L21,123L22,124L22,125L19,128L18,128L16,130L15,130L14,129L11,129L14,129L16,131L17,130L20,130L21,131L21,132L20,133L18,133L17,134L15,134L14,133L13,133L12,134L13,135L20,135L21,134L23,134L24,135L21,138L20,138L19,139L17,137L15,140L14,139L13,139L14,139L15,140L21,140L22,139L23,139L24,140L24,141L22,143L19,143L18,144L15,144L15,145L16,145L17,146L18,145L23,145L24,144L25,144L26,145L26,146L23,149L21,149L20,150L18,150L17,149L17,150L19,150L20,151L23,151L24,150L27,150L28,151L28,152L27,153L26,153L23,155L20,155L19,154L18,154L18,155L25,155L26,154L28,154L29,155L29,156L25,160L23,160L22,159L21,159L21,160L25,160L26,161L27,161L28,162L28,163L27,164L22,164L24,164L27,166L28,165L29,166L30,166L32,164L33,164L34,165L34,166L32,168L31,168L30,169L29,169L28,168L25,168L25,169L26,170L29,170L31,172L30,173L28,173L33,173L34,174L35,174L35,173L36,172L37,172L38,173L38,174L36,176L35,176L34,177L33,176L32,177L31,177L34,179L34,181L40,181L41,182L39,184L37,184L40,187L40,188L41,188L42,189L42,191L43,190L44,190L45,191L45,193L46,193L48,195L50,195L51,196L51,197L53,197L54,198L56,198L57,199L58,199L59,200L61,200L62,201L63,201L64,200L65,201L65,202L66,201L68,201L69,202L77,202L78,203L98,203L99,202L102,202L103,201L104,201L107,198L108,198L109,199L111,196L113,196L114,195L116,195L117,194L117,192L118,191L119,192L120,192L120,190L121,189L124,189L124,186L125,185L127,185L130,182L130,180L131,179L133,179L133,176L136,174L136,172L137,171L139,171L139,169L141,166L141,163L143,161L143,159L141,161L139,161L138,162L115,162L114,161L113,161L110,163L98,163L97,162L94,162L93,161L92,161L90,159L89,159L80,150L80,149L76,144L76,143L72,136L72,134L71,134L71,139L72,140L72,150L73,151L73,153L72,154L71,153L71,152L69,149L69,147L68,146L68,135L69,134L69,132L70,131L70,128L70,129L69,130L69,133L68,134L68,147L69,148L69,150L70,151L70,153L71,154L72,157L78,163L80,163L82,165L81,166L79,166L78,165L75,164L70,159L70,158L68,156L68,155L66,152L66,149L65,148L65,143L64,143L64,144L63,145L63,146L64,147L64,150L63,151L61,151L60,150L56,150L53,148L53,146L55,143L56,143L58,146L59,146L60,145L60,144L59,143L57,143L55,141L53,141L52,140L52,137L53,136L56,136L54,136L53,135L53,132L55,130L63,130L65,132L64,133L61,133L63,133L65,135L65,136L64,137L58,137L57,138L57,139L58,139L59,138L60,139L62,139L64,141L64,140L63,140L62,139L62,138L63,137L65,137L65,132L69,125L69,121L68,121L67,120L66,121L65,121L63,119L62,119L60,117L60,116L61,115L68,115L66,115L65,114L68,111L68,96L69,95L69,88L70,87L70,85L71,84L71,82L73,79L73,78L72,78L71,77L71,75L73,73L74,74L75,73L72,72L71,71L71,69L72,68L77,68L79,66L79,65L81,63L81,62L83,60L83,59L87,55L87,54L83,54L82,53L81,53L80,54L79,53L78,54L77,53L77,52L77,53L76,54L74,54L68,60L68,61L64,68L64,71L64,70L66,68L67,69L67,74L68,75L68,79L66,81L66,83L67,84L67,86L66,87L65,87L64,86L64,83L63,82L63,75L64,74L63,73L63,85L64,86L64,89L65,90L65,92L64,93L63,93L62,92L62,91L61,90L61,87L60,86L60,70L61,69L61,67L62,66L62,64L63,63L63,62L65,60L65,59L74,50L66,50L65,49L64,50L63,49L63,50L69,50L70,51L70,52L67,54L65,54L65,56L64,57L64,58L62,60L56,60L55,59L53,59L51,57L52,56L52,55L55,53L56,53L58,55L61,54L58,54L56,52L56,51L59,48L60,49L62,46L69,46L70,47L72,44L77,44L78,45L81,44L82,45L82,47L83,48L82,49L79,49L78,48L76,48L76,49L77,49L78,50L85,50L86,51L87,51L89,53L87,51L88,50L90,50L91,51L91,52L94,50L97,50L98,49L103,49L104,48L118,48L119,47L135,47L138,49L140,49L141,50L143,50L144,51L145,51L146,50L145,49L145,48L143,46L143,44L141,44L140,43L140,42L141,41L137,37L136,34L134,34L133,33L133,32L134,31L132,31L131,30L131,28L130,29L129,28L129,26L127,26L126,25L126,24L122,20L121,20L119,18L118,18L117,17L117,16L116,17L111,13L110,14L109,14L107,12L106,12L105,11L100,11L99,10L95,10L94,9L84,9L83,8ZM45,186L46,185L47,185L48,186L48,187L47,188L46,188L45,187ZM112,184L113,185L113,186L112,187L111,187L110,186ZM81,185L82,184L84,186L84,187L83,188L82,188L81,187ZM87,181L89,183L89,185L86,188L85,187L85,186L86,185L85,182L86,181ZM74,180L75,179L76,180L76,181L75,182L74,181ZM40,181L42,179L43,179L44,180L44,181L43,182L41,182ZM76,179L79,177L87,177L90,180L89,181L87,181L86,180L85,181L82,182L81,181L82,180L80,180L79,181L78,181ZM34,179L36,177L37,177L38,176L40,176L41,177L41,178L38,180L35,180ZM89,169L90,170L90,171L89,172L88,172L87,171ZM35,169L36,170L36,171L34,173L33,173L32,172L32,171L34,169ZM74,170L74,169L75,168L85,168L86,169L84,171L82,171L81,172L77,172ZM86,164L86,163L87,162L89,162L90,163L88,165L87,165ZM61,164L64,162L72,162L73,163L73,165L72,166L69,166L68,167L65,167L64,166L62,166L61,165ZM81,162L82,161L85,161L86,162L86,164L84,166L83,166L82,165L83,164L82,164L81,163ZM78,162L79,161L80,161L81,162L80,163L79,163ZM28,161L30,159L31,159L32,160L32,161L31,162L29,162ZM57,159L58,158L59,158L59,157L60,156L62,156L64,158L65,157L67,157L68,158L67,159L68,159L69,160L69,161L68,162L61,162L60,161L59,162L58,162L57,161ZM54,151L55,150L57,150L58,151L58,152L63,152L66,155L66,156L65,157L63,157L62,156L59,156L58,157L56,157L54,155L55,154ZM59,119L63,119L64,120L64,121L67,121L68,122L68,123L69,124L67,126L64,126L65,126L66,127L66,129L65,130L55,130L54,129L54,128L56,126L57,126L58,125L61,125L58,125L56,123L56,122L58,120L59,121L58,120ZM33,108L34,109L34,110L32,112L31,112L30,111L30,110L32,108ZM28,104L29,104L30,105L30,110L29,111L28,111L27,110L28,109L28,107L27,106L27,105ZM33,102L36,104L36,105L38,108L38,112L37,113L37,114L34,117L30,117L31,118L31,124L32,125L32,130L33,131L33,135L34,136L34,138L35,139L35,142L36,143L36,144L37,145L37,146L38,147L38,148L39,149L39,150L40,151L40,152L41,153L43,158L45,160L47,165L50,168L50,169L52,171L52,172L53,172L61,180L62,180L64,182L67,183L69,185L72,186L74,188L79,188L80,189L95,189L96,188L100,188L101,187L103,187L104,186L105,186L106,187L106,188L105,189L104,189L103,190L100,190L99,191L97,191L96,192L78,192L77,191L73,191L72,190L70,190L69,189L68,189L67,188L62,186L59,183L58,183L51,176L51,175L47,171L47,170L45,168L45,167L41,163L41,162L40,161L40,160L36,153L36,151L33,146L33,144L32,143L32,142L31,141L31,139L30,138L30,134L29,133L29,130L28,129L28,121L26,119L28,116L27,113L28,112L33,112L35,110L35,107L32,104L32,103ZM28,100L28,98L29,97L30,97L31,98L31,99L29,101ZM31,89L32,90L32,92L30,94L29,93L29,90L30,89ZM49,90L52,88L55,89L54,89L53,88L54,87L58,87L60,90L60,92L59,93L58,93L59,93L61,95L60,96L61,97L61,98L58,100L56,100L54,98L54,97L55,96L52,96L50,94L52,92L55,92L50,92L49,91ZM32,83L33,84L33,85L32,86L32,88L31,89L30,89L29,88L29,87L30,86L30,84L31,83ZM47,84L48,83L50,83L51,82L57,82L59,84L59,86L58,87L56,87L55,86L51,86L50,87L49,87L47,85ZM47,79L50,76L52,76L53,75L54,75L55,76L58,76L59,77L59,80L56,82L53,82L51,80L50,80L49,81ZM46,76L47,75L49,77L48,78L47,78L46,77ZM54,74L55,73L57,73L58,74L58,75L57,76L55,76L54,75ZM47,74L48,73L49,73L50,74L50,75L49,76L48,76L47,75ZM34,71L35,72L35,75L34,76L34,79L32,82L31,81L31,77L32,76L31,75L31,74ZM47,69L48,68L51,68L52,67L54,67L55,68L58,68L59,69L59,71L60,72L58,74L57,73L55,73L54,74L53,73L48,73L47,72L47,71L48,70ZM38,61L39,62L39,64L37,67L37,69L35,71L34,71L33,70L35,67L35,65L36,64L36,62L37,61ZM48,63L51,60L52,60L53,61L56,60L57,61L60,61L61,62L61,65L60,66L51,66L50,65L49,65L48,64ZM76,55L77,54L83,54L84,55L84,56L81,58L78,58L76,56ZM87,31L88,30L89,30L90,31L90,32L89,33ZM95,28L96,29L96,32L95,33L95,34L94,35L93,35L91,37L89,37L87,35L88,34L90,34L91,33L92,33L93,30ZM84,26L86,23L88,23L89,22L91,22L94,25L93,26L92,26L91,25L88,25L86,27L85,27ZM56,20L57,19L58,20L57,21ZM69,22L71,20L72,20L73,19L76,19L77,18L94,18L95,19L98,19L99,20L102,20L109,24L108,25L106,25L105,24L103,24L102,23L100,23L99,22L95,22L94,21L77,21L76,22L73,22L72,23L70,23ZM64,16L64,15L65,14L66,14L67,15L65,17ZM65,13L67,10L68,10L69,11L69,13L68,14L66,14ZM72,10L73,9L74,9L75,10L75,11L74,12L73,12L72,11Z"
	},
	brakes: {
		w: 137,
		h: 112,
		paper: "M17,47L17,56L18,57L18,62L19,63L19,66L20,67L20,69L21,70L22,73L24,75L24,76L27,79L27,80L30,83L31,83L34,86L35,86L37,88L38,88L43,91L45,91L46,92L50,92L51,93L53,93L55,96L55,99L56,100L56,101L58,103L59,103L60,104L62,104L63,103L67,103L67,93L70,91L73,91L74,90L75,90L76,89L81,87L83,85L84,85L90,79L90,78L96,71L98,71L101,69L105,69L106,68L112,68L113,67L115,67L117,65L119,65L119,63L120,62L124,62L125,61L125,44L124,43L124,41L122,41L121,40L119,40L118,39L117,39L114,36L114,31L112,29L111,29L110,28L107,28L106,27L99,27L98,26L90,26L83,19L82,19L81,18L80,18L78,16L77,16L76,15L74,15L71,13L67,13L66,12L62,12L61,11L57,11L56,12L49,12L47,9L44,9L43,8L43,5L38,5L35,7L35,9L34,10L34,18L26,26L26,27L23,30L23,31L20,36L20,38L19,39L19,41L18,42L18,46Z",
		ink: "M18,48L18,55L19,56L19,61L20,62L20,65L21,66L21,68L22,69L23,72L25,74L25,75L28,78L28,79L31,82L32,82L35,85L36,85L38,87L39,87L44,90L46,90L47,91L51,91L52,92L54,92L56,95L56,98L57,99L57,100L59,102L60,102L61,103L62,102L66,102L66,94L65,93L67,91L68,91L69,90L72,90L73,89L74,89L75,88L80,86L82,84L83,84L89,78L89,77L95,70L97,70L100,68L104,68L105,67L111,67L112,66L114,66L116,64L118,64L118,46L120,44L121,44L123,46L123,49L122,50L122,58L121,59L123,61L124,60L124,45L123,44L123,42L121,42L120,41L118,41L117,40L116,40L113,37L113,32L111,30L110,30L109,29L106,29L105,28L98,28L97,27L89,27L82,20L81,20L80,19L79,19L77,17L76,17L75,16L73,16L70,14L66,14L65,13L61,13L60,12L58,12L57,13L48,13L46,10L45,11L44,11L42,9L42,6L39,6L36,8L36,10L35,11L35,19L27,27L27,28L24,31L24,32L21,37L21,39L20,40L20,42L19,43L19,47ZM56,93L57,92L60,92L61,93L59,95L58,95ZM61,92L62,91L63,91L64,92L64,93L63,94L62,94L61,93ZM84,75L84,76L81,79L80,79L77,82L76,82L74,84L72,84L69,86L66,86L64,84L64,83L66,80L69,80L70,79L71,79L75,75L80,75L81,74L83,74ZM69,75L70,74L71,75L71,76L70,77L69,76ZM54,72L56,72L57,73L58,72L59,72L60,73L60,75L61,76L61,85L62,86L62,88L59,90L57,90L55,88L55,87L54,86L54,83L53,82L53,80L52,79L52,74ZM62,66L63,66L65,69L65,74L65,72L66,71L69,74L69,76L67,78L66,78L61,74L61,67ZM57,67L58,66L59,66L60,67L60,68L59,69L58,69L57,68ZM53,66L54,65L55,65L57,67L57,68L56,69L54,69L53,68ZM51,63L53,65L53,68L51,70L50,70L49,69L49,65ZM46,60L47,60L49,63L49,76L48,77L46,77L45,76L45,61ZM82,46L83,46L84,47L84,51L85,52L85,58L84,59L84,61L83,62L82,62L80,59L79,60L78,60L77,59L76,56L75,57L74,57L73,56L73,52L74,51L75,51L77,54L77,49L78,48L79,48L81,51L80,48ZM55,43L61,43L63,45L64,45L66,47L66,48L67,49L67,55L66,56L66,57L63,60L62,60L61,61L57,61L56,60L54,60L50,56L50,55L49,54L49,50L50,49L50,48ZM48,38L49,39L49,42L46,45L45,44L45,40L47,38ZM51,36L53,38L53,39L52,40L50,40L49,39L49,38ZM69,30L70,29L71,29L73,32L71,34L70,34L69,33ZM35,26L36,26L39,29L39,30L40,31L40,33L41,34L41,62L41,43L43,41L44,41L45,42L45,73L44,74L43,74L42,73L42,70L41,69L41,65L41,69L40,70L39,70L36,67L36,66L34,64L34,62L33,61L33,42L34,41L34,38L35,37L36,37L37,38L37,44L37,33L37,34L34,36L34,38L33,39L33,48L31,50L31,60L33,62L33,64L34,65L34,67L36,69L36,70L38,72L38,73L42,77L43,77L44,78L49,80L52,83L52,85L51,86L47,86L46,85L41,83L39,81L38,81L29,72L29,71L27,69L27,68L25,65L25,63L24,62L24,59L23,58L23,49L25,47L25,41L26,40L26,38L27,37L28,34L30,32L30,31ZM53,26L54,25L55,25L57,27L57,30L57,27L59,25L61,27L61,29L61,28L62,27L63,27L65,29L65,30L65,29L66,28L67,28L69,30L69,35L68,36L69,36L70,35L73,35L74,34L75,34L76,35L77,34L79,34L82,36L84,36L85,37L87,37L88,38L89,38L91,40L96,42L98,44L99,44L102,46L104,46L105,47L107,47L108,48L114,48L115,47L118,50L116,52L116,53L115,54L115,57L116,57L117,58L117,60L116,61L116,62L115,63L113,61L113,59L110,59L109,60L108,60L107,59L106,60L104,60L103,61L101,61L100,62L99,62L97,64L96,64L95,65L94,65L93,66L88,68L86,70L85,70L80,73L75,73L74,72L70,72L69,71L68,71L64,67L64,65L66,63L67,63L72,60L75,61L79,65L83,65L84,64L86,64L87,63L88,63L88,62L89,61L89,49L88,48L88,47L90,45L91,45L92,46L92,53L92,49L94,47L95,47L92,44L90,44L89,43L87,43L86,42L83,42L82,41L81,41L79,43L79,44L74,49L73,49L71,47L71,46L67,42L67,41L66,40L65,40L64,39L62,39L61,38L58,38L57,39L54,39L53,38L53,37L52,36L52,34L53,33ZM71,65L70,66L70,67L71,68L72,68L73,67L73,66L72,65ZM101,54L100,54L98,56ZM74,39L72,39L71,40L71,41L72,42L73,42L74,41ZM40,25L43,25L44,24L46,24L47,25L48,28L50,30L50,27L51,26L53,28L53,33L52,34L51,34L50,33L49,36L47,38L44,38L42,36L42,35L39,30L39,28L38,27ZM49,20L51,18L52,18L53,19L55,17L62,17L63,18L67,18L68,19L70,19L71,20L76,22L78,24L79,24L83,28L89,28L90,29L96,29L97,30L106,30L107,31L108,31L111,34L111,35L110,36L107,36L106,35L102,35L99,38L94,40L92,38L92,36L93,35L86,35L85,34L82,34L80,32L78,32L75,29L74,29L69,26L67,26L66,25L63,25L62,24L52,24L51,25L49,23ZM40,20L40,19L42,17L44,17L46,19L44,21L41,21ZM38,15L38,13L39,12L44,12L45,13L43,15L42,15L41,16L39,16Z"
	},
	steering: {
		w: 145,
		h: 130,
		paper: "M67,0L67,2L66,3L61,3L60,4L57,4L56,5L54,5L51,7L49,7L48,8L47,8L45,10L42,11L40,13L39,13L36,16L35,16L25,27L25,28L23,30L23,31L19,38L19,40L17,43L17,46L16,47L16,49L15,50L15,55L14,56L14,72L15,73L15,78L16,79L16,82L17,83L17,85L18,86L18,88L20,91L20,93L22,95L22,96L23,97L23,98L25,100L25,101L29,105L29,106L35,112L36,112L40,116L41,116L43,118L44,118L49,121L51,121L54,123L56,123L57,124L61,124L64,126L72,126L73,127L73,129L81,129L81,127L82,126L88,126L89,125L92,125L93,124L96,124L99,122L101,122L102,121L103,121L104,120L105,120L106,119L111,117L113,115L114,115L118,111L119,111L123,107L123,106L127,102L127,101L131,96L131,95L134,90L134,88L136,85L136,82L137,81L137,78L138,77L138,72L139,71L139,58L138,57L138,50L137,49L137,47L136,46L136,43L135,42L135,40L134,39L134,38L133,37L133,36L132,35L130,30L128,28L128,27L121,20L121,19L118,16L117,16L114,13L113,13L108,9L107,9L100,5L98,5L97,4L94,4L93,3L89,3L88,2L88,0Z",
		ink: "M80,2L78,2L77,3L68,3L67,4L62,4L61,5L58,5L57,6L55,6L52,8L50,8L49,9L48,9L46,11L43,12L41,14L40,14L37,17L36,17L31,22L31,23L26,28L26,29L24,31L24,32L20,39L20,41L18,44L18,47L17,48L17,50L16,51L16,56L15,57L15,71L16,72L16,77L17,78L17,81L18,82L18,84L19,85L19,87L21,90L21,92L23,94L23,95L24,96L24,97L26,99L26,100L30,104L30,105L36,111L37,111L41,115L42,115L44,117L45,117L50,120L52,120L53,121L54,121L55,122L57,122L58,123L62,123L65,125L73,125L74,126L80,126L81,125L87,125L88,124L91,124L92,123L95,123L98,121L100,121L101,120L102,120L103,119L104,119L105,118L110,116L112,114L113,114L117,110L118,110L122,106L122,105L126,101L126,100L130,95L130,94L133,89L133,87L135,84L135,81L136,80L136,77L137,76L137,71L138,70L138,59L137,58L137,51L136,50L136,48L135,47L135,44L134,43L134,41L133,40L133,39L132,38L132,37L131,36L129,31L127,29L127,28L120,21L120,20L117,17L116,17L113,14L112,14L107,10L106,10L99,6L97,6L96,5L93,5L92,4L88,4L87,3L81,3ZM75,6L79,6L80,7L84,7L85,8L89,8L90,9L92,9L93,10L95,10L96,11L98,11L99,12L100,12L101,13L106,15L108,17L109,17L113,21L114,21L119,26L119,27L123,31L123,32L125,34L125,35L126,36L126,37L130,44L130,46L131,47L131,49L132,50L132,54L133,55L133,71L132,72L132,77L131,78L131,81L130,82L130,84L129,85L129,86L128,87L128,88L127,89L125,94L123,96L123,97L118,102L118,103L115,106L114,106L109,111L108,111L106,113L105,113L98,117L96,117L95,118L93,118L92,119L89,119L88,120L83,120L82,121L70,121L69,120L64,120L63,119L60,119L59,118L57,118L54,116L52,116L50,114L47,113L45,111L44,111L42,109L41,109L32,100L32,99L29,96L28,93L26,91L26,90L24,87L24,85L22,82L22,80L21,79L21,76L20,75L20,70L19,69L19,58L20,57L20,52L21,51L21,49L22,48L22,46L23,45L23,43L24,42L24,41L25,40L27,35L29,33L29,32L31,30L31,29L42,18L43,18L48,14L49,14L54,11L56,11L59,9L61,9L62,8L65,8L66,7L74,7ZM71,17L70,18L66,18L65,19L62,19L61,20L59,20L58,21L57,21L56,22L51,24L49,26L48,26L39,35L39,36L37,38L37,39L35,41L35,42L34,43L34,45L32,48L32,50L31,51L31,53L30,54L30,59L29,60L29,67L30,68L30,74L31,75L31,79L32,80L32,82L33,83L35,88L37,90L38,93L48,103L49,103L51,105L52,105L53,106L54,106L61,110L64,110L65,111L68,111L69,112L85,112L86,111L89,111L90,110L92,110L93,109L95,109L96,108L97,108L98,107L103,105L106,102L107,102L115,94L115,93L117,91L117,90L118,89L118,88L122,81L122,79L123,78L123,75L124,74L124,55L123,54L123,52L122,51L122,48L121,47L121,46L120,45L120,44L119,43L117,38L114,35L114,34L107,27L106,27L101,23L100,23L97,21L95,21L92,19L90,19L89,18L86,18L85,17ZM77,104L79,106L79,107L78,108L78,110L77,111L76,111L74,109L74,107ZM73,94L74,93L75,93L77,95L75,97L73,95ZM73,88L74,87L75,87L76,88L76,89L75,90L74,90L73,89ZM118,69L119,70L119,74L118,75L118,79L117,80L117,81L116,82L114,87L111,90L111,91L102,100L101,100L99,102L98,102L95,104L93,104L90,106L88,106L87,107L85,107L82,104L83,103L83,96L84,95L84,89L85,88L85,81L86,80L86,79L88,77L89,77L93,73L94,73L95,72L97,72L98,71L106,71L107,70L114,70L115,69ZM38,69L40,69L41,70L50,70L51,71L61,71L62,72L63,72L69,78L69,80L70,81L70,89L71,90L71,101L72,102L72,104L70,107L67,107L66,106L64,106L63,105L61,105L60,104L55,102L53,100L52,100L41,89L41,88L40,87L40,86L36,79L36,77L35,76L35,72ZM33,67L33,66L34,65L35,65L36,66L34,68ZM41,62L42,61L43,61L44,62L43,63L42,63ZM94,59L96,61L96,62L95,63L93,63L92,62L92,61ZM49,61L52,59L58,59L59,60L59,62L58,63L55,63L54,64L53,63L50,63L49,62ZM77,51L79,51L80,52L83,52L85,54L86,54L90,58L90,59L91,60L91,65L90,66L90,69L89,70L89,72L86,75L86,76L83,78L74,78L73,77L71,77L66,72L66,71L65,70L65,68L64,67L64,63L65,62L65,60L67,58L67,57L70,54L71,54L74,52L76,52ZM77,74L76,75L77,76L78,76L79,75L78,74ZM88,63L87,63L86,64L86,66L87,66L88,65ZM69,63L68,63L67,64L67,65L69,65ZM74,59L73,60L73,62L72,63L72,67L74,69L75,69L76,70L79,70L80,69L81,69L83,67L83,62L80,59ZM77,59L78,60L79,60L82,63L82,66L80,68L79,68L78,69L75,68L73,65L73,63L74,62L74,61ZM79,54L77,54L77,56L78,56L79,55ZM80,45L81,45L82,46L82,49L81,50L80,50L79,49L79,46ZM84,22L87,22L88,23L90,23L91,24L93,24L94,25L97,26L99,28L100,28L102,30L103,30L112,39L112,40L114,42L114,43L117,48L117,50L118,51L118,53L119,54L119,57L117,59L114,59L113,58L97,58L96,57L94,57L90,53L89,53L87,51L87,50L86,49L86,47L85,46L85,38L84,37L84,33L83,32L83,26L82,25L82,24ZM70,22L72,24L72,29L71,30L71,47L70,48L70,49L64,55L63,55L62,56L56,56L55,57L44,57L43,58L37,58L35,56L35,53L36,52L36,50L37,49L37,47L38,46L38,45L40,43L40,42L42,40L42,39L52,29L53,29L55,27L56,27L61,24L63,24L64,23L66,23L67,22Z"
	},
	dashboard: {
		w: 194,
		h: 102,
		paper: "M13,11L13,94L14,95L14,96L17,99L17,101L187,101L187,99L188,98L189,98L191,95L193,95L193,8L191,8L190,7L189,7L186,5L184,5L183,4L157,4L156,5L150,5L149,4L21,4L20,5L17,6L14,9L14,10Z",
		ink: "M14,12L14,93L15,94L15,95L18,98L20,98L21,99L175,99L176,100L177,99L183,99L184,98L186,98L187,97L188,97L191,92L191,89L192,88L192,13L191,12L190,9L185,6L183,6L182,5L164,5L163,6L160,6L159,5L158,5L157,6L149,6L148,5L22,5L21,6L18,7L15,10L15,11ZM133,88L134,87L135,87L137,89L137,91L137,89L138,88L139,88L140,89L142,87L145,87L147,89L149,87L151,89L151,94L150,95L148,95L147,94L146,95L141,95L140,94L139,95L137,95L136,94L136,93L136,94L135,95L134,95L133,94ZM69,87L70,87L71,88L71,94L70,95L69,95L68,94L68,88ZM66,87L68,89L68,92L67,93L67,94L66,95L65,95L64,94L64,89ZM53,88L54,87L56,87L57,88L57,89L57,88L58,87L59,87L61,89L61,90L61,89L62,88L63,88L64,89L64,94L63,95L61,95L60,94L60,93L60,94L59,95L58,95L57,94L57,93L57,94L56,95L55,95L53,93L54,92L53,91ZM130,86L132,86L133,87L133,94L132,95L130,95L129,94L129,87ZM73,86L74,86L75,87L75,94L74,95L73,95L72,94L72,89L71,88ZM51,86L52,86L53,87L53,94L52,95L51,95L50,94L50,87ZM161,83L162,84L162,94L161,95L159,95L158,94L158,91L158,94L157,95L156,95L155,94L155,91L154,94L153,95L152,95L151,94L151,88L152,87L153,87L154,88L154,89L154,88L156,85L157,85L158,86L158,88L158,85L160,83ZM84,80L86,82L86,94L85,95L76,95L75,94L75,86L76,85L81,83L82,84L82,89L82,82ZM87,78L88,78L90,80L90,86L90,82L91,81L93,83L93,94L92,95L91,95L90,94L90,93L89,92L89,89L89,94L88,95L87,95L86,94L86,79ZM116,76L117,76L118,77L118,78L119,78L122,81L122,85L122,83L123,82L124,82L125,83L125,89L125,86L127,84L128,84L129,85L129,94L128,95L123,95L122,94L121,95L116,95L115,94L115,77ZM112,71L113,71L115,73L115,94L114,95L112,95L111,94L111,72ZM58,48L59,48L60,49L60,50L63,53L63,57L62,58L59,57L56,52L56,50ZM63,46L65,46L68,49L68,50L69,51L69,53L67,56L66,56L65,55L65,54L64,53L64,51L61,48ZM72,45L73,44L74,45L74,46L73,47L72,46ZM68,40L69,39L70,40L69,41ZM58,29L65,29L66,30L68,30L69,31L71,31L72,32L75,33L83,41L83,42L85,45L85,47L86,48L86,50L87,51L87,55L86,56L86,58L84,60L83,60L78,55L78,54L75,49L75,47L74,46L74,45L73,44L72,45L71,44L71,43L72,42L69,39L68,39L67,38L64,38L63,37L60,37L59,38L57,38L56,39L55,39L51,43L51,44L52,44L53,45L53,46L52,47L50,47L49,46L49,51L48,52L49,53L49,58L50,59L50,60L52,62L53,62L55,64L56,64L57,65L59,65L60,66L71,66L72,67L75,68L77,70L77,72L76,73L75,73L73,75L71,75L70,76L68,76L67,77L59,77L58,76L56,76L55,75L53,75L52,74L51,74L49,72L48,72L45,69L45,68L43,66L43,65L41,62L41,60L39,57L39,46L41,44L43,39L49,33L50,33L55,30L57,30ZM135,21L150,21L151,22L153,22L154,23L155,23L156,24L161,26L169,34L169,35L171,37L171,38L173,41L173,43L174,44L174,47L175,48L175,57L174,58L174,61L173,62L173,64L172,65L171,68L169,70L169,71L161,79L160,79L158,81L157,81L156,82L154,82L153,83L151,83L150,84L136,84L135,83L133,83L132,82L127,80L125,78L124,78L117,71L117,70L115,68L115,67L114,66L114,64L113,63L113,61L112,60L112,55L111,54L111,51L112,50L112,45L113,44L113,42L114,41L114,39L115,38L115,37L117,35L117,34L125,26L126,26L128,24L129,24L130,23L132,23ZM137,29L136,30L134,30L133,31L130,32L128,34L127,34L124,37L124,38L122,40L122,41L120,44L120,46L119,47L119,59L121,62L121,64L122,65L122,66L129,73L130,73L132,75L134,75L135,76L137,76L138,77L150,77L151,76L156,74L158,72L159,72L162,69L162,68L164,66L164,65L166,62L166,60L167,59L167,47L166,46L166,44L165,43L163,38L159,34L158,34L156,32L155,32L150,29L144,29L143,28L142,29ZM138,29L148,29L149,30L151,30L152,31L155,32L163,40L163,41L166,46L166,48L167,49L167,56L166,57L166,60L165,61L165,63L164,64L164,65L162,67L162,68L159,71L158,71L153,75L151,75L150,76L147,76L146,77L143,77L142,76L138,76L137,75L134,75L133,74L132,74L130,72L129,72L124,67L124,66L122,64L122,63L120,60L120,54L119,53L119,50L120,49L120,45L121,44L122,41L124,39L124,38L128,34L129,34L131,32L132,32L135,30L137,30ZM152,69L151,69L150,70L147,70L151,70ZM128,64L129,64L130,63L134,63L128,63ZM126,47L129,49L131,49L133,47L138,45L136,45L131,48L129,48L126,45ZM140,35L139,35L138,36L136,36L135,37L133,37L132,38L131,38L128,41L129,40L130,40L132,38L133,38L136,36L138,36L139,35ZM148,34L146,34L146,35L145,36L145,39L144,40L144,43L143,44L143,46L140,49L140,50L139,51L139,56L141,58L147,58L148,57L148,54L149,53L149,52L146,47L147,46L150,46L151,47L152,47L155,50L152,47L149,46L147,44L147,39L149,37L151,37L153,39L154,39L159,44L159,45L160,46L160,48L158,50L159,50L160,49L160,46L159,45L159,44L157,42L157,41L154,38L151,37ZM143,50L144,50L146,52L146,54L144,56L143,56L141,54L141,52ZM55,21L70,21L71,22L73,22L74,23L76,23L77,24L78,24L80,26L81,26L89,34L89,35L91,37L91,38L93,41L93,43L94,44L94,48L95,49L95,55L94,56L94,60L93,61L93,63L92,64L92,65L91,66L90,66L89,65L88,65L86,63L86,59L87,58L87,48L86,47L86,45L85,44L85,42L84,41L84,40L82,38L82,37L79,34L78,34L76,32L75,32L72,30L70,30L69,29L63,29L62,28L61,29L57,29L56,30L54,30L53,31L48,33L44,37L44,38L40,43L40,45L39,46L39,59L40,60L40,62L41,63L41,64L42,65L44,70L46,72L47,72L49,74L50,74L51,75L53,75L54,76L57,76L58,77L70,77L71,76L74,75L79,71L80,71L82,73L83,73L84,74L84,76L82,78L81,78L79,80L78,80L75,82L73,82L72,83L70,83L69,84L57,84L56,83L53,83L52,82L51,82L50,81L45,79L37,71L37,70L35,68L35,67L33,64L33,62L32,61L32,58L31,57L31,47L32,46L32,43L34,40L34,38L36,36L36,35L39,32L39,31L42,28L43,28L46,25L47,25L52,22L54,22ZM18,15L19,14L19,13L23,9L160,9L161,10L163,10L164,9L182,9L183,10L185,10L187,12L187,91L185,93L184,92L183,92L183,93L182,94L180,94L179,95L166,95L165,94L164,95L163,95L162,94L162,82L163,81L164,81L165,82L165,83L165,80L167,78L168,78L169,79L169,80L169,76L172,73L173,70L175,68L175,66L176,65L176,63L177,62L177,59L178,58L178,47L177,46L177,43L176,42L176,40L175,39L175,38L174,37L172,32L164,24L163,24L161,22L160,22L157,20L155,20L152,18L145,18L144,17L141,17L140,18L137,18L136,19L133,19L132,20L130,20L129,21L124,23L122,25L121,25L116,30L116,31L112,36L112,37L111,38L111,40L110,41L110,43L108,46L108,58L109,59L109,61L110,62L109,63L111,65L111,69L112,70L112,71L111,72L111,94L110,95L109,95L107,93L107,92L107,94L106,95L105,95L104,94L104,67L104,94L103,95L101,95L100,94L100,93L100,94L99,95L94,95L93,94L93,85L94,84L96,84L98,82L99,79L94,77L89,72L88,72L82,66L81,66L76,61L75,61L73,59L73,57L74,56L75,56L77,58L78,58L85,65L86,65L88,67L90,67L91,68L91,69L93,69L97,73L98,73L94,69L94,68L97,65L96,64L96,62L97,61L97,57L98,56L98,49L97,48L97,43L96,42L96,40L95,39L93,34L91,32L91,31L84,24L83,24L81,22L80,22L75,19L72,19L71,18L67,18L66,17L60,17L59,18L56,18L55,19L52,19L51,20L49,20L48,21L45,22L43,24L42,24L34,32L34,33L32,35L32,36L31,37L31,39L30,40L30,42L29,43L29,46L28,47L28,74L28,66L29,65L30,65L32,68L32,71L33,71L35,73L36,76L37,76L39,78L39,79L40,79L43,82L44,82L46,84L48,84L50,86L50,93L48,95L47,95L46,94L46,90L46,93L44,95L40,95L39,94L38,94L37,95L21,95L18,93ZM178,84L177,85L177,86L178,85ZM26,82L24,84L24,89L27,91L29,91L30,90L31,90L31,88L32,87L32,85L31,84L31,83L30,83L29,82ZM27,82L28,83L30,83L32,86L31,87L31,88L29,90L27,90L26,89L27,86L25,88L24,87L24,84ZM176,80L173,83L172,86L173,83L175,81L179,81L182,84L182,86L181,87L181,88L180,89L178,89L177,90L177,91L178,91L181,88L181,87L182,86L182,83L180,81L179,81L178,80ZM108,65L108,78L107,79L107,87L107,80L108,79ZM25,52L24,52L24,77L24,55L25,54ZM183,28L183,72L183,66L184,65L184,48L183,47L183,41L184,40L184,38L183,37L183,31L184,30L184,29ZM174,15L172,18L172,22L173,23L175,23L176,24L179,24L180,23L181,23L183,21L183,17L181,15L180,15L179,14L177,14L176,15ZM180,16L181,17L182,20L180,23L177,24L176,23L176,21L177,20L177,19ZM177,15L178,16L178,17L177,18L177,19L174,22L172,19L173,18L173,17L175,15ZM30,14L27,14L27,15L24,18L24,20L25,21L28,21L29,20L30,20L30,19L31,18L31,16L30,15ZM25,20L25,18L26,17L26,16L27,15L29,15L31,18L28,21L26,21Z"
	},
	battery: {
		w: 109,
		h: 62,
		paper: "M7,0L7,2L4,4L4,17L5,18L5,19L6,20L7,20L9,23L9,30L8,31L8,58L9,59L9,61L75,61L75,59L76,58L76,41L77,40L77,23L83,17L83,5L81,2L81,0Z",
		ink: "M5,5L5,16L6,17L6,18L7,19L8,19L10,22L10,31L9,32L9,33L10,34L9,35L9,57L11,59L73,59L75,57L75,40L76,39L76,22L82,16L82,6L80,3L8,3ZM32,47L33,47L35,49L35,51L33,54L32,54L31,53L31,48ZM28,47L29,47L31,50L31,51L29,54L28,54L27,53L27,48ZM20,47L21,47L23,50L23,51L21,54L20,54L19,53L19,48ZM16,47L17,47L18,48L18,53L17,54L16,54L14,51L14,50ZM68,46L69,46L70,47L70,53L69,54L68,54L67,53L67,47ZM64,46L65,46L67,48L67,52L65,54L64,54L63,53L63,47ZM60,46L61,46L63,48L63,49L62,50L62,53L61,54L60,54L59,53L59,47ZM56,46L57,46L59,48L59,51L57,54L56,54L55,53L55,47ZM52,46L53,46L54,47L54,49L55,50L54,51L54,53L53,54L52,54L51,53L51,47ZM48,46L49,46L50,47L50,49L51,50L50,51L50,53L49,54L48,54L47,53L47,47ZM44,46L45,46L47,48L47,50L46,51L46,53L45,54L44,54L43,53L43,47ZM40,46L41,46L42,47L42,50L43,51L41,54L40,54L39,53L39,47ZM36,46L37,46L39,48L39,50L38,51L38,53L37,54L36,54L35,53L35,47ZM25,46L27,48L27,53L26,54L24,54L23,53L23,48ZM71,18L71,43L68,45L16,45L14,43L14,20L16,17L43,17L44,16L45,16L46,17L70,17ZM23,30L23,32L24,33L33,33L35,31L35,30L34,29L24,29ZM55,25L54,26L54,28L53,29L50,29L49,30L49,32L50,33L52,33L54,35L54,37L55,38L57,38L58,35L60,33L62,33L62,30L59,29L58,28L58,26L57,25ZM9,10L11,8L23,8L24,7L28,7L29,8L32,8L33,7L37,7L38,8L41,8L42,7L72,7L73,8L76,8L78,10L78,12L76,14L74,14L73,15L71,15L70,14L46,14L45,15L41,15L40,14L37,14L36,15L34,15L33,14L32,14L31,15L12,15L9,12Z"
	},
	paint: {
		w: 112,
		h: 106,
		paper: "M6,4L6,5L5,6L5,9L6,10L8,10L9,11L9,15L8,16L0,16L0,33L2,33L4,35L4,44L5,45L5,49L6,50L6,53L7,54L7,56L8,57L8,59L9,60L9,62L10,63L10,65L11,66L11,77L10,78L10,91L11,92L11,95L12,96L12,97L14,99L15,99L18,101L24,101L25,102L43,102L44,101L79,101L80,100L85,100L86,99L89,99L91,97L92,97L94,95L94,90L95,89L95,68L96,67L96,65L98,63L98,62L100,59L100,57L101,56L101,54L103,51L103,49L104,48L104,45L105,44L105,16L100,13L100,5L99,5L98,4L96,4L95,5L81,5L80,4Z",
		ink: "M7,5L6,8L7,9L9,9L11,11L12,14L10,17L2,17L2,18L3,19L3,20L2,21L2,30L3,31L3,32L5,34L5,43L6,44L6,48L7,49L7,52L8,53L8,55L9,56L9,58L10,59L10,61L11,62L11,64L12,65L12,78L11,79L11,90L12,91L12,94L13,95L13,96L15,98L16,98L19,100L25,100L26,101L42,101L43,100L78,100L79,99L84,99L85,98L88,98L90,96L91,96L93,94L93,89L94,88L94,67L95,66L95,64L97,62L97,61L99,58L99,56L100,55L100,53L102,50L102,48L103,47L103,44L104,43L103,42L103,39L104,38L104,17L101,15L95,15L94,14L94,12L99,8L99,6L98,6L97,5L96,6L80,6L79,5ZM15,80L16,79L16,75L17,74L17,73L18,72L19,72L22,75L23,75L25,77L26,77L31,80L33,80L34,81L36,81L39,84L39,85L40,86L44,86L45,85L58,85L60,87L60,89L60,87L61,86L62,86L64,88L64,90L64,88L66,86L67,87L67,86L69,83L70,83L71,84L71,85L72,86L72,89L72,82L73,81L74,81L75,82L75,81L76,80L77,80L79,82L79,85L79,79L83,75L84,75L87,73L88,73L90,75L90,83L89,84L89,90L88,91L88,92L86,94L85,94L84,95L70,95L69,96L23,96L22,95L20,95L17,92L17,88L16,87L16,84L15,83ZM30,37L32,39L32,45L30,47L27,48L24,45L24,42L25,41L25,40L28,37ZM8,21L10,21L12,23L12,27L10,29L7,29L6,28L6,23ZM95,19L97,19L99,21L99,27L98,28L96,28L94,25L94,20ZM61,20L62,19L63,19L64,20L65,20L66,21L68,21L69,22L75,22L76,23L76,27L74,29L70,29L69,28L68,28L66,26L65,26L64,25L64,24L61,21ZM58,17L59,16L60,16L62,18L62,19L61,20L60,20L58,18ZM90,12L90,51L88,54L88,57L87,58L87,63L87,61L88,60L91,61L91,58L92,57L92,56L93,55L94,55L94,45L95,44L95,35L97,33L101,33L102,34L102,42L101,43L101,49L100,50L100,53L99,54L99,55L96,58L95,57L95,62L93,64L93,65L86,72L85,72L82,75L80,75L79,76L78,76L71,80L69,80L66,77L64,77L63,76L62,77L60,77L59,78L58,78L59,79L58,80L50,80L49,79L50,78L48,78L47,77L44,77L43,76L40,76L40,77L38,79L33,79L32,78L31,78L30,77L25,75L22,72L21,72L12,61L12,60L10,57L10,55L9,54L9,52L8,51L8,47L7,46L7,40L6,39L6,35L8,33L10,33L12,35L12,51L13,52L13,53L16,56L16,42L17,41L17,38L16,37L16,25L18,23L21,23L25,27L25,28L26,29L26,37L25,38L25,40L22,45L22,49L25,52L26,52L27,53L31,53L34,50L34,48L35,47L35,28L36,27L37,24L39,22L40,22L42,20L43,20L46,18L53,18L54,19L55,19L58,22L59,22L64,27L65,27L67,29L69,29L70,30L74,30L75,29L77,29L78,28L79,28L82,25L82,22L83,21L83,11L84,10L88,10ZM44,64L44,67L44,66L45,65Z"
	},
	claxon: {
		w: 132,
		h: 73,
		paper: "M126,18L125,17L125,15L124,14L124,13L120,8L119,8L118,7L110,7L109,8L108,8L105,11L105,12L104,13L104,14L102,16L102,17L97,22L96,22L89,26L87,26L86,27L84,27L83,28L80,28L79,29L76,29L75,30L39,30L38,29L36,29L35,28L34,28L27,24L17,24L16,25L14,25L13,26L10,27L8,29L8,30L6,33L6,45L7,46L7,51L6,52L0,52L0,57L35,57L35,55L36,54L40,54L41,55L41,57L43,60L43,62L46,65L48,65L49,66L51,66L52,67L71,67L72,66L74,66L75,65L76,65L81,60L82,57L85,54L91,54L92,55L93,55L97,59L97,60L99,63L99,65L102,70L102,72L123,72L123,70L124,69L124,67L125,66L125,62L126,61L126,57L127,56L127,22L126,21Z",
		ink: "M12,56L13,57L17,57L18,56L19,57L22,57L19,55L18,55L17,56L16,56L15,55ZM1,57L7,57L7,56L8,55L10,55L10,54L9,53L2,53L1,54ZM3,55L4,54L7,54L8,55L6,57L5,57ZM126,23L125,22L125,19L124,18L124,16L123,15L123,14L121,12L121,11L119,9L118,9L117,8L111,8L110,9L109,9L106,12L106,13L105,14L105,15L103,17L103,18L98,23L97,23L90,27L88,27L87,28L85,28L84,29L81,29L80,30L77,30L76,31L72,31L71,32L70,31L38,31L37,30L35,30L34,29L33,29L26,25L18,25L17,26L15,26L14,27L11,28L9,30L9,31L7,34L7,44L8,45L9,48L11,50L12,50L17,53L23,53L24,52L28,52L29,51L30,52L31,55L30,56L29,55L27,55L25,57L33,57L34,56L35,57L33,54L33,52L31,52L30,51L32,49L33,49L38,46L40,46L41,47L41,53L42,54L42,57L43,58L44,61L47,64L49,64L50,65L52,65L53,66L70,66L71,65L73,65L74,64L75,64L80,59L81,56L84,53L85,53L86,52L89,52L90,53L92,53L93,54L94,54L98,58L98,59L100,62L100,64L101,65L103,70L105,72L120,72L122,70L122,69L123,68L123,66L124,65L124,61L125,60L125,56L126,55ZM114,57L115,56L116,57L116,58L115,59L114,58ZM115,53L115,52L116,51L117,51L118,52L116,54ZM112,50L113,49L114,50L114,51L113,52L112,51ZM18,50L19,49L20,49L21,50L20,51L19,51ZM44,37L46,35L66,35L67,36L71,36L73,38L74,38L76,40L76,41L77,42L77,44L78,45L78,52L77,53L77,54L75,56L75,57L73,59L72,59L69,61L53,61L52,60L51,60L48,57L48,56L47,55L47,53L46,52L46,51L47,50L48,50L49,51L49,53L51,56L52,56L53,57L55,57L56,58L68,58L69,57L70,57L73,54L74,54L73,54L71,56L69,56L68,57L62,57L61,58L56,58L55,57L54,57L50,53L51,50L53,48L56,51L59,51L60,52L64,52L65,51L68,51L70,49L70,47L69,46L69,45L67,43L65,43L64,42L50,42L49,41L46,41L44,39ZM71,40L72,41L74,46L75,46L75,44L74,43L74,42L72,40ZM39,35L40,35L42,37L42,39L40,41L38,39L38,36ZM113,30L114,30L115,31L115,36L114,37L112,35L112,31ZM10,39L10,34L14,30L15,30L17,28L22,28L23,29L25,29L26,30L28,30L31,32L31,34L30,35L27,35L26,34L23,34L22,35L20,35L19,36L16,37L13,40L11,40ZM115,13L118,16L118,17L120,20L120,23L121,24L121,41L122,42L122,46L121,47L121,55L120,56L120,58L119,59L118,59L117,58L117,54L118,53L118,43L117,42L117,41L118,40L118,39L117,39L115,37L115,30L112,27L112,25L115,22L117,22L116,21L115,21L114,22L113,21L112,21L111,22L111,23L109,26L109,28L108,29L108,36L107,37L107,49L108,50L108,56L109,57L109,60L110,61L111,64L112,64L113,65L115,65L116,64L116,62L117,61L118,61L119,62L119,64L118,65L118,66L116,68L114,68L113,69L109,69L107,67L106,64L104,62L104,61L103,60L103,58L99,53L98,53L95,51L93,51L90,49L87,49L84,47L81,47L80,46L81,45L81,40L81,42L80,43L79,43L78,42L77,39L75,37L78,35L80,35L81,34L84,34L85,33L87,33L88,32L90,32L91,31L93,31L94,30L95,30L96,29L101,27L107,21L107,20L108,19L108,18L110,16L110,15L112,13Z"
	},
	windshield: {
		w: 247,
		h: 115,
		paper: "M1,21L1,24L2,25L2,28L3,29L3,32L4,33L4,34L5,34L8,36L10,36L11,37L13,37L16,39L18,39L19,38L20,38L21,37L22,37L23,36L28,34L29,35L31,35L32,36L34,36L35,37L37,37L40,39L42,39L43,40L45,40L47,42L47,71L48,72L48,102L240,102L240,79L239,78L239,31L238,30L238,6L51,6L50,7L48,12L46,14L45,14L44,15L41,15L40,16L37,16L36,17L34,17L24,7L22,7L21,8L16,8L15,9L10,9L9,10L7,10L6,11L6,12L5,13L5,14Z",
		ink: "M48,75L48,76L50,78L50,96L51,97L51,100L126,100L127,101L226,101L227,102L233,102L235,100L235,78L236,77L236,75L235,74L234,75L230,75L229,74L228,74L227,75L227,79L229,82L229,83L228,84L217,84L216,85L208,85L207,84L206,84L205,85L201,85L200,84L158,84L157,83L143,83L142,84L139,84L138,83L137,84L120,84L119,83L112,83L111,82L108,82L107,83L81,83L79,81L77,83L72,83L71,82L66,82L65,83L64,83L62,81L61,82L58,82L56,80L56,77L57,76L57,74L49,74ZM54,86L55,85L105,85L106,86L107,85L109,85L110,86L112,86L113,85L115,85L116,86L186,86L187,87L229,87L232,90L232,96L230,99L229,98L229,96L229,98L227,100L225,100L224,99L224,92L224,99L222,101L220,99L220,92L220,98L218,100L217,100L216,99L216,94L216,98L214,100L213,100L212,99L211,99L210,100L208,100L207,99L206,100L204,100L203,99L203,92L203,99L202,100L200,100L199,99L199,92L199,98L197,100L196,100L195,99L195,95L195,96L194,97L194,99L193,100L192,100L190,98L190,92L190,99L189,100L188,100L186,98L186,92L186,98L184,100L182,98L182,96L182,98L180,100L179,100L178,99L178,95L178,97L177,98L177,99L176,100L175,100L174,99L174,94L173,93L173,92L173,93L174,94L174,96L173,97L173,98L172,99L170,99L169,98L169,97L169,98L168,99L167,99L165,97L165,91L165,97L163,99L162,99L161,98L161,93L161,97L159,99L158,99L157,98L157,94L157,97L154,100L150,100L148,98L148,93L148,98L146,100L144,98L143,99L141,99L140,98L140,94L140,97L138,99L136,99L135,98L135,95L135,98L134,99L132,99L131,100L130,100L127,98L127,91L127,98L126,99L124,99L123,98L123,92L123,97L121,99L118,99L117,100L116,99L115,99L114,98L114,97L114,98L113,99L111,99L110,98L110,94L110,97L108,99L107,99L106,98L106,91L106,92L105,93L106,94L106,97L104,99L103,99L101,97L101,96L101,98L100,99L99,99L97,97L97,98L96,99L94,99L93,98L93,92L93,97L91,99L90,99L89,98L89,97L87,99L86,99L85,98L85,92L85,93L84,94L84,98L83,99L82,99L80,97L80,98L79,99L78,99L76,97L76,90L76,97L74,99L72,97L72,91L72,98L71,99L69,99L68,98L68,94L68,96L67,97L67,98L66,99L65,99L63,96L64,95L63,94L63,93L63,97L61,99L59,97L59,92L59,97L58,98L56,98L55,97L55,92L54,91ZM77,68L73,72L74,72L77,69ZM121,25L120,25L116,29L116,30ZM235,24L232,24L231,25L228,25L229,28L230,28L231,29L231,31L230,32L230,39L231,40L230,41L230,45L229,46L229,49L230,50L230,54L231,55L230,56L230,59L231,60L231,62L230,63L230,67L229,68L229,69L230,70L233,70L233,69L234,68L234,30L236,28L236,25ZM189,22L188,23L187,23L184,26L184,27L177,34ZM36,17L35,18L35,20L36,21L36,22L41,27L41,28L40,29L41,29L42,28L45,31L45,30L43,28L43,26L42,27L35,20L35,19L38,16L37,17ZM45,14L45,15L46,16L46,15ZM11,15L7,19L7,20L6,21L6,30L7,31L7,32L9,34L9,35L10,35L12,37L14,37L15,38L20,38L27,34L29,34L30,33L35,33L36,34L41,36L46,40L47,40L49,42L49,43L50,44L50,69L51,70L54,70L55,69L55,67L54,67L53,66L53,65L54,64L55,64L55,59L53,57L53,48L54,47L55,47L55,38L56,37L56,34L55,33L56,32L55,33L54,33L53,32L53,29L56,27L56,26L58,24L58,22L57,21L49,21L48,22L48,24L50,26L50,36L53,36L54,37L54,38L53,39L47,39L46,38L45,38L44,37L43,37L42,36L37,34L33,30L32,30L30,28L30,27L31,26L31,24L30,23L30,21L29,20L29,19L24,14L22,14L21,13L15,13L14,14ZM15,14L22,14L27,18L27,19L29,21L29,23L30,24L30,27L29,28L29,30L28,31L28,32L25,35L24,35L22,37L14,37L9,33L9,32L7,30L7,28L6,27L6,24L7,23L7,21L8,20L8,19L11,16L12,16ZM52,10L52,17L55,17L56,16L56,15L59,12L62,12L63,13L140,13L141,14L207,14L208,15L212,15L213,14L224,14L225,15L228,15L229,16L230,19L234,19L234,13L232,11L231,11L230,10L171,10L170,9L171,10L171,11L170,12L100,12L99,11L97,11L95,9L85,9L84,8L54,8ZM192,11L193,10L230,10L231,11L231,12L230,13L193,13L192,12ZM185,11L186,10L187,10L188,11L188,12L187,13L186,13L185,12ZM54,9L55,8L80,8L81,9L81,10L80,11L56,11Z"
	},
	tires: {
		w: 160,
		h: 168,
		paper: "M58,9L57,10L56,10L55,11L50,13L48,15L47,15L44,18L43,18L36,25L36,26L34,28L34,29L31,34L31,36L29,39L29,41L28,42L28,45L27,46L27,52L26,53L26,77L27,78L27,83L28,84L28,88L29,89L29,92L30,93L30,95L31,96L31,98L32,99L32,101L33,102L33,104L35,107L35,109L36,110L38,115L40,117L41,120L48,129L48,133L47,134L46,134L46,136L47,136L51,140L51,143L78,143L78,142L77,142L76,141L74,141L73,140L71,140L69,138L67,138L65,136L65,125L67,123L71,123L72,124L72,125L78,125L79,126L86,126L87,127L87,131L89,131L89,123L91,121L98,121L98,111L99,110L103,110L103,98L104,97L104,95L102,92L102,87L101,86L101,78L102,77L102,73L99,73L98,72L98,68L99,67L99,60L93,60L92,59L92,53L89,53L88,52L88,48L86,48L85,47L85,45L82,45L81,44L81,38L82,37L90,37L91,38L92,41L94,41L95,42L95,47L97,47L98,48L98,54L101,54L102,55L102,56L104,56L105,57L105,64L108,64L109,65L109,67L111,69L111,70L112,71L112,77L111,78L111,85L114,85L115,86L115,91L114,92L114,99L113,100L113,109L112,110L112,118L111,119L111,122L109,124L107,124L107,128L106,129L106,130L104,132L103,132L102,133L98,133L98,135L97,136L94,136L94,139L92,141L89,141L89,143L114,143L115,142L118,141L123,137L124,137L127,134L127,133L132,128L134,123L137,120L137,119L140,114L140,111L142,108L142,105L143,104L143,101L144,100L144,75L143,74L143,68L142,67L142,64L141,63L141,61L139,58L139,55L137,52L137,50L136,49L136,48L135,47L133,42L132,42L130,40L130,38L129,37L129,35L127,33L127,32L124,29L124,28L122,26L121,26L118,23L118,22L113,17L112,17L111,16L109,16L108,15L108,14L103,10L99,10L96,7L94,7L93,6L87,6L86,5L76,5L75,6L69,6L68,7L64,7L63,8L61,8L60,9ZM57,23L61,23L62,24L65,24L66,25L72,25L73,26L73,30L79,30L80,31L80,39L79,40L75,40L74,39L74,38L72,38L71,39L67,39L66,38L66,34L64,34L64,37L63,38L59,38L58,37L56,37L56,42L55,43L51,43L50,42L50,41L48,41L48,50L47,51L43,51L43,59L42,60L42,69L41,70L41,80L43,80L44,81L44,92L46,92L47,93L47,101L49,101L50,102L50,107L52,107L53,108L53,116L55,116L56,115L60,115L64,119L64,128L62,131L58,131L57,130L56,130L52,126L52,125L50,123L49,120L48,120L47,119L47,118L43,113L43,112L42,111L42,110L41,109L41,108L37,101L37,99L36,98L36,96L34,93L34,90L33,89L33,85L32,84L32,82L31,81L31,77L30,76L30,71L29,70L29,64L30,63L30,59L31,58L33,58L33,54L34,53L34,44L36,42L39,42L39,35L40,34L44,34L44,29L45,28L48,28L49,27L56,27L56,24Z",
		ink: "M47,135L48,135L55,142L55,143L56,143L56,142L55,142L48,135ZM65,35L65,40L63,42L61,40L61,39L61,41L59,43L57,41L57,38L57,43L55,45L53,45L53,46L51,48L50,48L49,47L49,42L49,51L48,52L48,54L46,57L45,57L44,56L44,52L44,60L43,61L43,70L42,71L42,79L42,76L43,75L44,76L44,78L45,79L45,91L46,90L48,92L48,100L48,99L49,98L51,100L51,106L51,105L52,104L53,104L55,107L55,109L54,110L54,115L54,111L56,109L59,112L59,113L60,113L65,118L65,123L65,121L67,119L69,121L71,121L73,123L73,124L74,123L75,123L76,124L79,123L80,124L80,125L81,125L81,124L82,123L83,123L84,124L86,122L87,122L88,123L88,130L88,122L90,120L92,120L93,117L95,115L96,115L97,116L97,120L97,110L98,109L98,107L100,104L102,106L102,109L102,104L101,105L100,104L100,103L101,102L102,102L102,97L103,96L101,93L101,88L100,87L100,77L101,76L101,74L101,75L100,76L99,76L97,73L97,67L98,66L98,61L98,66L96,68L94,66L94,61L93,62L92,62L90,59L90,57L91,56L91,54L91,55L89,57L87,55L87,49L87,52L86,53L83,51L83,48L84,47L84,46L84,47L82,49L81,49L79,47L79,46L80,45L80,41L80,44L78,46L77,46L76,45L76,42L76,44L75,45L74,45L73,44L73,43L72,42L73,41L73,39L73,41L71,43L70,43L69,42L69,40L67,42L66,42L65,41ZM61,43L68,43L69,44L72,44L73,45L76,46L78,48L79,48L90,59L90,60L94,65L94,66L96,69L96,71L97,72L97,74L99,77L99,80L100,81L100,88L101,89L101,97L100,98L100,102L99,103L99,106L98,107L96,112L94,114L94,115L91,118L90,118L88,120L87,120L84,122L75,122L74,121L72,121L71,120L66,118L55,107L55,106L53,104L53,103L52,102L52,101L48,94L48,92L47,91L47,89L46,88L46,86L45,85L45,79L44,78L44,66L45,65L45,61L46,60L46,58L47,57L49,52L55,46L56,46L58,44L60,44ZM61,50L60,51L57,52L55,54L55,55L53,57L53,58L51,61L51,64L50,65L50,69L49,70L49,75L50,76L50,83L51,84L51,88L52,89L52,91L53,92L53,93L54,94L54,95L55,96L57,101L59,103L59,104L67,112L68,112L70,114L72,114L73,115L76,115L77,116L81,116L82,115L84,115L85,114L88,113L90,111L90,110L94,103L94,101L95,100L95,95L96,94L96,87L95,86L95,81L94,80L94,77L93,76L93,74L92,73L92,72L91,71L89,66L87,64L87,63L84,60L84,59L80,55L79,55L77,53L76,53L73,51L71,51L70,50ZM78,82L79,81L80,81L81,82L80,83L79,83ZM79,61L81,61L83,63L83,64L86,67L86,68L87,69L87,70L91,77L91,79L92,80L92,84L93,85L93,89L92,90L92,91L90,93L88,93L86,91L86,90L83,87L83,86L80,81L80,79L79,78L79,76L78,75L78,69L77,68L77,65L78,64L78,62ZM56,61L57,61L58,62L58,63L57,64L57,66L56,67L56,70L55,71L55,81L56,82L56,87L57,88L57,90L58,91L58,92L60,94L60,95L61,96L61,97L63,99L63,100L67,104L68,104L70,106L71,106L74,108L79,108L80,109L80,110L79,111L73,111L72,110L69,109L67,107L66,107L58,98L58,97L55,92L55,90L54,89L54,87L53,86L53,83L52,82L52,70L53,69L53,66L54,65L54,63ZM59,10L58,11L57,11L56,12L51,14L49,16L48,16L45,19L44,19L37,26L37,27L35,29L35,30L32,35L32,37L31,38L31,39L30,40L30,42L29,43L29,46L28,47L28,53L27,54L27,76L28,77L28,82L29,83L29,87L30,88L30,91L31,92L31,94L32,95L32,97L33,98L33,100L34,101L34,103L35,104L35,105L36,106L36,108L37,109L39,114L41,116L42,119L44,121L44,122L47,125L47,126L51,130L51,131L56,136L57,136L61,140L62,140L64,142L65,142L66,143L77,143L76,143L75,142L73,142L72,141L70,141L68,139L66,139L63,136L64,135L64,130L64,134L62,136L60,134L59,134L51,127L51,126L49,124L49,123L46,120L46,119L42,114L42,113L41,112L41,111L40,110L40,109L36,102L36,100L35,99L35,97L33,94L33,91L32,90L32,86L31,85L31,83L30,82L30,78L29,77L29,72L28,71L28,63L29,62L29,58L31,55L32,56L32,57L32,53L33,52L33,43L34,42L34,39L36,37L37,37L38,38L38,41L38,33L39,32L39,31L40,30L42,30L43,31L43,33L43,27L45,25L46,25L47,26L47,27L47,25L49,23L50,23L51,24L51,26L51,24L53,21L55,23L55,26L55,22L56,21L58,21L59,22L61,20L63,22L63,23L63,22L64,21L65,21L67,23L67,24L67,23L68,22L70,22L71,23L73,23L74,24L74,29L74,26L75,25L76,25L78,27L78,28L79,27L80,27L82,29L82,30L81,31L81,36L81,31L82,30L84,30L85,31L85,36L85,33L86,32L87,32L89,34L89,36L90,35L92,37L93,40L94,39L96,41L96,46L96,44L97,43L98,43L99,44L99,45L100,46L100,48L99,49L99,53L99,50L101,48L103,50L103,55L104,54L105,54L107,56L107,57L106,58L106,63L106,61L107,60L108,60L110,62L110,66L112,68L112,69L113,70L113,78L112,79L112,84L112,79L113,78L114,78L116,80L116,92L115,93L115,100L114,101L114,110L113,111L113,119L112,120L112,123L109,126L108,125L108,129L107,130L107,131L105,133L104,133L103,134L103,135L101,137L100,137L99,136L99,134L99,138L97,140L96,140L95,139L95,137L95,140L93,142L90,142L91,143L94,143L95,142L96,143L111,143L112,142L117,140L119,138L120,138L122,136L123,136L126,133L126,132L131,127L133,122L136,119L136,118L139,113L139,110L141,107L141,104L142,103L142,100L143,99L143,96L142,95L142,93L143,92L143,76L142,75L142,69L141,68L141,65L140,64L140,62L138,59L138,56L136,53L136,51L135,50L135,49L134,48L132,43L131,43L129,41L129,39L128,38L128,36L126,34L126,33L123,30L123,29L121,27L120,27L117,24L117,23L112,18L111,18L110,17L108,17L107,16L107,15L102,11L98,11L95,8L93,8L92,7L91,8L88,8L85,6L77,6L76,7L70,7L69,8L65,8L64,9L62,9L61,10ZM114,128L115,127L116,127L119,130L119,131L118,132L116,132L115,131ZM129,115L130,114L132,116L131,117L130,117L129,116ZM117,114L118,115L118,118L120,120L121,120L124,123L123,124L123,125L121,127L120,127L119,126L119,125L117,123L116,123L116,124L115,125L113,130L112,131L111,131L110,130L110,127L112,124L112,122L114,119L114,117L115,116L115,115L116,114ZM126,108L127,107L128,107L130,109L129,110L127,110L126,109ZM115,100L116,100L117,101L117,105L116,106L115,106L114,105L114,101ZM134,90L135,90L136,91L136,94L135,95L134,95L133,94L133,91ZM125,87L126,86L131,86L133,88L131,90L130,90ZM123,86L124,85L125,85L126,86L125,87L124,87ZM126,61L127,61L128,62L128,65L127,66L125,64L125,62ZM127,57L128,57L130,59L130,60L132,63L132,65L134,67L134,72L135,73L135,79L136,80L136,88L135,89L134,89L133,88L133,83L132,82L132,76L131,75L131,72L130,71L130,68L129,67L129,65L128,64L128,62L126,59L126,58ZM114,41L115,40L116,41L116,42L115,43L114,42ZM119,33L120,34L120,40L121,41L123,46L126,49L126,50L127,50L128,51L128,55L127,56L125,56L125,57L124,58L122,58L121,57L121,53L119,51L117,46L118,45L119,45L121,48L121,47L115,38L115,37L116,36L117,36L117,35ZM108,31L109,31L111,33L111,35L113,37L113,38L112,39L108,35L108,34L107,33L107,32ZM100,26L101,25L103,25L106,28L106,29L105,30L102,30L101,29ZM79,21L81,21L82,22L83,22L85,24L86,24L91,29L93,29L94,30L95,30L97,32L97,35L99,35L100,36L100,37L103,40L105,40L108,42L106,44L105,44L106,47L107,47L108,48L108,49L112,54L115,54L116,55L118,55L120,57L118,59L115,59L114,58L114,61L115,62L115,64L116,65L116,67L119,69L125,69L126,70L126,71L125,72L119,72L118,73L118,74L119,75L119,78L120,79L120,80L124,84L124,85L123,86L120,86L120,87L121,88L121,96L124,99L125,99L128,102L129,102L129,95L131,93L132,94L132,100L132,98L134,96L135,97L135,99L137,101L137,102L135,104L133,104L132,103L132,102L132,103L130,106L128,106L126,104L121,102L121,105L120,106L120,111L118,114L117,114L116,113L116,107L117,106L117,84L116,83L116,79L115,78L115,75L114,74L114,71L113,70L113,68L112,67L112,65L111,64L111,62L110,61L110,60L109,59L109,58L108,57L108,56L107,55L107,54L106,53L104,48L95,38L95,37L92,36L85,28L84,28L82,26L81,26L78,23L78,22ZM71,21L73,19L74,20L76,20L77,21L77,22L76,23L74,23ZM92,19L93,18L95,18L98,21L97,22L95,22ZM66,19L67,18L69,18L71,20L70,21L68,21ZM97,18L98,17L100,17L105,22L108,21L109,22L109,25L110,26L110,28L109,29L108,29L103,24L102,24L97,19ZM96,13L97,13L98,14L98,17L97,18L96,18L94,16L94,15ZM79,10L81,12L81,13L80,14L78,14L77,13L77,12ZM64,10L65,11L65,12L63,14L60,15L59,14L59,13L61,11ZM82,9L83,8L84,8L85,9L85,10L84,11L83,11L82,10Z"
	},
	headlights: {
		w: 105,
		h: 171,
		paper: "M25,12L24,13L23,13L22,14L17,16L17,17L16,18L16,21L17,22L17,24L22,29L22,32L23,33L23,39L16,46L16,47L14,49L14,50L11,55L11,57L10,58L10,60L9,61L9,64L8,65L8,82L9,83L9,87L10,88L10,90L12,93L12,95L13,96L13,97L15,99L15,100L18,103L18,104L24,110L25,110L26,111L26,112L27,113L27,116L28,117L28,127L27,128L27,129L24,132L24,133L22,136L22,140L21,141L21,153L23,155L24,155L25,156L67,156L68,157L80,157L81,156L84,156L87,153L87,136L86,135L86,134L83,131L83,112L86,109L86,108L92,102L92,101L94,99L94,98L97,93L97,91L99,88L99,85L100,84L100,64L99,63L99,61L98,60L98,57L97,56L97,54L96,53L96,52L94,50L93,47L90,44L90,43L85,38L84,38L82,36L82,31L83,30L83,29L85,27L87,27L89,25L89,23L90,22L90,17L88,15L86,15L83,13L81,13L80,12L78,12L77,11L76,11L75,10L73,10L72,9L61,9L60,8L57,8L56,9L42,9L41,8L38,8L37,9L34,9L33,10L31,10L30,11L28,11L27,12Z",
		ink: "M40,30L39,31L37,31L36,32L33,33L31,35L30,35L27,38L26,38L17,47L17,48L15,50L15,51L12,56L12,58L11,59L11,61L10,62L10,65L9,66L9,81L10,82L10,86L11,87L11,89L13,92L13,94L14,95L14,96L16,98L16,99L19,102L19,103L25,109L26,109L27,110L27,111L28,112L28,115L29,116L29,128L28,129L28,130L25,133L25,134L23,137L23,141L22,142L22,152L24,154L25,154L26,155L68,155L69,156L70,155L74,155L75,156L79,156L80,155L83,155L86,152L86,137L85,136L85,135L82,132L82,111L85,108L85,107L91,101L91,100L93,98L93,97L96,92L96,90L98,87L98,84L99,83L99,65L98,64L98,62L97,61L97,58L96,57L96,55L95,54L95,53L93,51L92,48L89,45L89,44L84,39L83,39L80,36L79,36L77,34L76,34L73,32L71,32L70,31L68,31L67,30L65,30L64,29L59,29L58,28L50,28L49,29L44,29L43,30ZM31,149L32,148L40,148L41,149L41,150L40,151L32,151L31,150ZM81,147L81,150L79,152L42,152L41,151L41,150L43,148L54,148L55,149L69,149L70,148L76,148L78,146L80,146ZM72,146L73,145L74,145L75,146L75,147L74,148L73,148L72,147ZM66,147L66,146L67,145L69,145L70,146L68,148L67,148ZM61,145L62,145L64,147L62,149L61,149L59,147ZM53,145L54,144L55,144L56,145L56,147L55,148L54,148L53,147ZM46,145L47,144L48,144L50,146L50,147L49,148L47,148L46,147ZM40,147L40,145L41,144L42,144L44,146L42,148L41,148ZM34,145L35,144L36,144L37,145L37,146L36,147L35,147L34,146ZM73,142L74,141L76,143L75,144L74,144L73,143ZM49,142L50,141L51,141L52,142L51,143L50,143ZM32,142L34,140L37,140L40,142L39,143L33,143ZM59,130L60,131L60,137L58,139L57,139L56,140L54,140L53,139L53,138L54,137L56,137L56,136L57,135L57,131L58,130ZM54,129L55,128L56,128L57,129L56,130L55,130ZM51,129L52,128L53,129L52,130ZM79,115L79,125L78,126L78,129L79,130L79,132L77,134L65,134L64,133L63,133L57,127L49,127L46,130L46,131L45,132L33,132L32,131L32,116L33,115L34,115L35,116L35,121L36,122L36,129L42,129L43,128L44,128L47,125L48,125L49,124L51,124L52,123L54,123L55,124L58,124L60,126L61,126L63,128L63,129L64,130L74,130L75,129L75,118L72,118L71,119L69,119L68,120L66,120L65,121L62,121L61,122L57,122L55,120L56,119L60,119L61,118L65,118L66,117L68,117L69,116L72,116L74,114L76,114L77,113ZM33,104L34,103L35,103L37,105L40,104L41,105L42,108L44,108L45,109L45,110L46,109L48,109L49,110L50,109L51,109L52,110L52,111L53,111L53,110L54,109L55,109L56,110L56,111L57,111L57,110L58,109L59,109L61,111L62,110L66,110L67,109L69,109L70,108L71,108L73,106L74,106L75,105L76,105L77,106L77,107L74,110L73,110L71,112L70,112L69,113L67,113L66,114L62,114L61,115L49,115L48,114L45,114L44,113L42,113L41,112L38,111L36,109L35,109L33,107ZM83,96L84,97L84,100L82,102L81,101L81,97L82,96ZM26,96L27,96L29,98L29,99L28,100L31,99L33,101L33,103L31,106L29,104L28,104L25,101L25,97ZM23,91L24,91L25,92L25,95L24,96L23,96L22,95L22,92ZM19,92L20,91L21,92L21,93L20,94L19,93ZM20,85L21,84L22,85L21,86ZM18,84L19,85L19,88L18,89L17,89L16,88L16,86ZM92,82L93,83L93,86L92,87L92,89L91,90L91,91L89,93L88,93L88,96L87,97L86,97L85,96L85,91L87,88L87,86L88,85L88,84L90,82ZM15,82L16,81L17,81L18,82L18,83L17,84ZM91,76L92,75L93,75L94,76L94,77L93,78L92,78L91,77ZM18,57L19,56L20,57L20,58L19,59L18,58ZM90,56L91,55L92,55L93,56L92,57L91,57ZM51,40L61,40L62,41L64,41L65,42L67,42L68,43L70,43L72,45L73,45L75,47L76,47L81,52L81,53L84,56L84,57L87,62L87,66L88,67L88,69L89,70L89,77L88,78L88,82L87,83L87,85L86,86L84,91L82,93L82,94L76,100L75,100L73,102L72,102L67,105L65,105L64,106L61,106L60,107L50,107L49,106L46,106L45,105L43,105L42,104L39,103L37,101L36,101L26,91L26,90L25,89L25,87L23,85L23,83L22,82L22,75L21,74L22,73L22,66L23,65L23,63L24,62L24,60L25,59L26,56L29,53L30,50L31,49L34,48L38,44L39,44L40,43L42,43L43,42L45,42L46,41L50,41ZM40,92L39,92L37,94L37,95L39,93L40,93ZM77,90L77,91L78,91L78,90ZM74,90L72,96L73,96L73,92L74,91ZM62,89L62,90L61,91L61,93L60,94L60,96L58,98L58,100L60,97L60,95L61,94L63,94L64,93L62,91ZM53,75L52,76L52,77L53,77ZM78,74L78,86L79,85L79,82L78,81L78,80L79,79L79,76L78,75ZM52,70L52,71L53,71L53,70ZM33,61L33,62L34,62L34,61ZM75,53L75,55L73,57L73,58L71,61L71,63L70,64L70,67L68,70L68,72L67,73L67,75L64,80L64,83L63,84L65,86L66,86L66,79L67,78L67,77L69,75L70,75L72,77L69,80L69,81L70,82L70,87L72,87L73,88L74,87L74,84L73,83L73,82L74,81L74,78L75,77L75,75L73,73L73,72L74,71L74,69L74,70L73,71L72,71L71,70L71,68L73,65L74,65L75,66L75,61L74,60L75,59L75,58L77,56L75,54ZM58,46L57,46L57,47L54,52L54,54L53,55L53,56L51,59L51,61L49,64L49,66L48,67L48,69L44,76L44,81L45,81L45,80L46,79L46,76L47,75L47,72L48,71L48,69L52,65L52,61L53,60L53,58L54,57L54,55L56,53L57,53L56,52L56,51L57,50L57,48L58,47ZM18,52L18,51L20,49L20,48L26,42L29,41L29,40L30,39L31,39L35,35L36,35L41,32L43,32L44,31L46,31L47,30L59,30L60,31L63,31L64,32L67,32L68,33L69,33L70,34L71,34L72,35L77,37L80,40L81,40L88,47L88,48L89,49L89,51L88,52L86,50L86,49L82,45L82,44L80,44L79,43L78,43L76,41L75,41L72,39L70,39L67,37L65,37L64,36L62,36L61,37L60,37L59,36L54,36L53,37L52,36L46,36L46,38L45,39L44,39L43,38L43,37L43,38L41,41L40,41L38,39L38,41L36,44L35,44L34,43L34,40L33,40L33,42L32,43L32,46L31,47L29,45L29,44L30,43L29,43L29,44L24,49L24,50L21,53L19,53ZM17,19L17,20L18,21L18,23L23,28L23,31L24,32L24,34L34,28L36,28L39,26L42,26L43,25L48,25L49,24L57,24L58,25L64,25L65,26L69,26L74,29L76,29L77,30L79,30L80,31L84,26L86,26L88,24L88,22L89,21L89,18L87,16L85,16L82,14L80,14L79,13L77,13L76,12L75,12L74,11L72,11L71,10L60,10L59,9L58,9L57,10L41,10L40,9L39,9L38,10L35,10L34,11L32,11L31,12L29,12L28,13L26,13L25,14L24,14L23,15L18,17L18,18ZM68,24L69,23L70,24L69,25ZM35,16L37,14L44,14L45,15L43,17L39,17L38,18L37,18ZM24,21L27,18L56,18L57,17L62,17L54,17L53,16L53,14L54,13L62,13L63,14L69,14L70,15L70,16L69,17L65,17L80,17L83,19L83,21L81,23L80,23L79,24L78,24L77,23L60,23L59,24L44,24L43,23L40,23L39,24L26,24ZM47,14L48,13L50,13L51,14L51,15L49,17L47,15Z"
	},
	planning: {
		w: 114,
		h: 145,
		paper: "M9,22L7,24L7,25L6,26L6,119L7,120L7,130L8,131L8,133L10,135L10,136L13,138L18,138L19,139L90,139L91,138L93,138L95,136L95,135L96,134L96,131L97,130L97,120L101,116L104,115L106,113L106,112L108,110L108,109L110,106L110,104L111,103L113,103L113,90L111,90L110,89L110,87L109,86L108,83L105,80L105,79L104,79L101,76L100,76L96,72L96,43L97,42L97,36L96,35L96,24L95,23L95,22L94,21L93,21L92,20L90,20L89,19L78,19L76,17L76,16L75,15L74,15L73,14L67,14L60,6L57,6L56,5L43,5L42,6L41,6L34,14L30,14L29,15L28,15L28,16L25,19L24,19L23,20L17,20L16,21L11,21L10,22Z",
		ink: "M10,23L8,25L8,26L7,27L7,118L8,119L8,129L9,130L9,132L11,134L11,135L14,137L19,137L20,138L89,138L90,137L92,137L94,135L94,134L95,133L95,130L96,129L96,119L100,115L103,114L105,112L105,111L107,109L107,108L109,105L109,103L110,102L110,98L111,97L110,96L110,91L109,90L109,88L108,87L107,84L104,81L104,80L103,80L100,77L99,77L95,73L95,42L96,41L96,37L95,36L95,25L94,24L94,23L93,22L92,22L91,21L89,21L88,20L77,20L75,18L75,17L74,16L73,16L72,15L66,15L59,7L56,7L55,6L44,6L43,7L42,7L35,15L31,15L30,16L29,16L29,17L26,20L25,20L24,21L18,21L17,22L12,22L11,23ZM25,123L26,122L79,122L80,123L84,123L85,122L87,124L84,127L73,127L72,126L27,126L25,124ZM16,122L17,121L18,121L19,122L19,124L18,125L17,125L16,124ZM86,78L90,78L91,79L94,79L95,80L98,81L104,87L104,88L106,91L106,94L107,95L107,99L106,100L106,103L105,104L105,105L98,112L97,112L94,114L85,114L84,113L82,113L81,112L80,112L77,109L76,109L75,108L75,107L72,104L72,102L71,101L71,91L72,90L72,88L79,81L80,81L83,79L85,79ZM89,84L88,85L87,85L87,95L86,96L86,97L81,101L81,103L82,104L83,104L90,97L90,85ZM85,25L88,28L88,71L86,74L83,74L82,75L80,75L78,77L77,77L75,79L74,79L70,83L70,84L69,85L69,87L67,90L67,93L66,94L66,96L67,97L67,102L68,103L68,105L69,106L70,109L75,114L76,114L78,116L80,116L81,117L82,117L84,119L83,120L81,120L80,121L77,121L76,120L59,120L58,119L25,119L24,120L18,120L15,117L15,29L17,27L18,27L19,26L26,26L29,29L29,30L31,33L34,33L35,32L74,32L74,28L76,25ZM20,87L20,88L19,89L19,93L20,94L20,96ZM58,83L57,84L57,86L58,87L60,87L60,83ZM57,70L57,73L58,73L59,74L71,74L72,73L72,71L71,70L68,70L67,69L60,69L59,70L58,69ZM27,57L27,58L30,60L35,60L36,59L37,59L38,60L45,60L45,56L44,55L29,55ZM57,42L57,47L78,47L79,46L79,43L78,42ZM52,38L51,39L51,40L49,42L35,42L34,43L34,46L35,47L49,47L51,49L51,57L52,58L52,63L51,64L51,68L50,69L46,69L45,70L42,70L42,73L45,73L46,74L50,74L52,76L52,80L49,83L35,83L34,84L34,87L50,87L52,89L52,93L53,94L53,61L52,60L52,47L53,46L52,45ZM32,20L34,18L35,18L36,19L36,26L36,20L38,18L39,18L40,19L40,26L40,16L42,14L43,14L44,15L44,25L44,12L46,10L48,12L48,14L48,11L49,10L50,10L52,12L52,26L52,12L53,11L55,11L56,12L56,25L56,13L57,12L60,15L60,16L61,17L60,18L60,26L60,20L61,19L62,19L64,21L64,26L64,20L65,19L66,19L68,21L68,26L68,22L69,21L70,21L71,22L71,23L72,24L72,28L69,31L34,31L32,29Z"
	},
	research: {
		w: 196,
		h: 190,
		paper: "M43,165L43,176L45,178L57,178L58,179L107,179L107,177L108,176L139,176L140,177L151,177L158,173L162,173L164,171L164,169L163,168L161,168L160,167L158,167L155,165L153,165L152,164L150,164L149,163L96,163L95,164L44,164ZM146,168L147,167L152,167L153,168L153,172L152,173L147,173L146,172ZM153,10L150,10L143,17L143,18L126,35L126,36L120,42L120,43L112,52L90,52L89,53L83,53L82,52L75,52L74,53L70,53L69,52L59,52L58,51L49,51L48,50L43,50L42,49L42,38L41,37L41,36L39,34L26,34L25,35L22,35L21,36L19,36L16,38L16,39L14,42L14,46L13,47L13,125L14,126L14,145L15,146L15,147L18,150L20,150L21,151L38,151L39,150L63,150L64,151L68,151L69,150L100,150L101,149L111,149L112,150L148,150L149,151L170,151L171,150L173,150L174,149L176,149L176,97L175,96L175,91L176,90L176,56L175,55L175,53L172,51L155,51L153,49L153,34L154,33L154,12L153,11ZM99,131L101,129L128,129L129,130L129,137L127,139L100,139L99,138ZM43,105L44,104L55,104L56,105L56,107L57,108L57,109L61,114L61,118L60,119L54,119L53,118L44,118L42,116L42,107L43,106ZM51,55L52,54L57,54L58,55L98,55L99,56L103,56L104,57L104,61L103,62L103,63L94,72L94,73L86,81L86,82L79,89L79,90L69,100L69,101L68,102L68,107L69,107L70,108L72,108L74,106L80,106L82,108L89,108L90,107L113,107L114,106L144,106L145,105L153,105L153,82L154,81L154,77L153,76L153,58L155,55L167,55L168,56L169,56L171,58L171,71L172,72L172,131L171,132L171,145L168,147L141,147L140,146L134,146L133,145L133,135L134,134L141,134L141,130L142,129L160,129L161,130L161,140L164,140L164,128L163,127L99,127L98,128L97,128L97,140L98,141L98,146L97,147L31,147L30,148L26,148L25,147L24,147L22,145L22,139L29,134L41,134L42,133L42,124L44,122L67,122L68,121L68,117L64,112L64,109L63,109L59,104L59,100L65,94L65,93L68,88L68,84L69,83L69,77L68,76L68,74L67,73L67,71L65,69L65,68L61,64L60,64L58,62L52,60L51,59Z",
		ink: "M44,175L46,177L58,177L59,178L106,178L61,178L59,176L60,175L100,175L101,174L102,174L103,175L106,175L107,174L110,174L111,175L112,175L113,174L116,174L117,175L136,175L137,174L140,174L141,175L141,176L150,176L151,175L156,173L156,172L153,174L151,174L150,175L147,175L144,172L144,169L142,169L139,167L139,166L141,164L147,164L150,166L153,166L154,167L156,167L159,169L159,172L161,172L163,170L162,169L160,169L159,168L157,168L154,166L152,166L151,165L149,165L148,164L97,164L96,165L57,165L57,169L58,170L94,170L95,171L94,172L57,172L57,173L56,174L54,174L53,173L53,167L51,165L45,165L44,166ZM130,171L131,170L139,170L140,171L139,172L131,172ZM123,171L124,170L125,170L126,171L125,172L124,172ZM84,167L85,166L91,166L92,167L92,168L91,169L90,169L89,168L88,169L85,169L84,168ZM59,167L60,166L81,166L82,167L82,168L81,169L76,169L75,170L74,170L73,169L64,169L63,170L62,170L61,169L60,169L59,168ZM110,167L112,165L138,165L139,166L139,167L138,168L111,168ZM103,166L104,165L106,165L107,166L107,167L106,168L104,168L103,167ZM95,167L97,165L99,165L100,166L100,167L99,168L96,168ZM45,167L47,165L51,165L52,166L52,168L49,170L47,170L45,168ZM98,129L98,132L98,130L100,128L129,128L131,130L131,133L130,134L130,138L128,140L99,140L98,139L98,138L98,139L99,140L129,140L130,139L131,140L132,140L130,138L130,135L132,133L140,133L132,133L131,132L131,129L132,128L161,128L163,130L163,132L162,133L162,134L163,135L163,138L162,139L163,139L163,129L162,128L100,128L99,129ZM152,11L151,11L144,18L144,19L127,36L127,37L121,43L121,44L117,48L117,49L108,58L108,59L104,63L104,64L95,73L95,74L87,82L87,83L80,90L80,91L70,101L70,102L69,103L69,106L70,106L71,107L73,105L75,105L76,104L76,102L77,101L79,103L79,105L81,105L83,107L88,107L89,106L112,106L113,105L143,105L143,101L142,100L143,99L144,99L145,100L145,102L146,103L146,104L148,104L150,102L152,104L152,81L153,80L153,78L152,77L152,57L154,54L168,54L169,55L170,55L172,57L172,70L173,71L173,132L172,133L172,146L169,148L150,148L149,149L148,149L147,148L143,148L142,149L140,149L139,148L139,147L99,147L98,148L32,148L31,149L25,149L24,148L23,148L19,144L19,142L20,141L21,138L28,133L40,133L41,132L41,123L43,121L66,121L67,120L67,118L63,113L63,112L62,111L62,110L60,108L60,107L57,104L57,106L58,107L58,108L60,110L60,111L62,113L62,114L64,117L64,118L62,120L53,120L52,119L43,119L41,117L41,106L42,105L42,104L43,103L50,103L53,101L55,101L56,100L57,100L64,93L64,92L67,87L67,86L66,85L68,82L68,78L67,77L67,75L66,74L66,72L64,70L64,69L60,65L59,65L57,63L56,63L55,62L53,62L50,60L47,60L46,61L43,61L41,59L41,55L43,53L58,53L59,54L99,54L100,55L105,55L106,54L106,53L91,53L90,54L82,54L81,53L76,53L75,54L69,54L68,53L58,53L57,52L48,52L47,51L42,51L40,48L40,46L41,45L41,39L40,38L40,37L38,35L27,35L26,36L23,36L22,37L20,37L19,38L18,38L15,43L15,47L14,48L14,78L15,79L15,82L14,83L14,103L15,104L15,108L14,109L14,114L15,115L15,116L14,117L14,124L15,125L15,144L16,145L16,146L19,149L21,149L22,150L37,150L38,149L64,149L65,150L67,150L68,149L99,149L100,148L112,148L113,149L129,149L130,148L131,148L132,149L149,149L150,150L162,150L163,149L166,149L167,150L169,150L170,149L172,149L173,148L175,148L175,104L174,103L174,101L175,100L175,98L174,97L174,90L175,89L175,61L174,60L175,59L175,57L174,56L174,54L171,52L170,53L169,53L168,52L167,53L166,52L154,52L152,50L152,33L153,32L153,22L152,21L152,16L153,15L153,13L152,12ZM18,138L19,139L19,143L18,144L17,144L16,143L16,140ZM84,106L85,105L86,106L85,107ZM98,105L99,104L107,104L108,105L107,106L99,106ZM116,103L117,102L118,103L118,104L117,105L116,104ZM122,104L123,103L123,100L124,99L125,99L126,100L126,103L131,103L132,102L133,103L136,103L137,104L136,105L123,105ZM109,98L110,99L110,104L109,105L108,105L107,104L107,100ZM94,98L95,99L95,103L93,105L92,104L92,99L93,98ZM43,98L44,97L45,97L46,98L46,99L45,100L44,100L43,99ZM58,87L59,87L60,88L60,94L59,95L58,95L57,94L57,88ZM42,84L43,84L45,86L46,89L48,91L48,92L47,93L43,93L41,91L41,85ZM44,70L48,70L50,72L51,72L55,76L55,77L57,80L57,85L56,86L55,89L52,91L50,91L49,90L49,89L46,86L46,85L44,83L44,82L41,77L41,73ZM59,69L60,69L61,70L61,78L60,79L59,79L58,78L58,70ZM122,66L123,67L123,68L121,70L120,70L119,69L119,68L121,66ZM45,67L46,66L47,67L46,68ZM52,70L52,66L53,65L54,65L57,67L57,68L56,69L55,69L53,71ZM42,65L43,64L44,64L45,65L45,67L44,68L43,68L42,67ZM48,63L49,63L50,64L50,67L49,68L47,66L47,64ZM131,62L133,64L133,66L132,67L132,79L133,80L133,81L132,82L132,84L131,85L126,85L124,83L122,85L111,85L110,84L110,82L130,62ZM35,36L36,37L37,37L39,39L39,40L40,41L40,98L41,99L41,126L40,127L40,130L38,132L28,132L27,133L24,134L23,133L23,132L25,130L22,133L23,134L21,136L18,136L16,134L16,133L17,132L17,128L19,126L20,126L22,124L22,123L21,123L19,125L17,125L16,124L16,121L19,118L20,118L20,116L21,115L22,115L22,114L21,113L22,112L20,112L19,113L17,113L16,112L16,111L18,109L16,107L16,106L18,104L16,102L16,98L17,97L18,97L19,96L24,94L23,93L22,94L20,94L19,95L17,95L16,94L16,93L18,91L20,91L21,90L22,90L19,90L18,89L18,88L19,87L20,87L18,87L16,85L16,80L18,78L20,78L20,77L19,78L17,78L16,77L16,76L18,74L19,74L20,73L17,74L16,73L16,71L18,69L20,69L23,67L27,67L28,66L25,66L24,67L22,67L20,69L17,69L15,67L15,58L17,56L19,56L20,55L22,55L21,54L21,53L22,52L24,52L24,51L25,50L25,49L24,49L22,51L21,51L20,52L20,54L19,55L16,55L15,54L15,50L17,48L18,48L17,48L15,46L15,45L16,44L19,44L19,41L22,38L23,38L24,37L27,37L28,36ZM24,99L25,100L27,100L27,99ZM22,64L19,65L21,65ZM24,59L24,60L25,60L25,59ZM32,50L31,51L31,52L32,51ZM28,48L30,48L31,47L33,47L30,47L29,48ZM28,44L25,44L20,47L21,46L23,46L24,45L26,45L27,44ZM28,40L27,41L24,41L23,42L22,42L24,42L25,41L28,41Z"
	},
	marketing: {
		w: 242,
		h: 146,
		paper: "M7,38L7,41L8,42L8,54L9,55L9,56L11,58L11,63L10,64L10,66L9,67L9,74L10,75L10,76L14,83L17,84L19,86L21,86L22,87L25,87L28,89L30,89L35,92L37,92L38,93L40,93L43,95L47,95L50,97L52,97L53,98L55,98L60,101L63,101L64,102L66,102L67,103L70,103L71,104L73,104L74,105L76,105L77,106L79,106L80,107L83,107L84,108L87,108L94,112L96,112L97,113L99,113L100,114L102,114L105,116L107,116L112,119L114,119L115,120L117,120L118,121L120,121L123,123L126,123L127,124L129,124L130,125L132,125L133,126L135,126L136,127L138,127L139,128L142,128L143,129L146,129L147,130L150,130L151,131L155,131L157,133L163,133L166,131L168,131L169,130L171,130L172,129L177,127L181,123L183,123L185,121L186,121L188,119L189,119L194,115L195,115L196,114L197,114L198,113L199,113L200,112L205,110L207,108L212,106L215,103L218,102L222,98L223,98L225,96L226,96L228,94L229,94L235,88L235,87L236,86L236,84L237,83L237,77L236,76L236,68L234,66L234,65L231,62L231,58L230,57L230,55L229,55L228,54L225,54L224,53L222,53L221,52L221,48L223,46L224,46L229,43L229,39L226,36L214,36L213,35L203,35L202,34L194,34L193,33L187,33L186,32L180,32L179,31L176,31L175,30L170,30L169,29L164,29L163,28L160,28L159,27L156,27L155,26L152,26L151,25L148,25L147,24L144,24L143,23L137,23L136,22L131,22L130,21L126,21L125,20L123,20L122,19L121,19L120,18L119,18L118,17L117,17L116,16L111,14L109,12L108,12L106,10L105,10L99,4L94,4L93,5L91,5L90,6L84,6L79,3L72,3L71,4L70,4L67,7L66,7L64,9L63,9L61,11L60,11L58,13L57,13L54,15L51,15L49,17L46,17L45,18L42,18L39,20L35,20L34,21L29,21L28,22L25,22L22,24L20,24L19,25L16,26L14,28L13,28L10,31L10,32L8,35L8,37Z",
		ink: "M8,39L8,40L9,41L9,44L10,45L10,48L9,49L9,53L10,54L10,55L13,58L13,59L12,60L12,64L11,65L11,67L10,68L10,73L11,74L11,75L15,82L18,83L20,85L22,85L23,86L26,86L29,88L31,88L36,91L38,91L39,92L41,92L44,94L48,94L51,96L53,96L54,97L56,97L61,100L64,100L65,101L67,101L68,102L71,102L72,103L74,103L75,104L77,104L78,105L80,105L81,106L84,106L85,107L88,107L95,111L97,111L98,112L100,112L101,113L103,113L106,115L108,115L113,118L115,118L116,119L118,119L119,120L121,120L124,122L127,122L128,123L130,123L131,124L133,124L134,125L136,125L137,126L139,126L140,127L143,127L144,128L147,128L148,129L151,129L152,130L156,130L158,132L162,132L165,130L167,130L168,129L170,129L171,128L176,126L180,122L182,122L184,120L185,120L187,118L188,118L193,114L194,114L195,113L196,113L197,112L198,112L199,111L204,109L206,107L211,105L214,102L217,101L221,97L222,97L224,95L225,95L227,93L228,93L234,87L234,86L235,85L235,83L236,82L236,78L234,75L234,73L235,72L235,69L233,67L233,66L230,63L230,59L229,58L229,56L228,56L227,55L224,55L223,54L221,54L220,53L218,53L216,51L216,50L220,46L221,46L228,42L228,40L225,37L213,37L212,36L202,36L201,35L193,35L192,34L186,34L185,33L179,33L178,32L175,32L174,31L169,31L168,30L163,30L162,29L159,29L158,28L155,28L154,27L151,27L150,26L147,26L146,25L143,25L142,24L136,24L135,23L130,23L129,22L125,22L124,21L122,21L121,20L120,20L119,19L118,19L117,18L116,18L115,17L110,15L108,13L107,13L105,11L104,11L98,5L95,5L94,6L92,6L91,7L83,7L78,4L73,4L72,5L71,5L68,8L67,8L65,10L64,10L62,12L61,12L59,14L58,14L55,16L52,16L50,18L47,18L46,19L43,19L40,21L36,21L35,22L30,22L29,23L26,23L23,25L21,25L20,26L17,27L15,29L14,29L11,32L11,33L9,36L9,38ZM126,116L127,115L128,116L127,117ZM174,110L175,109L176,109L177,110L177,111L176,112ZM177,109L178,108L179,109L178,110ZM180,107L181,106L182,106L183,107L182,108L181,108ZM196,105L196,106L195,107L194,107L192,109L191,109L188,112L183,114L178,119L177,119L175,121L174,121L171,123L170,123L169,122L170,119L172,117L173,117L178,113L181,112L183,110L184,110L186,108L189,107L191,105L192,105L193,104L195,104ZM184,105L185,104L186,105L185,106ZM124,101L125,100L126,100L127,101L130,101L131,102L135,102L136,103L143,103L142,103L141,102L138,102L136,100L137,99L140,99L141,100L142,99L145,99L147,101L147,102L152,107L153,107L154,108L154,109L152,111L147,111L146,110L144,110L143,109L141,109L140,108L138,108L135,106L131,106L129,104L127,104L126,103L125,103L124,102ZM205,92L206,91L207,91L208,92L207,93L206,93ZM102,92L103,91L104,92L104,93L103,94L102,93ZM56,90L57,89L58,90L58,91L57,92L56,91ZM210,88L211,87L212,87L213,88L213,89L212,90L211,90L210,89ZM60,87L61,87L62,88L62,92L61,93L60,93L59,92L59,88ZM49,88L50,87L52,87L53,88L54,88L55,89L55,90L54,91L52,91L51,90L50,90L49,89ZM68,86L70,84L72,84L73,85L75,85L76,86L78,86L79,87L81,87L84,89L86,89L87,90L89,90L94,93L97,93L100,96L98,101L97,102L95,102L94,101L92,101L91,100L91,101L97,103L98,104L98,105L97,106L95,106L94,105L91,105L90,104L89,104L88,103L86,103L83,101L80,101L77,99L75,99L74,98L72,98L69,96L67,96L66,95L66,94L67,93L68,93L70,90L72,92L72,94L73,95L75,95L76,96L75,95L74,95L72,93L72,89L70,89L68,87ZM80,97L81,98L83,98ZM216,85L218,83L219,83L220,84L220,85L219,86L217,86ZM48,84L49,83L51,83L52,84L52,85L51,86L49,86L48,85ZM38,84L39,83L40,84L39,85ZM173,86L176,83L177,83L178,82L181,82L182,83L180,85L179,85L176,87L174,87ZM43,85L43,83L44,82L46,82L47,83L44,86ZM231,82L231,83L229,85L226,86L223,89L220,90L218,92L213,94L211,96L210,96L207,99L206,99L205,100L203,100L202,99L202,98L203,97L204,97L209,93L212,92L214,90L217,89L220,86L221,86L221,85L220,84L220,82L221,81L223,83L223,84L227,80L229,80ZM105,80L106,81L106,84L105,85L104,85L103,84L103,82ZM28,81L29,80L30,80L31,81L30,82L29,82ZM228,78L229,77L230,77L231,78L231,79L230,80L229,80L228,79ZM195,78L196,77L197,78L196,79ZM208,75L208,77L209,78L209,79L207,81L205,81L203,84L198,84L197,85L196,85L195,84L196,85L196,87L195,88L191,88L186,85L186,84L187,83L188,83L193,80L195,80L197,78L199,78L202,75L203,75L204,76L207,74ZM218,71L219,70L221,70L222,71L222,72L221,73L219,73L218,72ZM54,71L55,70L59,70L60,71L62,71L65,73L67,73L68,74L70,74L71,75L73,75L74,76L76,76L77,77L80,77L81,78L83,78L86,80L88,80L91,82L93,82L96,84L98,84L99,85L101,85L102,86L103,86L105,88L103,90L100,90L93,86L90,86L88,84L86,84L83,82L81,82L80,81L77,81L76,80L74,80L73,79L69,79L64,76L62,76L61,75L58,75L56,73L55,73L54,72ZM173,69L175,71L175,72L174,73L173,73L171,71ZM25,71L27,69L31,69L32,70L34,70L41,74L43,74L46,76L49,76L54,79L56,79L57,80L60,80L61,81L63,81L64,82L66,82L69,85L68,86L63,86L62,85L60,85L59,84L57,84L56,83L54,83L53,82L51,82L49,80L45,80L44,79L43,79L40,77L38,77L35,75L33,75L32,74L30,74L29,73L27,73ZM224,68L225,67L226,67L227,68L227,69L226,70L225,70L224,69ZM47,68L48,67L49,68L52,68L53,69L53,70L52,71L49,71L47,69ZM195,67L196,66L197,66L198,67L198,68L197,69L196,69L195,68ZM177,66L180,69L180,70L179,71L178,71L175,69L175,68ZM18,66L21,66L24,68L24,70L23,71L23,73L22,74L22,78L21,79L18,78L16,76L16,75L14,72L14,70L15,69L15,68ZM202,66L203,65L204,66L203,67ZM36,66L37,65L39,65L40,66L44,66L45,67L46,67L47,68L47,69L46,70L43,70L42,69L39,69L38,68L37,68L36,67ZM30,65L31,64L32,65L31,66ZM188,62L190,65L190,66L189,67L186,67L184,69L182,69L180,67L180,66L181,65L182,65L183,64ZM60,63L61,62L62,63L61,64ZM26,63L27,62L28,63L28,64L27,65L26,64ZM224,63L224,64L223,65L220,65L215,68L213,68L212,69L209,69L206,71L204,71L203,72L201,72L194,76L191,76L190,77L187,77L184,79L181,79L180,80L179,80L178,81L176,81L175,82L168,82L167,83L164,84L159,88L159,89L158,90L158,93L159,94L159,95L160,95L161,96L162,95L165,95L166,94L167,94L169,92L170,92L175,88L176,88L183,84L186,87L186,89L188,91L186,93L185,93L183,91L183,93L181,95L180,95L179,94L179,93L176,93L175,94L174,94L174,95L175,95L176,96L173,99L172,99L170,101L169,101L168,102L167,102L165,104L164,104L163,105L163,107L164,106L165,106L166,105L167,105L168,104L169,104L170,103L171,103L172,102L173,102L174,101L175,101L176,100L181,98L186,94L192,92L196,88L198,88L200,86L202,86L203,85L204,85L209,82L211,82L216,79L218,79L219,80L218,81L217,81L215,83L214,83L211,86L210,86L209,87L204,89L200,93L199,93L197,95L194,96L192,98L191,98L188,101L183,103L181,105L180,105L177,107L175,107L174,108L174,112L172,114L170,114L170,115L168,117L167,117L166,118L166,125L164,127L157,127L156,126L152,126L151,125L147,125L146,124L143,124L142,123L140,123L137,121L135,121L134,120L133,120L132,119L132,118L133,117L134,117L133,117L132,116L129,116L128,115L126,115L124,113L124,112L125,111L126,111L127,112L130,112L131,113L133,113L131,113L130,112L127,112L126,111L124,111L123,110L120,110L119,109L117,109L116,108L113,107L114,108L115,108L116,109L118,109L119,110L119,111L118,112L117,112L116,111L117,112L120,112L121,113L124,113L125,114L125,115L124,116L122,116L121,115L118,115L117,114L114,114L113,113L111,113L110,112L105,110L100,106L100,98L102,96L106,96L109,98L111,98L112,99L115,99L118,101L120,101L121,102L123,102L124,103L125,103L128,106L127,107L126,107L125,106L123,106L125,106L126,107L128,107L129,108L130,108L130,107L131,106L132,106L133,107L134,107L136,109L136,110L137,110L138,109L140,109L141,110L144,110L145,111L149,111L150,112L153,112L155,114L155,117L156,117L157,118L159,118L158,118L155,115L155,114L157,112L160,112L160,111L159,111L157,109L157,107L156,108L155,107L153,107L148,102L148,101L149,100L152,100L153,101L154,101L156,103L158,103L160,101L161,101L162,100L164,100L165,99L163,99L162,100L160,100L159,101L154,101L153,100L150,100L148,98L146,98L145,99L144,98L141,98L140,97L138,97L137,96L135,96L134,95L132,95L131,94L129,94L130,94L133,96L136,96L138,98L136,100L135,99L134,99L133,100L132,99L131,99L129,97L127,97L126,98L125,98L124,97L123,97L122,98L121,97L115,97L114,98L110,98L109,97L108,97L106,94L106,90L108,88L110,88L108,86L108,85L107,84L107,78L105,75L105,73L108,71L109,72L112,72L115,75L116,75L117,76L122,76L123,75L124,75L125,76L125,77L124,78L126,78L128,76L129,77L132,77L133,78L137,78L138,79L141,79L142,80L150,80L151,81L155,81L156,80L157,81L159,81L162,83L162,82L161,82L160,81L160,80L163,78L164,78L166,80L167,80L168,79L170,79L169,78L169,77L170,76L171,76L174,78L175,77L178,77L179,76L180,76L179,75L179,74L183,70L186,70L189,73L188,72L188,70L190,68L192,68L194,70L195,69L197,69L198,68L201,68L202,67L204,67L205,66L207,66L210,64L212,64L210,64L209,63L209,62L211,60L216,60L217,61L217,62L218,62L219,61L222,61ZM119,88L120,89L120,91L122,91L123,92L125,92L125,90L124,89L121,89L120,88ZM118,83L118,84L120,84L121,85L124,85L123,85L122,84L119,84ZM131,80L134,80L136,82L135,83L134,83L135,84L136,84L135,83L136,82L140,82L141,83L144,83L145,84L148,84L149,85L151,85L150,84L145,84L144,83L141,83L140,82L137,82L134,80ZM119,80L121,80L122,81L123,81L123,80ZM20,60L21,60L22,61L22,63L21,64L20,64L18,62ZM193,62L193,61L195,59L196,59L197,58L201,58L202,59L202,60L201,61L199,61L199,62L198,63L194,63ZM56,58L57,57L60,57L61,58L64,58L65,59L69,59L70,60L73,59L74,60L77,60L78,61L81,61L82,62L84,62L85,63L86,63L87,64L87,65L86,66L84,66L83,65L79,65L78,64L75,64L74,63L70,63L69,62L64,62L63,61L60,61L59,60L58,60ZM30,58L31,57L32,58L32,59L31,60L30,59ZM189,58L191,56L192,56L193,57L193,58L192,59L190,59ZM48,56L50,54L51,55L53,55L54,56L54,57L53,58L52,58L51,57L49,57ZM44,55L46,53L48,55L47,56L45,56ZM200,52L201,53L201,54L199,56L198,56L197,55L197,54ZM39,53L40,52L41,52L42,53L42,54L41,55ZM36,51L37,50L38,51L38,52L37,53L36,52ZM207,49L209,51L209,53L211,55L211,57L210,58L209,58L207,60L205,60L202,58L202,57L205,55L205,54L203,54L202,53L202,52ZM24,47L25,46L26,46L27,47L29,47L30,48L32,48L33,49L34,49L36,51L36,52L35,53L34,53L33,52L30,52L28,50L28,51L27,52L26,52L25,51L25,49L24,48ZM25,43L27,41L28,41L29,40L31,40L32,41L34,41L34,39L38,35L39,35L41,37L41,38L40,39L40,41L42,43L44,43L42,41L42,39L44,37L43,37L42,36L42,35L43,34L44,34L45,33L47,33L49,31L50,31L51,30L54,30L55,29L58,29L59,28L62,28L63,29L66,30L68,32L70,32L71,33L74,33L75,34L77,34L78,35L80,35L81,36L83,36L84,37L87,37L90,39L90,41L89,42L91,42L93,44L90,47L83,43L79,43L78,44L77,44L80,47L80,50L78,52L78,53L77,54L80,54L83,56L86,56L89,58L90,58L90,57L92,55L93,56L94,56L95,57L95,58L94,59L94,64L95,65L95,66L94,67L90,67L89,66L89,65L91,63L91,62L90,61L87,61L86,60L83,60L82,59L80,59L79,58L76,58L75,57L72,57L71,56L63,56L57,52L53,52L52,51L48,51L47,50L46,50L44,48L44,47L41,48L40,47L38,47L37,46L33,46L32,45L27,45ZM76,47L75,47L74,48L74,53L77,48ZM61,48L61,49L62,49L63,50L65,50L66,51L70,51L70,50L65,50L63,47L62,47ZM51,45L52,45L55,47L57,47L57,46L55,44L53,44L52,45ZM66,36L66,38L67,39L68,39L71,41L73,41L73,39L71,37L69,37L68,36ZM12,40L13,39L13,37L16,34L16,33L21,29L22,29L23,28L30,28L32,26L35,26L36,25L39,25L42,23L48,23L53,20L55,20L56,21L58,21L58,19L60,17L61,17L62,16L65,16L67,14L68,14L74,8L76,8L77,9L79,9L80,10L82,10L87,13L91,13L92,14L92,15L91,16L89,16L88,17L87,17L86,16L86,15L84,15L83,14L79,14L78,13L76,13L75,14L75,15L80,15L81,16L83,16L86,18L88,18L89,19L91,19L92,20L95,20L96,21L94,19L93,19L92,18L93,17L92,16L92,15L93,14L94,14L101,18L103,18L106,21L108,21L109,22L110,22L111,21L114,21L115,22L118,22L119,23L123,23L124,24L126,24L127,25L130,25L131,26L133,26L134,27L137,27L138,28L142,28L143,29L146,29L147,30L149,30L150,31L153,31L154,32L162,32L163,33L167,33L168,34L172,34L173,35L184,35L185,36L189,36L190,37L195,37L196,38L202,38L203,39L205,39L208,41L210,41L211,40L214,40L216,42L216,43L215,44L214,44L212,46L209,47L207,49L206,49L203,51L201,51L198,53L196,53L193,55L191,55L190,56L187,57L186,58L186,61L185,62L183,62L182,63L179,64L178,63L178,61L177,61L176,62L175,62L174,63L172,63L171,64L170,64L163,68L161,68L160,69L157,70L154,73L154,74L155,74L156,73L158,73L159,74L160,73L162,73L163,72L165,72L166,71L168,71L169,72L169,74L167,76L165,76L164,77L162,77L161,78L159,78L156,80L153,80L149,76L149,74L151,72L151,69L153,67L154,67L155,66L157,66L160,64L162,64L165,62L167,62L168,61L169,61L167,61L164,63L162,63L161,64L159,64L154,67L152,67L147,71L147,74L149,76L149,78L147,80L146,80L145,79L142,79L141,78L137,78L136,77L132,77L131,76L128,76L127,75L123,75L122,74L119,74L118,73L116,73L115,72L113,72L110,70L109,71L106,71L105,70L103,70L102,69L99,69L98,68L97,68L95,65L95,60L102,53L103,53L105,51L106,51L107,50L109,50L111,48L112,48L113,47L117,47L118,46L121,46L120,45L117,45L114,43L112,43L111,42L109,42L108,41L104,41L103,40L100,40L97,38L93,38L92,37L91,37L90,36L88,36L87,35L82,35L79,33L77,33L72,30L70,30L67,28L65,28L64,27L62,27L61,26L60,26L59,27L57,27L56,28L54,28L53,29L51,29L50,30L46,30L45,31L42,31L41,32L40,32L37,34L35,34L34,35L29,37L27,39L26,39L23,42L23,45L22,46L22,48L21,49L20,49L20,50L24,57L24,58L23,59L21,59L20,58L18,58L15,55L15,54L14,53L17,50L16,49L16,48L14,46L14,45L12,42ZM115,67L116,67L117,68L120,68L121,69L123,69L122,69L121,68L119,68L118,67ZM117,58L118,59L120,59L121,60L125,60L126,61L130,61L131,62L134,62L135,63L139,63L136,63L135,62L132,62L131,61L129,61L128,60L125,60L124,59L120,59L119,58ZM128,57L129,57L130,58L134,58L136,56L137,56L139,59L144,59L143,59L141,57L140,57L139,56L137,56L136,55L133,55L131,57ZM121,51L122,52L126,52L124,52L123,51ZM156,52L157,52L158,53L162,53L163,54L165,54L166,55L169,53L169,51L165,51L164,50L161,50L160,49L157,49L159,49L160,50L164,50L165,51L166,51L167,52L167,53L166,54L164,54L163,53L160,53L159,52ZM128,44L129,44L130,45L132,45L133,46L135,46L136,47L139,47L142,49L146,49L147,50L150,50L149,50L148,49L145,49L144,48L141,48L140,47L138,47L137,46L137,45L138,44L140,44L141,45L144,45L141,45L140,44L137,44L136,43L133,43L132,42L130,44ZM118,38L118,39L120,41L120,42L122,42L123,41L123,40L122,40L121,39L119,39ZM99,33L100,34L101,34L103,37L105,37L106,38L109,38L112,40L116,40L114,37L112,37L111,36L109,36L108,35L105,35L104,34L102,34L101,33ZM88,29L90,31L90,32L91,32L92,33L94,33L95,32L94,31L92,31L91,30L89,30ZM118,28L120,28L121,29L123,29L124,30L126,30L127,31L129,31L130,32L133,32L134,33L138,33L139,34L142,34L143,35L145,35L146,36L149,36L150,37L154,37L157,39L160,39L161,40L165,40L166,41L169,41L170,42L173,42L174,43L177,43L178,44L183,44L184,45L195,45L196,44L194,44L191,42L189,42L189,43L188,44L181,44L180,43L176,43L175,42L171,42L170,41L167,41L166,40L163,40L162,39L158,39L157,38L155,38L154,37L150,37L149,36L146,36L145,35L143,35L142,34L140,34L139,33L138,33L137,32L137,31L136,32L134,30L127,30L125,28L125,27L124,27L124,28L123,29L122,28ZM105,24L107,24L108,25L110,25L109,25L108,24ZM69,25L70,26L72,26L73,27L73,24L70,24Z"
	},
	car: {
		w: 202,
		h: 115,
		paper: "M11,11L11,22L12,23L12,26L13,27L13,30L14,31L14,35L15,36L15,39L16,40L16,43L17,44L17,46L16,47L15,47L14,48L12,48L11,49L10,49L9,50L8,50L8,51L6,53L6,54L5,55L5,57L4,58L4,61L3,62L3,66L2,67L2,71L1,72L1,78L0,79L0,88L1,89L1,90L6,90L7,91L7,95L8,96L8,98L9,99L9,101L10,102L10,103L11,104L11,105L12,106L12,107L14,109L15,109L17,111L18,111L19,112L20,112L21,113L23,113L24,114L41,114L42,113L44,113L45,112L46,112L49,109L50,109L52,107L53,107L53,106L54,105L54,104L56,102L56,100L57,99L57,97L58,96L58,90L59,89L116,89L117,88L124,88L125,89L132,89L133,88L141,88L144,85L145,86L145,97L146,98L146,99L147,100L147,101L148,102L148,104L149,105L149,106L152,109L153,109L155,111L156,111L157,112L158,112L159,113L161,113L162,114L179,114L180,113L182,113L184,111L185,111L188,108L189,108L191,106L191,105L192,104L192,103L194,101L194,99L195,98L195,80L193,78L193,76L191,74L191,73L190,72L191,71L192,71L194,73L201,73L201,66L200,65L198,65L197,64L196,64L195,63L194,63L193,62L192,62L190,60L188,60L187,59L184,59L183,58L183,57L184,56L184,45L180,41L180,40L179,39L179,38L173,38L173,39L170,42L166,42L165,41L141,41L140,40L139,40L138,39L138,38L137,37L137,35L136,34L136,31L135,30L135,28L134,27L134,23L135,22L135,21L136,20L136,16L135,15L135,14L133,12L130,12L129,11L123,11L122,10L119,10L118,9L115,9L114,8L109,8L108,7L104,7L103,6L99,6L98,5L91,5L90,4L85,4L84,3L75,3L74,2L67,2L66,1L61,1L60,0L50,0L49,1L45,1L44,2L40,2L39,3L35,3L34,4L30,4L29,5L25,5L24,6L21,6L20,7L19,7L18,8L14,8ZM189,71L190,70L191,71L190,72ZM154,57L154,56L155,55L157,55L158,56L156,58L155,58ZM144,48L145,47L174,47L175,48L176,48L177,49L177,50L178,51L178,57L177,58L174,58L173,57L173,49L145,49ZM140,47L141,46L142,47L141,48Z",
		ink: "M13,13L13,20L14,21L14,24L15,25L15,28L16,29L16,33L17,34L17,37L18,38L18,41L19,42L19,44L21,46L21,47L20,48L19,48L18,49L17,49L16,50L14,50L13,51L12,51L11,52L10,52L10,53L8,55L8,56L7,57L7,59L6,60L6,63L5,64L5,68L4,69L4,73L3,74L3,80L2,81L3,82L2,83L2,86L3,87L3,88L5,88L6,87L7,87L9,89L9,93L10,94L10,96L11,97L11,99L12,100L12,101L13,102L13,103L14,104L14,105L16,107L17,107L19,109L20,109L21,110L22,110L23,111L25,111L26,112L39,112L40,111L42,111L43,110L44,110L47,107L48,107L50,105L51,105L51,104L52,103L52,102L54,100L54,98L55,97L55,95L56,94L56,88L57,87L100,87L101,86L102,86L103,87L114,87L115,86L126,86L127,87L130,87L131,86L139,86L144,81L147,84L147,95L148,96L148,97L149,98L149,99L150,100L150,102L151,103L151,104L154,107L155,107L157,109L158,109L159,110L160,110L161,111L163,111L164,112L177,112L178,111L180,111L182,109L183,109L186,106L187,106L189,104L189,103L190,102L190,101L192,99L192,97L193,96L193,82L191,80L191,78L189,76L189,75L184,70L184,69L185,68L186,68L187,67L190,67L191,68L192,68L193,69L194,69L196,71L199,71L199,68L198,67L196,67L195,66L194,66L193,65L192,65L191,64L190,64L188,62L186,62L185,61L180,61L179,60L173,60L172,61L168,61L167,62L165,62L164,63L162,63L161,64L160,64L159,65L158,65L151,72L150,72L149,71L149,70L151,68L151,67L154,64L154,61L151,58L151,55L153,53L156,53L157,52L161,52L163,54L161,56L161,57L158,60L157,60L158,61L159,60L161,60L162,59L166,59L167,58L170,58L171,57L171,55L170,55L169,54L171,52L171,51L162,51L161,52L160,52L159,51L143,51L142,50L139,50L135,46L135,45L136,44L143,44L144,45L176,45L177,46L178,46L179,47L179,48L180,49L180,52L181,53L181,55L180,56L181,57L181,55L182,54L182,47L178,43L178,42L177,41L177,40L175,40L175,41L172,44L164,44L163,43L139,43L138,42L137,42L136,41L136,40L135,39L135,37L134,36L134,33L133,32L133,30L132,29L132,26L131,25L131,22L133,20L133,19L134,18L133,17L133,16L131,14L128,14L127,13L121,13L120,12L117,12L116,11L113,11L112,10L107,10L106,9L102,9L101,8L97,8L96,7L89,7L88,6L83,6L82,5L73,5L72,4L65,4L64,3L59,3L58,2L52,2L51,3L47,3L46,4L42,4L41,5L37,5L36,6L32,6L31,7L27,7L26,8L23,8L22,9L21,9L20,10L16,10ZM169,93L170,94L170,100L169,101L168,101L167,102L164,102L162,100L162,99L164,97L164,96L167,93ZM157,92L158,91L159,91L160,90L165,90L166,91L166,93L162,97L160,97L158,95L158,94L157,93ZM173,91L175,89L182,89L183,90L183,95L181,97L178,97L175,94L175,93ZM150,85L151,86L151,95L150,96L149,95L149,86ZM180,81L182,83L182,84L183,85L183,86L182,87L181,87L180,88L175,88L174,87L174,86L176,84L176,83L178,81ZM73,83L75,81L121,81L122,82L121,83L120,83L119,84L74,84ZM64,82L65,81L70,81L72,83L71,84L65,84L64,83ZM137,78L138,77L141,77L142,78L142,79L141,80L138,80L137,79ZM112,79L114,77L132,77L134,79L133,80L119,80L118,81L114,81ZM91,78L93,76L95,76L95,75L96,74L97,74L98,75L98,76L99,77L99,79L98,80L93,80ZM89,76L89,79L88,80L69,80L68,79L68,77L69,76L74,76L75,75L76,75L77,74L79,74L80,73L83,73L84,74L86,74L87,75L88,75ZM58,73L59,73L61,75L61,76L62,77L62,78L60,80L57,77L57,74ZM168,67L173,67L174,68L177,68L178,69L180,69L182,71L183,71L186,74L186,75L189,78L189,79L190,80L190,81L191,82L191,85L192,86L192,93L191,94L191,96L189,98L189,100L188,101L188,102L186,104L185,104L181,108L180,108L179,109L177,109L176,108L175,109L174,108L173,109L172,109L171,108L170,109L165,109L164,108L164,107L163,107L162,106L161,106L160,107L159,106L159,104L159,105L158,106L157,106L154,103L154,99L155,98L156,99L157,99L158,98L159,98L161,100L161,101L162,101L163,102L171,102L171,101L170,100L170,99L171,98L171,95L172,94L174,94L177,97L177,98L178,99L178,100L177,101L176,101L175,102L176,102L177,101L179,101L181,99L181,98L183,96L183,95L184,94L184,88L185,87L185,86L184,85L184,84L183,83L183,81L181,79L180,79L179,78L178,79L178,80L176,82L175,82L174,81L176,79L174,77L173,78L173,85L171,87L169,87L168,88L166,88L165,87L165,85L163,83L163,82L164,81L165,81L167,83L169,83L169,75L168,76L164,76L163,77L162,77L159,80L159,82L158,83L158,84L156,86L155,86L155,89L156,89L157,90L157,91L156,92L155,92L155,98L153,100L151,98L152,97L152,83L153,82L154,83L154,84L154,79L157,76L157,75L158,74L159,74L159,73L160,72L161,73L161,74L161,73L162,72L162,71L164,69L165,69L166,68L167,68ZM30,67L35,67L36,68L39,68L40,69L42,69L44,71L45,71L51,77L51,78L53,80L53,82L54,83L54,94L53,95L53,97L52,98L52,99L50,101L50,102L49,103L49,104L48,105L47,105L44,108L43,108L42,109L40,109L39,110L37,110L36,111L31,111L30,110L25,110L24,109L23,109L22,108L21,108L19,106L18,106L15,103L15,102L13,100L13,98L11,96L11,85L12,84L13,84L13,79L14,78L14,77L16,75L16,74L18,72L19,72L21,70L22,70L23,69L25,69L26,68L29,68ZM24,76L23,77L22,77L20,79L19,79L19,85L17,87L16,87L16,92L17,93L17,94L19,96L19,97L20,98L20,99L24,103L27,103L28,104L30,104L31,105L37,105L38,104L39,104L41,102L42,102L44,100L44,99L47,96L47,95L48,94L48,88L47,87L47,84L46,83L46,82L43,79L42,79L41,78L40,78L39,77L38,77L37,76L33,76L31,74L29,76L27,76L26,77L25,77ZM36,95L37,96L38,96L40,98L40,100L38,102L37,102L36,103L35,103L33,101L33,98ZM28,95L29,95L30,96L31,96L33,98L32,99L32,100L30,102L27,102L25,100L25,98ZM26,90L28,92L28,93L24,97L23,97L21,95L21,92L23,90ZM38,90L39,89L44,89L46,91L46,92L45,93L45,96L44,97L41,97L38,94ZM20,88L21,87L25,87L27,89L26,90L21,90L20,89ZM25,82L26,81L27,81L30,84L31,84L32,85L32,86L31,87L30,87L27,84L26,84L25,83ZM33,76L34,76L35,77L35,83L34,84L33,84L32,83L32,82L31,81L32,80L32,77ZM176,66L177,65L178,65L179,66L178,67L177,67ZM40,62L42,60L44,60L45,61L46,61L48,63L49,63L51,65L52,65L56,69L56,70L55,71L54,70L53,70L52,69L51,69L49,67L48,67L47,66L46,66L45,65L44,65L43,64L42,64ZM97,59L98,60L98,68L97,69L96,69L95,68L95,61ZM159,59L160,58L161,58L162,59L161,60L160,60ZM140,58L141,58L143,60L143,61L141,63L140,62L139,62L138,61L138,60ZM23,60L24,59L25,59L26,58L37,58L38,59L39,59L41,61L40,62L32,62L31,61L26,61L25,62ZM149,57L150,56L151,57L151,58L150,59L149,58ZM95,56L96,55L97,55L98,56L97,57L96,57ZM145,54L147,54L149,56L149,59L151,61L151,64L150,65L149,65L148,64L147,65L145,63L145,58L143,56ZM166,53L167,52L168,52L169,53L169,55L168,56L167,56L166,55ZM67,50L68,49L70,49L71,50L71,51L70,52L69,52ZM118,40L119,39L121,39L122,40L122,41L121,42L119,42L118,41ZM132,34L132,35L131,36L130,36L129,37L126,37L124,35L125,34L125,31L124,31L120,35L119,35L119,36L118,37L118,38L114,42L107,42L106,41L106,40L105,39L104,39L102,37L101,37L100,36L100,34L99,33L99,26L100,25L100,23L101,22L122,22L123,21L126,21L127,22L127,23L128,24L128,25L129,26L129,32L130,32ZM32,24L34,22L45,22L46,21L52,21L53,22L55,22L56,23L56,31L55,32L55,41L56,41L57,42L62,42L62,29L61,28L62,27L62,23L63,22L72,22L73,21L86,21L87,22L94,22L96,24L96,36L97,36L99,38L99,40L97,42L92,42L91,43L90,43L89,42L83,42L82,41L81,41L80,40L79,40L78,39L77,39L74,36L70,36L69,37L69,41L68,42L67,42L86,42L87,43L88,42L89,43L91,43L92,42L93,42L94,43L95,42L99,42L100,43L101,42L127,42L127,41L128,40L131,40L132,41L134,41L136,43L136,44L135,45L134,45L133,46L128,46L127,47L124,47L123,46L118,46L117,47L116,46L109,46L108,47L101,47L101,48L105,48L106,49L106,51L105,52L101,52L100,51L99,51L96,48L96,47L78,47L75,50L73,48L69,48L68,47L61,47L60,48L59,47L53,47L52,48L40,48L39,47L38,47L36,45L36,44L37,43L39,43L40,44L41,43L42,43L41,42L41,41L40,40L40,39L39,38L38,38L37,37L36,37L33,34L33,30L32,29ZM17,14L18,15L18,24L17,25L16,24L16,15ZM19,11L20,10L21,11L21,12L20,13L19,12ZM18,38L18,31L17,30L17,29L18,28L18,17L19,16L20,16L21,17L21,11L23,9L24,9L25,8L28,8L29,7L34,7L35,6L41,6L42,5L46,5L47,4L66,4L67,5L76,5L77,6L82,6L83,7L88,7L89,8L94,8L95,9L101,9L102,10L109,10L110,11L116,11L117,12L120,12L121,13L124,13L125,14L128,14L129,15L130,15L131,16L131,18L130,19L117,19L116,18L115,18L114,19L109,19L108,18L103,18L102,19L100,19L99,18L91,18L90,19L88,19L87,18L85,18L84,19L61,19L60,18L59,18L58,17L57,17L56,18L55,18L54,17L54,15L54,17L53,18L40,18L39,19L25,19L23,21L24,22L24,24L25,25L25,31L26,32L26,37L27,38L27,42L23,46L22,45L21,45L20,44L20,40ZM34,11L34,13L36,13L36,11Z"
	},
	truck: {
		w: 233,
		h: 123,
		paper: "M4,44L4,47L3,48L3,52L4,53L4,63L3,64L3,71L1,73L1,74L0,75L0,83L1,83L2,84L4,84L5,85L6,85L7,86L8,86L9,87L12,87L13,88L15,88L16,89L20,89L21,90L23,90L24,91L26,91L27,92L29,92L30,93L33,93L34,94L34,103L35,104L35,106L37,108L37,109L38,110L38,111L43,116L44,116L45,117L46,117L47,118L48,118L49,119L51,119L52,120L55,120L56,121L61,121L62,120L66,120L67,119L70,119L71,118L72,118L74,116L75,116L80,111L80,110L81,109L81,108L82,107L82,106L83,105L83,104L84,103L84,101L85,100L91,100L92,101L149,101L150,102L162,102L163,101L173,101L174,100L174,99L176,97L177,97L178,98L178,102L179,103L179,105L180,106L180,107L181,108L181,109L182,110L182,111L185,114L185,115L186,115L189,118L190,118L192,120L193,120L194,121L195,121L196,122L211,122L212,121L216,121L217,120L218,120L219,119L220,119L227,112L227,111L229,109L229,108L230,107L230,104L231,103L231,89L230,88L230,86L229,85L229,83L227,81L227,80L225,78L226,77L227,77L228,78L232,78L232,72L227,67L226,67L224,65L223,65L221,63L220,63L219,62L217,62L215,60L215,52L214,51L214,50L211,47L210,47L209,46L208,46L207,45L205,45L204,44L202,44L201,43L197,43L196,42L192,42L191,41L187,41L186,40L182,40L181,39L177,39L176,38L175,38L174,37L174,35L173,34L173,33L172,32L172,28L171,27L171,24L172,23L172,22L173,21L173,15L172,14L172,13L171,12L170,12L169,11L168,11L167,10L165,10L164,9L161,9L160,8L158,8L157,7L154,7L153,6L149,6L148,5L145,5L144,4L141,4L140,3L137,3L136,2L133,2L132,1L127,1L126,0L113,0L112,1L110,1L109,2L108,2L106,4L105,4L103,6L102,6L98,10L98,11L97,12L97,13L96,14L96,15L95,16L95,23L94,24L94,47L93,48L91,48L90,49L18,49L16,47L16,46L14,44ZM164,91L165,90L166,91L165,92ZM165,89L166,88L167,89L167,90L166,91L165,90ZM166,87L167,86L168,87L168,88L167,89L166,88ZM170,80L171,81L171,82L169,84L169,86L168,87L167,86L167,81L168,80ZM174,74L175,75L174,76L174,77L173,78L172,77L172,75L173,74ZM216,71L217,70L218,71L217,72ZM177,71L178,70L179,71L178,72Z",
		ink: "M6,46L6,49L5,50L6,51L6,65L5,66L5,70L6,71L5,72L5,73L3,75L3,76L2,77L2,81L3,81L4,82L6,82L7,83L8,83L9,84L10,84L11,85L14,85L15,86L17,86L18,87L22,87L23,88L25,88L26,89L28,89L29,90L31,90L32,91L34,89L34,88L35,87L35,86L36,85L36,84L38,82L39,83L39,84L38,85L38,86L37,87L37,88L36,89L36,101L37,102L37,104L39,106L39,107L40,108L40,109L45,114L46,114L47,115L48,115L49,116L50,116L51,117L53,117L54,118L57,118L58,119L59,119L60,118L64,118L65,117L68,117L69,116L70,116L72,114L73,114L78,109L78,108L79,107L79,106L80,105L80,104L81,103L81,102L82,101L82,99L83,98L93,98L94,99L151,99L152,100L160,100L161,99L171,99L172,98L172,97L174,95L175,95L176,94L177,94L179,92L179,90L180,89L181,90L181,93L180,94L180,100L181,101L181,103L182,104L182,105L183,106L183,107L184,108L184,109L187,112L187,113L188,113L191,116L192,116L194,118L195,118L196,119L197,119L198,120L209,120L210,119L214,119L215,118L216,118L217,117L218,117L225,110L225,109L227,107L227,106L228,105L228,102L229,101L229,91L228,90L228,88L227,87L227,85L225,83L225,82L223,80L223,79L221,77L220,77L217,74L215,74L214,73L213,73L212,72L211,72L210,71L211,70L213,70L214,69L214,68L215,67L217,67L218,68L219,68L221,70L222,70L225,73L226,73L228,75L229,75L230,76L230,74L225,69L224,69L222,67L221,67L219,65L218,65L217,64L215,64L214,63L207,63L206,62L204,62L203,63L197,63L196,64L194,64L193,65L192,65L191,66L190,66L189,67L188,67L186,69L185,69L176,78L176,79L174,81L174,82L173,83L173,84L171,86L171,88L170,89L170,90L169,91L169,92L167,94L142,94L141,93L133,93L132,94L131,93L130,94L116,94L115,93L111,93L110,92L111,91L132,91L133,90L136,90L137,89L140,89L141,90L146,90L147,89L153,89L154,88L156,88L157,89L162,89L163,88L163,87L164,86L164,85L165,84L165,78L166,77L166,73L167,72L168,73L168,78L169,78L170,77L170,62L171,61L172,62L172,63L173,64L173,65L172,66L172,69L173,70L173,72L174,72L175,71L175,65L177,63L178,64L178,67L179,68L181,66L181,63L182,62L183,62L184,63L184,64L186,64L186,61L187,60L189,62L192,62L193,61L197,61L198,60L213,60L213,54L212,53L212,52L209,49L208,49L207,48L206,48L205,47L203,47L202,46L200,46L199,45L195,45L194,44L190,44L189,43L185,43L184,42L180,42L179,41L175,41L174,40L173,40L172,39L172,37L171,36L171,35L170,34L170,30L169,29L169,26L168,25L168,24L169,23L169,22L170,21L170,20L171,19L171,17L170,16L170,15L169,14L168,14L167,13L166,13L165,12L163,12L162,11L159,11L158,10L156,10L155,9L152,9L151,8L147,8L146,7L143,7L142,6L139,6L138,5L135,5L134,4L131,4L130,3L125,3L124,2L115,2L114,3L112,3L111,4L110,4L108,6L107,6L105,8L104,8L100,12L100,13L99,14L99,15L98,16L98,17L97,18L97,25L96,26L96,49L95,50L93,50L92,51L16,51L14,49L14,48L12,46ZM219,106L220,107L220,109L219,110L218,110L217,111L216,111L215,110L215,109L218,106ZM191,107L192,106L193,106L196,109L197,109L198,110L199,110L200,111L204,111L205,112L207,112L208,111L211,111L212,110L213,110L214,109L215,110L215,113L214,114L213,113L211,115L210,115L209,116L207,116L206,115L202,115L201,116L200,115L199,115L198,114L197,114L196,113L195,113L194,112L194,110L192,110L191,109ZM44,106L45,105L46,105L50,109L52,109L53,110L55,110L56,111L62,111L63,110L65,110L66,111L66,113L65,114L63,114L62,115L61,114L60,115L58,115L57,114L56,114L55,115L53,113L49,113L47,111L47,110L44,107ZM202,103L203,104L203,108L202,109L201,109L199,107L199,106ZM221,101L222,102L222,105L221,106L220,105L220,102ZM207,102L208,101L209,101L210,102L210,103L213,106L213,107L212,108L211,108L210,109L208,109L207,108ZM62,101L64,103L64,105L61,108L59,106L60,105L60,102L61,101ZM74,100L76,102L76,106L74,108L73,108L73,109L72,110L70,110L69,111L68,111L67,112L66,111L66,110L72,104L72,103L73,102L73,101ZM199,99L200,100L199,101L199,102L196,105L194,103L194,102L193,101L195,99ZM224,98L225,99L225,103L224,104L223,103L223,99ZM212,99L213,98L217,98L218,99L218,101L216,103L215,103L212,100ZM39,98L40,97L41,98L41,99L40,100L39,99ZM77,96L78,97L78,102L77,103L76,102L76,97ZM42,96L43,96L44,97L44,104L43,105L42,104L42,103L41,102L41,97ZM76,94L77,93L78,94L77,95ZM63,93L65,93L68,96L70,96L71,97L71,100L70,101L70,102L69,103L67,103L64,100L64,96L63,96L62,95L62,94ZM185,92L186,93L186,99L185,100L184,99L184,93ZM59,89L60,90L57,93L57,96L58,97L59,97L60,98L60,99L59,100L58,100L58,101L57,102L57,106L55,108L53,108L51,106L52,105L52,104L55,101L55,100L56,99L55,98L52,98L51,99L50,99L49,100L48,100L46,98L46,97L45,96L45,95L47,93L48,94L50,94L51,93L52,93L53,92L54,92L56,90L57,90L58,89ZM216,88L217,89L217,90L218,91L218,93L217,94L216,94L215,95L210,95L209,94L215,88ZM189,89L190,88L191,89L190,90ZM224,87L225,88L225,93L224,94L223,93L223,88ZM49,87L50,86L51,86L52,87L52,88L51,89ZM221,85L222,86L222,90L221,91L220,90L220,86ZM42,85L43,86L43,89L44,90L44,92L43,93L42,93L39,90L39,89L41,87L41,86ZM210,83L212,85L212,86L210,88L210,89L205,94L204,94L203,95L202,95L201,96L200,96L199,95L200,94L200,92L201,91L204,91L205,90L206,90L206,89L207,88L207,85L209,83ZM191,83L192,82L194,84L194,85L193,86L192,86L191,85ZM85,82L86,81L88,83L88,84L89,85L89,86L90,87L90,88L92,90L97,90L98,91L108,91L109,92L108,93L90,93L87,90L87,88L86,87L86,84L85,83ZM195,80L196,81L196,83L195,84L193,82ZM107,81L108,80L109,81L108,82ZM97,80L98,81L98,83L99,84L99,85L98,86L96,84L96,81ZM40,79L41,80L41,81L39,83L38,82L38,81ZM213,79L214,78L216,80L217,80L218,81L218,82L219,81L220,82L220,85L219,86L218,86L213,81ZM150,79L150,80L148,82L116,82L115,81L116,80L144,80L145,79L148,79L149,78ZM40,79L41,78L42,79L41,80ZM186,78L187,77L188,78L187,79ZM82,78L83,77L84,77L85,78L85,79L86,80L86,81L85,82L83,80L83,79ZM41,78L42,77L43,78L42,79ZM210,78L210,79L209,80L204,80L203,81L199,81L198,82L197,82L196,81L196,80L197,79L198,79L198,78L199,77L203,77L204,76L205,76L206,77L209,77ZM187,77L188,76L189,77L188,78ZM81,77L82,76L83,77L82,78ZM42,77L43,76L44,77L43,78ZM80,76L81,75L82,76L81,77ZM43,83L44,82L44,81L46,79L47,79L49,77L50,77L51,76L53,76L54,75L64,75L65,76L67,76L68,77L69,77L70,78L71,78L75,82L75,83L76,84L76,89L75,90L74,89L74,88L71,85L71,84L70,83L68,83L66,81L64,81L63,80L61,80L61,83L60,84L60,86L59,87L58,86L58,84L56,82L55,82L53,80L52,81L51,81L50,82L49,82L48,83L47,83L47,86L46,87L45,87L44,86L44,84ZM60,68L61,67L65,67L66,68L70,68L71,69L73,69L74,70L75,70L77,72L76,73L75,73L74,72L72,72L71,71L70,71L69,70L65,70L64,69L61,69ZM167,63L168,64L168,66L167,67L166,66L166,64ZM137,58L138,57L139,57L140,58L139,59L138,59ZM141,57L142,56L143,56L144,57L144,58L143,59L142,59L141,58ZM14,54L15,53L46,53L47,54L57,54L58,53L61,53L62,54L63,53L64,54L66,54L67,53L75,53L76,54L77,53L84,53L85,54L86,53L90,53L91,54L91,55L90,56L15,56L14,55ZM9,49L11,51L10,52L10,75L9,76L8,75L8,50ZM158,48L159,47L160,48L159,49ZM176,46L177,45L184,45L185,46L188,46L189,47L193,47L194,48L197,48L198,49L201,49L202,50L202,51L201,52L194,52L192,54L190,54L188,52L187,53L186,53L185,54L180,54L178,52L178,51L177,50L177,47ZM113,14L114,15L114,17L113,18L112,17L112,15ZM120,14L121,13L122,14L122,15L121,16L120,15ZM114,11L115,10L116,10L117,11L116,12L115,12ZM102,14L108,8L109,8L111,6L113,6L114,5L119,5L120,4L121,4L122,5L127,5L128,6L132,6L133,7L135,7L136,8L140,8L141,9L145,9L146,10L149,10L150,11L152,11L153,12L155,12L156,13L159,13L160,14L163,14L164,15L166,15L168,17L166,19L165,19L164,18L160,18L159,17L158,17L156,19L154,17L152,17L151,16L150,17L149,16L148,17L146,15L145,16L144,15L144,13L143,14L141,14L140,13L139,13L139,16L138,17L135,17L134,16L134,12L134,14L133,15L132,14L132,13L131,13L130,12L130,11L129,11L129,16L128,17L126,17L125,16L125,14L124,13L125,12L127,12L127,9L126,9L126,10L125,11L124,11L124,14L123,15L122,14L122,9L122,10L121,11L120,10L120,9L120,11L119,12L119,16L118,17L117,16L117,9L116,9L115,10L114,9L114,11L113,12L112,11L112,10L112,14L111,15L110,15L109,14L108,14L108,16L109,17L109,18L110,19L110,20L111,21L111,22L112,23L112,24L113,25L113,26L114,27L114,28L116,30L116,31L117,32L117,33L118,34L118,35L119,36L119,37L121,39L121,40L122,41L122,42L123,43L123,44L125,46L126,46L126,45L124,43L124,42L123,41L123,40L122,39L122,38L121,37L121,36L120,35L120,34L119,33L119,32L118,31L118,30L117,29L117,28L116,27L116,26L115,25L115,22L117,20L121,20L122,19L123,20L127,20L128,19L129,20L131,20L132,19L133,20L145,20L146,21L158,21L159,22L163,22L165,24L165,25L166,26L166,29L167,30L167,32L168,33L168,40L167,41L159,41L158,42L158,45L159,46L159,47L158,48L156,46L155,46L152,43L151,43L149,41L149,39L148,38L148,36L150,34L150,32L149,31L148,32L148,33L143,38L143,39L140,42L140,43L139,44L139,45L141,45L142,44L142,43L144,41L146,41L147,42L148,42L151,45L151,46L149,48L150,49L149,50L135,50L134,49L118,49L117,48L112,48L111,47L109,47L108,46L107,46L104,43L103,43L100,40L100,22L101,21L101,17L102,16ZM112,34L112,39L113,38L114,39L114,45L115,45L115,42L116,41L117,41L117,37L116,38L115,37L115,36L114,35L114,37L113,38L112,37ZM110,28L110,30L109,31L109,36L110,37L110,41ZM104,18L104,41L105,40L106,41L106,42L107,42L107,28L107,32L105,34L104,33L104,28L105,27L105,26L104,25L104,24L105,23L105,18Z"
	},
	sports: {
		w: 222,
		h: 104,
		paper: "M220,53L218,51L218,50L217,49L217,48L214,45L214,44L213,44L212,43L211,43L210,42L209,42L208,41L204,41L203,40L203,36L202,35L202,32L201,31L201,29L198,26L195,26L194,25L194,21L193,20L187,20L187,23L186,24L181,24L180,23L174,23L173,22L168,22L167,21L160,21L159,20L152,20L151,19L143,19L142,18L137,18L134,15L134,14L133,13L133,12L132,11L132,10L131,9L131,7L130,6L130,5L129,4L129,3L128,2L128,0L122,0L122,7L123,8L123,9L124,10L124,12L125,13L125,14L124,15L121,15L120,16L119,16L118,17L117,17L116,16L118,14L118,13L120,11L120,7L118,5L114,5L112,7L112,8L108,12L108,13L106,15L106,16L102,20L102,21L100,23L100,29L103,29L104,30L104,31L100,35L99,35L98,36L93,36L88,31L88,30L84,26L84,25L80,21L80,20L76,16L76,15L72,11L70,11L69,10L58,10L57,11L57,14L56,15L56,19L54,21L50,21L49,22L44,22L43,23L38,23L37,24L33,24L32,25L29,25L28,26L25,26L24,27L22,27L21,28L20,28L19,29L17,29L16,30L15,30L14,31L13,31L12,32L11,32L9,34L8,34L6,36L5,36L5,37L1,41L1,42L0,43L0,53L1,54L1,55L3,57L3,58L7,62L8,62L10,64L11,64L13,66L20,66L21,67L21,83L22,84L22,86L23,87L23,89L25,91L25,92L27,94L27,95L28,95L31,98L31,99L32,99L33,100L34,100L35,101L37,101L38,102L41,102L42,103L52,103L53,102L57,102L58,101L60,101L61,100L62,100L63,99L64,99L71,92L71,91L72,90L72,89L73,88L73,86L74,85L74,81L75,80L75,79L76,78L100,78L101,79L111,79L112,80L113,80L114,81L116,81L117,82L119,82L120,83L133,83L134,82L137,82L138,81L139,81L140,80L141,80L143,78L144,78L145,77L152,77L153,78L164,78L166,76L168,78L168,84L169,85L169,86L170,87L170,88L171,89L171,90L173,92L173,93L174,94L174,95L177,98L178,98L179,99L180,99L181,100L182,100L183,101L185,101L186,102L188,102L189,103L200,103L201,102L204,102L205,101L207,101L209,99L210,99L212,97L213,97L217,93L217,92L219,90L219,88L220,87L220,84L221,83L221,69L220,68L220,67L219,66L219,64L218,63L218,62L216,60L217,59L219,59L220,58ZM10,43L11,44L11,51L10,52L8,50L8,49L7,48L7,46ZM99,42L100,42L101,43L101,49L100,50L99,50L98,49L98,43ZM80,39L81,40L84,40L86,42L86,53L85,54L84,54L82,52L82,49L80,49L79,48L79,40ZM184,31L185,30L186,31L190,31L191,32L192,32L193,33L194,33L195,34L195,35L196,36L195,37L185,37L184,36ZM115,31L116,30L117,31L116,32ZM74,37L74,52L71,55L67,51L66,51L65,50L64,50L63,49L62,49L61,48L59,48L58,47L55,47L54,46L45,46L44,47L41,47L40,48L38,48L36,50L35,50L34,51L33,51L31,53L30,53L29,54L29,55L28,56L27,56L25,58L25,59L23,61L23,62L22,63L22,65L21,66L20,65L20,59L19,58L19,42L16,42L15,41L14,41L13,40L14,39L15,39L16,38L17,38L18,37L19,37L20,36L21,36L22,35L23,35L24,34L26,34L27,33L29,33L30,32L32,32L33,31L36,31L37,30L39,30L40,29L44,29L45,28L52,28L53,27L60,27L61,28L62,28L63,29L65,29L67,31L68,31ZM136,26L136,27L135,28L133,28L133,29L131,31L127,31L126,30L121,30L120,31L117,31L116,30L118,28L120,28L121,27L122,27L123,26L126,26L127,25L135,25Z",
		ink: "M100,44L99,45L99,47L100,48ZM84,43L84,49L83,50L83,52L84,53L84,54L84,53L85,52L85,51L84,50ZM72,36L72,52L72,45L73,44L72,43ZM25,36L25,37L24,38L25,39L25,41L24,42L24,54L25,54ZM29,35L29,36L28,37L28,48L29,49L29,50ZM33,34L33,43L32,44L32,45L33,46L33,47ZM68,33L68,51L68,49L69,48L69,34ZM41,33L40,34L40,41L41,42L41,40L40,39L41,38ZM37,32L36,33L36,35L37,36L37,45ZM64,31L64,46L64,34L65,33L64,32ZM48,31L48,40L49,40L49,31ZM44,31L44,41L45,42L45,43L45,31ZM60,30L60,46L61,46L61,30ZM56,30L56,44L57,44L57,30ZM53,30L52,31L52,43L53,43ZM218,55L216,53L216,52L215,51L215,50L212,47L212,46L211,46L210,45L209,45L208,44L207,44L206,43L190,43L189,44L186,44L185,45L182,45L181,46L180,46L179,47L178,47L177,48L176,48L174,50L173,50L167,56L167,57L166,58L165,58L164,57L164,56L166,54L166,53L171,48L172,48L175,45L177,45L178,44L179,44L180,43L182,43L183,42L185,42L186,41L191,41L192,40L201,40L201,38L200,37L200,34L199,33L199,31L196,28L193,28L192,27L192,26L191,25L191,24L192,23L191,22L189,22L189,25L188,26L179,26L178,25L172,25L171,24L166,24L165,23L158,23L157,22L150,22L149,21L141,21L140,20L135,20L132,17L132,16L131,15L131,14L130,13L130,12L129,11L129,9L128,8L128,7L127,6L127,5L126,4L126,2L124,2L124,5L125,6L125,7L126,8L126,10L127,11L127,12L128,13L128,14L129,15L129,16L127,18L126,17L123,17L122,18L121,18L120,19L120,20L119,21L118,21L117,20L116,20L113,17L113,16L114,15L114,14L116,12L116,11L118,9L116,7L114,9L114,10L110,14L110,15L108,17L108,18L104,22L104,23L102,25L102,27L105,27L106,26L106,25L108,23L108,22L109,21L111,21L112,22L112,24L108,28L108,29L107,30L107,31L106,32L106,33L102,37L101,37L100,38L97,38L96,39L94,39L93,38L91,38L86,33L86,32L82,28L82,27L78,23L78,22L74,18L74,17L70,13L68,13L67,12L60,12L59,13L59,16L58,17L58,21L56,23L52,23L51,24L46,24L45,25L40,25L39,26L35,26L34,27L31,27L30,28L27,28L26,29L24,29L23,30L22,30L21,31L19,31L18,32L17,32L16,33L15,33L14,34L13,34L11,36L10,36L8,38L7,38L7,39L3,43L3,44L2,45L2,51L3,52L3,53L5,55L5,56L9,60L10,60L12,62L13,62L15,64L18,64L18,61L17,60L17,59L16,58L16,57L17,56L17,44L17,45L16,46L16,51L17,52L17,53L16,54L16,55L17,56L16,57L16,58L15,59L13,57L13,43L13,55L11,57L6,52L6,51L5,50L5,44L12,37L13,37L14,36L15,36L16,35L17,35L18,34L19,34L20,33L21,33L22,32L24,32L25,31L27,31L28,30L30,30L31,29L34,29L35,28L37,28L38,27L42,27L43,26L50,26L51,25L62,25L63,26L64,26L65,27L67,27L69,29L70,29L75,34L76,34L77,35L78,35L79,36L80,36L81,37L82,37L83,38L86,38L87,39L90,39L91,40L100,40L101,39L103,39L116,26L118,26L119,25L120,25L121,24L124,24L125,23L138,23L139,24L153,24L154,25L164,25L165,26L170,26L171,27L178,27L179,28L187,28L188,29L192,29L193,30L194,30L195,31L196,31L197,32L197,33L198,34L198,38L197,39L189,39L188,40L185,40L184,39L183,39L182,38L182,37L181,36L181,35L182,34L182,31L181,31L180,30L171,30L170,29L159,29L158,28L151,28L150,27L143,27L142,26L140,26L139,27L138,27L138,30L137,31L136,31L135,30L135,31L133,33L125,33L124,32L123,32L122,33L119,33L117,35L116,34L115,35L115,36L113,38L112,38L110,40L107,40L107,41L106,42L105,42L103,44L103,51L102,52L100,52L100,56L99,57L98,57L96,55L96,45L96,55L94,57L92,55L92,44L92,55L90,57L89,56L89,55L88,54L88,44L88,55L86,57L83,57L80,54L80,51L80,53L78,55L77,54L77,41L76,40L76,39L76,54L74,56L74,58L75,59L75,60L77,62L77,63L79,65L79,66L81,68L82,68L84,70L83,71L81,71L80,70L78,70L77,69L77,68L76,67L76,66L75,65L75,64L72,61L72,60L65,53L64,53L63,52L62,52L61,51L60,51L59,50L57,50L56,49L53,49L52,48L47,48L46,49L43,49L42,50L40,50L38,52L37,52L36,53L35,53L33,55L32,55L31,56L31,57L30,58L29,58L27,60L27,61L25,63L25,64L24,65L24,67L23,68L23,81L24,82L24,84L25,85L25,87L27,89L27,90L29,92L29,93L30,93L33,96L33,97L34,97L35,98L36,98L37,99L39,99L40,100L43,100L44,101L50,101L51,100L55,100L56,99L58,99L59,98L60,98L61,97L62,97L69,90L69,89L70,88L70,87L71,86L71,84L72,83L72,79L73,78L73,77L74,76L102,76L103,77L113,77L114,78L115,78L116,79L118,79L119,80L121,80L122,81L131,81L132,80L135,80L136,79L137,79L138,78L139,78L141,76L142,76L143,75L154,75L155,76L162,76L167,71L169,73L169,75L170,76L170,82L171,83L171,84L172,85L172,86L173,87L173,88L175,90L175,91L176,92L176,93L179,96L180,96L181,97L182,97L183,98L184,98L185,99L187,99L188,100L190,100L191,101L198,101L199,100L202,100L203,99L205,99L207,97L208,97L210,95L211,95L215,91L215,90L217,88L217,86L218,85L218,82L219,81L219,71L218,70L218,69L217,68L217,66L216,65L216,64L214,62L214,61L207,54L208,53L212,53L213,54L214,54L215,55L215,56L216,57L217,57L218,56ZM198,96L198,98L197,99L193,99L191,97L192,96L195,96L196,95L197,95ZM181,87L182,88L182,92L181,93L179,91L179,89ZM210,86L210,92L209,93L208,93L207,92L206,92L206,95L205,96L204,96L203,95L203,94L202,94L202,95L201,96L200,96L199,95L199,94L194,94L193,95L191,95L190,96L190,97L189,98L187,96L187,94L186,95L185,95L184,94L184,93L183,92L185,90L186,90L187,91L190,91L191,92L193,92L194,91L202,91L208,85L209,85ZM194,87L195,86L195,85L196,84L198,84L201,87L201,88L200,89L199,89L198,90L196,90L194,88ZM48,85L49,84L51,84L54,87L54,88L53,89L51,89L50,90L49,90L48,89ZM182,80L183,79L185,79L186,80L184,82ZM29,79L30,78L31,78L32,79L32,82L33,83L33,85L37,89L38,89L40,91L42,91L43,92L52,92L53,91L55,91L56,92L52,96L49,96L48,97L47,97L46,98L41,98L40,97L42,95L40,95L39,94L37,94L35,92L34,93L33,93L31,91L31,86L30,85L30,84L29,83ZM124,76L125,75L130,75L131,76L131,77L130,78L125,78L124,77ZM26,75L27,74L28,75L27,76ZM194,71L195,70L196,70L198,72L196,74L194,72ZM61,72L61,80L60,81L60,82L59,83L53,83L49,79L47,79L46,80L46,81L47,82L47,88L45,90L44,90L43,89L41,89L38,86L39,85L39,84L43,80L41,80L38,83L36,83L34,81L34,74L35,73L39,73L40,74L44,74L45,75L46,75L47,76L55,76L56,77L58,77L58,71L59,70ZM48,71L49,70L50,70L52,72L55,72L56,73L55,74L50,74L48,72ZM103,70L104,69L105,70L104,71ZM86,70L87,69L98,69L99,70L98,71L87,71ZM204,68L207,71L207,72L208,73L208,78L207,79L207,82L205,84L204,84L203,83L200,83L199,82L198,82L197,81L197,80L196,79L194,79L193,80L193,85L192,86L192,87L190,89L187,89L185,87L185,85L190,80L187,80L186,79L188,77L188,76L190,74L191,74L193,76L202,76L203,77L205,77L205,76L204,75L200,75L198,73L199,72L201,72L202,71L203,71L203,69ZM32,67L33,68L33,70L32,71L32,73L31,74L30,74L29,73L29,70L30,69L30,68L31,67ZM133,67L133,68L132,69L131,69L130,70L125,70L124,69L124,68L125,67L129,67L130,66L132,66ZM196,66L197,65L198,66L197,67ZM110,66L111,65L112,65L113,66L113,67L112,68L111,68L110,67ZM49,65L50,64L51,65L50,66ZM165,60L164,61L164,62L163,63L163,64L162,65L162,66L161,67L161,68L159,70L151,70L150,69L152,67L157,67L160,64L160,63L161,62L161,61L163,59L164,59ZM123,59L125,59L126,60L125,61L126,62L124,64L123,64L121,62L121,61ZM34,58L35,58L36,59L36,60L35,61L35,62L36,62L37,63L37,64L35,66L34,66L33,65L33,63L32,63L31,62L31,61ZM37,56L38,56L39,55L40,55L41,54L53,54L54,55L56,55L57,56L58,56L59,57L60,57L62,59L63,59L66,62L66,63L67,64L67,65L69,67L69,69L70,70L70,75L69,76L69,77L68,78L68,80L66,82L66,83L62,87L62,88L60,90L59,90L58,89L58,88L62,84L62,82L63,81L63,75L62,74L62,70L61,69L61,67L60,66L60,65L59,65L58,64L57,64L56,63L55,63L52,60L51,61L49,61L48,60L47,60L46,61L44,61L43,62L39,62L38,61L38,60L39,59L41,59L42,58L44,58L44,57L43,57L42,58L39,58L38,59L36,59L35,58ZM175,64L178,61L178,60L179,59L180,59L183,56L184,56L185,55L187,55L188,54L190,54L191,53L192,54L193,53L196,53L197,54L200,54L201,55L203,55L204,56L205,56L206,57L207,57L210,60L210,62L211,63L211,64L212,63L214,65L214,69L215,70L215,71L216,71L217,72L217,73L218,74L218,76L216,78L215,77L215,73L214,73L214,83L215,84L215,86L214,87L214,88L213,89L212,89L211,88L211,66L210,66L210,67L211,68L209,70L208,69L208,68L207,67L207,63L206,62L206,63L205,64L204,64L203,63L203,60L202,60L202,61L201,62L199,60L199,58L197,60L196,60L195,59L195,57L194,58L194,59L192,61L190,61L189,62L187,62L186,63L184,63L183,62L184,63L182,65L181,65L180,66L179,66L179,70L178,71L178,83L179,84L178,85L178,88L177,89L175,87L175,84L173,82L173,81L172,80L172,71L173,70L173,68L174,67L174,66L175,65ZM175,74L175,80L175,77L176,76L175,75ZM113,54L114,53L118,53L119,54L122,54L124,56L123,57L118,57L116,55L115,55L114,56L113,55ZM128,50L129,50L131,52L135,52L136,51L136,50L137,49L140,52L140,60L139,61L139,62L138,63L137,63L136,64L135,64L134,63L132,63L129,60L129,59L128,58L130,56L131,56L132,57L133,57L134,58L134,59L135,60L136,59L136,58L138,56L137,55L132,55L131,54L129,54L128,53L127,53L126,52ZM129,43L131,45L129,47L127,45ZM148,43L149,42L151,42L152,43L152,45L151,46L150,46L148,44ZM168,41L170,43L170,45L168,47L167,46L167,42ZM171,41L172,40L173,40L174,41L174,43L173,44L172,44L171,43ZM118,38L120,38L121,37L124,37L125,36L126,36L127,35L128,35L129,34L132,34L133,35L135,35L136,36L137,36L139,38L140,38L142,40L143,40L144,41L144,42L147,45L147,46L148,47L148,49L149,50L149,53L150,54L150,57L149,58L148,58L148,59L149,60L149,62L146,65L147,66L145,68L144,68L139,73L138,73L137,72L137,71L141,67L141,62L142,61L142,54L141,53L141,50L140,49L140,48L135,43L135,42L136,41L135,40L135,39L134,38L132,38L132,40L131,41L129,41L128,40L124,40L123,41L121,41L120,42L119,42L118,43L117,43L113,47L112,46L112,44ZM60,16L63,13L66,13L67,14L68,14L69,15L70,15L73,18L73,19L78,24L78,25L81,28L81,29L85,33L85,35L84,36L82,36L80,34L78,34L75,31L74,31L70,27L69,27L68,26L67,26L66,25L65,25L61,21L61,20L60,19Z"
	},
	specArrow: {
		w: 49,
		h: 52,
		paper: "",
		ink: "M0,1L0,2L3,5L3,6L11,14L11,15L16,20L16,21L19,24L19,25L18,26L18,27L15,30L15,31L12,34L12,35L10,37L10,38L7,41L7,42L3,46L3,47L0,50L1,51L27,51L30,48L30,47L33,44L33,43L37,39L37,38L40,35L40,34L43,31L43,30L47,26L47,25L48,24L46,22L46,21L41,16L41,15L37,11L37,10L34,7L34,6L30,2L30,1L29,0L5,0L4,1Z"
	},
	clock: {
		w: 81,
		h: 101,
		paper: "",
		ink: "M27,0L26,1L26,5L25,6L24,6L24,11L22,13L22,17L20,19L20,21L18,23L17,23L16,24L13,24L12,23L11,24L9,24L8,25L6,25L4,27L3,27L3,29L1,32L1,77L0,78L0,79L1,80L1,93L3,95L3,96L5,98L7,98L10,100L70,100L71,99L72,99L73,98L74,98L75,97L76,97L76,95L77,94L78,94L78,91L79,90L79,88L80,87L80,67L79,66L79,55L80,54L80,52L79,51L79,50L80,49L80,48L79,47L79,46L80,45L80,43L79,42L79,41L80,40L80,33L79,32L79,31L78,30L78,29L76,27L73,27L72,26L72,24L71,23L72,22L72,18L74,16L74,13L72,11L71,11L70,10L67,10L66,9L64,9L63,8L59,8L56,6L51,6L49,4L44,4L43,3L41,3L40,2L37,2L34,0ZM37,32L38,33L40,33L41,32L42,32L43,33L45,33L46,34L51,34L53,36L55,36L56,37L56,38L58,38L59,39L59,40L60,40L61,41L61,42L62,42L63,43L63,44L65,46L65,48L66,48L67,49L67,53L68,53L69,54L69,69L67,71L67,74L65,76L65,77L64,78L63,78L63,79L56,86L55,86L54,87L53,87L50,89L47,89L46,90L44,90L43,91L42,90L40,90L39,91L38,90L35,90L34,89L32,89L31,88L30,88L29,87L28,87L27,86L26,86L25,85L24,85L17,78L17,77L15,75L15,74L13,72L13,67L12,66L12,56L13,55L13,52L14,51L14,50L15,49L15,48L17,46L17,45L18,44L19,44L19,43L24,38L25,38L25,37L26,36L28,36L30,34L33,34L34,33L36,33ZM43,43L41,43L40,42L39,43L38,43L38,58L37,59L37,60L36,61L36,62L32,66L32,67L31,68L30,68L30,69L31,70L31,71L35,71L35,70L36,69L37,69L37,68L38,67L39,67L39,66L40,65L41,65L41,64L43,62ZM31,8L32,7L34,7L35,6L36,7L41,7L44,9L48,9L51,11L54,11L57,13L62,13L63,14L64,14L65,15L66,15L67,16L67,21L65,23L65,29L64,30L63,30L63,32L62,33L59,33L57,31L55,31L53,29L50,29L47,27L35,27L32,29L26,29L25,28L25,23L27,20L27,17L29,15L29,11L30,10L31,10Z"
	},
	arrow: {
		w: 499,
		h: 499,
		paper: "",
		ink: "M233,0L232,1L222,1L221,2L214,2L213,3L208,3L207,4L202,4L201,5L197,5L196,6L193,6L192,7L189,7L188,8L185,8L184,9L181,9L180,10L178,10L177,11L174,11L173,12L171,12L170,13L168,13L165,15L163,15L162,16L160,16L157,18L155,18L152,20L150,20L149,21L148,21L147,22L146,22L145,23L144,23L143,24L142,24L141,25L140,25L139,26L138,26L137,27L136,27L135,28L134,28L133,29L132,29L131,30L130,30L129,31L128,31L127,32L126,32L124,34L123,34L122,35L121,35L119,37L118,37L117,38L116,38L114,40L113,40L111,42L110,42L108,44L107,44L104,47L103,47L101,49L100,49L97,52L96,52L92,56L91,56L85,62L84,62L62,84L62,85L56,91L56,92L52,96L52,97L49,100L49,101L47,103L47,104L44,107L44,108L42,110L42,111L40,113L40,114L38,116L38,117L37,118L37,119L35,121L35,122L34,123L34,124L32,126L32,127L31,128L31,129L30,130L30,131L29,132L29,133L28,134L28,135L27,136L27,137L26,138L26,139L25,140L25,141L24,142L24,143L23,144L23,145L22,146L22,147L20,150L20,152L19,153L19,154L18,155L18,157L16,160L16,162L15,163L15,165L13,168L13,170L12,171L12,173L11,174L11,177L10,178L10,180L9,181L9,184L8,185L8,188L7,189L7,192L6,193L6,196L5,197L5,201L4,202L4,207L3,208L3,213L2,214L2,221L1,222L1,232L0,233L0,265L1,266L1,276L2,277L2,284L3,285L3,290L4,291L4,296L5,297L5,301L6,302L6,305L7,306L7,309L8,310L8,313L9,314L9,317L10,318L10,320L11,321L11,324L12,325L12,327L13,328L13,330L15,333L15,335L16,336L16,338L18,341L18,343L20,346L20,348L21,349L21,350L22,351L22,352L23,353L23,354L24,355L24,356L25,357L25,358L26,359L26,360L27,361L27,362L28,363L28,364L29,365L29,366L30,367L30,368L31,369L31,370L32,371L32,372L34,374L34,375L35,376L35,377L37,379L37,380L38,381L38,382L40,384L40,385L42,387L42,388L44,390L44,391L47,394L47,395L49,397L49,398L52,401L52,402L56,406L56,407L62,413L62,414L84,436L85,436L91,442L92,442L96,446L97,446L100,449L101,449L103,451L104,451L107,454L108,454L110,456L111,456L113,458L114,458L116,460L117,460L118,461L119,461L121,463L122,463L123,464L124,464L126,466L127,466L128,467L129,467L130,468L131,468L132,469L133,469L134,470L135,470L136,471L137,471L138,472L139,472L140,473L141,473L142,474L143,474L144,475L145,475L146,476L147,476L150,478L152,478L153,479L154,479L155,480L157,480L160,482L162,482L163,483L165,483L168,485L170,485L171,486L173,486L174,487L177,487L178,488L180,488L181,489L184,489L185,490L188,490L189,491L192,491L193,492L196,492L197,493L201,493L202,494L207,494L208,495L213,495L214,496L221,496L222,497L232,497L233,498L265,498L266,497L276,497L277,496L284,496L285,495L290,495L291,494L296,494L297,493L301,493L302,492L305,492L306,491L309,491L310,490L313,490L314,489L317,489L318,488L320,488L321,487L324,487L325,486L327,486L328,485L330,485L333,483L335,483L336,482L338,482L341,480L343,480L346,478L348,478L349,477L350,477L351,476L352,476L353,475L354,475L355,474L356,474L357,473L358,473L359,472L360,472L361,471L362,471L363,470L364,470L365,469L366,469L367,468L368,468L369,467L370,467L371,466L372,466L374,464L375,464L376,463L377,463L379,461L380,461L381,460L382,460L384,458L385,458L387,456L388,456L390,454L391,454L394,451L395,451L397,449L398,449L401,446L402,446L406,442L407,442L413,436L414,436L436,414L436,413L442,407L442,406L446,402L446,401L449,398L449,397L451,395L451,394L454,391L454,390L456,388L456,387L458,385L458,384L460,382L460,381L461,380L461,379L463,377L463,376L464,375L464,374L466,372L466,371L467,370L467,369L468,368L468,367L469,366L469,365L470,364L470,363L471,362L471,361L472,360L472,359L473,358L473,357L474,356L474,355L475,354L475,353L476,352L476,351L478,348L478,346L479,345L479,344L480,343L480,341L482,338L482,336L483,335L483,333L485,330L485,328L486,327L486,325L487,324L487,321L488,320L488,318L489,317L489,314L490,313L490,310L491,309L491,306L492,305L492,302L493,301L493,297L494,296L494,291L495,290L495,285L496,284L496,277L497,276L497,266L498,265L498,233L497,232L497,222L496,221L496,214L495,213L495,208L494,207L494,202L493,201L493,197L492,196L492,193L491,192L491,189L490,188L490,185L489,184L489,181L488,180L488,178L487,177L487,174L486,173L486,171L485,170L485,168L483,165L483,163L482,162L482,160L480,157L480,155L478,152L478,150L477,149L477,148L476,147L476,146L475,145L475,144L474,143L474,142L473,141L473,140L472,139L472,138L471,137L471,136L470,135L470,134L469,133L469,132L468,131L468,130L467,129L467,128L466,127L466,126L464,124L464,123L463,122L463,121L461,119L461,118L460,117L460,116L458,114L458,113L456,111L456,110L454,108L454,107L451,104L451,103L449,101L449,100L446,97L446,96L442,92L442,91L436,85L436,84L414,62L413,62L407,56L406,56L402,52L401,52L398,49L397,49L395,47L394,47L391,44L390,44L388,42L387,42L385,40L384,40L382,38L381,38L380,37L379,37L377,35L376,35L375,34L374,34L372,32L371,32L370,31L369,31L368,30L367,30L366,29L365,29L364,28L363,28L362,27L361,27L360,26L359,26L358,25L357,25L356,24L355,24L354,23L353,23L352,22L351,22L348,20L346,20L345,19L344,19L343,18L341,18L338,16L336,16L335,15L333,15L330,13L328,13L327,12L325,12L324,11L321,11L320,10L318,10L317,9L314,9L313,8L310,8L309,7L306,7L305,6L302,6L301,5L297,5L296,4L291,4L290,3L285,3L284,2L277,2L276,1L266,1L265,0ZM233,45L264,45L265,46L274,46L275,47L281,47L282,48L286,48L287,49L291,49L292,50L296,50L297,51L300,51L301,52L303,52L304,53L307,53L308,54L310,54L311,55L313,55L314,56L316,56L317,57L319,57L320,58L321,58L322,59L324,59L327,61L329,61L330,62L331,62L332,63L333,63L334,64L335,64L336,65L337,65L338,66L339,66L340,67L341,67L342,68L343,68L344,69L345,69L346,70L347,70L348,71L349,71L351,73L352,73L353,74L354,74L356,76L357,76L358,77L359,77L361,79L362,79L365,82L366,82L368,84L369,84L372,87L373,87L377,91L378,91L385,98L386,98L399,111L399,112L406,119L406,120L410,124L410,125L413,128L413,129L416,132L416,133L418,135L418,136L420,138L420,139L422,141L422,142L423,143L423,144L425,146L425,147L426,148L426,149L427,150L427,151L429,153L429,154L430,155L430,156L431,157L431,158L432,159L432,160L434,163L434,165L435,166L435,167L437,170L437,172L439,175L439,177L441,180L441,182L442,183L442,185L443,186L443,188L444,189L444,192L445,193L445,195L446,196L446,199L447,200L447,203L448,204L448,208L449,209L449,213L450,214L450,219L451,220L451,227L452,228L452,242L453,243L453,255L452,256L452,270L451,271L451,278L450,279L450,284L449,285L449,289L448,290L448,294L447,295L447,298L446,299L446,302L445,303L445,305L444,306L444,309L443,310L443,312L442,313L442,315L441,316L441,318L439,321L439,323L437,326L437,328L436,329L436,330L434,333L434,335L433,336L433,337L432,338L432,339L431,340L431,341L430,342L430,343L429,344L429,345L427,347L427,348L426,349L426,350L425,351L425,352L423,354L423,355L422,356L422,357L420,359L420,360L418,362L418,363L416,365L416,366L413,369L413,370L410,373L410,374L406,378L406,379L399,386L399,387L386,400L385,400L378,407L377,407L373,411L372,411L369,414L368,414L366,416L365,416L362,419L361,419L359,421L358,421L357,422L356,422L354,424L353,424L352,425L351,425L349,427L348,427L347,428L346,428L345,429L344,429L343,430L342,430L341,431L340,431L339,432L338,432L337,433L336,433L335,434L334,434L333,435L332,435L329,437L327,437L324,439L322,439L319,441L317,441L316,442L314,442L313,443L311,443L310,444L308,444L307,445L304,445L303,446L301,446L300,447L297,447L296,448L292,448L291,449L287,449L286,450L282,450L281,451L275,451L274,452L265,452L264,453L233,453L232,452L223,452L222,451L216,451L215,450L211,450L210,449L206,449L205,448L201,448L200,447L197,447L196,446L194,446L193,445L190,445L189,444L187,444L186,443L184,443L183,442L181,442L180,441L178,441L177,440L176,440L175,439L173,439L170,437L168,437L167,436L166,436L165,435L164,435L163,434L162,434L161,433L160,433L159,432L158,432L157,431L156,431L155,430L154,430L153,429L152,429L151,428L150,428L149,427L148,427L146,425L145,425L144,424L143,424L141,422L140,422L139,421L138,421L136,419L135,419L132,416L131,416L129,414L128,414L125,411L124,411L120,407L119,407L112,400L111,400L98,387L98,386L91,379L91,378L87,374L87,373L84,370L84,369L81,366L81,365L79,363L79,362L77,360L77,359L75,357L75,356L74,355L74,354L72,352L72,351L71,350L71,349L70,348L70,347L68,345L68,344L67,343L67,342L66,341L66,340L65,339L65,338L63,335L63,333L62,332L62,331L60,328L60,326L58,323L58,321L56,318L56,316L55,315L55,313L54,312L54,310L53,309L53,306L52,305L52,303L51,302L51,299L50,298L50,295L49,294L49,290L48,289L48,285L47,284L47,279L46,278L46,271L45,270L45,256L44,255L44,243L45,242L45,228L46,227L46,220L47,219L47,214L48,213L48,209L49,208L49,204L50,203L50,200L51,199L51,196L52,195L52,193L53,192L53,189L54,188L54,186L55,185L55,183L56,182L56,180L58,177L58,175L60,172L60,170L61,169L61,168L63,165L63,163L64,162L64,161L65,160L65,159L66,158L66,157L67,156L67,155L68,154L68,153L70,151L70,150L71,149L71,148L72,147L72,146L74,144L74,143L75,142L75,141L77,139L77,138L79,136L79,135L81,133L81,132L84,129L84,128L87,125L87,124L91,120L91,119L98,112L98,111L111,98L112,98L119,91L120,91L124,87L125,87L128,84L129,84L131,82L132,82L135,79L136,79L138,77L139,77L140,76L141,76L143,74L144,74L145,73L146,73L148,71L149,71L150,70L151,70L152,69L153,69L154,68L155,68L156,67L157,67L158,66L159,66L160,65L161,65L162,64L163,64L164,63L165,63L168,61L170,61L173,59L175,59L178,57L180,57L181,56L183,56L184,55L186,55L187,54L189,54L190,53L193,53L194,52L196,52L197,51L200,51L201,50L205,50L206,49L210,49L211,48L215,48L216,47L222,47L223,46L232,46ZM235,82L234,83L226,83L225,84L220,84L219,85L215,85L214,86L210,86L209,87L206,87L205,88L203,88L202,89L199,89L198,90L196,90L195,91L193,91L190,93L188,93L185,95L183,95L182,96L181,96L180,97L179,97L178,98L177,98L176,99L175,99L174,100L173,100L172,101L171,101L170,102L169,102L168,103L167,103L166,104L165,104L163,106L162,106L160,108L159,108L158,109L157,109L155,111L154,111L151,114L150,114L147,117L146,117L142,121L141,121L121,141L121,142L117,146L117,147L114,150L114,151L112,153L112,154L110,156L110,157L108,159L108,160L106,162L106,163L105,164L105,165L104,166L104,167L102,169L102,170L101,171L101,172L100,173L100,174L99,175L99,176L97,179L97,181L96,182L96,183L94,186L94,188L92,191L92,193L91,194L91,196L90,197L90,199L89,200L89,203L88,204L88,207L87,208L87,211L86,212L86,216L85,217L85,221L84,222L84,229L83,230L83,242L82,243L82,254L83,255L83,267L84,268L84,275L85,276L85,280L86,281L86,285L87,286L87,289L88,290L88,293L89,294L89,297L90,298L90,300L91,301L91,303L92,304L92,306L94,309L94,311L95,312L95,313L97,316L97,318L98,319L98,320L99,321L99,322L100,323L100,324L101,325L101,326L102,327L102,328L104,330L104,331L105,332L105,333L106,334L106,335L108,337L108,338L110,340L110,341L112,343L112,344L114,346L114,347L117,350L117,351L121,355L121,356L141,376L142,376L146,380L147,380L150,383L151,383L154,386L155,386L157,388L158,388L159,389L160,389L162,391L163,391L165,393L166,393L167,394L168,394L169,395L170,395L171,396L172,396L173,397L174,397L175,398L176,398L177,399L178,399L179,400L180,400L183,402L185,402L188,404L190,404L193,406L195,406L196,407L198,407L199,408L202,408L203,409L205,409L206,410L209,410L210,411L214,411L215,412L219,412L220,413L225,413L226,414L234,414L235,415L263,415L264,414L272,414L273,413L278,413L279,412L283,412L284,411L288,411L289,410L292,410L293,409L295,409L296,408L299,408L300,407L302,407L303,406L305,406L308,404L310,404L313,402L315,402L316,401L317,401L318,400L319,400L320,399L321,399L322,398L323,398L324,397L325,397L326,396L327,396L328,395L329,395L330,394L331,394L332,393L333,393L335,391L336,391L338,389L339,389L340,388L341,388L343,386L344,386L347,383L348,383L351,380L352,380L356,376L357,376L377,356L377,355L381,351L381,350L384,347L384,346L386,344L386,343L388,341L388,340L390,338L390,337L392,335L392,334L393,333L393,332L394,331L394,330L396,328L396,327L397,326L397,325L398,324L398,323L399,322L399,321L401,318L401,316L402,315L402,314L404,311L404,309L406,306L406,304L407,303L407,301L408,300L408,298L409,297L409,294L410,293L410,290L411,289L411,286L412,285L412,281L413,280L413,276L414,275L414,268L415,267L415,255L416,254L416,243L415,242L415,230L414,229L414,222L413,221L413,217L412,216L412,212L411,211L411,208L410,207L410,204L409,203L409,200L408,199L408,197L407,196L407,194L406,193L406,191L404,188L404,186L403,185L403,184L401,181L401,179L400,178L400,177L399,176L399,175L398,174L398,173L397,172L397,171L396,170L396,169L394,167L394,166L393,165L393,164L392,163L392,162L390,160L390,159L388,157L388,156L386,154L386,153L384,151L384,150L381,147L381,146L377,142L377,141L357,121L356,121L352,117L351,117L348,114L347,114L344,111L343,111L341,109L340,109L339,108L338,108L336,106L335,106L333,104L332,104L331,103L330,103L329,102L328,102L327,101L326,101L325,100L324,100L323,99L322,99L321,98L320,98L319,97L318,97L315,95L313,95L310,93L308,93L305,91L303,91L302,90L300,90L299,89L296,89L295,88L293,88L292,87L289,87L288,86L284,86L283,85L279,85L278,84L273,84L272,83L264,83L263,82ZM248,112L249,112L373,236L372,237L311,237L311,360L310,361L187,361L186,360L186,237L125,237L124,236Z"
	},
	finish: {
		w: 116,
		h: 143,
		paper: "",
		ink: "M74,0L69,0L68,1L66,1L65,2L62,2L61,3L59,3L58,4L56,4L55,5L52,5L51,6L48,6L47,7L44,7L43,8L41,8L40,9L37,9L36,10L34,10L33,11L30,11L29,12L26,12L25,13L22,13L21,14L19,14L18,15L16,15L15,16L13,16L12,17L11,17L10,18L10,19L8,22L8,24L7,25L7,36L5,38L5,39L2,42L2,43L0,46L0,126L1,127L1,129L2,130L2,131L3,132L3,133L5,135L5,136L7,138L8,138L10,140L11,140L14,142L99,142L100,141L101,141L102,140L104,140L106,138L107,138L111,134L111,133L113,131L113,130L114,129L114,127L115,126L115,48L114,47L114,46L113,45L113,44L112,43L112,42L109,39L109,38L106,35L105,35L102,33L99,33L98,32L96,32L95,31L94,31L91,28L90,28L87,25L87,24L85,22L85,21L84,20L84,19L82,16L82,12L81,11L81,9L80,8L80,6L79,5L79,4L78,3L78,2L77,2ZM84,80L85,80L86,81L87,81L90,83L90,84L86,88L86,89L85,90L84,90L82,88L82,87L81,86L81,85L82,84L82,83ZM68,72L69,73L70,73L71,74L72,74L75,76L75,78L74,79L74,80L73,81L73,82L71,84L70,84L69,83L68,83L67,82L66,82L64,80L64,79L65,78L65,77L66,76L66,75ZM80,68L81,68L82,69L83,69L84,70L85,70L87,72L87,73L86,74L86,76L84,79L82,79L81,78L79,78L76,76L76,75L77,74L77,73L78,72L78,71ZM92,64L93,64L94,65L95,65L97,67L95,70L95,72L93,74L92,74L91,73L89,73L88,72L88,70L89,69L89,68L90,67L90,66ZM64,60L65,61L66,61L67,62L68,62L71,64L71,66L70,67L70,68L69,69L69,70L67,72L64,70L62,70L60,68L60,67L61,66L61,65L62,64L62,63ZM76,56L77,57L78,57L79,58L80,58L83,60L83,61L82,62L82,63L81,64L81,65L79,68L78,67L77,67L76,66L75,66L72,64L72,62L73,61L73,60L74,59L74,58ZM88,51L91,53L93,53L95,55L95,57L94,58L94,59L93,60L93,61L91,63L90,63L89,62L87,62L84,60L84,58L85,57L85,56L86,55L86,54ZM76,38L77,39L77,41L78,42L78,47L79,48L79,49L78,50L78,51L77,52L77,53L76,54L76,55L75,56L74,56L73,55L72,55L71,54L70,54L68,52L68,50L69,49L69,48L71,45L70,44L70,43L69,42L69,41L72,39L74,39L75,38ZM41,39L42,38L44,38L45,37L49,37L50,38L50,40L51,41L51,43L52,44L50,46L48,46L47,47L44,47L42,45L42,42L41,41ZM55,26L56,27L56,29L57,30L57,32L58,33L56,35L54,35L53,36L51,36L50,37L49,36L49,34L48,33L48,31L47,30L47,28L48,27L51,27L52,26ZM24,25L27,25L28,26L28,28L29,29L29,32L33,32L34,31L37,31L39,33L39,35L40,36L40,39L39,40L36,40L35,41L33,41L32,42L32,43L33,44L33,47L35,50L36,49L38,49L39,48L42,48L43,49L43,50L44,51L44,53L45,54L45,55L43,57L40,57L39,58L37,58L37,61L38,62L38,65L39,66L39,68L40,69L40,72L41,73L41,74L42,73L42,71L43,70L43,68L45,65L45,63L46,62L46,61L47,60L47,59L49,56L49,54L50,53L50,52L52,49L52,46L55,43L55,42L56,41L56,40L58,38L59,38L59,36L58,35L60,33L62,33L63,32L66,32L67,33L67,34L68,35L68,38L69,39L69,40L68,41L62,41L62,42L61,43L61,44L59,47L59,48L60,49L61,49L62,50L63,50L66,52L66,54L64,57L64,59L63,60L62,60L59,58L57,58L56,57L55,57L54,58L54,59L52,62L52,65L53,65L54,66L55,66L56,67L57,67L59,69L58,70L58,71L57,72L57,73L55,76L54,75L53,75L50,73L47,73L47,74L46,75L46,76L44,79L44,83L45,84L45,86L46,87L46,89L47,90L47,92L48,93L48,95L49,96L49,98L50,99L50,101L51,102L51,104L98,104L99,105L100,105L102,107L102,108L103,109L103,123L102,124L102,125L100,127L99,127L98,128L17,128L13,124L13,108L17,104L29,104L29,103L30,102L30,100L31,99L31,98L33,95L33,93L34,92L34,91L36,88L36,86L38,83L38,78L37,77L37,75L36,74L36,72L35,71L35,69L34,68L34,66L33,65L33,63L32,62L32,60L30,57L30,55L29,54L29,52L28,51L28,48L27,47L27,45L26,44L26,42L25,41L25,38L24,37L24,35L23,34L23,31L22,30L22,27ZM82,110L82,111L83,111L84,112L84,120L82,122L87,122L85,120L85,117L86,116L92,116L93,117L93,120L91,122L96,122L96,121L95,120L95,116L94,115L94,114L95,113L95,112L96,111L96,110L91,110L93,112L93,114L92,115L86,115L85,114L85,112L86,111L87,111L87,110ZM69,111L69,115L70,116L72,116L73,117L75,117L77,119L77,120L76,121L75,121L74,122L73,122L72,121L71,121L69,119L68,119L68,121L69,122L77,122L79,120L79,117L76,115L74,115L73,114L72,114L71,113L71,112L74,110L75,111L76,111L78,113L78,111L77,110L71,110L70,111ZM59,110L59,111L60,111L61,112L61,120L59,122L64,122L64,121L63,120L63,112L64,111L64,110ZM42,110L42,111L43,111L44,112L44,120L43,121L42,121L42,122L46,122L46,121L45,121L44,120L44,115L45,114L46,114L51,119L51,120L53,122L54,122L54,118L55,117L55,112L56,111L56,110L52,110L54,112L54,117L53,118L52,118L51,117L51,116L47,112L48,111L48,110ZM34,110L34,111L36,113L35,114L35,115L36,116L36,120L34,122L39,122L37,120L37,112L38,111L39,111L39,110ZM30,110L19,110L19,111L20,111L21,112L21,120L20,121L19,121L19,122L24,122L24,121L23,120L23,117L24,116L26,116L27,117L28,117L28,114L27,114L26,115L24,115L22,113L22,112L24,110L25,111L28,111L30,113ZM41,87L39,90L39,92L38,93L38,95L36,98L36,100L35,101L35,102L34,103L34,104L46,104L46,103L45,102L45,99L44,98L44,96L43,95L43,93L42,92L42,90L41,89ZM71,21L73,24L73,26L74,27L74,29L71,31L69,31L68,32L67,32L66,31L66,28L65,27L65,25L64,24L66,22L69,22L70,21ZM44,19L45,20L45,22L46,23L46,26L47,27L45,29L42,29L41,30L39,30L37,27L37,24L36,23L36,22L37,21L39,21L40,20L42,20L43,19ZM53,17L56,15L58,15L59,14L61,14L62,15L62,17L63,18L63,20L64,21L64,23L63,24L60,24L59,25L56,25L55,24L55,22L54,21L54,18Z"
	},
	brand0: {
		w: 74,
		h: 71,
		paper: "",
		ink: "M1,0L2,0L3,1L2,2L0,2L1,2L2,3L2,8L3,9L2,10L3,11L3,37L4,38L4,43L3,44L4,44L6,46L7,46L8,47L8,49L9,50L11,50L12,51L12,53L13,54L14,53L16,55L15,56L16,55L23,62L24,62L26,64L26,66L27,65L29,67L28,68L31,68L32,69L36,69L37,70L37,69L38,68L41,68L42,67L43,67L44,68L45,68L45,67L46,66L49,66L49,65L50,64L51,64L52,63L53,63L55,61L56,62L56,61L62,55L62,54L65,51L65,50L66,49L67,50L66,49L67,48L67,47L68,46L68,45L69,44L69,43L70,42L70,41L72,39L71,38L71,35L72,34L73,34L72,33L72,29L73,28L72,28L70,26L70,24L69,23L67,23L66,22L66,20L65,19L64,20L61,17L62,16L61,15L60,16L58,14L58,13L57,13L52,8L52,7L50,7L49,6L50,5L49,4L47,4L46,3L45,3L44,2L43,2L42,1L41,1L40,2L39,2L40,3L40,4L41,5L41,6L40,7L40,9L41,10L40,11L40,16L41,17L41,18L40,19L41,20L40,21L40,23L41,24L39,26L39,27L38,28L35,28L34,29L33,29L32,28L24,28L21,25L22,24L21,23L21,21L20,20L20,19L21,18L22,19L21,18L24,15L32,15L33,14L34,14L34,13L33,12L33,10L32,9L31,9L29,7L27,7L26,6L26,5L25,5L24,4L23,5L22,4L22,3L21,3L20,2L20,1L17,1L16,0ZM12,53L13,52L14,53L13,54ZM20,24L21,23L22,24L21,25Z"
	},
	brand1: {
		w: 56,
		h: 75,
		paper: "",
		ink: "M1,3L0,4L0,7L1,8L1,17L2,18L2,26L3,27L3,37L4,38L4,47L5,48L5,56L6,57L6,63L7,64L7,65L9,67L10,67L11,68L12,68L13,69L14,69L15,70L16,70L17,71L18,71L19,72L20,72L21,73L24,73L25,74L30,74L31,73L34,73L35,72L36,72L37,71L38,71L39,70L40,70L41,69L42,69L43,68L45,68L49,64L49,58L50,57L50,48L51,47L51,38L52,37L52,28L53,27L53,19L54,18L54,9L55,8L55,4L54,3L52,3L51,2L46,2L45,1L36,1L35,0L21,0L20,1L11,1L10,2L5,2L4,3Z"
	},
	brand2: {
		w: 68,
		h: 77,
		paper: "",
		ink: "M32,0L32,1L31,2L30,2L29,3L28,3L27,4L29,4L30,5L31,5L32,6L32,12L31,13L24,13L23,12L23,11L20,11L19,10L21,8L22,8L23,7L23,5L21,5L19,7L15,7L12,10L12,11L11,12L12,13L10,15L10,17L9,18L9,19L8,20L8,23L7,24L7,25L3,29L2,29L2,30L0,32L0,34L1,35L0,36L2,38L2,40L3,41L3,44L4,45L4,46L6,48L6,49L10,49L13,52L13,51L12,50L14,48L15,48L16,49L16,52L15,53L15,54L13,56L12,55L12,56L11,57L11,59L13,61L12,62L12,64L13,65L14,65L15,66L15,67L14,68L14,69L15,70L18,67L19,67L21,69L19,71L17,71L16,72L20,76L25,76L26,75L31,75L34,72L37,72L37,71L36,70L35,70L34,69L35,68L38,68L39,67L40,67L41,68L41,69L40,70L39,70L39,71L40,71L41,70L42,70L43,69L44,69L47,66L47,65L48,64L50,64L51,63L51,62L54,59L54,56L55,55L56,56L57,55L57,54L58,53L58,51L59,50L59,48L60,47L60,39L61,38L63,38L64,39L65,39L66,38L67,38L67,34L66,33L66,29L65,28L65,25L64,25L64,26L63,27L62,26L62,20L60,18L60,17L54,11L51,11L50,12L49,11L49,10L50,9L51,9L50,8L49,8L48,9L47,9L46,8L47,7L46,8L45,8L44,7L43,7L42,6L43,5L44,5L42,5L41,4L34,4L33,5L30,5L29,4L29,3L30,2L31,2L32,1L35,1L33,1ZM23,75L24,74L25,75L24,76ZM19,75L20,74L21,75L20,76ZM22,70L24,72L24,73L22,75L21,75L20,74L20,72ZM33,69L34,70L34,71L32,73L31,73L30,72L30,71L32,69ZM41,67L42,66L44,66L45,67L44,68L42,68ZM15,60L16,61L16,63L15,64L14,63L14,61ZM56,47L58,49L58,51L57,52L56,52L55,51L56,50L55,49L55,48ZM58,45L59,44L60,45L59,46ZM5,46L7,44L8,44L10,46L9,47L6,47ZM55,43L56,44L56,47L55,48L54,47L54,44ZM13,45L13,44L14,43L15,43L16,44L14,46ZM55,42L56,41L57,41L58,42L58,43L57,44L56,44L55,43ZM63,36L64,35L65,36L65,37L64,38L63,37ZM4,34L6,34L7,35L6,36L6,37L7,38L7,43L6,44L5,43L5,42L4,41L4,39L3,38L3,35ZM64,28L65,29L64,30L64,31L63,32L62,31L62,29L63,28ZM13,28L14,28L15,29L15,30L16,31L16,41L14,43L13,42L12,42L11,41L11,39L12,38L12,37L10,35L10,34L9,33L10,32L10,31ZM6,28L8,30L8,31L7,32L6,32L6,33L5,34L4,34L3,33L3,31L4,30L4,29L5,28ZM6,27L7,26L8,27L7,28ZM12,17L13,18L13,20L12,21L11,21L10,20L10,19ZM58,16L59,17L59,19L58,20L57,20L56,21L55,20L55,19L56,18L56,17L57,16ZM18,15L19,15L20,16L21,15L22,15L23,16L23,17L24,18L24,28L23,29L18,29L17,28L17,21L16,20L16,18L17,17L17,16ZM54,15L55,14L56,15L55,16ZM15,12L16,13L16,17L15,18L14,18L13,17L13,15L14,14L14,13ZM48,12L49,11L50,12L49,13ZM39,12L40,11L41,11L42,12L41,13L40,13ZM12,11L13,10L14,11L13,12Z"
	},
	brand3: {
		w: 76,
		h: 67,
		paper: "",
		ink: "M37,0L36,1L36,3L35,4L35,7L34,8L34,10L33,11L33,14L32,15L32,17L31,18L31,21L30,22L30,25L29,26L29,28L28,29L28,32L27,33L27,35L26,36L26,37L11,52L11,53L0,64L0,65L1,65L2,66L3,65L6,65L7,64L10,64L11,63L14,63L15,62L18,62L19,61L22,61L23,60L25,60L26,59L29,59L30,58L33,58L34,57L41,57L42,58L45,58L46,59L49,59L50,60L52,60L53,61L56,61L57,62L60,62L61,63L64,63L65,64L68,64L69,65L72,65L73,66L75,64L62,51L62,50L48,36L48,33L47,32L47,30L46,29L46,26L45,25L45,23L44,22L44,19L43,18L43,15L42,14L42,12L41,11L41,8L40,7L40,4L39,3L39,1L38,1Z"
	},
	brand4: {
		w: 81,
		h: 55,
		paper: "",
		ink: "M2,17L2,18L1,19L1,21L0,22L0,33L1,34L1,35L2,36L2,37L3,38L3,39L9,45L10,45L12,47L13,47L14,48L15,48L16,49L17,49L18,50L20,50L21,51L23,51L24,52L26,52L27,53L33,53L34,54L46,54L47,53L52,53L53,52L56,52L57,51L59,51L60,50L61,50L62,49L63,49L64,48L65,48L66,47L67,47L69,45L70,45L76,39L76,38L78,36L78,34L79,33L79,31L80,30L80,24L79,23L79,21L78,20L78,19L77,18L77,17L76,16L76,15L71,10L70,10L68,8L67,8L65,6L64,6L63,5L61,5L60,4L59,4L58,3L56,3L55,2L52,2L51,1L40,1L39,0L38,1L29,1L28,2L25,2L24,3L21,3L20,4L19,4L18,5L17,5L16,6L15,6L14,7L13,7L12,8L11,8L8,11L7,11L4,14L4,15Z"
	}
}, it = [
	"#7dbf65",
	"#e03c2b",
	"#9371a4",
	"#efca55",
	"#405da4"
];
function X({ name: e, color: t = "#202121", ...n }) {
	let r = rt[e];
	return /* @__PURE__ */ p("svg", {
		viewBox: `0 0 ${r.w} ${r.h}`,
		"aria-hidden": !0,
		...n,
		children: [r.paper && /* @__PURE__ */ f("path", {
			d: r.paper,
			fill: "#fbfaf3",
			fillRule: "evenodd"
		}), /* @__PURE__ */ f("path", {
			d: r.ink,
			fill: t,
			fillRule: "evenodd"
		})]
	});
}
function at({ kind: e, x: t = 0, y: n = 0, size: r = 24 }) {
	return /* @__PURE__ */ f(X, {
		name: e,
		x: t,
		y: n,
		width: r,
		height: r * .65,
		color: j[e]
	});
}
function ot({ brand: e }) {
	return /* @__PURE__ */ f(X, {
		name: `brand${e}`,
		color: it[e],
		className: "hc-brand"
	});
}
//#endregion
//#region src/games/horselesscarriage/board.tsx
function st({ name: e, className: t, children: n }) {
	let { ref: r, hidden: i } = m(e);
	return /* @__PURE__ */ f("span", {
		ref: r,
		className: t,
		style: { visibility: i ? "hidden" : void 0 },
		children: n
	});
}
function ct() {
	return /* @__PURE__ */ p("svg", {
		viewBox: "0 0 112 137",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ f("rect", {
				x: "1",
				y: "1",
				width: "110",
				height: "135",
				rx: "3",
				fill: "#53696b",
				stroke: "#203536"
			}),
			/* @__PURE__ */ f("path", {
				d: "M8 8H104V129H8Z",
				fill: "none",
				stroke: "#bdc7ba",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ f("text", {
				x: "56",
				y: "61",
				textAnchor: "middle",
				fill: "#efeede",
				fontSize: "10",
				fontFamily: "Georgia",
				children: "HORSELESS"
			}),
			/* @__PURE__ */ f("text", {
				x: "56",
				y: "77",
				textAnchor: "middle",
				fill: "#efeede",
				fontSize: "10",
				fontFamily: "Georgia",
				children: "CARRIAGE"
			})
		]
	});
}
function Z({ name: e, children: t }) {
	let n = h(), r = a(null), { hidden: o } = m(e);
	return i(() => (n?.registerProbe(e, () => {
		let e = r.current;
		if (!e?.isConnected) return null;
		let t = e.getBoundingClientRect();
		return {
			x: t.x,
			y: t.y,
			w: t.width,
			h: t.height
		};
	}), () => n?.registerProbe(e, null)), [n, e]), /* @__PURE__ */ f("g", {
		ref: r,
		style: { visibility: o ? "hidden" : void 0 },
		children: t
	});
}
function lt({ id: e }) {
	return /* @__PURE__ */ p("defs", { children: [
		/* @__PURE__ */ p("pattern", {
			id: `${e}A`,
			width: ".45",
			height: ".6",
			patternUnits: "userSpaceOnUse",
			children: [/* @__PURE__ */ f("rect", {
				width: ".45",
				height: ".6",
				fill: "#eeeee6"
			}), /* @__PURE__ */ f("path", {
				d: "M0 0L.45 .6M.45 0L0 .6",
				stroke: "#afb2ab",
				strokeWidth: ".014"
			})]
		}),
		/* @__PURE__ */ p("pattern", {
			id: `${e}B`,
			width: ".16",
			height: ".16",
			patternUnits: "userSpaceOnUse",
			children: [/* @__PURE__ */ f("rect", {
				width: ".16",
				height: ".16",
				fill: "#c9c9c5"
			}), /* @__PURE__ */ f("path", {
				d: "M0 .04H.16M0 .09H.16",
				stroke: "#919491",
				strokeWidth: ".012"
			})]
		}),
		/* @__PURE__ */ p("pattern", {
			id: `${e}C`,
			width: ".32",
			height: ".32",
			patternUnits: "userSpaceOnUse",
			children: [/* @__PURE__ */ f("rect", {
				width: ".32",
				height: ".32",
				fill: "#aaadac"
			}), /* @__PURE__ */ f("path", {
				d: "M-.16 0L.32 .48M0-.16L.48 .32",
				stroke: "#646b6a",
				strokeWidth: ".02"
			})]
		}),
		/* @__PURE__ */ p("pattern", {
			id: `${e}D`,
			width: ".27",
			height: ".27",
			patternUnits: "userSpaceOnUse",
			children: [/* @__PURE__ */ f("rect", {
				width: ".27",
				height: ".27",
				fill: "#777f7e"
			}), /* @__PURE__ */ f("path", {
				d: "M0 0L.27 .27M.27 0L0 .27",
				stroke: "#333e3e",
				strokeWidth: ".018"
			})]
		})
	] });
}
function ut({ specs: e }) {
	let t = s();
	return /* @__PURE__ */ f("span", {
		className: "hc-specs",
		children: Object.entries(e).map(([e, n]) => /* @__PURE__ */ p("span", {
			style: { background: A[e] },
			title: t(ae[e]),
			children: [t(ae[e]), /* @__PURE__ */ f("b", { children: n })]
		}, e))
	});
}
function dt({ tile: e, brand: t }) {
	let n = s(), i = z(e), a = r().replaceAll(":", ""), [o, c] = k[e.item], l = F(e.item) ? ie[t][Number(e.item.slice(-1))] : n(oe[e.item]), u = N(e.item) ? D[e.item].step : e.item === "spec" && e.dim && e.level ? D[E[e.dim][e.level - 1]].step : null, m = P(e.item) ? "#dddcd7" : u === "D" ? "#55595a" : u === "C" ? "#8c9394" : u === "B" ? "#b7b9b6" : u === "A" ? "#eeeae0" : F(e.item) ? "#cbcba8" : "#9aa8ac";
	return /* @__PURE__ */ p("g", { children: [
		/* @__PURE__ */ f("title", { children: l }),
		/* @__PURE__ */ f(lt, { id: a }),
		/* @__PURE__ */ f("rect", {
			x: i.x + .04,
			y: i.y + .04,
			width: i.w - .08,
			height: i.h - .08,
			fill: m,
			stroke: "#171b1d",
			strokeWidth: ".07"
		}),
		/* @__PURE__ */ p("g", {
			transform: `translate(${i.x + i.w / 2} ${i.y + i.h / 2}) rotate(${e.r * 90}) translate(${-o / 2} ${-c / 2})`,
			children: [P(e.item) && /* @__PURE__ */ p(d, { children: [
				[
					"D",
					"B",
					"A",
					"C"
				].map((e, t) => /* @__PURE__ */ f("path", {
					d: [
						`M0 0H${o}L${o / 2} ${c / 2}Z`,
						`M${o} 0V${c}L${o / 2} ${c / 2}Z`,
						`M0 ${c}H${o}L${o / 2} ${c / 2}Z`,
						`M0 0V${c}L${o / 2} ${c / 2}Z`
					][t],
					fill: `url(#${a}${e})`,
					stroke: "#333b3b",
					strokeWidth: ".02"
				}, e)),
				[
					"D",
					"B",
					"A",
					"C"
				].map((e, t) => /* @__PURE__ */ f("text", {
					x: [
						o / 2,
						o - .3,
						o / 2,
						.3
					][t],
					y: [
						.42,
						c / 2 + .14,
						c - .12,
						c / 2 + .14
					][t],
					fontSize: ".42",
					textAnchor: "middle",
					fontWeight: "900",
					children: e
				}, e)),
				/* @__PURE__ */ f(at, {
					kind: e.item,
					x: o / 2 - 1.2,
					y: c / 2 - .7,
					size: 2.4
				})
			] }), e.item === "spec" ? /* @__PURE__ */ p(d, { children: [
				u && /* @__PURE__ */ f("rect", {
					x: ".06",
					y: ".06",
					width: ".88",
					height: ".88",
					fill: `url(#${a}${u})`
				}),
				/* @__PURE__ */ f(X, {
					name: "specArrow",
					x: ".1",
					y: ".1",
					width: ".8",
					height: ".8",
					color: "#151b1d"
				}),
				/* @__PURE__ */ f(X, {
					name: "specArrow",
					x: ".18",
					y: ".18",
					width: ".64",
					height: ".64",
					color: e.dim ? A[e.dim] : "#edece3"
				})
			] }) : !P(e.item) && /* @__PURE__ */ p(d, { children: [
				u && /* @__PURE__ */ f("rect", {
					x: ".06",
					y: ".06",
					width: o - .12,
					height: c - .12,
					fill: `url(#${a}${u})`
				}),
				(N(e.item) || e.item === "research" || e.item === "planning") && /* @__PURE__ */ f(X, {
					name: e.item,
					x: .15,
					y: .16,
					width: o - .3,
					height: c - (u ? .55 : .3)
				}),
				u && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("text", {
					x: o - .18,
					y: ".5",
					textAnchor: "end",
					fontSize: ".5",
					fontWeight: "900",
					children: u
				}), w.flatMap((e) => E[e].map((t, n) => ({
					tech: t,
					dim: e,
					level: n + 1
				}))).filter((t) => t.tech === e.item).map((e, t) => /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("rect", {
					x: .12 + t * .42,
					y: c - .43,
					width: ".38",
					height: ".34",
					fill: A[e.dim]
				}), /* @__PURE__ */ f("text", {
					x: .31 + t * .42,
					y: c - .17,
					fontSize: ".29",
					textAnchor: "middle",
					fill: "white",
					fontWeight: "900",
					children: e.level
				})] }, `${e.dim}${e.level}`))] }),
				F(e.item) && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("text", {
					x: o / 2,
					y: c * .43,
					textAnchor: "middle",
					fontSize: ".34",
					fontStyle: "italic",
					fontWeight: "700",
					children: l
				}), /* @__PURE__ */ f(X, {
					name: `brand${t}`,
					x: o / 2 - .4,
					y: c * .55,
					width: ".8",
					height: ".8",
					color: it[t]
				})] }),
				e.item === "marketing" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("rect", {
					x: ".06",
					y: ".06",
					width: o - .12,
					height: c - .12,
					fill: "#ae99b9"
				}), /* @__PURE__ */ f(X, {
					name: "marketing",
					x: ".25",
					y: ".25",
					width: o - .5,
					height: c - .5
				})] })
			] })]
		})
	] });
}
function ft({ player: e, draft: t = [], expansion: r, ghost: i, selected: c, editing: l = !1, expanding: d = !1, onCell: m, onTile: h, tools: g }) {
	let _ = s(), [v, y] = o(0), b = a(null), x = a(null), S = a(null), [C, w] = o({
		x: 8,
		y: 44
	});
	n(() => {
		if (!g) return;
		let e = () => {
			if (!b.current || !x.current || !S.current) return;
			let e = b.current.getBoundingClientRect(), t = x.current.getBoundingClientRect(), n = S.current.getBoundingClientRect(), r = {
				x: Math.max(8, Math.min(e.width - n.width - 8, t.x - e.x + (t.width - n.width) / 2)),
				y: Math.max(42, Math.min(e.height - n.height - 8, t.bottom - e.y + 8 + n.height < e.height ? t.bottom - e.y + 8 : t.top - e.y - n.height - 8))
			};
			w((e) => Math.abs(e.x - r.x) + Math.abs(e.y - r.y) < .5 ? e : r);
		};
		e();
		let t = new MutationObserver(e);
		t.observe(b.current, {
			subtree: !0,
			attributes: !0,
			attributeFilter: ["transform"]
		});
		let n = new ResizeObserver(e);
		return n.observe(b.current), () => {
			t.disconnect(), n.disconnect();
		};
	}, [g]);
	let ee = le(e.floors), T = [...e.tiles, ...t], te = e.floors.flatMap((e, t) => V(e, t === 0).all), E = r ? V(r).all : [], D = te, O = d ? 8 : 1, ne = Math.min(...D.map((e) => e[0])) - O, k = Math.min(...D.map((e) => e[1])) - O, re = Math.max(...D.map((e) => e[0])) + 1 + O, ie = Math.max(...D.map((e) => e[1])) + 1 + O, A = [];
	if (l || h) for (let e = k; e < ie; e++) for (let t = ne; t < re; t++) (d || ee.all.has(L(t, e))) && A.push({
		key: L(t, e),
		rect: {
			x: (t - ne) * 100,
			y: (e - k) * 100,
			w: 100,
			h: 100
		}
	});
	return /* @__PURE__ */ p("div", {
		className: "hc-factory-map",
		ref: b,
		children: [
			/* @__PURE__ */ f(u, {
				sheetW: (re - ne) * 100,
				sheetH: (ie - k) * 100,
				fitKey: `${e.rid}:${e.floors.length}:${d}:${v}`,
				eligible: A,
				highlight: "off",
				clampToSheet: !0,
				onTapEligible: (e) => {
					let [t, n] = e.split(",").map(Number);
					if (l && m) m(t, n);
					else {
						let e = T.find((e) => {
							let r = z(e);
							return t >= r.x && t < r.x + r.w && n >= r.y && n < r.y + r.h;
						});
						e && h?.(e);
					}
				},
				children: /* @__PURE__ */ p("g", {
					transform: `translate(${-ne * 100} ${-k * 100}) scale(100)`,
					children: [
						te.map(([e, t]) => /* @__PURE__ */ f("rect", {
							x: e,
							y: t,
							width: "1",
							height: "1",
							fill: ee.bays.has(L(e, t)) ? "#9fa6a4" : "#292d2e",
							stroke: "#555c5d",
							strokeWidth: ".025"
						}, L(e, t))),
						e.floors.map((t, n) => {
							let r = V(t, n === 0).bounds;
							return /* @__PURE__ */ f(Z, {
								name: `floor:${e.rid}:${n}`,
								children: /* @__PURE__ */ f("rect", {
									x: r.x,
									y: r.y,
									width: r.w,
									height: r.h,
									fill: "none",
									stroke: "#c4c9c7",
									strokeWidth: ".08"
								})
							}, n);
						}),
						E.map(([e, t]) => /* @__PURE__ */ f("rect", {
							x: e,
							y: t,
							width: "1",
							height: "1",
							fill: "#d4d8b4",
							fillOpacity: ".3",
							stroke: "#d4d8b4",
							strokeWidth: ".04"
						}, `e${e},${t}`)),
						d && r && /* @__PURE__ */ f("g", {
							ref: x,
							children: /* @__PURE__ */ f("rect", {
								...V(r).bounds,
								width: V(r).bounds.w,
								height: V(r).bounds.h,
								fill: "none",
								stroke: "#f5d77e",
								strokeWidth: ".1"
							})
						}),
						T.map((n) => /* @__PURE__ */ p("g", {
							ref: !i && c === n.id ? x : void 0,
							className: t.includes(n) ? "hc-tile-draft" : void 0,
							children: [/* @__PURE__ */ f(Z, {
								name: `tile:${e.rid}:${n.id}`,
								children: /* @__PURE__ */ f(dt, {
									tile: n,
									brand: e.brand
								})
							}), (c === n.id || t.includes(n)) && /* @__PURE__ */ f("rect", {
								...z(n),
								width: z(n).w,
								height: z(n).h,
								fill: "none",
								stroke: c === n.id ? "#f6d36c" : "#9fcecb",
								strokeWidth: ".1",
								strokeDasharray: ".25 .15",
								children: /* @__PURE__ */ f("animate", {
									attributeName: "stroke-dashoffset",
									from: "0",
									to: "-.8",
									dur: "1s",
									repeatCount: "indefinite"
								})
							})]
						}, n.id)),
						i && /* @__PURE__ */ p("g", {
							ref: x,
							opacity: ".8",
							children: [/* @__PURE__ */ f(dt, {
								tile: i,
								brand: e.brand
							}), /* @__PURE__ */ f("rect", {
								...z(i),
								width: z(i).w,
								height: z(i).h,
								fill: "none",
								stroke: "#ffe89c",
								strokeWidth: ".14",
								strokeDasharray: ".3 .2",
								children: /* @__PURE__ */ f("animate", {
									attributeName: "stroke-dashoffset",
									from: "0",
									to: "-1",
									dur: "1s",
									repeatCount: "indefinite"
								})
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ f("button", {
				type: "button",
				className: "hc-map-fit",
				onClick: () => y((e) => e + 1),
				children: _("games.horselesscarriage.fullFactory")
			}),
			g && /* @__PURE__ */ f("div", {
				ref: S,
				className: "hc-local-tools",
				style: {
					left: C.x,
					top: C.y
				},
				children: g
			})
		]
	});
}
function pt({ pub: e, dealer: t, preview: n, selected: r, onNiche: i, legal: a = [] }) {
	let o = s();
	return /* @__PURE__ */ f("div", {
		className: "hc-market-map",
		children: /* @__PURE__ */ f(u, {
			sheetW: 1010,
			sheetH: 1010,
			fitKey: "market",
			clampToSheet: !0,
			highlight: "inset",
			eligible: a.map((e) => {
				let [t, n] = e.split(",").map(Number);
				return {
					key: e,
					rect: {
						x: (t + 1.25) * 100,
						y: (8 - n) * 100,
						w: 100,
						h: 100
					}
				};
			}),
			onTapEligible: (e) => {
				let [t, n] = e.split(",").map(Number);
				i?.(t, n);
			},
			children: /* @__PURE__ */ p("g", {
				transform: "scale(100)",
				children: [
					/* @__PURE__ */ f("rect", {
						x: "0",
						y: "0",
						width: "10.1",
						height: "10.1",
						fill: "#e6e5dd"
					}),
					Array.from({ length: 64 }, (t, n) => {
						let i = n % 8, a = Math.floor(n / 8), o = e.buyers[n], s = e.sparks[n], c = xe(i, a);
						return /* @__PURE__ */ p(Z, {
							name: `niche:${i},${a}`,
							children: [
								/* @__PURE__ */ f("rect", {
									x: i + 1.25,
									y: 8 - a,
									width: "1",
									height: "1",
									fill: [
										"#d6d9d4",
										"#c3c9c8",
										"#b4b7be",
										"#a4a9b4"
									][c],
									stroke: "#5c6263",
									strokeWidth: ".018"
								}),
								T.map((e, t) => o[e] || s[e] ? /* @__PURE__ */ p(Z, {
									name: `buyers:${i},${a}:${e}`,
									children: [
										/* @__PURE__ */ f(at, {
											kind: e,
											x: i + 1.3,
											y: 8.06 - a + t * .29,
											size: .28
										}),
										/* @__PURE__ */ f("text", {
											x: i + 1.66,
											y: 8.25 - a + t * .29,
											fontSize: ".22",
											fill: "#161b1d",
											fontWeight: "800",
											children: o[e] || "–"
										}),
										s[e] > 0 && /* @__PURE__ */ p("text", {
											x: i + 1.94,
											y: 8.25 - a + t * .29,
											fontSize: ".17",
											fill: j[e],
											children: ["✦", s[e]]
										})
									]
								}, e) : null),
								r?.x === i && r.y === a && /* @__PURE__ */ f("rect", {
									x: i + 1.28,
									y: 8.03 - a,
									width: ".94",
									height: ".94",
									fill: "none",
									stroke: "#fff1a9",
									strokeWidth: ".09"
								})
							]
						}, n);
					}),
					[
						0,
						1,
						2,
						3
					].map((t) => /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("text", {
						x: 2.25 + t * 2,
						y: "9.4",
						textAnchor: "middle",
						fontSize: ".3",
						fontWeight: "700",
						children: e.minimum[e.axes[0]] + t
					}), /* @__PURE__ */ f("text", {
						x: ".85",
						y: 8.2 - t * 2,
						textAnchor: "middle",
						fontSize: ".3",
						fontWeight: "700",
						children: e.minimum[e.axes[1]] + t
					})] }, t)),
					/* @__PURE__ */ f(Z, {
						name: "axis:0",
						children: /* @__PURE__ */ f("text", {
							className: "hc-axis-label",
							x: "5.25",
							y: "9.85",
							textAnchor: "middle",
							fontSize: ".35",
							fontWeight: "800",
							fill: A[e.axes[0]],
							children: o(ae[e.axes[0]])
						}, e.axes[0])
					}),
					/* @__PURE__ */ f(Z, {
						name: "axis:1",
						children: /* @__PURE__ */ f("text", {
							className: "hc-axis-label",
							transform: "translate(.35 5) rotate(-90)",
							textAnchor: "middle",
							fontSize: ".35",
							fontWeight: "800",
							fill: A[e.axes[1]],
							children: o(ae[e.axes[1]])
						}, e.axes[1])
					}),
					[
						0,
						1,
						2,
						3
					].map((e) => /* @__PURE__ */ f("text", {
						x: 1.45 + e % 2 * 4,
						y: e < 2 ? 8.95 : 1.38,
						fontSize: ".22",
						fill: "#5c6263",
						children: [
							"I",
							"II",
							"III",
							"IV"
						][e]
					}, e)),
					e.players.flatMap((e) => Object.entries(e.windows).map(([t, n]) => {
						let r = e.tiles.find((e) => e.id === t);
						if (!r) return null;
						let [i, a] = Se({ stretch: Math.min(2, e.tiles.filter((e) => e.item === "marketing" && (() => {
							let t = z(e), n = z(r);
							return (t.x + t.w === n.x || n.x + n.w === t.x) && Math.max(t.y, n.y) < Math.min(t.y + t.h, n.y + n.h) || (t.y + t.h === n.y || n.y + n.h === t.y) && Math.max(t.x, n.x) < Math.min(t.x + t.w, n.x + n.w);
						})()).length) }, n);
						return /* @__PURE__ */ f(Z, {
							name: `window:${e.rid}:${t}`,
							children: /* @__PURE__ */ f("rect", {
								x: n.x + 1.25,
								y: 9 - n.y - a,
								width: i,
								height: a,
								fill: "none",
								stroke: it[e.brand],
								strokeWidth: ".075"
							})
						}, `${e.rid}${t}`);
					})),
					t && n && (() => {
						let [e, r] = Se(t, n);
						return /* @__PURE__ */ f("rect", {
							x: n.x + 1.25,
							y: 9 - n.y - r,
							width: e,
							height: r,
							fill: "#fff8c1",
							fillOpacity: ".18",
							stroke: "#272e2f",
							strokeWidth: ".1",
							strokeDasharray: ".15 .1",
							children: /* @__PURE__ */ f("animate", {
								attributeName: "stroke-dashoffset",
								from: "0",
								to: "-.5",
								dur: ".7s",
								repeatCount: "indefinite"
							})
						});
					})()
				]
			})
		})
	});
}
function mt({ card: e }) {
	let t = s();
	return /* @__PURE__ */ p("div", {
		className: "hc-demand-face",
		children: [/* @__PURE__ */ p("svg", {
			viewBox: "0 0 112 137",
			"aria-label": t("games.horselesscarriage.cardNumber", { n: e.id + 1 }),
			children: [
				/* @__PURE__ */ f("rect", {
					x: "1",
					y: "1",
					width: "110",
					height: "135",
					rx: "3",
					fill: "#f2f0e7",
					stroke: "#363b3c"
				}),
				Array.from({ length: 16 }, (e, t) => {
					let n = t % 4, r = Math.floor(t / 4);
					return /* @__PURE__ */ f("rect", {
						x: 8 + n * 24,
						y: 9 + (3 - r) * 24,
						width: "24",
						height: "24",
						fill: (n + r) % 2 ? "#c6cbc8" : "#e0e1d9",
						stroke: "#727777",
						strokeWidth: ".3"
					}, t);
				}),
				e.points.map((e, t) => /* @__PURE__ */ p("g", { children: [/* @__PURE__ */ f("rect", {
					x: 8 + e.x * 24,
					y: 9 + (3 - e.y) * 24,
					width: "24",
					height: "24",
					fill: j[e.kind]
				}), Array.from({ length: e.count }, (t, n) => /* @__PURE__ */ f(at, {
					kind: e.kind,
					x: 10 + e.x * 24,
					y: 13 + (3 - e.y) * 24 + n * 9,
					size: 20
				}, n))] }, t)),
				/* @__PURE__ */ f("rect", {
					x: "8",
					y: "112",
					width: "21",
					height: "17",
					fill: "#8a9c6e"
				}),
				/* @__PURE__ */ f("text", {
					x: "18.5",
					y: "124",
					textAnchor: "middle",
					fill: "#fff",
					fontSize: "12",
					fontWeight: "800",
					children: e.year
				}),
				e.clocks > 0 ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(X, {
					name: "clock",
					x: "58",
					y: "113",
					width: "10",
					height: "15"
				}), /* @__PURE__ */ f("text", {
					x: "77",
					y: "125",
					textAnchor: "middle",
					fontSize: "12",
					children: e.clocks
				})] }) : /* @__PURE__ */ f("text", {
					x: "69",
					y: "125",
					textAnchor: "middle",
					fontSize: "12",
					children: "—"
				})
			]
		}), /* @__PURE__ */ p("span", { children: [
			t("games.horselesscarriage.earliest", { n: e.year }),
			" · ",
			t("games.horselesscarriage.clocks", { n: e.clocks })
		] })]
	});
}
function ht({ pub: e, x: t, y: n }) {
	let r = s(), i = e.buyers[be(t, n)];
	return /* @__PURE__ */ p("div", {
		className: "hc-niche-detail",
		children: [
			/* @__PURE__ */ f("b", { children: r("games.horselesscarriage.niche", {
				x: t + 1,
				y: n + 1
			}) }),
			/* @__PURE__ */ f(ut, { specs: ke(e, t, n) }),
			/* @__PURE__ */ f("div", { children: T.map((e) => /* @__PURE__ */ p("span", { children: [
				r(oe[e]),
				" ",
				i[e],
				" "
			] }, e)) })
		]
	});
}
//#endregion
//#region src/games/horselesscarriage/view-player.tsx
var gt = {
	industrialist: "games.horselesscarriage.industrialist",
	setup: "games.horselesscarriage.setup",
	research: "games.horselesscarriage.researchPhase",
	focus: "games.horselesscarriage.focusPhase",
	build: "games.horselesscarriage.buildPhase",
	brochures: "games.horselesscarriage.brochures",
	sell: "games.horselesscarriage.sellPhase",
	finish: "games.horselesscarriage.finishPhase",
	expectations: "games.horselesscarriage.expectations",
	demand: "games.horselesscarriage.demandPhase",
	reveal: "games.horselesscarriage.reveal",
	grow: "games.horselesscarriage.grow",
	neutral: "games.horselesscarriage.neutral",
	prices: "games.horselesscarriage.prices",
	done: "games.horselesscarriage.done"
}, _t = {
	factory: "games.horselesscarriage.factory",
	market: "games.horselesscarriage.market",
	technology: "games.horselesscarriage.technology",
	demand: "games.horselesscarriage.demand",
	history: "games.horselesscarriage.history"
}, vt = (e) => e === "research" ? "technology" : [
	"sell",
	"reveal",
	"grow",
	"neutral",
	"prices",
	"expectations"
].includes(e) ? "market" : e === "demand" ? "demand" : "factory";
function yt(e) {
	let t = e.public;
	return /* @__PURE__ */ f(bt, {
		...e,
		pub: t,
		priv: e.private
	});
}
function bt({ pub: e, priv: t, members: r, myRid: i, send: u }) {
	let h = s(), g = e.players.find((e) => e.rid === i), _ = e.actor === i, [v, y] = o(vt(e.phase)), [b, x] = o(i), S = e.players.find((e) => e.rid === b) ?? g ?? e.players[0], [w, ee] = o([]), [E, O] = o(null), [ne, j] = o(null), M = w.filter((e) => !g?.tiles.some((t) => t.id === e.id)), [I, L] = o(!1), [R, se] = o(null), [B, ce] = o(0), [V, le] = o([]), [de, pe] = o(null), [me, he] = o(0), [be, xe] = o(g?.brand ?? 0), [Se, Ce] = o(0), [we, Te] = o(null), [H, De] = o(null), [ke, Ae] = o(0), [je, Me] = o(null), Ne = a({
		year: e.year,
		phase: e.phase,
		actor: e.actor
	});
	n(() => {
		let t = Ne.current;
		if (Ne.current = {
			year: e.year,
			phase: e.phase,
			actor: e.actor
		}, (t.year !== e.year || t.phase !== e.phase || t.actor !== e.actor) && (ee([]), O(null), j(null), L(!1), se(null), le([]), pe(null), De(null), Me(null), t.phase !== e.phase && [
			"reveal",
			"grow",
			"neutral",
			"prices",
			"expectations"
		].includes(e.phase) && y("market"), e.actor === i && t.actor !== i)) {
			if (x(i), t.phase === "expectations" && e.phase === "demand" || t.phase === "prices" && e.phase === "research") {
				y("market");
				let t = setTimeout(() => y(vt(e.phase)), G.admin);
				return () => clearTimeout(t);
			}
			y(vt(e.phase));
		}
	}, [
		e.year,
		e.phase,
		e.actor,
		i
	]);
	let { ref: Pe } = m("supply"), { ref: Fe } = m("hand"), { ref: Ie } = m("market-scene"), U = (e) => r.find((t) => t.rid === e)?.name ?? e, Le = _ && !!g && ["setup", "build"].includes(e.phase), Re = Le && b === i, ze = g ? {
		...g,
		tiles: [...g.tiles, ...M]
	} : null, W = [...S.tiles, ...b === i ? M : []].find((e) => e.id === ne), Be = g ? _e(e, g, M, e.phase === "setup") : null, Ve = !g || e.phase === "setup" || g.floors.length === 7 || R && ue(g.floors, R), He = g ? ve(g, e.introductory) : [], K = He.find((e) => e.tile.id === we) ?? He[0], Ue = g ? Oe(e, g) : [], q = K ? [...new Set(Ue.filter((e) => e.dealer === K.tile.id).map((e) => `${e.x},${e.y}`))] : [], We = K && g?.windows[K.tile.id], Ge = K && H ? We ? [We] : Ee(e, K, H.x, H.y) : [], J = Ge[ke % Math.max(1, Ge.length)] ?? null, Ke = K && H ? Ue.find((e) => e.dealer === K.tile.id && e.x === H.x && e.y === H.y) : null, qe = {};
	if (Ke && K && g) for (let t of T) {
		let n = Ke.counts[t];
		for (let r of K.lines.filter((n) => (e.introductory ? "car" : n.item) === t)) {
			let e = Math.min(n, g.capacity - (g.used[r.id] ?? 0));
			qe[r.id] = e, n -= e;
		}
	}
	let Ye = je ?? qe, Xe = !!Ke && !!K && !!g && T.every((t) => K.lines.filter((n) => (e.introductory ? "car" : n.item) === t).reduce((e, t) => e + (Ye[t.id] ?? 0), 0) === Ke.counts[t]) && K.lines.every((e) => (Ye[e.id] ?? 0) <= g.capacity - (g.used[e.id] ?? 0)), Ze = (e) => u(e), Qe = (t) => {
		Ce((e) => e + 1), L(!1), O({
			id: `y${e.year}-${g?.brand}-${Se}`,
			item: t,
			x: 5,
			y: 5,
			r: B
		}), j(null), y("factory"), x(i);
	}, $e = (e, t) => {
		if (I) {
			se({
				x: e,
				y: t,
				r: B
			});
			return;
		}
		if (E) {
			O({
				...E,
				x: e,
				y: t
			});
			return;
		}
		let n = ze?.tiles.find((n) => {
			let r = z(n);
			return e >= r.x && e < r.x + r.w && t >= r.y && t < r.y + r.h;
		});
		j(n?.id ?? null);
	}, et = () => {
		let e = (B + 1) % 4;
		ce(e), E && O({
			...E,
			r: e
		}), I && R && se({
			...R,
			r: e
		});
	}, tt = (t, n) => {
		W && t !== "capacity" && (Ce((e) => e + 1), O({
			id: `y${e.year}-${g?.brand}-${Se}`,
			item: "spec",
			target: W.id,
			dim: t,
			level: n,
			x: W.x - 1,
			y: W.y,
			r: 0
		}), L(!1));
	}, Y = (e, t, n = !1) => /* @__PURE__ */ f("button", {
		type: "button",
		className: "hc-button",
		disabled: n,
		onClick: t,
		children: e
	}), nt = Re && (E || I || W) ? /* @__PURE__ */ p(d, { children: [
		E && /* @__PURE__ */ f("b", { children: h(oe[E.item]) }),
		(E || I) && Y(h("games.horselesscarriage.rotate"), et),
		E && Y(h("games.horselesscarriage.placeTile"), () => {
			ee((e) => [...e, E]), j(E.id), O(null);
		}),
		I && Y(h("games.horselesscarriage.confirmExpansion"), () => L(!1), !R || !ue(g.floors, R)),
		(E || I) && Y(h("games.horselesscarriage.cancel"), () => {
			O(null), L(!1);
		}),
		W && M.some((e) => e.id === W.id) && !E && !I && /* @__PURE__ */ p(d, { children: [Y(h("games.horselesscarriage.moveTile"), () => {
			ee((e) => e.filter((e) => e.id !== W.id)), O(W), ce(W.r);
		}), Y(h("games.horselesscarriage.remove"), () => {
			ee((e) => e.filter((e) => e.id !== W.id)), j(null);
		})] })
	] }) : null, rt = /* @__PURE__ */ f(ft, {
		player: S,
		draft: b === i ? M : [],
		ghost: Re ? E : null,
		expansion: Re ? R : null,
		selected: ne,
		editing: Re,
		expanding: Re && I,
		onCell: $e,
		onTile: (e) => j(e.id),
		tools: nt
	}), it = /* @__PURE__ */ f(pt, {
		pub: e,
		dealer: K,
		preview: v === "market" ? J : null,
		selected: H,
		legal: _ && e.phase === "sell" ? q : [],
		onNiche: (e, t) => {
			De({
				x: e,
				y: t
			}), Ae(0), Me(null);
		}
	}), at = e.phase === "setup" ? ["research", "planning"] : [
		"car",
		"truck",
		"sports",
		"dealer0",
		"dealer1",
		"dealer2",
		"research",
		"planning",
		"marketing",
		...te
	], Z = g ? Math.min(g.tiles.filter((e) => e.item === "research").length, Je(e, i).length) : 0, lt = g && de !== null ? C[g.brand][de] : null, yt = e.phase === "done" ? h("games.horselesscarriage.done") : _ ? h(gt[e.phase]) : e.actor ? h("games.horselesscarriage.waiting", { name: U(e.actor) }) : h(gt[e.phase]);
	return /* @__PURE__ */ f("div", {
		className: "hc-screen",
		children: /* @__PURE__ */ f(l, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ p("header", {
					className: "hc-header",
					children: [/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("span", {
						className: "hc-wordmark",
						children: h("games.horselesscarriage.name")
					}), /* @__PURE__ */ p("strong", { children: [
						h("games.horselesscarriage.year", { n: e.year }),
						" · ",
						yt
					] })] }), /* @__PURE__ */ p("span", {
						className: "hc-clock",
						title: h("games.horselesscarriage.clock"),
						children: [/* @__PURE__ */ f(X, { name: "clock" }), /* @__PURE__ */ f(c, { value: e.clock })]
					})]
				}),
				/* @__PURE__ */ f("div", {
					className: "hc-players",
					children: e.order.map((t, n) => {
						let r = e.players.find((e) => e.rid === t);
						return /* @__PURE__ */ p("button", {
							type: "button",
							className: "hc-player",
							"data-selected": b === t,
							"data-actor": e.actor === t,
							onClick: () => {
								x(t), y("factory"), j(null);
							},
							children: [
								/* @__PURE__ */ f(st, {
									name: `seat:${t}`,
									children: /* @__PURE__ */ f(ot, { brand: r.brand })
								}),
								/* @__PURE__ */ f("small", {
									className: "hc-order",
									children: n + 1
								}),
								/* @__PURE__ */ f("strong", {
									title: U(t),
									children: U(t)
								}),
								/* @__PURE__ */ p("span", {
									title: h("games.horselesscarriage.wealth"),
									children: ["$", /* @__PURE__ */ f(c, { value: r.wealth })]
								}),
								/* @__PURE__ */ f(st, {
									name: `gantt:${t}`,
									children: /* @__PURE__ */ p("small", {
										title: h("games.horselesscarriage.gantt"),
										children: ["▤ ", /* @__PURE__ */ f(c, { value: r.gantt })]
									})
								}),
								/* @__PURE__ */ f(st, {
									name: `sealed:${t}`,
									className: "hc-sealed",
									children: e.demandSubmitted.includes(t) && !e.revealed.some((e) => e.rid === t) && /* @__PURE__ */ f(ct, {})
								})
							]
						}, t);
					})
				}),
				/* @__PURE__ */ f("nav", {
					className: "hc-tabs",
					children: Object.keys(_t).map((e) => /* @__PURE__ */ f("button", {
						type: "button",
						"data-active": v === e,
						onClick: () => y(e),
						children: h(_t[e])
					}, e))
				})
			] }),
			children: /* @__PURE__ */ p("div", {
				className: "hc-desk",
				children: [
					/* @__PURE__ */ f("section", {
						className: "hc-main-scene",
						ref: v === "demand" ? Fe : v === "market" ? Ie : void 0,
						"aria-label": h(_t[v]),
						children: v === "factory" ? /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ p("div", {
							className: "hc-scene-heading",
							children: [/* @__PURE__ */ f("b", { children: re[S.brand] }), /* @__PURE__ */ p("span", { children: [
								h("games.horselesscarriage.capacity"),
								" ",
								S.capacity
							] })]
						}), rt] }) : v === "market" ? it : v === "technology" ? /* @__PURE__ */ f(xt, {
							pub: e,
							name: U,
							moves: V,
							onMove: _ && e.phase === "research" ? (e) => le((t) => t.some((t) => t.rid === e.rid && t.dim === e.dim) ? t.filter((t) => t.rid !== e.rid || t.dim !== e.dim) : t.length < Z ? [...t, e] : t) : void 0,
							rid: i
						}) : v === "demand" ? /* @__PURE__ */ f("div", {
							className: "hc-card-grid",
							children: (t?.hand ?? []).map((t) => {
								let n = C[g?.brand ?? 0][t], r = !!g && n.year <= g.floors.length - 1;
								return /* @__PURE__ */ f("button", {
									type: "button",
									className: "hc-card",
									"data-selected": t === de,
									disabled: !_ || e.phase !== "demand" || !r,
									onClick: () => pe(t),
									children: /* @__PURE__ */ f(mt, { card: n })
								}, t);
							})
						}) : /* @__PURE__ */ f("ol", {
							className: "hc-log",
							children: e.log.map((e, t) => /* @__PURE__ */ p("li", { children: [
								/* @__PURE__ */ f("b", { children: h("games.horselesscarriage.year", { n: e.year }) }),
								" ",
								Ct(e, h, U)
							] }, t))
						})
					}),
					/* @__PURE__ */ f("section", {
						className: "hc-secondary",
						"aria-label": h(v === "market" ? "games.horselesscarriage.factory" : "games.horselesscarriage.market"),
						children: v === "market" ? rt : it
					}),
					/* @__PURE__ */ p("aside", {
						className: "hc-console",
						children: [/* @__PURE__ */ p("div", {
							className: "hc-console-scroll",
							children: [
								/* @__PURE__ */ p("div", {
									className: "hc-supply-origin",
									ref: Pe,
									children: [/* @__PURE__ */ f(X, { name: "research" }), /* @__PURE__ */ f("span", { children: h(Le ? "games.horselesscarriage.components" : gt[e.phase]) })]
								}),
								_ && e.phase === "industrialist" && /* @__PURE__ */ p(d, { children: [
									/* @__PURE__ */ f("h2", { children: h("games.horselesscarriage.industrialist") }),
									/* @__PURE__ */ f("div", {
										className: "hc-industrialists",
										children: re.map((t, n) => /* @__PURE__ */ p("button", {
											type: "button",
											className: "hc-button",
											"data-active": be === n,
											disabled: e.players.some((e) => e.brandChosen && e.brand === n),
											onClick: () => xe(n),
											children: [/* @__PURE__ */ f(ot, { brand: n }), t]
										}, t))
									}),
									/* @__PURE__ */ f("div", {
										className: "hc-brand-cards",
										children: C[be].filter((t) => !e.introductory || t.points.every((e) => e.kind === "car")).map((e) => /* @__PURE__ */ f(mt, { card: e }, e.id))
									})
								] }),
								Le && /* @__PURE__ */ p(d, { children: [
									/* @__PURE__ */ f("p", { children: h(e.phase === "setup" ? "games.horselesscarriage.startHint" : "games.horselesscarriage.buildHint") }),
									/* @__PURE__ */ f("div", {
										className: "hc-supply",
										children: at.map((t) => {
											let n = ye({
												...e,
												players: e.players.map((e) => e.rid === i ? ze : e)
											}, t, ze), [r, a] = k[t], o = !N(t) || fe(e, i, t).length > 0;
											return /* @__PURE__ */ p("button", {
												type: "button",
												className: "hc-supply-tile",
												"data-step": N(t) ? D[t].step : void 0,
												disabled: n <= 0 || !o || e.phase === "setup" && M.some((e) => e.item === t),
												onClick: () => Qe(t),
												children: [
													/* @__PURE__ */ f("svg", {
														className: "hc-supply-art",
														viewBox: `0 0 ${r} ${a}`,
														"aria-hidden": !0,
														children: /* @__PURE__ */ f(dt, {
															tile: {
																id: t,
																item: t,
																x: 0,
																y: 0,
																r: 0
															},
															brand: g.brand
														})
													}),
													/* @__PURE__ */ f("b", { children: F(t) ? ie[g.brand][Number(t.slice(-1))] : h(oe[t]) }),
													/* @__PURE__ */ p("small", { children: [
														r,
														"×",
														a,
														" · ",
														n
													] })
												]
											}, t);
										})
									}),
									W && N(W.item) && /* @__PURE__ */ p("div", {
										className: "hc-arrow-choices",
										children: [/* @__PURE__ */ f("h3", { children: h("games.horselesscarriage.chooseSpec") }), fe(e, i, W.item).map((e) => Y(/* @__PURE__ */ p(d, { children: [
											/* @__PURE__ */ f("i", { style: { background: A[e.dim] } }),
											h(ae[e.dim]),
											" · ",
											e.level
										] }), () => tt(e.dim, e.level), ze.tiles.some((t) => t.item === "spec" && t.target === W.id && t.dim === e.dim && t.level === e.level)))]
									}),
									e.phase === "build" && g.floors.length < 7 && Y(h("games.horselesscarriage.placeExpansion"), () => {
										y("factory"), x(i), L(!0), O(null);
									}),
									/* @__PURE__ */ f("div", {
										className: "hc-validation",
										role: "status",
										children: h(Be ? ge[Be] : Ve ? "games.horselesscarriage.valid" : "games.horselesscarriage.errExpansion")
									})
								] }),
								_ && e.phase === "research" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("p", { children: h("games.horselesscarriage.researchHint", { n: Z }) }), /* @__PURE__ */ p("span", {
									className: "hc-progress",
									children: [
										V.length,
										" / ",
										Z
									]
								})] }),
								e.phase === "focus" && /* @__PURE__ */ p(d, { children: [
									/* @__PURE__ */ f("p", { children: h("games.horselesscarriage.focusHint") }),
									/* @__PURE__ */ p("div", {
										className: "hc-focus-labels",
										children: [/* @__PURE__ */ p("span", { children: [h("games.horselesscarriage.engineering"), " →"] }), /* @__PURE__ */ p("span", { children: ["← ", h("games.horselesscarriage.sales")] })]
									}),
									/* @__PURE__ */ f("div", {
										className: "hc-focus",
										children: e.focusSlots.map((e, t) => /* @__PURE__ */ p("button", {
											type: "button",
											disabled: !_ || !!e,
											onClick: () => Ze({
												type: "focus",
												slot: t
											}),
											children: [/* @__PURE__ */ f("b", { children: t + 1 }), /* @__PURE__ */ f("span", { children: e ? U(e) : "—" })]
										}, t))
									}),
									_ && Y(h("games.horselesscarriage.pass"), () => Ze({
										type: "focus",
										slot: -1
									}))
								] }),
								e.phase === "sell" && /* @__PURE__ */ p(d, { children: [
									/* @__PURE__ */ f("h2", { children: h("games.horselesscarriage.sellPhase") }),
									He.map((e) => /* @__PURE__ */ p("button", {
										type: "button",
										className: "hc-dealer",
										"data-selected": e === K,
										disabled: !_,
										onClick: () => {
											Te(e.tile.id), De(null), Ae(0), Me(null), y("market");
										},
										children: [
											/* @__PURE__ */ f("b", { children: /* @__PURE__ */ f(st, {
												name: `dealer:${i}:${e.tile.id}`,
												children: ie[g.brand][Number(e.tile.item.slice(-1))]
											}) }),
											/* @__PURE__ */ f(ut, { specs: e.specs }),
											/* @__PURE__ */ f("span", { children: T.map((t) => `${h(oe[t])} ${e.capacity[t]}`).join(" · ") })
										]
									}, e.tile.id)),
									H && K && /* @__PURE__ */ p(d, { children: [
										/* @__PURE__ */ f(ht, {
											pub: e,
											...H
										}),
										!We && Ge.length > 1 && Y(h("games.horselesscarriage.nextWindow"), () => Ae((e) => e + 1)),
										/* @__PURE__ */ p("b", { children: [
											h("games.horselesscarriage.window"),
											" ",
											J ? `${J.x + 1},${J.y + 1}` : "—",
											" ",
											Ge.length ? `${ke % Ge.length + 1}/${Ge.length}` : ""
										] }),
										Ke && /* @__PURE__ */ p(d, { children: [
											/* @__PURE__ */ f("h3", { children: h("games.horselesscarriage.allocate") }),
											K.lines.map((e, t) => /* @__PURE__ */ p("label", {
												className: "hc-allocation",
												children: [
													/* @__PURE__ */ p("span", { children: [
														h(oe[e.item]),
														" ",
														t + 1
													] }),
													/* @__PURE__ */ f("input", {
														type: "number",
														min: 0,
														max: g.capacity - (g.used[e.id] ?? 0),
														value: Ye[e.id] ?? 0,
														onChange: (t) => Me({
															...Ye,
															[e.id]: Math.max(0, Math.min(g.capacity - (g.used[e.id] ?? 0), Math.floor(Number(t.target.value) || 0)))
														})
													}),
													/* @__PURE__ */ p("small", { children: ["/ ", g.capacity - (g.used[e.id] ?? 0)] })
												]
											}, e.id)),
											/* @__PURE__ */ f("b", { children: h("games.horselesscarriage.income", { n: Ke.income }) })
										] })
									] })
								] }),
								_ && e.phase === "demand" && /* @__PURE__ */ p(d, { children: [
									/* @__PURE__ */ f("p", { children: h("games.horselesscarriage.demandHint") }),
									lt && /* @__PURE__ */ f("div", {
										className: "hc-selected-card",
										children: /* @__PURE__ */ f(mt, { card: lt })
									}),
									/* @__PURE__ */ f("div", {
										className: "hc-quadrants",
										children: [
											2,
											3,
											0,
											1
										].map((e) => /* @__PURE__ */ f("button", {
											type: "button",
											"data-active": me === e,
											onClick: () => he(e),
											children: [
												"I",
												"II",
												"III",
												"IV"
											][e]
										}, e))
									})
								] }),
								!_ && e.phase !== "focus" && /* @__PURE__ */ p("div", {
									className: "hc-observer",
									children: [
										/* @__PURE__ */ f(ut, { specs: e.minimum }),
										/* @__PURE__ */ f("small", { children: h("games.horselesscarriage.minimum") }),
										e.revealed.map((t) => /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ p("b", { children: [
											U(t.rid),
											" · ",
											h("games.horselesscarriage.quadrant", { n: [
												"I",
												"II",
												"III",
												"IV"
											][t.quadrant] })
										] }), /* @__PURE__ */ f(st, {
											name: `reveal:${t.rid}`,
											children: /* @__PURE__ */ f(mt, { card: C[e.players.find((e) => e.rid === t.rid).brand][t.card] })
										})] }, t.rid))
									]
								}),
								W && !Le && /* @__PURE__ */ p("div", {
									className: "hc-inspector",
									children: [/* @__PURE__ */ f("b", { children: h(oe[W.item]) }), P(W.item) && /* @__PURE__ */ p("span", { children: [
										h("games.horselesscarriage.sold"),
										" ",
										S.used[W.id] ?? 0,
										" / ",
										S.capacity
									] })]
								}),
								/* @__PURE__ */ f(st, {
									name: "neutral-deck",
									className: "hc-neutral-deck",
									children: /* @__PURE__ */ f(ct, {})
								}),
								/* @__PURE__ */ f("div", {
									className: "hc-price-strip",
									children: e.prices.map((e, t) => /* @__PURE__ */ p(st, {
										name: `price:${t}`,
										children: [/* @__PURE__ */ f("small", { children: t + 1 }), /* @__PURE__ */ p("b", { children: ["$", /* @__PURE__ */ f(c, { value: e })] })]
									}, t))
								})
							]
						}), /* @__PURE__ */ p("div", {
							className: "hc-confirm",
							children: [
								_ && e.phase === "industrialist" && Y(h("games.horselesscarriage.chooseBrand"), () => Ze({
									type: "chooseBrand",
									brand: be
								}), e.players.some((e) => e.brandChosen && e.brand === be)),
								Le && Y(h(e.phase === "setup" ? "games.horselesscarriage.confirmStart" : "games.horselesscarriage.confirmBuild"), () => Ze(e.phase === "setup" ? {
									type: "startFactory",
									tiles: M
								} : {
									type: "build",
									tiles: M,
									expansion: R
								}), !!Be || !Ve || !!E || I),
								_ && e.phase === "research" && Y(h("games.horselesscarriage.confirmResearch"), () => Ze({
									type: "research",
									moves: V
								}), V.length !== Z),
								_ && e.phase === "demand" && Y(h("games.horselesscarriage.confirmDemand"), () => {
									de !== null && Ze({
										type: "demand",
										card: de,
										quadrant: me
									});
								}, de === null),
								_ && e.phase === "sell" && Y(h("games.horselesscarriage.confirmSale"), () => {
									K && H && J && Ze({
										type: "sell",
										dealer: K.tile.id,
										...H,
										window: We ? null : J,
										allocation: Ye
									});
								}, !Ke || !J || !Xe),
								!_ && /* @__PURE__ */ f("span", { children: yt })
							]
						})]
					})
				]
			})
		})
	});
}
function xt({ pub: e, name: t, moves: n, rid: r, onMove: i }) {
	let a = s(), o = Je(e, r);
	return /* @__PURE__ */ f("div", {
		className: "hc-research-table",
		children: [
			...e.axes,
			...e.offboard,
			"capacity"
		].map((r) => {
			let s = r === "capacity", c = s ? [
				1,
				2,
				3,
				4,
				5
			] : [
				0,
				1,
				2,
				3,
				4,
				5,
				6
			];
			return /* @__PURE__ */ p("section", {
				className: "hc-track",
				style: { borderColor: s ? "#69766d" : A[r] },
				children: [/* @__PURE__ */ p("header", { children: [/* @__PURE__ */ f("b", {
					style: { color: s ? "#364c43" : A[r] },
					children: a(s ? "games.horselesscarriage.capacity" : ae[r])
				}), !s && /* @__PURE__ */ p("span", { children: [
					a("games.horselesscarriage.minimum"),
					" ",
					e.minimum[r],
					" ",
					e.axes[e.obsolete] === r && `· ${a("games.horselesscarriage.obsolete")}`
				] })] }), /* @__PURE__ */ f("div", {
					className: "hc-track-grid",
					style: { gridTemplateColumns: `repeat(${c.length},minmax(0,1fr))` },
					children: c.map((c) => {
						let l = !s && c > 0 ? E[r][c - 1] : null;
						return /* @__PURE__ */ p("div", {
							className: "hc-track-cell",
							"data-minimum": !s && c === e.minimum[r],
							children: [
								/* @__PURE__ */ f("b", {
									className: "hc-track-number",
									children: c
								}),
								l && /* @__PURE__ */ p(d, { children: [
									/* @__PURE__ */ f(X, {
										name: l,
										className: "hc-tech-art"
									}),
									/* @__PURE__ */ f("span", {
										className: "hc-tech-name",
										children: a(oe[l])
									}),
									/* @__PURE__ */ f("small", { children: D[l].step })
								] }),
								(s ? c === 5 : [4, 6].includes(c)) && /* @__PURE__ */ f(X, {
									name: "clock",
									className: "hc-track-clock"
								}),
								/* @__PURE__ */ f("div", {
									className: "hc-track-pieces",
									children: e.players.map((e) => {
										let a = s ? e.capacity : e.research[r], l = n.some((t) => t.rid === e.rid && t.dim === r);
										return /* @__PURE__ */ f(St, {
											p: e,
											dim: r,
											level: c,
											current: a,
											selected: l,
											label: t(e.rid),
											enabled: !!i && o.some((t) => t.rid === e.rid && t.dim === r),
											onMove: i
										}, e.rid);
									})
								})
							]
						}, c);
					})
				})]
			}, r);
		})
	});
}
function St({ p: e, dim: t, level: n, current: r, selected: i, label: a, enabled: o, onMove: s }) {
	let { ref: c, hidden: l } = m(`research:${e.rid}:${t}:${n}`);
	return /* @__PURE__ */ p("span", {
		ref: c,
		className: "hc-track-slot",
		style: { visibility: l ? "hidden" : void 0 },
		children: [r === n && /* @__PURE__ */ f("button", {
			type: "button",
			"aria-label": `${a} · ${n}`,
			title: `${a} · ${n}`,
			disabled: !o,
			"data-selected": i,
			onClick: () => s?.({
				rid: e.rid,
				dim: t
			}),
			children: /* @__PURE__ */ f(ot, { brand: e.brand })
		}), i && r + 1 === n && /* @__PURE__ */ f("span", {
			className: "hc-track-preview",
			children: /* @__PURE__ */ f(ot, { brand: e.brand })
		})]
	});
}
function Ct(e, t, n) {
	let r = e.n ?? 0, i = e.rid ? n(e.rid) : "";
	switch (e.kind) {
		case "setup": return t("games.horselesscarriage.logSetup");
		case "research": return t("games.horselesscarriage.logResearch", {
			name: i,
			n: r
		});
		case "focus": return t(e.n === -1 ? "games.horselesscarriage.logPass" : "games.horselesscarriage.logFocus", {
			name: i,
			n: r + 1
		});
		case "build": return t("games.horselesscarriage.logBuild", {
			name: i,
			n: r
		});
		case "brochures": return t("games.horselesscarriage.logBrochures", {
			name: i,
			n: r
		});
		case "sale": return t("games.horselesscarriage.logSale", {
			name: i,
			n: r
		});
		case "finish": return t("games.horselesscarriage.logFinish");
		case "expectations": return t("games.horselesscarriage.logExpectations", { dim: e.dim ? t(ae[e.dim]) : "" });
		case "demand": return t("games.horselesscarriage.logDemand", {
			name: i,
			n: (e.card ?? 0) + 1,
			q: [
				"I",
				"II",
				"III",
				"IV"
			][e.quadrant ?? 0]
		});
		case "grow": return t("games.horselesscarriage.logGrow", { n: r });
		case "neutral": return t("games.horselesscarriage.logNeutral", { q: [
			"I",
			"II",
			"III",
			"IV"
		][e.quadrant ?? 0] });
		case "prices": return t("games.horselesscarriage.logPrices");
	}
}
//#endregion
//#region src/games/horselesscarriage/bot.ts
var wt = {
	researchTarget: 3,
	planningTarget: 2,
	futureWeight: .55,
	capacityWeight: 1.5,
	denialWeight: .2
}, Tt = (e) => {
	let t = e.floors.flatMap((e, t) => V(e, t === 0).all);
	return {
		left: Math.min(...t.map((e) => e[0])),
		top: Math.min(...t.map((e) => e[1])),
		right: Math.max(...t.map((e) => e[0])) + 1,
		bottom: Math.max(...t.map((e) => e[1])) + 1
	};
};
function Et(e) {
	let t = le(e.floors), n = new Set(e.tiles.flatMap((e) => se(z(e)).map(([e, t]) => L(e, t))));
	return (e) => se(z(e)).every(([e, r]) => t.all.has(L(e, r)) && !t.bays.has(L(e, r)) && !n.has(L(e, r)));
}
function Dt(e, t, n) {
	let r = Tt(e), i = Et(e), a = [];
	for (let e = 0; e < 4; e++) {
		let o = z({
			id: n,
			item: t,
			x: 0,
			y: 0,
			r: e
		});
		for (let s = r.top; s <= r.bottom - o.h; s++) for (let c = r.left; c <= r.right - o.w; c++) {
			let r = {
				id: n,
				item: t,
				x: c,
				y: s,
				r: e
			};
			i(r) && a.push(r);
		}
	}
	return a;
}
function Ot(e) {
	if (e.floors.length >= 7) return null;
	let t = Tt(e), n = [];
	for (let e = 0; e < 4; e++) {
		let r = e % 2 ? 6 : 8, i = e % 2 ? 8 : 6;
		for (let a = t.left - r; a <= t.right; a++) for (let r of [t.top - i, t.bottom]) n.push({
			x: a,
			y: r,
			r: e
		});
		for (let a = t.top - i; a <= t.bottom; a++) for (let i of [t.left - r, t.right]) n.push({
			x: i,
			y: a,
			r: e
		});
	}
	let r = n.filter((t) => ue(e.floors, t)), i = (n) => Math.min(...e.tiles.map((e) => Math.abs(n.x + 4 - e.x) + Math.abs(n.y + 3 - e.y)), 12) + (Math.max(t.right, n.x + (n.r % 2 ? 6 : 8)) - Math.min(t.left, n.x)) * .05;
	return r.sort((e, t) => i(e) - i(t))[0] ?? null;
}
function kt(e, t, n) {
	let r = z(e), i = [];
	for (let e = 0; e < 4; e++) {
		let a = z({
			id: n,
			item: t,
			x: 0,
			y: 0,
			r: e
		});
		for (let o = -a.w + 1; o < r.w; o++) for (let s of [r.y - a.h, r.y + r.h]) i.push({
			id: n,
			item: t,
			x: r.x + o,
			y: s,
			r: e
		});
		for (let o = -a.h + 1; o < r.h; o++) for (let s of [r.x - a.w, r.x + r.w]) i.push({
			id: n,
			item: t,
			x: s,
			y: r.y + o,
			r: e
		});
	}
	return i;
}
function At(e, t, n, r, i) {
	let a = z(t), o = [], s = Et(e);
	for (let e = a.y; e < a.y + a.h; e++) o.push({
		id: i,
		item: "spec",
		x: a.x - 1,
		y: e,
		r: 0,
		target: t.id,
		dim: n,
		level: r
	}), o.push({
		id: i,
		item: "spec",
		x: a.x + a.w,
		y: e,
		r: 2,
		target: t.id,
		dim: n,
		level: r
	});
	for (let e = a.x; e < a.x + a.w; e++) o.push({
		id: i,
		item: "spec",
		x: e,
		y: a.y - 1,
		r: 1,
		target: t.id,
		dim: n,
		level: r
	}), o.push({
		id: i,
		item: "spec",
		x: e,
		y: a.y + a.h,
		r: 3,
		target: t.id,
		dim: n,
		level: r
	});
	return o.filter(s);
}
function jt(e, t, n = wt, r = !1) {
	let i = structuredClone(t), a = [], o = `y${e.year}b${i.brand}-`, s = 0, c = () => `${o}${s++}`, l = (t) => !_e({
		...e,
		players: e.players.map((e) => e.rid === i.rid ? i : e)
	}, i, t), u = (e) => {
		i.tiles.push(...e), a.push(...e);
	};
	if (!i.tiles.some((e) => P(e.item))) {
		let t = r || e.introductory ? "car" : T.map((t) => ({
			kind: t,
			n: e.buyers.reduce((e, n) => e + n[t], 0)
		})).sort((e, t) => t.n - e.n)[0].kind, n = c(), a = c();
		outer: for (let e of Dt(i, t, n)) {
			let t = Et({
				...i,
				tiles: [...i.tiles, e]
			});
			for (let n of kt(e, "dealer0", a).filter(t)) if (l([e, n])) {
				u([e, n]);
				break outer;
			}
		}
	}
	let d = (t) => {
		let r = Math.max(0, ...ve(i, e.introductory).map((e) => e.specs[t]));
		return r < e.minimum[t] ? 12 : r === 0 ? 3 : e.axes.includes(t) ? 2 / (r + 1) : n.futureWeight / (r + 1);
	};
	for (let t = 0; t < (r ? 1 : 12); t++) {
		let t = te.flatMap((t) => fe(e, i.rid, t).map((e) => ({
			item: t,
			...e,
			weight: d(e.dim) / (k[t][0] * k[t][1] + 1)
		}))).sort((e, t) => t.weight - e.weight), n = !1;
		for (let r of t) {
			let t = i.tiles.filter((e) => e.item === r.item && !i.tiles.some((t) => t.item === "spec" && t.target === e.id && t.dim === r.dim && t.level === r.level));
			for (let e of t) {
				let t = At(i, e, r.dim, r.level, c()).find((e) => l([e]));
				if (t) {
					u([t]), n = !0;
					break;
				}
			}
			if (n) break;
			if (ye({ players: e.players.map((e) => e.rid === i.rid ? i : e) }, r.item, i) <= 0) continue;
			let a = c(), o = c(), s = i.tiles.filter((e) => P(e.item) || te.includes(e.item) && D[e.item].step === D[r.item].step || e.item === "spec");
			for (let e of Dt(i, r.item, a).filter((e) => s.some((t) => B(z(e), z(t))))) {
				let t = At({
					...i,
					tiles: [...i.tiles, e]
				}, e, r.dim, r.level, o).find((t) => l([e, t]));
				if (t) {
					u([e, t]), n = !0;
					break;
				}
			}
			if (n) break;
		}
		if (!n) break;
	}
	for (let t of ["research", "planning"]) {
		let a = r ? 1 : t === "research" ? n.researchTarget : n.planningTarget;
		if (!(e.year >= 5)) for (; i.tiles.filter((e) => e.item === t).length < a;) {
			let e = Dt(i, t, c()).find((e) => l([e]));
			if (!e) break;
			u([e]);
		}
	}
	return a;
}
function Mt(e = wt) {
	return (t, n) => {
		let r = t.public, i = r.players.find((e) => e.rid === n.rid);
		if (r.actor !== n.rid || !i) return null;
		let a = n.difficulty === "weak";
		if (r.phase === "industrialist") return { action: {
			type: "chooseBrand",
			brand: [
				i.brand,
				0,
				1,
				2,
				3,
				4
			].find((e) => !r.players.some((t) => t.brandChosen && t.brand === e))
		} };
		if (r.phase === "setup") return { action: {
			type: "startFactory",
			tiles: [{
				id: "start-research",
				item: "research",
				x: 0,
				y: 5,
				r: 0
			}, {
				id: "start-planning",
				item: "planning",
				x: 3,
				y: 5,
				r: 0
			}]
		} };
		if (r.phase === "research") {
			let t = i.tiles.filter((e) => e.item === "research").length, n = Je(r, i.rid), o = n.map((t) => {
				if (t.dim === "capacity") return {
					move: t,
					score: i.capacity < 3 ? e.capacityWeight : .1
				};
				let n = t.rid === i.rid, a = Math.max(0, ...ve(i, r.introductory).map((e) => e.specs[t.dim]));
				return {
					move: t,
					score: n ? 1 + (a < r.minimum[t.dim] ? 8 : a === 0 ? 2 : r.axes.includes(t.dim) ? 1.5 : e.futureWeight) - i.research[t.dim] * .1 : -1
				};
			}).sort((e, t) => t.score - e.score);
			return { action: {
				type: "research",
				moves: (a ? n : o.map((e) => e.move)).slice(0, t)
			} };
		}
		if (r.phase === "focus") {
			let e = r.focusSlots.map((e, t) => e ? -1 : t).filter((e) => e >= 0), t = a || r.year <= 2 || ve(i).every((e) => w.some((t) => e.specs[t] < r.minimum[t])) ? e[0] : e[e.length - 1];
			return { action: {
				type: "focus",
				slot: i.gantt >= (r.year <= 2 ? 1 : 2) ? t : -1
			} };
		}
		if (r.phase === "build") return { action: {
			type: "build",
			tiles: jt(r, i, e, a),
			expansion: Ot(i)
		} };
		if (r.phase === "sell") {
			let e = Oe(r, i, !a), t = (e) => {
				let t = ve(i, r.introductory).find((t) => t.tile.id === e.dealer), n = e.window ? r.buyers.reduce((n, i, a) => H(t, e.window, a % 8, Math.floor(a / 8)) ? n + De(r, t, a % 8, Math.floor(a / 8)).income : n, 0) : 0;
				return e.income + n * .15;
			}, n = a ? e[0] : e.sort((e, n) => t(n) - t(e))[0];
			if (n) return { action: {
				type: "sell",
				dealer: n.dealer,
				x: n.x,
				y: n.y,
				window: n.window
			} };
		}
		if (r.phase === "demand") {
			let n = (t.private?.hand ?? []).map((e) => C[i.brand][e]).filter((e) => e.year <= i.floors.length - 1), o = ve(i, r.introductory), s = n.flatMap((t) => [
				0,
				1,
				2,
				3
			].map((n) => {
				let a = t.points.reduce((t, i) => {
					let a = n % 2 * 4 + i.x, s = Math.floor(n / 2) * 4 + i.y, c = o.some((e) => w.every((t) => e.specs[t] >= r.minimum[t]) && e.specs[r.axes[0]] >= r.minimum[r.axes[0]] + Math.floor(a / 2) && e.specs[r.axes[1]] >= r.minimum[r.axes[1]] + Math.floor(s / 2) && e.capacity[i.kind] > 0);
					return t + i.count * (c ? 4 : -e.denialWeight);
				}, 0) - t.clocks * (i.wealth < Math.max(...r.players.map((e) => e.wealth)) ? .25 : -.25);
				return {
					card: t.id,
					quadrant: n,
					score: a
				};
			})), c = a ? s[0] : s.sort((e, t) => t.score - e.score)[0];
			if (c) return { action: {
				type: "demand",
				card: c.card,
				quadrant: c.quadrant
			} };
		}
		return null;
	};
}
var Nt = Mt();
//#endregion
//#region src/games/horselesscarriage/fx.tsx
function Pt({ at: e, ms: t, flip: n = !1, children: r }) {
	let o = a(null);
	return i(() => {
		let e = o.current;
		if (!e) return;
		let r = e.animate(n ? [
			{
				transform: "perspective(500px) rotateY(-90deg)",
				opacity: .5
			},
			{
				transform: "perspective(500px) rotateY(0deg)",
				opacity: 1,
				offset: .45
			},
			{
				transform: "perspective(500px) rotateY(0deg)",
				opacity: 1
			}
		] : [
			{
				transform: "scale(.5)",
				opacity: 0
			},
			{
				transform: "scale(1.12)",
				opacity: 1,
				offset: .5
			},
			{
				transform: "scale(1)",
				opacity: 1
			}
		], {
			duration: t,
			easing: "ease-out",
			fill: "both"
		});
		return () => r.cancel();
	}, [t, n]), /* @__PURE__ */ f("div", {
		ref: o,
		className: "hc-fx-appear",
		style: {
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: r
	});
}
var Q = (e, t) => {
	let n = e.anchor(t);
	return n && n.w > 0 && n.h > 0 ? n : null;
}, $ = (e, t = 36) => ({
	x: e.x + (e.w - t) / 2,
	y: e.y + (e.h - t) / 2,
	w: t,
	h: t
});
function Ft(e, t, n, r, i, a = !1) {
	let o = [], s = [];
	return e.forEach((e, c) => {
		let l = `buyers:${e.x + t % 2 * 4},${e.y + Math.floor(t / 2) * 4}:${e.kind}`, u = Q(n, l);
		u && (s.push(l), o.push(i ? /* @__PURE__ */ f(_, {
			from: $(i),
			to: $(u, Math.max(20, u.h)),
			ms: r * .65,
			delay: r * .15,
			children: /* @__PURE__ */ p("div", {
				className: "hc-fx-vehicle",
				children: [/* @__PURE__ */ f("svg", {
					viewBox: "0 0 36 28",
					children: /* @__PURE__ */ f(at, {
						kind: e.kind,
						size: 36
					})
				}), a && /* @__PURE__ */ f("b", { children: "✦" })]
			})
		}, c) : /* @__PURE__ */ f(Pt, {
			at: u,
			ms: r * .7,
			children: /* @__PURE__ */ p("svg", {
				viewBox: "0 0 100 30",
				children: [/* @__PURE__ */ f(at, {
					kind: e.kind,
					size: 38
				}), /* @__PURE__ */ p("text", {
					x: "42",
					y: "22",
					fontSize: "20",
					fontWeight: "800",
					children: ["+", e.count]
				})]
			})
		}, c)));
	}), {
		node: o,
		hide: s
	};
}
var It = {
	build(e, t) {
		let n = e.data, r = Q(t, "supply");
		if (!r) return null;
		let i = [], a = [];
		for (let o of n.tiles) {
			let s = `tile:${e.rid}:${o.id}`, c = Q(t, s);
			if (!c) continue;
			let l = z(o);
			a.push(s), i.push(/* @__PURE__ */ f(_, {
				from: $(r, Math.min(65, c.w)),
				to: c,
				ms: 550,
				children: /* @__PURE__ */ f("svg", {
					width: Math.min(65, c.w),
					height: Math.min(65, c.w) * l.h / l.w,
					viewBox: `${l.x} ${l.y} ${l.w} ${l.h}`,
					children: /* @__PURE__ */ f(dt, {
						tile: o,
						brand: n.brand
					})
				})
			}, s));
		}
		let o = n.expansion ? Q(t, `floor:${e.rid}:${n.floorIndex}`) : null;
		return o && i.push(/* @__PURE__ */ f(v, {
			at: o,
			ms: 700
		}, "floor")), i.length ? {
			ms: 700,
			node: i,
			hide: a
		} : null;
	},
	research(e, t) {
		let n = e.data, r = [], i = [];
		for (let e of n.moves) {
			let n = Q(t, `research:${e.rid}:${e.dim}:${e.level}`), a = `research:${e.rid}:${e.dim}:${e.level + 1}`, o = Q(t, a);
			n && o && (i.push(a), r.push(/* @__PURE__ */ f(_, {
				from: $(n, 22),
				to: $(o, 22),
				ms: 560,
				children: /* @__PURE__ */ f("div", {
					className: "hc-fx-brand",
					children: /* @__PURE__ */ f(ot, { brand: e.brand })
				})
			}, a)));
		}
		return r.length ? {
			ms: 650,
			node: r,
			hide: i
		} : null;
	},
	focus(e, t) {
		let n = Q(t, `gantt:${e.rid}`);
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ f(v, {
				at: n,
				ms: 500
			})
		} : null;
	},
	brochure(e, t) {
		let n = Q(t, `gantt:${e.rid}`), r = e.data;
		return n ? {
			ms: G.admin,
			node: /* @__PURE__ */ f(g, {
				at: n,
				ms: G.admin,
				children: /* @__PURE__ */ p("span", {
					className: "hc-fx-income",
					children: ["+", r.n]
				})
			})
		} : null;
	},
	sale(e, t) {
		let n = e.data, r = Q(t, `niche:${n.x},${n.y}`), i = Q(t, `seat:${e.rid}`), a = [];
		if (r) for (let [i, o] of n.produced.entries()) {
			let s = Q(t, `tile:${e.rid}:${o.id}`) ?? Q(t, `tile:${e.rid}:${n.dealer}`) ?? Q(t, `dealer:${e.rid}:${n.dealer}`);
			s && a.push(/* @__PURE__ */ f(_, {
				from: $(r),
				to: $(s),
				ms: 600,
				delay: i * 40,
				children: /* @__PURE__ */ p("div", {
					className: "hc-fx-vehicle",
					children: [/* @__PURE__ */ f("svg", {
						viewBox: "0 0 36 28",
						children: /* @__PURE__ */ f(at, {
							kind: o.kind,
							size: 36
						})
					}), /* @__PURE__ */ p("b", { children: ["×", o.n] })]
				})
			}, o.id));
		}
		let o = n.window ? Q(t, `window:${e.rid}:${n.dealer}`) : null;
		return o && a.push(/* @__PURE__ */ f(v, {
			at: o,
			ms: G.sale
		}, "window")), i && a.push(/* @__PURE__ */ f(g, {
			at: i,
			ms: G.sale,
			children: /* @__PURE__ */ p("span", {
				className: "hc-fx-income",
				children: ["+$", n.income]
			})
		}, "income")), a.length ? {
			ms: G.sale,
			node: a
		} : null;
	},
	demandCommit(e, t) {
		let n = Q(t, "hand"), r = `sealed:${e.rid}`, i = Q(t, r), a = e.secret;
		if (!i) return null;
		let o = a ? /* @__PURE__ */ f(mt, { card: C[a.brand][a.card] }) : /* @__PURE__ */ f(ct, {});
		return n && e.rid === t.myRid ? {
			ms: 500,
			hide: [r],
			node: /* @__PURE__ */ f(_, {
				from: $(n, 54),
				to: i,
				ms: 500,
				children: /* @__PURE__ */ f("div", {
					className: "hc-fx-card",
					style: { width: 54 },
					children: o
				})
			})
		} : {
			ms: 450,
			hide: [r],
			node: /* @__PURE__ */ f(Pt, {
				at: i,
				ms: 450,
				children: /* @__PURE__ */ f(ct, {})
			})
		};
	},
	demand(e, t) {
		let n = e.data, r = `reveal:${e.rid}`, i = Q(t, r);
		if (!i) return null;
		let a = C[n.brand][n.card], o = Ft(a.points, n.quadrant, t, G.reveal, $(i), !0);
		return {
			ms: G.reveal,
			hide: [r, ...o.hide],
			node: /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(Pt, {
				at: i,
				ms: G.reveal * .65,
				flip: !0,
				children: /* @__PURE__ */ f(mt, { card: a })
			}), o.node] })
		};
	},
	growth(e, t) {
		let n = e.data.added.map((e, n) => {
			let r = Q(t, `buyers:${e.x},${e.y}:${e.kind}`);
			return r ? /* @__PURE__ */ f(Pt, {
				at: r,
				ms: G.growth * .75,
				children: /* @__PURE__ */ p("svg", {
					viewBox: "0 0 100 30",
					children: [/* @__PURE__ */ f(at, {
						kind: e.kind,
						size: 38
					}), /* @__PURE__ */ p("text", {
						x: "42",
						y: "22",
						fontSize: "20",
						fontWeight: "800",
						children: ["+", e.n]
					})]
				})
			}, n) : null;
		});
		return n.some(Boolean) ? {
			ms: G.growth,
			node: n
		} : null;
	},
	neutral(e, t) {
		let n = e.data, r = Q(t, "neutral-deck"), i = Ft(M[n.card], n.quadrant, t, G.admin, r ?? void 0);
		return i.node.length ? {
			ms: G.admin,
			...i
		} : null;
	},
	expectations(e, t) {
		let n = [0, 1].map((e) => {
			let n = Q(t, `axis:${e}`);
			return n ? /* @__PURE__ */ f(v, {
				at: n,
				ms: G.admin
			}, e) : null;
		});
		return {
			ms: G.admin,
			node: n
		};
	},
	prices(e, t) {
		let n = [
			0,
			1,
			2,
			3
		].map((e) => {
			let n = Q(t, `price:${e}`);
			return n ? /* @__PURE__ */ f(v, {
				at: n,
				ms: G.admin
			}, e) : null;
		});
		return {
			ms: G.admin,
			node: n
		};
	},
	finish(e, t) {
		let n = Q(t, "supply");
		return n ? {
			ms: G.admin,
			node: /* @__PURE__ */ f(Pt, {
				at: $(n, 60),
				ms: G.admin,
				children: /* @__PURE__ */ f(X, { name: "finish" })
			})
		} : null;
	}
}, Lt = () => {};
function Rt({ result: e, public: t, private: r, members: i, myRid: c, hintCount: l, onPlayAgain: u, onBackToLobby: m }) {
	let h = s(), g = t, [_, v] = o(!0), x = a(null);
	n(() => {
		_ && x.current?.focus();
	}, [_]);
	let S = (e) => i.find((t) => t.rid === e)?.name ?? e;
	return /* @__PURE__ */ p("div", {
		className: "hc-final-root",
		children: [
			/* @__PURE__ */ f("div", {
				className: "hc-final-board",
				inert: _,
				children: /* @__PURE__ */ f(yt, {
					public: g,
					private: r,
					members: i,
					myRid: c,
					send: Lt
				})
			}),
			/* @__PURE__ */ f("div", {
				className: "hc-result-backdrop",
				hidden: !_,
				children: /* @__PURE__ */ p("div", {
					ref: x,
					role: "dialog",
					"aria-modal": "true",
					"aria-label": h("games.horselesscarriage.annualReport"),
					tabIndex: -1,
					className: "hc-result",
					onKeyDown: (e) => {
						e.key === "Escape" && v(!1);
					},
					children: [
						/* @__PURE__ */ p("header", {
							className: "hc-result-header",
							children: [/* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("small", { children: h("games.horselesscarriage.name") }), /* @__PURE__ */ f("h1", { children: h("games.horselesscarriage.annualReport") })] }), /* @__PURE__ */ f("button", {
								type: "button",
								className: "hc-result-close",
								"aria-label": h("games.horselesscarriage.returnFactory"),
								onClick: () => v(!1),
								children: /* @__PURE__ */ f(y, { size: 22 })
							})]
						}),
						/* @__PURE__ */ p("div", {
							className: "hc-result-body",
							children: [
								/* @__PURE__ */ p("div", {
									className: "hc-result-title",
									children: [/* @__PURE__ */ f(X, { name: "finish" }), /* @__PURE__ */ p("div", { children: [/* @__PURE__ */ f("span", { children: h("games.horselesscarriage.year", { n: g.year }) }), /* @__PURE__ */ f("h2", { children: h("games.horselesscarriage.winner", { name: e.winner.map(S).join("、") }) })] })]
								}),
								/* @__PURE__ */ f("ol", {
									className: "hc-ranking",
									children: e.ranking.map((t, n) => {
										let r = g.players.find((e) => e.rid === t), i = e.autopilot?.[t];
										return /* @__PURE__ */ p("li", {
											"data-winner": e.winner.includes(t),
											children: [
												/* @__PURE__ */ f("span", {
													className: "hc-result-rank",
													children: n + 1
												}),
												/* @__PURE__ */ f(ot, { brand: r.brand }),
												/* @__PURE__ */ p("div", {
													className: "hc-result-person",
													children: [
														/* @__PURE__ */ f("strong", { children: S(t) }),
														/* @__PURE__ */ f("span", { children: re[r.brand] }),
														i !== void 0 && i > 0 && /* @__PURE__ */ f("small", { children: h("session.autopilot.share", { n: Math.round(i * 100) }) })
													]
												}),
												/* @__PURE__ */ p("div", {
													className: "hc-result-wealth",
													children: [/* @__PURE__ */ f("small", { children: h("games.horselesscarriage.finished") }), /* @__PURE__ */ p("b", { children: ["$", e.scores?.[t] ?? r.wealth] })]
												})
											]
										}, t);
									})
								}),
								/* @__PURE__ */ f("p", {
									className: "hc-result-tiebreak",
									children: h("games.horselesscarriage.tieRule")
								}),
								/* @__PURE__ */ f("div", {
									className: "hc-operating-data",
									children: /* @__PURE__ */ p("table", { children: [
										/* @__PURE__ */ f("caption", { children: h("games.horselesscarriage.operatingData") }),
										/* @__PURE__ */ f("thead", { children: /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", {}), e.ranking.map((e) => /* @__PURE__ */ f("th", { children: S(e) }, e))] }) }),
										/* @__PURE__ */ f("tbody", { children: [
											"capacity",
											"gantt",
											"factoryCount"
										].map((t) => /* @__PURE__ */ p("tr", { children: [/* @__PURE__ */ f("th", { children: h({
											factoryCount: "games.horselesscarriage.componentCount",
											capacity: "games.horselesscarriage.capacity",
											gantt: "games.horselesscarriage.gantt"
										}[t]) }), e.ranking.map((e) => {
											let n = g.players.find((t) => t.rid === e);
											return /* @__PURE__ */ f("td", { children: t === "factoryCount" ? n.tiles.length : n[t] }, e);
										})] }, t)) })
									] })
								}),
								l !== void 0 && /* @__PURE__ */ f("p", { children: h("session.hint.usedCount", { n: l }) })
							]
						}),
						/* @__PURE__ */ f("footer", {
							className: "hc-result-controls",
							children: u || m ? /* @__PURE__ */ p(d, { children: [u && /* @__PURE__ */ f(b, {
								label: h("session.result.playAgain"),
								confirmLabel: h("games.horselesscarriage.confirmAgain"),
								onConfirm: u,
								className: "hc-button"
							}), m && /* @__PURE__ */ f(b, {
								label: h("session.result.backToLobby"),
								confirmLabel: h("games.horselesscarriage.confirmLeave"),
								onConfirm: m,
								className: "hc-button"
							})] }) : /* @__PURE__ */ f("span", { children: h("session.result.waitHost") })
						})
					]
				})
			}),
			/* @__PURE__ */ f("button", {
				type: "button",
				className: "hc-result-restore hc-button",
				hidden: _,
				onClick: () => v(!0),
				children: h("games.horselesscarriage.annualReport")
			})
		]
	});
}
//#endregion
//#region src/games/horselesscarriage/options.tsx
function zt({ value: e, onChange: t }) {
	let n = s(), r = je.safeParse(e).data ?? je.parse(void 0);
	return /* @__PURE__ */ f(S, {
		title: n("games.horselesscarriage.mode"),
		children: [!1, !0].map((e) => /* @__PURE__ */ f(x, {
			name: "horselesscarriage-mode",
			value: String(e),
			checked: r.introductory === e,
			label: n(e ? "games.horselesscarriage.introMode" : "games.horselesscarriage.fullMode"),
			hint: e ? n("games.horselesscarriage.introHint") : void 0,
			accent: Ae.accent,
			onChange: () => t({ introductory: e })
		}, String(e)))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/horselesscarriage/entry.tsx
var Bt = {
	definition: nt,
	View: yt,
	bot: Nt,
	fx: It,
	OverView: Rt,
	Options: zt,
	locales: {
		zh: {
			name: "无马之车",
			desc: "在汽车工业的黎明，拼建工厂、研发技术，并争夺不断变化的市场。",
			rules: "目标：\n经营一家早期汽车工厂，通过销售车辆积累财富。游戏结束时财富最多者获胜；财富相同时，销售专注更高者获胜。\n准备：\n游戏支持3–5人。每人选择一位工业家，获得其17张需求牌、3个不同尺寸的经销商、4个营销部门，以及一块12行12列的主地板和6块6行8列的扩建板。先在主地板放置一个3行3列的研究部门和一个3行2列的规划部门，组件只能覆盖黑格，并通过边相邻的组件连到装卸区。装卸区和通道必须保持畅通。\n随机确定工程顺序，按相反顺序给予1至人数张甘特图。两条随机的活跃研发轨起始为1，其余研发轨起始为0；各产线产能为1。3、4、5人分别有24、32、40格时间。初始从中立牌抽取人数加1张，在象限I放置买家，最低价格区定价6。\n年度流程：\n每年依次进行以下步骤：\n· 进行研发。\n· 设置专注。\n· 建造工厂。\n· 印制销售册。\n· 销售汽车。\n· 检查是否结束游戏。\n· 改变预期。\n· 进行需求增长。\n游戏最多进行七年。\n研发：\n按上一年的工程顺序，每个研究部门必须推进一个不同标记一步。可以推进自己的产能，或任意玩家在五项技术上的研发；同一玩家本阶段不能重复推进同一标记。研发上限6，产能上限5；研发推进到第4或第6格、产能推进到第5格时，时间减少1。\n设置专注：\n甘特图最多者先行动，平手时工程顺序较高者先行。选择任意空位并清空自己的甘特图，或保留甘特图并跳过。跳过者按原工程相对顺序填入剩余位置。左侧工程优先，右侧销售优先。每年重新选择。\n建厂：\n按工程顺序，在现有地板上放置任意数量的组件，然后必须增加一块扩建板，直至6块扩建板用尽。扩建板必须与既有地板边相邻、对齐网格，且不能重叠或堵住任一装卸区向外的通道。新扩建区域从下一年起才能建造。\n以前年度的组件不能移动或移除。本年草稿可以调整，确认时整体布局必须合法。所有组件必须完全覆盖黑格、不重叠，并经连续组件连到装卸区。每条主线必须邻接经销商，每个经销商也必须邻接主线；营销部门必须邻接经销商。各组件和规格箭头供应有限，工程顺序决定取得优先权。\n技术与制造区：\n技术站和规格箭头标有A、B、C或D工序。它们只能通过同工序组件和主线对应的一侧连通；每个制造区必须包含主线，同一制造区不能出现两个同名技术站。不同制造区可以重复技术站。\n自己研发达到某项技术位置时，可以建造对应技术站和该位置的规格箭头。工程第一位也能使用至少1位其他玩家已研发的技术，第二位需要至少2位其他玩家，依次类推。每个技术站至少有一个邻接且指向自己的规格箭头。每个研发位置在同一技术站最多提供一个箭头；同一维度在轨道上重复出现的技术位置各提供一个贡献。\n已建技术和箭头不会因次年失去专利权限而失效；新增技术站或补充箭头仍要满足当年的权限。\n销售册：\n每个规划部门增加1张甘特图，最多20张；经过10时，时间减少1。每条主线的五项规格等于其各制造区内相应规格箭头的数量。一个经销商邻接多条主线时，每项规格取这些主线中的最低值，能够销售各主线的车型。\n销售窗口按相邻营销部门数量确定：\n· 没有相邻营销部门时，使用 1 行 2 列的窗口。\n· 有一个相邻营销部门时，使用 2 行 2 列的窗口。\n· 有至少两个相邻营销部门时，使用 3 行 3 列的窗口。\n销售：\n从销售专注最高者开始轮流销售。每次选择一个经销商和窗口内的一个细分格，必须向该格所有可满足的买家销售，直到对应产能用尽；同一格有多种可生产车型时必须同时销售。不能在有销售机会时跳过。每条主线每年的总产量不超过自己的产能，连接同一主线的经销商共享该限额；多条同类主线时可以选择消耗哪条产线。\n首次使用经销商时先放置窗口。窗口可伸出市场，可与其他窗口重叠，1行2列的窗口可横放或竖放；窗口内所有板内格的需求都不能超过经销商规格。所有五维最低规格也必须满足。放置后本年不得移动或旋转窗口。\n市场两个活跃维度按每两行或每两列提高1点需求；离场维度只要求最低规格。每辆车获得其价格区当前价格，卡车额外获得1，跑车额外获得2。四个价格区沿对角线划分，与用于放置需求的四个象限不同。年末收回窗口与已生产车辆，未售买家和火花留在市场。\n结束与预期：\n销售结束后，若时间已耗尽或已到第7年，游戏结束。否则淘汰箭头指向的活跃维度，其最低规格增加1，将其放到离场队尾。另一活跃维度成为下次淘汰对象。其余离场维度中，所有玩家超出创新标记的研发步数合计最多者入场；平手看最远研发，仍平手按离场顺序。新维度的坐标从其最低规格开始。\n需求增长：\n按工程顺序秘密选择一张需求牌和一个象限。只能打出最低年数不超过自身扩建板数量的牌，打出的牌永久弃置。卡牌方向与市场一致，不旋转。全部提交后，按象限I至IV揭示并加入对应火花；按牌面钟数减少时间。\n每个火花产生1位同车型买家，但每个细分格同车型的火花所产生买家总量不超过火花数量的2倍。再从洗混的中立牌中，分别给象限II和III各抽1张，给象限I抽取人数减2张，直接产生买家；中立牌产生的买家不受火花上限限制，之后全部中立牌收回重洗。\n从最高价格区向最低价格区，依次给有买家的价格区分配6、4、3、2；空区跳过，然后进入下一年。\n入门模式：\n移除所有含卡车或跑车的需求牌及中立牌，每人保留8张牌；所有主线均生产普通汽车。其他规则不变。",
			mode: "规则模式",
			fullMode: "完整基础版",
			introMode: "入门模式",
			introHint: "只销售普通汽车，每人8张需求牌。",
			industrialist: "选择工业家",
			setup: "摆放起始部门",
			researchPhase: "研发",
			focusPhase: "设置专注",
			buildPhase: "建造工厂",
			brochures: "印制销售册",
			sellPhase: "销售车辆",
			finishPhase: "年度结算",
			expectations: "改变预期",
			demandPhase: "选择需求",
			reveal: "揭示需求",
			grow: "需求增长",
			neutral: "自然需求",
			prices: "重新定价",
			done: "工业时代落幕",
			year: "第{{n}}年",
			clock: "剩余时间",
			wealth: "财富",
			gantt: "甘特图",
			capacity: "产能",
			factory: "工厂",
			market: "市场",
			technology: "技术",
			demand: "需求牌",
			history: "记录",
			close: "关闭",
			speed: "速度",
			reliability: "可靠性",
			design: "设计",
			range: "续航",
			safety: "安全性",
			chassis: "底盘",
			bumpers: "保险杠",
			body: "车身",
			radiator: "散热器",
			door: "车门",
			engine: "发动机",
			fuelTank: "油箱",
			gears: "变速器",
			brakes: "制动器",
			steering: "方向盘",
			dashboard: "仪表盘",
			battery: "蓄电池",
			paint: "涂装",
			claxon: "喇叭",
			windshield: "挡风玻璃",
			tires: "轮胎",
			headlights: "前灯",
			car: "普通汽车",
			truck: "卡车",
			sports: "跑车",
			dealer: "经销商",
			planning: "规划部门",
			research: "研究部门",
			marketing: "营销部门",
			spec: "规格箭头",
			loading: "装卸区",
			clear: "保持畅通",
			yourTurn: "请完成当前行动",
			waiting: "等待{{name}}",
			settling: "正在结算",
			chooseBrand: "选择这位工业家",
			unavailable: "已选",
			startHint: "摆放一个研究部门和一个规划部门，然后确认。",
			buildHint: "选择组件，在地板上摆放；完成后放置扩建板。",
			researchHint: "选择{{n}}个不同标记，各推进一步。",
			focusHint: "选择空位并清空甘特图，或保留甘特图并跳过。",
			salesHint: "选择经销商、细分格及销售窗口。",
			demandHint: "选择一张需求牌和一个象限。",
			confirmStart: "确认起始布局",
			confirmBuild: "确认建厂",
			confirmResearch: "确认研发",
			confirmDemand: "提交需求",
			confirmSale: "销售车辆",
			pass: "保留甘特图",
			components: "组件供应",
			departments: "部门",
			lines: "主线与经销商",
			stations: "技术站",
			arrows: "规格箭头",
			expansion: "扩建板",
			placeExpansion: "放置扩建板",
			remove: "移除草稿组件",
			rotate: "旋转",
			cancel: "取消选择",
			clearDraft: "清空草稿",
			selected: "已选择",
			draft: "本年草稿",
			oldTile: "往年组件",
			valid: "布局合法",
			size: "{{w}}×{{h}}",
			remaining: "剩余{{n}}",
			fullFactory: "工厂全景",
			placeTile: "放置组件",
			moveTile: "移动草稿组件",
			confirmExpansion: "保留扩建位置",
			selectStation: "选择要升级的技术站",
			chooseSpec: "选择规格贡献",
			level: "研发位置{{n}}",
			addSpec: "放置规格箭头",
			engineering: "工程",
			sales: "销售",
			focusSlot: "第{{n}}位",
			minimum: "最低规格",
			obsolete: "下年淘汰",
			access: "专利权限",
			window: "销售窗口",
			nextWindow: "切换窗口位置",
			turnWindow: "横竖切换",
			sold: "本年已生产",
			income: "收入{{n}}",
			buyerCount: "{{n}}位买家",
			sparkCount: "{{n}}个火花",
			allocate: "分配产线",
			allocationHint: "选择各条主线本次生产的数量。",
			niche: "细分格（{{x}}，{{y}}）",
			earliest: "至少{{n}}块扩建板",
			clocks: "时间减少{{n}}",
			quadrant: "象限{{n}}",
			played: "已提交",
			cardNumber: "需求牌{{n}}",
			noSparks: "不增加火花",
			finished: "最终财富",
			winner: "{{name}}赢得胜利",
			returnFactory: "查看工厂",
			playAgain: "再来一局",
			backLobby: "返回大堂",
			rank: "第{{n}}名",
			factoryCount: "{{n}}块组件",
			componentCount: "组件数",
			annualReport: "汽车工业 · 经营结算单",
			operatingData: "最终经营数据",
			tieRule: "财富相同时，最终销售专注更高者排名在前。",
			confirmAgain: "确认开始新局",
			confirmLeave: "确认返回大堂",
			logSetup: "汽车工业的竞争开始。",
			logResearch: "{{name}}完成{{n}}次研发。",
			logFocus: "{{name}}选择专注位置{{n}}。",
			logPass: "{{name}}保留甘特图。",
			logBuild: "{{name}}建造{{n}}块组件并完成年度扩建。",
			logBrochures: "{{name}}获得{{n}}张甘特图。",
			logSale: "{{name}}销售车辆，获得{{n}}财富。",
			logFinish: "本局游戏结束。",
			logExpectations: "{{dim}}成为活跃市场需求。",
			logDemand: "{{name}}在象限{{q}}打出需求牌{{n}}。",
			logGrow: "火花产生{{n}}位新买家。",
			logNeutral: "象限{{q}}出现自然买家。",
			logPrices: "各价格区已重新定价。",
			errTurn: "当前尚未轮到你行动。",
			errPhase: "当前阶段不能执行此操作。",
			errBrand: "这位工业家已被其他玩家选择。",
			errResearch: "请为每个研究部门选择一个不同且可以推进的标记。",
			errFocus: "请选择尚未占用的专注位置。",
			errSale: "这个经销商、窗口或细分格当前无法完成销售。",
			errDemand: "这张牌不在手中，或尚未达到所需扩建数量。",
			errAllocation: "各主线生产数量必须与本次销售一致，且不能超过剩余产能。",
			errOverlap: "组件不能重叠，请调整摆放位置。",
			errOutside: "组件必须完全放在黑色工厂地板上。",
			errDisconnected: "每块组件必须通过连续相邻组件连到装卸区。",
			errDealer: "每条主线与每个经销商都必须彼此邻接。",
			errMarketing: "营销部门必须邻接经销商。",
			errTechnology: "当前没有所选技术或规格的使用权限。",
			errSpec: "每个技术站至少需要一个指向自己的规格箭头。",
			errArrow: "规格箭头必须指向相应技术站，同一研发位置不能重复。",
			errDuplicate: "同一制造区不能有两个同名技术站。",
			errManufacturing: "技术站和规格箭头必须经同工序制造区连接主线。",
			errStock: "这类组件或规格箭头的供应不足。",
			errExpansion: "扩建板必须邻接既有地板，不能重叠或堵住装卸通道。",
			errStart: "起始布局必须恰好包含一个研究部门和一个规划部门。"
		},
		en: {
			name: "Horseless Carriage",
			desc: "Build a factory, research new technologies and compete for a changing automobile market.",
			rules: "Objective:\nSell vehicles and accumulate the most wealth. Ties are won by the tied player with the higher sales focus.\nSetup:\nFor 3–5 players. Choose an industrialist and take their 17 demand cards, 3 differently sized dealerships, 4 marketing departments, a 12×12 main factory floor and 6 expansions measuring 8×6. Place one 3×3 research department and one 2×3 planning department on the main floor. Tiles may cover only black squares and must connect by adjacent tiles to a loading bay. Loading bays and their exits must remain clear.\nRandomize engineering order and give 1 through the player count Gantt charts in reverse order. Research starts at 1 on two random active dimensions and at 0 elsewhere. Assembly capacity starts at 1. The timecard starts at 24, 32 or 40 for 3, 4 or 5 players. Draw player count plus 1 neutral cards and add their buyers to quadrant I. The lowest price segment starts at 6.\nEach year:\nEach year, complete these steps in order:\n· Conduct research.\n· Set focus.\n· Build the factory.\n· Print sales brochures.\n· Sell cars.\n· Check whether the game ends.\n· Advance expectations.\n· Grow demand.\nPlay at most 7 years.\nResearch:\nIn last year's engineering order, advance a different marker once for each research department. Advance your own assembly capacity or any player's marker on any research track. You cannot advance the same marker twice on your turn. Research is capped at 6 and capacity at 5. Reaching research position 4 or 6, or capacity 5, reduces time by 1.\nSet focus:\nThe player with the most Gantt charts acts first. Break ties by engineering order. Choose any empty focus slot and spend all your Gantt charts, or pass and keep them. Passing players fill remaining slots while preserving their previous engineering order. The left side has engineering priority; the right side has sales priority. Choose again every year.\nBuild the factory:\nIn engineering order, add any number of tiles to the existing floor, then add one mandatory expansion until all 6 are used. Expansions must share an edge with the factory, align with its grid and neither overlap nor block any loading bay's outward exits. Build on the new expansion starting next year.\nTiles from earlier years can never move or be removed. You can edit this year's draft before confirming a complete legal layout. Tiles must fit entirely on black floor squares without overlap and connect through adjacent tiles to a loading bay. Every mainline needs an adjacent dealership and every dealership needs an adjacent mainline. Marketing departments must touch a dealership. Tiles and spec indicators are limited; engineering order decides priority.\nTechnologies and manufacturing zones:\nTechnology stations and spec indicators have manufacturing steps A, B, C or D. They connect through matching steps to the corresponding side of a mainline. Every zone must contain a mainline and may contain only one of each named technology station. Separate zones may repeat a station.\nReaching a technology's research position gives access to its station and that position's spec indicator. First in engineering also has access to research reached by at least 1 other player; second needs at least 2 others, and so on. Every station needs at least one adjacent spec indicator pointing at it. Each research position can contribute once per station; repeated occurrences of a technology on one dimension provide separate contributions.\nBuilt stations and indicators continue functioning after access is lost. New stations or indicators still require current access.\nSales brochures:\nEach planning department adds 1 Gantt chart, up to 20. Crossing 10 reduces time by 1. A mainline's specs equal its connected spec indicators in all four manufacturing zones. If a dealer touches several mainlines, each spec is the lowest among those lines. It sells all connected vehicle types.\nChoose the sales window from the number of adjacent marketing departments:\n· With none, use a 2×1 window.\n· With one, use a 2×2 window.\n· With at least two, use a 3×3 window.\nSales:\nTake turns from highest sales focus. Activate one dealership and sell in one niche inside its window. Sell to every possible buyer there, up to remaining capacity, including all vehicle types that dealer can produce. You must sell if possible. Each mainline produces at most your assembly capacity per year; dealerships connected to the same line share that limit. You may choose how production is divided among multiple lines of the same type.\nPlace a dealer's window on its first sale. Windows may extend beyond the market and overlap any other window. The 2×1 window can be horizontal or vertical. Every on-board niche inside must meet the dealer's specs, and all five minimum specs must be met. A placed window cannot move or rotate that year.\nThe two active dimensions increase requirements by 1 for every two rows or columns; off-board dimensions require only their minimum. Earn the niche's current segment price for each car, plus 1 for trucks or 2 for sports cars. The four price segments run diagonally and differ from the four demand quadrants. At year end, remove windows and produced vehicles; unsold buyers and sparks remain.\nEnd and expectations:\nAfter sales, end if time is exhausted or it is year 7. Otherwise remove the active dimension indicated by the obsolescence marker, increase its minimum by 1 and put it last in the off-board order. The other active dimension becomes next to leave. Among the other off-board dimensions, introduce the one with the greatest total research steps beyond its innovation indicator. Break ties by the furthest research marker, then off-board order. Its axis starts at its minimum spec.\nGrow demand:\nIn engineering order, secretly choose one demand card and one quadrant. A card's minimum year cannot exceed your number of expansions. Cards are permanently discarded and align with the market without rotation. After everyone submits, reveal by quadrants I to IV, add the pictured sparks and reduce time by the printed clocks.\nEach spark creates 1 buyer of its type, up to 2 buyers per spark of that type in each niche. Then shuffle neutral cards and draw one for quadrant II, one for III, and player count minus 2 for I. These directly add buyers without the spark limit. Return all neutral cards and reshuffle each year.\nFrom highest segment to lowest, assign 6, 4, 3 and 2 to occupied price segments, skipping empty segments. Begin the next year.\nIntroductory rules:\nRemove every demand or neutral card depicting trucks or sports cars, leaving 8 cards per player. Every mainline produces normal cars. All other rules remain unchanged.",
			mode: "Rules",
			fullMode: "Full base game",
			introMode: "Introductory game",
			introHint: "Only normal cars; 8 demand cards per player.",
			industrialist: "Choose an industrialist",
			setup: "Place starting departments",
			researchPhase: "Research",
			focusPhase: "Set focus",
			buildPhase: "Build factory",
			brochures: "Print sales brochures",
			sellPhase: "Sell vehicles",
			finishPhase: "Year end",
			expectations: "Advance expectations",
			demandPhase: "Choose demand",
			reveal: "Reveal demand",
			grow: "Grow demand",
			neutral: "Spontaneous demand",
			prices: "Set prices",
			done: "The automobile age",
			year: "Year {{n}}",
			clock: "Time remaining",
			wealth: "Wealth",
			gantt: "Gantt charts",
			capacity: "Capacity",
			factory: "Factory",
			market: "Market",
			technology: "Technology",
			demand: "Demand cards",
			history: "History",
			close: "Close",
			speed: "Speed",
			reliability: "Reliability",
			design: "Design",
			range: "Range",
			safety: "Safety",
			chassis: "Chassis",
			bumpers: "Bumpers",
			body: "Body",
			radiator: "Radiator",
			door: "Door",
			engine: "Engine",
			fuelTank: "Fuel tank",
			gears: "Gears",
			brakes: "Brakes",
			steering: "Steering wheel",
			dashboard: "Dashboard",
			battery: "Battery",
			paint: "Paint",
			claxon: "Claxon",
			windshield: "Windshield",
			tires: "Tires",
			headlights: "Headlights",
			car: "Normal car",
			truck: "Truck",
			sports: "Sports car",
			dealer: "Dealership",
			planning: "Planning department",
			research: "Research department",
			marketing: "Marketing department",
			spec: "Spec indicator",
			loading: "Loading bay",
			clear: "Keep clear",
			yourTurn: "Complete your action",
			waiting: "Waiting for {{name}}",
			settling: "Resolving",
			chooseBrand: "Choose industrialist",
			unavailable: "Taken",
			startHint: "Place one research and one planning department, then confirm.",
			buildHint: "Select and place tiles, then place an expansion.",
			researchHint: "Choose {{n}} different markers to advance one step.",
			focusHint: "Choose a free slot and spend all Gantt charts, or pass to keep them.",
			salesHint: "Choose a dealer, a niche and a market window.",
			demandHint: "Choose one demand card and a quadrant.",
			confirmStart: "Confirm starting layout",
			confirmBuild: "Confirm factory",
			confirmResearch: "Confirm research",
			confirmDemand: "Submit demand",
			confirmSale: "Sell vehicles",
			pass: "Keep Gantt charts",
			components: "Tile supply",
			departments: "Departments",
			lines: "Mainlines & dealers",
			stations: "Technology stations",
			arrows: "Spec indicators",
			expansion: "Expansion",
			placeExpansion: "Place expansion",
			remove: "Remove draft tile",
			rotate: "Rotate",
			cancel: "Cancel selection",
			clearDraft: "Clear draft",
			selected: "Selected",
			draft: "This year’s draft",
			oldTile: "Previous year’s tile",
			valid: "Legal layout",
			size: "{{w}}×{{h}}",
			remaining: "{{n}} remaining",
			selectStation: "Choose a station to upgrade",
			chooseSpec: "Choose a spec contribution",
			level: "Research position {{n}}",
			addSpec: "Place spec indicator",
			fullFactory: "Full factory",
			placeTile: "Place tile",
			moveTile: "Move draft tile",
			confirmExpansion: "Keep expansion position",
			engineering: "Engineering",
			sales: "Sales",
			focusSlot: "Slot {{n}}",
			minimum: "Minimum specs",
			obsolete: "Next to leave",
			access: "Patent access",
			window: "Market window",
			nextWindow: "Next window position",
			turnWindow: "Change orientation",
			sold: "Produced this year",
			income: "Income {{n}}",
			buyerCount: "{{n}} buyers",
			sparkCount: "{{n}} sparks",
			allocate: "Allocate production",
			allocationHint: "Choose how many vehicles each mainline produces.",
			niche: "Niche ({{x}}, {{y}})",
			earliest: "Expansions required: {{n}}",
			clocks: "Reduce time by {{n}}",
			quadrant: "Quadrant {{n}}",
			played: "Submitted",
			cardNumber: "Demand card {{n}}",
			noSparks: "No added sparks",
			finished: "Final wealth",
			winner: "{{name}} wins",
			returnFactory: "Inspect factories",
			playAgain: "Play again",
			backLobby: "Back to lobby",
			rank: "Rank {{n}}",
			factoryCount: "{{n}} tiles",
			componentCount: "Components",
			annualReport: "Automobile Industry · Final Report",
			operatingData: "Final operating figures",
			tieRule: "Equal wealth is broken by the higher final sales focus.",
			confirmAgain: "Confirm new game",
			confirmLeave: "Confirm return to lobby",
			logSetup: "The automobile industry begins.",
			logResearch: "{{name}} advances {{n}} research markers.",
			logFocus: "{{name}} chooses focus slot {{n}}.",
			logPass: "{{name}} keeps their Gantt charts.",
			logBuild: "{{name}} adds {{n}} tiles and completes the annual expansion.",
			logBrochures: "{{name}} gains {{n}} Gantt charts.",
			logSale: "{{name}} sells vehicles for {{n}} wealth.",
			logFinish: "The game has ended.",
			logExpectations: "{{dim}} becomes an active market requirement.",
			logDemand: "{{name}} plays demand card {{n}} in quadrant {{q}}.",
			logGrow: "Sparks create {{n}} new buyers.",
			logNeutral: "Spontaneous buyers arrive in quadrant {{q}}.",
			logPrices: "All price segments have been repriced.",
			errTurn: "It is not your turn.",
			errPhase: "This action is unavailable in the current phase.",
			errBrand: "Another player has chosen that industrialist.",
			errResearch: "Choose a different available marker for each research department.",
			errFocus: "Choose an unoccupied focus slot.",
			errSale: "That dealer, window or niche cannot make this sale.",
			errDemand: "That card is not in your hand or requires more expansions.",
			errAllocation: "Production must match the sale without exceeding each mainline’s remaining capacity.",
			errOverlap: "Tiles cannot overlap. Adjust their placement.",
			errOutside: "Tiles must fit entirely on black factory floor squares.",
			errDisconnected: "Every tile must connect through adjacent tiles to a loading bay.",
			errDealer: "Every mainline and dealership needs a neighboring counterpart.",
			errMarketing: "Marketing departments must touch a dealership.",
			errTechnology: "You do not currently have access to that technology or spec.",
			errSpec: "Every technology station needs a spec indicator pointing at it.",
			errArrow: "Point the indicator at its matching station without repeating a research position.",
			errDuplicate: "A manufacturing zone cannot contain two stations with the same name.",
			errManufacturing: "Stations and indicators must connect through their manufacturing step to a mainline.",
			errStock: "There are not enough of those tiles or spec indicators.",
			errExpansion: "Expansions must touch the factory without overlapping or blocking loading bay exits.",
			errStart: "Start with exactly one research and one planning department."
		}
	}
};
//#endregion
export { Bt as default };
