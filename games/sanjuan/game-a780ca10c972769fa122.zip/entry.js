import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { useT as a } from "@bgparty/sdk/i18n";
import { IconCheck as o, IconClose as s, IconInfo as c } from "@bgparty/sdk/icons";
import { useFxAnchor as l } from "@bgparty/sdk/fx/anchors";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as d } from "@bgparty/sdk/ui/phase-banner";
import { HintRing as f } from "@bgparty/sdk/ui/hint-ring";
import { gameAssetUrl as p } from "@bgparty/sdk/assets";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { FlySprite as _, PulseBox as v } from "@bgparty/sdk/fx/primitives";
import { OptionSwitch as y } from "@bgparty/sdk/ui/game-options";
//#region src/games/sanjuan/data.ts
var b = {
	indigo: {
		cost: 1,
		vp: 1,
		count: 10,
		production: !0,
		expansion: !1,
		name: "games.sanjuan.indigo",
		text: "games.sanjuan.indigoText"
	},
	sugar: {
		cost: 2,
		vp: 1,
		count: 8,
		production: !0,
		expansion: !1,
		name: "games.sanjuan.sugar",
		text: "games.sanjuan.sugarText"
	},
	tobacco: {
		cost: 3,
		vp: 2,
		count: 8,
		production: !0,
		expansion: !1,
		name: "games.sanjuan.tobacco",
		text: "games.sanjuan.tobaccoText"
	},
	coffee: {
		cost: 4,
		vp: 2,
		count: 8,
		production: !0,
		expansion: !1,
		name: "games.sanjuan.coffee",
		text: "games.sanjuan.coffeeText"
	},
	silver: {
		cost: 5,
		vp: 3,
		count: 8,
		production: !0,
		expansion: !1,
		name: "games.sanjuan.silver",
		text: "games.sanjuan.silverText"
	},
	archive: {
		cost: 1,
		vp: 1,
		count: 3,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.archive",
		text: "games.sanjuan.archiveText"
	},
	goldMine: {
		cost: 1,
		vp: 1,
		count: 3,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.goldMine",
		text: "games.sanjuan.goldMineText"
	},
	smithy: {
		cost: 1,
		vp: 1,
		count: 3,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.smithy",
		text: "games.sanjuan.smithyText"
	},
	poorHouse: {
		cost: 2,
		vp: 1,
		count: 3,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.poorHouse",
		text: "games.sanjuan.poorHouseText"
	},
	blackMarket: {
		cost: 2,
		vp: 1,
		count: 3,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.blackMarket",
		text: "games.sanjuan.blackMarketText"
	},
	tradingPost: {
		cost: 2,
		vp: 1,
		count: 3,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.tradingPost",
		text: "games.sanjuan.tradingPostText"
	},
	well: {
		cost: 2,
		vp: 1,
		count: 3,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.well",
		text: "games.sanjuan.wellText"
	},
	marketStand: {
		cost: 2,
		vp: 1,
		count: 3,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.marketStand",
		text: "games.sanjuan.marketStandText"
	},
	crane: {
		cost: 2,
		vp: 1,
		count: 3,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.crane",
		text: "games.sanjuan.craneText"
	},
	chapel: {
		cost: 3,
		vp: 2,
		count: 3,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.chapel",
		text: "games.sanjuan.chapelText"
	},
	tower: {
		cost: 3,
		vp: 2,
		count: 3,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.tower",
		text: "games.sanjuan.towerText"
	},
	aqueduct: {
		cost: 3,
		vp: 2,
		count: 3,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.aqueduct",
		text: "games.sanjuan.aqueductText"
	},
	carpenter: {
		cost: 3,
		vp: 2,
		count: 3,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.carpenter",
		text: "games.sanjuan.carpenterText"
	},
	statue: {
		cost: 3,
		vp: 3,
		count: 3,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.statue",
		text: "games.sanjuan.statueText"
	},
	marketHall: {
		cost: 4,
		vp: 2,
		count: 3,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.marketHall",
		text: "games.sanjuan.marketHallText"
	},
	prefecture: {
		cost: 4,
		vp: 2,
		count: 3,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.prefecture",
		text: "games.sanjuan.prefectureText"
	},
	quarry: {
		cost: 4,
		vp: 2,
		count: 3,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.quarry",
		text: "games.sanjuan.quarryText"
	},
	victoryColumn: {
		cost: 4,
		vp: 4,
		count: 3,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.victoryColumn",
		text: "games.sanjuan.victoryColumnText"
	},
	library: {
		cost: 5,
		vp: 3,
		count: 3,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.library",
		text: "games.sanjuan.libraryText"
	},
	hero: {
		cost: 5,
		vp: 5,
		count: 3,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.hero",
		text: "games.sanjuan.heroText"
	},
	cityHall: {
		cost: 6,
		vp: 0,
		count: 2,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.cityHall",
		text: "games.sanjuan.cityHallText"
	},
	guildHall: {
		cost: 6,
		vp: 0,
		count: 2,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.guildHall",
		text: "games.sanjuan.guildHallText"
	},
	palace: {
		cost: 6,
		vp: 0,
		count: 2,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.palace",
		text: "games.sanjuan.palaceText"
	},
	triumphalArch: {
		cost: 6,
		vp: 0,
		count: 2,
		production: !1,
		expansion: !1,
		name: "games.sanjuan.triumphalArch",
		text: "games.sanjuan.triumphalArchText"
	},
	guardRoom: {
		cost: 1,
		vp: 1,
		count: 3,
		production: !1,
		expansion: !0,
		name: "games.sanjuan.guardRoom",
		text: "games.sanjuan.guardRoomText"
	},
	officeBuilding: {
		cost: 1,
		vp: 1,
		count: 3,
		production: !1,
		expansion: !0,
		name: "games.sanjuan.officeBuilding",
		text: "games.sanjuan.officeBuildingText"
	},
	hut: {
		cost: 1,
		vp: 1,
		count: 3,
		production: !1,
		expansion: !0,
		name: "games.sanjuan.hut",
		text: "games.sanjuan.hutText"
	},
	tavern: {
		cost: 2,
		vp: 1,
		count: 3,
		production: !1,
		expansion: !0,
		name: "games.sanjuan.tavern",
		text: "games.sanjuan.tavernText"
	},
	bank: {
		cost: 3,
		vp: 2,
		count: 3,
		production: !1,
		expansion: !0,
		name: "games.sanjuan.bank",
		text: "games.sanjuan.bankText"
	},
	customsOffice: {
		cost: 3,
		vp: 2,
		count: 3,
		production: !1,
		expansion: !0,
		name: "games.sanjuan.customsOffice",
		text: "games.sanjuan.customsOfficeText"
	},
	park: {
		cost: 3,
		vp: 2,
		count: 3,
		production: !1,
		expansion: !0,
		name: "games.sanjuan.park",
		text: "games.sanjuan.parkText"
	},
	harbor: {
		cost: 4,
		vp: 2,
		count: 3,
		production: !1,
		expansion: !0,
		name: "games.sanjuan.harbor",
		text: "games.sanjuan.harborText"
	},
	goldsmith: {
		cost: 5,
		vp: 3,
		count: 3,
		production: !1,
		expansion: !0,
		name: "games.sanjuan.goldsmith",
		text: "games.sanjuan.goldsmithText"
	},
	residence: {
		cost: 6,
		vp: 0,
		count: 2,
		production: !1,
		expansion: !0,
		name: "games.sanjuan.residence",
		text: "games.sanjuan.residenceText"
	},
	cathedral: {
		cost: 7,
		vp: 0,
		count: 1,
		production: !1,
		expansion: !0,
		name: "games.sanjuan.cathedral",
		text: "games.sanjuan.cathedralText"
	}
}, x = Object.keys(b), S = [
	"indigo",
	"sugar",
	"tobacco",
	"coffee",
	"silver"
], ee = [
	"builder",
	"producer",
	"trader",
	"councillor",
	"prospector"
], te = {
	builder: "games.sanjuan.builder",
	producer: "games.sanjuan.producer",
	trader: "games.sanjuan.trader",
	councillor: "games.sanjuan.councillor",
	prospector: "games.sanjuan.prospector"
}, ne = {
	builder: "🏗️",
	producer: "📦",
	trader: "⛵",
	councillor: "📜",
	prospector: "⛏️"
}, re = [
	[
		1,
		1,
		1,
		2,
		2
	],
	[
		1,
		1,
		2,
		2,
		2
	],
	[
		1,
		1,
		2,
		2,
		3
	],
	[
		1,
		2,
		2,
		2,
		3
	],
	[
		1,
		2,
		2,
		3,
		3
	]
], C = x.filter((e) => e !== "cathedral").flatMap((e) => Array.from({ length: b[e].count }, () => ({
	kind: e,
	expansion: b[e].expansion
})));
for (let e of [
	"indigo",
	"tobacco",
	"coffee",
	"silver"
]) C.push({
	kind: e,
	expansion: !0
});
var w = C.length;
C.push({
	kind: "cathedral",
	expansion: !0
});
var T = (e) => C[e].kind, E = (e) => b[T(e)], ie = {
	id: "sanjuan",
	tier: "alpha",
	mechanics: [
		"hand-management",
		"engine-building",
		"drafting"
	],
	interactionTags: [],
	nameKey: "games.sanjuan.name",
	descKey: "games.sanjuan.desc",
	rulesKey: "games.sanjuan.rules",
	icon: "🏛️",
	iconImg: "games/sanjuan.webp",
	rulesUrl: { en: "https://robert-milstead-5xqr.squarespace.com/s/San-Juan-2nd-Edition-Rules.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#625084",
	releasedAt: "2026-10-31T14:34:17+08:00",
	search: {
		py: "sheng hu an",
		init: "sha"
	},
	hotseat: "cover"
}, D = t.enum([
	"builder",
	"producer",
	"trader",
	"councillor",
	"prospector"
]), O = t.int().min(0).max(143), k = t.array(O).max(144), A = t.object({
	expansion: t.boolean().default(!1),
	variedStart: t.boolean().default(!1)
}).prefault({}), j = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("role"),
		role: D,
		library: t.boolean().default(!1)
	}),
	t.object({
		type: t.literal("build"),
		card: O,
		pay: k,
		cover: O.nullable().default(null),
		goods: k.default([])
	}),
	t.object({
		type: t.literal("produce"),
		buildings: k
	}),
	t.object({
		type: t.literal("trade"),
		buildings: k,
		harbor: O.nullable().default(null)
	}),
	t.object({
		type: t.literal("keep"),
		cards: k
	}),
	t.object({
		type: t.literal("prospect"),
		mine: t.boolean(),
		smith: t.boolean()
	}),
	t.object({
		type: t.literal("office"),
		cards: k
	}),
	t.object({
		type: t.literal("deposit"),
		chapel: O.nullable(),
		bank: k
	}),
	t.object({
		type: t.literal("discard"),
		cards: k
	}),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), ae = t.enum([
	"role",
	"build",
	"produce",
	"trade",
	"council",
	"prospect",
	"office",
	"deposit",
	"limit",
	"start",
	"settle",
	"done"
]), oe = t.object({
	card: O,
	good: t.boolean(),
	covered: t.int().nonnegative()
}), se = t.object({
	buildings: t.int(),
	deposits: t.int(),
	guild: t.int(),
	city: t.int(),
	arch: t.int(),
	residence: t.int(),
	cathedral: t.int(),
	palace: t.int(),
	total: t.int(),
	tie: t.int()
}), ce = t.object({
	rid: t.string(),
	event: t.enum([
		"role",
		"build",
		"produce",
		"trade",
		"council",
		"bonus",
		"prospect",
		"mine",
		"smith",
		"office",
		"deposit",
		"discard",
		"pass",
		"round"
	]),
	n: t.int(),
	card: O.optional(),
	role: D.optional()
}), le = t.object({
	phase: ae,
	turn: t.string(),
	governor: t.string(),
	chooser: t.string(),
	round: t.int().positive(),
	role: D.nullable(),
	used: t.array(D),
	privilege: t.int().min(1).max(2),
	market: t.array(t.int().min(1).max(3)).length(5).nullable(),
	deckCount: t.int().nonnegative(),
	discardCount: t.int().nonnegative(),
	cathedral: t.boolean(),
	config: A,
	players: t.array(t.object({
		rid: t.string(),
		handCount: t.int().nonnegative(),
		buildings: t.array(oe),
		libraryUsed: t.boolean(),
		bankUsed: t.boolean(),
		score: se.nullable()
	})),
	log: t.array(ce)
}), M = t.object({
	hand: k,
	drawn: k,
	keepCount: t.int().nonnegative(),
	deposits: t.int().nonnegative(),
	mineCards: k
}), N = (e, t) => e.buildings.some((e) => T(e.card) === t), P = () => ({ code: "games.sanjuan.errAction" }), F = (e) => new Set(e).size === e.length, I = (e, t) => F(e) && e.every((e) => t.includes(e)), L = (e) => e.players[e.actor], R = (e, t) => {
	e.log.push(t), e.log.length > 40 && e.log.shift();
};
function z(t, n) {
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function B(e, t) {
	let n = [];
	for (let r = 0; r < t; r++) {
		!e.deck.length && e.discard.length && (e.deck = z(e, e.discard), e.discard = []);
		let t = e.deck.pop();
		if (t === void 0) break;
		n.push(t);
	}
	return n;
}
function V(e, t, n, r = []) {
	let i = n.filter((e) => e.n > 0);
	i.length && (e.pop(), e.push({
		kind: "movement",
		rid: t,
		data: { moves: i },
		for: [t],
		secret: { incoming: r }
	}));
}
function H(e, t, n, r, i = "supply", a = `hand:${r.rid}`) {
	R(e, r), e.phase = "settle", e.resume = t, e.beat = 480;
	let o = a.startsWith("hand:") ? e.players.find((e) => e.rid === r.rid).hand.slice(-r.n || Infinity) : [];
	n.push({
		kind: "transfer",
		rid: r.rid,
		data: {
			from: i,
			to: a,
			event: r.event,
			n: r.n,
			...r.card === void 0 ? {} : { card: r.card }
		},
		for: [r.rid],
		secret: { incoming: o }
	});
}
function U(e, t) {
	return N(t, "tower") ? 12 : !N(t, "guardRoom") && e.some((e) => N(e, "guardRoom")) ? 6 : 7;
}
function ue(e, t, n, r = null, i = 0) {
	let a = e.buildings.find((e) => e.card === r);
	return Math.max(0, E(t).cost - n - +!!N(e, E(t).production ? "smithy" : "quarry") - i - (a ? T(a.card) === "park" ? 6 : E(a.card).cost : 0));
}
function de(e, t) {
	return 1 + t + Number(N(e, "aqueduct"));
}
function fe(e, t) {
	return 1 + t + Number(N(e, "tradingPost"));
}
function pe(e) {
	let t = /* @__PURE__ */ new Map();
	e.forEach((e) => t.set(T(e), (t.get(T(e)) ?? 0) + 1));
	let n = [...t.entries()], r = /* @__PURE__ */ new Map(), i = (e) => {
		let t = e.join(",");
		if (r.has(t)) return r.get(t);
		let n = 0;
		for (let t = 0; t < e.length; t++) for (let r = t + 1; r < e.length; r++) for (let a = r + 1; a < e.length; a++) {
			if (!e[t] || !e[r] || !e[a]) continue;
			let o = [...e];
			o[t]--, o[r]--, o[a]--, n = Math.max(n, 1 + i(o));
		}
		return r.set(t, n), n;
	};
	return i(n.map((e) => e[1]));
}
function me(e, t) {
	let n = t.buildings.map((e) => e.card), r = n.filter((e) => E(e).production), i = [
		"statue",
		"victoryColumn",
		"hero"
	].filter((e) => n.some((t) => T(t) === e)).length, a = 0;
	if (N(t, "residence")) for (let e = 1; e <= 7; e++) a += pe(n.filter((t) => E(t).cost === e));
	let o = e.players.filter((e) => e !== t).flatMap((e) => e.buildings).filter((e) => E(e.card).cost === 6).length, s = {
		buildings: n.reduce((e, t) => e + E(t).vp, 0),
		deposits: t.deposits.length,
		guild: N(t, "guildHall") ? r.length + new Set(r.map(T)).size : 0,
		city: N(t, "cityHall") ? n.length - r.length : 0,
		arch: N(t, "triumphalArch") ? [
			0,
			4,
			6,
			8
		][i] : 0,
		residence: N(t, "residence") ? [
			0,
			4,
			7,
			9,
			10
		][Math.min(4, a)] : 0,
		cathedral: N(t, "cathedral") ? [
			0,
			4,
			7,
			9,
			10
		][Math.min(4, o)] : 0,
		palace: 0,
		total: 0,
		tie: t.hand.length + t.buildings.filter((e) => e.good !== null).length
	};
	return s.total = s.buildings + s.deposits + s.guild + s.city + s.arch + s.residence + s.cathedral, s.palace = N(t, "palace") ? Math.floor(s.total / 4) : 0, s.total += s.palace, s;
}
function he(e, t) {
	let n = L(e), r = e.actor === e.selector ? e.privilege : 0;
	e.role === "councillor" ? (e.drawn = B(e, 2 + r * 3), e.keepCount = Math.min(e.drawn.length, 1 + Number(N(n, "prefecture"))), e.phase = "council", t.push({
		kind: "movement",
		rid: n.rid,
		data: { moves: [{
			from: "supply",
			to: `hand:${n.rid}`,
			n: e.drawn.length
		}] },
		for: [n.rid],
		secret: { incoming: e.drawn }
	})) : e.phase = {
		builder: "build",
		producer: "produce",
		trader: "trade",
		prospector: "prospect"
	}[e.role];
}
function ge(e) {
	if (e.role = null, e.marketShown = !1, e.selected >= (e.players.length === 2 ? 3 : e.players.length)) {
		e.round++, e.governor = (e.governor + 1) % e.players.length, e.used = [], e.selected = 0;
		for (let t of e.players) t.libraryUsed = !1;
		e.actor = e.governor, e.roundStep = 0, e.phase = "office", _e(e), R(e, {
			rid: e.players[e.governor].rid,
			event: "round",
			n: e.round
		});
	} else e.selector = (e.governor + e.selected) % e.players.length, e.actor = e.selector, e.phase = "role";
}
function _e(e) {
	for (let t = 0; t < e.players.length * 3 + 1; t++) {
		let t = L(e), n = e.roundStep === 0 ? N(t, "officeBuilding") && t.hand.length > 0 : e.roundStep === 1 ? (N(t, "chapel") || N(t, "bank") && !t.bankUsed) && t.hand.length > 0 : t.hand.length > U(e.players, t);
		if (e.phase = e.roundStep === 0 ? "office" : e.roundStep === 1 ? "deposit" : "limit", n) return;
		if (e.actor = (e.actor + 1) % e.players.length, e.actor === e.governor && e.roundStep++, e.roundStep === 3) {
			e.selector = e.governor, e.actor = e.governor, e.phase = "role";
			return;
		}
	}
}
function W(e, t) {
	if (e.role === "builder") {
		let t = Math.min(...e.players.map((e) => e.buildings.length)), n = Math.max(...e.players.map((e) => e.buildings.length));
		e.bonusQueue = e.players.filter((r) => N(r, "tavern") && e.oldTaverns.includes(r.rid) && r.buildings.length === t && t < n).map((e) => e.rid);
	} else e.role === "trader" && (e.marketShown = !1, e.markets.push(e.markets.shift()), e.bonusQueue = e.sold === 0 ? e.players.filter((e) => N(e, "hut")).map((e) => e.rid) : []);
	G(e, t);
}
function G(e, t) {
	let n = e.bonusQueue.shift();
	if (n) {
		e.players.find((e) => e.rid === n).hand.push(...B(e, 1)), H(e, "phaseBonus", t, {
			rid: n,
			event: "bonus",
			card: e.players.find((e) => e.rid === n).buildings.find((t) => T(t.card) === (e.role === "builder" ? "tavern" : "hut")).card,
			n: 1
		});
		return;
	}
	if (e.role === "builder" && e.players.some((e) => e.buildings.length >= 12)) {
		e.phase = "done";
		return;
	}
	ge(e);
}
function K(e, t) {
	e.actor = (e.actor + 1) % e.players.length, e.actor === e.selector ? W(e, t) : he(e, t);
}
function q(e, t) {
	let n = L(e);
	if (e.resume === "roleStart") {
		if (e.actor = e.selector, e.sold = 0, e.bonusQueue = [], e.oldTaverns = e.players.filter((e) => N(e, "tavern")).map((e) => e.rid), e.role === "trader" && (e.marketShown = !0), e.role === "councillor") for (let n of e.players) for (let r of n.buildings) T(r.card) === "customsOffice" && r.good === null && (r.good = B(e, 1)[0] ?? null, r.good !== null && t.push({
			kind: "movement",
			rid: n.rid,
			data: { moves: [{
				from: "supply",
				to: `good:${r.card}`,
				n: 1
			}] },
			...t.length ? { with: !0 } : {}
		}));
		let n = t.length;
		he(e, t), t.length > n && n > 0 && (t[t.length - 1].with = !0);
	} else if (e.resume === "actor") K(e, t);
	else if (e.resume === "roundStep") e.actor = (e.actor + 1) % e.players.length, e.actor === e.governor && e.roundStep++, e.roundStep === 3 ? (e.selector = e.governor, e.actor = e.governor, e.phase = "role") : _e(e);
	else if (e.resume === "carpenter") {
		if (e.carpenter) {
			n.hand.push(...B(e, 1)), H(e, "poorHouse", t, {
				rid: n.rid,
				event: "bonus",
				card: n.buildings.find((e) => T(e.card) === "carpenter").card,
				n: 1
			});
			return;
		}
		e.resume = "poorHouse", q(e, t);
	} else if (e.resume === "poorHouse") e.poorHouse && n.hand.length <= 1 ? (n.hand.push(...B(e, 1)), H(e, "actor", t, {
		rid: n.rid,
		event: "bonus",
		card: n.buildings.find((e) => T(e.card) === "poorHouse").card,
		n: 1
	})) : K(e, t);
	else if (e.resume === "mine") {
		if (e.mine) {
			let r = B(e, 4);
			e.mineCards[n.rid] = r;
			let i;
			r.length === 4 && new Set(r.map((e) => E(e).cost)).size === 4 && (i = [...r].sort((e, t) => E(e).cost - E(t).cost)[0], n.hand.push(i)), e.discard.push(...r.filter((e) => e !== i)), H(e, "smith", t, {
				rid: n.rid,
				event: "mine",
				n: Number(i !== void 0)
			}), V(t, n.rid, [{
				from: "supply",
				to: `hand:${n.rid}`,
				n: Number(i !== void 0)
			}, {
				from: "supply",
				to: "discard",
				n: r.length - Number(i !== void 0)
			}], i === void 0 ? [] : [i]);
			return;
		}
		e.resume = "smith", q(e, t);
	} else if (e.resume === "smith") {
		if (e.smith) {
			let r = B(e, 1)[0];
			if (r !== void 0) {
				let i = !e.players.some((e) => N(e, T(r)));
				i ? n.hand.push(r) : e.discard.push(r), H(e, "actor", t, {
					rid: n.rid,
					event: "smith",
					n: Number(i),
					card: r
				}), V(t, n.rid, [{
					from: "supply",
					to: i ? `hand:${n.rid}` : "discard",
					n: 1,
					card: r
				}], i ? [r] : []);
				return;
			}
		}
		K(e, t);
	} else G(e, t);
}
function ve(e, t, n) {
	let r = {
		seed: n,
		cursor: 0,
		config: A.parse(e),
		players: t.map((e) => ({
			rid: e,
			hand: [],
			buildings: [],
			deposits: [],
			libraryUsed: !1,
			bankUsed: !1
		})),
		deck: [],
		discard: [],
		round: 1,
		governor: 0,
		selector: 0,
		selected: 0,
		actor: 0,
		phase: "role",
		role: null,
		used: [],
		privilege: 1,
		markets: [],
		marketShown: !1,
		cathedral: !1,
		drawn: [],
		keepCount: 0,
		roundStep: 0,
		resume: "actor",
		beat: 480,
		log: [],
		sold: 0,
		oldTaverns: [],
		bonusQueue: [],
		mine: !1,
		smith: !1,
		carpenter: !1,
		poorHouse: !1,
		mineCards: {}
	};
	r.cathedral = r.config.expansion, r.deck = C.flatMap((e, t) => t !== w && (!e.expansion || r.config.expansion) ? [t] : []);
	for (let e of r.players) {
		let t = r.deck.findIndex((e) => T(e) === "indigo");
		e.buildings.push({
			card: r.deck.splice(t, 1)[0],
			good: null,
			below: []
		});
	}
	return z(r, r.deck), r.markets = z(r, [
		0,
		1,
		2,
		3,
		4
	]), r.players.forEach((e, t) => {
		e.hand = B(r, r.config.variedStart ? t + 5 : 4);
	}), r.config.variedStart && (r.phase = "start"), { state: r };
}
function ye(e, t, n) {
	if (t.type === "tick") {
		if (n.by !== "$engine" || e.phase !== "settle") return P();
		let t = structuredClone(e), r = [];
		return q(t, r), {
			state: t,
			fx: r
		};
	}
	if (e.phase === "done" || e.phase === "settle") return P();
	if (e.players[e.actor]?.rid !== n.by) return { code: "games.sanjuan.errTurn" };
	let r = structuredClone(e), i = L(r), a = [], o = r.actor === r.selector ? r.privilege : 0;
	if (t.type === "role" && r.phase === "role") {
		if (r.used.includes(t.role)) return P();
		let e = N(i, "library") && (r.players.length !== 2 || !i.libraryUsed);
		if (t.library && !e) return P();
		r.privilege = t.library ? 2 : 1, t.library && (i.libraryUsed = !0), r.role = t.role, r.used.push(t.role), r.selected++, H(r, "roleStart", a, {
			rid: i.rid,
			event: "role",
			role: t.role,
			n: r.privilege
		}, `role:${t.role}`, `seat:${i.rid}`);
	} else if (t.type === "build" && r.phase === "build") {
		let e = t.card, n = e === w;
		if (n ? !r.cathedral : !i.hand.includes(e)) return P();
		let s = t.cover === null ? void 0 : i.buildings.find((e) => e.card === t.cover);
		if (t.cover !== null && (!s || !N(i, "crane") || T(s.card) === "crane" || T(s.card) === T(e)) || !E(e).production && i.buildings.some((t) => t !== s && T(t.card) === T(e)) || !I(t.pay, i.hand.filter((t) => t !== e)) || !F(t.goods) || t.goods.length > 2 || t.goods.length && !N(i, "blackMarket")) return P();
		let c = t.goods.map((e) => i.buildings.find((t) => t.card === e && t.good !== null));
		if (c.some((e) => !e) || t.pay.length !== ue(i, e, o, t.cover, t.goods.length)) return P();
		c.forEach((e) => {
			r.discard.push(e.good), e.good = null;
		}), r.discard.push(...t.pay), i.hand = i.hand.filter((n) => n !== e && !t.pay.includes(n)), s?.good !== null && s?.good !== void 0 && r.discard.push(s.good);
		let l = s ? [...s.below, s.card] : [];
		i.buildings = i.buildings.filter((e) => e !== s), r.carpenter = !E(e).production && N(i, "carpenter"), r.poorHouse = N(i, "poorHouse"), i.buildings.push({
			card: e,
			good: null,
			below: l
		}), n && (r.cathedral = !1), H(r, "carpenter", a, {
			rid: i.rid,
			event: "build",
			n: t.pay.length,
			card: e
		}, `hand:${i.rid}`, `building:${e}`), V(a, i.rid, [
			{
				from: `hand:${i.rid}`,
				to: `building:${e}`,
				n: 1,
				card: e
			},
			{
				from: `hand:${i.rid}`,
				to: "discard",
				n: t.pay.length
			},
			...t.goods.map((e) => ({
				from: `good:${e}`,
				to: "discard",
				n: 1
			})),
			...s?.good !== null && s?.good !== void 0 && !t.goods.includes(s.card) ? [{
				from: `city:${i.rid}`,
				to: "discard",
				n: 1
			}] : []
		]);
	} else if (t.type === "produce" && r.phase === "produce") {
		if (!F(t.buildings) || t.buildings.length > de(i, o)) return P();
		let e = t.buildings.map((e) => i.buildings.find((t) => t.card === e && E(e).production && t.good === null));
		if (e.some((e) => !e)) return P();
		let n = 0;
		for (let t of e) t.good = B(r, 1)[0] ?? null, t.good !== null && n++;
		let s = n >= 2 && N(i, "well") ? B(r, 1) : [];
		i.hand.push(...s), H(r, "actor", a, {
			rid: i.rid,
			event: "produce",
			n
		}), V(a, i.rid, [...e.filter((e) => e.good !== null).map((e) => ({
			from: "supply",
			to: `good:${e.card}`,
			n: 1
		})), {
			from: "supply",
			to: `hand:${i.rid}`,
			n: s.length
		}], s);
	} else if (t.type === "trade" && r.phase === "trade") {
		if (!F(t.buildings) || t.buildings.length > fe(i, o)) return P();
		let e = t.buildings.map((e) => i.buildings.find((t) => t.card === e && t.good !== null));
		if (e.some((e) => !e) || t.harbor !== null && (!N(i, "harbor") || !t.buildings.includes(t.harbor))) return P();
		let n = 0;
		for (let a of e) n += T(a.card) === "customsOffice" ? 2 : re[r.markets[0]][S.indexOf(T(a.card))], a.card === t.harbor ? i.deposits.push(a.good) : r.discard.push(a.good), a.good = null;
		e.length && N(i, "marketHall") && n++, e.length >= 2 && N(i, "marketStand") && n++;
		let s = B(r, n);
		i.hand.push(...s), r.sold += e.length, H(r, "actor", a, {
			rid: i.rid,
			event: "trade",
			n: e.length
		}, `seat:${i.rid}`, `hand:${i.rid}`), V(a, i.rid, [...e.map((e) => ({
			from: `good:${e.card}`,
			to: e.card === t.harbor ? `building:${i.buildings.find((e) => T(e.card) === "harbor").card}` : "discard",
			n: 1
		})), {
			from: "supply",
			to: `hand:${i.rid}`,
			n: s.length
		}], s);
	} else if (t.type === "keep" && (r.phase === "council" || r.phase === "start")) {
		let e = r.phase === "start", n = !e && N(i, "archive"), o = e ? i.hand : n ? [...i.hand, ...r.drawn] : r.drawn, s = e ? 4 : r.keepCount + (n ? i.hand.length : 0);
		if (!I(t.cards, o) || t.cards.length !== s) return P();
		r.discard.push(...o.filter((e) => !t.cards.includes(e))), i.hand = e || n ? [...t.cards] : [...i.hand, ...t.cards], r.drawn = [], r.keepCount = 0, e ? (r.actor++, r.actor >= r.players.length && (r.actor = 0, r.phase = "role")) : H(r, "actor", a, {
			rid: i.rid,
			event: "council",
			n: t.cards.length
		}, `hand:${i.rid}`, `hand:${i.rid}`), a.push({
			kind: "movement",
			rid: i.rid,
			data: { moves: [{
				from: `hand:${i.rid}`,
				to: "discard",
				n: o.length - t.cards.length
			}] },
			...a.length ? { with: !0 } : {}
		});
	} else if (t.type === "prospect" && r.phase === "prospect") {
		if (t.mine && !N(i, "goldMine") || t.smith && !N(i, "goldsmith")) return P();
		r.mine = t.mine, r.smith = t.smith, i.hand.push(...B(r, o)), H(r, "mine", a, {
			rid: i.rid,
			event: "prospect",
			n: o
		});
	} else if (t.type === "office" && r.phase === "office") {
		if (!N(i, "officeBuilding") || t.cards.length > 2 || !I(t.cards, i.hand)) return P();
		i.hand = i.hand.filter((e) => !t.cards.includes(e)), r.discard.push(...t.cards);
		let e = B(r, t.cards.length);
		i.hand.push(...e), H(r, "roundStep", a, {
			rid: i.rid,
			event: "office",
			n: t.cards.length
		}), V(a, i.rid, [{
			from: `hand:${i.rid}`,
			to: "discard",
			n: t.cards.length
		}, {
			from: "supply",
			to: `hand:${i.rid}`,
			n: e.length
		}], e);
	} else if (t.type === "deposit" && r.phase === "deposit") {
		let e = t.chapel === null ? [] : [t.chapel], n = [...e, ...t.bank];
		if (!I(n, i.hand) || e.length && !N(i, "chapel") || t.bank.length && (!N(i, "bank") || i.bankUsed)) return P();
		i.hand = i.hand.filter((e) => !n.includes(e)), i.deposits.push(...n), t.bank.length && (i.bankUsed = !0), H(r, "roundStep", a, {
			rid: i.rid,
			event: "deposit",
			n: 0
		}, `hand:${i.rid}`), V(a, i.rid, [...e.length ? [{
			from: `hand:${i.rid}`,
			to: `building:${i.buildings.find((e) => T(e.card) === "chapel").card}`,
			n: 1
		}] : [], ...t.bank.length ? [{
			from: `hand:${i.rid}`,
			to: `building:${i.buildings.find((e) => T(e.card) === "bank").card}`,
			n: t.bank.length
		}] : []]);
	} else if (t.type === "discard" && r.phase === "limit") {
		if (!I(t.cards, i.hand) || i.hand.length - t.cards.length !== U(r.players, i)) return P();
		i.hand = i.hand.filter((e) => !t.cards.includes(e)), r.discard.push(...t.cards), H(r, "roundStep", a, {
			rid: i.rid,
			event: "discard",
			n: t.cards.length
		}, `hand:${i.rid}`, "discard");
	} else if (t.type === "pass" && ![
		"role",
		"limit",
		"start"
	].includes(r.phase)) {
		let e = ["office", "deposit"].includes(r.phase), t = r.phase === "council" ? r.drawn.length : 0;
		r.phase === "council" && (r.discard.push(...r.drawn), r.drawn = [], r.keepCount = 0), H(r, e ? "roundStep" : "actor", a, {
			rid: i.rid,
			event: "pass",
			n: 0
		}), t && V(a, i.rid, [{
			from: `hand:${i.rid}`,
			to: "discard",
			n: t
		}]);
	} else return P();
	return {
		state: r,
		fx: a
	};
}
function J(e, t) {
	let n = e.players.find((e) => e.rid === t);
	return {
		public: {
			phase: e.phase,
			turn: L(e).rid,
			governor: e.players[e.governor].rid,
			chooser: e.players[e.selector].rid,
			round: e.round,
			role: e.role,
			used: [...e.used],
			privilege: e.privilege,
			market: e.marketShown ? [...re[e.markets[0]]] : null,
			deckCount: e.deck.length,
			discardCount: e.discard.length,
			cathedral: e.cathedral,
			config: { ...e.config },
			players: e.players.map((t) => ({
				rid: t.rid,
				handCount: t.hand.length,
				buildings: t.buildings.map((e) => ({
					card: e.card,
					good: e.good !== null,
					covered: e.below.length
				})),
				libraryUsed: t.libraryUsed,
				bankUsed: t.bankUsed,
				score: e.phase === "done" ? me(e, t) : null
			})),
			log: structuredClone(e.log)
		},
		private: {
			hand: [...n?.hand ?? []],
			drawn: t === L(e).rid ? [...e.drawn] : [],
			keepCount: t === L(e).rid ? e.keepCount : 0,
			deposits: n?.deposits.length ?? 0,
			mineCards: [...e.mineCards[t] ?? []]
		}
	};
}
function Y(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = e.players.map((t) => ({
		rid: t.rid,
		...me(e, t)
	})).sort((e, t) => t.total - e.total || t.tie - e.tie);
	return {
		phase: "done",
		ranking: t.map((e) => e.rid),
		winner: t.filter((e) => e.total === t[0].total && e.tie === t[0].tie).map((e) => e.rid),
		scores: Object.fromEntries(t.map((e) => [e.rid, e.total]))
	};
}
var be = {
	meta: ie,
	saveCompatibility: { version: "1" },
	schemas: {
		action: j,
		publicView: le,
		privateView: M,
		config: A
	},
	setup: ve,
	reduce: ye,
	viewFor: J,
	status: Y,
	nextTickIn: (e) => e.phase === "settle" ? e.beat : null
};
//#endregion
//#region src/games/sanjuan/card.tsx
function xe({ id: e, selected: t = !1, target: n = !1, good: r = !1, compact: i = !1, onClick: s, onDetail: u, anchor: d }) {
	let m = a(), _ = E(e), v = T(e), { ref: y, hidden: x } = l(d ?? null), { ref: S, hidden: ee } = l(d?.startsWith("building:") ? `good:${e}` : null);
	return /* @__PURE__ */ g("div", {
		ref: y,
		"data-kind": v,
		className: `sj-card${_.production ? " sj-production" : ""}${t ? " sj-selected" : ""}${n ? " sj-target" : ""}${i ? " sj-compact" : ""}`,
		style: { visibility: x ? "hidden" : void 0 },
		children: [
			/* @__PURE__ */ g("button", {
				type: "button",
				className: "sj-card-face",
				onClick: s,
				disabled: !s,
				"aria-pressed": s ? t : void 0,
				"aria-label": m(_.name),
				children: [
					/* @__PURE__ */ g("div", {
						className: "sj-card-head",
						children: [/* @__PURE__ */ h("span", {
							className: "sj-cost",
							children: _.cost
						}), /* @__PURE__ */ h("span", {
							className: "sj-vp",
							children: _.vp || (_.cost >= 6 ? "?" : 0)
						})]
					}),
					/* @__PURE__ */ h("img", {
						className: "sj-art",
						src: p(`games/sanjuan/live/${v}.svg`),
						alt: "",
						draggable: !1
					}),
					/* @__PURE__ */ h("strong", {
						className: "sj-card-name",
						children: m(b[v].name)
					}),
					/* @__PURE__ */ h("span", {
						className: "sj-card-text",
						children: m(_.text)
					}),
					t && /* @__PURE__ */ h("span", {
						className: "sj-card-check",
						children: /* @__PURE__ */ h(o, { size: 16 })
					}),
					d?.startsWith("building:") && /* @__PURE__ */ h("span", {
						ref: S,
						className: "sj-good",
						"aria-label": r ? m("games.sanjuan.goods") : void 0,
						"aria-hidden": !r,
						style: { visibility: r && !ee ? "visible" : "hidden" },
						children: "▧"
					})
				]
			}),
			u && /* @__PURE__ */ h("button", {
				type: "button",
				className: "sj-detail-button",
				onClick: u,
				"aria-label": m("games.sanjuan.detail"),
				children: /* @__PURE__ */ h(c, { size: 15 })
			}),
			n && !t && /* @__PURE__ */ h(f, { radius: 5 })
		]
	});
}
//#endregion
//#region src/games/sanjuan/view-player.tsx
var Se = {
	role: "games.sanjuan.chooseRole",
	build: "games.sanjuan.buildPrompt",
	produce: "games.sanjuan.producePrompt",
	trade: "games.sanjuan.tradePrompt",
	council: "games.sanjuan.councilPrompt",
	prospect: "games.sanjuan.prospectPrompt",
	office: "games.sanjuan.officePrompt",
	deposit: "games.sanjuan.depositPrompt",
	limit: "games.sanjuan.limitPrompt",
	start: "games.sanjuan.startPrompt",
	settle: "games.sanjuan.settlePrompt",
	done: "games.sanjuan.done"
}, Ce = {
	build: "games.sanjuan.build",
	produce: "games.sanjuan.produce",
	trade: "games.sanjuan.sell",
	council: "games.sanjuan.keep",
	start: "games.sanjuan.keep",
	office: "games.sanjuan.exchange",
	deposit: "games.sanjuan.bury",
	limit: "games.sanjuan.discard"
};
function X({ name: e, children: t, className: n = "" }) {
	let { ref: r, hidden: i } = l(e);
	return /* @__PURE__ */ h("div", {
		ref: r,
		className: n,
		style: { visibility: i ? "hidden" : void 0 },
		children: t
	});
}
function we(e) {
	let t = e.public;
	return /* @__PURE__ */ h(Te, { ...e }, `${t.round}:${t.turn}:${t.phase}:${t.log.length}`);
}
function Te({ public: e, private: t, members: o, myRid: c, send: l }) {
	let p = a(), _ = e, v = t ?? {
		hand: [],
		drawn: [],
		keepCount: 0,
		deposits: 0,
		mineCards: []
	}, y = _.players.find((e) => e.rid === c), x = _.turn === c && !["settle", "done"].includes(_.phase), [re, C] = i(c), [D, O] = i([]), [k, A] = i(null), [j, ae] = i(null), [oe, se] = i([]), [ce, le] = i(null), [M, P] = i(null), [F, I] = i([]), [L, R] = i("normal"), [z, B] = i(!1), [V, H] = i(null), pe = r(null), [me, he] = i(!0), [ge, _e] = i(!0);
	n(() => {
		V === null ? pe.current?.close() : pe.current?.showModal();
	}, [V]);
	let W = (e) => o.find((t) => t.rid === e)?.name ?? e, G = _.players.find((e) => e.rid === re) ?? y ?? _.players[0], K = _.chooser === c ? _.privilege : 0, q = (e, t = D, n = O, r = 144) => {
		t.includes(e) ? n(t.filter((t) => t !== e)) : t.length < r && n([...t, e]);
	}, ve = (e) => {
		if (x) {
			if (_.phase === "build") {
				if (k === null) {
					if (y && !E(e).production && N(y, T(e))) return;
					A(e), O([]);
				} else e === k ? (A(null), O([])) : q(e);
			} else _.phase === "deposit" ? L === "bank" || !y || !N(y, "chapel") ? e !== M && q(e, F, I) : (P(M === e ? null : e), I(F.filter((t) => t !== e))) : q(e, D, O, _.phase === "office" ? 2 : 144);
		}
	}, ye = (e) => {
		if (!x || G.rid !== c || !y) {
			H(e);
			return;
		}
		let t = y.buildings.find((t) => t.card === e);
		_.phase === "build" && L === "cover" ? T(e) !== "crane" && ae(j === e ? null : e) : _.phase === "build" && L === "black" ? t.good && q(e, oe, se, 2) : _.phase === "trade" && L === "harbor" ? D.includes(e) && le(ce === e ? null : e) : _.phase === "produce" && E(e).production && !t.good ? q(e, D, O, de(y, K)) : _.phase === "trade" && t.good ? (q(e, D, O, fe(y, K)), ce === e && le(null)) : H(e);
	}, J = null, Y = !1, be = k === null || !y ? 0 : ue(y, k, K, j, oe.length);
	x && y && (_.phase === "build" && k !== null && (J = {
		type: "build",
		card: k,
		pay: D,
		cover: j,
		goods: oe
	}, Y = D.length === be && (j === null || T(j) !== T(k)) && (E(k).production || !y.buildings.some((e) => e.card !== j && T(e.card) === T(k)))), _.phase === "produce" && (J = {
		type: "produce",
		buildings: D
	}, Y = D.length > 0), _.phase === "trade" && (J = {
		type: "trade",
		buildings: D,
		harbor: ce
	}, Y = D.length > 0), (_.phase === "council" || _.phase === "start") && (J = {
		type: "keep",
		cards: D
	}, Y = D.length === (_.phase === "start" ? 4 : v.keepCount + (N(y, "archive") ? v.hand.length : 0))), _.phase === "prospect" && (J = {
		type: "prospect",
		mine: me && N(y, "goldMine"),
		smith: ge && N(y, "goldsmith")
	}, Y = !0), _.phase === "office" && (J = {
		type: "office",
		cards: D
	}, Y = D.length > 0), _.phase === "deposit" && (J = {
		type: "deposit",
		chapel: M,
		bank: F
	}, Y = M !== null || F.length > 0), _.phase === "limit" && (J = {
		type: "discard",
		cards: D
	}, Y = D.length === v.hand.length - U(_.players, y)));
	let we = _.phase === "council" && x ? y && N(y, "archive") ? [...v.hand, ...v.drawn] : v.drawn : v.hand, Te = x && [
		"build",
		"council",
		"office",
		"deposit",
		"limit",
		"start"
	].includes(_.phase), Z = (e) => H(e);
	return /* @__PURE__ */ g("div", {
		className: "sj-root",
		children: [/* @__PURE__ */ h(u, {
			adaptive: !0,
			className: "sj-screen",
			banner: /* @__PURE__ */ h(d, {
				tone: x ? "accent" : _.phase === "done" ? "done" : "info",
				accent: ie.accent,
				text: x || _.phase === "settle" || _.phase === "done" ? p(Se[_.phase]) : p("games.sanjuan.wait", { name: W(_.turn) }),
				chip: p("games.sanjuan.round", { n: _.round })
			}),
			actionsHeight: "sj-actions-height",
			actions: /* @__PURE__ */ g("div", {
				className: "sj-actions",
				children: [/* @__PURE__ */ h("span", { children: x && _.phase === "build" && k !== null ? p("games.sanjuan.cost", { n: be }) : x && _.phase === "limit" && y ? p("games.sanjuan.handLimit", { n: U(_.players, y) }) : x ? p("games.sanjuan.selected", { n: D.length }) : _.role ? p(te[_.role]) : p("games.sanjuan.name") }), x && _.phase !== "role" && /* @__PURE__ */ g("div", { children: [!["limit", "start"].includes(_.phase) && /* @__PURE__ */ h("button", {
					type: "button",
					onClick: () => l({ type: "pass" }),
					children: p("games.sanjuan.pass")
				}), /* @__PURE__ */ h("button", {
					type: "button",
					className: "sj-primary",
					disabled: !Y,
					onClick: () => {
						J && l(J);
					},
					children: p(Ce[_.phase] ?? "games.sanjuan.confirm")
				})] })]
			}),
			children: /* @__PURE__ */ g("div", {
				className: "sj-layout",
				children: [/* @__PURE__ */ g("aside", {
					className: "sj-sidebar",
					children: [
						/* @__PURE__ */ g("section", {
							className: "sj-roles",
							children: [
								/* @__PURE__ */ h("h2", { children: p("games.sanjuan.round", { n: _.round }) }),
								x && _.phase === "role" && y && N(y, "library") && (_.players.length !== 2 || !y.libraryUsed) && /* @__PURE__ */ g("label", {
									className: "sj-toggle",
									children: [/* @__PURE__ */ h("input", {
										type: "checkbox",
										checked: z,
										onChange: (e) => B(e.target.checked)
									}), p("games.sanjuan.useLibrary")]
								}),
								/* @__PURE__ */ h("div", {
									className: "sj-role-list",
									children: ee.map((e) => /* @__PURE__ */ h(X, {
										name: `role:${e}`,
										children: /* @__PURE__ */ g("button", {
											type: "button",
											className: `sj-role${_.role === e ? " sj-role-active" : ""}`,
											disabled: !x || _.phase !== "role" || _.used.includes(e),
											onClick: () => l({
												type: "role",
												role: e,
												library: z
											}),
											children: [
												/* @__PURE__ */ h("span", { children: ne[e] }),
												/* @__PURE__ */ h("strong", { children: p(te[e]) }),
												_.used.includes(e) && /* @__PURE__ */ h("small", { children: p("games.sanjuan.used") }),
												x && _.phase === "role" && !_.used.includes(e) && /* @__PURE__ */ h(f, { radius: 5 })
											]
										})
									}, e))
								})
							]
						}),
						/* @__PURE__ */ g("section", {
							className: "sj-market",
							children: [
								/* @__PURE__ */ h("h2", { children: p("games.sanjuan.market") }),
								/* @__PURE__ */ h("div", {
									className: "sj-prices",
									children: S.map((e, t) => /* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h("strong", { children: p(b[e].name) }), /* @__PURE__ */ h("b", { children: _.market?.[t] ?? "—" })] }, e))
								}),
								/* @__PURE__ */ g("div", {
									className: "sj-piles",
									children: [/* @__PURE__ */ g(X, {
										name: "supply",
										children: [/* @__PURE__ */ h("span", {
											className: "sj-back",
											children: _.deckCount
										}), p("games.sanjuan.supply")]
									}), /* @__PURE__ */ g(X, {
										name: "discard",
										children: [/* @__PURE__ */ h("span", {
											className: "sj-back sj-discard",
											children: _.discardCount
										}), p("games.sanjuan.discardPile")]
									})]
								})
							]
						}),
						/* @__PURE__ */ h("nav", {
							className: "sj-seats",
							"aria-label": p("games.sanjuan.viewCity"),
							children: _.players.map((e) => /* @__PURE__ */ h(X, {
								name: `seat:${e.rid}`,
								children: /* @__PURE__ */ g("button", {
									type: "button",
									className: G.rid === e.rid ? "sj-seat sj-seat-active" : "sj-seat",
									onClick: () => {
										C(e.rid), R("normal");
									},
									children: [/* @__PURE__ */ g("strong", { children: [W(e.rid), e.rid === _.governor ? " ♛" : ""] }), /* @__PURE__ */ g("span", { children: [
										p("games.sanjuan.cityCount", { n: e.buildings.length }),
										" · ",
										p("games.sanjuan.count", { n: e.handCount })
									] })]
								})
							}, e.rid))
						})
					]
				}), /* @__PURE__ */ g("main", {
					className: "sj-main",
					children: [
						/* @__PURE__ */ g("section", {
							className: "sj-city",
							children: [
								/* @__PURE__ */ h(X, {
									name: `city:${G.rid}`,
									children: /* @__PURE__ */ g("header", { children: [/* @__PURE__ */ g("h2", { children: [
										W(G.rid),
										" · ",
										p("games.sanjuan.city")
									] }), /* @__PURE__ */ h("span", { children: p("games.sanjuan.cityCount", { n: G.buildings.length }) })] })
								}),
								/* @__PURE__ */ g("div", {
									className: "sj-city-tools",
									children: [x && G.rid === c && _.phase === "build" && y && (N(y, "crane") || N(y, "blackMarket")) && /* @__PURE__ */ g("div", {
										className: "sj-tools",
										children: [
											N(y, "crane") && /* @__PURE__ */ h("button", {
												type: "button",
												"aria-pressed": L === "cover",
												onClick: () => R(L === "cover" ? "normal" : "cover"),
												children: p("games.sanjuan.cover")
											}),
											j !== null && /* @__PURE__ */ h("button", {
												type: "button",
												onClick: () => ae(null),
												children: p("games.sanjuan.noCover")
											}),
											N(y, "blackMarket") && /* @__PURE__ */ h("button", {
												type: "button",
												"aria-pressed": L === "black",
												onClick: () => R(L === "black" ? "normal" : "black"),
												children: p("games.sanjuan.blackGoods")
											})
										]
									}), x && G.rid === c && _.phase === "trade" && y && N(y, "harbor") && /* @__PURE__ */ h("div", {
										className: "sj-tools",
										children: /* @__PURE__ */ h("button", {
											type: "button",
											"aria-pressed": L === "harbor",
											onClick: () => R(L === "harbor" ? "normal" : "harbor"),
											children: p("games.sanjuan.harborGood")
										})
									})]
								}),
								/* @__PURE__ */ g("div", {
									className: "sj-city-grid",
									children: [G.buildings.map((e) => {
										let t = x && G.rid === c && (_.phase === "produce" && E(e.card).production && !e.good || _.phase === "trade" && e.good || _.phase === "build" && (L === "cover" && T(e.card) !== "crane" || L === "black" && e.good));
										return /* @__PURE__ */ h(xe, {
											id: e.card,
											good: e.good,
											compact: !0,
											selected: D.includes(e.card) || j === e.card || oe.includes(e.card) || ce === e.card,
											target: t,
											anchor: `building:${e.card}`,
											onClick: () => ye(e.card),
											onDetail: () => Z(e.card)
										}, e.card);
									}), _.cathedral && /* @__PURE__ */ h(xe, {
										id: w,
										compact: !0,
										selected: k === w,
										target: x && _.phase === "build",
										onClick: () => {
											x && _.phase === "build" ? (A(k === w ? null : w), O([])) : Z(w);
										},
										onDetail: () => Z(w)
									})]
								})
							]
						}),
						/* @__PURE__ */ g(X, {
							name: `hand:${c}`,
							className: "sj-hand",
							children: [
								/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ h("h2", { children: x && _.phase === "council" ? p("games.sanjuan.drawn") : p("games.sanjuan.hand") }), /* @__PURE__ */ g("span", { children: [x && _.phase === "council" ? p("games.sanjuan.keepCount", { n: v.keepCount + (y && N(y, "archive") ? v.hand.length : 0) }) : p("games.sanjuan.count", { n: v.hand.length }), v.deposits > 0 ? ` · ${p("games.sanjuan.deposits", { n: v.deposits })}` : ""] })] }),
								/* @__PURE__ */ g("div", {
									className: "sj-hand-tools",
									children: [x && _.phase === "deposit" && y && /* @__PURE__ */ g("div", {
										className: "sj-tools",
										children: [N(y, "chapel") && /* @__PURE__ */ h("button", {
											type: "button",
											"aria-pressed": L !== "bank",
											onClick: () => R("chapel"),
											children: p("games.sanjuan.chapel")
										}), N(y, "bank") && !y.bankUsed && /* @__PURE__ */ h("button", {
											type: "button",
											"aria-pressed": L === "bank",
											onClick: () => R("bank"),
											children: p("games.sanjuan.bank")
										})]
									}), x && _.phase === "prospect" && y && /* @__PURE__ */ g("div", {
										className: "sj-tools",
										children: [N(y, "goldMine") && /* @__PURE__ */ g("label", {
											className: "sj-toggle",
											children: [/* @__PURE__ */ h("input", {
												type: "checkbox",
												checked: me,
												onChange: (e) => he(e.target.checked)
											}), p("games.sanjuan.useMine")]
										}), N(y, "goldsmith") && /* @__PURE__ */ g("label", {
											className: "sj-toggle",
											children: [/* @__PURE__ */ h("input", {
												type: "checkbox",
												checked: ge,
												onChange: (e) => _e(e.target.checked)
											}), p("games.sanjuan.useSmith")]
										})]
									})]
								}),
								/* @__PURE__ */ h("div", {
									className: "sj-hand-grid",
									children: we.map((e) => /* @__PURE__ */ h(xe, {
										id: e,
										anchor: `card:${e}`,
										selected: D.includes(e) || k === e || M === e || F.includes(e),
										target: Te && (_.phase !== "build" || k !== null || E(e).production || !y || !N(y, T(e))),
										onClick: Te ? () => ve(e) : () => Z(e),
										onDetail: () => Z(e)
									}, e))
								})
							]
						}),
						v.mineCards.length > 0 && /* @__PURE__ */ g("details", {
							className: "sj-log",
							children: [/* @__PURE__ */ h("summary", { children: p("games.sanjuan.mineDraw") }), /* @__PURE__ */ h("p", { children: v.mineCards.map((e) => p(E(e).name)).join(" · ") })]
						}),
						/* @__PURE__ */ g("details", {
							className: "sj-log",
							children: [/* @__PURE__ */ h("summary", { children: p("games.sanjuan.recent") }), [..._.log].reverse().map((e, t) => {
								let n = {
									name: W(e.rid),
									n: e.n,
									card: e.card === void 0 ? "" : p(E(e.card).name),
									role: e.role ? p(te[e.role]) : ""
								};
								return /* @__PURE__ */ h("p", { children: p({
									role: "games.sanjuan.logRole",
									build: "games.sanjuan.logBuild",
									produce: "games.sanjuan.logProduce",
									trade: "games.sanjuan.logTrade",
									council: "games.sanjuan.logCouncil",
									bonus: "games.sanjuan.logBonus",
									prospect: "games.sanjuan.logProspect",
									mine: "games.sanjuan.logMine",
									smith: "games.sanjuan.logSmith",
									office: "games.sanjuan.logOffice",
									deposit: "games.sanjuan.logDeposit",
									discard: "games.sanjuan.logDiscard",
									pass: "games.sanjuan.logPass",
									round: "games.sanjuan.logRound"
								}[e.event], n) }, t);
							})]
						})
					]
				})]
			})
		}), /* @__PURE__ */ h("dialog", {
			ref: pe,
			className: "sj-dialog",
			onCancel: () => H(null),
			onClick: (e) => {
				e.target === e.currentTarget && H(null);
			},
			children: V !== null && /* @__PURE__ */ g(m, { children: [
				/* @__PURE__ */ h("button", {
					type: "button",
					className: "sj-close",
					"aria-label": p("games.sanjuan.close"),
					onClick: () => H(null),
					children: /* @__PURE__ */ h(s, { size: 22 })
				}),
				/* @__PURE__ */ h(xe, { id: V }),
				/* @__PURE__ */ h("h2", { children: p(E(V).name) }),
				/* @__PURE__ */ h("p", { children: p(E(V).text) })
			] })
		})]
	});
}
//#endregion
//#region src/games/sanjuan/bot.ts
var Z = {
	engine: 1,
	production: 1,
	payment: 0,
	race: 1,
	economy: 1
}, Ee = {
	library: 5.5,
	quarry: 4.2,
	carpenter: 3.8,
	prefecture: 4.1,
	smithy: 1.8,
	goldMine: 1.2,
	poorHouse: 1.5,
	tradingPost: 1.5,
	marketHall: 2.4,
	marketStand: 1.2,
	well: 1.2,
	aqueduct: 1.6,
	chapel: 1.3,
	archive: 1.2,
	tower: .6,
	crane: .7,
	blackMarket: .8,
	bank: .8,
	harbor: 2,
	goldsmith: 2,
	tavern: 1.5,
	officeBuilding: 1,
	customsOffice: 2,
	guardRoom: .5,
	hut: .7
}, Q = (e) => e === "customsOffice" ? 2 : re.reduce((t, n) => t + n[S.indexOf(e)], 0) / 5;
function $(e, t, n = Z, r = !1) {
	let i = T(e), a = E(e), o = t.buildings.length, s = Math.max(0, (12 - o) / 10);
	if (!a.production && N(t, i)) return .1;
	let c = a.vp, l = t.buildings.filter((e) => E(e.card).production);
	if (i === "cityHall" && (c = o - l.length + 2), i === "guildHall" && (c = l.length + new Set(l.map((e) => T(e.card))).size + 1), i === "palace" && (c = (o * 1.8 + 3) / 4), i === "triumphalArch" && (c = [
		0,
		4,
		6,
		8
	][[
		"statue",
		"victoryColumn",
		"hero"
	].filter((e) => t.buildings.some((t) => T(t.card) === e)).length]), i === "residence" && (c = o > 7 ? 4 : 3), i === "cathedral" && (c = 4), r) return c + (a.production ? .7 : 0) + .3;
	let u = c + .8 * n.race;
	return u += (Ee[i] ?? 0) * s * n.engine, a.production && (u += Math.max(.4, 3.5 - l.length * .8) * Q(i) * s * n.production), [
		"statue",
		"hero",
		"victoryColumn"
	].includes(i) && N(t, "triumphalArch") && (u += 2), a.production && N(t, "guildHall") && (u += 1 + Number(!N(t, i))), !a.production && N(t, "cityHall") && u++, u;
}
function De(e, t, n, r, i = Z, a = !1) {
	let o = e.players.find((e) => e.rid === n), s = [], c = o.buildings.filter((e) => e.good).map((e) => e.card), l = [[]];
	if (N(o, "blackMarket")) {
		for (let e of c) l.push([e]);
		for (let e = 0; e < c.length; e++) for (let t = e + 1; t < c.length; t++) l.push([c[e], c[t]]);
	}
	for (let n of [...t.hand, ...e.cathedral ? [w] : []]) {
		if (!E(n).production && N(o, T(n))) continue;
		let e = [null, ...N(o, "crane") ? o.buildings.filter((e) => T(e.card) !== "crane" && T(e.card) !== T(n)).map((e) => e.card) : []];
		for (let c of e) for (let e of l) {
			let l = ue(o, n, r, c, e.length), u = t.hand.filter((e) => e !== n).sort((e, t) => $(e, o, i, a) - $(t, o, i, a) || e - t);
			if (l > u.length) continue;
			let d = u.slice(0, l), f = $(n, o, i, a) - l * (a ? .2 : .65) - d.reduce((e, t) => e + $(t, o, i, a) * (a ? .2 : i.payment), 0) - e.length * .65 - (c === null ? 0 : $(c, {
				...o,
				buildings: o.buildings.filter((e) => e.card !== c)
			}, i, a) + .7);
			s.push({
				action: {
					type: "build",
					card: n,
					pay: d,
					cover: c,
					goods: e
				},
				score: f
			});
		}
	}
	return s.sort((e, t) => t.score - e.score);
}
function Oe(e = Z) {
	return ({ public: t, private: n }, r) => {
		if (!n || t.turn !== r.rid || t.phase === "settle" || t.phase === "done") return null;
		let i = t.players.find((e) => e.rid === r.rid), a = r.difficulty === "weak", o = (t) => $(t, i, e, a), s = (e, t) => o(t) - o(e) || e - t, c = t.chooser === r.rid ? t.privilege : 0, l = (e) => ({ action: e });
		if (t.phase === "role") {
			let o = ee.filter((e) => !t.used.includes(e)).map((o) => {
				let s = N(i, "library") && (t.players.length !== 2 || !i.libraryUsed), c = s ? 2 : 1, l = De(t, n, r.rid, c, e, a), u = i.buildings.filter((e) => E(e.card).production && !e.good).sort((e, t) => Q(T(t.card)) - Q(T(e.card))), d = i.buildings.filter((e) => e.good).sort((e, t) => Q(T(t.card)) - Q(T(e.card))), f = 0;
				return o === "builder" && (f = (l[0]?.score ?? -2) + .8), o === "producer" && (f = u.slice(0, de(i, c)).reduce((e, t) => e + Q(T(t.card)) * .75, 0) * e.economy), o === "trader" && (f = d.slice(0, fe(i, c)).reduce((e, t) => e + Q(T(t.card)) * .9, 0) * e.economy + (N(i, "marketHall") && d.length ? .8 : 0)), o === "councillor" && (f = (N(i, "prefecture") ? 2.9 : 1.7) + (n.hand.length < 3 ? .8 : 0) + (s ? .4 : 0)), o === "prospector" && (f = c * .9 + (N(i, "goldMine") ? .4 : 0) + (N(i, "goldsmith") ? .8 : 0)), !a && o === "trader" && (f -= t.players.filter((e) => e !== i).reduce((e, t) => e + Math.min(1, t.buildings.filter((e) => e.good).length) * .2, 0)), {
					role: o,
					library: s,
					score: f
				};
			}).sort((e, t) => t.score - e.score);
			return l({
				type: "role",
				role: o[0].role,
				library: o[0].library
			});
		}
		if (t.phase === "build") {
			let i = De(t, n, r.rid, c, e, a)[0];
			return l(i && i.score > -.4 ? i.action : { type: "pass" });
		}
		if (t.phase === "produce") return l({
			type: "produce",
			buildings: i.buildings.filter((e) => E(e.card).production && !e.good).sort((e, t) => Q(T(t.card)) - Q(T(e.card))).slice(0, de(i, c)).map((e) => e.card)
		});
		if (t.phase === "trade") {
			let e = (e) => T(e) === "customsOffice" ? 2 : t.market[S.indexOf(T(e))], n = i.buildings.filter((e) => e.good).sort((t, n) => e(n.card) - e(t.card)).slice(0, fe(i, c)).map((e) => e.card);
			return l({
				type: "trade",
				buildings: n,
				harbor: N(i, "harbor") ? n[0] ?? null : null
			});
		}
		if (t.phase === "council" || t.phase === "start") {
			let e = t.phase === "council" && N(i, "archive"), r = t.phase === "start" ? n.hand : e ? [...n.hand, ...n.drawn] : n.drawn, a = t.phase === "start" ? 4 : n.keepCount + (e ? n.hand.length : 0);
			return l({
				type: "keep",
				cards: [...r].sort(s).slice(0, a)
			});
		}
		if (t.phase === "prospect") return l({
			type: "prospect",
			mine: N(i, "goldMine"),
			smith: N(i, "goldsmith")
		});
		if (t.phase === "office") return l({
			type: "office",
			cards: [...n.hand].sort((e, t) => s(t, e)).slice(0, 2)
		});
		if (t.phase === "deposit") {
			let e = [...n.hand].sort((e, t) => s(t, e));
			return l({
				type: "deposit",
				chapel: N(i, "chapel") && e.length > 3 ? e.shift() : null,
				bank: N(i, "bank") && !i.bankUsed && i.buildings.length >= 9 ? e.slice(0, Math.max(0, e.length - 3)) : []
			});
		}
		return t.phase === "limit" ? l({
			type: "discard",
			cards: [...n.hand].sort((e, t) => s(t, e)).slice(0, n.hand.length - U(t.players, i))
		}) : l({ type: "pass" });
	};
}
var ke = Oe(), Ae = (e, t, n) => e.type === "role" ? n(te[e.role]) : e.type === "build" ? n(b[T(e.card)].name) : n("games.sanjuan.confirm");
//#endregion
//#region src/games/sanjuan/fx.tsx
function je(e, t, n, r) {
	let i = r.queued ? 180 : 480, a = (e) => {
		let n = e.startsWith("hand:") && t !== r.myRid ? `seat:${t}` : e, i = r.anchor(n), a = i ?? r.anchor(`seat:${t}`);
		return !a || a.w === 0 || a.h === 0 ? null : i && (e.startsWith("building:") || e.startsWith("good:") || e.startsWith("card:")) ? a : {
			x: a.x + a.w / 2 - 22,
			y: a.y + Math.min(a.h / 2, 40) - 30,
			w: 44,
			h: 60
		};
	}, o = e.flatMap((e) => e.to === `hand:${t}` && t === r.myRid && n.length ? n.map((t) => ({
		...e,
		to: `card:${t}`,
		n: 1
	})) : [e]).filter((e) => e.n > 0).flatMap((e, t) => {
		let n = a(e.from), r = a(e.to);
		return n && r ? [{
			p: e,
			from: n,
			to: r,
			i: t
		}] : [];
	});
	return o.length ? {
		ms: i,
		hide: r.queued ? [] : [...o.filter(({ p: e }) => e.to.startsWith("good:") || e.card !== void 0 && e.to.startsWith("building:")).map(({ p: e }) => e.to).filter((e) => {
			let t = r.anchor(e);
			return t && t.w > 0 && t.h > 0;
		}), ...t === r.myRid ? n.map((e) => `card:${e}`).filter((e) => r.anchor(e)) : []],
		node: /* @__PURE__ */ h(m, { children: o.map(({ p: e, from: t, to: n, i: r }) => /* @__PURE__ */ h(_, {
			from: t,
			to: n,
			ms: i,
			children: e.card === void 0 ? /* @__PURE__ */ h("div", {
				className: "sj-fx-card",
				children: e.n > 1 ? e.n : ""
			}) : /* @__PURE__ */ h("div", {
				className: "sj-fx-building",
				children: /* @__PURE__ */ h(xe, { id: e.card })
			})
		}, r)) })
	} : null;
}
var Me = {
	transfer(e, t) {
		let n = e.data, r = e.rid, i = e.secret?.incoming ?? [];
		if (n.event === "role" || n.event === "pass" || n.n === 0 && n.event !== "build") {
			let e = t.anchor(n.event === "role" ? n.from : `seat:${r}`);
			return e ? {
				ms: t.queued ? 180 : 480,
				node: /* @__PURE__ */ h(v, {
					at: e,
					ms: t.queued ? 180 : 480
				})
			} : null;
		}
		return je([{
			from: n.from,
			to: n.to,
			n: n.event === "build" ? 1 : n.n,
			...n.event === "build" && n.card !== void 0 ? { card: n.card } : {}
		}], r, i, t);
	},
	movement(e, t) {
		return je(e.data.moves, e.rid, e.secret?.incoming ?? [], t);
	}
}, Ne = {
	buildings: "games.sanjuan.scoreBuildings",
	deposits: "games.sanjuan.scoreDeposits",
	guild: "games.sanjuan.scoreGuild",
	city: "games.sanjuan.scoreCity",
	arch: "games.sanjuan.scoreArch",
	residence: "games.sanjuan.scoreResidence",
	cathedral: "games.sanjuan.scoreCathedral",
	palace: "games.sanjuan.scorePalace"
};
function Pe(e) {
	let t = a(), n = e.public, [o, s] = i(!0), [c, l] = i(null), u = r(null), d = r(null), f = (t) => e.members.find((e) => e.rid === t)?.name ?? t, p = e.result.ranking.map((e) => n.players.find((t) => t.rid === e)).filter(Boolean), m = (e) => {
		s(e), l(null), requestAnimationFrame(() => {
			(e ? d : u).current?.focus();
		});
	}, _ = () => {
		c === "again" ? e.onPlayAgain?.() : e.onBackToLobby?.(), l(null);
	};
	return /* @__PURE__ */ g("div", {
		className: "sj-result-wrap",
		children: [
			/* @__PURE__ */ h("div", {
				className: "sj-result-board",
				inert: o,
				children: /* @__PURE__ */ h(we, {
					...e,
					send: () => {}
				})
			}),
			/* @__PURE__ */ h("div", {
				className: "sj-result-shade",
				hidden: !o,
				children: /* @__PURE__ */ g("section", {
					className: "sj-result",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": t("games.sanjuan.result"),
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), m(!1));
					},
					children: [
						/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ h("h1", { children: t("games.sanjuan.result") }), /* @__PURE__ */ h("button", {
							type: "button",
							ref: d,
							onClick: () => m(!1),
							children: t("games.sanjuan.review")
						})] }),
						/* @__PURE__ */ h("p", {
							className: "sj-result-sub",
							children: e.result.winner.length === 1 ? t("games.sanjuan.winner", { name: f(e.result.winner[0]) }) : `${t("games.sanjuan.tieWinner")} · ${e.result.winner.map(f).join(" / ")}`
						}),
						/* @__PURE__ */ g("div", {
							className: "sj-result-scroll",
							inert: c !== null,
							children: [/* @__PURE__ */ g("table", { children: [
								/* @__PURE__ */ h("thead", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
									scope: "col",
									children: t("games.sanjuan.city")
								}), p.map((e) => /* @__PURE__ */ h("th", {
									scope: "col",
									children: f(e.rid)
								}, e.rid))] }) }),
								/* @__PURE__ */ g("tbody", { children: [Object.keys(Ne).filter((e) => e === "buildings" || e === "deposits" || p.some((t) => (t.score?.[e] ?? 0) > 0)).map((e) => /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
									scope: "row",
									children: t(Ne[e])
								}), p.map((t) => /* @__PURE__ */ h("td", { children: t.score?.[e] ?? 0 }, t.rid))] }, e)), /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
									scope: "row",
									children: t("games.sanjuan.goods")
								}), p.map((e) => /* @__PURE__ */ h("td", { children: t("games.sanjuan.tieCount", { n: e.score?.tie ?? 0 }) }, e.rid))] })] }),
								/* @__PURE__ */ h("tfoot", { children: /* @__PURE__ */ g("tr", { children: [/* @__PURE__ */ h("th", {
									scope: "row",
									children: t("games.sanjuan.total")
								}), p.map((e) => /* @__PURE__ */ h("td", { children: e.score?.total ?? 0 }, e.rid))] }) })
							] }), e.hintCount !== void 0 && /* @__PURE__ */ h("p", { children: t("session.hint.usedCount", { n: e.hintCount }) })]
						}),
						c ? /* @__PURE__ */ g("div", {
							className: "sj-result-confirm",
							children: [/* @__PURE__ */ h("button", {
								type: "button",
								autoFocus: !0,
								className: "sj-primary",
								onClick: _,
								children: t(c === "again" ? "games.sanjuan.confirmAgain" : "games.sanjuan.confirmLobby")
							}), /* @__PURE__ */ h("button", {
								type: "button",
								onClick: () => l(null),
								children: t("games.sanjuan.cancel")
							})]
						}) : /* @__PURE__ */ g("footer", { children: [
							e.onBackToLobby && /* @__PURE__ */ h("button", {
								type: "button",
								onClick: () => l("lobby"),
								children: t("session.result.backToLobby")
							}),
							e.onPlayAgain && /* @__PURE__ */ h("button", {
								type: "button",
								className: "sj-primary",
								onClick: () => l("again"),
								children: t("session.result.playAgain")
							}),
							!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ h("span", { children: t("session.result.waitHost") })
						] })
					]
				})
			}),
			/* @__PURE__ */ h("button", {
				type: "button",
				ref: u,
				className: "sj-result-restore",
				hidden: o,
				onClick: () => m(!0),
				children: t("games.sanjuan.showResult")
			})
		]
	});
}
//#endregion
//#region src/games/sanjuan/options.tsx
function Fe({ value: e, onChange: t }) {
	let n = a(), r = A.safeParse(e), i = r.success ? r.data : A.parse(void 0);
	return /* @__PURE__ */ g("div", { children: [/* @__PURE__ */ h(y, {
		label: n("games.sanjuan.expansion"),
		checked: i.expansion,
		accent: ie.accent,
		onChange: () => t({
			...i,
			expansion: !i.expansion
		})
	}), /* @__PURE__ */ h(y, {
		label: n("games.sanjuan.variedStart"),
		checked: i.variedStart,
		accent: ie.accent,
		onChange: () => t({
			...i,
			variedStart: !i.variedStart
		})
	})] });
}
//#endregion
//#region .bgparty/cache/pack-entry/sanjuan/entry.tsx
var Ie = {
	definition: be,
	View: we,
	bot: ke,
	describe: Ae,
	fx: Me,
	OverView: Pe,
	Options: Fe,
	locales: {
		zh: {
			indigo: "靛蓝染料厂",
			indigoText: "生产靛蓝染料。",
			sugar: "制糖厂",
			sugarText: "生产蔗糖。",
			tobacco: "烟草加工厂",
			tobaccoText: "生产烟草。",
			coffee: "咖啡烘焙厂",
			coffeeText: "生产咖啡。",
			silver: "银矿冶炼厂",
			silverText: "生产白银。",
			archive: "档案馆",
			archiveText: "议员阶段可以将原有手牌与新抽的牌一起选择保留。",
			goldMine: "金矿",
			goldMineText: "淘金阶段私下抽取4张牌，费用全部不同时获得其中费用最低的一张。",
			smithy: "铁匠铺",
			smithyText: "建造生产建筑时少支付1张牌。",
			poorHouse: "济贫院",
			poorHouseText: "完成建造后，手牌不超过1张时抽1张牌。",
			blackMarket: "黑市",
			blackMarketText: "建造时可以弃置至多2件货物，每件抵扣1张费用。",
			tradingPost: "贸易站",
			tradingPostText: "商人阶段可以额外出售1件货物。",
			well: "水井",
			wellText: "一次生产至少2件货物后抽1张牌。",
			marketStand: "集市摊位",
			marketStandText: "一次出售至少2件货物后抽1张牌。",
			crane: "起重机",
			craneText: "可以覆盖一座起重机以外且类型不同的建筑，减免被覆盖建筑的费用。",
			chapel: "小教堂",
			chapelText: "每轮开始时可以埋藏1张手牌，每张在终局计1分。",
			tower: "高塔",
			towerText: "每轮开始时的手牌上限为12张。",
			aqueduct: "引水渠",
			aqueductText: "生产阶段可以额外生产1件货物。",
			carpenter: "木工坊",
			carpenterText: "建造城市建筑后抽1张牌，建造木工坊本身不触发。",
			statue: "雕像",
			statueText: "纪念建筑，终局计3分。",
			marketHall: "市场大厅",
			marketHallText: "一次出售至少1件货物后抽1张牌。",
			prefecture: "行政厅",
			prefectureText: "议员阶段额外保留1张牌。",
			quarry: "采石场",
			quarryText: "建造城市建筑时少支付1张牌。",
			victoryColumn: "胜利纪念柱",
			victoryColumnText: "纪念建筑，终局计4分。",
			library: "图书馆",
			libraryText: "选择角色时可以使特权翻倍；两人局每轮只可使用一次。",
			hero: "英雄纪念像",
			heroText: "纪念建筑，终局计5分。",
			cityHall: "市政厅",
			cityHallText: "每座有效城市建筑计1分，包含市政厅本身。",
			guildHall: "同业公会",
			guildHallText: "每座有效生产建筑及每种生产建筑各计1分。",
			palace: "宫殿",
			palaceText: "其他得分每满4分，额外计1分。",
			triumphalArch: "凯旋门",
			triumphalArchText: "拥有1／2／3种纪念建筑时分别计4／6／8分。",
			guardRoom: "警卫室",
			guardRoomText: "其他没有警卫室的玩家手牌上限降为6张，高塔仍为12张。",
			officeBuilding: "办公楼",
			officeBuildingText: "每轮开始时可以弃置1至2张手牌，再抽取相同数量。",
			hut: "小屋",
			hutText: "商人阶段所有人均未出售货物时抽1张牌。",
			tavern: "酒馆",
			tavernText: "建造阶段结束时，建筑最少且有人更多时抽1张牌；新建酒馆当次不触发。",
			bank: "银行",
			bankText: "整局一次，轮开始时可以埋藏任意数量手牌，每张计1分。",
			customsOffice: "海关",
			customsOfficeText: "议员阶段自动存放1件货物，出售时固定获得2张牌。",
			park: "公园",
			parkText: "通过起重机覆盖公园时，抵扣6张费用。",
			harbor: "港口",
			harborText: "每次商人阶段可以埋藏其中1件刚售货物，终局计1分。",
			goldsmith: "金匠铺",
			goldsmithText: "淘金阶段翻开1张牌，所有人均未建造该类建筑时获得它。",
			residence: "宅邸",
			residenceText: "同费用且类型不同的3座建筑组成一组，1／2／3／4组分别计4／7／9／10分。",
			cathedral: "大教堂",
			cathedralText: "对手共有1／2／3／至少4座费用为6的建筑时，分别计4／7／9／10分。",
			name: "圣胡安",
			desc: "选择角色，以手牌支付费用，在圣胡安建造繁荣的城市。",
			builder: "建筑师",
			producer: "生产者",
			trader: "商人",
			councillor: "议员",
			prospector: "淘金者",
			errAction: "当前不能执行此操作，请检查选择。",
			errTurn: "请等待轮到你行动。",
			round: "第{{n}}轮",
			wait: "等待{{name}}行动",
			chooseRole: "选择一个尚未使用的角色",
			buildPrompt: "选择要建造的建筑，再选择支付的手牌",
			producePrompt: "选择空置生产建筑",
			tradePrompt: "选择要出售的货物",
			councilPrompt: "选择要保留的牌",
			prospectPrompt: "选择是否使用淘金建筑",
			officePrompt: "选择要交换的手牌，至多2张",
			depositPrompt: "选择小教堂或银行要埋藏的手牌",
			limitPrompt: "将手牌弃至上限",
			startPrompt: "选择保留4张起始手牌",
			settlePrompt: "正在结算行动",
			done: "城市建造完成",
			hand: "手牌",
			city: "城市",
			market: "交易所",
			supply: "牌库",
			discardPile: "弃牌堆",
			governor: "总督",
			goods: "货物",
			count: "{{n}}张",
			cityCount: "{{n}}／12座",
			pass: "放弃本次行动",
			confirm: "确认",
			build: "建造",
			produce: "生产",
			sell: "出售",
			keep: "保留",
			exchange: "交换",
			bury: "埋藏",
			discard: "弃置",
			selected: "已选择{{n}}张",
			cost: "建造费用{{n}}张",
			pay: "支付手牌",
			cover: "覆盖建筑",
			noCover: "不覆盖建筑",
			blackGoods: "黑市货物",
			harborGood: "港口埋藏的已售货物",
			none: "不使用",
			useLibrary: "使用图书馆特权",
			mineDraw: "金矿最近抽取的牌",
			useMine: "使用金矿",
			useSmith: "使用金匠铺",
			used: "本轮已使用",
			drawn: "新抽的牌",
			keepCount: "保留{{n}}张",
			handLimit: "手牌上限{{n}}张",
			points: "{{n}}分",
			deposits: "埋藏{{n}}张",
			expansion: "新建筑扩展",
			variedStart: "起始手牌变体",
			on: "启用",
			off: "关闭",
			detail: "建筑详情",
			close: "关闭",
			viewCity: "查看城市",
			result: "圣胡安建设纪要",
			winner: "{{name}}获胜",
			tieWinner: "并列获胜",
			scoreBuildings: "建筑分数",
			scoreDeposits: "埋藏分数",
			scoreGuild: "同业公会",
			scoreCity: "市政厅",
			scoreArch: "凯旋门",
			scoreResidence: "宅邸",
			scoreCathedral: "大教堂",
			scorePalace: "宫殿",
			total: "总分",
			tieCount: "手牌与货物共{{n}}张",
			review: "回看城市",
			showResult: "查看结算",
			cancel: "取消",
			confirmAgain: "确认再玩一局",
			confirmLobby: "确认返回大厅",
			recent: "最近行动",
			logRole: "{{name}}选择{{role}}",
			logBuild: "{{name}}建造{{card}}",
			logProduce: "{{name}}生产{{n}}件货物",
			logTrade: "{{name}}出售{{n}}件货物",
			logCouncil: "{{name}}完成议员行动",
			logBonus: "{{name}}通过{{card}}获得{{n}}张牌",
			logProspect: "{{name}}完成淘金行动",
			logMine: "{{name}}通过金矿获得{{n}}张牌",
			logSmith: "{{name}}的金匠铺翻开{{card}}",
			logOffice: "{{name}}交换{{n}}张牌",
			logDeposit: "{{name}}完成埋藏",
			logDiscard: "{{name}}弃置{{n}}张牌",
			logPass: "{{name}}放弃本次行动",
			logRound: "第{{n}}轮开始",
			rules: "目标：\n以第二版规则建设圣胡安。建筑上的分数、埋藏牌及特殊建筑共同决定胜负。\n准备：\n2至4人，每人拥有1座靛蓝染料厂和4张手牌。手牌可建造、支付费用或成为货物，牌库与弃牌均背面朝上。起始手牌变体下，依座位抽5、6、7、8张，各保留4张。新建筑扩展默认关闭，开启时加入33张建筑和公共大教堂。\n流程：\n每轮从总督开始顺时针各选择一个未用角色，所有人从选择者开始依次行动，只有选择者获得角色特权。两人局依次由总督、另一人、总督选择，共3个不同角色。行动可以放弃；角色不能放弃。\n· 建筑师：建造1张手牌，弃置其他手牌支付其费用。选择者少支付1张。生产建筑可以重复，同名城市建筑只可拥有1座。也可以建造公共大教堂。\n· 生产者：在1座空置生产建筑上放置1张牌库牌作为货物；选择者可以额外生产1件。每座建筑最多存1件货物，货物牌不能查看。\n· 商人：按当前交易所价格出售1件货物，选择者可以额外出售1件，每件货物换取对应数量的手牌。阶段结束后交易所移到牌堆底部，下一次交易才翻开新的价格。\n· 议员：抽2张并保留1张，选择者额外抽3张，其余弃置。档案馆允许从原手牌与新牌中一起选择弃牌，行政厅额外保留1张。\n· 淘金者：只有选择者抽1张牌。拥有金矿或金匠铺的人仍可使用相应能力。第二版金矿私下抽取4张牌，仅在费用全部不同时获得最低费用牌。\n图书馆可以将角色特权翻倍；两人局每轮只能使用一次，由玩家选择使用时机。建筑能力详情可查看卡牌。起重机覆盖建筑后，旧建筑失去效果与印刷分数，其原有埋藏牌仍计分；覆盖货物会弃置。新建建筑不对自己的建造触发效果。\n每轮开始：\n角色全部归还，总督移至下一人。办公楼先交换手牌，再处理小教堂每轮1张、银行整局一次的埋藏，最后检查手牌上限7张；高塔为12张，有警卫室时未拥有警卫室的人为6张。轮内不检查手牌上限。牌库耗尽时洗混弃牌继续抽牌。\n结束与计分：\n有人拥有12座建筑时，完成整个建筑师阶段后结束。统计有效建筑印刷分数与埋藏牌每张1分，再计特殊建筑：同业公会为生产建筑数量加生产种类数；市政厅为城市建筑数量（含自身）；凯旋门按1、2、3种纪念建筑计4、6、8分；宅邸按同费用且类型不同的3座建筑组成不重复使用建筑的组，1至4组计4、7、9、10分；大教堂按对手的费用6建筑数量计4、7、9、10分；宫殿最后按其他分数每满4分加1分。同分时比较手牌加货物的数量，再同分则共享胜利。"
		},
		en: {
			indigo: "Indigo plant",
			indigoText: "Produces indigo.",
			sugar: "Sugar mill",
			sugarText: "Produces sugar.",
			tobacco: "Tobacco storage",
			tobaccoText: "Produces tobacco.",
			coffee: "Coffee roaster",
			coffeeText: "Produces coffee.",
			silver: "Silver smelter",
			silverText: "Produces silver.",
			archive: "Archive",
			archiveText: "During Councillor, choose discards from your old hand and drawn cards together.",
			goldMine: "Gold mine",
			goldMineText: "During Prospector, draw 4 cards privately. If all costs differ, keep the cheapest.",
			smithy: "Smithy",
			smithyText: "Pay 1 card less for production buildings.",
			poorHouse: "Poor house",
			poorHouseText: "After building, draw 1 card if your hand contains at most 1 card.",
			blackMarket: "Black market",
			blackMarketText: "When building, discard up to 2 goods to reduce the cost by 1 each.",
			tradingPost: "Trading post",
			tradingPostText: "Sell 1 additional good during Trader.",
			well: "Well",
			wellText: "Draw 1 card after producing at least 2 goods.",
			marketStand: "Market stand",
			marketStandText: "Draw 1 card after selling at least 2 goods.",
			crane: "Crane",
			craneText: "Build over a different building other than the crane, reducing the new cost by its printed cost.",
			chapel: "Chapel",
			chapelText: "At each round start, bury 1 hand card for 1 VP at game end.",
			tower: "Tower",
			towerText: "Your round-start hand limit is 12.",
			aqueduct: "Aqueduct",
			aqueductText: "Produce 1 additional good during Producer.",
			carpenter: "Carpenter",
			carpenterText: "Draw 1 card after building a city building. Does not trigger on its own construction.",
			statue: "Statue",
			statueText: "Monument worth 3 VP.",
			marketHall: "Market hall",
			marketHallText: "Draw 1 card after selling at least 1 good.",
			prefecture: "Prefecture",
			prefectureText: "Keep 1 additional card during Councillor.",
			quarry: "Quarry",
			quarryText: "Pay 1 card less for city buildings.",
			victoryColumn: "Victory column",
			victoryColumnText: "Monument worth 4 VP.",
			library: "Library",
			libraryText: "Double your selected role privilege. In a 2-player game, use only once per round.",
			hero: "Hero",
			heroText: "Monument worth 5 VP.",
			cityHall: "City hall",
			cityHallText: "Score 1 VP per active city building, including this one.",
			guildHall: "Guild hall",
			guildHallText: "Score 1 VP per active production building and 1 per different production type.",
			palace: "Palace",
			palaceText: "Score 1 additional VP per complete 4 VP from all other sources.",
			triumphalArch: "Triumphal arch",
			triumphalArchText: "Score 4/6/8 VP for 1/2/3 different monuments.",
			guardRoom: "Guard room",
			guardRoomText: "Players without a guard room have a hand limit of 6. Towers still allow 12.",
			officeBuilding: "Office building",
			officeBuildingText: "At round start, discard 1 or 2 hand cards and draw the same number.",
			hut: "Hut",
			hutText: "Draw 1 card if nobody sold any goods during Trader.",
			tavern: "Tavern",
			tavernText: "At Builder end, draw 1 card if you have the fewest buildings and someone has more. Not on its own construction.",
			bank: "Bank",
			bankText: "Once per game at round start, bury any number of hand cards for 1 VP each.",
			customsOffice: "Customs office",
			customsOfficeText: "At Councillor start, store 1 good if empty. Sell it for 2 cards.",
			park: "Park",
			parkText: "When covered using a crane, reduces the new cost by 6.",
			harbor: "Harbor",
			harborText: "Bury 1 just-sold good per Trader phase for 1 VP at game end.",
			goldsmith: "Goldsmith",
			goldsmithText: "During Prospector, reveal 1 card. Keep it if no player has that active building type.",
			residence: "Residence",
			residenceText: "Sets of 3 different buildings of the same cost score 4/7/9/10 VP for 1/2/3/4 sets.",
			cathedral: "Cathedral",
			cathedralText: "Score 4/7/9/10 VP for 1/2/3/4+ opponent-owned 6-cost buildings.",
			name: "San Juan",
			desc: "Choose roles and spend cards to build a thriving city in San Juan.",
			builder: "Builder",
			producer: "Producer",
			trader: "Trader",
			councillor: "Councillor",
			prospector: "Prospector",
			errAction: "This action is unavailable. Check your selection.",
			errTurn: "Please wait for your turn.",
			round: "Round {{n}}",
			wait: "Waiting for {{name}}",
			chooseRole: "Choose an available role",
			buildPrompt: "Choose a building, then select payment cards",
			producePrompt: "Choose empty production buildings",
			tradePrompt: "Choose goods to sell",
			councilPrompt: "Choose cards to keep",
			prospectPrompt: "Choose prospecting abilities",
			officePrompt: "Choose up to 2 hand cards to exchange",
			depositPrompt: "Choose hand cards to bury",
			limitPrompt: "Discard down to your hand limit",
			startPrompt: "Keep 4 starting cards",
			settlePrompt: "Resolving the action",
			done: "The city is complete",
			hand: "Hand",
			city: "City",
			market: "Trading house",
			supply: "Supply",
			discardPile: "Discard",
			governor: "Governor",
			goods: "Goods",
			count: "{{n}} cards",
			cityCount: "{{n}} / 12 buildings",
			pass: "Pass",
			confirm: "Confirm",
			build: "Build",
			produce: "Produce",
			sell: "Sell",
			keep: "Keep",
			exchange: "Exchange",
			bury: "Bury",
			discard: "Discard",
			selected: "{{n}} selected",
			cost: "Build cost: {{n}} cards",
			pay: "Payment cards",
			cover: "Build over",
			noCover: "Do not build over",
			blackGoods: "Black market goods",
			harborGood: "Sold good to bury at harbor",
			none: "None",
			useLibrary: "Use library privilege",
			mineDraw: "Latest gold mine draw",
			useMine: "Use gold mine",
			useSmith: "Use goldsmith",
			used: "Used this round",
			drawn: "Drawn cards",
			keepCount: "Keep {{n}} cards",
			handLimit: "Hand limit: {{n}}",
			points: "{{n}} VP",
			deposits: "{{n}} buried cards",
			expansion: "The New Buildings",
			variedStart: "Varied starting hands",
			on: "On",
			off: "Off",
			detail: "Building details",
			close: "Close",
			viewCity: "View city",
			result: "San Juan city ledger",
			winner: "{{name}} wins",
			tieWinner: "Shared victory",
			scoreBuildings: "Building VP",
			scoreDeposits: "Buried cards",
			scoreGuild: "Guild hall",
			scoreCity: "City hall",
			scoreArch: "Triumphal arch",
			scoreResidence: "Residence",
			scoreCathedral: "Cathedral",
			scorePalace: "Palace",
			total: "Total",
			tieCount: "{{n}} hand cards and goods",
			review: "Review city",
			showResult: "Show results",
			cancel: "Cancel",
			confirmAgain: "Start another game",
			confirmLobby: "Return to lobby",
			recent: "Recent actions",
			logRole: "{{name}} chose {{role}}",
			logBuild: "{{name}} built {{card}}",
			logProduce: "{{name}} produced {{n}} goods",
			logTrade: "{{name}} sold {{n}} goods",
			logCouncil: "{{name}} completed Councillor",
			logBonus: "{{name}} gained {{n}} cards from {{card}}",
			logProspect: "{{name}} completed Prospector",
			logMine: "{{name}} gained {{n}} cards from a gold mine",
			logSmith: "{{name}}’s goldsmith revealed {{card}}",
			logOffice: "{{name}} exchanged {{n}} cards",
			logDeposit: "{{name}} completed a deposit",
			logDiscard: "{{name}} discarded {{n}} cards",
			logPass: "{{name}} passed",
			logRound: "Round {{n}} begins",
			rules: "Objective:\nBuild San Juan using the second edition rules. Building VP, buried cards and special buildings determine the winner.\nSetup:\nFor 2–4 players. Each player starts with 1 indigo plant and 4 hand cards. Cards serve as buildings, payment and goods. Supply and discard piles stay face down. With varied starting hands, seats draw 5, 6, 7 or 8 cards and keep 4. The optional New Buildings expansion adds 33 buildings and the shared cathedral; it is off by default.\nRound:\nStarting with the Governor, each player selects an unused role. All players act clockwise from its selector, who alone receives the privilege. With 2 players the Governor, other player and Governor select 3 different roles. Actions may be passed; a role must be selected.\n· Builder: Build 1 hand card and discard other hand cards equal to its cost. The selector pays 1 less. Production types may repeat; each city type is limited to 1 active copy. The shared cathedral may also be built.\n· Producer: Place 1 supply card face down as a good on 1 empty production building. The selector may produce 1 extra good. Each building stores at most 1 good, whose face must remain unseen.\n· Trader: Sell 1 good for hand cards at the current trading house prices. The selector may sell 1 extra good. Move the tile to the bottom after the phase; reveal the next tile only at the next Trader phase.\n· Councillor: Draw 2 and keep 1. The selector draws 3 extra. Discard the rest. Archive allows discards from the old hand and new cards together; Prefecture keeps 1 extra card.\n· Prospector: Only the selector draws 1 card. Other players may still use gold mines or goldsmiths. The second edition gold mine keeps the cheapest of 4 privately drawn cards only when all 4 costs differ.\nLibrary may double a role privilege; with 2 players it can be used only once per round, at its owner's chosen time. Inspect cards for building abilities. Crane coverings remove the old building's effect and printed VP, but its buried cards retain their VP. Goods on a covered building are discarded. New buildings do not trigger on their own construction.\nRound start:\nReturn roles and pass the Governor clockwise. Resolve office exchanges, then chapel deposits of at most 1 card and a bank's once-per-game deposit, then discard down to 7 cards. Tower allows 12; a guard room reduces players without one to 6. There is no hand limit during a round. Reshuffle the discard pile when the supply runs out.\nEnd and scoring:\nFinish the entire Builder phase when anyone reaches 12 buildings. Score active buildings' printed VP and 1 per buried card. Guild hall scores production count plus different production types. City hall scores city count including itself. Triumphal arch scores 4/6/8 for 1/2/3 monument types. Residence forms disjoint sets of 3 different buildings of the same cost, scoring 4/7/9/10 for 1–4 sets. Cathedral scores 4/7/9/10 for 1/2/3/4+ opponent-owned 6-cost buildings. Palace scores 1 per complete 4 VP from all other sources, calculated last. Break ties by hand cards plus stored goods, then share victory."
		}
	}
};
//#endregion
export { Ie as default };
