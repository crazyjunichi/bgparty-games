import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useLayoutEffect as n, useRef as r, useState as i } from "react";
import { createPortal as a } from "react-dom";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { Texture as l } from "@bgparty/sdk/texture";
import { useFxAnchor as u } from "@bgparty/sdk/fx/anchors";
import { useWakeLock as d } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as ee } from "@bgparty/sdk/ui/game-screen";
import { LogSheet as te } from "@bgparty/sdk/ui/log-sheet";
import { SeatBadgedAvatar as f, seatName as ne } from "@bgparty/sdk/ui/player-strip";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { OptionRadio as g, OptionSection as _, OptionSwitch as v } from "@bgparty/sdk/ui/game-options";
import { Floater as y, FlySprite as b, PulseBox as x } from "@bgparty/sdk/fx/primitives";
//#region src/games/uno/cards.ts
var S = [
	"red",
	"yellow",
	"green",
	"blue"
];
function re() {
	let e = [], t = (t, n, r = 0) => e.push({
		id: e.length,
		color: t,
		kind: n,
		value: r
	});
	for (let e of S) {
		t(e, "number");
		for (let n = 1; n <= 9; n++) t(e, "number", n), t(e, "number", n);
		for (let n of [
			"skip",
			"reverse",
			"draw2"
		]) t(e, n), t(e, n);
	}
	for (let e = 0; e < 4; e++) t(null, "wild");
	for (let e = 0; e < 4; e++) t(null, "wild4");
	return e;
}
var C = re(), w = (e) => C[e], T = (e) => {
	let t = w(e);
	return t.kind === "number" ? t.value : t.color ? 20 : 50;
}, E = (e) => e.reduce((e, t) => e + T(t), 0), D = (e) => w(e).color === null, ie = (e) => w(e).kind === "draw2" || w(e).kind === "wild4";
function ae(e) {
	return [...e].sort((e, t) => {
		let n = w(e), r = w(t);
		return (n.color ? S.indexOf(n.color) : 4) - (r.color ? S.indexOf(r.color) : 4) || e - t;
	});
}
//#endregion
//#region src/games/uno/meta.ts
var O = {
	id: "uno",
	tier: "released",
	mechanics: ["hand-management"],
	interactionTags: [],
	nameKey: "games.uno.name",
	descKey: "games.uno.desc",
	rulesKey: "games.uno.rules",
	icon: "🃏",
	iconImg: "games/uno.webp",
	rulesUrl: { en: "https://service.mattel.com/instruction_sheets/W2085-Eng.pdf" },
	minPlayers: 2,
	maxPlayers: 10,
	bestPlayers: [
		4,
		5,
		6
	],
	accent: "#bf352c",
	releasedAt: "2026-10-25T00:32:36+08:00",
	search: {
		py: "",
		init: ""
	},
	hotseat: "cover",
	botDelayMs: 400
}, k = t.enum([
	"red",
	"yellow",
	"green",
	"blue"
]), A = t.int().min(0).max(107), j = t.object({
	mode: t.enum(["single", "points"]).catch("single"),
	stacking: t.enum([
		"off",
		"draw2",
		"same",
		"mixed"
	]).catch("off"),
	drawRule: t.enum(["one", "untilPlayable"]).catch("one"),
	wildFour: t.enum(["challenge", "free"]).catch("challenge"),
	sevenZero: t.boolean().catch(!1)
}).default({
	mode: "single",
	stacking: "off",
	drawRule: "one",
	wildFour: "challenge",
	sevenZero: !1
}).transform((e) => ({
	...e,
	wildFour: e.stacking === "same" || e.stacking === "mixed" ? "free" : e.wildFour
})), oe = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("tick"),
		now: t.number()
	}),
	t.object({
		type: t.literal("play"),
		card: A,
		color: k.optional()
	}),
	t.object({ type: t.literal("draw") }),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("chooseColor"),
		color: k
	}),
	t.object({
		type: t.literal("swap"),
		target: t.string()
	}),
	t.object({ type: t.literal("challenge") }),
	t.object({ type: t.literal("acknowledge") }),
	t.object({ type: t.literal("nextRound") })
]), se = t.object({
	kind: t.enum([
		"play",
		"draw",
		"pass",
		"color",
		"swap",
		"rotate",
		"challenge",
		"round"
	]),
	by: t.string(),
	card: A.optional(),
	color: k.optional(),
	target: t.string().optional(),
	count: t.int().nonnegative().optional(),
	success: t.boolean().optional()
}), ce = t.object({
	config: j,
	phase: t.enum([
		"play",
		"startColor",
		"swap",
		"reveal",
		"roundOver",
		"done",
		"settle"
	]),
	motion: t.object({
		kind: t.enum(["play", "draw"]),
		by: t.string(),
		card: A.optional(),
		count: t.int().nonnegative().optional()
	}).nullable(),
	round: t.int().positive(),
	turn: t.string(),
	direction: t.union([t.literal(1), t.literal(-1)]),
	top: A,
	color: k.nullable(),
	deckCount: t.int().nonnegative(),
	pendingDraw: t.int().nonnegative(),
	challenge: t.object({
		by: t.string(),
		previousColor: k
	}).nullable(),
	challengeResult: t.object({
		by: t.string(),
		target: t.string(),
		previousColor: k,
		success: t.boolean(),
		count: t.int().nonnegative()
	}).nullable(),
	players: t.array(t.object({
		rid: t.string(),
		count: t.int().nonnegative(),
		score: t.int().nonnegative()
	})),
	roundWinner: t.string().nullable(),
	roundAward: t.int().nonnegative(),
	roundScores: t.array(t.object({
		rid: t.string(),
		remaining: t.int().nonnegative(),
		earned: t.int().nonnegative(),
		total: t.int().nonnegative()
	})),
	log: t.array(se)
}), M = t.object({
	hand: t.array(A),
	incoming: t.array(A),
	playable: t.array(A),
	drawnCard: A.nullable(),
	revealedHand: t.array(A).nullable()
}), N = (e) => 160 + Math.max(0, Math.min(e, 12) - 1) * 12 + 40;
function P(t, n) {
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.rngCursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function F(e, t = e.turn, n = 1) {
	let r = e.players.indexOf(t);
	return e.players[(r + e.direction * n + e.players.length * n) % e.players.length];
}
function I(e, t) {
	e.log = [...e.log.slice(-39), t];
}
function L(e, t, n) {
	let r = [];
	for (let i = 0; i < n; i++) {
		e.deck.length === 0 && e.discard.length > 1 && (e.deck = P(e, e.discard.slice(0, -1)), e.discard = e.discard.slice(-1));
		let n = e.deck.pop();
		if (n === void 0) break;
		e.hands[t].push(n), r.push(n);
	}
	return r;
}
function R(e) {
	e.deck = P(e, C.map((e) => e.id)), e.discard = [], e.hands = Object.fromEntries(e.players.map((e) => [e, []]));
	for (let t = 0; t < 7; t++) for (let t of e.players) L(e, t, 1);
	for (; w(e.deck[e.deck.length - 1]).kind === "wild4";) P(e, e.deck);
	let t = e.deck.pop();
	e.discard = [t];
	let n = w(t);
	e.color = n.color, e.direction = 1, e.turn = e.players[(e.dealer + 1) % e.players.length], e.phase = n.kind === "wild" ? "startColor" : "play", e.pendingDraw = n.kind === "draw2" ? 2 : 0, e.challenge = null, e.challengeResult = null, e.reveal = null, e.afterReveal = null, e.drawnCard = null, e.roundWinner = null, e.roundAward = 0, e.roundScores = [], n.kind === "reverse" ? (e.direction = -1, e.turn = e.players[e.dealer]) : n.kind === "skip" && (e.turn = F(e));
}
function z(e) {
	if (e.pendingDraw || e.challenge || e.phase === "swap" || e.phase === "reveal") return;
	let t = e.players.find((t) => e.hands[t].length === 0);
	t && (e.roundWinner = t, e.roundAward = e.players.reduce((t, n) => t + E(e.hands[n]), 0), e.scores[t] += e.roundAward, e.roundScores = e.players.map((n) => ({
		rid: n,
		remaining: E(e.hands[n]),
		earned: n === t ? e.roundAward : 0,
		total: e.scores[n]
	})), e.turn = t, e.drawnCard = null, e.phase = e.config.mode === "single" || e.scores[t] >= 500 ? "done" : "roundOver", I(e, {
		kind: "round",
		by: t,
		count: e.roundAward
	}));
}
function B(e, t) {
	if (!ie(t) || e.players.some((t) => e.hands[t].length === 0)) return !1;
	let n = w(t).kind, r = w(e.discard[e.discard.length - 1]).kind;
	switch (e.config.stacking) {
		case "off": return !1;
		case "draw2": return n === "draw2" && r === "draw2";
		case "same": return n === r;
		case "mixed": return !0;
	}
}
function V(e, t, n) {
	if (e.phase !== "play" || e.turn !== t || !e.hands[t].includes(n)) return !1;
	if (e.pendingDraw) return !e.challenge && B(e, n);
	if (e.drawnCard !== null && e.drawnCard !== n) return !1;
	let r = w(n), i = w(e.discard[e.discard.length - 1]);
	return D(n) || r.color === e.color || (r.kind === "number" && i.kind === "number" ? r.value === i.value : r.kind !== "number" && r.kind === i.kind);
}
function H(t, n, r) {
	let i = {
		config: j.parse(t),
		players: [...n],
		hands: {},
		scores: Object.fromEntries(n.map((e) => [e, 0])),
		deck: [],
		discard: [],
		seed: r,
		rngCursor: 0,
		dealer: 0,
		round: 1,
		phase: "play",
		turn: n[0],
		direction: 1,
		color: null,
		pendingDraw: 0,
		challenge: null,
		challengeResult: null,
		reveal: null,
		afterReveal: null,
		drawnCard: null,
		roundWinner: null,
		roundAward: 0,
		roundScores: [],
		log: [],
		pending: null
	};
	return i.dealer = e(r, i.rngCursor++, n.length), R(i), { state: i };
}
function U(e, t, { by: n }) {
	if (!e.players.includes(n)) return { code: "games.uno.errPlayer" };
	if (e.phase === "done") return { code: "games.uno.errFinished" };
	if (e.turn !== n) return { code: "games.uno.errTurn" };
	let r = {
		...e,
		hands: Object.fromEntries(e.players.map((t) => [t, [...e.hands[t]]])),
		scores: { ...e.scores },
		deck: [...e.deck],
		discard: [...e.discard]
	}, i = () => ({ code: "games.uno.errPhase" });
	if (t.type === "nextRound") return r.phase === "roundOver" ? (r.round++, r.dealer = (r.dealer + 1) % r.players.length, R(r), { state: r }) : i();
	if (t.type === "chooseColor") return r.phase === "startColor" ? (r.color = t.color, r.phase = "play", I(r, {
		kind: "color",
		by: n,
		color: t.color
	}), { state: r }) : i();
	if (t.type === "swap") return r.phase === "swap" ? t.target === n || !r.players.includes(t.target) ? { code: "games.uno.errTarget" } : ([r.hands[n], r.hands[t.target]] = [r.hands[t.target], r.hands[n]], I(r, {
		kind: "swap",
		by: n,
		target: t.target
	}), r.phase = "play", r.turn = F(r, n), z(r), { state: r }) : i();
	if (t.type === "acknowledge") return r.phase !== "reveal" || !r.afterReveal ? i() : (r.turn = r.afterReveal, r.afterReveal = null, r.reveal = null, r.phase = "play", z(r), { state: r });
	if (r.phase !== "play") return i();
	if (t.type === "challenge") {
		let e = r.challenge;
		if (!e) return i();
		let t = L(r, e.guilty ? e.by : n, e.guilty ? 4 : 6);
		return r.challengeResult = {
			by: e.by,
			target: n,
			previousColor: e.previousColor,
			success: e.guilty,
			count: t.length
		}, r.reveal = [...e.hand], r.afterReveal = e.guilty ? n : F(r, n), r.pendingDraw = 0, r.challenge = null, r.phase = "reveal", I(r, {
			kind: "challenge",
			by: n,
			target: e.by,
			count: t.length,
			success: e.guilty
		}), { state: r };
	}
	if (t.type === "pass") return r.drawnCard === null || r.pendingDraw ? i() : (r.drawnCard = null, r.turn = F(r), I(r, {
		kind: "pass",
		by: n
	}), { state: r });
	if (t.type === "draw") {
		if (r.drawnCard !== null) return { code: "games.uno.errAlreadyDrew" };
		if (r.pendingDraw) {
			let e = L(r, n, r.pendingDraw);
			r.pendingDraw = 0, r.challenge = null, r.turn = F(r), I(r, {
				kind: "draw",
				by: n,
				count: e.length
			}), z(r);
		} else {
			let e = 0;
			for (;;) {
				let t = L(r, n, 1);
				if (!t.length) {
					r.drawnCard = null, r.turn = F(r);
					break;
				}
				if (e++, r.drawnCard = t[0], V(r, n, t[0])) break;
				if (r.drawnCard = null, r.config.drawRule === "one") {
					r.turn = F(r);
					break;
				}
			}
			I(r, {
				kind: "draw",
				by: n,
				count: e
			});
		}
		return { state: r };
	}
	if (t.type !== "play") return i();
	if (!V(r, n, t.card)) return { code: "games.uno.errCard" };
	if (D(t.card) && !t.color) return { code: "games.uno.errColor" };
	let a = r.color, o = r.hands[n].some((e) => w(e).color === a), s = w(t.card);
	if (r.hands[n] = r.hands[n].filter((e) => e !== t.card), r.discard.push(t.card), r.color = s.color ?? t.color, r.drawnCard = null, r.challengeResult = null, I(r, {
		kind: "play",
		by: n,
		card: t.card,
		color: r.color
	}), s.kind === "draw2" || s.kind === "wild4") r.pendingDraw += s.kind === "draw2" ? 2 : 4, r.turn = F(r, n), s.kind === "wild4" && r.config.wildFour === "challenge" && (r.challenge = {
		by: n,
		previousColor: a,
		guilty: o,
		hand: [...r.hands[n]]
	});
	else if (s.kind === "reverse") r.direction = r.direction === 1 ? -1 : 1, r.turn = F(r, n, r.players.length === 2 ? 2 : 1);
	else if (s.kind === "skip") r.turn = F(r, n, 2);
	else if (r.config.sevenZero && s.kind === "number" && s.value === 7) r.phase = "swap";
	else if (r.config.sevenZero && s.kind === "number" && s.value === 0) {
		let e = r.hands;
		r.hands = Object.fromEntries(r.players.map((t) => [F(r, t), e[t]])), r.turn = F(r, n), I(r, {
			kind: "rotate",
			by: n
		});
	} else r.turn = F(r, n);
	return z(r), { state: r };
}
function W(e, t, n) {
	if ("code" in t) return t;
	let r = t.state, i = r.hands[n]?.filter((t) => !e.hands[n].includes(t)) ?? [], a = r.players.find((t) => t !== n && r.hands[t].some((n) => !e.hands[t].includes(n))), o = a ? r.hands[a].filter((t) => !e.hands[a].includes(t)) : [];
	if ((r.log.at(-1)?.kind === "draw" || r.log.at(-1)?.kind === "challenge" || r.log.at(-1)?.kind === "round" && e.pendingDraw > 0) && (i.length || o.length)) {
		let e = i.length ? n : a, t = i.length ? i : o, s = r.phase;
		return r.phase = "settle", r.pending = {
			kind: "resume",
			phase: s,
			ms: N(t.length),
			incoming: {
				by: e,
				cards: t
			}
		}, {
			state: r,
			fx: [{
				kind: "draw",
				rid: e,
				data: { count: t.length },
				for: [e],
				secret: { cards: t }
			}]
		};
	}
	if (e.color !== r.color || e.direction !== r.direction) {
		let t = r.phase;
		return r.phase = "settle", r.pending = {
			kind: "resume",
			phase: t,
			ms: 100
		}, {
			state: r,
			fx: [{
				kind: "change",
				rid: r.turn,
				data: {
					color: r.color,
					fromColor: e.color,
					direction: r.direction,
					fromDirection: e.direction
				}
			}]
		};
	}
	return t;
}
function le(e, t, { by: n }) {
	if (t.type === "tick") {
		if (e.phase !== "settle" || !e.pending) return { state: e };
		let t = e.pending;
		if (t.kind === "resume") return { state: {
			...e,
			phase: t.phase,
			pending: null
		} };
		let n = {
			...e,
			phase: "play",
			pending: null
		};
		return W(n, U(n, t.action, { by: t.by }), t.by);
	}
	return e.phase === "settle" ? { code: "games.uno.errPhase" } : t.type === "play" && V(e, n, t.card) && (!D(t.card) || t.color) ? {
		state: {
			...e,
			phase: "settle",
			pending: {
				kind: "play",
				by: n,
				action: t
			}
		},
		fx: [{
			kind: "play",
			rid: n,
			data: { card: t.card }
		}]
	} : W(e, U(e, t, { by: n }), n);
}
var ue = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: O,
	schemas: {
		action: oe,
		publicView: ce,
		privateView: M,
		config: j
	},
	setup: H,
	reduce: le,
	nextTickIn: (e) => e.phase === "settle" && e.pending ? e.pending.kind === "play" ? 200 : e.pending.ms : null,
	viewFor: (e, t) => ({
		public: {
			config: e.config,
			phase: e.phase,
			round: e.round,
			turn: e.turn,
			direction: e.direction,
			motion: e.pending?.kind === "play" ? {
				kind: "play",
				by: e.pending.by,
				card: e.pending.action.card
			} : e.pending?.kind === "resume" && e.pending.incoming ? {
				kind: "draw",
				by: e.pending.incoming.by,
				count: e.pending.incoming.cards.length
			} : null,
			top: e.discard[e.discard.length - 1],
			color: e.color,
			deckCount: e.deck.length,
			pendingDraw: e.pendingDraw,
			challenge: e.challenge ? {
				by: e.challenge.by,
				previousColor: e.challenge.previousColor
			} : null,
			challengeResult: e.challengeResult,
			players: e.players.map((t) => ({
				rid: t,
				count: e.hands[t].length - (e.pending?.kind === "resume" && e.pending.incoming?.by === t ? e.pending.incoming.cards.length : 0),
				score: e.scores[t]
			})),
			roundWinner: e.roundWinner,
			roundAward: e.roundAward,
			roundScores: e.roundScores,
			log: e.log
		},
		private: {
			hand: [...e.hands[t] ?? []],
			playable: (e.hands[t] ?? []).filter((n) => V(e, t, n)),
			incoming: e.pending?.kind === "resume" && e.pending.incoming?.by === t ? e.pending.incoming.cards : [],
			drawnCard: t === e.turn ? e.drawnCard : null,
			revealedHand: e.phase === "reveal" && e.challengeResult?.target === t ? e.reveal : null
		}
	}),
	status: (e) => {
		if (e.phase !== "done" || !e.roundWinner) return { phase: e.phase };
		let t = e.roundWinner, n = e.config.mode === "points" ? e.scores : Object.fromEntries(e.players.map((t) => [t, E(e.hands[t])])), r = [t, ...e.players.filter((e) => e !== t).sort((t, r) => e.config.mode === "points" ? n[r] - n[t] : n[t] - n[r])];
		return {
			phase: "done",
			winner: [t],
			ranking: r,
			scores: n
		};
	}
}, G = {
	red: "#e84539",
	yellow: "#edbd2c",
	green: "#299768",
	blue: "#2787c5"
}, de = {
	red: "#874438",
	yellow: "#796424",
	green: "#24654e",
	blue: "#2b6c94"
}, fe = {
	red: "#b72e25",
	yellow: "#edbd2c",
	green: "#166e49",
	blue: "#17679e"
}, K = "#20292b", q = "#fffdf5", J = "Segoe UI Black, Arial Black, sans-serif";
function pe({ color: e, solid: t = !1 }) {
	return /* @__PURE__ */ m("svg", {
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		className: "uno-color-mark",
		fill: t ? "currentColor" : G[e],
		stroke: K,
		strokeWidth: "1.2",
		children: e === "red" ? /* @__PURE__ */ m("circle", {
			cx: "12",
			cy: "12",
			r: "9"
		}) : e === "yellow" ? /* @__PURE__ */ m("path", { d: "M12 2 23 21H1Z" }) : e === "green" ? /* @__PURE__ */ m("rect", {
			x: "3",
			y: "3",
			width: "18",
			height: "18",
			rx: "2"
		}) : /* @__PURE__ */ m("path", { d: "m12 1 11 11-11 11L1 12Z" })
	});
}
function me({ kind: e, value: t }) {
	return e === "number" ? /* @__PURE__ */ h("g", {
		fontSize: "86",
		fontWeight: "950",
		fontFamily: J,
		fontStyle: "italic",
		textAnchor: "middle",
		children: [/* @__PURE__ */ m("text", {
			x: "52",
			y: "102",
			fill: K,
			children: t
		}), /* @__PURE__ */ m("text", {
			x: "49",
			y: "98",
			fill: q,
			stroke: K,
			strokeWidth: "1.2",
			paintOrder: "stroke",
			children: t
		})]
	}) : e === "skip" ? /* @__PURE__ */ h("g", {
		fill: "none",
		strokeLinecap: "round",
		children: [/* @__PURE__ */ h("g", {
			stroke: K,
			strokeWidth: "10",
			children: [/* @__PURE__ */ m("circle", {
				cx: "50",
				cy: "73",
				r: "25"
			}), /* @__PURE__ */ m("path", { d: "m32 91 36-36" })]
		}), /* @__PURE__ */ h("g", {
			stroke: q,
			strokeWidth: "6",
			children: [/* @__PURE__ */ m("circle", {
				cx: "50",
				cy: "73",
				r: "25"
			}), /* @__PURE__ */ m("path", { d: "m32 91 36-36" })]
		})]
	}) : e === "reverse" ? /* @__PURE__ */ h("g", {
		transform: "rotate(-24 50 73)",
		fill: q,
		stroke: K,
		strokeWidth: "1.8",
		strokeLinejoin: "round",
		children: [/* @__PURE__ */ m("path", { d: "M23 69V48q0-14 14-14h17V23l24 21-24 21V53H40v16Z" }), /* @__PURE__ */ m("path", { d: "M77 77v21q0 14-14 14H46v11L22 102l24-21v12h14V77Z" })]
	}) : e === "draw2" ? /* @__PURE__ */ h("g", {
		fill: q,
		stroke: K,
		strokeWidth: "2",
		children: [/* @__PURE__ */ m("rect", {
			x: "25",
			y: "53",
			width: "29",
			height: "46",
			rx: "3",
			transform: "rotate(-14 40 76)"
		}), /* @__PURE__ */ m("rect", {
			x: "49",
			y: "39",
			width: "29",
			height: "46",
			rx: "3",
			transform: "rotate(10 64 62)"
		})]
	}) : e === "wild4" ? /* @__PURE__ */ m("g", { children: [
		"red",
		"yellow",
		"green",
		"blue"
	].map((e, t) => /* @__PURE__ */ h("g", {
		transform: `rotate(${t * 13 - 20} 50 92)`,
		children: [/* @__PURE__ */ m("rect", {
			x: 23 + t * 6,
			y: 44 - t * 2,
			width: "35",
			height: "57",
			rx: "3",
			fill: G[e],
			stroke: K,
			strokeWidth: "2"
		}), /* @__PURE__ */ m("path", {
			d: `M${29 + t * 6} ${50 - t * 2}v36`,
			stroke: q,
			strokeOpacity: ".55",
			strokeWidth: "2"
		})]
	}, e)) }) : /* @__PURE__ */ h("g", {
		transform: "translate(50 73) rotate(25) scale(.85 1.15)",
		children: [
			/* @__PURE__ */ m("path", {
				d: "M0 0V-30A30 30 0 0 1 30 0Z",
				fill: G.red
			}),
			/* @__PURE__ */ m("path", {
				d: "M0 0H30A30 30 0 0 1 0 30Z",
				fill: G.blue
			}),
			/* @__PURE__ */ m("path", {
				d: "M0 0V30A30 30 0 0 1-30 0Z",
				fill: G.green
			}),
			/* @__PURE__ */ m("path", {
				d: "M0 0H-30A30 30 0 0 1 0-30Z",
				fill: G.yellow
			}),
			/* @__PURE__ */ m("circle", {
				r: "30",
				fill: "none",
				stroke: q,
				strokeWidth: "2"
			})
		]
	});
}
function Y({ id: e, back: t = !1 }) {
	if (t || e === void 0) return /* @__PURE__ */ h("svg", {
		viewBox: "0 0 100 146",
		className: "uno-card-face",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ m("rect", {
				x: "1",
				y: "1",
				width: "98",
				height: "144",
				rx: "7",
				fill: q,
				stroke: K,
				strokeWidth: "2"
			}),
			/* @__PURE__ */ m("rect", {
				x: "6",
				y: "6",
				width: "88",
				height: "134",
				rx: "4",
				fill: K
			}),
			/* @__PURE__ */ m("ellipse", {
				cx: "50",
				cy: "73",
				rx: "33",
				ry: "58",
				fill: G.red,
				transform: "rotate(28 50 73)",
				stroke: q,
				strokeWidth: "2.5"
			}),
			/* @__PURE__ */ m("text", {
				x: "50",
				y: "86",
				fill: "#ffe391",
				stroke: K,
				strokeWidth: "2.4",
				paintOrder: "stroke",
				textAnchor: "middle",
				fontFamily: J,
				fontStyle: "italic",
				fontSize: "35",
				fontWeight: "950",
				transform: "rotate(-17 50 73)",
				children: "UNO"
			})
		]
	});
	let n = w(e), r = n.color ? G[n.color] : K, i = n.kind === "number" ? String(n.value) : n.kind === "draw2" ? "+2" : n.kind === "wild4" ? "+4" : n.kind === "reverse" ? "⇄" : n.kind === "skip" ? "⊘" : "✦";
	return /* @__PURE__ */ h("svg", {
		viewBox: "0 0 100 146",
		className: "uno-card-face",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ m("rect", {
				x: "1",
				y: "1",
				width: "98",
				height: "144",
				rx: "7",
				fill: q,
				stroke: K,
				strokeWidth: "2"
			}),
			/* @__PURE__ */ m("rect", {
				x: "6",
				y: "6",
				width: "88",
				height: "134",
				rx: "4",
				fill: r
			}),
			n.kind !== "wild" && /* @__PURE__ */ m("ellipse", {
				cx: "50",
				cy: "73",
				rx: "32",
				ry: "57",
				transform: "rotate(27 50 73)",
				fill: "none",
				stroke: q,
				strokeWidth: "2.8"
			}),
			/* @__PURE__ */ m(me, {
				kind: n.kind,
				value: n.value
			}),
			/* @__PURE__ */ h("g", {
				fill: q,
				fontFamily: J,
				fontStyle: "italic",
				fontSize: "21",
				fontWeight: "900",
				stroke: K,
				strokeWidth: ".5",
				paintOrder: "stroke",
				children: [/* @__PURE__ */ m("text", {
					x: "11",
					y: "28",
					children: i
				}), /* @__PURE__ */ m("text", {
					x: "11",
					y: "28",
					transform: "rotate(180 50 73)",
					children: i
				})]
			}),
			n.color && /* @__PURE__ */ m("g", {
				transform: "translate(75 12) scale(.55)",
				fill: "#fffaf0",
				children: n.color === "red" ? /* @__PURE__ */ m("circle", {
					cx: "10",
					cy: "10",
					r: "8"
				}) : n.color === "yellow" ? /* @__PURE__ */ m("path", { d: "M10 1 20 19H0Z" }) : n.color === "green" ? /* @__PURE__ */ m("rect", {
					x: "2",
					y: "2",
					width: "16",
					height: "16",
					rx: "1"
				}) : /* @__PURE__ */ m("path", { d: "m10 0 10 10-10 10L0 10Z" })
			})
		]
	});
}
function he() {
	return /* @__PURE__ */ h("svg", {
		viewBox: "0 0 100 53",
		className: "uno-logo",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ m("ellipse", {
			cx: "50",
			cy: "26",
			rx: "47",
			ry: "23",
			transform: "rotate(-12 50 26)",
			fill: "#bf392f",
			stroke: K,
			strokeWidth: "2"
		}), /* @__PURE__ */ m("text", {
			x: "50",
			y: "39",
			textAnchor: "middle",
			fill: "#ffe391",
			stroke: K,
			strokeWidth: "1.8",
			paintOrder: "stroke",
			fontFamily: J,
			fontStyle: "italic",
			fontSize: "38",
			fontWeight: "950",
			children: "UNO"
		})]
	});
}
function ge({ direction: e }) {
	return /* @__PURE__ */ m("svg", {
		viewBox: "0 0 64 64",
		className: "uno-direction-mark",
		"aria-hidden": "true",
		children: /* @__PURE__ */ h("g", {
			transform: e === -1 ? "translate(64 0) scale(-1 1)" : void 0,
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "5",
			strokeLinecap: "round",
			strokeLinejoin: "round",
			children: [/* @__PURE__ */ m("path", { d: "M52 25A23 23 0 1 0 51 46" }), /* @__PURE__ */ m("path", { d: "M51 11v16H35" })]
		})
	});
}
//#endregion
//#region src/games/uno/labels.ts
var X = {
	red: "games.uno.color.red",
	yellow: "games.uno.color.yellow",
	green: "games.uno.color.green",
	blue: "games.uno.color.blue"
};
function Z(e, t) {
	let n = w(e), r = n.color ? t(X[n.color]) : "";
	switch (n.kind) {
		case "number": return t("games.uno.card.number", {
			color: r,
			n: n.value
		});
		case "skip": return t("games.uno.card.skip", { color: r });
		case "reverse": return t("games.uno.card.reverse", { color: r });
		case "draw2": return t("games.uno.card.draw2", { color: r });
		case "wild": return t("games.uno.card.wild");
		case "wild4": return t("games.uno.card.wild4");
	}
}
//#endregion
//#region src/games/uno/options.tsx
var _e = {
	off: "games.uno.options.off",
	draw2: "games.uno.options.draw2",
	same: "games.uno.options.same",
	mixed: "games.uno.options.mixed"
}, ve = {
	off: "games.uno.options.stackOffHint",
	draw2: "games.uno.options.draw2Hint",
	same: "games.uno.options.sameHint",
	mixed: "games.uno.options.mixedHint"
};
function ye({ value: e, onChange: t }) {
	let n = c(), r = j.safeParse(e), i = r.success ? r.data : j.parse(void 0), a = (e) => t(j.parse({
		...i,
		...e
	})), o = i.stacking === "same" || i.stacking === "mixed";
	return /* @__PURE__ */ h("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ m(_, {
				title: n("games.uno.options.mode"),
				children: ["single", "points"].map((e) => /* @__PURE__ */ m(g, {
					name: "uno-mode",
					value: e,
					checked: i.mode === e,
					label: n(e === "single" ? "games.uno.options.single" : "games.uno.options.points"),
					accent: O.accent,
					onChange: () => a({ mode: e })
				}, e))
			}),
			/* @__PURE__ */ m(_, {
				title: n("games.uno.options.stacking"),
				children: [
					"off",
					"draw2",
					"same",
					"mixed"
				].map((e) => /* @__PURE__ */ m(g, {
					name: "uno-stacking",
					value: e,
					checked: i.stacking === e,
					label: n(_e[e]),
					hint: n(ve[e]),
					accent: O.accent,
					onChange: () => a({ stacking: e })
				}, e))
			}),
			/* @__PURE__ */ m(_, {
				title: n("games.uno.options.drawRule"),
				children: ["one", "untilPlayable"].map((e) => /* @__PURE__ */ m(g, {
					name: "uno-draw",
					value: e,
					checked: i.drawRule === e,
					label: n(e === "one" ? "games.uno.options.one" : "games.uno.options.untilPlayable"),
					accent: O.accent,
					onChange: () => a({ drawRule: e })
				}, e))
			}),
			/* @__PURE__ */ m(_, {
				title: n("games.uno.options.wildFour"),
				children: ["challenge", "free"].map((e) => /* @__PURE__ */ m(g, {
					name: "uno-four",
					value: e,
					checked: i.wildFour === e,
					disabled: o && e === "challenge",
					label: n(e === "challenge" ? "games.uno.options.challenge" : "games.uno.options.free"),
					accent: O.accent,
					onChange: () => a({ wildFour: e })
				}, e))
			}),
			o && /* @__PURE__ */ m("p", {
				className: "text-sm text-ink/70",
				children: n("games.uno.options.forcedFree")
			}),
			/* @__PURE__ */ m(v, {
				checked: i.sevenZero,
				label: n("games.uno.options.sevenZero"),
				hint: n("games.uno.options.sevenZeroHint"),
				accent: O.accent,
				onChange: () => a({ sevenZero: !i.sevenZero })
			})
		]
	});
}
function be({ config: e }) {
	let t = c(), n = [
		["games.uno.options.mode", t(e.mode === "single" ? "games.uno.options.single" : "games.uno.options.points")],
		["games.uno.options.stacking", t(_e[e.stacking])],
		["games.uno.options.drawRule", t(e.drawRule === "one" ? "games.uno.options.one" : "games.uno.options.untilPlayable")],
		["games.uno.options.wildFour", t(e.wildFour === "challenge" ? "games.uno.options.challenge" : "games.uno.options.free")],
		["games.uno.options.sevenZero", t(e.sevenZero ? "games.uno.options.on" : "games.uno.options.off")]
	];
	return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("p", {
		className: "font-bold",
		children: t("games.uno.automaticUno")
	}), /* @__PURE__ */ m("dl", {
		className: "divide-y divide-ink/15",
		children: n.map(([e, n]) => /* @__PURE__ */ h("div", {
			className: "flex items-center justify-between gap-3 py-3",
			children: [/* @__PURE__ */ m("dt", {
				className: "text-sm text-ink/70",
				children: t(e)
			}), /* @__PURE__ */ m("dd", {
				className: "text-right font-bold",
				children: n
			})]
		}, e))
	})] });
}
//#endregion
//#region src/games/uno/view-player.tsx
function xe(e) {
	return /* @__PURE__ */ m(we, {
		...e,
		pub: e.public,
		priv: e.private
	});
}
function Se({ player: e, member: t, myRid: n, current: r, direction: i, index: a, count: o, points: l }) {
	let d = c(), ee = s((e) => e.locale), { ref: te } = u(`seat:${e.rid}`), p = o > 5 ? Math.ceil(o / 2) : o, g = Math.floor(a / p), _ = g ? 2 * p - a : a + 1;
	return /* @__PURE__ */ h("li", {
		ref: te,
		className: `uno-seat${r ? " uno-seat-current" : ""}`,
		"aria-current": r ? "step" : void 0,
		style: {
			"--uno-col": _,
			"--uno-row": g + 1
		},
		children: [
			/* @__PURE__ */ m("span", {
				className: "uno-seat-avatar",
				children: /* @__PURE__ */ m(f, {
					m: t,
					myRid: n,
					action: r ? "pending" : null,
					anchorName: null,
					box: "uno-avatar-box",
					img: "uno-avatar-image"
				})
			}),
			/* @__PURE__ */ m("span", {
				className: "uno-seat-name",
				title: ne(t, ee),
				children: ne(t, ee)
			}),
			/* @__PURE__ */ h("span", {
				className: "uno-player-status",
				"aria-label": d("games.uno.handAria", { n: e.count }),
				children: [/* @__PURE__ */ m("span", { children: d("games.uno.handCount", { n: e.count }) }), e.count === 1 && /* @__PURE__ */ m("strong", {
					className: "uno-call",
					children: "UNO"
				})]
			}),
			l && /* @__PURE__ */ m("span", {
				className: "uno-player-score",
				children: d("games.uno.score", { n: e.score })
			}),
			a < o - 1 && /* @__PURE__ */ m("span", {
				"aria-hidden": "true",
				className: `uno-seat-flow${g ? " uno-flow-bottom" : ""}${a === p - 1 ? " uno-flow-bend" : ""}`,
				children: i === 1 ? ">" : "<"
			}),
			g && a === o - 1 && o % p === 0 ? /* @__PURE__ */ m("span", {
				"aria-hidden": "true",
				className: "uno-flow-loop",
				children: i === 1 ? ">" : "<"
			}) : null
		]
	});
}
function Ce({ id: e, selected: t, available: n, disabled: r, inFlight: i, onClick: a }) {
	let o = c(), { ref: s, hidden: l } = u(`hand:${e}`);
	return /* @__PURE__ */ h("button", {
		ref: s,
		type: "button",
		"aria-label": Z(e, o),
		disabled: r || !n,
		style: { visibility: l || i ? "hidden" : void 0 },
		className: `uno-hand-card${t ? " uno-selected" : ""}${n ? " uno-available" : ""}`,
		onClick: a,
		children: [/* @__PURE__ */ m(Y, { id: e }), t && /* @__PURE__ */ m("span", {
			className: "uno-selected-mark",
			"aria-hidden": "true",
			children: "✓"
		})]
	});
}
function we({ pub: e, priv: t, members: n, myRid: r, send: f }) {
	d();
	let g = c(), _ = s((e) => e.locale), v = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? ne(t, _) : e;
	}, y = e.turn === r, b = y && e.phase === "play", x = ae(t?.hand ?? []), re = `${e.round}|${e.turn}|${e.phase}|${e.top}|${x.join(",")}`, [C, w] = i(null), T = C?.key === re && t?.playable.includes(C.card) ? C : null, { ref: E } = u("deck"), { ref: ie } = u("discard"), { ref: O } = u("hand"), { ref: k } = u("color"), { ref: A, hidden: j } = u("direction"), { ref: oe } = u("mat"), se = t?.incoming ?? [], [ce, M] = i(!1), [N, P] = i(!1), F = y && (e.phase === "startColor" || T !== null), I = y && e.phase === "reveal" && e.challengeResult !== null, L = g("games.uno.turnWait", { name: v(e.turn) }), R = L;
	y && (R = e.phase === "startColor" || F ? g("games.uno.chooseColor") : e.phase === "swap" ? g("games.uno.chooseTarget") : e.phase === "reveal" ? g("games.uno.revealPrompt") : e.phase === "roundOver" ? g("games.uno.roundOver", { name: v(e.turn) }) : e.challenge ? g("games.uno.challengePrompt") : e.pendingDraw ? g(t?.playable.length ? "games.uno.penalty" : "games.uno.penaltyOnly", { n: e.pendingDraw }) : t?.drawnCard !== null && t?.drawnCard !== void 0 ? g("games.uno.drawnPrompt") : g("games.uno.turnYou"));
	let z = (e) => {
		let t = {
			name: v(e.by),
			n: e.count ?? 0,
			target: v(e.target ?? ""),
			color: e.color ? g(X[e.color]) : "",
			card: e.card === void 0 ? "" : Z(e.card, g)
		};
		switch (e.kind) {
			case "play": return g(e.card !== void 0 && D(e.card) ? "games.uno.log.wild" : "games.uno.log.play", t);
			case "draw": return g("games.uno.log.draw", t);
			case "pass": return g("games.uno.log.pass", t);
			case "color": return g("games.uno.log.color", t);
			case "swap": return g("games.uno.log.swap", t);
			case "rotate": return g("games.uno.log.rotate", t);
			case "challenge": return g(e.success ? "games.uno.log.challengeWon" : "games.uno.log.challengeLost", t);
			case "round": return g("games.uno.log.round", t);
		}
	}, B = e.pendingDraw ? g("games.uno.takePenalty", { n: e.pendingDraw }) : g(e.config.drawRule === "one" ? "games.uno.draw" : "games.uno.drawUntil"), V = b && t?.drawnCard === null, H = V && t.playable.length === 0, U = (t) => {
		e.phase === "startColor" ? f({
			type: "chooseColor",
			color: t
		}) : T && (f({
			type: "play",
			card: T.card,
			color: t
		}), w(null));
	}, W = /* @__PURE__ */ h("table", {
		className: "w-full text-sm",
		children: [/* @__PURE__ */ m("thead", { children: /* @__PURE__ */ h("tr", { children: [
			/* @__PURE__ */ m("th", {
				className: "py-2 text-left",
				children: g("games.uno.round", { n: e.round })
			}),
			/* @__PURE__ */ m("th", {
				className: "text-right",
				children: g("games.uno.remainingPoints")
			}),
			/* @__PURE__ */ m("th", {
				className: "text-right",
				children: g("games.uno.totalPoints")
			})
		] }) }), /* @__PURE__ */ m("tbody", { children: e.roundScores.map((e) => /* @__PURE__ */ h("tr", {
			className: "border-t border-ink/15",
			children: [
				/* @__PURE__ */ m("td", {
					className: "py-3 font-bold",
					children: v(e.rid)
				}),
				/* @__PURE__ */ m("td", {
					className: "text-right font-mono tabular-nums",
					children: e.remaining
				}),
				/* @__PURE__ */ m("td", {
					className: "text-right font-mono tabular-nums",
					children: e.total
				})
			]
		}, e.rid)) })]
	});
	return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(ee, {
		adaptive: !0,
		className: "uno-game",
		scroll: !1,
		actionsHeight: "uno-actions-height",
		banner: /* @__PURE__ */ h("div", {
			className: "uno-banner",
			children: [/* @__PURE__ */ h("div", {
				className: "uno-heading",
				children: [/* @__PURE__ */ m(he, {}), /* @__PURE__ */ h("div", {
					className: "uno-phase",
					children: [/* @__PURE__ */ m("span", { children: g("games.uno.round", { n: e.round }) }), /* @__PURE__ */ m("strong", { children: R })]
				})]
			}), /* @__PURE__ */ m("ol", {
				className: "uno-seats",
				"aria-label": g(e.direction === 1 ? "games.uno.clockwise" : "games.uno.counterclockwise"),
				style: {
					"--uno-seats": e.players.length,
					"--uno-cols": e.players.length > 5 ? Math.ceil(e.players.length / 2) : e.players.length
				},
				children: e.players.map((t, i) => {
					let a = n.find((e) => e.rid === t.rid);
					return a ? /* @__PURE__ */ m(Se, {
						player: t,
						member: a,
						myRid: r,
						current: e.turn === t.rid,
						direction: e.direction,
						index: i,
						count: e.players.length,
						points: e.config.mode === "points"
					}, t.rid) : null;
				})
			})]
		}),
		actions: /* @__PURE__ */ m("div", {
			className: "uno-actions",
			children: b && /* @__PURE__ */ h(p, { children: [
				e.pendingDraw > 0 && /* @__PURE__ */ m("button", {
					className: "btn-base bg-surface",
					onClick: () => f({ type: "draw" }),
					children: B
				}),
				e.challenge && /* @__PURE__ */ m("button", {
					className: "btn-base bg-warn-soft text-warn-ink",
					onClick: () => f({ type: "challenge" }),
					children: g("games.uno.challenge")
				}),
				t?.drawnCard !== null && t?.drawnCard !== void 0 && /* @__PURE__ */ m("button", {
					className: "btn-base bg-surface",
					onClick: () => f({ type: "pass" }),
					children: g("games.uno.pass")
				})
			] })
		}),
		children: /* @__PURE__ */ h("div", {
			ref: oe,
			className: "uno-content",
			"data-color": e.color ?? "none",
			style: {
				"--uno-current": e.color ? G[e.color] : "#6e7a7a",
				"--uno-mat": e.color ? de[e.color] : "#303e40",
				"--uno-label": e.color ? fe[e.color] : "#303e40",
				"--uno-label-ink": e.color === "yellow" ? "#20292b" : "#fffdf5"
			},
			children: [
				/* @__PURE__ */ m(l, {
					kind: "sheen",
					base: "var(--uno-mat)",
					className: "uno-texture"
				}),
				/* @__PURE__ */ h("div", {
					className: "uno-table-tools",
					children: [
						/* @__PURE__ */ m("button", {
							className: "btn-quiet uno-config-button",
							onClick: () => M(!0),
							children: g("games.uno.configuration")
						}),
						e.pendingDraw > 0 && /* @__PURE__ */ m("span", {
							className: "uno-penalty",
							children: g("games.uno.pendingDraw", { n: e.pendingDraw })
						}),
						/* @__PURE__ */ m("button", {
							className: "btn-quiet uno-config-button",
							onClick: () => P(!0),
							children: g("common.log.title")
						})
					]
				}),
				/* @__PURE__ */ m("div", {
					className: "uno-table",
					children: /* @__PURE__ */ h("div", {
						className: "uno-table-piles",
						children: [
							/* @__PURE__ */ h("div", {
								className: "uno-pile",
								children: [/* @__PURE__ */ h("button", {
									ref: E,
									className: `uno-stack${H ? " uno-draw-needed" : ""}`,
									disabled: !V,
									"aria-label": B,
									onClick: () => f({ type: "draw" }),
									children: [/* @__PURE__ */ m(Y, { back: !0 }), H && /* @__PURE__ */ m("span", {
										className: "uno-draw-label",
										"aria-hidden": "true",
										children: B
									})]
								}), /* @__PURE__ */ m("span", {
									className: "uno-pile-count",
									children: g("games.uno.deckCount", { n: e.deckCount })
								})]
							}),
							/* @__PURE__ */ h("div", {
								className: "uno-table-state",
								children: [/* @__PURE__ */ m("span", {
									ref: A,
									style: { visibility: j ? "hidden" : void 0 },
									className: "uno-direction",
									role: "img",
									"aria-label": g(e.direction === 1 ? "games.uno.clockwise" : "games.uno.counterclockwise"),
									children: /* @__PURE__ */ m(ge, { direction: e.direction })
								}), /* @__PURE__ */ m("div", {
									ref: k,
									className: "uno-active-color",
									"aria-label": e.color ? g("games.uno.activeColor", { color: g(X[e.color]) }) : g("games.uno.chooseColor"),
									children: e.color && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(pe, {
										color: e.color,
										solid: !0
									}), /* @__PURE__ */ m("span", { children: g(X[e.color]) })] })
								})]
							}),
							/* @__PURE__ */ h("div", {
								className: "uno-pile",
								children: [/* @__PURE__ */ m("div", {
									ref: ie,
									className: "uno-discard",
									role: "img",
									"aria-label": Z(e.top, g),
									children: /* @__PURE__ */ m(Y, { id: e.top })
								}), /* @__PURE__ */ m("span", {
									className: "uno-pile-count",
									"aria-hidden": "true",
									children: "\xA0"
								})]
							})
						]
					})
				}),
				/* @__PURE__ */ h("section", {
					className: "uno-hand",
					"aria-label": g("games.uno.hand"),
					children: [/* @__PURE__ */ h("div", {
						className: "uno-hand-heading",
						children: [/* @__PURE__ */ m("h2", { children: g("games.uno.hand") }), /* @__PURE__ */ m("span", { children: g("games.uno.handCount", { n: x.length - se.length }) })]
					}), /* @__PURE__ */ m("div", {
						ref: O,
						className: "uno-hand-scroll",
						tabIndex: 0,
						children: /* @__PURE__ */ h("div", {
							className: "uno-hand-cards",
							children: [x.map((n) => /* @__PURE__ */ m(Ce, {
								id: n,
								selected: T?.card === n || e.motion?.kind === "play" && e.motion.by === r && e.motion.card === n && D(n),
								available: t?.playable.includes(n) ?? !1,
								disabled: !b,
								inFlight: se.includes(n) || e.motion?.kind === "play" && e.motion.by === r && e.motion.card === n,
								onClick: () => D(n) ? w({
									key: re,
									card: n
								}) : f({
									type: "play",
									card: n
								})
							}, n)), x.length === 0 && /* @__PURE__ */ m("p", {
								className: "uno-empty-hand",
								children: g("games.uno.emptyHand")
							})]
						})
					})]
				})
			]
		})
	}), a(/* @__PURE__ */ h(p, { children: [
		N && /* @__PURE__ */ m(te, {
			log: e.log,
			line: z,
			onClose: () => P(!1)
		}),
		/* @__PURE__ */ m(o, {
			open: ce,
			onClose: () => M(!1),
			label: g("games.uno.configuration"),
			title: g("games.uno.configuration"),
			children: /* @__PURE__ */ m(be, { config: e.config })
		}),
		/* @__PURE__ */ m(o, {
			open: F,
			onClose: e.phase === "startColor" ? void 0 : () => w(null),
			label: g("games.uno.chooseColor"),
			title: g("games.uno.chooseColor"),
			children: /* @__PURE__ */ m("div", {
				className: "uno-color-choices",
				children: S.map((e) => /* @__PURE__ */ h("button", {
					className: "btn-base uno-color-choice",
					style: { borderColor: G[e] },
					onClick: () => U(e),
					children: [/* @__PURE__ */ m(pe, { color: e }), g(X[e])]
				}, e))
			})
		}),
		/* @__PURE__ */ m(o, {
			open: y && e.phase === "swap",
			label: g("games.uno.chooseTarget"),
			title: g("games.uno.chooseTarget"),
			children: e.players.filter((e) => e.rid !== r).map((e) => /* @__PURE__ */ h("button", {
				className: "btn-base flex items-center justify-between bg-surface",
				onClick: () => f({
					type: "swap",
					target: e.rid
				}),
				children: [/* @__PURE__ */ m("span", {
					className: "truncate",
					children: v(e.rid)
				}), /* @__PURE__ */ m("span", {
					className: "shrink-0",
					children: g("games.uno.handCount", { n: e.count })
				})]
			}, e.rid))
		}),
		/* @__PURE__ */ m(o, {
			open: I,
			label: g("games.uno.revealPrompt"),
			title: g("games.uno.revealPrompt"),
			footer: /* @__PURE__ */ m("div", {
				className: "safe-b p-3",
				children: /* @__PURE__ */ m("button", {
					className: "btn-base uno-primary w-full",
					onClick: () => f({ type: "acknowledge" }),
					children: g("games.uno.acknowledge")
				})
			}),
			children: e.challengeResult && /* @__PURE__ */ h(p, { children: [
				/* @__PURE__ */ m("p", {
					className: "font-bold",
					children: e.challengeResult.success ? g("games.uno.challengeSuccess", {
						name: v(e.challengeResult.by),
						n: e.challengeResult.count
					}) : g("games.uno.challengeFailed", { n: e.challengeResult.count })
				}),
				/* @__PURE__ */ m("p", { children: g("games.uno.challengeColor", { color: g(X[e.challengeResult.previousColor]) }) }),
				/* @__PURE__ */ m("p", { children: g("games.uno.challengeHand", { name: v(e.challengeResult.by) }) }),
				/* @__PURE__ */ h("div", {
					className: "uno-evidence",
					children: [t?.revealedHand?.map((e) => /* @__PURE__ */ m("span", {
						role: "img",
						"aria-label": Z(e, g),
						children: /* @__PURE__ */ m(Y, { id: e })
					}, e)), t?.revealedHand?.length === 0 && /* @__PURE__ */ m("p", { children: g("games.uno.emptyHand") })]
				})
			] })
		}),
		/* @__PURE__ */ h(o, {
			open: e.phase === "roundOver",
			label: g("games.uno.roundOver", { name: v(e.roundWinner ?? "") }),
			title: g("games.uno.roundOver", { name: v(e.roundWinner ?? "") }),
			footer: /* @__PURE__ */ m("div", {
				className: "safe-b p-3",
				children: y ? /* @__PURE__ */ m("button", {
					className: "btn-base uno-primary w-full",
					onClick: () => f({ type: "nextRound" }),
					children: g("games.uno.nextRound")
				}) : /* @__PURE__ */ m("p", {
					className: "py-3 text-center font-bold",
					children: L
				})
			}),
			children: [/* @__PURE__ */ m("p", {
				className: "font-bold",
				children: g("games.uno.winnerPoints", {
					name: v(e.roundWinner ?? ""),
					n: e.roundAward
				})
			}), W]
		})
	] }), document.body)] });
}
//#endregion
//#region src/games/uno/bot.ts
function Q(e) {
	let t = 4294967296 - 4294967296 % e.length, n;
	do
		n = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
	while (n >= t);
	return e[n % e.length];
}
var $ = {
	wild: 42,
	wild4Risky: 95,
	threat1: 130,
	threat2: 0,
	idleAction: -9,
	draw2OnLast: 12,
	duel: 45,
	sameColor: 6,
	points: 2,
	seven: 19,
	zero: 0,
	colorHold: 34,
	voidHit: 26,
	voidColor: 20,
	challenge: .15
}, Te = /* @__PURE__ */ new Set(["play", "pass"]);
function Ee(e) {
	let t = /* @__PURE__ */ new Map(), n = e.log, r = null;
	for (let e = 0; e < n.length; e++) {
		let i = n[e];
		if (i.kind === "play") {
			r = i.color ?? r;
			continue;
		}
		if (i.kind === "round") {
			r = null;
			continue;
		}
		if (i.kind !== "draw" || !r || i.count !== 1) continue;
		let a = n[e + 1];
		!a || a.by === i.by && Te.has(a.kind) || (t.has(i.by) || t.set(i.by, /* @__PURE__ */ new Set()), t.get(i.by).add(r));
	}
	return t;
}
function De(e, t) {
	let n = {
		red: 0,
		yellow: 0,
		green: 0,
		blue: 0
	};
	for (let r of e) {
		if (r === t) continue;
		let e = w(r).color;
		e && (n[e] += 1);
	}
	return n;
}
function Oe(e, t) {
	let n = new Set(e);
	for (let e of t.log) e.kind === "play" && e.card !== void 0 && n.add(e.card);
	return C.filter((e) => !n.has(e.id)).map((e) => e.id);
}
function ke(e, t, n) {
	if (n <= 0 || t <= 0 || e <= 0) return 0;
	let r = 1;
	for (let i = 0; i < n && r > 0; i++) r *= Math.max(0, t - e - i) / Math.max(1, t - i);
	return 1 - r;
}
function Ae(e, t) {
	let n = e.players.findIndex((t) => t.rid === e.turn), r = e.players.length, i = (n + e.direction + r) % r, a = (n - e.direction + r) % r, o = Oe(t.hand, e), s = De(o), c = e.color !== null && t.hand.some((t) => w(t).color === e.color);
	return {
		pub: e,
		priv: t,
		handSize: t.hand.length,
		nextRid: e.players[i].rid,
		nextCount: e.players[i].count,
		prevCount: e.players[a].count,
		minOther: Math.min(...e.players.filter((t) => t.rid !== e.turn).map((e) => e.count)),
		colorCounts: De(t.hand),
		unseenByColor: s,
		unseenTotal: o.length,
		hasColoredPlayable: t.playable.some((e) => w(e).color !== null),
		guilty: c,
		voids: Ee(e)
	};
}
function je(e, t) {
	let n = De(e.priv.hand, t), r = e.voids.get(e.nextRid), i = S[0], a = -Infinity;
	for (let t of S) {
		let o = ke(e.unseenByColor[t], e.unseenTotal, e.nextCount), s = r?.has(t) ? $.voidColor * (e.nextCount <= 3 ? 1 : .4) : 0, c = n[t] * 10 + s - o * (e.nextCount <= 3 ? $.colorHold : $.colorHold / 2.5) - e.unseenByColor[t] / Math.max(1, e.unseenTotal) * 5;
		c > a && (a = c, i = t);
	}
	return i;
}
function Me(e, t) {
	let n = w(t);
	return e.pub.config.sevenZero && n.kind === "number" && n.value === 7;
}
function Ne(e, t) {
	let n = w(t);
	return e.pub.config.sevenZero && n.kind === "number" && n.value === 0;
}
function Pe(e) {
	return e.handSize - 1 < e.minOther;
}
function Fe(e) {
	return e.prevCount > e.handSize - 1 + 1;
}
function Ie(e, t) {
	return w(t).kind === "wild4" && e.pub.config.wildFour === "challenge" && e.guilty;
}
function Le(e, t) {
	let n = w(e), { pub: r } = t, i = t.handSize === 1, a = Me(t, e), o = Ne(t, e), s = 0;
	if (i && (a ? s -= 500 : o ? s -= 800 : Ie(t, e) ? s -= 140 : s += 1e3), n.color === null) {
		let n = Ie(t, e), r = t.hasColoredPlayable ? 1 : .25;
		s -= (n ? $.wild4Risky : $.wild) * r;
	} else s += (t.colorCounts[n.color] - 1) * $.sameColor, r.config.mode === "points" && (s += T(e) * $.points), t.nextCount <= 3 && t.voids.get(t.nextRid)?.has(n.color) && (s += $.voidHit);
	return i || ((n.kind === "skip" || n.kind === "reverse" || n.kind === "draw2") && (t.nextCount <= 2 ? s += t.nextCount === 1 ? $.threat1 : $.threat2 : s += $.idleAction, n.kind === "draw2" && t.nextCount === 1 && (s += $.draw2OnLast), r.players.length === 2 && (s += $.duel)), a && (s += (t.handSize - 1 - t.minOther) * $.seven), o && (s += (t.prevCount - (t.handSize - 1)) * $.zero, t.handSize - 1 <= 1 && (s -= 60))), s;
}
function Re(e, t) {
	return e.handSize <= 1 ? !1 : Me(e, t) && Pe(e) || Ne(e, t) && Fe(e) ? !0 : Ie(e, t);
}
function ze(e, t) {
	return [...t].sort((t, n) => Le(n, e) - Le(t, e) || t - n)[0];
}
var Be = (e, t) => {
	let n = e.public, r = e.private;
	if (!r || n.turn !== t.rid || n.phase === "done" || n.phase === "settle") return null;
	let i = t.difficulty === "weak";
	if (n.phase === "startColor") {
		let e = Ae(n, r);
		return { action: {
			type: "chooseColor",
			color: i ? Q(S) : je(e)
		} };
	}
	if (n.phase === "swap") {
		let e = n.players.filter((e) => e.rid !== t.rid);
		return { action: {
			type: "swap",
			target: (i ? Q(e) : [...e].sort((e, t) => e.count - t.count)[0]).rid
		} };
	}
	if (n.phase === "reveal") return { action: { type: "acknowledge" } };
	if (n.phase === "roundOver") return { action: { type: "nextRound" } };
	if (n.challenge) {
		let e = n.challenge, t = n.players.find((t) => t.rid === e.by), a = Oe(r.hand, n), o = a.filter((t) => w(t).color === e.previousColor).length, s = Ee(n).get(e.by)?.has(e.previousColor) ?? !1, c = ke(o, a.length, t.count) * (s ? .35 : 1), l = $.challenge * (t.count <= 2 ? .85 : 1);
		return (i ? Q([!0, !1]) : c > l) ? { action: { type: "challenge" } } : { action: { type: "draw" } };
	}
	let a = Ae(n, r);
	if (r.playable.length) {
		if (n.pendingDraw) {
			let e = i ? Q(r.playable) : ze(a, r.playable), t = w(e).color === null ? i ? Q(S) : je(a) : void 0;
			return { action: {
				type: "play",
				card: e,
				...t ? { color: t } : {}
			} };
		}
		let e = i ? r.playable : r.playable.filter((e) => !Re(a, e));
		if (!e.length) return r.drawnCard === null ? { action: { type: "draw" } } : { action: { type: "pass" } };
		let t = i ? Q(r.playable) : ze(a, e), o = w(t).color === null ? i ? Q(S) : je(a, t) : void 0;
		return { action: {
			type: "play",
			card: t,
			...o ? { color: o } : {}
		} };
	}
	return r.drawnCard === null ? { action: { type: "draw" } } : { action: { type: "pass" } };
}, Ve = (e, t, n) => {
	switch (e.type) {
		case "tick": return "";
		case "play": return e.color ? n("games.uno.hint.wild", {
			card: Z(e.card, n),
			color: n(X[e.color])
		}) : n("games.uno.hint.play", { card: Z(e.card, n) });
		case "draw": return t.public.pendingDraw ? n("games.uno.hint.penalty", { n: t.public.pendingDraw }) : n("games.uno.hint.draw");
		case "pass": return n("games.uno.hint.pass");
		case "challenge": return n("games.uno.hint.challenge");
		case "chooseColor": return n("games.uno.hint.color", { color: n(X[e.color]) });
		case "swap": return n("games.uno.hint.swap");
		case "acknowledge": return n("games.uno.hint.acknowledge");
		case "nextRound": return n("games.uno.hint.nextRound");
	}
};
//#endregion
//#region src/games/uno/fx.tsx
function He(e, t) {
	return {
		x: e.x + (e.w - t) / 2,
		y: e.y + (e.h - t * 1.46) / 2,
		w: t,
		h: t * 1.46
	};
}
function Ue({ at: e, direction: t, ms: i }) {
	let a = r(null);
	return n(() => {
		let e = a.current?.animate([
			{ transform: "scaleX(1)" },
			{
				transform: "scaleX(0)",
				offset: .5
			},
			{ transform: "scaleX(-1)" }
		], {
			duration: i,
			fill: "both",
			easing: "ease-in-out"
		});
		return () => e?.cancel();
	}, [i]), /* @__PURE__ */ m("span", {
		ref: a,
		className: "uno-fx-change",
		style: {
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: /* @__PURE__ */ m(ge, { direction: t })
	});
}
var We = {
	play(e, t) {
		let n = e.data.card, r = t.anchor("discard"), i = e.rid === t.myRid ? t.anchor(`hand:${n}`) : t.anchor(`seat:${e.rid}`);
		if (!i || !r) return null;
		let a = e.rid === t.myRid ? i : He(i, Math.max(44, Math.min(r.w * .75, i.h))), o = t.queued ? 90 : 180;
		return {
			ms: t.queued ? 100 : 200,
			node: /* @__PURE__ */ m(b, {
				from: a,
				to: r,
				ms: o,
				children: /* @__PURE__ */ m("span", {
					className: "uno-fx-card",
					style: {
						width: a.w,
						height: a.h
					},
					children: /* @__PURE__ */ m(Y, { id: n })
				})
			})
		};
	},
	draw(e, t) {
		let n = e.data.count, r = e.secret?.cards, i = t.anchor("deck"), a = t.anchor(`seat:${e.rid}`), o = e.rid === t.myRid ? t.anchor("hand") : null;
		if (!i || !a || n < 1) return null;
		let s = Math.min(n, 12), c = t.queued > 0, l = c ? 90 : 160, u = c ? 4 : 12;
		return {
			ms: c ? l + s * u : N(n),
			node: /* @__PURE__ */ h(p, { children: [Array.from({ length: s }, (e, n) => {
				let s = r?.[n], c = s !== void 0 && o ? t.anchor(`hand:${s}`) : null, d = c ?? He(a, Math.min(58, a.h));
				return o && c && (d = {
					...c,
					x: Math.max(o.x + 4, Math.min(c.x, o.x + o.w - c.w - 4))
				}), /* @__PURE__ */ m(b, {
					from: i,
					to: d,
					ms: l,
					delay: n * u,
					children: /* @__PURE__ */ m("span", {
						className: "uno-fx-card",
						style: {
							width: i.w,
							height: i.h
						},
						children: /* @__PURE__ */ m(Y, {
							id: s,
							back: s === void 0
						})
					})
				}, n);
			}), /* @__PURE__ */ h(y, {
				at: a,
				ms: 80,
				delay: l + (s - 1) * u - 40,
				children: ["+", n]
			})] })
		};
	},
	change(e, t) {
		let n = e.data, r = t.anchor("direction"), i = t.anchor("color"), a = t.anchor(`seat:${e.rid}`), o = n.direction !== n.fromDirection, s = t.queued ? 70 : 100;
		return {
			ms: s,
			hide: o && !t.queued ? ["direction"] : [],
			node: /* @__PURE__ */ h(p, { children: [
				o && r && !t.queued && /* @__PURE__ */ m(Ue, {
					at: r,
					direction: n.fromDirection,
					ms: s
				}),
				n.color !== n.fromColor && i && /* @__PURE__ */ m(x, {
					at: i,
					ms: s
				}),
				a && /* @__PURE__ */ m(x, {
					at: a,
					ms: s
				})
			] })
		};
	}
};
//#endregion
//#region src/games/uno/game-over-row.tsx
function Ge({ public: e, rid: t }) {
	let n = c(), r = e, i = r.roundScores.find((e) => e.rid === t);
	return i ? /* @__PURE__ */ h("span", {
		className: "text-xs text-ink/70",
		children: [
			n("games.uno.remainingPoints"),
			": ",
			i.remaining,
			r.config.mode === "points" && /* @__PURE__ */ h(p, { children: [
				" · ",
				n("games.uno.earnedPoints"),
				": ",
				i.earned
			] })
		]
	}) : null;
}
//#endregion
//#region .bgparty/cache/pack-entry/uno/entry.tsx
var Ke = {
	definition: ue,
	View: xe,
	bot: Be,
	describe: Ve,
	fx: We,
	RowView: Ge,
	Options: ye,
	locales: {
		zh: {
			name: "UNO",
			desc: "匹配颜色或数字出牌，巧用功能牌，率先清空手牌",
			rules: "目标：\n· 单局模式率先清空手牌获胜；积分赛率先达到 500 分获胜。\n准备：\n· 使用经典 108 张牌，2–10 人，每人起手 7 张。\n· 数字牌 76 张，跳过、反转、加二各 8 张，两种万能牌各 4 张。\n· 庄家随机确定，从庄家左侧开始，后续每局轮换庄家。\n出牌：\n· 每回合出 1 张与顶牌颜色、数字或功能相同的牌，或出万能牌。\n· 万能牌指定后续颜色；加四还使下家抽 4 张并跳过回合。\n· 跳过使下家跳过回合；反转改变行进方向。\n· 两人局反转等同跳过，出牌者继续行动。\n· 加二使下家抽 2 张并跳过回合。\n· 可以主动抽牌；普通抽牌默认只抽 1 张，不能连续抽牌。\n· 抽牌后，只能打出刚抽到的那张牌；也可以保留该牌，并结束回合。\n· 抽到无法出牌的牌后自动结束回合。\n· 剩余 1 张手牌时自动宣告 UNO，没有漏喊罚牌。\n· 牌库耗尽后保留弃牌顶牌，重洗其余弃牌；无牌可抽时结束回合。\n首牌：\n· 首牌为加二或跳过时，对庄家左侧玩家生效。\n· 首牌为反转时庄家先行动，方向反转。\n· 首牌为普通万能牌时，由庄家左侧玩家选择颜色并开始行动。首牌为加四牌时，将其洗回牌堆，再重新翻开一张首牌。\n加四质疑：\n· 官方模式下，手中有当前颜色的牌时使用加四属于违规。\n· 允许冒险出牌；受罚者可选择接受罚牌或质疑。\n· 质疑时仅质疑者查看出牌者当时剩余的手牌。\n· 质疑成功，出牌者抽 4 张，质疑者正常行动。\n· 质疑失败，质疑者抽 6 张并跳过回合。\n可选规则：\n· 仅加二叠加：加二可接加二；加四不能参与叠加。\n· 同类叠加：加二接加二，加四接加四，颜色不限。\n· 混合叠加：加二与加四可互接，颜色不限，罚牌数量累计。\n· 受罚者可继续叠加，或抽取全部累计罚牌并跳过回合。\n· 罚牌期间不能用跳过、反转或普通万能牌抵消。\n· 同类或混合叠加时，加四自由使用且不质疑。\n· 连续抽牌：普通抽牌持续到抽到可出的牌，再选择出牌或保留。\n· 7–0：出 7 后选择一名对手交换手牌，出 0 按当前方向轮转手牌。\n· 先完成手牌交换，再检查是否有玩家的手牌为空。接收到空手牌的玩家获胜。\n结算：\n· 有人清空手牌后不再叠加，先处理末张罚牌与加四质疑。\n· 数字牌按面值，跳过、反转、加二各 20 分，两种万能牌各 50 分。\n· 单局赢家排名第一，其余玩家按剩余牌分从低到高排列。\n· 积分赛赢家获得其余玩家剩余牌分总和，累计至 500 分获胜。",
			color: {
				red: "红色",
				yellow: "黄色",
				green: "绿色",
				blue: "蓝色"
			},
			card: {
				number: "{{color}} {{n}}",
				skip: "{{color}}跳过",
				reverse: "{{color}}反转",
				draw2: "{{color}}加二",
				wild: "万能牌",
				wild4: "万能加四",
				back: "牌背"
			},
			options: {
				mode: "胜负模式",
				single: "单局结束",
				points: "500 分积分赛",
				stacking: "罚牌叠加",
				off: "关闭",
				on: "开启",
				draw2: "仅加二",
				same: "同类叠加",
				mixed: "混合叠加",
				stackOffHint: "受罚后跳过回合",
				draw2Hint: "加二接加二",
				sameHint: "相同罚牌互接",
				mixedHint: "加二与加四互接",
				drawRule: "普通抽牌",
				one: "抽 1 张",
				untilPlayable: "抽到可以出牌",
				wildFour: "万能加四",
				challenge: "官方限制与质疑",
				free: "自由使用，不质疑",
				forcedFree: "同类或混合叠加时，加四自由使用且不质疑。",
				sevenZero: "7–0 换手",
				sevenZeroHint: "出 7 交换手牌，出 0 轮转手牌"
			},
			round: "第 {{n}} 局",
			turnYou: "轮到你出牌",
			turnWait: "等待 {{name}} 行动",
			chooseColor: "选择后续颜色",
			chooseTarget: "选择交换手牌的对手",
			penalty: "抽取 {{n}} 张罚牌，或叠加罚牌",
			penaltyOnly: "抽取 {{n}} 张罚牌",
			challengePrompt: "接受加四罚牌，或提出质疑",
			drawnPrompt: "打出刚抽到的牌，或结束回合",
			revealPrompt: "查看质疑结果",
			roundOver: "{{name}} 赢得本局",
			play: "出牌",
			draw: "抽牌",
			drawUntil: "抽到可以出牌",
			takePenalty: "接受罚牌 {{n}} 张",
			pass: "保留并结束回合",
			challenge: "质疑加四",
			acknowledge: "继续对局",
			nextRound: "开始下一局",
			cancel: "取消",
			wait: "等待其他玩家",
			hand: "我的手牌",
			handCount: "{{n}} 张",
			handAria: "{{n}} 张手牌",
			drawPile: "抽牌堆",
			discard: "弃牌堆",
			deckCount: "余 {{n}} 张",
			direction: "行进方向",
			clockwise: "顺时针",
			counterclockwise: "逆时针",
			activeColor: "当前颜色：{{color}}",
			pendingDraw: "累计罚牌 {{n}} 张",
			configuration: "本局规则",
			score: "累计 {{n}} 分",
			automaticUno: "自动宣告 UNO",
			winnerPoints: "{{name}} 获得 {{n}} 分",
			totalPoints: "累计得分",
			remainingPoints: "剩余牌分",
			earnedPoints: "本局得分",
			challengeSuccess: "质疑成功，{{name}} 抽取 {{n}} 张",
			challengeFailed: "质疑失败，你抽取 {{n}} 张并跳过回合",
			challengeHand: "{{name}} 出加四时的手牌",
			challengeColor: "当时的颜色：{{color}}",
			emptyHand: "没有剩余手牌",
			log: {
				play: "{{name}} 打出{{card}}",
				wild: "{{name}} 打出{{card}}，指定{{color}}",
				draw: "{{name}} 抽取 {{n}} 张牌",
				pass: "{{name}} 保留抽到的牌",
				color: "{{name}} 指定{{color}}",
				swap: "{{name}} 与 {{target}} 交换手牌",
				rotate: "{{name}} 使全员轮转手牌",
				challengeWon: "{{name}} 质疑成功，{{target}} 抽取 {{n}} 张",
				challengeLost: "{{name}} 质疑失败，抽取 {{n}} 张",
				round: "{{name}} 赢得本局，获得 {{n}} 分"
			},
			hint: {
				play: "打出{{card}}",
				wild: "打出{{card}}，指定{{color}}",
				draw: "抽牌",
				penalty: "接受 {{n}} 张罚牌",
				pass: "保留抽到的牌并结束回合",
				challenge: "质疑万能加四",
				color: "选择{{color}}",
				swap: "与手牌较少的对手交换",
				acknowledge: "确认质疑结果",
				nextRound: "开始下一局"
			},
			errTurn: "请等待轮到你行动",
			errPhase: "请先完成当前操作",
			errCard: "这张牌现在不能打出",
			errColor: "请先选择后续颜色",
			errTarget: "请选择另一名玩家",
			errAlreadyDrew: "请打出刚抽到的牌，或结束回合",
			errFinished: "对局已经结束",
			errPlayer: "你不在本局玩家中"
		},
		en: {
			name: "UNO",
			desc: "Match colors or numbers, use action cards, and empty your hand first",
			rules: "Goal:\n· Empty your hand first in a single round, or reach 500 points in a match.\nSetup:\n· Use the classic 108-card deck for 2–10 players; deal 7 cards each.\n· There are 76 number cards, 8 each of Skip, Reverse and Draw Two, and 4 of each Wild.\n· Choose a random dealer; start on their left. The dealer changes each round.\nPlay:\n· Play one card matching the top card’s color, number or action, or play a Wild.\n· A Wild sets the next color; Wild Draw Four also makes the next player draw 4 and miss a turn.\n· Skip makes the next player miss a turn; Reverse changes direction.\n· In a two-player game, Reverse acts as Skip: the same player goes again.\n· Draw Two makes the next player draw 2 and miss a turn.\n· You may draw voluntarily. By default, draw only one card.\n· After drawing, play only the card just drawn, or keep it and end your turn.\n· Drawing an unplayable card ends your turn automatically.\n· UNO is called automatically at one card; there is no missed-call penalty.\n· Keep the top discard and reshuffle the rest when the deck runs out; end the turn if none remain.\nFirst card:\n· An initial Draw Two or Skip affects the player to the dealer’s left.\n· An initial Reverse makes the dealer start and reverses direction.\n· For an initial Wild, the first player chooses a color and plays; reshuffle an initial Wild Draw Four.\nDraw Four challenges:\n· Under official restrictions, playing Draw Four with a card of the current color is illegal.\n· Bluffing is allowed; the affected player may accept the penalty or challenge.\n· Only the challenger sees the offender’s remaining hand at the time of play.\n· A successful challenge makes the offender draw 4; the challenger takes a normal turn.\n· A failed challenge makes the challenger draw 6 and miss their turn.\nOptional rules:\n· Draw Two only: stack Draw Two on Draw Two; Draw Four cannot join a stack.\n· Same type: stack Draw Two on Draw Two or Draw Four on Draw Four, regardless of color.\n· Mixed: stack Draw Two and Draw Four on either type, regardless of color; add their penalties.\n· Stack another penalty card, or draw the full accumulated penalty and miss your turn.\n· Skip, Reverse and regular Wild cards cannot cancel a pending penalty.\n· Same-type and mixed stacking use unrestricted Draw Four without challenges.\n· Draw until playable: keep drawing until a playable card, then play it or keep it.\n· 7–0: a 7 swaps hands with a chosen opponent; a 0 passes every hand in the current direction.\n· Complete the hand exchange before checking for an empty hand; its recipient wins.\nScoring:\n· Once a hand is empty, stop stacking and resolve the final penalty and any Draw Four challenge.\n· Number cards score face value; Skip, Reverse and Draw Two score 20; either Wild scores 50.\n· In a single round, the winner ranks first; others rank by remaining points, lowest first.\n· The round winner earns everyone else’s remaining card points; first to 500 wins the match.",
			color: {
				red: "Red",
				yellow: "Yellow",
				green: "Green",
				blue: "Blue"
			},
			card: {
				number: "{{color}} {{n}}",
				skip: "{{color}} Skip",
				reverse: "{{color}} Reverse",
				draw2: "{{color}} Draw Two",
				wild: "Wild",
				wild4: "Wild Draw Four",
				back: "Card back"
			},
			options: {
				mode: "Game length",
				single: "Single round",
				points: "500-point match",
				stacking: "Penalty stacking",
				off: "Off",
				on: "On",
				draw2: "Draw Two only",
				same: "Same type",
				mixed: "Mixed types",
				stackOffHint: "Draw and miss a turn",
				draw2Hint: "Draw Two on Draw Two",
				sameHint: "Match penalty type",
				mixedHint: "Mix Draw Two and Four",
				drawRule: "Normal drawing",
				one: "Draw one",
				untilPlayable: "Draw until playable",
				wildFour: "Wild Draw Four",
				challenge: "Official + challenges",
				free: "Free, no challenges",
				forcedFree: "Same-type or mixed stacking uses unrestricted Draw Four without challenges.",
				sevenZero: "7–0 hand exchange",
				sevenZeroHint: "7 swaps two hands; 0 passes all hands"
			},
			round: "Round {{n}}",
			turnYou: "Your turn",
			turnWait: "Waiting for {{name}}",
			chooseColor: "Choose the next color",
			chooseTarget: "Choose a hand to swap with",
			penalty: "Draw {{n}} penalty cards, or stack",
			penaltyOnly: "Draw {{n}} penalty cards",
			challengePrompt: "Accept Draw Four, or challenge",
			drawnPrompt: "Play the drawn card, or end your turn",
			revealPrompt: "Review the challenge",
			roundOver: "{{name}} wins the round",
			play: "Play",
			draw: "Draw",
			drawUntil: "Draw until playable",
			takePenalty: "Draw {{n}} penalty cards",
			pass: "Keep and end turn",
			challenge: "Challenge",
			acknowledge: "Continue",
			nextRound: "Next round",
			cancel: "Cancel",
			wait: "Waiting for other players",
			hand: "My hand",
			handCount: "{{n}} cards",
			handAria: "{{n}} cards in hand",
			drawPile: "Draw pile",
			discard: "Discard pile",
			deckCount: "{{n}} left",
			direction: "Direction",
			clockwise: "Clockwise",
			counterclockwise: "Counterclockwise",
			activeColor: "Current color: {{color}}",
			pendingDraw: "{{n}} penalty cards",
			configuration: "This game’s rules",
			score: "{{n}} points",
			automaticUno: "Automatic UNO",
			winnerPoints: "{{name}} earns {{n}} points",
			totalPoints: "Total points",
			remainingPoints: "Cards remaining",
			earnedPoints: "Points earned",
			challengeSuccess: "Challenge won: {{name}} draws {{n}}",
			challengeFailed: "Challenge lost: you draw {{n}} and miss your turn",
			challengeHand: "{{name}}’s hand when playing Draw Four",
			challengeColor: "Previous color: {{color}}",
			emptyHand: "No cards remaining",
			log: {
				play: "{{name}} plays {{card}}",
				wild: "{{name}} plays {{card}}, choosing {{color}}",
				draw: "{{name}} draws {{n}} cards",
				pass: "{{name}} keeps the drawn card",
				color: "{{name}} chooses {{color}}",
				swap: "{{name}} swaps hands with {{target}}",
				rotate: "{{name}} passes all hands",
				challengeWon: "{{name}} wins the challenge; {{target}} draws {{n}}",
				challengeLost: "{{name}} loses the challenge and draws {{n}}",
				round: "{{name}} wins the round and earns {{n}} points"
			},
			hint: {
				play: "Play {{card}}",
				wild: "Play {{card}}, choosing {{color}}",
				draw: "Draw a card",
				penalty: "Accept {{n}} penalty cards",
				pass: "Keep the drawn card and end your turn",
				challenge: "Challenge the Wild Draw Four",
				color: "Choose {{color}}",
				swap: "Swap with an opponent holding fewer cards",
				acknowledge: "Confirm the challenge result",
				nextRound: "Start the next round"
			},
			errTurn: "Please wait for your turn",
			errPhase: "Complete the current action first",
			errCard: "You cannot play that card now",
			errColor: "Choose the next color first",
			errTarget: "Choose another player",
			errAlreadyDrew: "Play the drawn card or end your turn",
			errFinished: "The game has ended",
			errPlayer: "You are not a player in this game"
		}
	}
};
//#endregion
export { Ke as default };
