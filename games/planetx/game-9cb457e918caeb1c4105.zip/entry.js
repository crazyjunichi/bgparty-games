import { randomAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useId as n, useState as r } from "react";
import { create as i } from "zustand";
import { persist as a } from "zustand/middleware";
import { BottomSheet as o } from "@bgparty/sdk/bottom-sheet";
import { useT as s } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as c } from "@bgparty/sdk/player-colors";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { GameOverScreen as p } from "@bgparty/sdk/ui/game-over-screen";
import { OptionRadio as m, OptionSection as h } from "@bgparty/sdk/ui/game-options";
//#region src/games/planetx/board.ts
var g = [
	"asteroid",
	"comet",
	"gasCloud",
	"dwarfPlanet"
], _ = {
	sectors: 12,
	counts: {
		asteroid: 4,
		comet: 2,
		gasCloud: 2,
		dwarfPlanet: 1,
		empty: 2,
		planetX: 1
	},
	cometSectors: [
		1,
		2,
		4,
		6,
		10
	],
	numResearch: 6,
	conferenceCells: [8],
	theoryInterval: 3,
	skySize: 6,
	surveyCosts: [{
		maxWidth: 3,
		cost: 4
	}, {
		maxWidth: 6,
		cost: 3
	}],
	targetCost: 4,
	researchCost: 1,
	locateCost: 5,
	numTargets: 2,
	theoriesPerTurn: 1,
	theoryTokens: {
		asteroid: 4,
		comet: 2,
		gasCloud: 2,
		dwarfPlanet: 1
	},
	scoreValues: {
		asteroid: 2,
		comet: 3,
		gasCloud: 4,
		dwarfPlanet: 4
	},
	startingClues: {
		beginner: 8,
		experienced: 4,
		genius: 0
	}
};
function v(e, t) {
	for (let n of e.surveyCosts) if (t <= n.maxWidth) return n.cost;
	return e.surveyCosts[e.surveyCosts.length - 1].cost;
}
function y(e, t, n) {
	let r = Math.abs(t - n) % e.sectors;
	return Math.min(r, e.sectors - r);
}
function b(e, t, n) {
	return (n - t + e.sectors) % e.sectors;
}
function x(e) {
	let t = {
		asteroid: 0,
		comet: 0,
		gasCloud: 0,
		dwarfPlanet: 0,
		empty: 0,
		planetX: 0
	};
	for (let n of e) t[n]++;
	return t;
}
function S(e, t, n) {
	let r = [];
	if (t.forEach((e, t) => {
		e === n && r.push(t);
	}), r.length === 0) return 0;
	let i = 0;
	for (let t = 0; t < r.length; t++) {
		let n = (r[(t + 1) % r.length] - r[t] + e.sectors) % e.sectors;
		n > i && (i = n);
	}
	return e.sectors - i + 1;
}
function C(e, t) {
	let n = e.sectors;
	for (let r = 0; r < n; r++) if (t[r] === "comet" && !e.cometSectors.includes(r)) return !1;
	for (let e = 0; e < n; e++) {
		let r = t[(e - 1 + n) % n], i = t[(e + 1) % n];
		if (t[e] === "asteroid" && r !== "asteroid" && i !== "asteroid" || t[e] === "gasCloud" && r !== "empty" && i !== "empty" || t[e] === "planetX" && (r === "dwarfPlanet" || i === "dwarfPlanet")) return !1;
	}
	return !0;
}
function w(e, t, n = 200) {
	let r = [];
	for (let [t, n] of Object.entries(e.counts)) for (let e = 0; e < n; e++) r.push(t);
	for (let i = 0; i < n; i++) {
		let n = [...r];
		for (let e = n.length - 1; e > 0; e--) {
			let r = Math.floor(t() * (e + 1));
			[n[e], n[r]] = [n[r], n[e]];
		}
		if (C(e, n)) return n;
	}
	return null;
}
function T(e, t, n) {
	if (t[n] !== "empty") return !1;
	let r = t.indexOf("planetX"), i = [...t];
	return i[r] = "empty", i[n] = "planetX", C(e, i);
}
//#endregion
//#region src/games/planetx/rules-gen.ts
function E(e, t) {
	if (t < 0 || t > e) return 0;
	let n = 1;
	for (let r = 0; r < t; r++) n = n * (e - r) / (r + 1);
	return Math.round(n);
}
function ee(e) {
	let t = 1;
	for (let n = 2; n <= e; n++) t *= n;
	return t;
}
function D(e, t) {
	let n = 1;
	for (let r = 0; r < t; r++) n *= e - r;
	return n;
}
function te(e, t = 2) {
	if (e < t) return [];
	let n = [[e]];
	for (let r = t; r <= Math.floor(e / 2); r++) for (let t of te(e - r, r)) n.push([r, ...t]);
	return n;
}
function O(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(n, (t.get(n) ?? 0) + 1);
	let n = 1;
	for (let e of t.values()) n *= ee(e);
	return n;
}
function k(e) {
	switch (e.kind) {
		case "adjacent":
		case "opposite":
		case "within": return [e.obj1, e.obj2];
		default: return [e.obj];
	}
}
function A(e) {
	let t = k(e);
	return t[t.length - 1] === "empty" ? t.slice(0, -1) : t;
}
function j(e, t) {
	let n = e.filter((e) => e !== "empty"), r = t.filter((e) => e !== "empty");
	return n.length === r.length && n.every((e) => r.includes(e));
}
function M(e) {
	return e.kind === "adjacent" || e.kind === "opposite" || e.kind === "within";
}
function N(e) {
	return !M(e);
}
function ne(e, t) {
	if (e.kind !== t.kind) return !1;
	if (M(e) && M(t)) return e.kind === "within" && t.kind === "within" && e.n !== t.n || e.qualifier !== t.qualifier ? !1 : e.qualifier === "every" ? e.obj1 === t.obj1 && e.obj2 === t.obj2 : e.obj1 === t.obj1 && e.obj2 === t.obj2 || e.obj1 === t.obj2 && e.obj2 === t.obj1;
	if (N(e) && N(t)) {
		if (e.kind === "band" && t.kind === "band") return e.obj === t.obj && e.band === t.band && e.precision === t.precision;
		if (e.kind === "sectors" && t.kind === "sectors") return e.obj === t.obj && re(e.positions, t.positions);
		if ((e.kind === "adjacentSelf" || e.kind === "oppositeSelf") && e.kind === t.kind) return e.obj === t.obj && e.qualifier === t.qualifier;
	}
	return !1;
}
function re(e, t) {
	return e.length === t.length && e.every((e) => t.includes(e));
}
function ie(e, t, n) {
	let r = t.map((t) => 2 * e[t]), i = t.map(() => !1);
	for (let a of n) {
		if (a.kind !== "adjacent" && a.kind !== "adjacentSelf") continue;
		let n = k(a);
		if (j(n, t)) return [
			!1,
			!1,
			!1
		];
		let o = n.filter((e) => t.includes(e));
		if (o.length === 0) continue;
		let s = a.qualifier;
		for (let c = 0; c < t.length; c++) o.includes(t[c]) && (s === "none" ? i[c] = !0 : s === "every" ? r[c] -= e[n[0]] : r[c] -= a.kind === "adjacent" ? 1 : 2);
	}
	let a = !0, o = !0, s = !0;
	for (let n = 0; n < r.length; n++) {
		let c = r[n];
		c === 0 && (a = !1);
		let l = e[t[0]];
		(c < l || c === l && i[n]) && (s = !1), (c < 1 || c === 1 && i[n]) && (o = !1);
	}
	return [
		a,
		o,
		s
	];
}
function P(e, t) {
	return t[Math.floor(e() * t.length)];
}
function F(e, t, n) {
	let r = e.sectors, i = x(n), a = Math.floor(r / 2);
	switch (t.kind) {
		case "adjacent": {
			let e = 0;
			for (let i = 0; i < r; i++) n[i] === t.obj1 && (n[(i - 1 + r) % r] === t.obj2 || n[(i + 1) % r] === t.obj2) && e++;
			return t.qualifier === "none" ? e === 0 : t.qualifier === "atLeastOne" ? e > 0 : e === i[t.obj1];
		}
		case "opposite": {
			if (r % 2 != 0) return t.qualifier === "none";
			let e = 0;
			for (let i = 0; i < r; i++) n[i] === t.obj1 && n[(i + a) % r] === t.obj2 && e++;
			return t.qualifier === "none" ? e === 0 : t.qualifier === "atLeastOne" ? e > 0 : e === i[t.obj1];
		}
		case "within": {
			let a = n.map((e, n) => e === t.obj2 ? n : -1).filter((e) => e >= 0), o = 0;
			for (let i = 0; i < r; i++) n[i] === t.obj1 && Math.min(...a.map((t) => y(e, i, t))) <= t.n && o++;
			return t.qualifier === "none" ? o === 0 : t.qualifier === "atLeastOne" ? o > 0 : o === i[t.obj1];
		}
		case "adjacentSelf": {
			let e = 0;
			for (let i = 0; i < r; i++) n[i] === t.obj && (n[(i - 1 + r) % r] === t.obj || n[(i + 1) % r] === t.obj) && e++;
			return t.qualifier === "none" ? e === 0 : t.qualifier === "atLeastOne" ? e > 0 : e === i[t.obj];
		}
		case "oppositeSelf": {
			if (r % 2 != 0) return t.qualifier === "none";
			let e = 0;
			for (let i = 0; i < r; i++) n[i] === t.obj && n[(i + a) % r] === t.obj && e++;
			return t.qualifier === "none" ? e === 0 : t.qualifier === "atLeastOne" ? e > 0 : e === i[t.obj];
		}
		case "band": {
			let r = S(e, n, t.obj);
			return t.precision === "exactly" ? r === t.band : r <= t.band;
		}
		case "sectors":
			for (let e = 0; e < r; e++) if (n[e] === t.obj && !t.positions.includes(e)) return !1;
			return !0;
	}
}
function ae(e, t, n) {
	let r = e.sectors, i = [];
	if (t.kind === "opposite" && r % 2 != 0) return i;
	let a = Math.floor(r / 2);
	for (let o = 0; o < r; o++) {
		if (n[o] === t.obj2) continue;
		let s;
		if (t.kind === "adjacent") s = n[(o - 1 + r) % r] === t.obj2 || n[(o + 1) % r] === t.obj2;
		else if (t.kind === "opposite") s = n[(o + a) % r] === t.obj2;
		else {
			let r = n.map((e, n) => e === t.obj2 ? n : -1).filter((e) => e >= 0);
			s = r.length > 0 && Math.min(...r.map((t) => y(e, o, t))) <= t.n;
		}
		s && i.push(o);
	}
	return i;
}
function oe(e, t, n) {
	let r = e.sectors, i = x(n);
	if (M(t)) {
		let a = i[t.obj1], o = r - i[t.obj2], s = ae(e, t, n).length, c = E(o, a);
		return c <= 1 ? 0 : t.qualifier === "none" ? (c - E(o - s, a)) / (c - 1) : t.qualifier === "atLeastOne" ? E(o - s, a) / (c - 1) : (c - E(s, a)) / (c - 1);
	}
	if (t.kind === "adjacentSelf") {
		let e = i[t.obj], n = E(r, e);
		if (t.qualifier === "every") {
			let t = 0;
			for (let n of te(e)) {
				let i = O(n), a = r - e - 1, o = r;
				a >= n.length - 1 ? o *= D(a, n.length - 1) : o = 0, o = Math.floor(o / i), t += o;
			}
			return (n - t) / (n - 1);
		}
		if (r < 2 * e) return 0;
		let a = r - e - 1, o = r;
		return a >= e - 1 ? o *= D(a, e - 1) : o = 0, o = Math.floor(o / ee(e)), t.qualifier === "none" ? (n - o) / (n - 1) : o / (n - 1);
	}
	if (t.kind === "oppositeSelf") {
		if (r % 2 != 0) return 0;
		let e = i[t.obj], n = r / 2, a = E(r, e);
		if (t.qualifier === "every") return (a - E(n, Math.floor(e / 2))) / (a - 1);
		if (r < 2 * e) return 0;
		let o = 1;
		for (let t = 0; t < e; t++) o *= r - 2 * t;
		return o = Math.floor(o / ee(e)), t.qualifier === "none" ? (a - o) / (a - 1) : o / (a - 1);
	}
	if (t.kind === "band") {
		let e = i[t.obj], n = E(r, e);
		return (n - (t.precision === "exactly" ? r * E(t.band - 2, e - 2) : r * E(t.band - 1, e - 1))) / (n - 1);
	}
	let a = i[t.obj], o = E(r, a);
	return (o - E(t.positions.length, a)) / (o - 1);
}
function I(e, t, n, r, i, a, o) {
	let s = x(t), c = s[i], l = s[a], u = e.sectors;
	for (let e of r) if (j(k(e), [i, a])) return null;
	let [d, f, p] = ie(s, [i, a], [...n, ...r]);
	if (!d && !f && !p) return null;
	let m = 0;
	for (let e = 0; e < u; e++) t[e] === i && (t[(e - 1 + u) % u] === a || t[(e + 1) % u] === a) && m++;
	let h;
	return h = m === 0 ? ["none"] : m < c ? ["atLeastOne"] : ["atLeastOne", "every"], c === 1 && (h = h.filter((e) => e !== "atLeastOne")), c >= 2 * l && (h = h.filter((e) => e !== "every")), p || (h = h.filter((e) => e !== "every")), f || (h = h.filter((e) => e !== "atLeastOne")), d || (h = h.filter((e) => e !== "none")), h.length === 0 ? null : {
		kind: "adjacent",
		obj1: i,
		obj2: a,
		qualifier: P(o, h)
	};
}
function se(e, t, n, r, i, a, o) {
	let s = x(t), c = s[i], l = s[a], u = e.sectors;
	for (let e of n) if (e.kind === "opposite" && ne(e, {
		kind: "opposite",
		obj1: i,
		obj2: a,
		qualifier: e.qualifier
	})) return null;
	let d = c, f = !1;
	for (let e of r) (e.kind === "opposite" && (e.obj1 === i || e.obj2 === i) && e.qualifier === "none" || e.kind === "oppositeSelf" && e.obj === i && e.qualifier === "none") && (f = !0);
	for (let e of [...n, ...r]) e.kind === "opposite" && e.obj1 === i ? e.qualifier === "every" ? d -= c : e.qualifier === "atLeastOne" && --d : e.kind === "opposite" && e.obj2 === i ? e.qualifier === "every" ? d -= s[e.obj2] : e.qualifier === "atLeastOne" && --d : e.kind === "oppositeSelf" && e.obj === i && (e.qualifier === "every" ? d -= c : e.qualifier === "atLeastOne" && (d -= 2));
	if (d <= 0) return null;
	let p = !f, m = d > 1 || !f;
	if (u % 2 != 0) return null;
	let h = Math.floor(u / 2), g = 0;
	for (let e = 0; e < u; e++) t[e] === i && t[(e + h) % u] === a && g++;
	let _;
	return _ = g === 0 ? ["none"] : g < c ? ["atLeastOne"] : ["atLeastOne", "every"], c === l && (_ = _.filter((e) => e !== "every")), c === 1 && (_ = _.filter((e) => e !== "atLeastOne")), p || (_ = _.filter((e) => e !== "every")), m || (_ = _.filter((e) => e !== "atLeastOne")), _.length === 0 ? null : {
		kind: "opposite",
		obj1: i,
		obj2: a,
		qualifier: P(o, _)
	};
}
function ce(e, t, n, r, i, a, o) {
	let s = x(t), c = s[i], l = s[a], u = e.sectors, d = 2, f = u;
	for (let e of n) {
		if (e.kind !== "within") continue;
		let t = e.obj1 === i && e.obj2 === a || e.obj1 === a && e.obj2 === i;
		e.qualifier === "none" && t ? e.n + 1 > d && (d = e.n + 1) : e.qualifier === "every" && t && e.n - 1 < f && (f = e.n - 1);
	}
	if (c > l) return null;
	let p = Math.floor(u / 3 - 1);
	f = Math.min(f, p);
	let m = t.map((e, t) => e === i ? t : -1).filter((e) => e >= 0), h = t.map((e, t) => e === a ? t : -1).filter((e) => e >= 0);
	if (m.length === 0 || h.length === 0) return null;
	let g = u, _ = 0;
	for (let t of m) {
		let n = Math.min(...h.map((n) => y(e, t, n)));
		n > _ && (_ = n), n < g && (g = n);
	}
	let v = [];
	if (g > d) {
		let e = d + Math.floor(o() * (g - d));
		v.push({
			qualifier: "none",
			n: e
		});
	}
	if (_ <= f) {
		let e = Math.max(2, _), t = p;
		if (e <= t) {
			let n = e + Math.floor(o() * (t + 1 - e));
			v.push({
				qualifier: "every",
				n
			});
		}
	}
	if (v.length === 0) return null;
	let b = P(o, v);
	return {
		kind: "within",
		obj1: i,
		obj2: a,
		n: b.n,
		qualifier: b.qualifier
	};
}
function le(e, t, n, r, i, a) {
	let o = x(t), s = o[i], c = e.sectors;
	for (let e of n) if (e.kind === "adjacentSelf" && e.obj === i || e.kind === "sectors" && e.obj === i) return null;
	let l = 2 * s, u = !1;
	for (let e of r) (e.kind === "adjacent" && (e.obj1 === i || e.obj2 === i) && e.qualifier === "none" || e.kind === "adjacentSelf" && e.obj === i && e.qualifier === "none") && (u = !0);
	for (let e of [...n, ...r]) if (e.kind === "adjacent" && e.obj1 === i) e.qualifier === "every" ? l -= s : e.qualifier === "atLeastOne" && --l;
	else if (e.kind === "adjacent" && e.obj2 === i) e.qualifier === "every" ? l -= Math.floor((o[e.obj2] + 1) / 2) : e.qualifier === "atLeastOne" && --l;
	else if (e.kind === "adjacentSelf" && e.obj === i) e.qualifier === "every" ? l -= s : e.qualifier === "atLeastOne" && (l -= 2);
	else if (e.kind === "band" && e.obj === i && e.band < 2 * s - 1) return null;
	if (l <= 0) return null;
	let d = l > 2 || !u;
	if (s === 1) return null;
	let f = 0;
	for (let e = 0; e < c; e++) t[e] === i && (t[(e - 1 + c) % c] === i || t[(e + 1) % c] === i) && f++;
	let p = f === 0 ? ["none"] : ["atLeastOne"];
	return s <= 2 && (p = p.filter((e) => e !== "atLeastOne")), d || (p = p.filter((e) => e !== "atLeastOne")), p.length === 0 ? null : {
		kind: "adjacentSelf",
		obj: i,
		qualifier: P(a, p)
	};
}
function ue(e, t, n, r, i, a) {
	let o = x(t), s = o[i], c = e.sectors;
	for (let e of n) if (e.kind === "oppositeSelf" && e.obj === i || e.kind === "sectors" && e.obj === i) return null;
	let l = s, u = !1;
	for (let e of r) (e.kind === "opposite" && (e.obj1 === i || e.obj2 === i) && e.qualifier === "none" || e.kind === "oppositeSelf" && e.obj === i && e.qualifier === "none") && (u = !0);
	for (let e of [...n, ...r]) if (e.kind === "opposite" && e.obj1 === i) e.qualifier === "every" ? l -= s : e.qualifier === "atLeastOne" && --l;
	else if (e.kind === "opposite" && e.obj2 === i) e.qualifier === "every" ? l -= o[e.obj2] : e.qualifier === "atLeastOne" && --l;
	else if (e.kind === "oppositeSelf" && e.obj === i) e.qualifier === "every" ? l -= s : e.qualifier === "atLeastOne" && (l -= 2);
	else if (e.kind === "band" && e.obj === i && e.band <= Math.floor(c / 2)) return null;
	if (l <= 0) return null;
	let d = l > 2 || !u;
	if (c % 2 != 0 || s === 1) return null;
	let f = Math.floor(c / 2), p = 0;
	for (let e = 0; e < c; e++) t[e] === i && t[(e + f) % c] === i && p++;
	let m;
	return m = p === 0 ? ["none"] : p < s ? ["atLeastOne"] : ["atLeastOne", "every"], m = m.filter((e) => e !== "every"), s <= 2 && (m = m.filter((e) => e !== "atLeastOne")), d || (m = m.filter((e) => e !== "atLeastOne")), m.length === 0 ? null : {
		kind: "oppositeSelf",
		obj: i,
		qualifier: P(a, m)
	};
}
function de(e, t, n, r, i, a) {
	let o = x(t)[i], s = e.sectors;
	for (let e of n) if (e.kind === "band" && e.obj === i) return null;
	if (o === 1) return null;
	let c = Math.min(2 * o + 1, Math.floor(s / 2)), l = S(e, t, i), u = Math.max(l, o + 1);
	return u > c ? null : {
		kind: "band",
		obj: i,
		band: u + Math.floor(a() * (c + 1 - u)),
		precision: "within"
	};
}
function L(e, t, n, r, i) {
	let a = e.sectors;
	switch (t.kind) {
		case "adjacent": {
			for (let e of i) if (j(k(t), k(e))) return !1;
			let [e, a, o] = ie(n, [t.obj1, t.obj2], [...r, ...i]);
			return t.qualifier === "none" ? e : t.qualifier === "atLeastOne" ? a : o;
		}
		case "opposite": {
			let e = n[t.obj1], a = 2 * e, o = !1;
			for (let e of r) if (e.kind === "opposite" && j([t.obj1, t.obj2], [e.obj1, e.obj2])) return !1;
			for (let e of i) {
				if (M(e) && j([t.obj1, t.obj2], k(e)) || N(e) && t.obj2 === "empty" && e.obj === t.obj1) return !1;
				(e.kind === "opposite" && (e.obj1 === t.obj1 || e.obj2 === t.obj1) && e.qualifier === "none" || e.kind === "oppositeSelf" && e.obj === t.obj1 && e.qualifier === "none") && (o = !0);
			}
			for (let o of [...r, ...i]) o.kind === "opposite" && o.obj1 === t.obj1 ? o.qualifier === "every" ? a -= e : o.qualifier === "atLeastOne" && --a : o.kind === "opposite" && o.obj2 === t.obj1 ? o.qualifier === "every" ? a -= n[o.obj2] : o.qualifier === "atLeastOne" && --a : o.kind === "oppositeSelf" && o.obj === t.obj1 && (o.qualifier === "every" ? a -= e : o.qualifier === "atLeastOne" && (a -= 2));
			if (a <= 0) return !1;
			let s = !o, c = a > 1 || !o;
			return t.qualifier === "every" ? s : t.qualifier !== "atLeastOne" || c;
		}
		case "within": {
			let e = 2, n = a;
			for (let i of r) {
				if (i.kind !== "within") continue;
				let r = i.obj1 === t.obj1 && i.obj2 === t.obj2 || i.obj1 === t.obj2 && i.obj2 === t.obj1;
				i.qualifier === "none" && r ? i.n + 1 > e && (e = i.n + 1) : i.qualifier === "every" && r && i.n - 1 < n && (n = i.n - 1);
			}
			for (let e of i) if (M(e) && j([t.obj1, t.obj2], k(e)) || N(e) && t.obj2 === "empty" && e.obj === t.obj1) return !1;
			return t.qualifier === "every" ? t.n <= n : t.qualifier === "none" && t.n >= e;
		}
		case "adjacentSelf": {
			let e = n[t.obj], a = 2 * e, o = !1;
			for (let e of r) if (e.kind === "adjacentSelf" && e.obj === t.obj || e.kind === "sectors" && e.obj === t.obj) return !1;
			for (let e of i) {
				if (M(e) && e.obj1 === t.obj && e.obj2 === "empty" || N(e) && e.obj === t.obj) return !1;
				(e.kind === "adjacent" && (e.obj1 === t.obj || e.obj2 === t.obj) && e.qualifier === "none" || e.kind === "adjacentSelf" && e.obj === t.obj && e.qualifier === "none") && (o = !0);
			}
			for (let o of [...r, ...i]) if (o.kind === "adjacent" && o.obj1 === t.obj) o.qualifier === "every" ? a -= e : o.qualifier === "atLeastOne" && --a;
			else if (o.kind === "adjacent" && o.obj2 === t.obj) o.qualifier === "every" ? a -= Math.floor((n[o.obj2] + 1) / 2) : o.qualifier === "atLeastOne" && --a;
			else if (o.kind === "adjacentSelf" && o.obj === t.obj) o.qualifier === "every" ? a -= e : o.qualifier === "atLeastOne" && (a -= 2);
			else if (o.kind === "band" && o.obj === t.obj && o.band < 2 * e - 1) return !1;
			if (a <= 0) return !1;
			let s = a > 2 || !o;
			return t.qualifier !== "atLeastOne" || s;
		}
		case "oppositeSelf": {
			let e = n[t.obj], o = e, s = !1;
			if (a % 2 != 0) return !1;
			for (let e of r) if (e.kind === "oppositeSelf" && e.obj === t.obj || e.kind === "sectors" && e.obj === t.obj) return !1;
			for (let e of i) {
				if (M(e) && e.obj1 === t.obj && e.obj2 === "empty" || N(e) && e.obj === t.obj) return !1;
				(e.kind === "opposite" && (e.obj1 === t.obj || e.obj2 === t.obj) && e.qualifier === "none" || e.kind === "oppositeSelf" && e.obj === t.obj && e.qualifier === "none") && (s = !0);
			}
			for (let s of [...r, ...i]) if (s.kind === "opposite" && s.obj1 === t.obj) s.qualifier === "every" ? o -= e : s.qualifier === "atLeastOne" && --o;
			else if (s.kind === "opposite" && s.obj2 === t.obj) s.qualifier === "every" ? o -= n[s.obj2] : s.qualifier === "atLeastOne" && --o;
			else if (s.kind === "oppositeSelf" && s.obj === t.obj) s.qualifier === "every" ? o -= e : s.qualifier === "atLeastOne" && (o -= 2);
			else if (s.kind === "band" && s.obj === t.obj && s.band <= Math.floor(a / 2)) return !1;
			if (o <= 0) return !1;
			let c = o > 2 || !s;
			return t.qualifier !== "atLeastOne" || c;
		}
		case "band":
			for (let e of r) if (e.kind === "band" && e.obj === t.obj) return !1;
			for (let e of i) if (M(e) && e.obj1 === t.obj && e.obj2 === "empty" || N(e) && e.obj === t.obj) return !1;
			return !0;
		case "sectors": return !1;
	}
}
function R(e, t, n, r, i, a, o, s) {
	let c = e.sectors, l = Math.floor(c / 2);
	if (t === "adjacent") {
		for (let e of r) if (e.kind === "adjacent" && ne(e, {
			kind: "adjacent",
			obj1: a,
			obj2: o,
			qualifier: e.qualifier
		})) return null;
		let e = 0, t = /* @__PURE__ */ new Set(), s = [o];
		i.eliminationObject === o && s.push(a);
		for (let r = 0; r < c; r++) (s.includes(n[(r - 1 + c) % c]) || s.includes(n[(r + 1) % c])) && (n[r] === a ? e++ : n[r] === i.eliminationObject && i.needEliminated.has(r) && t.add(r));
		if (e === 0 && t.size > 0) {
			let e = new Set([...t].filter((e) => !i.alreadyEliminated.has(e)));
			if (e.size >= i.minimum) return {
				eliminated: e,
				rule: {
					kind: "adjacent",
					obj1: a,
					obj2: o,
					qualifier: "none"
				}
			};
		}
		return null;
	}
	if (t === "opposite") {
		for (let e of r) if (e.kind === "opposite" && ne(e, {
			kind: "opposite",
			obj1: a,
			obj2: o,
			qualifier: e.qualifier
		})) return null;
		if (c % 2 != 0) return null;
		let e = 0, t = /* @__PURE__ */ new Set(), s = [o];
		i.eliminationObject === o && s.push(a);
		for (let r = 0; r < c; r++) s.includes(n[(r + l) % c]) && (n[r] === a ? e++ : n[r] === o && i.needEliminated.has(r) && t.add(r));
		if (e === 0 && t.size > 0) {
			let e = new Set([...t].filter((e) => !i.alreadyEliminated.has(e)));
			if (e.size >= i.minimum) return {
				eliminated: e,
				rule: {
					kind: "opposite",
					obj1: a,
					obj2: o,
					qualifier: "none"
				}
			};
		}
		return null;
	}
	let u = 2, d = c;
	for (let e of r) {
		if (e.kind !== "within") continue;
		let t = e.obj1 === a && e.obj2 === o || e.obj1 === o && e.obj2 === a;
		e.qualifier === "none" && t ? e.n + 1 > u && (u = e.n + 1) : e.qualifier === "every" && e.obj1 === a && e.obj2 === o && e.n - 1 < d && (d = e.n - 1);
	}
	let f = Math.floor(c / 3 - 1);
	d = Math.min(d, f);
	let p = n.map((e, t) => e === a ? t : -1).filter((e) => e >= 0), m = [...i.needEliminated], h = n.map((e, t) => e === o ? t : -1).filter((e) => e >= 0);
	if (i.eliminationObject === o && h.push(...p), h.length === 0 || p.length === 0) return null;
	let g = (t) => Math.min(...h.filter((e) => e !== t).map((n) => y(e, t, n))), _ = 0, v = c;
	for (let e of p) {
		let t = g(e);
		t > _ && (_ = t), t < v && (v = t);
	}
	let b = [];
	for (let e of m) {
		let t = g(e);
		if (Number.isFinite(t)) {
			for (; b.length <= t;) b.push([]);
			b[t].push(e);
		}
	}
	let x = [];
	for (let e = 0; e < b.length; e++) if (!(e < u || e > d)) {
		if (e >= v) {
			let t = /* @__PURE__ */ new Set();
			for (let n = e + 1; n < b.length; n++) for (let e of b[n]) t.add(e);
			for (let e of i.alreadyEliminated) t.delete(e);
			t.size > 0 && x.push({
				n: e,
				eliminated: t,
				qualifier: "every"
			});
		}
		if (e < _) {
			let t = /* @__PURE__ */ new Set();
			for (let n = 0; n <= e && n < b.length; n++) for (let e of b[n]) t.add(e);
			for (let e of i.alreadyEliminated) t.delete(e);
			t.size > 0 && x.push({
				n: e,
				eliminated: t,
				qualifier: "none"
			});
		}
	}
	if (x.length === 0) return null;
	let S = Math.max(...x.map((e) => e.eliminated.size)), C = x;
	if (S >= i.goal && (C = C.filter((e) => e.eliminated.size >= i.goal)), C = C.filter((e) => e.eliminated.size >= i.minimum), C.length === 0) return null;
	let w = P(s, C);
	return {
		eliminated: w.eliminated,
		rule: {
			kind: "within",
			obj1: a,
			obj2: o,
			n: w.n,
			qualifier: w.qualifier
		}
	};
}
//#endregion
//#region src/games/planetx/research.ts
function fe(e) {
	return [
		{
			kind: "sectors",
			obj: "comet",
			positions: [...e.cometSectors]
		},
		{
			kind: "adjacentSelf",
			obj: "asteroid",
			qualifier: "every"
		},
		{
			kind: "adjacent",
			obj1: "planetX",
			obj2: "dwarfPlanet",
			qualifier: "none"
		},
		{
			kind: "adjacent",
			obj1: "gasCloud",
			obj2: "empty",
			qualifier: "every"
		}
	];
}
function pe(e, t) {
	for (let n = t.length - 1; n > 0; n--) {
		let r = Math.floor(e() * (n + 1));
		[t[n], t[r]] = [t[r], t[n]];
	}
	return t;
}
function me(e, t) {
	let n = t.reduce((e, t) => e + t, 0);
	if (n <= 0) return Math.floor(e() * t.length);
	let r = e() * n;
	for (let e = 0; e < t.length; e++) if (r -= t[e], r < 0) return e;
	return t.length - 1;
}
var he = [
	"comet",
	"asteroid",
	"dwarfPlanet",
	"gasCloud"
];
function ge(e, t, n, r) {
	let i = x(t), a = Math.floor(r() * 3), o = [];
	for (let i of he) {
		let a = de(e, t, n, [], i, r);
		a && o.push(a);
		let s = ue(e, t, n, [], i, r);
		s && o.push(s);
		let c = le(e, t, n, [], i, r);
		c && o.push(c);
		let l = I(e, t, n, [], i, "empty", r);
		l && o.push(l);
	}
	let s = [];
	for (let i = 0; i < he.length; i++) for (let a = i + 1; a < he.length; a++) {
		let o = he[i], c = he[a];
		for (let [i, a] of [[o, c], [c, o]]) {
			let o = se(e, t, n, [], i, a, r);
			o && s.push(o);
			let c = I(e, t, n, [], i, a, r);
			c && s.push(c);
			let l = ce(e, t, n, [], i, a, r);
			l && s.push(l);
		}
	}
	let c = [], l = o.map((n) => oe(e, n, t));
	for (; c.length < a && o.length > 0;) {
		let t = me(r, l), [a] = o.splice(t, 1);
		l.splice(t, 1), L(e, a, i, n, c) && c.push(a);
	}
	let u = s.map((n) => oe(e, n, t));
	for (; c.length < e.numResearch && s.length > 0;) {
		let t = me(r, u), [a] = s.splice(t, 1);
		u.splice(t, 1), L(e, a, i, n, c) && c.push(a);
	}
	return pe(r, c), c.length === e.numResearch ? c : null;
}
function _e(e, t, n, r) {
	let i = e.conferenceCells.length, a = /* @__PURE__ */ new Set();
	t.forEach((n, r) => {
		n === "empty" && T(e, t, r) && a.add(r);
	});
	let o = [
		"empty",
		"comet",
		"asteroid",
		"dwarfPlanet",
		"gasCloud"
	], s = [];
	for (let e of o) for (let t of [
		"opposite",
		"adjacent",
		"within"
	]) s.push({
		obj: e,
		kind: t
	});
	pe(r, s);
	let c = [], l = /* @__PURE__ */ new Set(), u = new Set(a), d = Math.ceil(u.size / i), f = d;
	for (let o = 0; o < i; o++) for (let p of s) {
		let m = R(e, p.kind, t, n, {
			eliminationObject: "empty",
			minimum: f,
			goal: d,
			needEliminated: new Set(a),
			alreadyEliminated: l
		}, "planetX", p.obj, r);
		if (m && m.eliminated.size >= f) {
			c.push(m.rule);
			for (let e = s.length - 1; e >= 0; e--) s[e].obj === p.obj && s.splice(e, 1);
			for (let e of m.eliminated) l.add(e), u.delete(e);
			let e = i - o - 1;
			e > 0 && (f = Math.ceil(u.size / e));
			break;
		}
	}
	if (u.size === 0) for (let a = c.length; a < i; a++) for (let i of s) {
		let a = i.kind === "adjacent" ? I(e, t, n, c, "planetX", i.obj, r) : i.kind === "opposite" ? se(e, t, n, c, "planetX", i.obj, r) : ce(e, t, n, c, "planetX", i.obj, r);
		if (a) {
			for (let e = s.length - 1; e >= 0; e--) s[e].obj === i.obj && s.splice(e, 1);
			c.push(a);
			break;
		}
	}
	return pe(r, c), c.length === i ? c : null;
}
function ve(e, t, n) {
	let r = e.sectors, i = [];
	for (let n = 0; n < r; n++) i.push(g.filter((e) => e !== t[n]).filter((t) => t !== "comet" || e.cometSectors.includes(n)));
	let a = /* @__PURE__ */ new Map();
	for (let e of g) a.set(e, -1);
	for (let e = 0; e < r; e++) for (let t of i[e]) a.set(t, a.get(t) + 1);
	let o = [];
	for (let e = 0; e < 4; e++) {
		let e = new Map(a), t = [], s = pe(n, Array.from({ length: r }, (e, t) => t));
		for (let a of s) {
			let o = i[a].filter((t) => e.get(t) > 0);
			if (o.length === 0) continue;
			if (t.length === r) break;
			let s = o[Math.floor(n() * o.length)];
			t.push({
				sector: a,
				obj: s
			}), e.set(s, e.get(s) - 1);
		}
		o.push(t);
	}
	return o;
}
function ye(e, t, n = 100) {
	let r = fe(e);
	for (let i = 0; i < n; i++) {
		let n = w(e, t);
		if (!n) continue;
		let i = ge(e, n, r, t);
		if (!i) continue;
		let a = _e(e, n, r, t);
		if (a) return {
			board: n,
			research: i,
			conference: a,
			startingClues: ve(e, n, t)
		};
	}
	return null;
}
function be(e) {
	return e.map(A);
}
//#endregion
//#region src/games/planetx/meta.ts
var xe = {
	id: "planetx",
	tier: "beta",
	mechanics: ["deduction"],
	interactionTags: [],
	nameKey: "games.planetx.name",
	descKey: "games.planetx.desc",
	rulesKey: "games.planetx.rules",
	icon: "🪐",
	iconImg: "games/planetx.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/planetx/en.pdf" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2, 3],
	accent: "#4f46e5",
	releasedAt: "2026-09-21",
	search: {
		py: "x xing xing zhi mi",
		init: "xxxzm"
	},
	hotseat: "cover"
}, z = t.enum([
	"asteroid",
	"comet",
	"gasCloud",
	"dwarfPlanet",
	"empty",
	"planetX"
]), B = t.enum([
	"asteroid",
	"comet",
	"gasCloud",
	"dwarfPlanet"
]), Se = t.enum([
	"asteroid",
	"comet",
	"gasCloud",
	"dwarfPlanet",
	"empty"
]), V = t.int().min(0).max(11), Ce = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("survey"),
		obj: Se,
		from: V,
		to: V
	}),
	t.object({
		type: t.literal("target"),
		sector: V
	}),
	t.object({
		type: t.literal("research"),
		topic: t.int().min(0).max(5)
	}),
	t.object({
		type: t.literal("locate"),
		sector: V,
		objPrev: B.or(t.literal("empty")),
		objNext: B.or(t.literal("empty"))
	}),
	t.object({
		type: t.literal("submitTheories"),
		entries: t.array(t.object({
			sector: V,
			obj: B
		})).max(2)
	}),
	t.object({ type: t.literal("conferenceAck") })
]), H = t.string(), we = t.enum([
	"none",
	"atLeastOne",
	"every"
]), Te = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("adjacent"),
		obj1: z,
		obj2: z,
		qualifier: we
	}),
	t.object({
		kind: t.literal("opposite"),
		obj1: z,
		obj2: z,
		qualifier: we
	}),
	t.object({
		kind: t.literal("within"),
		obj1: z,
		obj2: z,
		n: t.int().min(1),
		qualifier: we
	}),
	t.object({
		kind: t.literal("adjacentSelf"),
		obj: z,
		qualifier: we
	}),
	t.object({
		kind: t.literal("oppositeSelf"),
		obj: z,
		qualifier: we
	}),
	t.object({
		kind: t.literal("band"),
		obj: z,
		band: t.int().min(1),
		precision: t.enum(["within", "exactly"])
	}),
	t.object({
		kind: t.literal("sectors"),
		obj: z,
		positions: t.array(t.int().min(0))
	})
]), Ee = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("start"),
		sector: V,
		obj: B
	}),
	t.object({
		kind: t.literal("survey"),
		obj: Se,
		from: V,
		to: V,
		count: t.int().min(0)
	}),
	t.object({
		kind: t.literal("target"),
		sector: V,
		obj: z
	}),
	t.object({
		kind: t.literal("research"),
		topic: t.int().min(0),
		rule: Te
	})
]), De = t.discriminatedUnion("kind", [
	t.object({
		kind: t.literal("survey"),
		rid: t.string(),
		obj: Se,
		from: V,
		to: V
	}),
	t.object({
		kind: t.literal("target"),
		rid: t.string(),
		sector: V
	}),
	t.object({
		kind: t.literal("research"),
		rid: t.string(),
		topic: t.int().min(0)
	}),
	t.object({
		kind: t.literal("locate"),
		rid: t.string(),
		success: t.boolean()
	}),
	t.object({
		kind: t.literal("theories"),
		rid: t.string(),
		sectors: t.array(V)
	}),
	t.object({ kind: t.literal("conference") })
]), Oe = t.object({ difficulty: t.enum([
	"beginner",
	"experienced",
	"genius"
]).default("beginner") }).default({ difficulty: "beginner" }), ke = t.object({
	id: t.int().min(0),
	rid: H,
	sector: V,
	progress: t.int().min(0).max(3),
	frozen: t.boolean(),
	obj: B.optional(),
	accurate: t.boolean().optional()
}), Ae = t.object({
	phase: t.enum([
		"turn",
		"theory",
		"conference",
		"lastChance",
		"done"
	]),
	currentSector: V,
	players: t.array(t.object({
		rid: H,
		sector: V,
		arrival: t.int().min(0),
		targetsLeft: t.int().min(0),
		lastAction: t.enum([
			"survey",
			"target",
			"research",
			"locate"
		]).nullable(),
		researched: t.array(t.int().min(0))
	})),
	turn: H.nullable(),
	pending: t.array(H),
	theories: t.array(ke),
	confirmed: t.record(t.string(), B),
	researchTopics: t.array(t.array(z)),
	conference: Te.nullable(),
	locator: H.nullable(),
	lastChance: t.object({
		turn: H,
		behind: t.int().min(0)
	}).nullable(),
	board: t.array(z).nullable(),
	history: t.array(De)
}), je = t.object({
	clues: t.array(Ee),
	myTheories: t.array(t.object({
		id: t.int().min(0),
		sector: V,
		obj: B,
		progress: t.int().min(0).max(3),
		frozen: t.boolean()
	})),
	tokensLeft: t.record(t.string(), t.int().min(0))
}), U = _, W = (e, t) => ({
	code: e,
	params: t
});
function Me(e, t) {
	return e.players.find((e) => e.rid === t);
}
function G(e, t) {
	return e.board[t.sector] === t.obj;
}
function Ne(e, t, n) {
	let r = e.theories.filter((e) => e.rid === t && e.obj === n).length;
	return U.theoryTokens[n] - r;
}
function Pe(e, t, n) {
	t.sector = (t.sector + n) % U.sectors, t.arrival = e.arrivalCounter++;
}
function Fe(e) {
	let t = [...e.players].sort((e, t) => e.sector - t.sector || e.arrival - t.arrival), n = -1, r = 0;
	for (let e = 0; e < t.length; e++) {
		let i = (t[(e + 1) % t.length].sector - t[e].sector + U.sectors) % U.sectors;
		i > n && (n = i, r = (e + 1) % t.length);
	}
	return t[r];
}
function Ie(e) {
	let t = U.sectors, n = Fe(e), r = n.sector;
	r < e.currentSector && (r += t);
	let i = "player", a = ((-e.currentSector - 1) % U.theoryInterval + U.theoryInterval) % U.theoryInterval, o = e.currentSector + a;
	if ((e.lastActionKind === "theory" || e.lastActionKind === "conference" && e.currentSector === o) && (o += U.theoryInterval), o < r && (r = o, i = "theory"), e.firstRotation) {
		let t = e.lastActionKind === "conference" ? U.conferenceCells.findIndex((t) => t > e.currentSector) : U.conferenceCells.findIndex((t) => t >= e.currentSector);
		if (t >= 0) {
			let e = U.conferenceCells[t];
			e < r && (r = e, i = "conference");
		}
	}
	r %= t;
	let s = e.firstRotation && r >= e.currentSector;
	return {
		kind: i,
		sector: r,
		stillFirst: s,
		rid: n.rid
	};
}
function Le(e) {
	let t = Ie(e);
	e.currentSector = t.sector, e.firstRotation = t.stillFirst, t.kind === "player" ? (e.phase = "turn", e.turn = t.rid, e.pending = [], e.lastActionKind = "player") : t.kind === "theory" ? (e.phase = "theory", e.turn = null, e.pending = e.players.map((e) => e.rid), e.lastActionKind = "theory") : (e.phase = "conference", e.turn = null, e.pending = e.players.map((e) => e.rid), e.conferenceRevealed = !0, e.lastActionKind = "conference", e.history.push({ kind: "conference" }));
}
function Re(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e.theories) !n.frozen && n.progress === 2 && G(e, n) && t.add(n.sector);
	let n = [...e.theories.filter((n) => !n.frozen && !G(e, n) && (t.has(n.sector) || n.progress === 2))].sort((t, n) => {
		let r = Me(e, t.rid), i = Me(e, n.rid), a = b(U, e.currentSector, r.sector), o = b(U, e.currentSector, i.sector);
		return a === o ? r.arrival - i.arrival : a - o;
	});
	for (let t of n) Pe(e, Me(e, t.rid), 1);
	for (let t of e.theories) t.frozen || (t.progress = Math.min(3, t.progress + 1));
	for (let n of e.theories) !n.frozen && (n.progress === 3 || t.has(n.sector)) && (n.frozen = !0, n.progress === 3 && G(e, n) && (e.confirmed[String(n.sector)] = n.obj));
}
function ze(e, t) {
	return b(U, e.currentSector, t) < U.skySize;
}
function Be(e, t, n, r) {
	if (n.length > r) return W("games.planetx.errTooManyTheories", { n: r });
	let i = /* @__PURE__ */ new Set();
	for (let r of n) {
		if (i.has(r.sector)) return W("games.planetx.errDuplicateSector");
		if (i.add(r.sector), e.confirmed[String(r.sector)]) return W("games.planetx.errSectorConfirmed");
		if (e.theories.some((e) => e.rid === t && e.sector === r.sector && e.obj === r.obj)) return W("games.planetx.errDuplicateTheory");
		let a = n.filter((e) => e.obj === r.obj).length;
		if (Ne(e, t, r.obj) < a) return W("games.planetx.errNoTokens");
	}
	return null;
}
function Ve(e, t, n) {
	for (let r of n) e.theories.push({
		id: e.theoryIdCounter++,
		rid: t,
		sector: r.sector,
		obj: r.obj,
		progress: 0,
		frozen: !1
	});
	n.length > 0 && e.history.push({
		kind: "theories",
		rid: t,
		sectors: n.map((e) => e.sector)
	});
}
function He(e, t) {
	let n = Me(e, e.locator);
	return b(U, Me(e, t).sector, n.sector);
}
function Ue(e) {
	if (e.lastChanceQueue.shift(), e.lastChanceQueue.length === 0) {
		e.phase = "done", e.turn = null;
		return;
	}
	e.turn = e.lastChanceQueue[0];
}
function We(e, t, n, r) {
	let i = U.sectors;
	return e.board[t] === "planetX" && e.board[(t - 1 + i) % i] === n && e.board[(t + 1) % i] === r;
}
function Ge(t, n, r) {
	let i = 0, a = () => e(r, i++), o = ye(U, a);
	for (; !o;) o = ye(U, a);
	let s = U.startingClues[t.difficulty], c = {};
	return n.forEach((e, t) => {
		c[e] = o.startingClues[t].slice(0, s).map((e) => ({
			kind: "start",
			sector: e.sector,
			obj: e.obj
		}));
	}), { state: {
		board: o.board,
		research: o.research,
		conferenceCard: o.conference[0],
		conferenceRevealed: !1,
		players: n.map((e, t) => ({
			rid: e,
			sector: 0,
			arrival: t,
			targetsLeft: U.numTargets,
			lastAction: null,
			researched: []
		})),
		clues: c,
		theories: [],
		confirmed: {},
		currentSector: 0,
		firstRotation: !0,
		lastActionKind: "start",
		phase: "turn",
		turn: n[0],
		pending: [],
		arrivalCounter: n.length,
		theoryIdCounter: 0,
		locator: null,
		locateSuccesses: [],
		lastChanceQueue: [],
		history: []
	} };
}
function Ke(e, t, n) {
	let r = structuredClone(e), i = r.players.find((e) => e.rid === n.by);
	if (!i) return W("games.planetx.errNotYourTurn");
	switch (t.type) {
		case "survey": {
			if (r.phase !== "turn" || r.turn !== n.by) return W("games.planetx.errNotYourTurn");
			let e = t.from, a = t.to;
			if (!ze(r, e) || !ze(r, a)) return W("games.planetx.errBadSurveyRange");
			let o = b(U, e, a) + 1;
			if (o > U.skySize) return W("games.planetx.errBadSurveyRange");
			if (t.obj === "comet" && (!U.cometSectors.includes(e) || !U.cometSectors.includes(a))) return W("games.planetx.errCometRange");
			let s = 0;
			for (let n = e; (r.board[n] === t.obj || t.obj === "empty" && r.board[n] === "planetX") && s++, n !== a; n = (n + 1) % U.sectors);
			return r.clues[n.by].push({
				kind: "survey",
				obj: t.obj,
				from: e,
				to: a,
				count: s
			}), r.history.push({
				kind: "survey",
				rid: n.by,
				obj: t.obj,
				from: e,
				to: a
			}), Pe(r, i, v(U, o)), i.lastAction = "survey", Le(r), { state: r };
		}
		case "target": {
			if (r.phase !== "turn" || r.turn !== n.by) return W("games.planetx.errNotYourTurn");
			if (i.targetsLeft <= 0) return W("games.planetx.errNoTargets");
			if (!ze(r, t.sector)) return W("games.planetx.errBadTarget");
			let e = r.board[t.sector] === "planetX" ? "empty" : r.board[t.sector];
			return r.clues[n.by].push({
				kind: "target",
				sector: t.sector,
				obj: e
			}), r.history.push({
				kind: "target",
				rid: n.by,
				sector: t.sector
			}), i.targetsLeft--, Pe(r, i, U.targetCost), i.lastAction = "target", Le(r), { state: r };
		}
		case "research": return r.phase !== "turn" || r.turn !== n.by ? W("games.planetx.errNotYourTurn") : t.topic >= r.research.length ? W("games.planetx.errBadTopic") : i.researched.includes(t.topic) ? W("games.planetx.errAlreadyResearched") : i.lastAction === "research" ? W("games.planetx.errResearchConsecutive") : (i.researched.push(t.topic), r.clues[n.by].push({
			kind: "research",
			topic: t.topic,
			rule: r.research[t.topic]
		}), r.history.push({
			kind: "research",
			rid: n.by,
			topic: t.topic
		}), Pe(r, i, U.researchCost), i.lastAction = "research", Le(r), { state: r });
		case "locate":
			if (r.phase === "turn") {
				if (r.turn !== n.by) return W("games.planetx.errNotYourTurn");
				let e = We(r, t.sector, t.objPrev, t.objNext);
				if (Pe(r, i, U.locateCost), i.lastAction = "locate", r.history.push({
					kind: "locate",
					rid: n.by,
					success: e
				}), !e) return Le(r), { state: r };
				r.locator = n.by, r.locateSuccesses.push({
					rid: n.by,
					behind: null
				});
				let a = r.players.filter((e) => e.rid !== n.by).map((e) => ({
					rid: e.rid,
					behind: He(r, e.rid),
					arrival: e.arrival
				})).filter((e) => e.behind >= 1 && e.behind <= 5).sort((e, t) => t.behind - e.behind || e.arrival - t.arrival).map((e) => e.rid);
				return a.length === 0 ? (r.phase = "done", r.turn = null, { state: r }) : (r.phase = "lastChance", r.lastChanceQueue = a, r.turn = a[0], { state: r });
			}
			return r.phase === "lastChance" && r.turn === n.by ? (We(r, t.sector, t.objPrev, t.objNext) ? (r.locateSuccesses.push({
				rid: n.by,
				behind: He(r, n.by)
			}), r.history.push({
				kind: "locate",
				rid: n.by,
				success: !0
			})) : r.history.push({
				kind: "locate",
				rid: n.by,
				success: !1
			}), Ue(r), { state: r }) : W("games.planetx.errNotYourTurn");
		case "submitTheories":
			if (r.phase === "theory") return r.pending.includes(n.by) ? Be(r, n.by, t.entries, U.theoriesPerTurn) || (Ve(r, n.by, t.entries), r.pending = r.pending.filter((e) => e !== n.by), r.pending.length === 0 && (Re(r), Le(r)), { state: r }) : W("games.planetx.errNotYourTurn");
			if (r.phase === "lastChance") {
				if (r.turn !== n.by) return W("games.planetx.errNotYourTurn");
				let e = He(r, n.by), i = e >= 1 && e <= 3 ? 1 : e <= 5 ? 2 : 0;
				return i === 0 ? W("games.planetx.errNoLastChance") : Be(r, n.by, t.entries, i) || (Ve(r, n.by, t.entries), Ue(r), { state: r });
			}
			return W("games.planetx.errNotYourTurn");
		case "conferenceAck": return r.phase !== "conference" || !r.pending.includes(n.by) ? W("games.planetx.errNotYourTurn") : (r.pending = r.pending.filter((e) => e !== n.by), r.pending.length === 0 && Le(r), { state: r });
	}
}
function qe(e, t) {
	let n = e.phase === "done", r = {
		phase: e.phase,
		currentSector: e.currentSector,
		players: e.players.map((e) => ({
			rid: e.rid,
			sector: e.sector,
			arrival: e.arrival,
			targetsLeft: e.targetsLeft,
			lastAction: e.lastAction,
			researched: [...e.researched]
		})),
		turn: e.turn,
		pending: [...e.pending],
		theories: e.theories.map((t) => t.frozen || n ? {
			id: t.id,
			rid: t.rid,
			sector: t.sector,
			progress: t.progress,
			frozen: t.frozen,
			obj: t.obj,
			accurate: G(e, t)
		} : {
			id: t.id,
			rid: t.rid,
			sector: t.sector,
			progress: t.progress,
			frozen: t.frozen
		}),
		confirmed: { ...e.confirmed },
		researchTopics: be(e.research),
		conference: e.conferenceRevealed || n ? e.conferenceCard : null,
		locator: e.locator,
		lastChance: e.phase === "lastChance" && e.turn ? {
			turn: e.turn,
			behind: He(e, e.turn)
		} : null,
		board: n ? [...e.board] : null,
		history: [...e.history]
	}, i = {};
	for (let n of [
		"asteroid",
		"comet",
		"gasCloud",
		"dwarfPlanet"
	]) i[n] = Ne(e, t, n);
	return {
		public: r,
		private: {
			clues: [...e.clues[t] ?? []],
			myTheories: e.theories.filter((e) => e.rid === t).map((e) => ({
				id: e.id,
				sector: e.sector,
				obj: e.obj,
				progress: e.progress,
				frozen: e.frozen
			})),
			tokensLeft: i
		}
	};
}
function Je(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = /* @__PURE__ */ new Map();
	for (let n of e.players) t.set(n.rid, {
		theoryPts: 0,
		leader: 0,
		locatePts: 0,
		total: 0
	});
	for (let n of e.theories) G(e, n) && (t.get(n.rid).theoryPts += U.scoreValues[n.obj]);
	let n = /* @__PURE__ */ new Map();
	for (let t of e.theories) {
		if (!G(e, t)) continue;
		let r = n.get(t.sector) ?? [];
		r.push(t), n.set(t.sector, r);
	}
	for (let e of n.values()) {
		let n = Math.max(...e.map((e) => e.progress));
		for (let r of e) r.progress === n && (t.get(r.rid).leader += 1);
	}
	e.locateSuccesses.forEach((e, n) => {
		t.get(e.rid).locatePts += n === 0 ? 10 : 2 * (e.behind ?? 0);
	});
	for (let e of t.values()) e.total = e.theoryPts + e.leader + e.locatePts;
	let r = new Map(e.players.map((e, t) => [e.rid, t])), i = [...e.players.map((e) => e.rid)].sort((e, n) => {
		let i = t.get(e), a = t.get(n);
		return i.total === a.total ? i.locatePts === a.locatePts ? i.leader === a.leader ? r.get(e) - r.get(n) : a.leader - i.leader : a.locatePts - i.locatePts : a.total - i.total;
	}), a = t.get(i[0]), o = i.filter((e) => {
		let n = t.get(e);
		return n.total === a.total && n.locatePts === a.locatePts && n.leader === a.leader;
	}), s = {};
	for (let [e, n] of t) s[e] = n.total;
	return {
		phase: "done",
		winner: o,
		ranking: i,
		scores: s
	};
}
var Ye = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: xe,
	schemas: {
		action: Ce,
		publicView: Ae,
		privateView: je,
		config: Oe
	},
	setup: Ge,
	reduce: Ke,
	viewFor: qe,
	status: Je
}, K = {
	asteroid: "games.planetx.objAsteroid",
	comet: "games.planetx.objComet",
	gasCloud: "games.planetx.objGasCloud",
	dwarfPlanet: "games.planetx.objDwarfPlanet",
	empty: "games.planetx.objEmpty",
	planetX: "games.planetx.objPlanetX"
}, Xe = {
	asteroid: "games.planetx.artAsteroid",
	comet: "games.planetx.artComet",
	gasCloud: "games.planetx.artGasCloud",
	dwarfPlanet: "games.planetx.artDwarfPlanet",
	empty: "games.planetx.artEmpty",
	planetX: "games.planetx.artPlanetX"
}, Ze = {
	asteroid: "games.planetx.plAsteroid",
	comet: "games.planetx.plComet",
	gasCloud: "games.planetx.plGasCloud",
	dwarfPlanet: "games.planetx.plDwarfPlanet",
	empty: "games.planetx.plEmpty",
	planetX: "games.planetx.plPlanetX"
}, Qe = {
	none: "games.planetx.ruleAdjacentNone",
	atLeastOne: "games.planetx.ruleAdjacentAtLeastOne",
	every: "games.planetx.ruleAdjacentEvery"
}, $e = {
	none: "games.planetx.ruleOppositeNone",
	atLeastOne: "games.planetx.ruleOppositeAtLeastOne",
	every: "games.planetx.ruleOppositeEvery"
}, et = {
	none: "games.planetx.ruleWithinNone",
	atLeastOne: "games.planetx.ruleWithinAtLeastOne",
	every: "games.planetx.ruleWithinEvery"
}, tt = {
	none: "games.planetx.ruleAdjacentSelfNone",
	atLeastOne: "games.planetx.ruleAdjacentSelfAtLeastOne",
	every: "games.planetx.ruleAdjacentSelfEvery"
}, nt = {
	none: "games.planetx.ruleOppositeSelfNone",
	atLeastOne: "games.planetx.ruleOppositeSelfAtLeastOne",
	every: "games.planetx.ruleOppositeSelfEvery"
};
function rt(e, t) {
	switch (t.kind) {
		case "adjacent": return e(Qe[t.qualifier], {
			obj1: e(K[t.obj1]),
			obj2: e(K[t.obj2]),
			art2: e(Xe[t.obj2])
		});
		case "opposite": return e($e[t.qualifier], {
			obj1: e(K[t.obj1]),
			obj2: e(K[t.obj2]),
			art2: e(Xe[t.obj2])
		});
		case "within": return e(et[t.qualifier], {
			obj1: e(K[t.obj1]),
			obj2: e(K[t.obj2]),
			art2: e(Xe[t.obj2]),
			n: t.n
		});
		case "adjacentSelf": return e(tt[t.qualifier], { obj: e(K[t.obj]) });
		case "oppositeSelf": return e(nt[t.qualifier], { obj: e(K[t.obj]) });
		case "band": return e(t.precision === "exactly" ? "games.planetx.ruleBandExactly" : "games.planetx.ruleBandWithin", {
			pl: e(Ze[t.obj]),
			n: t.band
		});
		case "sectors": return e("games.planetx.ruleSectors", {
			pl: e(Ze[t.obj]),
			list: t.positions.map((e) => e + 1).join("·")
		});
	}
}
//#endregion
//#region src/games/planetx/board-view.tsx
var it = _.sectors, q = 187.5, J = 225, Y = (e) => String(e + 1).padStart(2, "0");
function X(e, t) {
	let n = t * Math.PI / 180;
	return {
		x: q + e * Math.cos(n),
		y: J + e * Math.sin(n)
	};
}
function at(e, t, n, r) {
	let i = X(t, n), a = X(t, r), o = X(e, r), s = X(e, n);
	return `M ${i.x} ${i.y} A ${t} ${t} 0 0 1 ${a.x} ${a.y} L ${o.x} ${o.y} A ${e} ${e} 0 0 0 ${s.x} ${s.y} Z`;
}
function ot({ obj: e, x: t = 0, y: n = 0 }) {
	let r = {
		asteroid: /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d("circle", {
				cx: -6,
				cy: 3,
				r: 4
			}),
			/* @__PURE__ */ d("circle", {
				cx: 2,
				cy: -3,
				r: 5
			}),
			/* @__PURE__ */ d("circle", {
				cx: 7,
				cy: 5,
				r: 3
			})
		] }),
		comet: /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("path", {
			d: "M-11 7 Q-5 0 1 -3 M-9 11 Q-3 2 3 -1",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: 2
		}), /* @__PURE__ */ d("circle", {
			cx: 6,
			cy: -5,
			r: 5
		})] }),
		gasCloud: /* @__PURE__ */ d("path", { d: "M-10 6 Q-14 0 -7 -3 Q-6 -10 1 -7 Q9 -9 10 -2 Q16 2 8 7 Z" }),
		dwarfPlanet: /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("circle", { r: 8 }), /* @__PURE__ */ d("ellipse", {
			rx: 13,
			ry: 4,
			transform: "rotate(-24)",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: 2
		})] }),
		empty: /* @__PURE__ */ d("circle", {
			r: 9,
			fill: "none",
			stroke: "currentColor",
			strokeWidth: 1.5,
			strokeDasharray: "2 2"
		}),
		planetX: /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("circle", {
			r: 10,
			fill: "none",
			stroke: "currentColor",
			strokeWidth: 2
		}), /* @__PURE__ */ d("path", {
			d: "M-5 -5 L5 5 M5 -5 L-5 5",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: 2.5
		})] })
	};
	return /* @__PURE__ */ d("g", {
		transform: `translate(${t} ${n})`,
		className: "planetx-object-glyph",
		"aria-hidden": !0,
		children: r[e]
	});
}
function st({ pub: e, members: t, myRid: r, marks: i, selected: a, selectable: o, neighborSector: l, onSectorTap: p }) {
	let m = s(), h = n().replace(/:/g, ""), g = (e) => t.find((t) => t.rid === e)?.name ?? e, v = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? c[n.colorIndex % c.length].hex : "#91a8b1";
	}, y = e.phase === "done", x = /* @__PURE__ */ new Map();
	for (let t of e.players) {
		let e = x.get(t.sector) ?? [];
		e.push(t.rid), x.set(t.sector, e);
	}
	for (let t of x.values()) t.sort((t, n) => (e.players.find((e) => e.rid === t)?.arrival ?? 0) - (e.players.find((e) => e.rid === n)?.arrival ?? 0));
	let S = (e, t) => {
		(e.key === "Enter" || e.key === " ") && (e.preventDefault(), p(t));
	};
	return /* @__PURE__ */ d("div", {
		className: "planetx-board-frame",
		children: /* @__PURE__ */ f("svg", {
			className: "planetx-board",
			viewBox: "0 0 375 442",
			role: "group",
			"aria-label": m("games.planetx.boardTitle"),
			children: [
				/* @__PURE__ */ f("defs", { children: [/* @__PURE__ */ f("pattern", {
					id: `pxGrid${h}`,
					width: "20",
					height: "20",
					patternUnits: "userSpaceOnUse",
					children: [/* @__PURE__ */ d("path", {
						d: "M20 0 H0 V20",
						fill: "none",
						stroke: "#174052",
						strokeWidth: ".55",
						opacity: ".5"
					}), /* @__PURE__ */ d("circle", {
						r: ".8",
						fill: "#326474",
						opacity: ".5"
					})]
				}), /* @__PURE__ */ f("linearGradient", {
					id: `pxEarth${h}`,
					x1: "0",
					y1: "0",
					x2: "1",
					y2: "1",
					children: [/* @__PURE__ */ d("stop", { stopColor: "#153c4e" }), /* @__PURE__ */ d("stop", {
						offset: "1",
						stopColor: "#071c2b"
					})]
				})] }),
				/* @__PURE__ */ d("rect", {
					width: "375",
					height: "442",
					rx: "7",
					fill: "#091d2a"
				}),
				/* @__PURE__ */ d("rect", {
					width: "375",
					height: "442",
					rx: "7",
					fill: `url(#pxGrid${h})`
				}),
				/* @__PURE__ */ d("path", {
					d: "M17 17 h10 M17 17 v10 M358 17 h-10 M358 17 v10 M17 425 h10 M17 425 v-10 M358 425 h-10 M358 425 v-10",
					fill: "none",
					stroke: "#69d5d4",
					strokeWidth: "1.4"
				}),
				/* @__PURE__ */ f("text", {
					x: "26",
					y: "27",
					className: "planetx-board-heading",
					children: ["SOLAR ARRAY / ", m("games.planetx.boardTitle")]
				}),
				/* @__PURE__ */ d("text", {
					x: "349",
					y: "43",
					textAnchor: "end",
					className: "planetx-board-meta",
					children: "FIELD 01 · 12 SECTORS"
				}),
				/* @__PURE__ */ d("circle", {
					cx: q,
					cy: J,
					r: "176",
					fill: "#0b2734",
					stroke: "#75b7bf",
					strokeWidth: "1.8"
				}),
				/* @__PURE__ */ d("circle", {
					cx: q,
					cy: J,
					r: "171",
					fill: "none",
					stroke: "#2d6071"
				}),
				/* @__PURE__ */ d("circle", {
					cx: q,
					cy: J,
					r: "168",
					fill: "#0f2d3a",
					stroke: "#5f98a6",
					strokeWidth: "1.2"
				}),
				/* @__PURE__ */ d("circle", {
					cx: q,
					cy: J,
					r: "151",
					fill: "#0b2635",
					stroke: "#3b6978",
					strokeWidth: "1.5"
				}),
				Array.from({ length: 72 }, (e, t) => {
					let n = -90 + t * 5, r = X(t % 6 == 0 ? 165 : 169, n), i = X(173, n);
					return /* @__PURE__ */ d("path", {
						d: `M${r.x} ${r.y} L${i.x} ${i.y}`,
						stroke: t % 6 == 0 ? "#69d5d4" : "#426d7a",
						strokeWidth: t % 6 == 0 ? 1.1 : .6
					}, `tick-${t}`);
				}),
				Array.from({ length: it }, (t, n) => {
					let r = -90 + n * 30, s = y || b(_, e.currentSector, n) < _.skySize, c = a(n), u = o(n), h = l(n), g = e.confirmed[String(n)], x = y ? e.board?.[n] : g, C = X(133, r), w = [
						"asteroid",
						"comet",
						"gasCloud",
						"dwarfPlanet",
						"empty",
						"planetX"
					].filter((e) => i[`${n}:${e}`] !== void 0).length, T = e.theories.filter((e) => e.sector === n), E = `${m("games.planetx.sectorLabel", { n: n + 1 })}${x ? `, ${m(K[x])}` : ""}${s ? `, ${m("games.planetx.visibleSkyLabel")}` : ""}`;
					return /* @__PURE__ */ f("g", {
						role: "button",
						tabIndex: 0,
						"aria-label": E,
						className: `planetx-sector ${c ? "is-selected" : ""} ${u ? "is-selectable" : ""} ${s ? "is-visible" : "is-hidden"}`,
						onClick: () => p(n),
						onKeyDown: (e) => S(e, n),
						children: [
							/* @__PURE__ */ d("path", {
								d: at(74, 148, r - 14.3, r + 14.3),
								fill: c ? "#26555b" : x ? "#1b4b51" : s ? "#173b49" : "#0b2230",
								stroke: c ? "#f2c369" : x ? "#69d5d4" : u ? "#65c7cc" : s ? "#4e8795" : "#35576b",
								strokeWidth: c ? 2.8 : u ? 1.8 : 1.2
							}),
							c && /* @__PURE__ */ d("path", {
								d: at(143, 148, r - 13.6, r + 13.6),
								fill: "#f2c369"
							}),
							h && !c && /* @__PURE__ */ d("path", {
								d: at(143, 148, r - 13.6, r + 13.6),
								fill: "#69d5d4"
							}),
							x ? /* @__PURE__ */ d(ot, {
								obj: x,
								x: X(103, r).x,
								y: X(103, r).y
							}) : Array.from({ length: 4 }, (e, t) => {
								let n = X(86 + t * 11, r);
								return /* @__PURE__ */ d("circle", {
									cx: n.x,
									cy: n.y,
									r: "2.5",
									fill: "none",
									stroke: s ? "#73a3ab" : "#4d7180",
									strokeWidth: "1.2"
								}, t);
							}),
							T.map((e, t) => {
								let n = X(117 - 11 * e.progress, r), i = (t - (T.length - 1) / 2) * 8, a = n.x - Math.sin(r * Math.PI / 180) * i, o = n.y + Math.cos(r * Math.PI / 180) * i;
								return /* @__PURE__ */ f("g", { children: [/* @__PURE__ */ d("circle", {
									cx: a,
									cy: o,
									r: "5.2",
									fill: v(e.rid),
									stroke: "#e7f3f0",
									strokeWidth: "1"
								}), e.frozen && e.accurate !== void 0 && /* @__PURE__ */ d("text", {
									x: a,
									y: o + 2.5,
									textAnchor: "middle",
									className: "planetx-theory-result",
									children: e.accurate ? "✓" : "×"
								})] }, e.id);
							}),
							/* @__PURE__ */ d("text", {
								x: C.x,
								y: C.y + 5.5,
								textAnchor: "middle",
								className: `planetx-sector-number ${c ? "selected" : s || x ? "visible" : ""}`,
								children: Y(n)
							}),
							_.cometSectors.includes(n) && /* @__PURE__ */ d("path", {
								d: (() => {
									let e = X(124, r + 11);
									return `M${e.x} ${e.y - 3} l3 3 -3 3 -3 -3 Z`;
								})(),
								fill: s ? "#69d5d4" : "#f2c369"
							}),
							c && /* @__PURE__ */ f("g", { children: [/* @__PURE__ */ d("circle", {
								cx: X(112, r).x,
								cy: X(112, r).y,
								r: "10",
								fill: "#102c38",
								stroke: "#f2c369",
								strokeWidth: "2"
							}), /* @__PURE__ */ d("circle", {
								cx: X(112, r).x,
								cy: X(112, r).y,
								r: "2.5",
								fill: "#f2c369"
							})] }),
							!x && w > 0 && /* @__PURE__ */ d("circle", {
								cx: X(141, r + 11).x,
								cy: X(141, r + 11).y,
								r: "2.5",
								fill: "#f2c369"
							})
						]
					}, n);
				}),
				/* @__PURE__ */ d("circle", {
					cx: q,
					cy: J,
					r: "157",
					fill: "none",
					stroke: "#6fabb3",
					strokeWidth: "1.1"
				}),
				Array.from({ length: it }, (e, t) => {
					let n = -90 + t * 30, r = X(152, n - 15), i = X(168, n - 15), a = X(162, n), o = X(174, n);
					return /* @__PURE__ */ f("g", { children: [
						/* @__PURE__ */ d("path", {
							d: `M${r.x} ${r.y} L${i.x} ${i.y}`,
							stroke: "#558797",
							strokeWidth: "1"
						}),
						t % _.theoryInterval === _.theoryInterval - 1 && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("circle", {
							cx: a.x,
							cy: a.y,
							r: "5",
							fill: "#143746",
							stroke: "#f2c369",
							strokeWidth: "1.2"
						}), /* @__PURE__ */ d("text", {
							x: a.x,
							y: a.y + 2.3,
							textAnchor: "middle",
							className: "planetx-track-letter",
							children: "T"
						})] }),
						_.conferenceCells.includes(t) && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("circle", {
							cx: o.x,
							cy: o.y,
							r: "5.5",
							fill: "#183e4a",
							stroke: "#f2c369",
							strokeWidth: "1.4"
						}), /* @__PURE__ */ d("text", {
							x: o.x,
							y: o.y + 2.3,
							textAnchor: "middle",
							className: "planetx-track-letter",
							children: "X"
						})] })
					] }, `track-${t}`);
				}),
				[...x.entries()].flatMap(([t, n]) => n.map((i, a) => {
					let o = -90 + t * 30, s = X(161, o), c = (a - (n.length - 1) / 2) * 13, l = s.x - Math.sin(o * Math.PI / 180) * c, u = s.y + Math.cos(o * Math.PI / 180) * c, p = e.turn === i && (e.phase === "turn" || e.phase === "lastChance");
					return /* @__PURE__ */ f("g", {
						"aria-label": `${g(i)} ${m("games.planetx.sectorLabel", { n: t + 1 })}`,
						children: [
							p && /* @__PURE__ */ d("circle", {
								cx: l,
								cy: u,
								r: "13",
								fill: "none",
								stroke: "#f2c369",
								strokeWidth: "1.5"
							}),
							/* @__PURE__ */ d("circle", {
								cx: l,
								cy: u,
								r: p ? 10 : 9,
								fill: v(i),
								stroke: "#c9e7e1",
								strokeWidth: "1.5"
							}),
							/* @__PURE__ */ d("text", {
								x: l,
								y: u + 3,
								textAnchor: "middle",
								className: "planetx-pawn-letter",
								children: g(i).slice(0, 1)
							}),
							i === r && /* @__PURE__ */ d("circle", {
								cx: l + 8,
								cy: u - 8,
								r: "2.5",
								fill: "#69d5d4"
							})
						]
					}, `pawn-${i}`);
				})),
				/* @__PURE__ */ d("circle", {
					cx: q,
					cy: J,
					r: "73",
					fill: "#091d2a",
					stroke: "#69a6b0",
					strokeWidth: "1.6"
				}),
				/* @__PURE__ */ d("circle", {
					cx: q,
					cy: J,
					r: "68",
					fill: `url(#pxEarth${h})`,
					stroke: "#2b6f81",
					strokeWidth: "1.4"
				}),
				/* @__PURE__ */ d("path", {
					d: at(49, 65, -105 + e.currentSector * 30, 75 + e.currentSector * 30),
					fill: "#69d5d4",
					opacity: ".16"
				}),
				/* @__PURE__ */ d("circle", {
					cx: q,
					cy: J,
					r: "51",
					fill: "none",
					stroke: "#41798a"
				}),
				/* @__PURE__ */ d("path", {
					d: `M140.5 ${J} H234.5 M${q} 178 V272`,
					fill: "none",
					stroke: "#2f6577",
					strokeWidth: ".8"
				}),
				/* @__PURE__ */ d("circle", {
					cx: q,
					cy: 212,
					r: "15",
					fill: "#104558",
					stroke: "#69d5d4",
					strokeWidth: "1.5"
				}),
				/* @__PURE__ */ d("ellipse", {
					cx: q,
					cy: 212,
					rx: "6.2",
					ry: "15",
					fill: "none",
					stroke: "#69d5d4",
					strokeWidth: ".85"
				}),
				/* @__PURE__ */ d("path", {
					d: "M174.5 207 H200.5 M174.5 217 H200.5",
					fill: "none",
					stroke: "#69d5d4",
					strokeWidth: ".85"
				}),
				/* @__PURE__ */ d("text", {
					x: q,
					y: 248,
					textAnchor: "middle",
					className: "planetx-sky-caption",
					children: "VISIBLE SKY"
				}),
				/* @__PURE__ */ f("text", {
					x: q,
					y: 267,
					textAnchor: "middle",
					className: "planetx-sky-range",
					children: [
						Y(e.currentSector),
						" — ",
						Y((e.currentSector + _.skySize - 1) % it)
					]
				}),
				/* @__PURE__ */ d("circle", {
					cx: "30",
					cy: "416",
					r: "4",
					fill: "#173b49",
					stroke: "#69d5d4"
				}),
				/* @__PURE__ */ d("text", {
					x: "39",
					y: "419",
					className: "planetx-legend",
					children: m("games.planetx.visibleSkyLabel")
				}),
				/* @__PURE__ */ d("circle", {
					cx: "145",
					cy: "416",
					r: "4",
					fill: "#26555b",
					stroke: "#f2c369"
				}),
				/* @__PURE__ */ d("text", {
					x: "154",
					y: "419",
					className: "planetx-legend",
					children: m("games.planetx.selectedLabel")
				}),
				/* @__PURE__ */ d("circle", {
					cx: "258",
					cy: "416",
					r: "4",
					fill: "#1b4b51",
					stroke: "#69d5d4"
				}),
				/* @__PURE__ */ d("text", {
					x: "267",
					y: "419",
					className: "planetx-legend",
					children: m("games.planetx.confirmedLabel")
				}),
				/* @__PURE__ */ f("text", {
					x: "349",
					y: "435",
					textAnchor: "end",
					className: "planetx-legend-small",
					children: ["◇ ", m("games.planetx.cometMarker")]
				})
			]
		})
	});
}
//#endregion
//#region src/games/planetx/view-player.tsx
var Z = _.sectors, ct = [
	"asteroid",
	"comet",
	"gasCloud",
	"dwarfPlanet"
], lt = [
	"asteroid",
	"comet",
	"gasCloud",
	"dwarfPlanet",
	"empty"
], ut = [
	"empty",
	"asteroid",
	"comet",
	"gasCloud",
	"dwarfPlanet"
], dt = [
	"asteroid",
	"comet",
	"gasCloud",
	"dwarfPlanet",
	"empty",
	"planetX"
], Q = (e) => e + 1;
function ft(e, t) {
	switch (t.kind) {
		case "start": return e("games.planetx.clueStart", {
			n: Q(t.sector),
			obj: e(K[t.obj]),
			art: e(Xe[t.obj])
		});
		case "survey": return e("games.planetx.clueSurvey", {
			from: Q(t.from),
			to: Q(t.to),
			count: t.count,
			obj: e(K[t.obj])
		});
		case "target": return t.obj === "empty" || t.obj === "planetX" ? e("games.planetx.clueTargetEmpty", { n: Q(t.sector) }) : e("games.planetx.clueTarget", {
			n: Q(t.sector),
			obj: e(K[t.obj]),
			art: e(Xe[t.obj])
		});
		case "research": return rt(e, t.rule);
	}
}
var pt = i()(a((e) => ({
	marks: {},
	cycle: (t, n) => e((e) => {
		let r = `${t}:${n}`, i = e.marks[r], a = { ...e.marks };
		return i === void 0 ? a[r] = 1 : i === 1 ? a[r] = 2 : delete a[r], { marks: a };
	}),
	reset: () => e({ marks: {} })
}), { name: "bgparty:planetx-notes" }));
function mt(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ d(ht, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function ht({ pub: e, priv: t, members: n, myRid: i, send: a }) {
	let p = s(), m = pt(), h = (e) => n.find((t) => t.rid === e)?.name ?? e, g = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? c[t.colorIndex % c.length].hex : "#888";
	}, v = e.phase === "turn" && e.turn === i, y = e.pending.includes(i), x = e.phase === "lastChance" && e.turn === i, S = e.players.find((e) => e.rid === i), C = e.phase === "done", [w, T] = r(null), [E, ee] = r(null), [D, te] = r(null), [O, k] = r({
		sector: null,
		prev: "empty",
		next: "empty"
	}), [A, j] = r([]), [M, N] = r(null), [ne, re] = r(null), [ie, P] = r(!1), [F, ae] = r("notes"), [oe, I] = r(!1), [se, ce] = r(!1), le = (t) => b(_, e.currentSector, t) < _.skySize, ue = e.phase === "theory" ? 1 : x && e.lastChance ? e.lastChance.behind <= 3 ? 1 : 2 : 0, de = e.phase === "theory" && y || x, L = () => {
		T(null), ee(null), te(null), k({
			sector: null,
			prev: "empty",
			next: "empty"
		});
	}, R = (e) => {
		a(e), L(), j([]);
	}, fe = (t) => {
		if (w === "survey" && E) {
			if (!le(t) || E === "comet" && !_.cometSectors.includes(t)) return;
			if (D === null) te(t);
			else {
				let e = D, n = t;
				if (b(_, e, n) >= _.skySize) return;
				R({
					type: "survey",
					obj: E,
					from: e,
					to: n
				});
			}
			return;
		}
		if (w === "target") {
			le(t) && R({
				type: "target",
				sector: t
			});
			return;
		}
		if (w === "locate") {
			k((e) => ({
				...e,
				sector: t
			}));
			return;
		}
		if (de) {
			if (e.confirmed[String(t)]) return;
			if (A.some((e) => e.sector === t)) {
				j(A.filter((e) => e.sector !== t));
				return;
			}
			A.length < ue && N(t);
			return;
		}
		re(t), ae("notes"), P(!0);
	}, pe = (e) => {
		M !== null && j([...A, {
			sector: M,
			obj: e
		}]), N(null);
	}, me;
	return me = C ? {
		tone: "done",
		text: p("games.planetx.phaseDone")
	} : e.phase === "conference" ? {
		tone: "warn",
		text: p("games.planetx.phaseConference"),
		sub: p(y ? "games.planetx.conferenceInfo" : "games.planetx.waitingConference")
	} : e.phase === "theory" ? {
		tone: "info",
		text: p("games.planetx.phaseTheory"),
		sub: y ? p("games.planetx.theoryPrompt", { n: 1 }) : p("games.planetx.waitingTheory")
	} : e.phase === "lastChance" ? x ? {
		tone: "accent",
		text: p("games.planetx.phaseLastChance"),
		sub: p("games.planetx.lastChancePrompt", {
			n: e.lastChance?.behind ?? 0,
			max: ue
		})
	} : {
		tone: "info",
		text: p("games.planetx.phaseLastChance"),
		sub: p("games.planetx.waitingLastChance", { name: h(e.turn ?? "") })
	} : v ? {
		tone: "accent",
		text: p("games.planetx.yourTurn")
	} : {
		tone: "info",
		text: p("games.planetx.phaseTurnWait", { name: h(e.turn ?? "") })
	}, /* @__PURE__ */ f("div", {
		className: "planetx-screen planetx-shell",
		children: [
			/* @__PURE__ */ d(l, {
				adaptive: !0,
				className: "planetx-adaptive",
				scroll: !1,
				actionsHeight: "planetx-action-slot",
				banner: /* @__PURE__ */ f("div", {
					className: "planetx-header",
					children: [
						/* @__PURE__ */ f("div", {
							className: "planetx-banner " + (v || x ? "is-active" : ""),
							children: [
								/* @__PURE__ */ d("div", {
									className: "planetx-heading",
									children: "PLANET X / OBSERVATORY"
								}),
								/* @__PURE__ */ f("div", {
									className: "planetx-status",
									children: [/* @__PURE__ */ d("span", { className: "planetx-status-dot" }), me.text]
								}),
								/* @__PURE__ */ d("div", {
									className: "planetx-status-sub",
									children: me.sub ?? "\xA0"
								}),
								/* @__PURE__ */ f("div", {
									className: "planetx-obs-readout",
									children: ["OBS ", Y(e.currentSector)]
								})
							]
						}),
						/* @__PURE__ */ d("div", {
							className: "planetx-player-strip",
							"aria-label": p("games.planetx.playerPositions"),
							children: e.players.map((t) => /* @__PURE__ */ f("div", {
								className: "planetx-player " + (e.turn === t.rid ? "is-turn" : ""),
								children: [/* @__PURE__ */ d("i", { style: { background: g(t.rid) } }), /* @__PURE__ */ f("span", {
									className: "planetx-player-label",
									children: [/* @__PURE__ */ d("b", { children: h(t.rid) }), /* @__PURE__ */ f("small", { children: [
										p("games.planetx.sectorShort"),
										" ",
										Y(t.sector)
									] })]
								})]
							}, t.rid))
						}),
						/* @__PURE__ */ f("div", {
							className: "planetx-links",
							children: [
								/* @__PURE__ */ d("button", {
									type: "button",
									className: "planetx-link",
									onClick: () => {
										ae("notes"), P(!0);
									},
									children: p("games.planetx.recordTitle")
								}),
								/* @__PURE__ */ f("button", {
									type: "button",
									className: "planetx-link",
									onClick: () => {
										ae("clues"), P(!0);
									},
									children: [
										p("games.planetx.myClues"),
										" · ",
										t?.clues.length ?? 0
									]
								}),
								/* @__PURE__ */ f("button", {
									type: "button",
									className: "planetx-link",
									onClick: () => ce(!0),
									children: [
										p("games.planetx.historyTitle"),
										" · ",
										e.history.length
									]
								})
							]
						})
					]
				}),
				actions: /* @__PURE__ */ f("div", {
					className: "planetx-actions",
					children: [/* @__PURE__ */ f("div", {
						className: "planetx-actions-meta",
						children: [/* @__PURE__ */ f("span", { children: ["MISSION CONTROL / ", p("games.planetx.actionConsole")] }), /* @__PURE__ */ f("span", { children: ["OBS ", Y(e.currentSector)] })]
					}), he()]
				}),
				children: /* @__PURE__ */ d("div", {
					className: "planetx-board-wrap",
					children: /* @__PURE__ */ d(st, {
						pub: e,
						members: n,
						myRid: i,
						marks: m.marks,
						selected: (e) => D === e || O.sector === e || A.some((t) => t.sector === e),
						selectable: (t) => w === "survey" && E ? !le(t) || E === "comet" && !_.cometSectors.includes(t) ? !1 : D === null || b(_, D, t) < _.skySize : w === "target" ? le(t) : w === "locate" ? !0 : de ? !e.confirmed[String(t)] && (A.length < ue || A.some((e) => e.sector === t)) : !1,
						neighborSector: (e) => O.sector !== null && (e === (O.sector + 1) % Z || e === (O.sector + Z - 1) % Z),
						onSectorTap: fe
					})
				})
			}),
			/* @__PURE__ */ d(o, {
				open: oe,
				onClose: () => I(!1),
				label: p("games.planetx.actResearch"),
				children: /* @__PURE__ */ f("div", {
					className: "planetx-sheet",
					children: [/* @__PURE__ */ d("p", {
						className: "planetx-sheet-title",
						children: p("games.planetx.researchPick")
					}), /* @__PURE__ */ d("div", {
						className: "planetx-sheet-list",
						children: e.researchTopics.map((e, t) => {
							let n = S?.researched.includes(t) ?? !1, r = S?.lastAction === "research";
							return /* @__PURE__ */ f("button", {
								type: "button",
								disabled: n || r,
								className: "planetx-sheet-item",
								onClick: () => {
									R({
										type: "research",
										topic: t
									}), I(!1);
								},
								children: [/* @__PURE__ */ f("p", {
									className: "text-sm font-bold",
									children: [
										p("games.planetx.clueResearch", { topic: t + 1 }),
										" · ",
										e.map((e) => p(K[e])).join(" & ")
									]
								}), /* @__PURE__ */ d("p", {
									className: "text-xs opacity-60",
									children: n ? p("games.planetx.researchUsed") : r ? p("games.planetx.researchBlocked") : e.map((e) => p(K[e])).join(" · ")
								})]
							}, t);
						})
					})]
				})
			}),
			/* @__PURE__ */ d(o, {
				open: M !== null,
				onClose: () => N(null),
				label: p("games.planetx.theoryPick"),
				children: /* @__PURE__ */ f("div", {
					className: "planetx-sheet",
					children: [/* @__PURE__ */ d("p", {
						className: "planetx-sheet-title",
						children: p("games.planetx.theoryPick")
					}), /* @__PURE__ */ d("div", {
						className: "grid grid-cols-2 gap-2",
						children: ct.map((e) => {
							let n = t?.tokensLeft[e] ?? 0, r = M !== null && (t?.myTheories.some((t) => t.sector === M && t.obj === e) || A.some((t) => t.sector === M && t.obj === e));
							return /* @__PURE__ */ f("button", {
								type: "button",
								disabled: n <= 0 || !!r,
								className: "planetx-sheet-item",
								onClick: () => pe(e),
								children: [
									/* @__PURE__ */ d(vt, { obj: e }),
									/* @__PURE__ */ d("p", {
										className: "text-sm font-bold",
										children: p(K[e])
									}),
									/* @__PURE__ */ f("p", {
										className: "text-xs opacity-60",
										children: [
											p("games.planetx.tokensLabel"),
											": ",
											n
										]
									})
								]
							}, e);
						})
					})]
				})
			}),
			/* @__PURE__ */ d(o, {
				tall: !0,
				compact: !0,
				open: ie,
				onClose: () => P(!1),
				label: p("games.planetx.recordTitle"),
				children: /* @__PURE__ */ f("div", {
					className: "planetx-sheet",
					children: [
						/* @__PURE__ */ f("div", {
							className: "planetx-sheet-caption",
							children: ["PRIVATE DATA / ", p("games.planetx.recordTitle")]
						}),
						/* @__PURE__ */ f("div", {
							className: "planetx-note-heading",
							children: [
								/* @__PURE__ */ d("div", {
									className: "planetx-sheet-title",
									children: p("games.planetx.recordMatrix")
								}),
								/* @__PURE__ */ d("span", { children: p("games.planetx.localOnlyShort") }),
								/* @__PURE__ */ d("button", {
									type: "button",
									"aria-label": p("games.planetx.cancel"),
									onClick: () => P(!1),
									children: /* @__PURE__ */ d("svg", {
										viewBox: "0 0 24 24",
										"aria-hidden": "true",
										children: /* @__PURE__ */ d("path", { d: "M5 5 19 19M19 5 5 19" })
									})
								})
							]
						}),
						/* @__PURE__ */ d("div", {
							className: "planetx-tabs",
							children: [
								"notes",
								"clues",
								"rules"
							].map((e) => /* @__PURE__ */ d("button", {
								type: "button",
								className: "planetx-tab " + (F === e ? "is-active" : ""),
								onClick: () => ae(e),
								children: p(e === "notes" ? "games.planetx.recordMatrix" : e === "clues" ? "games.planetx.myClues" : "games.planetx.basicRules")
							}, e))
						}),
						F === "notes" && /* @__PURE__ */ f(u, { children: [
							/* @__PURE__ */ d("p", {
								className: "planetx-action-copy",
								children: p("games.planetx.noteCycle")
							}),
							/* @__PURE__ */ f("table", {
								className: "planetx-note-table",
								children: [/* @__PURE__ */ d("thead", { children: /* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", { children: p("games.planetx.sectorShort") }), dt.map((e) => /* @__PURE__ */ f("th", { children: [
									p(K[e]),
									/* @__PURE__ */ d("br", {}),
									/* @__PURE__ */ f("small", { children: ["×", _.counts[e]] })
								] }, e))] }) }), /* @__PURE__ */ d("tbody", { children: Array.from({ length: Z }, (e, t) => /* @__PURE__ */ f("tr", {
									className: ne === t ? "is-focus" : "",
									children: [/* @__PURE__ */ d("td", { children: Y(t) }), dt.map((e) => {
										let n = m.marks[`${t}:${e}`];
										return /* @__PURE__ */ d("td", { children: /* @__PURE__ */ d("button", {
											type: "button",
											className: "planetx-note-cell " + (n === 1 ? "yes" : n === 2 ? "no" : ""),
											"aria-label": `${p("games.planetx.sectorLabel", { n: t + 1 })} ${p(K[e])}: ${n === 1 ? "✓" : n === 2 ? "✕" : "?"}`,
											onClick: () => {
												m.cycle(t, e), re(t);
											},
											children: n === 1 ? "✓" : n === 2 ? "×" : "·"
										}) }, e);
									})]
								}, t)) })]
							}),
							/* @__PURE__ */ f("div", {
								className: "planetx-note-footer",
								children: [/* @__PURE__ */ d("span", { children: ne === null ? p("games.planetx.localOnly") : `${p("games.planetx.sectorLabel", { n: ne + 1 })} · ${p("games.planetx.localOnly")}` }), /* @__PURE__ */ d("button", {
									type: "button",
									className: "planetx-action-mini primary",
									onClick: () => P(!1),
									children: p("games.planetx.confirm")
								})]
							})
						] }),
						F === "clues" && /* @__PURE__ */ d("div", {
							className: "planetx-sheet-list",
							children: (t?.clues ?? []).length === 0 ? /* @__PURE__ */ d("p", { children: "—" }) : t?.clues.map((e, t) => /* @__PURE__ */ d("div", {
								className: "planetx-sheet-item",
								children: ft(p, e)
							}, t))
						}),
						F === "rules" && /* @__PURE__ */ d("p", {
							className: "whitespace-pre-line text-xs leading-relaxed",
							children: p("games.planetx.rules")
						})
					]
				})
			}),
			/* @__PURE__ */ d(o, {
				open: se,
				onClose: () => ce(!1),
				label: p("games.planetx.historyTitle"),
				children: /* @__PURE__ */ f("div", {
					className: "planetx-sheet",
					children: [/* @__PURE__ */ d("p", {
						className: "planetx-sheet-title",
						children: p("games.planetx.historyTitle")
					}), /* @__PURE__ */ d("ul", {
						className: "planetx-sheet-list",
						children: e.history.map((e, t) => /* @__PURE__ */ d("li", {
							className: "planetx-sheet-item",
							children: bt(p, e, h)
						}, t))
					})]
				})
			})
		]
	});
	function he() {
		return C ? /* @__PURE__ */ d("p", {
			className: "planetx-action-copy",
			children: p("games.planetx.phaseDone")
		}) : e.phase === "conference" ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("p", {
			className: "planetx-action-copy",
			children: e.conference ? rt(p, e.conference) : p("games.planetx.waitingConference")
		}), y && /* @__PURE__ */ d("button", {
			type: "button",
			className: "planetx-action-mini primary",
			onClick: () => R({ type: "conferenceAck" }),
			children: p("games.planetx.ack")
		})] }) : w === "locate" && (v || x) ? /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d("p", {
				className: "planetx-action-copy",
				children: p("games.planetx.locatePick")
			}),
			/* @__PURE__ */ f("div", {
				className: "planetx-action-row",
				children: [
					/* @__PURE__ */ d(_t, {
						label: p("games.planetx.locatePrev", { n: O.sector === null ? "?" : Q((O.sector + Z - 1) % Z) }),
						value: O.prev,
						onCycle: () => k((e) => ({
							...e,
							prev: gt(e.prev)
						}))
					}),
					/* @__PURE__ */ d("div", {
						className: "planetx-action-mini",
						children: O.sector === null ? "X ?" : "X " + Y(O.sector)
					}),
					/* @__PURE__ */ d(_t, {
						label: p("games.planetx.locateNext", { n: O.sector === null ? "?" : Q((O.sector + 1) % Z) }),
						value: O.next,
						onCycle: () => k((e) => ({
							...e,
							next: gt(e.next)
						}))
					})
				]
			}),
			/* @__PURE__ */ f("div", {
				className: "planetx-action-row",
				children: [/* @__PURE__ */ d("button", {
					type: "button",
					className: "planetx-action-mini",
					onClick: L,
					children: p("games.planetx.cancel")
				}), /* @__PURE__ */ d("button", {
					type: "button",
					className: "planetx-action-mini primary",
					disabled: O.sector === null,
					onClick: () => O.sector !== null && R({
						type: "locate",
						sector: O.sector,
						objPrev: O.prev,
						objNext: O.next
					}),
					children: p("games.planetx.confirm")
				})]
			})
		] }) : de ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("p", {
			className: "planetx-action-copy",
			children: A.length ? A.map((e) => Y(e.sector) + " " + p(K[e.obj])).join(" · ") : p("games.planetx.theoryPick")
		}), /* @__PURE__ */ f("div", {
			className: "planetx-action-row",
			children: [
				A.map((e) => /* @__PURE__ */ f("button", {
					type: "button",
					className: "planetx-action-mini",
					onClick: () => j(A.filter((t) => t.sector !== e.sector)),
					children: [Y(e.sector), " ×"]
				}, e.sector)),
				/* @__PURE__ */ d("button", {
					type: "button",
					className: "planetx-action-mini",
					onClick: () => R({
						type: "submitTheories",
						entries: []
					}),
					children: p("games.planetx.skipTheories")
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "planetx-action-mini primary",
					disabled: A.length === 0,
					onClick: () => R({
						type: "submitTheories",
						entries: A
					}),
					children: [
						p("games.planetx.submit"),
						" ",
						A.length,
						"/",
						ue
					]
				}),
				x && /* @__PURE__ */ d("button", {
					type: "button",
					className: "planetx-action-mini",
					onClick: () => T("locate"),
					children: p("games.planetx.actLocate")
				})
			]
		})] }) : e.phase === "theory" || e.phase === "lastChance" ? /* @__PURE__ */ d("p", {
			className: "planetx-action-copy",
			children: e.phase === "theory" ? p("games.planetx.waitingTheory") : p("games.planetx.waitingLastChance", { name: h(e.turn ?? "") })
		}) : v ? w === "survey" ? E ? /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d("p", {
				className: "planetx-action-copy",
				children: p(E === "comet" ? "games.planetx.surveyCometHint" : "games.planetx.surveyPickRange")
			}),
			/* @__PURE__ */ f("p", {
				className: "planetx-action-copy",
				children: [
					D === null ? p("games.planetx.selectStart") : Y(D) + " → ?",
					" · ",
					p("games.planetx.surveyCostHint")
				]
			}),
			/* @__PURE__ */ d("button", {
				type: "button",
				className: "planetx-action-mini",
				onClick: L,
				children: p("games.planetx.cancel")
			})
		] }) : /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ d("p", {
				className: "planetx-action-copy",
				children: p("games.planetx.surveyPickObj")
			}),
			/* @__PURE__ */ d("div", {
				className: "planetx-pick-objects",
				children: lt.map((e) => /* @__PURE__ */ f("button", {
					type: "button",
					onClick: () => ee(e),
					children: [/* @__PURE__ */ d(vt, { obj: e }), p(K[e])]
				}, e))
			}),
			/* @__PURE__ */ d("button", {
				type: "button",
				className: "planetx-action-mini",
				onClick: L,
				children: p("games.planetx.cancel")
			})
		] }) : w === "target" ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ f("p", {
			className: "planetx-action-copy",
			children: [
				p("games.planetx.targetPick"),
				" · +",
				_.targetCost
			]
		}), /* @__PURE__ */ d("button", {
			type: "button",
			className: "planetx-action-mini",
			onClick: L,
			children: p("games.planetx.cancel")
		})] }) : /* @__PURE__ */ f("div", {
			className: "planetx-action-grid",
			children: [
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "planetx-action",
					onClick: () => T("survey"),
					children: [
						/* @__PURE__ */ d(yt, { kind: "survey" }),
						p("games.planetx.actSurvey"),
						/* @__PURE__ */ d("small", { children: p("games.planetx.surveyCostShort") })
					]
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "planetx-action",
					disabled: (S?.targetsLeft ?? 0) <= 0,
					onClick: () => T("target"),
					children: [
						/* @__PURE__ */ d(yt, { kind: "target" }),
						p("games.planetx.actTarget"),
						/* @__PURE__ */ f("small", { children: [
							"+",
							_.targetCost,
							" · ×",
							S?.targetsLeft ?? 0
						] })
					]
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "planetx-action",
					disabled: S?.lastAction === "research" || e.researchTopics.every((e, t) => S?.researched.includes(t)),
					onClick: () => I(!0),
					children: [
						/* @__PURE__ */ d(yt, { kind: "research" }),
						p("games.planetx.actResearch"),
						/* @__PURE__ */ f("small", { children: ["+", _.researchCost] })
					]
				}),
				/* @__PURE__ */ f("button", {
					type: "button",
					className: "planetx-action primary",
					onClick: () => T("locate"),
					children: [
						/* @__PURE__ */ d(yt, { kind: "locate" }),
						p("games.planetx.actLocate"),
						/* @__PURE__ */ f("small", { children: ["+", _.locateCost] })
					]
				})
			]
		}) : /* @__PURE__ */ d("p", {
			className: "planetx-action-copy",
			children: p("games.planetx.phaseTurnWait", { name: h(e.turn ?? "") })
		});
	}
}
function gt(e) {
	return ut[(ut.indexOf(e) + 1) % ut.length];
}
function _t({ label: e, value: t, onCycle: n }) {
	let r = s();
	return /* @__PURE__ */ f("button", {
		type: "button",
		className: "planetx-action-mini",
		onClick: n,
		children: [/* @__PURE__ */ d("span", {
			className: "block text-[9px] opacity-70",
			children: e
		}), /* @__PURE__ */ d("span", {
			className: "block text-[10px]",
			children: r(K[t])
		})]
	});
}
function vt({ obj: e }) {
	let t = s();
	return /* @__PURE__ */ d("svg", {
		viewBox: "-16 -16 32 32",
		role: "img",
		"aria-label": t(K[e]),
		children: /* @__PURE__ */ d(ot, { obj: e })
	});
}
function yt({ kind: e }) {
	return /* @__PURE__ */ d("svg", {
		className: "planetx-action-icon",
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children: {
			survey: /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("circle", {
				cx: "14",
				cy: "14",
				r: "7"
			}), /* @__PURE__ */ d("path", { d: "m19 19 7 7M14 7v14M7 14h14" })] }),
			target: /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("circle", {
					cx: "16",
					cy: "16",
					r: "10"
				}),
				/* @__PURE__ */ d("circle", {
					cx: "16",
					cy: "16",
					r: "4"
				}),
				/* @__PURE__ */ d("path", { d: "M16 2v7M16 23v7M2 16h7M23 16h7" })
			] }),
			research: /* @__PURE__ */ d(u, { children: /* @__PURE__ */ d("path", { d: "M6 5h16l4 4v18H6zM22 5v5h4M10 14h12M10 19h12M10 24h8" }) }),
			locate: /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("circle", {
				cx: "16",
				cy: "16",
				r: "11"
			}), /* @__PURE__ */ d("path", { d: "m11 11 10 10m0-10L11 21M16 1v4M16 27v4" })] })
		}[e]
	});
}
function bt(e, t, n) {
	switch (t.kind) {
		case "survey": return e("games.planetx.historySurvey", {
			name: n(t.rid),
			obj: e(K[t.obj]),
			from: Q(t.from),
			to: Q(t.to)
		});
		case "target": return e("games.planetx.historyTarget", {
			name: n(t.rid),
			n: Q(t.sector)
		});
		case "research": return e("games.planetx.historyResearch", {
			name: n(t.rid),
			topic: t.topic + 1
		});
		case "locate": return e(t.success ? "games.planetx.historyLocateOk" : "games.planetx.historyLocateFail", { name: n(t.rid) });
		case "theories": return e("games.planetx.historyTheories", {
			name: n(t.rid),
			list: t.sectors.map(Q).join("·")
		});
		case "conference": return e("games.planetx.historyConference");
	}
}
//#endregion
//#region src/games/planetx/bot.ts
var $ = _.sectors, xt = [
	"asteroid",
	"comet",
	"gasCloud",
	"dwarfPlanet"
];
function St() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 2 ** 32;
}
function Ct(e) {
	return e[Math.floor(St() * e.length)];
}
function wt(e, t, n = 24, r = 1500) {
	let i = [], a = Object.entries(e.confirmed);
	for (let o = 0; o < r && i.length < n; o++) {
		let n = w(_, St);
		if (!n) continue;
		let r = !0;
		for (let [e, t] of a) if (n[Number(e)] !== t) {
			r = !1;
			break;
		}
		if (r && e.conference && !F(_, e.conference, n) && (r = !1), r) for (let e of t) {
			if (e.kind === "start") n[e.sector] === e.obj && (r = !1);
			else if (e.kind === "target") (n[e.sector] === "planetX" ? "empty" : n[e.sector]) !== e.obj && (r = !1);
			else if (e.kind === "survey") {
				let t = 0;
				for (let r = e.from; (n[r] === e.obj || e.obj === "empty" && n[r] === "planetX") && t++, r !== e.to; r = (r + 1) % $);
				t !== e.count && (r = !1);
			} else F(_, e.rule, n) || (r = !1);
			if (!r) break;
		}
		r && i.push(n);
	}
	return i;
}
function Tt(e) {
	let t = /* @__PURE__ */ new Map();
	if (e.length === 0) return t;
	for (let n of e) for (let r = 0; r < $; r++) {
		let i = `${r}:${n[r]}`;
		t.set(i, (t.get(i) ?? 0) + 1 / e.length);
	}
	return t;
}
var Et = (e, t, n) => e.get(`${t}:${n}`) ?? 0;
function Dt(e) {
	let t = null, n = .9;
	for (let r = 0; r < $; r++) {
		let i = Et(e, r, "planetX");
		if (i < n) continue;
		let a = (t) => {
			let n = null, r = .8;
			for (let i of ["empty", ...xt]) {
				let a = Et(e, t, i);
				a > r && (r = a, n = i);
			}
			return n;
		}, o = a((r - 1 + $) % $), s = a((r + 1) % $);
		o && s && (t = {
			sector: r,
			objPrev: o,
			objNext: s
		}, n = i);
	}
	return t;
}
function Ot(e, t, n, r) {
	let i = [];
	for (let r = 0; r < $; r++) if (!e.confirmed[String(r)] && !t.myTheories.some((e) => e.sector === r)) for (let e of xt) {
		if ((t.tokensLeft[e] ?? 0) <= 0) continue;
		let a = Et(n, r, e);
		a >= .75 && i.push({
			sector: r,
			obj: e,
			score: a * _.scoreValues[e]
		});
	}
	return i.sort((e, t) => t.score - e.score), i.slice(0, r).map(({ sector: e, obj: t }) => ({
		sector: e,
		obj: t
	}));
}
function kt(e, t) {
	let n = e.currentSector, r = (n + _.skySize - 1) % $, i = [{
		from: n,
		to: r
	}];
	if (_.cometSectors.includes(n)) {
		let e = _.cometSectors.filter((e) => b(_, n, e) < _.skySize), t = e[e.length - 1];
		t !== void 0 && t !== n && i.push({
			from: n,
			to: t
		});
	}
	let a = {
		obj: "asteroid",
		from: n,
		to: r
	}, o = -1;
	for (let e of i) {
		let i = e.from === n && e.to === r ? [
			"asteroid",
			"gasCloud",
			"dwarfPlanet",
			"empty"
		] : ["comet"];
		for (let n of i) {
			let r = t.map((t) => {
				let r = 0;
				for (let i = e.from; (t[i] === n || n === "empty" && t[i] === "planetX") && r++, i !== e.to; i = (i + 1) % $);
				return r;
			}), i = r.reduce((e, t) => e + t, 0) / Math.max(1, r.length), s = r.reduce((e, t) => e + (t - i) ** 2, 0) / Math.max(1, r.length);
			s > o && (o = s, a = {
				obj: n,
				...e
			});
		}
	}
	return a;
}
function At(e) {
	return {
		type: "survey",
		obj: "asteroid",
		from: e.currentSector,
		to: (e.currentSector + _.skySize - 1) % $
	};
}
var jt = (e, t) => {
	let n = e.public, r = e.private, i = t.rid;
	if (n.phase === "conference") return n.pending.includes(i) ? { action: { type: "conferenceAck" } } : null;
	if (t.difficulty === "weak") {
		if (n.phase === "theory") return n.pending.includes(i) ? { action: {
			type: "submitTheories",
			entries: []
		} } : null;
		if (n.phase === "lastChance") return n.turn === i ? { action: {
			type: "submitTheories",
			entries: []
		} } : null;
		if (n.phase !== "turn" || n.turn !== i || !r) return null;
		let e = n.players.find((e) => e.rid === i), t = [
			0,
			1,
			2,
			3,
			4,
			5
		].filter((t) => !(e?.researched.includes(t) ?? !0));
		return e?.lastAction !== "research" && t.length > 0 && St() < .5 ? { action: {
			type: "research",
			topic: Ct(t)
		} } : { action: At(n) };
	}
	if (n.phase === "theory") {
		if (!n.pending.includes(i) || !r) return null;
		let e = wt(n, r.clues);
		return { action: {
			type: "submitTheories",
			entries: e.length > 0 ? Ot(n, r, Tt(e), _.theoriesPerTurn) : []
		} };
	}
	if (n.phase === "lastChance") {
		if (n.turn !== i || !r) return null;
		let e = wt(n, r.clues), t = Tt(e), a = e.length > 0 ? Dt(t) : null;
		if (a) return { action: {
			type: "locate",
			...a
		} };
		let o = n.lastChance?.turn === i ? n.lastChance.behind : 6, s = o <= 3 ? 1 : o <= 5 ? 2 : 0;
		return { action: {
			type: "submitTheories",
			entries: e.length > 0 && s > 0 ? Ot(n, r, t, s) : []
		} };
	}
	if (n.phase !== "turn" || n.turn !== i || !r) return null;
	let a = wt(n, r.clues), o = Tt(a), s = n.players.find((e) => e.rid === i);
	if (!s) return null;
	let c = a.length > 0 ? Dt(o) : null;
	if (c) return { action: {
		type: "locate",
		...c
	} };
	let l = n.researchTopics.map((e, t) => t).filter((e) => !s.researched.includes(e));
	if (s.lastAction !== "research" && l.length > 0) return { action: {
		type: "research",
		topic: Ct(l)
	} };
	if (s.targetsLeft > 0 && a.length > 0) {
		let e = -1, t = 0;
		for (let r = 0; r < $; r++) {
			if (b(_, n.currentSector, r) >= _.skySize || n.confirmed[String(r)]) continue;
			let i = Et(o, r, "planetX");
			i >= .2 && i <= .85 && i > t && (t = i, e = r);
		}
		if (e >= 0) return { action: {
			type: "target",
			sector: e
		} };
	}
	return a.length > 0 ? { action: {
		type: "survey",
		...kt(n, a)
	} } : { action: At(n) };
}, Mt = (e, t, n) => {
	switch (e.type) {
		case "survey": {
			let t = b(_, e.from, e.to) + 1;
			return n("games.planetx.describeSurvey", {
				obj: n(K[e.obj]),
				from: e.from + 1,
				to: e.to + 1,
				cost: v(_, t)
			});
		}
		case "target": return n("games.planetx.describeTarget", { n: e.sector + 1 });
		case "research": return n("games.planetx.describeResearch", { topic: (t.public.researchTopics[e.topic] ?? []).map((e) => n(K[e])).join(" & ") || e.topic + 1 });
		case "locate": return n("games.planetx.describeLocate", { n: e.sector + 1 });
		case "submitTheories": return e.entries.length === 0 ? n("games.planetx.describeSkipTheories") : n("games.planetx.describeTheories", { list: e.entries.map((e) => `${e.sector + 1} ${n(K[e.obj])}`).join("·") });
		case "conferenceAck": return n("games.planetx.describeAck");
	}
};
//#endregion
//#region src/games/planetx/game-over.tsx
function Nt(e) {
	return /* @__PURE__ */ d("div", {
		className: "planetx-over",
		children: /* @__PURE__ */ d(p, {
			...e,
			accent: xe.accent
		})
	});
}
//#endregion
//#region src/games/planetx/options.tsx
var Pt = [
	{
		id: "beginner",
		label: "games.planetx.optBeginner"
	},
	{
		id: "experienced",
		label: "games.planetx.optExperienced"
	},
	{
		id: "genius",
		label: "games.planetx.optGenius"
	}
];
function Ft({ value: e, onChange: t }) {
	let n = s(), r = Oe.safeParse(e), i = r.success ? r.data : Oe.parse(void 0);
	return /* @__PURE__ */ d(h, {
		title: n("games.planetx.optDifficulty"),
		columns: 3,
		children: Pt.map((e) => /* @__PURE__ */ d(m, {
			name: "planetx-difficulty",
			value: e.id,
			checked: i.difficulty === e.id,
			label: n(e.label),
			accent: xe.accent,
			onChange: () => t({
				...i,
				difficulty: e.id
			})
		}, e.id))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/planetx/entry.tsx
var It = {
	definition: Ye,
	View: mt,
	bot: jt,
	describe: Mt,
	OverView: Nt,
	Options: Ft,
	locales: {
		zh: {
			name: "X行星之谜",
			desc: "推理 X 行星的藏身扇区，提出理论，抢先定位",
			rules: "目标:推理出 X 行星藏在哪个扇区;首位正确定位(连同左右邻格的天体)触发终局,总分最高者获胜。\n盘面:12 个扇区围成一圈,各藏一个天体:\n· 4 颗小行星(两两相邻),2 颗彗星(只在带标记的素数扇区)。\n· 2 朵气体云(都与空扇区相邻),1 颗矮行星(不与 X 相邻)。\n· 1 颗 X 行星(显示为空),2 个真正的空扇区。\n回合:棋子最靠后的玩家行动(同格先到先动)。\n· 行动后棋子按花费前进,箭头转到最靠后棋子处。\n· 经过理论格(每 3 格)触发理论阶段;第一圈经过扇区 9 触发 X1 会议。\n行动(四选一):\n· 调查:选一种天体与可见天空内的连续区间,私下得知数量;调查「空」会把 X 计入。\n· 调查按区间宽前进:宽 1-3 格前进 4 步,宽 4-6 格前进 3 步。\n· 锁定:私下得知一个可见扇区的内容,限 2 次,前进 4 步。\n· 研究:私下查看一个主题的规则,不能连续两回合研究,前进 1 步。\n· 定位:指认 X 与左右邻格,前进 5 步,只公布成败。\n理论:\n· 理论阶段每人可秘密提交 1 个「某扇区是某天体」,进入该扇区评审轨最外格。\n· 每个理论阶段所有理论内移一格;到最内格时评审:正确则该扇区确认公开,错误则移除并罚前进 1 格。\n· 被确认扇区上的其余理论全部翻开,错误者同样移除并罚前进 1 格;每种天体的理论标记有限。\n终局:有人定位成功后,落后其 1-5 格的玩家按从后到前各获最后一次机会。\n· 落后 1-3 格可提交 1 个理论,4-5 格可提交 2 个,或尝试定位。\n计分:首位定位 X 者获得 10 分,其余定位成功者按落后格数的两倍得分。\n· 正确理论按天体获得 2/3/4/4 分;每个你最先(含并列)猜中的扇区获得 1 分领袖分。\n· 平手依次比定位分、领袖分,再平则共享胜利。",
			optDifficulty: "起始线索",
			optBeginner: "新手 · 8 条",
			optExperienced: "老手 · 4 条",
			optGenius: "天才 · 无",
			objAsteroid: "小行星",
			objComet: "彗星",
			objGasCloud: "气体云",
			objDwarfPlanet: "矮行星",
			objEmpty: "空扇区",
			objPlanetX: "X行星",
			artAsteroid: "小行星",
			artComet: "彗星",
			artGasCloud: "气体云",
			artDwarfPlanet: "矮行星",
			artEmpty: "空扇区",
			artPlanetX: "X行星",
			plAsteroid: "小行星",
			plComet: "彗星",
			plGasCloud: "气体云",
			plDwarfPlanet: "矮行星",
			plEmpty: "空扇区",
			plPlanetX: "X行星",
			ruleAdjacentNone: "没有{{obj1}}与{{obj2}}相邻",
			ruleAdjacentAtLeastOne: "至少有一个{{obj1}}与{{obj2}}相邻",
			ruleAdjacentEvery: "每个{{obj1}}都与{{obj2}}相邻",
			ruleOppositeNone: "没有{{obj1}}与{{obj2}}正对",
			ruleOppositeAtLeastOne: "至少有一个{{obj1}}与{{obj2}}正对",
			ruleOppositeEvery: "每个{{obj1}}都与{{obj2}}正对",
			ruleWithinNone: "没有{{obj1}}在{{obj2}}的 {{n}} 格以内",
			ruleWithinAtLeastOne: "至少有一个{{obj1}}在{{obj2}}的 {{n}} 格以内",
			ruleWithinEvery: "每个{{obj1}}都在{{obj2}}的 {{n}} 格以内",
			ruleAdjacentSelfNone: "{{obj}}两两互不相邻",
			ruleAdjacentSelfAtLeastOne: "至少有两个{{obj}}相邻",
			ruleAdjacentSelfEvery: "每个{{obj}}都与另一个{{obj}}相邻",
			ruleOppositeSelfNone: "{{obj}}两两互不正对",
			ruleOppositeSelfAtLeastOne: "至少有两个{{obj}}正对",
			ruleOppositeSelfEvery: "每个{{obj}}都与另一个{{obj}}正对",
			ruleBandWithin: "所有{{obj}}集中在至多 {{n}} 格的带内",
			ruleBandExactly: "所有{{obj}}集中在恰好 {{n}} 格的带内",
			ruleSectors: "{{pl}}只可能在扇区 {{list}}",
			clueStart: "扇区 {{n}} 不是{{obj}}",
			clueSurvey: "扇区 {{from}}–{{to}} 有 {{count}} 个{{obj}}",
			clueTarget: "扇区 {{n}} 是{{obj}}",
			clueTargetEmpty: "扇区 {{n}} 看起来是空的",
			clueResearch: "主题 {{topic}}",
			phaseTurnWait: "等 {{name}} 行动…",
			yourTurn: "轮到你行动",
			phaseTheory: "理论阶段",
			theoryPrompt: "可提交至多 {{n}} 个理论(面朝下进入评审轨)",
			waitingTheory: "等其他人提交理论…",
			phaseConference: "X1 会议",
			conferenceInfo: "会议公开了一条关于 X 行星的规则:",
			waitingConference: "等其他人确认…",
			ack: "知道了",
			phaseLastChance: "最后机会",
			lastChancePrompt: "落后 {{n}} 格:可提交至多 {{max}} 个理论,或尝试定位",
			lastChanceLocateOnly: "落后 {{n}} 格:可尝试定位",
			waitingLastChance: "等 {{name}} 做最后抉择…",
			phaseDone: "对局结束",
			actSurvey: "调查",
			actTarget: "锁定",
			actResearch: "研究",
			actLocate: "定位X",
			surveyPickObj: "调查哪种天体?",
			surveyPickRange: "点选可见天空内的区间首尾",
			surveyWidth: "{{n}} 格 · 前进 {{cost}} 步",
			surveyCometHint: "彗星调查:首尾必须是带标记的素数扇区",
			targetPick: "点选一个可见扇区(限 2 次)",
			researchPick: "选主题,私下查看规则(前进 1 步)",
			researchUsed: "已研究",
			researchBlocked: "上回合刚研究过",
			locatePick: "指认 X 所在格与左右邻格(前进 5 步)",
			locatePrev: "上一格(扇区 {{n}})",
			locateNext: "下一格(扇区 {{n}})",
			confirm: "确定",
			cancel: "取消",
			submit: "提交",
			skipTheories: "不提交",
			theoryPick: "点选扇区提交「它是某天体」的理论",
			tokensLabel: "理论标记余量",
			theoryCorrect: "成立",
			theoryWrong: "不成立",
			confirmedLabel: "已确认",
			visibleSkyLabel: "可见天空",
			selectedLabel: "已选择",
			boardTitle: "太阳系观测盘",
			sectorLabel: "扇区 {{n}}",
			cometMarker: "彗星候选格",
			playerPositions: "玩家位置",
			actionConsole: "行动台",
			youLabel: "你",
			recordTitle: "个人记录",
			recordMatrix: "扇区推理矩阵",
			basicRules: "基础规则",
			sectorShort: "扇区",
			noteCycle: "点击单元格循环：未标记 → 可能 → 排除",
			localOnly: "你的标记只保存在本机",
			localOnlyShort: "仅本机",
			selectStart: "选择起始扇区",
			surveyCostHint: "1–3 格 +4 步 · 4–6 格 +3 步",
			surveyCostShort: "+3 / +4 步",
			myClues: "我的情报",
			sectionStart: "起始线索",
			sectionResearch: "研究",
			sectionSurvey: "调查",
			sectionTarget: "锁定",
			historyTitle: "记录",
			noteHint: "点扇区做笔记:循环 ? / ✓ / ✗(仅自己可见)",
			historySurvey: "{{name}} 调查了 {{obj}}(扇区 {{from}}–{{to}})",
			historyTarget: "{{name}} 锁定了扇区 {{n}}",
			historyResearch: "{{name}} 研究了「{{topic}}」",
			historyLocateOk: "{{name}} 定位成功!",
			historyLocateFail: "{{name}} 定位失败",
			historyTheories: "{{name}} 提交了理论(扇区 {{list}})",
			historyConference: "X1 会议召开,规则公开",
			errNotYourTurn: "现在轮不到你",
			errBadSurveyRange: "区间必须在可见天空内",
			errCometRange: "调查彗星时,区间首尾必须是带标记的素数扇区",
			errNoTargets: "锁定标记已用完",
			errBadTarget: "只能锁定可见天空内的扇区",
			errBadTopic: "无效的研究主题",
			errAlreadyResearched: "这个主题你已经研究过了",
			errResearchConsecutive: "不能连续两回合研究",
			errTooManyTheories: "本次最多提交 {{n}} 个理论",
			errNoTokens: "该天体的理论标记已用完",
			errSectorConfirmed: "该扇区已确认,不能再提交理论",
			errDuplicateSector: "一次提交中同一扇区只能放一个理论",
			errDuplicateTheory: "同一扇区的相同理论不能重复提交",
			errNoLastChance: "你的位置没有最后机会",
			describeSurvey: "调查 {{obj}}(扇区 {{from}}–{{to}},前进 {{cost}} 步)",
			describeTarget: "锁定扇区 {{n}}",
			describeResearch: "研究主题「{{topic}}」",
			describeLocate: "尝试定位:扇区 {{n}}",
			describeTheories: "提交理论:扇区 {{list}}",
			describeSkipTheories: "本轮不提交理论",
			describeAck: "确认会议信息"
		},
		en: {
			name: "The Search for Planet X",
			desc: "Deduce which sector hides Planet X, publish theories, locate it first",
			rules: "Goal: deduce which sector hides Planet X; the first player to locate it (naming both neighbors) triggers the endgame — highest score wins.\nBoard: 12 sectors in a ring, each hiding an object:\n· 4 asteroids (each adjacent to another), 2 comets (marked prime sectors only).\n· 2 gas clouds (each adjacent to an empty sector), 1 dwarf planet (not adjacent to X).\n· 1 Planet X (appears empty), 2 truly empty sectors.\nTurns: the player furthest back acts (earliest arrival breaks ties).\n· After acting, your pawn advances by the action cost and the arrow rotates to the rearmost pawn.\n· Passing a theory space (every 3) triggers a theory phase; passing sector 9 on the first rotation triggers the X1 conference.\nActions — pick one:\n· Survey: pick an object type and a range within the visible sky; you privately learn how many are there. Surveying \"empty\" counts Planet X.\n· Survey cost by width: 1-3 wide advances 4 steps, 4-6 wide advances 3 steps.\n· Target: privately learn one visible sector, twice per game, advances 4 steps.\n· Research: privately read one topic's rule, never twice in a row, advances 1 step.\n· Locate: name X and both neighbors, advances 5 steps, only success/failure is public.\nTheories:\n· In each theory phase everyone may secretly submit 1 theory (\"sector S is object O\") onto the outermost space of that sector's review track.\n· All theories advance one space per theory phase; at the innermost space they are reviewed — correct ones confirm the sector, wrong ones are removed and their owners advance 1 space.\n· Other theories on a confirmed sector are revealed, wrong ones likewise removed with penalty; theory tokens per object are limited.\nEndgame: once someone locates X, players 1-5 sectors behind (back to front) each get one last chance.\n· 1-3 behind: submit 1 theory; 4-5 behind: submit 2 theories; or attempt a locate.\nScoring: the first locator scores 10 pts; later locators score twice their sectors behind.\n· Correct theories score 2/3/4/4 by object; 1 leader point per sector you were first (or tied first) to guess.\n· Ties: locate points, then leader points, then shared victory.",
			optDifficulty: "Starting clues",
			optBeginner: "Beginner · 8",
			optExperienced: "Experienced · 4",
			optGenius: "Genius · none",
			objAsteroid: "asteroid",
			objComet: "comet",
			objGasCloud: "gas cloud",
			objDwarfPlanet: "dwarf planet",
			objEmpty: "empty sector",
			objPlanetX: "Planet X",
			artAsteroid: "an asteroid",
			artComet: "a comet",
			artGasCloud: "a gas cloud",
			artDwarfPlanet: "a dwarf planet",
			artEmpty: "an empty sector",
			artPlanetX: "Planet X",
			plAsteroid: "asteroids",
			plComet: "comets",
			plGasCloud: "gas clouds",
			plDwarfPlanet: "dwarf planets",
			plEmpty: "empty sectors",
			plPlanetX: "Planet X",
			ruleAdjacentNone: "No {{obj1}} is adjacent to any {{obj2}}.",
			ruleAdjacentAtLeastOne: "At least one {{obj1}} is adjacent to {{art2}}.",
			ruleAdjacentEvery: "Every {{obj1}} is adjacent to {{art2}}.",
			ruleOppositeNone: "No {{obj1}} is directly opposite any {{obj2}}.",
			ruleOppositeAtLeastOne: "At least one {{obj1}} is directly opposite {{art2}}.",
			ruleOppositeEvery: "Every {{obj1}} is directly opposite {{art2}}.",
			ruleWithinNone: "No {{obj1}} is within {{n}} sectors of any {{obj2}}.",
			ruleWithinAtLeastOne: "At least one {{obj1}} is within {{n}} sectors of {{art2}}.",
			ruleWithinEvery: "Every {{obj1}} is within {{n}} sectors of {{art2}}.",
			ruleAdjacentSelfNone: "No {{obj}} is adjacent to another {{obj}}.",
			ruleAdjacentSelfAtLeastOne: "At least one {{obj}} is adjacent to another {{obj}}.",
			ruleAdjacentSelfEvery: "Every {{obj}} is adjacent to another {{obj}}.",
			ruleOppositeSelfNone: "No {{obj}} is directly opposite another {{obj}}.",
			ruleOppositeSelfAtLeastOne: "At least one {{obj}} is directly opposite another {{obj}}.",
			ruleOppositeSelfEvery: "Every {{obj}} is directly opposite another {{obj}}.",
			ruleBandWithin: "All {{pl}} are in a band of at most {{n}} sectors.",
			ruleBandExactly: "All {{pl}} are in a band of exactly {{n}} sectors.",
			ruleSectors: "The {{pl}} are only in sectors {{list}}.",
			clueStart: "Sector {{n}} does not contain {{art}}",
			clueSurvey: "Sectors {{from}}–{{to}}: {{count}} × {{obj}}",
			clueTarget: "Sector {{n}} is {{art}}",
			clueTargetEmpty: "Sector {{n}} appears empty",
			clueResearch: "Topic {{topic}}",
			phaseTurnWait: "Waiting for {{name}}…",
			yourTurn: "Your turn",
			phaseTheory: "Theory phase",
			theoryPrompt: "Submit up to {{n}} theories (face-down onto the review track)",
			waitingTheory: "Waiting for other theories…",
			phaseConference: "X1 Conference",
			conferenceInfo: "The conference reveals a rule about Planet X:",
			waitingConference: "Waiting for others to acknowledge…",
			ack: "Got it",
			phaseLastChance: "Last chance",
			lastChancePrompt: "{{n}} sectors behind: submit up to {{max}} theories or attempt a locate",
			lastChanceLocateOnly: "{{n}} sectors behind: you may attempt a locate",
			waitingLastChance: "Waiting for {{name}}…",
			phaseDone: "Game over",
			actSurvey: "Survey",
			actTarget: "Target",
			actResearch: "Research",
			actLocate: "Locate X",
			surveyPickObj: "Survey which object?",
			surveyPickRange: "Tap both ends of a range in the visible sky",
			surveyWidth: "{{n}} sectors · advance {{cost}}",
			surveyCometHint: "Comet surveys: both ends must be marked prime sectors",
			targetPick: "Tap a visible sector (2 per game)",
			researchPick: "Pick a topic to read privately (advance 1)",
			researchUsed: "Read",
			researchBlocked: "Researched last turn",
			locatePick: "Name the sector of X and both neighbors (advance 5)",
			locatePrev: "Previous (sector {{n}})",
			locateNext: "Next (sector {{n}})",
			confirm: "Confirm",
			cancel: "Cancel",
			submit: "Submit",
			skipTheories: "Skip",
			theoryPick: "Tap a sector to theorize what it contains",
			tokensLabel: "Theory tokens left",
			theoryCorrect: "correct",
			theoryWrong: "wrong",
			confirmedLabel: "Confirmed",
			visibleSkyLabel: "Visible sky",
			selectedLabel: "Selected",
			boardTitle: "Solar array",
			sectorLabel: "Sector {{n}}",
			cometMarker: "Comet candidate",
			playerPositions: "Player positions",
			actionConsole: "Action deck",
			youLabel: "You",
			recordTitle: "Private record",
			recordMatrix: "Sector matrix",
			basicRules: "Basic rules",
			sectorShort: "Sector",
			noteCycle: "Tap a cell: unmarked → possible → excluded",
			localOnly: "Your marks stay on this device",
			localOnlyShort: "LOCAL ONLY",
			selectStart: "Select a starting sector",
			surveyCostHint: "1–3 sectors +4 · 4–6 sectors +3",
			surveyCostShort: "+3 / +4",
			myClues: "My intel",
			sectionStart: "Starting clues",
			sectionResearch: "Research",
			sectionSurvey: "Surveys",
			sectionTarget: "Targets",
			historyTitle: "Log",
			noteHint: "Tap a sector for notes: cycle ? / ✓ / ✗ (only you see this)",
			historySurvey: "{{name}} surveyed {{obj}} (sectors {{from}}–{{to}})",
			historyTarget: "{{name}} targeted sector {{n}}",
			historyResearch: "{{name}} researched \"{{topic}}\"",
			historyLocateOk: "{{name}} located Planet X!",
			historyLocateFail: "{{name}} failed to locate Planet X",
			historyTheories: "{{name}} submitted theories (sector {{list}})",
			historyConference: "X1 Conference held — rule revealed",
			errNotYourTurn: "Not your turn",
			errBadSurveyRange: "Range must stay within the visible sky",
			errCometRange: "Comet surveys must start and end on marked prime sectors",
			errNoTargets: "No target tokens left",
			errBadTarget: "Can only target a visible sector",
			errBadTopic: "Invalid research topic",
			errAlreadyResearched: "You already read this topic",
			errResearchConsecutive: "Cannot research twice in a row",
			errTooManyTheories: "At most {{n}} theories this time",
			errNoTokens: "No theory tokens of that object left",
			errSectorConfirmed: "That sector is already confirmed",
			errDuplicateSector: "Only one theory per sector per submission",
			errDuplicateTheory: "Duplicate theory on the same sector",
			errNoLastChance: "No last chance from your position",
			describeSurvey: "Survey {{obj}} (sectors {{from}}–{{to}}, advance {{cost}})",
			describeTarget: "Target sector {{n}}",
			describeResearch: "Research \"{{topic}}\"",
			describeLocate: "Attempt a locate: sector {{n}}",
			describeTheories: "Submit theories: sector {{list}}",
			describeSkipTheories: "Submit no theory this phase",
			describeAck: "Acknowledge the conference"
		}
	}
};
//#endregion
export { It as default };
