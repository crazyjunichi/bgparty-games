import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useI18nSettings as s, useT as c } from "@bgparty/sdk/i18n";
import { IconBot as l, IconExpand as u, IconLog as d, IconMirror as f, IconRotate as p } from "@bgparty/sdk/icons";
import { useWakeLock as m } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as h } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as g } from "@bgparty/sdk/ui/phase-banner";
import { SeatBadgedAvatar as _, seatName as ee } from "@bgparty/sdk/ui/player-strip";
import { Fragment as v, jsx as y, jsxs as b } from "react/jsx-runtime";
import { SheetView as te } from "@bgparty/sdk/sheet-view";
import { LogSheet as ne } from "@bgparty/sdk/ui/log-sheet";
import { OptionRadio as re, OptionSection as x } from "@bgparty/sdk/ui/game-options";
//#region src/games/kalypso/data.ts
var S = [
	"wood",
	"metal",
	"rubber",
	"seaweed"
], C = {
	wood: "games.kalypso.material.wood",
	metal: "games.kalypso.material.metal",
	rubber: "games.kalypso.material.rubber",
	seaweed: "games.kalypso.material.seaweed",
	plastic: "games.kalypso.material.plastic",
	wild: "games.kalypso.material.wild",
	boat: "games.kalypso.item.boat",
	island: "games.kalypso.island"
}, w = {
	house: {
		material: "wood",
		vp: 1,
		key: "games.kalypso.building.house",
		effect: "games.kalypso.effect.house"
	},
	cooper: {
		material: "wood",
		vp: 3,
		key: "games.kalypso.building.cooper",
		effect: "games.kalypso.effect.cooper"
	},
	shipyard: {
		material: "metal",
		vp: 1,
		key: "games.kalypso.building.shipyard",
		effect: "games.kalypso.effect.shipyard"
	},
	solar: {
		material: "metal",
		vp: 0,
		key: "games.kalypso.building.solar",
		effect: "games.kalypso.effect.solar"
	},
	scrapyard: {
		material: "rubber",
		vp: 3,
		key: "games.kalypso.building.scrapyard",
		effect: "games.kalypso.effect.scrapyard"
	},
	warehouse: {
		material: "rubber",
		vp: 1,
		key: "games.kalypso.building.warehouse",
		effect: "games.kalypso.effect.warehouse"
	},
	netWorkshop: {
		material: "seaweed",
		vp: 3,
		key: "games.kalypso.building.netWorkshop",
		effect: "games.kalypso.effect.netWorkshop"
	},
	greenhouse: {
		material: "seaweed",
		vp: 2,
		key: "games.kalypso.building.greenhouse",
		effect: "games.kalypso.effect.greenhouse"
	},
	monument: {
		material: "wood",
		vp: 11,
		key: "games.kalypso.building.monument",
		effect: "games.kalypso.effect.monument"
	},
	sanctuary: {
		material: "wood",
		vp: 11,
		key: "games.kalypso.building.sanctuary",
		effect: "games.kalypso.effect.sanctuary"
	}
}, ie = {
	wood: ["house", "cooper"],
	metal: ["shipyard", "solar"],
	rubber: ["scrapyard", "warehouse"],
	seaweed: ["netWorkshop", "greenhouse"]
}, T = [
	"sun",
	"rain",
	"dock",
	"drought",
	"hatches",
	"teeth",
	"storm"
], E = {
	sun: "games.kalypso.weather.sun",
	rain: "games.kalypso.weather.rain",
	dock: "games.kalypso.weather.dock",
	drought: "games.kalypso.weather.drought",
	hatches: "games.kalypso.weather.hatches",
	teeth: "games.kalypso.weather.teeth",
	storm: "games.kalypso.weather.storm"
}, ae = [
	"angler",
	"carpenter",
	"guardian",
	"salvager",
	"captain"
], D = {
	angler: "games.kalypso.expert.angler",
	carpenter: "games.kalypso.expert.carpenter",
	guardian: "games.kalypso.expert.guardian",
	salvager: "games.kalypso.expert.salvager",
	captain: "games.kalypso.expert.captain"
}, O = {
	angler: "games.kalypso.expertEffect.angler",
	carpenter: "games.kalypso.expertEffect.carpenter",
	guardian: "games.kalypso.expertEffect.guardian",
	salvager: "games.kalypso.expertEffect.salvager",
	captain: "games.kalypso.expertEffect.captain"
}, k = [
	"games.kalypso.goal.groups",
	"games.kalypso.goal.corners",
	"games.kalypso.goal.perimeter",
	"games.kalypso.goal.monuments",
	"games.kalypso.goal.enclosures",
	"games.kalypso.goal.lines",
	"games.kalypso.goal.sets",
	"games.kalypso.goal.empty",
	"games.kalypso.goal.full",
	"games.kalypso.goal.plastic"
], oe = [
	0,
	3,
	4,
	6,
	9
], se = [
	[
		3,
		6,
		9,
		12
	],
	[
		1,
		2,
		3,
		4
	],
	[
		0,
		0,
		0,
		0
	],
	[
		1,
		2,
		3,
		4
	],
	[
		6,
		8,
		10,
		12
	],
	[
		2,
		4,
		5,
		6
	],
	[
		5,
		8,
		10,
		12
	],
	[
		9,
		8,
		6,
		5
	],
	[
		5,
		11,
		18,
		26
	],
	[
		10,
		12,
		15,
		18
	]
], ce = {
	learning: [
		[
			1,
			1,
			1,
			1
		],
		[
			2,
			1,
			1,
			1
		],
		[
			2,
			2,
			2,
			1
		],
		[
			3,
			2,
			2,
			2
		]
	],
	easy: [
		[
			1,
			1,
			2,
			2
		],
		[
			2,
			2,
			1,
			1
		],
		[
			3,
			2,
			2,
			2
		],
		[
			4,
			2,
			3,
			2
		]
	],
	medium: [
		[
			1,
			2,
			2,
			2
		],
		[
			2,
			2,
			2,
			2
		],
		[
			3,
			3,
			3,
			2
		],
		[
			4,
			3,
			4,
			3
		]
	],
	hard: [
		[
			2,
			2,
			2,
			2
		],
		[
			3,
			2,
			2,
			2
		],
		[
			3,
			3,
			3,
			3
		],
		[
			4,
			4,
			4,
			4
		]
	]
}, le = [
	0,
	2,
	4,
	6,
	7,
	8,
	10,
	11,
	12,
	14,
	15,
	16,
	18,
	19,
	20
], A = [
	0,
	2,
	4,
	5,
	6,
	8,
	10,
	11,
	12,
	14,
	15,
	16,
	18,
	20
], ue = {
	W: "wood",
	M: "metal",
	R: "rubber",
	S: "seaweed",
	P: "plastic"
}, de = (/* @__PURE__ */ "SRWSM.MMWWR.SSMWW.RSMSM.WWSSP.MWSRP.MPPMS.WMWWP.WPSSM.PMSMR.MSRPR.WWRPM.RMRWP.RPMMM.MWSWM.MMSPS.WMSWP.RRWMW.SWWMR.RWRWW.MRRMP.MMSPM.PWMWP.PMMWR.WSSWR.MWPRM.RMMSP.WMWPR.MMWRR.RSPRS.PMPSW.RMMRW.SRPWR.SMWPR.WSWWM.WWWPP.WWMRW.PRRWW.SRRMS.RRWWR.PRRSM.SWSSW.SSPRM.RSSRW.RMWSP.MSPWR.MSMRS.MMWRR.WRRMW.WPWMW.RRMMR.RRRWP.SPWSM.MSPMM.SWWSW.WSPWR.SPSWS.WWRSS.PWSRS.PSWRP.WMSWR.RRPMW.RSRMS.SMRSP.WMPWW.PWPMM.RSSPM.RSRSR.SRPRW.WSWMM.SRRSM.MPMPR.RSRRP.SPSRS.MWRMW.SRRPW.SMSSR.RPRMR.MPMRM.MMWWP.RMWSS.RWSRW.RPRRS.WPPRW.MMSSP.MPPSS.RWWRR.RPSMW.WMRPM.SSWMR.PSPWM.PMSMW.MMPSS.PPPMM.SPWRR.PWMSS.RSRRM.WPSWS.RWSWW.RWPRS.SMSRS.MRPPW.RPMMW.RSPMM.PWMWS.PPRRS.WWSMR.PSSRS.PSWRS.MPMMW.PSSWR.RMMWP.PPSMS.RRMPW.MPPMW.PPSSM.SMPSS.PSMWM.MWSPR.SWRPP".split(".")).map((e) => [...e].map((e) => ue[e])), j = {
	20: {
		rings: [
			"19,0",
			"0,0",
			"5,8",
			"11,5",
			"14,11",
			"8,14",
			"19,19",
			"0,19"
		],
		barrels: [
			"7,1",
			"18,7",
			"1,12",
			"12,18"
		],
		fish: /* @__PURE__ */ "14,0.3,1.9,1.5,2.11,2.12,2.15,2.18,3.2,4.0,5.5,5.8,5.14,5.17,5.6,6.10,6.13,6.2,7.2,8.10,8.14,8.6,9.8,9.18,9.1,10.11,10.13,10.5,11.9,11.17,11.17,12.6,13.9,13.13,13.2,14.5,14.11,14.14,14.19,14.17,15.1,16.4,17.7,17.8,17.14,17.10,18.16,18.5,19".split(".")
	},
	40: {
		rings: [
			"12,2",
			"31,5",
			"5,8",
			"14,11",
			"28,14",
			"37,12",
			"8,14",
			"25,8",
			"11,25",
			"2,27",
			"8,34",
			"25,28",
			"34,31",
			"27,37",
			"31,25",
			"14,31"
		],
		barrels: [
			"7,1",
			"27,1",
			"18,7",
			"38,7",
			"1,12",
			"21,12",
			"32,18",
			"12,18",
			"7,21",
			"27,21",
			"38,27",
			"18,27",
			"21,32",
			"1,32",
			"12,38",
			"32,38"
		],
		fish: /* @__PURE__ */ "0,0.14,0.34,0.39,0.3,1.9,1.18,1.23,1.29,1.5,2.11,2.15,2.25,2.31,2.32,2.35,2.18,3.38,3.2,4.11,4.22,4.0,5.5,5.8,5.14,5.17,5.25,5.28,5.34,5.37,5.6,6.10,6.13,6.26,6.30,6.33,6.2,7.22,7.2,8.14,8.22,8.30,8.34,8.6,9.8,9.18,9.26,9.28,9.38,9.1,10.11,10.13,10.21,10.33,10.5,11.9,11.17,11.25,11.29,11.35,11.37,11.17,12.6,13.9,13.13,13.26,13.29,13.33,13.2,14.5,14.11,14.14,14.19,14.22,14.25,14.31,14.34,14.39,14.17,15.37,15.1,16.16,16.19,16.21,16.23,16.4,17.7,17.8,17.14,17.18,17.24,17.27,17.28,17.34,17.10,18.16,18.22,18.30,18.36,18.38,18.23,19.25,19.14,20.16,20.1,21.3,21.9,21.17,21.23,21.29,21.5,22.11,22.12,22.15,22.21,22.25,22.31,22.32,22.35,22.16,23.18,23.20,23.23,23.38,23.2,24.22,24.0,25.5,25.8,25.14,25.17,25.20,25.25,25.28,25.34,25.37,25.6,26.10,26.13,26.26,26.30,26.33,26.22,27.2,28.4,28.10,28.14,28.22,28.30,28.34,28.6,29.18,29.26,29.28,29.38,29.1,30.11,30.13,30.21,30.31,30.33,30.5,31.9,31.17,31.25,31.37,31.17,32.37,32.6,33.9,33.13,33.26,33.29,33.33,33.2,34.5,34.11,34.14,34.22,34.25,34.31,34.34,34.39,34.17,35.28,35.37,35.1,36.21,36.4,37.7,37.8,37.14,37.24,37.28,37.34,37.10,38.16,38.21,38.30,38.36,38.0,39.5,39.25,39.39,39".split(".")
	}
}, M = ({ x: e, y: t }) => `${e},${t}`, N = (e) => {
	let [t, n] = e.split(",").map(Number);
	return {
		x: t,
		y: n
	};
}, P = ({ x: e, y: t }) => [
	{
		x: e - 1,
		y: t
	},
	{
		x: e + 1,
		y: t
	},
	{
		x: e,
		y: t - 1
	},
	{
		x: e,
		y: t + 1
	}
], F = (e, t) => t.x >= 0 && t.y >= 0 && t.x < e.size && t.y < e.size, I = (e) => `${Math.floor(e.x / 4)},${Math.floor(e.y / 4)}`, L = (e, t, n) => Array.from({ length: n * n }, (r, i) => ({
	x: e + i % n,
	y: t + Math.floor(i / n)
})), R = (e) => L(e.x, e.y, e.kind === "monument" || e.kind === "sanctuary" ? 3 : 2), z = (e) => [...e.cells, ...e.boats.filter((e) => e.docked).flatMap((e) => e.cells.map((t) => ({
	...t,
	material: "boat",
	piece: e.id
})))], B = (e) => new Set([...e.cells, ...e.boats.flatMap((e) => e.cells)].map(M)), V = (e) => new Set([
	...e.buildings.flatMap(R),
	...e.gardens.flatMap((e) => e.cells),
	...e.nets.filter((e) => !e.stacked).flatMap((e) => e.cells)
].map(M));
function H(e, t) {
	let n = e.kind === "tile" ? de[e.tile] : e.kind === "scrap" ? [e.material, "plastic"] : e.kind === "barrel" ? ["wild"] : e.kind === "boat" ? [
		"boat",
		"boat",
		"boat"
	] : ["seaweed", "seaweed"], r = (e.kind === "tile" ? [
		[0, 0],
		[1, 0],
		[2, 0],
		[1, 1],
		[1, 2]
	] : n.map((e, t) => [t, 0])).map(([e, r], i) => {
		t.flip && (e = -e);
		for (let n = 0; n < t.rotation; n++) [e, r] = [-r, e];
		return {
			x: e,
			y: r,
			material: n[i]
		};
	}), i = Math.min(...r.map((e) => e.x)), a = Math.min(...r.map((e) => e.y));
	return r.map((e) => ({
		...e,
		x: e.x - i + t.x,
		y: e.y - a + t.y
	}));
}
function fe(e) {
	let t = !0;
	for (; t;) {
		t = !1;
		let n = new Set(z(e).map(M));
		for (let r of e.boats) !r.docked && r.cells.some((e) => P(e).some((e) => n.has(M(e)))) && (r.docked = !0, t = !0);
	}
}
function U(e) {
	let t = new Set(z(e).map(M)), n = z(e), r = Math.min(-1, ...n.map((e) => e.x - 1)), i = Math.max(e.size, ...n.map((e) => e.x + 1)), a = Math.min(-1, ...n.map((e) => e.y - 1)), o = Math.max(e.size, ...n.map((e) => e.y + 1)), s = /* @__PURE__ */ new Set(), c = [];
	for (let e = a; e <= o; e++) for (let n = r; n <= i; n++) {
		let l = {
			x: n,
			y: e
		}, u = M(l);
		if (t.has(u) || s.has(u)) continue;
		let d = [l];
		s.add(u);
		let f = !1;
		for (let e = 0; e < d.length; e++) {
			let n = d[e];
			(n.x === r || n.y === a || n.x === i || n.y === o) && (f = !0);
			for (let e of P(n)) {
				let n = M(e);
				e.x < r || e.y < a || e.x > i || e.y > o || t.has(n) || s.has(n) || (s.add(n), d.push(e));
			}
		}
		f || c.push(d);
	}
	return c;
}
function pe(e) {
	return [
		e.some((e) => e.y === 17 && e.x >= 18 && e.x <= 21),
		e.some((e) => e.x === 22 && e.y >= 18 && e.y <= 21),
		e.some((e) => e.y === 22 && e.x >= 18 && e.x <= 21),
		e.some((e) => e.x === 17 && e.y >= 18 && e.y <= 21)
	].flatMap((e, t) => e ? [t] : []);
}
function W(e, t, n, r = {}) {
	let i = H(t, n), a = B(e), o = new Set(z(e).map(M)), s = V(e);
	if (!i.some((t) => F(e, t))) return !1;
	if (t.kind === "garden") {
		let t = i.some((t) => e.cells.some((e) => M(e) === M(t) && e.material === "island")), n = [18, 21].some((e) => i.every((t) => t.x === e && (t.y === 19 || t.y === 20)));
		return i.every((e) => o.has(M(e)) && !s.has(M(e))) && (!t || n);
	}
	if (t.kind === "net") {
		let t = I(i[0]);
		if (!i.every((n) => F(e, n) && I(n) === t) || e.nets.some((e) => e.zone === t)) return !1;
		let n = e.boats.filter((e) => e.cells.some((e) => I(e) === t)), c = z(e).some((e) => I(e) === t && e.material !== "island");
		if (!n.length && !(r.experts?.includes("angler") && c)) return !1;
		let l = r.closed ?? new Set(U(e).flat().map(M));
		if (i.some((e) => l.has(M(e)))) return !1;
		let u = (n) => n.every((n) => F(e, n) && I(n) === t && !l.has(M(n)) && !a.has(M(n)) && !s.has(M(n)) && !e.rings.includes(M(n)) && !e.barrels.includes(M(n)));
		if (u(i)) return !0;
		let d = N(t), f = L(d.x * 4, d.y * 4, 4).some((e) => u([e, {
			x: e.x + 1,
			y: e.y
		}]) || u([e, {
			x: e.x,
			y: e.y + 1
		}])), p = n.some((e) => i.some((t) => e.cells.some((e) => M(e) === M(t)))), m = r.experts?.includes("angler") && i.some((e) => o.has(M(e)));
		return !f && (!!p || !!m);
	}
	return i.some((e) => a.has(M(e))) ? !1 : t.kind === "boat" ? !0 : r.initial ? e.size === 20 ? i.some((e) => e.x >= 9 && e.x <= 10 && e.y >= 9 && e.y <= 10) : pe(i).some((e) => !r.usedSides?.includes(e)) : i.some((e) => P(e).some((e) => o.has(M(e))));
}
function me(e, t, n = {}, r = Infinity) {
	t.kind === "net" && !n.closed && (n = {
		...n,
		closed: new Set(U(e).flat().map(M))
	});
	let i = t.kind === "boat" || t.kind === "net" ? L(0, 0, e.size) : z(e), a = /* @__PURE__ */ new Set();
	if (n.initial && e.size === 20) for (let e of L(6, 6, 8)) a.add(M(e));
	for (let e of i) for (let t = -3; t <= 1; t++) for (let n = -3; n <= 1; n++) a.add(`${e.x + n},${e.y + t}`);
	let o = [];
	for (let i of a) for (let a of n.orientation ? [n.orientation.rotation] : t.kind === "barrel" ? [0] : [
		0,
		1,
		2,
		3
	]) for (let s of n.orientation ? [n.orientation.flip] : t.kind === "tile" ? [!1, !0] : [!1]) {
		let c = {
			...N(i),
			rotation: a,
			flip: s
		};
		if (W(e, t, c, n) && (o.push(c), o.length >= r)) return o;
	}
	return o;
}
function he(e, t, n, r, i, a, o) {
	let s = i === "monument" || i === "sanctuary", c = L(n, r, s ? 3 : 2), l = V(e), u = new Map(z(e).map((e) => [M(e), e.material]));
	return i === "sanctuary" && !o.includes("guardian") || !s && w[i].material !== a || !c.some((e) => t.includes(M(e))) || c.some((e) => !u.has(M(e)) || u.get(M(e)) === "island" || l.has(M(e))) ? !1 : c.filter((e) => u.get(M(e)) === a || u.get(M(e)) === "wild").length >= (s ? 5 : 3);
}
function ge(e, t, n) {
	let r = /* @__PURE__ */ new Set(), i = [];
	for (let e of t) {
		let t = N(e);
		for (let e = -2; e <= 0; e++) for (let n = -2; n <= 0; n++) r.add(`${t.x + n},${t.y + e}`);
	}
	for (let a of r) {
		let r = N(a);
		for (let a of Object.keys(w)) for (let o of S) he(e, t, r.x, r.y, a, o, n) && i.push({
			...r,
			kind: a,
			material: o
		});
	}
	return i;
}
function _e(e, t, n) {
	let r = e.boats.find((e) => e.id === t);
	if (!r || r.docked) return !1;
	let i = Math.min(...r.cells.map((e) => e.x)), a = Math.min(...r.cells.map((e) => e.y));
	if (Math.max(Math.abs(n.x - i), Math.abs(n.y - a)) > 4) return !1;
	let o = new Set(r.cells.map(I));
	return H({
		id: 0,
		kind: "boat"
	}, n).some((e) => o.has(I(e))) && W({
		...e,
		boats: e.boats.filter((e) => e.id !== t)
	}, {
		id: 0,
		kind: "boat"
	}, n);
}
function G(e) {
	let t = z(e).filter((t) => F(e, t)), n = B(e), r = V(e), i = e.size / 4, a = Array.from({ length: i * i }, (e, t) => ({
		x: t % i,
		y: Math.floor(t / i)
	})), o = new Set(t.map(I)), s = a.filter((e) => L(e.x * 4, e.y * 4, 4).every((e) => n.has(M(e)))), c = z(e).filter((e) => e.material === "plastic" && !r.has(M(e))), l = new Set(c.map(I)), u = /* @__PURE__ */ new Set(), d = [], f = [], p = e.buildings.filter((e) => e.kind !== "monument" && e.kind !== "sanctuary");
	for (let t of p) {
		let n = R(t).filter((t) => F(e, t)).map((e) => N(I(e)));
		for (let e of n) (e.x === 0 || e.x === i - 1) && (e.y === 0 || e.y === i - 1) && u.add(M(e));
		n.some((e) => e.x === 0 || e.y === 0 || e.x === i - 1 || e.y === i - 1) ? d.push(t) : f.push(t);
	}
	let m = 0, h = /* @__PURE__ */ new Set();
	for (let e of p) {
		if (h.has(e.id)) continue;
		let t = [e];
		h.add(e.id);
		for (let n = 0; n < t.length; n++) {
			let r = new Set(R(t[n]).flatMap(P).map(M));
			for (let n of p) !h.has(n.id) && n.material === e.material && R(n).some((e) => r.has(M(e))) && (h.add(n.id), t.push(n));
		}
		t.length >= 2 && m++;
	}
	let g = 0;
	for (let e = 0; e < i; e++) Array.from({ length: i }, (t, n) => `${e},${n}`).every((e) => o.has(e)) && g++, Array.from({ length: i }, (t, n) => `${n},${e}`).every((e) => o.has(e)) && g++;
	let _ = U(e).filter((t) => t.some((t) => j[e.size].fish.includes(M(t)) && !n.has(M(t)))).length;
	return {
		groups: m,
		corners: u.size,
		perimeter: d.length,
		inside: f.length,
		monuments: e.buildings.length - p.length,
		enclosures: _,
		lines: g,
		sets: Math.min(...S.map((e) => p.filter((t) => t.material === e).length)),
		empty: i * i - o.size,
		full: s.length,
		clean: [...o].filter((e) => !l.has(e)).length,
		plastic: c.length,
		residents: e.buildings.filter((e) => e.resident).length,
		buildings: p.length
	};
}
//#endregion
//#region src/games/kalypso/meta.ts
var ve = {
	id: "kalypso",
	tier: "alpha",
	mechanics: [
		"drafting",
		"tile-placement",
		"engine-building"
	],
	interactionTags: ["cooperative"],
	nameKey: "games.kalypso.name",
	descKey: "games.kalypso.desc",
	rulesKey: "games.kalypso.rules",
	icon: "🛟",
	iconImg: "games/kalypso.webp",
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [
		2,
		3,
		4
	],
	playerRange: (e) => e?.mode === "solo" ? {
		min: 1,
		max: 1
	} : {
		min: 2,
		max: 4
	},
	accent: "#087e8b",
	releasedAt: "2026-10-29T13:06:21+08:00",
	search: {
		py: "ka li pu suo",
		init: "klps"
	},
	hotseat: "cover"
}, ye = t.enum([
	"wood",
	"metal",
	"rubber",
	"seaweed",
	"plastic",
	"wild",
	"boat",
	"island"
]), be = t.enum([
	"wood",
	"metal",
	"rubber",
	"seaweed"
]), xe = t.enum([
	"house",
	"cooper",
	"shipyard",
	"solar",
	"scrapyard",
	"warehouse",
	"netWorkshop",
	"greenhouse",
	"monument",
	"sanctuary"
]), Se = t.enum([
	"sun",
	"rain",
	"dock",
	"drought",
	"hatches",
	"teeth",
	"storm"
]), Ce = t.enum([
	"angler",
	"carpenter",
	"guardian",
	"salvager",
	"captain"
]), we = t.object({
	mode: t.enum([
		"competitive",
		"cooperative",
		"solo"
	]).catch("competitive"),
	difficulty: t.enum([
		"learning",
		"easy",
		"medium",
		"hard"
	]).catch("learning")
}).default({
	mode: "competitive",
	difficulty: "learning"
}), Te = t.object({
	x: t.int().min(-250).max(290),
	y: t.int().min(-250).max(290)
}), Ee = Te.extend({
	rotation: t.int().min(0).max(3),
	flip: t.boolean()
}), K = t.object({
	x: t.int(),
	y: t.int(),
	material: ye,
	piece: t.int()
}), De = t.object({
	id: t.int(),
	x: t.int(),
	y: t.int(),
	kind: xe,
	material: be,
	resident: t.boolean(),
	builtRound: t.int()
}), Oe = t.object({
	id: t.int(),
	cells: t.array(Te),
	docked: t.boolean(),
	owner: t.string()
}), ke = t.object({
	size: t.int(),
	cells: t.array(K),
	buildings: t.array(De),
	boats: t.array(Oe),
	gardens: t.array(t.object({
		id: t.int(),
		cells: t.array(Te)
	})),
	nets: t.array(t.object({
		id: t.int(),
		cells: t.array(Te),
		zone: t.string(),
		stacked: t.boolean()
	})),
	rings: t.array(t.string()),
	barrels: t.array(t.string()),
	fishClaimed: t.array(t.string()),
	enclosedFish: t.array(t.string())
}), Ae = t.enum([
	"tile",
	"scrap",
	"barrel",
	"boat",
	"garden",
	"net",
	"fish",
	"house",
	"expert",
	"catch"
]), je = t.object({
	id: t.int(),
	kind: Ae,
	tile: t.int().optional(),
	material: be.optional(),
	value: t.int().optional(),
	choices: t.array(t.int()).optional(),
	unlimited: t.boolean().optional()
}), Me = t.object({
	barrel: t.int(),
	garden: t.int(),
	fish: t.int(),
	survivor: t.int(),
	scrap: t.int(),
	boat: t.int(),
	net: t.int(),
	house: t.int()
}), Ne = t.object({
	weather: Se,
	paid: Me,
	complete: t.boolean(),
	round: t.int()
}), Pe = t.object({
	buildings: t.int(),
	monuments: t.int(),
	gardens: t.int(),
	survivors: t.int(),
	fish: t.int(),
	solar: t.int(),
	goals: t.int(),
	weather: t.int(),
	total: t.int()
}), Fe = t.object({
	rid: t.string(),
	board: t.int(),
	hand: t.array(t.int()),
	jobs: t.array(je),
	recent: t.array(t.string()),
	ready: t.boolean(),
	drafted: t.boolean(),
	initialDone: t.boolean(),
	initialSide: t.int().nullable(),
	survivors: t.int(),
	fishCount: t.int(),
	events: t.array(Ne),
	weatherChosen: t.boolean(),
	availableWeather: t.array(Se),
	score: Pe
}), Ie = t.object({
	config: we,
	phase: t.enum([
		"initial",
		"weather",
		"expand",
		"captain",
		"ended"
	]),
	round: t.int(),
	step: t.int(),
	players: t.array(Fe),
	boards: t.array(ke),
	goals: t.array(t.int()),
	experts: t.array(Ce),
	islandSurvivors: t.int(),
	fish: t.int(),
	gardenBonus: t.int(),
	solarBonus: t.int(),
	soloDiscard: t.array(t.int()),
	supply: t.object({
		tiles: t.int(),
		scraps: t.int(),
		barrels: t.int(),
		boats: t.int(),
		gardenNets: t.int(),
		monuments: t.int(),
		survivors: t.int(),
		buildings: t.record(be, t.int()),
		fish: t.int()
	}),
	captainMoved: t.array(t.int()),
	won: t.boolean(),
	reason: t.enum([
		"weather",
		"housing",
		"fish",
		"gardens",
		"goals"
	]).nullable(),
	log: t.array(t.object({
		rid: t.string(),
		kind: t.enum([
			"place",
			"build",
			"rescue",
			"fish",
			"weather",
			"round",
			"expert",
			"donate",
			"move"
		]),
		n: t.int(),
		detail: t.string()
	}))
}), Le = t.object({
	jobs: t.array(je),
	fish: t.array(t.int()),
	chosenWeather: Se.nullable()
}), Re = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("choose"),
		tile: t.int().min(0).max(119)
	}),
	t.object({
		type: t.literal("weather"),
		weather: Se
	}),
	Ee.extend({
		type: t.literal("place"),
		job: t.int()
	}),
	Te.extend({
		type: t.literal("build"),
		kind: xe,
		material: be,
		reverse: t.boolean().optional(),
		rings: t.array(t.string()).max(3).optional()
	}),
	t.object({
		type: t.literal("donate"),
		job: t.int().nullable(),
		to: t.string()
	}),
	t.object({
		type: t.literal("house"),
		job: t.int(),
		building: t.int()
	}),
	t.object({
		type: t.literal("expert"),
		job: t.int(),
		expert: Ce
	}),
	t.object({
		type: t.literal("catch"),
		job: t.int(),
		returnIndex: t.int().min(0)
	}),
	t.object({
		type: t.literal("discard"),
		job: t.int()
	}),
	Ee.extend({
		type: t.literal("move"),
		boat: t.int()
	}),
	t.object({ type: t.literal("ready") })
]), q = (e) => e.config.mode !== "competitive", J = () => ({ code: "games.kalypso.errAction" }), ze = () => ({
	barrel: 0,
	garden: 0,
	fish: 0,
	survivor: 0,
	scrap: 0,
	boat: 0,
	net: 0,
	house: 0
}), Be = () => ({
	buildings: 0,
	monuments: 0,
	gardens: 0,
	survivors: 0,
	fish: 0,
	solar: 0,
	goals: 0,
	weather: 0,
	total: 0
}), Ve = (e, t) => e.boards[t.board];
function He(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function Ue(e, t, n, r = 1, i = "") {
	e.log.push({
		rid: t.rid,
		kind: n,
		n: r,
		detail: i
	});
}
function We(e) {
	return {
		size: e,
		cells: e === 40 ? L(18, 18, 4).map((e) => ({
			...e,
			material: "island",
			piece: 0
		})) : [],
		buildings: [],
		boats: [],
		gardens: [],
		nets: [],
		rings: [...j[e].rings],
		barrels: [...j[e].barrels],
		fishClaimed: [],
		enclosedFish: []
	};
}
function Y(e, t, n, r = {}) {
	t.jobs.push({
		id: ++e.serial,
		kind: n,
		...r
	});
}
function X(e, t, n, r = !1) {
	if (n === "tile") {
		let r = e.tileBag.shift();
		r !== void 0 && Y(e, t, n, { tile: r });
		return;
	}
	if (n === "scrap") {
		let r = e.scrapBag.shift();
		r && Y(e, t, n, { material: r });
		return;
	}
	if (n === "barrel" || n === "boat") {
		let i = n === "barrel" ? "barrels" : "boats";
		e.supply[i] > 0 && (e.supply[i]--, Y(e, t, n, { unlimited: r }));
		return;
	}
	if (n === "garden" || n === "net") {
		e.supply.gardenNets > 0 && (e.supply.gardenNets--, Y(e, t, n));
		return;
	}
	if (n === "fish") {
		let n = e.fishBag.shift();
		n !== void 0 && (n === -1 ? X(e, t, "barrel") : Y(e, t, "fish", { value: n }));
		return;
	}
	Y(e, t, n);
}
function Ge(e, t, n) {
	let r = e.fishBag.splice(0, n + +!!e.experts.includes("captain"));
	if (e.experts.includes("captain") && r.length) Y(e, t, "catch", { choices: r });
	else for (let n of r) n === -1 ? X(e, t, "barrel") : Y(e, t, "fish", { value: n });
}
function Ke(e, t, n) {
	switch (e) {
		case "sun": return t ? { house: 1 } : n && n.fish > 0 ? { fish: 2 } : { survivor: 1 };
		case "rain": return t ? { barrel: 2 } : {
			barrel: 1,
			garden: 1
		};
		case "dock": return {
			fish: 1,
			garden: 1
		};
		case "drought": return t ? {
			garden: 1,
			barrel: 1
		} : {
			survivor: 1,
			barrel: 1
		};
		case "hatches": return { scrap: t ? 2 : 3 };
		case "teeth": return t ? {
			net: 1,
			boat: 1
		} : {
			survivor: 1,
			boat: 1
		};
		case "storm": return { boat: t ? 1 : 2 };
	}
}
function qe(e, t) {
	return e.weather === "sun" && !t ? e.paid.survivor >= 1 || e.paid.fish >= 2 : Object.entries(Ke(e.weather, t, e.paid)).every(([t, n]) => e.paid[t] >= n);
}
function Je(e, t) {
	return e.events.find((e) => e.round === t);
}
function Ye(e, t, n) {
	if (e.complete) return !1;
	if (e.weather === "sun" && !n) return t === "survivor" && e.paid.survivor < 1 || t === "fish" && e.paid.fish < 2;
	let r = Ke(e.weather, n, e.paid)[t] ?? 0;
	return e.paid[t] < r;
}
function Xe(e, t) {
	let n = Je(t, e.round);
	if (n && !n.complete && qe(n, q(e))) switch (n.complete = !0, Ue(e, t, "weather", 1, n.weather), n.weather) {
		case "sun":
			q(e) && e.players.every((t) => Je(t, e.round)?.complete) && e.solarBonus++;
			break;
		case "rain":
			q(e) && e.players.every((t) => Je(t, e.round)?.complete) && e.gardenBonus++;
			break;
		case "dock":
			q(e) && X(e, t, "tile");
			break;
		case "drought":
			X(e, t, "scrap"), X(e, t, "scrap");
			break;
		case "hatches":
			X(e, t, "boat", !0);
			break;
		case "teeth":
			Ge(e, t, 2);
			break;
		case "storm": X(e, t, "barrel"), q(e) || X(e, t, "barrel");
	}
}
function Ze(e, t) {
	e.supply.survivors !== 0 && (e.supply.survivors--, q(e) ? (e.islandSurvivors++, e.experts.length < ae.length && Y(e, t, "expert")) : t.survivors++, Ue(e, t, "rescue"));
}
function Qe(e, t, n) {
	let r = Ve(e, t), i = new Set(n.map(M)), a = r.rings.filter((e) => i.has(e)), o = r.barrels.filter((e) => i.has(e));
	r.rings = r.rings.filter((e) => !i.has(e)), r.barrels = r.barrels.filter((e) => !i.has(e));
	for (let n of a) Ze(e, t);
	for (let n of o) Y(e, t, "barrel");
}
function $e(e, t) {
	let n = Ve(e, t), r = B(n), i = U(n).flat().filter((e) => F(n, e) && !r.has(M(e)));
	Qe(e, t, i);
	let a = i.map(M).filter((e) => j[n.size].fish.includes(e) && !n.fishClaimed.includes(e));
	n.fishClaimed.push(...a), n.enclosedFish.push(...a), q(e) && (e.fish += a.length), a.length && Ue(e, t, "fish", a.length);
}
function et(e, t) {
	e.jobs = e.jobs.filter((e) => e.id !== t);
}
function tt(e) {
	return e.players.flatMap((e) => e.initialSide === null ? [] : [e.initialSide]);
}
function nt(e, t) {
	return {
		initial: e.phase === "initial" && !t.initialDone,
		usedSides: tt(e),
		experts: e.experts
	};
}
function rt(e) {
	let t = e.solarBonus;
	return A[Math.min(t, A.length - 1)];
}
function it(e, t) {
	return !q(e) || t.unlimited === !0 || e.boards[0].boats.length < rt(e);
}
function at(e, t, n, r) {
	let i = Ve(e, t), a = nt(e, t);
	if (![
		"tile",
		"scrap",
		"barrel",
		"boat",
		"garden",
		"net"
	].includes(n.kind) || !W(i, n, r, a) || n.kind === "boat" && !it(e, n)) return !1;
	let o = H(n, r), s = ++e.serial;
	if (et(t, n.id), n.kind === "garden") i.gardens.push({
		id: s,
		cells: o.map(({ x: e, y: t }) => ({
			x: e,
			y: t
		}))
	});
	else if (n.kind === "net") {
		let n = I(o[0]), r = B(i), a = V(i), c = o.some((e) => r.has(M(e)) || a.has(M(e)) || i.rings.includes(M(e)) || i.barrels.includes(M(e)));
		i.nets.push({
			id: s,
			cells: o.map(({ x: e, y: t }) => ({
				x: e,
				y: t
			})),
			zone: n,
			stacked: c
		});
		let l = j[i.size].fish.filter((e) => I(N(e)) === n && !r.has(e) && !i.fishClaimed.includes(e));
		i.fishClaimed.push(...l), Ge(e, t, l.length), Ue(e, t, "fish", l.length);
	} else {
		n.kind === "boat" ? i.boats.push({
			id: s,
			cells: o.map(({ x: e, y: t }) => ({
				x: e,
				y: t
			})),
			docked: !1,
			owner: t.rid
		}) : i.cells.push(...o.map((e) => ({
			...e,
			piece: s
		})));
		for (let e of i.nets) !e.stacked && e.cells.some((e) => o.some((t) => M(e) === M(t))) && (e.stacked = !0);
		fe(i), Qe(e, t, o), t.recent = o.map(M), a.initial && (q(e) && (t.initialSide = pe(o).find((e) => !a.usedSides.includes(e)) ?? null), t.initialDone = !0), $e(e, t);
	}
	return Ue(e, t, "place", o.length, n.kind), !0;
}
function ot(e, t) {
	if ((q(e) ? e.islandSurvivors : t.survivors) <= 0) return [];
	let n = Je(t, e.round), r = q(e) && n?.weather === "sun" && !n.complete;
	return Ve(e, t).buildings.filter((t) => !t.resident && t.kind !== "monument" && t.kind !== "sanctuary" && (t.kind !== "house" || r && t.builtRound === e.round)).map((e) => e.id);
}
function st(e, t, n) {
	switch (n) {
		case "house":
			ot(e, t).length && X(e, t, "house");
			break;
		case "cooper":
			X(e, t, "barrel");
			break;
		case "shipyard":
			X(e, t, "boat");
			break;
		case "scrapyard":
			X(e, t, "scrap"), X(e, t, "scrap");
			break;
		case "warehouse":
			X(e, t, "tile");
			break;
		case "netWorkshop":
			X(e, t, "net");
			break;
		case "greenhouse":
			X(e, t, "garden");
			break;
		case "solar": q(e) && e.solarBonus++;
	}
}
function ct(e) {
	e.phase = "weather";
	for (let t of e.players) t.ready = !1, t.drafted = !1, t.recent = [], t.extraTaken = !1, t.chosenWeather = null;
	if (q(e)) {
		let t = e.forecast[e.round - 1];
		for (let n of e.players) n.events.push({
			weather: t,
			paid: ze(),
			complete: !1,
			round: e.round
		});
		lt(e);
	}
}
function lt(e) {
	e.phase = "expand", e.step = 1, e.soloDiscard = [];
	for (let t of e.players) t.ready = !1, t.drafted = !1, t.hand = e.tileBag.splice(0, e.config.mode === "solo" ? 2 : 5);
}
function ut(e) {
	if (e.round === 4) {
		e.won = !q(e) || e.goals.every((t) => mt(e.boards[0], t, e.players.length).met), e.reason = q(e) && !e.won ? "goals" : null, e.phase = "ended";
		return;
	}
	if (e.round++, q(e)) {
		let t = ce[e.config.difficulty][e.players.length - 1][e.round - 1], n = Math.min(t, e.supply.survivors);
		e.islandSurvivors += n, e.supply.survivors -= n;
	}
	Ue(e, e.players[0], "round", e.round), ct(e);
}
function dt(e) {
	if (q(e)) {
		let t = null, n = G(e.boards[0]).residents, r = e.boards[0].gardens.length + e.gardenBonus;
		if (e.players.some((t) => !Je(t, e.round)?.complete) ? t = "weather" : e.islandSurvivors > 0 ? t = "housing" : e.fish < n * 2 ? t = "fish" : (e.fish -= n * 2, n > le[Math.min(r, le.length - 1)] && (t = "gardens")), t) {
			e.reason = t, e.phase = "ended", e.won = !1;
			return;
		}
		if (e.experts.includes("captain") && e.boards[0].boats.some((e) => !e.docked)) {
			e.phase = "captain", e.captainMoved = [];
			for (let t of e.players) t.ready = !1;
			return;
		}
	}
	ut(e);
}
function ft(e) {
	if (!e.players.every((e) => e.ready)) return;
	if (e.phase === "initial") {
		e.tileBag = He(e, [...e.tileBag, ...e.initialReturns]), e.initialReturns = [], ct(e);
		return;
	}
	if (e.phase === "captain") {
		ut(e);
		return;
	}
	if (e.phase !== "expand") return;
	let t = e.config.mode === "solo", n = t ? 5 : 4, r = e.experts.includes("salvager");
	if (e.step < n) {
		if (t) e.players[0].hand = e.tileBag.splice(0, 2);
		else {
			let t = e.players.map((e) => e.hand), n = e.round % 2 == 1 ? 1 : -1;
			e.players.forEach((r, i) => {
				r.hand = t[(i - n + e.players.length) % e.players.length];
			});
		}
		e.step++;
		for (let t of e.players) t.ready = !1, t.drafted = !1, t.recent = [];
		return;
	}
	if (r && e.step === n) {
		e.step++;
		for (let n of e.players) n.ready = !1, n.drafted = !1, n.recent = [], t && (n.hand = e.soloDiscard.slice(-1));
		return;
	}
	for (let t of e.players) t.hand = [], t.recent = [];
	dt(e);
}
function pt(e, t, n) {
	return n.kind === "house" ? !0 : n.kind === "expert" ? e.experts.length === ae.length : n.kind === "boat" && !it(e, n) ? !0 : n.kind === "fish" || n.kind === "catch" ? !1 : me(Ve(e, t), n, nt(e, t), 1).length === 0;
}
function mt(e, t, n) {
	let r = G(e), i = se[t][n - 1], a = [
		r.groups,
		r.corners,
		r.perimeter,
		r.monuments,
		r.enclosures,
		r.lines,
		r.sets,
		r.empty,
		r.full,
		r.plastic
	], o = [
		r.groups * 2,
		[
			0,
			3,
			8,
			12,
			18
		][r.corners],
		r.perimeter * 2,
		r.monuments * 4,
		r.enclosures * 2,
		r.lines * 2,
		r.sets * 3,
		r.empty * 2,
		r.full * 4,
		r.clean * 2
	];
	return {
		value: a[t],
		target: t === 2 ? r.inside + 1 : i,
		met: t === 9 ? r.plastic <= i : t === 2 ? r.perimeter > r.inside : a[t] >= i,
		vp: o[t]
	};
}
function ht(e, t, n, r, i) {
	let a = Be(), o = B(e), s = G(e);
	a.buildings = e.buildings.filter((e) => e.kind !== "monument" && e.kind !== "sanctuary").reduce((e, t) => e + w[t.kind].vp, 0), a.monuments = s.monuments * 11, a.survivors = s.residents * 3 + n * 2, a.fish = t.reduce((e, t) => e + t, 0) + e.enclosedFish.filter((e) => !o.has(e)).length, a.gardens = e.gardens.reduce((t, n) => {
		let r = new Set(n.cells.flatMap(P).map(M));
		return t + Math.min(5, e.buildings.filter((e) => e.kind !== "monument" && e.kind !== "sanctuary" && R(e).some((e) => r.has(M(e)))).length);
	}, 0), a.solar = e.buildings.filter((e) => e.kind === "solar").reduce((e, t) => {
		let n = new Set(R(t).map(M)), r = new Set(R(t).flatMap(P).map(M).filter((e) => !n.has(e)));
		return e + Math.min(7, [...r].filter((e) => !o.has(e)).length);
	}, 0), a.goals = i.reduce((t, n) => t + mt(e, n, 1).vp, 0);
	for (let t of r) t.complete ? (t.weather === "sun" && (a.weather += e.buildings.filter((e) => e.kind === "solar").length), t.weather === "rain" && (a.weather += e.gardens.length), t.weather === "dock" && (a.weather += n)) : a.weather -= t.weather === "hatches" ? (3 - t.paid.scrap) * 2 : t.weather === "storm" ? (2 - t.paid.boat) * 4 : t.weather === "teeth" ? 6 : 3;
	return a.total = Object.values(a).reduce((e, t) => e + t, 0), a;
}
var gt = {
	meta: ve,
	saveCompatibility: { version: "1" },
	schemas: {
		action: Re,
		config: we,
		publicView: Ie,
		privateView: Le
	},
	setup(e, t, n) {
		let r = {
			config: e,
			phase: "initial",
			round: 1,
			step: 0,
			players: [],
			boards: [],
			goals: [],
			experts: [],
			islandSurvivors: 0,
			fish: 0,
			gardenBonus: 0,
			solarBonus: 0,
			soloDiscard: [],
			captainMoved: [],
			won: !1,
			reason: null,
			log: [],
			seed: n,
			cursor: 0,
			serial: 0,
			tileBag: [],
			scrapBag: [],
			fishBag: [],
			forecast: [],
			initialReturns: [],
			supply: {
				barrels: 40,
				boats: 36,
				gardenNets: 48,
				monuments: 15,
				survivors: 48,
				buildings: {
					wood: 32,
					metal: 32,
					rubber: 36,
					seaweed: 32
				}
			}
		};
		return r.tileBag = He(r, Array.from({ length: 120 }, (e, t) => t)), r.scrapBag = He(r, S.flatMap((e) => Array.from({ length: 15 }, () => e))), r.fishBag = He(r, [
			...Array(38).fill(1),
			...Array(12).fill(2),
			...[
				,
				,
				,
			].fill(0),
			...[
				,
				,
				,
			].fill(3),
			...[
				,
				,
				,
				,
			].fill(-1)
		]), r.forecast = He(r, T), r.goals = q(r) ? [He(r, oe)[0], He(r, [
			1,
			2,
			5,
			7,
			8
		])[0]] : He(r, Array.from({ length: 10 }, (e, t) => t)).slice(0, 2), r.boards = q(r) ? [We(40)] : t.map(() => We(20)), r.supply.barrels -= q(r) ? 16 : t.length * 4, r.players = t.map((e, t) => ({
			rid: e,
			board: q(r) ? 0 : t,
			hand: r.tileBag.splice(0, 2),
			jobs: [],
			recent: [],
			ready: !1,
			drafted: !1,
			initialDone: !1,
			initialSide: null,
			survivors: q(r) ? 0 : 2,
			fish: [],
			events: [],
			chosenWeather: null,
			availableWeather: [...T],
			extraTaken: !1
		})), q(r) && (r.islandSurvivors = ce[e.difficulty][t.length - 1][0]), r.supply.survivors -= q(r) ? r.islandSurvivors : t.length * 2, { state: r };
	},
	reduce(e, t, { by: n }) {
		if (e.phase === "ended" || !e.players.some((e) => e.rid === n)) return J();
		let r = structuredClone(e), i = r.players.find((e) => e.rid === n), a = Ve(r, i);
		if (t.type === "weather") {
			if (r.phase !== "weather" || !i.availableWeather.includes(t.weather) || i.chosenWeather) return J();
			if (i.chosenWeather = t.weather, r.players.every((e) => e.chosenWeather !== null)) {
				let e = r.round % 2 == 1 ? -1 : 1, t = r.players.map((e) => e.chosenWeather);
				r.players.forEach((n, i) => {
					n.events.push({
						weather: t[(i - e + r.players.length) % r.players.length],
						paid: ze(),
						complete: !1,
						round: r.round
					}), n.availableWeather = n.availableWeather.filter((e) => e !== n.chosenWeather);
				}), lt(r);
			}
			return { state: r };
		}
		if (r.phase === "weather" || i.ready) return J();
		if (t.type === "ready") {
			if (i.jobs.length || r.phase === "initial" && !i.initialDone) return J();
			if (r.phase === "expand" && !i.drafted) {
				let e = r.config.mode === "solo" ? 5 : 4;
				if (!(r.experts.includes("salvager") && r.step > e)) return J();
				i.hand = [];
			}
			return i.ready = !0, ft(r), { state: r };
		}
		if (t.type === "move") {
			if (r.phase !== "captain") return J();
			let e = a.boats.find((e) => e.id === t.boat);
			if (!e || e.owner !== n || e.docked || r.captainMoved.includes(e.id)) return J();
			let o = H({
				id: 0,
				kind: "boat"
			}, t);
			if (!_e(a, e.id, t)) return J();
			let s = new Set(e.cells.map(I));
			e.cells = o.map(({ x: e, y: t }) => ({
				x: e,
				y: t
			})), r.captainMoved.push(e.id), fe(a), Qe(r, i, o), $e(r, i);
			let c = B(a), l = new Set(e.cells.map(I));
			return a.nets = a.nets.filter((e) => {
				let t = e.stacked && s.has(e.zone) && !l.has(e.zone) && !j[a.size].fish.some((t) => I(N(t)) === e.zone && !c.has(t));
				return t && r.supply.gardenNets++, !t;
			}), Ue(r, i, "move"), { state: r };
		}
		if (t.type === "choose") {
			if (r.phase === "captain" || i.drafted || i.jobs.length || !i.hand.includes(t.tile)) return J();
			let e = i.hand.filter((e) => e !== t.tile);
			return r.phase === "initial" ? (r.initialReturns.push(...e), i.hand = []) : r.config.mode === "solo" ? (r.step <= 5 && r.soloDiscard.push(...e), i.hand = []) : i.hand = e, i.drafted = !0, Y(r, i, "tile", { tile: t.tile }), { state: r };
		}
		if (t.type === "build") {
			if (!he(a, i.recent, t.x, t.y, t.kind, t.material, r.experts)) return J();
			let e = t.kind === "monument" || t.kind === "sanctuary";
			if (e ? r.supply.monuments <= 0 : r.supply.buildings[t.material] <= 0) return J();
			e ? r.supply.monuments-- : r.supply.buildings[t.material]--;
			let n = {
				id: ++r.serial,
				x: t.x,
				y: t.y,
				kind: t.kind,
				material: t.material,
				resident: !1,
				builtRound: r.round
			};
			if (a.buildings.push(n), Ue(r, i, "build", 1, t.kind), t.kind === "sanctuary") {
				let e = t.rings ?? [];
				if (new Set(e).size !== e.length || e.some((e) => !a.rings.includes(e))) return J();
				a.rings = a.rings.filter((t) => !e.includes(t));
			}
			if (!e) {
				let e = new Map(z(a).map((e) => [M(e), e.material]));
				if (L(t.x, t.y, 2).every((n) => e.get(M(n)) === t.material) && r.experts.includes("carpenter")) {
					let e = ie[t.material];
					for (let n of t.reverse ? [e[1], e[0]] : e) st(r, i, n);
				} else st(r, i, t.kind);
			}
			return { state: r };
		}
		if (t.type === "donate") {
			if (r.phase === "initial") return J();
			let e = r.players.find((e) => e.rid === t.to);
			if (!e || !q(r) && e !== i) return J();
			let n = Je(e, r.round), a = t.job === null ? null : i.jobs.find((e) => e.id === t.job), o = a ? a.kind : "survivor";
			if (!n || ![
				"barrel",
				"garden",
				"fish",
				"survivor",
				"scrap",
				"boat",
				"net"
			].includes(o) || !Ye(n, o, q(r))) return J();
			if (a) et(i, a.id);
			else if (t.job === null && !q(r) && i.survivors > 0) i.survivors--;
			else return J();
			return n.paid[o]++, Ue(r, i, "donate", 1, o), Xe(r, e), e.jobs.length && (e.ready = !1), { state: r };
		}
		let o = i.jobs.find((e) => e.id === t.job);
		if (!o) return J();
		if (t.type === "place") return at(r, i, o, t) ? { state: r } : J();
		if (t.type === "discard") return pt(r, i, o) ? (et(i, o.id), (o.kind === "garden" || o.kind === "net") && r.supply.gardenNets++, o.kind === "boat" && r.supply.boats++, { state: r }) : J();
		if (t.type === "expert") return o.kind !== "expert" || r.experts.includes(t.expert) ? J() : (r.experts.push(t.expert), et(i, o.id), Ue(r, i, "expert", 1, t.expert), { state: r });
		if (t.type === "catch") {
			if (o.kind === "catch") {
				let e = o.choices, n = e[t.returnIndex];
				if (n === void 0) return J();
				r.fishBag = He(r, [...r.fishBag, n]), et(i, o.id), e.forEach((e, n) => {
					n !== t.returnIndex && (e === -1 ? X(r, i, "barrel") : Y(r, i, "fish", { value: e }));
				});
			} else if (o.kind === "fish") q(r) ? r.fish += o.value : i.fish.push(o.value), et(i, o.id);
			else return J();
			return { state: r };
		}
		if (t.type === "house") {
			if (o.kind !== "house" || !ot(r, i).includes(t.building)) return J();
			let e = a.buildings.find((e) => e.id === t.building);
			if (e.resident = !0, et(i, o.id), q(r) ? r.islandSurvivors-- : i.survivors--, e.kind === "house") {
				let e = Je(i, r.round);
				if (!e || e.weather !== "sun" || e.complete) return J();
				e.paid.house++, Xe(r, i);
			} else st(r, i, e.kind);
			return { state: r };
		}
		return J();
	},
	viewFor(e, t) {
		let n = e.players.find((e) => e.rid === t);
		return {
			public: {
				config: e.config,
				phase: e.phase,
				round: e.round,
				step: e.step,
				boards: e.boards,
				goals: e.goals,
				experts: e.experts,
				islandSurvivors: e.islandSurvivors,
				fish: e.fish,
				gardenBonus: e.gardenBonus,
				solarBonus: e.solarBonus,
				soloDiscard: e.soloDiscard,
				captainMoved: e.captainMoved,
				won: e.won,
				reason: e.reason,
				log: e.log.slice(-160),
				supply: {
					...e.supply,
					tiles: e.tileBag.length,
					scraps: e.scrapBag.length,
					fish: e.fishBag.length
				},
				players: e.players.map((t) => ({
					rid: t.rid,
					board: t.board,
					hand: t.hand,
					jobs: q(e) ? t.jobs : t.jobs.map((e) => ({
						...e,
						...e.value === void 0 ? {} : { value: 0 },
						...e.choices ? { choices: e.choices.map(() => 0) } : {}
					})),
					recent: t.recent,
					ready: t.ready,
					drafted: t.drafted,
					initialDone: t.initialDone,
					initialSide: t.initialSide,
					survivors: t.survivors,
					fishCount: t.fish.length,
					events: t.events,
					weatherChosen: t.chosenWeather !== null,
					availableWeather: t.availableWeather,
					score: q(e) ? Be() : ht(e.boards[t.board], e.phase === "ended" ? t.fish : [], t.survivors, t.events, e.goals)
				}))
			},
			private: {
				jobs: n?.jobs ?? [],
				fish: n?.fish ?? [],
				chosenWeather: n?.chosenWeather ?? null
			}
		};
	},
	status(e) {
		if (e.phase !== "ended") return { phase: e.phase };
		if (q(e)) return {
			phase: e.phase,
			winner: e.won ? e.players.map((e) => e.rid) : [],
			ranking: e.players.map((e) => e.rid)
		};
		let t = e.players.map((t) => ({
			rid: t.rid,
			score: ht(Ve(e, t), t.fish, t.survivors, t.events, e.goals).total,
			m: G(Ve(e, t))
		})), n = (e, t) => t.score - e.score || e.m.plastic - t.m.plastic || t.m.residents - e.m.residents || t.m.monuments - e.m.monuments || t.m.buildings - e.m.buildings;
		return t.sort(n), {
			phase: e.phase,
			winner: t.filter((e) => n(e, t[0]) === 0).map((e) => e.rid),
			ranking: t.map((e) => e.rid),
			scores: Object.fromEntries(t.map((e) => [e.rid, e.score]))
		};
	}
}, _t = {
	wood: "<path d=\"M13 24 34 17 37 80 16 86Z\" fill=\"#a17136\" stroke=\"#614b31\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M37 16 58 19 62 85 40 81Z\" fill=\"#d59b43\" stroke=\"#614b31\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M64 22 85 18 81 82 60 87Z\" fill=\"#ba8540\" stroke=\"#614b31\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M17 24 30 22 33 77 20 79M42 22 51 24 54 77M68 26 78 23 75 77\" fill=\"none\" stroke=\"#f5cf7e\" stroke-width=\"4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M10 40 88 30 91 48 14 59Z\" fill=\"#e0aa55\" stroke=\"#614b31\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M14 43 85 35M18 52 86 42\" fill=\"none\" stroke=\"#ffdc91\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M22 63 24 74M47 29 47 34M68 63 67 73\" fill=\"none\" stroke=\"#79572e\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><circle cx=\"24\" cy=\"46\" r=\"2.2\" fill=\"#6e542f\" stroke=\"none\" stroke-width=\"1\" /><circle cx=\"77\" cy=\"39\" r=\"2.2\" fill=\"#6e542f\" stroke=\"none\" stroke-width=\"1\" />",
	metal: "<path d=\"M13 26 39 16 51 76 23 86Z\" fill=\"#7293a0\" stroke=\"#385c66\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M42 18 72 20 85 80 52 82Z\" fill=\"#a8c4ca\" stroke=\"#385c66\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M12 39 83 33 85 48 17 55Z\" fill=\"#b87156\" stroke=\"#385c66\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M18 42 80 37M19 49 81 44\" fill=\"none\" stroke=\"#e4ac86\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M20 62 85 59 87 73 22 79Z\" fill=\"#70828a\" stroke=\"#385c66\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M24 65 80 63M26 73 79 70\" fill=\"none\" stroke=\"#b2c2bf\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M21 29 33 24M51 25 66 27\" fill=\"none\" stroke=\"#e6f0e5\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><circle cx=\"23\" cy=\"45\" r=\"2.5\" fill=\"#e4dcc2\" stroke=\"#405c62\" stroke-width=\"1\" /><circle cx=\"73\" cy=\"41\" r=\"2.5\" fill=\"#e4dcc2\" stroke=\"#405c62\" stroke-width=\"1\" /><circle cx=\"31\" cy=\"69\" r=\"2.5\" fill=\"#e4dcc2\" stroke=\"#405c62\" stroke-width=\"1\" /><circle cx=\"77\" cy=\"67\" r=\"2.5\" fill=\"#e4dcc2\" stroke=\"#405c62\" stroke-width=\"1\" /><circle cx=\"31\" cy=\"27\" r=\"2.5\" fill=\"#e4dcc2\" stroke=\"#405c62\" stroke-width=\"1\" /><circle cx=\"62\" cy=\"29\" r=\"2.5\" fill=\"#e4dcc2\" stroke=\"#405c62\" stroke-width=\"1\" />",
	rubber: "<g transform=\"rotate(-24 50 50)\"><ellipse cx=\"43\" cy=\"45\" rx=\"25\" ry=\"33\" fill=\"#182f3c\" stroke=\"#9bb9ba\" stroke-width=\"3\"/><ellipse cx=\"43\" cy=\"42\" rx=\"23\" ry=\"30\" fill=\"#466875\" stroke=\"#172e3b\" stroke-width=\"3\"/><ellipse cx=\"43\" cy=\"42\" rx=\"12\" ry=\"18\" fill=\"#1b3544\" stroke=\"#a4bbba\" stroke-width=\"3\"/><path d=\"M26 24 33 29M21 39 29 41M24 57 32 53M50 17 48 24M60 29 53 32\" fill=\"none\" stroke=\"#a0b9b8\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"rotate(32 66 65)\"><ellipse cx=\"65\" cy=\"66\" rx=\"21\" ry=\"26\" fill=\"#172f3c\" stroke=\"#adc2bd\" stroke-width=\"3\"/><ellipse cx=\"65\" cy=\"61\" rx=\"21\" ry=\"26\" fill=\"#52757e\" stroke=\"#172f3c\" stroke-width=\"3\"/><ellipse cx=\"65\" cy=\"61\" rx=\"10\" ry=\"14\" fill=\"#183341\" stroke=\"#9bb8b8\" stroke-width=\"3\"/><path d=\"M49 46 54 50M45 61 52 61M50 78 55 73M75 39 72 46M83 57 77 58M80 76 75 71\" fill=\"none\" stroke=\"#a8c2bd\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g>",
	seaweed: "<path d=\"M38 85C13 66 15 46 31 33 40 25 26 21 34 12 49 16 47 30 39 39 19 60 47 59 38 85Z\" fill=\"#b9ce76\" stroke=\"#345f49\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M48 86C34 68 62 56 51 43 35 24 54 20 58 9 74 24 56 29 66 45 77 67 52 66 59 86Z\" fill=\"#83b36c\" stroke=\"#345f49\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M65 85C57 72 81 62 72 50 60 34 77 24 83 30 87 37 73 41 84 54 94 72 71 73 77 83Z\" fill=\"#c4d28b\" stroke=\"#345f49\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M35 78C20 53 47 41 37 21M54 77C47 66 69 54 58 35M72 77C67 66 86 60 77 48\" fill=\"none\" stroke=\"#e3e5ac\" stroke-width=\"2.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M29 82 78 79 76 89 34 92Z\" fill=\"#d1b777\" stroke=\"#345f49\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
	plastic: "<path d=\"M24 27 35 23 41 32 41 43 53 59 38 73 21 58 22 42Z\" fill=\"#c7dedb\" stroke=\"#4f6f73\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M23 23 33 20 37 27 27 30Z\" fill=\"#477b85\" stroke=\"#315962\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M32 44 42 48 36 58 26 51Z\" fill=\"#e67a62\" stroke=\"#4f6f73\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M55 35 73 32 78 47 85 71 67 84 48 69 56 54Z\" fill=\"#e0ebe0\" stroke=\"#4f6f73\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M55 31 70 28 73 35 58 39Z\" fill=\"#d3ad65\" stroke=\"#4f6f73\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M59 55 76 52 80 65 62 70Z\" fill=\"#9eb9a7\" stroke=\"#4f6f73\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M15 68 31 63 46 81 30 90 14 80Z\" fill=\"#91c4c9\" stroke=\"#4f6f73\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M25 37 25 43M59 43 60 51M20 72 26 71\" fill=\"none\" stroke=\"#fff8d8\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
	barrel: "<path d=\"M25 25C32 13 68 13 75 25 83 46 80 72 71 85 59 94 37 91 27 82 19 61 18 43 25 25Z\" fill=\"#bd8746\" stroke=\"#5b5237\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"50\" cy=\"25\" rx=\"25\" ry=\"12\" fill=\"#e0b66e\" stroke=\"#5b5237\" stroke-width=\"3\"/><path d=\"M32 34 34 82M46 39 47 85M60 38 59 85M72 33 68 80\" fill=\"none\" stroke=\"#805d37\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M22 42Q50 56 79 42L80 51Q49 65 22 51Z\" fill=\"#60828b\" stroke=\"#395c64\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M24 70Q48 81 77 68L74 77Q49 89 27 79Z\" fill=\"#60828b\" stroke=\"#395c64\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M30 23Q50 15 69 24\" fill=\"none\" stroke=\"#fae0a0\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><circle cx=\"51\" cy=\"25\" r=\"4\" fill=\"#77582e\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M49 49 55 59 67 61 58 69 59 81 49 75 39 81 41 69 32 61 44 59Z\" fill=\"#fff4c2\" stroke=\"#78633b\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
	house: "<path d=\"M8 83 64 77 93 86 70 96 8 93Z\" fill=\"#ac8959\" stroke=\"#3e5953\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M21 39 61 31 64 85 20 91Z\" fill=\"#c1a77a\" stroke=\"#375853\" stroke-width=\"2.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M61 31 82 40 84 85 64 89Z\" fill=\"#76928a\" stroke=\"#375853\" stroke-width=\"2.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M25 44 55 39 57 75 24 79Z\" fill=\"#3c5a58\" stroke=\"#375853\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M23 46 29 45 30 70 25 72Z\" fill=\"#e2d7b7\" stroke=\"#375853\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M30 45 36 43 37 70 31 71Z\" fill=\"#b66c57\" stroke=\"#375853\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M37 43 43 42 45 68 38 70Z\" fill=\"#efe0b4\" stroke=\"#375853\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M44 41 50 40 52 67 46 68Z\" fill=\"#b56d59\" stroke=\"#375853\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M51 40 57 39 59 66 53 67Z\" fill=\"#e4d9b6\" stroke=\"#375853\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M21 70 62 65 63 76 21 82Z\" fill=\"#647d72\" stroke=\"#375853\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M24 73 58 69M25 78 58 73\" fill=\"none\" stroke=\"#9baf98\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M26 79 26 91M57 75 58 90M41 78 42 91\" fill=\"none\" stroke=\"#3a5550\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M68 50 83 52 84 77 67 78Z\" fill=\"#bfa978\" stroke=\"#375853\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M69 56 82 57M69 63 82 64M69 71 82 71\" fill=\"none\" stroke=\"#718472\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M65 45 80 45 80 52 65 53Z\" fill=\"#dbbc85\" stroke=\"#375853\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M16 9 24 7 25 26 17 27Z\" fill=\"#48656a\" stroke=\"#375853\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M13 35 46 8 78 20 88 45 55 43Z\" fill=\"#557f77\" stroke=\"#31535a\" stroke-width=\"2.7\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M14 35 46 12 48 21 17 43Z\" fill=\"#739b8e\" stroke=\"#375853\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M17 43 48 22 51 30 18 51Z\" fill=\"#3d6b67\" stroke=\"#375853\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M19 51 52 31 54 40 22 58Z\" fill=\"#74998b\" stroke=\"#375853\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M47 11 78 22 81 30 49 20Z\" fill=\"#abb69b\" stroke=\"#375853\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M49 21 81 32 84 39 51 29Z\" fill=\"#6e8f80\" stroke=\"#375853\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M52 30 85 41 89 49 55 40Z\" fill=\"#b3b997\" stroke=\"#375853\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M55 41 87 50 88 56 58 47Z\" fill=\"#52766d\" stroke=\"#375853\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M57 23 72 28 73 34 59 29Z\" fill=\"#c4aa79\" stroke=\"#375853\" stroke-width=\"1.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M34 32 43 26M26 48 39 40M59 36 71 40\" fill=\"none\" stroke=\"#c5c7a2\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><circle cx=\"22\" cy=\"38\" r=\"1.1\" fill=\"#e6d9ad\" stroke=\"#405f56\" stroke-width=\"0.5\" /><circle cx=\"45\" cy=\"19\" r=\"1.1\" fill=\"#e6d9ad\" stroke=\"#405f56\" stroke-width=\"0.5\" /><circle cx=\"53\" cy=\"25\" r=\"1.1\" fill=\"#e6d9ad\" stroke=\"#405f56\" stroke-width=\"0.5\" /><circle cx=\"79\" cy=\"36\" r=\"1.1\" fill=\"#e6d9ad\" stroke=\"#405f56\" stroke-width=\"0.5\" /><circle cx=\"63\" cy=\"39\" r=\"1.1\" fill=\"#e6d9ad\" stroke=\"#405f56\" stroke-width=\"0.5\" /><circle cx=\"30\" cy=\"47\" r=\"1.1\" fill=\"#e6d9ad\" stroke=\"#405f56\" stroke-width=\"0.5\" /><circle cx=\"26\" cy=\"75\" r=\"1.1\" fill=\"#e6d9ad\" stroke=\"#405f56\" stroke-width=\"0.5\" /><circle cx=\"57\" cy=\"72\" r=\"1.1\" fill=\"#e6d9ad\" stroke=\"#405f56\" stroke-width=\"0.5\" /><path d=\"M13 87 68 82M16 91 64 87M77 85 85 88\" fill=\"none\" stroke=\"#e2c796\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><g transform=\"translate(76 66) scale(0.21)\" ><path d=\"M25 25C32 13 68 13 75 25 83 46 80 72 71 85 59 94 37 91 27 82 19 61 18 43 25 25Z\" fill=\"#bd8746\" stroke=\"#5b5237\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"50\" cy=\"25\" rx=\"25\" ry=\"12\" fill=\"#e0b66e\" stroke=\"#5b5237\" stroke-width=\"3\"/><path d=\"M32 34 34 82M46 39 47 85M60 38 59 85M72 33 68 80\" fill=\"none\" stroke=\"#805d37\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M22 42Q50 56 79 42L80 51Q49 65 22 51Z\" fill=\"#60828b\" stroke=\"#395c64\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M24 70Q48 81 77 68L74 77Q49 89 27 79Z\" fill=\"#60828b\" stroke=\"#395c64\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M30 23Q50 15 69 24\" fill=\"none\" stroke=\"#fae0a0\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><circle cx=\"51\" cy=\"25\" r=\"4\" fill=\"#77582e\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M49 49 55 59 67 61 58 69 59 81 49 75 39 81 41 69 32 61 44 59Z\" fill=\"#fff4c2\" stroke=\"#78633b\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g>",
	cooper: "<path d=\"M7 83 49 70 92 81 62 96 9 93Z\" fill=\"#b99b69\" stroke=\"#3f5c52\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M19 80C11 55 22 29 49 24 75 25 86 51 80 82L58 90Z\" fill=\"#bb8e52\" stroke=\"#405852\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M24 38Q44 45 71 36L78 46Q48 59 19 49Z\" fill=\"#557b7e\" stroke=\"#365b5c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M18 66Q48 77 82 65L81 75Q50 89 20 78Z\" fill=\"#557b7e\" stroke=\"#365b5c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M28 49C26 56 27 66 29 70M38 53 37 74M61 52 65 75M72 48 77 68\" fill=\"none\" stroke=\"#765d3c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M36 56 54 54 59 82 38 86Z\" fill=\"#3c5e60\" stroke=\"#304f54\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M40 57 44 83M51 56 53 82\" fill=\"none\" stroke=\"#a38350\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M16 31 47 18 80 27 76 40 47 43 15 41Z\" fill=\"#6b9d99\" stroke=\"#365b5c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M23 32 48 24 70 30M23 37 47 32 71 35\" fill=\"none\" stroke=\"#b1ccc0\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M38 13 61 13 63 24Q49 32 36 23Z\" fill=\"#c49b61\" stroke=\"#405852\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"49\" cy=\"13\" rx=\"13\" ry=\"5\" fill=\"#8cae9e\" stroke=\"#405852\" stroke-width=\"2.5\"/><g transform=\"translate(66 62) scale(0.3)\" ><path d=\"M25 25C32 13 68 13 75 25 83 46 80 72 71 85 59 94 37 91 27 82 19 61 18 43 25 25Z\" fill=\"#bd8746\" stroke=\"#5b5237\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"50\" cy=\"25\" rx=\"25\" ry=\"12\" fill=\"#e0b66e\" stroke=\"#5b5237\" stroke-width=\"3\"/><path d=\"M32 34 34 82M46 39 47 85M60 38 59 85M72 33 68 80\" fill=\"none\" stroke=\"#805d37\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M22 42Q50 56 79 42L80 51Q49 65 22 51Z\" fill=\"#60828b\" stroke=\"#395c64\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M24 70Q48 81 77 68L74 77Q49 89 27 79Z\" fill=\"#60828b\" stroke=\"#395c64\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M30 23Q50 15 69 24\" fill=\"none\" stroke=\"#fae0a0\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><circle cx=\"51\" cy=\"25\" r=\"4\" fill=\"#77582e\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M49 49 55 59 67 61 58 69 59 81 49 75 39 81 41 69 32 61 44 59Z\" fill=\"#fff4c2\" stroke=\"#78633b\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><path d=\"M11 86 34 83M66 89 86 83\" fill=\"none\" stroke=\"#e9cc95\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
	shipyard: "<path d=\"M10 80 68 69 94 78 44 96 8 91Z\" fill=\"#ae9b6a\" stroke=\"#3c5d56\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M20 31 49 25 51 76 22 83Z\" fill=\"#d0c0a0\" stroke=\"#3c5d56\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M51 26 80 38 80 70 51 77Z\" fill=\"#879e98\" stroke=\"#3c5d56\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M12 34 30 12 60 14 84 38 49 39 30 29Z\" fill=\"#638f9e\" stroke=\"#365760\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M18 33 31 18 40 20 32 33M36 35 47 19 57 21 68 37\" fill=\"none\" stroke=\"#a2c3c2\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M27 49 43 46 43 76 28 80Z\" fill=\"#395d64\" stroke=\"#3c5d56\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M31 51 37 49 37 75\" fill=\"none\" stroke=\"#c9b684\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M54 45 72 51 71 61 54 56Z\" fill=\"#dbb674\" stroke=\"#3c5d56\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M12 70 15 53 19 44 23 54 23 73 18 80Z\" fill=\"#d6aa64\" stroke=\"#365760\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M7 73 24 68 29 74 18 88 5 82Z\" fill=\"#d78259\" stroke=\"#365760\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M56 77 82 68 91 73 76 87 54 86Z\" fill=\"#e2ba72\" stroke=\"#365760\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M61 79 79 74 84 76 74 82 61 83Z\" fill=\"#78938a\" stroke=\"#365760\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M52 64 52 87M84 69 85 86M40 86 47 83\" fill=\"none\" stroke=\"#456961\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
	greenhouse: "<path d=\"M13 80 58 68 88 79 49 94 11 90Z\" fill=\"#a78c54\" stroke=\"#3e654e\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M20 43 54 34 76 46 76 78 40 90 20 80Z\" fill=\"#90b9a4\" stroke=\"#3c6b59\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M18 42 33 20 58 18 81 43 51 53Z\" fill=\"#c6e1d0\" stroke=\"#3c6b59\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M20 44 51 54 51 85M33 24 50 52M58 22 51 52M29 48 29 81M39 51 39 86M63 50 63 82M22 63 50 72 75 64\" fill=\"none\" stroke=\"#567d64\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M30 73C17 62 27 55 34 66 30 52 41 52 41 67 50 58 55 65 45 75Z\" fill=\"#76a35c\" stroke=\"#3d6c4c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M58 68C52 56 59 52 64 61 64 49 76 52 71 65 80 61 83 70 68 74Z\" fill=\"#a6bc6a\" stroke=\"#3d6c4c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M12 84 43 92M52 90 79 81\" fill=\"none\" stroke=\"#e1c98b\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
	solar: "<path d=\"M12 81 56 68 88 80 51 94 12 90Z\" fill=\"#b4a47b\" stroke=\"#3b5d59\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M27 57 28 83M67 50 69 81\" fill=\"none\" stroke=\"#5b756c\" stroke-width=\"6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M17 29 76 18 83 60 23 74Z\" fill=\"#3e7b99\" stroke=\"#345d6c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M23 34 72 25 77 55 27 66Z\" fill=\"#527f9e\" stroke=\"#aacdd0\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M39 31 42 62M56 28 59 59M25 44 74 35M26 54 76 45\" fill=\"none\" stroke=\"#bddbd8\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M29 36 39 34M46 43 55 41M62 50 72 48\" fill=\"none\" stroke=\"#7fbdca\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><rect x=\"13\" y=\"72\" width=\"12\" height=\"12\" rx=\"1\" fill=\"#b2aa7b\" stroke=\"#365b5a\" stroke-width=\"2\" />",
	warehouse: "<path d=\"M8 80 63 71 92 81 53 96 7 91Z\" fill=\"#b39d71\" stroke=\"#3e5b56\" stroke-width=\"2.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M19 34 61 25 79 40 79 81 22 89Z\" fill=\"#6f9a94\" stroke=\"#3d5957\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M15 35 35 15 66 17 86 40 58 44Z\" fill=\"#556e7b\" stroke=\"#36535c\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M24 33 37 20M38 36 49 20M54 38 61 22M25 50 25 84M37 47 37 85M50 46 50 84M65 46 65 80\" fill=\"none\" stroke=\"#a9b8a2\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M31 63 51 58 51 86 31 90Z\" fill=\"#345b63\" stroke=\"#36535c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><g transform=\"translate(61 54) scale(0.3)\" ><path d=\"M25 25C32 13 68 13 75 25 83 46 80 72 71 85 59 94 37 91 27 82 19 61 18 43 25 25Z\" fill=\"#bd8746\" stroke=\"#5b5237\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><ellipse cx=\"50\" cy=\"25\" rx=\"25\" ry=\"12\" fill=\"#e0b66e\" stroke=\"#5b5237\" stroke-width=\"3\"/><path d=\"M32 34 34 82M46 39 47 85M60 38 59 85M72 33 68 80\" fill=\"none\" stroke=\"#805d37\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M22 42Q50 56 79 42L80 51Q49 65 22 51Z\" fill=\"#60828b\" stroke=\"#395c64\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M24 70Q48 81 77 68L74 77Q49 89 27 79Z\" fill=\"#60828b\" stroke=\"#395c64\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M30 23Q50 15 69 24\" fill=\"none\" stroke=\"#fae0a0\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><circle cx=\"51\" cy=\"25\" r=\"4\" fill=\"#77582e\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M49 49 55 59 67 61 58 69 59 81 49 75 39 81 41 69 32 61 44 59Z\" fill=\"#fff4c2\" stroke=\"#78633b\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><path d=\"M8 73 23 70 25 84 10 87Z\" fill=\"#d3a965\" stroke=\"#36535c\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M10 75 21 80M21 73 11 84\" fill=\"none\" stroke=\"#997343\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M18 35 58 43 84 39\" fill=\"none\" stroke=\"#d28e62\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
	boat: "<path d=\"M4 48Q14 34 42 37L86 40Q95 42 96 51L93 64Q63 73 20 64 7 61 4 48Z\" fill=\"#436d69\" stroke=\"#2f5156\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M5 47Q19 36 45 40L87 43Q92 44 92 51L88 60Q52 67 19 59Z\" fill=\"#b79a66\" stroke=\"#2f5156\" stroke-width=\"1.5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M11 48Q20 42 43 44L86 47 85 56Q54 62 22 55Z\" fill=\"#d6be8b\" stroke=\"#526c5e\" stroke-width=\"1.1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M18 43 20 57M28 43 30 60M40 43 41 62M54 45 54 63M69 46 68 62M80 47 79 60\" fill=\"none\" stroke=\"#89734f\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M8 49Q18 62 49 64T91 59\" fill=\"none\" stroke=\"#d9c898\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M8 54Q24 66 57 67L88 64\" fill=\"none\" stroke=\"#7d9b85\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M43 38 61 37 62 59 43 61Z\" fill=\"#719485\" stroke=\"#31585b\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M61 38 70 43 69 58 62 59Z\" fill=\"#496e6b\" stroke=\"#31585b\" stroke-width=\"1.1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M41 37 44 24 62 27 70 41 59 43Z\" fill=\"#759a88\" stroke=\"#31585b\" stroke-width=\"1.4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M45 27 61 30M44 31 63 34M44 35 66 38\" fill=\"none\" stroke=\"#d0bb85\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M46 45 56 44 56 54 46 55Z\" fill=\"#b7d5c8\" stroke=\"#31585b\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M50 44 50 54\" fill=\"none\" stroke=\"#f1e5b5\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M65 45 68 46 67 51 64 51Z\" fill=\"#c6dac9\" stroke=\"#31585b\" stroke-width=\"0.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M22 47 34 47 35 55 23 55Z\" fill=\"#b77e55\" stroke=\"#31585b\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M23 50H34M27 48V54\" fill=\"none\" stroke=\"#e1b67c\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M76 45 83 45 84 57 75 58Z\" fill=\"#826e4c\" stroke=\"#31585b\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M78 47V56M81 47V56\" fill=\"none\" stroke=\"#d0ad74\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M17 40 18 31 21 29 22 42\" fill=\"#c88f59\" stroke=\"#31585b\" stroke-width=\"1.2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M17 31 25 31\" fill=\"none\" stroke=\"#31585b\" stroke-width=\"1.3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M87 39 88 26M87 39 94 45\" fill=\"none\" stroke=\"#31585b\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M52 63 50 72 57 77 62 72 60 64Z\" fill=\"#506e6a\" stroke=\"#31585b\" stroke-width=\"1.1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M53 68 59 70M54 72 58 73\" fill=\"none\" stroke=\"#b4b89a\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><circle cx=\"36\" cy=\"60\" r=\"3.5\" fill=\"#355658\" stroke=\"#cbbf92\" stroke-width=\"1\" /><path d=\"M33 58 39 62\" fill=\"none\" stroke=\"#879b83\" stroke-width=\"1\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
	fish: "<path d=\"M18 49 5 32 7 67 22 53C40 76 67 72 91 49 68 25 39 24 18 49Z\" fill=\"#bfd9cd\" stroke=\"#3e7482\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M46 35 52 22 66 37M42 65 51 78 67 63\" fill=\"#78a8a5\" stroke=\"#3e7482\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M56 35Q45 50 56 65\" fill=\"none\" stroke=\"#7aa5a6\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><circle cx=\"75\" cy=\"45\" r=\"4\" fill=\"#2c5965\" stroke=\"none\" stroke-width=\"1\" /><path d=\"M29 45 33 49 29 53M37 41 42 46 37 52\" fill=\"none\" stroke=\"#7aa5a6\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
	ring: "<circle cx=\"50\" cy=\"50\" r=\"31\" fill=\"#e9dec4\" stroke=\"#315f6b\" stroke-width=\"3\" /><circle cx=\"50\" cy=\"50\" r=\"17\" fill=\"#78bccb\" stroke=\"#315f6b\" stroke-width=\"3\" /><path d=\"M24 34 35 22 44 33 33 44Z\" fill=\"#dc8664\" stroke=\"none\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M66 23 78 35 67 44 56 33Z\" fill=\"#dc8664\" stroke=\"none\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M77 66 65 78 56 67 67 56Z\" fill=\"#dc8664\" stroke=\"none\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M34 77 22 65 33 56 44 67Z\" fill=\"#dc8664\" stroke=\"none\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M19 49 12 46M80 50 88 55M49 19 53 12M50 80 46 88\" fill=\"none\" stroke=\"#f7e4ac\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
	resident: "<circle cx=\"50\" cy=\"23\" r=\"13\" fill=\"#ffe6a0\" stroke=\"#53716a\" stroke-width=\"2.5\" /><path d=\"M34 41 65 41 81 63 70 71 64 62 66 89 53 89 50 70 46 89 32 89 35 61 26 70 17 62Z\" fill=\"#f3cf78\" stroke=\"#53716a\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M30 20Q50 6 70 20\" fill=\"none\" stroke=\"#527f83\" stroke-width=\"5\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
	garden: "<path d=\"M8 23 87 16 94 76 16 89Z\" fill=\"#866d43\" stroke=\"#3c6051\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M14 27 83 22 87 72 21 82Z\" fill=\"#526e47\" stroke=\"#d8bd7e\" stroke-width=\"4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M28 34V69\" fill=\"none\" stroke=\"#2b5a45\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M28 47C8 33 13 25 28 37C44 23 49 35 28 47M28 69C10 57 14 46 28 60C46 46 46 61 28 69\" fill=\"#b0c87b\" stroke=\"#4e784f\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M50 34V69\" fill=\"none\" stroke=\"#2b5a45\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M50 47C30 33 35 25 50 37C66 23 71 35 50 47M50 69C32 57 36 46 50 60C68 46 68 61 50 69\" fill=\"#b0c87b\" stroke=\"#4e784f\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M72 34V69\" fill=\"none\" stroke=\"#2b5a45\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M72 47C52 33 57 25 72 37C88 23 93 35 72 47M72 69C54 57 58 46 72 60C90 46 90 61 72 69\" fill=\"#b0c87b\" stroke=\"#4e784f\" stroke-width=\"1.6\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
	net: "<path d=\"M9 20 89 20 89 81 9 81Z\" fill=\"#70bbc2\" stroke=\"#2d6671\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M20 22V80M10 20H88\" fill=\"none\" stroke=\"#e6d8aa\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M35 22V80M10 35H88\" fill=\"none\" stroke=\"#e6d8aa\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M50 22V80M10 50H88\" fill=\"none\" stroke=\"#e6d8aa\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M65 22V80M10 65H88\" fill=\"none\" stroke=\"#e6d8aa\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M80 22V80M10 80H88\" fill=\"none\" stroke=\"#e6d8aa\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><circle cx=\"12\" cy=\"23\" r=\"5\" fill=\"#efbd72\" stroke=\"#5e775e\" stroke-width=\"1.5\" /><circle cx=\"86\" cy=\"23\" r=\"5\" fill=\"#efbd72\" stroke=\"#5e775e\" stroke-width=\"1.5\" /><circle cx=\"12\" cy=\"79\" r=\"5\" fill=\"#efbd72\" stroke=\"#5e775e\" stroke-width=\"1.5\" /><circle cx=\"86\" cy=\"79\" r=\"5\" fill=\"#efbd72\" stroke=\"#5e775e\" stroke-width=\"1.5\" />",
	sun: "<circle cx=\"50\" cy=\"41\" r=\"21\" fill=\"#f3ce79\" stroke=\"#647e71\" stroke-width=\"2.5\" /><g transform=\"rotate(0 50 41)\"><path d=\"M50 10V3\" fill=\"none\" stroke=\"#be9e5e\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"rotate(45 50 41)\"><path d=\"M50 10V3\" fill=\"none\" stroke=\"#be9e5e\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"rotate(90 50 41)\"><path d=\"M50 10V3\" fill=\"none\" stroke=\"#be9e5e\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"rotate(135 50 41)\"><path d=\"M50 10V3\" fill=\"none\" stroke=\"#be9e5e\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"rotate(180 50 41)\"><path d=\"M50 10V3\" fill=\"none\" stroke=\"#be9e5e\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"rotate(225 50 41)\"><path d=\"M50 10V3\" fill=\"none\" stroke=\"#be9e5e\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"rotate(270 50 41)\"><path d=\"M50 10V3\" fill=\"none\" stroke=\"#be9e5e\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><g transform=\"rotate(315 50 41)\"><path d=\"M50 10V3\" fill=\"none\" stroke=\"#be9e5e\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /></g><path d=\"M6 78Q25 64 43 78T80 78M19 89Q36 79 54 89T92 89\" fill=\"none\" stroke=\"#80b6bd\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
	rain: "<path d=\"M14 45C0 26 23 11 36 22 41 3 68 8 71 26 95 21 99 49 80 52H21Z\" fill=\"#bbd2d1\" stroke=\"#4b7a82\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M24 62l-7 12\" fill=\"none\" stroke=\"#408ca4\" stroke-width=\"4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M45 69l-7 12\" fill=\"none\" stroke=\"#408ca4\" stroke-width=\"4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M66 62l-7 12\" fill=\"none\" stroke=\"#408ca4\" stroke-width=\"4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M83 69l-7 12\" fill=\"none\" stroke=\"#408ca4\" stroke-width=\"4\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
	storm: "<path d=\"M10 45C0 25 23 13 37 23 43 5 71 11 73 28 96 24 98 52 79 54H17Z\" fill=\"#7ea5b1\" stroke=\"#3e6d7b\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M50 43 33 69 49 66 42 92 70 56 53 59Z\" fill=\"#f3d184\" stroke=\"#496c72\" stroke-width=\"2\" stroke-linejoin=\"round\" stroke-linecap=\"round\" />",
	monument: "<path d=\"M12 83 50 70 89 81 54 97 12 92Z\" fill=\"#bcae84\" stroke=\"#4c6c64\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M37 21 60 17 66 76 45 83 29 74Z\" fill=\"#b9cec2\" stroke=\"#4c6c64\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M37 22 44 36 40 72M60 22 51 42 53 76\" fill=\"none\" stroke=\"#f1e8c5\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><path d=\"M32 19 50 6 68 17 52 30Z\" fill=\"#e4cf98\" stroke=\"#4c6c64\" stroke-width=\"3\" stroke-linejoin=\"round\" stroke-linecap=\"round\" /><circle cx=\"50\" cy=\"18\" r=\"5\" fill=\"#6c9e97\" stroke=\"none\" stroke-width=\"1\" />"
}, vt = {
	wood: "#edbe65",
	metal: "#c9dfe4",
	rubber: "#294c60",
	seaweed: "#6d9f68",
	plastic: "#e9896a",
	wild: "#dfb775",
	boat: "#b99663",
	island: "#d9cf9f"
};
function Z({ kind: e, ...t }) {
	return /* @__PURE__ */ y("g", {
		...t,
		dangerouslySetInnerHTML: { __html: _t[e] }
	});
}
function Q({ kind: e, className: t }) {
	return /* @__PURE__ */ y("svg", {
		viewBox: "0 0 100 100",
		className: t ?? "kalypso-content-icon",
		"aria-hidden": !0,
		children: /* @__PURE__ */ y(Z, { kind: e })
	});
}
function yt({ material: e }) {
	return e === "island" ? null : /* @__PURE__ */ y(Z, { kind: e === "wild" ? "barrel" : e });
}
function bt({ claimed: e = !1 }) {
	return /* @__PURE__ */ b("g", {
		opacity: e ? .35 : 1,
		children: [/* @__PURE__ */ y(Z, { kind: "fish" }), e && /* @__PURE__ */ y("path", {
			d: "m24 76 17 12 35-28",
			stroke: "#f4e8c7",
			strokeWidth: "7",
			fill: "none"
		})]
	});
}
function xt() {
	return /* @__PURE__ */ y(Z, { kind: "ring" });
}
function St({ kind: e }) {
	return e === "sanctuary" ? /* @__PURE__ */ b("g", { children: [/* @__PURE__ */ y(Z, { kind: "monument" }), /* @__PURE__ */ y("g", {
		transform: "translate(18 16) scale(.64)",
		children: /* @__PURE__ */ y(Z, { kind: "ring" })
	})] }) : e === "scrapyard" ? /* @__PURE__ */ b("g", { children: [
		/* @__PURE__ */ y(Z, { kind: "warehouse" }),
		/* @__PURE__ */ y("g", {
			transform: "translate(9 52) scale(.4)",
			children: /* @__PURE__ */ y(Z, { kind: "rubber" })
		}),
		/* @__PURE__ */ y("g", {
			transform: "translate(55 51) scale(.4)",
			children: /* @__PURE__ */ y(Z, { kind: "metal" })
		})
	] }) : e === "netWorkshop" ? /* @__PURE__ */ b("g", { children: [/* @__PURE__ */ y(Z, { kind: "shipyard" }), /* @__PURE__ */ y("g", {
		transform: "translate(55 44) scale(.42)",
		children: /* @__PURE__ */ y(Z, { kind: "net" })
	})] }) : /* @__PURE__ */ y(Z, { kind: e });
}
function Ct({ weather: e }) {
	return /* @__PURE__ */ y(Q, { kind: e === "sun" || e === "rain" || e === "storm" ? e : e === "drought" ? "sun" : e === "dock" ? "boat" : e === "teeth" ? "fish" : "warehouse" });
}
function wt({ width: e = 300, height: t = 100 }) {
	return /* @__PURE__ */ y("svg", {
		width: e,
		height: t,
		viewBox: "0 23 100 56",
		preserveAspectRatio: "none",
		overflow: "visible",
		children: /* @__PURE__ */ y(Z, { kind: "boat" })
	});
}
function Tt({ job: e, rotation: t = 0, flip: n = !1 }) {
	if (e.kind === "boat") return /* @__PURE__ */ y("svg", {
		viewBox: "-4 -4 308 108",
		className: "kalypso-item-art",
		"aria-hidden": !0,
		children: /* @__PURE__ */ y(wt, {})
	});
	if (e.kind === "garden" || e.kind === "net") return /* @__PURE__ */ b("svg", {
		viewBox: "0 0 200 100",
		className: "kalypso-item-art",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ y(Z, { kind: e.kind }), /* @__PURE__ */ y("g", {
			transform: "translate(100)",
			children: /* @__PURE__ */ y(Z, { kind: e.kind })
		})]
	});
	let r = H(e, {
		x: 0,
		y: 0,
		rotation: t,
		flip: n
	}), i = Math.max(1, ...r.map((e) => e.x + 1)), a = Math.max(1, ...r.map((e) => e.y + 1));
	return r.length ? /* @__PURE__ */ y("svg", {
		viewBox: `-7 -7 ${i * 100 + 14} ${a * 100 + 14}`,
		className: "kalypso-item-art",
		"aria-hidden": !0,
		children: r.map((e) => /* @__PURE__ */ b("g", {
			transform: `translate(${e.x * 100} ${e.y * 100})`,
			children: [/* @__PURE__ */ y("rect", {
				x: "2",
				y: "2",
				width: "96",
				height: "96",
				fill: vt[e.material],
				stroke: "#325d60",
				strokeWidth: "4"
			}), /* @__PURE__ */ y(yt, { material: e.material })]
		}, `${e.x},${e.y}`))
	}) : /* @__PURE__ */ y(Q, { kind: e.kind === "fish" || e.kind === "catch" ? "fish" : e.kind === "house" ? "resident" : "ring" });
}
//#endregion
//#region src/games/kalypso/board-tools.tsx
var Et = (e, t) => Math.max(0, Math.min(e.right, t.right) - Math.max(e.left, t.left)) * Math.max(0, Math.min(e.bottom, t.bottom) - Math.max(e.top, t.top));
function Dt({ host: e, children: t }) {
	let n = a(null), [i, s] = o(null);
	return r(() => {
		let t = e.current, r = n.current;
		if (!t || !r) return;
		let i = 0, a = () => {
			i = 0;
			let e = t.querySelector("[data-kalypso-focus]")?.getBoundingClientRect();
			if (!e) {
				s(null);
				return;
			}
			let n = t.getBoundingClientRect(), a = r.offsetWidth, o = r.offsetHeight, c = (e.left + e.right) / 2, l = (e.top + e.bottom) / 2, u = [
				[c - a / 2, e.bottom + 10],
				[c - a / 2, e.top - o - 10],
				[e.right + 10, l - o / 2],
				[e.left - a - 10, l - o / 2]
			], d = [...(t.parentElement ?? t).querySelectorAll("[data-kalypso-occupied],.kalypso-map-controls,.kalypso-map-caption,.kalypso-personal-stats,.kalypso-resource-track,.kalypso-action-detail")].map((e) => e.getBoundingClientRect()), f = {
				left: 8,
				top: 8
			}, p = Infinity;
			for (let [t, r] of u) {
				let i = Math.max(n.left + 8, Math.min(n.right - a - 8, t)), s = Math.max(n.top + 8, Math.min(n.bottom - o - 8, r)), u = {
					left: i,
					top: s,
					right: i + a,
					bottom: s + o
				}, m = Et(u, e) * 1e6 + d.reduce((e, t) => e + Et(u, t), 0) * 100 + Math.hypot(i + a / 2 - c, s + o / 2 - l);
				m < p && (f = {
					left: i - n.left,
					top: s - n.top
				}, p = m);
			}
			s((e) => e && Math.abs(e.left - f.left) < .5 && Math.abs(e.top - f.top) < .5 ? e : f);
		}, o = () => {
			i ||= requestAnimationFrame(a);
		}, c = new ResizeObserver(o);
		c.observe(t), c.observe(r);
		let l = new MutationObserver(o), u = t.querySelector("svg");
		return u && l.observe(u, {
			attributes: !0,
			subtree: !0,
			childList: !0
		}), o(), () => {
			cancelAnimationFrame(i), c.disconnect(), l.disconnect();
		};
	}, [e, t]), /* @__PURE__ */ y("div", {
		ref: n,
		className: "kalypso-near-controls",
		style: {
			left: i?.left ?? 0,
			top: i?.top ?? 0,
			visibility: i ? "visible" : "hidden"
		},
		onPointerDown: (e) => e.stopPropagation(),
		onPointerUp: (e) => e.stopPropagation(),
		children: t
	});
}
//#endregion
//#region src/games/kalypso/board-view.tsx
function Ot({ job: e, pose: t, turns: n }) {
	let r = H(e, {
		x: 0,
		y: 0,
		rotation: 0,
		flip: !1
	}), i = H(e, t), a = Math.max(...r.map((e) => e.x + 1)) * 100, o = Math.max(...r.map((e) => e.y + 1)) * 100, s = (Math.max(...i.map((e) => e.x)) - t.x + 1) * 100, c = (Math.max(...i.map((e) => e.y)) - t.y + 1) * 100;
	return /* @__PURE__ */ y("g", {
		className: "kalypso-preview",
		style: { transform: `translate(${t.x * 100 + s / 2}px,${t.y * 100 + c / 2}px) rotate(${n * 90}deg) scaleX(${t.flip ? -1 : 1})` },
		children: /* @__PURE__ */ y("g", {
			transform: `translate(${-a / 2} ${-o / 2})`,
			children: e.kind === "boat" ? /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("rect", {
				x: "2",
				y: "2",
				width: a - 4,
				height: o - 4,
				rx: "10",
				fill: "#fffbd3",
				fillOpacity: ".3",
				stroke: "#fffbd3",
				strokeWidth: "8"
			}), /* @__PURE__ */ y(wt, {
				width: a,
				height: o
			})] }) : r.map((t, n) => /* @__PURE__ */ b("g", {
				transform: `translate(${t.x * 100} ${t.y * 100})`,
				children: [/* @__PURE__ */ y("rect", {
					x: "2",
					y: "2",
					width: "96",
					height: "96",
					fill: vt[t.material],
					stroke: "#fffbd3",
					strokeWidth: "8"
				}), e.kind === "net" || e.kind === "garden" ? /* @__PURE__ */ y(Z, { kind: e.kind }) : /* @__PURE__ */ y(yt, { material: t.material })]
			}, n))
		})
	});
}
function kt({ board: e, eligible: t, onPick: n, preview: o, rotationTurns: s = o?.rotation ?? 0, buildingPreview: l, job: u, fitKey: d, selectedRings: f = [], controls: p }) {
	let m = c(), h = e, g = a(null), _ = a(null);
	r(() => {
		let e = d.split("-")[0], t = [...g.current?.querySelectorAll("[data-kalypso-arrival]") ?? []], n = _.current;
		if (n?.board === e && !matchMedia("(prefers-reduced-motion: reduce)").matches) for (let e of t) n.ids.has(e.dataset.kalypsoArrival) || e.animate([{
			opacity: .35,
			translate: "0 -14px"
		}, {
			opacity: 1,
			translate: "0 0"
		}], {
			duration: 240,
			easing: "cubic-bezier(.2,.8,.3,1)"
		});
		_.current = {
			board: e,
			ids: new Set(t.map((e) => e.dataset.kalypsoArrival))
		};
	}, [h, d]);
	let ee = [...h.cells, ...h.boats.flatMap((e) => e.cells)], v = Math.min(-.7, ...ee.map((e) => e.x - .4)), ne = Math.min(-.7, ...ee.map((e) => e.y - .4)), re = Math.max(h.size + .7, ...ee.map((e) => e.x + 1.4)), x = Math.max(h.size + .7, ...ee.map((e) => e.y + 1.4)), S = -v * 100, C = -ne * 100, ie = B(h), T = t.map((e) => ({
		key: M(e),
		rect: {
			x: e.x * 100 + S,
			y: e.y * 100 + C,
			w: 100,
			h: 100
		}
	})), E = j[h.size].fish.filter((e) => !ie.has(e)), ae = i(() => Array.from({ length: h.size + 1 }, (e, t) => t), [h.size]), D = u && o ? H(u, o) : l && o ? Array.from({ length: l.kind === "monument" || l.kind === "sanctuary" ? 3 : 2 }, (e, t) => ({
		x: o.x + t,
		y: o.y + t
	})) : [], O = D.length ? {
		x: Math.min(...D.map((e) => e.x)) * 100,
		y: Math.min(...D.map((e) => e.y)) * 100,
		w: (Math.max(...D.map((e) => e.x)) - Math.min(...D.map((e) => e.x)) + 1) * 100,
		h: (Math.max(...D.map((e) => e.y)) - Math.min(...D.map((e) => e.y)) + 1) * 100
	} : null;
	return /* @__PURE__ */ b("div", {
		ref: g,
		className: "kalypso-board",
		role: "group",
		"aria-label": m("games.kalypso.viewMap"),
		children: [/* @__PURE__ */ y(te, {
			sheetW: (re - v) * 100,
			sheetH: (x - ne) * 100,
			fitKey: d,
			eligible: T,
			onTapEligible: (e) => n(N(e)),
			highlight: "off",
			children: /* @__PURE__ */ b("g", {
				transform: `translate(${S} ${C})`,
				children: [
					/* @__PURE__ */ y("rect", {
						x: -20,
						y: -20,
						width: h.size * 100 + 40,
						height: h.size * 100 + 40,
						rx: "12",
						fill: "#62b6ca",
						stroke: "#3e8c9e",
						strokeWidth: "5"
					}),
					/* @__PURE__ */ y("rect", {
						width: h.size * 100,
						height: h.size * 100,
						fill: "#80cbd8"
					}),
					Array.from({ length: h.size * 2 }, (e, t) => /* @__PURE__ */ y("path", {
						d: `M${t * 317 % (h.size * 100)} ${t * 50}q60-30 120 0t120 0`,
						fill: "none",
						stroke: "#9bd8ce",
						opacity: ".25",
						strokeWidth: "8"
					}, t)),
					ae.map((e) => /* @__PURE__ */ y("g", {
						stroke: e % 4 == 0 ? "#edf6e7" : "#c5e5e3",
						strokeWidth: e % 4 == 0 ? 4 : 1.5,
						children: /* @__PURE__ */ y("path", { d: `M${e * 100} 0v${h.size * 100}M0 ${e * 100}h${h.size * 100}` })
					}, e)),
					ae.slice(0, -1).map((e) => /* @__PURE__ */ b("g", {
						fill: "#376d7b",
						textAnchor: "middle",
						fontSize: "34",
						fontWeight: "700",
						children: [/* @__PURE__ */ y("text", {
							x: e * 100 + 50,
							y: -34,
							children: e + 1
						}), /* @__PURE__ */ y("text", {
							x: -42,
							y: e * 100 + 64,
							children: e + 1
						})]
					}, e)),
					h.size === 20 && /* @__PURE__ */ y("circle", {
						cx: "1000",
						cy: "1000",
						r: "25",
						fill: "#e9edda",
						opacity: ".8"
					}),
					E.map((e) => {
						let t = N(e);
						return /* @__PURE__ */ y("g", {
							transform: `translate(${t.x * 100 + 12} ${t.y * 100 + 12}) scale(.76)`,
							children: /* @__PURE__ */ y(bt, { claimed: h.fishClaimed.includes(e) })
						}, e);
					}),
					h.barrels.map((e) => {
						let t = N(e);
						return /* @__PURE__ */ y("g", {
							opacity: ".75",
							transform: `translate(${t.x * 100} ${t.y * 100})`,
							children: /* @__PURE__ */ y(yt, { material: "wild" })
						}, e);
					}),
					h.rings.map((e) => {
						let t = N(e);
						return /* @__PURE__ */ b("g", {
							transform: `translate(${t.x * 100} ${t.y * 100})`,
							children: [/* @__PURE__ */ y(xt, {}), f.includes(e) && /* @__PURE__ */ y("path", {
								d: "M20 50l22 22 38-42",
								stroke: "#fff",
								strokeWidth: "12",
								fill: "none"
							})]
						}, e);
					}),
					h.cells.map((e) => /* @__PURE__ */ b("g", {
						"data-kalypso-arrival": `cell-${M(e)}`,
						"data-kalypso-occupied": !0,
						transform: `translate(${e.x * 100} ${e.y * 100})`,
						children: [/* @__PURE__ */ y("rect", {
							x: "1",
							y: "1",
							width: "98",
							height: "98",
							fill: vt[e.material],
							stroke: "#466d65",
							strokeWidth: "2"
						}), e.material !== "island" && /* @__PURE__ */ y(yt, { material: e.material })]
					}, M(e))),
					h.size === 40 && /* @__PURE__ */ b("g", {
						transform: "translate(1800 1800)",
						children: [
							/* @__PURE__ */ y("path", {
								d: "m45 300 8-205 75-40 72 25 75-25 72 50 11 198-148 55z",
								fill: "#9fae88",
								stroke: "#53796d",
								strokeWidth: "12"
							}),
							/* @__PURE__ */ y("path", {
								d: "m62 122 67-38 72 20 72-20 58 37-89 57-66 0z",
								fill: "#e7d6aa"
							}),
							/* @__PURE__ */ y("path", {
								d: "M180 164v160m45-155v150M92 165l-9 105m222-100 12 101",
								fill: "none",
								stroke: "#698e7b",
								strokeWidth: "14"
							})
						]
					}),
					h.size === 40 && [18, 21].map((e) => /* @__PURE__ */ y("rect", {
						x: e * 100 + 8,
						y: 1908,
						width: "84",
						height: "184",
						rx: "12",
						fill: "#acc49a",
						fillOpacity: ".6",
						stroke: "#edf1cf",
						strokeWidth: "5",
						strokeDasharray: "12 8"
					}, e)),
					h.boats.map((e) => {
						let t = e.cells.map((e) => e.x), n = e.cells.map((e) => e.y), r = Math.min(...t) * 100, i = Math.min(...n) * 100, a = (Math.max(...t) - Math.min(...t) + 1) * 100, o = (Math.max(...n) - Math.min(...n) + 1) * 100;
						return /* @__PURE__ */ b("g", {
							"data-kalypso-arrival": `boat-${e.id}`,
							"data-kalypso-occupied": !0,
							transform: a > o ? `translate(${r} ${i})` : `translate(${r + a} ${i}) rotate(90)`,
							children: [/* @__PURE__ */ y(wt, {
								width: Math.max(a, o),
								height: Math.min(a, o)
							}), !e.docked && /* @__PURE__ */ y("circle", {
								cx: "40",
								cy: "45",
								r: "12",
								fill: "#eef5dd",
								stroke: "#537b77",
								strokeWidth: "4"
							})]
						}, e.id);
					}),
					h.nets.map((e) => /* @__PURE__ */ y("g", {
						"data-kalypso-arrival": `net-${e.id}`,
						"data-kalypso-occupied": !0,
						opacity: e.stacked ? .55 : .8,
						children: e.cells.map((e, t) => /* @__PURE__ */ y("g", {
							transform: `translate(${e.x * 100} ${e.y * 100})`,
							children: /* @__PURE__ */ y(Z, { kind: "net" })
						}, t))
					}, e.id)),
					h.gardens.map((e) => /* @__PURE__ */ y("g", {
						"data-kalypso-arrival": `garden-${e.id}`,
						"data-kalypso-occupied": !0,
						children: e.cells.map((e, t) => /* @__PURE__ */ y("g", {
							transform: `translate(${e.x * 100} ${e.y * 100})`,
							children: /* @__PURE__ */ y(Z, { kind: "garden" })
						}, t))
					}, e.id)),
					h.buildings.map((e) => {
						let t = e.kind === "monument" || e.kind === "sanctuary" ? 3 : 2;
						return /* @__PURE__ */ b("g", {
							"data-kalypso-arrival": `building-${e.id}`,
							"data-kalypso-occupied": !0,
							transform: `translate(${e.x * 100} ${e.y * 100})`,
							children: [
								/* @__PURE__ */ y("title", { children: m(w[e.kind].key) }),
								/* @__PURE__ */ y("rect", {
									x: "4",
									y: "4",
									width: t * 100 - 8,
									height: t * 100 - 8,
									rx: "9",
									fill: vt[e.material],
									stroke: "#f0e7ca",
									strokeWidth: "6"
								}),
								/* @__PURE__ */ y("g", {
									transform: `scale(${t})`,
									children: /* @__PURE__ */ y(St, { kind: e.kind })
								}),
								e.resident && /* @__PURE__ */ b("g", {
									transform: `translate(${t * 100 - 42} 12)`,
									children: [/* @__PURE__ */ y("circle", {
										cx: "0",
										cy: "0",
										r: "15",
										fill: "#ffe7a0",
										stroke: "#785d39",
										strokeWidth: "4"
									}), /* @__PURE__ */ y("path", {
										d: "m0 13-24 24h13l-8 24h14V44h11v17h14l-8-24h13z",
										fill: "#ffe7a0",
										stroke: "#785d39",
										strokeWidth: "4"
									})]
								})
							]
						}, e.id);
					}),
					t.map((e) => /* @__PURE__ */ b("g", {
						pointerEvents: "none",
						children: [/* @__PURE__ */ y("circle", {
							cx: e.x * 100 + 50,
							cy: e.y * 100 + 50,
							r: "14",
							fill: "#edf9ed",
							stroke: "#267f99",
							strokeWidth: "5"
						}), /* @__PURE__ */ y("circle", {
							cx: e.x * 100 + 50,
							cy: e.y * 100 + 50,
							r: "4",
							fill: "#267f99"
						})]
					}, `hit-${M(e)}`)),
					u && o && /* @__PURE__ */ y(Ot, {
						job: u,
						pose: o,
						turns: s
					}, `${u.kind}-${u.id}`),
					l && o && (() => {
						let e = l.kind === "monument" || l.kind === "sanctuary" ? 3 : 2;
						return /* @__PURE__ */ b("g", {
							transform: `translate(${o.x * 100} ${o.y * 100})`,
							opacity: ".75",
							children: [/* @__PURE__ */ y("rect", {
								x: "4",
								y: "4",
								width: e * 100 - 8,
								height: e * 100 - 8,
								rx: "9",
								fill: vt[l.material],
								stroke: "#fffbd3",
								strokeWidth: "10"
							}), /* @__PURE__ */ y("g", {
								transform: `scale(${e})`,
								children: /* @__PURE__ */ y(St, { kind: l.kind })
							})]
						});
					})(),
					O && /* @__PURE__ */ y("rect", {
						"data-kalypso-focus": !0,
						x: O.x,
						y: O.y,
						width: O.w,
						height: O.h,
						fill: "none",
						pointerEvents: "none"
					})
				]
			})
		}), o && p && /* @__PURE__ */ y(Dt, {
			host: g,
			children: p
		})]
	});
}
//#endregion
//#region src/games/kalypso/labels.ts
var $ = {
	tile: "games.kalypso.item.tile",
	scrap: "games.kalypso.item.scrap",
	barrel: "games.kalypso.item.barrel",
	boat: "games.kalypso.item.boat",
	garden: "games.kalypso.item.garden",
	net: "games.kalypso.item.net",
	fish: "games.kalypso.item.fish",
	house: "games.kalypso.item.house",
	expert: "games.kalypso.item.expert",
	catch: "games.kalypso.item.catch"
}, At = {
	barrel: $.barrel,
	garden: $.garden,
	fish: $.fish,
	survivor: "games.kalypso.survivors",
	scrap: $.scrap,
	boat: $.boat,
	net: $.net,
	house: $.house
}, jt = {
	competitive: "games.kalypso.mode.competitive",
	cooperative: "games.kalypso.mode.cooperative",
	solo: "games.kalypso.mode.solo"
}, Mt = {
	learning: "games.kalypso.difficulty.learning",
	easy: "games.kalypso.difficulty.easy",
	medium: "games.kalypso.difficulty.medium",
	hard: "games.kalypso.difficulty.hard"
}, Nt = {
	sun: "games.kalypso.weatherNeed.sun",
	rain: "games.kalypso.weatherNeed.rain",
	dock: "games.kalypso.weatherNeed.dock",
	drought: "games.kalypso.weatherNeed.drought",
	hatches: "games.kalypso.weatherNeed.hatches",
	teeth: "games.kalypso.weatherNeed.teeth",
	storm: "games.kalypso.weatherNeed.storm"
}, Pt = {
	sun: "games.kalypso.weatherNeedCoop.sun",
	rain: "games.kalypso.weatherNeedCoop.rain",
	dock: "games.kalypso.weatherNeedCoop.dock",
	drought: "games.kalypso.weatherNeedCoop.drought",
	hatches: "games.kalypso.weatherNeedCoop.hatches",
	teeth: "games.kalypso.weatherNeedCoop.teeth",
	storm: "games.kalypso.weatherNeedCoop.storm"
}, Ft = {
	sun: "games.kalypso.weatherReward.sun",
	rain: "games.kalypso.weatherReward.rain",
	dock: "games.kalypso.weatherReward.dock",
	drought: "games.kalypso.weatherReward.drought",
	hatches: "games.kalypso.weatherReward.hatches",
	teeth: "games.kalypso.weatherReward.teeth",
	storm: "games.kalypso.weatherReward.storm"
}, It = {
	sun: "games.kalypso.weatherRewardCoop.sun",
	rain: "games.kalypso.weatherRewardCoop.rain",
	dock: "games.kalypso.weatherRewardCoop.dock",
	drought: "games.kalypso.weatherRewardCoop.drought",
	hatches: "games.kalypso.weatherRewardCoop.hatches",
	teeth: "games.kalypso.weatherRewardCoop.teeth",
	storm: "games.kalypso.weatherRewardCoop.storm"
}, Lt = [
	"games.kalypso.goalRule.groups",
	"games.kalypso.goalRule.corners",
	"games.kalypso.goalRule.perimeter",
	"games.kalypso.goalRule.monuments",
	"games.kalypso.goalRule.enclosures",
	"games.kalypso.goalRule.lines",
	"games.kalypso.goalRule.sets",
	"games.kalypso.goalRule.empty",
	"games.kalypso.goalRule.full",
	"games.kalypso.goalRule.plastic"
], Rt = {
	buildings: "games.kalypso.score.buildings",
	monuments: "games.kalypso.score.monuments",
	gardens: "games.kalypso.score.gardens",
	survivors: "games.kalypso.score.survivors",
	fish: "games.kalypso.score.fish",
	solar: "games.kalypso.score.solar",
	goals: "games.kalypso.score.goals",
	weather: "games.kalypso.score.weather",
	total: "games.kalypso.score.total"
}, zt = {
	initial: "games.kalypso.phase.initial",
	weather: "games.kalypso.phase.weather",
	expand: "games.kalypso.phase.expand",
	captain: "games.kalypso.phase.captain",
	ended: "games.kalypso.phase.ended"
}, Bt = {
	weather: "games.kalypso.reason.weather",
	housing: "games.kalypso.reason.housing",
	fish: "games.kalypso.reason.fish",
	gardens: "games.kalypso.reason.gardens",
	goals: "games.kalypso.reason.goals"
};
//#endregion
//#region src/games/kalypso/info.tsx
function Vt({ value: e, children: t }) {
	let r = a(null), i = a(e);
	return n(() => {
		i.current !== e && !matchMedia("(prefers-reduced-motion: reduce)").matches && r.current?.animate([{
			opacity: .4,
			translate: "0 5px"
		}, {
			opacity: 1,
			translate: "0 0"
		}], {
			duration: 220,
			easing: "ease-out"
		}), i.current = e;
	}, [e]), /* @__PURE__ */ y("b", {
		ref: r,
		children: t ?? e
	});
}
function Ht({ pub: e }) {
	let t = c(), n = e.boards[0], r = G(n).residents, i = n.gardens.length + e.gardenBonus;
	return /* @__PURE__ */ b("div", {
		className: "kalypso-resource-track",
		children: [
			/* @__PURE__ */ b("div", { children: [/* @__PURE__ */ y(Q, { kind: "resident" }), /* @__PURE__ */ b("span", { children: [t("games.kalypso.survivors"), /* @__PURE__ */ y(Vt, { value: e.islandSurvivors })] })] }),
			/* @__PURE__ */ b("div", { children: [/* @__PURE__ */ y(Q, { kind: "fish" }), /* @__PURE__ */ b("span", { children: [t("games.kalypso.foodNeed"), /* @__PURE__ */ y(Vt, { value: `${e.fish} / ${r * 2}` })] })] }),
			/* @__PURE__ */ b("div", { children: [/* @__PURE__ */ y(Q, { kind: "garden" }), /* @__PURE__ */ b("span", { children: [
				t("games.kalypso.gardens"),
				" · ",
				i,
				/* @__PURE__ */ y(Vt, {
					value: i,
					children: t("games.kalypso.peopleCapacity", { n: le[Math.min(i, le.length - 1)] })
				})
			] })] }),
			/* @__PURE__ */ b("div", { children: [/* @__PURE__ */ y(Q, { kind: "solar" }), /* @__PURE__ */ b("span", { children: [
				t("games.kalypso.solar"),
				" · ",
				e.solarBonus,
				/* @__PURE__ */ y(Vt, {
					value: e.solarBonus,
					children: t("games.kalypso.boatCapacity", { n: A[Math.min(e.solarBonus, A.length - 1)] })
				})
			] })] })
		]
	});
}
var Ut = {
	barrel: "barrel",
	garden: "garden",
	fish: "fish",
	survivor: "resident",
	scrap: "metal",
	boat: "boat",
	net: "net",
	house: "house"
};
function Wt({ weather: e, cooperative: t, event: n, onChoose: r }) {
	let i = c(), a = Ke(e, t, n?.paid), o = /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ b("header", { children: [
		/* @__PURE__ */ y(Ct, { weather: e }),
		/* @__PURE__ */ y("strong", { children: i(E[e]) }),
		n?.complete && /* @__PURE__ */ y("span", {
			"aria-label": i("games.kalypso.completed"),
			children: "✓"
		})
	] }), /* @__PURE__ */ b("div", {
		className: "kalypso-weather-body",
		children: [
			/* @__PURE__ */ y("p", { children: i((t ? Pt : Nt)[e]) }),
			/* @__PURE__ */ y("div", {
				className: "kalypso-weather-needs",
				children: Object.entries(a).map(([e, t]) => /* @__PURE__ */ b("span", { children: [
					/* @__PURE__ */ y(Q, { kind: Ut[e] }),
					/* @__PURE__ */ y("b", { children: n ? `${n.paid[e]} / ${t}` : `× ${t}` }),
					/* @__PURE__ */ y("span", {
						className: "sr-only",
						children: i(At[e])
					})
				] }, e))
			}),
			/* @__PURE__ */ y("p", {
				className: "kalypso-muted",
				children: i((t ? It : Ft)[e])
			})
		]
	})] });
	return r ? /* @__PURE__ */ y("button", {
		type: "button",
		className: "kalypso-weather-card",
		"aria-label": i(E[e]),
		onClick: r,
		children: o
	}) : /* @__PURE__ */ y("section", {
		className: `kalypso-weather-card${n?.complete ? " kalypso-complete" : ""}`,
		children: o
	});
}
function Gt({ pub: e, rid: t, nameOf: n }) {
	let r = c(), i = e.players.find((e) => e.rid === t) ?? e.players[0], a = e.boards[i.board], o = e.config.mode !== "competitive";
	return /* @__PURE__ */ b("div", {
		className: "kalypso-info-content",
		children: [
			o && /* @__PURE__ */ y(Ht, { pub: e }),
			/* @__PURE__ */ y("h3", { children: r("games.kalypso.weatherTitle") }),
			(o ? e.players : [i]).map((t) => {
				let r = t.events.find((t) => t.round === e.round);
				return r && /* @__PURE__ */ b("div", { children: [o && /* @__PURE__ */ y("h4", { children: n(t.rid) }), /* @__PURE__ */ y(Wt, {
					weather: r.weather,
					event: r,
					cooperative: o
				})] }, t.rid);
			}),
			/* @__PURE__ */ y("h3", { children: r("games.kalypso.goalsTitle") }),
			e.goals.map((t) => {
				let n = mt(a, t, e.players.length);
				return /* @__PURE__ */ b("div", {
					className: "kalypso-goal-card",
					children: [/* @__PURE__ */ y(Q, { kind: t === 3 ? "monument" : t === 4 ? "fish" : t === 9 ? "plastic" : t === 8 ? "garden" : "house" }), /* @__PURE__ */ b("div", { children: [
						/* @__PURE__ */ y("strong", { children: r(k[t]) }),
						/* @__PURE__ */ b("details", { children: [/* @__PURE__ */ y("summary", { children: r("games.kalypso.goalDetails") }), /* @__PURE__ */ y("p", { children: r(Lt[t]) })] }),
						/* @__PURE__ */ y("b", { children: o ? `${n.met ? "✓ " : ""}${r(t === 9 ? "games.kalypso.plasticTarget" : "games.kalypso.target", {
							n: n.value,
							target: n.target
						})}` : `${n.vp} VP` })
					] })]
				}, t);
			}),
			o && e.experts.length > 0 && /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("h3", { children: r("games.kalypso.expertsTitle") }), e.experts.map((e) => /* @__PURE__ */ b("div", {
				className: "kalypso-notice",
				children: [/* @__PURE__ */ b("strong", { children: ["✓ ", r(D[e])] }), /* @__PURE__ */ y("p", { children: r(O[e]) })]
			}, e))] }),
			/* @__PURE__ */ y("h3", { children: r("games.kalypso.supply") }),
			/* @__PURE__ */ b("div", {
				className: "kalypso-progress",
				children: [
					/* @__PURE__ */ b("span", { children: [/* @__PURE__ */ y(Q, { kind: "wood" }), e.supply.tiles] }),
					/* @__PURE__ */ b("span", { children: [/* @__PURE__ */ y(Q, { kind: "metal" }), e.supply.scraps] }),
					/* @__PURE__ */ b("span", { children: [/* @__PURE__ */ y(Q, { kind: "barrel" }), e.supply.barrels] }),
					/* @__PURE__ */ b("span", { children: [/* @__PURE__ */ y(Q, { kind: "boat" }), e.supply.boats] }),
					/* @__PURE__ */ b("span", { children: [/* @__PURE__ */ y(Q, { kind: "garden" }), e.supply.gardenNets] })
				]
			}),
			/* @__PURE__ */ b("details", {
				className: "kalypso-history-details",
				children: [/* @__PURE__ */ y("summary", { children: r("games.kalypso.history") }), /* @__PURE__ */ y("div", {
					className: "kalypso-history",
					children: e.log.slice(-30).reverse().map((e, t) => {
						let i = {
							place: "games.kalypso.log.place",
							build: "games.kalypso.log.build",
							rescue: "games.kalypso.log.rescue",
							fish: "games.kalypso.log.fish",
							weather: "games.kalypso.log.weather",
							round: "games.kalypso.log.round",
							expert: "games.kalypso.log.expert",
							donate: "games.kalypso.log.donate",
							move: "games.kalypso.log.move"
						}, a = e.kind === "build" ? w[e.detail]?.key : e.kind === "weather" ? E[e.detail] : e.kind === "expert" ? D[e.detail] : void 0;
						return /* @__PURE__ */ b("p", { children: [
							n(e.rid),
							" · ",
							r(i[e.kind], {
								n: e.n,
								name: a ? r(a) : ""
							})
						] }, t);
					})
				})]
			})
		]
	});
}
//#endregion
//#region src/games/kalypso/view-player.tsx
function Kt(e) {
	m();
	let t = c(), n = s((e) => e.locale), r = e.public, a = e.private, [l, u] = o(e.myRid), [d, te] = o(-1), [ne, re] = o(0), [x, S] = o(!1), [ie, T] = o(null), [E, k] = o(null), [oe, se] = o(!1), [ce, le] = o(!1), [ue, de] = o(0), [j, M] = o(!1), [N, P] = o([]), [F, I] = o(null), [L, R] = o(!1), z = r.players.find((t) => t.rid === e.myRid) ?? r.players[0], B = r.players.find((e) => e.rid === l) ?? z, V = r.boards[B.board], H = r.config.mode !== "competitive", fe = H || B.rid === e.myRid, U = fe && !z.ready && r.phase !== "ended" && r.phase !== "weather", pe = a?.jobs ?? [], W = pe.find((e) => e.id === d) ?? pe[0] ?? null, he = E ? `build-${E.kind}-${E.material}` : F === null ? W ? `job-${W.id}` : "" : `move-${F}`, G = ie?.target === he ? {
		...ie.point,
		rotation: ne % 4,
		flip: x
	} : null, ye = i(() => ({
		initial: r.phase === "initial" && !z.initialDone,
		usedSides: r.players.flatMap((e) => e.initialSide === null ? [] : [e.initialSide]),
		experts: r.experts,
		orientation: {
			rotation: ne % 4,
			flip: x
		}
	}), [
		r.phase,
		z.initialDone,
		r.players,
		r.experts,
		ne,
		x
	]), be = i(() => U ? ge(V, z.recent, r.experts) : [], [
		U,
		V,
		z.recent,
		r.experts
	]), xe = i(() => be.filter((e) => e.kind === "monument" || e.kind === "sanctuary" ? r.supply.monuments > 0 : r.supply.buildings[e.material] > 0), [be, r.supply]), Se = i(() => U ? E ? xe.filter((e) => e.kind === E.kind && e.material === E.material) : F === null ? W?.kind === "boat" && H && !W.unlimited && V.boats.length >= A[Math.min(r.solarBonus, A.length - 1)] ? [] : W && [
		"tile",
		"scrap",
		"barrel",
		"boat",
		"garden",
		"net"
	].includes(W.kind) ? me(V, W, ye) : [] : V.boats.find((e) => e.id === F) ? me({
		...V,
		boats: V.boats.filter((e) => e.id !== F)
	}, {
		id: 0,
		kind: "boat"
	}, ye).filter((e) => _e(V, F, e)) : [] : [], [
		U,
		E,
		xe,
		F,
		V,
		ye,
		W,
		H,
		r.solarBonus
	]), Ce = W?.kind === "house" ? V.buildings.filter((e) => !e.resident && e.kind !== "monument" && e.kind !== "sanctuary" && (e.kind !== "house" || H && e.builtRound === r.round && z.events.some((e) => e.round === r.round && e.weather === "sun" && !e.complete))) : [], we = U && W?.kind === "house" && !E ? Ce.map((e) => ({
		x: e.x,
		y: e.y
	})) : Se, Te = G && Se.some((e) => e.x === G.x && e.y === G.y), Ee = (t) => {
		let r = e.members.find((e) => e.rid === t);
		return r ? ee(r, n) : t;
	}, K = (t) => {
		e.send(t), T(null), k(null), se(!1), I(null), P([]);
	}, De = (e) => {
		if (W?.kind === "house" && !E) {
			let t = Ce.find((t) => t.x === e.x && t.y === e.y);
			t && K({
				type: "house",
				job: W.id,
				building: t.id
			});
			return;
		}
		T({
			target: he,
			point: e
		});
	}, Oe = () => {
		G && Te && (E ? K({
			type: "build",
			...G,
			...E,
			reverse: j,
			rings: N
		}) : F === null ? W && K({
			type: "place",
			job: W.id,
			...G
		}) : K({
			type: "move",
			boat: F,
			...G
		}));
	}, ke = (e) => {
		te(e.id), k(null), I(null), T(null);
	}, Ae = r.experts.includes("salvager") && r.step > (r.config.mode === "solo" ? 5 : 4), je = r.phase === "captain" || (r.phase === "initial" ? z.initialDone : z.drafted || Ae), Me = U && !pe.length && je, Ne = r.phase === "weather" ? !z.weatherChosen : !z.ready, Pe = W && [
		"barrel",
		"garden",
		"fish",
		"scrap",
		"boat",
		"net"
	].includes(W.kind) ? (H ? r.players : [z]).filter((e) => {
		let t = e.events.find((e) => e.round === r.round);
		return t && Ye(t, W.kind, H);
	}) : [], Fe = z.events.find((e) => e.round === r.round), Ie = r.solarBonus, Le = W?.kind === "boat" && H && !W.unlimited && V.boats.length >= A[Math.min(Ie, A.length - 1)], Re = W && (W.kind === "house" || W.kind === "expert" && r.experts.length === 5 || Le || [
		"tile",
		"scrap",
		"barrel",
		"boat",
		"garden",
		"net"
	].includes(W.kind) && !me(V, W, {
		...ye,
		orientation: void 0
	}, 1).length), q = xe.filter((e, t, n) => n.findIndex((t) => t.kind === e.kind && t.material === e.material) === t), J = E ? t("games.kalypso.selectPosition") : W?.kind === "house" ? t("games.kalypso.chooseResident") : W?.kind === "expert" ? t("games.kalypso.chooseExpert") : W?.kind === "catch" ? t("games.kalypso.chooseReturn") : W?.kind === "fish" ? "" : W && Se.length ? t("games.kalypso.selectPosition") : W ? t("games.kalypso.noSpace") : "";
	return /* @__PURE__ */ y(h, {
		adaptive: !0,
		scroll: !1,
		className: "kalypso-screen",
		actionsHeight: "kalypso-action-slot",
		banner: /* @__PURE__ */ b("div", {
			className: "kalypso-banner",
			children: [/* @__PURE__ */ y(g, {
				tone: Ne ? "accent" : "info",
				accent: ve.accent,
				text: t(Ne ? zt[r.phase] : "games.kalypso.waiting"),
				chip: t("games.kalypso.round", { n: r.round })
			}), /* @__PURE__ */ y("div", {
				className: "kalypso-players",
				children: e.members.filter((e) => r.players.some((t) => t.rid === e.rid)).map((t) => /* @__PURE__ */ b("button", {
					type: "button",
					className: `kalypso-player${B.rid === t.rid ? " kalypso-selected" : ""}`,
					onClick: () => {
						u(t.rid), k(null), I(null), T(null);
					},
					children: [/* @__PURE__ */ y(_, {
						m: t,
						myRid: e.myRid,
						action: r.players.find((e) => e.rid === t.rid)?.ready ? "done" : "pending",
						anchorName: null,
						box: "kalypso-avatar",
						img: "kalypso-avatar-img"
					}), /* @__PURE__ */ y("span", { children: ee(t, n) })]
				}, t.rid))
			})]
		}),
		actions: /* @__PURE__ */ y("div", {
			className: "kalypso-actions",
			children: r.phase === "weather" ? /* @__PURE__ */ b("div", {
				className: "kalypso-hand",
				children: [/* @__PURE__ */ y(Q, { kind: "sun" }), z.weatherChosen ? /* @__PURE__ */ y("p", { children: t("games.kalypso.waiting") }) : /* @__PURE__ */ y("button", {
					className: "btn-base kalypso-primary",
					onClick: () => R(!0),
					children: t(zt.weather)
				})]
			}) : /* @__PURE__ */ b(v, { children: [
				/* @__PURE__ */ b("div", {
					className: "kalypso-hand",
					children: [
						pe.length > 0 && /* @__PURE__ */ y("span", {
							className: "kalypso-hand-label",
							children: t("games.kalypso.pendingItems")
						}),
						!z.drafted && r.phase !== "captain" && U && z.hand.map((e) => /* @__PURE__ */ y("button", {
							className: "kalypso-piece-choice",
							onClick: () => K({
								type: "choose",
								tile: e
							}),
							"aria-label": t("games.kalypso.chooseTile"),
							children: /* @__PURE__ */ y(Tt, { job: {
								id: 0,
								kind: "tile",
								tile: e
							} })
						}, e)),
						pe.map((e) => /* @__PURE__ */ y("button", {
							className: `kalypso-piece-choice${e.id === W?.id && !E ? " kalypso-selected" : ""}`,
							onClick: () => ke(e),
							disabled: !U,
							title: t($[e.kind]),
							"aria-label": t($[e.kind]),
							children: [
								"tile",
								"scrap",
								"barrel",
								"boat",
								"garden",
								"net"
							].includes(e.kind) ? /* @__PURE__ */ y(Tt, { job: e }) : /* @__PURE__ */ b("span", { children: [e.kind === "fish" ? "🐟" : e.kind === "house" ? "🏠" : e.kind === "expert" ? "🛟" : "🐟", /* @__PURE__ */ b("small", { children: [t($[e.kind]), e.kind === "fish" && ` · ${e.value}`] })] })
						}, e.id)),
						!pe.length && (z.drafted || r.phase === "captain" || z.ready) && /* @__PURE__ */ y("span", {
							className: "kalypso-step-readout",
							children: t(z.ready ? "games.kalypso.waiting" : r.phase === "initial" ? "games.kalypso.completed" : r.phase === "captain" ? "games.kalypso.moveBoat" : "games.kalypso.step", { n: r.step })
						})
					]
				}),
				!G && Me && /* @__PURE__ */ y("button", {
					className: "btn-base kalypso-primary",
					onClick: () => K({ type: "ready" }),
					children: t(r.phase === "captain" ? "games.kalypso.finishRound" : "games.kalypso.ready")
				}),
				U && !E && W?.kind === "fish" && /* @__PURE__ */ b("button", {
					className: "btn-base kalypso-primary",
					onClick: () => K({
						type: "catch",
						job: W.id,
						returnIndex: 0
					}),
					children: [
						t("games.kalypso.claimFish"),
						" · ",
						W.value
					]
				}),
				U && !E && Re && W && /* @__PURE__ */ y("button", {
					className: "btn-quiet",
					onClick: () => K({
						type: "discard",
						job: W.id
					}),
					children: t(W.kind === "house" ? "games.kalypso.skipHouse" : "games.kalypso.discard")
				})
			] })
		}),
		overlay: U && J && !G ? /* @__PURE__ */ y("div", {
			className: "kalypso-hint",
			children: J
		}) : void 0,
		children: /* @__PURE__ */ b("div", {
			className: "kalypso-table",
			children: [
				/* @__PURE__ */ b("div", {
					className: "kalypso-map-area",
					children: [
						/* @__PURE__ */ y(kt, {
							board: V,
							eligible: we,
							onPick: De,
							preview: G,
							rotationTurns: ne,
							buildingPreview: E,
							job: E ? null : F === null ? W : {
								id: 0,
								kind: "boat"
							},
							fitKey: `${B.board}-${ue}`,
							selectedRings: N,
							controls: U && G ? /* @__PURE__ */ b(v, { children: [
								/* @__PURE__ */ y("button", {
									className: "btn-quiet",
									onClick: () => re((e) => e + 1),
									disabled: !he || !!E,
									"aria-label": t("games.kalypso.rotate"),
									children: /* @__PURE__ */ y(p, { size: 21 })
								}),
								/* @__PURE__ */ y("button", {
									className: "btn-quiet",
									onClick: () => S((e) => !e),
									disabled: W?.kind !== "tile" || !!E,
									"aria-label": t("games.kalypso.flip"),
									children: /* @__PURE__ */ y(f, { size: 21 })
								}),
								/* @__PURE__ */ y("button", {
									className: "btn-quiet",
									onClick: () => E ? k(null) : se(!0),
									children: t(E ? "games.kalypso.cancel" : "games.kalypso.build")
								}),
								/* @__PURE__ */ y("button", {
									className: "btn-base kalypso-primary",
									disabled: !Te,
									onClick: Oe,
									children: t("games.kalypso.confirm")
								})
							] }) : void 0
						}),
						/* @__PURE__ */ b("div", {
							className: "kalypso-map-caption",
							children: [
								H ? t("games.kalypso.sharedMap") : Ee(B.rid),
								" ",
								/* @__PURE__ */ b("span", { children: [
									V.size,
									" × ",
									V.size
								] })
							]
						}),
						/* @__PURE__ */ b("div", {
							className: "kalypso-map-controls",
							children: [
								/* @__PURE__ */ y("button", {
									className: "btn-quiet",
									onClick: () => de((e) => e + 1),
									children: t("games.kalypso.fullView")
								}),
								/* @__PURE__ */ y("button", {
									className: "btn-quiet",
									onClick: () => le(!0),
									children: t("games.kalypso.viewInfo")
								}),
								U && !G && /* @__PURE__ */ y("button", {
									className: "btn-quiet",
									onClick: () => se(!0),
									children: t("games.kalypso.build")
								})
							]
						}),
						!H && /* @__PURE__ */ b("div", {
							className: "kalypso-personal-stats",
							children: [
								/* @__PURE__ */ b("span", { children: [/* @__PURE__ */ y(Q, { kind: "resident" }), /* @__PURE__ */ y(Vt, { value: B.survivors })] }),
								/* @__PURE__ */ b("span", { children: [/* @__PURE__ */ y(Q, { kind: "fish" }), /* @__PURE__ */ y(Vt, { value: B.fishCount })] }),
								fe && /* @__PURE__ */ b("span", { children: [
									t("games.kalypso.personalFish"),
									" ",
									/* @__PURE__ */ y(Vt, { value: a?.fish.reduce((e, t) => e + t, 0) ?? 0 })
								] })
							]
						}),
						/* @__PURE__ */ b("details", {
							className: "kalypso-action-detail",
							children: [/* @__PURE__ */ y("summary", { children: t("games.kalypso.moreActions") }), /* @__PURE__ */ b("div", { children: [
								U && !H && z.survivors > 0 && Fe && Ye(Fe, "survivor", !1) && /* @__PURE__ */ y("button", {
									className: "btn-quiet",
									onClick: () => K({
										type: "donate",
										job: null,
										to: z.rid
									}),
									children: t("games.kalypso.donateSurvivor")
								}),
								U && W && Pe.map((e) => /* @__PURE__ */ b("button", {
									className: "btn-quiet",
									onClick: () => K({
										type: "donate",
										job: W.id,
										to: e.rid
									}),
									children: [t("games.kalypso.donate"), H ? ` · ${Ee(e.rid)}` : ""]
								}, e.rid)),
								U && he && Se.length > 0 && /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ b("label", { children: ["X", /* @__PURE__ */ y("input", {
									"aria-label": "X",
									type: "number",
									value: G ? G.x + 1 : "",
									onChange: (e) => De({
										x: Number(e.target.value) - 1,
										y: G?.y ?? Se[0].y
									})
								})] }), /* @__PURE__ */ b("label", { children: ["Y", /* @__PURE__ */ y("input", {
									"aria-label": "Y",
									type: "number",
									value: G ? G.y + 1 : "",
									onChange: (e) => De({
										x: G?.x ?? Se[0].x,
										y: Number(e.target.value) - 1
									})
								})] })] }),
								(E || F !== null) && /* @__PURE__ */ y("button", {
									className: "btn-quiet",
									onClick: () => {
										k(null), I(null), T(null);
									},
									children: t("games.kalypso.cancel")
								})
							] })]
						})
					]
				}),
				/* @__PURE__ */ y("aside", {
					className: "kalypso-sidebar",
					children: /* @__PURE__ */ y(Gt, {
						pub: r,
						rid: B.rid,
						nameOf: Ee
					})
				}),
				ce && /* @__PURE__ */ y("div", {
					className: "kalypso-modal",
					children: /* @__PURE__ */ b("div", {
						className: "kalypso-panel",
						children: [/* @__PURE__ */ y("button", {
							className: "btn-quiet kalypso-panel-close",
							onClick: () => le(!1),
							children: t("games.kalypso.close")
						}), /* @__PURE__ */ y(Gt, {
							pub: r,
							rid: B.rid,
							nameOf: Ee
						})]
					})
				}),
				oe && U && /* @__PURE__ */ b("div", {
					className: "kalypso-build-panel kalypso-panel",
					children: [
						/* @__PURE__ */ b("div", {
							className: "kalypso-panel-title",
							children: [/* @__PURE__ */ y("strong", { children: t("games.kalypso.build") }), /* @__PURE__ */ y("button", {
								className: "btn-quiet",
								onClick: () => se(!1),
								children: t("games.kalypso.close")
							})]
						}),
						/* @__PURE__ */ y("div", {
							className: "kalypso-build-choices",
							children: q.map((e) => /* @__PURE__ */ b("button", {
								className: `kalypso-build-choice${E?.kind === e.kind && E.material === e.material ? " kalypso-selected" : ""}`,
								onClick: () => {
									k(e), T(null), e.kind !== "sanctuary" && !r.experts.includes("carpenter") && se(!1);
								},
								children: [
									/* @__PURE__ */ y("svg", {
										viewBox: "0 0 100 100",
										"aria-hidden": !0,
										children: /* @__PURE__ */ y(St, { kind: e.kind })
									}),
									/* @__PURE__ */ y("strong", { children: t(w[e.kind].key) }),
									/* @__PURE__ */ y("span", { children: t(C[e.material]) }),
									/* @__PURE__ */ y("small", { children: t(w[e.kind].effect) })
								]
							}, `${e.kind}-${e.material}`))
						}),
						!q.length && /* @__PURE__ */ b("div", {
							className: "kalypso-build-help",
							children: [/* @__PURE__ */ y("p", { children: t(be.length ? "games.kalypso.noBuildingSupply" : "games.kalypso.noBuildings") }), !be.length && /* @__PURE__ */ y("p", { children: t("games.kalypso.buildRequirements") })]
						}),
						r.experts.includes("carpenter") && /* @__PURE__ */ b("label", {
							className: "kalypso-check",
							children: [/* @__PURE__ */ y("input", {
								type: "checkbox",
								checked: j,
								onChange: (e) => M(e.target.checked)
							}), t("games.kalypso.carpenterOrder")]
						}),
						E?.kind === "sanctuary" && /* @__PURE__ */ b("div", { children: [/* @__PURE__ */ y("p", { children: t("games.kalypso.sanctuaryRings") }), /* @__PURE__ */ y("div", {
							className: "kalypso-ring-choices",
							children: V.rings.map((e) => /* @__PURE__ */ b("label", {
								className: "kalypso-check",
								children: [/* @__PURE__ */ y("input", {
									type: "checkbox",
									checked: N.includes(e),
									disabled: !N.includes(e) && N.length >= 3,
									onChange: () => P((t) => t.includes(e) ? t.filter((t) => t !== e) : [...t, e])
								}), e.split(",").map(Number).map((e) => e + 1).join(", ")]
							}, e))
						})] }),
						E && /* @__PURE__ */ y("button", {
							className: "btn-base kalypso-primary kalypso-build-position",
							onClick: () => se(!1),
							children: t("games.kalypso.selectPosition")
						})
					]
				}),
				L && r.phase === "weather" && !z.weatherChosen && /* @__PURE__ */ y("div", {
					className: "kalypso-modal",
					children: /* @__PURE__ */ b("section", {
						className: "kalypso-panel kalypso-weather-panel",
						children: [/* @__PURE__ */ b("header", {
							className: "kalypso-panel-title",
							children: [/* @__PURE__ */ y("strong", { children: t(zt.weather) }), /* @__PURE__ */ y("button", {
								className: "btn-quiet",
								onClick: () => R(!1),
								children: t("games.kalypso.close")
							})]
						}), /* @__PURE__ */ y("div", {
							className: "kalypso-weather-choice",
							children: z.availableWeather.map((e) => /* @__PURE__ */ y(Wt, {
								weather: e,
								cooperative: H,
								onChoose: () => {
									K({
										type: "weather",
										weather: e
									}), R(!1);
								}
							}, e))
						})]
					})
				}),
				U && W?.kind === "expert" && !E && /* @__PURE__ */ b("div", {
					className: "kalypso-reward-panel kalypso-panel",
					children: [/* @__PURE__ */ y("strong", { children: t("games.kalypso.chooseExpert") }), ae.filter((e) => !r.experts.includes(e)).map((e) => /* @__PURE__ */ b("button", {
						className: "kalypso-build-choice",
						onClick: () => K({
							type: "expert",
							job: W.id,
							expert: e
						}),
						children: [/* @__PURE__ */ y("strong", { children: t(D[e]) }), /* @__PURE__ */ y("small", { children: t(O[e]) })]
					}, e))]
				}),
				U && W?.kind === "catch" && !E && /* @__PURE__ */ b("div", {
					className: "kalypso-reward-panel kalypso-panel",
					children: [/* @__PURE__ */ y("strong", { children: t("games.kalypso.chooseReturn") }), W.choices?.map((e, n) => /* @__PURE__ */ b("button", {
						className: "btn-base",
						onClick: () => K({
							type: "catch",
							job: W.id,
							returnIndex: n
						}),
						children: [
							e === -1 ? t("games.kalypso.item.barrel") : t("games.kalypso.fishValue", { n: e }),
							" · ",
							t("games.kalypso.returnFish")
						]
					}, n))]
				}),
				U && r.phase === "captain" && !pe.length && /* @__PURE__ */ b("div", {
					className: "kalypso-captain-panel",
					children: [/* @__PURE__ */ y("span", { children: t("games.kalypso.moveBoat") }), V.boats.filter((t) => !t.docked && t.owner === e.myRid && !r.captainMoved.includes(t.id)).map((e) => /* @__PURE__ */ y("button", {
						className: "btn-quiet",
						onClick: () => {
							I(e.id), T(null);
						},
						children: t("games.kalypso.boatNumber", { n: e.id })
					}, e.id))]
				})
			]
		})
	});
}
//#endregion
//#region src/games/kalypso/bot.ts
var qt = {
	candidates: 900,
	future: .7,
	production: 1,
	rescue: 1
};
function Jt(e, t, n, r) {
	let i = e.boards[t.board], a = e.config.mode !== "competitive", o = new Map(z(i).map((e) => [M(e), e.material])), s = B(i), c = V(i), l = i.buildings.filter((e) => e.resident).length, u = a ? e.players.flatMap((e) => e.rid === t.rid ? n : e.jobs) : n, d = (e) => u.filter((t) => t.kind === e).length, f = (n) => e.players.filter((e) => a || e.rid === t.rid).reduce((t, r) => {
		let i = r.events.find((t) => t.round === e.round);
		return t + (!i || i.complete ? 0 : Math.max(0, (Ke(i.weather, a, i.paid)[n] ?? 0) - i.paid[n]));
	}, 0), p = l + e.islandSurvivors, m = (e, t) => e[Math.min(t, e.length - 1)], h = i.gardens.length + e.gardenBonus + Math.max(0, d("garden") - f("garden")), g = a ? Math.max(0, p - m(le, h)) : 0, _ = a ? Math.max(0, p * 2 - e.fish - u.filter((e) => e.kind === "fish").sort((e, t) => (e.value ?? 0) - (t.value ?? 0)).slice(f("fish")).reduce((e, t) => e + (t.value ?? 0), 0)) : 0, ee = i.buildings.filter((e) => !e.resident && ![
		"house",
		"monument",
		"sanctuary"
	].includes(e.kind)), v = t.events.find((t) => t.round === e.round), y = a && v?.weather === "sun" && !v.complete, b = /* @__PURE__ */ new Map();
	for (let e of j[i.size].fish) if (!s.has(e) && !i.fishClaimed.includes(e)) {
		let t = I(N(e));
		b.set(t, (b.get(t) ?? 0) + 1);
	}
	let te = new Set(i.nets.map((e) => e.zone)), ne = new Set((e.experts.includes("angler") ? z(i).filter((e) => e.material !== "island") : i.boats.flatMap((e) => e.cells)).map(I)), re = Math.max(0, ...[...ne].filter((e) => !te.has(e)).map((e) => b.get(e) ?? 0)), x = Math.max(.3, (5 - e.round) / 4);
	function C(n) {
		let o = r.production;
		switch (n) {
			case "house": {
				if ((a ? e.islandSurvivors : t.survivors) <= d("house")) return 0;
				if (y) return 38;
				if (!ee.length) return 0;
				let n = Math.max(...ee.map((e) => C(e.kind)));
				return a ? 35 + n * .8 : 1 + n;
			}
			case "cooper": return e.supply.barrels ? o * (f("barrel") > d("barrel") ? 27 : 10) : 0;
			case "scrapyard": return e.supply.scraps ? o * (f("scrap") > d("scrap") ? 34 : 17 * x) : 0;
			case "warehouse": return e.supply.tiles ? o * 17 * x : 0;
			case "solar": return a ? m(A, e.solarBonus) < i.boats.length + d("boat") ? 35 : i.boats.length === 0 && !e.experts.includes("angler") ? _ > 0 ? 38 : 15 : 4 : 0;
			case "shipyard": return e.supply.boats ? o * (f("boat") > d("boat") ? 45 : a && i.boats.length >= m(A, e.solarBonus) ? 0 : re === 0 && !e.experts.includes("angler") ? a && _ > 0 ? 50 : 19 : 10 * x) : 0;
			case "netWorkshop": return e.supply.gardenNets ? o * (f("net") > d("net") ? 42 : Math.max(a && _ > 0 ? 12 : 2, re * (a && _ > 0 ? 12 : 3.2) / (1 + d("net")))) : 0;
			case "greenhouse": return e.supply.gardenNets ? o * (f("garden") > d("garden") ? 42 : a ? g > 0 ? 42 : h === 0 && p === 0 ? 10 : 1 : 5) : 0;
			default: return 0;
		}
	}
	return {
		s: e,
		p: t,
		b: i,
		jobs: n,
		cooperative: a,
		weights: r,
		ground: o,
		occ: s,
		covers: c,
		pending: d,
		need: f,
		residents: l,
		population: p,
		gardenShortage: g,
		fishShortage: _,
		targets: ee,
		sun: y,
		event: v,
		fishByZone: b,
		netZones: te,
		fishingZones: ne,
		bestFish: re,
		effect: C,
		materialValue: Object.fromEntries(S.map((e) => [e, Math.max(...ie[e].map((e) => C(e) + (a ? 1 : w[e].vp)))])),
		capacity: m
	};
}
function Yt(e, t, n = e.ground) {
	let { b: r, s: i, cooperative: a } = e, o = t.kind === "monument" || t.kind === "sanctuary", s = (a ? 1 : w[t.kind].vp) + e.effect(t.kind);
	!o && i.experts.includes("carpenter") && L(t.x, t.y, 2).every((e) => n.get(M(e)) === t.material) && (s += e.effect(ie[t.material].find((e) => e !== t.kind)), t.reverse = !(e.sun && t.material === "wood"));
	let c = L(t.x, t.y, o ? 3 : 2), l = new Set(c.flatMap(P).map(M)), u = r.size / 4;
	!a && t.kind === "solar" && (s += Math.min(7, [...l].filter((t) => !e.occ.has(t)).length)), o && (s += a ? i.goals.includes(3) && r.buildings.filter((e) => ["monument", "sanctuary"].includes(e.kind)).length < i.players.length ? 25 : -5 : 0);
	for (let e of i.goals) {
		if (e === 0 && r.buildings.some((e) => e.material === t.material && R(e).some((e) => l.has(M(e)))) && (s += a ? 7 : 2), e === 1 && c.some((e) => F(r, e) && [0, u - 1].includes(Math.floor(e.x / 4)) && [0, u - 1].includes(Math.floor(e.y / 4))) && (s += a ? 15 : 5), e === 2 && (s += c.some((e) => F(r, e) && [0, u - 1].some((t) => Math.floor(e.x / 4) === t || Math.floor(e.y / 4) === t)) ? a ? 9 : 2 : a ? -3 : 0), e === 6 && !o) {
			let e = (e) => r.buildings.filter((t) => t.material === e && !["monument", "sanctuary"].includes(t.kind)).length;
			e(t.material) === Math.min(...S.map(e)) && (s += a ? 7 : 2);
		}
		e === 9 && (s += c.filter((e) => n.get(M(e)) === "plastic").length * (a ? 4 : 1));
	}
	return s;
}
function Xt(e, t, n, r = e.covers) {
	let i = /* @__PURE__ */ new Set(), a = [];
	for (let e of n) {
		let t = N(e);
		for (let e = -2; e <= 0; e++) for (let n = -2; n <= 0; n++) i.add(M({
			x: t.x + n,
			y: t.y + e
		}));
	}
	for (let o of i) {
		let i = N(o);
		for (let o of [2, 3]) {
			let s = L(i.x, i.y, o);
			if (s.some((e) => n.includes(M(e))) && !s.some((e) => !t.has(M(e)) || t.get(M(e)) === "island" || r.has(M(e)))) {
				for (let n of S) if (!(s.filter((e) => t.get(M(e)) === n || t.get(M(e)) === "wild").length < (o === 2 ? 3 : 5))) {
					if (o === 2 && e.s.supply.buildings[n] > 0) for (let e of ie[n]) a.push({
						type: "build",
						...i,
						kind: e,
						material: n
					});
					if (o === 3 && e.s.supply.monuments > 0) for (let t of e.s.experts.includes("guardian") ? ["monument", "sanctuary"] : ["monument"]) a.push({
						type: "build",
						...i,
						kind: t,
						material: n,
						rings: t === "sanctuary" ? e.b.rings.slice(0, 3) : []
					});
				}
			}
		}
	}
	return a;
}
function Zt(e) {
	return {
		initial: e.s.phase === "initial" && !e.p.initialDone,
		usedSides: e.s.players.flatMap((e) => e.initialSide === null ? [] : [e.initialSide]),
		experts: e.s.experts
	};
}
function Qt(e, t) {
	let n = Zt(e), r = [], i = /* @__PURE__ */ new Set(), a = t.kind === "net" ? new Set(U(e.b).flat().map(M)) : void 0, o = [...e.ground.keys()].map(N);
	for (let s of t.kind === "barrel" ? [0] : t.kind === "tile" ? [
		0,
		1,
		2,
		3
	] : [0, 1]) for (let c of t.kind === "tile" ? [!1, !0] : [!1]) {
		let l = H(t, {
			x: 0,
			y: 0,
			rotation: s,
			flip: c
		}), u = /* @__PURE__ */ new Set(), d = t.kind === "boat" || t.kind === "net" ? L(-2, -2, e.b.size + 4) : t.kind === "garden" ? o : n.initial && e.b.size === 20 ? L(9, 9, 2) : o.flatMap(P);
		for (let e of d) for (let n of t.kind === "boat" || t.kind === "net" ? [{
			x: 0,
			y: 0
		}] : l) u.add(M({
			x: e.x - n.x,
			y: e.y - n.y
		}));
		for (let o of u) {
			let u = {
				...N(o),
				rotation: s,
				flip: c
			}, d = l.map((e) => ({
				...e,
				x: e.x + u.x,
				y: e.y + u.y
			}));
			if (!d.some((t) => F(e.b, t))) continue;
			if (t.kind === "net") {
				let r = I(d[0]);
				if (e.netZones.has(r) || !e.fishingZones.has(r) || !d.every((t) => F(e.b, t) && I(t) === r && !a.has(M(t))) || !W(e.b, t, u, {
					...n,
					closed: a
				})) continue;
			} else if (t.kind === "garden") {
				if (!d.every((t) => e.ground.has(M(t)) && !e.covers.has(M(t))) || d.some((t) => e.ground.get(M(t)) === "island") && ![18, 21].some((e) => d.every((t) => t.x === e && (t.y === 19 || t.y === 20)))) continue;
			} else if (d.some((t) => e.occ.has(M(t))) || t.kind !== "boat" && n.initial && e.b.size === 40 && !pe(d).some((e) => !n.usedSides.includes(e))) continue;
			let f = d.map((e) => `${M(e)}:${e.material}`).sort().join(";");
			i.has(f) || (i.add(f), r.push(u));
		}
	}
	return r;
}
function $t(e, t) {
	let n = 0;
	for (let r of t) {
		let t = M(r);
		e.b.barrels.includes(t) && (n += e.need("barrel") > e.pending("barrel") ? 27 : 11), e.b.rings.includes(t) && (n += e.cooperative ? (e.s.experts.length + e.pending("expert") === 0 ? e.pending("net") > 0 ? 28 : 5 : -16) * e.weights.rescue - (e.s.islandSurvivors > 0 ? 5 : 0) : 3), j[e.b.size].fish.includes(t) && !e.b.fishClaimed.includes(t) && (n -= e.fishShortage > 0 ? 1 : .15), r.material === "plastic" && e.s.goals.includes(9) && (n -= e.cooperative ? 1.4 : .4);
	}
	return n;
}
function en(e, t, n) {
	let r = /* @__PURE__ */ new Set(), i = [];
	for (let e of n) for (let t = -1; t <= 0; t++) for (let n = -1; n <= 0; n++) r.add(M({
		x: e.x + n,
		y: e.y + t
	}));
	for (let n of r) {
		let r = N(n), a = L(r.x, r.y, 2), o = a.map((e) => t.get(M(e)));
		if (a.some((t) => e.covers.has(M(t))) || o.includes("island")) continue;
		let s = o.filter(Boolean).length;
		if (s - Math.max(...S.map((e) => o.filter((t) => t === e || t === "wild").length)) > 1) continue;
		let c = Math.max(...S.map((t) => {
			let n = o.filter((e) => e === t || e === "wild").length;
			return s - n > 1 || n === 0 ? 0 : e.materialValue[t] * (s === 4 ? +(n >= 3) : s === 3 ? n >= 2 ? .26 : 0 : s === 2 ? n === 2 ? .12 : .035 : .015);
		}));
		i.push(c);
	}
	return i.sort((e, t) => t - e), (i[0] ?? 0) + (i[1] ?? 0) * .12 + (i[2] ?? 0) * .05;
}
function tn(e, t) {
	if (t.kind === "boat" && e.cooperative && !t.unlimited && e.b.boats.length >= e.capacity(A, e.s.solarBonus)) return {
		action: {
			type: "discard",
			job: t.id
		},
		value: -1
	};
	let n = Qt(e, t);
	if (!n.length) return {
		action: {
			type: "discard",
			job: t.id
		},
		value: -1
	};
	let r = new Map(e.ground), i = n.map((n) => {
		let r = H(t, n), i = $t(e, r);
		if (t.kind === "net") i = (e.fishByZone.get(I(r[0])) ?? 0) * (e.cooperative && e.fishShortage > 0 ? 9 : 3.2);
		else if (t.kind === "garden") {
			let t = new Set(r.flatMap(P).map(M));
			i = e.cooperative ? e.gardenShortage > 0 ? 26 : 1 : Math.min(5, e.b.buildings.filter((e) => R(e).some((e) => t.has(M(e)))).length), i -= r.reduce((t, n) => t + (e.ground.get(M(n)) === "island" || e.ground.get(M(n)) === "boat" || e.ground.get(M(n)) === "plastic" ? 0 : 2), 0);
		} else {
			for (let t of r) {
				for (let n of P(t)) e.ground.has(M(n)) && (i += e.ground.get(M(n)) === t.material ? 1.3 : .15);
				i -= (Math.abs(t.x - e.b.size / 2) + Math.abs(t.y - e.b.size / 2)) * .015;
			}
			if (t.kind === "boat") {
				let t = new Set(r.map(I));
				i += Math.max(0, ...[...t].filter((t) => !e.netZones.has(t)).map((t) => e.fishByZone.get(t) ?? 0)) * (e.cooperative && e.fishShortage > 0 ? 2.7 : 1.3), r.some((t) => P(t).some((t) => e.ground.has(M(t)))) && (i += 5);
			}
		}
		return {
			pose: n,
			cells: r,
			value: i
		};
	}).sort((e, t) => t.value - e.value), a = i[0], o = -Infinity, s = [];
	for (let n of i.slice(0, e.weights.candidates)) {
		let i = n.value;
		if ([
			"tile",
			"scrap",
			"barrel"
		].includes(t.kind) || t.kind === "boat" && n.cells.some((t) => P(t).some((t) => e.ground.has(M(t))))) {
			for (let e of n.cells) r.set(M(e), e.material);
			i += e.weights.future * en(e, r, n.cells);
			for (let e of n.cells) r.delete(M(e));
		}
		s.push({
			option: n,
			value: i
		});
	}
	s.sort((e, t) => t.value - e.value);
	let c = new Map(e.ground);
	for (let n of s.slice(0, 8)) {
		let r = n.value;
		if ([
			"tile",
			"scrap",
			"barrel"
		].includes(t.kind) || t.kind === "boat" && n.option.cells.some((t) => P(t).some((t) => e.ground.has(M(t))))) {
			for (let e of n.option.cells) c.set(M(e), e.material);
			let t = Xt(e, c, n.option.cells.map(M));
			r += Math.max(0, ...t.map((t) => Yt(e, t, c))) * .3;
			for (let e of n.option.cells) c.delete(M(e));
		}
		r > o && (o = r, a = n.option);
	}
	return {
		action: {
			type: "place",
			job: t.id,
			...a.pose
		},
		value: o
	};
}
function nn(e) {
	let t = {
		angler: e.cooperative ? 44 : e.bestFish === 0 ? 40 : 16,
		carpenter: 27,
		salvager: 22 + (4 - e.s.round) * 2,
		captain: e.fishShortage > 0 ? 23 : 18,
		guardian: 1
	};
	return [...ae].filter((t) => !e.s.experts.includes(t)).sort((e, n) => t[n] - t[e])[0];
}
function rn(e) {
	let t = e.s.players.indexOf(e.p), n = e.s.round % 2 == 1 ? -1 : 1, r = e.s.players[(t + n + e.s.players.length) % e.s.players.length], i = e.s.boards[r.board], a = (e) => {
		let t = Ke(e, !1), n = 0;
		for (let [e, a] of Object.entries(t)) {
			let t = e === "barrel" ? ["cooper"] : e === "garden" ? ["greenhouse"] : e === "boat" ? ["shipyard"] : e === "scrap" ? ["scrapyard"] : ["netWorkshop"];
			n += a * (e === "survivor" ? r.survivors > 0 ? .5 : 5 : 2.5 / (1 + i.buildings.filter((e) => t.includes(e.kind)).length));
		}
		return e === "sun" && (n = r.survivors > 0 ? .5 : 4), n;
	};
	return {
		type: "weather",
		weather: [...e.p.availableWeather].sort((e, t) => a(t) - a(e))[0]
	};
}
function an(e) {
	let t;
	for (let n of e.b.boats.filter((t) => !t.docked && t.owner === e.p.rid && !e.s.captainMoved.includes(t.id))) {
		let r = Math.min(...n.cells.map((e) => e.x)), i = Math.min(...n.cells.map((e) => e.y)), a = {
			...e.b,
			boats: e.b.boats.filter((e) => e.id !== n.id)
		}, o = {
			...e,
			b: a,
			occ: B(a),
			ground: new Map(z(a).map((e) => [M(e), e.material]))
		};
		for (let a of [0, 1]) for (let s = i - 4; s <= i + 4; s++) for (let i = r - 4; i <= r + 4; i++) {
			let r = {
				x: i,
				y: s,
				rotation: a,
				flip: !1
			};
			if (!_e(e.b, n.id, r)) continue;
			let c = H({
				id: 0,
				kind: "boat"
			}, r), l = $t(o, c) + (c.some((e) => P(e).some((e) => o.ground.has(M(e)))) ? 10 : 0);
			l > 0 && (!t || l > t.value) && (t = {
				action: {
					type: "move",
					boat: n.id,
					...r
				},
				value: l
			});
		}
	}
	return t?.action;
}
function on(e = {}) {
	let t = {
		...qt,
		...e
	};
	return (e, n) => {
		let r = e.public, i = r.players.find((e) => e.rid === n.rid), a = e.private;
		if (!i || !a || r.phase === "ended" || i.ready) return null;
		let o = Jt(r, i, a.jobs, n.difficulty === "weak" ? {
			...t,
			candidates: 80,
			future: t.future * .4
		} : t);
		if (r.phase === "weather") return i.weatherChosen ? null : { action: rn(o) };
		let s, c = (e, t) => {
			(!s || t > s.value) && (s = {
				action: e,
				value: t
			});
		};
		!o.cooperative && r.phase !== "initial" && i.survivors > 0 && o.event && Ye(o.event, "survivor", !1) && c({
			type: "donate",
			job: null,
			to: i.rid
		}, o.event.weather === "sun" ? 4 : 9);
		for (let e of a.jobs) {
			if (e.kind === "expert") {
				let t = nn(o);
				return { action: t ? {
					type: "expert",
					job: e.id,
					expert: t
				} : {
					type: "discard",
					job: e.id
				} };
			}
			if (e.kind === "catch") {
				let t = (e) => e === -1 ? o.need("barrel") > 0 ? 7 : 2 : e * (o.fishShortage > 0 ? 2 : 1), n = e.choices.reduce((n, r, i) => t(r) < t(e.choices[n]) ? i : n, 0);
				return { action: {
					type: "catch",
					job: e.id,
					returnIndex: n
				} };
			}
			if (r.phase !== "initial" && [
				"barrel",
				"garden",
				"fish",
				"scrap",
				"boat",
				"net"
			].includes(e.kind)) for (let t of r.players.filter((e) => o.cooperative || e.rid === i.rid)) {
				let n = t.events.find((e) => e.round === r.round);
				n && Ye(n, e.kind, o.cooperative) && c({
					type: "donate",
					job: e.id,
					to: t.rid
				}, o.cooperative ? 1e3 - (e.kind === "fish" ? e.value ?? 0 : 0) : 5 + (n.weather === "hatches" || n.weather === "storm" ? 2 : 0));
			}
			if (e.kind === "fish") c({
				type: "catch",
				job: e.id,
				returnIndex: 0
			}, o.cooperative ? (e.value ?? 0) * (o.fishShortage > 0 ? 9 : 2) : e.value ?? 0);
			else if (e.kind === "house") {
				let t = o.b.buildings.filter((e) => !e.resident && !["monument", "sanctuary"].includes(e.kind) && (e.kind !== "house" || o.sun && e.builtRound === r.round));
				if ((o.cooperative ? r.islandSurvivors : i.survivors) > 0) for (let n of t) c({
					type: "house",
					job: e.id,
					building: n.id
				}, n.kind === "house" ? 1e3 : 21 + o.effect(n.kind));
				c({
					type: "discard",
					job: e.id
				}, -5);
			} else {
				let t = tn(o, e);
				t && c(t.action, t.value);
			}
		}
		let l = Xt(o, o.ground, i.recent).map((e) => ({
			action: e,
			value: Yt(o, e)
		})).sort((e, t) => t.value - e.value);
		if (l[0]?.value > 0 && (!s || s.action.type === "place" || s.action.type === "discard")) return { action: l[0].action };
		for (let e of l) e.value > 0 && c(e.action, e.value);
		if (s) return { action: s.action };
		if (!i.drafted && r.phase !== "captain" && i.hand.length) {
			let e = i.hand[0], t = -Infinity;
			for (let n of i.hand) {
				let r = tn(o, {
					id: 0,
					kind: "tile",
					tile: n
				});
				r && r.value > t && (e = n, t = r.value);
			}
			return { action: {
				type: "choose",
				tile: e
			} };
		}
		return { action: r.phase === "captain" ? an(o) ?? { type: "ready" } : { type: "ready" } };
	};
}
var sn = on(), cn = (e, t, n) => {
	let r = (e, t) => ({
		x: e + 1,
		y: t + 1
	}), i = "job" in e && e.job !== null ? t.private?.jobs.find((t) => t.id === e.job) : void 0;
	switch (e.type) {
		case "choose": return n("games.kalypso.bot.choose", { n: e.tile + 1 });
		case "weather": return n("games.kalypso.phase.weather") + ": " + n(E[e.weather]);
		case "place": return i ? n("games.kalypso.bot.place", {
			item: n($[i.kind]),
			...r(e.x, e.y),
			rotation: e.rotation * 90,
			flip: e.flip ? n("games.kalypso.bot.flipped") : ""
		}) : "";
		case "build": return n("games.kalypso.bot.build", {
			building: n(w[e.kind].key),
			...r(e.x, e.y),
			reverse: e.reverse ? n("games.kalypso.bot.reverse") : "",
			rings: e.rings?.length ? n("games.kalypso.bot.rings", { positions: e.rings.map((e) => {
				let t = N(e);
				return `(${t.x + 1}, ${t.y + 1})`;
			}).join(", ") }) : ""
		});
		case "donate": return n("games.kalypso.bot.donate", {
			item: n(i ? $[i.kind] : "games.kalypso.bot.survivor"),
			n: t.public.players.findIndex((t) => t.rid === e.to) + 1
		});
		case "house": {
			let i = t.public.boards.flatMap((e) => e.buildings).find((t) => t.id === e.building);
			return i ? n("games.kalypso.bot.house", {
				building: n(w[i.kind].key),
				...r(i.x, i.y)
			}) : "";
		}
		case "expert": return n("games.kalypso.bot.expert", { expert: n(D[e.expert]) });
		case "catch": return n(i?.kind === "catch" ? "games.kalypso.bot.return" : "games.kalypso.claimFish", { n: e.returnIndex + 1 });
		case "discard": return i ? n("games.kalypso.bot.discard", { item: n($[i.kind]) }) : "";
		case "move": return n("games.kalypso.bot.move", {
			n: e.boat,
			...r(e.x, e.y),
			rotation: e.rotation * 90
		});
		case "ready": return n(t.public.phase === "captain" ? "games.kalypso.finishRound" : "games.kalypso.ready");
	}
}, ln = [
	"buildings",
	"monuments",
	"gardens",
	"survivors",
	"fish",
	"solar",
	"goals",
	"weather"
];
function un(e) {
	let t = c(), r = s((e) => e.locale), i = e.public, [f, p] = o(!0), [m, h] = o(e.myRid), [g, te] = o(!1), [re, x] = o(!1), [S, C] = o(null), ie = a(null), T = a(null), ae = a(null);
	n(() => {
		ie.current?.focus({ preventScroll: !0 });
	}, []);
	let O = i.players.find((e) => e.rid === m) ?? i.players[0], k = i.config.mode !== "competitive", oe = (t) => {
		let n = e.members.find((e) => e.rid === t);
		return n ? ee(n, r) : t;
	}, se = (e) => {
		C(null), p(e), requestAnimationFrame(() => (e ? ie : T).current?.focus({ preventScroll: !0 }));
	}, ce = (e) => {
		if (e.key === "Escape" && (e.stopPropagation(), se(!1)), e.key !== "Tab") return;
		let t = [...ae.current?.querySelectorAll("button:not(:disabled),summary,[tabindex=\"0\"]") ?? []].filter((e) => e.getClientRects().length), n = t[0], r = t[t.length - 1];
		e.shiftKey && document.activeElement === n && (e.preventDefault(), r?.focus()), !e.shiftKey && document.activeElement === r && (e.preventDefault(), n?.focus());
	}, le = (e, t) => {
		S === e ? (C(null), t()) : C(e);
	};
	return /* @__PURE__ */ b("div", {
		className: "kalypso-screen kalypso-endgame",
		children: [
			/* @__PURE__ */ b("div", {
				className: "kalypso-final-map",
				inert: f,
				children: [
					/* @__PURE__ */ b("nav", {
						className: "kalypso-replay-toolbar",
						children: [!k && i.players.map((e) => /* @__PURE__ */ y("button", {
							className: `btn-quiet${e.rid === O.rid ? " kalypso-selected" : ""}`,
							onClick: () => h(e.rid),
							children: oe(e.rid)
						}, e.rid)), /* @__PURE__ */ y("button", {
							className: "btn-quiet",
							onClick: () => te((e) => !e),
							children: t("games.kalypso.viewInfo")
						})]
					}),
					/* @__PURE__ */ y("div", {
						className: "kalypso-replay-board",
						children: i.players.filter((e, t, n) => n.findIndex((t) => t.board === e.board) === t).map((e) => /* @__PURE__ */ y("div", {
							className: "kalypso-review-map",
							style: { visibility: e.board === O.board ? "visible" : "hidden" },
							inert: e.board !== O.board,
							"aria-hidden": e.board !== O.board,
							children: /* @__PURE__ */ y(kt, {
								board: i.boards[e.board],
								eligible: [],
								onPick: () => {},
								fitKey: String(e.board)
							})
						}, e.board))
					}),
					/* @__PURE__ */ y("div", {
						className: "kalypso-modal",
						hidden: !g,
						children: /* @__PURE__ */ b("div", {
							className: "kalypso-panel",
							children: [/* @__PURE__ */ y("button", {
								className: "btn-quiet kalypso-panel-close",
								onClick: () => te(!1),
								children: t("games.kalypso.close")
							}), /* @__PURE__ */ y(Gt, {
								pub: i,
								rid: O.rid,
								nameOf: oe
							})]
						})
					})
				]
			}),
			/* @__PURE__ */ y("div", {
				className: "kalypso-end-veil",
				hidden: !f,
				children: /* @__PURE__ */ b("section", {
					ref: ae,
					className: "kalypso-result-panel",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": t("games.kalypso.resultTitle"),
					onKeyDown: ce,
					children: [
						/* @__PURE__ */ b("header", {
							className: "kalypso-result-header",
							children: [
								/* @__PURE__ */ b("div", { children: [
									/* @__PURE__ */ y("b", { children: "KALYPSO" }),
									/* @__PURE__ */ y("h1", { children: t("games.kalypso.resultTitle") }),
									/* @__PURE__ */ y("p", { children: k ? t(i.won ? "games.kalypso.victory" : "games.kalypso.defeat") : t("games.kalypso.winnerNames", { names: e.result.winner.map(oe).join(" / ") }) })
								] }),
								/* @__PURE__ */ b("div", {
									className: "kalypso-result-art",
									children: [
										/* @__PURE__ */ y(Q, { kind: "cooper" }),
										/* @__PURE__ */ y(Q, { kind: "house" }),
										/* @__PURE__ */ y(Q, { kind: "boat" })
									]
								}),
								/* @__PURE__ */ y("button", {
									ref: ie,
									className: "btn-quiet",
									"aria-label": t("games.kalypso.reviewHide"),
									onClick: () => se(!1),
									children: /* @__PURE__ */ y(u, { size: 20 })
								})
							]
						}),
						/* @__PURE__ */ b("div", {
							className: "kalypso-result-body",
							children: [e.hintCount !== void 0 && /* @__PURE__ */ y("p", { children: t("session.hint.usedCount", { n: e.hintCount }) }), k ? /* @__PURE__ */ b(v, { children: [
								/* @__PURE__ */ y("div", {
									className: "kalypso-team-result",
									children: e.result.ranking.map((n) => /* @__PURE__ */ b("div", { children: [/* @__PURE__ */ y("strong", { children: oe(n) }), !!e.result.autopilot?.[n] && /* @__PURE__ */ b("small", { children: [/* @__PURE__ */ y(l, { size: 12 }), t("session.autopilot.share", { n: Math.round(e.result.autopilot[n] * 100) })] })] }, n))
								}),
								/* @__PURE__ */ y("div", {
									className: "kalypso-end-reason",
									children: i.reason && t(Bt[i.reason])
								}),
								/* @__PURE__ */ y(Gt, {
									pub: i,
									rid: O.rid,
									nameOf: oe
								})
							] }) : /* @__PURE__ */ b("table", {
								className: "kalypso-score-table",
								children: [
									/* @__PURE__ */ y("thead", { children: /* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ y("th", {
										scope: "col",
										children: t("games.kalypso.scoreItem")
									}), e.result.ranking.map((n) => {
										let r = e.members.find((e) => e.rid === n);
										return /* @__PURE__ */ b("th", {
											scope: "col",
											"data-winner": e.result.winner.includes(n),
											children: [
												r && /* @__PURE__ */ y(_, {
													m: r,
													myRid: e.myRid,
													action: null,
													anchorName: null,
													box: "kalypso-avatar",
													img: "kalypso-avatar-img"
												}),
												/* @__PURE__ */ y("strong", { children: oe(n) }),
												e.result.winner.includes(n) && /* @__PURE__ */ y("small", { children: t("games.kalypso.winner") }),
												!!e.result.autopilot?.[n] && /* @__PURE__ */ b("small", { children: [/* @__PURE__ */ y(l, { size: 12 }), t("session.autopilot.share", { n: Math.round(e.result.autopilot[n] * 100) })] })
											]
										}, n);
									})] }) }),
									/* @__PURE__ */ y("tbody", { children: ln.map((n) => /* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ y("th", {
										scope: "row",
										children: t(Rt[n])
									}), e.result.ranking.map((e) => /* @__PURE__ */ y("td", { children: i.players.find((t) => t.rid === e)?.score[n] ?? "—" }, e))] }, n)) }),
									/* @__PURE__ */ y("tfoot", { children: /* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ y("th", {
										scope: "row",
										children: t(Rt.total)
									}), e.result.ranking.map((t) => /* @__PURE__ */ y("td", {
										"data-winner": e.result.winner.includes(t),
										children: i.players.find((e) => e.rid === t)?.score.total ?? "—"
									}, t))] }) })
								]
							})]
						}),
						/* @__PURE__ */ b("footer", {
							className: "kalypso-result-actions",
							children: [
								/* @__PURE__ */ b("button", {
									className: "btn-quiet",
									onClick: () => x(!0),
									children: [/* @__PURE__ */ y(d, { size: 18 }), t("common.log.title")]
								}),
								e.onBackToLobby && /* @__PURE__ */ y("button", {
									className: `btn-quiet${S === "lobby" ? " danger-stripes text-white" : ""}`,
									onBlur: () => C(null),
									onClick: () => le("lobby", e.onBackToLobby),
									children: t(S === "lobby" ? "games.kalypso.confirmLobby" : "session.result.backToLobby")
								}),
								e.onPlayAgain && /* @__PURE__ */ y("button", {
									className: `btn-base kalypso-primary${S === "again" ? " danger-stripes text-white" : ""}`,
									onBlur: () => C(null),
									onClick: () => le("again", e.onPlayAgain),
									children: t(S === "again" ? "games.kalypso.confirmAgain" : "session.result.playAgain")
								}),
								!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ y("p", { children: t("session.result.waitHost") })
							]
						})
					]
				})
			}),
			/* @__PURE__ */ b("button", {
				ref: T,
				hidden: f,
				className: "btn-base kalypso-primary kalypso-result-restore",
				onClick: () => se(!0),
				children: [/* @__PURE__ */ y(d, { size: 18 }), t("games.kalypso.reviewShow")]
			}),
			re && /* @__PURE__ */ y(ne, {
				log: i.log,
				onClose: () => x(!1),
				line: (e) => {
					let n = {
						place: "games.kalypso.log.place",
						build: "games.kalypso.log.build",
						rescue: "games.kalypso.log.rescue",
						fish: "games.kalypso.log.fish",
						weather: "games.kalypso.log.weather",
						round: "games.kalypso.log.round",
						expert: "games.kalypso.log.expert",
						donate: "games.kalypso.log.donate",
						move: "games.kalypso.log.move"
					}, r = e.kind === "build" ? w[e.detail]?.key : e.kind === "weather" ? E[e.detail] : e.kind === "expert" ? D[e.detail] : void 0;
					return `${oe(e.rid)} · ${t(n[e.kind], {
						n: e.n,
						name: r ? t(r) : ""
					})}`;
				}
			})
		]
	});
}
//#endregion
//#region src/games/kalypso/options.tsx
function dn({ value: e, onChange: t }) {
	let n = c(), r = we.safeParse(e), i = r.success ? r.data : we.parse(void 0);
	return /* @__PURE__ */ b("div", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ y(x, {
			title: n("games.kalypso.optMode"),
			columns: 3,
			children: [
				"competitive",
				"cooperative",
				"solo"
			].map((e) => /* @__PURE__ */ y(re, {
				name: "kalypso-mode",
				value: e,
				checked: i.mode === e,
				label: n(jt[e]),
				accent: ve.accent,
				onChange: () => t({
					...i,
					mode: e
				})
			}, e))
		}), i.mode !== "competitive" && /* @__PURE__ */ y(x, {
			title: n("games.kalypso.optDifficulty"),
			children: [
				"learning",
				"easy",
				"medium",
				"hard"
			].map((e) => /* @__PURE__ */ y(re, {
				name: "kalypso-difficulty",
				value: e,
				checked: i.difficulty === e,
				label: n(Mt[e]),
				accent: ve.accent,
				onChange: () => t({
					...i,
					difficulty: e
				})
			}, e))
		})]
	});
}
//#endregion
//#region src/games/kalypso/guide.tsx
function fn({ text: e }) {
	let t = e.split("\n").filter(Boolean), n = t.filter((e) => !e.startsWith("· ")), r = t.filter((e) => e.startsWith("· "));
	return /* @__PURE__ */ b(v, { children: [n.map((e, t) => /* @__PURE__ */ y("p", { children: e }, t)), r.length > 0 && /* @__PURE__ */ y("ul", {
		style: {
			listStyle: "disc",
			paddingLeft: 20
		},
		children: r.map((e, t) => /* @__PURE__ */ y("li", { children: e.slice(2) }, t))
	})] });
}
function pn() {
	let e = c();
	return /* @__PURE__ */ b("div", {
		className: "kalypso-guide",
		children: [
			/* @__PURE__ */ y("h3", { children: e("games.kalypso.buildingsTitle") }),
			Object.entries(w).map(([t, n]) => /* @__PURE__ */ b("details", { children: [/* @__PURE__ */ b("summary", { children: [
				e(n.key),
				" · ",
				n.vp,
				" VP"
			] }), /* @__PURE__ */ y("p", { children: e(n.effect) })] }, t)),
			/* @__PURE__ */ y("h3", { children: e("games.kalypso.weatherGuide") }),
			T.map((t) => /* @__PURE__ */ b("details", { children: [/* @__PURE__ */ y("summary", { children: e(E[t]) }), /* @__PURE__ */ b("ul", {
				style: {
					listStyle: "disc",
					paddingLeft: 20
				},
				children: [/* @__PURE__ */ b("li", { children: [
					/* @__PURE__ */ y("strong", { children: e("games.kalypso.mode.competitive") }),
					/* @__PURE__ */ y("p", { children: e(Nt[t]) }),
					/* @__PURE__ */ y("p", { children: e(Ft[t]) })
				] }), /* @__PURE__ */ b("li", { children: [
					/* @__PURE__ */ y("strong", { children: e("games.kalypso.mode.cooperative") }),
					/* @__PURE__ */ y("p", { children: e(Pt[t]) }),
					/* @__PURE__ */ y("p", { children: e(It[t]) })
				] })]
			})] }, t)),
			/* @__PURE__ */ y("h3", { children: e("games.kalypso.expertsGuide") }),
			ae.map((t) => /* @__PURE__ */ b("details", { children: [/* @__PURE__ */ y("summary", { children: e(D[t]) }), /* @__PURE__ */ y("p", { children: e(O[t]) })] }, t)),
			/* @__PURE__ */ y("h3", { children: e("games.kalypso.goalsGuide") }),
			/* @__PURE__ */ y("p", { children: e("games.kalypso.countsByPlayers") }),
			k.map((t, n) => /* @__PURE__ */ b("details", { children: [/* @__PURE__ */ y("summary", { children: e(t) }), /* @__PURE__ */ y(fn, { text: e(Lt[n]) })] }, t))
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/kalypso/entry.tsx
var mn = {
	definition: gt,
	View: Kt,
	bot: sn,
	describe: cn,
	OverView: un,
	Options: dn,
	Guide: pn,
	locales: {
		zh: {
			name: "卡里普索",
			desc: "在漂流物上建起海上聚落；竞争得分，或合作照料幸存者并度过四轮风雨。",
			rules: "目标与准备：\n竞争模式为2至4人，每人独立使用20行20列的海图；合作模式为2至4人共用40行40列的海图，单人模式使用同一合作海图。总共进行四轮。竞争模式以总分最高获胜；合作与单人必须每轮完成天气、安置全部幸存者、每位居民消耗2条鱼，并以足够花园容量供养居民，最后同时达成两个聚落目标。\n竞争每人起始有2名幸存者、4个半沉木桶和8个救生圈；合作海图有16个木桶、16个救生圈，岛上幸存者按所选难度逐轮到来。每人抽2块漂流物，选择1块放置，另一块回袋。竞争起始板块须接触或覆盖中央白圈；合作起始板块须正交连接岛屿不同的一边。\n\n每轮流程：\n竞争每人从尚未使用的天气中秘密选1张交给邻座，同时揭示；第1、3轮逆时针，第2、4轮顺时针。合作与单人每轮揭示1个共同天气，每个人分别完成自己的配额，可以分享新获得的资源。\n多人每人漩涡抽5块漂流物。每次选1块，旋转或翻面后放置，处理全部奖励，再确认完成。全部玩家确认后传递漩涡：第1、3轮顺时针，第2、4轮逆时针；每轮放4块，最后1块移出本局。单人每次抽2选1，另一块暂存，本轮共选5次，再将暂存板块移出本局。打捞专家可在最后额外放置剩下的第五块；单人可放第五次放弃的那块。\n\n地基与扩张：\n漂流物、碎料、满桶及已停靠的船构成地基；合作岛屿也属于地基。新地基须与已有地基正交相邻，不能只接角；船可放在任意未占用海面，正交接触地基后立即停靠，此后可从船继续扩张。物件可部分伸出海图，但至少一格须在海图内。物件不能互相重叠或覆盖岛屿。\n覆盖半沉木桶便获得该满桶，作为万能材料接地基放置；覆盖救生圈便救起1名幸存者。合作救起的人先到岛上，仍须入住；同时可选择一项尚未解锁的专家能力。每次新获得的物件须在传漩涡前处理，不能留到下次。无法合法放置的物件才可归还或放弃；房屋入住是可选奖励。\n\n建造与入住：\n最新落下的地基须贡献到目标区域。2行2列的区域全部铺满，至少3格同一种木材、金属、橡胶或海藻，满桶可替代任一种材料，塑料最多占1格；满足这些条件时，可建造对应材质任一面建筑。建筑不能覆盖建筑、花园或网。建成即触发奖励；每次使用房屋奖励，可把1名储备或岛上的幸存者安置到一座尚无居民、不是房屋或纪念碑的建筑，再次触发其奖励。合作的晴天天气允许把人安置到新建房屋，本次不触发奖励。\n3行3列的地基中有至少5格同一材料时，可建造纪念碑，获得11分；合作中只用于目标，或由守护专家建成圣所。具体建筑、天气与专家效果见下方图鉴。\n\n捕鱼与围合：\n渔网工坊提供1行2列的渔网，在有己方船的4行4列区域内撒网，每区域只能一次，网不能跨区或放入围合海域。数该区域仍可见且未领取的鱼，抽取等量鱼牌。若没有空间，或网会盖住圈或桶，可把网叠在该区域的船上作标记；以后扩张覆盖网时也可移网作标记。花园为1行2列，放在完整地基上；合作岛另有最多2个花园位。\n鱼牌有0、1、2、3条鱼，或木桶。竞争秘密保留鱼值，数量公开；合作立刻加入团队鱼资源，牌移出本局。木桶牌获得1个满桶。\n地基完整包围海域时立即取得其中可见的圈与桶；竞争终局每条仍可见的已围合鱼获得1分，合作围合时每条加1鱼。同一条鱼不能通过捕鱼与围合重复领取。海图边、区域线与渔网不构成围墙；对角地基只有同属正交相连的聚落时才能协助围合。\n\n天气与生存：\n新获得物件时，可以正常使用，或献给本轮天气；献出后整局留在天气牌上。竞争储备幸存者可随时献出。完成天气立即获得资源奖励，计分奖励延至终局；未完成天气按卡面扣分。合作任一玩家未完成天气即全体失败。\n合作模式每轮结束时，依次进行以下检查：\n· 检查所有玩家是否完成本轮天气要求。\n· 检查全部幸存者是否已入住。\n· 为每名居民消耗 2 份鱼。\n· 检查花园容量是否足够。\n花园不消耗：1至14个花园的容量依次为2、4、6、7、8、10、11、12、14、15、16、18、19、20人。\n太阳能限制海上船数，1至13太阳能的容量依次为2、4、5、6、8、10、11、12、14、15、16、18、20；天气奖励船可以超出容量。通过生存检查后，船长可移动未停靠船。\n\n竞争计分与平分：\n· 建筑按标示得分，纪念碑11分。\n· 花园每正交相邻一座建筑获得1分，最多5分。\n·  太阳能板每正交相邻一个可见海格获得1分，最多7分，图外算海，鱼、圈与半沉桶不遮挡。\n· 每名居民获得 3 分，每名储备幸存者获得 2 分，保留鱼牌按鱼值计分，再加围合鱼、两个聚落目标和天气分。\n· 总分相同依次比较：可见塑料较少、居民较多、纪念碑较多、建筑较多；仍相同则共享胜利。\n本游戏依据工坊附带的开发版规则书及当前卡面；库存按规则书，空区域目标按未占用区域数量计算。",
			mode: {
				competitive: "竞争",
				cooperative: "合作",
				solo: "单人"
			},
			difficulty: {
				learning: "入门",
				easy: "简单",
				medium: "中等",
				hard: "困难"
			},
			optMode: "游戏模式",
			optDifficulty: "生存难度",
			material: {
				wood: "木材",
				metal: "金属",
				rubber: "橡胶",
				seaweed: "海藻",
				plastic: "塑料",
				wild: "万能材料"
			},
			item: {
				tile: "漂流物",
				scrap: "碎料",
				barrel: "满桶",
				boat: "船",
				garden: "花园",
				net: "渔网",
				fish: "鱼牌",
				house: "安置幸存者",
				expert: "选择专家",
				catch: "选择放回的鱼牌"
			},
			building: {
				house: "房屋",
				cooper: "制桶坊",
				shipyard: "船厂",
				solar: "太阳能板",
				scrapyard: "废料场",
				warehouse: "仓库",
				netWorkshop: "渔网工坊",
				greenhouse: "温室",
				monument: "纪念碑",
				sanctuary: "圣所"
			},
			effect: {
				house: "安置1名幸存者到尚无居民的非房屋、非纪念碑建筑，再次触发其奖励。",
				cooper: "获得1个满桶。",
				shipyard: "获得1艘1×3的船。合作建船受太阳能容量限制。",
				solar: "竞争模式中，每个正交相邻的可见海格获得 1 分，最多获得 7 分；合作模式中，太阳能增加 1 点。",
				scrapyard: "抽取并分别放置2块1×2碎料。",
				warehouse: "抽取并放置1块额外漂流物。",
				netWorkshop: "获得1张1×2渔网，在有船的区域捕鱼。",
				greenhouse: "获得1个1×2花园，放在完整地基上。",
				monument: "建造纪念碑需要一片 3 行 3 列的完整地基，其中至少五格为相同材料。竞争模式中，每座纪念碑获得 11 分。",
				sanctuary: "拥有守护专家时，可以按纪念碑的条件建造圣所。建成时，立即移除至多三个救生圈，但不救出幸存者，也不解锁专家。"
			},
			weather: {
				sun: "烈日当空",
				rain: "细雨连绵",
				dock: "闲坐码头",
				drought: "讽刺的干旱",
				hatches: "封舱备险",
				teeth: "利齿成排",
				storm: "风暴将至"
			},
			weatherNeed: {
				sun: "献出 1 名幸存者，或献出 2 张鱼牌。",
				rain: "献出 1 个满桶及 1 个花园。",
				dock: "献出 1 张鱼牌及 1 个花园。",
				drought: "献出 1 名幸存者及 1 个满桶。",
				hatches: "献出 3 块碎料。",
				teeth: "献出 1 名幸存者及 1 艘船。",
				storm: "献出 2 艘船。"
			},
			weatherNeedCoop: {
				sun: "在本轮新建的房屋中安置 1 名幸存者。",
				rain: "献出 2 个满桶。",
				dock: "献出 1 张鱼牌及 1 个花园。",
				drought: "献出 1 个花园及 1 个满桶。",
				hatches: "献出 2 块碎料。",
				teeth: "献出 1 张渔网及 1 艘船。",
				storm: "献出 1 艘船。"
			},
			weatherReward: {
				sun: "完成要求后，终局时每座太阳能板额外获得 1 分；未完成时，扣除 3 分。",
				rain: "完成要求后，终局时每个花园额外获得 1 分；未完成时，扣除 3 分。",
				dock: "完成要求后，终局时每名储备幸存者额外获得 1 分；未完成时，扣除 3 分。",
				drought: "完成要求后，立即获得 2 块碎料；未完成时，终局扣除 3 分。",
				hatches: "完成要求后，立即获得 1 艘船；未完成时，每少献出 1 块碎料，终局扣除 2 分。",
				teeth: "完成要求后，立即抽取并结算 2 张鱼牌；未完成时，终局扣除 6 分。",
				storm: "完成要求后，立即获得 2 个满桶；未完成时，每少献出 1 艘船，终局扣除 4 分。"
			},
			weatherRewardCoop: {
				sun: "全体玩家均完成各自要求后，全队的太阳能合计增加 1 点。",
				rain: "全体玩家均完成各自要求后，全队的花园轨合计前进 1 格。",
				dock: "完成要求后，立即抽取并放置 1 块漂流物。",
				drought: "完成要求后，立即获得 2 块碎料。",
				hatches: "完成要求后，立即获得 1 艘船；这艘船可以超出太阳能容量。",
				teeth: "完成要求后，立即抽取并结算 2 张鱼牌。",
				storm: "完成要求后，立即获得 1 个满桶。"
			},
			expert: {
				angler: "渔夫",
				carpenter: "木匠",
				guardian: "守护者",
				salvager: "打捞者",
				captain: "船长"
			},
			expertEffect: {
				angler: "可以从地基所在区域撒网，无需有船。",
				carpenter: "若 2 行 2 列的建造区域中，四格均为相同材料且没有木桶，则按自选顺序触发该材料两面建筑的奖励，最后选择其中一面朝上。以后有居民入住时，只触发朝上一面的奖励。",
				guardian: "可以建造圣所。建成时，立即移除至多三个救生圈，但不救出幸存者；本次未使用的移除名额以后不能补用。",
				salvager: "每轮最后可额外放置漩涡剩下的板块；单人可放第五次放弃的板块。",
				captain: "捕鱼时，多抽一张鱼牌，再选择一张放回。轮末通过生存检查后，每艘未停靠的船可以移动至多一个区域，但仍须有一部分留在其原先占据的至少一个区域内。"
			},
			goal: {
				groups: "同材相邻建筑组",
				corners: "四角建筑",
				perimeter: "外围建筑",
				monuments: "纪念碑",
				enclosures: "有鱼的围合海域",
				lines: "区域行与列",
				sets: "四材建筑套",
				empty: "空区域",
				full: "铺满区域",
				plastic: "控制塑料"
			},
			goalRule: {
				groups: "每组建筑由至少 2 座正交相邻、材料相同的建筑组成。\n· 竞争模式中，每组获得 2 分。\n· 合作模式中，玩家人数为 1、2、3、4 人时，分别须有至少 3、6、9、12 组。",
				corners: "· 竞争模式中，建筑占据 1、2、3、4 个角落区域时，分别获得 3、8、12、18 分。\n· 合作模式中，玩家人数为 1、2、3、4 人时，分别须占据至少 1、2、3、4 个角落区域。",
				perimeter: "· 竞争模式中，每座至少有一部分位于外围区域的建筑获得 2 分。\n· 合作模式中，位于外围区域的建筑数量必须多于完全位于内部区域的建筑数量。",
				monuments: "· 竞争模式中，每座纪念碑额外获得 4 分。\n· 合作模式中，纪念碑数量至少须等于玩家人数。",
				enclosures: "· 竞争模式中，每片含有可见鱼的围合海域获得 2 分。\n· 合作模式中，玩家人数为 1、2、3、4 人时，分别须有至少 6、8、10、12 片这样的海域。",
				lines: "若完整一行或一列中的每个区域均有地基，则计为一条。\n· 竞争模式中，每条获得 2 分。\n· 合作模式中，玩家人数为 1、2、3、4 人时，分别须有至少 2、4、5、6 条。",
				sets: "木材、金属、橡胶和海藻建筑各 1 座组成一套。\n· 竞争模式中，每套获得 3 分。\n· 合作模式中，玩家人数为 1、2、3、4 人时，分别须有至少 5、8、10、12 套。",
				empty: "· 竞争模式中，每个没有地基的区域获得 2 分。\n· 合作模式中，玩家人数为 1、2、3、4 人时，分别须保留至少 9、8、6、5 个没有地基的区域。",
				full: "只有地基和船能够遮挡可见海格。\n· 竞争模式中，每个没有可见海格的区域获得 4 分。\n· 合作模式中，玩家人数为 1、2、3、4 人时，分别须有至少 5、11、18、26 个这样的区域。",
				plastic: "· 竞争模式中，每个有地基且没有可见塑料的区域获得 2 分。\n· 合作模式中，玩家人数为 1、2、3、4 人时，全图可见塑料分别不得超过 10、12、15、18 格。"
			},
			phase: {
				initial: "选择并放置起始漂流物",
				weather: "选择交给邻座的天气",
				expand: "扩张聚落并处理奖励",
				captain: "移动未停靠的船，或确认完成",
				ended: "本局结束"
			},
			waiting: "等待其他玩家",
			round: "第 {{n}}／4 轮",
			step: "第 {{n}} 次扩张",
			chooseTile: "选择漂流物",
			chooseJob: "处理新获得的物件",
			selectPosition: "在海图上选择放置位置",
			confirm: "确认放置",
			ready: "本次完成",
			finishRound: "完成移动",
			rotate: "旋转",
			flip: "翻面",
			build: "建造",
			close: "关闭",
			cancel: "取消选择",
			discard: "放弃物件",
			skipHouse: "暂不安置",
			donate: "献给天气",
			donateSurvivor: "献出1名幸存者",
			claimFish: "保留鱼牌",
			returnFish: "放回此牌",
			viewInfo: "天气与目标",
			viewMap: "查看海图",
			fullView: "回到全景",
			island: "中央岛",
			survivors: "待安置",
			residents: "居民",
			fish: "鱼",
			gardens: "花园",
			solar: "太阳能",
			boats: "船",
			fishValue: "{{n}} 条鱼",
			fishTokens: "{{n}} 张鱼牌",
			personalFish: "已保留鱼值",
			weatherTitle: "本轮天气",
			goalsTitle: "聚落目标",
			expertsTitle: "专家",
			completed: "已完成",
			unmet: "未完成",
			target: "{{n}}／{{target}}",
			plasticTarget: "{{n}}／最多 {{target}}",
			gardenCapacity: "花园 {{n}}，可供养 {{capacity}} 人",
			solarCapacity: "太阳能 {{n}}，船容量 {{capacity}}",
			shelterNeeded: "岛上还有 {{n}} 人等待入住",
			sharedFish: "现有 {{n}} 鱼，本轮需 {{need}} 鱼",
			noSpace: "目前没有合法放置位置",
			noBuildings: "最新地基尚不满足建造条件",
			noBuildingSupply: "符合条件的建筑已无剩余供给。",
			buildRequirements: "普通建筑需要铺满的2×2地基，其中至少3格同材，满桶可代替材料；该区域必须包含你最新放置的地基，且未被建筑、花园或网覆盖。先放置物件，再查看可建建筑。",
			chooseBuilding: "选择建筑后，在海图上选择位置",
			chooseResident: "选择一座建筑安置幸存者",
			chooseExpert: "选择一项永久专家能力",
			chooseReturn: "选择1张鱼牌放回袋中",
			carpenterOrder: "先触发另一面的奖励",
			sanctuaryRings: "选择移除的救生圈（最多3个）",
			newItems: "新获得",
			vortex: "漩涡",
			preserved: "本轮放弃的漂流物",
			supply: "剩余供给",
			moveBoat: "选择未停靠的船",
			boatNumber: "船 {{n}}",
			history: "对局记录",
			log: {
				place: "放置了{{n}}格物件",
				build: "建造了{{name}}",
				rescue: "救起{{n}}名幸存者",
				fish: "领取了{{n}}条鱼",
				weather: "完成了{{name}}",
				round: "进入第{{n}}轮",
				expert: "解锁了{{name}}",
				donate: "献出了1件资源",
				move: "移动了1艘船"
			},
			score: {
				buildings: "建筑",
				monuments: "纪念碑",
				gardens: "花园",
				survivors: "居民与幸存者",
				fish: "鱼",
				solar: "太阳能板",
				goals: "聚落目标",
				weather: "天气",
				total: "总分"
			},
			victory: "聚落成功度过四轮，并达成全部目标",
			defeat: "聚落未能继续生存",
			reason: {
				weather: "有玩家未能完成本轮天气要求。",
				housing: "仍有幸存者未能入住。",
				fish: "鱼不足以供养全部居民。",
				gardens: "花园容量不足以供养全部居民。",
				goals: "四轮结束时未同时达成两个聚落目标。"
			},
			buildingsTitle: "建筑图鉴",
			weatherGuide: "天气图鉴",
			goalsGuide: "聚落目标图鉴",
			expertsGuide: "专家能力",
			countsByPlayers: "合作模式的各项目标要求均按 1 人、2 人、3 人和 4 人的顺序说明。",
			replay: "查看终局海图",
			foodNeed: "储备 / 本轮需求",
			pendingItems: "待处理物件",
			peopleCapacity: "供养 {{n}} 人",
			boatCapacity: "容量 {{n}} 艘",
			goalDetails: "目标说明",
			sharedMap: "共同海图",
			moreActions: "更多操作",
			resultTitle: "海上聚落 · 本局结算",
			winnerNames: "{{names}} 获胜",
			winner: "获胜",
			reviewHide: "收起结算，查看海图",
			reviewShow: "查看结算",
			scoreItem: "计分项目",
			confirmAgain: "确认再来一局",
			confirmLobby: "确认返回大厅",
			bot: {
				choose: "选择第{{n}}号漂流物。",
				place: "放置{{item}}：左上角坐标为（{{x}}，{{y}}），旋转{{rotation}}°{{flip}}。",
				flipped: "，并翻面",
				build: "在（{{x}}，{{y}}）建造{{building}}{{reverse}}{{rings}}。",
				reverse: "，先触发另一面的奖励",
				rings: "，移除坐标为{{positions}}的救生圈",
				donate: "将{{item}}献给第{{n}}位玩家的天气。",
				house: "将1名幸存者安置到（{{x}}，{{y}}）的{{building}}。",
				expert: "解锁{{expert}}。",
				return: "将第{{n}}张鱼牌放回袋中。",
				discard: "放弃{{item}}。",
				move: "移动船{{n}}：左上角坐标为（{{x}}，{{y}}），旋转{{rotation}}°。",
				survivor: "1名幸存者"
			},
			errAction: "当前无法执行此操作，请检查阶段、物件与放置条件。"
		},
		en: {
			name: "Kalypso",
			desc: "Build a floating settlement from salvage. Compete for points, or work together to shelter survivors through four rounds.",
			rules: "Goal and setup:\nCompetitive mode supports 2–4 players, each with a 20×20 ocean. Cooperative mode supports 2–4 players on one 40×40 ocean; solo uses the cooperative ocean. Play four rounds. Competitive: the highest score wins. Cooperative and solo: complete every player's forecast, shelter every survivor, spend 2 fish per settler and provide enough garden capacity each round, then meet both settlement goals.\nCompetitive players start with 2 survivors, 4 half-submerged barrels and 8 life preservers. The shared ocean has 16 barrels and 16 life preservers; survivors arrive on the island each round according to difficulty. Draw 2 salvage, place 1 and return the other to the bag. Competitive initial salvage must touch or cover the central white circle; cooperative initial salvage must adjoin different sides of the island orthogonally.\n\nRound sequence:\nCompetitive players secretly select an unused forecast to pass to their neighbour, revealing together. Pass counterclockwise in rounds 1/3 and clockwise in rounds 2/4. Cooperative and solo reveal one common forecast each round; each player must meet their own quota, and newly gained resources may be shared.\nIn multiplayer, draw 5 salvage per vortex. Choose 1, rotate or mirror it, place it and resolve every bonus before confirming. Once everyone confirms, pass vortices clockwise in rounds 1/3 and counterclockwise in rounds 2/4. Place four per round and remove the final tile from play. Solo: draw 2, keep 1 and set the other aside, five times per round; then remove those five rejected tiles. The Salvager may place the final vortex tile, or solo's fifth rejected tile, as an extra placement.\n\nFoundation and expansion:\nSalvage, scrap, full barrels and docked boats form foundation; the cooperative island also counts. New foundation must adjoin existing foundation orthogonally. Boats may be placed on any unoccupied ocean and become permanently docked when they touch foundation orthogonally. A docked boat can support further expansion. An item may extend beyond the ocean, provided at least one cell remains on it. Items cannot overlap each other or the island.\nCovering a half-submerged barrel gains that barrel: place it beside foundation as a wild material. Covering a life preserver rescues a survivor. Cooperative survivors wait on the island and must still become settlers; a rescue may also unlock an unused specialist. Resolve new items before passing the vortex. An item can be returned or lost only if it cannot be placed; a House's settling bonus is optional.\n\nConstruction and settlers:\nThe most recently placed foundation item must contribute to the building area. A fully covered 2×2 square with at least 3 identical wood, metal, rubber or seaweed icons allows either face of that material's building. Full barrels are wild; at most one cell may be plastic. Buildings cannot overlap buildings, gardens or nets. Resolve the reward immediately. A House lets you place one reserve/island survivor on an unoccupied building other than a House or Monument, triggering that building again. The cooperative Sun forecast allows a survivor on a newly built House, without another reward.\nA 3×3 foundation square with at least 5 matching material icons allows a Monument worth 11 VP. In cooperative play it only helps goals, unless the Guardian builds a Sanctuary. Building, forecast and specialist details appear in the reference below.\n\nFishing and enclosures:\nA Net Workshop provides a 1×2 net. Cast it in a 4×4 zone containing one of your boats, once per zone. A net cannot cross zones or enter an enclosure. Draw one fish token for each visible, unclaimed fish in that zone. If there is no room, or the net would cover a barrel or preserver, stack it on the boat as a marker. Later expansion may move a net onto the boat. Gardens are 1×2 and cover completed foundation; the shared island also allows up to two gardens.\nFish tokens show 0, 1, 2 or 3 fish, or a barrel. Competitive values are private, but token count is public. Cooperative values immediately add to the shared fish track and the tokens leave play. A barrel token provides a full barrel.\nFoundation completely surrounding an ocean area immediately collects visible barrels and life preservers. Competitive enclosed fish still visible at game end score 1 VP each; cooperative enclosures provide 1 fish per icon immediately. A fish cannot be claimed both by fishing and enclosure. Ocean edges, zone borders and nets are not enclosure walls. Diagonal foundation helps only when it belongs to the same orthogonally connected settlement.\n\nForecasts and survival:\nA newly gained item may be used normally or assigned to the current forecast, where it stays for the rest of the game. Competitive reserve survivors may be assigned at any time. Forecast resources are rewarded immediately, scoring bonuses at game end. Competitive failures lose the stated VP; any cooperative player's failure loses the game.\nAt the end of each cooperative round, complete these checks in order:\n· Check each player’s forecast.\n· Check that every survivor is housed.\n· Spend 2 fish per settler.\n· Check that garden capacity is sufficient.\nGardens persist. Capacities for 1–14 gardens are 2,4,6,7,8,10,11,12,14,15,16,18,19,20 settlers.\nSolar panels limit boats at sea: capacities for 1–13 solar are 2,4,5,6,8,10,11,12,14,15,16,18,20. Forecast boat rewards can exceed capacity. After successful survival checks, the Captain may move undocked boats.\n\nCompetitive scoring and ties:\nAdd the following scoring categories:\n· Each building scores its printed victory points, and each Monument scores 11 victory points.\n· Each Garden scores 1 point per orthogonally adjacent building, up to 5 points.\n· Each Solar Panel scores 1 point per orthogonally adjacent visible ocean cell, up to 7 points. Off-board space counts as ocean; fish, life preservers and half-submerged barrels do not block visibility.\n· Each settler scores 3 points, and each reserve survivor scores 2 points.\n· Retained fish tokens score their printed values. Add the points for visible enclosed fish, both settlement goals and forecasts. Break ties by least visible plastic, most settlers, most Monuments, most buildings, then share victory.\nThis game follows the workshop's development rulebook and current cards. Component stock follows the rulebook; the empty-zone goal counts unoccupied zones.",
			mode: {
				competitive: "Competitive",
				cooperative: "Cooperative",
				solo: "Solo"
			},
			difficulty: {
				learning: "Learning",
				easy: "Easy",
				medium: "Medium",
				hard: "Hard"
			},
			optMode: "Game mode",
			optDifficulty: "Survival difficulty",
			material: {
				wood: "Wood",
				metal: "Metal",
				rubber: "Rubber",
				seaweed: "Seaweed",
				plastic: "Plastic",
				wild: "Wild material"
			},
			item: {
				tile: "Salvage",
				scrap: "Scrap",
				barrel: "Full barrel",
				boat: "Boat",
				garden: "Garden",
				net: "Net",
				fish: "Fish token",
				house: "Settle a survivor",
				expert: "Choose a specialist",
				catch: "Return one fish token"
			},
			building: {
				house: "House",
				cooper: "Cooper",
				shipyard: "Shipyard",
				solar: "Solar panel",
				scrapyard: "Scrapyard",
				warehouse: "Warehouse",
				netWorkshop: "Net Workshop",
				greenhouse: "Greenhouse",
				monument: "Monument",
				sanctuary: "Sanctuary"
			},
			effect: {
				house: "Settle one survivor on an unoccupied building other than a House or Monument, triggering its reward again.",
				cooper: "Gain one full barrel.",
				shipyard: "Gain a 1×3 boat. Cooperative boats require solar capacity.",
				solar: "In competitive mode, score 1 point for each orthogonally adjacent visible ocean cell, up to 7 points. In cooperative mode, add 1 solar.",
				scrapyard: "Draw and place two 1×2 scrap tiles separately.",
				warehouse: "Draw and place one extra salvage.",
				netWorkshop: "Gain a 1×2 net and fish in a zone with a boat.",
				greenhouse: "Gain a 1×2 garden to place on completed foundation.",
				monument: "Build a Monument on a complete 3×3 foundation area with at least five cells of the same material. In competitive mode, each Monument scores 11 points.",
				sanctuary: "With the Guardian specialist, you may build a Sanctuary using the Monument requirements. Immediately remove up to three life preservers without rescuing survivors or unlocking specialists."
			},
			weather: {
				sun: "Sun Beats Down",
				rain: "Raindrops Keep Falling",
				dock: "Sitting on the Dock",
				drought: "An Ironic Drought",
				hatches: "Batten the Hatches",
				teeth: "Rows of Teeth",
				storm: "Storms a Comin’"
			},
			weatherNeed: {
				sun: "Contribute 1 survivor or 2 fish tokens.",
				rain: "Contribute 1 full barrel and 1 garden.",
				dock: "Contribute 1 fish token and 1 garden.",
				drought: "Contribute 1 survivor and 1 full barrel.",
				hatches: "Contribute 3 scrap tiles.",
				teeth: "Contribute 1 survivor and 1 boat.",
				storm: "Contribute 2 boats."
			},
			weatherNeedCoop: {
				sun: "Settle 1 survivor in a House built this round.",
				rain: "Contribute 2 full barrels.",
				dock: "Contribute 1 fish token and 1 garden.",
				drought: "Contribute 1 garden and 1 full barrel.",
				hatches: "Contribute 2 scrap tiles.",
				teeth: "Contribute 1 net and 1 boat.",
				storm: "Contribute 1 boat."
			},
			weatherReward: {
				sun: "If completed, score 1 additional point per Solar Panel at game end. If not completed, lose 3 points.",
				rain: "If completed, score 1 additional point per Garden at game end. If not completed, lose 3 points.",
				dock: "If completed, score 1 additional point per reserve survivor at game end. If not completed, lose 3 points.",
				drought: "If completed, immediately gain 2 scrap tiles. If not completed, lose 3 points at game end.",
				hatches: "If completed, immediately gain 1 boat. If not completed, lose 2 points at game end for each missing scrap tile.",
				teeth: "If completed, immediately draw and resolve 2 fish tokens. If not completed, lose 6 points at game end.",
				storm: "If completed, immediately gain 2 full barrels. If not completed, lose 4 points at game end for each missing boat."
			},
			weatherRewardCoop: {
				sun: "After every player completes their requirement, increase the team’s solar by 1 in total.",
				rain: "After every player completes their requirement, advance the team’s garden track by 1 space in total.",
				dock: "After completing the requirement, immediately draw and place 1 salvage tile.",
				drought: "After completing the requirement, immediately gain 2 scrap tiles.",
				hatches: "After completing the requirement, immediately gain 1 boat. This boat may exceed solar capacity.",
				teeth: "After completing the requirement, immediately draw and resolve 2 fish tokens.",
				storm: "After completing the requirement, immediately gain 1 full barrel."
			},
			expert: {
				angler: "Angler",
				carpenter: "Carpenter",
				guardian: "Guardian",
				salvager: "Salvager",
				captain: "Captain"
			},
			expertEffect: {
				angler: "Fish from any zone containing foundation, without needing a boat.",
				carpenter: "If a 2×2 building area contains four cells of the same material and no barrels, trigger the rewards on both faces in your chosen order. Choose one face to remain visible; future settlers trigger only that face’s reward.",
				guardian: "You may build a Sanctuary. When it is built, immediately remove up to three life preservers without rescuing survivors. Any unused removal allowance cannot be used later.",
				salvager: "Optionally place the final vortex tile each round; solo may place the fifth rejected tile.",
				captain: "When fishing, draw one extra fish token, then choose one to return. After passing the round-end survival checks, move each undocked boat up to one zone while keeping part of it in at least one zone it originally occupied."
			},
			goal: {
				groups: "Matching building groups",
				corners: "Corner buildings",
				perimeter: "Perimeter buildings",
				monuments: "Monuments",
				enclosures: "Enclosures with fish",
				lines: "Zone rows and columns",
				sets: "Four-material sets",
				empty: "Empty zones",
				full: "Filled zones",
				plastic: "Control plastic"
			},
			goalRule: {
				groups: "Each group consists of at least 2 orthogonally adjacent buildings made of the same material.\n· In competitive mode, score 2 points per group.\n· In cooperative mode, you need at least 3, 6, 9, or 12 groups with 1, 2, 3, or 4 players, respectively.",
				corners: "· In competitive mode, buildings in 1, 2, 3, or 4 corner zones score 3, 8, 12, or 18 points, respectively.\n· In cooperative mode, you need to occupy at least 1, 2, 3, or 4 corner zones with 1, 2, 3, or 4 players, respectively.",
				perimeter: "· In competitive mode, score 2 points per building with at least part of its foundation in a perimeter zone.\n· In cooperative mode, you need more buildings in perimeter zones than buildings entirely in inner zones.",
				monuments: "· In competitive mode, score 4 additional points per Monument.\n· In cooperative mode, you need at least as many Monuments as there are players.",
				enclosures: "· In competitive mode, score 2 points per enclosed area of ocean containing visible fish.\n· In cooperative mode, you need at least 6, 8, 10, or 12 such areas with 1, 2, 3, or 4 players, respectively.",
				lines: "A complete row or column counts as one line if every zone in it contains foundation.\n· In competitive mode, score 2 points per line.\n· In cooperative mode, you need at least 2, 4, 5, or 6 lines with 1, 2, 3, or 4 players, respectively.",
				sets: "One building each made of wood, metal, rubber, and seaweed forms a set.\n· In competitive mode, score 3 points per set.\n· In cooperative mode, you need at least 5, 8, 10, or 12 sets with 1, 2, 3, or 4 players, respectively.",
				empty: "· In competitive mode, score 2 points per zone without foundation.\n· In cooperative mode, you need to retain at least 9, 8, 6, or 5 zones without foundation with 1, 2, 3, or 4 players, respectively.",
				full: "Only foundation and boats cover visible ocean cells.\n· In competitive mode, score 4 points per zone with no visible ocean cells.\n· In cooperative mode, you need at least 5, 11, 18, or 26 such zones with 1, 2, 3, or 4 players, respectively.",
				plastic: "· In competitive mode, score 2 points per zone containing foundation but no visible plastic.\n· In cooperative mode, the whole map may contain at most 10, 12, 15, or 18 visible plastic cells with 1, 2, 3, or 4 players, respectively."
			},
			phase: {
				initial: "Choose and place initial salvage",
				weather: "Choose a forecast for your neighbour",
				expand: "Expand and resolve your rewards",
				captain: "Move undocked boats or finish",
				ended: "Game over"
			},
			waiting: "Waiting for other players",
			round: "Round {{n}}/4",
			step: "Expansion {{n}}",
			chooseTile: "Choose salvage",
			chooseJob: "Resolve new items",
			selectPosition: "Choose a position on the ocean",
			confirm: "Confirm placement",
			ready: "Finish this step",
			finishRound: "Finish moving",
			rotate: "Rotate",
			flip: "Mirror",
			build: "Build",
			close: "Close",
			cancel: "Clear selection",
			discard: "Discard item",
			skipHouse: "Skip settling",
			donate: "Assign to forecast",
			donateSurvivor: "Assign 1 survivor",
			claimFish: "Keep fish",
			returnFish: "Return this token",
			viewInfo: "Forecasts and goals",
			viewMap: "View ocean",
			fullView: "Fit ocean",
			island: "Central island",
			survivors: "Awaiting housing",
			residents: "Settlers",
			fish: "Fish",
			gardens: "Gardens",
			solar: "Solar",
			boats: "Boats",
			fishValue: "{{n}} fish",
			fishTokens: "{{n}} fish tokens",
			personalFish: "Retained fish value",
			weatherTitle: "Current forecast",
			goalsTitle: "Settlement goals",
			expertsTitle: "Specialists",
			completed: "Complete",
			unmet: "Incomplete",
			target: "{{n}}/{{target}}",
			plasticTarget: "{{n}}/max {{target}}",
			gardenCapacity: "{{n}} gardens: capacity {{capacity}}",
			solarCapacity: "{{n}} solar: {{capacity}} boats",
			shelterNeeded: "{{n}} survivors on the island",
			sharedFish: "{{n}} fish available; {{need}} needed",
			noSpace: "No legal placement available",
			noBuildings: "The latest foundation cannot support a building",
			chooseBuilding: "Choose a building, then its position",
			chooseResident: "Choose a building for the survivor",
			chooseExpert: "Choose a permanent specialist ability",
			chooseReturn: "Choose one token to return",
			carpenterOrder: "Resolve the other face first",
			sanctuaryRings: "Choose up to 3 preservers to remove",
			noBuildingSupply: "No matching buildings remain in the supply.",
			buildRequirements: "A regular building needs a filled 2×2 foundation with at least 3 matching materials; full barrels are wild. The area must include your latest foundation placement and be free of buildings, gardens and nets. Place an item, then check the available buildings.",
			newItems: "New items",
			vortex: "Vortex",
			preserved: "Rejected salvage this round",
			supply: "Supply",
			moveBoat: "Choose an undocked boat",
			boatNumber: "Boat {{n}}",
			history: "History",
			log: {
				place: "placed {{n}} cells",
				build: "built {{name}}",
				rescue: "rescued {{n}} survivors",
				fish: "claimed {{n}} fish",
				weather: "completed {{name}}",
				round: "started round {{n}}",
				expert: "unlocked {{name}}",
				donate: "assigned 1 resource",
				move: "moved 1 boat"
			},
			score: {
				buildings: "Buildings",
				monuments: "Monuments",
				gardens: "Gardens",
				survivors: "Settlers and survivors",
				fish: "Fish",
				solar: "Solar panels",
				goals: "Settlement goals",
				weather: "Forecasts",
				total: "Total"
			},
			victory: "The settlement survived four rounds and met both goals",
			defeat: "The settlement could not survive",
			reason: {
				weather: "A player did not complete the forecast.",
				housing: "Some survivors still need housing.",
				fish: "There are not enough fish for all settlers.",
				gardens: "Garden capacity is insufficient for all settlers.",
				goals: "Both settlement goals were not met after four rounds."
			},
			buildingsTitle: "Building reference",
			weatherGuide: "Forecast reference",
			goalsGuide: "Settlement goal reference",
			expertsGuide: "Specialist abilities",
			countsByPlayers: "Each cooperative goal lists its requirements for 1, 2, 3, and 4 players, in that order.",
			replay: "View final ocean",
			errAction: "That action is unavailable. Check the phase, item and placement requirements.",
			foodNeed: "Stored / needed",
			pendingItems: "New items",
			peopleCapacity: "Supports {{n}} people",
			boatCapacity: "Capacity {{n}} boats",
			goalDetails: "Goal details",
			sharedMap: "Shared sea chart",
			moreActions: "More actions",
			resultTitle: "Sea settlement · Results",
			winnerNames: "{{names}} won",
			winner: "Winner",
			reviewHide: "Hide results and view the chart",
			reviewShow: "Show results",
			scoreItem: "Scoring",
			confirmAgain: "Confirm new game",
			confirmLobby: "Confirm return to lobby",
			bot: {
				choose: "Choose salvage tile {{n}}.",
				place: "Place {{item}} with its top-left corner at ({{x}}, {{y}}), rotated {{rotation}}°{{flip}}.",
				flipped: " and flipped",
				build: "Build {{building}} at ({{x}}, {{y}}){{reverse}}{{rings}}.",
				reverse: ", resolving the other face first",
				rings: ", removing life preservers at {{positions}}",
				donate: "Assign {{item}} to player {{n}}'s forecast.",
				house: "House one survivor in {{building}} at ({{x}}, {{y}}).",
				expert: "Unlock {{expert}}.",
				return: "Return fish token {{n}} to the bag.",
				discard: "Discard {{item}}.",
				move: "Move boat {{n}} with its top-left corner at ({{x}}, {{y}}), rotated {{rotation}}°.",
				survivor: "one survivor"
			}
		}
	}
};
//#endregion
export { mn as default };
