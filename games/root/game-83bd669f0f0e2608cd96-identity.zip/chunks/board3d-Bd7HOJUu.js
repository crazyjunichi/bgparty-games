import { C as e, D as t, M as n, b as r, g as i, i as a, j as o, m as s, n as c, r as l, t as u, w as d } from "@bgparty/game/chunks/board-view-A2R57WV5.js";
import { useCallback as f, useEffect as p, useImperativeHandle as m, useLayoutEffect as h, useMemo as g, useRef as _, useState as v } from "react";
import { useFxAnchor as ee } from "@bgparty/sdk/fx/anchors";
import { Fragment as y, jsx as b, jsxs as x } from "react/jsx-runtime";
import { IconRecenter as te, IconZoomIn as ne, IconZoomOut as re } from "@bgparty/sdk/icons";
import { useFrame as S, useThree as ie } from "@react-three/fiber";
import { AmbientLight as ae, BoxGeometry as C, BufferGeometry as oe, CatmullRomCurve3 as w, CircleGeometry as se, Color as ce, ConeGeometry as T, CylinderGeometry as le, DirectionalLight as ue, DodecahedronGeometry as E, Float32BufferAttribute as de, Group as D, InstancedMesh as O, Mesh as k, MeshBasicMaterial as fe, MeshLambertMaterial as pe, Object3D as me, OrthographicCamera as he, PlaneGeometry as ge, RingGeometry as _e, Shape as ve, ShapeGeometry as ye, SphereGeometry as be, TorusGeometry as xe, Vector3 as A } from "three";
import { ResilientCanvas as Se } from "@bgparty/sdk/three/resilient-canvas";
//#region src/games/root/pieces3d.tsx
var j = /* @__PURE__ */ new Map(), M = {
	box: new C(1, 1, 1),
	ball: new be(1, 10, 7),
	stone: new E(1, 0),
	cone: new T(1, 1, 7),
	roof: new T(1, 1, 4),
	trunk: new le(1, 1, 1, 8),
	ring: new xe(1, .19, 5, 12)
};
function N(e) {
	return j.has(e) || j.set(e, new pe({
		color: e,
		flatShading: !0
	})), j.get(e);
}
function P(e, t, n, r, i, a = [
	0,
	0,
	0
]) {
	let o = new k(M[t], N(n));
	return o.position.set(...r), o.scale.set(...i), o.rotation.set(...a), e.add(o), o;
}
var Ce = new fe({
	color: s.ink,
	transparent: !0,
	opacity: .16,
	depthWrite: !1
});
function F(e, t = .32) {
	let n = new k(M.ball, Ce);
	n.position.set(.06, .012, -.03), n.scale.set(t, .008, t * .65), e.add(n);
}
function I(e, t, n, r = .078) {
	for (let i of [-r, r]) P(e, "ball", s.ink, [
		i,
		t,
		n
	], [
		.022,
		.027,
		.017
	]);
}
function we(e) {
	let t = new D(), n = s[e], r = e === "eyrie" || e === "corvid";
	if (F(t), P(t, "trunk", s.bark, [
		0,
		.055,
		0
	], [
		.21,
		.1,
		.18
	]), P(t, "cone", n, [
		0,
		.3,
		0
	], [
		.24,
		.48,
		.2
	]), e === "vagabond") {
		P(t, "cone", s.pine, [
			0,
			.39,
			-.035
		], [
			.29,
			.58,
			.24
		]), P(t, "ball", s.vagabond, [
			0,
			.67,
			.04
		], [
			.2,
			.18,
			.16
		]);
		for (let e of [-.14, .14]) P(t, "ball", s.ink, [
			e,
			.8,
			.02
		], [
			.065,
			.075,
			.06
		]);
		P(t, "box", s.ink, [
			0,
			.68,
			.178
		], [
			.33,
			.073,
			.025
		]), I(t, .69, .197), P(t, "box", s.gold, [
			0,
			.49,
			.19
		], [
			.32,
			.07,
			.03
		], [
			0,
			0,
			-.12
		]), P(t, "ball", s.bark, [
			-.23,
			.38,
			-.11
		], [
			.14,
			.19,
			.11
		]), P(t, "trunk", s.bark, [
			.27,
			.42,
			.09
		], [
			.025,
			.76,
			.025
		], [
			0,
			0,
			-.13
		]), P(t, "ball", s.gold, [
			.31,
			.86,
			.09
		], [
			.05,
			.08,
			.05
		]);
	} else if (e === "alliance") {
		P(t, "ball", s.paper, [
			0,
			.65,
			.035
		], [
			.19,
			.18,
			.15
		]);
		for (let e of [-.16, .16]) P(t, "ball", n, [
			e,
			.81,
			0
		], [
			.1,
			.12,
			.065
		]), P(t, "ball", s.paper, [
			e,
			.81,
			.054
		], [
			.055,
			.073,
			.018
		]);
		P(t, "cone", n, [
			0,
			.81,
			-.04
		], [
			.23,
			.18,
			.18
		], [
			0,
			0,
			-.2
		]), P(t, "ball", s.paper, [
			0,
			.59,
			.175
		], [
			.12,
			.065,
			.085
		]), I(t, .68, .178), P(t, "ball", s.ink, [
			0,
			.61,
			.26
		], [
			.025,
			.024,
			.023
		]), P(t, "box", s.gold, [
			0,
			.49,
			.16
		], [
			.3,
			.07,
			.04
		]), P(t, "box", s.bark, [
			.25,
			.38,
			.08
		], [
			.035,
			.65,
			.035
		]), P(t, "cone", s.stone, [
			.25,
			.76,
			.08
		], [
			.065,
			.19,
			.04
		]), P(t, "ring", n, [
			-.2,
			.2,
			-.18
		], [
			.14,
			.14,
			.14
		], [
			0,
			.7,
			.6
		]);
	} else if (r) {
		P(t, "ball", n, [
			0,
			.64,
			.025
		], [
			.19,
			.22,
			.16
		]), P(t, "cone", s.gold, [
			0,
			.6,
			.24
		], [
			.064,
			.23,
			.045
		], [
			Math.PI / 2,
			0,
			0
		]), I(t, .69, .174), P(t, "cone", n, [
			-.06,
			.88,
			-.07
		], [
			.12,
			.24,
			.06
		], [
			0,
			0,
			.25
		]);
		for (let e of [-.21, .21]) P(t, "stone", n, [
			e,
			.38,
			-.035
		], [
			.075,
			.24,
			.13
		], [
			0,
			0,
			e > 0 ? -.25 : .25
		]);
		P(t, "box", s.paper, [
			0,
			.48,
			.12
		], [
			.3,
			.09,
			.1
		]), P(t, "box", s.bark, [
			.28,
			.42,
			.02
		], [
			.028,
			.85,
			.028
		]), P(t, "cone", s.stone, [
			.28,
			.94,
			.02
		], [
			.065,
			.2,
			.045
		]);
	} else {
		P(t, "ball", n, [
			0,
			.64,
			.02
		], [
			.21,
			.19,
			.17
		]);
		for (let e of [-.145, .145]) P(t, "cone", n, [
			e,
			.84,
			0
		], [
			.1,
			.24,
			.07
		], [
			0,
			0,
			e > 0 ? -.14 : .14
		]);
		P(t, "ball", s.paper, [
			0,
			.58,
			.166
		], [
			.13,
			.07,
			.035
		]), I(t, .68, .182), P(t, "cone", s.ink, [
			0,
			.6,
			.21
		], [
			.032,
			.045,
			.024
		], [
			0,
			0,
			Math.PI
		]);
		for (let e of [-.14, .14]) P(t, "box", s.ink, [
			e,
			.58,
			.2
		], [
			.1,
			.012,
			.01
		], [
			0,
			0,
			e > 0 ? .12 : -.12
		]);
		P(t, "box", s.pine, [
			0,
			.47,
			.07
		], [
			.34,
			.08,
			.24
		]), P(t, "ring", n, [
			-.18,
			.24,
			-.19
		], [
			.15,
			.15,
			.15
		], [
			.4,
			0,
			.45
		]), P(t, "box", s.bark, [
			.27,
			.39,
			.07
		], [
			.035,
			.78,
			.035
		]), P(t, "cone", s.stone, [
			.27,
			.87,
			.07
		], [
			.063,
			.18,
			.04
		]);
	}
	return t;
}
function Te(e, t) {
	let n = new D(), r = s[t];
	if (F(n, .42), e === "wood") for (let [e, t] of [
		[-.13, .12],
		[.13, .12],
		[0, .32]
	]) P(n, "trunk", s.bark, [
		e,
		t,
		0
	], [
		.12,
		.64,
		.12
	], [
		Math.PI / 2,
		0,
		0
	]), P(n, "trunk", s.gold, [
		e,
		t,
		.326
	], [
		.095,
		.012,
		.095
	], [
		Math.PI / 2,
		0,
		0
	]);
	else if (e === "sympathy" || e === "plot" || e === "tunnel") P(n, "trunk", r, [
		0,
		.055,
		0
	], [
		.32,
		.09,
		.32
	]), e === "sympathy" ? (P(n, "box", s.paper, [
		0,
		.115,
		0
	], [
		.075,
		.025,
		.46
	], [
		0,
		-.55,
		0
	]), P(n, "box", s.paper, [
		0,
		.12,
		0
	], [
		.075,
		.025,
		.46
	], [
		0,
		.55,
		0
	]), P(n, "ball", s.gold, [
		0,
		.13,
		0
	], [
		.08,
		.015,
		.08
	])) : P(n, "ring", s.ink, [
		0,
		.12,
		0
	], [
		.17,
		.17,
		.17
	], [
		Math.PI / 2,
		0,
		0
	]);
	else if (e === "roost") {
		for (let e of [-.24, .24]) P(n, "box", s.bark, [
			e,
			.37,
			0
		], [
			.09,
			.74,
			.09
		]);
		P(n, "box", s.paper, [
			0,
			.63,
			0
		], [
			.65,
			.12,
			.5
		]), P(n, "ring", s.bark, [
			0,
			.76,
			0
		], [
			.25,
			.25,
			.25
		], [
			Math.PI / 2,
			0,
			0
		]), P(n, "roof", r, [
			0,
			1.09,
			0
		], [
			.55,
			.33,
			.48
		], [
			0,
			Math.PI / 4,
			0
		]), P(n, "box", s.bark, [
			.1,
			1.29,
			0
		], [
			.025,
			.36,
			.025
		]), P(n, "box", r, [
			.23,
			1.39,
			0
		], [
			.24,
			.13,
			.025
		]);
	} else if (e === "keep") {
		P(n, "box", s.stone, [
			0,
			.26,
			0
		], [
			.7,
			.5,
			.58
		]), P(n, "box", s.bark, [
			0,
			.18,
			.3
		], [
			.2,
			.33,
			.035
		]);
		for (let e of [-.33, .33]) for (let t of [-.26, .26]) P(n, "box", s.stone, [
			e,
			.41,
			t
		], [
			.23,
			.8,
			.23
		]), P(n, "roof", r, [
			e,
			.93,
			t
		], [
			.23,
			.27,
			.23
		], [
			0,
			Math.PI / 4,
			0
		]);
		P(n, "box", s.bark, [
			0,
			.95,
			0
		], [
			.03,
			.55,
			.03
		]), P(n, "box", r, [
			.15,
			1.14,
			0
		], [
			.3,
			.16,
			.03
		]);
	} else if (e === "base") P(n, "cone", r, [
		0,
		.35,
		0
	], [
		.49,
		.66,
		.38
	]), P(n, "cone", s.ink, [
		0,
		.19,
		.31
	], [
		.16,
		.37,
		.07
	]), P(n, "box", s.bark, [
		.4,
		.43,
		0
	], [
		.025,
		.85,
		.025
	]), P(n, "box", s.gold, [
		.52,
		.78,
		0
	], [
		.25,
		.14,
		.03
	]);
	else {
		P(n, "box", s.paper, [
			0,
			.24,
			0
		], [
			.64,
			.46,
			.52
		]), P(n, "roof", r, [
			0,
			.66,
			0
		], [
			.56,
			.4,
			.47
		], [
			0,
			Math.PI / 4,
			0
		]), P(n, "box", s.bark, [
			0,
			.17,
			.27
		], [
			.16,
			.32,
			.025
		]);
		for (let e of [-.22, .22]) P(n, "box", s.ink, [
			e,
			.29,
			.272
		], [
			.09,
			.11,
			.022
		]);
		if (e === "sawmill") {
			P(n, "trunk", s.stone, [
				.42,
				.27,
				.02
			], [
				.27,
				.055,
				.27
			], [
				0,
				0,
				Math.PI / 2
			]);
			for (let e = 0; e < 8; e++) P(n, "box", s.stone, [
				.42,
				.27 + Math.sin(e * Math.PI / 4) * .25,
				.02 + Math.cos(e * Math.PI / 4) * .25
			], [
				.055,
				.09,
				.09
			], [
				e * Math.PI / 4,
				0,
				0
			]);
			P(n, "trunk", s.bark, [
				-.42,
				.12,
				.1
			], [
				.1,
				.7,
				.1
			], [
				Math.PI / 2,
				0,
				0
			]);
		} else e === "workshop" ? (P(n, "box", s.stone, [
			.16,
			.75,
			-.08
		], [
			.15,
			.74,
			.16
		]), P(n, "box", s.ink, [
			.16,
			1.14,
			-.08
		], [
			.21,
			.06,
			.22
		]), P(n, "box", s.bark, [
			-.42,
			.17,
			.2
		], [
			.23,
			.07,
			.36
		])) : (P(n, "box", s.bark, [
			-.42,
			.44,
			.06
		], [
			.025,
			.87,
			.025
		]), P(n, "box", r, [
			-.28,
			.79,
			.06
		], [
			.28,
			.2,
			.025
		]), P(n, "box", s.paper, [
			-.28,
			.79,
			.08
		], [
			.035,
			.12,
			.012
		]));
	}
	return n;
}
//#endregion
//#region src/games/root/board3d.tsx
var L = /* @__PURE__ */ new Map(), R = /* @__PURE__ */ new Map(), z = (e) => (R.has(e) || R.set(e, new fe({ color: e })), R.get(e));
function B(e, t) {
	return L.has(e) || L.set(e, t()), L.get(e);
}
function V(e, t, n, r, i = [
	1,
	1,
	1
], a = [
	0,
	0,
	0
]) {
	let o = new k(t, n);
	return o.position.set(...r), o.scale.set(...i), o.rotation.set(...a), e.add(o), o;
}
var H = new ge(1, 1), U = new E(1, 0), Ee = new le(1, 1, 1, 7), De = new T(1, 1, 7), Oe = new E(1, 1), [W, G, K, q, J] = [
	5,
	10,
	11,
	7,
	4
].map(n), ke = new w([
	new A(1.6, 0, -8),
	new A(W.x + 1, 0, W.z - 1.2),
	new A(W.x + 1.1, 0, W.z - .1),
	new A(G.x + 1.1, 0, G.z - .6),
	new A(G.x + 1.3, 0, G.z + .3),
	new A(K.x + .9, 0, K.z - .9),
	new A(K.x + 1.2, 0, K.z + .6),
	new A(q.x + 1.2, 0, q.z + .5),
	new A(q.x - .2, 0, q.z + .9),
	new A(J.x + 1.2, 0, J.z - 1),
	new A(J.x - .5, 0, J.z - 1.1),
	new A(J.x - 1.3, 0, J.z + .4),
	new A(-8, 0, 5)
]), Ae = ke.getPoints(120);
function je(e, t, n, r) {
	let i = r.x - n.x, a = r.z - n.z, o = Math.max(0, Math.min(1, ((e - n.x) * i + (t - n.z) * a) / (i * i + a * a)));
	return Math.hypot(e - n.x - o * i, t - n.z - o * a);
}
function Y(e) {
	let t = Math.sin(e * 127.1 + 311.7) * 43758.5453;
	return t - Math.floor(t);
}
function Me(e) {
	let t = r[e], n = (e) => t.clearings.find((t) => t.id === e);
	return Array.from({ length: 2300 }, (e, t) => ({
		x: Y(t * 3) * 17 - 8.5,
		z: Y(t * 3 + 1) * 18 - 9,
		h: .61 + Y(t * 3 + 2) * .72,
		kind: t % 9 == 0 ? "broad" : "pine",
		color: t % 17 == 0 ? s.orange : t % 19 == 0 ? s.gold : [
			s.pine,
			s.pineLight,
			s.pine,
			s.leaf,
			s.pineLight,
			s.pineDark
		][t % 6]
	})).filter((r) => !(e === "lake" && (r.x - .6) ** 2 / 3.5 + (r.z - .5) ** 2 / 4.7 < 1) && !t.clearings.some((e) => Math.hypot(e.x - r.x, (e.z + .22 - r.z) * 1.12) < 1.27) && !t.paths.some(([e, t]) => je(r.x, r.z, n(e), n(t)) < .38) && !(e === "autumn" ? Ae.some((e) => Math.hypot(e.x - r.x, e.z - r.z) < .6) : t.rivers.some(([e, t]) => je(r.x, r.z, n(e), n(t)) < .65))).filter((e, t) => t % 3 == 0).slice(0, 470);
}
function Ne(e) {
	let t = new D(), n = Me(e), r = n.filter((e) => e.kind === "pine"), i = n.filter((e) => e.kind === "broad"), a = [
		new O(De, N("#ffffff"), r.length * 3),
		new O(Oe, N("#ffffff"), i.length * 2),
		new O(Ee, N(s.bark), n.length)
	], o = new me();
	function c(e, t, n, r, i, a, s, c, l) {
		o.position.set(n, r, i), o.rotation.set(0, t * 1.27, 0), o.scale.set(a, s, c), o.updateMatrix(), e.setMatrixAt(t, o.matrix), l && e.setColorAt(t, new ce(l));
	}
	r.forEach((e, t) => {
		for (let n = 0; n < 3; n++) {
			let r = .29 - n * .066;
			c(a[0], t * 3 + n, e.x, .33 + e.h * (.2 + n * .25), e.z, r, e.h * .56, r, e.color);
		}
	}), i.forEach((e, t) => {
		for (let n = 0; n < 2; n++) c(a[1], t * 2 + n, e.x + n * .12, e.h * (.65 + n * .18), e.z, .34 - n * .07, e.h * .36, .31, e.color);
	}), n.forEach((e, t) => c(a[2], t, e.x, .25, e.z, .045, .5, .045));
	for (let e of a) e.instanceMatrix.needsUpdate = !0, e.instanceColor && (e.instanceColor.needsUpdate = !0), t.add(e);
	return t;
}
function X(e, t) {
	let n = new w(e), r = [], i = [], a = Math.max(12, e.length * 12);
	for (let e = 0; e <= a; e++) {
		let o = n.getPoint(e / a), s = n.getTangent(e / a), c = new A(-s.z, 0, s.x).normalize().multiplyScalar(t / 2);
		if (r.push(o.x + c.x, 0, o.z + c.z, o.x - c.x, 0, o.z - c.z), e < a) {
			let t = e * 2;
			i.push(t, t + 2, t + 1, t + 1, t + 2, t + 3);
		}
	}
	let o = new oe();
	return o.setAttribute("position", new de(r, 3)), o.setIndex(i), o.computeVertexNormals(), o;
}
function Pe(e) {
	let t = new ve();
	for (let n = 0; n <= 24; n++) {
		let r = n / 24 * Math.PI * 2, i = .96 + .055 * Math.sin(r * 3 + e) + .035 * Math.cos(r * 5 - e), a = Math.cos(r) * i, o = Math.sin(r) * i * .83;
		n ? t.lineTo(a, o) : t.moveTo(a, o);
	}
	return t.closePath(), new ye(t);
}
function Fe(e, t, n, i, a, o) {
	let c = r[t], l = c.clearings.find((e) => e.id === n), u = c.clearings.find((e) => e.id === i), d = u.x - l.x, f = u.z - l.z, p = .06 * Math.sin(n + i), m = [
		new A(l.x, 0, l.z),
		new A((l.x + u.x) / 2 - f * p, 0, (l.z + u.z) / 2 + d * p),
		new A(u.x, 0, u.z)
	];
	if (V(e, B(`road:${t}:${n}:${i}`, () => X(m, .25)), z(s.clay), [
		0,
		.025,
		0
	]), V(e, B(`road-top:${t}:${n}:${i}`, () => X(m, .17)), z(s.path), [
		0,
		.028,
		0
	]), o) {
		let t = new w(m), n = o.getPoints(160), r;
		for (let e = 10; e <= 70; e++) {
			let i = e / 80, a = t.getPoint(i);
			if (Math.hypot(a.x - l.x, a.z - l.z) < 1.1 || Math.hypot(a.x - u.x, a.z - u.z) < 1.1) continue;
			let o = Math.min(...n.map((e) => e.distanceTo(a)));
			(!r || o < r.distance) && (r = {
				t: i,
				distance: o
			});
		}
		if (r && r.distance < .16) {
			let n = t.getPoint(r.t), i = t.getTangent(r.t), a = new D();
			a.position.set(n.x, .06, n.z), a.rotation.y = Math.atan2(i.x, i.z), e.add(a);
			let o = B("bridge-box", () => new C(1, 1, 1));
			for (let e = 0; e < 8; e++) V(a, o, N(e % 2 ? s.bark : s.clay), [
				0,
				.02,
				(e - 3.5) * .105
			], [
				.4,
				.055,
				.09
			]);
			for (let e of [-.21, .21]) {
				V(a, o, N(s.bark), [
					e,
					.21,
					0
				], [
					.035,
					.035,
					.83
				]);
				for (let t of [-.35, .35]) V(a, o, N(s.bark), [
					e,
					.11,
					t
				], [
					.045,
					.28,
					.045
				]);
			}
		}
	}
	if (a) for (let t = 0; t < 3; t++) V(e, U, N(s.stone), [
		(l.x + u.x) / 2 + (t - 1) * .15,
		.12,
		(l.z + u.z) / 2
	], [
		.12,
		.17,
		.15
	]);
}
function Ie({ view: n, selected: a, destination: c, targets: l }) {
	let u = new D(), f = o(n), p = r[n.map], m = t(f), h = d(f);
	u.add(new ae(s.cream, 1.35));
	let g = new ue(s.cream, 1.15);
	g.position.set(-5, 12, 8), u.add(g), V(u, H, z(s.grass), [
		0,
		-.035,
		0
	], [
		42,
		42,
		1
	], [
		-Math.PI / 2,
		0,
		0
	]);
	for (let e = 0; e < 34; e++) {
		let t = Y(e + 500) * 16 - 8, n = Y(e + 700) * 16 - 8;
		V(u, B("patch", () => new se(1, 24)), z(e % 2 ? s.moss : s.litter), [
			t,
			-.025 + e * 3e-4,
			n
		], [
			.65 + Y(e) * 1.3,
			.45 + Y(e + 1),
			1
		], [
			-Math.PI / 2,
			0,
			0
		]);
	}
	let _ = n.map === "autumn" ? ke.points : null;
	if (_) for (let [e, t, n] of [
		[
			.63,
			s.sand,
			.009
		],
		[
			.48,
			s.waterDeep,
			.012
		],
		[
			.36,
			s.river,
			.015
		]
	]) V(u, B(`river:${e}`, () => X(_, e)), z(t), [
		0,
		n,
		0
	]);
	else if (n.map === "lake") V(u, B("lake", () => new se(1, 40)), z(s.river), [
		.6,
		.014,
		.5
	], [
		1.8,
		2.1,
		1
	], [
		-Math.PI / 2,
		0,
		0
	]);
	else for (let [e, t] of p.rivers) {
		let r = m.find((t) => t.id === e), i = m.find((e) => e.id === t);
		V(u, B(`river:${n.map}:${e}:${t}`, () => X([new A(r.x, 0, r.z), new A(i.x, 0, i.z)], .42)), z(s.river), [
			0,
			.014,
			0
		]);
	}
	let v = _ ? new w(_) : void 0;
	for (let [t, r] of p.paths) Fe(u, n.map, t, r, n.table?.blocked.some(([n, i]) => e(t, r) === e(n, i)) ?? !1, v);
	u.add(Ne(n.map));
	for (let e of m) {
		let t = new D();
		t.position.set(e.x, .035, e.z), u.add(t);
		let r = B(`clearing:${e.id}`, () => Pe(e.id)), o = n.table?.scorched.includes(e.id);
		V(t, r, z(s.clay), [
			0,
			0,
			0
		], [
			1.07,
			1.07,
			1
		], [
			-Math.PI / 2,
			0,
			0
		]), V(t, r, z(o ? s.soil : s.sand), [
			0,
			.004,
			0
		], [
			1,
			1,
			1
		], [
			-Math.PI / 2,
			0,
			0
		]);
		for (let n = 0; n < 5; n++) {
			let r = (n * 1.25 + e.id) * 1.4;
			V(t, U, N(n % 2 ? s.stone : s.gold), [
				Math.cos(r) * .99,
				.045,
				Math.sin(r) * .81
			], [
				.04,
				.04,
				.06
			]);
		}
		if (a === e.id || c === e.id || l.includes(e.id)) {
			let n = c === e.id, r = a === e.id;
			V(t, B("selection-ring", () => new _e(.97, 1.07, 48)), z(n ? s.pineDark : r ? s.gold : s.cream), [
				0,
				.022,
				0
			], [
				1,
				.85,
				1
			], [
				-Math.PI / 2,
				0,
				0
			]), (r || n) && V(t, B("selection-inner", () => new _e(.91, .925, 48)), z(s.cream), [
				0,
				.024,
				0
			], [
				1,
				.85,
				1
			], [
				-Math.PI / 2,
				0,
				0
			]);
		}
		let d = n.pieces.filter((t) => t.clearing === e.id && i(t.kind));
		for (let r = 0; r < e.slots; r++) {
			let i = -(e.slots - 1) * .24 + r * .48;
			V(t, H, z(s.bark), [
				i,
				.012,
				-.28
			], [
				.38,
				.34,
				1
			], [
				-Math.PI / 2,
				0,
				0
			]), V(t, H, z(s.clearing), [
				i,
				.014,
				-.28
			], [
				.32,
				.28,
				1
			], [
				-Math.PI / 2,
				0,
				0
			]);
			let a = d[r];
			if (a) {
				let e = Te(a.kind, n.players.find((e) => e.rid === a.owner).faction);
				e.position.set(i, .02, -.28), e.scale.setScalar(.54), t.add(e);
			} else if (r === e.slots - 1 && (n.table ? n.table.ruins.some((t) => t.clearing === e.id && t.count) : e.ruin)) for (let e = 0; e < 3; e++) V(t, U, N(s.stone), [
				i + (e - 1) * .07,
				.12 + e * .03,
				-.28 + e * .04
			], [
				.11,
				.15 + e * .03,
				.1
			]);
		}
		let f = n.pieces.filter((t) => t.clearing === e.id && t.kind !== "warrior" && !i(t.kind));
		for (let [e, r] of f.entries()) {
			let i = Te(r.kind, n.players.find((e) => e.rid === r.owner).faction);
			i.position.set(-.67 + e * .3, .02, .05), i.scale.setScalar(r.kind === "keep" ? .43 : .48), t.add(i);
		}
		let p = n.players.map((t) => ({
			p: t,
			n: n.pieces.filter((n) => n.owner === t.rid && n.clearing === e.id && n.kind === "warrior").reduce((e, t) => e + t.count, 0)
		})).filter((e) => e.n);
		for (let [n, { p: r, n: i }] of p.entries()) {
			let a = new D();
			a.name = `army:${r.rid}:${e.id}`, t.add(a);
			for (let e = 0; e < Math.min(2, i); e++) {
				let t = Math.min(3, p.length), i = n % t, o = Math.floor(n / t), s = we(r.faction);
				s.position.set((i - (t - 1) / 2) * .53 + e * .17, .025, .29 - e * .14 + o * .33), s.rotation.y = -.12 - e * .17, s.scale.setScalar(e ? .6 : .8), a.add(s);
			}
		}
	}
	for (let e of n.table?.boards.filter((e) => e.character) ?? []) {
		let t = e.location < 0 ? h.find((t) => t.id === e.location) : m.find((t) => t.id === e.location);
		if (t) {
			let e = we("vagabond");
			e.position.set(t.x + .45, .05, t.z + .18), e.scale.setScalar(.72), u.add(e);
		}
	}
	return u;
}
function Le({ view: e, selected: t, destination: n, targets: r }) {
	let i = g(() => Ie({
		view: e,
		selected: t,
		destination: n,
		targets: r
	}), [
		e,
		t,
		n,
		r
	]);
	return p(() => () => {
		i.traverse((e) => {
			e instanceof O && e.dispose();
		});
	}, [i]), /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("primitive", { object: i }), e.pieces.filter((e) => e.kind === "warrior").map((e) => /* @__PURE__ */ b(Re, {
		name: `army:${e.owner}:${e.clearing}`,
		object: i
	}, e.uid))] });
}
function Re({ name: e, object: t }) {
	let { hidden: n } = ee(e), { invalidate: r } = ie();
	return h(() => {
		let i = t.getObjectByName(e);
		i && (i.visible = !n, r());
	}, [
		t,
		e,
		n,
		r
	]), null;
}
function Z(e, t, n, r, i) {
	e.left = -t / 2, e.right = t / 2, e.top = n / 2, e.bottom = -n / 2, e.zoom = Math.min(t / 13, n / 11.4) * r, e.position.set(i[0], 17, 12 + i[1]), e.lookAt(i[0], 0, i[1]), e.updateProjectionMatrix(), e.updateMatrixWorld();
}
function Q(e, t, n, r, i) {
	let a = new A(0, 0, 0).unproject(e), o = new A(2 * r / t, -2 * i / n, 0).unproject(e).sub(a), s = e.getWorldDirection(new A());
	return o.addScaledVector(s, -o.y / s.y), [o.x, o.z];
}
function $(e) {
	let n = new he();
	Z(n, 13, 11.4, 1, [0, 0]);
	let r = new A(0, .08, 0).project(n);
	return [...t({ map: e }), ...d({ map: e })].map((e) => {
		let t = new A(e.x, .08, e.z + .68).project(n), i = new A(e.x, .08, e.z).project(n), a = new A(e.x + 1.03, .08, e.z).project(n), o = new A(e.x, .08, e.z + .88).project(n);
		return {
			id: e.id,
			x: (t.x - r.x) * 13 / 2,
			y: (r.y - t.y) * 11.4 / 2,
			gx: (i.x - r.x) * 13 / 2,
			gy: (r.y - i.y) * 11.4 / 2,
			rx: Math.abs(a.x - i.x) * 13 / 2,
			ry: Math.abs(o.y - i.y) * 11.4 / 2
		};
	});
}
function ze({ poseRef: e, controlsRef: t, labelsRef: n, marksRef: r, points: i }) {
	let { camera: a, size: o, invalidate: s } = ie(), c = f(() => {
		let t = a, { zoom: s, pan: c } = e.current;
		Z(t, o.width, o.height, s, c);
		let l = new A(0, .08, 0).project(t), u = (l.x + 1) * o.width / 2, d = (1 - l.y) * o.height / 2;
		r.current && (r.current.setAttribute("transform", `translate(${u} ${d}) scale(${t.zoom})`), r.current.style.visibility = "visible");
		for (let e of i) {
			let r = n.current.get(e.id);
			r && (r.style.transform = `translate3d(${u + e.x * t.zoom}px,${d + e.y * t.zoom}px,0)`, r.style.visibility = "visible");
		}
	}, [
		a,
		o.width,
		o.height,
		e,
		n,
		r,
		i
	]);
	return m(t, () => ({
		panBy(t, n) {
			if (!o.width || !o.height) return;
			let r = a, i = e.current;
			Z(r, o.width, o.height, i.zoom, i.pan);
			let [c, l] = Q(r, o.width, o.height, t, n);
			i.pan = [Math.max(-5, Math.min(5, i.pan[0] - c)), Math.max(-5, Math.min(5, i.pan[1] - l))], s();
		},
		zoomBy(t) {
			e.current.zoom = Math.max(.85, Math.min(2.6, e.current.zoom * t)), s();
		},
		reset() {
			e.current.zoom = 1, e.current.pan = [0, 0], s();
		},
		refresh: s
	}), [
		a,
		o.width,
		o.height,
		e,
		s
	]), h(() => {
		c(), s();
	}, [c, s]), S(c), null;
}
function Be() {
	if (typeof document > "u") return !1;
	try {
		let e = document.createElement("canvas").getContext("webgl2");
		return e ? (e.getExtension("WEBGL_lose_context")?.loseContext(), !0) : !1;
	} catch {
		return !1;
	}
}
function Ve(e) {
	let [t] = v(Be), [n, r] = v(!1), i = _({
		zoom: 1,
		pan: [0, 0]
	}), o = _(null), s = _(/* @__PURE__ */ new Map()), d = _(null), f = _(/* @__PURE__ */ new Map()), p = g(() => $(e.view.map), [e.view.map]);
	h(() => {
		o.current?.refresh();
	});
	let m = (e) => {
		e.target.closest("button") || f.current.size >= 2 || e.pointerType === "mouse" && e.button !== 0 || (e.currentTarget.setPointerCapture(e.pointerId), f.current.set(e.pointerId, [e.clientX, e.clientY]));
	}, ee = (e) => {
		let t = f.current.get(e.pointerId);
		if (!t) return;
		let n = [...f.current.entries()].find(([t]) => t !== e.pointerId)?.[1];
		if (f.current.set(e.pointerId, [e.clientX, e.clientY]), n) {
			let r = Math.hypot(t[0] - n[0], t[1] - n[1]), i = Math.hypot(e.clientX - n[0], e.clientY - n[1]);
			r && i && o.current?.zoomBy(i / r);
		} else o.current?.panBy(e.clientX - t[0], e.clientY - t[1]);
	}, S = (e) => {
		f.current.delete(e.pointerId);
	};
	return t ? /* @__PURE__ */ x("div", {
		className: "root-board-3d",
		role: "group",
		"aria-label": e.t("board"),
		onPointerDown: m,
		onPointerMove: ee,
		onPointerUp: S,
		onPointerCancel: S,
		onLostPointerCapture: S,
		onWheel: (e) => {
			e.stopPropagation(), e.deltaY && o.current?.zoomBy(e.deltaY > 0 ? .9 : 1.1);
		},
		children: [/* @__PURE__ */ x(Se, {
			orthographic: !0,
			camera: {
				position: [
					0,
					17,
					12
				],
				near: .1,
				far: 100
			},
			dpr: [1, 2],
			frameloop: "demand",
			gl: {
				antialias: !0,
				alpha: !0
			},
			recoveryFallback: /* @__PURE__ */ b(l, { ...e }),
			onRecoveryChange: r,
			children: [/* @__PURE__ */ b(ze, {
				poseRef: i,
				controlsRef: o,
				labelsRef: s,
				marksRef: d,
				points: p
			}), /* @__PURE__ */ b(Le, { ...e })]
		}), !n && /* @__PURE__ */ x(y, { children: [
			/* @__PURE__ */ b(a, {
				...e,
				projectionRef: d,
				points: p.map((e) => ({
					id: e.id,
					x: e.gx,
					y: e.gy,
					rx: e.rx,
					ry: e.ry
				}))
			}),
			/* @__PURE__ */ b("div", {
				className: "root-board-labels",
				children: p.map((t) => /* @__PURE__ */ b("div", {
					ref: (e) => {
						e ? s.current.set(t.id, e) : s.current.delete(t.id);
					},
					className: "root-clearing-projection",
					style: {
						left: 0,
						top: 0,
						visibility: "hidden"
					},
					children: t.id > 0 ? /* @__PURE__ */ b(u, {
						...e,
						id: t.id
					}) : /* @__PURE__ */ b(c, {
						...e,
						id: t.id
					})
				}, t.id))
			}),
			/* @__PURE__ */ x("div", {
				className: "root-camera-controls",
				children: [
					/* @__PURE__ */ b("button", {
						onClick: () => o.current?.zoomBy(1.2),
						"aria-label": e.t("zoomIn"),
						children: /* @__PURE__ */ b(ne, { size: 19 })
					}),
					/* @__PURE__ */ b("button", {
						onClick: () => o.current?.zoomBy(1 / 1.2),
						"aria-label": e.t("zoomOut"),
						children: /* @__PURE__ */ b(re, { size: 19 })
					}),
					/* @__PURE__ */ b("button", {
						onClick: () => o.current?.reset(),
						"aria-label": e.t("recenter"),
						children: /* @__PURE__ */ b(te, { size: 19 })
					})
				]
			})
		] })]
	}) : /* @__PURE__ */ b(l, { ...e });
}
//#endregion
export { $ as boardProjection, Ie as createWoodlandScene, Ve as default, Z as fitCamera, Q as groundPanDelta };
