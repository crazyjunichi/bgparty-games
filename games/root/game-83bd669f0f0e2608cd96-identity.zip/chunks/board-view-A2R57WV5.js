import { useId as e } from "react";
import { useFxAnchor as t } from "@bgparty/sdk/fx/anchors";
import { Fragment as n, jsx as r, jsxs as i } from "react/jsx-runtime";
import { DeltaNumber as a } from "@bgparty/sdk/fx/delta-number";
//#region src/games/root/data.ts
var o = [
	"marquise",
	"eyrie",
	"alliance",
	"vagabond",
	"cult",
	"riverfolk",
	"duchy",
	"corvid"
], s = {
	marquise: 25,
	eyrie: 20,
	alliance: 10,
	vagabond: 0,
	cult: 25,
	riverfolk: 15,
	duchy: 20,
	corvid: 15
}, c = [
	"boot",
	"sack",
	"crossbow",
	"hammer",
	"sword",
	"tea",
	"coin",
	"torch"
], l = {
	boot: 2,
	sack: 2,
	crossbow: 1,
	hammer: 1,
	sword: 2,
	tea: 2,
	coin: 2,
	torch: 0
}, u = [
	"thief",
	"tinker",
	"ranger",
	"vagrant",
	"arbiter",
	"scoundrel",
	"adventurer",
	"harrier",
	"ronin"
], d = {
	thief: [
		"boot",
		"torch",
		"tea",
		"sword"
	],
	tinker: [
		"boot",
		"torch",
		"sack",
		"hammer"
	],
	ranger: [
		"boot",
		"torch",
		"crossbow",
		"sword"
	],
	vagrant: [
		"coin",
		"torch",
		"boot"
	],
	arbiter: [
		"boot",
		"torch",
		"sword",
		"sword"
	],
	scoundrel: [
		"boot",
		"boot",
		"torch",
		"crossbow"
	],
	adventurer: [
		"boot",
		"torch",
		"hammer"
	],
	harrier: [
		"coin",
		"torch",
		"sword",
		"crossbow"
	],
	ronin: [
		"boot",
		"boot",
		"torch",
		"sword"
	]
}, f = [
	"builder",
	"charismatic",
	"commander",
	"despot"
], p = [
	"recruit",
	"move",
	"battle",
	"build"
], m = {
	builder: ["recruit", "move"],
	charismatic: ["recruit", "battle"],
	commander: ["move", "battle"],
	despot: ["move", "build"]
}, h = [
	"foremole",
	"captain",
	"marshal",
	"brigadier",
	"banker",
	"mayor",
	"duchess",
	"baron",
	"earl"
], g = {
	foremole: 2,
	captain: 2,
	marshal: 2,
	brigadier: 3,
	banker: 3,
	mayor: 3,
	duchess: 4,
	baron: 4,
	earl: 4
}, _ = [
	0,
	1,
	2,
	3,
	3,
	4
], v = {
	sawmill: [
		0,
		1,
		2,
		3,
		4,
		5
	],
	workshop: [
		0,
		2,
		2,
		3,
		4,
		5
	],
	recruiter: [
		0,
		1,
		2,
		3,
		3,
		4
	]
}, y = [
	1,
	1,
	1,
	2,
	2,
	2,
	3,
	3,
	3,
	3
], b = [
	0,
	1,
	1,
	1,
	2,
	2,
	3,
	4,
	4,
	4
], x = [
	0,
	0,
	1,
	2,
	3,
	4,
	4,
	5
], S = [
	0,
	0,
	2,
	2,
	3,
	4
], C = (e, t, n, r, i) => ({
	id: e,
	suit: t,
	kind: "item",
	item: n,
	cost: r,
	vp: i
}), w = (e, t, n) => ({
	id: e,
	suit: t,
	kind: "persistent",
	effect: e,
	cost: n
}), ee = [
	...[
		"bird",
		"bird",
		"fox",
		"rabbit",
		"mouse"
	].map((e) => ({
		id: "ambush",
		suit: e,
		kind: "ambush",
		cost: []
	})),
	...[
		"bird",
		"fox",
		"rabbit",
		"mouse"
	].map((e) => ({
		id: "dominance",
		suit: e,
		kind: "dominance",
		cost: []
	})),
	C("birdyBindle", "bird", "sack", ["mouse"], 1),
	C("woodlandRunners", "bird", "boot", ["rabbit"], 1),
	C("armsTrader", "bird", "sword", ["fox", "fox"], 2),
	C("crossbow", "bird", "crossbow", ["fox"], 1),
	C("knapsack", "fox", "sack", ["mouse"], 1),
	C("rootTea", "fox", "tea", ["mouse"], 2),
	C("travelGear", "fox", "boot", ["rabbit"], 1),
	C("protectionRacket", "fox", "coin", ["rabbit", "rabbit"], 3),
	C("foxfolkSteel", "fox", "sword", ["fox", "fox"], 2),
	C("anvil", "fox", "hammer", ["fox"], 2),
	C("smugglersTrail", "rabbit", "sack", ["mouse"], 1),
	C("rootTea", "rabbit", "tea", ["mouse"], 2),
	C("visitFriends", "rabbit", "boot", ["rabbit"], 1),
	C("bakeSale", "rabbit", "coin", ["rabbit", "rabbit"], 3),
	C("mouseSack", "mouse", "sack", ["mouse"], 1),
	C("rootTea", "mouse", "tea", ["mouse"], 2),
	C("travelGear", "mouse", "boot", ["rabbit"], 1),
	C("investments", "mouse", "coin", ["rabbit", "rabbit"], 3),
	C("sword", "mouse", "sword", ["fox", "fox"], 2),
	C("crossbow", "mouse", "crossbow", ["fox"], 1),
	...[0, 1].flatMap(() => [
		w("armorers", "bird", ["fox"]),
		w("sappers", "bird", ["mouse"]),
		w("brutalTactics", "bird", ["fox", "fox"]),
		w("standAndDeliver", "fox", [
			"mouse",
			"mouse",
			"mouse"
		]),
		w("commandWarren", "rabbit", ["rabbit", "rabbit"]),
		w("betterBurrowBank", "rabbit", ["rabbit", "rabbit"]),
		w("cobbler", "rabbit", ["rabbit", "rabbit"]),
		w("scoutingParty", "mouse", ["mouse", "mouse"]),
		w("codebreakers", "mouse", ["mouse"])
	]),
	w("royalClaim", "bird", [
		"any",
		"any",
		"any",
		"any"
	]),
	...[
		0,
		1,
		2
	].map(() => w("taxCollector", "fox", [
		"fox",
		"rabbit",
		"mouse"
	])),
	...[
		"fox",
		"rabbit",
		"mouse"
	].map((e) => ({
		id: "favor",
		suit: e,
		kind: "item",
		cost: [
			e,
			e,
			e
		],
		favor: e
	}))
], T = (e) => ee.find((t) => t.id === e.id && t.suit === e.suit), te = () => ee.map((e, t) => ({
	uid: `deck:${t}`,
	id: e.id,
	suit: e.suit,
	kind: e.kind
})), ne = [
	{
		id: "fundraising",
		suit: "fox",
		items: ["tea", "coin"]
	},
	{
		id: "logistics",
		suit: "fox",
		items: ["boot", "sack"]
	},
	{
		id: "repairShed",
		suit: "fox",
		items: ["torch", "hammer"]
	},
	{
		id: "speech",
		suit: "fox",
		items: ["tea", "torch"]
	},
	{
		id: "errand",
		suit: "fox",
		items: ["tea", "boot"]
	},
	{
		id: "guardDuty",
		suit: "rabbit",
		items: ["torch", "sword"]
	},
	{
		id: "expelBandits",
		suit: "rabbit",
		items: ["sword", "sword"]
	},
	{
		id: "fendBear",
		suit: "rabbit",
		items: ["torch", "crossbow"]
	},
	{
		id: "speech",
		suit: "rabbit",
		items: ["torch", "tea"]
	},
	{
		id: "errand",
		suit: "rabbit",
		items: ["boot", "tea"]
	},
	{
		id: "fendBear",
		suit: "mouse",
		items: ["torch", "crossbow"]
	},
	{
		id: "guardDuty",
		suit: "mouse",
		items: ["torch", "sword"]
	},
	{
		id: "logistics",
		suit: "mouse",
		items: ["boot", "sack"]
	},
	{
		id: "escort",
		suit: "mouse",
		items: ["boot", "boot"]
	},
	{
		id: "expelBandits",
		suit: "mouse",
		items: ["sword", "sword"]
	}
], re = [
	"fox",
	"rabbit",
	"mouse"
], E = [
	{
		id: 1,
		suit: "fox",
		slots: 1,
		ruin: !1,
		corner: !0,
		x: -4.8,
		z: -4.5
	},
	{
		id: 2,
		suit: "mouse",
		slots: 2,
		ruin: !1,
		corner: !0,
		x: 4.7,
		z: -3.2
	},
	{
		id: 3,
		suit: "rabbit",
		slots: 1,
		ruin: !1,
		corner: !0,
		x: 4.4,
		z: 4.5
	},
	{
		id: 4,
		suit: "rabbit",
		slots: 1,
		ruin: !1,
		corner: !0,
		x: -4.6,
		z: 4.1
	},
	{
		id: 5,
		suit: "rabbit",
		slots: 2,
		ruin: !1,
		corner: !1,
		x: 1,
		z: -4.8
	},
	{
		id: 6,
		suit: "fox",
		slots: 2,
		ruin: !1,
		corner: !1,
		x: 5,
		z: .2
	},
	{
		id: 7,
		suit: "mouse",
		slots: 2,
		ruin: !0,
		corner: !1,
		x: 1.1,
		z: 3
	},
	{
		id: 8,
		suit: "fox",
		slots: 2,
		ruin: !0,
		corner: !1,
		x: -1.6,
		z: 5
	},
	{
		id: 9,
		suit: "mouse",
		slots: 2,
		ruin: !1,
		corner: !1,
		x: -4.8,
		z: -.7
	},
	{
		id: 10,
		suit: "rabbit",
		slots: 2,
		ruin: !1,
		corner: !1,
		x: -.9,
		z: -2.5
	},
	{
		id: 11,
		suit: "mouse",
		slots: 3,
		ruin: !0,
		corner: !1,
		x: 2,
		z: -.1
	},
	{
		id: 12,
		suit: "fox",
		slots: 2,
		ruin: !0,
		corner: !1,
		x: -1.9,
		z: .8
	}
], ie = [
	[1, 5],
	[1, 10],
	[1, 9],
	[5, 2],
	[2, 10],
	[2, 6],
	[10, 12],
	[9, 12],
	[9, 4],
	[12, 4],
	[12, 7],
	[12, 11],
	[11, 6],
	[11, 3],
	[6, 3],
	[4, 8],
	[8, 7],
	[7, 3]
], ae = (e) => E.find((t) => t.id === e), D = (e, t, n, r) => e.map((e, i) => ({
	id: i + 1,
	slots: e,
	ruin: t.includes(i + 1),
	corner: n.includes(i + 1),
	suit: [
		"fox",
		"rabbit",
		"mouse"
	][i % 3],
	x: (r[i][0] - 1200) / 190,
	z: (r[i][1] - 1100) / 165
})), O = {
	autumn: {
		clearings: E,
		paths: ie,
		rivers: [
			[5, 10],
			[10, 11],
			[11, 7],
			[7, 4]
		],
		forests: [
			[
				1,
				5,
				2,
				10
			],
			[
				9,
				1,
				10,
				12
			],
			[
				12,
				10,
				2,
				6,
				11
			],
			[
				9,
				12,
				4
			],
			[
				12,
				11,
				3,
				7
			],
			[
				11,
				6,
				3
			],
			[
				4,
				12,
				7,
				8
			]
		],
		diagonals: [[1, 3], [2, 4]],
		blocked: [],
		coastal: [],
		ferry: null,
		tower: null
	},
	winter: {
		clearings: D([
			1,
			2,
			2,
			1,
			1,
			3,
			3,
			1,
			2,
			2,
			2,
			2
		], [
			6,
			7,
			10,
			11
		], [
			1,
			4,
			9,
			12
		], [
			[322, 292],
			[908, 388],
			[1432, 530],
			[2104, 518],
			[334, 943],
			[892, 1129],
			[1527, 1037],
			[2203, 1294],
			[337, 1792],
			[889, 1896],
			[1408, 1607],
			[2028, 1892]
		]),
		paths: [
			[1, 2],
			[1, 6],
			[1, 5],
			[2, 3],
			[3, 4],
			[4, 8],
			[4, 7],
			[5, 9],
			[6, 10],
			[6, 9],
			[7, 12],
			[7, 11],
			[8, 12],
			[9, 10],
			[10, 11],
			[11, 12]
		],
		rivers: [
			[5, 6],
			[6, 7],
			[7, 8]
		],
		forests: [
			[
				1,
				5,
				6
			],
			[
				1,
				2,
				3,
				4,
				7,
				6
			],
			[
				4,
				7,
				8
			],
			[
				5,
				6,
				9
			],
			[
				6,
				9,
				10
			],
			[
				6,
				7,
				11,
				10
			],
			[
				7,
				11,
				12
			],
			[
				7,
				8,
				12
			]
		],
		diagonals: [[1, 12], [4, 9]],
		blocked: [],
		coastal: [],
		ferry: null,
		tower: null
	},
	lake: {
		clearings: D([
			1,
			1,
			2,
			1,
			1,
			3,
			3,
			3,
			1,
			3,
			1,
			2
		], [
			6,
			7,
			8,
			10
		], [
			1,
			4,
			9,
			12
		], [
			[360, 418],
			[1080, 272],
			[1658, 502],
			[2164, 728],
			[253, 1058],
			[769, 798],
			[1569, 1070],
			[2127, 1256],
			[300, 1773],
			[821, 1467],
			[1080, 1940],
			[2043, 1870]
		]),
		paths: [
			[1, 2],
			[1, 6],
			[1, 5],
			[2, 6],
			[2, 7],
			[2, 3],
			[3, 7],
			[3, 4],
			[4, 8],
			[5, 6],
			[5, 9],
			[7, 8],
			[8, 12],
			[9, 10],
			[9, 11],
			[10, 11],
			[11, 12]
		],
		rivers: [
			[6, 7],
			[6, 10],
			[6, 12],
			[7, 10],
			[7, 12],
			[10, 12]
		],
		forests: [
			[
				1,
				6,
				5
			],
			[
				1,
				6,
				2
			],
			[
				6,
				2,
				7
			],
			[
				3,
				2,
				7
			],
			[
				3,
				4,
				8,
				7
			],
			[
				10,
				9,
				5,
				6
			],
			[
				9,
				10,
				11
			],
			[
				10,
				11,
				12
			],
			[
				7,
				8,
				12
			]
		],
		diagonals: [[1, 12], [4, 9]],
		blocked: [],
		coastal: [
			6,
			7,
			10,
			12
		],
		ferry: 12,
		tower: null
	},
	mountain: {
		clearings: D([
			2,
			3,
			1,
			2,
			1,
			2,
			3,
			1,
			2,
			3,
			1,
			2
		], [
			2,
			6,
			7,
			10
		], [
			1,
			4,
			9,
			12
		], [
			[273, 378],
			[713, 761],
			[1287, 356],
			[2001, 495],
			[215, 1273],
			[1188, 886],
			[1527, 1360],
			[2195, 1106],
			[357, 1838],
			[820, 1486],
			[1388, 1900],
			[2078, 1739]
		]),
		paths: [
			[1, 2],
			[1, 5],
			[2, 3],
			[2, 5],
			[2, 6],
			[2, 10],
			[3, 4],
			[3, 6],
			[3, 7],
			[4, 7],
			[4, 8],
			[5, 9],
			[6, 7],
			[6, 10],
			[7, 8],
			[7, 10],
			[7, 12],
			[8, 12],
			[9, 10],
			[10, 11],
			[11, 12]
		],
		rivers: [[4, 6], [6, 9]],
		forests: [
			[
				1,
				2,
				5
			],
			[
				2,
				3,
				6
			],
			[
				2,
				6,
				10
			],
			[
				6,
				7,
				10
			],
			[
				3,
				6,
				7
			],
			[
				3,
				4,
				7
			],
			[
				4,
				7,
				8
			],
			[
				7,
				8,
				12
			],
			[
				2,
				5,
				9,
				10
			],
			[
				7,
				10,
				11,
				12
			]
		],
		diagonals: [[1, 12], [9, 4]],
		blocked: [
			[5, 2],
			[2, 3],
			[3, 4],
			[10, 7],
			[7, 8],
			[11, 12]
		],
		coastal: [],
		ferry: null,
		tower: 6
	}
}, k = (e) => O[e.map].clearings.map((t, n) => ({
	...t,
	suit: e.game?.suits[n] ?? t.suit
})), A = (e, t) => k(e).find((e) => e.id === t), j = (e, t) => `${Math.min(e, t)}:${Math.max(e, t)}`, M = (e) => ({
	map: e.map,
	...e.table ? { game: {
		suits: e.table.suits,
		blocked: e.table.blocked,
		scorched: e.table.scorched
	} } : {}
}), N = (e) => O[e.map].forests.map((t, n) => ({
	id: -n - 1,
	x: t.reduce((t, n) => t + A(e, n).x, 0) / t.length,
	z: t.reduce((t, n) => t + A(e, n).z, 0) / t.length
})), oe = (e, t, n = !1) => O[e.map].paths.filter(([t, r]) => n || !(e.game?.blocked ?? O[e.map].blocked).some(([e, n]) => j(t, r) === j(e, n))).flatMap(([e, n]) => e === t ? [n] : n === t ? [e] : []), se = (e, t) => O[e.map].rivers.flatMap(([e, n]) => e === t ? [n] : n === t ? [e] : []);
function ce(e, t, n) {
	let r = e.game?.riverboats?.includes(t) || e.players?.some((e) => e.rid === t && e.faction === "riverfolk") ? se(e, n) : [];
	return [.../* @__PURE__ */ new Set([...oe(e, n), ...r])];
}
var le = (e, t, n) => n > 0 && (t === "bird" || t === A(e, n).suit), ue = (e) => O[e.map].forests.map((e, t) => -t - 1);
function de(e, t) {
	let n = O[e.map];
	if (t > 0) return n.forests.flatMap((e, n) => e.includes(t) ? [-n - 1] : []);
	let r = n.forests[-t - 1] ?? [];
	return [...r, ...n.forests.flatMap((i, a) => {
		if (-a - 1 === t) return [];
		let o = r.filter((e) => i.includes(e));
		return n.paths.some(([e, t]) => o.includes(e) && o.includes(t)) || e.map === "lake" && o.some((e) => n.coastal.includes(e)) ? [-a - 1] : [];
	})];
}
//#endregion
//#region src/games/root/model.ts
var P = (e) => [
	"sawmill",
	"workshop",
	"recruiter",
	"roost",
	"base",
	"garden",
	"citadel",
	"market"
].includes(e), fe = (e, t) => e.players.find((e) => e.rid === t), pe = (e, t, n) => e.pieces.filter((e) => e.owner === t && e.clearing === n && e.kind === "warrior").reduce((e, t) => e + t.count, 0), me = (e, t, n) => e.pieces.filter((e) => e.owner === t && e.clearing === n), F = {
	ink: "#4b493b",
	paper: "#f1e7c9",
	cream: "#fff6de",
	ochre: "#d3ad61",
	sage: "#9da97b",
	moss: "#697f66",
	dark: "#435c50",
	bark: "#937451",
	clay: "#b88658",
	rust: "#be7043",
	blue: "#7c9ca0",
	rose: "#bb7e66"
};
function I({ x: e, y: t, species: a = "mouse", coat: o = F.blue, scale: s = 1, facing: c = 1, pose: l = "hold", children: u }) {
	let d = a === "fox" ? F.rust : a === "bird" ? F.blue : F.cream;
	return /* @__PURE__ */ i("g", {
		transform: `translate(${e} ${t}) scale(${s * c} ${s})`,
		children: [
			a === "mouse" && /* @__PURE__ */ r("path", {
				d: "M-10 54q-31 8-25-9 3-6 8-2",
				fill: "none",
				stroke: F.rose,
				strokeWidth: "3"
			}),
			a === "fox" && /* @__PURE__ */ i(n, { children: [/* @__PURE__ */ r("path", {
				d: "M-12 49q-34 19-36-5-3-19 15-19-7 14 16 9",
				fill: F.rust
			}), /* @__PURE__ */ r("path", {
				d: "M-43 29q-10 6-4 18l12-2-3-6Z",
				fill: F.cream
			})] }),
			a === "bird" && /* @__PURE__ */ r("path", {
				d: "m-9 44-22 8 8-19 13-2",
				fill: F.blue
			}),
			/* @__PURE__ */ r("path", {
				d: l === "walk" ? "m-9 43-17 18 5 5 20-14m4-8 18 15-3 7-20-14" : "m-11 44-3 20 10 1 6-19m6-1 8 19 9-1-6-20",
				fill: F.bark
			}),
			/* @__PURE__ */ r("path", {
				d: l === "walk" ? "m-29 63 11 3m36-3 8 4" : "m-16 64 14 1m15 0 13-1",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ r("path", {
				d: "m-11 9 21-2 13 38q-17 9-38 1Z",
				fill: o
			}),
			/* @__PURE__ */ r("path", {
				d: "m-8 11 7 10 10-12m-10 12 2 26m-13-6 28-1",
				fill: "none",
				stroke: F.paper
			}),
			/* @__PURE__ */ r("path", {
				d: l === "work" ? "m-12 16-17 12 4 7 19-10m20-9 14-20 7 5-14 24" : l === "speak" ? "m-12 16-13-14-7 4 15 22m30-13 18-11 5 7-19 16" : l === "walk" ? "m-12 16-16 16 5 5 17-13m19-10 17 13 5-6-18-16" : "m-12 16-17 16 5 6 19-13m18-10 16 17 6-5-18-19",
				fill: d
			}),
			a === "rabbit" && /* @__PURE__ */ i(n, { children: [/* @__PURE__ */ r("path", {
				d: "M-11-14q-13-33-5-36 9-3 13 34m7 1q-2-39 7-37 10 2 1 39",
				fill: d
			}), /* @__PURE__ */ r("path", {
				d: "m-14-42 7 23m15-25-1 25",
				fill: "none",
				stroke: F.rose
			})] }),
			a === "mouse" && /* @__PURE__ */ i(n, { children: [
				/* @__PURE__ */ r("circle", {
					cx: "-12",
					cy: "-19",
					r: "11",
					fill: d
				}),
				/* @__PURE__ */ r("circle", {
					cx: "10",
					cy: "-20",
					r: "10",
					fill: d
				}),
				/* @__PURE__ */ r("path", {
					d: "M-17-18q-2-9 6-6m17 1q7-7 9 2",
					fill: "none",
					stroke: F.rose,
					strokeWidth: "2"
				})
			] }),
			/* @__PURE__ */ r("path", {
				d: a === "fox" ? "M-15-4-17-30-4-20 8-23 19-35 18-11 27-3 8 11-9 7Z" : a === "bird" ? "M-13-5q-6-22 10-25l11 5 8 12 15 4-17 7q-3 17-19 11Z" : "M-16-9q2-18 18-17 15 2 15 17l9 6-15 13q-23 6-27-19Z",
				fill: d
			}),
			a === "fox" && /* @__PURE__ */ r("path", {
				d: "m-11-9 12 5 7 10 8-15 7 6L8 11-4 7Z",
				fill: F.cream
			}),
			a === "bird" && /* @__PURE__ */ r("path", {
				d: "m13-13 16 4-17 7",
				fill: F.ochre
			}),
			/* @__PURE__ */ r("path", {
				d: "m-5-12 2 1m13-4 2-1M15-3l4-1m-12 7 4 1",
				fill: "none",
				strokeWidth: "2"
			}),
			a !== "bird" && /* @__PURE__ */ r("path", {
				d: "m-11-2-12 1m13 4-12 4",
				fill: "none",
				strokeWidth: ".8"
			}),
			/* @__PURE__ */ r("path", {
				d: "m-12 30 5 8m-7-3 5 8m23-14 3 6m-5 5 3 4m-12 8-3 9m17-9 3 8M-8-16l4-2m-5 6 3-2m14-5 3-2",
				fill: "none",
				strokeWidth: ".7"
			}),
			u
		]
	});
}
function L({ river: e = !1, night: t = !1 }) {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r("path", {
			d: "M0 0h240v188H0Z",
			fill: t ? F.dark : F.paper,
			stroke: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M0 54q35-34 65-6t58-11 59 6 58-15v145H0Z",
			fill: t ? F.moss : "#bcc29b",
			stroke: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M9-8 4 145m24-150 15 131M217-8l-13 148m29-145 9 127",
			fill: "none",
			stroke: F.bark,
			strokeWidth: "9"
		}),
		/* @__PURE__ */ r("path", {
			d: "M13 13 3 35m28 23L18 44m193-6 14-15m-15 48 16-15M4 92l13 5",
			fill: "none",
			stroke: F.ink
		}),
		/* @__PURE__ */ r("path", {
			d: "M0 145q41-21 80 0t81-8 79-3v54H0Z",
			fill: e ? F.blue : "#d0bf95",
			stroke: "none"
		}),
		e ? /* @__PURE__ */ r("path", {
			d: "M0 163q56-18 111 0t129-4M24 180h27m70-2h45m37-33h22m-93 4h17",
			fill: "none",
			stroke: F.cream
		}) : /* @__PURE__ */ r("path", {
			d: "m42 188 52-38 21 1-36 37M13 163l8-4m6 16 7-3m160 7 9-2m-23-15 8-3",
			fill: F.paper,
			stroke: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "m4 133 7-17 8 17m-4-7 10-13 7 18m173-7 8-14 8 16m-5-4 11-16 9 20",
			fill: F.moss
		}),
		/* @__PURE__ */ r("path", {
			d: "m8 137 3-11m14 11-1-12m186 12 3-13m12 11 1-15",
			fill: "none",
			stroke: F.paper,
			strokeWidth: ".8"
		}),
		t && /* @__PURE__ */ r("circle", {
			cx: "156",
			cy: "27",
			r: "14",
			fill: F.ochre,
			stroke: "none"
		})
	] });
}
function R({ stone: e = !1 }) {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r("path", {
			d: "M0 0h240v188H0Z",
			fill: e ? "#b8b69a" : F.paper,
			stroke: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M0 140 240 130v58H0Z",
			fill: F.clay
		}),
		/* @__PURE__ */ r("path", {
			d: "M10 0v139m52-139v137m116-137v131m51-131v129M0 31h240M0 72h240M0 111h240",
			stroke: e ? "#97977e" : "#c9bc97",
			fill: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M0 0h240v11H0Zm0 0h11v149H0Zm229 0h11v134h-11Z",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "m8 159 66-21m-32 50 60-52m47 52-20-54m89 54-58-56M0 175l240-19",
			fill: "none",
			stroke: F.bark,
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ r("path", {
			d: "M145 88V40q0-24 27-24t27 24v48Z",
			fill: F.blue
		}),
		/* @__PURE__ */ r("path", {
			d: "M172 18v70m-26-37h52",
			fill: "none",
			stroke: F.bark,
			strokeWidth: "3"
		}),
		/* @__PURE__ */ r("path", {
			d: "M155 35q7-10 12-8m12 3 9 8M145 90h56",
			fill: "none",
			stroke: F.cream
		}),
		/* @__PURE__ */ r("path", {
			d: "m16 17 3 13m-3 4 2 12m213 62 3 8m-3 5 2 5",
			fill: "none",
			strokeWidth: ".75"
		})
	] });
}
function z({ x: e = 66, y: t = 133, width: n = 116 }) {
	return /* @__PURE__ */ i("g", {
		transform: `translate(${e} ${t})`,
		children: [
			/* @__PURE__ */ r("path", {
				d: `m0 0 17-14 ${n} 1-17 18Z`,
				fill: F.clay
			}),
			/* @__PURE__ */ r("path", {
				d: `m0 0 ${n} 5v8L0 8Zm7 9-4 40m${n - 19}-39 7 39`,
				fill: F.bark
			}),
			/* @__PURE__ */ r("path", {
				d: `m10 1 35 1m15 1 32 1M11 14l-3 29m${n - 11}-28 4 27`,
				fill: "none",
				strokeWidth: ".7"
			})
		]
	});
}
function B({ x: e, y: t, scale: n = 1 }) {
	return /* @__PURE__ */ i("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ r("path", {
				d: "m0 0 30 3 9-7-30-3Z",
				fill: F.ochre
			}),
			/* @__PURE__ */ r("path", {
				d: "m0 0 30 3v29L0 29Zm30 3 9-7v28l-9 8",
				fill: F.clay
			}),
			/* @__PURE__ */ r("path", {
				d: "m4 4 22 24M4 25 26 7M3 10l24 3m-24 7 24 3m6-16 3-3m-3 8 3-3m-3 8 3-3",
				fill: "none",
				strokeWidth: ".8"
			})
		]
	});
}
function V({ x: e, y: t, n = 3 }) {
	return /* @__PURE__ */ r("g", {
		transform: `translate(${e} ${t})`,
		children: Array.from({ length: n }, (e, t) => /* @__PURE__ */ i("g", {
			transform: `translate(${t % 3 * 12} ${-Math.floor(t / 3) * 4 + t % 2 * 2})`,
			children: [
				/* @__PURE__ */ r("path", {
					d: "M-6-2v4q6 5 12 0v-4",
					fill: F.ochre
				}),
				/* @__PURE__ */ r("ellipse", {
					cy: "-2",
					rx: "6",
					ry: "3",
					fill: F.ochre
				}),
				/* @__PURE__ */ r("path", {
					d: "m-2-3 4 2m-2-3v4",
					fill: "none",
					strokeWidth: ".7"
				})
			]
		}, t))
	});
}
function H({ x: e, y: t, scale: n = 1 }) {
	return /* @__PURE__ */ i("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [/* @__PURE__ */ r("path", {
			d: "m-10-19 8 3 10-4-3 13q23 29 3 35-31 7-29-12 1-12 14-23Z",
			fill: F.ochre
		}), /* @__PURE__ */ r("path", {
			d: "m-7-6 13 1m-14 3 15 1m-12 5q-9 13-4 19M7 4q10 14 4 20m-9-30 6 12m-6-12-5 11m-9 15 5 2m11-1 4-2",
			fill: "none",
			strokeWidth: "1"
		})]
	});
}
function U({ x: e, y: t, turn: n = 0, scale: a = 1 }) {
	return /* @__PURE__ */ i("g", {
		transform: `translate(${e} ${t}) rotate(${n}) scale(${a})`,
		children: [
			/* @__PURE__ */ r("path", {
				d: "m-4 8 1-47 4-9 4 9-2 47Z",
				fill: "#c2c5b2"
			}),
			/* @__PURE__ */ r("path", {
				d: "M1-38 0 7",
				fill: "none",
				stroke: F.cream
			}),
			/* @__PURE__ */ r("path", {
				d: "m-12 8 24 1-1 5-23-2m9 1-1 16 6 1 1-16",
				fill: F.ochre
			}),
			/* @__PURE__ */ r("path", {
				d: "m-4 18 6 1m-6 4 6 1",
				fill: "none"
			})
		]
	});
}
function he() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(L, {}),
		/* @__PURE__ */ r("path", {
			d: "m52 175 146-56 7 11-147 57Z",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "m60 178 33-11m42-16 40-15",
			fill: "none",
			stroke: F.paper
		}),
		/* @__PURE__ */ r(I, {
			x: 119,
			y: 97,
			species: "bird",
			pose: "walk",
			scale: 1.12,
			coat: F.rust
		}),
		/* @__PURE__ */ r("path", {
			d: "m102 78 83-32",
			fill: "none",
			stroke: F.bark,
			strokeWidth: "4"
		}),
		/* @__PURE__ */ r("path", {
			d: "m166 54 12-7q25 12 17 34-15 17-28-2-7-12-1-25Z",
			fill: F.sage
		}),
		/* @__PURE__ */ r("path", {
			d: "m171 54 10 4m-12 1 11 4m-11 1 9 5m-6 12 9 4m-1-36 7-12m-7 12 14-3",
			fill: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "m46 124 11-26 15 30-25 2m10-32 9-14 8 32",
			fill: F.moss
		}),
		/* @__PURE__ */ r("path", {
			d: "m52 157 6-12m135 21 8-11m9 18 4-8M76 31l8-4 7 4m22-10 7-4 8 4",
			fill: "none"
		})
	] });
}
function ge() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(L, {}),
		/* @__PURE__ */ r("path", {
			d: "m3 188 97-65 18 1-78 64",
			fill: F.cream,
			stroke: "none"
		}),
		/* @__PURE__ */ r(I, {
			x: 82,
			y: 97,
			species: "bird",
			pose: "walk",
			coat: F.sage,
			scale: 1.1
		}),
		/* @__PURE__ */ r(I, {
			x: 176,
			y: 111,
			species: "bird",
			pose: "walk",
			coat: F.rose,
			scale: .79
		}),
		/* @__PURE__ */ r("path", {
			d: "m43 165 21-14 4 10-13 12-11 1Zm59-13 10-3 10 8 1 10-13 1-11-6m50-13 12-8 4 8-9 8Zm42-2 8 1 7 9-9 3",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "m48 166 15-8m42-3 10 9m38-14 6-4m35 5 6 5M55 86l-19 3m18 6-13 3m104-18-14 3m16 5-10 3",
			fill: "none",
			stroke: F.paper
		}),
		/* @__PURE__ */ r("path", {
			d: "m118 102 14-20 4 16 15-10m-23 65 8 4m1 13 9 2m57-47 15-9",
			fill: "none"
		})
	] });
}
function _e() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(L, {}),
		/* @__PURE__ */ r("path", {
			d: "M23 121V38m109 86V36M18 39l53-19 67 16-3 23H16Z",
			fill: F.rose
		}),
		/* @__PURE__ */ r("path", {
			d: "m30 36 13-5-1 27H26m32-32 13-4 9 36H62m32-32 13 3 16 29h-18",
			fill: F.paper,
			stroke: "none"
		}),
		/* @__PURE__ */ r(z, {
			x: 17,
			y: 139,
			width: 128
		}),
		/* @__PURE__ */ r(I, {
			x: 84,
			y: 99,
			species: "bird",
			coat: F.dark
		}),
		/* @__PURE__ */ r(I, {
			x: 192,
			y: 109,
			species: "fox",
			facing: -1,
			coat: F.sage
		}),
		/* @__PURE__ */ r(U, {
			x: 37,
			y: 109,
			turn: -12,
			scale: .65
		}),
		/* @__PURE__ */ r(U, {
			x: 118,
			y: 106,
			turn: 16,
			scale: .7
		}),
		/* @__PURE__ */ r("path", {
			d: "m156 149 32-16 7 9-34 18Zm-104 9 41-12 3 4-39 15",
			fill: F.paper
		}),
		/* @__PURE__ */ r(V, {
			x: 108,
			y: 130,
			n: 5
		}),
		/* @__PURE__ */ r(B, {
			x: 17,
			y: 160,
			scale: .7
		}),
		/* @__PURE__ */ r("path", {
			d: "m77 68-2-11 13 2 3 9m-23 56 10-4m94 12-10 4",
			fill: "none"
		})
	] });
}
function ve({ suit: e }) {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(L, {}),
		/* @__PURE__ */ r("path", {
			d: "M177 45q32-9 36 32t-22 39q-29-3-31-33t17-38Z",
			fill: F.bark
		}),
		/* @__PURE__ */ r("ellipse", {
			cx: "187",
			cy: "80",
			rx: "21",
			ry: "30",
			fill: F.paper
		}),
		/* @__PURE__ */ r("ellipse", {
			cx: "187",
			cy: "80",
			rx: "14",
			ry: "21",
			fill: "none",
			stroke: F.rust,
			strokeWidth: "3"
		}),
		/* @__PURE__ */ r("ellipse", {
			cx: "187",
			cy: "80",
			rx: "5",
			ry: "8",
			fill: F.rust
		}),
		/* @__PURE__ */ r("path", {
			d: "m177 116-7 43m29-44 10 45",
			fill: "none",
			stroke: F.bark,
			strokeWidth: "4"
		}),
		/* @__PURE__ */ r(I, {
			x: 75,
			y: 112,
			species: e,
			coat: F.sage,
			pose: "work",
			scale: 1.15
		}),
		/* @__PURE__ */ r("path", {
			d: "m77 96 79-14m-30-24q34 22 21 56m-21-56 21 56m-43-18 8 16 6-1-5-17m-6-2 58-10-8-4m8 4-5 5",
			fill: "none",
			strokeWidth: "3"
		}),
		/* @__PURE__ */ r("path", {
			d: "m112 90 33-6M58 163l14-4m99 7 8-2m-77-14 11-2",
			fill: "none",
			stroke: F.cream
		}),
		/* @__PURE__ */ r(B, {
			x: 20,
			y: 157,
			scale: .65
		})
	] });
}
function ye() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(R, {}),
		/* @__PURE__ */ r(I, {
			x: 78,
			y: 111,
			species: "fox",
			coat: F.sage,
			pose: "work"
		}),
		/* @__PURE__ */ r(z, {
			x: 93,
			y: 138,
			width: 111
		}),
		/* @__PURE__ */ r(H, {
			x: 155,
			y: 109,
			scale: 1.15
		}),
		/* @__PURE__ */ r("path", {
			d: "M125 143q-13-19-7-25m1 10q20-4 29 10m-3-2q-13 28 10 34 12-2 11-14",
			fill: "none",
			stroke: F.cream,
			strokeWidth: "3"
		}),
		/* @__PURE__ */ r("path", {
			d: "M25 69V29h58v32m-51-4V32m10 25V32m12 25V32m11 25V32m10 25V32",
			fill: "none",
			stroke: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "m28 37 7 8m7-1 8-6m8-2 8 8m5-6 8 7",
			fill: "none"
		}),
		/* @__PURE__ */ r(B, {
			x: 20,
			y: 147
		}),
		/* @__PURE__ */ r("path", {
			d: "m194 120 11-8 5 7-10 7m-5 9 15-11m-20 8-9-4m12 9-10-4",
			fill: "none"
		}),
		/* @__PURE__ */ r(V, {
			x: 118,
			y: 138,
			n: 2
		})
	] });
}
function be({ suit: e }) {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(L, {}),
		/* @__PURE__ */ r("path", {
			d: "M20 83q11-32 34-11 5-22 26-7 19-32 37-5l-9 59H22Z",
			fill: F.sage
		}),
		/* @__PURE__ */ r("path", {
			d: "M28 94q35-19 70-10m-63 19 63-9m-68-12 58-9",
			fill: "none",
			stroke: F.cream,
			strokeWidth: ".9"
		}),
		/* @__PURE__ */ r(I, {
			x: 164,
			y: 100,
			species: e,
			coat: F.rose,
			pose: "hold",
			scale: 1.06
		}),
		/* @__PURE__ */ r(z, {
			x: 57,
			y: 145,
			width: 126
		}),
		/* @__PURE__ */ r("path", {
			d: "M82 132q-9-24 1-40h26q12 14 3 40Z",
			fill: F.ochre
		}),
		/* @__PURE__ */ r("path", {
			d: "m85 90 4-7h14l4 7m-26 11-17-6 14 20m34-17q20-11 19 5t-16 16",
			fill: "none",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ r("path", {
			d: "M137 130v-13h18v13q-9 11-18 0m18-12q14-4 7 9h-7m-22 10h28m-71-32 18-2m-16 9 15-2m-17 9 16-2",
			fill: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M143 110q-7-10 0-18m8 17q-5-8 2-13m-59-22q-9-9-2-19",
			fill: "none",
			stroke: F.moss
		}),
		/* @__PURE__ */ r("path", {
			d: "m28 157 9-17 10 19m-14-6 12-13m-10 23 1-18",
			fill: F.moss
		}),
		/* @__PURE__ */ r(B, {
			x: 15,
			y: 160,
			scale: .65
		})
	] });
}
function xe({ suit: e }) {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(L, {}),
		/* @__PURE__ */ r("path", {
			d: "M29 104V43h69v60ZM24 44l39-25 40 25",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "M38 106V55h19v50m9-1V55h21v49",
			fill: F.dark
		}),
		/* @__PURE__ */ r(I, {
			x: 151,
			y: 113,
			species: e,
			pose: "walk",
			coat: F.blue
		}),
		/* @__PURE__ */ r("path", {
			d: "m131 86-17-20 4-4 21 19m-20-17 4-12 18-1 6 32-21 8-8-6Z",
			fill: F.sage
		}),
		/* @__PURE__ */ r("path", {
			d: "m125 60 15-2m-15 8 17-2m-13 12 14-3",
			fill: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M170 121v-24h15l2 17 18 7-1 13h-36Z",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "m174 104 10-1m-10 7h10m-15 19h32",
			fill: "none",
			stroke: F.paper
		}),
		/* @__PURE__ */ r(H, {
			x: 81,
			y: 144,
			scale: .8
		}),
		/* @__PURE__ */ r("path", {
			d: "m32 119 32-5 3 25-30 4Zm1 6 31-4m-27 14 28-5m147-39-8-4m9-3 9 2",
			fill: F.paper
		}),
		/* @__PURE__ */ r("path", {
			d: "m197 165 11-27 17 28m-17-28v37",
			fill: F.moss
		})
	] });
}
function Se() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(L, {}),
		/* @__PURE__ */ r("path", {
			d: "M136 140V62q27-24 62 0v78Zm-10-78 43-31 41 31",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "M154 140V83q15-15 28 0v57Z",
			fill: F.dark
		}),
		/* @__PURE__ */ r("path", {
			d: "m143 67 44 3m-43 7 43 2m-43 8h9",
			fill: "none",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ r(I, {
			x: 77,
			y: 110,
			species: "fox",
			scale: 1.2,
			coat: F.dark,
			pose: "speak"
		}),
		/* @__PURE__ */ r(I, {
			x: 169,
			y: 122,
			species: "rabbit",
			scale: .7,
			coat: F.rose
		}),
		/* @__PURE__ */ r("path", {
			d: "M64 84 75 81l14 15-5 7-16-7Zm-4-30-1-9 16-3 8 10m24 63 20-15 4 5-19 19",
			fill: F.bark
		}),
		/* @__PURE__ */ r(V, {
			x: 124,
			y: 136,
			n: 7
		}),
		/* @__PURE__ */ r(H, {
			x: 205,
			y: 159,
			scale: .7
		}),
		/* @__PURE__ */ r("path", {
			d: "m22 174 12-5m-13-8 18-5m80 21 11-3m54-8 13-1",
			fill: "none"
		})
	] });
}
function Ce() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(R, { stone: !0 }),
		/* @__PURE__ */ r("path", {
			d: "M14 139V71Q14 29 52 28t37 43v69Z",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "M23 128V77q0-30 28-30t28 30v51Z",
			fill: F.ink
		}),
		/* @__PURE__ */ r("path", {
			d: "M30 125q-10-25 9-41-3 24 10 11l5-23q27 35 14 53Z",
			fill: F.rust
		}),
		/* @__PURE__ */ r("path", {
			d: "m44 124 8-22 10 22",
			fill: F.ochre,
			stroke: "none"
		}),
		/* @__PURE__ */ r(I, {
			x: 145,
			y: 105,
			species: "fox",
			pose: "work",
			coat: F.blue,
			scale: 1.03
		}),
		/* @__PURE__ */ r("path", {
			d: "m128 113 21 9-3 23-20 9-24-7 17-13-26-11Z",
			fill: "#a3ab9b"
		}),
		/* @__PURE__ */ r("path", {
			d: "m124 148-10 21 43 2-9-25",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "m107 123 24 8 16-7m-26 32 24 2m-21 5 24 1",
			fill: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "m169 76 9-26 6 2-8 27m-3-34 25 4-4 13-25-5Z",
			fill: F.bark
		}),
		/* @__PURE__ */ r(U, {
			x: 79,
			y: 154,
			turn: 67,
			scale: .85
		}),
		/* @__PURE__ */ r("path", {
			d: "m94 99 8-8m-8-1-5-7m13 19 11-1m-75-53 5-9m15 5 5-9",
			fill: "none",
			stroke: F.ochre
		}),
		/* @__PURE__ */ r(B, {
			x: 188,
			y: 153,
			scale: .8
		}),
		/* @__PURE__ */ r("path", {
			d: "m22 62 7 1m-8 10h8m-7 10h6m47-18 10 1m-9 9h9m-9 9h9m34 37 8 3m-6 2 7 2",
			fill: "none",
			strokeWidth: ".7"
		})
	] });
}
function we() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(L, {
			river: !0,
			night: !0
		}),
		/* @__PURE__ */ r("path", {
			d: "m32 169 28-21 117-5 25 12-37 22-106 4Z",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "m54 162 113-8m-110 15 107-6m-100 13 97-5m-69-16-4 22m48-24-6 20",
			fill: "none",
			stroke: F.ochre
		}),
		/* @__PURE__ */ r(I, {
			x: 91,
			y: 109,
			species: "rabbit",
			coat: F.dark,
			pose: "walk",
			scale: .9
		}),
		/* @__PURE__ */ r(I, {
			x: 161,
			y: 119,
			species: "rabbit",
			coat: F.rose,
			pose: "hold",
			scale: .7
		}),
		/* @__PURE__ */ r(H, {
			x: 74,
			y: 106,
			scale: .9
		}),
		/* @__PURE__ */ r(B, {
			x: 124,
			y: 123,
			scale: .7
		}),
		/* @__PURE__ */ r("path", {
			d: "m166 148 25-31 4 3-25 31M49 126l-21-16m5-4 9 5-4 8m166-26 16 3m-16 4 11 2",
			fill: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M30 188q21-22 27-13l6 13m142 0q1-24 13-17l8 17",
			fill: F.dark,
			stroke: "none"
		})
	] });
}
function Te() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(L, {}),
		/* @__PURE__ */ r("path", {
			d: "M13 133V49h66v84M5 50l41-28 42 28",
			fill: F.clay
		}),
		/* @__PURE__ */ r("path", {
			d: "M25 130V79q18-18 33 0v51Z",
			fill: F.ink
		}),
		/* @__PURE__ */ r("path", {
			d: "m30 127 8-22 8 13 4-17 7 26",
			fill: F.rust,
			stroke: "none"
		}),
		/* @__PURE__ */ r(I, {
			x: 177,
			y: 111,
			species: "fox",
			pose: "walk",
			coat: F.blue,
			facing: -1,
			scale: 1.04
		}),
		/* @__PURE__ */ r("path", {
			d: "m45 139 81-5 26 12-83 10Z",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "m47 142 20 22 73-5 11-13m-5 0 32-13m-12-2 12 2-10 9",
			fill: "none",
			strokeWidth: "3"
		}),
		/* @__PURE__ */ r("circle", {
			cx: "76",
			cy: "164",
			r: "14",
			fill: F.ochre
		}),
		/* @__PURE__ */ r("circle", {
			cx: "131",
			cy: "160",
			r: "13",
			fill: F.ochre
		}),
		/* @__PURE__ */ r("path", {
			d: "M76 151v26m-12-13h24m43-16v24m-12-12h24m-74-2 15 14m-15 0 14-14m42-4 13 12m-13 0 12-12",
			fill: "none",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ r("path", {
			d: "m68 101 23 5 28-6 8 13-20 7-2 12 13 6-49 3 16-11v-11l-24-12Z",
			fill: "#a3ab9b"
		}),
		/* @__PURE__ */ r("path", {
			d: "m70 108 24 7 29-8m-33 12v12m-6 3 19-1m-15 4 16-1",
			fill: "none",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ r("path", {
			d: "m37 64 18-1m-15-7 13-1m-38 82 4-9m3 10 5-12m179 24 6-13m-2 15 10-11",
			fill: "none",
			stroke: F.moss
		}),
		/* @__PURE__ */ r("path", {
			d: "m104 43 7-6 8 7m-22 8 8-5 7 4",
			fill: "none"
		})
	] });
}
function Ee() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(R, {}),
		/* @__PURE__ */ r("path", {
			d: "M19 121V25h72v96M20 54h70m-70 33h70",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "m29 31 5 18m4-19 5 18m5-18 5 18m13-18 4 18m5-18 5 18M29 62h18v18H29m28-18h26v18H57",
			fill: F.sage
		}),
		/* @__PURE__ */ r(I, {
			x: 144,
			y: 106,
			species: "bird",
			coat: F.rose,
			pose: "work"
		}),
		/* @__PURE__ */ r(z, {
			x: 54,
			y: 143,
			width: 143
		}),
		/* @__PURE__ */ r("path", {
			d: "m74 135 22-27 34 3q-9 20-3 31Z",
			fill: F.cream
		}),
		/* @__PURE__ */ r("path", {
			d: "m97 115 21 2m-25 4 20 2m-26 5 21 2m-17 6 22 1",
			fill: "none",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ r("path", {
			d: "m166 84 7-39q22-8 16 12l-23 27m8-33 3 11m3-15 3 10m-17 26-9 41",
			fill: F.paper
		}),
		/* @__PURE__ */ r("path", {
			d: "m151 134 7-10 8 2 5 11Z",
			fill: F.ink
		}),
		/* @__PURE__ */ r("path", {
			d: "m176 136 20-10 14 5-21 11m-12-9 21-3",
			fill: F.ochre
		}),
		/* @__PURE__ */ r(B, {
			x: 18,
			y: 151,
			scale: .7
		}),
		/* @__PURE__ */ r("path", {
			d: "m122 75 17 2m-14-5 11 1m61 97 10-2m-103 10 13-1",
			fill: "none"
		})
	] });
}
function De() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(L, {}),
		/* @__PURE__ */ r("path", {
			d: "M116 151V75q-3-56 45-59t54 59v76Z",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "M145 153V91q0-30 23-30t23 30v62Z",
			fill: F.dark
		}),
		/* @__PURE__ */ r("path", {
			d: "M137 154V94q-1-27 10-32l-25 5v92Z",
			fill: F.ochre
		}),
		/* @__PURE__ */ r("path", {
			d: "m125 80 14-5m-14 13 13-5m-13 13 12-5m-12 13 12-5m-12 13 12-5m-10 17h5",
			fill: "none",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ r(I, {
			x: 169,
			y: 111,
			species: "rabbit",
			coat: F.rose,
			pose: "speak",
			scale: .7
		}),
		/* @__PURE__ */ r(I, {
			x: 78,
			y: 111,
			species: "rabbit",
			coat: F.blue,
			pose: "walk",
			scale: 1.02
		}),
		/* @__PURE__ */ r("path", {
			d: "m93 122 22-5 2 19-21 5Zm1-4 9-13 11 11m-14 9 14-3m-13 7 14-3",
			fill: F.sage
		}),
		/* @__PURE__ */ r("path", {
			d: "m40 167 17-6m115 2 27-1m-79 13 17-3m-12-124 8-9m57 6-7-8m18 14-6-8",
			fill: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "m23 150 5-26 10 24m-6-18 9-8 6 25m-18-1 1 14",
			fill: F.moss
		})
	] });
}
function Oe() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(R, {}),
		/* @__PURE__ */ r("path", {
			d: "M19 114V40h89v75m-88-45h86m-86 29h86",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "m27 42 5 22m5-22 5 22m5-22 5 22m17-22 4 22m4-22 5 22m5-22 5 22M28 76h19v17H28m32-17h34v17H60",
			fill: F.sage
		}),
		/* @__PURE__ */ r(I, {
			x: 150,
			y: 102,
			species: "mouse",
			pose: "work",
			coat: F.rose
		}),
		/* @__PURE__ */ r(z, {
			x: 49,
			y: 142,
			width: 143
		}),
		/* @__PURE__ */ r(H, {
			x: 99,
			y: 109,
			scale: 1.3
		}),
		/* @__PURE__ */ r("path", {
			d: "m145 143 31-13 5 5-30 14m-7-2-12 5m44-12 5 7m-8-1 13-2m-14 5 15 4",
			fill: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "m171 98 22 3-2 25-14-1Z",
			fill: F.cream
		}),
		/* @__PURE__ */ r("path", {
			d: "m178 105 10 1m-9 6 8 1m-8 6 7 1",
			fill: "none",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ r(B, {
			x: 15,
			y: 155,
			scale: .8
		}),
		/* @__PURE__ */ r("path", {
			d: "M201 164q18-35 26-3m-26 7 27-1m-24 6 22-1",
			fill: F.sage
		})
	] });
}
function ke() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(R, {}),
		/* @__PURE__ */ r(I, {
			x: 75,
			y: 107,
			species: "mouse",
			coat: F.dark,
			pose: "hold"
		}),
		/* @__PURE__ */ r(z, {
			x: 54,
			y: 140,
			width: 139
		}),
		/* @__PURE__ */ r("path", {
			d: "m102 123 25-21 38 3-21 24Z",
			fill: F.cream
		}),
		/* @__PURE__ */ r("path", {
			d: "m127 107 24 2m-29 3 23 2m-29 3 19 2m-12 7 11-1",
			fill: "none",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ r(V, {
			x: 153,
			y: 134,
			n: 8
		}),
		/* @__PURE__ */ r("path", {
			d: "m22 83 5-34 20-2 3 33Z",
			fill: F.ochre
		}),
		/* @__PURE__ */ r("path", {
			d: "m26 55 20-1m-21 7 22-1m-22 7 22-1m-20 7 20-1",
			fill: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M195 130V96m-1 15q-24-6-16-23 21 0 16 23m2-8q-6-25 12-27 13 19-12 27m-1-7q-23-8-17-23 22-1 17 23m2-11q-1-17 12-22 12 14-12 22",
			fill: F.sage
		}),
		/* @__PURE__ */ r("path", {
			d: "m179 130 33-2-5 22-21 2Z",
			fill: F.clay
		}),
		/* @__PURE__ */ r("path", {
			d: "m188 136 17-1m-16 6 15-1",
			fill: "none"
		}),
		/* @__PURE__ */ r(H, {
			x: 30,
			y: 166,
			scale: .65
		})
	] });
}
function Ae() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(L, {}),
		/* @__PURE__ */ r("path", {
			d: "M8 160q25-33 63-10l24 38H0Z",
			fill: F.moss
		}),
		/* @__PURE__ */ r("path", {
			d: "m157 133 22-13 32 12 14 29-66 5-17-17Z",
			fill: "#aab09a"
		}),
		/* @__PURE__ */ r("path", {
			d: "m157 134 20 13 36-14m-36 14-4 16m21-30 12 16m-47 8 12 2",
			fill: "none",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ r(I, {
			x: 95,
			y: 113,
			species: "mouse",
			coat: F.blue,
			pose: "work",
			scale: 1.15
		}),
		/* @__PURE__ */ r(U, {
			x: 141,
			y: 114,
			turn: -24,
			scale: 1.2
		}),
		/* @__PURE__ */ r("path", {
			d: "m71 62 17-5 17 3m-31 0 2-9 20-2 6 9",
			fill: F.ochre
		}),
		/* @__PURE__ */ r("path", {
			d: "m162 103 10-8m-13-2 4-12m10 34 12 2m-64 46 12-3m66 15 9-2",
			fill: "none",
			stroke: F.ochre
		}),
		/* @__PURE__ */ r("path", {
			d: "m13 179 4-13m2 14 6-10m7 10 4-15m174 9 5-16m2 15 7-12",
			fill: "none",
			stroke: F.paper
		})
	] });
}
function je() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(R, { stone: !0 }),
		/* @__PURE__ */ r("path", {
			d: "M16 129V55h66v78m-65-52h64",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "m26 44 12-10 15 9-2 29-12 11-12-13Zm36-6 10-7 13 6-2 26-10 9-10-10Z",
			fill: "#aab09a"
		}),
		/* @__PURE__ */ r("path", {
			d: "M39 42v33m-10-22 19 1m25-17v28m-8-16h15",
			fill: "none",
			stroke: F.cream
		}),
		/* @__PURE__ */ r(I, {
			x: 144,
			y: 104,
			species: "bird",
			coat: F.rose,
			pose: "work"
		}),
		/* @__PURE__ */ r(z, {
			x: 77,
			y: 140,
			width: 119
		}),
		/* @__PURE__ */ r("path", {
			d: "m94 120 1-17q15-26 36-9l7 25-16 7Zm5-5 31-3m-27-8 23-2m-15-5 4 16",
			fill: "#aab09a"
		}),
		/* @__PURE__ */ r("path", {
			d: "m164 82 8-22 6 2-8 22m-2-28 17 5-3 10-17-5Z",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "m158 141 23-16 10 10-25 15Zm9-5 12-7m-6 14 12-8",
			fill: F.ochre
		}),
		/* @__PURE__ */ r(B, {
			x: 17,
			y: 149,
			scale: .8
		})
	] });
}
function Me() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(L, {}),
		/* @__PURE__ */ r("path", {
			d: "M0 64q54-11 102 17t138-4v111H0Z",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "M13 188V154Q13 96 80 98t85 57v33Z",
			fill: F.ink
		}),
		/* @__PURE__ */ r("path", {
			d: "M18 188v-33q0-50 62-50t77 50v33",
			fill: F.dark
		}),
		/* @__PURE__ */ r("path", {
			d: "m35 183 5-63 89 5 9 59m-96-50 85 3",
			fill: "none",
			stroke: F.clay,
			strokeWidth: "6"
		}),
		/* @__PURE__ */ r(I, {
			x: 88,
			y: 143,
			species: "bird",
			coat: F.ochre,
			pose: "work",
			scale: .7
		}),
		/* @__PURE__ */ r("path", {
			d: "m107 133 29-35 4 3-29 36m15-43 22 11-2 6-25-12Z",
			fill: F.bark
		}),
		/* @__PURE__ */ r(I, {
			x: 190,
			y: 91,
			species: "bird",
			coat: F.sage,
			pose: "work",
			scale: .85
		}),
		/* @__PURE__ */ r("path", {
			d: "m177 121-24 27 5 5 26-30m-27 24-10 2-7 10 10 9 14-13Z",
			fill: F.blue
		}),
		/* @__PURE__ */ r("path", {
			d: "m16 95 10-6m6 3 8-7m76 20 11-6m-7 16 10-7m-87 48 6-4m6 13 9-4",
			fill: "none",
			stroke: F.ochre
		}),
		/* @__PURE__ */ r(B, {
			x: 183,
			y: 156,
			scale: .8
		})
	] });
}
function Ne() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(L, {}),
		/* @__PURE__ */ r("path", {
			d: "M17 188q18-45 42-23l16 23m97 0q12-37 34-21l26 21",
			fill: F.moss
		}),
		/* @__PURE__ */ r(I, {
			x: 89,
			y: 103,
			species: "bird",
			coat: F.rust,
			pose: "speak",
			scale: 1.15
		}),
		/* @__PURE__ */ r(I, {
			x: 174,
			y: 123,
			species: "bird",
			coat: F.dark,
			pose: "walk",
			scale: .75
		}),
		/* @__PURE__ */ r("path", {
			d: "m97 62 6-48m-4 8 44 6-13 11 9 9-39-7",
			fill: F.rose
		}),
		/* @__PURE__ */ r("path", {
			d: "m105 27 24 4m-24 3 16 2m5 47 20-33 4 2-20 35m11-37 11-12 2 17Z",
			fill: F.paper
		}),
		/* @__PURE__ */ r(U, {
			x: 182,
			y: 114,
			turn: 24,
			scale: .7
		}),
		/* @__PURE__ */ r("path", {
			d: "m17 78 13 7m-7-19 12 10m164-30-8 12m17-5-11 10M78 151l13 9 9-6m-64 25 12-5",
			fill: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "m37 153 14-8 8 11-16 7Z",
			fill: F.ochre
		})
	] });
}
function Pe() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(L, { night: !0 }),
		/* @__PURE__ */ r("path", {
			d: "m93 188 37-61 17 2-18 59",
			fill: F.paper,
			stroke: "none"
		}),
		/* @__PURE__ */ r(I, {
			x: 78,
			y: 113,
			species: "fox",
			coat: F.dark,
			pose: "speak",
			scale: 1.07
		}),
		/* @__PURE__ */ r(I, {
			x: 180,
			y: 127,
			species: "mouse",
			coat: F.rose,
			pose: "speak",
			scale: .83
		}),
		/* @__PURE__ */ r("path", {
			d: "m66 81 21-2 5 9-25 5Z",
			fill: F.ink
		}),
		/* @__PURE__ */ r("path", {
			d: "m64 59 13-5 15 6 7 4-37 6Zm-6 4 43-4",
			fill: F.dark
		}),
		/* @__PURE__ */ r(U, {
			x: 121,
			y: 103,
			turn: 80,
			scale: .8
		}),
		/* @__PURE__ */ r(H, {
			x: 163,
			y: 164,
			scale: .72
		}),
		/* @__PURE__ */ r(V, {
			x: 137,
			y: 166,
			n: 4
		}),
		/* @__PURE__ */ r("path", {
			d: "m18 187 9-32 11 24 11-15 13 24m149 0 8-40 15 40",
			fill: F.moss
		}),
		/* @__PURE__ */ r("path", {
			d: "m181 73-1-9m7 10 4-8m-37 50-8-1",
			fill: "none",
			stroke: F.ochre
		})
	] });
}
function Fe() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r("path", {
			d: "M0 0h240v188H0Z",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "M9 188V82Q9 9 118 9t113 73v106Z",
			fill: F.paper
		}),
		/* @__PURE__ */ r("path", {
			d: "M18 102Q7 23 115 20t108 79m-203-17q7-43 53-50m135 21 9 15",
			fill: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M0 154q121-25 240-2v36H0Z",
			fill: F.clay
		}),
		/* @__PURE__ */ r("path", {
			d: "M158 134V66q0-27 28-27t28 27v68Z",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "M166 131V69q0-21 20-21t20 21v62Z",
			fill: F.dark
		}),
		/* @__PURE__ */ r("path", {
			d: "M173 63v62m12-70v69m12-61v62m-29-34h34",
			fill: "none",
			stroke: F.ochre,
			strokeWidth: "2"
		}),
		/* @__PURE__ */ r(I, {
			x: 89,
			y: 110,
			species: "rabbit",
			coat: F.blue,
			pose: "hold",
			scale: .92
		}),
		/* @__PURE__ */ r(z, {
			x: 19,
			y: 143,
			width: 132
		}),
		/* @__PURE__ */ r(V, {
			x: 103,
			y: 133,
			n: 8
		}),
		/* @__PURE__ */ r(H, {
			x: 34,
			y: 114,
			scale: .75
		}),
		/* @__PURE__ */ r("path", {
			d: "m64 136 29-10 16 8-30 11Z",
			fill: F.cream
		}),
		/* @__PURE__ */ r("path", {
			d: "m74 135 10-3m-5 7 10-3M28 61h27v32H28Zm4 6h19m-19 7h14m-14 7h18",
			fill: "none",
			strokeWidth: ".8"
		})
	] });
}
function Ie() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(R, {}),
		/* @__PURE__ */ r("path", {
			d: "M24 87V28h77v59M22 89h81",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "M33 48V34h11v20l12 4v8H29V53m38-5V34h11v19l12 5v8H63V54",
			fill: F.ochre
		}),
		/* @__PURE__ */ r("path", {
			d: "m34 40 8 1m25-1 8 1m-44 20h22m13 0h21",
			fill: "none"
		}),
		/* @__PURE__ */ r(I, {
			x: 150,
			y: 106,
			species: "rabbit",
			coat: F.rose,
			pose: "work",
			scale: .9
		}),
		/* @__PURE__ */ r(z, {
			x: 51,
			y: 143,
			width: 142
		}),
		/* @__PURE__ */ r("path", {
			d: "M86 130V98l20-2v27l25 5 2 14-51-1v-9Z",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "m90 104 13-1m-13 7 13-1m-14 7h14m-18 19 44 2",
			fill: "none",
			stroke: F.paper
		}),
		/* @__PURE__ */ r("path", {
			d: "m172 86 6-19 5 1-5 21m-3-27 17 6-3 9-17-6m-32 57-4-6m-3 9-3-5m30 9 16-6",
			fill: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M30 149q-22 24 14 24 17-4 15-13",
			fill: "none",
			stroke: F.cream,
			strokeWidth: "2"
		}),
		/* @__PURE__ */ r(B, {
			x: 15,
			y: 155,
			scale: .65
		})
	] });
}
function Le() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(L, {}),
		/* @__PURE__ */ r("path", {
			d: "M0 160 26 113l37 15 34 60H0Zm133 28 27-57 41-11 39 55v13Z",
			fill: F.moss
		}),
		/* @__PURE__ */ r(I, {
			x: 88,
			y: 102,
			species: "mouse",
			coat: F.sage,
			pose: "work",
			scale: 1.05
		}),
		/* @__PURE__ */ r(I, {
			x: 178,
			y: 112,
			species: "mouse",
			coat: F.blue,
			pose: "hold",
			scale: .75
		}),
		/* @__PURE__ */ r("path", {
			d: "m98 80 35-21 7 9-35 24Z",
			fill: F.ochre
		}),
		/* @__PURE__ */ r("ellipse", {
			cx: "137",
			cy: "63",
			rx: "5",
			ry: "7",
			transform: "rotate(-30 137 63)",
			fill: F.dark
		}),
		/* @__PURE__ */ r("path", {
			d: "m111 75 5 10m6-17 5 10M58 57l5-12 30-2 8 13Z",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "m161 132 26-7 10 20-27 8Z",
			fill: F.paper
		}),
		/* @__PURE__ */ r("path", {
			d: "m169 135 9 2 4-4 7 6m-10-9 1 13",
			fill: "none",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ r("path", {
			d: "m31 127 5-18m4 22 7-17m156 35 4-21m4 17 9-14M138 34l11-5 9 4m-33 9 8-4 7 3",
			fill: "none"
		})
	] });
}
function Re() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(R, {}),
		/* @__PURE__ */ r("path", {
			d: "M0 0h240v188H0Z",
			fill: F.dark,
			stroke: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M12 143V23h67v123m-64-87h62m-62 40h62",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "m23 30 4 25m5-25 4 25m5-25 4 25m12-25 4 25m6-25 4 25M23 66l4 28m6-28 4 28m6-28 4 28m12-28 4 28m6-28 4 28",
			fill: "none",
			stroke: F.paper
		}),
		/* @__PURE__ */ r("path", {
			d: "M0 155q115-18 240-4v37H0Z",
			fill: F.clay
		}),
		/* @__PURE__ */ r(I, {
			x: 135,
			y: 103,
			species: "mouse",
			coat: F.blue,
			pose: "hold"
		}),
		/* @__PURE__ */ r(z, {
			x: 69,
			y: 143,
			width: 142
		}),
		/* @__PURE__ */ r("path", {
			d: "m86 136 22-26 40 5 26 23-47 10Z",
			fill: F.cream
		}),
		/* @__PURE__ */ r("path", {
			d: "m108 115 19 30m-28-12 20 1m-14-7 11 1m19-6 16 2m-11 5 15 2m-10 4 15 2",
			fill: "none",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ r("circle", {
			cx: "174",
			cy: "111",
			r: "12",
			fill: F.paper,
			fillOpacity: ".35",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ r("path", {
			d: "m182 120 13 17m-18-24 4-6m-12-5 7-1",
			strokeWidth: "2",
			fill: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M197 70v-20m-8 20h16l4 28h-24Zm2 25h14m-9-21 3 17",
			fill: F.ochre
		}),
		/* @__PURE__ */ r("path", {
			d: "m123 83 9-4 11 4m-19 0 1-8m17 8-1-8m-14 6q5 6 10 0",
			fill: "none"
		}),
		/* @__PURE__ */ r(B, {
			x: 21,
			y: 154,
			scale: .7
		})
	] });
}
function ze() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(R, { stone: !0 }),
		/* @__PURE__ */ r("path", {
			d: "M25 143V29l40-9 44 9v115Z",
			fill: F.blue
		}),
		/* @__PURE__ */ r("path", {
			d: "m39 31 26-6 30 7v53L66 104 39 85Z",
			fill: F.rose
		}),
		/* @__PURE__ */ r("path", {
			d: "m48 55 9 5 9-17 8 17 12-7-5 24H52Z",
			fill: F.ochre
		}),
		/* @__PURE__ */ r(I, {
			x: 81,
			y: 114,
			species: "bird",
			pose: "speak",
			coat: F.ochre,
			scale: 1.1
		}),
		/* @__PURE__ */ r("path", {
			d: "m61 76 2-13 9 6 8-13 8 11 10-7-1 16Z",
			fill: F.ochre
		}),
		/* @__PURE__ */ r("path", {
			d: "m110 99 7 17 4-1 8-68m-7 2 7-15 7 13-8 10Z",
			fill: F.ochre
		}),
		/* @__PURE__ */ r("path", {
			d: "m137 98 50-6-5 51-44 4q6-21-1-49Z",
			fill: F.paper
		}),
		/* @__PURE__ */ r("path", {
			d: "m145 106 32-4m-31 10 27-3m-27 10 24-2m-22 10 15-1",
			fill: "none",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ r("circle", {
			cx: "173",
			cy: "133",
			r: "6",
			fill: F.rose
		}),
		/* @__PURE__ */ r("path", {
			d: "m169 132 4-2 3 3-4 2Z",
			fill: F.ochre
		}),
		/* @__PURE__ */ r(I, {
			x: 201,
			y: 145,
			species: "mouse",
			coat: F.sage,
			scale: .55
		}),
		/* @__PURE__ */ r("path", {
			d: "M11 163h115v9H11m11 0-12 16m96-16 13 16",
			fill: F.bark
		})
	] });
}
function Be() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(L, {}),
		/* @__PURE__ */ r("path", {
			d: "M146 142V53h64v89m-71-88 39-28 42 28Z",
			fill: F.clay
		}),
		/* @__PURE__ */ r("path", {
			d: "M169 139V85h23v54m-30-78h15v15h-15m23-15h15v15h-15",
			fill: F.dark
		}),
		/* @__PURE__ */ r(I, {
			x: 82,
			y: 105,
			species: "fox",
			coat: F.blue,
			pose: "hold",
			scale: 1.1
		}),
		/* @__PURE__ */ r(I, {
			x: 176,
			y: 120,
			species: "mouse",
			coat: F.sage,
			scale: .78
		}),
		/* @__PURE__ */ r("path", {
			d: "m110 102 22-12 11 31-23 10Z",
			fill: F.paper
		}),
		/* @__PURE__ */ r("path", {
			d: "m117 102 11-5m-8 11 12-5m-10 12 13-5m-10 11 7-3",
			fill: "none",
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ r(H, {
			x: 128,
			y: 160,
			scale: .9
		}),
		/* @__PURE__ */ r(V, {
			x: 159,
			y: 143,
			n: 5
		}),
		/* @__PURE__ */ r("path", {
			d: "M58 71v-7l21-5 11 9Zm-6 1 45-4m24 49 9 1m45 40 12-3",
			fill: F.bark
		}),
		/* @__PURE__ */ r(B, {
			x: 14,
			y: 149,
			scale: .7
		})
	] });
}
function Ve({ suit: e }) {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(L, { night: e === "mouse" }),
		e === "rabbit" ? /* @__PURE__ */ i(n, { children: [
			/* @__PURE__ */ r("path", {
				d: "M15 188q-7-57 47-58t78 58Z",
				fill: F.bark
			}),
			/* @__PURE__ */ r("path", {
				d: "M35 188q-1-40 32-39t44 39",
				fill: F.ink
			}),
			/* @__PURE__ */ r(I, {
				x: 73,
				y: 129,
				species: "rabbit",
				coat: F.sage,
				pose: "work",
				scale: .85
			}),
			/* @__PURE__ */ r(I, {
				x: 178,
				y: 104,
				species: "rabbit",
				coat: F.rose,
				pose: "speak",
				scale: .9
			}),
			/* @__PURE__ */ r("path", {
				d: "m95 111 34-49 5 3-32 49m23-50 12-12 1 17Z",
				fill: F.paper
			}),
			/* @__PURE__ */ r("path", {
				d: "m166 140 37-17 5 9-38 16",
				fill: F.bark
			})
		] }) : e === "bird" ? /* @__PURE__ */ i(n, { children: [
			/* @__PURE__ */ r("path", {
				d: "M0 65 240 38v12L0 78Z",
				fill: F.bark
			}),
			/* @__PURE__ */ r("path", {
				d: "m26 65 17-13m37 7 12-13m56 6 12-11m36 6 14-12",
				fill: "none"
			}),
			/* @__PURE__ */ r(I, {
				x: 75,
				y: 96,
				species: "bird",
				coat: F.rose,
				pose: "work",
				scale: 1.05
			}),
			/* @__PURE__ */ r(I, {
				x: 179,
				y: 74,
				species: "bird",
				coat: F.sage,
				pose: "work",
				scale: .8
			}),
			/* @__PURE__ */ r(U, {
				x: 107,
				y: 93,
				turn: 130,
				scale: .8
			}),
			/* @__PURE__ */ r("path", {
				d: "m176 107-20 39m-3-3 1 16 10-10",
				fill: F.paper
			})
		] }) : /* @__PURE__ */ i(n, { children: [
			/* @__PURE__ */ r("path", {
				d: "M0 188V98l27-3 26 93m110 0 27-58 50-10v68",
				fill: F.bark
			}),
			/* @__PURE__ */ r(I, {
				x: 79,
				y: 121,
				species: "mouse",
				coat: F.dark,
				pose: "work",
				scale: 1.1
			}),
			/* @__PURE__ */ r(I, {
				x: 188,
				y: 134,
				species: "mouse",
				coat: F.rose,
				pose: "work",
				scale: .8
			}),
			/* @__PURE__ */ r(U, {
				x: 118,
				y: 110,
				turn: -25,
				scale: .85
			}),
			/* @__PURE__ */ r("path", {
				d: "m185 123 20-35m-25 20q28-15 37 12m-37-12 37 12",
				fill: "none",
				strokeWidth: "2"
			})
		] }),
		/* @__PURE__ */ r("path", {
			d: "M0 188v-27q10-24 23-9 11-25 28-5l11 41m128 0q-10-33 9-34 11-26 27-5l14-5v44",
			fill: F.moss
		}),
		/* @__PURE__ */ r("path", {
			d: "m12 175 8-13m5 22 8-18m172 16 7-14m5 8 10-15",
			fill: "none",
			stroke: F.sage
		})
	] });
}
function He({ suit: e }) {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(L, {}),
		/* @__PURE__ */ r("path", {
			d: "M28 188V83L75 56l43 27v105m18 0V72l39-24 38 24v116",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "m23 85 52-37 49 37m7-13 44-33 44 33",
			fill: F.blue
		}),
		/* @__PURE__ */ r("path", {
			d: "M43 109h57v79H43Zm109-17h44v96h-44Z",
			fill: F.dark
		}),
		/* @__PURE__ */ r("path", {
			d: "M44 88h58v17H44Zm108-12h44v14h-44",
			fill: F.ochre
		}),
		/* @__PURE__ */ r("path", {
			d: "M122 141V15m-3 11 55 3-13 15 12 15-54-8Z",
			fill: e === "fox" ? F.rust : e === "mouse" ? F.rose : e === "rabbit" ? F.ochre : F.blue
		}),
		/* @__PURE__ */ r("path", {
			d: "m126 34 18 1m-18 6 24 1m-24 6 15 1",
			fill: "none",
			stroke: F.cream
		}),
		/* @__PURE__ */ r(I, {
			x: 74,
			y: 137,
			species: e,
			coat: F.sage,
			scale: .65
		}),
		/* @__PURE__ */ r(I, {
			x: 175,
			y: 134,
			species: e,
			coat: F.rose,
			scale: .6
		}),
		/* @__PURE__ */ r("path", {
			d: "m14 175 41-10 3 9-44 12m176-24 42 10-3 10-41-11",
			fill: F.clay
		}),
		/* @__PURE__ */ r("path", {
			d: "m25 124 5 1m-5 11 5 1m82-35 5 1m22 36 5 1m65-25h5m-5 12h5",
			fill: "none",
			strokeWidth: ".75"
		})
	] });
}
function Ue({ suit: e }) {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r(L, {}),
		/* @__PURE__ */ r("path", {
			d: "m0 188 41-44 51 12 44-17 104 49",
			fill: F.ochre,
			stroke: "none"
		}),
		/* @__PURE__ */ r(I, {
			x: 115,
			y: 101,
			species: e,
			coat: F.rose,
			pose: "speak",
			scale: 1.15
		}),
		/* @__PURE__ */ r(I, {
			x: 42,
			y: 131,
			species: e,
			coat: F.blue,
			pose: "speak",
			scale: .65
		}),
		/* @__PURE__ */ r(I, {
			x: 196,
			y: 130,
			species: e,
			coat: F.sage,
			pose: "speak",
			scale: .65,
			facing: -1
		}),
		/* @__PURE__ */ r("path", {
			d: "M83 154q-1-21 28-23t32 22v22H83Z",
			fill: F.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "m89 148 13-9m-8 19 13-9m16-11 11 9m-15 5 14 7m-32 8 27-2",
			fill: "none",
			stroke: F.paper,
			strokeWidth: ".8"
		}),
		/* @__PURE__ */ r("path", {
			d: "m40 64 9-25 5 23m-7-10 19-15m123 30-11-28-6 25m7-12-18-14M74 27l6 13m14-23 2 14m53-13-5 14m20-6-9 11",
			fill: "none",
			stroke: F.ochre,
			strokeWidth: "2"
		}),
		/* @__PURE__ */ r("path", {
			d: "m9 120 8-8 8 6-7 10Zm201-14 10-6 8 8-10 7m-148-56 9-6 6 8-10 5",
			fill: F.rose
		}),
		/* @__PURE__ */ r("path", {
			d: "m18 171 15 3m173-2 16 2m-64 6 12-2",
			fill: "none"
		})
	] });
}
function We({ card: e }) {
	switch (e.id) {
		case "birdyBindle": return /* @__PURE__ */ r(he, {});
		case "woodlandRunners": return /* @__PURE__ */ r(ge, {});
		case "armsTrader": return /* @__PURE__ */ r(_e, {});
		case "crossbow": return /* @__PURE__ */ r(ve, { suit: e.suit });
		case "knapsack": return /* @__PURE__ */ r(ye, {});
		case "rootTea": return /* @__PURE__ */ r(be, { suit: e.suit });
		case "travelGear": return /* @__PURE__ */ r(xe, { suit: e.suit });
		case "protectionRacket": return /* @__PURE__ */ r(Se, {});
		case "foxfolkSteel": return /* @__PURE__ */ r(Ce, {});
		case "anvil": return /* @__PURE__ */ r(Te, {});
		case "smugglersTrail": return /* @__PURE__ */ r(we, {});
		case "visitFriends": return /* @__PURE__ */ r(De, {});
		case "mouseSack": return /* @__PURE__ */ r(Oe, {});
		case "investments": return /* @__PURE__ */ r(ke, {});
		case "sword": return /* @__PURE__ */ r(Ae, {});
		case "armorers": return /* @__PURE__ */ r(je, {});
		case "sappers": return /* @__PURE__ */ r(Me, {});
		case "brutalTactics": return /* @__PURE__ */ r(Ne, {});
		case "standAndDeliver": return /* @__PURE__ */ r(Pe, {});
		case "betterBurrowBank": return /* @__PURE__ */ r(Fe, {});
		case "cobbler": return /* @__PURE__ */ r(Ie, {});
		case "scoutingParty": return /* @__PURE__ */ r(Le, {});
		case "codebreakers": return /* @__PURE__ */ r(Re, {});
		case "royalClaim": return /* @__PURE__ */ r(ze, {});
		case "taxCollector": return /* @__PURE__ */ r(Be, {});
		case "ambush": return /* @__PURE__ */ r(Ve, { suit: e.suit });
		case "dominance": return /* @__PURE__ */ r(He, { suit: e.suit });
		case "favor": return /* @__PURE__ */ r(Ue, { suit: e.suit });
		case "vizier": return /* @__PURE__ */ r(Ee, {});
		default: return null;
	}
}
//#endregion
//#region src/games/root/card-art.tsx
var W = {
	ink: "#4b493b",
	paper: "#f1e7c9",
	cream: "#fff6de",
	ochre: "#d3ad61",
	sage: "#9da97b",
	moss: "#697f66",
	dark: "#435c50",
	bark: "#937451",
	clay: "#b88658",
	rust: "#be7043",
	blue: "#7c9ca0",
	rose: "#bb7e66"
};
function G({ x: e, y: t, turn: n = 0 }) {
	return /* @__PURE__ */ i("g", {
		transform: `translate(${e} ${t}) rotate(${n})`,
		children: [/* @__PURE__ */ r("path", {
			d: "M-13 5C-17-9 12-15 16-1L15 7Q0 11-13 5Z",
			fill: W.ochre
		}), /* @__PURE__ */ r("path", {
			d: "m-7-1 3-5m4 4 3-6m3 5 3-5M-11 5q12 3 23-1",
			fill: "none"
		})]
	});
}
function Ge() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r("path", {
			d: "M0 0h240v188H0Z",
			fill: W.paper,
			stroke: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M0 72Q20 37 45 69T95 63Q121 34 148 63T194 55Q223 33 240 52V139H0Z",
			fill: "#c5c49b",
			stroke: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M5 10q-3 17 8 26M16 2q-4 21 9 31m199-33q-14 13-12 32M234 5q-10 11-9 24",
			fill: "none",
			stroke: W.sage
		}),
		/* @__PURE__ */ r("path", {
			d: "M0 157q52-24 103-7t137-8v46H0Z",
			fill: "#d4c69b",
			stroke: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M6 151V92Q6 56 35 55T65 92v62Z",
			fill: W.clay
		}),
		/* @__PURE__ */ r("path", {
			d: "M12 94Q11 65 35 65T58 94",
			fill: "none",
			stroke: W.paper,
			strokeWidth: "4"
		}),
		/* @__PURE__ */ r("path", {
			d: "M16 141V113q0-26 20-26t20 26v29Z",
			fill: W.ink
		}),
		/* @__PURE__ */ r("path", {
			d: "M23 136q-8-11 3-23 0 10 6 9l5-21q18 20 11 35",
			fill: W.rust,
			stroke: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "m31 135 5-13 6 13",
			fill: W.ochre,
			stroke: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M21 54V29h23v28m-25-27h27M27 24q-7-9 0-16m12 14q7-9 0-18",
			fill: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "m10 151 46-1 9 8-62 1Z",
			fill: W.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "M83 85V34m137 50V34M77 38l64-24 85 22",
			fill: "none",
			strokeWidth: "3"
		}),
		/* @__PURE__ */ r("path", {
			d: "m78 36 64-21 83 19 8 30H70Z",
			fill: W.cream
		}),
		/* @__PURE__ */ r("path", {
			d: "m91 32 12-4-7 36H78Zm32-11 11-4 2 47h-20Zm29-3 12 3 11 43h-20Zm31 7 12 3 24 36h-21Z",
			fill: W.rose,
			stroke: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M70 64q8 18 18 0 10 19 21 0 10 18 21 0 10 18 21 0 10 18 21 0 10 18 21 0 10 19 21 0 11 17 19 0",
			fill: W.cream
		}),
		/* @__PURE__ */ r("path", {
			d: "M126 104q-10-16-7-28 4-8 8 1l10 24m5-3q-3-27 4-27 9 0 4 31",
			fill: W.cream
		}),
		/* @__PURE__ */ r("path", {
			d: "m124 82 6 18m14-21 1 20",
			stroke: W.rose,
			fill: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M126 99q16-8 29 4l8 12-10 11q-17 8-29-7-8-7 2-20Z",
			fill: W.cream
		}),
		/* @__PURE__ */ r("path", {
			d: "M132 111h1m17-2h1m-9 7 3 1-2 3m-16-3-11-1m15 6-12 3",
			fill: "none",
			strokeLinecap: "round",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ r("path", {
			d: "M128 127q13 7 24-3l15 33-48 2Z",
			fill: W.blue
		}),
		/* @__PURE__ */ r("path", {
			d: "m135 129 4 6 7-9 9 30h-30Z",
			fill: W.cream
		}),
		/* @__PURE__ */ r("path", {
			d: "m125 135-19 5 1 9 26-5m22-11 22-13 5 7-20 19",
			fill: W.cream
		}),
		/* @__PURE__ */ r("path", {
			d: "M177 122q-7-9-1-12 4 1 5 7m-5 9 10-2",
			fill: W.cream
		}),
		/* @__PURE__ */ r(G, {
			x: 186,
			y: 113,
			turn: -12
		}),
		/* @__PURE__ */ r("path", {
			d: "M78 152h145v11H78Zm7 11v25m128-25v25m-131-2h135",
			fill: W.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "M84 164h133v22H84Z",
			fill: W.sage
		}),
		/* @__PURE__ */ r("path", {
			d: "M91 168v13m6-13v13m98-13v13m6-13v13m6-13v13",
			stroke: W.moss
		}),
		/* @__PURE__ */ r("path", {
			d: "M89 147q23-12 44 0m30 1q26-11 52 0",
			fill: "none"
		}),
		/* @__PURE__ */ r(G, {
			x: 108,
			y: 143
		}),
		/* @__PURE__ */ r(G, {
			x: 97,
			y: 132,
			turn: 9
		}),
		/* @__PURE__ */ r(G, {
			x: 122,
			y: 134,
			turn: -15
		}),
		/* @__PURE__ */ r("path", {
			d: "M162 151v-13q11-9 20 0v13m6 0v-11q10-10 19 0v11",
			fill: W.ochre
		}),
		/* @__PURE__ */ r("path", {
			d: "m165 140 5 3 5-4m17 3 4 3 6-4M158 152h55",
			fill: "none"
		}),
		/* @__PURE__ */ r("ellipse", {
			cx: "146",
			cy: "149",
			rx: "7",
			ry: "3",
			fill: W.ochre
		}),
		/* @__PURE__ */ r("path", {
			d: "m140 146 11-1m-4-4 2 1",
			fill: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M65 181v-15h11v17m-14-5h16m142-5 9-15 8 15m-6-1v15M3 173l12-3m5 9 7-2m28 4 8 1",
			fill: "none"
		}),
		/* @__PURE__ */ i("g", {
			fill: "none",
			strokeWidth: ".75",
			children: [
				/* @__PURE__ */ r("path", { d: "M8 100h9m-9 11h7m-7 12h6m36-21h13m-7 12h7m-6 12h6M12 83l7 2m-1-14 6 5m12-14v6m13 2-4 6m13 3-6 4" }),
				/* @__PURE__ */ r("path", { d: "M22 142h30m-24 3h17M26 38h14m-14 6h14m-14 6h14m-8-20v8m3 6v6m-6-12v6" }),
				/* @__PURE__ */ r("path", {
					d: "m76 59 7-18m6 17 5-18m33 18 1-29m34 29-5-31m45 30-12-24M81 66q3 5 5 0m14 0q4 6 7 0m14 0q4 6 7 0m16 0q4 6 7 0m14 0q4 6 7 0m14 0q4 6 7 0m15 0q4 6 7 0",
					opacity: ".55"
				}),
				/* @__PURE__ */ r("path", { d: "m126 101 4-1m-5 4 4-1m22-2 3 2m-20 18 4 1m-3 2 4 1m-5 12-4 14m18-13 4 12m-22 3 22-1m-45-13 3 4m-1-5 3 4m62-20 2 3m1-5 2 3" }),
				/* @__PURE__ */ r("path", {
					d: "m87 155 33 1m28 0 59-1m-102 10v18m22-17v18m49-18v18m5-18v18m-43-5h21m-20-5h18",
					opacity: ".55"
				}),
				/* @__PURE__ */ r("path", { d: "M102 126q4-4 8-2m8 10 3-4m-27 7 4-5m67 12h14m13 2h12m-32-12 1 4m23-4v5" })
			]
		})
	] });
}
function Ke() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r("path", {
			d: "M0 0h240v188H0Z",
			fill: W.dark,
			stroke: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M-8 26Q59-29 126 4t126 39v149H-8Z",
			fill: W.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "M13 137V87Q9 26 91 24t130 67v47Z",
			fill: W.ink
		}),
		/* @__PURE__ */ r("path", {
			d: "M19 138V88Q15 33 94 31t119 59v48Z",
			fill: "#6c7459",
			stroke: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M0 0q31 26 72 20m-43-20q22 10 30 32m160-32q-24 31-10 61m-33-61q-5 18-25 26",
			fill: "none",
			stroke: W.ink,
			strokeWidth: "3"
		}),
		/* @__PURE__ */ r("path", {
			d: "m17 11 9 3m12 10 9 3m149-18-3 8m13 17 4 7M5 153q72-30 142-9t93 5v39H0Z",
			fill: "#a08e66"
		}),
		/* @__PURE__ */ r("path", {
			d: "M29 132V76l40-3v56Zm3-43 34-2m-33 14 33-1m-33 15 33-1",
			fill: W.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "m39 84 8-2m6 12 8-1m-18 13 14-1m-8 14 11-1",
			fill: "none",
			stroke: W.paper
		}),
		/* @__PURE__ */ r("path", {
			d: "M87 39v23m-7 0h14l3 24H77Zm3 1 2-7h6l2 7",
			fill: W.ochre
		}),
		/* @__PURE__ */ r("path", {
			d: "m82 68 7-1 3 15-11 1Z",
			fill: W.cream
		}),
		/* @__PURE__ */ r("path", {
			d: "M105 68q-3-24 4-25 7 3 4 25m5 1q4-25 10-22 7 3-1 27",
			fill: W.paper
		}),
		/* @__PURE__ */ r("path", {
			d: "M105 70q14-10 24 1l8 14-10 12-22-4q-10-10 0-23Z",
			fill: W.cream
		}),
		/* @__PURE__ */ r("path", {
			d: "M108 81h1m14 1h1m-9 8 4 1m-15-4-12 2m31 0 11 5",
			fill: "none",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ r("path", {
			d: "m105 95 23 1 10 37-43-1Z",
			fill: W.blue
		}),
		/* @__PURE__ */ r("path", {
			d: "m109 99 8 10 7-10m-6 10 3 19",
			fill: "none",
			stroke: W.paper
		}),
		/* @__PURE__ */ r("path", {
			d: "m103 108-25 21 6 6 27-15m19-14 27 15-4 7-28-9",
			fill: W.cream
		}),
		/* @__PURE__ */ r("path", {
			d: "M174 115q-2-13 1-24l7 7 11-2 7-10 1 24-10 12Z",
			fill: W.rust
		}),
		/* @__PURE__ */ r("path", {
			d: "m178 105 6 3 5-1 6-5-3 12-6 4Z",
			fill: W.cream
		}),
		/* @__PURE__ */ r("path", {
			d: "m180 104 1 1m12-3 1 1m-8 10 3-1",
			fill: "none",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ r("path", {
			d: "m176 117 19 2 12 42-40 2Z",
			fill: W.sage
		}),
		/* @__PURE__ */ r("path", {
			d: "m181 120 5 12 7-11m-7 11-3 21m-6-19-20 5-2-8 17-8",
			fill: W.paper
		}),
		/* @__PURE__ */ r("path", {
			d: "m144 121 16-9 10 20-16 9Z",
			fill: W.cream
		}),
		/* @__PURE__ */ r("path", {
			d: "m151 121 7-4m-4 9 7-4",
			fill: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "m66 135 44-17 63 16-47 25Z",
			fill: W.clay
		}),
		/* @__PURE__ */ r("path", {
			d: "m66 135 60 17 47-18v7l-47 24-60-22Zm9 9-2 37m86-34 6 34m-42-19-1 26",
			fill: W.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "m81 135 32-12 43 11-32 15Z",
			fill: W.paper
		}),
		/* @__PURE__ */ r("path", {
			d: "m90 135 12-1 5-6 7 8 12-4 10 5 13-2m-44-2 9 9m6-15 1 6m8 2 6 6",
			fill: "none",
			stroke: W.moss
		}),
		/* @__PURE__ */ r("circle", {
			cx: "115",
			cy: "136",
			r: "2.8",
			fill: W.rust
		}),
		/* @__PURE__ */ r("circle", {
			cx: "132",
			cy: "137",
			r: "2.3",
			fill: W.blue
		}),
		/* @__PURE__ */ r("path", {
			d: "m145 165 9-11 6 3-5 13m-124-19 20-4 10 31-21 5Zm2 4 19-3m-15 9 17-3m-14 9 15-3",
			fill: W.paper
		}),
		/* @__PURE__ */ r("path", {
			d: "M207 73v-9m-6 2 6-7 6 7M205 125l18-10m-19 16 21-12m-18 17 18-10M9 92l8-7m-8 16 8-7m-8 16 8-7",
			fill: "none",
			stroke: W.ochre
		}),
		/* @__PURE__ */ r("path", {
			d: "m15 171 10 1m43 7 12-2m93 4 15 1m21-14 18-2",
			fill: "none"
		}),
		/* @__PURE__ */ i("g", {
			fill: "none",
			strokeWidth: ".75",
			children: [
				/* @__PURE__ */ r("path", {
					d: "M22 78q3-31 44-40m-43 46q3-28 19-35m157 18q7 6 10 16M10 55l-7 8m12-4-7 8m194-47 6 6m-10-1 6 6",
					opacity: ".7"
				}),
				/* @__PURE__ */ r("path", {
					d: "M33 79v8m6-9v8m5-8v8m7-9v8m5-8v8m6-8v8M35 92v8m6-8v8m16-9v8m5-8v8m-29 6v8m6-8v8m6-8v8m7-8v8m10-8v8",
					stroke: W.ochre
				}),
				/* @__PURE__ */ r("path", { d: "m107 72 3-1m15 3 3 3m-17 16 3 1m-6 1 3 1m-9 25-3 7m30-6 3 7M177 104l3 3m13-3 3-3m-18 11 4 3m9-1 3-3m-20 22-3 15m22-14 6 14" }),
				/* @__PURE__ */ r("path", { d: "m90 136 11 4 6-2m15-3 6 2 7-1m-21-9 3 3m3 11 4 2m-44-1 37 12m-37-7 35 11m-39-10-1 27m84-20 3 19" }),
				/* @__PURE__ */ r("path", { d: "m43 156 5-1m-3 4 5-1m1 6 5-1M83 65h5m-4 4v11m-4 6h14m-4-1v3m-13 0h17" }),
				/* @__PURE__ */ r("path", {
					d: "m14 150 8 1m-10 4h6m186-5 12-2m-12 6 18-3m-16 7 16-3m-20-9 4-2",
					opacity: ".6"
				})
			]
		})
	] });
}
function qe() {
	return /* @__PURE__ */ i(n, { children: [
		/* @__PURE__ */ r("path", {
			d: "M0 0h240v188H0Z",
			fill: W.paper,
			stroke: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M0 28q30 18 53-6t61-4 65 6 61-12v176H0Z",
			fill: "#bec29b",
			stroke: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M24-5 10 149m35-155 10 151M203-5l-9 143m25-147 14 151",
			fill: "none",
			stroke: W.moss,
			strokeWidth: "8"
		}),
		/* @__PURE__ */ r("path", {
			d: "m31 5-6 19m20 16-12 13m174-34-9 13m17 25 9 10",
			fill: "none",
			stroke: W.paper
		}),
		/* @__PURE__ */ r("path", {
			d: "M0 165 68 143l51 4 45-31 76 15v57H0Z",
			fill: W.ochre,
			stroke: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "m111 188 46-45 15 1-37 44",
			fill: W.paper,
			stroke: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "M8-5q18 21 11 62t14 56l30 37-13 14-32-25q-7 25-18 29V-5Z",
			fill: W.bark
		}),
		/* @__PURE__ */ r("path", {
			d: "M6 10q13 20 5 46t11 54l17 16M2 119q7 10 19 13m-9-96-7-6m16 74-12-5m19 35-13-1",
			fill: "none",
			stroke: W.ink
		}),
		/* @__PURE__ */ r("path", {
			d: "M0 157q18-19 31-3 7-25 28-12 15-23 33-8 16-8 24 8L75 188H0Z",
			fill: W.moss
		}),
		/* @__PURE__ */ r("path", {
			d: "M75 137q-7-24 5-41l-6-26 23 14 14-3 15-17 1 31-15 35Z",
			fill: W.rust
		}),
		/* @__PURE__ */ r("path", {
			d: "m79 78 6 13 8-5m26-10-4 14 9-2",
			fill: W.ink,
			stroke: "none"
		}),
		/* @__PURE__ */ r("path", {
			d: "m81 105 15 3 7 16 11-24 10-4q-5 28-20 33-14-5-23-24Z",
			fill: W.cream
		}),
		/* @__PURE__ */ r("path", {
			d: "m88 101 6 2m17-4 6-3m-17 20 7-2-2 5Z",
			fill: W.ink,
			strokeWidth: "2"
		}),
		/* @__PURE__ */ r("path", {
			d: "m88 129 19 2 24 29-39 21-20-31Z",
			fill: W.blue
		}),
		/* @__PURE__ */ r("path", {
			d: "m89 134 8 17 21-4m-17-13-3 17-16 16",
			fill: "none",
			stroke: W.paper,
			strokeWidth: "2"
		}),
		/* @__PURE__ */ r("path", {
			d: "m107 136 26-28 7 5-22 31m-38 1-15-11-5 7 16 16",
			fill: W.rust
		}),
		/* @__PURE__ */ r("path", {
			d: "m131 109 17-49 5 2-13 52m4-53 12-20 4 24Z",
			fill: W.paper
		}),
		/* @__PURE__ */ r("path", {
			d: "m145 64 9 2m-21 41 10 3",
			fill: "none",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ r("path", {
			d: "M84 165q-13 3-18 17l17 6 17-14m22-17 22 16-5 13-15-9-17-7",
			fill: W.rust
		}),
		/* @__PURE__ */ r("path", {
			d: "m66 182 17 6m46-8 9 5",
			fill: "none",
			strokeWidth: "4"
		}),
		/* @__PURE__ */ r("path", {
			d: "M81 160q-37-16-37 11 4 15 29 7",
			fill: W.rust
		}),
		/* @__PURE__ */ r("path", {
			d: "M48 163q-7 15 12 17l1-17Z",
			fill: W.cream
		}),
		/* @__PURE__ */ r("path", {
			d: "M173 114q-6-18-3-32l12 10 14-1 13-11-3 28-17 16Z",
			fill: W.rust
		}),
		/* @__PURE__ */ r("path", {
			d: "m172 99 13 6 17-8-10 20-7 2Z",
			fill: W.cream
		}),
		/* @__PURE__ */ r("path", {
			d: "m177 99 3 2m15-2 4-2m-15 13 6-1",
			fill: "none",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ r("path", {
			d: "m174 118 19 5 12 25-39 4Z",
			fill: W.sage
		}),
		/* @__PURE__ */ r("path", {
			d: "m175 126-20 9-5-7 20-13m29 13 13 3-1 8-16-2",
			fill: W.rust
		}),
		/* @__PURE__ */ r("path", {
			d: "m154 131 57-30m-9-9q24 13 15 29m-15-29 9 9 6 20",
			fill: "none",
			strokeWidth: "2"
		}),
		/* @__PURE__ */ r("path", {
			d: "M211 187q-23-22-10-43 16-15 30 3 0-18 18-15v56Z",
			fill: W.dark
		}),
		/* @__PURE__ */ r("path", {
			d: "m202 178 7-25m3 23 9-19m-9 26 19-9M10 178l8-13m14 22 8-17m21-21 7-8M182 46l-9 4m12 3-11 5m-16 28 4-8",
			fill: "none",
			stroke: W.sage
		}),
		/* @__PURE__ */ r("path", {
			d: "m67 48 12 12m-2-16 7 13m-3 12 6 4",
			fill: "none",
			stroke: W.ink
		}),
		/* @__PURE__ */ i("g", {
			fill: "none",
			strokeWidth: ".75",
			children: [
				/* @__PURE__ */ r("path", { d: "m82 92 5 4m-6 1 4 3m28-7 5-3m-4 7 6-3m-29 19 4 5m-2-6 4 5m13-7 4-5m-3 9 5-5m-23 18 4 2m-1 2 5 2" }),
				/* @__PURE__ */ r("path", { d: "m78 147 3 5m-1-7 3 5m47-39 4 3m-2-5 4 3m-7 51 9 9m-7-12 9 8m-58 13 7-7m-33-9 5 3m-7 0 6 3" }),
				/* @__PURE__ */ r("path", { d: "m90 143 6 12 11-3m-18 3-5 8m16 9 13-8m59-41 5 5m-7-3 4 5m19 11 4 6m-26-10-3 10M150 63l-13 39m18-49 2 8" }),
				/* @__PURE__ */ r("path", { d: "m14 75-4-8m8 11-3-9m6 32-6-11m3 17-6-11m7 22 5 3M22 135l16 18m-16-12 12 13m-9-7 5 7" }),
				/* @__PURE__ */ r("path", {
					d: "m11 160 4-8m2 10 5-8m24-4 4-8m5 10 5-9m7-3 6 4m-3-8 5 4m131 7 4-6m4 10 3-7m8 6 4-5m-13 23 6-7m-8 14 8-8",
					stroke: W.sage
				}),
				/* @__PURE__ */ r("path", { d: "m162 158 7-3m-22 24 5-3m-11 8 7-3m-10-16 5 1m-6-5 5 1" })
			]
		})
	] });
}
function Je({ card: e }) {
	let t = e.id === "bakeSale" ? /* @__PURE__ */ r(Ge, {}) : e.id === "commandWarren" ? /* @__PURE__ */ r(Ke, {}) : e.kind === "ambush" && e.suit === "fox" ? /* @__PURE__ */ r(qe, {}) : /* @__PURE__ */ r(We, { card: e });
	return t && /* @__PURE__ */ r("svg", {
		className: "root-card-art root-card-art-detailed",
		viewBox: "0 0 240 188",
		"aria-hidden": "true",
		children: /* @__PURE__ */ r("g", {
			stroke: W.ink,
			strokeWidth: "1.4",
			strokeLinecap: "round",
			strokeLinejoin: "round",
			children: t
		})
	});
}
//#endregion
//#region src/games/root/card-print.tsx
var Ye = {
	armorers: {
		timing: "cardInBattle",
		text: "armorersText",
		brief: "cardArmorersBrief",
		symbol: "shield"
	},
	sappers: {
		timing: "cardAsDefender",
		text: "cardSappersText",
		brief: "cardExtraHit",
		symbol: "battle"
	},
	brutalTactics: {
		timing: "cardAsAttacker",
		text: "cardBrutalTacticsText",
		brief: "cardBrutalTacticsBrief",
		symbol: "battle"
	},
	scoutingParty: {
		timing: "cardAsAttacker",
		text: "cardScoutingPartyText",
		brief: "cardScoutingPartyBrief",
		symbol: "shield"
	},
	standAndDeliver: {
		timing: "cardOnceBirdsong",
		text: "cardStandAndDeliverText",
		brief: "cardStandAndDeliverBrief",
		symbol: "cards"
	},
	commandWarren: {
		timing: "cardStartDaylight",
		text: "cardCommandWarrenText",
		brief: "cardCommandWarrenBrief",
		symbol: "battle"
	},
	betterBurrowBank: {
		timing: "cardStartBirdsong",
		text: "cardBetterBurrowBankText",
		brief: "cardBetterBurrowBankBrief",
		symbol: "cards"
	},
	cobbler: {
		timing: "cardStartEvening",
		text: "cardCobblerText",
		brief: "cardCobblerBrief",
		symbol: "move"
	},
	codebreakers: {
		timing: "cardOnceDaylight",
		text: "cardInspectHandText",
		brief: "cardInspectHand",
		symbol: "cards"
	},
	taxCollector: {
		timing: "cardOnceDaylight",
		text: "cardTaxCollectorText",
		brief: "cardTaxCollectorBrief",
		symbol: "cards"
	},
	royalClaim: {
		timing: "cardInBirdsong",
		text: "cardRoyalClaimText",
		brief: "cardRoyalClaimBrief",
		symbol: "crown"
	}
};
function K(e, t) {
	let n = e.match(/[a-zA-Z0-9’'+-]+|\s+|./gu) ?? [], r = (e) => [...e].reduce((e, t) => e + (t.codePointAt(0) > 255 ? 2 : /[ilI.,:;!' ]/.test(t) ? .55 : 1), 0), i = [], a = "";
	for (let e of n) a && r(a + e) > t && !/^[，。；：！？、,.!?;:]$/u.test(e) && (i.push(a.trim()), a = ""), a += a ? e : e.trimStart();
	return a.trim() && i.push(a.trim()), i;
}
var q = {
	ink: "#38382e",
	paper: "#f4ebd5",
	edge: "#9c815b",
	soft: "#d7c39a",
	fox: "#d38a65",
	rabbit: "#d2b763",
	mouse: "#bc8d87",
	bird: "#87afb5"
};
function Xe({ symbol: e }) {
	return /* @__PURE__ */ r("svg", {
		x: "25",
		y: "337",
		width: "48",
		height: "48",
		viewBox: "0 0 40 40",
		"aria-hidden": "true",
		children: /* @__PURE__ */ r("path", {
			d: {
				cards: "M6 9h18v24H6Zm6-5h18v24m4-18 5 4-5 4",
				battle: "m7 5 9 5 15 20-5 5L11 15Zm16 0 10 2-3 11-8 7-5-5 8-10ZM4 22l13 14m7-14 12 14",
				move: "M6 12h21l-6-6m6 6-6 6M34 28H13l6-6m-6 6 6 6",
				shield: "m7 6 13-3 13 3v13Q31 30 20 37 9 30 7 19Zm6 13 5 5 10-12",
				crown: "m4 12 9 7 7-13 7 13 9-7-5 20H9ZM10 27h20"
			}[e],
			fill: "none",
			stroke: q.ink,
			strokeWidth: "1.6",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})
	});
}
function Ze({ card: e, t, name: a, detail: o = !1, art: s, itemIcon: c, suitIcon: l }) {
	let u = T(e), d = o ? 460 : 420, f = q[e.suit], p = e.kind === "dominance" ? t("cardSuitDominance", { suit: t(e.suit) }) : a, m = p.codePointAt(0) < 128, h = K(p, m ? 13.5 : 13), g = h.length > 1 ? 20 : o || m ? 25 : 32, _ = u?.effect ? Ye[u.effect] : void 0, v = _ ? t(_.text) : u?.favor ? t("favorText") : e.kind === "ambush" ? t("cardAmbushText") : e.kind === "dominance" ? t(e.suit === "bird" ? "cardBirdDominanceText" : "cardSuitDominanceText", { suit: t(e.suit) }) : e.id === "vizier" ? t("cardVizierText") : "", y = K(v, m ? e.kind === "dominance" ? 32 : e.id === "vizier" ? 30 : 26 : 30), b = d - 24, x = _ ? K(t(_.brief), m ? 20 : 14) : [], S = (e, t, n, i, a = q.ink) => /* @__PURE__ */ r("svg", {
		x: t,
		y: n,
		width: i,
		height: i,
		viewBox: "0 0 32 32",
		style: { color: a },
		"aria-hidden": "true",
		children: l(e)
	});
	return /* @__PURE__ */ r("svg", {
		className: "root-card-print",
		viewBox: `0 0 300 ${d}`,
		xmlns: "http://www.w3.org/2000/svg",
		role: "img",
		"aria-label": `${p} · ${t(e.suit)}${o && v ? ` · ${v}` : ""}`,
		children: /* @__PURE__ */ i("g", {
			fill: q.ink,
			strokeLinejoin: "round",
			fontFamily: "'Microsoft YaHei', 'Segoe UI', sans-serif",
			children: [
				/* @__PURE__ */ r("path", {
					className: "root-print-edge",
					d: `M7 6 77 8 147 5 225 7 293 5 291 76 294 148 291 225 294 303 292 ${d - 8} 219 ${d - 6} 143 ${d - 8} 69 ${d - 5} 6 ${d - 7} 8 331 5 244 8 157 5 80Z`,
					fill: q.paper,
					stroke: q.ink,
					strokeWidth: "2.5"
				}),
				/* @__PURE__ */ r("path", {
					d: `M13 14 85 16 157 12 223 15 285 13M285 291l1 ${d - 311}-74 4-72-2-72 3-54-2V294`,
					fill: "none",
					stroke: q.edge,
					strokeWidth: ".8"
				}),
				/* @__PURE__ */ r("path", {
					d: "M11 18 93 17 160 20 229 16 288 19 285 68 216 65 148 68 78 65 12 68Z",
					fill: f,
					stroke: q.ink,
					strokeWidth: "1.3"
				}),
				/* @__PURE__ */ r("path", {
					d: "m74 23 88 2 63-3 52 3M77 60l63 2 70-2 65 1",
					fill: "none",
					stroke: q.paper,
					strokeWidth: "1",
					opacity: ".65"
				}),
				/* @__PURE__ */ r("path", {
					d: "M12 19 31 10l30 5 8 25-11 26-31 3L11 51Z",
					fill: q.paper,
					stroke: q.ink,
					strokeWidth: "2"
				}),
				/* @__PURE__ */ r("circle", {
					cx: "39",
					cy: "40",
					r: "22",
					fill: q.ink
				}),
				S(e.suit, 22, 23, 34, q.paper),
				/* @__PURE__ */ r("text", {
					x: "178",
					y: h.length > 1 ? 35 : 51,
					textAnchor: "middle",
					fontFamily: "Georgia, 'Microsoft YaHei', serif",
					fontSize: g,
					fontWeight: "700",
					children: h.map((e, t) => /* @__PURE__ */ r("tspan", {
						x: "178",
						dy: t ? g : 0,
						children: e
					}, t))
				}),
				/* @__PURE__ */ r("svg", {
					x: "14",
					y: "76",
					width: "272",
					height: "213.07",
					viewBox: "0 0 240 188",
					"aria-hidden": "true",
					children: s
				}),
				/* @__PURE__ */ r("path", {
					d: "m14 76 81 1 98-2 93 2v211l-94-2-86 3-92-2Z",
					fill: "none",
					stroke: q.ink,
					strokeWidth: "1.5"
				}),
				!!u?.cost.length && /* @__PURE__ */ i("g", {
					"aria-label": t("cardCraftCost"),
					children: [/* @__PURE__ */ r("path", {
						d: `M17 83h38l-2 ${u.cost.length * 35 + 7}-17 7-18-7Z`,
						fill: q.paper,
						stroke: q.ink,
						strokeWidth: "1.2"
					}), u.cost.map((e, t) => /* @__PURE__ */ i("g", { children: [/* @__PURE__ */ r("path", {
						d: `m20 ${88 + t * 35} 16-2 14 2-1 27-14 2-15-3Z`,
						fill: e === "any" ? q.soft : q[e],
						stroke: q.edge,
						strokeWidth: ".7"
					}), e === "any" ? /* @__PURE__ */ r("path", {
						d: `m35 ${91 + t * 35} 9 11-9 11-9-11Z`,
						fill: "none",
						stroke: q.ink,
						strokeWidth: "1.6"
					}) : S(e, 23, 90 + t * 35, 25)] }, t))]
				}),
				/* @__PURE__ */ r("path", {
					d: `M14 285q39 4 72 0t72 0 68 0l60 1v${d - 300}l-70 3-72-2-69 3-61-2Z`,
					fill: q.paper
				}),
				/* @__PURE__ */ r("path", {
					d: "M15 287q43 4 74 0t69 0 68 0l59 1",
					fill: "none",
					stroke: q.ink,
					strokeWidth: "1.2"
				}),
				u?.item && /* @__PURE__ */ i(n, { children: [
					/* @__PURE__ */ r("text", {
						x: "24",
						y: "312",
						fontSize: o ? 17 : 23,
						fontWeight: "700",
						fill: q.edge,
						children: t("cardCraftedReward")
					}),
					/* @__PURE__ */ r("path", {
						d: "m25 332 16-10 27 4 10 26-14 26-29-2-15-21Z",
						fill: f,
						stroke: q.ink,
						strokeWidth: "1.3"
					}),
					/* @__PURE__ */ r("svg", {
						x: "30",
						y: "332",
						width: "37",
						height: "37",
						viewBox: "0 0 32 32",
						children: c(u.item)
					}),
					/* @__PURE__ */ r("text", {
						x: "88",
						y: "357",
						fontSize: m ? t(u.item).length > 7 ? 21 : 26 : o ? 27 : 32,
						fontWeight: "700",
						children: t(u.item)
					}),
					/* @__PURE__ */ i("g", {
						transform: "translate(247 350)",
						children: [
							/* @__PURE__ */ r("circle", {
								r: "29",
								fill: q.ink
							}),
							/* @__PURE__ */ r("circle", {
								r: "25",
								fill: q.paper,
								stroke: f,
								strokeWidth: "3"
							}),
							/* @__PURE__ */ r("path", {
								d: "m-31 17-5-15m5 10-8-7m7 1-6-8m7 1-5-9m3 4-1-11m34 35 5-15m-5 10 8-7m-7 1 6-8m-7 1 5-9m-3 4 1-11",
								fill: "none",
								stroke: q.edge,
								strokeWidth: "1.5"
							}),
							/* @__PURE__ */ r("text", {
								y: "13",
								textAnchor: "middle",
								fontSize: "39",
								fontWeight: "800",
								children: u?.vp
							})
						]
					}),
					/* @__PURE__ */ r("text", {
						x: "247",
						y: "392",
						textAnchor: "middle",
						fontSize: "16",
						children: t("cardVictoryPoints")
					})
				] }),
				_ && /* @__PURE__ */ i(n, { children: [
					/* @__PURE__ */ r("path", {
						d: "m24 300 11-3 230 2 11 8-8 13-235-1Z",
						fill: f,
						opacity: ".55"
					}),
					/* @__PURE__ */ r("text", {
						x: "150",
						y: "313",
						textAnchor: "middle",
						fontSize: o ? 16 : m ? 19 : 23,
						fontWeight: "700",
						children: t(_.timing)
					}),
					o ? /* @__PURE__ */ r("text", {
						x: "25",
						y: "346",
						fontSize: "17",
						children: y.map((e, t) => /* @__PURE__ */ r("tspan", {
							x: "25",
							dy: t ? 23 : 0,
							children: e
						}, t))
					}) : /* @__PURE__ */ i(n, { children: [/* @__PURE__ */ r(Xe, { symbol: _.symbol }), /* @__PURE__ */ r("text", {
						x: "88",
						y: x.length > 1 ? 351 : 365,
						fontSize: m ? 20 : 25,
						fontWeight: "700",
						children: x.map((e, t) => /* @__PURE__ */ r("tspan", {
							x: "88",
							dy: t ? 27 : 0,
							children: e
						}, t))
					})] })
				] }),
				u?.favor && /* @__PURE__ */ i(n, { children: [
					/* @__PURE__ */ r("path", {
						d: "m24 300 11-3 230 2 11 8-8 13-235-1Z",
						fill: f,
						opacity: ".55"
					}),
					/* @__PURE__ */ r("text", {
						x: "150",
						y: "313",
						textAnchor: "middle",
						fontSize: o ? 16 : m ? 20 : 23,
						fontWeight: "700",
						children: t("cardWhenCrafted")
					}),
					o ? /* @__PURE__ */ r("text", {
						x: "25",
						y: "347",
						fontSize: "17",
						children: y.map((e, t) => /* @__PURE__ */ r("tspan", {
							x: "25",
							dy: t ? 23 : 0,
							children: e
						}, t))
					}) : /* @__PURE__ */ i(n, { children: [
						S(u.favor, 26, 340, 43),
						/* @__PURE__ */ r("path", {
							d: "m27 339 42 43m0-43-42 43",
							stroke: q.ink,
							strokeWidth: "2"
						}),
						/* @__PURE__ */ r("text", {
							x: "88",
							y: "350",
							fontSize: m ? 20 : 25,
							fontWeight: "700",
							children: K(t("cardFavorBrief"), m ? 20 : 14).map((e, t) => /* @__PURE__ */ r("tspan", {
								x: "88",
								dy: t ? 27 : 0,
								children: e
							}, t))
						})
					] })
				] }),
				e.id === "vizier" && /* @__PURE__ */ i(n, { children: [
					/* @__PURE__ */ r("path", {
						d: "m24 300 11-3 230 2 11 8-8 13-235-1Z",
						fill: f,
						opacity: ".55"
					}),
					/* @__PURE__ */ r("text", {
						x: "150",
						y: "313",
						textAnchor: "middle",
						fontSize: o ? 16 : 23,
						fontWeight: "700",
						children: t("decree")
					}),
					o ? /* @__PURE__ */ r("text", {
						x: "25",
						y: "347",
						fontSize: m ? 15.5 : 17,
						children: y.map((e, t) => /* @__PURE__ */ r("tspan", {
							x: "25",
							dy: t ? 21 : 0,
							children: e
						}, t))
					}) : /* @__PURE__ */ i(n, { children: [/* @__PURE__ */ r(Xe, { symbol: "crown" }), /* @__PURE__ */ r("text", {
						x: "88",
						y: "365",
						fontSize: m ? 20 : 25,
						fontWeight: "700",
						children: t("cardVizierBrief")
					})] })
				] }),
				e.kind === "ambush" && /* @__PURE__ */ i(n, { children: [
					/* @__PURE__ */ r("path", {
						d: "m22 300 39-5 18 24-18 27-39-6Z",
						fill: f,
						stroke: q.ink,
						strokeWidth: "1.2"
					}),
					/* @__PURE__ */ r("text", {
						x: "47",
						y: "332",
						textAnchor: "middle",
						fontSize: "39",
						fontWeight: "800",
						children: "2"
					}),
					/* @__PURE__ */ r("text", {
						x: "88",
						y: "327",
						fontSize: m ? 22 : 27,
						fontWeight: "700",
						children: t("cardImmediateHits")
					}),
					o ? /* @__PURE__ */ r("text", {
						x: "25",
						y: "369",
						fontSize: "16",
						children: y.map((e, t) => /* @__PURE__ */ r("tspan", {
							x: "25",
							dy: t ? 21 : 0,
							children: e
						}, t))
					}) : /* @__PURE__ */ r("text", {
						x: "150",
						y: "378",
						textAnchor: "middle",
						fontSize: m ? 19 : 23,
						children: t("cardAmbushFoil")
					})
				] }),
				e.kind === "dominance" && /* @__PURE__ */ i(n, { children: [
					/* @__PURE__ */ r("path", {
						d: "m23 299 84-2 17 9 150-2-5 17-240-1Z",
						fill: f,
						opacity: ".55"
					}),
					/* @__PURE__ */ r("text", {
						x: "150",
						y: "313",
						textAnchor: "middle",
						fontSize: o ? 16 : m ? 17 : 21,
						fontWeight: "700",
						children: t("cardDominanceActivate")
					}),
					o ? /* @__PURE__ */ r("text", {
						x: "25",
						y: "338",
						fontSize: m ? 14.5 : 15.5,
						children: y.map((e, t) => /* @__PURE__ */ r("tspan", {
							x: "25",
							dy: t ? m ? 17 : 19 : 0,
							children: e
						}, t))
					}) : /* @__PURE__ */ i(n, { children: [
						/* @__PURE__ */ r("path", {
							d: "M26 342h39v39H26Z",
							fill: "none",
							stroke: q.ink,
							strokeWidth: "1.2"
						}),
						e.suit === "bird" ? /* @__PURE__ */ i(n, { children: [/* @__PURE__ */ r("path", {
							d: "m31 376 29-29m-29 0 29 29",
							fill: "none",
							stroke: q.edge,
							strokeWidth: "1.4"
						}), /* @__PURE__ */ r("path", {
							d: "M28 344h10v10H28Zm25 25h10v10H53Z",
							fill: f,
							stroke: q.ink
						})] }) : /* @__PURE__ */ i(n, { children: [
							S(e.suit, 28, 343, 35),
							/* @__PURE__ */ r("circle", {
								cx: "58",
								cy: "377",
								r: "13",
								fill: q.ink
							}),
							/* @__PURE__ */ r("text", {
								x: "58",
								y: "384",
								textAnchor: "middle",
								fontSize: "20",
								fontWeight: "700",
								fill: q.paper,
								children: "3"
							})
						] }),
						/* @__PURE__ */ r("text", {
							x: "87",
							y: "364",
							fontSize: m ? 17 : 26,
							fontWeight: "700",
							children: t(e.suit === "bird" ? "cardOppositeCorners" : "cardThreeClearings")
						})
					] })
				] }),
				/* @__PURE__ */ r("path", {
					d: `m25 ${b - 7} 43 1m164-1 42 1m-250-7 7 5-7 5m253-10-7 5 7 5`,
					fill: "none",
					stroke: q.edge,
					strokeWidth: "1"
				}),
				/* @__PURE__ */ r("text", {
					x: "150",
					y: b,
					textAnchor: "middle",
					fontSize: "13",
					letterSpacing: m ? 1.4 : 4,
					fill: q.edge,
					children: t(u?.favor ? "favor" : e.id === "vizier" ? "vizier" : e.kind)
				}),
				/* @__PURE__ */ r("path", {
					d: `m15 18 4 4m267-5-4 5M15 ${d - 17}l4-5m266 6-4-5`,
					fill: "none",
					stroke: q.edge,
					strokeWidth: "1.3"
				})
			]
		})
	});
}
//#endregion
//#region src/games/root/art-assets.tsx
var J = {
	ink: "#3f4538",
	paper: "#eee5ce",
	cream: "#faf4e5",
	bark: "#826b4e",
	soil: "#8d8065",
	grass: "#a4ae81",
	clearing: "#dfd1a6",
	clearingEdge: "#b7b08b",
	path: "#e6d9b8",
	river: "#a2c3c6",
	riverEdge: "#dedcc2",
	pine: "#779177",
	pineLight: "#a0ad80",
	orange: "#cba56a",
	gold: "#c6a65e",
	stone: "#a7ac97",
	pineDark: "#5c7b68",
	leaf: "#b1b68a",
	sand: "#e9dcb9",
	clay: "#b5a07a",
	waterDeep: "#7da6ae",
	snow: "#e9ebde",
	moss: "#9caa80",
	litter: "#acb58c",
	marquise: "#dc8743",
	eyrie: "#508ba4",
	alliance: "#69974c",
	vagabond: "#9b958a",
	cult: "#d7be4e",
	riverfolk: "#66b6b1",
	duchy: "#cfb18a",
	corvid: "#8a6b9d"
}, Qe = {
	fox: "M5 4 11 9Q16 6 21 9L27 4 25 19 16 28 7 19Z",
	rabbit: "M11 16C3 1 11-3 14 13L18 13C21-3 29 1 21 16Q27 19 23 25Q16 31 9 25Q5 20 11 16Z",
	mouse: "M9 17C-1 17 1 4 9 8Q12 9 12 14Q16 12 20 14Q20 9 23 8C31 4 33 17 23 17Q29 28 16 29Q3 28 9 17Z",
	bird: "M3 13 12 15 15 4 20 10 28 10 22 16 20 24 10 27 12 20Z"
};
function Y({ suit: e }) {
	return /* @__PURE__ */ i("svg", {
		className: "root-glyph",
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ r("path", {
				d: Qe[e],
				fill: "currentColor"
			}),
			/* @__PURE__ */ r("circle", {
				cx: "12",
				cy: "20",
				r: "1.2",
				fill: J.cream
			}),
			/* @__PURE__ */ r("circle", {
				cx: "20",
				cy: "20",
				r: "1.2",
				fill: J.cream
			})
		]
	});
}
function X({ faction: e }) {
	return e === "alliance" ? /* @__PURE__ */ i("svg", {
		className: "root-glyph",
		viewBox: "0 0 40 40",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ r("path", {
				d: "M5 13C0 0 18 0 15 13L25 13C22 0 40 0 35 13L31 17Q35 31 20 36Q5 31 9 17Z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ r("path", {
				d: "m10 20 10-5 10 5-5 3-5-2-5 2Z",
				fill: Z.cream
			}),
			/* @__PURE__ */ r("path", {
				d: "m18 29 2 2 2-2",
				stroke: Z.cream,
				strokeWidth: "2",
				fill: "none"
			})
		]
	}) : e === "vagabond" ? /* @__PURE__ */ i("svg", {
		className: "root-glyph",
		viewBox: "0 0 40 40",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ r("path", {
				d: "M20 2Q6 7 4 33L20 38 36 33Q34 7 20 2Z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ r("path", {
				d: "M10 17Q20 8 30 17L27 28 20 32 13 28Z",
				fill: Z.cream
			}),
			/* @__PURE__ */ r("path", {
				d: "m11 18 9 4 9-4-2 7-7-1-7 1Z",
				fill: Z.ink
			}),
			/* @__PURE__ */ r("circle", {
				cx: "15",
				cy: "22",
				r: "1.2",
				fill: Z.cream
			}),
			/* @__PURE__ */ r("circle", {
				cx: "25",
				cy: "22",
				r: "1.2",
				fill: Z.cream
			})
		]
	}) : e === "eyrie" ? /* @__PURE__ */ i("svg", {
		className: "root-glyph",
		viewBox: "0 0 40 40",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ r("path", {
				d: "M4 14 17 18 20 5l5 2 3 5 9 2-9 5-1 12-14 5 4-12-10 2Z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ r("path", {
				d: "m19 11 2 10-8 9m5-5-7 6m11-11 4 4",
				fill: "none",
				stroke: Z.cream,
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ r("circle", {
				cx: "25",
				cy: "13",
				r: "1.4",
				fill: Z.cream
			})
		]
	}) : e === "corvid" ? /* @__PURE__ */ i("svg", {
		className: "root-glyph",
		viewBox: "0 0 40 40",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ r("path", {
				d: "M5 35 12 20Q9 6 20 4l7 4 2 7 9 5-13 2-3 15-8-6-9 6Z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ r("path", {
				d: "m14 17 7-3 6 3-4 6-9-1m5 2-7 9",
				fill: "none",
				stroke: Z.cream,
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ r("circle", {
				cx: "24",
				cy: "13",
				r: "1.3",
				fill: Z.cream
			})
		]
	}) : e === "cult" ? /* @__PURE__ */ i("svg", {
		className: "root-glyph",
		viewBox: "0 0 40 40",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ r("path", {
				d: "m10 36-5-8 5-9 6-2 2-11 5-4 3 5-1 6 11 5-7 8-8-2-6 4q-2 6 7 5l9-5-3 9-13 2Z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ r("path", {
				d: "m25 15 6 3-5 3m-7-13 4 3m-7 10 5-2m-9 13 7 3",
				fill: "none",
				stroke: Z.cream,
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ r("circle", {
				cx: "24",
				cy: "12",
				r: "1.4",
				fill: Z.cream
			})
		]
	}) : e === "riverfolk" ? /* @__PURE__ */ i("svg", {
		className: "root-glyph",
		viewBox: "0 0 40 40",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ r("path", {
				d: "M8 13Q2 2 13 5l7 3 7-3q11-2 6 10l-2 12q-5 13-17 7L6 25Z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ r("path", {
				d: "m12 16 3 1m9-1 3-1m-11 9 4-2 5 2-5 5Zm-5-4-7-1m8 6-8 3m23-8 8-1m-9 6 8 3",
				fill: "none",
				stroke: Z.cream,
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ r("path", {
				d: "M12 33q8-5 16-1l-4 5-9-1Z",
				fill: Z.cream
			})
		]
	}) : e === "duchy" ? /* @__PURE__ */ i("svg", {
		className: "root-glyph",
		viewBox: "0 0 40 40",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ r("path", {
				d: "M7 21q-6-12 6-16 12-5 18 10l7 7-8 6q-2 10-15 9L4 31l7-4Z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ r("path", {
				d: "m12 13 5 1m14 4 4 3-5 2m-17 4 6 1m-9 1 5 5m6-9 2 8",
				fill: "none",
				stroke: Z.cream,
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ r("path", {
				d: "m13 5-3-4 8 2 5-3 1 6Z",
				fill: Z.gold
			})
		]
	}) : /* @__PURE__ */ i("svg", {
		className: "root-glyph",
		viewBox: "0 0 40 40",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ r("path", {
			d: "M7 5 17 12 23 12 33 5 31 22Q29 33 20 36Q11 33 9 22Z",
			fill: "currentColor"
		}), /* @__PURE__ */ r("path", {
			d: "M13 20 16 21M24 21 27 20M18 27 22 27 20 29Z",
			fill: "none",
			stroke: J.cream,
			strokeWidth: "2",
			strokeLinecap: "round"
		})]
	});
}
var Z = J;
function Q({ item: e }) {
	return /* @__PURE__ */ r("svg", {
		className: "root-glyph root-item-glyph",
		viewBox: "0 0 32 32",
		"aria-hidden": "true",
		children: /* @__PURE__ */ r("path", {
			d: {
				boot: "M10 4h12v15l8 3v7H7v-8l3-3Z M10 25h17 M14 9h5m-5 5h5",
				sack: "m11 4 5 3 5-3-2 8c11 13 10 18-3 18S2 25 13 12Z M11 12h10m-8 4-2 8",
				sword: "m20 3 6 2-3 13-7 8-3-3 7-8Z M8 19l10 10 M9 28l5-5",
				crossbow: "M6 5q22 0 20 22 M6 5l20 22 M23 4 8 26 M5 24l6 5 M13 15l6 5",
				hammer: "m5 6 17-3 6 9-17 3Z M16 14l-4 15 5 1 5-17",
				tea: "M7 14h17v8q-8 12-17 0Z M24 15q10-2 5 7h-5 M5 28h22 M11 10q-5-4 0-7m7 7q-5-4 0-7",
				coin: "M27 16a11 13 0 1 1-22 0 11 13 0 1 1 22 0Z M16 8v16m4-13q-9-5-9 2t9 5-9 4",
				torch: "m13 17-3 13h7l3-13Z M10 14Q2 8 14 2q-3 7 4 5 14 11-3 12Z"
			}[e],
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2.3",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})
	});
}
function $({ kind: e }) {
	return /* @__PURE__ */ r("svg", {
		className: "root-glyph",
		viewBox: "0 0 40 40",
		"aria-hidden": "true",
		children: /* @__PURE__ */ r("g", {
			stroke: Z.ink,
			strokeWidth: "1.5",
			strokeLinecap: "round",
			strokeLinejoin: "round",
			children: e === "wood" ? /* @__PURE__ */ i(n, { children: [
				/* @__PURE__ */ r("path", {
					d: "m8 27 15-15 10 9-15 15Z",
					fill: Z.bark
				}),
				/* @__PURE__ */ r("circle", {
					cx: "12",
					cy: "30",
					r: "7",
					fill: Z.gold
				}),
				/* @__PURE__ */ r("circle", {
					cx: "12",
					cy: "30",
					r: "3",
					fill: "none",
					stroke: Z.bark
				}),
				/* @__PURE__ */ r("path", {
					d: "m17 25 10-9m-7 12 9-9",
					fill: "none"
				})
			] }) : e === "roost" ? /* @__PURE__ */ i(n, { children: [
				/* @__PURE__ */ r("path", {
					d: "M9 35V18m22 17V18M5 19h30L20 5Z",
					fill: "currentColor"
				}),
				/* @__PURE__ */ r("ellipse", {
					cx: "20",
					cy: "24",
					rx: "9",
					ry: "5",
					fill: Z.bark
				}),
				/* @__PURE__ */ r("path", {
					d: "m12 25 6-3 9 3m-18-3 7 7m6-7 7 6",
					fill: "none",
					stroke: Z.paper
				})
			] }) : e === "sympathy" ? /* @__PURE__ */ i(n, { children: [/* @__PURE__ */ r("path", {
				d: "M3 25 8 9l13-5 14 12-4 17-17 4Z",
				fill: "currentColor"
			}), /* @__PURE__ */ r("path", {
				d: "m8 25 6-9 6 5 8-9m-11 9 5 7m-10 0 3 5m8-1 6-7",
				fill: "none",
				stroke: Z.cream,
				strokeWidth: "2.5"
			})] }) : e === "tunnel" ? /* @__PURE__ */ i(n, { children: [
				/* @__PURE__ */ r("path", {
					d: "M3 35V25q0-20 17-20t17 20v10Z",
					fill: Z.clay
				}),
				/* @__PURE__ */ r("path", {
					d: "M10 35V24q0-12 10-12t10 12v11",
					fill: Z.ink
				}),
				/* @__PURE__ */ r("path", {
					d: "m7 19 5 2m2-13 3 6m8-6-2 6m10 4-6 3M5 28h6m18 0h6",
					fill: "none"
				})
			] }) : e === "garden" ? /* @__PURE__ */ i(n, { children: [
				/* @__PURE__ */ r("path", {
					d: "M5 35V19h30v16Z",
					fill: "currentColor"
				}),
				/* @__PURE__ */ r("path", {
					d: "M3 20 20 9l17 11M20 10V3m-7 3 7-4 7 4",
					fill: "none",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ r("path", {
					d: "M10 35V23h7v12m7 0V23h6v12",
					fill: Z.paper
				}),
				/* @__PURE__ */ r("path", {
					d: "m13 26 2 2m12-2 1 2M5 36h30",
					fill: "none"
				})
			] }) : e === "tradePost" ? /* @__PURE__ */ i(n, { children: [
				/* @__PURE__ */ r("path", {
					d: "M7 35V14h26v21Z",
					fill: Z.paper
				}),
				/* @__PURE__ */ r("path", {
					d: "M4 15 10 4h20l6 11q-5 8-8 0-4 8-8 0-4 8-8 0-4 8-8 0Z",
					fill: "currentColor"
				}),
				/* @__PURE__ */ r("path", {
					d: "M8 27h24v8H8m4-10 4-5 5 5m3 0 4-5 4 5",
					fill: Z.gold
				})
			] }) : e === "citadel" || e === "keep" ? /* @__PURE__ */ i(n, { children: [/* @__PURE__ */ r("path", {
				d: "M5 35V7h6v5h5V5h8v7h5V7h6v28Z",
				fill: "currentColor"
			}), /* @__PURE__ */ r("path", {
				d: "M16 35V26q4-9 8 0v9M9 18h4m15 0h4M9 25h4m15 0h4",
				fill: Z.paper
			})] }) : e === "market" ? /* @__PURE__ */ i(n, { children: [
				/* @__PURE__ */ r("path", {
					d: "M7 35V16m26 19V16M3 17 11 6h18l8 11Z",
					fill: "currentColor"
				}),
				/* @__PURE__ */ r("path", {
					d: "M6 26h29v9H6Z",
					fill: Z.gold
				}),
				/* @__PURE__ */ r("path", {
					d: "m11 25 4-7 4 7m3 0 4-5 4 5m-14 1v8m11-8v8",
					fill: "none"
				})
			] }) : e === "base" ? /* @__PURE__ */ i(n, { children: [
				/* @__PURE__ */ r("path", {
					d: "m3 34 7-23 13-6 14 29Z",
					fill: "currentColor"
				}),
				/* @__PURE__ */ r("path", {
					d: "m13 34 9-17 8 17m-9-17V8M6 35h29M9 13l12 5 13-4",
					fill: Z.paper
				}),
				/* @__PURE__ */ r("path", {
					d: "M6 11V3l10 3-10 5",
					fill: Z.gold
				})
			] }) : e === "plot" ? /* @__PURE__ */ i(n, { children: [
				/* @__PURE__ */ r("path", {
					d: "M20 3 36 18 22 37 4 21Z",
					fill: "currentColor"
				}),
				/* @__PURE__ */ r("path", {
					d: "m10 20 9-6 9 5-9 7Z",
					fill: Z.paper
				}),
				/* @__PURE__ */ r("path", {
					d: "m16 18 4 1 3-1m-4 2v3",
					fill: "none"
				})
			] }) : /* @__PURE__ */ i(n, { children: [
				/* @__PURE__ */ r("path", {
					d: "M7 34V15h26v19ZM4 16 20 4l16 12Z",
					fill: "currentColor"
				}),
				/* @__PURE__ */ r("path", {
					d: "M16 34V23h8v11",
					fill: Z.paper
				}),
				e === "sawmill" ? /* @__PURE__ */ i(n, { children: [/* @__PURE__ */ r("circle", {
					cx: "29",
					cy: "27",
					r: "8",
					fill: Z.stone
				}), /* @__PURE__ */ r("path", {
					d: "M29 17v20m-10-10h20m-17-7 14 14m0-14L22 34",
					fill: "none",
					strokeWidth: "1"
				})] }) : e === "workshop" ? /* @__PURE__ */ i(n, { children: [/* @__PURE__ */ r("path", {
					d: "M26 12V3h6v12",
					fill: Z.stone
				}), /* @__PURE__ */ r("path", {
					d: "m9 22 8 4m-4-6-3 9",
					fill: "none"
				})] }) : /* @__PURE__ */ i(n, { children: [/* @__PURE__ */ r("path", {
					d: "M6 26V3l10 3-10 5",
					fill: Z.gold
				}), /* @__PURE__ */ r("path", {
					d: "m21 18 5 2m-5 3 5 2",
					fill: "none"
				})] })
			] })
		})
	});
}
function $e() {
	return /* @__PURE__ */ i("svg", {
		className: "root-glyph",
		viewBox: "0 0 40 32",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ r("path", {
			d: "m4 7 9 7 7-12 7 12 9-7-5 20H9Z",
			fill: Z.gold,
			stroke: Z.ink,
			strokeWidth: "1.5",
			strokeLinejoin: "round"
		}), /* @__PURE__ */ r("path", {
			d: "M10 22h20m-10-11v7m-7 1 1 1m12-1-1 1",
			fill: "none",
			stroke: Z.paper,
			strokeWidth: "2"
		})]
	});
}
function et({ plot: e }) {
	return /* @__PURE__ */ r("svg", {
		className: "root-glyph",
		viewBox: "0 0 40 40",
		"aria-hidden": "true",
		children: /* @__PURE__ */ r("path", {
			d: {
				bomb: "M23 10q8-8 12-3m-12 5 5-6M25 24a10 10 0 1 1-20 0 10 10 0 1 1 20 0Zm-3-10 4-5 4 4-4 5M10 22l2-2",
				snare: "M8 7h23L13 31 8 7Zm6 0 8 11m5-7 6 16M5 33h26m-3-4 6-3 3 4",
				extortion: "m5 18 14 7 15-10m-29 3 13-9 16 6v15l-15 7-14-8Zm13 7v12M11 7l4-3m11 3-1-4",
				raid: "m5 26 12-7 15 7M17 19V4l13 4-13 5M8 25v10h23V25m-13 10V25h5v10"
			}[e ?? ""] ?? "M20 4 35 19 21 36 5 21Zm-8 15 8-4 8 4-8 6Z",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})
	});
}
function tt({ card: e }) {
	return /* @__PURE__ */ r(Je, { card: e });
}
function nt() {
	return /* @__PURE__ */ i("svg", {
		className: "root-choice-outline",
		viewBox: "0 0 100 100",
		preserveAspectRatio: "none",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ r("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "96",
			rx: "4",
			fill: "none",
			stroke: Z.pineDark,
			strokeWidth: "2",
			vectorEffect: "non-scaling-stroke"
		}), /* @__PURE__ */ r("rect", {
			className: "root-choice-march",
			x: "2",
			y: "2",
			width: "96",
			height: "96",
			rx: "4",
			pathLength: "100",
			fill: "none",
			stroke: Z.cream,
			strokeWidth: "2",
			strokeDasharray: "3 2",
			vectorEffect: "non-scaling-stroke",
			children: /* @__PURE__ */ r("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-10",
				dur: "2s",
				repeatCount: "indefinite"
			})
		})]
	});
}
function rt({ card: e, t: a, active: o = !1, selected: s = !1, detail: c = !1, onClick: l, anchor: u }) {
	let { ref: d, hidden: f } = t(u ?? null), p = e.id in it ? a(it[e.id]) : a(e.kind), m = /* @__PURE__ */ i(n, { children: [/* @__PURE__ */ r(Ze, {
		card: e,
		t: a,
		name: p,
		detail: c,
		art: /* @__PURE__ */ r(tt, { card: e }),
		itemIcon: (e) => /* @__PURE__ */ r(Q, { item: e }),
		suitIcon: (e) => /* @__PURE__ */ r(Y, { suit: e })
	}), o && /* @__PURE__ */ r(nt, {})] }), h = `root-card root-card-designed${c ? " root-card-detail" : ""}${o ? " root-card-available" : ""}${s ? " root-card-selected" : ""}`;
	return l ? /* @__PURE__ */ r("button", {
		ref: d,
		style: { visibility: f ? "hidden" : void 0 },
		className: h,
		"data-suit": e.suit,
		onClick: l,
		"aria-pressed": s,
		"aria-label": `${a(e.suit)} · ${p}`,
		children: m
	}) : /* @__PURE__ */ r("div", {
		ref: d,
		style: { visibility: f ? "hidden" : void 0 },
		className: h,
		"data-suit": e.suit,
		children: m
	});
}
var it = {
	ambush: "ambush",
	dominance: "dominance",
	armorers: "armorers",
	sappers: "sappers",
	brutalTactics: "brutalTactics",
	scoutingParty: "scoutingParty",
	standAndDeliver: "standAndDeliver",
	commandWarren: "commandWarren",
	betterBurrowBank: "betterBurrowBank",
	cobbler: "cobbler",
	codebreakers: "codebreakers",
	taxCollector: "taxCollector",
	royalClaim: "royalClaim",
	birdyBindle: "birdyBindle",
	woodlandRunners: "woodlandRunners",
	armsTrader: "armsTrader",
	crossbow: "crossbow",
	knapsack: "knapsack",
	rootTea: "rootTea",
	travelGear: "travelGear",
	protectionRacket: "protectionRacket",
	foxfolkSteel: "foxfolkSteel",
	anvil: "anvil",
	smugglersTrail: "smugglersTrail",
	visitFriends: "visitFriends",
	bakeSale: "bakeSale",
	mouseSack: "mouseSack",
	investments: "investments",
	sword: "sword",
	favor: "favor",
	vizier: "vizier"
};
//#endregion
//#region src/games/root/motion.tsx
function at({ value: e }) {
	return typeof window > "u" ? /* @__PURE__ */ r("span", { children: e }) : /* @__PURE__ */ r(a, { value: e });
}
//#endregion
//#region src/games/root/board-view.tsx
function ot({ owner: e, faction: n, id: a, n: o, t: s }) {
	let { ref: c, hidden: l } = t(`army:${e}:${a}`);
	return /* @__PURE__ */ i("span", {
		ref: c,
		className: "root-army",
		style: {
			"--root-army": J[n],
			visibility: l ? "hidden" : void 0
		},
		"aria-label": `${s(n)} · ${s("warriors", { n: o })}`,
		children: [/* @__PURE__ */ r(X, { faction: n }), /* @__PURE__ */ r("b", { children: /* @__PURE__ */ r(at, { value: o }) })]
	});
}
function st({ id: e, view: n, t: a, avatarOf: o, nameOf: s, selected: c, destination: l, targets: u, onClearing: d }) {
	let f = A(M(n), e), { ref: p } = t(`clearing:${e}`);
	return /* @__PURE__ */ i("button", {
		ref: p,
		className: `root-clearing-label${c === e ? " root-clearing-selected" : ""}${u.includes(e) ? " root-clearing-target" : ""}${l === e ? " root-clearing-destination" : ""}`,
		onClick: () => d(e),
		"aria-label": a("clearing", {
			suit: a(f.suit),
			n: e
		}),
		"aria-pressed": c === e || l === e,
		children: [
			/* @__PURE__ */ i("span", {
				className: "root-clearing-name",
				"data-suit": f.suit,
				children: [
					/* @__PURE__ */ r(Y, { suit: f.suit }),
					/* @__PURE__ */ r("b", { children: e }),
					u.includes(e) && /* @__PURE__ */ r("span", {
						className: "root-target-mark",
						children: "◆"
					})
				]
			}),
			n.battle?.clearing === e && /* @__PURE__ */ r("span", {
				className: "root-combat-marker",
				"aria-label": a("battle"),
				children: /* @__PURE__ */ r("svg", {
					viewBox: "0 0 24 24",
					"aria-hidden": "true",
					children: /* @__PURE__ */ r("path", {
						d: "m4 3 13 13m3-13L7 16M3 15l6 6m12-6-6 6M3 3l1 5 4-4Zm18 0-1 5-4-4Z",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "2"
					})
				})
			}),
			n.table?.ferry === e && /* @__PURE__ */ r("span", {
				className: "root-map-marker",
				children: a("ferry")
			}),
			O[n.map].tower === e && /* @__PURE__ */ r("span", {
				className: "root-map-marker",
				children: a("tower")
			}),
			n.table?.scorched.includes(e) && /* @__PURE__ */ r("span", {
				className: "root-map-marker",
				children: a("scorched")
			}),
			/* @__PURE__ */ i("span", {
				className: "root-armies",
				children: [
					n.players.map((t) => {
						let i = n.pieces.filter((n) => n.owner === t.rid && n.clearing === e && n.kind === "warrior").reduce((e, t) => e + t.count, 0);
						return i > 0 && /* @__PURE__ */ r(ot, {
							owner: t.rid,
							faction: t.faction,
							id: e,
							n: i,
							t: a
						}, t.rid);
					}),
					n.table?.boards.filter((t) => t.character && t.location === e).map((e) => /* @__PURE__ */ i("span", {
						className: "root-army",
						children: [/* @__PURE__ */ r(X, { faction: "vagabond" }), /* @__PURE__ */ r("b", {
							title: s(e.owner),
							style: {
								display: "inline-flex",
								width: 18,
								height: 18,
								flex: "none"
							},
							children: /* @__PURE__ */ r("img", {
								src: o(e.owner),
								alt: "",
								draggable: !1,
								style: {
									width: "1.75em",
									height: "1.75em",
									maxWidth: "100%",
									maxHeight: "100%",
									display: "block",
									objectFit: "contain",
									pointerEvents: "none",
									borderRadius: "inherit"
								}
							})
						})]
					}, e.owner)),
					n.pieces.filter((t) => t.clearing === e && t.kind === "wood").map((e) => /* @__PURE__ */ i("span", {
						className: "root-army root-resource",
						"aria-label": `${a("wood")} · ${e.count}`,
						children: [/* @__PURE__ */ r($, { kind: "wood" }), /* @__PURE__ */ r("b", { children: e.count })]
					}, e.uid))
				]
			})
		]
	});
}
function ct({ selected: t, destination: n, targets: a, points: o, viewBox: s, projectionRef: c }) {
	let l = e().replaceAll(":", ""), u = o.find((e) => e.id === t), d = o.find((e) => e.id === n);
	return /* @__PURE__ */ i("svg", {
		className: "root-selection-map",
		viewBox: s,
		"aria-hidden": "true",
		children: [/* @__PURE__ */ r("defs", { children: /* @__PURE__ */ r("marker", {
			id: l,
			viewBox: "0 0 10 10",
			refX: "8",
			refY: "5",
			markerWidth: "5",
			markerHeight: "5",
			orient: "auto-start-reverse",
			children: /* @__PURE__ */ r("path", {
				d: "m1 1 8 4-8 4 2-4Z",
				fill: J.ink
			})
		}) }), /* @__PURE__ */ i("g", {
			ref: c,
			style: c ? { visibility: "hidden" } : void 0,
			children: [u && d && /* @__PURE__ */ r("path", {
				className: "root-route-preview",
				d: `M${u.x} ${u.y} Q${(u.x + d.x) / 2} ${(u.y + d.y) / 2 - u.ry * 1.4} ${d.x} ${d.y}`,
				fill: "none",
				stroke: J.ink,
				strokeWidth: u.rx * .07,
				markerEnd: `url(#${l})`
			}, `${t}:${n}`), o.filter((e) => e.id === t || e.id === n || a.includes(e.id)).map((e) => {
				let a = e.id === n ? "destination" : e.id === t ? "selected" : "legal";
				return /* @__PURE__ */ i("g", {
					className: `root-ground-mark root-ground-${a}`,
					children: [
						/* @__PURE__ */ r("ellipse", {
							cx: e.x,
							cy: e.y,
							rx: e.rx,
							ry: e.ry,
							fill: a === "legal" ? J.cream : J.gold,
							fillOpacity: a === "legal" ? ".15" : ".1",
							stroke: J.ink,
							strokeWidth: e.rx * .12
						}),
						/* @__PURE__ */ r("ellipse", {
							cx: e.x,
							cy: e.y,
							rx: e.rx,
							ry: e.ry,
							fill: "none",
							stroke: a === "selected" ? J.gold : a === "destination" ? J.cream : J.pineLight,
							strokeWidth: e.rx * .07
						}),
						a === "legal" && /* @__PURE__ */ r("ellipse", {
							className: "root-choice-march",
							cx: e.x,
							cy: e.y,
							rx: e.rx,
							ry: e.ry,
							fill: "none",
							stroke: J.cream,
							strokeWidth: e.rx * .07,
							strokeDasharray: `${e.rx * .24} ${e.rx * .16}`,
							children: /* @__PURE__ */ r("animate", {
								attributeName: "stroke-dashoffset",
								from: "0",
								to: -e.rx * .8,
								dur: "2s",
								repeatCount: "indefinite"
							})
						}),
						a === "destination" && /* @__PURE__ */ r("path", {
							d: `M${e.x - e.rx * .24} ${e.y - e.ry * 1.35}l${e.rx * .24} ${e.ry * .3} ${e.rx * .24} ${-e.ry * .3}`,
							fill: "none",
							stroke: J.ink,
							strokeWidth: e.rx * .09
						})
					]
				}, `${e.id}:${a}`);
			})]
		})]
	});
}
function lt(e) {
	let t = M(e.view), n = O[e.view.map], a = k(t), o = (e) => {
		let n = A(t, e);
		return `${n.x},${n.z}`;
	}, s = N(t), c = Array.from({ length: 430 }, (e, t) => ({
		x: Math.sin(t * 17.3) * 6.7,
		z: Math.cos(t * 11.7) * 6.5,
		n: t
	})).filter((t) => !a.some((e) => Math.hypot(e.x - t.x, e.z - t.z) < 1.03) && !(e.view.map === "lake" && (t.x - .6) ** 2 / 4 + (t.z - .5) ** 2 / 5 < 1)), l = (e, n) => {
		let r = A(t, e), i = A(t, n), a = .06 * Math.sin(e + n);
		return `M${o(e)} Q${(r.x + i.x) / 2 - (i.z - r.z) * a * 2},${(r.z + i.z) / 2 + (i.x - r.x) * a * 2} ${o(n)}`;
	};
	return /* @__PURE__ */ r("div", {
		className: "root-board-2d",
		role: "group",
		"aria-label": e.t("board"),
		children: /* @__PURE__ */ i("div", {
			className: "root-flat-map",
			children: [
				/* @__PURE__ */ i("svg", {
					viewBox: "-6.5 -6 13 12.4",
					className: "root-map-svg",
					"aria-hidden": "true",
					children: [
						/* @__PURE__ */ r("rect", {
							x: "-6.5",
							y: "-6",
							width: "13",
							height: "12.4",
							fill: J.grass
						}),
						c.map((e) => /* @__PURE__ */ i("g", {
							transform: `translate(${e.x} ${e.z})`,
							children: [/* @__PURE__ */ r("path", {
								d: "m0-.55-.25.4h.12l-.22.35h.7L.13-.15h.12Z",
								fill: [
									J.pine,
									J.pineDark,
									J.pineLight,
									J.leaf
								][e.n % 4]
							}), /* @__PURE__ */ r("path", {
								d: "M0 .2v.18",
								stroke: J.bark,
								strokeWidth: ".045"
							})]
						}, e.n)),
						e.view.map === "lake" ? /* @__PURE__ */ r("ellipse", {
							cx: ".6",
							cy: ".5",
							rx: "1.7",
							ry: "2.0",
							fill: J.river,
							stroke: J.sand,
							strokeWidth: ".14"
						}) : n.rivers.map(([e, t]) => /* @__PURE__ */ i("g", { children: [/* @__PURE__ */ r("path", {
							d: l(e, t),
							fill: "none",
							stroke: J.sand,
							strokeWidth: ".55"
						}), /* @__PURE__ */ r("path", {
							d: l(e, t),
							fill: "none",
							stroke: J.river,
							strokeWidth: ".35"
						})] }, `${e}:${t}`)),
						n.paths.map(([t, n]) => /* @__PURE__ */ r("path", {
							d: l(t, n),
							fill: "none",
							stroke: e.view.table?.blocked.some(([e, r]) => j(t, n) === j(e, r)) ? J.stone : J.path,
							strokeWidth: ".15",
							strokeDasharray: ".13 .055"
						}, `${t}:${n}`)),
						a.map((t) => /* @__PURE__ */ i("g", { children: [
							/* @__PURE__ */ r("path", {
								d: `M${t.x - .98} ${t.z}q.03-.79.97-.81t.98.82q0 .81-.98.79t-.97-.8Z`,
								fill: e.view.table?.scorched.includes(t.id) ? J.soil : J.sand,
								stroke: e.selected === t.id || e.destination === t.id ? J.gold : e.targets.includes(t.id) ? J.cream : J.clay,
								strokeWidth: e.selected === t.id || e.targets.includes(t.id) ? ".08" : ".045"
							}),
							Array.from({ length: t.slots }, (n, i) => /* @__PURE__ */ r("rect", {
								x: t.x - (t.slots - 1) * .22 + i * .44 - .17,
								y: t.z - .53,
								width: ".34",
								height: ".27",
								rx: ".025",
								fill: (e.view.table ? e.view.table.ruins.some((e) => e.clearing === t.id && e.count) : t.ruin) && i === t.slots - 1 ? J.stone : J.clearing,
								stroke: J.bark,
								strokeWidth: ".03"
							}, i)),
							e.view.pieces.filter((e) => e.clearing === t.id && e.kind !== "warrior").map((n, i, a) => {
								let o = a.filter((e) => P(e.kind)).indexOf(n), s = P(n.kind) ? t.x - (t.slots - 1) * .22 + o * .44 : t.x - .5 + a.slice(0, i).filter((e) => !P(e.kind)).length * .33;
								return /* @__PURE__ */ r("svg", {
									x: s - .22,
									y: P(n.kind) ? t.z - .82 : t.z - .2,
									width: ".44",
									height: ".5",
									viewBox: "0 0 40 40",
									color: J[e.view.players.find((e) => e.rid === n.owner).faction],
									children: /* @__PURE__ */ r($, { kind: n.kind })
								}, n.uid);
							})
						] }, t.id))
					]
				}),
				/* @__PURE__ */ r(ct, {
					...e,
					viewBox: "-6.5 -6 13 12.4",
					points: [...a.map((e) => ({
						id: e.id,
						x: e.x,
						y: e.z,
						rx: 1.03,
						ry: .86
					})), ...s.map((e) => ({
						id: e.id,
						x: e.x,
						y: e.z,
						rx: .45,
						ry: .36
					}))]
				}),
				/* @__PURE__ */ i("div", {
					className: "root-board-labels",
					children: [a.map((t) => /* @__PURE__ */ r("div", {
						className: "root-clearing-projection",
						style: {
							left: `${(t.x + 6.5) / 13 * 100}%`,
							top: `${(t.z + 6) / 12.4 * 100}%`
						},
						children: /* @__PURE__ */ r(st, {
							...e,
							id: t.id
						})
					}, t.id)), s.map((t) => /* @__PURE__ */ r("div", {
						className: "root-clearing-projection",
						style: {
							left: `${(t.x + 6.5) / 13 * 100}%`,
							top: `${(t.z + 6) / 12.4 * 100}%`
						},
						children: /* @__PURE__ */ r(ut, {
							...e,
							id: t.id
						})
					}, t.id))]
				})
			]
		})
	});
}
function ut({ id: e, view: n, t: a, avatarOf: o, nameOf: s, onClearing: c, targets: l, selected: u, destination: d }) {
	let { ref: f } = t(`clearing:${e}`);
	return /* @__PURE__ */ i("button", {
		ref: f,
		className: `root-forest-label${l.includes(e) ? " root-forest-target" : ""}${u === e || d === e ? " root-forest-selected" : ""}`,
		onClick: () => c(e),
		"aria-pressed": u === e || d === e,
		"aria-label": a("chooseForest", { n: -e }),
		children: [/* @__PURE__ */ i("span", {
			className: "root-forest-name",
			children: ["♧", -e]
		}), n.table?.boards.filter((t) => t.character && t.location === e).map((e) => /* @__PURE__ */ i("span", { children: [/* @__PURE__ */ r(X, { faction: "vagabond" }), /* @__PURE__ */ r("span", {
			title: s(e.owner),
			style: {
				display: "inline-block",
				width: 18,
				height: 18
			},
			children: /* @__PURE__ */ r("img", {
				src: o(e.owner),
				alt: "",
				draggable: !1,
				style: {
					width: "1.75em",
					height: "1.75em",
					maxWidth: "100%",
					maxHeight: "100%",
					display: "block",
					objectFit: "contain",
					pointerEvents: "none",
					borderRadius: "inherit"
				}
			})
		})] }, e.owner))]
	});
}
//#endregion
export { te as $, le as A, l as B, j as C, k as D, de as E, v as F, ne as G, f as H, u as I, y as J, x as K, p as L, ae as M, re as N, oe as O, _ as P, T as Q, o as R, A as S, ue as T, h as U, c as V, g as W, m as X, b as Y, s as Z, me as _, at as a, O as b, rt as c, X as d, Q as f, P as g, Y as h, ct as i, M as j, se as k, nt as l, J as m, ut as n, $ as o, et as p, d as q, lt as r, tt as s, st as t, $e as u, fe as v, N as w, ce as x, pe as y, S as z };
