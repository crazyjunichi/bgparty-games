import { $ as e, A as t, B as n, C as r, D as i, E as a, F as o, G as s, H as c, I as l, J as u, K as d, L as f, N as p, O as m, P as h, Q as g, R as _, S as v, T as y, U as ee, V as te, W as b, X as ne, Y as re, Z as ie, _ as x, a as ae, b as S, c as oe, d as C, f as se, g as w, h as ce, j as le, k as ue, l as de, m as T, o as fe, p as pe, q as me, r as he, s as ge, u as _e, v as E, x as ve, y as D, z as ye } from "@bgparty/game/chunks/board-view-DwOumbdc.js";
import { z as O } from "zod";
import { randomIntAt as be } from "@bgparty/sdk/engine/prng";
import { Fragment as xe, Suspense as Se, lazy as Ce, useEffect as we, useMemo as Te, useRef as Ee, useState as De } from "react";
import { useI18nSettings as Oe, useT as ke } from "@bgparty/sdk/i18n";
import { useWakeLock as Ae } from "@bgparty/sdk/use-wake-lock";
import { PLAYER_COLORS as je } from "@bgparty/sdk/player-colors";
import { BottomSheet as Me } from "@bgparty/sdk/bottom-sheet";
import { Texture as Ne } from "@bgparty/sdk/texture";
import { GameScreen as Pe } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as Fe } from "@bgparty/sdk/ui/phase-banner";
import { useFxAnchor as Ie, useFxAnchorsMaybe as Le } from "@bgparty/sdk/fx/anchors";
import { Fragment as k, jsx as A, jsxs as j } from "react/jsx-runtime";
import { Floater as Re, FlySprite as ze, PulseBox as Be } from "@bgparty/sdk/fx/primitives";
import { IconBack as Ve, IconBot as He, IconExpand as Ue, IconLog as We } from "@bgparty/sdk/icons";
import { seatName as Ge } from "@bgparty/sdk/ui/player-strip";
import { Confetti as Ke } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as qe, OptionSection as Je } from "@bgparty/sdk/ui/game-options";
//#region src/games/root/meta.ts
var Ye = {
	id: "root",
	tier: "beta",
	mechanics: [
		"area-control",
		"hand-management",
		"action-programming",
		"dice-rolling"
	],
	interactionTags: [],
	nameKey: "games.root.name",
	descKey: "games.root.desc",
	rulesKey: "games.root.rules",
	icon: "🌲",
	iconImg: "games/root.webp",
	minPlayers: 2,
	maxPlayers: 6,
	bestPlayers: [4],
	accent: "#537951",
	playerRange(e) {
		let t = e && typeof e == "object" && "factions" in e && Array.isArray(e.factions) ? e.factions : [];
		return {
			min: 2,
			max: t.length ? Math.min(6, new Set(t).size + Number(t.includes("vagabond"))) : 6
		};
	},
	rulesUrl: { en: "https://rules.ledergames.com/?product=root&locale=en-US&printing=p16" },
	releasedAt: "2026-10-23T02:03:09+08:00",
	search: {
		py: "mao lin yuan ji gen",
		init: "mlyj"
	},
	hotseat: "cover"
}, Xe = O.enum([
	"marquise",
	"eyrie",
	"alliance",
	"vagabond",
	"cult",
	"riverfolk",
	"duchy",
	"corvid"
]), Ze = O.enum([
	"fox",
	"rabbit",
	"mouse",
	"bird"
]), Qe = O.enum([
	"autumn",
	"winter",
	"lake",
	"mountain"
]), $e = O.object({
	map: Qe.default("autumn"),
	factions: O.array(Xe).max(8).refine((e) => !e.length || new Set(e).size + Number(e.includes("vagabond")) >= 2).default([])
}).default({
	map: "autumn",
	factions: []
}), M = O.string().min(1), N = O.number().int().nonnegative(), et = O.number().int().min(1).max(12), tt = O.number().int().min(0).max(12), nt = O.enum([
	"warrior",
	"sawmill",
	"workshop",
	"recruiter",
	"roost",
	"base",
	"garden",
	"tradePost",
	"citadel",
	"market",
	"keep",
	"wood",
	"sympathy",
	"tunnel",
	"plot"
]), P = O.object({
	uid: M,
	id: M,
	suit: Ze,
	kind: O.enum([
		"ambush",
		"item",
		"persistent",
		"dominance"
	])
}), rt = O.object({
	uid: M,
	owner: M,
	kind: nt,
	clearing: et,
	count: N.min(1),
	faceUp: O.boolean(),
	plot: O.enum([
		"bomb",
		"snare",
		"extortion",
		"raid"
	]).nullable()
}), it = O.enum([
	"armorers",
	"brutalTactics",
	"sappers",
	"scoutingParty",
	"standAndDeliver",
	"commandWarren",
	"betterBurrowBank",
	"cobbler",
	"codebreakers",
	"taxCollector",
	"royalClaim",
	"swiftStrike"
]), at = O.object({
	rid: M,
	faction: Xe,
	vp: N,
	supply: N,
	hand: O.array(P),
	effects: O.array(O.object({
		effect: it,
		card: P
	})),
	leader: O.enum([
		"builder",
		"charismatic",
		"commander",
		"despot"
	]).nullable()
}), ot = O.object({
	owner: M,
	kind: O.enum([
		"march",
		"move",
		"battle"
	]),
	remaining: N,
	suit: Ze.nullable(),
	source: O.string()
}), st = O.object({
	clearing: et,
	attacker: M,
	defender: M,
	stage: O.enum([
		"ambush",
		"counter",
		"ambushHits",
		"ambushAftermath",
		"roll",
		"effects",
		"hits",
		"result"
	]),
	ambushCard: P.nullable(),
	dice: O.tuple([N.max(3), N.max(3)]).nullable(),
	effectsDone: O.array(M),
	effectsOwner: M.nullable(),
	usedEffects: O.array(O.object({
		owner: M,
		effect: it
	})),
	hits: O.array(O.object({
		owner: M,
		by: M,
		remaining: N
	})),
	selectedLosses: O.array(O.object({
		owner: M,
		by: M,
		piece: M,
		n: N.min(1)
	})),
	despotAwarded: O.array(M),
	arbiter: M.nullable().optional(),
	ally: M.nullable().optional(),
	instigator: M.nullable().optional(),
	allyHits: N.optional(),
	itemHits: N.optional()
}), ct = O.object({
	owner: M,
	clearing: et,
	count: N.min(1)
}), lt = O.object({
	id: N,
	type: O.enum([
		"move",
		"battle",
		"ambush",
		"counter",
		"roll",
		"loss",
		"hospital",
		"skipHospital",
		"effect",
		"complete"
	]),
	owner: M,
	target: M.nullable(),
	clearing: tt,
	from: tt.nullable(),
	n: N
}), ut = O.discriminatedUnion("type", [
	O.object({
		type: O.literal("move"),
		from: tt,
		to: tt,
		n: N.min(1),
		via: O.enum([
			"path",
			"river",
			"ferry",
			"tunnel"
		]).optional()
	}),
	O.object({
		type: O.literal("battle"),
		clearing: et,
		defender: M
	}),
	O.object({
		type: O.literal("card"),
		uid: M
	}),
	O.object({ type: O.literal("pass") }),
	O.object({
		type: O.literal("effect"),
		effect: it
	}),
	O.object({
		type: O.literal("effectOrder"),
		owner: M
	}),
	O.object({
		type: O.literal("loss"),
		piece: M
	}),
	O.object({
		type: O.literal("choose"),
		id: M
	}),
	O.object({
		type: O.literal("itemHit"),
		uid: M
	}),
	O.object({
		type: O.literal("tick"),
		now: O.number().finite()
	})
]), dt = O.object({
	action: ut,
	kind: O.enum([
		"move",
		"battle",
		"ambush",
		"counter",
		"hospital",
		"pass",
		"loss",
		"effect",
		"effectOrder",
		"option",
		"itemHit"
	]),
	clearing: tt.nullable(),
	n: N.nullable(),
	label: O.string().optional(),
	args: O.record(O.string(), O.union([O.string(), O.number()])).optional(),
	weight: O.number().optional()
}), ft = O.enum([
	"boot",
	"sack",
	"crossbow",
	"hammer",
	"sword",
	"tea",
	"coin",
	"torch"
]), pt = O.enum([
	"fox",
	"rabbit",
	"mouse"
]), mt = O.object({
	id: M,
	suit: pt,
	items: O.tuple([ft, ft])
}), ht = O.object({
	owner: M,
	starting: et.nullable(),
	revealed: O.array(P),
	supportersCount: N,
	officers: N,
	decree: O.array(O.object({
		column: O.enum([
			"recruit",
			"move",
			"battle",
			"build"
		]),
		card: P,
		vizier: O.boolean()
	})),
	leadersUsed: O.array(at.shape.leader.unwrap()),
	acolytes: N,
	outcast: pt,
	hated: O.boolean(),
	funds: O.array(M),
	committed: O.array(M),
	payments: O.array(M),
	tradePostsLost: O.array(pt),
	prices: O.object({
		card: N.min(1).max(4),
		boats: N.min(1).max(4),
		mercenaries: N.min(1).max(4)
	}),
	ministers: O.array(O.enum(ee)),
	crownsLost: O.array(N),
	character: O.enum(l).nullable(),
	location: O.number().int(),
	items: O.array(O.object({
		uid: M,
		type: ft,
		exhausted: O.boolean(),
		damaged: O.boolean(),
		origin: O.enum([
			"starting",
			"ruin",
			"crafted"
		])
	})),
	relationships: O.array(O.object({
		owner: M,
		level: O.number().int().min(-1).max(3),
		aids: N
	})),
	completedQuests: O.array(mt),
	craftedItems: O.array(ft),
	dominance: P.nullable(),
	coalition: M.nullable()
}), gt = O.object({
	suits: O.array(pt).length(12),
	blocked: O.array(O.array(et).length(2)),
	ferry: et.nullable(),
	scorched: O.array(et),
	ruins: O.array(O.object({
		clearing: et,
		count: N
	})),
	deckCount: N,
	availableDominance: O.array(P),
	lostSouls: O.array(P),
	itemSupply: O.record(ft, N),
	quests: O.array(mt),
	boards: O.array(ht),
	round: N,
	turn: N,
	phase: O.enum([
		"setup",
		"birdsong",
		"daylight",
		"evening"
	]),
	step: O.string(),
	actions: N,
	used: O.array(O.string()),
	decreeDone: O.array(O.string()),
	riverboats: O.array(M),
	mercenaries: O.array(M)
}), _t = at.omit({ hand: !0 }).extend({
	handCount: N,
	publicHand: O.array(P).nullable()
}), vt = O.object({
	version: N,
	map: Qe,
	active: M,
	acting: M.nullable(),
	phase: O.enum([
		"setup",
		"birdsong",
		"daylight",
		"evening",
		"command",
		"battle",
		"hospital",
		"complete",
		"done"
	]),
	players: O.array(_t),
	pieces: O.array(rt.omit({ plot: !0 }).extend({ plot: rt.shape.plot })),
	command: ot.nullable(),
	battle: st.nullable(),
	hospital: ct.nullable(),
	discard: O.array(P),
	log: O.array(lt),
	winner: O.array(M),
	table: gt.optional()
}), yt = O.object({
	hand: O.array(P),
	choices: O.array(dt),
	plots: O.array(O.object({
		uid: M,
		plot: rt.shape.plot
	})),
	supporters: O.array(P).optional(),
	peek: O.array(P).optional()
}), F = (e, t, n = {}) => ({
	label: e,
	run: t,
	...n
}), I = (e) => {
	e.game.tasks.shift();
}, L = (e = "continue") => F(e, I, { weight: -100 }), bt = (e, t) => {
	if (t === 0) return [[]];
	if (e.length < t) return [];
	if (e.length === t) return [[...e]];
	let [n, ...r] = e;
	return [...bt(r, t - 1).map((e) => [n, ...e]), ...bt(r, t)];
}, xt = (e) => ({
	owner: e,
	starting: null,
	revealed: [],
	supporters: [],
	officers: 0,
	decree: [],
	leadersUsed: [],
	acolytes: 0,
	outcast: "fox",
	hated: !1,
	funds: [],
	committed: [],
	payments: [],
	tradePostsLost: [],
	prices: {
		card: 1,
		boats: 1,
		mercenaries: 1
	},
	ministers: [],
	crownsLost: [],
	character: null,
	location: -1,
	items: [],
	relationships: [],
	completedQuests: [],
	craftedItems: [],
	dominance: null,
	coalition: null
}), St = Symbol("root-resolution-fx");
function Ct(e, t) {
	let n = structuredClone(e);
	return Object.defineProperty(n, St, {
		value: t,
		configurable: !0
	}), n;
}
function wt(e) {
	return e && delete e[St], e;
}
function R(e, t) {
	let n = e[St];
	if (n) {
		if ((t.rid !== void 0 || t.data !== void 0) && !n.some((e) => e.rid !== void 0 || e.data !== void 0)) {
			n.unshift({
				...t,
				with: !1
			});
			for (let e = 1; e < n.length; e++) n[e].with = !0;
		} else n.push({
			...t,
			with: n.length > 0
		});
	}
}
var Tt = (e, t) => e.players.find((e) => e.rid === t).faction, z = (e, t) => e.game.boards.find((e) => e.owner === t), Et = (e, t) => e.players.find((e) => e.faction === t)?.rid, B = (e, t, n, r) => e.pieces.filter((i) => i.owner === t && i.kind === n && (!r || v(e, i.clearing).suit === r)).reduce((e, t) => e + t.count, 0), Dt = (e, t) => e.suit === t || e.suit === "bird" && t !== "bird";
function Ot(e, t) {
	let n = [...t];
	for (let t = n.length - 1; t > 0; t--) {
		let r = be(e.seed, e.cursor++, t + 1);
		[n[t], n[r]] = [n[r], n[t]];
	}
	return n;
}
function V(e, t, n) {
	let r = e.game && z(e, t);
	!r?.dominance && !r?.coalition && (E(e, t).vp = Math.max(0, E(e, t).vp + n));
}
function kt(e, t) {
	e.winner = [t, ...e.game?.boards.filter((e) => e.coalition === t).map((e) => e.owner) ?? []];
}
function At(e) {
	if (e.winner.length) return;
	let t = e.order.indexOf(e.active), n = [...e.order.slice(t), ...e.order.slice(0, t)].find((t) => E(e, t).vp >= 30 && (!e.game || !z(e, t).dominance && !z(e, t).coalition));
	n && kt(e, n);
}
function H(e, ...t) {
	if (!e.game) {
		e.discard.push(...t);
		return;
	}
	if (Et(e, "cult")) e.game.lostSouls.push(...t);
	else for (let n of t) (n.kind === "dominance" ? e.game.availableDominance : e.discard).push(n);
}
function U(e, t = 1, n) {
	let r = [], i = e.game;
	for (let n = 0; n < t; n++) {
		i.deck.length || (i.deck = Ot(e, e.discard), e.discard = []);
		let t = i.deck.shift();
		if (!t) break;
		r.push(t), !i.deck.length && e.discard.length && (i.deck = Ot(e, e.discard), e.discard = []);
	}
	return n && r.length && R(e, {
		kind: "draw",
		rid: n,
		data: { n: r.length },
		for: [n],
		secret: { uids: r.map((e) => e.uid) }
	}), r;
}
function W(e, t, n) {
	let r = E(e, t), i = r.hand.findIndex((e) => e.uid === n);
	if (i < 0) throw Error("Root card no longer in hand");
	let a = r.hand.splice(i, 1)[0];
	return R(e, {
		kind: "cardUse",
		for: [t],
		secret: { card: a }
	}), a;
}
function jt(e, t) {
	let n = E(e, t).hand;
	return n.length ? n.splice(be(e.seed, e.cursor++, n.length), 1)[0] : null;
}
function Mt(e, t, n) {
	return n > 0 && !e.game?.scorched.includes(n) && !e.pieces.some((e) => e.clearing === n && e.owner !== t && (e.kind === "keep" || e.kind === "plot" && e.faceUp && e.plot === "snare"));
}
function G(e, t, n, r, i = 1, a = null, o = !1) {
	if (i < 1 || !o && !Mt(e, t, r) || e.game?.scorched.includes(r)) return null;
	let s = e.pieces.find((e) => e.owner === t && e.kind === n && e.clearing === r && e.plot === a);
	if (o || R(e, {
		kind: "piece",
		rid: t,
		data: {
			mode: "place",
			clearing: r,
			kind: n,
			n: i,
			faction: Tt(e, t)
		}
	}), s && n === "warrior" || s && n === "wood") return s.count += i, s;
	let c = {
		uid: `${t}:${n}:${e.version}:${e.pieces.length}`,
		owner: t,
		kind: n,
		clearing: r,
		count: i,
		faceUp: n !== "plot",
		plot: a
	};
	return e.pieces.push(c), c;
}
function K(e, t, n, r = 1) {
	let i = E(e, t), a = Math.min(r, i.supply);
	return n === 0 && e.game && i.faction === "duchy" ? (i.supply -= a, z(e, t).location += a, a) : a && G(e, t, "warrior", n, a) ? (i.supply -= a, a) : 0;
}
function Nt(e, t, n, r) {
	if (n === 0) {
		z(e, t).location -= r, E(e, t).supply += r;
		return;
	}
	let i = r;
	for (let r of x(e, t, n).filter((e) => e.kind === "warrior")) {
		let e = Math.min(i, r.count);
		r.count -= e, i -= e;
	}
	e.pieces = e.pieces.filter((e) => e.count > 0), E(e, t).supply += r - i;
}
function Pt(e, t, n, r, i) {
	Nt(e, t, n, i), E(e, t).supply -= i, r === 0 ? z(e, t).location += i : G(e, t, "warrior", r, i, null, !0), Ft(e, t, r), R(e, {
		kind: "move",
		rid: t,
		data: {
			from: n,
			clearing: r,
			n: i,
			total: D(e, t, r),
			faction: Tt(e, t)
		}
	});
}
function Ft(e, t, n) {
	if (e.game) for (let r of e.pieces.filter((e) => e.kind === "sympathy" && e.clearing === n && e.owner !== t)) e.game.interrupts.push({
		kind: "outrage",
		owner: t,
		target: r.owner,
		location: n
	});
}
function It(e, t, n) {
	let r = z(e, t);
	r.supporters.push(...n), n.length && R(e, {
		kind: "supporters",
		rid: t,
		data: { n: n.length }
	}), !B(e, t, "base") && r.supporters.length > 5 && !e.game.interrupts.some((e) => e.kind === "baseLoss" && e.owner === t && e.key === "limit") && e.game.interrupts.push({
		kind: "baseLoss",
		owner: t,
		key: "limit"
	});
}
function Lt(e, t, n, r = "crafted") {
	let i = z(e, t);
	i.items.push({
		uid: `${t}:item:${e.version}:${i.items.length}`,
		type: n,
		exhausted: !1,
		damaged: !1,
		origin: r
	}), R(e, {
		kind: "item",
		rid: t,
		data: {
			uid: i.items.at(-1).uid,
			item: n,
			faction: Tt(e, t)
		}
	});
}
var q = (e, t, n) => z(e, t).items.filter((e) => !e.exhausted && !e.damaged && (!n || e.type === n)), Rt = (e, t) => z(e, t).items.filter((e) => e.type === "sword" && !e.damaged).length;
function zt(e, t, n, r) {
	let i = z(e, t).items.find((e) => e.uid === n);
	Object.assign(i, r), R(e, {
		kind: "item",
		rid: t,
		data: {
			uid: n,
			item: i.type,
			faction: Tt(e, t)
		}
	});
}
function Bt(e, t, n) {
	for (let r of n) zt(e, t, r, { exhausted: !0 });
}
function J(e, ...t) {
	e.game.tasks.unshift(...t);
}
function Vt(e, ...t) {
	e.game.interrupts.push(...t);
}
var Ht = (e, t, n) => E(e, t).faction === "vagabond" && !!e.game && z(e, t).location === n, Ut = (e, t, n) => x(e, t, n).length > 0 || Ht(e, t, n);
function Wt(e, t, n) {
	if (!e.game || e.game.phase === "birdsong" || !e.game.mercenaries.includes(t)) return null;
	let r = Et(e, "riverfolk");
	return r && r !== n ? r : null;
}
function Gt(e, t, n, r) {
	if (E(e, t).faction === "vagabond" && e.game) return Ht(e, t, n) ? Rt(e, t) : 0;
	let i = Wt(e, t, r);
	return D(e, t, n) + (i ? D(e, i, n) : 0);
}
function Kt(e, t, n = "effect") {
	let r = t.flatMap((t) => {
		let n = e.pieces.find((e) => e.uid === t.piece);
		return n ? [{
			...n,
			count: Math.min(t.n, n.count),
			by: t.by
		}] : [];
	});
	for (let t of r) e.pieces.find((e) => e.uid === t.uid).count -= t.count;
	e.pieces = e.pieces.filter((e) => e.count > 0);
	let i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Set();
	for (let t of r) {
		R(e, {
			kind: "piece",
			rid: t.owner,
			data: {
				mode: "remove",
				clearing: t.clearing,
				kind: t.kind,
				n: t.count,
				faction: Tt(e, t.owner)
			}
		});
		let r = E(e, t.owner), o = E(e, t.by), s = e.game, c = s && z(e, t.owner);
		if (t.kind === "warrior") {
			if (s && r.faction === "cult" && n === "battle" && e.battle?.defender === t.owner ? c.acolytes += t.count : r.supply += t.count, r.faction === "marquise") {
				let e = `${t.owner}:${t.clearing}`, n = i.get(e);
				i.set(e, {
					clearing: t.clearing,
					n: (n?.n ?? 0) + t.count
				});
			}
		} else t.owner !== t.by && (V(e, t.by, t.count), n === "battle" && o.faction === "eyrie" && o.leader === "despot" && !e.battle?.despotAwarded.includes(t.by) && (V(e, t.by, 1), e.battle?.despotAwarded.push(t.by)));
		let l = n === "battle" && e.battle && (Wt(e, e.battle.attacker, e.battle.defender) === t.owner || Wt(e, e.battle.defender, e.battle.attacker) === t.owner);
		if (s && o.faction === "vagabond" && t.owner !== t.by && !l) {
			let r = z(e, t.by).relationships.find((e) => e.owner === t.owner);
			if (r) {
				let i = t.kind === "warrior" && r.level !== -1;
				i && (r.level = -1), r.level === -1 && n === "battle" && e.active === t.by && V(e, t.by, t.count - Number(i));
			}
		}
		e.log.push({
			id: e.version,
			type: "loss",
			owner: t.owner,
			target: t.by,
			clearing: t.clearing,
			from: null,
			n: t.count
		}), s && (t.kind === "sympathy" && t.owner !== t.by && Vt(e, {
			kind: "outrage",
			owner: t.by,
			target: t.owner,
			location: t.clearing
		}), t.kind === "base" && Vt(e, {
			kind: "baseLoss",
			owner: t.owner,
			key: "base",
			suit: v(e, t.clearing).suit
		}), t.kind === "garden" && Vt(e, {
			kind: "gardenLoss",
			owner: t.owner,
			n: t.count
		}), t.kind === "tradePost" && (c.tradePostsLost.push(v(e, t.clearing).suit), Vt(e, {
			kind: "tradeLoss",
			owner: t.owner
		})), r.faction === "duchy" && w(t.kind) && a.add(t.owner), t.kind === "plot" && t.plot === "raid" && n !== "exposure" && Vt(e, {
			kind: "raid",
			owner: t.owner,
			locations: ve(e, t.owner, t.clearing)
		}));
	}
	for (let [t, n] of i) {
		let r = t.slice(0, t.lastIndexOf(":"));
		e.pieces.some((e) => e.owner === r && e.kind === "keep") && (e.game ? Vt(e, {
			kind: "hospital",
			owner: r,
			location: n.clearing,
			n: n.n
		}) : e.hospitals.push({
			owner: r,
			clearing: n.clearing,
			count: n.n
		}));
	}
	for (let t of a) Vt(e, {
		kind: "failure",
		owner: t
	});
	At(e);
}
function qt(e, t, n) {
	let r = Wt(e, t);
	Kt(e, e.pieces.filter((e) => e.owner !== t && (e.owner !== r || e.kind !== "warrior") && n.includes(e.clearing)).map((e) => ({
		piece: e.uid,
		by: t,
		n: e.count
	})));
	for (let r of e.players.filter((r) => r.faction === "vagabond" && r.rid !== t && n.includes(z(e, r.rid).location))) Vt(e, {
		kind: "damage",
		owner: r.rid,
		n: 3
	});
}
function Jt(e, t) {
	let n = v(e, t), r = e.game ? e.game.ruins.some((e) => e.clearing === t && e.items.length) : n.ruin;
	return n.slots - Number(r) - e.pieces.filter((e) => e.clearing === t && w(e.kind)).reduce((e, t) => e + t.count, 0);
}
function Yt(e, n, r) {
	let i = z(e, n).dominance;
	return !i || E(e, n).faction === "vagabond" ? !1 : i.suit === "bird" ? S[e.map].diagonals.some((t) => t.every((t) => r(e, t) === n)) : S[e.map].clearings.filter((a) => t(e, i.suit, a.id) && r(e, a.id) === n).length >= 3;
}
var Xt = (e, t) => Object.fromEntries(te.map((n) => [n, Math.min(3, q(e, t, n).length)]));
//#endregion
//#region src/games/root/position.ts
function Y(e, t) {
	if (t === 0) return e.players.find((e) => e.faction === "duchy")?.rid ?? null;
	let n = e.pieces.filter((e) => e.clearing === t && e.kind === "garden");
	if (n.length) return n[0].owner;
	let r = e.game && e.game.phase !== "birdsong" && e.game.mercenaries.includes(e.active) ? e.players.find((e) => e.faction === "riverfolk") : void 0, i = e.players.map((n) => ({
		rid: n.rid,
		faction: n.faction,
		n: D(e, n.rid, t) + e.pieces.filter((e) => e.owner === n.rid && e.clearing === t && w(e.kind)).reduce((e, t) => e + t.count, 0) + (r && n.rid === e.active ? D(e, r.rid, t) : 0)
	})), a = Math.max(0, ...i.map((e) => e.n));
	if (!a) return null;
	let o = i.filter((e) => e.n === a);
	return o.length === 1 ? o[0].rid : o.find((e) => e.faction === "eyrie")?.rid ?? null;
}
function X(e, t, n) {
	return Mt(e, t, n);
}
function Zt(e, t, n) {
	return [...new Set(Qt(e, t, n).map((e) => e.to))];
}
function Qt(e, t, n) {
	let r = E(e, t);
	if (n === 0 && (!e.game || r.faction !== "duchy" || !z(e, t).location) || n !== 0 && !D(e, t, n) || e.pieces.some((e) => e.clearing === n && e.owner !== t && e.kind === "plot" && e.faceUp && e.plot === "snare")) return [];
	let i = r.faction === "corvid", a = ue(e, n), o = r.faction === "riverfolk", s = e.game?.riverboats.includes(t), c = r.faction === "duchy" && e.game ? e.pieces.filter((e) => e.owner === t && e.kind === "tunnel").map((e) => e.clearing) : [], l = e.game?.ferry === n && !e.game.used.includes("ferry") ? S[e.map].coastal.filter((e) => e !== n) : [], u = n === 0 ? c.map((e) => ({
		to: e,
		via: "tunnel"
	})) : [
		...m(e, n).map((e) => ({
			to: e,
			via: "path"
		})),
		...o || s ? a.map((e) => ({
			to: e,
			via: "river"
		})) : [],
		...c.includes(n) ? [{
			to: 0,
			via: "tunnel"
		}] : [],
		...l.map((e) => ({
			to: e,
			via: "ferry"
		}))
	], d = /* @__PURE__ */ new Set();
	return u.filter(({ to: r, via: a }) => {
		let s = `${r}:${a === "ferry"}`;
		return d.has(s) || e.game?.scorched.includes(r) || !(i || o && a === "river" || Y(e, n) === t || Y(e, r) === t) ? !1 : (d.add(s), !0);
	});
}
function $t(e, n, r) {
	let i = e.command;
	return !!i && i.remaining > 0 && (i.kind === n || n === "move" && i.kind === "march") && (i.suit === null || t(e, i.suit, r));
}
//#endregion
//#region src/games/root/setup.ts
function en(t, r, i) {
	let a = $e.parse(t), o = a.factions.length ? [...new Set(a.factions)] : [..._], s = o.length + Number(o.includes("vagabond"));
	if (r.length < 2 || r.length > Math.min(6, s) || new Set(r).size !== r.length) throw Error("Root player count does not match the faction pool");
	let c = {
		version: 0,
		seed: i,
		cursor: 0,
		map: a.map,
		order: [...r],
		active: r[0],
		players: r.map((e) => ({
			rid: e,
			faction: "marquise",
			vp: 0,
			supply: 0,
			hand: [],
			effects: [],
			leader: null
		})),
		pieces: [],
		command: null,
		battle: null,
		hospitals: [],
		discard: [],
		log: [],
		winner: [],
		game: {
			map: a.map,
			suits: S[a.map].clearings.map((e) => e.suit),
			blocked: S[a.map].blocked.map((e) => [...e]),
			ferry: S[a.map].ferry,
			scorched: [],
			ruins: S[a.map].clearings.filter((e) => e.ruin).map((e) => ({
				clearing: e.id,
				items: ["boot"]
			})),
			deck: [],
			availableDominance: [],
			lostSouls: [],
			itemSupply: { ...n },
			questDeck: [],
			quests: [],
			boards: r.map(xt),
			tasks: [],
			interrupts: [],
			picked: [],
			round: 0,
			turn: 0,
			phase: "setup",
			actions: 0,
			used: [],
			crafted: [],
			decreeDone: [],
			servicesBought: 0,
			riverboats: [],
			mercenaries: [],
			plotsPlaced: 0,
			refresh: 0,
			configuredFactions: o
		}
	}, l = c.game;
	c.order = Ot(c, c.order), c.active = c.order[0], c.map !== "autumn" && (l.suits = Ot(c, [
		...p,
		...p,
		...p,
		...p
	])), l.deck = Ot(c, e().filter((e) => r.length > 2 || e.kind !== "dominance"));
	for (let e of c.order) E(c, e).hand = U(c, 3, e);
	return l.tasks = [...c.order.map((e) => ({
		kind: "draft",
		owner: e
	})), {
		kind: "setupFinish",
		owner: c.active
	}], c;
}
function tn(e, t, n) {
	let r = z(e, t);
	E(e, t).leader = n, r.leadersUsed.push(n), r.decree = r.decree.filter((e) => !e.vizier);
	for (let [e, i] of ne[n].entries()) r.decree.push({
		column: i,
		vizier: !0,
		card: {
			uid: `${t}:vizier:${e}`,
			id: "vizier",
			suit: "bird",
			kind: "persistent"
		}
	});
}
function nn(e) {
	let t = e.game.tasks[0], n = t.owner, r = z(e, n), a = E(e, n), o = S[e.map];
	if (t.kind === "draft") {
		let t = e.game.configuredFactions.length ? e.game.configuredFactions : _;
		return _.filter((n) => t.includes(n) && e.players.filter((t) => e.game.picked.includes(t.rid) && t.faction === n).length < (n === "vagabond" ? 2 : 1)).map((e) => F(e, (t) => {
			E(t, n).faction = e, E(t, n).supply = ie[e], e === "duchy" && (z(t, n).location = 0), t.game.picked.push(n), I(t);
		}));
	}
	if (t.kind === "setupCorner") {
		let t = o.clearings.filter((t) => t.corner && !e.game.boards.some((e) => e.starting === t.id)).map((e) => e.id);
		if (a.faction !== "marquise") {
			let n = o.diagonals.flatMap(([t, n]) => e.game.boards.some((e) => e.starting === t) ? [n] : e.game.boards.some((e) => e.starting === n) ? [t] : []).filter((e) => t.includes(e));
			n.length && (t = n);
		}
		return t.map((e) => F("chooseClearing", (t) => {
			if (z(t, n).starting = e, a.faction === "marquise") {
				G(t, n, "keep", e);
				let r = o.diagonals.find((t) => t.includes(e)).find((t) => t !== e);
				for (let e of o.clearings) e.id !== r && K(t, n, e.id);
			} else if (a.faction === "eyrie") K(t, n, e, 6), G(t, n, "roost", e);
			else if (a.faction === "cult") {
				K(t, n, e, 4), G(t, n, "garden", e);
				for (let r of m(t, e)) K(t, n, r);
			} else if (a.faction === "duchy") {
				K(t, n, e, 2), G(t, n, "tunnel", e);
				for (let r of m(t, e)) K(t, n, r, 2);
				z(t, n).location = 0;
			}
			I(t);
		}, {
			clearing: e,
			args: { n: e }
		}));
	}
	return t.kind === "setupCatBuilding" ? [r.starting, ...m(e, r.starting)].filter((t) => {
		let n = o.clearings.find((e) => e.id === t);
		return n.slots - Number(n.ruin) > e.pieces.filter((e) => e.clearing === t && [
			"sawmill",
			"workshop",
			"recruiter"
		].includes(e.kind)).length;
	}).map((e) => F("placeBuilding", (r) => {
		G(r, n, t.key, e), I(r);
	}, {
		clearing: e,
		args: {
			piece: t.key,
			n: e
		}
	})) : t.kind === "setupLeader" ? c.map((e) => F(e, (t) => {
		tn(t, n, e), I(t);
	})) : t.kind === "setupOutcast" ? p.map((e) => F(e, (t) => {
		z(t, n).outcast = e, I(t);
	})) : t.kind === "setupRiver" ? o.clearings.filter((t) => o.rivers.some((e) => e.includes(t.id)) && X(e, n, t.id)).map((e) => F("recruitAt", (t) => {
		K(t, n, e.id), --t.game.tasks[0].n === 0 && I(t);
	}, {
		clearing: e.id,
		args: {
			n: e.id,
			count: 1
		}
	})) : t.kind === "setupCorvid" ? i(e).filter((n) => n.suit === p[t.n ?? 0] && !e.pieces.some((e) => e.kind === "keep" && e.clearing === n.id)).map((e) => F("recruitAt", (t) => {
		K(t, n, e.id), ++t.game.tasks[0].n === 3 && I(t);
	}, {
		clearing: e.id,
		args: {
			n: e.id,
			count: 1
		}
	})) : t.kind === "setupCharacter" ? l.filter((t) => !e.game.boards.some((e) => e.character === t)).map((e) => F(e, (t) => {
		z(t, n).character = e;
		for (let r of me[e]) Lt(t, n, r, "starting");
		I(t);
	})) : t.kind === "setupForest" ? y(e).map((e) => F("chooseForest", (t) => {
		z(t, n).location = e, I(t);
	}, { args: { n: -e } })) : t.kind === "prices" ? [
		1,
		2,
		3,
		4
	].map((e) => F("setPrice", (r) => {
		z(r, n).prices[t.key] = e, I(r);
	}, { args: {
		service: t.key,
		n: e
	} })) : null;
}
function rn(e) {
	let t = e.game, n = t.tasks[0];
	if (n.kind === "setupFinish") {
		if (I(e), !t.tasks.length && t.picked.length === e.players.length && (t.tasks = e.order.map((t) => E(e, t)).sort((e, t) => _.indexOf(e.faction) - _.indexOf(t.faction)).map((e) => ({
			kind: "setupBegin",
			owner: e.rid
		})), t.tasks.push({
			kind: "setupFinish",
			owner: e.active,
			key: "begin"
		}), n.key === "begin")) {
			let n = e.players.filter((e) => e.faction === "vagabond").length;
			for (let e of t.ruins) e.items = [];
			for (let r = 0; r < Math.max(1, n); r++) {
				let n = Ot(e, t.ruins.map((e) => e.clearing));
				for (let [e, r] of [
					"sack",
					"boot",
					"hammer",
					"sword"
				].entries()) t.ruins.find((t) => t.clearing === n[e]).items.push(r);
			}
			n && (t.questDeck = Ot(e, s), t.quests = t.questDeck.splice(0, 3));
			for (let t of e.players) t.faction === "vagabond" && (z(e, t.rid).relationships = e.players.filter((e) => e.faction !== "vagabond").map((e) => ({
				owner: e.rid,
				level: 0,
				aids: 0
			})));
			t.tasks = [{
				kind: "turnStart",
				owner: e.order[0]
			}];
		}
		return !0;
	}
	if (n.kind !== "setupBegin") return !1;
	let r = n.owner, i = E(e, r).faction;
	I(e);
	let a = t.tasks;
	return i === "marquise" && a.unshift({
		kind: "setupCorner",
		owner: r
	}, ...[
		"sawmill",
		"workshop",
		"recruiter"
	].map((e) => ({
		kind: "setupCatBuilding",
		owner: r,
		key: e
	}))), i === "eyrie" && a.unshift({
		kind: "setupCorner",
		owner: r
	}, {
		kind: "setupLeader",
		owner: r
	}), i === "alliance" && It(e, r, U(e, 3)), i === "cult" && a.unshift({
		kind: "setupCorner",
		owner: r
	}, {
		kind: "setupOutcast",
		owner: r
	}), i === "riverfolk" && (E(e, r).supply -= 3, z(e, r).payments = [
		r,
		r,
		r
	], a.unshift({
		kind: "setupRiver",
		owner: r,
		n: 4
	}, ...[
		"card",
		"boats",
		"mercenaries"
	].map((e) => ({
		kind: "prices",
		owner: r,
		key: e
	})))), i === "duchy" && a.unshift({
		kind: "setupCorner",
		owner: r
	}), i === "corvid" && a.unshift({
		kind: "setupCorvid",
		owner: r,
		n: 0
	}), i === "vagabond" && a.unshift({
		kind: "setupCharacter",
		owner: r
	}, {
		kind: "setupForest",
		owner: r
	}), !0;
}
//#endregion
//#region src/games/root/engine.ts
var an = (e, t, n) => E(e, t).effects.some((e) => e.effect === n), on = (e, t, n) => e.usedEffects.some((e) => e.owner === t && e.effect === n), sn = (e, t) => t.count - (e.battle?.selectedLosses.filter((e) => e.piece === t.uid).reduce((e, t) => e + t.n, 0) ?? 0);
function cn(e, t, n, r, i = 0, a = null, o = null) {
	e.log.push({
		id: e.version,
		type: t,
		owner: n,
		clearing: r,
		n: i,
		target: a,
		from: o
	}), (t !== "move" || !e.game) && R(e, {
		kind: t,
		rid: n,
		data: {
			clearing: r,
			from: o,
			n: i,
			target: a,
			faction: Tt(e, n)
		}
	});
}
function ln(e, t) {
	let n = e.battle, r = E(e, t).effects.map((e) => e.effect).filter((e) => !on(n, t, e) && (e === "armorers" || e === "brutalTactics" && t === n.attacker || e === "sappers" && t === n.defender));
	return e.game && z(e, t).character === "ronin" && q(e, t, "sword").length && !on(n, t, "swiftStrike") && r.push("swiftStrike"), r;
}
function un(e) {
	if (e.winner.length) return null;
	let t = e.hospitals[0];
	if (t) return t.owner;
	let n = e.battle;
	return n ? n.stage === "ambush" ? n.defender : n.stage === "counter" ? n.attacker : n.stage === "effects" ? n.effectsOwner ?? e.active : n.stage === "hits" || n.stage === "ambushHits" ? n.hits.find((e) => e.remaining > 0)?.owner ?? null : null : e.command?.remaining ? e.command.owner : null;
}
function dn(e) {
	return e.winner.length || e.hospitals.length || !e.battle ? !1 : un(e) === null;
}
function fn(e, n) {
	if (un(e) !== n) return [];
	let r = [], a = (e, t, n = null, i = null) => r.push({
		kind: e,
		action: t,
		clearing: n,
		n: i
	}), o = E(e, n), s = e.hospitals[0], c = e.battle;
	if (s) {
		let i = e.pieces.find((e) => e.owner === n && e.kind === "keep");
		if (i && X(e, n, i.clearing)) for (let n of o.hand.filter((n) => t(e, n.suit, s.clearing))) a("hospital", {
			type: "card",
			uid: n.uid
		}, s.clearing, s.count);
		return a("pass", { type: "pass" }), r;
	}
	if (c) {
		if (c.stage === "ambush" || c.stage === "counter") {
			for (let n of o.hand.filter((n) => n.kind === "ambush" && t(e, n.suit, c.clearing))) a(c.stage === "ambush" ? "ambush" : "counter", {
				type: "card",
				uid: n.uid
			}, c.clearing, 2);
			a("pass", { type: "pass" });
		} else if (c.stage === "effects") {
			if (c.effectsOwner === null) for (let e of [c.attacker, c.defender].filter((e) => !c.effectsDone.includes(e))) a("effectOrder", {
				type: "effectOrder",
				owner: e
			});
			else {
				for (let t of ln(e, n)) a("effect", {
					type: "effect",
					effect: t
				});
				a("pass", { type: "pass" });
			}
		} else if (c.stage === "hits" || c.stage === "ambushHits") {
			if (e.game && o.faction === "vagabond") {
				for (let t of z(e, n).items.filter((e) => !e.damaged)) a("itemHit", {
					type: "itemHit",
					uid: t.uid
				}, c.clearing, 1);
				if (c.ally && n === c.attacker) for (let t of x(e, c.ally, c.clearing).filter((t) => t.kind === "warrior" && sn(e, t) > 0)) a("loss", {
					type: "loss",
					piece: t.uid
				}, c.clearing, 1);
				return r;
			}
			for (let t of x(e, n, c.clearing).filter((t) => t.kind !== "warrior" && sn(e, t) > 0)) a("loss", {
				type: "loss",
				piece: t.uid
			}, c.clearing, 1);
		}
		return r;
	}
	for (let t of [...i(e), ...e.game && o.faction === "duchy" ? [{ id: 0 }] : []]) {
		if ($t(e, "move", t.id)) for (let r of Qt(e, n, t.id)) for (let i = 1; i <= (t.id === 0 ? z(e, n).location : D(e, n, t.id)); i++) a("move", {
			type: "move",
			from: t.id,
			to: r.to,
			n: i,
			...r.via === "ferry" ? { via: "ferry" } : {}
		}, r.to, i);
		if ($t(e, "battle", t.id) && (Gt(e, n, t.id) || Ht(e, n, t.id))) for (let r of e.players.filter((r) => r.rid !== n && (Gt(e, n, t.id, r.rid) || Ht(e, n, t.id)) && (x(e, r.rid, t.id).length || Ht(e, r.rid, t.id)))) a("battle", {
			type: "battle",
			clearing: t.id,
			defender: r.rid
		}, t.id);
	}
	return (e.command?.kind === "march" || e.command?.source === "optional") && a("pass", { type: "pass" }), r;
}
function pn(e, t) {
	let n = e.battle;
	n.hits = [], n.selectedLosses = [];
	for (let r of t) {
		if (e.game && E(e, r.owner).faction === "vagabond") {
			let t = z(e, r.owner).items.filter((e) => !e.damaged).length + (r.owner === n.attacker && n.ally ? D(e, n.ally, n.clearing) : 0);
			n.hits.push({
				owner: r.owner,
				by: r.by,
				remaining: Math.min(r.n, t)
			});
			continue;
		}
		let t = Wt(e, r.owner, r.by), i = [...x(e, r.owner, n.clearing), ...t ? x(e, t, n.clearing).filter((e) => e.kind === "warrior") : []], a = Math.min(r.n, i.reduce((e, t) => e + t.count, 0));
		if (t) {
			let e = i.filter((e) => e.kind === "warrior" && e.owner === r.owner), o = i.filter((e) => e.kind === "warrior" && e.owner === t);
			for (let t = 0; t < r.n; t++) {
				let i = (t % 2 == 0 ? [...e, ...o] : [...o, ...e]).find((e) => e.count > n.selectedLosses.filter((t) => t.piece === e.uid).reduce((e, t) => e + t.n, 0));
				if (!i) break;
				n.selectedLosses.push({
					owner: i.owner,
					by: r.by,
					piece: i.uid,
					n: 1
				}), a--;
			}
			n.hits.push({
				owner: r.owner,
				by: r.by,
				remaining: a
			});
			continue;
		}
		for (let e of i.filter((e) => e.kind === "warrior")) {
			let t = Math.min(e.count, a);
			t && n.selectedLosses.push({
				owner: r.owner,
				by: r.by,
				piece: e.uid,
				n: t
			}), a -= t;
		}
		n.hits.push({
			owner: r.owner,
			by: r.by,
			remaining: a
		});
	}
}
function mn(e) {
	let t = e.battle;
	Kt(e, t.selectedLosses.map((e) => ({
		...e,
		by: t.instigator ?? e.by
	})), "battle"), t.selectedLosses = [], t.hits = [];
}
function hn(e) {
	e.battle?.ambushCard && (H(e, e.battle.ambushCard), e.battle.ambushCard = null);
}
function gn(e) {
	let t = e.battle;
	for (let n of [t.attacker, t.defender]) !t.effectsDone.includes(n) && !ln(e, n).length && t.effectsDone.push(n);
	let n = [t.attacker, t.defender].filter((e) => !t.effectsDone.includes(e));
	if (t.effectsOwner = n.length === 1 ? n[0] : null, n.length) return;
	let r = t.dice, i = Math.max(...r), a = Math.min(...r), o = E(e, t.defender).faction === "alliance", s = Math.min(Gt(e, t.attacker, t.clearing, t.defender) + (t.ally ? D(e, t.ally, t.clearing) : 0), o ? a : i), c = Math.min(Gt(e, t.defender, t.clearing, t.attacker) + (t.arbiter ? Rt(e, t.arbiter) : 0), o ? i : a), l = on(t, t.attacker, "armorers") ? 0 : c, u = on(t, t.defender, "armorers") ? 0 : s;
	Gt(e, t.defender, t.clearing, t.attacker) || (u += 1), E(e, t.attacker).faction === "eyrie" && E(e, t.attacker).leader === "commander" && (u += 1), on(t, t.attacker, "brutalTactics") && (u += 1), on(t, t.defender, "sappers") && (l += 1), on(t, t.attacker, "swiftStrike") && (u += 1), on(t, t.defender, "swiftStrike") && (l += 1), E(e, t.defender).faction === "corvid" && e.pieces.some((e) => e.owner === t.defender && e.clearing === t.clearing && e.kind === "plot" && !e.faceUp) && (l += 1), pn(e, [{
		owner: t.attacker,
		by: t.defender,
		n: l
	}, {
		owner: t.defender,
		by: t.attacker,
		n: u
	}]), t.stage = "hits";
}
function _n(e, t, n, r) {
	let i = e.pieces.find((e) => e.owner === t && e.kind === "warrior" && e.clearing === n);
	i ? i.count += r : e.pieces.push({
		uid: `${t}:warriors:${e.version}`,
		owner: t,
		kind: "warrior",
		clearing: n,
		count: r,
		faceUp: !0,
		plot: null
	});
}
function vn(e) {
	let t = e.battle;
	if (t.stage === "roll") t.dice = [be(e.seed, e.cursor++, 4), be(e.seed, e.cursor++, 4)], t.stage = "effects", cn(e, "roll", t.attacker, t.clearing, Math.max(...t.dice), t.defender), gn(e);
	else if (t.stage === "ambushHits" || t.stage === "hits") {
		let n = t.stage === "ambushHits";
		mn(e), n ? (hn(e), t.stage = "ambushAftermath") : t.stage = "result";
	} else t.stage === "ambushAftermath" ? t.stage = Gt(e, t.attacker, t.clearing, t.defender) || Ht(e, t.attacker, t.clearing) ? "roll" : "result" : t.stage === "result" && (e.game && t.ally && (t.allyHits ?? 0) > (t.itemHits ?? 0) && (z(e, t.attacker).relationships.find((e) => e.owner === t.ally).level = -1), cn(e, "complete", t.attacker, t.clearing, 0, t.defender), e.battle = null);
}
function yn(e, t, n, r = []) {
	return wt(bn(e, t, n, r));
}
function bn(e, t, n, r) {
	let i = ut.safeParse(t);
	if (!i.success || e.winner.length) return null;
	let a = i.data;
	if (a.type === "tick") {
		if (n !== "$engine" || !dn(e)) return null;
		let t = Ct(e, r);
		return t.version++, vn(t), t;
	}
	if (!fn(e, n).some((e) => JSON.stringify(e.action) === JSON.stringify(a))) return null;
	let o = Ct(e, r);
	o.version++;
	let s = E(o, n), c = o.hospitals[0], l = o.battle;
	if (c) {
		if (a.type === "card") {
			let e = s.hand.findIndex((e) => e.uid === a.uid);
			R(o, {
				kind: "card",
				rid: n,
				data: {
					faction: s.faction,
					clearing: c.clearing
				}
			}), H(o, ...s.hand.splice(e, 1));
			let t = o.pieces.find((e) => e.owner === n && e.kind === "keep");
			s.supply -= c.count, _n(o, n, t.clearing, c.count), cn(o, "hospital", n, t.clearing, c.count, null, c.clearing);
		} else cn(o, "skipHospital", n, c.clearing, c.count);
		return o.hospitals.shift(), o;
	}
	if (l) {
		if (a.type === "card") {
			let e = s.hand.splice(s.hand.findIndex((e) => e.uid === a.uid), 1)[0];
			R(o, {
				kind: "card",
				rid: n,
				data: {
					faction: s.faction,
					clearing: l.clearing,
					card: e
				}
			}), l.stage === "ambush" ? (l.ambushCard = e, l.stage = "counter", cn(o, "ambush", n, l.clearing, 2, l.attacker)) : (H(o, e), hn(o), l.stage = "roll", cn(o, "counter", n, l.clearing, 0, l.defender));
		} else if (a.type === "pass") l.stage === "ambush" ? l.stage = "roll" : l.stage === "counter" ? (l.stage = "ambushHits", pn(o, [{
			owner: l.attacker,
			by: l.defender,
			n: 2
		}])) : (l.effectsDone.push(n), gn(o));
		else if (a.type === "loss") {
			let e = l.hits.find((e) => e.owner === n && e.remaining > 0), t = o.pieces.find((e) => e.uid === a.piece).owner;
			l.selectedLosses.push({
				owner: t,
				by: e.by,
				piece: a.piece,
				n: 1
			}), l.ally && t === l.ally && (l.allyHits = (l.allyHits ?? 0) + 1), e.remaining--, R(o, {
				kind: "assign",
				rid: n,
				data: {
					clearing: l.clearing,
					n: 1
				}
			});
		} else if (a.type === "itemHit") zt(o, n, a.uid, { damaged: !0 }), l.itemHits = (l.itemHits ?? 0) + 1, l.hits.find((e) => e.owner === n && e.remaining > 0).remaining--;
		else if (a.type === "effectOrder") l.effectsOwner = a.owner;
		else if (a.type === "effect") {
			if (l.usedEffects.push({
				owner: n,
				effect: a.effect
			}), a.effect === "armorers" || a.effect === "sappers") {
				let e = s.effects.findIndex((e) => e.effect === a.effect);
				H(o, s.effects.splice(e, 1)[0].card);
			}
			a.effect === "brutalTactics" && (V(o, l.defender, 1), At(o)), a.effect === "swiftStrike" && Bt(o, n, [q(o, n, "sword")[0].uid]), cn(o, "effect", n, l.clearing, 0, a.effect), ln(o, n).length || (l.effectsDone.push(n), gn(o));
		}
		return o;
	}
	if (a.type === "move") {
		if (o.game) return Pt(o, n, a.from, a.to, a.n), a.via === "ferry" && (o.game.ferry = a.to, o.game.used.push("ferry"), s.hand.push(...U(o, 1, n))), o.command.remaining--, cn(o, "move", n, a.to, a.n, null, a.from), o;
		let e = a.n;
		for (let t of x(o, n, a.from).filter((e) => e.kind === "warrior")) {
			let n = Math.min(t.count, e);
			t.count -= n, e -= n;
		}
		o.pieces = o.pieces.filter((e) => e.count > 0), _n(o, n, a.to, a.n), o.command.remaining--, cn(o, "move", n, a.to, a.n, null, a.from);
	} else a.type === "battle" ? (o.command.remaining--, o.battle = {
		clearing: a.clearing,
		attacker: n,
		defender: a.defender,
		stage: an(o, n, "scoutingParty") ? "roll" : "ambush",
		ambushCard: null,
		dice: null,
		effectsDone: [],
		effectsOwner: null,
		usedEffects: [],
		hits: [],
		selectedLosses: [],
		despotAwarded: []
	}, cn(o, "battle", n, a.clearing, 0, a.defender)) : a.type === "pass" && (o.command.remaining = 0);
	return o;
}
//#endregion
//#region src/games/root/actions.ts
function Z(e, t, n, r = 1, i = "action", a = null) {
	e.command = {
		owner: t,
		kind: n,
		remaining: r,
		source: i,
		suit: a
	}, J(e, {
		kind: "command",
		owner: t
	});
}
function xn(e, t, n, r, i = null, a = null) {
	e.battle = {
		clearing: r,
		attacker: t,
		defender: n,
		stage: E(e, t).effects.some((e) => e.effect === "scoutingParty") ? "roll" : "ambush",
		ambushCard: null,
		dice: null,
		effectsDone: [],
		effectsOwner: null,
		usedEffects: [],
		hits: [],
		selectedLosses: [],
		despotAwarded: [],
		ally: i,
		instigator: a,
		allyHits: 0,
		itemHits: 0
	}, e.log.push({
		id: e.version,
		type: "battle",
		owner: t,
		target: n,
		clearing: r,
		from: null,
		n: 0
	}), R(e, {
		kind: "battle",
		rid: t,
		data: {
			clearing: r,
			faction: Tt(e, t)
		}
	});
}
var Sn = (e, t) => [...i(e).filter((n) => D(e, t, n.id)).map((e) => e.id), ...E(e, t).faction === "duchy" && z(e, t).location ? [0] : []], Cn = (e, n, r = null) => Sn(e, n).some((i) => (!r || t(e, r, i)) && Zt(e, n, i).length), wn = (e, n, r = null) => i(e).filter((i) => (!r || t(e, r, i.id)) && e.players.some((t) => t.rid !== n && Ut(e, t.rid, i.id) && (Gt(e, n, i.id, t.rid) || Ht(e, n, i.id)))).map((e) => e.id);
function Tn(e, t) {
	let n = E(e, t), r = e.game, i = z(e, t);
	if (n.faction === "vagabond") return i.location > 0 ? q(e, t, "hammer").map((t) => ({
		uid: t.uid,
		suit: v(e, i.location).suit,
		location: i.location
	})) : [];
	if (n.faction === "riverfolk") return p.flatMap((n) => Array.from({ length: B(e, t, "tradePost", n) + i.tradePostsLost.filter((e) => e === n).length }, (e, t) => ({
		uid: `post:${n}:${t}`,
		suit: n,
		location: 0
	}))).filter((e) => !r.crafted.includes(e.uid));
	let a = {
		marquise: ["workshop"],
		eyrie: ["roost"],
		alliance: ["sympathy"],
		cult: ["garden"],
		duchy: ["citadel", "market"],
		corvid: ["plot"]
	}[n.faction];
	return e.pieces.filter((n) => n.owner === t && a.includes(n.kind) && !r.crafted.includes(n.uid) && (E(e, t).faction !== "cult" || v(e, n.clearing).suit === i.outcast)).map((t) => ({
		uid: t.uid,
		suit: v(e, t.clearing).suit,
		location: t.clearing
	}));
}
function En(e, t, n) {
	let r = g(n), i = z(e, t);
	return !r?.cost.length || r.item && !e.game.itemSupply[r.item] || r.effect && E(e, t).effects.some((e) => e.effect === r.effect) || E(e, t).faction === "riverfolk" && i.funds.length < r.cost.length ? [] : bt(Tn(e, t), r.cost.length).filter((e) => {
		let t = e.map((e) => e.suit);
		for (let e of r.cost) if (e !== "any") {
			let n = t.indexOf(e);
			if (n < 0) return !1;
			t.splice(n, 1);
		}
		return !0;
	});
}
function Dn(e, t, n) {
	let r = /* @__PURE__ */ new Set();
	return bt(z(e, t).funds, n).filter((e) => {
		let t = [...e].sort().join("|");
		return !r.has(t) && (r.add(t), !0);
	});
}
function On(e, t, n, r = !1) {
	let i = z(e, t);
	for (let t of n) i.funds.splice(i.funds.indexOf(t), 1), r ? E(e, t).supply++ : i.committed.push(t);
	R(e, {
		kind: "funds",
		rid: t,
		data: { n: n.length }
	});
}
function kn(e, t, n, r, a, o) {
	let s = E(e, t), c = g(n), l = z(e, t), u = W(e, t, n.uid);
	if (R(e, {
		kind: "craft",
		rid: t,
		data: {
			card: u,
			locations: r.map((e) => e.location),
			item: c.item ?? null,
			faction: s.faction
		}
	}), s.faction === "vagabond" ? Bt(e, t, r.map((e) => e.uid)) : e.game.crafted.push(...r.map((e) => e.uid)), s.faction === "riverfolk" && On(e, t, a), o) {
		H(e, u), s.supply && (s.supply--, l.payments.push(t));
		return;
	}
	c.item ? (e.game.itemSupply[c.item]--, s.faction === "vagabond" ? Lt(e, t, c.item) : l.craftedItems.push(c.item), V(e, t, s.faction === "eyrie" && s.leader !== "builder" ? 1 : c.vp), H(e, u)) : c.effect ? s.effects.push({
		effect: c.effect,
		card: u
	}) : c.favor && (H(e, u), qt(e, t, i(e).filter((e) => e.suit === c.favor).map((e) => e.id)));
}
function An(e) {
	let t = e.game.tasks[0], n = t.owner, r = E(e, n);
	if (!t.card) return [...r.hand.filter((t) => En(e, n, t).length).map((e) => F("craftCard", (t) => {
		t.game.tasks[0].card = e;
	}, {
		args: {
			card: e.id,
			cardUid: e.uid,
			suit: e.suit
		},
		weight: 30 + (g(e)?.vp ?? 0)
	})), L("finishCraft")];
	let i = t.card, a = En(e, n, i), o = r.faction === "riverfolk" ? Dn(e, n, g(i).cost.length) : [[]];
	return [...a.flatMap((t) => o.flatMap((a) => [!1, ...r.faction === "riverfolk" ? [!0] : []].map((r) => F(r ? "exportCard" : "craftWith", (e) => {
		kn(e, n, i, t, a, r), delete e.game.tasks[0].card;
	}, {
		args: {
			places: t.map((e) => e.location || e.suit).join(", "),
			funds: a.map((t) => E(e, t).faction).join(", "),
			card: i.id,
			cardUid: i.uid
		},
		weight: r ? 0 : 30 + (g(i)?.vp ?? 0)
	})))), F("cancel", (e) => {
		delete e.game.tasks[0].card;
	}, { weight: -100 })];
}
function jn(e, t) {
	let n = [], a = E(e, t), o = z(e, t), s = e.game;
	for (let r of a.hand.filter((e) => e.kind === "dominance" && a.vp >= 10 && !o.dominance && !o.coalition)) if (a.faction === "vagabond") {
		if (e.players.length < 4) continue;
		let i = e.players.filter((e) => e.rid !== t && e.faction !== "vagabond" && !s.boards.some((t) => t.coalition === e.rid)), a = Math.min(...e.players.filter((e) => e.rid !== t).map((e) => e.vp));
		for (let e of i.filter((e) => e.vp === a)) n.push(F("coalitionWith", (n) => {
			let i = z(n, t);
			i.dominance = W(n, t, r.uid), i.coalition = e.rid;
			let a = i.relationships.find((t) => t.owner === e.rid);
			a && (a.level = 0);
		}, {
			args: {
				faction: e.faction,
				card: r.id,
				cardUid: r.uid
			},
			weight: -10
		}));
	} else n.push(F("activateDominance", (e) => {
		z(e, t).dominance = W(e, t, r.uid);
	}, {
		args: {
			suit: r.suit,
			card: r.id,
			cardUid: r.uid
		},
		weight: -30
	}));
	for (let e of s.availableDominance) for (let r of a.hand.filter((t) => Dt(t, e.suit))) n.push(F("takeDominance", (n) => {
		H(n, W(n, t, r.uid)), n.game.availableDominance = n.game.availableDominance.filter((t) => t.uid !== e.uid), E(n, t).hand.push(e);
	}, {
		args: {
			suit: e.suit,
			card: r.id,
			cardUid: r.uid
		},
		weight: -20
	}));
	for (let r of a.effects.filter((e) => !s.used.includes(e.effect))) {
		if (r.effect === "codebreakers") for (let r of e.players.filter((e) => e.rid !== t && e.hand.length)) n.push(F("inspectHand", (e) => {
			e.game.used.push("codebreakers"), e.game.interrupts.push({
				kind: "peek",
				owner: t,
				target: r.rid
			});
		}, {
			args: { faction: r.faction },
			weight: 1
		}));
		if (r.effect === "taxCollector") for (let r of i(e).filter((n) => D(e, t, n.id))) n.push(F("collectTax", (e) => {
			e.game.used.push("taxCollector"), Nt(e, t, r.id, 1), E(e, t).hand.push(...U(e, 1, t));
		}, {
			clearing: r.id,
			args: { n: r.id },
			weight: 10
		}));
	}
	if (s.phase === "daylight" && !s.used.includes("clearPath")) for (let i of s.blocked.filter((n) => n.some((n) => Ut(e, t, n)))) for (let e of a.hand) n.push(F("clearPath", (n) => {
		H(n, W(n, t, e.uid)), n.game.blocked = n.game.blocked.filter((e) => r(e[0], e[1]) !== r(i[0], i[1])), n.game.used.push("clearPath"), V(n, t, 1);
	}, {
		args: {
			from: i[0],
			to: i[1],
			card: e.id,
			cardUid: e.uid
		},
		weight: 20
	}));
	return n;
}
function Mn(e, n) {
	let r = [];
	for (let i of e.pieces.filter((t) => t.kind === "plot" && !t.faceUp && t.owner !== n && Ut(e, n, t.clearing))) for (let a of E(e, n).hand.filter((n) => t(e, n.suit, i.clearing))) for (let e of [
		"bomb",
		"snare",
		"extortion",
		"raid"
	]) r.push(F("exposePlot", (t) => {
		i.plot === e ? Kt(t, [{
			piece: i.uid,
			by: n,
			n: 1
		}], "exposure") : E(t, i.owner).hand.push(W(t, n, a.uid));
	}, {
		clearing: i.clearing,
		args: {
			n: i.clearing,
			plot: e,
			card: a.id,
			cardUid: a.uid,
			suit: a.suit
		},
		weight: -25
	}));
	return r;
}
//#endregion
//#region src/games/root/factions-base.ts
function Nn(e, t, n) {
	let r = /* @__PURE__ */ new Set(), i = [n];
	for (; i.length;) {
		let n = i.shift();
		r.has(n) || Y(e, n) !== t || (r.add(n), i.push(...ve(e, t, n)));
	}
	return [...r];
}
function Pn(e, n) {
	let r = e.game, a = [];
	if (r.actions > 0) {
		Cn(e, n) && a.push(F("march", (e) => {
			e.game.actions--, Z(e, n, "march", 2);
		}, { weight: 15 })), wn(e, n).length && a.push(F("battle", (e) => {
			e.game.actions--, Z(e, n, "battle");
		}, { weight: 10 }));
		let s = e.pieces.filter((t) => t.owner === n && t.kind === "recruiter" && X(e, n, t.clearing)).map((e) => e.clearing);
		!r.used.includes("recruit") && s.length && E(e, n).supply && a.push(F("recruit", (e) => {
			e.game.actions--, e.game.used.push("recruit"), J(e, {
				kind: "recruit",
				owner: n,
				locations: s
			});
		}, { weight: 25 }));
		for (let t of [
			"sawmill",
			"workshop",
			"recruiter"
		]) {
			let r = B(e, n, t);
			if (!(r >= 6)) for (let s of i(e).filter((t) => Y(e, t.id) === n && X(e, n, t.id) && Jt(e, t.id) > 0)) {
				let i = Nn(e, n, s.id);
				e.pieces.filter((e) => e.owner === n && e.kind === "wood" && i.includes(e.clearing)).reduce((e, t) => e + t.count, 0) < h[r] || a.push(F("buildAt", (e) => {
					e.game.actions--, J(e, {
						kind: "woodPayment",
						owner: n,
						location: s.id,
						n: h[r],
						key: t,
						locations: i
					});
				}, {
					clearing: s.id,
					args: {
						piece: t,
						n: s.id,
						cost: h[r],
						vp: o[t][r]
					},
					weight: 40 + o[t][r]
				}));
			}
		}
		if (B(e, n, "wood") < 8) for (let r of e.pieces.filter((t) => t.owner === n && t.kind === "sawmill" && X(e, n, t.clearing))) for (let i of E(e, n).hand.filter((n) => t(e, n.suit, r.clearing))) a.push(F("overworkAt", (e) => {
			H(e, W(e, n, i.uid)), G(e, n, "wood", r.clearing), e.game.actions--;
		}, {
			clearing: r.clearing,
			args: {
				n: r.clearing,
				card: i.id,
				cardUid: i.uid
			},
			weight: 20
		}));
	}
	for (let t of E(e, n).hand.filter((e) => e.suit === "bird")) a.push(F("extraAction", (e) => {
		H(e, W(e, n, t.uid)), e.game.actions++;
	}, {
		args: {
			card: t.id,
			cardUid: t.uid
		},
		weight: r.actions ? -5 : 25
	}));
	return a;
}
function Fn(e) {
	let n = e.game, r = n.tasks[0], a = r.owner, o = z(e, a), s = E(e, a);
	if (r.kind === "woodPayment") return e.pieces.filter((e) => e.owner === a && e.kind === "wood" && r.locations.includes(e.clearing)).map((e) => F("spendWood", (t) => {
		let n = t.pieces.find((t) => t.uid === e.uid);
		n.count--, t.pieces = t.pieces.filter((e) => e.count > 0), t.game.tasks[0].n--, R(t, {
			kind: "piece",
			rid: a,
			data: {
				mode: "remove",
				clearing: e.clearing,
				kind: "wood",
				n: 1,
				faction: "marquise"
			}
		});
	}, {
		clearing: e.clearing,
		args: { n: e.clearing }
	}));
	if (r.kind === "recruit") return r.locations.filter((t) => X(e, a, t)).map((e) => F("recruitAt", (t) => {
		K(t, a, e), t.game.tasks[0].locations.splice(t.game.tasks[0].locations.indexOf(e), 1);
	}, {
		clearing: e,
		args: {
			n: e,
			count: 1
		}
	}));
	if (r.kind === "decreeAdd") {
		let e = s.hand.filter((e) => e.suit !== "bird" || !n.used.includes("decreeBird")).flatMap((e) => f.map((t) => F("addDecree", (n) => {
			let r = W(n, a, e.uid);
			z(n, a).decree.push({
				column: t,
				card: r,
				vizier: !1
			}), r.suit === "bird" && n.game.used.push("decreeBird"), R(n, {
				kind: "decree",
				rid: a,
				data: {
					card: r,
					column: t
				}
			}), n.game.tasks[0].n = (n.game.tasks[0].n ?? 0) + 1, (n.game.tasks[0].n === 2 || !E(n, a).hand.length) && I(n);
		}, {
			args: {
				card: e.id,
				cardUid: e.uid,
				suit: e.suit,
				column: t
			},
			weight: (t === "move" ? 10 : t === "recruit" ? 6 : 0) + Number(e.suit === "bird") * 5
		})));
		return r.n && e.push(L()), e;
	}
	if (r.kind === "emergencyRoost") {
		if (B(e, a, "roost")) return [];
		let t = i(e).filter((t) => X(e, a, t.id) && Jt(e, t.id) > 0), n = Math.min(...t.map((t) => e.pieces.filter((e) => e.clearing === t.id && e.kind === "warrior").reduce((e, t) => e + t.count, 0)));
		return t.filter((t) => e.pieces.filter((e) => e.clearing === t.id && e.kind === "warrior").reduce((e, t) => e + t.count, 0) === n).map((e) => F("emergencyRoostAt", (t) => {
			G(t, a, "roost", e.id), K(t, a, e.id, 3), I(t);
		}, {
			clearing: e.id,
			args: { n: e.id }
		}));
	}
	if (r.kind === "decree") {
		let r = o.decree.filter((e) => !n.decreeDone.includes(e.card.uid)), c = f.find((e) => r.some((t) => t.column === e));
		if (!c) return [];
		let l = [];
		for (let n of r.filter((e) => e.column === c)) {
			let r = (e) => e.game.decreeDone.push(n.card.uid);
			if (c === "move" && Cn(e, a, n.card.suit) && l.push(F("fulfillMove", (e) => {
				r(e), Z(e, a, "move", 1, "decree", n.card.suit);
			}, { args: { suit: n.card.suit } })), c === "battle" && wn(e, a, n.card.suit).length && l.push(F("fulfillBattle", (e) => {
				r(e), Z(e, a, "battle", 1, "decree", n.card.suit);
			}, { args: { suit: n.card.suit } })), c === "recruit") {
				let i = s.leader === "charismatic" ? 2 : 1;
				if (s.supply < i) continue;
				for (let o of e.pieces.filter((r) => r.owner === a && r.kind === "roost" && X(e, a, r.clearing) && t(e, n.card.suit, r.clearing))) l.push(F("recruitAt", (e) => {
					r(e), K(e, a, o.clearing, i);
				}, {
					clearing: o.clearing,
					args: {
						n: o.clearing,
						count: i
					}
				}));
			}
			if (c === "build" && B(e, a, "roost") < 7) for (let o of i(e).filter((r) => t(e, n.card.suit, r.id) && Y(e, r.id) === a && X(e, a, r.id) && Jt(e, r.id) > 0 && !e.pieces.some((e) => e.owner === a && e.kind === "roost" && e.clearing === r.id))) l.push(F("placeRoost", (e) => {
				r(e), G(e, a, "roost", o.id);
			}, {
				clearing: o.id,
				args: { n: o.id }
			}));
		}
		return l;
	}
	if (r.kind === "turmoil") {
		let e = c.filter((e) => !o.leadersUsed.includes(e));
		return (e.length ? e : [...c]).map((t) => F(t, (n) => {
			let r = z(n, a);
			e.length || (r.leadersUsed = []), tn(n, a, t), I(n);
		}));
	}
	if (r.kind === "allianceRevolt") {
		let t = [];
		for (let n of e.pieces.filter((e) => e.owner === a && e.kind === "sympathy")) {
			let r = v(e, n.clearing).suit;
			!X(e, a, n.clearing) || Jt(e, n.clearing) + e.pieces.filter((e) => e.clearing === n.clearing && e.owner !== a && [
				"sawmill",
				"workshop",
				"recruiter",
				"roost",
				"base",
				"garden",
				"citadel",
				"market"
			].includes(e.kind)).length <= 0 || B(e, a, "base", r) || o.supporters.filter((e) => Dt(e, r)).length < 2 || t.push(F("revoltAt", (e) => J(e, {
				kind: "payCards",
				owner: a,
				n: 2,
				suit: r,
				location: n.clearing,
				key: "revolt"
			}), {
				clearing: n.clearing,
				args: { n: n.clearing },
				weight: 50
			}));
		}
		return [...t, L("finishRevolt")];
	}
	if (r.kind === "allianceSpread") {
		let t = B(e, a, "sympathy");
		if (t >= 10) return [L("finishSpread")];
		let n = e.pieces.filter((e) => e.owner === a && e.kind === "sympathy").flatMap((t) => ve(e, a, t.clearing));
		return [...i(e).filter((r) => (!t || n.includes(r.id)) && X(e, a, r.id) && !e.pieces.some((e) => e.owner === a && e.kind === "sympathy" && e.clearing === r.id)).flatMap((n) => {
			let r = u[t] + Number(e.players.some((t) => t.rid !== a && D(e, t.rid, n.id) >= 3));
			return o.supporters.filter((e) => Dt(e, n.suit)).length >= r ? [F("spreadAt", (e) => J(e, {
				kind: "payCards",
				owner: a,
				n: r,
				suit: n.suit,
				location: n.id,
				key: "spread"
			}), {
				clearing: n.id,
				args: {
					n: n.id,
					cost: r,
					vp: re[t]
				},
				weight: 40 + re[t]
			})] : [];
		}), L("finishSpread")];
	}
	if (r.kind === "payCards") return o.supporters.filter((e) => Dt(e, r.suit)).map((e) => F("spendSupporter", (t) => {
		let n = z(t, a).supporters;
		H(t, ...n.splice(n.findIndex((t) => t.uid === e.uid), 1)), t.game.tasks[0].n--;
	}, { args: {
		card: e.id,
		cardUid: e.uid,
		suit: e.suit
	} }));
	if (r.kind === "allianceOps") {
		let t = [];
		if (n.actions > 0) {
			if (Cn(e, a) && t.push(F("move", (e) => {
				e.game.actions--, Z(e, a, "move");
			}, { weight: 15 })), wn(e, a).length && t.push(F("battle", (e) => {
				e.game.actions--, Z(e, a, "battle");
			}, { weight: 10 })), s.supply) for (let n of e.pieces.filter((t) => t.owner === a && t.kind === "base" && X(e, a, t.clearing))) t.push(F("recruitAt", (e) => {
				e.game.actions--, K(e, a, n.clearing);
			}, {
				clearing: n.clearing,
				args: {
					n: n.clearing,
					count: 1
				},
				weight: 25
			}));
			if (B(e, a, "sympathy") < 10) for (let n of i(e).filter((t) => D(e, a, t.id) && X(e, a, t.id) && !e.pieces.some((e) => e.owner === a && e.kind === "sympathy" && e.clearing === t.id))) t.push(F("organizeAt", (e) => {
				e.game.actions--, Nt(e, a, n.id, 1);
				let t = B(e, a, "sympathy");
				G(e, a, "sympathy", n.id), V(e, a, re[t]);
			}, {
				clearing: n.id,
				args: {
					n: n.id,
					vp: re[B(e, a, "sympathy")]
				},
				weight: 45
			}));
		}
		return [...t, L("finishActions")];
	}
	return null;
}
function In(e, n) {
	let r = [], i = E(e, n);
	for (let a of i.hand) r.push(F("mobilizeCard", (e) => It(e, n, [W(e, n, a.uid)]), {
		args: {
			card: a.id,
			cardUid: a.uid,
			suit: a.suit
		},
		weight: 20
	})), i.supply && e.pieces.some((r) => r.owner === n && r.kind === "base" && t(e, a.suit, r.clearing)) && r.push(F("trainOfficer", (e) => {
		H(e, W(e, n, a.uid)), E(e, n).supply--, z(e, n).officers++;
	}, {
		args: {
			card: a.id,
			cardUid: a.uid,
			suit: a.suit
		},
		weight: z(e, n).officers < 3 ? 30 : 5
	}));
	return r;
}
function Ln(e) {
	let t = e.game, n = t.tasks[0], r = n.owner, i = E(e, r), a = z(e, r);
	if (n.kind === "woodPayment" && !n.n) {
		let t = n.key, i = B(e, r, t);
		return G(e, r, t, n.location), V(e, r, o[t][i]), I(e), !0;
	}
	if (n.kind === "recruit" && (!n.locations?.length || !i.supply) || n.kind === "emergencyRoost" && B(e, r, "roost")) return I(e), !0;
	if (n.kind === "decree" && !Fn(e).length) return a.decree.some((e) => !t.decreeDone.includes(e.card.uid)) ? (V(e, r, -a.decree.filter((e) => e.card.suit === "bird").length), H(e, ...a.decree.filter((e) => !e.vizier).map((e) => e.card)), a.decree = [], i.leader = null, t.tasks = t.tasks.filter((e) => e.kind !== "decree"), J(e, {
		kind: "turmoil",
		owner: r
	})) : I(e), !0;
	if (n.kind === "payCards" && !n.n) {
		let t = n.location;
		if (n.key === "spread") {
			let n = B(e, r, "sympathy");
			G(e, r, "sympathy", t), V(e, r, re[n]);
		} else qt(e, r, [t]), G(e, r, "base", t), K(e, r, t, B(e, r, "sympathy", v(e, t).suit)), i.supply && (i.supply--, a.officers++);
		return I(e), !0;
	}
	return !1;
}
//#endregion
//#region src/games/root/factions-expansions.ts
function Rn(e, t) {
	let n = [], r = E(e, t);
	for (let a of r.hand) {
		let o = (e) => z(e, t).revealed.push(W(e, t, a.uid));
		if (a.suit === "bird") {
			r.supply && n.push(F("sacrifice", (e) => {
				o(e), E(e, t).supply--, z(e, t).acolytes++;
			}, {
				args: {
					card: a.id,
					cardUid: a.uid
				},
				weight: 20
			}));
			continue;
		}
		let s = B(e, t, "garden", a.suit);
		s > 0 && !e.game.used.includes(`score:${a.suit}`) && n.push(F("cultScore", (e) => {
			H(e, W(e, t, a.uid)), V(e, t, ye[s]), e.game.used.push(`score:${a.suit}`);
		}, {
			args: {
				suit: a.suit,
				vp: ye[s],
				card: a.id,
				cardUid: a.uid
			},
			weight: 50 + ye[s]
		}));
		for (let c of i(e).filter((n) => n.suit === a.suit && X(e, t, n.id))) r.supply && n.push(F("ritualRecruit", (e) => {
			o(e), K(e, t, c.id);
		}, {
			clearing: c.id,
			args: {
				n: c.id,
				card: a.id,
				cardUid: a.uid
			},
			weight: 15
		})), s < 5 && Jt(e, c.id) > 0 && Y(e, c.id) === t && n.push(F("ritualBuild", (e) => {
			o(e), G(e, t, "garden", c.id);
		}, {
			clearing: c.id,
			args: {
				n: c.id,
				card: a.id,
				cardUid: a.uid
			},
			weight: 40
		}));
	}
	return n;
}
function zn(e, t) {
	let n = [], r = z(e, t), a = E(e, t);
	for (let o of [...new Set(r.funds)]) if (Cn(e, t) && n.push(F("fundMove", (e) => {
		On(e, t, [o]), Z(e, t, "move");
	}, {
		args: { faction: E(e, o).faction },
		weight: 10
	})), wn(e, t).length && n.push(F("fundBattle", (e) => {
		On(e, t, [o]), Z(e, t, "battle");
	}, {
		args: { faction: E(e, o).faction },
		weight: 10
	})), (e.game.deck.length || e.discard.length) && n.push(F("fundDraw", (e) => {
		On(e, t, [o]), E(e, t).hand.push(...U(e, 1, t));
	}, {
		args: { faction: E(e, o).faction },
		weight: 5
	})), a.supply || o === t) for (let r of i(e).filter((n) => S[e.map].rivers.some((e) => e.includes(n.id)) && X(e, t, n.id))) n.push(F("fundRecruit", (e) => {
		On(e, t, [o], !0), K(e, t, r.id);
	}, {
		clearing: r.id,
		args: {
			faction: E(e, o).faction,
			n: r.id
		},
		weight: 20
	}));
	for (let a of i(e).filter((n) => X(e, t, n.id) && !e.pieces.some((e) => e.kind === "tradePost" && e.clearing === n.id))) {
		let i = Y(e, a.id);
		!i || r.funds.filter((e) => e === i).length < 2 || B(e, t, "tradePost", a.suit) + r.tradePostsLost.filter((e) => e === a.suit).length >= 3 || n.push(F("establishPost", (e) => {
			On(e, t, [i, i], !0), G(e, t, "tradePost", a.id), K(e, t, a.id), V(e, t, 2);
		}, {
			clearing: a.id,
			args: {
				n: a.id,
				faction: E(e, i).faction
			},
			weight: 45
		}));
	}
	return n;
}
function Bn(e, n, r = !1, a = () => {}) {
	let o = [];
	for (let s of E(e, n).hand) for (let c of i(e).filter((i) => (r || t(e, s.suit, i.id)) && Y(e, i.id) === n && X(e, n, i.id) && Jt(e, i.id) > 0)) for (let t of ["citadel", "market"]) B(e, n, t) >= 3 || o.push(F("duchyBuild", (e) => {
		a(e), z(e, n).revealed.push(W(e, n, s.uid)), G(e, n, t, c.id);
	}, {
		clearing: c.id,
		args: {
			n: c.id,
			piece: t,
			card: s.id,
			cardUid: s.uid
		},
		weight: 30
	}));
	return o;
}
function Vn(e, n) {
	if (!e.game.actions) return [];
	let r = Bn(e, n, !1, (e) => e.game.actions--), a = z(e, n), o = E(e, n);
	if (Cn(e, n) && r.push(F("move", (e) => {
		e.game.actions--, Z(e, n, "move");
	}, { weight: 10 })), wn(e, n).length && r.push(F("battle", (e) => {
		e.game.actions--, Z(e, n, "battle");
	}, { weight: 10 })), o.supply && r.push(F("recruitBurrow", (e) => {
		e.game.actions--, K(e, n, 0);
	}, { weight: 15 })), a.location > 0) for (let s of o.hand) for (let o of i(e).filter((r) => t(e, s.suit, r.id) && X(e, n, r.id) && !e.pieces.some((e) => e.owner === n && e.kind === "tunnel" && e.clearing === r.id))) {
		let t = e.pieces.filter((e) => e.owner === n && e.kind === "tunnel"), i = t.length >= 3 ? t.map((e) => e.uid) : [null];
		for (let t of i) for (let i = 1; i <= Math.min(4, a.location); i++) r.push(F("digAt", (e) => {
			e.game.actions--, H(e, W(e, n, s.uid)), t && (e.pieces = e.pieces.filter((e) => e.uid !== t)), G(e, n, "tunnel", o.id), Pt(e, n, 0, o.id, i);
		}, {
			clearing: o.id,
			args: {
				n: o.id,
				count: i,
				card: s.id,
				cardUid: s.uid,
				from: t ? e.pieces.find((e) => e.uid === t).clearing : "supply"
			},
			weight: 25 + i
		}));
	}
	return r;
}
function Hn(e, t, n, r = !1) {
	let i = [], a = r ? "mayor" : n, o = (e) => e.game.used.push(`minister:${a}`);
	if (n === "foremole") return Bn(e, t, !0, o);
	if ((n === "marshal" || n === "brigadier") && Cn(e, t) && i.push(F("ministerMove", (e) => {
		o(e), Z(e, t, "march", n === "brigadier" ? 2 : 1);
	}, {
		args: {
			minister: a,
			count: n === "brigadier" ? 2 : 1
		},
		weight: 15
	})), (n === "captain" || n === "brigadier") && wn(e, t).length && i.push(F("ministerBattle", (e) => {
		o(e), Z(e, t, "battle", n === "brigadier" ? 2 : 1, n === "brigadier" ? "optional" : "action");
	}, {
		args: {
			minister: a,
			count: n === "brigadier" ? 2 : 1
		},
		weight: 15
	})), n === "banker") for (let n of [...p, "bird"]) E(e, t).hand.some((e) => Dt(e, n)) && i.push(F("bankerSuit", (e) => {
		o(e), J(e, {
			kind: "banker",
			owner: t,
			suit: n,
			n: 0
		});
	}, {
		args: { suit: n },
		weight: 40
	}));
	let s = n === "duchess" ? B(e, t, "tunnel") === 3 ? 2 : 0 : n === "baron" ? B(e, t, "market") : n === "earl" ? B(e, t, "citadel") : 0;
	return s && i.push(F("ministerScore", (e) => {
		o(e), V(e, t, s);
	}, {
		args: {
			minister: a,
			vp: s
		},
		weight: 50 + s
	})), i;
}
function Un(e) {
	let n = e.game, r = n.tasks[0], a = r.owner, o = z(e, a), s = E(e, a);
	if (r.kind === "cultConspiracy") {
		let t = [], n = 2 - Number(o.hated);
		if (o.acolytes >= n) {
			Cn(e, a, o.outcast) && t.push(F("crusadeMove", (e) => {
				z(e, a).acolytes -= n, E(e, a).supply += n, Z(e, a, "move", 1, "crusade", o.outcast);
			}, {
				args: { cost: n },
				weight: 15
			})), wn(e, a, o.outcast).length && t.push(F("crusadeBattle", (e) => {
				z(e, a).acolytes -= n, E(e, a).supply += n, Z(e, a, "battle", 1, "crusade", o.outcast);
			}, {
				args: { cost: n },
				weight: 15
			}));
			for (let r of e.pieces.filter((t) => t.owner !== a && t.kind === "warrior" && v(e, t.clearing).suit === o.outcast && X(e, a, t.clearing))) t.push(F("convertAt", (e) => {
				z(e, a).acolytes -= n, E(e, a).supply += n, Kt(e, [{
					piece: r.uid,
					by: a,
					n: 1
				}]), K(e, a, r.clearing);
			}, {
				clearing: r.clearing,
				args: {
					n: r.clearing,
					faction: E(e, r.owner).faction,
					cost: n
				},
				weight: 25
			}));
		}
		let r = 3 - Number(o.hated);
		if (o.acolytes >= r && B(e, a, "garden", o.outcast) < 5) for (let n of e.pieces.filter((t) => t.owner !== a && w(t.kind) && v(e, t.clearing).suit === o.outcast && X(e, a, t.clearing))) t.push(F("sanctifyAt", (e) => {
			z(e, a).acolytes -= r, E(e, a).supply += r, Kt(e, [{
				piece: n.uid,
				by: a,
				n: 1
			}]), G(e, a, "garden", n.clearing);
		}, {
			clearing: n.clearing,
			args: {
				n: n.clearing,
				piece: n.kind,
				cost: r
			},
			weight: 40
		}));
		return [...t, L("finishConspiracies")];
	}
	return r.kind === "crusadeBattle" ? [...e.players.filter((t) => t.rid !== a && Ut(e, t.rid, r.location)).map((e) => F("battleAgainst", (t) => {
		I(t), xn(t, a, e.rid, r.location);
	}, {
		args: { name: e.faction },
		weight: 15
	})), L("pass")] : r.kind === "duchyParliament" ? [...o.ministers.filter((e) => !n.used.includes(`minister:${e}`)).flatMap((t) => t === "mayor" ? o.ministers.filter((e) => b[e] <= 3 && e !== "mayor").flatMap((t) => Hn(e, a, t, !0)) : Hn(e, a, t)), L("finishParliament")] : r.kind === "banker" ? [...s.hand.filter((e) => Dt(e, r.suit)).map((e) => F("bankerSpend", (t) => {
		H(t, W(t, a, e.uid)), V(t, a, 1), t.game.tasks[0].n++;
	}, {
		args: {
			card: e.id,
			cardUid: e.uid,
			suit: e.suit
		},
		weight: 30
	})), ...r.n ? [L("finishBanker")] : []] : r.kind === "duchySway" ? [...ee.filter((e) => !o.ministers.includes(e)).filter((t) => o.ministers.filter((e) => b[e] === b[t]).length + o.crownsLost.filter((e) => e === b[t]).length < 3 && Wn(e, a, b[t])).map((e) => F("swayMinister", (t) => {
		J(t, {
			kind: "swayCards",
			owner: a,
			key: e,
			n: b[e],
			locations: []
		});
	}, {
		args: {
			minister: e,
			cost: b[e],
			vp: b[e] - 1
		},
		weight: 45
	})), L("finishSway")] : r.kind === "swayCards" ? s.hand.flatMap((n) => i(e).filter((i) => !r.locations.includes(i.id) && t(e, n.suit, i.id) && x(e, a, i.id).length).filter((t) => Wn(e, a, r.n - 1, [...r.locations, t.id], [n.uid])).map((e) => F("revealForSway", (t) => {
		z(t, a).revealed.push(W(t, a, n.uid)), t.game.tasks[0].locations.push(e.id), t.game.tasks[0].n--;
	}, {
		clearing: e.id,
		args: {
			n: e.id,
			card: n.id,
			cardUid: n.uid,
			suit: n.suit
		}
	}))) : null;
}
function Wn(e, n, r, a = [], o = []) {
	if (!r) return !0;
	let s = E(e, n).hand.filter((e) => !o.includes(e.uid)), c = i(e).filter((t) => !a.includes(t.id) && x(e, n, t.id).length);
	if (s.length < r || c.length < r) return !1;
	for (let i of s) for (let s of c.filter((n) => t(e, i.suit, n.id))) if (Wn(e, n, r - 1, [...a, s.id], [...o, i.uid])) return !0;
	return !1;
}
function Gn(e) {
	let t = e.game.tasks[0], n = t.owner;
	return t.kind === "swayCards" && !t.n && (z(e, n).ministers.push(t.key), V(e, n, b[t.key] - 1), I(e), e.game.tasks[0]?.kind === "duchySway" && I(e), !0);
}
//#endregion
//#region src/games/root/factions-forest.ts
function Kn(e, t) {
	if (!e.game.actions) return [];
	let n = [], r = e.game;
	Cn(e, t) && n.push(F("move", (e) => {
		e.game.actions--, Z(e, t, "move");
	}, { weight: 15 })), wn(e, t).length && n.push(F("battle", (e) => {
		e.game.actions--, Z(e, t, "battle");
	}, { weight: 10 }));
	let a = e.pieces.filter((e) => e.kind === "plot" && e.owner === t);
	for (let o of i(e).filter((n) => D(e, t, n.id) >= r.plotsPlaced + 1 && X(e, t, n.id) && !e.pieces.some((e) => e.kind === "plot" && e.clearing === n.id))) for (let e of [
		"bomb",
		"snare",
		"extortion",
		"raid"
	]) a.filter((t) => t.plot === e).length >= 2 || n.push(F("plotAt", (n) => {
		Nt(n, t, o.id, n.game.plotsPlaced + 1), n.game.plotsPlaced++, n.game.actions--, G(n, t, "plot", o.id, 1, e);
	}, {
		clearing: o.id,
		args: {
			n: o.id,
			plot: e,
			cost: r.plotsPlaced + 1
		},
		weight: 35
	}));
	for (let [e, t] of bt(a, 2).filter(([e, t]) => e.faceUp === t.faceUp)) n.push(F("trickPlots", (n) => {
		let r = n.pieces.find((t) => t.uid === e.uid), i = n.pieces.find((e) => e.uid === t.uid);
		[r.clearing, i.clearing] = [i.clearing, r.clearing], n.game.actions--;
	}, {
		args: {
			from: e.clearing,
			to: t.clearing
		},
		weight: -5
	}));
	return n;
}
function qn(e, t, n, r = null, i = 0) {
	let a = z(e, t), o = a.location;
	a.location = n, R(e, {
		kind: "move",
		rid: t,
		data: {
			from: o,
			clearing: n,
			n: 1,
			faction: "vagabond"
		}
	}), r && i && Pt(e, r, o, n, i), e.log.push({
		id: e.version,
		type: "move",
		owner: t,
		target: null,
		clearing: Math.max(1, n),
		from: o > 0 ? o : null,
		n: 1
	});
}
function Jn(e, t, n = "move") {
	let r = z(e, t), i = [], o = n === "slip";
	if (!o && e.pieces.some((e) => e.clearing === r.location && e.owner !== t && e.kind === "plot" && e.faceUp && e.plot === "snare")) return [];
	let s = r.location < 0 ? a(e, r.location).filter((e) => o || e > 0) : [
		...m(e, r.location),
		...o ? a(e, r.location) : [],
		...e.game.riverboats.includes(t) ? ue(e, r.location) : []
	], c = [...new Set(s)].map((e) => ({
		to: e,
		ferry: !1
	}));
	if (e.game.ferry === r.location && !e.game.used.includes("ferry")) for (let t of S[e.map].coastal.filter((e) => e !== r.location)) c.push({
		to: t,
		ferry: !0
	});
	for (let { to: a, ferry: s } of c.filter((t) => !e.game.scorched.includes(t.to))) {
		let c = r.relationships.some((t) => t.level === -1 && D(e, t.owner, a)), l = bt(q(e, t, "boot"), o ? 0 : Number(n === "move") + Number(c)), u = [{
			owner: null,
			n: 0
		}];
		if (a > 0 && r.location > 0) {
			for (let t of r.relationships.filter((e) => e.level === 3)) if (Qt(e, t.owner, r.location).some((e) => e.to === a && e.via === "ferry" === s)) for (let n = 1; n <= D(e, t.owner, r.location); n++) u.push({
				owner: t.owner,
				n
			});
		}
		for (let c of l) for (let l of u) i.push(F(s ? "vagabondFerry" : a < 0 ? "slipForest" : o ? "slipClearing" : "vagabondMove", (e) => {
			Bt(e, t, c.map((e) => e.uid)), qn(e, t, a, l.owner, l.n), s && (e.game.ferry = a, e.game.used.push("ferry"), E(e, t).hand.push(...U(e, 1, t)), l.owner && E(e, l.owner).hand.push(...U(e, 1, l.owner))), n !== "move" && I(e);
		}, {
			clearing: a > 0 ? a : void 0,
			args: {
				n: Math.abs(a),
				count: l.n,
				faction: l.owner ? E(e, l.owner).faction : "vagabond",
				cost: c.length
			},
			weight: a < 0 ? r.items.some((e) => e.damaged) ? 35 : 0 : 10 + Number(e.game.ruins.some((e) => e.clearing === a)) * 15
		}));
	}
	return i;
}
function Yn(e, t, n = !1) {
	let r = z(e, t), i = r.location;
	if (i < 1) return [];
	let a = [];
	for (let o of n ? [null] : q(e, t, "sword")) for (let s of e.players.filter((n) => n.rid !== t && Ut(e, n.rid, i))) {
		let c = [null, ...r.relationships.filter((t) => t.level === 3 && t.owner !== s.rid && D(e, t.owner, i)).map((e) => e.owner)];
		for (let r of c) a.push(F(r ? "battleWithAlly" : "battleAgainst", (e) => {
			o && Bt(e, t, [o.uid]), n && I(e), xn(e, t, s.rid, i, r);
		}, {
			clearing: i,
			args: {
				name: s.faction,
				faction: r ? E(e, r).faction : "vagabond"
			},
			weight: 10
		}));
	}
	return a;
}
function Xn(e, t, n) {
	let r = z(e, t).relationships.find((e) => e.owner === n);
	if (r && r.level !== -1) {
		if (r.level === 3) {
			V(e, t, 2);
			return;
		}
		r.aids++, r.aids >= r.level + 1 && (r.level++, r.aids = 0, V(e, t, r.level === 1 ? 1 : 2));
	}
}
function Zn(e, t, n) {
	let r = z(e, t);
	return bt(q(e, t), 2).flatMap((t) => {
		if (t[0].type === n.items[0] && t[1].type === n.items[1] || t[1].type === n.items[0] && t[0].type === n.items[1]) return [{
			items: t,
			improvise: null
		}];
		if (r.character !== "adventurer" || e.game.used.includes("improvise")) return [];
		let i = t.find((e) => n.items.includes(e.type));
		return i ? [{
			items: t,
			improvise: t.find((e) => e.uid !== i.uid).uid
		}] : [];
	});
}
function Qn(e, n) {
	let r = z(e, n), a = E(e, n), o = e.game, s = [...Jn(e, n), ...Yn(e, n)];
	if (r.location < 0) return s;
	let c = r.location, l = e.players.filter((t) => t.rid !== n && Ut(e, t.rid, c));
	for (let t of q(e, n, "torch")) o.ruins.some((e) => e.clearing === c && e.items.length) && s.push(F("explore", (e) => {
		Bt(e, n, [t.uid]), J(e, {
			kind: "chooseItem",
			owner: n,
			location: c,
			key: "ruin"
		});
	}, {
		clearing: c,
		weight: 40
	}));
	for (let r of l) for (let i of a.hand.filter((n) => t(e, n.suit, c))) for (let t of q(e, n)) s.push(F("aidFaction", (e) => {
		Bt(e, n, [t.uid]), E(e, r.rid).hand.push(W(e, n, i.uid)), Xn(e, n, r.rid), J(e, {
			kind: "aidItem",
			owner: n,
			target: r.rid
		});
	}, {
		args: {
			faction: r.faction,
			card: i.id,
			cardUid: i.uid,
			item: t.type
		},
		weight: r.faction === "vagabond" ? -5 : 25
	}));
	for (let t of o.quests.filter((t) => t.suit === v(e, c).suit)) for (let i of Zn(e, n, t)) for (let e of ["vp", "cards"]) s.push(F(e === "vp" ? "questScore" : "questDraw", (r) => {
		Bt(r, n, i.items.map((e) => e.uid)), i.improvise && (zt(r, n, i.improvise, { damaged: !0 }), r.game.used.push("improvise"));
		let a = z(r, n);
		a.completedQuests.push(t), e === "vp" ? V(r, n, a.completedQuests.filter((e) => e.suit === t.suit).length) : E(r, n).hand.push(...U(r, 2, n)), r.game.quests = r.game.quests.filter((e) => e.id !== t.id || e.suit !== t.suit);
		let o = r.game.questDeck.shift();
		o && r.game.quests.push(o);
	}, {
		args: {
			quest: t.id,
			items: i.items.map((e) => e.type).join(", "),
			vp: r.completedQuests.filter((e) => e.suit === t.suit).length + 1
		},
		weight: e === "vp" ? 35 : 15
	}));
	for (let t of q(e, n, "crossbow")) for (let r of l) {
		let i = x(e, r.rid, c), a = i.find((e) => e.kind === "warrior"), o = a ? [a] : i;
		for (let e of o) s.push(F("strikePiece", (r) => {
			Bt(r, n, [t.uid]), Kt(r, [{
				piece: e.uid,
				by: n,
				n: 1
			}]);
		}, {
			args: {
				piece: e.kind,
				faction: r.faction
			},
			weight: e.kind === "warrior" ? 15 : 30
		}));
	}
	for (let t of q(e, n, "hammer")) for (let e of r.items.filter((e) => e.damaged)) s.push(F("repairItem", (r) => {
		Bt(r, n, [t.uid]), zt(r, n, e.uid, { damaged: !1 });
	}, {
		args: { item: e.type },
		weight: 30
	}));
	for (let a of q(e, n, "torch")) {
		let u = (e) => Bt(e, n, [a.uid]);
		if (r.character === "thief") for (let e of l.filter((e) => e.hand.length)) s.push(F("stealCard", (t) => {
			u(t);
			let r = jt(t, e.rid);
			r && E(t, n).hand.push(r);
		}, {
			args: { faction: e.faction },
			weight: 15
		}));
		if (r.character === "tinker") for (let r of e.discard.filter((n) => t(e, n.suit, c))) s.push(F("dayLabor", (e) => {
			u(e), e.discard = e.discard.filter((e) => e.uid !== r.uid), E(e, n).hand.push(r);
		}, {
			args: {
				card: r.id,
				cardUid: r.uid,
				suit: r.suit
			},
			weight: 20
		}));
		if (r.character === "ranger" && r.items.some((e) => e.damaged) && s.push(F("hideout", (e) => {
			u(e), I(e), J(e, {
				kind: "chooseItem",
				owner: n,
				key: "hideout",
				n: 3
			});
		}, { weight: 5 })), r.character === "vagrant") for (let t of e.players.filter((t) => Ut(e, t.rid, c) && (D(e, t.rid, c) || Ht(e, t.rid, c)))) for (let r of e.players.filter((n) => n.rid !== t.rid && Ut(e, n.rid, c))) s.push(F("instigate", (e) => {
			u(e), xn(e, t.rid, r.rid, c, null, n);
		}, {
			args: {
				attacker: t.faction,
				defender: r.faction
			},
			weight: 15
		}));
		if (r.character === "scoundrel" && !o.scorched.includes(c) && s.push(F("scorchedEarth", (e) => {
			z(e, n).items = z(e, n).items.filter((e) => e.uid !== a.uid), e.game.scorched.push(c), qt(e, n, [c]);
		}, {
			clearing: c,
			weight: 0
		})), r.character === "harrier") for (let t of i(e).filter((e) => e.id !== c && !o.scorched.includes(e.id))) s.push(F("glideTo", (e) => {
			u(e), qn(e, n, t.id);
		}, {
			clearing: t.id,
			args: { n: t.id },
			weight: 5
		}));
	}
	return s;
}
function $n(e) {
	let t = e.game, n = t.tasks[0], r = n.owner, a = z(e, r), o = E(e, r);
	if (n.kind === "corvidFlip") return [...e.pieces.filter((t) => t.owner === r && t.kind === "plot" && !t.faceUp && D(e, r, t.clearing)).map((e) => F("flipPlot", (t) => {
		let n = t.pieces.find((t) => t.uid === e.uid);
		if (n.faceUp = !0, V(t, r, t.pieces.filter((e) => e.owner === r && e.kind === "plot" && e.faceUp).length), n.plot === "bomb" && (qt(t, r, [n.clearing]), t.pieces = t.pieces.filter((e) => e.uid !== n.uid)), n.plot === "extortion") for (let e of t.players.filter((e) => e.rid !== r && Ut(t, e.rid, n.clearing))) {
			let n = jt(t, e.rid);
			n && E(t, r).hand.push(n);
		}
	}, {
		clearing: e.clearing,
		args: {
			plot: e.plot,
			n: e.clearing
		},
		weight: 50
	})), L("finishFlip")];
	if (n.kind === "corvidRecruit") return [...o.hand.flatMap((e) => (e.suit === "bird" ? [...p] : [e.suit]).map((t) => F("corvidRecruit", (n) => {
		H(n, W(n, r, e.uid)), I(n), J(n, {
			kind: "recruit",
			owner: r,
			locations: i(n).filter((e) => e.suit === t && X(n, r, e.id)).map((e) => e.id)
		});
	}, {
		args: {
			suit: t,
			card: e.id,
			cardUid: e.uid
		},
		weight: 25
	}))), L("skipRecruit")];
	if (n.kind === "corvidExert") return n.n ? Kn(e, r) : [F("exert", (e) => {
		e.game.actions = 1, e.game.tasks[0].n = 1, e.game.used.push("exert");
	}, { weight: 10 }), L("skipExert")];
	if (n.kind === "vagabondRefresh") return [...a.items.filter((e) => e.exhausted).map((e) => F("refreshItem", (t) => {
		zt(t, r, e.uid, { exhausted: !1 }), t.game.refresh--;
	}, {
		args: { item: e.type },
		weight: e.type === "torch" ? 25 : e.type === "hammer" ? 20 : 10
	})), L("finishRefresh")];
	if (n.kind === "vagabondSlip") return [...Jn(e, r, "slip"), L("skipSlip")];
	if (n.kind === "chooseItem" && n.key === "ruin") {
		let e = t.ruins.find((e) => e.clearing === n.location);
		return [...new Set(e.items)].filter((e) => !a.items.some((t) => t.origin === "ruin" && t.type === e)).map((e) => F("takeRuinItem", (t) => {
			let i = t.game.ruins.find((e) => e.clearing === n.location);
			i.items.splice(i.items.indexOf(e), 1), Lt(t, r, e, "ruin"), V(t, r, 1), I(t);
		}, {
			args: { item: e },
			weight: e === "hammer" ? 25 : 20
		}));
	}
	return n.kind === "chooseItem" && n.key === "hideout" ? [...a.items.filter((e) => e.damaged).map((e) => F("repairItem", (t) => {
		zt(t, r, e.uid, { damaged: !1 }), t.game.tasks[0].n--;
	}, { args: { item: e.type } })), L("finishRepair")] : n.kind === "aidItem" ? [...z(e, n.target).craftedItems.map((e, t) => F("takeCraftedItem", (i) => {
		z(i, n.target).craftedItems.splice(t, 1), Lt(i, r, e), I(i);
	}, {
		args: { item: e },
		weight: 30
	})), L("skipItem")] : n.kind === "capacity" ? a.items.map((e) => F("discardItem", (t) => {
		z(t, r).items = z(t, r).items.filter((t) => t.uid !== e.uid);
	}, {
		args: { item: e.type },
		weight: e.damaged ? 20 : e.type === "torch" ? -30 : -5
	})) : null;
}
function er(e, t) {
	let n = Xt(e, t);
	return z(e, t).items.length - n.tea - n.coin - n.sack > 6 + n.sack * 2;
}
function tr(e) {
	let t = e.game, n = t.tasks[0], r = z(e, n.owner);
	return n.kind === "vagabondRefresh" && !t.refresh || n.kind === "capacity" && !er(e, n.owner) || n.kind === "chooseItem" && n.key === "hideout" && !n.n || n.kind === "corvidExert" && n.n && !t.actions || n.kind === "chooseItem" && n.key === "ruin" && !$n(e).length || n.kind === "chooseItem" && n.key === "hideout" && !r.items.some((e) => e.damaged) ? (I(e), !0) : !1;
}
//#endregion
//#region src/games/root/interrupts.ts
var Q = (e) => {
	e.game.interrupts.shift();
};
function nr(e) {
	let t = e.game.interrupts;
	return t.length > 1 && !t[0].selected ? t.every((e) => e.owner === t[0].owner) ? t[0].owner : e.active : t[0].owner;
}
function rr(e) {
	let t = e.game.interrupts;
	if (t.length > 1 && !t[0].selected) return t.map((t, n) => F("resolveEffect", (e) => {
		let t = e.game.interrupts.splice(n, 1)[0];
		t.selected = !0, e.game.interrupts.unshift(t);
	}, { args: {
		faction: E(e, t.owner).faction,
		effect: t.kind
	} }));
	let n = e.game.interrupts[0], r = E(e, n.owner), i = z(e, n.owner);
	if (n.kind === "baseLoss" && n.key === "base" || n.kind === "gardenLoss") return [];
	if (n.kind === "outrage") return r.hand.filter((t) => Dt(t, v(e, n.location).suit)).map((e) => F("payOutrage", (t) => {
		It(t, n.target, [W(t, n.owner, e.uid)]), Q(t);
	}, { args: {
		card: e.id,
		cardUid: e.uid,
		suit: e.suit
	} }));
	if (n.kind === "peek") return [F("continue", Q)];
	if (n.kind === "baseLoss") return i.supporters.length > 5 ? i.supporters.map((e) => F("discardSupporter", (t) => {
		let r = z(t, n.owner).supporters;
		H(t, ...r.splice(r.findIndex((t) => t.uid === e.uid), 1)), r.length <= 5 && Q(t);
	}, { args: {
		card: e.id,
		cardUid: e.uid,
		suit: e.suit
	} })) : [];
	if (n.kind === "tradeLoss") return n.n === 0 ? [] : [...new Set(i.funds)].map((t) => F("returnFund", (e) => {
		let r = z(e, n.owner).funds;
		r.splice(r.indexOf(t), 1), E(e, t).supply++;
		let a = (n.n ?? Math.ceil(i.funds.length / 2)) - 1;
		e.game.interrupts[0].n = a, a <= 0 && Q(e);
	}, { args: { faction: E(e, t).faction } }));
	if (n.kind === "failure") {
		let e = Math.max(0, ...i.ministers.map((e) => b[e]));
		return i.ministers.filter((t) => b[t] === e).map((e) => F("loseMinister", (t) => {
			let r = z(t, n.owner);
			r.ministers = r.ministers.filter((t) => t !== e), r.crownsLost.push(b[e]);
			let i = jt(t, n.owner);
			i && H(t, i), Q(t);
		}, {
			args: { minister: e },
			weight: -b[e]
		}));
	}
	if (n.kind === "damage") return i.items.filter((e) => !e.damaged).map((e) => F("damageItem", (t) => {
		zt(t, n.owner, e.uid, { damaged: !0 }), --t.game.interrupts[0].n <= 0 && Q(t);
	}, {
		args: { item: e.type },
		weight: e.type === "torch" ? -20 : e.type === "sword" ? -10 : 5
	}));
	if (n.kind === "arbiter") return [F("enlistArbiter", (e) => {
		e.battle.arbiter = n.target, V(e, n.target, 1), Q(e);
	}, { weight: 10 }), F("pass", (e) => {
		e.battle.arbiter = null, Q(e);
	})];
	if (n.kind === "hospital") {
		let t = e.pieces.find((e) => e.owner === n.owner && e.kind === "keep");
		return [...t && X(e, n.owner, t.clearing) ? r.hand.filter((t) => Dt(t, v(e, n.location).suit)).map((e) => F("hospitalPay", (r) => {
			H(r, W(r, n.owner, e.uid)), K(r, n.owner, t.clearing, n.n), Q(r);
		}, {
			args: {
				card: e.id,
				cardUid: e.uid,
				suit: e.suit,
				count: n.n
			},
			weight: 40 + n.n
		})) : [], F("pass", Q, { weight: -30 })];
	}
	return n.kind === "raid" && r.supply ? n.locations.filter((t) => X(e, n.owner, t)).map((e) => F("recruitAt", (t) => {
		K(t, n.owner, e), t.game.interrupts[0].locations = t.game.interrupts[0].locations.filter((t) => t !== e);
	}, {
		clearing: e,
		args: {
			n: e,
			count: 1
		}
	})) : [];
}
function ir(e) {
	let t = e.game, n = t.interrupts[0], r = z(e, n.owner);
	if (n.kind === "outrage") {
		Q(e), t.interrupts.unshift({
			kind: "peek",
			owner: n.target,
			target: n.owner,
			key: "outrage"
		});
		return;
	}
	if (n.kind !== "peek") {
		if (n.kind === "baseLoss" && n.key === "base") {
			let t = r.supporters.filter((e) => Dt(e, n.suit));
			r.supporters = r.supporters.filter((e) => !t.includes(e)), H(e, ...t);
			let i = Math.ceil(r.officers / 2);
			if (r.officers -= i, E(e, n.owner).supply += i, !B(e, n.owner, "base") && r.supporters.length > 5) {
				n.key = "limit";
				return;
			}
		}
		if (n.kind === "gardenLoss") for (let t = 0; t < n.n; t++) {
			let t = jt(e, n.owner);
			t && H(e, t);
		}
		if (n.kind === "failure") {
			let t = jt(e, n.owner);
			t && H(e, t);
		}
		if (n.kind === "baseLoss" && n.key === "limit" && r.supporters.length > 5) throw Error("Root supporters choice unavailable");
		Q(e);
	}
}
function ar(e, t) {
	let n = e.game.interrupts[0];
	n?.kind === "peek" && n.owner === t && n.key === "outrage" && It(e, t, U(e));
}
function or(e) {
	let t = e.battle;
	if (!t || t.stage !== "roll" || t.arbiter !== void 0) return !1;
	t.arbiter = null;
	let n = e.game.boards.find((e) => e.character === "arbiter" && e.owner !== t.attacker && e.owner !== t.defender && e.location === t.clearing);
	return n ? (e.game.interrupts.push({
		kind: "arbiter",
		owner: t.defender,
		target: n.owner
	}), !0) : !1;
}
//#endregion
//#region src/games/root/turn.ts
function sr(e, t, n = !1) {
	let r = [], a = E(e, t), o = e.game;
	for (let s of a.effects.filter((e) => !o.used.includes(e.effect))) {
		if (!n && s.effect === "royalClaim") {
			let n = i(e).filter((n) => Y(e, n.id) === t).length + Number(a.faction === "duchy");
			r.push(F("claimRule", (e) => {
				let r = E(e, t).effects.findIndex((e) => e.effect === "royalClaim");
				H(e, E(e, t).effects.splice(r, 1)[0].card), V(e, t, n);
			}, {
				args: { vp: n },
				weight: 35
			}));
		}
		if (n && s.effect === "betterBurrowBank") for (let n of e.players.filter((e) => e.rid !== t)) r.push(F("shareBank", (e) => {
			e.game.used.push("betterBurrowBank"), E(e, t).hand.push(...U(e, 1, t)), E(e, n.rid).hand.push(...U(e, 1, n.rid));
		}, {
			args: { faction: n.faction },
			weight: 20
		}));
		if (!n && s.effect === "standAndDeliver") for (let n of e.players.filter((e) => e.rid !== t && e.hand.length)) r.push(F("standDeliver", (e) => {
			e.game.used.push("standAndDeliver");
			let r = jt(e, n.rid);
			r && E(e, t).hand.push(r), V(e, n.rid, 1);
		}, {
			args: { faction: n.faction },
			weight: 10
		}));
	}
	return r;
}
function cr(e) {
	let t = e.game.tasks[0].owner, n = e.game, r = E(e, t), i = e.players.find((e) => e.faction === "riverfolk" && e.rid !== t), a = sr(e, t, !0);
	if (!i) return [...a, L("finishPurchases")];
	let o = z(e, i.rid), s = 1 + e.pieces.filter((n) => n.owner === i.rid && n.kind === "tradePost" && Ut(e, t, n.clearing)).length;
	if (n.servicesBought >= s) return [...a, L("finishPurchases")];
	for (let s of [
		"card",
		"boats",
		"mercenaries"
	]) {
		if (s === "boats" && n.riverboats.includes(t) || s === "mercenaries" && (n.mercenaries.includes(t) || r.faction === "vagabond")) continue;
		let c = o.prices[s], l = r.faction === "vagabond" ? bt(q(e, t), c) : r.supply >= c ? [[]] : [], u = s === "card" ? i.hand : [null];
		for (let e of l) for (let n of u) a.push(F(s === "card" ? "buyCard" : s === "boats" ? "buyBoats" : "buyMercenaries", (a) => {
			let o = z(a, i.rid);
			if (r.faction === "vagabond") {
				Bt(a, t, e.map((e) => e.uid));
				let n = Math.min(E(a, i.rid).supply, c);
				E(a, i.rid).supply -= n, o.payments.push(...Array.from({ length: n }, () => i.rid));
			} else E(a, t).supply -= c, o.payments.push(...Array.from({ length: c }, () => t));
			n && E(a, t).hand.push(W(a, i.rid, n.uid)), s === "boats" && a.game.riverboats.push(t), s === "mercenaries" && a.game.mercenaries.push(t), a.game.servicesBought++;
		}, {
			args: {
				card: n?.id ?? "",
				suit: n?.suit ?? "bird",
				cost: c,
				items: e.map((e) => e.type).join(", ")
			},
			weight: s === "card" ? 5 : -5
		}));
	}
	return [...a, L("finishPurchases")];
}
function lr(e) {
	let t = e.game.tasks[0], n = t.owner, r = E(e, n);
	return t.kind === "services" ? cr(e) : t.kind === "birdEffects" ? [...sr(e, n), L()] : t.kind === "commandWarren" ? [...r.effects.some((e) => e.effect === "commandWarren") ? r.faction === "vagabond" ? Yn(e, n, !0) : wn(e, n).length ? [F("commandWarren", (e) => {
		I(e), Z(e, n, "battle");
	}, { weight: 10 })] : [] : [], L("pass")] : t.kind === "cobbler" ? [...r.effects.some((e) => e.effect === "cobbler") ? r.faction === "vagabond" ? Jn(e, n, "cobbler") : Cn(e, n) ? [F("cobbler", (e) => {
		I(e), Z(e, n, "move");
	}, { weight: 10 })] : [] : [], L("pass")] : t.kind === "discard" ? r.hand.length > 5 ? r.hand.map((e) => F("discardCard", (t) => {
		H(t, W(t, n, e.uid));
	}, {
		args: {
			card: e.id,
			cardUid: e.uid,
			suit: e.suit
		},
		weight: e.kind === "ambush" ? -10 : 5
	})) : [] : t.kind === "chooseItem" && t.key === "woodProduction" ? t.locations.filter((t) => X(e, n, t)).map((e) => F("produceWood", (t) => {
		G(t, n, "wood", e), t.game.tasks[0].locations.splice(t.game.tasks[0].locations.indexOf(e), 1);
	}, {
		clearing: e,
		args: { n: e }
	})) : null;
}
function ur(e) {
	let t = e.game, n = t.tasks[0], r = n.owner, i = E(e, r), a = z(e, r);
	if (n.kind === "turnStart") {
		e.active = r, t.phase = "birdsong", t.turn++, t.round = Math.floor((t.turn - 1) / e.order.length) + 1, t.used = [], t.crafted = [], t.decreeDone = [], t.servicesBought = 0, t.riverboats = [], t.mercenaries = [], t.plotsPlaced = 0;
		for (let e of a.relationships) e.aids = 0;
		return Yt(e, r, Y) ? (kt(e, r), !0) : (I(e), J(e, {
			kind: "services",
			owner: r
		}, {
			kind: "birdEffects",
			owner: r
		}, {
			kind: "birdsong",
			owner: r
		}, {
			kind: "dayStart",
			owner: r
		}, {
			kind: "daylight",
			owner: r
		}, {
			kind: "eveningStart",
			owner: r
		}, {
			kind: "evening",
			owner: r
		}, {
			kind: "draw",
			owner: r
		}, {
			kind: "discard",
			owner: r
		}, ...i.faction === "vagabond" ? [{
			kind: "capacity",
			owner: r
		}] : [], {
			kind: "turnEnd",
			owner: r
		}), !0);
	}
	if (n.kind === "birdsong") {
		if (I(e), i.faction === "marquise" && J(e, {
			kind: "chooseItem",
			owner: r,
			key: "woodProduction",
			locations: e.pieces.filter((t) => t.owner === r && t.kind === "sawmill" && X(e, r, t.clearing)).flatMap((e) => Array.from({ length: e.count }, () => e.clearing))
		}), i.faction === "eyrie" && (i.hand.length || i.hand.push(...U(e, 1, r)), J(e, {
			kind: "decreeAdd",
			owner: r,
			n: 0
		}, {
			kind: "emergencyRoost",
			owner: r
		})), i.faction === "alliance" && J(e, {
			kind: "allianceRevolt",
			owner: r
		}, {
			kind: "allianceSpread",
			owner: r
		}), i.faction === "cult") {
			let n = p.map((e) => ({
				suit: e,
				n: t.lostSouls.filter((t) => t.suit === e).length
			})), i = Math.max(...n.map((e) => e.n)), o = n.filter((e) => e.n === i);
			o.length === 1 ? (a.hated = a.outcast === o[0].suit, a.outcast = o[0].suit) : a.hated = !0;
			for (let n of t.lostSouls) (n.kind === "dominance" ? t.availableDominance : e.discard).push(n);
			t.lostSouls = [], J(e, {
				kind: "cultConspiracy",
				owner: r
			});
		}
		if (i.faction === "riverfolk") {
			if (!a.payments.length) {
				let e = Math.min(2, i.supply);
				i.supply -= e, a.payments.push(...Array.from({ length: e }, () => r));
			}
			B(e, r, "tradePost") && V(e, r, Math.floor(a.funds.length / 2)), a.funds.push(...a.committed, ...a.payments), a.committed = [], a.payments = [];
		}
		return i.faction === "duchy" && K(e, r, 0, [
			1,
			2,
			4,
			6
		][B(e, r, "citadel")]), i.faction === "corvid" && J(e, {
			kind: "craft",
			owner: r
		}, {
			kind: "corvidFlip",
			owner: r
		}, {
			kind: "corvidRecruit",
			owner: r
		}), i.faction === "vagabond" && (t.refresh = 3 + 2 * Xt(e, r).tea, J(e, {
			kind: "vagabondRefresh",
			owner: r
		}, {
			kind: "vagabondSlip",
			owner: r
		})), !0;
	}
	if (n.kind === "dayStart") {
		t.phase = "daylight", I(e), t.actions = i.faction === "marquise" || i.faction === "corvid" ? 3 : i.faction === "duchy" ? 2 : 0;
		let n = [{
			kind: "commandWarren",
			owner: r
		}];
		return i.faction === "marquise" && n.push({
			kind: "craft",
			owner: r
		}), i.faction === "eyrie" && n.push({
			kind: "craft",
			owner: r
		}, {
			kind: "decree",
			owner: r
		}), i.faction === "eyrie" && (t.tasks = t.tasks.filter((e) => e.kind !== "daylight")), J(e, ...n), !0;
	}
	if (n.kind === "eveningStart") return t.phase = "evening", I(e), J(e, {
		kind: "cobbler",
		owner: r
	}), !0;
	if (n.kind === "evening") {
		if (I(e), i.faction === "eyrie" && V(e, r, d[B(e, r, "roost")]), i.faction === "alliance" && (t.actions = a.officers, J(e, {
			kind: "allianceOps",
			owner: r
		})), i.faction === "cult" || i.faction === "duchy") {
			let t = a.revealed.splice(0);
			i.faction === "duchy" ? (H(e, ...t.filter((e) => e.suit === "bird")), i.hand.push(...t.filter((e) => e.suit !== "bird"))) : i.hand.push(...t), J(e, {
				kind: "craft",
				owner: r
			});
		}
		if (i.faction === "corvid" && J(e, {
			kind: "corvidExert",
			owner: r
		}), i.faction === "vagabond" && a.location < 0) for (let t of a.items) t.damaged && zt(e, r, t.uid, {
			damaged: !1,
			exhausted: !1
		});
		return !0;
	}
	if (n.kind === "draw") {
		let n = 1;
		return i.faction === "marquise" && (n += Number(B(e, r, "recruiter") >= 3) + Number(B(e, r, "recruiter") >= 5)), i.faction === "eyrie" && (n += Number(B(e, r, "roost") >= 3) + Number(B(e, r, "roost") >= 6)), i.faction === "alliance" && (n += B(e, r, "base")), i.faction === "cult" && (n += p.filter((t) => B(e, r, "garden", t) >= 2).length), (i.faction === "riverfolk" || i.faction === "corvid" && t.used.includes("exert")) && (n = 0), i.faction === "duchy" && (n += B(e, r, "market")), i.faction === "corvid" && n && (n += e.pieces.filter((e) => e.owner === r && e.kind === "plot" && e.faceUp && e.plot === "extortion").length), i.faction === "vagabond" && (n += Xt(e, r).coin), i.hand.push(...U(e, n, r)), I(e), !0;
	}
	if (n.kind === "discard" && i.hand.length <= 5) return I(e), !0;
	if (n.kind === "turnEnd") {
		if (!n.key && S[e.map].tower && Y(e, S[e.map].tower) === r && V(e, r, 1), I(e), i.faction === "riverfolk" && !n.key) return J(e, ...[
			"card",
			"boats",
			"mercenaries"
		].map((e) => ({
			kind: "prices",
			owner: r,
			key: e
		})), {
			kind: "turnEnd",
			owner: r,
			key: "priced"
		}), !0;
		let t = e.order[(e.order.indexOf(r) + 1) % e.order.length];
		return J(e, {
			kind: "turnStart",
			owner: t
		}), !0;
	}
	return n.kind === "chooseItem" && n.key === "woodProduction" && (!n.locations.length || B(e, r, "wood") >= 8) ? (I(e), !0) : n.kind === "command" && !e.command?.remaining && !e.battle && (e.command = null, I(e), !0);
}
//#endregion
//#region src/games/root/play.ts
function dr(e) {
	let t = e.game, n = t.tasks[0];
	return !n || [
		"setupBegin",
		"setupFinish",
		"turnStart",
		"birdsong",
		"dayStart",
		"eveningStart",
		"evening",
		"draw",
		"turnEnd",
		"command"
	].includes(n.kind) ? !0 : n.kind === "woodPayment" || n.kind === "payCards" || n.kind === "swayCards" ? !n.n : n.kind === "recruit" ? !n.locations?.length || !E(e, n.owner).supply : n.kind === "emergencyRoost" ? B(e, n.owner, "roost") > 0 : n.kind === "discard" ? E(e, n.owner).hand.length <= 5 : n.kind === "capacity" ? !er(e, n.owner) : n.kind === "vagabondRefresh" ? !t.refresh : n.kind === "corvidExert" ? !!n.n && !t.actions : n.kind === "chooseItem" && n.key === "woodProduction" ? !n.locations?.length || B(e, n.owner, "wood") >= 8 : n.kind === "chooseItem" && n.key === "hideout" ? !n.n || !z(e, n.owner).items.some((e) => e.damaged) : !1;
}
function fr(e) {
	let t = e.game.tasks[0].owner, n = E(e, t).faction, r = n === "marquise" ? Pn(e, t) : n === "alliance" ? In(e, t) : n === "cult" ? Rn(e, t) : n === "riverfolk" ? zn(e, t) : n === "duchy" ? Vn(e, t) : n === "corvid" ? Kn(e, t) : n === "vagabond" ? Qn(e, t) : [];
	return [
		"alliance",
		"riverfolk",
		"vagabond"
	].includes(n) && E(e, t).hand.some((n) => En(e, t, n).length) && r.push(F("craft", (e) => J(e, {
		kind: "craft",
		owner: t
	}), { weight: 35 })), r.push(F("finishActions", (e) => {
		I(e), n === "duchy" && J(e, {
			kind: "duchyParliament",
			owner: t
		}, {
			kind: "duchySway",
			owner: t
		});
	}, { weight: -100 })), r;
}
function pr(e) {
	if (e.game.interrupts.length) return rr(e);
	if (dr(e)) return [];
	let t = e.game.tasks[0], n = t.kind === "daylight" ? fr(e) : t.kind === "craft" ? An(e) : nn(e) ?? Fn(e) ?? Un(e) ?? $n(e) ?? lr(e) ?? [], r = [
		"daylight",
		"decree",
		"duchyParliament",
		"duchySway"
	].includes(t.kind) || t.kind === "craft" && !t.card;
	e.game.phase === "daylight" && r && n.push(...jn(e, t.owner)), e.game.phase === "birdsong" && [
		"emergencyRoost",
		"allianceRevolt",
		"allianceSpread",
		"cultConspiracy",
		"corvidFlip",
		"corvidRecruit",
		"vagabondSlip"
	].includes(t.kind) && n.push(...sr(e, t.owner));
	let i = r || [
		"birdEffects",
		"emergencyRoost",
		"allianceRevolt",
		"allianceSpread",
		"cultConspiracy",
		"corvidFlip",
		"corvidRecruit",
		"vagabondSlip",
		"allianceOps"
	].includes(t.kind) || t.kind === "corvidExert" && !t.n;
	return t.owner === e.active && e.game.phase !== "setup" && i && n.push(...Mn(e, t.owner)), n;
}
function mr(e) {
	return e.game ? e.winner.length ? null : e.game.interrupts.length ? rr(e).length ? nr(e) : null : e.hospitals.length || e.battle ? un(e) : e.command?.remaining ? fn(e, e.command.owner).length ? e.command.owner : null : pr(e).length ? e.game.tasks[0].owner : null : un(e);
}
function hr(e, t) {
	return e.game ? mr(e) === t ? !e.game.interrupts.length && (e.hospitals.length || e.battle || e.command?.remaining) ? fn(e, t) : pr(e).map((t, n) => ({
		action: {
			type: "choose",
			id: `${e.version}:${n}`
		},
		kind: "option",
		clearing: t.clearing ?? null,
		n: t.n ?? null,
		label: t.label,
		args: t.args ?? {},
		weight: t.weight ?? 0
	})) : [] : fn(e, t);
}
var gr = (e) => e.game ? !e.winner.length && mr(e) === null : dn(e);
function _r(e, t, n, r = []) {
	return wt(vr(e, t, n, r));
}
function vr(e, t, n, r) {
	if (!e.game) return yn(e, t, n, r);
	let i = ut.safeParse(t);
	if (!i.success || e.winner.length) return null;
	let a = i.data;
	if (a.type === "tick") {
		if (n !== "$engine" || !gr(e)) return null;
		let t = Ct(e, r);
		return t.version++, t.game.interrupts.length ? (ir(t), t) : t.battle || t.hospitals.length ? or(t) ? t : yn(e, a, n, r) : t.command?.remaining ? (t.command.remaining = 0, t) : rn(t) || Ln(t) || Gn(t) || tr(t) || ur(t) ? (At(t), t) : pr(t).length ? null : (I(t), t);
	}
	if (mr(e) !== n) return null;
	if (!e.game.interrupts.length && (e.battle || e.hospitals.length || e.command?.remaining)) {
		let t = yn(e, a, n, r);
		return t?.game && a.type === "move" && e.command?.source === "crusade" && t.game.tasks.splice(1, 0, {
			kind: "crusadeBattle",
			owner: n,
			location: a.to
		}), t;
	}
	if (a.type !== "choose") return null;
	let o = pr(e), s = o.findIndex((t, n) => a.id === `${e.version}:${n}`);
	if (s < 0) return null;
	let c = Ct(e, r);
	return c.version++, c.game.interrupts[0]?.kind === "peek" && o[s].label === "continue" && ar(c, n), o[s].run(c), R(c, {
		kind: "decision",
		for: [n],
		secret: {
			label: o[s].label,
			clearing: o[s].clearing ?? null
		}
	}), At(c), c;
}
//#endregion
//#region src/games/root/view.ts
function yr(e, t) {
	let n = e.players.find((e) => e.rid === t);
	return {
		public: {
			version: e.version,
			map: e.map,
			active: e.active,
			acting: mr(e),
			phase: e.winner.length ? "done" : e.hospitals.length ? "hospital" : e.battle ? "battle" : e.command?.remaining ? "command" : e.game?.phase ?? "complete",
			players: e.players.map(({ hand: e, ...t }) => ({
				...t,
				handCount: e.length,
				publicHand: t.faction === "riverfolk" ? e : null
			})),
			pieces: e.pieces.map((e) => ({
				...e,
				plot: e.faceUp ? e.plot : null
			})),
			command: e.command,
			battle: e.battle,
			hospital: e.hospitals[0] ?? null,
			discard: e.discard,
			log: e.log,
			winner: e.winner,
			...e.game ? { table: {
				suits: e.game.suits,
				blocked: e.game.blocked,
				ferry: e.game.ferry,
				scorched: e.game.scorched,
				ruins: e.game.ruins.map((e) => ({
					clearing: e.clearing,
					count: e.items.length
				})),
				deckCount: e.game.deck.length,
				availableDominance: e.game.availableDominance,
				lostSouls: e.game.lostSouls,
				itemSupply: e.game.itemSupply,
				quests: e.game.quests,
				boards: e.game.boards.map(({ supporters: e, ...t }) => ({
					...t,
					supportersCount: e.length
				})),
				round: e.game.round,
				turn: e.game.turn,
				phase: e.game.phase,
				step: e.game.interrupts.length > 1 && !e.game.interrupts[0].selected ? "chooseEffect" : (e.game.interrupts[0] ?? e.game.tasks[0])?.kind ?? "turnEnd",
				actions: e.game.actions,
				used: e.game.used,
				decreeDone: e.game.decreeDone,
				riverboats: e.game.riverboats,
				mercenaries: e.game.mercenaries
			} } : {}
		},
		...n ? { private: {
			hand: n.hand,
			choices: hr(e, t),
			plots: e.pieces.filter((e) => e.owner === t && e.kind === "plot").map((e) => ({
				uid: e.uid,
				plot: e.plot
			})),
			...e.game ? {
				supporters: e.game.boards.find((e) => e.owner === t).supporters,
				peek: e.game.interrupts[0]?.kind === "peek" && e.game.interrupts[0].owner === t ? e.players.find((t) => t.rid === e.game.interrupts[0].target).hand : []
			} : {}
		} } : {}
	};
}
//#endregion
//#region src/games/root/rules.ts
var br = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: Ye,
	schemas: {
		config: $e,
		action: ut,
		publicView: vt,
		privateView: yt
	},
	setup(e, t, n) {
		return { state: en(e, t, n) };
	},
	reduce(e, t, n) {
		let r = [], i = _r(e, t, n.by, r);
		return i ? {
			state: i,
			fx: r
		} : { code: "games.root.invalidAction" };
	},
	viewFor: yr,
	status(e) {
		let t = Object.fromEntries(e.players.map((e) => [e.rid, e.vp]));
		return e.winner.length ? {
			phase: "done",
			winner: e.winner,
			ranking: [...e.order].sort((n, r) => Number(e.winner.includes(r)) - Number(e.winner.includes(n)) || t[r] - t[n]),
			scores: t
		} : {
			phase: e.game?.phase ?? "playing",
			scores: t
		};
	},
	nextTickIn(e) {
		return gr(e) ? e.battle ? 700 : 60 : null;
	}
};
//#endregion
//#region src/games/root/presentation.ts
function xr(e) {
	return (t, n) => e(Sr[t], n);
}
var Sr = {
	reviewShow: "games.root.reviewShow",
	reviewHide: "games.root.reviewHide",
	reviewConfirmAgain: "games.root.reviewConfirmAgain",
	reviewConfirmLobby: "games.root.reviewConfirmLobby",
	reviewCancel: "games.root.reviewCancel",
	cardSuitDominanceText: "games.root.cardSuitDominanceText",
	cardThreeClearings: "games.root.cardThreeClearings",
	cardWhenCrafted: "games.root.cardWhenCrafted",
	cardFavorBrief: "games.root.cardFavorBrief",
	cardOnceBirdsong: "games.root.cardOnceBirdsong",
	cardStartDaylight: "games.root.cardStartDaylight",
	cardStartBirdsong: "games.root.cardStartBirdsong",
	cardStartEvening: "games.root.cardStartEvening",
	cardInBirdsong: "games.root.cardInBirdsong",
	cardInBattle: "games.root.cardInBattle",
	cardAsAttacker: "games.root.cardAsAttacker",
	cardAsDefender: "games.root.cardAsDefender",
	cardArmorersBrief: "games.root.cardArmorersBrief",
	cardExtraHit: "games.root.cardExtraHit",
	cardBrutalTacticsBrief: "games.root.cardBrutalTacticsBrief",
	cardScoutingPartyBrief: "games.root.cardScoutingPartyBrief",
	cardStandAndDeliverBrief: "games.root.cardStandAndDeliverBrief",
	cardCommandWarrenBrief: "games.root.cardCommandWarrenBrief",
	cardBetterBurrowBankBrief: "games.root.cardBetterBurrowBankBrief",
	cardCobblerBrief: "games.root.cardCobblerBrief",
	cardTaxCollectorBrief: "games.root.cardTaxCollectorBrief",
	cardRoyalClaimBrief: "games.root.cardRoyalClaimBrief",
	cardSappersText: "games.root.cardSappersText",
	cardBrutalTacticsText: "games.root.cardBrutalTacticsText",
	cardScoutingPartyText: "games.root.cardScoutingPartyText",
	cardStandAndDeliverText: "games.root.cardStandAndDeliverText",
	cardCommandWarrenText: "games.root.cardCommandWarrenText",
	cardBetterBurrowBankText: "games.root.cardBetterBurrowBankText",
	cardCobblerText: "games.root.cardCobblerText",
	cardTaxCollectorText: "games.root.cardTaxCollectorText",
	cardRoyalClaimText: "games.root.cardRoyalClaimText",
	cardVizierBrief: "games.root.cardVizierBrief",
	cardVizierText: "games.root.cardVizierText",
	cardSuitDominance: "games.root.cardSuitDominance",
	cardCraftCost: "games.root.cardCraftCost",
	cardCraftedReward: "games.root.cardCraftedReward",
	cardOnceDaylight: "games.root.cardOnceDaylight",
	cardInspectHand: "games.root.cardInspectHand",
	cardImmediateHits: "games.root.cardImmediateHits",
	cardAmbushFoil: "games.root.cardAmbushFoil",
	cardDominanceActivate: "games.root.cardDominanceActivate",
	cardOppositeCorners: "games.root.cardOppositeCorners",
	cardBirdDominanceText: "games.root.cardBirdDominanceText",
	cardInspectHandText: "games.root.cardInspectHandText",
	cardAmbushText: "games.root.cardAmbushText",
	cardVictoryPoints: "games.root.cardVictoryPoints",
	servicePrices: "games.root.servicePrices",
	ministerCourt: "games.root.ministerCourt",
	battleAftermath: "games.root.battleAftermath",
	battleEffects: "games.root.battleEffects",
	battleLosses: "games.root.battleLosses",
	battleResult: "games.root.battleResult",
	battleResolving: "games.root.battleResolving",
	battleRemaining: "games.root.battleRemaining",
	battleAssigned: "games.root.battleAssigned",
	supplyArea: "games.root.supplyArea",
	itemSupply: "games.root.itemSupply",
	discardPile: "games.root.discardPile",
	chooseItemLoss: "games.root.chooseItemLoss",
	tower: "games.root.tower",
	scorched: "games.root.scorched",
	inspectClearing: "games.root.inspectClearing",
	vagabondFerry: "games.root.vagabondFerry",
	ferry: "games.root.ferry",
	crowns: "games.root.crowns",
	fundsUsed: "games.root.fundsUsed",
	resolveEffect: "games.root.resolveEffect",
	gardenLoss: "games.root.gardenLoss",
	hospitalPay: "games.root.hospitalPay",
	standAndDeliverText: "games.root.standAndDeliverText",
	commandWarrenText: "games.root.commandWarrenText",
	betterBurrowBankText: "games.root.betterBurrowBankText",
	cobblerText: "games.root.cobblerText",
	codebreakersText: "games.root.codebreakersText",
	taxCollectorText: "games.root.taxCollectorText",
	royalClaimText: "games.root.royalClaimText",
	favorText: "games.root.favorText",
	craft: "games.root.craft",
	winter: "games.root.winter",
	lake: "games.root.lake",
	mountain: "games.root.mountain",
	birdsong: "games.root.birdsong",
	evening: "games.root.evening",
	setup: "games.root.setup",
	continue: "games.root.continue",
	recruit: "games.root.recruit",
	build: "games.root.build",
	finishActions: "games.root.finishActions",
	finishCraft: "games.root.finishCraft",
	standAndDeliver: "games.root.standAndDeliver",
	commandWarren: "games.root.commandWarren",
	betterBurrowBank: "games.root.betterBurrowBank",
	cobbler: "games.root.cobbler",
	codebreakers: "games.root.codebreakers",
	taxCollector: "games.root.taxCollector",
	royalClaim: "games.root.royalClaim",
	swiftStrike: "games.root.swiftStrike",
	boot: "games.root.boot",
	sack: "games.root.sack",
	crossbow: "games.root.crossbow",
	hammer: "games.root.hammer",
	sword: "games.root.sword",
	tea: "games.root.tea",
	coin: "games.root.coin",
	torch: "games.root.torch",
	thief: "games.root.thief",
	tinker: "games.root.tinker",
	ranger: "games.root.ranger",
	vagrant: "games.root.vagrant",
	arbiter: "games.root.arbiter",
	scoundrel: "games.root.scoundrel",
	adventurer: "games.root.adventurer",
	harrier: "games.root.harrier",
	ronin: "games.root.ronin",
	foremole: "games.root.foremole",
	captain: "games.root.captain",
	marshal: "games.root.marshal",
	brigadier: "games.root.brigadier",
	banker: "games.root.banker",
	mayor: "games.root.mayor",
	duchess: "games.root.duchess",
	baron: "games.root.baron",
	earl: "games.root.earl",
	bomb: "games.root.bomb",
	snare: "games.root.snare",
	extortion: "games.root.extortion",
	raid: "games.root.raid",
	card: "games.root.card",
	boats: "games.root.boats",
	mercenaries: "games.root.mercenaries",
	birdyBindle: "games.root.birdyBindle",
	woodlandRunners: "games.root.woodlandRunners",
	armsTrader: "games.root.armsTrader",
	knapsack: "games.root.knapsack",
	rootTea: "games.root.rootTea",
	travelGear: "games.root.travelGear",
	protectionRacket: "games.root.protectionRacket",
	foxfolkSteel: "games.root.foxfolkSteel",
	anvil: "games.root.anvil",
	smugglersTrail: "games.root.smugglersTrail",
	visitFriends: "games.root.visitFriends",
	bakeSale: "games.root.bakeSale",
	mouseSack: "games.root.mouseSack",
	investments: "games.root.investments",
	favor: "games.root.favor",
	vizier: "games.root.vizier",
	fundraising: "games.root.fundraising",
	logistics: "games.root.logistics",
	repairShed: "games.root.repairShed",
	speech: "games.root.speech",
	errand: "games.root.errand",
	expelBandits: "games.root.expelBandits",
	fendBear: "games.root.fendBear",
	guardDuty: "games.root.guardDuty",
	escort: "games.root.escort",
	chooseClearing: "games.root.chooseClearing",
	chooseForest: "games.root.chooseForest",
	placeBuilding: "games.root.placeBuilding",
	recruitAt: "games.root.recruitAt",
	setPrice: "games.root.setPrice",
	payOutrage: "games.root.payOutrage",
	discardSupporter: "games.root.discardSupporter",
	returnFund: "games.root.returnFund",
	loseMinister: "games.root.loseMinister",
	damageItem: "games.root.damageItem",
	enlistArbiter: "games.root.enlistArbiter",
	craftCard: "games.root.craftCard",
	craftWith: "games.root.craftWith",
	exportCard: "games.root.exportCard",
	coalitionWith: "games.root.coalitionWith",
	activateDominance: "games.root.activateDominance",
	takeDominance: "games.root.takeDominance",
	inspectHand: "games.root.inspectHand",
	collectTax: "games.root.collectTax",
	clearPath: "games.root.clearPath",
	exposePlot: "games.root.exposePlot",
	buildAt: "games.root.buildAt",
	overworkAt: "games.root.overworkAt",
	extraAction: "games.root.extraAction",
	spendWood: "games.root.spendWood",
	addDecree: "games.root.addDecree",
	emergencyRoostAt: "games.root.emergencyRoostAt",
	fulfillMove: "games.root.fulfillMove",
	fulfillBattle: "games.root.fulfillBattle",
	placeRoost: "games.root.placeRoost",
	revoltAt: "games.root.revoltAt",
	finishRevolt: "games.root.finishRevolt",
	spreadAt: "games.root.spreadAt",
	finishSpread: "games.root.finishSpread",
	spendSupporter: "games.root.spendSupporter",
	organizeAt: "games.root.organizeAt",
	mobilizeCard: "games.root.mobilizeCard",
	trainOfficer: "games.root.trainOfficer",
	sacrifice: "games.root.sacrifice",
	cultScore: "games.root.cultScore",
	ritualRecruit: "games.root.ritualRecruit",
	ritualBuild: "games.root.ritualBuild",
	crusadeMove: "games.root.crusadeMove",
	crusadeBattle: "games.root.crusadeBattle",
	convertAt: "games.root.convertAt",
	sanctifyAt: "games.root.sanctifyAt",
	finishConspiracies: "games.root.finishConspiracies",
	fundMove: "games.root.fundMove",
	fundBattle: "games.root.fundBattle",
	fundDraw: "games.root.fundDraw",
	fundRecruit: "games.root.fundRecruit",
	establishPost: "games.root.establishPost",
	duchyBuild: "games.root.duchyBuild",
	recruitBurrow: "games.root.recruitBurrow",
	digAt: "games.root.digAt",
	ministerMove: "games.root.ministerMove",
	ministerBattle: "games.root.ministerBattle",
	bankerSuit: "games.root.bankerSuit",
	ministerScore: "games.root.ministerScore",
	finishParliament: "games.root.finishParliament",
	bankerSpend: "games.root.bankerSpend",
	finishBanker: "games.root.finishBanker",
	swayMinister: "games.root.swayMinister",
	finishSway: "games.root.finishSway",
	revealForSway: "games.root.revealForSway",
	plotAt: "games.root.plotAt",
	trickPlots: "games.root.trickPlots",
	flipPlot: "games.root.flipPlot",
	finishFlip: "games.root.finishFlip",
	corvidRecruit: "games.root.corvidRecruit",
	skipRecruit: "games.root.skipRecruit",
	exert: "games.root.exert",
	skipExert: "games.root.skipExert",
	slipForest: "games.root.slipForest",
	slipClearing: "games.root.slipClearing",
	vagabondMove: "games.root.vagabondMove",
	battleWithAlly: "games.root.battleWithAlly",
	explore: "games.root.explore",
	aidFaction: "games.root.aidFaction",
	questScore: "games.root.questScore",
	questDraw: "games.root.questDraw",
	strikePiece: "games.root.strikePiece",
	repairItem: "games.root.repairItem",
	stealCard: "games.root.stealCard",
	dayLabor: "games.root.dayLabor",
	hideout: "games.root.hideout",
	instigate: "games.root.instigate",
	scorchedEarth: "games.root.scorchedEarth",
	glideTo: "games.root.glideTo",
	refreshItem: "games.root.refreshItem",
	finishRefresh: "games.root.finishRefresh",
	skipSlip: "games.root.skipSlip",
	takeRuinItem: "games.root.takeRuinItem",
	finishRepair: "games.root.finishRepair",
	takeCraftedItem: "games.root.takeCraftedItem",
	skipItem: "games.root.skipItem",
	discardItem: "games.root.discardItem",
	finishPurchases: "games.root.finishPurchases",
	buyCard: "games.root.buyCard",
	buyBoats: "games.root.buyBoats",
	buyMercenaries: "games.root.buyMercenaries",
	claimRule: "games.root.claimRule",
	shareBank: "games.root.shareBank",
	standDeliver: "games.root.standDeliver",
	discardCard: "games.root.discardCard",
	produceWood: "games.root.produceWood",
	supporters: "games.root.supporters",
	officers: "games.root.officers",
	decree: "games.root.decree",
	acolytes: "games.root.acolytes",
	outcast: "games.root.outcast",
	hated: "games.root.hated",
	funds: "games.root.funds",
	committed: "games.root.committed",
	payments: "games.root.payments",
	ministers: "games.root.ministers",
	burrow: "games.root.burrow",
	items: "games.root.items",
	relationships: "games.root.relationships",
	quests: "games.root.quests",
	completedQuests: "games.root.completedQuests",
	craftedItems: "games.root.craftedItems",
	revealed: "games.root.revealed",
	exhausted: "games.root.exhausted",
	damaged: "games.root.damaged",
	hostile: "games.root.hostile",
	indifferent: "games.root.indifferent",
	allied: "games.root.allied",
	availableDominance: "games.root.availableDominance",
	deck: "games.root.deck",
	lostSouls: "games.root.lostSouls",
	actions: "games.root.actions",
	chooseAction: "games.root.chooseAction",
	chooseResponse: "games.root.chooseResponse",
	allActions: "games.root.allActions",
	filterClearing: "games.root.filterClearing",
	noChoices: "games.root.noChoices",
	mapOption: "games.root.mapOption",
	factionsOption: "games.root.factionsOption",
	allFactions: "games.root.allFactions",
	coreFactions: "games.root.coreFactions",
	secondVagabond: "games.root.secondVagabond",
	supplyPlace: "games.root.supplyPlace",
	draft: "games.root.draft",
	setupBegin: "games.root.setupBegin",
	setupCorner: "games.root.setupCorner",
	setupCatBuilding: "games.root.setupCatBuilding",
	setupLeader: "games.root.setupLeader",
	setupOutcast: "games.root.setupOutcast",
	setupRiver: "games.root.setupRiver",
	prices: "games.root.prices",
	setupCorvid: "games.root.setupCorvid",
	setupCharacter: "games.root.setupCharacter",
	setupForest: "games.root.setupForest",
	setupFinish: "games.root.setupFinish",
	turnStart: "games.root.turnStart",
	services: "games.root.services",
	birdEffects: "games.root.birdEffects",
	dayStart: "games.root.dayStart",
	eveningStart: "games.root.eveningStart",
	draw: "games.root.draw",
	discard: "games.root.discard",
	capacity: "games.root.capacity",
	turnEnd: "games.root.turnEnd",
	decreeAdd: "games.root.decreeAdd",
	emergencyRoost: "games.root.emergencyRoost",
	turmoil: "games.root.turmoil",
	allianceRevolt: "games.root.allianceRevolt",
	allianceSpread: "games.root.allianceSpread",
	allianceOps: "games.root.allianceOps",
	cultConspiracy: "games.root.cultConspiracy",
	corvidFlip: "games.root.corvidFlip",
	corvidExert: "games.root.corvidExert",
	vagabondRefresh: "games.root.vagabondRefresh",
	vagabondSlip: "games.root.vagabondSlip",
	duchyParliament: "games.root.duchyParliament",
	duchySway: "games.root.duchySway",
	swayCards: "games.root.swayCards",
	command: "games.root.command",
	woodPayment: "games.root.woodPayment",
	payCards: "games.root.payCards",
	chooseItem: "games.root.chooseItem",
	aidItem: "games.root.aidItem",
	outrage: "games.root.outrage",
	peek: "games.root.peek",
	baseLoss: "games.root.baseLoss",
	tradeLoss: "games.root.tradeLoss",
	failure: "games.root.failure",
	arbiterResponse: "games.root.arbiterResponse",
	removeTunnel: "games.root.removeTunnel",
	name: "games.root.name",
	desc: "games.root.desc",
	rules: "games.root.rules",
	marquise: "games.root.marquise",
	eyrie: "games.root.eyrie",
	alliance: "games.root.alliance",
	vagabond: "games.root.vagabond",
	cult: "games.root.cult",
	riverfolk: "games.root.riverfolk",
	duchy: "games.root.duchy",
	corvid: "games.root.corvid",
	fox: "games.root.fox",
	rabbit: "games.root.rabbit",
	mouse: "games.root.mouse",
	bird: "games.root.bird",
	warrior: "games.root.warrior",
	sawmill: "games.root.sawmill",
	workshop: "games.root.workshop",
	recruiter: "games.root.recruiter",
	roost: "games.root.roost",
	base: "games.root.base",
	garden: "games.root.garden",
	tradePost: "games.root.tradePost",
	citadel: "games.root.citadel",
	market: "games.root.market",
	keep: "games.root.keep",
	wood: "games.root.wood",
	sympathy: "games.root.sympathy",
	tunnel: "games.root.tunnel",
	plot: "games.root.plot",
	armorers: "games.root.armorers",
	brutalTactics: "games.root.brutalTactics",
	sappers: "games.root.sappers",
	scoutingParty: "games.root.scoutingParty",
	ambush: "games.root.ambush",
	counter: "games.root.counter",
	hospital: "games.root.hospital",
	item: "games.root.item",
	persistent: "games.root.persistent",
	dominance: "games.root.dominance",
	autumn: "games.root.autumn",
	daylight: "games.root.daylight",
	move: "games.root.move",
	march: "games.root.march",
	battle: "games.root.battle",
	selectOrigin: "games.root.selectOrigin",
	selectDestination: "games.root.selectDestination",
	selectBattle: "games.root.selectBattle",
	chooseAmbush: "games.root.chooseAmbush",
	chooseCounter: "games.root.chooseCounter",
	chooseHospital: "games.root.chooseHospital",
	chooseLoss: "games.root.chooseLoss",
	chooseEffect: "games.root.chooseEffect",
	chooseOrder: "games.root.chooseOrder",
	rolling: "games.root.rolling",
	resolving: "games.root.resolving",
	completed: "games.root.completed",
	victory: "games.root.victory",
	wait: "games.root.wait",
	clearing: "games.root.clearing",
	moveN: "games.root.moveN",
	battleAgainst: "games.root.battleAgainst",
	remaining: "games.root.remaining",
	cancel: "games.root.cancel",
	pass: "games.root.pass",
	endMarch: "games.root.endMarch",
	useCard: "games.root.useCard",
	playAmbush: "games.root.playAmbush",
	playCounter: "games.root.playCounter",
	remove: "games.root.remove",
	confirm: "games.root.confirm",
	hand: "games.root.hand",
	factionBoard: "games.root.factionBoard",
	close: "games.root.close",
	inspect: "games.root.inspect",
	count: "games.root.count",
	warriors: "games.root.warriors",
	vp: "games.root.vp",
	supply: "games.root.supply",
	handCount: "games.root.handCount",
	attacker: "games.root.attacker",
	defender: "games.root.defender",
	damage: "games.root.damage",
	hospitalCount: "games.root.hospitalCount",
	recenter: "games.root.recenter",
	zoomIn: "games.root.zoomIn",
	zoomOut: "games.root.zoomOut",
	board: "games.root.board",
	emptySlot: "games.root.emptySlot",
	ruin: "games.root.ruin",
	eventMove: "games.root.eventMove",
	eventBattle: "games.root.eventBattle",
	eventAmbush: "games.root.eventAmbush",
	eventCounter: "games.root.eventCounter",
	eventRoll: "games.root.eventRoll",
	eventLoss: "games.root.eventLoss",
	eventHospital: "games.root.eventHospital",
	eventSkipHospital: "games.root.eventSkipHospital",
	eventEffect: "games.root.eventEffect",
	eventComplete: "games.root.eventComplete",
	ambushText: "games.root.ambushText",
	hospitalText: "games.root.hospitalText",
	armorersText: "games.root.armorersText",
	brutalTacticsText: "games.root.brutalTacticsText",
	sappersText: "games.root.sappersText",
	scoutingPartyText: "games.root.scoutingPartyText",
	commander: "games.root.commander",
	despot: "games.root.despot",
	builder: "games.root.builder",
	charismatic: "games.root.charismatic",
	leader: "games.root.leader",
	invalidAction: "games.root.invalidAction"
}, Cr = {
	move: "eventMove",
	battle: "eventBattle",
	ambush: "eventAmbush",
	counter: "eventCounter",
	roll: "eventRoll",
	loss: "eventLoss",
	hospital: "eventHospital",
	skipHospital: "eventSkipHospital",
	effect: "eventEffect",
	complete: "eventComplete"
}, wr = (e, t, n) => t(Cr[e.type], {
	name: n(e.owner),
	n: e.n,
	from: e.from ?? "",
	to: e.clearing
});
function Tr(e, t) {
	return typeof e == "string" ? Object.hasOwn(Sr, e) ? t(e) : e.includes(", ") ? e.split(", ").map((e) => Tr(e, t)).join(" · ") : e : e;
}
function Er(e, t) {
	if (e.label && Object.hasOwn(Sr, e.label)) return t(e.label, Object.fromEntries(Object.entries(e.args ?? {}).map(([e, n]) => [e, Tr(n, t)])));
	let n = e.action;
	return n.type === "move" ? `${n.from || t("burrow")} → ${n.to || t("burrow")} · ${t("moveN", { n: n.n })}${n.via === "ferry" ? ` · ${t("ferry")}` : ""}` : n.type === "itemHit" ? t("damageItem", { item: "" }) : t(Object.hasOwn(Sr, e.kind) ? e.kind : "chooseResponse");
}
//#endregion
//#region src/games/root/battle-view.tsx
var Dr = {
	ambush: "ambush",
	counter: "counter",
	ambushHits: "ambush",
	ambushAftermath: "battleAftermath",
	roll: "rolling",
	effects: "battleEffects",
	hits: "battleLosses",
	result: "battleResult"
};
function Or({ value: e, rolling: t, label: n }) {
	let r = e === 1 ? [[20, 20]] : e === 2 ? [[12, 12], [28, 28]] : e === 3 ? [
		[11, 11],
		[20, 20],
		[29, 29]
	] : [];
	return /* @__PURE__ */ j("span", {
		className: `root-battle-die${t ? " root-die-rolling" : ""}${e === null ? "" : " root-die-settled"}`,
		"aria-label": `${n}: ${e ?? "—"}`,
		children: [/* @__PURE__ */ j("svg", {
			viewBox: "0 0 40 40",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ A("path", {
				d: "M8 3h24q5 0 5 5v24q0 5-5 5H8q-5 0-5-5V8q0-5 5-5Z",
				fill: "currentColor",
				fillOpacity: ".07"
			}), r.map(([e, t], n) => /* @__PURE__ */ A("circle", {
				cx: e,
				cy: t,
				r: "3.6",
				fill: "currentColor"
			}, n))]
		}), /* @__PURE__ */ A("b", { children: e ?? "—" })]
	}, e ?? "unrolled");
}
function kr({ view: e, t, name: n }) {
	let { ref: r } = Ie("battle"), i = e.battle, a = e.hospital, o = !!a || e.table?.step === "hospital";
	if (!i && !o) return null;
	let s = e.acting && e.players.find((t) => t.rid === e.acting), c = i && e.players.find((e) => e.rid === i.defender).faction === "alliance", l = i?.dice ? c ? [Math.min(...i.dice), Math.max(...i.dice)] : [Math.max(...i.dice), Math.min(...i.dice)] : null, u = o ? "hospital" : Dr[i.stage];
	return /* @__PURE__ */ j("section", {
		ref: r,
		className: "root-battle-panel",
		"data-edge": i && v(le(e), i.clearing).z > 0 ? "top" : "bottom",
		"aria-label": t(i ? "battle" : "hospital"),
		children: [
			/* @__PURE__ */ j("header", {
				className: "root-battle-header",
				children: [/* @__PURE__ */ j("span", { children: [
					t(i ? "battle" : "hospital"),
					" ",
					(i || a) && /* @__PURE__ */ j("b", { children: ["· ", i?.clearing ?? a.clearing] })
				] }), /* @__PURE__ */ A("strong", {
					className: "root-battle-stage",
					children: t(u)
				}, u)]
			}),
			i && /* @__PURE__ */ j(k, { children: [
				/* @__PURE__ */ A("div", {
					className: "root-battle-sides",
					children: [i.attacker, i.defender].map((n, r) => {
						let a = e.players.find((e) => e.rid === n), o = e.table?.boards.find((e) => e.owner === n), s = e.pieces.filter((e) => e.owner === n && e.clearing === i.clearing && e.kind === "warrior").reduce((e, t) => e + t.count, 0), c = i.selectedLosses.filter((e) => e.owner === n).reduce((e, t) => e + t.n, 0), u = i.hits.filter((e) => e.owner === n).reduce((e, t) => e + t.remaining, 0);
						return /* @__PURE__ */ j("div", {
							className: `root-battle-side${e.acting === n ? " root-battle-responding" : ""}`,
							style: { "--root-faction": T[a.faction] },
							children: [
								/* @__PURE__ */ A("span", {
									className: "root-battle-role",
									children: t(r ? "defender" : "attacker")
								}),
								/* @__PURE__ */ j("div", {
									className: "root-battle-portrait",
									children: [/* @__PURE__ */ A(C, { faction: a.faction }), /* @__PURE__ */ A(Or, {
										value: l?.[r] ?? null,
										rolling: i.stage === "roll",
										label: t(r ? "defender" : "attacker")
									})]
								}),
								/* @__PURE__ */ A("strong", {
									className: "root-battle-faction",
									children: t(a.faction)
								}),
								/* @__PURE__ */ A("span", {
									className: "root-battle-strength",
									children: o?.character ? /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A(se, { item: "sword" }), /* @__PURE__ */ A(ae, { value: o.items.filter((e) => e.type === "sword" && !e.damaged).length })] }) : t("warriors", { n: s })
								}),
								(u > 0 || c > 0) && /* @__PURE__ */ A("span", {
									className: "root-battle-hits",
									children: u > 0 ? t("battleRemaining", { n: u }) : t("battleAssigned", { n: c })
								}, `${u}:${c}:${i.stage}`)
							]
						}, n);
					})
				}),
				i.usedEffects.length > 0 && /* @__PURE__ */ A("div", {
					className: "root-battle-effects",
					children: i.usedEffects.map((n) => /* @__PURE__ */ A("span", {
						style: { "--root-faction": T[e.players.find((e) => e.rid === n.owner).faction] },
						children: t(n.effect)
					}, `${n.owner}:${n.effect}`))
				}),
				i.ambushCard && /* @__PURE__ */ j("div", {
					className: "root-battle-ambush",
					children: [/* @__PURE__ */ A(ge, { card: i.ambushCard }), /* @__PURE__ */ j("span", { children: [
						t("ambush"),
						" · ",
						t(i.ambushCard.suit)
					] })]
				}, i.ambushCard.uid)
			] }),
			a && /* @__PURE__ */ j("div", {
				className: "root-battle-hospital",
				children: [/* @__PURE__ */ A(C, { faction: "marquise" }), /* @__PURE__ */ j("span", { children: [
					t("hospital"),
					" · ",
					t("hospitalCount", { n: a.count })
				] })]
			}, `${a.owner}:${a.clearing}`),
			/* @__PURE__ */ A("footer", {
				className: "root-battle-responder",
				"aria-live": "polite",
				children: s ? /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A(C, { faction: s.faction }), /* @__PURE__ */ A("span", { children: t("wait", { name: n(s.rid) }) })] }) : /* @__PURE__ */ A("span", { children: t(i?.stage === "result" ? "battleResult" : i?.stage === "roll" ? "rolling" : "battleResolving") })
			})
		]
	});
}
//#endregion
//#region src/games/root/faction-panel.tsx
var Ar = {
	armorers: "armorersText",
	brutalTactics: "brutalTacticsText",
	sappers: "sappersText",
	scoutingParty: "scoutingPartyText",
	standAndDeliver: "standAndDeliverText",
	commandWarren: "commandWarrenText",
	betterBurrowBank: "betterBurrowBankText",
	cobbler: "cobblerText",
	codebreakers: "codebreakersText",
	taxCollector: "taxCollectorText",
	royalClaim: "royalClaimText"
}, jr = (e) => JSON.stringify(e), Mr = {
	codebreakers: ["inspectHand"],
	taxCollector: ["collectTax"],
	royalClaim: ["claimRule"],
	betterBurrowBank: ["shareBank"],
	standAndDeliver: ["standDeliver"],
	commandWarren: ["commandWarren"],
	cobbler: ["cobbler"]
};
function Nr({ children: e, className: t = "", choices: n = [], title: r, label: i, onChoices: a, anchor: o, onInspect: s }) {
	let { ref: c, hidden: l } = Ie(o ?? null), u = { visibility: l ? "hidden" : void 0 };
	return n.length ? /* @__PURE__ */ j("button", {
		ref: c,
		className: `root-object root-object-available ${t}`,
		style: u,
		"aria-label": i,
		onClick: () => a({
			title: r,
			actions: n.map((e) => jr(e.action))
		}),
		children: [e, /* @__PURE__ */ A(de, {})]
	}) : s ? /* @__PURE__ */ A("button", {
		ref: c,
		className: `root-object root-object-viewable ${t}`,
		style: u,
		"aria-label": i,
		onClick: s,
		children: e
	}) : /* @__PURE__ */ A("div", {
		ref: c,
		className: `root-object ${t}`,
		style: u,
		"aria-label": i,
		children: e
	});
}
function Pr({ n: e, faction: t }) {
	return /* @__PURE__ */ j("span", {
		className: "root-reserve-pieces",
		"aria-hidden": "true",
		children: [Array.from({ length: Math.min(e, 8) }, (e, n) => /* @__PURE__ */ A(C, { faction: t }, n)), e === 0 && /* @__PURE__ */ A("span", { children: "—" })]
	});
}
function Fr({ view: e, rid: t, t: n, privateView: r, inBoard: i = !1, onChoices: a, onCard: s }) {
	let { ref: c } = Ie(i ? `faction:${t}` : `inspection:${t}`), l = Le(), f = e.players.find((e) => e.rid === t), p = e.table, m = e.pieces.filter((e) => e.owner === t), g = p?.boards.find((e) => e.owner === t), _ = r?.choices ?? [], y = (...e) => _.filter((t) => e.includes(t.label ?? "")), te = (e) => m.filter((t) => t.kind === e).reduce((e, t) => e + t.count, 0), ne = (e) => _.filter((t) => t.args?.cardUid === e || t.action.type === "card" && t.action.uid === e), ie = (e) => /* @__PURE__ */ A("div", {
		className: "root-public-hand",
		children: e.map((e) => /* @__PURE__ */ A(oe, {
			card: e,
			t: n,
			active: ne(e.uid).length > 0,
			onClick: () => s(e)
		}, e.uid))
	}), x = (e, t, r, i, o, s) => /* @__PURE__ */ A(Nr, {
		className: e,
		title: t,
		label: s ?? n(t),
		choices: i,
		onChoices: a,
		anchor: o,
		children: r
	}), S = (e) => _.filter((t) => {
		if (t.action.type === "itemHit") return t.action.uid === e.uid;
		if (t.args?.item !== e.type || ![
			"repairItem",
			"refreshItem",
			"discardItem"
		].includes(t.label ?? "")) return !1;
		let n = g.items.filter((n) => n.type === e.type && (t.label === "repairItem" ? n.damaged : t.label !== "refreshItem" || n.exhausted));
		return n[_.filter((n) => n.label === t.label && n.args?.item === e.type).indexOf(t) % n.length]?.uid === e.uid;
	});
	return /* @__PURE__ */ j("section", {
		className: "root-faction-panel",
		style: { "--root-faction": T[f.faction] },
		children: [
			/* @__PURE__ */ j("header", {
				ref: c,
				children: [/* @__PURE__ */ A(C, { faction: f.faction }), /* @__PURE__ */ A("h2", { children: n(f.faction) })]
			}),
			/* @__PURE__ */ A("dl", {
				className: "root-faction-stats",
				children: [
					"supply",
					"hand",
					"vp"
				].map((e) => /* @__PURE__ */ j("div", { children: [/* @__PURE__ */ A("dt", { children: e === "vp" ? "◆" : n(e) }), /* @__PURE__ */ A("dd", {
					"aria-label": e === "vp" ? n("vp", { n: f.vp }) : void 0,
					children: /* @__PURE__ */ A(ae, { value: e === "supply" ? f.supply : e === "hand" ? f.handCount : f.vp })
				})] }, e))
			}),
			f.faction === "marquise" && /* @__PURE__ */ A("div", {
				className: "root-building-tracks",
				children: [
					"sawmill",
					"workshop",
					"recruiter"
				].map((e) => {
					let t = te(e);
					return /* @__PURE__ */ j("section", {
						className: "root-building-track",
						children: [/* @__PURE__ */ j("h3", { children: [/* @__PURE__ */ A(fe, { kind: e }), n(e)] }), x("root-building-rail", e, /* @__PURE__ */ A(k, { children: h.map((n, r) => /* @__PURE__ */ j("span", {
							className: `root-track-slot${r < t ? " root-track-built" : ""}${r === t ? " root-track-next" : ""}`,
							children: [
								/* @__PURE__ */ j("small", { children: [/* @__PURE__ */ A(fe, { kind: "wood" }), n] }),
								r < t ? /* @__PURE__ */ A("b", {
									className: "root-track-check",
									children: "✓"
								}) : /* @__PURE__ */ A(fe, { kind: e }),
								/* @__PURE__ */ j("em", { children: [o[e][r], "◆"] })
							]
						}, r)) }), _.filter((t) => t.args?.piece === e && ["buildAt", "placeBuilding"].includes(t.label ?? "")))]
					}, e);
				})
			}),
			f.faction === "eyrie" && /* @__PURE__ */ j(k, { children: [
				/* @__PURE__ */ A("div", {
					className: "root-roost-track",
					"aria-label": n("roost"),
					children: d.slice(1).map((e, t) => /* @__PURE__ */ j("span", {
						className: t < te("roost") ? "root-roost-built" : "",
						children: [/* @__PURE__ */ A(fe, { kind: "roost" }), /* @__PURE__ */ j("b", { children: [e, "◆"] })]
					}, t))
				}),
				f.leader && /* @__PURE__ */ j("p", {
					className: "root-leader",
					children: [
						/* @__PURE__ */ A(C, { faction: "eyrie" }),
						/* @__PURE__ */ A("span", { children: n("leader") }),
						/* @__PURE__ */ A("strong", { children: n(f.leader) })
					]
				}),
				g && /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A("h3", {
					className: "root-panel-label",
					children: n("decree")
				}), /* @__PURE__ */ A("div", {
					className: "root-decree",
					children: [
						"recruit",
						"move",
						"battle",
						"build"
					].map((e) => /* @__PURE__ */ j("div", {
						ref: (n) => {
							i && l?.register(`decree:${t}:${e}`, n);
						},
						children: [x("root-decree-heading", e, /* @__PURE__ */ A("b", { children: n(e) }), _.filter((t) => t.label === "addDecree" && t.args?.column === e)), g.decree.filter((t) => t.column === e).map((t) => /* @__PURE__ */ j(Nr, {
							title: e,
							className: `root-decree-card${p.decreeDone.includes(t.card.uid) ? " root-decree-done" : ""}`,
							anchor: i ? `decree-card:${t.card.uid}` : void 0,
							onChoices: a,
							choices: p.decreeDone.includes(t.card.uid) ? [] : _.filter((n) => (e === "move" && n.label === "fulfillMove" || e === "battle" && n.label === "fulfillBattle") && n.args?.suit === t.card.suit),
							children: [
								/* @__PURE__ */ A(ce, { suit: t.card.suit }),
								/* @__PURE__ */ A("small", { children: Tr(t.card.id, n) }),
								p.decreeDone.includes(t.card.uid) && /* @__PURE__ */ A("b", {
									"aria-hidden": "true",
									children: "✓"
								})
							]
						}, t.card.uid))]
					}, e))
				})] })
			] }),
			f.faction !== "marquise" && f.faction !== "eyrie" && /* @__PURE__ */ A("div", {
				className: "root-building-counts",
				children: [...new Set(m.map((e) => e.kind))].filter((e) => ![
					"warrior",
					"sympathy",
					"garden",
					"plot"
				].includes(e)).map((e) => /* @__PURE__ */ j("div", { children: [/* @__PURE__ */ j("span", { children: [/* @__PURE__ */ A(fe, { kind: e }), n(e)] }), /* @__PURE__ */ A("b", { children: te(e) })] }, e))
			}),
			g && p && /* @__PURE__ */ j("div", {
				className: "root-faction-details",
				children: [
					f.faction === "alliance" && /* @__PURE__ */ j(k, { children: [
						/* @__PURE__ */ A("h3", { children: n("sympathy") }),
						x("root-sympathy-track", "allianceSpread", /* @__PURE__ */ A(k, { children: re.map((e, t) => /* @__PURE__ */ j("span", {
							className: t < te("sympathy") ? "root-token-deployed" : "",
							children: [
								/* @__PURE__ */ A("small", { children: u[t] }),
								/* @__PURE__ */ A(fe, { kind: "sympathy" }),
								/* @__PURE__ */ j("b", { children: [e, "◆"] })
							]
						}, t)) }), y("spreadAt")),
						/* @__PURE__ */ j("div", {
							className: "root-reserve-row",
							children: [x("root-reserve-bowl", "supporters", /* @__PURE__ */ j(k, { children: [
								/* @__PURE__ */ A("span", {
									className: "root-small-card-stack",
									"aria-hidden": "true",
									children: /* @__PURE__ */ A(ce, { suit: "mouse" })
								}),
								/* @__PURE__ */ A("b", { children: /* @__PURE__ */ A(ae, { value: g.supportersCount }) }),
								/* @__PURE__ */ A("span", { children: n("supporters") })
							] }), y("spendSupporter")), x("root-reserve-bowl", "officers", /* @__PURE__ */ j(k, { children: [
								/* @__PURE__ */ A(Pr, {
									n: g.officers,
									faction: "alliance"
								}),
								/* @__PURE__ */ A("b", { children: /* @__PURE__ */ A(ae, { value: g.officers }) }),
								/* @__PURE__ */ A("span", { children: n("officers") })
							] }), y("move", "battle", "organizeAt", "recruitAt"))]
						}),
						r?.supporters && ie(r.supporters)
					] }),
					f.faction === "cult" && /* @__PURE__ */ j(k, { children: [
						x(`root-outcast${g.hated ? " root-outcast-hated" : ""}`, "outcast", /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A(ce, { suit: g.outcast }), /* @__PURE__ */ j("span", { children: [n("outcast"), g.hated && /* @__PURE__ */ A("b", { children: n("hated") })] })] }), p.step === "setupOutcast" ? y("fox", "rabbit", "mouse") : []),
						[
							"fox",
							"rabbit",
							"mouse"
						].map((t) => {
							let n = m.filter((n) => n.kind === "garden" && v(le(e), n.clearing).suit === t).reduce((e, t) => e + t.count, 0);
							return /* @__PURE__ */ j("div", {
								className: "root-garden-row",
								children: [/* @__PURE__ */ A(ce, { suit: t }), x("root-garden-track", "garden", /* @__PURE__ */ A(k, { children: ye.slice(1).map((e, t) => /* @__PURE__ */ j("span", {
									className: t < n ? "root-token-deployed" : "",
									children: [/* @__PURE__ */ A(fe, { kind: "garden" }), /* @__PURE__ */ j("b", { children: [e, "◆"] })]
								}, t)) }), _.filter((n) => ["ritualBuild", "cultScore"].includes(n.label ?? "") && (n.args?.suit === t || n.clearing !== null && n.clearing > 0 && v(le(e), n.clearing).suit === t)))]
							}, t);
						}),
						x("root-reserve-bowl", "acolytes", /* @__PURE__ */ j(k, { children: [
							/* @__PURE__ */ A(Pr, {
								n: g.acolytes,
								faction: "cult"
							}),
							/* @__PURE__ */ A("b", { children: /* @__PURE__ */ A(ae, { value: g.acolytes }) }),
							/* @__PURE__ */ A("span", { children: n("acolytes") })
						] }), y("crusadeMove", "crusadeBattle", "convertAt", "sanctifyAt")),
						/* @__PURE__ */ j("h3", { children: [
							n("lostSouls"),
							" · ",
							p.lostSouls.length
						] }),
						ie(p.lostSouls)
					] }),
					f.faction === "riverfolk" && /* @__PURE__ */ j(k, { children: [
						/* @__PURE__ */ A("div", {
							className: "root-funds-board",
							children: [
								"funds",
								"committed",
								"payments"
							].map((t) => /* @__PURE__ */ j(Nr, {
								className: "root-funds-bowl",
								title: t,
								onChoices: a,
								label: n(t),
								choices: t === "funds" ? y("fundMove", "fundBattle", "fundDraw", "fundRecruit", "establishPost") : [],
								children: [
									/* @__PURE__ */ A("b", { children: n(t) }),
									/* @__PURE__ */ A("div", { children: g[t].map((t, r) => {
										let i = e.players.find((e) => e.rid === t).faction;
										return /* @__PURE__ */ j("span", {
											style: { color: T[i] },
											title: n(i),
											children: [/* @__PURE__ */ A(C, { faction: i }), /* @__PURE__ */ A("span", {
												className: "sr-only",
												children: n(i)
											})]
										}, r);
									}) }),
									/* @__PURE__ */ A("strong", { children: /* @__PURE__ */ A(ae, { value: g[t].length }) })
								]
							}, t))
						}),
						/* @__PURE__ */ A("h3", { children: n("servicePrices") }),
						/* @__PURE__ */ A("div", {
							className: "root-services",
							children: [
								"card",
								"boats",
								"mercenaries"
							].map((e) => /* @__PURE__ */ A("div", { children: x("root-service-tag", e, /* @__PURE__ */ j(k, { children: [
								/* @__PURE__ */ A("svg", {
									className: "root-service-art",
									viewBox: "0 0 64 44",
									"aria-hidden": "true",
									children: /* @__PURE__ */ A("g", {
										fill: T[e === "card" ? "paper" : "riverfolk"],
										stroke: T.ink,
										strokeWidth: "1.5",
										children: e === "card" ? /* @__PURE__ */ j(k, { children: [
											/* @__PURE__ */ A("path", { d: "m15 6 25-3 6 33-25 4Z" }),
											/* @__PURE__ */ A("path", {
												d: "m25 10 24 3-4 29-24-3Z",
												fill: T.cream
											}),
											/* @__PURE__ */ A("path", {
												d: "m34 19 5 5-6 6-5-6Z",
												fill: T.gold
											})
										] }) : e === "boats" ? /* @__PURE__ */ j(k, { children: [
											/* @__PURE__ */ A("path", { d: "m6 27 51-5-8 15-32 2Z" }),
											/* @__PURE__ */ A("path", {
												d: "M30 24V3L47 20H30",
												fill: T.cream
											}),
											/* @__PURE__ */ A("path", {
												d: "m5 41 10-2 12 2 12-2 15 1",
												fill: "none"
											})
										] }) : /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A("path", { d: "M18 38V16h12v22m5 0V19h12v19" }), /* @__PURE__ */ A("path", {
											d: "m15 17 9-10 9 10m0 2 8-9 9 9M11 35V4l7 3-7 4m42 25V5",
											fill: "none"
										})] })
									})
								}),
								/* @__PURE__ */ A("span", { children: n(e) }),
								/* @__PURE__ */ A("strong", { children: g.prices[e] })
							] }), _.filter((t) => t.label === "setPrice" && t.args?.service === e)) }, e))
						})
					] }),
					f.faction === "duchy" && /* @__PURE__ */ j(k, { children: [
						/* @__PURE__ */ j("div", {
							className: "root-burrow-reserve",
							children: [
								/* @__PURE__ */ A(fe, { kind: "tunnel" }),
								/* @__PURE__ */ A("span", { children: n("burrow") }),
								/* @__PURE__ */ A("b", { children: /* @__PURE__ */ A(ae, { value: g.location }) }),
								/* @__PURE__ */ A(Pr, {
									n: g.location,
									faction: "duchy"
								})
							]
						}),
						/* @__PURE__ */ A("h3", { children: n("crowns") }),
						/* @__PURE__ */ A("div", {
							className: "root-crown-bank",
							children: [
								2,
								3,
								4
							].map((e) => /* @__PURE__ */ j("div", { children: [/* @__PURE__ */ A("b", { children: e }), [
								0,
								1,
								2
							].map((t) => /* @__PURE__ */ A("span", {
								className: t < g.crownsLost.filter((t) => t === e).length ? "root-crown-lost" : t < g.crownsLost.filter((t) => t === e).length + g.ministers.filter((t) => b[t] === e).length ? "root-crown-spent" : "",
								children: /* @__PURE__ */ A(_e, {})
							}, t))] }, e))
						}),
						/* @__PURE__ */ A("h3", { children: n("ministerCourt") }),
						/* @__PURE__ */ A("div", {
							className: "root-ministers",
							children: ee.map((e) => {
								let t = g.ministers.includes(e), r = p.used.includes(`minister:${e}`);
								return /* @__PURE__ */ j(Nr, {
									className: `root-minister${t ? " root-minister-swayed" : ""}${r ? " root-minister-used" : ""}`,
									title: e,
									label: n(e),
									onChoices: a,
									choices: _.filter((n) => n.args?.minister === e || e === "banker" && t && !r && n.label === "bankerSuit" || e === "foremole" && t && !r && n.label === "duchyBuild" && p.step === "duchyParliament"),
									children: [
										/* @__PURE__ */ j("span", {
											className: "root-minister-rank",
											children: [/* @__PURE__ */ A(_e, {}), b[e]]
										}),
										/* @__PURE__ */ A(C, { faction: "duchy" }),
										/* @__PURE__ */ A("strong", { children: n(e) }),
										t && /* @__PURE__ */ A("b", {
											className: "root-minister-seal",
											children: r ? "✓" : "◆"
										})
									]
								}, e);
							})
						})
					] }),
					g.character && /* @__PURE__ */ j(k, { children: [
						/* @__PURE__ */ j("p", {
							className: "root-character",
							children: [
								/* @__PURE__ */ A(C, { faction: "vagabond" }),
								/* @__PURE__ */ A("strong", { children: Tr(g.character, n) }),
								/* @__PURE__ */ A("span", { children: g.location < 0 ? n("chooseForest", { n: -g.location }) : n("chooseClearing", { n: g.location }) })
							]
						}),
						/* @__PURE__ */ A("h3", { children: n("items") }),
						/* @__PURE__ */ A("div", {
							className: "root-item-grid root-satchel",
							children: g.items.map((e) => /* @__PURE__ */ j(Nr, {
								title: e.type,
								label: [
									n(e.type),
									e.exhausted ? n("exhausted") : "",
									e.damaged ? n("damaged") : ""
								].filter(Boolean).join(" · "),
								anchor: i ? `item:${e.uid}` : void 0,
								className: `root-item${e.exhausted ? " root-item-exhausted" : ""}${e.damaged ? " root-item-damaged" : ""}`,
								choices: S(e),
								onChoices: a,
								children: [
									/* @__PURE__ */ A(se, { item: e.type }),
									/* @__PURE__ */ A("b", { children: n(e.type) }),
									e.exhausted && /* @__PURE__ */ A("small", { children: n("exhausted") }),
									e.damaged && /* @__PURE__ */ A("small", { children: n("damaged") })
								]
							}, e.uid))
						}),
						/* @__PURE__ */ A("h3", { children: n("relationships") }),
						/* @__PURE__ */ A("div", {
							className: "root-relationships",
							children: g.relationships.map((t) => {
								let r = e.players.find((e) => e.rid === t.owner).faction;
								return /* @__PURE__ */ j("div", {
									style: { "--root-relation-faction": T[r] },
									children: [
										/* @__PURE__ */ j("span", { children: [/* @__PURE__ */ A(C, { faction: r }), n(r)] }),
										/* @__PURE__ */ A("div", {
											className: "root-relation-track",
											"aria-label": String(t.level),
											children: [
												-1,
												0,
												1,
												2,
												3
											].map((e) => /* @__PURE__ */ A("span", {
												className: t.level === e ? "root-relation-current" : "",
												children: e === -1 ? "×" : e === 0 ? "·" : e === 3 ? "◆" : e
											}, e))
										}),
										/* @__PURE__ */ A("small", { children: t.level < 0 ? n("hostile") : t.level === 0 ? n("indifferent") : t.level === 3 ? n("allied") : t.level })
									]
								}, t.owner);
							})
						}),
						/* @__PURE__ */ j("h3", { children: [
							n("completedQuests"),
							" · ",
							g.completedQuests.length
						] }),
						/* @__PURE__ */ A("div", {
							className: "root-quests",
							children: p.quests.map((e) => /* @__PURE__ */ j(Nr, {
								title: "quests",
								onChoices: a,
								className: "root-quest",
								choices: _.filter((t) => t.args?.quest === e.id && t.args?.items === e.items.join(", ")),
								children: [
									/* @__PURE__ */ A(ce, { suit: e.suit }),
									/* @__PURE__ */ A("strong", { children: Tr(e.id, n) }),
									/* @__PURE__ */ A("span", { children: e.items.map((e, t) => /* @__PURE__ */ A(se, { item: e }, t)) })
								]
							}, `${e.suit}:${e.id}`))
						})
					] }),
					f.faction === "corvid" && /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A("h3", { children: n("plot") }), /* @__PURE__ */ A("div", {
						className: "root-plots",
						children: m.filter((e) => e.kind === "plot").map((e) => {
							let t = r?.plots.find((t) => t.uid === e.uid)?.plot ?? e.plot;
							return /* @__PURE__ */ j(Nr, {
								title: "plot",
								className: `root-plot${e.faceUp ? " root-plot-faceup" : ""}`,
								label: `${n("chooseClearing", { n: e.clearing })}${t ? ` · ${n(t)}` : ""}`,
								choices: _.filter((t) => t.clearing === e.clearing && ["flipPlot", "exposePlot"].includes(t.label ?? "")),
								onChoices: a,
								children: [
									/* @__PURE__ */ A("span", {
										className: "root-plot-location",
										children: e.clearing
									}),
									/* @__PURE__ */ A(pe, { plot: t }),
									/* @__PURE__ */ A("b", { children: n(t || "plot") }),
									e.faceUp && /* @__PURE__ */ A("small", { children: "◆" })
								]
							}, e.uid);
						})
					})] }),
					g.revealed.length > 0 && /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A("h3", { children: n("revealed") }), ie(g.revealed)] }),
					g.craftedItems.length > 0 && /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A("h3", { children: n("craftedItems") }), /* @__PURE__ */ A("div", {
						className: "root-item-grid",
						children: g.craftedItems.map((e, t) => /* @__PURE__ */ j("div", {
							className: "root-item",
							children: [/* @__PURE__ */ A(se, { item: e }), /* @__PURE__ */ A("b", { children: n(e) })]
						}, t))
					})] }),
					g.dominance && /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A("h3", { children: n("dominance") }), ie([g.dominance])] }),
					p.riverboats.includes(t) && /* @__PURE__ */ j("p", {
						className: "root-service-receipt",
						children: [n("boats"), " ◆"]
					}),
					p.mercenaries.includes(t) && /* @__PURE__ */ j("p", {
						className: "root-service-receipt",
						children: [n("mercenaries"), " ◆"]
					})
				]
			}),
			f.effects.length > 0 && /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A("h3", {
				className: "root-panel-label",
				children: n("persistent")
			}), /* @__PURE__ */ A("div", {
				className: "root-effects-board",
				children: f.effects.map((e) => /* @__PURE__ */ j(Nr, {
					className: "root-effect-card",
					title: e.effect,
					choices: _.filter((t) => t.action.type === "effect" && t.action.effect === e.effect || Mr[e.effect]?.includes(t.label ?? "") || p?.step === e.effect && t.kind === "option" && t.label !== "pass"),
					onChoices: a,
					onInspect: () => s(e.card),
					label: n(e.effect),
					children: [/* @__PURE__ */ A(ge, { card: e.card }), /* @__PURE__ */ j("span", { children: [/* @__PURE__ */ A(ce, { suit: e.card.suit }), /* @__PURE__ */ A("strong", { children: n(e.effect) })] })]
				}, e.card.uid))
			})] }),
			f.publicHand && ie(f.publicHand)
		]
	});
}
//#endregion
//#region src/games/root/view-player.tsx
var Ir = Ce(() => import("@bgparty/game/chunks/board3d-B9ZwzdxF.js")), Lr = [
	{
		key: "build",
		labels: ["buildAt", "placeRoost"]
	},
	{
		key: "craft",
		labels: ["craftCard"]
	},
	{
		key: "decreeAdd",
		labels: ["addDecree"]
	},
	{
		key: "move",
		labels: [
			"fulfillMove",
			"vagabondMove",
			"vagabondFerry"
		]
	},
	{
		key: "battle",
		labels: [
			"fulfillBattle",
			"battleAgainst",
			"battleWithAlly"
		]
	},
	{
		key: "allianceSpread",
		labels: ["spreadAt"]
	},
	{
		key: "allianceRevolt",
		labels: ["revoltAt"]
	}
];
function Rr({ open: e, children: t }) {
	let n = Ee(null);
	return we(() => {
		if (!e) return;
		let t = document.activeElement;
		return n.current?.focus({ preventScroll: !0 }), () => {
			t?.isConnected && t.focus({ preventScroll: !0 });
		};
	}, [e]), /* @__PURE__ */ A("div", {
		ref: n,
		tabIndex: -1,
		className: "root-inspect-content",
		onKeyDown: (e) => {
			if (e.key !== "Tab") return;
			let t = (n.current?.closest("[role=\"dialog\"]"))?.querySelectorAll("button:not(:disabled), input, [tabindex=\"0\"]"), r = t?.[0], i = t?.[t.length - 1];
			r && i && (document.activeElement === n.current || e.shiftKey && document.activeElement === r || !e.shiftKey && document.activeElement === i) && (e.preventDefault(), (e.shiftKey ? i : r).focus());
		},
		children: t
	});
}
function zr(e) {
	Ae();
	let t = xr(ke()), n = Le(), r = e.public, i = e.private, [a, o] = De({
		version: -1,
		from: null,
		to: null,
		n: 1
	}), [s, c] = De(null), [l, u] = De(!1), d = a.version === r.version ? a : {
		version: r.version,
		from: null,
		to: null,
		n: 1
	}, f = r.phase === "done" ? [] : i?.choices ?? [], p = r.players.find((t) => t.rid === e.myRid), m = r.battle, h = (n) => e.members.find((e) => e.rid === n)?.name ?? t(r.players.find((e) => e.rid === n).faction), g = (e) => {
		c(e), u(!0);
	}, _ = () => u(!1), y = (t) => {
		_(), e.send(t);
	}, ee = (e) => g({
		kind: "object",
		version: r.version,
		...e
	}), te = (e) => g({
		kind: "card",
		card: e
	}), b = f.flatMap((e) => e.action.type === "move" ? [e.action] : []), ne = f.flatMap((e) => e.action.type === "battle" ? [e.action] : []), re = [...new Set(b.map((e) => e.from))], ie = f.flatMap((e) => e.kind === "option" ? e.clearing === null ? ["chooseForest", "slipForest"].includes(e.label ?? "") && typeof e.args?.n == "number" ? [-e.args.n] : [] : [e.clearing] : []), x = f.flatMap((e) => e.action.type === "loss" ? r.pieces.filter((t) => e.action.type === "loss" && t.uid === e.action.piece).map((e) => e.clearing) : []), S = d.from === null ? [
		...re,
		...ne.map((e) => e.clearing),
		...ie,
		...x
	] : b.filter((e) => e.from === d.from).map((e) => e.to), w = b.filter((e) => e.from === d.from && e.to === d.to), ue = w.find((e) => e.n === Math.min(d.n, Math.max(1, ...w.map((e) => e.n)))), pe = ne.filter((e) => e.clearing === d.from), me = s?.kind === "card" ? f.find((e) => e.action.type === "card" && e.action.uid === s.card.uid) : void 0, ge = (e) => {
		if (e < 0 || !b.length && !ne.length && f.some((e) => e.kind === "option")) {
			g({
				kind: "actions",
				location: e
			});
			return;
		}
		b.length ? d.from !== null && b.some((t) => t.from === d.from && t.to === e) ? o({
			...d,
			to: e
		}) : re.includes(e) ? o({
			version: r.version,
			from: e,
			to: null,
			n: 1
		}) : g({
			kind: "clearing",
			id: e
		}) : ne.some((t) => t.clearing === e) ? o({
			version: r.version,
			from: e,
			to: null,
			n: 1
		}) : g({
			kind: "clearing",
			id: e
		});
	}, _e = r.hospital ? "chooseHospital" : m?.stage === "ambush" ? "chooseAmbush" : m?.stage === "counter" ? "chooseCounter" : m?.stage === "effects" ? m.effectsOwner ? "chooseEffect" : "chooseOrder" : m?.stage === "roll" ? "rolling" : "resolving", E = f.some((e) => e.kind === "itemHit") ? "chooseItemLoss" : "chooseLoss", ve = r.table?.step, D = ve === "corvidRecruit" ? "recruit" : ve === "crusadeBattle" ? "battle" : ve, ye = D && Object.hasOwn(Sr, D) ? t(D) : t("chooseResponse"), O = r.phase === "done" ? t("victory") : r.phase === "complete" ? t("completed") : r.acting ? r.acting === e.myRid ? f.some((e) => e.kind === "option") ? ye : m || r.hospital ? t(m?.stage === "hits" || m?.stage === "ambushHits" ? E : _e) : t(ne.length ? "selectBattle" : d.from === null ? "selectOrigin" : "selectDestination") : t("wait", { name: h(r.acting) }) : t("resolving"), be = {
		view: r,
		t,
		selected: r.hospital?.clearing ?? m?.clearing ?? d.from,
		destination: d.to,
		targets: [...new Set(S)],
		onClearing: ge
	}, xe = s?.kind === "faction" ? s.rid : p?.rid ?? r.active, Ce = r.log.at(-1), we = s?.kind === "actions" ? Lr.find((e) => e.key === s.group) : void 0, Te = s?.kind === "object" ? t(s.title) : s?.kind === "card" ? t(s.card.kind) : s?.kind === "clearing" ? t("clearing", {
		suit: t(v(le(r), s.id).suit),
		n: s.id
	}) : s?.kind === "log" ? t("inspect") : s?.kind === "supply" ? t("supplyArea") : s?.kind === "actions" ? we ? t(we.key) : ye : t("factionBoard"), Ee = f.filter((e) => e.kind === "option"), Oe = s?.kind === "actions" && s.location !== void 0 ? f.filter((e) => e.clearing === s.location || s.location < 0 && e.args?.n === -s.location && ["chooseForest", "slipForest"].includes(e.label ?? "")) : f, Ie = we ? Oe.filter((e) => we.labels.includes(e.label ?? "")) : Oe, Re = s?.kind === "actions" && !we && s.location === void 0 ? Lr.filter((e) => Ie.some((t) => e.labels.includes(t.label ?? ""))) : [], ze = Ie.filter((e) => !Re.some((t) => t.labels.includes(e.label ?? ""))), Be = Ee.filter((e) => [
		"march",
		"move",
		"battle",
		"recruit",
		"craft"
	].includes(e.label ?? "")), Ve = Lr.filter((e) => Ee.some((t) => e.labels.includes(t.label ?? ""))), He = /* @__PURE__ */ j("div", {
		className: "root-banner",
		children: [/* @__PURE__ */ A("div", {
			className: "root-player-strip",
			style: { "--root-seats": Math.min(4, r.players.length) },
			children: r.players.map((i) => {
				let a = e.members.find((e) => e.rid === i.rid);
				return /* @__PURE__ */ j("button", {
					ref: (e) => n?.register(`seat:${i.rid}`, e),
					className: `root-player${i.rid === r.acting ? " root-player-active" : ""}`,
					onClick: () => g({
						kind: "faction",
						rid: i.rid
					}),
					style: {
						"--root-faction": T[i.faction],
						"--root-player": je[(a?.colorIndex ?? 0) % je.length].hex
					},
					"aria-label": `${h(i.rid)} · ${t(i.faction)} · ${t("vp", { n: i.vp })}`,
					children: [
						/* @__PURE__ */ A("span", {
							className: "root-player-emblem",
							children: /* @__PURE__ */ A(C, { faction: i.faction })
						}),
						/* @__PURE__ */ A("span", {
							className: "root-player-name",
							children: h(i.rid)
						}),
						/* @__PURE__ */ A("strong", {
							className: "root-player-score",
							children: /* @__PURE__ */ A(ae, { value: i.vp })
						})
					]
				}, i.rid);
			})
		}), /* @__PURE__ */ A("div", {
			className: "root-turn-card",
			"data-own-turn": r.acting === e.myRid,
			children: /* @__PURE__ */ A(Fe, {
				tone: r.acting === e.myRid ? "accent" : "info",
				text: O,
				chip: t(r.hospital ? "hospital" : m ? "battle" : r.command?.kind ?? r.table?.phase ?? "daylight"),
				accent: T.pineDark
			})
		})]
	}), Ue = /* @__PURE__ */ j("div", {
		className: "root-footer",
		children: [
			/* @__PURE__ */ A(Ne, {
				kind: "sheen",
				base: "#d8d6b5",
				className: "root-table-texture"
			}),
			/* @__PURE__ */ j("div", {
				className: "root-hand-area",
				children: [/* @__PURE__ */ j("button", {
					className: "root-hand-caption",
					style: { "--root-faction": p ? T[p.faction] : T.pineDark },
					onClick: () => p && g({
						kind: "faction",
						rid: p.rid
					}),
					children: [
						p && /* @__PURE__ */ A(C, { faction: p.faction }),
						/* @__PURE__ */ A("span", { children: t("hand") }),
						/* @__PURE__ */ A("b", { children: i?.hand.length ?? 0 })
					]
				}), /* @__PURE__ */ A("div", {
					className: "root-hand",
					"data-fan": (i?.hand.length ?? 0) <= 5,
					ref: (e) => n?.register("hand", e),
					children: i?.hand.map((e) => /* @__PURE__ */ A(oe, {
						anchor: `card:${e.uid}`,
						card: e,
						t,
						selected: l && s?.kind === "card" && s.card.uid === e.uid,
						active: f.some((t) => t.action.type === "card" && t.action.uid === e.uid || t.args?.cardUid === e.uid),
						onClick: () => g({
							kind: "card",
							card: e
						})
					}, e.uid))
				})]
			}),
			/* @__PURE__ */ j("div", {
				className: "root-actions",
				ref: (e) => n?.register("actions", e),
				children: [
					Ee.length > 0 && /* @__PURE__ */ j(k, { children: [
						Be.slice(0, 3).map((e, n) => /* @__PURE__ */ A("button", {
							className: "btn-base root-primary",
							onClick: () => y(e.action),
							children: Er(e, t)
						}, `quick:${n}`)),
						Ve.slice(0, Math.max(0, 3 - Be.length)).map((e) => /* @__PURE__ */ A("button", {
							className: "btn-base root-primary",
							onClick: () => g({
								kind: "actions",
								group: e.key
							}),
							children: t(e.key)
						}, e.key)),
						/* @__PURE__ */ A("button", {
							className: `btn-quiet root-secondary${!Be.length && !Ve.length ? " root-action-main" : ""}`,
							onClick: () => g({ kind: "actions" }),
							children: t("allActions")
						}),
						Ee.filter((e) => [
							"finishActions",
							"continue",
							"finishCraft",
							"finishRevolt",
							"finishSpread",
							"finishParliament",
							"finishSway",
							"finishFlip",
							"finishPurchases"
						].includes(e.label ?? "")).slice(0, 1).map((e) => /* @__PURE__ */ A("button", {
							className: "btn-quiet root-secondary",
							onClick: () => y(e.action),
							children: Er(e, t)
						}, e.action.type === "choose" ? e.action.id : e.label))
					] }),
					f.some((e) => e.action.type === "move" && (e.action.from === 0 || e.action.to === 0)) && /* @__PURE__ */ A("button", {
						className: "btn-quiet root-secondary",
						onClick: () => g({ kind: "actions" }),
						children: t("burrow")
					}),
					ue && /* @__PURE__ */ j(k, { children: [/* @__PURE__ */ A("input", {
						className: "root-move-range",
						type: "range",
						min: 1,
						max: Math.max(...w.map((e) => e.n)),
						value: ue.n,
						"aria-label": t("moveN", { n: ue.n }),
						onChange: (e) => o({
							...d,
							n: Number(e.target.value)
						})
					}), w.filter((e) => e.n === ue.n).map((e) => /* @__PURE__ */ j("button", {
						className: "btn-base root-primary",
						onClick: () => y(e),
						children: [t("moveN", { n: e.n }), e.via === "ferry" ? ` · ${t("ferry")}` : ""]
					}, e.via ?? "path"))] }),
					pe.map((e) => /* @__PURE__ */ A("button", {
						className: "btn-base root-primary",
						onClick: () => y(e),
						children: t("battleAgainst", { name: t(r.players.find((t) => t.rid === e.defender).faction) })
					}, e.defender)),
					f.filter((e) => e.kind === "loss").map((e) => {
						let n = e.action;
						if (n.type !== "loss") return null;
						let i = r.pieces.find((e) => e.uid === n.piece);
						return /* @__PURE__ */ j("button", {
							className: "btn-base root-primary",
							onClick: () => y(n),
							children: [
								t("remove"),
								" · ",
								t(i.kind)
							]
						}, i.uid);
					}),
					f.filter((e) => e.kind === "effect").map((e) => {
						let n = e.action;
						return n.type === "effect" && /* @__PURE__ */ A("button", {
							className: "btn-base root-primary",
							onClick: () => y(n),
							children: t(n.effect)
						}, n.effect);
					}),
					f.filter((e) => e.kind === "effectOrder").map((e) => {
						let n = e.action;
						return n.type === "effectOrder" && /* @__PURE__ */ A("button", {
							className: "btn-base root-primary",
							onClick: () => y(n),
							children: t(r.players.find((e) => e.rid === n.owner).faction)
						}, n.owner);
					}),
					f.filter((e) => e.kind === "itemHit").map((e) => {
						let n = e.action;
						if (n.type !== "itemHit") return null;
						let i = r.table?.boards.flatMap((e) => e.items).find((e) => e.uid === n.uid);
						return /* @__PURE__ */ j("button", {
							className: "btn-base root-primary",
							onClick: () => y(n),
							children: [
								i && /* @__PURE__ */ A(se, { item: i.type }),
								" ",
								t("damageItem", { item: i ? t(i.type) : "" })
							]
						}, n.uid);
					}),
					d.from !== null && /* @__PURE__ */ A("button", {
						className: "btn-quiet root-secondary",
						onClick: () => o({
							version: -1,
							from: null,
							to: null,
							n: 1
						}),
						children: t("cancel")
					}),
					f.some((e) => e.action.type === "pass") && /* @__PURE__ */ A("button", {
						className: "btn-quiet root-secondary",
						onClick: () => y({ type: "pass" }),
						children: t(r.command?.kind === "march" && !m && !r.hospital ? "endMarch" : "pass")
					}),
					r.table && /* @__PURE__ */ A("button", {
						className: "btn-quiet root-secondary",
						onClick: () => g({ kind: "supply" }),
						children: t("supplyArea")
					})
				]
			})
		]
	});
	return /* @__PURE__ */ j("div", {
		className: "root-game",
		children: [/* @__PURE__ */ A(Pe, {
			adaptive: !0,
			scroll: !1,
			className: "root-shell",
			banner: He,
			actionsHeight: "root-actions-height",
			actions: Ue,
			children: /* @__PURE__ */ j("div", {
				className: "root-main",
				children: [/* @__PURE__ */ j("div", {
					className: "root-woodland",
					children: [
						/* @__PURE__ */ A("div", {
							className: "root-map-title",
							children: t(r.map)
						}),
						/* @__PURE__ */ A(Se, {
							fallback: /* @__PURE__ */ A(he, { ...be }),
							children: /* @__PURE__ */ A(Ir, { ...be })
						}),
						r.table && /* @__PURE__ */ j("span", {
							ref: (e) => n?.register("deck", e),
							className: "root-deck",
							"aria-label": `${t("deck")} · ${r.table.deckCount}`,
							children: [/* @__PURE__ */ j("svg", {
								viewBox: "0 0 32 44",
								"aria-hidden": "true",
								children: [
									/* @__PURE__ */ A("path", {
										d: "M3 5h24v36H3Z",
										fill: T.clay,
										stroke: T.bark
									}),
									/* @__PURE__ */ A("path", {
										d: "M6 2h24v36H6Z",
										fill: T.paper,
										stroke: T.bark
									}),
									/* @__PURE__ */ A("path", {
										d: "m18 9 7 10-7 10-7-10Z",
										fill: "none",
										stroke: T.gold,
										strokeWidth: "2"
									}),
									/* @__PURE__ */ A("path", {
										d: "M18 13v12m-4-6h8",
										stroke: T.pineDark
									})
								]
							}), /* @__PURE__ */ A("b", { children: /* @__PURE__ */ A(ae, { value: r.table.deckCount }) })]
						}),
						/* @__PURE__ */ A(kr, {
							view: r,
							t,
							name: h
						}),
						Ce && /* @__PURE__ */ A("button", {
							className: "root-log-line",
							onClick: () => g({ kind: "log" }),
							children: wr(Ce, t, h)
						})
					]
				}), /* @__PURE__ */ A("aside", {
					className: "root-side-panel",
					children: /* @__PURE__ */ A(Fr, {
						view: r,
						rid: p?.rid ?? r.active,
						t,
						privateView: i,
						inBoard: !0,
						onChoices: ee,
						onCard: te
					})
				})]
			})
		}), /* @__PURE__ */ A("div", {
			onKeyDown: (e) => {
				e.key === "Escape" && _();
			},
			children: /* @__PURE__ */ A(Me, {
				open: l,
				onClose: _,
				label: Te,
				title: Te,
				children: /* @__PURE__ */ j(Rr, {
					open: l,
					children: [
						s?.kind === "card" && /* @__PURE__ */ j("div", {
							className: "root-card-inspection",
							children: [
								/* @__PURE__ */ A(oe, {
									card: s.card,
									t,
									detail: !0
								}),
								me?.kind === "hospital" && /* @__PURE__ */ A("p", { children: t("hospitalText") }),
								me && /* @__PURE__ */ A("button", {
									className: "btn-base root-primary",
									onClick: () => y(me.action),
									children: t(me.kind === "hospital" ? "useCard" : me.kind === "counter" ? "playCounter" : "playAmbush")
								}),
								f.filter((e) => e.args?.cardUid === s.card.uid).map((e, n) => /* @__PURE__ */ A("button", {
									className: "btn-base root-decision",
									onClick: () => y(e.action),
									children: Er(e, t)
								}, n))
							]
						}),
						s?.kind === "faction" && /* @__PURE__ */ A(Fr, {
							view: r,
							rid: xe,
							t,
							privateView: xe === e.myRid ? i : void 0,
							onChoices: ee,
							onCard: te
						}),
						s?.kind === "object" && /* @__PURE__ */ j("div", {
							className: "root-decision-list",
							children: [Ar[s.title] && /* @__PURE__ */ A("p", { children: t(Ar[s.title]) }), (s.version === r.version ? f.filter((e) => s.actions.includes(jr(e.action))) : []).map((e) => /* @__PURE__ */ A("button", {
								className: "btn-base root-decision",
								onClick: () => y(e.action),
								children: e.action.type === "itemHit" ? t("damageItem", { item: Tr(s.title, t) }) : e.action.type === "effect" ? t(e.action.effect) : Er(e, t)
							}, jr(e.action)))]
						}),
						s?.kind === "clearing" && /* @__PURE__ */ j("div", {
							className: "root-clearing-inspection",
							children: [
								/* @__PURE__ */ A(ce, { suit: v(le(r), s.id).suit }),
								r.pieces.filter((e) => e.clearing === s.id).map((e) => {
									let n = f.find((t) => t.action.type === "loss" && t.action.piece === e.uid), i = /* @__PURE__ */ j(k, { children: [
										/* @__PURE__ */ A(C, { faction: r.players.find((t) => t.rid === e.owner).faction }),
										/* @__PURE__ */ A(k, { children: e.kind !== "warrior" && /* @__PURE__ */ A(fe, { kind: e.kind }) }),
										/* @__PURE__ */ A("span", { children: t(e.kind) }),
										/* @__PURE__ */ A("b", { children: e.count })
									] });
									return n ? /* @__PURE__ */ j("button", {
										className: "root-piece-choice root-object-available",
										onClick: () => y(n.action),
										"aria-label": `${t("remove")} · ${t(e.kind)}`,
										children: [i, /* @__PURE__ */ A(de, {})]
									}, e.uid) : /* @__PURE__ */ A("div", { children: i }, e.uid);
								}),
								/* @__PURE__ */ A("button", {
									className: "btn-base root-primary",
									onClick: () => g({
										kind: "actions",
										location: s.id
									}),
									children: t("allActions")
								})
							]
						}),
						s?.kind === "actions" && /* @__PURE__ */ j("div", {
							className: "root-decision-list",
							children: [
								s.location !== void 0 && s.location > 0 && /* @__PURE__ */ A("button", {
									className: "btn-quiet root-secondary",
									onClick: () => g({
										kind: "clearing",
										id: s.location
									}),
									children: t("inspectClearing", { n: s.location })
								}),
								i?.peek?.length ? /* @__PURE__ */ A("div", {
									className: "root-public-hand",
									children: i.peek.map((e) => /* @__PURE__ */ A(oe, {
										card: e,
										t
									}, e.uid))
								}) : null,
								Re.length > 0 && /* @__PURE__ */ A("div", {
									className: "root-action-groups",
									children: Re.map((e) => /* @__PURE__ */ j("button", {
										className: "btn-base root-decision",
										onClick: () => g({
											kind: "actions",
											group: e.key
										}),
										children: [t(e.key), /* @__PURE__ */ A("span", {
											"aria-hidden": "true",
											children: "›"
										})]
									}, e.key))
								}),
								ze.map((e, n) => /* @__PURE__ */ A("button", {
									className: "btn-base root-decision",
									onClick: () => y(e.action),
									children: Er(e, t)
								}, n)),
								!Ie.length && /* @__PURE__ */ A("p", { children: t("noChoices") }),
								(s.location !== void 0 || s.group) && /* @__PURE__ */ A("button", {
									className: "btn-quiet root-secondary",
									onClick: () => g({ kind: "actions" }),
									children: t("allActions")
								})
							]
						}),
						s?.kind === "log" && /* @__PURE__ */ A("ol", {
							className: "root-history",
							children: r.log.map((e, n) => /* @__PURE__ */ A("li", { children: wr(e, t, h) }, n))
						}),
						s?.kind === "supply" && r.table && /* @__PURE__ */ j("div", {
							className: "root-faction-details",
							children: [
								/* @__PURE__ */ j("h3", { children: [
									t("deck"),
									" · ",
									r.table.deckCount
								] }),
								/* @__PURE__ */ A("h3", { children: t("itemSupply") }),
								/* @__PURE__ */ A("div", {
									className: "root-item-grid",
									children: Object.entries(r.table.itemSupply).filter(([e]) => e !== "torch").map(([e, n]) => /* @__PURE__ */ j("span", {
										className: "root-item",
										children: [
											/* @__PURE__ */ A(se, { item: e }),
											/* @__PURE__ */ A("b", { children: Tr(e, t) }),
											/* @__PURE__ */ A("strong", { children: n })
										]
									}, e))
								}),
								/* @__PURE__ */ A("h3", { children: t("availableDominance") }),
								/* @__PURE__ */ A("div", {
									className: "root-public-hand",
									children: r.table.availableDominance.map((e) => /* @__PURE__ */ A(oe, {
										card: e,
										t,
										onClick: () => g({
											kind: "card",
											card: e
										})
									}, e.uid))
								}),
								/* @__PURE__ */ j("h3", { children: [
									t("discardPile"),
									" · ",
									r.discard.length
								] }),
								/* @__PURE__ */ A("div", {
									className: "root-public-hand",
									children: r.discard.map((e) => /* @__PURE__ */ A(oe, {
										card: e,
										t,
										onClick: () => g({
											kind: "card",
											card: e
										})
									}, e.uid))
								})
							]
						})
					]
				})
			})
		})]
	});
}
//#endregion
//#region src/games/root/bot.ts
var Br = (e, t) => e.filter((e) => !t || e.kind === t).reduce((e, t) => e + t.count, 0), Vr = {
	recruit: 20,
	move: 8,
	battle: 12,
	build: 18
};
function Hr(e, t) {
	return t > 0 && t <= e.clearings.length ? e.clearings[t - 1].suit : "bird";
}
function Ur(e, t, n) {
	return n > 0 && (t === "bird" || Hr(e, n) === t);
}
function Wr(e, t = e.me.leader) {
	return t === "charismatic" ? 2 : 1;
}
function Gr(e, t, n) {
	let r = e.players.find((e) => e.rid === t), a = e.table, o = i(le(e)), s = le(e), c = {
		active: e.active,
		players: e.players,
		pieces: e.pieces,
		game: a ? {
			phase: a.phase,
			mercenaries: a.mercenaries
		} : void 0
	}, l = /* @__PURE__ */ new Map();
	for (let t of [0, ...o.map((e) => e.id)]) l.set(t, t === 0 ? e.players.find((e) => e.faction === "duchy")?.rid ?? null : Y(c, t));
	let u = (t, n) => e.pieces.filter((e) => e.owner === t && e.clearing === n), d = (e, t) => !!a?.boards.some((n) => n.owner === e && n.location === t), f = (e, t) => Br(u(e, t), "warrior"), p = (e, t) => u(e, t).reduce((e, t) => e + (w(t.kind) ? t.count : 0), 0), m = (e, t) => u(e, t).length > 0 || d(e, t), h = (e) => a?.phase !== "birdsong" && a?.mercenaries.includes(e);
	return {
		view: e,
		owner: t,
		hand: n,
		me: r,
		board: a?.boards.find((e) => e.owner === t),
		table: a,
		clearings: o,
		map: s,
		rulers: l,
		warriors: f,
		buildings: p,
		pieces: u,
		presence: m,
		strength: (t, n) => {
			if (e.players.find((e) => e.rid === t)?.faction === "vagabond") return d(t, n) ? a?.boards.find((e) => e.owner === t)?.items.filter((e) => e.type === "sword" && !e.damaged).length ?? 0 : 0;
			let r = h(t) ? e.players.find((e) => e.faction === "riverfolk")?.rid : void 0;
			return f(t, n) + (r ? f(r, n) : 0);
		},
		openSlots: (t) => {
			let n = o[t - 1];
			if (!n) return 0;
			let r = +((a?.ruins.find((e) => e.clearing === t)?.count ?? 0) > 0);
			return n.slots - r - e.pieces.filter((e) => e.clearing === t && w(e.kind)).reduce((e, t) => e + t.count, 0);
		},
		canPlace: (n) => n > 0 && !a?.scorched.includes(n) && !e.pieces.some((e) => e.clearing === n && e.owner !== t && (e.kind === "keep" || e.kind === "plot" && e.faceUp && e.plot === "snare")),
		enemies: (n) => e.players.filter((e) => e.rid !== t && m(e.rid, n)).map((e) => e.rid),
		ownRoost: (e) => u(t, e).some((e) => e.kind === "roost"),
		roosts: e.pieces.filter((e) => e.owner === t && e.kind === "roost").reduce((e, t) => e + t.count, 0)
	};
}
function Kr(e, t) {
	return e.view.pieces.some((n) => n.clearing === t && n.owner !== e.owner && n.kind === "plot" && n.faceUp && n.plot === "snare");
}
function qr(e, t) {
	if (t === 0) return e.pieces(e.owner, 0).length ? e.view.pieces.filter((t) => t.owner === e.owner && t.kind === "tunnel").map((e) => e.clearing) : [];
	let n = new Set(m(e.map, t));
	if (e.me.faction === "riverfolk" || e.table?.riverboats.includes(e.owner)) for (let r of ue(e.map, t)) n.add(r);
	if (e.table?.ferry === t && !e.table.used.includes("ferry")) for (let r of S[e.view.map].coastal) r !== t && n.add(r);
	return e.me.faction === "duchy" && e.view.pieces.some((n) => n.owner === e.owner && n.kind === "tunnel" && n.clearing === t) && n.add(0), [...n].filter((t) => !e.table?.scorched.includes(t));
}
function Jr(e, t) {
	return e.clearings.some((n) => Ur(e, t, n.id) && e.warriors(e.owner, n.id) > 0 && !Kr(e, n.id)) && e.clearings.some((n) => {
		if (!Ur(e, t, n.id) || !e.warriors(e.owner, n.id) || Kr(e, n.id)) return !1;
		let r = e.me.faction === "corvid" || e.rulers.get(n.id) === e.owner;
		return qr(e, n.id).some((t) => r || e.rulers.get(t) === e.owner);
	});
}
function Yr(e, t) {
	return e.clearings.some((n) => Ur(e, t, n.id) && e.strength(e.owner, n.id) > 0 && e.enemies(n.id).length > 0);
}
function Xr(e, t, n = Wr(e)) {
	return e.me.supply < n ? !1 : e.view.pieces.some((n) => n.owner === e.owner && n.kind === "roost" && Ur(e, t, n.clearing) && e.canPlace(n.clearing));
}
function Zr(e, t) {
	return e.roosts >= 7 ? [] : e.clearings.filter((n) => Ur(e, t, n.id) && e.rulers.get(n.id) === e.owner && e.canPlace(n.id) && e.openSlots(n.id) > 0 && !e.ownRoost(n.id)).map((e) => e.id);
}
function Qr(e, t) {
	return Zr(e, t).filter((t) => {
		let n = Math.max(0, ...e.view.players.filter((t) => t.rid !== e.owner).map((n) => e.strength(n.rid, t)));
		return e.warriors(e.owner, t) >= 2 && e.warriors(e.owner, t) + e.buildings(e.owner, t) >= n + 2;
	});
}
function $r(e, t) {
	return e.clearings.filter((n) => Ur(e, t, n.id) && e.strength(e.owner, n.id) > 0 && e.enemies(n.id).length > 0).map((e) => e.id);
}
function ei(e, t, n, r, i = Wr(e)) {
	return t === "recruit" ? Xr(e, n, i) && e.me.supply >= r * i : t === "move" ? Jr(e, n) : t === "battle" ? Yr(e, n) : Zr(e, n).length >= r;
}
function ti(e, t) {
	let n = ne[e];
	if (!n) return 0;
	let r = e === "charismatic" ? 2 : 1, i = 16;
	for (let e of n) {
		if (!ei(t, e, "bird", 1, r)) return -1e3;
		i += Vr[e];
	}
	return e === "builder" && (i += 6), e === "charismatic" && (i += t.me.supply >= 6 ? 8 : -6), e === "commander" && (i += t.me.leader === "commander" ? 2 : 4), e === "despot" && (i += Math.min(10, t.clearings.reduce((e, n) => e + t.enemies(n.id).filter((e) => t.buildings(e, n.id) > 0).length, 0) * 2)), n.includes("build") && (i -= 10), i;
}
function ni(e, t, n) {
	let r = (e.board?.decree ?? []).filter((n) => n.column === t && !e.table?.decreeDone.includes(n.card.uid)).map((e) => e.card.suit);
	if (n && r.push(n), !r.length) return !0;
	let i = Wr(e);
	if (t === "recruit") return e.me.supply < i * r.length + i * 2 + 1 ? !1 : r.every((t) => e.view.pieces.some((n) => n.owner === e.owner && n.kind === "roost" && Ur(e, t, n.clearing) && e.canPlace(n.clearing)));
	if (t === "move") {
		if (!r.every((t) => Jr(e, t))) return !1;
		let t = (t) => e.clearings.filter((n) => Ur(e, t, n.id) && e.warriors(e.owner, n.id) > 0 && !Kr(e, n.id)).length, n = (e) => r.filter((t) => t === e).length;
		return [
			"fox",
			"mouse",
			"rabbit"
		].every((e) => t(e) >= n(e)) ? e.clearings.filter((t) => e.warriors(e.owner, t.id) > 0 && !Kr(e, t.id)).length >= r.length : !1;
	}
	if (t === "battle") {
		if (!r.every((t) => Yr(e, t))) return !1;
		let t = (t) => $r(e, t).length, n = (e) => r.filter((t) => t === e).length;
		return [
			"fox",
			"mouse",
			"rabbit"
		].every((e) => t(e) >= n(e)) ? r.length <= e.clearings.reduce((t, n) => t + Number(e.strength(e.owner, n.id) > 0 && e.enemies(n.id).length > 0), 0) : !1;
	}
	let a = (e.board?.decree ?? []).some((t) => t.column === "battle" && !e.table?.decreeDone.includes(t.card.uid)), o = (t) => Qr(e, t).filter((t) => !a || e.warriors(e.owner, t) >= 3), s = /* @__PURE__ */ new Set();
	for (let e of [...r].sort((e, t) => Number(e === "bird") - Number(t === "bird"))) {
		let t = o(e).find((e) => !s.has(e));
		if (t === void 0) return !1;
		s.add(t);
	}
	return !0;
}
function ri(e, t, n) {
	let r = String(e.args?.column ?? ""), i = String(e.args?.suit ?? "bird");
	if (!(r in Vr)) return -1e3;
	let a = ni(t, r, i);
	if (!a && n) return -1e3;
	let o = (t.board?.decree.filter((e) => e.column === r).length ?? 0) + 1, s = Wr(t), c = a ? Vr[r] : Vr[r] - 200;
	if (r === "recruit") {
		c += Math.min(10, t.roosts * 2);
		let e = s * (o + 2);
		c += t.me.supply >= e + 2 ? 5 : t.me.supply <= e ? -30 : -8, o >= 3 ? c -= 30 : o >= 2 && (c -= 8);
	}
	return r === "build" && (c += t.roosts < 3 ? 10 : t.roosts < 6 ? 5 : 0, c += Qr(t, i).length > o ? 5 : -10), r === "battle" && (c += $r(t, i).length > o ? 3 : 0), i === "bird" && (c += 5), n && (c -= 14), c;
}
function ii(e) {
	let t = [...e.players].sort((e, t) => t.vp - e.vp);
	return t[0] && t[0].vp > (t[1]?.vp ?? -1) ? t[0].rid : null;
}
function ai(e, t) {
	let n = e.clearing, r = t.strength(t.owner, n), i = t.strength(e.defender, n), a = t.pieces(e.defender, n).reduce((e, t) => e + (w(t.kind) ? t.count * 2 : t.kind === "wood" || t.kind === "sympathy" ? t.count : 0), 0), o = ii(t.view) === e.defender, s = 30 + a * 4 + Number(o) * 8;
	return s += Math.max(-30, Math.min(18, (r - i) * 3)), t.me.leader === "commander" && (s += 6), t.me.faction === "eyrie" && t.me.leader === "despot" && (s += a > 0 ? 8 : 0), oi(t, n) && r - i < 2 && (s -= 12), s;
}
function oi(e, t) {
	return (e.board?.decree ?? []).some((n) => n.column === "build" && !e.table?.decreeDone.includes(n.card.uid) && Ur(e, n.card.suit, t));
}
function si(e, t) {
	return (e.board?.decree ?? []).some((n) => n.column === "battle" && !e.table?.decreeDone.includes(n.card.uid) && Ur(e, n.card.suit, t));
}
function ci(e, t, n = 20) {
	let r = e.from, i = e.to, a = t.warriors(t.owner, i) + e.n, o = Math.max(0, ...t.view.players.filter((e) => e.rid !== t.owner).map((e) => t.strength(e.rid, i))), s = t.buildings(t.owner, i), c = t.view.pieces.some((e) => e.owner === t.owner && e.clearing === i && e.kind === "plot" && !e.faceUp), l = [...t.view.log].reverse().find((e) => e.type === "move" && e.owner === t.owner), u = n + Math.min(e.n, 4) - t.warriors(t.owner, i) * 3 - o * 5 + Number(c && !t.warriors(t.owner, i)) * 35 + Number(e.via === "ferry") * 3 - Number(l?.from === i) * 18, d = t.rulers.get(i);
	return d !== t.owner && a + s > o ? u += 22 : d === t.owner && (u += 6), t.me.faction === "marquise" && t.openSlots(i) > 0 && t.rulers.get(i) !== t.owner && (u += 6), t.rulers.get(r) === t.owner && oi(t, r) && t.warriors(t.owner, r) - e.n + t.buildings(t.owner, r) <= Math.max(0, ...t.view.players.filter((e) => e.rid !== t.owner).map((e) => t.strength(e.rid, r))) && (u -= 40), si(t, r) && t.enemies(r).length && t.warriors(t.owner, r) - e.n <= 0 && (u -= 50), si(t, i) && t.enemies(i).length && (u += 12), t.view.pieces.some((e) => e.owner === t.owner && e.kind === "plot" && !e.faceUp && e.clearing === r) && t.warriors(t.owner, r) - e.n <= 0 && (u -= 45), t.me.faction === "marquise" && t.rulers.get(r) === t.owner && t.buildings(t.owner, r) > 0 && t.warriors(t.owner, r) - e.n + t.buildings(t.owner, r) <= Math.max(0, ...t.view.players.filter((e) => e.rid !== t.owner).map((e) => t.strength(e.rid, r))) && (u -= 25), t.board?.decree.some((e) => e.column === "build" && !t.table?.decreeDone.includes(e.card.uid) && Ur(t, e.card.suit, i)) && (d !== t.owner && a + s > o ? u += 25 : t.openSlots(i) > 0 && (u += 8)), t.me.faction === "alliance" && !t.view.pieces.some((e) => e.owner === t.owner && e.kind === "sympathy" && e.clearing === i) && (u += 8), t.me.faction === "vagabond" && t.table?.ruins.some((e) => e.clearing === i && e.count > 0) && (u += 10), u;
}
var li = {
	harrier: 10,
	thief: 8,
	ranger: 8,
	arbiter: 4,
	scoundrel: 4,
	tinker: 2,
	adventurer: 2,
	ronin: 2,
	vagrant: 2
}, ui = (e) => e.board?.items ?? [], di = (e, t) => ui(e).filter((e) => e.type === t && !e.exhausted && !e.damaged).length, fi = (e, t) => ui(e).filter((e) => e.type === t && !e.damaged).length, pi = (e, t) => (e.table?.quests ?? []).filter((n) => n.suit === Hr(e, t)), mi = (e) => new Set((e.table?.quests ?? []).flatMap((e) => e.items)), hi = (e, t) => (e.board?.completedQuests.filter((e) => e.suit === t.suit).length ?? 0) + 1;
function gi(e, t) {
	let [n, r] = t.items;
	return n === r ? di(e, n) >= 2 ? 2 : +(fi(e, n) >= 2) : di(e, n) > 0 && di(e, r) > 0 ? 2 : +(fi(e, n) > 0 && fi(e, r) > 0);
}
var _i = (e, t) => Math.max(0, ...pi(e, t).map((t) => gi(e, t)));
function vi(e, t) {
	let n = di(e, "hammer");
	if (!n || t < 1) return 0;
	let r = Hr(e, t);
	return e.hand.filter((t) => {
		let i = g(t);
		return !i?.cost.length || i.cost.length > n || i.item && (e.table?.itemSupply[i.item] ?? 0) <= 0 ? !1 : i.cost.every((e) => e === "any" || e === r);
	}).length;
}
function yi(e, t) {
	if (t < 1) return 0;
	let n = _i(e, t), r = n === 2 ? 26 : n === 1 ? 12 : 0;
	di(e, "torch") > 0 && (e.table?.ruins.find((e) => e.clearing === t)?.count ?? 0) > 0 && (r += 14), r += Math.min(3, vi(e, t)) * 9;
	let i = Hr(e, t), a = e.hand.filter((e) => e.suit === "bird" || e.suit === i).length, o = e.view.players.filter((n) => n.rid !== e.owner && e.presence(n.rid, t) && (e.board?.relationships.find((e) => e.owner === n.rid)?.level ?? -1) >= 0);
	return o.length && a && (r += Math.min(3, a) * 8 + o.length * 2), r;
}
function bi(e, t, n) {
	let r = n, i = e.board?.location ?? 0, a = fi(e, t) > di(e, t);
	if (a) for (let n of pi(e, i)) n.items.filter((e) => e === t).length > di(e, t) && (r += 30 + hi(e, n) * 4);
	if (a) for (let n of e.clearings) n.id !== i && pi(e, n.id).some((e) => e.items.includes(t)) && (r += 4);
	return t === "torch" && di(e, "torch") === 0 && (e.table?.ruins.find((e) => e.clearing === i)?.count ?? 0) > 0 && (r += 20), t === "hammer" && (r += Math.min(24, vi(e, i) * 12)), t === "tea" && (r += 34), t === "coin" && (r += 6), r;
}
function xi(e, t, n) {
	let r = e.hand.find((e) => e.uid === String(t.args?.cardUid ?? "")), i = r && g(r);
	if (!i) return n;
	let a = i.item, o = a ? a === "tea" ? 9 : a === "coin" ? 6 : a === "hammer" ? 5 : mi(e).has(a) ? 6 : 2 : 0;
	return e.me.faction === "duchy" && Oi(e) ? n + (i.vp ?? 0) * 2 - 24 : n + (i.vp ?? 0) * 4 + o;
}
function Si(e, t, n) {
	let r = t.view.players.find((t) => t.faction === String(e.args?.faction ?? "")), i = t.board?.relationships.find((e) => e.owner === r?.rid);
	if (!i) return n;
	if (i.level === -1) return -1e3;
	let a = n + (i.level === 3 ? 16 : 3) + Math.min(12, i.aids * 4);
	i.level < 3 && i.aids + 1 >= i.level + 1 && (a += 8);
	let o = String(e.args?.item ?? "");
	o === "tea" ? a -= 20 : (o === "coin" || o === "sack") && (a -= 14), mi(t).has(o) && (a -= 8);
	let s = t.table?.boards.find((e) => e.owner === r?.rid)?.craftedItems ?? [];
	for (let e of s) a += mi(t).has(e) ? 14 : ui(t).some((t) => t.type === e) ? 0 : 6;
	return a;
}
function Ci(e) {
	return e === "coin" || e === "tea" || e === "sack" ? -30 : e === "torch" ? -12 : e === "sword" ? -8 : e === "crossbow" ? -6 : e === "hammer" ? -4 : 4;
}
function wi(e, t, n) {
	let r = t.view.players.find((t) => t.faction === String(e.args?.name ?? ""));
	if (!r) return n;
	let i = t.board?.relationships.find((e) => e.owner === r.rid), a = e.clearing ?? 0, o = n + t.pieces(r.rid, a).reduce((e, t) => e + (t.kind === "warrior" ? 0 : t.count), 0) * 10;
	return i && i.level >= 0 && (o -= 40), i?.level === -1 && (o += 10 + Math.max(0, t.warriors(r.rid, a) - 1) * 4), e.label === "battleWithAlly" && (o += 6), o;
}
var Ti = {
	baron: 60,
	earl: 46,
	duchess: 40,
	banker: 34,
	mayor: 26,
	brigadier: 20,
	foremole: 14,
	captain: 8,
	marshal: 8
}, Ei = (e, t) => e.view.pieces.filter((n) => n.owner === e.owner && n.kind === t).reduce((e, t) => e + t.count, 0);
function Di(e) {
	let t = e.board?.ministers ?? [], n = Object.entries(Ti).filter(([e]) => !t.includes(e));
	if (!n.length) return null;
	let r = n.reduce((e, t) => t[1] > e[1] ? t : e);
	return {
		minister: r[0],
		cost: b[r[0]]
	};
}
function Oi(e) {
	let t = Di(e);
	return !t || Ei(e, "market") < 3 && e.hand.length < t.cost ? !1 : e.hand.length <= t.cost;
}
function ki(e, t, n) {
	let r = e.label;
	if (r === "swayMinister") {
		let r = String(e.args?.minister ?? ""), i = Number(e.args?.cost ?? 9), a = Di(t), o = Ti[r] ?? 20, s = n + o + (t.hand.length > i ? 8 : 0);
		return a && r !== a.minister && o < 40 && t.hand.length >= a.cost - 1 && (s -= 35), s;
	}
	if (r === "revealForSway") return n + (t.hand.find((t) => t.uid === String(e.args?.cardUid ?? ""))?.suit === "bird" ? -6 : 0);
	if (r === "bankerSuit") {
		let r = String(e.args?.suit ?? "");
		return n + t.hand.filter((e) => e.suit === "bird" || e.suit === r).length * 5;
	}
	if (r === "bankerSpend") return n + (t.hand.length > 3 ? 8 : -12);
	if (r === "duchyBuild") {
		let r = String(e.args?.piece ?? ""), i = t.board?.ministers ?? [];
		if (r === "market") {
			let e = n + (Ei(t, "market") < 3 ? 26 : 4);
			return i.includes("baron") && (e += 10), e;
		}
		return n + (Ei(t, "citadel") < 2 ? 10 : 0) + (i.includes("earl") ? 8 : 0);
	}
	if (r === "digAt") {
		let r = n + (Ei(t, "tunnel") < 3 ? 12 : 2) + Number(e.args?.count ?? 0) * 2;
		return e.clearing && t.rulers.get(e.clearing) === t.owner && (r += 4), Oi(t) && (r -= 45), r;
	}
	return r === "recruitBurrow" ? n + ((t.board?.location ?? 9) <= 1 ? 4 : -14) : r === "ministerScore" ? n + Number(e.args?.vp ?? 1) * 6 : null;
}
function Ai(e, t, n) {
	let r = e.label ?? "", i = e.weight ?? 0;
	if (r === "activateDominance") {
		let n = String(e.args?.suit ?? "bird"), r = (e) => t.rulers.get(e) === t.owner;
		return (n === "bird" ? S[t.view.map].diagonals.some((e) => e.every(r)) : t.clearings.filter((e) => e.suit === n && r(e.id)).length >= 3) ? 1e3 : -1e3;
	}
	if (r === "addDecree") return ri(e, t, n);
	if (r in ne) return ti(r, t);
	if (t.me.faction === "vagabond" && r in li) return i + li[r];
	if (r === "mobilizeCard") return (t.board?.supportersCount ?? 0) >= 5 + 2 * t.view.pieces.filter((e) => e.owner === t.owner && e.kind === "base").reduce((e, t) => e + t.count, 0) ? -1e3 : i;
	if (r === "setPrice") return 8 - Math.abs(Number(e.args?.n ?? 1) - 2) * 3;
	if (r === "chooseClearing") {
		let n = e.clearing ?? Number(e.args?.n ?? 0);
		if (!n) return i;
		let r = t.clearings[n - 1]?.slots ?? 0, a = m(t.map, n), o = a.reduce((e, n) => e + (t.clearings[n - 1]?.slots ?? 0), 0);
		if (t.me.faction === "eyrie") {
			let e = Hr(t, n);
			return i + t.hand.filter((t) => t.suit === "bird" || t.suit === e).length * 14 + r * 3 + o;
		}
		return t.me.faction === "marquise" ? i + r * 4 + o * 2 + a.length : i;
	}
	if (r === "placeBuilding") {
		let n = e.clearing ?? Number(e.args?.n ?? 0);
		return i + (t.clearings[n - 1]?.slots ?? 0) * 3 + m(t.map, n).length;
	}
	if (r === "discardCard") return i + (String(e.args?.suit ?? "") === "bird" ? -6 : 0);
	if (r === "plotAt") {
		let n = e.clearing ?? 0, r = String(e.args?.plot ?? ""), i = Number(e.args?.cost ?? 0), a = t.warriors(t.owner, n) - i, o = Math.max(0, ...t.view.players.filter((e) => e.rid !== t.owner).map((e) => t.strength(e.rid, n))), s = t.view.players.filter((e) => e.rid !== t.owner).reduce((e, r) => e + t.pieces(r.rid, n).reduce((e, t) => e + (w(t.kind) ? t.count : 0), 0), 0), c = t.enemies(n).length, l = t.view.pieces.filter((e) => e.owner === t.owner && e.kind === "plot" && e.faceUp).length, u = 12;
		return r === "raid" && (u += 8), r === "extortion" && (u += 6 + c * 2), r === "snare" && (u += 6 + Math.min(10, s * 2)), r === "bomb" && (u += Math.min(16, s * 5)), u += r === "bomb" ? l ? 0 : -6 : 6 + l * 3, u += a > o ? 26 : a === o ? 8 : -30, a === 0 && (u -= 8), r === "bomb" && a <= 0 && (u -= 20), u;
	}
	if (r === "flipPlot") {
		let n = String(e.args?.plot ?? ""), r = e.clearing ?? 0;
		return n === "bomb" ? 20 + t.view.players.filter((e) => e.rid !== t.owner).reduce((e, n) => e + t.pieces(n.rid, r).reduce((e, t) => e + (w(t.kind) ? t.count * 2 : 1), 0), 0) * 8 : i + 20;
	}
	if (r === "corvidRecruit") {
		let n = String(e.args?.suit ?? ""), r = t.clearings.filter((e) => (n === "bird" || e.suit === n) && t.canPlace(e.id));
		return i + r.filter((e) => t.view.pieces.some((n) => n.owner === t.owner && n.kind === "plot" && !n.faceUp && n.clearing === e.id) && t.warriors(t.owner, e.id) === 0).length * 14 + r.length * 2;
	}
	if (t.me.faction === "duchy") {
		let n = ki(e, t, i);
		if (n !== null) return n;
	}
	if (r === "aidFaction") return Si(e, t, i);
	if (r === "refreshItem") return bi(t, String(e.args?.item ?? ""), i);
	if (r === "questScore") return i + Number(e.args?.vp ?? 1) * 8;
	if (r === "questDraw") return i + (t.hand.length <= 2 ? 32 : 6);
	if (r === "stealCard" || r === "dayLabor") return i + (t.hand.length <= 2 ? 18 : 0);
	if (r === "explore") return i + (ui(t).length < 6 ? 18 : 8);
	if (r === "strikePiece") {
		let n = t.view.players.find((t) => t.faction === String(e.args?.faction ?? "")), r = t.board?.relationships.find((e) => e.owner === n?.rid);
		return String(e.args?.piece ?? "") === "warrior" ? r?.level === -1 ? i + 10 : -40 : i + 14;
	}
	if (r === "repairItem") {
		let n = String(e.args?.item ?? ""), r = i;
		return mi(t).has(n) && (r += 12), (n === "coin" || n === "tea") && (r += 8), n === "torch" && (r += 4), r;
	}
	if (r === "takeRuinItem") {
		let n = String(e.args?.item ?? "");
		return i + (mi(t).has(n) ? 16 : 0) + (ui(t).some((e) => e.type === n) ? 0 : 4) + (n === "tea" ? 8 : n === "coin" ? 6 : 0);
	}
	if (r === "takeCraftedItem") {
		let n = String(e.args?.item ?? "");
		return i + (mi(t).has(n) ? 16 : 0) + (n === "hammer" || n === "torch" ? 4 : 0) + (n === "tea" ? 8 : n === "coin" ? 6 : 0);
	}
	if (r === "coalitionWith") {
		let n = t.view.players.find((t) => t.faction === String(e.args?.faction ?? ""));
		return n && n.vp >= t.me.vp + 12 ? i : -1e3;
	}
	if (r === "takeDominance") return t.me.faction === "vagabond" ? -1e3 : i;
	if (r === "damageItem") return Ci(String(e.args?.item ?? ""));
	if (r === "craftCard" || r === "craftWith") return xi(t, e, i);
	if (r === "discardItem") {
		let n = String(e.args?.item ?? "");
		return i + (mi(t).has(n) ? 0 : 8) + (n === "boot" || n === "hammer" ? 6 : 0);
	}
	return r === "battleAgainst" || r === "battleWithAlly" ? wi(e, t, i) : r === "vagabondMove" || r === "slipClearing" || r === "vagabondFerry" || r === "glideTo" ? i + yi(t, Number(e.args?.n ?? e.clearing ?? 0)) - Number(e.args?.cost ?? 0) * 2 : i;
}
function ji(e, t, n) {
	let r = e.action;
	if (e.kind === "option") return Ai(e, t, n);
	if (e.kind === "itemHit") {
		let e = t.view.table?.boards.flatMap((e) => e.items).find((e) => r.type === "itemHit" && e.uid === r.uid);
		return e ? Ci(e.type) : 0;
	}
	if (e.kind === "hospital") return 80 + (e.n ?? 0);
	if (e.kind === "counter") return 90;
	if (e.kind === "ambush") return 75;
	if (r.type === "effect") return r.effect === "armorers" ? 65 : 55;
	if (r.type === "loss") {
		let e = t.view.pieces.find((e) => e.uid === r.piece);
		return e?.kind === "keep" ? -1e3 : e?.kind === "sympathy" || e?.kind === "base" || e?.kind === "garden" ? -25 : e?.kind === "wood" ? 30 : 10;
	}
	return r.type === "battle" ? ai(r, t) : r.type === "move" ? ci(r, t) : r.type === "effectOrder" ? 5 : -100;
}
var Mi = (e, t) => {
	if (e.public.acting !== t.rid || !e.private?.choices.length) return null;
	let n = Gr(e.public, t.rid, e.private.hand), r = e.private.choices.some((e) => e.label === "addDecree") && e.private.choices.some((e) => e.label === "continue"), i = e.private.choices.map((e, t) => ({
		choice: e,
		index: t,
		n: ji(e, n, r)
	}));
	return i.sort((e, t) => t.n - e.n || e.index - t.index), { action: i[0].choice.action };
}, Ni = (e) => e.data ?? {}, Pi = (e) => e && e.w > 0 && e.h > 0 ? e : null, Fi = (e, t = "") => Pi(e.anchor(`faction:${t}`)) ?? Pi(e.anchor(`seat:${t}`)), Ii = (e, t = "") => t === e.myRid ? Pi(e.anchor("hand")) ?? Fi(e, t) : Fi(e, t), Li = (e, t) => t === void 0 ? null : Pi(e.anchor(`clearing:${t}`)), $ = (e, t = 36, n = t) => ({
	x: e.x + e.w / 2 - t / 2,
	y: e.y + e.h / 2 - n / 2,
	w: t,
	h: n
}), Ri = (e, t = 520) => e.queued ? 220 : t;
function zi({ children: e, faction: t, className: n = "" }) {
	return /* @__PURE__ */ A("span", {
		className: `root-fx-seal ${n}`,
		style: {
			"--root-ink": T.ink,
			"--root-paper": T.cream,
			"--root-gold": T.gold,
			"--root-faction": t ? T[t] : T.pineDark
		},
		children: e
	});
}
function Bi({ card: e }) {
	let t = xr(ke());
	return e ? /* @__PURE__ */ A("div", {
		className: "root-fx-card",
		children: /* @__PURE__ */ A(oe, {
			card: e,
			t
		})
	}) : /* @__PURE__ */ A("span", {
		className: "root-fx-card-back",
		style: {
			color: T.gold,
			background: T.paper,
			borderColor: T.bark
		},
		children: /* @__PURE__ */ A(C, { faction: "vagabond" })
	});
}
function Vi({ from: e, to: t, ms: n }) {
	let r = Math.atan2(t.y + t.h / 2 - e.y - e.h / 2, t.x + t.w / 2 - e.x - e.w / 2) * 180 / Math.PI + 90;
	return /* @__PURE__ */ A(ze, {
		from: $(e, 30),
		to: $(t, 30),
		ms: n,
		children: /* @__PURE__ */ A(zi, { children: /* @__PURE__ */ A("svg", {
			viewBox: "0 0 32 32",
			style: { transform: `rotate(${r}deg)` },
			"aria-hidden": "true",
			children: /* @__PURE__ */ A("path", {
				d: "m7 22 9-13 9 13-9-5Z",
				fill: "currentColor"
			})
		}) })
	});
}
function Hi({ at: e, ms: t }) {
	return /* @__PURE__ */ A("svg", {
		className: "root-fx-impact",
		style: {
			left: e.x + e.w / 2 - 38,
			top: e.y + e.h / 2 - 38,
			animationDuration: `${t}ms`
		},
		viewBox: "0 0 76 76",
		"aria-hidden": "true",
		children: /* @__PURE__ */ j("g", {
			fill: "none",
			stroke: T.gold,
			strokeWidth: "3",
			strokeLinecap: "round",
			children: [Array.from({ length: 8 }, (e, t) => /* @__PURE__ */ A("path", {
				d: "M38 7v12",
				transform: `rotate(${t * 45} 38 38)`
			}, t)), /* @__PURE__ */ A("path", {
				d: "m26 27 24 24m0-24L26 51",
				stroke: T.ink
			})]
		})
	});
}
function Ui(e, t, n) {
	let r = Ni(e), i = Li(t, r.clearing) ?? Fi(t, e.rid);
	if (!i) return null;
	let a = Ri(t);
	return {
		ms: a,
		node: /* @__PURE__ */ j("div", {
			className: "root-fx-scene",
			children: [/* @__PURE__ */ A(Be, {
				at: i,
				ms: a
			}), n && /* @__PURE__ */ A(Re, {
				at: i,
				ms: a,
				children: /* @__PURE__ */ A(zi, {
					faction: r.faction,
					children: n
				})
			})]
		})
	};
}
var Wi = {
	move(e, t) {
		let n = Ni(e), r = Li(t, n.from) ?? Fi(t, e.rid), i = Li(t, n.clearing) ?? Fi(t, e.rid);
		if (!r || !i) return null;
		let a = Ri(t), o = n.total === n.n && n.faction !== "vagabond" && !t.queued;
		return {
			ms: a,
			hide: o ? [`army:${e.rid}:${n.clearing}`] : [],
			node: /* @__PURE__ */ j("div", {
				className: "root-fx-scene",
				children: [
					o && n.faction ? /* @__PURE__ */ A(ze, {
						from: $(r),
						to: $(i),
						ms: a - 90,
						children: /* @__PURE__ */ j(zi, {
							faction: n.faction,
							children: [/* @__PURE__ */ A(C, { faction: n.faction }), /* @__PURE__ */ A("b", { children: n.n })]
						})
					}) : /* @__PURE__ */ A(Vi, {
						from: r,
						to: i,
						ms: a - 90
					}),
					/* @__PURE__ */ A(Be, {
						at: i,
						ms: a - 180,
						delay: 180
					}),
					/* @__PURE__ */ A(Re, {
						at: i,
						ms: a - 140,
						delay: 140,
						children: /* @__PURE__ */ j(zi, {
							faction: n.faction,
							children: ["+", n.n]
						})
					})
				]
			})
		};
	},
	piece(e, t) {
		let n = Ni(e), r = Ui(e, t, /* @__PURE__ */ j(k, { children: [n.kind && n.kind !== "warrior" ? /* @__PURE__ */ A(fe, { kind: n.kind }) : n.faction && /* @__PURE__ */ A(C, { faction: n.faction }), /* @__PURE__ */ j("b", { children: [n.mode === "remove" ? "−" : "+", n.n] })] })), i = Li(t, n.clearing);
		return r && i && n.mode === "remove" && n.kind !== "wood" ? {
			...r,
			node: /* @__PURE__ */ j(k, { children: [r.node, /* @__PURE__ */ A(Hi, {
				at: i,
				ms: r.ms
			})] })
		} : r;
	},
	draw(e, t) {
		let n = Pi(t.anchor("deck")), r = Ii(t, e.rid);
		if (!n || !r) return null;
		let i = Ni(e), a = Ri(t), o = Math.min(4, i.n ?? 1), s = e.secret?.uids ?? [];
		return {
			ms: a,
			hide: t.queued ? [] : s.map((e) => `card:${e}`),
			node: /* @__PURE__ */ A(k, { children: Array.from({ length: o }, (e, t) => /* @__PURE__ */ A(ze, {
				from: $(n, 40, 55),
				to: $(r, 40, 55),
				ms: a - o * 40,
				delay: t * 40,
				children: /* @__PURE__ */ A(Bi, {})
			}, t)) })
		};
	},
	card(e, t) {
		let n = Ni(e), r = Ii(t, e.rid), i = Pi(t.anchor("battle")) ?? Li(t, n.clearing);
		if (!r || !i) return null;
		let a = Ri(t);
		return {
			ms: a,
			node: /* @__PURE__ */ A(ze, {
				from: $(r, 64, 88),
				to: $(i, 64, 88),
				ms: a,
				children: /* @__PURE__ */ A(Bi, { card: n.card })
			})
		};
	},
	cardUse(e, t) {
		if (!e.secret) return null;
		let n = Ii(t, t.myRid);
		return n ? {
			ms: 280,
			node: /* @__PURE__ */ A("div", {
				className: "root-fx-scene",
				children: /* @__PURE__ */ A(Be, {
					at: n,
					ms: 280
				})
			})
		} : null;
	},
	craft(e, t) {
		let n = Ni(e), r = Ii(t, e.rid), i = Fi(t, e.rid);
		if (!r || !i) return null;
		let a = Ri(t, 600);
		return {
			ms: a,
			node: /* @__PURE__ */ j("div", {
				className: "root-fx-scene",
				children: [
					/* @__PURE__ */ A(ze, {
						from: $(r, 64, 88),
						to: $(i, 64, 88),
						ms: a - 80,
						children: /* @__PURE__ */ A(Bi, { card: n.card })
					}),
					n.locations?.map((e, n) => {
						let r = Li(t, e);
						return r && /* @__PURE__ */ A(Be, {
							at: r,
							ms: a - 50
						}, `${e}:${n}`);
					}),
					n.item && /* @__PURE__ */ A(Re, {
						at: i,
						ms: a,
						children: /* @__PURE__ */ A(zi, {
							faction: n.faction,
							children: /* @__PURE__ */ A(se, { item: n.item })
						})
					})
				]
			})
		};
	},
	decree(e, t) {
		let n = Ni(e), r = Ii(t, e.rid), i = `decree:${e.rid}:${n.column}`, a = Pi(t.anchor(i)) ?? Fi(t, e.rid);
		if (!r || !a) return null;
		let o = Ri(t), s = n.card ? `decree-card:${n.card.uid}` : "";
		return {
			ms: o,
			hide: t.queued || !Pi(t.anchor(s)) ? [] : [s],
			node: /* @__PURE__ */ j("div", {
				className: "root-fx-scene",
				children: [/* @__PURE__ */ A(ze, {
					from: $(r, 48, 66),
					to: $(a, 48, 66),
					ms: o - 60,
					children: /* @__PURE__ */ A(Bi, { card: n.card })
				}), /* @__PURE__ */ A(Be, {
					at: a,
					ms: o - 120,
					delay: 120
				})]
			})
		};
	},
	item(e, t) {
		let n = Ni(e), r = Pi(t.anchor(`item:${n.uid}`)) ?? Fi(t, e.rid);
		if (!r) return null;
		let i = Ri(t, 420);
		return {
			ms: i,
			node: /* @__PURE__ */ j("div", {
				className: "root-fx-scene",
				children: [/* @__PURE__ */ A(Be, {
					at: r,
					ms: i
				}), n.item && /* @__PURE__ */ A(Re, {
					at: r,
					ms: i,
					children: /* @__PURE__ */ A(zi, {
						faction: n.faction,
						children: /* @__PURE__ */ A(se, { item: n.item })
					})
				})]
			})
		};
	},
	funds: (e, t) => Ui(e, t, /* @__PURE__ */ j(k, { children: [
		/* @__PURE__ */ A(se, { item: "coin" }),
		"−",
		Ni(e).n
	] })),
	supporters: (e, t) => Ui(e, t, /* @__PURE__ */ j(k, { children: [
		"+",
		Ni(e).n,
		/* @__PURE__ */ A(C, { faction: "alliance" })
	] })),
	decision(e, t) {
		if (!e.secret) return null;
		let n = e.secret, r = Li(t, n.clearing) ?? Fi(t, t.myRid) ?? Pi(t.anchor("actions"));
		return r && n.label && Object.hasOwn(Sr, n.label) ? {
			ms: Ri(t, 360),
			node: /* @__PURE__ */ A("div", {
				className: "root-fx-scene",
				children: /* @__PURE__ */ A(Be, {
					at: r,
					ms: Ri(t, 360)
				})
			})
		} : null;
	},
	battle: (e, t) => Ui(e, t, /* @__PURE__ */ A("span", {
		className: "root-fx-clash",
		children: "⚔"
	})),
	roll(e, t) {
		let n = Pi(t.anchor("battle"));
		return n ? {
			ms: 620,
			node: /* @__PURE__ */ A("div", {
				className: "root-fx-scene",
				children: /* @__PURE__ */ A(Be, {
					at: n,
					ms: 620
				})
			})
		} : null;
	},
	ambush: (e, t) => Ui(e, t, /* @__PURE__ */ A("span", {
		className: "root-fx-clash",
		children: "⚔"
	})),
	counter: (e, t) => Ui(e, t, "◇"),
	assign: (e, t) => Ui(e, t, "✓"),
	effect: (e, t) => Ui(e, t, "✦"),
	hospital: (e, t) => Ui(e, t, /* @__PURE__ */ j(k, { children: ["+", Ni(e).n] })),
	skipHospital: (e, t) => Ui(e, t),
	complete: (e, t) => Ui(e, t, "✓")
};
//#endregion
//#region src/games/root/endgame-review.tsx
function Gi({ board: e, renderResult: t, ...n }) {
	let r = ke(), [i, a] = De(!0), [o, s] = De(null), c = Ee(null), l = Ee(null), u = Ee(null);
	we(() => {
		if (!o) return;
		u.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => s(null), 5e3);
		return () => clearTimeout(e);
	}, [o]);
	let d = (e) => {
		s(null), a(e), requestAnimationFrame(() => (e ? c : l).current?.focus({ preventScroll: !0 }));
	}, f = Te(() => ({
		onPlayAgain: n.onPlayAgain && (() => s({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => s({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => s({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), p = {
		...n,
		...f
	};
	return /* @__PURE__ */ j("div", {
		className: "root-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ A("div", {
				className: "root-endgame-board",
				inert: i,
				children: e
			}),
			/* @__PURE__ */ A("div", {
				className: "root-endgame-overlay",
				hidden: !i,
				children: /* @__PURE__ */ j("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), d(!1));
					},
					className: "root-endgame-panel",
					"aria-label": r("session.result.title"),
					children: [
						/* @__PURE__ */ j("header", {
							className: "root-endgame-heading",
							children: [/* @__PURE__ */ j("div", {
								className: "root-endgame-brand",
								children: [/* @__PURE__ */ A("span", {
									"aria-hidden": "true",
									children: Ye.icon
								}), r(Ye.nameKey)]
							}), /* @__PURE__ */ A("button", {
								type: "button",
								ref: c,
								className: "btn-quiet",
								"aria-label": r("games.root.reviewHide"),
								title: r("games.root.reviewHide"),
								onClick: () => d(!1),
								children: /* @__PURE__ */ A(Ue, { size: 19 })
							})]
						}),
						/* @__PURE__ */ A("div", {
							className: "root-endgame-result",
							inert: o !== null,
							children: t(p)
						}),
						o && /* @__PURE__ */ j("div", {
							className: "root-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || s(null);
							},
							children: [/* @__PURE__ */ A("button", {
								type: "button",
								ref: u,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = o.run;
									s(null), e();
								},
								children: r(o.label === "again" ? "games.root.reviewConfirmAgain" : "games.root.reviewConfirmLobby")
							}), /* @__PURE__ */ A("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									s(null), c.current?.focus({ preventScroll: !0 });
								},
								children: r("games.root.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ A("div", {
				className: "root-endgame-toolbar",
				hidden: i,
				children: /* @__PURE__ */ j("button", {
					type: "button",
					className: "btn-base",
					ref: l,
					onClick: () => d(!0),
					children: [
						/* @__PURE__ */ A(We, { size: 18 }),
						r("games.root.reviewShow"),
						/* @__PURE__ */ A(Ve, { size: 18 })
					]
				})
			})
		]
	});
}
function Ki({ result: e, members: t, myRid: n, hintCount: r, onPlayAgain: i, onBackToLobby: a, rows: o, renderRowExtra: s, summary: c, navigation: l, content: u, afterRanking: d, scoreUnit: f, rankOf: p }) {
	let m = ke(), h = Oe((e) => e.locale), [g, _] = De({}), v = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? Ge(n, h) : e;
	}, y = (t, n) => p?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), ee = e.ranking.some((t) => e.scores?.[t] !== void 0), te = (t, r) => /* @__PURE__ */ j("div", {
		className: "root-score-identity",
		children: [
			/* @__PURE__ */ j("span", {
				className: "root-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ A("span", {
					"aria-label": m("games.root.victory"),
					children: "♛ "
				}), ee && y(t, r)]
			}),
			/* @__PURE__ */ j("span", {
				className: "root-score-name",
				children: [v(t), t === n && /* @__PURE__ */ A("small", { children: m("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ j("small", {
				className: "root-score-autopilot",
				children: [
					/* @__PURE__ */ A(He, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), b = (t) => e.ranking.map((n) => /* @__PURE__ */ A("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ j("div", {
		className: "root-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ A(Ke, {}),
			l,
			/* @__PURE__ */ j("div", {
				className: "root-score-body",
				children: [
					c && /* @__PURE__ */ A("div", {
						className: "root-score-summary",
						children: c
					}),
					r !== void 0 && /* @__PURE__ */ A("p", {
						className: "root-score-hints",
						children: m("session.hint.usedCount", { n: r })
					}),
					u ?? (o?.length ? /* @__PURE__ */ A("div", {
						className: "root-score-table-scroll",
						children: /* @__PURE__ */ j("table", {
							className: "root-score-table",
							"aria-label": m(Ye.nameKey),
							children: [
								/* @__PURE__ */ A("thead", { children: /* @__PURE__ */ j("tr", { children: [/* @__PURE__ */ A("th", { scope: "col" }), /* @__PURE__ */ A(k, { children: e.ranking.map((t, n) => /* @__PURE__ */ A("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: te(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ A("tbody", { children: o.map((e, t) => /* @__PURE__ */ j(xe, { children: [/* @__PURE__ */ j("tr", { children: [/* @__PURE__ */ A("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ j("button", {
										type: "button",
										"aria-expanded": !!g[t],
										onClick: () => _((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ A(Ue, { size: 15 }), e.label]
									}) : e.label
								}), b(e)] }), g[t] && e.details?.map((e, t) => /* @__PURE__ */ j("tr", {
									className: "root-score-sub",
									children: [/* @__PURE__ */ A("th", {
										scope: "row",
										children: e.label
									}), b(e)]
								}, t))] }, t)) }),
								ee && /* @__PURE__ */ A("tfoot", { children: /* @__PURE__ */ j("tr", { children: [/* @__PURE__ */ A("th", {
									scope: "row",
									children: m("games.root.cardVictoryPoints")
								}), e.ranking.map((t) => /* @__PURE__ */ A("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ A("ol", {
						className: "root-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ j("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ j("div", {
								className: "root-score-rankline",
								children: [te(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ j("strong", {
									className: "root-score-points",
									children: [e.scores[t], f && /* @__PURE__ */ A("small", { children: f })]
								})]
							}), s?.(t)]
						}, t))
					})),
					d,
					!!o?.length && s && /* @__PURE__ */ A("div", {
						className: "root-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ j("details", { children: [/* @__PURE__ */ A("summary", { children: v(e) }), s(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ j("footer", {
				className: "root-score-actions",
				children: [
					a && /* @__PURE__ */ A("button", {
						type: "button",
						className: "btn-quiet",
						onClick: a,
						children: m("session.result.backToLobby")
					}),
					i && /* @__PURE__ */ A("button", {
						type: "button",
						className: "btn-base",
						onClick: i,
						children: m("session.result.playAgain")
					}),
					!i && !a && /* @__PURE__ */ A("p", { children: m("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/root/game-over.tsx
function qi(e) {
	return /* @__PURE__ */ A(Ki, {
		...e,
		accent: Ye.accent
	});
}
function Ji(e) {
	return /* @__PURE__ */ A(Gi, {
		...e,
		board: /* @__PURE__ */ A(zr, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ A(qi, { ...e })
	});
}
//#endregion
//#region src/games/root/options.tsx
function Yi({ value: e, onChange: t }) {
	let n = xr(ke()), r = $e.safeParse(e), i = r.success ? r.data : $e.parse(void 0);
	return /* @__PURE__ */ j("div", {
		className: "flex flex-col gap-3",
		children: [/* @__PURE__ */ A(Je, {
			title: n("mapOption"),
			children: [
				"autumn",
				"winter",
				"lake",
				"mountain"
			].map((e) => /* @__PURE__ */ A(qe, {
				name: "root-map",
				value: e,
				checked: i.map === e,
				label: n(e),
				accent: Ye.accent,
				onChange: () => t({
					...i,
					map: e
				})
			}, e))
		}), /* @__PURE__ */ j(Je, {
			title: n("factionsOption"),
			children: [/* @__PURE__ */ A(qe, {
				name: "root-factions",
				value: "all",
				checked: !i.factions.length,
				label: n("allFactions"),
				accent: Ye.accent,
				onChange: () => t({
					...i,
					factions: []
				})
			}), /* @__PURE__ */ A(qe, {
				name: "root-factions",
				value: "core",
				checked: !!i.factions.length,
				label: n("coreFactions"),
				accent: Ye.accent,
				onChange: () => t({
					...i,
					factions: [
						"marquise",
						"eyrie",
						"alliance",
						"vagabond"
					]
				})
			})]
		})]
	});
}
//#endregion
//#region src/games/root/locales/extra.ts
var Xi = {
	cardSuitDominance: "{{suit}}支配",
	cardCraftCost: "锻造需求",
	cardCraftedReward: "锻造后获得",
	cardOnceDaylight: "白天 · 每回合一次",
	cardInspectHand: "查看对手手牌",
	cardImmediateHits: "点立即伤害",
	cardAmbushFoil: "匹配奇袭可抵消",
	cardInspectHandText: "查看一名对手的手牌。",
	cardAmbushText: "防守时、掷骰前使用；进攻方可用匹配的奇袭牌抵消。",
	cardVictoryPoints: "分",
	cardDominanceActivate: "白天 · 至少 10 分",
	cardOppositeCorners: "控制对角领地",
	cardBirdDominanceText: "清晨开始时，控制一对对角领地即可获胜，取代分数胜利。游侠：四人及以上时，改与最低分的非游侠玩家结盟。",
	cardSuitDominanceText: "清晨开始时，控制三个{{suit}}领地即可获胜，取代分数胜利。游侠：四人及以上时，改与最低分的非游侠玩家结盟。",
	cardThreeClearings: "控制同色领地",
	cardWhenCrafted: "锻造时",
	cardFavorBrief: "移除匹配领地的敌方棋件",
	cardOnceBirdsong: "清晨 · 每回合一次",
	cardStartDaylight: "白天开始时",
	cardStartBirdsong: "清晨开始时",
	cardStartEvening: "夜晚开始时",
	cardInBirdsong: "清晨时",
	cardInBattle: "战斗时",
	cardAsAttacker: "作为进攻方",
	cardAsDefender: "作为防守方",
	cardArmorersBrief: "忽略掷骰伤害",
	cardExtraHit: "额外造成 1 点伤害",
	cardBrutalTacticsBrief: "额外伤害，对手得分",
	cardScoutingPartyBrief: "不受奇袭影响",
	cardStandAndDeliverBrief: "窃取手牌，对手得分",
	cardCommandWarrenBrief: "发起一次战斗",
	cardBetterBurrowBankBrief: "双方各抽一张牌",
	cardCobblerBrief: "进行一次移动",
	cardTaxCollectorBrief: "移回士兵，抽牌",
	cardRoyalClaimBrief: "按控制领地得分",
	cardSappersText: "弃置此牌，额外造成 1 点伤害。",
	cardBrutalTacticsText: "额外造成 1 点伤害，防守方获得 1 分。",
	cardScoutingPartyText: "不受奇袭影响。",
	cardStandAndDeliverText: "窃取一名对手的随机手牌，该对手获得一分。",
	cardCommandWarrenText: "可以发起一次战斗。",
	cardBetterBurrowBankText: "你和一名对手各抽一张牌。",
	cardCobblerText: "可以进行一次移动。",
	cardTaxCollectorText: "从任意领地移回一名己方士兵，抽一张牌。",
	cardRoyalClaimText: "可以弃置此牌，每控制一处领地获得一分。",
	cardVizierBrief: "鸟牌法令",
	cardVizierText: "作为鸟牌履行法令。忠臣由领袖指定放置位置，动乱时随新领袖重新放置，不进入弃牌堆。",
	supplyArea: "公共区域",
	itemSupply: "可锻造道具",
	discardPile: "弃牌堆",
	servicePrices: "服务价格",
	ministerCourt: "大臣",
	chooseItemLoss: "选择要损坏的道具或移除的盟军士兵",
	tower: "山口高塔",
	scorched: "焦土",
	inspectClearing: "查看领地 {{n}} 的棋件",
	vagabondFerry: "乘渡轮至领地 {{n}}，耗竭 {{cost}} 只靴子，携带 {{count}} 名{{faction}}士兵",
	ferry: "渡轮",
	crowns: "可用王冠",
	fundsUsed: "资金来源",
	resolveEffect: "处理{{faction}}的{{effect}}",
	gardenLoss: "失去庭院",
	hospitalPay: "支付{{suit}}「{{card}}」，救回 {{count}} 名士兵",
	standAndDeliverText: "清晨时每回合一次，窃取一名对手的随机手牌，该对手获得一分。",
	commandWarrenText: "白天开始时，可以发起一次战斗。",
	betterBurrowBankText: "清晨开始时，你和一名对手各抽一张牌。",
	cobblerText: "夜晚开始时，可以进行一次移动。",
	codebreakersText: "白天时每回合一次，查看一名对手的手牌。",
	taxCollectorText: "白天时每回合一次，从任意领地移回一名己方士兵，抽一张牌。",
	royalClaimText: "清晨时可以弃置此牌，每控制一处领地获得一分。",
	favorText: "移除所有匹配此牌花色的领地中的敌方棋件。",
	craft: "锻造",
	winter: "冬季森林",
	lake: "湖泊",
	mountain: "山脉",
	birdsong: "清晨",
	evening: "夜晚",
	setup: "准备",
	continue: "继续",
	recruit: "招募",
	build: "建造",
	finishActions: "结束行动",
	finishCraft: "结束锻造",
	standAndDeliver: "拦路抢劫",
	commandWarren: "指挥所",
	betterBurrowBank: "兔窝银行",
	cobbler: "补鞋匠",
	codebreakers: "密码破译员",
	taxCollector: "税吏",
	royalClaim: "王权宣告",
	swiftStrike: "迅捷打击",
	boot: "靴子",
	sack: "背包",
	crossbow: "十字弩",
	hammer: "锤子",
	sword: "剑",
	tea: "茶壶",
	coin: "钱币",
	torch: "火炬",
	thief: "盗贼",
	tinker: "工匠",
	ranger: "游骑兵",
	vagrant: "无赖",
	arbiter: "霸王",
	scoundrel: "恶棍",
	adventurer: "冒险家",
	harrier: "飞毛腿",
	ronin: "浪人",
	foremole: "工头",
	captain: "队长",
	marshal: "元帅",
	brigadier: "准将",
	banker: "银行家",
	mayor: "市长",
	duchess: "泥泞女公爵",
	baron: "尘土男爵",
	earl: "磐石伯爵",
	bomb: "炸弹",
	snare: "圈套",
	extortion: "勒索",
	raid: "袭击",
	card: "手牌",
	boats: "小舟",
	mercenaries: "佣兵",
	birdyBindle: "鸟儿行囊",
	woodlandRunners: "林间快靴",
	armsTrader: "军火商",
	knapsack: "二手背包",
	rootTea: "树根茶",
	travelGear: "旅行装备",
	protectionRacket: "保护费",
	foxfolkSteel: "狐族钢铁",
	anvil: "铁砧",
	smugglersTrail: "走私小径",
	visitFriends: "走亲访友",
	bakeSale: "糕点义卖",
	mouseSack: "袋中老鼠",
	investments: "投资",
	favor: "族群恩惠",
	vizier: "忠臣",
	fundraising: "筹款",
	logistics: "后勤支援",
	repairShed: "修理棚屋",
	speech: "发表演说",
	errand: "跑腿",
	expelBandits: "驱逐匪徒",
	fendBear: "赶走巨熊",
	guardDuty: "站岗",
	escort: "护送",
	chooseClearing: "选择领地 {{n}}",
	chooseForest: "选择树林 {{n}}",
	placeBuilding: "在领地 {{n}} 放置{{piece}}",
	recruitAt: "在领地 {{n}} 招募 {{count}} 名士兵",
	setPrice: "{{service}}价格设为 {{n}}",
	payOutrage: "平息民愤：交出{{suit}}牌「{{card}}」",
	discardSupporter: "弃置支持者：{{suit}}「{{card}}」",
	returnFund: "退还一名{{faction}}士兵",
	loseMinister: "失去{{minister}}",
	damageItem: "损坏{{item}}",
	enlistArbiter: "请求霸王保护",
	craftCard: "锻造{{suit}}牌「{{card}}」",
	craftWith: "使用 {{places}} 锻造「{{card}}」",
	exportCard: "出口「{{card}}」",
	coalitionWith: "与{{faction}}结盟",
	activateDominance: "启用{{suit}}支配",
	takeDominance: "支付「{{card}}」取得{{suit}}支配",
	inspectHand: "查看{{faction}}的手牌",
	collectTax: "从领地 {{n}} 收税",
	clearPath: "支付「{{card}}」清理 {{from}}—{{to}} 道路",
	exposePlot: "出示{{suit}}「{{card}}」：猜测领地 {{n}} 为{{plot}}",
	buildAt: "在领地 {{n}} 建造{{piece}}：{{cost}} 木材，{{vp}} 分",
	overworkAt: "支付「{{card}}」在领地 {{n}} 加班",
	extraAction: "支付鸟牌「{{card}}」增加一次行动",
	spendWood: "使用领地 {{n}} 的木材",
	addDecree: "将{{suit}}「{{card}}」加入{{column}}法令",
	emergencyRoostAt: "在领地 {{n}} 建立紧急鸟巢",
	fulfillMove: "履行{{suit}}移动法令",
	fulfillBattle: "履行{{suit}}战斗法令",
	placeRoost: "在领地 {{n}} 建造鸟巢",
	revoltAt: "在领地 {{n}} 发动起义",
	finishRevolt: "结束起义",
	spreadAt: "向领地 {{n}} 传播民意：{{cost}} 支持者，{{vp}} 分",
	finishSpread: "结束传播民意",
	spendSupporter: "支付{{suit}}支持者「{{card}}」",
	organizeAt: "在领地 {{n}} 组织民意：{{vp}} 分",
	mobilizeCard: "将{{suit}}「{{card}}」动员为支持者",
	trainOfficer: "支付{{suit}}「{{card}}」训练长官",
	sacrifice: "揭示鸟牌「{{card}}」进行献祭",
	cultScore: "支付{{suit}}「{{card}}」举行仪式：{{vp}} 分",
	ritualRecruit: "揭示「{{card}}」在领地 {{n}} 招募",
	ritualBuild: "揭示「{{card}}」在领地 {{n}} 建造庭院",
	crusadeMove: "花费 {{cost}} 名仆从发动圣战移动",
	crusadeBattle: "花费 {{cost}} 名仆从发动圣战战斗",
	convertAt: "花费 {{cost}} 名仆从转化领地 {{n}} 的{{faction}}士兵",
	sanctifyAt: "花费 {{cost}} 名仆从净化领地 {{n}} 的{{piece}}",
	finishConspiracies: "结束阴谋",
	fundMove: "调用一名{{faction}}资金，进行移动",
	fundBattle: "调用一名{{faction}}资金，发起战斗",
	fundDraw: "调用一名{{faction}}资金，抽一张牌",
	fundRecruit: "花费一名{{faction}}资金，在领地 {{n}} 招募",
	establishPost: "花费两名{{faction}}资金，在领地 {{n}} 建立贸易站",
	duchyBuild: "揭示「{{card}}」在领地 {{n}} 建造{{piece}}",
	recruitBurrow: "在地洞招募一名士兵",
	digAt: "支付「{{card}}」，从{{from}}取隧道，在领地 {{n}} 挖掘并移动 {{count}} 名士兵",
	ministerMove: "{{minister}}：至多移动 {{count}} 次",
	ministerBattle: "{{minister}}：至多战斗 {{count}} 次",
	bankerSuit: "银行家：支付{{suit}}牌得分",
	ministerScore: "{{minister}}：获得 {{vp}} 分",
	finishParliament: "结束议会",
	bankerSpend: "支付{{suit}}「{{card}}」，获得一分",
	finishBanker: "结束银行家行动",
	swayMinister: "说服{{minister}}：揭示 {{cost}} 张牌，获得 {{vp}} 分",
	finishSway: "结束说服大臣",
	revealForSway: "揭示{{suit}}「{{card}}」，对应领地 {{n}}",
	plotAt: "移回 {{cost}} 名士兵，在领地 {{n}} 布置{{plot}}",
	trickPlots: "交换领地 {{from}} 和 {{to}} 的阴谋",
	flipPlot: "翻开领地 {{n}} 的{{plot}}",
	finishFlip: "结束翻开阴谋",
	corvidRecruit: "支付「{{card}}」在所有{{suit}}领地招募",
	skipRecruit: "跳过招募",
	exert: "竭力行动，本回合不抽牌",
	skipExert: "跳过竭力行动",
	slipForest: "潜入树林 {{n}}",
	slipClearing: "潜行至领地 {{n}}，携带 {{count}} 名{{faction}}士兵",
	vagabondMove: "耗竭 {{cost}} 只靴子，移至领地 {{n}}，携带 {{count}} 名{{faction}}士兵",
	battleWithAlly: "与{{faction}}盟军共同进攻{{name}}",
	explore: "耗竭火炬探索遗迹",
	aidFaction: "耗竭{{item}}，协助{{faction}}并给予「{{card}}」",
	questScore: "完成{{quest}}（{{items}}），获得 {{vp}} 分",
	questDraw: "完成{{quest}}（{{items}}），抽两张牌",
	strikePiece: "袭击：耗竭十字弩，移除{{faction}}的{{piece}}",
	repairItem: "修复{{item}}",
	stealCard: "耗竭火炬，窃取{{faction}}的随机手牌",
	dayLabor: "耗竭火炬，取得弃牌{{suit}}「{{card}}」",
	hideout: "耗竭火炬，修复至多三件道具并结束白天",
	instigate: "耗竭火炬，挑动{{attacker}}进攻{{defender}}",
	scorchedEarth: "留下火炬，将此领地化为焦土",
	glideTo: "耗竭火炬，滑翔至领地 {{n}}",
	refreshItem: "重整{{item}}",
	finishRefresh: "结束重整",
	skipSlip: "跳过潜行",
	takeRuinItem: "取得遗迹中的{{item}}",
	finishRepair: "结束修复",
	takeCraftedItem: "取得{{item}}",
	skipItem: "不取道具",
	discardItem: "永久弃置{{item}}",
	finishPurchases: "结束购买服务",
	buyCard: "花费 {{cost}} 购买{{suit}}「{{card}}」",
	buyBoats: "花费 {{cost}} 购买小舟服务",
	buyMercenaries: "花费 {{cost}} 雇佣商会士兵",
	claimRule: "弃置王权宣告，获得 {{vp}} 分",
	shareBank: "与{{faction}}各抽一张牌",
	standDeliver: "窃取{{faction}}一张随机手牌，对方获得一分",
	discardCard: "弃置{{suit}}「{{card}}」",
	produceWood: "在领地 {{n}} 生产一份木材",
	supporters: "支持者",
	officers: "长官",
	decree: "法令",
	acolytes: "仆从",
	outcast: "遭弃者",
	hated: "憎恨",
	funds: "资金",
	committed: "已调用",
	payments: "付款",
	ministers: "已说服大臣",
	burrow: "地洞",
	items: "道具",
	relationships: "关系",
	quests: "任务",
	completedQuests: "已完成任务",
	craftedItems: "已锻造道具",
	revealed: "已揭示手牌",
	exhausted: "已耗竭",
	damaged: "已损坏",
	hostile: "敌对",
	indifferent: "中立",
	allied: "盟友",
	availableDominance: "可取得的支配",
	deck: "牌堆",
	lostSouls: "遭弃者牌堆",
	actions: "行动",
	chooseAction: "选择行动",
	chooseResponse: "完成当前选择",
	allActions: "可用行动",
	filterClearing: "按领地筛选",
	noChoices: "当前没有可用行动",
	mapOption: "地图",
	factionsOption: "可选阵营",
	allFactions: "本体与两项扩展",
	coreFactions: "本体四阵营",
	secondVagabond: "可选择第二游侠",
	supplyPlace: "待命区",
	draft: "选择阵营",
	setupBegin: "准备阵营",
	setupCorner: "选择起始角落",
	setupCatBuilding: "摆放起始建筑",
	setupLeader: "选择领袖",
	setupOutcast: "选择遭弃者",
	setupRiver: "摆放商会士兵",
	prices: "设置服务价格",
	setupCorvid: "摆放阴谋羽党士兵",
	setupCharacter: "选择游侠角色",
	setupForest: "选择起始树林",
	setupFinish: "完成准备",
	turnStart: "回合开始",
	services: "购买商会服务",
	birdEffects: "清晨效果",
	dayStart: "白天开始",
	eveningStart: "夜晚开始",
	draw: "抽牌",
	discard: "弃牌至五张",
	capacity: "整理背包",
	turnEnd: "回合结束",
	decreeAdd: "增加法令",
	emergencyRoost: "新的鸟巢",
	turmoil: "动乱",
	allianceRevolt: "起义",
	allianceSpread: "传播民意",
	allianceOps: "长官行动",
	cultConspiracy: "神教阴谋",
	corvidFlip: "翻开阴谋",
	corvidExert: "竭力行动",
	vagabondRefresh: "重整道具",
	vagabondSlip: "潜行",
	duchyParliament: "议会",
	duchySway: "说服大臣",
	swayCards: "揭示说服用牌",
	command: "执行行动",
	woodPayment: "支付木材",
	payCards: "支付支持者",
	chooseItem: "选择道具",
	aidItem: "选择协助道具",
	outrage: "平息民愤",
	peek: "查看手牌",
	baseLoss: "基地损失",
	tradeLoss: "贸易中断",
	failure: "失败的代价",
	arbiterResponse: "霸王保护",
	removeTunnel: "收回隧道"
}, Zi = {
	cardSuitDominance: "{{suit}} Dominance",
	cardCraftCost: "Crafting cost",
	cardCraftedReward: "Craft to gain",
	cardOnceDaylight: "Daylight · Once per turn",
	cardInspectHand: "Inspect a hand",
	cardImmediateHits: "immediate hits",
	cardAmbushFoil: "Matching ambush can foil",
	cardInspectHandText: "Look at an opponent’s hand.",
	cardAmbushText: "As defender, play before rolling. The attacker may foil this with a matching ambush.",
	cardVictoryPoints: "VP",
	cardDominanceActivate: "Daylight · At least 10 VP",
	cardOppositeCorners: "Rule opposite corners",
	cardBirdDominanceText: "At Birdsong’s start, rule two opposite corner clearings to win instead of points. Vagabond (4+ players): form a coalition with a lowest-scoring non-Vagabond player.",
	cardSuitDominanceText: "At Birdsong’s start, rule three {{suit}} clearings to win instead of points. Vagabond (4+ players): form a coalition with a lowest-scoring non-Vagabond player.",
	cardThreeClearings: "Rule matching clearings",
	cardWhenCrafted: "When crafted",
	cardFavorBrief: "Remove all enemy pieces",
	cardOnceBirdsong: "Birdsong · Once per turn",
	cardStartDaylight: "Start of Daylight",
	cardStartBirdsong: "Start of Birdsong",
	cardStartEvening: "Start of Evening",
	cardInBirdsong: "During Birdsong",
	cardInBattle: "During battle",
	cardAsAttacker: "As attacker",
	cardAsDefender: "As defender",
	cardArmorersBrief: "Ignore rolled hits",
	cardExtraHit: "Deal 1 extra hit",
	cardBrutalTacticsBrief: "Extra hit; defender +1 VP",
	cardScoutingPartyBrief: "Ambush immunity",
	cardStandAndDeliverBrief: "Steal; opponent +1 VP",
	cardCommandWarrenBrief: "Take a battle",
	cardBetterBurrowBankBrief: "Both draw a card",
	cardCobblerBrief: "Take a move",
	cardTaxCollectorBrief: "Return warrior; draw",
	cardRoyalClaimBrief: "Score ruled clearings",
	cardSappersText: "Discard this to deal 1 extra hit.",
	cardBrutalTacticsText: "Deal 1 extra hit. The defender scores 1 point.",
	cardScoutingPartyText: "You are not affected by ambushes.",
	cardStandAndDeliverText: "Steal a random card from an opponent. They score 1 point.",
	cardCommandWarrenText: "You may initiate a battle.",
	cardBetterBurrowBankText: "You and one opponent each draw a card.",
	cardCobblerText: "You may take a move.",
	cardTaxCollectorText: "Return one of your warriors from any clearing to draw a card.",
	cardRoyalClaimText: "You may discard this to score 1 point per clearing you rule.",
	cardVizierBrief: "Wild Decree card",
	cardVizierText: "Bird card in the Decree. Your leader sets its column. Reassign it after Turmoil; never discard it.",
	supplyArea: "Shared supply",
	itemSupply: "Craftable items",
	discardPile: "Discard pile",
	servicePrices: "Service prices",
	ministerCourt: "Ministers",
	chooseItemLoss: "Choose an item to damage or an allied warrior to remove",
	tower: "Pass tower",
	scorched: "Scorched",
	inspectClearing: "Inspect pieces in clearing {{n}}",
	vagabondFerry: "Ferry to {{n}}: exhaust {{cost}} boots, take {{count}} {{faction}} warriors",
	ferry: "Ferry",
	crowns: "Available crowns",
	fundsUsed: "Funds used",
	resolveEffect: "Resolve {{faction}}: {{effect}}",
	gardenLoss: "Garden lost",
	hospitalPay: "Spend {{suit}} {{card}} to save {{count}} warriors",
	standAndDeliverText: "Once in Birdsong, steal a random card from an opponent. They score one point.",
	commandWarrenText: "At the start of Daylight, you may initiate a battle.",
	betterBurrowBankText: "At the start of Birdsong, you and one opponent each draw a card.",
	cobblerText: "At the start of Evening, you may take a move.",
	codebreakersText: "Once in Daylight, look at an opponent’s hand.",
	taxCollectorText: "Once in Daylight, return one of your warriors from any clearing to draw a card.",
	royalClaimText: "In Birdsong, discard this card to score one point per clearing you rule.",
	favorText: "Remove all enemy pieces in clearings matching this card’s suit.",
	craft: "Craft",
	winter: "Winter",
	lake: "Lake",
	mountain: "Mountain",
	birdsong: "Birdsong",
	evening: "Evening",
	setup: "Setup",
	continue: "Continue",
	recruit: "Recruit",
	build: "Build",
	finishActions: "Finish actions",
	finishCraft: "Finish crafting",
	standAndDeliver: "Stand and Deliver",
	commandWarren: "Command Warren",
	betterBurrowBank: "Better Burrow Bank",
	cobbler: "Cobbler",
	codebreakers: "Codebreakers",
	taxCollector: "Tax Collector",
	royalClaim: "Royal Claim",
	swiftStrike: "Swift Strike",
	boot: "Boot",
	sack: "Bag",
	crossbow: "Crossbow",
	hammer: "Hammer",
	sword: "Sword",
	tea: "Tea",
	coin: "Coin",
	torch: "Torch",
	thief: "Thief",
	tinker: "Tinker",
	ranger: "Ranger",
	vagrant: "Vagrant",
	arbiter: "Arbiter",
	scoundrel: "Scoundrel",
	adventurer: "Adventurer",
	harrier: "Harrier",
	ronin: "Ronin",
	foremole: "Foremole",
	captain: "Captain",
	marshal: "Marshal",
	brigadier: "Brigadier",
	banker: "Banker",
	mayor: "Mayor",
	duchess: "Duchess of Mud",
	baron: "Baron of Dirt",
	earl: "Earl of Stone",
	bomb: "Bomb",
	snare: "Snare",
	extortion: "Extortion",
	raid: "Raid",
	card: "Hand card",
	boats: "Riverboats",
	mercenaries: "Mercenaries",
	birdyBindle: "Birdy Bindle",
	woodlandRunners: "Woodland Runners",
	armsTrader: "Arms Trader",
	knapsack: "Gently Used Knapsack",
	rootTea: "Root Tea",
	travelGear: "Travel Gear",
	protectionRacket: "Protection Racket",
	foxfolkSteel: "Foxfolk Steel",
	anvil: "Anvil",
	smugglersTrail: "Smuggler’s Trail",
	visitFriends: "A Visit to Friends",
	bakeSale: "Bake Sale",
	mouseSack: "Mouse in a Sack",
	investments: "Investments",
	favor: "Favor",
	vizier: "Loyal Vizier",
	fundraising: "Fundraising",
	logistics: "Logistics Help",
	repairShed: "Repair a Shed",
	speech: "Give a Speech",
	errand: "Errand",
	expelBandits: "Expel Bandits",
	fendBear: "Fend off a Bear",
	guardDuty: "Guard Duty",
	escort: "Escort",
	chooseClearing: "Choose clearing {{n}}",
	chooseForest: "Choose forest {{n}}",
	placeBuilding: "Place {{piece}} in {{n}}",
	recruitAt: "Recruit {{count}} warriors in {{n}}",
	setPrice: "Set {{service}} price to {{n}}",
	payOutrage: "Outrage: give {{suit}} {{card}}",
	discardSupporter: "Discard supporter: {{suit}} {{card}}",
	returnFund: "Return one {{faction}} fund",
	loseMinister: "Lose {{minister}}",
	damageItem: "Damage {{item}}",
	enlistArbiter: "Enlist the Arbiter",
	craftCard: "Craft {{suit}} {{card}}",
	craftWith: "Craft {{card}} using {{places}}",
	exportCard: "Export {{card}}",
	coalitionWith: "Form coalition with {{faction}}",
	activateDominance: "Activate {{suit}} dominance",
	takeDominance: "Spend {{card}} for {{suit}} dominance",
	inspectHand: "View {{faction}}’s hand",
	collectTax: "Collect tax in {{n}}",
	clearPath: "Spend {{card}} to clear path {{from}}–{{to}}",
	exposePlot: "Show {{suit}} {{card}}: guess {{plot}} in {{n}}",
	buildAt: "Build {{piece}} in {{n}}: {{cost}} wood, {{vp}} VP",
	overworkAt: "Spend {{card}} to overwork in {{n}}",
	extraAction: "Spend bird {{card}} for one action",
	spendWood: "Spend wood from {{n}}",
	addDecree: "Add {{suit}} {{card}} to {{column}} decree",
	emergencyRoostAt: "Emergency roost in {{n}}",
	fulfillMove: "Resolve {{suit}} move decree",
	fulfillBattle: "Resolve {{suit}} battle decree",
	placeRoost: "Build roost in {{n}}",
	revoltAt: "Revolt in {{n}}",
	finishRevolt: "Finish revolting",
	spreadAt: "Spread to {{n}}: {{cost}} supporters, {{vp}} VP",
	finishSpread: "Finish spreading",
	spendSupporter: "Spend {{suit}} supporter {{card}}",
	organizeAt: "Organize in {{n}}: {{vp}} VP",
	mobilizeCard: "Mobilize {{suit}} {{card}}",
	trainOfficer: "Spend {{suit}} {{card}} to train officer",
	sacrifice: "Reveal bird {{card}} to sacrifice",
	cultScore: "Spend {{suit}} {{card}}: {{vp}} VP",
	ritualRecruit: "Reveal {{card}} to recruit in {{n}}",
	ritualBuild: "Reveal {{card}} to build garden in {{n}}",
	crusadeMove: "Crusade move: {{cost}} acolytes",
	crusadeBattle: "Crusade battle: {{cost}} acolytes",
	convertAt: "Convert {{faction}} warrior in {{n}}: {{cost}} acolytes",
	sanctifyAt: "Sanctify {{piece}} in {{n}}: {{cost}} acolytes",
	finishConspiracies: "Finish conspiracies",
	fundMove: "Commit {{faction}} fund to move",
	fundBattle: "Commit {{faction}} fund to battle",
	fundDraw: "Commit {{faction}} fund to draw",
	fundRecruit: "Spend {{faction}} fund to recruit in {{n}}",
	establishPost: "Spend two {{faction}} funds for trade post in {{n}}",
	duchyBuild: "Reveal {{card}} to build {{piece}} in {{n}}",
	recruitBurrow: "Recruit in the Burrow",
	digAt: "Spend {{card}}, take tunnel from {{from}}, dig in {{n}} with {{count}} warriors",
	ministerMove: "{{minister}}: up to {{count}} moves",
	ministerBattle: "{{minister}}: up to {{count}} battles",
	bankerSuit: "Banker: spend {{suit}} cards",
	ministerScore: "{{minister}}: {{vp}} VP",
	finishParliament: "Finish Parliament",
	bankerSpend: "Spend {{suit}} {{card}} for 1 VP",
	finishBanker: "Finish Banker",
	swayMinister: "Sway {{minister}}: reveal {{cost}} cards, {{vp}} VP",
	finishSway: "Finish swaying",
	revealForSway: "Reveal {{suit}} {{card}} for {{n}}",
	plotAt: "Return {{cost}} warriors to plot {{plot}} in {{n}}",
	trickPlots: "Swap plots in {{from}} and {{to}}",
	flipPlot: "Flip {{plot}} in {{n}}",
	finishFlip: "Finish flipping",
	corvidRecruit: "Spend {{card}} to recruit in all {{suit}} clearings",
	skipRecruit: "Skip recruiting",
	exert: "Exert: one action, no draw",
	skipExert: "Skip exertion",
	slipForest: "Slip into forest {{n}}",
	slipClearing: "Slip into {{n}} with {{count}} {{faction}} warriors",
	vagabondMove: "Exhaust {{cost}} boots to {{n}} with {{count}} {{faction}} warriors",
	battleWithAlly: "Attack {{name}} with {{faction}} ally",
	explore: "Exhaust torch to explore",
	aidFaction: "Exhaust {{item}}, give {{faction}} {{card}}",
	questScore: "Complete {{quest}} ({{items}}): {{vp}} VP",
	questDraw: "Complete {{quest}} ({{items}}): draw 2",
	strikePiece: "Exhaust crossbow to strike {{faction}} {{piece}}",
	repairItem: "Repair {{item}}",
	stealCard: "Exhaust torch to steal from {{faction}}",
	dayLabor: "Exhaust torch for discarded {{suit}} {{card}}",
	hideout: "Exhaust torch: repair up to 3, end Daylight",
	instigate: "Exhaust torch: {{attacker}} attacks {{defender}}",
	scorchedEarth: "Leave torch and scorch this clearing",
	glideTo: "Exhaust torch to glide to {{n}}",
	refreshItem: "Refresh {{item}}",
	finishRefresh: "Finish refreshing",
	skipSlip: "Skip Slip",
	takeRuinItem: "Take ruin {{item}}",
	finishRepair: "Finish repairs",
	takeCraftedItem: "Take {{item}}",
	skipItem: "Take no item",
	discardItem: "Permanently discard {{item}}",
	finishPurchases: "Finish purchases",
	buyCard: "Pay {{cost}} for {{suit}} {{card}}",
	buyBoats: "Pay {{cost}} for Riverboats",
	buyMercenaries: "Pay {{cost}} for Mercenaries",
	claimRule: "Discard Royal Claim: {{vp}} VP",
	shareBank: "Both draw a card with {{faction}}",
	standDeliver: "Steal from {{faction}}; they gain 1 VP",
	discardCard: "Discard {{suit}} {{card}}",
	produceWood: "Produce one wood in {{n}}",
	supporters: "Supporters",
	officers: "Officers",
	decree: "Decree",
	acolytes: "Acolytes",
	outcast: "Outcast",
	hated: "Hated",
	funds: "Funds",
	committed: "Committed",
	payments: "Payments",
	ministers: "Swayed ministers",
	burrow: "Burrow",
	items: "Items",
	relationships: "Relationships",
	quests: "Quests",
	completedQuests: "Completed quests",
	craftedItems: "Crafted items",
	revealed: "Revealed cards",
	exhausted: "Exhausted",
	damaged: "Damaged",
	hostile: "Hostile",
	indifferent: "Indifferent",
	allied: "Allied",
	availableDominance: "Available dominance",
	deck: "Deck",
	lostSouls: "Lost Souls",
	actions: "Actions",
	chooseAction: "Choose an action",
	chooseResponse: "Make your choice",
	allActions: "Available actions",
	filterClearing: "Filter by clearing",
	noChoices: "No actions available",
	mapOption: "Map",
	factionsOption: "Available factions",
	allFactions: "Base + two expansions",
	coreFactions: "Base four factions",
	secondVagabond: "Second Vagabond available",
	supplyPlace: "Supply",
	draft: "Choose faction",
	setupBegin: "Prepare faction",
	setupCorner: "Choose starting corner",
	setupCatBuilding: "Place starting buildings",
	setupLeader: "Choose leader",
	setupOutcast: "Choose Outcast",
	setupRiver: "Place Riverfolk warriors",
	prices: "Set service prices",
	setupCorvid: "Place Corvid warriors",
	setupCharacter: "Choose character",
	setupForest: "Choose starting forest",
	setupFinish: "Finish setup",
	turnStart: "Start turn",
	services: "Buy services",
	birdEffects: "Birdsong effects",
	dayStart: "Start Daylight",
	eveningStart: "Start Evening",
	draw: "Draw",
	discard: "Discard to five",
	capacity: "Check item capacity",
	turnEnd: "End turn",
	decreeAdd: "Add to Decree",
	emergencyRoost: "A New Roost",
	turmoil: "Turmoil",
	allianceRevolt: "Revolt",
	allianceSpread: "Spread Sympathy",
	allianceOps: "Military operations",
	cultConspiracy: "Conspiracies",
	corvidFlip: "Flip plots",
	corvidExert: "Exert",
	vagabondRefresh: "Refresh items",
	vagabondSlip: "Slip",
	duchyParliament: "Parliament",
	duchySway: "Sway ministers",
	swayCards: "Reveal for minister",
	command: "Take action",
	woodPayment: "Pay wood",
	payCards: "Pay supporters",
	chooseItem: "Choose item",
	aidItem: "Take aid item",
	outrage: "Outrage",
	peek: "View hand",
	baseLoss: "Base lost",
	tradeLoss: "Trade disruption",
	failure: "Price of Failure",
	arbiterResponse: "Arbiter protection",
	removeTunnel: "Return tunnel"
}, Qi = {
	definition: br,
	View: zr,
	bot: Mi,
	fx: Wi,
	OverView: Ji,
	Options: Yi,
	locales: {
		zh: {
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			...Xi,
			name: "茂林源记",
			desc: "八大阵营以各自的方式争夺森林，支持本体、河岸和地底扩展。",
			rules: "目标：\n· 率先达到 30 分立即获胜；移除敌方建筑或标记各得一分。\n· 至少 10 分时，可在白天启用支配牌，改用其胜利条件。\n准备：\n· 选择地图与阵营，按提示摆放起始棋件，每人取得三张手牌。\n· 支持本体、河岸扩展和地底扩展，以及九种游侠角色。\n回合：\n· 依次进行清晨、白天、夜晚，按阵营板执行各自流程。\n· 鸟牌通常可代替其他花色；蜥蜴仪式不适用此替代。\n移动与控制：\n· 士兵与建筑最多的阵营控制领地；飞鹰赢得非零平手。\n· 庭院强制控制领地。一般移动须控制起点或终点。\n· 沿道路移动；游侠、阴谋羽党、小舟与商会有特殊移动规则。\n战斗与锻造：\n· 防守方可打出匹配奇袭，进攻方可用匹配奇袭反制。\n· 双骰高点归进攻方；联盟防守时取高点。\n· 掷骰伤害不超过参战士兵或未损坏的剑数量。\n· 双方同时受伤，先移除士兵，再自行选择建筑与标记。\n· 激活匹配花色的锻造棋件支付费用，每件每回合使用一次。\n· 道具数量有限；不能重复锻造同名持续效果。\n猫咪贵族与飞鹰王朝：\n· 猫咪生产木材，白天锻造后执行三行动，可支付鸟牌追加。\n· 行军至多移动两次，招募每回合一次，建造需控制连通木材。\n· 失去士兵后，可支付匹配牌将其放回仍在场的城堡。\n· 飞鹰清晨增加法令，白天锻造后依次履行招募、移动、战斗、建造。\n· 无法履行则动乱：扣除法令鸟牌分数、弃法令并更换领袖。\n森林联盟与蜥蜴神教：\n· 联盟花费支持者传播民意或起义，训练长官以执行夜晚行动。\n· 他人移除民意或移动士兵进入民意领地时，必须平息民愤。\n· 无基地时支持者最多五张；失去基地还会失去匹配支持者和半数长官。\n· 蜥蜴用揭示的手牌建造、招募、献祭，用弃牌仪式得分。\n· 遭弃者由遭弃者牌堆决定；仆从可发动圣战、转化或净化。\n河岸商会与鼹鼠地国：\n· 清晨可用待命士兵购买商会手牌、小舟与佣兵服务。\n· 商会调用资金执行行动，花费资金招募、建立贸易站。\n· 鼹鼠地国白天两次议会前行动，随后使用大臣并说服一名新大臣。\n· 揭示牌夜晚归还，鸟牌须弃置；建筑损失触发失败的代价。\n阴谋羽党与神秘游侠：\n· 阴谋羽党锻造、翻开阴谋、招募后执行三行动，可竭力追加一次。\n· 对手可出示匹配手牌猜测暗阴谋，猜错须交出该牌。\n· 游侠重整道具并潜行，以耗竭道具支付移动、协助、任务等行动。\n· 游侠受伤时损坏道具；在树林中休息可修复受损道具，夜晚检查背包容量。\n· 两名游侠共享任务与遗迹，各自管理道具和关系。\n地图：\n· 冬图河流分隔树林；湖图海岸经湖相连，渡轮每回合一次并抽牌。\n· 山图可在白天支付任意牌清路得一分，夜晚结束控制山口得一分。",
			marquise: "猫咪贵族",
			eyrie: "飞鹰王朝",
			alliance: "森林联盟",
			vagabond: "神秘游侠",
			cult: "蜥蜴神教",
			riverfolk: "河岸商会",
			duchy: "鼹鼠地国",
			corvid: "阴谋羽党",
			fox: "狐狸",
			rabbit: "兔子",
			mouse: "老鼠",
			bird: "鸟类",
			warrior: "士兵",
			sawmill: "锯木厂",
			workshop: "工坊",
			recruiter: "征兵所",
			roost: "鸟巢",
			base: "基地",
			garden: "庭院",
			tradePost: "贸易站",
			citadel: "城堡",
			market: "集市",
			keep: "城堡",
			wood: "木材",
			sympathy: "民意",
			tunnel: "隧道",
			plot: "阴谋",
			armorers: "军械师",
			brutalTactics: "残酷战术",
			sappers: "工兵",
			scoutingParty: "侦察队",
			ambush: "奇袭",
			counter: "反制奇袭",
			hospital: "战地医院",
			item: "道具",
			persistent: "持续效果",
			dominance: "支配",
			autumn: "秋季森林",
			daylight: "白天",
			move: "移动",
			march: "行军",
			battle: "战斗",
			selectOrigin: "选择出发领地",
			selectDestination: "选择目的地",
			selectBattle: "选择战斗领地",
			chooseAmbush: "是否发动奇袭？",
			chooseCounter: "是否抵消奇袭？",
			chooseHospital: "是否将士兵放回城堡？",
			chooseLoss: "选择要移除的建筑或标记",
			chooseEffect: "选择战斗效果",
			chooseOrder: "选择先使用效果的一方",
			rolling: "掷骰",
			resolving: "结算伤害",
			completed: "行动结束",
			victory: "胜利",
			wait: "等待 {{name}}",
			clearing: "{{suit}}领地 {{n}}",
			moveN: "移动 {{n}} 名士兵",
			battleAgainst: "与{{name}}战斗",
			remaining: "还可移动 {{n}} 次",
			cancel: "取消选择",
			pass: "放弃",
			endMarch: "结束行军",
			useCard: "支付此牌",
			playAmbush: "打出奇袭",
			playCounter: "抵消奇袭",
			remove: "移除",
			confirm: "确认",
			hand: "手牌",
			factionBoard: "阵营板",
			close: "关闭",
			inspect: "查看",
			count: "{{n}} 个",
			warriors: "{{n}} 名士兵",
			vp: "{{n}} 分",
			supply: "待命士兵",
			handCount: "手牌 {{n}} 张",
			attacker: "进攻方",
			defender: "防守方",
			damage: "伤害",
			hospitalCount: "{{n}} 名士兵",
			battleAftermath: "奇袭结算",
			battleEffects: "战斗效果",
			battleLosses: "分配损失",
			battleResult: "战斗结算",
			battleResolving: "正在结算",
			battleRemaining: "待分配 {{n}} 点伤害",
			battleAssigned: "已分配 {{n}} 个损失",
			recenter: "回到全景",
			zoomIn: "放大地图",
			zoomOut: "缩小地图",
			board: "森林地图",
			emptySlot: "空建筑槽",
			ruin: "遗迹",
			eventMove: "{{name}}将 {{n}} 名士兵从领地 {{from}} 移至领地 {{to}}。",
			eventBattle: "{{name}}在领地 {{to}} 发起战斗。",
			eventAmbush: "{{name}}发动奇袭。",
			eventCounter: "{{name}}抵消奇袭。",
			eventRoll: "{{name}}掷出战斗骰。",
			eventLoss: "{{name}}在领地 {{to}} 失去 {{n}} 个棋件。",
			eventHospital: "{{name}}将 {{n}} 名士兵放回城堡。",
			eventSkipHospital: "{{name}}放弃战地医院。",
			eventEffect: "{{name}}使用战斗效果。",
			eventComplete: "领地 {{to}} 的战斗结束。",
			ambushText: "防守时造成 2 点立即伤害；进攻方可用匹配的奇袭牌抵消。",
			hospitalText: "支付一张匹配受损领地花色的手牌，将这批士兵放回城堡。",
			armorersText: "弃置此牌，忽略本次战斗承受的全部掷骰伤害。",
			brutalTacticsText: "作为进攻方额外造成 1 点伤害，防守方获得 1 分。",
			sappersText: "作为防守方弃置此牌，额外造成 1 点伤害。",
			scoutingPartyText: "作为进攻方不受奇袭影响。",
			commander: "指挥官",
			despot: "暴君",
			builder: "建造者",
			charismatic: "魅力领袖",
			leader: "领袖",
			invalidAction: "当前无法执行此行动。"
		},
		en: {
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			...Zi,
			name: "Root",
			desc: "Eight asymmetric factions with the base game, Riverfolk and Underworld expansions.",
			rules: "Goal:\n· Reach 30 points to win immediately. Removing enemy buildings or tokens scores one each.\n· At 10 points, activate dominance in Daylight to change your victory condition.\nSetup:\n· Choose map and factions, place starting pieces, and draw three cards each.\n· Includes the base game, Riverfolk, Underworld, and nine Vagabond characters.\nTurns:\n· Resolve Birdsong, Daylight, and Evening following your faction board.\n· Birds are usually wild, except for Cult rituals.\nMovement and rule:\n· Most warriors and buildings rules a clearing. Eyrie wins nonzero ties.\n· Gardens force rule. Normal moves require rule at origin or destination.\n· Move along paths; Vagabond, Corvids, Riverboats, and Riverfolk have exceptions.\nBattle and crafting:\n· Defender may ambush; attacker may foil with a matching ambush.\n· Attacker takes the high die, except when attacking the Alliance.\n· Rolled hits are limited by warriors or undamaged swords.\n· Take hits simultaneously, warriors first, then choose buildings and tokens.\n· Activate matching crafting pieces; each can be used once per turn.\n· Items are limited. Identical persistent effects cannot be crafted twice.\nMarquise and Eyrie:\n· Cats produce wood, craft, then take three actions. Spend birds for extra actions.\n· March moves up to twice, recruit once per turn, and build using connected ruled wood.\n· Spend a matching card to return removed warriors to a surviving Keep.\n· Eyrie adds to Decree, crafts, then resolves recruit, move, battle, and build.\n· Failure causes Turmoil: lose bird-card points, discard Decree, and replace leader.\nAlliance and Cult:\n· Spend supporters to spread sympathy or revolt. Train officers for Evening operations.\n· Enemies removing sympathy or moving warriors into sympathy must pay Outrage.\n· Without bases, keep five supporters. Losing a base loses matching supporters and half officers.\n· Cult reveals cards to build, recruit, or sacrifice, and spends cards to score.\n· Lost Souls determines Outcast; acolytes crusade, convert, or sanctify.\nRiverfolk and Duchy:\n· Buy Riverfolk cards, Riverboats, or Mercenaries with supply warriors in Birdsong.\n· Riverfolk commits funds for actions, and spends funds to recruit or establish trade posts.\n· Duchy takes two Assembly actions, uses Parliament, and may sway one minister.\n· Revealed cards return in Evening; birds are discarded. Lost buildings trigger Price of Failure.\nCorvids and Vagabond:\n· Corvids craft, flip plots, recruit, and take three actions; Exert adds one without drawing.\n· Enemies may show matching cards to guess hidden plots; wrong guesses surrender the card.\n· Vagabond refreshes items and slips, then exhausts items to move, aid, quest, and act.\n· Hits damage items. Forest rest repairs damaged items; check satchel capacity in Evening.\n· Two Vagabonds share quests and ruins, but keep separate items and relationships.\nMaps:\n· Winter rivers divide forests. Lake coasts connect; Ferry moves once per turn and draws.\n· On Mountain, spend a card to clear a path for one point; rule the Pass at turn end for one.",
			marquise: "Marquise de Cat",
			eyrie: "Eyrie Dynasties",
			alliance: "Woodland Alliance",
			vagabond: "Vagabond",
			cult: "Lizard Cult",
			riverfolk: "Riverfolk Company",
			duchy: "Underground Duchy",
			corvid: "Corvid Conspiracy",
			fox: "Fox",
			rabbit: "Rabbit",
			mouse: "Mouse",
			bird: "Bird",
			warrior: "Warrior",
			sawmill: "Sawmill",
			workshop: "Workshop",
			recruiter: "Recruiter",
			roost: "Roost",
			base: "Base",
			garden: "Garden",
			tradePost: "Trade post",
			citadel: "Citadel",
			market: "Market",
			keep: "Keep",
			wood: "Wood",
			sympathy: "Sympathy",
			tunnel: "Tunnel",
			plot: "Plot",
			armorers: "Armorers",
			brutalTactics: "Brutal Tactics",
			sappers: "Sappers",
			scoutingParty: "Scouting Party",
			ambush: "Ambush",
			counter: "Foil ambush",
			hospital: "Field Hospitals",
			item: "Item",
			persistent: "Persistent effect",
			dominance: "Dominance",
			autumn: "Autumn Woodland",
			daylight: "Daylight",
			move: "Move",
			march: "March",
			battle: "Battle",
			selectOrigin: "Choose an origin",
			selectDestination: "Choose a destination",
			selectBattle: "Choose a battle clearing",
			chooseAmbush: "Play an ambush?",
			chooseCounter: "Foil the ambush?",
			chooseHospital: "Return warriors to the keep?",
			chooseLoss: "Choose a building or token to remove",
			chooseEffect: "Choose a battle effect",
			chooseOrder: "Choose who uses effects first",
			rolling: "Roll dice",
			resolving: "Resolve hits",
			completed: "Action complete",
			victory: "Victory",
			wait: "Waiting for {{name}}",
			clearing: "{{suit}} clearing {{n}}",
			moveN: "Move {{n}} warriors",
			battleAgainst: "Battle {{name}}",
			remaining: "{{n}} moves remaining",
			cancel: "Cancel selection",
			pass: "Pass",
			endMarch: "End march",
			useCard: "Spend card",
			playAmbush: "Play ambush",
			playCounter: "Foil ambush",
			remove: "Remove",
			confirm: "Confirm",
			hand: "Hand",
			factionBoard: "Faction board",
			close: "Close",
			inspect: "Inspect",
			count: "{{n}} pieces",
			warriors: "{{n}} warriors",
			vp: "{{n}} points",
			supply: "Warrior supply",
			handCount: "{{n}} cards in hand",
			attacker: "Attacker",
			defender: "Defender",
			damage: "Hits",
			hospitalCount: "{{n}} warriors",
			battleAftermath: "Ambush aftermath",
			battleEffects: "Battle effects",
			battleLosses: "Assign losses",
			battleResult: "Battle result",
			battleResolving: "Resolving",
			battleRemaining: "{{n}} hits to assign",
			battleAssigned: "{{n}} losses assigned",
			recenter: "Show whole map",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			board: "Woodland map",
			emptySlot: "Empty building slot",
			ruin: "Ruin",
			eventMove: "{{name}} moved {{n}} warriors from clearing {{from}} to {{to}}.",
			eventBattle: "{{name}} initiated battle in clearing {{to}}.",
			eventAmbush: "{{name}} played an ambush.",
			eventCounter: "{{name}} foiled the ambush.",
			eventRoll: "{{name}} rolled the battle dice.",
			eventLoss: "{{name}} lost {{n}} pieces in clearing {{to}}.",
			eventHospital: "{{name}} returned {{n}} warriors to the keep.",
			eventSkipHospital: "{{name}} declined Field Hospitals.",
			eventEffect: "{{name}} used a battle effect.",
			eventComplete: "The battle in clearing {{to}} ended.",
			ambushText: "As defender, deal 2 immediate hits. The attacker may foil this with a matching ambush.",
			hospitalText: "Spend a card matching the affected clearing to place these warriors at the keep.",
			armorersText: "Discard this to ignore all rolled hits you take in this battle.",
			brutalTacticsText: "As attacker, deal 1 extra hit. The defender scores 1 point.",
			sappersText: "As defender, discard this to deal 1 extra hit.",
			scoutingPartyText: "As attacker, you are not affected by ambushes.",
			commander: "Commander",
			despot: "Despot",
			builder: "Builder",
			charismatic: "Charismatic",
			leader: "Leader",
			invalidAction: "You cannot take this action now."
		}
	}
};
//#endregion
export { Qi as default };
