import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useMemo as r, useRef as i, useState as a } from "react";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as u } from "@bgparty/sdk/ui/player-strip";
import { gridCell as d } from "@bgparty/sdk/sheet-geometry";
import { SheetText as f, SheetView as p } from "@bgparty/sdk/sheet-view";
import { Fragment as ee, jsx as m, jsxs as h } from "react/jsx-runtime";
import { GameOverScreen as te } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/doppelt-so-clever/meta.ts
var g = {
	id: "doppelt-so-clever",
	tier: "beta",
	mechanics: [
		"roll-and-write",
		"drafting",
		"dice-rolling"
	],
	interactionTags: [],
	nameKey: "games.doppelt-so-clever.name",
	descKey: "games.doppelt-so-clever.desc",
	rulesKey: "games.doppelt-so-clever.rules",
	icon: "🦊",
	iconImg: "games/doppelt-so-clever.webp",
	rulesUrl: {
		en: "https://juegosrollandwrite.com/wp-content/uploads/2019/12/SH_Games_twice_as_clever_rules_for_web_1.pdf",
		de: "https://www.schmidtspiele.de/files/Produkte/4/49357%20-%20Doppelt%20so%20clever/49357_Doppelt_so_clever_DE.pdf"
	},
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2],
	accent: "#ec4899",
	releasedAt: "2026-09-17",
	search: {
		py: "shuang bei cong ming",
		init: "sbcm"
	},
	hotseat: "cover"
}, _ = t.enum([
	"yellow",
	"blue",
	"green",
	"pink",
	"silver",
	"white"
]), v = t.enum([
	"yellow",
	"blue",
	"green",
	"pink",
	"silver"
]), y = t.enum([
	"yellow",
	"blue",
	"green",
	"pink"
]), ne = t.enum([
	"reroll",
	"return",
	"extra"
]), b = t.discriminatedUnion("area", [
	t.object({
		area: t.literal("silver"),
		row: y
	}),
	t.object({
		area: t.literal("yellow"),
		cell: t.int().min(0).max(9)
	}),
	t.object({ area: t.literal("blue") }),
	t.object({ area: t.literal("green") }),
	t.object({ area: t.literal("pink") })
]), x = t.discriminatedUnion("area", [
	t.object({
		area: t.literal("silver"),
		row: y,
		num: t.int().min(1).max(6)
	}),
	t.object({
		area: t.literal("yellow"),
		cell: t.int().min(0).max(9)
	}),
	t.object({
		area: t.literal("blue"),
		value: t.int().min(2).max(12)
	}),
	t.object({
		area: t.literal("green"),
		value: t.int().min(1).max(6)
	}),
	t.object({
		area: t.literal("pink"),
		value: t.int().min(1).max(6)
	})
]), S = t.discriminatedUnion("type", [
	t.object({ type: t.literal("roll") }),
	t.object({ type: t.literal("reroll") }),
	t.object({
		type: t.literal("return"),
		die: _
	}),
	t.object({
		type: t.literal("pick"),
		die: _,
		target: b,
		cascadeRow: y.optional()
	}),
	t.object({ type: t.literal("forfeit") }),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("bonus"),
		color: v,
		target: x
	}),
	t.object({
		type: t.literal("tiePick"),
		die: _
	})
]), C = t.object({
	silver: t.record(y, t.array(t.boolean()).length(6)),
	yellow: t.array(t.int().min(0).max(2)).length(10),
	blue: t.array(t.int().min(0).max(12)).length(12),
	green: t.array(t.int().min(0).max(6)).length(12),
	pink: t.array(t.int().min(0).max(6)).length(12),
	actions: t.record(ne, t.array(t.int().min(0).max(2)).length(6))
}), w = t.object({ color: t.union([v, t.literal("any")]) }), re = t.object({
	players: t.array(t.string()).min(1).max(4),
	active: t.string(),
	phase: t.enum([
		"roundStart",
		"roll",
		"pick",
		"passive",
		"extra",
		"done"
	]),
	round: t.int().min(1).max(6),
	roundsTotal: t.int().min(4).max(6),
	dice: t.record(_, t.int().min(0).max(6)),
	pool: t.array(_),
	platter: t.array(_),
	slots: t.tuple([
		_.nullable(),
		_.nullable(),
		_.nullable()
	]),
	rollCount: t.int().min(0).max(3),
	passivePending: t.array(t.string()),
	extraQueue: t.array(t.string()),
	extraUsed: t.record(t.string(), t.array(_)),
	sheets: t.record(t.string(), C),
	pending: t.record(t.string(), t.array(w)),
	bonusFor: t.string().nullable(),
	soloTie: t.object({
		candidates: t.array(_).min(2),
		need: t.int().min(1)
	}).nullable()
}), T = t.object({}), E = [
	"yellow",
	"blue",
	"green",
	"pink",
	"silver",
	"white"
], D = [
	"yellow",
	"blue",
	"green",
	"pink",
	"silver"
], O = [
	"yellow",
	"blue",
	"green",
	"pink"
], ie = [
	3,
	6,
	1,
	2,
	4,
	3,
	2,
	5,
	5,
	4
], k = [
	[0, 1],
	[0, 3],
	[1, 0],
	[1, 2],
	[2, 1],
	[2, 3],
	[3, 0],
	[3, 2],
	[4, 1],
	[4, 3]
], A = [
	2,
	2,
	2,
	1,
	3,
	3,
	3,
	2,
	3,
	1,
	4,
	1
], ae = [
	1,
	3,
	6,
	10,
	15,
	21,
	28,
	36,
	45,
	55,
	66,
	78
], j = [
	0,
	2,
	4,
	7,
	11,
	16,
	22
], oe = [
	0,
	3,
	10,
	21,
	36,
	55,
	75,
	96,
	118,
	141,
	165
], M = [
	0,
	0,
	2,
	3,
	4,
	5,
	6,
	2,
	3,
	4,
	5,
	6
], N = {
	plus1: {
		kind: "action",
		action: "extra"
	},
	reroll: {
		kind: "action",
		action: "reroll"
	},
	ret: {
		kind: "action",
		action: "return"
	},
	fox: { kind: "fox" },
	y: {
		kind: "bonus",
		color: "yellow"
	},
	b: {
		kind: "bonus",
		color: "blue"
	},
	g: {
		kind: "bonus",
		color: "green"
	},
	p: {
		kind: "bonus",
		color: "pink"
	},
	s: {
		kind: "bonus",
		color: "silver"
	}
}, se = [
	N.plus1,
	N.y,
	N.fox,
	N.b,
	N.g,
	N.p
], ce = [
	N.b,
	N.ret,
	N.y,
	N.g,
	N.p
], le = [
	N.reroll,
	N.plus1,
	N.s,
	N.fox
], ue = [
	null,
	N.ret,
	N.y,
	null,
	N.plus1,
	N.reroll,
	N.p,
	null,
	N.fox,
	N.ret,
	null,
	N.g
], de = [
	null,
	N.reroll,
	null,
	N.b,
	N.ret,
	null,
	N.fox,
	N.s,
	N.plus1,
	null,
	N.p,
	N.y
], fe = [
	null,
	null,
	N.reroll,
	N.ret,
	N.plus1,
	N.g,
	N.y,
	N.fox,
	N.s,
	N.reroll,
	N.b,
	N.y
], pe = {
	reroll: N.fox,
	return: N.p,
	extra: N.s
}, me = [
	{
		kind: "action",
		action: "reroll"
	},
	{
		kind: "action",
		action: "extra"
	},
	{
		kind: "action",
		action: "return"
	},
	{ kind: "any" }
];
function he() {
	return {
		silver: {
			yellow: [
				,
				,
				,
				,
				,
				,
			].fill(!1),
			blue: [
				,
				,
				,
				,
				,
				,
			].fill(!1),
			green: [
				,
				,
				,
				,
				,
				,
			].fill(!1),
			pink: [
				,
				,
				,
				,
				,
				,
			].fill(!1)
		},
		yellow: Array(10).fill(0),
		blue: Array(12).fill(0),
		green: Array(12).fill(0),
		pink: Array(12).fill(0),
		actions: {
			reroll: [
				,
				,
				,
				,
				,
				,
			].fill(0),
			return: [
				,
				,
				,
				,
				,
				,
			].fill(0),
			extra: [
				,
				,
				,
				,
				,
				,
			].fill(0)
		}
	};
}
function P(e) {
	return e.findIndex((e) => e === 0);
}
function F(e, t) {
	let n = P(e.blue);
	return n < 0 || t < 2 || t > 12 ? !1 : n === 0 || t <= e.blue[n - 1];
}
function I(e, t, n) {
	if (ie[t] !== n) return null;
	let r = e.yellow[t];
	return r === 0 ? "circle" : r === 1 ? "cross" : null;
}
function L(e, t, n, r) {
	let i = [], a = t === "white" ? [...D] : t === "silver" ? ["silver"] : t === "blue" ? ["blue"] : [t];
	for (let t of a) if (t === "silver") for (let t of O) e.silver[t][n - 1] || i.push({
		area: "silver",
		row: t
	});
	else if (t === "yellow") for (let t = 0; t < 10; t++) I(e, t, n) && i.push({
		area: "yellow",
		cell: t
	});
	else t === "blue" ? F(e, r) && i.push({ area: "blue" }) : t === "green" ? P(e.green) >= 0 && i.push({ area: "green" }) : P(e.pink) >= 0 && i.push({ area: "pink" });
	return i;
}
function ge(e, t) {
	return e.area === t.area ? e.area === "silver" && t.area === "silver" ? e.row === t.row : e.area === "yellow" && t.area === "yellow" ? e.cell === t.cell : !0 : !1;
}
function R(e, t) {
	return O.every((n) => e.silver[n][t]) ? se[t] : null;
}
function z(e, t) {
	let [n, r] = k[t], i = (t) => k.every((n, r) => !t(n) || e.yellow[r] >= 1), a = [];
	return i((e) => e[0] === n) && a.push(ce[n]), i((e) => e[1] === r) && a.push(le[r]), a;
}
function B(e, t, n) {
	return e === "blue" ? ue[n] : e === "green" ? de[n] : t.pink[n] < M[n] ? null : fe[n];
}
function V(e, t) {
	let n = e.actions[t], r = n.findIndex((e) => e === 0);
	return r < 0 ? null : (n[r] = 1, n.every((e) => e >= 1) ? pe[t] : null);
}
function H(e, t) {
	return e.actions[t].filter((e) => e === 1).length;
}
function U(e, t) {
	let n = e.actions[t].findIndex((e) => e === 1);
	n >= 0 && (e.actions[t][n] = 2);
}
function W(e, t, n) {
	if (t === "any") return D.some((t) => W(e, t, n));
	if (t === "silver") return O.some((t) => e.silver[t].some((e) => !e));
	if (t === "yellow") return e.yellow.some((e) => e === 0 || e === 1);
	if (t === "blue") {
		let t = P(e.blue);
		return t >= 0 && (t === 0 || e.blue[t - 1] >= 2);
	}
	return t === "green" ? P(e.green) >= 0 : P(e.pink) >= 0;
}
function _e(e) {
	let t = O.reduce((t, n) => t + j[e.silver[n].filter(Boolean).length], 0), n = oe[e.yellow.filter((e) => e === 2).length], r = P(e.blue), i = r === 0 ? 0 : ae[(r < 0 ? 12 : r) - 1], a = 0;
	for (let t = 0; t < 6; t++) {
		let n = e.green[t * 2], r = e.green[t * 2 + 1];
		n > 0 && r > 0 && (a += n * A[t * 2] - r * A[t * 2 + 1]);
	}
	let o = e.pink.reduce((e, t) => e + t, 0);
	return {
		silver: t,
		yellow: n,
		blue: i,
		green: a,
		pink: o
	};
}
function ve(e) {
	let t = 0;
	return O.every((t) => e.silver[t][2]) && (t += 1), k.every((t, n) => t[1] !== 3 || e.yellow[n] >= 1) && (t += 1), e.blue[8] > 0 && (t += 1), e.green[6] > 0 && (t += 1), e.pink[7] >= M[7] && (t += 1), e.actions.reroll.every((e) => e >= 1) && (t += 1), t;
}
function G(e) {
	let t = _e(e), n = D.map((e) => t[e]), r = Math.min(...n), i = ve(e), a = r > 0 ? i * r : 0;
	return {
		areas: t,
		foxes: i,
		foxScore: a,
		total: n.reduce((e, t) => e + t, 0) + a,
		bestArea: Math.max(...n)
	};
}
function ye(e) {
	let t = [
		321,
		300,
		280,
		260,
		240,
		220,
		200,
		180,
		160,
		140
	].findIndex((t) => e >= t);
	return t < 0 ? 10 : t;
}
//#endregion
//#region src/games/doppelt-so-clever/rules.ts
var K = {
	over: "games.doppelt-so-clever.errOver",
	notYourTurn: "games.doppelt-so-clever.errNotYourTurn",
	badStage: "games.doppelt-so-clever.errBadStage",
	badTarget: "games.doppelt-so-clever.errBadTarget",
	badDie: "games.doppelt-so-clever.errBadDie",
	noAction: "games.doppelt-so-clever.errNoAction",
	bonusPending: "games.doppelt-so-clever.errBonusPending",
	tiePending: "games.doppelt-so-clever.errTiePending"
};
function be(e) {
	return e === 4 ? 4 : e === 3 ? 5 : 6;
}
function q(e) {
	return e.players.map((t, n) => e.players[(e.activeIdx + n) % e.players.length]);
}
function J(e, t, n) {
	if (n.kind !== "fox") {
		if (n.kind === "action") {
			let r = V(e.sheets[t], n.action);
			r && J(e, t, r);
			return;
		}
		e.pending[t].push({ color: n.color });
	}
}
function xe(e, t) {
	let n = e.sheets[t], r = e.dice.blue + e.dice.white;
	e.pending[t] = e.pending[t].filter((e) => W(n, e.color, r)), e.pending[t].length > 0 && e.bonusFor === null && (e.bonusFor = t);
}
function Se(e, t, n) {
	for (let r of n) r && J(e, t, r);
	xe(e, t);
}
function Y(e) {
	return e.dice.blue + e.dice.white;
}
function Ce(e, t, n, r) {
	let i = e.sheets[t];
	if (n.area === "silver") return i.silver[n.row][r - 1] = !0, [R(i, r - 1)];
	if (n.area === "yellow") return I(i, n.cell, r) === "circle" ? (i.yellow[n.cell] = 1, z(i, n.cell)) : (i.yellow[n.cell] = 2, []);
	if (n.area === "blue") {
		let e = P(i.blue);
		return i.blue[e] = r, [B("blue", i, e)];
	}
	if (n.area === "green") {
		let e = P(i.green);
		return i.green[e] = r, [B("green", i, e)];
	}
	let a = P(i.pink);
	return i.pink[a] = r, [B("pink", i, a)];
}
function we(e) {
	if (e.players.length === 1) {
		e.pool = [...E], Oe(e), e.slots = [
			null,
			null,
			null
		], e.platter = [], e.extraUsed = {};
		let t = E.map((t) => ({
			c: t,
			v: e.dice[t]
		})).sort((e, t) => e.v - t.v), n = t[2].v, r = 3;
		for (let { c: i, v: a } of t) a < n && (e.platter.push(i), --r);
		let i = t.filter((e) => e.v === n).map((e) => e.c);
		r > 0 && i.length === r && (e.platter.push(...i), r = 0), e.soloTie = r > 0 ? {
			candidates: i,
			need: r
		} : null, e.pool = e.pool.filter((t) => !e.platter.includes(t)), e.passivePending = [...e.players], e.phase = "passive";
		return;
	}
	e.platter.push(...e.pool), e.pool = [], e.passivePending = e.players.filter((t) => t !== e.players[e.activeIdx]), e.phase = "passive";
}
function Te(e) {
	if (e.extraQueue = q(e).filter((t) => H(e.sheets[t], "extra") > 0), e.extraQueue.length === 0) {
		X(e);
		return;
	}
	e.phase = "extra";
}
function X(e) {
	if (e.activeIdx = (e.activeIdx + 1) % e.players.length, e.activeIdx === e.firstIdx && (e.round += 1), e.round > e.roundsTotal) {
		e.phase = "done";
		return;
	}
	e.pool = [...E], e.platter = [], e.slots = [
		null,
		null,
		null
	], e.rollCount = 0, e.dice = {
		yellow: 0,
		blue: 0,
		green: 0,
		pink: 0,
		silver: 0,
		white: 0
	}, e.extraUsed = {}, e.passivePending = [], e.extraQueue = [], e.activeIdx === e.firstIdx && Ee(e), q(e).some((t) => e.pending[t].length > 0) ? (e.phase = "roundStart", e.bonusFor = q(e).find((t) => e.pending[t].length > 0) ?? null) : e.phase = "roll";
}
function Ee(e) {
	let t = me[e.round - 1];
	if (t) for (let n of e.players) {
		if (t.kind === "action") {
			let r = V(e.sheets[n], t.action);
			r && J(e, n, r);
		} else e.pending[n].push({ color: "any" });
		xe(e, n);
	}
}
function De(e, t) {
	if (xe(e, t), !(e.pending[t].length > 0)) {
		if (e.bonusFor = null, e.phase === "roundStart") {
			let t = q(e).find((t) => e.pending[t].length > 0);
			t ? e.bonusFor = t : e.phase = "roll";
			return;
		}
		e.phase === "passive" && e.passivePending.length === 0 && Te(e);
	}
}
function Oe(t) {
	for (let n of E) t.pool.includes(n) && (t.dice[n] = e(t.seed, t.rngCursor, 6) + 1, t.rngCursor += 1);
}
function ke(t, n, r) {
	let i = {}, a = {};
	for (let e of n) i[e] = he(), a[e] = [];
	let o = {
		players: n,
		firstIdx: e(r, 0, n.length),
		activeIdx: 0,
		round: 1,
		roundsTotal: be(n.length),
		phase: "roll",
		dice: {
			yellow: 0,
			blue: 0,
			green: 0,
			pink: 0,
			silver: 0,
			white: 0
		},
		pool: [...E],
		platter: [],
		slots: [
			null,
			null,
			null
		],
		rollCount: 0,
		passivePending: [],
		extraQueue: [],
		extraUsed: {},
		sheets: i,
		pending: a,
		bonusFor: null,
		soloTie: null,
		seed: r,
		rngCursor: 1
	};
	return o.activeIdx = o.firstIdx, Ee(o), {
		state: o,
		fx: []
	};
}
function Ae(e, t) {
	let n = e.sheets[t], r = e.platter.filter((t) => L(n, t, e.dice[t], Y(e)).length > 0);
	return r.length > 0 ? r : e.slots.filter((t) => t !== null && L(n, t, e.dice[t], Y(e)).length > 0);
}
function je(e, t, n, r) {
	let i = e.sheets[t], a = /* @__PURE__ */ new Map();
	for (let t of E) !n.includes(t) || t !== "white" && t !== "silver" || a.set(t, O.filter((n) => !i.silver[n][e.dice[t] - 1]));
	let o = [];
	for (let t of E) {
		if (!n.includes(t)) continue;
		let s = e.dice[t];
		if (t === "white" || t === "silver") {
			let e = a.get(t) ?? [];
			if (e.length === 0) continue;
			if (!r || !e.includes(r)) return { code: K.badTarget };
			if (i.silver[r][s - 1]) continue;
			i.silver[r][s - 1] = !0, o.push(R(i, s - 1));
			continue;
		}
		i.silver[t][s - 1] || (i.silver[t][s - 1] = !0, o.push(R(i, s - 1)));
	}
	return { rewards: o };
}
function Me(e, t, n) {
	if (e.phase === "done") return { code: K.over };
	if (e.bonusFor !== null && t.type !== "bonus") return { code: K.bonusPending };
	if (e.soloTie !== null && t.type !== "tiePick" && t.type !== "bonus") return { code: K.tiePending };
	if (t.type === "tiePick") {
		let r = e.soloTie;
		if (e.phase !== "passive" || e.players.length !== 1 || !r || n.by !== e.players[e.activeIdx]) return { code: K.notYourTurn };
		if (!r.candidates.includes(t.die)) return { code: K.badDie };
		let i = structuredClone(e), a = i.soloTie;
		return i.platter.push(t.die), i.pool = i.pool.filter((e) => e !== t.die), a.candidates = a.candidates.filter((e) => e !== t.die), --a.need, a.need <= 0 && (i.soloTie = null), {
			state: i,
			fx: []
		};
	}
	if (t.type === "bonus") {
		if (e.bonusFor !== n.by) return { code: K.notYourTurn };
		let r = structuredClone(e), i = r.sheets[n.by], a = r.pending[n.by], o = a.findIndex((e) => e.color === t.color);
		if (o < 0 && (o = a.findIndex((e) => e.color === "any")), o < 0) return { code: K.badTarget };
		let s = t.target;
		if (s.area !== t.color) return { code: K.badTarget };
		let c;
		if (s.area === "silver") {
			if (i.silver[s.row][s.num - 1]) return { code: K.badTarget };
			i.silver[s.row][s.num - 1] = !0, c = [R(i, s.num - 1)];
		} else if (s.area === "yellow") {
			let e = i.yellow[s.cell];
			if (e === 0) i.yellow[s.cell] = 1, c = z(i, s.cell);
			else if (e === 1) i.yellow[s.cell] = 2, c = [];
			else return { code: K.badTarget };
		} else if (s.area === "blue") {
			if (!F(i, s.value)) return { code: K.badTarget };
			let e = P(i.blue);
			i.blue[e] = s.value, c = [B("blue", i, e)];
		} else if (s.area === "green") {
			let e = P(i.green);
			if (e < 0) return { code: K.badTarget };
			i.green[e] = s.value, c = [B("green", i, e)];
		} else {
			let e = P(i.pink);
			if (e < 0) return { code: K.badTarget };
			i.pink[e] = s.value, c = [B("pink", i, e)];
		}
		a.splice(o, 1);
		for (let e of c) e && J(r, n.by, e);
		return De(r, n.by), {
			state: r,
			fx: []
		};
	}
	if (t.type === "roll") {
		if (e.phase !== "roll" || n.by !== e.players[e.activeIdx]) return { code: K.notYourTurn };
		let t = structuredClone(e);
		return Oe(t), t.rollCount += 1, t.phase = "pick", {
			state: t,
			fx: []
		};
	}
	if (t.type === "return") {
		if (e.phase !== "roll" || n.by !== e.players[e.activeIdx]) return { code: K.notYourTurn };
		if (!e.platter.includes(t.die)) return { code: K.badDie };
		if (H(e.sheets[n.by], "return") === 0) return { code: K.noAction };
		let r = structuredClone(e);
		return U(r.sheets[n.by], "return"), r.platter.splice(r.platter.indexOf(t.die), 1), r.pool.push(t.die), {
			state: r,
			fx: []
		};
	}
	if (t.type === "reroll") {
		if (e.phase !== "pick" || n.by !== e.players[e.activeIdx]) return { code: K.notYourTurn };
		if (H(e.sheets[n.by], "reroll") === 0) return { code: K.noAction };
		let t = structuredClone(e);
		return U(t.sheets[n.by], "reroll"), Oe(t), {
			state: t,
			fx: []
		};
	}
	if (t.type === "forfeit") {
		if (e.phase !== "pick" || n.by !== e.players[e.activeIdx]) return { code: K.notYourTurn };
		let t = structuredClone(e);
		return t.rollCount >= 3 ? we(t) : t.phase = "roll", {
			state: t,
			fx: []
		};
	}
	if (t.type === "pass") {
		let t = structuredClone(e);
		return t.phase === "passive" && t.passivePending.includes(n.by) ? (t.passivePending = t.passivePending.filter((e) => e !== n.by), t.passivePending.length === 0 && Te(t), {
			state: t,
			fx: []
		}) : t.phase === "extra" && t.extraQueue[0] === n.by ? (t.extraQueue.shift(), t.extraQueue.length === 0 && X(t), {
			state: t,
			fx: []
		}) : { code: K.notYourTurn };
	}
	if (t.type === "pick") {
		let r = structuredClone(e), i = r.sheets[n.by], a = r.players[r.activeIdx];
		if (!L(i, t.die, r.dice[t.die], Y(r)).some((e) => ge(e, t.target))) return { code: K.badTarget };
		if (r.phase === "pick" && n.by === a) {
			if (!r.pool.includes(t.die)) return { code: K.badDie };
			let e = r.dice[t.die], i = Ce(r, n.by, t.target, t.target.area === "blue" ? Y(r) : e);
			r.pool = r.pool.filter((e) => e !== t.die), r.slots[r.rollCount - 1] = t.die;
			let a = r.pool.filter((t) => r.dice[t] < e);
			if (r.pool = r.pool.filter((t) => r.dice[t] >= e), r.platter.push(...a), t.target.area === "silver") {
				let e = je(r, n.by, a, t.cascadeRow);
				if ("code" in e) return e;
				i.push(...e.rewards);
			} else if (t.cascadeRow !== void 0) return { code: K.badTarget };
			return Se(r, n.by, i), r.pool.length === 0 || r.rollCount >= 3 ? we(r) : r.phase = "roll", {
				state: r,
				fx: []
			};
		}
		if (r.phase === "passive" && r.passivePending.includes(n.by)) {
			if (t.cascadeRow !== void 0) return { code: K.badTarget };
			if (!Ae(r, n.by).includes(t.die)) return { code: K.badDie };
			let e = Ce(r, n.by, t.target, t.target.area === "blue" ? Y(r) : r.dice[t.die]);
			return Se(r, n.by, e), r.passivePending = r.passivePending.filter((e) => e !== n.by), r.passivePending.length === 0 && r.bonusFor === null && Te(r), {
				state: r,
				fx: []
			};
		}
		if (r.phase === "extra" && r.extraQueue[0] === n.by) {
			if (t.cascadeRow !== void 0) return { code: K.badTarget };
			if (H(i, "extra") === 0) return { code: K.noAction };
			if ((r.extraUsed[n.by] ?? []).includes(t.die)) return { code: K.badDie };
			U(i, "extra"), r.extraUsed[n.by] = [...r.extraUsed[n.by] ?? [], t.die];
			let e = Ce(r, n.by, t.target, t.target.area === "blue" ? Y(r) : r.dice[t.die]);
			return Se(r, n.by, e), (H(i, "extra") === 0 || r.extraUsed[n.by].length >= E.length) && (r.extraQueue.shift(), r.extraQueue.length === 0 && X(r)), {
				state: r,
				fx: []
			};
		}
		return { code: K.notYourTurn };
	}
	return { code: K.badStage };
}
function Ne(e) {
	return {
		public: {
			players: [...e.players],
			active: e.players[e.activeIdx],
			phase: e.phase,
			round: e.round,
			roundsTotal: e.roundsTotal,
			dice: { ...e.dice },
			pool: [...e.pool],
			platter: [...e.platter],
			slots: [...e.slots],
			rollCount: e.rollCount,
			passivePending: [...e.passivePending],
			extraQueue: [...e.extraQueue],
			extraUsed: Object.fromEntries(Object.entries(e.extraUsed).map(([e, t]) => [e, [...t]])),
			sheets: e.sheets,
			pending: Object.fromEntries(Object.entries(e.pending).map(([e, t]) => [e, t.map((e) => ({ ...e }))])),
			bonusFor: e.bonusFor,
			soloTie: e.soloTie ? {
				candidates: [...e.soloTie.candidates],
				need: e.soloTie.need
			} : null
		},
		private: {}
	};
}
function Pe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {}, n = {};
	for (let r of e.players) {
		let i = G(e.sheets[r]);
		t[r] = i.total, n[r] = i.bestArea;
	}
	let r = [...e.players].sort((r, i) => t[i] - t[r] || n[i] - n[r] || e.players.indexOf(r) - e.players.indexOf(i)), i = r[0];
	return {
		phase: "done",
		winner: r.filter((e) => t[e] === t[i] && n[e] === n[i]),
		ranking: r,
		scores: t
	};
}
var Fe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: g,
	schemas: {
		action: S,
		publicView: re,
		privateView: T
	},
	setup: ke,
	reduce: Me,
	viewFor: Ne,
	status: Pe
}, Ie = 1060, Le = [
	{
		x: 29,
		y: 21,
		w: 110,
		h: 110
	},
	{
		x: 29,
		y: 140,
		w: 110,
		h: 110
	},
	{
		x: 29,
		y: 261,
		w: 110,
		h: 110
	}
], Re = {
	x: 182,
	y: 23,
	w: 83,
	h: 113,
	pitch: 94,
	count: 6
}, ze = {
	reroll: {
		x: 262,
		y: 164,
		w: 54,
		h: 40,
		pitch: 79.9,
		count: 6
	},
	return: {
		x: 262,
		y: 238,
		w: 54,
		h: 40,
		pitch: 79.9,
		count: 6
	},
	extra: {
		x: 262,
		y: 313,
		w: 54,
		h: 40,
		pitch: 79.9,
		count: 6
	}
}, Be = {
	yellow: {
		x: 18,
		y: 463,
		w: 49,
		h: 48,
		pitch: 56.4,
		count: 6
	},
	blue: {
		x: 18,
		y: 516.5,
		w: 49,
		h: 48,
		pitch: 56.4,
		count: 6
	},
	green: {
		x: 18,
		y: 570,
		w: 49,
		h: 48,
		pitch: 56.4,
		count: 6
	},
	pink: {
		x: 18,
		y: 623.5,
		w: 49,
		h: 48,
		pitch: 56.4,
		count: 6
	}
}, Ve = 415, He = 448, Ue = 59.7, We = 39, Ge = 62, Ke = 63;
function qe(e, t) {
	return {
		x: Ve + t * Ue,
		y: He + e * We,
		w: Ge,
		h: Ke
	};
}
var Je = {
	x: 62,
	y: 776,
	w: 46,
	h: 46,
	pitch: 54.5,
	count: 12
}, Ye = {
	x: 63,
	y: 885,
	w: 48,
	h: 45,
	pitch: 54.2,
	count: 12
}, Xe = {
	x: 65,
	y: 985,
	w: 48,
	h: 45,
	pitch: 54,
	count: 12
};
//#endregion
//#region src/games/doppelt-so-clever/sheet-view.tsx
function Ze(e) {
	return e.kind === "silver" ? `s:${e.row}:${e.num}` : `${e.kind[0]}:${e.cell}`;
}
function Qe(e) {
	return e.kind === "silver" ? d(Be[e.row], e.num - 1) : e.kind === "yellow" ? qe(k[e.cell][0], k[e.cell][1]) : e.kind === "blue" ? d(Je, e.cell) : e.kind === "green" ? d(Ye, e.cell) : d(Xe, e.cell);
}
var $e = {
	yellow: "#f5c518",
	blue: "#2e5ec0",
	green: "#3aa655",
	pink: "#e86a9a",
	silver: "#9aa0a6",
	white: "#ffffff"
}, et = {
	1: [[.5, .5]],
	2: [[.28, .28], [.72, .72]],
	3: [
		[.25, .25],
		[.5, .5],
		[.75, .75]
	],
	4: [
		[.28, .28],
		[.72, .28],
		[.28, .72],
		[.72, .72]
	],
	5: [
		[.25, .25],
		[.75, .25],
		[.5, .5],
		[.25, .75],
		[.75, .75]
	],
	6: [
		[.3, .25],
		[.7, .25],
		[.3, .5],
		[.7, .5],
		[.3, .75],
		[.7, .75]
	]
};
function tt({ x: e, y: t, size: n, color: r, value: i }) {
	let a = r === "white" || r === "yellow" || r === "silver" ? "var(--color-ink)" : "#ffffff";
	return /* @__PURE__ */ h("g", {
		pointerEvents: "none",
		children: [/* @__PURE__ */ m("rect", {
			x: e,
			y: t,
			width: n,
			height: n,
			rx: n * .2,
			fill: $e[r],
			stroke: "var(--color-ink)",
			strokeWidth: n * .05
		}), i > 0 && et[i].map(([r, i], o) => /* @__PURE__ */ m("circle", {
			cx: e + r * n,
			cy: t + i * n,
			r: n * .095,
			fill: a
		}, o))]
	});
}
function Z({ r: e, pad: t = .2 }) {
	let n = e.w * t, r = e.h * t;
	return /* @__PURE__ */ h("g", {
		stroke: "var(--color-ink)",
		strokeWidth: Math.min(e.w, e.h) * .16,
		strokeLinecap: "round",
		pointerEvents: "none",
		children: [/* @__PURE__ */ m("line", {
			x1: e.x + n,
			y1: e.y + r,
			x2: e.x + e.w - n,
			y2: e.y + e.h - r
		}), /* @__PURE__ */ m("line", {
			x1: e.x + e.w - n,
			y1: e.y + r,
			x2: e.x + n,
			y2: e.y + e.h - r
		})]
	});
}
function nt({ r: e }) {
	return /* @__PURE__ */ m("ellipse", {
		cx: e.x + e.w / 2,
		cy: e.y + e.h / 2,
		rx: e.w * .38,
		ry: e.h * .38,
		fill: "none",
		stroke: "var(--color-ink)",
		strokeWidth: Math.min(e.w, e.h) * .14,
		strokeLinecap: "round",
		pointerEvents: "none"
	});
}
function rt({ sheet: e, round: t, slots: n, dice: i, eligible: a, onTapCell: o, readOnly: s, fitKey: c }) {
	let l = r(() => a?.map((e) => ({
		key: Ze(e),
		rect: Qe(e)
	})), [a]), u = r(() => new Map(a?.map((e) => [Ze(e), e])), [a]);
	return /* @__PURE__ */ h(p, {
		image: "games/doppelt-so-clever/sheet.webp",
		sheetW: 760,
		sheetH: Ie,
		eligible: l,
		onTapEligible: o ? (e) => {
			let t = u.get(e);
			t && o(t);
		} : void 0,
		readOnly: s,
		fitKey: c,
		children: [
			d(Re, 0) && Array.from({ length: Math.min(t, Re.count) }, (e, t) => /* @__PURE__ */ m(Z, {
				r: d(Re, t),
				pad: .26
			}, `rd${t}`)),
			O.map((t) => e.silver[t].map((e, n) => e ? /* @__PURE__ */ m(Z, {
				r: d(Be[t], n),
				pad: .22
			}, `s${t}${n}`) : null)),
			e.yellow.map((e, t) => {
				if (e === 0) return null;
				let n = qe(k[t][0], k[t][1]);
				return e === 1 ? /* @__PURE__ */ m(nt, { r: n }, `y${t}`) : /* @__PURE__ */ m(Z, {
					r: n,
					pad: .22
				}, `y${t}`);
			}),
			e.blue.map((e, t) => e > 0 ? /* @__PURE__ */ m(f, {
				r: d(Je, t),
				text: String(e)
			}, `b${t}`) : null),
			e.green.map((e, t) => e > 0 ? /* @__PURE__ */ m(f, {
				r: d(Ye, t),
				text: String(e * A[t])
			}, `g${t}`) : null),
			e.pink.map((e, t) => e > 0 ? /* @__PURE__ */ m(f, {
				r: d(Xe, t),
				text: String(e)
			}, `p${t}`) : null),
			Object.keys(ze).map((t) => e.actions[t].map((e, n) => {
				if (e === 0) return null;
				let r = d(ze[t], n);
				return e === 1 ? /* @__PURE__ */ m(nt, { r }, `a${t}${n}`) : /* @__PURE__ */ m(Z, {
					r,
					pad: .24
				}, `a${t}${n}`);
			})),
			n.map((e, t) => {
				if (!e) return null;
				let n = Le[t];
				return /* @__PURE__ */ m(tt, {
					x: n.x + 5,
					y: n.y + 5,
					size: n.w - 10,
					color: e,
					value: i[e]
				}, `slot${t}`);
			})
		]
	});
}
//#endregion
//#region src/games/doppelt-so-clever/view-player.tsx
function it() {
	let e = i(null), [t, r] = a("");
	return n(() => {
		let t = e.current;
		if (!t) return;
		let n = !0, i = new ResizeObserver(([e]) => {
			let t = Math.round(e.contentRect.width), i = Math.round(e.contentRect.height);
			if (!t || !i) return;
			let a = `${t}x${i}`;
			queueMicrotask(() => {
				n && r((e) => e === a ? e : a);
			});
		});
		return i.observe(t), () => {
			n = !1, i.disconnect();
		};
	}, []), [e, t];
}
var at = {
	yellow: "games.doppelt-so-clever.die.yellow",
	blue: "games.doppelt-so-clever.die.blue",
	green: "games.doppelt-so-clever.die.green",
	pink: "games.doppelt-so-clever.die.pink",
	silver: "games.doppelt-so-clever.die.silver",
	white: "games.doppelt-so-clever.die.white"
}, ot = {
	yellow: "games.doppelt-so-clever.area.yellow",
	blue: "games.doppelt-so-clever.area.blue",
	green: "games.doppelt-so-clever.area.green",
	pink: "games.doppelt-so-clever.area.pink",
	silver: "games.doppelt-so-clever.area.silver"
}, st = {
	1: [[.5, .5]],
	2: [[.28, .28], [.72, .72]],
	3: [
		[.25, .25],
		[.5, .5],
		[.75, .75]
	],
	4: [
		[.28, .28],
		[.72, .28],
		[.28, .72],
		[.72, .72]
	],
	5: [
		[.25, .25],
		[.75, .25],
		[.5, .5],
		[.25, .75],
		[.75, .75]
	],
	6: [
		[.3, .25],
		[.7, .25],
		[.3, .5],
		[.7, .5],
		[.3, .75],
		[.7, .75]
	]
};
function Q({ color: e, value: t, selected: n, disabled: r, dim: i, onTap: a, label: o }) {
	let s = e === "white" || e === "yellow" || e === "silver" ? "var(--color-ink)" : "#ffffff", c = /* @__PURE__ */ h("svg", {
		viewBox: "0 0 48 48",
		role: "img",
		className: "dsc-die",
		children: [
			/* @__PURE__ */ m("rect", {
				x: 2,
				y: 2,
				width: 44,
				height: 44,
				rx: 10,
				fill: $e[e],
				stroke: "var(--color-ink)",
				strokeWidth: 2.5
			}),
			t > 0 && st[t].map(([e, t], n) => /* @__PURE__ */ m("circle", {
				cx: e * 48,
				cy: t * 48,
				r: 4.6,
				fill: s
			}, n)),
			t === 0 && /* @__PURE__ */ m("circle", {
				cx: 24,
				cy: 24,
				r: 5,
				fill: s,
				opacity: .35
			})
		]
	});
	return a ? /* @__PURE__ */ m("button", {
		type: "button",
		"aria-label": o,
		disabled: r,
		onClick: a,
		className: `shrink-0 rounded-xl transition-transform ${n ? "ring-4 ring-sky-400 scale-110" : ""} ${i ? "opacity-35" : ""} cursor-pointer`,
		children: c
	}) : /* @__PURE__ */ m("span", {
		className: `shrink-0 ${i ? "opacity-35" : ""}`,
		"aria-hidden": !0,
		children: c
	});
}
function ct(e) {
	let t = e.public;
	return /* @__PURE__ */ m(lt, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function lt({ pub: e, members: t, myRid: n, send: i }) {
	let o = s(), [d, f] = it(), [p, te] = a(n), [_, v] = a(null), y = e.sheets[n], ne = e.sheets[p] ?? y, b = e.active === n, x = (e) => t.find((t) => t.rid === e)?.name ?? e, S = e.dice.blue + e.dice.white, C = e.bonusFor !== null && e.bonusFor !== n, w = r(() => {
		if (!y || C || e.bonusFor === n || e.soloTie !== null) return [];
		if (e.phase === "pick" && b) return e.pool.map((e) => ({
			die: e,
			source: "pool"
		}));
		if (e.phase === "passive" && e.passivePending.includes(n)) {
			let t = e.platter.filter((t) => L(y, t, e.dice[t], S).length > 0);
			return (t.length > 0 ? t : e.slots.filter((t) => t !== null && L(y, t, e.dice[t], S).length > 0)).map((e) => ({
				die: e,
				source: "platter"
			}));
		}
		if (e.phase === "extra" && e.extraQueue[0] === n && H(y, "extra") > 0) {
			let t = e.extraUsed[n] ?? [];
			return E.filter((e) => !t.includes(e)).map((e) => ({
				die: e,
				source: "extra"
			}));
		}
		return [];
	}, [
		y,
		C,
		e,
		n,
		b,
		S
	]), re = e.pending[n] ?? [], T = r(() => {
		if (!y || p !== n) return [];
		if (_?.mode === "pick") {
			let t = e.dice[_.die];
			return L(y, _.die, t, S).map((e) => e.area === "silver" ? {
				ref: {
					kind: "silver",
					row: e.row,
					num: t
				},
				target: e
			} : e.area === "yellow" ? {
				ref: {
					kind: "yellow",
					cell: e.cell
				},
				target: e
			} : e.area === "blue" ? {
				ref: {
					kind: "blue",
					cell: P(y.blue)
				},
				target: e
			} : e.area === "green" ? {
				ref: {
					kind: "green",
					cell: P(y.green)
				},
				target: e
			} : {
				ref: {
					kind: "pink",
					cell: P(y.pink)
				},
				target: e
			});
		}
		if (_?.mode === "cascade") {
			let t = e.dice[_.cascadeDie];
			return O.filter((e) => !y.silver[e][t - 1]).map((e) => ({ ref: {
				kind: "silver",
				row: e,
				num: t
			} }));
		}
		if (_?.mode === "bonus" && e.bonusFor === n) {
			if (_.color === "silver") return O.flatMap((e) => y.silver[e].flatMap((t, n) => t ? [] : [{ ref: {
				kind: "silver",
				row: e,
				num: n + 1
			} }]));
			if (_.color === "yellow") return y.yellow.flatMap((e, t) => e <= 1 ? [{ ref: {
				kind: "yellow",
				cell: t
			} }] : []);
			let e = P(_.color === "blue" ? y.blue : _.color === "green" ? y.green : y.pink);
			return e < 0 ? [] : [{ ref: {
				kind: _.color,
				cell: e
			} }];
		}
		return [];
	}, [
		y,
		p,
		n,
		_,
		e.dice,
		e.bonusFor,
		S
	]), ie = (t, n) => {
		if (_?.mode !== "pick" || e.phase !== "pick" || !b || n.area !== "silver") return null;
		let r = e.dice[t], i = e.pool.filter((n) => n !== t && e.dice[n] < r).find((e) => e === "white" || e === "silver");
		if (!i) return null;
		let a = e.dice[i];
		return O.some((e) => !y.silver[e][a - 1]) ? i : null;
	}, k = (e, t, n) => {
		i({
			type: "pick",
			die: e,
			target: t,
			cascadeRow: n
		}), v(null);
	}, A = (t) => {
		if (y && p === n) {
			if (_?.mode === "pick") {
				let e = T.find((e) => e.target && e.ref.kind === t.kind && JSON.stringify(e.ref) === JSON.stringify(t));
				if (!e?.target) return;
				let n = ie(_.die, e.target);
				if (n) {
					v({
						mode: "cascade",
						die: _.die,
						target: e.target,
						cascadeDie: n
					});
					return;
				}
				k(_.die, e.target);
				return;
			}
			if (_?.mode === "cascade" && t.kind === "silver") {
				k(_.die, _.target, t.row);
				return;
			}
			_?.mode === "bonus" && e.bonusFor === n && (_.color === "silver" && t.kind === "silver" ? (i({
				type: "bonus",
				color: "silver",
				target: {
					area: "silver",
					row: t.row,
					num: t.num
				}
			}), v(null)) : _.color === "yellow" && t.kind === "yellow" && (i({
				type: "bonus",
				color: "yellow",
				target: {
					area: "yellow",
					cell: t.cell
				}
			}), v(null)));
		}
	}, ae = (e) => {
		_?.mode === "bonus" && (_.color === "blue" ? i({
			type: "bonus",
			color: "blue",
			target: {
				area: "blue",
				value: e
			}
		}) : _.color === "green" ? i({
			type: "bonus",
			color: "green",
			target: {
				area: "green",
				value: e
			}
		}) : _.color === "pink" && i({
			type: "bonus",
			color: "pink",
			target: {
				area: "pink",
				value: e
			}
		}), v(null));
	}, j = e.bonusFor ? e.bonusFor === n ? {
		tone: "accent",
		text: o("games.doppelt-so-clever.bonusPrompt")
	} : {
		tone: "info",
		text: o("games.doppelt-so-clever.waitingBonus", { name: x(e.bonusFor) })
	} : e.phase === "roundStart" ? {
		tone: "info",
		text: o("games.doppelt-so-clever.roundStart")
	} : e.phase === "roll" ? b ? {
		tone: "accent",
		text: o("games.doppelt-so-clever.rollPrompt")
	} : {
		tone: "info",
		text: o("games.doppelt-so-clever.waitingRoll", { name: x(e.active) })
	} : e.phase === "pick" ? b ? {
		tone: "accent",
		text: o("games.doppelt-so-clever.pickPrompt")
	} : {
		tone: "info",
		text: o("games.doppelt-so-clever.waitingPick", { name: x(e.active) })
	} : e.phase === "passive" ? e.soloTie ? {
		tone: "accent",
		text: o("games.doppelt-so-clever.tiePrompt", { n: e.soloTie.need })
	} : e.passivePending.includes(n) ? {
		tone: "accent",
		text: o("games.doppelt-so-clever.passivePrompt")
	} : {
		tone: "info",
		text: o("games.doppelt-so-clever.waitingPassive")
	} : e.phase === "extra" ? e.extraQueue[0] === n ? {
		tone: "accent",
		text: o("games.doppelt-so-clever.extraPrompt")
	} : {
		tone: "info",
		text: o("games.doppelt-so-clever.waitingExtra", { name: x(e.extraQueue[0] ?? e.active) })
	} : {
		tone: "info",
		text: ""
	}, oe = (() => {
		if (_?.mode !== "bonus" || e.bonusFor !== n) return [];
		if (_.color === "blue") {
			let e = [];
			for (let t = 2; t <= 12; t++) F(y, t) && e.push(t);
			return e;
		}
		return _.color === "green" || _.color === "pink" ? [
			1,
			2,
			3,
			4,
			5,
			6
		] : [];
	})(), M = e.phase === "pick" && b && !C && e.bonusFor === null && H(y, "reroll") > 0, N = e.phase === "roll" && b && !C && e.platter.length > 0 && H(y, "return") > 0;
	return /* @__PURE__ */ m(c, {
		adaptive: !0,
		scroll: !1,
		className: "dsc-screen",
		children: /* @__PURE__ */ h("div", {
			className: "dsc-table",
			children: [/* @__PURE__ */ m("div", {
				ref: d,
				className: "frame dsc-paper",
				children: /* @__PURE__ */ m(rt, {
					sheet: ne,
					round: e.round,
					slots: e.phase === "done" ? [
						null,
						null,
						null
					] : e.slots,
					dice: e.dice,
					eligible: T.length > 0 ? T.map((e) => e.ref) : void 0,
					onTapCell: A,
					readOnly: p !== n,
					fitKey: `${p}:${f}`
				})
			}), /* @__PURE__ */ h("aside", {
				className: "dsc-sidebar",
				children: [/* @__PURE__ */ h("div", {
					className: "dsc-header",
					children: [/* @__PURE__ */ m(l, {
						tone: j.tone,
						text: j.text,
						accent: g.accent,
						chip: o("games.doppelt-so-clever.roundChip", {
							n: e.round,
							total: e.roundsTotal
						})
					}), /* @__PURE__ */ m(u, {
						members: t.filter((t) => e.players.includes(t.rid)),
						myRid: n,
						variant: "plate",
						status: (t) => {
							let n = e.sheets[t];
							if (!n) return null;
							let r = G(n);
							return /* @__PURE__ */ h("span", {
								className: "flex items-center gap-1.5 font-mono tabular-nums",
								children: [/* @__PURE__ */ m("span", {
									className: "dsc-total font-black",
									children: r.total
								}), r.foxes > 0 && /* @__PURE__ */ h("span", {
									className: "dsc-fox font-bold",
									children: ["🦊", r.foxes]
								})]
							});
						},
						action: (t) => e.bonusFor ? e.bonusFor === t ? "pending" : null : e.phase === "passive" ? e.passivePending.includes(t) ? "pending" : "done" : e.phase === "extra" ? e.extraQueue.includes(t) ? e.extraQueue[0] === t ? "pending" : null : "done" : null,
						onPick: (e) => {
							te(e), v(null);
						},
						picked: (e) => e === p
					})]
				}), /* @__PURE__ */ h("div", {
					className: "dsc-controls",
					children: [/* @__PURE__ */ h("div", {
						className: "dsc-context",
						children: [
							e.soloTie !== null && e.soloTie.candidates.map((t) => /* @__PURE__ */ m(Q, {
								color: t,
								value: e.dice[t],
								onTap: () => i({
									type: "tiePick",
									die: t
								}),
								label: o(at[t], { n: e.dice[t] })
							}, t)),
							e.bonusFor === n && _?.mode !== "bonus" && [...new Set(re.flatMap((e) => e.color === "any" ? D : [e.color]))].map((e) => /* @__PURE__ */ h("button", {
								type: "button",
								onClick: () => v({
									mode: "bonus",
									color: e
								}),
								className: "btn-base min-h-11 px-3 text-sm font-black text-white",
								style: { background: $e[e] },
								children: [o(ot[e]), " ?"]
							}, e)),
							oe.map((e) => /* @__PURE__ */ m("button", {
								type: "button",
								onClick: () => ae(e),
								className: "btn-base min-h-11 min-w-11 font-mono text-base font-black text-white",
								style: { background: g.accent },
								children: e
							}, e)),
							e.bonusFor === null && _?.mode !== "bonus" && w.map(({ die: t }) => /* @__PURE__ */ m(Q, {
								color: t,
								value: e.dice[t],
								selected: _?.mode === "pick" && _.die === t,
								onTap: () => v(_?.mode === "pick" && _.die === t ? null : {
									mode: "pick",
									die: t
								}),
								label: o(at[t], { n: e.dice[t] })
							}, t)),
							_?.mode === "return" && e.platter.map((t) => /* @__PURE__ */ m(Q, {
								color: t,
								value: e.dice[t],
								onTap: () => {
									i({
										type: "return",
										die: t
									}), v(null);
								},
								label: o(at[t], { n: e.dice[t] })
							}, t)),
							w.length === 0 && _?.mode !== "return" && e.bonusFor === null && e.soloTie === null && e.phase !== "done" && /* @__PURE__ */ m("div", {
								className: "dsc-spectator-dice",
								"aria-hidden": !0,
								children: E.map((t) => /* @__PURE__ */ m(Q, {
									color: t,
									value: e.dice[t],
									dim: !e.pool.includes(t),
									label: ""
								}, t))
							})
						]
					}), /* @__PURE__ */ h("div", {
						className: "dsc-actions",
						children: [
							_ !== null && /* @__PURE__ */ m("button", {
								type: "button",
								onClick: () => v(null),
								className: "btn-quiet min-h-11 flex-1 text-sm font-bold",
								children: o("games.doppelt-so-clever.cancel")
							}),
							_ === null && e.phase === "roll" && b && !C && /* @__PURE__ */ h(ee, { children: [/* @__PURE__ */ m("button", {
								type: "button",
								onClick: () => i({ type: "roll" }),
								className: "btn-base min-h-12 flex-1 text-base font-black text-white",
								style: { background: g.accent },
								children: o("games.doppelt-so-clever.roll")
							}), N && /* @__PURE__ */ m("button", {
								type: "button",
								onClick: () => v({ mode: "return" }),
								className: "btn-quiet min-h-12 flex-1 text-sm font-bold",
								children: o("games.doppelt-so-clever.returnDie", { n: H(y, "return") })
							})] }),
							_ === null && e.phase === "pick" && b && !C && /* @__PURE__ */ h(ee, { children: [/* @__PURE__ */ m("button", {
								type: "button",
								disabled: !M,
								onClick: () => i({ type: "reroll" }),
								className: "btn-quiet min-h-12 flex-1 text-sm font-bold disabled:opacity-40",
								children: o("games.doppelt-so-clever.reroll", { n: H(y, "reroll") })
							}), /* @__PURE__ */ m("button", {
								type: "button",
								onClick: () => i({ type: "forfeit" }),
								className: "btn-quiet min-h-12 flex-1 text-sm font-bold",
								children: o("games.doppelt-so-clever.forfeit")
							})] }),
							_ === null && e.phase === "passive" && e.passivePending.includes(n) && !C && e.soloTie === null && /* @__PURE__ */ m("button", {
								type: "button",
								onClick: () => i({ type: "pass" }),
								className: "btn-quiet min-h-12 w-full text-sm font-bold",
								children: o("games.doppelt-so-clever.passiveSkip")
							}),
							_ === null && e.phase === "extra" && e.extraQueue[0] === n && !C && /* @__PURE__ */ m("button", {
								type: "button",
								onClick: () => i({ type: "pass" }),
								className: "btn-base min-h-12 w-full text-base font-black text-white",
								style: { background: g.accent },
								children: o("games.doppelt-so-clever.extraDone")
							})
						]
					})]
				})]
			})]
		})
	});
}
//#endregion
//#region src/games/doppelt-so-clever/bot.ts
var ut = {
	actionW: 1.5,
	bonusFlatW: 2,
	colW: 3,
	sacrificeW: .3,
	rerollBelow: 1.5,
	passiveBelow: .5,
	extraBelow: 2
}, $ = (e) => e.blue + e.white;
function dt(e, t, n) {
	if (t.area === "silver") {
		e.silver[t.row][n - 1] = !0;
		let r = R(e, n - 1);
		return r ? [r] : [];
	}
	if (t.area === "yellow") return I(e, t.cell, n) === "circle" ? (e.yellow[t.cell] = 1, z(e, t.cell)) : (e.yellow[t.cell] = 2, []);
	if (t.area === "blue") {
		let t = P(e.blue);
		e.blue[t] = n;
		let r = B("blue", e, t);
		return r ? [r] : [];
	}
	if (t.area === "green") {
		let t = P(e.green);
		e.green[t] = n;
		let r = B("green", e, t);
		return r ? [r] : [];
	}
	let r = P(e.pink);
	e.pink[r] = n;
	let i = B("pink", e, r);
	return i ? [i] : [];
}
function ft(e, t) {
	if (t.area === "silver") {
		e.silver[t.row][t.num - 1] = !0;
		let n = R(e, t.num - 1);
		return n ? [n] : [];
	}
	if (t.area === "yellow") return e.yellow[t.cell] === 0 ? (e.yellow[t.cell] = 1, z(e, t.cell)) : (e.yellow[t.cell] = 2, []);
	if (t.area === "blue") {
		let n = P(e.blue);
		e.blue[n] = t.value;
		let r = B("blue", e, n);
		return r ? [r] : [];
	}
	if (t.area === "green") {
		let n = P(e.green);
		e.green[n] = t.value;
		let r = B("green", e, n);
		return r ? [r] : [];
	}
	let n = P(e.pink);
	e.pink[n] = t.value;
	let r = B("pink", e, n);
	return r ? [r] : [];
}
function pt(e, t) {
	let n = null;
	for (let r of O) {
		let i = e.silver[r].filter(Boolean).length;
		for (let a = 1; a <= 6; a += 1) {
			if (e.silver[r][a - 1]) continue;
			let o = O.every((t) => t === r || e.silver[t][a - 1]), s = j[i + 1] - j[i] + (o ? t.colW : 0);
			(!n || s > n.score) && (n = {
				row: r,
				num: a,
				score: s
			});
		}
	}
	return n;
}
function mt(e, t, n) {
	if (t === "silver") {
		let t = pt(e, n);
		return t ? {
			area: "silver",
			row: t.row,
			num: t.num
		} : null;
	}
	if (t === "yellow") {
		let t = e.yellow.findIndex((e) => e === 1);
		if (t >= 0) return {
			area: "yellow",
			cell: t
		};
		let n = null;
		for (let t = 0; t < 10; t += 1) {
			if (e.yellow[t] !== 0) continue;
			let [r, i] = k[t], a = 0;
			for (let t = 0; t < 10; t += 1) k[t][0] === r && e.yellow[t] >= 1 && (a += 1), k[t][1] === i && e.yellow[t] >= 1 && (a += 1);
			(!n || a > n.score) && (n = {
				cell: t,
				score: a
			});
		}
		return n ? {
			area: "yellow",
			cell: n.cell
		} : null;
	}
	if (t === "blue") return F(e, 2) ? {
		area: "blue",
		value: 2
	} : null;
	if (t === "green") {
		let t = P(e.green);
		return t < 0 ? null : {
			area: "green",
			value: t % 2 == 0 ? 6 : 1
		};
	}
	return P(e.pink) >= 0 ? {
		area: "pink",
		value: 6
	} : null;
}
function ht(e, t, n) {
	let r = 0, i = 6, a = [...t];
	for (; a.length > 0;) {
		let t = a.shift();
		if (t.kind === "fox") continue;
		if (t.kind === "action") {
			let i = V(e, t.action);
			r += n.actionW, i && a.push(i);
			continue;
		}
		if (i <= 0) {
			r += n.bonusFlatW;
			continue;
		}
		--i;
		let o = mt(e, t.color, n);
		o && a.push(...ft(e, o));
	}
	return r;
}
function gt(e, t, n, r, i, a) {
	let o = structuredClone(e), s = G(o).total, c = dt(o, n, r);
	if (a) for (let e of E) {
		if (!a.moved.includes(e)) continue;
		let n = t[e];
		if (e === "white" || e === "silver") {
			if (!a.jokerRow || o.silver[a.jokerRow][n - 1]) continue;
			o.silver[a.jokerRow][n - 1] = !0;
		} else {
			if (o.silver[e][n - 1]) continue;
			o.silver[e][n - 1] = !0;
		}
		let r = R(o, n - 1);
		r && c.push(r);
	}
	return G(o).total - s + ht(o, c, i);
}
function _t(e, t, n, r, i, a) {
	if (n.area !== "silver") return;
	let o = structuredClone(e);
	dt(o, n, r);
	let s = t[i], c = O.filter((e) => !o.silver[e][s - 1]);
	if (c.length === 0) return;
	let l = c[0], u = -1;
	for (let e of c) {
		let t = o.silver[e].filter(Boolean).length, n = O.every((t) => t === e || o.silver[t][s - 1]), r = j[t + 1] - j[t] + (n ? a.colW : 0);
		r > u && (u = r, l = e);
	}
	return l;
}
function vt(e, t, n, r) {
	let i = $(t), a = -Infinity;
	for (let o of L(e, n, t[n], i)) {
		let s = gt(e, t, o, o.area === "blue" ? i : t[n], r);
		s > a && (a = s);
	}
	return a;
}
function yt(e, t, n) {
	let r = $(t.dice), i = [];
	for (let a of t.pool) {
		let o = t.dice[a];
		for (let s of L(e, a, o, r)) {
			let c, l, u = t.pool.filter((e) => e !== a && t.dice[e] < o);
			if (s.area === "silver") {
				let r = u.find((e) => e === "white" || e === "silver");
				l = r ? _t(e, t.dice, s, o, r, n) : void 0, c = {
					moved: u,
					jokerRow: l
				};
			}
			let d = gt(e, t.dice, s, s.area === "blue" ? r : o, n, c);
			for (let r of u) {
				let i = vt(e, t.dice, r, n);
				i > 0 && (d -= i * n.sacrificeW);
			}
			i.push({
				die: a,
				target: s,
				cascadeRow: l,
				score: d
			});
		}
	}
	return i.sort((e, t) => t.score - e.score);
}
function bt(e, t, n, r) {
	let i = $(t), a = [];
	for (let o of n) for (let n of L(e, o, t[o], i)) a.push({
		die: o,
		target: n,
		score: gt(e, t, n, n.area === "blue" ? i : t[o], r)
	});
	return a.sort((e, t) => t.score - e.score);
}
function xt(e = ut) {
	return (t, n) => {
		let r = t.public, i = r.sheets[n.rid];
		if (!i || r.phase === "done") return null;
		let a = n.difficulty === "weak", o = (e) => e[Math.floor(Math.random() * e.length)], s = $(r.dice);
		if (r.bonusFor === n.rid) {
			let t = r.pending[n.rid]?.[0];
			if (!t) return null;
			let c = (t.color === "any" ? [
				"yellow",
				"blue",
				"green",
				"pink",
				"silver"
			] : [t.color]).filter((e) => W(i, e, s));
			if (c.length === 0) return null;
			if (a) {
				let t = o(c), n = mt(i, t, e);
				return n ? { action: {
					type: "bonus",
					color: t,
					target: n
				} } : null;
			}
			let l = null;
			for (let t of c) {
				let n = mt(i, t, e);
				if (!n) continue;
				let r = structuredClone(i), a = G(r).total, o = ft(r, n), s = G(r).total - a + ht(r, o, e);
				(!l || s > l.score) && (l = {
					color: t,
					bt: n,
					score: s
				});
			}
			return l ? { action: {
				type: "bonus",
				color: l.color,
				target: l.bt
			} } : null;
		}
		if (r.bonusFor !== null) return null;
		if (r.soloTie) {
			let t = r.soloTie.candidates;
			if (a) return { action: {
				type: "tiePick",
				die: o(t)
			} };
			let n = t[0], s = -Infinity;
			for (let a of t) {
				let t = vt(i, r.dice, a, e);
				t > s && (s = t, n = a);
			}
			return { action: {
				type: "tiePick",
				die: n
			} };
		}
		let c = r.active === n.rid;
		if (r.phase === "roll" && c) return { action: { type: "roll" } };
		if (r.phase === "pick" && c) {
			let t = yt(i, r, e), n = H(i, "reroll") > 0;
			if (t.length === 0) return { action: n ? { type: "reroll" } : { type: "forfeit" } };
			if (a) {
				if (n && Math.random() < .25) return { action: { type: "reroll" } };
				let e = o(t);
				return { action: {
					type: "pick",
					die: e.die,
					target: e.target,
					cascadeRow: e.cascadeRow
				} };
			}
			let s = t[0];
			return s.score < e.rerollBelow && n && r.pool.length >= 2 ? { action: { type: "reroll" } } : { action: {
				type: "pick",
				die: s.die,
				target: s.target,
				cascadeRow: s.cascadeRow
			} };
		}
		if (r.phase === "passive" && r.passivePending.includes(n.rid)) {
			let t = r.platter.filter((e) => L(i, e, r.dice[e], s).length > 0), n = t.length > 0 ? t : r.slots.filter((e) => e !== null && L(i, e, r.dice[e], s).length > 0), c = bt(i, r.dice, n, e);
			if (c.length === 0) return { action: { type: "pass" } };
			if (a) {
				let e = o(c);
				return { action: {
					type: "pick",
					die: e.die,
					target: e.target
				} };
			}
			return c[0].score >= e.passiveBelow ? { action: {
				type: "pick",
				die: c[0].die,
				target: c[0].target
			} } : { action: { type: "pass" } };
		}
		if (r.phase === "extra" && r.extraQueue[0] === n.rid) {
			let t = E.filter((e) => !(r.extraUsed[n.rid] ?? []).includes(e)), s = bt(i, r.dice, t, e);
			if (s.length === 0) return { action: { type: "pass" } };
			if (a) {
				if (Math.random() < .5) {
					let e = o(s);
					return { action: {
						type: "pick",
						die: e.die,
						target: e.target
					} };
				}
				return { action: { type: "pass" } };
			}
			return s[0].score >= e.extraBelow ? { action: {
				type: "pick",
				die: s[0].die,
				target: s[0].target
			} } : { action: { type: "pass" } };
		}
		return null;
	};
}
var St = xt(), Ct = {
	yellow: "games.doppelt-so-clever.die.yellow",
	blue: "games.doppelt-so-clever.die.blue",
	green: "games.doppelt-so-clever.die.green",
	pink: "games.doppelt-so-clever.die.pink",
	silver: "games.doppelt-so-clever.die.silver",
	white: "games.doppelt-so-clever.die.white"
}, wt = {
	yellow: "games.doppelt-so-clever.area.yellow",
	blue: "games.doppelt-so-clever.area.blue",
	green: "games.doppelt-so-clever.area.green",
	pink: "games.doppelt-so-clever.area.pink",
	silver: "games.doppelt-so-clever.area.silver"
}, Tt = (e, t, n) => {
	let r = (e) => ({ die: n(Ct[e], { n: t.public.dice[e] }) });
	switch (e.type) {
		case "roll": return n("games.doppelt-so-clever.roll");
		case "reroll": return n("games.doppelt-so-clever.hintReroll");
		case "return": return n("games.doppelt-so-clever.hintReturn", r(e.die));
		case "forfeit": return n("games.doppelt-so-clever.forfeit");
		case "pass": return t.public.phase === "extra" ? n("games.doppelt-so-clever.extraDone") : n("games.doppelt-so-clever.passiveSkip");
		case "pick": return n("games.doppelt-so-clever.hintPick", {
			...r(e.die),
			area: n(wt[e.target.area])
		});
		case "bonus": return n("games.doppelt-so-clever.hintBonus", { area: n(wt[e.color]) });
		case "tiePick": return n("games.doppelt-so-clever.tiePrompt", { n: t.public.soloTie?.need ?? 1 });
		default: return "";
	}
}, Et = {
	name: "Twice as Clever",
	desc: "Silver die cascades, foxes score your weakest area",
	rules: "Goal: Score across five colored areas; at the end each fox scores your lowest area, highest total wins.\nPlay:\n· 6 rounds with 2 players, 5 with 3, 4 with 4; each player is the active player once per round.\n· Solo plays 6 rounds: each round you act as the active player, then as the passive player.\n· As the passive player: reroll all 6 dice, the 3 lowest go to the silver platter, and you record one of them.\n· At the start of each round everyone crosses the round box and collects its bonus.\n· Round bonuses in order: reroll, extra die, return, and a black ? (use any color's ? immediately).\n· The active player rolls all 6 dice, places one on a dice slot and records it in its area.\n· All lower dice go to the silver platter; the rest are rerolled.\n· At most 3 rolls and 3 placed dice; you may forfeit a roll instead.\n· Then every other player simultaneously records one die from the silver platter (dice stay put).\n· Only if no platter die is usable may they use a die from the active player's slots.\n· At the end of the turn, anyone may spend extra-die actions: pick any die (even used ones) and record it once more; each die once per turn.\nAreas:\n· Silver: taking the silver die crosses its number (any row); every die sent to the platter by that choice also crosses one.\n· The white die is wild for any color.\n· Yellow: circle a number first; only circled cells can be crossed; row/column bonuses trigger on circling.\n· Blue: enter the sum of blue + white die, left to right without gaps, never exceeding the previous cell.\n· Green: enter the die value multiplied by the cell's multiplier. For each pair, subtract the right value from the left value; the result may be negative. A pair with an empty cell scores 0 points.\n· Pink: enter the die value directly; a cell's bonus only counts if its threshold is met.\nActions:\n· Reroll and Return are active-player only: reroll everything just rolled after a roll; return takes 1 die back from the platter before rolling.\n· Extra die is used at turn end. Earning an action circles its box, spending crosses it; unused actions stack up.\n· ? bonuses must be used immediately: cross, circle or fill any cell of that color; they may chain into more bonuses.\nScoring:\n· Silver scores per row by crosses (1 cross = 2 pts, 6 crosses = 22); yellow by crosses (up to 165).\n· Blue scores the star value above the last filled cell.\n· Green scores the sum of the pair differences.\n· Pink scores the sum of its entries.\n· Each fox scores the same number of points as your lowest-scoring area. If any area scores 0, each fox scores 0.\n· Ties go to the highest single area, then shared victory.",
	roundChip: "Round {{n}}/{{total}}",
	roll: "Roll",
	reroll: "Reroll ({{n}} left)",
	returnDie: "Return ({{n}} left)",
	forfeit: "Forfeit this roll",
	passiveSkip: "Skip (no die)",
	extraDone: "Done, next player",
	cancel: "Cancel",
	rollPrompt: "Your turn: roll the dice",
	waitingRoll: "Waiting for {{name}} to roll…",
	pickPrompt: "Tap a die below, then a highlighted cell on the sheet",
	waitingPick: "Waiting for {{name}} to pick a die…",
	passivePrompt: "Record one die from the silver platter, or skip",
	waitingPassive: "Waiting for others to pick from the platter…",
	extraPrompt: "Turn end: spend extra-die actions to record again",
	waitingExtra: "Waiting for {{name}} to use extra dice…",
	bonusPrompt: "Resolve your ? bonus: pick a color to use",
	waitingBonus: "Waiting for {{name}} to resolve a ? bonus…",
	roundStart: "New round: collect round bonuses",
	tiePrompt: "Tied dice: pick {{n}} for the platter",
	soloLevels: [
		"Twice as clever!",
		"Score = IQ!",
		"Respect²",
		"That can't have been luck!",
		"Everyone, look at this!",
		"Pretty clever!",
		"Someone's been practicing!",
		"You can be satisfied!",
		"On the right track.",
		"We'll turn a blind eye.",
		"Half as clever."
	],
	hintReroll: "Reroll all dice",
	hintReturn: "Take back {{die}} from the platter",
	hintPick: "Record {{die}} in {{area}}",
	hintBonus: "Use the ? bonus on {{area}}",
	die: {
		yellow: "Yellow die {{n}}",
		blue: "Blue die {{n}}",
		green: "Green die {{n}}",
		pink: "Pink die {{n}}",
		silver: "Silver die {{n}}",
		white: "White die {{n}}"
	},
	area: {
		yellow: "Yellow",
		blue: "Blue",
		green: "Green",
		pink: "Pink",
		silver: "Silver"
	},
	errOver: "This game is over",
	errNotYourTurn: "Not your turn",
	errBadStage: "Not in this phase",
	errBadTarget: "That target is not available",
	errBadDie: "That die is not available",
	errNoAction: "No circled action box left",
	errBonusPending: "Resolve your ? bonus first",
	errTiePending: "Decide the platter dice first"
}, Dt = {
	name: "双倍聪明",
	desc: "银骰一选连锁划,狐狸只认最低分",
	rules: "目标:在五个色区中尽量多地得分;终局每只狐狸奖励等于你最低分区的分数,总分最高者获胜。\n流程:\n· 2 人玩 6 轮,3 人 5 轮,4 人 4 轮;每轮每人当一次主动玩家。\n· 单人玩 6 轮:每轮你先当主动玩家,再扮演被动玩家。\n· 扮演被动玩家时:重新掷出全部6颗骰子，将点数最低的3颗放到银盘上，再从中选择1颗，在对应区域记录其点数。\n· 每轮开始,所有人划掉当前轮数格并领取奖励。\n· 轮次奖励依次是:重掷、额外骰、取回、黑色 ?(任选一种颜色的 ? 立即使用)。\n· 主动玩家投掷全部6颗骰子，选择1颗放至骰位，并在对应色区记录。\n· 将点数小于所选骰子的全部骰子放上银盘，然后重新投掷剩余骰子。\n· 至多掷 3 次、放 3 颗骰;不想要任何骰可放弃本次投掷。\n· 随后，其他玩家同时从银盘中各选择1颗骰子，在对应色区记录；所选骰子留在原处。\n· 银盘骰全不可用时,才可改用主动玩家骰位上的骰。\n· 回合结束时，每名玩家可以使用额外骰行动：选择任意一颗骰子，包括本回合已使用的骰子，再记录一次。每颗骰子在同一回合的额外骰行动中只能使用一次。\n色区:\n· 银区：选择银色骰子时，可以在任意一行划掉对应点数的格子；因此次选择而被送上银盘的骰子，也各允许划掉1个对应点数的格子。\n· 白骰是百搭,可当任意色使用。\n· 黄区：先圈出数字，只有已圈出的格子才能打叉。完成整行或整列的奖励，在该行或该列全部圈出时触发。\n· 蓝区：填写蓝色骰子与白色骰子的点数之和，从左至右依次填写，不能跳过空格，且填入的数字不得大于前一格。\n· 绿区：填写骰子点数乘以该格倍数的结果。每对格子的得分为左格减去右格，可以为负分；只填了一格时，该对格子不得分。\n· 粉区：直接填写骰子点数。只有达到该格要求的点数门槛，才能获得格子下方的奖励。\n行动:\n· 重掷与取回只有主动玩家可以使用。重掷在掷骰后进行；取回在掷骰前进行，从银盘取回1颗骰子。\n· 额外骰在回合末使用。获得行动时圈出对应格,使用时划掉;未用的行动可囤积。\n· ? 奖励必须立即使用:在对应色区任选一格划叉、圈出或填入,可连锁触发新奖励。\n结算:\n· 银区根据每行已打叉的格子数量查表计分，1格获得2分，6格获得22分。\n· 黄区根据已打叉的格子总数查表计分，最多获得165分。\n· 蓝区按照最后一个已填写格子上方的星标分值计分。\n· 绿区将每对格子的差值相加计分。\n· 粉区将所有已填数字相加计分。\n· 每只狐狸获得的分数等于自己得分最低区域的分数；有区域为0分时，每只狐狸获得0分。\n· 总分最高的玩家获胜。总分相同时，单个区域最高得分较高的玩家获胜；若仍然相同，则共享胜利。",
	roundChip: "第 {{n}}/{{total}} 轮",
	roll: "掷骰",
	reroll: "重掷(剩 {{n}})",
	returnDie: "取回(剩 {{n}})",
	forfeit: "放弃本次投掷",
	passiveSkip: "跳过(不选骰)",
	extraDone: "完成,换下一位",
	cancel: "取消",
	rollPrompt: "轮到你了:掷骰",
	waitingRoll: "等 {{name}} 掷骰…",
	pickPrompt: "点底部骰子,再点表上高亮格录入",
	waitingPick: "等 {{name}} 选骰…",
	passivePrompt: "从银盘选一颗骰录入,或跳过",
	waitingPassive: "等其他玩家从银盘选骰…",
	extraPrompt: "回合末:可用额外骰行动再录入(点骰子选目标)",
	waitingExtra: "等 {{name}} 使用额外骰…",
	bonusPrompt: "结算 ? 奖励:选一种颜色用掉它",
	waitingBonus: "等 {{name}} 结算 ? 奖励…",
	roundStart: "新一轮开始:领取轮次奖励",
	tiePrompt: "同点并列:选 {{n}} 颗上银盘",
	soloLevels: [
		"双倍聪明!",
		"分数即智商!",
		"双倍敬意!",
		"这绝非运气!",
		"快来看呐!",
		"相当聪明!",
		"看来练过!",
		"你可以满意了!",
		"路子对了。",
		"再睁一只眼闭一只眼。",
		"只有一半聪明。"
	],
	hintReroll: "重掷全部骰子",
	hintReturn: "从银盘取回 {{die}}",
	hintPick: "用 {{die}} 录入{{area}}",
	hintBonus: "? 奖励落在{{area}}",
	die: {
		yellow: "黄骰 {{n}} 点",
		blue: "蓝骰 {{n}} 点",
		green: "绿骰 {{n}} 点",
		pink: "粉骰 {{n}} 点",
		silver: "银骰 {{n}} 点",
		white: "白骰 {{n}} 点"
	},
	area: {
		yellow: "黄区",
		blue: "蓝区",
		green: "绿区",
		pink: "粉区",
		silver: "银区"
	},
	errOver: "本局已结束",
	errNotYourTurn: "现在轮不到你",
	errBadStage: "现在不是这个阶段",
	errBadTarget: "这个目标不可用",
	errBadDie: "这颗骰不可用",
	errNoAction: "对应的行动格已用完",
	errBonusPending: "先结算 ? 奖励",
	errTiePending: "先决定哪颗骰上银盘"
}, Ot = {
	silver: "games.doppelt-so-clever.area.silver",
	yellow: "games.doppelt-so-clever.area.yellow",
	blue: "games.doppelt-so-clever.area.blue",
	green: "games.doppelt-so-clever.area.green",
	pink: "games.doppelt-so-clever.area.pink"
};
function kt({ public: e, rid: t }) {
	let n = s(), r = o((e) => e.locale), i = e, a = i.sheets[t];
	if (!a) return null;
	let c = G(a);
	return /* @__PURE__ */ h("div", {
		className: "dsc-over-details mt-1.5",
		children: [
			i.players.length === 1 && /* @__PURE__ */ m("div", {
				className: "mb-0.5 text-xs font-black",
				style: { color: "var(--color-ink)" },
				children: (r === "zh" ? Dt : Et).soloLevels[ye(c.total)]
			}),
			/* @__PURE__ */ h("div", {
				className: "flex flex-wrap items-center gap-x-2 gap-y-0.5 font-mono text-xs tabular-nums",
				children: [D.map((e) => /* @__PURE__ */ h("span", { children: [
					n(Ot[e]),
					" ",
					c.areas[e]
				] }, e)), /* @__PURE__ */ h("span", { children: [
					"🦊 ",
					c.foxes,
					"×",
					c.foxScore / Math.max(c.foxes, 1) || 0
				] })]
			}),
			/* @__PURE__ */ m("div", {
				className: "dsc-over-paper frame pointer-events-none mt-1 overflow-hidden",
				"aria-hidden": !0,
				children: /* @__PURE__ */ m("div", {
					style: { aspectRatio: `760 / ${Ie}` },
					children: /* @__PURE__ */ m(rt, {
						sheet: a,
						round: i.roundsTotal,
						slots: [
							null,
							null,
							null
						],
						dice: i.dice,
						readOnly: !0,
						fitKey: `over-${t}`
					})
				})
			})
		]
	});
}
//#endregion
//#region src/games/doppelt-so-clever/game-over.tsx
function At(e) {
	return /* @__PURE__ */ m("div", {
		className: "dsc-over",
		children: /* @__PURE__ */ m(te, {
			hintCount: e.hintCount,
			result: e.result,
			members: e.members,
			myRid: e.myRid,
			accent: g.accent,
			onPlayAgain: e.onPlayAgain,
			onBackToLobby: e.onBackToLobby,
			renderRowExtra: (t) => /* @__PURE__ */ m(kt, {
				public: e.public,
				rid: t,
				myRid: e.myRid
			})
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/doppelt-so-clever/entry.tsx
var jt = {
	definition: Fe,
	View: ct,
	bot: St,
	describe: Tt,
	OverView: At,
	RowView: kt,
	locales: {
		zh: Dt,
		en: Et
	}
};
//#endregion
export { jt as default };
