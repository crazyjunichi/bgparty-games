import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { useI18nSettings as t, useT as n } from "@bgparty/sdk/i18n";
import { z as r } from "zod";
import { useCallback as i, useLayoutEffect as a, useRef as o, useState as s } from "react";
import { useWakeLock as c } from "@bgparty/sdk/use-wake-lock";
import { useFxAnchor as l, useFxAnchorsMaybe as u } from "@bgparty/sdk/fx/anchors";
import { playTurn as d, useSoundEdge as f } from "@bgparty/sdk/sfx";
import { BottomSheet as p } from "@bgparty/sdk/bottom-sheet";
import { AVATARS as m } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as h } from "@bgparty/sdk/player-colors";
import { seatName as g } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as _ } from "@bgparty/sdk/ui/game-screen";
import { Fragment as ee, jsx as v, jsxs as y } from "react/jsx-runtime";
import { FlySprite as te, PulseBox as b } from "@bgparty/sdk/fx/primitives";
import { IconClose as x } from "@bgparty/sdk/icons";
import { OptionCheckbox as ne, OptionRadio as S, OptionSection as re } from "@bgparty/sdk/ui/game-options";
//#region src/games/compile3/legacy-data.ts
var C = [
	"ambush",
	"envy",
	"fulcrum",
	"gluttony",
	"greed",
	"lust",
	"momentum",
	"nova",
	"overwhelm",
	"pride",
	"sloth",
	"wrath"
], ie = [
	"flexible",
	"rigid",
	"inert"
];
[...C, ...ie];
var w = (e = "", t = "") => ({
	zh: e,
	en: t
}), T = (e, t, n, r = w(), i = w()) => ({
	id: `${e}-${t}`,
	protocol: e,
	value: t,
	top: r,
	mid: n,
	bottom: i
}), E = w("弃置 1 张手牌。", "Discard 1 card."), D = [
	T("envy", 0, w(), w("你在此列的总值增加对手在此列中数值最高的牌的数值。", "Your total value in this line is increased by the value of your opponent’s highest value card in this line.")),
	T("envy", 1, w("如果对手持有控制权，你可以翻转 1 张牌。", "If your opponent has control, you may flip 1 card."), w(), w("开始时：如果对手持有控制权，获得控制权。", "Start: If your opponent has control, gain control.")),
	T("envy", 2, w("抽取等同于对手手牌数量的牌。", "Draw cards equal to the number of cards in your opponent’s hand.")),
	T("envy", 3, w(), w(), w("对手在此列打出牌后：将你的牌库顶牌暗置打入此列。", "After your opponent plays a card in this line: Play the top card of your deck face-down in this line.")),
	T("envy", 4, w("如果对手已编译的协议比你多，翻转 1 张牌。", "If your opponent has more compiled protocols than you do, flip 1 card.")),
	T("envy", 5, E),
	T("pride", 0, w("如果你持有控制权，移动另外 1 张牌。否则，移动你自己的 1 张牌。", "If you have control, shift 1 other card. Else, shift 1 of your cards."), w("你编译后：补充手牌。", "After you compile: Refresh.")),
	T("pride", 2, w("抽取等同于你总值领先的列数的牌。", "Draw cards equal to the number of lines where you have a higher total value than your opponent."), w(), w("开始时：如果你在此列的总值高于对手，抽 1 张牌。", "Start: If you have a higher total value than your opponent in this line, draw 1 card.")),
	T("pride", 3, w("翻转你自己的 1 张暗置牌。", "Flip 1 of your face-down cards.")),
	T("pride", 4, w("如果你持有控制权，你可以将对手的 1 张牌移动至此列。", "If you have control, you may shift 1 of your opponent’s cards to this line.")),
	T("pride", 5, E),
	T("pride", 6, w("如果对手持有控制权，翻转此牌。", "If your opponent has control, flip this card."), w("对手获得控制权后：翻转此牌。", "After your opponent gains control: Flip this card.")),
	T("lust", 0, w("获得控制权。", "Gain control."), w("双方在此列的总值均增加 10。", "Each player’s total value in this line is increased by 10."), w("如果你持有控制权，对手不能编译。", "Your opponent can’t compile if you have control.")),
	T("lust", 2, w("你可以将对手的 1 张被覆盖的牌移动至此列。", "You may shift 1 of your opponent’s covered cards to this line."), w(), w("你的牌可以正面打入此牌所在的牌堆，无须匹配协议。", "Your cards may be played in this stack without matching protocols.")),
	T("lust", 3, w("对手随机展示 1 张手牌。将该牌暗置打入对手一侧。", "Your opponent reveals 1 random card from their hand. Play that card face-down on their side."), w(), w("结束时：你可以失去控制权。如果失去，翻转 1 张牌。", "End: You may lose control. If you did, flip 1 card.")),
	T("lust", 4, w("展示你的手牌。对手失去控制权。", "Reveal your hand. Your opponent loses control."), w(), w("对手获得控制权后：抽 1 张牌。", "After your opponent gains control: Draw 1 card.")),
	T("lust", 5, E),
	T("lust", 6, w("弃置 1 张手牌。对手在此列暗置打出 1 张手牌。", "Discard 1 card. Your opponent plays 1 card face-down in this line.")),
	T("overwhelm", 1, w("在你总值领先的每一列中，将你的牌库顶牌暗置打入。", "Play the top card of your deck face-down in each line where you have a higher total value than your opponent.")),
	T("overwhelm", 2, w("对手在每一列中，将其牌库顶牌暗置打入。", "Your opponent plays the top card of their deck face-down in each line."), w("结束时：在每一列中，将你的牌库顶牌暗置打入。翻转此牌。", "End: Play the top card of your deck face-down in each line. Flip this card.")),
	T("overwhelm", 3, w(), w(), w("结束时：如果你有至少 5 张手牌，将你的牌库顶牌暗置打入此牌堆。", "End: If you have 5 or more cards in your hand, play the top card of your deck face-down in this stack.")),
	T("overwhelm", 4, w("如果你的在场牌比对手多，删除对手数值最低的 1 张被覆盖的牌。", "If you have more cards in play than your opponent, delete your opponent’s lowest value covered card.")),
	T("overwhelm", 5, E),
	T("overwhelm", 6, w(), w("开始时：如果对手在此列的总值高于你，翻转此牌。", "Start: If your opponent has a higher total value in this line than you do, flip this card.")),
	T("ambush", 0, w("抽 3 张牌。翻转你自己的 1 张暗置牌。", "Draw 3 cards. Flip 1 of your face-down cards.")),
	T("ambush", 1, w("翻转你所有其他数值为 0 或 1 的牌。每翻转 1 张，抽 1 张牌。", "Flip all of your other cards with a value of 0 and 1. Draw 1 card for each card flipped.")),
	T("ambush", 2, w("移动你数值最低的 1 张被覆盖的牌。", "Shift your lowest value covered card.")),
	T("ambush", 3, w("翻转对手数值最高的 1 张未被覆盖的正面牌。", "Flip your opponent’s highest value face-up uncovered card.")),
	T("ambush", 4, w("如果你有未被覆盖的暗置牌，抽 1 张牌。", "Draw 1 card if you have an uncovered face-down card.")),
	T("ambush", 5, E),
	T("fulcrum", 0, w("如果你恰有 0 张手牌，对手弃置 1 张手牌。", "If you have exactly 0 cards in hand, your opponent discards 1 card."), w("开始时：如果你恰有 0 张手牌，对手弃置 2 张手牌。", "Start: If you have exactly 0 cards in hand, your opponent discards 2 cards.")),
	T("fulcrum", 1, w("翻转每一张其他正面牌。交换你最左侧与最右侧的牌堆。", "Flip each other face-up card. Swap your left stack with your right stack.")),
	T("fulcrum", 2, w("如果你恰有 2 张手牌，删除对手的 1 张牌。", "If you have exactly 2 cards in hand, delete 1 of your opponent’s cards.")),
	T("fulcrum", 3, w("抽 1 张牌。交换你最左侧与最右侧的协议。", "Draw 1 card. Swap the positions of your left and right protocols.")),
	T("fulcrum", 4, w("如果你恰有 4 张手牌，抽 1 张牌。", "If you have exactly 4 cards in hand, draw 1 card.")),
	T("fulcrum", 5, E),
	T("gluttony", 0, w("将另外 1 张牌返回其所有者的手牌。抽 1 张牌。", "Return 1 other card. Draw 1 card."), w("你清理缓存后：将你的牌库顶牌暗置打出。", "After you clear cache: Play the top card of your deck face-down.")),
	T("gluttony", 1, w("抽 2 张牌。", "Draw 2 cards."), w(), w("任一方清理缓存后：删除 1 张牌。", "After a player clears cache: Delete 1 card.")),
	T("gluttony", 2, w("抽取等同于你手牌数量的牌。", "Draw cards equal to the number of cards in your hand.")),
	T("gluttony", 3, w("抽 2 张牌。", "Draw 2 cards."), w("结束时：如果此牌被正面牌覆盖，删除覆盖它的那张牌。", "End: If this card is covered by a face-up card, delete that card.")),
	T("gluttony", 4, w(), w(), w("你补充手牌后：抽 1 张牌。", "After you refresh: Draw 1 card.")),
	T("gluttony", 5, E),
	T("nova", 0, w("持有控制权的一方交换你的任意 2 个协议的位置。", "The player with control swaps the positions of 2 of your protocols."), w("开始时：选择你恰有 5 张牌的一列，删除其中所有正面牌。", "Start: Delete all face-up cards in a line where you have exactly 5 cards."), w("结束时：将你的牌库顶牌暗置打入 1 张未被覆盖的 Nova 牌下方。", "End: Play the top card of your deck face-down under an uncovered Nova card.")),
	T("nova", 1, w("对手弃置等同于此牌堆牌数的手牌。", "Your opponent discards cards equal to the number of cards in this stack.")),
	T("nova", 2, w("如果此牌正覆盖 Nova 牌，你可以重排自己的协议。否则，获得控制权。", "If this card is covering a Nova card, you may rearrange your protocols. Else, gain control."), w(), w("你重排协议后：你可以移动 1 张暗置牌。", "After you rearrange protocols: You may shift 1 face-down card.")),
	T("nova", 3, w("移动 1 张数值小于此牌堆牌数的牌。", "Shift 1 card with a value less than the number of cards in this stack.")),
	T("nova", 4, w("翻转 1 张数值小于此牌堆牌数的牌。", "Flip 1 card with a value less than the number of cards in this stack.")),
	T("nova", 5, E),
	T("momentum", 0, w("在你已编译协议所在的每一列中，将你的牌库顶牌暗置打入。", "Play the top card of your deck face-down in each line with a compiled protocol.")),
	T("momentum", 1, w(), w("任一方编译后：将你的牌库顶牌暗置打入此牌堆。", "After a player compiles: Play the top card of your deck face-down in this stack."), w("任一方重排协议后：弃置 1 张手牌。抽 1 张牌。", "After a player rearranges protocols: Discard 1 card. Draw 1 card.")),
	T("momentum", 3, w("抽 2 张牌。", "Draw 2 cards.")),
	T("momentum", 4, w("重排你自己的协议。", "Rearrange your protocols.")),
	T("momentum", 5, E),
	T("momentum", 6, E, w("任一方编译后：删除此牌。", "After a player compiles: Delete this card.")),
	T("greed", 0, w("弃置所有手牌。删除 1 张牌。", "Discard your hand. Delete 1 card."), w(), w("你删除牌后：抽 1 张牌。", "After you delete a card: Draw 1 card.")),
	T("greed", 1, w(), w(), w("结束时：编译你总值至少为 10 且领先于对手的一列。", "End: Compile a line where you have at least 10 value and a higher total value than your opponent.")),
	T("greed", 2, w("对手弃置 1 张手牌。", "Your opponent discards 1 card."), w(), w("开始时：你可以将你自己的 1 张牌返回手牌。", "Start: You may return 1 of your cards.")),
	T("greed", 3, w("移动此牌堆中你自己的 1 张被覆盖的牌。", "Shift 1 of your covered cards in this stack.")),
	T("greed", 4, w("你可以弃置所有手牌。如果这样做，翻转 1 张牌。", "You may discard your hand. If you did, flip 1 card.")),
	T("greed", 5, E),
	T("sloth", 0, w("抽取等同于你总值落后的列数的牌。", "Draw cards equal to the number of lines where you have a lower total value than your opponent."), w("如果此牌被 Sloth 牌覆盖，你在此列的总值增加 5。", "Your total value in this line is increased by 5 if this card is covered by a Sloth card.")),
	T("sloth", 1, w("将另外 1 张牌返回其所有者的手牌。如果返回的是你自己的牌，补充手牌。", "Return 1 other card. If the returned card is one of your cards, refresh."), w(), w("你补充手牌后：将你的牌库顶牌暗置打入此牌堆。", "After you refresh: Play the top card of your deck face-down in this stack.")),
	T("sloth", 2, w("翻转你自己的 1 张被覆盖的牌。", "Flip 1 of your covered cards."), w(), w("开始时：你可以将 1 张手牌放到自己牌库底。", "Start: You may put 1 card from your hand on the bottom of your deck.")),
	T("sloth", 3, w("对手弃置 2 张手牌。", "Your opponent discards 2 cards.")),
	T("sloth", 4, w("此牌将被覆盖时：先翻转 1 张正面牌。", "When this card would be covered: First, flip 1 face-up card.")),
	T("sloth", 5, E),
	T("wrath", 0, w("将你的牌库顶牌暗置打入此牌堆。", "Play the top card of your deck face-down in this stack."), w("此列中数值最高的所有牌，均不计入各自一方的总值。", "All cards with the highest value in this line do not add to a player’s total value in this line.")),
	T("wrath", 1, w("抽 1 张牌。", "Draw 1 card."), w(), w("结束时：失去控制权。如果失去，删除 1 张正面牌。", "End: Lose control. If you did, delete 1 face-up card.")),
	T("wrath", 2, w("选择牌数最多的一列，翻转其中所有正面牌。", "Flip all face-up cards in a line with the most cards.")),
	T("wrath", 3, w("翻转 1 张正面牌。", "Flip 1 face-up card.")),
	T("wrath", 4, w("失去控制权。如果失去，对手弃置 2 张手牌。", "Lose control. If you did, your opponent discards 2 cards.")),
	T("wrath", 5, E),
	T("flexible", 0, w("将 1 张牌返回手牌，或移动 1 张牌。", "Return or shift 1 card.")),
	T("flexible", 1, w("翻转或移动你自己的 1 张牌。", "Flip or shift 1 of your cards.")),
	T("flexible", 2, w("抽 1 张牌。", "Draw 1 card."), w("结束时：如果此牌被暗置牌覆盖，你可以移动覆盖它的那张牌。", "End: If this is covered by a face-down card, you may shift that card.")),
	T("flexible", 3, w("移动对手的 1 张牌，或交换你自己的 2 个协议。", "Shift 1 of your opponent’s cards or swap 2 of your protocols.")),
	T("flexible", 4, w(), w(), w("结束时：你可以抽 2 张牌。如果这样做，翻转此牌。", "End: You may draw 2 cards. If you do, flip this card.")),
	T("flexible", 5, E),
	T("rigid", 1, w("翻转对手的 1 张正面牌。", "Flip 1 of your opponent’s face-up cards."), w(), w("结束时：在其他每一列中，如果对手未被覆盖的牌是暗置牌，你在该列暗置打出 1 张手牌。", "End: Play 1 card face-down in each other line where your opponent’s uncovered card is face-down.")),
	T("rigid", 2, w(), w(), w("你使用行动暗置打出牌后：将你的牌库顶牌暗置打入同一牌堆。", "After you use your action to play a card face-down: Play the top card of your deck face-down in the same stack.")),
	T("rigid", 3, w("在此牌正下方暗置打入 1 张手牌。", "Play 1 card face-down directly under this card.")),
	T("rigid", 4, w(), w(), w("此牌将被暗置牌覆盖时：先抽 1 张牌。", "When this card would be covered by a face-down card: First, draw 1 card.")),
	T("rigid", 5, E),
	T("rigid", 7, E, w("结束时：对手选择抽 1 张牌或打出 1 张手牌。", "End: Your opponent chooses to draw 1 card or play 1 card."), w("此牌不能被翻转或移动。", "This card cannot be flipped or shifted.")),
	T("inert", 0, w("翻转另一列中 1 张被覆盖或未被覆盖的正面牌。", "Flip 1 covered or uncovered face-up card in a different line."), w("此列中的所有其他牌均没有顶部指令。", "All other cards in this line have no top commands.")),
	T("inert", 1, w("对手弃置 2 张手牌。", "Your opponent discards 2 cards."), w(), w("此列中的所有其他牌均没有底部指令。", "All other cards in this line have no bottom command.")),
	T("inert", 2, w("选择一列，翻转其中所有数值最高的正面牌。", "Flip all face-up cards in a line that have the highest value in that line.")),
	T("inert", 3, w("在其他每一列中，你暗置打出 1 张手牌。对手在此列暗置打出 1 张手牌。", "Play 1 card face-down in each other line. Your opponent plays 1 card face-down in this line.")),
	T("inert", 4, w("弃置你的整个牌库。对手弃置其整个牌库。", "Discard your deck. Your opponent discards their deck.")),
	T("inert", 5, E)
], O = Object.fromEntries(D.map((e) => [e.id, e])), ae = {
	ambush: "#4997ad",
	envy: "#13bdcb",
	fulcrum: "#7cb6ce",
	gluttony: "#d9af45",
	greed: "#61b1b4",
	lust: "#ed6867",
	momentum: "#e3a488",
	nova: "#e5a850",
	overwhelm: "#b8a2b6",
	pride: "#f0d266",
	sloth: "#b6a7b2",
	wrath: "#db6451",
	flexible: "#cc78d9",
	rigid: "#c8cc62",
	inert: "#c4c0b7"
}, oe = [
	{
		name: "Define Parameters",
		protocols: [
			"envy",
			"gluttony",
			"greed"
		],
		plays: ["up"],
		control: "none"
	},
	{
		name: "Data Transfer",
		protocols: [
			"momentum",
			"overwhelm",
			"pride"
		],
		plays: ["up"],
		control: "draw"
	},
	{
		name: "Merge Sort",
		protocols: [
			"ambush",
			"fulcrum",
			"overwhelm"
		],
		plays: ["low", "up"],
		control: "steal"
	},
	{
		name: "Authentication",
		protocols: [
			"ambush",
			"fulcrum",
			"overwhelm"
		],
		plays: ["up", "up"],
		control: "draw"
	},
	{
		name: "Distributed Denial of Service",
		protocols: [
			"ambush",
			"fulcrum",
			"overwhelm"
		],
		plays: [
			"high",
			"low",
			"low"
		],
		control: "draw"
	},
	{
		name: "2-Factor Authentication",
		protocols: [
			"momentum",
			"overwhelm",
			"pride"
		],
		plays: ["up", "up"],
		control: "draw"
	},
	{
		name: "Handshake",
		protocols: [
			"fulcrum",
			"momentum",
			"overwhelm"
		],
		plays: ["up"],
		control: "none"
	},
	{
		name: "Encryption",
		protocols: [
			"fulcrum",
			"momentum",
			"overwhelm"
		],
		plays: ["low", "up"],
		control: "draw"
	},
	{
		name: "Vulnerability Exploit",
		protocols: [
			"gluttony",
			"lust",
			"pride"
		],
		plays: ["up", "up"],
		control: "steal"
	},
	{
		name: "Benchmark",
		protocols: [
			"ambush",
			"fulcrum",
			"momentum"
		],
		plays: ["up", "up"],
		control: "draw"
	},
	{
		name: "Bottleneck",
		protocols: [
			"ambush",
			"momentum",
			"overwhelm"
		],
		plays: [
			"low",
			"up",
			"up"
		],
		control: "rearrange"
	},
	{
		name: "Root Access",
		protocols: [
			"ambush",
			"momentum",
			"overwhelm"
		],
		plays: [
			"up",
			"up",
			"up"
		],
		control: "draw"
	}
], se = [
	"darkness",
	"death",
	"fire",
	"gravity",
	"life",
	"light",
	"metal",
	"plague",
	"psychic",
	"speed",
	"spirit",
	"water"
], ce = [
	"chaos",
	"clarity",
	"corruption",
	"courage",
	"fear",
	"ice",
	"luck",
	"mirror",
	"peace",
	"smoke",
	"time",
	"war"
], le = [
	"love",
	"hate",
	"apathy"
], k = [
	"assimilation",
	"diversity",
	"unity"
], ue = [
	...se,
	...ce,
	...C,
	...le,
	...k,
	...ie
], de = {
	apathy: "冷漠",
	assimilation: "同化",
	chaos: "混沌",
	clarity: "明晰",
	corruption: "腐化",
	courage: "勇气",
	darkness: "黑暗",
	death: "死亡",
	diversity: "多样",
	fear: "恐惧",
	fire: "火焰",
	gravity: "重力",
	hate: "憎恨",
	ice: "寒冰",
	life: "生命",
	light: "光明",
	love: "爱",
	luck: "幸运",
	metal: "金属",
	mirror: "镜像",
	peace: "和平",
	plague: "瘟疫",
	psychic: "灵能",
	smoke: "烟雾",
	speed: "速度",
	spirit: "精神",
	time: "时间",
	unity: "团结",
	war: "战争",
	water: "水流"
};
function A(e) {
	return t.getState().locale === "zh" ? me[e] ?? e : e.charAt(0).toUpperCase() + e.slice(1);
}
var fe = {
	apathy: "#8d9db1",
	assimilation: "#20bbd1",
	chaos: "#9239a4",
	clarity: "#95d4d5",
	corruption: "#be765b",
	courage: "#e0ac26",
	darkness: "#5851b4",
	death: "#e7e4db",
	diversity: "#ac5ac5",
	fear: "#582f9a",
	fire: "#ed4826",
	gravity: "#d28daa",
	hate: "#b12f3d",
	ice: "#78c6dc",
	life: "#68b942",
	light: "#f3cc4f",
	love: "#dc6994",
	luck: "#78ab59",
	metal: "#a5b5bb",
	mirror: "#8dd3db",
	peace: "#7292c7",
	plague: "#a6b93b",
	psychic: "#ca73ab",
	smoke: "#8c83b4",
	speed: "#f9bf39",
	spirit: "#a6ae73",
	time: "#da8d54",
	unity: "#7da990",
	war: "#df7048",
	water: "#3c9bbb"
}, pe = [
	{
		protocol: "apathy",
		value: 0,
		top: {
			zh: "此列每有 1 张暗置牌，你在此列的总值就增加 1。",
			en: "Your total value in this line is increased by 1 for each face-down card in this line."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "apathy-0",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "apathy",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "apathy-1",
		mid: {
			zh: "翻转此列中所有其他正面朝上的牌。",
			en: "Flip all other face-up cards in this line."
		}
	},
	{
		protocol: "apathy",
		value: 2,
		top: {
			zh: "忽略此列所有牌的中部指令。",
			en: "Ignore all middle commands of cards in this line."
		},
		bottom: {
			zh: "此牌将被覆盖时：先翻转此牌。",
			en: "When this card would be covered:  First, flip this card."
		},
		id: "apathy-2",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "apathy",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "apathy-3",
		mid: {
			zh: "翻转对手的 1 张正面朝上的牌。",
			en: "Flip 1 of your opponent's face-up cards."
		}
	},
	{
		protocol: "apathy",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "apathy-4",
		mid: {
			zh: "你可以翻转自己的 1 张被覆盖且正面朝上的牌。",
			en: "You may flip 1 of your face-up covered cards."
		}
	},
	{
		protocol: "apathy",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "apathy-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "assimilation",
		value: 0,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "assimilation-0",
		mid: {
			zh: "将对手的 1 张暗置牌拿入你的手牌，无论该牌是否被覆盖。",
			en: "Put 1 of your opponent's covered or uncovered face-down cards into your hand."
		}
	},
	{
		protocol: "assimilation",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "任意玩家补充手牌后：抽取对手的牌库顶牌。将你的 1 张手牌弃入对手的弃牌堆。",
			en: "After a player refreshes:  Draw the top card of your opponent's deck. Discard 1 card into their trash."
		},
		id: "assimilation-1",
		mid: {
			zh: "弃置 1 张手牌。补充手牌。",
			en: "Discard 1 card. Refresh."
		}
	},
	{
		protocol: "assimilation",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "结束时：将对手的牌库顶牌暗置打入此牌堆。",
			en: "End:  Play the top card of your opponent's deck face down in this stack."
		},
		id: "assimilation-2",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "assimilation",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "assimilation-4",
		mid: {
			zh: "抽取对手的牌库顶牌。对手抽取你的牌库顶牌。",
			en: "Draw the top card of your opponent's deck. Your opponent draws the top card of your deck."
		}
	},
	{
		protocol: "assimilation",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "assimilation-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "assimilation",
		value: 6,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "结束时：将你的牌库顶牌暗置打到对手一侧。",
			en: "End:  Play the top card of your deck face-down on your opponent's side."
		},
		id: "assimilation-6",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "chaos",
		value: 0,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "开始时：抽取对手的牌库顶牌。对手抽取你的牌库顶牌。",
			en: "Start:  Draw the top card of your opponent's deck. Your opponent draws the top card of your deck."
		},
		id: "chaos-0",
		mid: {
			zh: "在每一列中，翻转 1 张被覆盖的牌。",
			en: "Flip 1 covered card in each line."
		}
	},
	{
		protocol: "chaos",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "chaos-1",
		mid: {
			zh: "重排你的协议。重排对手的协议。",
			en: "Rearrange your protocols. Rearrange your opponent's protocols."
		}
	},
	{
		protocol: "chaos",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "chaos-2",
		mid: {
			zh: "移动自己的 1 张被覆盖的牌。",
			en: "Shift 1 of your covered cards."
		}
	},
	{
		protocol: "chaos",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "此牌可以正面打入任意一列，无须匹配协议。",
			en: "This card may be played without matching protocols."
		},
		id: "chaos-3",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "chaos",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "结束时：弃置全部手牌。抽取等同于本次弃牌数量的牌。",
			en: "End:  Discard your hand. Draw that many cards."
		},
		id: "chaos-4",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "chaos",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "chaos-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "clarity",
		value: 0,
		top: {
			zh: "你每有 1 张手牌，在此列的总值就增加 1。",
			en: "Your total value in this line is increased by 1 for each card in your hand."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "clarity-0",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "clarity",
		value: 1,
		top: {
			zh: "开始时：展示你的牌库顶牌。你可以弃置你的牌库顶牌。",
			en: "Start:  Reveal the top card of your deck. You may discard the top card of your deck."
		},
		bottom: {
			zh: "此牌将被覆盖时：先抽取 3 张牌。",
			en: "When this card would be covered:  First, draw 3 cards."
		},
		id: "clarity-1",
		mid: {
			zh: "对手展示全部手牌。",
			en: "Your opponent reveals their hand."
		}
	},
	{
		protocol: "clarity",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "clarity-2",
		mid: {
			zh: "展示你的牌库。从展示的牌中抽取 1 张数值为 1 的牌。洗混你的牌库。打出 1 张数值为 1 的手牌。",
			en: "Reveal your deck. Draw 1 card with a value of 1 revealed this way. Shuffle your deck. Play 1 card with a value of 1."
		}
	},
	{
		protocol: "clarity",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "clarity-3",
		mid: {
			zh: "展示你的牌库。从展示的牌中抽取 1 张数值为 5 的牌。洗混你的牌库。",
			en: "Reveal your deck. Draw 1 card with a value of 5 revealed this way. Shuffle your deck."
		}
	},
	{
		protocol: "clarity",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "clarity-4",
		mid: {
			zh: "你可以将弃牌堆洗入牌库。",
			en: "You may shuffle your trash into your deck."
		}
	},
	{
		protocol: "clarity",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "clarity-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "corruption",
		value: 0,
		top: {
			zh: "开始时：翻转此牌堆中另外 1 张正面朝上的牌，无论该牌是否被覆盖。",
			en: "Start:  Flip 1 face-up covered or uncovered card in this stack other than this card."
		},
		bottom: {
			zh: "此牌可以打入任意一列，也可以打到对手一侧。",
			en: "You may play this card in any line on either player's side."
		},
		id: "corruption-0",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "corruption",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "一张牌将返回对手的手牌时：改为将该牌暗置放到对手的牌库顶。",
			en: "When a card would be returned to your opponent's hand:  Put that card on top of their deck face-down instead."
		},
		id: "corruption-1",
		mid: {
			zh: "将 1 张牌返回手牌。",
			en: "Return 1 card."
		}
	},
	{
		protocol: "corruption",
		value: 2,
		top: {
			zh: "你弃牌后：对手弃置 1 张手牌。",
			en: "After you discard cards:  Your opponent discards 1 card."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "corruption-2",
		mid: {
			zh: "抽取 1 张牌。弃置 1 张手牌。",
			en: "Draw 1 card. Discard 1 card."
		}
	},
	{
		protocol: "corruption",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "corruption-3",
		mid: {
			zh: "你可以翻转 1 张被覆盖且正面朝上的牌。",
			en: "You may flip 1 face-up covered card."
		}
	},
	{
		protocol: "corruption",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "corruption-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "corruption",
		value: 6,
		top: {
			zh: "结束时：弃置 1 张手牌，或删除此牌。",
			en: "End:  Either discard 1 card or delete this card."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "corruption-6",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "courage",
		value: 0,
		top: {
			zh: "开始时：如果你没有手牌，抽取 1 张牌。",
			en: "Start:  If you have no cards in hand, draw 1 card."
		},
		bottom: {
			zh: "结束时：你可以弃置 1 张手牌。如果如此做，对手弃置 1 张手牌。",
			en: "End:  You may discard 1 card. If you do, your opponent discards 1 card."
		},
		id: "courage-0",
		mid: {
			zh: "抽取 1 张牌。",
			en: "Draw 1 card."
		}
	},
	{
		protocol: "courage",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "courage-1",
		mid: {
			zh: "在对手总值高于你的任意一列中，删除对手的 1 张牌。",
			en: "Delete 1 of your opponent's cards in a line where they have a higher total value than you do"
		}
	},
	{
		protocol: "courage",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "结束时：如果对手在此列的总值高于你，抽取 1 张牌。",
			en: "End:  If your opponent has a higher total value than you do in this line, draw 1 card."
		},
		id: "courage-2",
		mid: {
			zh: "抽取 1 张牌。",
			en: "Draw 1 card."
		}
	},
	{
		protocol: "courage",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "结束时：你可以将此牌移动到对手总值最高的一列。",
			en: "End:  You may shift this card to the line where your opponent has their highest total value."
		},
		id: "courage-3",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "courage",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "courage-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "courage",
		value: 6,
		top: {
			zh: "结束时：如果对手在此列的总值高于你，翻转此牌。",
			en: "End:  If your opponent has a higher value in this line than you do, flip this card."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "courage-6",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "darkness",
		value: 0,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "darkness-0",
		mid: {
			zh: "抽取 3 张牌。移动对手的 1 张被覆盖的牌。",
			en: "Draw 3 cards. Shift 1 of your opponent's covered cards."
		}
	},
	{
		protocol: "darkness",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "darkness-1",
		mid: {
			zh: "翻转对手的 1 张牌。你可以移动该牌。",
			en: "Flip 1 of your opponent's cards. You may shift that card."
		}
	},
	{
		protocol: "darkness",
		value: 2,
		top: {
			zh: "此牌堆中所有暗置牌的数值均为 4。",
			en: "All face-down cards in this stack have a value of 4."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "darkness-2",
		mid: {
			zh: "你可以翻转此列中 1 张被覆盖的牌。",
			en: "You may flip 1 covered card in this line."
		}
	},
	{
		protocol: "darkness",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "darkness-3",
		mid: {
			zh: "将 1 张手牌暗置打入另一列。",
			en: "Play 1 card face-down in another line."
		}
	},
	{
		protocol: "darkness",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "darkness-4",
		mid: {
			zh: "移动 1 张暗置牌。",
			en: "Shift 1 face-down card."
		}
	},
	{
		protocol: "darkness",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "darkness-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "death",
		value: 0,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "death-0",
		mid: {
			zh: "在其他每一列中，删除 1 张牌。",
			en: "Delete 1 card from each other line."
		}
	},
	{
		protocol: "death",
		value: 1,
		top: {
			zh: "开始时：你可以抽取 1 张牌。如果如此做，删除另外 1 张牌。然后，删除此牌。",
			en: "Start:  You may draw 1 card. If you do, delete 1 other card. Then delete this card."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "death-1",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "death",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "death-2",
		mid: {
			zh: "删除某一列中所有数值为 1 或 2 的牌。",
			en: "Delete all cards in 1 line with values of 1 or 2."
		}
	},
	{
		protocol: "death",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "death-3",
		mid: {
			zh: "删除 1 张暗置牌。",
			en: "Delete 1 face-down card."
		}
	},
	{
		protocol: "death",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "death-4",
		mid: {
			zh: "删除 1 张数值为 0 或 1 的牌。",
			en: "Delete a card with a value of 0 or 1."
		}
	},
	{
		protocol: "death",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "death-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "diversity",
		value: 0,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "结束时：你可以将 1 张非多样协议的手牌打入此列。",
			en: "End:  You may play 1 non-Diversity card in this line."
		},
		id: "diversity-0",
		mid: {
			zh: "如果场上的牌共有 6 种不同协议，将你的多样协议翻到已编译面。",
			en: "If there are 6 different protocols on cards in the field, flip the Diversity protocol to the compiled side."
		}
	},
	{
		protocol: "diversity",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "diversity-1",
		mid: {
			zh: "移动 1 张牌。抽取等同于此列牌上不同协议种数的牌。",
			en: "Shift 1 card. Draw cards equal to the number of different protocols in this line."
		}
	},
	{
		protocol: "diversity",
		value: 3,
		top: {
			zh: "如果此牌堆中有非多样协议的正面牌，你在此列的总值增加 2。",
			en: "Your total value in this line is increased by 2 if there are any non-Diversity face-up cards in this stack."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "diversity-3",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "diversity",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "diversity-4",
		mid: {
			zh: "翻转 1 张数值小于场上牌的不同协议种数的牌。",
			en: "Flip 1 card with a value less than the number of different protocols on cards in the field."
		}
	},
	{
		protocol: "diversity",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "diversity-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "diversity",
		value: 6,
		top: {
			zh: "结束时：如果场中牌上没有至少 4 种不同的协议，删除此牌。",
			en: "End: If there are not at least 4 different protocols on cards in the field, delete this card."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "diversity-6",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "fear",
		value: 0,
		top: {
			zh: "在你的回合中，对手的牌没有中部指令。",
			en: "During your turn, your opponent's cards do not have middle commands."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "fear-0",
		mid: {
			zh: "移动或翻转 1 张牌。",
			en: "Shift or flip 1 card."
		}
	},
	{
		protocol: "fear",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "fear-1",
		mid: {
			zh: "抽取 2 张牌。对手弃置全部手牌，然后抽取比本次弃牌数量少 1 张的牌。",
			en: "Draw 2 cards. Your opponent discards their hand and draws the amount of cards discarded minus 1."
		}
	},
	{
		protocol: "fear",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "fear-2",
		mid: {
			zh: "将对手的 1 张牌返回手牌。",
			en: "Return 1 of your opponent's cards."
		}
	},
	{
		protocol: "fear",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "fear-3",
		mid: {
			zh: "移动此列中对手的 1 张牌，无论该牌是否被覆盖。",
			en: "Shift 1 of your opponent's covered or uncovered cards in this line."
		}
	},
	{
		protocol: "fear",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "fear-4",
		mid: {
			zh: "对手随机弃置 1 张手牌。",
			en: "Your opponent discards 1 random card."
		}
	},
	{
		protocol: "fear",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "fear-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "fire",
		value: 0,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "此牌将被覆盖时：先抽取 1 张牌。然后，翻转另外 1 张牌。",
			en: "When this card would be covered:  First, draw 1 card. Then, flip 1 other card."
		},
		id: "fire-0",
		mid: {
			zh: "翻转另外 1 张牌。抽取 2 张牌。",
			en: "Flip 1 other card. Draw 2 cards."
		}
	},
	{
		protocol: "fire",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "fire-1",
		mid: {
			zh: "弃置 1 张手牌。如果如此做，删除 1 张牌。",
			en: "Discard 1 card. If you do, delete 1 card."
		}
	},
	{
		protocol: "fire",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "fire-2",
		mid: {
			zh: "弃置 1 张手牌。如果如此做，将 1 张牌返回手牌。",
			en: "Discard 1 card. If you do, return 1 card."
		}
	},
	{
		protocol: "fire",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "结束时：你可以弃置 1 张手牌。如果如此做，翻转 1 张牌。",
			en: "End:  You may discard 1 card. If you do, flip 1 card."
		},
		id: "fire-3",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "fire",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "fire-4",
		mid: {
			zh: "弃置至少 1 张手牌。抽取比本次弃牌数量多 1 张的牌。",
			en: "Discard 1 or more cards. Draw the amount discarded plus 1."
		}
	},
	{
		protocol: "fire",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "fire-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "gravity",
		value: 0,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "gravity-0",
		mid: {
			zh: "此列每有 2 张牌，就将你的 1 张牌库顶牌暗置打到此牌下方。",
			en: "For every 2 cards in this line, play the top card of your deck face-down under this card."
		}
	},
	{
		protocol: "gravity",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "gravity-1",
		mid: {
			zh: "抽取 2 张牌。将 1 张牌移入或移出此列。",
			en: "Draw 2 cards. Shift 1 card either to or from this line."
		}
	},
	{
		protocol: "gravity",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "gravity-2",
		mid: {
			zh: "翻转 1 张牌。将该牌移动至此列。",
			en: "Flip 1 card. Shift that card to this line."
		}
	},
	{
		protocol: "gravity",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "gravity-4",
		mid: {
			zh: "将 1 张暗置牌移动至此列。",
			en: "Shift 1 face-down card to this line."
		}
	},
	{
		protocol: "gravity",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "gravity-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "gravity",
		value: 6,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "gravity-6",
		mid: {
			zh: "对手将自己的牌库顶牌暗置打入此列。",
			en: "Your opponent plays the top card of their deck face-down in this line."
		}
	},
	{
		protocol: "hate",
		value: 0,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "hate-0",
		mid: {
			zh: "删除 1 张牌。",
			en: "Delete 1 card."
		}
	},
	{
		protocol: "hate",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "hate-1",
		mid: {
			zh: "弃置 3 张手牌。删除 1 张牌。删除 1 张牌。",
			en: "Discard 3 cards. Delete 1 card. Delete 1 card."
		}
	},
	{
		protocol: "hate",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "hate-2",
		mid: {
			zh: "删除自己数值最高的未覆盖牌。删除对手数值最高的未覆盖牌。",
			en: "Delete your highest value uncovered card. Delete your opponent's highest value uncovered card."
		}
	},
	{
		protocol: "hate",
		value: 3,
		top: {
			zh: "你删除牌后：抽取 1 张牌。",
			en: "After you delete cards:  Draw 1 card."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "hate-3",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "hate",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "此牌将被覆盖时：先删除此列中数值最低的 1 张被覆盖的牌。",
			en: "When this card would be covered:  First, delete the lowest value covered card in this line."
		},
		id: "hate-4",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "hate",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "hate-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "ice",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "对手在此列打出牌后：对手弃置 1 张手牌。",
			en: "After your opponent plays a card in this line:  Your opponent discards 1 card."
		},
		id: "ice-1",
		mid: {
			zh: "你可以移动此牌。",
			en: "You may shift this card."
		}
	},
	{
		protocol: "ice",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "ice-2",
		mid: {
			zh: "移动另外 1 张牌。",
			en: "Shift 1 other card."
		}
	},
	{
		protocol: "ice",
		value: 3,
		top: {
			zh: "结束时：如果此牌被覆盖，你可以移动此牌。",
			en: "End:  If this card is covered, you may shift it."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "ice-3",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "ice",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "此牌不能被翻转。",
			en: "This card cannot be flipped."
		},
		id: "ice-4",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "ice",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "ice-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "ice",
		value: 6,
		top: {
			zh: "如果你有手牌，你就不能抽牌。",
			en: "If you have any cards in your hand, you cannot draw cards."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "ice-6",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "life",
		value: 0,
		top: {
			zh: "结束时：如果此牌被覆盖，删除此牌。",
			en: "End:  If this card is covered, delete this card."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "life-0",
		mid: {
			zh: "在自己有牌的每一列中，将你的牌库顶牌暗置打入该列。",
			en: "Play the top card of your deck face-down in each line where you have a card."
		}
	},
	{
		protocol: "life",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "life-1",
		mid: {
			zh: "翻转 1 张牌。翻转 1 张牌。",
			en: "Flip 1 card. Flip 1 card."
		}
	},
	{
		protocol: "life",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "life-2",
		mid: {
			zh: "抽取 1 张牌。你可以翻转 1 张暗置牌。",
			en: "Draw 1 card. You may flip 1 face-down card."
		}
	},
	{
		protocol: "life",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "此牌将被覆盖时：先将你的牌库顶牌暗置打入另一列。",
			en: "When this card would be covered:  First, play the top card of your deck face-down in another line."
		},
		id: "life-3",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "life",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "life-4",
		mid: {
			zh: "如果此牌覆盖着其他牌，抽取 1 张牌。",
			en: "If this card is covering a card, draw 1 card."
		}
	},
	{
		protocol: "life",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "life-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "light",
		value: 0,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "light-0",
		mid: {
			zh: "翻转 1 张牌。抽取等同于该牌当前数值的牌。",
			en: "Flip 1 card. Draw cards equal to that card's value."
		}
	},
	{
		protocol: "light",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "结束时：抽取 1 张牌。",
			en: "End:  Draw 1 card."
		},
		id: "light-1",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "light",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "light-2",
		mid: {
			zh: "抽取 2 张牌。展示 1 张暗置牌。你可以移动或翻转该牌。",
			en: "Draw 2 cards. Reveal 1 face-down card. You may shift or flip that card."
		}
	},
	{
		protocol: "light",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "light-3",
		mid: {
			zh: "将此列中所有暗置牌移动至同一条其他列，保持它们在各自牌堆中的相对顺序。",
			en: "Shift all face-down cards in this line to another line."
		}
	},
	{
		protocol: "light",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "light-4",
		mid: {
			zh: "对手展示全部手牌。",
			en: "Your opponent reveals their hand."
		}
	},
	{
		protocol: "light",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "light-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "love",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "结束时：你可以将 1 张手牌交给对手。如果如此做，抽取 2 张牌。",
			en: "End:  You may give 1 card from your hand to your opponent. If you do, draw 2 cards."
		},
		id: "love-1",
		mid: {
			zh: "抽取对手的牌库顶牌。",
			en: "Draw the top card of your opponent's deck."
		}
	},
	{
		protocol: "love",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "love-2",
		mid: {
			zh: "对手抽取 1 张牌。补充手牌。",
			en: "Your opponent draws 1 card. Refresh."
		}
	},
	{
		protocol: "love",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "love-3",
		mid: {
			zh: "随机拿取对手的 1 张手牌。将你的 1 张手牌交给对手。",
			en: "Take 1 random card from your opponent's hand. Give 1 card from your hand to your opponent."
		}
	},
	{
		protocol: "love",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "love-4",
		mid: {
			zh: "展示你的 1 张手牌。翻转 1 张牌。",
			en: "Reveal 1 card from your hand. Flip 1 card."
		}
	},
	{
		protocol: "love",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "love-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "love",
		value: 6,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "love-6",
		mid: {
			zh: "对手抽取 2 张牌。",
			en: "Your opponent draws 2 cards."
		}
	},
	{
		protocol: "luck",
		value: 0,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "luck-0",
		mid: {
			zh: "声明一个数值。抽取 3 张牌。展示本次抽到的 1 张正面数值等于所声明数值的牌。你可以打出该牌。",
			en: "State a number. Draw 3 cards. Reveal 1 card drawn with the face-up value of your stated number. You may play it."
		}
	},
	{
		protocol: "luck",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "luck-1",
		mid: {
			zh: "将你的牌库顶牌暗置打出。翻转该牌，但忽略该次翻转所触发的中部指令。",
			en: "Play the top card of your deck face-down. Flip that card, ignoring its middle commands."
		}
	},
	{
		protocol: "luck",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "luck-2",
		mid: {
			zh: "弃置你的牌库顶牌。抽取等同于本次弃牌数值的牌。",
			en: "Discard the top card of your deck. Draw cards equal to the value of the discarded card."
		}
	},
	{
		protocol: "luck",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "luck-3",
		mid: {
			zh: "声明一个协议。弃置对手的牌库顶牌。如果该牌属于所声明的协议，删除 1 张牌。",
			en: "State a protocol. Discard the top card of your opponent's deck. If the discarded card matches the stated protocol, delete 1 card."
		}
	},
	{
		protocol: "luck",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "luck-4",
		mid: {
			zh: "弃置你的牌库顶牌。删除 1 张与该弃牌数值相同的牌，无论该牌是否被覆盖。",
			en: "Discard the top card of your deck. Delete 1 covered or uncovered card that shares a value with the discarded card."
		}
	},
	{
		protocol: "luck",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "luck-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "metal",
		value: 0,
		top: {
			zh: "对手在此列的总值减少 2。",
			en: "Your opponent's total value in this line is reduced by 2."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "metal-0",
		mid: {
			zh: "翻转 1 张牌。",
			en: "Flip 1 card."
		}
	},
	{
		protocol: "metal",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "metal-1",
		mid: {
			zh: "抽取 2 张牌。对手在其下一个回合不能编译。",
			en: "Draw 2 cards. Your opponent cannot compile on their next turn."
		}
	},
	{
		protocol: "metal",
		value: 2,
		top: {
			zh: "对手不能在此列暗置打牌。",
			en: "Your opponent cannot play cards face-down in this line."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "metal-2",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "metal",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "metal-3",
		mid: {
			zh: "抽取 1 张牌。选择其他一列，若该列至少有 8 张牌，删除该列中的所有牌。",
			en: "Draw 1 card. Delete all cards in 1 other line with 8 or more cards."
		}
	},
	{
		protocol: "metal",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "metal-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "metal",
		value: 6,
		top: {
			zh: "此牌将被覆盖或翻转时：先删除此牌。",
			en: "When this card would be covered or flipped:  First, delete this card."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "metal-6",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "mirror",
		value: 0,
		top: {
			zh: "对手在此列每有 1 张牌，你在此列的总值就增加 1。",
			en: "Your total value in this line is increased by 1 for each of your opponent's cards in this line."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "mirror-0",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "mirror",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "结束时：你可以将对手 1 张牌的中部指令视为写在此牌上，并执行该指令。",
			en: "End:  You may resolve the middle command of 1 of your opponent's cards as if it were on this card."
		},
		id: "mirror-1",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "mirror",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "mirror-2",
		mid: {
			zh: "交换自己的两个非空牌堆，保持每个牌堆内的相对顺序。",
			en: "Swap all of your cards in one of your stacks with another one of your stacks."
		}
	},
	{
		protocol: "mirror",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "mirror-3",
		mid: {
			zh: "翻转自己的 1 张牌。翻转同一列中对手的 1 张牌。",
			en: "Flip 1 of your cards. Flip 1 of your opponent's cards in the same line."
		}
	},
	{
		protocol: "mirror",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "对手抽牌后：抽取 1 张牌。",
			en: "After your opponent draws cards:  Draw 1 card."
		},
		id: "mirror-4",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "mirror",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "mirror-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "peace",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "结束时：如果你没有手牌，抽取 1 张牌。",
			en: "End:  If your hand is empty, draw 1 card."
		},
		id: "peace-1",
		mid: {
			zh: "双方分别弃置全部手牌，由你决定先后顺序。",
			en: "Both players discard their hand."
		}
	},
	{
		protocol: "peace",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "peace-2",
		mid: {
			zh: "抽取 1 张牌。将 1 张手牌暗置打出。",
			en: "Draw 1 card. Play 1 card face-down."
		}
	},
	{
		protocol: "peace",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "peace-3",
		mid: {
			zh: "你可以弃置 1 张手牌。翻转 1 张数值大于你当前手牌数量的牌。",
			en: "You may discard 1 card. Flip 1 card that has a value greater than the number of cards in your hand."
		}
	},
	{
		protocol: "peace",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "你在对手回合中弃牌后：抽取 1 张牌。",
			en: "After you discard cards during your opponent's turn:  Draw 1 card."
		},
		id: "peace-4",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "peace",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "peace-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "peace",
		value: 6,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "peace-6",
		mid: {
			zh: "如果你的手牌超过 1 张，翻转此牌。",
			en: "If you have more than 1 card in your hand, flip this card"
		}
	},
	{
		protocol: "plague",
		value: 0,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "对手不能在此列打牌。",
			en: "Your opponent cannot play cards in this line."
		},
		id: "plague-0",
		mid: {
			zh: "对手弃置 1 张手牌。",
			en: "Your opponent discards 1 card."
		}
	},
	{
		protocol: "plague",
		value: 1,
		top: {
			zh: "对手弃牌后：抽取 1 张牌。",
			en: "After your opponent discards cards:  Draw 1 card."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "plague-1",
		mid: {
			zh: "对手弃置 1 张手牌。",
			en: "Your opponent discards 1 card."
		}
	},
	{
		protocol: "plague",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "plague-2",
		mid: {
			zh: "弃置至少 1 张手牌。对手弃置比本次弃牌数量多 1 张的手牌。",
			en: "Discard 1 or more cards. Your opponent discards the amount of cards discarded plus 1."
		}
	},
	{
		protocol: "plague",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "plague-3",
		mid: {
			zh: "依次翻转其他每一张未覆盖且正面朝上的牌。",
			en: "Flip each other uncovered face-up card."
		}
	},
	{
		protocol: "plague",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "结束时：对手删除自己的 1 张暗置牌。你可以翻转此牌。",
			en: "End:  Your opponent deletes 1 of their face-down cards. You may flip this card."
		},
		id: "plague-4",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "plague",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "plague-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "psychic",
		value: 0,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "psychic-0",
		mid: {
			zh: "抽取 2 张牌。对手弃置 2 张手牌，然后展示全部手牌。",
			en: "Draw 2 cards. Your opponent discards 2 cards, then reveals their hand."
		}
	},
	{
		protocol: "psychic",
		value: 1,
		top: {
			zh: "对手只能暗置打牌。",
			en: "Your opponent can only play cards face-down."
		},
		bottom: {
			zh: "开始时：翻转此牌。",
			en: "Start:  Flip this card."
		},
		id: "psychic-1",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "psychic",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "psychic-2",
		mid: {
			zh: "对手弃置 2 张手牌。重排对手的协议。",
			en: "Your opponent discards 2 cards. Rearrange their protocols."
		}
	},
	{
		protocol: "psychic",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "psychic-3",
		mid: {
			zh: "对手弃置 1 张手牌。移动对手的 1 张牌。",
			en: "Your opponent discards 1 card. Shift 1 of their cards."
		}
	},
	{
		protocol: "psychic",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "结束时：你可以将对手的 1 张牌返回手牌。如果如此做，翻转此牌。",
			en: "End:  You may return 1 of your opponent's cards. If you do, flip this card."
		},
		id: "psychic-4",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "psychic",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "psychic-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "smoke",
		value: 0,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "smoke-0",
		mid: {
			zh: "在有暗置牌的每一列中，将你的牌库顶牌暗置打入该列。",
			en: "Play the top card of your deck face-down in each line with a face-down card."
		}
	},
	{
		protocol: "smoke",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "smoke-1",
		mid: {
			zh: "翻转自己的 1 张牌。你可以移动该牌。",
			en: "Flip 1 of your cards. You may shift that card."
		}
	},
	{
		protocol: "smoke",
		value: 2,
		top: {
			zh: "此列每有 1 张暗置牌，你在此列的总值就增加 1。",
			en: "Your total value in this line is increased by 1 for each face-down card in this line."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "smoke-2",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "smoke",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "smoke-3",
		mid: {
			zh: "将 1 张手牌暗置打入有暗置牌的一列。",
			en: "Play 1 card face-down in a line with a face-down card."
		}
	},
	{
		protocol: "smoke",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "smoke-4",
		mid: {
			zh: "移动 1 张被覆盖的暗置牌。",
			en: "Shift 1 covered face-down card."
		}
	},
	{
		protocol: "smoke",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "smoke-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "speed",
		value: 0,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "speed-0",
		mid: {
			zh: "打出 1 张手牌。",
			en: "Play 1 card."
		}
	},
	{
		protocol: "speed",
		value: 1,
		top: {
			zh: "你清理缓存后：抽取 1 张牌。",
			en: "After you clear cache:  Draw 1 card."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "speed-1",
		mid: {
			zh: "抽取 2 张牌。",
			en: "Draw 2 cards."
		}
	},
	{
		protocol: "speed",
		value: 2,
		top: {
			zh: "此牌将因编译而被删除时：改为移动此牌，无论此牌是否被覆盖。",
			en: "When this card would be deleted by compiling:  Shift this card, even if this card is covered."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "speed-2",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "speed",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "结束时：你可以移动自己的 1 张牌。如果如此做，翻转此牌。",
			en: "End:  You may shift 1 of your cards. If you do, flip this card."
		},
		id: "speed-3",
		mid: {
			zh: "移动自己的另外 1 张牌。",
			en: "Shift 1 of your other cards."
		}
	},
	{
		protocol: "speed",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "speed-4",
		mid: {
			zh: "移动对手的 1 张暗置牌。",
			en: "Shift 1 of your opponent's face-down cards."
		}
	},
	{
		protocol: "speed",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "speed-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "spirit",
		value: 0,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "跳过你的检查缓存阶段。",
			en: "Skip your check cache phase."
		},
		id: "spirit-0",
		mid: {
			zh: "补充手牌。抽取 1 张牌。",
			en: "Refresh. Draw 1 card."
		}
	},
	{
		protocol: "spirit",
		value: 1,
		top: {
			zh: "你的牌可以正面打入任意一列，无须匹配协议。",
			en: "When you play cards face-up, they may be played without matching protocols."
		},
		bottom: {
			zh: "开始时：弃置 1 张手牌，或翻转此牌。",
			en: "Start:  Either discard 1 card or flip this card."
		},
		id: "spirit-1",
		mid: {
			zh: "抽取 2 张牌。",
			en: "Draw 2 cards."
		}
	},
	{
		protocol: "spirit",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "spirit-2",
		mid: {
			zh: "你可以翻转 1 张牌。",
			en: "You may flip 1 card."
		}
	},
	{
		protocol: "spirit",
		value: 3,
		top: {
			zh: "你抽牌后：你可以移动此牌，无论此牌是否被覆盖。",
			en: "After you draw cards:  You may shift this card, even if this card is covered."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "spirit-3",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "spirit",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "spirit-4",
		mid: {
			zh: "交换你的 2 个协议的位置。",
			en: "Swap the positions of 2 of your protocols"
		}
	},
	{
		protocol: "spirit",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "spirit-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "time",
		value: 0,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "time-0",
		mid: {
			zh: "打出弃牌堆中的 1 张牌。将弃牌堆洗入牌库。",
			en: "Play 1 card from your trash. Shuffle your trash into your deck."
		}
	},
	{
		protocol: "time",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "time-1",
		mid: {
			zh: "翻转 1 张被覆盖的牌。弃置你的整个牌库。",
			en: "Flip 1 covered card. Discard your entire deck."
		}
	},
	{
		protocol: "time",
		value: 2,
		top: {
			zh: "你洗牌后：抽取 1 张牌。然后，你可以移动此牌。",
			en: "After you shuffle your deck: Draw 1 card. Then, you may shift this card."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "time-2",
		mid: {
			zh: "如果你的弃牌堆中有牌，你可以将弃牌堆洗入牌库。",
			en: "If there are any cards in your trash, you may shuffle your trash into your deck."
		}
	},
	{
		protocol: "time",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "time-3",
		mid: {
			zh: "展示弃牌堆中的 1 张牌。将该牌暗置打入另一列。",
			en: "Reveal 1 card from your trash. Play it face-down in another line."
		}
	},
	{
		protocol: "time",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "time-4",
		mid: {
			zh: "抽取 2 张牌。弃置 2 张手牌。",
			en: "Draw 2 cards. Discard 2 cards."
		}
	},
	{
		protocol: "time",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "time-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "unity",
		value: 0,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "此牌将被团结协议牌覆盖时：先翻转 1 张牌，或抽取 1 张牌。",
			en: "When this card would be covered by a Unity card:  First, either flip 1 card or draw 1 card."
		},
		id: "unity-0",
		mid: {
			zh: "如果场上还有其他团结协议牌，翻转 1 张牌，或抽取 1 张牌。",
			en: "If there is another Unity card in the field, either flip 1 card or draw 1 card."
		}
	},
	{
		protocol: "unity",
		value: 1,
		top: {
			zh: "开始时：如果此牌被覆盖，你可以移动此牌。",
			en: "Start:  If this card is covered, you may shift this card."
		},
		bottom: {
			zh: "团结协议牌可以正面打入此列。",
			en: "Unity cards may be played face-up in this line."
		},
		id: "unity-1",
		mid: {
			zh: "如果场中有至少 5 张团结牌，将团结协议翻至已编译面。",
			en: "If there are 5 or more Unity cards in the field, flip the Unity protocol to the compiled side."
		}
	},
	{
		protocol: "unity",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "unity-2",
		mid: {
			zh: "抽取等同于场上团结协议牌数量的牌。",
			en: "Draw cards equal to the number of Unity cards in the field."
		}
	},
	{
		protocol: "unity",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "unity-3",
		mid: {
			zh: "如果场上还有其他团结协议牌，你可以翻转 1 张正面朝上的牌。",
			en: "If there is another Unity card in the field, you may flip 1 face-up card."
		}
	},
	{
		protocol: "unity",
		value: 4,
		top: {
			zh: "结束时：如果你没有手牌，展示你的牌库，从中抽取所有团结牌，然后洗混你的牌库。",
			en: "End: If your hand is empty, reveal your deck, draw all Unity cards from it, and shuffle your deck."
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "unity-4",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "unity",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "unity-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "war",
		value: 0,
		top: {
			zh: "你补充手牌后：你可以翻转此牌。",
			en: "After you refresh:  You may flip this card."
		},
		bottom: {
			zh: "对手抽牌后：你可以删除 1 张牌。",
			en: "After your opponent draws cards:  You may delete 1 card."
		},
		id: "war-0",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "war",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "对手补充手牌后：弃置任意数量的手牌。补充手牌。",
			en: "After your opponent refreshes:  Discard any number of cards. Refresh."
		},
		id: "war-1",
		mid: {
			zh: "",
			en: ""
		}
	},
	{
		protocol: "war",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "对手编译后：对手弃置全部手牌。",
			en: "After your opponent compiles:  Your opponent discards their hand."
		},
		id: "war-2",
		mid: {
			zh: "翻转 1 张牌。",
			en: "Flip 1 card."
		}
	},
	{
		protocol: "war",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "对手弃牌后：你可以暗置打出 1 张手牌。",
			en: "After your opponent discards cards:  You may play 1 card face-down."
		},
		id: "war-3",
		mid: {
			zh: "抽取 1 张牌。",
			en: "Draw 1 card."
		}
	},
	{
		protocol: "war",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "war-4",
		mid: {
			zh: "对手弃置 1 张手牌。",
			en: "Your opponent discards 1 card."
		}
	},
	{
		protocol: "war",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "war-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	},
	{
		protocol: "water",
		value: 0,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "water-0",
		mid: {
			zh: "翻转另外 1 张牌。翻转此牌。",
			en: "Flip 1 other card. Flip this card."
		}
	},
	{
		protocol: "water",
		value: 1,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "water-1",
		mid: {
			zh: "在其他每一列中，将你的牌库顶牌暗置打入该列。",
			en: "Play the top card of your deck face-down in each other line."
		}
	},
	{
		protocol: "water",
		value: 2,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "water-2",
		mid: {
			zh: "抽取 2 张牌。重排你的协议。",
			en: "Draw 2 cards. Rearrange your protocols."
		}
	},
	{
		protocol: "water",
		value: 3,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "water-3",
		mid: {
			zh: "将某一列中所有数值为 2 的牌返回手牌。",
			en: "Return all cards with a value of 2 in 1 line."
		}
	},
	{
		protocol: "water",
		value: 4,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "water-4",
		mid: {
			zh: "将自己的 1 张牌返回手牌。",
			en: "Return 1 of your cards."
		}
	},
	{
		protocol: "water",
		value: 5,
		top: {
			zh: "",
			en: ""
		},
		bottom: {
			zh: "",
			en: ""
		},
		id: "water-5",
		mid: {
			zh: "弃置 1 张手牌。",
			en: "You discard 1 card."
		}
	}
], me = {
	...de,
	ambush: "伏击",
	envy: "嫉妒",
	fulcrum: "支点",
	gluttony: "暴食",
	greed: "贪婪",
	lust: "色欲",
	momentum: "动量",
	nova: "新星",
	overwhelm: "压倒",
	pride: "傲慢",
	sloth: "懒惰",
	wrath: "愤怒",
	flexible: "柔性",
	rigid: "刚性",
	inert: "惰性"
}, he = {
	...fe,
	...ae,
	life: "#63c5b8",
	gravity: "#bc83d0"
}, ge = (e) => ({
	...e,
	zh: Object.entries(me).reduce((e, [t, n]) => e.replaceAll(t.charAt(0).toUpperCase() + t.slice(1), n), e.zh)
}), _e = [...pe, ...D.map((e) => ({
	...e,
	top: ge(e.top),
	mid: ge(e.mid),
	bottom: ge(e.bottom)
}))], j = Object.fromEntries(_e.map((e) => [e.id, e])), ve = [
	"定义参数",
	"数据传输",
	"归并排序",
	"身份认证",
	"分布式拒绝服务",
	"双因素认证",
	"握手",
	"加密",
	"漏洞利用",
	"基准测试",
	"瓶颈",
	"根权限"
];
function M(e) {
	return t.getState().locale === "zh" ? ve[e] : oe[e]?.name;
}
//#endregion
//#region src/games/compile3/meta.ts
var ye = {
	id: "compile3",
	tier: "alpha",
	mechanics: [
		"hand-management",
		"drafting",
		"race"
	],
	interactionTags: [],
	nameKey: "games.compile3.name",
	descKey: "games.compile3.desc",
	rulesKey: "games.compile3.rules",
	icon: "💠",
	iconImg: "games/compile3.webp",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/10329057516993603131/84F941766E6FCD910130C9745D178259CD6FFC4F/" },
	minPlayers: 1,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#277d91",
	releasedAt: "2026-11-10T13:10:00+08:00",
	search: {
		py: "yi shi jie",
		init: "ysj"
	},
	hotseat: "cover"
}, be = r.object({
	aux3: r.boolean().default(!1),
	control: r.boolean().default(!0),
	draft: r.boolean().default(!0),
	scenario: r.int().min(0).max(11).default(0)
}).default({
	aux3: !1,
	control: !0,
	draft: !0,
	scenario: 0
}), N = r.discriminatedUnion("type", [r.object({
	type: r.literal("choose"),
	id: r.string()
}), r.object({
	type: r.literal("tick"),
	now: r.number()
})]), xe = r.object({
	token: r.int(),
	face: r.string().nullable(),
	up: r.boolean(),
	value: r.number(),
	covered: r.boolean()
}), Se = r.object({
	id: r.string(),
	kind: r.string(),
	card: r.string().optional(),
	token: r.int().optional(),
	side: r.int().optional(),
	line: r.int().optional(),
	order: r.array(r.string()).optional(),
	up: r.boolean().optional(),
	source: r.string().optional(),
	slot: r.enum([
		"top",
		"mid",
		"bottom"
	]).optional()
}), P = r.object({
	phase: r.enum([
		"draft",
		"resolve",
		"choose",
		"done"
	]),
	turn: r.int(),
	round: r.int(),
	sides: r.array(r.string()),
	protocols: r.array(r.array(r.object({
		name: r.string(),
		compiled: r.boolean()
	}))),
	field: r.array(r.array(r.array(xe))),
	totals: r.array(r.array(r.number())),
	handCounts: r.array(r.int()),
	deckCounts: r.array(r.int()),
	trash: r.array(r.array(r.string())),
	control: r.int().nullable(),
	useControl: r.boolean(),
	solo: r.boolean(),
	scenario: r.int(),
	available: r.array(r.string()),
	pending: r.object({
		actor: r.string(),
		kind: r.string(),
		source: r.string().nullable(),
		count: r.int()
	}).nullable(),
	revealed: r.array(r.object({
		side: r.int(),
		cards: r.array(r.string())
	})),
	last: r.object({
		kind: r.string(),
		side: r.int(),
		line: r.int().optional(),
		token: r.int().optional()
	}).nullable(),
	winner: r.int().nullable(),
	log: r.array(r.object({
		kind: r.string(),
		side: r.int(),
		n: r.int().optional(),
		line: r.int().optional(),
		card: r.string().optional()
	}))
}), Ce = r.object({
	hand: r.array(r.string()),
	faces: r.record(r.string(), r.string()),
	options: r.array(Se),
	decision: r.int()
}), we = {
	move: 420,
	compile: 850,
	phase: 40,
	reveal: 900
}, Te = (e) => 1 - e, Ee = (e) => JSON.stringify([
	e.protocols,
	e.field,
	e.hands,
	e.decks,
	e.trash,
	e.control
]), De = (e, t) => e.solo ? e.sides[0] : e.sides[t], F = (e, t) => {
	for (let n = 0; n < 2; n++) for (let r = 0; r < 3; r++) {
		let i = e.field[n][r], a = i.findIndex((e) => e.token === t);
		if (a >= 0) return {
			side: n,
			line: r,
			index: a,
			card: i[a],
			stack: i
		};
	}
}, I = (e) => e.field.flatMap((e, t) => e.flatMap((e, n) => e.map((r, i) => ({
	side: t,
	line: n,
	index: i,
	card: r,
	stack: e
})))), Oe = (e) => e.index === e.stack.length - 1, L = (e) => e.up ? O[e.id].value : 2, ke = (e, t) => t.card.up && !(e.solo && t.side === 1 && e.config.scenario < 6);
function R(e, t, n) {
	if (!ke(e, t) || !O[t.card.id][n].en || n !== "top" && !Oe(t)) return !1;
	if (n === "mid") return !0;
	let r = n === "top" ? "inert-0" : "inert-1";
	return !I(e).some((i) => i.line === t.line && i.card.token !== t.card.token && ke(e, i) && i.card.id === r && (n === "top" || Oe(i)));
}
var Ae = (e, t) => ({
	token: e.card.token,
	rev: e.card.rev,
	epoch: e.card.epoch,
	slot: t
});
function je(e, t) {
	if (!t) return !0;
	let n = F(e, t.token);
	return !!n && n.card.rev === t.rev && (t.slot === "top" || n.card.epoch === t.epoch) && R(e, n, t.slot);
}
function Me(e, t, n) {
	return {
		t: "command",
		side: t.side,
		src: Ae(t, n),
		card: t.card.id
	};
}
function Ne(e) {
	let t = [[
		0,
		0,
		0
	], [
		0,
		0,
		0
	]];
	for (let n = 0; n < 3; n++) {
		let r = I(e).filter((e) => e.line === n), i = Math.max(0, ...r.map((e) => L(e.card))), a = r.some((t) => t.card.id === "wrath-0" && R(e, t, "top"));
		for (let o of r) {
			let r = L(o.card);
			(!a || r !== i) && (t[o.side][n] += r), R(e, o, "top") && (o.card.id === "envy-0" && (t[o.side][n] += Math.max(0, ...e.field[Te(o.side)][n].map(L))), o.card.id === "lust-0" && (t[0][n] += 10, t[1][n] += 10), o.card.id === "sloth-0" && o.stack.slice(o.index + 1).some((e) => e.up && O[e.id].protocol === "sloth") && (t[o.side][n] += 5));
		}
	}
	return t;
}
function Pe(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
var z = (e, t) => {
	e.queue.unshift(...t);
};
function B(e, t, n, r, i, a) {
	e.last = {
		kind: t,
		side: n,
		...r === void 0 ? {} : { line: r }
	}, e.log.push({
		kind: t,
		side: n,
		...r === void 0 ? {} : { line: r },
		...i === void 0 ? {} : { n: i },
		...a === void 0 ? {} : { card: a }
	});
}
function V(e, t, n, r, i, a, o) {
	let s = typeof a == "string" ? void 0 : a?.up ? a.id : void 0;
	e.fx.push({
		kind: "move",
		...e.fx.length ? { with: !0 } : {},
		rid: e.sides[n],
		data: {
			kind: t,
			from: r,
			to: i,
			...s ? { card: s } : {},
			...o === void 0 ? {} : { token: o }
		},
		for: [e.sides[n]],
		secret: { ...a ? { card: typeof a == "string" ? a : a.id } : {} }
	}), e.beat = t === "compile" ? we.compile : we.move;
}
function H(e, t, n, r, i = null) {
	r.length && (e.turnOffered = !0, e.decision++, e.pending = {
		kind: t,
		actor: De(e, n),
		source: i,
		options: r.map((t, n) => ({
			...t,
			view: {
				...t.view,
				id: `${e.decision}:${n}`
			}
		}))
	}, e.phase = "choose");
}
function Fe(e, t) {
	t.length && z(e, [{
		t: "order",
		side: e.turn,
		list: t
	}]);
}
function Ie(e, t, n, r, i = !1) {
	Fe(e, I(e).flatMap((a) => {
		let o = a.card.id, s = [];
		return t === "control" && a.side !== n && (o === "pride-6" && s.push("top"), o === "lust-4" && s.push("bottom")), t === "compile" && (o === "pride-0" && a.side === n || o === "momentum-1" || o === "momentum-6") && s.push("top"), t === "rearrange" && (o === "momentum-1" || o === "nova-2" && a.side === n) && s.push("bottom"), t === "cache" && (o === "gluttony-0" && a.side === n && s.push("top"), o === "gluttony-1" && s.push("bottom")), t === "refresh" && a.side === n && (o === "gluttony-4" || o === "sloth-1") && s.push("bottom"), t === "delete" && a.side === n && o === "greed-0" && s.push("bottom"), t === "play" && a.side !== n && o === "envy-3" && a.line === r && s.push("bottom"), (t === "actionDown" || i) && a.side === n && o === "rigid-2" && s.push("bottom"), s.filter((t) => R(e, a, t)).map((n) => ({
			...Me(e, a, n),
			line: r,
			mode: t
		}));
	}));
}
function Le(e, t) {
	e.config.control && e.control !== t && (e.control = t, B(e, "control", t ?? e.turn), e.fx.push({
		kind: "control",
		data: { side: t }
	}), e.beat = we.move, t !== null && Ie(e, "control", t));
}
function Re(e, t, n, r = t) {
	let i = 0;
	for (let a = 0; a < n; a++) {
		!e.decks[r].length && e.trash[r].length && (e.decks[r] = Pe(e, e.trash[r]), e.trash[r] = []);
		let n = e.decks[r].shift();
		if (!n) break;
		e.hands[t].push(n), i++;
	}
	i && (B(e, "draw", t, void 0, i), V(e, "draw", t, `deck:${r}`, `hand:${t}`));
}
function ze(e, t) {
	let n = t.at(-1);
	if (!n) return;
	let r = F(e, n.token);
	r && R(e, r, "mid") && z(e, [Me(e, r, "mid")]);
}
function Be(e, t, n) {
	return ["shift", "flip"].includes(n) && t.card.id === "rigid-7" && R(e, t, "bottom");
}
function Ve(e, t, n, r) {
	let i = Oe(t), a = `stack:${t.side}:${t.line}`, [o] = t.stack.splice(t.index, 1);
	n !== "shift" && o.rev++, n === "delete" && e.trash[t.side].push(o.id), n === "return" && e.hands[t.side].push(o.id), B(e, n, t.side, t.line, 1, o.up ? o.id : void 0), n === "shift" ? z(e, [{
		t: "commit",
		side: t.side,
		line: r,
		card: o.id,
		token: o.token,
		up: o.up,
		n: o.rev,
		epoch: o.epoch,
		flag: !0,
		from: a,
		filter: i ? "shiftUncovered" : "shiftCovered"
	}]) : V(e, n, t.side, a, `${n === "delete" ? "trash" : "hand"}:${t.side}`, o), i && ze(e, t.stack);
}
var He = (e) => e.length ? e.flatMap((t, n) => He(e.filter((e, t) => n !== t)).map((e) => [t, ...e])) : [[]];
function Ue(e, t, n, r = !1, i = !1) {
	let a = e.protocols[n].map((e) => e.name);
	return [...He(a).filter((e) => e.some((e, t) => e !== a[t]) && (!r || e.filter((e, t) => e !== a[t]).length === 2)).map((e) => ({
		view: {
			kind: "rearrange",
			side: n,
			order: e
		},
		ops: [{
			t: "rearrange",
			side: t,
			n,
			order: e
		}]
	})), ...i ? [{
		view: { kind: "skip" },
		ops: []
	}] : []];
}
function We(e, t) {
	if (I(e).some((n) => n.side !== t && n.card.id === "lust-0" && R(e, n, "bottom") && e.control === n.side)) return [];
	let n = Ne(e);
	return [
		0,
		1,
		2
	].filter((e) => n[t][e] >= 10 && n[t][e] > n[Te(t)][e]);
}
function Ge(e, t) {
	e.winner = t, e.phase = "done", e.queue = [], e.pending = null;
}
function Ke(e) {
	for (let t = 0; t < 2; t++) e.decks[t] = Pe(e, D.filter((n) => e.protocols[t].some((e) => e.name === n.protocol)).map((e) => e.id)), Re(e, t, 5);
	e.phase = "resolve", z(e, [{
		t: "phase",
		side: 0,
		mode: "start"
	}]);
}
function qe(e, t, n) {
	let r = be.parse(e), i = t.length === 1, a = {
		config: r,
		seed: n,
		cursor: 0,
		sides: [t[0], t[1] ?? "$compile-bot"],
		solo: i,
		turn: 0,
		round: 1,
		protocols: [[], []],
		field: [[
			[],
			[],
			[]
		], [
			[],
			[],
			[]
		]],
		hands: [[], []],
		decks: [[], []],
		trash: [[], []],
		control: null,
		phase: "draft",
		queue: [],
		pending: null,
		decision: 0,
		nextToken: 1,
		available: [...C, ...r.aux3 ? ie : []],
		draftAt: 0,
		winner: null,
		beat: we.move,
		revealed: [],
		last: null,
		log: [],
		fx: [],
		idleTurns: 0,
		turnProgress: !1,
		turnOffered: !1
	};
	if (i) {
		let e = oe[r.scenario].protocols;
		a.protocols[1] = e.map((e) => ({
			name: e,
			compiled: !1
		})), a.available = a.available.filter((t) => !e.includes(t));
	} else r.draft || (a.protocols = [[
		"overwhelm",
		"momentum",
		"gluttony"
	], [
		"fulcrum",
		"sloth",
		"ambush"
	]].map((e) => e.map((e) => ({
		name: e,
		compiled: !1
	}))), Ke(a));
	a.phase === "draft" && Je(a);
	let o = a.fx;
	return a.fx = [], {
		state: a,
		fx: o
	};
}
function Je(e) {
	let t = e.solo ? 0 : [
		0,
		1,
		1,
		0,
		0,
		1
	][e.draftAt];
	e.turn = t, H(e, "draft", t, e.available.map((e) => ({
		view: {
			kind: "draft",
			card: e
		},
		ops: [{
			t: "draft",
			side: t,
			card: e
		}]
	}))), e.phase = "draft";
}
function Ye(e, t, n, r) {
	return e.protocols.some((e) => e[r]?.name === O[n].protocol) || e.field[t][r].some((t) => {
		let n = F(e, t.token);
		return t.id === "lust-2" && R(e, n, "bottom");
	});
}
function Xe(e, t, n = "any", r, i) {
	return (i ? [i] : e.solo && t === 1 ? e.hands[t].slice(0, 1) : e.hands[t]).flatMap((i) => [
		0,
		1,
		2
	].filter((e) => r === void 0 || e === r).flatMap((r) => [!0, !1].filter((e) => n !== "down" || !e).filter((n) => !n || Ye(e, t, i, r)).map((e) => ({
		view: {
			kind: "play",
			card: i,
			side: t,
			line: r,
			up: e
		},
		ops: [{
			t: "play",
			side: t,
			card: i,
			line: r,
			up: e
		}]
	}))));
}
function Ze(e, t) {
	let n = t.src ? F(e, t.src.token) : void 0, r = t.side, i = Te(r), a = I(e).filter((e) => t.filter?.includes("all") || t.filter?.includes("covered") ? !0 : Oe(e)), o = t.filter ?? "";
	if (o.includes("own") && (a = a.filter((e) => e.side === r)), o.includes("opp") && (a = a.filter((e) => e.side === i)), o.includes("covered") && (a = a.filter((e) => !Oe(e))), o.includes("other") && (a = a.filter((e) => e.card.token !== t.src?.token)), o.includes("faceup") && (a = a.filter((e) => e.card.up)), o.includes("down") && (a = a.filter((e) => !e.card.up)), o.includes("stack") && (a = a.filter((e) => e.line === n?.line && e.side === r)), o.includes("different") && (a = a.filter((e) => e.line !== n?.line)), o.includes("less") && (a = a.filter((e) => L(e.card) < (n?.stack.length ?? 0))), o.includes("lowest") || o.includes("highest")) {
		let e = o.includes("lowest") ? Math.min(...a.map((e) => L(e.card))) : Math.max(...a.map((e) => L(e.card)));
		a = a.filter((t) => L(t.card) === e);
	}
	t.token !== void 0 && (a = I(e).filter((e) => e.card.token === t.token));
	let s = (t.mode ?? "flip").split("|"), c = a.flatMap((n) => s.flatMap((i) => Be(e, n, i) ? [] : (i === "shift" ? [
		0,
		1,
		2
	].filter((e) => e !== n.line && (t.line === void 0 || e === t.line)) : [n.line]).map((e) => ({
		view: {
			kind: i,
			token: n.card.token,
			line: e,
			side: n.side
		},
		ops: [{
			t: i,
			side: r,
			token: n.card.token,
			line: e
		}, ...(t.list ?? []).map((e) => ({
			...e,
			flag: n.side === r
		}))]
	}))));
	t.mode === "shiftOrSwap" && c.splice(0, c.length, ...Qe(e, {
		...t,
		mode: "shift"
	}), ...Ue(e, r, r, !0)), t.optional && c.push({
		view: { kind: "skip" },
		ops: []
	}), H(e, t.mode ?? "flip", r, c, n?.card.id ?? null);
}
function Qe(e, t) {
	let n = e.pending, r = e.phase;
	Ze(e, t);
	let i = e.pending?.options.map(({ view: e, ops: t }) => ({
		view: e,
		ops: t
	})) ?? [];
	return e.pending = n, e.phase = r, i;
}
function $e(e, t) {
	let n = F(e, t.src.token), r = n.side, i = Te(r), a = t.src.slot, o = (e, n = {}) => ({
		t: e,
		side: r,
		src: t.src,
		...n
	}), s = (e, t = r) => o("draw", {
		n: e,
		side: t
	}), c = (e, t = r) => o("discard", {
		n: e,
		side: t
	}), l = (e, t = "", n = !1, r = {}) => o("manipulate", {
		mode: e,
		filter: t,
		optional: n,
		...r
	}), u = (e, t = {}) => o("deckPlay", {
		line: e,
		...t
	}), d = (e) => o("control", { n: e ?? -1 }), f = Ne(e), p = [
		0,
		1,
		2
	].filter((e) => f[r][e] > f[i][e]), m = [
		0,
		1,
		2
	].filter((e) => f[r][e] < f[i][e]), h = (e) => o(e, { token: n.card.token }), g = (e) => o("each", { list: e });
	if (a === "top") switch (n.card.id) {
		case "pride-0": return [o("refresh")];
		case "pride-6": return [h("flip")];
		case "gluttony-0": return [u()];
		case "gluttony-3": {
			let e = n.stack[n.index + 1];
			return e?.up ? [o("delete", { token: e.token })] : [];
		}
		case "overwhelm-2": return [g([
			0,
			1,
			2
		].map((e) => u(e))), h("flip")];
		case "overwhelm-6": return f[i][n.line] > f[r][n.line] ? [h("flip")] : [];
		case "fulcrum-0": return e.hands[r].length === 0 ? [c(2, i)] : [];
		case "momentum-1": return [u(n.line)];
		case "momentum-6": return [h("delete")];
		case "nova-0": return [o("group", {
			mode: "delete",
			filter: "five"
		})];
		case "flexible-2": {
			let e = n.stack[n.index + 1];
			return e && !e.up ? [l("shift", "", !0, { token: e.token })] : [];
		}
		case "rigid-7": return [o("drawOrPlay", { side: i })];
		default: return [];
	}
	if (a === "bottom") switch (n.card.id) {
		case "envy-1": return e.control === i ? [d(r)] : [];
		case "envy-3": return [u(n.line)];
		case "overwhelm-3": return e.hands[r].length >= 5 ? [u(n.line)] : [];
		case "pride-2": return p.includes(n.line) ? [s(1)] : [];
		case "lust-3": return e.control === r ? [o("optional", { list: [d(null), l("flip")] })] : [];
		case "lust-4": return [s(1)];
		case "gluttony-1": return [l("delete")];
		case "gluttony-4": return [s(1)];
		case "nova-0": return [o("novaUnder")];
		case "nova-2": return [l("shift", "down", !0)];
		case "momentum-1": return [c(1), s(1)];
		case "greed-0": return [s(1)];
		case "greed-1": return [o("compileChoice")];
		case "greed-2": return [l("return", "own", !0)];
		case "sloth-1": return [u(n.line)];
		case "sloth-2": return [o("bottomHand", { optional: !0 })];
		case "wrath-1": return e.control === r ? [d(null), l("delete", "faceup")] : [];
		case "flexible-4": return [o("optional", { list: [s(2), h("flip")] })];
		case "rigid-1": return [g([
			0,
			1,
			2
		].filter((t) => t !== n.line && e.field[i][t].at(-1)?.up === !1).map((e) => o("handPlay", { line: e })))];
		case "rigid-2": return [u(t.line)];
		default: return [];
	}
	if (O[n.card.id].mid.en === "Discard 1 card.") return [c(1)];
	switch (n.card.id) {
		case "envy-1": return e.control === i ? [l("flip", "", !0)] : [];
		case "envy-2": return [s(e.hands[i].length)];
		case "envy-4": return e.protocols[i].filter((e) => e.compiled).length > e.protocols[r].filter((e) => e.compiled).length ? [l("flip")] : [];
		case "pride-0": return [l("shift", e.control === r ? "other" : "own")];
		case "pride-2": return [s(p.length)];
		case "pride-3": return [l("flip", "own down")];
		case "pride-4": return e.control === r ? [l("shift", "opp", !0, { line: n.line })] : [];
		case "pride-6": return e.control === i ? [h("flip")] : [];
		case "lust-0": return [d(r)];
		case "lust-2": return [l("shift", "opp covered", !0, { line: n.line })];
		case "lust-3": return [o("randomPlay", { side: i })];
		case "lust-4": return [o("revealHand"), d(e.control === i ? null : e.control)];
		case "lust-6": return [c(1), o("handPlay", {
			side: i,
			line: n.line
		})];
		case "overwhelm-1": return [g(p.map((e) => u(e)))];
		case "overwhelm-2": return [g([
			0,
			1,
			2
		].map((e) => u(e, { side: i })))];
		case "overwhelm-4": return e.field[r].flat().length > e.field[i].flat().length ? [l("delete", "opp covered lowest")] : [];
		case "ambush-0": return [s(3), l("flip", "own down")];
		case "ambush-1": return [o("multiFlip", {
			ids: I(e).filter((e) => e.side === r && e.card.token !== n.card.token && L(e.card) <= 1).map((e) => e.card.token),
			flag: !0
		})];
		case "ambush-2": return [l("shift", "own covered lowest")];
		case "ambush-3": return [l("flip", "opp faceup highest")];
		case "ambush-4": return e.field[r].some((e) => e.at(-1)?.up === !1) ? [s(1)] : [];
		case "fulcrum-0": return e.hands[r].length === 0 ? [c(1, i)] : [];
		case "fulcrum-1": return [g(I(e).filter((e) => e.card.token !== n.card.token && e.card.up && Oe(e)).map((e) => o("flip", {
			token: e.card.token,
			line: e.line
		}))), o("swapStacks")];
		case "fulcrum-2": return e.hands[r].length === 2 ? [l("delete", "opp")] : [];
		case "fulcrum-3": return [s(1), o("swapEnds")];
		case "fulcrum-4": return e.hands[r].length === 4 ? [s(1)] : [];
		case "gluttony-0": return [l("return", "other"), s(1)];
		case "gluttony-1":
		case "gluttony-3":
		case "momentum-3": return [s(2)];
		case "gluttony-2": return [s(e.hands[r].length)];
		case "nova-0": return e.control === null ? [] : [o("arrangeChoice", {
			side: e.control,
			n: r,
			mode: "swap"
		})];
		case "nova-1": return [c(n.stack.length, i)];
		case "nova-2": return n.stack.slice(n.index - 1, n.index).some((e) => e.up && O[e.id].protocol === "nova") ? [o("arrangeChoice", {
			n: r,
			optional: !0
		})] : [d(r)];
		case "nova-3": return [l("shift", "less")];
		case "nova-4": return [l("flip", "less")];
		case "momentum-0": return [g(e.protocols[r].flatMap((e, t) => e.compiled ? [u(t)] : []))];
		case "momentum-4": return [o("arrangeChoice", { n: r })];
		case "greed-0": return [c(e.hands[r].length), l("delete")];
		case "greed-2": return [c(1, i)];
		case "greed-3": return [l("shift", "own covered stack")];
		case "greed-4": return e.hands[r].length ? [o("optional", { list: [c(e.hands[r].length), l("flip")] })] : [];
		case "sloth-0": return [s(m.length)];
		case "sloth-1": return [l("return", "other", !1, { list: [o("refreshIfOwn")] })];
		case "sloth-2": return [l("flip", "own covered")];
		case "sloth-3":
		case "inert-1": return [c(2, i)];
		case "wrath-0": return [u(n.line)];
		case "wrath-1":
		case "flexible-2": return [s(1)];
		case "wrath-2": return [o("group", {
			mode: "flip",
			filter: "most"
		})];
		case "wrath-3": return [l("flip", "faceup")];
		case "wrath-4": return e.control === r ? [d(null), c(2, i)] : [];
		case "flexible-0": return [l("return|shift")];
		case "flexible-1": return [l("flip|shift", "own")];
		case "flexible-3": return [l("shiftOrSwap", "opp")];
		case "rigid-1": return [l("flip", "opp faceup")];
		case "rigid-3": return [o("handPlay", {
			line: n.line,
			token: n.card.token
		})];
		case "inert-0": return [l("flip", "all faceup different")];
		case "inert-2": return [o("group", {
			mode: "flip",
			filter: "highest"
		})];
		case "inert-3": return [g([
			0,
			1,
			2
		].filter((e) => e !== n.line).map((e) => o("handPlay", { line: e }))), o("handPlay", {
			side: i,
			line: n.line
		})];
		case "inert-4": return [o("discardDeck"), o("discardDeck", { side: i })];
		default: return [];
	}
}
function et(t, n) {
	if (!je(t, n.src)) return;
	let r = n.side, i = Te(r), a = n.src ? F(t, n.src.token) : void 0, o = (e, t, n) => t.map((t) => ({
		view: {
			kind: e,
			line: t,
			side: r
		},
		ops: n(t)
	}));
	switch (n.t) {
		case "draft": {
			let e = n.card;
			if (!t.available.includes(e)) return;
			t.available = t.available.filter((t) => t !== e), r === 1 && !t.solo ? t.protocols[r].unshift({
				name: e,
				compiled: !1
			}) : t.protocols[r].push({
				name: e,
				compiled: !1
			}), t.draftAt++, t.draftAt === (t.solo ? 3 : 6) ? (t.turn = 0, t.available = [], Ke(t)) : Je(t);
			break;
		}
		case "command":
			z(t, $e(t, n));
			break;
		case "each": {
			let e = (n.list ?? []).filter((e) => je(t, e.src));
			e.length === 1 ? z(t, e) : e.length > 1 && H(t, "each", r, e.map((t, r) => ({
				view: {
					kind: t.token === void 0 ? "line" : "flip",
					line: t.line,
					token: t.token,
					source: a?.card.id
				},
				ops: [t, {
					...n,
					list: e.filter((e, t) => r !== t)
				}]
			})), a?.card.id ?? null);
			break;
		}
		case "order": {
			let e = (n.list ?? []).filter((e) => je(t, e.src));
			e.length === 1 ? z(t, e) : e.length > 1 && H(t, "order", t.turn, e.map((t, r) => ({
				view: {
					kind: "order",
					token: t.src?.token,
					source: t.card,
					slot: t.src?.slot
				},
				ops: [t, {
					...n,
					list: e.filter((e, t) => r !== t)
				}]
			})));
			break;
		}
		case "phase":
			switch (t.turn = r, n.mode) {
				case "start":
				case "end": {
					n.mode === "start" && (t.turnProgress = !1, t.turnOffered = !1);
					let e = n.mode === "start" ? "Start:" : "End:", i = I(t).filter((e) => e.side === r).flatMap((n) => ["top", "bottom"].filter((r) => R(t, n, r) && O[n.card.id][r].en.startsWith(e)).map((e) => Me(t, n, e)));
					z(t, [{
						t: "phase",
						side: r,
						mode: n.mode === "start" ? "checkControl" : "next"
					}]), Fe(t, i);
					break;
				}
				case "checkControl": {
					z(t, [{
						t: "phase",
						side: r,
						mode: "checkCompile"
					}]);
					let e = Ne(t);
					e[r].filter((t, n) => t > e[i][n]).length >= 2 && Le(t, r);
					break;
				}
				case "checkCompile":
					We(t, r).length ? (z(t, [{
						t: "phase",
						side: r,
						mode: "cache"
					}]), et(t, {
						t: "compileChoice",
						side: r
					})) : z(t, [{
						t: "phase",
						side: r,
						mode: "action"
					}]);
					break;
				case "action":
					if (z(t, [{
						t: "phase",
						side: r,
						mode: "cache"
					}]), t.solo && r === 1) t.hands[r].length ? z(t, oe[t.config.scenario].plays.map((e) => ({
						t: "soloPlay",
						side: r,
						mode: e
					}))) : t.decks[r].length + t.trash[r].length && z(t, [{
						t: "refresh",
						side: r,
						flag: !0
					}]);
					else {
						let e = Xe(t, r).map((e) => ({
							...e,
							ops: e.ops.map((e) => ({
								...e,
								flag: !0
							}))
						}));
						t.hands[r].length < 5 && t.decks[r].length + t.trash[r].length > 0 && e.push({
							view: { kind: "refresh" },
							ops: [{
								t: "refresh",
								side: r
							}]
						}), H(t, "action", r, e);
					}
					break;
				case "cache":
					z(t, [{
						t: "phase",
						side: r,
						mode: "end"
					}]), t.hands[r].length > 5 && z(t, [{
						t: "discard",
						side: r,
						n: t.hands[r].length - 5
					}, {
						t: "event",
						side: r,
						mode: "cache"
					}]);
					break;
				case "next":
					if (t.idleTurns = !t.turnProgress && !t.turnOffered ? t.idleTurns + 1 : 0, t.idleTurns >= 2) {
						Ge(t, -1);
						break;
					}
					t.round++, t.revealed = [], z(t, [{
						t: "phase",
						side: i,
						mode: "start"
					}]);
			}
			break;
		case "event":
			Ie(t, n.mode, r, n.line);
			break;
		case "optional":
			H(t, "optional", r, [{
				view: { kind: "accept" },
				ops: n.list ?? []
			}, {
				view: { kind: "skip" },
				ops: []
			}], a?.card.id ?? null);
			break;
		case "draw":
			Re(t, r, n.n ?? 1, n.line ?? r);
			break;
		case "control":
			Le(t, n.n === -1 ? null : n.n);
			break;
		case "manipulate":
			Ze(t, n);
			break;
		case "refreshIfOwn":
			n.flag && z(t, [{
				t: "refresh",
				side: r,
				src: n.src
			}]);
			break;
		case "refresh":
			if (t.hands[r].length >= 5 || !(t.decks[r].length + t.trash[r].length)) break;
			if (t.config.control && t.control === r && !n.mode) {
				z(t, [{
					...n,
					mode: "ready"
				}]), et(t, {
					t: "useControl",
					side: r
				});
				break;
			}
			Re(t, r, 5 - t.hands[r].length), Ie(t, "refresh", r);
			break;
		case "useControl":
			if (Le(t, null), t.solo && r === 1) switch (oe[t.config.scenario].control) {
				case "draw":
					z(t, [{
						t: "draw",
						side: r,
						n: 1
					}]);
					break;
				case "steal":
					z(t, [{
						t: "draw",
						side: r,
						n: 1,
						line: 0
					}]);
					break;
				case "rearrange": H(t, "rearrange", 0, [
					...Ue(t, 0, 0),
					...Ue(t, 0, 1),
					{
						view: { kind: "skip" },
						ops: []
					}
				]);
			}
			else H(t, "rearrange", r, [
				...Ue(t, r, r),
				...Ue(t, r, i),
				{
					view: { kind: "skip" },
					ops: []
				}
			]);
			break;
		case "compileChoice":
			H(t, "compile", r, o("compile", We(t, r), (e) => [{
				t: "compile",
				side: r,
				line: e
			}]), a?.card.id ?? null);
			break;
		case "compile": {
			if (n.mode !== "ready" && !We(t, r).includes(n.line)) break;
			if (t.config.control && t.control === r && !n.mode) {
				z(t, [{
					...n,
					mode: "ready"
				}]), et(t, {
					t: "useControl",
					side: r
				});
				break;
			}
			let e = n.line, a = t.protocols[r][e].compiled;
			for (let n = 0; n < 2; n++) {
				for (let r of t.field[n][e]) V(t, "compileDelete", n, `stack:${n}:${e}`, `trash:${n}`, r);
				t.trash[n].push(...t.field[n][e].map((e) => e.id)), t.field[n][e] = [];
			}
			if (B(t, "compile", r, e), t.protocols[r][e].compiled = !0, V(t, "compile", r, `stack:${r}:${e}`, `protocol:${r}:${e}`), a && t.solo && r === 1 || t.protocols[r].every((e) => e.compiled)) {
				z(t, [{
					t: "victory",
					side: r
				}]);
				break;
			}
			a && z(t, [{
				t: "draw",
				side: r,
				n: 1,
				line: i
			}]), Ie(t, "compile", r);
			break;
		}
		case "victory":
			Ge(t, r);
			break;
		case "discard": {
			let e = Math.min(n.n ?? 1, t.hands[r].length);
			if (!e) break;
			if (t.solo && r === 1 || e === t.hands[r].length) {
				let n = t.hands[r].splice(0, e);
				t.trash[r].push(...n), B(t, "discard", r, void 0, e), V(t, "discard", r, `hand:${r}`, `trash:${r}`);
			} else H(t, "discard", r, t.hands[r].map((t) => ({
				view: {
					kind: "discard",
					card: t,
					side: r
				},
				ops: [{
					t: "discardOne",
					side: r,
					card: t
				}, ...e > 1 ? [{
					...n,
					n: e - 1
				}] : []]
			})), a?.card.id ?? null);
			break;
		}
		case "discardOne": {
			let e = t.hands[r].indexOf(n.card);
			if (e < 0) break;
			let [i] = t.hands[r].splice(e, 1);
			t.trash[r].push(i), B(t, "discard", r, void 0, 1, i), V(t, "discard", r, `hand:${r}`, `trash:${r}`, i);
			break;
		}
		case "discardDeck": {
			let e = t.decks[r].length;
			t.trash[r].push(...t.decks[r]), t.decks[r] = [], e && (B(t, "discardDeck", r, void 0, e), V(t, "discard", r, `deck:${r}`, `trash:${r}`));
			break;
		}
		case "bottomHand":
			H(t, "bottomHand", r, [...t.hands[r].map((e) => ({
				view: {
					kind: "bottomHand",
					card: e,
					side: r
				},
				ops: [{
					t: "putBottom",
					side: r,
					card: e
				}]
			})), {
				view: { kind: "skip" },
				ops: []
			}], a?.card.id ?? null);
			break;
		case "putBottom": {
			let e = t.hands[r].indexOf(n.card);
			if (e < 0) break;
			let [i] = t.hands[r].splice(e, 1);
			t.decks[r].push(i), V(t, "return", r, `hand:${r}`, `deck:${r}`, i);
			break;
		}
		case "revealHand":
			t.revealed = [{
				side: r,
				cards: [...t.hands[r]]
			}], t.beat = we.reveal;
			break;
		case "randomPlay": {
			if (!t.hands[r].length) break;
			let i = t.hands[r][e(t.seed, t.cursor++, t.hands[r].length)];
			t.revealed = [{
				side: r,
				cards: [i]
			}], H(t, "play", n.src ? F(t, n.src.token).side : r, Xe(t, r, "down", void 0, i), a?.card.id ?? null);
			break;
		}
		case "drawOrPlay": {
			if (t.solo && r === 1) {
				let e = t.hands[r].length ? [{
					view: { kind: "queuePlay" },
					ops: [{
						t: "queuePlay",
						side: r
					}]
				}] : [];
				t.decks[r].length + t.trash[r].length && e.push({
					view: { kind: "draw" },
					ops: [{
						t: "draw",
						side: r,
						n: 1
					}]
				}), H(t, "drawOrPlay", r, e, a?.card.id ?? null);
				break;
			}
			let e = Xe(t, r);
			t.decks[r].length + t.trash[r].length && e.push({
				view: { kind: "draw" },
				ops: [{
					t: "draw",
					side: r,
					n: 1
				}]
			}), H(t, "drawOrPlay", r, e, a?.card.id ?? null);
			break;
		}
		case "queuePlay": {
			let e = t.hands[r][0];
			if (!e) break;
			t.revealed = [{
				side: r,
				cards: [e]
			}], H(t, "play", r, Xe(t, r, "any", void 0, e));
			break;
		}
		case "handPlay":
			H(t, "play", r, Xe(t, r, "down", n.line).map((e) => ({
				...e,
				ops: e.ops.map((e) => ({
					...e,
					token: n.token
				}))
			})), a?.card.id ?? null);
			break;
		case "soloPlay": {
			let e = t.hands[1][0];
			if (!e) break;
			let i = [
				0,
				1,
				2
			], a = n.mode === "up";
			if (a) i = i.filter((n) => Ye(t, 1, e, n)), i.length || (a = !1, i = [
				0,
				1,
				2
			]);
			else {
				let e = Ne(t)[1], r = n.mode === "low" ? Math.min(...e) : Math.max(...e);
				i = i.filter((t) => e[t] === r);
			}
			i.length === 1 ? z(t, [{
				t: "play",
				side: r,
				card: e,
				line: i[0],
				up: a
			}]) : H(t, "soloLine", 0, o("soloLine", i, (t) => [{
				t: "play",
				side: 1,
				card: e,
				line: t,
				up: a
			}]));
			break;
		}
		case "deckPlay":
			if (!t.decks[r].length) break;
			if (n.line === void 0) H(t, "deckLine", r, o("deckLine", [
				0,
				1,
				2
			], (e) => [{
				...n,
				src: void 0,
				line: e
			}]), a?.card.id ?? null);
			else {
				let e = t.decks[r].shift();
				z(t, [{
					t: "commit",
					side: r,
					line: n.line,
					card: e,
					token: t.nextToken++,
					up: !1,
					from: `deck:${r}`
				}]);
			}
			break;
		case "play": {
			let e = t.hands[r].indexOf(n.card);
			if (e < 0) break;
			t.hands[r].splice(e, 1), z(t, [{
				t: "commit",
				side: r,
				card: n.card,
				token: t.nextToken++,
				up: n.up,
				line: n.line,
				n: 0,
				ids: n.token === void 0 ? void 0 : [n.token],
				from: `hand:${r}`,
				filter: n.flag && !n.up ? "actionDown" : void 0
			}]);
			break;
		}
		case "commit": {
			let e = t.field[r][n.line], i = n.ids?.[0], a = i === void 0 ? -1 : e.findIndex((e) => e.token === i), o = e.at(-1);
			if (a < 0 && o && !n.handled?.includes(o.token)) {
				let e = F(t, o.token), i = o.id === "sloth-4" && R(t, e, "mid") ? {
					t: "manipulate",
					side: r,
					mode: "flip",
					filter: "faceup"
				} : o.id === "rigid-4" && !n.up && R(t, e, "bottom") ? {
					t: "draw",
					side: r,
					n: 1
				} : null;
				if (i) {
					z(t, [i, {
						...n,
						handled: [...n.handled ?? [], o.token]
					}]);
					break;
				}
			}
			a < 0 && o && o.epoch++;
			let s = {
				id: n.card,
				token: n.token,
				up: n.up,
				rev: n.n ?? 0,
				epoch: n.epoch ?? 0
			};
			a < 0 ? e.push(s) : e.splice(a, 0, s), B(t, n.flag ? "shift" : "play", r, n.line, 1, s.up ? s.id : void 0), t.last = {
				kind: n.flag ? "shift" : "play",
				side: r,
				line: n.line,
				token: s.token
			}, V(t, n.flag ? "shift" : "play", r, n.from ?? `hand:${r}`, `card:${s.token}`, s, s.token), n.flag || Ie(t, "play", r, n.line, n.filter === "actionDown");
			let c = F(t, s.token);
			(!n.flag || n.filter === "shiftCovered") && R(t, c, "mid") && z(t, [Me(t, c, "mid")]);
			break;
		}
		case "flip": {
			let e = F(t, n.token);
			if (!e || Be(t, e, "flip")) break;
			e.card.up = !e.card.up, e.card.rev++, e.card.epoch++, B(t, "flip", e.side, e.line, 1, e.card.up ? e.card.id : void 0), V(t, "flip", e.side, `card:${e.card.token}`, `card:${e.card.token}`, e.card, e.card.token), R(t, e, "mid") && z(t, [Me(t, e, "mid")]);
			break;
		}
		case "delete":
		case "return":
		case "shift": {
			let e = F(t, n.token);
			if (!e || Be(t, e, n.t)) break;
			Ve(t, e, n.t, n.line), n.t === "delete" && Ie(t, "delete", r);
			break;
		}
		case "multiFlip": {
			let e = (n.ids ?? []).map((e) => F(t, e)).filter((e) => !!e && !Be(t, e, "flip"));
			for (let n of e) n.card.up = !n.card.up, n.card.rev++, n.card.epoch++, V(t, "flip", n.side, `card:${n.card.token}`, `card:${n.card.token}`, n.card, n.card.token);
			B(t, "flip", r, void 0, e.length), n.flag && e.length && z(t, [{
				t: "draw",
				side: r,
				n: e.length,
				src: n.src
			}]), Fe(t, e.filter((e) => R(t, e, "mid")).map((e) => Me(t, e, "mid")));
			break;
		}
		case "group": {
			let e = [
				0,
				1,
				2
			];
			if (n.filter === "five" && (e = e.filter((e) => t.field[r][e].length === 5)), n.filter === "most") {
				let n = e.map((e) => t.field[0][e].length + t.field[1][e].length), r = Math.max(...n);
				e = e.filter((e) => n[e] === r);
			}
			H(t, "line", r, e.flatMap((e) => {
				let i = I(t).filter((t) => t.line === e);
				if (n.filter === "highest") {
					let e = Math.max(0, ...i.map((e) => L(e.card)));
					i = i.filter((t) => L(t.card) === e);
				}
				let a = i.filter((e) => e.card.up && !Be(t, e, n.mode)).map((e) => e.card.token);
				return a.length ? [{
					view: {
						kind: n.mode,
						line: e,
						side: r
					},
					ops: [{
						t: n.mode === "flip" ? "multiFlip" : "multiDelete",
						side: r,
						ids: a,
						src: n.src
					}]
				}] : [];
			}), a?.card.id ?? null);
			break;
		}
		case "multiDelete": {
			let e = (n.ids ?? []).map((e) => F(t, e)).filter((e) => !!e), i = /* @__PURE__ */ new Set();
			for (let n of e) n.card.rev++, t.trash[n.side].push(n.card.id), i.add(n.stack), V(t, "delete", n.side, `stack:${n.side}:${n.line}`, `trash:${n.side}`, n.card);
			for (let e of i) {
				let r = e.at(-1)?.token, i = e.filter((e) => !n.ids.includes(e.token));
				e.splice(0, e.length, ...i), r !== e.at(-1)?.token && ze(t, e);
			}
			e.length && Ie(t, "delete", r);
			break;
		}
		case "novaUnder":
			if (!t.decks[r].length) break;
			H(t, "novaUnder", r, I(t).filter((e) => e.side === r && Oe(e) && e.card.up && O[e.card.id].protocol === "nova").map((e) => ({
				view: {
					kind: "novaUnder",
					token: e.card.token,
					side: r,
					line: e.line
				},
				ops: [{
					t: "deckUnder",
					side: r,
					token: e.card.token
				}]
			})), a?.card.id ?? null);
			break;
		case "deckUnder": {
			let e = F(t, n.token);
			if (!e || !t.decks[r].length) break;
			let i = t.decks[r].shift();
			z(t, [{
				t: "commit",
				side: r,
				line: e.line,
				card: i,
				token: t.nextToken++,
				up: !1,
				ids: [e.card.token],
				from: `deck:${r}`
			}]);
			break;
		}
		case "arrangeChoice":
			H(t, "rearrange", r, Ue(t, r, n.n ?? r, n.mode === "swap", n.optional), a?.card.id ?? null);
			break;
		case "rearrange": {
			let e = n.n ?? r, i = t.protocols[e];
			t.protocols[e] = n.order.map((n) => t.protocols[e].find((e) => e.name === n));
			for (let [r, a] of i.entries()) {
				let i = n.order.indexOf(a.name);
				r !== i && t.fx.push({
					kind: "protocol",
					...t.fx.length ? { with: !0 } : {},
					data: {
						protocol: a.name,
						compiled: a.compiled,
						from: `protocol:${e}:${r}`,
						to: `protocol:${e}:${i}`
					}
				});
			}
			t.beat = we.move, B(t, "rearrange", r), Ie(t, "rearrange", r);
			break;
		}
		case "swapEnds": {
			let e = t.protocols[r].map((e) => e.name);
			[e[0], e[2]] = [e[2], e[0]], z(t, [{
				t: "rearrange",
				side: r,
				n: r,
				order: e,
				src: n.src
			}]);
			break;
		}
		case "swapStacks": {
			for (let e of [0, 2]) for (let n of t.field[r][e]) V(t, "shift", r, `stack:${r}:${e}`, `card:${n.token}`, n, n.token);
			let e = t.field[r];
			[e[0], e[2]] = [e[2], e[0]], B(t, "swapStacks", r);
			break;
		}
	}
}
function tt(e, t, n) {
	if (e.phase === "done" || t.type === "tick" && n.by !== "$engine" || t.type === "choose" && (!e.pending || e.pending.actor !== n.by || !e.pending.options.some((e) => e.view.id === t.id)) || t.type === "tick" && (e.pending || !e.queue.length)) return { code: "games.compile3.invalid" };
	let r = structuredClone(e);
	if (r.fx = [], r.beat = we.phase, t.type === "choose") {
		let e = r.pending.options.find((e) => e.view.id === t.id);
		r.pending = null, r.phase = "resolve", z(r, e.ops);
	}
	let i = r.queue.shift();
	i && et(r, i), Ee(r) !== Ee(e) && (r.turnProgress = !0), r.winner === null && !r.pending && !r.queue.length && z(r, [{
		t: "phase",
		side: r.turn,
		mode: "cache"
	}]);
	let a = r.fx;
	return r.fx = [], {
		state: r,
		fx: a
	};
}
function nt(e, t) {
	let n = e.sides.indexOf(t), r = e.pending?.actor === t, i = {
		phase: e.phase,
		turn: e.turn,
		round: e.round,
		sides: e.sides,
		protocols: e.protocols,
		field: e.field.map((e) => e.map((e) => e.map((t, n) => ({
			token: t.token,
			face: t.up ? t.id : null,
			up: t.up,
			value: L(t),
			covered: n < e.length - 1
		})))),
		totals: Ne(e),
		handCounts: e.hands.map((e) => e.length),
		deckCounts: e.decks.map((e) => e.length),
		trash: e.trash,
		control: e.control,
		useControl: e.config.control,
		solo: e.solo,
		scenario: e.config.scenario,
		available: e.available,
		pending: e.pending ? {
			actor: e.pending.actor,
			kind: e.pending.kind,
			source: e.pending.source,
			count: e.pending.options.length
		} : null,
		revealed: e.revealed,
		last: e.last,
		winner: e.winner,
		log: e.log.slice(-100)
	};
	return n < 0 ? { public: i } : {
		public: i,
		private: {
			hand: e.hands[n],
			faces: Object.fromEntries(e.field[n].flat().map((e) => [e.token, e.id])),
			options: r ? e.pending.options.map((t) => {
				let n = { ...t.view };
				return e.solo && n.kind === "play" && n.side === 1 && !n.up && !e.revealed.some((e) => e.cards.includes(n.card ?? "")) && delete n.card, n;
			}) : [],
			decision: e.decision
		}
	};
}
var rt = {
	meta: ye,
	saveCompatibility: { version: "1" },
	schemas: {
		action: N,
		publicView: P,
		privateView: Ce,
		config: be
	},
	setup: qe,
	reduce: tt,
	viewFor: nt,
	status(e) {
		let t = Object.fromEntries(e.sides.filter((t, n) => !e.solo || n === 0).map((t, n) => [t, e.protocols[n].filter((e) => e.compiled).length]));
		return e.winner === null ? { phase: e.phase } : e.winner === -1 ? {
			phase: "done",
			winner: [],
			ranking: e.sides.filter((t, n) => !e.solo || n === 0),
			scores: t
		} : {
			phase: "done",
			winner: e.solo ? e.winner === 0 ? [e.sides[0]] : [] : [e.sides[e.winner]],
			ranking: e.solo ? [e.sides[0]] : [e.sides[e.winner], e.sides[Te(e.winner)]],
			scores: t
		};
	},
	nextTickIn: (e) => e.phase !== "done" && !e.pending && e.queue.length ? e.beat : null
}, it = r.object({
	boxes: r.array(r.int().min(1).max(3)).min(1).default([1]),
	legacy3: r.boolean().default(!1),
	aux3: r.boolean().default(!1),
	scenario: r.int().min(0).max(11).default(0),
	aux1: r.boolean().default(!1),
	aux2: r.boolean().default(!1),
	control: r.boolean().default(!0),
	draft: r.boolean().default(!0)
}).default({
	boxes: [1],
	legacy3: !1,
	aux3: !1,
	scenario: 0,
	aux1: !1,
	aux2: !1,
	control: !0,
	draft: !0
}), at = r.discriminatedUnion("type", [r.object({
	type: r.literal("choose"),
	id: r.string()
}), r.object({
	type: r.literal("tick"),
	now: r.number()
})]), ot = r.object({
	id: r.string(),
	kind: r.string(),
	card: r.string().optional(),
	token: r.int().optional(),
	side: r.int().optional(),
	line: r.int().optional(),
	n: r.int().optional(),
	order: r.array(r.string()).optional(),
	up: r.boolean().optional(),
	source: r.string().optional(),
	slot: r.enum([
		"top",
		"mid",
		"bottom"
	]).optional()
}), st = r.object({
	phase: r.enum([
		"draft",
		"resolve",
		"choose",
		"done"
	]),
	turn: r.int(),
	round: r.int(),
	sides: r.array(r.string()),
	protocols: r.array(r.array(r.object({
		name: r.string(),
		compiled: r.boolean()
	}))),
	field: r.array(r.array(r.array(r.object({
		token: r.int(),
		face: r.string().nullable(),
		up: r.boolean(),
		value: r.number(),
		covered: r.boolean()
	})))),
	totals: r.array(r.array(r.number())),
	handCounts: r.array(r.int()),
	deckCounts: r.array(r.int()),
	trash: r.array(r.array(r.string())),
	control: r.int().nullable(),
	useControl: r.boolean(),
	solo: r.boolean(),
	scenario: r.int(),
	available: r.array(r.string()),
	pending: r.object({
		actor: r.string(),
		kind: r.string(),
		source: r.string().nullable(),
		count: r.int()
	}).nullable(),
	revealed: r.array(r.object({
		side: r.int(),
		cards: r.array(r.string())
	})),
	last: r.object({
		kind: r.string(),
		side: r.int(),
		line: r.int().optional(),
		token: r.int().optional()
	}).nullable(),
	winner: r.int().nullable(),
	log: r.array(r.object({
		kind: r.string(),
		side: r.int(),
		n: r.int().optional(),
		line: r.int().optional(),
		card: r.string().optional()
	}))
}), ct = r.object({
	hand: r.array(r.string()),
	faces: r.record(r.string(), r.string()),
	options: r.array(ot),
	decision: r.int()
}), U = {
	move: 420,
	compile: 850,
	phase: 40,
	reveal: 900
}, lt = (e) => 1 - e, ut = (e, t) => e.solo ? e.sides[0] : e.sides[t], dt = (e) => JSON.stringify([
	e.protocols,
	e.field,
	e.hands,
	e.decks,
	e.trash,
	e.control
]), W = (e, t) => G(e).find((e) => e.card.token === t), G = (e) => e.field.flatMap((e, t) => e.flatMap((e, n) => e.map((r, i) => ({
	side: t,
	line: n,
	index: i,
	card: r,
	stack: e
})))), K = (e) => e.index === e.stack.length - 1;
function q(e, t, n) {
	return !t.card.up || e.solo && t.side === 1 && e.config.scenario < 6 || !j[t.card.id][n].en || n !== "top" && !K(t) ? !1 : n === "mid" ? !G(e).some((n) => q(e, n, "top") && (n.card.id === "apathy-2" && n.line === t.line || n.card.id === "fear-0" && n.side !== t.side && e.turn === n.side)) : !G(e).some((e) => e.line === t.line && e.card.token !== t.card.token && e.card.up && e.card.id === (n === "top" ? "inert-0" : "inert-1") && (n === "top" || K(e)));
}
var ft = (e, t) => ({
	token: e.card.token,
	rev: e.card.rev,
	epoch: e.card.epoch,
	slot: t
});
function pt(e, t) {
	if (!t) return !0;
	let n = W(e, t.token);
	return !!n && n.card.rev === t.rev && (t.slot === "top" || n.card.epoch === t.epoch) && q(e, n, t.slot);
}
function mt(e, t, n) {
	return {
		t: "command",
		side: t.side,
		src: ft(t, n),
		card: t.card.id
	};
}
function J(e, t) {
	return t.card.up ? j[t.card.id].value : t.stack.some((t) => t.id === "darkness-2" && q(e, W(e, t.token), "top")) ? 4 : 2;
}
function ht(e) {
	let t = [[
		0,
		0,
		0
	], [
		0,
		0,
		0
	]];
	for (let n of G(e)) {
		let r = G(e).filter((e) => e.line === n.line), i = J(e, n);
		if ((!r.some((t) => t.card.id === "wrath-0" && q(e, t, "top")) || i !== Math.max(...r.map((t) => J(e, t)))) && (t[n.side][n.line] += i), !q(e, n, "top")) continue;
		let a = n.card.id;
		a === "metal-0" && (t[lt(n.side)][n.line] -= 2), a === "clarity-0" && (t[n.side][n.line] += e.hands[n.side].length), a === "mirror-0" && (t[n.side][n.line] += e.field[lt(n.side)][n.line].length), (a === "smoke-2" || a === "apathy-0") && (t[n.side][n.line] += G(e).filter((e) => e.line === n.line && !e.card.up).length), a === "diversity-3" && n.stack.some((e) => e.up && j[e.id].protocol !== "diversity") && (t[n.side][n.line] += 2), a === "envy-0" && (t[n.side][n.line] += Math.max(0, ...G(e).filter((e) => e.side !== n.side && e.line === n.line).map((t) => J(e, t)))), a === "lust-0" && (t[0][n.line] += 10, t[1][n.line] += 10), a === "sloth-0" && n.stack.slice(n.index + 1).some((e) => e.up && j[e.id].protocol === "sloth") && (t[n.side][n.line] += 5);
	}
	return t;
}
function gt(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
var Y = (e, t) => {
	e.queue.unshift(...t);
};
function X(e, t, n, r, i, a) {
	e.last = {
		kind: t,
		side: n,
		...r === void 0 ? {} : { line: r }
	}, e.log.push({
		kind: t,
		side: n,
		...r === void 0 ? {} : { line: r },
		...i === void 0 ? {} : { n: i },
		...a === void 0 ? {} : { card: a }
	});
}
function Z(e, t, n, r, i, a, o) {
	let s = typeof a == "string" ? t === "discard" ? a : void 0 : a?.up ? a.id : void 0, c = r.startsWith("depart:hand:");
	e.fx.push({
		kind: "move",
		...e.fx.length ? { with: !0 } : {},
		rid: e.sides[n],
		data: {
			kind: t,
			from: c ? `hand:${r.split(":")[2]}` : r,
			to: i,
			...s ? { card: s } : {},
			...o === void 0 ? {} : { token: o }
		},
		for: [e.sides[n]],
		secret: {
			...c ? { from: r } : {},
			...a ? { card: typeof a == "string" ? a : a.id } : {}
		}
	}), e.beat = t === "compile" ? U.compile : U.move;
}
function Q(e, t, n, r, i = null) {
	r.length && (e.turnOffered = !0, e.decision++, e.pending = {
		kind: t,
		actor: ut(e, n),
		source: i,
		options: r.map((t, n) => ({
			...t,
			view: {
				...t.view,
				id: `${e.decision}:${n}`
			}
		}))
	}, e.phase = "choose");
}
var _t = (e, t) => {
	t.length && Y(e, [{
		t: "order",
		side: e.turn,
		list: t
	}]);
};
function vt(e, t, n, r) {
	return G(e).flatMap((i) => {
		let a = i.card.id, o = [];
		return t === "draw" && (a === "spirit-3" && i.side === n && o.push("top"), i.side !== n && (a === "mirror-4" || a === "war-0") && o.push("bottom")), t === "shuffle" && a === "time-2" && i.side === n && o.push("top"), t === "discard" && ((a === "corruption-2" && i.side === n || a === "plague-1" && i.side !== n) && o.push("top"), (a === "peace-4" && i.side === n && e.turn !== n || a === "war-3" && i.side !== n) && o.push("bottom")), t === "delete" && a === "hate-3" && i.side === n && o.push("top"), t === "cache" && a === "speed-1" && i.side === n && o.push("top"), t === "refresh" && (a === "war-0" && i.side === n && o.push("top"), (a === "war-1" && i.side !== n || a === "assimilation-1") && o.push("bottom")), t === "compile" && a === "war-2" && i.side !== n && o.push("bottom"), t === "play" && a === "ice-1" && i.side !== n && i.line === r && o.push("bottom"), t === "control" && i.side !== n && (a === "pride-6" && o.push("top"), a === "lust-4" && o.push("bottom")), t === "compile" && (a === "pride-0" && i.side === n || a === "momentum-1" || a === "momentum-6") && o.push("top"), t === "rearrange" && (a === "momentum-1" || a === "nova-2" && i.side === n) && o.push("bottom"), t === "cache" && (a === "gluttony-0" && i.side === n && o.push("top"), a === "gluttony-1" && o.push("bottom")), t === "refresh" && i.side === n && (a === "gluttony-4" || a === "sloth-1") && o.push("bottom"), t === "delete" && i.side === n && a === "greed-0" && o.push("bottom"), t === "play" && i.side !== n && a === "envy-3" && i.line === r && o.push("bottom"), t === "actionDown" && i.side === n && a === "rigid-2" && o.push("bottom"), o.filter((t) => q(e, i, t)).map((n) => ({
			...mt(e, i, n),
			mode: t,
			line: r
		}));
	});
}
function $(e, t, n, r) {
	_t(e, vt(e, t, n, r));
}
function yt(e, t) {
	e.config.control && e.control !== t && (e.control = t, X(e, "control", t ?? e.turn), e.fx.push({
		kind: "control",
		data: { side: t }
	}), e.beat = U.move, t !== null && $(e, "control", t));
}
function bt(e, t, n, r = t, i = !1) {
	if (G(e).some((n) => n.side === t && n.card.id === "ice-6" && q(e, n, "top")) && e.hands[t].length) return [];
	let a = [], o = 0;
	for (let t = 0; t < n; t++) {
		!e.decks[r].length && e.trash[r].length && (e.decks[r] = gt(e, e.trash[r]), e.trash[r] = [], o++);
		let t = e.decks[r].shift();
		if (!t) break;
		a.push(t);
	}
	return e.hands[t].push(...e.solo && t === 1 && !i ? gt(e, a) : a), a.length && (X(e, "draw", t, void 0, a.length), Z(e, "draw", t, `deck:${r}`, `hand:${t}`), Y(e, [{
		t: "event",
		side: t,
		mode: "draw"
	}])), o && Y(e, Array.from({ length: o }, () => ({
		t: "event",
		side: r,
		mode: "shuffle"
	}))), a;
}
function xt(e, t) {
	let n = t.at(-1), r = n ? W(e, n.token) : void 0;
	r && q(e, r, "mid") && Y(e, [mt(e, r, "mid")]);
}
function St(e, t, n) {
	return n === "flip" && t.card.id === "ice-4" && q(e, t, "bottom") || ["shift", "flip"].includes(n) && t.card.id === "rigid-7" && q(e, t, "bottom");
}
function Ct(e, t, n) {
	let r = K(t), i = `depart:${t.card.token}`, [a] = t.stack.splice(t.index, 1);
	if (n.t === "shift") Y(e, [{
		t: "commit",
		side: t.side,
		actor: n.side,
		line: n.line,
		card: a.id,
		token: a.token,
		up: a.up,
		n: a.rev,
		epoch: a.epoch,
		flag: !0,
		from: i,
		filter: r ? "shiftUncovered" : "shiftCovered"
	}]);
	else {
		a.rev++;
		let r = n.t === "return" && G(e).some((n) => n.side !== t.side && n.card.id === "corruption-1" && q(e, n, "bottom"));
		Y(e, [{
			t: "land",
			side: t.side,
			dest: n.t === "take" ? n.side : t.side,
			actor: n.side,
			card: a.id,
			token: a.token,
			up: a.up,
			mode: r ? "top" : n.t,
			from: i
		}]);
	}
	r && xt(e, t.stack);
}
var wt = (e) => e.length ? e.flatMap((t, n) => wt(e.filter((e, t) => n !== t)).map((e) => [t, ...e])) : [[]];
function Tt(e, t, n, r = !1, i = !1) {
	let a = e.protocols[n].map((e) => e.name);
	return [...wt(a).filter((e) => e.some((e, t) => e !== a[t]) && (!r || e.filter((e, t) => e !== a[t]).length === 2)).map((e) => ({
		view: {
			kind: "rearrange",
			side: n,
			order: e
		},
		ops: [{
			t: "rearrange",
			side: t,
			dest: n,
			order: e
		}]
	})), ...i ? [{
		view: { kind: "skip" },
		ops: []
	}] : []];
}
function Et(e, t) {
	if (G(e).some((n) => n.side !== t && n.card.id === "lust-0" && q(e, n, "bottom") && e.control === n.side) || e.metalLocks.some((n) => n.side === t && n.round === e.round && (() => {
		let t = W(e, n.token);
		return t?.card.rev === n.rev && q(e, t, "mid");
	})())) return [];
	let n = ht(e);
	return [
		0,
		1,
		2
	].filter((e) => n[t][e] >= 10 && n[t][e] > n[lt(t)][e]);
}
function Dt(e, t) {
	e.winner = t, e.phase = "done", e.pending = null, e.queue = [];
}
function Ot(e, t, n, r, i, a, o = !1) {
	return G(e).some((n) => n.side !== t && n.line === i && n.card.id === "plague-0" && q(e, n, "bottom")) ? !1 : a ? G(e).some((n) => n.side !== t && n.card.id === "psychic-1" && q(e, n, "top")) ? !1 : o || r === "chaos-3" || r === "corruption-0" || G(e).some((r) => r.side === t && r.card.id === "spirit-1" && q(e, r, "top") || r.side === n && r.line === i && r.card.id === "lust-2" && q(e, r, "bottom")) || e.protocols.some((e) => e[i]?.name === j[r].protocol) || j[r].protocol === "unity" && G(e).some((t) => t.line === i && t.card.id === "unity-1" && q(e, t, "bottom")) : !G(e).some((n) => n.side !== t && n.line === i && n.card.id === "metal-2" && q(e, n, "top"));
}
function kt(e, t) {
	return (t.cards ?? (t.from === "trash" ? e.trash[t.side] : e.solo && t.side === 1 ? e.hands[t.side].slice(0, 1) : e.hands[t.side])).flatMap((n) => (n === "corruption-0" && t.dest === void 0 ? [t.side, lt(t.side)] : [t.dest ?? t.side]).flatMap((r) => [
		0,
		1,
		2
	].filter((e) => t.line === void 0 || e === t.line).filter((n) => !t.filter?.includes("other") || n !== W(e, t.src.token)?.line).filter((n) => !t.filter?.includes("smoke") || e.field.some((e) => e[n].some((e) => !e.up))).flatMap((i) => [!0, !1].filter((e) => t.mode !== "down" || !e).filter((a) => Ot(e, t.side, r, n, i, a, t.flag)).map((e) => ({
		view: {
			kind: "play",
			card: n,
			side: r,
			line: i,
			up: e
		},
		ops: [{
			t: "play",
			side: t.side,
			dest: r,
			card: n,
			line: i,
			up: e,
			from: t.from,
			src: t.src
		}]
	})))));
}
function At(e, t) {
	let n = t.src ? W(e, t.src.token) : void 0, r = (t.filter ?? "").split(" "), i = G(e).filter((e) => r.includes("all") || r.includes("both") || (r.includes("covered") ? !K(e) : K(e)));
	if (r.includes("own") && (i = i.filter((e) => e.side === t.side)), r.includes("opp") && (i = i.filter((e) => e.side !== t.side)), r.includes("other") && (i = i.filter((e) => e.card.token !== n?.card.token)), r.includes("down") && (i = i.filter((e) => !e.card.up)), (r.includes("up") || r.includes("faceup")) && (i = i.filter((e) => e.card.up)), r.includes("stack") && (i = i.filter((e) => e.side === n?.side && e.line === n.line)), r.includes("line") && (i = i.filter((e) => e.line === n?.line)), r.includes("different") && (i = i.filter((e) => e.line !== n?.line)), r.includes("less") && (i = i.filter((t) => J(e, t) < (n?.stack.length ?? 0))), r.includes("higher")) {
		let t = ht(e);
		i = i.filter((e) => t[e.side][e.line] > t[lt(e.side)][e.line]);
	}
	if (r.includes("low01") && (i = i.filter((t) => J(e, t) <= 1)), r.includes("peace") && (i = i.filter((n) => J(e, n) > e.hands[t.side].length)), r.includes("diversity") && (i = i.filter((t) => J(e, t) < new Set(G(e).filter((e) => e.card.up).map((e) => j[e.card.id].protocol)).size)), t.n !== void 0 && (i = i.filter((n) => J(e, n) === t.n)), t.line !== void 0 && t.mode !== "shift" && (i = i.filter((e) => e.line === t.line)), r.includes("highest") || r.includes("lowest")) {
		let t = i.map((t) => J(e, t)), n = r.includes("highest") ? Math.max(...t) : Math.min(...t);
		i = i.filter((t) => J(e, t) === n);
	}
	return t.token !== void 0 && (i = G(e).filter((e) => e.card.token === t.token)), i;
}
function jt(e, t) {
	if (t.mode === "shiftOrSwap") {
		jt(e, {
			...t,
			mode: "shift"
		});
		let n = e.pending?.options.map((e) => ({
			view: e.view,
			ops: e.ops
		})) ?? [];
		e.pending = null, Q(e, "shiftOrSwap", t.side, [...n, ...Tt(e, t.side, t.side, !0)], t.src ? W(e, t.src.token)?.card.id ?? null : null);
		return;
	}
	let n = t.src ? W(e, t.src.token) : void 0, r = At(e, t).flatMap((r) => (t.mode ?? "flip").split("|").flatMap((i) => St(e, r, i) ? [] : (i === "shift" ? [
		0,
		1,
		2
	].filter((e) => e !== r.line && (t.line === void 0 || e === t.line)).filter((e) => !t.filter?.includes("gravity") || r.line === n?.line || e === n?.line) : [r.line]).map((e) => ({
		view: {
			kind: i,
			token: r.card.token,
			side: r.side,
			line: e
		},
		ops: [{
			t: i,
			side: t.side,
			token: r.card.token,
			line: e,
			src: t.src
		}, ...(t.list ?? []).map((e) => ({
			...e,
			token: e.from === "lineTarget" ? void 0 : e.token ?? r.card.token,
			card: e.card ?? r.card.id,
			line: e.line ?? r.line,
			flag: r.side === t.side
		}))]
	}))));
	t.optional && r.push({
		view: { kind: "skip" },
		ops: []
	}), Q(e, t.mode ?? "flip", t.side, r, n?.card.id ?? null);
}
function Mt(e) {
	for (let t = 0; t < 2; t++) e.decks[t] = gt(e, _e.filter((n) => e.protocols[t].some((e) => e.name === n.protocol)).map((e) => e.id));
	for (let t = 0; t < 2; t++) e.hands[t] = e.decks[t].splice(0, 5);
	e.turn = 0, e.phase = "resolve", e.available = [], Y(e, [{
		t: "phase",
		side: 0,
		mode: "start"
	}]);
}
function Nt(e) {
	let t = e.solo ? 0 : [
		0,
		1,
		1,
		0,
		0,
		1
	][e.draftAt];
	e.turn = t, Q(e, "draft", t, e.available.map((e) => ({
		view: {
			kind: "draft",
			card: e
		},
		ops: [{
			t: "draft",
			side: t,
			card: e
		}]
	}))), e.phase = "draft";
}
function Pt(e, t, n) {
	let r = it.parse(e);
	if (r.legacy3) {
		let e = rt.setup(r, t, n);
		return {
			...e,
			state: {
				...e.state,
				legacy: !0
			}
		};
	}
	let i = t.length === 1, a = {
		config: r,
		solo: i,
		seed: n,
		cursor: 0,
		sides: [t[0], t[1] ?? "$compile-bot"],
		turn: 0,
		round: 1,
		protocols: [[], []],
		field: [[
			[],
			[],
			[]
		], [
			[],
			[],
			[]
		]],
		hands: [[], []],
		decks: [[], []],
		trash: [[], []],
		control: null,
		phase: "draft",
		queue: [],
		pending: null,
		decision: 0,
		nextToken: 1,
		available: [
			...r.boxes.includes(1) ? se : [],
			...r.boxes.includes(2) ? ce : [],
			...r.boxes.includes(3) ? C : [],
			...r.aux1 ? le : [],
			...r.aux2 ? k : [],
			...r.aux3 ? ie : []
		],
		draftAt: 0,
		winner: null,
		beat: U.move,
		revealed: [],
		last: null,
		log: [],
		fx: [],
		metalLocks: [],
		idleTurns: 0,
		turnProgress: !1,
		turnOffered: !1
	};
	if (i) {
		let e = oe[r.scenario].protocols;
		a.protocols[1] = e.map((e) => ({
			name: e,
			compiled: !1
		})), a.available = a.available.filter((t) => !e.includes(t));
	}
	if (r.draft || i) Nt(a);
	else {
		let e = gt(a, a.available).slice(0, 6);
		a.protocols = [e.slice(0, 3), e.slice(3, 6)].map((e) => e.map((e) => ({
			name: e,
			compiled: !1
		}))), Mt(a);
	}
	let o = a.fx;
	return a.fx = [], {
		state: a,
		fx: o
	};
}
function Ft(e, t) {
	let n = W(e, t.src.token), r = n.side, i = lt(r), a = t.src.slot, o = t.card ?? n.card.id, s = (e, n = {}) => ({
		t: e,
		side: r,
		src: t.src,
		...n
	}), c = (e, t = r) => s("draw", {
		n: e,
		side: t
	}), l = (e, t = r) => s("discard", {
		n: e,
		side: t
	}), u = (e, t = "", n = !1, r = {}) => s("manipulate", {
		mode: e,
		filter: t,
		optional: n,
		...r
	}), d = (e, t = {}) => s("deckPlay", {
		line: e,
		...t
	}), f = (e) => s("control", { n: e ?? -1 }), p = ht(e), m = [
		0,
		1,
		2
	].filter((e) => p[r][e] > p[i][e]), h = [
		0,
		1,
		2
	].filter((e) => p[r][e] < p[i][e]), g = (e) => s(e, { token: n.card.token }), _ = (e) => s("each", { list: e });
	if (a === "top") switch (o) {
		case "pride-0": return [s("refresh")];
		case "pride-6": return [g("flip")];
		case "gluttony-0": return [d()];
		case "gluttony-3": {
			let e = n.stack[n.index + 1];
			return e?.up ? [s("delete", { token: e.token })] : [];
		}
		case "overwhelm-2": return [_([
			0,
			1,
			2
		].map((e) => d(e))), g("flip")];
		case "overwhelm-6": return p[i][n.line] > p[r][n.line] ? [g("flip")] : [];
		case "fulcrum-0": return e.hands[r].length === 0 ? [l(2, i)] : [];
		case "momentum-1": return [d(n.line)];
		case "momentum-6": return [g("delete")];
		case "nova-0": return [s("group", {
			mode: "delete",
			filter: "five"
		})];
		case "flexible-2": {
			let e = n.stack[n.index + 1];
			return e && !e.up ? [u("shift", "", !0, { token: e.token })] : [];
		}
		case "rigid-7": return [s("drawOrPlay", { side: i })];
		default: return [];
	}
	if (a === "bottom") switch (o) {
		case "envy-1": return e.control === i ? [f(r)] : [];
		case "envy-3": return [d(n.line)];
		case "overwhelm-3": return e.hands[r].length >= 5 ? [d(n.line)] : [];
		case "pride-2": return m.includes(n.line) ? [c(1)] : [];
		case "lust-3": return e.control === r ? [s("optional", { list: [f(null), u("flip")] })] : [];
		case "lust-4": return [c(1)];
		case "gluttony-1": return [u("delete")];
		case "gluttony-4": return [c(1)];
		case "nova-0": return [s("novaUnder")];
		case "nova-2": return [u("shift", "down", !0)];
		case "momentum-1": return [l(1), c(1)];
		case "greed-0": return [c(1)];
		case "greed-1": return [s("compileChoice")];
		case "greed-2": return [u("return", "own", !0)];
		case "sloth-1": return [d(n.line)];
		case "sloth-2": return [s("bottomHand", { optional: !0 })];
		case "wrath-1": return e.control === r ? [f(null), u("delete", "faceup")] : [];
		case "flexible-4": return [s("optional", { list: [c(2), g("flip")] })];
		case "rigid-1": return [_([
			0,
			1,
			2
		].filter((t) => t !== n.line && e.field[i][t].at(-1)?.up === !1).map((e) => s("handPlay", { line: e })))];
		case "rigid-2": return [d(t.line)];
		default: return [];
	}
	if (j[o].mid.en === "Discard 1 card.") return [l(1)];
	switch (o) {
		case "envy-1": return e.control === i ? [u("flip", "", !0)] : [];
		case "envy-2": return [c(e.hands[i].length)];
		case "envy-4": return e.protocols[i].filter((e) => e.compiled).length > e.protocols[r].filter((e) => e.compiled).length ? [u("flip")] : [];
		case "pride-0": return [u("shift", e.control === r ? "other" : "own")];
		case "pride-2": return [c(m.length)];
		case "pride-3": return [u("flip", "own down")];
		case "pride-4": return e.control === r ? [u("shift", "opp", !0, { line: n.line })] : [];
		case "pride-6": return e.control === i ? [g("flip")] : [];
		case "lust-0": return [f(r)];
		case "lust-2": return [u("shift", "opp covered", !0, { line: n.line })];
		case "lust-3": return [s("randomPlay", { side: i })];
		case "lust-4": return [s("revealHand"), f(e.control === i ? null : e.control)];
		case "lust-6": return [l(1), s("handPlay", {
			side: i,
			line: n.line
		})];
		case "overwhelm-1": return [_(m.map((e) => d(e)))];
		case "overwhelm-2": return [_([
			0,
			1,
			2
		].map((e) => d(e, { side: i })))];
		case "overwhelm-4": return e.field[r].flat().length > e.field[i].flat().length ? [u("delete", "opp covered lowest")] : [];
		case "ambush-0": return [c(3), u("flip", "own down")];
		case "ambush-1": return [s("multiFlip", {
			ids: G(e).filter((t) => t.side === r && t.card.token !== n.card.token && J(e, t) <= 1).map((e) => e.card.token),
			flag: !0
		})];
		case "ambush-2": return [u("shift", "own covered lowest")];
		case "ambush-3": return [u("flip", "opp faceup highest")];
		case "ambush-4": return e.field[r].some((e) => e.at(-1)?.up === !1) ? [c(1)] : [];
		case "fulcrum-0": return e.hands[r].length === 0 ? [l(1, i)] : [];
		case "fulcrum-1": return [_(G(e).filter((e) => e.card.token !== n.card.token && e.card.up && K(e)).map((e) => s("flip", {
			token: e.card.token,
			line: e.line
		}))), s("swapStacks")];
		case "fulcrum-2": return e.hands[r].length === 2 ? [u("delete", "opp")] : [];
		case "fulcrum-3": return [c(1), s("swapEnds")];
		case "fulcrum-4": return e.hands[r].length === 4 ? [c(1)] : [];
		case "gluttony-0": return [u("return", "other"), c(1)];
		case "gluttony-1":
		case "gluttony-3":
		case "momentum-3": return [c(2)];
		case "gluttony-2": return [c(e.hands[r].length)];
		case "nova-0": return e.control === null ? [] : [s("arrangeChoice", {
			side: e.control,
			n: r,
			mode: "swap"
		})];
		case "nova-1": return [l(n.stack.length, i)];
		case "nova-2": return n.stack.slice(n.index - 1, n.index).some((e) => e.up && j[e.id].protocol === "nova") ? [s("arrangeChoice", {
			n: r,
			optional: !0
		})] : [f(r)];
		case "nova-3": return [u("shift", "less")];
		case "nova-4": return [u("flip", "less")];
		case "momentum-0": return [_(e.protocols[r].flatMap((e, t) => e.compiled ? [d(t)] : []))];
		case "momentum-4": return [s("arrangeChoice", { n: r })];
		case "greed-0": return [l(e.hands[r].length), u("delete")];
		case "greed-2": return [l(1, i)];
		case "greed-3": return [u("shift", "own covered stack")];
		case "greed-4": return e.hands[r].length ? [s("optional", { list: [l(e.hands[r].length), u("flip")] })] : [];
		case "sloth-0": return [c(h.length)];
		case "sloth-1": return [u("return", "other", !1, { list: [s("refreshIfOwn")] })];
		case "sloth-2": return [u("flip", "own covered")];
		case "sloth-3":
		case "inert-1": return [l(2, i)];
		case "wrath-0": return [d(n.line)];
		case "wrath-1":
		case "flexible-2": return [c(1)];
		case "wrath-2": return [s("group", {
			mode: "flip",
			filter: "most"
		})];
		case "wrath-3": return [u("flip", "faceup")];
		case "wrath-4": return e.control === r ? [f(null), l(2, i)] : [];
		case "flexible-0": return [u("return|shift")];
		case "flexible-1": return [u("flip|shift", "own")];
		case "flexible-3": return [u("shiftOrSwap", "opp")];
		case "rigid-1": return [u("flip", "opp faceup")];
		case "rigid-3": return [s("handPlay", {
			line: n.line,
			token: n.card.token
		})];
		case "inert-0": return [u("flip", "all faceup different")];
		case "inert-2": return [s("group", {
			mode: "flip",
			filter: "highest"
		})];
		case "inert-3": return [_([
			0,
			1,
			2
		].filter((e) => e !== n.line).map((e) => s("handPlay", { line: e }))), s("handPlay", {
			side: i,
			line: n.line
		})];
		case "inert-4": return [s("discardDeck"), s("discardDeck", { side: i })];
		default: return [];
	}
}
function It(e, t) {
	let n = W(e, t.src.token), r = n.side, i = lt(r), a = t.src.slot, o = t.card ?? n.card.id;
	if ([...C, ...ie].includes(j[o].protocol)) return Ft(e, t);
	let s = (e, n = {}) => ({
		t: e,
		side: r,
		src: t.src,
		...n
	}), c = (e, t = r, n = t) => s("draw", {
		side: t,
		n: e,
		origin: n
	}), l = (e, t = r, n) => s("discard", {
		side: t,
		actor: r,
		n: e,
		after: n
	}), u = (e, t = "", n = !1, r = {}) => s("manipulate", {
		mode: e,
		filter: t,
		optional: n,
		...r
	}), d = (e, t = {}) => s(e, {
		token: n.card.token,
		...t
	}), f = (e, t = {}) => s("deckPlay", {
		line: e,
		...t
	}), p = (e) => s("each", { list: e }), m = (e, t = !1) => s("arrangeChoice", {
		dest: e,
		mode: t ? "swap" : void 0
	}), h = (e, t = 1, n = r) => s("discardMany", {
		after: e,
		min: t,
		side: n,
		actor: r
	}), g = () => G(e).filter((e) => e.card.up && j[e.card.id].protocol === "unity").length, _ = (t) => new Set(G(e).filter((e) => e.card.up && (t === void 0 || e.line === t)).map((e) => j[e.card.id].protocol)).size, ee = ht(e);
	if (a === "top") switch (o) {
		case "death-1": return [s("optional", { list: [s("draw", {
			n: 1,
			after: "death"
		})] })];
		case "corruption-0": return [u("flip", "stack all up other")];
		case "corruption-2": return [l(1, i)];
		case "corruption-6": return [s("discardOrSelf", { mode: "delete" })];
		case "courage-0": return e.hands[r].length === 0 ? [c(1)] : [];
		case "courage-6": return ee[i][n.line] > ee[r][n.line] ? [d("flip")] : [];
		case "clarity-1": return [s("reveal", {
			side: r,
			cards: e.decks[r].slice(0, 1)
		}), s("optional", { list: [s("discardDeck", { n: 1 })] })];
		case "hate-3":
		case "plague-1":
		case "speed-1": return [c(1)];
		case "ice-3":
		case "unity-1": return K(n) ? [] : [u("shift", "", !0, { token: n.card.token })];
		case "life-0": return K(n) ? [] : [d("delete")];
		case "spirit-3": return [u("shift", "", !0, { token: n.card.token })];
		case "time-2": return [c(1), u("shift", "", !0, { token: n.card.token })];
		case "unity-4": return e.hands[r].length === 0 ? [
			s("reveal", { cards: [...e.decks[r]] }),
			s("unityDraw"),
			s("shuffle")
		] : [];
		case "diversity-6": return _() < 4 ? [d("delete")] : [];
		case "war-0": return [s("optional", { list: [d("flip")] })];
		default: return [];
	}
	if (a === "bottom") switch (o) {
		case "apathy-2": return [d("flip")];
		case "assimilation-1": return [c(1, r, i), s("discard", {
			side: r,
			actor: r,
			n: 1,
			dest: i
		})];
		case "assimilation-2": return [f(n.line, { origin: i })];
		case "assimilation-6": return [f(void 0, { dest: i })];
		case "chaos-0": return [c(1, r, i), c(1, i, r)];
		case "chaos-4": return [l(e.hands[r].length, r, "redraw")];
		case "clarity-1": return [c(3)];
		case "courage-0": return [s("optional", { list: [l(1, r, "opponent")] })];
		case "courage-2": return ee[i][n.line] > ee[r][n.line] ? [c(1)] : [];
		case "courage-3": {
			let e = Math.max(...ee[i]);
			return [s("selfShift", {
				ids: [
					0,
					1,
					2
				].filter((t) => t !== n.line && ee[i][t] === e),
				optional: !0
			})];
		}
		case "fire-0": return [c(1), u("flip", "other")];
		case "fire-3": return [s("optional", { list: [l(1, r, "flip")] })];
		case "hate-4": return [u("delete", "line covered lowest")];
		case "ice-1": return [l(1, i)];
		case "life-3": return [s("deckOther")];
		case "light-1":
		case "mirror-4":
		case "peace-4": return [c(1)];
		case "love-1": return [s("give", {
			optional: !0,
			after: "draw2"
		})];
		case "mirror-1": return [s("copyMid")];
		case "peace-1": return e.hands[r].length === 0 ? [c(1)] : [];
		case "plague-4": return [s("manipulate", {
			side: i,
			mode: "delete",
			filter: "own down"
		}), s("optional", { list: [d("flip")] })];
		case "psychic-1": return [d("flip")];
		case "psychic-4": return [u("return", "opp", !0, { list: [d("flip")] })];
		case "speed-3": return [u("shift", "own", !0, { list: [d("flip")] })];
		case "spirit-1": return [s("discardOrSelf", { mode: "flip" })];
		case "unity-0": return [s("flipOrDraw")];
		case "diversity-0": return [s("handPlay", {
			line: n.line,
			filter: "nonDiversity",
			flag: !0,
			optional: !0,
			mode: "any"
		})];
		case "war-0": return [u("delete", "", !0)];
		case "war-1": return [h("refresh", 0)];
		case "war-2": return [l(e.hands[i].length, i)];
		case "war-3": return [s("handPlay", { optional: !0 })];
		default: return [];
	}
	if (j[o].mid.en === "You discard 1 card." || j[o].mid.en === "Discard 1 card.") return [l(1)];
	switch (o) {
		case "apathy-1": return [s("group", {
			mode: "flip",
			line: n.line,
			filter: "all up other"
		})];
		case "apathy-3": return [u("flip", "opp up")];
		case "apathy-4": return [u("flip", "own covered up", !0)];
		case "assimilation-0": return [u("take", "opp both down")];
		case "assimilation-1": return [l(1), s("refresh")];
		case "assimilation-4": return [c(1, r, i), c(1, i, r)];
		case "chaos-0": return [p([
			0,
			1,
			2
		].map((e) => u("flip", "covered", !1, { line: e })))];
		case "chaos-1": return [m(r), m(i)];
		case "chaos-2": return [u("shift", "own covered")];
		case "clarity-1":
		case "light-4": return [s("revealHand", { side: i })];
		case "clarity-2": return [s("searchDeck", { n: 1 }), s("handPlay", {
			mode: "any",
			n: 1
		})];
		case "clarity-3": return [s("searchDeck", { n: 5 })];
		case "clarity-4":
		case "time-2": return e.trash[r].length ? [s("optional", { list: [s("shuffle", { flag: !0 })] })] : [];
		case "corruption-1": return [u("return")];
		case "corruption-2": return [c(1), l(1)];
		case "corruption-3": return [u("flip", "covered up", !0)];
		case "courage-0":
		case "courage-2":
		case "war-3": return [c(1)];
		case "courage-1": return [u("delete", "opp higher")];
		case "darkness-0": return [c(3), u("shift", "opp covered")];
		case "darkness-1": return [u("flip", "opp", !1, { list: [u("shift", "", !0)] })];
		case "darkness-2": return [u("flip", "line covered", !0)];
		case "darkness-3": return [s("handPlay", { filter: "other" })];
		case "darkness-4": return [u("shift", "down")];
		case "death-0": return [p([
			0,
			1,
			2
		].filter((e) => e !== n.line).map((e) => u("delete", "", !1, { line: e })))];
		case "death-2": return [s("group", {
			mode: "delete",
			filter: "values12"
		})];
		case "death-3": return [u("delete", "down")];
		case "death-4": return [u("delete", "low01")];
		case "diversity-0": return _() >= 6 ? [s("directCompile", { card: "diversity" })] : [];
		case "diversity-1": return [u("shift"), s("drawDiversity", { line: n.line })];
		case "diversity-4": return [u("flip", "diversity")];
		case "fear-0": return [u("shift|flip")];
		case "fear-1": return [c(2), l(e.hands[i].length, i, "redrawLess")];
		case "fear-2": return [u("return", "opp")];
		case "fear-3": return [u("shift", "opp both line")];
		case "fear-4": return [s("randomDiscard", { side: i })];
		case "fire-0": return [u("flip", "other"), c(2)];
		case "fire-1": return [l(1, r, "delete")];
		case "fire-2": return [l(1, r, "return")];
		case "fire-4": return [h("drawMore")];
		case "gravity-0": return [s("underRepeat", { n: Math.floor(G(e).filter((e) => e.line === n.line).length / 2) })];
		case "gravity-1": return [c(2), u("shift", "gravity")];
		case "gravity-2": return [u("flip", "", !1, { list: [u("shift", "", !1, { line: n.line })] })];
		case "gravity-4": return [u("shift", "down", !1, { line: n.line })];
		case "gravity-6": return [f(n.line, { side: i })];
		case "hate-0": return [u("delete")];
		case "hate-1": return [
			l(3),
			u("delete"),
			u("delete")
		];
		case "hate-2": return [u("delete", "own highest"), u("delete", "opp highest")];
		case "ice-1": return [u("shift", "", !0, { token: n.card.token })];
		case "ice-2": return [u("shift", "other")];
		case "life-0": return [p([
			0,
			1,
			2
		].filter((t) => e.field[r][t].length).map((e) => f(e)))];
		case "life-1": return [u("flip"), u("flip")];
		case "life-2": return [c(1), u("flip", "down", !0)];
		case "life-4": return n.index > 0 ? [c(1)] : [];
		case "light-0": return [u("flip", "", !1, { list: [s("drawTarget")] })];
		case "light-2": return [c(2), u("reveal", "down", !1, { list: [u("shift|flip", "", !0)] })];
		case "light-3": return [s("shiftAllDown", { line: n.line })];
		case "love-1": return [c(1, r, i)];
		case "love-2": return [c(1, i), s("refresh")];
		case "love-3": return [s("stealRandom"), s("give")];
		case "love-4": return [s("revealOne"), u("flip")];
		case "love-6": return [c(2, i)];
		case "luck-0": return [s("declareNumber")];
		case "luck-1": return [f(void 0, { after: "flipQuiet" })];
		case "luck-2": return [s("discardTop", { after: "drawValue" })];
		case "luck-3": return [s("declareProtocol")];
		case "luck-4": return [s("discardTop", { after: "deleteValue" })];
		case "metal-0":
		case "war-2": return [u("flip")];
		case "metal-1": return [c(2), s("metalLock")];
		case "metal-3": return [c(1), s("group", {
			mode: "delete",
			filter: "eightOther"
		})];
		case "mirror-2": return [s("swapStacksChoice")];
		case "mirror-3": return [u("flip", "own", !1, { list: [u("flip", "opp", !1, { from: "lineTarget" })] })];
		case "peace-1": return [s("each", { list: [l(e.hands[r].length), l(e.hands[i].length, i)] })];
		case "peace-2": return [c(1), s("handPlay")];
		case "peace-3": return [s("optional", { list: [l(1)] }), u("flip", "peace")];
		case "peace-6": return e.hands[r].length > 1 ? [d("flip")] : [];
		case "plague-0":
		case "plague-1":
		case "war-4": return [l(1, i)];
		case "plague-2": return [h("opponentMore")];
		case "plague-3": return [p(G(e).filter((e) => e.card.up && K(e) && e.card.token !== n.card.token).map((e) => s("flip", { token: e.card.token })))];
		case "psychic-0": return [
			c(2),
			l(2, i),
			s("revealHand", { side: i })
		];
		case "psychic-2": return [l(2, i), m(i)];
		case "psychic-3": return [l(1, i), u("shift", "opp")];
		case "smoke-0": return [p([
			0,
			1,
			2
		].filter((t) => e.field.some((e) => e[t].some((e) => !e.up))).map((e) => f(e)))];
		case "smoke-1": return [u("flip", "own", !1, { list: [u("shift", "", !0)] })];
		case "smoke-3": return [s("handPlay", { filter: "smoke" })];
		case "smoke-4": return [u("shift", "covered down")];
		case "speed-0": return [s("handPlay", { mode: "any" })];
		case "speed-1": return [c(2)];
		case "speed-3": return [u("shift", "own other")];
		case "speed-4": return [u("shift", "opp down")];
		case "spirit-0": return [s("refresh"), c(1)];
		case "spirit-1": return [c(2)];
		case "spirit-2": return [u("flip", "", !0)];
		case "spirit-4": return [m(r, !0)];
		case "time-0": return [s("handPlay", {
			from: "trash",
			mode: "any"
		}), s("shuffle", { flag: !0 })];
		case "time-1": return [u("flip", "covered"), s("discardDeck")];
		case "time-3": return [s("handPlay", {
			from: "trash",
			filter: "other",
			after: "reveal"
		})];
		case "time-4": return [c(2), l(2)];
		case "unity-0": return g() > 1 ? [s("flipOrDraw")] : [];
		case "unity-1": return g() >= 5 ? [s("directCompile", { card: "unity" })] : [];
		case "unity-2": return [c(g())];
		case "unity-3": return g() > 1 ? [u("flip", "up", !0)] : [];
		case "water-0": return [u("flip", "other"), d("flip")];
		case "water-1": return [p([
			0,
			1,
			2
		].filter((e) => e !== n.line).map((e) => f(e)))];
		case "water-2": return [c(2), m(r)];
		case "water-3": return [s("group", {
			mode: "return",
			filter: "twos"
		})];
		case "water-4": return [u("return", "own")];
		default: return [];
	}
}
function Lt(t, n) {
	if (!pt(t, n.src)) return;
	let r = n.side, i = lt(r), a = n.src ? W(t, n.src.token) : void 0, o = a?.card.id ?? null, s = (e, t = {}) => ({
		t: e,
		side: r,
		src: n.src,
		...t
	}), c = (e, i, a, s = r) => Q(t, e, s, i.map((t) => ({
		view: {
			kind: e,
			line: t,
			side: n.dest ?? r
		},
		ops: a(t)
	})), o), l = (e) => t.decks[e].length + t.trash[e].length > 0 && !(t.hands[e].length && G(t).some((n) => n.side === e && n.card.id === "ice-6" && q(t, n, "top")));
	switch (n.t) {
		case "draft": {
			let e = n.card;
			if (!t.available.includes(e)) break;
			t.available = t.available.filter((t) => t !== e), r === 1 && !t.solo ? t.protocols[r].unshift({
				name: e,
				compiled: !1
			}) : t.protocols[r].push({
				name: e,
				compiled: !1
			}), t.draftAt++, t.draftAt === (t.solo ? 3 : 6) ? Mt(t) : Nt(t);
			break;
		}
		case "command":
			Y(t, It(t, n));
			break;
		case "each":
		case "order": {
			let e = (n.list ?? []).filter((e) => pt(t, e.src));
			e.length === 1 ? Y(t, e) : e.length > 1 && Q(t, n.t, n.t === "order" ? t.turn : r, e.map((t, r) => ({
				view: {
					kind: "order",
					side: t.side,
					token: t.src?.token,
					source: t.card ?? o ?? void 0,
					slot: t.src?.slot,
					line: t.line
				},
				ops: [t, {
					...n,
					list: e.filter((e, t) => r !== t)
				}]
			})), o);
			break;
		}
		case "phase":
			switch (t.turn = r, n.mode) {
				case "start":
				case "end": {
					n.mode === "start" && (t.turnProgress = !1, t.turnOffered = !1, t.metalLocks = t.metalLocks.filter((e) => e.round >= t.round));
					let e = n.mode === "start" ? "Start:" : "End:", i = G(t).filter((e) => e.side === r).flatMap((n) => ["top", "bottom"].filter((r) => q(t, n, r) && j[n.card.id][r].en.startsWith(e)).map((e) => mt(t, n, e)));
					Y(t, [{
						t: "phase",
						side: r,
						mode: n.mode === "start" ? "checkControl" : "next"
					}]), _t(t, i);
					break;
				}
				case "checkControl": {
					Y(t, [{
						t: "phase",
						side: r,
						mode: "checkCompile"
					}]);
					let e = ht(t);
					e[r].filter((t, n) => t > e[i][n]).length >= 2 && yt(t, r);
					break;
				}
				case "checkCompile":
					Et(t, r).length ? (Y(t, [{
						t: "phase",
						side: r,
						mode: "cache"
					}]), Lt(t, {
						t: "compileChoice",
						side: r
					})) : Y(t, [{
						t: "phase",
						side: r,
						mode: "action"
					}]);
					break;
				case "action":
					if (Y(t, [{
						t: "phase",
						side: r,
						mode: "cache"
					}]), t.solo && r === 1) t.hands[r].length ? Y(t, oe[t.config.scenario].plays.map((e) => ({
						t: "soloPlay",
						side: r,
						mode: e
					}))) : l(r) && Y(t, [{
						t: "refresh",
						side: r
					}]);
					else {
						let e = kt(t, {
							t: "play",
							side: r
						}).map((e) => ({
							...e,
							ops: e.ops.map((e) => ({
								...e,
								flag: !0
							}))
						}));
						t.hands[r].length < 5 && l(r) && e.push({
							view: { kind: "refresh" },
							ops: [{
								t: "refresh",
								side: r
							}]
						}), Q(t, "action", r, e);
					}
					break;
				case "cache":
					Y(t, [{
						t: "phase",
						side: r,
						mode: "end"
					}]), t.hands[r].length > 5 && !G(t).some((e) => e.side === r && e.card.id === "spirit-0" && q(t, e, "bottom")) && Y(t, [{
						t: "discard",
						side: r,
						n: t.hands[r].length - 5
					}, {
						t: "event",
						side: r,
						mode: "cache"
					}]);
					break;
				case "next":
					if (t.idleTurns = !t.turnProgress && !t.turnOffered ? t.idleTurns + 1 : 0, t.idleTurns >= 2) {
						Dt(t, -1);
						break;
					}
					t.round++, t.revealed = [], Y(t, [{
						t: "phase",
						side: i,
						mode: "start"
					}]);
			}
			break;
		case "event":
			$(t, n.mode, r, n.line);
			break;
		case "optional":
			Q(t, "optional", r, [{
				view: { kind: "accept" },
				ops: n.list ?? []
			}, {
				view: { kind: "skip" },
				ops: []
			}], o);
			break;
		case "draw": {
			let e = t.queue.length, i = bt(t, r, n.n ?? 1, n.origin ?? n.line ?? r), o = t.queue.length - e, c = n.after === "death" && i.length ? [s("manipulate", {
				mode: "delete",
				filter: "other"
			}), s("delete", { token: a.card.token })] : n.after === "luck" ? [s("luckDrawn", {
				cards: i,
				n: n.count
			})] : [];
			t.queue.splice(o, 0, ...c);
			break;
		}
		case "control":
			yt(t, n.n === -1 ? null : n.n);
			break;
		case "refreshIfOwn":
			n.flag && Y(t, [s("refresh")]);
			break;
		case "refresh":
			if (t.hands[r].length >= 5 || !l(r)) break;
			if (t.config.control && t.control === r && !n.mode) {
				Y(t, [{
					...n,
					mode: "ready"
				}]), Lt(t, {
					t: "useControl",
					side: r
				});
				break;
			}
			Y(t, [{
				t: "event",
				side: r,
				mode: "refresh"
			}]), bt(t, r, 5 - t.hands[r].length, r, !0);
			break;
		case "useControl":
			if (yt(t, null), t.solo && r === 1) switch (oe[t.config.scenario].control) {
				case "draw":
					Y(t, [{
						t: "draw",
						side: r,
						n: 1
					}]);
					break;
				case "steal":
					Y(t, [{
						t: "draw",
						side: r,
						n: 1,
						origin: 0
					}]);
					break;
				case "rearrange": Q(t, "rearrange", 0, [...Tt(t, 0, 0), ...Tt(t, 0, 1)]);
			}
			else Q(t, "rearrange", r, [
				...Tt(t, r, r),
				...Tt(t, r, i),
				{
					view: { kind: "skip" },
					ops: []
				}
			]);
			break;
		case "compileChoice":
			c("compile", Et(t, r), (e) => [{
				t: "compile",
				side: r,
				line: e
			}]);
			break;
		case "compile": {
			if (n.mode !== "ready" && !Et(t, r).includes(n.line)) break;
			if (t.config.control && t.control === r && !n.mode) {
				Y(t, [{
					...n,
					mode: "ready"
				}]), Lt(t, {
					t: "useControl",
					side: r
				});
				break;
			}
			let e = G(t).find((e) => e.line === n.line && e.card.id === "speed-2" && q(t, e, "top"));
			e ? Q(t, "shift", e.side, [
				0,
				1,
				2
			].filter((e) => e !== n.line).map((t) => ({
				view: {
					kind: "shift",
					token: e.card.token,
					line: t,
					side: e.side
				},
				ops: [{
					...n,
					t: "compileDelete",
					token: e.card.token,
					n: t
				}]
			}))) : Y(t, [{
				...n,
				t: "compileDelete"
			}]);
			break;
		}
		case "compileDelete": {
			let e = n.line, a = t.protocols[r][e].compiled, o = n.token === void 0 ? void 0 : W(t, n.token), s;
			o && (s = o.card, o.stack.splice(o.index, 1));
			for (let n = 0; n < 2; n++) {
				for (let r of t.field[n][e]) Z(t, "compileDelete", n, `depart:${r.token}`, `trash:${n}`, r);
				t.trash[n].push(...t.field[n][e].map((e) => e.id)), t.field[n][e] = [];
			}
			t.protocols[r][e].compiled = !0, X(t, "compile", r, e), Z(t, "compile", r, `stack:${r}:${e}`, `protocol:${r}:${e}`), a && t.solo && r === 1 || t.protocols[r].every((e) => e.compiled) ? Y(t, [{
				t: "victory",
				side: r
			}]) : Y(t, [...a ? [{
				t: "draw",
				side: r,
				n: 1,
				origin: i
			}] : [], {
				t: "compileAfter",
				side: r
			}]), s && o && Y(t, [{
				t: "commit",
				side: o.side,
				actor: o.side,
				line: n.n,
				card: s.id,
				token: s.token,
				up: s.up,
				n: s.rev,
				epoch: s.epoch,
				flag: !0,
				from: `depart:${s.token}`,
				filter: "shiftCovered"
			}]);
			break;
		}
		case "compileAfter":
			_t(t, [...vt(t, "delete", r), ...vt(t, "compile", r)]);
			break;
		case "victory":
			Dt(t, r);
			break;
		case "directCompile": {
			let e = t.protocols[r].findIndex((e) => e.name === n.card);
			if (e < 0) break;
			t.protocols[r][e].compiled = !0, X(t, "compile", r, e), Z(t, "compile", r, `stack:${r}:${e}`, `protocol:${r}:${e}`), t.protocols[r].every((e) => e.compiled) && Y(t, [{
				t: "victory",
				side: r
			}]), n.flag && Y(t, [s("multiDelete", { ids: G(t).filter((t) => t.line === e).map((e) => e.card.token) })]);
			break;
		}
		case "metalLock":
			a && t.metalLocks.push({
				token: a.card.token,
				rev: a.card.rev,
				side: i,
				round: t.round + (r === t.turn ? 1 : 2)
			});
			break;
		case "discardMany": {
			let e = t.hands[r].length, i = Math.min(n.min ?? 1, e);
			Q(t, "discardCount", r, Array.from({ length: e - i + 1 }, (e, t) => t + i).map((e) => ({
				view: {
					kind: "count",
					n: e
				},
				ops: [{
					...n,
					t: "discard",
					n: e,
					count: 0
				}]
			})), o);
			break;
		}
		case "discard": {
			let e = Math.min(n.n ?? 1, t.hands[r].length);
			if (!e) {
				Y(t, [{
					...n,
					t: "discardDone",
					n: n.count ?? 0
				}]);
				break;
			}
			if (e === t.hands[r].length || t.solo && r === 1) {
				let i = t.hands[r].splice(0, e);
				t.trash[n.dest ?? r].push(...i), X(t, "discard", r, void 0, e);
				for (let e of i) Z(t, "discard", r, `depart:hand:${r}:${e}`, `trash:${n.dest ?? r}`, e);
				Y(t, [{
					...n,
					t: "discardDone",
					n: (n.count ?? 0) + e
				}]);
			} else Q(t, "discard", r, t.hands[r].map((t) => ({
				view: {
					kind: "discard",
					card: t,
					side: r
				},
				ops: [{
					...n,
					t: "discardOne",
					card: t,
					n: e
				}]
			})), o);
			break;
		}
		case "discardOne": {
			let e = t.hands[r].indexOf(n.card);
			if (e < 0) break;
			let [i] = t.hands[r].splice(e, 1);
			t.trash[n.dest ?? r].push(i), X(t, "discard", r, void 0, 1, i), Z(t, "discard", r, `depart:hand:${r}:${i}`, `trash:${n.dest ?? r}`, i), Y(t, [{
				...n,
				t: "discard",
				n: (n.n ?? 1) - 1,
				count: (n.count ?? 0) + 1
			}]);
			break;
		}
		case "discardDone":
			Y(t, [{
				...n,
				t: "afterDiscard",
				side: n.actor ?? r,
				dest: r
			}]), n.n && $(t, "discard", r);
			break;
		case "afterDiscard": {
			let e = n.n ?? 0, a = n.dest ?? r;
			n.after === "redraw" && Y(t, [s("draw", {
				side: a,
				n: e
			})]), n.after === "redrawLess" && Y(t, [s("draw", {
				side: a,
				n: Math.max(0, e - 1)
			})]), n.after === "drawMore" && Y(t, [s("draw", { n: e + 1 })]), n.after === "opponentMore" && Y(t, [s("discard", {
				side: i,
				n: e + 1
			})]), n.after === "refresh" && Y(t, [s("refresh")]), e && n.after === "opponent" && Y(t, [s("discard", {
				side: i,
				n: 1
			})]), e && [
				"delete",
				"return",
				"flip"
			].includes(n.after ?? "") && Y(t, [s("manipulate", { mode: n.after })]);
			break;
		}
		case "discardOrSelf": {
			let e = [{
				view: {
					kind: n.mode,
					token: a.card.token,
					side: r
				},
				ops: [s(n.mode, { token: a.card.token })]
			}];
			t.hands[r].length && e.push({
				view: { kind: "discard" },
				ops: [s("discard", { n: 1 })]
			}), Q(t, "discardOrSelf", r, e, o);
			break;
		}
		case "randomDiscard": {
			if (!t.hands[r].length) break;
			let [n] = t.hands[r].splice(e(t.seed, t.cursor++, t.hands[r].length), 1);
			t.trash[r].push(n), X(t, "discard", r, void 0, 1, n), Z(t, "discard", r, `depart:hand:${r}:${n}`, `trash:${r}`, n), $(t, "discard", r);
			break;
		}
		case "discardDeck":
		case "discardTop": {
			let e = t.decks[r].splice(0, n.t === "discardTop" ? 1 : n.n ?? t.decks[r].length);
			if (!e.length) break;
			t.trash[r].push(...e), X(t, "discardDeck", r, void 0, e.length), Z(t, "discard", r, `deck:${r}`, `trash:${r}`), n.after && Y(t, [{
				...n,
				t: "afterTop",
				card: e[0]
			}]), $(t, "discard", n.actor ?? r);
			break;
		}
		case "afterTop": {
			let e = n.actor ?? r, i = j[n.card];
			n.after === "drawValue" && Y(t, [s("draw", {
				side: e,
				n: i.value
			})]), n.after === "deleteValue" && Y(t, [s("manipulate", {
				side: e,
				mode: "delete",
				filter: "all",
				n: i.value
			})]), n.after === "namedProtocol" && i.protocol === n.filter && Y(t, [s("manipulate", {
				side: e,
				mode: "delete"
			})]);
			break;
		}
		case "shuffle":
			n.flag && (t.decks[r].push(...t.trash[r]), t.trash[r] = []), t.decks[r] = gt(t, t.decks[r]), X(t, "shuffle", r), $(t, "shuffle", r);
			break;
		case "revealHand":
			Y(t, [{
				...n,
				t: "reveal",
				cards: [...t.hands[r]]
			}]);
			break;
		case "reveal": {
			let e = n.token === void 0 ? void 0 : W(t, n.token), i = n.cards ?? (e ? [e.card.id] : []);
			if (!i.length) break;
			t.revealed = [{
				side: e?.side ?? r,
				cards: i
			}], t.beat = U.reveal, Q(t, "reveal", a?.side ?? r, [{
				view: { kind: "continue" },
				ops: [{
					t: "hideReveal",
					side: r
				}]
			}], o);
			break;
		}
		case "hideReveal":
			t.revealed = [];
			break;
		case "revealOne":
			Q(t, "revealOne", r, t.hands[r].map((e) => ({
				view: {
					kind: "reveal",
					card: e,
					side: r
				},
				ops: [s("reveal", { cards: [e] })]
			})), o);
			break;
		case "give": {
			let e = t.hands[r].map((e) => ({
				view: {
					kind: "give",
					card: e,
					side: r
				},
				ops: [s("giveOne", {
					card: e,
					after: n.after
				})]
			}));
			n.optional && e.push({
				view: { kind: "skip" },
				ops: []
			}), Q(t, "give", r, e, o);
			break;
		}
		case "giveOne": {
			let e = t.hands[r].indexOf(n.card);
			if (e < 0) break;
			let [a] = t.hands[r].splice(e, 1);
			t.hands[i].push(a), X(t, "give", r, void 0, 1), Z(t, "give", r, `hand:${r}`, `hand:${i}`), n.after === "draw2" && Y(t, [s("draw", { n: 2 })]);
			break;
		}
		case "stealRandom": {
			if (!t.hands[i].length) break;
			let [n] = t.hands[i].splice(e(t.seed, t.cursor++, t.hands[i].length), 1);
			t.hands[r].push(n), Z(t, "take", r, `hand:${i}`, `hand:${r}`);
			break;
		}
		case "declareNumber":
			Q(t, "declareNumber", r, Array.from({ length: 8 }, (e, t) => ({
				view: {
					kind: "number",
					n: t
				},
				ops: [s("draw", {
					n: 3,
					count: t,
					after: "luck"
				})]
			})), o);
			break;
		case "luckDrawn":
			Q(t, "luckDrawn", r, (n.cards ?? []).filter((e) => j[e].value === n.n && t.hands[r].includes(e)).map((e) => ({
				view: {
					kind: "reveal",
					card: e,
					side: r
				},
				ops: [s("reveal", { cards: [e] }), s("handPlay", {
					mode: "any",
					cards: [e],
					optional: !0
				})]
			})), o);
			break;
		case "declareProtocol":
			Q(t, "declareProtocol", r, ue.map((e) => ({
				view: {
					kind: "protocol",
					card: e
				},
				ops: [s("discardTop", {
					side: i,
					actor: r,
					after: "namedProtocol",
					filter: e
				})]
			})), o);
			break;
		case "searchDeck":
			Y(t, [s("reveal", { cards: [...t.decks[r]] }), s("searchChoice", { n: n.n })]);
			break;
		case "searchChoice": {
			let e = t.decks[r].filter((e) => j[e].value === n.n).map((e) => ({
				view: {
					kind: "take",
					card: e,
					side: r
				},
				ops: [s("searchTake", { card: e }), s("shuffle")]
			}));
			e.length ? Q(t, "searchDeck", r, e, o) : Y(t, [s("shuffle")]);
			break;
		}
		case "searchTake": {
			if (t.hands[r].length && G(t).some((e) => e.side === r && e.card.id === "ice-6" && q(t, e, "top"))) break;
			let e = t.decks[r].indexOf(n.card);
			if (e < 0) break;
			let [i] = t.decks[r].splice(e, 1);
			t.hands[r].push(i), Z(t, "draw", r, `deck:${r}`, `hand:${r}`), $(t, "draw", r);
			break;
		}
		case "unityDraw": {
			if (t.hands[r].length && G(t).some((e) => e.side === r && e.card.id === "ice-6" && q(t, e, "top"))) break;
			let e = t.decks[r].filter((e) => j[e].protocol === "unity");
			t.decks[r] = t.decks[r].filter((t) => !e.includes(t)), t.hands[r].push(...e), e.length && (Z(t, "draw", r, `deck:${r}`, `hand:${r}`), $(t, "draw", r));
			break;
		}
		case "drawTarget": {
			let e = W(t, n.token);
			Y(t, [s("draw", { n: e ? J(t, e) : t.trash.some((e) => e.includes(n.card)) ? j[n.card].value : 2 })]);
			break;
		}
		case "drawDiversity":
			Y(t, [s("draw", { n: new Set(G(t).filter((e) => e.line === (a?.line ?? n.line) && e.card.up).map((e) => j[e.card.id].protocol)).size })]);
			break;
		case "copyMid":
			Q(t, "copyMid", r, [...G(t).filter((e) => e.side === i && q(t, e, "mid")).map((e) => ({
				view: {
					kind: "order",
					token: e.card.token,
					side: e.side,
					source: e.card.id,
					slot: "mid"
				},
				ops: [s("copyCommand", { card: e.card.id })]
			})), {
				view: { kind: "skip" },
				ops: []
			}], o);
			break;
		case "copyCommand":
			Y(t, It(t, {
				...n,
				src: {
					...n.src,
					slot: "mid"
				}
			}).map((e) => ({
				...e,
				src: n.src
			})));
			break;
		case "flipOrDraw":
			Q(t, "flipOrDraw", r, [{
				view: { kind: "flip" },
				ops: [s("manipulate", { mode: "flip" })]
			}, {
				view: { kind: "draw" },
				ops: [s("draw", { n: 1 })]
			}], o);
			break;
		case "manipulate":
			jt(t, n);
			break;
		case "selfShift":
			c("shift", n.ids ?? [], (e) => [s("shift", {
				token: a.card.token,
				line: e
			})]), n.optional && t.pending && t.pending.options.push({
				view: {
					id: `${t.decision}:skip`,
					kind: "skip"
				},
				ops: []
			});
			break;
		case "handPlay": {
			let e = n.mode ?? "down", i = (n.cards ?? (n.from === "trash" ? t.trash[r] : t.solo && r === 1 ? t.hands[r].slice(0, 1) : t.hands[r])).filter((e) => n.n === void 0 || j[e].value === n.n).filter((e) => !n.filter?.includes("nonDiversity") || j[e].protocol !== "diversity"), a = kt(t, {
				...n,
				mode: e,
				cards: i
			}).map((e) => ({
				...e,
				ops: e.ops.flatMap((e) => [...n.after === "reveal" ? [s("reveal", { cards: [e.card] })] : [], {
					...e,
					token: n.token
				}])
			}));
			n.optional && a.push({
				view: { kind: "skip" },
				ops: []
			}), Q(t, "play", r, a, o);
			break;
		}
		case "deckOther":
			c("deckLine", [
				0,
				1,
				2
			].filter((e) => e !== a?.line), (e) => [s("deckPlay", { line: e })]);
			break;
		case "deckPlay": {
			let e = n.origin ?? r, i = n.dest ?? r;
			if (!t.decks[e].length) break;
			if (n.line === void 0) {
				c("deckLine", [
					0,
					1,
					2
				].filter((n) => Ot(t, r, i, t.decks[e][0], n, !1)), (e) => [{
					...n,
					line: e
				}]);
				break;
			}
			if (!Ot(t, r, i, t.decks[e][0], n.line, !1)) break;
			let a = t.decks[e].shift(), o = t.nextToken++;
			Y(t, [{
				t: "commit",
				side: i,
				actor: r,
				line: n.line,
				card: a,
				token: o,
				up: !1,
				from: `deck:${e}`
			}, ...n.after === "flipQuiet" ? [s("flip", {
				token: o,
				mode: "quiet"
			})] : []]);
			break;
		}
		case "underRepeat":
			(n.n ?? 0) > 0 && Y(t, [s("deckUnder", { token: a.card.token }), {
				...n,
				n: n.n - 1
			}]);
			break;
		case "deckUnder": {
			let e = W(t, n.token);
			if (!e || !t.decks[r].length) break;
			let i = t.decks[r].shift();
			Y(t, [{
				t: "commit",
				side: r,
				line: e.line,
				card: i,
				token: t.nextToken++,
				up: !1,
				ids: [e.card.token],
				from: `deck:${r}`
			}]);
			break;
		}
		case "play": {
			let e = n.from === "trash" ? t.trash[r] : t.hands[r], i = e.indexOf(n.card);
			if (i < 0) break;
			e.splice(i, 1), Y(t, [{
				t: "commit",
				side: n.dest ?? r,
				actor: r,
				card: n.card,
				token: t.nextToken++,
				up: n.up,
				line: n.line,
				n: 0,
				ids: n.token === void 0 ? void 0 : [n.token],
				from: n.from === "trash" ? `trash:${r}` : `depart:hand:${r}:${n.card}`,
				filter: n.flag && !n.up ? "actionDown" : void 0
			}]);
			break;
		}
		case "commit": {
			let e = t.field[r][n.line], i = n.ids?.[0], a = i === void 0 ? -1 : e.findIndex((e) => e.token === i), o = e.at(-1);
			if (a < 0 && o && !n.handled?.includes(o.token)) {
				let e = W(t, o.token), r = o.id, i;
				if (r === "metal-6" && q(t, e, "top") ? i = {
					t: "delete",
					side: e.side,
					token: o.token
				} : [
					"fire-0",
					"life-3",
					"hate-4",
					"apathy-2",
					"clarity-1"
				].includes(r) && q(t, e, "bottom") || r === "unity-0" && n.up && j[n.card].protocol === "unity" && q(t, e, "bottom") ? i = mt(t, e, "bottom") : r === "sloth-4" && q(t, e, "mid") ? i = {
					t: "manipulate",
					side: e.side,
					mode: "flip",
					filter: "up"
				} : r === "rigid-4" && !n.up && q(t, e, "bottom") && (i = {
					t: "draw",
					side: e.side,
					n: 1
				}), i) {
					Y(t, [i, {
						...n,
						handled: [...n.handled ?? [], o.token]
					}]);
					break;
				}
			}
			a < 0 && o && o.epoch++;
			let s = {
				id: n.card,
				token: n.token,
				up: n.up,
				rev: n.n ?? 0,
				epoch: n.epoch ?? 0
			};
			a < 0 ? e.push(s) : e.splice(a, 0, s), X(t, n.flag ? "shift" : "play", r, n.line, 1, s.up ? s.id : void 0), t.last = {
				kind: n.flag ? "shift" : "play",
				side: r,
				line: n.line,
				token: s.token
			}, Z(t, n.flag ? "shift" : "play", r, n.from ?? `hand:${r}`, `card:${s.token}`, s, s.token), n.flag || ($(t, "play", n.actor ?? r, n.line), n.filter === "actionDown" && $(t, "actionDown", n.actor ?? r, n.line));
			let c = W(t, s.token);
			(!n.flag || n.filter === "shiftCovered") && q(t, c, "mid") && Y(t, [mt(t, c, "mid")]);
			break;
		}
		case "flip": {
			let e = W(t, n.token);
			if (!e || St(t, e, "flip")) break;
			if (e.card.id === "metal-6" && q(t, e, "top")) {
				Ct(t, e, {
					t: "delete",
					side: e.side
				});
				break;
			}
			e.card.up = !e.card.up, e.card.rev++, e.card.epoch++, X(t, "flip", e.side, e.line, 1, e.card.up ? e.card.id : void 0), Z(t, "flip", e.side, `card:${e.card.token}`, `card:${e.card.token}`, e.card, e.card.token), n.mode !== "quiet" && q(t, e, "mid") && Y(t, [mt(t, e, "mid")]);
			break;
		}
		case "delete":
		case "return":
		case "shift":
		case "take": {
			let e = W(t, n.token);
			if (!e || St(t, e, n.t) || n.t === "shift" && (n.line === void 0 || n.line === e.line)) break;
			Ct(t, e, n);
			break;
		}
		case "land": {
			let e = n.dest ?? r;
			n.mode === "delete" ? t.trash[r].push(n.card) : n.mode === "top" ? t.decks[e].unshift(n.card) : t.hands[e].push(n.card), X(t, n.mode, r, void 0, 1, n.up ? n.card : void 0), Z(t, n.mode, r, n.from, `${n.mode === "delete" ? "trash" : n.mode === "top" ? "deck" : "hand"}:${e}`, {
				id: n.card,
				token: n.token,
				up: n.up,
				rev: 0,
				epoch: 0
			}), n.mode === "delete" && $(t, "delete", n.actor ?? r);
			break;
		}
		case "group": {
			let e = [
				0,
				1,
				2
			];
			if (n.line !== void 0 && (e = [n.line]), n.filter === "five" && (e = e.filter((e) => t.field[r][e].length === 5)), n.filter === "eightOther" && (e = e.filter((e) => e !== a?.line && t.field[0][e].length + t.field[1][e].length >= 8)), n.filter === "most") {
				let n = e.map((e) => t.field[0][e].length + t.field[1][e].length), r = Math.max(...n);
				e = e.filter((e) => n[e] === r);
			}
			Q(t, "line", r, e.flatMap((e) => {
				let i = G(t).filter((t) => t.line === e);
				if (n.filter === "values12" && (i = i.filter((e) => [1, 2].includes(J(t, e)))), n.filter === "twos" && (i = i.filter((e) => J(t, e) === 2)), n.filter === "all up other" && (i = i.filter((e) => e.card.up && e.card.token !== a?.card.token)), n.filter === "highest") {
					let e = Math.max(...i.map((e) => J(t, e)));
					i = i.filter((n) => n.card.up && J(t, n) === e);
				}
				return n.filter === "five" && (i = i.filter((e) => e.card.up)), n.mode === "flip" && (i = i.filter((e) => !St(t, e, "flip"))), i.length ? [{
					view: {
						kind: n.mode,
						line: e,
						side: r
					},
					ops: [s(n.mode === "flip" ? "multiFlip" : n.mode === "return" ? "multiReturn" : "multiDelete", { ids: i.map((e) => e.card.token) })]
				}] : [];
			}), o);
			break;
		}
		case "multiFlip": {
			let e = (n.ids ?? []).map((e) => W(t, e)).filter((e) => !!e && !St(t, e, "flip")), i = e.find((e) => e.card.id === "metal-6" && q(t, e, "top"));
			if (i) {
				Y(t, [{
					t: "delete",
					side: i.side,
					token: i.card.token
				}, n]);
				break;
			}
			for (let n of e) n.card.up = !n.card.up, n.card.rev++, n.card.epoch++, Z(t, "flip", n.side, `card:${n.card.token}`, `card:${n.card.token}`, n.card, n.card.token);
			X(t, "flip", r, void 0, e.length), n.flag && e.length && Y(t, [s("draw", { n: e.length })]), _t(t, e.filter((e) => q(t, e, "mid")).map((e) => mt(t, e, "mid")));
			break;
		}
		case "multiDelete":
		case "multiReturn": {
			let e = (n.ids ?? []).map((e) => W(t, e)).filter((e) => !!e), i = /* @__PURE__ */ new Map(), a = [];
			for (let r of e) {
				i.has(r.stack) || i.set(r.stack, r.stack.at(-1)?.token);
				let e = n.t === "multiReturn" && G(t).some((e) => e.side !== r.side && e.card.id === "corruption-1" && q(t, e, "bottom"));
				r.card.rev++, n.t === "multiDelete" ? t.trash[r.side].push(r.card.id) : e ? t.decks[r.side].unshift(r.card.id) : t.solo && r.side === 1 ? a.push(r.card.id) : t.hands[r.side].push(r.card.id), Z(t, n.t === "multiDelete" ? "delete" : "return", r.side, `depart:${r.card.token}`, `${n.t === "multiDelete" ? "trash" : e ? "deck" : "hand"}:${r.side}`, r.card);
			}
			t.hands[1].push(...gt(t, a));
			let o = [];
			for (let [e, r] of i) {
				let i = e.filter((e) => !n.ids.includes(e.token));
				if (e.splice(0, e.length, ...i), r !== e.at(-1)?.token) {
					let n = e.at(-1), r = n ? W(t, n.token) : void 0;
					r && q(t, r, "mid") && o.push(mt(t, r, "mid"));
				}
			}
			e.length && n.t === "multiDelete" && Y(t, [{
				t: "event",
				side: r,
				mode: "delete"
			}]), _t(t, o);
			break;
		}
		case "shiftAllDown": {
			let e = G(t).filter((e) => e.line === n.line && !e.card.up).map((e) => e.card.token);
			e.length && c("shift", [
				0,
				1,
				2
			].filter((e) => e !== n.line), (t) => [s("moveBatch", {
				ids: e,
				line: t
			})]);
			break;
		}
		case "moveBatch": {
			let e = (n.ids ?? []).map((e) => W(t, e)).filter((e) => !!e), r = /* @__PURE__ */ new Map(), i = [];
			for (let t of e) r.set(t.stack, t.stack.at(-1)?.token), i.push({
				t: "commit",
				side: t.side,
				line: n.line,
				card: t.card.id,
				token: t.card.token,
				up: t.card.up,
				n: t.card.rev,
				epoch: t.card.epoch,
				flag: !0,
				from: `depart:${t.card.token}`,
				filter: K(t) ? "shiftUncovered" : "shiftCovered"
			});
			for (let [e] of r) {
				let t = e.filter((e) => !n.ids.includes(e.token));
				e.splice(0, e.length, ...t);
			}
			Y(t, i);
			let a = [];
			for (let [e, n] of r) if (n !== e.at(-1)?.token) {
				let n = e.at(-1), r = n ? W(t, n.token) : void 0;
				r && q(t, r, "mid") && a.push(mt(t, r, "mid"));
			}
			_t(t, a);
			break;
		}
		case "arrangeChoice":
			Q(t, "rearrange", r, Tt(t, r, n.dest ?? n.n ?? r, n.mode === "swap", n.optional), o);
			break;
		case "rearrange": {
			let e = n.dest ?? n.n ?? r, i = t.protocols[e];
			t.protocols[e] = n.order.map((e) => i.find((t) => t.name === e));
			for (let [r, a] of i.entries()) {
				let i = n.order.indexOf(a.name);
				r !== i && t.fx.push({
					kind: "protocol",
					...t.fx.length ? { with: !0 } : {},
					data: {
						protocol: a.name,
						compiled: a.compiled,
						from: `protocol:${e}:${r}`,
						to: `protocol:${e}:${i}`
					}
				});
			}
			t.beat = U.move, X(t, "rearrange", e), $(t, "rearrange", e);
			break;
		}
		case "swapStacksChoice": {
			let e = [
				0,
				1,
				2
			].filter((e) => t.field[r][e].length);
			Q(t, "swapStacks", r, e.flatMap((t, n) => e.slice(n + 1).map((e) => ({
				view: {
					kind: "swapStacks",
					line: t,
					n: e,
					side: r
				},
				ops: [s("swapStacks", {
					line: t,
					n: e
				})]
			}))), o);
			break;
		}
		case "swapStacks": {
			let e = n.line ?? 0, i = n.n ?? 2;
			for (let n of [e, i]) for (let e of t.field[r][n]) Z(t, "shift", r, `depart:${e.token}`, `card:${e.token}`, e, e.token);
			let a = t.field[r];
			[a[e], a[i]] = [a[i], a[e]], X(t, "swapStacks", r);
			break;
		}
		case "swapEnds": {
			let e = t.protocols[r].map((e) => e.name);
			[e[0], e[2]] = [e[2], e[0]], Y(t, [s("rearrange", {
				dest: r,
				order: e
			})]);
			break;
		}
		case "bottomHand":
			Q(t, "bottomHand", r, [...t.hands[r].map((e) => ({
				view: {
					kind: "bottomHand",
					card: e,
					side: r
				},
				ops: [s("putBottom", { card: e })]
			})), {
				view: { kind: "skip" },
				ops: []
			}], o);
			break;
		case "putBottom": {
			let e = t.hands[r].indexOf(n.card);
			if (e >= 0) {
				let [n] = t.hands[r].splice(e, 1);
				t.decks[r].push(n), Z(t, "return", r, `hand:${r}`, `deck:${r}`, n);
			}
			break;
		}
		case "novaUnder":
			if (!t.decks[r].length) break;
			Q(t, "novaUnder", r, G(t).filter((e) => e.side === r && K(e) && e.card.up && j[e.card.id].protocol === "nova").map((e) => ({
				view: {
					kind: "novaUnder",
					token: e.card.token,
					side: r,
					line: e.line
				},
				ops: [s("deckUnder", { token: e.card.token })]
			})), o);
			break;
		case "randomPlay": {
			if (!t.hands[r].length) break;
			let n = t.hands[r][e(t.seed, t.cursor++, t.hands[r].length)];
			Y(t, [s("reveal", { cards: [n] }), s("handPlay", { cards: [n] })]);
			break;
		}
		case "drawOrPlay": {
			let e = t.solo && r === 1 ? t.hands[r].length ? [{
				view: { kind: "queuePlay" },
				ops: [s("queuePlay")]
			}] : [] : kt(t, {
				...n,
				mode: "any"
			});
			l(r) && e.push({
				view: { kind: "draw" },
				ops: [s("draw", { n: 1 })]
			}), Q(t, "drawOrPlay", r, e, o);
			break;
		}
		case "queuePlay": {
			let e = t.hands[r][0];
			e && Y(t, [s("reveal", { cards: [e] }), s("handPlay", {
				cards: [e],
				mode: "any"
			})]);
			break;
		}
		case "soloPlay": {
			let e = t.hands[1][0];
			if (!e) break;
			let i = [
				0,
				1,
				2
			], a = n.mode === "up";
			if (a) i = i.filter((n) => Ot(t, r, r, e, n, !0)), i.length || (a = !1, i = [
				0,
				1,
				2
			].filter((n) => Ot(t, r, r, e, n, !1)));
			else {
				let a = ht(t)[1], o = n.mode === "low" ? Math.min(...a) : Math.max(...a);
				i = i.filter((n) => a[n] === o && Ot(t, r, r, e, n, !1));
			}
			i.length === 1 ? Y(t, [{
				t: "play",
				side: r,
				card: e,
				line: i[0],
				up: a
			}]) : c("soloLine", i, (t) => [{
				t: "play",
				side: r,
				card: e,
				line: t,
				up: a
			}], 0);
			break;
		}
	}
}
function Rt(e, t, n) {
	if (e.legacy) {
		let r = rt.reduce(e, t, n);
		return "code" in r ? r : {
			...r,
			state: r.state
		};
	}
	let r = { code: "games.compile3.invalid" };
	if (e.phase === "done" || t.type === "tick" && (n.by !== "$engine" || e.pending || !e.queue.length) || t.type === "choose" && (!e.pending || e.pending.actor !== n.by || !e.pending.options.some((e) => e.view.id === t.id))) return r;
	let i = structuredClone(e);
	if (i.fx = [], i.beat = U.phase, t.type === "choose") {
		let e = i.pending.options.find((e) => e.view.id === t.id);
		i.pending = null, i.phase = "resolve", Y(i, e.ops);
	}
	let a = i.queue.shift();
	a && Lt(i, a), dt(i) !== dt(e) && (i.turnProgress = !0), i.winner === null && !i.pending && !i.queue.length && Y(i, [{
		t: "phase",
		side: i.turn,
		mode: "cache"
	}]);
	let o = i.fx;
	return i.fx = [], {
		state: i,
		fx: o
	};
}
function zt(e, t) {
	if (e.legacy) return rt.viewFor(e, t);
	let n = e.sides.indexOf(t), r = {
		phase: e.phase,
		turn: e.turn,
		round: e.round,
		sides: e.sides,
		protocols: e.protocols,
		field: e.field.map((t) => t.map((t) => t.map((n, r) => ({
			token: n.token,
			face: n.up ? n.id : null,
			up: n.up,
			value: J(e, W(e, n.token)),
			covered: r < t.length - 1
		})))),
		totals: ht(e),
		handCounts: e.hands.map((e) => e.length),
		deckCounts: e.decks.map((e) => e.length),
		trash: e.trash,
		control: e.control,
		useControl: e.config.control,
		solo: e.solo,
		scenario: e.config.scenario,
		available: e.available,
		pending: e.pending ? {
			actor: e.pending.actor,
			kind: e.pending.kind,
			source: e.pending.source,
			count: e.pending.options.length
		} : null,
		revealed: e.revealed,
		last: e.last,
		winner: e.winner,
		log: e.log.slice(-100)
	};
	return n < 0 ? { public: r } : {
		public: r,
		private: {
			hand: e.hands[n],
			faces: Object.fromEntries(e.field[n].flat().map((e) => [e.token, e.id])),
			options: e.pending?.actor === t ? e.pending.options.map((t) => {
				let n = { ...t.view };
				return e.solo && n.kind === "play" && n.side === 1 && !n.up && !e.revealed.some((e) => e.cards.includes(n.card ?? "")) && delete n.card, n;
			}) : [],
			decision: e.decision
		}
	};
}
var Bt = {
	meta: ye,
	saveCompatibility: {
		version: "2",
		migrate({ version: e, log: t }) {
			if (e !== "1" && e !== void 0 || !t.length || typeof t[0] != "object" || t[0] === null) return null;
			let n = t[0];
			return n.type === "$setup" ? [{
				...n,
				saveVersion: "2",
				config: {
					...n.config,
					boxes: [3],
					legacy3: !0
				}
			}, ...t.slice(1)] : null;
		}
	},
	schemas: {
		action: at,
		publicView: st,
		privateView: ct,
		config: it
	},
	setup: Pt,
	reduce: Rt,
	viewFor: zt,
	status(e) {
		if (e.legacy) return rt.status(e);
		let t = e.sides.filter((t, n) => !e.solo || n === 0), n = Object.fromEntries(t.map((t, n) => [t, e.protocols[n].filter((e) => e.compiled).length]));
		return e.winner === null ? { phase: e.phase } : {
			phase: "done",
			winner: e.winner === -1 ? [] : e.solo ? e.winner === 0 ? [e.sides[0]] : [] : [e.sides[e.winner]],
			ranking: e.solo ? t : e.winner === -1 ? e.sides : [e.sides[e.winner], e.sides[lt(e.winner)]],
			scores: n
		};
	},
	nextTickIn: (e, t) => e.legacy ? rt.nextTickIn?.(e, t) ?? null : e.phase !== "done" && !e.pending && e.queue.length ? e.beat : null
}, Vt = {
	name: "译世界",
	desc: "组合三个协议，在暗牌、连锁指令与控制权的争夺中率先完成编译。支持基础盒 1／2／3 与扩展 1／2／3 自由混用，包含官方单人情境。",
	invalid: "当前不能执行这项操作，请重新选择。",
	rules: "目标：\n你将扮演一个人工智能，使用三个协议的指令牌与对手争夺三列区域。率先将自己的三个协议全部编译的一方获胜。\n\n准备：\n开局可选择启用 基础盒 1、基础盒 2、基础盒 3 中的一个或多个基础盒，并分别选择是否加入 扩展 1、扩展 2、扩展 3。三个基础盒各含 12 个协议，每个扩展含 3 个协议；每个协议均有 6 张指令牌。所有已启用的协议组成同一选取池，可以自由混用。默认仅启用 基础盒 1，首次游玩建议从此开始。\n· 双人对局依次选取协议：先手选 1 个，后手选 2 个，先手再选 2 个，后手最后选 1 个。协议按照各自选取顺序，从自己的左侧排向右侧。选择随机组合时，从已启用的协议池随机分配双方的协议，并跳过选取步骤。\n· 每方将自己三个协议的 18 张指令牌洗成牌库，抽取 5 张手牌。双方各有三列牌堆，两侧同位置的协议和牌堆共同构成一列。\n· 控制权组件起初保持中立。开局可关闭控制权；关闭后，所有获得、失去或检查控制权的效果均不能生效。\n\n卡牌与牌堆：\n新牌通常盖在牌堆末端。最外侧的一张牌称为未被覆盖的牌，其余牌均为被覆盖的牌。正面牌的顶部指令在被覆盖后仍生效；中部和底部指令只有未被覆盖时才生效。暗置牌没有协议及指令，数值视为 2。你可以查看自己一侧的暗置牌，对手不能查看。\n· 正面打牌时，牌的协议必须匹配该列中任意一方的协议。牌始终打入自己一侧；牌上指令另有规定时，遵从指令。\n· 暗置打牌时，可以选择自己一侧的任意一列。\n· 正面牌进入场中、由暗置翻为正面，或成为未被覆盖的牌时，执行其中部指令。只将一张未被覆盖的正面牌移动到另一列，不会重复执行其中部指令。\n\n回合流程：\n· 开始时，记录自己一侧当前生效的所有“开始时”指令，再按自己选择的顺序逐一执行。此阶段中新出现的开始指令不在本回合追加执行。\n· 检查控制权：如果你在至少两列中的总值均高于对手，获得控制权；否则，控制权保持原状。\n· 检查编译：如果你在某列的总值至少为 10，且高于对手在同一列的总值，必须选择一个符合条件的列编译。本次检查只编译一列，并跳过本回合的行动步骤。\n· 行动时，选择打出 1 张手牌，或将手牌补充至 5 张。手牌已满 5 张，或已经没有可抽的牌时，不能选择补充。没有手牌时必须补充；如果既不能出牌，也不能抽牌，则跳过行动。\n· 检查缓存：如果手牌超过 5 张，必须自行选择并弃置多余的牌，直至剩下 5 张。这次处理称为清理缓存；完成后才触发相应指令。\n· 结束时，记录自己一侧当前生效的所有“结束时”指令，再按自己选择的顺序逐一执行，随后轮到对手。\n\n编译与控制权：\n编译时，删除该列双方的所有牌，将它们分别放入当前所有者的弃牌堆，再将自己的该列协议翻至已编译一面。协议移动时，已编译状态跟随协议移动，场上的牌堆不随协议移动。\n· 如果该协议已经编译，仍然删除该列所有牌，然后抽取对手牌库顶的 1 张牌加入自己的手牌，并取得该牌的所有权。\n· 如果持有控制权时要编译或补充手牌，先将控制权交回中立。你可以重排任意一方的三个协议，再执行原定的编译或补充。重排后的顺序必须与原来不同，协议不能交换到另一方。\n· 某些指令允许在检查步骤之外编译或补充手牌。仍须遵守该指令的条件及控制权规则。\n\n指令与连锁：\n所有能够执行的效果都必须执行，只有写明“可以”的效果允许跳过。一个指令中的各句依次处理；新触发的效果先完整结算，再继续原指令。多个效果同时触发时，由当前回合的一方选择结算顺序。\n写明“所有”的操作同时影响符合条件的全部牌，包括被覆盖牌；写明“每个”或“每张”的操作先记录符合条件的对象，再由来源牌的所有者选择顺序逐个处理，并完整结算每个对象的后果。\n· 通常只能选择未被覆盖的牌作为翻转、删除、返回或移动的目标。写明“被覆盖”“所有”“此牌”或“该牌”时，按照相应范围处理。\n· 移动表示将牌移至同一方的另一列，不改变所有权。返回表示加入当前所有者的手牌；删除表示进入当前所有者的弃牌堆；弃置表示将手牌移入弃牌堆。\n· 翻转会改变正面与暗置状态。如果来源牌翻面、离场，或者正在执行的指令被覆盖，尚未执行的部分就不再生效。\n· 牌将要被覆盖时的指令，必须先于新牌落下执行。已经承诺打出或移动的牌在此期间不能被其他效果选作目标。\n· 抽牌时若牌库为空，将弃牌堆洗成新的牌库，再继续抽取。其他涉及牌库的效果不会因牌库为空而自动洗牌。弃牌堆全部公开，双方手牌和牌库只有数量公开。\n· 极少数情况下，双方均无法作出任何选择，且连续两个完整回合没有任何牌、协议或控制权变化时，本实现将对局判为平局。这是对官方未说明的强制停滞局面的补充处理；存在任何可选行动时，不会按此结束。\n\n官方单人模式：\n单人对局在开局设置中选择普通或进阶模式的一个情境。自动机按情境使用三个固定协议，你从剩余协议中自由选择三个协议，并始终先手。自动机抽取的 5 张起始牌组成一个暗置队列。\n·自动机只能打出队首牌，抽牌和返回的牌加入队尾。除补充队列以外，同时加入队列的多张牌须先洗混，再依次加入队尾；补充队列时，按抽取顺序加入。每回合按情境顺序打出 1 至 3 张牌，每张牌完整结算后再打下一张。队列不足时，打完剩余牌；行动开始时队列为空，才补充至 5 张。\n· 情境要求明置时，自动机打入匹配协议的一列；要求暗置时，打入自动机当前总值最高或最低的一列。平局由你决定。自动机需要作出的所有其他决定也由你选择，官方允许选择对你最有利的结果。自动机被迫弃牌时，从队首依次弃置。\n· 普通模式中，自动机所有牌都视为没有指令。进阶模式中，自动机的指令正常生效。自动机若不能按要求明置，则暗置到你选择的一列。\n·自动机持有控制权且要编译或补充时，先交回控制权，再执行情境规定的抽牌、窃取或重排参数，随后执行原定动作。它不会自动使用双人模式的重排规则。\n· 你先完成三个协议即获胜。自动机完成三个协议，或者再次编译任意一个已经编译的协议，都会立即使你失败。\n本实现包含官方普通 6 个与进阶 6 个情境。单人自动机使用第三部情境规定的固定协议，玩家从所启用的牌池中选择协议。情境名、协议名及卡牌指令均已中文化；点开牌面可查看完整指令。",
	ui: {
		results: "对局结果",
		hintCount: "本局求助 {n} 次",
		mainBox: "基础盒",
		auxBox: "扩展",
		searchDeck: "选择要抽取的牌",
		discardOrSelf: "弃置 1 张手牌，或处理此牌",
		cardPreview: "卡牌查看",
		recent: "最近行动",
		choices: "查看可选项",
		hideChoices: "收起可选项",
		emptyHand: "暂时没有手牌",
		waitingDraft: "等待选择协议",
		selectTarget: "选择此牌后，在操作带确认动作。",
		selectedCard: "已选择",
		selectedTarget: "已选择目标",
		inspectSelected: "查看选中牌",
		lineLeft: "左列",
		lineMiddle: "中列",
		lineRight: "右列",
		field: "场中",
		downCard: "1 张暗置牌",
		aCard: "1 张牌",
		cardsUnit: "张",
		log_play: "{player}在{line}打出了{card}。",
		log_shift: "{player}将{card}移至{line}。",
		log_flip: "{player}翻转了{card}。",
		log_draw: "{player}抽取了 {n} 张牌。",
		log_discard: "{player}弃置了 {n} 张手牌。",
		log_discardDeck: "{player}从牌库弃置了 {n} 张牌。",
		log_compile: "{player}编译了{line}的协议。",
		log_control: "{player}触发了控制权变更。",
		log_shuffle: "{player}洗混了牌库。",
		log_return: "{player}将{card}返回手牌。",
		log_delete: "{player}删除了{card}。",
		log_take: "{player}抽取了{card}。",
		log_top: "{player}将{card}放回牌库顶。",
		log_give: "{player}将 1 张手牌交给了对手。",
		log_rearrange: "{player}重排了协议。",
		log_swapStacks: "{player}交换了两个牌堆。",
		log_refresh: "{player}补充了手牌。",
		log_cache: "{player}清理了缓存。",
		log_resolve: "{player}执行了指令。",
		choice_protocol: "声明此协议",
		choice_novaUnder: "在此牌下打入暗牌",
		choice_queuePlay: "打出队首牌",
		continue: "继续",
		choice_number: "声明数值",
		choice_count: "弃置张数",
		choice_take: "抽取此牌",
		choice_give: "交给对手",
		choice_reveal: "展示此牌",
		declareNumber: "声明一个数值",
		declareProtocol: "声明一个协议",
		discardCount: "选择要弃置的张数",
		searchChoice: "选择要抽取的牌",
		luckDrawn: "选择要展示的牌",
		give: "选择要交给对手的手牌",
		revealOne: "选择要展示的手牌",
		reveal: "查看展示的牌后继续",
		copyMid: "选择要复制的中部指令，或跳过",
		flipOrDraw: "翻转一张牌，或抽取一张牌",
		stalemate: "对局平局",
		each: "选择下一个要处理的目标",
		queuePlay: "打出自动机队首牌",
		choice_play: "打出",
		choice_compile: "编译",
		choice_shift: "移动",
		choice_flip: "翻转",
		choice_return: "返回手牌",
		choice_delete: "删除",
		choice_discard: "弃牌",
		choice_bottomHand: "放至牌库底",
		choice_order: "执行指令",
		choice_deckLine: "打入暗牌",
		choice_soloLine: "自动机落点",
		choice_line: "选择此列",
		choice_rearrange: "重排协议",
		draft: "选择一个协议",
		action: "选择手牌与落点，或补充手牌",
		order: "选择先执行的指令",
		compile: "选择要编译的列",
		discard: "选择要弃置的手牌",
		flip: "选择要翻转的牌",
		shift: "选择要移动的牌及目标列",
		return: "选择要返回手牌的牌",
		delete: "选择要删除的牌",
		"shift|flip": "选择要移动或翻转的牌",
		"return|shift": "选择要返回或移动的牌",
		"flip|shift": "选择你要翻转或移动的牌",
		shiftOrSwap: "移动对手的牌，或交换自己的协议",
		rearrange: "选择新的协议顺序",
		play: "选择要打出的手牌及落点",
		optional: "选择是否执行此效果",
		bottomHand: "选择要放到牌库底的手牌",
		soloLine: "选择自动机的落点",
		deckLine: "选择牌库顶牌的落点",
		line: "选择一列",
		novaUnder: "选择要在下方打入暗牌的新星牌",
		drawOrPlay: "抽取 1 张牌，或打出 1 张手牌",
		accept: "执行",
		skip: "跳过",
		refresh: "补充手牌",
		draw: "抽牌",
		faceUp: "正面",
		faceDown: "暗置",
		loading: "待编译",
		compiled: "已编译",
		hand: "手牌",
		deck: "牌库",
		trash: "弃牌",
		control: "控制权",
		neutral: "中立",
		bot: "自动机",
		wait: "等待对方选择",
		resolving: "正在结算",
		details: "牌面详情",
		close: "关闭",
		cancel: "取消选择",
		back: "返回",
		log: "记录",
		win: "编译完成",
		lose: "自动机已完成编译",
		turn: "回合",
		review: "查看最终牌阵",
		startAgain: "再来一局",
		lobby: "返回大堂",
		waitHost: "等待房主继续",
		top: "顶部",
		mid: "中部",
		bottom: "底部",
		boxes: "启用的基础盒（至少一个）",
		aux: "加入扩展协议",
		controlOption: "使用控制权",
		draftOption: "选择协议方式",
		draftOn: "轮流选取",
		draftOff: "随机组合",
		solo: "官方单人情境",
		regular: "普通",
		advanced: "进阶",
		yes: "启用",
		no: "关闭",
		own: "自己",
		opponent: "对手",
		chosen: "已选中",
		noCommand: "没有指令",
		next: "落在此列",
		revealHand: "公开的手牌",
		swapStacks: "交换两端牌堆",
		discardDeck: "弃置牌库",
		playLog: "打出牌",
		score: "已编译协议"
	}
}, Ht = {
	name: "Compile",
	desc: "Combine three protocols and race to compile them through hidden cards, cascading commands and Control. Mix Main 1–3 and Aux 1–3, with official solo scenarios.",
	invalid: "That action is unavailable. Please choose again.",
	rules: "Objective:\nYou are an artificial intelligence competing across three lines. Be the first to compile all three of your protocols.\n\nSetup:\nEnable one or more of Main 1, Main 2 and Main 3, and optionally add Aux 1, Aux 2 and Aux 3. Each Main includes 12 protocols and each Aux includes 3; each protocol has 6 command cards. All enabled protocols share one draft pool and may be mixed freely. Only Main 1 is enabled by default and is recommended for a first game.\n· In a two-player draft, the first player takes 1 protocol, the second takes 2, the first takes 2 more, and the second takes 1. Place protocols from your own left to right in draft order. The random setup assigns protocols from the enabled pool and skips the draft.\n· Shuffle your protocols’ 18 command cards into a deck and draw 5. Each player has three stacks; the opposing stacks and protocols at the same position form a line.\n· Control starts neutral. You may disable Control in setup. When disabled, effects that gain, lose or check Control cannot apply.\n\nCards and stacks:\nA new card normally covers the outermost card of its stack. The outermost card is uncovered; all other cards are covered. A face-up card’s top command remains active when covered. Middle and bottom commands are active only while uncovered. A face-down card has no protocol or commands and has a value of 2. You may inspect face-down cards on your side, but not your opponent’s.\n· To play face up, the card must match either player’s protocol in the chosen line. It is still played on your side unless a command says otherwise.\n· You may play a card face down into any line on your side.\n· Resolve a middle command when its face-up card enters play, flips face up, or becomes uncovered. Shifting an already uncovered face-up card does not repeat its middle command.\n\nTurn sequence:\n· At Start, note all active Start commands on your side. Resolve them in your chosen order. New Start commands appearing during this phase do not join this set.\n· Check Control: gain Control if you have a higher total than your opponent in at least two lines. Otherwise, Control stays where it is.\n· Check Compile: if your total in a line is at least 10 and strictly greater than your opponent’s, you must choose one eligible line to compile. Compile only one line in this check, and skip your Action phase.\n· During Action, either play 1 card or refresh your hand to 5 cards. You cannot refresh with at least 5 cards or when no cards can be drawn. With no cards in hand, you must refresh; if you cannot play or draw, skip Action.\n· Check Cache: if you have more than 5 cards, choose and discard down to 5. This is clearing cache. Trigger the relevant commands only after the discard is complete.\n· At End, note and resolve your active End commands in your chosen order. Then your opponent takes a turn.\n\nCompiling and Control:\nTo compile, delete all cards on both sides of the chosen line into their current owners’ trash, then turn your protocol to its compiled side. Compiled status moves with a protocol when it is rearranged; the stacks stay in place.\n· If the protocol is already compiled, still delete the line, then draw the top card of your opponent’s deck into your hand. You become that card’s owner.\n· If you have Control when compiling or refreshing, first return Control to neutral. You may rearrange either player’s three protocols, then perform the compile or refresh. A rearrangement must change the order, and protocols never change sides.\n· Commands may compile or refresh outside the normal check. Their conditions and the Control rules still apply.\n\nCommands and chains:\nResolve every effect that can change the game state; only effects saying “may” are optional. Resolve sentences in order. Newly triggered effects resolve completely before the original command continues. The current player orders simultaneous triggers.\n“All” acts simultaneously on all matching cards, including covered cards. “Each” first notes the matching objects, then the source card’s owner chooses their order and resolves each object and its consequences completely before the next.\n· Normally only uncovered cards can be selected to flip, delete, return or shift. Text specifying covered cards, all cards, this card or that card changes this restriction.\n· Shift moves a card to another line on the same side without changing ownership. Return puts it in its owner’s hand. Delete sends a field card to its owner’s trash. Discard sends a hand card to trash.\n· Flip changes facing. If a source card flips, leaves play, or its executing command becomes covered, the remaining effects of that command cease to apply.\n· “When this card would be covered” effects resolve before the incoming card lands. A committed card cannot be selected by other effects while waiting to land.\n· When drawing from an empty deck, shuffle your trash into a new deck and continue. Other deck effects do not automatically reshuffle. Trash contents and hand/deck counts are public; hands and deck order are private.\n· In the rare case that neither player has any choice and two complete consecutive turns cause no card, protocol or Control change, this implementation ends the game as a draw. This supplements a forced stalemate that the official rules do not resolve. It never applies when a choice is available.\n\nOfficial solo mode:\nChoose one Regular or Advanced scenario in setup. The BOT has the three listed protocols; choose any three remaining protocols for yourself and always go first. The BOT’s 5 starting cards form a face-down FIFO queue.\n· The BOT always plays the front card. Drawn and returned cards join the back. Outside a refresh, shuffle cards added simultaneously before adding them one by one. A refresh keeps their draw order. It plays 1–3 cards in the scenario’s order, fully resolving each before the next. If it runs out, it plays only the remaining cards. It refreshes to 5 only when its queue is empty at the start of Action.\n· A face-up play matches a protocol. A face-down play goes in the BOT’s current highest or lowest total line as specified. You break ties and make every other BOT decision; the official rules encourage choosing what benefits you. BOT discards always come from the front of its queue.\n· In Regular mode, all BOT cards have no commands. In Advanced mode, their commands work normally. If a required face-up play is prohibited, play it face down in a line you choose.\n· When the BOT has Control and must compile or refresh, it first returns Control to neutral, applies the scenario’s draw, steal or rearrange parameter, and then performs the original action. It does not use the standard two-player rearrangement automatically.\n· Win by compiling all three protocols first. Lose if the BOT compiles all three or recompiles any already compiled protocol.\nAll 6 Regular and 6 Advanced official scenarios are included. The BOT uses the fixed Main 3 protocols listed by its scenario; choose your protocols from the enabled pool. Select a card to inspect its complete commands.",
	ui: {
		results: "Match results",
		hintCount: "Hints used: {n}",
		mainBox: "Main",
		auxBox: "Aux",
		searchDeck: "Choose a card to draw",
		discardOrSelf: "Discard a hand card, or resolve this card",
		cardPreview: "Card preview",
		recent: "Recent actions",
		choices: "Show choices",
		hideChoices: "Hide choices",
		emptyHand: "No cards in hand",
		waitingDraft: "Waiting for the draft",
		selectTarget: "Select this card, then confirm in the action bar.",
		selectedCard: "Selected",
		selectedTarget: "Target selected",
		inspectSelected: "Inspect selected card",
		lineLeft: "the left line",
		lineMiddle: "the middle line",
		lineRight: "the right line",
		field: "the field",
		downCard: "a face-down card",
		aCard: "a card",
		cardsUnit: "cards",
		log_play: "{player} played {card} in {line}.",
		log_shift: "{player} shifted {card} to {line}.",
		log_flip: "{player} flipped {card}.",
		log_draw: "{player} drew {n} cards.",
		log_discard: "{player} discarded {n} hand cards.",
		log_discardDeck: "{player} discarded {n} cards from their deck.",
		log_compile: "{player} compiled the protocol in {line}.",
		log_control: "{player} triggered a Control change.",
		log_shuffle: "{player} shuffled their deck.",
		log_return: "{player} returned {card} to hand.",
		log_delete: "{player} deleted {card}.",
		log_take: "{player} drew {card}.",
		log_top: "{player} put {card} on top of their deck.",
		log_give: "{player} gave a hand card to their opponent.",
		log_rearrange: "{player} rearranged their protocols.",
		log_swapStacks: "{player} swapped two stacks.",
		log_refresh: "{player} refreshed their hand.",
		log_cache: "{player} cleared their cache.",
		log_resolve: "{player} resolved a command.",
		choice_protocol: "Declare this protocol",
		choice_novaUnder: "Play under this card",
		choice_queuePlay: "Play front card",
		continue: "Continue",
		choice_number: "Declare value",
		choice_count: "Cards to discard",
		choice_take: "Draw this card",
		choice_give: "Give to opponent",
		choice_reveal: "Reveal this card",
		declareNumber: "Declare a value",
		declareProtocol: "Declare a protocol",
		discardCount: "Choose how many cards to discard",
		searchChoice: "Choose a card to draw",
		luckDrawn: "Choose a card to reveal",
		give: "Choose a hand card to give",
		revealOne: "Choose a hand card to reveal",
		reveal: "Review the revealed cards, then continue",
		copyMid: "Choose a middle command to copy, or skip",
		flipOrDraw: "Flip a card or draw a card",
		stalemate: "Stalemate — draw",
		each: "Choose the next target to resolve",
		queuePlay: "Play the BOT’s front card",
		choice_play: "Play",
		choice_compile: "Compile",
		choice_shift: "Shift",
		choice_flip: "Flip",
		choice_return: "Return to hand",
		choice_delete: "Delete",
		choice_discard: "Discard",
		choice_bottomHand: "Put on deck bottom",
		choice_order: "Resolve command",
		choice_deckLine: "Play face down",
		choice_soloLine: "BOT destination",
		choice_line: "Choose this line",
		choice_rearrange: "Rearrange protocols",
		draft: "Choose a protocol",
		action: "Choose a hand card and a line, or refresh",
		order: "Choose the command to resolve first",
		compile: "Choose a line to compile",
		discard: "Choose a card to discard",
		flip: "Choose a card to flip",
		shift: "Choose a card and its destination",
		return: "Choose a card to return",
		delete: "Choose a card to delete",
		"shift|flip": "Choose a card to shift or flip",
		"return|shift": "Return or shift a card",
		"flip|shift": "Flip or shift one of your cards",
		shiftOrSwap: "Shift an opposing card or swap your protocols",
		rearrange: "Choose a new protocol order",
		play: "Choose a hand card and destination",
		optional: "Choose whether to resolve this effect",
		bottomHand: "Choose a card for the bottom of your deck",
		soloLine: "Choose the BOT’s destination",
		deckLine: "Choose a destination for the top deck card",
		line: "Choose a line",
		novaUnder: "Choose an uncovered Nova card",
		drawOrPlay: "Draw 1 card or play 1 card",
		accept: "Resolve",
		skip: "Skip",
		refresh: "Refresh",
		draw: "Draw",
		faceUp: "Face up",
		faceDown: "Face down",
		loading: "Loading",
		compiled: "Compiled",
		hand: "Hand",
		deck: "Deck",
		trash: "Trash",
		control: "Control",
		neutral: "Neutral",
		bot: "BOT",
		wait: "Waiting for a choice",
		resolving: "Resolving",
		details: "Card details",
		close: "Close",
		cancel: "Deselect",
		back: "Back",
		log: "History",
		win: "Compilation complete",
		lose: "BOT compilation complete",
		turn: "Turn",
		review: "Review final field",
		startAgain: "Play again",
		lobby: "Back to lobby",
		waitHost: "Waiting for the host",
		top: "Top",
		mid: "Middle",
		bottom: "Bottom",
		boxes: "Enabled Main sets (at least one)",
		aux: "Additional Aux protocols",
		controlOption: "Use Control",
		draftOption: "Protocol selection",
		draftOn: "Draft",
		draftOff: "Random sets",
		solo: "Official solo scenario",
		regular: "Regular",
		advanced: "Advanced",
		yes: "Enabled",
		no: "Disabled",
		own: "You",
		opponent: "Opponent",
		chosen: "Selected",
		noCommand: "No commands",
		next: "Play in this line",
		revealHand: "Revealed hand",
		swapStacks: "Swap outer stacks",
		discardDeck: "Discard deck",
		playLog: "Play card",
		score: "Compiled protocols"
	}
};
//#endregion
//#region src/games/compile3/card.tsx
function Ut({ protocol: e, size: t = 24 }) {
	return /* @__PURE__ */ v("img", {
		width: t,
		height: t,
		src: `games/compile3/icons/${e}.svg`,
		alt: "",
		"aria-hidden": "true",
		className: "c3-icon"
	});
}
function Wt() {
	return /* @__PURE__ */ v("svg", {
		className: "c3-target-outline",
		width: "100%",
		height: "100%",
		"aria-hidden": "true",
		children: /* @__PURE__ */ v("rect", {
			x: "2",
			y: "2",
			width: "calc(100% - 4px)",
			height: "calc(100% - 4px)",
			rx: "3",
			fill: "none",
			stroke: "#b8f4ed",
			strokeWidth: "2",
			strokeDasharray: "7 5",
			children: /* @__PURE__ */ v("animate", {
				attributeName: "stroke-dashoffset",
				from: "24",
				to: "0",
				dur: "1s",
				repeatCount: "indefinite"
			})
		})
	});
}
function Gt({ id: e, locale: t, covered: n = !1, down: r = !1, known: i = !1, selected: a = !1, value: o }) {
	let s = (t === "zh" ? Vt : Ht).ui, c = e ? j[e] : void 0;
	if (!c || r) return /* @__PURE__ */ y("div", {
		lang: t,
		className: `c3-card c3-card-back${n ? " is-covered" : ""}${a ? " is-selected" : ""}`,
		children: [/* @__PURE__ */ y("div", {
			className: "c3-card-head",
			children: [
				/* @__PURE__ */ v("span", { children: s.faceDown }),
				/* @__PURE__ */ v("strong", { children: o ?? 2 }),
				/* @__PURE__ */ v("span", {
					className: "c3-back-mark",
					children: "◇"
				})
			]
		}), !n && /* @__PURE__ */ y("div", {
			className: "c3-back-core",
			children: [/* @__PURE__ */ v("span", { children: "⬡" }), /* @__PURE__ */ v("small", { children: i && c ? `${A(c.protocol)} · ${c.value}` : t === "zh" ? Vt.name : "COMPILE" })]
		})]
	});
	let l = (e) => {
		let n = c[e][t], r = [...n].reduce((e, t) => e + (t.charCodeAt(0) > 255 ? 1 : /\s/.test(t) ? .32 : .56), 0), i = 9;
		for (; i > 3.8 && Math.ceil(r / Math.floor(82 / i)) * i * 1.3 > 27.5;) i -= .2;
		return /* @__PURE__ */ v("div", {
			className: `c3-command c3-command-${e}${n ? "" : " is-empty"}`,
			style: { "--command-size": `${i}cqw` },
			children: n || /* @__PURE__ */ v("span", { "aria-hidden": "true" })
		});
	};
	return /* @__PURE__ */ y("div", {
		lang: t,
		className: `c3-card${n ? " is-covered" : ""}${a ? " is-selected" : ""}`,
		style: {
			"--protocol": he[c.protocol],
			"--card-art": `url('games/compile3/${c.protocol}.webp')`
		},
		children: [/* @__PURE__ */ y("div", {
			className: "c3-card-head",
			children: [
				/* @__PURE__ */ v("span", { children: A(c.protocol) }),
				/* @__PURE__ */ v("strong", { children: c.value }),
				/* @__PURE__ */ v(Ut, {
					protocol: c.protocol,
					size: 34
				})
			]
		}), n ? /* @__PURE__ */ v("div", {
			className: "c3-covered-command",
			children: c.top[t]
		}) : /* @__PURE__ */ y("div", {
			className: "c3-command-slots",
			children: [
				l("top"),
				l("mid"),
				l("bottom")
			]
		})]
	});
}
function Kt({ token: e, children: t, style: n, ...r }) {
	let a = `card:${e}`, { ref: s, hidden: c } = l(a), d = u(), f = o(null), p = i((t) => {
		if (!t && f.current) {
			let t = f.current.getBoundingClientRect();
			d?.registerProbe(`depart:${e}`, () => ({
				x: t.x,
				y: t.y,
				w: t.width,
				h: t.height
			}));
		}
		f.current = t, s(t);
	}, [
		d,
		e,
		s
	]);
	return /* @__PURE__ */ v("div", {
		ref: p,
		...r,
		style: {
			...n,
			...c ? { visibility: "hidden" } : {}
		},
		children: t
	});
}
//#endregion
//#region src/games/compile3/view-player.tsx
function qt({ name: e, className: t, children: n }) {
	let { ref: r, hidden: i } = l(e);
	return /* @__PURE__ */ v("div", {
		ref: r,
		className: t,
		style: i ? { visibility: "hidden" } : void 0,
		children: n
	});
}
function Jt({ signature: e, children: t }) {
	let n = o(null), r = o(!0);
	return a(() => {
		r.current && n.current && (n.current.scrollTop = n.current.scrollHeight);
	}, [e]), /* @__PURE__ */ v("div", {
		className: "c3-stack-scroll",
		ref: n,
		onScroll: (e) => {
			let t = e.currentTarget;
			r.current = t.scrollHeight - t.clientHeight - t.scrollTop < 12;
		},
		children: t
	});
}
function Yt(e) {
	return c(), /* @__PURE__ */ v(Xt, { ...e });
}
function Xt({ public: e, private: r, members: i, myRid: a, send: o, onShowResults: c }) {
	let l = e, u = r, te = t((e) => e.locale), b = te === "zh" ? "zh" : "en", x = (b === "zh" ? Vt : Ht).ui, ne = n(), S = Math.max(0, l.sides.indexOf(a)), re = 1 - S, C = l.phase === "done" ? [] : u?.options ?? [], ie = l.phase !== "done" && l.pending?.actor === a;
	f(ie, d);
	let [w, T] = s({
		rid: a,
		decision: -1,
		up: !0
	}), E = w.rid === a && w.decision === u?.decision && C.length > 0, D = E ? w.card : void 0, O = E ? w.token : void 0, ae = !E || w.up, [oe, se] = s(null), [ce, le] = s(!1), k = (e) => se({
		rid: a,
		id: e
	}), ue = (e) => {
		k(e), le(!0);
	}, [de, fe] = s(!1), [pe, me] = s(null), [ge, _e] = s({
		decision: -1,
		open: !0
	}), ve = oe?.rid === a ? oe.id : u?.hand[0] ?? l.field.flat(2).find((e) => e.face)?.face ?? null, M = (e) => o({
		type: "choose",
		id: e.id
	}), ye = (e) => `${x[`choice_${e.kind}`] ?? x[e.kind] ?? x.next}${e.n === void 0 ? "" : ` ${e.n}`}`, be = (e, t, n) => T({
		rid: a,
		card: e,
		token: t,
		decision: u?.decision ?? -1,
		up: n ?? (e ? C.some((t) => t.card === e && t.up) : ae)
	}), N = (e) => {
		let t = i.find((t) => t.rid === l.sides[e]);
		return t ? g(t, te) : l.solo && e === 1 ? x.bot : e === S ? x.own : x.opponent;
	}, xe = S === 0 || l.solo ? [
		0,
		1,
		2
	] : [
		2,
		1,
		0
	], Se = (e) => C.filter((t) => t.kind !== "swapStacks" && t.kind !== "order" && t.line === e && (D ? t.card === D && t.up === ae : O === void 0 ? !t.card && t.token === void 0 : t.token === O && t.kind === "shift")), P = (e) => e && j[e] ? `${A(j[e].protocol)} ${j[e].value}` : x.aCard, Ce = (e) => e === void 0 ? x.field : [
		x.lineLeft,
		x.lineMiddle,
		x.lineRight
	][xe.indexOf(e)], we = (e) => (x[`log_${e.kind}`] ?? x.log_resolve).replaceAll("{player}", N(e.side)).replaceAll("{line}", Ce(e.line)).replaceAll("{card}", e.card ? P(e.card) : e.kind === "play" ? x.downCard : x.aCard).replaceAll("{n}", String(e.n ?? 1)), Te = (e) => {
		let t = i.find((t) => t.rid === l.sides[e]);
		return /* @__PURE__ */ y("div", {
			className: "c3-player",
			"data-active": l.turn === e,
			children: [
				/* @__PURE__ */ v("span", {
					className: "c3-avatar",
					style: { background: t ? h[t.colorIndex % h.length].hex : "#465f78" },
					children: /* @__PURE__ */ v("img", {
						src: m[(t?.avatar ?? 0) % m.length],
						alt: ""
					})
				}),
				/* @__PURE__ */ y("div", {
					className: "c3-player-identity",
					children: [/* @__PURE__ */ v("strong", {
						title: N(e),
						children: N(e)
					}), /* @__PURE__ */ y("span", {
						className: "c3-player-stock",
						children: [
							/* @__PURE__ */ y(qt, {
								name: `hand:${e}`,
								children: [
									x.hand,
									" ",
									l.handCounts[e]
								]
							}),
							/* @__PURE__ */ y(qt, {
								name: `deck:${e}`,
								children: [
									x.deck,
									" ",
									l.deckCounts[e]
								]
							}),
							/* @__PURE__ */ v(qt, {
								name: `trash:${e}`,
								children: /* @__PURE__ */ y("button", {
									className: "c3-tool",
									onClick: () => me(e),
									children: [
										x.trash,
										" ",
										l.trash[e].length
									]
								})
							})
						]
					})]
				}),
				/* @__PURE__ */ y("span", {
					className: "c3-pips",
					"aria-label": `${x.score} ${l.protocols[e].filter((e) => e.compiled).length} / 3`,
					children: [l.protocols[e].filter((e) => e.compiled).length, /* @__PURE__ */ v("small", { children: "/3" })]
				})
			]
		});
	}, Ee = O === void 0 ? [] : C.filter((e) => e.token === O && e.kind !== "shift" && e.kind !== "order"), De = D ?? l.field.flat(2).find((e) => e.token === O)?.face ?? (O === void 0 ? void 0 : u?.faces[String(O)]), F = (e, t) => /* @__PURE__ */ y(qt, {
		name: `stack:${e}:${t}`,
		className: `c3-stack${e === re ? " c3-stack-opponent" : ""}`,
		children: [l.field[e][t].length === 0 && /* @__PURE__ */ v("div", {
			className: "c3-empty",
			"aria-hidden": !0,
			children: "◇"
		}), l.field[e][t].map((t) => {
			let n = C.filter((e) => e.token === t.token && e.kind !== "order"), r = e === S ? u?.faces[String(t.token)] : void 0, i = t.face ?? r;
			return /* @__PURE__ */ y(Kt, {
				token: t.token,
				className: `c3-field-card${n.length ? " is-target" : ""}`,
				children: [n.length > 0 && /* @__PURE__ */ v(Wt, {}), /* @__PURE__ */ v("button", {
					type: "button",
					className: "c3-card-button",
					"aria-label": `${i ? P(i) : x.faceDown} · ${N(e)}`,
					onMouseEnter: () => i && k(i),
					onFocus: () => i && k(i),
					onClick: () => {
						n.length ? (be(void 0, t.token), i && k(i)) : i && ue(i);
					},
					children: /* @__PURE__ */ v(Gt, {
						id: i,
						locale: b,
						covered: t.covered,
						down: !t.up,
						known: !!r,
						selected: O === t.token,
						value: t.value
					})
				})]
			}, t.token);
		})]
	}), I = (e) => /* @__PURE__ */ v("div", {
		className: "c3-protocol-pair",
		children: [re, S].map((t) => {
			let n = Se(e).filter((e) => e.side === void 0 || e.side === t), r = l.protocols[t][e];
			return /* @__PURE__ */ v(qt, {
				name: `protocol:${t}:${e}`,
				children: /* @__PURE__ */ y("button", {
					type: "button",
					className: `c3-protocol${n.length ? " is-target" : ""}`,
					style: { "--protocol": he[r?.name] ?? "#85b5ca" },
					onClick: () => n[0] && M(n[0]),
					disabled: !n.length,
					"aria-label": `${N(t)} · ${Ce(e)} · ${r ? A(r.name) : x.loading} · ${l.totals[t][e]}${n[0] ? ` · ${ye(n[0])}` : ""}`,
					children: [
						n.length > 0 && /* @__PURE__ */ v(Wt, {}),
						r && /* @__PURE__ */ y(ee, { children: [/* @__PURE__ */ v(Ut, {
							protocol: r.name,
							size: 27
						}), /* @__PURE__ */ y("span", { children: [/* @__PURE__ */ v("b", { children: A(r.name) }), /* @__PURE__ */ v("small", { children: n[0] ? ye(n[0]) : r.compiled ? `◆ ${x.compiled}` : x.loading })] })] }),
						/* @__PURE__ */ v("strong", {
							className: "c3-total",
							children: l.totals[t][e]
						})
					]
				})
			}, t);
		})
	}, `protocol:${e}`), Oe = C.filter((e) => !e.card && e.token === void 0 && e.line === void 0 && !e.order && e.kind !== "order"), L = C.filter((e) => e.order || e.kind === "order"), ke = [...new Set(C.filter((e) => e.card && j[e.card] && !u?.hand.includes(e.card)).map((e) => e.card))], R = C.filter((e) => e.kind === "protocol"), Ae = C.filter((e) => e.kind === "swapStacks"), je = L.length + ke.length + R.length + Ae.length + l.revealed.length > 0, Me = ge.decision !== u?.decision || ge.open, Ne = (e, t) => A(l.protocols[e][t]?.name ?? ""), Pe = l.phase === "done" ? l.winner === -1 ? x.stalemate : x.win : ie ? x[l.pending?.kind ?? ""] ?? x.action : l.pending ? `${N(l.sides.indexOf(l.pending.actor))} · ${x.wait}` : x.resolving;
	return /* @__PURE__ */ y("div", {
		className: "c3-root",
		children: [
			/* @__PURE__ */ v(_, {
				adaptive: !0,
				scroll: !1,
				className: "c3-screen",
				banner: /* @__PURE__ */ y("header", {
					className: "c3-header",
					children: [
						/* @__PURE__ */ y("div", {
							className: "c3-brand",
							children: [/* @__PURE__ */ v("span", { children: b === "zh" ? Vt.name : "COMPILE" }), /* @__PURE__ */ v("small", { children: b === "zh" ? "COMPILE" : Ht.name })]
						}),
						/* @__PURE__ */ y("div", {
							className: "c3-players",
							children: [Te(re), Te(S)]
						}),
						/* @__PURE__ */ y(qt, {
							name: "protocols:0",
							className: "c3-control",
							children: [/* @__PURE__ */ y("span", { children: [
								x.turn,
								" ",
								l.round
							] }), l.useControl && /* @__PURE__ */ y("small", { children: [
								x.control,
								" · ",
								l.control === null ? x.neutral : N(l.control)
							] })]
						}),
						/* @__PURE__ */ v("button", {
							className: "c3-tool c3-history",
							"aria-label": x.log,
							onClick: () => fe(!0),
							children: x.log
						})
					]
				}),
				actionsHeight: "c3-hand-height",
				actions: /* @__PURE__ */ y("div", {
					className: "c3-hand-area",
					children: [
						/* @__PURE__ */ v(qt, {
							name: "card-size",
							className: "c3-card-measure",
							children: /* @__PURE__ */ v("span", {})
						}),
						/* @__PURE__ */ y("div", {
							className: "c3-decision",
							children: [/* @__PURE__ */ y("div", {
								className: "c3-status",
								role: "status",
								children: [/* @__PURE__ */ v("strong", { children: Pe }), /* @__PURE__ */ v("small", { children: D ? `${x.selectedCard} · ${P(D)}` : O === void 0 ? l.pending?.source ? P(l.pending.source) : "\xA0" : `${x.selectedTarget} · ${P(De ?? void 0)}` })]
							}), /* @__PURE__ */ y("div", {
								className: "c3-decision-actions",
								children: [
									l.phase === "done" && c && /* @__PURE__ */ v("button", {
										className: "c3-action",
										onClick: c,
										children: x.results
									}),
									D && C.some((e) => e.card === D && e.kind === "play") && /* @__PURE__ */ v("span", {
										className: "c3-facing",
										children: [!0, !1].filter((e) => C.some((t) => t.card === D && t.up === e)).map((e) => /* @__PURE__ */ v("button", {
											"aria-pressed": ae === e,
											onClick: () => be(D, void 0, e),
											children: e ? x.faceUp : x.faceDown
										}, String(e)))
									}),
									Ee.map((e) => /* @__PURE__ */ v("button", {
										className: "c3-action",
										onClick: () => M(e),
										children: ye(e)
									}, e.id)),
									Oe.map((e) => /* @__PURE__ */ v("button", {
										className: "c3-action",
										onClick: () => M(e),
										children: ye(e)
									}, e.id)),
									je && /* @__PURE__ */ v("button", {
										className: "c3-tool",
										onClick: () => _e({
											decision: u?.decision ?? -1,
											open: !Me
										}),
										children: Me ? x.hideChoices : x.choices
									}),
									De && /* @__PURE__ */ v("button", {
										className: "c3-tool",
										onClick: () => ue(De),
										children: x.details
									}),
									(D || O !== void 0) && /* @__PURE__ */ v("button", {
										className: "c3-tool",
										onClick: () => be(),
										children: x.cancel
									})
								]
							})]
						}),
						/* @__PURE__ */ y("div", {
							className: "c3-hand-label",
							children: [/* @__PURE__ */ y("strong", { children: [
								x.hand,
								" · ",
								u?.hand.length ?? 0
							] }), /* @__PURE__ */ y("small", { children: [
								x.deck,
								" ",
								l.deckCounts[S],
								" · ",
								x.trash,
								" ",
								l.trash[S].length
							] })]
						}),
						/* @__PURE__ */ y("div", {
							className: "c3-hand-scroll",
							children: [u?.hand.map((e) => {
								let t = C.filter((t) => t.card === e && t.kind !== "draft");
								return /* @__PURE__ */ y(Kt, {
									token: `hand:${S}:${e}`,
									className: `c3-hand-card${t.length ? " is-target" : ""}`,
									children: [/* @__PURE__ */ v("button", {
										className: "c3-card-button",
										onMouseEnter: () => k(e),
										onFocus: () => k(e),
										onClick: () => {
											t.length === 1 && t[0].kind !== "play" ? M(t[0]) : t.length ? (be(e), k(e)) : ue(e);
										},
										"aria-label": P(e),
										children: /* @__PURE__ */ v(Gt, {
											id: e,
											locale: b,
											selected: D === e
										})
									}), t.length > 0 && /* @__PURE__ */ v(Wt, {})]
								}, e);
							}), !u?.hand.length && /* @__PURE__ */ v("span", {
								className: "c3-hand-empty",
								children: l.phase === "draft" ? x.waitingDraft : x.emptyHand
							})]
						})
					]
				}),
				children: /* @__PURE__ */ y("main", {
					className: "c3-arena",
					children: [/* @__PURE__ */ y("div", {
						className: "c3-main",
						children: [
							/* @__PURE__ */ y("div", {
								className: "c3-board",
								children: [
									xe.map((e) => /* @__PURE__ */ v("div", {
										className: "c3-stack-wrap",
										children: /* @__PURE__ */ v(Jt, {
											signature: l.field[re][e].map((e) => e.token).join(","),
											children: F(re, e)
										})
									}, `opponent:${e}`)),
									xe.map(I),
									xe.map((e) => /* @__PURE__ */ v("div", {
										className: "c3-stack-wrap",
										children: /* @__PURE__ */ v(Jt, {
											signature: l.field[S][e].map((e) => e.token).join(","),
											children: F(S, e)
										})
									}, `own:${e}`))
								]
							}),
							l.available.length > 0 && /* @__PURE__ */ y("div", {
								className: "c3-draft",
								children: [/* @__PURE__ */ v("h2", { children: ie ? x.draft : x.waitingDraft }), /* @__PURE__ */ v("div", {
									className: "c3-draft-grid",
									children: l.available.map((e) => {
										let t = C.find((t) => t.card === e);
										return /* @__PURE__ */ y("button", {
											className: "c3-draft-card",
											style: {
												"--protocol": he[e],
												"--card-art": `url('games/compile3/${e}.webp')`
											},
											disabled: !t,
											onClick: () => t && M(t),
											children: [
												/* @__PURE__ */ v(Ut, {
													protocol: e,
													size: 44
												}),
												/* @__PURE__ */ v("strong", { children: A(e) }),
												/* @__PURE__ */ v("small", { children: t ? x.draft : x.wait })
											]
										}, e);
									})
								})]
							}),
							je && Me && /* @__PURE__ */ y("section", {
								className: "c3-choice-tray",
								"aria-label": x.choices,
								children: [
									/* @__PURE__ */ y("div", {
										className: "c3-tray-head",
										children: [/* @__PURE__ */ v("strong", { children: Pe }), /* @__PURE__ */ v("button", {
											className: "c3-tool",
											onClick: () => _e({
												decision: u?.decision ?? -1,
												open: !1
											}),
											children: x.hideChoices
										})]
									}),
									L.length > 0 && /* @__PURE__ */ v("div", {
										className: "c3-order-choices",
										children: L.map((e) => /* @__PURE__ */ y("button", {
											onClick: () => M(e),
											children: [/* @__PURE__ */ y("small", { children: [N(e.side ?? S), e.line === void 0 ? "" : ` · ${Ne(e.side ?? S, e.line)}`] }), e.order ? /* @__PURE__ */ v("strong", { children: e.order.map(A).join(" → ") }) : e.source ? /* @__PURE__ */ y(ee, { children: [/* @__PURE__ */ y("strong", { children: [
												P(e.source),
												" · ",
												x[e.slot ?? "mid"]
											] }), /* @__PURE__ */ v("span", { children: j[e.source][e.slot ?? "mid"][b] })] }) : ye(e)]
										}, e.id))
									}),
									R.length > 0 && /* @__PURE__ */ v("div", {
										className: "c3-declarations",
										children: R.map((e) => /* @__PURE__ */ y("button", {
											className: "c3-action",
											onClick: () => M(e),
											children: [/* @__PURE__ */ v(Ut, { protocol: e.card }), A(e.card)]
										}, e.id))
									}),
									Ae.length > 0 && /* @__PURE__ */ v("div", {
										className: "c3-declarations",
										children: Ae.map((e) => /* @__PURE__ */ y("button", {
											className: "c3-action",
											onClick: () => M(e),
											children: [
												N(e.side ?? S),
												" · ",
												Ne(e.side ?? S, e.line),
												" ↔ ",
												Ne(e.side ?? S, e.n)
											]
										}, e.id))
									}),
									ke.length > 0 && /* @__PURE__ */ v("div", {
										className: "c3-extra-cards",
										children: ke.map((e) => /* @__PURE__ */ v("div", {
											className: "c3-hand-card",
											children: /* @__PURE__ */ v("button", {
												className: "c3-card-button",
												onMouseEnter: () => k(e),
												onFocus: () => k(e),
												onClick: () => {
													let t = C.filter((t) => t.card === e);
													t.length === 1 && t[0].kind !== "play" ? M(t[0]) : (be(e), k(e));
												},
												"aria-label": P(e),
												children: /* @__PURE__ */ v(Gt, {
													id: e,
													locale: b,
													selected: D === e
												})
											})
										}, e))
									}),
									l.revealed.length > 0 && /* @__PURE__ */ v("div", {
										className: "c3-revealed",
										children: l.revealed.map((e, t) => /* @__PURE__ */ y("p", { children: [
											N(e.side),
											" · ",
											x.revealHand,
											": ",
											e.cards.map((e) => /* @__PURE__ */ v("button", {
												onClick: () => ue(e),
												children: P(e)
											}, e))
										] }, t))
									})
								]
							})
						]
					}), /* @__PURE__ */ y("aside", {
						className: "c3-inspector",
						children: [
							/* @__PURE__ */ v("h2", { children: x.cardPreview }),
							ve && /* @__PURE__ */ v("button", {
								className: "c3-inspector-card c3-card-button",
								onClick: () => ue(ve),
								children: /* @__PURE__ */ v(Gt, {
									id: ve,
									locale: b
								})
							}),
							/* @__PURE__ */ y("div", {
								className: "c3-recent",
								children: [/* @__PURE__ */ v("h2", { children: x.recent }), l.log.slice(-3).map((e, t) => /* @__PURE__ */ v("p", { children: we(e) }, t))]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ v(p, {
				open: de,
				onClose: () => fe(!1),
				label: x.log,
				title: x.log,
				children: /* @__PURE__ */ v("div", {
					className: "c3-log",
					children: l.log.map((e, t) => /* @__PURE__ */ v("p", { children: we(e) }, t))
				})
			}),
			/* @__PURE__ */ v(p, {
				open: pe !== null,
				onClose: () => me(null),
				label: x.trash,
				title: `${x.trash} · ${pe === null ? "" : N(pe)}`,
				children: /* @__PURE__ */ v("div", {
					className: "c3-trash-grid",
					children: pe !== null && l.trash[pe].map((e) => /* @__PURE__ */ v("button", {
						className: "c3-card-button",
						onClick: () => ue(e),
						children: /* @__PURE__ */ v(Gt, {
							id: e,
							locale: b
						})
					}, e))
				})
			}),
			/* @__PURE__ */ v(p, {
				open: ce && !!ve,
				onClose: () => le(!1),
				label: x.details,
				title: x.details,
				children: ve && /* @__PURE__ */ v("div", {
					className: "c3-detail",
					children: /* @__PURE__ */ v(Gt, {
						id: ve,
						locale: b
					})
				})
			}),
			/* @__PURE__ */ v("span", {
				className: "sr-only",
				children: ne("games.compile3.name")
			})
		]
	});
}
//#endregion
//#region src/games/compile3/bot.ts
var Zt = {
	compile: 18,
	lead: 1.4,
	threat: 2.5,
	cards: 1.3,
	command: 1
}, Qt = (e) => 1 - e;
function $t(e, t, n, r) {
	let i = t.side ?? n, a = t.line ?? 0, o = Qt(n), s = i === n ? 1 : -1, c = t.source ? j[t.source] : null, l = t.token === void 0 ? null : e.field.flat(2).find((e) => e.token === t.token), u = t.card ? j[t.card]?.value ?? 2 : l?.value ?? 2, d = e.totals[n][a], f = e.totals[o][a], p = Math.max(10, f + 1) - d;
	switch (t.kind) {
		case "compile": return 100 + (e.protocols[n][a].compiled ? -25 : r.compile) + e.field[o][a].length - e.field[n][a].length;
		case "draft": return _e.filter((e) => e.protocol === t.card).reduce((e, t) => e + t.value, 0) + (t.card === "lust" ? 5 : t.card === "overwhelm" ? 3 : 0);
		case "refresh": return (5 - e.handCounts[n]) * r.cards + (e.handCounts[n] === 0 ? 30 : -2);
		case "play": {
			let i = t.up ? u : 2, o = d + s * i, c = s > 0 && !e.protocols[n][a].compiled && o >= Math.max(10, f + 1) ? r.compile : 0, l = s > 0 && f >= 10 && d <= f && o >= f ? r.threat * 4 : 0, m = t.card ? j[t.card] : null, h = t.up && m ? m.mid.en.startsWith("Draw") ? 3 : m.mid.en === "Discard 1 card." ? -1.5 : +!!m.mid.en.startsWith("Flip") : 0;
			return c + l + Math.min(i, Math.max(1, p)) * s * r.lead + h * r.command - (e.protocols[n][a].compiled ? 2 : 0);
		}
		case "discard":
		case "bottomHand": return 5 - u + (j[t.card ?? ""]?.mid.en === "Discard 1 card." ? .5 : 0);
		case "delete": return -s * u * r.threat + (s < 0 && f >= 10 ? 7 : 0);
		case "return": return -s * u + (s > 0 ? r.cards * 2 : -r.cards);
		case "flip": return s * (l?.up ? 2 - u : .5) * r.threat + (c?.id === "rigid-7" ? -20 : 0);
		case "shift": return s * u * (e.totals[i][a] < 10 ? .8 : -.3) + (s > 0 && !e.protocols[n][a].compiled && d + u > f && d + u >= 10 ? r.compile : 0);
		case "rearrange": return t.order?.reduce((t, n, r) => t + (e.protocols[i].find((e) => e.name === n)?.compiled ? -1 : 1) * e.totals[i][r] * s, 0) ?? 0;
		case "draw": return r.cards;
		case "accept": return 1;
		case "skip": return 0;
		default: return 0;
	}
}
function en(e = Zt) {
	return (t, n) => {
		let r = t.private?.options ?? [];
		if (!r.length || t.public.pending?.actor !== n.rid) return null;
		let i = Math.max(0, t.public.sides.indexOf(n.rid));
		return { action: {
			type: "choose",
			id: (n.difficulty === "weak" ? r[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % r.length] : r.reduce((n, r) => $t(t.public, r, i, e) > $t(t.public, n, i, e) ? r : n)).id
		} };
	};
}
var tn = en();
//#endregion
//#region src/games/compile3/fx.tsx
function nn(e) {
	let n = t((e) => e.locale);
	return /* @__PURE__ */ v(Gt, {
		...e,
		locale: n === "zh" ? "zh" : "en"
	});
}
var rn = {
	protocol(e, t) {
		let n = e.data, r = t.anchor(n.from), i = t.anchor(n.to);
		if (!r || !i) return null;
		let a = t.queued ? 140 : U.move;
		return {
			ms: a,
			node: /* @__PURE__ */ v(te, {
				from: r,
				to: i,
				ms: a,
				children: /* @__PURE__ */ y("div", {
					className: "c3-protocol",
					style: {
						width: r.w,
						height: r.h,
						"--protocol": he[n.protocol]
					},
					children: [/* @__PURE__ */ v(Ut, {
						protocol: n.protocol,
						size: 27
					}), /* @__PURE__ */ y("span", { children: [/* @__PURE__ */ v("b", { children: A(n.protocol) }), /* @__PURE__ */ v("small", { children: n.compiled ? "◆" : "◇" })] })]
				})
			}),
			...t.queued ? {} : { hide: [n.to] }
		};
	},
	move(e, t) {
		let n = e.data, r = e.secret, i = (r?.from ? t.anchor(r.from) : null) ?? t.anchor(n.from), a = t.anchor(n.to);
		if (!i || !a) return null;
		let o = t.queued ? 140 : n.kind.startsWith("compile") ? U.compile : U.move;
		if (n.kind === "compile" || n.kind === "rearrange") return {
			ms: o,
			node: /* @__PURE__ */ v(b, {
				at: a,
				ms: o
			})
		};
		if (n.kind === "flip") return {
			ms: o,
			node: /* @__PURE__ */ v("div", {
				className: "absolute",
				style: {
					left: a.x,
					top: a.y,
					width: a.w,
					height: a.h,
					perspective: 600
				},
				children: /* @__PURE__ */ v("div", {
					className: "c3-fx-flip",
					style: {
						width: "100%",
						animationDuration: `${o}ms`,
						"--c3-covered-height": `${a.h}px`
					},
					children: /* @__PURE__ */ v(nn, {
						id: n.card ?? r?.card,
						down: !n.card,
						covered: a.h < 75
					})
				})
			}),
			...t.queued ? {} : { hide: [n.to] }
		};
		let s = n.card ?? r?.card, c = n.kind === "play" || n.kind === "shift", l = t.anchor("card-size")?.w ?? (c ? a.w : i.w), u = c ? a.h < 75 : n.from.startsWith("depart:") && !n.from.startsWith("depart:hand:") && i.h < 75;
		return {
			ms: o,
			node: /* @__PURE__ */ v(te, {
				from: i,
				to: a,
				ms: o,
				children: /* @__PURE__ */ v("div", {
					style: {
						width: l,
						"--c3-covered-height": `${c ? a.h : i.h}px`
					},
					children: /* @__PURE__ */ v(nn, {
						id: s,
						down: !n.card && c,
						covered: u
					})
				})
			}),
			...n.token === void 0 || t.queued ? {} : { hide: [n.to] }
		};
	},
	control(e, t) {
		let n = t.anchor("protocols:0");
		return n ? {
			ms: U.move,
			node: /* @__PURE__ */ v(b, {
				at: n,
				ms: U.move
			})
		} : null;
	}
};
//#endregion
//#region src/games/compile3/game-over.tsx
function an(e) {
	let n = e.public, r = t((e) => e.locale), i = (r === "zh" ? Vt : Ht).ui, [a, o] = s(!1), c = (t) => {
		let a = e.members.find((e) => e.rid === n.sides[t]);
		return a ? g(a, r) : n.solo && t === 1 ? i.bot : i.opponent;
	};
	return /* @__PURE__ */ y("div", {
		className: "c3-root c3-final-root",
		children: [/* @__PURE__ */ v("div", {
			className: "c3-review-board",
			inert: !a,
			children: /* @__PURE__ */ v(Xt, {
				public: n,
				private: e.private,
				members: e.members,
				myRid: e.myRid,
				send: () => {},
				onShowResults: () => o(!1)
			})
		}), /* @__PURE__ */ y("section", {
			className: "c3-over",
			hidden: a,
			"aria-label": i.results,
			children: [
				/* @__PURE__ */ v("button", {
					className: "c3-final-close c3-tool",
					onClick: () => o(!0),
					"aria-label": i.review,
					children: /* @__PURE__ */ v(x, { size: 20 })
				}),
				/* @__PURE__ */ y("span", { children: ["COMPILE · ", r === "zh" ? Vt.name : Ht.name] }),
				/* @__PURE__ */ v("h1", { children: n.winner === -1 ? i.stalemate : n.solo && n.winner === 1 ? i.lose : i.win }),
				/* @__PURE__ */ v("div", {
					className: "c3-over-grid",
					children: n.protocols.map((t, r) => {
						let a = e.members.find((e) => e.rid === n.sides[r]);
						return /* @__PURE__ */ y("section", {
							className: "c3-over-player",
							"data-winner": n.winner === r,
							children: [/* @__PURE__ */ y("h2", { children: [
								/* @__PURE__ */ v("span", {
									className: "c3-avatar",
									style: { background: a ? h[a.colorIndex % h.length].hex : "#465f78" },
									children: /* @__PURE__ */ v("img", {
										src: m[(a?.avatar ?? 0) % m.length],
										alt: ""
									})
								}),
								c(r),
								/* @__PURE__ */ y("small", { children: [t.filter((e) => e.compiled).length, " / 3"] })
							] }), t.map((e) => /* @__PURE__ */ y("div", {
								className: "c3-over-protocol",
								children: [
									/* @__PURE__ */ v(Ut, {
										protocol: e.name,
										size: 38
									}),
									/* @__PURE__ */ v("strong", { children: A(e.name) }),
									/* @__PURE__ */ v("small", { children: e.compiled ? i.compiled : i.loading })
								]
							}, e.name))]
						}, r);
					})
				}),
				e.hintCount !== void 0 && e.hintCount > 0 && /* @__PURE__ */ v("p", {
					className: "c3-ending-hint",
					children: i.hintCount.replace("{n}", String(e.hintCount))
				}),
				/* @__PURE__ */ y("div", {
					className: "c3-over-controls",
					children: [
						/* @__PURE__ */ v("button", {
							onClick: () => o(!0),
							children: i.review
						}),
						e.onPlayAgain && /* @__PURE__ */ v("button", {
							onClick: e.onPlayAgain,
							children: i.startAgain
						}),
						e.onBackToLobby && /* @__PURE__ */ v("button", {
							onClick: e.onBackToLobby,
							children: i.lobby
						}),
						!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ v("span", { children: i.waitHost })
					]
				})
			]
		})]
	});
}
//#endregion
//#region src/games/compile3/options.tsx
function on({ value: e, onChange: n }) {
	let r = (t((e) => e.locale) === "zh" ? Vt : Ht).ui, i = it.safeParse(e), a = i.success ? i.data : it.parse(void 0);
	return /* @__PURE__ */ y("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ v(re, {
				title: r.boxes,
				children: [
					1,
					2,
					3
				].map((e) => /* @__PURE__ */ v(ne, {
					name: "compile3-boxes",
					value: String(e),
					checked: a.boxes.includes(e),
					disabled: a.boxes.length === 1 && a.boxes.includes(e),
					label: `${r.mainBox} ${e}`,
					onChange: () => n({
						...a,
						boxes: a.boxes.includes(e) ? a.boxes.filter((t) => t !== e) : [...a.boxes, e].sort()
					})
				}, e))
			}),
			/* @__PURE__ */ v(re, {
				title: r.aux,
				children: [
					"aux1",
					"aux2",
					"aux3"
				].map((e, t) => /* @__PURE__ */ v(ne, {
					name: "compile3-aux",
					value: e,
					checked: a[e],
					label: `${r.auxBox} ${t + 1}`,
					onChange: () => n({
						...a,
						[e]: !a[e]
					})
				}, e))
			}),
			/* @__PURE__ */ v(re, {
				title: r.controlOption,
				children: /* @__PURE__ */ v(ne, {
					name: "compile3-control",
					value: "control",
					checked: a.control,
					label: r.controlOption,
					onChange: () => n({
						...a,
						control: !a.control
					})
				})
			}),
			/* @__PURE__ */ v(re, {
				title: r.draftOption,
				children: [!0, !1].map((e) => /* @__PURE__ */ v(S, {
					name: "compile3-draft",
					value: String(e),
					checked: a.draft === e,
					label: e ? r.draftOn : r.draftOff,
					onChange: () => n({
						...a,
						draft: e
					})
				}, String(e)))
			}),
			/* @__PURE__ */ v(re, {
				title: r.solo,
				children: oe.map((e, t) => /* @__PURE__ */ v(S, {
					name: "compile3-scenario",
					value: String(t),
					checked: a.scenario === t,
					label: /* @__PURE__ */ y(ee, { children: [`${t < 6 ? r.regular : r.advanced} ${t % 6 + 1} · ${M(t)}`, /* @__PURE__ */ v("small", {
						className: "block",
						children: e.protocols.map(A).join(" · ")
					})] }),
					onChange: () => n({
						...a,
						scenario: t
					})
				}, e.name))
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/compile3/entry.tsx
var sn = {
	definition: Bt,
	View: Yt,
	bot: tn,
	fx: rn,
	OverView: an,
	Options: on,
	locales: {
		zh: Vt,
		en: Ht
	}
};
//#endregion
export { sn as default };
