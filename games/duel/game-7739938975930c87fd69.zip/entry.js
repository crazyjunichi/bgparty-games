import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useT as r } from "@bgparty/sdk/i18n";
import { Texture as i } from "@bgparty/sdk/texture";
import { GameScreen as a } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as o } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as s, jsx as c, jsxs as l } from "react/jsx-runtime";
import { Confetti as u } from "@bgparty/sdk/ui/confetti";
//#region src/games/duel/data.ts
var d = [
	"clay",
	"wood",
	"stone",
	"glass",
	"papyrus"
], f = [
	{
		id: "lumber-yard",
		age: 1,
		color: "brown",
		cost: {},
		effects: [{
			kind: "produce",
			resources: { wood: 1 }
		}]
	},
	{
		id: "logging-camp",
		age: 1,
		color: "brown",
		cost: { coins: 1 },
		effects: [{
			kind: "produce",
			resources: { wood: 1 }
		}]
	},
	{
		id: "clay-pool",
		age: 1,
		color: "brown",
		cost: {},
		effects: [{
			kind: "produce",
			resources: { clay: 1 }
		}]
	},
	{
		id: "clay-pit",
		age: 1,
		color: "brown",
		cost: { coins: 1 },
		effects: [{
			kind: "produce",
			resources: { clay: 1 }
		}]
	},
	{
		id: "quarry",
		age: 1,
		color: "brown",
		cost: {},
		effects: [{
			kind: "produce",
			resources: { stone: 1 }
		}]
	},
	{
		id: "stone-pit",
		age: 1,
		color: "brown",
		cost: { coins: 1 },
		effects: [{
			kind: "produce",
			resources: { stone: 1 }
		}]
	},
	{
		id: "glassworks",
		age: 1,
		color: "gray",
		cost: { coins: 1 },
		effects: [{
			kind: "produce",
			resources: { glass: 1 }
		}]
	},
	{
		id: "press",
		age: 1,
		color: "gray",
		cost: { coins: 1 },
		effects: [{
			kind: "produce",
			resources: { papyrus: 1 }
		}]
	},
	{
		id: "guard-tower",
		age: 1,
		color: "red",
		cost: {},
		effects: [{
			kind: "shields",
			n: 1
		}]
	},
	{
		id: "stable",
		age: 1,
		color: "red",
		cost: { resources: { wood: 1 } },
		chainTo: "horseshoe",
		effects: [{
			kind: "shields",
			n: 1
		}]
	},
	{
		id: "garrison",
		age: 1,
		color: "red",
		cost: { resources: { clay: 1 } },
		chainTo: "sword",
		effects: [{
			kind: "shields",
			n: 1
		}]
	},
	{
		id: "palisade",
		age: 1,
		color: "red",
		cost: { coins: 2 },
		chainTo: "wall",
		effects: [{
			kind: "shields",
			n: 1
		}]
	},
	{
		id: "workshop",
		age: 1,
		color: "green",
		cost: { resources: { papyrus: 1 } },
		effects: [{
			kind: "vp",
			n: 1
		}, {
			kind: "science",
			symbol: "compass"
		}]
	},
	{
		id: "apothecary",
		age: 1,
		color: "green",
		cost: { resources: { glass: 1 } },
		effects: [{
			kind: "vp",
			n: 1
		}, {
			kind: "science",
			symbol: "wheel"
		}]
	},
	{
		id: "scriptorium",
		age: 1,
		color: "green",
		cost: { coins: 2 },
		chainTo: "book",
		effects: [{
			kind: "science",
			symbol: "writing"
		}]
	},
	{
		id: "pharmacist",
		age: 1,
		color: "green",
		cost: { coins: 2 },
		chainTo: "gear",
		effects: [{
			kind: "science",
			symbol: "mortar"
		}]
	},
	{
		id: "stone-reserve",
		age: 1,
		color: "yellow",
		cost: { coins: 3 },
		effects: [{
			kind: "tradeOne",
			resources: ["stone"]
		}]
	},
	{
		id: "clay-reserve",
		age: 1,
		color: "yellow",
		cost: { coins: 3 },
		effects: [{
			kind: "tradeOne",
			resources: ["clay"]
		}]
	},
	{
		id: "wood-reserve",
		age: 1,
		color: "yellow",
		cost: { coins: 3 },
		effects: [{
			kind: "tradeOne",
			resources: ["wood"]
		}]
	},
	{
		id: "theater",
		age: 1,
		color: "blue",
		cost: {},
		chainTo: "mask",
		effects: [{
			kind: "vp",
			n: 3
		}]
	},
	{
		id: "altar",
		age: 1,
		color: "blue",
		cost: {},
		chainTo: "moon",
		effects: [{
			kind: "vp",
			n: 3
		}]
	},
	{
		id: "baths",
		age: 1,
		color: "blue",
		cost: { resources: { stone: 1 } },
		chainTo: "drop",
		effects: [{
			kind: "vp",
			n: 3
		}]
	},
	{
		id: "tavern",
		age: 1,
		color: "yellow",
		cost: {},
		chainTo: "amphora",
		effects: [{
			kind: "coins",
			n: 4
		}]
	}
], p = [
	{
		id: "sawmill",
		age: 2,
		color: "brown",
		cost: { coins: 2 },
		effects: [{
			kind: "produce",
			resources: { wood: 2 }
		}]
	},
	{
		id: "brickyard",
		age: 2,
		color: "brown",
		cost: { coins: 2 },
		effects: [{
			kind: "produce",
			resources: { clay: 2 }
		}]
	},
	{
		id: "shelf-quarry",
		age: 2,
		color: "brown",
		cost: { coins: 2 },
		effects: [{
			kind: "produce",
			resources: { stone: 2 }
		}]
	},
	{
		id: "glass-blower",
		age: 2,
		color: "gray",
		cost: {},
		effects: [{
			kind: "produce",
			resources: { glass: 1 }
		}]
	},
	{
		id: "drying-room",
		age: 2,
		color: "gray",
		cost: {},
		effects: [{
			kind: "produce",
			resources: { papyrus: 1 }
		}]
	},
	{
		id: "walls",
		age: 2,
		color: "red",
		cost: { resources: { stone: 2 } },
		effects: [{
			kind: "shields",
			n: 2
		}]
	},
	{
		id: "horse-breeders",
		age: 2,
		color: "red",
		cost: { resources: {
			clay: 1,
			wood: 1
		} },
		chainFrom: "horseshoe",
		effects: [{
			kind: "shields",
			n: 1
		}]
	},
	{
		id: "barracks",
		age: 2,
		color: "red",
		cost: { coins: 3 },
		chainFrom: "sword",
		effects: [{
			kind: "shields",
			n: 1
		}]
	},
	{
		id: "archery-range",
		age: 2,
		color: "red",
		cost: { resources: {
			stone: 1,
			wood: 1,
			papyrus: 1
		} },
		chainTo: "target",
		effects: [{
			kind: "shields",
			n: 2
		}]
	},
	{
		id: "parade-ground",
		age: 2,
		color: "red",
		cost: { resources: {
			clay: 2,
			glass: 1
		} },
		chainTo: "helmet",
		effects: [{
			kind: "shields",
			n: 2
		}]
	},
	{
		id: "forum",
		age: 2,
		color: "yellow",
		cost: {
			coins: 3,
			resources: { clay: 1 }
		},
		effects: [{
			kind: "produceChoice",
			options: ["glass", "papyrus"]
		}]
	},
	{
		id: "caravansery",
		age: 2,
		color: "yellow",
		cost: {
			coins: 2,
			resources: {
				glass: 1,
				papyrus: 1
			}
		},
		effects: [{
			kind: "produceChoice",
			options: [
				"wood",
				"clay",
				"stone"
			]
		}]
	},
	{
		id: "customs-house",
		age: 2,
		color: "yellow",
		cost: { coins: 4 },
		effects: [{
			kind: "tradeOne",
			resources: ["papyrus", "glass"]
		}]
	},
	{
		id: "brewery",
		age: 2,
		color: "yellow",
		cost: {},
		chainTo: "barrel",
		effects: [{
			kind: "coins",
			n: 6
		}]
	},
	{
		id: "library",
		age: 2,
		color: "green",
		cost: { resources: {
			stone: 1,
			wood: 1,
			glass: 1
		} },
		chainFrom: "book",
		effects: [{
			kind: "vp",
			n: 2
		}, {
			kind: "science",
			symbol: "writing"
		}]
	},
	{
		id: "dispensary",
		age: 2,
		color: "green",
		cost: { resources: {
			clay: 2,
			stone: 1
		} },
		chainFrom: "gear",
		effects: [{
			kind: "vp",
			n: 2
		}, {
			kind: "science",
			symbol: "mortar"
		}]
	},
	{
		id: "school",
		age: 2,
		color: "green",
		cost: { resources: {
			wood: 1,
			papyrus: 2
		} },
		chainTo: "lyre",
		effects: [{
			kind: "vp",
			n: 1
		}, {
			kind: "science",
			symbol: "wheel"
		}]
	},
	{
		id: "laboratory",
		age: 2,
		color: "green",
		cost: { resources: {
			wood: 1,
			glass: 2
		} },
		chainTo: "lamp",
		effects: [{
			kind: "vp",
			n: 1
		}, {
			kind: "science",
			symbol: "compass"
		}]
	},
	{
		id: "statue",
		age: 2,
		color: "blue",
		cost: { resources: { clay: 2 } },
		chainFrom: "mask",
		chainTo: "columns",
		effects: [{
			kind: "vp",
			n: 4
		}]
	},
	{
		id: "temple",
		age: 2,
		color: "blue",
		cost: { resources: {
			wood: 1,
			papyrus: 1
		} },
		chainFrom: "moon",
		chainTo: "sun",
		effects: [{
			kind: "vp",
			n: 4
		}]
	},
	{
		id: "aqueduct",
		age: 2,
		color: "blue",
		cost: { resources: { stone: 3 } },
		chainFrom: "drop",
		effects: [{
			kind: "vp",
			n: 5
		}]
	},
	{
		id: "rostrum",
		age: 2,
		color: "blue",
		cost: { resources: {
			stone: 1,
			wood: 1
		} },
		chainTo: "senate",
		effects: [{
			kind: "vp",
			n: 4
		}]
	},
	{
		id: "courthouse",
		age: 2,
		color: "blue",
		cost: { resources: {
			wood: 2,
			glass: 1
		} },
		effects: [{
			kind: "vp",
			n: 5
		}]
	}
], m = [
	{
		id: "arsenal",
		age: 3,
		color: "red",
		cost: { resources: {
			clay: 3,
			wood: 2
		} },
		effects: [{
			kind: "shields",
			n: 3
		}]
	},
	{
		id: "pretorium",
		age: 3,
		color: "red",
		cost: { coins: 8 },
		effects: [{
			kind: "shields",
			n: 3
		}]
	},
	{
		id: "fortifications",
		age: 3,
		color: "red",
		cost: { resources: {
			stone: 2,
			clay: 1,
			papyrus: 1
		} },
		chainFrom: "wall",
		effects: [{
			kind: "shields",
			n: 2
		}]
	},
	{
		id: "siege-workshop",
		age: 3,
		color: "red",
		cost: { resources: {
			wood: 3,
			glass: 1
		} },
		chainFrom: "target",
		effects: [{
			kind: "shields",
			n: 2
		}]
	},
	{
		id: "circus",
		age: 3,
		color: "red",
		cost: { resources: {
			clay: 2,
			stone: 2
		} },
		chainFrom: "helmet",
		effects: [{
			kind: "shields",
			n: 2
		}]
	},
	{
		id: "academy",
		age: 3,
		color: "green",
		cost: { resources: {
			stone: 1,
			wood: 1,
			glass: 2
		} },
		effects: [{
			kind: "vp",
			n: 3
		}, {
			kind: "science",
			symbol: "sundial"
		}]
	},
	{
		id: "study",
		age: 3,
		color: "green",
		cost: { resources: {
			wood: 2,
			glass: 1,
			papyrus: 1
		} },
		effects: [{
			kind: "vp",
			n: 3
		}, {
			kind: "science",
			symbol: "sundial"
		}]
	},
	{
		id: "university",
		age: 3,
		color: "green",
		cost: { resources: {
			clay: 1,
			glass: 1,
			papyrus: 1
		} },
		chainFrom: "lyre",
		effects: [{
			kind: "vp",
			n: 2
		}, {
			kind: "science",
			symbol: "astrology"
		}]
	},
	{
		id: "observatory",
		age: 3,
		color: "green",
		cost: { resources: {
			stone: 1,
			papyrus: 2
		} },
		chainFrom: "lamp",
		effects: [{
			kind: "vp",
			n: 2
		}, {
			kind: "science",
			symbol: "astrology"
		}]
	},
	{
		id: "palace",
		age: 3,
		color: "blue",
		cost: { resources: {
			clay: 1,
			stone: 1,
			wood: 1,
			glass: 2
		} },
		effects: [{
			kind: "vp",
			n: 7
		}]
	},
	{
		id: "town-hall",
		age: 3,
		color: "blue",
		cost: { resources: {
			stone: 3,
			wood: 2
		} },
		effects: [{
			kind: "vp",
			n: 7
		}]
	},
	{
		id: "obelisk",
		age: 3,
		color: "blue",
		cost: { resources: {
			stone: 2,
			glass: 1
		} },
		effects: [{
			kind: "vp",
			n: 5
		}]
	},
	{
		id: "gardens",
		age: 3,
		color: "blue",
		cost: { resources: {
			clay: 2,
			wood: 2
		} },
		chainFrom: "columns",
		effects: [{
			kind: "vp",
			n: 6
		}]
	},
	{
		id: "pantheon",
		age: 3,
		color: "blue",
		cost: { resources: {
			clay: 1,
			wood: 1,
			papyrus: 2
		} },
		chainFrom: "sun",
		effects: [{
			kind: "vp",
			n: 6
		}]
	},
	{
		id: "senate",
		age: 3,
		color: "blue",
		cost: { resources: {
			clay: 2,
			stone: 1,
			papyrus: 1
		} },
		chainFrom: "senate",
		effects: [{
			kind: "vp",
			n: 5
		}]
	},
	{
		id: "chamber-of-commerce",
		age: 3,
		color: "yellow",
		cost: { resources: { papyrus: 2 } },
		effects: [{
			kind: "vp",
			n: 3
		}, {
			kind: "coinsPer",
			target: "gray",
			n: 3
		}]
	},
	{
		id: "port",
		age: 3,
		color: "yellow",
		cost: { resources: {
			wood: 1,
			glass: 1,
			papyrus: 1
		} },
		effects: [{
			kind: "vp",
			n: 3
		}, {
			kind: "coinsPer",
			target: "brown",
			n: 2
		}]
	},
	{
		id: "armory",
		age: 3,
		color: "yellow",
		cost: { resources: {
			stone: 2,
			glass: 1
		} },
		effects: [{
			kind: "vp",
			n: 3
		}, {
			kind: "coinsPer",
			target: "red",
			n: 1
		}]
	},
	{
		id: "lighthouse",
		age: 3,
		color: "yellow",
		cost: { resources: {
			clay: 2,
			glass: 1
		} },
		chainFrom: "amphora",
		effects: [{
			kind: "vp",
			n: 3
		}, {
			kind: "coinsPer",
			target: "yellow",
			n: 1
		}]
	},
	{
		id: "arena",
		age: 3,
		color: "yellow",
		cost: { resources: {
			clay: 1,
			stone: 1,
			wood: 1
		} },
		chainFrom: "barrel",
		effects: [{
			kind: "vp",
			n: 3
		}, {
			kind: "coinsPer",
			target: "wonder",
			n: 2
		}]
	}
], h = [
	{
		id: "merchants-guild",
		age: 3,
		color: "purple",
		cost: { resources: {
			clay: 1,
			wood: 1,
			glass: 1,
			papyrus: 1
		} },
		effects: [{
			kind: "guild",
			target: "yellow",
			coinsPer: 1,
			vpPer: 1
		}]
	},
	{
		id: "shipowners-guild",
		age: 3,
		color: "purple",
		cost: { resources: {
			clay: 1,
			stone: 1,
			glass: 1,
			papyrus: 1
		} },
		effects: [{
			kind: "guild",
			target: "brownGray",
			coinsPer: 1,
			vpPer: 1
		}]
	},
	{
		id: "builders-guild",
		age: 3,
		color: "purple",
		cost: { resources: {
			stone: 2,
			clay: 1,
			wood: 1,
			glass: 1
		} },
		effects: [{
			kind: "guild",
			target: "wonder",
			coinsPer: 0,
			vpPer: 2
		}]
	},
	{
		id: "magistrates-guild",
		age: 3,
		color: "purple",
		cost: { resources: {
			wood: 2,
			clay: 1,
			papyrus: 1
		} },
		effects: [{
			kind: "guild",
			target: "blue",
			coinsPer: 1,
			vpPer: 1
		}]
	},
	{
		id: "scientists-guild",
		age: 3,
		color: "purple",
		cost: { resources: {
			clay: 2,
			wood: 2
		} },
		effects: [{
			kind: "guild",
			target: "green",
			coinsPer: 1,
			vpPer: 1
		}]
	},
	{
		id: "moneylenders-guild",
		age: 3,
		color: "purple",
		cost: { resources: {
			stone: 2,
			wood: 2
		} },
		effects: [{
			kind: "guild",
			target: "coins",
			coinsPer: 0,
			vpPer: 1
		}]
	},
	{
		id: "tacticians-guild",
		age: 3,
		color: "purple",
		cost: { resources: {
			stone: 2,
			clay: 1,
			papyrus: 1
		} },
		effects: [{
			kind: "guild",
			target: "red",
			coinsPer: 1,
			vpPer: 1
		}]
	}
], g = [
	...f,
	...p,
	...m,
	...h
], _ = new Map(g.map((e) => [e.id, e]));
function v(e) {
	let t = _.get(e);
	if (!t) throw Error(`unknown card ${e}`);
	return t;
}
var ee = new Map([
	{
		id: "appian-way",
		cost: { resources: {
			stone: 2,
			clay: 2,
			papyrus: 1
		} },
		effects: [
			{
				kind: "coins",
				n: 3
			},
			{
				kind: "opponentCoins",
				n: 3
			},
			{ kind: "playAgain" },
			{
				kind: "vp",
				n: 3
			}
		]
	},
	{
		id: "circus-maximus",
		cost: { resources: {
			stone: 2,
			wood: 1,
			glass: 1
		} },
		effects: [
			{
				kind: "destroy",
				color: "gray"
			},
			{
				kind: "shields",
				n: 1
			},
			{
				kind: "vp",
				n: 3
			}
		]
	},
	{
		id: "colossus",
		cost: { resources: {
			clay: 3,
			glass: 1
		} },
		effects: [{
			kind: "shields",
			n: 2
		}, {
			kind: "vp",
			n: 3
		}]
	},
	{
		id: "great-library",
		cost: { resources: {
			wood: 3,
			papyrus: 1,
			glass: 1
		} },
		effects: [{ kind: "library" }, {
			kind: "vp",
			n: 4
		}]
	},
	{
		id: "great-lighthouse",
		cost: { resources: {
			wood: 1,
			stone: 1,
			papyrus: 2
		} },
		effects: [{
			kind: "produceChoice",
			options: [
				"wood",
				"stone",
				"clay"
			]
		}, {
			kind: "vp",
			n: 4
		}]
	},
	{
		id: "hanging-gardens",
		cost: { resources: {
			wood: 2,
			papyrus: 1,
			glass: 1
		} },
		effects: [
			{
				kind: "coins",
				n: 6
			},
			{ kind: "playAgain" },
			{
				kind: "vp",
				n: 3
			}
		]
	},
	{
		id: "mausoleum",
		cost: { resources: {
			clay: 2,
			glass: 2,
			papyrus: 1
		} },
		effects: [{ kind: "revive" }, {
			kind: "vp",
			n: 2
		}]
	},
	{
		id: "piraeus",
		cost: { resources: {
			wood: 2,
			stone: 1,
			clay: 1
		} },
		effects: [
			{
				kind: "produceChoice",
				options: ["glass", "papyrus"]
			},
			{ kind: "playAgain" },
			{
				kind: "vp",
				n: 2
			}
		]
	},
	{
		id: "pyramids",
		cost: { resources: {
			stone: 3,
			papyrus: 1
		} },
		effects: [{
			kind: "vp",
			n: 9
		}]
	},
	{
		id: "sphinx",
		cost: { resources: {
			stone: 1,
			clay: 1,
			glass: 2
		} },
		effects: [{ kind: "playAgain" }, {
			kind: "vp",
			n: 6
		}]
	},
	{
		id: "statue-of-zeus",
		cost: { resources: {
			wood: 1,
			stone: 1,
			clay: 1,
			papyrus: 2
		} },
		effects: [
			{
				kind: "destroy",
				color: "brown"
			},
			{
				kind: "shields",
				n: 1
			},
			{
				kind: "vp",
				n: 3
			}
		]
	},
	{
		id: "temple-of-artemis",
		cost: { resources: {
			wood: 1,
			stone: 1,
			glass: 1,
			papyrus: 1
		} },
		effects: [{
			kind: "coins",
			n: 12
		}, { kind: "playAgain" }]
	}
].map((e) => [e.id, e]));
function y(e) {
	let t = ee.get(e);
	if (!t) throw Error(`unknown wonder ${e}`);
	return t;
}
var b = new Map([
	{
		id: "agriculture",
		effects: [{
			kind: "coins",
			n: 6
		}, {
			kind: "vp",
			n: 4
		}]
	},
	{
		id: "architecture",
		effects: [{
			kind: "discount",
			target: "wonder",
			n: 2
		}]
	},
	{
		id: "economy",
		effects: [{ kind: "economy" }]
	},
	{
		id: "law",
		effects: [{ kind: "scienceLaw" }]
	},
	{
		id: "masonry",
		effects: [{
			kind: "discount",
			target: "blue",
			n: 2
		}]
	},
	{
		id: "mathematics",
		effects: [{
			kind: "vpPerToken",
			n: 3
		}]
	},
	{
		id: "philosophy",
		effects: [{
			kind: "vp",
			n: 7
		}]
	},
	{
		id: "strategy",
		effects: [{ kind: "strategy" }]
	},
	{
		id: "theology",
		effects: [{ kind: "theology" }]
	},
	{
		id: "urbanism",
		effects: [{
			kind: "coins",
			n: 6
		}, { kind: "urbanism" }]
	}
].map((e) => [e.id, e]));
function x(e) {
	let t = b.get(e);
	if (!t) throw Error(`unknown token ${e}`);
	return t;
}
function S(e) {
	let t = [];
	return e.forEach((e, n) => {
		let r = e.xs ?? Array.from({ length: e.n }, (t, n) => -(e.n - 1) + n * 2);
		for (let i of r) t.push({
			row: n,
			x: i,
			faceUp: e.faceUp
		});
	}), t;
}
var C = {
	1: S([
		{
			n: 2,
			faceUp: !0
		},
		{
			n: 3,
			faceUp: !1
		},
		{
			n: 4,
			faceUp: !0
		},
		{
			n: 5,
			faceUp: !1
		},
		{
			n: 6,
			faceUp: !0
		}
	]),
	2: S([
		{
			n: 6,
			faceUp: !0
		},
		{
			n: 5,
			faceUp: !1
		},
		{
			n: 4,
			faceUp: !0
		},
		{
			n: 3,
			faceUp: !1
		},
		{
			n: 2,
			faceUp: !0
		}
	]),
	3: S([
		{
			n: 2,
			faceUp: !0
		},
		{
			n: 3,
			faceUp: !1
		},
		{
			n: 4,
			faceUp: !0
		},
		{
			n: 2,
			faceUp: !1,
			xs: [-2, 2]
		},
		{
			n: 4,
			faceUp: !0
		},
		{
			n: 3,
			faceUp: !1
		},
		{
			n: 2,
			faceUp: !0
		}
	])
}, w = [
	{
		from: 0,
		vp: 0,
		fine: 0
	},
	{
		from: 1,
		vp: 2,
		fine: 0
	},
	{
		from: 3,
		vp: 5,
		fine: 2
	},
	{
		from: 6,
		vp: 10,
		fine: 5
	}
], T = {
	id: "duel",
	tier: "beta",
	mechanics: [
		"drafting",
		"engine-building",
		"set-collection"
	],
	interactionTags: [],
	nameKey: "games.duel.name",
	descKey: "games.duel.desc",
	rulesKey: "games.duel.rules",
	icon: "🏛️",
	iconImg: "games/duel.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/duel/en.pdf" },
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#b45309",
	releasedAt: "2026-09-16",
	search: {
		py: "qi da qi ji dui jue",
		init: "qdqjdj"
	},
	hotseat: "cover"
}, E = t.union([
	t.object({
		type: t.literal("draft"),
		wonderId: t.string()
	}),
	t.object({
		type: t.literal("take"),
		slot: t.int().nonnegative(),
		use: t.enum([
			"build",
			"sell",
			"wonder"
		]),
		wonderId: t.string().optional()
	}),
	t.object({
		type: t.literal("chooseToken"),
		tokenId: t.string()
	}),
	t.object({
		type: t.literal("chooseDestroy"),
		cardId: t.string()
	}),
	t.object({
		type: t.literal("chooseRevive"),
		cardId: t.string()
	}),
	t.object({
		type: t.literal("chooseLibrary"),
		tokenId: t.string()
	}),
	t.object({
		type: t.literal("chooseStart"),
		player: t.string()
	})
]), D = t.string(), O = t.object({
	total: t.int().nonnegative(),
	trade: t.int().nonnegative(),
	viaChain: t.boolean()
}), k = t.object({
	rid: D,
	coins: t.int().nonnegative(),
	cards: t.array(t.string()),
	wonders: t.array(t.object({
		id: t.string(),
		built: t.boolean()
	})),
	tokens: t.array(t.string())
}), te = t.object({
	kind: t.enum([
		"token",
		"destroy",
		"revive",
		"library",
		"ageStart"
	]),
	who: D,
	options: t.array(t.string())
}), ne = t.object({
	phase: t.enum([
		"draft",
		"age",
		"choice",
		"done"
	]),
	age: t.union([
		t.literal(1),
		t.literal(2),
		t.literal(3)
	]),
	turn: D,
	draft: t.object({
		pool: t.array(t.string()),
		board: t.array(t.object({
			id: t.string(),
			ownerRid: D.nullable()
		})),
		round: t.union([t.literal(1), t.literal(2)]),
		turnRid: D
	}).nullable(),
	pyramid: t.array(t.object({
		slot: t.int().nonnegative(),
		cardId: t.string().nullable(),
		faceUp: t.boolean(),
		taken: t.boolean(),
		accessible: t.boolean(),
		buildPrice: O.nullable(),
		sellValue: t.int().nonnegative().nullable()
	})),
	pawn: t.int(),
	fines: t.array(t.int()),
	tokenPool: t.array(t.string()),
	discard: t.array(t.string()),
	cities: t.array(k),
	pending: te.nullable(),
	wonderPrices: t.record(t.string(), O.nullable()),
	winReason: t.enum([
		"military",
		"science",
		"civilian"
	]).nullable()
}), A = t.object({});
//#endregion
//#region src/games/duel/rules.ts
function j(e) {
	let t = {};
	for (let n of e) for (let e of v(n).effects) if (e.kind === "produce") for (let [n, r] of Object.entries(e.resources)) t[n] = (t[n] ?? 0) + (r ?? 0);
	return t;
}
function re(e) {
	let t = [], n = (e) => {
		for (let n of e) n.kind === "produceChoice" && n.options && t.push(n.options);
	};
	for (let t of e.cards) n(v(t).effects);
	for (let t of e.wonders) t.built && n(y(t.id).effects);
	return t;
}
function ie(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e) for (let e of v(n).effects) if (e.kind === "tradeOne") for (let n of e.resources) t.add(n);
	return t;
}
var M = (e, t) => e.tokens.includes(t);
function N(e) {
	let t = [];
	for (let n of e.cards) for (let e of v(n).effects) e.kind === "science" && t.push(e.symbol);
	return M(e, "law") && t.push("law"), t;
}
function ae(e) {
	return e.wonders.filter((e) => e.built).map((e) => y(e.id));
}
function P(e, t) {
	return e.cards.filter((e) => v(e).color === t).length;
}
function F(e, t, n, r) {
	let i = { ...e.resources ?? {} }, a = j(t.cards);
	for (let e of d) {
		let t = Math.min(i[e] ?? 0, a[e] ?? 0);
		t > 0 && (i[e] = (i[e] ?? 0) - t), i[e] === 0 && delete i[e];
	}
	let o = [];
	for (let [e, t] of Object.entries(i)) for (let n = 0; n < (t ?? 0); n += 1) o.push(e);
	let s = (r === "wonder" && M(t, "architecture") ? 2 : 0) + (r === "blue" && M(t, "masonry") ? 2 : 0), c = re(t);
	for (let e = 0; e < s; e += 1) c.push([...d]);
	if (o.length === 0) return {
		total: e.coins ?? 0,
		trade: 0
	};
	let l = ie(t.cards), u = j(n.cards), f = (e) => l.has(e) ? 1 : 2 + (u[e] ?? 0), p = Infinity, m = Array(c.length).fill(!1), h = (e, t) => {
		if (t >= p) return;
		if (e === o.length) {
			p = t;
			return;
		}
		let n = o[e];
		for (let r = 0; r < c.length; r += 1) !m[r] && c[r].includes(n) && (m[r] = !0, h(e + 1, t), m[r] = !1);
		h(e + 1, t + f(n));
	};
	return h(0, 0), {
		total: (e.coins ?? 0) + p,
		trade: p
	};
}
function oe(e, t) {
	return !!e.chainFrom && t.some((t) => v(t).chainTo === e.chainFrom);
}
function I(e) {
	let t = Math.abs(e), n = 0;
	for (let e of w) t >= e.from && (n = e.vp);
	return n;
}
function L(e, t, n) {
	let r = [t, n], i = (e) => Math.max(e(r[0]), e(r[1]));
	switch (e) {
		case "yellow": return i((e) => P(e, "yellow"));
		case "blue": return i((e) => P(e, "blue"));
		case "green": return i((e) => P(e, "green"));
		case "red": return i((e) => P(e, "red"));
		case "brownGray": return i((e) => P(e, "brown") + P(e, "gray"));
		case "wonder": return i((e) => e.wonders.filter((e) => e.built).length);
		case "coins": return Math.floor(i((e) => e.coins) / 3);
		default: return 0;
	}
}
function R(e, t) {
	let n = e.cities[e.players[t]], r = e.cities[e.players[1 - t]], i = 0, a = 0, o = 0;
	for (let e of n.cards) {
		let t = v(e);
		for (let e of t.effects) e.kind === "vp" && (i += e.n), e.kind === "guild" && (a += e.vpPer * L(e.target, n, r));
		if (t.color === "blue") for (let e of t.effects) e.kind === "vp" && (o += e.n);
	}
	let s = 0;
	for (let e of ae(n)) for (let t of e.effects) t.kind === "vp" && (s += t.n);
	let c = 0;
	for (let e of n.tokens) for (let t of x(e).effects) t.kind === "vp" && (c += t.n), t.kind === "vpPerToken" && (c += t.n * n.tokens.length);
	let l = t === 0 ? 1 : -1, u = e.pawn * l > 0 ? I(e.pawn) : 0, d = Math.floor(n.coins / 3);
	return {
		buildings: i,
		guilds: a,
		wonders: s,
		tokens: c,
		military: u,
		coins: d,
		blueVp: o,
		total: i + a + s + c + u + d
	};
}
function z(t, n, r) {
	let i = [...t];
	for (let t = i.length - 1; t > 0; --t) {
		let a = e(n, r.v, t + 1);
		r.v += 1, [i[t], i[a]] = [i[a], i[t]];
	}
	return i;
}
function se(e, t, n) {
	let r = g.filter((t) => t.age === e && t.color !== "purple").map((e) => e.id);
	if (e === 3) {
		let e = z(g.filter((e) => e.color === "purple").map((e) => e.id), t, n).slice(0, 3);
		r = [...r, ...e];
	}
	let i = z(r, t, n);
	return C[e].map((e, t) => ({
		cardId: i[t],
		faceUp: e.faceUp,
		taken: !1
	}));
}
function B(t, n, r) {
	let i = { v: 0 }, a = z([
		"appian-way",
		"circus-maximus",
		"colossus",
		"great-library",
		"great-lighthouse",
		"hanging-gardens",
		"mausoleum",
		"piraeus",
		"pyramids",
		"sphinx",
		"statue-of-zeus",
		"temple-of-artemis"
	], r, i), o = z([
		"agriculture",
		"architecture",
		"economy",
		"law",
		"masonry",
		"mathematics",
		"philosophy",
		"strategy",
		"theology",
		"urbanism"
	], r, i), s = e(r, i.v, 2);
	i.v += 1;
	let c = {};
	for (let e of n) c[e] = {
		coins: 7,
		cards: [],
		wonders: [],
		tokens: []
	};
	return { state: {
		players: [n[0], n[1]],
		firstPlayer: s,
		phase: "draft",
		seed: r,
		cursor: i.v,
		draft: {
			pool: a.slice(0, 4),
			board: a.slice(0, 4),
			rest: a.slice(4, 8),
			round: 1,
			turn: s
		},
		age: 1,
		turn: s,
		pyramid: [],
		pawn: 0,
		fines: [],
		tokenPool: o.slice(0, 5),
		tokenBox: o.slice(5),
		discard: [],
		pending: [],
		extraTurn: !1,
		lastActor: s,
		winReason: null,
		winner: null,
		cities: c
	} };
}
function V(e, t) {
	return e.cities[e.players[t]];
}
function ce(e, t, n) {
	let r = t === 0 ? 1 : -1;
	e.pawn += r * n;
	let i = [{
		kind: "pawn",
		data: { pawn: e.pawn }
	}];
	for (let n of [3, 6]) {
		let a = n * r;
		if (Math.abs(e.pawn) >= n && Math.sign(e.pawn) === r && !e.fines.includes(a)) {
			e.fines.push(a);
			let r = V(e, 1 - t), o = Math.min(r.coins, n === 3 ? 2 : 5);
			r.coins -= o, i.push({
				kind: "fine",
				rid: e.players[1 - t],
				data: { coins: o }
			});
		}
	}
	return Math.abs(e.pawn) >= 9 && (e.phase = "done", e.winReason = "military", e.winner = t, e.pending = []), i;
}
function le(e, t) {
	let n = N(V(e, t));
	if (new Set(n).size >= 6) return e.phase = "done", e.winReason = "science", e.winner = t, e.pending = [], [];
	let r = /* @__PURE__ */ new Map();
	for (let e of n) r.set(e, (r.get(e) ?? 0) + 1);
	for (let [, n] of r) if (n === 2 && e.tokenPool.length > 0) {
		e.pending.push({
			kind: "token",
			who: t
		});
		break;
	}
	return [];
}
function ue(e, t, n) {
	let r = x(n), i = [{
		kind: "token",
		rid: e.players[t],
		data: { tokenId: n }
	}];
	V(e, t).tokens.push(n);
	for (let n of r.effects) n.kind === "coins" && (V(e, t).coins += n.n), n.kind === "scienceLaw" && i.push(...le(e, t));
	return i;
}
function de(e, t, n, r) {
	let i = V(e, t), a = V(e, 1 - t);
	for (let o of n.effects) switch (o.kind) {
		case "coins":
			i.coins += o.n;
			break;
		case "coinsPer": {
			let e = o.target === "wonder" ? i.wonders.filter((e) => e.built).length : P(i, o.target);
			i.coins += o.n * e;
			break;
		}
		case "shields": {
			let n = +!!M(i, "strategy");
			r.push(...ce(e, t, o.n + n));
			break;
		}
		case "science":
			r.push(...le(e, t));
			break;
		case "guild": i.coins += o.coinsPer * L(o.target, i, a);
	}
}
function fe(t, n, r, i) {
	let a = V(t, n), o = 1 - n, s = V(t, o);
	for (let c of r.effects) switch (c.kind) {
		case "coins":
			a.coins += c.n;
			break;
		case "opponentCoins": {
			let e = Math.min(s.coins, c.n);
			s.coins -= e;
			break;
		}
		case "shields":
			i.push(...ce(t, n, c.n));
			break;
		case "playAgain":
			t.extraTurn = !0;
			break;
		case "destroy": {
			if (t.phase === "done") break;
			let e = s.cards.filter((e) => v(e).color === c.color);
			e.length === 1 ? (s.cards = s.cards.filter((t) => t !== e[0]), t.discard.push(e[0]), i.push({
				kind: "destroy",
				rid: t.players[o],
				data: { cardId: e[0] }
			})) : e.length > 1 && t.pending.push({
				kind: "destroy",
				who: n,
				color: c.color,
				targets: e
			});
			break;
		}
		case "revive":
			if (t.discard.length === 1) {
				let e = t.discard.pop();
				V(t, n).cards.push(e), i.push({
					kind: "revive",
					rid: t.players[n],
					data: { cardId: e }
				}), de(t, n, v(e), i);
			} else t.discard.length > 1 && t.pending.push({
				kind: "revive",
				who: n
			});
			break;
		case "library": {
			let r = t.tokenBox;
			if (r.length === 0) break;
			let a = [], o = [...r];
			for (; a.length < 3 && o.length > 0;) {
				let n = e(t.seed, t.cursor, o.length);
				t.cursor += 1, a.push(o.splice(n, 1)[0]);
			}
			a.length === 1 ? i.push(...ue(t, n, a[0])) : t.pending.push({
				kind: "library",
				who: n,
				options: a
			});
			break;
		}
	}
}
function pe(e, t) {
	let n = C[e.age], r = n[t];
	return !e.pyramid[t].taken && !n.some((t, n) => t.row === r.row + 1 && Math.abs(t.x - r.x) === 1 && !e.pyramid[n].taken);
}
function me(e) {
	let t = [];
	return e.pyramid.forEach((n, r) => {
		!n.taken && !n.faceUp && pe(e, r) && (n.faceUp = !0, t.push(n.cardId));
	}), t;
}
function he(e) {
	if (e.phase === "done") return [];
	if (e.pyramid.every((e) => e.taken)) {
		if (e.extraTurn = !1, e.age === 3) return e.phase = "done", e.winReason = "civilian", [];
		e.age += 1;
		let t = { v: e.cursor };
		return e.pyramid = se(e.age, e.seed, t), e.cursor = t.v, e.pending = [{
			kind: "ageStart",
			who: e.pawn > 0 ? 1 : e.pawn < 0 ? 0 : e.lastActor
		}], e.phase = "choice", [{
			kind: "age",
			data: { age: e.age }
		}];
	}
	return e.lastActor = e.turn, e.extraTurn || (e.turn = 1 - e.turn), e.extraTurn = !1, [];
}
var H = (e) => ({ code: e });
function ge(e, t, n) {
	if (e.phase === "done") return H("games.duel.errNotYourTurn");
	let r = e.players.indexOf(n.by);
	if (r !== 0 && r !== 1) return H("games.duel.errNotYourTurn");
	let i = r;
	if (t.type === "draft") {
		if (e.phase !== "draft" || !e.draft) return H("games.duel.errBadPhase");
		if (e.draft.turn !== i) return H("games.duel.errNotYourTurn");
		if (!e.draft.pool.includes(t.wonderId)) return H("games.duel.errBadChoice");
		let r = structuredClone(e), a = r.draft;
		a.pool = a.pool.filter((e) => e !== t.wonderId), V(r, i).wonders.push({
			id: t.wonderId,
			built: !1
		});
		let o = [{
			kind: "draft",
			rid: n.by,
			data: {
				wonderId: t.wonderId,
				round: a.round
			}
		}], s = r.firstPlayer, c = a.round === 1 ? [
			s,
			1 - s,
			1 - s,
			s
		] : [
			1 - s,
			s,
			s,
			1 - s
		], l = 4 - a.pool.length;
		if (a.pool.length === 0) {
			if (a.round === 1) a.round = 2, a.pool = a.rest, a.board = [...a.rest], a.turn = 1 - s;
			else {
				r.draft = null;
				let e = { v: r.cursor };
				return r.pyramid = se(1, r.seed, e), r.cursor = e.v, r.turn = r.firstPlayer, r.phase = "age", {
					state: r,
					fx: [...o, {
						kind: "age",
						data: { age: 1 }
					}]
				};
			}
		} else a.turn = c[l];
		return {
			state: r,
			fx: o
		};
	}
	if ([
		"chooseToken",
		"chooseDestroy",
		"chooseRevive",
		"chooseLibrary",
		"chooseStart"
	].includes(t.type)) {
		let r = e.pending[0];
		if (e.phase !== "choice" || !r) return H("games.duel.errBadPhase");
		if (e.players[r.who] !== n.by) return H("games.duel.errNotYourTurn");
		let i = structuredClone(e), a = i.pending.shift(), o = [];
		switch (a.kind) {
			case "token": {
				if (t.type !== "chooseToken" || !i.tokenPool.includes(t.tokenId)) return H("games.duel.errBadChoice");
				let e = t.tokenId;
				i.tokenPool = i.tokenPool.filter((t) => t !== e), o.push(...ue(i, a.who, e));
				break;
			}
			case "destroy": {
				if (t.type !== "chooseDestroy" || !a.targets.includes(t.cardId)) return H("games.duel.errBadChoice");
				let e = t.cardId, n = V(i, 1 - a.who);
				n.cards = n.cards.filter((t) => t !== e), i.discard.push(e), o.push({
					kind: "destroy",
					rid: i.players[1 - a.who],
					data: { cardId: e }
				});
				break;
			}
			case "revive": {
				if (t.type !== "chooseRevive" || !i.discard.includes(t.cardId)) return H("games.duel.errBadChoice");
				let e = t.cardId;
				i.discard = i.discard.filter((t) => t !== e), V(i, a.who).cards.push(e), o.push({
					kind: "revive",
					rid: i.players[a.who],
					data: { cardId: e }
				}), de(i, a.who, v(e), o);
				break;
			}
			case "library": {
				if (t.type !== "chooseLibrary" || !a.options.includes(t.tokenId)) return H("games.duel.errBadChoice");
				let e = t.tokenId;
				i.tokenBox = i.tokenBox.filter((t) => t !== e), o.push(...ue(i, a.who, e));
				break;
			}
			case "ageStart": {
				if (t.type !== "chooseStart") return H("games.duel.errBadChoice");
				let e = i.players.indexOf(t.player);
				if (e !== 0 && e !== 1) return H("games.duel.errBadChoice");
				i.turn = e;
				break;
			}
		}
		return i.phase !== "done" && (i.pending.length > 0 ? i.phase = "choice" : a.kind === "ageStart" ? i.phase = "age" : (i.phase = "age", o.push(...he(i)))), {
			state: i,
			fx: o
		};
	}
	if (t.type === "take") {
		if (e.phase !== "age") return H("games.duel.errBadPhase");
		if (e.turn !== i) return H("games.duel.errNotYourTurn");
		let r = e.pyramid[t.slot];
		if (!r || r.taken || !r.faceUp || !pe(e, t.slot)) return H("games.duel.errBadSlot");
		let a = v(r.cardId), o = V(e, i), s = V(e, 1 - i), c = null, l = !1, u = null;
		if (t.use === "build") {
			if (l = oe(a, o.cards), c = l ? {
				total: 0,
				trade: 0
			} : F(a.cost, o, s, a.color === "blue" ? "blue" : "other"), c.total > o.coins) return H("games.duel.errCantAfford");
		} else if (t.use === "wonder") {
			if (!o.wonders.find((e) => e.id === t.wonderId && !e.built && !e.out) || !t.wonderId || o.wonders.filter((e) => e.built).length + s.wonders.filter((e) => e.built).length >= 7) return H("games.duel.errBadWonder");
			if (u = y(t.wonderId), c = F(u.cost, o, s, "wonder"), c.total > o.coins) return H("games.duel.errCantAfford");
		}
		let d = structuredClone(e), f = V(d, i), p = V(d, 1 - i), m = [{
			kind: "take",
			rid: n.by,
			data: {
				slot: t.slot,
				cardId: a.id,
				use: t.use,
				wonderId: t.wonderId ?? null
			}
		}];
		if (d.pyramid[t.slot].taken = !0, d.lastActor = i, t.use === "sell") {
			let e = 2 + P(f, "yellow");
			f.coins += e, d.discard.push(a.id);
		} else if (t.use === "build") f.coins -= c.total, M(p, "economy") && (p.coins += c.trade), l && M(f, "urbanism") && (f.coins += 4), f.cards.push(a.id), de(d, i, a, m);
		else {
			let e = f.wonders.find((e) => e.id === t.wonderId);
			if (e.built = !0, f.coins -= c.total, M(p, "economy") && (p.coins += c.trade), f.wonders.filter((e) => e.built).length + p.wonders.filter((e) => e.built).length >= 7) for (let e of [...f.wonders, ...p.wonders]) e.built || (e.out = !0);
			m.push({
				kind: "wonder",
				rid: n.by,
				data: { wonderId: u.id }
			}), fe(d, i, u, m);
		}
		let h = me(d);
		return h.length > 0 && m.push({
			kind: "flip",
			data: { cardIds: h }
		}), d.phase !== "done" && (d.pending.length > 0 ? d.phase = "choice" : m.push(...he(d))), {
			state: d,
			fx: m
		};
	}
	return H("games.duel.errBadPhase");
}
function _e(e, t) {
	let n = e.players.indexOf(t), r = n >= 0 ? V(e, n) : null, i = n >= 0 ? V(e, 1 - n) : null, a = e.pyramid.map((t, n) => {
		let a = !t.taken && pe(e, n), o = null;
		if (a && t.faceUp && r && i) {
			let e = v(t.cardId);
			o = oe(e, r.cards) ? {
				total: 0,
				trade: 0,
				viaChain: !0
			} : {
				...F(e.cost, r, i, e.color === "blue" ? "blue" : "other"),
				viaChain: !1
			};
		}
		return {
			slot: n,
			cardId: t.faceUp ? t.cardId : null,
			faceUp: t.faceUp,
			taken: t.taken,
			accessible: a,
			buildPrice: o,
			sellValue: a && t.faceUp && r ? 2 + P(r, "yellow") : null
		};
	}), o = {};
	if (r && i) {
		let e = r.wonders.filter((e) => e.built).length + i.wonders.filter((e) => e.built).length;
		for (let t of r.wonders) t.built || t.out || (o[t.id] = e >= 7 ? null : {
			...F(y(t.id).cost, r, i, "wonder"),
			viaChain: !1
		});
	}
	let s = e.pending[0];
	return {
		public: {
			phase: e.phase,
			age: e.age,
			turn: e.players[e.turn],
			draft: e.draft ? {
				pool: e.draft.pool,
				board: e.draft.board.map((t) => ({
					id: t,
					ownerRid: e.players.find((n) => e.cities[n].wonders.some((e) => e.id === t)) ?? null
				})),
				round: e.draft.round,
				turnRid: e.players[e.draft.turn]
			} : null,
			pyramid: a,
			pawn: e.pawn,
			fines: e.fines,
			tokenPool: e.tokenPool,
			discard: e.discard,
			cities: e.players.map((t) => ({
				rid: t,
				coins: e.cities[t].coins,
				cards: [...e.cities[t].cards],
				wonders: e.cities[t].wonders.map((e) => ({
					id: e.id,
					built: e.built
				})),
				tokens: [...e.cities[t].tokens]
			})),
			pending: s ? {
				kind: s.kind,
				who: e.players[s.who],
				options: s.kind === "token" ? [...e.tokenPool] : s.kind === "destroy" ? [...s.targets] : s.kind === "revive" ? [...e.discard] : s.kind === "library" ? [...s.options] : [...e.players]
			} : null,
			wonderPrices: o,
			winReason: e.winReason
		},
		private: {}
	};
}
function ve(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t, n;
	if (e.winReason === "military" || e.winReason === "science") {
		let r = e.players[e.winner];
		n = [r], t = [r, e.players[1 - e.winner]];
	} else {
		let r = R(e, 0), i = R(e, 1), a = i.total - r.total || i.blueVp - r.blueVp;
		t = a === 0 ? [...e.players] : a > 0 ? [e.players[1], e.players[0]] : [e.players[0], e.players[1]], n = a === 0 ? [...e.players] : [t[0]];
	}
	let r = {};
	for (let t of [0, 1]) r[e.players[t]] = R(e, t).total;
	return {
		phase: "done",
		winner: n,
		ranking: t,
		scores: r
	};
}
var ye = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: T,
	schemas: {
		action: E,
		publicView: ne,
		privateView: A
	},
	setup: B,
	reduce: ge,
	viewFor: _e,
	status: ve
}, be = {
	wood: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("path", { d: "M8 5v22M16 3v26M24 5v22M5 9h22M5 23h22" }), /* @__PURE__ */ c("path", { d: "M11 13h2m6 6h2" })] }),
	clay: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("rect", {
		x: "4",
		y: "5",
		width: "24",
		height: "22",
		rx: "2"
	}), /* @__PURE__ */ c("path", { d: "M4 12h24M4 20h24M12 5v7m8 0v8m-8 0v7" })] }),
	stone: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("path", { d: "M5 11 12 4h11l5 8-3 13-11 3-9-7Z" }), /* @__PURE__ */ c("path", { d: "m5 11 9 5 14-4m-14 4v12m0-12 9-12" })] }),
	glass: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("path", { d: "m16 3 11 13-11 13L5 16Z" }), /* @__PURE__ */ c("path", { d: "m16 7 7 9-7 9-7-9Z" })] }),
	papyrus: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("path", { d: "M8 4h17v22H8a4 4 0 0 1-4-4V8a4 4 0 0 1 4-4Z" }), /* @__PURE__ */ c("path", { d: "M9 4v22M13 10h8M13 15h8M13 20h6" })] })
}, xe = {
	compass: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("circle", {
		cx: "16",
		cy: "16",
		r: "11"
	}), /* @__PURE__ */ c("path", { d: "m20 9-3 8-8 3 3-8Z" })] }),
	wheel: /* @__PURE__ */ l(s, { children: [
		/* @__PURE__ */ c("circle", {
			cx: "16",
			cy: "16",
			r: "11"
		}),
		/* @__PURE__ */ c("circle", {
			cx: "16",
			cy: "16",
			r: "3"
		}),
		/* @__PURE__ */ c("path", { d: "M16 5v8m0 6v8M5 16h8m6 0h8m-18-7 5.5 5.5m3 3L23 23m0-14-5.5 5.5m-3 3L9 23" })
	] }),
	writing: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("path", { d: "M7 25h18M10 20 22 6l4 4-12 14-5 1Z" }), /* @__PURE__ */ c("path", { d: "m18 10 4 4" })] }),
	mortar: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("path", { d: "M5 12h22l-3 9-7 4h-2l-7-4Z" }), /* @__PURE__ */ c("path", { d: "m18 10 6-7m-4 10 5-6" })] }),
	sundial: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("path", { d: "M5 24h22M8 20a8 8 0 0 1 16 0H8Z" }), /* @__PURE__ */ c("path", { d: "m16 20 4-12M16 3v2m-9 4 2 2m16-2-2 2" })] }),
	astrology: /* @__PURE__ */ l(s, { children: [
		/* @__PURE__ */ c("circle", {
			cx: "16",
			cy: "16",
			r: "10"
		}),
		/* @__PURE__ */ c("path", { d: "M16 2v5m0 18v5M2 16h5m18 0h5M10 10l12 12m0-12L10 22" }),
		/* @__PURE__ */ c("circle", {
			cx: "16",
			cy: "16",
			r: "2"
		})
	] }),
	law: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M16 4v22M7 26h18M6 10h20M9 10l-4 9h8Zm14 0-4 9h8Z" }) })
}, Se = {
	horseshoe: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M7 6v13a9 9 0 0 0 18 0V6h-5v13a4 4 0 0 1-8 0V6Z" }) }),
	sword: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "m8 25 14-18 3 3-17 14M5 21l6 6M6 28l3-3" }) }),
	wall: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M4 8h24v18H4ZM4 14h24M4 20h24M12 8v6m8 0v6m-8 0v6" }) }),
	target: /* @__PURE__ */ l(s, { children: [
		/* @__PURE__ */ c("circle", {
			cx: "16",
			cy: "16",
			r: "11"
		}),
		/* @__PURE__ */ c("circle", {
			cx: "16",
			cy: "16",
			r: "6"
		}),
		/* @__PURE__ */ c("circle", {
			cx: "16",
			cy: "16",
			r: "1"
		})
	] }),
	helmet: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("path", { d: "M6 18a10 10 0 0 1 20 0v5H6Z" }), /* @__PURE__ */ c("path", { d: "M16 8v15M6 18h20" })] }),
	book: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M16 8c-4-3-8-3-12-2v19c4-1 8-1 12 2 4-3 8-3 12-2V6c-4-1-8-1-12 2Zm0 0v19" }) }),
	gear: /* @__PURE__ */ l(s, { children: [
		/* @__PURE__ */ c("circle", {
			cx: "16",
			cy: "16",
			r: "7"
		}),
		/* @__PURE__ */ c("circle", {
			cx: "16",
			cy: "16",
			r: "2"
		}),
		/* @__PURE__ */ c("path", { d: "M16 2v6m0 16v6M2 16h6m16 0h6M6 6l4 4m12 12 4 4m0-20-4 4M10 22l-4 4" })
	] }),
	lyre: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M7 6c-2 8 0 15 9 18 9-3 11-10 9-18M7 6l4 3m14-3-4 3M16 24v4m-5-18v11m5-12v15m5-14v11" }) }),
	lamp: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("path", { d: "M6 18h20l-4 7H10Z" }), /* @__PURE__ */ c("path", { d: "M16 18c-5-4-1-7 0-11 4 4 5 7 0 11Z" })] }),
	mask: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("path", { d: "M5 8c7-4 15-4 22 0l-2 12-9 7-9-7Z" }), /* @__PURE__ */ c("path", { d: "M9 14h5m4 0h5m-11 6c3 2 5 2 8 0" })] }),
	moon: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M22 4A12 12 0 1 0 28 23 12 12 0 0 1 22 4Z" }) }),
	drop: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M16 3C12 10 7 16 7 21a9 9 0 0 0 18 0c0-5-5-11-9-18Z" }) }),
	columns: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M4 7h24M6 26h20M8 10v13m6-13v13m6-13v13m6-13v13M4 5h24v4H4Zm2 19h20v3H6Z" }) }),
	sun: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("circle", {
		cx: "16",
		cy: "16",
		r: "6"
	}), /* @__PURE__ */ c("path", { d: "M16 2v5m0 18v5M2 16h5m18 0h5M6 6l4 4m12 12 4 4m0-20-4 4M10 22l-4 4" })] }),
	senate: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("path", { d: "M7 25c-5-8-4-16 1-20m17 20c5-8 4-16-1-20M8 8l5 3m-7 4 6 2m-4 4 5 1m11-14-5 3m7 4-6 2m4 4-5 1" }), /* @__PURE__ */ c("path", { d: "M13 25h6" })] }),
	amphora: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M11 5h10M13 5v5C9 13 9 22 16 27c7-5 7-14 3-17V5M11 11c-6-2-7 7-2 8m12-8c6-2 7 7 2 8" }) }),
	barrel: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M9 4h14c-3 7-3 17 0 24H9c3-7 3-17 0-24ZM7 9h18M7 23h18" }) })
}, Ce = {
	"appian-way": /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M3 27 12 5h8l9 22M9 16h14M6 23h20M16 6v20" }) }),
	"circus-maximus": /* @__PURE__ */ l(s, { children: [
		/* @__PURE__ */ c("ellipse", {
			cx: "16",
			cy: "16",
			rx: "12",
			ry: "8"
		}),
		/* @__PURE__ */ c("ellipse", {
			cx: "16",
			cy: "16",
			rx: "7",
			ry: "3"
		}),
		/* @__PURE__ */ c("path", { d: "M16 8v16" })
	] }),
	colossus: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M10 27 12 7h8l2 20M8 27h16M9 13h14M6 6l6 4m14-4-6 4" }) }),
	"great-library": /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("path", { d: "M5 6h6v20H5Zm8-2h6v22h-6Zm8 4h6v18h-6ZM4 28h24" }), /* @__PURE__ */ c("path", { d: "M7 10h2m6 0h2m6 2h2" })] }),
	"great-lighthouse": /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M11 27 13 8h6l2 19M8 27h16M10 12h12M16 2v5M5 6l4 3m18-3-4 3" }) }),
	"hanging-gardens": /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("path", { d: "M4 27h24M7 20h18v7H7Zm3-7h12v7H10Zm3-7h6v7h-6Z" }), /* @__PURE__ */ c("path", { d: "m16 3-3 4m3-4 3 4" })] }),
	mausoleum: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M5 27h22M8 23h16v4H8Zm3-12h10v12H11ZM7 11l9-7 9 7Z" }) }),
	piraeus: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("path", { d: "M4 21c4-2 8-2 12 0s8 2 12 0M4 26c4-2 8-2 12 0s8 2 12 0M8 16h16l-3 5H11Z" }), /* @__PURE__ */ c("path", { d: "M16 4v12m0-11 7 9h-7" })] }),
	pyramids: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("path", { d: "M3 27 12 6l9 21Zm11 0 7-15 8 15Z" }), /* @__PURE__ */ c("path", { d: "M8 18h8m4 2h5" })] }),
	sphinx: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("path", { d: "M4 25h24M7 22l7-11 5 7 6-4 3 8Z" }), /* @__PURE__ */ c("circle", {
		cx: "16",
		cy: "7",
		r: "3"
	})] }),
	"statue-of-zeus": /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("path", { d: "m18 2-9 15h7l-2 13 9-16h-7Z" }), /* @__PURE__ */ c("path", { d: "M4 27h6m12 0h6" })] }),
	"temple-of-artemis": /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M7 26V12l9-7 9 7v14M4 26h24M12 14a6 6 0 0 0 8 0M16 14v8" }) })
}, we = {
	agriculture: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M16 28V6m0 8C8 7 6 10 12 17m4 4c8-7 10-4 4 3M9 26h14" }) }),
	architecture: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("path", { d: "M4 26 16 4l12 22Z" }), /* @__PURE__ */ c("path", { d: "M16 4v22M9 18h14" })] }),
	economy: /* @__PURE__ */ l(s, { children: [
		/* @__PURE__ */ c("circle", {
			cx: "11",
			cy: "16",
			r: "7"
		}),
		/* @__PURE__ */ c("circle", {
			cx: "21",
			cy: "16",
			r: "7"
		}),
		/* @__PURE__ */ c("path", { d: "M8 16h6m4 0h6" })
	] }),
	law: xe.law,
	masonry: Se.wall,
	mathematics: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M5 9h9m-4-4v9m8-7 9 9m0-9-9 9M5 23h9m6 0h7" }) }),
	philosophy: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("circle", {
		cx: "16",
		cy: "16",
		r: "11"
	}), /* @__PURE__ */ c("path", { d: "M10 13c1-5 9-5 10 0 1 3-4 4-4 7m0 3v1" })] }),
	strategy: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("path", { d: "M5 5h22v22H5Z M12 5v22M20 5v22M5 12h22M5 20h22" }), /* @__PURE__ */ c("path", { d: "M6 6h5v5H6Zm14 14h6v6h-6Z" })] }),
	theology: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M8 26V14a8 8 0 0 1 16 0v12M5 26h22M16 3v5m-4-1h8" }) }),
	urbanism: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M4 27V12h8v15m2 0V5h8v22m2 0V15h4v12M3 27h26M7 16h2m-2 5h2m10-12h2m-2 6h2m-2 6h2" }) })
}, Te = {
	coin: /* @__PURE__ */ l(s, { children: [
		/* @__PURE__ */ c("circle", {
			cx: "16",
			cy: "16",
			r: "12"
		}),
		/* @__PURE__ */ c("circle", {
			cx: "16",
			cy: "16",
			r: "8"
		}),
		/* @__PURE__ */ c("path", { d: "M12 16h8m-4-4v8" })
	] }),
	shield: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("path", { d: "M16 3 27 8v8c0 7-5 11-11 14C10 27 5 23 5 16V8Z" }), /* @__PURE__ */ c("path", { d: "M16 9v14m-6-7h12" })] }),
	vp: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "m16 3 4 9 10 1-7 7 2 10-9-5-9 5 2-10-7-7 10-1Z" }) }),
	turn: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M25 11a10 10 0 1 0 1 10M25 5v7h-7" }) }),
	destroy: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M5 24h22M9 21 14 7l5 10 4-5 2 9M7 8l4 4m10 8 4 4" }) }),
	revive: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M6 18a10 10 0 0 1 18-7M24 14A10 10 0 0 1 6 21M6 11V5h6m12 16v6h-6" }) }),
	library: Se.book,
	opponent: /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("circle", {
		cx: "16",
		cy: "9",
		r: "5"
	}), /* @__PURE__ */ c("path", { d: "M6 28c0-7 4-11 10-11s10 4 10 11" })] }),
	trade: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M4 10h23m-5-5 5 5-5 5M28 22H5m5-5-5 5 5 5" }) }),
	capital: /* @__PURE__ */ c(s, { children: /* @__PURE__ */ c("path", { d: "M5 27V10h5V6h4v4h4V6h4v4h5v17ZM3 27h26M13 27v-8h6v8" }) })
};
function Ee(e, t) {
	return e === "resource" ? be[t] : e === "science" ? xe[t] : e === "chain" ? Se[t] : e === "wonder" ? Ce[t ?? ""] ?? Ce.pyramids : e === "token" ? we[t ?? ""] ?? we.philosophy : Te[e];
}
function U({ kind: e, id: t, className: n = "" }) {
	return /* @__PURE__ */ c("svg", {
		className: `duel-symbol duel-symbol-${e} ${n}`,
		"data-id": t,
		viewBox: "0 0 32 32",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": "true",
		children: Ee(e, t)
	});
}
//#endregion
//#region src/games/duel/card.tsx
var De = {
	brown: "duel-card-brown",
	gray: "duel-card-gray",
	blue: "duel-card-blue",
	green: "duel-card-green",
	yellow: "duel-card-yellow",
	red: "duel-card-red",
	purple: "duel-card-purple"
}, W = {
	clay: "games.duel.resource.clay",
	wood: "games.duel.resource.wood",
	stone: "games.duel.resource.stone",
	glass: "games.duel.resource.glass",
	papyrus: "games.duel.resource.papyrus"
}, Oe = {
	compass: "games.duel.science.compass",
	wheel: "games.duel.science.wheel",
	writing: "games.duel.science.writing",
	mortar: "games.duel.science.mortar",
	sundial: "games.duel.science.sundial",
	astrology: "games.duel.science.astrology",
	law: "games.duel.science.law"
}, ke = {
	brown: "games.duel.target.brown",
	gray: "games.duel.target.gray",
	yellow: "games.duel.target.yellow",
	blue: "games.duel.target.blue",
	green: "games.duel.target.green",
	red: "games.duel.target.red",
	brownGray: "games.duel.target.brownGray",
	wonder: "games.duel.target.wonder",
	coins: "games.duel.target.coins"
}, Ae = {
	agriculture: "games.duel.tokenInfo.agriculture",
	architecture: "games.duel.tokenInfo.architecture",
	economy: "games.duel.tokenInfo.economy",
	law: "games.duel.tokenInfo.law",
	masonry: "games.duel.tokenInfo.masonry",
	mathematics: "games.duel.tokenInfo.mathematics",
	philosophy: "games.duel.tokenInfo.philosophy",
	strategy: "games.duel.tokenInfo.strategy",
	theology: "games.duel.tokenInfo.theology",
	urbanism: "games.duel.tokenInfo.urbanism"
}, G = (e) => `games.duel.card.${e}`, K = (e) => `games.duel.wonder.${e}`, q = (e) => `games.duel.token.${e}`, je = (e) => De[e];
function J({ kind: e, id: t, n, prefix: r, title: i }) {
	return /* @__PURE__ */ l("span", {
		className: "duel-mark",
		title: i,
		children: [
			r && /* @__PURE__ */ c("span", { children: r }),
			/* @__PURE__ */ c(U, {
				kind: e,
				id: t
			}),
			n !== void 0 && /* @__PURE__ */ c("span", {
				className: "duel-mark-number",
				children: n
			})
		]
	});
}
function Y({ n: e, prefix: t }) {
	return /* @__PURE__ */ c(J, {
		kind: "coin",
		n: e,
		prefix: t
	});
}
function Me({ cost: e }) {
	let t = r(), n = Object.entries(e.resources ?? {});
	return !e.coins && n.length === 0 ? /* @__PURE__ */ c("span", {
		className: "duel-mark-free",
		children: t("games.duel.noCost")
	}) : /* @__PURE__ */ l("span", {
		className: "duel-mark-line",
		children: [!!e.coins && /* @__PURE__ */ c(J, {
			kind: "coin",
			n: e.coins
		}), n.map(([e, n]) => /* @__PURE__ */ c(J, {
			kind: "resource",
			id: e,
			n: n > 1 ? n : void 0,
			title: t(W[e])
		}, e))]
	});
}
function X({ cost: e }) {
	let t = r(), n = Object.entries(e.resources ?? {});
	return n.length === 0 ? null : /* @__PURE__ */ c("span", {
		className: "duel-cost-details",
		children: t("games.duel.costResources", { items: n.map(([e, n]) => `${t(W[e])}${n > 1 ? ` ×${n}` : ""}`).join(" · ") })
	});
}
function Ne({ target: e }) {
	return e === "wonder" ? /* @__PURE__ */ c(U, {
		kind: "wonder",
		id: "pyramids"
	}) : e === "coins" ? /* @__PURE__ */ c(U, { kind: "coin" }) : e === "brownGray" ? /* @__PURE__ */ l("span", {
		className: "duel-target-pair",
		children: [/* @__PURE__ */ c("span", { className: "duel-target-color duel-card-brown" }), /* @__PURE__ */ c("span", { className: "duel-target-color duel-card-gray" })]
	}) : /* @__PURE__ */ c("span", { className: `duel-target-color ${De[e]}` });
}
function Pe({ effect: e }) {
	let t = r();
	switch (e.kind) {
		case "produce": return /* @__PURE__ */ c(s, { children: Object.entries(e.resources).map(([e, n]) => /* @__PURE__ */ c(J, {
			kind: "resource",
			id: e,
			n: n > 1 ? n : void 0,
			title: t(W[e])
		}, e)) });
		case "produceChoice": return /* @__PURE__ */ l("span", {
			className: "duel-mark",
			children: [/* @__PURE__ */ c("span", {
				className: "duel-mark-choices",
				children: e.options.map((e) => /* @__PURE__ */ c(U, {
					kind: "resource",
					id: e
				}, e))
			}), /* @__PURE__ */ c("span", {
				className: "duel-mark-number",
				children: "1"
			})]
		});
		case "tradeOne": return /* @__PURE__ */ l("span", {
			className: "duel-mark",
			children: [
				/* @__PURE__ */ c(U, { kind: "trade" }),
				/* @__PURE__ */ c("span", {
					className: "duel-mark-number",
					children: "1"
				}),
				/* @__PURE__ */ c("span", {
					className: "duel-mark-choices",
					children: e.resources.map((e) => /* @__PURE__ */ c(U, {
						kind: "resource",
						id: e
					}, e))
				})
			]
		});
		case "coins": return /* @__PURE__ */ c(J, {
			kind: "coin",
			n: e.n,
			prefix: "+"
		});
		case "coinsPer": return /* @__PURE__ */ l("span", {
			className: "duel-mark",
			children: [
				/* @__PURE__ */ c(U, { kind: "coin" }),
				/* @__PURE__ */ l("span", {
					className: "duel-mark-number",
					children: [
						"+",
						e.n,
						"/"
					]
				}),
				/* @__PURE__ */ c(Ne, { target: e.target })
			]
		});
		case "vp": return /* @__PURE__ */ c(J, {
			kind: "vp",
			n: e.n
		});
		case "shields": return /* @__PURE__ */ c(J, {
			kind: "shield",
			n: e.n
		});
		case "science": return /* @__PURE__ */ c(J, {
			kind: "science",
			id: e.symbol,
			title: t(Oe[e.symbol])
		});
		case "guild": return /* @__PURE__ */ l("span", {
			className: "duel-mark",
			children: [
				/* @__PURE__ */ c(Ne, { target: e.target }),
				/* @__PURE__ */ c("span", {
					className: "duel-mark-number",
					children: "×"
				}),
				e.coinsPer > 0 && /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c(U, { kind: "coin" }), /* @__PURE__ */ c("span", {
					className: "duel-mark-number",
					children: e.coinsPer
				})] }),
				/* @__PURE__ */ c(U, { kind: "vp" }),
				/* @__PURE__ */ c("span", {
					className: "duel-mark-number",
					children: e.vpPer
				})
			]
		});
	}
}
function Fe({ def: e }) {
	return /* @__PURE__ */ c("span", {
		className: "duel-mark-line",
		children: e.effects.map((e, t) => /* @__PURE__ */ c(Pe, { effect: e }, t))
	});
}
function Ie({ effect: e }) {
	let t = r(), n = (e) => e.map((e) => t(W[e])).join(" / "), i;
	switch (e.kind) {
		case "produce":
			i = t("games.duel.effectText.produce", { items: Object.entries(e.resources).map(([e, n]) => `${t(W[e])}${n > 1 ? ` ×${n}` : ""}`).join(" · ") });
			break;
		case "produceChoice":
			i = t("games.duel.effectText.produceChoice", { items: n(e.options) });
			break;
		case "tradeOne":
			i = t("games.duel.effectText.tradeOne", { items: n(e.resources) });
			break;
		case "coins":
			i = t("games.duel.effectText.coins", { n: e.n });
			break;
		case "coinsPer":
			i = t("games.duel.effectText.coinsPer", {
				n: e.n,
				target: t(ke[e.target])
			});
			break;
		case "vp":
			i = t("games.duel.effectText.vp", { n: e.n });
			break;
		case "shields":
			i = t("games.duel.effectText.shields", { n: e.n });
			break;
		case "science":
			i = t("games.duel.effectText.science", { symbol: t(Oe[e.symbol]) });
			break;
		case "guild": i = e.coinsPer > 0 ? t("games.duel.effectText.guild", {
			target: t(ke[e.target]),
			vp: e.vpPer,
			coins: e.coinsPer
		}) : t("games.duel.effectText.guildVp", {
			target: t(ke[e.target]),
			vp: e.vpPer
		});
	}
	return /* @__PURE__ */ c("li", { children: i });
}
function Le({ def: e }) {
	return /* @__PURE__ */ c("ul", {
		className: "duel-effect-details",
		children: e.effects.map((e, t) => /* @__PURE__ */ c(Ie, { effect: e }, t))
	});
}
function Re({ effect: e }) {
	switch (e.kind) {
		case "vp": return /* @__PURE__ */ c(J, {
			kind: "vp",
			n: e.n
		});
		case "coins": return /* @__PURE__ */ c(J, {
			kind: "coin",
			n: e.n,
			prefix: "+"
		});
		case "opponentCoins": return /* @__PURE__ */ l("span", {
			className: "duel-mark",
			children: [
				/* @__PURE__ */ c(U, { kind: "opponent" }),
				/* @__PURE__ */ c("span", { children: "−" }),
				/* @__PURE__ */ c(U, { kind: "coin" }),
				/* @__PURE__ */ c("span", {
					className: "duel-mark-number",
					children: e.n
				})
			]
		});
		case "shields": return /* @__PURE__ */ c(J, {
			kind: "shield",
			n: e.n
		});
		case "playAgain": return /* @__PURE__ */ c(J, { kind: "turn" });
		case "produceChoice": return /* @__PURE__ */ l("span", {
			className: "duel-mark",
			children: [/* @__PURE__ */ c("span", {
				className: "duel-mark-choices",
				children: e.options.map((e) => /* @__PURE__ */ c(U, {
					kind: "resource",
					id: e
				}, e))
			}), /* @__PURE__ */ c("span", {
				className: "duel-mark-number",
				children: "1"
			})]
		});
		case "destroy": return /* @__PURE__ */ l("span", {
			className: "duel-mark",
			children: [/* @__PURE__ */ c(U, { kind: "destroy" }), /* @__PURE__ */ c(Ne, { target: e.color })]
		});
		case "revive": return /* @__PURE__ */ c(J, { kind: "revive" });
		case "library": return /* @__PURE__ */ c(J, { kind: "library" });
	}
}
function ze({ id: e }) {
	return /* @__PURE__ */ c("span", {
		className: "duel-mark-line",
		children: y(e).effects.map((e, t) => /* @__PURE__ */ c(Re, { effect: e }, t))
	});
}
function Be({ effect: e }) {
	let t = r(), n;
	switch (e.kind) {
		case "vp":
			n = t("games.duel.effectText.vp", { n: e.n });
			break;
		case "coins":
			n = t("games.duel.effectText.coins", { n: e.n });
			break;
		case "opponentCoins":
			n = t("games.duel.effectText.opponentCoins", { n: e.n });
			break;
		case "shields":
			n = t("games.duel.effectText.shields", { n: e.n });
			break;
		case "playAgain":
			n = t("games.duel.effectText.playAgain");
			break;
		case "produceChoice":
			n = t("games.duel.effectText.produceChoice", { items: e.options.map((e) => t(W[e])).join(" / ") });
			break;
		case "destroy":
			n = t("games.duel.effectText.destroy", { target: t(ke[e.color]) });
			break;
		case "revive":
			n = t("games.duel.effectText.revive");
			break;
		case "library": n = t("games.duel.effectText.library");
	}
	return /* @__PURE__ */ c("li", { children: n });
}
function Ve({ id: e }) {
	return /* @__PURE__ */ c("ul", {
		className: "duel-effect-details",
		children: y(e).effects.map((e, t) => /* @__PURE__ */ c(Be, { effect: e }, t))
	});
}
function He({ id: e }) {
	let t = r();
	return /* @__PURE__ */ c("span", {
		className: "duel-science-mark",
		title: t(Oe[e]),
		children: /* @__PURE__ */ c(U, {
			kind: "science",
			id: e
		})
	});
}
function Z({ id: e, large: t = !1 }) {
	let n = r(), i = v(e);
	return /* @__PURE__ */ l("div", {
		className: `duel-card ${De[i.color]} ${t ? "duel-card-large" : ""}`,
		children: [
			/* @__PURE__ */ c("div", {
				className: "duel-card-effect",
				children: /* @__PURE__ */ c(Fe, { def: i })
			}),
			/* @__PURE__ */ c("div", {
				className: "duel-card-cost",
				children: /* @__PURE__ */ c(Me, { cost: i.cost })
			}),
			/* @__PURE__ */ l("div", {
				className: "duel-card-art",
				"aria-hidden": !0,
				children: [/* @__PURE__ */ c(U, {
					kind: i.color === "green" ? "science" : i.color === "red" ? "shield" : i.color === "blue" ? "vp" : i.color === "yellow" ? "trade" : i.color === "purple" ? "library" : "resource",
					id: i.color === "green" ? i.effects.find((e) => e.kind === "science")?.symbol : i.color === "brown" ? "wood" : "stone"
				}), /* @__PURE__ */ c("span", {
					className: "duel-card-art-age",
					children: Ue[i.age - 1]
				})]
			}),
			/* @__PURE__ */ c("div", {
				className: "duel-card-name",
				title: n(G(e)),
				children: n(G(e))
			}),
			(i.chainFrom || i.chainTo) && /* @__PURE__ */ l("div", {
				className: "duel-card-chain",
				children: [i.chainFrom && /* @__PURE__ */ c("span", {
					title: n("games.duel.chainFrom"),
					children: /* @__PURE__ */ c(U, {
						kind: "chain",
						id: i.chainFrom
					})
				}), i.chainTo && /* @__PURE__ */ c("span", {
					title: n("games.duel.chainTo"),
					children: /* @__PURE__ */ c(U, {
						kind: "chain",
						id: i.chainTo
					})
				})]
			})
		]
	});
}
var Ue = [
	"I",
	"II",
	"III"
];
function We({ age: e }) {
	return /* @__PURE__ */ c("div", {
		className: "duel-card-back",
		"aria-hidden": !0,
		children: /* @__PURE__ */ l("div", {
			className: "duel-card-back-inner",
			children: [
				/* @__PURE__ */ c(U, { kind: "vp" }),
				/* @__PURE__ */ c("strong", { children: Ue[e - 1] }),
				/* @__PURE__ */ c(U, { kind: "vp" })
			]
		})
	});
}
function Q({ id: e, large: t = !1, built: n = !1, out: i = !1 }) {
	let a = r(), o = y(e);
	return /* @__PURE__ */ l("div", {
		className: `duel-wonder ${t ? "duel-wonder-large" : ""} ${i ? "duel-wonder-out" : ""} ${n ? "duel-wonder-built" : ""}`,
		children: [
			/* @__PURE__ */ c("span", {
				className: "duel-wonder-emblem",
				children: /* @__PURE__ */ c(U, {
					kind: "wonder",
					id: e
				})
			}),
			/* @__PURE__ */ l("span", {
				className: "duel-wonder-body",
				children: [
					/* @__PURE__ */ c("strong", {
						className: "duel-wonder-name",
						children: a(K(e))
					}),
					/* @__PURE__ */ c("span", {
						className: "duel-wonder-effects",
						children: /* @__PURE__ */ c(ze, { id: e })
					}),
					/* @__PURE__ */ c("span", {
						className: "duel-wonder-cost",
						children: /* @__PURE__ */ c(Me, { cost: o.cost })
					})
				]
			}),
			n && /* @__PURE__ */ c("span", {
				className: "duel-wonder-status",
				"aria-label": a("games.duel.built"),
				children: "✓"
			})
		]
	});
}
function $({ id: e, size: t = 34 }) {
	return /* @__PURE__ */ c("span", {
		className: "duel-token grid flex-none place-items-center rounded-full border-2 border-ink bg-teal-200",
		style: {
			width: t,
			height: t,
			fontSize: t * .62
		},
		"aria-hidden": !0,
		children: /* @__PURE__ */ c(U, {
			kind: "token",
			id: e
		})
	});
}
//#endregion
//#region src/games/duel/view-player.tsx
var Ge = [
	"I",
	"II",
	"III"
], Ke = [
	"brown",
	"gray",
	"blue",
	"green",
	"yellow",
	"red",
	"purple"
], qe = {
	brown: "◆",
	gray: "◈",
	blue: "●",
	green: "✦",
	yellow: "⬡",
	red: "▲",
	purple: "✶"
}, Je = {
	brown: "games.duel.cardColor.brown",
	gray: "games.duel.cardColor.gray",
	blue: "games.duel.cardColor.blue",
	green: "games.duel.cardColor.green",
	yellow: "games.duel.cardColor.yellow",
	red: "games.duel.cardColor.red",
	purple: "games.duel.cardColor.purple"
}, Ye = {
	token: "games.duel.pickToken",
	destroy: "games.duel.pickDestroy",
	revive: "games.duel.pickRevive",
	library: "games.duel.pickLibrary",
	ageStart: "games.duel.pickStart"
}, Xe = {
	military: "games.duel.winMilitary",
	science: "games.duel.winScience",
	civilian: "games.duel.winCivilian"
};
function Ze(e) {
	let t = e.public;
	return /* @__PURE__ */ c(Qe, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Qe({ pub: e, members: t, myRid: u, send: d }) {
	let f = r(), p = (e) => t.find((t) => t.rid === e)?.name ?? e, m = e.cities.find((e) => e.rid === u), h = e.cities.find((e) => e.rid !== u), g = e.phase === "age" && e.turn === u, _ = e.phase === "draft" && e.draft?.turnRid === u, ee = e.phase === "choice" && e.pending?.who === u, [b, x] = n(null), [S, C] = n(!1), [w, E] = n(null), [D, O] = n(null), [k, te] = n(null), [ne, A] = n(null), j = `${e.phase}|${e.turn}|${e.age}|${e.pyramid.map((e) => +!!e.taken).join("")}|${e.pending?.kind ?? ""}|${e.pending?.options.join(",") ?? ""}`, [re, ie] = n(j);
	re !== j && (ie(j), x(null), C(!1), E(null), O(null), te(null), A(null));
	let M = b === null ? null : e.pyramid[b], N = M?.cardId ? v(M.cardId) : null, ae = m?.wonders.filter((e) => !e.built) ?? [], P = w ? e.wonderPrices[w] : null, F = !!(m && P && P.total <= m.coins), oe = !!(D && e.draft?.pool.includes(D)), I = "info", L = "", R;
	e.phase === "draft" && e.draft ? (R = f("games.duel.draftRound", { n: e.draft.round }), _ ? (I = "accent", L = f("games.duel.draftPick")) : L = f("games.duel.draftWait", { name: p(e.draft.turnRid) })) : e.phase === "choice" && e.pending ? (R = f("games.duel.ageChip", { n: Ge[e.age - 1] }), ee ? (I = "accent", L = f(Ye[e.pending.kind])) : L = f("games.duel.waitChoice", { name: p(e.pending.who) })) : e.phase === "age" ? (R = f("games.duel.ageChip", { n: Ge[e.age - 1] }), g ? (I = "accent", L = f("games.duel.turnYou")) : L = f("games.duel.turnWait", { name: p(e.turn) })) : e.phase === "done" && (L = e.winReason ? f(Xe[e.winReason]) : "");
	let z = (e) => {
		A(null), x(b === e ? null : e), C(!1), E(null);
	}, se = /* @__PURE__ */ c("div", {
		className: "duel-action-slot",
		children: e.phase === "draft" && _ ? /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("span", {
			className: "duel-action-hint",
			children: f(D ? K(D) : "games.duel.chooseToInspect")
		}), /* @__PURE__ */ c("button", {
			type: "button",
			disabled: !oe,
			className: "btn-base min-h-12 px-3 text-sm text-white disabled:opacity-40",
			style: { background: T.accent },
			onClick: () => {
				oe && D && d({
					type: "draft",
					wonderId: D
				}), O(null);
			},
			children: f("games.duel.confirm")
		})] }) : ee && e.pending ? /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("span", {
			className: "duel-action-hint",
			children: k ? $e(e.pending.kind, k, p, f) : f("games.duel.chooseToInspect")
		}), /* @__PURE__ */ c("button", {
			type: "button",
			disabled: !k,
			className: "btn-base min-h-12 px-3 text-sm text-white disabled:opacity-40",
			style: { background: T.accent },
			onClick: () => {
				if (e.pending && k) {
					switch (e.pending.kind) {
						case "token":
							d({
								type: "chooseToken",
								tokenId: k
							});
							break;
						case "library":
							d({
								type: "chooseLibrary",
								tokenId: k
							});
							break;
						case "destroy":
							d({
								type: "chooseDestroy",
								cardId: k
							});
							break;
						case "revive":
							d({
								type: "chooseRevive",
								cardId: k
							});
							break;
						case "ageStart": d({
							type: "chooseStart",
							player: k
						});
					}
					te(null);
				}
			},
			children: f("games.duel.confirmChoice")
		})] }) : g && M && N && S ? /* @__PURE__ */ l(s, { children: [
			/* @__PURE__ */ c("button", {
				type: "button",
				className: "btn-quiet min-h-12 px-3 text-sm",
				onClick: () => {
					C(!1), E(null);
				},
				children: f("games.duel.cancel")
			}),
			/* @__PURE__ */ c("span", {
				className: "duel-action-hint",
				children: f(w ? K(w) : "games.duel.chooseWonder")
			}),
			/* @__PURE__ */ c("button", {
				type: "button",
				disabled: !F,
				className: "btn-base min-h-12 px-3 text-sm text-white disabled:opacity-40",
				style: { background: T.accent },
				onClick: () => {
					w && d({
						type: "take",
						slot: M.slot,
						use: "wonder",
						wonderId: w
					}), x(null), C(!1), E(null);
				},
				children: f("games.duel.buildThisWonder")
			})
		] }) : g && M && N ? /* @__PURE__ */ l(s, { children: [
			/* @__PURE__ */ c("button", {
				type: "button",
				className: "btn-quiet min-h-12 px-1 text-xs",
				onClick: () => x(null),
				children: f("games.duel.cancel")
			}),
			/* @__PURE__ */ c("button", {
				type: "button",
				className: "btn-quiet min-h-12 px-1 text-xs",
				onClick: () => {
					d({
						type: "take",
						slot: M.slot,
						use: "sell"
					}), x(null);
				},
				children: f("games.duel.sell", { n: M.sellValue ?? 2 })
			}),
			/* @__PURE__ */ c("button", {
				type: "button",
				disabled: ae.length === 0,
				className: "btn-quiet min-h-12 px-1 text-xs disabled:opacity-40",
				onClick: () => C(!0),
				children: f("games.duel.buildWonder")
			}),
			/* @__PURE__ */ c("button", {
				type: "button",
				disabled: !M.buildPrice || !m || M.buildPrice.total > m.coins,
				className: "btn-base min-h-12 px-1 text-xs text-white disabled:opacity-40",
				style: { background: T.accent },
				onClick: () => {
					d({
						type: "take",
						slot: M.slot,
						use: "build"
					}), x(null);
				},
				children: M.buildPrice?.viaChain ? f("games.duel.free") : f("games.duel.build")
			})
		] }) : /* @__PURE__ */ c("span", {
			className: "duel-action-hint px-2",
			children: g ? f("games.duel.chooseCard") : L
		})
	}), B = null;
	return ne ? B = /* @__PURE__ */ c(st, {
		inspect: ne,
		onInspect: A,
		onClose: () => A(null)
	}) : ee && e.pending ? B = /* @__PURE__ */ c(ct, {
		pending: e.pending,
		sel: k,
		nameOf: p,
		onSel: te
	}) : S && M && m ? B = /* @__PURE__ */ c(nt, {
		ids: ae.map((e) => e.id),
		sel: w,
		prices: e.wonderPrices,
		coins: m.coins,
		onSel: E
	}) : g && M && N && m ? B = /* @__PURE__ */ c(tt, {
		id: N.id,
		price: M.buildPrice,
		sellValue: M.sellValue ?? 2,
		coins: m.coins
	}) : e.phase === "draft" && D && (B = /* @__PURE__ */ l("div", {
		className: "pointer-events-auto duel-sheet duel-draft-focus",
		children: [
			/* @__PURE__ */ c(Q, {
				id: D,
				large: !0
			}),
			/* @__PURE__ */ c(Ve, { id: D }),
			/* @__PURE__ */ c(X, { cost: y(D).cost })
		]
	})), /* @__PURE__ */ c(a, {
		adaptive: !0,
		className: "duel-game-screen",
		scroll: !1,
		banner: /* @__PURE__ */ c(o, {
			tone: I,
			text: L,
			chip: R,
			accent: T.accent
		}),
		actions: se,
		actionsHeight: "duel-actions-height",
		overlay: B,
		children: /* @__PURE__ */ l("div", {
			className: "duel-table",
			children: [/* @__PURE__ */ c(i, {
				kind: "hatch",
				base: "var(--color-paper)",
				line: "var(--color-amber-100)",
				className: "pointer-events-none absolute inset-0 rounded-[inherit]"
			}), /* @__PURE__ */ l("div", {
				className: "duel-table-inner",
				children: [
					h && /* @__PURE__ */ c(at, {
						city: h,
						name: p(h.rid),
						isMe: !1,
						onInspect: A
					}),
					/* @__PURE__ */ l("div", {
						className: "duel-center",
						children: [/* @__PURE__ */ l("div", {
							className: "duel-commons",
							children: [/* @__PURE__ */ c(rt, {
								pawn: e.pawn,
								fines: e.fines,
								leftName: p(e.cities[1]?.rid ?? ""),
								rightName: p(e.cities[0]?.rid ?? "")
							}), /* @__PURE__ */ c("div", {
								className: "duel-token-pool",
								"aria-label": f("games.duel.progressTokens"),
								children: e.tokenPool.map((e) => /* @__PURE__ */ c($, {
									id: e,
									size: 23
								}, e))
							})]
						}), /* @__PURE__ */ c("div", {
							className: "duel-stage",
							children: e.phase === "draft" && e.draft ? /* @__PURE__ */ c(ot, {
								board: e.draft.board,
								myTurn: _,
								myRid: u,
								nameOf: p,
								sel: D,
								onSel: O
							}) : /* @__PURE__ */ c(it, {
								pub: e,
								myTurn: g,
								sel: b,
								onSel: z,
								onInspect: (e) => A({
									kind: "card",
									id: e
								})
							})
						})]
					}),
					m && /* @__PURE__ */ c(at, {
						city: m,
						name: p(m.rid),
						isMe: !0,
						onInspect: A
					})
				]
			})]
		})
	});
}
function $e(e, t, n, r) {
	return e === "ageStart" ? n(t) : r(e === "token" || e === "library" ? q(t) : G(t));
}
function et({ printed: e, price: t, coins: n }) {
	let i = r();
	return t ? t.viaChain ? /* @__PURE__ */ c("div", {
		className: "duel-price-free",
		children: i("games.duel.viaChain")
	}) : /* @__PURE__ */ l("div", {
		className: "duel-price-breakdown",
		children: [
			/* @__PURE__ */ l("span", { children: [
				i("games.duel.priceBase"),
				" ",
				/* @__PURE__ */ c(Y, { n: e })
			] }),
			/* @__PURE__ */ l("span", { children: [
				i("games.duel.priceTrade"),
				" ",
				/* @__PURE__ */ c(Y, { n: t.trade })
			] }),
			/* @__PURE__ */ l("strong", { children: [
				i("games.duel.priceTotal"),
				" ",
				/* @__PURE__ */ c(Y, { n: t.total })
			] }),
			/* @__PURE__ */ l("span", { children: [
				i("games.duel.priceHave"),
				" ",
				/* @__PURE__ */ c(Y, { n })
			] }),
			t.total > n && /* @__PURE__ */ c("b", {
				className: "duel-price-short",
				children: i("games.duel.priceShort", { n: t.total - n })
			})
		]
	}) : /* @__PURE__ */ c("div", {
		className: "duel-price-unavailable",
		children: i("games.duel.priceLimit")
	});
}
function tt({ id: e, price: t, sellValue: n, coins: i }) {
	let a = r(), o = v(e);
	return /* @__PURE__ */ c("div", {
		className: "pointer-events-auto duel-sheet",
		children: /* @__PURE__ */ l("div", {
			className: "duel-preview",
			children: [/* @__PURE__ */ c(Z, {
				id: e,
				large: !0
			}), /* @__PURE__ */ l("div", {
				className: "duel-preview-info",
				children: [
					/* @__PURE__ */ c("strong", { children: a(G(e)) }),
					/* @__PURE__ */ c(Le, { def: o }),
					/* @__PURE__ */ c(et, {
						printed: o.cost.coins ?? 0,
						price: t,
						coins: i
					}),
					/* @__PURE__ */ c("span", { children: a("games.duel.sell", { n }) })
				]
			})]
		})
	});
}
function nt({ ids: e, sel: t, prices: n, coins: i, onSel: a }) {
	let o = r(), s = t ? n[t] : null;
	return /* @__PURE__ */ l("div", {
		className: "pointer-events-auto duel-sheet",
		children: [
			/* @__PURE__ */ c("strong", {
				className: "duel-sheet-heading",
				children: o("games.duel.chooseWonder")
			}),
			/* @__PURE__ */ c("div", {
				className: "duel-wonder-picker",
				children: e.map((e) => /* @__PURE__ */ c("button", {
					type: "button",
					className: "duel-picker-wonder",
					"data-picked": t === e,
					"aria-label": o(K(e)),
					onClick: () => a(e),
					children: /* @__PURE__ */ c(Q, { id: e })
				}, e))
			}),
			t && /* @__PURE__ */ l("div", {
				className: "duel-wonder-focus",
				children: [
					/* @__PURE__ */ c(Q, {
						id: t,
						large: !0
					}),
					/* @__PURE__ */ c(Ve, { id: t }),
					/* @__PURE__ */ c(X, { cost: y(t).cost }),
					/* @__PURE__ */ c(et, {
						printed: y(t).cost.coins ?? 0,
						price: s,
						coins: i
					})
				]
			})
		]
	});
}
function rt({ pawn: e, fines: t, leftName: n, rightName: i }) {
	let a = r();
	return /* @__PURE__ */ l("div", {
		className: "duel-military",
		"aria-label": `${a("games.duel.militaryTrack")} ${e}`,
		children: [
			/* @__PURE__ */ l("div", {
				className: "duel-military-labels",
				children: [
					/* @__PURE__ */ l("span", {
						title: n,
						children: [
							/* @__PURE__ */ c(U, { kind: "capital" }),
							" ",
							n
						]
					}),
					/* @__PURE__ */ c("span", { children: /* @__PURE__ */ c(U, { kind: "shield" }) }),
					/* @__PURE__ */ l("span", {
						title: i,
						children: [
							i,
							" ",
							/* @__PURE__ */ c(U, { kind: "capital" })
						]
					})
				]
			}),
			/* @__PURE__ */ l("div", {
				className: "duel-military-rail",
				children: [Array.from({ length: 19 }, (e, t) => {
					let n = t - 9;
					return /* @__PURE__ */ c("span", {
						className: "duel-military-cell",
						"data-zone": Math.abs(n) >= 6 ? "10" : Math.abs(n) >= 3 ? "5" : "2",
						"data-center": n === 0
					}, n);
				}), /* @__PURE__ */ c("span", {
					className: "duel-military-pawn",
					style: { left: `${(e + 9) / 18 * 100}%` },
					"aria-hidden": !0,
					children: /* @__PURE__ */ c(U, { kind: "shield" })
				})]
			}),
			[
				-6,
				-3,
				3,
				6
			].filter((e) => !t.includes(e)).map((e) => /* @__PURE__ */ c("span", {
				className: "duel-military-fine",
				style: { left: `${(e + 9) / 18 * 100}%` },
				children: /* @__PURE__ */ c(Y, { n: Math.abs(e) === 3 ? 2 : 5 })
			}, e))
		]
	});
}
function it({ pub: e, myTurn: t, sel: n, onSel: i, onInspect: a }) {
	let o = r(), s = C[e.age], l = Math.max(...s.map((e) => e.row)) + 1, u = .52, d = 1 / 6 * 1.34 * (1 + (l - 1) * u), f = 1 / (1 + (l - 1) * u);
	return /* @__PURE__ */ c("div", {
		className: "duel-pyramid",
		style: {
			"--duel-pyramid-ratio": d,
			aspectRatio: `1 / ${d}`
		},
		children: e.pyramid.map((r, l) => {
			if (r.taken) return null;
			let d = s[l], p = {
				left: `${(d.x + 5) / 12 * 100}%`,
				top: `${d.row * u * f * 100}%`,
				width: `${100 / 6}%`,
				height: `${f * 100}%`
			}, m = r.faceUp && r.cardId ? /* @__PURE__ */ c(Z, { id: r.cardId }) : /* @__PURE__ */ c(We, { age: e.age });
			if (r.faceUp && r.cardId) {
				let e = r.cardId, s = t && r.accessible;
				return /* @__PURE__ */ c("button", {
					type: "button",
					className: "duel-pyramid-slot",
					style: p,
					"data-selectable": s,
					"data-picked": n === l,
					"aria-label": o(G(e)),
					onClick: () => s ? i(l) : a(e),
					children: m
				}, l);
			}
			return /* @__PURE__ */ c("div", {
				className: "duel-pyramid-slot",
				style: p,
				children: m
			}, l);
		})
	});
}
function at({ city: e, name: t, isMe: n, onInspect: i }) {
	let a = r(), o = [...Ke].sort((t, n) => e.cards.filter((e) => v(e).color === n).length - e.cards.filter((e) => v(e).color === t).length), s = [];
	for (let t of e.cards) for (let e of v(t).effects) e.kind === "science" && s.push(e.symbol);
	e.tokens.includes("law") && s.push("law");
	let u = [...new Set(s)];
	return /* @__PURE__ */ l("section", {
		className: `duel-city ${n ? "duel-city-mine" : "duel-city-opponent"}`,
		"aria-label": `${a(n ? "games.duel.myCity" : "games.duel.opponentCity")} ${t}`,
		children: [
			/* @__PURE__ */ l("div", {
				className: "duel-city-head",
				children: [
					/* @__PURE__ */ l("strong", { children: [n ? "● " : "◆ ", t] }),
					/* @__PURE__ */ l("span", {
						className: "duel-city-science",
						children: [
							/* @__PURE__ */ c(U, {
								kind: "science",
								id: "compass"
							}),
							" ",
							u.length,
							"/",
							6
						]
					}),
					/* @__PURE__ */ c("span", {
						className: "duel-city-coins duel-value-pulse",
						children: /* @__PURE__ */ c(Y, { n: e.coins })
					}, e.coins)
				]
			}),
			/* @__PURE__ */ l("div", {
				className: "duel-city-main",
				children: [/* @__PURE__ */ c("div", {
					className: "duel-city-buildings",
					"aria-label": a("games.duel.buildings"),
					children: o.map((t) => {
						let n = e.cards.filter((e) => v(e).color === t);
						return /* @__PURE__ */ l("button", {
							type: "button",
							disabled: n.length === 0,
							className: `duel-city-stack ${je(t)}`,
							"aria-label": `${a(Je[t])} ${n.length}`,
							onClick: () => i({
								kind: "group",
								color: t,
								city: e,
								focusId: n[n.length - 1]
							}),
							children: [/* @__PURE__ */ c("span", {
								className: "duel-city-stack-effect",
								children: n.length ? /* @__PURE__ */ c(Fe, { def: v(n[n.length - 1]) }) : qe[t]
							}), /* @__PURE__ */ c("span", {
								className: "duel-city-stack-count",
								children: n.length ? `${qe[t]}${n.length}` : ""
							})]
						}, t);
					})
				}), /* @__PURE__ */ c("div", {
					className: "duel-city-wonders",
					"aria-label": a("games.duel.wonders"),
					children: e.wonders.map((e) => /* @__PURE__ */ c("button", {
						type: "button",
						className: "duel-city-wonder duel-piece-arrive",
						"data-built": e.built,
						"aria-label": `${a(K(e.id))} ${a(e.built ? "games.duel.built" : "games.duel.unbuilt")}`,
						onClick: () => i({
							kind: "wonder",
							id: e.id
						}),
						children: /* @__PURE__ */ c(U, {
							kind: "wonder",
							id: e.id
						})
					}, `${e.id}-${e.built}`))
				})]
			}),
			/* @__PURE__ */ l("div", {
				className: "duel-city-tokens",
				children: [/* @__PURE__ */ c("span", {
					className: "duel-city-science-icons",
					children: u.map((e) => /* @__PURE__ */ c(He, { id: e }, e))
				}), e.tokens.map((e) => /* @__PURE__ */ c($, {
					id: e,
					size: 20
				}, e))]
			})
		]
	});
}
function ot({ board: e, myTurn: t, myRid: n, nameOf: i, sel: a, onSel: o }) {
	let s = r();
	return /* @__PURE__ */ c("div", {
		className: "duel-draft-grid",
		children: e.map(({ id: e, ownerRid: r }) => {
			let u = r === null ? "available" : r === n ? "mine" : "opponent", d = r === null ? null : s(r === n ? "games.duel.draftMine" : "games.duel.draftClaimed", { name: i(r) });
			return /* @__PURE__ */ l("button", {
				type: "button",
				disabled: !t || r !== null,
				className: "duel-draft-choice",
				"data-picked": a === e && r === null,
				"data-claimed": u,
				"aria-label": `${s(K(e))}${d ? ` · ${d}` : ""}`,
				onClick: () => o(a === e ? null : e),
				children: [/* @__PURE__ */ c(Q, {
					id: e,
					large: !0
				}), d && /* @__PURE__ */ c("span", {
					className: "duel-draft-claim",
					children: d
				})]
			}, e);
		})
	});
}
function st({ inspect: e, onInspect: t, onClose: n }) {
	let i = r(), a;
	if (e.kind === "card") a = /* @__PURE__ */ l("div", {
		className: "duel-inspect-card",
		children: [/* @__PURE__ */ c(Z, {
			id: e.id,
			large: !0
		}), /* @__PURE__ */ l("div", {
			className: "duel-inspect-meta",
			children: [
				/* @__PURE__ */ c("strong", { children: i(G(e.id)) }),
				/* @__PURE__ */ c(Le, { def: v(e.id) }),
				/* @__PURE__ */ c("span", { children: i("games.duel.cost") }),
				/* @__PURE__ */ c(Me, { cost: v(e.id).cost }),
				/* @__PURE__ */ c(X, { cost: v(e.id).cost })
			]
		})]
	});
	else if (e.kind === "wonder") a = /* @__PURE__ */ l(s, { children: [
		/* @__PURE__ */ c(Q, {
			id: e.id,
			large: !0
		}),
		/* @__PURE__ */ c(Ve, { id: e.id }),
		/* @__PURE__ */ c(X, { cost: y(e.id).cost })
	] });
	else {
		let n = e.city.cards.filter((t) => v(t).color === e.color);
		a = /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("div", {
			className: "duel-fan",
			children: n.map((n) => /* @__PURE__ */ c("button", {
				type: "button",
				className: "duel-fan-card",
				"data-picked": e.focusId === n,
				"aria-label": i(G(n)),
				onClick: () => t({
					...e,
					focusId: n
				}),
				children: /* @__PURE__ */ c(Z, { id: n })
			}, n))
		}), /* @__PURE__ */ l("div", {
			className: "duel-inspect-card",
			children: [/* @__PURE__ */ c(Z, {
				id: e.focusId,
				large: !0
			}), /* @__PURE__ */ l("div", {
				className: "duel-inspect-meta",
				children: [
					/* @__PURE__ */ c("strong", { children: i(G(e.focusId)) }),
					/* @__PURE__ */ c(Le, { def: v(e.focusId) }),
					/* @__PURE__ */ c("span", { children: i("games.duel.cost") }),
					/* @__PURE__ */ c(Me, { cost: v(e.focusId).cost }),
					/* @__PURE__ */ c(X, { cost: v(e.focusId).cost })
				]
			})]
		})] });
	}
	return /* @__PURE__ */ l("div", {
		className: "pointer-events-auto duel-sheet",
		children: [/* @__PURE__ */ l("div", {
			className: "duel-sheet-head",
			children: [/* @__PURE__ */ c("strong", { children: e.kind === "group" ? i("games.duel.cardsInCity", { n: e.city.cards.filter((t) => v(t).color === e.color).length }) : i("games.duel.cardDetail") }), /* @__PURE__ */ c("button", {
				type: "button",
				className: "btn-quiet min-h-11 px-3 text-xs",
				onClick: n,
				children: i("games.duel.close")
			})]
		}), a]
	});
}
function ct({ pending: e, sel: t, nameOf: n, onSel: i }) {
	let a = r(), o = e.kind === "token" || e.kind === "library", u = e.kind === "destroy" || e.kind === "revive";
	return /* @__PURE__ */ l("div", {
		className: "pointer-events-auto duel-sheet",
		children: [
			/* @__PURE__ */ c("strong", {
				className: "duel-sheet-heading",
				children: a(Ye[e.kind])
			}),
			o && /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("div", {
				className: "duel-token-picker",
				children: e.options.map((e) => /* @__PURE__ */ l("button", {
					type: "button",
					className: "duel-token-option",
					"data-picked": t === e,
					"aria-label": a(q(e)),
					onClick: () => i(e),
					children: [/* @__PURE__ */ c($, {
						id: e,
						size: 42
					}), /* @__PURE__ */ c("strong", { children: a(q(e)) })]
				}, e))
			}), t && /* @__PURE__ */ l("div", {
				className: "duel-token-detail",
				children: [/* @__PURE__ */ c($, {
					id: t,
					size: 50
				}), /* @__PURE__ */ l("span", { children: [/* @__PURE__ */ c("strong", { children: a(q(t)) }), /* @__PURE__ */ c("small", { children: a(Ae[t]) })] })]
			})] }),
			u && /* @__PURE__ */ l(s, { children: [/* @__PURE__ */ c("div", {
				className: "duel-fan",
				children: e.options.map((e) => /* @__PURE__ */ c("button", {
					type: "button",
					className: "duel-fan-card",
					"data-picked": t === e,
					"aria-label": a(G(e)),
					onClick: () => i(e),
					children: /* @__PURE__ */ c(Z, { id: e })
				}, e))
			}), t && /* @__PURE__ */ l("div", {
				className: "duel-inspect-card",
				children: [/* @__PURE__ */ c(Z, {
					id: t,
					large: !0
				}), /* @__PURE__ */ l("div", {
					className: "duel-inspect-meta",
					children: [/* @__PURE__ */ c("strong", { children: a(G(t)) }), /* @__PURE__ */ c(Le, { def: v(t) })]
				})]
			})] }),
			e.kind === "ageStart" && /* @__PURE__ */ c("div", {
				className: "duel-start-picker",
				children: e.options.map((e) => /* @__PURE__ */ l("button", {
					type: "button",
					className: "duel-start-option",
					"data-picked": t === e,
					onClick: () => i(e),
					children: [/* @__PURE__ */ c(U, { kind: "capital" }), /* @__PURE__ */ c("strong", { children: n(e) })]
				}, e))
			})
		]
	});
}
//#endregion
//#region src/games/duel/bot.ts
var lt = {
	pyramids: 10,
	"great-library": 9,
	colossus: 8,
	sphinx: 8,
	"statue-of-zeus": 7.5,
	"circus-maximus": 7,
	"appian-way": 7,
	mausoleum: 7,
	"hanging-gardens": 6.5,
	"great-lighthouse": 6,
	"temple-of-artemis": 6,
	piraeus: 5.5
};
function ut(e, t, n) {
	switch (e) {
		case "law": return n >= 5 ? 100 : 3.5;
		case "philosophy": return 7;
		case "mathematics": return 3 * t;
		case "agriculture": return 6.4;
		case "urbanism": return 3.6;
		case "strategy": return 3;
		case "economy": return 2.5;
		case "theology": return 2;
		case "architecture": return 2;
		case "masonry": return 2;
		default: return 1;
	}
}
function dt(e, t) {
	return e.cities.findIndex((e) => e.rid === t) === 0 ? 0 : 1;
}
function ft(e, t) {
	let n = /* @__PURE__ */ new Set();
	for (let t of e) for (let e of v(t).effects) e.kind === "science" && n.add(e.symbol);
	return t.includes("law") && n.add("law"), n.size;
}
function pt(e, t) {
	let n = [];
	for (let t of e) for (let e of v(t).effects) e.kind === "science" && n.push(e.symbol);
	return t.includes("law") && n.push("law"), n;
}
function mt(e, t, n) {
	let r = t.cities[n], i = n === 0 ? 1 : -1;
	for (let n of e.effects) {
		if (n.kind === "shields" && Math.abs(t.pawn + i * n.n) >= 9) return "military";
		if (n.kind === "science") {
			let e = pt(r.cards, r.tokens);
			if (e.push(n.symbol), new Set(e).size >= 6) return "science";
		}
	}
	return null;
}
function ht(e, t, n, r) {
	let i = t.cities[n], a = t.cities[1 - n], o = 0;
	for (let r of e.effects) switch (r.kind) {
		case "vp":
			o += r.n;
			break;
		case "coins":
			o += r.n * .4;
			break;
		case "coinsPer": {
			let e = r.target === "wonder" ? i.wonders.filter((e) => e.built).length : i.cards.filter((e) => v(e).color === r.target).length;
			o += r.n * e * .4;
			break;
		}
		case "shields": {
			let e = n === 0 ? 1 : -1, i = Math.abs(t.pawn + e * r.n);
			o += r.n * (2.5 + i * .3);
			break;
		}
		case "science": {
			let e = pt(i.cards, i.tokens), t = e.includes(r.symbol), n = new Set(e).size;
			t || (o += 3 + n * .8), e.filter((e) => e === r.symbol).length === 1 && (o += 4);
			break;
		}
		case "produce": {
			let e = Object.fromEntries(a.cards.flatMap((e) => v(e).effects.filter((e) => e.kind === "produce").flatMap((e) => Object.entries(e.resources))));
			for (let [t, n] of Object.entries(r.resources)) o += (n ?? 0) * (2 + .5 * (e[t] ?? 0)) * .5;
			break;
		}
		case "produceChoice":
			o += 2.2;
			break;
		case "tradeOne":
			o += 1.5;
			break;
		case "guild": {
			let e = (e, t) => e === "wonder" ? t.wonders.filter((e) => e.built).length : e === "brownGray" ? t.cards.filter((e) => ["brown", "gray"].includes(v(e).color)).length : e === "coins" ? Math.floor(t.coins / 3) : t.cards.filter((t) => v(t).color === e).length;
			o += r.vpPer * Math.max(e(r.target, i), e(r.target, a)) * .8;
			break;
		}
	}
	return e.chainTo && (o += .6), o - r * .4;
}
function gt(e, t) {
	let n = 0;
	for (let t of y(e).effects) switch (t.kind) {
		case "vp":
			n += t.n;
			break;
		case "coins":
			n += t.n * .4;
			break;
		case "opponentCoins":
			n += t.n * .4;
			break;
		case "shields":
			n += t.n * 3;
			break;
		case "playAgain":
			n += 3;
			break;
		case "produceChoice":
			n += 2.2;
			break;
		case "destroy":
			n += 3;
			break;
		case "revive":
			n += 2;
			break;
		case "library": n += 3;
	}
	return n - t * .4;
}
var _t = (e, t) => {
	let n = e.public, r = dt(n, t.rid);
	if (r < 0) return null;
	let i = n.cities[r];
	if (n.phase === "draft" && n.draft) return n.draft.turnRid === t.rid ? { action: {
		type: "draft",
		wonderId: [...n.draft.pool].sort((e, t) => (lt[t] ?? 5) - (lt[e] ?? 5))[0]
	} } : null;
	if (n.phase === "choice" && n.pending) {
		let e = n.pending;
		if (e.who !== t.rid) return null;
		switch (e.kind) {
			case "token":
			case "library": {
				let t = ft(i.cards, i.tokens), n = [...e.options].sort((e, n) => ut(n, i.tokens.length, t) - ut(e, i.tokens.length, t))[0];
				return { action: e.kind === "token" ? {
					type: "chooseToken",
					tokenId: n
				} : {
					type: "chooseLibrary",
					tokenId: n
				} };
			}
			case "destroy": return { action: {
				type: "chooseDestroy",
				cardId: [...e.options].sort((e, t) => vt(t) - vt(e))[0]
			} };
			case "revive": return { action: {
				type: "chooseRevive",
				cardId: [...e.options].sort((e, t) => ht(v(t), n, r, 0) - ht(v(e), n, r, 0))[0]
			} };
			case "ageStart": return { action: {
				type: "chooseStart",
				player: t.rid
			} };
		}
	}
	if (n.phase !== "age" || n.turn !== t.rid) return null;
	let a = [], o = /* @__PURE__ */ new Set();
	for (let e of n.pyramid) e.accessible && e.cardId && mt(v(e.cardId), n, 1 - r) && o.add(e.slot);
	for (let e of n.pyramid) {
		if (!e.accessible || !e.cardId) continue;
		let t = v(e.cardId), s = o.has(e.slot) ? 100 : 0;
		if (e.buildPrice && e.buildPrice.total <= i.coins) {
			let i = mt(t, n, r);
			a.push({
				action: {
					type: "take",
					slot: e.slot,
					use: "build"
				},
				score: i ? 1e3 : s + ht(t, n, r, e.buildPrice.total)
			});
		}
		a.push({
			action: {
				type: "take",
				slot: e.slot,
				use: "sell"
			},
			score: s + (e.sellValue ?? 2) * .4 - .5
		});
		for (let t of i.wonders) {
			if (t.built) continue;
			let r = n.wonderPrices[t.id];
			!r || r.total > i.coins || a.push({
				action: {
					type: "take",
					slot: e.slot,
					use: "wonder",
					wonderId: t.id
				},
				score: s + gt(t.id, r.total) - .3
			});
		}
	}
	return a.length === 0 ? null : (a.sort((e, t) => t.score - e.score), { action: a[0].action });
};
function vt(e) {
	let t = 0;
	for (let n of v(e).effects) n.kind === "produce" && (t += Object.values(n.resources).reduce((e, t) => e + (t ?? 0), 0));
	return t;
}
var yt = (e, t, n) => {
	if (e.type === "draft") return n("games.duel.hintDraft", { name: n(K(e.wonderId)) });
	if (e.type === "take") {
		let r = t.public.pyramid.find((t) => t.slot === e.slot)?.cardId;
		if (!r) return "";
		let i = n(G(r));
		return e.use === "build" ? n("games.duel.hintBuild", { name: i }) : e.use === "sell" ? n("games.duel.hintSell", { name: i }) : e.wonderId ? n("games.duel.hintWonder", {
			name: i,
			wonder: n(K(e.wonderId))
		}) : "";
	}
	return e.type === "chooseToken" || e.type === "chooseLibrary" ? n("games.duel.hintToken", { name: n(q(e.tokenId)) }) : e.type === "chooseDestroy" ? n("games.duel.hintDestroy", { name: n(G(e.cardId)) }) : e.type === "chooseRevive" ? n("games.duel.hintRevive", { name: n(G(e.cardId)) }) : e.type === "chooseStart" ? n("games.duel.hintChooseStart") : "";
}, bt = [
	{
		key: "military",
		label: "games.duel.score.military"
	},
	{
		key: "buildings",
		label: "games.duel.score.buildings"
	},
	{
		key: "wonders",
		label: "games.duel.score.wonders"
	},
	{
		key: "tokens",
		label: "games.duel.score.tokens"
	},
	{
		key: "guilds",
		label: "games.duel.score.guilds"
	},
	{
		key: "coins",
		label: "games.duel.score.coins"
	}
], xt = {
	military: "games.duel.winMilitary",
	science: "games.duel.winScience",
	civilian: "games.duel.winCivilian"
};
function St({ result: e, public: t, members: n, onPlayAgain: i, onBackToLobby: a }) {
	let o = r(), s = t, d = (e) => n.find((t) => t.rid === e)?.name ?? e, f = i ?? a, p = s.cities.map((e) => e.rid), m = Object.fromEntries(s.cities.map((e) => [e.rid, e])), h = (e) => R({
		players: p,
		cities: m,
		pawn: s.pawn
	}, p.indexOf(e)), g = Math.max(...p.map((e) => h(e).total)), _ = p.filter((e) => h(e).total === g).length > 1 && e.winner.length === 1;
	return /* @__PURE__ */ l("div", {
		className: "duel-over relative flex h-full min-h-0 flex-col items-center gap-2 overflow-y-auto",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ c(u, {}),
			/* @__PURE__ */ l("h1", {
				className: "duel-over-title flex flex-none items-center gap-2 text-center font-display text-xl font-extrabold",
				children: [/* @__PURE__ */ c("span", {
					"aria-hidden": !0,
					className: "text-amber-800",
					children: /* @__PURE__ */ c(U, { kind: "capital" })
				}), o("session.result.title")]
			}),
			s.winReason && /* @__PURE__ */ c("p", {
				className: "duel-over-reason flex-none rounded-full border-2 border-ink bg-amber-200 px-3 py-0.5 text-sm font-extrabold",
				children: o(xt[s.winReason])
			}),
			/* @__PURE__ */ c("div", {
				className: "duel-over-results flex w-full max-w-md flex-none flex-col gap-2",
				children: e.ranking.map((t, n) => {
					let r = h(t), i = e.winner.includes(t);
					return /* @__PURE__ */ l("section", {
						className: "duel-over-player frame flex flex-col gap-1 p-2.5",
						children: [
							/* @__PURE__ */ l("header", {
								className: "duel-over-player-head flex items-center gap-2",
								children: [
									/* @__PURE__ */ c("span", {
										"aria-hidden": !0,
										className: `w-5 flex-none text-center ${i ? "" : "invisible"}`,
										children: /* @__PURE__ */ c(U, {
											kind: "vp",
											className: "text-amber-700"
										})
									}),
									/* @__PURE__ */ l("span", {
										className: "duel-over-name min-w-0 flex-1 truncate text-sm font-extrabold",
										children: [
											n + 1,
											". ",
											d(t)
										]
									}),
									/* @__PURE__ */ c("span", {
										className: "duel-over-total flex-none font-mono text-lg font-extrabold tabular-nums",
										children: r.total
									})
								]
							}),
							/* @__PURE__ */ c("ul", {
								className: "duel-over-categories grid grid-cols-3 gap-x-3 gap-y-0.5 text-xs font-bold",
								children: bt.map(({ key: e, label: t }) => /* @__PURE__ */ l("li", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ c("span", {
										className: "opacity-70",
										children: o(t)
									}), /* @__PURE__ */ c("span", {
										className: "font-mono tabular-nums",
										children: r[e]
									})]
								}, e))
							}),
							_ && /* @__PURE__ */ c("p", {
								className: "text-[11px] text-ink/60",
								children: o("games.duel.tiebreak", { n: r.blueVp })
							}),
							/* @__PURE__ */ c("div", {
								className: "duel-over-tokens flex flex-wrap items-center gap-1",
								children: m[t].tokens.map((e) => /* @__PURE__ */ l("span", {
									className: "flex items-center gap-0.5 text-[11px] font-bold",
									children: [/* @__PURE__ */ c($, {
										id: e,
										size: 18
									}), o(q(e))]
								}, e))
							})
						]
					}, t);
				})
			}),
			f ? /* @__PURE__ */ l("div", {
				className: "duel-over-controls safe-b flex w-full max-w-sm flex-none flex-col gap-2 pb-1",
				children: [i && /* @__PURE__ */ c("button", {
					className: "btn-base w-full cursor-pointer text-white",
					style: { background: T.accent },
					onClick: i,
					children: o("session.result.playAgain")
				}), a && /* @__PURE__ */ c("button", {
					className: "btn-quiet w-full cursor-pointer",
					onClick: a,
					children: o("session.result.backToLobby")
				})]
			}) : /* @__PURE__ */ c("p", {
				className: "safe-b flex-none pb-1 text-sm font-bold opacity-70",
				children: o("session.result.waitHost")
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/duel/entry.tsx
var Ct = {
	definition: ye,
	View: Ze,
	bot: _t,
	describe: yt,
	OverView: St,
	locales: {
		zh: {
			name: "七大奇迹:对决",
			desc: "双人对决:金字塔里抢牌建城,军事碾压、科技霸权、文明计分三条胜利路",
			rules: "目标:三个时代结束后文明总分最高者获胜;也可用军事推到对方首都、或集齐 6 种科技符号立即获胜。\n准备:\n· 双方各抽 4 座奇迹:两轮轮抽,先手 1 张、对方 2 张、先手 1 张,第二轮交换先后手。\n· 双方各获得 7 金币。\n· 每个时代有专属牌阵:被压住的牌不可拿,盖着的牌翻开才可见。\n流程(你的回合):\n· 从牌阵挑选 1 张可拿的牌,然后三选一:建造、弃掉换钱、建造奇迹。\n· 建造付牌面费用;弃掉换钱获得 2 + 黄卡数枚金币;建造奇迹改付奇迹费用,牌垫在奇迹下。\n· 缺资源可向银行买:每单位 2 + 对方棕/灰卡该资源产量的金币。\n· 卡面有连锁符号且你已建出对应符号的建筑时,免费建造。\n· 部分奇迹建成后立刻再行动一次;全场最多建成 7 座奇迹。\n军事:红卡的盾牌推动军事标记;推到对方首都立即获胜,进入对方区域还会掠取金币标记。\n科技:绿卡印有 7 种符号;集齐一对相同符号获得 1 枚科技标记,集齐 6 种不同符号立即获胜。\n结算:军事区分数 + 蓝/绿/黄/紫卡分数 + 奇迹分 + 标记分,再加每 3 金币 1 分。\n平分比蓝卡分数,再平共享胜利。",
			draftRound: "奇迹轮抽 · 第 {{n}} 轮",
			draftPick: "轮到你:选 1 座奇迹",
			draftWait: "等 {{name}} 选奇迹…",
			draftMine: "你已选 · {{name}}",
			draftClaimed: "{{name}} 已选",
			ageChip: "时代 {{n}}",
			turnYou: "轮到你:从牌阵拿 1 张牌",
			turnWait: "等 {{name}} 行动…",
			pickToken: "科技对子:选 1 枚标记",
			pickDestroy: "选要摧毁的对方建筑",
			pickRevive: "陵墓:从弃牌堆免费建 1 张",
			pickLibrary: "大图书馆:选 1 枚标记",
			pickStart: "军事弱势方:选下个时代的先手",
			waitChoice: "等 {{name}} 选择…",
			winMilitary: "军事胜利：攻入对方首都！",
			winScience: "科技胜利：集齐 6 种符号！",
			winCivilian: "文明计分",
			confirm: "确定",
			cancel: "取消",
			build: "建造",
			free: "免费建造",
			viaChain: "连锁免费",
			price: "费用",
			sell: "弃牌 +{{n}} 金币",
			buildWonder: "奇迹",
			chooseCard: "选择一张可拿的牌",
			chooseWonder: "选择要建造的奇迹",
			myCity: "我的城市",
			opponentCity: "对手城市",
			buildings: "建筑",
			wonders: "奇迹",
			progressTokens: "进度标记",
			militaryTrack: "军事冲突",
			cardDetail: "牌面详情",
			close: "关闭",
			unavailable: "不可建造",
			built: "已建成",
			unbuilt: "未建成",
			noCost: "免费",
			chainFrom: "可通过连锁免费建造",
			chainTo: "为后续建筑提供连锁",
			cardColor: {
				brown: "原料",
				gray: "制成品",
				blue: "民用",
				green: "科技",
				yellow: "商业",
				red: "军事",
				purple: "公会"
			},
			resource: {
				wood: "木材",
				clay: "黏土",
				stone: "石材",
				glass: "玻璃",
				papyrus: "纸草"
			},
			science: {
				compass: "罗盘",
				wheel: "车轮",
				writing: "书写",
				mortar: "研钵",
				sundial: "日晷",
				astrology: "天文",
				law: "法律"
			},
			priceBase: "牌面金币",
			priceTrade: "资源交易",
			priceTotal: "本次总价",
			priceHave: "现有金币",
			priceShort: "还差 {{n}} 金币",
			priceLimit: "奇迹建造已达上限",
			buildThisWonder: "建造此奇迹",
			chooseToInspect: "点选牌件查看详情",
			confirmChoice: "确认选择",
			cardsInCity: "{{n}} 张建筑",
			effect: "效果",
			cost: "牌面费用",
			cityOptions: "选择建筑",
			tokenOptions: "选择进度标记",
			costResources: "需要 {{items}}",
			effectText: {
				produce: "每回合产出 {{items}}",
				produceChoice: "每回合从 {{items}} 中任选 1 种",
				tradeOne: "购买 {{items}} 时每单位只需 1 金币",
				coins: "立即获得 {{n}} 金币",
				coinsPer: "每座{{target}}获得 {{n}} 金币",
				vp: "获得 {{n}} 胜利分",
				shields: "增加 {{n}} 盾牌",
				science: "获得{{symbol}}科技符号",
				guild: "按{{target}}数量计分：每个 {{vp}} 分、{{coins}} 金币",
				guildVp: "按{{target}}数量计分：每个 {{vp}} 分",
				opponentCoins: "对手失去 {{n}} 金币",
				playAgain: "建成后立即再行动一次",
				destroy: "摧毁对手 1 张{{target}}",
				revive: "从弃牌堆免费建造 1 张建筑",
				library: "从 3 枚进度标记中选择 1 枚"
			},
			target: {
				brownGray: "棕色或灰色建筑",
				wonder: "已建奇迹",
				coins: "金币",
				yellow: "商业建筑",
				blue: "民用建筑",
				green: "科技建筑",
				red: "军事建筑",
				brown: "原料建筑",
				gray: "制成品建筑"
			},
			errNotYourTurn: "还没轮到你",
			errBadPhase: "现在不能这么做",
			errBadSlot: "这张牌现在不能拿",
			errCantAfford: "金币不够",
			errBadWonder: "这座奇迹不能建",
			errBadChoice: "无效的选项",
			tiebreak: "平分决胜:蓝卡 {{n}} 分",
			score: {
				military: "军事",
				buildings: "建筑",
				wonders: "奇迹",
				tokens: "标记",
				guilds: "公会",
				coins: "金币"
			},
			card: {
				"lumber-yard": "伐木场",
				"logging-camp": "伐木营地",
				"clay-pool": "黏土池",
				"clay-pit": "黏土坑",
				quarry: "采石场",
				"stone-pit": "石矿坑",
				glassworks: "玻璃工坊",
				press: "纸草工坊",
				"guard-tower": "哨塔",
				stable: "马厩",
				garrison: "驻军营",
				palisade: "木栅",
				workshop: "工坊",
				apothecary: "药房",
				scriptorium: "缮写室",
				pharmacist: "药剂师",
				"stone-reserve": "石料储备",
				"clay-reserve": "黏土储备",
				"wood-reserve": "木材储备",
				theater: "剧院",
				altar: "祭坛",
				baths: "浴场",
				tavern: "酒馆",
				sawmill: "锯木厂",
				brickyard: "制砖厂",
				"shelf-quarry": "岩层采石场",
				"glass-blower": "玻璃吹制坊",
				"drying-room": "晾晒房",
				walls: "城墙",
				"horse-breeders": "育马场",
				barracks: "兵营",
				"archery-range": "箭术场",
				"parade-ground": "阅兵场",
				forum: "市集广场",
				caravansery: "商队驿站",
				"customs-house": "海关",
				brewery: "酿酒厂",
				library: "图书馆",
				dispensary: "诊疗所",
				school: "学校",
				laboratory: "实验室",
				statue: "雕像",
				temple: "神庙",
				aqueduct: "引水渠",
				rostrum: "演讲台",
				courthouse: "法院",
				arsenal: "军械库",
				pretorium: "执政官府",
				fortifications: "防御工事",
				"siege-workshop": "攻城工坊",
				circus: "赛马场",
				academy: "学院",
				study: "书斋",
				university: "大学",
				observatory: "天文台",
				palace: "宫殿",
				"town-hall": "市政厅",
				obelisk: "方尖碑",
				gardens: "花园",
				pantheon: "万神殿",
				senate: "元老院",
				"chamber-of-commerce": "商会",
				port: "港口",
				armory: "武备铺",
				lighthouse: "灯塔",
				arena: "角斗场",
				"merchants-guild": "商人公会",
				"shipowners-guild": "船东公会",
				"builders-guild": "建筑师公会",
				"magistrates-guild": "执政官公会",
				"scientists-guild": "科学家公会",
				"moneylenders-guild": "放贷人公会",
				"tacticians-guild": "战术家公会"
			},
			wonder: {
				"appian-way": "阿庇亚大道",
				"circus-maximus": "大竞技场",
				colossus: "罗德岛巨像",
				"great-library": "大图书馆",
				"great-lighthouse": "大灯塔",
				"hanging-gardens": "空中花园",
				mausoleum: "摩索拉斯陵墓",
				piraeus: "比雷埃夫斯港",
				pyramids: "吉萨金字塔",
				sphinx: "狮身人面像",
				"statue-of-zeus": "宙斯神像",
				"temple-of-artemis": "阿尔忒弥斯神庙"
			},
			token: {
				agriculture: "农业",
				architecture: "建筑学",
				economy: "经济学",
				law: "法律",
				masonry: "石工术",
				mathematics: "数学",
				philosophy: "哲学",
				strategy: "战略",
				theology: "神学",
				urbanism: "城市规划"
			},
			tokenInfo: {
				agriculture: "立即获得 6 金币，终局获得 4 分",
				architecture: "建奇迹少用 2 资源",
				economy: "对方的贸易费归你",
				law: "算作 1 个额外的科技符号(计入集齐 6 种,不能凑成对子)",
				masonry: "建蓝卡少用 2 资源",
				mathematics: "每枚进度标记额外获得 3 分",
				philosophy: "终局获得 7 分",
				strategy: "此后建造的红卡额外获得 1 面盾牌",
				theology: "此后的奇迹都带额外回合",
				urbanism: "立即获得 6 金币；此后连锁建造额外获得 4 金币"
			},
			hintDraft: "选择奇迹「{{name}}」",
			hintBuild: "建造「{{name}}」",
			hintSell: "弃掉「{{name}}」换钱",
			hintWonder: "垫「{{name}}」建造奇迹「{{wonder}}」",
			hintToken: "拿标记「{{name}}」",
			hintDestroy: "摧毁对方的「{{name}}」",
			hintRevive: "从弃牌堆建造「{{name}}」",
			hintChooseStart: "选择自己当下一时代的先手"
		},
		en: {
			name: "7 Wonders Duel",
			desc: "Two-player duel: draft from the pyramid, build your city — military, science, or civilian victory",
			rules: "Goal: after three Ages, the higher civilization score wins — or win instantly by reaching the enemy capital (military) or collecting 6 different science symbols.\nSetup:\n· Each player drafts 4 wonders: two rounds of 1-2-1 picks, swapping who starts in the second round.\n· Each player starts with 7 coins.\n· Each Age has its own card layout: covered cards cannot be taken; face-down cards flip when uncovered.\nOn your turn:\n· Take 1 accessible card from the layout, then choose one: build it, discard it for coins, or build a wonder.\n· Building pays the card's cost; discarding gains 2 + your yellow cards in coins; building a wonder pays the wonder's cost and tucks the card beneath it.\n· Missing resources can be bought from the bank: 2 + opponent brown/gray production of that resource per unit.\n· Chain symbols: if you already built the matching symbol, construction is free.\n· Some wonders grant an extra turn; at most 7 wonders can be built in total.\nMilitary: shields push the pawn; reaching the enemy capital wins instantly, and entering zones loots coin tokens.\nScience: 7 symbols on green cards; a pair of identical symbols grants a progress token, 6 different symbols win instantly.\nScoring: military zone VP + blue/green/yellow/purple cards + wonders + tokens, plus 1 VP per 3 coins.\nTies are broken by blue card VP, then shared victory.",
			draftRound: "Wonder draft · round {{n}}",
			draftPick: "Your pick: choose 1 wonder",
			draftWait: "{{name}} is drafting…",
			draftMine: "Your pick · {{name}}",
			draftClaimed: "Picked by {{name}}",
			ageChip: "Age {{n}}",
			turnYou: "Your turn: take 1 card",
			turnWait: "{{name}} is playing…",
			pickToken: "Science pair: take 1 token",
			pickDestroy: "Destroy an opponent building",
			pickRevive: "Mausoleum: build 1 discarded card for free",
			pickLibrary: "Great Library: take 1 token",
			pickStart: "Weaker military: choose who starts the next Age",
			waitChoice: "{{name}} is choosing…",
			winMilitary: "Military victory: enemy capital reached!",
			winScience: "Science victory: 6 distinct symbols!",
			winCivilian: "Civilian scoring",
			confirm: "Confirm",
			cancel: "Cancel",
			build: "Build",
			free: "Build free",
			viaChain: "Free via chain",
			price: "Cost",
			sell: "Discard +{{n}} coins",
			buildWonder: "Wonder",
			chooseCard: "Choose an available card",
			chooseWonder: "Choose a wonder to build",
			myCity: "My city",
			opponentCity: "Opponent city",
			buildings: "Buildings",
			wonders: "Wonders",
			progressTokens: "Progress tokens",
			militaryTrack: "Military conflict",
			cardDetail: "Card details",
			close: "Close",
			unavailable: "Cannot build",
			built: "Built",
			unbuilt: "Unbuilt",
			noCost: "Free",
			chainFrom: "Free through a chain",
			chainTo: "Provides a later chain",
			cardColor: {
				brown: "Raw materials",
				gray: "Manufactured goods",
				blue: "Civilian",
				green: "Science",
				yellow: "Commerce",
				red: "Military",
				purple: "Guild"
			},
			resource: {
				wood: "Wood",
				clay: "Clay",
				stone: "Stone",
				glass: "Glass",
				papyrus: "Papyrus"
			},
			science: {
				compass: "Compass",
				wheel: "Wheel",
				writing: "Writing",
				mortar: "Mortar",
				sundial: "Sundial",
				astrology: "Astrology",
				law: "Law"
			},
			priceBase: "Printed coins",
			priceTrade: "Resource trade",
			priceTotal: "Total to pay",
			priceHave: "Your coins",
			priceShort: "{{n}} coins short",
			priceLimit: "Wonder limit reached",
			buildThisWonder: "Build this wonder",
			chooseToInspect: "Choose a piece to inspect",
			confirmChoice: "Confirm choice",
			cardsInCity: "{{n}} buildings",
			effect: "Effect",
			cost: "Printed cost",
			cityOptions: "Choose a building",
			tokenOptions: "Choose a progress token",
			costResources: "Requires {{items}}",
			effectText: {
				produce: "Produces {{items}} each turn",
				produceChoice: "Choose one of {{items}} each turn",
				tradeOne: "Buy {{items}} for 1 coin per unit",
				coins: "Gain {{n}} coins immediately",
				coinsPer: "Gain {{n}} coins per {{target}}",
				vp: "Gain {{n}} victory points",
				shields: "Gain {{n}} shields",
				science: "Gain the {{symbol}} science symbol",
				guild: "Score per {{target}}: {{vp}} VP and {{coins}} coins each",
				guildVp: "Score {{vp}} VP per {{target}}",
				opponentCoins: "Opponent loses {{n}} coins",
				playAgain: "Take another turn after construction",
				destroy: "Destroy one opponent {{target}}",
				revive: "Build one discarded building for free",
				library: "Choose one of three progress tokens"
			},
			target: {
				brownGray: "brown or gray building",
				wonder: "built wonder",
				coins: "coin",
				yellow: "commercial building",
				blue: "civilian building",
				green: "science building",
				red: "military building",
				brown: "raw material building",
				gray: "manufactured building"
			},
			errNotYourTurn: "Not your turn",
			errBadPhase: "Not allowed right now",
			errBadSlot: "That card is not available",
			errCantAfford: "Not enough coins",
			errBadWonder: "Cannot build that wonder",
			errBadChoice: "Invalid choice",
			tiebreak: "Tiebreak: {{n}} blue VP",
			score: {
				military: "Military",
				buildings: "Buildings",
				wonders: "Wonders",
				tokens: "Tokens",
				guilds: "Guilds",
				coins: "Coins"
			},
			card: {
				"lumber-yard": "Lumber Yard",
				"logging-camp": "Logging Camp",
				"clay-pool": "Clay Pool",
				"clay-pit": "Clay Pit",
				quarry: "Quarry",
				"stone-pit": "Stone Pit",
				glassworks: "Glassworks",
				press: "Press",
				"guard-tower": "Guard Tower",
				stable: "Stable",
				garrison: "Garrison",
				palisade: "Palisade",
				workshop: "Workshop",
				apothecary: "Apothecary",
				scriptorium: "Scriptorium",
				pharmacist: "Pharmacist",
				"stone-reserve": "Stone Reserve",
				"clay-reserve": "Clay Reserve",
				"wood-reserve": "Wood Reserve",
				theater: "Theater",
				altar: "Altar",
				baths: "Baths",
				tavern: "Tavern",
				sawmill: "Sawmill",
				brickyard: "Brickyard",
				"shelf-quarry": "Shelf Quarry",
				"glass-blower": "Glass Blower",
				"drying-room": "Drying Room",
				walls: "Walls",
				"horse-breeders": "Horse Breeders",
				barracks: "Barracks",
				"archery-range": "Archery Range",
				"parade-ground": "Parade Ground",
				forum: "Forum",
				caravansery: "Caravansery",
				"customs-house": "Customs House",
				brewery: "Brewery",
				library: "Library",
				dispensary: "Dispensary",
				school: "School",
				laboratory: "Laboratory",
				statue: "Statue",
				temple: "Temple",
				aqueduct: "Aqueduct",
				rostrum: "Rostrum",
				courthouse: "Courthouse",
				arsenal: "Arsenal",
				pretorium: "Pretorium",
				fortifications: "Fortifications",
				"siege-workshop": "Siege Workshop",
				circus: "Circus",
				academy: "Academy",
				study: "Study",
				university: "University",
				observatory: "Observatory",
				palace: "Palace",
				"town-hall": "Town Hall",
				obelisk: "Obelisk",
				gardens: "Gardens",
				pantheon: "Pantheon",
				senate: "Senate",
				"chamber-of-commerce": "Chamber of Commerce",
				port: "Port",
				armory: "Armory",
				lighthouse: "Lighthouse",
				arena: "Arena",
				"merchants-guild": "Merchants Guild",
				"shipowners-guild": "Shipowners Guild",
				"builders-guild": "Builders Guild",
				"magistrates-guild": "Magistrates Guild",
				"scientists-guild": "Scientists Guild",
				"moneylenders-guild": "Moneylenders Guild",
				"tacticians-guild": "Tacticians Guild"
			},
			wonder: {
				"appian-way": "The Appian Way",
				"circus-maximus": "Circus Maximus",
				colossus: "The Colossus",
				"great-library": "The Great Library",
				"great-lighthouse": "The Great Lighthouse",
				"hanging-gardens": "The Hanging Gardens",
				mausoleum: "The Mausoleum",
				piraeus: "Piraeus",
				pyramids: "The Pyramids",
				sphinx: "The Sphinx",
				"statue-of-zeus": "The Statue of Zeus",
				"temple-of-artemis": "The Temple of Artemis"
			},
			token: {
				agriculture: "Agriculture",
				architecture: "Architecture",
				economy: "Economy",
				law: "Law",
				masonry: "Masonry",
				mathematics: "Mathematics",
				philosophy: "Philosophy",
				strategy: "Strategy",
				theology: "Theology",
				urbanism: "Urbanism"
			},
			tokenInfo: {
				agriculture: "Gain 6 coins now and 4 VP at game end",
				architecture: "Wonders cost 2 fewer resources",
				economy: "Opponent trade fees go to you",
				law: "Counts as 1 extra science symbol (toward 6 distinct; never forms a pair)",
				masonry: "Blue cards cost 2 fewer resources",
				mathematics: "3 extra VP per progress token",
				philosophy: "7 VP at game end",
				strategy: "Your future red cards gain 1 extra shield",
				theology: "Your future wonders grant an extra turn",
				urbanism: "Gain 6 coins now; future chain builds gain 4 more coins"
			},
			hintDraft: "Draft the wonder {{name}}",
			hintBuild: "Build {{name}}",
			hintSell: "Discard {{name}} for coins",
			hintWonder: "Use {{name}} to build the wonder {{wonder}}",
			hintToken: "Take the token {{name}}",
			hintDestroy: "Destroy the opponent's {{name}}",
			hintRevive: "Build {{name}} from the discard pile",
			hintChooseStart: "Choose yourself to start the next age"
		}
	}
};
//#endregion
export { Ct as default };
