import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { IconBack as u, IconBot as d, IconCheck as f, IconExpand as p, IconLog as m } from "@bgparty/sdk/icons";
import { GameScreen as h } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as g } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as _, seatName as v } from "@bgparty/sdk/ui/player-strip";
import { SheetView as y } from "@bgparty/sdk/sheet-view";
import { Fragment as b, jsx as x, jsxs as S } from "react/jsx-runtime";
import { Floater as C, PulseBox as w } from "@bgparty/sdk/fx/primitives";
import { Confetti as T } from "@bgparty/sdk/ui/confetti";
import { OptionSwitch as E } from "@bgparty/sdk/ui/game-options";
//#region src/games/nextstation/map-data.ts
var D = [
	{
		x: 0,
		y: 0,
		district: 0,
		shape: "pentagon",
		tourist: !1
	},
	{
		x: 1,
		y: 0,
		district: 1,
		shape: "triangle",
		tourist: !1
	},
	{
		x: 2,
		y: 0,
		district: 1,
		shape: "square",
		tourist: !1
	},
	{
		x: 4,
		y: 0,
		district: 2,
		shape: "triangle",
		tourist: !1
	},
	{
		x: 5,
		y: 0,
		district: 2,
		shape: "circle",
		tourist: !1
	},
	{
		x: 7,
		y: 0,
		district: 3,
		shape: "triangle",
		tourist: !1
	},
	{
		x: 9,
		y: 0,
		district: 4,
		shape: "circle",
		tourist: !1
	},
	{
		x: 1,
		y: 1,
		district: 1,
		shape: "pentagon",
		tourist: !1
	},
	{
		x: 3,
		y: 1,
		district: 2,
		shape: "square",
		tourist: !1
	},
	{
		x: 6,
		y: 1,
		district: 2,
		shape: "pentagon",
		tourist: !0
	},
	{
		x: 8,
		y: 1,
		district: 3,
		shape: "square",
		tourist: !1
	},
	{
		x: 9,
		y: 1,
		district: 3,
		shape: "pentagon",
		tourist: !1
	},
	{
		x: 0,
		y: 2,
		district: 1,
		shape: "circle",
		tourist: !1
	},
	{
		x: 3,
		y: 2,
		district: 2,
		shape: "triangle",
		tourist: !1
	},
	{
		x: 6,
		y: 2,
		district: 2,
		shape: "square",
		tourist: !1
	},
	{
		x: 9,
		y: 2,
		district: 3,
		shape: "triangle",
		tourist: !1
	},
	{
		x: 0,
		y: 3,
		district: 5,
		shape: "square",
		tourist: !0
	},
	{
		x: 2,
		y: 3,
		district: 5,
		shape: "pentagon",
		tourist: !1
	},
	{
		x: 4,
		y: 3,
		district: 6,
		shape: "triangle",
		tourist: !1
	},
	{
		x: 5,
		y: 3,
		district: 6,
		shape: "wild",
		tourist: !0
	},
	{
		x: 6,
		y: 3,
		district: 6,
		shape: "circle",
		tourist: !1
	},
	{
		x: 7,
		y: 3,
		district: 7,
		shape: "circle",
		tourist: !1
	},
	{
		x: 9,
		y: 3,
		district: 7,
		shape: "square",
		tourist: !1
	},
	{
		x: 1,
		y: 4,
		district: 5,
		shape: "triangle",
		tourist: !1
	},
	{
		x: 2,
		y: 4,
		district: 5,
		shape: "square",
		tourist: !1
	},
	{
		x: 4,
		y: 4,
		district: 6,
		shape: "pentagon",
		tourist: !1
	},
	{
		x: 5,
		y: 4,
		district: 6,
		shape: "square",
		tourist: !1
	},
	{
		x: 8,
		y: 4,
		district: 7,
		shape: "pentagon",
		tourist: !1
	},
	{
		x: 0,
		y: 5,
		district: 5,
		shape: "pentagon",
		tourist: !1
	},
	{
		x: 2,
		y: 5,
		district: 5,
		shape: "square",
		tourist: !1
	},
	{
		x: 4,
		y: 5,
		district: 6,
		shape: "circle",
		tourist: !1
	},
	{
		x: 7,
		y: 5,
		district: 7,
		shape: "circle",
		tourist: !1
	},
	{
		x: 3,
		y: 6,
		district: 6,
		shape: "pentagon",
		tourist: !1
	},
	{
		x: 4,
		y: 6,
		district: 6,
		shape: "triangle",
		tourist: !1
	},
	{
		x: 6,
		y: 6,
		district: 6,
		shape: "square",
		tourist: !1
	},
	{
		x: 7,
		y: 6,
		district: 7,
		shape: "triangle",
		tourist: !1
	},
	{
		x: 9,
		y: 6,
		district: 7,
		shape: "triangle",
		tourist: !0
	},
	{
		x: 0,
		y: 7,
		district: 9,
		shape: "circle",
		tourist: !1
	},
	{
		x: 2,
		y: 7,
		district: 9,
		shape: "square",
		tourist: !1
	},
	{
		x: 3,
		y: 7,
		district: 10,
		shape: "circle",
		tourist: !1
	},
	{
		x: 5,
		y: 7,
		district: 10,
		shape: "pentagon",
		tourist: !1
	},
	{
		x: 8,
		y: 7,
		district: 11,
		shape: "circle",
		tourist: !1
	},
	{
		x: 9,
		y: 7,
		district: 11,
		shape: "pentagon",
		tourist: !1
	},
	{
		x: 1,
		y: 8,
		district: 9,
		shape: "circle",
		tourist: !1
	},
	{
		x: 6,
		y: 8,
		district: 10,
		shape: "pentagon",
		tourist: !1
	},
	{
		x: 8,
		y: 8,
		district: 11,
		shape: "triangle",
		tourist: !1
	},
	{
		x: 0,
		y: 9,
		district: 8,
		shape: "triangle",
		tourist: !1
	},
	{
		x: 1,
		y: 9,
		district: 9,
		shape: "square",
		tourist: !1
	},
	{
		x: 3,
		y: 9,
		district: 10,
		shape: "pentagon",
		tourist: !1
	},
	{
		x: 4,
		y: 9,
		district: 10,
		shape: "circle",
		tourist: !0
	},
	{
		x: 5,
		y: 9,
		district: 10,
		shape: "triangle",
		tourist: !1
	},
	{
		x: 7,
		y: 9,
		district: 11,
		shape: "circle",
		tourist: !1
	},
	{
		x: 9,
		y: 9,
		district: 12,
		shape: "square",
		tourist: !1
	}
], O = [
	{
		a: 0,
		b: 1,
		thames: !1
	},
	{
		a: 0,
		b: 7,
		thames: !1
	},
	{
		a: 0,
		b: 12,
		thames: !1
	},
	{
		a: 1,
		b: 2,
		thames: !1
	},
	{
		a: 1,
		b: 7,
		thames: !1
	},
	{
		a: 1,
		b: 13,
		thames: !1
	},
	{
		a: 2,
		b: 3,
		thames: !1
	},
	{
		a: 2,
		b: 7,
		thames: !1
	},
	{
		a: 2,
		b: 8,
		thames: !1
	},
	{
		a: 2,
		b: 17,
		thames: !1
	},
	{
		a: 3,
		b: 4,
		thames: !1
	},
	{
		a: 3,
		b: 8,
		thames: !1
	},
	{
		a: 3,
		b: 14,
		thames: !1
	},
	{
		a: 3,
		b: 18,
		thames: !1
	},
	{
		a: 4,
		b: 5,
		thames: !1
	},
	{
		a: 4,
		b: 9,
		thames: !1
	},
	{
		a: 4,
		b: 13,
		thames: !1
	},
	{
		a: 4,
		b: 19,
		thames: !1
	},
	{
		a: 5,
		b: 6,
		thames: !1
	},
	{
		a: 5,
		b: 9,
		thames: !1
	},
	{
		a: 5,
		b: 10,
		thames: !1
	},
	{
		a: 5,
		b: 21,
		thames: !1
	},
	{
		a: 6,
		b: 10,
		thames: !1
	},
	{
		a: 6,
		b: 11,
		thames: !1
	},
	{
		a: 7,
		b: 8,
		thames: !1
	},
	{
		a: 7,
		b: 12,
		thames: !1
	},
	{
		a: 7,
		b: 23,
		thames: !0
	},
	{
		a: 7,
		b: 25,
		thames: !1
	},
	{
		a: 8,
		b: 9,
		thames: !1
	},
	{
		a: 8,
		b: 13,
		thames: !1
	},
	{
		a: 8,
		b: 19,
		thames: !1
	},
	{
		a: 9,
		b: 10,
		thames: !1
	},
	{
		a: 9,
		b: 14,
		thames: !1
	},
	{
		a: 9,
		b: 18,
		thames: !1
	},
	{
		a: 10,
		b: 11,
		thames: !1
	},
	{
		a: 10,
		b: 15,
		thames: !1
	},
	{
		a: 10,
		b: 20,
		thames: !1
	},
	{
		a: 10,
		b: 27,
		thames: !1
	},
	{
		a: 11,
		b: 15,
		thames: !1
	},
	{
		a: 11,
		b: 21,
		thames: !1
	},
	{
		a: 12,
		b: 13,
		thames: !1
	},
	{
		a: 12,
		b: 16,
		thames: !1
	},
	{
		a: 12,
		b: 24,
		thames: !0
	},
	{
		a: 13,
		b: 14,
		thames: !1
	},
	{
		a: 13,
		b: 17,
		thames: !1
	},
	{
		a: 13,
		b: 18,
		thames: !1
	},
	{
		a: 13,
		b: 32,
		thames: !0
	},
	{
		a: 14,
		b: 15,
		thames: !1
	},
	{
		a: 14,
		b: 19,
		thames: !1
	},
	{
		a: 14,
		b: 20,
		thames: !1
	},
	{
		a: 14,
		b: 21,
		thames: !1
	},
	{
		a: 15,
		b: 22,
		thames: !1
	},
	{
		a: 16,
		b: 17,
		thames: !1
	},
	{
		a: 16,
		b: 23,
		thames: !0
	},
	{
		a: 16,
		b: 28,
		thames: !0
	},
	{
		a: 17,
		b: 18,
		thames: !1
	},
	{
		a: 17,
		b: 23,
		thames: !0
	},
	{
		a: 17,
		b: 24,
		thames: !0
	},
	{
		a: 17,
		b: 30,
		thames: !1
	},
	{
		a: 18,
		b: 19,
		thames: !1
	},
	{
		a: 18,
		b: 25,
		thames: !1
	},
	{
		a: 18,
		b: 26,
		thames: !1
	},
	{
		a: 18,
		b: 29,
		thames: !0
	},
	{
		a: 19,
		b: 20,
		thames: !1
	},
	{
		a: 19,
		b: 25,
		thames: !1
	},
	{
		a: 19,
		b: 26,
		thames: !1
	},
	{
		a: 19,
		b: 31,
		thames: !0
	},
	{
		a: 20,
		b: 21,
		thames: !1
	},
	{
		a: 20,
		b: 26,
		thames: !1
	},
	{
		a: 20,
		b: 34,
		thames: !0
	},
	{
		a: 20,
		b: 36,
		thames: !0
	},
	{
		a: 21,
		b: 22,
		thames: !1
	},
	{
		a: 21,
		b: 27,
		thames: !1
	},
	{
		a: 21,
		b: 31,
		thames: !0
	},
	{
		a: 21,
		b: 33,
		thames: !0
	},
	{
		a: 22,
		b: 27,
		thames: !1
	},
	{
		a: 22,
		b: 36,
		thames: !0
	},
	{
		a: 23,
		b: 24,
		thames: !1
	},
	{
		a: 23,
		b: 28,
		thames: !1
	},
	{
		a: 23,
		b: 29,
		thames: !1
	},
	{
		a: 23,
		b: 43,
		thames: !1
	},
	{
		a: 24,
		b: 25,
		thames: !0
	},
	{
		a: 24,
		b: 29,
		thames: !1
	},
	{
		a: 24,
		b: 33,
		thames: !1
	},
	{
		a: 25,
		b: 26,
		thames: !1
	},
	{
		a: 25,
		b: 30,
		thames: !1
	},
	{
		a: 25,
		b: 34,
		thames: !0
	},
	{
		a: 26,
		b: 27,
		thames: !1
	},
	{
		a: 26,
		b: 30,
		thames: !1
	},
	{
		a: 26,
		b: 35,
		thames: !0
	},
	{
		a: 26,
		b: 40,
		thames: !0
	},
	{
		a: 27,
		b: 31,
		thames: !0
	},
	{
		a: 27,
		b: 41,
		thames: !0
	},
	{
		a: 28,
		b: 29,
		thames: !1
	},
	{
		a: 28,
		b: 37,
		thames: !1
	},
	{
		a: 28,
		b: 38,
		thames: !1
	},
	{
		a: 29,
		b: 30,
		thames: !0
	},
	{
		a: 29,
		b: 32,
		thames: !1
	},
	{
		a: 29,
		b: 37,
		thames: !1
	},
	{
		a: 29,
		b: 38,
		thames: !1
	},
	{
		a: 30,
		b: 31,
		thames: !0
	},
	{
		a: 30,
		b: 32,
		thames: !0
	},
	{
		a: 30,
		b: 33,
		thames: !0
	},
	{
		a: 31,
		b: 34,
		thames: !1
	},
	{
		a: 31,
		b: 35,
		thames: !1
	},
	{
		a: 31,
		b: 42,
		thames: !1
	},
	{
		a: 32,
		b: 33,
		thames: !1
	},
	{
		a: 32,
		b: 38,
		thames: !1
	},
	{
		a: 32,
		b: 39,
		thames: !1
	},
	{
		a: 33,
		b: 34,
		thames: !1
	},
	{
		a: 33,
		b: 39,
		thames: !1
	},
	{
		a: 33,
		b: 40,
		thames: !1
	},
	{
		a: 33,
		b: 49,
		thames: !1
	},
	{
		a: 34,
		b: 35,
		thames: !1
	},
	{
		a: 34,
		b: 40,
		thames: !1
	},
	{
		a: 34,
		b: 44,
		thames: !1
	},
	{
		a: 34,
		b: 45,
		thames: !1
	},
	{
		a: 35,
		b: 36,
		thames: !1
	},
	{
		a: 35,
		b: 41,
		thames: !1
	},
	{
		a: 35,
		b: 49,
		thames: !1
	},
	{
		a: 35,
		b: 51,
		thames: !1
	},
	{
		a: 36,
		b: 41,
		thames: !1
	},
	{
		a: 36,
		b: 42,
		thames: !1
	},
	{
		a: 37,
		b: 38,
		thames: !1
	},
	{
		a: 37,
		b: 43,
		thames: !1
	},
	{
		a: 37,
		b: 46,
		thames: !1
	},
	{
		a: 38,
		b: 39,
		thames: !1
	},
	{
		a: 38,
		b: 43,
		thames: !1
	},
	{
		a: 38,
		b: 49,
		thames: !1
	},
	{
		a: 39,
		b: 40,
		thames: !1
	},
	{
		a: 39,
		b: 47,
		thames: !1
	},
	{
		a: 39,
		b: 48,
		thames: !1
	},
	{
		a: 39,
		b: 50,
		thames: !1
	},
	{
		a: 40,
		b: 41,
		thames: !1
	},
	{
		a: 40,
		b: 44,
		thames: !1
	},
	{
		a: 40,
		b: 48,
		thames: !1
	},
	{
		a: 40,
		b: 50,
		thames: !1
	},
	{
		a: 41,
		b: 42,
		thames: !1
	},
	{
		a: 41,
		b: 45,
		thames: !1
	},
	{
		a: 42,
		b: 45,
		thames: !1
	},
	{
		a: 42,
		b: 52,
		thames: !1
	},
	{
		a: 43,
		b: 44,
		thames: !1
	},
	{
		a: 43,
		b: 46,
		thames: !1
	},
	{
		a: 43,
		b: 47,
		thames: !1
	},
	{
		a: 44,
		b: 45,
		thames: !1
	},
	{
		a: 44,
		b: 50,
		thames: !1
	},
	{
		a: 44,
		b: 51,
		thames: !1
	},
	{
		a: 45,
		b: 51,
		thames: !1
	},
	{
		a: 45,
		b: 52,
		thames: !1
	},
	{
		a: 46,
		b: 47,
		thames: !1
	},
	{
		a: 47,
		b: 48,
		thames: !1
	},
	{
		a: 48,
		b: 49,
		thames: !1
	},
	{
		a: 49,
		b: 50,
		thames: !1
	},
	{
		a: 50,
		b: 51,
		thames: !1
	},
	{
		a: 51,
		b: 52,
		thames: !1
	}
], k = "M10.021,4.428L6.131,4.428C6.047,4.428 5.967,4.461 5.908,4.520L5.090,5.343C5.031,5.402 4.951,5.435 4.868,5.435L4.383,5.435L3.935,5.435C3.853,5.435 3.774,5.403 3.715,5.346L3.573,5.207C3.554,5.189 3.541,5.167 3.533,5.143L3.445,4.876C3.430,4.829 3.404,4.787 3.369,4.752L2.178,3.555C2.119,3.494 2.037,3.460 1.953,3.460L-1.011,3.460", A = [
	"blue",
	"green",
	"pink",
	"purple"
], j = new Map(D.map((e, t) => [`${e.x},${e.y}`, t])), M = (e, t) => {
	let n = j.get(`${e},${t}`);
	if (n === void 0) throw Error(`station missing at ${e},${t}`);
	return n;
}, N = {
	blue: M(5, 7),
	green: M(3, 2),
	pink: M(7, 3),
	purple: M(2, 5)
}, ee = M(5, 3), te = D.flatMap((e, t) => e.tourist ? [t] : []), ne = [
	0,
	1,
	2,
	4,
	6,
	8,
	11,
	14,
	17,
	21,
	25
], P = [
	0,
	0,
	2,
	5,
	9
], re = [
	"pink:square",
	"pink:triangle",
	"pink:pentagon",
	"pink:circle",
	"pink:joker",
	"blue:square",
	"blue:triangle",
	"blue:pentagon",
	"blue:circle",
	"blue:joker",
	"blue:switch"
];
function F(e) {
	let [t, n] = e.split(":");
	return {
		pink: t === "pink",
		shape: n === "joker" || n === "switch" ? null : n,
		joker: n === "joker",
		switch: n === "switch"
	};
}
var ie = [
	"interchange8",
	"districts13",
	"tourists5",
	"central9",
	"thames6"
], I = (() => {
	let e = D.map(() => []);
	return O.forEach((t, n) => {
		e[t.a].push(n), e[t.b].push(n);
	}), e;
})();
function L(e, t) {
	let n = O[e];
	return n.a === t ? n.b : n.a;
}
function R(e, t) {
	let n = O[t];
	return e.stations.includes(n.a) ? n.b : n.a;
}
function ae(e, t, n, r) {
	let i = D[e], a = D[t], o = D[n], s = D[r], c = (a.x - i.x) * (o.y - i.y) - (a.y - i.y) * (o.x - i.x), l = (a.x - i.x) * (s.y - i.y) - (a.y - i.y) * (s.x - i.x), u = (s.x - o.x) * (i.y - o.y) - (s.y - o.y) * (i.x - o.x), d = (s.x - o.x) * (a.y - o.y) - (s.y - o.y) * (a.x - o.x);
	return c * l < 0 && u * d < 0;
}
var oe = O.map((e, t) => {
	let n = [];
	return O.forEach((r, i) => {
		t !== i && e.a !== r.a && e.a !== r.b && e.b !== r.a && e.b !== r.b && ae(e.a, e.b, r.a, r.b) && n.push(i);
	}), n;
});
function se(e) {
	return {
		stations: [N[e]],
		edges: []
	};
}
function ce(e, t) {
	if (e.edges.length === 0) return [N[t]];
	let n = /* @__PURE__ */ new Map();
	for (let t of e.edges) {
		let { a: e, b: r } = O[t];
		n.set(e, (n.get(e) ?? 0) + 1), n.set(r, (n.get(r) ?? 0) + 1);
	}
	return e.stations.filter((e) => (n.get(e) ?? 0) === 1);
}
function le() {
	return {
		lines: A.map(se),
		lineScores: [],
		tourist: 0
	};
}
function z(e, t, n, r) {
	if (n.switch) return [];
	let i = e.lines[t], a = new Set(i.stations), o = r ? i.stations : ce(i, A[t]), s = new Set(e.lines.flatMap((e) => e.edges)), c = /* @__PURE__ */ new Set();
	for (let e of o) for (let t of I[e]) {
		if (s.has(t)) continue;
		let r = L(t, e);
		a.has(r) || (n.joker || r === ee || D[r].shape === n.shape) && (oe[t].some((e) => s.has(e)) || c.add(t));
	}
	return [...c];
}
function B(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.stations) {
		let e = D[n].district;
		t.set(e, (t.get(e) ?? 0) + 1);
	}
	let n = Math.max(...t.values()), r = e.edges.filter((e) => O[e].thames).length;
	return t.size * n + r * 2;
}
function V(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.lines) for (let e of n.stations) t.set(e, (t.get(e) ?? 0) + 1);
	return t;
}
function ue(e) {
	let t = 0;
	for (let n of V(e).values()) t += P[n] ?? 0;
	return t;
}
function H(e) {
	let t = V(e), n = new Set(e.lines.flatMap((e) => e.stations)), r = new Set([...n].map((e) => D[e].district)), i = e.lines.reduce((e, t) => e + t.edges.filter((e) => O[e].thames).length, 0);
	return {
		interchange8: [...t.values()].filter((e) => e >= 2).length >= 8,
		districts13: r.size >= 13,
		tourists5: te.every((e) => n.has(e)),
		central9: D.every((e, t) => e.district !== 6 || n.has(t)),
		thames6: i >= 6
	};
}
function U(e, t) {
	let n = e.lineScores, r = ne[Math.min(e.tourist, 10)], i = ue(e), a = H(e), o = t.reduce((e, t) => e + (a[t] ? 10 : 0), 0);
	return {
		lines: [...n],
		tourist: r,
		interchange: i,
		objectives: o,
		total: n.reduce((e, t) => e + t, 0) + r + i + o
	};
}
//#endregion
//#region src/games/nextstation/meta.ts
var W = {
	id: "nextstation",
	tier: "beta",
	mechanics: ["roll-and-write", "route-building"],
	interactionTags: [],
	nameKey: "games.nextstation.name",
	descKey: "games.nextstation.desc",
	rulesKey: "games.nextstation.rules",
	icon: "🚇",
	iconImg: "games/nextstation.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/nextstation/en.pdf" },
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [2, 4],
	accent: "#1d4ed8",
	releasedAt: "2026-09-21",
	search: {
		py: "xia yi zhan lun dun",
		init: "xyzld"
	},
	hotseat: "open"
}, G = t.object({ objectives: t.boolean() }).prefault({ objectives: !1 }), de = t.int().min(0).max(154), fe = t.discriminatedUnion("type", [t.object({
	type: t.literal("draw"),
	edge: de
}), t.object({ type: t.literal("pass") })]), pe = t.enum([
	"pink:square",
	"pink:triangle",
	"pink:pentagon",
	"pink:circle",
	"pink:joker",
	"blue:square",
	"blue:triangle",
	"blue:pentagon",
	"blue:circle",
	"blue:joker",
	"blue:switch"
]), me = t.enum([
	"interchange8",
	"districts13",
	"tourists5",
	"central9",
	"thames6"
]), he = t.object({
	stations: t.array(t.int().min(0).max(52)),
	edges: t.array(de)
}), ge = t.object({
	lines: t.array(he).length(4),
	lineScores: t.array(t.int().min(0)).max(4),
	tourist: t.int().min(0).max(10)
}), _e = t.object({
	players: t.array(t.string()).min(1).max(4),
	round: t.int().min(0).max(3),
	color: t.enum([
		"blue",
		"green",
		"pink",
		"purple"
	]),
	phase: t.enum(["play", "done"]),
	revealed: t.array(pe),
	pendingSwitch: t.boolean(),
	lastCard: t.boolean(),
	responded: t.array(t.string()),
	boards: t.record(t.string(), ge),
	objectives: t.array(me),
	scores: t.record(t.string(), t.number())
}), ve = t.object({}), K = {
	over: "games.nextstation.errOver",
	alreadyDone: "games.nextstation.errAlreadyDone",
	badEdge: "games.nextstation.errBadEdge"
};
function q(e, t) {
	let n = e.decks[e.round];
	for (;;) {
		e.cardIdx += 1;
		let r = n[e.cardIdx];
		e.revealed.push(r);
		let i = F(r);
		if (i.pink && (e.pinkSeen += 1), i.switch) {
			e.revealed.length > 2 && (e.pendingSwitch = !0);
			continue;
		}
		t.push({
			kind: "flip",
			data: {
				card: r,
				switch: e.pendingSwitch
			}
		});
		return;
	}
}
function ye(e, t) {
	for (let n of e.players) {
		let r = e.boards[n], i = B(r.lines[e.round]);
		r.lineScores.push(i);
		let a = r.lines[e.round].stations.filter((e) => D[e].tourist).length;
		r.tourist = Math.min(10, r.tourist + a), t.push({
			kind: "score",
			rid: n,
			data: {
				round: e.round,
				pts: i
			}
		});
	}
	if (e.round === 3) {
		e.phase = "done";
		return;
	}
	e.round += 1, e.cardIdx = -1, e.pinkSeen = 0, e.pendingSwitch = !1, e.revealed = [], e.responded = [], q(e, t);
}
function be(t, n, r) {
	let i = 0, a = (t) => {
		for (let n = t.length - 1; n > 0; n--) {
			let a = e(r, i++, n + 1);
			[t[n], t[a]] = [t[a], t[n]];
		}
		return t;
	}, o = Array.from({ length: 4 }, () => a([...re])), s = t.objectives ? a([...ie]).slice(0, 2) : [], c = {};
	for (let e of n) c[e] = le();
	let l = {
		players: n,
		objectives: s,
		round: 0,
		decks: o,
		cardIdx: -1,
		pinkSeen: 0,
		pendingSwitch: !1,
		revealed: [],
		responded: [],
		boards: c,
		phase: "play"
	}, u = [];
	return q(l, u), {
		state: l,
		fx: u
	};
}
function xe(e, t, n) {
	if (e.phase !== "play") return { code: K.over };
	if (e.responded.includes(n.by)) return { code: K.alreadyDone };
	let r = structuredClone(e), i = [], a = F(r.decks[r.round][r.cardIdx]);
	if (t.type === "draw") {
		if (!z(r.boards[n.by], r.round, a, r.pendingSwitch).includes(t.edge)) return { code: K.badEdge };
		let e = r.boards[n.by].lines[r.round], o = O[t.edge], s = e.stations.includes(o.a) ? o.a : o.b;
		e.edges.push(t.edge), e.stations.push(L(t.edge, s)), i.push({
			kind: "draw",
			rid: n.by,
			data: {
				edge: t.edge,
				round: r.round
			}
		});
	}
	return r.responded.push(n.by), r.responded.length >= r.players.length && (r.pinkSeen >= 5 ? ye(r, i) : (r.responded = [], q(r, i))), {
		state: r,
		fx: i
	};
}
function Se(e) {
	let t = {};
	for (let n of e.players) t[n] = U(e.boards[n], e.objectives).total;
	return {
		public: {
			players: e.players,
			round: e.round,
			color: A[e.round],
			phase: e.phase,
			revealed: e.revealed,
			pendingSwitch: e.pendingSwitch,
			lastCard: e.pinkSeen >= 5,
			responded: e.responded,
			boards: e.boards,
			objectives: e.objectives,
			scores: t
		},
		private: {}
	};
}
function Ce(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = {}, n = {};
	for (let r of e.players) t[r] = U(e.boards[r], e.objectives).total, n[r] = Math.max(...e.boards[r].lineScores);
	let r = [...e.players].sort((r, i) => t[i] === t[r] ? n[i] === n[r] ? e.players.indexOf(r) - e.players.indexOf(i) : n[i] - n[r] : t[i] - t[r]), i = r[0];
	return {
		phase: "done",
		winner: r.filter((e) => t[e] === t[i] && n[e] === n[i]),
		ranking: r,
		scores: t
	};
}
var we = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: W,
	schemas: {
		action: fe,
		publicView: _e,
		privateView: ve,
		config: G
	},
	setup: be,
	reduce: xe,
	viewFor: Se,
	status: Ce
}, J = 1040, Y = J, X = (e) => 70 + e * 100, Z = (e) => 70 + e * 100, Q = {
	blue: "#3b82f6",
	green: "#16a34a",
	pink: "#ec4899",
	purple: "#9333ea"
};
function Te({ shape: e, cx: t, cy: n, size: r, fill: i, stroke: a, strokeWidth: o = 4 }) {
	let s = r / 2;
	if (e === "square") return /* @__PURE__ */ x("rect", {
		x: t - s,
		y: n - s,
		width: r,
		height: r,
		rx: r * .15,
		fill: i,
		stroke: a,
		strokeWidth: o
	});
	if (e === "circle") return /* @__PURE__ */ x("circle", {
		cx: t,
		cy: n,
		r: s,
		fill: i,
		stroke: a,
		strokeWidth: o
	});
	if (e === "triangle") return /* @__PURE__ */ x("polygon", {
		points: `${t},${n - s} ${t + s},${n + s} ${t - s},${n + s}`,
		fill: i,
		stroke: a,
		strokeWidth: o,
		strokeLinejoin: "round"
	});
	if (e === "pentagon") {
		let e = Array.from({ length: 5 }, (e, r) => {
			let i = Math.PI * 2 * r / 5 - Math.PI / 2;
			return `${(t + s * Math.cos(i)).toFixed(1)},${(n + s * Math.sin(i)).toFixed(1)}`;
		});
		return /* @__PURE__ */ x("polygon", {
			points: e.join(" "),
			fill: i,
			stroke: a,
			strokeWidth: o,
			strokeLinejoin: "round"
		});
	}
	return /* @__PURE__ */ x("text", {
		x: t,
		y: n,
		textAnchor: "middle",
		dominantBaseline: "central",
		fontSize: r * 1.3,
		fontWeight: 900,
		fill: i,
		children: "?"
	});
}
var $ = 30;
function Ee(e) {
	let t = D[e];
	return {
		x: X(t.x) - $ - 20,
		y: Z(t.y) - $ - 20,
		w: 100,
		h: 100
	};
}
var De = new Map(A.map((e) => [N[e], e]));
function Oe({ board: e, currentRound: t, candidateEdges: n, selectedTarget: r, eligible: a, onTapEligible: o, readOnly: s, fitKey: c }) {
	let l = i(() => V(e), [e]), u = i(() => new Set((n ?? []).map((n) => R(e.lines[t], n))), [
		e,
		n,
		t
	]), d = i(() => new Set(r == null ? [] : (n ?? []).map((e) => L(e, r))), [n, r]), f = Q[A[t]];
	return /* @__PURE__ */ S(y, {
		sheetW: J,
		sheetH: Y,
		eligible: a,
		onTapEligible: o,
		readOnly: s,
		fitKey: c,
		clampToSheet: !0,
		highlight: "off",
		children: [
			/* @__PURE__ */ x("rect", {
				x: 0,
				y: 0,
				width: J,
				height: Y,
				rx: 24,
				fill: "var(--color-surface)"
			}),
			/* @__PURE__ */ x("image", {
				href: "./games/nextstation/board.webp",
				x: 0,
				y: 0,
				width: J,
				height: Y,
				preserveAspectRatio: "none"
			}),
			/* @__PURE__ */ x("rect", {
				x: 20,
				y: 20,
				width: 1e3,
				height: 1e3,
				rx: 18,
				fill: "var(--color-surface)",
				opacity: .68
			}),
			/* @__PURE__ */ x("rect", {
				x: 2,
				y: 2,
				width: 1036,
				height: 1036,
				rx: 22,
				fill: "none",
				stroke: "var(--color-info-ink)",
				strokeOpacity: .55,
				strokeWidth: 5
			}),
			/* @__PURE__ */ S("g", {
				clipPath: "url(#nsl-clip)",
				children: [
					/* @__PURE__ */ S("g", {
						stroke: "var(--color-warn)",
						strokeWidth: 6,
						opacity: .78,
						pointerEvents: "none",
						children: [
							/* @__PURE__ */ x("line", {
								x1: X(2.5),
								y1: Z(0),
								x2: X(2.5),
								y2: Z(9)
							}),
							/* @__PURE__ */ x("line", {
								x1: X(6.5),
								y1: Z(0),
								x2: X(6.5),
								y2: Z(9)
							}),
							/* @__PURE__ */ x("line", {
								x1: X(0),
								y1: Z(2.5),
								x2: X(9),
								y2: Z(2.5)
							}),
							/* @__PURE__ */ x("line", {
								x1: X(0),
								y1: Z(6.5),
								x2: X(9),
								y2: Z(6.5)
							}),
							[
								`M ${X(.9)} ${Z(0)} A 90 90 0 0 0 ${X(0)} ${Z(.9)}`,
								`M ${X(8.1)} ${Z(0)} A 90 90 0 0 1 ${X(9)} ${Z(.9)}`,
								`M ${X(0)} ${Z(8.1)} A 90 90 0 0 0 ${X(.9)} ${Z(9)}`,
								`M ${X(9)} ${Z(8.1)} A 90 90 0 0 1 ${X(8.1)} ${Z(9)}`
							].map((e, t) => /* @__PURE__ */ x("path", {
								d: e,
								fill: "none"
							}, t))
						]
					}),
					/* @__PURE__ */ S("g", {
						transform: "translate(70 70) scale(100)",
						pointerEvents: "none",
						children: [
							/* @__PURE__ */ x("path", {
								d: k,
								fill: "none",
								stroke: "var(--color-surface)",
								strokeWidth: .46,
								strokeLinecap: "round"
							}),
							/* @__PURE__ */ x("path", {
								d: k,
								fill: "none",
								stroke: "var(--color-info)",
								strokeWidth: .34,
								strokeLinecap: "round",
								opacity: .55
							}),
							/* @__PURE__ */ x("path", {
								d: k,
								fill: "none",
								stroke: "var(--color-info-ink)",
								strokeWidth: .05,
								strokeLinecap: "round",
								opacity: .6
							})
						]
					}),
					/* @__PURE__ */ x("g", {
						stroke: "var(--color-info-ink)",
						strokeOpacity: .23,
						strokeWidth: 7,
						strokeLinecap: "round",
						strokeDasharray: "19 23",
						pointerEvents: "none",
						children: O.map((e, t) => /* @__PURE__ */ x("line", {
							x1: X(D[e.a].x),
							y1: Z(D[e.a].y),
							x2: X(D[e.b].x),
							y2: Z(D[e.b].y)
						}, t))
					}),
					/* @__PURE__ */ x("g", {
						pointerEvents: "none",
						fill: "none",
						strokeLinecap: "round",
						children: n?.map((e) => {
							let { a: t, b: n } = O[e], r = `M ${X(D[t].x)} ${Z(D[t].y)} L ${X(D[n].x)} ${Z(D[n].y)}`;
							return /* @__PURE__ */ S("g", { children: [/* @__PURE__ */ x("path", {
								d: r,
								stroke: "var(--color-surface)",
								strokeWidth: 27,
								opacity: .9
							}), /* @__PURE__ */ x("path", {
								d: r,
								stroke: f,
								strokeWidth: 12,
								strokeDasharray: "18 14"
							})] }, e);
						})
					}),
					e.lines.map((e, n) => {
						let r = Q[A[n]], i = n === t ? e.edges.length - 1 : -1;
						return /* @__PURE__ */ x("g", {
							pointerEvents: "none",
							strokeLinecap: "round",
							children: e.edges.map((e, t) => {
								let { a: n, b: a } = O[e], o = Math.hypot((D[a].x - D[n].x) * 100, (D[a].y - D[n].y) * 100), s = t === i;
								return /* @__PURE__ */ S("g", { children: [/* @__PURE__ */ x("line", {
									x1: X(D[n].x),
									y1: Z(D[n].y),
									x2: X(D[a].x),
									y2: Z(D[a].y),
									stroke: "var(--color-surface)",
									strokeWidth: 32
								}), /* @__PURE__ */ x("line", {
									className: s ? "nsl-line-draw" : void 0,
									x1: X(D[n].x),
									y1: Z(D[n].y),
									x2: X(D[a].x),
									y2: Z(D[a].y),
									stroke: r,
									strokeWidth: 19,
									strokeDasharray: s ? o : void 0,
									strokeDashoffset: s ? o : void 0,
									children: s && /* @__PURE__ */ x("animate", {
										attributeName: "stroke-dashoffset",
										from: o,
										to: 0,
										dur: "0.35s",
										fill: "freeze"
									})
								})] }, e);
							})
						}, n);
					}),
					D.map((e, t) => {
						let n = X(e.x), i = Z(e.y), a = De.get(t), o = (l.get(t) ?? 0) >= 2, s = u.has(t), c = d.has(t), p = r === t, m = a ? Q[a] : "var(--color-surface)", h = a ? "var(--color-surface)" : "var(--color-info-ink)";
						return /* @__PURE__ */ S("g", {
							pointerEvents: "none",
							children: [
								o && /* @__PURE__ */ x("circle", {
									cx: n,
									cy: i,
									r: 45,
									fill: "none",
									stroke: "var(--color-info-ink)",
									strokeWidth: 5
								}),
								e.tourist && /* @__PURE__ */ x("circle", {
									cx: n,
									cy: i,
									r: 41,
									fill: "var(--color-surface)",
									stroke: "var(--color-pop)",
									strokeWidth: 6
								}),
								/* @__PURE__ */ x("circle", {
									cx: n,
									cy: i,
									r: $,
									fill: m,
									stroke: a ? "var(--color-surface)" : "var(--color-info-ink)",
									strokeWidth: a ? 6 : 5
								}),
								/* @__PURE__ */ x(Te, {
									shape: e.shape,
									cx: n,
									cy: i,
									size: 25,
									fill: e.shape === "wild" ? h : "none",
									stroke: h,
									strokeWidth: 5
								}),
								(s || c || p) && /* @__PURE__ */ x("circle", {
									className: p ? void 0 : "nsl-candidate-ring",
									cx: n,
									cy: i,
									r: 43,
									fill: "none",
									stroke: f,
									strokeWidth: p ? 8 : 6,
									strokeDasharray: p ? void 0 : "11 9",
									children: !p && /* @__PURE__ */ x("animate", {
										attributeName: "stroke-dashoffset",
										from: "0",
										to: "-20",
										dur: "2.4s",
										repeatCount: "indefinite"
									})
								})
							]
						}, t);
					})
				]
			}),
			/* @__PURE__ */ x("defs", { children: /* @__PURE__ */ x("clipPath", {
				id: "nsl-clip",
				children: /* @__PURE__ */ x("rect", {
					x: 4,
					y: 4,
					width: 1032,
					height: 1032,
					rx: 20
				})
			}) })
		]
	});
}
//#endregion
//#region src/games/nextstation/view-player.tsx
var ke = {
	blue: "games.nextstation.lineColor.blue",
	green: "games.nextstation.lineColor.green",
	pink: "games.nextstation.lineColor.pink",
	purple: "games.nextstation.lineColor.purple"
}, Ae = {
	square: "games.nextstation.cardAria.square",
	triangle: "games.nextstation.cardAria.triangle",
	pentagon: "games.nextstation.cardAria.pentagon",
	circle: "games.nextstation.cardAria.circle",
	joker: "games.nextstation.cardAria.joker",
	switch: "games.nextstation.cardAria.switch"
};
function je({ id: e }) {
	let t = l(), n = F(e), { ref: r } = s("card"), i = e.split(":")[1], a = t(n.pink ? "games.nextstation.cardUnderground" : "games.nextstation.cardStreet");
	return /* @__PURE__ */ S("span", {
		ref: r,
		role: "img",
		"aria-label": `${a} · ${t(Ae[i])}`,
		className: `nsl-station-card ${n.pink ? "nsl-station-card--tube" : "nsl-station-card--street"}`,
		children: [/* @__PURE__ */ x("span", {
			className: "nsl-station-card__band",
			children: a
		}), /* @__PURE__ */ x("span", {
			className: "nsl-station-card__symbol",
			children: n.joker ? /* @__PURE__ */ x("span", {
				className: "nsl-station-card__special",
				children: "★"
			}) : n.switch ? /* @__PURE__ */ x("span", {
				className: "nsl-station-card__special",
				children: "🔀"
			}) : /* @__PURE__ */ x("svg", {
				viewBox: "0 0 48 48",
				"aria-hidden": "true",
				children: /* @__PURE__ */ x(Te, {
					shape: n.shape,
					cx: 24,
					cy: 24,
					size: 27,
					fill: "none",
					stroke: "var(--color-ink)",
					strokeWidth: 6
				})
			})
		})]
	});
}
function Me({ board: e, round: t }) {
	let n = l();
	return /* @__PURE__ */ x("ol", {
		className: "nsl-round-rail",
		"aria-label": n("games.nextstation.roundRail"),
		children: A.map((r, i) => /* @__PURE__ */ x("li", {
			className: `nsl-round-rail__stop ${i === t ? "nsl-round-rail__stop--active" : ""} ${i > t ? "nsl-round-rail__stop--future" : ""}`,
			"aria-label": `${n(ke[r])} ${e.lineScores[i] ?? "—"}`,
			children: /* @__PURE__ */ x("span", {
				className: "nsl-round-rail__disc",
				style: { backgroundColor: Q[r] },
				children: e.lineScores[i] ?? i + 1
			})
		}, r))
	});
}
function Ne(e) {
	let t = e.public;
	return /* @__PURE__ */ x(Pe, {
		pub: t,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Pe({ pub: e, members: t, myRid: n, send: r }) {
	let a = l(), [s, c] = o(n), [u, d] = o(null), p = e.boards[n], m = e.boards[s] ?? p, v = e.revealed[e.revealed.length - 1], y = F(v), b = e.revealed.filter((e) => e.startsWith("pink")).length, C = e.responded.includes(n), w = e.phase === "play" && !C && s === n, T = p.lines[e.round], E = i(() => {
		let t = /* @__PURE__ */ new Map();
		if (!w) return t;
		for (let n of z(p, e.round, y, e.pendingSwitch)) {
			let e = R(T, n), r = t.get(e);
			r ? r.push(n) : t.set(e, [n]);
		}
		return t;
	}, [
		w,
		p,
		T,
		e.round,
		y,
		e.pendingSwitch
	]), D = `${v}|${s}`, O = u && u.key === D ? u.target : null, k = i(() => O === null ? [...E.values()].flat() : E.get(O) ?? [], [E, O]), A = i(() => {
		if (w) return O === null ? [...E.keys()].map((e) => ({
			key: String(e),
			rect: Ee(e)
		})) : (E.get(O) ?? []).map((e) => ({
			key: String(e),
			rect: Ee(L(e, O))
		}));
	}, [
		w,
		O,
		E
	]), j = (e) => {
		if (w) {
			if (O === null) {
				let t = Number(e), n = E.get(t);
				if (!n || n.length === 0) return;
				n.length === 1 ? r({
					type: "draw",
					edge: n[0]
				}) : d({
					key: D,
					target: t
				});
				return;
			}
			r({
				type: "draw",
				edge: Number(e)
			}), d(null);
		}
	}, M = e.phase === "done" ? {
		tone: "done",
		text: a("games.nextstation.over")
	} : C ? {
		tone: "info",
		text: a("games.nextstation.waitingDraw")
	} : O === null ? E.size === 0 ? {
		tone: "warn",
		text: a("games.nextstation.noMoves")
	} : e.pendingSwitch ? {
		tone: "accent",
		text: a("games.nextstation.switchPrompt")
	} : {
		tone: "accent",
		text: a("games.nextstation.drawPrompt")
	} : {
		tone: "accent",
		text: a("games.nextstation.pickFrom")
	};
	return /* @__PURE__ */ x("div", {
		className: "nsl-root h-full min-h-0",
		style: {
			"--nsl-seat-columns": Math.min(2, e.players.length),
			"--nsl-seat-rows": Math.ceil(e.players.length / 2)
		},
		children: /* @__PURE__ */ x(h, {
			adaptive: !0,
			className: "nsl-layout",
			scroll: !1,
			actionsHeight: "nsl-actions-slot",
			banner: /* @__PURE__ */ S("div", {
				className: "nsl-banner",
				style: { "--nsl-line": Q[e.color] },
				children: [/* @__PURE__ */ x(g, {
					tone: M.tone,
					text: M.text,
					accent: W.accent,
					chip: `${a(ke[e.color])} ${e.round + 1}/4`,
					sub: e.phase === "play" && e.lastCard ? a("games.nextstation.lastCard") : void 0
				}), /* @__PURE__ */ x(_, {
					members: t.filter((t) => e.players.includes(t.rid)),
					myRid: n,
					variant: "plate",
					anchorOf: (e) => `seat:${e}`,
					status: (t) => /* @__PURE__ */ x("span", {
						className: "nsl-seat-score font-mono text-sm font-black tabular-nums",
						children: e.scores[t] ?? 0
					}),
					action: (t) => e.phase === "play" ? e.responded.includes(t) ? "done" : "pending" : null,
					onPick: (e) => c(e),
					picked: (e) => e === s
				})]
			}),
			actions: /* @__PURE__ */ S("div", {
				className: "nsl-actions",
				children: [e.phase === "play" && v && /* @__PURE__ */ x(je, { id: v }), /* @__PURE__ */ S("div", {
					className: "nsl-actions__side",
					children: [/* @__PURE__ */ S("div", {
						className: "nsl-progress",
						"aria-label": a("games.nextstation.pinkProgress", { n: b }),
						children: [
							/* @__PURE__ */ x("span", { children: a("games.nextstation.pinkProgress", { n: b }) }),
							e.pendingSwitch && /* @__PURE__ */ x("span", {
								role: "img",
								"aria-label": a("games.nextstation.switchPrompt"),
								children: "🔀"
							}),
							/* @__PURE__ */ x("span", {
								className: "nsl-progress__track",
								"aria-hidden": !0,
								children: /* @__PURE__ */ x("span", { style: { width: `${b * 20}%` } })
							})
						]
					}), e.phase === "play" && !C ? /* @__PURE__ */ x("button", {
						type: "button",
						onClick: O === null ? () => r({ type: "pass" }) : () => d(null),
						className: "btn-quiet nsl-pass font-bold",
						children: a(O === null ? "games.nextstation.pass" : "games.nextstation.cancelPick")
					}) : /* @__PURE__ */ x("span", {
						className: "nsl-wait-mark",
						role: "img",
						"aria-label": a("games.nextstation.waitingDraw"),
						children: /* @__PURE__ */ x(f, {
							size: 22,
							strokeWidth: 3,
							"aria-hidden": !0
						})
					})]
				})]
			}),
			children: /* @__PURE__ */ S("div", {
				className: "nsl-map-shell",
				children: [/* @__PURE__ */ x("div", {
					className: "nsl-map-viewport",
					children: /* @__PURE__ */ x(Oe, {
						board: m,
						currentRound: e.round,
						candidateEdges: k,
						selectedTarget: O,
						eligible: A,
						onTapEligible: j,
						readOnly: !w,
						fitKey: `${s}:${e.round}`
					})
				}), /* @__PURE__ */ x(Me, {
					board: m,
					round: e.round
				})]
			})
		})
	});
}
//#endregion
//#region src/games/nextstation/bot.ts
function Fe(e, t, n) {
	let r = e.lines[t], i = R(r, n), a = B({
		stations: [...r.stations, i],
		edges: [...r.edges, n]
	}) - B(r);
	D[i].tourist && e.tourist < 10 && (a += 2);
	let o = e.lines.filter((e) => e.stations.includes(i)).length;
	return a += (P[o + 1] ?? 9) - (P[o] ?? 0), a += I[i].length * .15, a;
}
var Ie = (e, t) => {
	let n = e.public;
	if (n.phase !== "play" || n.responded.includes(t.rid)) return null;
	let r = n.boards[t.rid];
	if (!r) return null;
	let i = F(n.revealed[n.revealed.length - 1]), a = z(r, n.round, i, n.pendingSwitch);
	if (a.length === 0) return { action: { type: "pass" } };
	if (t.difficulty === "weak") return Math.random() < .25 ? { action: { type: "pass" } } : { action: {
		type: "draw",
		edge: a[Math.floor(Math.random() * a.length)]
	} };
	let o = null;
	for (let e of a) {
		let t = Fe(r, n.round, e);
		(!o || t > o.v) && (o = {
			edge: e,
			v: t
		});
	}
	return !o || o.v < .5 ? { action: { type: "pass" } } : { action: {
		type: "draw",
		edge: o.edge
	} };
}, Le = {
	square: "games.nextstation.shapeName.square",
	triangle: "games.nextstation.shapeName.triangle",
	pentagon: "games.nextstation.shapeName.pentagon",
	circle: "games.nextstation.shapeName.circle",
	wild: "games.nextstation.shapeName.wild"
}, Re = (e, t, n) => {
	if (e.type === "pass") return n("games.nextstation.hintPass");
	let r = F(t.public.revealed[t.public.revealed.length - 1]);
	return n("games.nextstation.hintDraw", { shape: r.shape ? n(Le[r.shape]) : n("games.nextstation.shapeName.any") });
}, ze = {
	flip(e, t) {
		let n = t.anchor("card");
		return n ? {
			ms: 500,
			node: /* @__PURE__ */ x(w, {
				at: n,
				ms: 450
			})
		} : null;
	},
	score(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !r || typeof n?.pts != "number" ? null : {
			ms: 800,
			node: /* @__PURE__ */ x(C, {
				at: r,
				ms: 800,
				children: /* @__PURE__ */ S("span", {
					className: "font-mono font-black text-done-ink",
					style: { fontSize: Math.max(16, Math.min(34, r.h - 28)) },
					children: ["+", n.pts]
				})
			})
		};
	}
};
//#endregion
//#region src/games/nextstation/endgame-review.tsx
function Be({ board: e, renderResult: t, ...n }) {
	let s = l(), [c, d] = o(!0), [f, h] = o(null), g = a(null), _ = a(null), v = a(null);
	r(() => {
		if (!f) return;
		v.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => h(null), 5e3);
		return () => clearTimeout(e);
	}, [f]);
	let y = (e) => {
		h(null), d(e), requestAnimationFrame(() => (e ? g : _).current?.focus({ preventScroll: !0 }));
	}, b = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => h({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => h({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => h({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), C = {
		...n,
		...b
	};
	return /* @__PURE__ */ S("div", {
		className: "nextstation-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ x("div", {
				className: "nextstation-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ x("div", {
				className: "nextstation-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ S("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), y(!1));
					},
					className: "nextstation-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ S("header", {
							className: "nextstation-endgame-heading",
							children: [/* @__PURE__ */ S("div", {
								className: "nextstation-endgame-brand",
								children: [/* @__PURE__ */ x("span", {
									"aria-hidden": "true",
									children: W.icon
								}), s(W.nameKey)]
							}), /* @__PURE__ */ x("button", {
								type: "button",
								ref: g,
								className: "btn-quiet",
								"aria-label": s("games.nextstation.reviewHide"),
								title: s("games.nextstation.reviewHide"),
								onClick: () => y(!1),
								children: /* @__PURE__ */ x(p, { size: 19 })
							})]
						}),
						/* @__PURE__ */ x("div", {
							className: "nextstation-endgame-result",
							inert: f !== null,
							children: t(C)
						}),
						f && /* @__PURE__ */ S("div", {
							className: "nextstation-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || h(null);
							},
							children: [/* @__PURE__ */ x("button", {
								type: "button",
								ref: v,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = f.run;
									h(null), e();
								},
								children: s(f.label === "again" ? "games.nextstation.reviewConfirmAgain" : "games.nextstation.reviewConfirmLobby")
							}), /* @__PURE__ */ x("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									h(null), g.current?.focus({ preventScroll: !0 });
								},
								children: s("games.nextstation.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ x("div", {
				className: "nextstation-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ S("button", {
					type: "button",
					className: "btn-base",
					ref: _,
					onClick: () => y(!0),
					children: [
						/* @__PURE__ */ x(m, { size: 18 }),
						s("games.nextstation.reviewShow"),
						/* @__PURE__ */ x(u, { size: 18 })
					]
				})
			})
		]
	});
}
function Ve({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: s, rows: u, renderRowExtra: f, summary: m, navigation: h, content: g, afterRanking: _, scoreUnit: y, rankOf: C }) {
	let w = l(), E = c((e) => e.locale), [D, O] = o({}), k = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? v(n, E) : e;
	}, A = (t, n) => C?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), j = e.ranking.some((t) => e.scores?.[t] !== void 0), M = (t, n) => /* @__PURE__ */ S("div", {
		className: "nextstation-score-identity",
		children: [
			/* @__PURE__ */ S("span", {
				className: "nextstation-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ x("span", {
					"aria-label": w("games.nextstation.reviewWinner"),
					children: "♛ "
				}), j && A(t, n)]
			}),
			/* @__PURE__ */ S("span", {
				className: "nextstation-score-name",
				children: [k(t), t === r && /* @__PURE__ */ x("small", { children: w("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ S("small", {
				className: "nextstation-score-autopilot",
				children: [
					/* @__PURE__ */ x(d, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), N = (t) => e.ranking.map((n) => /* @__PURE__ */ x("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ S("div", {
		className: "nextstation-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ x(T, {}),
			h,
			/* @__PURE__ */ S("div", {
				className: "nextstation-score-body",
				children: [
					m && /* @__PURE__ */ x("div", {
						className: "nextstation-score-summary",
						children: m
					}),
					i !== void 0 && /* @__PURE__ */ x("p", {
						className: "nextstation-score-hints",
						children: w("session.hint.usedCount", { n: i })
					}),
					g ?? (u?.length ? /* @__PURE__ */ x("div", {
						className: "nextstation-score-table-scroll",
						children: /* @__PURE__ */ S("table", {
							className: "nextstation-score-table",
							"aria-label": w(W.nameKey),
							children: [
								/* @__PURE__ */ x("thead", { children: /* @__PURE__ */ S("tr", { children: [/* @__PURE__ */ x("th", { scope: "col" }), /* @__PURE__ */ x(b, { children: e.ranking.map((t, n) => /* @__PURE__ */ x("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: M(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ x("tbody", { children: u.map((e, t) => /* @__PURE__ */ S(n, { children: [/* @__PURE__ */ S("tr", { children: [/* @__PURE__ */ x("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ S("button", {
										type: "button",
										"aria-expanded": !!D[t],
										onClick: () => O((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ x(p, { size: 15 }), e.label]
									}) : e.label
								}), N(e)] }), D[t] && e.details?.map((e, t) => /* @__PURE__ */ S("tr", {
									className: "nextstation-score-sub",
									children: [/* @__PURE__ */ x("th", {
										scope: "row",
										children: e.label
									}), N(e)]
								}, t))] }, t)) }),
								j && /* @__PURE__ */ x("tfoot", { children: /* @__PURE__ */ S("tr", { children: [/* @__PURE__ */ x("th", {
									scope: "row",
									children: w("games.nextstation.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ x("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ x("ol", {
						className: "nextstation-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ S("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ S("div", {
								className: "nextstation-score-rankline",
								children: [M(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ S("strong", {
									className: "nextstation-score-points",
									children: [e.scores[t], y && /* @__PURE__ */ x("small", { children: y })]
								})]
							}), f?.(t)]
						}, t))
					})),
					_,
					!!u?.length && f && /* @__PURE__ */ x("div", {
						className: "nextstation-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ S("details", { children: [/* @__PURE__ */ x("summary", { children: k(e) }), f(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ S("footer", {
				className: "nextstation-score-actions",
				children: [
					s && /* @__PURE__ */ x("button", {
						type: "button",
						className: "btn-quiet",
						onClick: s,
						children: w("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ x("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: w("session.result.playAgain")
					}),
					!a && !s && /* @__PURE__ */ x("p", { children: w("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/nextstation/endgame-scores.tsx
function He(e) {
	let t = l(), n = e.public, r = (e) => n.boards[e] ? U(n.boards[e], n.objectives) : void 0, i = [
		"games.nextstation.lineColor.blue",
		"games.nextstation.lineColor.green",
		"games.nextstation.lineColor.pink",
		"games.nextstation.lineColor.purple"
	], a = {
		interchange8: "games.nextstation.objectives.interchange8",
		districts13: "games.nextstation.objectives.districts13",
		tourists5: "games.nextstation.objectives.tourists5",
		central9: "games.nextstation.objectives.central9",
		thames6: "games.nextstation.objectives.thames6"
	}, o = [
		...i.map((e, n) => ({
			label: /* @__PURE__ */ x("span", {
				style: { borderBottom: `3px solid ${Q[A[n]]}` },
				children: t(e)
			}),
			value: (e) => r(e)?.lines[n] ?? "—"
		})),
		...[["tourist", "games.nextstation.bdTourist"], ["interchange", "games.nextstation.bdInterchange"]].map(([e, n]) => ({
			label: t(n),
			value: (t) => r(t)?.[e] ?? "—"
		})),
		...n.objectives.map((e) => ({
			label: t(a[e]),
			value: (t) => n.boards[t] ? H(n.boards[t])[e] ? 10 : 0 : "—"
		}))
	];
	return /* @__PURE__ */ x(Ve, {
		...e,
		renderRowExtra: void 0,
		rows: o
	});
}
//#endregion
//#region src/games/nextstation/game-over.tsx
function Ue(e) {
	return /* @__PURE__ */ x(He, { ...e });
}
function We(e) {
	return /* @__PURE__ */ x(Be, {
		...e,
		board: /* @__PURE__ */ x(Ne, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ x(Ue, { ...e })
	});
}
//#endregion
//#region src/games/nextstation/game-over-row.tsx
var Ge = [
	"games.nextstation.lineColor.blue",
	"games.nextstation.lineColor.green",
	"games.nextstation.lineColor.pink",
	"games.nextstation.lineColor.purple"
], Ke = {
	interchange8: "games.nextstation.objectives.interchange8",
	districts13: "games.nextstation.objectives.districts13",
	tourists5: "games.nextstation.objectives.tourists5",
	central9: "games.nextstation.objectives.central9",
	thames6: "games.nextstation.objectives.thames6"
};
function qe({ public: e, rid: t }) {
	let n = l(), r = e, i = r.boards[t];
	if (!i) return null;
	let a = U(i, r.objectives), o = H(i);
	return /* @__PURE__ */ S("div", {
		className: "nsl-over-details mt-2 border-t border-ink/20 pt-2 font-mono font-bold tabular-nums",
		children: [/* @__PURE__ */ x("div", {
			className: "nsl-over-lines grid grid-cols-4 gap-1.5",
			children: a.lines.map((e, t) => /* @__PURE__ */ S("span", {
				className: "flex items-center justify-between border-b-4 px-1 pb-0.5 text-sm",
				style: { borderColor: Q[A[t]] },
				"aria-label": `${n(Ge[t])} ${e}`,
				children: [/* @__PURE__ */ x("span", {
					className: "text-[10px] text-ink/60",
					children: t + 1
				}), /* @__PURE__ */ x("strong", { children: e })]
			}, t))
		}), /* @__PURE__ */ S("div", {
			className: "nsl-over-bonuses mt-1.5 flex flex-wrap gap-x-3 gap-y-1 text-xs text-ink/75",
			children: [
				/* @__PURE__ */ S("span", { children: [
					n("games.nextstation.bdTourist"),
					" ",
					a.tourist
				] }),
				/* @__PURE__ */ S("span", { children: [
					n("games.nextstation.bdInterchange"),
					" ",
					a.interchange
				] }),
				r.objectives.map((e) => /* @__PURE__ */ S("span", {
					className: o[e] ? "text-done-ink" : "text-ink/40 line-through",
					children: [n(Ke[e]), o[e] ? " +10" : ""]
				}, e))
			]
		})]
	});
}
//#endregion
//#region src/games/nextstation/options.tsx
function Je({ value: e, onChange: t }) {
	let n = l(), r = G.safeParse(e), i = r.success ? r.data : G.parse(void 0);
	return /* @__PURE__ */ x(E, {
		checked: i.objectives,
		label: n("games.nextstation.optObjectives"),
		hint: n("games.nextstation.optObjectivesDesc"),
		accent: W.accent,
		onChange: () => t({ objectives: !i.objectives })
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/nextstation/entry.tsx
var Ye = {
	definition: we,
	View: Ne,
	bot: Ie,
	describe: Re,
	fx: ze,
	OverView: We,
	RowView: qe,
	Options: Je,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "下一站伦敦",
			desc: "翻牌连站画地铁,四条线路铺伦敦",
			rules: "目标:用四种颜色各画一条地铁线,总分最高者胜。\n流程:\n· 共 4 回合,每回合一种颜色(蓝→绿→粉→紫),从对应彩色始发站出发画一条线。\n· 每回合 11 张站牌逐张翻开;所有人同时决定:画一段,或跳过等下一张。\n· 画段:从线路某一端沿灰色潜在线连到与牌面同符号的站;第一段必须从始发站出发。\n· 百搭牌可连任意站;中央「?」站任何牌都可连。\n· 不可穿过其他站、不可成环、同一对站之间至多一段、线段不可交叉。\n· 道岔牌:翻出后立即再翻一张,这张可从线上任意站起画(分出支线);\n  若道岔是本回合第 1/2 张翻出的牌则忽略。\n· 第 5 张粉底牌翻出并应答完后,本回合结束并结算该线。\n计分:\n· 单线得分 = 经过的区数 × 单一区内最多站数,再加跨泰晤士河段数的两倍。\n· 旅游点:每条线每经过 1 个旅游点(红圈站)划 1 圈,全程至多 10 圈,按圈数查表得分。\n· 换乘站:有 2/3/4 条线经过的站,终局各获得 2/5/9 分。\n· 总分最高者胜;平局比单线最高分,再平共享胜利。",
			drawPrompt: "连到高亮站",
			switchPrompt: "道岔：可从线上任一站出发",
			pickFrom: "选择线路起点",
			noMoves: "无合法线路，跳过",
			waitingDraw: "等待其他玩家",
			lastCard: "本回合最后一张",
			over: "对局结束",
			pass: "跳过",
			cancelPick: "改选目标",
			pinkProgress: "粉底 {{n}}/5",
			cardUnderground: "地下",
			cardStreet: "街道",
			roundRail: "线路进度",
			lineColor: {
				blue: "蓝线",
				green: "绿线",
				pink: "粉线",
				purple: "紫线"
			},
			shapeName: {
				square: "方块",
				triangle: "三角",
				pentagon: "五边形",
				circle: "圆形",
				wild: "中央",
				any: "任意"
			},
			cardAria: {
				square: "方块牌",
				triangle: "三角牌",
				pentagon: "五边形牌",
				circle: "圆形牌",
				joker: "百搭牌",
				switch: "道岔牌"
			},
			optObjectives: "共同目标(进阶)",
			optObjectivesDesc: "开局从 5 个共同目标抽 2 个公示,完成各得 10 分",
			objectives: {
				interchange8: "8+ 换乘站",
				districts13: "覆盖 13 区",
				tourists5: "5 旅游点全连",
				central9: "中央区 9 站全连",
				thames6: "跨河 6+ 次"
			},
			bdTourist: "旅游",
			bdInterchange: "换乘",
			hintDraw: "画一段,连一个{{shape}}站",
			hintPass: "跳过这张牌",
			errOver: "本局已结束",
			errAlreadyDone: "这张牌你已行动过",
			errBadEdge: "这段不能画"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Next Station: London",
			desc: "Flip cards, link stations — draw four tube lines across London",
			rules: "Goal: Draw one Underground line in each of four colors; highest total wins.\nPlay:\n· 4 rounds, one color each (blue→green→pink→purple), starting from its colored departure station.\n· Each round an 11-card deck is revealed one card at a time; everyone simultaneously draws a section or skips.\n· A section runs from one end of your line along a gray potential link to a station matching the card's symbol; the first section starts at the departure station.\n· Jokers connect to any station; the central \"?\" station accepts any card.\n· Never pass through another station, never loop, at most one section between a pair of stations, and sections may not cross.\n· Switch card: immediately reveal the next card; that section may start from ANY station on your line (a branch).\n  A switch revealed as the 1st/2nd card is ignored.\n· After the 5th pink-backed card is resolved, the round ends and the line scores.\nScoring:\n· Line = districts visited × most stations in one district, plus twice the number of Thames crossings.\n· Tourist sites: circle one per site your line passes (max 10 all game), scored by table.\n· Interchanges: stations with 2/3/4 lines score 2/5/9.\n· Ties: highest single line, then shared victory.",
			drawPrompt: "Connect to a highlighted station",
			switchPrompt: "Switch: start from any station on your line",
			pickFrom: "Choose a starting station",
			noMoves: "No legal route — skip",
			waitingDraw: "Waiting for other players",
			lastCard: "Last card this round",
			over: "Game over",
			pass: "Skip",
			cancelPick: "Choose another target",
			pinkProgress: "Tube {{n}}/5",
			cardUnderground: "Tube",
			cardStreet: "Street",
			roundRail: "Line progress",
			lineColor: {
				blue: "Blue",
				green: "Green",
				pink: "Pink",
				purple: "Purple"
			},
			shapeName: {
				square: "square",
				triangle: "triangle",
				pentagon: "pentagon",
				circle: "circle",
				wild: "central",
				any: "any"
			},
			cardAria: {
				square: "Square card",
				triangle: "Triangle card",
				pentagon: "Pentagon card",
				circle: "Circle card",
				joker: "Joker card",
				switch: "Switch card"
			},
			optObjectives: "Shared objectives (advanced)",
			optObjectivesDesc: "Reveal 2 of 5 shared objectives at start; each completed scores 10",
			objectives: {
				interchange8: "8+ interchanges",
				districts13: "All 13 districts",
				tourists5: "All 5 tourist sites",
				central9: "All 9 central stations",
				thames6: "6+ Thames crossings"
			},
			bdTourist: "Tourist",
			bdInterchange: "Interchange",
			hintDraw: "Draw a section to a {{shape}} station",
			hintPass: "Skip this card",
			errOver: "The game is over",
			errAlreadyDone: "You already acted on this card",
			errBadEdge: "That section cannot be drawn"
		}
	}
};
//#endregion
export { Ye as default };
