import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { avatarNameAt as n, useI18nSettings as r, useT as i } from "@bgparty/sdk/i18n";
import { botAvatarOf as a } from "@bgparty/sdk/lobby";
import { AVATARS as o } from "@bgparty/sdk/avatars";
import { PLAYER_COLORS as s } from "@bgparty/sdk/player-colors";
import { useEffect as c, useRef as l, useState as u } from "react";
import { useWakeLock as d } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { PlayerStrip as ee } from "@bgparty/sdk/ui/player-strip";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { ConfirmButton as te } from "@bgparty/sdk/confirm-button";
import { IconExpand as g, IconLog as _ } from "@bgparty/sdk/icons";
import { OptionCheckbox as v, OptionRadio as y, OptionSection as b } from "@bgparty/sdk/ui/game-options";
//#region src/games/entropy/data.ts
var x = [
	"evolve",
	"life",
	"aggregate",
	"evolve",
	"life",
	"aggregate"
], S = [
	"activate",
	"biome",
	"draw",
	"upgrade",
	"asteroid",
	"soup"
], C = (e, t = 1, n) => ({
	kind: e,
	n: t,
	...n === void 0 ? {} : { tag: n }
});
function ne(e) {
	return [
		"H",
		"C",
		"W",
		"R"
	].map((t) => Number(e.match(RegExp(t + "(\\d)"))?.[1] ?? 0));
}
var w = (e, t, n, r, i, a) => ({
	id: e,
	tier: t,
	env: ne(n),
	next: r,
	effects: i,
	count: a
}), T = [
	w("IA", 1, "C1", [2, 3], [C("energy")], 6),
	w("IB", 1, "H1", [3, 4], [C("mass")], 6),
	w("IIA", 2, "C1W1", [5], [C("energy", 3)], 5),
	w("IIB", 2, "H1C1", [6, 7], [C("draw")], 5),
	w("IIC", 2, "H1W1", [8], [C("mass", 3)], 5),
	w("IIIA", 3, "C2W1", [9], [C("advance", 2)], 4),
	w("IIIB", 3, "H1C1W1", [9, 10], [C("life")], 4),
	w("IIIC", 3, "H2W1", [10, 11], [C("aggregate")], 4),
	w("IIID", 3, "W2R1", [], [C("asteroid")], 4),
	w("IVA", 4, "C1W1R1", [], [C("animalReward", 1, 68)], 3),
	w("IVB", 4, "H1W2R1", [], [C("animalReward", 3, 67)], 3),
	w("IVC", 4, "H1R1", [], [C("animalReward", 2, 63)], 3)
], E = (e, t, n, r, i, a) => ({
	id: e,
	type: Math.floor((e - 1) / 22),
	env: ne(t),
	require: n,
	consume: r,
	yield: i,
	effects: a
}), D = [
	E(1, "H1", 0, !1, 1, [C("energy", 2)]),
	E(2, "H1", 0, !1, 1, [C("mass", 2)]),
	E(3, "C1", 0, !1, 0, [C("asteroid")]),
	E(4, "C1", 0, !1, 1, [C("entropy", 4)]),
	E(5, "W1", 0, !1, 1, [C("draw")]),
	E(6, "W1", 0, !1, 2, [C("entropy", 2)]),
	E(7, "R1", 0, !1, 1, [C("entropy"), C("generator")]),
	E(8, "R1", 0, !1, 2, [C("mass", 4)]),
	E(9, "H2", 0, !1, 0, [C("biome")]),
	E(10, "C2", 0, !1, 1, [C("bacteria", 2)]),
	E(11, "H1C1", 0, !1, 2, [C("generator")]),
	E(12, "H1C1", 0, !1, 1, [C("energy", 3)]),
	E(13, "H1W1", 0, !1, 3, [C("vp", 3)]),
	E(14, "H1W1", 0, !1, 2, [C("draw", 2, 1)]),
	E(15, "H1R1", 0, !1, 1, [C("biome")]),
	E(16, "H1R1", 0, !1, 2, [C("draw", 2, 2)]),
	E(17, "C1W1", 0, !1, 1, [C("mass"), C("asteroid")]),
	E(18, "C1W1", 0, !1, 1, [C("bacteria"), C("generator")]),
	E(19, "C1R1", 0, !1, 2, [C("asteroid")]),
	E(20, "C1R1", 0, !1, 0, [C("bacteria", 3)]),
	E(21, "W1R1", 0, !1, 1, [C("draw", 2, 0)]),
	E(22, "W1R1", 0, !1, 2, [C("biome")]),
	E(23, "H2", 1, !0, 1, [C("asteroid", 1, 1)]),
	E(24, "C2", 1, !0, 1, [C("evolve")]),
	E(25, "W2", 1, !1, 1, [C("retrieve", 2)]),
	E(26, "R2", 1, !1, 0, [C("generator", 2)]),
	E(27, "H1C1W1", 1, !1, 2, [C("activate")]),
	E(28, "H1W1R1", 1, !0, 3, [C("generator")]),
	E(29, "H1C1W1", 1, !0, 1, [C("upgrade", 1, 1)]),
	E(30, "H1W1R1", 1, !1, 2, [C("generator")]),
	E(31, "H1C1R1", 1, !1, 1, [C("plant", 2)]),
	E(32, "C1W1R1", 1, !1, 2, [C("plant")]),
	E(33, "H2C1", 1, !1, 2, [C("retrieve")]),
	E(34, "H2W1", 1, !0, 1, [C("fulfill")]),
	E(35, "H2R1", 1, !1, 0, [C("asteroid", 1, 1)]),
	E(36, "H1C2", 1, !0, 2, [C("upgrade")]),
	E(37, "H1W2", 1, !0, 3, [C("activate")]),
	E(38, "C2R1", 1, !1, 0, [C("upgrade", 1, 1)]),
	E(39, "W1R2", 1, !1, 2, [C("aggregate")]),
	E(40, "C1W2", 1, !0, 2, [C("fulfill", 1, 1)]),
	E(41, "C1R2", 1, !1, 1, [C("aggregate")]),
	E(42, "H3", 1, !0, 2, [C("evolve")]),
	E(43, "C3", 1, !1, 0, [C("fulfill")]),
	E(44, "W3", 1, !1, 1, [C("vp", 6)]),
	...[
		[
			"H1C2",
			!0,
			1
		],
		[
			"H2C1",
			!0,
			1
		],
		[
			"H2W1",
			!0,
			1
		],
		[
			"H1W2",
			!1,
			0
		],
		[
			"H1R2",
			!0,
			3
		],
		[
			"H2R1",
			!1,
			1
		],
		[
			"C1W2",
			!1,
			1
		],
		[
			"C2W1",
			!1,
			1
		],
		[
			"C2R1",
			!1,
			0
		],
		[
			"W2R1",
			!1,
			0
		],
		[
			"W1R2",
			!0,
			1
		],
		[
			"H1C1W1",
			!0,
			2
		],
		[
			"H1C2W1",
			!0,
			3
		],
		[
			"H2C1W1",
			!0,
			1
		],
		[
			"H1C1R1",
			!1,
			2
		],
		[
			"H1C2R1",
			!1,
			3
		],
		[
			"H1C1R2",
			!1,
			1
		],
		[
			"H2W1R1",
			!1,
			1
		],
		[
			"H1W2R1",
			!0,
			3
		],
		[
			"H1W1R1",
			!1,
			1
		],
		[
			"C1W1R1",
			!1,
			1
		],
		[
			"C1W2R1",
			!1,
			0
		]
	].map(([e, t, n], r) => E(r + 45, e, 1, t, n, [C("animalReward", 1, r + 45)]))
], O = (e, t, n, r, i, a) => ({
	id: e,
	type: t,
	cost: n,
	condition: r,
	effects: i,
	...a ? { starting: a } : {}
}), k = [
	O(0, 3, 6, !0, [C("entropy", 5)]),
	O(1, 3, 6, !0, [C("entropy", 4)]),
	O(2, 3, 6, !0, [C("activateOne")]),
	O(3, 3, 3, !1, [C("upgrade")]),
	O(4, 3, 2, !1, [C("generator")]),
	O(5, 3, 7, !0, [C("generator", 2)]),
	O(6, 3, 8, !0, [C("anyLife", 2)]),
	O(7, 3, 4, !0, [C("draw")]),
	O(8, 3, 6, !0, [C("aggregate")]),
	O(9, 3, 3, !0, [C("entropy")]),
	O(10, 3, 6, !0, [C("advance", 2, 0)]),
	O(11, 1, 5, !0, [C("bacteria", 2)]),
	O(12, 1, 3, !1, [C("plant")]),
	O(13, 1, 5, !0, [C("plant")]),
	O(14, 1, 3, !0, [C("draw")]),
	O(15, 1, 4, !0, [C("bacteria")]),
	O(16, 1, 5, !0, [C("life")]),
	O(17, 1, 3, !1, [C("aggregate")]),
	O(18, 1, 6, !0, [C("mass", 4)]),
	O(19, 1, 7, !0, [C("plant", 2)]),
	O(20, 1, 4, !0, [C("retrieve")]),
	O(21, 1, 5, !0, [C("aggregate")]),
	O(22, 0, 5, !0, [C("advance", 2, 1)]),
	O(23, 0, 7, !0, [C("animal", 2)]),
	O(24, 0, 2, !1, [C("energy", 2)]),
	O(25, 0, 3, !1, [C("activateOne")]),
	O(26, 0, 5, !0, [C("activateOne")]),
	O(27, 0, 4, !0, [C("energy", 2)]),
	O(28, 0, 4, !0, [C("energy", 2)]),
	O(29, 0, 4, !0, [C("plant")]),
	O(30, 0, 4, !0, [C("biome")]),
	O(31, 0, 5, !0, [C("draw", 2)]),
	O(32, 0, 4, !0, [C("upgrade")]),
	O(33, 2, 6, !0, [C("life")]),
	O(34, 2, 5, !0, [C("retrieve", 2)]),
	O(35, 2, 4, !0, [C("draw")]),
	O(36, 2, 4, !0, [C("advance", 1, 1)]),
	O(37, 2, 6, !0, [C("draw", 2)]),
	O(38, 2, 2, !1, [C("biome")]),
	O(39, 2, 4, !1, [C("activateOne", 1, 1)]),
	O(40, 2, 6, !0, [C("activateOne", 1, 1)]),
	O(41, 2, 5, !0, [C("biome")]),
	O(42, 2, 5, !0, [C("bacteria", 2)]),
	O(43, 2, 3, !1, [C("life")]),
	O(44, 2, 0, !0, [C("bacteria", 2)], [2, 3]),
	O(45, 2, 0, !0, [C("draw", 2)], [2, 4]),
	O(46, 3, 0, !0, [C("entropy", 4)], [2, 4]),
	O(47, 3, 0, !0, [C("generator")], [3, 1]),
	O(48, 1, 0, !0, [C("plant")], [4, 1]),
	O(49, 0, 0, !0, [C("advance", 1, 1)], [3, 3]),
	O(50, 1, 0, !0, [C("mass", 4)], [4, 2]),
	O(51, 0, 0, !0, [C("energy", 2)], [3, 3])
], A = (e, t, n, r, i, a, o) => ({
	id: e,
	scarce: t,
	trigger: n,
	require: r,
	eitherBP: [
		0,
		5,
		8,
		10,
		12,
		18,
		28,
		29,
		30,
		35
	].includes(e),
	cost: i,
	effects: a,
	improved: o
}), j = [
	A(0, !0, "life", [
		0,
		3,
		0,
		1
	], C("entropy"), [C("mass", 2)], [C("retrieve")]),
	A(1, !0, "evolve", [
		2,
		0,
		2,
		0
	], C("entropy"), [C("mass", 2), C("draw", 2)], [C("draw", 2)]),
	A(2, !0, "life", [
		2,
		0,
		2,
		0
	], C("entropy"), [C("vp", 3)], [C("activateOne")]),
	A(3, !0, "activate", [
		0,
		0,
		1,
		3
	], C("entropy"), [C("bacteria"), C("vp", 4)], [C("vp", 4)]),
	A(4, !0, "activate", [
		3,
		1,
		0,
		0
	], C("entropy"), [C("mass", 2), C("draw")], [C("draw")]),
	A(5, !0, "upgrade", [
		0,
		1,
		0,
		3
	], C("entropy"), [C("generator"), C("vp", 4)], [C("vp", 4)]),
	A(6, !0, "aggregate", [
		3,
		2,
		0,
		0
	], C("entropy"), [C("energy", 2), C("biome")], [C("biome")]),
	A(7, !0, "soup", [
		0,
		0,
		0,
		4
	], C("entropy"), [C("bacteria"), C("vp", 4)], [C("vp", 4)]),
	A(8, !0, "soup", [
		0,
		0,
		2,
		2
	], C("entropy"), [C("mass", 2), C("draw")], [C("draw")]),
	A(9, !0, "evolve", [
		2,
		0,
		1,
		0
	], C("entropy"), [C("vp", 3)], [C("asteroid")]),
	A(10, !0, "biome", [
		0,
		0,
		3,
		1
	], C("entropy"), [C("draw")], [C("activateOne")]),
	A(11, !0, "aggregate", [
		0,
		0,
		1,
		3
	], C("entropy"), [C("vp", 3)], [
		C("mass"),
		C("energy"),
		C("generator")
	]),
	A(12, !0, "upgrade", [
		0,
		3,
		0,
		1
	], C("entropy"), [C("draw")], [C("activateOne")]),
	A(13, !0, "biome", [
		0,
		1,
		1,
		2
	], C("entropy"), [C("energy", 2), C("vp", 4)], [C("vp", 4)]),
	A(14, !0, "draw", [
		2,
		0,
		2,
		0
	], C("entropy"), [C("generator")], [C("aggregate")]),
	A(15, !1, "activate", [
		1,
		0,
		1,
		2
	], C("energy"), [C("vp", 2)], [C("vp", 2)]),
	A(16, !1, "upgrade", [
		1,
		0,
		2,
		1
	], C("entropy"), [C("generator")], [C("generator")]),
	A(17, !1, "aggregate", [
		0,
		0,
		0,
		3
	], C("entropy"), [C("energy")], [C("energy")]),
	A(18, !1, "aggregate", [
		0,
		0,
		1,
		2
	], C("energy"), [C("advance")], [C("advance")]),
	A(19, !1, "life", [
		0,
		3,
		0,
		0
	], C("energy"), [C("mass")], [C("mass")]),
	A(20, !1, "soup", [
		0,
		2,
		0,
		2
	], C("entropy"), [C("vp", 2)], [C("vp", 2)]),
	A(21, !1, "draw", [
		0,
		3,
		1,
		0
	], C("mass"), [C("vp", 2)], [C("vp", 2)]),
	A(22, !1, "upgrade", [
		0,
		0,
		0,
		4
	], C("draw"), [C("vp", 2)], [C("vp", 2)]),
	A(23, !1, "asteroid", [
		1,
		1,
		0,
		2
	], C("entropy"), [C("vp", 2)], [C("vp", 2)]),
	A(24, !1, "life", [
		0,
		1,
		1,
		2
	], C("mass"), [C("generator")], [C("generator")]),
	A(25, !1, "activate", [
		1,
		0,
		1,
		2
	], C("draw", 1, 1), [C("bacteria")], [C("bacteria")]),
	A(26, !1, "soup", [
		0,
		2,
		0,
		2
	], C("draw", 1, 0), [C("vp", 2)], [C("vp", 2)]),
	A(27, !1, "biome", [
		0,
		1,
		2,
		0
	], C("entropy"), [C("generator")], [C("generator")]),
	A(28, !1, "evolve", [
		0,
		0,
		2,
		1
	], C("entropy"), [C("advance")], [C("advance")]),
	A(29, !1, "biome", [
		0,
		2,
		0,
		2
	], C("mass"), [C("vp", 2)], [C("vp", 2)]),
	A(30, !1, "evolve", [
		2,
		1,
		0,
		0
	], C("mass"), [C("entropy")], [C("entropy")]),
	A(31, !1, "draw", [
		0,
		2,
		1,
		1
	], C("vp", 2), [C("bacteria")], [C("bacteria")]),
	A(32, !1, "asteroid", [
		1,
		1,
		0,
		2
	], C("energy"), [C("bacteria")], [C("bacteria")]),
	A(33, !0, "draw", [
		0,
		2,
		2,
		0
	], C("entropy"), [C("entropy", 3), C("vp", 4)], [C("vp", 4)]),
	A(34, !0, "asteroid", [
		2,
		0,
		1,
		1
	], C("entropy"), [C("energy", 2)], [C("aggregate")]),
	A(35, !0, "asteroid", [
		0,
		0,
		0,
		3
	], C("entropy"), [C("entropy", 3), C("vp", 4)], [C("vp", 4)])
], re = [
	{
		star: 0,
		space: "upgrade",
		hand: [
			3,
			0,
			0
		],
		energy: 1
	},
	{
		star: 0,
		space: "soup",
		hand: [
			0,
			2,
			0
		],
		energy: 3
	},
	{
		star: 0,
		space: "activate",
		hand: [
			1,
			1,
			0
		],
		energy: 2
	},
	{
		star: 1,
		space: "biome",
		hand: [
			1,
			1,
			0
		],
		energy: 1
	},
	{
		star: 1,
		space: "draw",
		hand: [
			2,
			1,
			0
		],
		energy: 1
	},
	{
		star: 1,
		space: "asteroid",
		hand: [
			1,
			2,
			0
		],
		energy: 2
	}
], ie = [
	0,
	1,
	3,
	5,
	7,
	10
], ae = [
	{
		discount: 0,
		count: 0
	},
	{
		discount: 1,
		count: 1
	},
	{
		discount: 1,
		count: 2
	},
	{
		discount: 1,
		count: 3
	},
	{
		discount: 2,
		count: 3
	},
	{
		discount: 2,
		count: 4
	},
	{
		discount: 3,
		count: 4
	}
], oe = [
	{
		track: -1,
		life: 0,
		cards: [[1, 0], [1, 1]],
		planet: [2, 0],
		biome: [1, 0]
	},
	{
		track: -1,
		life: 1,
		cards: [[2, 0], [2, 1]],
		planet: [1, 1],
		biome: [0, 1]
	},
	{
		track: -1,
		life: 2,
		cards: [[0, 0], [0, 1]],
		planet: [0, 1],
		biome: [1, 1]
	},
	{
		track: 0,
		life: -1,
		cards: [[0, 0], [1, 0]]
	},
	{
		track: 1,
		life: -1,
		cards: [[0, 1], [2, 1]]
	},
	{
		track: 2,
		life: -1,
		cards: [[1, 1], [2, 0]]
	},
	{
		track: 0,
		life: 0,
		cards: [[0, 1]],
		planet: [2, 0]
	},
	{
		track: 1,
		life: 0,
		cards: [[1, 0]],
		planet: [1, 0]
	},
	{
		track: 2,
		life: 0,
		cards: [[2, 1]],
		planet: [0, 0]
	},
	{
		track: -1,
		life: 0,
		cards: [[2, 0], [2, 1]],
		planet: [3, 0],
		biome: [0, 0]
	},
	{
		track: 0,
		life: 1,
		cards: [[2, 1]],
		planet: [2, 1]
	},
	{
		track: 1,
		life: 1,
		cards: [[0, 0]],
		planet: [1, 0]
	},
	{
		track: 2,
		life: 1,
		cards: [[1, 1]],
		planet: [0, 1]
	},
	{
		track: -1,
		life: 1,
		cards: [[0, 0], [0, 1]],
		planet: [3, 0],
		biome: [1, 1]
	},
	{
		track: 0,
		life: 2,
		cards: [[1, 0]],
		planet: [2, 1]
	},
	{
		track: 1,
		life: 2,
		cards: [[2, 1]],
		planet: [1, 1]
	},
	{
		track: 2,
		life: 2,
		cards: [[0, 1]],
		planet: [0, 0]
	},
	{
		track: -1,
		life: 2,
		cards: [[1, 0], [1, 1]],
		planet: [3, 1],
		biome: [0, 1]
	}
], se = {
	id: "entropy",
	tier: "alpha",
	mechanics: [
		"engine-building",
		"hand-management",
		"tile-placement",
		"race"
	],
	interactionTags: [],
	nameKey: "games.entropy.name",
	descKey: "games.entropy.desc",
	rulesKey: "games.entropy.rules",
	icon: "🌌",
	iconImg: "games/entropy.webp",
	rulesUrl: { en: "https://www.dropbox.com/scl/fi/lg9iu1qq1s457uymglaxo/entropy_rules_EN_web.pdf?rlkey=lpst6su3lu76smw2yrlnz363m&dl=1" },
	minPlayers: 1,
	maxPlayers: 4,
	accent: "#526a9c",
	releasedAt: "2026-10-29T12:51:41+08:00",
	search: {
		py: "chong su yu zhou",
		init: "csyz"
	},
	hotseat: "cover"
}, M = t.object({
	focus: t.enum([
		"random",
		"A",
		"B",
		"C",
		"D"
	]).default("random"),
	alternative: t.boolean().default(!1),
	advanced: t.boolean().default(!1),
	ghostMultiplier: t.union([
		t.literal(3),
		t.literal(4),
		t.literal(5)
	]).default(4),
	progress: t.enum([
		"standard",
		"all",
		"bOnly"
	]).default("standard"),
	doubleProgress: t.boolean().default(!1)
}).default({
	focus: "random",
	alternative: !1,
	advanced: !1,
	ghostMultiplier: 4,
	progress: "standard",
	doubleProgress: !1
}), N = t.discriminatedUnion("type", [t.object({
	type: t.literal("choose"),
	id: t.string().max(200),
	revision: t.int().nonnegative()
}), t.object({
	type: t.literal("tick"),
	now: t.number()
})]), P = t.tuple([
	t.int().nonnegative(),
	t.int().nonnegative(),
	t.int().nonnegative()
]), F = t.object({
	uid: t.int(),
	data: t.int().min(0).max(51),
	system: t.int(),
	life: P,
	cards: t.array(t.int().min(1).max(66)).max(3),
	asteroids: t.array(t.object({
		type: t.int().min(0).max(3),
		slot: t.int().min(0).max(1)
	})).max(2),
	biome: t.object({
		data: t.int().min(0).max(35),
		fulfilled: t.boolean()
	}).nullable()
}), I = t.object({
	rid: t.string(),
	energy: t.int().nonnegative(),
	mass: t.int().nonnegative(),
	entropy: t.int().nonnegative(),
	vp: t.int().nonnegative(),
	position: t.int().min(0).max(5),
	outer: t.boolean(),
	markers: t.array(t.object({
		position: t.int().min(-1).max(5),
		tired: t.boolean(),
		locked: t.boolean()
	})).length(4),
	focus: t.enum([
		"A",
		"B",
		"C",
		"D"
	]),
	levels: P,
	generator: t.int().min(0).max(6),
	generatorSteps: t.int().nonnegative(),
	systems: t.array(t.object({
		uid: t.int(),
		star: t.int().min(-1).max(11),
		starting: t.boolean()
	})),
	planets: t.array(F),
	tracks: P,
	events: P,
	small: P,
	big: P,
	handCount: t.int().nonnegative(),
	missionCount: t.int().min(0).max(2)
}), L = t.object({
	id: t.string(),
	kind: t.enum([
		"move",
		"skip",
		"gain",
		"evolve",
		"aggregate",
		"placePlanet",
		"play",
		"order",
		"finishLife",
		"draw",
		"biome",
		"fulfill",
		"activate",
		"upgrade",
		"asteroid",
		"advance",
		"addLife",
		"retrieve",
		"biomeTrigger",
		"exchange",
		"mission",
		"challenge",
		"end",
		"pickCondition"
	]),
	args: t.array(t.number())
}), ce = t.object({
	require: t.int().min(1).max(12),
	constraint: t.int().min(0).max(12),
	done: t.boolean()
}), le = t.object({
	position: t.int().min(0).max(5),
	deckAt: t.int().min(0).max(5),
	tracks: P,
	life: P,
	tiles: t.int().nonnegative(),
	challenges: t.array(ce).length(3),
	lastCard: t.int().min(0).max(19),
	remaining: t.int().nonnegative(),
	discard: t.array(t.int())
}), ue = t.object({
	vp: t.number(),
	life: t.number(),
	main: t.array(t.number()).length(3),
	resources: t.number(),
	challenges: t.number(),
	total: t.number()
}), de = t.object({
	players: t.array(I),
	turn: t.string(),
	round: t.int(),
	endRound: t.int().nullable(),
	phase: t.enum([
		"move",
		"resolve",
		"mission",
		"done"
	]),
	revision: t.int(),
	outer: t.array(t.enum([
		"activate",
		"biome",
		"draw",
		"upgrade",
		"asteroid",
		"soup"
	])).length(6),
	market: t.object({
		life: t.array(t.array(t.object({
			top: t.int().nullable(),
			count: t.int()
		}))),
		planets: t.array(t.array(t.object({
			top: t.int().nullable(),
			count: t.int()
		}))),
		biomes: t.array(t.array(t.object({
			top: t.int().nullable(),
			count: t.int()
		})))
	}),
	stars: t.array(t.int()).length(12),
	asteroids: t.array(t.int()).length(4),
	systemsLeft: t.int(),
	small: t.array(t.array(t.int())),
	big: t.array(t.boolean()).length(3),
	completed: t.int(),
	config: M,
	ghost: le.nullable(),
	prompt: t.string(),
	pending: t.object({
		n: t.number(),
		tag: t.number().nullable(),
		planet: t.number().nullable(),
		system: t.number().nullable(),
		card: t.number().nullable(),
		data: t.number().nullable(),
		bonus: t.number()
	}),
	log: t.array(t.object({
		kind: t.string(),
		rid: t.string(),
		args: t.array(t.number())
	})),
	scores: t.record(t.string(), ue),
	ghostScore: t.number()
}), fe = t.object({
	hand: t.array(t.int()),
	missions: t.array(t.int()),
	choices: t.array(L)
}), R = (e) => e.players[e.turn], z = (e) => e.reduce((e, t) => e + t, 0), B = (e, t) => e.planets.flatMap((e) => e.cards).filter((e) => D[e - 1].type === t).length, V = (e, ...t) => {
	e.tasks.unshift(...t);
}, H = (e, t) => e.map((e) => ({
	...e,
	...t === void 0 ? {} : { planet: t }
})), U = (e, t, n = []) => {
	e.log.push({
		kind: t,
		rid: R(e).rid,
		args: n
	}), e.log = e.log.slice(-24);
};
function W(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function G(e) {
	let t = Math.ceil(e.length / 2);
	return [e.slice(0, t), e.slice(t)];
}
function pe(e) {
	for (let t = 0; t < 2; t++) if (!e[t].length && e[1 - t].length > 1) {
		let n = e[1 - t];
		e[t] = n.splice(Math.ceil(n.length / 2));
	}
}
function K(e, t) {
	let n = e[t].shift();
	return pe(e), n;
}
function q(e, t) {
	return e.ghost?.challenges.some((e) => !e.done && e.constraint === t) ?? !1;
}
function me(e, t) {
	return e.map((e, n) => e + t[n]);
}
function he(e, t) {
	let n = k[t.data], r = [
		0,
		0,
		0,
		0
	];
	n.condition && r[n.type]++, t.asteroids.forEach((e) => r[e.type]++);
	let i = e.systems.find((e) => e.uid === t.system)?.star ?? -1;
	return i < 0 ? r : me(r, T[i].env);
}
function ge(e, t) {
	let n = [
		0,
		0,
		0,
		0
	];
	return e.planets.filter((e) => t === void 0 || e.system === t).forEach((e) => {
		let t = k[e.data];
		t.condition && n[t.type]++, e.asteroids.forEach((e) => n[e.type]++);
	}), e.systems.filter((e) => t === void 0 || e.uid === t).forEach((e) => {
		e.star >= 0 && T[e.star].env.forEach((e, t) => n[t] += e);
	}), n;
}
function _e(e, t, n, r, i, a) {
	let o = D[r - 1], s = e.tasks.filter((e) => ["lifeFinish", "lifeOrder"].includes(e.kind) && e.planet === n.uid).length;
	if (n.cards.length + s >= 3 || o.type > 0 && n.life[o.type - 1] < o.require) return !1;
	let c = he(t, n);
	if (i) {
		if (i === r || !t.hand.includes(i) || !D[i - 1].env[a]) return !1;
		c[a]++;
	}
	return o.env.some((e, t) => e > c[t]) ? !1 : !q(e, 7) || z(c) - z(o.env) >= 1;
}
function ve(e, t, n) {
	let r = [];
	for (let i of t.planets.filter((e) => n === void 0 || e.uid === n)) for (let n of t.hand) {
		_e(e, t, i, n, 0, 0) && r.push([
			n,
			i.uid,
			0,
			0
		]);
		for (let a of t.hand) if (a !== n) for (let o = 0; o < 4; o++) _e(e, t, i, n, a, o) && r.push([
			n,
			i.uid,
			a,
			o
		]);
	}
	return r;
}
function ye(e, t) {
	if (!t.biome || t.biome.fulfilled) return !1;
	let n = j[t.biome.data], r = n.require, i = n.eitherBP ? t.life[0] - r[0] + t.life[1] - r[1] : z(t.life) - r[0] - r[1] - r[2];
	return t.life.every((e, t) => e >= r[t]) && i >= r[3] && z(t.life) >= z(r) + +!!q(e, 6);
}
function be(e, t, n, r = 1) {
	let i = [...e.players, ...e.ghost ? [e.ghost] : []].filter((e) => e !== t).some((e) => e.tracks[n] === 5) ? 4 : 5, a = t.tracks[n];
	t.tracks[n] = Math.min(i, a + r), a < 5 && t.tracks[n] === 5 && e.completed++;
}
function xe(e) {
	e.completed >= 2 && e.endRound === null && (e.endRound = e.round + 1);
}
function Se(e) {
	let t = R(e);
	for (let n = 0; n < 3; n++) {
		be(e, t, n, t.events[n]), t.events[n] = 0;
		let r = t.planets.reduce((e, t) => e + t.life[n], 0), i = n === 2 ? [
			6,
			6,
			6,
			6
		][e.players.length - 1] : [11, 8][n];
		!t.small[n] && r >= i && e.small[n].length && (t.small[n] = e.small[n].shift()), !t.big[n] && r >= [
			18,
			14,
			11
		][n] && e.big[n] && (t.big[n] = 20, e.big[n] = !1, e.completed++);
	}
	xe(e);
}
function Ce(e, t) {
	let n = e.systems.map((e) => e.star), r = e.systems.map((t) => ge(e, t.uid));
	switch (t) {
		case 1: return new Set(e.planets.map((e) => k[e.data].type)).size >= 3;
		case 2: return new Set(e.planets.flatMap((e) => e.asteroids.map((e) => e.type))).size >= 3;
		case 3: return e.levels.includes(2);
		case 4: return e.levels.every((e) => e >= 1);
		case 5: return e.generatorSteps >= 3;
		case 6: return n.includes(5);
		case 7: return n.includes(6);
		case 8: return n.includes(7);
		default: return r.some((e) => e[t - 9] >= 3);
	}
}
function we(e, t) {
	switch (t) {
		case 1: return [
			0,
			1,
			2
		].some((t) => B(e, t) >= 4);
		case 2: return e.systems.some((e) => e.star >= 0 && T[e.star].tier === 4);
		case 3: return z(e.levels) >= 4;
		case 4: return e.systems.filter((e) => e.star >= 0).length >= 4;
		case 5: return e.planets.filter((e) => e.asteroids.length === 2).length >= 2;
		case 6: return e.planets.filter((e) => z(e.life) >= 5).length >= 3;
		case 7: return e.planets.filter((e) => e.cards.length > 0).length >= 4;
		case 8: return e.planets.length >= 6;
		default: return ge(e)[t - 9] >= (t < 11 ? 8 : 7);
	}
}
function Te(e, t, n = 0, r = !1) {
	return r ? 0 : Math.max(0, T[t].tier + +!!q(e, 4) - n);
}
function Ee(e, t) {
	return t.kind === "draw" ? e.hand.some((e) => t.tag === void 0 || D[e - 1].type === t.tag) : t.kind === "vp" ? e.vp >= t.n : t.kind === "energy" || t.kind === "mass" || t.kind === "entropy" ? e[t.kind] >= t.n : !1;
}
function De(e, t) {
	(t.kind === "energy" || t.kind === "mass" || t.kind === "entropy" || t.kind === "vp") && (e[t.kind] -= t.n);
}
function Oe(e) {
	if (e.phase === "done") return [];
	let t = R(e), n = [], r = (e, ...t) => n.push({
		kind: e,
		args: t
	}), i = e.tasks[0];
	if (e.phase === "move") for (let n = 1; n <= 3; n++) {
		let i = (t.position + n) % 6;
		for (let a of [!0, !1]) {
			let o = e.players.length <= 2 || e.players.length === 3 && i % 2 == 0, s = e.players.some((t, n) => n !== e.turn && t.position === i && (o || t.outer === a)) || e.ghost?.position === i && (o || !a);
			if (s && n === 3 && t.entropy < 1) continue;
			if (a) {
				r("move", n, 1, -1, +!!s);
				continue;
			}
			let c = x[i], l = [
				"evolve",
				"aggregate",
				"life"
			].indexOf(c);
			if (c !== "life" || ve(e, t).length) for (let i of [l, 3]) t.markers[i].position >= 0 || t.markers[i].tired || i === 3 && (c === "aggregate" && q(e, 10) || c === "life" && q(e, 11) || c === "evolve" && q(e, 12)) || r("move", n, 0, i, +!!s);
		}
	}
	else if (e.phase === "mission") t.missions.filter((e) => Ce(t, e)).forEach((e) => r("mission", e)), e.ghost?.challenges.forEach((e, n) => {
		!e.done && we(t, e.require) && r("challenge", n);
	}), r("end");
	else if (i) {
		let n = i.n ?? 1;
		switch (i.kind) {
			case "energy":
			case "mass":
			case "entropy":
			case "vp":
			case "generator":
				r("gain");
				break;
			case "evolve": {
				let n = +!!q(e, 2), a = e.tasks.filter((e) => ["starCommit", "focusStarBefore"].includes(e.kind)), o = (t) => e.stars[t] > a.filter((e) => e.data === t).length;
				for (let s of t.systems) {
					if (a.some((e) => e.system === s.uid)) continue;
					let c = s.star < 0 ? [0, 1] : T[s.star].next;
					for (let a of c) {
						let c = T[a].tier + n - 0, l = t.focus === "A" && (i.focus ?? 0) > 0 && s.star >= 0, u = T[s.star]?.effects, d = l && t.entropy >= Te(e, s.star, 0, i.focus === 2) ? u?.filter((e) => e.kind === "energy").reduce((e, t) => e + t.n, 0) ?? 0 : 0, f = t.energy + d >= c;
						o(a) && f && r("evolve", s.uid, a, c);
					}
				}
				if (e.systemsLeft > 0) for (let e of [0, 1]) o(e) && t.energy >= 1 + n && r("evolve", -1, e, 1 + n);
				break;
			}
			case "aggregate":
				t.planets.length + e.tasks.filter((e) => e.kind === "placePlanet").length < t.systems.length * 2 + e.systemsLeft * 2 && e.planetDecks.forEach((e, n) => e.forEach((e, i) => {
					e.length && t.mass >= k[e[0]].cost && r("aggregate", n, i, e[0]);
				}));
				break;
			case "placePlanet":
				t.systems.forEach((e) => {
					t.planets.filter((t) => t.system === e.uid).length < 2 && r("placePlanet", e.uid);
				}), e.systemsLeft > 0 && r("placePlanet", -1);
				break;
			case "life":
				ve(e, t, i.planet).forEach((e) => r("play", ...e));
				break;
			case "lifeOrder":
				r("order", 0), r("order", 1);
				break;
			case "lifeYield":
				t.planets.find((e) => e.uid === i.planet).life[D[i.card - 1].type] < 5 && r("gain");
				break;
			case "draw":
				e.lifeDecks.forEach((e, t) => {
					(i.tag === void 0 || i.tag === t) && e.forEach((e, n) => {
						e.length && r("draw", t, n, e[0]);
					});
				});
				break;
			case "activate":
			case "activateOne":
			case "recovery": {
				let a = i.kind === "activate" && i.tag === 1 && n <= ae[t.generator].count ? ae[t.generator].discount : 0;
				t.systems.forEach((n) => {
					n.star >= 0 && (i.system === void 0 || n.uid === i.system) && !i.used?.includes(n.uid) && t.entropy >= Te(e, n.star, a, i.free || i.tag === 1 && i.kind === "activateOne") && !(i.kind === "recovery" && q(e, 1)) && r("activate", n.uid, Te(e, n.star, a, i.free || i.tag === 1 && i.kind === "activateOne"));
				}), i.kind === "recovery" && r("gain");
				break;
			}
			case "upgrade":
				(i.tag === 1 || t.energy >= 3) && (!q(e, 3) || t.mass >= 1) && t.levels.forEach((e, t) => {
					e < 2 && r("upgrade", t);
				});
				break;
			case "biome":
			case "setOrFulfill":
				t.planets.filter((e) => !e.biome).forEach((t) => e.biomeDecks.forEach((e, n) => {
					(i.tag !== 1 || n !== 1) && e.forEach((e, i) => {
						e.length && r("biome", t.uid, n, i, e[0]);
					});
				})), i.kind === "setOrFulfill" && t.planets.filter((e) => e.biome && !e.biome.fulfilled && (i.tag !== 1 || !j[e.biome.data].scarce)).forEach((e) => r("fulfill", e.uid));
				break;
			case "fulfill":
				t.planets.filter((e) => e.biome && !e.biome.fulfilled && (i.tag !== 1 || !j[e.biome.data].scarce)).forEach((e) => r("fulfill", e.uid));
				break;
			case "asteroid":
				if (q(e, 5) && !t.hand.length) break;
				for (let n of t.planets) for (let a = 0; a < 2; a++) if (!n.asteroids.some((e) => e.slot === a)) for (let o = 0; o < 4; o++) {
					if (!e.asteroids[o]) continue;
					let s = i.tag === 1 ? 0 : (a === 0 ? 2 : 0) + +(o >= 2);
					if (t.mass < s) continue;
					let c = i.tag === 1 || a === 0 ? [-1] : [
						0,
						1,
						2
					].filter((e) => n.life[e] > 0);
					for (let i of c) for (let c of q(e, 5) ? t.hand : [0]) r("asteroid", n.uid, o, a, i, c, s);
				}
				break;
			case "advance":
			case "anyLife":
			case "bacteria":
			case "plant":
			case "animal":
				for (let e of t.planets) if ((i.planet === void 0 || i.tag !== 9 || i.planet === e.uid) && (i.system === void 0 || e.system === i.system)) {
					if (i.kind === "advance") for (let t = 0; t < 3; t++) i.tag === 0 && t !== 1 || i.tag === 1 && t !== 2 || e.life[t] < 5 && (t === 0 || e.life[t - 1] > 0) && r("advance", e.uid, t);
					else {
						let t = i.kind === "anyLife" ? [
							0,
							1,
							2
						] : [[
							"bacteria",
							"plant",
							"animal"
						].indexOf(i.kind)];
						for (let n of t) e.life[n] < 5 && r("addLife", e.uid, n);
					}
				}
				break;
			case "retrieve":
				t.markers.forEach((e, t) => {
					e.position >= 0 && !e.locked && r("retrieve", t);
				});
				break;
			case "biomeTrigger": {
				let e = t.planets.find((e) => e.uid === i.planet), n = e?.biome && j[e.biome.data];
				n && Ee(t, n.cost) && (n.cost.kind === "draw" ? t.hand.filter((e) => n.cost.tag === void 0 || D[e - 1].type === n.cost.tag).forEach((e) => r("biomeTrigger", e)) : r("biomeTrigger", 0));
				break;
			}
			case "focusBiome":
				t.planets.filter((e) => e.uid === i.planet && e.biome && (n === 2 || !j[e.biome.data].scarce)).forEach((e) => r("biomeTrigger", e.uid));
				break;
			case "biomeBatch":
				t.planets.filter((e) => e.biome && i.targets?.includes(e.uid) && !i.used?.includes(e.uid)).forEach((e) => r("biomeTrigger", e.uid));
				break;
			case "conditionReward":
				for (let e = 0; e < (i.tag === 51 ? 3 : 4); e++) r("pickCondition", e);
				break;
			case "samePlanet": t.planets.filter((e) => e.system === i.system).forEach((e) => {
				for (let t = 0; t < (n === 2 ? 2 : 3); t++) (t === 0 || e.life[t - 1] > 0) && e.life[t] < 5 && e.life[t + +(n === 2)] < 5 && r("advance", e.uid, t, n);
			});
		}
		!["lifeOrder", "placePlanet"].includes(i.kind) && (i.kind !== "life" || i.tag !== 9) && !ke(i) && r("skip");
	}
	return e.phase === "resolve" && e.actionWindow && !i?.kind.startsWith("ghost") && !ke(i) && t.entropy >= 2 && (r("exchange", 0), r("exchange", 1)), (e.phase !== "resolve" || !ke(i) && !i?.kind.startsWith("ghost")) && t.planets.filter((t) => ye(e, t)).forEach((e) => {
		n.some((t) => t.kind === "fulfill" && t.args[0] === e.uid) || r("fulfill", e.uid);
	}), (e.tasks.slice(1).some((e) => e.kind === "life" && e.tag === 9 || ["landing", "main"].includes(e.kind) && !e.outer && x[t.position] === "life") ? n.filter((t) => {
		if (![
			"play",
			"asteroid",
			"advance",
			"biomeTrigger",
			"evolve"
		].includes(t.kind)) return !0;
		let n = structuredClone(e);
		return Ve(n, {
			...t,
			id: ""
		}), t.kind === "evolve" && t.args[0] >= 0 && (R(n).systems.find((e) => e.uid === t.args[0]).star = t.args[1]), ve(n, R(n)).length > 0;
	}) : n).map((e, t) => ({
		...e,
		id: String(t)
	}));
}
function ke(e) {
	return !e || [
		"main",
		"landing",
		"lifeFinish",
		"focus",
		"checkpoint",
		"ghostMove",
		"ghostCard",
		"next",
		"animalReward",
		"missionReward",
		"starCommit",
		"focusStarBefore"
	].includes(e.kind);
}
function Ae(e, t) {
	let n = R(e);
	e.actionWindow = !0;
	let r = t.outer ? e.outer[n.position] : x[n.position];
	if (r === "soup") {
		V(e, ...H([
			C("generator"),
			C("mass"),
			C("energy")
		]));
		return;
	}
	V(e, {
		kind: r,
		n: r === "draw" ? 2 : 1,
		...r === "activate" ? { tag: 1 } : {},
		...t.outer ? {} : {
			focus: t.marker === 3 ? 0 : n.levels[t.marker],
			tag: r === "life" ? 9 : void 0,
			bonus: t.bonus
		}
	});
}
function je(e, t, n) {
	for (let r = 0; r < n; r++) t.generatorSteps++, t.generator < 6 && t.generator++, t.generator >= 4 && !q(e, 8) && (t.vp += 3);
}
function Me(e, t) {
	t.biome && !t.biome.fulfilled && (t.biome.fulfilled = !0, R(e).events[2]++, U(e, "fulfill", [t.uid]));
}
function Ne(e) {
	e.systemsLeft--;
	let t = {
		uid: e.uid++,
		star: -1,
		starting: !1
	};
	return R(e).systems.push(t), t;
}
function Pe(e, t, n, r, i) {
	return {
		kind: "focus",
		tag: e,
		n: t,
		planet: n,
		system: r,
		card: i
	};
}
function Fe(e, t) {
	let n = R(e), r = t.n ?? 0;
	if (!r) return;
	let i = n.planets.find((e) => e.uid === t.planet), a = n.systems.find((e) => e.uid === t.system);
	if (t.tag === 0) n.focus === "B" && V(e, {
		kind: "asteroid",
		tag: r === 2 ? 1 : void 0
	}), n.focus === "C" && a && a.star >= 0 && V(e, {
		kind: "vp",
		n: T[a.star].tier * r
	}), n.focus === "D" && a && V(e, {
		kind: "samePlanet",
		system: a.uid,
		n: r
	});
	else if (t.tag === 1 && i) n.focus === "A" && V(e, {
		kind: r === 2 ? "setOrFulfill" : "biome",
		tag: 1
	}), n.focus === "B" && V(e, {
		kind: "bacteria",
		n: r,
		planet: i.uid,
		tag: 9
	}), n.focus === "C" && V(e, {
		kind: "generator",
		n: r
	}), n.focus === "D" && V(e, {
		kind: "vp",
		n: r === 2 ? n.planets.length : n.planets.filter((e) => k[e.data].type === k[i.data].type).length
	});
	else if (t.tag === 2 && i && t.card) {
		let a = D[t.card - 1];
		n.focus === "A" && V(e, {
			kind: "vp",
			n: r === 2 ? n.planets.reduce((e, t) => e + t.cards.length, 0) : B(n, a.type)
		}), n.focus === "B" && V(e, {
			kind: "vp",
			n: z(a.env) * r
		}), n.focus === "C" && V(e, {
			kind: "focusBiome",
			planet: i.uid,
			n: r
		}), n.focus === "D" && V(e, {
			kind: "draw",
			tag: a.type,
			n: r
		});
	}
}
function Ie(e, t, n, r) {
	let i = R(e), a = i.planets, o = a.flatMap((e) => e.cards), s = a.flatMap((e) => e.asteroids), c = 0, l = [];
	switch (t) {
		case 45:
			c = a.filter((e) => k[e.data].type === r).length, l = [C("entropy"), C("vp", 2)];
			break;
		case 46:
			c = a.filter((e) => e.biome?.fulfilled).length, l = [C("plant"), C("vp", 3)];
			break;
		case 47:
			c = new Set(a.map((e) => k[e.data].type)).size, l = [C("energy"), C("vp", 2)];
			break;
		case 48:
			c = a.filter((e) => k[e.data].type === 1).length, l = [C("bacteria"), C("vp", 2)];
			break;
		case 49:
			c = new Set(i.systems.filter((e) => e.star >= 0).map((e) => T[e.star].tier)).size, l = [C("vp", 2)];
			break;
		case 50:
			c = a.filter((e) => e.life[2] > 0).length, l = [C("entropy"), C("vp", 3)];
			break;
		case 51:
			c = o.filter((e) => D[e - 1].type === r).length, l = [C("energy"), C("vp", 2)];
			break;
		case 52:
			c = a.filter((e) => k[e.data].type === 0).length, l = [C("mass"), C("vp", 2)];
			break;
		case 53:
			c = a.filter((e) => e.biome).length, l = [C("bacteria"), C("vp", 2)];
			break;
		case 54:
			c = z(i.levels), l = [C("plant"), C("vp", 2)];
			break;
		case 55:
			c = a.filter((e) => k[e.data].type === 3).length, l = [C("vp", 3)];
			break;
		case 56:
			c = s.filter((e) => e.type === r).length, l = [C("bacteria"), C("vp", 2)];
			break;
		case 57:
			c = a.filter((e) => k[e.data].type === 2).length, l = [C("vp", 2)];
			break;
		case 58:
			c = i.generatorSteps, l = [C("mass"), C("vp", 2)];
			break;
		case 59:
			c = a.filter((e) => e.life[0] > 0).length, l = [C("entropy"), C("vp", 2)];
			break;
		case 60:
			c = i.systems.reduce((e, t) => e + (t.star < 0 ? 0 : T[t.star].tier), 0), l = [C("vp")];
			break;
		case 61:
			c = o.length, l = n === 1 ? [C("entropy"), C("vp", 2)] : [C("vp")];
			break;
		case 62:
			c = s.length, l = [C("mass"), C("vp", 2)];
			break;
		case 63:
			c = a.length, l = [C("vp")];
			break;
		case 64:
			c = a.filter((e) => e.life[1] > 0).length, l = [C("vp", 3)];
			break;
		case 65:
			c = new Set(s.map((e) => e.type)).size, l = [C("energy"), C("vp", 3)];
			break;
		case 66:
			c = 1, l = [C("vp", 9)];
			break;
		case 67:
			c = i.systems.filter((e) => e.star >= 0).length, l = [C("vp")];
			break;
		case 68: c = o.length, l = [C("vp")];
	}
	return l.map((e) => ({
		...e,
		n: e.n * c * n
	})).filter((e) => e.n > 0);
}
function Le(e, t, n) {
	let r = R(e), i = r.planets;
	switch (t) {
		case 1: return [C("mass", 2 * i.filter((e) => e.biome).length)];
		case 2: return [C("entropy", 2 * (B(r, 0) + B(r, 1)))];
		case 3: return [C("plant", r.systems.filter((e) => e.star >= 0).length)];
		case 4: return [C("plant", i.length)];
		case 5: return [C("energy", 2 * (B(r, 1) + B(r, 2)))];
		case 6: return [C("entropy", 2 * i.length)];
		case 7: return [C("bacteria", ge(r)[n ?? 0])];
		case 8: return [C("draw", i.filter((e) => z(e.life) > 0).length)];
		case 9: return [C("mass", 2 * (B(r, 0) + B(r, 2)))];
		case 10: return [C("energy", 2 * z(r.levels))];
		case 11: return [C("draw", r.generatorSteps)];
		case 12: return [C("bacteria", i.reduce((e, t) => e + t.asteroids.length, 0))];
		default: return [];
	}
}
function Re(e, t) {
	let n = e.ghost;
	n.life[t] >= 5 || (n.life[t]++, n.life[t] === 3 && e.small[t].length && (n.tiles += e.small[t].shift()), n.life[t] === 5 && e.big[t] && (n.tiles += 20, e.big[t] = !1, e.completed++));
}
function ze(e, t) {
	let n = e.ghost;
	n.deck.length || (n.deck = W(e, n.discard.filter((e) => e >= 7 && e <= 18)), n.discard = []);
	let r = n.deck.shift();
	if (r === void 0) return;
	if (n.lastCard = r, r === 19) {
		V(e, {
			kind: "ghostCard",
			n: 2
		});
		return;
	}
	n.discard.push(r);
	let i = oe[r - 1];
	for (let r = 0; r < (t.n ?? 1); r++) i.track >= 0 && be(e, n, i.track), i.life >= 0 && Re(e, i.life);
	for (let [t, n] of i.cards) K(e.lifeDecks[t], n);
	i.planet && K(e.planetDecks[i.planet[0]], i.planet[1]), i.biome && K(e.biomeDecks[i.biome[0]], i.biome[1]), n.remaining = n.deck.length, xe(e), U(e, "progress", [r, t.n ?? 1]);
}
function Be(e) {
	let t = e.tasks.shift();
	if (!t) return;
	let n = R(e);
	switch (t.kind) {
		case "landing": {
			let r = t.distance + (t.bonus ?? 0), i = t.outer ? e.outer[n.position] : x[n.position], a = Math.max(0, 3 - r), o = [];
			i === "evolve" ? o.push({
				kind: "energy",
				n: a
			}) : i === "aggregate" || i === "asteroid" ? o.push({
				kind: "mass",
				n: a
			}) : i === "soup" ? o.push({
				kind: "advance",
				n: a
			}) : i !== "life" && o.push({
				kind: "entropy",
				n: a
			});
			let s = n.planets.filter((e) => e.biome && j[e.biome.data].trigger === i).map((e) => e.uid);
			V(e, ...o.filter((e) => (e.n ?? 1) > 0), ...s.length ? [{
				kind: "biomeBatch",
				used: [],
				targets: s
			}] : [], {
				...t,
				kind: "main",
				bonus: a,
				tag: void 0
			});
			break;
		}
		case "main":
			Ae(e, t);
			break;
		case "lifeFinish": {
			let r = n.planets.find((e) => e.uid === t.planet);
			r.cards.push(t.card), V(e, Pe(2, t.focus ?? 0, r.uid, r.system, t.card)), U(e, "play", [t.card, r.uid]);
			break;
		}
		case "focus":
			Fe(e, t);
			break;
		case "focusStarBefore": {
			let r = n.systems.find((e) => e.uid === t.system), i = Te(e, r.star, 0, t.n === 2);
			n.entropy >= i ? V(e, {
				kind: "activateOne",
				system: r.uid,
				free: t.n === 2,
				tag: 8
			}, {
				kind: "starCommit",
				system: r.uid,
				data: t.data,
				n: t.bonus,
				focus: t.focus
			}) : V(e, {
				kind: "starCommit",
				system: r.uid,
				data: t.data,
				n: t.bonus,
				focus: t.focus
			});
			break;
		}
		case "starCommit": {
			let r = t.n ?? 0;
			if (n.energy < r) {
				U(e, "unaffordable");
				break;
			}
			let i = t.system === -1 ? Ne(e) : n.systems.find((e) => e.uid === t.system);
			n.energy -= r, i.star >= 0 && !i.starting && e.stars[i.star]++, i.starting = !1, i.star = t.data, e.stars[i.star]--, T[i.star].tier >= 3 && n.events[0]++, V(e, Pe(0, t.focus ?? 0, void 0, i.uid)), U(e, "evolve", [i.uid, i.star]);
			break;
		}
		case "animalReward":
			[
				45,
				51,
				56
			].includes(t.tag) ? V(e, {
				kind: "conditionReward",
				tag: t.tag,
				n: t.n
			}) : V(e, ...H(Ie(e, t.tag, t.n ?? 1)));
			break;
		case "missionReward":
			t.tag === 7 ? V(e, {
				kind: "conditionReward",
				tag: 7,
				n: 1
			}) : V(e, ...H(Le(e, t.tag)));
			break;
		case "checkpoint":
			Se(e), e.phase = "mission", e.actionWindow = !1;
			break;
		case "ghostMove": {
			let t = e.ghost, r = 4 - e.distance, i = (t.position + r) % 6;
			i === n.position && (r++, i = (i + 1) % 6);
			let a = Array.from({ length: r }, (e, n) => (t.position + n + 1) % 6).includes(t.deckAt);
			t.position = i, U(e, "ghost", [i]), a && V(e, { kind: "ghostCard" });
			break;
		}
		case "ghostCard":
			ze(e, t);
			break;
		case "next":
			if (n.markers.forEach((e) => e.tired = !1), e.turn === e.players.length - 1) {
				if (e.endRound !== null && e.round >= e.endRound) {
					e.phase = "done", e.tasks = [];
					break;
				}
				e.round++;
			}
			e.turn = (e.turn + 1) % e.players.length, e.phase = "move", e.actionWindow = !1, e.tasks = [];
	}
}
function Ve(e, t) {
	let n = R(e), r = t.args, i = e.tasks[0], a = t.kind;
	if (a === "exchange") {
		n.entropy -= 2, r[0] === 0 ? n.energy++ : n.mass++, U(e, "exchange", r);
		return;
	}
	if (a === "fulfill") {
		Me(e, n.planets.find((e) => e.uid === r[0])), i && ["fulfill", "setOrFulfill"].includes(i.kind) && e.tasks.shift();
		return;
	}
	if (a === "move") {
		let [t, i, a, o] = r;
		e.distance = t, e.phase = "resolve", e.actionWindow = !1;
		let s = Array.from({ length: t }, (e, t) => (n.position + t + 1) % 6), c = [];
		for (let e of s) for (let t of n.markers) t.position === e && (t.locked ? t.locked = !1 : (t.position = -1, t.tired = !0, c.push({ kind: "recovery" })));
		n.position = s.at(-1), n.outer = !!i, t === 3 && o && n.entropy--, i || (n.markers[a].position = n.position, a === 3 && q(e, 9) && (n.markers[a].locked = !0)), V(e, ...c, {
			kind: "landing",
			distance: t,
			outer: !!i,
			marker: a,
			bonus: o
		}, { kind: "checkpoint" }), U(e, "move", [
			n.position,
			i,
			a
		]);
		return;
	}
	if (a === "mission") {
		n.missions = [], e.phase = "resolve", e.actionWindow = !1, V(e, {
			kind: "missionReward",
			tag: r[0]
		}, { kind: "checkpoint" }), U(e, "mission", r);
		return;
	}
	if (a === "challenge") {
		e.ghost.challenges[r[0]].done = !0, U(e, "challenge", [r[0]]);
		return;
	}
	if (a === "end") {
		Se(e), e.phase = "resolve", V(e, ...e.ghost ? [{ kind: "ghostMove" }] : [], { kind: "next" });
		return;
	}
	if (!i) return;
	e.tasks.shift();
	let o = (t = (i.n ?? 1) - 1) => {
		t > 0 && V(e, {
			...i,
			n: t
		});
	};
	if (a !== "skip") {
		if (a === "gain") {
			let t = i.n ?? 1;
			if ([
				"energy",
				"mass",
				"entropy",
				"vp"
			].includes(i.kind) && (n[i.kind] += t), i.kind === "generator" && je(e, n, t), i.kind === "recovery" && n.entropy++, i.kind === "lifeYield") {
				let e = n.planets.find((e) => e.uid === i.planet), t = D[i.card - 1];
				e.life[t.type] = Math.min(5, e.life[t.type] + t.yield + (i.bonus ?? 0));
			}
		} else if (a === "evolve") {
			let [t, a, o] = r;
			n.focus === "A" && (i.focus ?? 0) > 0 && t !== -1 && n.systems.find((e) => e.uid === t).star >= 0 ? V(e, {
				kind: "focusStarBefore",
				system: t,
				data: a,
				n: i.focus,
				bonus: o,
				focus: i.focus
			}) : V(e, {
				kind: "starCommit",
				system: t,
				data: a,
				n: o,
				focus: i.focus
			});
		} else if (a === "aggregate") {
			let [t, a, o] = r;
			n.mass -= k[o].cost, K(e.planetDecks[t], a), V(e, ...H(k[o].effects), {
				kind: "placePlanet",
				data: o,
				focus: i.focus
			}), U(e, "aggregate", [o]);
		} else if (a === "placePlanet") {
			let t = r[0] === -1 ? Ne(e) : n.systems.find((e) => e.uid === r[0]), a = {
				uid: e.uid++,
				data: i.data,
				system: t.uid,
				life: [
					0,
					0,
					0
				],
				cards: [],
				asteroids: [],
				biome: null
			};
			n.planets.push(a), V(e, Pe(1, i.focus ?? 0, a.uid, t.uid));
		} else if (a === "play") {
			let [t, a, o] = r, s = n.planets.find((e) => e.uid === a), c = D[t - 1];
			n.hand = n.hand.filter((e) => e !== t && e !== o), o && (e.lifeDecks[D[o - 1].type][0].push(o), pe(e.lifeDecks[D[o - 1].type])), c.consume && (s.life[c.type - 1] -= c.require), V(e, {
				kind: "lifeOrder",
				card: t,
				planet: a,
				bonus: i.bonus,
				focus: i.focus
			});
		} else if (a === "order") {
			let t = D[i.card - 1], n = {
				kind: "lifeYield",
				card: i.card,
				planet: i.planet,
				bonus: i.bonus
			}, a = H(t.effects);
			V(e, ...r[0] === 0 ? [n, ...a] : [...a, n], {
				kind: "lifeFinish",
				card: i.card,
				planet: i.planet,
				focus: i.focus
			});
		} else if (a === "draw") {
			let [t, i] = r;
			n.hand.push(K(e.lifeDecks[t], i)), o();
		} else if (a === "activate") {
			let t = n.systems.find((e) => e.uid === r[0]);
			n.entropy -= r[1], i.kind === "activate" && V(e, {
				...i,
				n: (i.n ?? 1) + 1,
				used: [...i.used ?? [], t.uid]
			}), V(e, ...H(T[t.star].effects)), U(e, "activate", [t.uid, t.star]);
		} else if (a === "upgrade") {
			let t = r[0];
			i.tag !== 1 && (n.energy -= 3), q(e, 3) && n.mass--, n.levels[t]++, n.markers[t].position >= 0 && (n.markers[t].position = -1, n.markers[t].tired = !0), U(e, "upgrade", [t, n.levels[t]]);
		} else if (a === "biome") {
			let [t, i, a, o] = r;
			n.planets.find((e) => e.uid === t).biome = {
				data: o,
				fulfilled: !1
			}, K(e.biomeDecks[i], a), U(e, "biome", [t, o]);
		} else if (a === "asteroid") {
			let [t, i, a, o, s, c] = r, l = n.planets.find((e) => e.uid === t);
			n.mass -= c, o >= 0 && l.life[o]--, s && (n.hand = n.hand.filter((e) => e !== s), e.lifeDecks[D[s - 1].type][0].push(s)), n.planets.some((e) => e.system === l.system && e.asteroids.length > 0) || n.events[1]++, l.asteroids.push({
				type: i,
				slot: a
			}), e.asteroids[i]--, V(e, ...H(k[l.data].effects)), U(e, "asteroid", [
				t,
				i,
				a
			]);
		} else if (a === "advance" || a === "addLife") {
			let e = n.planets.find((e) => e.uid === r[0]), t = r[1];
			i.kind === "samePlanet" ? (t > 0 && e.life[t - 1]--, e.life[t + +((i.n ?? 1) === 2)]++) : (a === "advance" && t > 0 && e.life[t - 1]--, e.life[t]++, o());
		} else if (a === "retrieve") {
			let e = n.markers[r[0]];
			e.position = -1, e.tired = !0, o();
		} else if (a === "biomeTrigger") {
			if (i.kind === "focusBiome") {
				V(e, {
					kind: "biomeTrigger",
					planet: i.planet
				});
				return;
			}
			if (i.kind === "biomeBatch") {
				V(e, {
					...i,
					used: [...i.used ?? [], r[0]]
				}), V(e, {
					kind: "biomeTrigger",
					planet: r[0]
				});
				return;
			}
			let t = n.planets.find((e) => e.uid === i.planet), a = j[t.biome.data];
			a.cost.kind === "draw" ? (n.hand = n.hand.filter((e) => e !== r[0]), e.lifeDecks[D[r[0] - 1].type][0].push(r[0])) : De(n, a.cost), V(e, ...H([...a.effects, ...t.biome.fulfilled ? a.improved : []])), U(e, "biomeTrigger", [t.uid, a.id]);
		} else a === "pickCondition" && (i.tag === 7 ? V(e, ...H(Le(e, 7, r[0]))) : V(e, ...H(Ie(e, i.tag, i.n ?? 1, r[0]))));
	}
}
function He(e, t, n) {
	let r = {
		players: [],
		turn: 0,
		round: 1,
		endRound: null,
		phase: "move",
		revision: 0,
		seed: n,
		cursor: 0,
		uid: 1,
		outer: [],
		lifeDecks: [],
		planetDecks: [],
		biomeDecks: [],
		stars: T.map((e) => e.count),
		asteroids: [
			10,
			10,
			10,
			10
		],
		systemsLeft: 20,
		small: [],
		big: [
			!0,
			!0,
			!0
		],
		completed: 0,
		config: e,
		ghost: null,
		tasks: [],
		actionWindow: !1,
		distance: 0,
		log: []
	};
	r.outer = W(r, [...S]), r.lifeDecks = [
		0,
		1,
		2
	].map((e) => [W(r, D.filter((t) => t.type === e).map((e) => e.id)), []]), r.planetDecks = [
		0,
		1,
		2,
		3
	].map((e) => G(W(r, k.filter((t) => !t.starting && t.type === e).map((e) => e.id)))), r.biomeDecks = [!1, !0].map((e) => G(W(r, j.filter((t) => t.scarce === e).map((e) => e.id))));
	let i = W(r, [
		0,
		1,
		2,
		3,
		4,
		5
	]), a = W(r, [
		44,
		45,
		46,
		47,
		48,
		49,
		50,
		51
	]), o = W(r, [
		1,
		2,
		3,
		4,
		5,
		6,
		7,
		8,
		9,
		10,
		11,
		12
	]), s = W(r, [
		"A",
		"B",
		"C",
		"D"
	]);
	for (let n = 0; n < t.length; n++) {
		let c = re[i[n]], l = k[a[n]], u = r.outer.indexOf(c.space), d = r.uid++, f = {
			rid: t[n],
			energy: c.energy,
			mass: l.starting[0],
			entropy: l.starting[1],
			vp: 0,
			position: u,
			outer: !0,
			markers: [
				0,
				1,
				2,
				3
			].map((e) => ({
				position: e === 3 ? u : -1,
				tired: !1,
				locked: e === 3
			})),
			focus: e.focus === "random" ? s[n] : e.focus,
			levels: [
				0,
				0,
				0
			],
			generator: 0,
			generatorSteps: 0,
			systems: [{
				uid: d,
				star: c.star,
				starting: !0
			}],
			planets: [{
				uid: r.uid++,
				data: l.id,
				system: d,
				life: [
					0,
					0,
					0
				],
				cards: [],
				asteroids: [],
				biome: null
			}],
			tracks: [
				0,
				0,
				0
			],
			events: [
				0,
				0,
				0
			],
			small: [
				0,
				0,
				0
			],
			big: [
				0,
				0,
				0
			],
			hand: [],
			missions: t.length === 1 ? [] : o.splice(0, 2),
			handCount: 0,
			missionCount: 0
		};
		c.hand.forEach((e, t) => {
			for (let n = 0; n < e; n++) f.hand.push(r.lifeDecks[t][0].shift());
		}), r.players.push(f), r.systemsLeft--;
	}
	r.lifeDecks = r.lifeDecks.map((e) => G(e[0]));
	let c = t.length <= 2 ? [15, 9] : t.length === 3 ? [
		15,
		12,
		9
	] : [
		15,
		12,
		9,
		6
	];
	if (r.small = [
		0,
		1,
		2
	].map(() => [...c]), t.length === 1) {
		let t = W(r, [
			1,
			2,
			3,
			4,
			5,
			6
		]), n = W(r, [
			7,
			8,
			9,
			10,
			11,
			12,
			13,
			14,
			15,
			16,
			17,
			18
		]);
		e.progress === "standard" && (t = t.slice(2), n = n.slice(2)), e.progress === "bOnly" && (t = [], n = n.slice(3));
		let i = [...t, ...n];
		e.doubleProgress && (i = [...i.slice(0, -3), ...W(r, [...i.slice(-3), 19])]);
		let a = [
			0,
			1,
			2
		].map((t) => {
			let n = W(r, [
				1,
				2,
				3,
				4
			].map((e) => e + t * 4));
			return {
				require: n[0],
				constraint: e.advanced ? n[1] : 0,
				done: !1
			};
		});
		r.ghost = {
			position: (r.players[0].position + 1) % 6,
			deckAt: (r.players[0].position + 1) % 6,
			tracks: [
				0,
				0,
				0
			],
			life: [
				0,
				0,
				0
			],
			tiles: 0,
			challenges: a,
			lastCard: 0,
			remaining: i.length,
			discard: [],
			deck: i
		};
	}
	return { state: r };
}
function Ue(e, t, n) {
	if (t.type === "tick") {
		if (e.phase !== "resolve" || !ke(e.tasks[0])) return { state: e };
		let t = structuredClone(e);
		return Be(t), t.revision++, { state: t };
	}
	if (e.phase === "done" || R(e).rid !== n.by) return { code: "games.entropy.errTurn" };
	if (t.revision !== e.revision) return { code: "games.entropy.errChoice" };
	let r = Oe(e).find((e) => e.id === t.id);
	if (!r) return { code: "games.entropy.errChoice" };
	let i = structuredClone(e);
	return Ve(i, r), i.revision++, { state: i };
}
function We(e, t, n) {
	let r = [
		0,
		1,
		2,
		3
	].map((t) => e.planets.filter((e) => k[e.data].type === t).length), i = t.alternative ? [
		e.planets.reduce((e, t) => e + t.asteroids.filter((e) => e.slot === 1).length, 0),
		e.planets.filter((e) => e.life.every((e) => e > 0)).length,
		z(e.levels)
	] : [
		Math.max(0, ...r),
		e.planets.filter((e) => e.biome && e.cards.length > 0).length,
		new Set(e.systems.filter((e) => e.star >= 0).map((e) => e.star)).size
	], a = e.tracks.map((e, t) => ie[e] * i[t]), o = z(e.small) + z(e.big), s = Math.floor((e.handCount + e.energy + e.mass + e.entropy) / 4), c = n ? n.challenges.reduce((e, t, n) => e + (t.done ? (n + 1) * 5 : 0), 0) : 0;
	return {
		vp: e.vp,
		life: o,
		main: a,
		resources: s,
		challenges: c,
		total: e.vp + o + z(a) + s + c
	};
}
function Ge(e) {
	let { hand: t, missions: n, ...r } = e;
	return {
		...r,
		handCount: t.length,
		missionCount: n.length
	};
}
function Ke(e) {
	return e.ghost ? e.ghost.tiles + z(e.ghost.tracks.map((e) => ie[e])) * e.config.ghostMultiplier : 0;
}
function qe(e, t) {
	let n = e.players.map(Ge), r = e.players.find((e) => e.rid === t), i = (e) => e.map((e) => e.map((e) => ({
		top: e[0] ?? null,
		count: e.length
	}))), a = e.ghost, o = a ? {
		position: a.position,
		deckAt: a.deckAt,
		tracks: a.tracks,
		life: a.life,
		tiles: a.tiles,
		challenges: a.challenges,
		lastCard: a.lastCard,
		remaining: a.deck.length,
		discard: a.discard
	} : null;
	return {
		public: {
			players: n,
			turn: R(e).rid,
			round: e.round,
			endRound: e.endRound,
			phase: e.phase,
			revision: e.revision,
			outer: e.outer,
			market: {
				life: i(e.lifeDecks),
				planets: i(e.planetDecks),
				biomes: i(e.biomeDecks)
			},
			stars: e.stars,
			asteroids: e.asteroids,
			systemsLeft: e.systemsLeft,
			small: e.small,
			big: e.big,
			completed: e.completed,
			config: e.config,
			ghost: o,
			prompt: e.phase === "resolve" ? e.tasks[0]?.kind ?? "next" : e.phase,
			pending: {
				n: e.tasks[0]?.n ?? 1,
				tag: e.tasks[0]?.tag ?? null,
				planet: e.tasks[0]?.planet ?? null,
				system: e.tasks[0]?.system ?? null,
				card: e.tasks[0]?.card ?? null,
				data: e.tasks[0]?.data ?? null,
				bonus: e.tasks[0]?.bonus ?? 0
			},
			log: e.log,
			scores: Object.fromEntries(n.map((t) => [t.rid, We(t, e.config, o)])),
			ghostScore: Ke(e)
		},
		private: {
			hand: r?.hand ?? [],
			missions: r?.missions ?? [],
			choices: R(e).rid === t ? Oe(e) : []
		}
	};
}
function Je(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = qe(e, "").public, n = e.players.map((e) => e.rid).sort((e, n) => t.scores[n].total - t.scores[e].total);
	return {
		phase: "done",
		ranking: n,
		winner: e.ghost ? e.ghost.challenges.filter((e) => e.done).length >= 2 && t.scores[n[0]].total > Ke(e) ? n : [] : n.filter((e) => t.scores[e].total === t.scores[n[0]].total),
		scores: Object.fromEntries(n.map((e) => [e, t.scores[e].total]))
	};
}
var Ye = {
	meta: se,
	saveCompatibility: { version: "1" },
	schemas: {
		action: N,
		publicView: de,
		privateView: fe,
		config: M
	},
	setup: He,
	reduce: Ue,
	viewFor: qe,
	status: Je,
	nextTickIn: (e) => e.phase === "resolve" && ke(e.tasks[0]) ? 350 : null
}, Xe = {
	selectPlanet: "选择目标行星",
	confirm: "确认行动",
	cancel: "取消选择",
	wait: "等待行动",
	resultsTitle: "宇宙成果",
	viewBoard: "回看最终局面",
	viewResults: "查看计分",
	confirmAgain: "确认再来一局？",
	confirmBack: "确认返回大厅？",
	victory: "胜利",
	defeat: "考验未通过",
	tie: "共同胜利",
	name: "重塑宇宙",
	desc: "引导恒星演化，塑造行星，孕育生命，接受宇宙创造者的最终考验。",
	rules: "目标：\n以恒星、行星与生命建立自己的宇宙，获得最多胜利分。支持 2–4 人竞争，以及 1 人对抗幽灵科学家的官方单人模式。\n准备：行动板块随机置于六个扇区外侧。每人获得随机起始恒星、起始行星、相应资源与生命牌、三个 Focus 和四枚创造标记。多人每人两张秘密任务牌；单人改用三项挑战。\n回合：依次执行移动、动作、任务检查；单人随后移动幽灵科学家。\n移动：沿顺时针方向移动 1–3 格，选择内圈或外圈落点。内圈依次为演化恒星、创造生命、聚合行星，循环两次。落内圈必须放置对应创造标记或万能标记；横置或已在主板的标记不可使用。经过自己的主板标记时必须回收并横置，每枚可选择支付熵激活一颗恒星，或获得1点熵。万能标记第一次经过只解锁。横置标记于回合结束时恢复可用。\n交通奖励：通常，移动1格获得2份交通奖励，移动2格获得1份，移动3格不获得；落点被其他科学家占用时按多走一格计算，实际移动3格且落点被其他科学家占用时，还须支付1点熵。两人所有内外对应格视为合并；三人隔一扇区合并；四人分别占位。恒星行动奖励能量、行星和小行星行动奖励质量、生命行动增加本次生命产量、原初汤奖励进化生命，其余外圈奖励熵。\n动作：可放弃奖励；除创造生命外，允许只领取交通奖励而不执行行动。动作阶段可不限次数支付2点熵，兑换1点能量或1点质量。\n演化恒星：支付1点能量，取得一颗 I 级恒星，放入无恒星的星系或新星系；或按演化树升级，升级至II、III或IV级，分别需要支付2、3或4点能量。升级本身不激活恒星。每个星系最多一颗恒星和两颗行星，星系板块及星体供应有限。\n聚合行星：从同类型双列市场顶端选择行星，支付质量，先执行其效果，再放到空行星位或新星系。行星上有无环境图标以该板块为准。\n创造生命：从手牌选择生命牌及目标行星。环境要求只统计该行星、其小行星及所属恒星；可弃另一张手牌，取弃牌上一个环境图标补足一个要求。黄色生命要求只需拥有，红色要求必须消耗。随后自行决定先增加本地生命还是执行牌底效果，最后才将牌放到行星旁。每颗行星最多三张生命牌，每类生命最多五个。\n激活恒星：支付对应等级的熵，逐颗激活任意数量恒星，每颗在该动作中最多一次。发电机折扣只适用于落在“激活恒星”行动时；回收标记等额外激活不享受折扣。\n设置生物群系：从市场取一块放在没有群系的行星上，永久绑定。落在指定行动后可领取其奖励；稀缺群系及部分富饶群系需支付板块所示费用。满足本地生命要求后可免费完成群系，翻面后增强奖励。无条件完成效果忽略生命要求。\n升级控制台：支付3点能量，将一个 Focus 升一级，最高二级，并回收对应的主板标记横置；此次回收没有恒星激活或熵奖励。使用对应创造标记时触发 Focus，万能标记不触发。四组 Focus 的具体能力可在控制台查看。\n抽取生命牌：从公开双列市场依次取两张，立即补充。没有手牌上限。一列耗尽时从另一同类型列补充；供应全部耗尽后不补造。\n捕获小行星：每颗行星有两个槽，一个槽位需要支付2点质量，另一个槽位需要移除本地1个任意种类的生命。水或辐射小行星还须额外支付1点质量。安装后再触发行星效果。免费捕获免除这些成本。\n原初汤：发电机推进一格，获得1点质量和1点能量。进化生命可新增一个细菌，或将一个细菌变为植物，或将一个植物变为动物。发电机最后三格各奖励 3 分，到顶后继续推进每次也获得 3 分。\n任务与目标：回合末可完成一张已达条件的任务并领取奖励，随后两张任务都弃掉。升级至 III 或 IV 级恒星、在某星系安装第一颗小行星、完成生物群系分别推进三条主目标；最终格只允许一位玩家占有。累计生命达到小目标可每类领取一次，达到大目标则抢夺唯一的 20 分奖励。\n结束：三条主目标最终格和三个生命大目标中，任意两个完成即触发结束；打完当前轮，再进行完整一轮。得分为过程胜利分、生命目标、主目标与剩余资源。主目标各格分值为 0/1/3/5/7/10，各主目标分别采用以下乘数：\n· 第一条主目标：数量最多的同类型行星数量。\n· 第二条主目标：同时具有生物群系和生命牌的行星数量。\n· 第三条主目标：不同种类的恒星数量。\n使用替代目标时，三条主目标的乘数依次改为：\n· 生命成本槽中的小行星数量。\n· 三类生命齐全的行星数量。\n· Focus的升级总级数。\n将剩余生命手牌数量与能量、质量、熵的数量合计，每满4个获得1分。多人同分共享胜利。\n单人：不用任务牌。幽灵起始在玩家下一内圈格；玩家移动 1/2/3 格后，幽灵分别移动 3/2/1 格，与玩家重合则再走一格。越过进度牌堆时抽牌，推进幽灵目标并移除指定市场组件。重洗时仅保留 B 牌。幽灵每类生命进度第三步领取小目标，第五步领取大目标。标准挑战各色一张；进阶挑战每色另有一张约束，完成对应挑战后解除约束。不同颜色挑战的分值如下：\n· 绿色挑战获得5分。\n· 黄色挑战获得10分。\n· 红色挑战获得15分。\n至少完成两项挑战，且总分严格超过幽灵才能获胜；幽灵得分为生命目标分加三条主目标分值总和乘难度倍率。设置中可选官方牌堆、倍率和双倍进度调整。",
	errTurn: "现在尚未轮到你行动。",
	errChoice: "局面已更新，请重新选择。",
	board: "公共盘面",
	universe: "恒星系",
	hand: "手牌",
	objectives: "目标",
	console: "控制台",
	market: "供应区",
	details: "详情",
	close: "关闭",
	choose: "选择行动",
	waiting: "等待 {{name}} 行动",
	round: "第 {{n}} 轮",
	lastRound: "最后一轮",
	resources: [
		"能量",
		"质量",
		"熵",
		"胜利分"
	],
	conditions: [
		"热",
		"碳",
		"水",
		"辐射"
	],
	lifeTypes: [
		"细菌",
		"植物",
		"动物"
	],
	space: {
		evolve: "演化恒星",
		aggregate: "聚合行星",
		life: "创造生命",
		activate: "激活恒星",
		biome: "设置生物群系",
		draw: "抽取生命牌",
		upgrade: "升级控制台",
		asteroid: "捕获小行星",
		soup: "原初汤"
	},
	effects: {
		energy: "能量",
		mass: "质量",
		entropy: "熵",
		vp: "胜利分",
		generator: "发电机推进",
		bacteria: "细菌",
		plant: "植物",
		animal: "动物",
		anyLife: "任意生命",
		advance: "进化生命",
		retrieve: "回收创造标记",
		fulfill: "无条件完成生物群系",
		setOrFulfill: "设置或无条件完成生物群系",
		activateOne: "激活一颗恒星",
		animalReward: "按条件获得奖励"
	},
	prompt: {
		move: "移动科学家，选择落点",
		resolve: "结算效果",
		mission: "检查任务与目标",
		done: "考验结束",
		main: "执行行动",
		landing: "领取交通与群系奖励",
		energy: "领取能量",
		mass: "领取质量",
		entropy: "领取熵",
		vp: "领取胜利分",
		generator: "推进发电机",
		evolve: "选择恒星演化路线",
		aggregate: "选择行星",
		placePlanet: "为新行星选择星系",
		life: "选择生命牌和目标行星",
		lifeOrder: "选择生命牌收益顺序",
		lifeYield: "在本地增加生命",
		lifeFinish: "放置生命牌",
		draw: "选择生命牌",
		activate: "选择要激活的恒星",
		activateOne: "选择一颗恒星激活",
		upgrade: "选择要升级的 Focus",
		biome: "选择生物群系和行星",
		fulfill: "选择要完成的群系",
		setOrFulfill: "设置或完成生物群系",
		asteroid: "选择小行星和支付方式",
		anyLife: "分配任意生命",
		biomeBatch: "选择要领取奖励的群系",
		advance: "选择生命进化",
		bacteria: "分配细菌",
		plant: "分配植物",
		animal: "分配动物",
		retrieve: "选择创造标记",
		recovery: "回收奖励：激活恒星或获得 1 熵",
		biomeTrigger: "选择是否支付费用领取群系奖励",
		focusBiome: "触发本地群系",
		conditionReward: "选择计分类型",
		samePlanet: "选择同一个生命连续进化",
		checkpoint: "检查目标",
		ghostMove: "幽灵科学家移动",
		ghostCard: "执行进度牌",
		next: "回合结束",
		focus: "触发 Focus",
		animalReward: "计算生命牌奖励",
		missionReward: "领取任务奖励",
		starCommit: "演化恒星",
		focusStarBefore: "升级前激活恒星"
	},
	accept: "领取",
	skip: "放弃本项奖励",
	finish: "结束回合",
	inner: "内圈",
	outer: "外圈",
	steps: "移动 {{n}} 格",
	traffic: "交通奖励 {{n}}",
	occupied: "落点拥挤",
	newSystem: "新建恒星系",
	system: "星系",
	planet: "行星",
	star: "恒星",
	noStar: "无恒星",
	emptyPlanet: "空行星位",
	cost: "费用",
	local: "本地",
	global: "任意分配",
	need: "要求",
	consume: "移除",
	produce: "新增",
	effect: "效果",
	fulfilled: "已完成",
	unfulfilled: "待完成",
	abundant: "富饶",
	scarce: "稀缺",
	left: "左列",
	right: "右列",
	top: "上列",
	bottom: "下列",
	cards: "张生命牌",
	discard: "弃牌",
	lifeFirst: "先增加本地生命",
	effectFirst: "先执行牌底效果",
	anyLife: "任意生命",
	free: "免费",
	matching: "同类型",
	markerNames: [
		"恒星标记",
		"行星标记",
		"生命标记",
		"万能标记"
	],
	ready: "可用",
	tired: "横置",
	locked: "锁定",
	generator: "发电机",
	discount: "熵折扣",
	upToStars: "颗恒星",
	upgrade: "升级",
	activate: "激活",
	place: "放置",
	trigger: "触发",
	complete: "完成",
	claim: "领取任务奖励",
	completeChallenge: "完成挑战",
	exchange: "兑换",
	count: "数量",
	all: "全部",
	mainEvents: [
		"升级恒星至 III / IV 级",
		"在星系安装第一颗小行星",
		"完成生物群系"
	],
	mainFactors: [
		"同类型行星最多数量",
		"有群系及生命牌的行星",
		"不同种类恒星"
	],
	altFactors: [
		"生命成本槽小行星",
		"三类生命齐全的行星",
		"Focus 升级总级数"
	],
	smallGoal: "小目标",
	bigGoal: "大目标",
	triggerEnd: "结束条件",
	mission: "任务",
	challenge: "挑战",
	constraint: "约束",
	ghost: "幽灵科学家",
	progress: "进度牌",
	challengeCount: "已完成挑战",
	soloFail: "至少完成两项挑战且分数严格超过幽灵才算获胜。",
	options: {
		focus: "Focus 组合",
		random: "随机分配",
		alternative: "使用替代主目标",
		advanced: "进阶单人挑战",
		advancedHint: "每色增加一项约束，完成该色挑战后解除。",
		multiplier: "幽灵计分倍率",
		progress: "单人进度牌堆",
		standard: "标准：A / B 各移除两张",
		all: "使用全部 A / B 牌",
		bOnly: "仅 B 牌，移除三张",
		double: "加入双倍进度牌"
	},
	scoring: {
		vp: "过程得分",
		life: "生命目标",
		main: "主目标",
		resources: "剩余资源",
		challenges: "挑战奖励",
		total: "总分"
	},
	missions: [
		"拥有三种不同类型的行星；每个生物群系获得 2 质量。",
		"拥有三种不同类型的小行星；每张已出细菌牌和植物牌获得 2 熵。",
		"一个 Focus 升至二级；每颗恒星获得 1 植物。",
		"三个 Focus 均至少升级一次；每颗行星获得 1 植物。",
		"发电机至少推进三次；每张已出植物牌和动物牌获得 2 能量。",
		"拥有 IIIA 恒星；每颗行星获得 2 熵。",
		"拥有 IIIB 恒星；选一种环境图标，每个获得 1 细菌。",
		"拥有 IIIC 恒星；每颗有生命的行星获得 1 张生命牌。",
		"同一星系有三个热图标；每张已出细菌牌和动物牌获得 2 质量。",
		"同一星系有三个碳图标；每个 Focus 升级级数获得 2 能量。",
		"同一星系有三个水图标；发电机每次推进获得 1 张生命牌。",
		"同一星系有三个辐射图标；每颗小行星获得 1 细菌。"
	],
	challenges: [
		"打出至少四张同类型生命牌。",
		"将一颗恒星升至 IV 级。",
		"累计升级 Focus 至少四次。",
		"拥有四颗恒星。",
		"两颗行星各有两颗小行星。",
		"三颗行星各有至少五个生命。",
		"四颗行星各有至少一张生命牌。",
		"拥有至少六颗行星。",
		"拥有至少八个热图标。",
		"拥有至少八个碳图标。",
		"拥有至少七个水图标。",
		"拥有至少七个辐射图标。"
	],
	constraints: [
		"回收创造标记时不能激活恒星，仍可获得 1 熵。",
		"演化恒星额外支付 1 能量。",
		"升级控制台额外支付 1 质量。",
		"激活恒星额外支付 1 熵。",
		"捕获小行星额外弃一张手牌。",
		"完成群系额外要求本地一个任意生命；无条件完成不受影响。",
		"生命牌额外要求一个任意环境图标。",
		"发电机不再奖励胜利分。",
		"万能标记每次使用后重新锁定。",
		"万能标记不能聚合行星。",
		"万能标记不能创造生命。",
		"万能标记不能演化恒星。"
	],
	focusDescriptions: [
		[
			"升级前支付熵激活该恒星；二级时此次激活免费。",
			"聚合行星后设置富饶群系；二级可设置或无条件完成富饶群系。",
			"创造生命后，每张已出同类型牌得 1 分；二级改为全部已出生命牌，含新牌。"
		],
		[
			"演化恒星后捕获小行星；二级免费捕获。",
			"聚合行星后，在新行星新增 1 / 2 细菌。",
			"创造生命后，牌上环境要求图标总数乘以 1 / 2 得分。"
		],
		[
			"演化恒星后，新恒星等级乘以 1 / 2 得分。",
			"聚合行星后，发电机推进 1 / 2 格。",
			"创造生命后，触发本地富饶群系；二级可触发本地任意群系，仍须支付费用。"
		],
		[
			"演化恒星后，在该星系进化一个生命；二级将同一个生命连续进化两次。",
			"聚合行星后，每颗同类型行星得 1 分；二级改为全部行星。",
			"创造生命后，抽取与刚出牌同类型的 1 / 2 张生命牌。"
		]
	],
	animals: [
		"每颗同类型行星：1 熵、2 分。",
		"每个已完成群系：1 植物、3 分。",
		"每种行星：1 能量、2 分。",
		"每颗碳行星：1 细菌、2 分。",
		"每种恒星等级：2 分。",
		"每颗有动物的行星：1 熵、3 分。",
		"每张已出同类型生命牌：1 能量、2 分。",
		"每颗热行星：1 质量、2 分。",
		"每个生物群系：1 细菌、2 分。",
		"每个 Focus 升级级数：1 植物、2 分。",
		"每颗辐射行星：3 分。",
		"每颗同类型小行星：1 细菌、2 分。",
		"每颗水行星：2 分。",
		"发电机每次推进：1 质量、2 分。",
		"每颗有细菌的行星：1 熵、2 分。",
		"全部恒星等级总和得分。",
		"每张已出生命牌：1 熵、2 分。",
		"每颗小行星：1 质量、2 分。",
		"每颗行星：1 分。",
		"每颗有植物的行星：3 分。",
		"每种小行星：1 能量、3 分。",
		"获得 9 分。"
	]
}, Ze = {
	selectPlanet: "Choose a planet",
	confirm: "Confirm action",
	cancel: "Cancel selection",
	wait: "Waiting",
	resultsTitle: "Your universe",
	viewBoard: "Inspect final universe",
	viewResults: "View results",
	confirmAgain: "Play another game?",
	confirmBack: "Return to the lobby?",
	victory: "Victory",
	defeat: "Trial failed",
	tie: "Shared victory",
	name: "Entropy",
	desc: "Evolve stars, shape planets and seed life in the final examination of a universe creator.",
	rules: "Goal:\nbuild solar systems and score the most victory points. Play competitively with 2–4 players, or face the Ghost Scientist in the official solo mode.\nSetup: randomize the six outer action tiles. Each player receives a random starting star and planet with their starting resources and Life cards, three Focus cards and four Creation tokens. In multiplayer each player receives two secret Missions. Solo uses three Challenges instead.\nTurn: Movement → Action → Mission. In solo, resolve the Ghost step afterwards.\nMovement: move clockwise 1–3 sectors and land on an inner or outer space. Inner spaces repeat Evolve a Star, Create Life, Aggregate Planet. To land inside, place the matching Creation token or Wild token. Tokens on the board or lying down cannot be used. Retrieve your tokens passed during movement, including those before your destination. Lay each down and choose to activate a star by paying Entropy, or gain 1 Entropy. The Wild token is only unlocked on its first pass. Retrieved tokens become available at the end of your turn.\nTraffic: moving 1 space normally awards 2 units, moving 2 spaces awards 1 unit, and moving 3 spaces awards none. An occupied destination counts as one extra space; actually moving three onto an occupied space also costs 1 Entropy. At two players all adjacent inner and outer spaces are merged for occupancy; at three, alternate sectors are merged; at four they are separate. Star actions award Energy, planet and asteroid actions Mass, Create Life adds local Lifeforms, Primordial Soup allows Lifeform advancement, and the other outer actions award Entropy.\nActions: rewards may be forfeited. You may take only the Traffic Bonus and forgo the action, except Create Life. During the Action step, exchange 2 Entropy for 1 Energy or 1 Mass any number of times.\nEvolve a Star: pay 1 Energy for a tier I star in a system without a star or a new system. Alternatively evolve along the tree, paying 2/3/4 Energy for tiers II/III/IV. Evolution does not activate a star. Each system holds one star and two planets. Systems and tiles are limited.\nAggregate Planet: choose the top planet from either stack of a type, pay its Mass cost, resolve its effect, then place it in an empty planet space or a new system. Only tiles showing a Life Condition icon contribute one.\nCreate Life: select a Life card and planet. Only that planet, its asteroids and its system’s star count toward Life Conditions. Discard at most one other Life card to supply one condition printed on the discarded card. Yellow Lifeform requirements must be present; red ones must be removed. Choose whether to add local Lifeforms or resolve the card’s bottom effect first. Place the played card beside the planet last. A planet holds at most three cards and five Lifeforms of each type.\nActivate Stars: pay each star’s tier in Entropy and resolve any number of stars, each at most once per action. Generator discounts apply only when landing on the Activate Stars action, never to activations from token retrieval or other effects.\nSet Biome: take a Biome and bind it permanently to a planet without one. After landing on its indicated action, you may pay its cost to receive its reward. Scarce Biomes cost Entropy; some Abundant Biomes also have costs. Fulfill a Biome as a free action when its local Lifeform requirements are met. Its fulfilled side improves the reward. Unconditional fulfillment ignores the requirements.\nUpgrade Console: pay 3 Energy to upgrade a Focus by one tier, to a maximum of two. Retrieve its matching Creation token from the main board and lay it down, without activation or Entropy. Using a matching Creation token triggers its Focus. The Wild token never triggers Focus. All four sets can be inspected in the console.\nTake Life Cards: take two cards, one at a time, from the face-up offers. There is no hand limit. Refill an exhausted stack from the other stack of the same type; never create replacement components after both run out.\nCatch an Asteroid: each planet has two slots. One costs 2 Mass; the other removes one local Lifeform. Water and Radiation asteroids cost 1 additional Mass. Trigger the planet’s effect again after installation. Free catches waive these costs.\nPrimordial Soup: advance the Generator, gain 1 Mass and 1 Energy. Lifeform advancement may add a Bacteria, exchange Bacteria for Plant, or Plant for Animal. The last three Generator spaces award 3 VP each; further advancement at the end also awards 3 VP.\nMissions and Objectives: at turn end, optionally fulfill one eligible Mission for its reward, then discard both. Evolving to tier III or IV, installing the first asteroid in a system, and fulfilling a Biome advance the three Main Objectives respectively. Only one scientist can occupy each final space. Claim at most one small objective per Lifeform type; each big objective is a unique 20 VP award.\nEnd: completing any two of the three final Main Objective spaces and the three big Lifeform Objectives triggers the end. Finish the round and play one full additional round. Add in-game VP, Lifeform Objectives, Main Objectives and remaining resources. Track values are 0/1/3/5/7/10, The three Main Objectives use these multipliers, in order:\n· The greatest number of planets of one type.\n· The number of planets with both a Biome and a Life card.\n· The number of distinct star types.\nAlternative Objectives replace those multipliers, in the same order, with:\n· Asteroids in Lifeform-cost slots.\n· Planets with all three Lifeform types.\n· Total Focus upgrade levels.\nEvery four remaining Life cards, Energy, Mass and Entropy score 1 VP. Multiplayer ties share victory.\nSolo: do not use Missions. The Ghost starts on the next inner space clockwise. After you move one, two or three spaces, the Ghost moves three, two or one space respectively. If it lands on you, move it one more space. Passing the Progress deck draws a card, advances Ghost Objectives and removes the specified market components. On reshuffle retain only B cards. The Ghost claims each small Lifeform Objective on its third advancement and the big one on its fifth. Standard Challenges use one per color. Advanced Challenges add one constraint per color, removed when that Challenge is fulfilled. Challenge rewards are:\n· Green Challenges score 5 VP.\n· Yellow Challenges score 10 VP.\n· Red Challenges score 15 VP.\nComplete at least two Challenges and strictly beat the Ghost to win. The Ghost scores its Lifeform tiles plus its three Main Objective values times the selected multiplier. Options expose the official deck, multiplier and double-progress adjustments.",
	errTurn: "It is not your turn.",
	errChoice: "The position has changed. Please choose again.",
	board: "Main board",
	universe: "Solar systems",
	hand: "Hand",
	objectives: "Objectives",
	console: "Console",
	market: "Supply",
	details: "Details",
	close: "Close",
	choose: "Choose action",
	waiting: "Waiting for {{name}}",
	round: "Round {{n}}",
	lastRound: "Final round",
	resources: [
		"Energy",
		"Mass",
		"Entropy",
		"Victory points"
	],
	conditions: [
		"Heat",
		"Carbon",
		"Water",
		"Radiation"
	],
	lifeTypes: [
		"Bacteria",
		"Plants",
		"Animals"
	],
	space: {
		evolve: "Evolve a Star",
		aggregate: "Aggregate Planet",
		life: "Create Life",
		activate: "Activate Stars",
		biome: "Set Biome",
		draw: "Take Life Cards",
		upgrade: "Upgrade Console",
		asteroid: "Catch an Asteroid",
		soup: "Primordial Soup"
	},
	effects: {
		energy: "Energy",
		mass: "Mass",
		entropy: "Entropy",
		vp: "VP",
		generator: "Generator advances",
		bacteria: "Bacteria",
		plant: "Plants",
		animal: "Animals",
		anyLife: "Any Lifeform",
		advance: "Advance Lifeforms",
		retrieve: "Retrieve Creation tokens",
		fulfill: "Fulfill a Biome unconditionally",
		setOrFulfill: "Set or fulfill a Biome unconditionally",
		activateOne: "Activate one star",
		animalReward: "Conditional reward"
	},
	prompt: {
		move: "Move your Scientist and choose a destination",
		resolve: "Resolve effects",
		mission: "Check Missions and Objectives",
		done: "Examination complete",
		main: "Resolve action",
		landing: "Traffic and Biome rewards",
		energy: "Gain Energy",
		mass: "Gain Mass",
		entropy: "Gain Entropy",
		vp: "Gain victory points",
		generator: "Advance the Generator",
		evolve: "Choose a star evolution",
		aggregate: "Choose a planet",
		placePlanet: "Choose a system for the new planet",
		life: "Choose a Life card and planet",
		lifeOrder: "Choose reward order",
		lifeYield: "Add local Lifeforms",
		lifeFinish: "Place the Life card",
		draw: "Choose a Life card",
		activate: "Choose a star to activate",
		activateOne: "Activate one star",
		upgrade: "Choose a Focus to upgrade",
		biome: "Choose a Biome and planet",
		fulfill: "Choose a Biome to fulfill",
		setOrFulfill: "Set or fulfill a Biome",
		asteroid: "Choose an asteroid and payment",
		anyLife: "Distribute any Lifeforms",
		biomeBatch: "Choose a Biome reward",
		advance: "Choose a Lifeform advancement",
		bacteria: "Distribute Bacteria",
		plant: "Distribute Plants",
		animal: "Distribute Animals",
		retrieve: "Choose a Creation token",
		recovery: "Retrieval: activate a star or gain 1 Entropy",
		biomeTrigger: "Pay for the Biome reward?",
		focusBiome: "Trigger the local Biome",
		conditionReward: "Choose a scoring type",
		samePlanet: "Advance the same Lifeform",
		checkpoint: "Check Objectives",
		ghostMove: "The Ghost Scientist moves",
		ghostCard: "Resolve a Progress card",
		next: "End of turn",
		focus: "Trigger Focus",
		animalReward: "Calculate Life card rewards",
		missionReward: "Gain Mission reward",
		starCommit: "Evolve the star",
		focusStarBefore: "Activate before evolving"
	},
	accept: "Gain reward",
	skip: "Forgo this reward",
	finish: "End turn",
	inner: "Inner ring",
	outer: "Outer ring",
	steps: "Move {{n}} spaces",
	traffic: "Traffic Bonus {{n}}",
	occupied: "Occupied destination",
	newSystem: "New solar system",
	system: "System",
	planet: "Planet",
	star: "Star",
	noStar: "No star",
	emptyPlanet: "Empty planet space",
	cost: "Cost",
	local: "Local",
	global: "Distribute freely",
	need: "Requires",
	consume: "Remove",
	produce: "Add",
	effect: "Effect",
	fulfilled: "Fulfilled",
	unfulfilled: "Unfulfilled",
	abundant: "Abundant",
	scarce: "Scarce",
	left: "Left stack",
	right: "Right stack",
	top: "Top stack",
	bottom: "Bottom stack",
	cards: "Life cards",
	discard: "Discard",
	lifeFirst: "Add local Lifeforms first",
	effectFirst: "Resolve bottom effect first",
	anyLife: "Any Lifeform",
	free: "Free",
	matching: "Matching type",
	markerNames: [
		"Star token",
		"Planet token",
		"Life token",
		"Wild token"
	],
	ready: "Available",
	tired: "Lying down",
	locked: "Locked",
	generator: "Generator",
	discount: "Entropy discount",
	upToStars: "stars",
	upgrade: "Upgrade",
	activate: "Activate",
	place: "Place",
	trigger: "Trigger",
	complete: "Fulfill",
	claim: "Claim Mission reward",
	completeChallenge: "Complete Challenge",
	exchange: "Exchange",
	count: "Count",
	all: "All",
	mainEvents: [
		"Evolve to tier III / IV",
		"First asteroid in a system",
		"Fulfill a Biome"
	],
	mainFactors: [
		"Most planets of one type",
		"Planets with Biome and Life card",
		"Distinct stars"
	],
	altFactors: [
		"Asteroids in Lifeform-cost slots",
		"Planets with all three Lifeforms",
		"Total Focus upgrades"
	],
	smallGoal: "Small Objective",
	bigGoal: "Big Objective",
	triggerEnd: "End condition",
	mission: "Mission",
	challenge: "Challenge",
	constraint: "Constraint",
	ghost: "Ghost Scientist",
	progress: "Progress card",
	challengeCount: "Challenges completed",
	soloFail: "Complete at least two Challenges and strictly beat the Ghost to win.",
	options: {
		focus: "Focus set",
		random: "Random",
		alternative: "Alternative Main Objectives",
		advanced: "Advanced solo Challenges",
		advancedHint: "Add a constraint per color; remove it when its Challenge is complete.",
		multiplier: "Ghost scoring multiplier",
		progress: "Solo Progress deck",
		standard: "Standard: remove two A and two B",
		all: "Use all A and B cards",
		bOnly: "Only B cards; remove three",
		double: "Include double-progress card"
	},
	scoring: {
		vp: "In-game VP",
		life: "Lifeform Objectives",
		main: "Main Objectives",
		resources: "Remaining resources",
		challenges: "Challenge rewards",
		total: "Total"
	},
	missions: [
		"Have three planet types; gain 2 Mass per Biome.",
		"Have three asteroid types; gain 2 Entropy per played Bacteria and Plant card.",
		"Have a tier-two Focus; gain 1 Plant per star.",
		"Upgrade all three Focus cards; gain 1 Plant per planet.",
		"Advance the Generator three times; gain 2 Energy per played Plant and Animal card.",
		"Have a IIIA star; gain 2 Entropy per planet.",
		"Have a IIIB star; choose a Life Condition and gain 1 Bacteria per icon.",
		"Have a IIIC star; take 1 Life card per planet with Lifeforms.",
		"Have three Heat icons in one system; gain 2 Mass per played Bacteria and Animal card.",
		"Have three Carbon icons in one system; gain 2 Energy per Focus upgrade.",
		"Have three Water icons in one system; take 1 Life card per Generator advancement.",
		"Have three Radiation icons in one system; gain 1 Bacteria per asteroid."
	],
	challenges: [
		"Play four Life cards of one type.",
		"Evolve a star to tier IV.",
		"Upgrade Focus four times.",
		"Have four stars.",
		"Have two planets with two asteroids each.",
		"Have three planets with at least five Lifeforms each.",
		"Have four planets with a Life card each.",
		"Have at least six planets.",
		"Have at least eight Heat icons.",
		"Have at least eight Carbon icons.",
		"Have at least seven Water icons.",
		"Have at least seven Radiation icons."
	],
	constraints: [
		"Retrieving Creation tokens cannot activate stars; you may still gain 1 Entropy.",
		"Evolving a star costs 1 extra Energy.",
		"Upgrading the Console costs 1 extra Mass.",
		"Activating a star costs 1 extra Entropy.",
		"Catching an asteroid requires discarding a Life card.",
		"Fulfilling a Biome requires one extra local Lifeform; unconditional fulfillment ignores this.",
		"Life cards require one extra Life Condition icon.",
		"The Generator awards no VP.",
		"Using the Wild token locks it again.",
		"The Wild token cannot Aggregate Planets.",
		"The Wild token cannot Create Life.",
		"The Wild token cannot Evolve Stars."
	],
	focusDescriptions: [
		[
			"Activate the star before evolving, paying Entropy. Tier two: this activation is free.",
			"After aggregation, set an Abundant Biome. Tier two: set or fulfill an Abundant Biome.",
			"After creating life, score 1 VP per played card of that type. Tier two: all played Life cards, including the new card."
		],
		[
			"After evolving, catch an asteroid. Tier two: catch it free.",
			"After aggregation, add 1 / 2 Bacteria to the new planet.",
			"After creating life, score its total Life Condition requirements × 1 / 2 VP."
		],
		[
			"After evolving, score the new star’s tier × 1 / 2 VP.",
			"After aggregation, advance the Generator 1 / 2 times.",
			"After creating life, trigger its local Abundant Biome. Tier two: any local Biome. Pay the usual cost."
		],
		[
			"After evolving, advance one Lifeform in that system. Tier two: advance that same Lifeform twice.",
			"After aggregation, score 1 VP per planet of the new type. Tier two: all planets.",
			"After creating life, take 1 / 2 cards of the played type."
		]
	],
	animals: [
		"Per planet of one type: 1 Entropy, 2 VP.",
		"Per fulfilled Biome: 1 Plant, 3 VP.",
		"Per distinct planet type: 1 Energy, 2 VP.",
		"Per Carbon planet: 1 Bacteria, 2 VP.",
		"Per distinct star tier: 2 VP.",
		"Per planet with Animals: 1 Entropy, 3 VP.",
		"Per played Life card of one type: 1 Energy, 2 VP.",
		"Per Heat planet: 1 Mass, 2 VP.",
		"Per Biome: 1 Bacteria, 2 VP.",
		"Per Focus upgrade: 1 Plant, 2 VP.",
		"Per Radiation planet: 3 VP.",
		"Per asteroid of one type: 1 Bacteria, 2 VP.",
		"Per Water planet: 2 VP.",
		"Per Generator advancement: 1 Mass, 2 VP.",
		"Per planet with Bacteria: 1 Entropy, 2 VP.",
		"Score the sum of all star tiers.",
		"Per played Life card: 1 Entropy, 2 VP.",
		"Per asteroid: 1 Mass, 2 VP.",
		"Per planet: 1 VP.",
		"Per planet with Plants: 3 VP.",
		"Per distinct asteroid type: 1 Energy, 3 VP.",
		"Gain 9 VP."
	]
}, Qe = [
	"🔥",
	"⬡",
	"💧",
	"☢"
], J = [
	"🦠",
	"🌱",
	"🐾"
];
function Y(e, t) {
	if (e.kind === "animalReward") return e.tag === 63 ? `${e.n} ${t.resources[3]} × ${t.planet}` : e.tag >= 45 && e.tag <= 66 ? t.animals[e.tag - 45] : `${e.n} ${t.resources[3]} × ${e.tag === 67 ? t.star : e.tag === 63 ? t.planet : t.cards}`;
	let n = t.space[e.kind] ?? t.effects[e.kind], r = e.tag === 1 && [
		"asteroid",
		"upgrade",
		"activateOne"
	].includes(e.kind) ? t.free : e.kind === "fulfill" && e.tag === 1 ? t.abundant : e.kind === "draw" && e.tag !== void 0 ? t.lifeTypes[e.tag] : e.kind === "advance" && e.tag !== void 0 ? `${J[e.tag]}→${J[e.tag + 1]}` : "";
	return `${e.n} ${n}${r ? ` · ${r}` : ""}`;
}
function $e(e, t) {
	return e.kind === "draw" ? `${t.discard} 1 ${e.tag === void 0 ? t.cards : t.lifeTypes[e.tag]}` : e.n === 0 ? t.free : Y(e, t);
}
function et(e, t, n) {
	let r = e.args, i = t.players.find((e) => e.rid === t.turn), a = t.pending, o = (e) => `${n.planet} ${e}`, s = (e) => e < 0 ? n.newSystem : `${n.system} ${e}`;
	switch (e.kind) {
		case "move": {
			let e = (i.position + r[0]) % 6;
			return `${n.steps.replace("{{n}}", String(r[0]))} → ${r[1] ? n.outer : n.inner} · ${n.space[r[1] ? t.outer[e] : x[e]]}${r[2] < 0 ? "" : ` · ${n.markerNames[r[2]]}`} · ${n.traffic.replace("{{n}}", String(Math.max(0, 3 - r[0] - r[3])))}${r[3] ? ` · ${n.occupied}${r[0] === 3 ? " · 1 △" : ""}` : ""}`;
		}
		case "gain": return t.prompt === "lifeYield" ? `${n.produce} ${D[a.card - 1].yield + a.bonus} ${n.lifeTypes[D[a.card - 1].type]} · ${o(a.planet)}` : t.prompt === "recovery" ? `+1 ${n.resources[2]}` : `${n.accept} · ${a.n} ${n.effects[t.prompt] ?? ""}`;
		case "skip": return n.skip;
		case "end": return n.finish;
		case "evolve": return `${s(r[0])} → ${T[r[1]].id} · ${r[2]} ⚡`;
		case "aggregate": return `${Qe[r[0]]} P${r[2] + 1} · ${k[r[2]].cost} ◼ · ${k[r[2]].effects.map((e) => Y(e, n)).join(" + ")}`;
		case "placePlanet": return `${n.place} P${a.data + 1} → ${s(r[0])}`;
		case "play": return `L${r[0]} ${J[D[r[0] - 1].type]} → ${o(r[1])}${r[2] ? ` · ${n.discard} L${r[2]} (${Qe[r[3]]})` : ""}`;
		case "order": return r[0] === 0 ? n.lifeFirst : n.effectFirst;
		case "draw": return `${n.space.draw} L${r[2]} ${J[r[0]]} · ${r[1] ? n.right : n.left}`;
		case "biome": return `${n.space.biome} B${r[3] + 1} (${j[r[3]].scarce ? n.scarce : n.abundant}) → ${o(r[0])}`;
		case "fulfill": return `${n.complete} · ${o(r[0])}`;
		case "activate": return `${n.activate} ${s(r[0])} · ${r[1]} △`;
		case "upgrade": return `${n.upgrade} ${n.markerNames[r[0]]} · ${i.levels[r[0]]} → ${i.levels[r[0]] + 1}`;
		case "asteroid": return `${Qe[r[1]]} ☄ → ${o(r[0])} · ${r[5]} ◼${r[3] >= 0 ? ` + 1 ${J[r[3]]}` : ""}${r[4] ? ` · ${n.discard} L${r[4]}` : ""}`;
		case "advance": return `${o(r[0])} · ${r[1] > 0 ? `${J[r[1] - 1]} → ` : "+ "}${J[r[1]]}${r[2] === 2 ? ` → ${J[r[1] + 1]}` : ""}`;
		case "addLife": return `+1 ${J[r[1]]} → ${o(r[0])}`;
		case "retrieve": return `${n.effects.retrieve} · ${n.markerNames[r[0]]}`;
		case "biomeTrigger":
			if (["biomeBatch", "focusBiome"].includes(t.prompt)) {
				let e = i.planets.find((e) => e.uid === r[0]), t = j[e.biome.data];
				return `${n.trigger} · ${o(e.uid)} · B${t.id + 1} · ${$e(t.cost, n)} → ${[...t.effects, ...e.biome.fulfilled ? t.improved : []].map((e) => Y(e, n)).join(" + ")}`;
			}
			return `${n.trigger} · ${a.planet === null ? "" : o(a.planet)}${r[0] > 0 && t.prompt !== "focusBiome" ? ` · ${n.discard} L${r[0]}` : ""}`;
		case "exchange": return `2 △ → 1 ${r[0] ? "◼" : "⚡"}`;
		case "mission": return `${n.claim} M${r[0]} · ${n.missions[r[0] - 1]}`;
		case "challenge": return `${n.completeChallenge} · ${n.challenges[t.ghost.challenges[r[0]].require - 1]}`;
		case "pickCondition": return a.tag === 51 ? n.lifeTypes[r[0]] ?? "" : `${Qe[r[0]]} ${n.conditions[r[0]]}`;
		case "finishLife": return n.complete;
	}
}
//#endregion
//#region src/games/entropy/art.tsx
var tt = /* #__PURE__ */ Object.assign({
	"./assets/icon-activate.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cpath%20d='M37.50%207.81C36.56%207.58%2038.67%209.30%2037.50%2010.94C36.33%2012.58%2031.56%2017.34%2029.69%2018.75C27.81%2020.16%2026.64%2020.31%2025.00%2020.31C23.36%2020.31%2019.69%2017.34%2018.75%2018.75C17.81%2020.16%2019.92%2026.88%2018.75%2029.69C17.58%2032.50%2012.58%2036.33%2010.94%2037.50C9.30%2038.67%207.58%2036.33%207.81%2037.50C8.05%2038.67%2011.80%2042.73%2012.50%2045.31C13.20%2047.89%2013.20%2052.34%2012.50%2054.69C11.80%2057.03%207.11%2058.83%207.81%2060.94C8.52%2063.05%2015.55%2065.70%2017.19%2068.75C18.83%2071.80%2018.05%2079.61%2018.75%2081.25C19.45%2082.89%2020.23%2079.69%2021.88%2079.69C23.52%2079.69%2027.34%2080.08%2029.69%2081.25C32.03%2082.42%2036.33%2085.86%2037.50%2087.50C38.67%2089.14%2036.56%2092.19%2037.50%2092.19C38.44%2092.19%2041.17%2088.20%2043.75%2087.50C46.33%2086.80%2052.11%2086.80%2054.69%2087.50C57.27%2088.20%2060.00%2091.95%2060.94%2092.19C61.88%2092.42%2060.00%2090.47%2060.94%2089.06C61.88%2087.66%2065.31%2084.22%2067.19%2082.81C69.06%2081.41%2071.33%2079.92%2073.44%2079.69C75.55%2079.45%2080.31%2081.25%2081.25%2081.25C82.19%2081.25%2079.69%2081.56%2079.69%2079.69C79.69%2077.81%2080.08%2071.33%2081.25%2068.75C82.42%2066.17%2085.86%2063.67%2087.50%2062.50C89.14%2061.33%2092.42%2062.58%2092.19%2060.94C91.95%2059.30%2086.64%2054.14%2085.94%2051.56C85.23%2048.98%2086.56%2045.86%2087.50%2043.75C88.44%2041.64%2092.19%2038.44%2092.19%2037.50C92.19%2036.56%2088.91%2038.20%2087.50%2037.50C86.09%2036.80%2083.98%2034.45%2082.81%2032.81C81.64%2031.17%2079.92%2028.67%2079.69%2026.56C79.45%2024.45%2082.19%2019.69%2081.25%2018.75C80.31%2017.81%2075.55%2020.55%2073.44%2020.31C71.33%2020.08%2069.06%2018.59%2067.19%2017.19C65.31%2015.78%2061.88%2012.34%2060.94%2010.94C60.00%209.53%2061.88%207.58%2060.94%207.81C60.00%208.05%2057.27%2011.80%2054.69%2012.50C52.11%2013.20%2046.33%2013.20%2043.75%2012.50C41.17%2011.80%2038.44%208.05%2037.50%207.81Z'%20fill='url(%23symHeat)'%20stroke='%23fff'%20stroke-width='2.8'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M47%2024C26%2030%2030%2050%2048%2048S73%2061%2057%2073M29%2062Q42%2074%2046%2061T65%2036'%20transform='rotate(0%2050%2050)'%20fill='none'%20stroke='%23e8ad20'%20stroke-width='1.1'%20opacity='.6'/%3e%3cpath%20d='M47%2024C26%2030%2030%2050%2048%2048S73%2061%2057%2073M29%2062Q42%2074%2046%2061T65%2036'%20transform='rotate(60%2050%2050)'%20fill='none'%20stroke='%23e8ad20'%20stroke-width='1.1'%20opacity='.6'/%3e%3cpath%20d='M47%2024C26%2030%2030%2050%2048%2048S73%2061%2057%2073M29%2062Q42%2074%2046%2061T65%2036'%20transform='rotate(120%2050%2050)'%20fill='none'%20stroke='%23e8ad20'%20stroke-width='1.1'%20opacity='.6'/%3e%3cpath%20d='M47%2024C26%2030%2030%2050%2048%2048S73%2061%2057%2073M29%2062Q42%2074%2046%2061T65%2036'%20transform='rotate(180%2050%2050)'%20fill='none'%20stroke='%23e8ad20'%20stroke-width='1.1'%20opacity='.6'/%3e%3cpath%20d='M47%2024C26%2030%2030%2050%2048%2048S73%2061%2057%2073M29%2062Q42%2074%2046%2061T65%2036'%20transform='rotate(240%2050%2050)'%20fill='none'%20stroke='%23e8ad20'%20stroke-width='1.1'%20opacity='.6'/%3e%3cpath%20d='M47%2024C26%2030%2030%2050%2048%2048S73%2061%2057%2073M29%2062Q42%2074%2046%2061T65%2036'%20transform='rotate(300%2050%2050)'%20fill='none'%20stroke='%23e8ad20'%20stroke-width='1.1'%20opacity='.6'/%3e%3cg%20transform='translate(18%2016)%20scale(0.63)'%3e%3cpath%20d='M7.25%2013.77L18.84%2039.86L23.19%2035.51L26.09%2035.51L37.68%2047.10L40.58%2063.04L33.33%2064.49L43.48%2080.43L50.72%2087.68L66.67%2064.49L59.42%2063.04L62.32%2047.10L75.36%2034.06L79.71%2039.86L92.75%2013.77L63.77%2010.87L66.67%2018.12L50.72%2023.91L34.78%2019.57L33.33%2016.67L36.23%2010.87L7.25%2013.77Z'%20fill='%23f4433e'%20stroke='%23fff'%20stroke-width='3.1'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-advance.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cpath%20d='M50%207L88%2029V72L50%2094L12%2072V29Z'%20fill='%2391bf45'%20stroke='%23fff'%20stroke-width='3'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M50%208V51L13%2072V29Z'%20fill='%2388bcca'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M13%2072L50%2051L87%2072L50%2094Z'%20fill='%23c4ad6b'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M50%208V51L13%2072M50%2051L87%2072'%20fill='none'%20stroke='%23fff'%20stroke-width='2'%20stroke-linejoin='round'%20/%3e%3cg%20transform='translate(14%2025)%20scale(0.37)'%3e%3cpath%20d='M15%2024Q18%2018%2025%2019Q30%2018%2033%2029L34%2037Q38%2039%2042%2039Q47%2042%2052%2038L58%2037Q63%2031%2068%2035L72%2040Q79%2042%2082%2049Q91%2052%2089%2058L87%2062L87%2069Q84%2077%2078%2080Q73%2084%2069%2077L65%2070L65%2063Q61%2061%2057%2062L52%2061L44%2065L40%2064Q35%2070%2030%2065L27%2061Q23%2061%2019%2055L14%2050Q7%2046%2010%2042L12%2039L12%2029Z'%20fill='%23fff'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3cg%20transform='translate(48%2025)%20scale(0.37)'%3e%3cpath%20d='M50%2017Q61%2025%2067%2042Q74%2037%2079%2038Q82%2044%2078%2056L89%2058Q88%2071%2076%2079Q71%2084%2062%2082L49%2081L36%2082Q25%2084%2017%2075Q10%2068%209%2058L21%2056Q17%2047%2019%2038Q25%2036%2033%2042Q38%2027%2050%2017Z'%20fill='%23fff'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3cg%20transform='translate(30%2057)%20scale(0.37)'%3e%3cpath%20d='M9%2047Q12%2032%2023%2026Q30%2021%2037%2021L35%2027L39%2030Q60%2023%2073%2027Q86%2029%2089%2044Q90%2052%2086%2060Q85%2070%2088%2079L73%2079Q68%2067%2058%2067Q50%2066%2046%2079L32%2080Q29%2075%2031%2064L33%2053L29%2048L26%2048Q20%2055%2014%2052L9%2050Z'%20fill='%23fff'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3cpath%20d='M57%2028L77%2016L96%2027V47L77%2037L57%2048Z'%20fill='%23fff'%20stroke='%23202020'%20stroke-width='2.4'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-aggregate.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cg%20transform='translate(0%20-2)%20scale(0.9)'%3e%3ccircle%20cx='50'%20cy='50'%20r='45'%20fill='url(%23symGlobe)'%20stroke='%23fff'%20stroke-width='2.8'/%3e%3cpath%20d='M79.69%2056.25C79.45%2057.19%2084.30%2060.23%2085.94%2060.94C87.58%2061.64%2089.92%2061.64%2090.62%2060.94C91.33%2060.23%2091.09%2057.19%2090.62%2056.25C90.16%2055.31%2089.14%2054.69%2087.50%2054.69C85.86%2054.69%2079.92%2055.31%2079.69%2056.25ZM7.81%2045.31C6.88%2046.95%207.73%2058.59%209.38%2060.94C11.02%2063.28%2017.11%2061.17%2018.75%2060.94C20.39%2060.70%2021.02%2060.55%2020.31%2059.38C19.61%2058.20%2014.77%2054.53%2014.06%2053.12C13.36%2051.72%2016.56%2051.17%2015.62%2050.00C14.69%2048.83%208.75%2043.67%207.81%2045.31ZM57.81%2035.94C56.88%2036.17%2057.11%2038.36%2057.81%2039.06C58.52%2039.77%2061.09%2039.45%2062.50%2040.62C63.91%2041.80%2065.78%2045.70%2067.19%2046.88C68.59%2048.05%2070.47%2048.44%2071.88%2048.44C73.28%2048.44%2076.56%2047.58%2076.56%2046.88C76.56%2046.17%2072.58%2044.69%2071.88%2043.75C71.17%2042.81%2072.58%2041.09%2071.88%2040.62C71.17%2040.16%2068.36%2041.09%2067.19%2040.62C66.02%2040.16%2065.47%2038.20%2064.06%2037.50C62.66%2036.80%2058.75%2035.70%2057.81%2035.94ZM79.69%2020.31C79.22%2018.20%2076.25%2015.70%2073.44%2014.06C70.62%2012.42%2063.05%209.84%2060.94%209.38C58.83%208.91%2059.84%2011.17%2059.38%2010.94C58.91%2010.70%2060.62%208.28%2057.81%207.81C55.00%207.34%2044.84%206.88%2040.62%207.81C36.41%208.75%2031.56%2013.36%2029.69%2014.06C27.81%2014.77%2030.00%2010.39%2028.12%2012.50C26.25%2014.61%2018.12%2024.84%2017.19%2028.12C16.25%2031.41%2020.47%2033.67%2021.88%2034.38C23.28%2035.08%2024.69%2032.81%2026.56%2032.81C28.44%2032.81%2033.20%2033.67%2034.38%2034.38C35.55%2035.08%2035.31%2036.33%2034.38%2037.50C33.44%2038.67%2029.30%2040.55%2028.12%2042.19C26.95%2043.83%2025.62%2047.27%2026.56%2048.44C27.50%2049.61%2031.80%2050.23%2034.38%2050.00C36.95%2049.77%2041.64%2048.05%2043.75%2046.88C45.86%2045.70%2048.44%2044.53%2048.44%2042.19C48.44%2039.84%2043.98%2033.59%2043.75%2031.25C43.52%2028.91%2044.30%2027.27%2046.88%2026.56C49.45%2025.86%2057.89%2025.62%2060.94%2026.56C63.98%2027.50%2066.02%2032.34%2067.19%2032.81C68.36%2033.28%2068.28%2029.92%2068.75%2029.69C69.22%2029.45%2069.61%2031.48%2070.31%2031.25C71.02%2031.02%2072.50%2028.59%2073.44%2028.12C74.38%2027.66%2075.62%2029.30%2076.56%2028.12C77.50%2026.95%2080.16%2022.42%2079.69%2020.31Z'%20fill='%23d2b057'%20stroke='%23718c5e'%20stroke-width='0.7'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3cpath%20d='M50%2046C67%2049%2077%2059%2083%2073L90%2072L82%2091L64%2076L71%2074C66%2062%2059%2055%2050%2049Z'%20fill='%23fff'%20stroke='%23202020'%20stroke-width='2.3'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-animal.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cpath%20d='M12.68%2032.39C10.56%2035.99%207.04%2044.93%207.04%2047.89C7.04%2050.85%2010.77%2051.48%2012.68%2052.11C14.58%2052.75%2017.82%2052.75%2019.72%2052.11C21.62%2051.48%2024.08%2048.52%2025.35%2047.89C26.62%2047.25%2027.11%2047.04%2028.17%2047.89C29.23%2048.73%2032.18%2051.20%2032.39%2053.52C32.61%2055.85%2030.00%2060.21%2029.58%2063.38C29.15%2066.55%2029.15%2071.90%2029.58%2074.65C30.00%2077.39%2031.76%2080.85%2032.39%2081.69C33.03%2082.54%2031.69%2080.49%2033.80%2080.28C35.92%2080.07%2044.58%2080.92%2046.48%2080.28C48.38%2079.65%2045.42%2077.75%2046.48%2076.06C47.54%2074.37%2051.83%2070.28%2053.52%2069.01C55.21%2067.75%2055.85%2067.39%2057.75%2067.61C59.65%2067.82%2063.87%2068.94%2066.20%2070.42C68.52%2071.90%2072.18%2075.99%2073.24%2077.46C74.30%2078.94%2070.92%2079.86%2073.24%2080.28C75.56%2080.70%2086.62%2083.45%2088.73%2080.28C90.85%2077.11%2087.11%2064.44%2087.32%2059.15C87.54%2053.87%2090.35%2048.87%2090.14%2045.07C89.93%2041.27%2087.18%2036.13%2085.92%2033.80C84.65%2031.48%2084.23%2030.85%2081.69%2029.58C79.15%2028.31%2072.82%2025.99%2069.01%2025.35C65.21%2024.72%2060.77%2024.72%2056.34%2025.35C51.90%2025.99%2042.61%2029.58%2039.44%2029.58C36.27%2029.58%2035.63%2026.83%2035.21%2025.35C34.79%2023.87%2037.25%2020.56%2036.62%2019.72C35.99%2018.87%2033.31%2019.08%2030.99%2019.72C28.66%2020.35%2023.87%2022.04%2021.13%2023.94C18.38%2025.85%2014.79%2028.80%2012.68%2032.39Z'%20fill='url(%23symAnimal)'%20stroke='%23fff'%20stroke-width='4'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-anyLife.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cpath%20d='M50%207L88%2029V72L50%2094L12%2072V29Z'%20fill='%2391bf45'%20stroke='%23fff'%20stroke-width='3'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M50%208V51L13%2072V29Z'%20fill='%2388bcca'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M13%2072L50%2051L87%2072L50%2094Z'%20fill='%23c4ad6b'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M50%208V51L13%2072M50%2051L87%2072'%20fill='none'%20stroke='%23fff'%20stroke-width='2'%20stroke-linejoin='round'%20/%3e%3cg%20transform='translate(14%2025)%20scale(0.37)'%3e%3cpath%20d='M15%2024Q18%2018%2025%2019Q30%2018%2033%2029L34%2037Q38%2039%2042%2039Q47%2042%2052%2038L58%2037Q63%2031%2068%2035L72%2040Q79%2042%2082%2049Q91%2052%2089%2058L87%2062L87%2069Q84%2077%2078%2080Q73%2084%2069%2077L65%2070L65%2063Q61%2061%2057%2062L52%2061L44%2065L40%2064Q35%2070%2030%2065L27%2061Q23%2061%2019%2055L14%2050Q7%2046%2010%2042L12%2039L12%2029Z'%20fill='%23fff'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3cg%20transform='translate(48%2025)%20scale(0.37)'%3e%3cpath%20d='M50%2017Q61%2025%2067%2042Q74%2037%2079%2038Q82%2044%2078%2056L89%2058Q88%2071%2076%2079Q71%2084%2062%2082L49%2081L36%2082Q25%2084%2017%2075Q10%2068%209%2058L21%2056Q17%2047%2019%2038Q25%2036%2033%2042Q38%2027%2050%2017Z'%20fill='%23fff'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3cg%20transform='translate(30%2057)%20scale(0.37)'%3e%3cpath%20d='M9%2047Q12%2032%2023%2026Q30%2021%2037%2021L35%2027L39%2030Q60%2023%2073%2027Q86%2029%2089%2044Q90%2052%2086%2060Q85%2070%2088%2079L73%2079Q68%2067%2058%2067Q50%2066%2046%2079L32%2080Q29%2075%2031%2064L33%2053L29%2048L26%2048Q20%2055%2014%2052L9%2050Z'%20fill='%23fff'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-asteroid.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cpath%20d='M43.75%206.25C41.64%206.25%2041.17%208.67%2039.06%209.38C36.95%2010.08%2032.03%209.30%2029.69%2010.94C27.34%2012.58%2025.31%2018.20%2023.44%2020.31C21.56%2022.42%2018.36%2023.12%2017.19%2025.00C16.02%2026.88%2016.80%2030.23%2015.62%2032.81C14.45%2035.39%2010.31%2039.61%209.38%2042.19C8.44%2044.77%209.84%2047.89%209.38%2050.00C8.91%2052.11%205.31%2053.44%206.25%2056.25C7.19%2059.06%2014.22%2065.70%2015.62%2068.75C17.03%2071.80%2015.16%2074.92%2015.62%2076.56C16.09%2078.20%2016.17%2078.05%2018.75%2079.69C21.33%2081.33%2028.59%2086.09%2032.81%2087.50C37.03%2088.91%2044.30%2088.36%2046.88%2089.06C49.45%2089.77%2048.36%2091.48%2050.00%2092.19C51.64%2092.89%2055.47%2093.98%2057.81%2093.75C60.16%2093.52%2063.28%2092.03%2065.62%2090.62C67.97%2089.22%2071.80%2086.72%2073.44%2084.38C75.08%2082.03%2074.45%2077.58%2076.56%2075.00C78.67%2072.42%2084.92%2070.00%2087.50%2067.19C90.08%2064.38%2093.28%2059.06%2093.75%2056.25C94.22%2053.44%2091.09%2050.55%2090.62%2048.44C90.16%2046.33%2091.33%2044.06%2090.62%2042.19C89.92%2040.31%2086.88%2038.52%2085.94%2035.94C85.00%2033.36%2086.72%2029.22%2084.38%2025.00C82.03%2020.78%2075.00%2010.16%2070.31%207.81C65.62%205.47%2057.11%209.61%2053.12%209.38C49.14%209.14%2045.86%206.25%2043.75%206.25Z'%20fill='%23767c7c'%20stroke='%23fff'%20stroke-width='2.8'%20stroke-linejoin='round'%20/%3e%3ccircle%20cx='40'%20cy='22'%20r='5'%20fill='%23373d3d'%20stroke='%23a3aaaa'%20stroke-width='1'/%3e%3ccircle%20cx='62'%20cy='23'%20r='3'%20fill='%23373d3d'%20stroke='%23a3aaaa'%20stroke-width='1'/%3e%3ccircle%20cx='32'%20cy='37'%20r='4'%20fill='%23373d3d'%20stroke='%23a3aaaa'%20stroke-width='1'/%3e%3ccircle%20cx='48'%20cy='44'%20r='8'%20fill='%23373d3d'%20stroke='%23a3aaaa'%20stroke-width='1'/%3e%3ccircle%20cx='71'%20cy='45'%20r='4'%20fill='%23373d3d'%20stroke='%23a3aaaa'%20stroke-width='1'/%3e%3ccircle%20cx='27'%20cy='62'%20r='5'%20fill='%23373d3d'%20stroke='%23a3aaaa'%20stroke-width='1'/%3e%3ccircle%20cx='44'%20cy='69'%20r='4'%20fill='%23373d3d'%20stroke='%23a3aaaa'%20stroke-width='1'/%3e%3ccircle%20cx='65'%20cy='68'%20r='7'%20fill='%23373d3d'%20stroke='%23a3aaaa'%20stroke-width='1'/%3e%3ccircle%20cx='56'%20cy='83'%20r='3'%20fill='%23373d3d'%20stroke='%23a3aaaa'%20stroke-width='1'/%3e%3cpath%20d='M50%2046C67%2049%2077%2059%2083%2073L90%2072L82%2091L64%2076L71%2074C66%2062%2059%2055%2050%2049Z'%20fill='%23fff'%20stroke='%23202020'%20stroke-width='2.3'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-asteroidBody.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cpath%20d='M43.75%206.25C41.64%206.25%2041.17%208.67%2039.06%209.38C36.95%2010.08%2032.03%209.30%2029.69%2010.94C27.34%2012.58%2025.31%2018.20%2023.44%2020.31C21.56%2022.42%2018.36%2023.12%2017.19%2025.00C16.02%2026.88%2016.80%2030.23%2015.62%2032.81C14.45%2035.39%2010.31%2039.61%209.38%2042.19C8.44%2044.77%209.84%2047.89%209.38%2050.00C8.91%2052.11%205.31%2053.44%206.25%2056.25C7.19%2059.06%2014.22%2065.70%2015.62%2068.75C17.03%2071.80%2015.16%2074.92%2015.62%2076.56C16.09%2078.20%2016.17%2078.05%2018.75%2079.69C21.33%2081.33%2028.59%2086.09%2032.81%2087.50C37.03%2088.91%2044.30%2088.36%2046.88%2089.06C49.45%2089.77%2048.36%2091.48%2050.00%2092.19C51.64%2092.89%2055.47%2093.98%2057.81%2093.75C60.16%2093.52%2063.28%2092.03%2065.62%2090.62C67.97%2089.22%2071.80%2086.72%2073.44%2084.38C75.08%2082.03%2074.45%2077.58%2076.56%2075.00C78.67%2072.42%2084.92%2070.00%2087.50%2067.19C90.08%2064.38%2093.28%2059.06%2093.75%2056.25C94.22%2053.44%2091.09%2050.55%2090.62%2048.44C90.16%2046.33%2091.33%2044.06%2090.62%2042.19C89.92%2040.31%2086.88%2038.52%2085.94%2035.94C85.00%2033.36%2086.72%2029.22%2084.38%2025.00C82.03%2020.78%2075.00%2010.16%2070.31%207.81C65.62%205.47%2057.11%209.61%2053.12%209.38C49.14%209.14%2045.86%206.25%2043.75%206.25Z'%20fill='%23767c7c'%20stroke='%23fff'%20stroke-width='2.8'%20stroke-linejoin='round'%20/%3e%3ccircle%20cx='40'%20cy='22'%20r='5'%20fill='%23373d3d'%20stroke='%23a3aaaa'%20stroke-width='1'/%3e%3ccircle%20cx='62'%20cy='23'%20r='3'%20fill='%23373d3d'%20stroke='%23a3aaaa'%20stroke-width='1'/%3e%3ccircle%20cx='32'%20cy='37'%20r='4'%20fill='%23373d3d'%20stroke='%23a3aaaa'%20stroke-width='1'/%3e%3ccircle%20cx='48'%20cy='44'%20r='8'%20fill='%23373d3d'%20stroke='%23a3aaaa'%20stroke-width='1'/%3e%3ccircle%20cx='71'%20cy='45'%20r='4'%20fill='%23373d3d'%20stroke='%23a3aaaa'%20stroke-width='1'/%3e%3ccircle%20cx='27'%20cy='62'%20r='5'%20fill='%23373d3d'%20stroke='%23a3aaaa'%20stroke-width='1'/%3e%3ccircle%20cx='44'%20cy='69'%20r='4'%20fill='%23373d3d'%20stroke='%23a3aaaa'%20stroke-width='1'/%3e%3ccircle%20cx='65'%20cy='68'%20r='7'%20fill='%23373d3d'%20stroke='%23a3aaaa'%20stroke-width='1'/%3e%3ccircle%20cx='56'%20cy='83'%20r='3'%20fill='%23373d3d'%20stroke='%23a3aaaa'%20stroke-width='1'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-bacteria.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cpath%20d='M13.16%2023.03C11.78%2024.41%2010.92%2024.61%2010.53%2026.97C10.13%2029.34%2010.92%2036.64%2010.53%2038.82C10.13%2040.99%208.29%2040.46%207.89%2041.45C7.50%2042.43%205.72%2042.63%207.89%2045.39C10.07%2048.16%2019.61%2057.50%2022.37%2059.87C25.13%2062.24%2025.33%2060.20%2026.32%2061.18C27.30%2062.17%2027.57%2065.46%2028.95%2066.45C30.33%2067.43%2033.75%2068.16%2035.53%2067.76C37.30%2067.37%2039.61%2064.21%2040.79%2063.82C41.97%2063.42%2041.64%2065.53%2043.42%2065.13C45.20%2064.74%2049.28%2061.38%2052.63%2061.18C55.99%2060.99%2063.82%2062.43%2065.79%2063.82C67.76%2065.20%2064.80%2067.83%2065.79%2070.39C66.78%2072.96%2070.79%2079.14%2072.37%2080.92C73.95%2082.70%2075.13%2082.24%2076.32%2082.24C77.50%2082.24%2078.88%2081.91%2080.26%2080.92C81.64%2079.93%2084.34%2077.24%2085.53%2075.66C86.71%2074.08%2087.76%2072.57%2088.16%2070.39C88.55%2068.22%2087.76%2062.96%2088.16%2061.18C88.55%2059.41%2090.39%2059.54%2090.79%2058.55C91.18%2057.57%2091.18%2055.79%2090.79%2054.61C90.39%2053.42%2089.14%2051.45%2088.16%2050.66C87.17%2049.87%2085.20%2050.33%2084.21%2049.34C83.22%2048.36%2083.36%2045.66%2081.58%2044.08C79.80%2042.50%2074.34%2040.39%2072.37%2038.82C70.39%2037.24%2069.80%2034.54%2068.42%2033.55C67.04%2032.57%2064.54%2031.84%2063.16%2032.24C61.78%2032.63%2060.79%2035.39%2059.21%2036.18C57.63%2036.97%2053.82%2037.50%2052.63%2037.50C51.45%2037.50%2051.91%2035.99%2051.32%2036.18C50.72%2036.38%2049.87%2038.22%2048.68%2038.82C47.50%2039.41%2044.61%2040.33%2043.42%2040.13C42.24%2039.93%2042.37%2038.09%2040.79%2037.50C39.21%2036.91%2034.08%2037.37%2032.89%2036.18C31.71%2035.00%2033.49%2032.17%2032.89%2029.61C32.30%2027.04%2030.92%2020.86%2028.95%2019.08C26.97%2017.30%2022.11%2017.17%2019.74%2017.76C17.37%2018.36%2014.54%2021.64%2013.16%2023.03Z'%20fill='url(%23symBacteria)'%20stroke='%23fff'%20stroke-width='4'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-biome.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cpath%20d='M8%2030H83L94%2050L83%2070H8L1%2050Z'%20fill='%232cadd0'%20stroke='%23fff'%20stroke-width='2.6'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M48%2031H82L91%2050L82%2069H30Z'%20fill='%2314759a'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M9%2042Q8%2035%2015%2037Q20%2028%2027%2038Q35%2037%2034%2046H12Z'%20fill='%23fff'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M56%2043Q57%2036%2063%2038Q68%2030%2073%2040Q81%2039%2080%2047H57ZM66%2046L62%2053H68L65%2059L75%2049H69L72%2044Z'%20fill='%23fff'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M83%2031L90%2050L83%2069H91L99%2050L91%2031Z'%20fill='%23c3cbcd'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cg%20transform='translate(42%2015)%20scale(0.65)'%3e%3cpath%20d='M50%2046C67%2049%2077%2059%2083%2073L90%2072L82%2091L64%2076L71%2074C66%2062%2059%2055%2050%2049Z'%20fill='%23fff'%20stroke='%23202020'%20stroke-width='2.3'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-biomeTile.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cpath%20d='M8%2030H83L94%2050L83%2070H8L1%2050Z'%20fill='%232cadd0'%20stroke='%23fff'%20stroke-width='2.6'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M48%2031H82L91%2050L82%2069H30Z'%20fill='%2314759a'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M9%2042Q8%2035%2015%2037Q20%2028%2027%2038Q35%2037%2034%2046H12Z'%20fill='%23fff'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M56%2043Q57%2036%2063%2038Q68%2030%2073%2040Q81%2039%2080%2047H57ZM66%2046L62%2053H68L65%2059L75%2049H69L72%2044Z'%20fill='%23fff'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M83%2031L90%2050L83%2069H91L99%2050L91%2031Z'%20fill='%23c3cbcd'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-carbon.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3ccircle%20cx='50'%20cy='50'%20r='46'%20fill='%23718186'%20stroke='none'%20stroke-width='1'/%3e%3ccircle%20cx='50'%20cy='49'%20r='43.8'%20fill='url(%23symCarbon)'%20stroke='%23fff'%20stroke-width='2.8'/%3e%3cpath%20d='M50%2020L75%2034.5V63.5L50%2078L25%2063.5V34.5Z'%20fill='none'%20stroke='%23fff'%20stroke-width='3'%20stroke-linejoin='round'%20/%3e%3ccircle%20cx='50'%20cy='20'%20r='6'%20fill='%23fff'%20stroke='none'%20stroke-width='1'/%3e%3ccircle%20cx='75'%20cy='34.5'%20r='6'%20fill='%23fff'%20stroke='none'%20stroke-width='1'/%3e%3ccircle%20cx='75'%20cy='63.5'%20r='6'%20fill='%23fff'%20stroke='none'%20stroke-width='1'/%3e%3ccircle%20cx='50'%20cy='78'%20r='6'%20fill='%23fff'%20stroke='none'%20stroke-width='1'/%3e%3ccircle%20cx='25'%20cy='63.5'%20r='6'%20fill='%23fff'%20stroke='none'%20stroke-width='1'/%3e%3ccircle%20cx='25'%20cy='34.5'%20r='6'%20fill='%23fff'%20stroke='none'%20stroke-width='1'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-draw.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3crect%20x='17'%20y='5'%20width='66'%20height='90'%20rx='4'%20fill='url(%23symLife)'%20stroke='%23fff'%20stroke-width='3'/%3e%3cpath%20d='M39%206V94M61%206V94'%20stroke='%23f1f3e4'%20stroke-width='1.5'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-energy.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cpath%20d='M70.15%208.96L35.82%208.96L34.33%2010.45L32.84%2023.88L23.88%2058.21L37.31%2058.21L38.81%2059.70L32.84%2079.10L31.34%2091.04L74.63%2041.79L58.21%2041.79L56.72%2040.30L70.15%208.96Z'%20fill='%23ffd342'%20stroke='%23fff'%20stroke-width='3'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-entropy.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cpath%20d='M7.25%2013.77L18.84%2039.86L23.19%2035.51L26.09%2035.51L37.68%2047.10L40.58%2063.04L33.33%2064.49L43.48%2080.43L50.72%2087.68L66.67%2064.49L59.42%2063.04L62.32%2047.10L75.36%2034.06L79.71%2039.86L92.75%2013.77L63.77%2010.87L66.67%2018.12L50.72%2023.91L34.78%2019.57L33.33%2016.67L36.23%2010.87L7.25%2013.77Z'%20fill='%23f4433e'%20stroke='%23fff'%20stroke-width='3.1'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-evolve.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cg%20transform='translate(0%209)%20scale(0.82)'%3e%3cpath%20d='M37.50%207.81C36.56%207.58%2038.67%209.30%2037.50%2010.94C36.33%2012.58%2031.56%2017.34%2029.69%2018.75C27.81%2020.16%2026.64%2020.31%2025.00%2020.31C23.36%2020.31%2019.69%2017.34%2018.75%2018.75C17.81%2020.16%2019.92%2026.88%2018.75%2029.69C17.58%2032.50%2012.58%2036.33%2010.94%2037.50C9.30%2038.67%207.58%2036.33%207.81%2037.50C8.05%2038.67%2011.80%2042.73%2012.50%2045.31C13.20%2047.89%2013.20%2052.34%2012.50%2054.69C11.80%2057.03%207.11%2058.83%207.81%2060.94C8.52%2063.05%2015.55%2065.70%2017.19%2068.75C18.83%2071.80%2018.05%2079.61%2018.75%2081.25C19.45%2082.89%2020.23%2079.69%2021.88%2079.69C23.52%2079.69%2027.34%2080.08%2029.69%2081.25C32.03%2082.42%2036.33%2085.86%2037.50%2087.50C38.67%2089.14%2036.56%2092.19%2037.50%2092.19C38.44%2092.19%2041.17%2088.20%2043.75%2087.50C46.33%2086.80%2052.11%2086.80%2054.69%2087.50C57.27%2088.20%2060.00%2091.95%2060.94%2092.19C61.88%2092.42%2060.00%2090.47%2060.94%2089.06C61.88%2087.66%2065.31%2084.22%2067.19%2082.81C69.06%2081.41%2071.33%2079.92%2073.44%2079.69C75.55%2079.45%2080.31%2081.25%2081.25%2081.25C82.19%2081.25%2079.69%2081.56%2079.69%2079.69C79.69%2077.81%2080.08%2071.33%2081.25%2068.75C82.42%2066.17%2085.86%2063.67%2087.50%2062.50C89.14%2061.33%2092.42%2062.58%2092.19%2060.94C91.95%2059.30%2086.64%2054.14%2085.94%2051.56C85.23%2048.98%2086.56%2045.86%2087.50%2043.75C88.44%2041.64%2092.19%2038.44%2092.19%2037.50C92.19%2036.56%2088.91%2038.20%2087.50%2037.50C86.09%2036.80%2083.98%2034.45%2082.81%2032.81C81.64%2031.17%2079.92%2028.67%2079.69%2026.56C79.45%2024.45%2082.19%2019.69%2081.25%2018.75C80.31%2017.81%2075.55%2020.55%2073.44%2020.31C71.33%2020.08%2069.06%2018.59%2067.19%2017.19C65.31%2015.78%2061.88%2012.34%2060.94%2010.94C60.00%209.53%2061.88%207.58%2060.94%207.81C60.00%208.05%2057.27%2011.80%2054.69%2012.50C52.11%2013.20%2046.33%2013.20%2043.75%2012.50C41.17%2011.80%2038.44%208.05%2037.50%207.81Z'%20fill='url(%23symHeat)'%20stroke='%23fff'%20stroke-width='2.8'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M47%2024C26%2030%2030%2050%2048%2048S73%2061%2057%2073M29%2062Q42%2074%2046%2061T65%2036'%20transform='rotate(0%2050%2050)'%20fill='none'%20stroke='%23e8ad20'%20stroke-width='1.1'%20opacity='.6'/%3e%3cpath%20d='M47%2024C26%2030%2030%2050%2048%2048S73%2061%2057%2073M29%2062Q42%2074%2046%2061T65%2036'%20transform='rotate(60%2050%2050)'%20fill='none'%20stroke='%23e8ad20'%20stroke-width='1.1'%20opacity='.6'/%3e%3cpath%20d='M47%2024C26%2030%2030%2050%2048%2048S73%2061%2057%2073M29%2062Q42%2074%2046%2061T65%2036'%20transform='rotate(120%2050%2050)'%20fill='none'%20stroke='%23e8ad20'%20stroke-width='1.1'%20opacity='.6'/%3e%3cpath%20d='M47%2024C26%2030%2030%2050%2048%2048S73%2061%2057%2073M29%2062Q42%2074%2046%2061T65%2036'%20transform='rotate(180%2050%2050)'%20fill='none'%20stroke='%23e8ad20'%20stroke-width='1.1'%20opacity='.6'/%3e%3cpath%20d='M47%2024C26%2030%2030%2050%2048%2048S73%2061%2057%2073M29%2062Q42%2074%2046%2061T65%2036'%20transform='rotate(240%2050%2050)'%20fill='none'%20stroke='%23e8ad20'%20stroke-width='1.1'%20opacity='.6'/%3e%3cpath%20d='M47%2024C26%2030%2030%2050%2048%2048S73%2061%2057%2073M29%2062Q42%2074%2046%2061T65%2036'%20transform='rotate(300%2050%2050)'%20fill='none'%20stroke='%23e8ad20'%20stroke-width='1.1'%20opacity='.6'/%3e%3c/g%3e%3cpath%20d='M57%2028L77%2016L96%2027V47L77%2037L57%2048Z'%20fill='%23fff'%20stroke='%23202020'%20stroke-width='2.4'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-fulfill.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cpath%20d='M8%2030H83L94%2050L83%2070H8L1%2050Z'%20fill='%232cadd0'%20stroke='%23fff'%20stroke-width='2.6'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M48%2031H82L91%2050L82%2069H30Z'%20fill='%2314759a'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M9%2042Q8%2035%2015%2037Q20%2028%2027%2038Q35%2037%2034%2046H12Z'%20fill='%23fff'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M56%2043Q57%2036%2063%2038Q68%2030%2073%2040Q81%2039%2080%2047H57ZM66%2046L62%2053H68L65%2059L75%2049H69L72%2044Z'%20fill='%23fff'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M83%2031L90%2050L83%2069H91L99%2050L91%2031Z'%20fill='%23c3cbcd'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cg%20transform='translate(24%2016)%20scale(0.76)'%3e%3cpath%20d='M57%2028L77%2016L96%2027V47L77%2037L57%2048Z'%20fill='%23fff'%20stroke='%23202020'%20stroke-width='2.4'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-generator.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cpath%20d='M14%2012Q18%2010%2023%2012L84%2032Q89%2034%2089%2040V67Q89%2074%2081%2077L18%2096Q7%2098%207%2087L9%2027Q9%2016%2014%2012Z'%20fill='%23080909'%20stroke='%23fff'%20stroke-width='3'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M15%2015Q17%2012%2023%2015L83%2034Q87%2036%2085%2041L81%2060L20%2080Q9%2083%2010%2074L12%2026Q12%2018%2015%2015Z'%20fill='%23505252'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M25%2025L41%2030L36%2034L54%2040L64%2038L78%2044L64%2050L61%2047L46%2053L37%2062L41%2065L25%2071L24%2058L29%2060L34%2049L28%2042L25%2044Z'%20fill='%23fff'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M65%2061H85L95%2080L85%2098H65L75%2080Z'%20fill='%23fff'%20stroke='%231e2020'%20stroke-width='2.4'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-heat.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3ccircle%20cx='50'%20cy='50'%20r='46'%20fill='%23718186'%20stroke='none'%20stroke-width='1'/%3e%3ccircle%20cx='50'%20cy='49'%20r='43.8'%20fill='url(%23symHeat)'%20stroke='%23fff'%20stroke-width='2.8'/%3e%3cpath%20d='M70.49%2031.15C69.75%2031.15%2070.57%2040.08%2068.85%2044.26C67.13%2048.44%2060.49%2055.57%2059.02%2059.02C57.54%2062.46%2058.52%2065.00%2059.02%2067.21C59.51%2069.43%2061.80%2074.26%2062.30%2073.77C62.79%2073.28%2060.82%2067.38%2062.30%2063.93C63.77%2060.49%2070.41%2053.77%2072.13%2050.82C73.85%2047.87%2074.02%2047.21%2073.77%2044.26C73.52%2041.31%2071.23%2031.15%2070.49%2031.15ZM37.70%2026.23C37.21%2024.26%2036.31%2025.00%2036.07%2026.23C35.82%2027.46%2037.79%2030.25%2036.07%2034.43C34.34%2038.61%2026.31%2050.16%2024.59%2054.10C22.87%2058.03%2024.10%2058.69%2024.59%2060.66C25.08%2062.62%2027.38%2067.46%2027.87%2067.21C28.36%2066.97%2026.15%2063.20%2027.87%2059.02C29.59%2054.84%2037.87%2044.26%2039.34%2039.34C40.82%2034.43%2038.20%2028.20%2037.70%2026.23ZM54.10%2018.03C53.11%2019.75%2054.67%2031.80%2052.46%2037.70C50.25%2043.61%2041.31%2052.21%2039.34%2057.38C37.38%2062.54%2038.61%2068.69%2039.34%2072.13C40.08%2075.57%2043.52%2081.31%2044.26%2080.33C45.00%2079.34%2042.05%2071.48%2044.26%2065.57C46.48%2059.67%2056.80%2046.89%2059.02%2040.98C61.23%2035.08%2059.75%2029.67%2059.02%2026.23C58.28%2022.79%2055.08%2016.31%2054.10%2018.03Z'%20fill='%23fff'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20fill-rule='evenodd'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-life.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cg%20transform='translate(-2%20-1)%20scale(0.94)'%3e%3crect%20x='17'%20y='5'%20width='66'%20height='90'%20rx='4'%20fill='url(%23symLife)'%20stroke='%23fff'%20stroke-width='3'/%3e%3cpath%20d='M39%206V94M61%206V94'%20stroke='%23f1f3e4'%20stroke-width='1.5'/%3e%3c/g%3e%3cpath%20d='M50%2046C67%2049%2077%2059%2083%2073L90%2072L82%2091L64%2076L71%2074C66%2062%2059%2055%2050%2049Z'%20fill='%23fff'%20stroke='%23202020'%20stroke-width='2.3'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-local.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cpath%20d='M50%205C24%205%2012%2023%2017%2044Q25%2067%2050%2093Q74%2067%2083%2044C88%2023%2076%205%2050%205Z'%20fill='%23313338'%20stroke='%23fff'%20stroke-width='3'%20stroke-linejoin='round'%20/%3e%3ccircle%20cx='50'%20cy='32'%20r='16'%20fill='none'%20stroke='%23fff'%20stroke-width='2'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-mass.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3crect%20x='10'%20y='10'%20width='79'%20height='79'%20rx='5'%20fill='url(%23symMass)'%20stroke='%23fff'%20stroke-width='3.5'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-planet.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3ccircle%20cx='50'%20cy='50'%20r='45'%20fill='url(%23symGlobe)'%20stroke='%23fff'%20stroke-width='2.8'/%3e%3cpath%20d='M79.69%2056.25C79.45%2057.19%2084.30%2060.23%2085.94%2060.94C87.58%2061.64%2089.92%2061.64%2090.62%2060.94C91.33%2060.23%2091.09%2057.19%2090.62%2056.25C90.16%2055.31%2089.14%2054.69%2087.50%2054.69C85.86%2054.69%2079.92%2055.31%2079.69%2056.25ZM7.81%2045.31C6.88%2046.95%207.73%2058.59%209.38%2060.94C11.02%2063.28%2017.11%2061.17%2018.75%2060.94C20.39%2060.70%2021.02%2060.55%2020.31%2059.38C19.61%2058.20%2014.77%2054.53%2014.06%2053.12C13.36%2051.72%2016.56%2051.17%2015.62%2050.00C14.69%2048.83%208.75%2043.67%207.81%2045.31ZM57.81%2035.94C56.88%2036.17%2057.11%2038.36%2057.81%2039.06C58.52%2039.77%2061.09%2039.45%2062.50%2040.62C63.91%2041.80%2065.78%2045.70%2067.19%2046.88C68.59%2048.05%2070.47%2048.44%2071.88%2048.44C73.28%2048.44%2076.56%2047.58%2076.56%2046.88C76.56%2046.17%2072.58%2044.69%2071.88%2043.75C71.17%2042.81%2072.58%2041.09%2071.88%2040.62C71.17%2040.16%2068.36%2041.09%2067.19%2040.62C66.02%2040.16%2065.47%2038.20%2064.06%2037.50C62.66%2036.80%2058.75%2035.70%2057.81%2035.94ZM79.69%2020.31C79.22%2018.20%2076.25%2015.70%2073.44%2014.06C70.62%2012.42%2063.05%209.84%2060.94%209.38C58.83%208.91%2059.84%2011.17%2059.38%2010.94C58.91%2010.70%2060.62%208.28%2057.81%207.81C55.00%207.34%2044.84%206.88%2040.62%207.81C36.41%208.75%2031.56%2013.36%2029.69%2014.06C27.81%2014.77%2030.00%2010.39%2028.12%2012.50C26.25%2014.61%2018.12%2024.84%2017.19%2028.12C16.25%2031.41%2020.47%2033.67%2021.88%2034.38C23.28%2035.08%2024.69%2032.81%2026.56%2032.81C28.44%2032.81%2033.20%2033.67%2034.38%2034.38C35.55%2035.08%2035.31%2036.33%2034.38%2037.50C33.44%2038.67%2029.30%2040.55%2028.12%2042.19C26.95%2043.83%2025.62%2047.27%2026.56%2048.44C27.50%2049.61%2031.80%2050.23%2034.38%2050.00C36.95%2049.77%2041.64%2048.05%2043.75%2046.88C45.86%2045.70%2048.44%2044.53%2048.44%2042.19C48.44%2039.84%2043.98%2033.59%2043.75%2031.25C43.52%2028.91%2044.30%2027.27%2046.88%2026.56C49.45%2025.86%2057.89%2025.62%2060.94%2026.56C63.98%2027.50%2066.02%2032.34%2067.19%2032.81C68.36%2033.28%2068.28%2029.92%2068.75%2029.69C69.22%2029.45%2069.61%2031.48%2070.31%2031.25C71.02%2031.02%2072.50%2028.59%2073.44%2028.12C74.38%2027.66%2075.62%2029.30%2076.56%2028.12C77.50%2026.95%2080.16%2022.42%2079.69%2020.31Z'%20fill='%23d2b057'%20stroke='%23718c5e'%20stroke-width='0.7'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-plant.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cpath%20d='M47.37%2016.45C45.20%2018.22%2039.21%2024.74%2036.84%2028.29C34.47%2031.84%2034.34%2038.75%2031.58%2040.13C28.82%2041.51%2020.59%2037.50%2018.42%2037.50C16.25%2037.50%2017.11%2037.37%2017.11%2040.13C17.11%2042.89%2018.82%2053.16%2018.42%2055.92C18.03%2058.68%2016.05%2058.16%2014.47%2058.55C12.89%2058.95%208.68%2057.57%207.89%2058.55C7.11%2059.54%207.83%2062.37%209.21%2065.13C10.59%2067.89%2014.34%2074.21%2017.11%2076.97C19.87%2079.74%2024.28%2082.57%2027.63%2083.55C30.99%2084.54%2037.50%2083.75%2039.47%2083.55C41.45%2083.36%2036.05%2082.24%2040.79%2082.24C45.53%2082.24%2064.74%2084.54%2071.05%2083.55C77.37%2082.57%2080.53%2077.63%2082.89%2075.66C85.26%2073.68%2085.66%2072.76%2086.84%2070.39C88.03%2068.03%2090.99%2061.84%2090.79%2059.87C90.59%2057.89%2086.91%2057.43%2085.53%2057.24C84.14%2057.04%2082.57%2058.75%2081.58%2058.55C80.59%2058.36%2078.95%2057.50%2078.95%2055.92C78.95%2054.34%2081.38%2050.79%2081.58%2048.03C81.78%2045.26%2081.25%2039.08%2080.26%2037.50C79.28%2035.92%2076.97%2036.91%2075.00%2037.50C73.03%2038.09%2069.47%2043.42%2067.11%2041.45C64.74%2039.47%2061.58%2028.09%2059.21%2024.34C56.84%2020.59%2053.09%2017.63%2051.32%2016.45C49.54%2015.26%2049.54%2014.67%2047.37%2016.45Z'%20fill='url(%23symPlant)'%20stroke='%23fff'%20stroke-width='4'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-radiation.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3ccircle%20cx='50'%20cy='50'%20r='46'%20fill='%23718186'%20stroke='none'%20stroke-width='1'/%3e%3ccircle%20cx='50'%20cy='49'%20r='43.8'%20fill='url(%23symRadiation)'%20stroke='%23fff'%20stroke-width='2.8'/%3e%3cpath%20d='M85.25%2040.98C83.77%2041.48%2065.82%2047.87%2060.66%2050.82C55.49%2053.77%2052.79%2057.21%2050.82%2060.66C48.85%2064.10%2047.79%2071.07%2047.54%2073.77C47.30%2076.48%2047.70%2076.72%2049.18%2078.69C50.66%2080.66%2054.67%2086.15%2057.38%2086.89C60.08%2087.62%2064.75%2084.84%2067.21%2083.61C69.67%2082.38%2074.51%2080.66%2073.77%2078.69C73.03%2076.72%2064.51%2072.70%2062.30%2070.49C60.08%2068.28%2059.26%2065.90%2059.02%2063.93C58.77%2061.97%2058.93%2059.84%2060.66%2057.38C62.38%2054.92%2066.80%2050.00%2070.49%2047.54C74.18%2045.08%2086.72%2040.49%2085.25%2040.98ZM34.43%2027.87C32.70%2028.36%2029.75%2032.70%2029.51%2034.43C29.26%2036.15%2031.07%2038.85%2032.79%2039.34C34.51%2039.84%2039.75%2038.93%2040.98%2037.70C42.21%2036.48%2041.97%2032.62%2040.98%2031.15C40.00%2029.67%2036.15%2027.38%2034.43%2027.87Z'%20fill='%23fff'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20fill-rule='evenodd'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-retrieve.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cpath%20d='M38%2013L68%204L90%2017V83L61%2097L37%2081Z'%20fill='%23161a1b'%20stroke='%23fff'%20stroke-width='2.7'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M38%2013L62%2024L90%2017L68%204Z'%20fill='%23929b9c'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M62%2024V96'%20fill='none'%20stroke='%23fff'%20stroke-width='1'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M43%2039q4%205%200%2010t0%2013t0%2013'%20fill='none'%20stroke='%23e2e5df'%20stroke-width='1.4'/%3e%3cpath%20d='M48%2039q4%205%200%2010t0%2013t0%2013'%20fill='none'%20stroke='%23e2e5df'%20stroke-width='1.4'/%3e%3cpath%20d='M53%2039q4%205%200%2010t0%2013t0%2013'%20fill='none'%20stroke='%23e2e5df'%20stroke-width='1.4'/%3e%3cpath%20d='M58%2039q4%205%200%2010t0%2013t0%2013'%20fill='none'%20stroke='%23e2e5df'%20stroke-width='1.4'/%3e%3cpath%20d='M43%2056Q20%2048%2012%2029L5%2032L16%206L35%2024L26%2025Q30%2043%2043%2050Z'%20fill='%23fff'%20stroke='%23222'%20stroke-width='2.4'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-soup.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cg%20transform='translate(-4%2015)%20scale(0.63)'%3e%3cpath%20d='M14%2012Q18%2010%2023%2012L84%2032Q89%2034%2089%2040V67Q89%2074%2081%2077L18%2096Q7%2098%207%2087L9%2027Q9%2016%2014%2012Z'%20fill='%23080909'%20stroke='%23fff'%20stroke-width='3'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M15%2015Q17%2012%2023%2015L83%2034Q87%2036%2085%2041L81%2060L20%2080Q9%2083%2010%2074L12%2026Q12%2018%2015%2015Z'%20fill='%23505252'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M25%2025L41%2030L36%2034L54%2040L64%2038L78%2044L64%2050L61%2047L46%2053L37%2062L41%2065L25%2071L24%2058L29%2060L34%2049L28%2042L25%2044Z'%20fill='%23fff'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M65%2061H85L95%2080L85%2098H65L75%2080Z'%20fill='%23fff'%20stroke='%231e2020'%20stroke-width='2.4'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3cg%20transform='translate(45%207)%20scale(0.5)'%3e%3crect%20x='10'%20y='10'%20width='79'%20height='79'%20rx='5'%20fill='url(%23symMass)'%20stroke='%23fff'%20stroke-width='3.5'/%3e%3c/g%3e%3cg%20transform='translate(45%2048)%20scale(0.5)'%3e%3cpath%20d='M70.15%208.96L35.82%208.96L34.33%2010.45L32.84%2023.88L23.88%2058.21L37.31%2058.21L38.81%2059.70L32.84%2079.10L31.34%2091.04L74.63%2041.79L58.21%2041.79L56.72%2040.30L70.15%208.96Z'%20fill='%23ffd342'%20stroke='%23fff'%20stroke-width='3'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-star.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cpath%20d='M37.50%207.81C36.56%207.58%2038.67%209.30%2037.50%2010.94C36.33%2012.58%2031.56%2017.34%2029.69%2018.75C27.81%2020.16%2026.64%2020.31%2025.00%2020.31C23.36%2020.31%2019.69%2017.34%2018.75%2018.75C17.81%2020.16%2019.92%2026.88%2018.75%2029.69C17.58%2032.50%2012.58%2036.33%2010.94%2037.50C9.30%2038.67%207.58%2036.33%207.81%2037.50C8.05%2038.67%2011.80%2042.73%2012.50%2045.31C13.20%2047.89%2013.20%2052.34%2012.50%2054.69C11.80%2057.03%207.11%2058.83%207.81%2060.94C8.52%2063.05%2015.55%2065.70%2017.19%2068.75C18.83%2071.80%2018.05%2079.61%2018.75%2081.25C19.45%2082.89%2020.23%2079.69%2021.88%2079.69C23.52%2079.69%2027.34%2080.08%2029.69%2081.25C32.03%2082.42%2036.33%2085.86%2037.50%2087.50C38.67%2089.14%2036.56%2092.19%2037.50%2092.19C38.44%2092.19%2041.17%2088.20%2043.75%2087.50C46.33%2086.80%2052.11%2086.80%2054.69%2087.50C57.27%2088.20%2060.00%2091.95%2060.94%2092.19C61.88%2092.42%2060.00%2090.47%2060.94%2089.06C61.88%2087.66%2065.31%2084.22%2067.19%2082.81C69.06%2081.41%2071.33%2079.92%2073.44%2079.69C75.55%2079.45%2080.31%2081.25%2081.25%2081.25C82.19%2081.25%2079.69%2081.56%2079.69%2079.69C79.69%2077.81%2080.08%2071.33%2081.25%2068.75C82.42%2066.17%2085.86%2063.67%2087.50%2062.50C89.14%2061.33%2092.42%2062.58%2092.19%2060.94C91.95%2059.30%2086.64%2054.14%2085.94%2051.56C85.23%2048.98%2086.56%2045.86%2087.50%2043.75C88.44%2041.64%2092.19%2038.44%2092.19%2037.50C92.19%2036.56%2088.91%2038.20%2087.50%2037.50C86.09%2036.80%2083.98%2034.45%2082.81%2032.81C81.64%2031.17%2079.92%2028.67%2079.69%2026.56C79.45%2024.45%2082.19%2019.69%2081.25%2018.75C80.31%2017.81%2075.55%2020.55%2073.44%2020.31C71.33%2020.08%2069.06%2018.59%2067.19%2017.19C65.31%2015.78%2061.88%2012.34%2060.94%2010.94C60.00%209.53%2061.88%207.58%2060.94%207.81C60.00%208.05%2057.27%2011.80%2054.69%2012.50C52.11%2013.20%2046.33%2013.20%2043.75%2012.50C41.17%2011.80%2038.44%208.05%2037.50%207.81Z'%20fill='url(%23symHeat)'%20stroke='%23fff'%20stroke-width='2.8'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M47%2024C26%2030%2030%2050%2048%2048S73%2061%2057%2073M29%2062Q42%2074%2046%2061T65%2036'%20transform='rotate(0%2050%2050)'%20fill='none'%20stroke='%23e8ad20'%20stroke-width='1.1'%20opacity='.6'/%3e%3cpath%20d='M47%2024C26%2030%2030%2050%2048%2048S73%2061%2057%2073M29%2062Q42%2074%2046%2061T65%2036'%20transform='rotate(60%2050%2050)'%20fill='none'%20stroke='%23e8ad20'%20stroke-width='1.1'%20opacity='.6'/%3e%3cpath%20d='M47%2024C26%2030%2030%2050%2048%2048S73%2061%2057%2073M29%2062Q42%2074%2046%2061T65%2036'%20transform='rotate(120%2050%2050)'%20fill='none'%20stroke='%23e8ad20'%20stroke-width='1.1'%20opacity='.6'/%3e%3cpath%20d='M47%2024C26%2030%2030%2050%2048%2048S73%2061%2057%2073M29%2062Q42%2074%2046%2061T65%2036'%20transform='rotate(180%2050%2050)'%20fill='none'%20stroke='%23e8ad20'%20stroke-width='1.1'%20opacity='.6'/%3e%3cpath%20d='M47%2024C26%2030%2030%2050%2048%2048S73%2061%2057%2073M29%2062Q42%2074%2046%2061T65%2036'%20transform='rotate(240%2050%2050)'%20fill='none'%20stroke='%23e8ad20'%20stroke-width='1.1'%20opacity='.6'/%3e%3cpath%20d='M47%2024C26%2030%2030%2050%2048%2048S73%2061%2057%2073M29%2062Q42%2074%2046%2061T65%2036'%20transform='rotate(300%2050%2050)'%20fill='none'%20stroke='%23e8ad20'%20stroke-width='1.1'%20opacity='.6'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-upgrade.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3crect%20x='19'%20y='9'%20width='56'%20height='82'%20rx='4'%20fill='%23d8d8d8'%20stroke='%23fff'%20stroke-width='3'/%3e%3crect%20x='23'%20y='13'%20width='48'%20height='29'%20rx='1'%20fill='%23bba76b'%20stroke='none'%20stroke-width='1'/%3e%3cpath%20d='M24%2028L32%2017L41%2029L49%2018L65%2035H24Z'%20fill='%239b8c59'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3crect%20x='23'%20y='48'%20width='48'%20height='10'%20rx='0'%20fill='%238a8c8b'%20stroke='none'%20stroke-width='1'/%3e%3crect%20x='23'%20y='63'%20width='48'%20height='8'%20rx='0'%20fill='%238a8c8b'%20stroke='none'%20stroke-width='1'/%3e%3crect%20x='23'%20y='76'%20width='48'%20height='9'%20rx='0'%20fill='%238a8c8b'%20stroke='none'%20stroke-width='1'/%3e%3cpath%20d='M57%2028L77%2016L96%2027V47L77%2037L57%2048Z'%20fill='%23fff'%20stroke='%23202020'%20stroke-width='2.4'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-vp.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cpath%20d='M49%205Q51%204%2054%206L82%2023Q86%2025%2085%2031L77%2082Q76%2085%2072%2087L53%2096Q50%2098%2046%2096L23%2086Q20%2085%2019%2080L12%2031Q11%2027%2016%2024Z'%20fill='url(%23symVp)'%20stroke='%23fff'%20stroke-width='3'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M49%2011L79%2028L72%2082L50%2092L25%2081L18%2029Z'%20fill='none'%20stroke='%23dce5dc'%20stroke-width='1'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M44%2018L49%2010L54%2018L51%2017L51%2026L48%2026L48%2017Z'%20fill='%23fff'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M29%2080Q50%2072%2072%2080M36%2084L44%2078M52%2088V77M63%2084L58%2078'%20fill='none'%20stroke='%23e4e9df'%20stroke-width='1.1'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-vpEnd.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cpath%20d='M49%205Q51%204%2054%206L82%2023Q86%2025%2085%2031L77%2082Q76%2085%2072%2087L53%2096Q50%2098%2046%2096L23%2086Q20%2085%2019%2080L12%2031Q11%2027%2016%2024Z'%20fill='url(%23symVpEnd)'%20stroke='%23fff'%20stroke-width='3'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M49%2011L79%2028L72%2082L50%2092L25%2081L18%2029Z'%20fill='none'%20stroke='%23dce5dc'%20stroke-width='1'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M44%2018L49%2010L54%2018L51%2017L51%2026L48%2026L48%2017Z'%20fill='%23fff'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20/%3e%3cpath%20d='M29%2080Q50%2072%2072%2080M36%2084L44%2078M52%2088V77M63%2084L58%2078'%20fill='none'%20stroke='%23e4e9df'%20stroke-width='1.1'%20stroke-linejoin='round'%20/%3e%3c/g%3e%3c/svg%3e",
	"./assets/icon-water.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3ccircle%20cx='50'%20cy='50'%20r='46'%20fill='%23718186'%20stroke='none'%20stroke-width='1'/%3e%3ccircle%20cx='50'%20cy='49'%20r='43.8'%20fill='url(%23symWater)'%20stroke='%23fff'%20stroke-width='2.8'/%3e%3cpath%20d='M47.54%2021.31C46.80%2022.30%2048.36%2023.93%2045.90%2027.87C43.44%2031.80%2033.61%2042.38%2031.15%2047.54C28.69%2052.70%2029.51%2059.34%2029.51%2062.30C29.51%2065.25%2029.92%2065.49%2031.15%2067.21C32.38%2068.93%2035.74%2072.30%2037.70%2073.77C39.67%2075.25%2041.80%2076.56%2044.26%2077.05C46.72%2077.54%2050.66%2078.52%2054.10%2077.05C57.54%2075.57%2065.00%2070.90%2067.21%2067.21C69.43%2063.52%2071.07%2058.36%2068.85%2052.46C66.64%2046.56%2055.16%2032.54%2052.46%2027.87C49.75%2023.20%2051.56%2022.30%2050.82%2021.31C50.08%2020.33%2048.28%2020.33%2047.54%2021.31ZM36.07%2054.10C37.54%2053.61%2040.66%2053.11%2042.62%2054.10C44.59%2055.08%2048.20%2058.44%2049.18%2060.66C50.16%2062.87%2050.16%2066.89%2049.18%2068.85C48.20%2070.82%2045.08%2074.26%2042.62%2073.77C40.16%2073.28%2034.26%2068.03%2032.79%2065.57C31.31%2063.11%2032.30%2059.10%2032.79%2057.38C33.28%2055.66%2034.59%2054.59%2036.07%2054.10Z'%20fill='%23fff'%20stroke='none'%20stroke-width='0'%20stroke-linejoin='round'%20fill-rule='evenodd'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/life-11.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='112'%20height='196'%20viewBox='0%200%20112%20196'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)'%3e%3csvg%20width='112'%20height='196'%20viewBox='0%200%20112%20196'%3e%3cdefs%3e%3clinearGradient%20id='worm11'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%232fa7bf'/%3e%3cstop%20offset='.25'%20stop-color='%23504a8e'/%3e%3cstop%20offset='.5'%20stop-color='%23b94190'/%3e%3cstop%20offset='.7'%20stop-color='%23dc5c9d'/%3e%3cstop%20offset='1'%20stop-color='%23771965'/%3e%3c/linearGradient%3e%3c/defs%3e%3cpath%20d='M49%2013C73%2055%2031%2071%2034%20116C33%20144%2055%20157%2044%20178'%20fill='none'%20stroke='%2373d3d8'%20stroke-width='18'%20stroke-linecap='round'/%3e%3cpath%20d='M49%2013C73%2055%2031%2071%2034%20116C33%20144%2055%20157%2044%20178'%20fill='none'%20stroke='url(%23worm11)'%20stroke-width='15'%20stroke-linecap='round'/%3e%3cpath%20d='M51%2014C71%2055%2031%2072%2038%20116C34%20144%2056%20156%2046%20174'%20fill='none'%20stroke='%23e366a7'%20stroke-width='2.2'%20stroke-linecap='round'/%3e%3cpath%20d='M57%2036q10%20-2%2010%205l3%204M57%2039q7%201%205%208'%20fill='none'%20stroke='%23254c73'%20stroke-width='2.3'%20stroke-linecap='round'/%3e%3cpath%20d='M56%2053q10%20-2%2010%205l3%204M56%2056q7%201%205%208'%20fill='none'%20stroke='%23254c73'%20stroke-width='2.3'%20stroke-linecap='round'/%3e%3cpath%20d='M42%2075q-10%20-2%20-10%205l-3%204M42%2078q-7%201%20-5%208'%20fill='none'%20stroke='%23254c73'%20stroke-width='2.3'%20stroke-linecap='round'/%3e%3cpath%20d='M34%2096q-10%20-2%20-10%205l-3%204M34%2099q-7%201%20-5%208'%20fill='none'%20stroke='%23254c73'%20stroke-width='2.3'%20stroke-linecap='round'/%3e%3cpath%20d='M33%20117q-10%20-2%20-10%205l-3%204M33%20120q-7%201%20-5%208'%20fill='none'%20stroke='%23254c73'%20stroke-width='2.3'%20stroke-linecap='round'/%3e%3cpath%20d='M39%20141q10%20-2%2010%205l3%204M39%20144q7%201%205%208'%20fill='none'%20stroke='%23254c73'%20stroke-width='2.3'%20stroke-linecap='round'/%3e%3cpath%20d='M47%20159q10%20-2%2010%205l3%204M47%20162q7%201%205%208'%20fill='none'%20stroke='%23254c73'%20stroke-width='2.3'%20stroke-linecap='round'/%3e%3cpath%20d='M44%209L45%204L49%207L54%203L56%2010'%20fill='%23875088'%20stroke='%234e3c79'%20stroke-width='1.5'/%3e%3c/svg%3e%3c/g%3e%3c/svg%3e",
	"./assets/life-31.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='112'%20height='196'%20viewBox='0%200%20112%20196'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)'%3e%3csvg%20width='112'%20height='196'%20viewBox='0%200%20112%20196'%3e%3cdefs%3e%3clinearGradient%20id='coral31'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%23642d52'/%3e%3cstop%20offset='.4'%20stop-color='%23b43b67'/%3e%3cstop%20offset='.7'%20stop-color='%23d75c78'/%3e%3cstop%20offset='1'%20stop-color='%23762c51'/%3e%3c/linearGradient%3e%3cradialGradient%20id='root31'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23c7c292'/%3e%3cstop%20offset='.35'%20stop-color='%238d8661'/%3e%3cstop%20offset='1'%20stop-color='%233f4e43'/%3e%3c/radialGradient%3e%3c/defs%3e%3cpath%20d='M34%20160Q43%20143%2059%20151Q72%20147%2078%20165L73%20179Q55%20191%2033%20181Z'%20fill='url(%23root31)'%20stroke='%2358624b'%20stroke-width='1.3'/%3e%3cpath%20d='M51%20164L51%20120L38%20102L38%2064L28%2048L28%2017'%20fill='none'%20stroke='%234e3f4b'%20stroke-width='5.6'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M51%20164L51%20120L38%20102L38%2064L28%2048L28%2017'%20fill='none'%20stroke='url(%23coral31)'%20stroke-width='4.1'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M53%20154L57%20110L71%2095L71%2068L85%2055L84%2031'%20fill='none'%20stroke='%234e3f4b'%20stroke-width='5.6'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M53%20154L57%20110L71%2095L71%2068L85%2055L84%2031'%20fill='none'%20stroke='url(%23coral31)'%20stroke-width='4.1'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M48%20136L28%20118L23%2093L11%2081L11%2062'%20fill='none'%20stroke='%234e3f4b'%20stroke-width='5.6'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M48%20136L28%20118L23%2093L11%2081L11%2062'%20fill='none'%20stroke='url(%23coral31)'%20stroke-width='4.1'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M54%20125L74%20116L84%2099L98%2087L101%2064'%20fill='none'%20stroke='%234e3f4b'%20stroke-width='5.6'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M54%20125L74%20116L84%2099L98%2087L101%2064'%20fill='none'%20stroke='url(%23coral31)'%20stroke-width='4.1'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M39%2085L54%2073L55%2048L46%2034L45%207'%20fill='none'%20stroke='%234e3f4b'%20stroke-width='5.6'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M39%2085L54%2073L55%2048L46%2034L45%207'%20fill='none'%20stroke='url(%23coral31)'%20stroke-width='4.1'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M72%2082L61%2068L64%2052'%20fill='none'%20stroke='%234e3f4b'%20stroke-width='5.6'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M72%2082L61%2068L64%2052'%20fill='none'%20stroke='url(%23coral31)'%20stroke-width='4.1'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M29%20115L15%20118L10%20102'%20fill='none'%20stroke='%234e3f4b'%20stroke-width='5.6'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M29%20115L15%20118L10%20102'%20fill='none'%20stroke='url(%23coral31)'%20stroke-width='4.1'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M52%20109L45%2097L45%2084'%20fill='none'%20stroke='%234e3f4b'%20stroke-width='5.6'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M52%20109L45%2097L45%2084'%20fill='none'%20stroke='url(%23coral31)'%20stroke-width='4.1'%20stroke-linecap='round'%20stroke-linejoin='round'/%3e%3cpath%20d='M26%2020q-5%20-4%20-2%20-8q6%200%207%205'%20fill='%23c9677d'%20stroke='%23775368'%20stroke-width='.8'/%3e%3cpath%20d='M29%2025q4%20-8%208%20-7q-1%208%20-8%2010'%20fill='%23739977'%20stroke='%234c7264'%20stroke-width='.7'/%3e%3cpath%20d='M43%2010q-5%20-4%20-2%20-8q6%200%207%205'%20fill='%23c9677d'%20stroke='%23775368'%20stroke-width='.8'/%3e%3cpath%20d='M46%2015q4%20-8%208%20-7q-1%208%20-8%2010'%20fill='%23739977'%20stroke='%234c7264'%20stroke-width='.7'/%3e%3cpath%20d='M82%2034q-5%20-4%20-2%20-8q6%200%207%205'%20fill='%23c9677d'%20stroke='%23775368'%20stroke-width='.8'/%3e%3cpath%20d='M85%2039q4%20-8%208%20-7q-1%208%20-8%2010'%20fill='%23739977'%20stroke='%234c7264'%20stroke-width='.7'/%3e%3cpath%20d='M9%2065q-5%20-4%20-2%20-8q6%200%207%205'%20fill='%23c9677d'%20stroke='%23775368'%20stroke-width='.8'/%3e%3cpath%20d='M12%2070q4%20-8%208%20-7q-1%208%20-8%2010'%20fill='%23739977'%20stroke='%234c7264'%20stroke-width='.7'/%3e%3cpath%20d='M99%2067q-5%20-4%20-2%20-8q6%200%207%205'%20fill='%23c9677d'%20stroke='%23775368'%20stroke-width='.8'/%3e%3cpath%20d='M102%2072q4%20-8%208%20-7q-1%208%20-8%2010'%20fill='%23739977'%20stroke='%234c7264'%20stroke-width='.7'/%3e%3cpath%20d='M62%2055q-5%20-4%20-2%20-8q6%200%207%205'%20fill='%23c9677d'%20stroke='%23775368'%20stroke-width='.8'/%3e%3cpath%20d='M65%2060q4%20-8%208%20-7q-1%208%20-8%2010'%20fill='%23739977'%20stroke='%234c7264'%20stroke-width='.7'/%3e%3cpath%20d='M43%2087q-5%20-4%20-2%20-8q6%200%207%205'%20fill='%23c9677d'%20stroke='%23775368'%20stroke-width='.8'/%3e%3cpath%20d='M46%2092q4%20-8%208%20-7q-1%208%20-8%2010'%20fill='%23739977'%20stroke='%234c7264'%20stroke-width='.7'/%3e%3cpath%20d='M8%20105q-5%20-4%20-2%20-8q6%200%207%205'%20fill='%23c9677d'%20stroke='%23775368'%20stroke-width='.8'/%3e%3cpath%20d='M11%20110q4%20-8%208%20-7q-1%208%20-8%2010'%20fill='%23739977'%20stroke='%234c7264'%20stroke-width='.7'/%3e%3cpath%20d='M35%20160q-4%202%20-1%205q6%201%207%20-3'%20fill='none'%20stroke='%23a8a880'%20stroke-width='1'%20opacity='.7'/%3e%3cpath%20d='M48%20167q-4%202%20-1%205q6%201%207%20-3'%20fill='none'%20stroke='%23a8a880'%20stroke-width='1'%20opacity='.7'/%3e%3cpath%20d='M61%20174q-4%202%20-1%205q6%201%207%20-3'%20fill='none'%20stroke='%23a8a880'%20stroke-width='1'%20opacity='.7'/%3e%3cpath%20d='M35%20181q-4%202%20-1%205q6%201%207%20-3'%20fill='none'%20stroke='%23a8a880'%20stroke-width='1'%20opacity='.7'/%3e%3cpath%20d='M48%20164q-4%202%20-1%205q6%201%207%20-3'%20fill='none'%20stroke='%23a8a880'%20stroke-width='1'%20opacity='.7'/%3e%3cpath%20d='M61%20171q-4%202%20-1%205q6%201%207%20-3'%20fill='none'%20stroke='%23a8a880'%20stroke-width='1'%20opacity='.7'/%3e%3cpath%20d='M35%20178q-4%202%20-1%205q6%201%207%20-3'%20fill='none'%20stroke='%23a8a880'%20stroke-width='1'%20opacity='.7'/%3e%3cpath%20d='M48%20161q-4%202%20-1%205q6%201%207%20-3'%20fill='none'%20stroke='%23a8a880'%20stroke-width='1'%20opacity='.7'/%3e%3cpath%20d='M61%20168q-4%202%20-1%205q6%201%207%20-3'%20fill='none'%20stroke='%23a8a880'%20stroke-width='1'%20opacity='.7'/%3e%3cpath%20d='M35%20175q-4%202%20-1%205q6%201%207%20-3'%20fill='none'%20stroke='%23a8a880'%20stroke-width='1'%20opacity='.7'/%3e%3cpath%20d='M48%20182q-4%202%20-1%205q6%201%207%20-3'%20fill='none'%20stroke='%23a8a880'%20stroke-width='1'%20opacity='.7'/%3e%3cpath%20d='M61%20165q-4%202%20-1%205q6%201%207%20-3'%20fill='none'%20stroke='%23a8a880'%20stroke-width='1'%20opacity='.7'/%3e%3cpath%20d='M35%20172q-4%202%20-1%205q6%201%207%20-3'%20fill='none'%20stroke='%23a8a880'%20stroke-width='1'%20opacity='.7'/%3e%3cpath%20d='M37%20179q-5%2013%20-9%2014'%20fill='none'%20stroke='%2353614b'%20stroke-width='1.7'/%3e%3cpath%20d='M41%20180q7%2013%2013%2014'%20fill='none'%20stroke='%2353614b'%20stroke-width='1.7'/%3e%3cpath%20d='M45%20179q-5%2013%20-9%2014'%20fill='none'%20stroke='%2353614b'%20stroke-width='1.7'/%3e%3cpath%20d='M49%20180q7%2013%2013%2014'%20fill='none'%20stroke='%2353614b'%20stroke-width='1.7'/%3e%3cpath%20d='M53%20179q-5%2013%20-9%2014'%20fill='none'%20stroke='%2353614b'%20stroke-width='1.7'/%3e%3cpath%20d='M57%20180q7%2013%2013%2014'%20fill='none'%20stroke='%2353614b'%20stroke-width='1.7'/%3e%3cpath%20d='M61%20179q-5%2013%20-9%2014'%20fill='none'%20stroke='%2353614b'%20stroke-width='1.7'/%3e%3cpath%20d='M65%20180q7%2013%2013%2014'%20fill='none'%20stroke='%2353614b'%20stroke-width='1.7'/%3e%3cpath%20d='M69%20179q-5%2013%20-9%2014'%20fill='none'%20stroke='%2353614b'%20stroke-width='1.7'/%3e%3cpath%20d='M73%20180q7%2013%2013%2014'%20fill='none'%20stroke='%2353614b'%20stroke-width='1.7'/%3e%3c/svg%3e%3c/g%3e%3c/svg%3e",
	"./assets/life-47.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='112'%20height='196'%20viewBox='0%200%20112%20196'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)'%3e%3csvg%20width='112'%20height='196'%20viewBox='0%200%20112%20196'%3e%3cdefs%3e%3cradialGradient%20id='jelly47'%20cx='.3'%20cy='.22'%3e%3cstop%20stop-color='%23e29195'/%3e%3cstop%20offset='.3'%20stop-color='%23bf5d89'/%3e%3cstop%20offset='.6'%20stop-color='%23a12c66'/%3e%3cstop%20offset='1'%20stop-color='%23552453'/%3e%3c/radialGradient%3e%3cradialGradient%20id='light47'%3e%3cstop%20stop-color='%23fff3ab'/%3e%3cstop%20offset='.45'%20stop-color='%23fcb65c'/%3e%3cstop%20offset='.72'%20stop-color='%23e77e58'/%3e%3cstop%20offset='1'%20stop-color='%23c2496b'/%3e%3c/radialGradient%3e%3c/defs%3e%3cpath%20d='M24%2092C54%20117%20-11%20138%2029%20154S74%20181%2041%20186'%20fill='none'%20stroke='%23743e78'%20stroke-width='3'%20stroke-linecap='round'/%3e%3cpath%20d='M32%2092C62%20117%20-3%20138%2037%20154S82%20181%2049%20186'%20fill='none'%20stroke='%23a0548b'%20stroke-width='1.8'%20stroke-linecap='round'/%3e%3cpath%20d='M40%2092C70%20117%205%20138%2045%20154S90%20181%2057%20186'%20fill='none'%20stroke='%23743e78'%20stroke-width='3'%20stroke-linecap='round'/%3e%3cpath%20d='M48%2092C78%20117%2013%20138%2053%20154S98%20181%2065%20186'%20fill='none'%20stroke='%23a0548b'%20stroke-width='1.8'%20stroke-linecap='round'/%3e%3cpath%20d='M56%2092C86%20117%2021%20138%2061%20154S106%20181%2073%20186'%20fill='none'%20stroke='%23743e78'%20stroke-width='3'%20stroke-linecap='round'/%3e%3cpath%20d='M64%2092C94%20117%2029%20138%2069%20154S114%20181%2081%20186'%20fill='none'%20stroke='%23a0548b'%20stroke-width='1.8'%20stroke-linecap='round'/%3e%3cpath%20d='M72%2092C102%20117%2037%20138%2077%20154S122%20181%2089%20186'%20fill='none'%20stroke='%23743e78'%20stroke-width='3'%20stroke-linecap='round'/%3e%3cpath%20d='M80%2092C110%20117%2045%20138%2085%20154S130%20181%2097%20186'%20fill='none'%20stroke='%23a0548b'%20stroke-width='1.8'%20stroke-linecap='round'/%3e%3cpath%20d='M88%2092C118%20117%2053%20138%2093%20154S138%20181%20105%20186'%20fill='none'%20stroke='%23743e78'%20stroke-width='3'%20stroke-linecap='round'/%3e%3cpath%20d='M16%2041Q16%2010%2055%2010Q92%208%20101%2042Q111%2078%2084%20100Q63%20117%2032%2096Q10%2082%2016%2041Z'%20fill='url(%23jelly47)'%20stroke='%23943c74'%20stroke-width='1.6'/%3e%3cellipse%20cx='35'%20cy='31'%20rx='7.2'%20ry='9'%20transform='rotate(-22%2035%2031)'%20fill='url(%23light47)'%20stroke='%23f18c75'%20stroke-width='1.2'/%3e%3cellipse%20cx='69'%20cy='22'%20rx='6.4'%20ry='8'%20transform='rotate(-22%2069%2022)'%20fill='url(%23light47)'%20stroke='%23f18c75'%20stroke-width='1.2'/%3e%3cellipse%20cx='88'%20cy='43'%20rx='5.6000000000000005'%20ry='7'%20transform='rotate(-22%2088%2043)'%20fill='url(%23light47)'%20stroke='%23f18c75'%20stroke-width='1.2'/%3e%3cellipse%20cx='31'%20cy='66'%20rx='7.2'%20ry='9'%20transform='rotate(-22%2031%2066)'%20fill='url(%23light47)'%20stroke='%23f18c75'%20stroke-width='1.2'/%3e%3cellipse%20cx='60'%20cy='55'%20rx='8'%20ry='10'%20transform='rotate(-22%2060%2055)'%20fill='url(%23light47)'%20stroke='%23f18c75'%20stroke-width='1.2'/%3e%3cellipse%20cx='83'%20cy='78'%20rx='6.4'%20ry='8'%20transform='rotate(-22%2083%2078)'%20fill='url(%23light47)'%20stroke='%23f18c75'%20stroke-width='1.2'/%3e%3cellipse%20cx='56'%20cy='90'%20rx='5.6000000000000005'%20ry='7'%20transform='rotate(-22%2056%2090)'%20fill='url(%23light47)'%20stroke='%23f18c75'%20stroke-width='1.2'/%3e%3cpath%20d='M46%20109Q39%20130%2064%20133Q84%20135%2093%20152Q90%20163%2073%20161Q51%20164%2043%20154'%20fill='none'%20stroke='%238a3276'%20stroke-width='4'%20stroke-linecap='round'/%3e%3cpath%20d='M42%20151Q65%20139%2092%20150Q88%20167%2061%20171Q43%20171%2042%20151Z'%20fill='%236e305f'%20stroke='%23c173a1'%20stroke-width='2'/%3e%3cpath%20d='M47%20151l1%208%203%20-8'%20fill='%23e6bfb6'%20stroke='%23793557'%20stroke-width='.5'/%3e%3cpath%20d='M52%20150l1%208%203%20-8'%20fill='%23e6bfb6'%20stroke='%23793557'%20stroke-width='.5'/%3e%3cpath%20d='M57%20149l1%208%203%20-8'%20fill='%23e6bfb6'%20stroke='%23793557'%20stroke-width='.5'/%3e%3cpath%20d='M62%20151l1%208%203%20-8'%20fill='%23e6bfb6'%20stroke='%23793557'%20stroke-width='.5'/%3e%3cpath%20d='M67%20150l1%208%203%20-8'%20fill='%23e6bfb6'%20stroke='%23793557'%20stroke-width='.5'/%3e%3cpath%20d='M72%20149l1%208%203%20-8'%20fill='%23e6bfb6'%20stroke='%23793557'%20stroke-width='.5'/%3e%3cpath%20d='M77%20151l1%208%203%20-8'%20fill='%23e6bfb6'%20stroke='%23793557'%20stroke-width='.5'/%3e%3cpath%20d='M82%20150l1%208%203%20-8'%20fill='%23e6bfb6'%20stroke='%23793557'%20stroke-width='.5'/%3e%3cpath%20d='M87%20149l1%208%203%20-8'%20fill='%23e6bfb6'%20stroke='%23793557'%20stroke-width='.5'/%3e%3c/svg%3e%3c/g%3e%3c/svg%3e",
	"./assets/organism-0.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='160'%20height='196'%20viewBox='0%200%20160%20196'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3csvg%20width='160'%20height='196'%20viewBox='0%20-8%20160%20155'%3e%3cg%20transform='rotate(-22%2080%2065)'%3e%3cpath%20d='M41%2027C60%209%2083%2018%2095%2039L116%2081C128%20104%20110%20128%2089%20118L49%2090C28%2076%2023%2044%2041%2027Z'%20fill='url(%23bac)'%20stroke='%233a7190'%20stroke-width='2.3'/%3e%3cpath%20d='M45%2034C60%2019%2077%2028%2086%2043L107%2082C117%20101%20104%20113%2089%20106L55%2082C39%2071%2032%2047%2045%2034Z'%20fill='%23a2d2d5'%20stroke='%23e4f4ed'%20stroke-width='2'/%3e%3cpath%20d='M67%2041Q48%2049%2068%2064T85%2090'%20stroke='%235184b0'%20stroke-width='5'%20fill='none'%20stroke-linecap='round'/%3e%3cpath%20d='M59%2047Q79%2048%2070%2062T90%2080'%20stroke='%23e9f1e6'%20stroke-width='2.5'%20fill='none'/%3e%3cpath%20d='M115%2069q14%200%2021%200'%20stroke='%23588da6'%20stroke-width='2'%20fill='none'/%3e%3cpath%20d='M109.50704155516199%2094.5q12.124355652982143%206.999999999999999%2018.186533479473212%206.499999999999999'%20stroke='%23588da6'%20stroke-width='2'%20fill='none'/%3e%3cpath%20d='M94.5%20113.16729559300637q7.000000000000002%2012.12435565298214%2010.500000000000002%2011.258330249197702'%20stroke='%23588da6'%20stroke-width='2'%20fill='none'/%3e%3cpath%20d='M74%20120q8.572527594031472e-16%2014%201.2858791391047208e-15%2013'%20stroke='%23588da6'%20stroke-width='2'%20fill='none'/%3e%3cpath%20d='M53.500000000000014%20113.16729559300637q-6.9999999999999964%2012.124355652982143%20-10.499999999999995%2011.258330249197703'%20stroke='%23588da6'%20stroke-width='2'%20fill='none'/%3e%3cpath%20d='M38.49295844483801%2094.5q-12.124355652982143%206.999999999999999%20-18.186533479473212%206.499999999999999'%20stroke='%23588da6'%20stroke-width='2'%20fill='none'/%3e%3cpath%20d='M33%2069q-14%201.7145055188062944e-15%20-21%201.592040838891559e-15'%20stroke='%23588da6'%20stroke-width='2'%20fill='none'/%3e%3cpath%20d='M38.49295844483801%2043.500000000000014q-12.124355652982143%20-6.9999999999999964%20-18.186533479473216%20-6.4999999999999964'%20stroke='%23588da6'%20stroke-width='2'%20fill='none'/%3e%3cpath%20d='M53.499999999999986%2024.832704406993635q-7.000000000000006%20-12.124355652982139%20-10.500000000000009%20-11.2583302491977'%20stroke='%23588da6'%20stroke-width='2'%20fill='none'/%3e%3cpath%20d='M73.99999999999999%2018q-2.5717582782094417e-15%20-14%20-3.857637417314163e-15%20-13'%20stroke='%23588da6'%20stroke-width='2'%20fill='none'/%3e%3cpath%20d='M94.5%2024.832704406993635q7.000000000000002%20-12.12435565298214%2010.500000000000002%20-11.258330249197702'%20stroke='%23588da6'%20stroke-width='2'%20fill='none'/%3e%3cpath%20d='M109.50704155516198%2043.49999999999998q12.124355652982137%20-7.000000000000006%2018.186533479473205%20-6.500000000000005'%20stroke='%23588da6'%20stroke-width='2'%20fill='none'/%3e%3ccircle%20cx='83'%20cy='48'%20r='5'%20fill='%23e9e7b1'%20stroke='%237aa08b'%20stroke-width='1'/%3e%3ccircle%20cx='56'%20cy='67'%20r='5'%20fill='%237aa8c4'%20stroke='none'%20stroke-width='1'/%3e%3ccircle%20cx='95'%20cy='91'%20r='4'%20fill='%23edf0be'%20stroke='none'%20stroke-width='1'/%3e%3cpath%20d='M103%20116Q150%20123%20138%2091T152%2055'%20stroke='%234d839e'%20stroke-width='2.8'%20fill='none'/%3e%3c/g%3e%3c/svg%3e%3c/g%3e%3c/svg%3e",
	"./assets/organism-1.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='160'%20height='196'%20viewBox='0%200%20160%20196'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3csvg%20width='160'%20height='196'%20viewBox='0%20-8%20160%20155'%3e%3cpath%20d='M74%20108Q47%2096%2048%2075Q35%2083%2027%2077Q41%2065%2043%2056Q26%2057%2021%2046Q42%2050%2056%2040Q46%2062%2066%2072M88%20109Q113%2098%20109%2076Q126%2084%20136%2070Q114%2075%20110%2057Q130%2063%20140%2051Q123%2053%20112%2042Q94%2066%2087%2079'%20fill='url(%23leaf)'%20stroke='%233d6351'%20stroke-width='1.2'/%3e%3cpath%20d='M74%20115C62%2088%2084%2069%2076%2047Q65%2025%2048%2020M83%20100C94%2075%2080%2051%2095%2033Q108%2018%20122%2021'%20stroke='%2341654d'%20stroke-width='6'%20fill='none'%20stroke-linecap='round'/%3e%3cpath%20d='M74%20111C71%2088%2088%2073%2078%2048M84%2095Q91%2075%2086%2058'%20stroke='%23b3c383'%20stroke-width='1.8'%20fill='none'/%3e%3cpath%20d='M60%2094C47%20103%2054%20122%2067%20126Q77%20144%2091%20130Q111%20126%20105%20110Q102%2090%2083%2092Z'%20fill='url(%23root)'%20stroke='%233a5447'%20stroke-width='1.6'/%3e%3cpath%20d='M66%20124Q55%20139%2039%20133T22%20141M74%20129Q73%20146%2062%20144T51%20149M89%20130Q101%20143%20116%20134T143%20143M99%20122Q119%20122%20122%20132T136%20130'%20stroke='%234b624a'%20stroke-width='3'%20fill='none'%20stroke-linecap='round'/%3e%3cpath%20d='M63%20105Q72%20111%2070%20123M80%20100Q87%20115%2081%20128M94%20105Q102%20114%2093%20125'%20stroke='%23b7b879'%20stroke-width='1.2'%20fill='none'/%3e%3cpath%20d='M75%2055C53%2054%2039%2044%2034%2028Q27%2015%2021%2014Q42%209%2051%2024Q57%2029%2061%2022Q63%2011%2057%203Q78%2010%2081%2026Q91%2017%2096%2018Q97%2039%2075%2055Z'%20fill='url(%23pod)'%20stroke='%2342584f'%20stroke-width='1.7'/%3e%3cpath%20d='M38%2026Q50%2039%2071%2040Q83%2038%2089%2027Q87%2047%2075%2049Q48%2048%2038%2026Z'%20fill='%234c354e'/%3e%3cpath%20d='M40%2027Q54%2035%2070%2036Q83%2035%2089%2026'%20fill='none'%20stroke='%23e7b4a9'%20stroke-width='2.2'/%3e%3cpath%20d='M47%2032L49%2039L54%2035M57%2036L61%2044L64%2037M72%2037L76%2043L80%2034'%20fill='%23d8d0a3'%20stroke='%23775a70'%20stroke-width='.6'/%3e%3cpath%20d='M27%2014Q33%207%2031%203M36%2018Q44%208%2040%204M48%2024Q55%2015%2050%2011M62%2022Q69%2014%2065%208M80%2028Q90%2023%2091%2016'%20fill='none'%20stroke='%23ba879a'%20stroke-width='1.7'%20stroke-linecap='round'/%3e%3cpath%20d='M102%2064Q95%2047%20106%2037Q111%2029%20111%2019Q131%2025%20128%2042Q124%2062%20110%2068Z'%20fill='url(%23pod)'%20stroke='%2342584f'%20stroke-width='1.5'/%3e%3cpath%20d='M106%2039Q118%2047%20124%2038M111%2048Q116%2054%20120%2049'%20stroke='%23c6a2ac'%20stroke-width='1.4'%20fill='none'/%3e%3cpath%20d='M43%2053L58%2072M30%2048L45%2052M112%2048L108%2068M124%2057L111%2059'%20stroke='%23c4d283'%20stroke-width='1'%20fill='none'/%3e%3cpath%20d='M55%2075Q42%2098%2031%20100Q46%2099%2064%2091M100%2082Q119%2092%20127%20107Q115%20105%2098%2094'%20fill='url(%23leaf)'%20stroke='%2353704c'%20stroke-width='1'/%3e%3c/svg%3e%3c/g%3e%3c/svg%3e",
	"./assets/organism-2.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='160'%20height='196'%20viewBox='0%200%20160%20196'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3csvg%20width='160'%20height='196'%20viewBox='0%20-8%20160%20155'%3e%3cpath%20d='M58%2071Q52%2086%2052%2098L35%20121L45%20125L63%20103L68%2078M94%2071L111%2091L114%20112L127%20118L132%20113L123%20107L121%2086L105%2068'%20fill='%23404663'%20stroke='%232b384e'%20stroke-width='1.2'/%3e%3cpath%20d='M42%2075Q14%2073%203%2040Q16%2053%2039%2053Q50%2053%2059%2044Q77%2033%2094%2040Q103%2043%20109%2047Q116%2040%20117%2029L115%2012Q124%2017%20128%2025Q139%2028%20147%2037L154%2041Q153%2047%20145%2049L131%2049Q126%2057%20124%2064Q122%2073%20113%2079L118%20102L110%20125L99%20125L103%20102Q95%2094%2089%2083Q79%2086%2072%2081L66%20100L48%20122L37%20119L53%2094L50%2079Z'%20fill='url(%23beast)'%20stroke='%23384259'%20stroke-width='1.6'/%3e%3cpath%20d='M62%2044Q67%2033%2069%2024L77%2035L84%2014L91%2036L101%2023L104%2043'%20fill='%239b6479'%20stroke='%23504761'%20stroke-width='1.1'/%3e%3cpath%20d='M70%2036L69%2027M85%2034L84%2019M99%2038L101%2027'%20stroke='%23dbbc98'%20stroke-width='1'/%3e%3cpath%20d='M109%2047Q104%2061%2094%2066Q79%2074%2054%2067Q69%2084%2088%2079Q98%2079%20104%2070Q103%2081%20108%2092L112%20102L105%20118'%20fill='none'%20stroke='%23bfb5aa'%20stroke-width='3'/%3e%3cpath%20d='M53%2077Q64%2072%2072%2078L61%2094L43%20118M117%2029L126%2039Q135%2043%20148%2041M127%2049L142%2045'%20stroke='%23dfbeaa'%20stroke-width='1.7'%20fill='none'/%3e%3cpath%20d='M96%2048Q88%2056%2092%2067M62%2051Q69%2052%2072%2057M73%2045Q78%2050%2081%2056M85%2045L89%2051M101%2051L101%2059'%20stroke='%23744662'%20stroke-width='2.1'%20fill='none'/%3e%3cpath%20d='M14%2051Q21%2066%2037%2066M54%2089L61%2093M107%2099L114%20103M49%20112L43%20112M106%20116L111%20116'%20stroke='%2393a5ac'%20stroke-width='1.4'%20fill='none'/%3e%3ccircle%20cx='132'%20cy='34'%20r='2'%20fill='%23e9d7a4'%20stroke='none'%20stroke-width='1'/%3e%3ccircle%20cx='132.5'%20cy='34'%20r='1'%20fill='%23283746'%20stroke='none'%20stroke-width='1'/%3e%3cpath%20d='M129%2030L136%2032M144%2037L146%2037M36%20122L41%20119L44%20124L48%20122M99%20127L104%20123L107%20127L111%20124'%20stroke='%23344057'%20stroke-width='1'%20fill='none'/%3e%3cpath%20d='M118%2024Q107%2012%20108%203Q119%207%20124%2021'%20fill='%239d697f'%20stroke='%23514761'%20stroke-width='1'/%3e%3c/svg%3e%3c/g%3e%3c/svg%3e",
	"./assets/planet-0.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cdefs%3e%3cclipPath%20id='orb0'%3e%3ccircle%20cx='50'%20cy='50'%20r='42'%20fill='white'%20stroke='none'%20stroke-width='1'/%3e%3c/clipPath%3e%3c/defs%3e%3ccircle%20cx='50'%20cy='50'%20r='47'%20opacity='.1'%20fill='%23edac62'%20stroke='none'%20stroke-width='1'/%3e%3ccircle%20cx='50'%20cy='50'%20r='42'%20fill='url(%23p0)'%20stroke='%23edac62'%20stroke-width='1'/%3e%3cg%20clip-path='url(%23orb0)'%3e%3cpath%20d='M9%2034L22%2021L29%2023L37%2012L50%2017L54%2029L44%2036L46%2045L31%2047L25%2059L10%2050ZM60%2026L81%2021L94%2043L80%2050L69%2040ZM42%2060L58%2052L73%2061L81%2082L63%2095L46%2088Z'%20fill='%236b4954'/%3e%3cpath%20d='M11%2049L26%2043L32%2029L38%2025M42%2012L40%2027L49%2032L44%2044L54%2057L47%2071L57%2088M76%2028L70%2040L79%2055L72%2071'%20fill='none'%20stroke='%23efb94d'%20stroke-width='2'/%3e%3cpath%20d='M16%2068Q28%2056%2030%2076T43%2093'%20stroke='%23eb8345'%20fill='none'%20stroke-width='3'/%3e%3cpath%20d='M9%2036Q20%2027%2035%2031T63%2031M18%2054Q33%2043%2046%2048M56%2065Q69%2059%2085%2066'%20fill='none'%20stroke='%23f7f6ed'%20stroke-width='1.5'%20opacity='.4'/%3e%3ccircle%20cx='50'%20cy='50'%20r='42'%20fill='url(%23limb)'%20stroke='none'%20stroke-width='1'/%3e%3c/g%3e%3cpath%20d='M20%2030Q30%2014%2048%2012'%20fill='none'%20stroke='%23e7fbf9'%20stroke-width='2.3'%20opacity='.7'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/planet-1.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cdefs%3e%3cclipPath%20id='orb2'%3e%3ccircle%20cx='50'%20cy='50'%20r='42'%20fill='white'%20stroke='none'%20stroke-width='1'/%3e%3c/clipPath%3e%3c/defs%3e%3ccircle%20cx='50'%20cy='50'%20r='47'%20opacity='.1'%20fill='%238dc3a9'%20stroke='none'%20stroke-width='1'/%3e%3ccircle%20cx='50'%20cy='50'%20r='42'%20fill='url(%23p1)'%20stroke='%238dc3a9'%20stroke-width='1'/%3e%3cg%20clip-path='url(%23orb2)'%3e%3cpath%20d='M13%2029Q20%2017%2029%2018Q34%2023%2039%2021Q48%2010%2052%2019L56%2027Q56%2034%2047%2038Q50%2041%2053%2043Q57%2054%2048%2053L36%2049Q31%2054%2029%2064Q20%2070%2018%2061L22%2048Q9%2044%2013%2029ZM61%2014Q70%209%2077%2017L78%2028Q91%2029%2086%2036Q85%2044%2078%2043L65%2037Q55%2028%2061%2014ZM54%2057Q64%2050%2070%2056Q79%2062%2078%2069L69%2077Q69%2090%2062%2091L51%2086Q42%2078%2045%2070Z'%20fill='%238aab57'%20stroke='%23bbc97f'%20stroke-width='.75'/%3e%3cpath%20d='M27%2021Q32%2026%2038%2029L30%2038L37%2044M61%2060Q56%2069%2063%2080M68%2023Q63%2030%2072%2035'%20stroke='%234e7951'%20stroke-width='2'%20fill='none'/%3e%3cpath%20d='M17%2034Q22%2025%2029%2027M51%2069Q57%2058%2065%2061'%20stroke='%23c1ce8a'%20stroke-width='1.3'%20fill='none'/%3e%3cpath%20d='M9%2036Q20%2027%2035%2031T63%2031M18%2054Q33%2043%2046%2048M56%2065Q69%2059%2085%2066'%20fill='none'%20stroke='%23f7f6ed'%20stroke-width='1.5'%20opacity='.4'/%3e%3ccircle%20cx='50'%20cy='50'%20r='42'%20fill='url(%23limb)'%20stroke='none'%20stroke-width='1'/%3e%3c/g%3e%3cpath%20d='M20%2030Q30%2014%2048%2012'%20fill='none'%20stroke='%23e7fbf9'%20stroke-width='2.3'%20opacity='.7'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/planet-2.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cdefs%3e%3cclipPath%20id='orb4'%3e%3ccircle%20cx='50'%20cy='50'%20r='42'%20fill='white'%20stroke='none'%20stroke-width='1'/%3e%3c/clipPath%3e%3c/defs%3e%3ccircle%20cx='50'%20cy='50'%20r='47'%20opacity='.1'%20fill='%2380cee7'%20stroke='none'%20stroke-width='1'/%3e%3ccircle%20cx='50'%20cy='50'%20r='42'%20fill='url(%23p2)'%20stroke='%2380cee7'%20stroke-width='1'/%3e%3cg%20clip-path='url(%23orb4)'%3e%3cpath%20d='M8%2034Q28%2019%2047%2034T93%2033M3%2044Q29%2037%2054%2046T96%2042M7%2073Q30%2052%2053%2067T97%2063'%20stroke='%23bce9e1'%20stroke-width='4'%20opacity='.63'%20fill='none'/%3e%3cpath%20d='M22%2012L39%2014L43%2024L32%2029L20%2024ZM61%2052L77%2053L84%2069L73%2085L61%2075Z'%20fill='%23e4eee0'%20opacity='.7'/%3e%3cpath%20d='M9%2036Q20%2027%2035%2031T63%2031M18%2054Q33%2043%2046%2048M56%2065Q69%2059%2085%2066'%20fill='none'%20stroke='%23f7f6ed'%20stroke-width='1.5'%20opacity='.4'/%3e%3ccircle%20cx='50'%20cy='50'%20r='42'%20fill='url(%23limb)'%20stroke='none'%20stroke-width='1'/%3e%3c/g%3e%3cpath%20d='M20%2030Q30%2014%2048%2012'%20fill='none'%20stroke='%23e7fbf9'%20stroke-width='2.3'%20opacity='.7'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/planet-3.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cdefs%3e%3cclipPath%20id='orb6'%3e%3ccircle%20cx='50'%20cy='50'%20r='42'%20fill='white'%20stroke='none'%20stroke-width='1'/%3e%3c/clipPath%3e%3c/defs%3e%3ccircle%20cx='50'%20cy='50'%20r='47'%20opacity='.1'%20fill='%23b79be3'%20stroke='none'%20stroke-width='1'/%3e%3ccircle%20cx='50'%20cy='50'%20r='42'%20fill='url(%23p3)'%20stroke='%23b79be3'%20stroke-width='1'/%3e%3cg%20clip-path='url(%23orb6)'%3e%3cpath%20d='M3%2026Q19%2013%2040%2029T84%2024M7%2040Q29%2028%2047%2045T98%2036M8%2059Q35%2039%2054%2059T96%2055M19%2078Q44%2055%2063%2078T90%2074'%20fill='none'%20stroke='%23ac77ba'%20stroke-width='7'%20opacity='.65'/%3e%3cpath%20d='M16%2038L32%2035L43%2045L57%2042L65%2051L83%2046M25%2067L39%2062L49%2068L62%2064'%20stroke='%23d1acd9'%20stroke-width='1'%20fill='none'/%3e%3cpath%20d='M9%2036Q20%2027%2035%2031T63%2031M18%2054Q33%2043%2046%2048M56%2065Q69%2059%2085%2066'%20fill='none'%20stroke='%23f7f6ed'%20stroke-width='1.5'%20opacity='.4'/%3e%3ccircle%20cx='50'%20cy='50'%20r='42'%20fill='url(%23limb)'%20stroke='none'%20stroke-width='1'/%3e%3c/g%3e%3cpath%20d='M20%2030Q30%2014%2048%2012'%20fill='none'%20stroke='%23e7fbf9'%20stroke-width='2.3'%20opacity='.7'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/star-0.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cdefs%3e%3cclipPath%20id='orb1'%3e%3ccircle%20cx='50'%20cy='50'%20r='42'%20fill='white'%20stroke='none'%20stroke-width='1'/%3e%3c/clipPath%3e%3c/defs%3e%3ccircle%20cx='50'%20cy='50'%20r='47'%20opacity='.1'%20fill='%23ed6547'%20stroke='none'%20stroke-width='1'/%3e%3ccircle%20cx='50'%20cy='50'%20r='43'%20fill='url(%23red)'%20stroke='%23ed6547'%20stroke-width='1.5'/%3e%3cg%20clip-path='url(%23orb1)'%20fill='none'%20stroke='%23f5ba58'%20stroke-width='.8'%20opacity='0.43'%3e%3cpath%20d='M6%207q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M23.7%2036.1q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M41.4%2065.2q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M59.099999999999994%209.300000000000011q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M76.8%2038.400000000000006q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M14.5%2067.5q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M32.19999999999999%2011.600000000000023q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M49.89999999999999%2040.70000000000002q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M67.6%2069.80000000000001q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M85.29999999999998%2013.900000000000034q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M23%2043q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M40.69999999999999%2072.10000000000002q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M58.39999999999998%2016.200000000000045q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M76.1%2045.30000000000001q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M13.799999999999983%2074.40000000000003q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M31.5%2018.5q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M49.19999999999999%2047.60000000000002q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M66.89999999999998%2076.70000000000005q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M84.59999999999997%2020.800000000000068q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M22.30000000000001%2049.89999999999998q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M40%2079q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M57.69999999999999%2023.100000000000023q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M75.39999999999998%2052.200000000000045q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M13.099999999999966%2081.30000000000007q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M30.799999999999955%2025.40000000000009q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M48.5%2054.5q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M66.19999999999999%2083.60000000000002q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M83.89999999999998%2027.700000000000045q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M21.599999999999966%2056.80000000000007q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M39.299999999999955%2085.90000000000009q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M57%2030q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M74.69999999999993%2059.10000000000002q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M12.399999999999977%2088.20000000000005q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M30.100000000000023%2032.30000000000007q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M47.799999999999955%2061.40000000000009q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M65.5%2090.5q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M83.19999999999993%2034.600000000000136q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M15%2052Q27%2031%2042%2046T76%2036M25%2070Q38%2049%2057%2067T85%2056M27%2020Q40%2039%2060%2025M52%2083Q61%2066%2079%2075'%20stroke-width='1.2'/%3e%3c/g%3e%3cpath%20d='M30%208Q25%200%2036%205'%20stroke='%23ed6547'%20fill='none'%20stroke-width='.8'%20transform='rotate(0%2050%2050)'/%3e%3cpath%20d='M35%208Q30%200%2041%205'%20stroke='%23ed6547'%20fill='none'%20stroke-width='.8'%20transform='rotate(69%2050%2050)'/%3e%3cpath%20d='M40%208Q35%200%2046%205'%20stroke='%23ed6547'%20fill='none'%20stroke-width='.8'%20transform='rotate(138%2050%2050)'/%3e%3cpath%20d='M45%208Q40%200%2051%205'%20stroke='%23ed6547'%20fill='none'%20stroke-width='.8'%20transform='rotate(207%2050%2050)'/%3e%3cpath%20d='M50%208Q45%200%2056%205'%20stroke='%23ed6547'%20fill='none'%20stroke-width='.8'%20transform='rotate(276%2050%2050)'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/star-1.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cdefs%3e%3cclipPath%20id='orb3'%3e%3ccircle%20cx='50'%20cy='50'%20r='42'%20fill='white'%20stroke='none'%20stroke-width='1'/%3e%3c/clipPath%3e%3c/defs%3e%3ccircle%20cx='50'%20cy='50'%20r='47'%20opacity='.1'%20fill='%23f7d957'%20stroke='none'%20stroke-width='1'/%3e%3ccircle%20cx='50'%20cy='50'%20r='43'%20fill='url(%23yellow)'%20stroke='%23f7d957'%20stroke-width='1.5'/%3e%3cg%20clip-path='url(%23orb3)'%20fill='none'%20stroke='%23f5ba58'%20stroke-width='.8'%20opacity='0.43'%3e%3cpath%20d='M6%207q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M23.7%2036.1q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M41.4%2065.2q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M59.099999999999994%209.300000000000011q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M76.8%2038.400000000000006q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M14.5%2067.5q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M32.19999999999999%2011.600000000000023q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M49.89999999999999%2040.70000000000002q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M67.6%2069.80000000000001q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M85.29999999999998%2013.900000000000034q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M23%2043q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M40.69999999999999%2072.10000000000002q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M58.39999999999998%2016.200000000000045q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M76.1%2045.30000000000001q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M13.799999999999983%2074.40000000000003q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M31.5%2018.5q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M49.19999999999999%2047.60000000000002q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M66.89999999999998%2076.70000000000005q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M84.59999999999997%2020.800000000000068q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M22.30000000000001%2049.89999999999998q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M40%2079q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M57.69999999999999%2023.100000000000023q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M75.39999999999998%2052.200000000000045q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M13.099999999999966%2081.30000000000007q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M30.799999999999955%2025.40000000000009q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M48.5%2054.5q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M66.19999999999999%2083.60000000000002q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M83.89999999999998%2027.700000000000045q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M21.599999999999966%2056.80000000000007q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M39.299999999999955%2085.90000000000009q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M57%2030q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M74.69999999999993%2059.10000000000002q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M12.399999999999977%2088.20000000000005q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M30.100000000000023%2032.30000000000007q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M47.799999999999955%2061.40000000000009q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M65.5%2090.5q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M83.19999999999993%2034.600000000000136q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M15%2052Q27%2031%2042%2046T76%2036M25%2070Q38%2049%2057%2067T85%2056M27%2020Q40%2039%2060%2025M52%2083Q61%2066%2079%2075'%20stroke-width='1.2'/%3e%3c/g%3e%3cpath%20d='M30%208Q25%200%2036%205'%20stroke='%23f7d957'%20fill='none'%20stroke-width='.8'%20transform='rotate(0%2050%2050)'/%3e%3cpath%20d='M35%208Q30%200%2041%205'%20stroke='%23f7d957'%20fill='none'%20stroke-width='.8'%20transform='rotate(69%2050%2050)'/%3e%3cpath%20d='M40%208Q35%200%2046%205'%20stroke='%23f7d957'%20fill='none'%20stroke-width='.8'%20transform='rotate(138%2050%2050)'/%3e%3cpath%20d='M45%208Q40%200%2051%205'%20stroke='%23f7d957'%20fill='none'%20stroke-width='.8'%20transform='rotate(207%2050%2050)'/%3e%3cpath%20d='M50%208Q45%200%2056%205'%20stroke='%23f7d957'%20fill='none'%20stroke-width='.8'%20transform='rotate(276%2050%2050)'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/star-2.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cdefs%3e%3cclipPath%20id='orb5'%3e%3ccircle%20cx='50'%20cy='50'%20r='42'%20fill='white'%20stroke='none'%20stroke-width='1'/%3e%3c/clipPath%3e%3c/defs%3e%3ccircle%20cx='50'%20cy='50'%20r='47'%20opacity='.1'%20fill='%23d7f6ff'%20stroke='none'%20stroke-width='1'/%3e%3ccircle%20cx='50'%20cy='50'%20r='43'%20fill='url(%23white)'%20stroke='%23d7f6ff'%20stroke-width='1.5'/%3e%3cg%20clip-path='url(%23orb5)'%20fill='none'%20stroke='%23b3e5fb'%20stroke-width='.8'%20opacity='0.28'%3e%3cpath%20d='M6%207q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M23.7%2036.1q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M41.4%2065.2q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M59.099999999999994%209.300000000000011q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M76.8%2038.400000000000006q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M14.5%2067.5q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M32.19999999999999%2011.600000000000023q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M49.89999999999999%2040.70000000000002q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M67.6%2069.80000000000001q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M85.29999999999998%2013.900000000000034q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M23%2043q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M40.69999999999999%2072.10000000000002q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M58.39999999999998%2016.200000000000045q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M76.1%2045.30000000000001q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M13.799999999999983%2074.40000000000003q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M31.5%2018.5q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M49.19999999999999%2047.60000000000002q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M66.89999999999998%2076.70000000000005q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M84.59999999999997%2020.800000000000068q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M22.30000000000001%2049.89999999999998q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M40%2079q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M57.69999999999999%2023.100000000000023q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M75.39999999999998%2052.200000000000045q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M13.099999999999966%2081.30000000000007q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M30.799999999999955%2025.40000000000009q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M48.5%2054.5q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M66.19999999999999%2083.60000000000002q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M83.89999999999998%2027.700000000000045q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M21.599999999999966%2056.80000000000007q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M39.299999999999955%2085.90000000000009q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M57%2030q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M74.69999999999993%2059.10000000000002q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M12.399999999999977%2088.20000000000005q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M30.100000000000023%2032.30000000000007q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M47.799999999999955%2061.40000000000009q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M65.5%2090.5q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M83.19999999999993%2034.600000000000136q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M15%2052Q27%2031%2042%2046T76%2036M25%2070Q38%2049%2057%2067T85%2056M27%2020Q40%2039%2060%2025M52%2083Q61%2066%2079%2075'%20stroke-width='1.2'/%3e%3c/g%3e%3cpath%20d='M30%208Q25%200%2036%205'%20stroke='%23d7f6ff'%20fill='none'%20stroke-width='.8'%20transform='rotate(0%2050%2050)'/%3e%3cpath%20d='M35%208Q30%200%2041%205'%20stroke='%23d7f6ff'%20fill='none'%20stroke-width='.8'%20transform='rotate(69%2050%2050)'/%3e%3cpath%20d='M40%208Q35%200%2046%205'%20stroke='%23d7f6ff'%20fill='none'%20stroke-width='.8'%20transform='rotate(138%2050%2050)'/%3e%3cpath%20d='M45%208Q40%200%2051%205'%20stroke='%23d7f6ff'%20fill='none'%20stroke-width='.8'%20transform='rotate(207%2050%2050)'/%3e%3cpath%20d='M50%208Q45%200%2056%205'%20stroke='%23d7f6ff'%20fill='none'%20stroke-width='.8'%20transform='rotate(276%2050%2050)'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/star-3.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='100'%20height='100'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3clinearGradient%20id='space'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23080f27'/%3e%3cstop%20offset='.47'%20stop-color='%2324225a'/%3e%3cstop%20offset='1'%20stop-color='%23070e26'/%3e%3c/linearGradient%3e%3clinearGradient%20id='metal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23fbfcf6'/%3e%3cstop%20offset='.35'%20stop-color='%23dce2e4'/%3e%3cstop%20offset='.58'%20stop-color='%23c1cbd1'/%3e%3cstop%20offset='.82'%20stop-color='%23f1f1e8'/%3e%3cstop%20offset='1'%20stop-color='%23aab7c2'/%3e%3c/linearGradient%3e%3clinearGradient%20id='plate'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23213151'/%3e%3cstop%20offset='1'%20stop-color='%23151b3c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='gold'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23fff0b3'/%3e%3cstop%20offset='.4'%20stop-color='%23d5af50'/%3e%3cstop%20offset='1'%20stop-color='%2392713c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='evolution'%3e%3cstop%20stop-color='%23753243'/%3e%3cstop%20offset='.29'%20stop-color='%23b66d37'/%3e%3cstop%20offset='.54'%20stop-color='%23b2a477'/%3e%3cstop%20offset='.7'%20stop-color='%239db8c7'/%3e%3cstop%20offset='1'%20stop-color='%233465a3'/%3e%3c/linearGradient%3e%3cradialGradient%20id='cloud'%3e%3cstop%20stop-color='%235963aa'%20stop-opacity='.2'/%3e%3cstop%20offset='.46'%20stop-color='%235e4290'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='%23252d66'%20stop-opacity='0'/%3e%3c/radialGradient%3e%3cradialGradient%20id='limb'%20cx='.27'%20cy='.24'%3e%3cstop%20offset='.3'%20stop-color='%23eaf2d1'%20stop-opacity='.05'/%3e%3cstop%20offset='.75'%20stop-color='%23101328'%20stop-opacity='.05'/%3e%3cstop%20offset='1'%20stop-color='%23080c23'%20stop-opacity='.7'/%3e%3c/radialGradient%3e%3cradialGradient%20id='red'%3e%3cstop%20stop-color='%23f46c3a'/%3e%3cstop%20offset='.55'%20stop-color='%23bd2228'/%3e%3cstop%20offset='.86'%20stop-color='%23831e30'/%3e%3cstop%20offset='1'%20stop-color='%23f55337'/%3e%3c/radialGradient%3e%3cradialGradient%20id='yellow'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fff7a8'/%3e%3cstop%20offset='.48'%20stop-color='%23ffd536'/%3e%3cstop%20offset='.9'%20stop-color='%23d79018'/%3e%3cstop%20offset='1'%20stop-color='%23f8ec93'/%3e%3c/radialGradient%3e%3cradialGradient%20id='white'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%23fffef4'/%3e%3cstop%20offset='.65'%20stop-color='%23daeafa'/%3e%3cstop%20offset='1'%20stop-color='%2387c7ec'/%3e%3c/radialGradient%3e%3cradialGradient%20id='blue'%20cx='.37'%20cy='.28'%3e%3cstop%20stop-color='%2368d9f4'/%3e%3cstop%20offset='.45'%20stop-color='%233697df'/%3e%3cstop%20offset='.85'%20stop-color='%23123d90'/%3e%3cstop%20offset='1'%20stop-color='%2382dfff'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p0'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23ffdc8b'/%3e%3cstop%20offset='.42'%20stop-color='%23cb733b'/%3e%3cstop%20offset='.76'%20stop-color='%23733d3c'/%3e%3cstop%20offset='1'%20stop-color='%231a2039'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p1'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23aed9be'/%3e%3cstop%20offset='.37'%20stop-color='%23297a83'/%3e%3cstop%20offset='.77'%20stop-color='%23143e61'/%3e%3cstop%20offset='1'%20stop-color='%23101c32'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p2'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d1f5ed'/%3e%3cstop%20offset='.38'%20stop-color='%23348dae'/%3e%3cstop%20offset='.76'%20stop-color='%231d486a'/%3e%3cstop%20offset='1'%20stop-color='%23111b37'/%3e%3c/radialGradient%3e%3cradialGradient%20id='p3'%20cx='.28'%20cy='.24'%3e%3cstop%20stop-color='%23d5b5eb'/%3e%3cstop%20offset='.35'%20stop-color='%238155af'/%3e%3cstop%20offset='.76'%20stop-color='%233f2a76'/%3e%3cstop%20offset='1'%20stop-color='%23151b36'/%3e%3c/radialGradient%3e%3clinearGradient%20id='bac'%20x2='1'%20y2='1'%3e%3cstop%20stop-color='%23f7ffff'/%3e%3cstop%20offset='.4'%20stop-color='%23b5dfe7'/%3e%3cstop%20offset='1'%20stop-color='%23568bba'/%3e%3c/linearGradient%3e%3clinearGradient%20id='leaf'%20x2='1'%20y2='.2'%3e%3cstop%20stop-color='%232b7774'/%3e%3cstop%20offset='.5'%20stop-color='%236ba94f'/%3e%3cstop%20offset='1'%20stop-color='%23d7dc6e'/%3e%3c/linearGradient%3e%3clinearGradient%20id='beast'%20x2='.2'%20y2='1'%3e%3cstop%20stop-color='%23c99978'/%3e%3cstop%20offset='.33'%20stop-color='%23a15f6a'/%3e%3cstop%20offset='.68'%20stop-color='%236d476b'/%3e%3cstop%20offset='1'%20stop-color='%23344569'/%3e%3c/linearGradient%3e%3cradialGradient%20id='pod'%20cx='.35'%20cy='.2'%3e%3cstop%20stop-color='%23ddafa4'/%3e%3cstop%20offset='.3'%20stop-color='%23ae6d80'/%3e%3cstop%20offset='.7'%20stop-color='%23673c63'/%3e%3cstop%20offset='1'%20stop-color='%23324d55'/%3e%3c/radialGradient%3e%3clinearGradient%20id='root'%20x2='.6'%20y2='1'%3e%3cstop%20stop-color='%23a8b974'/%3e%3cstop%20offset='.45'%20stop-color='%236b8950'/%3e%3cstop%20offset='1'%20stop-color='%23364d45'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card0'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23c9e6ee'/%3e%3cstop%20offset='1'%20stop-color='%238bbcc9'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card1'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23e0e9a9'/%3e%3cstop%20offset='1'%20stop-color='%238ba84c'/%3e%3c/linearGradient%3e%3clinearGradient%20id='card2'%20x2='.5'%20y2='1'%3e%3cstop%20stop-color='%23f2e4ba'/%3e%3cstop%20offset='1'%20stop-color='%23c5a568'/%3e%3c/linearGradient%3e%3c/defs%3e%3cdefs%3e%3clinearGradient%20id='symHeat'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23ffce39'/%3e%3cstop%20offset='1'%20stop-color='%23f19d16'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symCarbon'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2399c53b'/%3e%3cstop%20offset='1'%20stop-color='%235b9f35'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symWater'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%2345c5ed'/%3e%3cstop%20offset='1'%20stop-color='%23168dce'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symRadiation'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a48bc2'/%3e%3cstop%20offset='1'%20stop-color='%2359449d'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symBacteria'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23b2d9e7'/%3e%3cstop%20offset='1'%20stop-color='%236293a4'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symPlant'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23a1ce42'/%3e%3cstop%20offset='1'%20stop-color='%2365a636'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symAnimal'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23d1bc7d'/%3e%3cstop%20offset='1'%20stop-color='%23ac955a'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symMass'%20x2='.1'%20y2='1'%3e%3cstop%20stop-color='%23313131'/%3e%3cstop%20offset='.5'%20stop-color='%23080808'/%3e%3cstop%20offset='1'%20stop-color='%23050505'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVp'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23b7c4c6'/%3e%3cstop%20offset='.5'%20stop-color='%23718485'/%3e%3cstop%20offset='1'%20stop-color='%23526365'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symVpEnd'%20x2='1'%20y2='.5'%3e%3cstop%20stop-color='%23d5b363'/%3e%3cstop%20offset='.5'%20stop-color='%23b79245'/%3e%3cstop%20offset='1'%20stop-color='%238b6e36'/%3e%3c/linearGradient%3e%3clinearGradient%20id='symLife'%20x2='1'%20y2='0'%3e%3cstop%20stop-color='%2390cad9'/%3e%3cstop%20offset='.32'%20stop-color='%2380b5c3'/%3e%3cstop%20offset='.34'%20stop-color='%23a1c451'/%3e%3cstop%20offset='.65'%20stop-color='%2383ad3f'/%3e%3cstop%20offset='.67'%20stop-color='%23c7b26f'/%3e%3cstop%20offset='1'%20stop-color='%23c0a961'/%3e%3c/linearGradient%3e%3cradialGradient%20id='symGlobe'%20cx='.35'%20cy='.3'%3e%3cstop%20stop-color='%2370cde8'/%3e%3cstop%20offset='.65'%20stop-color='%232c98c6'/%3e%3cstop%20offset='1'%20stop-color='%235859a3'/%3e%3c/radialGradient%3e%3c/defs%3e%3cg%20transform='translate(0%200)%20scale(1)'%3e%3cdefs%3e%3cclipPath%20id='orb7'%3e%3ccircle%20cx='50'%20cy='50'%20r='42'%20fill='white'%20stroke='none'%20stroke-width='1'/%3e%3c/clipPath%3e%3c/defs%3e%3ccircle%20cx='50'%20cy='50'%20r='47'%20opacity='.1'%20fill='%2382dcfc'%20stroke='none'%20stroke-width='1'/%3e%3ccircle%20cx='50'%20cy='50'%20r='43'%20fill='url(%23blue)'%20stroke='%2382dcfc'%20stroke-width='1.5'/%3e%3cg%20clip-path='url(%23orb7)'%20fill='none'%20stroke='%23b3e5fb'%20stroke-width='.8'%20opacity='0.43'%3e%3cpath%20d='M6%207q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M23.7%2036.1q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M41.4%2065.2q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M59.099999999999994%209.300000000000011q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M76.8%2038.400000000000006q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M14.5%2067.5q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M32.19999999999999%2011.600000000000023q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M49.89999999999999%2040.70000000000002q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M67.6%2069.80000000000001q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M85.29999999999998%2013.900000000000034q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M23%2043q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M40.69999999999999%2072.10000000000002q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M58.39999999999998%2016.200000000000045q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M76.1%2045.30000000000001q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M13.799999999999983%2074.40000000000003q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M31.5%2018.5q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M49.19999999999999%2047.60000000000002q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M66.89999999999998%2076.70000000000005q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M84.59999999999997%2020.800000000000068q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M22.30000000000001%2049.89999999999998q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M40%2079q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M57.69999999999999%2023.100000000000023q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M75.39999999999998%2052.200000000000045q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M13.099999999999966%2081.30000000000007q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M30.799999999999955%2025.40000000000009q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M48.5%2054.5q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M66.19999999999999%2083.60000000000002q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M83.89999999999998%2027.700000000000045q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M21.599999999999966%2056.80000000000007q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M39.299999999999955%2085.90000000000009q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M57%2030q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M74.69999999999993%2059.10000000000002q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M12.399999999999977%2088.20000000000005q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M30.100000000000023%2032.30000000000007q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M47.799999999999955%2061.40000000000009q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M65.5%2090.5q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M83.19999999999993%2034.600000000000136q2%20-5%206%20-3l4%204q-2%205%20-5%204l-5%20-2z'/%3e%3cpath%20d='M15%2052Q27%2031%2042%2046T76%2036M25%2070Q38%2049%2057%2067T85%2056M27%2020Q40%2039%2060%2025M52%2083Q61%2066%2079%2075'%20stroke-width='1.2'/%3e%3c/g%3e%3cpath%20d='M30%208Q25%200%2036%205'%20stroke='%2382dcfc'%20fill='none'%20stroke-width='.8'%20transform='rotate(0%2050%2050)'/%3e%3cpath%20d='M35%208Q30%200%2041%205'%20stroke='%2382dcfc'%20fill='none'%20stroke-width='.8'%20transform='rotate(69%2050%2050)'/%3e%3cpath%20d='M40%208Q35%200%2046%205'%20stroke='%2382dcfc'%20fill='none'%20stroke-width='.8'%20transform='rotate(138%2050%2050)'/%3e%3cpath%20d='M45%208Q40%200%2051%205'%20stroke='%2382dcfc'%20fill='none'%20stroke-width='.8'%20transform='rotate(207%2050%2050)'/%3e%3cpath%20d='M50%208Q45%200%2056%205'%20stroke='%2382dcfc'%20fill='none'%20stroke-width='.8'%20transform='rotate(276%2050%2050)'/%3e%3c/g%3e%3c/svg%3e",
	"./assets/starfield.svg": "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='1920'%20height='1080'%20viewBox='0%200%201920%201080'%3e%3ccircle%20cx='47'%20cy='29'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='420'%20cy='226'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='793'%20cy='423'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='1166'%20cy='620'%20r='1'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1539'%20cy='817'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1912'%20cy='1014'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='365'%20cy='131'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='738'%20cy='328'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1111'%20cy='525'%20r='1'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1484'%20cy='722'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='1857'%20cy='919'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='310'%20cy='36'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='683'%20cy='233'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1056'%20cy='430'%20r='1'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='1429'%20cy='627'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='1802'%20cy='824'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='255'%20cy='1021'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='628'%20cy='138'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='1001'%20cy='335'%20r='1'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='1374'%20cy='532'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1747'%20cy='729'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='200'%20cy='926'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='573'%20cy='43'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='946'%20cy='240'%20r='1'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1319'%20cy='437'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1692'%20cy='634'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='145'%20cy='831'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='518'%20cy='1028'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='891'%20cy='145'%20r='1'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1264'%20cy='342'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='1637'%20cy='539'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='90'%20cy='736'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='463'%20cy='933'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='836'%20cy='50'%20r='1'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='1209'%20cy='247'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='1582'%20cy='444'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='35'%20cy='641'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='408'%20cy='838'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='781'%20cy='1035'%20r='1'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='1154'%20cy='152'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1527'%20cy='349'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1900'%20cy='546'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='353'%20cy='743'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='726'%20cy='940'%20r='1'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1099'%20cy='57'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1472'%20cy='254'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='1845'%20cy='451'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='298'%20cy='648'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='671'%20cy='845'%20r='1'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1044'%20cy='1042'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='1417'%20cy='159'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='1790'%20cy='356'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='243'%20cy='553'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='616'%20cy='750'%20r='1'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='989'%20cy='947'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='1362'%20cy='64'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1735'%20cy='261'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='188'%20cy='458'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='561'%20cy='655'%20r='1'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='934'%20cy='852'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1307'%20cy='1049'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1680'%20cy='166'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='133'%20cy='363'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='506'%20cy='560'%20r='1'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='879'%20cy='757'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1252'%20cy='954'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='1625'%20cy='71'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='78'%20cy='268'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='451'%20cy='465'%20r='1'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='824'%20cy='662'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='1197'%20cy='859'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='1570'%20cy='1056'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='23'%20cy='173'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='396'%20cy='370'%20r='1'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='769'%20cy='567'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='1142'%20cy='764'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1515'%20cy='961'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1888'%20cy='78'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='341'%20cy='275'%20r='1'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='714'%20cy='472'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1087'%20cy='669'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1460'%20cy='866'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='1833'%20cy='1063'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='286'%20cy='180'%20r='1'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='659'%20cy='377'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1032'%20cy='574'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='1405'%20cy='771'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='1778'%20cy='968'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='231'%20cy='85'%20r='1'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='604'%20cy='282'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='977'%20cy='479'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='1350'%20cy='676'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1723'%20cy='873'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='176'%20cy='1070'%20r='1'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='549'%20cy='187'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='922'%20cy='384'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1295'%20cy='581'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1668'%20cy='778'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='121'%20cy='975'%20r='1'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='494'%20cy='92'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='867'%20cy='289'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1240'%20cy='486'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='1613'%20cy='683'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='66'%20cy='880'%20r='1'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='439'%20cy='1077'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='812'%20cy='194'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='1185'%20cy='391'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='1558'%20cy='588'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='11'%20cy='785'%20r='1'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='384'%20cy='982'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='757'%20cy='99'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='1130'%20cy='296'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1503'%20cy='493'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1876'%20cy='690'%20r='1'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='329'%20cy='887'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='702'%20cy='4'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1075'%20cy='201'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1448'%20cy='398'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='1821'%20cy='595'%20r='1'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='274'%20cy='792'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='647'%20cy='989'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1020'%20cy='106'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='1393'%20cy='303'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='1766'%20cy='500'%20r='1'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='219'%20cy='697'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='592'%20cy='894'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='965'%20cy='11'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='1338'%20cy='208'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1711'%20cy='405'%20r='1'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='164'%20cy='602'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='537'%20cy='799'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='910'%20cy='996'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1283'%20cy='113'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1656'%20cy='310'%20r='1'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='109'%20cy='507'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='482'%20cy='704'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='855'%20cy='901'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1228'%20cy='18'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='1601'%20cy='215'%20r='1'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='54'%20cy='412'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='427'%20cy='609'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='800'%20cy='806'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='1173'%20cy='1003'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='1546'%20cy='120'%20r='1'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1919'%20cy='317'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='372'%20cy='514'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='745'%20cy='711'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='1118'%20cy='908'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1491'%20cy='25'%20r='1'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1864'%20cy='222'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='317'%20cy='419'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='690'%20cy='616'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1063'%20cy='813'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1436'%20cy='1010'%20r='1'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='1809'%20cy='127'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='262'%20cy='324'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='635'%20cy='521'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1008'%20cy='718'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='1381'%20cy='915'%20r='1'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='1754'%20cy='32'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='207'%20cy='229'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='580'%20cy='426'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='953'%20cy='623'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='1326'%20cy='820'%20r='1'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1699'%20cy='1017'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='152'%20cy='134'%20r='0.45'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3ccircle%20cx='525'%20cy='331'%20r='0.6'%20fill='%23bacbdd'%20opacity='0.26'/%3e%3ccircle%20cx='898'%20cy='528'%20r='0.8'%20fill='%23bacbdd'%20opacity='0.32'/%3e%3ccircle%20cx='1271'%20cy='725'%20r='1'%20fill='%23bacbdd'%20opacity='0.12'/%3e%3ccircle%20cx='1644'%20cy='922'%20r='1.15'%20fill='%23bacbdd'%20opacity='0.18'/%3e%3c/svg%3e"
}), nt = (e) => tt[`./assets/${e}.svg`], rt = [
	"heat",
	"carbon",
	"water",
	"radiation"
], X = [
	"bacteria",
	"plant",
	"animal"
];
function Z({ name: e, size: t, label: n }) {
	return /* @__PURE__ */ m("img", {
		className: "entropy-icon",
		src: nt(`icon-${e}`),
		width: t,
		height: t,
		alt: n ?? "",
		"aria-hidden": !n,
		draggable: !1
	});
}
function it({ type: e = 0, star: t = !1, size: n = 64 }) {
	return /* @__PURE__ */ m("img", {
		className: "entropy-orb",
		src: nt(`${t ? "star" : "planet"}-${e}`),
		width: n,
		height: n,
		alt: "",
		draggable: !1
	});
}
var at = {
	"🔥": "heat",
	"⬡": "carbon",
	"💧": "water",
	"☢": "radiation",
	"🦠": "bacteria",
	"🌱": "plant",
	"🐾": "animal",
	"☀": "evolve",
	"🪐": "aggregate",
	"🧬": "life",
	"✨": "activate",
	"🌄": "biome",
	"▤": "draw",
	"⬆": "upgrade",
	"☄": "asteroid",
	"⚗": "soup",
	"⚡": "energy",
	"◼": "mass",
	"△": "entropy",
	"◆": "vp"
}, ot = /(🔥|⬡|💧|☢|🦠|🌱|🐾|☀|🪐|🧬|✨|🌄|▤|⬆|☄|⚗|⚡|◼|△|◆)/u;
function st({ children: e, m: t }) {
	let n = {
		...Object.fromEntries(rt.map((e, n) => [e, t.conditions[n]])),
		...Object.fromEntries(X.map((e, n) => [e, t.lifeTypes[n]])),
		...t.space,
		energy: t.resources[0],
		mass: t.resources[1],
		entropy: t.resources[2],
		vp: t.resources[3]
	};
	return /* @__PURE__ */ m(p, { children: e.split(ot).map((e, t) => at[e] ? /* @__PURE__ */ m(Z, {
		name: at[e],
		label: n[at[e]]
	}, t) : e) });
}
function ct({ color: e, name: t, avatar: n, ghost: r = !1 }) {
	return /* @__PURE__ */ h("span", {
		className: "entropy-pawn",
		style: { "--pawn-color": e },
		title: t,
		children: [/* @__PURE__ */ h("svg", {
			viewBox: "0 0 32 40",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ m("path", {
					d: "M7 15Q3 16 3 24V34H9L11 23V38H21V23L23 34H29V24Q29 16 25 15Z",
					fill: "var(--pawn-color)",
					stroke: "#edf1e8",
					strokeWidth: "1.2"
				}),
				/* @__PURE__ */ m("circle", {
					cx: "16",
					cy: "8",
					r: "6",
					fill: "var(--pawn-color)",
					stroke: "#edf1e8",
					strokeWidth: "1.4"
				}),
				/* @__PURE__ */ m("path", {
					d: "M11 6H21V10H11Z",
					fill: "#18314b"
				}),
				/* @__PURE__ */ m("path", {
					d: "M13 18H19V25H13Z",
					fill: "#edf1e8"
				})
			]
		}), /* @__PURE__ */ m("small", { children: r ? "👻" : /* @__PURE__ */ m("img", {
			src: n,
			alt: "",
			draggable: !1,
			style: {
				width: 12,
				height: 12,
				display: "block",
				objectFit: "contain",
				pointerEvents: "none"
			}
		}) })]
	});
}
//#endregion
//#region src/games/entropy/pieces.tsx
function lt({ values: e, m: t }) {
	return /* @__PURE__ */ m("span", {
		className: "entropy-conditions",
		children: e.map((e, n) => e > 0 && /* @__PURE__ */ h("span", {
			title: t.conditions[n],
			children: [/* @__PURE__ */ m("b", { children: e }), /* @__PURE__ */ m(Z, {
				name: rt[n],
				label: t.conditions[n]
			})]
		}, n))
	});
}
var ut = {
	activateOne: "activate",
	setOrFulfill: "biome",
	animalReward: "vp"
}, dt = (e) => ut[e.kind] ?? e.kind, ft = [
	[
		"entropy",
		1,
		2,
		["planet"],
		"="
	],
	[
		"plant",
		1,
		3,
		["fulfill"]
	],
	[
		"energy",
		1,
		2,
		["planet"],
		"≠"
	],
	[
		"bacteria",
		1,
		2,
		["planet", "carbon"]
	],
	[
		"",
		0,
		2,
		["star"],
		"≠"
	],
	[
		"entropy",
		1,
		3,
		["planet", "animal"]
	],
	[
		"energy",
		1,
		2,
		["draw"],
		"="
	],
	[
		"mass",
		1,
		2,
		["planet", "heat"]
	],
	[
		"bacteria",
		1,
		2,
		["biomeTile"]
	],
	[
		"plant",
		1,
		2,
		["upgrade"]
	],
	[
		"",
		0,
		3,
		["planet", "radiation"]
	],
	[
		"bacteria",
		1,
		2,
		["asteroidBody"],
		"="
	],
	[
		"",
		0,
		2,
		["planet", "water"]
	],
	[
		"mass",
		1,
		2,
		["generator"]
	],
	[
		"entropy",
		1,
		2,
		["planet", "bacteria"]
	],
	[
		"",
		0,
		1,
		["star"],
		"Ⅰ–Ⅳ"
	],
	[
		"entropy",
		1,
		2,
		["draw"]
	],
	[
		"mass",
		1,
		2,
		["asteroidBody"]
	],
	[
		"",
		0,
		1,
		["planet"]
	],
	[
		"",
		0,
		3,
		["planet", "plant"]
	],
	[
		"energy",
		1,
		3,
		["asteroidBody"],
		"≠"
	],
	[
		"",
		0,
		9,
		[]
	]
];
function pt({ n: e }) {
	return /* @__PURE__ */ h("span", {
		className: "entropy-score-glyph",
		children: [/* @__PURE__ */ m(Z, { name: "vp" }), /* @__PURE__ */ m("b", { children: e })]
	});
}
function mt({ effect: e }) {
	let t = ft[e.tag - 45];
	if (!t) return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m(pt, { n: e.n }),
		"×",
		/* @__PURE__ */ m(Z, { name: e.tag === 67 ? "star" : "draw" })
	] });
	let [n, r, i, a, o] = t;
	return /* @__PURE__ */ h(p, { children: [
		n && /* @__PURE__ */ h(p, { children: [
			/* @__PURE__ */ m("b", { children: r * e.n }),
			/* @__PURE__ */ m(Z, { name: n }),
			"·"
		] }),
		/* @__PURE__ */ m(pt, { n: i * e.n }),
		a.length > 0 && /* @__PURE__ */ h(p, { children: [
			"×",
			a.map((e, t) => /* @__PURE__ */ m(Z, { name: e }, t)),
			o && /* @__PURE__ */ m("small", { children: o })
		] })
	] });
}
function ht({ effects: e, m: t }) {
	return /* @__PURE__ */ m("span", {
		className: "entropy-effects",
		children: e.map((e, n) => /* @__PURE__ */ m("span", {
			role: "img",
			"aria-label": Y(e, t),
			title: Y(e, t),
			className: e.kind === "animalReward" ? "entropy-animal-effect" : void 0,
			children: e.kind === "animalReward" ? /* @__PURE__ */ m(mt, { effect: e }) : /* @__PURE__ */ h(p, { children: [
				e.kind === "vp" ? /* @__PURE__ */ m(pt, { n: e.n }) : /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("b", { children: e.n }), /* @__PURE__ */ m(Z, { name: dt(e) })] }),
				e.kind === "draw" && e.tag !== void 0 && /* @__PURE__ */ m(Z, { name: X[e.tag] }),
				e.kind === "advance" && e.tag !== void 0 && /* @__PURE__ */ h(p, { children: [
					/* @__PURE__ */ m(Z, { name: X[e.tag] }),
					"→",
					/* @__PURE__ */ m(Z, { name: X[e.tag + 1] })
				] }),
				e.tag === 1 && [
					"asteroid",
					"upgrade",
					"activateOne"
				].includes(e.kind) && /* @__PURE__ */ m("small", { children: t.free }),
				e.kind === "fulfill" && e.tag === 1 && /* @__PURE__ */ m("small", { children: t.abundant })
			] })
		}, n))
	});
}
function gt({ id: e, m: t, small: n = !1, onClick: r, selected: i = !1, available: a = !1 }) {
	let o = D[e - 1], s = `L${e} · ${t.lifeTypes[o.type]} · ${o.env.map((e, n) => e ? `${e} ${t.conditions[n]}` : "").filter(Boolean).join(", ")}${o.require ? ` · ${o.consume ? t.consume : t.need} ${o.require} ${t.lifeTypes[o.type - 1]}` : ""} · ${t.produce} ${o.yield} ${t.lifeTypes[o.type]} · ${o.effects.map((e) => Y(e, t)).join(" + ")}`, c = /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ m("img", {
			className: "entropy-organism",
			src: nt([
				11,
				31,
				47
			].includes(e) ? `life-${e}` : `organism-${o.type}`),
			alt: "",
			draggable: !1
		}),
		/* @__PURE__ */ m("span", {
			className: "entropy-card-shield",
			children: /* @__PURE__ */ m(Z, { name: "local" })
		}),
		/* @__PURE__ */ h("span", {
			className: "entropy-card-require",
			children: [/* @__PURE__ */ m(lt, {
				values: o.env,
				m: t
			}), o.require > 0 && /* @__PURE__ */ h("span", {
				"data-consume": o.consume,
				children: [/* @__PURE__ */ m("b", { children: o.require }), /* @__PURE__ */ m(Z, {
					name: X[o.type - 1],
					label: t.lifeTypes[o.type - 1]
				})]
			})]
		}),
		/* @__PURE__ */ h("span", {
			className: "entropy-card-yield",
			children: [
				/* @__PURE__ */ m("b", { children: o.yield }),
				/* @__PURE__ */ m(Z, {
					name: X[o.type],
					label: t.lifeTypes[o.type]
				}),
				/* @__PURE__ */ m(Z, { name: "local" })
			]
		}),
		/* @__PURE__ */ h("span", {
			className: "entropy-card-effect",
			children: [/* @__PURE__ */ m(ht, {
				effects: o.effects,
				m: t
			}), /* @__PURE__ */ h("span", {
				className: "entropy-card-id",
				children: ["L", e]
			})]
		}),
		i && /* @__PURE__ */ m("span", {
			className: "entropy-selected-mark",
			"aria-hidden": "true",
			children: "✓"
		})
	] }), l = {
		className: "entropy-life-card",
		"data-life": o.type,
		"data-small": n,
		"data-selected": i,
		"data-available": a,
		"aria-label": s
	};
	return r ? /* @__PURE__ */ m("button", {
		type: "button",
		onClick: r,
		...l,
		"aria-pressed": a ? i : void 0,
		children: c
	}) : /* @__PURE__ */ m("div", {
		...l,
		children: c
	});
}
function _t({ id: e, m: t, onClick: n }) {
	let r = k[e];
	return /* @__PURE__ */ h("button", {
		className: "entropy-market-planet",
		onClick: n,
		type: "button",
		"aria-label": `P${e + 1} · ${r.cost} ${t.resources[1]} · ${r.effects.map((e) => Y(e, t)).join(" + ")}`,
		children: [
			/* @__PURE__ */ m(it, {
				type: r.type,
				size: 58
			}),
			/* @__PURE__ */ h("span", {
				className: "entropy-planet-label",
				children: [
					"P",
					e + 1,
					r.condition && /* @__PURE__ */ m(Z, { name: rt[r.type] })
				]
			}),
			/* @__PURE__ */ h("strong", { children: [r.cost, /* @__PURE__ */ m(Z, { name: "mass" })] }),
			/* @__PURE__ */ m(ht, {
				effects: r.effects,
				m: t
			})
		]
	});
}
function vt({ id: e, m: t, fulfilled: n = !1, onClick: r }) {
	let i = j[e], a = i.require.map((e, n) => e ? `${e} ${n < 3 ? t.lifeTypes[n] : i.eitherBP ? `${t.lifeTypes[0]} / ${t.lifeTypes[1]}` : t.anyLife}` : "").filter(Boolean).join(" + ");
	return /* @__PURE__ */ h("button", {
		className: "entropy-biome",
		onClick: r,
		type: "button",
		"data-scarce": i.scarce,
		"data-fulfilled": n,
		"aria-label": `B${e + 1} · ${i.scarce ? t.scarce : t.abundant} · ${t.space[i.trigger]} · ${t.cost}: ${$e(i.cost, t)} · ${i.effects.map((e) => Y(e, t)).join(" + ")} · ${t.need}: ${a} · ${n ? t.fulfilled : t.complete}: ${i.improved.map((e) => Y(e, t)).join(" + ")}`,
		children: [
			/* @__PURE__ */ h("svg", {
				viewBox: "0 0 240 100",
				preserveAspectRatio: "none",
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ m("path", {
						d: "M0 100V62L49 12L89 64L130 29L184 66L220 34L240 50V100Z",
						fill: "#8ec4b4"
					}),
					/* @__PURE__ */ m("path", {
						d: "M0 100V88L47 59L93 83L163 52L240 83V100Z",
						fill: "#346a78"
					}),
					/* @__PURE__ */ m("path", {
						d: "M0 100V89L72 79L118 90L200 69L240 85V100Z",
						fill: "#193f65"
					})
				]
			}),
			/* @__PURE__ */ h("span", {
				className: "entropy-biome-heading",
				children: [/* @__PURE__ */ h("strong", { children: [
					"B",
					e + 1,
					" · ",
					i.scarce ? t.scarce : t.abundant
				] }), /* @__PURE__ */ m(Z, {
					name: i.trigger,
					label: t.space[i.trigger]
				})]
			}),
			/* @__PURE__ */ h("span", { children: [
				t.cost,
				": ",
				$e(i.cost, t)
			] }),
			/* @__PURE__ */ m(ht, {
				effects: i.effects,
				m: t
			}),
			/* @__PURE__ */ h("span", {
				className: "entropy-biome-need",
				children: [
					t.need,
					": ",
					i.require.map((e, n) => e > 0 && /* @__PURE__ */ h("span", { children: [e, n < 3 ? /* @__PURE__ */ m(Z, { name: X[n] }) : i.eitherBP ? /* @__PURE__ */ h(p, { children: [
						/* @__PURE__ */ m(Z, { name: "bacteria" }),
						"/",
						/* @__PURE__ */ m(Z, { name: "plant" })
					] }) : t.anyLife] }, n))
				]
			}),
			/* @__PURE__ */ h("span", {
				className: "entropy-biome-upgrade",
				children: [
					n ? `✓ ${t.fulfilled}` : t.complete,
					": ",
					/* @__PURE__ */ m(ht, {
						effects: i.improved,
						m: t
					})
				]
			})
		]
	});
}
//#endregion
//#region src/games/entropy/view-player.tsx
function yt(e) {
	d();
	let t = i(), te = r((e) => e.locale), g = te === "zh" ? Xe : Ze, _ = e.public, v = e.private, [y, b] = u("board"), [S, C] = u(e.myRid), [ne, w] = u(!1), [E, O] = u(""), [A, j] = u(null), [re, ie] = u(null), oe = l(null), se = l(null), [M, N] = u(null), P = _.players.find((t) => t.rid === e.myRid) ?? _.players[0], F = _.players.find((e) => e.rid === S) ?? P, I = !e.readonly && _.turn === e.myRid, L = I ? v?.choices ?? [] : [], ce = (t) => {
		let r = e.members.find((e) => e.rid === t);
		return r ? a(t) === null ? r.name : n(te, r.avatar) : t;
	}, le = (t) => s[(e.members.find((e) => e.rid === t)?.colorIndex ?? 0) % s.length].hex, ue = (t) => o[(e.members.find((e) => e.rid === t)?.avatar ?? 0) % o.length], de = (t) => {
		e.send({
			type: "choose",
			id: t.id,
			revision: _.revision
		}), O(""), w(!1), j(null), ie(null);
	}, fe = g.prompt[_.prompt] ?? g.prompt.resolve, R = (e = "") => {
		w(!0), O(e), N(null);
	}, z = (e, t) => {
		let n = et(e, _, g);
		return /^[LPB]\d+$/i.test(t) ? RegExp(`\\b${t}(?!\\d)`, "i").test(n) : n.toLowerCase().includes(t.toLowerCase());
	}, B = M ? M.kind === "star" ? T[M.id].id : `${M.kind === "life" ? "L" : M.kind === "planet" ? "P" : "B"}${M.kind === "life" ? M.id : M.id + 1}` : "", V = L.filter((e) => e.kind === "play" && e.args[0] === A), H = V.filter((e) => e.args[1] === re), U = A !== null && V.length > 0, W = (e) => {
		ie(e), V.filter((t) => t.args[1] === e).length > 1 && R(`L${A}`);
	}, G = M !== null || ne && I;
	c(() => {
		if (G) return se.current = document.activeElement instanceof HTMLElement ? document.activeElement : null, oe.current?.querySelector("button, input")?.focus(), () => {
			se.current?.isConnected && se.current.focus();
		};
	}, [G]);
	let pe = () => {
		N(null), w(!1);
	}, K = (e) => {
		if (e.key === "Escape" && (e.stopPropagation(), pe()), e.key !== "Tab") return;
		let t = oe.current?.querySelectorAll("button:not(:disabled), input, [tabindex=\"0\"]");
		if (!t?.length) return;
		let n = t[0], r = t[t.length - 1];
		e.shiftKey && document.activeElement === n && (e.preventDefault(), r.focus()), !e.shiftKey && document.activeElement === r && (e.preventDefault(), n.focus());
	}, q = L.filter((e) => !["exchange", "fulfill"].includes(e.kind)), me = L.filter((e) => ["exchange", "fulfill"].includes(e.kind));
	return /* @__PURE__ */ m("div", {
		className: "entropy-screen",
		children: /* @__PURE__ */ m(f, {
			adaptive: !0,
			scroll: !1,
			className: "entropy-shell",
			banner: /* @__PURE__ */ h("div", {
				className: "entropy-header",
				inert: G,
				children: [
					/* @__PURE__ */ h("div", {
						className: "entropy-topbar",
						children: [
							/* @__PURE__ */ h("div", {
								className: "entropy-title",
								children: [/* @__PURE__ */ m("small", { children: "ENTROPY" }), /* @__PURE__ */ m("strong", { children: g.name })]
							}),
							/* @__PURE__ */ m("span", {
								className: "entropy-round",
								children: _.endRound === _.round ? g.lastRound : t("games.entropy.round", { n: _.round })
							}),
							/* @__PURE__ */ m("strong", {
								className: "entropy-current-prompt",
								children: e.readonly ? g.prompt.done : I ? fe : t("games.entropy.waiting", { name: ce(_.turn) })
							}),
							/* @__PURE__ */ m("div", {
								className: "entropy-resources",
								children: [
									P.energy,
									P.mass,
									P.entropy,
									P.vp
								].map((e, t) => /* @__PURE__ */ h("span", {
									title: g.resources[t],
									children: [/* @__PURE__ */ m(Z, {
										name: [
											"energy",
											"mass",
											"entropy",
											"vp"
										][t],
										label: g.resources[t]
									}), /* @__PURE__ */ m("strong", { children: e })]
								}, t))
							})
						]
					}),
					/* @__PURE__ */ m("div", {
						className: "entropy-player-line",
						children: /* @__PURE__ */ m(ee, {
							members: e.members,
							myRid: e.myRid,
							variant: "mini",
							adaptive: !0,
							scroll: !0,
							onPick: (e) => {
								C(e), b("universe");
							},
							picked: (e) => e === F.rid,
							status: (e) => `${_.players.find((t) => t.rid === e)?.vp ?? 0} VP`,
							action: (t) => !e.readonly && t === _.turn ? "pending" : null
						})
					}),
					/* @__PURE__ */ h("nav", {
						className: "entropy-tabs",
						children: [["board", "universe"].map((e) => /* @__PURE__ */ m("button", {
							onClick: () => b(e),
							type: "button",
							"aria-pressed": y === e,
							children: g[e]
						}, e)), /* @__PURE__ */ h("span", { children: [
							g.triggerEnd,
							" ",
							_.completed,
							"/2"
						] })]
					})
				]
			}),
			actionsHeight: "entropy-actions-height",
			actions: /* @__PURE__ */ h("div", {
				className: "entropy-actions",
				inert: G,
				children: [/* @__PURE__ */ h("div", {
					className: "entropy-hand-area",
					children: [/* @__PURE__ */ h("span", {
						className: "entropy-hand-label",
						children: [
							g.hand,
							" · ",
							v?.hand.length ?? 0
						]
					}), /* @__PURE__ */ m("div", {
						className: "entropy-hand-strip",
						children: v?.hand.map((t) => /* @__PURE__ */ m(gt, {
							id: t,
							m: g,
							small: !0,
							selected: U && A === t,
							available: L.some((e) => e.kind === "play" && e.args[0] === t),
							onClick: () => {
								L.some((e) => e.kind === "play" && e.args[0] === t) ? (j(A === t ? null : t), ie(null), C(e.myRid), b("universe")) : N({
									kind: "life",
									id: t
								});
							}
						}, t))
					})]
				}), /* @__PURE__ */ m("div", {
					className: "entropy-action-console",
					children: e.readonly ? /* @__PURE__ */ m("strong", { children: g.prompt.done }) : U ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("strong", { children: H.length === 1 ? /* @__PURE__ */ m(st, {
						m: g,
						children: et(H[0], _, g)
					}) : /* @__PURE__ */ h(p, { children: [
						"L",
						A,
						re === null ? ` · ${g.selectPlanet}` : ` → ${g.planet} ${re}`
					] }) }), /* @__PURE__ */ h("div", {
						className: "entropy-action-buttons",
						children: [
							/* @__PURE__ */ m("button", {
								className: "entropy-primary",
								disabled: !H.length,
								onClick: () => H.length === 1 ? de(H[0]) : R(`L${A}`),
								children: H.length === 1 ? g.confirm : g.choose
							}),
							/* @__PURE__ */ m("button", {
								className: "entropy-close",
								onClick: () => {
									j(null), ie(null);
								},
								children: g.cancel
							}),
							/* @__PURE__ */ m("button", {
								className: "entropy-close",
								onClick: () => N({
									kind: "life",
									id: A
								}),
								children: g.details
							})
						]
					})] }) : /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("strong", { children: I ? fe : t("games.entropy.waiting", { name: ce(_.turn) }) }), /* @__PURE__ */ m("button", {
						className: "entropy-primary",
						type: "button",
						disabled: !I || !L.length,
						onClick: () => R(),
						children: I ? g.choose : g.wait
					})] })
				})]
			}),
			overlay: M ? /* @__PURE__ */ h("div", {
				ref: oe,
				className: "entropy-modal entropy-detail",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": g.details,
				onKeyDown: K,
				children: [
					/* @__PURE__ */ m("button", {
						className: "entropy-close",
						onClick: () => N(null),
						children: g.close
					}),
					M.kind === "life" && /* @__PURE__ */ m(gt, {
						id: M.id,
						m: g
					}),
					M.kind === "life" && /* @__PURE__ */ m("p", {
						className: "entropy-detail-text",
						children: D[M.id - 1].effects.map((e) => Y(e, g)).join(" + ")
					}),
					M.kind === "planet" && /* @__PURE__ */ m(_t, {
						id: M.id,
						m: g
					}),
					M.kind === "biome" && /* @__PURE__ */ m(vt, {
						id: M.id,
						m: g
					}),
					M.kind === "star" && /* @__PURE__ */ m(xt, {
						id: M.id,
						m: g
					}),
					I && L.some((e) => z(e, B)) && /* @__PURE__ */ m("button", {
						className: "entropy-primary",
						onClick: () => R(B),
						children: g.choose
					})
				]
			}) : ne && I ? /* @__PURE__ */ h("div", {
				ref: oe,
				className: "entropy-modal entropy-chooser",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": g.choose,
				onKeyDown: K,
				children: [
					/* @__PURE__ */ h("div", {
						className: "entropy-chooser-head",
						children: [/* @__PURE__ */ m("strong", { children: fe }), /* @__PURE__ */ m("button", {
							className: "entropy-close",
							onClick: () => w(!1),
							children: g.close
						})]
					}),
					/* @__PURE__ */ h("div", {
						className: "entropy-pending",
						children: [_.pending.card && /* @__PURE__ */ h("span", { children: [
							"L",
							_.pending.card,
							" ·",
							" ",
							D[_.pending.card - 1].effects.map((e) => Y(e, g)).join(" + ")
						] }), [
							"energy",
							"mass",
							"entropy",
							"vp",
							"generator",
							"draw",
							"advance",
							"anyLife",
							"bacteria",
							"plant",
							"animal"
						].includes(_.prompt) && /* @__PURE__ */ h("strong", { children: ["× ", _.pending.n] })]
					}),
					/* @__PURE__ */ m("input", {
						className: "entropy-filter",
						"aria-label": g.choose,
						placeholder: g.all,
						value: E,
						onChange: (e) => O(e.target.value)
					}),
					/* @__PURE__ */ h("div", {
						className: "entropy-choice-list",
						children: [q.filter((e) => !U || re === null || e.kind === "play" && e.args[0] === A && e.args[1] === re).filter((e) => z(e, E)).map((e) => /* @__PURE__ */ m("button", {
							type: "button",
							"data-kind": e.kind,
							onClick: () => de(e),
							children: /* @__PURE__ */ m(st, {
								m: g,
								children: et(e, _, g)
							})
						}, e.id)), !L.length && /* @__PURE__ */ m("p", { children: fe })]
					}),
					/* @__PURE__ */ m("div", {
						className: "entropy-free-actions",
						children: me.map((e) => /* @__PURE__ */ m("button", {
							type: "button",
							onClick: () => de(e),
							children: /* @__PURE__ */ m(st, {
								m: g,
								children: et(e, _, g)
							})
						}, e.id))
					})
				]
			}) : null,
			children: /* @__PURE__ */ h("div", {
				className: "entropy-layout",
				"data-tab": y,
				inert: G,
				children: [/* @__PURE__ */ h("section", {
					className: "entropy-public",
					children: [/* @__PURE__ */ h("div", {
						className: "entropy-board-and-market",
						children: [/* @__PURE__ */ h(St, {
							pub: _,
							m: g,
							name: ce,
							colorOf: le,
							avatarOf: ue,
							choices: L,
							meRid: e.myRid,
							prompt: e.readonly ? g.prompt.done : I ? fe : g.wait,
							onSpace: (e, t) => {
								let n = L.filter((n) => n.kind === "move" && (P.position + n.args[0]) % 6 === e && !!n.args[1] === t);
								n.length === 1 ? de(n[0]) : n.length && R(g.space[t ? _.outer[e] : x[e]]);
							},
							children: [
								/* @__PURE__ */ m(Ct, {
									pub: _,
									m: g,
									onDetail: (e) => N({
										kind: "star",
										id: e
									})
								}),
								/* @__PURE__ */ m("h3", { children: g.space.aggregate }),
								/* @__PURE__ */ m("div", {
									className: "entropy-planet-offers",
									children: _.market.planets.map((e, t) => /* @__PURE__ */ h("div", {
										className: "entropy-offer-pair",
										children: [/* @__PURE__ */ m("span", { children: /* @__PURE__ */ m(Z, { name: rt[t] }) }), e.map((e, t) => /* @__PURE__ */ h("div", { children: [e.top === null ? /* @__PURE__ */ m("span", { children: "—" }) : /* @__PURE__ */ m(_t, {
											id: e.top,
											m: g,
											onClick: () => N({
												kind: "planet",
												id: e.top
											})
										}), /* @__PURE__ */ h("small", { children: ["×", e.count] })] }, t))]
									}, t))
								}),
								/* @__PURE__ */ m(wt, {
									pub: _,
									m: g
								})
							]
						}), /* @__PURE__ */ h("div", {
							className: "entropy-market",
							children: [
								/* @__PURE__ */ m("h3", { children: g.space.draw }),
								/* @__PURE__ */ m("div", {
									className: "entropy-life-offers",
									children: _.market.life.map((e, t) => /* @__PURE__ */ m("div", { children: e.map((e, t) => /* @__PURE__ */ h("div", { children: [e.top !== null && /* @__PURE__ */ m(gt, {
										id: e.top,
										m: g,
										small: !0,
										onClick: () => N({
											kind: "life",
											id: e.top
										})
									}), /* @__PURE__ */ h("small", { children: ["×", e.count] })] }, t)) }, t))
								}),
								/* @__PURE__ */ m("h3", { children: g.space.biome }),
								/* @__PURE__ */ m("div", {
									className: "entropy-biome-offers",
									children: _.market.biomes.flatMap((e, t) => e.map((e, n) => /* @__PURE__ */ h("div", { children: [e.top !== null && /* @__PURE__ */ m(vt, {
										id: e.top,
										m: g,
										onClick: () => N({
											kind: "biome",
											id: e.top
										})
									}), /* @__PURE__ */ h("small", { children: ["×", e.count] })] }, `${t}-${n}`)))
								}),
								/* @__PURE__ */ m(Tt, {
									pub: _,
									m: g,
									name: ce,
									colorOf: le,
									avatarOf: ue
								})
							]
						})]
					}), _.ghost && /* @__PURE__ */ h("div", {
						className: "entropy-solo",
						children: [
							/* @__PURE__ */ h("strong", { children: [
								g.ghost,
								" · ",
								_.ghostScore,
								" VP · ",
								g.progress,
								" SP",
								_.ghost.lastCard || "—",
								" · ×",
								_.ghost.remaining
							] }),
							/* @__PURE__ */ m("p", { children: g.soloFail }),
							_.ghost.challenges.map((e, t) => /* @__PURE__ */ h("div", {
								"data-done": e.done,
								children: [/* @__PURE__ */ h("strong", { children: [
									/* @__PURE__ */ m("span", {
										className: "entropy-challenge-number",
										children: t + 1
									}),
									" ",
									e.done ? "✓ " : "",
									g.challenges[e.require - 1]
								] }), e.constraint > 0 && !e.done && /* @__PURE__ */ h("p", { children: [
									g.constraint,
									": ",
									g.constraints[e.constraint - 1]
								] })]
							}, t))
						]
					})]
				}), /* @__PURE__ */ h("section", {
					className: "entropy-universe",
					children: [
						/* @__PURE__ */ h("header", { children: [/* @__PURE__ */ h("h3", { children: [
							ce(F.rid),
							" · ",
							g.universe
						] }), /* @__PURE__ */ m(lt, {
							values: ge(F),
							m: g
						})] }),
						/* @__PURE__ */ h("div", {
							className: "entropy-console",
							children: [
								/* @__PURE__ */ h("strong", { children: [
									g.console,
									" · Focus ",
									F.focus
								] }),
								/* @__PURE__ */ m("div", {
									className: "entropy-markers",
									children: F.markers.map((e, t) => /* @__PURE__ */ h("span", {
										"data-tired": e.tired,
										children: [/* @__PURE__ */ h("strong", { children: [
											/* @__PURE__ */ m(Z, { name: [
												"evolve",
												"aggregate",
												"life",
												"upgrade"
											][t] }),
											" ",
											t < 3 ? F.levels[t] : ""
										] }), e.position >= 0 ? `${e.position + 1} · ${e.locked ? g.locked : g.board}` : e.tired ? g.tired : g.ready]
									}, t))
								}),
								/* @__PURE__ */ h("div", {
									className: "entropy-generator",
									children: [/* @__PURE__ */ m("span", { children: g.generator }), ae.map((e, t) => /* @__PURE__ */ h("span", {
										"data-active": t === F.generator,
										children: [t, /* @__PURE__ */ h("small", { children: [
											"−",
											e.discount,
											" ",
											/* @__PURE__ */ m(Z, { name: "entropy" }),
											" / ",
											e.count,
											/* @__PURE__ */ m(Z, { name: "star" })
										] })]
									}, t))]
								}),
								/* @__PURE__ */ m("div", {
									className: "entropy-focus-help",
									children: g.focusDescriptions[F.focus.charCodeAt(0) - 65].map((e, t) => /* @__PURE__ */ h("details", { children: [/* @__PURE__ */ h("summary", { children: [
										g.markerNames[t],
										" · ",
										F.levels[t]
									] }), /* @__PURE__ */ m("p", { children: e })] }, t))
								})
							]
						}),
						/* @__PURE__ */ m("div", {
							className: "entropy-systems",
							children: F.systems.map((t) => /* @__PURE__ */ h("div", {
								className: "entropy-system",
								children: [
									/* @__PURE__ */ h("span", {
										className: "entropy-system-name",
										children: [
											g.system,
											" ",
											t.uid
										]
									}),
									/* @__PURE__ */ m("div", { className: "entropy-system-orbit" }),
									/* @__PURE__ */ m("div", {
										className: "entropy-system-star",
										children: t.star >= 0 ? /* @__PURE__ */ h("button", {
											type: "button",
											onClick: () => N({
												kind: "star",
												id: t.star
											}),
											children: [
												/* @__PURE__ */ m(it, {
													star: !0,
													type: T[t.star].tier - 1
												}),
												/* @__PURE__ */ m("strong", { children: T[t.star].id }),
												/* @__PURE__ */ m(lt, {
													values: T[t.star].env,
													m: g
												})
											]
										}) : /* @__PURE__ */ m("span", { children: g.noStar })
									}),
									[0, 1].map((n) => {
										let r = F.planets.filter((e) => e.system === t.uid)[n];
										return /* @__PURE__ */ m("div", {
											className: "entropy-system-planet",
											"data-slot": n,
											"data-available": !!r && F.rid === e.myRid && V.some((e) => e.args[1] === r.uid),
											"data-selected": !!r && U && re === r.uid,
											children: r ? /* @__PURE__ */ h(p, { children: [
												/* @__PURE__ */ h("button", {
													type: "button",
													className: "entropy-planet-orb",
													onClick: () => U && V.some((e) => e.args[1] === r.uid) && F.rid === e.myRid ? W(r.uid) : N({
														kind: "planet",
														id: r.data
													}),
													"aria-pressed": U ? re === r.uid : void 0,
													children: [
														/* @__PURE__ */ m(it, { type: k[r.data].type }),
														/* @__PURE__ */ h("strong", { children: [
															g.planet,
															" ",
															r.uid,
															" · P",
															r.data + 1
														] }),
														/* @__PURE__ */ m(lt, {
															values: he(F, r),
															m: g
														})
													]
												}),
												/* @__PURE__ */ m("div", {
													className: "entropy-life-counts",
													children: r.life.map((e, t) => /* @__PURE__ */ h("span", { children: [
														/* @__PURE__ */ m(Z, {
															name: X[t],
															label: g.lifeTypes[t]
														}),
														" ",
														/* @__PURE__ */ m("strong", { children: e })
													] }, t))
												}),
												/* @__PURE__ */ m("div", {
													className: "entropy-asteroids",
													children: [0, 1].map((e) => /* @__PURE__ */ m("span", {
														title: e === 0 ? `2 ${g.resources[1]}` : `1 ${g.anyLife}`,
														children: r.asteroids.some((t) => t.slot === e) ? /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(Z, { name: rt[r.asteroids.find((t) => t.slot === e).type] }), /* @__PURE__ */ m(Z, { name: "asteroidBody" })] }) : "◌"
													}, e))
												}),
												/* @__PURE__ */ m("div", {
													className: "entropy-played",
													children: r.cards.map((e) => /* @__PURE__ */ h("button", {
														onClick: () => N({
															kind: "life",
															id: e
														}),
														children: [
															/* @__PURE__ */ m(Z, { name: X[D[e - 1].type] }),
															" L",
															e
														]
													}, e))
												}),
												r.biome && /* @__PURE__ */ m(vt, {
													id: r.biome.data,
													m: g,
													fulfilled: r.biome.fulfilled,
													onClick: () => N({
														kind: "biome",
														id: r.biome.data
													})
												})
											] }) : /* @__PURE__ */ m("span", {
												className: "entropy-empty",
												children: g.emptyPlanet
											})
										}, n);
									})
								]
							}, t.uid))
						}),
						F.rid === e.myRid && v?.missions.map((e) => /* @__PURE__ */ h("div", {
							className: "entropy-mission",
							children: [/* @__PURE__ */ h("strong", { children: [
								g.mission,
								" M",
								e
							] }), /* @__PURE__ */ m("p", { children: g.missions[e - 1] })]
						}, e))
					]
				})]
			})
		})
	});
}
function bt(e) {
	return e < 2 ? [38, 38 + e * 58] : e < 5 ? [195, 22 + (e - 2) * 43] : e < 9 ? [350, 17 + (e - 5) * 32] : [520, 22 + (e - 9) * 43];
}
function xt({ id: e, m: t }) {
	let n = T[e];
	return /* @__PURE__ */ h("div", {
		className: "entropy-star-detail",
		children: [
			/* @__PURE__ */ m(it, {
				star: !0,
				type: n.tier - 1,
				size: 110
			}),
			/* @__PURE__ */ h("h3", { children: [
				t.star,
				" ",
				n.id
			] }),
			/* @__PURE__ */ m(lt, {
				values: n.env,
				m: t
			}),
			/* @__PURE__ */ h("p", { children: [
				t.cost,
				": ",
				n.tier,
				" ",
				/* @__PURE__ */ m(Z, { name: "entropy" })
			] }),
			/* @__PURE__ */ m(ht, {
				effects: n.effects,
				m: t
			}),
			/* @__PURE__ */ h("p", { children: [
				t.space.evolve,
				": ",
				n.next.map((e) => T[e].id).join(" / ") || "—"
			] })
		]
	});
}
function St({ pub: e, m: t, name: n, colorOf: r, avatarOf: i, onSpace: a, choices: o, meRid: s, prompt: c, children: l }) {
	let u = e.players.find((e) => e.rid === s) ?? e.players[0];
	return /* @__PURE__ */ h("div", {
		className: "entropy-ring-wrap",
		children: [/* @__PURE__ */ h("div", {
			className: "entropy-ring",
			children: [
				/* @__PURE__ */ h("svg", {
					className: "entropy-ring-art",
					viewBox: "0 0 600 600",
					"aria-hidden": "true",
					children: [
						/* @__PURE__ */ m("defs", { children: /* @__PURE__ */ h("linearGradient", {
							id: "entropy-metal",
							x2: "0.15",
							y2: "1",
							children: [
								/* @__PURE__ */ m("stop", { stopColor: "#fbfcf6" }),
								/* @__PURE__ */ m("stop", {
									offset: ".4",
									stopColor: "#c0ccd3"
								}),
								/* @__PURE__ */ m("stop", {
									offset: ".7",
									stopColor: "#f1f2e8"
								}),
								/* @__PURE__ */ m("stop", {
									offset: "1",
									stopColor: "#aab9c6"
								})
							]
						}) }),
						/* @__PURE__ */ m("circle", {
							cx: "300",
							cy: "300",
							r: "295",
							fill: "url(#entropy-metal)",
							stroke: "#7f96aa",
							strokeWidth: "2"
						}),
						/* @__PURE__ */ m("circle", {
							cx: "300",
							cy: "300",
							r: "253",
							fill: "none",
							stroke: "#889fab",
							strokeWidth: "2"
						}),
						/* @__PURE__ */ m("circle", {
							cx: "300",
							cy: "300",
							r: "211",
							fill: "#191c48",
							stroke: "#7d93a9",
							strokeWidth: "2"
						}),
						/* @__PURE__ */ m("circle", {
							cx: "300",
							cy: "300",
							r: "291",
							fill: "none",
							stroke: "#f9fffa",
							strokeWidth: "1"
						}),
						Array.from({ length: 6 }, (e, t) => [!1, !0].map((e) => {
							let n = o.some((n) => n.kind === "move" && (u.position + n.args[0]) % 6 === t && !!n.args[1] === e), r = (t * 60 - 119) * Math.PI / 180, i = (t * 60 - 61) * Math.PI / 180, a = e ? 254 : 212, s = e ? 293 : 252;
							return n && /* @__PURE__ */ m("path", {
								className: "entropy-legal-sector",
								"data-outer": e,
								d: `M${300 + a * Math.cos(r)} ${300 + a * Math.sin(r)}L${300 + s * Math.cos(r)} ${300 + s * Math.sin(r)}A${s} ${s} 0 0 1 ${300 + s * Math.cos(i)} ${300 + s * Math.sin(i)}L${300 + a * Math.cos(i)} ${300 + a * Math.sin(i)}A${a} ${a} 0 0 0 ${300 + a * Math.cos(r)} ${300 + a * Math.sin(r)}Z`,
								fill: "#28677f",
								stroke: "#9fe5eb"
							}, `${t}-${e}`);
						})),
						Array.from({ length: 6 }, (e, t) => {
							let n = (t * 60 - 120) * Math.PI / 180;
							return /* @__PURE__ */ m("path", {
								d: `M${300 + 212 * Math.cos(n)} ${300 + 212 * Math.sin(n)}L${300 + 294 * Math.cos(n)} ${300 + 294 * Math.sin(n)}`,
								stroke: "#8199ac",
								strokeWidth: "2"
							}, t);
						})
					]
				}),
				/* @__PURE__ */ h("div", {
					className: "entropy-ring-mobile-prompt",
					children: [
						/* @__PURE__ */ m("small", { children: "ENTROPY" }),
						/* @__PURE__ */ m("strong", { children: c }),
						/* @__PURE__ */ h("span", { children: [
							t.triggerEnd,
							" ",
							e.completed,
							"/2"
						] })
					]
				}),
				Array.from({ length: 6 }, (s, c) => [!1, !0].map((s) => {
					let l = (c * 60 - 90) * Math.PI / 180, d = e.players.filter((e) => e.position === c && e.outer === s), f = o.some((e) => e.kind === "move" && (u.position + e.args[0]) % 6 === c && !!e.args[1] === s);
					return /* @__PURE__ */ h("button", {
						type: "button",
						className: "entropy-ring-space",
						"data-outer": s,
						"data-available": f,
						disabled: !f,
						style: {
							left: `${50 + (s ? 45.8 : 38.5) * Math.cos(l)}%`,
							top: `${50 + (s ? 45.8 : 38.5) * Math.sin(l)}%`,
							"--mobile-left": `${50 + (s ? 46 : 33.5) * Math.cos(l)}%`,
							"--mobile-top": `${50 + (s ? 46 : 33.5) * Math.sin(l)}%`,
							"--ring-turn": `${c > 1 && c < 5 ? c * 60 - 180 : c * 60}deg`
						},
						onClick: () => a(c, s),
						"aria-label": `${c + 1} ${t[s ? "outer" : "inner"]} ${t.space[s ? e.outer[c] : x[c]]}`,
						children: [
							/* @__PURE__ */ m(Z, { name: s ? e.outer[c] : x[c] }),
							/* @__PURE__ */ m("strong", { children: t.space[s ? e.outer[c] : x[c]] }),
							f && /* @__PURE__ */ m("small", { children: "+" }),
							/* @__PURE__ */ h("span", {
								className: "entropy-scientists",
								children: [d.map((e) => /* @__PURE__ */ m(ct, {
									avatar: i(e.rid),
									color: r(e.rid),
									name: n(e.rid)
								}, e.rid)), !s && e.ghost?.position === c && /* @__PURE__ */ m(ct, {
									color: "#d0d7df",
									name: t.ghost,
									ghost: !0
								})]
							})
						]
					}, `${c}-${s}`);
				})),
				Array.from({ length: 6 }, (e, t) => /* @__PURE__ */ m("span", {
					className: "entropy-sector-number",
					style: {
						left: `${50 + 34.5 * Math.cos((t * 60 - 90) * Math.PI / 180)}%`,
						top: `${50 + 34.5 * Math.sin((t * 60 - 90) * Math.PI / 180)}%`,
						"--mobile-left": `${50 + 28.5 * Math.cos((t * 60 - 90) * Math.PI / 180)}%`,
						"--mobile-top": `${50 + 28.5 * Math.sin((t * 60 - 90) * Math.PI / 180)}%`
					},
					children: t + 1
				}, t)),
				e.players.flatMap((e, i) => e.markers.map((a, o) => a.position >= 0 ? /* @__PURE__ */ h("span", {
					className: "entropy-ring-token",
					title: `${n(e.rid)} · ${t.markerNames[o]}${a.locked ? ` · ${t.locked}` : ""}`,
					style: {
						left: `${50 + 34.5 * Math.cos((a.position * 60 - 111 + i * 7) * Math.PI / 180)}%`,
						top: `${50 + 34.5 * Math.sin((a.position * 60 - 111 + i * 7) * Math.PI / 180)}%`,
						borderColor: r(e.rid)
					},
					children: [/* @__PURE__ */ m(Z, { name: [
						"evolve",
						"aggregate",
						"life",
						"upgrade"
					][o] }), a.locked && /* @__PURE__ */ m("small", { children: "×" })]
				}, `${e.rid}-${o}`) : null))
			]
		}), /* @__PURE__ */ m("div", {
			className: "entropy-ring-center",
			children: l
		})]
	});
}
function Ct({ pub: e, m: t, onDetail: n }) {
	return /* @__PURE__ */ h("div", {
		className: "entropy-star-tree",
		children: [
			/* @__PURE__ */ m("h3", { children: t.space.evolve }),
			/* @__PURE__ */ m("svg", {
				viewBox: "0 0 580 130",
				"aria-hidden": "true",
				children: T.flatMap((e, t) => e.next.map((e) => /* @__PURE__ */ m("line", {
					x1: bt(t)[0],
					y1: bt(t)[1],
					x2: bt(e)[0],
					y2: bt(e)[1],
					stroke: "#dce8dc",
					strokeWidth: "1.5"
				}, `${t}-${e}`)))
			}),
			/* @__PURE__ */ m("div", { children: T.map((t, r) => /* @__PURE__ */ h("button", {
				type: "button",
				onClick: () => n(r),
				style: {
					left: `${bt(r)[0] / 580 * 100}%`,
					top: `${24 + bt(r)[1] / 130 * 70}%`
				},
				children: [
					/* @__PURE__ */ m("img", {
						src: nt(`star-${t.tier - 1}`),
						alt: ""
					}),
					/* @__PURE__ */ m("strong", { children: t.id }),
					/* @__PURE__ */ h("small", { children: ["×", e.stars[r]] })
				]
			}, t.id)) })
		]
	});
}
function wt({ pub: e, m: t }) {
	return /* @__PURE__ */ m("div", {
		className: "entropy-life-objectives",
		children: [
			0,
			1,
			2
		].map((n) => /* @__PURE__ */ h("div", { children: [
			/* @__PURE__ */ h("strong", { children: [
				/* @__PURE__ */ m(Z, {
					name: X[n],
					label: t.lifeTypes[n]
				}),
				[
					11,
					8,
					6
				][n],
				"+"
			] }),
			/* @__PURE__ */ h("span", { children: [e.small[n].join(" / "), " VP"] }),
			/* @__PURE__ */ h("span", { children: [
				[
					18,
					14,
					11
				][n],
				"+ · ",
				e.big[n] ? "20 VP" : "✓"
			] }),
			e.ghost && /* @__PURE__ */ h("span", { children: [
				"G ",
				e.ghost.life[n],
				"/5"
			] })
		] }, n))
	});
}
function Tt({ pub: e, m: t, name: n, colorOf: r, avatarOf: i }) {
	return /* @__PURE__ */ h("div", {
		className: "entropy-objectives",
		children: [
			/* @__PURE__ */ m("h3", { children: t.objectives }),
			t.mainEvents.map((a, o) => /* @__PURE__ */ h("div", {
				className: "entropy-objective",
				children: [
					/* @__PURE__ */ h("strong", { children: [
						o + 1,
						". ",
						a
					] }),
					/* @__PURE__ */ m("div", { children: ie.map((t, a) => /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m("b", { children: t }), /* @__PURE__ */ h("small", { children: [e.players.filter((e) => e.tracks[o] === a).map((e) => /* @__PURE__ */ m("span", {
						className: "entropy-track-player",
						title: n(e.rid),
						style: { borderColor: r(e.rid) },
						children: /* @__PURE__ */ m("img", {
							src: i(e.rid),
							alt: "",
							draggable: !1,
							style: {
								width: "100%",
								height: "100%",
								objectFit: "contain",
								pointerEvents: "none"
							}
						})
					}, e.rid)), e.ghost?.tracks[o] === a ? " 👻" : ""] })] }, a)) }),
					/* @__PURE__ */ h("p", { children: ["× ", (e.config.alternative ? t.altFactors : t.mainFactors)[o]] })
				]
			}, o)),
			/* @__PURE__ */ h("span", { children: [
				/* @__PURE__ */ m(st, {
					m: t,
					children: e.asteroids.map((e, t) => `${Qe[t]}☄ ×${e}`).join(" · ")
				}),
				" · ",
				t.system,
				" ×",
				e.systemsLeft
			] })
		]
	});
}
//#endregion
//#region src/games/entropy/bot-eval.ts
var Q = (e) => e.reduce((e, t) => e + t, 0), $ = (e, t) => Math.min(1, e / t), Et = (e) => e.players[e.turn];
function Dt(e, t) {
	let n = Et(e);
	switch (t) {
		case 1: return Math.max(...[
			0,
			1,
			2
		].map((e) => $(n.planets.flatMap((e) => e.cards).filter((t) => D[t - 1].type === e).length, 4)));
		case 2: return Math.max(0, ...n.systems.map((e) => e.star < 0 ? 0 : $(T[e.star].tier - 1, 3)));
		case 3: return $(Q(n.levels), 4);
		case 4: return $(n.systems.filter((e) => e.star >= 0).length, 4);
		case 5: return $(Q(n.planets.map((e) => e.asteroids.length / 2)), 2) * .3 + $(n.planets.filter((e) => e.asteroids.length === 2).length, 2) * .7;
		case 6: return Q(n.planets.map((e) => $(Q(e.life), 5)).sort((e, t) => t - e).slice(0, 3)) / 3;
		case 7: return $(n.planets.filter((e) => e.cards.length > 0).length, 4);
		case 8: return $(n.planets.length, 6);
		default: return $(ge(n)[t - 9], t < 11 ? 8 : 7);
	}
}
function Ot(e, t) {
	if (t === 1) return $(new Set(e.planets.map((e) => k[e.data].type)).size, 3);
	if (t === 2) return $(new Set(e.planets.flatMap((e) => e.asteroids.map((e) => e.type))).size, 3);
	if (t === 3) return Math.max(...e.levels) / 2;
	if (t === 4) return e.levels.filter((e) => e > 0).length / 3;
	if (t === 5) return $(e.generatorSteps, 3);
	if (t < 9) {
		let n = t - 1;
		return Math.max(0, ...e.systems.map((e) => e.star === n ? 1 : e.star >= 0 && T[e.star].next.includes(n) ? .5 : 0));
	}
	return Math.max(0, ...e.systems.map((n) => $(ge(e, n.uid)[t - 9], 3)));
}
function kt(e, t, n) {
	if (n.cards.length >= 3) return 0;
	let r = Et(e), i = D[t - 1], a = he(r, n), o = Q(i.env.map((e, t) => Math.max(0, e - a[t])));
	e.ghost?.challenges.some((e) => !e.done && e.constraint === 7) && Q(a) < Q(i.env) + 1 && o++;
	let s = r.hand.some((e) => e !== t && D[e - 1].env.some((e, t) => e > 0 && i.env[t] > a[t]));
	o && s && (o -= .65);
	let c = i.type > 0 ? Math.max(0, i.require - n.life[i.type - 1]) : 0;
	return 1 / (1 + o * 1.8 + c * 1.4);
}
function At(e, t) {
	return Math.min(e, 4) * t + Math.min(Math.max(0, e - 4), 5) * t * .45 + Math.max(0, e - 9) * .08;
}
function jt(e) {
	let t = j[e.biome.data], n = t.require, r = Q(n.slice(0, 3).map((t, n) => Math.max(0, t - e.life[n]))), i = t.eitherBP ? Math.max(0, e.life[0] - n[0]) + Math.max(0, e.life[1] - n[1]) : Q(e.life.map((e, t) => Math.max(0, e - n[t])));
	return 1 / (1 + r + Math.max(0, n[3] - i));
}
function Mt(e, t) {
	let n = Et(e), r = {
		...n,
		handCount: n.hand.length
	}, i = We(r, e.config, e.ghost).total;
	i += t * (At(r.energy, 1.6) + At(r.mass, 1.5) + At(r.entropy, 1.15)), i += t * (Math.min(r.planets.length, 6) * 3.5 + Math.max(0, r.planets.length - 6) * .5), i += t * (r.generator * 2.5 + Math.min(3, r.generatorSteps) * .5);
	for (let e of r.systems) if (e.star >= 0) {
		let n = T[e.star];
		i += t * (2 + n.tier * 1.9 + Q(n.env) * .45);
	}
	let a = {
		A: [
			4.5,
			4,
			5
		],
		B: [
			4,
			5,
			7
		],
		C: [
			6,
			7,
			4
		],
		D: [
			5,
			5,
			4
		]
	};
	i += t * Q(r.levels.map((e, t) => e * a[r.focus][t])), i += t * Q(r.markers.map((e, t) => e.position < 0 ? .6 + (r.levels[t] ?? 0) * .2 : e.locked ? -.4 : 0));
	let o = [
		0,
		1,
		2
	].map((e) => Q(r.planets.map((t) => t.life[e])));
	for (let n = 0; n < 3; n++) {
		let a = [
			11,
			8,
			6
		][n], s = [
			18,
			14,
			11
		][n];
		!r.small[n] && e.small[n].length && (i += t * e.small[n][0] * .8 * $(o[n], a) ** 1.7), !r.big[n] && e.big[n] && (i += t * 12 * $(o[n], s) ** 2);
		let c = [...e.players.filter((e) => e.rid !== r.rid), ...e.ghost ? [e.ghost] : []].some((e) => e.tracks[n] === 5) ? 4 : 5, l = Math.min(c, r.tracks[n] + r.events[n]);
		i += Math.max(0, l - r.tracks[n]) * (2 + r.planets.length * .6), l < c && (i += t * l * 1.1);
	}
	for (let e of r.planets) i += t * (e.life[0] * .65 + e.life[1] * 1.15 + e.life[2] * 1.7), i += t * ((e.life[0] > 0 ? .8 : 0) + +(e.life[1] > 0)), i += t * e.asteroids.length * 1.1, e.biome && (i += t * (1.5 + (e.biome.fulfilled ? 2 : jt(e) * 3)));
	let s = r.hand.map((t) => .35 + Math.max(0, ...r.planets.map((n) => kt(e, t, n))) * (2 + D[t - 1].type * .4)).sort((e, t) => t - e);
	if (i += t * Q(s.map((e, t) => e / (1 + t * .5))), r.missions.length && (i += t * Math.max(...r.missions.map((e) => Ot(r, e))) * 7), e.ghost) {
		let t = e.ghost.challenges.filter((e) => e.done).length, n = e.ghost.challenges.map((t) => t.done ? 1 : Dt(e, t.require)).sort((e, t) => t - e);
		if (i += (t < 2 ? 42 : 12) * Q(n.slice(0, 2).map((e) => e * e)), e.endRound !== null && t < 2 && (i -= (2 - t) * 30), t >= 2 && e.endRound !== null) {
			let t = e.ghost.tiles + Q(e.ghost.tracks.map((e) => [
				0,
				1,
				3,
				5,
				7,
				10
			][e])) * e.config.ghostMultiplier;
			i += We(r, e.config, e.ghost).total > t ? 30 : -15;
		}
	}
	return i;
}
function Nt(e, t) {
	let n = Et(e);
	return Q(t.map((e) => {
		let t = 0;
		return e.kind === "vp" && (t = 1), e.kind === "energy" && (t = n.energy < 5 ? 1.6 : .5), e.kind === "mass" && (t = n.mass < 5 ? 1.5 : .4), e.kind === "entropy" && (t = n.entropy < 6 ? 1.1 : .3), e.kind === "generator" && (t = n.generator < 4 ? 3 : 3.5), e.kind === "draw" && (t = n.hand.length < 3 ? 2.7 : n.hand.length < 6 ? 1 : .2), e.kind === "advance" && (t = 2.4), e.kind === "bacteria" && (t = 1.9), e.kind === "plant" && (t = 2.3), (e.kind === "animal" || e.kind === "anyLife") && (t = 3.2), e.kind === "aggregate" && (t = n.mass >= 2 && n.planets.length < 6 ? 6 : 1), e.kind === "evolve" && (t = n.energy >= 2 ? 6 : 1), e.kind === "life" && (t = n.hand.length ? 7 : 0), e.kind === "asteroid" && (t = n.mass >= 2 ? 4 : 1), (e.kind === "biome" || e.kind === "setOrFulfill") && (t = n.planets.some((e) => !e.biome) ? 4 : 1), e.kind === "upgrade" && (t = e.tag === 1 || n.energy >= 3 ? 6 : 0), e.kind === "retrieve" && (t = n.markers.some((e) => e.position >= 0 && !e.locked) ? 2 : 0), e.kind === "fulfill" && (t = n.planets.some((e) => e.biome && !e.biome.fulfilled) ? 5 : 0), (e.kind === "activate" || e.kind === "activateOne") && (t = n.entropy >= 2 ? 4 : 0), e.kind === "animalReward" && (t = 5), t * e.n;
	}));
}
function Pt(e, t) {
	let n = Et(e), r = t.args, i = e.tasks[0], a = n.planets.find((e) => e.uid === r[0]);
	if (t.kind === "skip") return 0;
	if (t.kind === "end") return -1;
	if (t.kind === "gain") return 4;
	if (t.kind === "fulfill") return 15;
	if (t.kind === "challenge") return 80;
	if (t.kind === "mission") return 12;
	if (t.kind === "move") return 4 - r[0] * .1 - r[3] * .2 + (r[2] >= 0 && r[2] < 3 ? n.levels[r[2]] : 0);
	if (t.kind === "evolve") return T[r[1]].tier * 3 + Q(T[r[1]].env) - r[2] + (r[0] < 0 && n.systems.length >= 4 ? -5 : 0);
	if (t.kind === "aggregate") return 7 - k[r[2]].cost * .6 + Nt(e, k[r[2]].effects) + +!!k[r[2]].condition;
	if (t.kind === "placePlanet") {
		let e = n.systems.find((e) => e.uid === r[0]);
		return e && e.star >= 0 ? Q(T[e.star].env) : 0;
	}
	if (t.kind === "play") {
		let t = D[r[0] - 1], a = n.planets.find((e) => e.uid === r[1]);
		return 4 + Math.min(5 - a.life[t.type], t.yield + (i?.bonus ?? 0)) * (t.type + 1) + Nt(e, t.effects) - (r[2] ? 2 : 0) - (t.consume ? t.require * .8 : 0);
	}
	if (t.kind === "draw") return Math.max(0, ...n.planets.map((t) => kt(e, r[2], t))) * 5 + Nt(e, D[r[2] - 1].effects) * .15 - n.hand.filter((e) => D[e - 1].type === r[0]).length * .4;
	if (t.kind === "order") return r[0] === 0 ? .1 : 0;
	if (t.kind === "activate") return Nt(e, T[n.systems.find((e) => e.uid === r[0]).star].effects) - r[1] * (n.entropy < 4 ? 1.1 : .6);
	if (t.kind === "upgrade") return n.levels[r[0]] === 0 ? 6 : 5;
	if (t.kind === "biome") {
		let t = j[r[3]];
		return 2 + jt({
			...a,
			biome: {
				data: r[3],
				fulfilled: !1
			}
		}) * 6 + Nt(e, t.effects) * .3;
	}
	if (t.kind === "biomeTrigger") {
		let t = i?.kind === "biomeTrigger" ? n.planets.find((e) => e.uid === i.planet) : a;
		if (!t?.biome) return -1;
		let r = j[t.biome.data], o = r.cost.kind === "draw" ? 2 : r.cost.kind === "vp" ? r.cost.n : r.cost.n * 1.3;
		return Nt(e, [...r.effects, ...t.biome.fulfilled ? r.improved : []]) - o;
	}
	if (t.kind === "asteroid") {
		let t = he(n, a), i = n.hand.filter((e) => D[e - 1].env[r[1]] > t[r[1]] && a.cards.length < 3).length;
		return 3 + Math.min(3, i) * 1.4 + Nt(e, k[a.data].effects) - r[5] * 1.3 - (r[3] >= 0 ? 1.5 : 0) - (r[4] ? 2 : 0);
	}
	if (t.kind === "advance" || t.kind === "addLife") {
		let e = [
			0,
			1,
			2
		].map((e) => Q(n.planets.map((t) => t.life[e]))), i = [
			11,
			8,
			6
		][r[1]], o = 2 + r[1] * .8 + (e[r[1]] < i ? e[r[1]] / i * 2 : 0);
		return a.biome && !a.biome.fulfilled && a.life[r[1]] < j[a.biome.data].require[r[1]] && (o += 3), n.hand.some((e) => D[e - 1].type === r[1] + 1 && D[e - 1].require > a.life[r[1]]) && (o += 1.5), t.kind === "advance" && r[1] > 0 && --o, o;
	}
	if (t.kind === "retrieve") return 2 + (n.levels[r[0]] ?? 0);
	if (t.kind === "exchange") {
		let e = r[0] === 0 ? "energy" : "mass", t = n[e];
		return e === "energy" && ["evolve", "upgrade"].includes(i?.kind ?? "") && t < 4 || e === "mass" && ["aggregate", "asteroid"].includes(i?.kind ?? "") && t < 4 ? 1 : -3;
	}
	return t.kind === "pickCondition" ? ge(n)[r[0]] : 0;
}
//#endregion
//#region src/games/entropy/bot-plan.ts
var Ft = (e) => e.kind + ":" + e.args.join(",");
function It(e, t) {
	let n = Ye.reduce(e, t ? {
		type: "choose",
		id: t.id,
		revision: e.revision
	} : {
		type: "tick",
		now: 0
	}, { by: e.players[e.turn].rid });
	return "code" in n ? null : n.state;
}
function Lt(e, t = 24) {
	for (let n = 0; n < t && e.phase === "resolve" && Ye.nextTickIn(e, 0) !== null && !(e.tasks[0]?.kind.startsWith("ghost") || e.tasks[0]?.kind === "next"); n++) e = It(e);
	return e;
}
function Rt(e, t, n) {
	let r = n, i;
	if (r?.tag === "entropy-plan-1" && r.rid === e.turn && r.round === e.round && r.state.revision < e.revision) {
		let t = Lt(r.state);
		t.phase === e.phase && (e.phase !== "resolve" || t.tasks[0]?.kind === e.prompt) && (i = t);
	}
	let a = e.players.find((t) => t.rid === e.turn), o = e.pending, s = {
		kind: e.prompt,
		n: o.n,
		bonus: o.bonus
	};
	for (let e of [
		"tag",
		"planet",
		"system",
		"card",
		"data"
	]) o[e] !== null && (s[e] = o[e]);
	if (!i && [
		"evolve",
		"aggregate",
		"life"
	].includes(e.prompt)) {
		let t = e.log.length - 1;
		for (; t >= 0 && (e.log[t].rid !== e.turn || e.log[t].kind !== "move");) t--;
		let n = e.log[t], r = n?.args[2] ?? -1;
		!e.log.slice(t + 1).some((t) => t.rid === e.turn && [
			"activate",
			"biomeTrigger",
			"play",
			"evolve",
			"aggregate"
		].includes(t.kind)) && n?.args[1] === 0 && r >= 0 && r < 3 && x[a.position] === e.prompt && (s.focus = a.levels[r]);
	}
	!i && e.prompt === "activate" && (s.used = a.systems.filter((e) => !t.choices.some((t) => t.kind === "activate" && t.args[0] === e.uid)).map((e) => e.uid)), e.prompt === "biomeBatch" && (s.targets = t.choices.filter((e) => e.kind === "biomeTrigger").map((e) => e.args[0]));
	let c = i?.tasks ?? (e.phase === "resolve" ? [s, { kind: "checkpoint" }] : []);
	i && c[0] && (c = [{
		...c[0],
		...s
	}, ...c.slice(1)]);
	let l = (e) => e.map((e) => e.map((e) => e.top === null ? [] : [e.top]));
	return {
		players: structuredClone(e.players).map((n) => ({
			...n,
			hand: n.rid === e.turn ? [...t.hand] : [],
			missions: n.rid === e.turn ? [...t.missions] : []
		})),
		turn: e.players.findIndex((t) => t.rid === e.turn),
		round: e.round,
		endRound: e.endRound,
		phase: e.phase,
		revision: e.revision,
		seed: 0,
		cursor: 0,
		uid: Math.max(0, ...e.players.flatMap((e) => [...e.systems, ...e.planets].map((e) => e.uid))) + 1,
		outer: [...e.outer],
		lifeDecks: l(e.market.life),
		planetDecks: l(e.market.planets),
		biomeDecks: l(e.market.biomes),
		stars: [...e.stars],
		asteroids: [...e.asteroids],
		systemsLeft: e.systemsLeft,
		small: structuredClone(e.small),
		big: [...e.big],
		completed: e.completed,
		config: { ...e.config },
		ghost: e.ghost ? {
			...structuredClone(e.ghost),
			deck: []
		} : null,
		tasks: structuredClone(c),
		actionWindow: i?.actionWindow ?? e.phase === "resolve",
		distance: i?.distance ?? 0,
		log: structuredClone(e.log)
	};
}
function zt(e, t, n) {
	let r = e.players[e.turn].rid;
	for (let t = 0; t < 64 && !(n?.aborted || e.phase === "mission" || e.phase === "done" || e.players[e.turn].rid !== r); t++) {
		if (Ye.nextTickIn(e, 0) !== null) {
			if (e.tasks[0]?.kind.startsWith("ghost") || e.tasks[0]?.kind === "next") break;
			e = It(e);
			continue;
		}
		let t = Oe(e);
		if (!t.length) break;
		let n = t.reduce((t, n) => Pt(e, n) > Pt(e, t) ? n : t), r = It(e, n);
		if (!r) break;
		e = r;
	}
	let i = Mt(e, t);
	if (e.endRound !== null && !e.ghost) {
		let t = Ye.viewFor(e, "").public.scores, n = t[r].total, a = Math.max(...Object.entries(t).filter(([e]) => e !== r).map(([, e]) => e.total));
		i += Math.max(-20, Math.min(30, (n - a) / 4));
	}
	return i;
}
function Bt(e, t) {
	let n = e.players[e.turn];
	if (n.hand.length <= 8) return e;
	let r = t.kind === "play" ? [t.args[0], t.args[2]] : t.kind === "asteroid" ? [t.args[4]] : t.kind === "biomeTrigger" && e.tasks[0]?.kind === "biomeTrigger" ? [t.args[0]] : [], i = n.hand.map((t) => ({
		id: t,
		value: Math.max(0, ...n.planets.map((n) => kt(e, t, n)))
	})).sort((e, t) => t.value - e.value), a = Array.from(/* @__PURE__ */ new Set([...r.filter((e) => e > 0), ...i.map((e) => e.id)])).slice(0, 8), o = structuredClone(e);
	return o.players[e.turn].hand = a, o;
}
function Vt(e, t, n, r) {
	let i = Rt(e, t, n), a = e.endRound === null ? 1 : Math.max(0, (e.endRound - e.round) * .35), o = t.choices.map((e) => ({
		c: e,
		estimate: Pt(i, e)
	})).sort((e, t) => t.estimate - e.estimate), s = o.slice(0, e.phase === "move" ? 18 : 12);
	for (let e of [
		"skip",
		"fulfill",
		"challenge",
		"mission"
	]) {
		let t = o.find((t) => t.c.kind === e);
		t && !s.includes(t) && s.push(t);
	}
	let c = o[0].c, l = -Infinity, u = null;
	for (let { c: e, estimate: t } of s) {
		if (r?.aborted) break;
		let n = Bt(i, e), o = Oe(n).find((t) => Ft(t) === Ft(e)), s = o ? It(n, o) : null, d = s ? zt(s, a, r) - Mt(n, a) : t * .5;
		d > l + 1e-7 && (l = d, c = e, u = s);
	}
	return {
		choice: c,
		memory: u ? {
			tag: "entropy-plan-1",
			state: u,
			rid: e.turn,
			round: e.round
		} : void 0
	};
}
//#endregion
//#region src/games/entropy/bot.ts
function Ht(e) {
	let t = Math.floor(4294967296 / e.length) * e.length, n;
	do
		n = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
	while (n >= t);
	return e[n % e.length];
}
var Ut = (e, t) => {
	if (e.public.turn !== t.rid || !e.private?.choices.length || t.signal?.aborted) return null;
	if (t.difficulty === "weak") return { action: {
		type: "choose",
		id: Ht(e.private.choices).id,
		revision: e.public.revision
	} };
	let n = Vt(e.public, e.private, t.memory, t.signal);
	return t.signal?.aborted ? null : {
		action: {
			type: "choose",
			id: n.choice.id,
			revision: e.public.revision
		},
		memory: n.memory
	};
}, Wt = (e, t, n) => {
	if (e.type !== "choose") return "";
	let r = t.private?.choices.find((t) => t.id === e.id);
	return r ? et(r, t.public, n("games.entropy.name") === Xe.name ? Xe : Ze) : n("games.entropy.errChoice");
};
//#endregion
//#region src/games/entropy/game-over.tsx
function Gt(e) {
	let { result: t, members: d, myRid: f, onPlayAgain: ee, onBackToLobby: p, hintCount: v } = e, y = e.public, b = r((e) => e.locale), x = i(), S = b === "zh" ? Xe : Ze, [C, ne] = u(!0), w = l(null), T = l(null), E = l(null);
	c(() => {
		w.current?.focus();
	}, []);
	let D = (e) => {
		ne(e), requestAnimationFrame(() => (e ? w : T).current?.focus());
	}, O = (e) => {
		let t = d.find((t) => t.rid === e);
		return t ? a(e) === null ? t.name : n(b, t.avatar) : e;
	}, k = [
		{
			label: S.scoring.vp,
			icon: "vp",
			value: (e) => e.vp
		},
		{
			label: S.scoring.life,
			icon: "life",
			value: (e) => e.life
		},
		...S.mainEvents.map((e, t) => ({
			label: e,
			icon: [
				"evolve",
				"asteroid",
				"biome"
			][t],
			value: (e) => e.main[t]
		})),
		{
			label: S.scoring.resources,
			icon: "mass",
			value: (e) => e.resources
		},
		...y.ghost ? [{
			label: S.scoring.challenges,
			icon: "vpEnd",
			value: (e) => e.challenges
		}] : []
	], A = y.ghost ? t.winner.includes(f) ? S.victory : S.defeat : t.winner.length > 1 ? S.tie : S.victory;
	return /* @__PURE__ */ h("div", {
		className: "entropy-game-over",
		children: [
			/* @__PURE__ */ m("div", {
				className: "entropy-final-board",
				inert: C,
				children: /* @__PURE__ */ m(yt, {
					public: e.public,
					private: e.private,
					members: d,
					myRid: f,
					send: () => {},
					readonly: !0
				})
			}),
			/* @__PURE__ */ h("section", {
				ref: E,
				className: "entropy-result",
				hidden: !C,
				"aria-label": S.resultsTitle,
				onKeyDown: (e) => {
					if (e.key === "Escape" && (e.stopPropagation(), D(!1)), e.key === "Tab") {
						let t = E.current?.querySelectorAll("button:not(:disabled)");
						if (!t?.length) return;
						let n = t[0], r = t[t.length - 1];
						e.shiftKey && document.activeElement === n && (e.preventDefault(), r.focus()), !e.shiftKey && document.activeElement === r && (e.preventDefault(), n.focus());
					}
				},
				children: [
					/* @__PURE__ */ h("header", {
						className: "entropy-result-top",
						children: [/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("small", { children: "ENTROPY" }), /* @__PURE__ */ m("h1", { children: S.resultsTitle })] }), /* @__PURE__ */ m("button", {
							ref: w,
							className: "entropy-close",
							type: "button",
							onClick: () => D(!1),
							"aria-label": S.viewBoard,
							title: S.viewBoard,
							children: /* @__PURE__ */ m(g, { size: 20 })
						})]
					}),
					/* @__PURE__ */ h("div", {
						className: "entropy-result-scroll",
						children: [
							/* @__PURE__ */ h("div", {
								className: "entropy-result-hero",
								children: [
									/* @__PURE__ */ m(it, {
										star: !0,
										type: 3,
										size: 90
									}),
									/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("strong", { children: A }), /* @__PURE__ */ m("p", { children: t.winner.map(O).join(" · ") || S.ghost })] }),
									/* @__PURE__ */ m(Z, {
										name: "vpEnd",
										size: 60
									})
								]
							}),
							/* @__PURE__ */ m("div", {
								className: "entropy-score-scroll",
								children: /* @__PURE__ */ h("table", {
									className: "entropy-score-table",
									style: { "--score-players": t.ranking.length },
									children: [/* @__PURE__ */ m("thead", { children: /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
										scope: "col",
										children: S.scoring.total
									}), t.ranking.map((e) => {
										let n = d.find((t) => t.rid === e);
										return /* @__PURE__ */ h("th", {
											scope: "col",
											"data-winner": t.winner.includes(e),
											style: { "--player-color": s[(n?.colorIndex ?? 0) % s.length].hex },
											children: [
												n && /* @__PURE__ */ m("img", {
													className: "entropy-result-avatar",
													src: o[n.avatar % o.length],
													alt: ""
												}),
												/* @__PURE__ */ m("span", { children: O(e) }),
												e === f && /* @__PURE__ */ m("small", { children: x("lobby.you") }),
												t.winner.includes(e) && /* @__PURE__ */ m(Z, {
													name: "vpEnd",
													size: 20
												})
											]
										}, e);
									})] }) }), /* @__PURE__ */ h("tbody", { children: [k.map((e) => /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ h("th", {
										scope: "row",
										children: [/* @__PURE__ */ m(Z, { name: e.icon }), e.label]
									}), t.ranking.map((t) => /* @__PURE__ */ m("td", { children: y.scores[t] ? e.value(y.scores[t]) : "—" }, t))] }, e.label)), /* @__PURE__ */ h("tr", {
										className: "entropy-score-total",
										children: [/* @__PURE__ */ h("th", {
											scope: "row",
											children: [/* @__PURE__ */ m(Z, { name: "vpEnd" }), S.scoring.total]
										}), t.ranking.map((e) => /* @__PURE__ */ m("td", { children: y.scores[e]?.total ?? t.scores?.[e] ?? "—" }, e))]
									})] })]
								})
							}),
							y.ghost && /* @__PURE__ */ h("div", {
								className: "entropy-result-solo",
								children: [
									/* @__PURE__ */ h("strong", { children: [
										S.ghost,
										" · ",
										y.ghostScore,
										" VP"
									] }),
									/* @__PURE__ */ h("span", { children: [
										S.scoring.challenges,
										" · ",
										y.ghost.challenges.filter((e) => e.done).length,
										"/3"
									] }),
									/* @__PURE__ */ m("p", { children: S.soloFail })
								]
							}),
							/* @__PURE__ */ h("div", {
								className: "entropy-result-notes",
								children: [v !== void 0 && /* @__PURE__ */ m("p", { children: x("session.hint.usedCount", { n: v }) }), t.ranking.map((e) => (t.autopilot?.[e] ?? 0) > 0 && /* @__PURE__ */ h("p", { children: [
									O(e),
									" · ",
									x("session.autopilot.share", { n: Math.round(t.autopilot[e] * 100) })
								] }, e))]
							})
						]
					}),
					/* @__PURE__ */ h("footer", {
						className: "entropy-result-actions",
						children: [
							ee && /* @__PURE__ */ m(te, {
								className: "entropy-primary",
								label: x("session.result.playAgain"),
								confirmLabel: S.confirmAgain,
								onConfirm: ee
							}),
							p && /* @__PURE__ */ m(te, {
								className: "entropy-close",
								label: x("session.result.backToLobby"),
								confirmLabel: S.confirmBack,
								onConfirm: p
							}),
							!ee && !p && /* @__PURE__ */ m("p", { children: x("session.result.waitHost") })
						]
					})
				]
			}),
			!C && /* @__PURE__ */ h("button", {
				ref: T,
				className: "entropy-restore entropy-primary",
				type: "button",
				onClick: () => D(!0),
				children: [/* @__PURE__ */ m(_, { size: 20 }), S.viewResults]
			})
		]
	});
}
//#endregion
//#region src/games/entropy/game-over-row.tsx
function Kt({ public: e, rid: t }) {
	let n = r((e) => e.locale) === "zh" ? Xe : Ze, i = e, a = i.scores[t];
	return a ? /* @__PURE__ */ h("div", {
		className: "mt-2 flex flex-col gap-1 text-xs",
		children: [/* @__PURE__ */ h("div", {
			className: "flex flex-wrap gap-x-3 gap-y-1",
			children: [[
				"vp",
				"life",
				"resources",
				"challenges"
			].map((e) => /* @__PURE__ */ h("span", { children: [
				n.scoring[e],
				" ",
				/* @__PURE__ */ m("strong", { children: a[e] })
			] }, e)), /* @__PURE__ */ h("span", { children: [
				n.scoring.main,
				" ",
				/* @__PURE__ */ m("strong", { children: a.main.join(" + ") })
			] })]
		}), i.ghost && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h("strong", { children: [
			n.ghost,
			": ",
			i.ghostScore,
			" VP · ",
			n.challengeCount,
			":",
			" ",
			i.ghost.challenges.filter((e) => e.done).length,
			"/3"
		] }), /* @__PURE__ */ m("p", { children: n.soloFail })] })]
	}) : null;
}
//#endregion
//#region src/games/entropy/options.tsx
function qt({ value: e, onChange: t }) {
	let n = r((e) => e.locale) === "zh" ? Xe : Ze, i = M.safeParse(e), a = i.success ? i.data : M.parse(void 0);
	return /* @__PURE__ */ h("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ m(b, {
				title: n.options.focus,
				children: [
					"random",
					"A",
					"B",
					"C",
					"D"
				].map((e) => /* @__PURE__ */ m(y, {
					name: "entropy-focus",
					value: e,
					checked: a.focus === e,
					label: e === "random" ? n.options.random : e,
					accent: se.accent,
					onChange: () => t({
						...a,
						focus: e
					})
				}, e))
			}),
			/* @__PURE__ */ m(v, {
				name: "entropy-alternative",
				value: "alternative",
				checked: a.alternative,
				label: n.options.alternative,
				onChange: () => t({
					...a,
					alternative: !a.alternative
				})
			}),
			/* @__PURE__ */ m(v, {
				name: "entropy-advanced",
				value: "advanced",
				checked: a.advanced,
				label: n.options.advanced,
				hint: n.options.advancedHint,
				onChange: () => t({
					...a,
					advanced: !a.advanced
				})
			}),
			/* @__PURE__ */ m(b, {
				title: n.options.multiplier,
				columns: 3,
				children: [
					3,
					4,
					5
				].map((e) => /* @__PURE__ */ m(y, {
					name: "entropy-multiplier",
					value: String(e),
					checked: a.ghostMultiplier === e,
					label: `×${e}`,
					onChange: () => t({
						...a,
						ghostMultiplier: e
					})
				}, e))
			}),
			/* @__PURE__ */ m(b, {
				title: n.options.progress,
				children: [
					"standard",
					"all",
					"bOnly"
				].map((e) => /* @__PURE__ */ m(y, {
					name: "entropy-progress",
					value: e,
					checked: a.progress === e,
					label: n.options[e],
					onChange: () => t({
						...a,
						progress: e
					})
				}, e))
			}),
			/* @__PURE__ */ m(v, {
				name: "entropy-double",
				value: "double",
				checked: a.doubleProgress,
				label: n.options.double,
				onChange: () => t({
					...a,
					doubleProgress: !a.doubleProgress
				})
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/entropy/entry.tsx
var Jt = {
	definition: Ye,
	View: yt,
	bot: Ut,
	describe: Wt,
	OverView: Gt,
	RowView: Kt,
	Options: qt,
	locales: {
		zh: Xe,
		en: Ze
	}
};
//#endregion
export { Jt as default };
