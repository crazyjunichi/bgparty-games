import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { useFxAnchor as a } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as l } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { PLAYER_COLORS as p } from "@bgparty/sdk/player-colors";
import { AVATARS as m } from "@bgparty/sdk/avatars";
import { FlySprite as h } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as g } from "@bgparty/sdk/confirm-button";
import { OptionSwitch as _ } from "@bgparty/sdk/ui/game-options";
//#region src/games/crewends/cards.ts
var v = [
	"blue",
	"green",
	"pink",
	"yellow",
	"helicopter"
], y = (e) => e < 36 ? Math.floor(e / 9) : 4, b = (e) => e < 36 ? e % 9 + 1 : e - 35, x = (e, t) => e === 4 ? 35 + t : e * 9 + t - 1, S = Array.from({ length: 40 }, (e, t) => t), C = [
	3,
	13,
	17,
	27,
	29,
	32
], ee = [
	2,
	12,
	14,
	19,
	24,
	31,
	34
];
function w(e) {
	let t = y(e[0]), n = (e) => y(e) === 4 ? 100 + b(e) : y(e) === t ? b(e) : -1;
	return e.reduce((t, r, i) => n(r) > n(e[t]) ? i : t, 0);
}
function T(e, t) {
	let n = t.length ? e.filter((e) => y(e) === y(t[0])) : [];
	return n.length ? n : e;
}
//#endregion
//#region src/games/crewends/meta.ts
var E = {
	id: "crewends",
	tier: "alpha",
	mechanics: ["trick-taking"],
	interactionTags: ["cooperative", "communication-limits"],
	nameKey: "games.crewends.name",
	descKey: "games.crewends.desc",
	rulesKey: "games.crewends.rules",
	icon: "🌍",
	iconImg: "games/crewends.webp",
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [3, 4],
	rulesUrl: { de: "https://www.kosmos.de/cdn/shop/files/4002051687250_DieCrew3_Anleitung_DE_web.pdf" },
	accent: "#be5b2e",
	releasedAt: "2026-11-06T19:00:00+08:00",
	search: {
		py: "xing ji tan xian dui shi jie jin tou zhi lv the crew journey to the ends of the earth",
		init: "xjtxdsjjtzl"
	},
	hotseat: "cover"
}, D = t.int().min(0).max(39), O = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("play"),
		card: D
	}),
	t.object({
		type: t.literal("communicate"),
		card: D,
		mode: t.enum([
			"high",
			"only",
			"low"
		])
	}),
	t.object({
		type: t.literal("choose"),
		value: t.string().max(160)
	}),
	t.object({
		type: t.literal("bury"),
		card: D
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), te = t.object({
	stage: t.int().min(1).max(25).catch(1),
	campaign: t.boolean().catch(!0),
	hardGhost: t.boolean().catch(!1)
}).default({
	stage: 1,
	campaign: !0,
	hardGhost: !1
}), k = t.object({
	value: t.string(),
	label: t.string(),
	n: t.number().optional(),
	seat: t.int().optional(),
	card: D.optional(),
	cards: t.array(D).optional()
}), ne = t.object({
	seat: t.int(),
	card: D
}), A = t.object({
	plays: t.array(ne),
	winner: t.int()
}), j = t.object({
	seat: t.int(),
	card: D,
	mode: t.enum([
		"high",
		"only",
		"low",
		"shown"
	])
}), M = t.object({
	phase: t.string(),
	stage: t.int(),
	round: t.int(),
	route: t.string(),
	seats: t.array(t.object({
		rid: t.string(),
		count: t.int(),
		tricks: t.int()
	})),
	guide: t.int(),
	scout: t.int(),
	driver: t.int().nullable(),
	turn: t.int().nullable(),
	leader: t.int(),
	crew: t.int(),
	elapsed: t.int(),
	timeLeft: t.int(),
	overtime: t.int(),
	task: t.int().nullable(),
	owner: t.int().nullable(),
	stacks: t.array(t.object({
		difficulty: t.int().nullable(),
		special: t.boolean(),
		random: t.boolean(),
		count: t.int(),
		discarded: t.boolean()
	})),
	tokens: t.int(),
	comms: t.array(j),
	plays: t.array(ne),
	last: A.nullable(),
	trickNumber: t.int(),
	trickLimit: t.int(),
	deckCount: t.int(),
	removed: t.array(D),
	ghost: t.array(D.nullable()),
	ghostCovered: t.array(t.boolean()),
	prompt: t.string().nullable(),
	waiting: t.array(t.int()),
	votes: t.array(t.boolean()).nullable(),
	parameters: t.record(t.string(), t.number()),
	board: t.array(D.nullable()),
	markers: t.array(t.int()),
	river: t.int(),
	flights: t.array(t.int()),
	towers: t.array(t.array(D)),
	clockStart: t.int().nullable(),
	subtask: t.int(),
	attempt: t.int(),
	subResults: t.array(t.boolean()),
	firstTry: t.boolean(),
	riverDeal: t.int(),
	roundSuccess: t.boolean().nullable(),
	movement: t.int(),
	cumulative: t.int().nullable(),
	score: t.int().nullable(),
	scores: t.array(t.object({
		stage: t.int(),
		score: t.int()
	})),
	chicago: t.boolean(),
	chicagoAttempt: t.int(),
	specialFailure: t.boolean(),
	notice: t.string().nullable(),
	revealCard: D.nullable()
}), N = t.object({
	hand: t.array(D),
	seat: t.int(),
	controlledSeat: t.int().nullable(),
	choiceSeat: t.int(),
	legal: t.array(D),
	communications: t.array(t.object({
		card: D,
		mode: t.enum([
			"high",
			"only",
			"low"
		])
	})),
	choices: t.array(k),
	selected: t.string().nullable(),
	secrets: t.record(t.string(), t.number()),
	hiddenCard: D.nullable(),
	burials: t.array(D)
}), P = (e, t) => Array.from({ length: t }, () => e), F = (e, t, n = [], r = 2) => ({
	spaces: e,
	time: t,
	stops: n,
	stacks: r
}), I = [
	5,
	8,
	11,
	14,
	16,
	19,
	20,
	23,
	25
], re = [
	5,
	11,
	16,
	20,
	23
], L = [
	[
		"Aachen – Constance",
		"亚琛—康斯坦茨",
		{ A: F(P("train", 7), 2) }
	],
	[
		"Appenzell – Davos",
		"阿彭策尔—达沃斯",
		{ A: F([
			...P("foot", 7),
			"train",
			"foot"
		], 3) }
	],
	[
		"St. Moritz – Milan",
		"圣莫里茨—米兰",
		{ A: F([...P("ski", 5), ...P("scooter", 5)], 5, [4]) }
	],
	[
		"Verona – Venice",
		"维罗纳—威尼斯",
		{ A: F([...P("scooter", 7), ...P("bicycle", 5)], 7) }
	],
	[
		"Pompeii",
		"庞贝",
		{}
	],
	[
		"Rome – Athens",
		"罗马—雅典",
		{ A: F([
			...P("bicycle", 6),
			"fog6",
			"fog7",
			...P("helicopter", 3)
		], 6, [7]) }
	],
	[
		"Piraeus – Alexandria",
		"比雷埃夫斯—亚历山大",
		{ A: F([
			"fog7",
			"fog6",
			"fog7",
			"fog6",
			"fog5",
			"fog7",
			...P("storm", 5)
		], 6, [6]) }
	],
	[
		"Africa",
		"非洲",
		{}
	],
	[
		"Cairo – Riyadh",
		"开罗—利雅得",
		{ A: F([
			...P("donkey", 5),
			"helicopter",
			...P("donkey", 4)
		], 5) }
	],
	[
		"Delhi – Jim Corbett",
		"德里—吉姆·科比特",
		{ A: F([...P("jeep", 8), ...P("machete", 5)], 7, [8]) }
	],
	[
		"Mount Everest",
		"珠穆朗玛峰",
		{}
	],
	[
		"Himalayas – Kathmandu",
		"喜马拉雅山—加德满都",
		{ A: F([
			...P("dog", 5),
			"ski",
			"ski",
			"helicopter",
			"donkey",
			...P("helicopter", 4),
			"dog",
			"dog"
		], 10) }
	],
	[
		"Chandragiri – Lhasa",
		"旃陀罗耆厘—拉萨",
		{ A: F([
			...P("cable", 4),
			"glider",
			"helicopter",
			...P("glider", 7)
		], 8) }
	],
	[
		"Macao",
		"澳门",
		{}
	],
	[
		"Sydney – Buenos Aires",
		"悉尼—布宜诺斯艾利斯",
		{
			A: F(P("storm", 12), 8),
			A2: F([
				...P("storm", 7),
				"fog4",
				"storm",
				"storm"
			], 6, [7]),
			B: F([
				"fog5",
				"fog4",
				"fog6",
				"fog5",
				"fog5",
				"fog7",
				"fog5",
				"fog6",
				"fog5",
				"fog6"
			], 6)
		}
	],
	[
		"Machu Picchu",
		"马丘比丘",
		{}
	],
	[
		"Sugarloaf – Rio",
		"糖面包山—里约热内卢",
		{ A: F([
			...P("cable", 7),
			"bicycle",
			"bicycle",
			...P("helicopter", 5)
		], 9) }
	],
	[
		"Brazilian Rainforest",
		"巴西雨林",
		{ A: F([
			"jeep",
			"jeep",
			"jeep",
			"machete",
			"donkey",
			"machete",
			"glider",
			"machete",
			"glider",
			"donkey",
			"machete",
			"glider",
			"machete",
			"glider",
			"machete"
		], 6, [3]) }
	],
	[
		"Amazon Rainforest",
		"亚马孙雨林",
		{}
	],
	[
		"Route 66",
		"66号公路",
		{}
	],
	[
		"Juneau – Dawson City",
		"朱诺—道森市",
		{
			A: F([
				"helicopter",
				"storm",
				"storm",
				"storm",
				"donkey",
				"storm",
				"fog6",
				"fog5",
				"storm",
				"donkey",
				"storm",
				"storm",
				"storm",
				"donkey",
				"storm",
				"fog6",
				"storm",
				"dog",
				"fog5",
				"storm"
			], 12),
			B: F(["helicopter", ...P("ice", 6)], -1, [
				1,
				2,
				3,
				4,
				6
			], 1),
			C: F([
				"helicopter",
				"foot",
				"helicopter",
				"helicopter",
				"cracked",
				"glider",
				"glider",
				"helicopter",
				"cracked",
				"foot",
				"foot",
				"foot",
				"cracked",
				"foot",
				"cracked",
				"foot",
				"foot",
				"dog",
				"fog5",
				"storm"
			], 12, [], 3)
		}
	],
	[
		"Kulusuk – Tasiilaq",
		"库鲁苏克—塔西拉克",
		{ A: F([
			"dog",
			"ice",
			"ice",
			"cracked",
			"ski",
			"ice",
			"cracked",
			"ski",
			"ice",
			"cracked",
			"ski",
			"dog",
			"cracked",
			"ice"
		], 8) }
	],
	[
		"London",
		"伦敦",
		{}
	],
	[
		"Inverness – Paris",
		"因弗内斯—巴黎",
		{ A: F([
			"scooter",
			"glider",
			"glider",
			"glider",
			"fog5",
			"storm",
			"helicopter",
			"ski",
			"cable",
			"cable",
			"dog",
			"bicycle",
			"bicycle",
			"machete",
			"jeep",
			"helicopter"
		], 2, [
			0,
			3,
			4,
			5,
			6,
			7,
			9,
			10,
			12,
			13,
			14,
			15
		]) }
	],
	[
		"Paris Catacombs",
		"巴黎地下墓穴",
		{}
	]
].map(([e, t, n], r) => ({
	id: r + 1,
	name: e,
	zh: t,
	routes: n,
	special: I.includes(r + 1),
	triple: re.includes(r + 1)
})), R = [
	0,
	1,
	2,
	5,
	8,
	7,
	6,
	3,
	4
], ie = [
	[
		0,
		1,
		-1,
		1,
		-1,
		-1,
		0,
		1
	],
	[
		0,
		-1,
		-1,
		0,
		1,
		1,
		1,
		-1
	],
	[
		0,
		-1,
		-1,
		-1,
		-1,
		-1,
		0,
		-1
	]
], ae = [
	[
		19,
		7,
		25,
		24,
		18,
		6,
		10,
		4,
		23
	],
	[
		9,
		31,
		28,
		26,
		11,
		7,
		10,
		27,
		19
	],
	[
		21,
		12,
		15,
		29,
		36,
		19,
		17,
		30,
		25
	]
], oe = [
	[1470, 258],
	[1020, 342],
	[1238, 580],
	[1425, 432],
	[924, 133],
	[995, 538],
	[1548, 773],
	[1200, 352]
], z = {
	goal: 17,
	crocodiles: [
		3,
		5,
		6,
		9,
		10,
		12,
		14
	]
}, se = [
	[2, 0],
	[3],
	[1],
	[2],
	[0],
	[3],
	[2, 1],
	[4],
	[1]
], B = [
	0,
	1,
	2,
	0,
	3,
	0,
	6,
	0,
	9
];
function ce(e, t) {
	if (!e.length) return !1;
	let n = oe[e[e.length - 1] - 1], r = oe[t - 1], i = (e, t, n) => (t[0] - e[0]) * (n[1] - e[1]) - (t[1] - e[1]) * (n[0] - e[0]);
	return e.slice(1).some((a, o) => {
		let s = e[o];
		if ([s, a].includes(e[e.length - 1]) || [s, a].includes(t)) return !1;
		let c = oe[s - 1], l = oe[a - 1];
		return i(n, r, c) * i(n, r, l) < 0 && i(c, l, n) * i(c, l, r) < 0;
	});
}
var le = [
	["111", 0],
	["333", 0],
	["322", 1],
	["222", 0],
	["111", 0],
	[
		"S",
		0,
		"-1,-1,-1"
	],
	["334", 0],
	["444", 0],
	["555", 0],
	["334", 0],
	[
		"S",
		0,
		"-5,-3,-2"
	],
	[
		"S",
		0,
		"-5,-2,0"
	],
	["R544", 0],
	["323", 0],
	["R634", 0],
	[
		"S",
		0,
		"-8,-4,-2"
	],
	["456", 1],
	["R323", 0],
	["R111", 0],
	["121", 0],
	["333", 1],
	["633", 1],
	[
		"S",
		0,
		"0,0,0"
	],
	[
		"S",
		0,
		"-9,-6,-4"
	],
	["322", 0],
	["323", 0],
	[
		"S",
		0,
		"-6,-5,-3"
	],
	[
		"S",
		0,
		"0,0,0"
	],
	[
		"S",
		0,
		"0,0,0"
	],
	["123", 0],
	[
		"S",
		0,
		"0,0,0"
	],
	["334", 1],
	["222", 0],
	["655", 0],
	["333", 0],
	["332", 1],
	["344", 0],
	["322", 0],
	["222", 0],
	["323", 0],
	["235", 0],
	["345", 0],
	["333", 0],
	["633", 0],
	["R356", 0],
	["222", 0],
	["122", 0],
	["234", 1],
	["234", 0],
	["354", 1],
	["222", 1],
	["222", 0],
	["345", 1],
	["334", 0],
	["445", 0],
	["233", 0],
	[
		"S",
		0,
		"0,0,0"
	],
	[
		"S",
		0,
		"-4,-3,-3"
	],
	["234", 0],
	["666", 0],
	["123", 0],
	["R243", 0],
	["321", 0],
	["R222", 0],
	["234", 0],
	["556", 1],
	["232", 0],
	["236", 1],
	["345", 0],
	[
		"S",
		0,
		"0,0,0"
	],
	["433", 0],
	["555", 1],
	["122", 0],
	["454", 0],
	["366", 0],
	["222", 0],
	["234", 1],
	["345", 0],
	["122", 0],
	["111", 1],
	["111", 0],
	["R322", 0],
	[
		"S",
		0,
		"-4,-2,-1"
	],
	[
		"S",
		0,
		"-7,-2,0"
	],
	[
		"S",
		0,
		"-6,-3,0"
	],
	[
		"S",
		0,
		"-5,-2,0"
	],
	[
		"RS",
		0,
		"-6,-3,-2"
	],
	[
		"S",
		0,
		"-6,-4,-2"
	],
	[
		"RS",
		0,
		"-4,-1,0"
	],
	[
		"S",
		0,
		"-7,-5,-3"
	],
	["322", 0],
	["222", 0],
	["222", 0],
	["222", 1],
	["111", 0],
	["433", 0],
	[
		"S",
		1,
		"-3,-2,-1"
	],
	[
		"S",
		1,
		"-2,-2,0"
	],
	[
		"S",
		1,
		"-3,-1,0"
	],
	[
		"S",
		1,
		"-4,-2,0"
	],
	[
		"S",
		1,
		"-2,-2,0"
	],
	["445", 0],
	["544", 0],
	["456", 0]
].map(([e, t, n], r) => ({
	id: r + 1,
	difficulty: e.replace(/[RS]/g, "").split("").map(Number),
	individual: !!t,
	special: e.includes("S"),
	random: e.includes("R"),
	offsets: n?.split(",").map(Number) ?? [
		0,
		0,
		0
	],
	double5: r === 83
})), V = (e) => le[e - 1], ue = (e, t) => V(e).special ? 3 : V(e).difficulty[t - 3];
function de(e) {
	let { id: t, seats: n, guide: r, owner: i, history: a, params: o, final: s } = e, c = V(t), l = n - 3, u = (e) => e.plays.map((e) => b(e.card)), d = (e) => e.plays.map((e) => y(e.card)), f = (e) => u(e).reduce((e, t) => e + t, 0), p = (e) => e.plays[0].card, m = (e) => e.plays[e.plays.length - 1].card, h = (e) => e.plays[w(e.plays.map((e) => e.card))].card, g = (e) => a.filter((t) => t.winner === e).flatMap((e) => e.plays.map((e) => e.card)), _ = (e, t) => g(e).filter((e) => y(e) === t).length, v = (e) => a.filter((t) => t.winner === e).length, S = Array.from({ length: n }, (e, t) => t), C = (r + 1) % n, ee = (r + n - 1) % n, T = n === 3 && o.two === 1 ? r : C, E = n === 3 && o.two === 1 ? o.scout : ee, D = (e) => new Set(e).size, O = (e, t) => e.slice(1).some((n, r) => t(e[r], n)), te = (e, t) => a.some((n, r) => a.slice(r, r + e).length === e && a.slice(r, r + e).every(t)), k = !0, ne = !1, A = 0, j = (e) => {
		k = a.every(e), ne = !k;
	}, M = (e) => {
		k = a.some(e);
	}, N = (e) => {
		A = a.filter(e).length;
	}, P = (e) => {
		let t = a.findIndex((t, n) => !e(t, n));
		A = t < 0 ? a.length : t, ne = t >= 0;
	};
	switch (t) {
		case 1:
			j((e) => !O(d(e), (e, t) => e === 0 && t === 1));
			break;
		case 2:
			j((e) => !u(e).some((e, t, n) => t >= 2 && n[t] % 2 == 0 && n[t - 1] % 2 == 0 && n[t - 2] % 2 == 0));
			break;
		case 3:
			k = v(i) === o["pred:" + i];
			break;
		case 4:
			M((e) => h(e) === 37);
			break;
		case 5:
			j((e) => b(p(e)) < 8);
			break;
		case 6:
			A = S.filter((e) => _(e, 2) > 0).length;
			break;
		case 7:
		case 102:
			k = v(r) === o.sum;
			break;
		case 8:
			k = _(o.neighbor, 1) === 3 && _(o.neighbor === C ? ee : C, 1) !== 3;
			break;
		case 9:
		case 10:
			k = _(r, 2) === o.sum;
			break;
		case 11:
			N((e) => u(e).some((t) => u(e).filter((e) => e === t).length === 2));
			break;
		case 12:
			N((e) => u(e).every((e) => e > 2));
			break;
		case 13:
		case 103:
			j((e) => y(h(e)) === 4 || b(h(e)) % 2 == 0);
			break;
		case 14:
			k = S.some((e) => g(e).filter((e) => y(e) === 2).reduce((e, t) => e + b(t), 0) === 10);
			break;
		case 15:
			j((e) => b(m(e)) % 2 == 0);
			break;
		case 16:
			N((e) => !O(u(e), (e, t) => e % 2 == 1 && t % 2 == 1));
			break;
		case 17:
			k = a.every((e, t) => e.winner === i === [
				0,
				2,
				4,
				6
			].includes(t)) && a.length >= 7;
			break;
		case 18:
			j((e) => y(m(e)) !== 2);
			break;
		case 19:
			j((e) => !(d(e).includes(2) && d(e).includes(0)));
			break;
		case 20:
			j((e) => !(d(e).includes(2) && (d(e).includes(0) || d(e).includes(1))));
			break;
		case 21:
			k = a.every((e, t) => e.winner !== r || t + 1 < a.length && a[t + 1].winner === i);
			break;
		case 22:
			k = v(i) === 1 && g(i).includes(x(3, 4));
			break;
		case 23:
			N((e) => f(e) <= [
				8,
				13,
				18
			][l]);
			break;
		case 24:
			N((e) => b(e.plays[1].card) > b(p(e)));
			break;
		case 25:
			j((e) => u(e).some((e) => e % 2 == 0) && u(e).some((e) => e % 2 == 1));
			break;
		case 26:
			j((e) => b(m(e)) < Math.max(...u(e)));
			break;
		case 27:
			P((e, t) => t < 9 && u(e).includes(t + 1));
			break;
		case 28:
			A = S.filter((e) => _(e, 1) > _(e, 3)).length;
			break;
		case 29:
			A = S.filter((e) => v(e) === o["pred:" + e]).length;
			break;
		case 30:
			k = a.some((e, t) => t + 2 < a.length && a.slice(t, t + 3).every((e) => u(e).filter((t) => t === Math.max(...u(e))).length === 1) && Math.max(...u(a[t])) < Math.max(...u(a[t + 1])) && Math.max(...u(a[t + 1])) < Math.max(...u(a[t + 2])));
			break;
		case 31:
			A = S.filter((e) => _(e, 2) === o["pred:" + e]).length;
			break;
		case 32:
			k = _(i, 3) === o["pred:" + i];
			break;
		case 33:
			j((e) => y(h(e)) !== 2);
			break;
		case 34:
			j((e) => ![0, 1].includes(y(h(e))));
			break;
		case 35:
			k = v(C) > 0 && v(r) === 2 * v(C);
			break;
		case 36:
			k = v(i) === 3 && a.filter((e) => e.winner === i).every((e) => e.plays[0].seat !== i);
			break;
		case 37:
			k = _(T, o.color) === o.number && _(E, o.color) === o.number;
			break;
		case 38:
			k = v(C) > 0 && v(C) === v(ee);
			break;
		case 39:
			j((e) => d(e).filter((e) => e === 0).length <= 2);
			break;
		case 40:
			k = S.every((e) => D(g(e).map(y).filter((e) => e !== 4)) < 4);
			break;
		case 41:
			k = S.every((e) => _(e, 3) > 0);
			break;
		case 42:
			j((e, t) => y(p(e)) !== 1 && (!s || t < a.length - 1 || !d(e).includes(1)));
			break;
		case 43:
			j((e) => !O(d(e), (e, t) => e === 2 && t === 2));
			break;
		case 44:
			j((e) => y(p(e)) !== 0 && y(m(e)) !== 0);
			break;
		case 45:
			k = Math.max(...S.map((e) => _(e, 2))) - Math.min(...S.map((e) => _(e, 2))) <= 1;
			break;
		case 46:
			j((e) => y(p(e)) !== 4 && y(m(e)) !== 4);
			break;
		case 47:
			j((e) => y(e.plays[1].card) !== 4);
			break;
		case 48:
			k = g(i).includes(o.target0);
			break;
		case 49:
			k = S.every((e) => _(e, 1) !== _(e, 3));
			break;
		case 50:
			k = g(i).filter((e) => b(e) === 1).length === 5;
			break;
		case 51:
			k = [
				x(1, 7),
				x(2, 2),
				x(3, 1)
			].every((e) => g(i).includes(e));
			break;
		case 52:
			M((e) => h(e) === 37 && d(e).includes(2));
			break;
		case 53:
			k = [o.target0, o.target1].every((e) => g(i).includes(e));
			break;
		case 54:
		case 55:
			k = S.every((e) => v(e) === o["pred:" + e]);
			break;
		case 56:
			M((e) => y(p(e)) !== 4 && f(e) <= [
				5,
				8,
				12
			][l]);
			break;
		case 57:
			N((e) => f(e) >= [
				16,
				20,
				24
			][l] && f(e) <= [
				17,
				21,
				26
			][l]);
			break;
		case 58:
			N((e) => d(e).includes(0));
			break;
		case 59:
			k = a.length > 0 && m(a[a.length - 1]) === x(1, 4);
			break;
		case 60:
			j((e) => ![2, 3].includes(y(p(e))));
			break;
		case 61:
			M((e) => e.plays.filter((e) => y(e.card) === 1).reduce((e, t) => e + b(t.card), 0) === 6);
			break;
		case 62:
			M((e) => e.plays.filter((e) => y(e.card) === 3).reduce((e, t) => e + b(t.card), 0) === 13);
			break;
		case 63:
			j((e) => Math.max(...u(e)) - Math.min(...u(e)) >= 4);
			break;
		case 64:
			j((e) => y(p(e)) !== 3);
			break;
		case 65:
			j((e) => D(d(e).filter((e) => e < 4)) <= 2);
			break;
		case 66:
			k = _(i, 0) > 0 && D([
				0,
				1,
				2,
				3
			].map((e) => _(i, e))) === 1;
			break;
		case 67:
			j((e) => u(e).some((e) => e <= 2));
			break;
		case 68:
			k = D(a.filter((e) => e.winner === i).map(h).map(y).filter((e) => e < 4)) === 4;
			break;
		case 69:
			k = g(o.player0).includes(o.target0) && g(o.player1).includes(o.target1);
			break;
		case 70:
			A = S.filter((e) => v(e) % 2 == 1).length;
			break;
		case 71:
		case 91:
			k = _(T, o.color) === 0 && _(E, o.color) === 0;
			break;
		case 72:
			k = S.every((e) => e === i || v(e) === 1);
			break;
		case 73: {
			let e = S.map((e) => g(e).filter((e) => b(e) === 5).length);
			k = Math.max(...e) - Math.min(...e) <= 1;
			break;
		}
		case 74:
			k = S.every((e) => o["forbid:" + e] === void 0 || _(e, o["forbid:" + e]) === 0);
			break;
		case 75:
			k = S.every((e) => [
				0,
				1,
				2,
				3
			].every((t) => _(e, t) > 0));
			break;
		case 76:
			j((e) => y(h(e)) === 4 || b(h(e)) >= 7);
			break;
		case 77:
			k = D([
				0,
				1,
				2,
				3
			].map((e) => _(i, e))) === 4;
			break;
		case 78:
			k = S.every((e) => _(e, 0) === _(e, 2));
			break;
		case 79:
			k = te(5, (e) => [
				3,
				6,
				9
			].includes(b(p(e))));
			break;
		case 80:
			k = [
				0,
				1,
				2,
				3
			].every((e) => _(i, e) > 0);
			break;
		case 81:
			k = a.length > 0 && u(a[a.length - 1]).every((e) => e >= 5);
			break;
		case 82:
			j((e, t) => t === 0 || e.winner !== a[t - 1].winner);
			break;
		case 83:
			N((e) => {
				let t = u(e).sort((e, t) => e - t);
				return t.every((e, n) => n === 0 || e === t[n - 1] + 1);
			});
			break;
		case 84:
			N((e) => u(e).every((e, t, n) => t === 0 || e > n[t - 1]));
			break;
		case 85:
			P((e, t) => t === 0 || e.winner === (a[t - 1].winner + 1) % n);
			break;
		case 86:
			N((e) => b(h(e)) <= 5);
			break;
		case 87:
			N((e) => h(e) === m(e));
			break;
		case 88:
			N((e) => b(h(e)) % 3 == 0);
			break;
		case 89:
			N((e) => u(e).every((e) => e % 3 != 0));
			break;
		case 90:
			N((e) => b(h(e)) % 2 == 0);
			break;
		case 92:
			k = v(n === 3 && o.two === 1 ? o.scout : C) + v(r) === o.number;
			break;
		case 93:
			k = S.every((e) => {
				let t = a.flatMap((t, n) => t.winner === e ? [n] : []);
				return !t.length || t[t.length - 1] - t[0] + 1 === t.length;
			});
			break;
		case 94:
			k = [x(0, 8), x(3, 5)].every((e) => g(i).includes(e));
			break;
		case 95:
			k = a.length > 0 && d(a[a.length - 1]).filter((e) => e === o.color).length >= 3;
			break;
		case 96:
			k = o.guess === o.missing;
			break;
		case 97:
			P((e) => e.winner !== i || b(m(e)) > Math.min(...u(e)));
			break;
		case 98:
			P((e) => e.winner !== i || u(e).filter((e) => e % 2 == 0).length === 2);
			break;
		case 99:
			P((e) => e.winner !== i || u(e).filter((e) => e < 5).length === 2);
			break;
		case 100:
			P((e) => e.winner !== i || D(d(e)) <= 2);
			break;
		case 101:
			P((e) => e.winner !== i || D(u(e)) < u(e).length);
			break;
		case 104: j((e) => !e.plays.some((e, t, n) => t > 0 && y(e.card) !== 4 && y(n[t - 1].card) !== 4 && b(e.card) % 2 == 1 && b(n[t - 1].card) % 2 == 1));
	}
	let F = c.special ? Math.max(0, A * (c.double5 && n === 5 ? 2 : 1) + c.offsets[l]) : k ? ue(t, n) : 0;
	return {
		success: s && (c.special ? F > 0 : k),
		movement: s ? F : 0,
		raw: A,
		failed: ne
	};
}
//#endregion
//#region src/games/crewends/rules.ts
var fe = {
	reveal: 900,
	collect: 600,
	result: 700,
	movement: 650
}, H = (e) => e.seats.map((e, t) => t), pe = (e, t) => t === 2 && e.players.length === 2 ? e.players[e.scout] : e.seats[t], me = (e) => L[e.stage - 1].routes[e.route], U = (e) => me(e)?.spaces[e.crew] ?? "train", W = (e) => L[e.stage - 1].special, he = (e) => e.owner ?? e.guide, G = () => ({ code: "games.crewends.errAction" });
function K(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
var q = (e, t, n = {}) => ({
	value: e,
	label: t,
	...n
}), ge = (e, t, n = "number") => Array.from({ length: t - e + 1 }, (t, r) => q(String(r + e), n, { n: r + e })), _e = (e = []) => ge(0, 3, "color").filter((t) => !e.includes(t.n)), ve = (e, t = "person") => e.map((e) => q(String(e), t, { seat: e })), ye = (e, t = "card") => e.map((e) => q(String(e), t, { card: e }));
function J(e, t, n, r) {
	e.prompt = {
		kind: t,
		actors: n,
		options: Object.fromEntries(n.map((e) => [e, typeof r == "function" ? r(e) : r])),
		answers: {}
	}, e.phase = "decision";
}
var be = (e, t) => t === 2 && e.players.length === 2 ? e.ghost.filter((e) => e !== null) : e.hands[t], Y = (e, t) => t === 2 && e.players.length === 2 ? e.ghost.filter((e) => e !== null).length + e.ghostBottom.filter((e) => e !== null).length : e.hands[t]?.length ?? 0;
function xe(e, t, n) {
	if (t === 2 && e.players.length === 2) {
		let t = e.ghost.indexOf(n);
		e.ghost[t] = null;
	} else e.hands[t].splice(e.hands[t].indexOf(n), 1);
}
function Se(e, t, n, r = []) {
	if (t === 2 && e.players.length === 2) for (let t of n) {
		let n = r.shift() ?? e.ghost.findIndex((t, n) => t === null && e.ghostBottom[n] === null);
		n >= 0 && (e.ghost[n] = t);
	}
	else e.hands[t].push(...n);
}
function Ce(e) {
	e.players.length === 2 && (e.ghost = e.ghost.map((t, n) => {
		if (t === null && e.ghostBottom[n] !== null) {
			let t = e.ghostBottom[n];
			return e.ghostBottom[n] = null, t;
		}
		return t;
	}));
}
function we(e, t) {
	if (e.stacks.length === t && e.stacks.every((e) => e.length > 1)) return;
	let n = K(e, [...e.stacks.flat(), ...e.used]);
	e.used = [], e.stacks = Array.from({ length: t }, () => []), n.forEach((n, r) => e.stacks[r % t].push(n)), e.discarded.length !== t && (e.discarded = Array.from({ length: t }, () => !1));
}
function Te(e) {
	if (W(e)) {
		X(e), Z(e);
		return;
	}
	if (we(e, e.stage === 21 && !e.routeSelected ? 2 : me(e).stacks), U(e) === "dog" && e.driver === null) {
		J(e, "driver", [e.guide], ve(H(e)));
		return;
	}
	e.phase = "select", e.prompt = null, e.task = null, e.owner = null, e.notice = null;
}
function Ee(e) {
	e.crew = 0, e.elapsed = 0, e.overtime = 0, e.score = null, e.roundSuccess = null, e.round = 0, e.task = null, e.owner = null, e.driver = null, e.subtask = 0, e.attempt = 1, e.subResults = [], e.firstTry = !0, e.chicago = !1, e.chicagoAttempt = 0, e.riverDeal = 1, e.discarded = e.stacks.map(() => !1);
	let t = Object.keys(L[e.stage - 1].routes).filter((e) => e !== "A2");
	if (e.route = t[0] ?? "A", e.routeSelected = !1, t.length > 1 && e.stage !== 21) {
		J(e, "route", [0], t.map((e) => q(e, "route")));
		return;
	}
	Te(e);
}
function X(t, n = !1) {
	let r = t.guide, i = t.task === 69 ? [t.params.player0, t.params.player1] : [];
	n || (t.round++, t.params = {
		two: +(t.players.length === 2),
		scout: t.scout
	}, i[0] !== void 0 && (t.params.player0 = i[0], t.params.player1 = i[1]), t.publicParams = t.task === 69 && i[0] !== void 0 ? {
		player0: i[0],
		player1: i[1]
	} : {}, t.board = Array.from({ length: 9 }, () => null), t.markers = [], t.flights = [1], t.towers = [[], []], t.clockStart = null, t.river = t.seats.length - 3, t.riverDeal = 1), t.hands = t.seats.map(() => []), t.draw = [], t.removed = [], t.ghost = [], t.ghostBottom = [], t.ghostPlayed = null, t.history = [], t.last = null, t.plays = [], t.tokens = t.players.length, t.comms = [], t.buried = t.seats.map(() => null), t.failed = !1, t.notice = null, t.revealCard = null, t.roundSuccess = null, t.movement = 0, t.votes = null, t.preStep = 0, t.postStep = 0;
	let a = K(t, S);
	if (t.task === 48 || t.task === 53 || t.task === 69) {
		let e = K(t, S.filter((e) => e < 36));
		t.params.target0 = e[0], t.params.target1 = e[1];
	}
	t.task === 96 && (t.params.missing = a.shift()), W(t) && ![19, 20].includes(t.stage) && t.players.length === 3 && (t.removed = a.filter((e) => e !== 39).slice(0, 7), a = a.filter((e) => !t.removed.includes(e)));
	let o = U(t).startsWith("fog") && !W(t) ? Number(U(t).slice(3)) : null;
	if (t.players.length === 2) {
		let e = t.task !== 96;
		e && (a = a.filter((e) => e !== 39));
		let n = a.splice(0, t.task === 96 ? 13 : 14);
		t.ghostBottom = [...n.slice(0, n.length - 7), ...t.task === 96 ? [null] : []], t.ghost = n.slice(-7), e && (a = K(t, [...a, 39]));
		let r = o ?? 13;
		for (let e = 0; e < r; e++) for (let e = 0; e < 2; e++) a.length && t.hands[e].push(a.shift());
		if (o && !t.hands.flat().includes(39) && a.includes(39)) {
			let e = a.indexOf(39);
			[a[e], t.hands[0][0]] = [t.hands[0][0], a[e]];
		}
		if (o && a.length) {
			let e = t.hands.findIndex((e) => e.includes(39));
			t.hands[e >= 0 ? e : 0].push(a.shift());
		}
		t.draw = a;
	} else if (o !== null) {
		let n = o * t.seats.length;
		if (a.indexOf(39) >= n) {
			let r = e(t.seed, t.cursor++, n), i = a.indexOf(39);
			[a[r], a[i]] = [a[i], a[r]];
		}
		for (let e = 0; e < o; e++) for (let e of H(t)) t.hands[e].push(a.shift());
		let r = t.hands.findIndex((e) => e.includes(39));
		t.seats.length === 3 && t.hands[r].push(a.shift()), t.draw = a;
	} else a.forEach((e, n) => t.hands[n % t.seats.length].push(e));
	let s = t.hands.findIndex((e) => e.includes(39));
	if (t.guide = s >= 0 ? s : Math.min(t.guide, t.players.length - 1), t.scout = t.players.length === 2 ? 1 - t.guide : 0, t.params.scout = t.scout, t.leader = t.task === 96 ? r : t.guide, t.turn = t.leader, t.limit = t.task === 96 ? Math.ceil(39 / t.seats.length) : Math.floor(40 / t.seats.length), W(t) && (t.limit = t.stage === 11 ? 8 : [
		5,
		16,
		23,
		25
	].includes(t.stage) ? 9 : t.players.length === 5 && ![19, 20].includes(t.stage) ? 10 : Math.floor((t.players.length === 3 && ![19, 20].includes(t.stage) ? 33 : 40) / t.seats.length)), t.task === 67 && t.seats.length === 3 && (t.limit = 10), t.task === 27 && (t.limit = Math.min(t.limit, 9)), t.task === 7 && t.hands[t.guide].filter((e) => y(e) === 4).length === 4) {
		X(t, n);
		return;
	}
}
function De(e, t) {
	if (e.task = e.stacks[t].shift(), e.used.push(e.task), e.owner = null, e.params = {}, e.task === 69 && e.players.length > 2) {
		J(e, "targetPeople", [e.guide], H(e).flatMap((t) => H(e).filter((e) => e > t).map((e) => q(`${t},${e}`, "pair", {
			seat: t,
			n: e
		}))));
		return;
	}
	X(e), Z(e);
}
function Oe(e) {
	if (e.task === null) return !0;
	let t = e.task, n = e.seats.length, r = e.guide, i = he(e), a = (r + 1) % n, o = (r + n - 1) % n, s = e.players.length === 2;
	if ([
		7,
		9,
		10,
		102
	].includes(t) && e.params.sum === void 0) {
		let n = t === 7 ? 3 : t === 9 ? 5 : 4, r = K(e, Array.from({ length: n }, (e, t) => t + 1));
		e.params.sum = r[0] + r[1];
	}
	if ([
		3,
		29,
		31,
		32,
		54,
		55
	].includes(t)) {
		let a = [3, 32].includes(t) ? [i] : H(e), o = ([54, 55].includes(t) ? H(e).map((e) => (e + r) % n) : a).filter((t) => e.params["declared:" + t] === void 0);
		if (o.length) return J(e, "prediction", [54, 55].includes(t) ? [o[0]] : o, ge(+(t === 32), t === 32 ? 8 : t === 31 ? 9 : e.limit)), !1;
	}
	if (t === 8 && e.params.neighbor === void 0) return J(e, "neighbor", [r], ve([a, o])), !1;
	if ([
		37,
		71,
		91,
		95
	].includes(t) && e.params.color === void 0) return J(e, "color", [s && [
		37,
		71,
		91
	].includes(t) || t === 95 ? r : a], _e()), !1;
	if (t === 37 && e.params.number === void 0) return J(e, "number", [s ? e.scout : o], ge(0, 9)), !1;
	if (t === 69 && e.params.player0 === void 0) {
		if (s) e.params.player0 = r, e.params.player1 = e.scout;
		else return J(e, "targetPeople", [r], H(e).flatMap((t) => H(e).filter((e) => e > t).map((e) => q(`${t},${e}`, "pair", {
			seat: t,
			n: e
		})))), !1;
	}
	if (t === 74) {
		let t = H(e).map((e) => (e + r) % n).slice(0, 4).find((t) => e.params["forbid:" + t] === void 0);
		if (t !== void 0) return J(e, "forbid", [t], _e(Object.entries(e.params).filter(([e]) => e.startsWith("forbid:")).map(([, e]) => e))), !1;
	}
	if (t === 92 && e.params.number === void 0) {
		let t = s ? e.scout : a;
		return J(e, "show", [t], ye(be(e, t))), !1;
	}
	return !0;
}
function Z(e) {
	if (e.preStep === 0) {
		if (e.task !== null && V(e.task).individual && e.owner === null) {
			if (e.players.length === 2 && [
				32,
				48,
				53
			].includes(e.task)) e.owner = e.guide;
			else {
				J(e, "vote", H(e), [q("yes", "yes"), q("no", "no")]);
				return;
			}
		}
		e.preStep = 1;
	}
	if (e.preStep === 1) {
		if (!Oe(e)) return;
		e.preStep = 2;
	}
	if (e.preStep === 2) {
		if (U(e) === "scooter" && !W(e)) {
			let t = H(e).find((t) => be(e, t).includes(0));
			if (t !== void 0) {
				e.params.scooter = t, J(e, "scooterPartner", [t], ve(H(e).filter((e) => e !== t)));
				return;
			}
		}
		e.preStep = 3;
	}
	if (e.preStep === 3) {
		if (U(e) === "glider" && !W(e)) {
			J(e, "bury", H(e).filter((t) => e.players.length !== 2 || t !== 2), (t) => ye(be(e, t)));
			return;
		}
		e.preStep = 4;
	}
	ke(e);
}
function ke(e) {
	e.phase = "between", e.prompt = null, e.plays = [], e.turn = e.leader, e.notice = null, e.postStep = 0, (e.stage === 20 && W(e) || U(e) === "dog") && J(e, "leader", [e.driver ?? e.guide], e.stage === 20 ? ve(H(e).filter((t) => Y(e, t) > 0)) : [q("keep", "keepLeader"), q("take", "takeLead")]);
}
function Ae(e, t) {
	if (!["between", "playing"].includes(e.phase) || e.turn !== t) return [];
	let n = be(e, t);
	if ((U(e) === "glider" && !W(e) && e.players.length !== 2 || U(e) === "glider" && !W(e) && t !== 2) && (n = e.history.length + 1 < e.limit ? n.filter((n) => n !== e.buried[t]) : n.filter((n) => n === e.buried[t])), e.players.length === 2 && t === 2 && e.config.hardGhost && e.plays.length === 0 && e.ghostPlayed !== null && e.last?.winner === 2) {
		let t = e.ghostPlayed, r = /* @__PURE__ */ new Set();
		e.ghost[t] !== null && r.add(e.ghost[t]);
		for (let n of [-1, 1]) for (let i = 1; i <= 7; i++) {
			let a = e.ghost[(t + n * i + 14) % 7];
			if (a !== null) {
				r.add(a);
				break;
			}
		}
		n = n.filter((e) => r.has(e));
	}
	return T(n, e.plays.map((e) => e.card));
}
function je(e, t) {
	if (e.phase !== "between" || e.tokens <= 0 || t >= e.players.length || U(e) === "glider") return [];
	let n = e.task;
	if (n !== null && ([
		7,
		9,
		10,
		102
	].includes(n) && t !== e.guide || n === 8 && t === e.guide || n === 32 && t === e.owner)) return [];
	let r = be(e, t);
	return U(e) === "jeep" && e.history.length < 3 && r.filter((t) => !e.comms.some((e) => e.card === t)).length <= 5 - e.history.length || U(e) === "bicycle" && r.some((e) => C.includes(e)) ? [] : r.filter((t) => y(t) !== 4 && !e.comms.some((e) => e.card === t)).flatMap((e) => {
		let t = r.filter((t) => y(t) === y(e)), n = [];
		return t.length === 1 ? n.push({
			card: e,
			mode: "only"
		}) : (e === Math.max(...t) && n.push({
			card: e,
			mode: "high"
		}), e === Math.min(...t) && n.push({
			card: e,
			mode: "low"
		})), n;
	});
}
function Me(t, n) {
	if (t.tokens--, U(t) === "storm" && e(t.seed, t.cursor++, 2) === 0) {
		t.notice = "stormFailed";
		return;
	}
	t.comms.push(n), t.notice = "communicated";
}
function Ne(e, t, n) {
	t === 2 && e.players.length === 2 && (e.ghostPlayed = e.ghost.indexOf(n)), xe(e, t, n), e.comms = e.comms.filter((e) => e.card !== n), e.plays.push({
		seat: t,
		card: n
	}), e.phase = "playing", e.notice = null;
	let r = H(e).filter((t) => Y(e, t) > 0 || e.plays.some((e) => e.seat === t));
	if (e.plays.length === r.length) e.phase = "reveal", e.turn = null;
	else {
		let n = (t + 1) % e.seats.length;
		for (; !r.includes(n);) n = (n + 1) % e.seats.length;
		e.turn = n;
	}
	return [{
		kind: "play",
		rid: e.seats[t],
		data: {
			seat: t,
			card: n,
			index: e.plays.length - 1
		}
	}];
}
function Q(e) {
	e.failed = !0;
}
function Pe(t, n) {
	let r = t.history.length - 1, i = n.plays.map((e) => e.card), a = i.map(b);
	if ([5, 16].includes(t.stage)) {
		let e = i[t.stage === 5 ? t.subtask === 0 ? 0 : t.subtask === 1 ? 1 : i.length - 1 : t.subtask === 0 ? 0 : t.subtask === 1 ? i.length - 1 : 1], n = R[r];
		if (t.board[n] = e, t.stage === 5 && t.subtask < 2) for (let r of [
			n % 3 > 0 ? n - 1 : -1,
			n % 3 < 2 ? n + 1 : -1,
			n - 3,
			n + 3
		]) r >= 0 && r < 9 && t.board[r] !== null && (t.subtask === 0 ? y(t.board[r]) === y(e) : b(t.board[r]) === b(e)) && Q(t);
		else t.stage === 5 && t.subtask === 2 && t.board.filter((t) => t !== null && y(t) === y(e)).length > 2 && Q(t);
		if (t.stage === 16 && t.subtask === 1) {
			let e = Array.from({ length: 9 }, (e, n) => t.board.filter((e) => e !== null && b(e) === n + 1).length);
			(e.some((e) => e > 2) || e.filter((e) => e === 2).length > 1) && Q(t);
		}
		if (t.stage === 16 && t.subtask === 2 && t.board.forEach((r, i) => {
			i !== n && r !== null && Math.abs(Math.floor(i / 3) - Math.floor(n / 3)) <= 1 && Math.abs(i % 3 - n % 3) <= 1 && y(r) === y(e) && Q(t);
		}), t.stage === 16 && t.subtask === 0 && r === 8) for (let e = 0; e < 3; e++) ([
			0,
			1,
			2
		].reduce((n, r) => n + b(t.board[e * 3 + r]), 0) < 22 || [
			0,
			1,
			2
		].reduce((n, r) => n + b(t.board[e + r * 3]), 0) < 22) && Q(t);
	} else if (t.stage === 8) {
		let e = b(i[i.length - 1]), n = t.flights, r = e <= 8 && e !== n[n.length - 1] && (e === 1 ? n.length === 8 : !n.includes(e)) && !ce(n, e);
		J(t, "flight", [t.guide], [q("skip", "skip"), ...r ? [q(String(e), "fly", { n: e })] : []]);
	} else if (t.stage === 11) {
		let e = i[0];
		if (t.board[r] = e, r > 0) {
			let n = b(e) - b(t.board[r - 1]), i = ie[t.subtask][r];
			(i === 0 ? n !== 0 : Math.sign(n) !== i) && Q(t);
		}
	} else if (t.stage === 14) {
		let e = ae[t.seats.length - 3].indexOf(a.reduce((e, t) => e + t, 0));
		e >= 0 && !t.markers.includes(e) && (t.markers.length < 3 ? t.markers.push(e) : (t.params.newMarker = e, J(t, "marker", [t.guide], t.markers.map((e) => q(String(e), "marker", { n: e + 1 })))));
	} else if (t.stage === 19) t.river = Math.min(z.goal, t.river + i.filter((e) => y(e) === 1).length), z.crocodiles.includes(t.river) && i.some((e) => y(e) === 1) && (t.revealCard = i[e(t.seed, t.cursor++, i.length)], y(t.revealCard) === 1 && Q(t));
	else if (t.stage === 20) {
		let e = i.flatMap((e, t) => b(e) === 6 ? [t] : []);
		t.chicago ? e.length && r !== t.limit - 1 && Q(t) : t.subtask === 0 && e.some((e) => e !== 1) || t.subtask === 1 && e.some((e) => w(i) !== e) ? Q(t) : t.subtask === 2 && e.length && (t.params.sixWinner === void 0 ? t.params.sixWinner = n.winner : t.params.sixWinner !== n.winner && Q(t));
	} else if (t.stage === 23) {
		if (t.subtask === 0 && (t.board[R[r]] = i[0], se[r].includes(y(i[0])) || Q(t)), t.subtask === 1) {
			let e = i[1], n = [0, 1].filter((n) => t.towers[n].length < (n === 0 ? 4 : 5) && (!t.towers[n].length || b(e) > b(t.towers[n][t.towers[n].length - 1])));
			n.length ? (t.params.towerCard = e, J(t, "tower", [t.guide], n.map((e) => q(String(e), "tower", { n: e + 1 })))) : Q(t);
		}
		if (t.subtask === 2) {
			if (t.board[r] = i[0], t.clockStart === null) {
				J(t, "clock", [t.guide], ge(0, 8, "clock"));
				return;
			}
			let e = B[(t.clockStart + r) % 9];
			(e !== 0 && b(i[0]) !== e || i[0] === 25 && e !== 0) && Q(t);
		}
	} else if (t.stage === 25 && (t.board[r] = i[0], r)) {
		let e = b(i[0]) - b(t.board[r - 1]), n = y(i[0]);
		[
			!0,
			e >= 3,
			n === 2 && e > 0,
			e <= -4,
			n === 3 && e < 0,
			e === 0,
			n === 0 && e > 0,
			n === 1 && e > 0,
			n === 3 && e < 0
		][r] || Q(t);
	}
}
function Fe(e, t) {
	return de({
		id: e.task,
		seats: e.seats.length,
		guide: e.guide,
		owner: he(e),
		history: e.history,
		params: e.params,
		final: t
	});
}
function Ie(e) {
	if (e.failed) return !1;
	if (e.stage === 8) return e.flights.length === 9 && e.flights[8] === 1;
	if (e.stage === 14) return [
		0,
		1,
		2
	].some((t) => [
		0,
		1,
		2
	].every((n) => e.markers.includes(t * 3 + n)) || [
		0,
		1,
		2
	].every((n) => e.markers.includes(t + n * 3)));
	if (e.stage === 19) return e.river === z.goal;
	if (e.stage === 20) {
		let t = e.history.flatMap((e) => e.plays.filter((e) => b(e.card) === 6));
		return e.chicago ? e.seats.length === 3 ? t.length === 3 && e.hands.some((e) => e.some((e) => b(e) === 6)) : t.length === 4 : t.length >= (e.subtask === 0 && e.seats.length === 5 || e.subtask === 2 && e.seats.length === 5 ? 3 : 4);
	}
	return e.stage === 23 && e.subtask === 2 ? e.board.includes(25) && e.history.length === 9 : e.history.length === e.limit;
}
function Le(e) {
	if (e.task === 96 && e.params.guess === void 0) {
		J(e, "guess", [e.guide], ye(S));
		return;
	}
	let t = e.task === null ? null : Fe(e, !0);
	e.roundSuccess = W(e) ? Ie(e) : !!t?.success && !e.failed, e.movement = e.roundSuccess ? t?.movement ?? 0 : 0, e.phase = "roundEnd", e.prompt = null, e.turn = null;
}
function Re(e) {
	let t = {
		plays: [...e.plays],
		winner: e.plays[w(e.plays.map((e) => e.card))].seat
	};
	if (e.history.push(t), e.last = t, e.phase = "collect", e.leader = t.winner, !W(e) && U(e) === "machete") {
		let n = t.plays.reduce((e, t) => e + b(t.card), 0);
		t.plays.some((e) => ee.includes(e.card)) && [5 * e.seats.length, 5 * e.seats.length + 1].includes(n) && (e.failed = !0);
	}
	return W(e) && Pe(e, t), [{
		kind: "collect",
		rid: e.seats[t.winner],
		data: {
			plays: t.plays,
			winner: t.winner
		}
	}];
}
function ze(e, t, n) {
	let r = be(e, t), i = r.filter((t) => !e.comms.some((e) => e.card === t)), a = n === 1 && i.length === 0 ? r : i;
	return n === 1 ? ye(a) : a.flatMap((e, t) => a.slice(t + 1).map((t) => q(`${e},${t}`, "cards", { cards: [e, t] })));
}
function Be(e) {
	if (e.plays = [], Ce(e), W(e) && e.players.length === 5 && ![19, 20].includes(e.stage) && e.history.length === 3 && e.postStep === 0) {
		let t = [...e.board.filter((e) => e !== null), ...e.towers.flat()], n = e.history.flatMap((e) => e.plays.map((e) => e.card)), r = [...t, ...K(e, n.filter((e) => !t.includes(e))).slice(0, 3 - t.length)], i = K(e, n.filter((e) => !r.includes(e)));
		for (let t of H(e)) e.hands[t].push(...i.splice(0, 2));
		e.postStep = 1;
	}
	if (e.postStep <= 1) {
		if (!W(e) && U(e).startsWith("fog")) for (let t of H(e)) (e.players.length !== 2 || t !== 2) && e.draw.length && e.hands[t].push(e.draw.shift());
		e.postStep = 2;
	}
	let t = e.history.length >= e.limit || H(e).every((t) => Y(e, t) === 0);
	if (!W(e) && e.task !== 96 && H(e).some((t) => Y(e, t) === 0) && (t = !0), W(e) && (e.failed || [
		8,
		14,
		19
	].includes(e.stage) && Ie(e)) && (t = !0), !W(e) && e.task !== null && U(e) !== "machete" && Fe(e, !1).failed && (t = !0), t) {
		if (e.stage === 19 && !e.failed && e.riverDeal === 1 && !Ie(e)) {
			e.riverDeal = 2, X(e, !0), Z(e);
			return;
		}
		Le(e);
		return;
	}
	if (e.postStep === 2 && (e.postStep = 3, !W(e) && U(e) === "ski" && e.last.plays.some((e) => e.card === 6) && (e.players.length === 2 ? ([e.hands[0], e.hands[1]] = [e.hands[1], e.hands[0]], e.comms = e.comms.map((e) => ({
		...e,
		seat: e.seat < 2 ? 1 - e.seat : e.seat
	}))) : (e.hands = e.hands.map((t, n) => e.hands[(n + e.seats.length - 1) % e.seats.length]), e.comms = e.comms.map((t) => ({
		...t,
		seat: (t.seat + 1) % e.seats.length
	})))), !W(e) && U(e) === "helicopter" && e.last.plays.some((e) => y(e.card) === 4))) {
		J(e, "pass", H(e).filter((t) => Y(e, t) > 0), (t) => ze(e, t, 1));
		return;
	}
	if (e.postStep === 3 && (e.postStep = 4, !W(e) && U(e) === "jeep" && e.history.length === 3)) {
		J(e, "jeep", H(e), (t) => ze(e, t, 2));
		return;
	}
	if (e.task === 96 && Y(e, e.leader) === 0) for (e.leader = (e.leader + 1) % e.seats.length; Y(e, e.leader) === 0;) e.leader = (e.leader + 1) % e.seats.length;
	ke(e);
}
function Ve(e, t) {
	e.score = t, e.stage !== 1 && e.scores.push({
		stage: e.stage,
		score: t
	}), e.phase = "stageEnd", e.prompt = null, e.turn = null;
}
function He(e) {
	if (W(e)) {
		if (e.chicago) {
			if (e.roundSuccess) {
				e.scores = e.scores.filter((e) => e.stage !== 20), Ve(e, -3);
				return;
			}
			if (e.chicagoAttempt < 3) {
				e.chicagoAttempt++, X(e), Z(e);
				return;
			}
			e.phase = "stageEnd";
			return;
		}
		if (L[e.stage - 1].triple) {
			if (e.roundSuccess || e.attempt === 2 ? (e.subResults.push(!!e.roundSuccess), (!e.roundSuccess || e.attempt !== 1) && (e.firstTry = !1), e.subtask++, e.attempt = 1) : (e.attempt++, e.firstTry = !1), e.subtask >= 3) {
				let t = e.subResults.filter(Boolean).length;
				Ve(e, e.firstTry ? -2 : 6 - 2 * t);
				return;
			}
		} else {
			if (e.roundSuccess) {
				Ve(e, 4 - 2 * e.attempt);
				return;
			}
			if (e.attempt === 3) {
				Ve(e, 4);
				return;
			}
			e.attempt++;
		}
		X(e), Z(e);
		return;
	}
	e.phase = "moveCrew";
}
function Ue(e) {
	if (e.stage === 21 && !e.routeSelected && e.roundSuccess) {
		J(e, "route", [e.guide], Object.keys(L[20].routes).map((e) => q(e, "route")));
		return;
	}
	if (e.stage === 15 && e.route === "A" && e.params.branch !== 1 && e.crew <= 5 && e.roundSuccess && e.crew + e.movement > 5) {
		J(e, "branch", [e.guide], [q("upper", "upper"), q("lower", "lower")]);
		return;
	}
	let t = me(e), n = U(e), r = e.crew;
	if (e.roundSuccess) {
		if (n === "cracked") e.crew = Math.max(0, e.crew - e.movement);
		else {
			let n = Math.min(t.spaces.length, e.crew + e.movement), i = t.stops.find((e) => e > r && e < n);
			i !== void 0 && (n = i), e.crew = n;
		}
	} else n === "cable" ? e.crew = Math.max(0, t.spaces.indexOf("cable")) : n === "ice" && (e.crew = Math.max(0, e.crew - 1));
	e.params.timeAdvance = n === "donkey" ? 2 : 1, e.phase = "moveTime";
}
function We(e) {
	let t = me(e), n = e.stage === 21 ? 8 : e.stage === 15 ? 4 : t.spaces.length - t.time;
	if (e.elapsed >= n && e.overtime++, e.elapsed += e.params.timeAdvance, e.crew >= t.spaces.length) {
		Ve(e, e.overtime > 0 ? e.overtime : -Math.max(0, n - e.elapsed));
		return;
	}
	e.driver = null, Te(e);
}
function Ge(e, t) {
	let n = Object.fromEntries(Object.entries(t.answers).map(([e, t]) => [e, Number(t)])), r = t.actors[0], i = t.answers[r], a = Number(i);
	switch (e.prompt = null, t.kind) {
		case "route":
			e.route = i, e.routeSelected = !0, e.stage === 21 ? Ue(e) : Te(e);
			return;
		case "branch":
			e.route = i === "lower" ? "A2" : "A", e.params.branch = 1, Ue(e);
			return;
		case "driver":
			e.driver = a, Te(e);
			return;
		case "vote": {
			e.votes = H(e).map((e) => t.answers[e] === "yes");
			let n = H(e).filter((t) => e.votes[t]);
			if (!n.length) {
				e.votes = null, Z(e);
				return;
			}
			J(e, "assign", [e.guide], ve(n));
			return;
		}
		case "assign":
			e.owner = a, Z(e);
			return;
		case "prediction":
			for (let r of t.actors) {
				let t = e.task === 55 ? (r + 1) % e.seats.length : r;
				e.params["declared:" + r] = 1, e.params["pred:" + t] = n[r], [
					3,
					54,
					55
				].includes(e.task) && (e.publicParams["pred:" + t] = n[r]);
			}
			Z(e);
			return;
		case "neighbor":
			e.params.neighbor = a, Z(e);
			return;
		case "color":
			e.params.color = a, [91, 95].includes(e.task) && (e.publicParams.color = a), Z(e);
			return;
		case "number":
			e.params.number = a, Z(e);
			return;
		case "targetPeople": {
			let [t, n] = i.split(",").map(Number);
			e.params.player0 = t, e.params.player1 = n, X(e), Z(e);
			return;
		}
		case "forbid":
			e.params["forbid:" + r] = a, e.publicParams["forbid:" + r] = a, Z(e);
			return;
		case "show":
			e.params.number = b(a), e.publicParams.number = b(a), e.comms.push({
				seat: r,
				card: a,
				mode: "shown"
			}), Z(e);
			return;
		case "scooterPartner":
			e.params.scooterPartner = a, J(e, "scooter", [e.params.scooter, a], (t) => ye(be(e, t).filter((e) => e !== 39)));
			return;
		case "scooter": {
			let [r, i] = t.actors, a = n[r], o = n[i], s = e.ghost.indexOf(a), c = e.ghost.indexOf(o);
			xe(e, r, a), xe(e, i, o), Se(e, r, [o], s < 0 ? [] : [s]), Se(e, i, [a], c < 0 ? [] : [c]), e.preStep = 3, Z(e);
			return;
		}
		case "bury":
			for (let r of t.actors) e.buried[r] = n[r];
			e.preStep = 4, Z(e);
			return;
		case "leader":
			e.leader = e.stage === 20 ? a : i === "take" ? r : e.leader, e.phase = "between", e.turn = e.leader;
			return;
		case "dogPermission":
			i === "yes" && e.pendingComm && Me(e, e.pendingComm), e.pendingComm = null, e.phase = "between";
			return;
		case "pass":
		case "jeep": {
			let n = t.actors.map((n) => ({
				seat: n,
				cards: t.answers[n].split(",").map(Number),
				slots: t.answers[n].split(",").map(Number).map((t) => e.ghost.indexOf(t)).filter((e) => e >= 0)
			}));
			for (let t of n) for (let n of t.cards) xe(e, t.seat, n);
			if (t.kind === "jeep") {
				let t = K(e, n.flatMap((e) => e.cards));
				for (let r of n) Se(e, r.seat, t.splice(0, 2), r.slots);
			} else for (let t of n) {
				let r = (t.seat + 1) % e.seats.length, i = n.find((e) => e.seat === r);
				Se(e, r, t.cards, i?.slots ?? []), e.comms = e.comms.map((e) => t.cards.includes(e.card) ? {
					...e,
					seat: r
				} : e);
			}
			e.phase = "collect", Be(e);
			return;
		}
		case "flight":
			i !== "skip" && (e.board[e.flights.length - 1] = e.last.plays[e.last.plays.length - 1].card, e.flights.push(a)), e.phase = "collect";
			return;
		case "marker":
			e.markers = e.markers.filter((e) => e !== a), e.markers.push(e.params.newMarker), e.phase = "collect";
			return;
		case "tower":
			e.towers[a].push(e.params.towerCard), e.phase = "collect";
			return;
		case "clock": {
			e.clockStart = a;
			let t = e.board[0], n = B[a];
			(n !== 0 && b(t) !== n || t === 25 && n !== 0) && Q(e), e.phase = "collect";
			return;
		}
		case "guess":
			e.params.guess = a, e.publicParams.guess = a, e.publicParams.missing = e.params.missing, Le(e);
			return;
	}
}
function Ke(e, t) {
	if (e.prompt) {
		let n = e.prompt.actors.find((n) => pe(e, n) === t && e.prompt.answers[n] === void 0);
		if (n !== void 0) return {
			choices: e.prompt.options[n],
			seat: n,
			selected: null
		};
		let r = e.prompt.actors.find((n) => pe(e, n) === t);
		return {
			choices: [],
			seat: r ?? e.players.indexOf(t),
			selected: r === void 0 ? null : e.prompt.answers[r] ?? null
		};
	}
	let n = e.players.indexOf(t);
	if (e.phase === "select" && pe(e, e.driver ?? e.guide) === t) {
		let t = e.stacks.map((t) => V(t[0]).special || V(t[0]).random ? 3 : ue(t[0], e.seats.length)), r = Math.min(...t);
		return {
			choices: e.stacks.flatMap((n, i) => [...U(e) === "foot" && t[i] !== r ? [] : [q("task:" + i, "taskStack", { n: i + 1 })], ...!e.discarded[i] && !V(n[0]).random ? [q("discard:" + i, "discard", { n: i + 1 })] : []]),
			seat: n,
			selected: null
		};
	}
	return e.phase === "roundEnd" && n === e.guide ? {
		choices: [q("continue", "continue")],
		seat: n,
		selected: null
	} : e.phase === "stageEnd" && n === 0 ? {
		choices: [q("next", "nextStage"), ...e.stage === 20 && !e.chicago ? [q("chicago", "chicago")] : []],
		seat: n,
		selected: null
	} : {
		choices: [],
		seat: n,
		selected: null
	};
}
function qe(e, t, n) {
	if (e.prompt) {
		let r = e.prompt.actors.find((n) => pe(e, n) === t && e.prompt.answers[n] === void 0);
		e.prompt.answers[r] = n, e.prompt.actors.every((t) => e.prompt.answers[t] !== void 0) && Ge(e, e.prompt);
	} else if (e.phase === "select") {
		let [t, r] = n.split(":"), i = Number(r);
		t === "discard" ? (e.stacks[i].push(e.stacks[i].shift()), e.discarded[i] = !0) : De(e, i);
	} else e.phase === "roundEnd" ? He(e) : e.phase === "stageEnd" && (n === "chicago" ? (e.chicago = !0, e.chicagoAttempt = 1, X(e), Z(e)) : !e.config.campaign || e.stage === 25 ? e.phase = "over" : (e.stage++, Ee(e)));
}
function Je(e, t) {
	let n = {};
	return e.params["pred:" + t] !== void 0 && (n["pred:" + t] = e.params["pred:" + t]), [
		7,
		9,
		10,
		102
	].includes(e.task) && t !== e.guide && (n.sum = e.params.sum), e.task === 8 && t === e.guide && (n.neighbor = e.params.neighbor), [48, 53].includes(e.task) && t === e.owner && (n.target0 = e.params.target0, e.task === 53 && (n.target1 = e.params.target1)), e.task === 69 && (t === e.params.player0 && (n.target0 = e.params.target0), t === e.params.player1 && (n.target1 = e.params.target1)), [
		37,
		71,
		91
	].includes(e.task) && (e.players.length === 2 ? [e.guide, e.scout] : [(e.guide + 1) % e.seats.length, (e.guide + e.seats.length - 1) % e.seats.length]).includes(t) && (e.params.color !== void 0 && (n.color = e.params.color), e.params.number !== void 0 && (n.number = e.params.number)), Object.fromEntries(Object.entries(n).filter(([, e]) => e !== void 0));
}
var Ye = {
	meta: E,
	saveCompatibility: { version: "1" },
	schemas: {
		action: O,
		publicView: M,
		privateView: N,
		config: te
	},
	setup(e, t, n) {
		let r = {
			seed: n,
			cursor: 0,
			config: e,
			players: [...t],
			seats: t.length === 2 ? [...t, "$ghost"] : [...t],
			phase: "select",
			stage: e.stage,
			route: "A",
			routeSelected: !1,
			crew: 0,
			elapsed: 0,
			overtime: 0,
			round: 0,
			guide: 0,
			scout: 1,
			driver: null,
			stacks: [],
			used: [],
			discarded: [],
			task: null,
			owner: null,
			hands: [],
			draw: [],
			removed: [],
			ghost: [],
			ghostBottom: [],
			ghostPlayed: null,
			leader: 0,
			turn: null,
			plays: [],
			last: null,
			history: [],
			limit: 13,
			tokens: 0,
			comms: [],
			buried: [],
			params: {},
			publicParams: {},
			prompt: null,
			votes: null,
			preStep: 0,
			pendingComm: null,
			board: [],
			markers: [],
			river: 0,
			riverDeal: 1,
			flights: [],
			towers: [[], []],
			clockStart: null,
			subtask: 0,
			attempt: 1,
			subResults: [],
			firstTry: !0,
			chicago: !1,
			chicagoAttempt: 0,
			roundSuccess: null,
			movement: 0,
			score: null,
			scores: [],
			failed: !1,
			notice: null,
			revealCard: null,
			postStep: 0
		}, i = K(r, [
			1,
			2,
			3,
			4,
			5,
			6
		]), a = K(r, Array.from({ length: 98 }, (e, t) => t + 7));
		return r.stacks = [i.slice(0, 3), i.slice(3)], a.forEach((e, t) => r.stacks[t % 2].push(e)), r.discarded = [!1, !1], Ee(r), { state: r };
	},
	reduce(e, t, { by: n }) {
		let r = structuredClone(e);
		if (t.type === "tick") return n === "$engine" ? r.phase === "reveal" ? {
			state: r,
			fx: Re(r)
		} : r.phase === "collect" ? (Be(r), { state: r }) : r.phase === "moveCrew" ? (Ue(r), {
			state: r,
			fx: [{
				kind: "move",
				data: { crew: r.crew }
			}]
		}) : r.phase === "moveTime" ? (We(r), { state: r }) : G() : G();
		if (!r.players.includes(n) || r.phase === "over") return G();
		if (t.type === "choose") return Ke(r, n).choices.some((e) => e.value === t.value) ? (qe(r, n, t.value), { state: r }) : G();
		if (t.type === "bury") {
			let e = r.players.indexOf(n);
			return r.phase !== "between" || U(r) !== "glider" || W(r) || r.history.length + 1 >= r.limit || !r.hands[e].includes(t.card) ? G() : (r.buried[e] = t.card, { state: r });
		}
		let i = r.turn;
		if (t.type === "play") return i === null || pe(r, i) !== n || !Ae(r, i).includes(t.card) ? G() : {
			state: r,
			fx: Ne(r, i, t.card)
		};
		if (t.type === "communicate") {
			let e = r.players.indexOf(n);
			if (e < 0 || !je(r, e).some((e) => e.card === t.card && e.mode === t.mode)) return G();
			let i = {
				seat: e,
				card: t.card,
				mode: t.mode
			};
			return U(r) === "dog" && r.driver !== e ? (r.pendingComm = i, J(r, "dogPermission", [r.driver], [q("yes", "approve"), q("no", "deny")])) : Me(r, i), { state: r };
		}
		return G();
	},
	viewFor(e, t) {
		let n = Ke(e, t), r = e.players.indexOf(t), i = e.turn !== null && pe(e, e.turn) === t ? e.turn : null, a = me(e), o = e.stage === 21 ? 8 : e.stage === 15 ? 4 : a ? a.spaces.length - a.time : 0, s = e.task !== null && V(e.task).special && (![29, 31].includes(e.task) || e.phase === "roundEnd") ? Fe(e, !1) : null;
		return {
			public: {
				phase: e.phase,
				stage: e.stage,
				round: e.round,
				route: e.route,
				seats: e.seats.map((t, n) => ({
					rid: t,
					count: Y(e, n),
					tricks: e.history.filter((e) => e.winner === n).length
				})),
				guide: e.guide,
				scout: e.scout,
				driver: e.driver,
				turn: e.turn,
				leader: e.leader,
				crew: e.crew,
				elapsed: e.elapsed,
				timeLeft: Math.max(0, o - e.elapsed),
				overtime: e.overtime,
				task: e.task,
				owner: e.owner,
				stacks: e.stacks.map((t, n) => {
					let r = V(t[0]);
					return {
						difficulty: r.special || r.random ? null : ue(t[0], e.seats.length),
						special: r.special,
						random: r.random,
						count: t.length,
						discarded: !!e.discarded[n]
					};
				}),
				tokens: e.tokens,
				comms: e.comms,
				plays: e.plays,
				last: e.last,
				trickNumber: e.history.length + +!["collect", "roundEnd"].includes(e.phase),
				trickLimit: e.limit,
				deckCount: e.draw.length,
				removed: e.removed,
				ghost: e.ghost,
				ghostCovered: e.ghostBottom.map((e) => e !== null),
				prompt: e.prompt?.kind ?? null,
				waiting: e.prompt ? e.prompt.actors.filter((t) => e.prompt.answers[t] === void 0) : [],
				votes: e.votes,
				parameters: e.publicParams,
				board: e.board,
				markers: e.markers,
				river: e.river,
				flights: e.flights,
				towers: e.towers,
				clockStart: e.clockStart,
				subtask: e.subtask,
				attempt: e.attempt,
				subResults: e.subResults,
				firstTry: e.firstTry,
				riverDeal: e.riverDeal,
				roundSuccess: e.roundSuccess,
				movement: e.movement,
				cumulative: s?.raw ?? null,
				score: e.score,
				scores: e.scores,
				chicago: e.chicago,
				chicagoAttempt: e.chicagoAttempt,
				specialFailure: e.failed,
				notice: e.notice,
				revealCard: e.revealCard
			},
			...r < 0 ? {} : { private: {
				seat: r,
				hand: e.hands[r] ?? [],
				controlledSeat: i,
				choiceSeat: n.seat,
				legal: i === null ? [] : Ae(e, i),
				communications: je(e, r),
				choices: n.choices,
				selected: n.selected,
				secrets: {
					...Je(e, r),
					...e.players.length === 2 && r === e.scout ? Je(e, 2) : {}
				},
				hiddenCard: e.buried[r] ?? null,
				burials: e.phase === "between" && U(e) === "glider" && !W(e) && e.history.length + 1 < e.limit ? e.hands[r].filter((t) => t !== e.buried[r]) : []
			} }
		};
	},
	status(e) {
		if (e.phase !== "over") return { phase: e.phase };
		let t = e.scores.map((e) => e.score), n = t.reduce((e, t) => e + t, 0) - (e.config.campaign && e.config.stage === 1 && t.length === 24 ? Math.max(...t) : 0);
		return {
			phase: e.phase,
			winner: [...e.players],
			ranking: [...e.players],
			scores: Object.fromEntries(e.players.map((e) => [e, n]))
		};
	},
	nextTickIn(e) {
		return e.phase === "reveal" ? fe.reveal : e.phase === "collect" ? fe.collect : e.phase === "moveCrew" ? fe.result : e.phase === "moveTime" ? fe.movement : null;
	}
}, Xe = [
	"#1684aa",
	"#7a9d22",
	"#c36596",
	"#c79a13",
	"#333b3d"
];
function Ze({ type: e }) {
	return e < 4 ? /* @__PURE__ */ d("img", {
		className: "crew-suit-icon",
		src: `games/crewends/suit-${e}.webp`,
		alt: "",
		"aria-hidden": !0
	}) : /* @__PURE__ */ d("svg", {
		viewBox: "0 0 40 40",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2.3",
		"aria-hidden": !0,
		children: /* @__PURE__ */ d("path", { d: "M5 10h30M20 6v9M9 27h22M14 15h12l4 8H10Z M30 19h6v-5M14 27v5M27 27v5M9 32h23" })
	});
}
function Qe({ kind: e }) {
	return /* @__PURE__ */ d("img", {
		className: "crew-gear-icon",
		src: `games/crewends/gear-${e}.webp`,
		alt: "",
		"aria-hidden": !0
	});
}
function $({ card: e, small: t = !1, back: n = !1, style: r }) {
	let i = s(), a = e === void 0 ? 0 : y(e), o = e === void 0 ? 0 : b(e), c = e === void 0 ? null : C.includes(e) ? "bicycle" : ee.includes(e) ? "machete" : e === 6 ? "ski" : e === 0 ? "scooter" : null;
	return /* @__PURE__ */ d("span", {
		className: `crew-card${t ? " is-small" : ""}${n ? " is-back" : ""}`,
		style: {
			"--crew-card-ink": Xe[a],
			...r
		},
		"aria-label": n ? void 0 : i(`games.crewends.colors.${v[a]}`) + ` ${o}`,
		children: n ? /* @__PURE__ */ d("span", {
			className: "crew-card-compass",
			children: "✦"
		}) : /* @__PURE__ */ f(u, { children: [
			/* @__PURE__ */ f("span", {
				className: "crew-card-corner",
				children: [/* @__PURE__ */ d("b", { children: o }), /* @__PURE__ */ d(Ze, { type: a })]
			}),
			/* @__PURE__ */ f("span", {
				className: "crew-card-corner is-opposite",
				children: [/* @__PURE__ */ d("b", { children: o }), /* @__PURE__ */ d(Ze, { type: a })]
			}),
			/* @__PURE__ */ d("span", {
				className: "crew-card-landscape",
				"aria-hidden": !0,
				children: /* @__PURE__ */ d("img", {
					src: `games/crewends/card-${a}-${o}.webp`,
					alt: "",
					draggable: !1
				})
			}),
			c && /* @__PURE__ */ d("span", {
				className: "crew-card-gear",
				children: /* @__PURE__ */ d(Qe, { kind: c })
			})
		] })
	});
}
function $e() {
	return /* @__PURE__ */ d("svg", {
		className: "crew-marching",
		viewBox: "0 0 100 150",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: /* @__PURE__ */ d("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "146",
			rx: "8",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2.5",
			strokeDasharray: "7 5",
			children: /* @__PURE__ */ d("animate", {
				attributeName: "stroke-dashoffset",
				from: "0",
				to: "-24",
				dur: "1s",
				repeatCount: "indefinite"
			})
		})
	});
}
//#endregion
//#region src/games/crewends/board.tsx
function et({ kind: e }) {
	let t = e.startsWith("fog") ? "fog" : e;
	return /* @__PURE__ */ d("svg", {
		viewBox: "0 0 40 40",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": !0,
		children: /* @__PURE__ */ d("path", { d: {
			train: "M8 6h24v22H8ZM8 14h24M10 28l-4 8M30 28l4 8M8 33h24M13 20h2M25 20h2",
			foot: "M14 4c7-2 12 9 7 15l-6 10c-5 6-14 0-10-6l5-8c-4-4-2-9 4-11ZM27 15c6-2 14 7 10 13l-6 8c-4 5-12 0-9-5l5-8c-4-2-4-6 0-8Z",
			glider: "M3 13Q20-2 37 13L20 24ZM20 24v10M15 32h10",
			ski: "M6 5l25 28 5-2M13 3l24 27M6 32 29 5M12 36 34 10",
			scooter: "M10 30h13L32 8h-8M32 8l3 18M5 30a5 5 0 1 0 10 0a5 5 0 1 0-10 0M28 30a5 5 0 1 0 10 0a5 5 0 1 0-10 0",
			bicycle: "M8 29l10-17 8 17H8l16-13h6M29 8l5 21M25 8h7M14 11h9M2 29a6 6 0 1 0 12 0a6 6 0 1 0-12 0M28 29a6 6 0 1 0 12 0a6 6 0 1 0-12 0",
			helicopter: "M4 8h32M20 4v10M11 15h15l5 11H8ZM30 20h6v-6M12 27v6M27 27v6M7 34h26",
			storm: "M4 15c0-9 10-12 15-7 8-7 18 0 17 9M5 19h30M21 17l-8 10h10l-8 11",
			donkey: "M9 17h21v13H9ZM28 17V7l5 4 2 8-6 4M10 28v8M26 28v8M9 19 4 14M28 7l-2-5M32 10l3-7",
			jeep: "M3 24h34v9H3ZM9 24l5-12h15l6 12M19 13v11M8 33v4M31 33v4M7 28h4M29 28h4",
			machete: "m6 35 10-12M13 21 29 5l7 1-16 21ZM5 30l7 7",
			dog: "M3 24h14l3 10h15M7 24v-7l5-3 5 5M20 24l4-5h10l3 5-5 2M24 26v7M33 26v7",
			cable: "M2 7 38 2M20 5v9M9 14h22v19H9ZM9 23h22M20 14v19",
			ice: "M3 25h34M7 30l3 4M22 31h8M5 15l6-7 4 8 7-5 8 8",
			cracked: "M3 9h34M20 9l-6 8 10 5-9 10 9 5M5 28h7M29 23h8",
			fog: "M4 12h28M9 19h28M3 26h28M9 33h27",
			plane: "m3 20 15-5V3l4 2 2 10 13 6v4l-14-2-2 11 6 3H12l5-3 1-11-15 2Z",
			clock: "M20 8v13l9 5M20 3a17 17 0 1 0 0 34a17 17 0 1 0 0-34"
		}[t] })
	});
}
function tt(e, t) {
	return e.startsWith("fog") ? t("games.crewends.terrain.fog", { n: Number(e.slice(3)) }) : t(`games.crewends.terrain.${e}`);
}
function nt({ pub: e, choices: t, onChoose: i, compact: a = !1 }) {
	let c = s(), l = o((e) => e.locale), u = L[e.stage - 1], p = Math.min(e.subtask, 2), m = r(null);
	if (n(() => {
		let e = m.current, t = e?.querySelector("[data-current=true]");
		e && t && (e.scrollLeft = Math.max(0, t.offsetLeft - e.offsetLeft - (e.clientWidth - t.clientWidth) / 2));
	}, [
		e.crew,
		e.stage,
		e.route
	]), e.prompt === "route") return /* @__PURE__ */ d("div", {
		className: "crew-route-previews",
		children: Object.entries(u.routes).filter(([e]) => e !== "A2").map(([n, r]) => /* @__PURE__ */ f("button", {
			className: "crew-route-preview",
			disabled: !t.some((e) => e.value === n),
			onClick: () => i(t.find((e) => e.value === n)),
			children: [
				t.some((e) => e.value === n) && /* @__PURE__ */ d($e, {}),
				/* @__PURE__ */ f("b", { children: [
					c("games.crewends.choice.route"),
					" ",
					n
				] }),
				/* @__PURE__ */ d("span", { children: c("games.crewends.routeSummary", {
					n: r.spaces.length,
					stacks: r.stacks
				}) }),
				/* @__PURE__ */ d("div", { children: r.spaces.map((e, t) => /* @__PURE__ */ f("span", {
					"data-stop": r.stops.includes(t),
					title: tt(e, c),
					children: [/* @__PURE__ */ d(et, { kind: e }), /* @__PURE__ */ f("small", { children: [t, e.startsWith("fog") ? ` · ${e.slice(3)}` : ""] })]
				}, t)) }),
				e.stage === 15 && n === "A" && /* @__PURE__ */ d("small", { children: c("games.crewends.branchInfo") })
			]
		}, n))
	});
	if (!u.special) {
		let t = u.routes[e.route], n = [...t.spaces, "plane"], r = n.length <= 10 ? 5 : 6, i = Math.ceil(n.length / r), o = (e) => {
			let t = Math.floor(e / r), n = e % r;
			return [40 + (t % 2 ? r - 1 - n : n) * 88, 55 + t * 100];
		}, s = o(e.crew), p = e.stage === 15 ? 4 : e.stage === 21 ? 8 : t.spaces.length - t.time;
		return /* @__PURE__ */ f("div", {
			className: "crew-map",
			"data-compact": a,
			children: [
				/* @__PURE__ */ f("div", {
					className: "crew-map-readings",
					children: [/* @__PURE__ */ d("b", { children: c("games.crewends.crewPosition", {
						n: e.crew,
						total: t.spaces.length
					}) }), /* @__PURE__ */ f("span", { children: [/* @__PURE__ */ d(et, { kind: "clock" }), e.overtime ? c("games.crewends.overtime", { n: e.overtime }) : c("games.crewends.timeLeft", { n: e.timeLeft })] })]
				}),
				a && /* @__PURE__ */ d("div", {
					ref: m,
					className: "crew-route-strip",
					"aria-label": l === "zh" ? u.zh : u.name,
					children: n.map((n, r) => /* @__PURE__ */ f("span", {
						"data-current": r === e.crew,
						"data-past": r < e.crew,
						"data-stop": t.stops.includes(r),
						title: n === "plane" ? c("games.crewends.destination") : tt(n, c),
						children: [/* @__PURE__ */ d(et, { kind: n }), /* @__PURE__ */ d("small", { children: n.startsWith("fog") ? n.slice(3) : r })]
					}, r))
				}),
				/* @__PURE__ */ f("svg", {
					className: "crew-route",
					viewBox: `0 0 ${r * 88} ${i * 100 + 15}`,
					role: "img",
					"aria-label": l === "zh" ? u.zh : u.name,
					children: [
						/* @__PURE__ */ d("path", {
							d: n.map((e, t) => `${t ? "L" : "M"}${o(t).join(" ")}`).join(" "),
							fill: "none",
							stroke: "#a58d62",
							strokeWidth: "5"
						}),
						/* @__PURE__ */ d("path", {
							d: n.map((e, t) => `${t ? "L" : "M"}${o(t).join(" ")}`).join(" "),
							fill: "none",
							stroke: "#f5edd5",
							strokeWidth: "2",
							strokeDasharray: "5 5"
						}),
						n.map((n, r) => {
							let [i, a] = o(r);
							return /* @__PURE__ */ f("g", {
								transform: `translate(${i},${a})`,
								children: [
									/* @__PURE__ */ d("circle", {
										r: "31",
										fill: r < e.crew ? "#dfcfaa" : "#f9efd6",
										stroke: r === e.crew ? "#b95228" : "#8c7b59",
										strokeWidth: r === e.crew ? 3 : 1.5
									}),
									/* @__PURE__ */ d("foreignObject", {
										x: "-19",
										y: "-22",
										width: "38",
										height: "38",
										children: /* @__PURE__ */ d("span", {
											className: "crew-route-icon",
											children: /* @__PURE__ */ d(et, { kind: n })
										})
									}),
									/* @__PURE__ */ d("text", {
										y: "23",
										textAnchor: "middle",
										fontSize: "11",
										fill: "#554b37",
										children: n.startsWith("fog") ? n.slice(3) : r
									}),
									t.stops.includes(r) && /* @__PURE__ */ d("path", {
										d: "M32 -24v48M36 -24v48",
										stroke: "#8a432d",
										strokeWidth: "3"
									})
								]
							}, r);
						}),
						/* @__PURE__ */ d("g", {
							className: "crew-route-token",
							style: { transform: `translate(${s[0]}px,${s[1]}px)` },
							children: /* @__PURE__ */ d("path", {
								d: "M-8-38a8 8 0 1 1 16 0a8 8 0 1 1-16 0M-8-28h16l5 18H-13ZM-6-10v10M6-10V0",
								stroke: "#aa4b26",
								strokeWidth: "5",
								fill: "#dc7a43",
								strokeLinecap: "round"
							})
						})
					]
				}),
				/* @__PURE__ */ f("svg", {
					className: "crew-time-track",
					viewBox: `0 0 ${p * 28 + 30} 28`,
					"aria-label": c("games.crewends.timeLeft", { n: e.timeLeft }),
					children: [
						/* @__PURE__ */ d("path", {
							d: `M10 15H${p * 28 + 10}`,
							stroke: "#b19b72",
							strokeWidth: "2"
						}),
						Array.from({ length: p + 1 }, (e, t) => /* @__PURE__ */ d("circle", {
							cx: 10 + t * 28,
							cy: "15",
							r: "4",
							fill: "#ccba95"
						}, t)),
						/* @__PURE__ */ d("g", {
							className: "crew-time-token",
							style: { transform: `translate(${10 + Math.min(p, e.elapsed) * 28}px,15px)` },
							children: /* @__PURE__ */ d("rect", {
								x: "-7",
								y: "-8",
								width: "14",
								height: "16",
								rx: "2",
								fill: "#fff8dc",
								stroke: "#92764b",
								strokeWidth: "2"
							})
						})
					]
				}),
				/* @__PURE__ */ f("div", {
					className: "crew-map-key",
					children: [
						/* @__PURE__ */ d(et, { kind: t.spaces[Math.min(e.crew, t.spaces.length - 1)] }),
						tt(t.spaces[Math.min(e.crew, t.spaces.length - 1)], c),
						e.stage === 15 && /* @__PURE__ */ d("small", { children: e.route === "A2" ? "A" : e.route })
					]
				})
			]
		});
	}
	if (e.stage === 8) {
		let t = oe.map(([e, t]) => [(e - 850) * .65 + 30, t * .65 + 5]), n = l === "zh" ? [
			"开罗",
			"廷巴克图",
			"班吉",
			"喀土穆",
			"拉巴特",
			"阿克拉",
			"内罗毕",
			"阿加德兹"
		] : [
			"Cairo",
			"Timbuktu",
			"Bangui",
			"Khartoum",
			"Rabat",
			"Accra",
			"Nairobi",
			"Agadez"
		];
		return /* @__PURE__ */ d("div", {
			className: "crew-map",
			children: /* @__PURE__ */ f("svg", {
				viewBox: "0 0 510 590",
				className: "crew-africa",
				children: [
					/* @__PURE__ */ d("path", {
						d: "M75 35 255 20 409 81 410 211 470 280 400 326 348 476 262 565 221 510 193 330 101 281 30 184Z",
						fill: "#dfd0a2",
						stroke: "#b3a16d",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ d("path", {
						d: e.flights.map((e, n) => `${n ? "L" : "M"}${t[e - 1].join(" ")}`).join(" "),
						fill: "none",
						stroke: "#b6522e",
						strokeWidth: "3"
					}),
					t.map(([t, r], i) => /* @__PURE__ */ f("g", {
						transform: `translate(${t} ${r})`,
						children: [
							/* @__PURE__ */ d("circle", {
								r: "18",
								fill: e.flights.includes(i + 1) ? "#b6522e" : "#7e7554"
							}),
							/* @__PURE__ */ d("text", {
								textAnchor: "middle",
								y: "7",
								fill: "white",
								fontSize: "22",
								fontWeight: "bold",
								children: i + 1
							}),
							/* @__PURE__ */ d("text", {
								textAnchor: "middle",
								y: "36",
								fill: "#55482f",
								fontSize: "14",
								children: n[i]
							})
						]
					}, i))
				]
			})
		});
	}
	if (e.stage === 19) return /* @__PURE__ */ f("div", {
		className: "crew-map",
		children: [
			/* @__PURE__ */ f("p", { children: [
				c("games.crewends.river", {
					n: e.river,
					total: z.goal
				}),
				" · ",
				c("games.crewends.riverDeal", { n: e.riverDeal })
			] }),
			/* @__PURE__ */ d("div", {
				className: "crew-river",
				children: Array.from({ length: 18 }, (t, n) => /* @__PURE__ */ f("span", {
					"data-current": n === e.river,
					children: [
						/* @__PURE__ */ d("b", { children: n === e.river ? "♟" : n }),
						z.crocodiles.includes(n) && /* @__PURE__ */ d("small", { children: c("games.crewends.crocodile") }),
						n === 17 && /* @__PURE__ */ d(et, { kind: "plane" })
					]
				}, n))
			}),
			e.revealCard !== null && /* @__PURE__ */ d($, { card: e.revealCard })
		]
	});
	if (e.stage === 11 || e.stage === 25) return /* @__PURE__ */ d("div", {
		className: "crew-map",
		children: /* @__PURE__ */ d("div", {
			className: "crew-mountain",
			children: Array.from({ length: e.stage === 11 ? 8 : 9 }, (t, n) => /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("span", { children: n + 1 }), e.board[n] === null ? /* @__PURE__ */ d("span", {
				className: "crew-card-slot",
				children: n === 0 ? "•" : e.stage === 11 ? [
					"↘",
					"＝",
					"↗"
				][ie[p][n] + 1] : [
					"",
					"≥+3",
					"■ ↗",
					"≤−4",
					"× ↘",
					"＝",
					"○ ↗",
					"▽ ↗",
					"× ↘"
				][n]
			}) : /* @__PURE__ */ d($, { card: e.board[n] })] }, n))
		})
	});
	if (e.stage === 23 && p === 1) return /* @__PURE__ */ d("div", {
		className: "crew-map crew-towers",
		children: e.towers.map((e, t) => /* @__PURE__ */ d("div", {
			className: "crew-tower",
			children: Array.from({ length: t ? 5 : 4 }, (t, n) => {
				let r = e[n];
				return /* @__PURE__ */ d("div", { children: r === void 0 ? /* @__PURE__ */ d("span", {
					className: "crew-card-slot",
					children: n + 1
				}) : /* @__PURE__ */ d($, {
					card: r,
					small: !0
				}) }, n);
			}).reverse()
		}, t))
	});
	if (e.stage === 23 && p === 2) return /* @__PURE__ */ d("div", {
		className: "crew-map",
		children: /* @__PURE__ */ f("div", {
			className: "crew-clock",
			"aria-label": c("games.crewends.clockBoard"),
			children: [/* @__PURE__ */ d("span", {
				className: "crew-clock-hands",
				"aria-hidden": !0,
				children: "◷"
			}), [
				[0, 0],
				[1, 0],
				[2, 0],
				[3, 0],
				[3, 1.5],
				[3, 3],
				[1.5, 3],
				[0, 3],
				[0, 1.5]
			].map(([n, r], a) => {
				let o = e.clockStart === null ? a : (a - e.clockStart + 9) % 9, s = e.board[o];
				return /* @__PURE__ */ f("button", {
					disabled: !t.some((e) => e.value === String(a)) || e.prompt !== "clock",
					onClick: () => i(t.find((e) => e.value === String(a))),
					"aria-label": c("games.crewends.clockPositions").split(",")[a],
					className: "crew-clock-cell",
					style: {
						left: `${n / 3 * 76}%`,
						top: `${r / 3 * 76}%`
					},
					children: [
						s == null ? /* @__PURE__ */ d("span", {
							className: "crew-card-slot",
							children: B[a] || "•"
						}) : /* @__PURE__ */ d($, {
							card: s,
							small: !0
						}),
						e.prompt === "clock" && t.some((e) => e.value === String(a)) && /* @__PURE__ */ d($e, {}),
						/* @__PURE__ */ f("small", { children: [
							c("games.crewends.clockPositions").split(",")[a],
							" · ",
							B[a] || c("games.crewends.clockCorner")
						] })
					]
				}, a);
			})]
		})
	});
	let h = e.stage === 14 ? ae[e.seats.length - 3].map((n, r) => /* @__PURE__ */ f("button", {
		className: "crew-grid-cell",
		disabled: e.prompt !== "marker" || !t.some((e) => e.value === String(r)),
		onClick: () => i(t.find((e) => e.value === String(r))),
		"aria-label": c("games.crewends.markerValue", { n }),
		"data-marked": e.markers.includes(r),
		children: [
			e.prompt === "marker" && t.some((e) => e.value === String(r)) && /* @__PURE__ */ d($e, {}),
			/* @__PURE__ */ d("b", { children: n }),
			e.markers.includes(r) && /* @__PURE__ */ d("span", {
				className: "crew-mark",
				children: "●"
			})
		]
	}, r)) : Array.from({ length: 9 }, (t, n) => {
		let r = e.stage === 23 && p === 2 ? n : R.indexOf(n), i = e.stage === 23 && p === 2, a = i ? e.board[e.clockStart === null ? n : (n - e.clockStart + 9) % 9] : e.board[n];
		return /* @__PURE__ */ f("div", {
			className: "crew-grid-cell",
			style: { "--crew-cell-index": r },
			children: [a == null ? /* @__PURE__ */ d("span", {
				className: "crew-card-slot",
				children: i ? B[n] || "•" : e.stage === 23 ? /* @__PURE__ */ d("span", {
					className: "crew-tate-types",
					children: se[r].map((e) => /* @__PURE__ */ d(Ze, { type: e }, e))
				}) : r + 1
			}) : /* @__PURE__ */ d($, {
				card: a,
				small: !0
			}), i && B[n] > 0 && /* @__PURE__ */ d("small", {
				className: "crew-cell-rule",
				children: B[n]
			})]
		}, n);
	});
	return /* @__PURE__ */ d("div", {
		className: "crew-map",
		children: /* @__PURE__ */ d("div", {
			className: `crew-grid${e.stage === 23 && e.subtask === 2 ? " is-clock" : ""}`,
			children: h
		})
	});
}
//#endregion
//#region src/games/crewends/identity.tsx
function rt({ member: e, ghost: t = !1, fallbackIndex: n = 0 }) {
	let r = s(), i = p[(e?.colorIndex ?? n) % p.length];
	return /* @__PURE__ */ f("span", {
		className: "crew-identity",
		style: { "--crew-player": t ? "#9c917e" : i.hex },
		children: [t ? /* @__PURE__ */ d("span", {
			className: "crew-ghost-avatar",
			"aria-hidden": !0,
			children: "✦"
		}) : /* @__PURE__ */ d("img", {
			src: m[(e?.avatar ?? n) % m.length],
			alt: ""
		}), /* @__PURE__ */ d("span", { children: t ? r("games.crewends.ghost") : e?.name || r(i.nameKey) })]
	});
}
//#endregion
//#region src/games/crewends/view-player.tsx
function it(e) {
	let t = e.public, n = e.readOnly ? void 0 : e.private, r = s(), a = o((e) => e.locale), [m, h] = i([]), [g, _] = i("play"), [y, b] = i(!1), [x, S] = i(!1), [C, ee] = i(!1), w = (n) => e.members.find((e) => e.rid === t.seats[n]?.rid), T = (e) => t.seats[e]?.rid === "$ghost" ? r("games.crewends.ghost") : w(e)?.name || r(p[(w(e)?.colorIndex ?? e) % p.length].nameKey), E = L[t.stage - 1], D = t.task === null ? null : V(t.task), O = (e, t) => r(`games.crewends.${e}`, t), [te, k] = i(""), ne = `${n?.seat}:${t.stage}:${t.round}`;
	te !== ne && (k(ne), _("play"), h([])), (g === "communicate" && !n?.communications.length || g === "bury" && !n?.burials.length) && (_("play"), h([]));
	let A = n?.choices.length || n?.legal.length, j = e.readOnly ? O("journeyEnded") : t.phase === "select" ? O("selectTask") : t.phase === "roundEnd" ? O(t.roundSuccess ? "roundWon" : "roundLost") : t.phase === "stageEnd" ? O("stageScore", { n: t.score ?? 0 }) : t.prompt ? O(`prompt.${t.prompt}`) : n?.legal.length ? O("yourTurn") : t.turn === null ? O("wait") : O("turn", { name: T(t.turn) }), M = (t) => {
		e.send({
			type: "choose",
			value: t.value
		}), h([]);
	}, N = m.filter((e) => n?.hand.includes(e) || t.ghost.includes(e)), P = n?.choices.filter((e) => e.card !== void 0 || e.cards !== void 0) ?? [], F = P.some((e) => e.cards !== void 0), I = P.length > 0 && [
		"bury",
		"scooter",
		"pass",
		"jeep",
		"show"
	].includes(t.prompt ?? ""), re = P.find((e) => {
		let t = e.cards ?? [e.card];
		return t.length === N.length && t.every((e) => N.includes(e));
	}), R = (e) => I ? P.some((t) => (t.cards ?? [t.card]).includes(e)) : g === "bury" ? n?.burials.includes(e) : g === "communicate" ? n?.communications.some((t) => t.card === e) : n?.legal.includes(e) && n.controlledSeat === n.seat, ie = (e) => h((t) => F ? t.includes(e) ? t.filter((t) => t !== e) : [...t.slice(-1), e] : t[0] === e ? [] : [e]), ae = () => {
		if (re && I) {
			M(re);
			return;
		}
		N.length === 1 && R(N[0]) && (e.send({
			type: g === "bury" ? "bury" : "play",
			card: N[0]
		}), h([]));
	}, oe = (e) => e.seat === void 0 ? e.label === "color" ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("span", {
		className: "crew-color-symbol",
		children: /* @__PURE__ */ d(Ze, { type: e.n })
	}), O(`colors.${v[e.n]}`)] }) : O(`choice.${e.label}`, { n: e.n ?? "" }) + (e.label === "route" ? ` ${e.value}` : "") : e.label === "pair" ? `${T(e.seat)} · ${T(e.n)}` : T(e.seat), z = /* @__PURE__ */ d("div", {
		className: "crew-choices",
		children: n?.choices.filter((e) => !I || e.card === void 0 && e.cards === void 0).map((e) => /* @__PURE__ */ d("button", {
			className: e.card === void 0 ? "crew-choice" : "crew-pick-card",
			onClick: () => M(e),
			children: e.card === void 0 ? /* @__PURE__ */ f(u, { children: [oe(e), e.value.startsWith("task:") && /* @__PURE__ */ d("b", { children: t.stacks[Number(e.value.slice(5))].difficulty ?? "?" })] }) : /* @__PURE__ */ d($, { card: e.card })
		}, e.value))
	}), se = t.task === null ? "" : O("taskTexts").split("\n")[t.task - 1], B = O("specialRules").split("\n")[[
		5,
		8,
		11,
		14,
		16,
		19,
		20,
		23,
		25
	].indexOf(t.stage)], ce = n ? /* @__PURE__ */ f("div", {
		className: "crew-hand",
		children: [/* @__PURE__ */ f("div", {
			className: "crew-hand-tools",
			children: [
				/* @__PURE__ */ d("b", { children: O("hand") }),
				/* @__PURE__ */ d("span", { children: O("count", { n: n.hand.length }) }),
				n.communications.length > 0 && /* @__PURE__ */ d("button", {
					"aria-pressed": g === "communicate",
					onClick: () => {
						_(g === "communicate" ? "play" : "communicate"), h([]);
					},
					children: O("communicate")
				}),
				n.burials.length > 0 && /* @__PURE__ */ d("button", {
					"aria-pressed": g === "bury",
					onClick: () => {
						_(g === "bury" ? "play" : "bury"), h([]);
					},
					children: O("hideSwap")
				}),
				g !== "communicate" && /* @__PURE__ */ d("button", {
					className: "crew-primary",
					disabled: I ? !re : N.length !== 1 || !R(N[0]),
					onClick: ae,
					children: O(I ? `prompt.${t.prompt}` : g === "bury" ? "hideSwap" : "play")
				}),
				g === "communicate" && n.communications.filter((e) => e.card === N[0]).map((t) => /* @__PURE__ */ d("button", {
					className: "crew-primary",
					onClick: () => {
						e.send({
							type: "communicate",
							...t
						}), h([]), _("play");
					},
					children: O(t.mode)
				}, t.mode))
			]
		}), /* @__PURE__ */ d("div", {
			className: "crew-hand-scroll",
			children: /* @__PURE__ */ d("div", {
				className: "crew-hand-row",
				children: [...n.hand].sort((e, t) => e - t).map((e) => /* @__PURE__ */ f("button", {
					className: `crew-hand-pick${N.includes(e) ? " is-selected" : ""}${e === n.hiddenCard ? " is-buried" : ""}`,
					disabled: !R(e),
					"aria-pressed": N.includes(e),
					onClick: () => ie(e),
					children: [
						/* @__PURE__ */ d($, { card: e }),
						R(e) && /* @__PURE__ */ d($e, {}),
						e === n.hiddenCard && /* @__PURE__ */ d("span", {
							className: "crew-hidden-label",
							children: O("hidden")
						})
					]
				}, e))
			})
		})]
	}) : /* @__PURE__ */ d("div", {
		className: "crew-hand-tools",
		children: O("wait")
	});
	return /* @__PURE__ */ f("div", {
		className: "crew-game",
		"data-readonly": e.readOnly,
		children: [/* @__PURE__ */ d(c, {
			adaptive: !0,
			actionsHeight: e.readOnly ? void 0 : "crew-actions-height",
			actions: ce,
			banner: /* @__PURE__ */ f("div", {
				className: "crew-header",
				children: [/* @__PURE__ */ f("div", {
					className: "crew-heading",
					children: [
						/* @__PURE__ */ d("span", {
							className: "crew-stage-stamp",
							children: String(t.stage).padStart(2, "0")
						}),
						/* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("small", { children: O("name") }), /* @__PURE__ */ d("h1", { children: a === "zh" ? E.zh : E.name })] }),
						/* @__PURE__ */ d("button", {
							onClick: () => b(!0),
							children: O("details")
						})
					]
				}), /* @__PURE__ */ d("div", {
					className: "crew-seats",
					children: t.seats.map((r, i) => /* @__PURE__ */ f(at, {
						id: r.rid,
						fallbackIndex: i,
						current: !e.readOnly && t.turn === i,
						mine: n?.seat === i,
						member: w(i),
						ghost: r.rid === "$ghost",
						children: [
							/* @__PURE__ */ d("strong", { children: /* @__PURE__ */ d(rt, {
								fallbackIndex: i,
								member: w(i),
								ghost: r.rid === "$ghost"
							}) }),
							/* @__PURE__ */ f("span", { children: [
								O("count", { n: r.count }),
								" · ",
								O("tricks", { n: r.tricks })
							] }),
							/* @__PURE__ */ d("small", { children: t.guide === i ? O("guide") : t.scout === i && t.seats.some((e) => e.rid === "$ghost") ? O("scout") : t.driver === i ? O("driver") : "" })
						]
					}, r.rid))
				})]
			}),
			children: /* @__PURE__ */ f("div", {
				className: "crew-journal",
				"data-special": E.special,
				children: [/* @__PURE__ */ f("section", {
					className: "crew-journal-map",
					children: [
						!E.special && /* @__PURE__ */ d("div", {
							className: "crew-place-art",
							"aria-hidden": !0
						}),
						/* @__PURE__ */ d(nt, {
							pub: t,
							choices: n?.choices ?? [],
							onChoose: M,
							compact: !0
						}),
						!E.special && /* @__PURE__ */ d("button", {
							className: "crew-route-open",
							onClick: () => ee(!0),
							children: O("fullRoute")
						}),
						E.special && /* @__PURE__ */ f("div", {
							className: "crew-attempts",
							children: [/* @__PURE__ */ d("b", { children: O("attempt", { n: t.attempt }) }), E.triple && /* @__PURE__ */ f("span", { children: [
								O("subtask", { n: Math.min(t.subtask + 1, 3) }),
								" · ",
								t.subResults.map((e, t) => /* @__PURE__ */ d("span", { children: e ? "●" : "×" }, t))
							] })]
						}),
						t.removed.length > 0 && /* @__PURE__ */ f("details", {
							className: "crew-removed",
							children: [/* @__PURE__ */ d("summary", { children: O("removed") }), /* @__PURE__ */ d("div", { children: t.removed.map((e) => /* @__PURE__ */ d($, {
								card: e,
								small: !0
							}, e)) })]
						})
					]
				}), /* @__PURE__ */ f("section", {
					className: "crew-journal-play",
					children: [
						/* @__PURE__ */ f("div", {
							className: "crew-task-note",
							children: [/* @__PURE__ */ f("div", {
								className: "crew-task-label",
								children: [
									/* @__PURE__ */ d("b", { children: t.task === null ? O("stage", { n: t.stage }) : O("task", { n: t.task }) }),
									D && /* @__PURE__ */ d("span", { children: D.individual ? O("individual") : D.special ? O("cumulative") : D.random ? O("random") : "" }),
									/* @__PURE__ */ d("span", {
										className: "crew-tokens",
										title: O("tokens"),
										children: Array.from({ length: t.seats.some((e) => e.rid === "$ghost") ? 2 : t.seats.length }, (e, n) => /* @__PURE__ */ d("i", { "data-used": n >= t.tokens }, n))
									})
								]
							}), t.phase === "select" ? z : /* @__PURE__ */ f(u, { children: [
								/* @__PURE__ */ d("p", { children: E.special ? B : se }),
								D && (D.special ? /* @__PURE__ */ d("small", { children: O("tallyRule", {
									n: Math.abs(D.offsets[t.seats.length - 3]),
									mult: D.double5 && t.seats.length === 5 ? 2 : 1
								}) }) : /* @__PURE__ */ d("small", { children: O("advance", { n: ue(D.id, t.seats.length) }) })),
								t.owner !== null && /* @__PURE__ */ d("strong", { children: O("owner", { name: T(t.owner) }) }),
								t.cumulative !== null && /* @__PURE__ */ d("b", {
									className: "crew-tally",
									children: O("raw", { n: t.cumulative })
								}),
								t.votes && /* @__PURE__ */ d("div", {
									className: "crew-votes",
									children: t.votes.map((e, t) => /* @__PURE__ */ f("span", { children: [
										T(t),
										" ",
										e ? "●" : "×"
									] }, t))
								}),
								n && Object.keys(n.secrets).length > 0 && /* @__PURE__ */ f("details", {
									className: "crew-secret",
									children: [/* @__PURE__ */ d("summary", { children: O("secrets") }), /* @__PURE__ */ d("div", { children: Object.entries(n.secrets).map(([e, t]) => /* @__PURE__ */ d("div", { children: e.startsWith("target") ? /* @__PURE__ */ d($, {
										card: t,
										small: !0
									}) : e === "neighbor" ? T(t) : e === "color" ? O(`colors.${v[t]}`) : e.startsWith("pred:") ? O("prediction", { n: t }) : O("secretNumber", { n: t }) }, e)) })]
								}),
								Object.keys(t.parameters).length > 0 && /* @__PURE__ */ d("div", {
									className: "crew-parameters",
									children: Object.entries(t.parameters).map(([e, t]) => /* @__PURE__ */ d("span", { children: e.startsWith("pred:") ? `${T(Number(e.slice(5)))}: ${t}` : e.startsWith("forbid:") ? /* @__PURE__ */ f(u, { children: [
										T(Number(e.slice(7))),
										": ",
										/* @__PURE__ */ d(Ze, { type: t })
									] }) : e === "color" ? /* @__PURE__ */ d(Ze, { type: t }) : e === "number" ? t : e.startsWith("player") ? T(t) : e === "missing" || e === "guess" ? /* @__PURE__ */ f(u, { children: [
										O(e),
										": ",
										/* @__PURE__ */ d($, {
											card: t,
											small: !0
										})
									] }) : null }, e))
								})
							] })]
						}),
						/* @__PURE__ */ d("div", {
							className: "crew-phase",
							children: /* @__PURE__ */ d(l, {
								tone: A ? "accent" : "info",
								text: j + (n?.choices.length && n.choiceSeat !== n.seat ? ` · ${T(n.choiceSeat)}` : ""),
								accent: "#a94f2c",
								chip: O("trick", {
									n: Math.min(t.trickNumber, t.trickLimit),
									total: t.trickLimit
								})
							})
						}),
						t.prompt === "branch" && /* @__PURE__ */ d("p", {
							className: "crew-branch-info",
							children: O("branchInfo")
						}),
						t.phase !== "select" && !I && ![
							"route",
							"clock",
							"marker"
						].includes(t.prompt ?? "") && z,
						n?.selected && /* @__PURE__ */ d("p", {
							className: "crew-submitted",
							children: O("selected")
						}),
						t.notice && /* @__PURE__ */ d("p", {
							role: "status",
							children: O(t.notice)
						}),
						t.phase === "roundEnd" && /* @__PURE__ */ f("div", {
							className: `crew-round-result${t.roundSuccess ? " is-success" : ""}`,
							children: [/* @__PURE__ */ d("b", { children: O(t.roundSuccess ? "roundWon" : "roundLost") }), !E.special && t.roundSuccess && /* @__PURE__ */ d("span", { children: O("advance", { n: t.movement }) })]
						}),
						/* @__PURE__ */ f("div", {
							className: `crew-trick${t.phase === "collect" ? " is-collecting" : ""}`,
							children: [/* @__PURE__ */ f("div", {
								className: "crew-trick-heading",
								children: [/* @__PURE__ */ d("b", { children: O("current") }), /* @__PURE__ */ d("button", {
									disabled: !t.last,
									onClick: () => S(!0),
									children: O("last")
								})]
							}), /* @__PURE__ */ d("div", {
								className: "crew-trick-row",
								children: t.seats.map((n, r) => {
									let i = t.plays.find((e) => e.seat === r);
									return /* @__PURE__ */ d(ot, {
										seat: r,
										card: i?.card,
										name: T(r),
										member: w(r),
										ghost: n.rid === "$ghost",
										current: !e.readOnly && t.turn === r
									}, n.rid);
								})
							})]
						}),
						t.comms.length > 0 && /* @__PURE__ */ d("div", {
							className: "crew-comms",
							children: t.comms.map((e) => /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d($, {
								card: e.card,
								small: !0
							}), /* @__PURE__ */ f("span", { children: [T(e.seat), /* @__PURE__ */ d("b", { children: O(e.mode) })] })] }, e.card))
						}),
						t.ghost.length > 0 && /* @__PURE__ */ f("section", {
							className: "crew-ghost",
							children: [/* @__PURE__ */ d("b", { children: O("ghostHand") }), /* @__PURE__ */ d("div", {
								className: "crew-ghost-row",
								children: t.ghost.map((r, i) => {
									let a = r !== null && (n?.controlledSeat === 2 && n.legal.includes(r) || I && P.some((e) => (e.cards ?? [e.card]).includes(r)));
									return /* @__PURE__ */ f("button", {
										className: `crew-ghost-stack${N.includes(r ?? -1) ? " is-selected" : ""}`,
										disabled: !a,
										onClick: () => {
											r !== null && (I ? ie(r) : e.send({
												type: "play",
												card: r
											}));
										},
										children: [
											t.ghostCovered[i] && /* @__PURE__ */ d($, {
												back: !0,
												small: !0
											}),
											r === null ? /* @__PURE__ */ d("span", {
												className: "crew-ghost-empty",
												children: i + 1
											}) : /* @__PURE__ */ d($, {
												card: r,
												small: !0
											}),
											a && /* @__PURE__ */ d($e, {})
										]
									}, i);
								})
							})]
						})
					]
				})]
			})
		}), (y || x || C) && /* @__PURE__ */ d("div", {
			className: "crew-modal-backdrop",
			children: /* @__PURE__ */ f("section", {
				className: "crew-modal",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": O(C ? "fullRoute" : x ? "last" : "details"),
				children: [/* @__PURE__ */ d("button", {
					className: "crew-modal-close",
					onClick: () => {
						b(!1), S(!1), ee(!1);
					},
					children: O("close")
				}), C ? /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("h2", { children: a === "zh" ? E.zh : E.name }), /* @__PURE__ */ d(nt, {
					pub: t,
					choices: n?.choices ?? [],
					onChoose: M
				})] }) : x ? /* @__PURE__ */ f(u, { children: [
					/* @__PURE__ */ d("h2", { children: O("last") }),
					/* @__PURE__ */ d("div", {
						className: "crew-last-cards",
						children: t.last?.plays.map((e, t) => /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d($, { card: e.card }), /* @__PURE__ */ d("span", { children: T(e.seat) })] }, t))
					}),
					t.last && /* @__PURE__ */ f("p", { children: [
						T(t.last.winner),
						" · ",
						O("tricks", { n: 1 })
					] })
				] }) : /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("h2", { children: O("details") }), /* @__PURE__ */ d("p", {
					className: "crew-full-rules",
					children: O("rules")
				})] })]
			})
		})]
	});
}
function at({ id: e, current: t, mine: n, children: r, member: i, ghost: o, fallbackIndex: s }) {
	let { ref: c } = a(`seat:${e}`);
	return /* @__PURE__ */ d("div", {
		ref: c,
		className: "crew-seat",
		style: { "--crew-player": o ? "#9c917e" : p[(i?.colorIndex ?? s) % p.length].hex },
		"data-current": t,
		"data-mine": n,
		children: r
	});
}
function ot({ seat: e, card: t, name: n, current: r, member: i, ghost: o }) {
	let { ref: s, hidden: c } = a(`play:${e}`);
	return /* @__PURE__ */ f("div", {
		className: "crew-trick-slot",
		"data-current": r,
		children: [/* @__PURE__ */ d("div", {
			ref: s,
			style: { visibility: c ? "hidden" : void 0 },
			children: t === void 0 ? /* @__PURE__ */ d("span", {
				className: "crew-card-slot",
				"aria-label": n,
				children: /* @__PURE__ */ d("span", {
					"aria-hidden": !0,
					children: "·"
				})
			}) : /* @__PURE__ */ d($, { card: t })
		}), /* @__PURE__ */ d("span", { children: /* @__PURE__ */ d(rt, {
			fallbackIndex: e,
			member: i,
			ghost: o
		}) })]
	});
}
//#endregion
//#region src/games/crewends/bot.ts
var st = {
	safety: 80,
	cumulative: 12,
	preserveTrump: .25,
	target: 16
};
function ct(e, t) {
	let n = t.hand;
	return e.task === 31 ? Math.round(n.filter((e) => y(e) === 2).length * .8) : e.task === 32 ? Math.max(1, Math.min(8, Math.round(n.filter((e) => y(e) === 3).length * .8))) : Math.max(0, Math.round(n.reduce((e, t) => e + (y(t) === 4 ? .9 : b(t) >= 8 ? .7 : b(t) >= 6 ? .25 : 0), 0)));
}
function lt(e, t) {
	let n = t.choices;
	if (e.phase === "select") {
		let t = n.filter((e) => e.value.startsWith("task:"));
		return t.reduce((t, n) => {
			let r = Number(n.value.split(":")[1]), i = Number(t.value.split(":")[1]), a = (t) => e.stacks[t].difficulty === null ? 2 : Math.min(e.stacks[t].difficulty, 3);
			return a(r) > a(i) ? n : t;
		}, t[0] ?? n[0]);
	}
	let r = e.prompt;
	if (r === "vote") return n.find((e) => e.value === "yes") ?? n[0];
	if (r === "prediction") {
		let r = ct(e, t);
		return n.reduce((e, t) => Math.abs((t.n ?? 0) - r) < Math.abs((e.n ?? 0) - r) ? t : e);
	}
	if (r === "assign") return n.find((e) => e.seat === t.seat) ?? n[0];
	if (r === "pass" || r === "jeep" || r === "scooter" || r === "bury") {
		let e = (e) => (e.cards ?? (e.card === void 0 ? [] : [e.card])).reduce((e, t) => e + (y(t) === 4 ? 20 : b(t)), 0);
		return n.reduce((t, n) => e(n) < e(t) ? n : t);
	}
	if (r === "color" || r === "forbid") return n.reduce((e, n) => t.hand.filter((e) => y(e) === n.n).length < t.hand.filter((t) => y(t) === e.n).length ? n : e);
	if (r === "number") return n.find((e) => e.n === 0) ?? n[0];
	if (r === "show") return n.reduce((n, r) => Math.abs(b(r.card) - ct(e, t) * 2) < Math.abs(b(n.card) - ct(e, t) * 2) ? r : n);
	if (r === "flight") return n.find((e) => e.value !== "skip") ?? n[0];
	if (r === "dogPermission") return n.find((e) => e.value === "yes") ?? n[0];
	if (r === "clock") {
		let t = e.board[0];
		if (t === null) return n[0];
		let r = [
			0,
			1,
			2,
			0,
			3,
			0,
			6,
			0,
			9
		];
		return n.find((e) => r[e.n] === b(t)) ?? n.find((e) => r[e.n] === 0) ?? n[0];
	}
	return r === "guess" ? n.find((n) => !t.hand.includes(n.card) && !e.plays.some((e) => e.card === n.card)) ?? n[0] : n[0];
}
function ut(e, t, n, r) {
	let i = e.task, a = e.owner ?? e.guide, o = n.winner, s = n.plays.map((e) => e.card), c = o === a, l = o === t.seat, u = s[w(s)];
	if (i === null) return 0;
	let d = 0, f = (e) => e.filter((e) => s.includes(e)).length * (c ? r : -r);
	if ((i === 48 || i === 53) && (d += f(Object.entries(t.secrets).filter(([e]) => e.startsWith("target")).map(([, e]) => e))), i === 50 && (d += f(S.filter((e) => b(e) === 1))), i === 51 && (d += f([
		15,
		19,
		27
	])), i === 94 && (d += f([7, 31])), i === 17 && (d += (e.trickNumber % 2 == 1 && e.trickNumber <= 7) === c ? r : -r), i === 22 && (d += f([30])), [
		3,
		29,
		32,
		54,
		55
	].includes(i)) {
		let n = e.parameters["pred:" + t.seat] ?? t.secrets["pred:" + t.seat];
		n !== void 0 && l && (d += e.seats[t.seat].tricks < n ? r : -r);
	}
	return i === 36 && c && (d += n.plays[0].seat === a ? -r : e.seats[a].tricks < 3 ? r : -r), i === 72 && (d += o === a ? e.seats.some((e, t) => t !== a && e.tricks === 0) ? -2 : 2 : e.seats[o].tricks === 0 ? r : -r), [
		41,
		75,
		80,
		68
	].includes(i) && (d += c || i === 41 || i === 75 ? s.filter((e) => y(e) !== 4).length : 0), i === 59 && e.trickNumber < e.trickLimit && s.includes(12) && (d -= r), i === 81 && e.trickNumber < e.trickLimit && (d += s.filter((e) => b(e) < 5).length * .5), (i === 4 || i === 52) && (d += u === 37 ? r : 0), d;
}
function dt(e = st) {
	return (t, n) => {
		let r = t.public, i = t.private;
		if (!i) return null;
		let a = n.memory, o = a?.round === r.round && a.stage === r.stage ? structuredClone(a) : {
			round: r.round,
			stage: r.stage,
			history: [],
			communicated: !1,
			observed: 0
		}, s = r.seats.reduce((e, t) => e + t.tricks, 0);
		if (r.last && s > o.observed && (o.history.push(r.last), o.observed = s), i.choices.length) return {
			action: {
				type: "choose",
				value: lt(r, i).value
			},
			memory: o
		};
		if (!i.legal.length) return null;
		if (n.difficulty === "weak") return {
			action: {
				type: "play",
				card: i.legal.reduce((e, t) => b(t) < b(e) ? t : e)
			},
			memory: o
		};
		if (!o.communicated && i.communications.length && r.trickNumber === 1) {
			let e = i.communications.find((e) => e.mode === "only") ?? i.communications.find((e) => b(e.card) >= 8) ?? i.communications[0];
			return o.communicated = !0, {
				action: {
					type: "communicate",
					...e
				},
				memory: o
			};
		}
		let c = /* @__PURE__ */ new Set([
			...i.hand,
			...r.board.filter((e) => e !== null),
			...r.ghost.filter((e) => e !== null),
			...r.removed,
			...r.plays.map((e) => e.card),
			...o.history.flatMap((e) => e.plays.map((e) => e.card))
		]);
		if (r.seats.length === 5 && [
			5,
			8,
			11,
			14,
			16,
			23,
			25
		].includes(r.stage) && s >= 3) for (let e of o.history.slice(0, 3)) for (let t of e.plays) !i.hand.includes(t.card) && !r.board.includes(t.card) && c.delete(t.card);
		let l = S.filter((e) => !c.has(e)), u = (t) => {
			let n = 0;
			for (let a = 0; a < 12; a++) {
				let s = [...r.plays, {
					seat: i.controlledSeat ?? i.seat,
					card: t
				}], c = new Set(s.map((e) => e.card)), u = r.seats.filter((e, t) => e.count > 0 || s.some((e) => e.seat === t)).length;
				for (let e = s.length; e < u; e++) {
					let n = (r.leader + e) % r.seats.length, i = r.comms.filter((e) => e.seat === n).map((e) => e.card).filter((e) => !c.has(e)), o = r.seats[n].rid === "$ghost", u = o ? r.ghost.filter((e) => e !== null && !c.has(e)) : [], d = o ? T(u, s.map((e) => e.card)) : i.length ? i : l.filter((e) => !c.has(e));
					if (!d.length) break;
					let f = d[(a * 7 + e * 11 + t * 3) % d.length];
					s.push({
						seat: n,
						card: f
					}), c.add(f);
				}
				if (s.length !== u || s.length < 2) continue;
				let d = {
					plays: s,
					winner: s[w(s.map((e) => e.card))].seat
				}, f = ut(r, i, d, e.target);
				if (r.task !== null) {
					let t = {
						...r.parameters,
						...i.secrets,
						two: +!!r.seats.some((e) => e.rid === "$ghost"),
						scout: r.scout
					}, n = {
						id: r.task,
						seats: r.seats.length,
						guide: r.guide,
						owner: r.owner ?? r.guide,
						params: t,
						final: !1
					}, a = de({
						...n,
						history: o.history
					}), s = de({
						...n,
						history: [...o.history, d]
					});
					s.failed && !a.failed && (f -= e.safety), V(r.task).special && (f += (s.raw - a.raw) * e.cumulative);
				}
				n += f;
			}
			return n / 12 - (y(t) === 4 ? b(t) * e.preserveTrump : b(t) * .015);
		};
		return {
			action: {
				type: "play",
				card: i.legal.reduce((e, t) => u(t) > u(e) ? t : e)
			},
			memory: o
		};
	};
}
var ft = dt(), pt = {
	play(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null, i = t.anchor(`play:${n.seat}`);
		return !r || !i ? null : {
			ms: 200,
			hide: [`play:${n.seat}`],
			node: /* @__PURE__ */ d(h, {
				from: r,
				to: i,
				ms: 190,
				children: /* @__PURE__ */ d($, {
					card: n.card,
					style: { width: i.w }
				})
			})
		};
	},
	collect(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return r ? {
			ms: 550,
			hide: n.plays.map((e) => `play:${e.seat}`),
			node: n.plays.map((e) => {
				let n = t.anchor(`play:${e.seat}`);
				if (!n) return null;
				let i = n.w * .4, a = n.h * .4, o = {
					x: r.x + (r.w - i) / 2,
					y: r.y + (r.h - a) / 2,
					w: i,
					h: a
				};
				return /* @__PURE__ */ d(h, {
					from: n,
					to: o,
					ms: 500,
					children: /* @__PURE__ */ d($, {
						card: e.card,
						style: { width: n.w }
					})
				}, e.seat);
			})
		} : null;
	}
};
//#endregion
//#region src/games/crewends/game-over.tsx
function mt({ public: e, result: t, onPlayAgain: n, onBackToLobby: r, members: a, myRid: c }) {
	let l = e, u = s(), p = o((e) => e.locale), m = Object.values(t.scores ?? {})[0] ?? 0, h = l.scores.length ? l.scores : [{
		stage: l.stage,
		score: l.score ?? 0
	}], _ = h.reduce((e, t) => e + t.score, 0), v = _ - m, [y, b] = i(!1);
	return /* @__PURE__ */ f("div", {
		className: "crew-ending-root",
		children: [/* @__PURE__ */ f("div", {
			className: "crew-ending-board",
			hidden: !y,
			children: [/* @__PURE__ */ d(it, {
				public: l,
				members: a,
				myRid: c,
				send: () => {},
				readOnly: !0
			}), /* @__PURE__ */ d("button", {
				className: "crew-return-results crew-primary",
				onClick: () => b(!1),
				children: u("games.crewends.showResults")
			})]
		}), /* @__PURE__ */ f("div", {
			className: "crew-ending",
			hidden: y,
			children: [
				/* @__PURE__ */ f("div", {
					className: "crew-ending-heading",
					children: [
						/* @__PURE__ */ d("small", { children: u("games.crewends.name") }),
						/* @__PURE__ */ d("h1", { children: u("games.crewends.resultTitle") }),
						/* @__PURE__ */ d("button", {
							className: "crew-choice",
							onClick: () => b(!0),
							children: u("games.crewends.viewFinal")
						})
					]
				}),
				/* @__PURE__ */ f("div", {
					className: "crew-ending-scroll",
					children: [/* @__PURE__ */ f("section", {
						className: "crew-ending-summary",
						children: [
							/* @__PURE__ */ f("div", {
								className: "crew-total",
								children: [
									/* @__PURE__ */ d("span", { children: u("games.crewends.total") }),
									/* @__PURE__ */ d("strong", { children: m }),
									/* @__PURE__ */ d("small", { children: u("games.crewends.lowerBetter") })
								]
							}),
							/* @__PURE__ */ f("dl", {
								className: "crew-score-math",
								children: [/* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("dt", { children: u("games.crewends.stageTotal") }), /* @__PURE__ */ d("dd", { children: _ })] }), l.scores.length === 24 && /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("dt", { children: u("games.crewends.highestDeduction") }), /* @__PURE__ */ f("dd", { children: ["−", v] })] })]
							}),
							/* @__PURE__ */ d("div", {
								className: "crew-ending-art",
								"aria-hidden": !0
							})
						]
					}), /* @__PURE__ */ f("section", {
						className: "crew-ending-ledger",
						children: [/* @__PURE__ */ d("h2", { children: u("games.crewends.scoreList") }), /* @__PURE__ */ d("ol", {
							className: "crew-score-list",
							children: h.map((e) => /* @__PURE__ */ f("li", { children: [
								/* @__PURE__ */ d("span", {
									className: "crew-stage-stamp",
									children: String(e.stage).padStart(2, "0")
								}),
								/* @__PURE__ */ d("span", { children: p === "zh" ? L[e.stage - 1].zh : L[e.stage - 1].name }),
								/* @__PURE__ */ d("b", { children: e.score })
							] }, e.stage))
						})]
					})]
				}),
				/* @__PURE__ */ f("div", {
					className: "crew-ending-controls",
					children: [
						r && /* @__PURE__ */ d(g, {
							className: "crew-choice",
							label: u("session.result.backToLobby"),
							confirmLabel: u("games.crewends.confirmLeave"),
							onConfirm: r
						}),
						" ",
						n && /* @__PURE__ */ d(g, {
							className: "crew-primary",
							label: u("session.result.playAgain"),
							confirmLabel: u("games.crewends.confirmAgain"),
							onConfirm: n
						}),
						" ",
						!n && !r && /* @__PURE__ */ d("p", { children: u("session.result.waitHost") })
					]
				})
			]
		})]
	});
}
//#endregion
//#region src/games/crewends/options.tsx
function ht({ value: e, onChange: t }) {
	let n = s(), r = o((e) => e.locale), i = te.safeParse(e), a = i.success ? i.data : te.parse(void 0);
	return /* @__PURE__ */ f("div", { children: [
		/* @__PURE__ */ f("label", {
			className: "flex flex-col gap-2 font-bold",
			children: [n("games.crewends.selectStage"), /* @__PURE__ */ d("select", {
				className: "rounded-lg border p-2",
				value: a.stage,
				onChange: (e) => t({
					...a,
					stage: Number(e.target.value)
				}),
				children: L.map((e) => /* @__PURE__ */ f("option", {
					value: e.id,
					children: [
						e.id,
						". ",
						r === "zh" ? e.zh : e.name
					]
				}, e.id))
			})]
		}),
		/* @__PURE__ */ d(_, {
			checked: a.campaign,
			label: n("games.crewends.campaign"),
			hint: n(a.campaign ? "games.crewends.campaignOn" : "games.crewends.campaignOff"),
			onChange: () => t({
				...a,
				campaign: !a.campaign
			})
		}),
		/* @__PURE__ */ d(_, {
			checked: a.hardGhost,
			label: n("games.crewends.hardGhost"),
			hint: n("games.crewends.hardGhostHelp"),
			onChange: () => t({
				...a,
				hardGhost: !a.hardGhost
			})
		})
	] });
}
//#endregion
//#region .bgparty/cache/pack-entry/crewends/entry.tsx
var gt = {
	definition: Ye,
	View: it,
	bot: ft,
	fx: pt,
	OverView: mt,
	Options: ht,
	locales: {
		zh: {
			highestDeduction: "扣除最高单项",
			fullRoute: "完整路线",
			journeyEnded: "旅程已结束",
			stageTotal: "阶段合计",
			viewFinal: "查看最终局面",
			showResults: "返回旅程记录",
			confirmLeave: "确认返回大厅",
			confirmAgain: "确认再来一局",
			name: "星际探险队：世界尽头之旅",
			desc: "有限交流的合作吃墩：完成任务，穿越25段环球旅程，与时间竞速。",
			rules: "目标:\n全体玩家合作完成环球旅程。普通阶段通过完成任务前进，队伍必须到达飞机。阶段分数越低越好；完整旅程不计教学阶段的分数；计算总分时，舍弃得分最高的一个阶段，再将其余阶段的分数相加。\n准备:\n40张游戏牌包括蓝、绿、粉、黄四种颜色的1至9，以及直升机1至4。直升机是将牌，也是一种独立类型。将104张任务牌分为两堆，较容易的1至6号任务洗匀后各放三张在顶部。每轮先根据背面难度选任务，再洗牌并发牌。持直升机4的人担任向导，领出第一墩。\n流程:\n按座次顺序每人出一张牌。必须跟随首张牌的类型；没有该类型时可以出任意牌。直升机胜过所有颜色牌；有多张直升机时较大者赢墩。否则首出颜色中数字最大的人赢墩，赢家领出下一墩。三人、四人和五人对局通常分别打13、10、8墩；三人对局时剩余一张牌。只允许翻看最近一墩。\n不能以语言、手势或暗示透露手牌。任务准备结束后，每墩开始前可以使用团队共享的通信令牌，数量等于真人数。同一人可以使用多个。展示一张非直升机牌，并声明它是该颜色的最高牌、唯一牌或最低牌；之后不能更改声明。展示的牌仍可正常打出，令牌本轮不能重复使用。\n个人任务先由所有队员秘密表决。全部提交后同时公开，向导从愿意承担的人中指定一人；全部拒绝时重新表决。秘密目标与秘密预测只对相应玩家可见。任务指定的公开预测按向导起始的座次依次声明。\n普通阶段:\n每阶段每个任务堆最多将顶牌放到底部一次；带随机背面的任务不能弃置。普通任务成功后前进对应难度格数。累计任务按牌面条件累计，再扣除人数对应的格数；结果小于或等于0算失败。不能主动少走。遇阻断线时停在线前，下一轮才能跨越。每个任务后时间前进一格；驴地形前进两格。任务明确结束或已经失败时可以结束本轮，砍刀地形必须打完。\n· 火车没有额外效果。\n· 步行必须选择估计难度较低的顶牌，累计与随机任务按3估计。\n· 滑翔伞每人暗扣一张牌，墩间可以换牌，最后一墩打暗扣牌；禁止通信。\n· 滑雪地形在蓝7所在的墩结束后将整副手牌及通信牌传左。\n· 滑板车地形由初始持蓝1者在首墩前秘密与一人交换牌，不能交换直升机4。\n· 自行车地形下，手中有自行车图标者不能通信。\n· 直升机地形下，含直升机的墩结束后每人同时秘密传左一张牌，不能传通信牌，除非剩余手牌全部是通信牌。\n· 迷雾地形先向每位玩家发放所示数量的牌；三人对局中，向导额外获得一张牌；每墩结束依次补牌，直至牌堆空。\n· 暴风雨通信先掷令牌：绿色才可展示，红色直接耗用。\n· 吉普车地形第三墩后每人秘密交两张非通信牌，洗匀后各收两张。前三墩通信必须保留足够未通信牌，以保证第三墩后能交出两张。\n· 砍刀地形下，若一墩含砍刀且总点数为15或16（三座）、20或21（四座）、25或26（五座），任务失败，仍需要打完本轮的全部牌。\n· 狗拉雪橇先指定驾驶员，由其决定任务、弃任务并批准通信；驾驶员可在每墩前决定自己领出。\n· 缆车地形：任务失败时，队伍退至本阶段的第一个缆车格。\n· 冰面地形：任务失败时，队伍后退一格。\n· 裂冰地形：任务成功时，队伍改为后退本应前进的格数，但不会退到起点之前；任务失败时，队伍留在原地。\n特殊阶段:\n庞贝、珠峰、马丘比丘、66号公路与伦敦各有三个子任务，每项最多两次。完成零至三项分别获得6、4、2、0分；全部子任务均在首次尝试时完成，则获得负 2 分。非洲、澳门、亚马孙与地下墓穴各有一项任务，最多三次；首次、第二次、第三次成功分别得负2、0、2分，全部失败获得4分。具体目标显示在阶段图与任务说明中。\n除亚马孙与66号公路外，三名真人玩家先随机公开移除七张非直升机4的牌；五名真人玩家第三墩后，保留已放到任务板上的牌，从其他已出牌中补足三张保留，其余洗匀后每人补两张。双人不移除牌。\n双人:\n两名真人与幽灵组成三人对局，难度按三人对局，只有两枚通信令牌。幽灵有七叠牌，每叠一暗一明，只能出明牌；下方牌在墩结束后翻开。向导以外的真人为侦察员，独自操作幽灵，不得讨论。可选困难模式限制幽灵赢墩后的领出位置。迷雾只给真人补牌；滑翔伞只要求真人暗扣牌；蓝色7号牌触发时两名真人互换手牌。部分任务固定由向导负责，幽灵的秘密决定由侦察员代办。移除一张牌的任务中幽灵为六张暗牌、七张明牌，真人各十三张。\n结算:\n队伍先到飞机，剩余时间格数记为负分；同时到达获得0分。时间先到后，记录队伍额外用了几个任务才到达，作为正分。游戏可选择完整旅程，或从指定阶段开始单独游玩。",
			routeSummary: "{{n}} 格 · {{stacks}} 个任务堆；双线处停下",
			clockPositions: "左上角,上沿1,上沿2,右上角,右沿3,右下角,下沿6,左下角,左沿9",
			markerValue: "移动总点数 {{n}} 的标记",
			selectTask: "请选择任务",
			clockBoard: "大本钟顺时针牌位",
			clockCorner: "任意牌／粉8",
			missing: "移除的牌",
			guess: "共同选择",
			branchInfo: "继续暴风雨路线距终点7格；经迷雾捷径距终点5格，进入迷雾后停下，迷雾每人先发4张。",
			tallyRule: "每项累计 {{mult}} 格，合计扣除 {{n}} 格；结果至少为1格才算成功。",
			hideSwap: "更换暗扣牌",
			hidden: "暗扣",
			errAction: "当前不能执行这个动作。",
			stage: "第 {{n}} 阶段",
			round: "第 {{n}} 轮",
			trick: "第 {{n}}／{{total}} 墩",
			guide: "向导",
			scout: "侦察员",
			ghost: "幽灵",
			driver: "驾驶员",
			hand: "我的手牌",
			ghostHand: "幽灵的明牌",
			last: "最近一墩",
			current: "本墩",
			tokens: "通信令牌",
			task: "任务 {{n}}",
			individual: "个人任务",
			cumulative: "累计任务",
			random: "随机任务",
			difficulty: "难度 {{n}}",
			owner: "负责人：{{name}}",
			chooseCard: "选择一张牌",
			play: "出牌",
			cancel: "取消",
			communicate: "通信",
			high: "最高",
			only: "唯一",
			low: "最低",
			shown: "展示",
			count: "{{n}} 张",
			tricks: "{{n}} 墩",
			turn: "轮到{{name}}出牌",
			yourTurn: "请选择要出的牌",
			wait: "等待其他队员",
			ready: "可在出牌前通信",
			roundWon: "任务完成",
			roundLost: "任务失败",
			advance: "前进 {{n}} 格",
			stageScore: "阶段分数 {{n}}",
			timeLeft: "剩余时间 {{n}}",
			overtime: "额外任务 {{n}}",
			crewPosition: "队伍 {{n}}／{{total}}",
			resultTitle: "旅程记录",
			total: "总分",
			discardHighest: "扣除最高单项：{{n}}",
			lowerBetter: "分数越低越好",
			singleResult: "本次阶段成绩",
			scoreList: "各阶段成绩",
			ending0: "你们找到了世界尽头的宝藏。",
			ending1: "旅程圆满结束，宝藏已近在眼前。",
			ending2: "冒险留下了珍贵的回忆。",
			ending3: "你们仍有许多未解的线索。",
			ending4: "整理行囊，再次启程吧。",
			selectStage: "起始阶段",
			campaign: "游玩方式",
			campaignOn: "继续至第25阶段",
			campaignOff: "只玩所选阶段",
			hardGhost: "幽灵困难模式",
			hardGhostHelp: "幽灵赢墩后，只能从刚出牌的位置或左右最近位置领出。",
			details: "规则与任务详情",
			close: "关闭",
			removed: "本轮移除的牌",
			secrets: "我的秘密目标",
			prediction: "我的预测：{{n}}",
			target: "秘密目标",
			secretNumber: "秘密数值：{{n}}",
			secretColor: "秘密颜色",
			neighbor: "秘密选择的队员",
			failed: "本次尝试已失败",
			successes: "完成 {{n}}／3 项",
			attempt: "第 {{n}} 次尝试",
			subtask: "子任务 {{n}}",
			riverDeal: "第 {{n}} 次发牌",
			river: "河道 {{n}}／{{total}}",
			crocodile: "鳄鱼",
			destination: "终点",
			start: "起点",
			blocked: "阻断",
			points: "本墩总点数 {{n}}",
			raw: "当前累计 {{n}}",
			noLast: "尚未完成一墩",
			selected: "已提交",
			allRed: "全部拒绝，请重新表决。",
			stormFailed: "令牌落在红面，本次不能通信。",
			communicated: "已展示通信牌。",
			unresolved: "本阶段路线仍在核实，开发版暂不开放。",
			prompt: {
				branch: "选择岔路",
				route: "选择路线",
				driver: "指定雪橇驾驶员",
				vote: "是否愿意承担这个任务？",
				assign: "从愿意承担的人中指定负责人",
				prediction: "声明预测数值",
				neighbor: "秘密选择一位相邻队员",
				color: "选择颜色",
				number: "选择数值",
				targetPeople: "选择两名承担目标的队员",
				forbid: "声明自己不能吃到的颜色",
				show: "展示一张手牌",
				scooterPartner: "选择交换牌的队员",
				scooter: "秘密选择一张交换牌",
				bury: "选择暗扣的牌",
				leader: "决定本墩由谁领出",
				dogPermission: "是否批准本次通信？",
				pass: "秘密选择一张牌传给左侧队员",
				jeep: "秘密选择两张牌交到中间",
				flight: "是否沿本墩末张牌的数字飞行？",
				marker: "选择要移动的标记",
				tower: "选择放牌的塔楼",
				clock: "选择钟面起点",
				guess: "共同确认被移除的牌"
			},
			choice: {
				upper: "继续暴风雨路线",
				lower: "经迷雾捷径",
				number: "{{n}}",
				color: "颜色 {{n}}",
				person: "队员",
				pair: "两名队员",
				card: "选择这张牌",
				cards: "选择这两张牌",
				yes: "愿意",
				no: "不愿意",
				route: "路线",
				taskStack: "选择任务堆 {{n}}",
				discard: "弃置任务堆 {{n}} 的顶牌",
				continue: "查看结果",
				nextStage: "继续旅程",
				chicago: "挑战芝加哥",
				keepLeader: "由原定队员领出",
				takeLead: "由我领出",
				approve: "批准",
				deny: "拒绝",
				skip: "跳过",
				fly: "飞往 {{n}}",
				marker: "移动格子 {{n}} 的标记",
				tower: "塔楼 {{n}}",
				clock: "钟面位置 {{n}}"
			},
			colors: {
				blue: "蓝色",
				green: "绿色",
				pink: "粉色",
				yellow: "黄色",
				helicopter: "直升机"
			},
			terrain: {
				train: "火车",
				foot: "步行",
				glider: "滑翔伞",
				ski: "滑雪",
				scooter: "滑板车",
				bicycle: "自行车",
				helicopter: "直升机",
				storm: "暴风雨",
				donkey: "驴",
				jeep: "吉普车",
				machete: "砍刀",
				dog: "狗拉雪橇",
				cable: "缆车",
				ice: "冰面",
				cracked: "裂冰",
				fog: "迷雾：每人先发 {{n}} 张"
			},
			specialRules: "每墩首张牌沿蛇形填入九宫格；相邻格不能同类型。第二项改用每墩第二张牌，相邻格不能同数字。第三项用末张牌，每种类型最多两张。\n每墩可以按末张牌的数字飞往对应城市，也可以跳过。由1出发，依次访问其他七城各一次，再返回1；所有航线为直线，不能相交。\n每墩首张牌按山路顺序排列，共八张。箭头要求下一张数字提高、降低或相同。每条山路为一个子任务。\n每墩总点数命中九宫格时必须放标记。只有三枚标记，第四个新格需要移动旧标记。同一行或同一列的三枚标记即成功。\n每墩沿蛇形填入九宫格。第一项用首张牌，每行每列点数至少22；第二项用末张牌，最多一个数字出现两次，其余不能重复；第三项用第二张牌，同类型不能横、竖、斜相邻。\n一次尝试发两轮完整手牌。每墩按其中绿色牌的数量沿河前进。落在鳄鱼格时随机翻开本墩一张牌，绿色则失败。必须到达码头，可以提前结束。\n每墩可共同决定领出者。第一项要求每张6均为墩的第二张，五座只需三张6；第二项要求每张6均赢墩；第三项要求同一队员吃到全部6，五座只需三张。完成后可再挑战芝加哥：全部6留在末墩，三座剩余手牌必须是第四张6；最多三次，成功整个阶段得负3分。\n三个子任务依次为泰特美术馆、塔桥、大本钟。美术馆用每墩首张牌按指定类型填格；塔桥用第二张牌从两塔底部向上严格递增填满四层和五层；大本钟用首张牌选择起点后顺时针摆放，指定数字必须相符，粉8在任一角。各九墩。\n每墩首张牌依次排列：任意；提高至少3；粉色且提高；降低至少4；黄色且降低；相同；蓝色且提高；绿色且提高；黄色且降低。共九墩。",
			taskTexts: "任何一墩中，蓝色牌后不能紧接绿色牌。\n任何一墩中，不能连续出现三张偶数牌。\n负责人公开预测自己将赢几墩，允许0墩，最终必须相符。\n直升机2必须赢下一墩。\n每墩不能以8或9领出。\n每位吃到至少一张粉色牌的队员贡献1格，再扣除1格。\n其他队员从1至3中秘密抽取两个不同数字，向导必须恰好赢得其和的墩数。只有向导可以通信；向导持全部直升机时重新发牌。\n向导秘密选择左右相邻的一人，该人必须恰好吃到三张绿色牌，另一人绿色牌数不能为三。向导不能通信。\n其他队员从1至5中秘密抽取两个不同数字，向导必须恰好吃到其和的粉色牌；向导不知道目标，只有向导可以通信。\n同上，但数字从1至4中抽取。\n每墩含某个恰好出现两次的数字则贡献1格，再按人数扣除5、3、2格。\n每墩不含1或2则贡献1格，再按人数扣除5、2、0格。\n每墩必须由偶数颜色牌或直升机赢下。\n至少一位队员吃到的粉色牌点数合计恰好为10。\n每墩末张牌的数字必须为偶数。\n每墩按出牌顺序没有两张奇数牌紧邻则贡献1格，再按人数扣除8、4、2格。\n负责人必须恰好赢第1、3、5、7墩，不能赢其他墩。\n每墩末张牌不能为粉色。\n任何一墩不能同时含粉色和蓝色牌。\n任何一墩不能同时含粉色与蓝色或绿色牌。\n向导每次赢墩后，下一墩必须由负责人赢下；向导不能赢最后一墩。\n负责人必须只赢一墩，且这一墩包含黄色4。\n每墩总点数不超过8、13、18（三、四、五座）则贡献1格。\n每墩第二张牌比首张牌数字大则贡献1格，再按人数扣除9、6、4格。\n每墩必须同时含奇数和偶数。\n每墩末张牌的数字必须小于该墩最大数字。\n第1墩含1，第2墩含2，依此类推；第一处失误或第9墩后结束。每个正确墩贡献1格，再按人数扣除6、5、3格。\n每位吃到绿色牌多于黄色牌的队员贡献1格；允许没有黄色牌。\n每位队员秘密预测自己的赢墩数，允许0；每位正确者贡献1格。\n至少存在连续三墩，其最大数字严格递增，且各墩的最大数字只出现一次。\n每位队员秘密预测自己将吃到的粉色牌数，允许0；每位正确者贡献1格。\n负责人秘密预测自己将吃到1至8张黄色牌，最终必须相符；负责人不能通信。\n不能有任何一墩由粉色牌赢下。\n不能有任何一墩由蓝色或绿色牌赢下。\n向导赢墩数必须是左侧相邻队员的两倍，且两者均不能为0。\n负责人恰好赢三墩，且这些墩都不能由负责人领出。\n向导左右相邻队员不得讨论。左侧选择颜色，右侧选择数量，两人均须恰好吃到该数量的该颜色牌；允许0。\n向导左右相邻队员必须赢得相同且不为0的墩数；不得讨论。\n每墩不能含超过两张蓝色牌。\n每位队员都不能吃齐四种颜色。\n每位队员都必须吃到至少一张黄色牌。\n不能以绿色领出；最后一墩不能含绿色。\n每墩不能连续打出两张粉色牌。\n每墩首张与末张牌都不能为蓝色。\n任何两位队员吃到的粉色牌数量之差不能超过1。\n每墩首张与末张牌都不能为直升机。\n每墩第二张牌不能为直升机。\n发牌前秘密抽取一张颜色牌，负责人必须吃到该牌。\n每位队员吃到的绿色牌数与黄色牌数必须不同；允许其中一种为0。\n负责人必须吃到全部五张1，包括直升机1。\n负责人必须吃到绿色7、粉色2与黄色1。\n直升机2必须赢下一墩含粉色牌的墩。\n发牌前秘密抽取两张颜色牌，负责人必须吃到这两张牌。\n由向导起按座次公开预测各自的赢墩数，全部预测必须正确。\n由向导起按座次公开预测左侧相邻队员的赢墩数，全部预测必须正确。\n至少一墩由颜色牌领出，且总点数不超过5、8、12（三、四、五座）。\n每墩总点数为16至17、20至21、24至26（三、四、五座）则贡献1格。\n每墩含蓝色牌则贡献1格，再按人数扣除4、3、3格。\n最后一墩的末张牌必须是绿色4。\n不能以粉色或黄色领出。\n至少一墩的绿色牌点数合计恰好为6。\n至少一墩的黄色牌点数合计恰好为13。\n每墩最大数字与最小数字的差至少为4。\n不能以黄色领出。\n每墩最多含两种颜色，直升机不计入颜色。\n负责人吃到的四种颜色牌数量必须相等，且均大于0。\n每墩必须含1或2；三座打完十墩后结束。\n负责人必须分别用四种颜色各赢至少一墩。\n选择两位队员，发牌前各秘密抽一张颜色牌；两人必须分别吃到自己的目标牌。\n每位赢墩数为奇数的队员贡献1格；0为偶数。\n向导左侧相邻队员独自选择一种颜色，左右两位相邻队员都不能吃到该颜色牌。\n除负责人外，每位队员必须恰好赢一墩，负责人赢其余所有墩。\n任何两位队员吃到的5的数量之差不能超过1。\n由向导起依次公开声明自己不能吃到的颜色，不能重复；第五位队员不受限制。\n每位队员必须吃到四种颜色各至少一张。\n每墩必须由7、8、9或直升机赢下。\n负责人吃到的四种颜色牌数量必须两两不同，允许一种为0。\n每位队员吃到的粉色牌数与蓝色牌数必须相等，允许两者均为0。\n至少存在连续五墩均以3、6或9领出。\n负责人必须吃到四种颜色各至少一张。\n最后一墩不能含1、2、3或4，包括直升机。\n不能由同一人连续赢两墩。\n每墩数字排序后为互不重复的连续整数则贡献1格，再按人数扣除4、2、1格。\n每墩按出牌顺序数字严格递增则贡献1格；三、四座再扣除7、2格，五座将累计格数翻倍。\n第一墩赢家任意，随后每墩由其左侧相邻队员依次赢下。首次失误停止；正确墩各贡献1格，再按人数扣除6、3、0格。\n每墩由1至5赢下则贡献1格，包括直升机，再按人数扣除5、2、0格。\n每墩由末张牌赢下则贡献1格，再按人数扣除6、3、2格。\n每墩由3、6或9赢下则贡献1格，包括直升机3，再按人数扣除6、4、2格。\n每墩不含3、6或9则贡献1格，包括直升机3，再按人数扣除4、1、0格。\n每墩由偶数赢下则贡献1格，包括直升机，再按人数扣除7、5、3格。\n向导左右相邻队员共同选择一种颜色，两人都不能吃到该颜色牌。\n向导左侧相邻队员展示一张手牌，该队员与向导的赢墩数之和必须等于该牌数字。牌在打出前保持展示。\n每位队员赢下的墩必须形成一个连续区段；允许0墩。\n负责人必须吃到蓝色8和黄色5。\n共同选择一种颜色，最后一墩必须含该颜色至少三张。\n秘密随机移除一张牌，其余39张尽量均发。本轮发牌者领出，打完后共同指出移除的是哪张牌；四、五座最后一墩有一人不出牌。\n负责人只可赢末张数字严格大于本墩最小数字的墩。每个未失误的墩贡献1格，首次由负责人赢下不合条件的墩时停止，再按人数扣除3、2、1格。\n负责人只可赢恰好有两张偶数的墩。每个未失误的墩贡献1格，首次由负责人赢下不合条件的墩时停止，再按人数扣除2、2、0格。\n负责人只可赢恰好有两张数字小于5的墩。每个未失误的墩贡献1格，首次失误停止，再按人数扣除3、1、0格。\n负责人只可赢最多含两种类型的墩。每个未失误的墩贡献1格，首次失误停止，再按人数扣除4、2、0格。\n负责人只可赢含重复数字的墩。每个未失误的墩贡献1格，首次失误停止，再按人数扣除2、2、0格。\n其他队员从1至4中秘密抽取两个不同数字，向导必须恰好赢得其和的墩数。只有向导可以通信。\n每墩不能由奇数颜色牌赢下，直升机不受限制。\n每墩不能连续打出两张奇数颜色牌，直升机不受限制。"
		},
		en: {
			highestDeduction: "Highest score deduction",
			fullRoute: "Full route",
			journeyEnded: "Journey complete",
			stageTotal: "Stage total",
			viewFinal: "View final board",
			showResults: "Back to results",
			confirmLeave: "Confirm return",
			confirmAgain: "Confirm new game",
			name: "The Crew: Journey to the Ends of the Earth",
			desc: "A cooperative trick-taking journey through 25 stages, with limited communication and a race against time.",
			rules: "Goal:\nWork together to reach the airplane in each stage. Lower scores are better. In a complete campaign, stage 1 is practice; discard the highest individual stage score before adding the others.\nSetup:\nThere are four color suits, numbered 1–9, and helicopters 1–4. Helicopters are a fifth suit and trump all colors. Split the 104 tasks into two stacks. Shuffle tasks 1–6 and place three on each stack. Each round, select a task by its back before dealing. Whoever holds helicopter 4 is the guide and leads the first trick.\nPlay:\nIn seat order, play one card each. You must follow the suit led if possible. Otherwise play any card. The highest helicopter wins; without helicopters, the highest card of the led color wins. The winner leads next. Normally play 13, 10 or 8 tricks with three, four or five seats; three seats leave one card unplayed. Only the most recent trick may be inspected.\nDo not reveal or hint at your hand. After task preparation, communication is allowed only between tricks. The team shares one token per human player. A player may use several. Show a non-helicopter card and declare it the highest, only or lowest of its color. This declaration never changes. The card stays in your hand until played; a token is used for the entire round.\nFor an individual task, everyone votes secretly. Reveal votes together, then the guide assigns one willing player. All red votes require another vote. Secret targets and predictions are visible only to the appropriate players. Public predictions are declared in order starting with the guide.\nOrdinary stages:\nOnce per stack per stage, you may put its top task underneath. Random tasks cannot be discarded. A standard task advances the crew by its difficulty. Cumulative tasks score their printed conditions, then apply the player-count deduction; zero or less is failure. You cannot voluntarily move fewer spaces. Stop before a disruption; cross it on a later round. Time advances one space per task, or two on a donkey. Play all tricks except an established failure or an explicit task endpoint. Machetes require all tricks.\n· Train has no effect.\n· On foot, choose the lower estimated difficulty; cumulative and random backs count as 3.\n· Paragliding hides one card per human player; it can be exchanged between tricks and must be played in the final trick. No communication.\n· Skiing passes all hands and communicated cards left after blue 7 is played.\n· The initial blue 1 holder secretly swaps a card with a chosen player before a scooter round; helicopter 4 cannot be exchanged.\n· A player holding a bicycle card cannot communicate on bicycle spaces.\n· After a helicopter trick on helicopter terrain, everyone secretly passes one card left. Communicated cards cannot be passed unless all remaining cards are communicated.\n· Fog deals the shown number to each player, with an extra card for the guide at three seats; draw one after each trick until the deck is empty.\n· Storm communication flips a token first: green allows it, red consumes it without showing a card.\n· Jeep terrain secretly pools two uncommunicated cards per player after trick three, shuffles and returns two each. Communication during the first three tricks must leave enough uncommunicated cards to guarantee this exchange.\n· A trick containing a machete fails the task if its total is 15 or 16 at three seats, 20 or 21 at four, or 25 or 26 at five. Still play all tricks.\n· A dog-sled driver selects and discards tasks, approves communication and may take the lead before any trick.\n· Failing on cable-car terrain returns the crew to the stage’s first cable car.\n· Failing on ice moves the crew back one space.\n· Succeeding on cracked ice moves the crew backwards by the earned distance, never before the start; failing leaves the crew in place.\nSpecial stages:\nPompeii, Everest, Machu Picchu, Route 66 and London have three tasks, each with two attempts. Complete zero, one, two or three for 6, 4, 2 or 0 points; all first attempts score −2. Africa, Macao, Amazon and the Catacombs each have one task and three attempts: first, second or third success scores −2, 0 or 2; failure scores 4. The stage display explains each objective.\nExcept Amazon and Route 66, three human players publicly remove seven random cards while keeping helicopter 4. Five players recycle the first fifteen played cards after trick three: retain cards placed on the task board, fill up to three retained cards from the other played cards, shuffle the rest and deal two per player. Two players do not remove seven cards.\nTwo players:\nTwo humans and Ghost form three seats. Use three-seat task values but two communication tokens. Ghost has seven covered cards with seven face-up cards above them. Play face-up cards only; uncover the card beneath after the trick. The human other than the guide is the scout and controls Ghost without discussion. Optional hard Ghost restricts its lead after winning a trick. Only humans draw in fog or hide a paragliding card; blue 7 swaps the human hands. Some individual tasks are fixed to the guide. The scout makes Ghost’s secret decisions. For the missing-card task, Ghost receives six covered and seven visible cards; humans receive thirteen each.\nScoring:\nIf the crew arrives first, score the time marker’s remaining distance as negative. Simultaneous arrival is 0. If time arrives first, count the additional tasks until the crew arrives, as positive. Select a full journey or a single starting stage in options.",
			routeSummary: "{{n}} spaces · {{stacks}} task stacks; stop at double lines",
			clockPositions: "Top-left,Top 1,Top 2,Top-right,Right 3,Bottom-right,Bottom 6,Bottom-left,Left 9",
			markerValue: "Move the marker on total {{n}}",
			selectTask: "Choose a task",
			clockBoard: "Big Ben clockwise card positions",
			clockCorner: "Any card / pink 8",
			missing: "Missing card",
			guess: "Crew’s guess",
			branchInfo: "Storm route: 7 spaces remain. Fog shortcut: 5 spaces remain, with a stop on the fog space; deal 4 cards per player there.",
			tallyRule: "Count {{mult}} spaces per success, then subtract {{n}}. The result must be at least 1 space.",
			hideSwap: "Change hidden card",
			hidden: "Hidden",
			errAction: "That action is not available now.",
			stage: "Stage {{n}}",
			round: "Round {{n}}",
			trick: "Trick {{n}} / {{total}}",
			guide: "Guide",
			scout: "Scout",
			ghost: "Ghost",
			driver: "Driver",
			hand: "My hand",
			ghostHand: "Ghost’s face-up cards",
			last: "Most recent trick",
			current: "Current trick",
			tokens: "Communication tokens",
			task: "Task {{n}}",
			individual: "Individual task",
			cumulative: "Cumulative task",
			random: "Random task",
			difficulty: "Difficulty {{n}}",
			owner: "Assigned to {{name}}",
			chooseCard: "Choose a card",
			play: "Play card",
			cancel: "Cancel",
			communicate: "Communicate",
			high: "Highest",
			only: "Only",
			low: "Lowest",
			shown: "Shown",
			count: "{{n}} cards",
			tricks: "{{n}} tricks",
			turn: "{{name}} to play",
			yourTurn: "Choose a card to play",
			wait: "Waiting for the crew",
			ready: "Communication is available before the trick",
			roundWon: "Task completed",
			roundLost: "Task failed",
			advance: "Advance {{n}} spaces",
			stageScore: "Stage score {{n}}",
			timeLeft: "Time remaining {{n}}",
			overtime: "Extra tasks {{n}}",
			crewPosition: "Crew {{n}} / {{total}}",
			resultTitle: "Travel journal",
			total: "Total score",
			discardHighest: "Highest score discarded: {{n}}",
			lowerBetter: "Lower is better",
			singleResult: "Stage result",
			scoreList: "Stage scores",
			ending0: "You found the treasure at the ends of the Earth.",
			ending1: "A successful journey brings the treasure within reach.",
			ending2: "Your adventure leaves treasured memories.",
			ending3: "Many clues remain unresolved.",
			ending4: "Pack your bags and set out again.",
			selectStage: "Starting stage",
			campaign: "Journey",
			campaignOn: "Continue through stage 25",
			campaignOff: "Play only the selected stage",
			hardGhost: "Hard Ghost",
			hardGhostHelp: "After Ghost wins, lead from the same position or the nearest available position on either side.",
			details: "Rules and task details",
			close: "Close",
			removed: "Cards removed this round",
			secrets: "My secret objectives",
			prediction: "My prediction: {{n}}",
			target: "Secret target",
			secretNumber: "Secret number: {{n}}",
			secretColor: "Secret color",
			neighbor: "Secretly selected crew member",
			failed: "This attempt has failed",
			successes: "Completed {{n}} / 3",
			attempt: "Attempt {{n}}",
			subtask: "Task {{n}}",
			riverDeal: "Deal {{n}}",
			river: "River {{n}} / {{total}}",
			crocodile: "Crocodile",
			destination: "Destination",
			start: "Start",
			blocked: "Disruption",
			points: "Trick total {{n}}",
			raw: "Current tally {{n}}",
			noLast: "No completed trick yet",
			selected: "Submitted",
			allRed: "Everyone declined. Please vote again.",
			stormFailed: "The token landed red. Communication failed.",
			communicated: "Communication card shown.",
			unresolved: "This route is still being verified and is not available in this development build.",
			prompt: {
				branch: "Choose the fork",
				route: "Choose a route",
				driver: "Choose the dog-sled driver",
				vote: "Are you willing to take this task?",
				assign: "Assign one willing crew member",
				prediction: "Declare a prediction",
				neighbor: "Secretly choose one neighboring crew member",
				color: "Choose a color",
				number: "Choose a number",
				targetPeople: "Choose two crew members for the targets",
				forbid: "Declare the color you cannot capture",
				show: "Show a card from your hand",
				scooterPartner: "Choose a crew member to swap with",
				scooter: "Secretly choose a card to swap",
				bury: "Choose a card to hide",
				leader: "Choose who leads this trick",
				dogPermission: "Approve this communication?",
				pass: "Secretly pass one card left",
				jeep: "Secretly choose two cards to pool",
				flight: "Fly using the last card’s number?",
				marker: "Choose a marker to move",
				tower: "Choose a tower",
				clock: "Choose the clock’s starting position",
				guess: "Identify the missing card together"
			},
			choice: {
				upper: "Continue through the storm",
				lower: "Take the fog shortcut",
				number: "{{n}}",
				color: "Color {{n}}",
				person: "Crew member",
				pair: "Two crew members",
				card: "Choose this card",
				cards: "Choose these cards",
				yes: "Willing",
				no: "Decline",
				route: "Route",
				taskStack: "Choose task stack {{n}}",
				discard: "Discard top of stack {{n}}",
				continue: "See result",
				nextStage: "Continue the journey",
				chicago: "Chicago challenge",
				keepLeader: "Keep the scheduled leader",
				takeLead: "I will lead",
				approve: "Approve",
				deny: "Decline",
				skip: "Skip",
				fly: "Fly to {{n}}",
				marker: "Move marker from space {{n}}",
				tower: "Tower {{n}}",
				clock: "Clock position {{n}}"
			},
			colors: {
				blue: "Blue",
				green: "Green",
				pink: "Pink",
				yellow: "Yellow",
				helicopter: "Helicopter"
			},
			terrain: {
				train: "Train",
				foot: "On foot",
				glider: "Paraglider",
				ski: "Skis",
				scooter: "Scooter",
				bicycle: "Bicycle",
				helicopter: "Helicopter",
				storm: "Storm",
				donkey: "Donkey",
				jeep: "Jeep",
				machete: "Machetes",
				dog: "Dog sled",
				cable: "Cable car",
				ice: "Ice",
				cracked: "Cracked ice",
				fog: "Fog: deal {{n}} cards each"
			},
			specialRules: "Place the first card of each trick along the snake path; orthogonal neighbors cannot share a type. Task two uses the second card and forbids equal neighboring numbers. Task three uses the last card, with at most two of each type.\nAfter each trick, optionally fly to the last card’s number, or skip. Start at 1, visit every other city once, then return to 1. Routes are straight lines and cannot cross.\nLay the first card of each trick along the mountain path, eight cards in all. Each next number must rise, fall or stay equal as marked. Each path is a separate task.\nIf a trick total matches a space, mark it. There are only three markers; a fourth new space requires moving an old marker. A full row or column succeeds.\nFill the snake grid. Task one uses first cards, with every row and column totaling at least 22. Task two uses last cards; at most one number may appear twice and all others once. Task three uses second cards; matching types cannot touch, even diagonally.\nEach attempt deals two complete hands. Move along the river by the number of green cards in each trick. On a crocodile space, reveal one random card from that trick; green fails. Reach the dock; you may stop early.\nThe crew may select each trick’s leader. Task one places every 6 second in its trick; five seats need three 6s. Task two wins each trick with a 6. Task three gives all 6s to one winner; five seats need three 6s. Afterwards, try Chicago up to three times: all 6s in the final trick, with the fourth 6 left in hand at three seats. Success changes the whole stage to −3.\nPlay Tate Gallery, Tower Bridge and Big Ben. Tate uses first cards along the marked color path. Tower Bridge uses second cards to build strictly increasing towers of four and five cards. Big Ben uses first cards clockwise from a chosen start; fixed numbers must match and pink 8 must occupy a corner. Each task lasts nine tricks.\nUse each trick’s first card: any; rise by at least 3; pink and higher; fall by at least 4; yellow and lower; equal; blue and higher; green and higher; yellow and lower. Nine tricks.",
			taskTexts: "No green card may immediately follow a blue card in any trick.\nNo trick may contain three even-numbered cards played consecutively.\nThe task owner publicly predicts how many tricks they will win, including zero. The prediction must be exact.\nHelicopter 2 must win a trick.\nNo trick may be led with an 8 or a 9.\nEach crew member who captures at least one pink card contributes one space.\nThe other crew members secretly draw two different numbers from 1 to 3. The guide must win exactly their sum in tricks. Only the guide may communicate. Deal again if the guide holds all four helicopters.\nThe guide secretly chooses one neighboring crew member. That neighbor must capture exactly three green cards; the other neighbor must capture a different number. The guide may not communicate.\nThe other crew members secretly draw two different numbers from 1 to 5. Without knowing their sum, the guide must capture exactly that many pink cards. Only the guide may communicate.\nThe other crew members secretly draw two different numbers from 1 to 4. Without knowing their sum, the guide must capture exactly that many pink cards. Only the guide may communicate.\nEach trick containing a number that appears exactly twice contributes one space.\nEach trick containing neither a 1 nor a 2 contributes one space.\nEvery trick must be won by an even-numbered colored card or a helicopter.\nAt least one crew member must capture pink cards with a total value of exactly 10.\nThe last card of every trick must have an even number.\nEach trick without two odd-numbered cards played immediately after one another contributes one space.\nThe task owner must win exactly tricks 1, 3, 5 and 7, and no others.\nThe last card of a trick may never be pink.\nNo trick may contain both pink and blue cards.\nNo trick may contain pink cards together with either blue or green cards.\nWhenever the guide wins a trick, the task owner must win the next trick. The guide may not win the final trick.\nThe task owner must win exactly one trick, and that trick must contain yellow 4.\nEach trick with a total value of at most 8, 13 or 18 at three, four or five seats contributes one space.\nEach trick whose second card has a higher number than its first contributes one space.\nEvery trick must contain both odd and even numbers.\nThe last card of every trick must have a number strictly below the highest number in that trick.\nTrick 1 must contain a 1, trick 2 a 2, and so on. Stop at the first mistake or after trick 9. Each correct trick contributes one space.\nEach crew member who captures more green cards than yellow cards contributes one space. Capturing no yellow cards is allowed.\nEach crew member secretly predicts their own number of tricks, including zero. Each correct prediction contributes one space.\nThere must be three consecutive tricks whose highest numbers increase strictly. Each of those highest numbers must appear only once in its trick.\nEach crew member secretly predicts how many pink cards they will capture, including zero. Each correct prediction contributes one space.\nThe task owner secretly predicts how many yellow cards they will capture, from 1 to 8. The prediction must be exact, and the owner may not communicate.\nNo trick may be won with a pink card.\nNo trick may be won with a blue or green card.\nThe guide must win twice as many tricks as the neighbor on their left. Neither may win zero tricks.\nThe task owner must win exactly three tricks and must not lead any of those tricks.\nWithout discussion, the guide’s left neighbor chooses a color and the right neighbor chooses a number, including zero. Both neighbors must capture exactly that many cards of that color.\nThe guide’s two neighbors must win the same positive number of tricks. They may not discuss this.\nNo trick may contain more than two blue cards.\nNo crew member may capture all four colors.\nEvery crew member must capture at least one yellow card.\nNo trick may be led with green, and the final trick must contain no green cards.\nNo two pink cards may be played consecutively in a trick.\nNeither the first nor the last card of any trick may be blue.\nThe numbers of pink cards captured by any two crew members must differ by at most one.\nNeither the first nor the last card of any trick may be a helicopter.\nThe second card of a trick may never be a helicopter.\nBefore dealing, secretly draw one colored target card. The task owner must capture that card.\nEach crew member must capture different numbers of green and yellow cards. One count may be zero.\nThe task owner must capture all five cards numbered 1, including helicopter 1.\nThe task owner must capture green 7, pink 2 and yellow 1.\nHelicopter 2 must win a trick containing at least one pink card.\nBefore dealing, secretly draw two colored target cards. The task owner must capture both cards.\nStarting with the guide, each crew member publicly predicts their own number of tricks in seating order. Every prediction must be exact.\nStarting with the guide, each crew member publicly predicts their left neighbor’s number of tricks in seating order. Every prediction must be exact.\nAt least one trick must be led with a colored card and have a total value of at most 5, 8 or 12 at three, four or five seats.\nEach trick with a total value of 16–17, 20–21 or 24–26 at three, four or five seats contributes one space.\nEach trick containing a blue card contributes one space.\nThe last card of the final trick must be green 4.\nNo trick may be led with pink or yellow.\nAt least one trick must contain green cards with a total value of exactly 6.\nAt least one trick must contain yellow cards with a total value of exactly 13.\nIn every trick, the highest and lowest numbers must differ by at least four.\nNo trick may be led with yellow.\nEvery trick may contain at most two colors. Helicopters do not count as colors.\nThe task owner must capture the same positive number of cards in each of the four colors.\nEvery trick must contain a 1 or a 2. At three seats, stop after ten tricks.\nThe task owner must win at least one trick with each of the four colored card types.\nBefore dealing, choose two crew members and secretly draw one colored target card for each. Each must capture their own target.\nEach crew member who wins an odd number of tricks contributes one space. Zero is even.\nThe guide’s left neighbor chooses a color without discussion. Neither of the guide’s neighbors may capture that color.\nEvery crew member except the task owner must win exactly one trick. The owner must win all remaining tricks.\nThe numbers of cards numbered 5 captured by any two crew members must differ by at most one.\nStarting with the guide, each crew member declares a different color they may not capture. A fifth crew member has no restriction.\nEvery crew member must capture at least one card in each of the four colors.\nEvery trick must be won with a 7, 8, 9 or helicopter.\nThe task owner must capture a different number of cards in each of the four colors. One count may be zero.\nEach crew member must capture equal numbers of pink and blue cards. Both counts may be zero.\nThere must be five consecutive tricks led with a 3, 6 or 9.\nThe task owner must capture at least one card in each of the four colors.\nThe final trick may not contain a 1, 2, 3 or 4, including helicopters.\nThe same crew member may not win two consecutive tricks.\nEach trick whose numbers form a sequence of different consecutive integers contributes one space.\nEach trick whose numbers increase strictly in play order contributes one space. At five seats, each contributes two spaces.\nAny crew member may win the first trick. Each subsequent trick must be won by the previous winner’s left neighbor. Stop at the first mistake; each correct trick contributes one space.\nEach trick won by a number from 1 to 5 contributes one space, including helicopters.\nEach trick won by its last card contributes one space.\nEach trick won by a 3, 6 or 9 contributes one space, including helicopter 3.\nEach trick containing no 3, 6 or 9 contributes one space, including helicopter 3.\nEach trick won by an even number contributes one space, including helicopters.\nThe guide’s two neighbors jointly choose a color. Neither may capture that color.\nThe guide’s left neighbor reveals one card from their hand. That neighbor and the guide must win a combined number of tricks equal to its number. Keep the card visible until played.\nEach crew member’s wins must form one uninterrupted sequence. Winning zero tricks is allowed.\nThe task owner must capture blue 8 and yellow 5.\nChoose a color together. The final trick must contain at least three cards of that color.\nSecretly remove one random card and deal the remaining 39 as evenly as possible. The dealer leads. After play ends, jointly identify the missing card. At four or five seats, one player has no card in the final trick.\nThe task owner may only win tricks whose last number is strictly above the lowest number in the trick. Each trick without a mistake contributes one space. Stop at the owner’s first mistake.\nThe task owner may only win tricks containing exactly two even numbers. Each trick without a mistake contributes one space. Stop at the owner’s first mistake.\nThe task owner may only win tricks containing exactly two numbers below 5. Each trick without a mistake contributes one space. Stop at the owner’s first mistake.\nThe task owner may only win tricks containing at most two card types. Each trick without a mistake contributes one space. Stop at the owner’s first mistake.\nThe task owner may only win tricks containing a repeated number. Each trick without a mistake contributes one space. Stop at the owner’s first mistake.\nThe other crew members secretly draw two different numbers from 1 to 4. Without knowing their sum, the guide must win exactly that many tricks. Only the guide may communicate.\nNo trick may be won by an odd-numbered colored card. Helicopters are allowed.\nNo two odd-numbered colored cards may be played consecutively in a trick. Helicopters are exempt."
		}
	}
};
//#endregion
export { gt as default };
