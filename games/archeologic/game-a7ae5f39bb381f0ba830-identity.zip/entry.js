import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useId as r, useRef as i, useState as a } from "react";
import { ConfirmButton as o } from "@bgparty/sdk/confirm-button";
import { IconClose as s, IconRotate as c } from "@bgparty/sdk/icons";
import { useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { useWakeLock as d } from "@bgparty/sdk/use-wake-lock";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { seatName as p } from "@bgparty/sdk/ui/player-strip";
import { Fragment as m, jsx as h, jsxs as g } from "react/jsx-runtime";
import { OptionRadio as _, OptionSection as v } from "@bgparty/sdk/ui/game-options";
//#region src/games/archeologic/puzzles.ts
var y = [
	{
		card: "3537",
		rating: 6.05,
		traps: [
			{
				cell: 11,
				symbol: 1
			},
			{
				cell: 4,
				symbol: 1
			},
			{
				cell: 2,
				symbol: 1
			},
			{
				cell: 16,
				symbol: 2
			},
			{
				cell: 18,
				symbol: 2
			}
		],
		solution: [
			{
				x: 0,
				y: 4,
				rotation: 0
			},
			{
				x: 0,
				y: 0,
				rotation: 1
			},
			{
				x: 1,
				y: 2,
				rotation: 2
			},
			{
				x: 3,
				y: 1,
				rotation: 3
			},
			{
				x: 3,
				y: 3,
				rotation: 0
			},
			{
				x: 2,
				y: 0,
				rotation: 0
			}
		],
		experts: [
			{
				rating: 6.46,
				clues: [
					{
						type: 19,
						a: 0,
						b: 1,
						rotation: -1
					},
					{
						type: 11,
						a: 1,
						b: 2,
						rotation: -1
					},
					{
						type: 10,
						a: 0,
						b: 3,
						rotation: -1
					},
					{
						type: 1,
						a: 2,
						b: -1,
						rotation: 2
					}
				]
			},
			{
				rating: 6.75,
				clues: [
					{
						type: 15,
						a: 0,
						b: 4,
						rotation: -1
					},
					{
						type: 1,
						a: 2,
						b: -1,
						rotation: 2
					},
					{
						type: 19,
						a: 0,
						b: 5,
						rotation: -1
					},
					{
						type: 3,
						a: 2,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 6.95,
				clues: [
					{
						type: 3,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 0,
						b: 5,
						rotation: -1
					},
					{
						type: 11,
						a: 1,
						b: 2,
						rotation: -1
					},
					{
						type: 8,
						a: 4,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7,
				clues: [
					{
						type: 22,
						a: 6,
						b: -1,
						rotation: -1
					},
					{
						type: 4,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 3,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 1,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 7.2,
				clues: [
					{
						type: 22,
						a: 15,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 3,
						b: -1,
						rotation: 3
					},
					{
						type: 2,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 1,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 7.3,
				clues: [
					{
						type: 10,
						a: 1,
						b: 2,
						rotation: -1
					},
					{
						type: 3,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 1,
						b: 2,
						rotation: -1
					},
					{
						type: 4,
						a: 4,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.36,
				clues: [
					{
						type: 11,
						a: 1,
						b: 2,
						rotation: -1
					},
					{
						type: 18,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 8,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 3,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 7.56,
				clues: [
					{
						type: 6,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 1,
						b: 2,
						rotation: -1
					},
					{
						type: 10,
						a: 1,
						b: 3,
						rotation: -1
					},
					{
						type: 19,
						a: 0,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 7.6,
				clues: [
					{
						type: 8,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 9,
						a: 4,
						b: 2,
						rotation: -1
					},
					{
						type: 11,
						a: 1,
						b: 2,
						rotation: -1
					},
					{
						type: 21,
						a: 2,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.54,
				clues: [
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 1
					},
					{
						type: 8,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 17,
						a: 2,
						b: 3,
						rotation: -1
					},
					{
						type: 14,
						a: 5,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 9.58,
				clues: [
					{
						type: 20,
						a: 4,
						b: 0,
						rotation: -1
					},
					{
						type: 6,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 14,
						a: 0,
						b: 5,
						rotation: -1
					},
					{
						type: 9,
						a: 4,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 9.94,
				clues: [
					{
						type: 2,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 15,
						a: 4,
						b: 2,
						rotation: -1
					},
					{
						type: 22,
						a: 15,
						b: -1,
						rotation: -1
					},
					{
						type: 4,
						a: 4,
						b: -1,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "3573",
		rating: 6.76,
		traps: [
			{
				cell: 9,
				symbol: 2
			},
			{
				cell: 4,
				symbol: 1
			},
			{
				cell: 22,
				symbol: 1
			},
			{
				cell: 14,
				symbol: 1
			},
			{
				cell: 18,
				symbol: 2
			}
		],
		solution: [
			{
				x: 1,
				y: 0,
				rotation: 3
			},
			{
				x: 2,
				y: 0,
				rotation: 1
			},
			{
				x: 3,
				y: 1,
				rotation: 0
			},
			{
				x: 2,
				y: 2,
				rotation: 1
			},
			{
				x: 3,
				y: 3,
				rotation: 3
			},
			{
				x: 0,
				y: 2,
				rotation: 1
			}
		],
		experts: [
			{
				rating: 6.11,
				clues: [
					{
						type: 22,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 16,
						a: 2,
						b: 0,
						rotation: -1
					},
					{
						type: 5,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 21,
						a: 5,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 7,
				clues: [
					{
						type: 13,
						a: 0,
						b: 4,
						rotation: -1
					},
					{
						type: 21,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 2,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 1
					}
				]
			},
			{
				rating: 7.18,
				clues: [
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 1
					},
					{
						type: 22,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 15,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 8,
						a: 4,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.33,
				clues: [
					{
						type: 21,
						a: 4,
						b: 2,
						rotation: -1
					},
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 1
					},
					{
						type: 9,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 19,
						a: 2,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.41,
				clues: [
					{
						type: 5,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 16,
						a: 1,
						b: 0,
						rotation: -1
					},
					{
						type: 1,
						a: 3,
						b: -1,
						rotation: 1
					},
					{
						type: 22,
						a: 20,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.61,
				clues: [
					{
						type: 21,
						a: 4,
						b: 0,
						rotation: -1
					},
					{
						type: 16,
						a: 4,
						b: 5,
						rotation: -1
					},
					{
						type: 8,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 3,
						b: -1,
						rotation: 1
					}
				]
			},
			{
				rating: 8.21,
				clues: [
					{
						type: 17,
						a: 3,
						b: 4,
						rotation: -1
					},
					{
						type: 22,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 0,
						b: 4,
						rotation: -1
					},
					{
						type: 4,
						a: 1,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.32,
				clues: [
					{
						type: 8,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 4,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 15,
						a: 0,
						b: 4,
						rotation: -1
					},
					{
						type: 1,
						a: 2,
						b: -1,
						rotation: 0
					}
				]
			},
			{
				rating: 8.53,
				clues: [
					{
						type: 14,
						a: 3,
						b: 4,
						rotation: -1
					},
					{
						type: 22,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 2,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 21,
						a: 4,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 8.8,
				clues: [
					{
						type: 21,
						a: 4,
						b: 1,
						rotation: -1
					},
					{
						type: 12,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 2,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 9,
						a: 3,
						b: 4,
						rotation: -1
					}
				]
			},
			{
				rating: 8.82,
				clues: [
					{
						type: 10,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 19,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 14,
						a: 4,
						b: 2,
						rotation: -1
					},
					{
						type: 22,
						a: 20,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.46,
				clues: [
					{
						type: 22,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 6,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 2,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "3575",
		rating: 6.88,
		traps: [
			{
				cell: 24,
				symbol: 1
			},
			{
				cell: 0,
				symbol: 1
			},
			{
				cell: 10,
				symbol: 1
			},
			{
				cell: 2,
				symbol: 1
			},
			{
				cell: 8,
				symbol: 2
			}
		],
		solution: [
			{
				x: 2,
				y: 1,
				rotation: 1
			},
			{
				x: 0,
				y: 2,
				rotation: 0
			},
			{
				x: 3,
				y: 3,
				rotation: 0
			},
			{
				x: 2,
				y: 0,
				rotation: 2
			},
			{
				x: 3,
				y: 1,
				rotation: 3
			},
			{
				x: 0,
				y: 0,
				rotation: 3
			}
		],
		experts: [
			{
				rating: 5.99,
				clues: [
					{
						type: 11,
						a: 0,
						b: 1,
						rotation: -1
					},
					{
						type: 10,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 1,
						a: 0,
						b: -1,
						rotation: 1
					},
					{
						type: 21,
						a: 2,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 6.5,
				clues: [
					{
						type: 21,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 10,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 18,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 11,
						a: 0,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 6.59,
				clues: [
					{
						type: 11,
						a: 0,
						b: 1,
						rotation: -1
					},
					{
						type: 3,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 5,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 0,
						b: -1,
						rotation: 1
					}
				]
			},
			{
				rating: 6.76,
				clues: [
					{
						type: 1,
						a: 0,
						b: -1,
						rotation: 1
					},
					{
						type: 8,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 2,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 0,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 6.93,
				clues: [
					{
						type: 11,
						a: 0,
						b: 1,
						rotation: -1
					},
					{
						type: 19,
						a: 5,
						b: 3,
						rotation: -1
					},
					{
						type: 5,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 22,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.32,
				clues: [
					{
						type: 2,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 0,
						b: 1,
						rotation: -1
					},
					{
						type: 22,
						a: 16,
						b: -1,
						rotation: -1
					},
					{
						type: 21,
						a: 2,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 8.45,
				clues: [
					{
						type: 10,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 11,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 8,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 3,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 9.09,
				clues: [
					{
						type: 2,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 13,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 21,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 16,
						a: 0,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.36,
				clues: [
					{
						type: 16,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 5,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 1,
						a: 0,
						b: -1,
						rotation: 1
					}
				]
			},
			{
				rating: 9.94,
				clues: [
					{
						type: 10,
						a: 2,
						b: 1,
						rotation: -1
					},
					{
						type: 13,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 16,
						a: 2,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 10.6,
				clues: [
					{
						type: 21,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 12,
						a: 0,
						b: 4,
						rotation: -1
					},
					{
						type: 2,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 0,
						b: -1,
						rotation: 1
					}
				]
			},
			{
				rating: 11.4,
				clues: [
					{
						type: 8,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 14,
						a: 3,
						b: 4,
						rotation: -1
					},
					{
						type: 2,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 17,
						a: 5,
						b: 2,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "3577",
		rating: 7.65,
		traps: [
			{
				cell: 7,
				symbol: 1
			},
			{
				cell: 13,
				symbol: 1
			},
			{
				cell: 20,
				symbol: 1
			},
			{
				cell: 18,
				symbol: 2
			},
			{
				cell: 16,
				symbol: 2
			}
		],
		solution: [
			{
				x: 2,
				y: 4,
				rotation: 2
			},
			{
				x: 2,
				y: 0,
				rotation: 3
			},
			{
				x: 3,
				y: 2,
				rotation: 2
			},
			{
				x: 0,
				y: 2,
				rotation: 1
			},
			{
				x: 1,
				y: 2,
				rotation: 2
			},
			{
				x: 0,
				y: 0,
				rotation: 2
			}
		],
		experts: [
			{
				rating: 5.42,
				clues: [
					{
						type: 10,
						a: 0,
						b: 1,
						rotation: -1
					},
					{
						type: 5,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 3,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 6.29,
				clues: [
					{
						type: 11,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 20,
						a: 1,
						b: 3,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 19,
						a: 3,
						b: 4,
						rotation: -1
					}
				]
			},
			{
				rating: 6.74,
				clues: [
					{
						type: 11,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 15,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 4,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 21,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 6.78,
				clues: [
					{
						type: 11,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 3,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 6,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 16,
						a: 5,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 7.03,
				clues: [
					{
						type: 11,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 16,
						a: 5,
						b: 3,
						rotation: -1
					},
					{
						type: 20,
						a: 2,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 7.08,
				clues: [
					{
						type: 19,
						a: 4,
						b: 1,
						rotation: -1
					},
					{
						type: 11,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 5,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 14,
						a: 1,
						b: 4,
						rotation: -1
					}
				]
			},
			{
				rating: 7.13,
				clues: [
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 2
					},
					{
						type: 21,
						a: 0,
						b: 2,
						rotation: -1
					},
					{
						type: 5,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 12,
						a: 3,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 7.58,
				clues: [
					{
						type: 22,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 9,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 13,
						a: 5,
						b: 0,
						rotation: -1
					},
					{
						type: 1,
						a: 3,
						b: -1,
						rotation: 1
					}
				]
			},
			{
				rating: 8.15,
				clues: [
					{
						type: 16,
						a: 1,
						b: 3,
						rotation: -1
					},
					{
						type: 14,
						a: 5,
						b: 0,
						rotation: -1
					},
					{
						type: 22,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 3,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 8.67,
				clues: [
					{
						type: 19,
						a: 0,
						b: 2,
						rotation: -1
					},
					{
						type: 2,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 4,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 3,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.41,
				clues: [
					{
						type: 6,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 13,
						a: 2,
						b: 1,
						rotation: -1
					},
					{
						type: 2,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 18,
						a: 1,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 10.58,
				clues: [
					{
						type: 15,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 21,
						a: 0,
						b: 5,
						rotation: -1
					},
					{
						type: 2,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 16,
						a: 2,
						b: 5,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "3735",
		rating: 7.85,
		traps: [
			{
				cell: 4,
				symbol: 2
			},
			{
				cell: 24,
				symbol: 1
			},
			{
				cell: 20,
				symbol: 1
			},
			{
				cell: 2,
				symbol: 1
			},
			{
				cell: 16,
				symbol: 2
			}
		],
		solution: [
			{
				x: 1,
				y: 4,
				rotation: 0
			},
			{
				x: 3,
				y: 2,
				rotation: 2
			},
			{
				x: 3,
				y: 0,
				rotation: 0
			},
			{
				x: 0,
				y: 2,
				rotation: 1
			},
			{
				x: 1,
				y: 2,
				rotation: 2
			},
			{
				x: 0,
				y: 0,
				rotation: 0
			}
		],
		experts: [
			{
				rating: 6.46,
				clues: [
					{
						type: 22,
						a: 18,
						b: -1,
						rotation: -1
					},
					{
						type: 9,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 4,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 6.6,
				clues: [
					{
						type: 11,
						a: 4,
						b: 2,
						rotation: -1
					},
					{
						type: 22,
						a: 18,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 2,
						a: 1,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.65,
				clues: [
					{
						type: 13,
						a: 5,
						b: 3,
						rotation: -1
					},
					{
						type: 11,
						a: 4,
						b: 2,
						rotation: -1
					},
					{
						type: 1,
						a: 3,
						b: -1,
						rotation: 1
					},
					{
						type: 3,
						a: 4,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.92,
				clues: [
					{
						type: 17,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 11,
						a: 4,
						b: 2,
						rotation: -1
					},
					{
						type: 22,
						a: 7,
						b: -1,
						rotation: -1
					},
					{
						type: 12,
						a: 5,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 7.98,
				clues: [
					{
						type: 20,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 3,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 9,
						a: 0,
						b: 1,
						rotation: -1
					},
					{
						type: 11,
						a: 4,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 8.25,
				clues: [
					{
						type: 14,
						a: 1,
						b: 2,
						rotation: -1
					},
					{
						type: 20,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 0
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.35,
				clues: [
					{
						type: 2,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 7,
						b: -1,
						rotation: -1
					},
					{
						type: 4,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 4,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 8.87,
				clues: [
					{
						type: 16,
						a: 2,
						b: 0,
						rotation: -1
					},
					{
						type: 8,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 18,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 1,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 10.03,
				clues: [
					{
						type: 16,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 14,
						a: 1,
						b: 2,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 2
					}
				]
			},
			{
				rating: 10.17,
				clues: [
					{
						type: 3,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 1,
						b: 3,
						rotation: -1
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 4,
						a: 1,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 10.31,
				clues: [
					{
						type: 2,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 13,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 21,
						a: 0,
						b: 4,
						rotation: -1
					}
				]
			},
			{
				rating: 10.36,
				clues: [
					{
						type: 4,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 9,
						a: 0,
						b: 4,
						rotation: -1
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "3753",
		rating: 7.96,
		traps: [
			{
				cell: 17,
				symbol: 2
			},
			{
				cell: 11,
				symbol: 2
			},
			{
				cell: 2,
				symbol: 2
			},
			{
				cell: 13,
				symbol: 1
			},
			{
				cell: 8,
				symbol: 2
			}
		],
		solution: [
			{
				x: 0,
				y: 0,
				rotation: 0
			},
			{
				x: 0,
				y: 1,
				rotation: 0
			},
			{
				x: 1,
				y: 1,
				rotation: 2
			},
			{
				x: 1,
				y: 3,
				rotation: 0
			},
			{
				x: 3,
				y: 0,
				rotation: 3
			},
			{
				x: 3,
				y: 2,
				rotation: 3
			}
		],
		experts: [
			{
				rating: 5.39,
				clues: [
					{
						type: 20,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 11,
						a: 4,
						b: 0,
						rotation: -1
					},
					{
						type: 1,
						a: 2,
						b: -1,
						rotation: 2
					},
					{
						type: 6,
						a: 3,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 6.74,
				clues: [
					{
						type: 10,
						a: 3,
						b: 4,
						rotation: -1
					},
					{
						type: 4,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 14,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 4,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 7.13,
				clues: [
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 3,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 3
					},
					{
						type: 11,
						a: 4,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 7.88,
				clues: [
					{
						type: 18,
						a: 1,
						b: 5,
						rotation: -1
					},
					{
						type: 20,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 11,
						a: 4,
						b: 0,
						rotation: -1
					},
					{
						type: 15,
						a: 4,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 7.93,
				clues: [
					{
						type: 11,
						a: 4,
						b: 0,
						rotation: -1
					},
					{
						type: 9,
						a: 3,
						b: 2,
						rotation: -1
					},
					{
						type: 15,
						a: 1,
						b: 5,
						rotation: -1
					},
					{
						type: 3,
						a: 2,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.93,
				clues: [
					{
						type: 21,
						a: 1,
						b: 0,
						rotation: -1
					},
					{
						type: 11,
						a: 4,
						b: 0,
						rotation: -1
					},
					{
						type: 9,
						a: 5,
						b: 3,
						rotation: -1
					},
					{
						type: 8,
						a: 5,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.01,
				clues: [
					{
						type: 7,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 4,
						b: 0,
						rotation: -1
					},
					{
						type: 17,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 3,
						a: 2,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.13,
				clues: [
					{
						type: 9,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 22,
						a: 20,
						b: -1,
						rotation: -1
					},
					{
						type: 17,
						a: 3,
						b: 4,
						rotation: -1
					},
					{
						type: 11,
						a: 4,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 8.14,
				clues: [
					{
						type: 5,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 3
					},
					{
						type: 10,
						a: 1,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 8.45,
				clues: [
					{
						type: 2,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 19,
						a: 3,
						b: 2,
						rotation: -1
					},
					{
						type: 22,
						a: 14,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 4,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.81,
				clues: [
					{
						type: 21,
						a: 3,
						b: 4,
						rotation: -1
					},
					{
						type: 10,
						a: 1,
						b: 4,
						rotation: -1
					},
					{
						type: 2,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 15,
						a: 4,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 9.95,
				clues: [
					{
						type: 21,
						a: 2,
						b: 0,
						rotation: -1
					},
					{
						type: 7,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 3
					}
				]
			}
		]
	},
	{
		card: "3755",
		rating: 8.22,
		traps: [
			{
				cell: 9,
				symbol: 1
			},
			{
				cell: 17,
				symbol: 2
			},
			{
				cell: 4,
				symbol: 2
			},
			{
				cell: 0,
				symbol: 1
			},
			{
				cell: 6,
				symbol: 2
			}
		],
		solution: [
			{
				x: 2,
				y: 1,
				rotation: 1
			},
			{
				x: 1,
				y: 3,
				rotation: 3
			},
			{
				x: 3,
				y: 0,
				rotation: 0
			},
			{
				x: 0,
				y: 0,
				rotation: 2
			},
			{
				x: 3,
				y: 2,
				rotation: 2
			},
			{
				x: 0,
				y: 1,
				rotation: 1
			}
		],
		experts: [
			{
				rating: 6.02,
				clues: [
					{
						type: 22,
						a: 24,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 7,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 1
					}
				]
			},
			{
				rating: 6.42,
				clues: [
					{
						type: 5,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 9,
						a: 5,
						b: 3,
						rotation: -1
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 24,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.27,
				clues: [
					{
						type: 14,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 3,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 2,
						b: -1,
						rotation: 0
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.32,
				clues: [
					{
						type: 6,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 18,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 10,
						a: 2,
						b: 1,
						rotation: -1
					},
					{
						type: 14,
						a: 1,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 7.33,
				clues: [
					{
						type: 2,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 24,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 2
					}
				]
			},
			{
				rating: 7.42,
				clues: [
					{
						type: 13,
						a: 1,
						b: 3,
						rotation: -1
					},
					{
						type: 9,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 1,
						a: 0,
						b: -1,
						rotation: 1
					},
					{
						type: 22,
						a: 20,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.96,
				clues: [
					{
						type: 20,
						a: 4,
						b: 3,
						rotation: -1
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 15,
						b: -1,
						rotation: -1
					},
					{
						type: 14,
						a: 5,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 8.18,
				clues: [
					{
						type: 16,
						a: 4,
						b: 0,
						rotation: -1
					},
					{
						type: 10,
						a: 2,
						b: 1,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 2
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.24,
				clues: [
					{
						type: 15,
						a: 2,
						b: 3,
						rotation: -1
					},
					{
						type: 17,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 10,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 2
					}
				]
			},
			{
				rating: 8.34,
				clues: [
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 15,
						a: 4,
						b: 3,
						rotation: -1
					},
					{
						type: 21,
						a: 1,
						b: 3,
						rotation: -1
					},
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 3
					}
				]
			},
			{
				rating: 8.39,
				clues: [
					{
						type: 22,
						a: 20,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 1,
						b: 3,
						rotation: -1
					},
					{
						type: 4,
						a: 2,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.64,
				clues: [
					{
						type: 9,
						a: 2,
						b: 0,
						rotation: -1
					},
					{
						type: 7,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 3,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 18,
						a: 2,
						b: 5,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "3757",
		rating: 8.33,
		traps: [
			{
				cell: 11,
				symbol: 2
			},
			{
				cell: 14,
				symbol: 1
			},
			{
				cell: 22,
				symbol: 1
			},
			{
				cell: 8,
				symbol: 2
			},
			{
				cell: 12,
				symbol: 1
			}
		],
		solution: [
			{
				x: 3,
				y: 1,
				rotation: 3
			},
			{
				x: 3,
				y: 0,
				rotation: 2
			},
			{
				x: 1,
				y: 3,
				rotation: 0
			},
			{
				x: 0,
				y: 1,
				rotation: 1
			},
			{
				x: 3,
				y: 3,
				rotation: 3
			},
			{
				x: 1,
				y: 0,
				rotation: 1
			}
		],
		experts: [
			{
				rating: 4,
				clues: [
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 1
					},
					{
						type: 22,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 4,
						b: 2,
						rotation: -1
					},
					{
						type: 3,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 6.3,
				clues: [
					{
						type: 11,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 22,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 21,
						a: 2,
						b: 1,
						rotation: -1
					},
					{
						type: 10,
						a: 2,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 6.32,
				clues: [
					{
						type: 11,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 17,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 12,
						a: 2,
						b: 3,
						rotation: -1
					},
					{
						type: 22,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 6.41,
				clues: [
					{
						type: 11,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 10,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 17,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 22,
						a: 2,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 6.51,
				clues: [
					{
						type: 19,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 10,
						a: 2,
						b: 1,
						rotation: -1
					},
					{
						type: 13,
						a: 2,
						b: 1,
						rotation: -1
					},
					{
						type: 11,
						a: 5,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 6.52,
				clues: [
					{
						type: 5,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 1
					},
					{
						type: 18,
						a: 5,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 6.77,
				clues: [
					{
						type: 11,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 9,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 7,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 12,
						a: 2,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 6.82,
				clues: [
					{
						type: 11,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 22,
						a: 20,
						b: -1,
						rotation: -1
					},
					{
						type: 13,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 8,
						a: 1,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.1,
				clues: [
					{
						type: 12,
						a: 5,
						b: 0,
						rotation: -1
					},
					{
						type: 8,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 3
					},
					{
						type: 11,
						a: 5,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.61,
				clues: [
					{
						type: 9,
						a: 2,
						b: 3,
						rotation: -1
					},
					{
						type: 20,
						a: 0,
						b: 5,
						rotation: -1
					},
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 2
					},
					{
						type: 22,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.66,
				clues: [
					{
						type: 20,
						a: 1,
						b: 3,
						rotation: -1
					},
					{
						type: 22,
						a: 20,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 8,
						a: 4,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.41,
				clues: [
					{
						type: 8,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 2,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 16,
						a: 0,
						b: 5,
						rotation: -1
					},
					{
						type: 10,
						a: 5,
						b: 4,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "5337",
		rating: 8.62,
		traps: [
			{
				cell: 12,
				symbol: 2
			},
			{
				cell: 17,
				symbol: 1
			},
			{
				cell: 24,
				symbol: 1
			},
			{
				cell: 18,
				symbol: 2
			},
			{
				cell: 6,
				symbol: 2
			}
		],
		solution: [
			{
				x: 0,
				y: 2,
				rotation: 0
			},
			{
				x: 0,
				y: 3,
				rotation: 1
			},
			{
				x: 0,
				y: 0,
				rotation: 1
			},
			{
				x: 2,
				y: 3,
				rotation: 0
			},
			{
				x: 2,
				y: 0,
				rotation: 1
			},
			{
				x: 3,
				y: 1,
				rotation: 3
			}
		],
		experts: [
			{
				rating: 7.1,
				clues: [
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 3
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 5,
						b: 0,
						rotation: -1
					},
					{
						type: 22,
						a: 21,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.94,
				clues: [
					{
						type: 14,
						a: 0,
						b: 2,
						rotation: -1
					},
					{
						type: 18,
						a: 5,
						b: 3,
						rotation: -1
					},
					{
						type: 20,
						a: 3,
						b: 2,
						rotation: -1
					},
					{
						type: 9,
						a: 5,
						b: 4,
						rotation: -1
					}
				]
			},
			{
				rating: 8.01,
				clues: [
					{
						type: 11,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 1,
						a: 3,
						b: -1,
						rotation: 0
					},
					{
						type: 8,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 12,
						a: 5,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 8.42,
				clues: [
					{
						type: 5,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 16,
						a: 4,
						b: 1,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 1
					},
					{
						type: 9,
						a: 4,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 8.57,
				clues: [
					{
						type: 21,
						a: 3,
						b: 2,
						rotation: -1
					},
					{
						type: 10,
						a: 1,
						b: 2,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 1
					},
					{
						type: 12,
						a: 4,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 8.78,
				clues: [
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 16,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 1
					},
					{
						type: 11,
						a: 0,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 8.88,
				clues: [
					{
						type: 11,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 14,
						a: 0,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 8.9,
				clues: [
					{
						type: 12,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 21,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 5,
						a: 4,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.95,
				clues: [
					{
						type: 12,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 20,
						a: 4,
						b: 2,
						rotation: -1
					},
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 1
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.14,
				clues: [
					{
						type: 10,
						a: 0,
						b: 3,
						rotation: -1
					},
					{
						type: 22,
						a: 9,
						b: -1,
						rotation: -1
					},
					{
						type: 6,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 2,
						a: 5,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.3,
				clues: [
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 3
					},
					{
						type: 2,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 5,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 5,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 10.25,
				clues: [
					{
						type: 15,
						a: 4,
						b: 2,
						rotation: -1
					},
					{
						type: 2,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 4,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 21,
						a: 3,
						b: 2,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "5357",
		rating: 8.74,
		traps: [
			{
				cell: 10,
				symbol: 2
			},
			{
				cell: 7,
				symbol: 1
			},
			{
				cell: 20,
				symbol: 1
			},
			{
				cell: 0,
				symbol: 1
			},
			{
				cell: 6,
				symbol: 2
			}
		],
		solution: [
			{
				x: 1,
				y: 2,
				rotation: 0
			},
			{
				x: 0,
				y: 3,
				rotation: 3
			},
			{
				x: 3,
				y: 3,
				rotation: 2
			},
			{
				x: 0,
				y: 0,
				rotation: 2
			},
			{
				x: 0,
				y: 2,
				rotation: 0
			},
			{
				x: 2,
				y: 0,
				rotation: 2
			}
		],
		experts: [
			{
				rating: 4.9,
				clues: [
					{
						type: 10,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 21,
						a: 0,
						b: 3,
						rotation: -1
					},
					{
						type: 22,
						a: 14,
						b: -1,
						rotation: -1
					},
					{
						type: 18,
						a: 0,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 6.12,
				clues: [
					{
						type: 3,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 0
					},
					{
						type: 21,
						a: 4,
						b: 5,
						rotation: -1
					},
					{
						type: 11,
						a: 4,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 6.2,
				clues: [
					{
						type: 13,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 22,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 4,
						b: 3,
						rotation: -1
					},
					{
						type: 6,
						a: 2,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 6.46,
				clues: [
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 18,
						a: 3,
						b: 4,
						rotation: -1
					},
					{
						type: 11,
						a: 4,
						b: 3,
						rotation: -1
					},
					{
						type: 5,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 6.73,
				clues: [
					{
						type: 20,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 14,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 11,
						a: 4,
						b: 3,
						rotation: -1
					},
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 3
					}
				]
			},
			{
				rating: 7.86,
				clues: [
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 2
					},
					{
						type: 22,
						a: 9,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 2,
						a: 4,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.94,
				clues: [
					{
						type: 9,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 11,
						a: 4,
						b: 3,
						rotation: -1
					},
					{
						type: 14,
						a: 4,
						b: 0,
						rotation: -1
					},
					{
						type: 6,
						a: 5,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.1,
				clues: [
					{
						type: 10,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 3,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 2,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 8.11,
				clues: [
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 4,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 4,
						b: 3,
						rotation: -1
					},
					{
						type: 16,
						a: 5,
						b: 4,
						rotation: -1
					}
				]
			},
			{
				rating: 8.52,
				clues: [
					{
						type: 13,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 6,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 2,
						a: 5,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.63,
				clues: [
					{
						type: 22,
						a: 14,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 2,
						b: 1,
						rotation: -1
					},
					{
						type: 8,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 12,
						a: 2,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.2,
				clues: [
					{
						type: 14,
						a: 4,
						b: 1,
						rotation: -1
					},
					{
						type: 10,
						a: 2,
						b: 3,
						rotation: -1
					},
					{
						type: 6,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 21,
						a: 1,
						b: 3,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "5373",
		rating: 8.78,
		traps: [
			{
				cell: 7,
				symbol: 2
			},
			{
				cell: 24,
				symbol: 2
			},
			{
				cell: 17,
				symbol: 1
			},
			{
				cell: 10,
				symbol: 1
			},
			{
				cell: 18,
				symbol: 2
			}
		],
		solution: [
			{
				x: 2,
				y: 4,
				rotation: 0
			},
			{
				x: 3,
				y: 1,
				rotation: 2
			},
			{
				x: 2,
				y: 2,
				rotation: 1
			},
			{
				x: 1,
				y: 0,
				rotation: 2
			},
			{
				x: 0,
				y: 1,
				rotation: 2
			},
			{
				x: 0,
				y: 2,
				rotation: 3
			}
		],
		experts: [
			{
				rating: 7.9,
				clues: [
					{
						type: 17,
						a: 5,
						b: 0,
						rotation: -1
					},
					{
						type: 14,
						a: 3,
						b: 4,
						rotation: -1
					},
					{
						type: 1,
						a: 2,
						b: -1,
						rotation: 1
					},
					{
						type: 6,
						a: 3,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.93,
				clues: [
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 3,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 3
					}
				]
			},
			{
				rating: 8.62,
				clues: [
					{
						type: 7,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 9,
						a: 0,
						b: 1,
						rotation: -1
					},
					{
						type: 2,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 13,
						a: 5,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 8.83,
				clues: [
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 3
					},
					{
						type: 22,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 4,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 15,
						a: 5,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.9,
				clues: [
					{
						type: 21,
						a: 0,
						b: 4,
						rotation: -1
					},
					{
						type: 9,
						a: 4,
						b: 2,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 2
					},
					{
						type: 5,
						a: 3,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.05,
				clues: [
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 5,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 1,
						b: 5,
						rotation: -1
					},
					{
						type: 10,
						a: 4,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.05,
				clues: [
					{
						type: 9,
						a: 3,
						b: 4,
						rotation: -1
					},
					{
						type: 15,
						a: 4,
						b: 2,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 3,
						a: 2,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.18,
				clues: [
					{
						type: 18,
						a: 1,
						b: 5,
						rotation: -1
					},
					{
						type: 10,
						a: 4,
						b: 0,
						rotation: -1
					},
					{
						type: 21,
						a: 0,
						b: 2,
						rotation: -1
					},
					{
						type: 22,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.81,
				clues: [
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 2
					},
					{
						type: 22,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 18,
						a: 1,
						b: 0,
						rotation: -1
					},
					{
						type: 21,
						a: 0,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 10.12,
				clues: [
					{
						type: 6,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 12,
						a: 1,
						b: 2,
						rotation: -1
					},
					{
						type: 21,
						a: 0,
						b: 4,
						rotation: -1
					},
					{
						type: 16,
						a: 3,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 10.19,
				clues: [
					{
						type: 22,
						a: 20,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 3,
						b: -1,
						rotation: 2
					},
					{
						type: 2,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 10.39,
				clues: [
					{
						type: 22,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 19,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 2,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 13,
						a: 0,
						b: 2,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "5375",
		rating: 8.94,
		traps: [
			{
				cell: 22,
				symbol: 2
			},
			{
				cell: 11,
				symbol: 1
			},
			{
				cell: 4,
				symbol: 1
			},
			{
				cell: 2,
				symbol: 1
			},
			{
				cell: 16,
				symbol: 2
			}
		],
		solution: [
			{
				x: 4,
				y: 1,
				rotation: 3
			},
			{
				x: 0,
				y: 0,
				rotation: 1
			},
			{
				x: 0,
				y: 3,
				rotation: 0
			},
			{
				x: 1,
				y: 2,
				rotation: 2
			},
			{
				x: 2,
				y: 3,
				rotation: 3
			},
			{
				x: 2,
				y: 0,
				rotation: 0
			}
		],
		experts: [
			{
				rating: 7.05,
				clues: [
					{
						type: 22,
						a: 10,
						b: -1,
						rotation: -1
					},
					{
						type: 12,
						a: 0,
						b: 5,
						rotation: -1
					},
					{
						type: 11,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 3
					}
				]
			},
			{
				rating: 7.21,
				clues: [
					{
						type: 21,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 3
					},
					{
						type: 11,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 15,
						a: 0,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 7.83,
				clues: [
					{
						type: 11,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 19,
						a: 2,
						b: 1,
						rotation: -1
					},
					{
						type: 14,
						a: 4,
						b: 1,
						rotation: -1
					},
					{
						type: 8,
						a: 5,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.86,
				clues: [
					{
						type: 3,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 9,
						a: 0,
						b: 3,
						rotation: -1
					},
					{
						type: 20,
						a: 0,
						b: 4,
						rotation: -1
					},
					{
						type: 15,
						a: 2,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 8.37,
				clues: [
					{
						type: 22,
						a: 24,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 18,
						a: 1,
						b: 3,
						rotation: -1
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.8,
				clues: [
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 3
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 14,
						a: 4,
						b: 1,
						rotation: -1
					},
					{
						type: 20,
						a: 0,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 9.61,
				clues: [
					{
						type: 9,
						a: 3,
						b: 2,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 3
					},
					{
						type: 14,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 2,
						a: 4,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 10,
				clues: [
					{
						type: 10,
						a: 4,
						b: 1,
						rotation: -1
					},
					{
						type: 6,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 0,
						b: 1,
						rotation: -1
					},
					{
						type: 2,
						a: 1,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 10.36,
				clues: [
					{
						type: 4,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 21,
						a: 4,
						b: 1,
						rotation: -1
					},
					{
						type: 10,
						a: 0,
						b: 1,
						rotation: -1
					},
					{
						type: 14,
						a: 0,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 10.46,
				clues: [
					{
						type: 21,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 10,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 4,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 18,
						a: 1,
						b: 4,
						rotation: -1
					}
				]
			},
			{
				rating: 10.85,
				clues: [
					{
						type: 8,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 19,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 4,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 21,
						a: 4,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 11.22,
				clues: [
					{
						type: 6,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 9,
						a: 3,
						b: 4,
						rotation: -1
					},
					{
						type: 13,
						a: 4,
						b: 5,
						rotation: -1
					},
					{
						type: 1,
						a: 0,
						b: -1,
						rotation: 3
					}
				]
			}
		]
	},
	{
		card: "5377",
		rating: 8.98,
		traps: [
			{
				cell: 0,
				symbol: 1
			},
			{
				cell: 20,
				symbol: 1
			},
			{
				cell: 24,
				symbol: 1
			},
			{
				cell: 18,
				symbol: 2
			},
			{
				cell: 12,
				symbol: 1
			}
		],
		solution: [
			{
				x: 4,
				y: 0,
				rotation: 3
			},
			{
				x: 0,
				y: 2,
				rotation: 1
			},
			{
				x: 0,
				y: 0,
				rotation: 2
			},
			{
				x: 2,
				y: 3,
				rotation: 0
			},
			{
				x: 2,
				y: 1,
				rotation: 2
			},
			{
				x: 0,
				y: 3,
				rotation: 2
			}
		],
		experts: [
			{
				rating: 7.65,
				clues: [
					{
						type: 6,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 16,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 3,
						a: 4,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.75,
				clues: [
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 19,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 2
					},
					{
						type: 14,
						a: 5,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.88,
				clues: [
					{
						type: 21,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 22,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 13,
						a: 5,
						b: 0,
						rotation: -1
					},
					{
						type: 3,
						a: 4,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.08,
				clues: [
					{
						type: 17,
						a: 1,
						b: 4,
						rotation: -1
					},
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 1
					},
					{
						type: 11,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.22,
				clues: [
					{
						type: 22,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 0,
						b: -1,
						rotation: 3
					},
					{
						type: 21,
						a: 3,
						b: 4,
						rotation: -1
					},
					{
						type: 9,
						a: 2,
						b: 4,
						rotation: -1
					}
				]
			},
			{
				rating: 8.24,
				clues: [
					{
						type: 10,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 13,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 5,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 18,
						a: 0,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 8.78,
				clues: [
					{
						type: 10,
						a: 1,
						b: 0,
						rotation: -1
					},
					{
						type: 22,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 12,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 17,
						a: 2,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 8.85,
				clues: [
					{
						type: 1,
						a: 2,
						b: -1,
						rotation: 2
					},
					{
						type: 3,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 4,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.04,
				clues: [
					{
						type: 1,
						a: 3,
						b: -1,
						rotation: 0
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 6,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 3,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.06,
				clues: [
					{
						type: 14,
						a: 5,
						b: 3,
						rotation: -1
					},
					{
						type: 9,
						a: 2,
						b: 1,
						rotation: -1
					},
					{
						type: 22,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 21,
						a: 5,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 9.42,
				clues: [
					{
						type: 2,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 0,
						b: 4,
						rotation: -1
					},
					{
						type: 11,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 10,
						a: 3,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 9.93,
				clues: [
					{
						type: 2,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 0,
						b: -1,
						rotation: 3
					},
					{
						type: 20,
						a: 0,
						b: 2,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "5537",
		rating: 9.14,
		traps: [
			{
				cell: 11,
				symbol: 1
			},
			{
				cell: 4,
				symbol: 1
			},
			{
				cell: 22,
				symbol: 1
			},
			{
				cell: 6,
				symbol: 2
			},
			{
				cell: 8,
				symbol: 2
			}
		],
		solution: [
			{
				x: 0,
				y: 0,
				rotation: 2
			},
			{
				x: 2,
				y: 3,
				rotation: 3
			},
			{
				x: 0,
				y: 1,
				rotation: 0
			},
			{
				x: 3,
				y: 0,
				rotation: 3
			},
			{
				x: 1,
				y: 3,
				rotation: 1
			},
			{
				x: 2,
				y: 1,
				rotation: 3
			}
		],
		experts: [
			{
				rating: 6.38,
				clues: [
					{
						type: 20,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 22,
						a: 20,
						b: -1,
						rotation: -1
					},
					{
						type: 2,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 3
					}
				]
			},
			{
				rating: 7.41,
				clues: [
					{
						type: 22,
						a: 15,
						b: -1,
						rotation: -1
					},
					{
						type: 18,
						a: 0,
						b: 4,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 3
					},
					{
						type: 11,
						a: 3,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 7.43,
				clues: [
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 3
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 20,
						a: 3,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 7.95,
				clues: [
					{
						type: 3,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 22,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 21,
						a: 4,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 8.5,
				clues: [
					{
						type: 11,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 17,
						a: 5,
						b: 3,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 2,
						a: 4,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.71,
				clues: [
					{
						type: 11,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 10,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 19,
						a: 4,
						b: 3,
						rotation: -1
					},
					{
						type: 20,
						a: 3,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 9.27,
				clues: [
					{
						type: 21,
						a: 1,
						b: 2,
						rotation: -1
					},
					{
						type: 22,
						a: 20,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 2,
						b: 1,
						rotation: -1
					},
					{
						type: 7,
						a: 2,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.34,
				clues: [
					{
						type: 12,
						a: 4,
						b: 1,
						rotation: -1
					},
					{
						type: 21,
						a: 1,
						b: 2,
						rotation: -1
					},
					{
						type: 22,
						a: 20,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 4,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 9.65,
				clues: [
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 3
					},
					{
						type: 2,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 16,
						a: 4,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 10.08,
				clues: [
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 20,
						b: -1,
						rotation: -1
					},
					{
						type: 2,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 6,
						a: 4,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 10.1,
				clues: [
					{
						type: 4,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 21,
						a: 5,
						b: 0,
						rotation: -1
					},
					{
						type: 10,
						a: 4,
						b: 0,
						rotation: -1
					},
					{
						type: 2,
						a: 1,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 10.54,
				clues: [
					{
						type: 2,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 7,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 9,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "5733",
		rating: 9.26,
		traps: [
			{
				cell: 24,
				symbol: 1
			},
			{
				cell: 0,
				symbol: 1
			},
			{
				cell: 10,
				symbol: 1
			},
			{
				cell: 8,
				symbol: 2
			},
			{
				cell: 18,
				symbol: 2
			}
		],
		solution: [
			{
				x: 2,
				y: 2,
				rotation: 0
			},
			{
				x: 0,
				y: 2,
				rotation: 0
			},
			{
				x: 3,
				y: 0,
				rotation: 2
			},
			{
				x: 2,
				y: 3,
				rotation: 0
			},
			{
				x: 1,
				y: 0,
				rotation: 2
			},
			{
				x: 0,
				y: 0,
				rotation: 3
			}
		],
		experts: [
			{
				rating: 7.72,
				clues: [
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 3,
						b: 2,
						rotation: -1
					},
					{
						type: 22,
						a: 19,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 3,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.44,
				clues: [
					{
						type: 9,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 21,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 12,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.93,
				clues: [
					{
						type: 13,
						a: 3,
						b: 4,
						rotation: -1
					},
					{
						type: 9,
						a: 2,
						b: 0,
						rotation: -1
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 3
					}
				]
			},
			{
				rating: 9.4,
				clues: [
					{
						type: 4,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 9,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 3
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.4,
				clues: [
					{
						type: 12,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 9,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 1,
						a: 2,
						b: -1,
						rotation: 2
					},
					{
						type: 5,
						a: 4,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.55,
				clues: [
					{
						type: 20,
						a: 0,
						b: 5,
						rotation: -1
					},
					{
						type: 22,
						a: 19,
						b: -1,
						rotation: -1
					},
					{
						type: 17,
						a: 3,
						b: 2,
						rotation: -1
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.62,
				clues: [
					{
						type: 9,
						a: 5,
						b: 0,
						rotation: -1
					},
					{
						type: 21,
						a: 0,
						b: 2,
						rotation: -1
					},
					{
						type: 1,
						a: 3,
						b: -1,
						rotation: 0
					},
					{
						type: 14,
						a: 4,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 10.19,
				clues: [
					{
						type: 4,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 12,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 18,
						a: 4,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 10.57,
				clues: [
					{
						type: 19,
						a: 0,
						b: 2,
						rotation: -1
					},
					{
						type: 10,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 12,
						a: 1,
						b: 0,
						rotation: -1
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 10.78,
				clues: [
					{
						type: 20,
						a: 2,
						b: 1,
						rotation: -1
					},
					{
						type: 22,
						a: 19,
						b: -1,
						rotation: -1
					},
					{
						type: 2,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 18,
						a: 4,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 10.78,
				clues: [
					{
						type: 17,
						a: 5,
						b: 3,
						rotation: -1
					},
					{
						type: 7,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 20,
						a: 2,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 11.73,
				clues: [
					{
						type: 4,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 12,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 9,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 18,
						a: 4,
						b: 3,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "5737",
		rating: 9.28,
		traps: [
			{
				cell: 4,
				symbol: 2
			},
			{
				cell: 24,
				symbol: 2
			},
			{
				cell: 20,
				symbol: 1
			},
			{
				cell: 6,
				symbol: 2
			},
			{
				cell: 12,
				symbol: 1
			}
		],
		solution: [
			{
				x: 2,
				y: 4,
				rotation: 0
			},
			{
				x: 0,
				y: 2,
				rotation: 1
			},
			{
				x: 1,
				y: 0,
				rotation: 2
			},
			{
				x: 3,
				y: 1,
				rotation: 3
			},
			{
				x: 3,
				y: 0,
				rotation: 1
			},
			{
				x: 0,
				y: 3,
				rotation: 2
			}
		],
		experts: [
			{
				rating: 6.36,
				clues: [
					{
						type: 13,
						a: 4,
						b: 5,
						rotation: -1
					},
					{
						type: 11,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 2
					},
					{
						type: 18,
						a: 3,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 6.54,
				clues: [
					{
						type: 22,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 1
					},
					{
						type: 11,
						a: 3,
						b: 2,
						rotation: -1
					},
					{
						type: 18,
						a: 1,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 6.77,
				clues: [
					{
						type: 11,
						a: 4,
						b: 1,
						rotation: -1
					},
					{
						type: 22,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 19,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 7,
						a: 3,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.99,
				clues: [
					{
						type: 8,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 6,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 14,
						a: 2,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 9.1,
				clues: [
					{
						type: 8,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 18,
						a: 4,
						b: 5,
						rotation: -1
					},
					{
						type: 6,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 1
					}
				]
			},
			{
				rating: 9.12,
				clues: [
					{
						type: 7,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 9,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 13,
						a: 4,
						b: 1,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.18,
				clues: [
					{
						type: 2,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 3,
						b: 2,
						rotation: -1
					},
					{
						type: 22,
						a: 18,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 5,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.36,
				clues: [
					{
						type: 11,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 1
					},
					{
						type: 10,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 21,
						a: 5,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 9.59,
				clues: [
					{
						type: 9,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 12,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 1,
						a: 0,
						b: -1,
						rotation: 0
					},
					{
						type: 2,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.68,
				clues: [
					{
						type: 8,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 20,
						a: 3,
						b: 2,
						rotation: -1
					},
					{
						type: 17,
						a: 5,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 10.18,
				clues: [
					{
						type: 7,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 15,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 10,
						a: 4,
						b: 0,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 10.5,
				clues: [
					{
						type: 14,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 9,
						a: 2,
						b: 1,
						rotation: -1
					},
					{
						type: 4,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 3,
						b: 5,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "5773",
		rating: 9.34,
		traps: [
			{
				cell: 2,
				symbol: 2
			},
			{
				cell: 17,
				symbol: 1
			},
			{
				cell: 22,
				symbol: 1
			},
			{
				cell: 10,
				symbol: 1
			},
			{
				cell: 16,
				symbol: 2
			}
		],
		solution: [
			{
				x: 0,
				y: 0,
				rotation: 0
			},
			{
				x: 0,
				y: 1,
				rotation: 3
			},
			{
				x: 3,
				y: 0,
				rotation: 0
			},
			{
				x: 0,
				y: 3,
				rotation: 0
			},
			{
				x: 3,
				y: 3,
				rotation: 3
			},
			{
				x: 2,
				y: 2,
				rotation: 2
			}
		],
		experts: [
			{
				rating: 9.59,
				clues: [
					{
						type: 21,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 22,
						a: 6,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 4,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.62,
				clues: [
					{
						type: 10,
						a: 0,
						b: 5,
						rotation: -1
					},
					{
						type: 7,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 3
					},
					{
						type: 22,
						a: 15,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.92,
				clues: [
					{
						type: 19,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 9,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 21,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 3
					}
				]
			},
			{
				rating: 10.25,
				clues: [
					{
						type: 19,
						a: 3,
						b: 2,
						rotation: -1
					},
					{
						type: 22,
						a: 6,
						b: -1,
						rotation: -1
					},
					{
						type: 21,
						a: 5,
						b: 0,
						rotation: -1
					},
					{
						type: 14,
						a: 0,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 10.43,
				clues: [
					{
						type: 21,
						a: 3,
						b: 2,
						rotation: -1
					},
					{
						type: 2,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 14,
						a: 1,
						b: 3,
						rotation: -1
					},
					{
						type: 22,
						a: 5,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 10.59,
				clues: [
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 12,
						a: 2,
						b: 0,
						rotation: -1
					},
					{
						type: 20,
						a: 2,
						b: 3,
						rotation: -1
					},
					{
						type: 7,
						a: 1,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 10.84,
				clues: [
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 2,
						b: 0,
						rotation: -1
					},
					{
						type: 7,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 12,
						a: 5,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 11.14,
				clues: [
					{
						type: 22,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 2,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 18,
						a: 2,
						b: 1,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 11.83,
				clues: [
					{
						type: 9,
						a: 5,
						b: 3,
						rotation: -1
					},
					{
						type: 1,
						a: 2,
						b: -1,
						rotation: 0
					},
					{
						type: 14,
						a: 0,
						b: 5,
						rotation: -1
					},
					{
						type: 22,
						a: 15,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 11.84,
				clues: [
					{
						type: 2,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 15,
						b: -1,
						rotation: -1
					},
					{
						type: 13,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 2
					}
				]
			},
			{
				rating: 11.91,
				clues: [
					{
						type: 10,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 12,
						a: 5,
						b: 3,
						rotation: -1
					},
					{
						type: 22,
						a: 15,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 12.28,
				clues: [
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 3
					},
					{
						type: 2,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 16,
						a: 4,
						b: 1,
						rotation: -1
					},
					{
						type: 20,
						a: 2,
						b: 0,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "7335",
		rating: 9.44,
		traps: [
			{
				cell: 21,
				symbol: 1
			},
			{
				cell: 17,
				symbol: 2
			},
			{
				cell: 7,
				symbol: 2
			},
			{
				cell: 20,
				symbol: 2
			},
			{
				cell: 14,
				symbol: 1
			}
		],
		solution: [
			{
				x: 0,
				y: 2,
				rotation: 1
			},
			{
				x: 3,
				y: 0,
				rotation: 2
			},
			{
				x: 2,
				y: 1,
				rotation: 3
			},
			{
				x: 1,
				y: 2,
				rotation: 1
			},
			{
				x: 0,
				y: 0,
				rotation: 3
			},
			{
				x: 2,
				y: 3,
				rotation: 0
			}
		],
		experts: [
			{
				rating: 7.65,
				clues: [
					{
						type: 20,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 2,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 9,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 1,
						a: 2,
						b: -1,
						rotation: 3
					}
				]
			},
			{
				rating: 8.06,
				clues: [
					{
						type: 18,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 7,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 13,
						a: 4,
						b: 5,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 0
					}
				]
			},
			{
				rating: 8.19,
				clues: [
					{
						type: 3,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 14,
						a: 2,
						b: 1,
						rotation: -1
					},
					{
						type: 20,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 9,
						a: 5,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.41,
				clues: [
					{
						type: 9,
						a: 2,
						b: 1,
						rotation: -1
					},
					{
						type: 3,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 3,
						b: -1,
						rotation: 1
					},
					{
						type: 8,
						a: 1,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.53,
				clues: [
					{
						type: 10,
						a: 0,
						b: 1,
						rotation: -1
					},
					{
						type: 4,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 3,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 2,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 8.57,
				clues: [
					{
						type: 22,
						a: 24,
						b: -1,
						rotation: -1
					},
					{
						type: 3,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 2
					},
					{
						type: 6,
						a: 3,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.73,
				clues: [
					{
						type: 21,
						a: 0,
						b: 4,
						rotation: -1
					},
					{
						type: 5,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 4,
						b: 5,
						rotation: -1
					},
					{
						type: 22,
						a: 24,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.13,
				clues: [
					{
						type: 22,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 18,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 0
					}
				]
			},
			{
				rating: 9.46,
				clues: [
					{
						type: 12,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 3
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 1,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 9.56,
				clues: [
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 9,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 17,
						a: 0,
						b: 2,
						rotation: -1
					},
					{
						type: 21,
						a: 5,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.83,
				clues: [
					{
						type: 20,
						a: 5,
						b: 0,
						rotation: -1
					},
					{
						type: 16,
						a: 5,
						b: 3,
						rotation: -1
					},
					{
						type: 9,
						a: 5,
						b: 3,
						rotation: -1
					},
					{
						type: 12,
						a: 2,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 10.18,
				clues: [
					{
						type: 2,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 14,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 22,
						a: 24,
						b: -1,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "7353",
		rating: 9.8,
		traps: [
			{
				cell: 20,
				symbol: 2
			},
			{
				cell: 0,
				symbol: 2
			},
			{
				cell: 11,
				symbol: 1
			},
			{
				cell: 2,
				symbol: 1
			},
			{
				cell: 12,
				symbol: 1
			}
		],
		solution: [
			{
				x: 0,
				y: 2,
				rotation: 1
			},
			{
				x: 1,
				y: 2,
				rotation: 0
			},
			{
				x: 2,
				y: 0,
				rotation: 2
			},
			{
				x: 3,
				y: 1,
				rotation: 3
			},
			{
				x: 0,
				y: 0,
				rotation: 0
			},
			{
				x: 2,
				y: 2,
				rotation: 3
			}
		],
		experts: [
			{
				rating: 6.25,
				clues: [
					{
						type: 17,
						a: 5,
						b: 3,
						rotation: -1
					},
					{
						type: 11,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 1,
						a: 0,
						b: -1,
						rotation: 1
					},
					{
						type: 22,
						a: 24,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 6.51,
				clues: [
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 3
					},
					{
						type: 21,
						a: 0,
						b: 2,
						rotation: -1
					},
					{
						type: 7,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 12,
						a: 3,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 7.44,
				clues: [
					{
						type: 1,
						a: 0,
						b: -1,
						rotation: 1
					},
					{
						type: 2,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 21,
						a: 0,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 7.82,
				clues: [
					{
						type: 5,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 1,
						b: 2,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 18,
						a: 3,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.92,
				clues: [
					{
						type: 2,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 24,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 7,
						a: 3,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.37,
				clues: [
					{
						type: 13,
						a: 1,
						b: 4,
						rotation: -1
					},
					{
						type: 21,
						a: 1,
						b: 4,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 1,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 8.37,
				clues: [
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 0
					},
					{
						type: 8,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 19,
						a: 5,
						b: 3,
						rotation: -1
					},
					{
						type: 11,
						a: 5,
						b: 4,
						rotation: -1
					}
				]
			},
			{
				rating: 8.54,
				clues: [
					{
						type: 19,
						a: 1,
						b: 4,
						rotation: -1
					},
					{
						type: 8,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 3
					},
					{
						type: 10,
						a: 5,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 8.85,
				clues: [
					{
						type: 12,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 3,
						b: 4,
						rotation: -1
					},
					{
						type: 2,
						a: 3,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.88,
				clues: [
					{
						type: 9,
						a: 1,
						b: 5,
						rotation: -1
					},
					{
						type: 11,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 8,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 0
					}
				]
			},
			{
				rating: 9.25,
				clues: [
					{
						type: 22,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 5,
						b: 0,
						rotation: -1
					},
					{
						type: 2,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 0
					}
				]
			},
			{
				rating: 9.43,
				clues: [
					{
						type: 8,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 17,
						a: 4,
						b: 5,
						rotation: -1
					},
					{
						type: 6,
						a: 1,
						b: -1,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "7355",
		rating: 10,
		traps: [
			{
				cell: 0,
				symbol: 2
			},
			{
				cell: 20,
				symbol: 2
			},
			{
				cell: 17,
				symbol: 1
			},
			{
				cell: 24,
				symbol: 1
			},
			{
				cell: 14,
				symbol: 1
			}
		],
		solution: [
			{
				x: 0,
				y: 0,
				rotation: 2
			},
			{
				x: 1,
				y: 1,
				rotation: 2
			},
			{
				x: 3,
				y: 3,
				rotation: 0
			},
			{
				x: 0,
				y: 1,
				rotation: 1
			},
			{
				x: 0,
				y: 3,
				rotation: 3
			},
			{
				x: 3,
				y: 0,
				rotation: 1
			}
		],
		experts: [
			{
				rating: 6.76,
				clues: [
					{
						type: 22,
						a: 22,
						b: -1,
						rotation: -1
					},
					{
						type: 17,
						a: 4,
						b: 1,
						rotation: -1
					},
					{
						type: 9,
						a: 0,
						b: 5,
						rotation: -1
					},
					{
						type: 12,
						a: 3,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 6.93,
				clues: [
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 0,
						b: 2,
						rotation: -1
					},
					{
						type: 22,
						a: 13,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 0,
						b: -1,
						rotation: 2
					}
				]
			},
			{
				rating: 6.94,
				clues: [
					{
						type: 22,
						a: 22,
						b: -1,
						rotation: -1
					},
					{
						type: 3,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 9,
						a: 0,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 7.34,
				clues: [
					{
						type: 4,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 3,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 2,
						b: 3,
						rotation: -1
					},
					{
						type: 8,
						a: 4,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.87,
				clues: [
					{
						type: 16,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 9,
						a: 0,
						b: 5,
						rotation: -1
					},
					{
						type: 22,
						a: 13,
						b: -1,
						rotation: -1
					},
					{
						type: 15,
						a: 4,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 8.28,
				clues: [
					{
						type: 10,
						a: 5,
						b: 3,
						rotation: -1
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 2,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.51,
				clues: [
					{
						type: 20,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 4,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 3,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 13,
						a: 0,
						b: 4,
						rotation: -1
					}
				]
			},
			{
				rating: 8.65,
				clues: [
					{
						type: 17,
						a: 1,
						b: 2,
						rotation: -1
					},
					{
						type: 5,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 21,
						a: 1,
						b: 0,
						rotation: -1
					},
					{
						type: 3,
						a: 1,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9,
				clues: [
					{
						type: 1,
						a: 0,
						b: -1,
						rotation: 2
					},
					{
						type: 17,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 9,
						a: 0,
						b: 3,
						rotation: -1
					},
					{
						type: 20,
						a: 2,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 9.66,
				clues: [
					{
						type: 9,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 16,
						a: 1,
						b: 4,
						rotation: -1
					},
					{
						type: 22,
						a: 13,
						b: -1,
						rotation: -1
					},
					{
						type: 2,
						a: 4,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 10.62,
				clues: [
					{
						type: 20,
						a: 2,
						b: 0,
						rotation: -1
					},
					{
						type: 4,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 12,
						a: 4,
						b: 3,
						rotation: -1
					},
					{
						type: 19,
						a: 4,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 11.79,
				clues: [
					{
						type: 14,
						a: 4,
						b: 3,
						rotation: -1
					},
					{
						type: 16,
						a: 2,
						b: 3,
						rotation: -1
					},
					{
						type: 4,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 2,
						b: 4,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "7357",
		rating: 10.03,
		traps: [
			{
				cell: 20,
				symbol: 2
			},
			{
				cell: 11,
				symbol: 1
			},
			{
				cell: 14,
				symbol: 1
			},
			{
				cell: 22,
				symbol: 1
			},
			{
				cell: 18,
				symbol: 2
			}
		],
		solution: [
			{
				x: 0,
				y: 2,
				rotation: 1
			},
			{
				x: 1,
				y: 1,
				rotation: 3
			},
			{
				x: 1,
				y: 3,
				rotation: 0
			},
			{
				x: 3,
				y: 2,
				rotation: 3
			},
			{
				x: 3,
				y: 0,
				rotation: 2
			},
			{
				x: 0,
				y: 0,
				rotation: 2
			}
		],
		experts: [
			{
				rating: 6.2,
				clues: [
					{
						type: 22,
						a: 7,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 3,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 6.66,
				clues: [
					{
						type: 22,
						a: 23,
						b: -1,
						rotation: -1
					},
					{
						type: 9,
						a: 0,
						b: 2,
						rotation: -1
					},
					{
						type: 3,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 18,
						a: 5,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 7.01,
				clues: [
					{
						type: 7,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 15,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 1,
						a: 2,
						b: -1,
						rotation: 0
					},
					{
						type: 2,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.4,
				clues: [
					{
						type: 7,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 12,
						a: 1,
						b: 4,
						rotation: -1
					},
					{
						type: 3,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 3,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 7.83,
				clues: [
					{
						type: 17,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 2,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 7,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 7,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.21,
				clues: [
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 2
					},
					{
						type: 16,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 9,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 21,
						a: 3,
						b: 4,
						rotation: -1
					}
				]
			},
			{
				rating: 8.24,
				clues: [
					{
						type: 7,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 18,
						a: 1,
						b: 2,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 2
					}
				]
			},
			{
				rating: 8.53,
				clues: [
					{
						type: 22,
						a: 7,
						b: -1,
						rotation: -1
					},
					{
						type: 6,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 2
					},
					{
						type: 18,
						a: 5,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.58,
				clues: [
					{
						type: 2,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 18,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 14,
						a: 1,
						b: 4,
						rotation: -1
					}
				]
			},
			{
				rating: 9.78,
				clues: [
					{
						type: 22,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 2,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 17,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 12,
						a: 1,
						b: 4,
						rotation: -1
					}
				]
			},
			{
				rating: 10.11,
				clues: [
					{
						type: 12,
						a: 0,
						b: 2,
						rotation: -1
					},
					{
						type: 21,
						a: 2,
						b: 1,
						rotation: -1
					},
					{
						type: 8,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 5,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 10.84,
				clues: [
					{
						type: 12,
						a: 0,
						b: 1,
						rotation: -1
					},
					{
						type: 21,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 16,
						a: 1,
						b: 2,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "7375",
		rating: 10.21,
		traps: [
			{
				cell: 20,
				symbol: 2
			},
			{
				cell: 17,
				symbol: 1
			},
			{
				cell: 14,
				symbol: 1
			},
			{
				cell: 2,
				symbol: 1
			},
			{
				cell: 18,
				symbol: 2
			}
		],
		solution: [
			{
				x: 0,
				y: 4,
				rotation: 2
			},
			{
				x: 0,
				y: 0,
				rotation: 1
			},
			{
				x: 0,
				y: 2,
				rotation: 0
			},
			{
				x: 2,
				y: 1,
				rotation: 1
			},
			{
				x: 3,
				y: 3,
				rotation: 0
			},
			{
				x: 3,
				y: 0,
				rotation: 1
			}
		],
		experts: [
			{
				rating: 5.97,
				clues: [
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 1
					},
					{
						type: 5,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 14,
						a: 4,
						b: 5,
						rotation: -1
					},
					{
						type: 22,
						a: 6,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 6.08,
				clues: [
					{
						type: 22,
						a: 6,
						b: -1,
						rotation: -1
					},
					{
						type: 6,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 1
					},
					{
						type: 11,
						a: 4,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 6.47,
				clues: [
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 1
					},
					{
						type: 18,
						a: 4,
						b: 0,
						rotation: -1
					},
					{
						type: 15,
						a: 4,
						b: 1,
						rotation: -1
					},
					{
						type: 22,
						a: 6,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.17,
				clues: [
					{
						type: 11,
						a: 4,
						b: 5,
						rotation: -1
					},
					{
						type: 10,
						a: 5,
						b: 0,
						rotation: -1
					},
					{
						type: 22,
						a: 6,
						b: -1,
						rotation: -1
					},
					{
						type: 18,
						a: 4,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 7.93,
				clues: [
					{
						type: 21,
						a: 0,
						b: 5,
						rotation: -1
					},
					{
						type: 15,
						a: 4,
						b: 0,
						rotation: -1
					},
					{
						type: 7,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 2,
						b: -1,
						rotation: 0
					}
				]
			},
			{
				rating: 8.31,
				clues: [
					{
						type: 11,
						a: 4,
						b: 5,
						rotation: -1
					},
					{
						type: 5,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 4,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.39,
				clues: [
					{
						type: 10,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 6,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 4,
						b: 1,
						rotation: -1
					},
					{
						type: 1,
						a: 2,
						b: -1,
						rotation: 0
					}
				]
			},
			{
				rating: 8.47,
				clues: [
					{
						type: 1,
						a: 3,
						b: -1,
						rotation: 1
					},
					{
						type: 6,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 19,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.84,
				clues: [
					{
						type: 5,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 2,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 15,
						a: 1,
						b: 5,
						rotation: -1
					},
					{
						type: 11,
						a: 4,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 8.95,
				clues: [
					{
						type: 11,
						a: 4,
						b: 5,
						rotation: -1
					},
					{
						type: 9,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 5,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 4,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.15,
				clues: [
					{
						type: 21,
						a: 0,
						b: 1,
						rotation: -1
					},
					{
						type: 8,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 16,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 11,
						a: 4,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 9.72,
				clues: [
					{
						type: 19,
						a: 0,
						b: 2,
						rotation: -1
					},
					{
						type: 2,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 19,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "7533",
		rating: 10.59,
		traps: [
			{
				cell: 23,
				symbol: 1
			},
			{
				cell: 1,
				symbol: 2
			},
			{
				cell: 4,
				symbol: 2
			},
			{
				cell: 14,
				symbol: 2
			},
			{
				cell: 20,
				symbol: 1
			}
		],
		solution: [
			{
				x: 2,
				y: 0,
				rotation: 0
			},
			{
				x: 0,
				y: 3,
				rotation: 3
			},
			{
				x: 0,
				y: 0,
				rotation: 0
			},
			{
				x: 3,
				y: 2,
				rotation: 1
			},
			{
				x: 3,
				y: 1,
				rotation: 2
			},
			{
				x: 0,
				y: 2,
				rotation: 2
			}
		],
		experts: [
			{
				rating: 6.8,
				clues: [
					{
						type: 1,
						a: 3,
						b: -1,
						rotation: 1
					},
					{
						type: 22,
						a: 10,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 17,
						a: 2,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 6.99,
				clues: [
					{
						type: 22,
						a: 24,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 3
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 5,
						b: 4,
						rotation: -1
					}
				]
			},
			{
				rating: 7.79,
				clues: [
					{
						type: 11,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 13,
						a: 1,
						b: 4,
						rotation: -1
					},
					{
						type: 21,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 6,
						a: 1,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.01,
				clues: [
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 2
					},
					{
						type: 11,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 8,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 21,
						a: 3,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 8.03,
				clues: [
					{
						type: 15,
						a: 5,
						b: 3,
						rotation: -1
					},
					{
						type: 16,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 11,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 21,
						a: 3,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 8.08,
				clues: [
					{
						type: 20,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 24,
						b: -1,
						rotation: -1
					},
					{
						type: 9,
						a: 2,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 8.16,
				clues: [
					{
						type: 11,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 17,
						a: 0,
						b: 3,
						rotation: -1
					},
					{
						type: 12,
						a: 1,
						b: 3,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 2
					}
				]
			},
			{
				rating: 8.22,
				clues: [
					{
						type: 8,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 10,
						b: -1,
						rotation: -1
					},
					{
						type: 19,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 10,
						a: 0,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 9,
				clues: [
					{
						type: 20,
						a: 4,
						b: 5,
						rotation: -1
					},
					{
						type: 16,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 11,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 9,
						a: 5,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 9.45,
				clues: [
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 14,
						a: 4,
						b: 3,
						rotation: -1
					},
					{
						type: 21,
						a: 5,
						b: 0,
						rotation: -1
					},
					{
						type: 11,
						a: 5,
						b: 4,
						rotation: -1
					}
				]
			},
			{
				rating: 9.88,
				clues: [
					{
						type: 10,
						a: 5,
						b: 0,
						rotation: -1
					},
					{
						type: 6,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 15,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 2
					}
				]
			},
			{
				rating: 10.06,
				clues: [
					{
						type: 17,
						a: 2,
						b: 3,
						rotation: -1
					},
					{
						type: 10,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 11,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 6,
						a: 2,
						b: -1,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "7535",
		rating: 10.64,
		traps: [
			{
				cell: 15,
				symbol: 2
			},
			{
				cell: 11,
				symbol: 1
			},
			{
				cell: 22,
				symbol: 1
			},
			{
				cell: 16,
				symbol: 2
			},
			{
				cell: 12,
				symbol: 1
			}
		],
		solution: [
			{
				x: 0,
				y: 1,
				rotation: 1
			},
			{
				x: 0,
				y: 0,
				rotation: 2
			},
			{
				x: 3,
				y: 0,
				rotation: 1
			},
			{
				x: 0,
				y: 3,
				rotation: 0
			},
			{
				x: 3,
				y: 2,
				rotation: 2
			},
			{
				x: 2,
				y: 2,
				rotation: 3
			}
		],
		experts: [
			{
				rating: 6.22,
				clues: [
					{
						type: 5,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 3
					},
					{
						type: 10,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 13,
						a: 3,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 7.55,
				clues: [
					{
						type: 22,
						a: 7,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 12,
						a: 0,
						b: 1,
						rotation: -1
					},
					{
						type: 20,
						a: 2,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.57,
				clues: [
					{
						type: 19,
						a: 1,
						b: 2,
						rotation: -1
					},
					{
						type: 22,
						a: 24,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 9,
						a: 1,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 7.82,
				clues: [
					{
						type: 11,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 20,
						a: 4,
						b: 0,
						rotation: -1
					},
					{
						type: 19,
						a: 3,
						b: 4,
						rotation: -1
					},
					{
						type: 15,
						a: 1,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 8.01,
				clues: [
					{
						type: 21,
						a: 3,
						b: 1,
						rotation: -1
					},
					{
						type: 6,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 10,
						a: 0,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 8.24,
				clues: [
					{
						type: 11,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 14,
						a: 5,
						b: 3,
						rotation: -1
					},
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 2
					},
					{
						type: 20,
						a: 2,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 8.62,
				clues: [
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 2
					},
					{
						type: 13,
						a: 4,
						b: 2,
						rotation: -1
					},
					{
						type: 11,
						a: 5,
						b: 2,
						rotation: -1
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.67,
				clues: [
					{
						type: 9,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 22,
						a: 7,
						b: -1,
						rotation: -1
					},
					{
						type: 7,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 15,
						a: 4,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 8.71,
				clues: [
					{
						type: 20,
						a: 2,
						b: 3,
						rotation: -1
					},
					{
						type: 14,
						a: 1,
						b: 3,
						rotation: -1
					},
					{
						type: 18,
						a: 4,
						b: 3,
						rotation: -1
					},
					{
						type: 2,
						a: 1,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.9,
				clues: [
					{
						type: 1,
						a: 0,
						b: -1,
						rotation: 1
					},
					{
						type: 16,
						a: 4,
						b: 5,
						rotation: -1
					},
					{
						type: 8,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 21,
						a: 4,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 8.95,
				clues: [
					{
						type: 13,
						a: 3,
						b: 2,
						rotation: -1
					},
					{
						type: 16,
						a: 5,
						b: 0,
						rotation: -1
					},
					{
						type: 1,
						a: 3,
						b: -1,
						rotation: 0
					},
					{
						type: 22,
						a: 2,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 11.66,
				clues: [
					{
						type: 16,
						a: 2,
						b: 0,
						rotation: -1
					},
					{
						type: 2,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 12,
						a: 0,
						b: 3,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "7537",
		rating: 10.67,
		traps: [
			{
				cell: 14,
				symbol: 2
			},
			{
				cell: 4,
				symbol: 1
			},
			{
				cell: 10,
				symbol: 1
			},
			{
				cell: 22,
				symbol: 1
			},
			{
				cell: 6,
				symbol: 2
			}
		],
		solution: [
			{
				x: 4,
				y: 2,
				rotation: 3
			},
			{
				x: 2,
				y: 0,
				rotation: 1
			},
			{
				x: 2,
				y: 3,
				rotation: 1
			},
			{
				x: 0,
				y: 0,
				rotation: 1
			},
			{
				x: 0,
				y: 3,
				rotation: 0
			},
			{
				x: 2,
				y: 1,
				rotation: 0
			}
		],
		experts: [
			{
				rating: 6.58,
				clues: [
					{
						type: 22,
						a: 16,
						b: -1,
						rotation: -1
					},
					{
						type: 15,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 4,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 3,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 6.59,
				clues: [
					{
						type: 11,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 1
					},
					{
						type: 8,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 16,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.57,
				clues: [
					{
						type: 11,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 17,
						a: 4,
						b: 1,
						rotation: -1
					},
					{
						type: 8,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 11,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.14,
				clues: [
					{
						type: 22,
						a: 11,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 9,
						a: 5,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 9.5,
				clues: [
					{
						type: 21,
						a: 2,
						b: 1,
						rotation: -1
					},
					{
						type: 22,
						a: 11,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 15,
						a: 4,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.57,
				clues: [
					{
						type: 20,
						a: 0,
						b: 2,
						rotation: -1
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 2,
						a: 3,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.76,
				clues: [
					{
						type: 21,
						a: 2,
						b: 3,
						rotation: -1
					},
					{
						type: 22,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 18,
						a: 0,
						b: 4,
						rotation: -1
					},
					{
						type: 6,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.81,
				clues: [
					{
						type: 11,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 12,
						a: 5,
						b: 1,
						rotation: -1
					},
					{
						type: 10,
						a: 1,
						b: 2,
						rotation: -1
					},
					{
						type: 8,
						a: 1,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.81,
				clues: [
					{
						type: 1,
						a: 0,
						b: -1,
						rotation: 3
					},
					{
						type: 19,
						a: 2,
						b: 3,
						rotation: -1
					},
					{
						type: 2,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 6,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.82,
				clues: [
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 6,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 12,
						a: 3,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 10.13,
				clues: [
					{
						type: 4,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 1
					}
				]
			},
			{
				rating: 10.82,
				clues: [
					{
						type: 17,
						a: 5,
						b: 0,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 7,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 21,
						a: 4,
						b: 5,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "7553",
		rating: 10.79,
		traps: [
			{
				cell: 7,
				symbol: 1
			},
			{
				cell: 13,
				symbol: 1
			},
			{
				cell: 0,
				symbol: 1
			},
			{
				cell: 10,
				symbol: 1
			},
			{
				cell: 6,
				symbol: 2
			}
		],
		solution: [
			{
				x: 4,
				y: 1,
				rotation: 3
			},
			{
				x: 3,
				y: 2,
				rotation: 0
			},
			{
				x: 0,
				y: 2,
				rotation: 2
			},
			{
				x: 0,
				y: 0,
				rotation: 2
			},
			{
				x: 1,
				y: 3,
				rotation: 3
			},
			{
				x: 2,
				y: 0,
				rotation: 2
			}
		],
		experts: [
			{
				rating: 6.32,
				clues: [
					{
						type: 22,
						a: 12,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 14,
						a: 1,
						b: 0,
						rotation: -1
					},
					{
						type: 8,
						a: 1,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.37,
				clues: [
					{
						type: 9,
						a: 5,
						b: 0,
						rotation: -1
					},
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 0
					},
					{
						type: 8,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 2,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 8.14,
				clues: [
					{
						type: 22,
						a: 20,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 10,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 21,
						a: 1,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 8.32,
				clues: [
					{
						type: 9,
						a: 4,
						b: 1,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 3
					},
					{
						type: 21,
						a: 4,
						b: 3,
						rotation: -1
					},
					{
						type: 11,
						a: 2,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 8.54,
				clues: [
					{
						type: 22,
						a: 12,
						b: -1,
						rotation: -1
					},
					{
						type: 17,
						a: 5,
						b: 0,
						rotation: -1
					},
					{
						type: 9,
						a: 1,
						b: 0,
						rotation: -1
					},
					{
						type: 21,
						a: 2,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 8.58,
				clues: [
					{
						type: 21,
						a: 1,
						b: 5,
						rotation: -1
					},
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 0
					},
					{
						type: 22,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.66,
				clues: [
					{
						type: 22,
						a: 12,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 0,
						b: -1,
						rotation: 3
					},
					{
						type: 6,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 5,
						b: 4,
						rotation: -1
					}
				]
			},
			{
				rating: 8.82,
				clues: [
					{
						type: 11,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 7,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 13,
						a: 3,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 9.28,
				clues: [
					{
						type: 21,
						a: 1,
						b: 3,
						rotation: -1
					},
					{
						type: 16,
						a: 0,
						b: 4,
						rotation: -1
					},
					{
						type: 6,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 4,
						b: -1,
						rotation: 3
					}
				]
			},
			{
				rating: 10.31,
				clues: [
					{
						type: 7,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 2,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 21,
						a: 2,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 10.38,
				clues: [
					{
						type: 8,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 20,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 2,
						a: 5,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 10.8,
				clues: [
					{
						type: 21,
						a: 1,
						b: 3,
						rotation: -1
					},
					{
						type: 12,
						a: 4,
						b: 0,
						rotation: -1
					},
					{
						type: 2,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 5,
						b: -1,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "7573",
		rating: 10.96,
		traps: [
			{
				cell: 22,
				symbol: 2
			},
			{
				cell: 17,
				symbol: 1
			},
			{
				cell: 2,
				symbol: 1
			},
			{
				cell: 8,
				symbol: 2
			},
			{
				cell: 6,
				symbol: 2
			}
		],
		solution: [
			{
				x: 2,
				y: 4,
				rotation: 2
			},
			{
				x: 2,
				y: 2,
				rotation: 3
			},
			{
				x: 0,
				y: 0,
				rotation: 1
			},
			{
				x: 2,
				y: 0,
				rotation: 2
			},
			{
				x: 1,
				y: 1,
				rotation: 3
			},
			{
				x: 0,
				y: 2,
				rotation: 1
			}
		],
		experts: [
			{
				rating: 7.66,
				clues: [
					{
						type: 4,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 2,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 1,
						b: 3,
						rotation: -1
					},
					{
						type: 22,
						a: 13,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 7.78,
				clues: [
					{
						type: 1,
						a: 0,
						b: -1,
						rotation: 2
					},
					{
						type: 16,
						a: 3,
						b: 4,
						rotation: -1
					},
					{
						type: 10,
						a: 0,
						b: 3,
						rotation: -1
					},
					{
						type: 22,
						a: 13,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8,
				clues: [
					{
						type: 15,
						a: 5,
						b: 3,
						rotation: -1
					},
					{
						type: 22,
						a: 9,
						b: -1,
						rotation: -1
					},
					{
						type: 5,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 1,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 8.14,
				clues: [
					{
						type: 13,
						a: 0,
						b: 1,
						rotation: -1
					},
					{
						type: 7,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 1
					},
					{
						type: 22,
						a: 20,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.32,
				clues: [
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 1
					},
					{
						type: 18,
						a: 1,
						b: 0,
						rotation: -1
					},
					{
						type: 9,
						a: 5,
						b: 4,
						rotation: -1
					},
					{
						type: 3,
						a: 4,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.41,
				clues: [
					{
						type: 13,
						a: 1,
						b: 3,
						rotation: -1
					},
					{
						type: 10,
						a: 0,
						b: 3,
						rotation: -1
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 1,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 8.42,
				clues: [
					{
						type: 13,
						a: 2,
						b: 1,
						rotation: -1
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 22,
						a: 13,
						b: -1,
						rotation: -1
					},
					{
						type: 10,
						a: 2,
						b: 0,
						rotation: -1
					}
				]
			},
			{
				rating: 9.54,
				clues: [
					{
						type: 13,
						a: 0,
						b: 3,
						rotation: -1
					},
					{
						type: 10,
						a: 0,
						b: 3,
						rotation: -1
					},
					{
						type: 3,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 16,
						a: 4,
						b: 5,
						rotation: -1
					}
				]
			},
			{
				rating: 9.97,
				clues: [
					{
						type: 19,
						a: 0,
						b: 2,
						rotation: -1
					},
					{
						type: 9,
						a: 4,
						b: 1,
						rotation: -1
					},
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 3
					},
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 10.14,
				clues: [
					{
						type: 4,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 0,
						b: 5,
						rotation: -1
					},
					{
						type: 1,
						a: 3,
						b: -1,
						rotation: 2
					},
					{
						type: 9,
						a: 5,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 11.18,
				clues: [
					{
						type: 10,
						a: 2,
						b: 0,
						rotation: -1
					},
					{
						type: 4,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 21,
						a: 0,
						b: 1,
						rotation: -1
					},
					{
						type: 2,
						a: 5,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 11.6,
				clues: [
					{
						type: 8,
						a: 0,
						b: -1,
						rotation: -1
					},
					{
						type: 12,
						a: 2,
						b: 3,
						rotation: -1
					},
					{
						type: 18,
						a: 3,
						b: 5,
						rotation: -1
					},
					{
						type: 4,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			}
		]
	},
	{
		card: "7735",
		rating: 11.16,
		traps: [
			{
				cell: 2,
				symbol: 2
			},
			{
				cell: 4,
				symbol: 1
			},
			{
				cell: 22,
				symbol: 1
			},
			{
				cell: 8,
				symbol: 2
			},
			{
				cell: 16,
				symbol: 2
			}
		],
		solution: [
			{
				x: 0,
				y: 0,
				rotation: 0
			},
			{
				x: 2,
				y: 3,
				rotation: 3
			},
			{
				x: 0,
				y: 3,
				rotation: 0
			},
			{
				x: 3,
				y: 0,
				rotation: 3
			},
			{
				x: 0,
				y: 1,
				rotation: 3
			},
			{
				x: 2,
				y: 1,
				rotation: 1
			}
		],
		experts: [
			{
				rating: 7.35,
				clues: [
					{
						type: 20,
						a: 3,
						b: 0,
						rotation: -1
					},
					{
						type: 6,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 2,
						b: -1,
						rotation: 0
					},
					{
						type: 11,
						a: 0,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 8.32,
				clues: [
					{
						type: 21,
						a: 2,
						b: 4,
						rotation: -1
					},
					{
						type: 14,
						a: 0,
						b: 4,
						rotation: -1
					},
					{
						type: 16,
						a: 0,
						b: 4,
						rotation: -1
					},
					{
						type: 3,
						a: 5,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.76,
				clues: [
					{
						type: 15,
						a: 4,
						b: 3,
						rotation: -1
					},
					{
						type: 11,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 9,
						a: 0,
						b: 5,
						rotation: -1
					},
					{
						type: 6,
						a: 0,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 8.8,
				clues: [
					{
						type: 11,
						a: 2,
						b: 5,
						rotation: -1
					},
					{
						type: 1,
						a: 3,
						b: -1,
						rotation: 3
					},
					{
						type: 8,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 20,
						a: 5,
						b: 2,
						rotation: -1
					}
				]
			},
			{
				rating: 8.96,
				clues: [
					{
						type: 22,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 12,
						a: 0,
						b: 3,
						rotation: -1
					},
					{
						type: 3,
						a: 5,
						b: -1,
						rotation: -1
					},
					{
						type: 11,
						a: 0,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 9.11,
				clues: [
					{
						type: 14,
						a: 2,
						b: 0,
						rotation: -1
					},
					{
						type: 10,
						a: 4,
						b: 3,
						rotation: -1
					},
					{
						type: 8,
						a: 2,
						b: -1,
						rotation: -1
					},
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 1
					}
				]
			},
			{
				rating: 9.21,
				clues: [
					{
						type: 1,
						a: 5,
						b: -1,
						rotation: 1
					},
					{
						type: 4,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 2,
						a: 3,
						b: -1,
						rotation: -1
					},
					{
						type: 21,
						a: 1,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 9.26,
				clues: [
					{
						type: 2,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 18,
						a: 3,
						b: 2,
						rotation: -1
					},
					{
						type: 9,
						a: 4,
						b: 5,
						rotation: -1
					},
					{
						type: 1,
						a: 1,
						b: -1,
						rotation: 3
					}
				]
			},
			{
				rating: 9.56,
				clues: [
					{
						type: 20,
						a: 3,
						b: 2,
						rotation: -1
					},
					{
						type: 10,
						a: 2,
						b: 0,
						rotation: -1
					},
					{
						type: 2,
						a: 1,
						b: -1,
						rotation: -1
					},
					{
						type: 7,
						a: 4,
						b: -1,
						rotation: -1
					}
				]
			},
			{
				rating: 10.16,
				clues: [
					{
						type: 16,
						a: 0,
						b: 2,
						rotation: -1
					},
					{
						type: 2,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 14,
						a: 2,
						b: 0,
						rotation: -1
					},
					{
						type: 9,
						a: 2,
						b: 1,
						rotation: -1
					}
				]
			},
			{
				rating: 10.32,
				clues: [
					{
						type: 9,
						a: 0,
						b: 4,
						rotation: -1
					},
					{
						type: 11,
						a: 0,
						b: 3,
						rotation: -1
					},
					{
						type: 4,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 17,
						a: 4,
						b: 3,
						rotation: -1
					}
				]
			},
			{
				rating: 10.38,
				clues: [
					{
						type: 11,
						a: 0,
						b: 3,
						rotation: -1
					},
					{
						type: 22,
						a: 17,
						b: -1,
						rotation: -1
					},
					{
						type: 2,
						a: 4,
						b: -1,
						rotation: -1
					},
					{
						type: 14,
						a: 1,
						b: 3,
						rotation: -1
					}
				]
			}
		]
	}
], b = {
	id: "archeologic",
	tier: "alpha",
	mechanics: ["deduction"],
	interactionTags: [],
	nameKey: "games.archeologic.name",
	descKey: "games.archeologic.desc",
	rulesKey: "games.archeologic.rules",
	icon: "🔍",
	iconImg: "games/archeologic.webp",
	minPlayers: 1,
	maxPlayers: 4,
	bestPlayers: [1, 2],
	accent: "#16768e",
	releasedAt: "2026-11-03T18:00:00+08:00",
	search: {
		py: "jing zhong jie archeologic",
		init: "jzj"
	},
	hotseat: "cover",
	rulesUrl: {
		en: "https://www.data.ludonaute.fr/Archeologic/RULES/EN_RULES_ARCHEOLOGIC_v2.pdf",
		zh: "https://www.data.ludonaute.fr/Archeologic/RULES/SCN_RULES_ARCHEOLOGIC.pdf"
	}
}, x = [
	"1",
	"E",
	"4",
	"C",
	"2",
	"A",
	"5",
	"D",
	"3",
	"B"
], S = [
	-1,
	-1,
	-1,
	0,
	4,
	2,
	3,
	5,
	1
], C = [
	1,
	1,
	2,
	2,
	2,
	3,
	3,
	3,
	3
], w = [
	[
		[
			0,
			0,
			0
		],
		[
			1,
			0,
			0
		],
		[
			2,
			0,
			2
		]
	],
	[
		[
			1,
			2,
			0
		],
		[
			0,
			2,
			0
		],
		[
			0,
			1,
			0
		],
		[
			0,
			0,
			1
		]
	],
	[
		[
			0,
			0,
			0
		],
		[
			1,
			0,
			2
		],
		[
			0,
			1,
			0
		],
		[
			1,
			1,
			1
		]
	],
	[
		[
			0,
			1,
			0
		],
		[
			1,
			1,
			0
		],
		[
			1,
			0,
			2
		],
		[
			2,
			1,
			1
		]
	],
	[
		[
			0,
			1,
			0
		],
		[
			0,
			0,
			2
		],
		[
			1,
			1,
			0
		]
	],
	[
		[
			2,
			0,
			1
		],
		[
			1,
			0,
			0
		],
		[
			1,
			1,
			0
		],
		[
			0,
			1,
			0
		]
	]
];
function T(e, t) {
	let n = w[e].map((e) => [...e]);
	for (let e = 0; e < t; e++) {
		n = n.map(([e, t, n]) => [
			-t,
			e,
			n
		]);
		let e = Math.min(...n.map(([e]) => e)), t = Math.min(...n.map(([, e]) => e));
		n = n.map(([n, r, i]) => [
			n - e,
			r - t,
			i
		]);
	}
	return n;
}
function E(e, t) {
	return T(e, t.rotation).map(([e, n, r]) => ({
		cell: (t.y + n) * 5 + t.x + e,
		symbol: r
	}));
}
function D(e, t, n) {
	if (T(t, n.rotation).some(([e, t]) => e + n.x >= 5 || t + n.y >= 5)) return !1;
	let r = new Set(e.flatMap((e, n) => e && n !== t ? E(n, e).map((e) => e.cell) : []));
	return E(t, n).every(({ cell: e }) => !r.has(e));
}
function O(e) {
	let t = Array(25).fill(-1), n = Array(25).fill(0);
	return e.forEach((e, r) => {
		if (e) for (let i of E(r, e)) t[i.cell] = r, n[i.cell] = i.symbol;
	}), {
		pieces: t,
		symbols: n
	};
}
function k(e) {
	let t = x[e];
	return /^\d$/.test(t) ? Array.from({ length: 5 }, (e, n) => (Number(t) - 1) * 5 + n) : Array.from({ length: 5 }, (e, n) => n * 5 + t.charCodeAt(0) - 65);
}
function A(e, t, n, r) {
	let i = k(n);
	return r === 0 ? {
		number: i.filter((t) => e[t] < 0).length,
		symbols: []
	} : r === 1 ? {
		number: new Set(i.map((t) => e[t]).filter((e) => e >= 0)).size,
		symbols: []
	} : {
		number: null,
		symbols: i.filter((n) => r === 2 ? t[n] > 0 : e[n] === S[r]).map((e) => t[e]).sort()
	};
}
var j = (e) => e.number === null ? e.symbols.join("") : `n${e.number}`;
function M(e, t) {
	let n = (t - e + 10) % 10;
	return n === 1 ? 0 : n === 2 ? 1 : 2;
}
var N = (e, t, n) => JSON.stringify(E(e, t).sort((e, t) => e.cell - t.cell)) === JSON.stringify(E(e, n).sort((e, t) => e.cell - t.cell)), P = (e) => Array.from({ length: 100 }, (e, t) => ({
	x: t % 5,
	y: Math.floor(t / 5) % 5,
	rotation: Math.floor(t / 25)
})).filter((t) => D([
	,
	,
	,
	,
	,
	,
].fill(null), e, t));
function F(e, t) {
	if (e.type === 22) return !t.some((t, n) => t && E(n, t).some((t) => t.cell === e.a));
	let n = t[e.a];
	if (!n) return !0;
	let r = E(e.a, n).map(({ cell: e }) => [e % 5, Math.floor(e / 5)]), i = (e) => [
		Math.min(...e.map(([e]) => e)),
		Math.max(...e.map(([e]) => e)),
		Math.min(...e.map(([, e]) => e)),
		Math.max(...e.map(([, e]) => e))
	], [a, o, s, c] = i(r), l = a === 0 || o === 4 || s === 0 || c === 4;
	if (e.type === 1) return n.rotation === e.rotation;
	if (e.type === 2) return l;
	if (e.type === 3) return !l;
	if (e.type === 4) return a === 0 || o === 4;
	if (e.type === 5) return a !== 0 && o !== 4;
	if (e.type === 6) return s === 0 || c === 4;
	if (e.type === 7) return s !== 0 && c !== 4;
	if (e.type === 8) return r.some(([e, t]) => (e === 0 || e === 4) && (t === 0 || t === 4));
	let u = t[e.b];
	if (!u) return !0;
	let d = E(e.b, u).map(({ cell: e }) => [e % 5, Math.floor(e / 5)]), [f, p, m, h] = i(d), g = r.some(([e, t]) => d.some(([n, r]) => Math.abs(e - n) + Math.abs(t - r) === 1));
	switch (e.type) {
		case 9: return g;
		case 10: return !g;
		case 11: return !g && r.some(([e, t]) => d.some(([n, r]) => Math.abs(e - n) === 1 && Math.abs(t - r) === 1));
		case 12: return r.some(([, e]) => d.some(([, t]) => e === t));
		case 13: return !r.some(([, e]) => d.some(([, t]) => e === t));
		case 14: return r.some(([e]) => d.some(([t]) => e === t));
		case 15: return !r.some(([e]) => d.some(([t]) => e === t));
		case 16: return o > p;
		case 17: return a < f;
		case 18: return s < m;
		case 19: return c > h;
		case 20: return a > p;
		case 21: return s > h;
		default: return !1;
	}
}
//#endregion
//#region src/games/archeologic/schema.ts
var I = t.int().min(0).max(9), L = t.int().min(0).max(5), R = t.object({
	x: t.int().min(0).max(4),
	y: t.int().min(0).max(4),
	rotation: t.int().min(0).max(3)
}), z = t.object({
	card: t.int().min(-1).max(27).default(-1),
	mode: t.enum(["normal", "expert"]).default("normal"),
	clues: t.union([
		t.literal(3),
		t.literal(4),
		t.literal(5)
	]).default(3),
	expert: t.int().min(-1).max(11).default(-1),
	verification: t.enum(["app", "strict"]).default("app"),
	soloAxis: I.default(0)
}).default({
	card: -1,
	mode: "normal",
	clues: 3,
	expert: -1,
	verification: "app",
	soloAxis: 0
}), B = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("place"),
		piece: L,
		placement: R.nullable()
	}),
	t.object({
		type: t.literal("query"),
		axis: I,
		question: t.int().min(0).max(8)
	}),
	t.object({ type: t.literal("declare") }),
	t.object({ type: t.literal("check") }),
	t.object({ type: t.literal("withdraw") }),
	t.object({
		type: t.literal("note"),
		text: t.string().max(2e3)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), V = t.object({
	number: t.int().nonnegative().nullable(),
	symbols: t.array(t.int().min(0).max(2)).max(5)
}), H = t.object({
	type: t.int().min(1).max(22),
	a: t.int().min(0).max(24),
	b: t.int().min(-1).max(5),
	rotation: t.int().min(-1).max(3)
}), ee = t.object({
	axis: I,
	question: t.int().min(0).max(8),
	answer: V,
	time: t.int().nonnegative()
}), U = t.object({
	rid: t.string(),
	time: t.int().nonnegative(),
	mode: t.enum([
		"search",
		"check",
		"out"
	]),
	queries: t.int().nonnegative()
}), W = t.object({
	card: t.string(),
	mode: t.enum(["normal", "expert"]),
	expert: t.int(),
	verification: t.enum(["app", "strict"]),
	players: t.array(U).min(1).max(4),
	active: t.string(),
	phase: t.enum([
		"play",
		"observing",
		"done"
	]),
	clues: t.array(H),
	traps: t.array(t.object({
		cell: t.int().min(0).max(24),
		symbol: t.int().min(1).max(2)
	})),
	axis: I,
	last: t.object({
		rid: t.string(),
		axis: I,
		question: t.int().min(0).max(8)
	}).nullable(),
	winner: t.string().nullable(),
	solution: t.array(R).length(6).nullable(),
	thresholds: t.tuple([t.int(), t.int()])
}), te = t.object({
	draft: t.array(R.nullable()).length(6),
	history: t.array(ee),
	text: t.string().max(2e3),
	feedback: t.array(t.boolean()).length(6).nullable(),
	submitted: t.array(R).length(6).nullable()
}), G = () => ({ code: "games.archeologic.errorAction" });
function K(e) {
	let t = e.public.players.filter((e) => e.mode !== "out").sort((e, t) => e.time - t.time);
	t.length ? e.public.active = t[0].rid : (e.public.phase = "done", e.public.solution = structuredClone(e.solution));
}
function q(e, t, n) {
	let r = e.public.players.find((e) => e.rid === t);
	for (; n > 0;) r.time++, e.public.players.some((e) => e.rid !== t && e.mode !== "out" && e.time === r.time) || n--;
}
var J = {
	meta: b,
	saveCompatibility: { version: "1" },
	schemas: {
		action: B,
		config: z,
		publicView: W,
		privateView: te
	},
	setup(t, n, r) {
		let i = y[t.card < 0 ? e(r, 0, 28) : t.card], a = t.expert < 0 ? e(r, 1, 12) : t.expert, o = n.map((t, n) => ({
			rid: t,
			draw: e(r, n + 2, 1e6)
		})).sort((e, t) => e.draw - t.draw), s = t.mode === "expert" ? i.experts[a].rating : i.rating;
		return { state: {
			public: {
				card: i.card,
				mode: t.mode,
				expert: t.mode === "expert" ? a : -1,
				verification: t.verification,
				players: o.map(({ rid: e }, t) => ({
					rid: e,
					time: t,
					mode: "search",
					queries: 0
				})),
				active: o[0].rid,
				phase: "play",
				clues: t.mode === "expert" ? structuredClone(i.experts[a].clues) : [],
				traps: t.mode === "normal" ? i.traps.slice(0, n.length === 1 ? 3 : t.clues) : [],
				axis: n.length === 1 ? t.soloAxis : 0,
				last: null,
				winner: null,
				solution: null,
				thresholds: [Math.round(s * 1.3) + 10, Math.round(s * 2.8) + 10]
			},
			secrets: Object.fromEntries(n.map((e) => [e, {
				draft: [
					,
					,
					,
					,
					,
					,
				].fill(null),
				history: [],
				text: "",
				feedback: null,
				submitted: null
			}])),
			solution: structuredClone(i.solution),
			pending: null
		} };
	},
	reduce(e, t, n) {
		if (t.type === "tick") {
			if (n.by !== "$engine") return G();
			if (!e.pending) return { state: e };
			let t = structuredClone(e), r = t.pending, i = t.public.players.find((e) => e.rid === r.rid);
			return t.secrets[r.rid].history.push({
				...r,
				time: i.time
			}), t.public.players.length === 1 && (t.public.axis = (t.public.axis + r.answer.symbols.filter((e) => e > 0).length) % 10), t.public.phase = "play", t.pending = null, K(t), { state: t };
		}
		let r = e.public.players.find((e) => e.rid === n.by);
		if (!r || r.mode === "out" || e.public.phase === "done") return G();
		let i = structuredClone(e), a = i.secrets[n.by], o = i.public.players.find((e) => e.rid === n.by);
		if (t.type === "note") return a.text = t.text, { state: i };
		if (t.type === "place") return o.mode !== "search" || t.placement && !D(a.draft, t.piece, t.placement) ? G() : (a.draft[t.piece] = t.placement, a.feedback = null, { state: i });
		if (i.public.phase !== "play" || i.public.active !== n.by) return G();
		if (t.type === "withdraw") return o.mode = "out", K(i), { state: i };
		if (o.mode === "check") return t.type !== "check" || !a.submitted ? G() : (a.feedback = a.submitted.map((e, t) => N(t, e, i.solution[t])), a.feedback.every(Boolean) ? (i.public.winner = n.by, i.public.phase = "done", i.public.solution = structuredClone(i.solution)) : i.public.verification === "strict" ? (o.mode = "out", K(i)) : o.mode = "search", { state: i });
		if (t.type === "declare") return a.draft.every((e) => e !== null) ? (a.submitted = structuredClone(a.draft), o.mode = "check", q(i, n.by, 4), K(i), { state: i }) : { code: "games.archeologic.errorIncomplete" };
		if (t.type !== "query") return G();
		let s = O(i.solution), c = A(s.pieces, s.symbols, t.axis, t.question);
		return q(i, n.by, M(i.public.axis, t.axis) + [
			1,
			1,
			2,
			2,
			2,
			3,
			3,
			3,
			3
		][t.question]), o.queries++, i.public.axis = t.axis, i.public.last = {
			rid: n.by,
			axis: t.axis,
			question: t.question
		}, i.public.phase = "observing", i.pending = {
			rid: n.by,
			axis: t.axis,
			question: t.question,
			answer: c
		}, { state: i };
	},
	viewFor(e, t) {
		return {
			public: structuredClone(e.public),
			private: structuredClone(e.secrets[t] ?? {
				draft: [
					,
					,
					,
					,
					,
					,
				].fill(null),
				history: [],
				text: "",
				feedback: null,
				submitted: null
			})
		};
	},
	status(e) {
		let t = e.public;
		return t.phase === "done" ? {
			phase: "done",
			winner: t.winner ? [t.winner] : [],
			ranking: [...t.players].sort((e, n) => Number(n.rid === t.winner) - Number(e.rid === t.winner) || e.time - n.time).map((e) => e.rid),
			scores: Object.fromEntries(t.players.map((e) => [e.rid, e.time]))
		} : { phase: t.phase };
	},
	nextTickIn(e) {
		return e.pending ? 480 : null;
	}
};
//#endregion
//#region src/games/archeologic/art.tsx
function Y({ symbol: e, x: t = 0, y: n = 0, size: r = 24 }) {
	return /* @__PURE__ */ h("svg", {
		x: t,
		y: n,
		width: r,
		height: r,
		viewBox: "-15 -15 30 30",
		"aria-hidden": "true",
		children: e === 1 ? /* @__PURE__ */ h("path", {
			d: "M-4 4C-16-10 16-17 11 1C8 14-12 12-8-1C-6-8 7-7 5 1C4 7-3 6-2 0M-11 3l-2-6 6 1",
			fill: "none",
			stroke: "#aa318b",
			strokeWidth: "3",
			strokeLinecap: "round"
		}) : e === 2 ? /* @__PURE__ */ g("g", {
			fill: "none",
			stroke: "#e26e25",
			strokeWidth: "2.8",
			strokeLinejoin: "round",
			children: [/* @__PURE__ */ h("path", { d: "M-11-8H11L0 12ZM-4-12L4-3-3 3" }), /* @__PURE__ */ h("path", {
				d: "M-11-8H11L0 12Z",
				stroke: "#ffb96e",
				strokeWidth: "1"
			})]
		}) : /* @__PURE__ */ g("g", {
			fill: "#203e63",
			children: [/* @__PURE__ */ h("path", { d: "M-10-10H-3V-3H3V-10H10V-3H3V3H10V10H3V3H-3V10H-10V3H-3V-3H-10Z" }), /* @__PURE__ */ h("rect", {
				x: "-3",
				y: "-3",
				width: "6",
				height: "6",
				fill: "#d5eaf2"
			})]
		})
	});
}
function X({ piece: e, rotation: t = 0, unit: n = 50 }) {
	let r = T(e, t), i = new Set(r.map(([e, t]) => `${e},${t}`)), a = r.flatMap(([e, t]) => {
		let r = e * n, a = t * n;
		return [
			[
				0,
				-1,
				`M${r},${a}h${n}`
			],
			[
				1,
				0,
				`M${r + n},${a}v${n}`
			],
			[
				0,
				1,
				`M${r},${a + n}h${n}`
			],
			[
				-1,
				0,
				`M${r},${a}v${n}`
			]
		].filter(([n, r]) => !i.has(`${e + Number(n)},${t + Number(r)}`)).map(([, , e]) => e);
	}).join(" ");
	return /* @__PURE__ */ g("g", {
		className: "arc-building-art",
		children: [
			r.map(([e, t, r], i) => /* @__PURE__ */ g("g", {
				transform: `translate(${e * n} ${t * n})`,
				children: [
					/* @__PURE__ */ h("rect", {
						width: n,
						height: n,
						fill: "#b9dce9"
					}),
					/* @__PURE__ */ h("path", {
						d: `M4 4H${n - 4}V${n - 4}H4V10H${n - 10}V${n - 10}H10V16H${n - 16}`,
						fill: "none",
						stroke: "#7294ae",
						strokeWidth: "1"
					}),
					/* @__PURE__ */ h("path", {
						d: `M2 ${n - 2}V2H${n - 2}`,
						fill: "none",
						stroke: "#e4f6ff",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ h(Y, {
						symbol: r,
						x: n * .25,
						y: n * .25,
						size: n * .5
					})
				]
			}, i)),
			/* @__PURE__ */ h("path", {
				d: a,
				fill: "none",
				stroke: "#21354c",
				strokeWidth: "4",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ h("path", {
				d: a,
				fill: "none",
				stroke: "#e3f4ff",
				strokeWidth: "1",
				strokeLinejoin: "round"
			})
		]
	});
}
function Z({ piece: e, rotation: t = 0 }) {
	let n = T(e, t), r = Math.max(...n.map(([e]) => e)) + 1, i = Math.max(...n.map(([, e]) => e)) + 1;
	return /* @__PURE__ */ h("svg", {
		viewBox: `-5 -5 ${r * 50 + 10} ${i * 50 + 10}`,
		"aria-hidden": "true",
		children: /* @__PURE__ */ h(X, {
			piece: e,
			rotation: t
		})
	});
}
function ne({ axis: e, selected: t, disabled: n, onSelect: i }) {
	let a = r().replaceAll(":", ""), o = [
		"1",
		"E",
		"4",
		"C",
		"2",
		"A",
		"5",
		"D",
		"3",
		"B"
	];
	return /* @__PURE__ */ g("svg", {
		className: "arc-ring",
		viewBox: "0 0 240 240",
		"aria-label": "Archeoscope",
		children: [
			/* @__PURE__ */ h("defs", { children: /* @__PURE__ */ g("radialGradient", {
				id: a,
				children: [/* @__PURE__ */ h("stop", { stopColor: "#286078" }), /* @__PURE__ */ h("stop", {
					offset: "1",
					stopColor: "#102a40"
				})]
			}) }),
			/* @__PURE__ */ h("circle", {
				cx: "120",
				cy: "120",
				r: "98",
				fill: "#1b3047",
				stroke: "#b48955",
				strokeWidth: "8"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "120",
				cy: "120",
				r: "76",
				fill: `url(#${a})`,
				stroke: "#547b86",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ h("path", {
				className: "arc-viewfinder",
				d: "M113 48L120 33L127 48Z",
				transform: `rotate(${e * 36} 120 120)`,
				fill: "#f3ca85"
			}),
			/* @__PURE__ */ h("path", {
				d: "M66 120H174M120 66V174",
				stroke: "#77bccb",
				strokeWidth: ".5"
			}),
			/* @__PURE__ */ h("circle", {
				cx: "120",
				cy: "120",
				r: "43",
				fill: "none",
				stroke: "#6cc8da",
				strokeWidth: "1"
			}),
			o.map((e, r) => {
				let a = r * Math.PI / 5 - Math.PI / 2, o = 120 + 99 * Math.cos(a), s = 120 + 99 * Math.sin(a);
				return /* @__PURE__ */ g("g", {
					className: "arc-axis",
					"data-selected": t === r,
					role: "button",
					tabIndex: n ? -1 : 0,
					"aria-disabled": n,
					"aria-label": e,
					"aria-pressed": t === r,
					onClick: () => {
						n || i(r);
					},
					onKeyDown: (e) => {
						!n && (e.key === "Enter" || e.key === " ") && (e.preventDefault(), i(r));
					},
					children: [/* @__PURE__ */ h("circle", {
						cx: o,
						cy: s,
						r: "17"
					}), /* @__PURE__ */ h("text", {
						x: o,
						y: s + 6,
						textAnchor: "middle",
						children: e
					})]
				}, e);
			}),
			/* @__PURE__ */ h("text", {
				x: "120",
				y: "113",
				textAnchor: "middle",
				className: "arc-lens-label",
				children: "AXIS"
			}),
			/* @__PURE__ */ h("text", {
				x: "120",
				y: "145",
				textAnchor: "middle",
				className: "arc-lens-number",
				children: o[t]
			}),
			/* @__PURE__ */ h("path", {
				className: "arc-scan",
				d: "M77 120H163",
				stroke: "#acf4ff",
				strokeWidth: "3"
			})
		]
	});
}
//#endregion
//#region src/games/archeologic/board.tsx
function Q({ draft: e, traps: t = [], selected: n, feedback: r, disabled: i = !1, onCell: o, onPiece: s }) {
	let c = u(), [l, d] = a(null), f = O(e), p = !i && n ? Array.from({ length: 25 }, (e, t) => t).filter((t) => D(e, n.piece, {
		x: t % 5,
		y: Math.floor(t / 5),
		rotation: n.rotation
	})) : [], m = (e) => String.fromCharCode(65 + e % 5) + (Math.floor(e / 5) + 1);
	return /* @__PURE__ */ g("svg", {
		className: "arc-board",
		viewBox: "0 0 360 360",
		"aria-label": c("games.archeologic.review"),
		children: [
			/* @__PURE__ */ h("rect", {
				x: "4",
				y: "4",
				width: "352",
				height: "352",
				rx: "18",
				fill: "#182d42",
				stroke: "#9c784e",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ h("rect", {
				x: "33",
				y: "33",
				width: "294",
				height: "294",
				rx: "3",
				fill: "#0c2939",
				stroke: "#73a8b3",
				strokeWidth: "1"
			}),
			[
				0,
				1,
				2,
				3,
				4
			].map((e) => /* @__PURE__ */ g("g", {
				className: "arc-coordinate",
				children: [
					/* @__PURE__ */ h("text", {
						x: 80 + e * 50,
						y: "28",
						textAnchor: "middle",
						children: "ABCDE"[e]
					}),
					/* @__PURE__ */ h("text", {
						x: "22",
						y: 85 + e * 50,
						textAnchor: "middle",
						children: e + 1
					}),
					/* @__PURE__ */ h("text", {
						x: 80 + e * 50,
						y: "347",
						textAnchor: "middle",
						children: "ABCDE"[e]
					}),
					/* @__PURE__ */ h("text", {
						x: "340",
						y: 85 + e * 50,
						textAnchor: "middle",
						children: e + 1
					})
				]
			}, e)),
			Array.from({ length: 25 }, (e, t) => /* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("rect", {
				x: 55 + t % 5 * 50,
				y: 55 + Math.floor(t / 5) * 50,
				width: "50",
				height: "50",
				fill: "#14394a",
				stroke: "#396173",
				strokeWidth: ".7"
			}), /* @__PURE__ */ h("path", {
				d: `M${58 + t % 5 * 50} ${58 + Math.floor(t / 5) * 50}h8m-8 0v8`,
				fill: "none",
				stroke: "#517480",
				strokeWidth: ".7"
			})] }, t)),
			e.map((e, t) => e && /* @__PURE__ */ h("g", {
				className: "arc-map-piece",
				"data-selected": n?.piece === t,
				"data-feedback": r ? String(r[t]) : void 0,
				style: { transform: `translate(${55 + e.x * 50}px, ${55 + e.y * 50}px)` },
				children: /* @__PURE__ */ h(X, {
					piece: t,
					rotation: e.rotation
				})
			}, t)),
			t.map(({ cell: e, symbol: t }) => f.pieces[e] < 0 && /* @__PURE__ */ g("g", {
				opacity: ".9",
				children: [/* @__PURE__ */ h("circle", {
					cx: 80 + e % 5 * 50,
					cy: 80 + Math.floor(e / 5) * 50,
					r: "16",
					fill: "#f5e4c4"
				}), /* @__PURE__ */ h(Y, {
					symbol: t,
					x: 65 + e % 5 * 50,
					y: 65 + Math.floor(e / 5) * 50,
					size: 30
				})]
			}, e)),
			n && l !== null && p.includes(l) && /* @__PURE__ */ h("g", {
				opacity: ".5",
				pointerEvents: "none",
				transform: `translate(${55 + l % 5 * 50} ${55 + Math.floor(l / 5) * 50})`,
				children: /* @__PURE__ */ h(X, {
					piece: n.piece,
					rotation: n.rotation
				})
			}),
			Array.from({ length: 25 }, (e, t) => /* @__PURE__ */ g("g", { children: [p.includes(t) && /* @__PURE__ */ h("rect", {
				x: 58 + t % 5 * 50,
				y: 58 + Math.floor(t / 5) * 50,
				width: "44",
				height: "44",
				className: "arc-target",
				pointerEvents: "none",
				children: /* @__PURE__ */ h("animate", {
					attributeName: "stroke-dashoffset",
					from: "0",
					to: "-18",
					dur: ".85s",
					repeatCount: "indefinite"
				})
			}), /* @__PURE__ */ h("rect", {
				x: 55 + t % 5 * 50,
				y: 55 + Math.floor(t / 5) * 50,
				width: "50",
				height: "50",
				fill: "transparent",
				className: "arc-cell-hit",
				role: "button",
				"aria-label": c("games.archeologic.cell", { cell: m(t) }),
				"aria-disabled": i || !p.includes(t) && (n != null || f.pieces[t] < 0),
				tabIndex: i ? -1 : 0,
				onPointerEnter: () => d(t),
				onPointerLeave: () => d(null),
				onFocus: () => d(t),
				onBlur: () => d(null),
				onClick: () => {
					i || (n ? p.includes(t) && o?.(t) : f.pieces[t] >= 0 && s?.(f.pieces[t]));
				},
				onKeyDown: (e) => {
					(e.key === "Enter" || e.key === " ") && (e.preventDefault(), !i && (n && p.includes(t) ? o?.(t) : !n && f.pieces[t] >= 0 && s?.(f.pieces[t])));
				}
			})] }, t)),
			[18, 342].flatMap((e) => [18, 342].map((t) => /* @__PURE__ */ g("g", { children: [/* @__PURE__ */ h("circle", {
				cx: e,
				cy: t,
				r: "4",
				fill: "#c49b65"
			}), /* @__PURE__ */ h("path", {
				d: `M${e - 2} ${t + 2}l4-4`,
				stroke: "#4a3b31"
			})] }, `${e},${t}`)))
		]
	});
}
//#endregion
//#region src/games/archeologic/view-player.tsx
var $ = [
	"games.archeologic.piece0",
	"games.archeologic.piece1",
	"games.archeologic.piece2",
	"games.archeologic.piece3",
	"games.archeologic.piece4",
	"games.archeologic.piece5"
], re = [
	"games.archeologic.clue1",
	"games.archeologic.clue2",
	"games.archeologic.clue3",
	"games.archeologic.clue4",
	"games.archeologic.clue5",
	"games.archeologic.clue6",
	"games.archeologic.clue7",
	"games.archeologic.clue8",
	"games.archeologic.clue9",
	"games.archeologic.clue10",
	"games.archeologic.clue11",
	"games.archeologic.clue12",
	"games.archeologic.clue13",
	"games.archeologic.clue14",
	"games.archeologic.clue15",
	"games.archeologic.clue16",
	"games.archeologic.clue17",
	"games.archeologic.clue18",
	"games.archeologic.clue19",
	"games.archeologic.clue20",
	"games.archeologic.clue21",
	"games.archeologic.clue22"
];
function ie({ answer: e }) {
	let t = u();
	return /* @__PURE__ */ h("span", {
		className: "arc-answer",
		"aria-label": e.number === null ? e.symbols.map((e) => t(e === 1 ? "games.archeologic.sharp" : e === 2 ? "games.archeologic.fire" : "games.archeologic.safe")).join(", ") || t("games.archeologic.noSymbols") : String(e.number),
		children: e.number === null ? e.symbols.length ? e.symbols.map((e, t) => /* @__PURE__ */ h(Y, { symbol: e }, t)) : /* @__PURE__ */ h("span", { children: "—" }) : /* @__PURE__ */ h("b", { children: e.number })
	});
}
function ae({ clue: e }) {
	let t = u(), n = String.fromCharCode(65 + e.a % 5) + (Math.floor(e.a / 5) + 1);
	return /* @__PURE__ */ g("li", {
		className: "arc-clue",
		children: [/* @__PURE__ */ h("span", { children: t(re[e.type - 1], {
			a: e.type === 22 ? n : t($[e.a]),
			b: e.b >= 0 ? t($[e.b]) : ""
		}) }), e.type === 1 && /* @__PURE__ */ h(Z, {
			piece: e.a,
			rotation: e.rotation
		})]
	});
}
function oe({ question: e }) {
	return e >= 3 ? /* @__PURE__ */ h(Z, { piece: S[e] }) : e === 2 ? /* @__PURE__ */ g("span", {
		className: "arc-trap-pair",
		children: [/* @__PURE__ */ h(Y, { symbol: 1 }), /* @__PURE__ */ h(Y, { symbol: 2 })]
	}) : /* @__PURE__ */ h("svg", {
		viewBox: "0 0 60 50",
		"aria-hidden": "true",
		children: e === 0 ? /* @__PURE__ */ h("rect", {
			x: "12",
			y: "7",
			width: "36",
			height: "36",
			fill: "none",
			stroke: "#93e3ef",
			strokeWidth: "2",
			strokeDasharray: "5 4"
		}) : /* @__PURE__ */ g("g", {
			fill: "#b9dce9",
			stroke: "#3c8ca9",
			strokeWidth: "2",
			children: [/* @__PURE__ */ h("path", { d: "M8 10H22V24H36V38H8Z" }), /* @__PURE__ */ h("path", { d: "M35 7H51V23H35Z" })]
		})
	});
}
function se({ public: e, private: t, members: n, myRid: r, send: i }) {
	let _ = e, v = t, y = u(), b = l((e) => e.locale);
	d();
	let [w, T] = a(null), E = w?.rid === r ? w : null, [D, O] = a(null), [k, A] = a(3), [j, N] = a("initial"), P = _.players.find((e) => e.rid === r), F = _.active === r && _.phase === "play", I = P?.mode === "search" && _.phase !== "done", L = D?.at === _.axis ? D.value : (_.axis + 1) % 10, R = $.map((e) => y(e)), z = (e) => e === 0 ? y("games.archeologic.query0") : e === 1 ? y("games.archeologic.query1") : e === 2 ? y("games.archeologic.query2") : R[S[e]], B = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? p(t, b) : e;
	}, V = (e) => T({
		rid: r,
		piece: e,
		rotation: v.draft[e]?.rotation ?? 0
	}), H = C[k] + M(_.axis, L);
	return /* @__PURE__ */ h(f, {
		adaptive: !0,
		scroll: !1,
		className: "arc-screen",
		banner: /* @__PURE__ */ g("header", {
			className: "arc-header",
			children: [/* @__PURE__ */ g("div", {
				className: "arc-title",
				children: [/* @__PURE__ */ h("h1", { children: y("games.archeologic.name") }), /* @__PURE__ */ g("span", { children: [
					y("games.archeologic.card", { n: _.card }),
					" · ",
					y(_.mode === "normal" ? "games.archeologic.normal" : "games.archeologic.expert")
				] })]
			}), /* @__PURE__ */ h("div", {
				className: "arc-time-track",
				children: _.players.map((e) => /* @__PURE__ */ g("div", {
					className: "arc-time-pawn",
					"data-active": e.rid === _.active,
					"data-out": e.mode === "out",
					children: [
						/* @__PURE__ */ h("b", { children: B(e.rid) }),
						/* @__PURE__ */ h("strong", { children: e.time }),
						/* @__PURE__ */ h("small", { children: y(e.mode === "check" ? "games.archeologic.checking" : e.mode === "out" ? "games.archeologic.out" : "games.archeologic.searching") })
					]
				}, e.rid))
			})]
		}),
		children: /* @__PURE__ */ g("div", {
			className: "arc-stage",
			children: [/* @__PURE__ */ g("section", {
				className: "arc-map-workspace",
				children: [/* @__PURE__ */ h("div", {
					className: "arc-board-space",
					children: /* @__PURE__ */ h(Q, {
						draft: v.draft,
						traps: _.traps,
						selected: I ? E : null,
						feedback: v.feedback,
						disabled: !I,
						onPiece: V,
						onCell: (e) => {
							E && (i({
								type: "place",
								piece: E.piece,
								placement: {
									x: e % 5,
									y: Math.floor(e / 5),
									rotation: E.rotation
								}
							}), T(null));
						}
					})
				}), /* @__PURE__ */ h("div", {
					className: "arc-tray",
					children: R.map((e, t) => /* @__PURE__ */ g("div", {
						className: "arc-tray-slot",
						"data-selected": E?.piece === t,
						children: [/* @__PURE__ */ g("button", {
							type: "button",
							disabled: !I,
							className: "arc-piece-choice",
							"aria-label": y("games.archeologic.selectPiece", { piece: e }),
							"aria-pressed": E?.piece === t,
							onClick: () => V(t),
							children: [
								/* @__PURE__ */ h(Z, {
									piece: t,
									rotation: E?.piece === t ? E.rotation : v.draft[t]?.rotation ?? 0
								}),
								/* @__PURE__ */ h("span", { children: e }),
								/* @__PURE__ */ h("small", { children: v.draft[t] ? "✓" : "" })
							]
						}), E?.piece === t && /* @__PURE__ */ g("div", {
							className: "arc-piece-tools",
							children: [/* @__PURE__ */ h("button", {
								type: "button",
								"aria-label": y("games.archeologic.rotate", { piece: e }),
								onClick: () => T({
									rid: r,
									piece: t,
									rotation: (E.rotation + 1) % 4
								}),
								children: /* @__PURE__ */ h(c, { size: 18 })
							}), /* @__PURE__ */ h("button", {
								type: "button",
								"aria-label": y("games.archeologic.remove", { piece: e }),
								disabled: !v.draft[t],
								onClick: () => {
									i({
										type: "place",
										piece: t,
										placement: null
									}), T(null);
								},
								children: /* @__PURE__ */ h(s, { size: 18 })
							})]
						})]
					}, t))
				})]
			}), /* @__PURE__ */ g("section", {
				className: "arc-observer-workspace",
				"data-observing": _.phase === "observing",
				children: [
					/* @__PURE__ */ g("div", {
						className: "arc-instrument",
						children: [/* @__PURE__ */ h(ne, {
							axis: _.axis,
							selected: L,
							disabled: !F || P?.mode !== "search",
							onSelect: (e) => O({
								at: _.axis,
								value: e
							})
						}), /* @__PURE__ */ h("div", {
							className: "arc-questions",
							children: C.map((e, t) => /* @__PURE__ */ g("button", {
								type: "button",
								className: "arc-question",
								disabled: !F || P?.mode !== "search",
								"aria-pressed": k === t,
								"aria-label": z(t),
								title: z(t),
								onClick: () => A(t),
								children: [
									/* @__PURE__ */ h(oe, { question: t }),
									/* @__PURE__ */ h("span", { children: z(t) }),
									/* @__PURE__ */ h("small", { children: e })
								]
							}, t))
						})]
					}),
					/* @__PURE__ */ h("div", {
						className: "arc-action-slot",
						children: P?.mode === "check" ? /* @__PURE__ */ h("button", {
							type: "button",
							className: "arc-primary",
							disabled: !F,
							onClick: () => i({ type: "check" }),
							children: y("games.archeologic.check")
						}) : /* @__PURE__ */ g(m, { children: [/* @__PURE__ */ h("button", {
							type: "button",
							className: "arc-primary",
							disabled: !F || P?.mode !== "search",
							onClick: () => {
								i({
									type: "query",
									axis: L,
									question: k
								}), N("history");
							},
							children: y("games.archeologic.ask", { n: H })
						}), /* @__PURE__ */ h("button", {
							type: "button",
							disabled: !F || !v.draft.every(Boolean),
							onClick: () => i({ type: "declare" }),
							children: y("games.archeologic.declare")
						})] })
					}),
					/* @__PURE__ */ h("div", {
						className: "arc-turn-note",
						role: "status",
						children: _.phase === "observing" ? y("games.archeologic.observing") : F ? y("games.archeologic.turn", { name: B(r) }) : y("games.archeologic.waiting", { name: B(_.active) })
					}),
					/* @__PURE__ */ g("div", {
						className: "arc-notebook",
						children: [/* @__PURE__ */ h("nav", {
							className: "arc-tabs",
							children: [
								"initial",
								"history",
								"notes"
							].map((e) => /* @__PURE__ */ g("button", {
								type: "button",
								"aria-pressed": j === e,
								onClick: () => N(e),
								children: [y(e === "initial" ? "games.archeologic.initial" : e === "history" ? "games.archeologic.history" : "games.archeologic.notes"), e === "history" && v.history.length > 0 ? ` (${v.history.length})` : ""]
							}, e))
						}), /* @__PURE__ */ g("div", {
							className: "arc-notebook-page",
							children: [
								v.feedback && !v.feedback.every(Boolean) && /* @__PURE__ */ h("p", {
									className: "arc-correction",
									children: y("games.archeologic.incorrect")
								}),
								j === "initial" && /* @__PURE__ */ g("ul", {
									className: "arc-clues",
									children: [_.traps.map(({ cell: e, symbol: t }) => /* @__PURE__ */ g("li", {
										className: "arc-clue",
										children: [
											/* @__PURE__ */ g("b", { children: [String.fromCharCode(65 + e % 5), Math.floor(e / 5) + 1] }),
											/* @__PURE__ */ h(Y, { symbol: t }),
											/* @__PURE__ */ h("span", { children: y(t === 1 ? "games.archeologic.sharp" : "games.archeologic.fire") })
										]
									}, e)), _.clues.map((e, t) => /* @__PURE__ */ h(ae, { clue: e }, t))]
								}),
								j === "history" && /* @__PURE__ */ h("div", {
									className: "arc-history",
									children: v.history.length === 0 ? /* @__PURE__ */ h("p", { children: y("games.archeologic.noHistory") }) : [...v.history].reverse().map((e, t) => /* @__PURE__ */ g("div", {
										className: "arc-observation",
										children: [
											/* @__PURE__ */ h("b", { children: x[e.axis] }),
											/* @__PURE__ */ h("span", { children: z(e.question) }),
											/* @__PURE__ */ h(ie, { answer: e.answer }),
											/* @__PURE__ */ h("small", { children: y("games.archeologic.time", { n: e.time }) })
										]
									}, v.history.length - t))
								}),
								j === "notes" && /* @__PURE__ */ h("textarea", {
									"aria-label": y("games.archeologic.notes"),
									maxLength: 2e3,
									defaultValue: v.text,
									placeholder: y("games.archeologic.notesPlaceholder"),
									onBlur: (e) => {
										e.target.value !== v.text && i({
											type: "note",
											text: e.target.value
										});
									}
								}, r)
							]
						})]
					}),
					/* @__PURE__ */ h("div", {
						className: "arc-withdraw",
						children: F ? /* @__PURE__ */ h(o, {
							label: y("games.archeologic.withdraw"),
							confirmLabel: y("games.archeologic.confirmWithdraw"),
							onConfirm: () => i({ type: "withdraw" }),
							className: "arc-quiet"
						}) : /* @__PURE__ */ h("button", {
							type: "button",
							disabled: !0,
							children: y("games.archeologic.withdraw")
						})
					})
				]
			})]
		})
	});
}
//#endregion
//#region src/games/archeologic/bot.ts
var ce = {
	information: 1,
	cost: 1
};
function le(e, t) {
	let n = Array.from({ length: 6 }, (n, r) => P(r).filter((n) => {
		let i = E(r, n), a = [
			,
			,
			,
			,
			,
			,
		].fill(null);
		if (a[r] = n, e.traps.some((e) => i.some((t) => t.cell === e.cell && t.symbol !== e.symbol)) || !e.clues.every((e) => F(e, a)) || t.submitted && t.feedback && N(r, n, t.submitted[r]) !== t.feedback[r]) return !1;
		let o = O(a);
		return t.history.filter((e) => S[e.question] === r).every((e) => j(A(o.pieces, o.symbols, e.axis, e.question)) === j(e.answer));
	})), r = !0;
	for (; r;) {
		r = !1;
		for (let t = 0; t < 6; t++) {
			let i = n[t].filter((r) => n.every((n, i) => i === t || n.some((n) => {
				let a = [
					,
					,
					,
					,
					,
					,
				].fill(null);
				return a[t] = r, D(a, i, n) ? (a[i] = n, e.clues.every((e) => F(e, a))) : !1;
			})));
			i.length !== n[t].length && (n[t] = i, r = !0);
		}
	}
	return n;
}
function ue(e, t, n, r) {
	let i = [];
	for (let a = 3; a <= 8; a++) {
		let o = S[a];
		if (!(n[o].length <= 1)) for (let s = 0; s < 10; s++) {
			if (t.history.some((e) => e.axis === s && e.question === a)) continue;
			let c = /* @__PURE__ */ new Map();
			for (let e of n[o]) {
				let t = [
					,
					,
					,
					,
					,
					,
				].fill(null);
				t[o] = e;
				let n = O(t), r = j(A(n.pieces, n.symbols, s, a));
				c.set(r, (c.get(r) ?? 0) + 1);
			}
			if (c.size < 2) continue;
			let l = C[a] + M(e.axis, s), u = n[o].length, d = u - [...c.values()].reduce((e, t) => e + t * t, 0) / u;
			i.push({
				axis: s,
				question: a,
				score: r.information ? d / l ** r.cost : -a * 100 - l * 10 - s
			});
		}
	}
	return i.sort((e, t) => t.score - e.score)[0];
}
function de(e, t) {
	let n = [
		0,
		1,
		2,
		3,
		4,
		5
	].sort((e, n) => t[e].length - t[n].length), r = [
		,
		,
		,
		,
		,
		,
	].fill(null), i = 1e5;
	function a(o) {
		if (--i < 0) return !1;
		if (o === 6) {
			let t = O(r);
			return e.traps.every((e) => t.pieces[e.cell] >= 0 && t.symbols[e.cell] === e.symbol);
		}
		let s = n[o];
		for (let n of t[s]) if (D(r, s, n)) {
			if (r[s] = n, e.clues.every((e) => F(e, r)) && a(o + 1)) return !0;
			r[s] = null;
		}
		return !1;
	}
	return a(0) ? r : null;
}
function fe(e = ce) {
	return (t, n) => {
		let r = t.public, i = t.private;
		if (!i || r.phase !== "play" || r.active !== n.rid) return null;
		let a = r.players.find((e) => e.rid === n.rid);
		if (a.mode === "check") return { action: { type: "check" } };
		if (a.mode === "out") return null;
		let o = le(r, i), s = ue(r, i, o, n.difficulty === "weak" ? {
			information: 0,
			cost: 1
		} : e);
		if (s) return { action: {
			type: "query",
			axis: s.axis,
			question: s.question
		} };
		let c = de(r, o);
		if (!c) return { action: { type: "withdraw" } };
		for (let e = 0; e < 6; e++) if (i.draft[e] && !N(e, i.draft[e], c[e])) return { action: {
			type: "place",
			piece: e,
			placement: null
		} };
		for (let e = 0; e < 6; e++) if (!i.draft[e]) return { action: {
			type: "place",
			piece: e,
			placement: c[e]
		} };
		return { action: { type: "declare" } };
	};
}
var pe = fe(), me = (e, t, n) => e.type === "query" ? n("games.archeologic.hintQuery", {
	axis: x[e.axis],
	question: e.question + 1
}) : e.type === "place" ? e.placement ? n("games.archeologic.hintPlace", {
	n: e.piece + 1,
	cell: String.fromCharCode(65 + e.placement.x) + (e.placement.y + 1)
}) : n("games.archeologic.hintRemove", { n: e.piece + 1 }) : e.type === "declare" ? n("games.archeologic.declare") : e.type === "check" ? n("games.archeologic.check") : "";
//#endregion
//#region src/games/archeologic/game-over.tsx
function he({ public: e, result: t, members: r, hintCount: c, onPlayAgain: d, onBackToLobby: f }) {
	let m = e, _ = u(), v = l((e) => e.locale), [y, b] = a(!0), x = i(null), S = i(null), C = i(null);
	n(() => {
		(y ? S : C).current?.focus();
	}, [y]);
	let w = (e) => {
		let t = r.find((t) => t.rid === e);
		return t ? p(t, v) : e;
	}, T = m.players.find((e) => e.rid === m.winner), E = m.winner ? _("games.archeologic.solved", { name: w(m.winner) }) : _("games.archeologic.unsolved");
	return /* @__PURE__ */ g("div", {
		className: "arc-result arc-screen",
		children: [
			/* @__PURE__ */ h("div", {
				className: "arc-final-map",
				inert: y,
				"aria-hidden": y,
				children: /* @__PURE__ */ h(Q, {
					draft: m.solution ?? [
						,
						,
						,
						,
						,
						,
					].fill(null),
					disabled: !0
				})
			}),
			!y && /* @__PURE__ */ h("button", {
				type: "button",
				ref: C,
				className: "arc-result-restore",
				onClick: () => b(!0),
				children: _("games.archeologic.showResult")
			}),
			y && /* @__PURE__ */ h("div", {
				className: "arc-result-shade",
				children: /* @__PURE__ */ g("div", {
					className: "arc-result-dialog",
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": "arc-result-title",
					ref: x,
					onKeyDown: (e) => {
						if (e.key === "Escape" && (e.stopPropagation(), b(!1)), e.key !== "Tab") return;
						let t = Array.from(x.current?.querySelectorAll("button:not(:disabled)") ?? []);
						e.shiftKey && document.activeElement === t[0] ? (e.preventDefault(), t.at(-1)?.focus()) : !e.shiftKey && document.activeElement === t.at(-1) && (e.preventDefault(), t[0]?.focus());
					},
					children: [
						/* @__PURE__ */ g("header", { children: [/* @__PURE__ */ g("div", { children: [/* @__PURE__ */ g("small", { children: [
							_("games.archeologic.final"),
							" · ",
							m.card
						] }), /* @__PURE__ */ h("h1", {
							id: "arc-result-title",
							children: E
						})] }), /* @__PURE__ */ h("button", {
							type: "button",
							ref: S,
							"aria-label": _("games.archeologic.review"),
							onClick: () => b(!1),
							children: /* @__PURE__ */ h(s, { size: 22 })
						})] }),
						/* @__PURE__ */ g("div", {
							className: "arc-result-details",
							children: [
								m.players.length === 1 && T && /* @__PURE__ */ g("section", {
									className: "arc-title-award",
									children: [
										/* @__PURE__ */ h("span", {
											"aria-hidden": "true",
											children: "◇"
										}),
										/* @__PURE__ */ h("h2", { children: _(T.time <= m.thresholds[0] ? "games.archeologic.master" : T.time <= m.thresholds[1] ? "games.archeologic.seasoned" : "games.archeologic.apprentice") }),
										/* @__PURE__ */ h("p", { children: _("games.archeologic.target", {
											a: m.thresholds[0],
											b: m.thresholds[1]
										}) })
									]
								}),
								m.players.map((e) => /* @__PURE__ */ g("section", {
									className: "arc-expedition-row",
									"data-winner": e.rid === m.winner,
									children: [
										/* @__PURE__ */ h("h3", { children: w(e.rid) }),
										/* @__PURE__ */ h("strong", { children: _("games.archeologic.time", { n: e.time }) }),
										/* @__PURE__ */ h("span", { children: _("games.archeologic.queries", { n: e.queries }) }),
										(t.autopilot?.[e.rid] ?? 0) > 0 && /* @__PURE__ */ h("small", { children: _("session.autopilot.share", { n: Math.round(t.autopilot[e.rid] * 100) }) })
									]
								}, e.rid)),
								c !== void 0 && /* @__PURE__ */ h("p", { children: _("session.hint.usedCount", { n: c }) })
							]
						}),
						/* @__PURE__ */ g("footer", { children: [
							/* @__PURE__ */ h("button", {
								type: "button",
								onClick: () => b(!1),
								children: _("games.archeologic.review")
							}),
							d && /* @__PURE__ */ h(o, {
								label: _("session.result.playAgain"),
								confirmLabel: _("games.archeologic.confirmAgain"),
								onConfirm: d,
								className: "arc-primary"
							}),
							f && /* @__PURE__ */ h(o, {
								label: _("session.result.backToLobby"),
								confirmLabel: _("games.archeologic.confirmLeave"),
								onConfirm: f
							}),
							!d && !f && /* @__PURE__ */ h("p", { children: _("session.result.waitHost") })
						] })
					]
				})
			})
		]
	});
}
//#endregion
//#region src/games/archeologic/options.tsx
var ge = /* @__PURE__ */ "3537.3573.3575.3577.3735.3753.3755.3757.5337.5357.5373.5375.5377.5537.5733.5737.5773.7335.7353.7355.7357.7375.7533.7535.7537.7553.7573.7735".split(".");
function _e({ value: e, onChange: t }) {
	let n = u(), r = z.safeParse(e), i = r.success ? r.data : z.parse(void 0);
	return /* @__PURE__ */ g("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ h(v, {
				title: n("games.archeologic.optMode"),
				columns: 2,
				children: ["normal", "expert"].map((e) => /* @__PURE__ */ h(_, {
					name: "arc-mode",
					value: e,
					checked: i.mode === e,
					label: n(e === "normal" ? "games.archeologic.normal" : "games.archeologic.expert"),
					accent: b.accent,
					onChange: () => t({
						...i,
						mode: e
					})
				}, e))
			}),
			/* @__PURE__ */ g("label", {
				className: "flex flex-col gap-1",
				children: [n("games.archeologic.optCard"), /* @__PURE__ */ g("select", {
					className: "rounded border p-2",
					value: i.card,
					onChange: (e) => t({
						...i,
						card: Number(e.target.value)
					}),
					children: [/* @__PURE__ */ h("option", {
						value: -1,
						children: n("games.archeologic.random")
					}), ge.map((e, t) => /* @__PURE__ */ h("option", {
						value: t,
						children: e
					}, e))]
				})]
			}),
			i.mode === "normal" ? /* @__PURE__ */ h(v, {
				title: n("games.archeologic.optClues"),
				columns: 3,
				children: [
					3,
					4,
					5
				].map((e) => /* @__PURE__ */ h(_, {
					name: "arc-clues",
					value: String(e),
					checked: i.clues === e,
					label: n("games.archeologic.clues", { n: e }),
					accent: b.accent,
					onChange: () => t({
						...i,
						clues: e
					})
				}, e))
			}) : /* @__PURE__ */ g("label", {
				className: "flex flex-col gap-1",
				children: [n("games.archeologic.optExpert"), /* @__PURE__ */ g("select", {
					className: "rounded border p-2",
					value: i.expert,
					onChange: (e) => t({
						...i,
						expert: Number(e.target.value)
					}),
					children: [/* @__PURE__ */ h("option", {
						value: -1,
						children: n("games.archeologic.random")
					}), Array.from({ length: 12 }, (e, t) => /* @__PURE__ */ h("option", {
						value: t,
						children: n("games.archeologic.set", { n: t + 1 })
					}, t))]
				})]
			}),
			/* @__PURE__ */ h(v, {
				title: n("games.archeologic.optVerification"),
				children: ["app", "strict"].map((e) => /* @__PURE__ */ h(_, {
					name: "arc-verification",
					value: e,
					checked: i.verification === e,
					label: n(e === "app" ? "games.archeologic.app" : "games.archeologic.strict"),
					accent: b.accent,
					onChange: () => t({
						...i,
						verification: e
					})
				}, e))
			}),
			/* @__PURE__ */ h(v, {
				title: n("games.archeologic.optAxis"),
				columns: 2,
				children: x.map((e, n) => /* @__PURE__ */ h(_, {
					name: "arc-axis",
					value: String(n),
					checked: i.soloAxis === n,
					label: e,
					accent: b.accent,
					onChange: () => t({
						...i,
						soloAxis: n
					})
				}, e))
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/archeologic/entry.tsx
var ve = {
	definition: J,
	View: se,
	bot: pe,
	describe: me,
	OverView: he,
	Options: _e,
	locales: {
		zh: {
			name: "镜中解",
			desc: "转动观测仪，推理失落城市的建筑布局。",
			rules: "目标：\n推理5行5列城市地图中六块建筑的位置和朝向。建筑只能旋转，不能翻面；共占22格，剩余3格为空地。\n\n准备：\n选择基础版28张题卡之一或随机题卡。普通模式提供3、4或5条陷阱坐标；单人固定3条。专家模式为每张题卡提供12套起始条件。所有玩家获得相同起始信息，各自保留私有地图与问答记录。\n\n回合：\n时间轨最落后的玩家行动，可能连续行动。每次前进时跳过其他仍在游戏中的玩家占据的格子，不消耗步数。\n\n提问：\n每次先将观测标记顺时针免费移动1步；额外移动1步需要支付1点时间，移到任意其他轴需要支付2点时间。顺时针顺序为1、E、4、C、2、A、5、D、3、B。选择一个观测轴和一种问题后，支付相应的时间费用：\n· 询问空地数量或不同建筑的数量，需要支付1点时间。\n· 询问陷阱符号或三格建筑的符号，需要支付2点时间。\n· 询问四格建筑的符号，需要支付3点时间。\n问题公开，答案仅提问者可见；答案只提供符号及各自数量，不透露沿轴的位置。历史答案可免费查看。\n\n摆放：\n选择建筑，再选择合法落点；旋转工具位于所选建筑旁。可在等待他人行动时整理自己的地图和笔记。\n\n宣布解谜：\n在自己回合开始时，完整摆放六块建筑后支付4点时间，冻结提交地图。不移动观测标记，也不提问。等时间轨再次轮到自己时验证。正确则立即获胜。App规则下，错误建筑会被标明，玩家立即再行动一次；实体规则下，猜错者退出，其余玩家继续。所有人退出则无人获胜。\n\n单人：\n从时间0开始，可在设置中选择初始观测轴。每次答案含有一个火焰或尖刺符号，观测标记额外顺时针移动1步。完成时按官方App的题目时间标准获得大师、熟练或学徒评价。",
			card: "题卡 {{n}}",
			normal: "普通模式",
			expert: "专家模式",
			set: "第{{n}}套条件",
			random: "随机",
			optCard: "题卡",
			optMode: "模式",
			optClues: "普通起始线索（单人固定3条）",
			clues: "{{n}}条线索",
			optExpert: "专家条件",
			optVerification: "解谜验证",
			app: "App规则：标明错块后继续",
			strict: "实体规则：猜错后退出",
			optAxis: "单人初始观测轴",
			axis: "观测轴 {{axis}}",
			chooseAxis: "选择观测轴 {{axis}}",
			time: "{{n}}时间",
			turn: "轮到{{name}}",
			waiting: "等待{{name}}",
			observing: "观测中",
			searching: "搜索",
			checking: "待验证",
			out: "已退出",
			query0: "空地数量",
			query1: "不同建筑数量",
			query2: "陷阱符号",
			piece0: "长条建筑",
			piece1: "大L形建筑",
			piece2: "方形建筑",
			piece3: "T形建筑",
			piece4: "小L形建筑",
			piece5: "Z形建筑",
			selectPiece: "选择{{piece}}",
			rotate: "顺时针旋转{{piece}}",
			remove: "取回{{piece}}",
			cell: "城市格 {{cell}}",
			placeAt: "将{{piece}}放在{{cell}}",
			ask: "观测 · {{n}}时间",
			declare: "宣布解谜 · 4时间",
			check: "验证提交的地图",
			fire: "火焰陷阱",
			sharp: "尖刺陷阱",
			safe: "安全区域",
			noSymbols: "没有符号",
			answer: "观测结果",
			history: "问答记录",
			notes: "私人笔记",
			notesPlaceholder: "记录自己的推理……",
			noHistory: "尚未进行观测",
			initial: "起始线索",
			instrument: "观测仪",
			incorrect: "地图有误。标记的建筑需要调整，现在可以继续行动。",
			correctPiece: "位置和朝向正确",
			incorrectPiece: "位置或朝向有误",
			withdraw: "结束探索",
			confirmWithdraw: "确认结束探索",
			errorAction: "当前不能执行这个动作。",
			errorIncomplete: "请先在地图上完整摆放六块建筑。",
			solved: "{{name}}解开了城市之谜",
			unsolved: "本次未能解开城市之谜",
			final: "探索报告",
			review: "回看地图",
			showResult: "查看探索报告",
			master: "大师考古学家",
			seasoned: "熟练考古学家",
			apprentice: "学徒考古学家",
			target: "大师 {{a}}时间 · 熟练 {{b}}时间",
			queries: "{{n}}次观测",
			confirmAgain: "确认再来一局",
			confirmLeave: "确认返回大厅",
			hintQuery: "在{{axis}}轴进行第{{question}}种观测。",
			hintPlace: "将第{{n}}块建筑放在{{cell}}。",
			hintRemove: "取回第{{n}}块建筑，准备重新摆放。",
			clue1: "{{a}}的朝向如下图。",
			clue2: "{{a}}接触地图边缘。",
			clue3: "{{a}}不接触地图边缘。",
			clue4: "{{a}}接触左边缘或右边缘。",
			clue5: "{{a}}不接触左边缘和右边缘。",
			clue6: "{{a}}接触上边缘或下边缘。",
			clue7: "{{a}}不接触上边缘和下边缘。",
			clue8: "{{a}}占据地图的一个角格。",
			clue9: "{{a}}与{{b}}至少有一条边相接。",
			clue10: "{{a}}与{{b}}没有边相接。",
			clue11: "{{a}}与{{b}}仅以角相接。",
			clue12: "{{a}}与{{b}}至少占据同一行。",
			clue13: "{{a}}与{{b}}没有占据同一行。",
			clue14: "{{a}}与{{b}}至少占据同一列。",
			clue15: "{{a}}与{{b}}没有占据同一列。",
			clue16: "{{a}}至少有一格位于{{b}}最右格的右侧。",
			clue17: "{{a}}至少有一格位于{{b}}最左格的左侧。",
			clue18: "{{a}}至少有一格位于{{b}}最上格的上方。",
			clue19: "{{a}}至少有一格位于{{b}}最下格的下方。",
			clue20: "{{a}}整体位于{{b}}的右侧。",
			clue21: "{{a}}整体位于{{b}}的下方。",
			clue22: "{{a}}为空地。"
		},
		en: {
			name: "ArcheOlogic",
			desc: "Turn the Archeoscope and deduce the lost city.",
			rules: "Goal: Discover the positions and orientations of six buildings on a 5×5 map. Buildings may rotate but never flip. They occupy 22 cells, leaving 3 empty zones.\nSetup: Choose one of 28 base-game cards or a random card. Normal mode provides 3,4 or 5 trap coordinates; solo always uses 3. Expert mode offers 12 clue sets per card. Everyone receives the same starting information and keeps a private map and answer history.\nTurns: The player furthest behind on the time track acts, sometimes repeatedly. Skip spaces occupied by other active players without spending movement.\nQuestions: First move the viewfinder one step clockwise for free. One further step costs 1 time; any other axis costs 2. The clockwise order is 1,E,4,C,2,A,5,D,3,B. Choose an axis and a question, then pay its time cost:\n· Asking about empty zones or the number of distinct buildings costs 1 time.\n· Asking about trap symbols or the symbols of a three-cell building costs 2 time.\n· Asking about the symbols of a four-cell building costs 3 time.\n The question is public and the answer private. Symbols and their counts do not reveal positions along the axis. Revisit previous answers for free.\nPlacement: Select a building, then a legal origin cell. Its rotation tool stays beside it. Rearrange your map and notes while other players act.\nDeclare: At the start of your turn, place all six buildings and spend 4 time to submit and freeze your map. Do not move the viewfinder or ask a question. Check when the time track next reaches you. A correct map wins immediately. Under app rules, incorrect buildings are marked and you immediately take another turn. Under physical rules, an incorrect guess eliminates you; others continue. If everyone is eliminated, nobody wins.\nSolo: Start at time 0 and choose the starting axis in settings. For each fire or sharp trap symbol in an answer, move the viewfinder one extra step clockwise. Finish within the official app thresholds to become a Master, Seasoned or Apprentice Archaeologist.",
			card: "Card {{n}}",
			normal: "Normal",
			expert: "Expert",
			set: "Clue set {{n}}",
			random: "Random",
			optCard: "Card",
			optMode: "Mode",
			optClues: "Starting clues (solo always uses 3)",
			clues: "{{n}} clues",
			optExpert: "Expert clues",
			optVerification: "Checking a solution",
			app: "App: mark wrong buildings and continue",
			strict: "Physical: an incorrect guess eliminates you",
			optAxis: "Solo starting axis",
			axis: "Axis {{axis}}",
			chooseAxis: "Choose axis {{axis}}",
			time: "{{n}} time",
			turn: "{{name}}'s turn",
			waiting: "Waiting for {{name}}",
			observing: "Observing",
			searching: "Searching",
			checking: "Checking",
			out: "Eliminated",
			query0: "Empty zones",
			query1: "Distinct buildings",
			query2: "Trap symbols",
			piece0: "Straight building",
			piece1: "Large L building",
			piece2: "Square building",
			piece3: "T building",
			piece4: "Small L building",
			piece5: "Z building",
			selectPiece: "Select {{piece}}",
			rotate: "Rotate {{piece}} clockwise",
			remove: "Return {{piece}}",
			cell: "Map cell {{cell}}",
			placeAt: "Place {{piece}} at {{cell}}",
			ask: "Observe · {{n}} time",
			declare: "Declare ·4 time",
			check: "Check submitted map",
			fire: "Fire trap",
			sharp: "Sharp trap",
			safe: "Risk-free zone",
			noSymbols: "No symbols",
			answer: "Observation",
			history: "Answers",
			notes: "Private notes",
			notesPlaceholder: "Record your deductions…",
			noHistory: "No observations yet",
			initial: "Starting clues",
			instrument: "Archeoscope",
			incorrect: "The map is incorrect. Adjust the marked buildings and take another turn.",
			correctPiece: "Correct position and orientation",
			incorrectPiece: "Incorrect position or orientation",
			withdraw: "End exploration",
			confirmWithdraw: "Confirm end exploration",
			errorAction: "You cannot do that now.",
			errorIncomplete: "Place all six buildings on the map first.",
			solved: "{{name}} solved the city",
			unsolved: "The city remains unsolved",
			final: "Expedition report",
			review: "Review map",
			showResult: "Show expedition report",
			master: "Master Archaeologist",
			seasoned: "Seasoned Archaeologist",
			apprentice: "Apprentice Archaeologist",
			target: "Master {{a}} time · Seasoned {{b}} time",
			queries: "{{n}} observations",
			confirmAgain: "Confirm play again",
			confirmLeave: "Confirm return to lobby",
			hintQuery: "Use observation {{question}} on axis {{axis}}.",
			hintPlace: "Place building {{n}} at {{cell}}.",
			hintRemove: "Return building {{n}} before placing it again.",
			clue1: "{{a}} has the orientation shown.",
			clue2: "{{a}} touches an edge.",
			clue3: "{{a}} does not touch an edge.",
			clue4: "{{a}} touches the left or right edge.",
			clue5: "{{a}} touches neither the left nor the right edge.",
			clue6: "{{a}} touches the top or bottom edge.",
			clue7: "{{a}} touches neither the top nor the bottom edge.",
			clue8: "{{a}} occupies a corner cell.",
			clue9: "{{a}} and {{b}} share at least one edge.",
			clue10: "{{a}} and {{b}} share no edge.",
			clue11: "{{a}} and {{b}} touch only by a corner.",
			clue12: "{{a}} and {{b}} occupy at least one common row.",
			clue13: "{{a}} and {{b}} occupy no common row.",
			clue14: "{{a}} and {{b}} occupy at least one common column.",
			clue15: "{{a}} and {{b}} occupy no common column.",
			clue16: "{{a}} extends further right than {{b}}.",
			clue17: "{{a}} extends further left than {{b}}.",
			clue18: "{{a}} extends further up than {{b}}.",
			clue19: "{{a}} extends further down than {{b}}.",
			clue20: "{{a}} is entirely to the right of {{b}}.",
			clue21: "{{a}} is entirely below {{b}}.",
			clue22: "{{a}} is an empty zone."
		}
	}
};
//#endregion
export { ve as default };
